# LIVRO PRIMEIRO 

## CAPÍTULO I

### Louvor e Invocação

 És grande, Senhor e infinitamente digno de ser louvado; grande é teu poder, e incomensurável tua sabedoria. E o homem, pequena parte de tua criação quer louvar-te, e precisamente o homem que, revestido de sua mortalidade, traz em si o testemunho do pecado e a prova de que resistes aos soberbos. Todavia, o homem, partícula de tua criação, deseja louvar-te. Tu mesmo que incitas ao deleite no teu louvor, porque nos fizeste para ti, e nosso coração está inquieto enquanto não encontrar em ti descanso.

 Concede, Senhor, que eu bem saiba se é mais importante invocar-te e louvar-te, ou se devo antes conhecer-te, para depois te invocar. Mas alguém te invocará antes de te conhecer? Porque, te ignorando, facilmente estará em perigo de invocar outrem. Porque, porventura, deves antes ser invocado para depois ser conhecido? Mas como invocarão aquele em que não crêem? Ou como haverão de crer que alguém lhos pregue?

 Com certeza, louvarão ao Senhor os que o buscam, porque os que o buscam o encontram e os que o encontram hão de louvá-lo.

 Que eu, Senhor, te procure invocando-te, e te invoque crendo em ti, pois me pregaram teu nome. invoca-te, Senhor, a fé que tu me deste, a fé que me inspiraste pela humanidade de teu Filho e o ministério de teu pregador.

## CAPÍTULO II

### Deus está no homem, e este em Deus

 E como invocarei meu Deus, meu Deus e meu Senhor, se ao invocá-lo o faria certamente dentro de mim? E que lugar há em mim para receber o meu Deus, por onde Deus desça a mim, o Deus que fez o céu e a terra? Senhor, haverá em mim algum espaço que te possa conter? Acaso te contêm o céu e a terra, que tu criaste, e dentro dos quais também criaste a mim? Será, talvez, pelo fato de nada do que existe sem Ti, que todas as coisas te contêm? E, assim, se existo, que motivo pode haver para Te pedir que venhas a mim, já que não existiria se em mim não habitásseis?

 Ainda não estive no inferno, mas também ali estás presente, pois, se descer ao inferno, ali estarás.

 Eu nada seria, meu Deus, nada seria em absoluto se não estivesses em mim; talvez seria melhor dizer que eu não existiria de modo algum se não estivesse em ti, de quem, por quem e em quem existem todas as coisas? Assim é, Senhor, assim é. Como, pois, posso chamar-te se já estou em ti, ou de onde hás de vir a mim, ou a que parte do céu ou da terra me hei de recolher, para que ali venha a mim o meu Deus, ele que disse: Eu encho o céu e a terra?

## CAPÍTULO III

### Onde está Deus?

 Porventura o céu e a terra te contêm, porque os enches? Ou será melhor dizer que os enches, mas que ainda resta alguma parte de ti, já que eles não te podem conter? E onde estenderás isso que sobra de ti, depois de cheios o céu e a terra? Mas será necessário que sejas contido em algum lugar, tu que conténs todas as coisas, visto que as que enches as ocupas contendo-as? Porque não são os vasos cheios de ti que te tornam estável, já que, quando se quebrarem, tu não te derramarás; e quando te derramas sobre nós, isso não o fazes porque cais, mas porque nos levantas, nem porque te dispersas, mas porque nos recolhes.

 No entanto, todas as coisas que enches, enche-as todas com todo o teu ser; ou talvez, por não te poderem conter totalmente todas as coisas, contêm apenas parte de ti? E essa parte de ti as contêm todas ao mesmo tempo, ou cada uma a sua, as maiores a maior parte, e as menores a menor parte? Mas haverá em ti partes maiores e partes menores? Acaso não estás todo em todas as partes, sem que haja coisa alguma que te contenha totalmente?

## CAPÍTULO IV

### As perfeições de Deus

 Que és, portanto, ó meu Deus? Que és, repito, senão o Senhor Deus? Ó Deus sumo, excelente, poderosíssimo, onipotentíssimo, misericordiosíssimo e justíssimo.

 Tao oculto e tão presente, formosíssimo e fortíssimo, estável e incompreensível; imutável, mudando todas as coisas; nunca novo e nunca velho; renovador de todas as coisas, conduzindo à ruína os soberbos sem que eles o saibam; sempre agindo e sempre repouso; sempre sustentando, enchendo e protegendo; sempre criando, nutrindo e aperfeiçoando, sempre buscando, ainda que nada te falte.

 Amas sem paixão; tens zelos, e estás tranqüilo; te arrependes, e não tens dor; te iras, e continuas calmo; mudas de obra, mas não de resolução; recebes o que encontras, e nunca perdeste nada; não és avaro, e exiges lucro. A ti oferecemos tudo, para que sejas nosso devedor; porém, quem terá algo que não seja teu, pois, pagas dívidas que a ninguém deves, e perdoas dívidas sem que nada percas com isso?

 E que é o que até aqui dissemos, meu Deus, minha vida, minha doçura santa, ou que poderá alguém dizer quando fala de ti? Mas ai dos que nada dizem de ti, pois, embora seu muito falar, não passam de mudos charlatães.

## CAPÍTULO V

### Súplica

 Quem me dera descansar em ti! Quem me dera que viesses a meu coração e que o embriagasses, para que eu me esqueça de minhas maldades e me abrace contigo, meu único bem! Que és para mim? Tem piedade de mim, para que eu possa falar. E que sou eu para ti, para que me ordenes amar-te e, se não o fizer, irar-te contra mim, ameaçando-me com terríveis castigos? Acaso é pequeno o castigo de não te amar? Ai de mim! Dize-me por tuas misericórdias, meu Senhor e meu Deus, que és para mim? Dize a minha alma: Eu sou a tua salvação. Que eu ouça e siga essa voz e te alcance. Não queiras esconder-me teu rosto. Morra eu para que possa vê-lo para não morrer eternamente.

 Estreita é a casa de minha alma para que venhas até ela: que seja por ti dilatada. Está em ruínas; restaura-a. Há nela nódoas que ofendem o teu olhar: confesso-o, pois eu o sei; porém, quem haverá de purificá-la? A quem clamarei senão a ti? Livra-me, Senhor, dos pecados ocultos, e perdoa a teu servo os alheios! Creio, e por isso falo. Tu o sabes, Senhor. Acaso não confessei diante de ti meus delitos contra mim, ó meu Deus? E não me perdoaste a impiedade de meu coração? Não quero contender em juízos contigo, que és a verdade, e não quero enganar-me a mim mesmo, para que não se engane a si mesma minha iniqüidade. Não quero contender em juízos contigo, porque, se dás atenção às iniqüidades, Senhor, quem, Senhor, subsistirá?

## CAPÍTULO VI

### Os primeiros anos

 Permita, porém, que eu fale em presença de tua misericórdia, a mim, terra e cinza; deixa que eu fale, porque é à tua misericórdia que falo, e não ao homem, que de mim escarnece. Talvez também tu te rias de mim, mas, voltado para mim, terás compaixão.

 E que pretendo dizer-te, Senhor, senão que ignoro de onde vim para aqui, para esta não sei se posso chamar vida mortal ou morte vital? Não o sei. Mas receberam-me os consolos de tuas misericórdias, conforme o que ouvi de meus pais carnais, de quem e em quem me formaste no tempo, pois eu de mim nada recordo. Receberam-me os consolos do leite humano, do qual nem minha mãe, nem minhas amas enchiam os seios; mas eras tu que, por meio delas, me davas aquele alimento da infância, de acordo com o seu desígnio, e segundo os tesouros dispostos por ti até no mais íntimo das coisas.

 Também por tua causa é que eu não queria mais do que me davas; por tua causa é que minhas amas queriam dar-me o que tu lhes davas, pois elas, movidas de sadio afeto, queriam darme aquilo que abundavam graças a ti, já que era um bem para elas ou delas receber aquele bem, embora realmente não fosse delas, meros instrumentos, porque de ti procedem, com certeza, todos os bens, ó Deus, e de ti, Deus meu, depende toda minha salvação.

 Tudo isto vim a saber mais tarde, quando me falaste por meio dos mesmos bens que me concedias interior e exteriormente. Porque então as únicas coisas que fazia era sugar o leite, aquietar-me com os afagos e chorar as dores de minha carne.

 Depois também comecei a rir, primeiro dormindo, depois acordado. Isto disseram de mim, e o creio, porque o mesmo acontece com outros meninos, pois eu não tenho a menor lembrança dessas coisas.

 Pouco a pouco comecei a me dar conta de onde estava, e a querer dar a conhecer meus desejos a quem os podia satisfazer, embora realmente não o pudessem, porque meus desejos estavam dentro, e eles fora; e por nenhum sentido podiam entrar em minha alma. assim, agitava os braços e dava gritos e sinais semelhantes a meus desejos, os poucos que podia e como podia, embora não fossem de fato sua expressão. Mas, se não era atendido, ou porque não me entendessem, ou porque o que desejava me fosse prejudicial, eu me indignava com os adultos, porque não me obedeciam, e sendo livres, por não quererem me servir; e deles me vingava chorando. Assim são as crianças que pude observar; e que eu também fosse assim, mais me ensinaram elas, sem o saber, do que os que me criaram, sabendo-o.

 Minha infância morreu há muito tempo, mas eu continuo vivo. Mas, dize-me, Senhor, tu que sempre vives, e em quem nada falece – porque existias antes do começo dos séculos, e antes de tudo o que há de anterior, e és Deus e Senhor de todas as coisas; e esse encontram em ti as causas de tudo o que é instável, e em ti permanecem os princípios imutáveis de tudo o que se transforma, e vivem as razões eternas de tudo o que é transitório – dize-me a mim, eu to suplico, ó meu Deus, diz-me, misericordioso, a mim que sou miserável, dize-me: porventura a minha infância sucedeu a outra idade minha, já morta? Será esta aquela que vivi no ventre de minha mãe? Porque também desta me revelaram algumas coisas, e eu mesmo já vi mulheres grávidas.

 E antes desse tempo, minha doçura e meu Deus, que era eu? Fui alguém, ou era parte de alguma coisa? Dize-mo, porque não tenho quem me responda, nem meu pai, nem minha mãe, nem a experiência dos outros, nem minha memória. Acaso te ris de mim, porque desejo saber estas coisas, e me mandas que te louve e te confesse pelo que conheci de ti?

 Eu te confesso, Senhor dos céus e da terra, louvando-te por meus princípios e por minha infância, de que não tenho memória, mas que, por tua graça, o homem pode conjectura de si pelos outros, crendo em muitas coisas, ainda que confiado na autoridade de humildes mulheres. Então eu já existia, já vivia de verdade; e, já no fim da infância procurava sinais com que pudesse exprimir aos outros as coisas que sentia. Com efeito, de onde poderia vir semelhante criatura, senão de ti, Senhor? Acaso alguém pode ser artífice de si mesmo? Porventura existirá algum outro manancial por onde corra até nos o ser e a vida, diferente da que nos dais, Senhor, tu em quem ser e vida não são coisas distintas, porque és o Sumo Ser e a Suprema Vida? Com efeito, és sumo, e não te mudas, nem caminha para ti o dia de hoje, apesar de caminhar por ti, apesar de estarem em ti com certeza todas estas coisas, que não teriam caminho por onde passar se não as contivesses. E porque teus anos não fenecem, teus anos são um perpétuo hoje. Oh! Quantos dias nossos e de nossos pais já passaram por este teu hoje, e dele receberam sua duração, e de alguma maneira existiram, e quantos passarão ainda, e receberão seu modo, e seu ser? Mas tu és sempre o mesmo, e todas as coisas de amanhã e do futuro, e todas as coisas de ontem e do passado, nesse hoje as fazes, nesse hoje as fizeste.

 Que importa que alguém não entenda essas coisas? Que este alguém se ria, e diga: que é isto? Que se ria assim, e que prefira encontrar-te sem indagação do que, indagando, não te encontrar.

## CAPÍTULO VII

### Os pecados da primeira infância

 Escuta-me, ó meu Deus! Ai dos pecados dos homens! E quem isto te diz é um homem, e tu te compadeces dele porque o criaste, e não foste autor do pecado que nele existe.

 Quem me poderá lembrar o pecado da infância, já que ninguém está diante de ti limpo de pecado, nem mesmo a criança cuja vida conta um só dia sobre a terra? Quem mo recordará? Acaso alguma criança pequena de hoje, em quem vejo a imagem do que não recordo de mim? E em que eu poderia pecar nesse tempo? Acaso por desejar o peito da nutriz, chorando? Se agora eu suspirasse com a mesma avidez, não pelo seio materno, mas pelo alimento próprio da minha idade, seria justamente escarnecido e censurado. Logo, era então digno de repreensão o meu proceder; mas como não podia entender a censura, nem o costume nem a razão permitiam que eu fosse repreendido. Prova está que, ao crescermos, extirpamos e afastamos de nós essa sofreguidão; e jamais vi homem sensato que, para limpar uma coisa viciosa, prive-a do que tem de bom.

 Acaso, mesmo para aquela idade, era bom pedir chorando o que não se me podia dar sem dano, indignar-me acremente com as pessoas livres que não se submetiam, assim como as pessoas respeitáveis, e até com meus próprios pais, e com muitos outros que, mais sensatos, não davam atenção aos sinais de meus caprichos, enquanto eu me esforçava por agredi-los com meus golpes, quanto podia, por não obedecerem às minhas ordens, que me teriam sido danosas? Daqui se segue que o que é inocente nas crianças é a debilidade dos membros infantis, e não a alma.

 Certa vez, vi e observei um menino invejoso. Ainda não falava, e já olhava pálido e com rosto amargurado para o irmãozinho colaço. Quem não terá testemunhado isso? Dizem que as mães e as amas tentam esconjurar este defeito com não sei que práticas. Mas se poderá considerar inocência o não suportar que se partilhe a fonte do leite, que mana copiosa e abundante, com quem está tão necessitado do mesmo socorro, e que sustenta a vida apenas com esse alimento? Mas costuma-se tolerar indulgentemente essas faltas, não porque sejam insignificantes, mas porque espera-se que desapareçam com os anos. Por isso, sendo tais coisas perdoáveis em um menino, quando se acham em um adulto, mal as podemos suportar.

 Assim, pois, meu Senhor e meu Deus, tu que me deste a vida e corpo, o qual dotaste, como vemos, de sentidos e proviste de membros, adornando-o de beleza e de instintos naturais, com os quais pudesse defender sua integridade e conservação, tu me mandas que te louve por esses dons e te confesse e cante teu nome altíssimo. Serias Deus onipotente e bom ainda que só tivesses criado apenas estas coisas, que nenhum outro pode fazer senão tu, ó Unidade, origem de todas as variedades, ó Beleza, que dás forma a todas as coisas, e com tua lei as ordenas!

 Tenho vergonha, Senhor, de ter de somar à vida terrena que vivo aquela idade que não recordo ter vivido, na qual acredito pelo testemunho de outros, por vê-lo assim em outras crianças, embora essa conjectura mereça toda a fé. As trevas em que está envolto meu esquecimento a seu respeito assemelham-se à vida que vivi no ventre de minha mãe.

 Assim, se fui concebido em iniqüidade, e se em pecado me alimentou minha mãe, onde, suplico-te, meu Deus, onde, Senhor, eu, teu servo, onde e quando fui inocente? Mas eis que silencio sobre esse tempo. Para que ocupar-se dele, se dele já não conservo nenhuma lembrança?

## CAPÍTULO VIII

### As primeiras palavras

 Acaso não foi caminhando da infância até aqui que cheguei à puerícia? Ou melhor, esta veio a mim e suplantou à infância sem que esta fosse embora, pois, para onde poderia ir? Contudo deixou de existir, porque eu já não era um bebezinho que não falava, mas um menino que aprendia a falar. Disso me recordo; mas como aprendi a falar, só mais tarde é que vim a perceber. Não mo ensinaram os mais velhos apresentando-me as palavras com certa ordem e método, como logo depois fizeram com as letras; mas foi por mim mesmo, com o entendimento que me deste, meu Deus, quando queria manifestar meus sentimentos com gemidos, gritinhos, e vários movimentos do corpo, a fim de que atendessem meus desejos; e também ao ver que não podia exteriorizar tudo o que queria, nem ser compreendido por todos aqueles a quem me dirigia. Assim, pois, quando chamavam alguma coisa pelo nome, eu a retinha na memória e, ao se pronunciar de novo a tal palavra, moviam o corpo na direção do objeto, eu entendia e notava que aquele objeto era o denominado com a palavra que pronunciavam, porque assim o chamavam quando o desejavam mostrar.

 Que esta fosse sua intenção, era-me revelado pelos movimentos do corpo, que são como uma linguagem universal, feita com a expressão rosto, a atitude dos membros e o tom da voz, que indicam os afetos da alma para pedir, reter, rejeitar ou evitar alguma coisa. Deste modo, das palavras usadas nas e colocadas em várias frases e ouvidas repetidas vezes, ia eu aos poucos notando o significado e, domada a dificuldade de minha boca, comecei a dar a entender minhas vontades por meio delas.

 Foi assim que comecei a comunicar meus desejos às pessoas entre as quais vivia, e entrei a fazer parte do tempestuoso mundo da sociedade, dependendo da autoridade de meus pais e obedecendo às pessoas mais velhas.

## CAPÍTULO IX

### Estudos e jogos

 Ó meu Deus, meu Deus! Que de misérias e enganos não experimentei então, quando se me propunha, em criança, como norma de bem viver, obedecer os mestres que me instigavam a brilhar neste mundo, e me ilustrar nas artes da língua, fiel instrumento para obter honras humanas e satisfazer a cobiça! Mudaram-me à escola, para que aprendesse as letras, nas quais eu, miserável, desconhecia o que havia de útil. Contudo, se era preguiçoso para aprendê-las, era fustigado, num sistema louvado pelos mais velhos; muitos deles, que levavam esse gênero de vida antes de nós, nos traçaram caminhos tão dolorosos pelos quais éramos obrigados a caminhar, multiplicando assim o trabalho e a dor aos filhos de Adão.

 Mas, por sorte, encontrei homens que te invocavam, Senhor, e com eles aprendi a te sentir, quanto possível, como a um Ser grande que podia escutar-nos e vir em nosso auxílio, embora sem a percepção dos sentidos. Ainda menino, pois, comecei a invocar-te como refúgio e amparo e, para te invocar, desatei os nós de minha língua; e, embora pequeno, te rogava já com grande fervor para que não me açoitassem na escola. E quando não me escutavas, o que servia para meu proveito os mestres, assim como meus próprios pais, que certamente não desejavam o meu mal, riam-se daquele castigo, que então era para mim grave suplício.

 Porventura, Senhor, haverá alguma alma tão grande, unida a ti com tão ardente afeto, pois isto também pode ser produzido pela estultice – repito, uma alma que alcance tal grandeza de ânimo que despreze os cavaletes e garfos de ferro, e os demais instrumentos de martírio – para fugir dos quais se te dirigem súplicas de todas as partes do mundo? Haverá uma alma que assim os despreze – rindo-se dos que têm deles tanto horror – como se riam nossos pais dos tormentos que éramos castigados por nossos mestres quando meninos? Porque, na verdade, não os temíamos menos, nem te rogávamos com menor fervor para que nos livrasses deles.

 Contudo, pecávamos por negligencia escrevendo ou lendo, estudando menos do que nos era exigido; e não era por falta de memória ou de inteligência, que para aquela idade, Senhor, me deste de modo suficiente, senão porque eu gostava de brincar, embora os que nos castigavam não fizessem outra coisa. Mas os jogos dos mais velhos chamavam-se negócios, enquanto que os dos meninos eram por eles castigados, sem que ninguém se compadecesse de uns e de outros, ou melhor, de ambos. Um juiz sensato poderia aprovar os castigos que eu, menino, recebia porque jogava bola, e porque com este jogo atrasava o aprendizado das letras, com as quais, adulto haveria de jogar menos inocentemente?

 Acaso fazia outra coisa naquele que me castigava? Se nalguma questiúncula era vencido por algum colega seu, não era mais atormentado pela cólera e pela inveja do que eu, quando uma partida de bola era vencido por meu companheiro?

## CAPÍTULO X

### Amor ao jogo 

 Contudo, Senhor meu, ordenador e criador da natureza, mas do pecado somente ordenador, eu pecava; pecava desobedecendo as ordens de meus pais e mestres, uma vez que podia no futuro fazer bom uso das letras que desejavam me ensinar, qualquer que fosse sua intenção.

 E não era desobediente para me ocupar de coisas melhores, mas por amor ao jogo; buscava nos combates orgulhosas vitórias; deleitava-me com histórias frívolas, com as quais incentivava sempre mais minha curiosidade. Igualmente curiosos, meus olhos se abriam sempre mais para os jogos e espetáculos dos adultos, jogos que dão tao grande dignidade a quem os oferece, que quase todos desejam as mesmas dignidades para seus filhos. Contudo, gostam de os castigar se com tais espetáculos fogem dos estudos, por meio dos quais desejam que eles venham um dia a oferecer espetáculos semelhantes. Senhor, olha misericordiosamente para essas coisas, e livra-nos delas a nós que já te invocamos; mas livra também aos que ainda não te invocam, a fim de que te invoquem, e sejam igualmente libertados.

## CAPÍTULO XI

### O batismo diferido

 Ainda menino, ouvi falar da vida eterna, que nos está prometida pela humildade de Jesus, nosso Senhor, que desceu até nossa soberba; e fui marcado com o sinal da cruz, sendo-me dado saborear de seu sal logo que saí do ventre de minha mãe, que sempre esperou muito em ti.

 Tu viste, Senhor, que numa ocasião, ainda menino, atacou-me repentinamente um dor de estômago que me abrasava, e que me aproximou da morte. Tu viste também, meu Deus, pois já me tinhas sob tua guarda, com que fervor de espírito e com que fé pedi à piedade de minha mãe, e da mãe de todos nós, tua Igreja, o batismo de teu Cristo, meu Deus e Senhor. Perturbou-se minha mãe carnal, pois que me criava com mais amor em seu casto coração em tua fé para a vida eterna e, solícita, já havia cuidado de que me iniciasse e purificasse com os sacramentos da salvação, confessando-te, ó meu Senhor Jesus, em remissão de meus pecados, quando, de repente, comecei a melhorar. Em vista disso, diferiu-se minha purificação, considerando que seria impossível, se eu vivesse, que não me tornasse a manchar; pois a culpa dos pecados cometidos depois do batismo é muito maior e mais perigosa.

 Nesta época eu já tinha fé verdadeira, juntamente com minha mãe e com todos da casa, à exceção de meu pai, que, porém, não pôde vencer em mim a ascendência da piedade materna, para que deixasse de acreditar em Cristo, tal como ele não acreditava; minha mãe, solícita, cuidava de que tu, meu Deus, fosses mais pai para mim do que ele, e a ajudavas a triunfar do marido, a quem servia melhor, porque nele te servia a ti e a tuas ordens.

 Mas, meu Deus, suplico-te que me mostres, se te apraz, por que motivo se diferiu então meu batismo; se foi ou não para meu bem que me soltaram as rédeas do pecado. Por que razão ainda hoje se diz de uns e de outros, como ouvimos em muitos lugares: "Deixe que faça o que quiser, porque ainda não está batizado" – embora não digamos da saúde do corpo: "Deixe que receba ainda mais feridas, porque ainda não está curado?"

 Quanto melhor teria sido para mim receber logo a saúde, e que meus cuidados e os dos meus fossem empregados em conservar intacta debaixo da tua proteção a saúde da minha alma, que me havias concedido! Melhor fora, certamente; porém, como minha mãe, sem dúvida, já previa quantas e quão grandes ondas de tentações me ameaçariam depois da meninice, preferiu expor-me a elas como terra grosseira que depois receberia forma, do que expor-me já como imagem tua.

## CAPÍTULO XII 

### Ódio ao estudo 

 Nesta minha infância, na qual eu tinha menos que temer por mim do que em minha adolescência, eu não gostava dos estudos, e odiava que a eles me obrigassem. Contudo, era coagido, e me faziam grande bem. Quem não procedia bem era eu, que não estudava a não ser constrangido, pois ninguém faz bem o que faz contra a vontade, mesmo que seja bom o que faz.

 Tampouco os que obrigavam a estudar agiam corretamente; antes, todo o bem que eu recebia vinha de ti, meu Deus, porque eles não tinham outro fim ao me obrigarem a estudar senão saciar o apetite de abundante miséria e de gloria ignominiosa. Mas tu, Senhor, que tens contados os cabelos de nossa cabeça, usavas do erro de todos os que me coagiam a estudar para minha utilidade; e usavas da minha falta de vontade de estudar para meu castigo, de que certamente eu já era digno, sendo ainda tão pequeno, e tao grande pecador.

 Assim, convertias em bem o mal que eles me faziam, e dos meus pecados, me davas justa retribuição, porque é teu desígnio, e assim acontece, que toda alma desordenada seja castigo de si mesma.

## CAPÍTULO XIII

### Gosto pelo latim

 Porque odiava eu as letras gregas, que me ensinavam quando eu era criança? Não o sei, e nem agora o posso explicar. Em compensação, as letras latinas me apaixonavam, não as ensinadas pelos professores primários, mas a que é explicada pelos chamados gramáticos, porque aquelas primeiras, com as quais se aprende a ler, a escrever e a contar, não me foram menos pesadas e insuportáveis que as gregas. Mas donde podia proceder essa aversão, senão do pecado e da vaidade da vida, porque eu era carne e vento que caminha e não volta?

 Aquelas primeiras letras, pelas quais podia, como ainda faço, chegar e ler tudo o que há escrito e a escrever tudo o que quero, eram melhores e mais úteis que aquelas outras nas quais me obrigavam a decorar os erros de um tal Enéias, esquecido dos meus, e a chorar a morte de Dido, que se suicidou por amor, enquanto isso, eu, miserabilíssimo, suportava a minha própria morte com olhos enxutos, morrendo para ti, ó meu Deus, minha vida!

 Na verdade, que pode haver de mais miserável do que um infeliz que não se compadece de si mesmo e que, chorando a morte de Dido por amor de Enéias, não chora sua própria morte por falta de amor a ti, ó Deus, luz de meu coração, pão interior de minha alma, virtude fecundante de meu pensamento? Não te amava; prevaricava longe de ti, e ouvia de todas as partes: "Muito bem! Muito bem!" – porque a amizade deste mundo é adultério contra ti; e se aclamam a alguém dizendo: "Muito bem! Muito bem!" – é para que este não se envergonhe de ser assim. Eu não chorava estas faltas, chorava a morte de Dido "que se suicidou com a espada", eu procurava as últimas de tuas criaturas, abandonando-te a ti, como terra que eu era, atraída pela terra. Se então me proibissem a leitura de tais coisas, me afligiriam por não ler aquilo que me comovia até a dor. Não obstante, semelhante loucura é considerada como coisa mais nobre e proveitosa que as letras pelas quais aprendemos a ler e a escrever.

 Mas agora, meu Deus, grite em minha alma tua verdade, e diga: Não é assim, não é assim, antes, aquela primeira instrução é absolutamente superior; pois eu preferiria esquecer todas as aventuras de Enéias, e outras histórias semelhantes, do que o saber ler e escrever. Sei que nas escolas dos gramáticos pendem cortinas às portas; porém, servem menos para velar o segredo que para encobrir o erro.

 Não gritem contra mim aqueles mestres a quem já não temo, enquanto confesso a ti os desejos de minha alma, e aborreço dos meus maus caminhos, a fim de amar os teus. Não gritem contra mim os comerciantes da gramática, pois, se eu os interrogar sobre se é verdade que Enéias veio uma vez a Cartago, como afirma o poeta, os néscios responderão que não sabem, e os sábios negarão o fato. Porém, se lhes perguntar como se escreve o nome de Enéias, todos os que estudaram me responderão a mesma coisa, de acordo com a convenção com que os homens fixaram o valor das letras do alfabeto.

 Do mesmo modo, se lhes perguntar o que seria mais prejudicial para a vida humana: esquecer o ler e o escrever, ou todas as ficções dos poetas, quem não vê o que logo responderia aquele que não estivesse de tudo esquecido de ti? Pequei, pois, em minha infância, ao preferir vãos aos proveitosos, ou para dizer melhor, ao amar àqueles e ao odiar a estes; era para mim uma cantiga odiosa aquele "um e um, dois; dois e dois, quatro; enquanto considerava espetáculo encantador a história do cavalo de madeira cheio de guerreiros e o incêndio de Tróia, "e até a sombra de Creuza".

## CAPÍTULO XIV

### Aversão ao grego

 Por que então aborrecia eu a literatura grega na qual se cantam tais coisas? Porque também Homero é mui habilidoso em tecer essas historietas, dulcíssimo na sua frivolidade, embora para mim, menino, fosse bem amargo. Creio que o mesmo ocorra com Virgilio para os meninos gregos obrigados a estudá-lo, como a mim com relação a Homero. Era a dificuldade de ter de aprender totalmente uma língua estranha que, como fel, aspergia de amargura todas as doçuras das fábulas gregas.

 Eu ainda não conhecia nenhuma palavra daquela língua, e já me obrigavam com veemência, com crueldades e terríveis castigos, a aprendê-la. Na verdade, eu, ainda criança, também não conhecia nenhuma palavra de latim; contudo, com um pouco de atenção, o aprendi entre o carinho das amas, os gracejos dos que se riam e as alegrias dos que brincavam, sem medo algum nem tormento. Eu o aprendi, sem a pressão dos castigos, impelido unicamente por meu coração desejoso de dar à luz seus sentimentos, e o único caminho para isso era aprender algumas palavras, não dos que as ensinavam, mas do que falavam, em cujos ouvidos ia eu depositando quanto sentia.

 Por aqui se evidencia claramente que, para instruir, tem mais eficácia e curiosidade livre do que a necessidade inspirada pelo medo. Contudo, os excessos da curiosidade encontram nessa violência um freio segundo tuas leis, ó Deus; que desde as palmatórias dos mestres até os tormentos dos mártires sabem dosar suas salutares amarguras, que nos reconduzem a ti do seio do pernicioso deleite que de ti nos apartara.

## CAPÍTULO XV

### Oração

 Ouvi, Senhor, minha oração, para que não desfaleça minha alma sob a tua lei, nem me canse em confessar tuas misericórdias, com as quais me arrancaste de meus perversos caminhos; que tua doçura sobrepuje todas as doçuras que segui, e assim te ame fortissimamente, e abrace tua mão com toda minha alma, e me livres de toda a tentação até o fim dos meus dias. Pois é, Senhor, meu rei e meu Deus, e a ti consagro quanto falo, escrevo, leio e conto, pois quando aprendia aquelas futilidades, tu eras o que me davas a verdadeira disciplina, e já me perdoaste os pecados de deleite cometidos naquelas vaidades. Muitas palavras úteis aprendi nelas, é verdade; porém, estas também se podem aprender em estudos sérios, e este é o caminho seguro pelo qual deveriam encaminhar as crianças.

## CAPÍTULO XVI

### O mal da mitologia

 Ai de ti, torrente dos hábitos humanos! Quem há que te resista? Quando te secarás? Até quando irás arrastar os filhos de Eva a esse mar imenso e tenebroso, que apenas logram passar os que embarcam sobre o lenho da cruz? Acaso não foi em ti que li a fábula de Júpiter que troveja e adultera? É verdade que não podia fazer tais coisas ao mesmo tempo, mas assim se representou para autorizar a imitação de um verdadeiro adultério com o encantamento de um falso trovão. Contudo, qual é o professor de pênula capaz de ouvir com paciência a um homem nascido do mesmo pó que clama e diz: "Homero imaginava essas ficções e atribuía aos deuses os vícios humanos; porém, eu preferiria que atribuísse a nós as qualidades divinas". Com mais verdade se diria que Homero imaginou tudo isso, atribuindo qualidades divinas a homens corrompidos, para que os vícios não fossem considerados como tais, e para que todo aquele que os cometesse parecesse que imitava a deuses celestes, e não a homens corrompidos.

 E contudo, ó torrente infernal, em ti se precipitam os filhos dos homens, com o dinheiro gasto para aprender tais coisas. E consideram acontecimento importante representá-lo, publicamente no Foro, à vista das leis que concedem aos mestres um prêmio, além de seus salários particulares.

 E ferindo os rochedos de tuas margens, gritas dizendo: "Aqui se aprendem as palavras; aqui se adquire a eloqüência, tao necessária para persuadir e explicar os pensamentos; não poderíamos pois aprender as palavras: chuva de ouro, regaço, templo celeste, logro e outras mais, escritas em determinada passagem, se Terêncio não nos apresentasse um jovem perdido que se propõe a imitar a luxúria de Júpiter? Contemplava ele uma pintura mural "na qual se representava o mesmo Júpiter no momento em que, segundo dizem, descia como chuva de ouro sobre o regaço de Dânae, para lograr assim à pobre mulher".

E vede como se excitava à luxúria a vista de tão celestial mestre:

- Mas que deus fez isto? – diz.

- Nada menos que aquele que faz retumbar a abóbada do céu com enorme trovão!

- E eu, homenzinho, não haveria de fazer o mesmo?

- Fi-lo, sim, e com muito gosto.

 De modo algum se aprendem com semelhante torpeza aquelas palavras; antes, essas palavras levam mais atrevidamente a cometer a mesma devassidão. Não incrimino as palavras, que são como vasos seletos e preciosos, mas condeno o vinho do erro que mestres ébrios nos davam a beber nelas e, se não o bebêssemos, éramos açoitados, sem que pudéssemos apelar para juiz mais sóbrio.

 E, não obstante, meu Deus, cuja presença me protege desta lembrança, confesso que aprendi estas coisas com gosto e que, miserável, nelas me comprazi, sendo por isso chamado menino de grandes esperanças.

## CAPÍTULO XVII

### Êxitos escolares

 Permite-me, Senhor, que diga também algo de meu talento, dádiva tua, e dos desatinos em que o empregava. Propunha-se-me como desafio – coisa mui preocupante para minha alma, tanto pelo louvor ou descrédito, como por medo dos açoites – que repetisse as palavras de Juno, irada e ressentida por não podem "afastar da Itália ao rei dos troianos", embora jamais tenha sabido que tivessem sido pronunciadas por Juno. Mas obrigavam-nos a errar seguindo os passos das ficções poéticas, e a repetir em prosa o que o poeta havia dito em verso. Era mais elogiado aquele que, conforme a dignidade da pessoa representada, soubesse pintar com mais vivacidade e semelhança, e revestir com palavras mais apropriadas seus afetos de ira ou de dor.

 Mas qual o proveito disso – ó vida verdadeira, meu Deus – de que me servia ser aplaudido por minha declamação mais que todos os meus coetâneos e condiscípulos? Não era tudo aquilo fumo e vento? Acaso não havia outra coisa em que exercitar meu talento e minha língua? Teus louvores, Senhor, teus louvores, consignados nas Escrituras, poderiam soerguer a frágil planta de meu coração, e eu não teria sido arrebatado pela vaidade de vãs quimeras, presa imunda das aves. Com efeito, há diversas maneiras de oferecer sacrifício aos anjos rebeldes.

## CAPÍTULO XVIII

### Leis gramaticais, lei de Deus

 Mas, por que admirar-se que eu me deixasse arrastar pelas vaidades e me afastar de ti, meu Deus, se me propunham como exemplos para imitar a uns homens que se, ao contar alguma boa ação, deslizassem nalgum barbarismo ou solecismo cobriam-me de críticas e, pelo contrário, que eram elogiados por narrar suas torpezas com palavras castiças e apropriadas, de modo eloqüente e elegante, e que os inchavam de vaidade?

 Tu vês, Senhor, estas coisas, e te calas compassivo, paciente, cheio de misericórdia e verdade. Mas te calarás para sempre? Arranca, pois, agora deste espantoso abismo a alma que te busca sedenta de teus deleites, e que te diz de coração: Busquei, Senhor, teu rosto; teu rosto, Senhor, buscarei ainda. Longe está de teu rosto quem anda ocupado com afetos tenebrosos, porque não é com os pés carnais, nem cobrindo distâncias que nos aproximamos ou nos afastamos de ti. Porventura aquele teu filho menor procurou cavalos, ou carros, ou naves, ou voou com asas invisíveis, ou viajou a pé para alcançar aquela região longínqua onde dissipou o que lhes havia dado, ó Pai, meigo ao lhe entregar a substância, e mais carinhoso ainda ao recebê-lo andrajoso? Assim, pois, viver nas paixões da luxúria, é o mesmo que viver em paixões tenebrosas, é viver longe de teu rosto.

 Olha, meu Senhor e meu Deus, é vê paciente, como costumas ver, de que modo diligente os filhos dos homens observam as regras de ortografia recebidas dos primeiros mestres, e desprezam as leis eternas de salvação perpétua recebidas de ti; de tal modo que, se alguns dos que sabem ou ensinam as regras antigas dos sons pronunciasse a palavra homo, sem aspirar a primeira letra, desagradaria mais aos homens do que se, contra teus preceitos, odiasse a outro homem, sendo este homem.

 Como se o homem pudesse ter inimigo mais pernicioso que o ódio com que se irrita contra si mesmo, ou como se pudesse causar a outrem maior dano, perseguindo-o, do que causa a seu próprio coração odiando! Com certeza, não nos é mais íntima a ciência das letras do que a consciência, que manda não fazer a outrem o que não queremos que não nos façam.

 Oh! Como és misericordioso, tu, que habitando silencioso nos céus, Deus grande e único, espalhas com lei infatigável cegueiras vingadoras sobre as paixões ilícitas! Quando o homem, aspirando à fama de eloqüente, ataca a seu inimigo com ódio feroz diante do juiz, rodeado de grande multidão de homens, toma todo o cuidado para que, por um lapsus linguae, não se lhe escape um inter ominibus, sem aspirar o h, sem cuidar que com o furor de seu ódio se tire um homem de entre os homens.

## CAPÍTULO XIX

### Mau perdedor

 À beira de tal lodaçal jazia eu, pobre criança, sendo esta a arena em que me exercitava, temendo mais cometer um barbarismo de linguagem do que cuidando de não invejar, se o cometia, aqueles que o tinham evitado.

 Digo e confesso diante de ti, meu Deus, essas misérias, que me angariavam o louvor daqueles cuja simpatia equivalia para mim a uma vida honesta, pois não via o abismo pois não via o abismo de torpeza em que tudo isso me lançara, longe dos teus olhos. A teus olhos quem era mais repelente do que eu? E eu até desagradava tais homens, enganando com infinidade de mentiras a meus criados, mestres e pais por amor dos jogos, por gosto de ver espetáculos frívolos e o desejo inquieto de os imitar.

 Também cometia furtos na despensa e na mesa de meus pais, ora impelido pela gula, ora para ter de dar aos meninos para brincar com eles, folguedos que os deleitavam tanto quanto a mim, e que eles me faziam pagar. No jogo, frequentemente, conseguia vitórias fraudulentas, vencido pelo desejo de me sobressair. Contudo, nada havia que eu quisesse mais evitar e que eu repreendesse mais atrozmente se o descobrisse em outros, que o mesmo eu fazia aos demais. Se acaso eu era o prejudicado, e o acusado ficava furioso, eu não cedia. Será esta a inocência infantil? Não, Senhor, não o é, eu to confesso, meu Deus. Porque essas mesmas coisas que se fazem com os criados e mestres por causa de nozes, bolas e passarinhos, se avultam na maioridade com os magistrados e reis por causa de dinheiro, palácios e servos, do mesmo modo que à palmatória sucedem-se maiores castigos.

 Assim, quando tu, nosso rei, disseste: Delas é o reino do céus – quiseste sem dúvida louvar na pequenez de sua estatura um símbolo de humildade.

# LIVRO SEGUNDO

### Ação de graças

 Contudo, Senhor, graças te sejam dadas, excelso e ótimo criador e ordenador do universo, nosso Deus, mesmo que te limitasses a me fazer apenas menino. Porque então, eu já existia, vivia, sentia, cuidava da minha integridade, eco de tua profunda unidade, fonte de minha existência.

 Guardava também, com o secreto instinto, a integridade dos meus outros sentidos, e deleitava-me com a verdade nos pequenos pensamentos que formava sobre coisas pequenas. Não queria ser enganado, tinha boa memória, e me ia instruindo com a conversação. Alegrava-me com a amizade, fugia à dor, ao desprezo, à ignorância. E não seria isto, em tal criatura, digno de admiração e de louvor? Pois todas essas coisas são dons do meu Deus, que eu não dei a mim mesmo. E todos são bons, e tudo isso constitui o meu eu.

 O que me criou, portanto, é bom, e ele próprio é o meu bem; a ele louvo por todos estes bens que integravam meu ser de criança. Eu pecava em buscar em mim próprio e nas demais criaturas, e não nele, os deleites, grandezas e verdades; por isso caia logo em dores, confusões e erros.

 Graças a ti, minha doçura, minha esperança e meu Deus, graças a ti por teus dons; que eles fiquem em ti conservados. Assim me guardarás também a mim, e aumentarão e aperfeiçoarão os dons que me deste, e eu estarei contigo, porque também me deste a existência.

## CAPÍTULO I

### A adolescência

 Quero recordar minhas torpezas passadas e as degradações carnais de minha alma, não porque as ame, mas por te amar, ó meu Deus. É por amor de teu amor que o faço, percorrendo com a memória amargurada, aqueles meus perversos caminhos, para que tu me sejas doce, doçura sem engano, ditosa e eterna doçura. Resgata-me da dispersão em que me dissipei quando, afastando-me de tua unidade, me desvaneci em muitas coisas.

 Tempo houve de minha adolescência em que ardi em desejos de me fartar dos prazeres mais baixos, e ousei a bestialidade de vários e sombrios amores, e se murchou minha beleza, e me transformei em podridão diante de teus olhos, para agradar a mim mesmo e desejar agradar aos olhos dos homens.

## CAPÍTULO II

### As primeiras paixões

 E que me deleitava, senão amar e ser amada? Mas eu não era moderado, indo de alma para alma de acordo com os sinais luminosos da amizade, pois, da lodosa concupiscência de minha carne e do fervilhar da puberdade levantava-se como que uma névoa que obscurecia e ofuscava meu coração, a ponto de não discernir a serena amizade da tenebrosa libido. Uma e outra, confusamente, me abrasavam; arrastavam minha fraca idade pelo declive íngreme de meus apetites, afogando-me em um mar de torpezas. Tua ira se acumulava sobre mim, e eu não o sabia. Ensurdeci com o ruído da cadeia de minha mortalidade, e cada vez mais me afastava de ti, e tu o consentias; e me agitava, e me dissipava, e me derramava e fervia em minha devassidão, e tu te calavas – ó alegria que tão tarde encontrei! – tu te calavas então, e eu ia cada vez mais para longe de ti, sempre atrás de estéreis sementes de dores, com vil soberba e inquieto cansaço.

 Oh! Se alguém refreasse aquela minha miséria, para que fizesse bom uso da fugaz beleza das criaturas inferiores; limitasse suas delicias, a fim de que as vagas daquela minha idade rompessem na praia do matrimonio, já que de outro modo não podia haver paz – contendo-se nos limites da geração, como prescreve tua lei, Senhor, tu que crias o gérmen transmissor de nossa vida mortal, e que com mão bondosa podes suavizar a agudeza dos espinhos, que mantiveste fora do paraíso! Porque tua onipotência está perto de nós, mesmo quando vagueamos longe de ti.

 Pelo menos eu deveria atender com mais diligencia à voz de tuas nuvens: Também eles sofrerão as tribulações da carne; mas eu quisera poupar-vos; e bom é ao homem não tocar em mulher; o que está sem mulher pensa nas coisas de Deus, de como o há de agradar; mas o que está ligado pelo matrimonio pensa nas coisas do mundo, e em como há de agradar à mulher. Estas são as palavras que eu deveria ter ouvido mais atentamente; e, eunuco pelo amor ao reino de Deus, teria suspirado mais feliz por teus abraços.

 Mas eu, miserável, tornei-me em torrente, seguindo o ímpeto de minha paixão, te abandonei e transgredi a todos os teus preceitos, sem porém, escapar de teus castigos. E quem o poderia dentre os mortais? Sempre estavas ao meu lado, irritando-se misericordiosamente comigo, e aspergindo com amaríssimos desgostos todos os meus gozos ilícitos, para que eu buscasse a alegria sem te ofender e, quando a achasse, de modo algum fosse fora de ti, Senhor. Fora de ti, que impões a dor em mandamento, e feres para sarar, e nos tiras a vida para que não morramos sem ti.

 Mas onde estava eu? Oh! Quão longe, exilado das delicias de tua casa naqueles meus dezesseis anos de idade carnal, quando esta empunhou seu cetro sobre mim, e eu me rendi totalmente a ela, à fúria da concupiscência que a degradação humana legítima, porém, ilícita, de acordo com as tuas leis.

 Nem mesmo os meus cogitaram em me sustentar na queda, pelo casamento, ao ver-me cair; cuidavam apenas que eu aprendesse a compor discursos magníficos e a persuadir com a palavra.

### Cegueira do pai, cuidados da mãe

 Nesse mesmo ano tive de interromper meus estudos, quando voltei de Madaura, cidade vizinha, onde fora estudar literatura e oratória, enquanto se faziam os preparativos necessários para minha viagem mais longa a Cartago, levado mais pela ambição de meu pai que pelos seus parcos bens, pois, era mui modesto cidadão de Tagaste.

 Mas, a quem conto eu estes fatos? Certamente, não a ti, meu Deus, mas em tua presença conto estas coisas aos da minha estirpe, ao gênero humano, ainda que estas páginas chegassem às mãos de poucos. E para que então? Para que eu, e quem me ler, pensemos na profundeza do abismo de onde temos de clamar por ti? E que há de mais próximo a teus ouvidos que o coração contrito e a vida que procede da fé?

 Quem então não cumulava a meu pai de louvores, pois excedendo até seus deveres familiares, gastava com o filho o necessário para tão longa viagem por causa de seus estudos? Porque muitos cidadãos, muito mais ricos do que ele, não mostravam para com os filhos igual cuidado.

 Contudo, este mesmo pai não se importava de saber se eu crescia para ti, ou que fosse casto, contanto que fosse deserto; mas antes eu era deserto, por carecer de teu cultivo, ó Deus, único, verdadeiro e bom senhor de teu campo, o meu coração.

 Porém, no meu décimo-sexto ano foi necessária uma interrupção em meus estudos por falta de recursos familiares e, livre da escola, passei a viver com meus pais. Avassalaram então minha cabeça os espinhos de minhas paixões, sem que houvesse mãos que os arrancassem. Pelo contrário, meu pai, certo dia, percebendo ao banho sinais de minha puberdade e vendo-me revestido de inquieta adolescência, como se já se alegrasse pensando nos netos, foi contá-lo alegre à minha mãe. Alegria esta gerada pela embriaguez com que este mundo esquece de ti, seu criador, e em teu lugar ama tua criatura; embriaguez que nasce do vinho sutil de sua perversa e mal inclinada vontade para as coisas baixas.

 Mas, nessa época, já tinhas começado a levantar, no coração de minha mãe, teu templo e os alicerces de tua santa morada; meu pai não era mais que catecúmeno, recente ainda. Por isso minha mãe perturbou-se com santo temor. Embora eu ainda não fosse batizado, temia que eu seguisse as sendas tortuosas por onde andam os que te voltam as costas, e não o rosto.

 Ai de mim! Como me atrevo a dizer que te calavas quando me afastava de ti? Seria verdade que então te calavas comigo? E de quem eram, senão tuas, aquelas palavras que pela boca de minha mãe, tua serva fiel, sussurraste em meus ouvidos, embora nenhuma delas penetrasse no meu coração, para que a cumprisse?

 Lembro bem que um dia me admoestou em segredo, com grande solicitude, que me abstivesse da luxúria e, sobretudo, que não cometesse adultério com a mulher de ninguém. Porém, esses conselhos pareciam-me próprios de mulheres, e eu me envergonharia de segui-los. Mas, na realidade, eram teus, embora eu não o soubesse, e por isso julgava que te calavas, e que era ela quem me falava; e eu te desprezava em tua serva, eu, seu filho, filho de tua serva e servo teu, a ti que não cessavas de me falar pela sua boca.

 Mas eu não o sabia, e me precipitava com tanta cegueira, que me envergonhava entre os companheiros de minha idade, de ser menos torpe do que eles. Os ouvia jactar-se de suas maldades, e gloriar-se tanto mais quanto mais infames eram; assim eu gostava de fazer o mal, não só pelo prazer, mas ainda por vaidade. O que há de mais digno de vitupério do que o vicio? E, contudo, para não ser escarnecido, tornava-me mais viciado e, quando não houvesse cometido pecado que me igualasse aos mais perdidos, fingia ter feito o que não cometera, para que não parecesse mais abjeto quanto mais inocente, e tanto mais vil quanto mais casto.

 Eis com que companheiros andava eu pelas graças de Babilônia, revolvendo-me na lama, como em cinamomo e ungüentos preciosos. E, para que todo esse lodo me pegasse bem firme, subjugava-me o inimigo invisível, e me seduzia, por ser eu presa fácil da sedução.

 Nem então minha mãe carnal, que já fugira do meio da Babilônia, mas que em outras coisas caminhava mais devagar, cuidou – como fizera ao aconselhar-me a castidade – de conter com os laços do matrimonio aquilo de que seu marido lhe falara a meu respeito. Já percebera ela que me era pestilencial, e que mais adiante me seria perigoso – já que essa paixão não podia ser cortada pela raiz. Não pensou nisso, digo, por temer que o vínculo matrimonial frustrasse a esperança que sobre mim acalentava; não a esperança da vida futura, que ela já tinha posto em ti, mas a esperança das letras que ambos, meu pai e minha mãe, desejavam ardentemente; meu pai, porque não pensava quase nada de ti, mas apenas ambições vãs a meu respeito; minha mãe, porque considerava que tais tradicionais estudos das letras não só não me seriam de estorvo, sendo de não pouca ajuda para chegar a ti. Assim julgo eu, agora, enquanto me é possível pela lembrança, o caráter de meus pais.

 Por isso, soltavam-me as rédeas para o jogo mais do que o permite uma moderada severidade, deixando-me cair na dissolução de várias paixões; e de todas surgia uma obscuridade que me toldava, ó meu Deus, a luz da tua verdade; e, por assim dizer, de meu corpo, brotava minha iniqüidade.

## CAPÍTULO IV

### O furto das pêras

 É certo, Senhor, que tua lei pune o furto, lei tão arraigada no coração dos homens que nem a própria iniqüidade pode apagar. Que ladrão há que suporte com paciência que o roubem? Nem o rico tolera isto a quem o faz forçado pela indigência. Também eu quis roubar, e roubei não forçado pela necessidade, mas por penúria, fastio de justiça e abundância de maldade, pois roubei o que tinha em abundância, e muito melhor. Nem me atraía ao furto o gozo de seu resultado, mas atraía-me o furto em si, o pecado.

 Nas imediações de nossa vinha, havia uma pereira carregada de frutos, que nem pelo aspecto, nem pelo sabor tinham algo de tentador. Alta noite – pois até então ficaríamos jogando nas eiras, de acordo com nosso mau costume – dirigimo-nos ao local, eu e alguns jovens malvados, com o fim de sacudi-la e colher-lhe os frutos. E levamos grande quantidade deles, não para saboreá-los, mas para jogá-los aos porcos, embora comêssemos alguns; nosso deleite era fazer o que nos agradava justamente pelo fato de ser coisa proibida.

 Aí está meu coração, Senhor, meu coração que olhaste com misericórdia quando se encontrava na profundeza do abismo. Que este meu coração te diga agora que era o que ali buscava, para fazer o mal gratuitamente, não tendo minha maldade outra razão que a própria maldade. Era hedionda, e eu a amei; amei minha morte, amei meu pecado; não o objeto que me fazia cair, mas minha própria queda. Ó torpe minha alma, que saltando para fora do santo apoio, te lançavas na morte, não buscando na ignomínia senão a própria ignomínia?

## CAPÍTULO V

### A causa do pecado

 Todos os corpos formosos, o ouro, a prata, e todos os demais têm, com efeito, seu aspecto atraente. No contato carnal intervém grandemente a congruência das partes, e cada um dos sentidos percebe nos corpos certa modalidade própria. Também a honra temporal e o poder de mandar e dominar têm seu atrativo, de onde nasce o desejo de vingança.

 Todavia, para obtermos estas coisas, não é necessário abandonarmos a ti, nem nos desviar de tua lei. Também a vida que aqui vivemos tem seus encantos, por certa beleza que lhe é própria, e pela harmonia que tem com as demais belezas terrenas. Cara é, finalmente, a amizade dos homens pela união que une muitas almas com o doce laço do amor.

 Por todos estes motivos, e outros semelhantes, pecamos quando, por propensão imoderada para os bens ínfimos, são abandonados os melhores e mais altos, como tu, Senhor, nosso Deus, tua verdade e tua lei.

 É verdade que também esses bens ínfimos têm seus deleites, porém, não como os de Deus, criador de todas as coisas, porque nele se deleita o justo, e nele acham suas delicias os retos de coração.

 Portanto, quando indagamos a causa de um crime, não descansamos até averiguar qual o apetite dos bens chamados ínfimos, ou que temor de perdê-los foi capaz de provocá-lo. Sem dúvida são belos e atraentes, embora, comparados com os bens superiores e beatíficos, sejam abjetos e desprezíveis. Alguém comete um homicídio. Por que? Porque desejou a esposa do morto, ou suas terras, ou porque quis roubar alguma coisa, ou então, ferido, ardeu em desejos de vingança. Por acaso cometeria o crime sem motivo, apenas pelo gosto de matar? Quem pode acreditar em semelhante coisa?

 Mesmo de Catilina, homem sem entranhas e muito cruel, de quem se disse que era mau e cruel sem razão, acrescenta o historiador um motivo: "Para que a ociosidade não embotasse suas mãos e sentimento".

 Todavia, se indagares porque agia assim, dir-te-ei que mediante o exercício de crimes, depois de tomada a cidade, conseguisse honras, poderes e riquezas, libertando-se do medo das leis e das dificuldades da vida, causados pela pobreza de seu patrimônio e a consciência de seus crimes. Logo, nem o próprio Catilina amava seus crimes, mas aquilo por cujo motivo os cometia.

## CAPÍTULO VI

### O crime gratuito

 Que amei, então, em ti, ó meu furto, crime noturno dos meus dezesseis anos? Não eras belo, já que eras furto. Mas, por acaso és algo para que eu fale contigo? Belas eram as pêras que roubamos, por serem criaturas tuas, ó formosíssimo Criador de todas as coisas, bom Deus, Deus sumo, meu bem e meu verdadeiro bem; belas eram aquelas pêras! Porém, não eram elas que apeteciam minha alma depravada. Eu as tinha em abundância, e melhores. Colhi-as da árvore só para roubar; tanto que, tão logo colhidas, joguei-as fora, saboreando nelas apenas a iniqüidade, com que me regozijava. Se alguma delas entrou em minha boca, somente o crime é que lhe deu sabor.

 E agora pergunto, meu Deus: que é que me deleitava no furto? Pois não encontro nenhuma beleza nele. Já não falo da beleza que reside na justiça e na prudência, nem sequer da que resplandece na inteligência do homem, na memória, nos sentidos ou na vida vegetativa; nem da que brilha nos magníficos astros em suas órbitas, ou na terra e no mar, cheios de criaturas, que nascem para sucederem umas às outras; nem sequer da defeituosa e sombria formosura dos vícios enganadores.

 O orgulho imita a altura; mas só tu, Deus excelso, estás acima de todas as coisas. E a ambição, que busca, senão honras e glorias, quanto tu és o único sobre todas as coisas e ser honrado e glorificado eternamente? A crueldade dos tiranos quer ser temida; porém, quem há de ser temido senão Deus, a cujo poder ninguém, porém, quem há de ser temido senão Deus, a cujo poder ninguém, em tempo algum ou lugar, nem por nenhum meio pode subtrair-se e fugir? As carícias da volúpia buscam ser correspondidas; porém, não há nada mais carinhoso que tua caridade, nem que se ame de modo mais salutar que tua verdade, sobre todas as coisas formosa e resplandecente. A curiosidade sugere amor à ciência, enquanto só tu conheces plenamente todas as coisas. Até a própria ignorância e estultícia cobrem-se com o nome de simplicidade e inocência; das quais não acham nada mais simples do que tu. E que pode haver mais inocente do que tu, pois, até mesmo o castigo dos maus lhes vem de seus pecados? A indolência gosta do descanso; porém, que repouso seguro pode haver fora do Senhor? O luxo gosta de ser chamado de fartura; mas só tu és a plenitude e a abundância inesgotável de eterna suavidade. A prodigalidade veste-se com a capa da liberalidade; porém, só tu, és verdadeiro e liberalíssimo doador de todos os bens. A avareza quer possuir muitas coisas; porém, só tu as possui todas. A inveja litiga acerca de excelências; porém, que há mais excelente do que tu? A ira busca a vingança; e que vingança mais justa do que a tua? O temor aborrece as coisas repentinas e insólitas, contrárias ao que se ama ou se deseja manter seguro; mas haverá para ti algo de novo e repentino? Quem poderá separar de ti o que amas? E onde, senão em ti, se encontra inabalável segurança? A tristeza definha com a perda das coisas com que a cobiça se deleita, e não quer que se lhe tire nada, como nada pode ser tirado de ti.

 Assim peca a alma, quando se aparta e busca fora de ti o que não pode achar puro e ilibado senão quando se volta novamente para ti. Perversamente te imitam todos os que se afastam de ti e se levantam contra ti. Porém, mesmo imitando-te, mostram que és o criador de toda criatura e que, portanto, não existe lugar onde alguém se possa afastar de ti de modo absoluto.

 Que amei, então, naquele furto, e no que imitei, viciosa e imperfeitamente, a meu Senhor? Acaso foi o gosto de agir pela fraude contra a tua lei, já que não o podia fazer por força, simulando, cativo, uma falsa liberdade ao fazer impunemente o que estava proibido, imagem tenebrosa de tua onipotência?

 Eis aqui o servo que, fugindo do seu senhor, seguiu uma sombra. Ó podridão! Ó monstro da vida e abismo da morte! Como pôde agradar-me o ilícito, e não por outro motivo, senão porque era ilícito?

## CAPÍTULO VII

### Ação de graças

 Como agradecerei ao Senhor por poder recordar todas estas coisas sem que minha alma sinta medo algum? Amar-te-ei, Senhor, e dar-te-ei graças, e confessarei teu nome, pois me perdoaste tantas e tão nefandas ações. Devo à tua graça e misericórdia teres-me dissolvido os pecados como gelo, como também todo o mal que não pratiquei. De fato, de que pecados não seria capaz, eu que amei gratuitamente o erro?

 Confesso que todos já me foram perdoados; o mal cometido voluntariamente, e o que deixei de fazer pela tua graça. Quem dentre os homens, conhecendo tua fraqueza, poderá atribuir às próprias forças sua castidade e inocência para amar-te menos, como se tivesse menor necessidade de tua misericórdia, com a qual perdoas os pecados aos que se convertem a ti?

 Aquele, pois, que, chamado por ti, seguiu tua voz e evitou todas estas coisas que lê de mim, e que eu recordo e confesso, não se ria de mim por haver sido curado pelo mesmo médico que o preservou de cair enfermo, ou melhor, de que adoecesse tanto. Antes, esse deve amar-te tanto e ainda mais do que eu, porque o mesmo que me curou de tantas e tão graves enfermidades, esse mesmo o livrou de cair no pecado.

## CAPÍTULO VIII

### O prazer da cumplicidade

 E que fruto colhi eu, miserável, daquelas ações que agora recordo com rubor? Sobretudo daquele furto, em que amei o próprio furto, e nada mais? Nenhum, pois o furto, em si nada valia, ficando eu mais miserável com ele. Todavia, é certo que eu sozinho não o teria praticado – a julgar pela disposição de meu ânimo na ocasião; - não, de modo algum; eu sozinho não o faria. Portanto, apreciei também na ocasião a companhia daqueles com quem o cometi. Logo, também é certo que apreciei algo mais além do furto; embora não amasse de fato nada mais, pois também essa cumplicidade era nada.

 Mas, que é esta, na verdade? E quem mo poderá ensinar, senão o que ilumina meu coração e rasga minhas sombras? De onde vem à minha alma a idéia destas indagações, desta discussão e considerações? Se eu então amasse as pêras que roubei, e quisesse apenas seu desfrute, podia tê-las roubado sozinho, se isso bastasse. Poderia fazer a iniqüidade pela qual chegaria meu deleite sem necessidade de excitar o prurido da minha cobiça com a conivência de almas cúmplices.

 Porém, como não achava deleite algum nas pêras, colocava este no próprio pecado, que consistia na companhia dos que pecavam comigo.

## CAPÍTULO IX

### O prazer do pecado

 E que sentimento era aquele de minha alma? certamente, assaz torpe e eu um desgraçado por alimentá-lo. Mas, que era na realidade? E quem há que conheça os pecados? Era como um riso, como que a fazer-nos cócegas no coração, provocado por ver que enganávamos aos que não suspeitavam de nós tais coisas, e porque sabíamos que haviam de detestá-las.

 Porém, por que me deleitava o não perpetrar sozinho o roubo? Acaso alguém se ri facilmente quando está só? Ninguém o faz, é verdade; porém, também é verdade que às vezes o riso tenta e vence aos que estão sós, sem que ninguém os veja, quando se oferece aos sentidos ou à alma algo extraordinariamente ridículo. Porque a verdade é que eu sozinho nunca teria feito aquilo; não, eu sozinho jamais faria aquilo. Tenho viva, diante de mim, meu Deus, a lembrança daquele estado de alma, e repito que eu sozinho não teria cometido aquele furto, do qual não me deleitava o objeto, mas a razão do roubo, o que, sozinho, não me teria agradado de modo algum, nem eu o teria feito.

 Ó amizade inimiga! Sedução impenetrável da alma, vontade de fazer o mal por passatempo e brinquedo, apetite do dano alheio sem proveito algum e sem desejo de vingança! Só porque sentimos vergonha de não ser sem-vergonha quando ouvimos; "Vamos! Façamos!".

## CAPÍTULO X

### Deus, o sumo bem

 Quem desatará este nó, tão enredado e emaranhado? Como é asqueroso! Não quero voltar para ele os olhos, não quero vê-lo. Só a ti quero, justiça e inocência, tão bela e graciosa aos olhos puros, e com insaciável saciedade. Só em ti se acha o descanso supremo e a vida imperturbável. Quem entra em ti, entra no gozo do seu Senhor, e não temerá, e estará perfeitamente bem no sumo bem. Eu me afastei de ti e andei errante, meu Deus, mui longe de teu esteio em minha adolescência, e cheguei a ser para mim mesmo uma região de esterilidade.

# LIVRO TERCEIRO

## CAPÍTULO I

### O gosto do amor

 Cheguei a Cartago, e por toda parte fervilhava a sertã de amores impuros. Ainda não amava, mas já gostava de amar; secretamente sedento, aborrecia a mim próprio por não me sentir mais indigente de amor. Gostando do amor buscava o que amar, e odiava a segurança e os meus caminhos sem perigos, porque tinha dentro de mim fonte de alimento interior, de ti mesmo, ó meu Deus. Eu não sentia essa fonte como tal; antes, estava sem apetite algum dos manjares incorruptíveis, não porque estivesse saciado deles, mas porque, quanto mais vazio, tanto mais enfastiado me sentia.

 E por isso minha alma não estava bem e, ferida, voltava-se para fora de si, ávida de se roçar miseravelmente às coisas sensíveis; se porém não tivessem alma, não seriam certamente amadas.

 Amar e ser amado era para mim a coisa mais doce, sobretudo se podia gozar do corpo da criatura amada. Deste modo manchava com torpe concupiscência a fonte da amizade, e obscurecia seu candor com os vapores infernais da luxúria. E apesar de tão torpe e impuro, desejava com afã e cheio de vaidade, passar por afável e cortês.

 Caí por fim no amor, em que desejava ser colhido. Porém, ó meu Deus, misericórdia minha, quanto fel não misturaste àquela suavidade, e quão bom foste ao fazê-lo! Fui amado, e cheguei secretamente aos laços do prazer, e me deixei alegremente enredar com trabalhosos laços, para ser logo açoitado com as varas de ferro ardente do ciúme, das suspeitas, dos temores, das iras e das contendas.

## CAPÍTULO II

### A paixão dos espetáculos

 Arrebatavam-me os espetáculos teatrais, cheios das imagens de minhas misérias e de alimento para o fogo de minha paixão. Mas, por que quer o homem condoer-se ao contemplar coisas tristes e trágicas, que de modo algum gostaria de suportar? Contudo, o espectador deseja sofrer com elas, e até essa mesma dor é seu deleite. Que é isso, senão rematada loucura? De fato, tanto mais se comove alguém com elas quanto menos livre se está de tais afetos, embora chamemos de misérias os sofrimentos próprios, e de compaixão a comiseração do mal alheio.

 Porém, que compaixão pode haver em coisas fictícias e representadas? Nelas não se incita o espectador a que socorra a alguém, senão que o mesmo é convidado apenas à angústia, apreciando tanto mais o autor daquelas histórias quanto maior é o sentimento que elas nos inspiram. De onde resulta que, se tais desgraças humanas – quer das histórias antigas, quer sejam inventadas – são representadas de forma a não se excitarem sofrimento ao expectador, este sai aborrecido e murmurando; se porém, pelo contrário, é levado à tristeza, fica atento e chora satisfeito.

 Quer isso dizer que amamos as lágrimas e a dor? Sem dúvida que todo homem busca o gozo; mas como não agrada a ninguém ser miserável, e sendo grato a todos ser misericordioso, e como a piedade é inseparável da dor, não seria esta a causa verdadeira para que apreciemos essas emoções dolorosas?

 Também isso provém da amizade. Mas para onde se dirige? Para onde vai? Por que se atira à torrente da pez ardente, às vagas horrendas de negras leviandades em que a amizade se transforma voluntariamente, afastada e privada de sua celestial serenidade que o homem repudia?

 Deve-se, pois, repelir a compaixão? De modo algum. Convém, pois, que alguma vez se amem as dores. Mas evita nisso a impureza, ó minha alma, sob proteção de Deus, do Deus de nossos pais, louvado e exaltado por todos os séculos; cuidado com a impureza. Porque nem agora me fecho a tal compaixão. Mas naquele tempo comprazia-me no teatro com os amantes, quando eles se gozavam em suas torpezas – embora estas não passassem de encenações. E quando um deles se perdia, eu quase piedosamente me contristava, e sentia prazer numa e noutra coisa.

 Hoje, porém, tenho mais compaixão do homem que se alegra em seus vícios, que do que sofre pela perda de um prazer funesto ou pela perda de uma mísera felicidade. Esta misericórdia é certamente mais verdadeira, mas nela a dor não encontra nenhum prazer. E embora seja certo que se aprove quem por caridade se compadece do miserável, contudo, quem é fraternalmente compassivo preferiria que não houvesse razões para se compadecer. Porque assim como não é possível que exista uma benevolência malévola, tampouco o é que haja miseráveis para deles se compadecer.

 Há, pois, dores que merecem compaixão, porém, nenhuma que mereça amor. Por isso tu, Deus, que amas as almas muito mais elevadamente que nós, te compadeces delas de modo muito mais puro, porque não sentes nenhuma dor. Mas quem será capaz de chegar a isso?

 Mas eu, desventurado, amava então a dor, e buscava motivos para senti-la. Naquelas desgraças alheias, falsas e mímicas, agradava-me tanto mais a ação do ator, e me mantinha tanto mais atento quanto mais copiosas lágrimas me fazia derramar.

 Mas, que admira que eu, infeliz ovelha transviada de teu rebanho, por não aceitar tua proteção, estivesse atacado de ronha asquerosa? De aqui nasciam, sem dúvida, os desejos daquelas emoções de dor que, todavia, não queria que fossem muito profundas em mim, porque não desejava padecer coisas como as que via representadas. Comprazia-me que aquelas coisas, ouvidas ou fingidas, me tocassem só superficialmente. Mas, como acontece aos que coçam a ferida com as unhas, terminava por provocar em mim mesmo um tumor abrasador, podridão e pus repelente.

Tal era minha vida. Mas, seria isto vida, meu Deus?

## CAPÍTULO III

### O estudo da retórica e os demolidores

 Entretanto, tua misericórdia, fiel, de longe pairava sobre mim. Em quantas iniqüidades não me corrompi, meu Deus, levado por sacrílega curiosidade que, separando-me de ti, conduzia-me aos mais baixos, desleais e enganosos serviços aos demônios, a quem sacrificava minhas más ações, sendo em todas flagelado com duro açoite por ti!

 Também ousei apetecer ardentemente e procurar meios para conseguir os frutos da morte na celebração de teus mistérios, dentro dos muros de tua igreja. Por isso me açoitaste com duras penas, que nada eram comparadas com minhas culpas, ó Deus, misericórdia infinita, e meu refúgio contra os terríveis malfeitores, com os quais vaguei de cabeça erguida, afastando-me cada vez mais de ti, preferindo meus caminhos aos teus, amando a liberdade fugitiva!

 Os estudos a que era entregue, que se denominavam honestos ou nobres, tinham por objetivo as contendas do foro, nas quais deveria me distinguir com tanto maior louvor quanto mais hábeis fossem as mentiras. Tal é a cegueira dos homens, que até de sua própria cegueira se gloriam!

 Eu já conseguira, naquele tempo, ser o primeiro da escola de retórica, e por isso me vangloriava soberbamente, e me inflava de orgulho. Contudo, tu sabes, Senhor, que eu era muito mais sossegado que os demais, e totalmente alheio às turbulências dos eversores – ou demolidores – nome sinistro e diabólico que eles consideravam distintivo de urbanidade, entre os quais vivia com imprudente pudor por não pertencer a seu grupo. É verdade que andava com eles, e que me deleitava, às vezes, com sua amizade, porém, sempre aborreci o que faziam, como as troças e a insolência com que surpreendiam e ridicularizavam a timidez dos novatos, sem outra finalidade senão rir de suas trapalhadas, fazendo disso alimento para suas malévolas alegrias. Nada há mais parecido a estas ações que as dos demônios, pelo que nenhum nome lhes cai melhor que o de eversores ou demolidores, por serem eles transformados e pervertidos totalmente pelos espíritos malignos, que assim os burlam e enganam, sem que o saibam, justamente no que eles gostam de ludibriar ou enganar os demais.

## CAPÍTULO IV

### O Hortênsio de Cícero

 Entre essa gente estudava eu, em tão tenra idade, os livros da eloqüência, na qual desejava sobressair com o fim condenável e vão de satisfazer à vaidade humana. Mas, seguindo o programa usado no ensino desses estudos, cheguei a um livro de Cícero, cuja linguagem, mais do que seu conteúdo, quase todos admiram. Esse livro contém uma exortação à filosofia, e se chama Hortênsio. Esse livro mudou meus sentimentos, e transferiu para ti, Senhor, minhas súplicas, e fez com que mudassem meus votos e desejos. Subitamente, tornou-se vil a meus olhos toda vã esperança, e com incrível ardor de meu coração suspirava pela sabedoria imortal, e comecei a me reerguer para voltar a ti. Não era para limar a linguagem – aperfeiçoamento que, parece, eu compraria com o dinheiro de minha mãe, naquela idade de meus dezenove anos, fazendo dois que morrera meu pai – não era, repito, para limar o estilo que eu me dedicava à leitura daquele livro, nem era seu estilo o que a ela me incitava, mas o que ele dizia.

 Como ardia, meu Deus, como ardia meus desejos de voar para ti das coisas terrenas, sem que eu soubesse o que obravas em mim! Porque em ti está a sabedoria, pela qual aquelas páginas me apaixonavam. Não faltam os que nos iludam servindo-se da filosofia, colocando ou encobrindo seus erros com nome tão grande, tão doce e honesto. Mas quase todos os que assim fizeram em seu tempo e em épocas anteriores, são apontados e refutados nesse livro. Também se encontra ali bem claro aquele salutar aviso de teu Espírito, dado por meio de teu servo bom e piedoso (Paulo): Vede que ninguém vos engane com vãs filosofias e argúcias sedutoras, de acordo com a tradição dos homens e os ensinamentos deste mundo, e não de acordo com Cristo, porque é nele que habita corporalmente toda a plenitude da divindade.

 Mas então – tu bem o sabes, luz de meu coração – eu ainda não conhecia o pensamento de teu Apóstolo. Só me deleitava naquelas palavras de exortação, o fato de me excitarem fortemente, inflamando-me a amar, a buscar, a conquistar, a reter e a abraçar não a esta ou àquela seita, senão à própria Sabedoria, onde quer que estivesse. Só uma coisa me arrefecia tão grande ardor: não ver ali o nome de Cristo. Porque este nome, Senhor, este nome de meu Salvador, teu filho, por tua misericórdia eu o bebera piedosamente com o leite materno, e o conservava, no mais profundo do meu coração, em alto apreço; e assim, tudo quanto fosse escrito sem este nome, por mais verídico, elegante e erudito que fosse, não me arrebatava totalmente.

## CAPÍTULO V

### A desilusão das escrituras

 Em vista disso, decidi dedicar-me ao estudo da Sagrada Escritura, para a conhecer. Vi ali algo encoberto para os soberbos e obscuro para as crianças, mas humilde a princípio e sublime à medida que se avança o velado de mistérios; e eu não estava disposto a poder entrar nela, dobrando a cerviz à sua passagem. Contudo, ao fixar nela a atenção, não pensei o que agora estou dizendo, mas simplesmente me pareceu indigna de ser comparada com a majestade dos escritos de Cícero. Meu orgulho recusava sua simplicidade, e minha mente não lhe penetrava o íntimo. Contudo, a agudeza desta visão haveria de crescer com os pequenos; mas eu de nenhum modo queria ser criança e, enfatuado de soberba, considerava-me grande.

## CAPÍTULO VI

### A sedução do maniqueísmo

 Deste modo vim cair com uns homens que deliravam orgulhosos, demasiado carnais e loquazes; em sua boca havia laços diabólicos e engodo pegajoso feito com as silabas de teu nome, do nosso Senhor, Jesus Cristo, e do nosso Paráclito e Consolador, o Espírito Santo. Estes nomes nunca saíam de seus lábios, porém, só no som e ruído da boca, pois de resto, seu coração estava vazio de toda verdade.

 Diziam: "Verdade! Verdade!" – e, incessantemente, falavam-me da verdade, que nunca existiu neles; antes, diziam muitas falsidades, não apenas de ti, que és verdade por excelência, mas também dos elementos deste mundo, criação tua. Sobre isso, mesmo quando os filósofos diziam a verdade, tive de ultrapassá-los nos raciocínios por amor de ti, ó pai sumamente bom, beleza de todas as belezas!

 Ó verdade, verdade! Quão intimamente suspiravam por ti as fibras da minha alma, quando eles te faziam soar ao meu redor frequentemente e de muitos modos, embora apenas com as palavras e em seus muitos e volumosos livros. Estes eram as bandejas nas quais, estando eu faminto de ti, serviam-me em teu lugar o sol e a lua, formosas obras de tuas mãos, porém, obras tuas, e não a ti, nem sequer das principais. De fato, tuas obras espirituais são superiores a estas corporais, ainda que estas sejam brilhantes e celestes. Mas eu tinha sede e fome não daquelas primeiras, mas de ti mesmo, ó verdade, na qual não há mudança nem obscuridade momentânea!

 E eles serviam-me nessas bandejas esplendidas ficções, de acordo com as quais teria sido melhor amar a este sol, verdadeiro pelo menos aos olhos, em lugar daquelas falsidades que pelos olhos do corpo enganavam o entendimento.

 Contudo, como as tomava por ti, alimentava-me delas, não certamente com avidez, porque não tinham o teu gosto – pois não eras aqueles vãos fantasmas – nem me nutria com elas, antes sentia-me cada vez mais debilitado. A comida que se toma em sonhos, não obstante ser muito semelhante à do estado de vigília, não alimenta aos que dormem, porque estão dormindo. Aquilo, porém, em nada era semelhantes a ti, como agora me certificou a verdade, pois que eram fantasmas corpóreos ou falsos corpos; comparados com eles, são mais reais estes corpos – celestes ou terrestres – que vemos com os olhos da carne assim como os vêem os animais e as aves.

 Vemos estas coisas, e são mais reais do que as conjecturas sobre outros corpos grandiosos, que, por sua vez, que, por sua vez, quando as imaginamos, são mais reais do que quando por meio delas conjeturamos outras maiores e infinitas, que de modo algum existem. Com tais quimeras me alimentava eu, então, e por isso não me saciava.

 Mas tu, meu amor, em quem desfaleço para me tornar forte, nem és estes corpos que vemos, mesmo no céu; nem os outros que não vemos, porque és o Criador e os ocultaste, e não os consideras como as obras primas de tua criação.

 Oh! Quão longe estavas daquelas minhas quimeras, fantasmas de corpos que jamais existiram em comparação, são mais reais as imagens dos corpos existentes; e, mais reais ainda essas imagens, esses mesmos corpos, os quais, todavia, não são tu! Mas também não és a alma que dá vida aos corpos – mas é a vida das almas, a vida das vidas, que vives, imutável, por ti mesma; a vida de minha alma.

 Mas onde estavas então para mim? e quão longe peregrinava eu, longe de ti, privado até as bolotas com que eu alimentava os porcos! Quão melhores eram as fábulas dos gramáticos e poetas que todos aqueles enganos! Porque os versos, a poesia e a fábula de Medeia soando pelo ar são certamente mais úteis que os cinco elementos do mundo em seus mil disfarces, conforme os cinco antros de trevas, que não existem, mas que matam a quem nele acredita. Porém, versos e poesia eu os posso converter em iguaria para meu espírito e, quanto ao vôo de Medeia, se o recitava bem, não lhe afirmava veracidade e, se me agradava ouvi-lo, não lhe dava crédito. Mas – ai de mim! – eu acreditei naqueles erros dos maniqueístas.

 Ai de mim, por que degraus fui descendo até a profundidade do abismo, exaurido e devorado pela falta de verdade quando te buscava! E tudo isso, meu Deus – a quem me confesso porque te compadeceste de mim quando ainda não te conhecia – tudo por buscar-te, não com a inteligência – com a qual quiseste que eu fosse superior aos animais – mas com os sentidos da carne. E tu estavas dentro de mim, mais profundo do que o que em mim existe de mais íntimo, e mais elevado do que o que em mim existe de mais alto.

 Assim encontrei aquela mulher insolente e sem prudência – enigma de Salomão – que, sentada em uma cadeira à porta de sua casa, diz aos que passam: Comei à vontade dos pães escondidos, e bebei da doçura da água roubada, a qual me seduziu por andar eu vagando fora de mim, sob o império da vista carnal, ruminando em meu íntimo o que meus olhos haviam devorado.

## CAPÍTULO VII

### Alguns erros dos maniqueus

 Não conhecia eu outra realidade – a verdadeira – e me sentia como que movido por um aguilhão a aceitar a opinião daqueles insensatos impostores quando me perguntavam de onde procedia o mal, se Deus estava limitado por forma corpórea, se tinha cabelos e unhas, e se deviam ser considerados justos os que tinham várias mulheres simultaneamente, e os que causavam a morte de outros ou sacrificavam animais.

 Eu, ignorando essas coisas, perturbava-me com essas perguntas. Afastando-me da verdade, parecia-me encaminhar para ela, porque não sabia que o mal é apenas privação do bem, até chegar ao seu limite, o próprio nada. E como poderia ter eu tal conhecimento, se com os olhos não conseguia ver mais do que corpos, e com a alma não ia além de fantasmas?

 Tampouco sabia que Deus é espírito, que não tem membros dotados de comprimento ou largura, nem quantidade material alguma, porque a quantidade ou matéria é sempre menor na parte que no todo e, mesmo que fosse infinita, sempre seria menor em uma parte definida por um espaço determinado do que em sua infinitude, não podendo estar toda inteira em todas as partes, como o espírito, como Deus.

 Ignorava totalmente o princípio de nossa existência, que há em nós, e pelo qual a Escritura nos chama de imagem e semelhança de Deus.

 Não conhecia tampouco a verdadeira justiça interior, que não julga pelo costume, mas pela lei retíssima do Deus onipotente. Por ela se hão de formar os costumes dos países conforme os mesmos países e tempos, e sendo a mesma em todas as partes e tempos, não varia de acordo com as latitudes e as épocas; lei essa segundo a qual foram justos Abraão, Isaac, Jacó e Davi, e todos os que são louvados pela boca de Deus. Os ignorantes, julgando as coisas de acordo com a sabedoria humana, e medindo a conduta alheia pela própria, os julgam iníquos. É como se um ignorante em armaduras, não sabendo o que é próprio de cada membro, quisesse cobrir a cabeça com a couraça e os pés com o elmo, e se queixasse de que as peças não se lhe adaptem convenientemente. Ou como se alguém se queixasse de que, em determinado dia considerado feriado do meio-dia em diante, não lhe permitissem vender a mercadoria à tarde, como acontecera pela manhã; ou porque vê que na mesma casa permite-se a um escravo qualquer tocar no que não é permitido ao copeiro; ou porque não se permite fazer diante dos comensais o que se faz atrás de uma estrebaria; ou, finalmente, se indignasse porque, sendo uma a casa e uma a família, não se atribuíssem a todos as mesmas coisas.

 Tais são os que se indignam quando ouvem dizer que em outros tempos se permitiam aos justos coisas que não se lhe permitem agora, e que Deus mandou àqueles uma coisa e a estes outra, conforme os tempos, servindo uns e outros à mesma norma de santidade. E, contudo, é bem visível que no mesmo homem, no mesmo dia e na mesma hora e na mesma casa, o que convém a um membro não convém a outro; e aquilo que há pouco era licito, já não o é mais; e que o que se concede em uma parte, é justamente proibido e castigado em outra.

 Diremos, por isso, que a justiça é vária e inconstante? O que acontece é que os tempos a que ela preside não caminham no mesmo passo, porque são tempos. Mas os homens, cuja vida terrestre é breve, por não saberem harmonizar as causas dos tempos idos, e das gentes que não viram nem conheceram, com as que agora vêem e experimentam e, como também vêem facilmente o que no mesmo corpo, na mesma hora e lugar convém a cada membro, a cada tempo, a cada parte e a cada pessoa, escandalizam-se com as coisas daqueles tempos, enquanto aceitam as de agora.

 Ignorava eu então estas coisas e não as refletia e, embora de todos os lados me ferissem os olhos, eu não as via. Quando declamava algum poema, não me era lícito por um pé em qualquer outra parte do verso, senão em uma espécie de metro uns e em outra outros, e em um mesmo verso não podia meter em todas as partes o mesmo pé; e a própria arte da prosódia, apesar de mandar coisas tão distintas, não era diversa em cada parte, senão uma só e coerente. Contudo, não via como a justiça, à qual serviram aqueles varões bons e santos, pudesse conter simultaneamente, de modo mais belo e sublime, preceitos tão diversos, sem variar em sua essência, apesar de não mandar ou distribuir aos diferentes tempos todas as coisas simultaneamente, mas a cada um as que lhe são próprias. E, cego, censurava àqueles piedosos patriarcas, que não só usavam do presente como Deus lhes mandava e inspirava, mas também prediziam o futuro conforme Deus lhes revelava.

## CAPÍTULO VIII

### Moral e costume

 Acaso será em alguma parte e momento injusto amar a Deus de todo o coração, com toda a alma e com todo o entendimento, e amar ao próximo como a nós mesmos? Por isso, todos os pecados contra a natureza, como o foram os do sodomitas, hão de ser detestados e castigados sempre e em toda a parte, pois, mesmo que todos os cometessem, não seriam menos réus de crime diante da lei divina, que não fez os homens para usar tão torpemente de si; de fato viola-se a união que deve existir com Deus quando a natureza, da qual ele é autor, se mancha com a depravação das paixões.

 Com relação aos pecados que são contra os costumes humanos, também hão de ser evitados de acordo com a diversidade dos costumes, a fim de que o pacto mútuo entre os povos e nações, firmado pelo costume ou pela lei, não seja quebrado por nenhum capricho de cidadão ou forasteiro, porque é indecorosa a parte que não se acomoda ao todo.

 Todavia, quando Deus ordena algo contra tais costumes ou pactos, sejam quais forem, deve ser obedecido, embora o que mande nunca tenha sido feito; e se não foi cumprido, deve ser restaurado, e se não estava estabelecido, deve-se estabelecer. Se é lícito a um rei mandar na cidade que governa coisas que ninguém antes dele e nem ele próprio havia mandado, e se não é contra o bem da sociedade obedecê-lo, antes o seria o não obedecê-lo – por ser pacto básico de toda sociedade humana obedecer a seus reis – quanto mais deveria ser Deus obedecido sem titubeios em tudo que mandar, como rei do universo? Porque, assim como entre os poderes humanos o maior poder se antepõe ao menor, para que este lhe preste obediência, assim Deus antepõe-se a todos.

 O mesmo se deve dizer dos crimes perpetrados com desejo de causar o mal, quer por agressão, quer por injúria; e ambas as coisas, ou por desejo de vingança, como ocorre entre inimigos, ou por alcançar algum bem sem trabalhar, como o ladrão que rouba ao viajante; ou para evitar algum mal, como acontece com o que teme; ou por inveja, como quando um miserável quer mal ao que é mais feliz, ou ao que conseguiu riquezas, temendo ser igualado ou que já lhe sejam iguais; ou unicamente pelo prazer de ver o mal alheio, como acontece com o espectador dos combates dos gladiadores, ou com o que se ri e zomba dos outros.

 Tais são os princípios ou fontes de iniqüidade, que nascem da paixão de mandar, de ver ou de sentir, quer de uma só dessas paixões, ou de duas, ou de todas juntas. Razão por que se vive do mal, ó Deus altíssimo e dulcíssimo, contra o saltério de dez cordas, teu decálogo.

 Mas, que pecado pode atingir a ti, que não és atingido pela corrupção? Ou que crimes podem ser cometidos contra ti, a quem ninguém pode causar dano? O que vingas são os crimes que os homens cometem contra si, porque, mesmo quando pecam contra ti, agem impiamente contra suas próprias almas, e sua iniqüidade engana-se a si própria, quer corrompendo e pervertendo sua natureza – feita e ordenada por ti – quer usando imoderadamente das coisas permitidas, ou até desejando imoderadamente as não permitidas, pelo uso daquilo que é contra a natureza.

 Pecam também os que com o pensamento e a palavra se revoltam contra ti, dando coices contra o aguilhão; ou quando, uma vez quebrados os limites da sociedade humana, alegram-se audaciosamente com as facções ou desuniões, de acordo com as suas simpatias ou antipatias. E tudo isso o homem faz quando és abandonado, fonte da vida, único e verdadeiro criador e senhor do universo, e com orgulho egoísta ama-se uma parte do todo como se fosse o todo.

 Essa a razão pela qual só se pode voltar para ti com piedade humilde, para assim nos purificares nossos maus costumes; pela piedade te mostras propício com os pecados dos que te confessam, e ouves os gemidos dos cativos, e nos livras dos grilhões que nós mesmo forjamos, contanto que não ergamos contra ti os chifres de uma falsa liberdade, quer arrastados pela cobiça de mais haveres, quer pelo temos de perder tudo, preferindo nosso próprio egoísmo a ti, Bem de todos.

## CAPÍTULO IX

### Pecados e imperfeições

 Mas, entre tantas maldades, crimes e iniqüidades, estão os pecados dos que progridem, pecados que os homens de bom juízo vituperam, segundo a regra da perfeição, e louvam pela esperança de frutos futuros, como o verde é promissor das colheitas.

 Há outras ações semelhantes a ações maldosas ou a delitos, e que não são pecados, porque nem te ofendem a ti, Senhor, nosso Deus, nem tampouco à sociedade humana; como por exemplo quando procuramos coisas convenientes para o uso da vida e às circunstâncias, sem que se saiba se essa busca é cobiça, ou quando castigamos a alguém como desejo de que se corrija, fazendo uso do poder ordinário, e não se sabe se o fazemos por vontade de mortificar.

 Por isso, muitas ações que parecem condenáveis aos homens, são aprovadas por teu testemunho; e muitas, louvadas pelos homens, são condenadas por teu testemunho, porque muitas vezes as aparências do ato diferem das intenções do seu autor, assim como circunstâncias ocultas do tempo.

 Mas quando ordenas, algo insólito e imprevisto, mesmo que o tenhas proibido uma vez, mesmo que escondas por algum as razões do teu mandamento, mesmo que seja contra as convenções de alguns homens da sociedade, quem pode duvidar de que se há de obedecer, sendo que só é justa a sociedade humana que te obedece? Felizes dos que sabem o que tu ordenaste, porque os que te servem fazem tudo o que mandas, ou porque assim o exige o tempo presente, ou para preparar o futuro.

## CAPÍTULO X

### Ridicularias dos maniqueus

 Desconhecendo eu essas verdades, ria-me de teus santos e profetas. Mas, que fazia eu quando me ria deles, senão dar motivo para que te risses de mim? deixei-me cair insensivelmente, aos poucos, em tais extravagâncias, a ponto de acreditar que o figo, quando colhido, chora lágrimas de leite junto com a mãe figueira, e que se um "santo" da seita comesse o tal figo, colhido não por seu delito, mas de outrem, misturando-o em suas entranhas, gemendo e arrotando enquanto rezava, exalaria anjos e até mesmo partículas de Deus, partículas essas do verdadeiro Deus que ficariam cativas para sempre naquele fruto se não fossem libertadas pelos dentes e pelo estômago do "santo eleito"!

 Também acreditei, pobre de mim, que se devia ter mais misericórdia com os frutos da terra que com os homens para os quais foram criados. Pois, se algum faminto, que não fosse maniqueísta me pedisse de comer, parecia-me que atendê-lo era como merecer, por aquele bocado, a pena de morte.

## CAPÍTULO XI

### O sonho de Mônica

 Mas estendeste tua mão do alto, e arrancaste minha alma deste abismo de trevas, enquanto minha mãe, tua fiel serva, chorava-me diante de ti muito mais do que as outras mães costumam chorar sobre o cadáver dos filhos, pois via a morte de minha alma com a fé e o espírito que havia recebido de ti. E tu a escutaste, Senhor, tu a ouviste e não desprezaste suas lágrimas que, brotando copiosas, regavam o solo debaixo de seus olhos por onde fazia sua oração; sim, tu a escutaste, Senhor. Com efeito, donde podia vir aquele sonho, com que a consolaste, ao ponto de me admitir em sua companhia e mesa, fato que havia me negado porque aborrecia e detestava as blasfêmias do meu erro?

 Nesse sonho viu-se de pé sobre uma régua de madeira; e um jovem resplandecente, alegre e risonho que vinha ao seu encontro, triste e amarga. Este lhe perguntou a causa de sua tristeza e lágrimas diárias, não por curiosidade, como sói acontecer, mas para instruí-la; e respondendo-lhe ela que chorava a minha perdição, mandou-lhe, para sua tranqüilidade, que prestasse atenção e visse por onde ela estava também estaria eu. Apenas olhou, viu-me junto de si, de pé sobre a mesma régua.

 De onde veio este sonho, senão dos ouvidos que tinhas atentos a seu coração, ó Deus bom e onipotente, que cuidas de cada um de nós como se não tivesses outro para cuidar, zelando de todos como de cada um!

 E como explicar o que se segue? Contou-me minha mãe esta visão, e querendo-a eu persuadir de que significava o contrário, e que não devia desesperar de ser algum dia o que eu era, isto é, maniqueísta, ela, sem nenhuma hesitação, me respondeu: "Não; não me foi dito: onde ele está ali estarás tu, mas onde tu estás ali estará ele também".

 Confesso, Senhor, e muitas vezes disse que, pelo que me recordo, me abalou mais esta tua resposta pela solicitude de minha mãe, imperturbável diante de explicação falsa e ardilosa, e por ter visto o que se devia ver – e que eu certamente não veria sem que ela o dissesse – que o mesmo sonho com o qual anunciaste a esta piedosa mulher com tanta antecedência, a fim de consolá-la em sua aflição presente, uma alegria que só havia de se realizar muito tempo depois.

 Seguiram-se, efetivamente, quase nove anos, durante os quais continuei a me revolver naquele abismo de lodo e trevas de erro, afundando-me tanto mais quanto mais esforços fazia para me libertar. Entretanto, aquela piedosa viúva, casta e sóbria como as que tu amas, já um pouco mais alegre com a esperança, porém, não menos solícita em suas lágrimas e gemidos, não cessava de chorar por mim em tua presença em todas as horas de suas orações; e suas preces eram aceitas a teus olhos, mas deixava-me ainda revolver-me e envolver-me naquela escuridão.

## CAPÍTULO XII

### Uma profecia

 Nessa mesma ocasião deste à minha mãe outra resposta, de que ainda me lembro – pois passo em silencio muitas circunstâncias, pela pressa que tenho de chegar àquelas que te devo confessar com mais urgência, ou porque não as recordo – deste-lhe outra resposta por meio de um teu bispo, educado em tua Igreja e exercitado em tuas Escrituras. Como ela pedisse que se dignasse falar comigo, para refutar meus erros e desenganar-me de minhas más doutrinas e ensinar-me as boas – pois assim fazia com quantos julgava idôneos – ele negou-se com muita prudência, como pude verificar depois; respondeu-lhe que eu estava incapacitado para receber qualquer ensinamento, por estar enfatuado com a novidade da heresia maniqueísta, e por haver criado embaraço a muitos ignorantes com algumas questões fáceis, como ela mesma lhe relatara. "Deixe-o – disse – e unicamente ore por ele ao Senhor! Ele mesmo, lendo os livros dos hereges, descobrirá o erro e reconhecerá sua grande impiedade". – Ao mesmo tempo contou-lhe que, quando criança, sua mãe, seduzida pelo erro, entregara-o aos maniqueus, chegando não só a ler, mas a copiar quase todas as suas obras; e que ele mesmo, sem necessidade de que ninguém o contestasse ou convencesse, chegara a perceber a falácia daquela doutrina, abandonando-a enfim.

 Depois de assim falar, minha mãe não se aquietava, instando com maiores rogos e mais copiosas lágrimas a que me visitasse, para discutir comigo sobre o tal assunto. O bispo, já com certo enfado de sua insistência, lhe disse: "Vai-te em paz, mulher, e continua a viver assim, que não é possível que pereça o filho de tantas lágrimas" – palavras que ela recebeu como vindas do céu, segundo me recordava muitas vezes em seus colóquios comigo.

# LIVRO QUARTO

## CAPÍTULO I

### Dos dezenove aos vinte e oito anos

 Durante esse período de nove anos – dos dezenove até os vinte e oito anos – fui seduzido e sedutor, enganado e enganador, conforme minhas muitas paixões; publicamente, com aquelas doutrinas que se chamam liberais; ocultamente, com o falso nome de religião, mostrando-me aqui soberbo, ali supersticioso, e em toda parte vaidoso. Ora perseguindo a aura da gloria popular até os aplausos do teatro, os certames poéticos, os torneios de coroas de feno, as bagatelas de espetáculos e a intemperança da luxúria; ora, desejando muito purificar-me dessas imundícies, levando alimento aos chamados "eleitos" e "santos", para que na oficina de seu estômago fabricasse anjos e deuses que me libertassem. Tais coisas seguia eu e praticava com meus amigos, iludidos comigo e por mim.

 Riam-se de mim os arrogantes, e os que ainda não foram prostrados e salutarmente esmagados por ti, meu Deus; mas eu, pelo contrário, hei de confessar diante de ti minhas torpezas para teu louvor. Permite-me, te suplico, e concede-me que me lembre fielmente dos desvios passados de meu erro, e que eu te sacrifique uma vítima de louvor.

 De fato, sem ti, que sou eu para mim mesmo senão um guia que conduz ao abismo? Ou que sou eu, quando tudo me corre bem, senão uma criança que suga o leite, e que se alimenta de ti, alimento incorruptível? E que é o homem, seja ele quem for, se é homem?

 Riam-se de nós os fortes e poderosos, que nós, débeis e pobres, confessaremos teu santo nome.

## CAPÍTULO II

### Professor de retórica

 Naqueles anos eu ensinava retórica e, movido pela cobiça, vendia a arte de vencer pela loquacidade. Contudo, bem sabes, Senhor, que preferia ter bons discípulos, dos que se chamam "bons", aos quais ensinava sem rodeios a arte de enganar, não para que usassem dela contra a vida de um inocente, mas para algum dia defender algum culpado. Mas, ó Deus, tu me viste de longe vacilar sobre um caminho escorregadio, viste brilhar, entre espesso fumo, os fulgores da boa fé que eu demonstrava ao ensinar àqueles amantes da vaidade, àqueles pesquisadores de mentiras, eu, seu irmão e semelhante.

 Por essa mesma época tive em minha companhia uma mulher, não reconhecida pelo chamado matrimônio legítimo, mas procurada pelo inquieto ardor de minha paixão imprudente; mas era só uma, e eu lhe era fiel. E assim experimentei pessoalmente a distância que há entre o amor conjugal contraído com o fim de ter filhos, e o amor lascivo, no qual a prole também nasce, mas contra o desejo dos pais, embora, uma vez nascida, os obrigue a amá-la.

 Lembro-me também de que, querendo participar de um certame de poesia, um arúspide mandou-me indagar que dádiva lhe daria para eu sair vencedor. Mas eu, que abominava aqueles nefandos sortilégios, respondi-lhe que não consentiria que se matasse uma mosca para obter a vitória, mesmo que o prêmio fosse uma coroa de ouro incorruptível; sabia eu que ele teria de matar animais em seus sacrifícios, julgando com tais honras assegurar para mim os votos do demônio.

 Mas, confesso, Deus de meu coração, que se repudiei tal crime, não o fiz por amor da tua pureza. Pois ainda não sabia te amar, eu, que sabia conceder apenas esplendores corpóreos. Não é pois verdade que a alma que suspira por semelhantes fábulas não se aniquila longe de ti, e se apóia na falsidade, e se apascenta de vento? Mas eis que, não querendo que se oferecessem sacrifícios aos demônios, eu mesmo me sacrificava a eles com aquela superstição. Com efeito, que significa apascentar ventos, senão apascentar os espíritos diabólicos, isto é, tornarmo-nos, por nossos erros, objeto de seu riso e escárnio?

## CAPÍTULO III

### A atração da astrologia

 Por isso, não cessava de consultar os impostores chamados matemáticos, já que estes não usavam em suas adivinhações de quase nenhum sacrifício, nem dirigiam preces a nenhum espírito o que, consequentemente, é condenado e repelido com razão pela piedade cristã e verdadeira. Porque o bom é confessar-te, Senhor, e dizer-te: Tem misericórdia de mim, e cura minha alma, porque pecou contra ti, e não abusar da tua indulgência para pecar mais livremente, mas ter sempre presente a sentença do Senhor: Eis-te curado: não peques mais, para que te não suceda algo pior – Estas palavras, cujo efeito salutar os astrólogos querem destruir, dizendo: "O impulso de pecar vem dos céus; foi Vênus, Saturno ou Marte que fizeram isto" – e tudo para que o homem, que é carne, e sangue, e soberba podridão, se sinta sem culpa, e atribua esta ao criador e ordenador do céu e das estrelas. E quem é este, senão tu, nosso Deus, suavidade e fonte de justiça, que dás a cada um de acordo com suas obras, e não desprezas ao coração contrito e humilhado?

 Havia então um varão muito sábio, peritíssimo na arte médica, na qual era celebre; sendo procônsul, pôs com suas próprias mãos sobre minha cabeça insana a coroa da vitória do concurso; foi como procônsul, e não como médico, porque daquela minha enfermidade só tu me podias sarar, pois resistes aos soberbos e dás tua graça aos humildes.

 Contudo, deixaste acaso de cuidar de mim também por meio daquele ancião? Ou talvez desistisse de curar minha alma? Tendo-me familiarizado muito com ele, passei a ser assistente assíduo e freqüente de suas conversas, que eram agradáveis e graves, não pela elegância da linguagem, mas pela vivacidade das sentenças. Assim que ficou sabendo, por conversa, que eu me dedicava à leitura dos livros dos astrólogos, admoestou-me benigna e paternalmente a que os deixasse, e a que não gastasse inutilmente nessas quimeras meus cuidados e trabalho, que melhor empregaria em coisas úteis. Acrescentou que também ele havia cultivado aquela arte, a ponto de querer adotá-la, em sua juventude, como profissão para ganhar a vida, pois, se havia entendido Hipócrates, podia também entender aqueles livros; por fim, deixara aqueles estudos pelos da medicina, por causa da sua falsidade, não querendo, como homem sério, ganhar o pão enganando os outros. "Mas tu, disse-me ele – que tens para manter entre os homens tuas aulas de retórica, segues essas mentiras não por necessidade, mas por mera curiosidade; mais um motivo para que acredites no que te digo, pois cuidei de aprendê-la tão perfeitamente que quis viver apenas de seu exercício".

 Indaguei-lhe então por que muitas das coisas prognosticadas pela tal ciência se revelavam verdadeiras, respondeu-me, como pôde, que a força do acaso está espalhada por toda a natureza. "Se alguém – dizia ele – consultando as vezes as páginas de um poeta qualquer, encontra um verso que, apesar do poeta pensar em coisas muito diversas quando o compôs, adapta-se admiravelmente ao assunto que o preocupa; assim pois nada tem de estranho que a alma humana, movida por instinto superior, inconsciente do que se passa no seu íntimo, diga, não por arte, mas por sorte, algo que corresponda aos atos e gestos do consulente".

 E isto, Senhor, me ensinou ele, ou melhor, me ensinaste por teu intermédio, e delineaste em minha memória o que eu mesmo mais tarde devia procurar. Mas então, nem ele, nem meu caríssimo Nebrídio, jovem muito bom e casto, que zombava de toda aquela arte divinatória, puderam me convencer a abandoná-la, porque ainda impressionava-me mais a autoridade daqueles autores. Não tinha eu encontrado ainda o argumento evidente que procurava, que me demonstrasse sem ambigüidade que os presságios acertados dos astrólogos são obra da sorte ou casualidade, e não da arte de observar os astros.

## CAPÍTULO IV

### A morte do amigo

 Por aqueles anos, quando comecei a ensinar em minha cidade natal, conheci um amigo, a quem amei em demasia por ser meu companheiro de estudos, de minha idade, e por estarmos ambos na flor da juventude. Juntos fomos criados quando crianças, juntos íamos à escola, juntos havíamos brincado. Mas nessa época não era amigo tão íntimo como o foi depois, embora também não o fosse tanto quanto o exige a verdadeira amizade, uma vez que esta só existe entre os que unes por meio da caridade, derramada em nossos corações pelo Espírito Santo que nos foi dado.

 Contudo, aquela amizade, aquecida ao calor de estudos semelhantes era-me sumamente grata. Consegui até afastá-lo da verdadeira fé, pouco profunda e arraigada em sua adolescência, arrastando-o para as fábulas supersticiosas e prejudiciais, razão das lágrimas de minha mãe. Esse homem já errava em espírito comigo, e minha alma não podia viver sem ele.

 Mas eis que, seguindo de perto no encalço de teus servos fugitivos, ó Deus das vinganças, que és a um tempo fonte de misericórdia, e nos converte a ti por estranhos caminhos, eis que tu o arrebataste desta vida, quando eu apenas havia gozado um ano de sua amizade, mais doce para mim que todas as doçuras da minha vida.

 Quem poderá enumerar teus louvores, mesmo limitando-se ao que experimentou em si mesmo? Que fizeste então, meu Deus! E quão impenetrável é o abismo de teus juízos! Lutando meu amigo contra a febre, ficou por muito tempo sem sentidos, banhado no suor da morte; e, como temessem por sua vida, batizaram-no sem que ele o soubesse, com o que não me importei, convencido que estava de que seu espírito reteria melhor aquilo que eu lhe havia inculcado do que o sinal que recebera sobre o corpo inconsciente.

 A realidade, contudo, foi muito outra. Melhorando, e estando fora de perigo, logo que lhe pude falar – e o fiz logo que ele o pôde, e como dependíamos mutuamente um do outro eu não me afastava do seu lado – tentei rir-me em sua presença do batismo, julgando que também ele zombaria comigo de um batismo recebido sem conhecimento nem sentidos, mas ele já sabia que o havia recebido. Olhando-me então com horror, como a um inimigo, admoestou-me com admirável e repentina franqueza, dizendo-me que se queria continuar a ser seu amigo deixasse de tais palavras. Admirado e perturbado, reprimi toda minha emoção, esperando que convalescesse primeiro, para, recobradas as forças, estar disposto a discutir comigo o que quisesse. Mas tu, Senhor, livraste-o de minha louca amizade, guardando-o em ti para o meu consolo, pois, poucos dias depois, na minha ausência, voltaram-lhe as febres e morreu.

 Que dor fez anoitecer o meu coração! Tudo o que via era morte para mim. a pátria me era um suplício, e a casa paterna tormento insuportável, e tudo o que o lembrava transformava-se para mim em crudelíssimo martírio. Buscavam-no por toda parte meus olhos, e o mundo não mo devolvia. Cheguei a odiar todas as coisas, porque nada o continha, e ninguém mais me podia dizer como antes, quando chegava depois de alguma ausência: "Ali vem ele". Transformara-me mesmo num grande problema. Perguntava à minha alma porque andava triste, e se perturbava tanto, e ela não sabia o que responder-me. E se eu lhe dizia: "Espera em Deus" – minha alma não me obedecia, e com razão, porque para mim, era mais real e melhor o amigo querido que perdera, que o fantasma em que mandava tivesse esperança. Só o pranto me era doce. Ocupava o lugar de meu amigo nas delicias de meu coração.

## CAPÍTULO V

### O conforto das lágrimas

 E agora, Senhor, que essas coisas já passaram, agora que o tempo sarou minha ferida, poderei ouvir de ti, que és a própria verdade, aproximando o ouvido de meu coração de tua boca, o motivo por que o pranto é doce aos desgraçados? Acaso, mesmo presente em toda parte, repeliste para longe de ti nossa miséria, permanecendo imutável em ti, enquanto deixas que nos envolvamos em nossas provações? E, contudo, se nossos lamentos não chegarem a teus ouvidos, não haverá para nós esperança alguma.

 Mas, por que motivo dos gemidos, do choro, dos suspiros e das queixas colhe-se como fruto doce do amargor da vida? Esperamos que nos ouça? Virá daí a doçura? Isso acontece na oração que leva em si o desejo de chegar a ti; porém, poder-se-á dizer o mesmo da dor da perda ou do pranto que então me avassalavam?

 Eu não esperava ressuscitar meu amigo com minhas lágrimas, mas limitava-me a me condoer e a chorar minha miséria, pois eu havia perdido minha alegria.

 Ou será que o pranto, que é amargo em si mesmo, se torna um deleite quando, pelo fastio, aborrecemos os prazeres que antes nos eram gratos?

## CAPÍTULO VI

### Inconsolável

 Mas para que falar dessas coisas, se agora não é tempo de investigar, mas de me confessar a ti? Eu era miserável, como o é toda alma prisioneira do amor pelas coisas temporais; se sente despedaçar quando as perde, sentindo então sua miséria, que a torna miserável antes mesmo de as perder. Assim é como eu era então e, chorando muito amargamente, descansava na amargura. E como era miserável! Contudo, mais que o amigo caríssimo, eu amava minha vida miserável, porque embora desejasse mudá-la, não queria perdê-la como ao amigo, não sei se gostaria de perdê-la por ele, como se conta de Orestes e Pílades – se não é ficção – que queriam morrer um pelo outro, porque para eles viver separados era pior que a morte. Mas não sei que novo sentimento nascera em mim, muito contrário a este: sentia pesado tédio de viver, e ao mesmo tempo tinha medo de morrer. Creio que quanto mais amava o amigo tanto mais odiava e temia a morte, como inimigo feroz que mo havia arrebatado; pensava que ela acabaria de repente com todos os homens, como o fizera com ele. Este era meu estado de espírito, pelo que me lembro.

 Meu Deus, eis aqui meu coração, ei seu conteúdo! Olha para o meu passado, porque sei, esperança minha, que me purificas da impureza desses afetos, atraindo para ti meus olhos, e libertando meus pés dos laços que me aprisionavam. Maravilhava-me de que sobrevivessem os outros mortais a seus amados se nunca houvessem de morrer; e mais me maravilhava ainda de que, morto ele, eu continuasse a viver, porque eu era outro ele. Bem disse um poeta quando chamou ao amigo "metade da sua alma". E eu senti que minha alma e a sua não eram mais que uma em dois corpos, e por isso causava-me horror a vida, porque não queria viver pela metade; e ao mesmo tempo tinha muito medo de morrer, para que não morresse de todo aquele a quem eu tanto amara.

## CAPÍTULO VII

### De Tagaste para Cartago

 Ó loucura, que não sabe amar os homens humanamente! Ó homem insensato, que sofre desmedidamente os reveses humanos! Assim era eu então, e assim agitava-me, suspirava, chorava, perturbava-me, e não encontrava descanso nem conselho. Trazia a alma em farrapos e ensangüentada, indócil ao meu governo, e eu não encontrava lugar onde a pudesse depor. Nem os bosques amenos, nem os jogos e cantos, nem os lugares suavemente perfumados, nem os banquetes suntuosos, nem os prazeres da alcova e do leito, nem, finalmente, os livros e os versos podiam dar-lhe descanso. Tudo me causava horror, até a própria luz. Tudo o que não era o que ele era, era-me insuportável e odioso, exceto gemer e chorar, pois, somente nisto achava algum repouso. E se minha alma deixava de chorar, logo pesava sobre mim o grande fardo da desgraça.

 A ti, Senhor, deveria ser elevada, para ter cura. Eu o sabia, mas não o queria nem podia. Tanto mais que, ao pensar em ti, não tinha em mente algo sólido e firme, mas um fantasma, o meu erro. Se nele tentava descansar minha alma, logo deslizava como quem pisa em falso, e caía de novo sobre mim. Eu era para mim mesmo uma infeliz morada, na qual era ruim e da qual não podia sair. E para onde iria meu coração, fugindo de si mesmo? Para onde fugir de mim mesmo? Para onde não me seguiria?

 Por isso fugi de minha pátria, porque meus olhos buscariam menos meu amigo onde não estavam acostumados a vê-lo. E assim me fui de Tagaste para Cartago.

## CAPÍTULO VIII

### O consolo do tempo e da amizade

 O tempo não corre debalde, nem passa inutilmente sobre nossos sentidos; antes, causa na alma efeitos maravilhosos. Assim vinha e passava, dias após dias, e passando deixava em mim novas esperanças e novas recordações; pouco a pouco restituía-me a meus prazeres de outrora, a que ia cedendo minha dor. Substituíam-na não novas dores, mas sementes de novas dores. Mas, por que me penetrara aquela dor tão profundamente, até o mais íntimo de meu ser, senão porque derramei minha alma sobre a areia, amando a um mortal como se não o fora? O que mais me confortava e alegrava eram sobretudo as consolações de outros amigos, com os quais partilhava o amor para o que amava tem teu lugar, isto é, uma fábula enorme, uma longa mentira, cujo contato impuro corrompia nossa mente, arrastada pelo prurido de ouvir aquilo que a agradava; fábula esta que não morria para mim, ainda que morresse algum de meus amigos.

 Outros prazeres havia neles que cativavam mais fortemente minha alma, como conversar, rir, agradar-nos mutuamente com amabilidade, ler juntos livros bem escritos, gracejar uns com os outros e divertir-nos juntos; às vezes discutir, mas sem ódio, como quando discordamos de nós mesmos para, com tais discórdias muito raras, temperar as muitas conformidades; ensinar ou aprender reciprocamente muitas coisas, suspirar impacientes pelos ausentes e receber alegres os recém-chegados. Estes sinais, e outros semelhantes, que procedem de corações que se amam, e que se manifestam no rosto, na fala, nos olhos, e em mil outros gestos graciosos, inflamavam nossas almas, como em uma centelha, fazendo de muitas uma só.

## CAPÍTULO IX

### O amigo de Deus

. É isto o que se ama nos amigos; e de tal modo se ama, que a consciência humana se julga culpada se não ama ao que a ama, ou se não retribui amor com amor procurando na pessoa do amigo apenas o sinal exterior de sua benevolência. Daqui o pranto do luto quando morre um amigo, as trevas de dores, e as lágrimas que inundam o coração quando a doçura se transforma em angústia, e a morte dos que morrem na morte dos que vivem.

 Bem-aventurado o que te ama, Senhor, e ama ao amigo em ti, e ao inimigo por amor a ti; só não perde o amigo quem tem a todos por amigos naquele que nunca se perde. E quem é este, senão nosso Deus, o Deus que fez o céu e a terra, e os enche, porque, enchendo-os, os criou? Ninguém, Senhor, te perde senão o que te abandona. Mas, quem te deixa, para onde vai, ou para onde foge, senão de ti benévolo para ti irado? Onde não achará tua lei para seu castigo? Porque tua lei é a verdade, e a verdade és tu mesmo.

## CAPÍTULO X

### As mentiras da beleza

 Ó Deus das virtudes! Converte-nos e mostra-nos tua face, e seremos salvos! Porque, para onde quer que se volte a alma humana, onde quer que se estabeleça fora de ti, sempre encontrará dor, mesmo que sejam as belezas que estão fora de ti e fora de si mesma; e todavia, estas nada seriam se não existissem em ti. Elas nascem e morrem; e, nascendo, começam a existir, e crescem para alcançar a perfeição e, uma vez perfeitas, começam a envelhecer e morrem. Embora nem tudo envelheça, tudo perece. Logo, quando os seres nascem e se esforçam para existir, quanto mais depressa crescem para existir, tanto mais se apressam para deixar de existir. Esta é a sua condição. Eis tudo o que lhes deste, porque são partes de coisas que não existem simultaneamente mas, morrendo e sucedendo-se umas às outras, formam o conjunto de que são partes.

 Assim forma-se também nosso discurso, por meio dos sinais sonoros; este nunca se realizaria se uma palavra não se extinguisse, depois de pronunciadas suas sílabas, para dar lugar à seguinte.

 Que minha alma te louve por tudo isto, ó Deus, criador de todas as coisas; mas não se pegue a elas com o visco do amor dos sentidos, pois também elas caminham para o não-ser, e dilaceram a alma com desejos pestilenciais, e ela quer existir e gosta de descansar nas coisas que ama. Mas nelas não acha onde, porque as coisas não são estáveis. Elas são fugazes, e quem poderá segui-las com os sentidos da carne? Ou quem as pode alcançar, mesmo estando presentes? Lento é o sentido da carne, por ser da carne, mas essa é a sua condição. É suficiente para o que foi criado, mas não o é para reter o curso das coisas, do princípio que lhes foi fixado, até o fim que lhes foi designado, porque em teu Verbo, que as criou, ouvem estas palavras: "Daqui até ali".

## CAPÍTULO XI

### A verdade de Deus

 Não seja vã, ó minha alma, nem ensurdeças o ouvido do coração com o tumulto de tua vaidade. Ouve também : o próprio Verbo clama que voltes, porque só acharás repouso imperturbável lá onde o amor não é abandonado, se ele não nos abandona antes. Eis que as coisas passam para ceder lugar as outras, e para que assim se forme este universo inferior, de todas as suas partes. "Mas, por acaso, afasto-me de um lugar para outro? – diz o Verbo de Deus – Fixa nele tua morada, confia a ele tudo o que dele recebeste, alma minha, já cansada de tantos enganos. Confia à Verdade quanto da Verdade recebeste, e nada perderás; antes, tua podridão reflorescerá e serão curadas todas as tuas fraquezas, e serão retomadas e renovadas, estreitamente unidas a ti, tuas partes inconscientes; e já não te arrastarão para a ladeira por onde descem, mas permanecerão contigo para sempre onde está Deus, eterno e imutável.

 Por que, perversa, segues o apelo de tua carne? Seja esta, convertida a te seguir. Tudo o que por ela sentes é parte, mas ignoras o todo de que é parte, ainda que te dê prazer. Mas, se os sentidos de tua carne fossem idôneos para compreender o todo, e se, para teu castigo, não tivessem sido justamente limitados a compreender apenas partes do universo, certamente desejarias que passasse tudo o que presentemente existe, para melhor desfrutar do conjunto.

 O que falamos também ouves com os ouvidos da carne, e com certeza não queres que as sílabas se detenham, mas que voem, para que outras lhes sucedam, e assim ouvires o conjunto. O mesmo acontece com todas as coisas que compõem um todo, quando essas partes constituintes não existem simultaneamente; há mais encanto no todo do que nas partes percebidas separadamente. Mas melhor do que todas elas, é o que as fez, que é nosso Deus, que não passa, porque nada vem depois dele.

## CAPÍTULO XII

### O amor em Deus

 Se te agradam os corpos, louva a Deus neles, e dirige teu amor para teu artífice, para não o desagradar nas mesmas coisas que te agradam.

 Se te agradam as almas, ama-as em Deus, porque, embora mutáveis, se fixas nele, terão estabilidade; de outro modo, passariam e pereceriam. Ama-as, pois, nele, e arrasta contigo até ele quantas almas puderes, dizendo-lhes: "Amemo-lo". Porque ele criou estas coisas, e não está longe; ele não as fez para depois ir embora, mas dele procedem e nele estão. E ele está onde aprecia a verdade: no mais íntimo do coração; mas o coração errante se afastou dele.

 Voltai, pecadores, ao coração, e ligai-vos àquele que é vosso criador. Firmai-vos nele, e estareis firmes; descansai nele, e estareis descansados. Para onde ides por esses ásperos caminhos? Para onde ides? O bem que amais, dele procede, mas só é bom e suave quando se dirige a ele; porém, será justamente amargo se, abandonando a Deus, amardes injustamente o que dele procede. Por que continuai por caminhos difíceis e trabalhosos? O descanso não está onde o buscais. Buscais a vida feliz na região das trevas: não está lá. Como achar a vida bemaventurada onde nem sequer há vida?

 Ele, nossa vida real veio até nós; sofreu nossa morte, e a suplantou com a abundância de sua vida; com voz de trovão clamou para que voltássemos a ele, para o lugar escondido de onde veio até nós, passando primeiro pelo seio de uma virgem, onde se desposou com ele a natureza humana, carne mortal, para não ficar sempre mortal.

 Dali, como o esposo que sai do tálamo, deu saltos como um gigante, para correr seu caminho. E não se deteve; correu clamando com suas palavras, com suas obras, com sua própria morte, com sua vida, com sua descida aos ínferos e com sua ascensão, clamando para que voltássemos a ele. Se ele se afastou de nossa vista, foi para que entremos em nosso coração, e ali o encontremos; se partiu, ainda está conosco. Não quis ficar por muito tempo entre nós, mas não nos abandonou. Retirou-se de onde nunca se afastou, pois o mundo foi criado por ele, e no mundo estava, e ao mundo veio para salvar os pecadores. E a ele se confessa minha alma, a ele que a cura e contra quem pecou.

 Filhos dos homens, até quando sereis duros de coração? Será possível que, depois de ter a vida descido até vós, não queirais subir e viver? Mas para onde subis, quando vos ergueis e abris vossa boca no céu? Descei para subir, para subir até Deus, já que caístes levantando-vos contra Deus.

 Dize-lhes isto, minha alma, para que chorem neste vale de lágrimas, e assim os arrebates contigo para Deus, pois, ao dizer estas palavras ardendo em chamas de caridade, é o espírito divino que te inspira.

## CAPÍTULO XIII

### O problema do belo

 Então eu ignorava tais coisas – e por isso amava belezas terrenas. Caminhava para o abismo, dizendo a meus amigos: "Será que amamos algo que não é belo? E que é o belo? E que é a beleza? Que é que nos atrai e apega às coisas que amamos? Pois, com certeza, se nelas não houvesse certa graça e formosura, não nos atrairiam.

 E eu observava e via que num mesmo corpo uma coisa era o todo, harmonioso e belo, e outra o que lhe era conveniente, sal aptidão de se ajustar de maneira perfeita a alguma coisa como, por exemplo, a parte do corpo em relação ao conjunto, o calçado em relação ao pé, e outras similares. Esta consideração brotou em minha alma do íntimo de meu coração, e escrevi alguns livros sobre o belo e o conveniente, creio que dois ou três – tu o sabes, Senhor – pois já me esqueci, e não os tenho mais porque se me extraviaram não sei como.

## CAPÍTULO XIV

### Razões de uma dedicatória

 Mas, meu Senhor e meu Deus, qual o motivo de dedicar esses livros a Hiério, orador de Roma? Não o conhecia, apreciando-o apenas pela fama de sua doutrina, que era grande, e por alguns ditos seus, que ouvira, e que me agradaram. Mas dele gostava principalmente porque ele agradava aos outros, que lhe tributavam grandes elogios, admirados de que um sírio, educado na eloqüência grega, chegasse a orador admirável na latina, e grande conhecedor de todos os assuntos, ligados à filosofia. Assim, ouve-se louvar a um homem, e, embora ausente, começa-se a amá-lo. Entrará o amor no coração do que ouve pela boca do que louva? É certo que não, mas o amor de um se inflama com amor do outro. Por isso se ama ao que é louvado; mas só quando se está persuadido de que o louvor vem de coração sincero, ou quando o louvor é inspirado pelo amor.

 Assim pois amava eu então aos homens, pelo juízo dos homens, e não pelo teu, meu Deus, em quem ninguém se engana. Contudo, por que não o louvava como se louva a uma auriga famoso ou a um caçador afamado pelas aclamações do povo, mas de modo mais distinto e mais ponderado, tal como eu gostaria de ser louvado?

 Certamente, eu não gostaria de ser louvado e amado como os comediantes, embora eu também os ame e louve; antes, preferiria mil vezes, permanecer desconhecido a ser louvado dessa maneira, e mesmo ser odiado a ser amado assim. De que modo convivem em uma alma gostos tão vários e diversos? Como é que amo em outro o que rejeitaria e afastaria para longe de mim, sendo ambos homens? Aprecia-se um bom cavalo, sem que se queira ser um cavalo, se isso fosse possível. Mas de um histrião não se pode dizer o mesmo, pois tem a mesma natureza que nós. Logo, amo em um homem o que teria horror de ser, embora também eu seja homem? Grande abismo é o homem, cujos cabelos tu, Senhor, tens contados; e não se perde um sem que tu o saibas; e, contudo, mais fáceis de contar são seus cabelos que suas paixões e os movimentos de seu coração.

 Mas aquele orador era do número dos que eu amava a ponto de desejar ser como ele; mas eu andava errante por meu orgulho e era arrastado por toda espécie de vento, embora em segredo fosse governado por ti. E como sei, e como te confesso com tanta certeza que o amava mais por amor dos que o louvavam do que pelos méritos que lhe valiam esses louvores?

 Se em vez de o louvarem aquelas mesmas pessoas o criticassem, e se me contassem dele as mesmas coisas, mas com censura e desprezo, certamente não me entusiasmaria por ele; não obstante, os fatos não seriam diferentes e nem o homem outro, mas unicamente os sentimentos dos narradores.

 Eis onde jaz enferma a alma que ainda não se apoiou na firmeza da verdade. É levada e trazida, atirada e rechaçada, segundo os sopros das línguas que ventam dos peitos dos que opinam! E de tal modo a luz lhe é toldada, que não distingue a verdade, apesar de estar ela à nossa vista.

 Para mim era importante que aquele homem conhecesse minhas palavras e meus trabalhos. Se ele os aprovasse, me entusiasmaria ainda mais por ele; mas se os reprovasse, meu coração fútil e vazio de tua firmeza, se lastimaria. Contudo, meu prazer era pensar e refletir no problema do belo e do conveniente, assunto do livro que lhe dedicara, admirando-o na minha imaginação, mesmo que ninguém mais o louvasse.

## CAPÍTULO XV

### Os primeiros livros

 Mas não atinava com a chave de tuas artes em tão grandes obras, ó Deus onipotente, único criador de maravilhas. Vagava minha alma pelas formas corpóreas, e definia o belo como o que agrada por si mesmo, e o conveniente como o que agrada por sua acomodação a outra coisa, e apoiava essa distinção com exemplos tomados dos corpos.

 Daqui passei à natureza da alma, mas o falso conceito que tinha das coisas espirituais não me permitia perceber a verdade. A própria força da verdade saltava-me aos olhos, mas logo eu afastava da realidade incorpórea meu espírito inquiridor, voltando-me para as figuras, as cores e as grandezas materiais. E como não podia ver nada semelhantes na alma, julgava que tampouco seria possível ver minha alma.

 Mas, como eu amava a paz da virtude, e aborrecia a discórdia do vício, notava naquela certa unidade e neste certa desunião; parecia-me que residisse nessa unidade a alma racional, a essência da verdade e do sumo bem. Na desunião, via eu não sei que substância de vida irracional e a natureza do sumo mal, que não era apenas substância, mas também verdadeira vida. Todavia não procedia de ti, meu Deus, de quem procedem todas as coisas. E chamava àquela unidade mônada, como alma sem sexo, e a esta multiplicidade díada, como a ira nos crimes, a concupiscência nas paixões, sem saber o que dizia. Ignorava então, ainda não havia aprendido que o mal não é substância alguma, nem que nosso espírito não é o bem soberano e imutável.

 Assim como se cometem crimes quando o movimento do espírito é vicioso e se atira insolente e turbulento, e se cometem infâmias quando o afeto da alma, fonte dos prazeres carnais, é imoderado, assim os erros e falsas opiniões contaminam a vida se a alma racional está viciada, como estava a minha então. Ignorava que ela deveria ser ilustrada por outra luz para participar da verdade, por não ser da mesma essência da verdade, porque tu, Senhor, alumiarás minha lâmpada; tu, meu Deus, iluminarás minhas trevas, e todos participamos de tua plenitude, porque és a luz verdadeira que ilumina a todo homem que vem a este mundo, e porque em ti não há mudança nem a momentânea obscuridade.

 Eu me esforçava para me aproximar de ti, mas tu me repelias para que experimentasse a morte, pois resistes aos soberbos. E que maior soberba haveria que afirmar, com inaudita loucura, que eu era da mesma natureza que tu? Porque, sendo eu mutável, e reconhecendo-me tal – pois, se queria ser sábio, era para fazer-me de menos para mais perfeito – preferia, contudo, julgar mutável a ti do que não ser o que tu és. Eis aqui por que era repelido, e por que resistias à minha soberba cheia de vento.

 Eu não imaginava mais que formas corpóreas; carne, acusava a carne; espírito errante, não conseguia voltar para ti, nem em mim, nem nos corpos; não eram sugeridas por tua verdade, mas imaginadas por minha vaidade, de acordo com os corpos. E dizia aos pequeninos teus fiéis concidadãos, dos quais eu, ignaro, ainda exilado, dizia-lhes eu, tagarela inepto: "Por que a alma, criatura de Deus, se engana?" Mas não queria que dissessem: "E por que Deus se engana?" E defendia antes que tua substância imutável era obrigada a errar, para não confessar que a minha, mutável, se desencaminhara espontaneamente, ou que era castigada pelo erro.

 Teria eu vinte e seis ou vinte e sete anos quando escrevi essas coisas, revolvendo dentro de mim apenas imagens corporais, cujo ruído aturdia os ouvidos do meu coração. Buscava eu aplicá-los – ó doce verdade – à tua melodia interior, quando meditava sobre o belo e o conveniente. Meu desejo era estar diante de ti, e ouvir tua voz, e alegrar-me intensamente com a voz do esposo, mas não o podia, porque o alarido do meu erro me arrebatava para fora e, sob o peso de minha soberba, caía no abismo. Pois ainda não davas gozo e alegria a meus ouvidos, nem exultavam meus ossos, porque ainda não haviam sido humilhados.

## CAPÍTULO XVI

### As dez categorias de Aristóteles

 E que lucro me trazia, tendo eu vinte anos de idade, mais ou menos, e chegando-me às mãos a obra de Aristóteles, intitulada As Dez Categorias – que meu mestre, o retórico de Cartago, e outros, considerados doutos, citavam com grande ênfase e ponderação, fazendo-me suspirar por ela como por algo grandioso e divino – de que me servia ler essa obra e compreendê-la sozinho? Falando com outros, que afirmavam ter conseguido entendê-la só por meio de mestres eruditíssimos, que lha haviam explicado não apenas com palavras, mas também com figuras pintadas na areia, nada me souberam dizer que eu já não tivesse entendido em minha leitura particular.

 Parecia-me que essa obra falava com muita clareza das substâncias, como o homem, e das coisas que nelas se encerram, como a forma do homem; a estatura, quantos pés mede; o parentesco, de quem é irmão; onde se encontra, quando nasceu; se está de pé, sentado, calçado ou armado; se faz alguma coisa ou se padece de alguma coisa, e, enfim, uma infinidade de relações que se contêm nestes nove gêneros, dos quais citei alguns exemplos, ou no próprio gênero da substância, que são também inumeráveis os que encerra.

 De que me aproveitava tudo isso, se até me prejudicava? Julgando que naqueles dez predicamentos se achavam compreendidas, de modo absoluto, todas as coisas, esforçava-me por compreender também a ti, meu Deus, Ser maravilhosamente simples e imutável, como se fosses subordinado à tua grandeza e formosura, como se estas estivessem em ti como em seu sujeito, como se fosses um corpo; tua grandeza e beleza são porém uma mesma coisa contigo, ao contrário dos corpos, que não são grandes ou belos por serem corpos, pois, embora fosses menores e menos belos, nem por isso deixariam de ser corpos.

 Era pois falso o que pensava de ti, e não verdade; ilusões de minha miséria, e não representação sólida de tua beleza. Havias ordenado, Senhor, e assim se cumpria em mim tua vontade, que a terra me produzisse abrolhos e espinhos, e que eu só conseguisse meu pão à custa de trabalho.

 De que me aproveitava também ler e compreender por mim mesmo todos os livros que pude ter nas mãos sobre as artes chamadas liberais, se eu era então escravo de minhas más inclinações? Comprazia-me em sua leitura, sem atinar de onde vinha quanto de verdadeiro e certo achava neles; eu estava de costas para a luz, e o rosto, para os objetos iluminados, e por isso meus olhos, que os viam iluminados, não recebiam luz.

 Tu sabes, Senhor, meu Deus, como sem ajuda de mestre, aprendi tudo o que li, quanto às leis da retórica, da dialética, da geometria, da música e da matemática, porque também a vivacidade da inteligência e a agudeza da intuição são dons teus. Mas não te oferecia por eles sacrifício algum, e por isso causavam-me mais dano do que proveito. Insisti em me apoderar da melhor parte da minha herança, e não guardei em ti minha força, mas afastei-me de ti para uma região longínqua, a fim de dissipá-la entre as meretrizes de minhas paixões.

 De que me serviam dons tão preciosos, se não usava bem deles? Só compreendi que aquelas artes eram tão difíceis de entender, mesmo para os estudiosos e sábios, quando me esforçava para expô-las: entre eles, o mais destacado era o que me compreendia menos vagarosamente.

 Mas qual o fruto disso, se eu te concebia, Senhor meu Deus, ó Verdade, como um corpo luminoso e infinito, e eu como uma parcela desse corpo? Que rematada perversidade! Assim era eu; não me envergonho agora, meu Deus, de confessar tuas misericórdias para comigo, e de te invocar, já que não me envergonhei então de proferir ante os homens tais blasfêmias e de ladrar contra ti. De que me aproveitava, repito, a inteligência ágil para entender aquelas ciências, e para explicar com clareza tantos livros complicados, sem que ninguém mos houvesse explicado, se errava monstruosamente na piedade com sacrílega torpeza? E que prejuízo sofriam teus pequeninos em serem de menor inteligência, se não se afastavam de ti, para que, seguros no ninho da tua Igreja, se cobrissem de penas, e lhes alimentassem as asas da caridade com o sadio alimento da fé?

 Ó Deus e Senhor nosso! Esperemos, ao abrigo de tuas asas; protege-nos, leva-nos! Tu levarás os pequeninos, e até escarnecidos tu os levarás, nossa firmeza só é firmeza quando está em ti; mas quando depende de nós, então é debilidade. Nosso bem vive sempre em ti, e somos perversos porque nos afastamos de ti. Voltemos já, Senhor, para não nos aniquilarmos, porque em ti vive nosso bem, sem deficiência alguma; sem medo de não o encontrar quando voltarmos para nossa origem e, embora ausentes, nem por isso desaba nossa casa, tua eternidade.

# LIVRO QUINTO

## CAPÍTULO I

### Oração

 Recebe, Senhor, o sacrifício de minhas Confissões por meio da minha língua, que tu formaste e impeliste a confessar teu nome. Cura todos os meus ossos, e que eles proclamem: Senhor, quem haverá semelhante ai ti? Na verdade, quem se dirige a ti, nada te informa do que ocorre em si, porque não há coração fechado que se possa subtrair a teu olhar, nem dureza de homem que possa repelir tua mão. Ao contrário, a abrandas quando queres, ou para compadecerte, ou para castigar; não há quem se esconda de teu calor. Mas, que minha alma te louve para que te ame, a confesse tuas misericórdias para que te louve. Toda a criação não cala teus contínuos louvores, nem os espíritos todos, com sua boca voltada para ti, nem os animais e coisas corporais, pela boca dos que os contemplam. Assim, apoiando-se em tua criação, nossa alma se levanta de sua franqueza, e chega a ti, seu admirável criador, onde encontrará rejuvenescimento e verdadeira fortaleza.

## CAPÍTULO II

### Os que fogem de Deus

 Afastem-se e fujam de ti os irrequietos e os pecadores. Tu os vês e distingues suas sombras. E eis que, apesar deles, todas as continuam belas; somente eles são feios. E que damos te poderiam causar? Ou em que poderia desonrar teu império, justo e íntegro desde os céus até as coisas mais ínfimas? E para onde fugiram, ao fugir de tua presença? E em que lugar não os encontrarás? Fugiram, sim, para não ver-te a ti, que os estás vendo, mas deparam contigo, que não abandonas nada do que criaste; tropeçaram contigo, injustos, e justamente são castigados; subtraindo-se á tua brandura, ofenderam tua santidade, e caíram sob teus rigores. Evidentemente eles ignoram que estás em toda parte, que nenhum lugar te limita, e que só tu estás presente mesmo nos que se afastam de ti.

 Que se convertam, pois, e te busquem, porque não abandonas tua criatura, como elas abandonaram a seu Criador. Que se convertam, e logo estarás em seus corações, nos corações dos que te confessam, dos que se lançam em ti, dos que choram em teu regaço depois de percorrerem penosos caminhos. E tu, bondoso, enxugarás suas lágrimas; e chorarão ainda mais, mas serão felizes por chorar, porque és tu, Senhor, e nenhum homem de carne e sangue, tu, Senhor, que os criaste, que os consolas e robusteces.

 E onde estava eu quando te buscava? Certamente, estavas diante de mim, mas eu me havia afastado de mim mesmo, e não me encontrava, e muito menos de ti!

## CAPÍTULO III

### Fausto e o maniqueísmo

 Falarei, na presença de meu deus, do ano vigésimo-nono de minha vida. Já havia chegado a Cartago um dos bispos maniqueus, chamado Fausto, grande laço do demônio, no qual caíam muitos pelo encanto sedutor de sua eloqüência. Apesar de ser exaltada por mim, eu a sabia contudo discernir das verdades que desejava conhecer. Não era o prato do estilo que eu considerava, mas o alimento doutrinal que nele me era servido por aquele famoso Fausto, tao reputado entre os seus.

 Antecedera-o a fama de homem erudito em toda espécie de ciência, e particularmente instruído nas artes liberais. E como eu tinha lido muitas teorias dos filosofo, e as guardava na memória, quis comparar algumas destas com as grandes fábulas do maniqueísmo. Pareciam-me mais prováveis as doutrinas daqueles que chegaram a conhecer a ordem do mundo, embora não tivessem encontrado a seu Criador. Porque tu és grande, Senhor, e pondes os olhos nas coisas humildes, e as elevadas as conheces de longe, e não te aproximas senão dos contritos de coração. Nem és encontrado pelos soberbos, ainda que sua curiosa perícia seja capaz de contar as estrelas do céu e as areias do mar; seja capaz de medir as regiões do céu e de investigar o curso dos astros.

 Com a inteligência e o engenho que lhes deste investigam os segredos do mundo, e descobriram muitos deles; predisseram com muitos anos de antecedência os eclipses do sol e da lua, no dia e hora em que hão de suceder, sem que nunca lhes falhasse o cálculo, acontecendo sempre tal e como haviam anunciado. Deixaram ainda por escrito as leis por eles descobertas, as quais ainda hoje se lêem, e de acordo com elas se prediz em que ano, e em que mês do ano, e em que dia do mês, e em que hora do dia, e em que parte de sua luz se hão de eclipsar o sol e a lua; e tudo acontece como está predito.

 Admiram-se disto os ignorantes, e pasmam. Os sábios gloriam-se disso, e se desvanecem, e com ímpia soberba afastam-se e se eclipsam de tua luz. E, prevendo com exatidão o eclipse vindouro do sol, não vêem o seu, que já está presente. Não procuram religiosamente saber de onde lhes vem o talento com que investigam essas coisas e, achando que tu as criaste, não se entregam a ti, para que conserves o que lhes deste, nem se te oferecem em sacrifício, como se tivessem feito a si mesmos; nem dão morte às suas soberbas, que alçam vôo como aves do céu; nem às suas insaciáveis curiosidades que, como peixes do mar, passeiam pelas secretas sendas do abismo; nem às suas luxúrias, que os igualam aos animais do campo, a fim de que tu, ó Deus, fogo devorador, destruas estas suas preocupações de morte, e os torne a criar para uma vida imortal.

 Mas não conheceram o caminho, o teu Verbo, por quem fizeste as coisas que numeram, e a eles próprios que as numeram, e os sentidos com que percebem as coisas que numeram, e a mente graças à qual as numeram. Tua sabedoria escapa aos números. Teu Filho Unigênito se fez para nós sabedoria, justiça e santificação, e foi contado entre nós, e pagou tributo a César. Não conheceram este caminho, por onde desceriam de seu orgulho até ele, e por ele subiriam até ele; não conheceram, digo, este caminho, e se julgaram mais elevados e resplandecentes que estrelas, e assim vieram a rolar por terra, e seu coração insensato se obscureceu.

 Dizem muitas coisas verdadeiras acerca das criaturas; mas, como não procuram piedosamente a Verdade, isto é, o autor da Criação, não o encontram; e, se o encontram reconhecendo-o por Deus, não o honram como a Deus, nem lhe dão graças. Antes, se desvanecem em seus pensamentos, e se dizem sábios, atribuindo a si próprios o que é teu. Atribuem a ti, com perversa cegueira, suas mentiras, a ti, que és a própria Verdade; alteram a glória de um Deus incorruptível, concebendo-a à semelhança e imagem do homem corruptível, das aves, dos quadrúpedes, das serpentes. E convertem tua verdade em mentira, e adoram e servem antes à criatura do que ao Criador.

 Eu porém guardava muitas de suas opiniões verdadeiras acerca das criaturas, cuja explicação encontrava nos números, na ordem dos tempos e no testemunho visível dos astros; comparava-as com os ensinamentos de Manés, que escreveu sobre essas matérias numerosas e delirantes loucuras, sem achar nenhuma explicação para os solstícios e equinócios, os eclipses do sol e da lua, e para outras coisas, enfim, das quais tomara conhecimento pelos livros da sabedoria profana.

 Contudo, exigia-me que acreditasse nessas doutrinas, embora não concordassem absolutamente com meus cálculos e com o que meus olhos testemunhavam.

## CAPÍTULO IV

### Ciência e ignorância

 Senhor, Deus da verdade, acaso te agradará quem conhecer essas coisas? Infeliz do homem que, conhecendo-a todas, te ignora ti; mas feliz de quem te conhece, embora as ignore! Quanto ao que conhece a ti e a elas, este não é mais bem-aventurado por causa de seu saber, mas só é feliz por ti, se, conhecendo-te, te glorifica como Deus, e te dá graças, e não se desvanece em seus pensamentos.

 É melhor aquele que reconhece estar na posse de uma árvore e te dá graças por sua utilidade, embora ignore quantos côvados tem de altura e de largura, que o que a mede, e conta todos os seus ramos, mas não a possui, nem conhece, nem ama a seu Criador. Assim o homem fiel, a quem pertencem todas as riquezas do mundo, e que, nada possuindo, possui tudo, por estar unido a ti, a quem servem todas as coisas – embora desconheça até o curso das estrelas da Ursa – e seria insensatez duvidar – é certamente melhor do que o que mede os céus, conta as estrelas e pesa os elementos, mas despreza a ti, que dispuseste todas as coisas em número, peso e medida.

## CAPÍTULO V

### Loucuras de Manés

 Mas, quem pediu a esse Manés que escrevesse sobre coisas cujo conhecimento não é necessário à piedade? Tu disseste ao homem: Vê que a piedade é a sabedoria. Manés podia muito bem ignorar essa piedade ainda que fosse muito instruído nas ciências profanas. Mas, como não as conhecia, e se atrevia desavergonhadamente a ensiná-las, de nenhum modo conhecia a piedade. Pois certamente é vaidade alardear conhecimentos humanos, mesmo verdadeiros, e é piedade confessar-te a ti. Manés, afastando-se dessa regra, falou tanto sobre essas coisas que foi convencido de sua ignorância pelos que as conhecem bem. Donde se viu-se claramente o crédito que merecia em matérias mais obscuras. Ele não queria ser pouco estimado; empenhou-se em convencer aos demais que tinha em si, pessoalmente, e na plenitude de seu poder, o Espírito Santo, que consola e enriquece teus fiéis. Surpreendido em erro ao falar do céu, das estrelas, e do curso do sol e da lua, embora tais coisas não pertençam à religião, claramente deixou ver ser sacrílego seu atrevimento ao ensinar coisas que ignorava e também falsas, e isso com tão insano orgulho a ponto de atribuí-las à pretensa divindade de sua pessoa.

 Quando pois ouço que este ou aquele irmão em Cristo ignora esses problemas, e confunde uma coisa com outra, suporto com paciência seu modo de opinar. Nada vejo que possa ser-lhe prejudicial enquanto não fizer idéia indigna de ti, Senhor, criador do universo, mesmo que ignore até o lugar e a natureza das coisas materiais. O mal seria acreditar que esses problemas pertencem à essência da piedade, e tenazmente atrever-se a afirmar o que ignora. Mas ainda essa fraqueza é suportada nos primórdios da fé pela mãe caridade, até que o homem novo cresça e se transforme em varão perfeito, e não possa ser abalado por qualquer vento de doutrina.

 Quanto a Manés, que se atreveu a se fazer de doutor, de mestre, de guia e cabeça daqueles a quem convertera, de tal forma que os que o seguiam acreditassem seguir não um homem qualquer, mas teu Espírito Santo, quem não julgaria que tão rematada loucura, uma vez demonstrada sua falácia, deveria ser detestada e afastada para bem longe?

 Contudo, eu ainda não estava certo se o que havia lido em outros livros, sobre as mudanças dos dias e das noites, uns mais longos, outros mais curtos, e sobre o suceder-se dos dias e das noites, e dos eclipses do sol e da lua, e outros fenômenos semelhantes, poderiam ser explicados conforme sua doutrina. Caso isso fosse possível, eu ainda ficaria em dúvida quanto ao modo por que se realizariam esses fenômenos; eu anteporia a autoridade de Manés à minha fé, pois o tinha então em conta de santo.

## CAPÍTULO VI

### A eloqüência de Fausto

 Durante os quase nove anos em que meu espírito errante deu ouvidos aos maniqueus, esperei ansiosamente a vinda de Fausto. Os demais adeptos, com os quais me encontrava casualmente, embaraçados com as objeções que eu lhes fazia, remetiam-me a ele que, à sua chegada, com uma simples entrevista resolveria facilmente todas aquelas dificuldades, e ainda outras maiores que me ocorressem, de maneira claríssima.

 Logo que chegou, pude notar que se tratava de um homem simpático, de fala cativante, e que expunha os temas comuns dos maniqueus, mas com muito mais agrado que eles. Mas, que interessava à minha sede este elegante copeiro de copos preciosos? Eu já tinha os ouvidos fartos daquelas teorias, e nem me pareciam melhores por serem expostas em melhor estilo, nem mais verdadeiras pela elegância de suas formas; nem eu considerava Fausto mais sábio por ter o rosto de mais graça e sua linguagem mais finura. Aqueles que mo haviam recomendado não eram bons juizes: tinham Fausto como homem sábio e prudente somente porque lhes agradava sua facúndia. Diferentes de outra espécie de homens que conheci, que tinham como suspeita a verdade, e não se lhe renderiam se lhes fosse apresentada com linguagem elegante e verbosa.

 Mas eu, meu Deus, nessa época já tinha aprendido de ti, por caminhos ocultos e admiráveis – e creio que eras tu que me ensinavas, porque era verdade, e ninguém pode ser mestre da verdade senão tu, seja qual for a instância e modo dela brilhar – já havia aprendido de ti que não se deve ter por verdadeiro um pensamento porque expresso eloquentemente nem falso porque é dito com rudeza; e que, pelo contrário, um pensamento não é verdadeiro por ser enunciado com simplicidade, nem falso porque sua expressão é elegante; a sabedoria e a ignorância são como alimentos, proveitosos ou nocivos, e as palavras, elegantes ou rudes, como pratos preciosos ou toscos, nos quais se podem servir a ambos.

 A ânsia com a qual por tanto tempo esperara por Fausto, deleitava-se enfim com o ardor e a vivacidade de suas disputas, com os termos apropriados e a facilidade com que lhe vinham à boca para adornar seu pensamento. Deleitava-me, certamente, e eu o louvava e exaltava com os outros, e muito mais ainda do que eles.

 Contudo, na reunião dos ouvintes, me aborrecia não poder apresentar-lhe minhas dúvidas, e dividir com ele os cuidados de meus problemas, conferindo com ele minhas dificuldades em forma de perguntas e respostas. Quando, enfim, o pude fazer, acompanhado de meus amigos, comecei a falar-lhe em ocasião e lugar oportunos para tais discussões, apresentando-lhe algumas objeções das que mais me preocupavam. Vi então que se tratava de homem completamente ignorante das artes liberais, com exceção da gramática, que conhecia de modo superficial. Contudo como havia lido alguns discursos de Cícero, e pouquíssimos livros de Sêneca, alguns poemas e livros da seita, escritos em bom latim e com arte, e como se exercitava todos os dias em falar, adquirira grande facilidade de expressão, que ele tornava mais agradável e sedutora com o bom emprego de seu talento e certa graça natural.

 Não é assim como estou contando, meu Senhor e meu Deus, juiz de minha consciência? Diante de ti estão meu coração e minha memória, e que já então guiavas no segredo oculto de tua providência, pondo diante de meus olhos meu erros vergonhosos, para que os visse e odiasse.

## CAPÍTULO VII

### Desilusão

 Por isso, logo que reconheci sua ignorância naquelas ciências em que o julgava grande conhecedor, comecei a desesperar de que me pudesse esclarecer e resolver as dificuldades que me preocupavam. É bem verdade que ele podia ignorar tais coisas e possuir a verdadeira piedade, contanto que não fosse maniqueísta. Seus livros estão cheios de fábulas intermináveis acerca do céu e dos astros, do sol e da lua, que eu já não esperava, mas que pudesse explicar tão argutamente como eu o desejava, comparando-as com os cálculos matemáticos que eu lera em outras partes, para ver se deveria preferir o que diziam os livros de Manés, ou se, pelo menos, estes apresentavam demonstrações de igual valor.

 Mas, quando apresentei minhas dificuldades à sua consideração e crítica, com grande modéstia, não se atreveu a tomar sobre si tal encargo, pois certamente sabia que ignorava o assunto e não se envergonhava de confessá-lo. Não pertencia à classe de charlatães que me vi obrigado muitas vezes a suportar, que pretendiam ensinar-me tais coisas, mas não me diziam nada. Este, pelo menos, tinha coração, senão dirigido a ti, pelo menos não era incauto consigo mesmo. Não ignorava totalmente sua ignorância, razão pela qual não quis meter-se temerariamente em questões de onde não pudesse sair, ou de mui difícil retirada. Por isso mesmo cresceu aos meus olhos, por ser a modéstia de uma alma que se conhece muito mais bela que o saber que eu desejava; e em todas as questões mais difíceis e sutis o encontrei sempre com igual ânimo.

 Esfriado pois meu entusiasmo pelos livros de Manés, e muito mais desconfiado dos outros doutores maniqueus, depois que este, tão renomado, se me havia mostrado tão ignorante em muitas das questões que me inquietavam, continuei a tratar com ele, mas por causa de sua paixão pelas letras, que eu ensinava então aos jovens de Cartago. Lia com ele os livros que desejava conhecer por ter ouvido falar deles, ou os que eu considerava apropriados à sua inteligência.

 Quanto ao mais, todo o empenho que eu havia posto em progredir na seita desapareceu por completo tão logo conheci este homem, mas não a ponto de me separar definitivamente dela. De fato, não achando na ocasião caminho melhor que aquele por onde cegamente me lançara, resolvi continuar provisoriamente na mesma, até que tivesse a fortuna de encontrar algo melhor e preferível. Foi assim que aquele Fausto, que havia sido para muitos laço de morte, começava involuntária e inconscientemente a desfazer o laço que me enredara. É que tuas mãos, meu Deus, no segredo de tua providência, não abandonavam minha alma; e minha mãe, dia e noite, não deixava de te oferecer em sacrifício por mim o sangue de seu coração, na forma de suas lágrimas.

 E tu, Senhor, agiste comigo de modo admirável, pois isso foi obra tua, meu Deus. Porque o Senhor é quem dirige os passos do homem e quem inspira seu caminho. E quem poderá dar-nos a salvação, senão tua mão, que restaura o que fez?

## CAPÍTULO VIII

### Viagem a Roma

 Também foi obra tua o fato de me convencerem a ir a Roma, para ali lecionar o que ensinava em Cartago. Mas não deixarei de confessar-te o motivo que me moveu, porque também nisso tudo se reconhece a profundidade de teu desígnio, e merece ser meditada e exaltada tua misericórdia sempre presente. O motivo que me levou a Roma não foram maiores lucros e maior dignidade, como me prometiam os amigos que tal me aconselhavam – se bem que essas razões ainda fossem importantes para mim nesse tempo – mas o principal e quase único motivo de minha determinação era saber que os jovens de Roma eram mais sossegados nas classes, em virtude da rigorosa disciplina a que estavam sujeitos. Não lhes era lícito entrar desordenada e impudentemente nas aulas dos professores dos quais não eram alunos, nem sequer eram admitidos sem licença; bem o contrário do que acontecia em Cartago, onde a liberdade dos estudantes é tão vergonhosa e destemperada que invadem cínica e furiosamente as aulas, perturbando a ordem estabelecida pelos mestres em seu próprio interesse. Além disso, com incrível insolência cometem uma quantidade de grosserias, que deveriam ser castigadas pelas leis, se a tradição não os protegesse. Tal costume aliás, apenas manifesta a infelicidade no caso desses jovens, que já praticam como lícito o que jamais será permitido por tua lei eterna. Julgam agir impunemente, quando a própria cegueira é seu maior castigo, padecendo eles males incomparavelmente maiores do que os que causam aos outros.

 Com isso vi-me obrigado, quando professor, a suportar nos outros costumes que não quis adotar como meus quando estudante; e por isso desejava ir para uma cidade na qual, segundo me asseguravam, não aconteciam tais coisas. E tu, Senhor, minha esperança e meu quinhão na terra dos vivos, a fim de que eu mudasse de residência para a saúde de minha alma, me punhas espinhos em Cartago, para arrancar-me dali, e deleites em Roma para atrair-me para lá. Atraíasme por meio de homens que amavam uma vida morta, dos quais uns agiam aqui como loucos, e outros me aliciavam alhures com bens ilusórios. E, para corrigir meus passos, usavas ocultamente da sua e da minha perversidade. Porque os que perturbavam minha paz estavam cegos por uma raiva vergonhosa, e os que me convidavam para mudar sabiam a terra; e eu, que detestava em Cartago uma verdadeira miséria, buscava em Roma uma falsa felicidade.

 Mas o verdadeiro motivo de eu sair de Cartago e ir para Roma só tu, ó Deus, o sabias, sem manifestá-lo a mim nem à minha mãe, que chorou amargamente minha partida, seguindo-me até o mar. Mas tive de enganá-la, porque me agarrava com força, instando-me a desistir de meu propósito ou a levá-la comigo. Fingi pois que tinha que me despedir de um amigo que eu não queria abandonar, até que, soprando o vento, ele pudesse navegar. Assim enganei a minha mãe, e a uma tal mãe! Fugi, e tu também me perdoaste este pecado misericordiosamente, salvando-me a mim, cheio de execráveis imundícies, das águas do mar para que chegasse ás águas de tua graça. Purificado com elas, secariam os rios dos olhos de minha mãe, com que todos os dias regava a terra diante de ti, por minha causa.

 Contudo, como se recusasse a voltar sem mim, apenas pude persuadi-la a permanecer aquela noite em uma capela próxima a nosso navio, consagrada à memória de São Cipriano. Mas naquela mesma noite parti às escondidas, deixando-a orar e a chorar. E que te pedia ela, meu Deus, com tantas lágrimas, senão que me impedisses de navegar? Mas tu, de visão infinitamente mais ampla, entendendo o intuito de seu desejo, não atendeste ao que ela então te pedia, para fazer em mim aquilo que sempre te pedia.

 Soprou o vento, enfunou nossas velas, e logo desvaneceu de nosso olhar a praia, onde de manhã cedo minha mãe, louca de dor, enchia de queixas e de prantos teus ouvidos insensíveis. Deixaste-me correr atrás de minhas paixões para dar fim ás minhas concupiscências, castigando com o justo flagelo da dor a saudade demasiado carnal de minha mãe. Ela, como todas as mães, e ainda mais que a maioria delas, desejava manter-me junto de si, desconhecendo as grandes alegrias que lhe preparavas com minha ausência. Não o sabia, e por isso chorava e se lamentava, denunciando com esses lamentos a herança que recebera de Eva, buscando em lágrimas ao que com gemidos havia dado à luz.

 Por fim, depois de ter-me chamado de mentiroso e de mau filho, pôs-se de novo a rezar por mim e voltou para sua vida habitual, enquanto eu me dirigia a Roma.

## CAPÍTULO IX

### Enfermo

 Em Roma fui colhido pelo flagelo de uma doença corporal, que esteve a ponto de me mandar para a sepultura, carregado de todos os pecados cometidos contra ti, contra mim e contra o próximo; pecados numerosos e pecados, que se somavam à cadeia do pecado original, pelo qual todos morremos em Adão. Ainda não me tinhas perdoado nenhum deles em Cristo, nem ele havia apagado com sua cruz as inimizades que contraíra contigo com meus pecados. E como poderia ele desfazê-los por uma cruz de onde eu não via pender mais que um fantasma? Porque tão falsa me parecia a morte de sua carne como verdadeira a morte de minha alma, e tão verdadeira a morte de sua carne como falsa a vida de minha alma, que disto se não persuadia. Entretanto, agravando-se as febres, eu estava a ponto de partir e de perecer. Para onde iria eu, se então tivesse que morrer, senão para o fogo e tormentos merecidos por minhas ações, de acordo com a justa ordem por ti estabelecida? Minha mãe tudo ignorava, mas, ausente, orava por mim, e tu, presente em todas as partes onde ela estava, lhe dava ouvidos; exercias tua misericórdia para comigo onde eu estava, restituindo-me a saúde do corpo, ainda que meu coração sacrílego continuasse doente. Nem mesmo estando em tão grande perigo desejei teu batismo. Quando menino eu era melhor, porque então o solicitei à piedade de minha mãe, como já recordei e confessei. Mas, para minha vergonha, eu havia crescido e, em minha loucura, zombava dos remédios de tua medicina, que não me deixou morrer duplamente em tal estado.

 Se o coração de minha mãe fosse transpassado por essa ferida, nunca haveria de sarar. Minha eloqüência não é suficiente para descrever o grande amor que me dedicava, e a que ponto seus cuidados para me gerar em espírito eram piores que os que suportava quando me concebeu pela carne.

 Por isso, não vejo como poderia sarar se minha morte em tal estado tivesse ferido as entranhas de seu amor. E onde estariam tantas orações, continuamente repetidas? Estariam em ti, somente em ti. Seria possível que tu, Deus de misericórdia, desprezasses o coração contrito e humilhado de uma viúva casta e sóbria, que frequentemente dava esmolas e servia obsequiosa a teus santos? Que em nenhum dia deixava de levar sua oferenda a teu altar? Que ia duas vezes por dia – de manhã e à tarde – à tua igreja, sem faltar jamais, e não para entreter-se em vãs conversas e cochichos de velhas, mas para te ouvir as palavras e para que a ouvisses em suas orações? Poderias desprezar as lágrimas de uma mãe que não te pedia nem ouro, nem prata, nem bem algum terreno e frágil, mas a salvação da alma de seu filho? Poderias, ó Deus, a quem ela devia tudo o que era, poderias desprezá-la e negar-lhe teu auxílio? De nenhum modo, Senhor; pelo contrário, tu a assistias, e a escutavas, mas pelo caminho determinado por tua providência.

 Como poderias enganá-la naquelas visões e respostas, de algumas das quais já falamos, e de outras que passo em silêncio, que ela guardava em seu coração fiel, e que te apresentava em suas orações contínuas como compromissos assinados por tua mão, e que irias cumprir. Porque, por tua misericórdia infinita, gostas de te fazer devedor daqueles a quem perdoas todas as dívidas.

## CAPÍTULO X

### Agostinho e os erros dos maniqueus

 Restabeleceste-me, pois, daquela doença, e então salvaste o filho de tua serva quanto ao corpo a fim de poder, salvá-lo melhor e mais firmemente. Em Roma juntei-me ainda com os que se diziam "santos", falsos e enganadores. E não só convivia com os ouvintes, entre os quais se contava o dono da casa em que eu adoecera e convalescera – mas também com os que se chamam "eleitos".

 Ainda então me parecia que não éramos nós que pecávamos, mas não sei que estranha natureza que pecava em nós; por isso minha soberba se deleitava em me ter como isento de culpa, e portanto de todo desobrigado a confessar meu pecado, quando agia mal, para que pudesses curar minha alma que te ofendia. Antes, gostava de me desculpar, acusando a não sei que ser estranho que estava em mim, mas que não era eu. Na verdade, eu era tudo aquilo, embora minha impiedade me tivesse dividido contra mim mesmo. E o mais incurável de meu pecado era justamente o não me considerar pecador, preferindo, minha execrável iniqüidade, que fosses vencido em mim, para minha perdição, ó Deus onipotente, a que vencesses minha alma para minha salvação. Ainda não tinhas posto guarda diante da minha boca, nem porta de proteção ao redor de meus lábios, a fim de que meu coração não se inclinasse para as más palavras, nem buscasse desculpas para seus pecados, como os homens prevaricadores. Eis a razão pela qual eu ainda mantinha relações de amizade com os eleitos dos maniqueus. Mas, desesperado de poder progredir para a verdade dentro daquela falsa doutrina, contentava-me a segui-la até encontrar algo melhor, professando-a já com mais liberdade e frouxidão.

 Nesse tempo, veio-me à mente a idéia de que os filósofos chamados acadêmicos haviam sido mais prudentes que os outros, por sustentarem que se deve duvidar de tudo, e que nenhuma verdade pode ser compreendida pelo homem. Julguei então que era esse o seu pensamento, como geralmente se crê, não tendo ainda compreendido suas verdadeiras intenções.

 Quanto a meu hospede, não me furtei de admoestar sua excessiva credulidade com que aceitava as fábulas de que estavam cheios os livros dos maniqueus. Todavia, tinha mais amizade com tais homens do que com os estranhos à sua heresia. É verdade que já não a defendia com a antiga animosidade; mas sua familiaridade – em Roma havia muitos deles ocultos – tornava-me bastante negligente para procurar outra coisa. Desesperava eu principalmente de poder achar a verdade em tua Igreja, ó Senhor dos céus e da terra, Criador de todas as coisas visíveis e invisíveis, verdade da qual eles me afastavam. Parecia-me mui torpe acreditar que tinhas figura de carne humana, e que estavas limitado pelos contornos de um corpo como o nosso. E quando queria pensar em meu Deus, não o sabia imaginar senão com massa corpórea – pois não me parecia que pudesse existir algo diferente – esta era a causa principal e quase única de meu erro inevitável.

 Daqui se gerou também minha crença de que o mal tivesse substância, também corpórea, massa negra e disforme, ora espessa – a que chamavam terra – ora tênue e sutil, como o ar, a qual julgava ser um espírito maligno que investia sobre a terra. E visto que minha piedade, por pouca que fosse me obrigava a pensar que um Deus bom não podia criar nenhuma natureza má, eu imaginava duas substâncias antagônicas, ambas infinitas, a do mal um pouco menor, a do bem um pouco maior; e deste princípio pestilencial originavam-se as demais blasfêmias. Com efeito, quando meu espírito se esforçava por voltar à fé católica, era rechaçado porque minha idéia de fé católica não era correta. E me parecia ser mais piedoso, ó Deus, a quem louvam em mim tuas misericórdias, julgar-te infinito por todas as partes, com exceção de um aspecto, a substância do mal, onde era forçoso reconhecer teus limites, do que julgar-te limitado por todas as partes pelas formas do corpo humano.

 Também tinha como melhor admitir que não havias criado nenhum mal – o qual aparecia à minha ignorância não só como substância, mas como substância corpórea, por eu não poder conceber o espírito senão como corpo sutil difundido pelos espaços – do que crer que a natureza do mal, tal como a imaginava, procedesse de ti.

 Também supunha que nosso Salvador, teu Filho Unigênito, houvesse surgido, para nos salvar, dessa substância luzidíssima de teu corpo. A seu respeito, nada aceitava senão o que me sugeria minha louca imaginação. E por isso julgava que tal natureza não podia nascer da Virgem Maria sem se ajuntar com a carne, mas não via como poderia juntar-se à carne sem se corromper; por isso tinha medo de acreditar em sua encarnação, para não me ver obrigado a julgá-lo corrompido pela carne.

 Sem dúvida agora teus fiéis irão sorrir, branda e amorosamente, se lerem estas minhas confissões; mas eu, realmente, era assim.

## CAPÍTULO XI

### Desculpas dos maniqueus

 Além de tudo, eu já não estava convencido que se pudessem defender os pontos que os maniqueus criticavam em tuas Escrituras. Todavia, desejava por vezes discutir com sinceridade cada um desses pontos com algum varão, grande conhecedor de seus livros, para lhe indagar a opinião. Quando ainda em Cartago, já me despertara o interesse o discurso de um tal Elpídio, que falava e discutia publicamente contra os maniqueus, alegando citações da Sagrada Escritura que não me era fácil refutar.

 Por sua vez, as respostas dos maniqueus me pareciam fracas; e mesmo assim não as expunham em público, mas somente entre nós, e muito em segredo, alegando que as Escrituras do Novo Testamento haviam sido falsificadas por não sei quem, com o intuito de mesclar a lei dos judeus com a fé cristã; por isso eles próprios não podiam mostrar nenhum exemplar sem ser apócrifo.

 Mas o que principalmente me mantinha cativo, e como que sufocado, eram as tais "substâncias", que pareciam oprimir-me, e debaixo de cujo peso, arquejante, me era impossível respirar a atmosfera pura e simples de tua verdade.

## CAPÍTULO XII

### Os estudantes de Roma

 Com toda diligência comecei a pôr em prática a tarefa que me levara a Roma, ensinar a arte retórica, e comecei por reunir alguns estudantes em casa, para me tornar conhecido deles, e, por seu intermédio, dos demais.

 Mas logo vim a saber, com surpresa, que os estudantes de Roma praticavam outras artimanhas, que eu não havia experimentado na África. Se bem era verdade, como me haviam assegurado, que em Roma não ocorriam as mesmas violências dos jovens corrompidos de Cartago, também me afirmavam que aqui os estudantes, aos grupelhos, deixavam de repente de assistir às aulas, passando para outro professor, com o fim de não pagar o devido salário, faltando assim aos compromissos e desprezando a justiça por amor ao dinheiro.

 Também a estes odiava meu coração, porém, não com rancor perfeito, porque na realidade, mas os aborrecia pelo prejuízo que me podiam causar do que pela simples injustiça de seu comportamento. Sem dúvida são infames os que assim agem, e se maculam longe de ti, amando passatempos efêmero e a recompensa de lodo, que imundece as mãos ao ser colhida, agarrando-se a um mundo fugaz, e desprezando a ti, que permaneces eternamente, a ti que chamas e perdoas à alma humana adúltera quando se volta para ti. Ainda agora aborrece-me gente tão depravada e sem modos, embora agora deseje que se corrijam, para que prefiram ao dinheiro a ciência que aprendem, e à essa ciência prefiram a ti, Deus, verdade e abundância de verdadeiro bem e paz castíssima. Mas naquele tempo – confesso – preferia que não fossem maus para meu interesse do que bons por teu amor.

## CAPÍTULO XIII

### Viagem a Milão, Santo Ambrósio

 Por isso, quando da cidade de Milão escreveram ao prefeito de Roma pedindo para lá um professor de retórica, com viagem paga pelo Estado, eu mesmo solicitei esse emprego por intermédio dos mesmos amigos, ébrios com as vaidades dos maniqueus, dos quais ia-me separar. Tanto eles como eu, porém, o ignorávamos. Símaco, então prefeito da cidade, propôs-me o tema de um discurso, e sendo eu aprovado, mandou-me para Milão.

 Chegado a Milão, visitei o bispo Ambrosio, famoso na terra por suas qualidades, piedoso servo teu, cuja eloqüência distribuía zelosamente entre teu povo a flor de teu trigo, a alegria do azeite e a sóbria embriaguez de teu vinho. A ele era eu conduzido por ti sem o saber, a fim de que ele me conduzisse a ti conscientemente.

 Esse homem de Deus recebeu-me paternalmente, e se interessou muito por minha viagem, como bispo. Comecei a amá-lo; a princípio, não como mestre da verdade, que eu desesperava de achar em tua Igreja, mas pela sua amabilidade para comigo. Ouvia-o atentamente quando pregava ao povo, não com espírito adequado, mas como se quisesse sondar sua eloqüência, para ver se correspondia à sua fama, ou se era maior ou menor que a que se dizia; ficava suspenso das suas palavras, mas indiferente ao conteúdo, coisa que eu até desprezava. Deleitava-me com a suavidade dos sermões, os quais, embora mais eruditos que os de Fausto, eram contudo, menos alegres e envolventes no estilo. Quanto à substância de tais sermões não havia comparação, pois Fausto se perdia por entre as fábulas dos maniqueus, e Ambrosio ensinava claramente a mais sã doutrina da salvação. Mas a salvação anda longe dos pecadores, tal como eu era então. Todavia, insensivelmente e sem o saber, ia-me aproximando dela.

## CAPÍTULO XIV

### Catecúmeno

 Não cuidava eu de aprender o que dizia, interessado apenas em como o dizia – era este gosto frívolo o único que ainda permanecia em mim, perdidas já as esperanças de que se abrisse para o homem o caminho para ti. Todavia, infiltravam-se em meu espírito, juntamente com as palavras que me agradavam, as coisas que desprezava. Já não me era possível discernir umas das outras, e assim, ao abrir meu coração à sua eloqüência, nele entrava ao mesmo tempo e aos poucos, a verdade.

 Parece-me, de bom início, que seus ensinamentos podiam ser defendidos e que as afirmações de fé católica – que eu julgava impotente contra os ataques dos maniqueus – não eram absolutamente temerárias, principalmente depois de me serem explicados uma, duas ou mais vezes, as passagens obscuras do Velho Testamento que, interpretadas no sentido literal, me davam a morte. Assim, interpretados no sentido espiritual muitos dos textos daqueles livros, comecei a repreender aquele meu desespero, que me levava a crer na impossibilidade de resistir aos que aborreciam e zombavam da lei e dos profetas.

 Contudo, não me julgava na obrigação de segui o caminho dos católicos, só porque também esta fé podia ter defensores doutos, capazes de refutar objeções com eloqüência e lógica. Nem por isso me parecia que devia condenar a fé que antes abraçara, pois as armas de defesa eram iguais. Assim, de um lado a fé católica não me parecia vencida, contudo ainda não me parecia vencedora.

 Apliquei então todas as forças de meu espírito para ver se podia de algum modo, com argumentos decisivos, convencer de falsidade os maniqueus. A verdade é que se eu então tivesse podido conceber uma substância espiritual, imediatamente todas as invenções daqueles se esvaeceriam e seriam arrancadas de minha alma. Mas não podia.

 Contudo, refletindo e comparando sempre mais o que os filósofos haviam teorizado acerca do mundo material e de toda a natureza sensível, cada vez mais me capacitava de que eram muito mais prováveis as doutrinas destes que as dos maniqueus. Por isso, duvidando de tudo e flutuando por entre as doutrinas, à maneira dos acadêmicos, como os julga a opinião geral, resolvi abandonar os maniqueus, julgando que enquanto tivesse em dúvida não devia permanecer em uma seita à qual eu já antepunha alguns filósofos. Recusava-me, contudo, terminantemente, a confiar-lhes a cura das enfermidades de minha alma, por ser-lhes desconhecido o nome salutar de Cristo.

 Por isso tudo, resolvi tornar-me catecúmeno na Igreja Católica, que me havia sido recomendada por meus pais, até que alguma claridade certa viesse dirigir meus passos.

# LIVRO SEXTO

## CAPÍTULO I

### Esperanças

 Ó minha esperança desde a minha juventude! Onde estavas, ou a que lugar te havias retirado? Acaso não foste tu quem me criou, diferenciando-me dos animais, fazendo-me mais sábio que as aves do céu? Mas eu caminhava por trevas e resvaladouros, e te buscava fora de mim, e não encontrava o Deus de meu coração; caí nas profundezas do mar. Eu perdera a confiança e desesperava de encontrar a verdade.

 Minha mãe já viera a meu encontro, forte em sua piedade, seguindo-me por mar e por terra, confiando em ti em todos os perigos. Até na travessia do mar proceloso ela encorajava os marinheiros – os que costumam animar os navegadores inexperientes quando se perturbam – garantia-lhes que chegariam a salvo ao fim da viagem, porque assim lho tínheis prometido em visão.

 Encontrou-me em grave perigo, já sem esperança de buscar a verdade. Contudo, quando lhe disse que já não era maniqueísta, sem ser ainda católico, não pulou de alegria, como quem ouve algo inesperado, pois já estava segura sobre aquele ponto de minha miséria, que a fazia chorar por mim como por um morto que haveria de ressuscitar. Oferecia-me continuamente a ti em pensamento, como sobre um esquife, para que dissesses ao filho da viúva: Jovem, eu te digo: levanta-te, e seu filho revivesse, e voltasse a falar, e o entregasses à sua mãe.

 Nem se abalou seu coração com alegria exagerada ao ouvir quanto já se havia cumprido daquilo que com tantas lágrimas te suplicava todos os dias. Viu-me, senão na posse da verdade, já afastado do erro. E como estava certa de que me concederias o que faltava – pois lhe havias prometido a graça total – respondeu-me, com muita calma e com o coração cheio de confiança, que esperava em Cristo que, antes de sair desta vida, me havia de ver católico fiel.

 Foi o que me disse. Mas diante de ti, ó fonte das misericórdias, redobrava as súplicas e lágrimas, para que apressasses teu auxílio e aclarasses minhas trevas. Ia com maior solicitude à igreja para ficar suspensa dos lábios de Ambrosio, como da fonte de água viva que jorra para a vida eterna. Minha mãe amava este varão como a um anjo de Deus, pois sabia que fora ele quem me fizera mergulhar naquela dúvida, pela qual antevia, segura, que eu haveria de passar da enfermidade pela saúde, depois de um perigo mais grave, que os médicos chamam de crítico.

## CAPÍTULO II

### Obediência de Mônica

 Assim, um dia, como costumava na África, levou papas, pão e vinho puro à sepultura dos mártires, mas o porteiro não quis permitir suas ofertas. Quando soube que essa proibição vinha do bispo, resignou-se tão piedosamente e obedientemente, que eu mesmo me admirei de quão facilmente passasse a condenar o hábito, e não a criticar a proibição de Ambrósio.

 É que seu espírito não era dominado pela embriaguez, nem o amor do vinho a incitava ao ódio da verdade, como acontece a muitos homens e mulheres, que ao ouvir o cântico da sobriedade, sentem a mesma repulsa que os ébrios diante de um copo d'água. Mas ela, ao trazer as cestas com as oferendas usuais para serem provadas e repartidas, não bebia mais que um pequeno copo de vinho, temperado segundo seu paladar bastante sóbrio e condizente com sua dignidade. E se eram muitos os sepulcros que devia honrar desse modo, levava sempre o mesmo copo, usando-o para todos, de modo que o vinho não só estava muito aguado, mas até quente. Dividia-o em pequenos tragos com as pessoas presente, porque buscava a piedade, e não o prazer.

 Tão logo porém soube que o ilustre pregador e mestre a verdade proibira tal costume – mesmo para os que o praticavam sobriamente, para não dar aos ébrios azo de se embriagarem, e porque essa espécie de parentales (festas pagãs que se celebravam de 13 a 21 de fevereiro consagradas especialmente aos deuses lares) era muito semelhante à superstição dos pagãos – ela se absteve de muito boa vontade. No lugar da cesta cheia de frutos da terra, aprendeu a levar ao túmulo dos mártires um coração cheio de puros desejos, dando o que podia aos pobres. Celebrava assim a comunhão com o corpo do Senhor, cuja paixão serviu de modelo aos mártires em seu sacrifício e coroação.

 Mas, parece-me, meu Senhor e meu Deus – e assim o crê meu coração em tua presença – que minha mãe não teria abdicado tão facilmente desse costume – que todavia era necessário cortar – se outro a quem não amasse tanto como a Ambrosio o tivesse proibido. De fato, ela o estimava muito por ter-me salvado, e ele a tinha em grande estima pela religiosidade e solicitude com que freqüentava a igreja, na prática das boas obras. Por isso, muitas vezes quando me encontrava com ele, irrompia em louvores à minha mãe, e me felicitava por ser seu filho. Ignorava o filho que ela tinha em mim, filho que duvidava de tudo, e julgava impossível achar o caminho da vida.

## CAPÍTULO III

### Primeiras conquistas

 Na oração, eu ainda não implorava o teu socorro, mas meu espírito achava-se ocupado em investigar e inquieto por discutir. Considerava ao próprio Ambrósio como homem feliz aos olhos do mundo, vendo-o tão honrado pelas mais altas autoridades. Somente seu celibato me parecia difícil. Mas eu não podia aquilatar, por nunca as ter experimentado, as esperanças que o animavam, nem a luta que tinha de travar contra as tentações de sua alta posição; nem conhecia os consolos na adversidade, nem os saborosos deleites do interior do seu coração quando ruminava teu alimento. Ele, por sua vez, desconhecia minha inquietação e o abismo em que estava para cair, porque não lhe podia perguntar, como desejava, o que queria. Uma multidão de homens de negócios, a quem ele acudia nas dificuldades, impediam-me de o ouvir ou de lhe falar.

 No bem pouco tempo que lhe deixavam livre, dedicava-se a reparar as forças do corpo com o alimento necessário, ou as do espírito, com a leitura. Quando lia, seus olhos percorriam as páginas e seu espírito penetrava-lhes o sentido, mas sua voz e sua língua repousavam.

 Muitas vezes, estando eu presente – pois ninguém estava proibido de entrar, nem era costume anunciar quem se apresentava – vi-o ler em silêncio, e nunca de outra maneira. E ali ficava eu por muito tempo calado – pois, quem se atreveria molestar um homem tão atento? – e por fim me afastava. Conjeturava eu que nos curtos momentos que encontrava para repousar o espírito, livre do tumulto dos negócios alheios, não queria que o ocupassem com outra coisa. Lia em silêncio (era comum naqueles tempos ler em voz alta, tanto pela dificuldade dos textos como pela escassez dos livros, muitas vezes lidos em comum), talvez para evitar que algum ouvinte, suspenso e atento à leitura, encontrando alguma passagem obscura, pedisse explicações, ou o obrigasse a dissertar sobre questões difíceis. Gastaria o tempo em tais coisas, e impedido de ler todos os livros que desejava, embora fosse mais provável que lesse em silêncio para poupar a voz, que facilmente lhe enrouquecia.

 Em todo caso, qualquer que fosse sua intenção, só poderia ser boa em um homem como ele.

 O certo é que não se apresentava nenhum ensejo para interrogar a teu santo-oráculo que habitava em seu coração sobre o que desejava, exceto quando lhe ouvia uma breve resposta, e minhas inquietudes pediam muito tempo e vagar para consultá-lo, o que nunca encontrava. Ouviao, é certo, explicar perfeitamente ao povo a palavra da verdade todos os domingos, persuadindome sempre mais de que podiam ser desatados todos os nós das calúnias sagazes que aqueles que me enganavam teciam contra os livros sagrados.

 Logo verifiquei que vossos filhos espirituais, a quem regeneraste no sei da santo mãe, a Igreja, não interpretavam aquelas palavras: "Fizeste o homem à sua imagem" – de modo a acreditar que estavas encerrado na forma do corpo humano. E embora eu então não soubesse, nem sequer suspeitasse de longe o que fosse substância espiritual – alegrei-me com isso, envergonhando-me por ter ladrado durante tantos anos, não contra a fé católica, mas contra invenções de minha inteligência carnal. Tinha sido ímpio e temerário por criticar uma doutrina que eu deveria ter antes procurado conhecer. Mas tu – que estás ao mesmo tempo tão alto e tão perto de nós, tão escondido e tão presente, tu que não tens membros maiores nem menores, que estás inteiro em toda parte sem estar todo em nenhum lugar, certamente não tens nossa forma corpórea. Contudo, fizeste o homem à tua imagem, e eis que ele, da cabeça aos pés, é limitado pelo espaço.

## CAPÍTULO IV

### O espírito da letra

 Não compreendendo como poderia se espelhar esta tua imagem ao homem, eu deveria bater à porta, perguntando-te de que modo deveria entender essa crença, em lugar de me opor insolentemente, como se ela fosse o que eu imaginava. E assim, tanto mais fortemente me roia o coração o desejo de ter alguma certeza, quanto mais me envergonhava de ter sido o joguete dos que me haviam prometido a certeza, e por ter defendido com pueril empenho e animosidade tantas coisas duvidosas como sendo verdadeiras.

 Depois vi a razão por que eram falsas. Mas já estava então certo de que elas eram duvidosas, embora as tivesse julgado irrefutáveis por algum tempo, quando, com minhas cegas discussões, combatia tua Igreja Católica. Embora então não a reconhecesse como mestra da verdade, pelo menos sabia que não ensinava aquilo de que eu a acusava.

 Daí minha confusão, e a conversão que se operava em meu pensamento, ó meu Deus, vendo que tua Igreja única, corpo de teu Filho único, na qual, ainda menino me ensinaram o nome de Cisto, não gostava de bagatelas infantis. Regozijava-me que em sua doutrina sadia nada havia que te representasse, a ti, Criador de todas as coisas, circunscrito numa forma e num espaço que, embora amplo, seria contudo limitado.

 Também me alegrava de que as Antigas Escrituras da lei e os profetas já não me fossem propostas na interpretação anterior, em que me pareciam absurdas, quando eu acusava teus santos de pensamentos que nunca haviam tido. Alegrava-me ouvir a Ambrósio dizer muitas vezes em seus sermões ao povo, recomendando com muito zelo a verdade: a letra mata e o espírito vivifica. E, levantando o véu místico, revelava-me o significado espiritual de passagens que, segundo a letra, pareciam ensinar um erro. Nada dizia que me chocasse, embora eu ainda ignorasse se ele dizia a verdade.

 Abstinha-se meu coração de aderir a qualquer doutrina, temendo cair em um precipício; mas esta suspensão matava-me muito mais, porque queria estar tão certo das coisas que não via como o estava de que sete e três são dez. Eu não estava tão louco para pensar que a inteligência alcançaria tal evidência. Mas, assim como entendia isso, queria entender igualmente as outras verdades, quer fossem materiais, que não tinha presentes a meus sentidos, quer espirituais, nas quais não sabia pensar senão de modo material.

 É verdade que poderia sarar pela crença, e assim, purificado pela fé o olhar de meu espírito, pudesse dirigir-se de algum modo à tua verdade, sempre imutável e indefectível. Mas, como sói acontecer a quem caiu nas mãos de um médico ruim, e que depois receia as mãos de um bom, assim me sucedia quanto à saúde de minha alma que, não podendo sarar senão pela fé, recusava-se a sarar por temor de crer, novamente, em falsidades. Minha alma resistia às tuas mãos, ó meu Deus, que preparaste o remédio da fé, e o derramaste sobre as enfermidades da terra, dando-lhe tanta autoridade e eficácia.

## CAPÍTULO V

### Os mistérios da Bíblia

 Desde esse tempo, recaía minha preferência na doutrina católica, porque ajuizava que nela houvesse mais modéstia, e não mentira, ao impor a crença no que não era demonstrado – quer porque, mesmo havendo provas, estas não fossem acessíveis a todos, quer porque não existissem. Diferente do que ocorria entre os maniqueus, que desprezavam a fé, e prometiam, com temerária arrogância, a ciência, para depois nos obrigarem a acreditar em uma infinidade de fábulas completamente absurdas, impossíveis de demonstrar.

 Depois, com suavidade e misericórdia, começaste, Senhor, a cuidar e à preparar aos poucos o meu coração, e foi aceitando tudo o que eu acreditava sem o ter visto, e a cuja realização não presenciara. Tantos fatos da história dos povos, tantas notícias sobre lugares e cidades que não vira, tudo o que aceitava acreditando em amigos, em médicos e em outras pessoas que, se não as acreditássemos, não poderíamos dar um passo na vida. E, sobretudo, que fé inabalável eu tinha em ser filho de meus pais, coisa que não poderia saber sem prestar fé no que ouvia. Então me convenceste de que os dignos de censura não são os que acreditam em teus livros, cuja autoridade estabeleceste entre quase todos os povos, mas o que não crêem neles. E eu não devia dar ouvidos ao que talvez me dissessem: "Como sabes que esses livros foram dados aos homens pelo Espírito de Deus, único e verdadeiro?" Ora, era precisamente isto o que eu devia crer, porque nenhuma objeção caluniosa ou agressiva, das que eu havia lido nos escritos contraditórios dos filósofos, nunca conseguiram arrancar-me a certeza de tua existência, embora ignorasse o que eras, e a certeza de que o governo das coisas humanas está em tuas mãos.

 Eu acreditava nisso, ora mais fortemente, ora mais frouxamente; mas em tua existência e que cuidava do gênero humano, sempre acreditei, embora ignorasse a natureza, ou qual o caminho que nos conduz ou reconduz a ti. Por isso, persuadido de nossa impotência para achar a verdade só por meio da razão, e que para isso nos é necessária a autoridade das Sagradas Escrituras, comecei a crer que nunca terias conferido tão soberana autoridade a essas Escrituras em todo o mundo, se não quiséssemos que crêssemos e te buscássemos por elas.

 Sobre os mistérios em que costumava tropeçar, e que ouvira explicar muitas vezes de modo aceitável, eu os atribuía à sua profundidade, parecendo-me a autoridade das Escrituras tanto mais venerável e digna da fé sacrossanta, quando de leitura fácil para todos. E ela reserva porém, a uma percepção mais aguda a majestade de seu mistério. Pela clareza da linguagem e sua simplicidade do estilo, ela se abre a todos e, no entanto, estimula a reflexão dos que não são levianos de coração. Recebe a todos em seu vasto seio, mas não deixa ir a ti, por caminhos estreitos, senão um pequeno número; muito mais, porém, do que seriam se ela não tivesse essa elevada autoridade, e não atraísse as turbas do regaço de sua santa humildade.

 Pensava eu nessas coisas, e me assistias; suspirava, e me ouvias, vacilava, e me governavas; seguia pela via larga do mundo, e não me abandonavas.

## CAPÍTULO VI

### Alegria de bêbado

 Eu aspirava às honras, às riquezas e ao matrimonio, e tu te rias de mim. E nesses desejos sofria grandes amarguras; e tu me eras tanto mais propício quanto menos consentias que me fosse doçura o que não eras tu. Vê, Senhor, meu coração, tu que quiseste que recordasse estes fatos e os confessasse. Esta alma, a quem livraste do visco tenaz da morte, une-se agora a ti. Como era infeliz! E tu fustigavas o mais dolorido da ferida, para que deixasse tudo, e se convertesse a ti, que estás acima de tudo. Sem ti nada existiria. Ferias minha alma para que voltasse para ti, e fosse curada.

 Que miserável era eu então! E como agiste para que eu sentisse minha desgraça? Era o dia em que me preparava para declamar os louvores do imperador; neles ia mentir muito e, mentindo granjearia a aprovação dos que sabiam das mentiras. Preocupado, meu coração se consumia com a febre de pensamentos impuros quando, ao passar por uma rua de Milão, vi um mendigo já bêbado, creio eu, mas bem humorado e divertido. Suspirei então, e falei aos amigos que me acompanhavam sobre as muitas dores que nos provocavam nossas loucuras. Com todos os esforços, quais eram os que então me afligiam, apenas arrastava a carga de minha infelicidade cada vez mais pesada, aguilhoado por meus apetites, para conseguir somente uma alegria tranqüila, na qual já nos havia precedido aquele mendigo; alegria que nunca talvez alcançássemos. O que ele havia conseguido com umas poucas moedas de esmola, era exatamente o que eu aspirava com tão árduos caminhos e rodeios: a alegria de uma felicidade temporal.

 A alegria do mendigo não era certamente verdadeira, mas a que eu buscava com minhas ambições era ainda mais falsa. Ele, pelo menos, estava alegre, e eu, angustiado; ele seguro, e eu inquieto. Se alguém me perguntasse se preferia estar alegre ou triste eu responderia: alegre; mas se me perguntassem novamente se queria ser como aquele mendigo ou ser como eu era, sem dúvida escolheria a mim mesmo, embora cheio de cuidados e de temores. Mas isto eu faria por maldade ou com razão? Eu não devia preferir-me ao mendigo por ser mais culto, pois a ciência para mim não era fonte de felicidade, mas apenas um meio de agradar aos homens, e não instruílos. Por isso, Senhor, quebravas meus ossos com a vara de tua disciplina.

 Longe de minha alma os que dizem: "Importa levar em conta a causa da alegria; o mendigo se alegrava com a embriaguez, e tu com a glória". Que glória, Senhor? Com a que não está em ti. Porque como aquela não era verdadeira alegria, assim aquela glória não era a verdadeira, antes perturbava mais ainda meu coração. O ébrio, naquela mesma noite, curaria sua embriaguez, enquanto eu já dormia com a minha, e me levantara com ela, e tornaria a dormir e a levantar com ela, e tu sabes quantos dias!

 Importa, é certo, conhecer os motivos da alegria de cada um, eu o sei, e a alegria da esperança fiel dista infinitamente daquela vaidade. Mas então, havia entre nós outra diferença, pois certamente ele era o mais feliz, não só porque transbordava de alegria, enquanto eu me consumia de cuidados, mas também porque ele comprara o vinho desejando a felicidade dos benfeitores, enquanto eu procurava com mentiras uma vã ostentação.

 Muitas coisas disse então sobre isso a meus amigos, e muitas vezes eu costumava examinar minha vida, e achava-me infeliz. Isso me afligia e redobrava minha dor; se me sorria alguma ventura, não acudia para apanhá-la, porque escapava-me das mãos antes mesmo que a pudesse alcançar.

## CAPÍTULO VII

### Alípio

 Os que convivíamos em boa amizade lamentávamos estas coisas, mas de modo especial e muito intimamente eu falava com Alípio e Nebrídio. Alípio, como eu, era do município de Tagaste, nascido de uma das melhores famílias da cidade. Era mais jovem do que eu, pois havia sido meu discípulo quando comecei a ensinar em nossa cidade, de depois em Cartago. Ele me queria muito, por eu lhe parecer bom e douto, e eu o apreciava por sua grande inclinação à virtude, que já se manifestava em tenra idade.

 Contudo, o abismo dos costumes cartagineses, onde ferve o gosto dos espetáculos frívolos, engolfara-o na loucura dos jogos circenses. Alípio revolvia-se miseravelmente nesse abismo na época em que eu ensinava retórica na escola pública, mas ele não me tinha como mestre por causa de uma desavença que surgira entre mim e seu pai. Eu sabia que Alípio amava morbidamente o circo, e isso muito me angustiava, por me parecer que se iam se perder, se já não estivessem, magníficas esperanças. Mas não achava meios de alertá-lo e repreendê-lo, nem pela amizade, nem pelo magistério, pois julgava que tinha sobre mim a mesma opinião que seu pai. Mas não era assim. Pondo de parte a vontade paterna sobre isso, começou a me cumprimentar, comparecia à minha aula, ouvia-me um pouco, e logo se retirava.

 Eu já me esquecera de alertá-lo para não desperdiçar seu talento tão precioso com aquele cego e apaixonado gosto por jogos fúteis. Mas tu, Senhor, que governas o que criaste, não te esqueceste de que Alípio deveria ser ministro de teus sacramentos entre teus filhos; e para que fosse atribuída claramente a ti a sua emenda, a realizaste por meu intermédio, mas sem que eu o soubesse.

 Um dia, estando sentado ao lugar de costume, diante de meus discípulos, veio Alípio, saudou-me, sentou-se, atento ao assunto de que eu tratava. Por acaso trazia eu nas mãos uma lição; para melhor expô-la, e tornar mais clara e agradável sua explicação, pareceu-me oportuno fazer uma comparação com os jogos circenses, com mordaz sarcasmo aos escravos dessa loucura. Mas tu sabes, Senhor, que então não pensei em curar Alípio dessa peste. Todavia tomou para si minhas palavras, acreditando que eu só dissera por sua causa. Qualquer outro tomaria isso com desgosto; mas ele, jovem virtuoso, tomou-o como causa para censurar a si próprio, e para me estimar ainda mais.

 Já havias dito outrora, e escrito em teus livros: "Corrige o sábio, e ele te amará". Eu não o repreenderia, mas tu, servindo-te de todos, quer eles o saibam ou quer não, de acordo com a justa ordem que conheces, fizeste de meu coração e de minha língua carvões abrasadores, para cauterizar e curar aquela alma tão promissora, mas pervertida.

 Senhor, cale teus louvores quem não percebe tuas misericórdias, que eu te confesso do mais íntimo de meu ser. Depois de ouvidas minhas palavras, Alípio saiu daquele fosso profundo, onde gostosamente se enterrara, cegando-se com o torpe prazer, e sacudiu sua alma com corajosa temperança, afastando de si todas as imundícies dos jogos circenses, para onde nunca mais voltou.

 Depois venceu a resistência paterna para me escolher como mestre, e seu pai cedeu e consentiu. Voltando a ser meu discípulo, foi envolvido comigo na superstição dos maniqueus, apreciando neles aquela ostentação de continência, que ele julgava legítima e sincera. Na verdade, porém, era um desvario sedutor, um laço onde caíam almas preciosas, ainda incapazes de avaliar a sublimidade da virtude e, por isso mesmo, vítimas fáceis da aparência que mascara uma virtude hipócrita e fingida.

## CAPÍTULO VIII

### A atração do anfiteatro

 Não querendo por nada deixar a carreira mundana, tão decantada por seus pais, partira antes de mim para Roma, a fim de estudar Direito; lá se deixou arrebatar de modo incrível, e com incrível avidez, pelos espetáculos de gladiadores.

 A princípio, detestava e aborrecia espetáculos semelhantes. Certa vez, encontrando-se com alguns amigos e condiscípulos que voltavam de um jantar, apesar de resistir, foi arrastado por eles com amigável violência para o anfiteatro, onde naquele dia se celebravam jogos funestos e cruéis.

 Dizia-lhes Alípio: "Mesmo que arrasteis para lá meu corpo, e o retenhais ali, podereis por acaso obrigar minha alma e meus olhos a contemplar tais espetáculos? Estarei ali como ausente, e assim triunfarei deles e de vós". Mas eles, não fazendo caso de tais palavras, levaram-no, talvez para verificar se poderia ou não cumprir a palavra.

 Quando chegaram, ocuparam os lugares que puderam, pois todo o anfiteatro já fervia nas paixões mais selvagens. Alípio, fechando a porta dos olhos, proibiu que sua alma se envolvesse em tal crueldade. E oxalá também tivesse tapado os ouvidos! Porque, em um lance da luta, foi tão grande o clamor da multidão que, vencido pela curiosidade, e julgando-se preparado para desprezar e vencer a cena, fosse o que fosse, abriu os olhos. Foi logo ferido na alma mais profundamente do que a ferida física do gladiador a quem desejou contemplar e caiu. Sua queda foi mais miserável que a do gladiador, causa de tantos gritos. Estes, entrando-lhe pelos ouvidos, abriram-lhe os olhos, para ferir e abater sua alma, mais temerária do que forte, e tanto mais fraca por apoiar-se em si mesma, em lugar de se apoiar em ti. Logo que viu sangue, bebeu junto a crueldade, e não se afastou do espetáculo; pelo contrário, prestou mais atenção. Assim, sem o saber, absorvia o furor popular e se deleitava naquela luta criminosa, inebriado de sangrento prazer.

 Já não era o mesmo que ali viera, era agora mais um da turba à qual se misturara, digno companheiro daqueles que para ali o arrastaram.

 Que mais direi? Contemplou o espetáculo, gritou, apaixonou-se, e foi contaminado de louco ardor, que o estimulava a voltar, não só com os que o haviam levado, mas à sua frente, e arrastando a outros. Mas tu te dignaste, Senhor, livrá-lo deste estado com mão forte e misericordiosa, ensinando-o a não confiar em si, mas em ti, embora isto acontecesse muito tempo depois.

## CAPÍTULO IX

### Alípio, ladrão a contragosto

 Contudo, essa aventura gravara-se em sua memória como remédio para o futuro. o mesmo ocorreu com outro fato, quando ainda era estudante em Cartago, e seguia meus cursos. Era meio-dia. Alípio estava repassando uma declamação, segundo o costume dos estudantes, quando foi preso como ladrão pelos guardas do foro. Sem dúvida o permitiste, meu Deus, apenas para que esse jovem, tão grande no futuro, começasse já a aprender que, ao julgar outrem, ninguém deve condenar ninguém levianamente, e com temerária credulidade.

 Alípio, pois, passeava diante do tribunal, sozinho, com as tábuas e o estilete, quando um jovem estudante, o verdadeiro ladrão, levando escondido um machado, sem que Alípio o percebesse, entrou pelas grades que rodeiam a rua dos banqueiros, e se pôs a cortar o seu chumbo.

 Ao ruído dos golpes, os banqueiros que estavam embaixo alvoroçaram-se, e chamaram gente para prender o ladrão, fosse quem fosse. Mas este, ouvindo o vozerio, fugiu depressa, abandonando o machado para não ser preso com ele. Ora, Alípio, que não o vira entrar, viu-o sair e fugir precipitadamente. Curioso, porém, para saber a causa, entrou no lugar. Encontrou o machado e se pôs, admirado, a examiná-lo. Bem nessa hora chegaram os guardas dos banqueiros, e o surpreendem sozinho, empunhando o machado, a cujos golpes, alarmados, haviam acudido. Prendem-no, levam-no, e gloriam-se, diante dos inquilinos do foro por ter apanhado o ladrão em flagrante, e já o iam entregar aos rigores da justiça.

 Mas a lição devia ficar por aqui, Senhor, porque imediatamente saíste em socorro de sua inocência, da qual eras única testemunha. Quando o conduziam à prisão ou ao suplício, veio-lhes ao encontro um arquiteto, encarregado superior da direção dos edifícios públicos. Os guardas alegraram-se com esse encontro, pois sempre que faltava alguma coisa no foro o magistrado suspeitava deles. Agora ele saberia quem era o verdadeiro ladrão. Mas este senhor tinha visto várias vezes Alípio na casa de um senador, a quem visitava com freqüência. Reconheceu-o, tomou-o pela mão, separou-o da turba, e perguntou-lhe a causa de tamanha desgraça.

 Informado do que se passara, o arquiteto mandou à turba alvoroçada e enfurecida contra Alípio que o seguisse. Quando chegaram à casa do jovem autor do roubo, achava-se à porta um menino escravo, novo demais para recear comprometer seu amo, e que poderia revelar tudo, porque o seguira até o foro. Alípio, ao reconhecê-lo, apontou-o ao arquiteto; este, mostrando-lhe o machado, lhe disse: "Sabe de quem é este machado?" Ao que o menino respondeu sem demora: "Nosso". Depois de interrogado, confessou o resto.

 Deste modo, o processo foi transferido para aquela casa, para confusão da turba, que já imaginara tripudiar de Alípio. O futuro dispensador de tua palavra, e juiz de tantas causas de tua Igreja, saiu dessa aventura com mais experiência e sabedoria.

## CAPÍTULO X

### Os três amigos

 Encontrei Alípio em Roma, onde se uniu a mim com vínculo de amizade tão estreito, que foi comigo para Milão, tanto para evitar nosso afastamento como para exercer o Direito, embora mais para agradar aos pais do que por vontade própria. Já por três vezes fora assessor, sempre com admirável lisura, e ficando ele mais admirado ainda de que juizes preferissem o dinheiro à inocência.

 Ficou provada a integridade do seu caráter, não só contra os atrativos da cobiça, mas também contra o aguilhão do medo. Em Roma, era assessor do tesoureiro das finanças da Itália. Havia nesse tempo um senador poderosíssimo, a quem estavam sujeitos muitos clientes, uns por benefícios, outros por terror. Segundo o costume dos poderosos, este senador tentou fazer não sei que coisa era proibida pelas leis, e Alípio se lhe opôs. À tentativa de corrompê-lo, Alípio reconheceu com o riso. Zombou das ameaças que aquele lhe dirigiu, causando admiração geral pela rara qualidade de sua alma, que não desejava a amizade e nem temia a inimizade de homem tão poderoso, conhecido por seus inúmeros meios de prestar favores ou de prejudicar. Até o próprio juiz, de que Alípio era assessor, embora se opusesse também, não o fazia abertamente, responsabilizando a Alípio que, dizia ele, não lhe permitia fazer o que desejava, porque, se acedesse – e era verdade – demitir-se-ia imediatamente.

 Alípio quase se deixara seduzir pelo amor às letras, mandando copiar códigos segundo a tarifa paga aos trabalhos para o Estado; porém, consultando a justiça, inclinou-se pelo melhor, preferindo a integridade, que lhe proibia esta ação, ao poder que lha permitia.

 Isso é fato pequeno, mas o que é fiel no pouco também o é no muito, e de modo nenhum podem ser vãs aquelas palavras saídas da boca de tua Verdade. Se não fordes fiéis nas riquezas injustas, quem vos confiará as verdadeiras? E se nas alheias não fordes fiéis, quem vos dará o que é vosso?

 Assim era então este amigo, tão intimamente unido a mim, e que comigo buscava o tipo de vida que deveríamos seguir.

 Também Nebrídio deixou sua pátria, vizinha de Cartago, e a própria Cartago, onde gozava de boa fama. Abandonou as magníficas propriedades do pai, a casa e até a própria mãe, que não o quis seguir; veio para Milão apenas para viver comigo, na busca apaixonada da verdade e da sabedoria.

 Assim como eu, ele suspirava, partilhando minha perplexidade, mostrando-se investigador ardoroso da vida feliz e indagador acérrimo das questões mais difíceis.

 Eram três bocas famintas que comunicavam mutuamente a própria fome, esperando que lhes desses comida no tempo oportuno. Na amargura, que graças à tua misericórdia sempre seguia nossas ações mundanas, se desejávamos entender a causa dos sofrimentos, encontrávamos trevas. Afastávamos gemendo e dizendo: Até quando durará este sofrimento? E isto repetíamos com freqüência, mas não abandonávamos nosso modo de vida, porque não víamos nenhuma certeza a que nos pudéssemos abraçar, se o abandonássemos.

## CAPÍTULO XI

### Entre Deus e o mundo

 Era com admiração que me recordava diligentemente do longo tempo decorrido desde meus dezenove anos, quando comecei a arder no desejo da sabedoria, propondo-me, quando a achasse, abandonar todas as vãs esperanças e enganosas loucuras das paixões.

 Chegado porém aos trinta anos, ainda continuava preso ao mesmo lodaçal, ávido de gozar dos bens presentes, que me fugiam e me dissipavam. Entretanto, dizia: "Amanhã hei de encontrála; a verdade aparecerá clara, e a abraçarei. Fausto virá, e dará todas as explicações. Ó grandes varões da Academia: é verdade que não podemos compreender nenhuma coisa com certeza para a conduto de nossa vida?

 "Mas não! Procuremos com mais diligencia, sem desesperarmos. Já não me parecem absurdas nas Escrituras as coisas que antes me pareciam tais: posso compreendê-las de modo diferente, mais razoável. Fixarei, pois, os pés naquele degrau em que me colocaram meus pais quando criança, até que encontres a verdade em sua evidência.

 "Mas onde e quando buscá-la? Ambrósio não tem tempo livre para me ouvir, e a mim falta tempo para ler. E além do mais, onde encontrar os livros? E onde ou quando poderei comprá-los? A quem hei de pedi-los?

 "Repartamos o tempo, reservemos algumas horas para a salvação da alma. nasceu uma grande esperança: a fé católica não ensina o que eu pensava, e eu a criticava levianamente. Seus doutores têm como crime limitar Deus à figura humana; e eu ainda hesito em bater para que nos sejam reveladas as outras verdades! As horas da manhã eu dedico aos alunos; mas que faço das outras? Por que não as consagro a essa busca?

 "Mas quando então, visitar os amigos poderosos, de cujos favores necessito? Quando preparar as lições que os alunos me pagam? Quando reparar as forças do espírito, descansando em algo aprazível?

 "Perca-se tudo! Deixemos essas coisas vãs e fúteis. Entreguemo-nos por completo à busca da verdade. A vida é miserável, e a hora da morte, incerta. Se esta me surpreender de repente, em que estado sairei do mundo? E onde aprenderei o que deixei de aprender aqui? Não serei antes castigado por essa negligência? Mas, e se a própria morte cortar e for o fim a todo cuidado e sentimento? Também seria conveniente investigar este ponto. Mas afastemos tais pensamentos! Não é por acaso nem é em vão que se difunde por todo o mundo a fé cristã, com grande prestígio. Deus jamais teria criado tantas e tais coisas por nós, se com a morte do corpo terminasse também a vida da alma. porque hesitar, pois, em abandonar as esperanças do mundo para me consagrar à busca de Deus e da bem aventurança?

 Mas espere um pouco! Os bens mundanos também têm seus deleites, que não são pequenos. Não devo deixá-los sem pensar; seria feio ter de voltar a eles. Eis-me prestes a conseguir um cargo de honra. Que mais posso desejar? Tenho uma multidão de amigos poderosos. Sem me apressar muito poderia obter, no mínimo, uma presidência. Poderia então casar-me com uma mulher de alguma fortuna, para que meus gastos não fossem muito pesados. Aqui estariam os limites de meus desejos. Muitos homens grandes e dignos de imitação, apesar de casados, dedicaram-se ao estudo da sabedoria.

 Enquanto assim pensava, e os ventos cambiantes impeliam meu coração de um lado para outro, o tempo passava, e eu retardava minha conversão ao Senhor. Adiava de dia para dia o viver em ti, morrendo todavia todos os dias em mim mesmo. Amando a vida feliz, temia busca-la em sua morada; procurava-a fugindo dela! Pensava que seria mui desgraçado se me visse privado das carícias da mulher. Não pensava ainda no remédio de tua misericórdia, que cura esta enfermidade, porque nunca o havia experimentado. Julgava que a continência fosse obra de nossa própria força, que eu pensava não ter. Eu era bastante néscio para ignorar que ninguém, como está escrito, é casto sem que tu lhes dê a força. Essa força certamente ma darias se eu ferisse teus ouvidos com os gemidos de minha alma, e com fé firme lançasse em ti meus cuidados.

## CAPÍTULO XII

### Casar ou não?

 Opunha-se Alípio a que me casasse, repetindo-me que, se o fizesse, não poderíamos dedicar-nos juntos, com segura tranqüilidade, ao amor da sabedoria, como há muito desejávamos. Alípio, nessa matéria, era castíssimo de causar admiração, porque, ao entrar na juventude, experimentara o prazer carnal, mas não se prendera a ele. Antes, arrependeu-se muito, e o desprezou, vivendo depois em perfeita continência.

 Eu argumentava com os exemplos dos que, embora casados, haviam-se dedicado ao estudo da sabedoria, servindo a Deus, e guardando fidelidade e amor aos amigos. Contudo, eu estava longe dessa grandeza de alma. Prisioneiro da morbidade da carne, arrastava com prazer mortal minha cadeia, temendo que ela se rompesse e, rejeitando as palavras que bem me aconselhavam, como o ferido repele a mão que lhe desfaz as ataduras.

 Além do mais, a serpente falava por minha boca a Alípio, e pela língua lhe tecia doces laços em seu caminho, para que seus pés honestos e livres se enredassem.

 Ele admirava-se de que eu, a quem tanto estimava, estivesse tão preso ao visco do prazer a ponto de afirmar, sempre que tratávamos desse assunto, que me era impossível levar vida casta. Para esgrimir contra sua admiração, dizia-lhe que havia grande diferença entre sua rápida e furtiva experiência do prazer, de que mal se lembrava e que, por isso, podia desprezar facilmente, e as delícias de uma ligação verdadeira, à qual, se juntasse o honesto nome de matrimonio, já não causaria admiração se eu não pudesse desprezar aquela vida. Com isso, Alípio também começou a desejar o matrimonio, não certamente vencido pelo apetite do prazer, mas pela curiosidade. Desejava saber, dizia ele, o que era aquele bem sem o qual minha vida – que ele tanto apreciava – não me parecia vida, mas tormento. De fato, livre dessa prisão, sua alma pasmava de tal servidão, e do espanto passava ao desejo de experimentá-la. Depois talvez caísse naquela mesma servidão que o espantava, pois queria fazer um pacto com a morte, e o que ama o perigo, nele cairá.

 Certamente que nem ele, nem eu tínhamos grande interesse no que há de bonito e honesto no matrimonio, como a direção da família e a educação dos filhos. Mas o que me mantinha preso e com fortes tormentos era o hábito de saciar minha insaciável concupiscência; e a ele, era a admiração que o arrastava para o mesmo cativeiro. Assim éramos, Senhor, até que tu, ó Altíssimo, que não desamparas nosso lodo, compassivo, por caminhos maravilhosos e ocultos, viestes em socorro destes infelizes.

## CAPÍTULO XIII

### O pedido de casamento

 Instavam solicitamente comigo para que me casasse. Já havia feito o pedido, já havia recebido uma promessa, ajudado sobretudo por minha mãe, que nutria a esperança que eu, uma vez casado, seria regenerado nas águas salutares do batismo. Minha mãe alegrava-se por me ver cada dia mais apto para recebê-lo, vendo que na minha fé se realizavam seus votos e tuas promessas.

 Contudo, nada revelaste à minha mãe que, a meu pedido e por seu desejo, te suplicava com forte clamor de coração, todos os dias que lhe desse alguma visão sobre meu futuro matrimonio. Via, sim, algumas coisas vãs e fantásticas, que o espírito humano engendra quando preocupado. Ela me relatava, sem a confiança que costumava dar às visões que lhe enviavas, mas com desprezo. Dizia que distinguia, por um vago discernimento que não podia explicar com palavras, a diferença que havia entre tuas revelações e os sonhos de sua alma.

 Contudo, insistia no matrimonio, e pediu-se a mão de uma jovem, à que ainda faltavam dois anos para ser núbil (em todo o Império Romano era a idade de 12 anos), mas, como ela agradava, era preciso esperar.

## CAPÍTULO XIV

### Um projeto desfeito

 Éramos muitos os amigos, que aborrecíamos as mazelas da agitação da vida humana. Em nossas conversas, havíamos debatido e quase resolvido nos retirar da multidão para viver sossegadamente. Nosso projeto organizava a vida de tal sorte que tudo o que tivéssemos seria comunitário, formando de todos os patrimônios um patrimônio único. Graças à nossa amizade sincera não haveria mais a fortuna deste ou daquele, mas uma só fortuna comum.

 Seriamos cerca de dez homens os que desejávamos formar essa sociedade. Alguns de nós, muito ricos, como Romaniano, meu conterrâneo, cujos sérios cuidados de negócios o tinham trazido à corte imperial. Era muito amigo meu desde menino, e um dos que mais instavam nesse projeto, tendo sua opinião um grande peso pois sua riqueza era bem superior que a dos outros. Fora combinado que todos os anos, dois de nós, como magistrados, administrariam todo o necessário, ficando os outros em paz. Mas quando se começou a discutir se as mulheres consentiriam nesse acordo – alguns dentre nós eram casados, e outros pensavam em casar – todo o plano, tão bem construído, se desvaneceu entre nossas mãos, fez-se em pedaços e teve de ser abandonado.

 Novamente aos suspiros e gemidos, voltamos a caminhar pelos largos e batidos caminhos do século, porque em nosso coração havia mil pensamentos, mas teu conselho permanece eternamente. Na tua sabedoria te rias de nossos projetos, e preparavas o cumprimento dos teus, a fim de dar-nos alimento no tempo oportuno, abrindo tuas mãos e enchendo-nos de bênçãos.

## CAPÍTULO XV

### A separação da amante

 Entretanto, multiplicavam-se meus pecados. Quando arrancaram do meu lado, por ser impedimento ao meu matrimonio, aquela com quem partilhava o leito, meu coração, ao qual ela estava unida, ficou ferido e sangrando. Ela, por sua vez, voltando para a África, fez-te voto, Senhor, de jamais conhecer outro homem, deixando comigo o filho natural que dela tivera.

 Mas eu, desgraçado, fui incapaz de imitar aquela mulher. Estava impaciente pelo prazo de dois anos que deveria transcorrer até receber por esposa aquela que pedira em casamento – e porque eu não era amante do matrimonio, mas escravo da sensualidade – procurei pois outra mulher, não como esposa, mas para alimentar e manter íntegra ou agravada a doença da minha alma, sob a tutela do meu hábito, até que contraísse matrimonio. Mas nem por isso sarava a chaga causada pela separação da primeira mulher; mas, depois de ardor e sofrimento agudíssimos, começava a se corromper doendo tanto mais desesperadamente quanto mais fria se tornava.

## CAPÍTULO XVI

### A aproximação de Deus

 Louvor e glória a ti, ó fonte das misericórdias! Eu me tornava cada vez mais miserável, e tu te aproximavas cada vez mais de mim. já estava junto de mim tua destra, para me arrancar do lodo dos meus vícios, e em purificar, e eu não o sabia. Mas nada havia que me fizesse sair do profundo abismo dos prazeres carnais, a não ser o medo da morte e de teu juízo futuro, que jamais saiu do meu peito, através das várias doutrinas que segui.

 Discutia com meus amigos Alípio e Nebrídio, sobre o bem e o mal finais; facilmente meu juízo teria dado a palma a Epicuro, se eu não acreditasse na imortalidade da alma e do julgamento de nossos atos, coisas em que Epicuro nunca acreditou. E eu perguntava: "Se fossemos imortais, e vivêssemos em perpétuo gozo sensorial, sem temor algum de perde-lo, não seriamos felizes? Que mais poderíamos desejar?" Ignorava eu que isto era fruto duma grande miséria. Não podia, tão imerso no vício e cego como estava, imaginar a luz da virtude e uma beleza invisível aos olhos da carne, e somente visível das profundezas da alma. Na minha miséria, não indagava de que fonte provinha esse grande gosto em conversar com os amigos, por maior que fosse a abundância dos prazeres carnais, segundo a idéia que eu tinha então? Eu amava a meus amigos desinteressadamente, e também sentia que eles me amavam com o mesmo desinteresse.

 Ó caminhos tortuosos! Ai da alma temerária que, afastando-se de ti, esperava achar algo melhor! Dá voltas e mais voltas, para todos os lados, mas tudo lhe é duro, porque só tu és seu descanso. Mas eis que estás presente, e nos livras de nossos miseráveis erros, e nos pões em teu caminho, e nos consolas dizendo: "Correi, que eu vos levarei e conduzirei ao termo, e aí serei vosso sustento!

# LIVRO SÉTIMO

## CAPÍTULO I

### A idéia de Deus

 Já havia morrido minha adolescência má e nefanda; entrava na juventude, e quanto mais crescia em idade, mais vergonhosa se tornava minha vaidade, a ponto de não poder imaginar uma substância além da que se pode perceber com os olhos.

 Desde que comecei receber as lições da sabedoria, não mais te imaginava, meu Deus, sob a forma de um corpo humano – sempre fugi dessa idéia, e me alegrava encontrar essa doutrina na fé de nossa mãe espiritual, a Igreja Católica; - mas não me ocorria outro modo de te imaginar. E sendo eu homem – e que homem – esforçava-me para imaginar a ti, o sumo, o único e verdadeiro Deus. Com toda minha alma eu te julgava incorruptível, inviolável e imutável. Mesmo não sabendo de onde nem como me vinha esta certeza, eu via com clareza e tinha como certo que o incorruptível é melhor do que o corruptível. Sem hesitar, colocava o que não pode ser vencido acima do que o pode ser, e o que não sofre mudança parecia-me melhor do que é suscetível a mudanças.

 Meu coração clamava violentamente contra todos os meus fantasmas. Esforçava-me por afugentar, com um só golpe, o redemoinho de imagens imundas que voluteavam ao meu redor. Mas, apenas disperso, em um piscar de olhos, tornava a se formar os atropelos sobre minha vista, obscurecendo-a. Apesar de não te atribuir uma figura humana, contudo, necessitava te conceber como algo corporal, situado no espaço, quer imanente ao mundo, quer difundido por fora do mundo, através do infinito; tal era o ser incorruptível, inviolável e imutável que eu colocava acima do que é corruptível, sujeito à deterioração e ás mudanças. O que não ocupava espaço me parecia um nada absoluto, perfeito, e não um simples vazio, como quando se tira um corpo de um lugar, permanecendo o lugar vazio de todo o corpo, terrestre, úmido, aéreo ou celeste, mas, enfim, um lugar vazio, como que um nada espaçoso.

 Assim, pois, com o coração pesado, sem consciência clara de mim mesmo, considerava como um perfeito nada tudo o que não tivesse extensão por determinado espaço, ou não se difundisse ou pudesse assumir um desses estados. As formas percorridas por meus olhos eram os moldes das imagens pelas quais andava meu espírito; não via que a mesma faculdade com que formava essas imagens não era da mesma natureza que elas, não obstante não pudesse formá-las se ela não fosse por sua vez algo grande.

 E também a ti, vida de minha vida, imaginava-te como um Ser imenso, penetrando por todas as partes, através dos espaços infinitos, toda a massa do mundo, alastrando-se sem limites na imensidão, de sorte que a terra, o céu e todas as coisas te continham, e tudo isso tinha em ti seu limite, sem que te limitasses em parte alguma. E assim como a massa do ar – deste ar que está sobre a terra – não impede a passagem da luz do sol, não o impede de a atravessar, de a penetrar sem romper ou cortar, antes enchendo-a totalmente, assim eu pensava que não somente a substância do céu, do ar e do mar, mas também a da terra se deixava atravessar e penetrar por ti em todas as suas partes, grandes e pequenas, que receberiam tua presença, que, com secreta inspiração, governa interior e exteriormente tudo o que criaste.

 Assim conjeturava eu, por não poder imaginar-te de outra forma; mas minha conjectura era falsa. Porque, se assim fosse, uma porção maior da terra conteria parte maior de ti; e uma porção menor da terra conteria parte menor. E de tal modo estariam as coisas impregnadas de ti, que o corpo de um elefante conteria tanto mais de teu ser que o corpo do passarinho, pois aquele é maior do que este, e ocupa mais espaço. Assim, fragmentado entre as partes do universo, estarias presente nas grandes partes do universo por grandes partes de ti, e nas pequenas por pequenas, o que não acontece. Mas ainda não tinhas iluminado minhas trevas.

## CAPÍTULO II

### Objeção contra o maniqueísmo

 Bastava-me, Senhor, para calar aqueles enganados enganadores e muitos charlatães – pois o que se ouvia de sua boca não era a tua palavra – bastava-me, certamente, o argumento que há muito tempo, estando ainda em Cartago, costumava propor-lhes Nebrídio, impressionando a todos os que então o ouvimos.

 "Que poderia fazer contra ti – dizia aquela não sei que raça de trevas, que os maniqueus costumam opor-te como massa hostil – se não quisesses lutar contra ela?"

 Se respondessem que te podia ser nociva em algo, então serias violável e corruptível. Se dissessem que não te podia prejudicar nada, não haveria razão para luta. Luta essa em que uma parte de ti mesmo, um de teus membros, produto de tua própria substância, se misturava às forças adversas, a naturezas não criadas por ti. Assim se corromperia, degradando-se a ponto de mudar sua felicidade em miséria e de necessitar de auxílio para se libertar e purificar. E essa parte de ti seria a alma que teu Verbo devia salvar da escravidão, ele que é livre de impurezas, ele que é imaculado da corrupção, ele que é intacto sem ser corruptível, sendo feito de uma só e mesma substância.

 E assim, se declaram incorruptível tudo o que és, isto é, a substância que te forma, todas essas proposições são erros execráveis; e se eles te consideram corruptível, essa mesma afirmação também é falsa, e abominável logo à primeira vista.

 Bastava-me, pois, este argumento contra aqueles que eu queria expulsar de vez de meu peito angustiado. De fato, sentindo e dizendo tais coisas de ti, não tinham outra saída senão um horrível sacrilégio de coração e de língua.

## CAPÍTULO III

### Deus e o mal

 Mas eu, mesmo quando afirmava e cria firmemente que és incorruptível, inalterável, absolutamente imutável, Senhor meu, Deus verdadeiro que não só criaste nossas almas e nossos corpos, e não somente nossas almas e corpos, mas todas as criaturas e todas as coisas. Todavia, faltava-me ainda uma explicação, a solução do problema da causa do mal. Qualquer que ela fosse, estava certo de que deveria buscá-la onde não me visse obrigado, por sua causa, a julgar mutável a um Deus imutável, porque isso seria transformar-me no mal que procurava.

 Por isso, buscava-a com segurança, certo de que era falsidade o que diziam os maniqueus; deles fugia com toda a alma, porque via suas indagações sobre a origem do mal cheias de malícia, preferindo crer que tua substância era passível de sofrer o mal do que a deles ser susceptível de o cometer.

 Esforçava-me por compreender a tese que ouvira professar, de que o livre-arbítrio da vontade é a causa de praticarmos o mal, e de teu reto juízo é a causa do mal que padecemos. Mas era incapaz de entendê-lo com clareza. E esforçando-me por afastar desse abismo os olhos do meu espírito, nele me precipitava de novo, e tentando reiteradamente fugir dele, sempre voltava a recair.

 O fato de eu ter a consciência de possuir uma vontade, como tinha consciência de minha vida, era o que me erguia para a tua luz. Assim, quando queria ou não queria alguma coisa, estava certíssimo de que era eu, e não outro, o que queria ou não queria, e então me convencia de que ali estava a causa do meu pecado. Quanto ao que fazia contra a vontade, notava que isso mais era padecer do mal do que praticá-lo; julgava que isso não era culpa, mas castigo, que me instava a confessar justamente ferido por ti, considerando tua justiça.

 Mas de novo refletia: "Quem me criou? Não foi o bom Deus, que não só é bom, mas a própria bondade? De onde, então, me vem essa vontade de querer o mal e de não querer o bem? Seria talvez para que eu sofra as penas merecidas? Quem depositou em mim, e semeou minha alma esta semente de amargura, sendo eu totalmente obra de meu dulcíssimo Deus? Se foi o demônio que me criou, de onde procede ele? E se este, de anjo bom se fez demônio, por decisão de sua vontade perversa, de onde lhe veio essa vontade má que o transformou em diabo, tendo ele sido criado anjo por um Criador boníssimo?"

 Tais pensamentos de novo me deprimiam e sufocavam, mas não me arrastavam até aquele abismo de erro, onde ninguém te confessa, e onde se antepõe a tese que tu és sujeito ao mal a considerar o homem capaz de o cometer.

## CAPÍTULO IV

### A substância de Deus

 Empenhava-me então por descobrir as outras verdades, como havia descoberto que o incorruptível é melhor que o corruptível, e por isso confessava que tu, qualquer que fosse tua natureza, devias ser incorruptível. Porque ninguém pôde nem poderá jamais conceber algo melhor do que tu, que és o sumo bem por excelência. Por isso, sendo certíssimo e inegável que o incorruptível é superior ao corruptível, o que eu já fazia, meu pensamento já poderia conceber algo melhor do que o meu Deus, se não fosses incorruptível.

 Portanto, logo que vi que o incorruptível deve ser preferido ao corruptível, imediatamente deveria buscar-te no incorruptível, para depois indagar a causa do mal, isto é, a origem da corrupção, que de nenhum modo pode afetar tua substância. É certo que, nem por vontade, nem por necessidade, nem por qualquer acontecimento imprevisto, pode a corrupção afetar nosso Deus, porque ele é Deus, e não pode querer senão o que é bom, e ele próprio é o sumo bem; e estar sujeito à corrupção não é nenhum bem.

 Tampouco poder ser obrigado, contra a tua vontade, seja ao que for, porque tua vontade não é maior do que teu poder. Seria maior caso pudesses ser maior do que és, pois a vontade e o poder de Deus são o mesmo Deus. E que pode haver de imprevisto para ti, se conheces todas as coisas, e se todas elas existem porque as conheces?

 Mas, por que tantas palavras para demonstrar que a substância de Deus não é corruptível, já que se o fosse não seria Deus?

## CAPÍTULO V

### A origem do mal

 Eu buscava a origem do mal, mas de modo errôneo, e não via o erro que havia em meu modo de buscá-la. Desfilava diante dos olhos de minha alma toda a criação, tanto o que podemos ver – como a terra, o mar, o ar, as estrelas, as árvores e os animais – como o que não podemos ver – como o firmamento, e todos os anjos e seres espirituais. Estes, porém, como se também fossem corpóreos, colocados em minha imaginação em seus respectivos lugares. Fiz de tua criação uma espécie de massa imensa, diferenciada em diversos gêneros de corpos; uns, corpos verdadeiros, e espíritos, que eu imaginava como corpos.

 E eu a imaginava não tão imensa quanto ela era realmente – o que seria impossível – mas quanto me agradava, embora limitada por todos os lados. E a ti, Senhor, como a um ser que a rodeava e penetrava por todas as partes, infinito em todas as direções, como se fosses um mar incomensurável, que tivesse dentro de si uma esponja tão grande quanto possível, limitada, e toda embebida, em todas as suas partes, desse imenso mar.

 Assim é que eu concebia a tua criação finita, cheia de ti, infinito, e dizia: "Eis aqui Deus, e eis aqui as coisas que Deus criou; Deus é bom, imenso e infinitamente mais excelente que suas criaturas; e, como é bom, fez boas todas as coisas; e vede como as abraça e penetra! Onde está pois o mal? De onde e por onde conseguiu penetrar no mundo? Qual é a sua raiz e sua semente? E se tememos em vão, o próprio temor já é certamente um mal que atormenta e espicaça sem motivo nosso coração; e tanto mais grave quanto é certo que não há razão para temer. Portanto, ou o mal que tememos existe, ou o próprio temor é o mal. De onde, pois, procede o mal se Deus, que é bom, fez boas todas as coisas? Bem superior a todos os bens, o Bem supremo, criou sem dúvida bens menores do que ele. De onde pois vem o mal? Acaso a matéria de que se serviu para a criação era corrompida e, ao dar-lhe forma e organização, deixou nela algo que não converteu em bem?

 E por que isto? Acaso, sendo onipotente, não podia mudá-la, transformá-la toda, para que não restasse nela semente do mal? Enfim, por que se utilizou dessa matéria para criar? Por que sua onipotência não a aniquilou totalmente? Poderia ela existir contra sua vontade? E, se é eterna, por que deixou-a existir por tanto tempo no infinito do passado, resolvendo tão tarde servirse dela para fazer alguma coisa? Ou, já que quis fazer de súbito alguma coisa, sendo onipotente, não poderia suprimir a matéria, ficando ele só, bem total verdadeiro, sumo e infinito? E, se não era conveniente que, sendo bom, não criasse nem produzisse bem algum, por que não destruiu e aniquilou essa matéria má, criando outra que fosse boa e com a qual plasmar toda a criação? Porque ele não seria onipotente se não pudesse criar algum bem sem a ajuda dessa matéria que não havia criado."

 Tais eram os pensamentos de meu pobre coração, oprimido pelos pungentes temores da morte, e sem ter encontrado a verdade. Contudo, arraigava sempre mais em meu coração a fé de teu Cristo, nosso Senhor e Salvador, professada pela Igreja Católica; fé ainda incerta, certamente, em muitos pontos, e como que flutuando fora das normas da doutrina. Minha alma porém não a abandonava, e cada dia mais se abraçava a ela.

## CAPÍTULO VI

### O absurdo dos horóscopos

Também já havia rechaçado as enganosas predições e ímpios delírios dos astrólogos.

 Ainda por isso, meu Deus, quero confessar-te tuas misericórdias desde o mais íntimo de minha alma! Foste tu, e só tu – pois, quem pode afastar-nos da morte do erro, senão a Vida que desconhece a morte, a Sabedoria que ilumina as pobres inteligências sem precisar de outra luz, e que governa o mundo até as folhas que tremulam nas árvores? Foste tu que medicaste a obstinação com que me opunha ao sábio velho Vindiciano e ao magnânimo jovem Nebrídio, que diziam – o primeiro, com veemência, o segundo com alguma hesitação, mas frequentemente – não existir a tal arte de predizer as coisas futuras, e que as conjecturas dos homens muitas vezes têm concurso do acaso e que, de tanto repetir, acertavam em predizer algumas coisas, sem que os mesmos que as diziam o soubessem.

 Foste tu que me fizeste encontrar um amigo mui afeiçoado a consultar os astrólogos, não entendido nessa ciência, mas que consultava por curiosidade. Conhecia ele uma história, que ouvira do pai, segundo dizia. Ignorava ele até que ponto essa história era valiosa para destruir a autoridade daquela arte.

 Esse homem, chamado Firmino, educado nas artes liberais e instruído na eloqüência, veiome consultar, como amigo íntimo, sobre alguns assuntos nos quais alimentava esperanças mundanas, para ver qual seria meu vaticínio conforme suas constelações, como eles dizem. Eu, que já começara a me inclinar à opinião de Nebrídio, embora não me negasse a fazer-lhe o horóscopo e expor-lhe as suas conclusões, acrescentei, contudo, que estava quase persuadido de que tudo aquilo era ridícula quimera.

 Então, ele me contou que seu pai tinha grande interesse na leitura de tais livros, e que tivera um amigo igualmente apaixonado. Conversando sobre a matéria, empolgaram-se cada vez mais no estudo daquelas tolices, e chegaram ao ponto de observar os momentos do nascimento até dos animais domésticos, notando a posição das estrelas a fim de coligir dados experimentais daquela pseudo-arte.

 Firmino me relatava ter ouvido o pai contar que, estando sua mãe para o dar à luz, também estava grávida uma serva daquele amigo de seu pai, coisa que não poderia passar despercebida a seu senhor, que cuidava com extrema diligência e precisão de conhecer até o parto das cadelas.

 E sucedeu que, contando com o maior esmero os dias, horas e suas menores parcelas, da esposa e da escrava, ambas as mulheres deram à luz no mesmo momento, o que os obrigou a fazer, até em seus menores detalhes os mesmos horóscopos para os nascidos, um para o filho e outro para o pequeno servo.

 Tendo começado o trabalho de parto, informaram um ao outro o que se passava em suas casas, e enviaram mensageiros um ao outro, a fim de anunciar com igual rapidez o nascimento das crianças; e conseguiram-no fazer facilmente, como se o fato se passasse em suas próprias casas. E Firmino contava que os mensageiros que haviam sido enviados vieram a se encontrar à mesma distância de suas respectivas casas, de modo que não se podia notar a menor diferença na posição das estrelas, assim como nas demais frações de tempo. No entanto Firmino, como filho de grande família, corria pelos mais brilhantes caminhos do mundo, crescia em riquezas e era coberto de honras, ao passo que o escravo, sujeito ainda ao jugo da escravidão, tinha que servir a seus senhores, segundo ele próprio contava, pois o conhecia.

 Ouvindo essa história, na qual acreditei pelo crédito que merecia seu narrador – toda minha resistência se quebrou. Esforcei-me em seguida para afastar Firmino daquela vã curiosidade, dizendo-lhe que, pelo seu horóscopo e para ser verdadeiro, deveria certamente considerar a seus pais como os primeiros entre seus concidadãos; o renome da sua família, a mais nobre da cidade; seu nascimento ilustre, sua educação esmerada e seus conhecimentos nas artes liberais. E, pelo contrário, se aquele servo me consultasse sobre o tal horóscopo – que era o mesmo de Firmino – se também tivesse de lhe dizer a verdade – deveria ver nos mesmo signos sua família paupérrima, sua condição servil e tantas outras coisas, tão diferentes e opostas às primeiras.

 Portanto, para dizer a verdade, vendo os mesmos sinais celestes deveria tirar conclusões divergentes, porque fazer prognósticos semelhantes seria mentir.

 De onde concluí, com toda certeza, que as predições verdadeiras não podem atribuir a uma arte, mas ao acaso, e que as falsas não se devem à ignorância dessa arte, mas à mentira do acaso.

 Após esta abertura e nela baseado, ruminava dentro de mim tais coisas, para que nenhum daqueles loucos que buscam nisso o lucro, e a quem eu então desejava refutar e ridicularizar, não me objetasse que Firmino ou o pai podia ter contado mentiras. Voltei pois minha atenção ao caso dos gêmeos, muitos dos quais saem do seio materno com tão breve intervalo de tempo, que por mais que o pretendam importante, não pode ser apreciado pela observação humana, nem pode ser considerado nos signos que o astrólogo lançará mão para fazer uma previsão certa. Mas os vaticínios não serão verdadeiros pois, vendo os mesmos signos, deveria predizer a mesma sorte para Esaú e Jacó, sendo que os sucessos da vida de ambos foram muito diversos.

 O astrólogo, portanto, deveria prognosticar coisas falsas, ou, no caso de falar coisas verdadeiras, estas forçosamente deveriam ser diferentes, a despeito da identidade das observações. Logo, se seus prognósticos fossem verdadeiros, não o seriam por efeito da arte, mas do acaso. Porque tu, Senhor, governador justíssimo do Universo, por inspiração secreta, desconhecida dos consulentes e astrólogos, fazes que cada um ouça a resposta que lhe convém, de acordo com os méritos das almas, do fundo do abismo de teu justo juízo. E que o homem não se atreva a dizer: Que é isto? Por que isto? Não o diga, não o diga, porque é um simples homem.

## CAPÍTULO VII

### Ainda a origem do mal

 Deste modo, ó meu auxílio, já me havias libertado daqueles grilhões. Contudo eu buscava ainda a origem do mal, e não encontrava solução. Mas não permitias que as vagas de meu pensamento me apartassem da fé. Fé na tua existência, na tua substância imutável, na tua providência para os homens, e na tua justiça que os julgará. Já acreditava que traçaste o caminho da salvação dos homens, rumo à vida que sobrevém depois da morte, em Cristo, teu Filho e Senhor nosso, e nas Sagradas Escrituras, recomendadas pela autoridade de tua Igreja Católica.

 Salvas e fortemente arraigadas estas verdades em meu espírito, buscava eu ansiosamente a origem do mal. E que tormentos, como que de parto, eram aqueles de meu coração! Que gemidos, meu Deus! E ali estavam teus ouvidos atentos, e eu não o sabia. Quando, em silêncio, me esforçava em pacientes buscas, altos clamores se elevavam até tua misericórdia: eram as silenciosas angústias de minha alma.

 Tu só sabes o que eu padecia, mas homem algum o sabia. De fato, quão pouco era o que minha palavra transmitia aos meus amigos mais íntimos! Chegava, porventura, a eles o tumulto de minha alma, que nem o tempo, nem as palavras bastavam para declarar? Contudo, chegavam a teus ouvidos as queixas que em meu coração rugiam, e meu desejo estava diante de ti, mas a luz de meus olhos não estava contigo, porque ela estava dentro, e eu olhava para fora. Ela não ocupava espaço algum, e eu só pensava nas coisas que ocupam lugar, e não achava nelas lugar de descanso, nem me acolhiam de modo que pudesse dizer: "Basta, Aqui estou bem!" – Nem me permitiam que eu fosse para onde me sentisse satisfeito. Eu era superior a estas coisas, mas sempre inferior a ti. Serias minha verdadeira alegria se eu te fosse submisso, pois sujeitasse a mim tudo o que criaste inferior a mim. Tal seria o justo equilíbrio e a região central de minha salvação: permanecer como imagem tua, e servindo-te, ser o senhor de meu corpo. Mas, como me levantei soberbamente contra ti, investindo contra meu Senhor coberto com o escudo de minha dura cerviz, até mesmo as criaturas inferiores se fizeram superiores a mim, e me oprimiam, e não me davam um momento de alívio e de descanso.

 Quando as olhava, elas me vinham ao encontro atabalhoadamente de todos os lados; mas quando nelas me concentrava, tais imagens corporais me barravam para que me retirasse, como se me dissessem: "Para onde vais, indigno e impuro?" E estas recobravam forças com a minha chaga, porque humilhaste o soberbo como a um homem ferido. Minha presunção me separava de ti, e meu rosto de tão inchado, fechava meus olhos.

## CAPÍTULO VIII

### A piedade de Deus

Mas tu, Senhor, permaneces eternamente, e não te iras eternamente contra nós, porque te compadeceste da terra e do pó, e foi de teu agrado corrigir minhas deformidades. Tu me aguilhoavas com estímulos interiores para que estivesse impaciente, até que por uma visão interior, te tornasses para mim uma certeza. O inchaço de meu orgulho baixava graças à mão secreta de tua medicina; a vista de minha alma, perturbada e obscurecida, ia sarando dia a dia graças ao colírio das dores salutares.

## CAPÍTULO IX

### Agostinho e o neoplatonismo

 Primeiramente, querendo tu mostrar-me como resistes aos soberbos e dás tua graça aos humildes, e com quanta misericórdia ensinaste aos homens o caminho da humildade, por se ter feito carne teu Verbo, e ter habitado entre os homens, me fizeste chegar às mãos por meio de um homem inchado de monstruoso orgulho, alguns livros dos platônicos, traduzidos do grego para o latim.

 Neles eu li – não com estas palavras, mas substancialmente o mesmo e expresso com muitos e diversos argumentos – que "no princípio era o Verbo, e o Verbo estava com Deus, e o Verbo era Deus. Este estava desde o princípio em Deus. Todas as coisas foram feitas por ele, e sem ele nada foi feito do que foi feito. O que foi feito é vida nele, e a vida era a luz dos homens. E a luz brilha nas trevas, mas as trevas não a compreenderam. Diziam também que a alma do homem, embora dê testemunho da luz, não é a luz, mas o Verbo, Deus, é a verdadeira luz, que ilumina a todo homem que vem a este mundo. E que neste mundo estava, e que o mundo é criatura sua, e que o mundo não o conheceu.

 E que ele veio para sua morada, e que os seus não o receberam, e que a quantos o receberam deu o poder de se fazerem filhos de Deus, desde que acreditem em seu nome, isto não o li nesses livros.

 Também neles li que o Verbo, Deus, não nasceu da carne nem do sangue, nem da vontade do varão, mas de Deus. Mas que o Verbo se fez carne, e habitou entre nós, isso não o li naqueles livros.

 Igualmente achei nesses livros, dito de diversos e múltiplos modos, que o Filho, consubstancial ao Pai, não considerou usurpação ser igual a Deus, porque o é por natureza. Não dizem porém que se aniquilou a si mesmo, tomando a forma de escravo, que se fez semelhante aos homens, sendo julgado homem por seu exterior; e que se humilhou, fazendo-se obediente até a morte, e morte de cruz, pelo que Deus o ressuscitou entre os mortos, e lhe deu um nome acima de todo nome, para que ao nome de Jesus se dobrem todos os joelhos no céu, na terra e no inferno, e toda língua confesse que o Senhor Jesus está na glória de Deus Pai.

 Neles se diz também que antes e sobre todos os tempos, teu Filho único permanece imutável, eterno consigo, e que de sua plenitude recebem as almas para sua bem-aventurança e que, para serem sábias, são renovadas participando da sabedoria que permanece em si mesma. Mas não se encontra escrito ali que morreu, no tempo marcado, pelos ímpios, e que não perdoaste a teu Filho único, mas que o entregaste por todos nós. Porque escondeste estas coisas aos sábios e as revelastes aos humildes, a fim de que os atribulados e sobrecarregados viessem a ele, para que os reconfortasse, porque ele é manso e humilde de coração. Dirige os pequenos na justiça e ensina aos mansos seu caminho, vendo nossa humildade e nosso trabalho, e perdoando todos os nossos pecados.

 Mas aqueles que, erguendo-se sobre uma doutrina, digamos, mais sublime, não ouvem ao que lhes diz: Aprendei de mim que sou manso e humilde de coração, e encontrareis descanso para vossas almas. E ainda que conheçam a Deus, não o glorificam como Deus, nem lhe dão graças, mas se desvanecem em seus pensamentos, e seu coração insensato se obscurece; e dizendo que são sábios, se tornam estultos.

 E por isso lia também nesses livros que a glória de tua natureza incorruptível havia sido transformada em ídolos e simulacros de todo tipo, à semelhança da imagem do homem corruptível, das aves, dos quadrúpedes e serpentes. Isto é, naquele alimento do Egito pelo qual Esaú perdeu sua primogenitura. Israel, teu povo primogênito, voltando o coração para o Egito, honrou em teu lugar a cabeça de um quadrúpede, curvando tua imagem, isto é, a própria alma, diante da imagem de um bezerro comendo feno.

 É o que encontrei nesses livros, mas delas não me alimentei, porque agradou-te, Senhor, tirar de Jacó o opróbrio de sua inferioridade, para que o maior servisse ao menor, chamando os gentios para tua herança.

 Também eu vinha dentre os gentios para ti, e interessei-me pelo ouro que, por tua vontade, teu povo trouxera do Egito, pois era teu onde quer que estivesse. E disseste aos atenienses, por boca de teu Apóstolo, que em ti vivemos, nos movemos e temos nosso ser, como alguns deles o disseram, e é deles que vinham os livros que me ocupavam. Mas não me fixei nos ídolos dos egípcios, aos quais sacrificavam, com teu ouro, os que mudaram a verdade de Deus em mentira, adorando e servindo ante à criatura do que ao Criador.

## CAPÍTULO X

### A descoberta de Deus

 Estimulado por estas leituras a voltar a mim mesmo, entrei, guiado por ti, no profundo de meu coração, e o pude fazer porque te fizeste minha ajuda. Entrei, e vi com os olhos da alma, acima desses mesmos olhos, acima de minha inteligência, a luz imutável; não esta vulgar e visível a todos os olhos de carne, nem outra do mesmo gênero, embora maior. Era muito mais clara e enchendo com sua força todo o espaço. Não, não era esta luz, mas uma luz diferente de todas estas.

 Ela não estava sobre meu espírito como o azeite sobre a água, como o céu sobre a terra, mas estava acima de mim porque me criou; eu lhe era inferior por ter sido criado por ela. Quem conhece a verdade conhece a luz, e quem a conhece, conhece a eternidade. O amor a conhece!

 Ó eterna verdade, amor verdadeiro, amada eternidade! Tu és meu Deus. Por ti suspiro dia e noite. Quando te conheci pela primeira vez, ergueste-me para me fazer ver que havia algo para ser visto, mas que eu ainda era incapaz de ver. E deslumbraste a fraqueza de minha vista com o fulgor do teu brilho, e eu estremeci de amor e temor. Pareceu-me estar longe de ti numa região desconhecida, como se ouvira tua voz do alto: "Sou o pão dos fortes; cresce, e comer-me-ás. Não me transformarás em ti, como fazes com o alimento da tua carne, mas tu serás mudado em mim".

 E conheci então que "castigaste o homem por causa de sua iniqüidade", e "que secaste minha alma como uma teia de aranha", e eu disse: Porventura não existe a verdade, por não ser difusa pelos espaços finitos e infinitos? E tu me gritaste de longe: Na verdade, Eu sou o que sou. E eu ouvi como se ouve no coração, sem deixar motivo para dúvidas; antes, mais facilmente duvidaria de minha vida que da existência da verdade, que se manifesta à inteligência pelas coisas da criação.

## CAPÍTULO XI

### Deus e as criaturas

 E contemplei as outras coisas que estão abaixo de ti, e vi que nem existem absolutamente, e nem absolutamente deixam de existir. Certamente existem, porque procedem de ti; mas não existem, pois, não são o que tu és,, porque só existe verdadeiramente o que permanece imutável. Com isso, para mim é bom apegar-me a Deus, porque, se não permanecer nele, tampouco poderei permanecer em mim. ele, porém, permanecendo em si, renova todas as coisas, e tu és o meu Senhor, porque não necessitas de meus bens.

## CAPÍTULO XII

### O mal e o bem da criação

 Também pode entender que são boas as coisas que se corrompem. Se fossem sumamente boas, não poderiam se corromper, como tampouco o poderiam se não fossem boas de algum modo. Com efeito, se fossem sumamente boas, seriam incorruptíveis; e se não tivessem nenhuma bondade, nada haveria nelas que se pudesse corromper. Porque a corrupção é um mal, e não poderia ser nociva se não diminuísse o bem real. Logo, ou a corrupção é inofensiva, o que é impossível, ou, o que é certo, tudo o que se corrompe é privado de algum bem. E assim, se algo for privado de todo o bem, deixará totalmente de existir. E se algo subsistisse sem já poder ser corrompido, seria ainda melhor, porque permaneceria incorruptível. E haverá maior absurdo do que afirmar que uma coisa se torna melhor pela perda de todo o bem? Logo, ser privado de todo o bem é o nada absoluto. De onde se segue que, enquanto as coisas existem, elas são boas. Portanto, tudo o que existe é bom; e o mal, cuja origem eu procurava, não é uma substância, porque se o fosse seria um bem. De fato, ou ele seria substância incorruptível, e portanto um grande bem; ou seria uma substância corruptível, que se não se poderia corromper se não fosse boa.

 Vi pois, e foi para mim evidente, que tu eras o autor de todos os bens, e que não há em absoluto substância alguma que não tenha sido criada por ti. E como não as fizeste todas iguais, toas as coisas existem, porque cada uma por si é boa, e todas juntas muito boas, porque nosso Deus fez todas as coisas muito boas.

## CAPÍTULO XIII

### Os louvores da criação

 E para ti, Senhor, não existe absolutamente o mal; e nem para universalidade da tua criação; porque nada existe fora dela, capaz de romper ou de corromper a ordem que tu lhe impuseste. Todavia, em algumas de suas partes, determinados elementos não se harmonizam com outros, e estes são considerados maus. Mas, como esses mesmos elementos combinam com outros, são da mesma forma bons, e bons em si mesmos. E mesmo esses elementos que não concordam entre si se harmonizam com a parte inferior das criaturas que chamamos terra, com seu céu cheio de nuvens e de ventos, como lhe é conveniente.

 Longe de mim dizer: Oxalá não existissem estas coisas! – Embora, considerando-as separadamente, eu as desejasse melhores, somente o fato de existirem deveria bastar para eu te louvar porque o proclamam os dragões da terra e todos os abismos; o fogo, o granizo, a neve, o vento da tempestade, que executam tuas ordens; os montes e todas as colinas; as árvores frutíferas e todos os cedros; as feras e todos os gados; os répteis e todas as aves; os reis da terra e todos os povos; os príncipes e todos os juízes da terra, os jovens e as virgens, os anciões e as crianças; todos louvam teu nome.

 Mas como também do alto dos céus é louvado, que seja louvado o nosso Deus, lá no alto por todos os teus anjos, todas as potestades, o sol e a lua, todas as estrelas e a luz, os céus dos céus, e a águas que estão sobre os céus glorificam teu nome, eu já não desejava nada melhor, porque, considerando o todo, os elementos superiores me pareciam sem dúvida melhores que os inferiores; mas um julgamento mais sadio me fazia considerar o todo melhor que os elementos superiores tomados à parte.

## CAPÍTULO XIV

### Recapitulação

 Não têm juízo sadio, nos que se desagradam com alguma parte de tua criação, como acontecia comigo, quando me desagradavam tantas de tuas obras. Mas, como minha alma não se atrevia a desgostar do meu Deus, não queria considerar como obra tua o que lhe desagradava.

 Por isso fora atrás da teoria das duas substâncias, na qual não achava descanso, e repetia coisas alheias. Desembaraçando-me desses erros, imaginara para si um Deus que se difundia pelos espaços infinitos e, julgando que eras tu, colocou-o em seu coração, e de novo se tornou o templo de seu ídolo, coisa abominável a teus olhos.

 Mas, depois que afagaste minha cabeça, sem que eu o percebesse, e fechaste meus olhos para não vissem a vaidade, desprendi-me um pouco de mim mesmo, e minha loucura adormeceu profundamente; quando despertei em teus braços, vi que eras infinito não daquele modo, e esta visão não procedia da carne.

## CAPÍTULO XV

### Deus e a criação

 Contemplei depois as outras coisas, e vi que deviam a ti sua existência, e que todas estão contidas em ti, não como em um lugar material, mas de modo diferente: conservas todas elas em tua verdade, sustentadas na tua mão; todas as coisas são verdadeiras enquanto existem, e só é falso o que julgamos existir, mas não existe.

 Também vi que cada coisa adapta-se não só a seus lugares, mas também a seus tempos, e que tu, que és o único eterno, não começaste a agir depois de infinitos espaços de tempos, porque todos os espaços de tempo – passados ou futuros – não teriam passado nem viriam se tu não agistes e não fosses permanente.

## CAPÍTULO XVI

### Onde está o mal

 Entendi por experiência que não é de admirar que o pão seja enjoativo ao paladar enfermo, mesmo tão agradável para o paladar sadio, e que olhos enfermos considerem odiosa a luz, que para os límpidos é tão cara. Se tua justiça desagrada aos maus, muito mais desagradam a víbora e o caruncho, que criaste bons e adaptados à parte inferior da tua criação, com a qual também os maus se assemelham, tanto mais quanto mais diferem de ti, assim como os justos se assemelham às partes superiores do mundo na medida em que se assemelham a ti.

 Indaguei o que era a iniqüidade, e não achei substância, mas a perversão de uma vontade que se afasta da suprema substância, de ti, meu Deus – e se inclina para as coisas baixas, e que derrama suas entranhas, e se intumesce exteriormente.

## CAPÍTULO XVII

### Caminho para Deus

 Admirava-me de já te amar, e não a um fantasma em teu lugar, mas não era estável no gozo de meu Deus. Era arrebatado a ti por tua beleza, e logo afastado de ti pelo meu peso, que me precipitava sobre a terra a gemer. Meu peso eram os hábitos carnais. Mas tua lembrança me acompanhava. Nem absolutamente duvidava da existência de um ser a quem eu devia me unir, embora não estivesse apto para esta união, porque o corpo, que se corrompe, sobrecarrega a alma, e a morada terrena oprime o espírito carregado de cuidados. Estava certíssimo de que tuas belezas invisíveis se descobrem à inteligência desde a criação do universo, por meio de tuas obras; bem como teu poder eterno e tua divindade.

 Buscava saber de onde me vinha minha faculdade de apreciar a beleza dos corpos – quer celestes, quer terrenos – e o que me permitia julgar rápida e cabalmente das coisas mutáveis quando dizia: "Isto deve ser assim, aquilo não deve ser assim". Procurando a origem de minha faculdade de julgar quando assim julgava, achei a eternidade imutável e verdadeira, acima de meu espírito mutável.

 E, gradualmente, fui subindo dos corpos para a alma, que sente por meio do corpo; e dela à sua força interior, à qual os sentidos comunicam as coisas exteriores, que é o limite alcançado pelos animais. Daqui passei para o poder do raciocínio, ao qual cabe julgar as percepções dos sentidos corporais; por sua vez, julgando-se sujeito a mudanças, levantou-se até a sua própria inteligência, e afastou o pensamento de suas cogitações habituais. Livrou-se da multidão de fantasmas contraditórios, para descobrir que luz a inundava quando, sem nenhuma dúvida, afirmava que o imutável deve ser preferido ao mutável; e também de onde lhe vinha o conhecimento do próprio imutável, porque, se não tivesse dele alguma noção, nunca o preferiria ao mutável com tanta certeza. E, finalmente, chegou àquele que é um único lampejo.

 Foi então que tuas perfeições invisíveis se manifestaram à minha inteligência por meio de tuas obras. Mas não pude fixar nelas meu olhar; minha fraqueza se recobrou, e voltei a meus hábitos, não levando comigo senão uma lembrança amorosa e, por assim dizer, o desejo do perfume do alimento saboroso que eu ainda não podia comer.

## CAPÍTULO XVIII

### A senda da humildade

 Buscava um meio que me desse força necessária para gozar de ti, e não a encontrei enquanto não me abracei ao Mediador entre Deus e os homens, o homem Cristo Jesus, que está sobre todas as coisas, Deus bendito por todos os séculos, que chama e diz: Eu sou o caminho, a verdade e a vida. Ele une o alimento à carne (alimento que eu não tinha forças para tomar), porque o Verbo se fez carne, para que tua Sabedoria, pela qual criaste todas as coisas, fosse o leite de nossa infância.

 Não tendo humildade, eu não possuía Jesus, o Deus da humildade, e não atinava o que nos poderia ensinar sua fraqueza. Porque teu Verbo, verdade eterna, dominando as criaturas mais sublimes da tua criação, levanta a si as que se lhe sujeitam e, nas partes inferiores, construiu para si, com o nosso lodo, uma humilde morada. Assim faz para humilhar e arrancar de si mesmos aqueles que deseja sujeitar e atrair, curando-lhes a soberba e alimentando-lhes o amor, para que, confiando em si, não se afastem para mais longe. Pelo contrário, que se humilhem, vendo a seus pés a humildade de um Deus que também se vestiu de nossa túnica de carne, e cansados, se prostrem diante dela para que, ao se levantar, os exalte.

## CAPÍTULO XIX

### A doutrina do verbo

 Mas eu então julgava de outro modo. Considerava meu Senhor Jesus Cristo apenas um homem de extraordinária sabedoria, a quem ninguém poderia igualar. Sobretudo seu miraculoso nascimento de uma virgem, que nos ensina a desprezar os bens temporais para adquirir a imortalidade. Parecia-me ter merecido, por decreto da Providência divina, uma soberana autoridade para ensinar os homens.

 Mas nem suspeitava o mistério que se encerra nestas palavras: o Verbo se fez carne. Somente conhecia, pelas coisas que dele nos deixaram escritas, que comeu, bebeu, dormiu, passeou, que se alegrou, se entristeceu e pregou, e que essa carne não se juntou a teu Verbo senão com alma e inteligência humanas. Tudo isso sabe quem conhece a imutabilidade de teu Verbo, que eu já conhecia quanto me era possível, sem que disso nada duvidasse. Com efeito, mover os membros do corpo à vontade, ou não movê-los, estar dominado por algum afeto ou não o estar, traduzir por palavras sábios pensamentos e depois calar, são caracteres próprios da mutabilidade da alma e da inteligência. Se esses testemunhos das Escrituras fossem falsos, tudo o mais correria o risco de ser mentira, e o gênero humano não teria mais nesses livros a fé, condição de salvação. Mas como são verdadeiras as coisas nela escritas, eu reconhecia em Cristo um homem completo, não somente o corpo de um homem, ou um corpo sem uma alma inteligente, mas um homem real, que eu julgava superior a todos os outros não por ser a personificação da verdade, mas em razão da singular excelência de sua natureza humana, e de uma mais perfeita participação na sabedoria.

 Alípio porém pensava que os católicos, crendo em um Deus revestido de carne, entendiam quem eu em Cristo, além de Deus e da carne, não havia alma humana; e não julgava que lhe atribuíssem inteligência humana. E como estava bem persuadido de que os atos atribuídos tradicionalmente a Cristo não podiam ser senão obras de um criatura cheia de vida e de inteligência, Alípio se aproximava com certa relutância da fé cristã. Mas depois, ao saber que este erro era próprios dos hereges apolinaristas, aderiu alegremente à fé católica.

 De minha parte, confesso que só aprendi mais tarde a diferença de interpretação das palavras "o Verbo se fez carne", entre a verdade católica e o erro do Fotino (bispo de Sírmio, afirmava que o Verbo não havia sido Filho de Deus até encarnar-se nas entranhas da Virgem Maria, negando toda união substancial entre a natureza humana e o Verbo divino). A reprovação dos hereges põe às claras o pensamento da tua Igreja e o que esta considera como doutrina sã. Convém pois que haja heresias, para que os fortes se distingam entre os fracos.

## CAPÍTULO XX

### Do platonismo às Escrituras

 Depois de ter lido aqueles livros dos platônicos, induzido por eles a buscar a verdade incorpórea, começaram a se tornarem patentes, por meio de tuas obras, tuas perfeições visíveis. Repelido para longe de ti, compreendi em que consistia essa verdade, que as trevas de minha alma me impediam de contemplar. Estava certo de tua existência e de que és infinito, sem contudo te estenderes por espaços finitos ou infinitos; e de que és verdadeiramente aquele que é sempre idêntico a si mesmo, sem te mudares em outro, nem sofrer alteração alguma, quer parcialmente ou com algum movimento, quer de qualquer outro modo; e de que tudo o mais vem de ti, pela única e irrefutável razão de que existe. Tinha certeza de todas estas verdades, mas me achava ainda demasiado fraco para gozar de ti. Tagarelava muito, como se fora competente nisso, mas se não procurasse o caminho da verdade em Cristo, nosso Salvador, não seria perito, mas perituro. Já começava a querer parecer sábio, cheio de meu castigo, e não chorava, mas orgulhava-me com a ciência. Onde estava aquela caridade erigida sobre o alicerce da humildade, que é Cristo Jesus? Ou talvez me a ensinariam aqueles livros? Creio que quiseste que com eles me encontrasse antes de meditar nas tuas Escrituras, para que fixassem em minha memória os afetos que nela experimentei. Depois, quando encontrasse em teus livros a paz do coração, sarada com tuas mãos as feridas de minha alma, pudesse discernir e perceber a diferença entre presunção e humildade, entre os que vêem para onde se deve ir, e não vêem por onde se vai, nem o caminho que conduz à pátria bem-aventurada, não só para contemplá-la, mas também para habitá-la.

 Porém, se me tivesse instruído em tuas sagradas letras, e em sua intimidade tivesse experimentado na doçura, para depois conhecer os livros dos platônicos, talvez eles me arrancassem dos sólidos fundamentos da piedade; ou, se eu tivesse persistido nos sentimentos salutares nelas hauridos, talvez julgasse que só por esses livros se poderia chegar ao mesmo proveito espiritual.

## CAPÍTULO XXI

### A verdade das escrituras

 Por isso lancei-me avidamente sobre as veneráveis escrituras inspiradas por teu Espírito, sobretudo ao do apóstolo Paulo. E desnaveceram em mim aquelas dificuldades nas quais julguei descobrir contradições entre ele e seu texto, em desacordo com os testemunhos da Lei e dos Profetas. Compreendi a unidade daqueles castos escritos, e aprendi a me alegrar com tremor.

 Comecei a lê-los e compreendi que tudo de verdadeiro que lera nos tratados dos neoplatônicos se encontrava ali, mas com o aval da tua graça, para que aquele que vê não se glorie como se não houvesse recebido não só o que vê, mas também a faculdade de ver. Com efeito, que tem ele que não tenha recebido? E tu, que és imutável, não só o alertas para que te veja, mas também para que seja curado, para te possuir. Aquele que está muito longe de te ver, tome, contudo, o caminho para chegar a ti, para te ver e te possuir.

 Porque, embora o homem se deleite com a lei de Deus, segundo o homem interior, que fará dessa outra lei que luta em seus membros contra a lei de seu espírito, e que o prende sob a lei do pecado, impressa em seus membros? Porque tu és justo, Senhor; nós, porém, pecamos, cometemos iniqüidades; procedemos como ímpios, e tua mão se fez pesada sobre nós, e é com justiça que fomos entregues ao pecador antigo, ao príncipe da morte, porque ele persuadiu nossa vontade a se conformar à sua, que não quis persistir com tua verdade.

 Que fará esse homem infeliz? Quem o livrará deste corpo de morte, senão tua graça, por Jesus Cristo, nosso Senhor, a quem tu geraste co-eterno e criaste no princípio de teus caminhos, ele, em quem o príncipe deste mundo não achou nada que merecesse a morte, e a quem, contudo, matou? Com o que foi anulada a sentença que havia contra nós?

 Nada disso dizem os livros platônicos. Nem têm naquelas páginas esse sentimento de piedade, as lágrimas da confissão, esse teu sacrifício, a alma abatida, esse coração contrito e humilhado, nem a salvação de teu povo, nem a cidade prometida, nem o penhor do Espírito Santo, nem o cálice de nossa redenção.

 Nos livros platônicos ninguém canta: "Minha alma não estará sujeita a Deus? Porque dele procede minha salvação, pois é meu Deus e meu amparo, do qual não mais me apartarei.

 Ninguém ali ouvi o convite: Vinde a mim os que sofreis. Desdenham teus ensinamentos, porque és manso e humilde de coração. Porque escondeste estas coisas dos sábios e doutos, e as revelaste aos pequeninos.

 Uma coisa é ver de um monte agreste a pátria da paz, e não encontrar o caminho que conduz a ela, e fatigar-se debalde por lugares inacessíveis, entre ataques e emboscadas dos desertores fugitivos, com seu chefe, o leão e o dragão, e outra coisa é conhecer o caminho que conduz até lá, defendido pelos cuidados do imperador celeste, e onde não roubam os desertores da milícia do céu, pois eles o evitam como um suplício.

 Esses pensamentos penetravam-me as entranhas de modo maravilhoso, quando eu lia o menor de teus apóstolos. Considerava tuas obras e enchia-me de assombro.

# LIVRO OITAVO

## CAPÍTULO I

### Hesitações

 Faze, meu Deus, que eu recorde de ti em ação de graças, e proclame tuas misericórdias para comigo. Que meus ossos se penetrem do teu amor, e digam: Senhor quem semelhante a ti? Rompeste com grilhões, e te oferecerei um sacrifício de louvor. Contarei como os rompeste, e todos os que te adoram exclamarão quando me ouvirem: "Bendito seja o Senhor no céu e na terra! Grande e admirável é seu nome!

 Tuas palavras, Senhor, tinham-me gravado profundamente em meu coração, e me via cercado apenas por ti de todos os lados. Tinha certeza de tua vida eterna, embora apenas a visse em enigma e como em espelho. Já fora dissolvida toda dúvida quanto à tua substância incorruptível, ao saber que toda substância procedia dela. E o que desejava não era tanto estar mais certo de ti, mas mais firme em ti.

 Quanto à minha vida temporal, estava eu ainda vacilante, e era necessário que meu coração se purificasse do velho fermento. O caminho certo, que é o próprio Salvador, me encantava, mas titubeava ainda em caminhar por seus estreitos desfiladeiros.

 Então me inspiraste a idéia – que me pareceu excelente – de me dirigir a Simpliciano, que eu tinha como um de teus bons servidores, em quem brilhava tua graça. Sobre ele ouvira também que desde sua juventude te consagrava devotamente sua vida, e como já encanecia, achei que em tão longa vida, dedicada ao estudo de teus caminhos, teria acumulado grande experiência e instrução; e de fato assim era. Por isso queria confiar-lhe minhas inquietações, para que me apontasse o modo de vida mais idôneo de alguém, com minhas disposições interiores, seguir teu caminho.

Vi tua Igreja cheia de fiéis que, por um caminho ou por outro, progrediam.

 Quanto a mim, aborrecia-me a vida que levava no mundo, e era para mim fardo pesadíssimo, agora que os apetites mundanos, como a esperança de honras e riquezas, já não me animavam para suportar tão pesada servidão. Essas paixões haviam perdido para mim o encanto, diante de tua doçura e da beleza de tua casa, que já amava. Mas sentia-me ainda fortemente amarrado à mulher. Sem dúvida o Apóstolo não me proibia de casar, embora em seu ardente desejo de ver todos os homens semelhantes a ele, exortasse a um estado mais elevado. Mas eu, ainda muito fraco, escolhia a condição mais fácil; por isso, vivia hesitando em tudo o mais, e me desgastava com preocupações enervantes, pois a vida conjugal, a que me julgava destinado e obrigado, ter-me-ia obrigado a novas incumbências, que eu não queria suportar.

 Ouvira da boca da própria Verdade que há eunucos que mutilavam a si próprios por amor ao reino dos céus, embora acrescentando que o compreenda quem o puder compreender. São vãos, por certo, todos os homens nos quais não reside a ciência de Deus, e que nas coisas visíveis não puderam achar aquele que é. Mas eu já me livrara dessa vaidade, já a havia ultrapassado, e pelo testemunho de tua criação, te encontrara a ti, nosso Criador, e a teu Verbo, Deus em ti, e contigo um só Deus, por quem criaste todas as coisas.

 Há ainda outra espécie de ímpios; os que, conhecendo a Deus, não o glorificam como Deus, nem lhe renderam graças. Eu também tinha caído nesse pecado; mas tua destra me amparou e libertou, colocando-me em lugar onde me pudesse curar; e disseste ao homem: Eis que a piedade é a sabedoria. E ainda: Não queiras parecer sábio, porque os que se dizem sábios tornaram-se insensatos.

 Já havia encontrado, finalmente, a pérola preciosa, que devia comprar vendendo tudo o que possuía. Mas ainda hesitava.

## CAPÍTULO II

### Visita a Simpliciano. Conversão de Vitorino

 Fui ter pois com Simpliciano, pai espiritual do então bispo Ambrósio, que o amava verdadeiramente como pai. Contei-lhe os labirintos do meu erro. E quando lhe disse que havia lido alguns livros dos platônicos, traduzidos para o latim por Vitorino, outrora retórico em Roma – e do qual ouvira dizer que morrera cristão – ele me felicitou por não ter caído nas obras de outros filósofos, falazes e enganosas, segundo os elementos deste mundo, mas apenas estes, que insinuam por mil modos a Deus e a seu Verbo.

 Depois, para me exortar à humildade de Cristo, escondida aos sábios e revelada aos humildes, evocou a lembrança do próprio Vitorino, que conhecera intimamente, quando estava em Roma. Não guardarei silêncio sobre o que me contou dele, porque me dará azo de proclamar os grandes louvores de tua graça a seu respeito. Esse erudito ancião, profundo conhecedor de todas as ciências liberais, leitor e crítico de tantos livros de filosofia, fora mestres de muitos nobres senadores. O prestígio de seu magistério lhe valera uma estátua no foro romano, que ele aceitara (coisa que os cidadãos desse mundo têm em grande conta). Até aquela idade avançada, havia adorado os ídolos, participando de cultos sacrílegos, de que participava quase toda a nobreza romana da época que inspirava ao povo sua devoção por Osíris, por "toda sorte de monstros divinizados, pelo labrador Anúbis", monstros que outrora "pegaram em armas contra Netuno, Vênus e Minerva", e a quem, vencidos, a própria Roma dirigia súplicas, esse velho Vitorino, que durante tantos anos havia defendido esses deuses com sua terrível eloqüência, não se envergonhou de se tornar servo de teu Cristo e criança de tuas águas, dobrando o pescoço ao jugo da humildade, e dobrando sua fronte ante o opróbrio da cruz.

 Senhor, Senhor, que inclinaste os céus e o desceste, que tocaste os montes e estes fumegaram, de que modo te insinuaste naquele coração?

 Segundo contou-me Simpliciano, Vitorino lia as Escrituras e investigava e esquadrinhava com grande curiosidade toda a literatura cristã, e confiava a Simpliciano, não em público, mas muito em segredo e familiarmente: "Sabes que já sou cristão?" Ao que respondia aquele: "Não hei de acreditar, nem te contarei entre os cristãos enquanto não te vir na Igreja de Cristo". Mas ele ria e dizia: "Serão pois as paredes que fazem os cristãos?" E isto, de que já era cristão, o dizia muitas vezes, contestando-lhe Simpliciano outras tantas vezes com a mesma resposta, opondo-lhe sempre Vitorino o gracejo das paredes.

 Vitorino receava desgostar a seus amigos, os soberbos adoradores dos demônios, julgando que estes, de alto de sua babilônica dignidade, como cedros do Líbano, ainda não abatidos pelo Senhor, fariam cair sobre ele suas pesadas inimizades.

 Mas depois que hauriu forças nas leituras e orações, temeu ser renegado por Cristo diante de seus anjos, se tivesse medo de o confessar diante dos homens. Sentiu-se réu de um grande crime por se envergonhar dos mistérios de humildade de teu Verbo, não se envergonhando do culto sacrílego de demônios soberbos, que ele próprio aceitara como soberbo imitador; envergonhou-se da vaidade, e enrubesceu diante da verdade. De repente, disse a Simpliciano, segundo este mesmo contava: "Vamos à Igreja; quero me tornar cristão". Simpliciano, não cabendo em si de alegria, foi com ele. Recebidos os primeiros sacramentos da religião, não muito depois, deu seu nome para receber o batismo que renegara, causando admiração em Roma e alegria na Igreja. Viram-no os soberbos, e se iraram; rangiam os dentes e se consumiam de raiva. Mas teu servo havia posto no Senhor Deus sua esperança, e não tinha mais olhos para as vaidades e as enganosas loucuras.

 Enfim, chegou a hora da profissão de fé. Em Roma, os que se preparam para receber tua graça, pronunciam de um lugar elevado, diante dos fiei, formulas consagradas aprendidas de cor. Os presbíteros, dizia-me Simpliciano, propuseram a Vitorino que recitasse a profissão de fé em segredo, como era costume fazer com os que poderiam se perturbar pela timidez. Mas ele preferiu confessar sua salvação na presença da plebe santa, uma vez que nenhuma salvação havia na retórica que ensinara publicamente. Quanto menos, pois, devia temer diante de tua mansa grei pronunciar tua palavra, ele que não havia temido as turbas insanas em seus discursos!

 Assim, logo que subiu à tribuna para dar testemunho da sua fé, em uníssono, conforme o iam conhecendo, todos repetiram seu nome como num aplauso – e quem ali não o conhecia? – e um grito reprimido, saiu da boca de todos os que se alegravam: "Vitorino! Vitorino!" Ao verem-no, se puseram a gritar de júbilo, mas logo emudeceram pelo desejo de ouvi-lo. Vitorino pronunciou sua profissão de verdadeira fé com grande firmeza, e todos queriam raptá-lo para dentro de seus corações. E realmente o fizeram: seu amor e alegria eram as mãos que o arrebatavam.

## CAPÍTULO III

### A alegria das coisas perdidas

 Bom Deus, que se passa no homem para que se alegre mais com a salvação de uma alma desesperada, quando salva de grande perigo, do que se ela sempre tivesse tido esperança, ou se o perigo tivesse sido menor? Também tu, Pai misericordioso, sentes mais alegria por um pecador arrependido do que por noventa e nove justos que não têm necessidade de penitência. Grande é o nosso prazer ao falar da alegria do pastor trazendo de volta sobre os ombros a ovelha desgarrada, e da mulher que repõe em teus tesouros, para satisfação geral dos vizinhos, a dracma perdida. E nos arranca lágrimas a alegria das festas de tua casa quando lemos que teu filho menor estava morto e reviveu; estava perdido e foi encontrado.

 Tu te alegras em nós e em teus anjos, santificados pelo santo amor; pois és sempre o mesmo, e conheces do mesmo modo e sempre as coisas que nem sempre existem, nem da mesma maneira.

 Mas, que se passa na alma, para que se alegre mais com as coisas que estima, encontradas ou reavidas, do que se sempre as tivesse possuído? Na verdade, tudo o atesta, e há inúmeros testemunhos que afirmam: "É assim mesmo!"

 O general celebra o triunfo da vitória, e não teria vencido sem combate; e quanto mais foi árdua a batalha, tanto maior é o gozo no triunfo.

 A tempestade cai sobre os navegantes com ameaça de naufrágio. Todos empalidecem diante da morte iminente. O céu e o mar se acalmam, é grande sua alegria, e nasce do muito que temeram.

 Adoece uma pessoa amiga: seu pulso revela um desfecho fatal. Todos os que desejam sua cura sofrem com ela, por simpatia. Havendo melhora, embora ainda não recuperado o vigor de outrora, já reina tal alegria como não existia antes, quando andava sadia e forte.

 Até os prazeres da vida humana, não só compensam os homens de desgraças casuais e involuntárias, mas também de moléstias premeditadas e desejadas. Não há prazer algum em beber ou comer sem que haja antes o estímulo da sede ou da fome. Os ébrios costumam comer antes alguma coisa salgada, que lhes cause sede ardente e que transformará em prazer quando acalmada com a bebida. O costume quer que as esposas não sejam entregues imediatamente aos maridos: o marido desprezaria a noiva se não tivesse que esperar e suspirar por ela.

 Assim ocorre tanto na alegria torpe e vil, como na alegria lícita e permitida, na mais sincera e honesta amizade, como na aventura daquele que estava morto e tornou a viver, que se havia perdido e foi encontrado; em todos os casos uma alegria maior é precedida de uma dor também maior.

 Por que isto, Senhor, meu Deus, quando tu mesmo és tua própria alegria eterna, e as criaturas à tua volta em ti se alegram? Por que esta parte do universo sofre as alternâncias de progressos e quedas, de uniões e separações? Será este o modo de ser que lhe concedeste quando, do mais alto dos céus até às profundezas da terra, desde o princípio dos tempos até o fim dos séculos, desde o anjo até o pequenino verme, e desde o primeiro movimento até o último, dispuseste todos os gêneros de bens e todas as tuas obras justas, cada uma em seu lugar e tempo?

 Ai de mim! Quão alto és nas alturas e quão profundo nos abismos! Jamais te afastas de nós e, contudo, quanta dificuldade para voltar a ti!

## CAPÍTULO IV

### A conversão dos grandes

 Vamos pois, Senhor, mãos à obra! Desperta-nos, chama-nos, inflama-nos, arrebata-nos; derrama tuas doçuras, encanta-nos: amemos, corramos!

 Não é verdade que muitos voltam a ti, saindo de um abismo de cegueira mais profundo que o de Vitorino, e se aproximam de ti, e são iluminados pela tua luz, junto da qual recebem o poder de se fazerem teus filhos?

 Mas se estes são menos conhecidos pelo mundo dos homens, mesmo os que os conhecem se alegram menos; mas quando a alegria é partilhada por muitos, ainda é maior em cada um, porque se aquece e inflama de uns para os outros.

 Ademais, os que são conhecidos de muitos, arrastam à salvação muitos outros, e caminham adiante seguidos dos que os imitam. Por isso, grande é a alegria dos que os precederam, por que não se regozijam só consigo.

 Mas, longe de mim pensar que no teu tabernáculo são mais aceitos os ricos que os pobres, e os nobres mais do que os plebeus, porque escolheste os fracos segundo o mundo para confundir os fortes; o que é vil e desprezível segundo o mundo, a que não é nada, para aniquilar o que é.

 Contudo, o menor de teus apóstolos, por cuja boca pronunciaste essas palavras, quando suas armas abateram o orgulhoso procônsul Paulo, sujeitando-o ao leve jugo de teu Cristo e fizeram dele um súdito do grande Rei, quis, parar comemorar tão grande triunfo, mudar seu nome de Saulo pelo de Paulo. De fato, o adversário é mais completamente vencido naquilo em que tinha maior domínio e por meio do que retém maior número de sequazes. Ora, o inimigo domina com mais força os soberbos pela nobreza de seu nome e, graças a estes, número maior pelo prestígio de sua autoridade.

 Assim, na medida em que o coração de Vitorino era tido como fortaleza inexpugnável antes ocupada pelo demônio, e sua língua como dardo poderoso e agudo, que tantas vezes havia dado a morte às almas, tanto mais copiosamente deviam exultar teus filhos, ao verem que nosso Rei agrilhoara o forte, e que seus vasos roubados, eram agora purificados e destinados à tua honra, convertendo-se em instrumentos úteis ao Senhor para toda obra boa.

## CAPÍTULO V

### As duas vontades

 Mal teu servo Simpliciano me contou a conversão de Vitorino, ardi no desejo de imitá-lo; aliás, era esta a finalidade da narração de Simpliciano. Depois acrescentou que nos tempos do imperador Juliano, uma lei proibia aos cristãos ensinar literatura e oratória, e Vitorino, dócil à lei, preferiu abandonar a escola de palradores a abandonar teu Verbo, que torna eloqüentes as línguas dos meninos. Não só me pareceu corajoso como afortunado, por ter encontrado ocasião de se consagrar por ti. Por isso eu suspirava, acorrentado não com os ferros de uma vontade estranha, mas por minha férrea vontade.

 O inimigo dominava meu querer, e dele forjava uma corrente com a qual me mantinha cativo. Da vontade perversa nasce a paixão, e desta satisfeita procede o hábito, e do hábito não contrariado provém a necessidade, e com estes anéis enlaçados entre si – por isso lhes chamei corrente – me mantinha preso em dura servidão. A nova vontade, que despontava em mim, de te servir sem interesse, de me alegrar em ti, ó meu Deus, única alegria verdadeira, ainda não era capaz de vencer a vontade antiga e inveterada. Deste modo minhas duas vontades, a velha e a nova, a carnal e a espiritual, lutavam entre si e, nessa luta, dilaceravam-me a alma.

 Entendi, por experiência própria, o que havia lido: a carne tem desejos contra o espírito, e o espírito contra a carne. Eu vivia ao mesmo tempo a ambos, embora mais o que aprovava em mim do que o que em mim desaprovava. Com efeito, nesta última parte de mim eu era passivo e constrangido, mais do que ativo e livre.

 E,contudo, o hábito que se impunha contra mim vinha de mim mesmo, pois fora voluntariamente que eu chegara onde não queria. E quem poderia protestar legitimamente, se um castigo justo segue o pecador?

 Eu já não tinha aquela desculpa, com a qual persuadia-me de que, se ainda não desprezava o mundo para te servir, era porque não tinha visão clara da verdade, uma vez que agora já a conhecia de modo indiscutível. Mas, ainda apegado à terra, recusava-me a combater em tuas fileiras, e temia ver-me livre dos meus laços, quando devia temer estar por eles atado.

 Assim, sentia-me docemente oprimido pelo peso do mundo, como em um sonho, e os pensamentos com que meditava em ti eram semelhantes aos esforços dos que desejam despertar, mas, vencidos pela sonolência, voltam dormir. Não há ninguém que queira dormir sempre, e segundo dita o bom senso, é melhor estar desperto que dormir. Contudo, às vezes retarda-se o despertar, quando o torpor torna os membros pesados, e, mesmo a contragosto, continua-se a dormir mesmo depois de chegada a hora de despertar. Assim eu estava certo que era melhor entregar-me a teu amor que ceder à minha paixão. O primeiro me agradava, me dominava; o segundo me encantava, me prendia.

 Já não tinha o que responder quando me dizias: "Desperta, ó tu que dormes, levanta-te de entre os mortos, e Cristo te há de iluminar". E quando por todos os meios me mostrava a verdade do que dizias, e de que eu estava convencido, não tinha absolutamente nada para responder, senão umas palavras preguiçosas e sonolentas: Um momento... Depois... Um pouquinho mais... Mas este pouquinho não tinha fim, e este momento se ia prolongando.

 Em vão me deleitava em tua lei, segundo o homem interior, porque em meus membros outra lei combatia a lei de meu espírito, mantendo-me cativo sob a lei do pecado que estavas em meus membros. Com efeito, a lei do pecado é a violência do hábito, pelo qual a alma é arrastada e presa, mesmo contra sua vontade, merecidamente porém, pois se deixa arrastar por vontade própria. Pobre de mim! Quem poderia libertar-me deste corpo de morte senão tua graça, por Cristo, nosso Senhor?

## CAPÍTULO VI

### A narração de Ponticiano

 Agora contarei de que modo me arrancaste do vínculo do desejo carnal, que me prendia fortemente, e da servidão dos negócios do mundo, e confessarei teu nome, ó Senhor, meu auxílio e minha redenção. Levava minha vida habitual com angústia crescente; todos os dias suspirava por ti, freqüentava tua igreja, quando me deixavam livre os negócios, cujo peso me fazia sofrer.

 Comigo estava Alípio, desonerado do cargo de jurisconsulto, depois de ter sido assessor pela terceira vez. Ele aguardava a quem vender de novo seus conselhos, como eu vendia arte da eloqüência, se é que pelo ensino a podemos transmitir.

 Nebrídio, por sua vez, acendendo às nossas solicitações amigas, auxiliava na escola a nossa amigo íntimo, Verecundo; este, gramático e cidadão milanês, desejava enormemente, e nos instava em nome da amizade, que um de nós lhe prestasse uma fiel colaboração, pois dela muito necessitava.

 Não foi, pois, o interesse que moveu a Nebrídio – que poderia auferir bem mais vantagens se ensinasse as letras – mas, como grande amigo que era, não quis recusar nosso pedido em obsequio à amizade. Agia, porém, com muita prudência, evitando fazer-se conhecido dos poderosos deste mundo, para evitar as inquietações do espírito que ele queria manter o mais possível livre e desocupado para investigar, ler ou ouvir algo sobre a sabedoria.

 Certo dia em que Nebrídio estava ausente, não sei por que motivo, Alípio e eu recebemos a visita de um tal Ponticiano, nosso compatriota da África, que servia em alto cargo do palácio. Não sei mais o que queria de nós.

 Sentamo-nos para conversar, e, por acaso, deu com os olhos em um livro que estava sobre a mesa de jogo, à nossa frente. Pegou-o, abriu-o, viu que eram as epístolas de Paulo e ficou surpreso, pois pensava que se tratasse de algum dos livros cujo estudo me preocupava. Então sorriu para mim e, cumprimentando-me, manifestou-me sua admiração por ter encontrado aquele livro, e só aquele, ao alcance dos meus olhos. Ponticiano era um cristão fiel, e muitas vezes prostrava-se diante de ti, nosso Deus, na igreja, em freqüentes e prolongadas orações.

 E quando lhe declarei que aquele livro ocupava o melhor de minha atenção, tomando a palavra, começou a falar-nos de Antão, monge do Egito, cujo nome era celebrado entre teus fiéis, mas que nós desconhecíamos até aquela hora. Informado disto, continuou a falar, revelando esse grande homem à nossa ignorância, que ele muito admirou.

 Ouvíamos, estupefatos, tuas autenticas maravilhas, realizadas na verdadeira fé, na Igreja Católica, tão recentes e quase contemporâneas. Todos nos admirávamos; nós, por serem coisas tão grandes; e ele, por ser-nos tão desconhecidas.

 Depois, passou a falar das multidões que vivem em mosteiros, e de seus costumes, que trazem teu doce perfume, e da fecunda solidão do ermo, coisas todas que desconhecíamos.

 Até em Milão havia, fora dos muros, um mosteiro cheio de bons irmãos sob a direção de Ambrósio, que também desconhecíamos.

 Ponticiano prosseguia, e falava sempre mais, e nós o ouvíamos atentos e calados. E assim veio a nos contar que um dia, não sei quando, estando em Tréveris, saiu em companhia de três companheiros, enquanto o imperador se concentrava nos jogos circenses da tarde, para dar um passeio pelos jardins que rodeavam os muros da cidade. Distraidamente passeando dois a dois, um com Ponticiano, e os outros dois juntos, separaram-se e tomaram caminhos diferentes.

 Caminhando a esmo, estes últimos deram com uma cabana, habitada por alguns servos teus, pobres de espírito, a quem pertence o reino dos céus. Lá encontraram um exemplar manuscrito da Vida de Santo Antão. Um deles começou a lê-lo, e, admirado e arrebatado cogitou, enquanto lia, em abraçar aquele gênero de vida, abandonando o serviço do mundo, para servir unicamente a ti.

 Estes dois eram os chamados agentes de negócios do imperador. De repente, tomado de amor santo e casto pudor, irado consigo mesmo, olha para o companheiro, e lhe diz: "Dize-me, te peço, onde pretendemos chegar com todos estes nossos trabalhos? Que buscamos? Qual a finalidade do nosso labor? Podemos aspirar mais no palácio do que ser amigos do imperador? E mesmo nisto, quanta incerteza, quantos perigos! E quantos perigos teremos de passar para chegar a um perigo ainda maior? E quando chegaremos a isso? Mas, se eu quiser ser amigo de Deus, posso sê-lo agora mesmo". Disse essas palavras, e exaltado pela gestação da nova vida voltou os olhos para o livro; ao ler, transformava-se interiormente, o que só tu sabias, e seu espírito se despia do mundo, como logo se evidenciou.

 Enquanto lia, o coração se lhe tornou um mar tempestuoso, sentiu um estremecimento e, intuindo o melhor caminho a tomar, resolveu abraçá-lo, dizendo ao amigo:

 "Já rompi com nossos sonhos: decidi dedicar-me ao serviço de Deus, e isso quero começar aqui e agora. Se não me queres imitar, ao menos não me contraries".

 O amigo respondeu que desejava ficar com ele, e ser companheiro de tão nobre mercê e de tão grande combate. Ambos já te pertenciam, e começavam a construir, com capital suficiente, uma torre de salvação, a tudo renunciando para te seguir.

 Então Ponticiano e seu companheiro, que passeavam em outro local do jardim, procurando-os, deram também com a mesma cabana, e os avisaram para que voltassem, pois já entardecia. Mas eles, relataram-lhes sua determinação e propósito, e o modo como nascera e se fixara neles tal desejo, pediram-lhes que, se não quisessem juntar-se a eles, que não os molestassem. Mas estes, sem se converterem, lamentaram a si mesmos, no dizer de Ponticiano, e felicitando-os piedosamente, recomendaram-se às suas orações; depois, arrastando o coração pela terra, voltaram ao palácio, enquanto que os convertidos, fixando seu coração no céu, ficaram na cabana.

 Ambos eram noivos; mas, quando suas noivas ouviram o sucedido, também te consagraram sua virgindade.

## CAPÍTULO VII

### A reação de Agostinho

 Eis o que Ponticiano nos relatou. E tu, Senhor, enquanto ele falava, me fazias refletir, tirando-me da posição de costas, em que me colocara para não me ver a mim mesmo. Tu me colocavas diante de meu próprio rosto para que visse como estava indigno, disforme, sórdido, manchado e ulceroso.

 Eu me via, e enchia-me de horror, mas não tinha para onde fugir de mim mesmo. Se tentava afastar o olhar de mim mesmo, Ponticiano prosseguia com a narração, e de novo me punhas diante de mim, e me empurravas diante de meus olhos, para que eu descobrisse minha iniqüidade e a odiasse. Eu bem a conhecia, mas a dissimulava, fingia não ver, esquecia.

 E quanto mais ardentemente amava aqueles jovens, cuja salutar decisão ouvia relatar, por se terem entregue completamente a ti para que os curasses, tanto mais acerbamente me odiava ao me comparar com eles. Com efeito, já tinham decorrido muitos anos – talvez uns doze – desde que, ao dezenove anos, lendo o Hortênsio de Cícero, sentira-me atraído para o estudo da sabedoria. Ia adiando a hora de abandonar a felicidade meramente terrena, quando não somente a sua descoberta, mas a sua própria busca, deveria ser preferida aos maiores tesouros do mundo e aos maiores prazeres corporais, que a um aceno, afluíam a meu redor.

 Mas eu, jovem miserável, sim, miserável desde o despertar da juventude, já te havia pedido a castidade, dizendo: "Dá-me castidade e continência, mas não agora" – pois temia que me atendesse muito depressa, e que me curasses logo da doença de minha concupiscência, que eu mais queria saciar do que extinguir. E caminhei pelas sendas ruins de uma superstição sacrílega, não porque estivesse certo dela, mas porque a preferia às demais doutrinas, que eu não estudava piedosamente, mas que hostilmente combatia.

 Acreditava que o motivo por que adiava dia a dia o desprezo das promessas seculares, para seguir apenas a ti, era o não ter descoberto uma claridade capaz de dirigir meus passos. Veio, então, o dia em que me vi nu, a ouvir as repreensões de minha consciência: "Onde está a tua palavra? Não dizias que tua indecisão para lançar longe o fardo de tua vaidade se devia à incerteza? Agora tens a certeza, e não obstante, ainda te oprime esse fardo; outros, no entanto, que não se consumiram tanto em procurá-la, nem meditaram dez anos ou mais sobre tais problemas, vêem nascer asas em seus ombros mais livres".

 Assim me roia interiormente, devorado por enorme e terrível vergonha, enquanto Ponticiano contava aquilo tudo. Finda a conversa, e resolvida a questão a que viera, Ponticiano voltou para sua casa, e eu para dentro de mim. Que coisas não disse contra mim? Com que açoite de palavras não flagelei minha alma, para obrigá-la a me seguir em meus esforços para te alcançar! Ela resistia, recusava-se, sem se desculpar. Todos os argumentos já estavam esgotados e refutados. Nada lhe restava, senão uma angústia muda: tinha medo, como da morte, de ser tolhida à corrente do vício, onde se corrompia mortalmente.

## CAPÍTULO VIII

### Luta espiritual

 Então, em meio àquela luta interior que eu travava violentamente contra mim mesmo no recesso do meu coração, perturbado no rosto e no espírito, volto-me para Alípio exclamando: "Que tanto nos aflige? O que significa isto que ouviste? Levantam-se os ignorantes e arrebatam o céu, e nós, com todo nosso saber insensato, nos revolvemos na carne e no sangue! Acaso temos vergonha de segui-los porque se nos adiantaram, e não temos vergonha de não os seguir?"

 Foi mais ou menos o que eu lhe disse, e dele me afastei sob forte emoção. Alípio me olhava atônito em silêncio. Eu não falava como de costume, e muito mais que as palavras, minha fronte, minhas fazes, meus olhos, minha cor e o tom de minha voz denunciavam meu estado de espírito.

 Nossa casa tinha um pequeno jardim, que usávamos, assim como o restante da casa, que nosso hóspede não habitava. Para ali me levara a tormenta de meu coração, onde ninguém pudesse interferir no ardente combate que eu travava comigo mesmo, até que se resolvesse o assunto conforme tu sabias e eu ignorava. Mas eu delirava para reencontrar a razão, e morria para reviver; conhecia meu mal, mas desconhecia o bem que depois haveria de sobrevir.

 Retirei-me, pois, para o jardim, e Alípio seguiu-me passo a passo; mas, apesar de sua presença, eu não estava menos só. E como haveria ele de me deixar naquele estado? Sentamonos o mais longe possível da casa. Eu tremia pela violenta indignação, me enraivecia por não poder seguir teu agrado e aliança, ó meu Deus, aliança pela qual clamavam todos os meus ossos, que te elevavam louvores até o céu. E para ir a ti não há necessidade de navios nem de carros, nem mesmo de dar aqueles poucos passos que separavam a casa do jardim onde estávamos. Não somente ir, mas chegar junto de ti, nada mais é do que querer ir, mas com querer enérgico e pleno, e não com vontade tíbia, que se dispersa em todos os sentidos, e se agita incerta, dividida, ora levantando-se, ora voltando a cair.

 Enfim, naquela angustiante hesitação, fazia mil gestos, como soem fazer os homens que querem e não podem, ou porque não têm membros, ou porque os têm atados em cadeias, debilitados pela fraqueza ou paralisados de qualquer outro modo. Se puxei os cabelos, se feri a fronte, se apertei os joelhos entre os dedos entrelaçados, eu o fiz porque quis. Poderia porém querer fazê-lo e não o fazer, se a flexibilidade de meus membros não me obedecesse. Portanto, fiz muitas coisas, nas quais o querer não era o mesmo que o poder.

 Contudo, eu não fazia aquilo que desejava acima de tudo o mais, e que eu poderia fazer desde que o quisesse, porque se o tivesse efetivamente querido, bastava que o quisesse sinceramente; nisto o poder é o mesmo que o querer, e querer já seria agir.

 Contudo não o fazia, e meu corpo obedecia mais facilmente ao mais leve comando de minha alma, movendo os membros segundo sua vontade, do que a própria alma obedecer a si mesma para realizar seu grande desejo com a vontade.

## CAPÍTULO XI

### A desobediência da vontade

 Mas, de onde vinha este prodígio? Qual sua causa? Brilhe a tua misericórdia, e perguntarei – se é que me podem responder – aos sombrios castigos infligidos aos homens, e às tenebrosas misérias dos filhos de Adão. De onde vem este prodígio? E qual sua causa?

 A alma dá ordens ao corpo, e este obedece imediatamente; a alma dá ordens a si mesma, e resiste. Ordena a alma à mão que se mova, e é tal sua presteza, que mal se pode distinguir a ordem da execução; não obstante, a alma é espírito e a mão é corpo. A alma dá a si mesma a ordem de querer, uma não se distingue da outra, e contudo, ela não obedece. De onde este prodígio? E qual sua causa?

 Manda a alma que queira – e não mandaria se não quisesse – e, não obstante, não faz o que manda. Logo, não quer totalmente, e por isso não manda de modo total. A alma manda na proporção do querer, e enquanto não quiser, suas ordens não são executadas, porque é a vontade que dá a ordem de ser a uma vontade que nada mais é que ela própria. Logo, não manda plenamente, e esta é a razão por que não faz o que manda. Porque, se estivesse em sua plenitude, não mandaria que fosse, porque já seria.

 Não há, portanto, prodígio algum em querer em parte e em parte não querer; é uma enfermidade da alma. esta, sustentada pela verdade, não se ergue de todo, pois está oprimida pelo peso do hábito. Há, portanto, duas vontades, ambas incompletas, e o que uma possui falta à outra.

## CAPÍTULO X

### Contra os maniqueus

 Desapareçam de tua presença, ó meu Deus, como os vãos faladores e sedutores do espírito, aqueles que, ao observarem a dupla deliberação da vontade, concluem que temos duas almas de naturezas opostas, uma boa, outra má.

 Eles é que são de fato maus, que seguem tais más doutrinas; somente serão bons quando aceitarem a verdade, concordando com os que a possuem. E assim o Apóstolo poderá dizer deles: Outrora fostes trevas, mas agora sois luz no Senhor. Mas esses, querendo ser luz não no Senhor, mas em si mesmos, julgam que a natureza da alma á a mesma que a de Deus; vão-se tornando trevas ainda mais densas, pois em sua terrível arrogância se afastam ainda mais de ti, luz verdadeira, que ilumina a todo homem que vem a este mundo. Atentai para o que dizeis, e enchei-vos de vergonha. Aproximai-vos dele, e sereis iluminados, e vossos rostos não serão cobertos de confusão.

 Quando eu deliberava dedicar-me ao serviço do Senhor meu Deus, como de há muito me tinha proposto, eu era o que eu queria, e lera o que eu não queria. Mas, nem queria plenamente, nem deixar de querer por completo. Por isso lutava comigo mesmo, e me dilacerava a mim mesmo. Essa destruição, embora involuntária, não mostrava, contudo, a presença em mim de uma alma estranha, mas apenas o castigo de minha alma. E por isso já não era eu quem mo infligia, mas o pecado que habitava em mim, como castigo de pecado cometido livremente, por ser eu filho de Adão.

 Com efeito, se fossem tantas as naturezas contrárias quantas são as vontades que em nós se contradizem, não deveríamos admitir apenas duas naturezas, mas muitas. Se alguém, com efeito, hesita entre uma reunião dos maniqueístas ou ao teatro, logo eles exclamam: "Eis aí as duas naturezas, uma boa, que o atrai para cá, e outra má, que o arrasta pra lá. E de onde mais viria essa hesitação de vontades opostas?"

 De minha parte eu digo que ambas são más, tanto a que leva a eles como a que arrasta ao teatro; mas eles só julgam boa a que leva até eles.

 Mas, suponhamos que um dos nossos queira decidir, e conflitando as duas vontades, titubeie entre ir ao teatro ou à nossa igreja; não ficarão indecisos os maniqueístas na resposta que hão de dar? Porque, ou hão de confessar o que não querem, que é boa a vontade que o leva à nossa igreja, como vão a ela os que foram iniciados em seus mistérios e lhe permanecem fiéis, ou terão de reconhecer que num mesmo homem lutam duas naturezas más e duas almas más. E então terão de contradizer o que afirmam, que uma natureza é boa e outra má. Ou então terão de aceitar a verdade e, neste caso, não negarão que, quando alguém escolhe, é uma mesma alma a que hesita entre duas vontades opostas.

 Portanto, quando virem duas vontades que se contrapõem ao mesmo homem, não falem mais de luta entre duas almas contrárias, uma boa e outra má, originadas em duas substâncias antagônicas. Porque tu, ó Deus verdadeiro, os confundes, como no caso em que ambas as vontades são más; por exemplo, quando alguém hesita, entre matar a outrem com um punhal ou veneno; entre assaltar esta ou aquela propriedade alheia, quando não pode assaltar a ambas; entre esbanjar na compra do prazer da luxúria, ou guardar dinheiro por avareza; entre ir ao circo ou ao teatro, quando ambos sejam concomitantes; e ainda acrescento uma terceira incerteza: entre roubar ou não a casa do próximo, em havendo a oportunidade, ou ainda, acrescento uma quarta hipótese: entre cometer ou não adultério, se tem possibilidade para isso. Suponhamos que todas essas circunstâncias ocorram simultaneamente; como todas são igualmente desejadas, e irrealizáveis ao mesmo tempo, a alma será dilacerada por um conflito entre quatro vontades, ou mais ainda, tão numerosos são os objetos de desejo! Contudo, os maniqueus não afirmam que existe tão grande número de substâncias diferentes.

 O mesmo acontece com as vontades boas. Se eu lhes pergunto se é bom deleitar-se com a leitura do Apóstolo, com a leitura de algum salmo espiritual, ou com o comentar do Evangelho, eles responderão a cada questão: "É bom" – Ora, se as três atividades têm a mesma atração simultaneamente, não teríamos vontades opostas a dividir o coração do homem, enquanto escolhe qual delas abraçar de preferência?

 Todas essas vontades são boas, e lutam entre si, até que se tome uma decisão, que unifique a vontade, antes dividida. Assim também, quando a eternidade agrada à nossa parte superior e o bem temporal nos prende fortemente cá embaixo: é a mesma alma que, sem uma vontade plena, quer um e outro desses bens. Por isso, dilacera-a uma grande dor; a verdade nos faz preferir a eternidade, mas o hábito não quer abandonar os bens temporais.

## CAPÍTULO XI

### Últimas resistências

 Assim sofria e me atormentava, com acusações mais acerbas que de costume, rolando-me e debatendo-me dentro de minha cadeias, para ver se as quebrava por completo. Elas mal me prendiam,mas ainda me prendiam. E tu, Senhor, me espicaçavas no fundo de minha alma, e com severa misericórdia redobravas os açoites do temor e da vergonha, para que eu não afrouxasse de novo, e para que quebrasse minha tênue e leve cadeia, antes que ela se revigorasse para me prender mais firmemente.

 E dizia comigo mesmo: "Vamos! Mãos à obra, sem demoras!" E quase passava da palavra à ação. Estava a ponto de agir, mas não agia. Eu já não recaía nas antigas paixões, mas delas estava bem próximo, e tomava ainda alento de seu ar. Quase a alcançava, faltava pouco, cada vez menos, e já quase chegava ao termo e a segurava; mas não a alcançava, nem a tocava; hesitava entre morrer para a morte e viver para a vida. O mal arraigado dominava-me mais do que o bem, cujo hábito eu não possuía; na medida que ia se aproximando o momento em que me transformaria em outro homem, maior era o horror que me incutia, sem contudo me fazer voltar para trás ou mudar de caminho. Simplesmente mantinha-me indeciso.

 Mantinham-me preso umas tantas bagatelas, umas vaidades de vaidades, antigas amigas minhas, que me puxavam por minhas vestes carnais, murmurando: "Então, nos abandonas? De agora em diante nunca mais estaremos contigo? Desde este momento nunca mais te será lícito isto ou aquilo?"

 E que coisas, meu Deus, que torpezas me sugeriam com o que chamei de isto ou aquilo! Por tua misericórdia, afasta-as da alma de teu servo! Oh! Que imundícies me sugeriam, que indecências! Já se reduzira a menos da metade o número de vezes que eu lhes dava ouvidos; não era mais um assalto aberto, frontal, mas segredado por cima dos ombros, e como que puxando-me furtivamente, se me afastava, para que me voltasse para trás.

 Contudo, faziam com que eu, vacilante, tardasse em me separar delas para correr para onde me chamavam, enquanto o hábito violento me dizia: "Julgas que poderás viver sem elas?"

 Mas isto já dizia com voz muito débil. Para onde voltava o rosto, e por onde temia passar, mostrava-se para mim a casta dignidade da continência, serena e alegre, sem desordens, acariciando-me honestamente para que me aproximasse sem medo. Estendia para mim, para me acolher e abraçar, suas mãos piedosas, cheias de uma multidão de bons exemplos.

 Junto dela, uma turba de meninos e meninas, uma juventude numerosa, e homens de toda idade, viúvas veneráveis e virgens idosas. Em todas essas almas, não era estéril, mas fecunda a mãe de filhos nascidos nas alegrias do esposo, que eras tu, Senhor!

 E a continência zombava de mim com ironia animadora, como se dissesse: "Então, não serás capaz de fazer o mesmo que eles? Ou será que estes e estas encontraram forças em si mesmos, e não no Senhor, seu Deus? Foi o Senhor Deus, quem me entregou a eles. Por que te apóias em ti, se és vacilante? Lança-te nele, não temas, que ele não se apartará de ti, e tu não cairás. Lança-te com confiança, que ele te receberá e te curará."

 E enchia-me de vergonha por ainda ouvir o murmúrio daquelas bagatelas e, vacilante, continuava indeciso.

 Mas de novo a voz da castidade parecia me dizer: Não dês ouvidos às tentações imundas da tua carne impura que te prende à terra, a fim de que seja mortificada. Ela te fala de deleites, contrários porém, à lei do Senhor teu Deus.

 Essa luta se desenrolava no fundo do meu espírito, de mim contra mim mesmo. Alípio, sem sair de perto de mim, aguardava em silêncio o desfecho de minha insólita agitação.

## CAPÍTULO XII

### A conversão

 Mas logo que esta profunda reflexão tirou da profundeza de minha alma, e expôs toda minha miséria à vista de meu coração, caiu sobre mim enorme tormenta, trazendo copiosa torrente de lágrimas. E para dar-lhe toda vazão com seus gemidos, afastei-me de Alípio; a solidão parecia-me mais adequada e me afastei o mais longe possível, para que sua presença não me fosse embaraçosa. Tal era o estado em que encontrava, e Alípio percebeu-o, pois lhe disse alguma coisa com um timbre de voz embargado de lágrimas que me denunciou.

 Alípio, atônito, continuou no lugar em que estávamos sentados; mas eu, não sei como, me retirei para a sombra de uma figueira, e dei vazão às lágrimas; e dois rios brotaram de meus olhos, sacrifício agradável a teu coração. E embora não com estes termos, mas com o mesmo sentido, muitas coisas te disse como esta: E tu, Senhor, até quando? Até quando, Senhor, hás de estar irritado! Esquece-te de minhas iniqüidades passadas! Sentia-me ainda preso a elas, e gemia, e lamentava: "Até quando? Até quando direi amanhã, amanhã? Por que não agora? Por que não pôr fim agora às minhas torpezas?"

 Assim falava, e chorava oprimido pela mais amarga dor do meu coração. Mas eis que, de repente, ouço da casa vizinha uma voz, de menino ou menina, não sei, que cantava e repetia muitas vezes: "Toma e lê, toma e lê".

 E logo, mudando de semblante, comecei a buscar, com toda a atenção em minhas lembranças se porventura esta cantiga fazia parte de um jogo que as crianças costumassem cantarolar; mas não me lembrava de tê-la ouvido antes. Reprimindo o ímpeto das lágrimas, levantei-me. Uma só interpretação me ocorreu: a vontade divina mandava-me abrir o livro e ler o primeiro capitulo que encontrasse.

 Tinha ouvido dizer que Antão, assistindo por acaso a uma leitura do Evangelho, tomara para si esta advertência: "Vai, vende tudo o que tens, dá-lo aos pobres, e terás um tesouro no céu; depois vem e segue-me" – e que esse oráculo decidira imediatamente sua conversão.

 Depressa voltei para o lugar onde Alípio estava sentado, e onde eu deixara o livro do Apóstolo ao me levantar. Peguei-o, abri-o, e li em silêncio o primeiro capítulo que me caiu sob os olhos: "Não caminheis em glutonarias e embriaguez, não nos prazeres impuros do leito e em leviandades, não em contendas e rixas; mas revesti-vos de nosso Senhor Jesus Cristo, e não cuideis de satisfazer os desejos da carne".

 Não quis ler mais, nem era necessário. Quando cheguei ao fim da frase, uma espécie de luz de certeza se insinuou em meu coração, dissipando todas as trevas de dúvida.

 Então, marcando com o dedo, ou não sei com que, fechei o livro, e com o rosto já tranqüilo, revelei a Alípio o que se passara. Ele, por sua vez, me revelou o que acontecera com ele, e que eu ignorava. Pediu para ver o que eu tinha lido; mostrei-lhe, ele prosseguiu a leitura. Eu ignorava o texto seguinte, que era este: Recebei ao fraco na fé, palavras que aplicou a si mesmo, e mo revelou. Fortificado por essa advertência, firmou-se nessa resolução e santo propósito, bem de acordo com seus costumes, nos quais já há muito tempo tomara grande vantagem sobre mim.

 Fomos depois à procura de minha mãe, que ao saber do sucedido, ficou radiante. Contamo-lhe como o caso se passara; ela exultou, triunfante e bendizendo a ti, que és poderoso para dar-nos mais do que pedimos ou entendemos, porque via que lhe havias concedido, a meu respeito, muito mais do que constantemente te pedia com tristes gemidos e lágrimas.

 De tal forma me converteste a ti, que já não procurava esposa, nem abrigava esperança alguma deste mundo, mas estava já naquela "regra de fé" em que há tantos anos me havias mostrado à minha mãe. E assim converteste seu pranto em alegria, muito mais fecunda do que havia desejado, e muito mais preciosa e pura do que a que podia esperar dos netos nascidos de minha carne.

# LIVRO NONO

## CAPÍTULO I

### Colóquio

 Ó Senhor, sou teu servo e filho de tua serva. Rompeste minhas cadeias: eu te sacrificarei uma vítima de louvor. Louvem-te meu coração e minha língua, e que todos os meus ossos te digam: Senhor, quem semelhante a ti? Que eles te digam essas palavras e que me respondas e digas à minha alma: Eu sou tua salvação.

 Quem sou eu, e como era? Que males não tive em minhas obras, ou, se não em minhas obras, em minhas palavras, ou, se não em minhas palavras, em minha vontade! Mas tu, Senhor, bom e misericordioso, puseste os olhos na profundeza de minha morte, e purificaste com tua destra o abismo de corrupção de minha alma. Tratava-se agora apenas de não querer o que eu queria, e de querer o que tu querias.

 Mas, onde esteve meu livre arbítrio durante tantos anos? De que profundo e misterioso abismo foi ele chamado num instante, para que eu inclinasse a cerviz a teu jugo suave e o ombro a teu leve fardo, ó Cristo Jesus, meu auxílio e redenção?

 Quão suave foi para mim a privação de doçuras fúteis! Temia então perdê-las, como agora sentia prazer em deixa-las! Porque tu se afastavas de mim, e entravas em seu lugar, mais doce que qualquer prazer, mas não para a carne e o sangue; mais claro que toda luz, mais oculto que qualquer segredo; mais sublime que todas as honras, mas não para os que exaltam a si mesmos. Minha alma já estava livre dos devoradores cuidados da ambição, do ganho, e do prurido dos apetites carnais; e falava muito comigo, ó Deus e Senhor meu, minha luz, minha riqueza, minha salvação!

## CAPÍTULO II

### Adeus ao magistério

 Pareceu-me de bom alvitre, em tua presença, não abandonar de modo ostensivo o ministério da minha língua, mas retirá-lo suavemente do mercado da loquacidade, para que dali por diante os jovens, que não se preocupam com tua lei ou paz, mas com as enganosas loucuras e contendas forenses, não comprassem de minha boca armas para seu furor. Felizmente faltavam pouquíssimos dias para as férias das vindimas (é provável que as férias de outono dos estudantes coincidissem com as férias dos tribunais, que se iniciavam em 22 de agosto, e terminavam em 15 de outubro). Decidi suportá-los até lá. Então me retiraria como de costume, e, resgatado por ti, não tornaria mais a vender meu ofícios.

 Esta minha determinação, te era conhecida; dos homens, só a conheciam os de minha intimidade. E, mesmo assim, tínhamos combinado de nada deixar transpirar. Contudo, quando subíamos do vale de lágrimas, cantando o cântico gradual (série de salmos cantados pelos peregrinos que sobem os degraus do templo de Jerusalém) nos tinhas dado setas agudas e carvões destruidores contra a língua pérfida que contradiz, sob o pretexto de aconselhar e, como quem se alimenta, consome o que ama.

 Tinhas alvejado nosso coração com as setas do teu amor, e levávamos tuas palavras cravadas em nossas entranhas; os exemplos de teus servos, que das trevas trouxeram para a luz, e da morte para a vida, ardiam no fundo de nosso espírito em uma espécie de fogueira, que inflamava e consumia nosso torpor, para que não mais nos inclinássemos para as baixezas. Estávamos inflamados de tal ardor, que o vento da contradição das línguas dolosas não nos apagaria, antes fazia-nos arder mais e mais.

 Contudo, por causa de teu nome, que santificaste em toda terra, nossa decisão e propósito teriam também quem os louvasse. Pareceria de certo modo jactância não aguardar as férias tão próximas; abandonar antes dessa data uma profissão pública, e exposta a todos, seria atrair sobre minha conduta todas as atenções, provocando comentários. Diriam que eu me adiantara às férias iminentes por querer parecer grande personagem. E de que me valeria que pensassem ou discutissem sobre minhas intenções, blasfemando sobre o meu bem?

 Além disso, nesse mesmo verão, devido ao excessivo trabalho didático, meus pulmões começaram a se ressentir; respirava com dificuldade, e as dores no peito e minha voz, que não saía clara ou prolongada, revelavam uma lesão. A princípio me senti angustiado, vendo-me quase obrigado a abandonar o fardo do magistério ou, para me curar e convalescer, teria certamente de o interromper. Mas, quando nasceu em mim e se firmou a vontade plena de repousar e de ver que és o Senhor, então, tu o sabes meu Deus, que cheguei a me alegrar de encontrar esta desculpa verdadeira para moderar o sentimento das famílias, que por causa de seus filhos nunca me permitiram ser livre.

 Cheio dessa consolação, esperava que escoasse aquele tempo – talvez uns vinte dias. Mas minguara minha coragem, porque já me abandonara a cobiça de ganho, que me ajudava a carregar este pesado encargo; e teria sucumbido se a paciência não tomasse o lugar da ambição.

 Talvez alguns de teus servos, meus irmãos, dirá que pequei nisso porque, estando com o coração já cheio de desejos de te servir, consenti ficar mais uma hora sentado na cátedra da mentira. Não discutirei. Mas tu, Senhor misericordiosíssimo, acaso não me perdoaste e resgataste também este pecado, junto com todos os demais horrendos e mortais na água santa do batismo?

## CAPÍTULO III

### Dois amigos

Angustiava-se Verecundo por este nosso bem, porque se via afastado de nossa companhia pelos vínculos matrimoniais que o aprisionavam fortemente. Não era ainda cristão, como sua mulher, mas justamente nela encontrava o maior obstáculo que o impedia de entrar pelo caminho que havíamos começado a trilhar; não queria ser cristão, dizia ele, senão do modo que justamente lhe era proibido.

 Contudo, com sua grande bondade, pôs à nossa disposição sua propriedade no campo pelo tempo que nos aprouvesse. Tu, Senhor, haverás de recompensá-lo no dia da retribuição dos justos, pois já concedeste a graça. Porque, estando nós ausentes e já em Roma, atacado de uma enfermidade corporal, Verecundo saiu desta vida depois de se fazer cristão e crente. Assim te compadeceste não apenas dele, mas também de nós, para que quando pensássemos na grande generosidade que teve conosco este amigo, não nos afligíssemos de dor intolerável por não poder contá-lo entre os de tua grei.

 Graças te sejam dadas, ó Deus nosso! Somos teus: tuas exortações e consolos o indicam. Fiel cumpridor de tuas promessas, concedes a Verecundo a amenidade de teu paraíso sempre florido, por nos ter oferecido sua propriedade de Cassicíaco, na qual descansamos em ti das angústias do século; lhe perdoaste os pecados sobre a terra, na tua montanha, a montanha da abundância.

 Verecundo, como disse, angustiava-se, mas Nebrídio partilhava a nossa alegria, porque, embora não sendo ainda cristão e houvesse caído no erro tão pernicioso de julgar que a carne verdadeira do teu Filho fosse mera aparência, já começava a se desvencilhar e, sem ter ainda recebido os sacramentos da tua Igreja, buscava ardentemente a verdade.

 Não muito depois de nossa conversão e regeneração por teu batismo, fez-se por fim católico fiel. Servia-te na África junto aos seus, em castidade e continência perfeitas; toda sua família, sob sua influência, se fizera cristã. Libertaste-o então dos laços da carne, vivendo agora no seio de Abraão, seja qual for o significado dessa expressão. Ali vive meu Nebrídio, meu doce amigo que, de liberto, se tornou teu filho adotivo. Ali vive – pois, que outro lugar conviria a uma alma assim? Ali vive, nesse lugar sobre o qual indagava muitas coisas a mim, pobre homem ignorante. Já não aproxima seu ouvido da boca, mas aproxima sua boca espiritual de tua fonte, e bebe avidamente de tua sabedoria, numa felicidade sem fim. Mas não creio que se embriague a ponto de esquecer de mim, enquanto tu, Senhor, que és sua bebida, te lembras de nós.

 Essa era a nossa situação. Consolávamos o Verecundo que, sem que a amizade fenecesse, andava desgostoso com nossa conversão; nós o exortávamos a se manter fiel à sua condição conjugal. Quanto a Nebrídio, esperávamos que nos seguisse, pois, facilmente poderia fazê-lo, e já estava a ponto de se decidir. Enfim, aqueles dias passaram, e me pareceram tantos e tão longos, tal era meu desejo de liberdade e descanso, para cantar do fundo do meu ser: A ti meu coração: Procurei teu rosto; teu rosto, Senhor, hei de buscar.

## CAPÍTULO IV

### A doçura dos salmos

 Por fim, chegou o dia da libertação da profissão de retórico, da qual já me libertara em pensamento. Assim aconteceu. Livraste minha língua da tarefa de que há havias livrado meu coração. Eu te bendizia contente, e parti com todos os meus, para a quinta de Verecundo. O que lá realizei nas letras, já a teu serviço, mas ainda com a respiração ofegante, como durante uma pausa da luta, e ainda respirando da soberba da erudição, é atestado pelos livros nos quais anotava meus debates com meus amigos ou comigo mesmo em tua presença (refere-se aos seguintes livros: Contra Acadêmicos, De beata vita, De ordine e dos Solilóquios). Do que tratei com Nebrídio, então ausente, claramente o indicam minhas cartas.

 Mas quando encontrei tempo suficiente para dar testemunho de todos os grandes benefícios que me concedeste nessa época da vida, uma vez que tenho pressa de chegar a outros assuntos mais importantes? Volta-me – e me é doce confessá-lo, Senhor – a lembrança dos estímulos internos com que me domaste; o modo como me aplanaste a alma derrubando as colinas e montanhas de meus pensamentos; como endireitaste meus caminhos tortuosos e suavizasse minhas asperezas; como também submeteste Alípio – o irmão de meu coração – ao nome de teu Filho único, Jesus Cristo, Senhor e Salvador nosso, nome que ele mal suportava em minhas obras, porque preferia o cheiro dos soberbos cedros das escolas, já abatidos pelo Senhor, ao odor das salutares ervas de tua Igreja, antídoto contra o veneno das serpentes.

 Que invocações elevei a ti, meu Deus, lendo os Salmos de Davi, cânticos de fé, hinos de piedade, que expulsavam de mim todo sentimento de orgulho? Eu era ainda inexperiente de teu verdadeiro amor, e dividia minhas horas de lazer com Alípio, catecúmeno como eu. Minha mãe estava conosco. Ao aspecto da mulher ela aliava fé varonil, a calma da velhice, a ternura de mãe e a piedade de cristã. Que exclamações elevei a ti naqueles salmos, e como me inflamava com eles em teu amor! Incendiava-me em desejos de recitá-los, se fosse possível, ao mundo inteiro, para rebater a soberba do gênero humano! Com efeito, em todo o mundo se cantam. Não há ninguém que se subtraia a teu calor.

 Com que veemente e dolorosa indagação me levantava contra os maniqueístas! E de novo me compadecia deles por ignorarem esses sacramentos, esses remédios, investindo loucamente contra o antídoto que poderia curá-los! Gostaria que estivessem perto de mim, sem que eu o soubesse, e que vissem meu rosto e ouvissem minhas exclamações quando lia o Salmo 4 naquelas minhas férias, e percebessem os efeitos salutares que me produzia este salmo: Quando te invoquei, tu me escutaste, ó Deus de minha justiça! Dilataste minha alma na tribulação. Compadece-te, Senhor, de mim, e ouve minha prece. Se me ouvissem – sem eu o saber, para que não pensassem que eram por causa deles as palavras que eu entremeava às do salmo, porque realmente nem eu diria tais coisas, nem as diria daquele modo, se soubesse da sua presença; e, mesmo que as palavras fossem as mesmas, ele não as entenderiam como eu as dizia a mim mesmo, diante de ti, na íntima efusão dos afetos de minha alma.

 Estremeci de medo, ao mesmo tempo me abrasei de alegre esperança em tua misericórdia, ó Pai! E todos estes sentimentos saíam pelos meus olhos e pela voz quando, dirigindo-se para nós, teu Espírito de bondade nos dizia: Filhos dos homens, até quando sereis duros de coração? Por que amais a vaidade e buscais a mentira?

 Também eu tinha amado a vaidade e buscado a mentira. Mas tu, Senhor, já havias glorificado teu eleito, ressuscitando-o de entre os mortos e colocando-o à tua direita, de onde haveria de nos enviar, segundo a promessa, o Paráclito, o Espírito da Verdade. O Senhor estava glorificado, ressuscitando de entre os mortos, e subindo aos céus. Antes o Espírito ainda não tinha sido dado, porque Jesus ainda não tinha sido glorificado.

 Clama o profeta: Até quando sereis duros de coração? Por que amais a vaidade e buscais a mentira? Sabeis que o Senhor já glorificou a seu santo. Clama: Até quando? Clama: Sabei! – E eu sem o saber durante tanto tempo, amando a vaidade e buscando a mentira!

 Por isso tremi quando o ouvi, porque me lembrei de ter sido igual àqueles a quem tais palavras eram dirigidas. Os fantasmas que eu havia tomado pela verdade nada mais eram do que vaidade e mentira.

 Ah! As queixas fortes e profundas que me inspiravam a dor da recordação! Oxalá as tivessem ouvido os que ainda amam a vaidade e buscam a mentira! Talvez também se perturbassem e vomitassem seu erro. E tu os terias ouvidos quando clamassem por ti, porque morreu por nós de verdadeira morte corporal aquele que intercede por nós diante de ti.

 Eu lia: Irai-vos, e não queirais pecar. Como me perturbavam tais palavras, meu Deus! Já havia aprendido a me irar contra mim mesmo pelos meus crimes passados, para não pecar mais; e de uma cólera justa, porque não era uma natureza estranha, da raça das trevas, a que em mim pecava, como dizem os que não se indignam contra si, e acumulam contra si a ira para o dia da ira e da revelação de teu justo juízo?

 Meus bens já não eram exteriores, e eu já não os buscava à luz deste sol, com olhos carnais. Os que querem gozar externamente, facilmente se dissipam e derramam pelas coisas visíveis e temporais, lambendo com pensamento faminto apenas as aparências. Oh! Se eles se esgotassem com a privação, e perguntassem: Quem nos mostrará o bem? E que ouvissem nossa resposta: Está gravada dentro de nós a luz de teu rosto, Senhor! – Porque não somos nós a luz que ilumina a todo homem, mas somos iluminados por ti, para que sejamos luz em ti, nós que outrora fomos trevas.

 Oh! Se eles vissem essa luz interior e eterna que eu havia visto! E como a havia saboreado, irritava-me por não poder mostrá-la. Se, pelo seus olhares dirigidos para fora, visse seu coração afastado de ti, me dissessem: "Quem nos mostrará o bem? Pois ali, onde me irritara contra mim mesmo, ali, no recôndito de meu coração onde, arrependido, eu havia sacrificado e imolado em mim o velho homem; onde, pondo em ti minha esperança, começara a meditar a renovação de mim mesmo, ali fizeste com que eu sentisse tua doçura, dando alegria a meu coração. E exclamava ao ler, fora de mim, essas palavras cuja verdade ecoava em mim; e não queria desdobrar-me pelos bens terrenos, devorando o tempo e sendo por ele devorado, porque possuía na eterna simplicidade outro trigo, outro vinho e outro azeite.

 E subia, no versículo seguinte, um profundo clamor de meu coração: Oh! Em paz! Oh! Em seu próprio Ser! Mas, que disse? Dormirei e descansarei! Com efeito, quem nos há de resistir quando se cumprir a palavra que está escrita: A morte foi devorada pela vitória?

 Tu és esse mesmo Ser, e não mudas, e em ti está o repouso que faz esquecer todos os sofrimentos. Porque ninguém pode ser comparado a ti e nem vale pensar em adquirir outras coisas que não sejam o que tu és; mas tu, Senhor, singularmente me firmaste na esperança.

 Eu lia isto, e me inflamava. Não sabia que fazer com aqueles surdos, de quem eu fora a peste, um cão raivoso e cego que ladrava contra a Bíblia, dulcificada por seu mel celestial e iluminada por tua luz. E me consumia de dor por causa dos inimigos de tuas Escrituras.

 Quando poderei recordar tudo o que aconteceu naqueles dias de descanso? Mas não esqueci, nem quero silenciar, a aspereza de um açoite que usaste em mim, e a admirável presteza de tua misericórdia.

 Atormentavas-me então com uma dor de dentes, que se agravara a tal ponto de me impedir até de falar. Ocorreu-me ao pensamento pedir a todos os amigos, que rogassem por mim, ó Deus da salvação! Escrevi meu pedido numa tabuleta encerada, e lha dei para que o lessem. Apenas dobramos os joelhos com suplicante afeto, logo a dor desapareceu. E que dor! E como desapareceu! Enchi-me de espanto, eu o confesso, meu Deus e Senhor. Nunca, desde minha infância, havia experimentado coisa semelhante.

 No fundo de meu coração penetrou o sinal da tua vontade e, alegre na fé, louvei teu nome. contudo, esta fé não me deixava viver tranqüilo quanto a meus pecados passados, que ainda não me haviam sido perdoados por teu batismo.

## CAPÍTULO V

### O conselho de Ambrósio

 Terminadas as férias, informei aos milaneses que providenciassem para seus estudantes outro vendedor de palavras, visto que determinara consagrar-me a teu serviço; e mesmo porque não podia mais exercer aquela profissão pela dificuldade de respirar e pelas dores que sentia no peito.

 Também comuniquei por escrito a teu bispo e santo bispo Ambrosio, os meus antigos erros, minha intenção atual, para que me indicasse o que deveria ler de preferência em tuas Escrituras, a fim de me preparar e dispor melhor para receber tão grande graça.

 Ele me indicou o profeta Isaías, creio que porque anuncia mais claramente que os demais o Evangelho e vocação dos gentios. Contudo, nada tendo compreendido na primeira leitura, e julgando que toda a obra era assim, decidi voltar a ela quando estivesse mais familiarizado com a palavra do Senhor.

## CAPÍTULO VI

### Batismo de Agostinho. Seu filho Adeodato

 Chegado o tempo em que convinha nos inscrever para receber o batismo, deixamos o campo, e voltamos para Milão.

 Alípio também quis renascer em ti comigo, já revestido de humildade tão conforme a teus sacramentos. Era tão enérgico domador do seu corpo, que caminhava com os pés descalços, com insólita coragem, sobre o chão gelado da Itália.

 Juntamos também a nós o jovem Adeodato, filho carnal de meu pecado; a quem dotaste de grandes qualidades. Tinha cerca de quinze anos, mas por seu talento ultrapassava já muitos homens maduros e doutos. Confesso-te que eram dons teus, meu Senhor e meu Deus, criador de todas as coisas, tão poderoso para corrigir nossas deformidades, pois este menino nada havia de meu, senão meu pecado. Se o criei em tua disciplina, foste tu, e mais ninguém, quem no-lo inspirou. Sim, confesso que eram dons teus.

 Há um livro meu que se intitula O Mestre, no qual Adeodato dialoga comigo. Tu sabes que todos os pensamentos ali manifestados são dele quando tinha dezesseis anos. Muitas outras qualidades maravilhosas notei ainda nele, admirado por sua inteligência. Mas quem, além de ti, poderia ser o autor dessas maravilhas? Cedo o arrebataste desta terra; e a lembrança dele se torna mais tranqüila, nada mais tendo a temer por sua infância, por sua adolescência ou por toda sua vida adulta. Associamo-lo a nós como irmão na graça, para educá-lo em tua lei. Fomos batizados, e os remorsos de nossa vida passada se afastaram de nós.

 Naqueles dias eu não me fartava de considerar a grandeza de teus desígnios para a salvação do gênero humano, pela inefável doçura que sentia. Quanto chorei ao ouvir, profundamente comovido, teus hinos e cânticos que ressoavam suavemente em tua Igreja! Penetravam aquelas vozes em meus ouvidos, e destilavam a verdade em meu coração. Acendiase em mim um afeto piedoso, corriam-me lágrimas dos olhos, e o pranto me consolava.

## CAPÍTULO VII

### O canto dos fiéis. Os corpos de São Gervásio e de São Protásio

 Não havia muito tempo que a igreja de Milão começara a adotar essa prática consoladora e edificante do canto, com grande regozijo dos fiéis, que uniam em um só coro as vozes e o coração. Havia um ano, ou pouco mais, que Justina, mãe do imperador Valentiniano, ainda menor, seduzida pelos arianos, perseguia, por causa de sua heresia, teu servo Ambrósio. O povo fiel passava as noites na igreja, disposto a morrer com seu bispo.

 Nesse meio estava minha mãe, tua serva, uma das primeiras no zelo dessas inquietações e vigílias, não vivendo senão de orações. Nós, apensar de ainda frios, sem o calor de teu Espírito, nos sentíamos comovidos pela perturbação e consternação da cidade.

 Foi então que se fixou o costume de cantar hinos e salmos, como se faz no Oriente, para que os fiéis não se consumissem no tédio e na tristeza. Desde esse dia esse costume mantevese, e no resto do mundo, quase todas as tuas comunidades de fiéis passaram a adotá-lo.

 Foi também nessa época que revelaste em sonho ao bispo Ambrósio o lugar em que jaziam ocultos os corpos dos mártires Gervásio e Protásio, que durante muito tempo, conservastes intactos no tesouro de teus segredos, a fim de revelá-los no momento oportuno para refrear o furor de uma mulher, embora imperatriz.

 Com efeito, depois de descobertos e desenterrados, ao serem transladados com as honras convenientes para a basílica ambrosiana, alguns possessos, atormentados pelos espíritos imundos, foram curados, conforme confissão dos próprios demônios. Também um cidadão, cego havia muitos anos, e muito conhecido na cidade, perguntou a razão daquele alvoroço e alegria populares; informado, pediu a seu guia que o levasse até ás relíquias. Lá chegando, obteve permissão para tocar com um lenço o ataúde de teus santos, cuja morte havia sido preciosa a teus olhos. Feito isto, aplicou o lenço aos olhos, que imediatamente se abriram.

 A noticia do milagre logo se propagou, e imediatamente se ouviram teus louvores com fervor, e o coração de tua inimiga, sem se converter à tua fé, reprimiu contudo o furor da perseguição.

 Graças te dou, meu Deus! De onde e para onde guiaste minha memória, para que também te confessasse estes acontecimentos que, embora grandes, eu já havia esquecido e omitido?

 Todavia, quando assim exalava o odor de teus perfumes, eu ainda não corria atrás de ti. Eis que redobrava minhas lágrimas ao ouvir teus cânticos. Outrora eu suspirava por ti, e enfim respirava o pouco ar de uma choça de feno (alusão ao profeta Isaias,40,6)

## CAPÍTULO VIII

### Mônica

 Tu, que fazes morar na mesma casa os que têm coração unânime, trouxeste pra junto de nós Evódio, jovem de nosso município que, militando como agente de negócios do imperador, se convertera e recebera o batismo antes de nós, abandonara a milícia do século, alistando-se na tua.

 Estávamos juntos, e juntos pensávamos viver nosso santo propósito. Buscávamos um lugar onde nos pudéssemos instalar mais comodamente para te servir e juntos rumávamos para a África quando, chegando a Óstia, na foz do Tibre, faleceu minha mãe.

 Muitas coisas passo em silêncio, porque tenho pressa. Recebe minhas confissões e ações de graças, meu Deus, pelas inúmeras bondades que não menciono aqui. Mas não quero calar o que brota de minha alma a respeito desta tua serva, que me gerou na carne para a luz temporal, e no coração para a luz eterna. Não referirei suas qualidades, nem a si mesma se havia educado. Foste tu quem a educaste, nem seu pai, nem sua mãe sabiam o que viriam a ser aquela a quem geraram. A disciplina de teu Cristo, a doutrina de teu Filho único educaram-na em teu temor em uma família fiel, digno membro de tua Igreja.

 Nem ela mesma enaltecia o zelo da mãe em educá-la, quanto o de uma velha serva, que carregara seu pai quando menino, como hoje as meninas maiores costumam carregar as crianças, às costas.

 Estas recordações, sua idade avançada e hábitos exemplares lhe asseguravam naquela casa cristã o respeito de seus amos. Ela própria cuidava solicitamente das meninas que lhe haviam sido confiadas, ora repreendendo-as quando fosse o caso, com santa e enérgica severidade, ora instruindo-as com discreta prudência. Afora do horário em que tomavam uma sóbria refeição à mesa de seus pais, ainda que tivessem muita sede, nem água permitia que elas bebessem, precavendo com isso um mau costume. E acrescentava este sábio aviso: "Agora bebeis água, porque não tendes como beber vinho; mas quando estiverdes casadas, donas da despensa e da adega, deixareis a água, mas continuará o hábito de beber".

 E unindo assim o conselho à autoridade, refreava os apetites daquela tenra idade, e acostumava aquelas jovens à temperança, para que não tivesse desejo do que não lhes convinha.

 No entanto – como tua serva me contou a mim, seu filho – insinuou-se nela certo gosto pelo vinho. Julgando-a menina sóbria, seus pais a escolheram, como era costume, para tirar o vinho do tonel. Mergulhava a caneca pela parte superior do recipiente e, antes de passar o vinho para a garrafa, sorvia com a ponta dos lábios um pouquinho; era-lhe impossível beber mais, porque o vinho lhe repugnava. Não fazia isto movida pela inclinação à embriaguez, mas pela exuberância juvenil, que se manifestava em movimentos, em brincadeiras, e que na meninice costumam ser reprimidos pela autoridade severa dos mais velhos. Mas, acrescentando todos os dias uns goles àqueles goles – pois quem descuida das coisas pequenas pouco a pouco cai nas maiores – acostumou-se a esvaziar avidamente copos quase cheios de vinho puro.

 Onde estava então a prudente anciã, e sua severa proibição? Mas que remédio curaria um mal oculto se tua medicina, Senhor, não velasse sobre nós? Na ausência do pai, da mãe e das amas, estavas lá tu que nos criaste, que nos chamas, e que por meio dos que nos educam fazes o bem para a salvação das almas. Que fizeste então, meu Deus? Como a socorreste? Como a curaste? Fizeste sair de outra pessoa, segundo tuas secretas providências, um sarcasmo duro e pungente como ferro medicinal, para curar de um só golpe aquela gangrena.

 A criada que costumava acompanhá-la à adega, discutindo com sua jovem senhora, como às vezes acontece, estando as duas a sós, lançou-lhe em rosto sua intemperança, chamando-a insultuosamente de bêbada. Ferida por esse sarcasmo, a jovem reconheceu a fealdade daquele hábito, reprovou-o, e no mesmo instante o abandonou.

 Assim como muitas vezes as lisonjas dos amigos nos pervertem, assim os insultos dos inimigos nos corrigem. Mas não é o bem que nos fazem por seu intermédio que retribuis, mas a intenção com que o fazem. Aquela criada zangada pretendia ofender sua jovem senhora, e não corrigi-la; e se o fez às escondidas foi só por força da circunstância do lugar e tempo, ou para que não viesse a sofrer por denunciar tão tarde o costume de sua senhora.

 Mas, tu, Senhor, governador do céu e da terra, que desvias para teus desígnios as águas da torrente e regulas o curso turbulento dos séculos, curaste a loucura de uma alma com a insânia de outra. Por isso ninguém, ao considerar o caso, atribua a seu poder pessoal o mérito de ter corrigido com suas palavras a alguém cuja emenda deseja conseguir.

## CAPÍTULO IX

### Esposa e mãe exemplar

 Educada assim na modéstia e na temperança, mais sujeita a seus pais pela tua mão que por seus pais a ti, logo que chegou à idade núbil, foi dada em matrimônio a um homem, a quem serviu como a senhor. Procurou conquistá-lo para ti, falando0lhe de ti com suas virtudes, com as quais tu a tornavas bela e reverentemente amável e admirável ante seus olhos. Suportou suas infidelidades conjugais com tanta paciência, que jamais teve com ele a menor briga por isso, pois esperava que tua misericórdia viria sobre ele, e que lhe trouxesse, com a fé, a castidade.

 Seu marido, se de um lado era sumamente afetuoso, por outro era extremamente colérico, mas ela tinha o cuidado de não contrariá-lo nem com ações, nem com palavras, se o visse irado. Logo que o via calmo e sossegado, oportunamente, mostrava-lhe o que havia feito, se por acaso se tivesse irritado desmedidamente.

 Muitas senhoras, embora tendo maridos mais calmos, traziam no rosto as marcas das pancadas que as desfiguravam. Conversando entre amigas, lamentavam a conduta dos maridos. Minha mãe reprovava-lhes a língua e, como por gracejo, lembrava-lhes que, desde a leitura do contrato matrimonial, deviam considerá-lo como documento que as tornava servas, e portanto proibia-lhes de serem altivas com seus senhores. Essas senhoras, que conheciam o mau gênio de seu marido, admiravam-se de que jamais ninguém tivesse ouvido ou percebido qualquer indício que Patrício maltratasse a mulher, nem sequer que algum dia tivessem brigado por questões domésticas. E como lhe pedissem confidencialmente a razão disso, minha mãe expunha-lhes seu agir habitual, como acima mencionei. Algumas, após experimentar, punham-no em prática e davam-lhe graças; as que não a imitavam continuavam a sofrer humilhações e violências.

 Sua sogra, a princípio irritara-se contra ela por causa dos mexericos de criadas malévolas. Mas conseguiu conquistá-la com respeito, contínua tolerância e mansidão, que ela mesma, espontaneamente, denunciou ao filho as línguas intrigantes das criadas, que perturbavam a paz doméstica entre ela e a nora, e pediu que as castigasse. Ele, em obediência à mãe, para manter a disciplina familiar e a harmonia entre os seus, mandou açoitar as acusadas, segundo a vontade da acusante; e esta prometeu-lhes ainda que esse era o prêmio que devia esperar quem, querendo agradá-la, lhe dissesse mal da nora. E ninguém mais se atreveu a fazê-lo, e viveram as duas em doce e memorável harmonia.

 A esta tua boa serva, em cujo seio me criaste, ó meu deus, minha misericórdia, dotaste de outra grande virtude: a de intervir como pacificadora, sempre que podia, nas discórdias e querelas. Daquilo que ouvia de queixas amargas, vomitadas com animosidade ressentida, quando na presença de uma amiga os ódios mal digeridos se desafogam em amargas confidencias a respeito de uma amiga ausente, ela nada referia uma à outra, senão o que poderia servir para a reconciliação.

 Este dom me pareceria de pouca monta se uma triste experiência não me houvesse mostrado grande número de pessoas – por não sei que horrível contagio de pecados, espalhados por toda parte – que não só revelam as palavras pesadas de inimigos irados, mas que ainda acrescentam coisas que não foram ditas. Quem fosse realmente humano, deveria ter em pouca conta ou não excitar nem fomentar as inimizades dos homens, e melhor ainda procurar extinguilas com boas palavras.

Assim era minha mãe, ensinada por ti, mestre interior, na escola de seu coração.

 Por fim, conquistou para ti o seu marido, já no fim da vida, não tendo que lamentar no cristão o que havia tolerado no infiel.

 Ela era verdadeiramente a serva de teus servos, e todos os que a conheciam te louvavam, honravam, te amavam em sua pessoa, porque percebiam tua presença em seu coração, confirmada pelos frutos de uma vida santa.

 Havia sido mulher de um só homem, cumprira sua dívida de gratidão com os pais, governara sua casa piedosamente e dava testemunho com suas boas obras. Educara os filhos, dando-os à luz tantas vezes quantas os via apartarem-se de ti.

 E de nós, que nos chamamos teus servos por liberalidade tua, nós que vivemos em comum na graça de teu batismo, antes de adormecer em tua paz, ela cuidou de nós como se todos fôssemos seus filhos, e de tal modo nos serviu como se fosse filha de cada um de nós.

## CAPÍTULO X

### O êxtase de Óstia

 Estando já próximo o dia em que teria de partir desta vida – que tu, Senhor, conhecias, e nós ignorávamos – sucedeu, creio, por disposição de teus ocultos desígnios – que nos encontrássemos sós, eu e ela, apoiados em uma janela que dava para o jardim interior da casa em que morávamos. Era em Óstia, sobre a foz do Tibre, onde, longe da multidão, depois do cansaço de uma longa viagem, recobrávamos forças para a travessia do mar.

 Ali, sozinhos, conversávamos com grande doçura, esquecendo o passado, ocupados apenas no futuro, indagávamos juntos, na presença da Verdade, que és tu, qual seria a vida eterna dos santos, que nem os olhos viram, nem os ouvidos ouviram, nem o coração do homem pode conceber. Abríamos ansiosos os lábios de nosso coração ao jorro celeste de tua fonte – da fonte da vida que está em ti – para que, banhados por ela, pudéssemos de algum modo meditar sobre coisa tão transcendente.

 Nossa conversa chegou à conclusão que nenhum prazer dos sentidos carnais, por maior que seja, e por mais brilhante e maior que seja a luz material que o cerca, não parece digno de ser comparado à felicidade daquela vida em ti. Elevando nosso sentimento para mais alto, mais ardentemente em direção ao próprio Ser, percorremos uma a uma todas as coisas corporais, até o próprio céu, de onde o sol, a luz e as estrelas iluminam a terra.

 E subimos ainda mais em espírito, meditando, celebrando e admirando tuas obras, e chegamos até o íntimo de nossas almas. E fomos além delas, para alcançar a região da abundância inesgotável, onde apascentas eternamente a Israel com o alimento da verdade, lá onde a vida é a própria Sabedoria, por quem foram criadas todas as coisas, as que já existem e as vindouras, sem que ela própria se crie a si mesma, pois existe agora como antes existiu e como sempre existirá. Antes, nela não há nem passado, nem futuro: ela apenas é, porque é eterna; mas ter sido ou haver de ser não é próprio do ser eterno.

 E enquanto assim falávamos dessa Sabedoria e por ela suspirávamos, chegamos a tocá-la momentaneamente com supremo ímpeto de nosso coração; e, suspirando, deixando ali atadas as primícias de nosso espírito, e voltamos ao ruído vazio de nossos lábios, onde nasce e morre a palavra humana, em nada semelhante a teu Verbo, Senhor nosso, que subsiste em si sem envelhecer, renovando todas as coisas!

 E dizíamos: Suponhamos que se calasse o tumulto da carne, as imagens da terra, da água, do ar e até dos céus; e que a própria alma se calasse, e se elevasse sobre si mesma não pensando mais em si; se calassem os sonhos e revelações imaginarias e, por fim, se calasse por completo toda língua, todo sinal, e tudo o que é fugaz – uma vez que todas as coisas dizem a quem sabe ouvi-las: Não fizemos a nós mesmas; fez-nos o que permanece eternamente – se, dito isto, todas se calassem, atentas a seu Criador; e se só ele falasse, não por suas obras, mas por si mesmo, de modo que ouvíssemos sua palavra, não por uma língua material, nem pela voz de um anjo, nem pelo ruído do trovão, nem por parábolas enigmáticas, mas o ouvíssemos a ele mesmo, a quem amamos nas suas criaturas, mas sem o intermédio delas, como agora acabamos de experimentar, atingindo em um relance a eterna Sabedoria, que permanece imutável sobre toda realidade, e supondo que essa visão se prolongasse, que todas as outras visões cessassem, e unicamente esta arrebatasse a alma de seu contemplador, e a absorvesse e abismasse em íntimas delícias, de modo que a vida eterna seja semelhante a este momento de intuição que nos fez suspirar, não seria isto a realização do entrar em gozo de teu Senhor? Mas quando se dará isto? Por acaso quando todos ressuscitarmos? Mas então não seremos todos transformados?

 Tais coisas dizíamos, embora não deste modo, nem com estas palavras. Mas tu sabes, Senhor, que naquele dia, à medida que falávamos dessas coisas, quanto nos parecia vil este mundo, com todos os seus deleites – disse-me minha mãe: "Filho, quanto a mim, já nada me atrai nesta vida. Não sei o que faço ainda aqui, nem por que ainda estou aqui, se já se desvaneceram pra mim todas as esperanças do mundo. Uma só coisa me fazia desejar viver um pouco mais, e era ver-te católico antes de morrer. Deus me concedeu esta graça superabundantemente, pois te vejo desprezar a felicidade terrena para servi-lo. Que faço, pois, aqui?"

## CAPÍTULO XI

### A morte de Mônica

 Não me lembro bem o que respondi a tais palavras. Mas cerca de cinco dias mais tarde, ou pouco mais, caiu de cama, com febre. Durante a doença, teve um dia um desmaio, ficando por pouco tempo sem sentidos e sem reconhecer os presentes. Acudimos de imediato, e logo voltou a si. Vendo-nos a seu lado, a mim e a meu irmão (chamava-se Navígio, e era o mais velho dos irmãos), perguntou-nos, como quem procura algo: "Onde estava eu?" – Depois, vendo-nos atônitos de tristeza, nos disse: "Sepultareis aqui a vossa mãe" – Eu me calava, retendo as lágrimas, mas meu irmão disse umas palavras em que desejava vê-la morrer na pátria e não em terras distantes. Ao ouvi-lo, minha mãe repreendeu-o com o olhar, e aflita por ter pensado em tais coisas; depois, olhando para mim, disse: "Vê o que ele diz" – E depois para ambos: "Sepultem este corpo em qualquer lugar, e não se preocupem mais com ele. Peço apenas que se lembrem de mim diante do altar do Senhor, onde quer que estejam". E tendo-nos exposto seu pensamento com as palavras que pôde, calou-se; sua moléstia agravou-se e suas dores aumentaram.

 Mas eu, ó Deus invisível, meditando nos dons que infundes no coração de teus fiéis, e nas admiráveis colheitas que deles brotam, alegrava-me e te dava graças. Lembrava-me do grande cuidado que sempre demonstrara acerca de sua sepultura, adquirida e preparada junto ao corpo do marido. Tendo vivido com ele na maior concórdia, assim também queria – visão própria da alma humana incapaz das coisas divinas – ter a felicidade de que os homens recordassem que, depois de sua viagem para além-mar, lhe fora concedida a graça de a mesma terra cobrir o pó de ambos os cônjuges.

 Quando esta vaidade havia deixado de existir em seu coração, pela plenitude de tua bondade, eu não o sabia, mas alegrava-me com admiração ao ouvi-la falar assim. No entanto, naquela conversa à janela quando me disse: "Que faço eu aqui?" – já estava patente que não mais desejava morrer na pátria.

 Soube também depois que em Óstia, estando eu ausente, falou certo dia com alguns amigos meus, com maternal confiança, sobre o desprezo desta vida e o benefício da morte. Eles, maravilhados da coragem dessa mulher – dádiva tua – perguntaram-lhe se não temia deixar o corpo tão longe da pátria. "Nada está longe para Deus – disse ela – nem preciso temer que ele ignore, no fim dos tempos, o lugar onde me ressuscitará".

 Por fim, nove dias após cair enferma, aos cinqüenta e seis anos de idade e aos trinta e três da minha, aquela alma santa e piedosa libertou-se do corpo.

## CAPÍTULO XII

### As lágrimas negadas

 Fechei-lhe os olhos, e uma tristeza imensa invadiu-me o coração, e já me ia desfazer em lágrimas; ao mesmo tempo, meus olhos, obedecendo ao enérgico poder de minha vontade, fechavam sua fonte até secá-la. Como foi angustiosa essa luta! E foi quando ela deu o último suspiro, que o meu filho Adeodato rebentou em soluços; mas, instado por todos nós, se calou. Deste modo sua voz juvenil, voz do coração, calou em mim essa espécie de emoção pueril que me provocava o pranto. De fato, não julgávamos correto celebrar aquele funeral com lágrimas e choro, pois tais demonstrações deploram geralmente o triste destino dos que morrem, ou sua total extinção. A morte de minha mãe não era uma desgraça, e ela não morria para sempre, e disto estávamos certos pelo testemunho de seus costumes, por sua fé sincera e outras razões inequívocas.

 Que era então o que tanto me pungia, senão a ferida recente causada pelo rompimento repentino de nosso dulcíssimo e querido convívio?

 Era para mim grande consolação o testemunho que dera de mim, quando nesta última enfermidade, respondendo com ternura às minhas atenções, chamava-me de bom filho, e recordava com grande afeto o nunca ter ouvido de minha boca uma só palavra dura ou injuriosa contra ela. Entretanto, o que era, meu Deus e meu Criador, a solicitude que eu lhe tributava, em comparação com o devotamento servil que por mim suportava? Por me ver privado de tão grande consolo, sentia a alma ferida e minha vida, que era uma só com sua, estava despedaçada.

 Reprimido o pranto do Adeodato, Evódio tomou o saltério e começou a cantar um salmo, ao que todos respondíamos "Misericórdia e justiça te cantarei Senhor". Conhecia a notícia de sua morte, acorreram muitos irmãos e mulheres piedosas e, enquanto os encarregados dos funerais faziam seu ofício conforme o hábito, retirei-me para um lugar conveniente, junto com os amigos que julgavam oportuno não me deixar só. Falava sobre assuntos próprios das circunstâncias, e com o lenitivo da verdade mitigava meu sofrimento, só conhecido por ti. Eles o ignoravam e me ouviam atentamente, julgando que não sofria nenhuma dor.

 Mas eu, pertinho de teus ouvidos, onde ninguém me podia escutar, censurava a minha sensibilidade e fraqueza e reprimia a onda de tristeza que me invadia; esta cedia por uns instantes, e novamente me arrastava com seu ímpeto, embora não chegasse a derramar lágrimas ou alterar a face. Somente eu sabia quão oprimido estava meu coração! E como me desgostava profundamente que as vicissitudes humanas tivessem tanto poder sobre mim, que são inelutáveis pela ordem natural e a sorte de nossa condição; minha própria dor causava-me outra dor, e me afligia com dupla tristeza.

 Quando o corpo foi levado à sepultura, fui e voltei sem derramar uma lagrima. Nem mesmo nas orações que te fizemos, quando oferecemos o sacrifício de nossa redenção por intenção da morta, cujo cadáver jazia junto ao sepulcro antes de ser inumado, como ali é costume, nem mesmo nessas orações, chorei. Mas durante todo o dia andei oprimido por grande tristeza interior; pedia-te como podia, com a mente perturbada, que aliviasses minha dor. Mas não me atendias, sem dúvida para que fixasse, bem na memória, ao menos por esta única experiência, como são poderosos os laços do costume, mesmo em uma alma que já não se alimentava de palavras enganadoras.

 Lembrei então a ir aos banhos, por ter ouvido dizer que a palavra banho (bálneo, em latim) vinha dos gregos, que o chamaram balanéion (tirar fora a ania), porque o banho aliviava as tristezas da alma. Mas eu o confesso à tua misericórdia – ó Pai dos órfãos: depois do banho fiquei como estava antes, porque meu coração não expulsou o amargor de sua tristeza.

 Depois adormeci. Ao despertar, minha dor estava mitigada; só, em meu leito, lembrei-me dos versos cheios de verdade de teu Ambrósio. Porque, na verdade

Tu és Deus, criador de quanto existe,

De todo o mundo supremo governante,

Que o dia vestes com tua luz brilhante,

E de sonhos gratos a noite triste

 A fim de que os membros cansados O descanso ao trabalho prepare

E as mentes cansadas, repare

E os peitos de pena oprimidos

 Depois, pouco a pouco voltava aos sentimentos de antes sobre tua serva. Recordava de sua piedade para contigo, de sua solicitude e paciência comigo, da qual subitamente me via privado. E senti consolação em chorar diante de ti, por causa dela e por ela, e por minha causa e por mim. E deixei que as lágrimas reprimidas corressem à vontade, estendendo-as como um leito reparador sob meu coração. Teus ouvidos eram os que ali me escutavam, e não os de nenhum homem, que pudesse interpretar com soberba meu pranto.

 E agora, Senhor, to confesso nestas linhas: leia-o quem quiser, interprete-o como quiser. E se alguém julgar que pequei nessas lágrimas, que derramei sobre minha mãe por alguns instantes, por minha mãe então morta a meus olhos, ela que me havia chorado tantos anos para que eu vivesse aos teus olhos, não se ria. Antes, é grande sua caridade, chore por meus pecados diante de ti, Pai de todos os irmãos de teu Cristo!

## CAPÍTULO XIII

### Preces pela mãe morta

 Agora, com a ferida do meu coração já sanada, na qual se podia censurar um afeto muito carnal, derramo diante de ti, meu Deus, por tua serva, outra espécie de lágrimas, bem diferentes, aquelas que brotam do espírito comovido à vista dos perigos que corre toda alma que morre em Adão. É verdade que minha mãe, vivificada em Cristo, antes mesmo de ser livre dos laços da carne, viveu de tal modo, que teu nome era louvado em sua fé e em seus costumes. Contudo, não me atrevo a dizer que desde que a regeneraste no batismo não saiu de sua boca nenhuma palavra contrária à tua lei. Porque a Verdade, que é teu Filho, disse: "Quem chamar a seu irmão de louco será réu do fogo da geena". Ai da vida dos homens, por mais louvável que seja, se tu a julgares sem a tua misericórdia! Mas porque não examinas nossos pecados com rigor, confiadamente esperamos tomar lugar a teu lado. Quem enumera diante de ti seus próprios méritos, que mais expõe senão teus dons? Oh! Se os homens se reconhecessem como homens! Se quem se glorifica se glorificasse no Senhor!

 Por isso, Deus de meu coração, minha vida e minha gloria, esquecendo por um momento as boas ações de minha mãe, pelas quais te dou graças com alegria, peço-te agora perdão por seus pecados. Ouve-me pelos méritos daquele que é o médico de nossas feridas, que foi suspenso do madeiro da cruz e que, sentado agora à tua direita, intercede por nós junto a ti. Eu sei que ela sempre agiu com misericórdia, e que perdoou de coração todas as faltas contra ela cometidas; perdoa-lhe também suas dívidas, se algumas contraiu em tantos anos que se seguiram ao batismo. Perdoa-lhe, Senhor, perdoa-lhe, te suplico, e não entres em juízo com ela.

 Triunfe a misericórdia sobre a justiça pois as tuas são palavras de verdade, e prometeste misericórdia aos misericordiosos. Se alguém o foi, deve-o à tua graça, tu que tens compaixão de quem te apraz, e usas de misericórdia com quem queres ser misericordioso.

 Creio que já fizeste o que te suplico, mas desejo, Senhor, que acolhas os desejos de minha boca. Estando iminente o dia de sua morte, ela não desejou sepultar o corpo com grande pompa, ou que fosse embalsamado com preciosos aromas, nem desejou um rico monumento, nem se preocupou em tê-lo na pátria. Nada disto nos pediu, mas desejou apenas que nos lembrássemos dela ante do teu altar, onde servira todos os dias de sua vida, sabendo que nele se oferece a vítima santa, com cujo sangue se destrói o libelo de nossa condenação, e pelo qual vencemos o inimigo que conta nossas faltas e procura com que nos acusar, nada achando naquele que é nossa vitória.

 Quem poderá devolver-lhe seu sangue inocente? Quem poderá restituir-lhe o preço pago por nosso resgate, para nos arrancar ao inimigo? A este mistério de nossa redenção ligou tua serva sua alma com o vínculo da fé. que ninguém a afaste de tua proteção. Que entre ela e ti não se interponha, nem pela força, nem pelo engano, o leão ou o dragão. Ela não responderá que nada deve, para não ser convencida e arrebatada pelo astuto acusador, responderá que suas dívidas lhe foram perdoadas por aquele a quem ninguém pode restituir o que por nós pagou sem nada dever.

 Que ela repouse em paz com seu marido, antes e depois do qual não teve outro; a quem serviu, com uma paciência cujo fruto te oferecia, para o ganhar também para ti. Mas inspira, meu Senhor e meu Deus, inspira a teus servos, meus irmãos, a teus filhos, meus senhores, a quem sirvo de coração, com a palavra e com a pena, para que, ao lerem estas páginas, diante do teu altar lembrem de Mônica, tua serva, e de Patrício, outrora seu esposo, pelos quais me introduziste misteriosamente nesta vida. Que lembrem com piedoso afeto daqueles que foram meus pais nesta vida transitória, e meus irmãos em ti, ó Pai, na Igreja Católica, nossa mãe, e meus concidadãos na eterna Jerusalém, pela qual suspira teu povo em sua peregrinação desde a saída até o regresso. Assim, graças às minhas confissões, o último desejo de Mônica será mais amplamente satisfeito com muitas orações do que só pelas minhas.

# LIVRO DÉCIMO

## CAPÍTULO I

### Finalidade do livro

 Ó Deus, faz que eu te conheça, meu conhecedor, que eu te conheça como de ti sou conhecido. Virtude de minha alma, penetra-a, assemelha-a a ti, para que a tenhas e possuas sem mancha nem ruga.

 Esta é a esperança com que falo, e nesta esperança me alegro, quando gozo de sã alegria. Tudo o mais desta vida, tanto menos se há de chorar quanto mais o choramos, e tanto mais teríamos que chorar quanto menos o choramos.

 Mas tu amaste a verdade, porque quem a pratica alcança a luz. Eu desejo praticá-la em meu coração, diante de ti, por esta minha confissão, e diante de muitas testemunhas por meus escritos.

## CAPÍTULO II

### O que é confessar a Deus

 E, para ti, Senhor, que conheces o abismo da consciência humana, que poderia haver de oculto em mim, ainda que não to quisesse confessar?

 Poderia apenas esconder-te de mim, e nunca me esconder de ti. Agora que meus gemidos dão testemunho do desagrado que sinto por mim, tu me iluminas e me agradas, e és amado e desejado a ponto de eu me envergonhar de mim. renuncio a mim para te escolher, e não quero agradar a ti ou a mim senão por teu amor.

 Portanto, assim como sou, Senhor, tu me conheces. Já te disse com que escopo me vou confessando a ti. Faço esta confissão não com palavras e vozes do corpo, mas com as palavras da alma e o brado da inteligência, que teus ouvidos conhecem. Quando sou mau, confessar-me ai é o mesmo que desprezar a mim próprio; quando sou bom, é apenas nada atribuir a mim mesmo. Porque tu, Senhor, abençoas o justo, mas antes tornas justo ao pecador.

 Assim, meu Deus, a confissão que faço em tua presença, é e não é silenciosa; a boca se cala, mas meu coração clama. Tudo o que digo aos homens de verdadeiro já tinhas ouvido de mim, e nem ouves nada de mim que antes não me tivesses dito.

## CAPÍTULO III

### Por que se confessar aos homens?

 Que tenho eu que ver com os homens, para que me ouçam as confissões, como se eles pudessem curar as minhas enfermidades? São curiosos para conhecer a vida alheia, mas indolentes para corrigir a própria! Por que desejam ouvir de mim quem sou, quando não se importam em saber de ti o que são? E como podem saber, ao me ouvirem falar de mim mesmo, se lhes digo a verdade, uma vez que homem algum sabe o que se passa no outro, senão o espírito do homem, que nele, habita? Mas, se ouvissem a ti falar deles, não poderiam dizer: "O Senhor mente". E o que é ouvir-te falar de si, senão conhecerem-se a si mesmos? E quem, conhecendo a si mesmo, pode dizer "é falso", sem mentir?

 A caridade crê em tudo – pelo menos entre corações que ela unifica em si por seus laços – por isso também eu, Senhor, me confesso a ti para que me ouçam os homens. A eles não posso provar que falo a verdade; mas crêem-me aqueles cujos ouvidos a caridade abre para mim.

 Mas tu, Médico da minha alma, faze-me ver claramente a utilidade de meu propósito. As confissões de meus pecados passados – que já perdoaste e esqueceste, para me fazer feliz em ti, transformando minha alma com tua fé e teu sacramento – levam o coração dos que as lêem e ouvem a não dormir no desespero dizendo: "Não posso". Mas despertem para o amor pela tua misericórdia e para a doçura de tua graça, que fortalece o fraco e este se dá conta de sua debilidade.

 Os bons, por sua vez, se agradam em ouvir os pecados passados daqueles que já não sofrem. Agrada-lhes, não por serem pecados, mas porque o foram, e agora já não o são.

 Mas, Senhor meu – a quem todos os dias se confessa minha consciência, agora mais confiante com a esperança na tua misericórdia que na sua inocência – que proveito haverá em confessar aos homens, na tua presença, neste livro, não o que fui, mas o que sou agora? Sobre a confissão do passado, e dos seus eventuais proveitos, já falei acima.

 Há muitos porém, quer me conheçam, quer não, que desejam saber quem sou agora, neste momento em que escrevo as Confissões. Já ouviram de mim ou de outros alguma coisa a meu respeito, mas seu ouvido não ouve meu coração, onde eu sou o que sou. Querem, certamente, saber por confissão minha o que sou no íntimo, lá onde não podem penetrar com a vista, com o ouvido, ou com a mente. Estão dispostos a acreditar em mim. Mas poderão igualmente estar certos de me conhecer? A caridade, que os torna bons, lhes diz que eu não minto quando confesso tais coisas de mim. É ela que os faz acreditarem em mim.

## CAPÍTULO IV

### O fruto das confissões

 Mas, com que propósito desejam ouvir-me? Desejarão talvez congratular-me comigo, ouvindo quanto me aproximei de ti por tua graça, e orar por mim, ao ouvir quanto me retardou o peso de minhas culpas? A estes mostrarei quem sou; já não é pequeno fruto, Senhor meu Deus, que muitos te dêem graças por mim, e que muitos te roguem por mim. possa o coração de meus irmãos amar em mim o que ensinas a amar, e, deplorar em mim o que ensinas a aborrecer! Mas que brotem tais sentimentos em uma alma irmã, e não em almas estranhas, ou nesses filhos espúrios, cuja boca fala vaidade, e cuja direita é a direita da iniqüidade, que o faça uma alma fraterna que se alegra por mim quando me aprova, e quando me reprova se aflige por mim, porque quer me aprove, quer não, me ama.

 É a esses que me revelarei. Que eles respirem diante de minhas boas ações, e suspirem à vista de meus pecados. As obras boas são tuas obras e teus dons; as más são meus pecados. As obras boas são tuas obras e teus dons; as más são meus pecados, objeto de teus juízos. Respirem pelo bem e suspirem pelo mal, e que subam à tua presença hinos e lágrimas desses corações fraternos, que são os teus turíbulos.

 E tu, Senhor, que te alegras com a fragrância de teu santo templo, tem piedade de mim, segundo tua grande misericórdia por causa de teu nome, e tu, que jamais abandonas uma obra começada, aperfeiçoa em mim o que há de incompleto.

 Este poderá ser fruto de minhas confissões, não do que fui, mas do que sou. Farei minha confissão não apenas a ti, com íntima alegria mesclada de temor, e com secreta tristeza mesclada de esperança, mas também para os homens, que compartilham minha alegria e de minha mortalidade, meus concidadãos e peregrinos como eu, quer os que me precederam, como os que me seguem ou me acompanham no caminho da vida. Estes são teus servos, meus irmãos, que tu quiseste fossem filhos teus e meus senhores, e a quem me mandaste servir se quisesse viver contigo e de ti.

 Mas este preceito teria sido de pouco valor para mim, se teu Verbo o tivesse proferido apenas com palavras, e não tivesse mostrado o caminho com a obra. Eis que eu o imito pela ação e pela palavras, e o faço à sombra de tuas asas, o perigo seria grande demais, se minha alma aí não se abrigasse, e se minha fraqueza não te fosse conhecida.

 Sou como uma criança, mas meu Pai vive sempre, e é meu tutor idôneo; ele é a um tempo o que me gerou e o que me protege. Tu és todo o meu bem, tu, onipotente, que estás comigo mesmo antes de eu estar contigo.

 Revelarei pois, a estes, a quem me mandas servir, não como fui, mas como já sou agora, e como ainda não sou. Mas não quero julgar-me a mim mesmo. Assim é que peço para ser ouvido.

## CAPÍTULO V

### A ignorância do homem

 És tu, Senhor, quem me julga, porque ninguém conhece o que se passa no homem, a não ser o seu espírito que nele está, todavia há no homem coisas que até o espírito que nele habita ignora. Mas tu, Senhor, que o criaste, conheces todas as coisas. E eu, embora diante de ti me despreze e me considere como terra e cinza, sei algo de ti que ignoro de mim mesmo. É certo que agora vemos por espelho, em enigmas, e não face a face. Por isso, enquanto peregrino longe de ti, estou mais presente a mim do que a ti. Sei que em nada podes ser prejudicado, mas ignoro a que tentações posso resistir e a quais não posso. Todavia há esperança, pois és fiel, e não permites que sejamos tentados além de nossas forças; com a tentação, dás também meios para suportar, para que possamos resistir.

 Confessarei, portanto, o que sei de mim, e também o que de mim ignoro, porque o que sei de mim só o sei porque me iluminas, e o que de mim ignoro continuarei ignorando até que minhas trevas se transformem em meio-dia, em tua presença.

## CAPÍTULO VI

### Quem é Deus?

 O que sei, Senhor, sem sombra de dúvida, é que te amo. Feriste meu coração com tua palavra, e te amei. O céu, a terra e tudo quanto neles existe, de todas as partes me dizem que te ame; nem cessam de repeti-lo a todos os homens, para que não tenham desculpas. Terás compaixão mais profunda de quem já te compadeceste; e usarás de misericórdia com quem já foste misericordioso. De outro modo, o céu e a terra cantariam teus louvores a surdos.

 Mas, que amo eu, quando te amo? Não amo a beleza do corpo, nem o esplendor fugaz, nem a claridade da luz, tão cara a estes meus olhos, nem as doces melodias das mais diversas canções, nem a fragrância de flores, de ungüentos e de aromas, nem o maná, nem o mel, nem os membros tão afeitos aos amplexos da carne. Nada disto amo quando amo o meu Deus. E, contudo, amo uma luz, uma voz, um perfume, um alimento, um abraço de meu homem interior, onde brilha para minha alma uma luz sem limites, onde ressoam melodias que o tempo não arrebata, onde exalam perfumes que o vento não dissipa, onde se provam iguarias que o apetite não diminui, onde se sentem abraços que a saciedade não desfaz. Eis o que amo quando amo o meu Deus!

 Então, o que é Deus? Perguntei à terra, e ela me disse: "Eu não sou Deus". E tudo o que nela existe me respondeu o mesmo. Perguntei ao mar, aos abismos e aos répteis viventes, e eles me responderam: "Não somos teu Deus; busca-o acima de nós". Perguntei aos ventos que sopram; e todo o ar, com seus habitantes, me disse: "Anaxímenes está enganado eu não sou Deus". Perguntei ao céu, ao sol, à luz e às estrelas. "Tampouco somos o Deus a quem procuras" – me responderam.

 Disse então à todas as coisas que meu corpo percebe: "Dizei-me algo de meu Deus, já que não sois Deus; dizei-me alguma coisa dele" – e todas exclamaram em coro: "Ele nos criou" – Minha pergunta era meu olhar, e sua resposta a sua beleza.

 Dirigi-me, então, a mim mesmo, e perguntei: "E tu, quem és?" – e respondi: "Um homem". Para me servirem, tenho um corpo e uma alma: aquele exterior, esta interior. Por qual deles deverei perguntar pelo meu Deus, a quem já havia procurado com o corpo desde a terra até o céu, até onde pude enviar os raios de meu olhar como mensageiros? Melhor, sem dúvida, é a parte interior de mim mesmo. É a ela que dirigem suas respostas todos os mensageiros de meu corpo, como a um presidente ou juiz, respostas do céu, da terra, e de tudo o que existe, e que proclamam: "Não somos Deus" – e ainda – "Ele nos criou". O homem interior conhece essas coisas por meio do homem exterior; mas o homem interior, que é a alma, também conhece essas coisas por meio dos sentidos do corpo.

 Interroguei a imensidão do universo acerca de meu Deus, e ele me respondeu: "Não sou eu, mas foi ele quem me criou".

 Mas essa beleza não se manifesta a quantos têm sentidos perfeitos? E por que não fala a todos a mesma linguagem?

 Os animais, pequenos ou grandes, a vêem; mas não podem interrogá-la, porque não receberam a razão que, como juiz, interprete as mensagens dos sentidos. Os homens, porém, podem interrogá-la, para que as perfeições invisíveis de Deus se manifestem pelas suas obras. Mas o amor às coisas criadas os escraviza, e assim os torna incapazes de julga-las. Ora, elas só respondem aos que podem julgar-lhes as respostas. Elas não mudam sua linguagem, isto é, sua beleza, quando um só as vê, e outro as interroga; elas não lhes aparecem diferentes mas, para uns ficam mudas, enquanto falam a outros. Ou melhor: eles falam a todos, mas apenas se entendem os que comparam sua expressão exterior com a verdade interior. De fato a verdade me diz: "Teu Deus não é nem o céu, nem a terra, nem corpo algum. A natureza das coisas o diz para quem sabe ver; a matéria é menor em seus elementos que em seu todo. Por isso, minha alma, digo-te que és superior ao corpo, pois vivificas sua matéria, dando-lhe vida, como nenhum corpo pode dar a outro corpo. Mas teu Deus é também para ti a vida de tua vida.

## CAPÍTULO VII

### Deus e os sentidos

 Que amo, então, quando amo a meu Deus? Quem é aquele que está acima da minha alma? É por minha alma; portanto, que subirei até ele. Hei de sobrepujar a força que me ata ao corpo, e que enche meu organismo de vida, pois não encontro nela o meu Deus. Se assim fosse, o cavalo e a mula, que não têm inteligência, também o encontrariam, porque essa mesma força vivifica seus corpos.

 E existe outra força, que não só vivifica, mas que também torna sensível minha carne que o Senhor me deu, ordenando ao olho que não ouça, e ao ouvido que não veja, mas àquele que sirva para ver, e a este para ouvir; e que determinou a cada um dos outros sentidos o respectivo lugar e ofício. É deles que se serve minha alma para exercer suas diversas funções, permanecendo, contudo, uma só.

 Vencerei também essa força, que também a possuem o cavalo e a mula, pois também eles sentem por meio do corpo.

## CAPÍTULO VIII

### O milagre da memória

Vencerei então esta força de minha natureza, subindo por degraus até meu Criador.

 Chegarei assim diante dos campos, dos vastos palácios da memória, onde estão os tesouros de inúmeras imagens trazidas por percepções de toda espécie. Lá também estão armazenados todos os nossos pensamentos, quer aumentando, quer diminuindo, ou até alterando de algum modo o que nossos sentidos apanharam, e tudo o que aí depositamos, se ainda não foi sepultado ou absorvido no esquecimento.

 Quando ali penetro, convoco todas as lembranças que quero. Algumas se apresentam de imediato, outras só após uma busca mais demorada, como se devessem ser extraídas de receptáculos mais recônditos. Outras irrompem em turbilhão e, quando se procura outra coisa, se interpõem como a dizer: "Não seremos nós que procuras?" Eu as afasto com a mão do espírito da frente da memória, até que se esclareça o que quero, surgindo do esconderijo para a vista.

 Há imagens que acodem à mente facilmente e em seqüência ordenada à medida que são chamadas, as primeiras cedendo lugar às seguintes, e desaparecem, para se apresentarem novamente quando eu o quiser. É o que sucede quando conto alguma coisa de memória.

 Ali se conservam também, distintas em espécies, as sensações que aí penetraram cada qual por sua porta: a luz, as cores, as formas dos corpos, pelos olhos; toda espécie de sons, pelos ouvidos; todos os odores, pelas narinas; todos os sabores, pela boca; enfim, pelo tato de todo o corpo, o duro e o brando, o quente e o frio, o suave e o áspero, o pesado e o leve, quer extrínseco, como intrínseco ao corpo. A memória armazena tudo isso em seus vastos recessos, em suas secretas e inefáveis sinuosidades, para lembra-lo e trazê-lo à luz conforme a necessidade. Todas essas imagens entram na memória por suas respectivas portas, sendo ali armazenadas.

 Todavia, não são as coisas em si que entram na memória, mas as imagens das coisas sensíveis, que ali ficam à disposição do pensamento que as evoca. Mas quem poderá explicar como se formaram tais imagens, apesar de se conhecer o sentido pelo qual foram captadas e escondidas em seu íntimo? Pois, mesmo quando estou em silêncio e no escuro, imagino, se quiser, as cores, e sei distinguir o branco do preto, e todas as outras entre si; e isto sem que os sons, mesmo os lembrados, perturbem minhas imagens visuais, e permanecem como que a parte. Se decido chama-los, eles se apresentam imediatamente. Mesmo quando minha língua descansa e minha garganta se cala, canto quanto quero, sem que as imagens das cores, também presentes, se interponham ou perturbem enquanto me sirvo do tesouro que me entrou pelos ouvidos.

 Do mesmo modo as demais impressões, introduzidas e armazenadas em mim por meio dos outros sentidos, posso recordar a meu talante; distingo o aroma dos lírios do das violetas, sem cheirar nenhuma flor; e sem provar nem tocar em nada, mas apenas com a lembrança, posso preferir o mel ao arrobe e o macio ao áspero.

 Tudo isto realizo interiormente, no imenso palácio da memória. Ali eu tenho às minhas ordens o céu, a terra, o mar, com tudo o que neles pude perceber, com exceção do que já me esqueci. Ali encontro a mim mesmo, recordo de mim e de minhas ações, de seu tempo e lugar, e dos sentimentos que me dominavam ao praticá-las. Ali encontro a mim mesmo, recordo de mim e de minhas ações, de seu tempo e lugar, e dos sentimentos que me dominavam ao praticá-las. Ali estão todas as lembranças do que aprendi, quer pelo testemunho alheio, quer pela experiência. Deste mesmo manancial provém as analogias entre fatos de minhas experiências pessoais, ou em que acreditei baseado nas experiências previas; ligo umas e outras ao passado, e medito no futuro, nas ações, nos acontecimentos, nas esperanças, e tudo como se estivesse presente. "Farei isto ou aquilo" – digo para mim, nesse vasto universo de minha alma, repleto de imagens de tantas e tão grandes coisas. E disso tiro esta ou aquela conclusão. "Oh! Se acontecesse isto ou aquilo!" "Queira Deus não aconteça isto ou aquilo!" isto digo em meu íntimo, e nisso visualizando as imagens das realidades que exprimo, saídas do mesmo tesouro da memória; sem elas, nada poderia dizer.

 Grande é realmente o poder da memória, prodigiosamente grande, meu Deus! É um santuário amplo e infinito. Quem o pôde sondar até suas profundezas? É um poder próprio de meu espírito, que pertence à minha natureza; mas eu não sou capaz de compreender inteiramente o que sou. Será o espírito demasiado estreito para se conter a si mesmo? Onde, então, está o que ele não pode conter de si? Estaria fora dele, e não nele? Como então não o contém?

 Esta idéia me provoca grande admiração, e me enche de espanto. Viajam os homens para admirar as alturas dos montes, as grandes ondas do mar, as largas correntes dos rios, a imensidão do oceano, a órbita dos astros, e se esquecem de si mesmos! Nem se admiram que eu fale dessas coisas sem vê-las com os olhos; contudo, eu não as poderia mencionar se esses montes, se essas ondas, esses rios, esses astros, que eu vi, se esse oceano, no qual acredito pelo testemunho alheio, eu não os visse na memória em toda sua dimensão, como se estivessem diante de mim. mas quando eu os vi com meus olhos, eu não os absorvi; não são as coisas que se encontram dentro de mim, mas apenas suas imagens. E sei por qual sentido do corpo recebi a impressão de cada uma delas.

## CAPÍTULO IX

### A memória intelectual

 E não se limita a isto a imensa capacidade de minha memória. Ali estão, como em um lugar recôndito, que alias, não é um lugar, todas as noções aprendidas das artes liberais, pelo menos as que ainda não esqueci. Mas, neste caso, não são as imagens delas que trago em mim, mas as próprias realidades em si. As noções de literatura, a dialética, as diferentes espécies de questões, tudo o que sei a respeito desses problemas estão em minha memória, mas não estão ali como a imagem solta de uma coisa, cuja realidade se deixou fora. Nesse caso seria como um som que se ouve e passa, como a voz que deixa no ouvido um rastro, que permite que a lembremos, como se ainda soasse embora já não soe; ou como o perfume que, ao passar e desvanecer-se no ar, atinge o olfato e grava sua imagem na memória, imagem que a lembrança reproduz; ou como o alimento, que perde o sabor no estômago, mas o conserva na memória; ou como um corpo que se sente pelo tato e que, ausente, é imaginado pela memória. Todas essas realidades não nos penetram a memória, mas tão somente são captadas as suas imagens com maravilhosa rapidez, e dispostas, digamos, em compartimentos admiráveis, de onde são extraídas pelo milagre da lembrança.

## CAPÍTULO X

### Memória dos sentidos

 Ouço dizer que há três gêneros de questões a saber: se uma coisa existe, qual a sua natureza e qual sua qualidade – retenho a imagem dos sons de que se compõem estas palavras, e sei que estes atravessaram o ar como ruído, e já não existem. Mas as realidades significadas por tais palavras, eu jamais atingi com nenhum sentido do corpo, nem as vi em nenhuma parte fora de meu espírito; o que gravei na minha memória não são suas imagens, mas as próprias realidades. Que me digam, se o puderem, por onde entraram em mim! percorro em vão todas as portas do meu corpo, e não descubro por onde poderiam ter entrado. Com efeito: os olhos dizem: "Se são coloridas, fomos nós que as transmitimos." – Os ouvidos dizem: "Se eram sonoras, foram por nós comunicadas". – As narinas dizem: "Se tinham cheiro, passaram por aqui". – E o gosto diz: "Se não têm sabor, nada me perguntem". – O tato declara: "Se não são corpóreas, eu não as toquei, e portanto não poderia revelá-las"

 De onde, então, e por onde entraram em minha memória? Ignoro-o. Aprendi-as não dando crédito ao testemunho alheio, mas as reconheci em mim e aprovei-as como verdadeiras; confieias a meu espírito como em depósito, de onde poderei tirá-las quando quiser. Estavam pois ali, antes mesmo que eu as aprendesse, mas não na memória. E onde estavam então? E porque, ao serem mencionadas, eu as reconheci e disse: "É assim mesmo, é verdade" – senão porque já estavam em minha memória? Mas tão escondidas e sepultadas em tão secretos recessos, que se alguém não as arrancasse dali com suas perguntas, talvez eu nem pudesse concebê-las.

## CAPÍTULO XI

### Idéias inatas

 Por isso descobrimos que adquirir tais noções – cujas imagens não atingimos por meio dos sentidos mas que percebemos em nós, sem o auxílio de imagens, tais como são em si mesmas, nada mais é do que coligir com o pensamento os elementos esparsos na memória e, pela reflexão, obrigá-los a estarem sempre disponíveis à memória, onde antes se ocultavam em desordem e abandono, de modo que se apresentem sem dificuldade ao chamado do nosso espírito. E quantas noções deste tipo não encerra minha memória, já descobertas e, como disse, postas como que à mão; eis o que chamamos de "aprender" e "saber". Se porém deixo de as recordar por uns tempos, de tal modo submergem e se dispersam em seus profundos esconderijos, que é preciso reuni-las uma segunda vez, como se fossem novas (cogente) – pois não têm outra habitação – e juntá-las de novo para que possam ser objeto do saber; isto é: preciso tirá-las de sua condição de dispersão e juntá-las novamente. Daí a palavra cogitare, porque cogo e cogito são como ago e agito, e facio, facito. Contudo, a inteligência reivindicou essa palavra (cogito) para si, de modo que essa operação de coligir, de reunir no espírito, e não em outra parte, é propriamente o que se chama pensar (cogitare).

## CAPÍTULO XII

### A memória e as matemáticas

 A memória guarda também as relações e inumeráveis leis dos números e dimensões, sendo que nenhuma dessas idéias foi impressa em nós pelos sentidos do corpo, porque não têm cor, nem som, nem têm cheiro, nem gosto, nem são tangíveis. Ouço, quando elas se fala, os sons das palavras que as exprimem; mas uma coisa são os sons, e outra bem diferente são as idéias que elas significam. As palavras soam de modo diferente em grego e em latim; mas as idéias nem são gregas, nem latinas, nem de nenhuma outra língua.

 Vi linhas traçadas por artistas, finas como um fio de aranha. Mas as linhas materiais não são a imagem das que vi com meus olhos carnais. Para reconhecê-las não há necessidade alguma de se pensar em um corpo qualquer, pois, é no espírito que as reconhecemos.

 Também conheci os números mediante os sentidos do corpo: mas a idéia de número é bem diferente: não são imagens dos primeiros, possuindo por isso mesmo um ser muito mais real.

Ria-se de mim quem não compreender o que disse; eu terei compaixão de seu riso.

## CAPÍTULO XIII

### A memória da memória

 Tudo isso eu guardo em minha memória, assim como o modo pelo qual o aprendi. Também guardo na memória as muitas argumentações infundadas que ouvi contra essas verdades. Essas objeções sem dúvida são falsas, mas não é falso recordá-las. E lembro de ter sabido distinguir entre essas verdades e os erros que se lhe opunham. Vejo agora que uma coisa é essa distinção, que faço hoje, e outra o recordar ter feito muitas vezes tal distinção, ao considerá-las. Lembro-me, portanto, de ter muitas vezes compreendido isso, e confio à memória o ato atual de distingui-las e compreendê-las, para me lembrar, mais tarde, de que hoje as compreendi. Lembro-me então de que me lembrei; e se mais tarde lembrar de que agora pude recordar essas coisas, será ainda por força da memória.

## CAPÍTULO XIV

### A lembrança dos sentimentos

 Essa mesma memória conserva também os afetos da alma, não do modo como os sente a alma quando da vivencia, mas de modo muito diverso, segundo o exige a força da memória. Lembro-me de ter estado alegre, ainda que não o esteja agora; recordo minha tristeza passada, sem estar triste; lembro-me de ter sentido medo, sem senti-lo de novo; lembro-me de antigo desejo, sem que o mesmo sinta agora. Outras vezes, pelo contrário, lembro-me com alegria a tristeza passada, e com tristeza uma alegria passada. Isto nada tem para admirar quando se trata de emoções corporais, porque uma coisa é a alma e outra o corpo; e assim não é maravilha que me lembre com alegria de um sofrimento físico já passado.

 Porém, aqui o espírito é a própria memória. Quando confiamos uma tarefa a alguém, dizemos: "Não o guardei no espírito", "fugiu-me do espírito". É, portanto, a memória que chamamos de espírito. Sendo assim, por que ao evocar com alegria uma tristeza passada, meu espírito sente alegria e minha memória, tristeza? Se meu espírito se alegra com a alegria que tem em si, por que a memória não se entristece com a tristeza, que também tem em si? Seria a memória estranha ao espírito? Quem ousará afirmá-lo? Sem dúvida a memória é como o estômago da alma, e a alegria e a tristeza são como alimentos, doce ou amargo; quando tais emoções são confiadas à memória, depois de passarem, digamos, por esse estômago, podem ali serem guardadas, mas já perderam o sabor. Seria ridículo comparar emoções e alimento como semelhantes. Contudo, elas não são totalmente diferentes.

 É ainda da memória que tiro a distinção entre as quatro emoções da alma: o desejo, a alegria, o medo e a tristeza. Assim, todo raciocínio que eu teça, dividindo cada uma delas nas espécies de seus gêneros, definindo-as, é na memória que encontro o que tenho a dizer, e de lá tiro tudo o que digo. Contudo, ao recordar essas emoções, não me perturbo com nenhuma delas. E antes mesmo que eu as recordasse para discuti-las, elas ali estavam, e por isso puderam ser tiradas da memória mediante a lembrança. Talvez a lembrança tire da memória essas emoções como o ato de ruminar tira do estômago os alimentos. Mas então, por que aquele que rumina sobre tais paixões não sente na boca do pensamento a doçura da alegria ou a amargura da tristeza? Estará justamente nisto a diferença entre tais fatos? De fato, quem gostaria de falar dessas emoções se, todas as vezes que falássemos do medo ou da tristeza, nos víssemos tristes ou temerosos?

 Contudo, certamente não poderíamos falar deles se não encontrássemos na memória não só os sons dessas palavras, segundo a imagem gravada em nós pelos sentidos, mas ainda as noções que elas exprimem. Essas noções, nós não a recebemos por nenhuma porta da carne, mas a própria alma, sentindo-as pela experiência das próprias emoções, confiou-as à memória; ou então a própria memória as reteve, sem que ninguém lhas confiasse.

## CAPÍTULO XV

### A memória das coisas ausentes

Mas quem poderá explicar se a recordação se faz por meio de imagens ou não?

 Por exemplo: se digo pedra, ou digo sol, sem que tais objetos estejam presentes a meus sentidos, certamente tenho suas imagens na memória, à minha disposição.

 Evoco uma dor do corpo, que está ausente de mim, já que nada me dói. Contudo, se a imagem da dor não estivesse em minha memória, não saberia o que dizia, e ao raciocinar não a distinguiria do prazer.

 Falo de saúde do corpo, estando são; neste caso, está em mim o próprio objeto. No entanto, se sua imagem não estivesse em minha memória, de modo algum lembraria o significado dessa palavra. Os doentes, ouvindo falar de saúde, não saberiam do que se trata, não fosse o poder da memória a conservar a imagem da ausência da realidade.

 Falo dos números com que calculamos, e eles se apresentam na memória, não suas imagens, mas os próprios números.

 Evoco a imagem do sol, e esta se apresenta à minha memória; e não evoco a imagem de uma imagem, mas a própria imagem, disponível à recordação.

 Falo em memória, e reconheço o que falo, mas de onde o sei, senão da própria memória? Estará ela presente a si própria por sua imagem, e não por si mesma?

## CAPÍTULO XVI

### A memória do esquecimento

 E quando falo do esquecimento, e reconheço de que falo, como poderia eu reconhecê-lo se dele não lembrasse? Não falo do som da palavra, mas da realidade que ela exprime. Se eu a tivesse esquecido, não seria capaz de reconhecer o significado de tal som. Por isso, quando me lembro da memória é por ela mesmo que se apresenta a mim; mas quando me lembro do esquecimento, este e a memória estão presentes simultaneamente: a memória, com que me recordo, e o esquecimento, de que me recordo.

 Mas, que é o esquecimento, senão falta de memória? E como pode ele estar presente na minha lembrança. Se sua lembrança significa não lembrar? Mas se nos lembramos, o guardamos na memória, e se nos é impossível reconhecer o que significa a palavra esquecimento, quando a ouvimos, a não ser que dele nos lembremos, logo a memória é a que retém o esquecimento. Ele está na memória, pois do contrário, nós o esqueceríamos; mas, ele presente, nós nos esquecemos. Segue-se que ele não está presente à memória por si mesmo, quando nos lembramos dele, mas por sua imagem. Do contrário, o esquecimento não faria com que nos lembrássemos, mas com que nos esquecêssemos. Mas, enfim, quem poderá descobrir, quem poderá compreender o modo como isto se realiza?

 Mas, Senhor, esgota-me esta busca e é, portanto, sobre mim mesmo que me canso; tornei-me para mim mesmo uma terra de dificuldades e árduos labores. Por que não exploro agora as regiões do firmamento, nem meço as distâncias dos astros, nem busco as leis do equilíbrio da terra. Sou eu que me lembro, eu, o meu espírito. Não é de admirar que esteja longe de mim tudo o que não sou eu. Todavia, que há mais perto de mim do que eu mesmo? No entanto, é-me impossível compreender a natureza de minha memória, sem a qual eu nem poderia pronunciar meu próprio nome.

 Que direi então, desde que tenho a certeza que lembro do esquecimento? Diria talvez que não está em minha memória o que recordo? Ou talvez direi que o esquecimento está em minha memória, para que não o esqueça? Ambas hipóteses são grandes absurdos. Vejamos uma terceira hipótese: poderei eu afirmar que minha memória retém a imagem do esquecimento, e não o esquecimento em si, quando dele me lembro? Com que fundamento, pois, poderei dizê-lo, se para que se grave na memória a imagem de um objeto, é necessário que este esteja presente antes, de onde emana a imagem a ser gravada? É assim que lembro de Cartago, e assim de todos os outros lugares por que passei; assim me lembro do rosto dos homens que vi e das coisas que meus sentidos me deram a conhecer; assim me lembro ainda da dor física, coisas cujas imagens a memória fixou quando estavam presentes, para que eu as pudesse contemplar e repassar em espírito, quando eu as evocasse na sua ausência.

 Se, pois, é a imagem do esquecimento que está na memória, e não ele mesmo, é evidente que nalgum momento esteve presente para que sua imagem fosse fixada. Mas, se estava presente, como podia gravar na memória sua imagem, se o esquecimento apaga com sua presença tudo o que lá está impresso? Contudo, seja qual for o mecanismo desse fenômeno, e por mais incompreensível e inexplicável que seja, estou certo de que me lembro do esquecimento, que apaga da memória, todas as nossas lembranças.

## CAPÍTULO XVII

### Deus e a memória

 Grande é o poder da memória! E ela tem algo de terrível, meu Deus, em sua complexidade infinita e profunda. E isto é o espírito, e isto sou eu mesmo. Que sou, pois meu Deus? Qual a minha natureza? Vida vária e multiforme, de amplidão imensa. Eis-me em minha memória, em seus campos, antros, inumeráveis cavernas, tudo isso infinitamente cheio de toda espécie de coisas, também inumeráveis. Umas gravadas em imagens, como os corpos; outras, estão sob a forma de não sei que noções e sinais, como os afetos da alma, que a memória conserva quando a alma já não os sente, embora tudo o que está na memória esteja também no espírito. Percorro em todas as direções este mundo interior, vou de um lado para outro, e nele me aprofundo o mais possível, sem encontrar-lhe os limites, tão grande é a vida que reside no homem mortal!

 Que hei de fazer, pois, meu Deus, minha verdadeira vida? Ultrapassarei também esta faculdade que se chama memória? Ultrapassá-la-ei para chegar a ti, doce luz? Que dizes? Subindo em espírito a ti, que estás acima de mim, ultrapassarei também esta minha força, que se chama memória, pois quero atingir-te onde és acessível, e unir-me a ti por onde possa fazê-lo. Também os animais e as aves têm memória, porque de outro modo não voltariam a seus ninhos e tocas, nem fariam outras coisas habituais, e nem mesmo poderiam adquiri hábitos sem a memória. Passarei, pois, além da memória para chegar àquele que me separou dos animais e me fez mais sábio que as aves do céu. Passarei além da memória, mas onde te hei de achar, ó Deus verdadeiramente bom, suavidade segura? Onde te hei de encontrar? Se te encontro sem minha memória, estou esquecido de ti, e se não me lembro de ti, como te poderei encontrar?

## CAPÍTULO XVIII

### A memória das coisas perdidas

 Uma mulher perdeu uma dracma, e a procurou com sua lanterna. Mas se não se lembrasse dela, não a haveria de encontrar; de fato, se dela não lembrasse, como poderia saber, ao acha-la, que era aquela?

 Lembro-me de ter procurado e achado muitas coisas perdidas, sei disso porque, estando eu à procura, me diziam: "Por acaso é esta?" "Por acaso é aquela?" – e eu sempre respondia que não, até encontrar o que procurava. Se não tivesse fixado a lembrança do objeto, fosse o que fosse, ainda que me fosse mostrado, não o encontraria, pois não o poderia reconhecer. E sempre que perdemos e achamos alguma coisa acontece o mesmo.

 Se alguma coisa desaparece de nossa vista, e não da memória – como sucede com um corpo visível – conservamos interiormente sua imagem e o procuramos até que apareça a nossos olhos. Quando for encontrado, será reconhecido de acordo com essa imagem interior. Não podemos dizer que encontramos um objeto perdido se não o reconhecemos; nem o podemos reconhecer se dele não lembramos. Tinha pois desaparecido da nossa vista, mas era conservado pela memória.

## CAPÍTULO XIX

### A memória das lembranças

 E quando a própria memória perde uma lembrança, como acontece quando nos esquecemos de algo e procuramos recordá-la, o que se passa? Onde, afinal, a procuramos senão na própria memória? E se esta, por acaso, nos oferece uma coisa por outra, a repelimos até que apareça o que buscamos. E assim que aparece dizemos: "É isto". E assim não diríamos se não a reconhecêssemos, e não a reconheceríamos se dela não houvesse registro. É certo, portanto, que já a havíamos esquecido. Ou será que ela não se apagara totalmente de nossa memória, por meio da parte que nos ficou impressa procuramos a outra? A memória, nesse caso, teria ciência de não poder, como de ordinário, fornecer a lembrança em seu conjunto e, mutilada, reclamaria e parte faltante. É o que sucede quando vemos uma pessoa conhecida, ou nela pensamos sem poder recordar seu nome. Se outro nome nos apresenta ao espírito, não o associamos à tal pessoa; por isso o afastamos, até que se apresenta um que concorde com nossa representação habitual da pessoa.

 Mas donde nos vem este nome, senão da memória? Mesmo quando nos é sugerido por outrem, é pela memória que reconhecemos; não o aceitamos como um conhecimento novo, mas recordando-o, confirmamos ser esse o nome que nos disseram. Se fosse totalmente apagado da alma, nem mesmo avisados o reconheceríamos.

 Não podemos pois, afirmar que nos esquecemos completamente daquilo de que nos lembramos ter esquecido. De nenhum modo poderíamos resgatar uma lembrança perdida se seu esquecimento fosse total.

## CAPÍTULO XX

### A memória da felicidade

 E como hei de te buscar, Senhor? Quando te procuro, meu Deus, estou à procura da felicidade. Procurar-te-ei para que minha alma viva, porque meu corpo vive de minha alma, e minha alma vive de ti. Como então devo buscar a felicidade? Porque não a possuirei até que possa dizer "basta". Como, pois, procurá-la? Talvez pela lembrança, como se a tivesse esquecido, guardando contudo a lembrança do esquecimento? Ou pelo desejo de conhecer algo desconhecido ou por nunca tê-lo vivido, ou por tê-lo esquecido a ponto de nem ter consciência do seu esquecimento?

 Mas não será justamente a felicidade que todos querem, sem exceção? E onde a conheceram para a desejarem tanto? Onde a viram para assim a amarem? O que é certo é que está em nós a sua imagem. Mas não sei como isto se dá. E há diversos modos de ser feliz: quer possuindo realmente a felicidade, quer possuindo apenas sua esperança. Este último modo é inferior ao dos que são realmente felizes, embora estejam melhor que os não felizes nem na realidade, nem na esperança. Mesmo estes, todavia, não desejariam tanto a felicidade se esta lhes fosse completamente estranha, e é certo que a desejam. Não sei como a conheceram, e portanto ignoro a noção que dela têm. O que me preocupa é saber se essa noção reside na memória, pois, se é lá que reside, é sinal de já fomos felizes alguma vez. Por ora não busco saber se todos fomos felizes individualmente, ou se o fomos naquele que pecou primeiro, e no qual todos morremos, e de quem nascemos na infelicidade. O que procuro saber é se a felicidade reside na memória, porque certamente não a amaríamos se não a conhecêssemos. Mal ouvimos esta palavra, e todos confessamos que desejamos a mesma coisa; e não é o som da palavra que nos deleita. Quando um grego a ouve pronunciar em latim, não se alegra, porque ignora seu sentido. Mas nós nos alegramos ao ouvi-la, como ele se a ouvisse em sua língua. A felicidade, com efeito, não é grega nem latina; mas gregos e latinos, assim como todos que falam outras línguas, desejam alcançá-la.

 Logo, a felicidade é conhecida de todos; e se fosse possível perguntar-lhes a uma voz:" Quereis ser felizes?" – todos, sem hesitar, responderiam que sim. E isso não aconteceria se a memória não tivesse em si a realidade, expressa por essa palavra.

## CAPÍTULO XXI

### A memória do que nunca tivemos

 Podemos comparar essa lembrança à que conserva de Cartago, quem a viu? Não, a felicidade não se vê com os olhos, pois não é corporal. Seria pois comparável à lembrança dos números? Também não, pois quem conhece os números não deseja adquiri-los. Pelo contrário, a idéia da felicidade nos inclina a amá-la e a querer possuí-la, para sermos felizes.

 Lembramos dela, talvez, como lembramos da eloqüência? Também não, embora ao ouvir essa palavra, muitos que não são eloqüentes a associam à realidade que ela exprime, e desejariam obtê-la, o que indica que já têm idéia de eloqüência. Foi porém pelos sentidos do corpo que ouviram a eloqüência alheia, deleitando-se com ela, e desejando também ser eloqüentes. E certamente não lhes daria prazer se já não tivessem uma idéia da eloqüência, e nem a desejariam se esta não os tivesse deleitado. Mas a felicidade não a percebemos nos outros por nenhum sentido corporal.

 Essa lembrança, será porventura comparável à da alegria? Talvez, pois quando estou triste me lembro da alegria passada, e quando infeliz, lembro-me da felicidade. Ora, esta alegria, eu jamais a vi, ou ouvi, ou senti, ou saboreei, ou toquei; apenas a experimentei em minha alma quando me alegrei. E esta idéia se fixou em minha memória para que eu pudesse recordá-la, às vezes com desgosto, outras com saudades, conforme as circunstâncias que a geraram.

 De fato me senti invadido de alegria causada por ações torpes, cuja lembrança agora aborreço e abomino; outras vezes alegrei-me por ações boas e honestas, das quais me lembro com saudade; mas já pertencem ao passado, e evoco com tristeza minha antiga alegria.

 Mas onde e quando, então, experimentei a felicidade para lembrar-me dela, para amá-la e deseja-la? Não sou eu apenas, ou alguns que a desejam; mas todos, sem exceção queremos ser felizes. Sem uma noção precisa da felicidade, nossa vontade não teria essa firmeza.

 Que significa isto? Se perguntarmos a dois homens se querem alistar-se no exército, talvez um responda que sim o outro que não. Mas, perguntemos se desejam ser felizes, e ambos responderão que sim, sem nenhuma hesitação. E desejando um engajar-se, e o outro não, têm ambos a mesma finalidade: ser felizes. Um gosta disto, outro daquilo, mas ambos concordam em ser felizes, como seria unânime a resposta afirmativa a quem lhes perguntasse se querem estar alegres. Essa alegria é o que eles chamam de felicidade. E ainda que um siga por um caminho e outro por outro, a finalidade de todos é um só: a alegria. Como a alegria é um sentimento do qual todos temos experiência, a encontramos em nossa memória, e a reconhecemos ao ouvir pronunciar a palavra felicidade.

## CAPÍTULO XXII

### A verdadeira felicidade

 Longe de mim, longe do coração de teu servo, Senhor, que a ti se confessa, a idéia de encontrar a felicidade não importa em que alegria! A felicidade é uma alegria que não é concedida aos ímpios, mas àqueles que te servem por puro amor: tu és essa alegria! Alegrar-se de ti, em ti e por ti: isso é felicidade. E não há outra. Os que imaginam outra felicidade, apegam-se a uma alegria que não é a verdadeira. Contudo, sempre há uma imagem da alegria da qual sua vontade não se afasta.

## CAPÍTULO XXIII

### Felicidade e verdade

 Poderemos então concluir que nem todos desejam ser felizes, pois há aqueles que não querem buscar em ti sua alegria, tu que és a única felicidade? Ou talvez todos a queiram, mas, como a carne combate contra o espírito, e o espírito contra a carne, e com isso se contentam. Porque não querem com força bastante aquilo que não podem, para obtê-lo.

 Pergunto a todos se preferem encontrar a alegria na verdade ou no erro; ninguém hesita em declarar que preferem a verdade, como em dizer que querem ser felizes. É que a felicidade é a alegria que provém da verdade. E essa alegria é a que nasce de ti, que és a própria Verdade, ó meu Deus, minha luz, saúde de meu rosto! Todos querem essa vida, a única feliz, essa alegria que se origina na verdade.

 Encontrei muitos que gostam de enganar, mas ninguém que quisesse ser enganado. Onde, então, conheceram a felicidade, senão onde conheceram a verdade? Visto que não querem ser enganados, também amam a verdade, e desde que amam a felicidade, que nada mais é que a alegria proveniente da verdade, certamente também amam a verdade; e não a amariam se não retivessem dela, na sua memória, alguma noção. Por que, então, não se alegram com ela? Por que não são felizes? Porque se empolgam demais com outras coisas, que os tornam mais infelizes do que a verdade, de que se recordam fracamente, e que os faria felizes.

 Há ainda um pouco de luz entre os homens: caminhem, caminhem, para que as trevas não os surpreendam.

 Mas por que a verdade gera o ódio? Por que os homens olham como inimigo aquele que a prega em teu nome, uma vez que amam a felicidade, que mais não é que a alegria nascida da verdade? Talvez por amarem a verdade de tal modo que tudo de diferente que amam, querem que seja verdade; e, não admitindo ser enganados, também não querem ser convencidos de seu erro. Desse modo, detestam a verdade por amarem aquilo que tomam pela verdade. Amam-na quando ela brilha, mas odeiam-na quando os repreende; e, como não querem ser enganados, mas enganar, eles a amam quando ela se manifesta, mas a odeiam quando ela os denuncia. Porém ela os castiga; não querem ser descobertos pela verdade, mas esta os denuncia, sem que por isso se manifeste a eles.

 É assim o coração do homem! Cego e lerdo, torpe e indecente: quer permanecer oculto, mas não quer que nada lhe seja ocultado. Em castigo, sucede-lhe o contrário: não consegue esconder-se da verdade, enquanto esta lhe continua oculta. Contudo, apesar de tão infeliz, prefere encontrar alegrias na verdade que no erro. Será, portanto, feliz quando, livre de perturbações, se alegrar somente na Verdade, origem de tudo o que é verdadeiro.

## CAPÍTULO XXIV

### Deus e a memória

 Eis como esquadrinhei minha memória em tua procura, Senhor: não me foi possível encontrar-te fora dela. Nada encontrei de ti que não fosse lembrança, e nunca me esqueci de ti desde que te conheci. Onde encontrei a verdade, aí encontrei a meu Deus, que é a própria verdade; e desde que aprendi a conhecer a verdade, nunca mais a esqueci. Por isso, desde que te conheço, permaneces em minha memória. É lá que te encontro quando me lembro de ti e quando sou feliz em ti. Estas são as santas delicias que me deste em tua misericórdia, olhando para minha pobreza.

## CAPÍTULO XXV

### Recapitulação

 Onde habitas em minha memória, Senhor, em que lugar dela estás? Que esconderijo construíste aí? Que santuário aí edificaste para ti? Deste-me a honra de morar em minha memória; mas em que parte dela resides? É o que quero agora descobrir.

 Quando me recordei de ti, ultrapassei aquela região da memória que também os animais possuem, pois não te encontrei entre as imagens dos objetos corpóreos. E cheguei àquela parte onde depositei os afetos de minha alma, mas também aí não te encontrei. Cheguei à morada que meu próprio espírito possui na memória – porque também o espírito lembra de si mesmo – mas nem ali estavas. Isso porque não és imagem corpórea, nem afeto de ser vivo, como a alegria, a tristeza, o desejo, o temor, a lembrança, o esquecimento e outros semelhantes, e nem és meu próprio espírito, porque és o Senhor e Deus do espírito, e tudo isso é mutável, enquanto permaneces imutável e subsistes acima de todas as coisas, e te dignaste habitar em minha memória desde que te conheço.

 Mas, por que perguntar em que lugar da memória habitas, como se a memória tivesse compartimentos? Certo é que habitas nela desde que te conheço, e é nela que te encontro, quando penso em ti.

## CAPÍTULO XXVI

### Onde encontrar Deus?

 Onde, então, te encontrei, para te conhecer? Não estavas ainda em minha memória antes de eu te conhecer. Onde, então, te encontrei, para te conhecer, senão em ti mesmo, acima de mim? No entanto, aí não existe espaço. Quer nos afastemos de ti, quer nos aproximemos, aí não existe espaço algum. Ó Verdade, por toda parte assistes aos que te consultam, e respondes ao mesmo tempo a todas essas diversas consultas. Tuas respostas são claras, mas nem para todos. Os homens te consultam sobre o que querem, mas nem sempre ouvem as respostas que querem. Teu servo fiel é o que não pensa em ouvir de ti a resposta que quer, mas em querer a resposta que lhe dás.

## CAPÍTULO XXVII

### Solilóquio de amor

 Tarde te amei, Beleza tão antiga e tão nova, tarde te amei! Eis que estavas dentro de mim, e eu lá fora, a te procurar! Eu, disforme, me atirava à beleza das formas que criaste. Estavas comigo, e eu não estava em ti. Retinham-me longe de ti aquilo que nem existiria se não existisse em ti. Tu me chamaste, gritaste por mim, e venceste minha surdez. Brilhaste, e teu esplendor afugentou minha cegueira. Exalaste teu perfume, respirei-o, e suspiro por ti. Eu te saboreei, e agora tenho fome e sede de ti. Tocaste-me, e o desejo de tua paz me inflama.

## CAPÍTULO XXVIII

### A vida do homem

 Quando me unir a ti com todo meu ser, não sentirei mais dor ou fadiga; minha vida, cheia de ti, será então a verdadeira vida. Alivias aqueles que enches de ti; mas, como ainda não estou cheio de ti, sou um peso para mim mesmo. Minhas alegrias, que deveriam ser choradas, lutam com minhas tristezas que deveriam alegrar-me, e ignoro de que lado está a vitória.

 Ai de mim, Senhor, tem piedade de mim! As tristezas do meu mal lutam com minhas santas alegrias, e eu não sei de que lado está a vitória. Ai de mim! Senhor, tem piedade de mim! Eis minhas feridas: eu não as escondo. Tu és o médico, eu o enfermo; és misericordioso, e eu, miserável. Não é contínua tentação a vida do homem sobre a terra? Quem quer aborrecimentos e dificuldades? Mandas que os suportemos, e não que os amemos. Ninguém ama o que tolera, ainda que goste de o tolerar; e mesmo que alguém se alegre em tolerar, preferiria nada ter que suportar. Na adversidade, desejo a prosperidade, e na prosperidade temo a adversidade. Entre estes dois extremos, qual será o termo médio onde a vida humana não seja tentação?

 Ai das prosperidades do século, onde se receia a adversidade e a alegria é corrompida! Ai das adversidades do século, uma, duas, três vezes ai! Pelo desejo da prosperidade, por ser dura a adversidade, e pelo temor que vença a nossa paciência! A vida do homem sobre a terra não é pois uma contínua tentação?

## CAPÍTULO XXIX

### Esperança em Deus

 Só na grandeza da Tua misericórdia coloco toda minha esperança. Dai-me o que me ordenas e ordena-me o que quiserdes. Mandas que sejamos castos. "Sabendo, diz um sábio, que ninguém pode ser casto se Deus não lhe der este dom, já é sabedoria saber de quem procede este dom". A continência reúne os elementos de nossa pessoa, reconduz-nos à unidade que perdemos dispersando-nos por tantas criaturas. Pouco te ama quem te ama juntamente com alguma criatura, e não a ama por tua causa.

 Ó amor, que sempre ardes e jamais te extingues! Ó caridade, meu Deus, inflama-me! Ordena-me a continência? Dá-me o que mandas, e ordena o que quiseres!

## CAPÍTULO XXX

### Sonho e voluptuosidade

 Ordenas que me abstenha da concupiscência da carne, da concupiscência dos olhos e da ambição do século. Proibiste as uniões luxuriosas, e embora tenhas permitido o casamento, ensinaste que há um estado bem melhor. E, pela tua graça, optei por esse estado, antes mesmo de me tornar dispensador de teu sacramento.

 Mas em minha memória, de que falei longamente, vivem ainda as imagens dessas voluptuosidades que meus costumes de outrora ali gravaram. Sem forças diante de mim quando estou acordado, durante o sono, elas não somente suscitam em mim o prazer, mas o consentimento do prazer e a ilusão da ação. Tais ilusões têm tal poder sobre minha alma e sobre meu corpo, apesar de tão falsas, que seus fantasmas impelem a meu sono o que a realidade não me pode induzir quando em vigília. Acaso então, Senhor meu Deus, será que eu não sou eu nessas horas? E como vai tão grande diferença dentro de mim mesmo, do momento em que passo da vigília para o sono e vice versa! Onde pois está a razão, que durante a vigília resiste a tais sugestões, e que não se abala mesmo diante da realidade? Acaso se fecha juntamente com os olhos? Ou adormece com os sentidos do corpo?

 E por que, muitas vezes, mesmo no sono, resistimos, lembrados de nosso propósito, e nele permanecemos castos, negando o consentimento a tais seduções? Todavia, a diferença é tanta que, no caso de não resistir durante o sono, ao acordar voltamos a encontrar a paz de consciência; e a própria diferença entre os dois estados indica que não fomos nós que fizemos aquilo, e lamentamos o que se fez em nós.

 Senhor onipotente, não poderia tua mão curar todas as enfermidades de minha alma, abolindo também, com maior abundância de graça, os movimentos lascivos de meu sono? cada vez mais multiplica, Senhor, o número de tuas bondades para comigo, para que minha alma, livre do visco da concupiscência, siga até chegar a ti. Para que não seja rebelde, nem mesmo durante o sono; para que, pelo estímulo de imagens bestiais, não só não cometa essas torpezas degradantes até a lascívia carnal, mas que nem mesmo consinta nisso.

 Não é muito para ti, ó Todo-Poderoso, que podes fazer mais do que pedimos e compreendemos, fazer com que, quer minha idade presente, quer na minha vida futura, eu me deleite nessas tentações – mesmo que sejam tão pequenas, que o primeiro esforço as venceria, quando adormeço com pensamentos castos.

 Agora digo exultando ao meu Senhor em que estado me encontro neste gênero de pecado, com tremor pelos dons que já me concedeste, e gemendo pelas minhas imperfeições. Espero que aperfeiçoes em mim tuas misericórdias, até que atinja a plenitude da paz de que gozarão em ti meu espírito e meu corpo, quando a morte for absorvida pela vitória.

## CAPÍTULO XXXI

### A intemperança

 O dia me traz novo pecado, e oxalá fosse o único! Comendo e bebendo, restauramos as diuturnas perdas de nosso corpo, até o dia em que destruirás o alimento e o estômago, matando minha necessidade com uma maravilhosa saciedade, e revestindo este corpo corruptível de eterna incorruptibilidade.

 Mas por ora esta necessidade me é grata, e luto contra essa delícia, para que não me domine; é uma guerra cotidiana que sustento com jejum, reduzindo meu corpo à escravidão. Mas minhas dores são eliminadas pelo prazer, porque a fome e a sede são sofrimentos: queimam e matam como a febre se os alimentos não lhe põem remédio. Mas como esse remédio está sempre à nossa disposição, graças à liberdade de teus dons que põe à disposição de nossa fraqueza a terra, a água e o céu, nossas misérias recebem por nós o nome de delícias.

 Tu me ensinaste a considerar os alimentos como remédios. Mas quando passo dessa penosa necessidade à paz da saciedade, nessa passagem a concupiscência arma para mim sua cilada. Esta passagem é prazerosa, e não há outra para se chegar onde a necessidade nos obriga. A razão do beber e do comer é a conservação da saúde; mas um prazer insidioso acompanha como lacaio essas funções, e sempre tenta tomar a dianteira, de modo que faço pelo prazer o que digo fazer por minha saúde.

 Ora, a medida do prazer não é a mesma da saúde; o que é bastante para a saúde não o é para o prazer, e muitas vezes é difícil discernir se é o cuidado com o corpo que pede reforço de alimento, ou se é a gula que nos engana e quer ser servida. Essa incerteza alegra nossa pobre alma, feliz por ter encontrado um álibi e uma desculpa na impossibilidade de determinar o que basta para o cuidado com a saúde, e sob o pretexto da sua conservação esconde a busca do prazer. Esforço-me para resistir a essas tentações diárias, e invoco tua mão para me socorrer. A ti confesso minha incerteza, porque sobre este ponto meu juízo ainda não é firme.

 Ouço a voz de meu Deus que ordena: "Não se façam pesados vossos corações com a intemperança e embriaguez". A embriaguez está longe de mim; que tua misericórdia não a deixe se aproximar. Mas a intemperança, ao contrário, chega às vezes a arrastar teu servo. Tua misericórdia há de afastá-la de mim, porque ninguém pode ser temperante senão por tua graça.

 Muitas coisas nos concedes quando te invocamos, e todo o bem que recebemos, mesmo antes de o pedir, é a ti que sempre o devemos. E o ato mesmo de reconhecermos que esses dons são teus, é ainda graça tua. Nunca estive embriagado, mas conheci muitos, dados a esse vicio, que se tornaram sóbrios por tua graça. Assim, é graças a ti que alguns não são o que nunca foram; e também é graças a ti que outros não são mais o que foram; e é graças a ti, enfim, que estes e aqueles sabem a quem devem essa graça.

 Ouvi ainda de ti outra palavra: "Não corras atrás de tuas concupiscências, e reprime teus apetites" – Tua graça ainda me fez ouvir outra palavra, de que tanto gostei: "Se comemos, não teremos abundância; e se não comemos, não sofreremos privação". – Ou seja: nem isto me fará rico, nem aquilo pobre. – E ouvi ainda esta outra: "Aprendi a me contentar com o que tenho: sei viver na abundância e suportar a penúria. Tudo posso naquele que me fortalece". – Eis como fala o bom soldado da milícia celeste: nada parecido ao pó que somos. Mas, Senhor, lembra-se que somos pó, e que de pó fizeste o homem; que este havia se perdido, e que foi reencontrado.

 Por si mesmo, formado do mesmo pó que nós, nada podia aquele cujas palavras inspiradas tanto amei: "Tudo posso naquele que me fortalece" – Concede-me forças, para que eu possa. Dá-me o que mandas, e manda o que quiseres. Paulo confessa que tudo recebeu de ti, e, quando se gloria, é no Senhor que ele se gloria.

 Ouvi também outro que te pedia esta graça: "Afasta de mim a intemperança". – De onde se conclui claramente, ó Deus santo, que dás a força de cumprir o que mandas.

 "Tu me ensinaste, Pai bondoso, que tudo é puro para os puros, mas que é mau para o homem comer com escândalo, que tudo o que fizeste é bom, e que nada deve ser rejeitado do que se recebe com ação de graças; que os alimentos não nos recomendam a Deus, que ninguém nos deve julgar pela comida ou pela bebida; que o que come não deve julgar o que não come". – Por essas lições, graças e louvores te dou, meu Deus, meu Mestre, que bateste à porta de meus ouvidos e iluminaste meu coração. Livra-me de toda tentação. Não receio a impureza dos alimentos, mas a impureza do prazer.

 Sei que Noé teve permissão de comer toda espécie de carne que pudesse servir de alimento, e que Elias comeu carne para reparar as forças; sei que João Batista, asceta admirável, não se manchou com os animais – os gafanhotos – de que se alimentava. Todavia eu sei que Esaú deixou-se enganar pelo desejo de um prato de lentilhas; que Davi se repreendeu a si mesmo por ter desejado água; que nosso Rei foi submetido à tentação, não de carne, mas de pão. Por isso o povo foi justamente repreendido no deserto, não por ter desejado comer carne, mas porque o desejo o fez murmurar contra o Senhor.

 Exposto a estas limitações, luto diuturnamente contra a concupiscência do comer e do beber, pois não é coisa que possa cortar de uma vez por todas, apenas com o propósito de nunca mais recair, como fiz com a luxúria. É uma rédea imposta a meu paladar, ora para afrouxá-la, ora para retesá-la. E quem é, Senhor, que não se deixa arrastar às vezes além dos limites do necessário? Se existe alguém assim, é de fato grande, e deve engrandecer teu nome. eu porém não sou desse número, porque sou pecador. Contudo, também, eu engrandeço teu nome, e Aquele que venceu o mundo intercede junto a ti por meus pecados. Conta-me entre os membros enfermos de seu corpo, porque teus olhos viram minhas imperfeições e porque todos serão inscritos em teu livro.

## CAPÍTULO XXXII

### Os prazeres do olfato

 Quanto à sedução dos perfumes, não me preocupo demais. Quando ausentes, não os procuro; quando presentes, não os recuso, mas estou sempre disposto a deles me abster. Pelo menos assim me parece, embora talvez me engane. Trevas deploráveis me envolvem, que me escondem minhas faculdades reais; por isso, quando meu espírito indaga à respeito de suas forças, bem sabe que não pode confiar em si mesmo, por seu íntimo permanecer muitas vezes insondável, até que a experiência lho manifeste. Ninguém pois se deve ter seguro nesta vida, que é tentação perpétua. Pois. Como podemos nos tornar melhores, não aconteça de nos tornar piores. Nossa única esperança, nossa única confiança, nossa firme promessa é tua misericórdia.

## CAPÍTULO XXXIII

### Os prazeres do ouvido

 Os prazeres do ouvido me prendem e me subjugam com mais força, mas tu me desligaste, me libertaste.

 Agradam-me ainda, eu o confesso, os cânticos que tuas palavras vivificam, quando executados por voz suave e artística; todavia eles não me prendem, e dele posso me desvencilhar quando quero. Para assentarem no meu íntimo, em companhia com os pensamentos que lhe dão vida, buscam em meu coração um lugar de dignidade, mas eu me esforço ou me ofereço para ceder-lhes só o lugar conveniente.

 Às vezes parece-me tributar-lhe mais atenção do que devia: sinto que tuas palavras santas, acompanhadas do canto, me inflamam de piedade mais devota e mais ardente do que se fossem cantadas de outro modo. Sinto que as emoções da alma encontram na voz e no canto, conforme suas peculiaridades, seu modo de expressão próprio, um misterioso estímulo de afinidade.

 Mas o prazer dos sentidos, que não deveria seduzir o espírito, muitas vezes me engana. Os sentidos não se limitam a seguir, humildemente, a razão; o mesmo tendo sido admitidos graças à ela, buscam precedê-la e conduzi-la. É nisso que peco sem o sentir, embora depois o perceba.

 Outras vezes, porém, querendo exageradamente evitar este engano, peco por excessiva severidade; chego ao ponto de querer afastar de meus ouvidos, e da própria Igreja, a melodia dos suaves cânticos que habitualmente acompanham os salmos de Davi. Nessas ocasiões parece-me que o mais seguro seria adotar o costume de Atanásio, bispo de Alexandria. Segundo me relataram, ele os mandava recitar com tão fraca inflexão de voz, que era mais uma declamação do que um canto.

 Contudo, quando lembro das lágrimas que derramei ao ouvir os cantos de tua Igreja, nos primórdios de minha conversão, e que ainda agora me comovem, não tanto com o canto, mas com as letras cantadas, voz clara e modulações apropriadas, reconheço novamente a grande utilidade desse costume.

 Assim, oscilo entre o perigo do prazer e a constatação dos efeitos salutares do canto. Por isso, sem emitir juízo definitivo, inclino-me a aprovar o costume de cantar na igreja, para que, pelo prazer do ouvido, a alma ainda muito fraca, se eleve aos sentimentos de piedade. E quando me comovem mais os cantos do que as palavras cantadas, confesso meu pecado e mereço penitencia, e então preferiria não ouvir cantar.

 Eis em que estado me encontro! Chorai comigo, e chorai por mim, vós que alimentais no coração a virtude, fonte de boas obras. Porque vós, a quem isso não afeta, sois insensíveis a tudo isso. E tu, Senhor meu Deus, escuta, olha e vê; tem piedade de mim, cura-me. Eis que me tornei um problema para mim mesmo, sob teu olhar, e aí está precisamente meu mal.

## CAPÍTULO XXXIV

### O prazer dos olhos

 Resta ainda falar do prazer destes olhos carnais. Oxalá que os ouvidos fraternos e piedosos de teu templo ouvissem a minha confissão! Encerrando assim as tentações da concupiscência que ainda me perseguem, apesar de meus gemidos e dos desejos de ser revestido de meu tabernáculo, que é o céu.

 Meus olhos apreciam as formas belas e variadas, as cores brilhantes e amenas. Oxalá elas não me acorrentassem a alma! Oxalá ela só fosse presa pelo Deus que criou coisas tão boas: ele é meu bem, e não elas. Todos os dias, estando acordado, elas me importunam sem o descanso das vozes que se calam, e às vezes de tudo o que existe, quando silencia. A própria rainha das cores, a luz que inunda tudo o que vemos, e onde quer que eu esteja durante o dia, acaricia-me de mil modos, mesmo quando estou ocupado em outra coisa e não lhe dou atenção. E ela se insinua tão fortemente que, se de repente me for tirada, a desejo, a procuro e, se sua ausência se prolonga, a alma se entristece.

 Ó luz que Tobias contemplava quando, cego, mostrava ao filho o caminho da vida, caminhando à sua frente com os passos da caridade, sem jamais se perder! Luz que via Isaac, quando seus olhos carnais, oprimidos e velados pela velhice, mereceram não abençoar os filhos reconhecendo-os, mas reconhecê-los ao abençoá-los! Luz que via Jacó, também cego pela idade provecta, irradiou os fulgores de seu coração iluminado sobre as gerações do povo futuro, representadas em seus filhos! E a seus netos, os filhos de José, impôs as mãos misticamente cruzadas, não na ordem em que queria dispô-los o pai, que via com os olhos corporais, mas de acordo com seu próprio discernimento interior! Eis a verdadeira luz; ela é uma, e todos os que a vêem e amam formam um único ser.

 Quanto à luz corporal, de que falava, com sua doçura sedutora e perigosa, é um dos prazeres da vida para os cegos amantes do mundo. Mas os que nela sabem encontrar motivos para te louvar, Deus, criador de todas as coisas, convertem-na em hino em teu louvor, sem se deixarem dominar por ela no sono. é assim que desejo ser. Resisto às seduções dos olhos, para que meus pés, que começam a trilhar teus caminhos, não fiquem enredados. Elevo a ti olhos invisíveis, para que libertes meus pés de seus laços. Tu não cessa de livrá-los, porque sempre estão a se prender. Tu não cessas de me livrar, e eu me deixo cair a cada passo nas insídias espalhadas por toda parte, porque não dormirás, nem cochilarás, tu que guardas a Israel.

 Quantos encantos os homens acrescentaram às seduções dos olhos, com a variedade de suas artes, com sua indústria de vestidos, de calçados, de vasos, de objetos de toda espécie, com pinturas e esculturas diversas que de longe ultrapassam os limites do necessário e moderado e da expressão piedosa. Exteriormente perseguem as produções de suas artes, e em seu interior abandonam Àquele que os criou, deturpando em si o que ele fez.

 Quanto a mim, meu Deus e minha glória, encontro nisto razão para cantar-te um hino, e oferecer um sacrifício de louvor àquele que sacrificou por mim. As belezas que da alma do artista passam para suas mãos, provêm desta beleza, que é superior às nossas almas e pela qual minha alma suspira dia e noite.

 Entretanto, os que geram e os amantes das belezas exteriores, tiram da beleza soberana apenas o critério para julgá-las, mas não uma regra para usá-las bem. Contudo, a norma ali está, mas eles não a vêem. Se a vissem, não se afastariam , e guardariam sua força para ti, e não a dissipariam em fatigantes delícias.

 Mesmo eu, que exponho e compreendo essas verdades, deixo-me enredar nessas belezas; mas tu me livras de seu laço, tu me libertas, porque tua misericórdia está diante de meus olhos. Miseravelmente eu caio, e tu me levantas misericordiosamente, às vezes sem que eu o perceba, quando minha queda foi suave, e outras infligindo-me uma pena, por ter ficado preso ao chão.

## CAPÍTULO XXXV

### A curiosidade

 Às anteriores acrescente-se outra tentação, que oferece maiores perigos. Além da concupiscência da carne, que consiste no deleite voluptuoso de todos os sentidos, e cuja servidão dana os que ela afasta de ti, insinua-se na alma um outro desejo, que se exerce pelos mesmos sentidos corporais, mas tende menos a uma satisfação carnal do que a tudo conhecer por meio da carne.

 É a vã curiosidade, que se disfarça sob o nome de conhecimento e de ciência. Como nasce do apetite de tudo conhecer, e como entre os sentidos os olhos são os mais aptos para o conhecimento, a Sagrada Escritura chamou-a de concupiscência dos olhos.

 De fato, ver é função própria dos olhos; mas muitas vezes nós usamos essa expressão mesmo quando se trata de outros sentidos, aplicados ao conhecimento. Nós não dizemos: "Ouve como isto brilha" – nem: "Sente como isso resplandece" – nem: "Apalpa como isto cintila". – Para exprimir tudo isso dizemos "ver ou olhar". E até não nos limitamos a dizer: "Olha que luz!", pois apenas os olhos nos podem dar esta sensação – mas, dizemos ainda: "Olha que som! Olha que cheiro! Olha que gosto! Olha como é duro!" Por isso toda experiência que é obra dos sentidos é chamada, como disse, concupiscência dos olhos. Essa função da visão, que pertence aos olhos, é usurpada metaforicamente pelos outros sentidos, quando buscam conhecer alguma coisa.

 Daqui podemos distinguir claramente o papel da volúpia e o da curiosidade na ação dos sentidos. O prazer procura o que é belo, melodioso, suave, saboroso, agradável ao todo; a curiosidade por sua vez deseja o contrário, não para se expor ao sofrimento, mas pela paixão de conhecer por meio da experiência. Que prazer pode ter na visão de um cadáver dilacerado, que causa horror? E todavia onde há um cadáver, para lá corre toda a gente para se entristecer e empalidecer. E temem depois revê-lo em sonhos, como se alguém os tivesse obrigado a contemplá-lo, ou como se a fama de alguma beleza os tivesse atraído. O mesmo acontece com os outros sentidos, o que seria enfadonho enumerar.

 É esse quê de mórbido de curiosidade que faz com que se exibam monstruosidades nos espetáculos. É ela que nos induz a perscrutar os segredos da natureza exterior, cujo conhecimento de nada serve, mas que os homens buscam conhecer apenas pelo prazer de conhecer. É ela também que inspira o homem a pesquisar, com fim semelhante, a ciência perversa, que é a arte da magia.

 E é ela, enfim, que, até na religião, nos induz a tentar a Deus, pedindo-lhe sinais e prodígios, não para a salvação da alma, mas apenas pela ânsia de vê-los.

 Nessa imensa floresta, cheia de insídias e perigos, cortei e lancei para fora de meu coração muitos males, graças à força que me concedeste para tanto, Deus de minha salvação. Contudo, no turbilhão diário de tantas e tão variadas tentações que atormentam minha vida, quando ousarei dizer que nenhuma delas atrai mais minha atenção e não cativa minha vã curiosidade? Certamente que o teatro já não me atrai, nem me importo mais em conhecer o curso dos astros; jamais, para obter uma resposta, consultei as sombras, pois detesto todos os ritos sacrílegos.

 Mas quantos artifícios inventa o inimigo para me tentar a que te peça algum milagre, a ti, Senhor, meu Deus, a quem devo servir humilde e simplesmente! Eu te suplico, por nosso Rei, por nossa pátria, a pura e casta Jerusalém, que o perigo de consentir nessas coisas, que até agora esteve longe de mim, se afaste cada vez mais! Mas quando te peço a salvação de uma alma, a finalidade de meu intento é bem diferente: ouve-me pois, e concede-me a graça de seguir de bom grado tua vontade.

 Mas incontáveis são as pequenas e desprezíveis bagatelas que tentam cada dia nossa curiosidade! E quem poderá contar nossas quedas? Quantas vezes ouvimos contar banalidades! Toleramo-las, de início, para não magoar os fracos, e depois, aos poucos, ouvimo-las com atenção sempre crescente!

 Não vou mais ao circo, para ver um cão correr atrás de uma lebre; mas, passando casualmente pelo campo e vendo algo assim, eis-me interessado pela caçada, talvez até distraindo-me de algum pensamento profundo. E, se não chega a me fazer mudar o caminho do meu cavalo, desvio o curso do meu coração. Se após tal demonstração de minha fraqueza tu não me alertares para que abandone esse espetáculo, elevando-me a ti por meio de alguma reflexão, ou desprezando tudo e passando adiante, ficaria ali, absorvido como um bobo.

 E que dizer quando, sentado em minha casa, observando uma lagartixa à caça de moscas, ou uma aranha que as enreda em sua teia? Acaso, por serem animais pequenos, a curiosidade que despertam em mim não é a mesma? É verdade que depois passo a te louvar; Criador admirável, ordenador do universo, mas não foi esse o pensamento que primeiro me moveu. Uma coisa é levantar-se depressa, e outra é não cair.

 Dessas quedas está repleta minha vida, e minha única esperança está em tua infinita misericórdia. Nosso coração é o receptáculo de tais misérias, e traz em si grande quantidade de vaidades, que muitas vezes até interrompem e perturbam nossas orações; e enquanto em tua presença levantamos a voz de nossa alma até teus ouvidos, tais pensamentos fúteis, vindos não sei de onde, vêm perturbar um ato tão importante.

## CAPÍTULO XXXVI

### O orgulho

 Terei também essa miséria como desprezível? Haverá algo que possa restituir-me a esperança, a não ser tua conhecida misericórdia, que começou a me transformar? Sabes o quanto já me transformaste; curaste-me primeiro da paixão da vingança, para perdoar-me também todos meus pecados, curar minhas fraquezas, resgatar minha vida da corrupção, conservar-me na piedade e misericórdia, e saciar dos teus bens meu desejo. Derrubaste meu orgulho pelo temor, dobrando minha cerviz a teu jugo. Agora eu trago o teu jugo, e o sinto suave, como prometeste e cumpriste. Na verdade, teu jugo já era suave, mas eu não o sabia quando receava tomá-lo sobre mim.

 Mas, Senhor, tu és o único que sabe mandar sem orgulho, porque és o único Senhor verdadeiro, que não tem senhor! Diga-me, terá cessado em mim, se isso pode acontecer nesta vida, esta terceira espécie de tentação, que consiste em querer ser temido e amado pelos homens, com o único fim de obter uma alegria que não é alegria? Que vida miserável, que arrogância indigna! Aí está o principal motivo porque não te amamos e tememos piamente. Por isso resistes aos soberbos, enquanto dás tua graça aos humildes. Trovejas contra as ambições do mundo, e faz abalar as montanhas até suas raízes.

 Ora, como é necessário, para se adequar à sociedade, fazer-se amar e temer pelos homens, o inimigo de nossa verdadeira felicidade nos alicia, e por toda parte semeia seus laços gritando: "Bravo! Muito bem!" – para que, ávidos, recolhamos as lisonjas e nos deixemos incautamente enredar. Seu intento é que deixemos de encontrar nossa alegria na verdade, para buscá-la na mentira dos homens; estimula em nós o prazer em nos fazer temer e amar, não pelo teu amor, mas em teu lugar. Com isso nos tornamos semelhantes a ele, não unidos na caridade, mas partilhando de suas penas. Ele quis fixar sua morada no aquilão (vento gelado do norte), para que nós, nas trevas e no frio, servíssemos o perverso e sinuoso imitador de teu poder.

 Nós, Senhor, somos teu pequeno rebanho: sê nosso dono. Estende tuas asas, para nosso refúgio. Sê nossa glória; que nos amem por tua causa, e que tua palavra seja observada por nós. Quem busca o louvor dos homens, quando tu o reprovas, não será por estes defendido quando o julgares, nem poderá subtrair á tua condenação. Mas quando não se louva um pecados pelos desejos de sua alma, nem se abençoa quem pratica iniqüidades, mas te louva um homem pelos dons que lhe concedeste, se ele se compraz mais no louvor do que no dom que lhe atrai os louvores, tu o reprovas, a despeito dos louvores que recebe dos homens. E quem o louva é melhor do que é louvado, porque um se agradou com o dom de Deus, e o outro alegrou-se com o dom do homem.

## CAPÍTULO XXXVII

### A tentação do orgulho

 Todos os dias somos acometidos por estas tentações, Senhor, somos tentados sem trégua. Os louvores dos homens são a fornalha onde todos os dias somos postos à prova. Também nisso mandas que sejamos continentes. Concede-nos o que mandas, e manda o que quiseres.

 A esse respeito, conheces os lamentos que meu coração te dirige, e os rios de lágrimas que brotam de meus olhos. É-me difícil distinguir o quanto estou purificado dessa peste; tenho muito medo de minhas faltas ocultas, que teus olhos conhecem, e os meus ignoram. Nos outros gêneros de tentação, tenho recursos para me examinar, mas quanto a este, quase nenhum. Posso avaliar o quanto dominei a minha alma a respeito dos prazeres da carne e das vãs curiosidades, quando me vejo privado de tais coisas por minha vontade ou por necessidade. Então me indago se é pena maior ou menor o ver-me privado desses dons.

 Quanto à riqueza, ambicionada apenas para satisfazer a uma, duas ou todas as três paixões, no caso em que a alma não perceba se as despreza quando as possui, depende só dela renunciar a elas para provar seu desapego. Todavia, para nos privar dos louvores e provar nosso poder sobre eles, será talvez necessário levar uma vida má, infame, horrível, a ponto de ninguém nos conhecer sem nos detestar? Pode-se dizer ou conceber maior insanidade?

 Se o louvor deve habitualmente acompanhar uma vida boa e de boas obras, não será por isso que deveremos abandonar a vida exemplar. Contudo, para distinguir se a privação de um bem me é indiferente ou penosa, é preciso que me prive desse bem.

 Então, Senhor, que devo confessar-te quanto a tais tentações? Que tenho em grande apreço o louvor? Mas agrada-me mais a verdade. Pois, se tivesse que escolher entre duas situações: ser louvado pela minha loucura ou por meus erros ou ser escarnecido por todos pela minha firme certeza da verdade, bem sei o que escolheria. Contudo, não gostaria que a aprovação alheia aumentasse para mim a alegria que sinto pelo pouco bem que faço. Mas tenho de te confessar que não só o louvor a aumenta, mas também que o vitupério a diminui.

 Quando me sinto perturbado por essa miséria, uma desculpa surge em mim. Só tu sabes, Senhor, se ela é válida, porque a mim me deixa perplexo. De fato, não nos ordenaste apenas a continência, que nos ensina a afastar certas coisas de nós, mas também a justiça, que direciona nosso amor. Não quiseste que amássemos somente a ti, mas também o nosso próximo. Ora, às vezes me parece que é o aproveitamento e as esperanças de que o próximo dá mostra que me encantam, quando me regozijo com um elogio inteligente; e que, pelo contrário, é sua maldade que me entristece quando o ouço censurar o que ignora ou o que é bom.

 Às vezes também me entristeço com os elogios que me fazem, quando louvam em mim qualidades que me desagradam, ou quando dão muita importância a qualidade medíocres e secundárias.

 Mas, repito-o, como saber se o desagrado não provém de minha repugnância pelo louvor que destoa do meu juízo a respeito de mim mesmo – não que seu interesse me preocupe – mas pelo maior agrado que sinto quando o bem que amo em mim é amado pelos outros? De algum modo, não me considero louvado quando o elogio contradiz a opinião que tenho de mim mesmo, quer o encômio seja para o que me desagrada, quer exagerando o valor do que pouco me agrada. Serei, pois, sobre isso tudo um enigma para mim mesmo?

 Mas é em ti, ó Verdade, que percebo que devo me alegrar com os louvores que me dirigem, não em meu interesse, mas no interesse do próximo. Não sei se é este o meu caso, pois neste assunto me conheces melhor do que eu mesmo. Suplico-te, meu Deus, que me dês a conhecer a mim mesmo, para que eu possa confessar a meus irmãos, dispostos a orar por mim, as chagas que achar em mim. Faze que me examine com mais diligencia. Se for de fato o bem do próximo que me alegra quando me louvam, porque sou menos sensível ao vitupério injustamente feito a outro, do que se fosse a mim? Porque o aguilhão da injúria me faz sofrer mais do que injúria igualmente injusta feita a uma outra pessoa diante de mim? Acaso também ignoro isto? Deveria então concluir que me iludo, e que meu coração e minha língua burlam diante de ti a verdade?

 Afasta de mim, Senhor, esta loucura, para que minhas palavras não sejam para mim óleo de pecador para ungir minha cabeça.

## CAPÍTULO XXXVIII

### A vanglória

 Sou pobre e necessitado, e só melhoro quando, com gemidos íntimos e com desagrado de mim mesmo, busco tua misericórdia, até que minha indigência seja reparada e sanada com a paz que o olho soberbo ignora! Todavia, as palavras de nossa boca, ou nossos atos conhecidos dos homens, encerram uma tentação muito perigosa, filha do amor dos louvores que, para nos iludir com certa excelência, recolhe e mendiga os aplausos alheios. A vanglória me tenta até quando a critico em mim, e é por isso mesmo que eu a desaprovo. Muitas vezes, por excesso de vaidade, há quem se glorie até mesmo do desprezo da vanglória; mas de fato não é mais do desprezo da vanglória que se orgulha, porque ninguém a despreza quando se gloria de a desprezar.

## CAPÍTULO XXXIX

### O amor-próprio

 Há ainda entre nós, profundamente assentada, outra tentação do mesmo gênero, que torna vãos aqueles que se comprazem de si mesmos, ainda que não agradem aos outros, ou até lhes desagradem, ou sequer procuram lhes agradar. E quanto mais enfatuados estejam consigo mesmos, mais desagradam a ti, não só ao se gloriarem dos males como se fossem bens, mas sobretudo quando se gloriam de teus bens como se fossem deles; ou quando, reconhecendo-os em si, eles os atribuem a seus merecimentos; ou ainda quando, atribuindo-os à tua graça, eles não os gozam amigavelmente com os demais, gestando ciúmes e inveja.

 Em todos estes perigos e provas, tu vês o temor de meu coração, e sinto que são mas as feridas que curas em mim do que as que inflijo a mim mesmo.

## CAPÍTULO XL

### À procura de Deus

 Quando deixaste de me acompanhar, ó Verdade, para me ensinar o que eu devia evitar ou procurar, sempre te consultei, a ti submetendo, dentro da minha limitação, meus medíocres pontos de vista? Percorri com os sentidos, como pude, o mundo exterior. Observei a vida de meu corpo e os meus próprios sentidos. Depois adentrei nas profundezas da memória em seus múltiplos domínios, tão maravilhosamente repletos de inúmeras riquezas; observei tudo isso, estupefato. Sem teu auxílio nada poderia distinguir, mas reconheci que nada disto eras tu. Nem era eu o descobridor de todas essas coisas; me esforcei para distingui-las e avaliá-las em seu devido valor, recebendo-a através dos sentidos e interrogando-as. Senti outras coisas unidas a mim, e as examinei, assim como aos sentidos que mas traziam; revolvi as vastas reservas da memória, analisando certas lembranças, guardando umas e trazendo outras à luz. Porque tu és a luz permanente que eu consultava sobre a existência, o valor e a qualidade de todas as coisas, e eu ouvia teus ensinamentos e tuas ordens. Costumo fazê-lo muitas vezes, pois essa é a minha alegria, e sempre que meus trabalhos me permitem algum descanso, refugio-me nesse prazer.

 Em nenhuma dessas coisas que percorro consultando-te, não encontro lugar seguro para minha alma senão em ti; só em ti se reúnem meus pensamentos esparsos, sem que nada meu se aparte de ti. Às vezes, me fazes conhecer uma extraordinária plenitude de vida interior, de inefável doçura que, se chegasse à contemplação, não seria certamente compatível com esta vida. Mas torno a cair nesta baixeza, cujo peso me acabrunha; volto a ser dominado pelos meus hábitos, que me tem cativo e, apesar de minhas lágrimas, não me libertam. Tão pesado é o fardo do hábito! Não quero estar onde posso e não posso estar onde quero: miséria em ambos os casos!

## CAPÍTULO XLI

### Deus e a mentira

 Examinei minhas fraquezas de pecador nas três formas de concupiscência, e invoquei tua destra para me salvar. Apesar de ter coração ferido, vi teu esplendor, e forçado a recuar, disse: "Quem pode chegar lá? Fui lançado para longe de teus olhos". – Tu és a verdade que preside a todas as coisas. E eu, minha avareza, não queria perder-te, mas queria possuir ao mesmo tempo a ti e à mentira, como os que não querem mentir a ponto de perderem a noção de verdade. Assim te perdi, porque não admites, nem nenhum coração, conviver com a mentira.

## CAPÍTULO XLII

### Os neoplatônicos e o caminho para Deus

 Poderia eu encontrar alguém que me reconciliasse contigo? Deveria eu recorrer aos anjos? E com que orações, com que ritos? Ouvi dizer que muitos dos que se esforçam para voltar a ti, e que não conseguiam por si mesmos, tentaram este caminho e caíram na curiosidade de visões estranhas, recebendo por isso o justo castigo das ilusões.

 Soberbos, procuravam-te com o coração inchado de sua ciência arrogante, e sem humildade. E atraíram para si, pela semelhança de sentimentos, os demônios do ar, que se fizeram cúmplices e aliados de sua soberba, e se tornaram iludidos de seus poderes mágicos. Procuravam um mediador para purifica-los, mas não o encontraram, senão ao demônio transfigurado em anjo de luz, que justamente por não possuir corpo de carne, seduziu-lhes fortemente a carne orgulhosa. Eram eles mortais e pecadores, e tu, Senhor, com quem eles procuravam com soberba reconciliar-se, és imortal e sem pecado.

 Era necessário que o mediador entre Deus e o homem tivesse alguma semelhança tanto com Deus como com os homens; pois se assemelhasse apenas aos homens, estaria muito longe de Deus; e se assemelhando só a Deus, estaria muito longe dos homens; em ambos os casos não poderia ser mediador.

 E aquele falso mediador que é o demônio, a quem teus ocultos juízos permitem que iluda a soberba, tem de comum com os homens apenas uma coisa, isto é, o pecado. Finge contudo, ter algum traço em comum com Deus, e como não está revestido de carne mortal, pretende ser imortal. Mas, como a morte é o salário do pecado, ele tem isso em comum com os homens: como eles, ele é condenado à morte.

## CAPÍTULO XLIII

### Cristo, o único mediador

 O verdadeiro mediador que tua insondável misericórdia enviou e revelou aos homens, para que aprendessem a humildade pelo seu exemplo, é esse mediador entre Deus e os homens, o homem Jesus Cristo. Apareceu como intermediário entre os pecadores mortais e o Justo imortal, mortal como os homens e justo como Deus. E, como a vida e a paz são a recompensa da justiça, pela justiça que o une a Deus ele suprimiu a morte entre os ímpios justificados, e quis compartilhá-la com eles. Foi revelado aos santos dos antigos tempos, para que eles se salvassem pela fé em sua paixão futura, como nós nos salvamos pela fé em sua paixão passada. De fato, só é mediador enquanto homem; enquanto Verbo não é intermediário, por ser igual a Deus: Deus em Deus e, ao mesmo tempo, Deus único.

 Como nos amaste, Pai bondoso! Não poupando teu Filho único, o entregaste por nós pecadores! Oh! Como nos amaste! Foi por amor a nós que teu Filho, que não considerava rapina o ser igual a ti, submeteu-se até a morte de cruz. Ele era o único livre entre os mortos, tendo o poder de dar sua vida e de novamente retomá-la. Por nós se fez diante de ti vencedor e vítima; por nós, diante de ti, se fez sacerdote e sacrifício, e sacerdote porque ele era o sacrifício; de escravos, fez de nós teus filhos; nascidos de ti, se fez nosso escravo. Com razão ponho nele a firme esperança que curarás todas as minhas enfermidades por intermédio dele, que está sentado à tua direita e intercede por nós junto de ti. De outro modo desesperaria, pois são muitos e grandes meus males; porém mais poderoso é o poder do teu remédio. Poderíamos pensar que teu Verbo estava muito longe para se unir ao homem, e desesperar de nós, se ele não se tivesse feito carne, habitando entre nós.

 Atemorizado por meus pecados e pelo peso de minhas misérias, meditei o projeto de fugir para o ermo; mas tu te opuseste e me fortaleceste dizendo: Cristo morreu por todos, para que os viventes já não vivam para si, mas por aquele que morreu por eles.

 Eis, Senhor, que lanço em ti os cuidados da minha vida, e contemplarei as maravilhas da tua lei. Conheces minha ignorância e minha fraqueza: ensina-me, cura-me. Teu Filho único, em que estão escondidos todos os tesouros da sabedoria e da ciência, me remiu com sangue. Não me caluniem os soberbos, porque eu conheço bem o preço de minha redenção. Como o corpo e bebo o sangue da vítima redentora, distribuo-a aos outros; pobre, desejo saciar-me dela em companhia daqueles que a comem e são saciados. E louvarão ao Senhor os que o buscam!

# LIVRO DÉCIMO-PRIMEIRO

## CAPÍTULO I

### Finalidade das confissões

 Porventura, Senhor, tu que és eterno, ignoras o que te digo, ou não vês no tempo o que se passa no tempo? Por que motivo, então, narrar-te essas coisas todas? Certamente não é para que as conheças; é para despertar em mim e nos que me lêem nosso amor por ti; para que todos exclamemos: Grande é o Senhor, e infinitamente digno de louvores! Já disse e torno a dizer: É pelo desejo de teu amor que narro isso.

 Também nós oramos e, não obstante, a Verdade nos diz: O Pai sabe do que haveis mister, antes mesmo de lho pedires. – Por isso manifestamos nosso amor por ti, confessando-te nossas misérias e tuas misericórdias para conosco, para que termines a nossa libertação que começaste, e para que deixemos de ser infelizes em nós para sermos felizes em ti. Pois nos chamaste para que fôssemos pobres de espírito, mansos, penitentes, famintos e sedentos de justiça, misericordiosos, puros de coração e pacíficos.

 Muitas coisas te narrei, conforme o pude e conforme o desejo de minha alma, porque o exigiste primeiro, para que te confessasse, Senhor, meu Deus, porque és bom, e porque tua misericórdia é eterna.

## CAPÍTULO II

### A inteligência das Escrituras

 Quando poderei eu descrever, com o poder de minha pena, todas as exortações, todos os terrores, as consolações, as inspirações de que lançaste mão para me levar a pregar tua palavra e dispensar ao povo teu sacramento?

 Mesmo que eu fosse capaz de enumerar na ordem tais coisas, as gotas de meu tempo me são preciosas. De há muito que anseio ardentemente meditar sobre tua lei, e te confessar nela minha ciência e minha ignorância, os albores de tuas luzes na minha alma e o que ainda resta em mim de trevas, até que minha fraqueza seja absorvida por tua força. Não quero gastar em outros cuidados as horas de liberdade que me restam além dos cuidados indispensáveis do corpo, do trabalho intelectual, dos serviços que devemos aos homens, e dos que prestamos sem lhe dever.

 Senhor meu Deus, ouve minha prece; que tua misericórdia atenda ao meu desejo, pois não arde só por mim, mas também para servir ao amor fraternal, e bem vês em meu coração que é assim.

 Permitas que te sacrifique meu pensamento e minha língua, mas concede-me o que te devo oferecer, porque sou pobre e indigente, enquanto és rico para todos os que te invocam e, sem cuidados contigo, cuidas de nossa existência. Livra-me, Senhor, de toda temeridade e de toda mentira que meus lábios e meu coração possam proferir. Que tuas Escrituras sejam minhas castas delicias, que não me engane nelas, nem com elas engane a ninguém. Senhor, ouve-me, e tem compaixão, Senhor meu Deus, luz dos cegos e vigor dos fracos, mas também luz dos que vêem e força dos fortes; presta atenção à minha alma e ouve-a clamar do fundo do abismo. E se teus ouvidos estão ausentes do abismo, para onde iremos, por quem clamaremos?

 Teu é o dia e tua é a noite; a um aceno do teu querer, os minutos voam. Concede-me o tempo para meditar nos mistérios de tua lei, e não a feche para os que lhe batem à porta; não foi em vão que quiseste fossem escritas tantas páginas de obscuros segredos. Porventura, estes bosques não terão seus cervos, que ali se abrigam, se alimentam, que aí passeiam, descansam e ruminam? Ó Senhor, aperfeiçoa-me e revela-me o sentido desses mistérios. Tua palavra é minha alegria, tua voz está acima de todos os prazeres. Concede-me o que amo, porque ando enamorado, e amar é um dom que me concedeste. Não abandone teus dons, nem deixe de regar tua erva sedenta. Te exaltarei por tudo o que descobrir em teus livros; que eu ouça a voz de teus louvores. Faz que eu me inebrie de ti, e que eu contemple as maravilhas de tua lei, desde o começo dos tempos, quando fizeste o céu, a terra, até que partilharemos do reino do perpétuo de tua cidade santa.

 Senhor, tem piedade de mim, ouve meu desejo. Julgo que não desejo nada da terra, nem ouro, nem prata, nem pedras preciosas, nem belas roupas. Nem honrarias, nem prazeres carnais, nem de coisas necessárias ao corpo de nossa peregrinação desta vida. Tudo, alias, nos é dado por acréscimo quando procuramos teu reino e tua justiça.

 Vê, meu Deus, de onde nasce meu desejo. Os ímpios contaram-me suas alegrias, mas esses prazeres não são como os proporcionados por tua lei. É ela que inspira meu desejo. Olha, ó Pai, olha, e vê, e aprova. Queira tua misericórdia que eu encontre graça diante de ti, e que os arcanos secretos de tuas palavras se abram a meu espírito que bate às suas portas!

 Isso eu te suplico por nosso Senhor, Jesus Cristo, teu filho, aquele que está sentado à tua direita, o Filho do homem, a quem estabeleceste como mediador entre nós e ti. Por ele nos procuraste quanto não te procurávamos, e nos procuraste para que te buscássemos! Em nome de teu Verbo, por quem criaste todas as coisas, e a mim entre outras; de teu Filho unigênito, por quem chamaste à adoção o povo dos crentes, no qual também estou.

 Eu te conjuro por aquele que está sentado à tua direita, e que intercede por nós, no qual estão ocultos todos os tesouros da sabedoria e do conhecimento que procuro em teus livros. Moisés escreveu a respeito: "Isto diz ele, isto diz a Verdade".

## CAPÍTULO III

### O que disse Moisés

 Concede-me, Senhor, que eu ouça e compreenda como no princípio criaste o céu e a terra. Moisés assim o escreveu. Escreveu e partiu deste mundo, para onde lhe falaste, para junto de ti, e já não está presente para nós. Se estivesse aqui, detê-lo-ia, e dele indagaria, em teu nome, o sentido de tais palavras, e absorveria com atenção as palavras que brotassem de sua boca. Se me falasse em hebraico, em vão sua voz bateria em meus ouvidos, e nenhuma idéia chegaria à minha mente; mas se me falasse em latim, eu compreenderia suas palavras.

 Mas, como saberia eu se ele dizia a verdade? E, posto que o soubesse, sabê-lo-ia por seu intermédio? Não, mas seria dentro de mim, no íntimo recesso do pensamento que a Verdade, que nem é hebraica, nem grega, nem latina, nem bárbara, sem auxílio de lábios ou de língua, sem ruído de sílabas, me diria: "Ele fala a verdade". – e eu, imediatamente, com a certeza da fé, diria àquele teu servo: "Tu dizes a verdade!".

 Mas, como não posso consultar a Moisés, é a ti, ó Verdade, cuja plenitude ele possuía quando enunciou tais palavras, é a ti, meu Deus, que dirijo minha súplica, perdoa meus pecados. Concedeste que um tem servo dissesse essas coisas: faze agora com que eu as compreenda.

## CAPÍTULO IV

### O céu e a terra

 Existem pois o céu e a terra, e clamam que foram criados, mediante de suas transformações e mudanças. Mas o que não foi criado em sua forma definitiva, e todavia existe, nada pode conter que antes já não existisse em sua forma potencial, e nisso consiste a mudança e a variação. Proclamam também, os seres, que não foram criados por si mesmos: "Existimos porque fomos criados. Não existíamos antes, de modo que pudéssemos criar a nós mesmos." – E essa voz é a voz da própria evidência. És tu, Senhor, quem os criaste. E porque és belo, eles são belos; porque és bom, eles são bons; porque existes, eles existem. Mas tuas obras não são belas, não são boas, não existem de modo perfeito como tu, seu Criador. Comparados contigo, os seres nem são bons, nem belos, nem existem. Isso sabemos, e por isso te rendemos graças; mas nosso saber, comparado com tua ciência, é ignorância.

## CAPÍTULO V

### A palavra e a criação

 De que modo criaste o céu e a terra, e de que instrumento te serviste para levar a cabo tão grandiosa obra? Pois não procedeste como artesão, que forma um corpo de outro, conforme a concepção de seu espírito, que tem o poder de exteriorizar a forma que vê em si mesmo com o olhar do espírito. De onde lhe vem esse poder do espírito, senão de ti, que o criaste? E essa forma, ele a impõe a uma matéria que preexistia, apta para ser transformada, como a terra, a pedra, a madeira, o outro e tantas outras substâncias.

 Mas de onde proviriam essas coisas se não as tivesse criado? Criaste o corpo do artista, a alma que governa seus membros, a matéria que ele plasma, a inspiração que concebe e vê interiormente o que executará exteriormente. Deste-lhe os órgãos dos sentidos, intérpretes pelos quais materializa as intenções de sua alma; informam o espírito do que fizeram, para que este consulte a verdade, o juiz interior, para saber se a obra é boa. Tudo isso te louva como criador de todas as coisas.

 Mas como os fizeste? Como criaste, meu Deus, o céu e a terra? Por certo não criaste o céu e a terra no céu e na terra. Nem tampouco os criaste no ar, nem sob as águas que pertencem ao céu e à terra. Não criaste o universo no universo, porque não havia espaço onde pudesse existir. Não tinhas à mão a matéria com que modelar o céu e a terra. E de onde viria essa matéria que não tinhas ainda feito para dela fazer alguma coisa? Que criatura pode existir que não exija tua existência? Contudo, falaste e o mundo foi feito. Tua palavra o criou.

## CAPÍTULO VI

### Como falou Deus?

 Mas, como falaste? Porventura do mesmo modo como aquela voz que, saindo da nuvem, disse: Este é meu Filho bem-amado? – Essa voz fez-se ouvir, e passou; teve começo e fim; suas sílabas ressoaram, depois passaram, em sucessão ordenada até a última, que vem depois de todas as outras – e depois foi o silêncio. Por onde se vê claramente que essa voz foi gerada por órgão temporal de uma criatura a serviço de tua vontade eterna. E essas palavras, pronunciadas no tempo, foram comunicadas pelo ouvido material à inteligência, cujo ouvido interior está atento à tua palavra eterna. E a razão comparou essas palavras, proferidas no tempo, com o silêncio de teu Verbo eterno, e disse: "È diferente, muito diferente. Tais palavras estão bem abaixo de mim, nem sequer existem, pois fogem e passam; mas o Verbo de Deus permanece sobre mim eternamente".

 Se foi portanto com estas palavras sonoras e passageiras que ordenaste: Que se façam o céu e a terra! – se foi assim que os criaste, conclui-se que já havia, antes do céu e da terra, uma criatura temporal, cujos movimentos puderam fazer vibrar essa voz no tempo. Ora, não havia corpo algum antes do céu e da terra; ou se algum existia, tu certamente já o tinhas criado não por meio de uma voz passageira, justamente para que pudesse soar essa voz passageira para dizer: "Façam-se o céu e a terra!" E fosse o que fosse o ser de onde saísse tal voz, não teria existido se não o tivesses criado. Mas para criar esse corpo, necessário à emissão destas palavras, de que palavra e serviste?

## CAPÍTULO VII

### A palavra coeterna

 É assim que nos convidas a compreender o Verbo, que é Deus junto de ti, que também és Deus, Verbo pronunciado eternamente e pelo qual tudo é pronunciado eternamente. O que é dito, não é uma seqüência de palavras, ou uma palavra que é seguida por outra, como que a concluir uma frase; mas tudo é dito simultânea e eternamente. Do contrário, já haveria tempo e mudança, e não a verdadeira eternidade nem a verdadeira imortalidade.

 Isto eu o sei, meu Deus, e por isso te dou graças. Eu o sei, e eu to confesso, Senhor; e também o sabe todo aquele que não é ingrato à infalível verdade. Sabemos, Senhor, sabemos que não ser mais depois de ter existido, ou passar a ser quando ainda não se existia é o morrer e o nascer. Mas em teu Verbo, por ser verdadeiramente imortal e eterno, nada desaparece nem tem sucessão. Com o teu Verbo que é coeterno, enuncias eternamente e a um só tempo tudo o que dizes. E o que se realiza é o que dizes que se faça. Não é de outro modo, senão pelo Verbo, que crias. Todavia os seres criados por tua palavra não chegam à existência simultaneamente, desde toda a eternidade.

## CAPÍTULO VIII

### A verdadeira luz

 Imploro-te, Senhor meu Deus, qual o porquê disso tudo? De certo modo eu o compreendo, mas não sei como exprimi-lo. Poderei dizer que tudo o que tem começo e fim, começa e acaba quando a razão eterna, que não tem começo nem fim, sabe que deve começar ou acabar? Essa inteligência é teu Verbo, que é o princípio, porque também nos fala. Assim falou-nos no Evangelho com voz humana, e a palavra ecoou exteriormente nos ouvidos dos homens, para que cressem nele, e o buscassem em seu íntimo, e o encontrassem na eterna Verdade, onde um bom e único mestre instrui todos os seus discípulos.

 Aí, Senhor, ouço tua voz a me dizer que só nos fala verdadeiramente quem nos ensina, e quem não nos instrui, mesmo que fale, não nos diz nada. Mas quem nos ensina, senão a Verdade imutável? As lições da criatura mutável têm o único valor de nos conduzir à Verdade, que é imutável. Nela verdadeiramente aprendemos quando, de pé, a ouvimos, alegrando-nos por cauda da voz do Esposo, que nos reconduz àquele de quem viemos. Por isso, ele é o princípio, pois se ele não permanecesse, não teríamos para onde voltar de nossos erros. Quando voltamos de um erro, temos plena consciência dessa volta; e é para que tomemos consciência de nossos erros que ele nos instrui, porque ele é o princípio, e sua palavra é para nós.

## CAPÍTULO IX

### A voz do Verbo

 É nesse princípio, ó Deus, que criaste o céu e a terra; em teu Verbo, em teu Filho, em tua virtude, em tua sabedoria, em tua verdade, falando e agindo de modo admirável. Quem o poderá compreender ou explicar? Que luz é essa que por vezes me ilumina, e que fere meu coração sem o lesar? Atemorizo-me e inflamo-me: tremo porque, de certo modo, sou tão diferente dela; e inflamo-me, porque também sou semelhante a ela. A Sabedoria é a mesma sabedoria que brilha em mim de quando em quando: ela rasga as nuvens de minha alma, que novamente me encobrem quando dela me afasto, pelas trevas e pelo peso de minhas memórias. Na indigência, meu vigor enfraqueceu de tal modo, que nem posso mais suportar o meu bem, até que tu, Senhor que te mostraste compassivo com todas minhas iniqüidades, cures também todas as minhas fraquezas. Redimirás minha vida da corrupção; hás de me coroar na piedade e na misericórdia, e saciarás com teus bens meus desejos, porque minha juventude será renovada com a da águia. Pela esperança formos salvos, e aguardamos com paciência o cumprimento de tuas promessas.

 Ouça, pois, Tua voz em seu interior, quem puder, e eu quero clamar, cheio de fé em teu oráculo: "Como são magníficas as tuas obras, Senhor, que tudo criaste em tua Sabedoria! Ela é o princípio e nesse princípio criaste o céu e a terra".

## CAPÍTULO X

### Que fazia Deus antes da criação

 Com certeza ainda estão cheios do erro do velho homem os que nos dizem: "Que fazia Deus antes de criar o céu e a terra?" – Se estava ocioso, se nada fazia, porque não continuou a se abster sempre de qualquer ação? Se em Deus apareceu um movimento novo, uma vontade nova de dar o ser ao que ainda não tinha criado, como falar de uma verdadeira eternidade se nela nasce uma vontade que não existia antes? Mas a vontade de Deus não é uma criatura, ela é anterior a toda criatura; nenhuma criação seria possível se a vontade do Criador não a precedesse. A vontade, portanto, pertence à própria substância de Deus. Logo, se na substância de Deus nasce algo que antes não existia, não se pode mais com verdade chamá-la eterna. E se, desde toda eternidade, Deus quis a existência da criatura, por que a criatura também não é eterna?

## CAPÍTULO XI

### Tempo e eternidade

 Os que assim falam não te compreendem ainda, ó Sabedoria de Deus, luz das inteligências; não compreendem ainda como é criado o que é criado por ti e em ti. Esforçam-se por saborear as coisas eternas, mas seu espírito voa ainda sobre as realidades passadas e futuras. Quem poderá deter esse pensamento, quem o fixará por um momento, para que tenha um rápido vislumbre do esplendor da eternidade imutável, e a compare com os tempos impermanentes, para perceber que qualquer comparação é impossível? Então veria que a sucessão dos tempos não é feita senão de uma seqüência infindável de instantes, que não podem ser simultâneos; que, pelo contrário, na eternidade, nada é sucessivo, tudo é presente, enquanto o tempo não pode ser de todo presente. Veria que todo o passado é repelido pelo futuro, que todo futuro segue o passado, que tanto o passado como o futuro tiram seu ser e seu curso daquele que é sempre presente. Quem poderá deter a inteligência do homem para que pare e veja como a eternidade imóvel, que não é futura nem passada, determina o futuro e o passado? Acaso poderá realizar isso minha mão? Ou esta minha língua, com a palavra, poderia realizar tal obra?

## CAPÍTULO XII

### Deus antes da criação

 Eis minha resposta à questão: "Que fazia Deus antes de criar o céu e a terra?" – não responderei jocosamente como alguém para contornar a dificuldade do problema: "Preparava o inferno para os que perscrutam esses mistérios profundos". – Uma coisa é compreender e outra é brincar. Não, essa não será minha resposta. Prefiro dizer: "Não sei" – pois de fato não sei, que ridicularizar quem faz pergunta tão profunda, ou louvar quem responde com sofismas.

 Mas eu digo que tu, meu Deus, és o Criador de toda criatura; e, se por céu e terra se entende toda criatura, não temo afirmar: "Antes que Deus criasse o céu e a terra, nada fazia. De fato, se tivesse feito alguma coisa, o que poderia ser senão uma criatura? Oxalá eu soubesse tudo o que desejo saber, como sei que nenhuma criatura foi criada antes da criação.

## CAPÍTULO XIII

### O tempo antes da criação

 Se algum espírito leviano, vagando por tempos imaginários anteriores à criação, se admirar que o Deus Todo-Poderoso, tu, que criaste e conservas todas as coisas, ó autor do céu e da terra, tenha-te mantido inativo até o dia da criação, por séculos sem conta, que esse desperte e tome consciência do erra que gera sua admiração. Como, pois, poderiam transcorrer os séculos se tu, criador, ainda não os tinha criado? E poderia o tempo fluir se não existisse? E como poderiam os séculos passar, se jamais houvessem existido? Portanto, como és o criador de todos os tempos – se é que houve algum tempo antes da criação do céu e da terra – como se pode afirmar que ficaste ocioso? Pois também criaste esse mesmo tempo, e este não poderia passar antes que o criasses.

 Se porém, antes do céu e da terra não havia tempo algum, porque perguntam o que fazias então? Não poderia haver então se não existia o tempo.

 Não é no tempo que és anterior ao tempo: de outro modo não precederias a todos os tempos. Precedes porém a todo o passado na altura de tua eternidade sempre presente; dominas todo o futuro porque está por vir e que, quando chegar, já será passado. Contudo, tu és sempre o mesmo, e teus anos não passam jamais. Teus anos não vão nem vêm; mas os nossos vão e vêm, para que todos possam existir. Teus anos existem simultaneamente, pois não fluem; não passam, não são expulsos pelos que vêm, porque não passam. Os nossos, ao contrário, só existirão todos quando não mais existirem. Teus anos são como um só dia, e teu dia não é uma repetição cotidiana, é um perpétuo hoje, porque teu hoje não cede o lugar ao amanhã e nem sucede ao ontem. Teu hoje é a eternidade. Por isso geraste um filho coeterno, a quem disseste: "Hoje te gerei" – Todos os tempos são obra tua, e tu existes antes de todos os tempos; é pois inconcebível que tenha existido tempo quando o tempo ainda não existia.

## CAPÍTULO XIV

### Que é o tempo?

 Não houve, pois, tempo algum em que nada fizesses, pois fizeste o próprio tempo. E nenhum tempo pode ser coeterno contigo, pois és imutável; se, o tempo também o fosse, não seria tempo. Que é pois o tempo? Quem poderia explicá-lo de maneira breve e fácil? Quem pode concebê-lo, mesmo no pensamento, com bastante clareza para exprimir a idéia com palavras? E no entanto, haverá noção mais familiar e mais conhecida usada em nossas conversações? Quando falamos dele, certamente compreendemos o que dizemos; o mesmo acontece quando ouvimos alguém falar do tempo. Que é, pois, o tempo? Se ninguém me pergunta, eu sei; mas se quiser explicar a quem indaga, já não sei. Contudo, afirmo com certeza e sei que, se nada passasse, não haveria tempo passado; que se não houvesse os acontecimentos, não haveria tempo futuro; e que se nada existisse agora, não haveria tempo presente. Como então podem existir esses dois tempos, o passado e o futuro, se o passado já não existe e se o futuro ainda não chegou? Quanto ao presente, se continuasse sempre presente e não passasse ao pretérito, não seria tempo, mas eternidade. Portanto, se o presente, para ser tempo, deve tornar-se passado, como podemos afirmar que existe, se sua razão de ser é aquela pela qual deixará de existir? Por isso, o que nos permite afirmar que o tempo existe é a sua tendência para não existir.

## CAPÍTULO XV

### Tempo longo, tempo breve

 No entanto, dizemos que o tempo é longo ou breve, o que só podemos dizer do passado e do futuro. Chamamos longo, digamos, os cem anos passados, e longo também os cem anos posteriores ao presente; um passado curto para nós, seriam os dez dias anteriores a hoje, e breve futuro, os dez dias seguintes. Mas como pode ser longo ou curto o que não existe? O passado não existe mais e o futuro não existe ainda. Por isso não deveríamos dizer "o passado é longo" – mas o passado "foi longo" – e o futuro "será longo".

 Senhor, que és a minha luz, tua verdade não escarnecerá também nisso o homem? Esse tempo passado, foi longo quando já havia passado ou quando ainda estava presente? Porque ele só podia ser longo enquanto existia alguma coisa que pudesse ser longa. Mas uma vez passado, não existia mais: donde se conclui que não podia ser longo, porque já deixara de existir. Não digamos, portanto: "O tempo passado foi longo" – pois não encontraremos nada que pudesse ter sido longo; uma vez passado não existe mais. Mas digamos: "O tempo presente foi longo" – porque só era longo enquanto presente. Ainda não havia passado, ainda não havia deixado de existir, e por isso era susceptível de ser longo. Mas logo que passou, deixou de ser longo, porque cessou de existir.

 Mas vejamos, ó alma humana, se o tempo presente pode ser longo, porque foi-te dada a prerrogativa de perceber e medir os momentos. Que me respondes? Por acaso cem anos presentes são um tempo longo? Consideremos antes se cem anos podem ser presentes. Se for o primeiro ano que corre, está presente; mas os outros noventa e nove ainda são futuros, e portanto ainda não existem. Se estamos no segundo ano, já temos um ano passado, o segundo presente e todos os outros no futuro. Desse período de cem anos, seja qual for o ano que supomos presente, todos os que o precederam serão passados, e todos os que estão por vir, futuros. Portanto, os cem anos não podem estar simultaneamente presentes.

 Vejamos agora se, pelo menos, o ano em curso é presente. Se estamos no primeiro mês, os outros são futuros. Como acima, se estamos no segundo, o primeiro será passado, e os demais, futuros. Assim o ano que corre não está todo presente; e como não está todo presente, não é portanto verdade dizer-se que o ano esteja presente. Um ano compõe-se de doze meses, e seja qual for o mês considerado, será o único em curso. Mas o mês em curso não é presente, mas somente o dia. Vale o que dissemos antes: se estamos no primeiro dia, todos os outros são futuros; se estamos no último, todos os outros são passados; se estamos entre um desses dois dias, esse dia está entre os dias passados e os futuros.

 Eis, portanto, esse tempo presente, o único que julgávamos poder chamar de longo, reduzido ao espaço de um só dia. Mas, examinemos esse único dia, porque nem mesmo ele é todo presente. Compõe-se de dia e noite, num total de vinte e quatro horas; relativamente à primeira hora, todas as outras são futuras; em relação à última hora, todas as outras são passadas; cada hora intermediaria tem atrás de si horas passadas e diante de si horas futuras. Mas também essa única hora é composta de fugitivos instantes; tudo o que dela correu é passado, e tudo o que ainda lhe resta é futuro.

 Se pudermos conceber um lapso de tempo que não possa ser subdividido em frações, por menores que sejam, só essa fração poderá ser chamada de presente, mas sua passagem do futuro para o passado seria tão rápida, que não teria nenhuma duração. Se a tivesse, dividir-se-ia em passado e futuro, mas o presente não em duração alguma.

 Qual seria pois, o tempo que podemos chamar de longo? Seria acaso o futuro? mas nós não dizemos que o futuro é longo, porque ainda não existe, e por isso não pode ser longo. Dizemos: "Será longo". E quando se dará? Se atualmente ele ainda está no porvir, não pode ser longo: não existindo ainda, não pode ser longo. Mas somente poderá ser longo na hora em que emergir do futuro, que ainda não existe, em que começar a ser e a se tornar presente, de modo que possa ser longo. Nesse caso o presente nos clama, pelo que acima dissemos, que ele não pode ser longo.

## CAPÍTULO XVI

### A medida do presente

 E, contudo, Senhor, percebemos os intervalos de tempos, os comparamos entre si, e dizemos que uns são mais longos e outros mais breves. Medimos também o quanto uma duração é maior ou menor que outra, e respondemos que esta é o dobro ou o triplo de outra; que aquela é simples, ou que ambas são iguais. Mas é o tempo que passa que medimos quando o percebemos passar. Quanto ao passado, que não existe mais, e o futuro que não existe ainda, quem poderá medi-los, a menos que ouse afirmar que o nada pode ser medido? Assim, quando o tempo passa, pode ser percebido e medido. Porém quando já decorreu, ninguém o pode mentir ou sentir, porque já não existe.

## CAPÍTULO XVII

### O passado e o presente

 Pai, apenas pergunto, não estou afirmando; meu Deus, ajuda-me, dirige-me. Quem ousaria afirmar que não existe três tempos, como aprendemos na infância e como ensinamos às crianças, o passado, o presente e o futuro? será que só o presente existe, porque os demais, o passado e o futuro, não existem? Ou será que eles também existem, e então o presente provém de algum lugar oculto, quando de futuro se torna presente, e também se retira para outro esconderijo, quando de presente se torna passado? E os que predisseram o futuro, onde o viram, se ele ainda não existe? É impossível ver-se o que não existe. E os que narram o passado diriam mentiras se não vissem os acontecimentos com o espírito. Ora, se esse passado não tivesse existência alguma, seria absolutamente impossível vê-lo. Por conseguinte, o futuro e o passado também existem.

## CAPÍTULO XVIII

### As previsões

 Permite-me, Senhor, que eu leve adiante minhas investigações, tu que és minha esperança; faze que minha tentativa não seja perturbada. Se o futuro e o passado existem, quero saber onde estão. Se ainda não posso compreender, sei todavia que, onde quer que estejam, não existem nem como futuro, nem como passado, mas apenas como presente. Se também ali estiver enquanto futuro, então ainda não existirá; se o passado aí estiver como passado, já não estará lá. Portanto, no lugar e no modo que estiverem, só podem existir como presentes. Quando relatamos acontecimentos verídicos do passado, o que vêm à nossa memória não são os fatos em si, que já deixaram de existir, mas as palavras que exprimem as imagens dos fatos, que, através de nossos sentidos, gravaram em nosso espírito suas pegadas. Minha infância, por exemplo, que não existe mais, pertence a um passado que também desapareceu; mas quando eu a evoco e passo a relatá-la, vejo suas imagens no presente, imagens que ainda estão na minha memória. E a predição do futuro, meu Deus, seguiria um processo análogo? Os fatos que ainda não existem, serão representados antecipadamente em nosso espírito como imagens já existentes? Eu o ignoro. O que sei é que habitualmente premeditamos nossas ações futuras, e que essa premeditação pertence ao presente, enquanto esta começará a existir, pois então não será mais futura, mas presente.

 Seja qual for a natureza desse misterioso pressentimento do futuro, o certo é que apenas se pode ver aquilo que existe. Ora, o que já existe não é futuro, mas presente. Quando se diz que se vê o futuro, o que se vê não são os fatos futuros em si, que ainda não existem porque são futuros, mas suas causas ou talvez sinais prognósticos, causas e sinais que já existem. Estes não são pois futuros, mas presentes para os que as vêem, e é graças aos vaticínios que o futuro é concebido pelo espírito e profetizado. Esses conceitos já existem, e os que predizem o futuro vêem-nos presentes em si mesmos.

 Gostaria de apelar para um exemplo tomado entre os muitos possíveis. Vejo a aurora, e prognostico o nascimento do sol. O que vejo é presente, o que anuncio é futuro. Não o sol, que já existe, mas seu surgimento, que ainda não ocorreu. Contudo, se eu não tivesse uma imagem mental desse surgimento, como agora quando falo dele, ser-me-ia impossível a previsão. Mas essa aurora que vejo não é o nascimento do sol, embora o preceda; nem o é tampouco a imagem que trago em meu espírito. As duas coisas estão presentes, eu as vejo, e assim posso predizer o que vai acontecer. O futuro, portanto, ainda não existe; se ainda não existe, não existe no agora; e se não existe não pode ser visto de modo algum, mas pode ser prognosticado pelos sinais presentes, que já existem e podem ser vistos.

## CAPÍTULO XIX

### Oração

 Mas tu, que és soberano sobre tuas criaturas, de que modo ensinas às almas os fator porvir, como revelas aos teus profetas? De que modo ensinas o futuro, tu, para quem o futuro não existe? Ou antes, como ensinas os sinais presentes dos fatos futuros? Pois, o que ainda não existe não pode ser ensinado. O teu modo misterioso de agir está muito acima de minha inteligência, sobrepuja minhas forças. Por mim mesmo eu não o poderia alcançar, mas podê-lo-ei por ti, quando me concederes, ó doce Luz dos olhos de minha alma!

## CAPÍTULO XX

### Conclusão

 O que agora parece claro e evidente para mim é que nem o futuro, nem o passado existem, e é impróprio dizer que há três tempos: passado, presente e futuro. Talvez fosse mais correto dizer: há três tempos: o presente do passado, o presente do presente e o presente do futuro. E essas três espécies de tempos existem em nossa mente, e não as vejo em outra parte. O presente do passado é a memória; o presente do presente é a percepção direta; o presente do futuro é a esperança.

 Se me é lícito falar assim, vejo e confesso que há três tempos. Diga-se também que são três os tempos: presente, passado e futuro, como abusivamente afirma o costume. Não me importo, nem me oponho, nem critico o modo de falar, desde que fique bem entendido o que se diz, e que não se acredite que o futuro já existe e que o passado ainda existe. Uma linguagem que expresse com termos exatos é incomum: com muita freqüência falamos com impropriedade, mas entende-se o que queremos dizer.

## CAPÍTULO XXI

### A medida do tempo

 Disse há pouco que medimos o tempo que passa; de modo que podemos afirmar que um lapso de tempo é o dobro de outro, ou igual, e apontar entre os intervalos de tempo outras relações, mediante esse processo comparativo. Portanto, como eu dizia, medimos o tempo no momento em que passa. E se me perguntarem: Como o sabes? – eu responderia: Sei porque o medimos, e porque é impossível medir o que não existe; ora, o passado e o futuro não existem. Quanto ao presente, como podemos medi-lo, se não tem duração? Portanto, só podemos medi-lo enquanto passa; e quando passou, não o medimos mais, porque não há mais nada a mentir.

 Mas de onde se origina, por onde passa, para onde vai o tempo quando o medimos? De onde vem senão do futuro? Por onde passa, senão pelo presente? Para onde vai senão para o passado? Nasce pois do que ainda não existe, atravessa o que não tem duração, e corre para o que não existe mais. No entanto, o que é que medimos, senão o tempo relacionado ao espaço? Quando dizemos de um tempo que é simples, duplo, ou triplo, ou igual, ou quando formulamos qualquer outra relação dessa espécie, nada mais fazemos do que medir espaços de tempo. Em que espaço medimos então o tempo no momento em que passa? No futuro, talvez, donde procede? Mas o que ainda não existe não pode ser medido. Será no presente, por onde ele passa? Mas, como medir o que não tem extensão? Será no passado, para onde caminha? Mas o que não existe mais escapa à qualquer medida.

## CAPÍTULO XXII

### O enigma

 Minha alma se inflama no desejo de deslindar este enigma tão complicado! Senhor, meu Deus, meu bom Pai, eu to suplico por Cristo; não queiras tolher a meu desejo a solução de tais problemas, tão familiares mas tão obscuros; permite que eu os penetre, e faze com que a luz de tua misericórdia os ilumine, Senhor! A quem poderia eu consultar sobre isso? A quem confessaria minha ignorância com mais proveito do que a ti, que não se despraz com o forte zelo que me inflama por tuas Escrituras? Concede-me o que amo, pois este amor é um dom teu. Dá-me, ó Pai, esta graça, tu que sabes presentear com boas dádivas a teus filhos. Concede-me essa luz, porque determinei conhecê-las, e meu esforço será rude até que me reveles esses mistérios. Eu to suplico, por Cristo, em nome do Santo dos Santos, que ninguém perturbe minha investigação. Acreditei, e por isso falo. Minha esperança, a esperança pela qual vivo, é contemplar as delícias do Senhor. Eis que tornaste velhos os meus dias, e eles passam, não sei como.

 Nós só falamos de tempo, e de tempo, e de tempos e de tempos. Quanto tempo esse homem falou? Quanto tempo demorou para fazê-lo? Há quanto tempo não vejo isto! A duração desta sílaba é o dobro daquela, que é breve. Assim nos expressamos e assim ouvimos, e todos nos compreendem, e nós compreendemos. São palavras claras e de uso corrente, mas encerram mistérios, e compreendê-las requer melhor análise.

## CAPÍTULO XXIII

### O tempo e o movimento

 Ouvi um homem instruído dizer que o tempo é nada mais do que o movimento do sol, da lua e dos astros. Não concordo. Por que não seria então o tempo o movimento de todos os corpos? Se os astros passassem, e a roda de um oleiro continuasse a rodar, deixaria acaso de existir tempo para medir suas voltas? Como poderíamos dizer que elas se davam a intervalos iguais, ou ora mais rápida, ora mais lentamente, e que umas demoravam mais e outras menos? E, dizendo isto, não estaríamos falando do tempo? Não haveria mais em nossas palavras sílabas longas e breves, porque umas ressoam por mais tempo e outras por menos tempo?

 E tu, Deus, concede aos homens que percebam, que reconheçam neste modesto exemplo, o que as coisas grandes e pequenas têm em comum. Há astros e luminares celestes que nos servem de sinais e marcam as estações, os dias e os anos. Isso é verdade; todavia, como eu jamais diria que a volta realizada por aquela roda de madeira representa o dia, nem o sábio cuja opinião transcrevo poderia afirmar que a volta da roda não representa o tempo.

 O meu desejo é conhecer a natureza e a essência do tempo, com que medimos os movimentos dos corpos, e nos autoriza a dizer, por exemplo, que um movimento dura duas vezes mais que outro. O que chamamos de dia não é apenas o tempo todo o percurso de oriente a oriente, e que nos faz dizer: "Passaram-se tantos dias" – entendendo por isso também as noites, que não são enumeradas separadamente. Portanto, já que o dia se completa pelo movimento do sol e o círculo que ele cumpre a partir do oriente, pergunto eu se o dia é o próprio movimento ou se é o tempo que dura esses movimentos, ou ambas as coisas.

 Na primeira hipótese, teríamos um dia mesmo se o sol fizesse seu percurso no intervalo de uma hora. Na hipótese da duração, não haveria dia se o sol fizesse seu percurso no breve espaço de uma hora; e o sol deveria cumprir vinte e quatro vezes seu percurso para formar um dia. Diremos então que o movimento do sol, e a duração desse movimento, é que fazem o dia? Mas então não se poderia chamar de dia se o sol efetuasse seu percurso no lapso de uma hora, mais do que se, parando o sol seu percurso, passasse o mesmo tempo que é necessário habitualmente ao sol para completar sua revolução de uma manhã a outra.

 Portanto, não mais buscarei conhecer em que consiste o dia, mas em que consiste o tempo, que usamos para medir o percurso do sol. Usando tal medida, diríamos que o sol gastara em seu giro a metade do tempo habitual , se o tivesse completado em um lapso de doze horas. E, comparando essas duas durações, diríamos que uma é o dobro da outra, mesmo que o sol demorasse umas vezes o tempo simples, outras o tempo duplo para ir de oriente para oriente.

 Ninguém, portanto, me diga que o tempo é o movimento dos corpos celestes. Quando a oração de um homem fez parar o sol para concluir vitoriosamente a batalha, o sol estava imóvel, mas o tempo caminhava; e a batalha terminou no espaço de tempo que lhe era necessário.

 Veja, pois, que o tempo é uma espécie de extensão. Mas eu o vejo, ou apenas tenho a impressão de vê-lo? Só tu mo demonstrarás, ó Luz, ó Verdade!

## CAPÍTULO XXIV

### O tempo, medida do movimento

 Queres que eu aprove a quem diz que o tempo é o movimento de um corpo? Não, não aprovo. Sei que não há corpo que não se mova no tempo: tu mesmo o afirmas. Mas não acredito que o movimento de um corpo seja o tempo; isso nunca ouvi, e nem tu o dizes. Quando um corpo se move, sirvo-me do tempo para medir a duração de seu movimento do começo ao fim. Se não vejo o começo, e percebo seu movimento sem ver seu fim, só posso medi-lo do momento em que observo o corpo mover-se até o momento em que já não o vejo. Se o vejo por muito tempo, apenas posso afirmar que a duração de seu movimento é longa, mas não posso dizer quanto é longa, porque só determinamos o valor de uma duração comparando-a. Dizemos, por exemplo: "isso durou tanto quanto aquilo, ou essa duração é o dobro daquela", semelhantes. Se podemos notar o ponto do espaço onde se inicia um movimento, e o ponto de chegada, ou suas partes, se ele se movesse em círculo, poderíamos dizer quanto tempo levou para ir de um ponto a outro o movimento do corpo ou dessas partes.

 Assim, o movimento de um corpo é diferente da medida de sua duração; que não vê, pois, a qual dessas coisas se deve chamar de tempo? Se um corpo se move de forma irregular, e outras vezes se detém, ora, é o tempo que nos permite medir, não apenas seu movimento, mas também seu repouso, e afirmar: "Ficou em repouso por tanto tempo quanto em movimento – ou qualquer outro intervalo que tenhamos calculado ou estimado aproximadamente". O tempo não é pois a mesma coisa que o movimento.

## CAPÍTULO XXV

### Prece

 Confesso-te, Senhor, que ainda não sei o que é tempo. E torno a confessar, Senhor, eu o sei, que digo estas coisas no tempo, e que de há muito estou falando do tempo, e que esse muito também não seria o que é senão pela duração do tempo. Mas como posso saber isto, se desconheço o que é o tempo? Talvez eu ignore a arte de exprimir o que sei. Ai de mim, que não sei nem mesmo o que ignoro! Eis-me diante de ti, meu Deus, tu vês que não minto e que falo de coração. Acenderás minha candeia, Senhor meu Deus, e iluminarás minhas trevas.

## CAPÍTULO XXVI

### O tempo, distensão da alma

 Acaso minha alma não foi sincera confessando-te que posso medir o tempo? De fato, meu Deus, eu o meço, e não sei o que meço. Meço o movimento dos corpos com o auxílio do tempo, e não poderei medir o tempo do mesmo modo? E poderia eu medir o movimento de um corpo, sua duração, o tempo que gasta para ir de um lugar a outro, sem medir o tempo em que se move?

 Mas o tempo em si, com que o poderei medir? É com um tempo mais curto que medimos um mais longo, como medimos uma viga com o côvado? Do mesmo modo medimos a duração de uma sílaba longa com a duração de uma sílaba breve, dizendo que uma é o dobro da outra. Do mesmo modo medimos a extensão de um poema pelo número de versos, a extensão dos versos pelo número de pés, a extensão dos pés pelo número de sílabas, a duração das sílabas longas pela duração das breves. Não é pelas páginas dos livros que fazemos esse cálculo, o que seria medir o espaço e não o tempo. Conforme as palavras passam e as pronunciamos, dizemos: "Eis um poema longo, porque se compõe de tantos versos; esses versos são longos, porque são formados de tantos pés; esses pés são longos, porque se estendem por tantas sílabas; esta sílaba é longa, porque é o dobro de uma breve".

 Todavia, não conseguimos uma medida exata do tempo; pode acontecer que um verso mais curto, se pronunciado mais lentamente, se estenda por mais tempo que um verso mais longo, recitado depressa. O mesmo acontece com um poema, um pé, uma sílaba.

 Por esse motivo é que o tempo me pareceu não ser nada mais que uma extensão. Mas extensão de que? Não saberia dize-lo ao certo; seria de admirar que não fosse extensão da própria alma. portanto, dize-me , meu Deus, que é o que meço quando digo um tanto vagamente: "Este tempo é mais longo do que aquele" – ou mais exatamente: "Este tempo é o dobro daquele? – Meço o tempo, eu o sei; mas não o futuro, que ainda não existe, nem o presente, porque não tem duração, nem o passado, porque não existe mais. Que meço eu então? Acaso o tempo que passa, e não o tempo passado, como disse acima?

## CAPÍTULO XXVII

### A medida do passado

 Insiste, ó minha alma, e presta grande atenção: Deus é nosso apoio. Ele é que nos criou, e não nós. Olha para lá, par o lado onde desponta a aurora da verdade.

 Eis, por exemplo, que uma voz corpórea começa a ressoar, e soa, e continua vibrando e deixar de soar; faz-se silencio, a voz calou-se, passou e deixa de existir. Antes de soar, era futura, e não podia ser medida, pois ainda não existia; e agora também não o pode, porque já não existe mais. Só poderíamos medi-la quando ressoava, porque então havia o que medir. Mas mesmo então não era estável, porque vinha e passava. E não seria isso que a tornava mensurável? Porque enquanto passava, estendia-se por um espaço de tempo que a tornava capaz de ser medida, porque o presente não tem duração alguma.

 Admitamos que foi possível medi-la; eis, suponhamos agora, uma outra voz que começa a se fazer ouvir; ela vibra de modo contínuo, sem nenhuma interrupção. Meçamo-la enquanto vibra, porque no momento em que deixar de vibrar será passada, e já não poderá ser medida. Meçamola, então, e avaliemos sua duração. Mas ela vibra ainda, e só pode ser medida depois do início do fenômeno, quando começa a vibrar, até seu fim, quando deixa de vibrar. Porque é precisamente o intervalo que separa um começo de um fim que nós medimos. Por isso, uma voz, que ainda não terminou de ressoar, escapa à medida: é impossível dizer se ela será longa ou breve, se é igual a outra, simples ou dupla, ou qual a relação que tem com essa outra. Mas quando terminar de soar, deixará de existir. Como, então, poderemos medi-la?

 De fato, medimos o tempo; mas não o tempo que ainda não existe, nem o que já não existe, nem o que não tem duração alguma, nem o que está passando. Não é, portanto, nem o futuro, nem o passado, nem o presente, nem o que não tem limites que medimos: e, contudo, medimos o tempo.

Deus creator omnium (Deus, criador de tudo quanto existe): este verso é formado de oito sílabas, alternativamente breves e longas. As quatro breves, a primeira, a terceira, a quinta e a sétima – são simples em relação às quatro longas: a segunda, a quarta, a sexta e a oitava. Cada sílaba longa tem uma duração duas vezes maior que a breve. Eu pronuncio e percebo que é assim pelo testemunho claro de meus sentidos. E por esta testemunho que é fidedigno, meço uma longa por uma breve, e noto que ela a contém duas vezes.

 Mas como uma sílaba só se faz ouvir depois da outra, se a breve vem primeiro, e a longa a seguir, como poderei reter a breve, como aplicá-la à longa, para compará-las e ver que esta contém aquela duas vezes, uma vez que a longa só começa a soar quando a breve deixou de se ouvir? E a própria sílaba longa, não me é possível medi-la enquanto está soando, porque eu só poderia medi-la quando se calasse. Mas ela, ao terminar, passou. Que é pois que eu meço? Onde está a breve, que seria minha medida? Onde está a longa, que meço? Apenas vibraram, foramse, passaram, e não existem mais. Não obstante, eu as meço e respondo com a segurança que me pode dar um sentido bem educado, que evidentemente uma é de duração simples e a outra dupla. Mas só poderei fazê-lo depois que ambas passaram e terminaram.

 Logo, eu não meço as sílabas, que não existem mais, mas algo que permanece gravado em minha memória.

 É em ti, meu espírito, que meço o tempo. Não me objetes nada, pois é assim. Não te perturbes com as ondas desordenadas de tuas emoções. É em ti, digo, que meço o tempo. A impressão que em ti gravam as coisas em sua passagem, perduram ainda depois que os fatos passam. O que eu meço é esta impressão presente, e não as vibrações que a produziram e se foram. É ela que meço quando meço o tempo. Portanto, ou essa impressão é o tempo, ou eu não meço o tempo.

 Mas quando medimos silêncios, e dizemos que o silêncio teve a mesma duração que certa palavra, não estamos dirigindo nossa atenção para a medida dessa palavra, como se ainda pudéssemos ouvi-la, para podermos avaliar no espaço de tempo, o intervalo do silêncio? Com efeito, por vezes, sem abrir a boca ou dizer palavra, fazemos mentalmente poemas, versos, discursos; avaliamos a extensão do seu movimento, sua duração, uns em relação aos outros, exatamente como se usássemos a voz.

 Se alguém quisesse pronunciar um som prolongado, e regular antecipadamente, em pensamento, sua duração, estima em silêncio a medida dessa duração e, confiando à memória, começa a emitir o som, que vibra até atingir o limite fixado. Ou melhor: esse som vibrou e vibrará, porque a parte que passou soou; a que ainda resta, soará e chegará a seu fim. A atenção presente vai lançando o futuro para o passado, e o passado cresce com a diminuição do futuro, até que, esgotado o futuro, não haja mais que passado.

## CAPÍTULO XXVIII

### A medida do futuro

 Mas o futuro, que ainda não existe, como pode diminuir ou consumir-se? E o passado, que já não existe, como pode aumentar, a não se por existirem no espírito, autor dessas três transformações: a espera, a atenção e a lembrança? O objeto de sua espera passa pela atenção e se transforma em lembrança.

 De fato, quem ousará negar que o futuro ainda não existe? Todavia, a espera do futuro já está no espírito. E quem poderá negar que o passado não mais existe? Contudo, a lembrança do passado ainda está no espírito. Enfim, haverá alguém que negue que o presente carece de duração, porque é um instante que passa? No entanto, perdura a atenção, diante da qual o seu objeto presente continuamente se retira. O futuro, portanto, não é longo, porque não existe. Um futuro longo seria apenas uma longa espera do futuro. nem pode ser longo o passado, que também não existe. Um passado longo é uma longa lembrança do passado.

 Digamos que eu queira cantar uma canção que conheço: antes de iniciar, minha expectativa se estende pela melodia como um todo. Quando começo, tudo o que vira passado é armazenada na memória. A atividade de meu espírito se divide em memória, onde guardo o que já disse, e em expectativa em relação ao que vou dizer. Contudo, a atenção está presente, e por seu intermédio o futuro se torna passado. Quanto mais se aproxima o fim da canção, tanto menos se torna a expectativa e tanto maior a memória, até que aquela se esgota e a ação cumprida passa inteiramente para a memória.

 E o que acontece com a canção tomada em seu conjunto, também ocorre com cada uma de suas partes, com cada sílaba; e também acontece com uma ação mais longa, da qual essa melodia talvez faça parte. O mesmo acontece com toda a vida do homem, da qual seus atos são partes. Sucede, enfim, com toda a história dos filhos do homem, da qual cada existência é apenas uma parte.

## CAPÍTULO XXIX

### A eternidade de Deus

 Mas porque tua misericórdia é superior a todas as vidas, e eis que minha vida não é mais que distensão, e tua destra me acolheu em meu Senhor, o Filho do homem, mediador entre ti, que és uno, e nós, que somos muitos e vivemos divididos por diversas paixões. Assim. Por ele me unirei àquele, que por ele se uniu a nós, e liberto dos antigos dias, recolherei meu ser seguindo tua Unidade. Esquecido do passado, sem me preocupar com as coisas futuras e transitórias, atento apenas àquilo que é eterno, não com dispersão mas com todas as minhas forças buscarei a palma da vocação celeste, onde ouvirei a voz de teu louvor, e onde contemplarei tua alegria, que não conhece futuro nem passado.

 Agora, porém, meus anos transcorrem em lamentos, e tu, meu consolo, ó Senhor, meu Pai, tu és eterno. Mas eu me dispersei no tempo, cuja ordem ignoro; tumultuosas vicissitudes despedaçam meus pensamentos, entranhas de minha alma, até o dia em que, purificado pelo fogo de teu amor, me una a ti.

## CAPÍTULO XXX

### Deus e o tempo

 E repousarei imutável em ti, em tua verdade, na minha forma. não mais tolerarei as perguntas das pessoas que, pela enfermidade que é a pena de seu pecado, tem mais sede de saber do que lhes permite sua capacidade, que dizem: "Que fazia Deus antes de criar o céu e a terra?" – ou ainda: "Como lhe veio a idéia de criar algo, se antes nunca fizera nada" – Concedelhes, Senhor, que reflitam no que dizem, que compreendam que não se pode falar nunca onde não há tempo. Quando se diz que alguém nunca fez nada, que se quer dizer senão que esse tal nada fez em tempo algum? Que eles compreendam que não pode existir tempo na ausência da criação, e deixem de semelhantes falácias.

 Que também atentem para o que têm diante de si, para compreender que tu, antes de todos os tempos, és o Criador eterno de todos os tempos, e que nenhum tempo te é coeterno, nem criatura alguma, embora algumas estejam acima dos tempos (Agostinho se refere aqui, aos anjos e demônios).

## CAPÍTULO XXXI

### Conclusão

 Senhor, meu Deus, que abismos profundos os de teus segredos, e quão longe deles me levaram as conseqüências de meus pecados! Cura meus olhos, para que eu me alegre com tua luz!

 Se houvesse de fato um espírito de ciência e de presciência tão grandes para conhecer o passado e o futuro, como conheço qualquer canto popular, esse espírito nos encheria de extraordinária admiração e espanto. Nada, com efeito, lhe seria oculto no passado e nos séculos vindouros, exatamente como, ao entoar essa melodia, sei tudo o que cantei desde o começo, e tudo o que falta cantar até o fim. Mas longe de mim a idéia de identificar um tal conhecimento àquele que tens de todas as coisas futuras e passadas, ó Criador do Universo, Criador dos espíritos e dos corpos. Tua ciência é incomparavelmente mais admirável e mais misteriosa. Porque aquele que canta ou escuta uma melodia conhecida, dividido entre a expectativa das notas por vir e a lembrança das notas passadas, passa por impressões diferentes. Mas contigo não se dá nada semelhante, tu que és imutável e eterno, Criador verdadeiramente eterno dos espíritos. Como no princípio, conheceste o céu e a terra, sem que teu espírito mudasse seu saber, assim criaste o céu e a terra, sem que tua ação passasse por etapas distintas. Que aquele que compreende isto te louve, assim como o que não compreende. Oh! Como és sublime! E os de coração humildes são tua morada! Levantas os que caíram, e os que graças a ti continuam eretos, não caem nunca.

# LIVRO DÉCIMO-SEGUNDO

## CAPÍTULO I

### Prece

 Inquieto está meu coração, Senhor, quando, na miséria de minha vida é atingido pelas palavras de tua Escritura Sagrada. Por isso, geralmente, a abundância de palavras é testemunho da pobreza da inteligência humana. A busca usa mais palavras que a descoberta; é maior o pedir que o obter; a mão que bate cansa-se mais do que a mão que recebe. Mas nós temos tua promessa: quem a destruirá? Se Deus está conosco, quem será contra nós? Pedi, e recebereis; procurai e encontrareis; batei, e abrir-se-vos-á. Porque todo o que pede recebe, todo o que procura encontra, e a todo o que bate se lhe abrirá.

São promessas tuas. E quem temerá ser enganado, quando a promessa vem da Verdade?

## CAPÍTULO II

### O céu do céu

 Que a humildade de minha língua confesse à tua grandeza que criaste o céu e a terra; este céu que vejo, esta terra que piso, e de onde tiraste a terra que trago em mim. sim, criaste tudo isto.

 Mas, Senhor, onde está o céu de que nos falou a voz do salmista: "O céu do céu pertence ao Senhor, mas ele deu a terra aos filhos dos homens?" – Onde está esse céu que não vemos, e diante do qual tudo o que vemos é apenas terra?

 De fato, todo este mundo material, cuja base é a terra, embora não seja inteiramente belo em toda parte, recebeu até em seus últimos elementos, uma aparência atraente. Mas, comparado com esse céu do céu, o céu de nossa terra também não passa de terra. Por isso, não é absurdo chamar de terra esses dois grandes corpos visíveis, se os compararmos a esse céu misterioso que pertence ao Senhor, e não aos filhos dos homens.

## CAPÍTULO III

### As trevas sobre o abismo

 Mas esta terra era invisível e informe, era um profundo abismo acima do qual não pairava nenhuma luz, pois não tinha nenhuma forma. Por isso inspiraste estas palavras: "As trevas cobriam o abismo". – Mas que são trevas, senão ausência da luz? De fato, se então existisse, onde estaria a luz senão sobre a terra, para iluminá-la? Mas como a luz ainda não existia, o que era a presença das trevas, senão a ausência da luz? As trevas reinavam sobre o abismo porque a luz não existia, do mesmo modo que onde não há ruído reina o silêncio. E que significa reinar o silêncio, senão falta de som?

 Não ensinaste, Senhor, à alma que a ti se confessa? Não me ensinaste, Senhor, que antes de receber de ti forma e figura esta matéria informe, não existia nada, nem cor, nem figura, nem corpo, nem espírito? Não era um nada absoluto, mas massa informe, sem figura alguma.

## CAPÍTULO IV

### A matéria informe

 Que nome darei a esta matéria, como sugerir sua idéia às inteligências mais curtas, senão usando um termo de uso corrente? O que se pode encontrar no mundo que seja mais parecido com essa ausência total de forma, que a terra e o abismo? Colocados no mais baixo grau da criação, eles não têm a beleza dos corpos que no alto brilham de luz fulgurante.

 Por que, então, não aceitar que essa matéria informe, que criaste sem beleza para com ela moldar um mundo cheio de beleza, fosse comodamente designada aos homens pelos termos de terra invisível e informe?

## CAPÍTULO V

### Sua natureza

 Assim, quando o pensamento indaga o que nossos sentidos podem colher a respeito dessa matéria, responde a si mesmo: "Não é nem forma inteligível, como a vida, como a justiça, porque é a matéria corpórea, nem uma forma sensível, porque nada há que se possa ver ou perceber no que é invisível e sem forma". – Quando o pensamento humano fala desse modo, procura conhecê-la ignorando-a, ou ignorá-la conhecendo-a?

## CAPÍTULO VI

### Em que consiste

 Senhor, se pela boca e pela pena devo confessar-te o que me ensinaste sobre essa matéria, eu direi que outrora ouvi falar, sem nada compreender, a respeito desse nome por pessoas que também não entendiam. Tentei imaginá-la sob as formas mais diversas, e não o consegui. Meu espírito revolvia confusamente formas feias e horríveis, mas enfim sempre formas. Chamava de informe essa matéria, não porque a imaginasse sem forma, mas por tê-las tão estranhas e bizarras que, se a visse, afastaria meus sentidos e confundiria minha fraqueza de homem.

 Por isso, o que eu concebia era informe, não por ausência de qualquer forma, mas por comparação com formas mais belas. A reta razão me persuadia; se eu quisesse conceber algo absolutamente informe, a suprimir nele todo resquício de forma, mas eu não conseguia; pareciame bem mais fácil negar a existência do que estava privado de toda forma, do que conceber um ser a meio termo entre a forma e o nada, e que não fosse nem forma, nem nada, um ser informe, um quase nada.

 Então, minha inteligência deixou de inquirir minha imaginação, cheia de imagens de formas corpóreas, que ela variava e mudada a seu talante. Fixei a atenção nos próprios corpos, analisei mais profundamente essa mutabilidade pela qual eles cessam de ser o que eram e começam a ser o que não eram. Suspeitei que essa transição de uma forma para outra se fazia por meio de algo informe, e não do nada absoluto.

 Mas meu interesse era saber, e não apenas supor; e se minha voz e minha pena te confessassem em detalhes as soluções deste problema que me inspiraste, qual de meus leitores teria paciência para me entender? Contudo, meu coração não deixará de te honrar com cânticos de louvor por essas inspirações, por aquilo que não têm palavras capazes de exprimir.

 É a própria mutabilidade das coisas que é susceptível de assumir todas as formas em que se transfiguram as coisas mutáveis. E o que é essa mutabilidade? É espírito? Será talvez corpo? Seria uma espécie de espírito ou de corpo? Se pudéssemos dizer: um nada que é algo, ou o que é e não é, eu a chamaria assim. No entanto, era necessário que ela existisse de alguma maneira, para tomar essas formas visíveis e complexas.

## CAPÍTULO VII

### A criação do nada

 Mas de onde essa matéria tirava seu ser, senão de ti, por quem existe toda e qualquer coisa? Quanto mais difere de ti uma coisa, mais longe de ti está – e não se trata de distância espacial.

 Portanto, és tu, Senhor que não mudas ao sabor das circunstâncias, mas que és sempre o mesmo, o mesmo e o mesmo, santo e santo e santo, Senhor, Deus Todo-Poderoso, és tu, Senhor, que no princípio, que vem de ti, em tua Sabedoria, nascida de tua substância, fizeste algo do nada. Criaste o céu e a terra, e isso não com tua substância, pois nesse caso, tua criação seria igual a teu Filho unigênito e, por isso, iguais a ti mesmo. E não seria justo que o que não é da tua substância, fosse igual a ti.

 Mas fora de ti nada existia com que pudesses fazer o céu e a terra, ó Trindade una, Unidade trina. Por isso criaste do nada o céu e a terra; duas realidades, uma imensa e outra pequena. Porque és Todo-Poderoso e bom, e só podes criar coisas boas: o grande céu e a pequena terra.

 Fora de ti nada havia, e desse nada fizeste o céu e a terra, tuas duas obras: uma próxima de ti, a outra próxima do nada. Uma que tem acima de si apenas a ti mesmo, e outra que nada tem inferior a ela.

## CAPÍTULO VIII

### A terra invisível

 Mas o céu do céu pertence a ti, Senhor; a terra, que deste aos filhos dos homens para que a vissem e tocassem, não era tal como agora e vemos e tocamos. Era invisível e informe: um abismo sobre o qual não havia luz. As trevas se estendiam sobre o abismo – isto é: mais profundas que o abismo. Esse abismo das águas, agora visíveis, tem até em suas profundezas uma luminosidade, perceptível aos peixes e aos animais que se arrastam no fundo. Mas tudo isso era quase o nada, sendo ainda completamente informe; porém já era um ser apto a receber uma forma.

 Senhor, criaste o mundo de uma matéria sem forma; do nada fizeste este quase nada de onde tiraste as grandes coisas que admiramos, nós, os filhos dos homens. Porque este céu corpóreo é de fato admirável, este firmamento que separa uma água de outra, que criaste no segundo dia, depois da luz, dizendo: "Faça-se – e assim se fez". Chamaste a este firmamento de céu: o céu desta terra e deste mar que criaste no terceiro dia, dando forma visível à matéria informe, criado por ti antes de todos os dias.

 Já havias criado outro céu antes de haver dia; mas era o céu do céu, porque no princípio criaste o céu e a terra. Quanto a esta mesma terra, nada mais era que matéria informe, sendo invisível, caótica e as trevas reinando sobre o abismo. É desta terra invisível, caótica, desta massa informe, deste quase nada, que formaste todas as coisas de que é formado e não formado este mundo mutável, domínio da transformação, que torna possíveis a percepção e a medida do tempo. Porque o tempo é feito da mudança das coisas, de variações e transformações das formas, cuja matéria é esta terra invisível, de que falei acima.

## CAPÍTULO IX

### A criação do tempo

 Por isso, o Espírito que instruiu teu servo, quando relata que no princípio criaste o céu e a terra, cala-se sobre o tempo, guarda silêncio sobre os dias. De fato, o céu do céu, que fizeste no começo, é de alguma maneira uma criatura racional que, mesmo sem ser coeterna contigo, ó Trindade, participava todavia de tua eternidade. A doçura de te contemplar beatamente a mantém imóvel e unida a ti sem movimento, e desde sua criação escapa às vicissitudes fugazes do tempo. Porém, esta massa informe, esta terra invisível, este caos, tu não o enumeraste entre os dias; de fato, onde não há forma nem ordem, nada vem, nada passa e, portanto não pode haver nem dias, nem sucessão de espaços temporais.

## CAPÍTULO X

### Invocação à verdade

 Ó Verdade, luz de meu coração, faze com que se calem as minhas trevas. Deixei-me cair nelas e fiquei às escuras; mas, mesmo do fundo desse abismo, eu te amei ardentemente. Andei, errante, mas lembrei de ti. Ouvi tua voz atrás de mim, que me exortava a que voltasse; mas dificilmente podia escutá-la, por causa do tumulto de minha alma. e agora, eis que, ardente e anelante, volto à tua fonte. Que ninguém mo impeça; beberei de sua água, e assim viverei. Que não seja eu minha própria vida! Vivi mal por minha culpa, e fui a causa de minha morte. Em ti eu revivo! Fala-me, ensina-me. Creio em teus livros, e tuas palavras encerram profundos mistérios.

## CAPÍTULO XI

### As criaturas e o criador

 Já me disseste, Senhor, com voz forte ao ouvido de minha alma, que és eterno, e que só tu possuis a imortalidade, porque não mudas nem de forma, nem de movimento; tua vontade não varia conforme o tempo, pois a vontade mutável não é imortal. Esta verdade me é clara em tua presença. Peço-te que ela se torne para mim cada vez mais clara, e sob tuas asas eu me mantenha atento a esta evidência.

 Também disseste, Senhor, com voz forte ao ouvido de minha alma, que todas as naturezas, todas as substâncias que não são o que és, mas que existem, tu as criaste; que só o nada não provém de ti, assim como o movimento de uma vontade que se afasta de ti, Ser supremo. Enfim, que nenhum pecado te causa dano, nem perturba a ordem de teu império, superior ou inferior. Essa verdade é clara para mim em tua presença. Peço-te que se torne para mim cada vez mais clara, e que sob tuas asas eu me mantenha atento a esta evidência.

 Também disseste, Senhor, com voz forte ao ouvido de minha alma, que essa criatura, que tem em ti seu único deleite, não te é coeterna; que goza de ti em união casta e duradoura, sem nunca trair em parte alguma sua natureza mutável; que, se conserva sempre em tua presença e unida a ti com todo seu amor, não tem de esperar futuro, nem que recordar passado, imutável pois com o tempo e o vir a ser. Feliz criatura, se existe, por participar de tua felicidade, feliz de ser perenemente habitada e iluminada por ti! Nada encontro que melhor se possa chamar de céu de céu que pertence ao Senhor, que a esta habitação de tua divindade, que contempla tuas delícias sem que nada a afaste para outras partes. Puro espírito, intimamente ligado por um elo de paz com esses santos, espíritos, cidadãos de tua cidade, situada no céu e acima do nosso céu.

 Diante disso, possa a alma, cuja peregrinação afastou de ti, compreender se já tem sede de ti, se seu pranto se tornou seu pão, quando todos os dias lhe dizem: Onde está teu Deus? – se ela deseja apenas habitar em tua morada todos os dias de sua vida. E que é sua vida, senão tu? Que são teus dias, senão tua eternidade, como teus anos que não passam, porque és sempre o mesmo? Por isso, digo, faça compreender à alma, se possível, como tua eternidade transcende todos os temos. Tua morada, que nunca se afastou de ti, embora não te tendo coeterna, graças à sua incessante e ininterrupta união contigo, não padece de vicissitudes do tempo. Essa verdade é clara para mim em tua presença. Peço-te que se torne para mim cada vez mais clara, e que sob tuas asas eu me mantenha atento a esta evidência.

 Vejo, de fato, não sei que matéria informe nas transformações das coisas últimas e ínfimas. Mas quem dirá, a não ser o insensato, cujo espírito vagueia entre quimeras, à mercê de seus fantasmas, quem, salvo este, ousaria afirmar que, se toda forma fosse destruída, abolida, restando apenas a matéria informe, graças à qual as coisas se transformam e passam de uma forma para outra, ela poderia produzir as vicissitudes do tempo? Não, tal hipótese é absolutamente impossível, pois sem variedade de movimentos não há tempo; e não há variedade onde não há forma.

## CAPÍTULO XII

### A criação e a eternidade

 Bem consideradas estas coisas, por graça tua, meu Deus, e como me incitasse a bater, e como me abres quando bato, encontro duas criações tuas não afetadas pelo tempo, embora nenhuma delas te seja coeterna. Uma, que criaste tão perfeita que jamais deixa de te contemplar, que não sofre nenhuma mudança, embora de natureza mutável, e goza de tua eternidade e de tua imutabilidade. Outra, informe, a ponto de lhe ser impossível passar de uma forma para outra, quer no movimento, quer no repouso, e, portanto, incapaz de estar sujeito ao tempo. Mas tu não a deixaste informe pois, antes de qualquer dia, fizeste no principio o céu e a terra, as duas obras de que falava.

 Mas a terra era invisível e informe, e as trevas reinavam sobre o abismo. Por essas palavras, a Escritura sugere a idéia de algo informe, para ensinar aos poucos aos espíritos que não podem conceber que a falta absoluta de forma não se confunde com o nada. É dessa massa informe que deveria ser criado um segundo céu, uma terra visível, ordenada, a água cristalina, e enfim tudo o que foi feito na criação, de acordo com a tradição das Escrituras, em dias sucessivos. E essa obra é tal que, devido à mudanças regulares de seus movimentos e formas, está sujeita às vicissitudes do tempo.

## CAPÍTULO XIII

### O céu e a terra em Gênesis

 "No princípio criou Deus o céu e a terra. A terra era invisível e informe, e as trevas se estendiam sobre o abismo." Ouço estas palavras, meu Deus, e não encontrando menção do dia em que criaste essas coisas, concluo dessa omissão que se trata do céu do céu, do céu intelectual, onde a inteligência conhece simultaneamente e não por partes; não por enigma, ou como um espelho, mas por inteiro, em plena luz, face a face; conhece não ora isto, ora aquilo, mas, como disse, simultaneamente, sem a seqüência temporal. Concluo também que se trata da terra invisível, informe, estranha às vicissitudes do tempo, que ora causam isto, ora aquilo, pois onde não há forma não pode haver isto ou aquilo.

 Dessas realidades, uma de forma acabada desde o início, a outra absolutamente informe, o céu, isto é: o céu do céu, e a terra, isto é: terra invisível e informe, é bem a propósito delas que tua Escritura diz, sem mencionar o dia: "No princípio criou Deus o céu e a terra". E acrescenta imediatamente de que terra se trata. E, indicando que no segundo dia foi criado o firmamento, que foi chamado de céu, dá a entender também de que céu falara antes, sem precisar o dia.

## CAPÍTULO XIV

### A profundidade das Escrituras

 Admirável profundidade das tuas palavras! Sua aparência nos acaricia, como se acariciam as crianças! Sim, admirável profundidade, meu Deus, admirável profundidade! O meditá-las causa um arrepio sagrado, tremor de respeito, estremecimento de amor. Odeio com veemência seus inimigos. Oh! Se pudesses fazê-los morrer sob teu gládio de dois gumes, para que não tivessem mais inimigos! Desejaria que eles morressem para si mesmos, e que vivessem só para ti.

 Mas há outros que não censuram mas, pelo contrário, exaltam o livro de Gênesis, e que dizem: "Não é isto que quis dizer por essas palavras o Espírito de Deus, que as inspirou a teu servo Moisés. Não, o que ele quis dizer não é o que dizes, mas o que nós dizemos" – Eis, ó Deus de todos nós, o que eu lhes respondo: sê nosso árbitro.

## CAPÍTULO XV

### O que dizem seus inimigos

 Ousareis apontar como falso o que, com voz clara, a Verdade disse ao ouvido de minha alma sobre a verdadeira eternidade do Criador: ou seja, que sua substância não varia no tempo, e que sua vontade se confunde com sua substância? E que por isso ele não quer ora isto, ora aquilo, mas quer o que sempre quis, simultaneamente e para sempre. Sua vontade não se exerce repetidas vezes, não se propõe ora esta, ora aquela finalidade, não quer o que antes não queria, nem deixa de querer o que antes queria, uma vez que tal vontade seria mutável, e o que é mutável não é eterno; ora, nosso Deus é eterno.

 Tereis por falazes as palavras da Verdade faladas ao ouvido de minha alma: que a espera das coisas futuras se torna contemplação, quando presentes, e que depois se transforma em memória, quando passadas? Que todo pensamento que varia assim é mutável, e que nada do que é mutável é eterno? Ora, nosso Deus é eterno. E, reunindo e condensando estas verdades, deduzo que meu Deus, o Deus eterno, não criou o mundo por um novo ato de volição, e que sua ciência não admite nada que seja transitório.

 Que respondeis, então, meus contraditores? Será isso falso? – Não, dizem eles. – Mas então? Será que erro afirmar que toda criatura que tem forma, que toda matéria susceptível de têla recebe seu ser somente daquele que é Bondade soberana, porque ele é Ente supremo? – Também não o negamos. – Então, que negais? Negais talvez que haja uma criatura sublime, unida por um casto amor ao Deus verdadeiro e eterno, sem lhe ser coeterna, que dele não se separa nem se desvia para as várias vicissitudes do tempo, mas, pelo contrário, repousa apenas em sua contemplação? Com efeito, te ama tanto quanto pedes, ó Deus, e mostras a ela tua face e a sacias, e ela jamais se afasta de ti, nem rumo a sim mesma. Ela é a morada de Deus, não terrena, e nem formada de substância do céu material, habitáculo espiritual que participa de tua eternidade, imaculada por toda a eternidade. Tu a fundaste pelos séculos dos séculos; estabeleceste uma ordem, que não passará jamais. Contudo, essa lei não é coeterna, porque teve princípio, foi criada.

 Não encontramos o tempo antes dessa criação, porque a sabedoria foi a primeira de todas as tuas criações. E é claro que não me refiro à Sabedoria da qual és Pai, ó nosso Deus, e que te é perfeitamente igual e coeterna, por quem todas as coisas foram criadas, e que é o princípio em que criaste o céu e a terra; refiro-me à sabedoria criada, dessa essência intelectual que, pela contemplação da luz, também é luz; a esta, embora criada, também chamamos de sabedoria. E assim como a luz que ilumina difere da luz refletida, a sabedoria criada difere da sabedoria incriada; e a justiça justificante difere da justiça nascida da justificação. Nós fomos também chamados de tua justiça. Porque um de teus servos disse: "Para que, em Cristo, nos tornemos a justiça de Deus". – Há portanto, uma sabedoria criada antes de todas as coisas, e ela foi criada como espírito racional e inteligente, que habita tua cidade santa, nossa mãe, que está no alto, livre e eterna nos céus – e em que céus, senão aos céus dos céus, que te louvam, esse céu que pertence ao Senhor? – Se não encontramos o tempo antes dessa sabedoria, é porque ela precede à criação do tempo, tendo sido criada primeiro, mas antes dela há a eternidade de seu Criador, de quem recebeu sua origem, e não do tempo, pois este ainda não existia, mas pela sua condição de criatura criada.

 Ela procede pois, de ti, nosso Deus, embora seja de essência absolutamente diversa da tua. Não encontramos nenhum tempo, não apenas antes dela, mas nela própria, porque ela é capaz de contemplar sempre tua face sem jamais se apartar de ti, sendo incólume às mudanças e às variações. Contudo, há nela certa mutabilidade que poderia torná-la tenebrosa e gélida, não fosse o grande amor que a une a ti e que brilha como meridiana luz e calor.

 Ó morada luminosa e pura! Amei tua beleza e o lugar onde mora a glória de meu Senhor, teu criador e possuidor. Por ti eu suspiro durante meu exílio! Peço àquele que te criou que me possua também em ti, pois também me criou. Errei como ovelha desgarrada, mas espero ser reconduzido a ti nos ombros de meu pastor, teu arquiteto.

 Que me respondeis a isto, meus contraditores, vós que, também considerais Moisés um servo piedoso de Deus, e seus livros como oráculos do Espírito Santo? Não será esta a casa de Deus que, sem lhe ser coeterna, é contudo, á sua maneira, eterna nos céus? Em vão buscais aí as vicissitudes do tempo, pois não as encontrareis, uma vez que ela transcende toda extensão, toda volubilidade do tempo, e sua felicidade é estar intimamente unida a Deus para sempre.

– Assim é – dizem eles.

 Mas então, qual das verdades que meu coração proclamou diante de Deus, quando escutava em meu íntimo a voz que canta sal glória, podeis apontar como falsa? O que disse sobre matéria informe, na qual não podia haver ordem por carecer de forma? Mas onde não havia ordem não podia haver vicissitude de tempo; mas esse quase nada, enquanto não era o nada absoluto, provinha certamente daquele de onde nasce tudo o que, de algum modo, existe.

– Tampouco negamos isto – dizem eles.

## CAPÍTULO XVI

### Outros adversários das Escrituras

 Quero discutir diante de ti apenas com os que reconhecem por verdadeiras as afirmações que tua verdade revelou à minha inteligência. Os que o negam, que ladrem quanto quiserem, até ficar roucos. Tentarei persuadi-los a que se acalmem, e dêem acesso em seus corações à tua palavra. Se não o quiserem e me repelirem, peço-te, meu Deus, que não te cales, não te afastes de mim. fala com verdade em meu coração, porque só tu podes falar assim. E eu os deixarei fora, soprando o pó e levantando terra contra os próprios olhos. Retirar-me-ei em mim mesmo, levantando a ti cânticos de amor, soluçando altos gemidos durante meu exílio, lembrando-me de Jerusalém, voltando para ela meu coração – Jerusalém, minha pátria e minha mãe – e para ti, que reinas sobre ela, seu pai, sua luz, seu tutor, seu esposo, suas castas e grandes delícias, sua firme alegria, enfim, todos seus bens inefáveis, porque és o único, soberano e verdadeiro Bem. Não me apartarei de ti até que reúnas todas as partes dispersas e deformadas do meu ser na paz dessa mãe muito amada, onde estão as primícias de meu espírito, e de onde me vêm todas as certezas, e nela me reformes e confirmes por toda a eternidade, ó meu Deus, minha misericórdia.

 Àqueles que, sem negar essas verdades, respeitando tua Escritura Sagrada, obra do piedoso Moisés, e reconhecendo nela, conosco, a mais alta autoridade a seguir, e contudo nos opõem alguma objeções, dirijo estas palavras: "Tu, que és nosso Deus, serás árbitro entre minhas confissões e suas objeções".

## CAPÍTULO XVII

### Opiniões diversas sobre o céu e a terra

 Eles dizem: "Sem dúvida, isso é verdade, mas não era isso que Moisés queria exprimir quando, inspirado pelo Espírito Santo, escreveu: "No princípio criou Deus e céu e a terra" – Pela palavra céu, ele não quis significar essa criatura espiritual ou intelectual, que contempla eternamente a face de Deus; e pela palavra terra, uma matéria informe. – Que quis dizer então? – O que nós afirmamos – respondem – isso é o que Moisés quis dizer, e o que expressou naquelas palavras. – E que é que afirmais? – Pelas palavras céu e terra quis significar, em primeiro lugar, globalmente e de forma concisa, todo o mundo visível, para em seguida pormenorizar, enumerando os dias, ponto por ponto, esse conjunto que aprouve ao Espírito Santo designar com uma expressão global. O povo rude e carnal ao qual falava era constituído de homens tais que julgou conveniente dar-lhes a conhecer apenas as obras visíveis de Deus".

 Quanto a esta terra invisível e informe, a este abismo de trevas, com que, durante seis dias, foram sucessivamente criadas e ordenadas todas as coisas visíveis que são conhecidas de todos, eles concordam comigo em que se pode entender com isso, sem erro, essa matéria informe de que falei.

 Algum outro dirá, talvez, que a realidade invisível e visível não foi chamada impropriamente de céu e terra, e portanto, que o universo criado por Deus na sabedoria, isto é, no princípio, está compreendido sob esses dois termos. Porém as coisas não foram feitas da substância de Deus, mas do nada, e não se confundem com Deus, e nelas existe o princípio da mutabilidade, quer permaneçam como morada eterna de Deus, quer mudando-se como a alma e o corpo do homem. Por isso a matéria comum a todas as coisas invisíveis e visíveis, matéria ainda informe, mas susceptível de forma, e de onde se fariam o céu e a terra – em outras palavras, a criação invisível e visível – mas uma e outra tendo recebido forma, foi designada por essas expressões de terra invisível e informe, e de trevas reinando sobre o abismo. Com a seguinte distinção: por terra invisível e informe deve-se entender a matéria corpórea antes de ser qualificada pela forma; e por trevas reinando sobre o abismo, a matéria espiritual antes da restrição de sua, digamos, imoderada fluidez, e antes de ser iluminada pela sabedoria.

 Poderia alguém afirmar, se quisesse: Esses termos céu e terra não significam realidades perfeitas e acabadas, lá onde lemos: No princípio Deus criou o céu e a terra – mas um esboço ainda informe, uma matéria passível de receber forma e servir para a criação; nela já existiam, como que um embrião, sem distinção de formas e de qualidades, essas criaturas, uma espiritual, e outra material que, ordenadas como estão agora, são chamadas de céu e terra.

## CAPÍTULO XVIII

### Outras interpretações

 Ouço e considero todas essas teorias, mas não quero discutir por questões de palavras, o que não serve para nada, senão para a confusão dos ouvintes. Pelo contrário, a lei é boa para a edificação se dela se faz uso legítimo, porque sua finalidade é a caridade que nasce de um coração puro, de uma boa consciência e de uma fé não fingida. Nosso Mestre sabe quais dos dois preceitos em que resumiu toda a lei e os profetas. A mim, que observo com zelo tais preceitos, ó meu Deus, luz de meus olhos na escuridão, que me importa que possa que possa encontrar sentidos diferentes para essas palavras, se todos são verdadeiros? Que me interessa, digo eu, que outros compreendam o texto de Moisés de modo diferente do meu? Nós todos que o lemos procuramos indagar e compreender o pensamento do autor. E como o julgamos verídico, não ousamos admitir que ele pusesse dizer o que sabemos ou o que consideramos falso.

 Assim, nos esforços que fazemos para compreender, na Escritura Sagrada, a idéia que o escritor quis transmitir, onde está o mal se o leitor interpreta o sentido que tu, Luz de todas as inteligências sinceras, lhe fazes parecer verdadeiro, embora talvez não tenha sido este o pensamento do autor? E considerando que ele, pensando de outra maneira, só pensou verdades?

## CAPÍTULO XIX

### A verdade

 A verdade, Senhor é que criaste o céu e a terra. A verdade é que o princípio é tua Sabedoria, em que criaste todas as coisas. É também verdade que este mundo visível se compõe de duas grandes partes, o céu e a terra, síntese de todas as realidades criadas. É ainda verdade que tudo o que é mutável sugere a nosso pensamento a idéia de algo informe, susceptível de tomar forma, de mudar e de se transformar.

 A verdade é que um ser tão intimamente unido a uma forma mutável que, embora sujeito em si a mudanças, nunca se transforma, não está sujeito ao tempo. A verdade é que a massa sem forma, que é quase o nada, não pode conhecer as vicissitudes do tempo. A verdade é que a matéria que constitui uma coisa, se assim podemos falar, toma o nome dessa coisa, e portanto, podemos chamar de céu e de terra a essa massa informe com a qual foram feitos o céu e a terra. A verdade é que, de tudo o que recebeu forma, nada se aproxima mais do informe que a terra e o abismo. A verdade é que não apenas tudo o que foi criado e formado, mas ainda tudo o que possa ser criado se origina de ti, tu que és o autor de tudo que existe. A verdade é que tudo o que é formado a partir do informe, primeiro é informe, e depois recebe forma.

## CAPÍTULO XX

### O princípio e suas interpretações

 Todas essas verdades, das quais não duvidam os que de ti receberam a graça de ver com os olhos da alma, e que crêem firmemente que teu servo Moisés falou em espírito de verdade, há quem dê esta interpretação: "No princípio Deus criou o céu e a terra" – isto é, Deus criou, em seu Verbo, que lhe é coeterno, o mundo racional e sensível, ou espiritual e corporal. Outro diz: "No princípio Deus criou o céu e a terra" – isto é, Deus criou em seu Verbo, que lhe é coeterno, toda a massa do mundo corpóreo, com tudo o que contém de realidades, manifestamente conhecidas. Um terceiro diz: "No princípio Deus criou o céu e a terra" – isto é, Deus criou em seu Verbo, que lhe é coeterno, a matéria informe das criaturas espirituais e corporais. Outro afirma: "No princípio Deus criou o céu e a terra" – isto é, Deus criou a matéria informe das criaturas corporais, onde estavam ainda confundidos o céu e a terra, que agora distinguimos na massa do universo, com suas formas bem distintas e determinadas.

 Um último diz: "No princípio Deus criou o céu e a terra" – isto é, desde que começou a agir, Deus criou a matéria informe, onde estavam contidos confusamente em potencial o céu e a terra, que depois receberam forma própria, e que agora nos aparecem com tudo o que neles existe.

## CAPÍTULO XXI

### A terra invisível

 O mesmo ocorre em relação à interpretação das palavras que se seguem. Entre essas, todas verdadeiras, cada um escolhe uma. Este diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, essa massa corpórea, que Deus fez, era a matéria ainda sem forma, sem ordem, sem luz, das coisas corpóreas.

 Outro diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, esse conjunto que chamamos de terra e céu era a matéria ainda informe e tenebrosa, da qual seriam tirados o céu e a terra corpóreos, com tudo o que nossos sentidos físicos neles percebem.

 Outro diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto e´, esse conjunto que chamamos de céu e de terra era a matéria ainda informe e tenebrosa, donde seriam feitos o céu inteligível, noutros termos, o céu do céu, e a terra, isto é, toda natureza corpórea, nela incluindo o céu material, ou seja, a matéria de toda criatura visível e invisível.

 Outro diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, não quis a Escritura chamar à massa informe de céu e de terra, porque ela já existia; é dessa massa que ela chamou de terra invisível, caótica, abismo de trevas, é dela, que Deus criou o céu e a terra, isto é, a criatura espiritual e a corporal.

 E outro ainda: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, já existia uma matéria informe, da qual a Escritura diz que Deus criou o céu e a terra, toda a massa corporal do mundo, dividido em duas grandes partes, uma superior, outra inferior, com todas as criaturas nelas existentes e que nos são familiares.

## CAPÍTULO XXII

### Objeções

 Mas a essas últimas opiniões alguém poderia opor a seguinte objeção: "Se não quereis dar o nome de céu e terra à matéria informe, havia então alguma coisa não criada por Deus, e de que ele se serviria para criar o céu e a terra. De fato, a Escritura, não diz que Deus criou essa matéria, a menos que consideremos que seja ela o que chama céu e terra quando diz: "No princípio Deus criou o céu e a terra" – No que se segue: "A terra era invisível e informe" – ainda que a Escritura quisesse designar assim a matéria informe, nós apenas poderíamos entender com isso a matéria criada por Deus, conforme está escrito: "Criou o céu e a terra" – Aos que sustentam as duas últimas opiniões que acabamos de expor, ou de uma das duas, respondem assim: "Não negamos que esta matéria informe seja obra de Deus, de quem procede tudo o que é bom. De fato afirmamos ser um bem superior o que é criado e plenamente formado, mas também dizemos que aquilo que é passível de ser criado e receber forma, embora seja um bem inferior, é ainda um bem.

 A Escritura não menciona a criação por Deus dessa matéria informe, mas deixa também de falar de muitas outras coisas, como, por exemplo, da criação dos querubins, dos serafins, dos tronos, das dominações, dos principados, das potestades, todas criaturas que o Apóstolo menciona claramente, e que Deus evidentemente criou. Se as palavras: "Deus criou o céu e a terra" – compreendem todas as coisas, que diremos das águas sobre as quais pairava o Espírito de Deus?

 Se pretendemos que sejam parte do que designa a palavra terra, como conceber por isso uma matéria informe, quando vemos as águas tão belas? E, por outro lado, por que está escrito que dessa matéria informe foi criado o firmamento, chamado de céu, quando não se faz menção da criação das águas? Pois as águas que vemos correr com harmoniosa beleza e não são nem informes, nem invisíveis! E se elas receberam sua beleza quando Deus disse: "Que se reúnam as águas que estão sob o firmamento! – e se nessa reunião receberam sua formação, que dizer das águas que estão acima do firmamento? Informes, elas não teriam merecido lugar tão honroso, nem é referido com que palavras foram formadas.

 Assim, se o Gênesis é omisso quanto à criação de certas coisas, criação essa que está acima de dúvidas para uma fé sadia e uma inteligência segura, e se nenhuma doutrina racional ousa sustentar que essas águas são coeternas a Deus, pelo fato de as vermos mencionadas no Gênesis sem a menção do momento de sua criação , por que haveríamos de aceitar, à luz da verdade, que essa matéria informe, que a Escritura chama de terra invisível e desordenada e de abismo tenebroso, foi feita por Deus do nada e por isso não é coeterna a Deus, embora a narração da Escritura tenha deixado de referir o momento em que foi criada?

## CAPÍTULO XXIII

### A opinião de Agostinho

 Ouço e medito essas opiniões na medida de meu fraco entendimento, que confesso a Deus, embora ele bem o conheça. Vejo que se podem originar duas espécies de opiniões sobre um testemunho de interprete fidedigno. Uma é reativa à veracidade das coisas, e outra à intenção daquele que as enuncia. Procurar conhecer a verdade sobre a criação é uma coisa; procurar saber o que Moisés, grande servo de tua lei, quis o que o leitor ou ouvinte entendessem de suas palavras, é outra.

 Quanto à primeira opinião, longe de mim todos que têm como verdades os seus erros! Quanto à segunda, longe de mim todos os que julgam falsidade o que Moisés disse. Possa eu unir-me em ti, alegrar-me em ti, Senhor, com aqueles que se alimentam de tua verdade na imensidão da caridade. Aproximemo-nos juntos das palavras de teu Livro, procurando tua vontade nas intenções de teu servo, a cuja pena as revelaste.

## CAPÍTULO XXIV

### Qual a verdade?

 Quem de nós, entre tantos significados possíveis que ocorrem aos estudiosos quanto as varias interpretações de tuas palavras, poderá atinar com tais intenções e declarar com segurança: "Eis o pensamento de Moisés, este é o sentido que quis dar á sua narração". – Quem poderá declará-lo, com a mesma segurança que ele, que essa narração é verdadeira, qualquer que tenha sido o pensamento de Moisés?

 Eis que eu, meu Deus, teu servo, te consagrei nesta obra o sacrifício de minhas confissões; peço à tua misericórdia que me permita a realização desse desejo, e declaro com toda segurança que criaste todas as coisas, as invisíveis e as visíveis, pelo teu verbo imutável.

 Mas poderei dizer com a mesma certeza que Moisés teve essa intenção, e não outra, quando escreveu: "No princípio, criou Deus o céu e a terra"? – Embora esteja persuadido de que isto está claro na tua verdade, não vejo com igual certeza o que Moisés pretendia ao escrever tais palavras. Por essa expressão: "no princípio" pode ter significado: "no começo da criação". Por céu e terra, pode ter querido dar-nos a entender, a natureza espiritual e corporal, não já formada e perfeita, mas uma e outra, só esboçada e sem forma. Vejo que ambos os sentidos são igualmente plausíveis. Mas não posso atinar em qual dos dois pensava Moisés quando escrevia essas palavras. Fosse porém qual fosse sua intenção ao exprimir essas palavras, eu não poderia duvidar de que tão grande homem tenha entrevisto a verdade e a tenha formulado adequadamente.

## CAPÍTULO XXV

### Os diversos partidos

 Que ninguém me moleste portanto, dizendo: "O pensamento de Moisés não é o que tu dizes, mas o que eu digo". – Se apenas me dissessem: "Como sabes que Moisés de fato entendia essas palavras no sentido que lhe atribuis?" – Eu não me agastaria, e responderia talvez o que respondi acima, ou até mais explicitamente, se meu contraditor fosse insistente.

 Quando porém, me dizem: "O pensamento de Moisés não é o que dizes, é o que eu afirmo" – sem contudo provar a veracidade de uma ou outra interpretação, então, ó vida dos pobres, ó meu Deus, em cujo seio não há contradição, inunda de paz o meu coração, para que eu tenha paciência para suportar essas pessoas. Pois não emitem tais opiniões inspirados por Deus, ou porque tenham lido o pensamento de teu servo, mas porque são orgulhosos. Ignoram o pensamento de Moisés, mas só apreciam o deles, e não por que seja verdadeiro, mas por ser o deles. Assim não fosse, apreciariam igualmente a opinião alheia, quando verdadeira, assim como eu aprecio o que eles dizem de verdadeiro, não porque vem deles, mas porque é verdade, e que, por isso mesmo, é tanto deles como minha, pois pertence em comum a todos os amantes da verdade.

 Quanto à pretensão de que o pensamento de Moisés não está no que digo, mas no que eles dizem, isso eu não aceito. Ainda que assim fosse, sua temeridade não é da ciência, mas a da audácia; seria produzida não por uma intuição correta, mas pelo orgulho.

 Senhor, teu julgamento é terrível. Porque tua verdade nem é um bem meu, nem o bem deste ou daquele: a verdade é o bem de todos nós; e tu nos conclamas abertamente a que participemos dela, com a advertência severa de não a possuirmos como bem privativo, para não sermos privados dela. De fato, quem reivindica apenas para si o que ofereces para gozo de todos, e quer para si o que é de todos, é rejeitado desse bem comum para o que é seu, isto é, da verdade para a mentira: o que fala mentira fala do que é seu.

 Ouvem, pois, juiz excelente, ó Deus, que és a própria Verdade: ouve o que respondo a esse contraditor.

 É diante de ti que falo, e na presença de meus irmãos que usam legitimamente da lei, cujo fim á caridade. Escuta e vê o que lhes digo, se é de teu agrado. Eis as palavras fraternas e de paz que lhe dirijo: "Quando ambos vemos que tuas palavras são verdadeiras, ou as minhas palavras são verdadeiras, pergunto: onde o vemos? Certamente não é em ti que eu a vejo, nem tampouco é em mim que tu a vês. Ambos a vemos na verdade imutável, que está acima de nossas inteligências".

 Uma vez que não discordamos sobre essa luz do Senhor, nosso Deus, por que discutir sobre o pensamento de nosso próximo? Nós não o podemos ver como vemos a verdade imutável. Se o próprio Moisés nos aparecesse e nos explicasse seu pensamento – nem assim veríamos esse pensamento, mas apenas acreditaríamos nele. Cuidemos pois, de não nos levantarmos orgulhosamente um contra o outro a respeito das Escrituras. Amemos ao Senhor, nosso Deus, de todo o nosso coração, de toda nossa alma, de todo nosso espírito, e ao próximo como a nós mesmos. É segundo esses dois preceitos da caridade que Moisés pensou aquilo que escreveu em seus livros. Não acreditarmos nisso seria considerar o Senhor mentiroso, atribuindo a seu servo sentimentos distintos daqueles que ele próprio lhe ensinou. Diante de tantos pensamentos igualmente verdadeiros que podem ser deduzidos dessas palavras, vê que estultice é afirmar temerariamente que Moisés teve este pensamento e não aquele, ofendendo com nossas disputas perniciosas a caridade, por amor da qual ele escreveu as palavras que procuramos interpretar!

## CAPÍTULO XXVI

### Agostinho no lugar de Moisés

 Todavia, meu Deus, que me elevas em minha pequenez, que descansas minha fadiga, que ouves minhas confissões e perdoas meus pecados, tu me ordenas que eu ame a meu próximo como a mim mesmo; não posso crer que Moisés, teu servo tão fiel, tenha sido aquinhoado com menos dons do que eu teria desejado e apetecido se tivesse nascido em seu tempo, e me tivesses confiado a tarefa de te servir com meu coração e minha língua, e disseminar essas Escrituras. Estas, tanto tempo depois, deviam ser úteis a todos os homens e, pelo mundo afora, triunfar com o prestígio de sua autoridade sobre as afirmações das doutrinas falsas e orgulhosas.

 Quereria, se estivesse no lugar de Moisés – pois todos procedemos da mesma massa, e que é o homem se não te lembras dele? – e me tivesses confiado a missão de escrever o Gênesis, quereria receber de ti tal eloqüência, tal qualidade de estilo, que mesmo os espíritos incapazes de compreender como foi que Deus criou, não pudessem rejeitar minhas palavras como superiores às suas forças; que os que já o pudessem, descobrissem, nas poucas palavras de teu servo, todas as verdades que sua reflexão já lhes tivesse proporcionado; e que se alguém, à luz de tua verdade, nelas percebesse outro significado, também ele o pudesse encontrar nessas mesmas palavras.

## CAPÍTULO XXVII

### Os diversos sentidos da Escritura

 Assim como uma fonte, em seu pequeno leito, torna-se depois mais abundante e, pelos diversos regatos que alimenta, banha espaços muito mais amplos que qualquer um deles, que deslizam através de muitas regiões, assim também a narração do ministro de tua palavra, que deveria alimentar a tantos interpretes, faz brotar de seu estilo sóbrio e conciso torrentes de límpida verdade, de onde cada um tira para si a verdade que pode, para depois desenvolvê-la em longas sinuosidades de palavras.

 Alguns, lendo ou escutando aquelas palavras, imaginam a Deus como homem ou como massa material dotada de imenso poder que, por decisão nova e repentina, criara fora de si mesma e como que à distância, o céu e a terra, esses dois grandes corpos, um superior, outro inferior, onde estão contidas todas as coisas. E ao ouvirem dizer:"Deus disse: faça-se isto! E isto foi feito! – imaginam que se trata de palavras comuns, que começam e terminam, que soam no tempo e passam. Julgam que, logo após pronunciadas, começa existir o que ordenaram que existisse. Todas as suas demais concepções ressentem-se do mesmo hábito de pensar de modo carnal.

 Nisto são como crianças, pois enquanto essa linguagem humilde sustentar sua fraqueza como o seio de uma mãe, o que se fortifica salutarmente é a fé, que lhes faz ter como certo que Deus criou todas as realidades, cuja admirável variedade impressiona a seus sentidos.

 Mas, se alguém, desprezando a aparente simplicidade de tuas palavras, em sua orgulhosa fraqueza, se lançar para fora do ninho que o nutriu, então cairá miseravelmente, Senhor Deus, tem piedade dele! Que os transeuntes não pisem este passarinho implume; manda teu anjo para que o reponha no ninho, para que viva até que aprenda a voar!

## CAPÍTULO XXVIII

### Divergências

 Para outros essas palavras não são um ninho, mas um vergel (jardim) ensombreado onde descobrem frutos ocultos que procuram e colhem, voando e cantando alegremente.

 Quando lêem ou ouvem as palavras de Moisés, vêem que tua estável e eterna permanência, ó Deus, domina todos os tempos passados e futuros, e por isso não existe criatura corpórea que não seja obra tua. Vêem que tua vontade, confundindo-se com teu ser, criou todas as coisas sem sofrer modificação, sem que nasça nela uma decisão nova, que não existisse antes; que criaste o mundo, não tirando de tua substância uma imagem tua, forma substancial de toda realidade, mas tirando do nada uma matéria informe, diferente de ti mesmo; e esta poderia ser formada à tua imagem pela volta à tua Unidade, segundo a medida previamente estabelecida e concedida a cada ser, de acordo com sua espécie. Vêem assim que todas as obras da criação são excelentes, ou porque permanecem próximas a ti, ou porque, afastadas de ti no tempo e no espaço, fazem ou sofrem as admiráveis variedades do mundo. Reconhecem essas coisas, e por isso se alegram na luz de tua verdade, à medida que o podem com suas forças terrenas.

 Outros, refletindo o sentido destas palavras: "No princípio criou Deus..." – vê no princípio a Sabedoria, porque também ela nos fala.

 Outro, ao considerar as mesmas palavras, entende por princípio o começo da criação, e a expressão: "Deus criou no princípio" significa para ele: "Deus primeiramente fez". E entre os mesmos que por princípio entendem que Deus criou em sua Sabedoria o céu e a terra, um acredita que céu e terra designam a matéria da qual o céu e a terra foram criados; outro pensa que a expressão se aplica a naturezas já formadas e distintas; outro sustenta que a palavra céu significa natureza formada e espiritual, a terra, a natureza informe e material.

 Aqueles porém que entendem por céu e terra a matéria ainda informe, com a qual viriam a ser formados o céu e a terra, não têm unanimidade: um concebe essa matéria como origem comum das criaturas sensíveis e espirituais, outro apenas como fonte de massa sensível e corpórea, contendo em seu vasto seio todas as realidades visíveis, oferecidas a nossos sentidos.

 Tampouco são unânimes os que crêem que nesse texto céu e terra se referem às criaturas já formadas e dispostas; um acredita que se trata do mundo invisível e visível; outro, apenas do mundo visível, onde se contempla o céu luminoso e a terra tenebrosa, com tudo o que eles contêm.

## CAPÍTULO XXIX

### Dificuldades

 Mas quem interpreta a palavra: "No princípio criou..." como se ela quisesse dizer: "Primeiramente Deus criou..." – apenas pode entender, por céu e terra, se quiser se manter coerente à verdade, a matéria do céu e da terra, isto é, da criação universal, tanto espiritual como material.

 Pois, se quiser referir-se com isso a um universo já inteiramente formado, seríamos levados a indagar-lhe: "Se Deus criou isso antes, o que criou depois?" – Depois de ter criado tudo, não encontrará mais nada para criar e, gostando ou não, ouvirá a pergunta: "Como é possível que Deus tenha criado isso primeiro, se nada criou depois?"

 Se ele quer significar que Deus criou primeiro a matéria informe, e depois lhe deu forma, já não é uma tese absurda, desde que seja capaz de discernir a prioridade na eternidade, no tempo, na escolha, na origem. Na eternidade: Deus antecede todas as coisas; no tempo: a flor precede o fruto; na escolha: o fruto vale mais do que a flor; na origem: o som precede o canto.

 Dessas quatro prioridades, a primeira e a última dificilmente se compreendem, enquanto é bem fácil entender as outras duas. É de fato raro e dificultoso conceber a tua eternidade criando, mas conservando-se imutável, as coisas mutáveis e, por isso, antecedendo-as. E precisa ter uma inteligência penetrante para compreender, sem grande esforço, como o som antecede o canto, uma vez que o canto é o som organizado; e uma coisa pode muito bem existir sem forma, mas o que não existe não pode receber forma. Assim, a matéria é anterior ao que dela se forma. e não porque seja sua causa eficiente, pois também é objeto da criação; nem tampouco porque lhe seja anterior no tempo. De fato, não emitimos em um primeiro instante, sons desarticulados e informes, para depois os ligarmos e formar uma melodia e um canto, como se faz com a madeira e a prata ao fabricarmos uma arca ou um vaso.

 Com efeito, essas matérias precedem no tempo os objetos que delas são feitos. Mas com o canto não é assim. Quando se canta ouve-se o som do canto: não há em primeiro lugar sons desorganizados, que depois assumem a forma de canto. Logo que ele soa, o som se desvanece, e não deixa de si nada que se possa coordenar com arte. Por conseguinte, o canto é formado de sons: o som é sua matéria e, para se transformar em canto, recebe uma forma. A prioridade não se fundamenta em um poder criador, porque o som não é o artífice do canto, mas é apenas posto pelo corpo à disposição da alma do cantor, para que dele faça um canto. Nem se trata de prioridade temporal: o som é produzido ao mesmo tempo que o canto. Tampouco se trata de prioridade de escolha: o som não é superior ao canto, pois o canto nada mais é que som, mas um som bonito. Trata-se apenas de uma prioridade de origem, pois o canto não recebe forma para se tornar som, mas o som para se tornar canto.

 Compreende-se por esse exemplo, que a matéria das coisas foi criada antes, e chamada de céu e terra, porque dela foram formados o céu e a terá. Não foi criada antes em sentido cronológico, porque o tempo só tem início com a forma das coisas; ora, a matéria era informe, e se tornou perceptível juntamente com o tempo. Todavia, nada se pode mencionar dessa matéria a não ser alguma prioridade temporal, embora ocupe a última posição na escala de valores, pois o que tem forma é evidentemente superior ao que é informe. Ou que foi precedida pela eternidade do Criador, que a fez para que fossem feitas do nada todas as coisas.

## CAPÍTULO XXX

### Espírito de caridade

 Nessa diversidade de opiniões verdadeiras, que da própria verdade brote a concórdia! Que nosso Deus tenha compaixão de nós, para que usemos legitimamente da lei segundo o preceito que tem por fim a caridade pura.

 Por isso, se me perguntarem qual dessas opiniões foi a de teu servo Moisés, eu não seria coerente com minhas confissões se não te confessasse que o ignoro.

 Sei, contudo, que essas opiniões são verdadeiras, a não mera interpretações materialistas, sobre as quais já disse tudo o que pensava. São como meninos esperançosos aqueles que não temem as palavras do teu Livro, tão profundas em sua humildade, tão eloqüentes em sua concisão. Mas nós todos que, eu o declaro, distinguimos e dizemos a verdade sobre tais palavras, amemo-nos uns aos outros; e amemos igualmente a ti, nosso Deus, fonte da Verdade, pois temos sede, não de fantasias, mas da própria Verdade. Honremos a teu servo, que nos legou tua Escritura, cheio de teu espírito, e estejamos certos que, ao escrever as palavras que lhe revelaste, ele teve em mira as revelações mais salientes da verdade e seus frutos proveitosos.

## CAPÍTULO XXXI

### O Gênesis e seu autor

 Assim, quando alguém me diz: "O pensamento de Moisés é o meu" – e outro diz: "Não, ele pensou como eu" – parece-me mais consoante ao espírito religioso dizer: "Por que não admitir ambos os pontos de vista, se ambos são verdadeiros?" – E se alguém descobrir um terceiro, um quarto sentido, e outros mais, desde que sejam verdadeiros, por que não acreditar que Moisés viu todos eles, ele por cujo intermédio o Deus único adaptou as Escrituras à inteligência da multidão, que deveria descobrir-lhe significados diversos e verdadeiros?

 Por mim, digo-o sem hesitar e do fundo do coração: se, investido da mais alta autoridade, tivesse algo a escrever, preferiria fazê-lo de modo que minhas palavras proclamassem tudo o que cada um pudesse conceber de verdadeiro sobre isso, em vez de propor um significado único e claro que excluísse todos os demais, cuja falsidade não me pudesse ofender. E também não quero, meu Deus, ser tão temerário ao ponto de acreditar que esse grande homem não mereceu de ti essa graça.

 Moisés, redigindo esses textos, pensou, concebeu todas as verdades que já fomos capazes de encontrar, e também as que não o pudemos, mas que podem ser descobertas.

## CAPÍTULO XXXII

### Oração

 Enfim, Senhor, tu que és Deus, e não carne e sangue, se um homem não pôde ver tudo por completo, poderia teu Espírito bom, que me deve conduzir à terra da retidão, desconhecer algo do que tencionavas revelar por essas palavras a seus leitores vindouros, apesar de teu mensageiro não entender senão um dos numerosos sentidos verdadeiros? Se assim é, o sentido que ele pensou era o mais elevado de todos. Mas revela a nós, Senhor, esse sentido ou algum outro que for de teu agrado e real; e quer nos mostres o mesmo sentido que ao homem de Deus, quer seja outro, inspirado pelas mesmas palavras, alimenta nosso espírito, guarda-nos da ilusão do erro.

 Eis, Senhor meu Deus! Quantas páginas escrevi sobre tão poucas palavras! Deste modo, minhas forças e o meu tempo serão suficientes para examinar todos os teus livros? Permite-me, pois, abreviar minhas confissões e adotar uma única interpretação, que me farás escolher como verdadeira, certa e boa, entre as muitas outras que me poderão ocorrer. Que minha confissão seja fiel o bastante para que eu tenha exatidão ao exprimir o pensamento de teu servo, pois para tal me esforçarei; e, se não o conseguir, que eu pelo menos diga o que tua Verdade me quis dizer por suas palavras, como ela disse a Moisés o que lhe aprouve.

# LIVRO DÉCIMO-TERCEIRO

## CAPÍTULO I

### Invocação

 Eu te invoco, ó meu Deus, minha misericórdia, que me criaste, e que não olvidaste aquele que te esqueceu. Chamo-te à minha alma, que preparas para te receber fazendo-te desejar por ela.

 Não abandones ao que te invoca. Antes mesmo que eu te invocasse, já o tinhas prevenido. Muitas vezes me instaste, falando de mil modos diversos para que te ouvisse de longe, para que me convertesse e invocasse por ti que me chamavas.

 Senhor, apagaste todos os meus delitos para não ter de punir o que fizeram minhas iníquas mãos, e te antecipaste a meus atos meritórios para me recompensar do que fizeram tuas mãos, que me criaram; de fato, existias antes de mim, e eu não era digno de receber de ti o ser.

 Contudo, eis que existo, graças à tua bondade que precedeu tudo o que sou e do que me fizeste. Não tinhas necessidade de mim, eu não sou um bem que te possa ser útil, meu Senhor e meu Deus. Se estou a teu serviço, não é porque a ação te cansa ou porque teu poder, privado de meus serviços, diminua; nem porque meu culto seja para ti o que é a cultura para a terra, que sem ela ficaria estéril. Eu devo te honrar para ser feliz em ti, a quem devo meu ser, capaz de felicidade.

## CAPÍTULO II

### A criação e a bondade de Deus

 É pela plenitude de tua bondade que as criaturas subsistem, para que um bem, para ti de todo inútil, ou de nenhum modo igualável a ti, embora saído de ti, continuasse a existir, pois tu o criaste. Com efeito, que poderiam merecer de ti o céu e a terra, que criaste no princípio? E digam, as naturezas espirituais e corpórea, que méritos tinham a teus olhos, que as criaste em tua Sabedoria? Que méritos, para receber de ti o ser, que mostram inacabado e informe, quando tendem à desordem e se afastam de tua semelhança? O que é de natureza espiritual, mesmo informe, é ainda superior a um corpo que recebeu forma; um corpo sem forma é superior ao puro nada; ora, todas essas coisas continuariam informes em teu Verbo, se essa mesma palavra não as recolhesse à tua Unidade, comunicando-lhes a forma e a excelência graças apenas a ti, soberano Bem. Mas que merecimentos antecipados apresentaram a teus olhos, para existir mesmo informes essas criaturas que, sem que as criasses nem teriam existido?

 E o que a matéria corporal merecera de ti para existir, mesmo invisível e caótica? Nem mesmo essa existência teria, se não as tivesses criado. Não existindo ainda, não podia ter merecimento algum para existir. E a criatura espiritual, ainda no estado embrionário, que títulos teria, mesmo para ser essa coisa vagante e tenebrosa, semelhante ao abismo, diferente de ti, se por teu Verbo não fosse conduzida ao mesmo Verbo que a criou e se, iluminada por ele, também não se transformasse em luz, não igual, mas análoga à tua imagem? Para um corpo, não é a mesma coisa existir e ser belo, pois de outro modo não poderia viver e viver sabiamente não são a mesma coisa, porque, se fosse, todo espírito seria imutável em sua sabedoria.

 Mas seu bem reside em se manter unido a ti, para não perder, afastando-se, a luz que adquiriu com a tua proximidade, tornando a cair em uma vida semelhante a um abismo de trevas. E também nós, que por nossa alma somos criaturas espirituais, nós nos afastamos de ti, nossa luz, nós fomos outrora trevas nesta vida e ainda padecemos por entre os restos de nossas trevas, até que nos tornamos tua justiça em teu Filho único, como as montanhas de Deus. Pois fomos objetos de teus juízos, que são profundos como abismos.

## CAPÍTULO III

### A luz

 Sobre as palavras que proferiste no começo da criação: "Faça-se a luz, e a luz foi feita" – eu entendo que se adaptam com propriedade à criatura espiritual, que já era uma espécie de via apta a receber tua luz. Mas assim como ela não tinha merecido de ti ser essa espécie de vida apta a receber a luz, do mesmo modo, uma vez criada, ela como as demais formas não mereceu de ti essa iluminação. Porque sua informidade não te agradaria se não tivesse tornado luz, e isso não se contentando com existir, mas contemplando a luz que a iluminava, unindo-se intimamente a ela. Assim, ela devia a existência e o viver feliz apenas à tua graça; voltada, por uma escolha feliz, para o que não pode mudar nem para melhor, nem para pior. Voltou-se para ti, que és o único que existes, e só o teu ser é simples, pois o viver e a felicidade são para ti a mesma coisa, porque és tua própria felicidade.

## CAPÍTULO IV

### A bondade criadora

 Que faltaria, pois, a esse bem, que és tu mesmo, se nenhuma dessas criaturas existisse, ou se tivesse permanecido informes? Tu as criaste, não por ter necessidade delas, nem para aumentar tua felicidade, mas levado pela plenitude de tua bondade, comunicando-lhes uma forma. Na tua perfeição, desagrada-te sua imperfeição; tu as aperfeiçoas para que elas te agradem, e não, com isso, aperfeiçoar a ti mesmo.

 Com efeito, teu Espírito bom pairava sobre as águas, e não era por elas levado como se nelas descansasse. Se diz que teu Espírito nelas repousava; mas era ele que as fazia em si. Incorruptível, imutável, bastando-se a si mesma, tua vontade era suspensa acima da vida que tinhas criado, para a qual viver não é o mesmo que viver feliz, porque ela vive, mesmo quando flutua sobre as trevas. Esta vida carece ainda voltar-se para seu Criador, para viver cada vez mais próxima à fonte da vida, para ver a luz na Luz divina, e nela haurir perfeição, brilho e felicidade.

## CAPÍTULO V

### A trindade

 Mas eis que me aparece o enigma da Trindade que és, meu Deus. Porque tu, Pai, criaste o céu e a terra no princípio de nossa Sabedoria, que é tua Sabedoria, nascida de ti, igual e coeterna, a ti, isto é, em teu Filho.

 Já falei longamente do céu do céu, da terra invisível e informe e do abismo das trevas, onde a natureza espiritual errante e fluida permaneceria tal se não se voltasse para Aquele de quem toda vida procede, para que, por meio de sua luz, se tornasse viva e bela, o céu do céu, criado mais tarde entre a água superior e a água inferior.

 Pelo vocábulo "Deus" eu já entendia o Pai, que criou essas coisas; na palavra "princípio" eu entendia o Filho, em quem ele as criou. E, como eu acreditava na Trindade de meu Deus, eu a procurava em tuas santas palavras. E vi em tuas Escrituras que teu Espírito pairava sobre as águas. Eis tua Trindade, meu Deus, Pai, Filho, Espírito Santo, Criador de toda criatura!

## CAPÍTULO VI

### O espírito sobre as águas

 Mas, ó luz da verdade, aproximo de ti meu coração para que ele não me ensine falsidades; dissipa-lhe as trevas e dize-me, eu to suplico por nossa mãe, a caridade, dize-me, por que só depois de ter nomeado o céu, a terra invisível e informe e as trevas sobre o abismo, por que só então é que as Escrituras falam de teu Espírito? Será porque convinha apresentá-lo assim pairando sobre alguma coisa? E seria isso possível se não mencionasse primeiro sobre o que pairava? De fato, não era sobre o Pai nem sobre o Filho que ele pairava, e seria impróprio falar assim se não pairasse sobre alguma coisa.

 Era pois, necessário, mencionar primeiro o elemento sobre o qual ele pairava, já que convinha falar dele apenas dizendo que pairava. Mas por que não convinha apresentá-lo senão dizendo que pairava?

## CAPÍTULO VII

### As águas sem substância

 Agora, quem o puder com a inteligência, siga a teu Apostolo, quando ele diz que tua caridade se difundiu em nossos corações pelo Espírito Santo que nos foi dado, quando nos instrui sobre as coisas espirituais e nos indica o caminho excelso da caridade, e dobra o joelho diante de ti por nossa causa, para que conheçamos a ciência altíssima da caridade de Cristo. E é porque era super eminente desde o princípio que pairava sobre as águas.

 A quem e como falarei do peso da concupiscência, que nos arrasta para um abismo profundo, e da caridade que nos eleva, com a ajuda de teu Espírito, que pairava sobre as águas? A quem falar, como falar? Nós submergimos e emergimos, mas não em abismos materiais. A metáfora é a um tempo correta e muito inexata. São nossas paixões, nossos amores, a impureza de nosso espírito que nos arrasta para baixo sob o peso das preocupações. E é tua santidade que nos eleva pelo amor de tua paz, para que levantemos nossos corações para junto de ti, onde teu Espírito paira sobre as águas, e alcancemos o sublime repouso, quando nossa alma tiver atravessado essas águas que são sem substância.

## CAPÍTULO VIII

### À luz que ilumina as trevas

 O anjo caiu, a alma do homem caiu, revelando assim as profundas trevas em que teria caído o abismo que continha todas as criaturas espirituais, se não tivesses dito desde o começo: "Faça-se a luz!" – se a luz não se tivesse feito, se todas as inteligências de tua cidade celeste não se tivessem unido na obediência a ti, se não tivessem repousado em teu Espírito que paira, imutável, sobre os seres transitórios. De outro modo, até o céu do céu não seria mais que abismo de trevas, enquanto que agora é luz no Senhor.

 Nesta lamentável inquietação dos espíritos decaídos, que, despidos da veste de tua luz, manifestam as próprias trevas, mostras claramente a grandeza de tua criatura racional; na busca da felicidade, ela só se sacia com tua grandeza, onde encontra repouso – pois que ela não pode bastar-se a si própria. Porque tu, Senhor, iluminarás nossas trevas. De ti vêm nossas vestes de luz, e nossas trevas serão como o sol do meio-dia.

 Dá-te a mim, meu Deus, entrega-te a mim. Eu te amo. Se meu amor é pouco, faze que eu te ame com mais força. Não posso medir, não posso saber o que falta a meu amor para que seja suficiente para que minha vida corra para teus braços, e dali não saia antes de se esconder no segredo do teu rosto.

 Se isto reconheço: tudo me corre mal onde tu não estás, não somente à minha volta, mas até em mim mesmo; e toda a abundância que não é meu Deus, para não passa de indigência.

## CAPÍTULO IX

### O amor de Deus

 Mas o Pai e o Filho, não pairavam também sobre as águas? Se os imaginamos como um corpo pairando no espaço, isso não se pode aplicar nem mesmo ao Espírito Santo. Se porém entendermos por isso a excelência imutável da divindade acima de tudo o que é transitório, então o Pai, o Filho e o Espírito Santo pairavam igualmente sobre as águas. E por que só se menciona o Espírito Santo? Por que se menciona apenas a seu respeito um lugar onde estava, ele que, no entanto, não ocupa espaço? Também apenas dele se disse que era um dom de Deus, e é em teu dom que repousamos; é nele que gozamos de ti. Nosso repouso é nosso lugar. É para lá que o amor nos arrebata, e teu Espírito levanta nossa humildade para longe das portas da morte. A paz, para nós, reside na tua boa vontade. Os corpos tendem, por seu peso, para o lugar que lhes é próprio; mas um peso não tende só para baixo; tende para o lugar que lhe é próprio. O fogo sobe, a pedra cai. Cada um é movido por seu peso, e tende para seu justo lugar. O óleo, lançado à água, flutua; a água, lançada ao óleo, afunda. Ambos são impelidos por seu peso a procurarem o lugar que lhes é próprio. As coisas que não estão em seu lugar se agitam; mas quando o encontram, repousam.

 Meu peso é meu amor; para onde quer que eu vá, é ele quem me leva. Teu dom nos inflama e nos eleva; ardemos e partimos. Subimos os degraus do coração e cantamos o cântico gradual. É o teu fogo, o teu fogo benfazejo que nos consome e nos eleva, enquanto subimos para a paz de Jerusalém celeste. Regozijei-me ao ouvir essas palavras: "Vamos para a casa do Senhor!" – Ali nos há de instalar tua boa vontade, e não desejaremos nada mais do que permanecer ali eternamente.

## CAPÍTULO X

### Os dons de Deus

 Feliz a criatura que não conheceu outro estado! Seria porém diferente do que é se, apenas criada, teu Espírito, que paira sobre todas as coisas mutáveis, não a tivesse erguido com este apelo: "Faça- te a luz" – e a luz se fez. Em nós, o tempo em que éramos trevas distingue-se do tempo em que nos tornamos luz. Mas dessa criatura só se diz o que teria sido se não fosse iluminada. A Escritura fala dela como se tivesse sido flutuante e tenebrosa, para nos realçar a causa que a transformou, isto é, que a conduziu para a luz inextinguível, para que também fosse luz. Quem o puder, compreenda, quem não o puder, que te peça a graça de o compreender. Por que importunam, como seu fosse a luz que ilumina a todo homem que vem a este mundo?

## CAPÍTULO XI

### O homem e a trindade

 Quem é capaz de compreender a Trindade onipotente? E quem não fala dela, ainda que a não compreenda? Rara é a pessoa que, falando dela, sabe o que diz. Discute-se, disputa-se, mas ninguém sem paz interior contempla esta visão.

 Quisera que os homens refletissem sobre três coisas que têm dentro de si mesmos. Elas diferem muito da Trindade, e eu só as proponho para que as usem como exercício e experiência do pensamento, e com isso compreender como estão longe deste mistério. Eis as três coisas: ser, conhecer, querer. Porque existo, conheço, quero e vejo. Eu sou aquele que conhece e quer. Sei que existo e que quero, e quero existir e saber. Repare, quem puder, como nessas três coisas a vida é indivisível, a unidade da vida, a unidade da inteligência, a unidade da essência; veja a impossibilidade de distinguir elementos inseparáveis e, contudo, distintos. O homem está diante de si mesmo; que ele se examine, veja e me responda. Contudo, por ter encontrado e reconhecido esta analogia, não julgue por isso ter compreendido a essência do Ser imutável, que transcende tais movimentos da alma, que existe imutavelmente, conhece imutavelmente e quer imutavelmente. Mas é por causa de tais atributos que em deus há a Trindade, ou esses três atributos pertencem a cada pessoa divina, cada uma sendo assim uma e trina? Ou ambas as coisas são admiravelmente reais: a Trindade, misteriosamente simples e múltipla, sendo para si mesma seu próprio fim infinito, pelo qual existe, se conhece e se basta imutavelmente na magnitude superabundante de sua unidade? Quem conceberá facilmente este mistério? Quem poderia explicá-lo? Quem, temerariamente, ousaria enunciá-lo de algum modo?

## CAPÍTULO XII

### A criação e a Igreja

 Ó minha fé, vai adiante em tua confissão. Dize a teu Senhor: "Santo, santo, santo! É o Senhor, meu Deus! – Em teu nome fomos batizados, Pai. Filho e Espírito Santo; em teu nome batizamos, Pai, Filho e Espírito Santo. Também entre nós Deus criou, pelo seu Cristo, um céu e uma terra, isto é, os espirituais e os carnais de sua Igreja. E nossa terra, antes de receber a forma da doutrina, era invisível e informe, e estávamos imersos nas trevas da ignorância, porque castigaste o homem por causa de sua iniqüidade, e teus justos juízos são como abismos profundos.

 Mas porque teu Espírito pairava sobre as águas, tua misericórdia não abandonou nossa miséria, e disseste: "Faça-se a luz". Fazei penitencia, porque está próximo o reino de Deus. Fazei penitencia, faça-se a luz! E porque tínhamos a alma conturbada, nos lembramos de ti, Senhor, às margens do Jordão, sobre essa montanha grande como tu, que te tornaste pequeno por nós. Nossas trevas te desagradaram, nós nos voltamos para ti, e a luz se fez. E eis que outrora fomos trevas e que agora somos luz no Senhor.

## CAPÍTULO XIII

### Nós e a luz

 Contudo, somos luz apenas pela fé, e não por uma visão clara. É na esperança que fomos salvos, e a esperança que vê não é mais esperança. O abismo clama pelo abismo, mas é já pela voz de tuas cataratas. Não pude falar-vos como a homens espirituais, mas como a carnais. Quem assim fala, não julga ainda ter atingido sua meta e, esquecendo-se do que ficou para trás, avança para o que está vivo, como o cervo tem sede de água das fontes, e diz: "Quando chegarei?" – Ele deseja o abrigo de sua morada, que está no céu e chama o abismo inferior dizendo: "Não vos conformeis com este mundo, mas reformai-vos renovando vosso espírito, e não queirais ser crianças na mente, mas sede pequeninos quanto à malícia, para que sejais perfeitos no espírito..." E ainda: "Ó gálatas insensatos, quem vos fascinou?" – Mas não é mais sua voz que fala assim, e sim a tua voz, porque mandaste teu Espírito do alto do céu por intermédio de Jesus, que subiu ao céu e abriu as cataratas de seus dons, para que a torrente de alegria alegrasse tua cidade. É por essa cidade que suspira o amigo do esposo, ele que já possui as primícias do Espírito, mas que ainda geme, porque está à espera da adoção e do resgate do seu corpo. É por ela que suspira, porque ele é membro da Esposa de Cristo; por ela se abrasa em zelo, porque é o amigo do esposo. Zela por ela, não por si mesmo, pois é pela voz de tuas cataratas, e não com sua própria voz, que ele chama pelo outro abismo, objeto de seu zelo e de seus temores. Assim como a serpente enganou Eva com sua astúcia, ele receia que as inteligências débeis se corrompam e se afastem da pureza que está em teu Esposo, teu Filho único. Quão resplandecente será essa luz, quando o virmos tal como ele é, e quando tiverem passado essas lágrimas que se tornaram o pão de meus dias e de minhas noites, enquanto a cada dia me perguntam: Onde está o teu Deus?

## CAPÍTULO XIV

### Esperança

 Também eu pergunto: "Onde estás, meu Deus? Onde estás?" – Respiro um pouco de ti quando minha alma se expande dentro de mim mesmo em gritos de exaltação e de louvor, verdadeiro canto de festa. – Mas ela ainda está triste, porque torna a cair e a ser abismo, ou melhor, porque sente que ainda é abismo.

 Minha fé, que acendeste à noite para conduzir meus passos, lhe diz: "Por que está triste, ó minha alma, e por que me perturbas? Espera no Senhor. Seu Verbo é uma lâmpada para teus passos. Espera, persevera, até que a noite passe, a noite, mãe dos iníquos, até que passe a ira do Senhor, ira da qual outrora fomos filhos quando éramos trevas". – Dessas trevas ainda arrastamos os restos neste corpo morto pelo pecado, até que alvoreça o dia e se dissipem as sombras. Espera no Senhor. Desde a manhã estarei diante deles, e o contemplarei, e o louvarei eternamente. Desde a manhã estarei diante dele e verei a salvação de minha face, meu Deus, que vivificará nossos corpos mortais pelo seu Espírito que habita em nós, misericordiosamente levado por sobre as águas tenebrosas de nossas almas.

 Por isso, em nossa peregrinação, recebemos dele o penhor de já sermos luz; ele já nos salvou pela esperança e, de filhos da noite e das trevas que éramos, ele fez filhos da luz e do dia. Na incerteza da ciência humana, só tu és capaz de distinguir entre uns e outros, porque põe nossos corações à prova e chamas à luz dia e às trevas noite. Quem, senão tu, sabe nos distinguir? E que temos nós que não o tenhamos recebido de ti? Nós, feitos vasos de honra, fomos feitos da mesma argila que serviu para fazer os vasos de ignomínia.

## CAPÍTULO XV

### Símbolos

 E quem, senão tu, nosso Deus, estendeu sobre nós um firmamento de autoridade, da tua divina Escritura? O céu se dobrará como um livro, e agora ele se estende sobre nós como um pergaminho. Mais sublime é a autoridade de que goza tua divina Escritura depois que morreram aqueles que cujo intermédio no-las comunicaste. E sabes, Senhor, sabes como cobriste de peles os homens, quando o pecado os tornou mortais. Por isso estendeste como um pergaminho o firmamento de teu Livro, e tuas palavras em tudo concordes, que dispuseste sobre nós pelo ministério de homens mortais. Por sua morte, a autoridade de tuas palavras, por eles divulgadas, desdobra sua força sobre tudo o que existe em baixo; ela não se erguia tão alto enquanto eles viviam. É que ainda não tinhas desenrolado o céu como um pergaminho, nem tinhas ainda difundido a glória de sua morte por toda parte.

 Senhor, faze que contemplemos os céus, obra de tuas mãos! Dissipa de nossos olhares as nuvens com que os tens velado. Neles está teu testemunho, dando sabedoria aos humildes. Meu Deus completa teu louvor pela boca dos meninos que ainda mamam! Não conhecemos outros livros que assim destruam a soberba, e que abatam tão bem o inimigo que resiste a toda reconciliação contigo, e defende seus pecados. Não, Senhor, não conheci outras palavras tão puras, que tantos me persuadissem à confissão, e sujeitassem minha mente a teu jugo, convidando-me a te servir tão desinteressadamente. Oxalá eu as compreenda, bondoso Pai! Concede esta graça à minha submissão, pois as firmaste para os corações submissos.

 Há outras águas, creio eu, sobre esse firmamento: águas imortais e isentas da corrupção terrena. Que elas louvem teu nome! Que os povos celestes de teus anjos te bendigam, pois não têm necessidade de olhar esse firmamento, nem de ler para aprenderem a conhecer tua palavra! Eles sempre vêem tua face, e ali lêem, sem as sílabas transitórias, o objeto da tua vontade eterna. Lêem, escolhem, amam. Lêem perpetuamente, e o que eles lêem jamais fenece; escolhendo e amando, lêem tua imutável vontade. Teu códice jamais de fecha, jamais se enrola, porque tu mesmo és eternamente esse livro; tu os estabeleceste acima deste firmamento, levantado por ti acima da fraqueza dos povos da terra, para que estes, olhando-o, reconheçam tua misericórdia, que te anuncia no tempo, tu criador do tempo. Tua misericórdia está no céu, e tua verdade se eleva até às nuvens. As nuvens passam, mas o céu permanece. Os que pregam tua palavra passam para uma outra vida, mas tua Escritura se estende sobre os povos até o fim dos séculos. O céu e a terra passarão, mas tuas palavras não passarão. O pergaminho será enrolado, e a erva sobre o qual se estendia passará com seu esplendor, mas a tua palavra permanecerá eternamente. Agora ela nos aparece no enigma das nuvens e através do espelho dos céus, e não como é na realidade, porque ainda não se manifestou o que havemos de ser, apesar de amados pelo teu filho. Ele nos olhou através da teia da sua carne e nos acariciou, e nos inflamou de amor, e corremos atrás de sua fragrância. Mas quando ele aparecer seremos semelhantes a ele, porque o veremos tal como ele é. Vê-lo tal qual é será nossa felicidade, mas nós ainda não o podemos contemplar.

## CAPÍTULO XVI

### Deus, fonte de luz

 Assim como só tu existes plenamente, só tu possuis o conhecimento absoluto: imutável, com efeito, és em teu ser, imutável em teu saber, imutável na tua vontade. Tua essência sabe e quer imutavelmente, tua ciência é e quer imutavelmente, tua vontade é e sabe imutavelmente. Não é justo a teus olhos que a luz imutável seja conhecida pelo ser mutável, que ela ilumina, como ela se conhece a si própria. Por isso, minha alma é para ti como terra sem água, porque assim como não pode iluminar a si mesma, não se pode saciar por seus próprios meios. Porque em ti está a fonte da vida, e graças à tua luz é que veremos a luz.

## CAPÍTULO XVII

### As águas amargas

 Quem reuniu em um só mar as águas amargas? Seu objetivo é o mesmo: uma felicidade temporal, terrena, alvo de todas as suas ações a despeito da grande diversidade de cuidados que as agitam. Quem, senão tu, Senhor, poderia dizer a essas águas que se reunissem em um só lugar, e à terra enxuta que aparecesse, sedenta de ti? O mar é teu, pois tu o fizeste, e tuas mãos formaram a terra enxuta. Não é a amargura das vontades mas a reunião das águas que chamamos de mar. Também refreias as paixões más das almas e fixas os limites até onde permites que avancem as águas, para que suas ondas se quebrem sobre si mesmas; e assim, crias o mar, submetido a teu poder universal.

 As almas sedentas de ti, que aparecem a teu olhos separadas do mar com outra finalidade, tu as regas com um orvalho vivo, misterioso e doce, para que a terra produza seu fruto. E a terra o produz; ao teu comando, ó Senhor que és seu Deus, nossa alma germina obras de misericórdia, de acordo com sua condição: ela ama o próximo e vai em auxílio de suas necessidades materiais. Carrega em si a semente da compaixão, por uma semelhança de natureza, porque é o sentimento de nossa fraqueza que nos leva a compadecer as misérias dos que são necessitados, a socorre-los, como desejaríamos que nos socorressem se tivéssemos as mesmas necessidades. E não se trata só de dar apoio fácil, como ervas nascidas de sementes, mas de proteção enérgica, vigorosa como a árvore que carrega frutos, símbolos das obras que arrebatam à mão do poderoso a vítima da injustiça, dando-lhe um abrigo à sombra protetora de um julgamento justo.

## CAPÍTULO XVIII

### Meditação

 Senhor, assim como crias e concedes alegria e força, assim te peço que nasça da terra a vontade, e que a justiça lance os olhos sobre nós do alto dos céus, e que no firmamento brilhem os astros! Dividamos nosso pão com quem tem fome, acolhamos em nossa casa o pobre sem teto, vistamos quem está nu, e não desprezemos nossos semelhantes! Quando tais frutos nascem de nossa terra, olha, Senhor, e diz: Isso é bom; faze que tua luz brilho no momento oportuno. Por esta humilde messe de boas obras, faze que nos possamos elevar a uma contemplação deliciosa do Verbo da Vida, e que brilhemos no mundo como astros, fixados no firmamento de tua Escritura.

 E aí, de fato, que nos ensinas a distinguir entre as realidades inteligíveis e as sensíveis, entre as almas espirituais e as almas que se entregam aos sentidos, como entre o dia e a noite. Deste modo já não és mais o único, no segredo de teu discernimento, como eras antes da criação do firmamento, a distinguir entre a luz e as trevas. Também tuas criaturas espirituais, dispostas e ordenadas nesse mesmo firmamento, depois que tua graça se manifestou através do mundo, brilham sobre a terra, separam o dia da noite e marcam as diferenças dos tempos. De fato, as coisas antigas passaram, e eis que se fizeram novas, nossa salvação está mais próxima do que quando começamos a crer, a noite avançou e se aproximou o dia, coroas o ano com tua benção, envias teus operários à tua messe, semeada pelo trabalho de outros operários, enviando-os também para outra sementeira, cuja messe será colhida no fim dos séculos.

 Assim ouves as preces do justo e abençoas seus anos. Mas continuas eternamente o mesmo, e em teus anos, que não terão fim, preparas um celeiro para os anos que passam.

 Por desígnio eterno, lanças sobre a terra os bens do céu no tempo oportuno; a um, teu Espírito dá a palavra de sabedoria, luminar maior para os que encontram seu deleite na luz de uma verdade clara como o raiar do dia; a outro dás, pelo mesmo Espírito, a palavra de ciência, luminar menor; a outro a fé; a outro o poder de curar; a outro o dom dos milagres; a outro a graça da profecia; a este o discernimento dos espíritos, `aquele o dom das línguas. E todos esses dons são como estrelas, são obra de um só e mesmo Espírito, que reparte a cada um os seus dons como lhe agrada, e que faz aparecer tais astros para o bem comum.

 Mas a palavra de ciência em que estão encerradas todos os mistérios, que variam com o tempo, como varia a lua, e os outros dons que mencionei ao compará-los com as estrelas, diferem a tal ponto desse brilho de sabedoria de que goza o raiar do dia, que não passam de crepúsculo. Contudo, teus dons são necessários àqueles homens, a quem teu prudente servidor não pôde dirigir como a espirituais, mas como a carnais, ele que pregou a Sabedoria entre os perfeitos.

 Quanto ao homem carnal, semelhante a um menino em Cristo, que só se alimenta de leite, que não se julgue abandonado em sua noite, que saiba contentar-se com a luz da lua e das estrelas, até que possa tomar alimento sólido e olhar para o sol. Eis o que nos ensinas em tua sabedoria, nosso Deus, em teu livro, que é teu firmamento, para que distingamos todas as coisas em contemplação admirável, embora ainda estejamos sob a lei dos sinais, dos tempos, dos dias e dos anos.

## CAPÍTULO XIX

### Ainda a terra seca

Mas antes, lavai-vos, purificai-vos, arrancai a iniqüidade de vossos corações e de meus olhos, para que apareça a terra seca. Aprendei a fazer o bem, sede justos para com o órfão e defendei a viúva, para que a terra produza a erva tenra e árvores cheias de frutos. Vinde e dialoguemos, diz o Senhor, e assim no firmamento do céu se ascenderão luminares que brilharão por sobre a terra.

 Aquele rico perguntava ao bom Mestre o que deveria fazer para ganhar a vida eterna. E o bom Mestre, que é bom porque é Deus, e não um homem como o rico o considerava, lhe declarou: "O que deseja conseguir a vida deve observar os mandamentos, afastar de si a amargura da malícia e da iniqüidade, não matar, não cometer adultério, não roubar, não prestar falso testemunho, a fim de que se mostre a terra seca, geradora do respeito do pai e da mãe e do amor do próximo.

 – Tudo isto já fiz – diz o rico. – De onde vêm pois tantos espinhos, se a terra é fértil? – Vai, arranca os espessos emaranhados da avareza, vende teus bens, enriquece-te dando tudo aos pobres, e possuirás um tesouro no céu; segue o Senhor se queres ser perfeito, junta-te aos que ele instrui nas palavras de sabedoria, ele que sabe o que se deve dar ao dia e à noite. Também tu o saberás, e eles se tornarão para ti luminares no firmamento do céu. Mas isso não se realizará se ali não estiver teu coração, e teu coração, não estará onde não estiver teu tesouro – Assim falou teu bom Mestre. Mas a terra estéril entristeceu, e os espinhos sufocaram a Palavra divina.

 Mas vós, geração escolhida, fracos aos olhos do mundo, que tudo deixaste para seguir o Senhor, caminhais após ele, confundi os fortes; segui-lo com vossos pés resplandecentes, e brilhai no firmamento para que os céus cantem suas glórias, distinguindo a luz dos perfeitos, que ainda não são semelhantes aos anjos, e as trevas dos pequenos, que ainda não perderam a esperança. Brilhai sobre toda a terra! Que o dia resplandecente de sol transmita ao dia seguinte a palavra de Sabedoria, e que a noite, iluminada pela lua, transmita à noite a palavra de Ciência. A lua e as estrelas brilham na noite, mas a noite não as obscurece, porque são elas que iluminam a noite, de acordo com a sua capacidade.

 Como se Deus tivesse dito: Façam-se luminares no firmamento, e logo se fez ouvir um ruído vindo do céu, semelhante ao de um vento violento, e foram vistas línguas de fogo, que se dividiram e se colocaram sobre cada um deles. E apareceram luminares no céu, que possuíam a palavra de vida. Correi por toda parte, chamas sagradas, fogos admiráveis. Vós sois a luz do mundo, e não estais debaixo do alqueire. Aquele a quem vos unistes foi exaltado e ele vos exaltou. Correi e dai-vos a conhecer a todas as nações.

## CAPÍTULO XX

### Os répteis e as aves

 Que o mar também conceba e dê à luz tuas obras; que as águas produzam répteis dotados de almas vivas. De fato, separando o precioso do vil, vos tornastes a boca de Deus, pela qual ele diz: "Produzam as águas..." não a alma viva, filha da terra, mas répteis dotados de almas vivas, e pássaros que voam sobre a terra. Assim como esses répteis, teus sacramentos, ó meu Deus, deslizaram, graças às obras de teus santos, por entre as ondas das tentações do século para regenerarem os povos com teu nome, em teu batismo.

 Então se operaram grandes maravilhas, semelhantes a enormes cetáceos, e as palavras de teus mensageiros percorreram a terra, sob o firmamento de teu Livro, que com tua autoridade deveria proteger seu vôo para onde quer que fossem. Não há língua nem palavras em que não se ouçam suas vozes; seu som espalhou-se por toda a terra, e suas palavras até os confins do mundo, porque tu, Senhor, abençoando-os, os multiplicaste.

 Estaria eu mentindo? Ou confundindo a questão, não distinguindo as claras noções das coisas do firmamento das obras corpóreas que se realizam no mar agitado e sob o firmamento? Por certo que não. Há coisas cuja idéia é completa, acabada, que não se multiplicam no curso das gerações, tais como as luzes da sabedoria e da ciência. Mas esses seres são o objeto de operações materiais múltiplas e variadas e, crescendo umas de outras, se multiplicam sob tua benção, meu Deus. É assim que refreias a impertinência de nossos sentidos, dando a uma verdade única o meio de se exprimir de varias maneiras, por movimentos do corpo. Eis que produziram tuas águas, pela onipotência de teu Verbo. Tudo isto se originou das necessidades de povos afastados de tua verdade eterna, por meio do teu Evangelho. De fato foram essas águas que fizeram brotar essas coisas, e sua amargura estagnante foi causa de que teu Verbo as criasse.

 Todas tuas obras são belas, mas és indizivelmente mais belo tu, que criaste tudo o que existe. Se Adão não se tivesse separado de ti, em sua queda, de seu seio não teria saído o oceano amargo do gênero humano, com sua profunda curiosidade, seu orgulho cheio de tempestades, suas ondas instáveis. E os dispensadores de tuas palavras não teriam a necessidade de representar, no meio de tantas águas, por meio de sinais físicos e sensíveis, teus atos e palavras místicas. Foi nesse sentido que entendi esses répteis e essas aves. Mas até os homens iniciados nesses sinais e deles imbuídos, não avançariam no conhecimento desses mistérios, aos quais estão sujeitos, se sua alma não se elevasse á vida do espírito, e, após a palavra inicial, não aspirasse à perfeição.

## CAPÍTULO XXI

### A alma viva

 E assim não foi a profundeza do mar, mas a terra livre do amargor das águas que, impelida pelo teu Verbo gerou não mais os répteis dotados de almas vivas e os pássaros, mas a alma viva. E esta não mais tem necessidade de batismo (necessário para os gentios), como tinha necessidade enquanto as cobriam. Pois não se entra de outro modo no reino dos céus, desde que assim o determinaste. Para ter fé, ela já não exige grandes maravilhas. Ela crê sem ter visto sinais e prodígios, porque é terra fiel, já distinta das águas do mar que a incredulidade torna amargas: e as línguas são um sinal,não para os fiéis, mas para os infiéis.

 A terra que estendeste acima das águas não tem necessidade dessa espécie de aves que as águas produziram por ordem de teu Verbo. Envia-lhe, pois, teu Verbo, por meio de teus mensageiros. Nós falamos de suas obras, mas quem age por seu intermédio, para que produzam uma alma viva, és tu. A terra a germina porque é a causa dos fenômenos que ocorrem na superfície, assim como o mar foi causa da produção dos répteis dotados de almas vivas, e das aves sob o firmamento do céu. A terra já não necessita destas criaturas, embora ela se alimente de peixes pescados nas profundezas do mar, nessa mesa que preparaste na presença dos crentes; porque eles foram pescados nas profundezas do mar para alimentar a terra árida.

 Também as aves, ainda que nascidas no mar, multiplicam-se sobre a terra. As primeiras gerações evangélicas foram motivadas pela incredulidade dos homens, mas também fiéis nela encontram diariamente copiosas exortações e bênçãos. Todavia, a alma viva, extrai da terra sua origem, porque somente aos fiéis é meritório abster-se de amar este mundo, para que sua alma viva por ti, essa alma que estava morta quando vivia em delícias mortíferas. Ó Senhor, só tu fazes as delicias de um coração puro.

 Que teus ministros trabalhem na terra, não como nas águas da incredulidade, quando pregavam e falavam utilizando-se de milagres, de sinais misteriosos, de termos místicos, para capturar atenção da ignorância, mãe da admiração, pelo medo desses sinais secretos. Por esta porta, de fato, os filhos de Adão têm acesso à fé, esquecidos de ti enquanto se escondem de tua fade e se tornam abismos. Que teus ministros trabalhem como em terra seca, separada das fauces do abismo; e que sejam modelo para os fiéis, vivendo sob teus olhares e incitando-os à imitação. E assim ouve não só para ouvir, mas também para praticar. "Procurai a Deus, e vossa alma viverá, e a terra dará nascimento a uma alma viva. Não vos conformeis com este mundo em que vivemos, abstendo-vos dele. A alma vive evitando as coisas cujo desejo causa-lhe a morte. Abstende-vos das violências selvagens da soberba, das ociosas voluptuosidades da luxúria, da falsidade que engana em nome da ciência, para que os animais ferozes sejam domesticados, os brutos domados e para que as serpentes sejam inofensivas: todos representam alegoricamente os movimentos da alma humana. O fastio do orgulho, as delícias da luxúria, o veneno da curiosidade, são movimentos da alma morta, mas não morta a ponto de carecer de todo movimento; é afastando-se da fonte da vida que ela morre, o mundo a arrebata ao passar, e a este se amolda.

 Mas tua palavra, meu Deus, é a fonte da vida eterna, e não passa. Ela mesma nos proíbe que nos afastemos de ti por essas palavras: "Não vos conformeis com o mundo em que vivemos, para que a terra, fertilizada pela fonte da vida, produza uma alma viva, uma alma que busque em tua palavra, transmitida por teus evangelistas, se fortificar, imitando os imitadores de teu Cristo". – Eis o sentido da expressão "segundo sua espécie", porque o homem imita a quem ama. "Sede como eu" – diz o Apostolo, - porque sou como vós. – Assim haverá na alma viva apenas feras sem maldade, agindo com doçura. Pois nos deste este mandamento: "Fazei vossas obras com mansidão, e sereis amados por todos" – Também os animais domésticos serão bons: se comerem, não sofrerão fastio e, se não comerem, não terão fome. As serpentes, tornando-se boas, serão incapazes de causar danos, mas continuarão astutas e cautelosas; não investigarão a natureza temporal, senão na medida necessária para compreender e contemplar a eternidade através das coisas criadas. Esses animais, as paixões, obedecem à razão, quando refreados em seus caminhos mortais, vivem e se tornam bons.

## CAPÍTULO XXII

### Sentido místico da criação do homem

 Assim, Senhor, nosso Deus e nosso Criador, quando nossos afetos mundanos, que nos causam a morte porque nos faziam viver mal, se afastarem do amor do mundo, quando nossa alma, vivendo bem, se tornar alma viva, e quando se cumprir a palavra que proferiste pela boca de teu Apostolo: "Não vos conformeis com o mundo em que vivemos" – então seguir-se-á aquilo que acrescentaste imediatamente ao dizer: "Mas reformai-vos na novidade de vossa mente". – E já não será "segundo vossa espécie" – como se fosse imitar nossos predecessores ou viver seguindo os exemplos de alguém melhor que nós. Não disseste: "Que o homem seja feito de acordo com sua espécie" – mas "façamos o homem à nossa imagem e semelhança" – para que pudéssemos reconhecer tua vontade. Para tanto, o divulgador de teu pensamento, que gerou filhos pelo Evangelho, não querendo que continuassem como crianças os que alimentara com leite e agasalhara em teu seio como uma ama, dizia: "Reformai-vos renovando vosso coração, para discernir a vontade de Deus, que é bom, agradável e perfeito". – Também não dizes: "Façase o homem" – mas "à nossa imagem e semelhança". Aquele que é renovado no espírito, que compreende e conhece tua verdade, não mais carece que um outro lhe ensine a imitar sua espécie. Graças às tuas lições, ele reconhece por si qual é tua vontade, o que é bom, agradável e perfeito. Tu lhe ensinas, pois agora é capaz deste ensinamento, a ver a Trindade da Unidade e a Unidade da Trindade. Eis por que, depois de falar no plural: "Façamos o homem" se diz no singular: "E Deus criou o homem". Depois deste plural: "À nossa imagem" – este singular: "À imagem de Deus". Assim o homem "se renova pelo conhecimento de Deus, à imagem de seu criador" – e "tornando-se espiritual, julga todas as coisas", que certamente hão de ser julgadas, "mas ele não é julgado por ninguém".

## CAPÍTULO XXIII

### O julgamento do homem espiritual

 Ele julga tudo, significa que tem autoridade sobre os peixes do mar, sobre os pássaros do céu, sobre os animais domésticos e selvagens, sobre toda a terra e sobre todos os répteis que nela se arrastam. Exerce esse poder pela inteligência, pela qual percebe as coisas que são do Espírito de Deus. Mas, elevado a tão grande honra, o homem não entendeu sua dignidade, igualou-se aos jumentos insensatos, tornando-se semelhante a eles.

 Por isso, na tua Igreja, Senhor, pela graça que lhe concedeste – pois somos obra tua, e criados para obras boas, tanto os que governam como os que obedecem segundo o Espírito tem o dom de julgar. Porque assim fizeste a criatura humana homem e mulher, em tua graça espiritual, onde não há distinção conforme o sexo, nem judeu nem grego, nem escravo nem homem livre. Os espirituais, portanto, tanto os que presidem como os que obedecem, julgam espiritualmente. Eles não julgam conhecimentos espirituais que brilham no firmamento, pois não lhes cabe fazer juízos sobre tão sublime autoridade. Nem julgam tua Escritura, mesmo em suas passagens obscuras: nós lhe submetemos nossa inteligência, e temos certeza de que até aquilo que está oculto à nossa compreensão é justo e verdadeiro. O homem, pois, embora já espiritual e renovado pelo conhecimento, conforme a imagem de seu criador, deve ser cumpridor da lei, e não seu juiz. Nem pode ajuizar sobre o que distingue espirituais e carnais. Somente teus olhos, meu Senhor, os distinguem, mesmo que nenhuma obra sua os tenha revelado a nós, para que os reconheçamos por seus frutos. Mas tu, Senhor, já os conheces e os classificaste, e os chamaste no segredo de teu pensamento, antes de ter criado o firmamento.

 Tampouco julga, o homem espiritual, os povos inquietos deste mundo. De fato, por que julgaria ele os que estão fora, ignorando quem alcançará a doçura da tua graça, e quem permanecerá na eterna amargura da impiedade?

 Por isso, o homem que criaste à tua imagem, não recebeu poder sobre os astros do céu, nem sobre o mesmo céu misterioso, nem sobre o dia e a noite que chamaste á existência antes da criação do céu, nem sobre a massa das águas, que é o mar. Mas recebeu poder sobre os peixes do mar, sobre as aves do céu, sobre todos os animais, sobre toda a terra, e sobre tudo o que se arrasta pela superfície do solo.

 Ele julga e aprova o que acha bom, e reprova o que acha mau, quer na celebração dos sacramentos, com que são iniciados os que na tua misericórdia tira das águas profundas, quer no banquete em que se serve o peixe tirado das profundezas para alimento da terra fiel; quer nas palavras e expressões sujeitas à autoridade de teu Livro que, semelhantes aos pássaros, voam sob o firmamento: interpretações, exposições, discussões, bênçãos e invocações que brotam sonoras da boca, para que o povo responda: Amém! É necessário que essas palavras sejam enunciadas fisicamente, por causa do abismo do mundo e da cegueira da carne que, impossibilitada de ver o pensamento, tem necessidade de sons que firam os ouvidos. Assim, sem dúvida é sobre a terra que as aves se multiplicam, embora tenham suas origens na água.

 O homem espiritual julga também aprovando o que acha correto e reprovando o que é vicioso nas obras e nos costumes dos fiéis. Julga das suas esmolas, comparáveis aos frutos da terra; ele julga a alma viva pelas paixões domadas pela castidade, os jejuns, e pelos pensamentos piedosos, na medida em que essas coisas se manifestam aos sentidos do corpo. Em resumo, é juiz de tudo o que pode se corrigir.

## CAPÍTULO XXIV

### Crescei e multiplicai-vos

 Mas que é isto? Que mistério é este? Abençoas os homens, Senhor, para que eles cresçam, se multipliquem, e encham a terra. Não queres nisto dar-nos a entender alguma coisa? Por que não abençoaste também a luz, que chamaste dia, nem a terra, nem o mar? Eu diria, meu Deus, que nos criaste à tua imagem, diria que quiseste conceder especialmente ao homem esta benção, se não houvesses abençoado igualmente os peixes e os cetáceos, para que cresçam, se multipliquem, encham as águas do mar, e os pássaros para que se multipliquem sobre a terra.

 Afirmaria ainda que essa benção foi reservada às espécies vivas que se reproduzem por meio de geração, caso a encontrasse também nas árvores, nas plantas, nos animais da terra. Mas não foi dito nem às plantas, nem às árvore , nem aos répteis: "Crescei e multiplicai-vos" – embora todas essas criaturas se multipliquem pela procriação, como os peixes, os pássaros e os homens, conservando assim sua espécie.

 Quer dizer, então, ó minha Luz, ó Verdade? Que tais palavras carecem de senso e foram ditas em vão? De nenhum modo, ó Pai de misericórdia. Longe de mim, longe do servidor de teu Verbo, uma tal afirmação! Apenas não compreendo o sentido dessas palavras, e espero que os melhores que eu, ou seja, os mais inteligentes, a entendam melhor, segundo a sabedoria que deste, meu Deus, a cada um. Que te agrade ao menos a confissão, que faço diante de ti, de minha certeza de que não falaste em vão aquelas palavras.

 Não calarei as reflexões que me sugere a leitura dessas palavras. O que penso é verdadeiro, e nada vejo que impeça de explicar assim os textos figurados de teus livros. Sei que sinais corporais podem exprimir de vários modos uma idéia que o espírito concebe em um só sentido; uma idéia expressa de um só modo. Como exemplo, cito a simples idéia do amor de Deus e do próximo. Quantos símbolos, quantas línguas, e em cada uma inúmeras locuções lhe dão uma expressão concreta! É assim que crescem e se multiplicam os peixes das águas.

 E note ainda nisto, meu leitor. Há uma frase que a Escritura declara de uma só forma, e que a voz fala apenas dessa maneira: "No princípio criou Deus o céu e a terra" – E não pode a frase ser interpretada diversamente – descartando o erro ou o sofisma – conforme os diversos pontos de vista legítimos? É assim que crescem e se multiplicam as gerações dos homens!

 Se consideramos a natureza das coisas, não alegoricamente, mas em sentido próprio, a sentença: "Crescei e multiplicai-vos" – se aplica a todas as criaturas que nascem de uma semente. Se, ao contrário, a interpretamos em sentido figurado, como penso que foi a intenção da Escritura, que não limita inutilmente essa benção aos peixes e aos homens, encontramos então multidões de criaturas espirituais e temporais, como no céu e na terra; de almas justas e injustas, como na luz e nas trevas; de escritores sagrados que nos anunciaram a Lei, como no firmamento estabelecido entre as águas; na sociedade amargurada dos povos, como no mar; no zelo das almas piedosas, como em terra enxuta; nas obras de misericórdia praticadas nesta vida, como nas plantas que nascem de semente e nas árvore frutíferas; nos dons espirituais concedidos para o bem de todos, como nos luminares do céu; nas paixões dominadas pela temperança, como na alma viva. Em todas essas coisas encontramos multidões, fecundidade, crescimento. Mas que esse crescimento e essa proliferação exprimam uma mesma idéia de vários modos e que uma só expressão possa ser entendida de muitas maneiras, esse fato, apenas o encontramos nos sinais sensíveis e nos conceitos intelectuais.

 Os sinais corpóreos, originados da profundidade de nossa cegueira carnal, correspondem, segundo penso, às gerações das águas; os conceitos intelectuais, gerados pela fecundidade da inteligência, simbolizam,me parece, as gerações humanas.

 E é por isso, Senhor, creio que disseste tanto às águas como aos homens: "Crescei e multiplicai-vos" – Nessa benção, penso que nos deste a faculdade, o poder de formular de várias maneiras uma única idéia, e de compreender também de muitas maneiras uma expressão única, mas obscura.

 É assim que as águas do mar se povoam, e não se moveriam sem as várias interpretações das palavras. É assim que a terra se povoa de gerações humanas; sua aridez se fecunda pela sua paixão da verdade, sob o poder da razão.

## CAPÍTULO XXV

### Os frutos da terra

 Quero ainda dizer, Senhor meu Deus, o que me inspiram as palavras que seguem da tua Escritura. E o farei sem medo, porque direi a verdade; pois não vem de ti, por acaso, a inspiração do que queres que eu diga? Não creio que eu possa dizer a verdade se tu não me inspirares, pois tu és a própria verdade, e todo homem é mentiroso. Por isto, quem mente fala do que é seu. Logo, para falar a verdade, só falarei o que me inspiras.

 Tu nos deste para alimento todas as ervas que produzem semente e que cobrem a terra, e todas as árvore que contém em si, em germe, seus frutos. E não foi somente a nós que deste esse alimento, mas também às aves do céu, aos animais da terra e aos répteis, mas não aos peixes e aos grandes cetáceos. Dizíamos que esses frutos da terra significam e representam alegoricamente as obras de misericórdia, que a terra fecunda produz para as necessidades desta vida. Era semelhante a uma terra assim o piedoso Onesíforo, cuja casa recebeu a graça de tua misericórdia, porque muitas vezes assistira a teu Paulo, sem se envergonhar por suas cadeias.

 É o mesmo que fizeram os irmãos que, de Macedônia, lhe forneceram o que lhe era necessário, produzindo também abundante fruto. E contudo, o Apóstolo se queixa de certas árvore que não lhe tinham dado fruto devido, quando escreve: "em minha primeira defesa ninguém me assistiu; todos me abandonaram. Que isto não lhes seja imputado!" – Tais frutos são devidos aos que nos ministram doutrina racional, ajudando-nos a compreender os mistérios divinos. E nós lhes devemos exemplos de todas as virtudes; e também lhes devemos os frutos como a pássaros do céu, por causa das bênçãos que distribuem abundantemente sobre a terra, pois sua voz se fez ouvir por toda a terra.

## CAPÍTULO XXVI

### O dom e o fruto

 Nutrem-se com esses alimentos os que neles se alegram; não encontram neles alegria os homens cujo deus é seu ventre. E até entre os que ofertam esses frutos, o fruto não é o que eles dão, mas o espírito com que o oferecem. Por isso, naquele que servia a seu Deus e não a seu ventre percebo claramente a fonte de sua alegria; e participo fortemente de seu regozijo. Paulo recebera os presentes que os filipenses lhes tinham mandado por intermédio de Epafrodito. Vejo bem a razão de sua alegria. E é dela que se nutria, porque ele diz com verdade: "Alegrei-me muito no Senhor, vendo enfim reflorescer para mim vossa estima, da qual já andáveis desgostados".

 Eles, de fato, tinham estado realmente aborrecidos e, tornados áridos, não produziam mais o fruto das boas obras; e Paulo se alegra por eles, porque suas simpatias tornaram a florescer, e não por o terem socorrido na sua indigência. Porque ele diz em seguida: "Não é por causa das privações que sofro que falo assim: aprendi a me contentar com o que tenho. Sei acomodar-me às privações, e sei viver na abundância. Em tudo e por tudo habituei-me à saciedade e à fome, à abundância e à penúria. Tudo posso naquele que me fortalece".

 Qual então o motivo de tua alegria, ó grande Paulo? De onde vem tal júbilo, de que te alimentas, ó homem renovado para o conhecimento de Deus, conforme a imagem de teu Criador, alma viva que possui tal domínio de si, língua alada que exprime os mistérios? É certamente a tais almas que se deve este alimento. O que foi para ti esse alimento substancioso? A alegria. Ouçamos o que segue: "Contudo, fizestes bem ao partilhar de minhas tribulações" – Esta é a fonte da alegria, isto é o que o nutre, as boas obras, e não o conforto que aliviou sua miséria. Ele diz: "Na tribulação dilatastes meu coração" – pois ele aprendeu a viver na abundância e sofrer as privações, em ti, que o confortas. – "Bem sabeis, filipenses – diz ele – que nos primórdios de minha pregação do Evangelho, quando deixei a Macedônia, nenhuma Igreja me assistiu com seus bens quanto ao dar e receber, com exceção de vós, que, várias vezes me enviaste, para Tessalônica, com que suprir às minhas necessidades". – Alegra-se agora por voltarem à prática de boas ações, felicitando-se por terem eles reflorido como campo fértil e verdejante.

 Referia-se por acaso às próprias necessidades quando dizia: "Socorrestes às minhas necessidades"? – Será este o motivos de sua alegria? Certamente que não. E como o sabemos? Porque ele diz em seguida: "Eu não procuro a dádiva, mas o fruto". – Aprendi de ti, meu Deus, a discernir a dádiva do fruto. O dom é a própria coisa dada por aquele que acode às nossas necessidades; é o dinheiro, a comida, a bebida, a roupa, um abrigo, e auxílio. O fruto é a vontade boa e reta do doador. O bom Mestre não se limita a dizer: "Aquele que receber um profeta" – mas acrescenta: "Aquele que receber um justo..." – mas acrescenta: "na qualidade de justo". – E assim, aquele receberá a recompensa do profeta, e o outro, a do justo. Ele não diz apenas: "Aquele que der um copo de água fresca a um de meus pequeninos" – mas acrescenta: "na qualidade de discípulo". – E prossegue: "Na verdade vos digo: este não ficará sem recompensa". – Dom é receber o profeta, receber o justo, dar um copo de água fresca a um discípulo; fruto é fazer isso em consideração de sua qualidade de profeta, de justo, de discípulo. É com este fruto que Elias era alimentado pela viúva: ela sabia que alimentava um homem de Deus, e é por isso que o fazia. Os alimentos, porém, que lhe eram levados pelo corvo, não passavam de dom, e não era o Elias interior, mas o Elias exterior que recebia esse alimento, o que poderia morrer se lhe faltasse esse alimento.

## CAPÍTULO XXVII

### Peixes e cetáceos

 Por isso, Senhor, direi diante de ti a verdade. Por vezes, ignorantes e infiéis que, para serem iniciados e conquistados para a fé, precisam desses rituais de iniciação e de milagres mirabolantes, simbolizados, a meu ver, pelos peixes e pelos cetáceos, acolhem teus servos e os socorrem, ou os auxiliam nas necessidades da vida presente, sem saber por que o fazem nem em vista de que devem agir. Desse modo, nem aqueles os alimentam, nem estes são alimentados por eles, pois os primeiros não são movidos por vontade santa e reta, e os segundos não se alegram com os dons recebidos, não descobrindo neles fruto algum. Ora, a alma só se alimenta com o que lhe traz alegria. É esta a razão pela qual os peixes e os cetáceos se nutrem de alimentos que a terra só pode produzir depois de separados e purificados de amargura das águas do mar.

## CAPÍTULO XXVIII

### A bondade da criação

 Viste, meu Deus, que tudo o que criaste te pareceu excelente. Também nós vemos tua criação, e ela nos parece excelente. Para cada espécie de obra criada, disseste: "Faça-se" e quando elas se fizeram, viste que eram boas. Sete vezes está escrito – eu as contei – que viste a excelência de tua obra; e na oitava vez contemplaste toda a criação, e disseste que, no seu conjunto, era não apenas boa, mas muito boa. Tomadas separadamente, tuas obras eram boas; consideradas em seu conjunto, elas eram boas e até excelentes. O mesmo julgamento se pode fazer da beleza dos corpos. Um corpo, formado de membros todos belos, é muito mais bonito que cada um desses membros cuja harmoniosa organização forma o conjunto, embora, considerados à parte, também eles tenham sua beleza própria.

## CAPÍTULO XXIX

### A palavra de Deus e o tempo

 Procurei ver com atenção se forma sete ou oito as vezes que constataste a bondade de tuas obras quando elas te agradaram. Mas não encontrei uma seqüência temporal não tua visão, de onde pudesse deduzir que foi esse o número de vezes que viste tuas criaturas. Então disse: "Senhor, não será verdadeira tua Escritura, inspirada por ti, que és a própria verdade? Por que então me dizes que tua visão das coisas não está sujeita ao tempo, enquanto tua Escritura me diz que dia por dia viste a bondade de tuas obras? E calculei quantas vezes o fizeste."

 A isto me respondes, porque és meu Deus, falando com voz forte no ouvido interior de teu servo, rompendo minha surdez, me exclamas: "Ó homem, o que minha Escritura diz, isto digo eu. Mas ela fala no tempo, enquanto este não atinge o meu verbo, que permanece em mim, eterno como eu. Assim, o que vês por meu Espírito, sou eu quem o vê; o que dizes por meu Espírito, sou eu quem o diz. Mas o que vês no tempo, eu não vejo no tempo; e o que dizes no tempo, eu não digo no tempo."

## CAPÍTULO XXX

### Erro dos maniqueus

 Ouvi, Senhor, meu Deus, tua voz, e recolhi em meu coração uma gota de doçura de tua verdade. Compreendi que há uns aos quais tuas obras desagradam. Eles sustentam que muitas delas fizeste constrangido pela necessidade, como a estrutura dos céus, a ordem dos astros; afirmam que não as criaste por ti mesmo, mas que elas já existiam alhures, criadas por outra fonte; que te limitaste a reuni-las, a ordená-las, a entrelaçá-las; que com elas construíste as muralhas do mundo, depois de vencido teus inimigos, para que essa construção os mantivesse cativos, e não mais pudessem se revoltar contra ti; que não criaste nem organizaste outros seres, como os corpos carnais, os animais pequenos e tudo o que se prende à terra por meio de raízes; que foi um espírito hostil, uma outra natureza, não criada por ti, e que se opõe a ti nas regiões inferiores do mundo, que as gerou e organizou. Esses insensatos falam assim porque não vêem tuas obras através de teu Espírito, nem te reconhecem neles.

## CAPÍTULO XXXI

### A luz do espírito divino

 O oposto sucede aos que vêem tuas obras através de teu Espírito, pois és tu é quem as vê neles. Portanto, quando vêem que elas são boas, tu também vês essa bondade; em tudo o que lhes agrada por tua causa, tu és que nos agradas, e o que nos agrada através de teu Espírito é em nós que te agrada. Com efeito, quem dentre os homens sabe das coisas do homem, senão o espírito do homem que nele habita? Do mesmo modo o que pertence a Deus ninguém o sabe, a não ser o Espírito de Deus. "Quanto a nós, diz ainda Paulo, não recebemos e espírito deste mundo, mas o Espírito de Deus, para que conheçamos os dons que nos vêm de Deus".

 E isto me fez perguntar: Posto que certamente ninguém sabe das coisas de Deus, com exceção do Espírito de Deus, como então nós conhecemos os dons que nos vêm de Deus? Eis a resposta que recebi: As coisas que sabemos por seu Espírito, ninguém as sabe a não ser o Espírito de Deus. É pois justo que foi dito aos que falavam, inspirados pelo Espírito de Deus: "Não sois vós os que falais" – e aos que obtém seu saber do Espírito de Deus: "Não sois vós os que sabeis". – E com igual razão se diz aos que vêem através do Espírito de Deus: "Não sois vós os que vêem". Assim, em tudo o que vemos de bom pelo Espírito de Deus, não somos nós que vemos, mas Deus.

 Por isso, uma coisa é julgar mau o que é bom, como o fazem aqueles de quem falei acima, e outra coisa é o homem ver o que é bom. Todavia, muitos amam tua criação porque é boa, mas não tem amam nessa criação; e por isso preferem gozar dela que de ti. Há ainda outro caso, quando alguém vê que uma coisa é boa, mas é Deus que nele vê que essa coisa é boa, e é Deus que é amado em sua criação. Ele só o pode ser graças ao Espírito que Deus nos deu, porque o amor de Deus foi derramado em nossos corações pelo Espírito Santo que nos foi dado. Por ele, vemos que tudo o que de algum modo existe é bom, pois recebe seu ser daquele que é, não de um modo qualquer, mas de modo absoluto.

## CAPÍTULO XXXII

### A criação

 Graças te damos, Senhor! Vemos o céu e a terra, isto é, a parte superior e inferior do mundo material, assim como a criação espiritual e material. E, como adorno dessas partes que se compõe, o conjunto do Universo, e o conjunto de toda a criação, vemos a luz que foi criada e separada pelas trevas. Vemos o firmamento do céu, tanto o que está situado entre as águas espirituais superiores e as águas materiais inferiores, como ainda esses espaços de ar, chamados também de céu, onde volitam as aves do céu entre as águas que se evolam em vapores, e nas noites serenas se condensam em orvalho, e as que correm pesadas sobre a terra. Vemos a beleza das águas reunidas nas planícies do mar, e a terra enxuta, ora nua, ora tomando forma visível e ordenada, mãe das plantas e das árvore . vemos os luminares do céu brilhando acima de nós, o sol bastar para o dia, a lua e as estrelas consolando a noite, e todos esses astros marcando e assinalando a cadência do tempo. Vemos o elementos úmido habitado por peixes, monstros, animais alados, porque a densidade do ar que sustenta o vôo dos pássaros é aumentada pela evaporação das águas. Vemos a face da terra embelezar-se de animais terrestres, e o homem, criado à tua imagem e semelhança, senhor de todos os animais irracionais, precisamente porque foi feito à tua imagem e se assemelha a ti, em virtude da razão e da inteligência. E como na alma humana há uma parte que domina pela reflexão e outra que se submete na obediência, assim a mulher foi criada fisicamente para o homem; é fora de dúvida que ela possui um espírito e uma inteligência racional, iguais aos do homem, mas seu sexo a coloca sob a dependência do sexo masculino; é desse modo que o desejo, princípio da ação, se submete à razão que concebe a arte do agir retamente. Eis o que vemos, e que cada uma dessas coisas, tomadas por si, são boas, e que todas, em seu conjunto, são muito boas.

## CAPÍTULO XXXIII

### A matéria e a forma

 Que tuas obras te louvem para que te amemos! Que nós te amemos, para que tuas obras te louvem! Elas têm seu princípio e fim no tempo, seu nascimento e morte, seu progresso e decadência, sua beleza e sua imperfeição. Elas têm, portanto, sucessivamente sua manhã e sua noite, umas oculta; outras, manifestamente.

 Foram feitas por ti do nada, não de tua substância, nem de nenhuma substância estranha ou inferior a ti, mas de matéria concriada, isto é, criada por ti ao mesmo tempo em que lhe deste forma, sem nenhum intervalo de tempo. Sem dúvida a matéria do céu e da terra é uma coisa, e sua forma é outra; a matéria tua a fizeste do nada, a forma, tu a tiraste da matéria informe. Contudo, criaste uma e outra a um só tempo, de maneira que entre a matéria e a forma não houvesse nenhum intervalo de tempo.

## CAPÍTULO XXXIV

### Alegoria da criação

 Também meditei sobre o significado simbólico da ordem pela qual se fez tua criação e da ordem pela qual a Escritura relata. Vimos que tuas obras, consideradas cada uma em si, são boas, e em seu conjunto, muito boas. Em teu Verbo, em teu Filho único, vimos o céu e a terra, a cabeça e o corpo da Igreja, predestinadas antes de todos os tempos, quando ainda não havia nem manhã, nem tarde. Depois começaste a executar no tempo o que predestinaste antes do tempo, a fim de revelar teus desígnios ocultos e de dar ordem às nossas desordens – porque pesavam sobre nós nossos pecados, e nos perdíamos longe de ti em voragens de trevas. Teu Espírito misericordioso pairava sobre nós, para nos socorrer no momento oportuno. Justificaste os ímpios; tu os separaste dos pecadores e confirmaste a autoridade de teu Livro entre os superiores, que te eram dóceis, e os inferiores, para que a eles se submetessem. Reuniste em um corpo único, de mesmas aspirações, a sociedade dos infiéis, para que aparecesse o zelo dos fiéis fecundo em obras de misericórdia, e distribuindo aos pobres os bens da terra para adquirir os do céu.

 Acendeste então os luzeiros no firmamento: teus santos, que possuem a palavra de vida e brilham pela sublime autoridade dos seus dons espirituais. Depois, para difundir a fé entre as nações idólatras, fizeste com a matéria visível dos sacramentos os milagres bem perceptíveis, e determinaste as vozes das palavras sagradas, conformes ao firmamento de teu Livro, pelas quais seriam abençoados teus fiéis. Formaste depois a alma viva dos fiéis, pela disciplina das paixões bem ordenadas e pelo vigor da continência. Por fim renovaste a alma, que não estava sujeita senão a ti, e que não tinha mais necessidade de nenhuma autoridade humana para imitar, à tua imagem e semelhança; submeteste, como a mulher ao homem, a atividade racional ao poder da inteligência. Quiseste que a teus ministros que são necessários ao progresso dos fiéis nesta vida, que esses mesmos fiéis propiciassem o necessário para suas necessidades temporais; obras valiosas de caridade, cujos frutos colherão no futuro. vemos todas essas coisas, e todas são muito boas, porque tu as contemplas em nós, tu que nos deste o Espírito, para que por ele pudéssemos vê-las e amar-te nelas.

## CAPÍTULO XXXV

### Prece

 Senhor Deus, tu que nos deste tudo, concede-nos a paz do repouso, a paz do sábado, a paz do ocaso. De fato, esta formosíssima ordem de coisas muito boas, passará quando atingir o termo de seu destino, e terá sua tarde como teve seu amanhecer.

## CAPÍTULO XXXVI

### O repouso de Deus

 O sétimo dia, porém, não tem crepúsculo; não entardece porque o santificaste para que se prolongue eternamente. E o repouso de teu sétimo dia, depois de ter criado tantas e tão boas obras, embora sem te causar fadiga, a palavra de tua Escritura nos anuncia que também nós, depois de nossos trabalhos, que são bons porque assim nos o concedeste, encontraremos o repouso em ti, no sábado da vida eterna.

## CAPÍTULO XXXVII

### O repouso da alma

 Então também repousarás em nós, como hoje opera em nós; e o repouso de que gozaremos será teu, como as obras que fazemos são tuas. Mas tu, Senhor, sempre estás ativo e sempre estás em repouso. Tu não vês o tempo, não ages no tempo nem repousas no tempo; todavia, concede-nos que vejamos no tempo,fazes o próprio tempo e o repouso além do tempo.

## CAPÍTULO XXXVIII

### O descanso de Deus

 Vemos, portanto, as tuas criaturas porque elas existem. Mas elas existem porque tu as vês. Olhando à nossa volta, vemos que elas existem; em nosso íntimo, vemos que são boas. Mas tu já as viste feitas quando e onde viste que deviam ser feitas. Agora somos inclinados a praticar o bem, depois que nosso coração concebeu essa idéia em teu Espírito. Outrora estávamos inclinados ao mal, desertando de ti. Tu, porém, ó Deus, único bem, nunca cessaste de nos fazer o bem. Por tua graça, algumas de nossas obras são boas, mas não são eternas. Esperamos, depois de realizá-las, repousar em tua grande santificação. Mas tu, que não precisas de nenhum outro bem, estás sempre em repouso, porque és teu próprio repouso.

 Que homem poderá dar ao homem a compreensão desta verdade? Que anjo a outro anjo? Que anjo ao homem? É a ti que devemos pedir, e em ti é que a devemos buscar, é à tua porta que devemos bater. E somente assim receberemos, somente assim encontraremos, somente assim se nos abrirá tua porta.

*GRATIAS TIBI DOMINE*
