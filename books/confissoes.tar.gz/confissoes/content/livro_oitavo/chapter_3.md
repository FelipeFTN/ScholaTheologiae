## CAPÍTULO III

### A alegria das coisas perdidas

 Bom Deus, que se passa no homem para que se alegre mais com a salvação de uma alma desesperada, quando salva de grande perigo, do que se ela sempre tivesse tido esperança, ou se o perigo tivesse sido menor? Também tu, Pai misericordioso, sentes mais alegria por um pecador arrependido do que por noventa e nove justos que não têm necessidade de penitência. Grande é o nosso prazer ao falar da alegria do pastor trazendo de volta sobre os ombros a ovelha desgarrada, e da mulher que repõe em teus tesouros, para satisfação geral dos vizinhos, a dracma perdida. E nos arranca lágrimas a alegria das festas de tua casa quando lemos que teu filho menor estava morto e reviveu; estava perdido e foi encontrado.

 Tu te alegras em nós e em teus anjos, santificados pelo santo amor; pois és sempre o mesmo, e conheces do mesmo modo e sempre as coisas que nem sempre existem, nem da mesma maneira.

 Mas, que se passa na alma, para que se alegre mais com as coisas que estima, encontradas ou reavidas, do que se sempre as tivesse possuído? Na verdade, tudo o atesta, e há inúmeros testemunhos que afirmam: "É assim mesmo!"

 O general celebra o triunfo da vitória, e não teria vencido sem combate; e quanto mais foi árdua a batalha, tanto maior é o gozo no triunfo.

 A tempestade cai sobre os navegantes com ameaça de naufrágio. Todos empalidecem diante da morte iminente. O céu e o mar se acalmam, é grande sua alegria, e nasce do muito que temeram.

 Adoece uma pessoa amiga: seu pulso revela um desfecho fatal. Todos os que desejam sua cura sofrem com ela, por simpatia. Havendo melhora, embora ainda não recuperado o vigor de outrora, já reina tal alegria como não existia antes, quando andava sadia e forte.

 Até os prazeres da vida humana, não só compensam os homens de desgraças casuais e involuntárias, mas também de moléstias premeditadas e desejadas. Não há prazer algum em beber ou comer sem que haja antes o estímulo da sede ou da fome. Os ébrios costumam comer antes alguma coisa salgada, que lhes cause sede ardente e que transformará em prazer quando acalmada com a bebida. O costume quer que as esposas não sejam entregues imediatamente aos maridos: o marido desprezaria a noiva se não tivesse que esperar e suspirar por ela.

 Assim ocorre tanto na alegria torpe e vil, como na alegria lícita e permitida, na mais sincera e honesta amizade, como na aventura daquele que estava morto e tornou a viver, que se havia perdido e foi encontrado; em todos os casos uma alegria maior é precedida de uma dor também maior.

 Por que isto, Senhor, meu Deus, quando tu mesmo és tua própria alegria eterna, e as criaturas à tua volta em ti se alegram? Por que esta parte do universo sofre as alternâncias de progressos e quedas, de uniões e separações? Será este o modo de ser que lhe concedeste quando, do mais alto dos céus até às profundezas da terra, desde o princípio dos tempos até o fim dos séculos, desde o anjo até o pequenino verme, e desde o primeiro movimento até o último, dispuseste todos os gêneros de bens e todas as tuas obras justas, cada uma em seu lugar e tempo?

 Ai de mim! Quão alto és nas alturas e quão profundo nos abismos! Jamais te afastas de nós e, contudo, quanta dificuldade para voltar a ti!