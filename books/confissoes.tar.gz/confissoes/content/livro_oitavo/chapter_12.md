## CAPÍTULO XII

### A conversão

 Mas logo que esta profunda reflexão tirou da profundeza de minha alma, e expôs toda minha miséria à vista de meu coração, caiu sobre mim enorme tormenta, trazendo copiosa torrente de lágrimas. E para dar-lhe toda vazão com seus gemidos, afastei-me de Alípio; a solidão parecia-me mais adequada e me afastei o mais longe possível, para que sua presença não me fosse embaraçosa. Tal era o estado em que encontrava, e Alípio percebeu-o, pois lhe disse alguma coisa com um timbre de voz embargado de lágrimas que me denunciou.

 Alípio, atônito, continuou no lugar em que estávamos sentados; mas eu, não sei como, me retirei para a sombra de uma figueira, e dei vazão às lágrimas; e dois rios brotaram de meus olhos, sacrifício agradável a teu coração. E embora não com estes termos, mas com o mesmo sentido, muitas coisas te disse como esta: E tu, Senhor, até quando? Até quando, Senhor, hás de estar irritado! Esquece-te de minhas iniqüidades passadas! Sentia-me ainda preso a elas, e gemia, e lamentava: "Até quando? Até quando direi amanhã, amanhã? Por que não agora? Por que não pôr fim agora às minhas torpezas?"

 Assim falava, e chorava oprimido pela mais amarga dor do meu coração. Mas eis que, de repente, ouço da casa vizinha uma voz, de menino ou menina, não sei, que cantava e repetia muitas vezes: "Toma e lê, toma e lê".

 E logo, mudando de semblante, comecei a buscar, com toda a atenção em minhas lembranças se porventura esta cantiga fazia parte de um jogo que as crianças costumassem cantarolar; mas não me lembrava de tê-la ouvido antes. Reprimindo o ímpeto das lágrimas, levantei-me. Uma só interpretação me ocorreu: a vontade divina mandava-me abrir o livro e ler o primeiro capitulo que encontrasse.

 Tinha ouvido dizer que Antão, assistindo por acaso a uma leitura do Evangelho, tomara para si esta advertência: "Vai, vende tudo o que tens, dá-lo aos pobres, e terás um tesouro no céu; depois vem e segue-me" – e que esse oráculo decidira imediatamente sua conversão.

 Depressa voltei para o lugar onde Alípio estava sentado, e onde eu deixara o livro do Apóstolo ao me levantar. Peguei-o, abri-o, e li em silêncio o primeiro capítulo que me caiu sob os olhos: "Não caminheis em glutonarias e embriaguez, não nos prazeres impuros do leito e em leviandades, não em contendas e rixas; mas revesti-vos de nosso Senhor Jesus Cristo, e não cuideis de satisfazer os desejos da carne".

 Não quis ler mais, nem era necessário. Quando cheguei ao fim da frase, uma espécie de luz de certeza se insinuou em meu coração, dissipando todas as trevas de dúvida.

 Então, marcando com o dedo, ou não sei com que, fechei o livro, e com o rosto já tranqüilo, revelei a Alípio o que se passara. Ele, por sua vez, me revelou o que acontecera com ele, e que eu ignorava. Pediu para ver o que eu tinha lido; mostrei-lhe, ele prosseguiu a leitura. Eu ignorava o texto seguinte, que era este: Recebei ao fraco na fé, palavras que aplicou a si mesmo, e mo revelou. Fortificado por essa advertência, firmou-se nessa resolução e santo propósito, bem de acordo com seus costumes, nos quais já há muito tempo tomara grande vantagem sobre mim.

 Fomos depois à procura de minha mãe, que ao saber do sucedido, ficou radiante. Contamo-lhe como o caso se passara; ela exultou, triunfante e bendizendo a ti, que és poderoso para dar-nos mais do que pedimos ou entendemos, porque via que lhe havias concedido, a meu respeito, muito mais do que constantemente te pedia com tristes gemidos e lágrimas.

 De tal forma me converteste a ti, que já não procurava esposa, nem abrigava esperança alguma deste mundo, mas estava já naquela "regra de fé" em que há tantos anos me havias mostrado à minha mãe. E assim converteste seu pranto em alegria, muito mais fecunda do que havia desejado, e muito mais preciosa e pura do que a que podia esperar dos netos nascidos de minha carne.