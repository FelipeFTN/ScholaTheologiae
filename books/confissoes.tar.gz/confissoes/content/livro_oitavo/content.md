# LIVRO OITAVO

## CAPÍTULO I

### Hesitações

 Faze, meu Deus, que eu recorde de ti em ação de graças, e proclame tuas misericórdias para comigo. Que meus ossos se penetrem do teu amor, e digam: Senhor quem semelhante a ti? Rompeste com grilhões, e te oferecerei um sacrifício de louvor. Contarei como os rompeste, e todos os que te adoram exclamarão quando me ouvirem: "Bendito seja o Senhor no céu e na terra! Grande e admirável é seu nome!

 Tuas palavras, Senhor, tinham-me gravado profundamente em meu coração, e me via cercado apenas por ti de todos os lados. Tinha certeza de tua vida eterna, embora apenas a visse em enigma e como em espelho. Já fora dissolvida toda dúvida quanto à tua substância incorruptível, ao saber que toda substância procedia dela. E o que desejava não era tanto estar mais certo de ti, mas mais firme em ti.

 Quanto à minha vida temporal, estava eu ainda vacilante, e era necessário que meu coração se purificasse do velho fermento. O caminho certo, que é o próprio Salvador, me encantava, mas titubeava ainda em caminhar por seus estreitos desfiladeiros.

 Então me inspiraste a idéia – que me pareceu excelente – de me dirigir a Simpliciano, que eu tinha como um de teus bons servidores, em quem brilhava tua graça. Sobre ele ouvira também que desde sua juventude te consagrava devotamente sua vida, e como já encanecia, achei que em tão longa vida, dedicada ao estudo de teus caminhos, teria acumulado grande experiência e instrução; e de fato assim era. Por isso queria confiar-lhe minhas inquietações, para que me apontasse o modo de vida mais idôneo de alguém, com minhas disposições interiores, seguir teu caminho.

Vi tua Igreja cheia de fiéis que, por um caminho ou por outro, progrediam.

 Quanto a mim, aborrecia-me a vida que levava no mundo, e era para mim fardo pesadíssimo, agora que os apetites mundanos, como a esperança de honras e riquezas, já não me animavam para suportar tão pesada servidão. Essas paixões haviam perdido para mim o encanto, diante de tua doçura e da beleza de tua casa, que já amava. Mas sentia-me ainda fortemente amarrado à mulher. Sem dúvida o Apóstolo não me proibia de casar, embora em seu ardente desejo de ver todos os homens semelhantes a ele, exortasse a um estado mais elevado. Mas eu, ainda muito fraco, escolhia a condição mais fácil; por isso, vivia hesitando em tudo o mais, e me desgastava com preocupações enervantes, pois a vida conjugal, a que me julgava destinado e obrigado, ter-me-ia obrigado a novas incumbências, que eu não queria suportar.

 Ouvira da boca da própria Verdade que há eunucos que mutilavam a si próprios por amor ao reino dos céus, embora acrescentando que o compreenda quem o puder compreender. São vãos, por certo, todos os homens nos quais não reside a ciência de Deus, e que nas coisas visíveis não puderam achar aquele que é. Mas eu já me livrara dessa vaidade, já a havia ultrapassado, e pelo testemunho de tua criação, te encontrara a ti, nosso Criador, e a teu Verbo, Deus em ti, e contigo um só Deus, por quem criaste todas as coisas.

 Há ainda outra espécie de ímpios; os que, conhecendo a Deus, não o glorificam como Deus, nem lhe renderam graças. Eu também tinha caído nesse pecado; mas tua destra me amparou e libertou, colocando-me em lugar onde me pudesse curar; e disseste ao homem: Eis que a piedade é a sabedoria. E ainda: Não queiras parecer sábio, porque os que se dizem sábios tornaram-se insensatos.

 Já havia encontrado, finalmente, a pérola preciosa, que devia comprar vendendo tudo o que possuía. Mas ainda hesitava.

## CAPÍTULO II

### Visita a Simpliciano. Conversão de Vitorino

 Fui ter pois com Simpliciano, pai espiritual do então bispo Ambrósio, que o amava verdadeiramente como pai. Contei-lhe os labirintos do meu erro. E quando lhe disse que havia lido alguns livros dos platônicos, traduzidos para o latim por Vitorino, outrora retórico em Roma – e do qual ouvira dizer que morrera cristão – ele me felicitou por não ter caído nas obras de outros filósofos, falazes e enganosas, segundo os elementos deste mundo, mas apenas estes, que insinuam por mil modos a Deus e a seu Verbo.

 Depois, para me exortar à humildade de Cristo, escondida aos sábios e revelada aos humildes, evocou a lembrança do próprio Vitorino, que conhecera intimamente, quando estava em Roma. Não guardarei silêncio sobre o que me contou dele, porque me dará azo de proclamar os grandes louvores de tua graça a seu respeito. Esse erudito ancião, profundo conhecedor de todas as ciências liberais, leitor e crítico de tantos livros de filosofia, fora mestres de muitos nobres senadores. O prestígio de seu magistério lhe valera uma estátua no foro romano, que ele aceitara (coisa que os cidadãos desse mundo têm em grande conta). Até aquela idade avançada, havia adorado os ídolos, participando de cultos sacrílegos, de que participava quase toda a nobreza romana da época que inspirava ao povo sua devoção por Osíris, por "toda sorte de monstros divinizados, pelo labrador Anúbis", monstros que outrora "pegaram em armas contra Netuno, Vênus e Minerva", e a quem, vencidos, a própria Roma dirigia súplicas, esse velho Vitorino, que durante tantos anos havia defendido esses deuses com sua terrível eloqüência, não se envergonhou de se tornar servo de teu Cristo e criança de tuas águas, dobrando o pescoço ao jugo da humildade, e dobrando sua fronte ante o opróbrio da cruz.

 Senhor, Senhor, que inclinaste os céus e o desceste, que tocaste os montes e estes fumegaram, de que modo te insinuaste naquele coração?

 Segundo contou-me Simpliciano, Vitorino lia as Escrituras e investigava e esquadrinhava com grande curiosidade toda a literatura cristã, e confiava a Simpliciano, não em público, mas muito em segredo e familiarmente: "Sabes que já sou cristão?" Ao que respondia aquele: "Não hei de acreditar, nem te contarei entre os cristãos enquanto não te vir na Igreja de Cristo". Mas ele ria e dizia: "Serão pois as paredes que fazem os cristãos?" E isto, de que já era cristão, o dizia muitas vezes, contestando-lhe Simpliciano outras tantas vezes com a mesma resposta, opondo-lhe sempre Vitorino o gracejo das paredes.

 Vitorino receava desgostar a seus amigos, os soberbos adoradores dos demônios, julgando que estes, de alto de sua babilônica dignidade, como cedros do Líbano, ainda não abatidos pelo Senhor, fariam cair sobre ele suas pesadas inimizades.

 Mas depois que hauriu forças nas leituras e orações, temeu ser renegado por Cristo diante de seus anjos, se tivesse medo de o confessar diante dos homens. Sentiu-se réu de um grande crime por se envergonhar dos mistérios de humildade de teu Verbo, não se envergonhando do culto sacrílego de demônios soberbos, que ele próprio aceitara como soberbo imitador; envergonhou-se da vaidade, e enrubesceu diante da verdade. De repente, disse a Simpliciano, segundo este mesmo contava: "Vamos à Igreja; quero me tornar cristão". Simpliciano, não cabendo em si de alegria, foi com ele. Recebidos os primeiros sacramentos da religião, não muito depois, deu seu nome para receber o batismo que renegara, causando admiração em Roma e alegria na Igreja. Viram-no os soberbos, e se iraram; rangiam os dentes e se consumiam de raiva. Mas teu servo havia posto no Senhor Deus sua esperança, e não tinha mais olhos para as vaidades e as enganosas loucuras.

 Enfim, chegou a hora da profissão de fé. Em Roma, os que se preparam para receber tua graça, pronunciam de um lugar elevado, diante dos fiei, formulas consagradas aprendidas de cor. Os presbíteros, dizia-me Simpliciano, propuseram a Vitorino que recitasse a profissão de fé em segredo, como era costume fazer com os que poderiam se perturbar pela timidez. Mas ele preferiu confessar sua salvação na presença da plebe santa, uma vez que nenhuma salvação havia na retórica que ensinara publicamente. Quanto menos, pois, devia temer diante de tua mansa grei pronunciar tua palavra, ele que não havia temido as turbas insanas em seus discursos!

 Assim, logo que subiu à tribuna para dar testemunho da sua fé, em uníssono, conforme o iam conhecendo, todos repetiram seu nome como num aplauso – e quem ali não o conhecia? – e um grito reprimido, saiu da boca de todos os que se alegravam: "Vitorino! Vitorino!" Ao verem-no, se puseram a gritar de júbilo, mas logo emudeceram pelo desejo de ouvi-lo. Vitorino pronunciou sua profissão de verdadeira fé com grande firmeza, e todos queriam raptá-lo para dentro de seus corações. E realmente o fizeram: seu amor e alegria eram as mãos que o arrebatavam.

## CAPÍTULO III

### A alegria das coisas perdidas

 Bom Deus, que se passa no homem para que se alegre mais com a salvação de uma alma desesperada, quando salva de grande perigo, do que se ela sempre tivesse tido esperança, ou se o perigo tivesse sido menor? Também tu, Pai misericordioso, sentes mais alegria por um pecador arrependido do que por noventa e nove justos que não têm necessidade de penitência. Grande é o nosso prazer ao falar da alegria do pastor trazendo de volta sobre os ombros a ovelha desgarrada, e da mulher que repõe em teus tesouros, para satisfação geral dos vizinhos, a dracma perdida. E nos arranca lágrimas a alegria das festas de tua casa quando lemos que teu filho menor estava morto e reviveu; estava perdido e foi encontrado.

 Tu te alegras em nós e em teus anjos, santificados pelo santo amor; pois és sempre o mesmo, e conheces do mesmo modo e sempre as coisas que nem sempre existem, nem da mesma maneira.

 Mas, que se passa na alma, para que se alegre mais com as coisas que estima, encontradas ou reavidas, do que se sempre as tivesse possuído? Na verdade, tudo o atesta, e há inúmeros testemunhos que afirmam: "É assim mesmo!"

 O general celebra o triunfo da vitória, e não teria vencido sem combate; e quanto mais foi árdua a batalha, tanto maior é o gozo no triunfo.

 A tempestade cai sobre os navegantes com ameaça de naufrágio. Todos empalidecem diante da morte iminente. O céu e o mar se acalmam, é grande sua alegria, e nasce do muito que temeram.

 Adoece uma pessoa amiga: seu pulso revela um desfecho fatal. Todos os que desejam sua cura sofrem com ela, por simpatia. Havendo melhora, embora ainda não recuperado o vigor de outrora, já reina tal alegria como não existia antes, quando andava sadia e forte.

 Até os prazeres da vida humana, não só compensam os homens de desgraças casuais e involuntárias, mas também de moléstias premeditadas e desejadas. Não há prazer algum em beber ou comer sem que haja antes o estímulo da sede ou da fome. Os ébrios costumam comer antes alguma coisa salgada, que lhes cause sede ardente e que transformará em prazer quando acalmada com a bebida. O costume quer que as esposas não sejam entregues imediatamente aos maridos: o marido desprezaria a noiva se não tivesse que esperar e suspirar por ela.

 Assim ocorre tanto na alegria torpe e vil, como na alegria lícita e permitida, na mais sincera e honesta amizade, como na aventura daquele que estava morto e tornou a viver, que se havia perdido e foi encontrado; em todos os casos uma alegria maior é precedida de uma dor também maior.

 Por que isto, Senhor, meu Deus, quando tu mesmo és tua própria alegria eterna, e as criaturas à tua volta em ti se alegram? Por que esta parte do universo sofre as alternâncias de progressos e quedas, de uniões e separações? Será este o modo de ser que lhe concedeste quando, do mais alto dos céus até às profundezas da terra, desde o princípio dos tempos até o fim dos séculos, desde o anjo até o pequenino verme, e desde o primeiro movimento até o último, dispuseste todos os gêneros de bens e todas as tuas obras justas, cada uma em seu lugar e tempo?

 Ai de mim! Quão alto és nas alturas e quão profundo nos abismos! Jamais te afastas de nós e, contudo, quanta dificuldade para voltar a ti!

## CAPÍTULO IV

### A conversão dos grandes

 Vamos pois, Senhor, mãos à obra! Desperta-nos, chama-nos, inflama-nos, arrebata-nos; derrama tuas doçuras, encanta-nos: amemos, corramos!

 Não é verdade que muitos voltam a ti, saindo de um abismo de cegueira mais profundo que o de Vitorino, e se aproximam de ti, e são iluminados pela tua luz, junto da qual recebem o poder de se fazerem teus filhos?

 Mas se estes são menos conhecidos pelo mundo dos homens, mesmo os que os conhecem se alegram menos; mas quando a alegria é partilhada por muitos, ainda é maior em cada um, porque se aquece e inflama de uns para os outros.

 Ademais, os que são conhecidos de muitos, arrastam à salvação muitos outros, e caminham adiante seguidos dos que os imitam. Por isso, grande é a alegria dos que os precederam, por que não se regozijam só consigo.

 Mas, longe de mim pensar que no teu tabernáculo são mais aceitos os ricos que os pobres, e os nobres mais do que os plebeus, porque escolheste os fracos segundo o mundo para confundir os fortes; o que é vil e desprezível segundo o mundo, a que não é nada, para aniquilar o que é.

 Contudo, o menor de teus apóstolos, por cuja boca pronunciaste essas palavras, quando suas armas abateram o orgulhoso procônsul Paulo, sujeitando-o ao leve jugo de teu Cristo e fizeram dele um súdito do grande Rei, quis, parar comemorar tão grande triunfo, mudar seu nome de Saulo pelo de Paulo. De fato, o adversário é mais completamente vencido naquilo em que tinha maior domínio e por meio do que retém maior número de sequazes. Ora, o inimigo domina com mais força os soberbos pela nobreza de seu nome e, graças a estes, número maior pelo prestígio de sua autoridade.

 Assim, na medida em que o coração de Vitorino era tido como fortaleza inexpugnável antes ocupada pelo demônio, e sua língua como dardo poderoso e agudo, que tantas vezes havia dado a morte às almas, tanto mais copiosamente deviam exultar teus filhos, ao verem que nosso Rei agrilhoara o forte, e que seus vasos roubados, eram agora purificados e destinados à tua honra, convertendo-se em instrumentos úteis ao Senhor para toda obra boa.

## CAPÍTULO V

### As duas vontades

 Mal teu servo Simpliciano me contou a conversão de Vitorino, ardi no desejo de imitá-lo; aliás, era esta a finalidade da narração de Simpliciano. Depois acrescentou que nos tempos do imperador Juliano, uma lei proibia aos cristãos ensinar literatura e oratória, e Vitorino, dócil à lei, preferiu abandonar a escola de palradores a abandonar teu Verbo, que torna eloqüentes as línguas dos meninos. Não só me pareceu corajoso como afortunado, por ter encontrado ocasião de se consagrar por ti. Por isso eu suspirava, acorrentado não com os ferros de uma vontade estranha, mas por minha férrea vontade.

 O inimigo dominava meu querer, e dele forjava uma corrente com a qual me mantinha cativo. Da vontade perversa nasce a paixão, e desta satisfeita procede o hábito, e do hábito não contrariado provém a necessidade, e com estes anéis enlaçados entre si – por isso lhes chamei corrente – me mantinha preso em dura servidão. A nova vontade, que despontava em mim, de te servir sem interesse, de me alegrar em ti, ó meu Deus, única alegria verdadeira, ainda não era capaz de vencer a vontade antiga e inveterada. Deste modo minhas duas vontades, a velha e a nova, a carnal e a espiritual, lutavam entre si e, nessa luta, dilaceravam-me a alma.

 Entendi, por experiência própria, o que havia lido: a carne tem desejos contra o espírito, e o espírito contra a carne. Eu vivia ao mesmo tempo a ambos, embora mais o que aprovava em mim do que o que em mim desaprovava. Com efeito, nesta última parte de mim eu era passivo e constrangido, mais do que ativo e livre.

 E,contudo, o hábito que se impunha contra mim vinha de mim mesmo, pois fora voluntariamente que eu chegara onde não queria. E quem poderia protestar legitimamente, se um castigo justo segue o pecador?

 Eu já não tinha aquela desculpa, com a qual persuadia-me de que, se ainda não desprezava o mundo para te servir, era porque não tinha visão clara da verdade, uma vez que agora já a conhecia de modo indiscutível. Mas, ainda apegado à terra, recusava-me a combater em tuas fileiras, e temia ver-me livre dos meus laços, quando devia temer estar por eles atado.

 Assim, sentia-me docemente oprimido pelo peso do mundo, como em um sonho, e os pensamentos com que meditava em ti eram semelhantes aos esforços dos que desejam despertar, mas, vencidos pela sonolência, voltam dormir. Não há ninguém que queira dormir sempre, e segundo dita o bom senso, é melhor estar desperto que dormir. Contudo, às vezes retarda-se o despertar, quando o torpor torna os membros pesados, e, mesmo a contragosto, continua-se a dormir mesmo depois de chegada a hora de despertar. Assim eu estava certo que era melhor entregar-me a teu amor que ceder à minha paixão. O primeiro me agradava, me dominava; o segundo me encantava, me prendia.

 Já não tinha o que responder quando me dizias: "Desperta, ó tu que dormes, levanta-te de entre os mortos, e Cristo te há de iluminar". E quando por todos os meios me mostrava a verdade do que dizias, e de que eu estava convencido, não tinha absolutamente nada para responder, senão umas palavras preguiçosas e sonolentas: Um momento... Depois... Um pouquinho mais... Mas este pouquinho não tinha fim, e este momento se ia prolongando.

 Em vão me deleitava em tua lei, segundo o homem interior, porque em meus membros outra lei combatia a lei de meu espírito, mantendo-me cativo sob a lei do pecado que estavas em meus membros. Com efeito, a lei do pecado é a violência do hábito, pelo qual a alma é arrastada e presa, mesmo contra sua vontade, merecidamente porém, pois se deixa arrastar por vontade própria. Pobre de mim! Quem poderia libertar-me deste corpo de morte senão tua graça, por Cristo, nosso Senhor?

## CAPÍTULO VI

### A narração de Ponticiano

 Agora contarei de que modo me arrancaste do vínculo do desejo carnal, que me prendia fortemente, e da servidão dos negócios do mundo, e confessarei teu nome, ó Senhor, meu auxílio e minha redenção. Levava minha vida habitual com angústia crescente; todos os dias suspirava por ti, freqüentava tua igreja, quando me deixavam livre os negócios, cujo peso me fazia sofrer.

 Comigo estava Alípio, desonerado do cargo de jurisconsulto, depois de ter sido assessor pela terceira vez. Ele aguardava a quem vender de novo seus conselhos, como eu vendia arte da eloqüência, se é que pelo ensino a podemos transmitir.

 Nebrídio, por sua vez, acendendo às nossas solicitações amigas, auxiliava na escola a nossa amigo íntimo, Verecundo; este, gramático e cidadão milanês, desejava enormemente, e nos instava em nome da amizade, que um de nós lhe prestasse uma fiel colaboração, pois dela muito necessitava.

 Não foi, pois, o interesse que moveu a Nebrídio – que poderia auferir bem mais vantagens se ensinasse as letras – mas, como grande amigo que era, não quis recusar nosso pedido em obsequio à amizade. Agia, porém, com muita prudência, evitando fazer-se conhecido dos poderosos deste mundo, para evitar as inquietações do espírito que ele queria manter o mais possível livre e desocupado para investigar, ler ou ouvir algo sobre a sabedoria.

 Certo dia em que Nebrídio estava ausente, não sei por que motivo, Alípio e eu recebemos a visita de um tal Ponticiano, nosso compatriota da África, que servia em alto cargo do palácio. Não sei mais o que queria de nós.

 Sentamo-nos para conversar, e, por acaso, deu com os olhos em um livro que estava sobre a mesa de jogo, à nossa frente. Pegou-o, abriu-o, viu que eram as epístolas de Paulo e ficou surpreso, pois pensava que se tratasse de algum dos livros cujo estudo me preocupava. Então sorriu para mim e, cumprimentando-me, manifestou-me sua admiração por ter encontrado aquele livro, e só aquele, ao alcance dos meus olhos. Ponticiano era um cristão fiel, e muitas vezes prostrava-se diante de ti, nosso Deus, na igreja, em freqüentes e prolongadas orações.

 E quando lhe declarei que aquele livro ocupava o melhor de minha atenção, tomando a palavra, começou a falar-nos de Antão, monge do Egito, cujo nome era celebrado entre teus fiéis, mas que nós desconhecíamos até aquela hora. Informado disto, continuou a falar, revelando esse grande homem à nossa ignorância, que ele muito admirou.

 Ouvíamos, estupefatos, tuas autenticas maravilhas, realizadas na verdadeira fé, na Igreja Católica, tão recentes e quase contemporâneas. Todos nos admirávamos; nós, por serem coisas tão grandes; e ele, por ser-nos tão desconhecidas.

 Depois, passou a falar das multidões que vivem em mosteiros, e de seus costumes, que trazem teu doce perfume, e da fecunda solidão do ermo, coisas todas que desconhecíamos.

 Até em Milão havia, fora dos muros, um mosteiro cheio de bons irmãos sob a direção de Ambrósio, que também desconhecíamos.

 Ponticiano prosseguia, e falava sempre mais, e nós o ouvíamos atentos e calados. E assim veio a nos contar que um dia, não sei quando, estando em Tréveris, saiu em companhia de três companheiros, enquanto o imperador se concentrava nos jogos circenses da tarde, para dar um passeio pelos jardins que rodeavam os muros da cidade. Distraidamente passeando dois a dois, um com Ponticiano, e os outros dois juntos, separaram-se e tomaram caminhos diferentes.

 Caminhando a esmo, estes últimos deram com uma cabana, habitada por alguns servos teus, pobres de espírito, a quem pertence o reino dos céus. Lá encontraram um exemplar manuscrito da Vida de Santo Antão. Um deles começou a lê-lo, e, admirado e arrebatado cogitou, enquanto lia, em abraçar aquele gênero de vida, abandonando o serviço do mundo, para servir unicamente a ti.

 Estes dois eram os chamados agentes de negócios do imperador. De repente, tomado de amor santo e casto pudor, irado consigo mesmo, olha para o companheiro, e lhe diz: "Dize-me, te peço, onde pretendemos chegar com todos estes nossos trabalhos? Que buscamos? Qual a finalidade do nosso labor? Podemos aspirar mais no palácio do que ser amigos do imperador? E mesmo nisto, quanta incerteza, quantos perigos! E quantos perigos teremos de passar para chegar a um perigo ainda maior? E quando chegaremos a isso? Mas, se eu quiser ser amigo de Deus, posso sê-lo agora mesmo". Disse essas palavras, e exaltado pela gestação da nova vida voltou os olhos para o livro; ao ler, transformava-se interiormente, o que só tu sabias, e seu espírito se despia do mundo, como logo se evidenciou.

 Enquanto lia, o coração se lhe tornou um mar tempestuoso, sentiu um estremecimento e, intuindo o melhor caminho a tomar, resolveu abraçá-lo, dizendo ao amigo:

 "Já rompi com nossos sonhos: decidi dedicar-me ao serviço de Deus, e isso quero começar aqui e agora. Se não me queres imitar, ao menos não me contraries".

 O amigo respondeu que desejava ficar com ele, e ser companheiro de tão nobre mercê e de tão grande combate. Ambos já te pertenciam, e começavam a construir, com capital suficiente, uma torre de salvação, a tudo renunciando para te seguir.

 Então Ponticiano e seu companheiro, que passeavam em outro local do jardim, procurando-os, deram também com a mesma cabana, e os avisaram para que voltassem, pois já entardecia. Mas eles, relataram-lhes sua determinação e propósito, e o modo como nascera e se fixara neles tal desejo, pediram-lhes que, se não quisessem juntar-se a eles, que não os molestassem. Mas estes, sem se converterem, lamentaram a si mesmos, no dizer de Ponticiano, e felicitando-os piedosamente, recomendaram-se às suas orações; depois, arrastando o coração pela terra, voltaram ao palácio, enquanto que os convertidos, fixando seu coração no céu, ficaram na cabana.

 Ambos eram noivos; mas, quando suas noivas ouviram o sucedido, também te consagraram sua virgindade.

## CAPÍTULO VII

### A reação de Agostinho

 Eis o que Ponticiano nos relatou. E tu, Senhor, enquanto ele falava, me fazias refletir, tirando-me da posição de costas, em que me colocara para não me ver a mim mesmo. Tu me colocavas diante de meu próprio rosto para que visse como estava indigno, disforme, sórdido, manchado e ulceroso.

 Eu me via, e enchia-me de horror, mas não tinha para onde fugir de mim mesmo. Se tentava afastar o olhar de mim mesmo, Ponticiano prosseguia com a narração, e de novo me punhas diante de mim, e me empurravas diante de meus olhos, para que eu descobrisse minha iniqüidade e a odiasse. Eu bem a conhecia, mas a dissimulava, fingia não ver, esquecia.

 E quanto mais ardentemente amava aqueles jovens, cuja salutar decisão ouvia relatar, por se terem entregue completamente a ti para que os curasses, tanto mais acerbamente me odiava ao me comparar com eles. Com efeito, já tinham decorrido muitos anos – talvez uns doze – desde que, ao dezenove anos, lendo o Hortênsio de Cícero, sentira-me atraído para o estudo da sabedoria. Ia adiando a hora de abandonar a felicidade meramente terrena, quando não somente a sua descoberta, mas a sua própria busca, deveria ser preferida aos maiores tesouros do mundo e aos maiores prazeres corporais, que a um aceno, afluíam a meu redor.

 Mas eu, jovem miserável, sim, miserável desde o despertar da juventude, já te havia pedido a castidade, dizendo: "Dá-me castidade e continência, mas não agora" – pois temia que me atendesse muito depressa, e que me curasses logo da doença de minha concupiscência, que eu mais queria saciar do que extinguir. E caminhei pelas sendas ruins de uma superstição sacrílega, não porque estivesse certo dela, mas porque a preferia às demais doutrinas, que eu não estudava piedosamente, mas que hostilmente combatia.

 Acreditava que o motivo por que adiava dia a dia o desprezo das promessas seculares, para seguir apenas a ti, era o não ter descoberto uma claridade capaz de dirigir meus passos. Veio, então, o dia em que me vi nu, a ouvir as repreensões de minha consciência: "Onde está a tua palavra? Não dizias que tua indecisão para lançar longe o fardo de tua vaidade se devia à incerteza? Agora tens a certeza, e não obstante, ainda te oprime esse fardo; outros, no entanto, que não se consumiram tanto em procurá-la, nem meditaram dez anos ou mais sobre tais problemas, vêem nascer asas em seus ombros mais livres".

 Assim me roia interiormente, devorado por enorme e terrível vergonha, enquanto Ponticiano contava aquilo tudo. Finda a conversa, e resolvida a questão a que viera, Ponticiano voltou para sua casa, e eu para dentro de mim. Que coisas não disse contra mim? Com que açoite de palavras não flagelei minha alma, para obrigá-la a me seguir em meus esforços para te alcançar! Ela resistia, recusava-se, sem se desculpar. Todos os argumentos já estavam esgotados e refutados. Nada lhe restava, senão uma angústia muda: tinha medo, como da morte, de ser tolhida à corrente do vício, onde se corrompia mortalmente.

## CAPÍTULO VIII

### Luta espiritual

 Então, em meio àquela luta interior que eu travava violentamente contra mim mesmo no recesso do meu coração, perturbado no rosto e no espírito, volto-me para Alípio exclamando: "Que tanto nos aflige? O que significa isto que ouviste? Levantam-se os ignorantes e arrebatam o céu, e nós, com todo nosso saber insensato, nos revolvemos na carne e no sangue! Acaso temos vergonha de segui-los porque se nos adiantaram, e não temos vergonha de não os seguir?"

 Foi mais ou menos o que eu lhe disse, e dele me afastei sob forte emoção. Alípio me olhava atônito em silêncio. Eu não falava como de costume, e muito mais que as palavras, minha fronte, minhas fazes, meus olhos, minha cor e o tom de minha voz denunciavam meu estado de espírito.

 Nossa casa tinha um pequeno jardim, que usávamos, assim como o restante da casa, que nosso hóspede não habitava. Para ali me levara a tormenta de meu coração, onde ninguém pudesse interferir no ardente combate que eu travava comigo mesmo, até que se resolvesse o assunto conforme tu sabias e eu ignorava. Mas eu delirava para reencontrar a razão, e morria para reviver; conhecia meu mal, mas desconhecia o bem que depois haveria de sobrevir.

 Retirei-me, pois, para o jardim, e Alípio seguiu-me passo a passo; mas, apesar de sua presença, eu não estava menos só. E como haveria ele de me deixar naquele estado? Sentamonos o mais longe possível da casa. Eu tremia pela violenta indignação, me enraivecia por não poder seguir teu agrado e aliança, ó meu Deus, aliança pela qual clamavam todos os meus ossos, que te elevavam louvores até o céu. E para ir a ti não há necessidade de navios nem de carros, nem mesmo de dar aqueles poucos passos que separavam a casa do jardim onde estávamos. Não somente ir, mas chegar junto de ti, nada mais é do que querer ir, mas com querer enérgico e pleno, e não com vontade tíbia, que se dispersa em todos os sentidos, e se agita incerta, dividida, ora levantando-se, ora voltando a cair.

 Enfim, naquela angustiante hesitação, fazia mil gestos, como soem fazer os homens que querem e não podem, ou porque não têm membros, ou porque os têm atados em cadeias, debilitados pela fraqueza ou paralisados de qualquer outro modo. Se puxei os cabelos, se feri a fronte, se apertei os joelhos entre os dedos entrelaçados, eu o fiz porque quis. Poderia porém querer fazê-lo e não o fazer, se a flexibilidade de meus membros não me obedecesse. Portanto, fiz muitas coisas, nas quais o querer não era o mesmo que o poder.

 Contudo, eu não fazia aquilo que desejava acima de tudo o mais, e que eu poderia fazer desde que o quisesse, porque se o tivesse efetivamente querido, bastava que o quisesse sinceramente; nisto o poder é o mesmo que o querer, e querer já seria agir.

 Contudo não o fazia, e meu corpo obedecia mais facilmente ao mais leve comando de minha alma, movendo os membros segundo sua vontade, do que a própria alma obedecer a si mesma para realizar seu grande desejo com a vontade.

## CAPÍTULO XI

### A desobediência da vontade

 Mas, de onde vinha este prodígio? Qual sua causa? Brilhe a tua misericórdia, e perguntarei – se é que me podem responder – aos sombrios castigos infligidos aos homens, e às tenebrosas misérias dos filhos de Adão. De onde vem este prodígio? E qual sua causa?

 A alma dá ordens ao corpo, e este obedece imediatamente; a alma dá ordens a si mesma, e resiste. Ordena a alma à mão que se mova, e é tal sua presteza, que mal se pode distinguir a ordem da execução; não obstante, a alma é espírito e a mão é corpo. A alma dá a si mesma a ordem de querer, uma não se distingue da outra, e contudo, ela não obedece. De onde este prodígio? E qual sua causa?

 Manda a alma que queira – e não mandaria se não quisesse – e, não obstante, não faz o que manda. Logo, não quer totalmente, e por isso não manda de modo total. A alma manda na proporção do querer, e enquanto não quiser, suas ordens não são executadas, porque é a vontade que dá a ordem de ser a uma vontade que nada mais é que ela própria. Logo, não manda plenamente, e esta é a razão por que não faz o que manda. Porque, se estivesse em sua plenitude, não mandaria que fosse, porque já seria.

 Não há, portanto, prodígio algum em querer em parte e em parte não querer; é uma enfermidade da alma. esta, sustentada pela verdade, não se ergue de todo, pois está oprimida pelo peso do hábito. Há, portanto, duas vontades, ambas incompletas, e o que uma possui falta à outra.

## CAPÍTULO X

### Contra os maniqueus

 Desapareçam de tua presença, ó meu Deus, como os vãos faladores e sedutores do espírito, aqueles que, ao observarem a dupla deliberação da vontade, concluem que temos duas almas de naturezas opostas, uma boa, outra má.

 Eles é que são de fato maus, que seguem tais más doutrinas; somente serão bons quando aceitarem a verdade, concordando com os que a possuem. E assim o Apóstolo poderá dizer deles: Outrora fostes trevas, mas agora sois luz no Senhor. Mas esses, querendo ser luz não no Senhor, mas em si mesmos, julgam que a natureza da alma á a mesma que a de Deus; vão-se tornando trevas ainda mais densas, pois em sua terrível arrogância se afastam ainda mais de ti, luz verdadeira, que ilumina a todo homem que vem a este mundo. Atentai para o que dizeis, e enchei-vos de vergonha. Aproximai-vos dele, e sereis iluminados, e vossos rostos não serão cobertos de confusão.

 Quando eu deliberava dedicar-me ao serviço do Senhor meu Deus, como de há muito me tinha proposto, eu era o que eu queria, e lera o que eu não queria. Mas, nem queria plenamente, nem deixar de querer por completo. Por isso lutava comigo mesmo, e me dilacerava a mim mesmo. Essa destruição, embora involuntária, não mostrava, contudo, a presença em mim de uma alma estranha, mas apenas o castigo de minha alma. E por isso já não era eu quem mo infligia, mas o pecado que habitava em mim, como castigo de pecado cometido livremente, por ser eu filho de Adão.

 Com efeito, se fossem tantas as naturezas contrárias quantas são as vontades que em nós se contradizem, não deveríamos admitir apenas duas naturezas, mas muitas. Se alguém, com efeito, hesita entre uma reunião dos maniqueístas ou ao teatro, logo eles exclamam: "Eis aí as duas naturezas, uma boa, que o atrai para cá, e outra má, que o arrasta pra lá. E de onde mais viria essa hesitação de vontades opostas?"

 De minha parte eu digo que ambas são más, tanto a que leva a eles como a que arrasta ao teatro; mas eles só julgam boa a que leva até eles.

 Mas, suponhamos que um dos nossos queira decidir, e conflitando as duas vontades, titubeie entre ir ao teatro ou à nossa igreja; não ficarão indecisos os maniqueístas na resposta que hão de dar? Porque, ou hão de confessar o que não querem, que é boa a vontade que o leva à nossa igreja, como vão a ela os que foram iniciados em seus mistérios e lhe permanecem fiéis, ou terão de reconhecer que num mesmo homem lutam duas naturezas más e duas almas más. E então terão de contradizer o que afirmam, que uma natureza é boa e outra má. Ou então terão de aceitar a verdade e, neste caso, não negarão que, quando alguém escolhe, é uma mesma alma a que hesita entre duas vontades opostas.

 Portanto, quando virem duas vontades que se contrapõem ao mesmo homem, não falem mais de luta entre duas almas contrárias, uma boa e outra má, originadas em duas substâncias antagônicas. Porque tu, ó Deus verdadeiro, os confundes, como no caso em que ambas as vontades são más; por exemplo, quando alguém hesita, entre matar a outrem com um punhal ou veneno; entre assaltar esta ou aquela propriedade alheia, quando não pode assaltar a ambas; entre esbanjar na compra do prazer da luxúria, ou guardar dinheiro por avareza; entre ir ao circo ou ao teatro, quando ambos sejam concomitantes; e ainda acrescento uma terceira incerteza: entre roubar ou não a casa do próximo, em havendo a oportunidade, ou ainda, acrescento uma quarta hipótese: entre cometer ou não adultério, se tem possibilidade para isso. Suponhamos que todas essas circunstâncias ocorram simultaneamente; como todas são igualmente desejadas, e irrealizáveis ao mesmo tempo, a alma será dilacerada por um conflito entre quatro vontades, ou mais ainda, tão numerosos são os objetos de desejo! Contudo, os maniqueus não afirmam que existe tão grande número de substâncias diferentes.

 O mesmo acontece com as vontades boas. Se eu lhes pergunto se é bom deleitar-se com a leitura do Apóstolo, com a leitura de algum salmo espiritual, ou com o comentar do Evangelho, eles responderão a cada questão: "É bom" – Ora, se as três atividades têm a mesma atração simultaneamente, não teríamos vontades opostas a dividir o coração do homem, enquanto escolhe qual delas abraçar de preferência?

 Todas essas vontades são boas, e lutam entre si, até que se tome uma decisão, que unifique a vontade, antes dividida. Assim também, quando a eternidade agrada à nossa parte superior e o bem temporal nos prende fortemente cá embaixo: é a mesma alma que, sem uma vontade plena, quer um e outro desses bens. Por isso, dilacera-a uma grande dor; a verdade nos faz preferir a eternidade, mas o hábito não quer abandonar os bens temporais.

## CAPÍTULO XI

### Últimas resistências

 Assim sofria e me atormentava, com acusações mais acerbas que de costume, rolando-me e debatendo-me dentro de minha cadeias, para ver se as quebrava por completo. Elas mal me prendiam,mas ainda me prendiam. E tu, Senhor, me espicaçavas no fundo de minha alma, e com severa misericórdia redobravas os açoites do temor e da vergonha, para que eu não afrouxasse de novo, e para que quebrasse minha tênue e leve cadeia, antes que ela se revigorasse para me prender mais firmemente.

 E dizia comigo mesmo: "Vamos! Mãos à obra, sem demoras!" E quase passava da palavra à ação. Estava a ponto de agir, mas não agia. Eu já não recaía nas antigas paixões, mas delas estava bem próximo, e tomava ainda alento de seu ar. Quase a alcançava, faltava pouco, cada vez menos, e já quase chegava ao termo e a segurava; mas não a alcançava, nem a tocava; hesitava entre morrer para a morte e viver para a vida. O mal arraigado dominava-me mais do que o bem, cujo hábito eu não possuía; na medida que ia se aproximando o momento em que me transformaria em outro homem, maior era o horror que me incutia, sem contudo me fazer voltar para trás ou mudar de caminho. Simplesmente mantinha-me indeciso.

 Mantinham-me preso umas tantas bagatelas, umas vaidades de vaidades, antigas amigas minhas, que me puxavam por minhas vestes carnais, murmurando: "Então, nos abandonas? De agora em diante nunca mais estaremos contigo? Desde este momento nunca mais te será lícito isto ou aquilo?"

 E que coisas, meu Deus, que torpezas me sugeriam com o que chamei de isto ou aquilo! Por tua misericórdia, afasta-as da alma de teu servo! Oh! Que imundícies me sugeriam, que indecências! Já se reduzira a menos da metade o número de vezes que eu lhes dava ouvidos; não era mais um assalto aberto, frontal, mas segredado por cima dos ombros, e como que puxando-me furtivamente, se me afastava, para que me voltasse para trás.

 Contudo, faziam com que eu, vacilante, tardasse em me separar delas para correr para onde me chamavam, enquanto o hábito violento me dizia: "Julgas que poderás viver sem elas?"

 Mas isto já dizia com voz muito débil. Para onde voltava o rosto, e por onde temia passar, mostrava-se para mim a casta dignidade da continência, serena e alegre, sem desordens, acariciando-me honestamente para que me aproximasse sem medo. Estendia para mim, para me acolher e abraçar, suas mãos piedosas, cheias de uma multidão de bons exemplos.

 Junto dela, uma turba de meninos e meninas, uma juventude numerosa, e homens de toda idade, viúvas veneráveis e virgens idosas. Em todas essas almas, não era estéril, mas fecunda a mãe de filhos nascidos nas alegrias do esposo, que eras tu, Senhor!

 E a continência zombava de mim com ironia animadora, como se dissesse: "Então, não serás capaz de fazer o mesmo que eles? Ou será que estes e estas encontraram forças em si mesmos, e não no Senhor, seu Deus? Foi o Senhor Deus, quem me entregou a eles. Por que te apóias em ti, se és vacilante? Lança-te nele, não temas, que ele não se apartará de ti, e tu não cairás. Lança-te com confiança, que ele te receberá e te curará."

 E enchia-me de vergonha por ainda ouvir o murmúrio daquelas bagatelas e, vacilante, continuava indeciso.

 Mas de novo a voz da castidade parecia me dizer: Não dês ouvidos às tentações imundas da tua carne impura que te prende à terra, a fim de que seja mortificada. Ela te fala de deleites, contrários porém, à lei do Senhor teu Deus.

 Essa luta se desenrolava no fundo do meu espírito, de mim contra mim mesmo. Alípio, sem sair de perto de mim, aguardava em silêncio o desfecho de minha insólita agitação.

## CAPÍTULO XII

### A conversão

 Mas logo que esta profunda reflexão tirou da profundeza de minha alma, e expôs toda minha miséria à vista de meu coração, caiu sobre mim enorme tormenta, trazendo copiosa torrente de lágrimas. E para dar-lhe toda vazão com seus gemidos, afastei-me de Alípio; a solidão parecia-me mais adequada e me afastei o mais longe possível, para que sua presença não me fosse embaraçosa. Tal era o estado em que encontrava, e Alípio percebeu-o, pois lhe disse alguma coisa com um timbre de voz embargado de lágrimas que me denunciou.

 Alípio, atônito, continuou no lugar em que estávamos sentados; mas eu, não sei como, me retirei para a sombra de uma figueira, e dei vazão às lágrimas; e dois rios brotaram de meus olhos, sacrifício agradável a teu coração. E embora não com estes termos, mas com o mesmo sentido, muitas coisas te disse como esta: E tu, Senhor, até quando? Até quando, Senhor, hás de estar irritado! Esquece-te de minhas iniqüidades passadas! Sentia-me ainda preso a elas, e gemia, e lamentava: "Até quando? Até quando direi amanhã, amanhã? Por que não agora? Por que não pôr fim agora às minhas torpezas?"

 Assim falava, e chorava oprimido pela mais amarga dor do meu coração. Mas eis que, de repente, ouço da casa vizinha uma voz, de menino ou menina, não sei, que cantava e repetia muitas vezes: "Toma e lê, toma e lê".

 E logo, mudando de semblante, comecei a buscar, com toda a atenção em minhas lembranças se porventura esta cantiga fazia parte de um jogo que as crianças costumassem cantarolar; mas não me lembrava de tê-la ouvido antes. Reprimindo o ímpeto das lágrimas, levantei-me. Uma só interpretação me ocorreu: a vontade divina mandava-me abrir o livro e ler o primeiro capitulo que encontrasse.

 Tinha ouvido dizer que Antão, assistindo por acaso a uma leitura do Evangelho, tomara para si esta advertência: "Vai, vende tudo o que tens, dá-lo aos pobres, e terás um tesouro no céu; depois vem e segue-me" – e que esse oráculo decidira imediatamente sua conversão.

 Depressa voltei para o lugar onde Alípio estava sentado, e onde eu deixara o livro do Apóstolo ao me levantar. Peguei-o, abri-o, e li em silêncio o primeiro capítulo que me caiu sob os olhos: "Não caminheis em glutonarias e embriaguez, não nos prazeres impuros do leito e em leviandades, não em contendas e rixas; mas revesti-vos de nosso Senhor Jesus Cristo, e não cuideis de satisfazer os desejos da carne".

 Não quis ler mais, nem era necessário. Quando cheguei ao fim da frase, uma espécie de luz de certeza se insinuou em meu coração, dissipando todas as trevas de dúvida.

 Então, marcando com o dedo, ou não sei com que, fechei o livro, e com o rosto já tranqüilo, revelei a Alípio o que se passara. Ele, por sua vez, me revelou o que acontecera com ele, e que eu ignorava. Pediu para ver o que eu tinha lido; mostrei-lhe, ele prosseguiu a leitura. Eu ignorava o texto seguinte, que era este: Recebei ao fraco na fé, palavras que aplicou a si mesmo, e mo revelou. Fortificado por essa advertência, firmou-se nessa resolução e santo propósito, bem de acordo com seus costumes, nos quais já há muito tempo tomara grande vantagem sobre mim.

 Fomos depois à procura de minha mãe, que ao saber do sucedido, ficou radiante. Contamo-lhe como o caso se passara; ela exultou, triunfante e bendizendo a ti, que és poderoso para dar-nos mais do que pedimos ou entendemos, porque via que lhe havias concedido, a meu respeito, muito mais do que constantemente te pedia com tristes gemidos e lágrimas.

 De tal forma me converteste a ti, que já não procurava esposa, nem abrigava esperança alguma deste mundo, mas estava já naquela "regra de fé" em que há tantos anos me havias mostrado à minha mãe. E assim converteste seu pranto em alegria, muito mais fecunda do que havia desejado, e muito mais preciosa e pura do que a que podia esperar dos netos nascidos de minha carne.