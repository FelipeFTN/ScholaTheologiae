## CAPÍTULO IV

### A conversão dos grandes

 Vamos pois, Senhor, mãos à obra! Desperta-nos, chama-nos, inflama-nos, arrebata-nos; derrama tuas doçuras, encanta-nos: amemos, corramos!

 Não é verdade que muitos voltam a ti, saindo de um abismo de cegueira mais profundo que o de Vitorino, e se aproximam de ti, e são iluminados pela tua luz, junto da qual recebem o poder de se fazerem teus filhos?

 Mas se estes são menos conhecidos pelo mundo dos homens, mesmo os que os conhecem se alegram menos; mas quando a alegria é partilhada por muitos, ainda é maior em cada um, porque se aquece e inflama de uns para os outros.

 Ademais, os que são conhecidos de muitos, arrastam à salvação muitos outros, e caminham adiante seguidos dos que os imitam. Por isso, grande é a alegria dos que os precederam, por que não se regozijam só consigo.

 Mas, longe de mim pensar que no teu tabernáculo são mais aceitos os ricos que os pobres, e os nobres mais do que os plebeus, porque escolheste os fracos segundo o mundo para confundir os fortes; o que é vil e desprezível segundo o mundo, a que não é nada, para aniquilar o que é.

 Contudo, o menor de teus apóstolos, por cuja boca pronunciaste essas palavras, quando suas armas abateram o orgulhoso procônsul Paulo, sujeitando-o ao leve jugo de teu Cristo e fizeram dele um súdito do grande Rei, quis, parar comemorar tão grande triunfo, mudar seu nome de Saulo pelo de Paulo. De fato, o adversário é mais completamente vencido naquilo em que tinha maior domínio e por meio do que retém maior número de sequazes. Ora, o inimigo domina com mais força os soberbos pela nobreza de seu nome e, graças a estes, número maior pelo prestígio de sua autoridade.

 Assim, na medida em que o coração de Vitorino era tido como fortaleza inexpugnável antes ocupada pelo demônio, e sua língua como dardo poderoso e agudo, que tantas vezes havia dado a morte às almas, tanto mais copiosamente deviam exultar teus filhos, ao verem que nosso Rei agrilhoara o forte, e que seus vasos roubados, eram agora purificados e destinados à tua honra, convertendo-se em instrumentos úteis ao Senhor para toda obra boa.