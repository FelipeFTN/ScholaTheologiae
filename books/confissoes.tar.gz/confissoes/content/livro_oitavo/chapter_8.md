## CAPÍTULO VIII

### Luta espiritual

 Então, em meio àquela luta interior que eu travava violentamente contra mim mesmo no recesso do meu coração, perturbado no rosto e no espírito, volto-me para Alípio exclamando: "Que tanto nos aflige? O que significa isto que ouviste? Levantam-se os ignorantes e arrebatam o céu, e nós, com todo nosso saber insensato, nos revolvemos na carne e no sangue! Acaso temos vergonha de segui-los porque se nos adiantaram, e não temos vergonha de não os seguir?"

 Foi mais ou menos o que eu lhe disse, e dele me afastei sob forte emoção. Alípio me olhava atônito em silêncio. Eu não falava como de costume, e muito mais que as palavras, minha fronte, minhas fazes, meus olhos, minha cor e o tom de minha voz denunciavam meu estado de espírito.

 Nossa casa tinha um pequeno jardim, que usávamos, assim como o restante da casa, que nosso hóspede não habitava. Para ali me levara a tormenta de meu coração, onde ninguém pudesse interferir no ardente combate que eu travava comigo mesmo, até que se resolvesse o assunto conforme tu sabias e eu ignorava. Mas eu delirava para reencontrar a razão, e morria para reviver; conhecia meu mal, mas desconhecia o bem que depois haveria de sobrevir.

 Retirei-me, pois, para o jardim, e Alípio seguiu-me passo a passo; mas, apesar de sua presença, eu não estava menos só. E como haveria ele de me deixar naquele estado? Sentamonos o mais longe possível da casa. Eu tremia pela violenta indignação, me enraivecia por não poder seguir teu agrado e aliança, ó meu Deus, aliança pela qual clamavam todos os meus ossos, que te elevavam louvores até o céu. E para ir a ti não há necessidade de navios nem de carros, nem mesmo de dar aqueles poucos passos que separavam a casa do jardim onde estávamos. Não somente ir, mas chegar junto de ti, nada mais é do que querer ir, mas com querer enérgico e pleno, e não com vontade tíbia, que se dispersa em todos os sentidos, e se agita incerta, dividida, ora levantando-se, ora voltando a cair.

 Enfim, naquela angustiante hesitação, fazia mil gestos, como soem fazer os homens que querem e não podem, ou porque não têm membros, ou porque os têm atados em cadeias, debilitados pela fraqueza ou paralisados de qualquer outro modo. Se puxei os cabelos, se feri a fronte, se apertei os joelhos entre os dedos entrelaçados, eu o fiz porque quis. Poderia porém querer fazê-lo e não o fazer, se a flexibilidade de meus membros não me obedecesse. Portanto, fiz muitas coisas, nas quais o querer não era o mesmo que o poder.

 Contudo, eu não fazia aquilo que desejava acima de tudo o mais, e que eu poderia fazer desde que o quisesse, porque se o tivesse efetivamente querido, bastava que o quisesse sinceramente; nisto o poder é o mesmo que o querer, e querer já seria agir.

 Contudo não o fazia, e meu corpo obedecia mais facilmente ao mais leve comando de minha alma, movendo os membros segundo sua vontade, do que a própria alma obedecer a si mesma para realizar seu grande desejo com a vontade.