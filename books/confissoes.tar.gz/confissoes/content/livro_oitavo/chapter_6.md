## CAPÍTULO VI

### A narração de Ponticiano

 Agora contarei de que modo me arrancaste do vínculo do desejo carnal, que me prendia fortemente, e da servidão dos negócios do mundo, e confessarei teu nome, ó Senhor, meu auxílio e minha redenção. Levava minha vida habitual com angústia crescente; todos os dias suspirava por ti, freqüentava tua igreja, quando me deixavam livre os negócios, cujo peso me fazia sofrer.

 Comigo estava Alípio, desonerado do cargo de jurisconsulto, depois de ter sido assessor pela terceira vez. Ele aguardava a quem vender de novo seus conselhos, como eu vendia arte da eloqüência, se é que pelo ensino a podemos transmitir.

 Nebrídio, por sua vez, acendendo às nossas solicitações amigas, auxiliava na escola a nossa amigo íntimo, Verecundo; este, gramático e cidadão milanês, desejava enormemente, e nos instava em nome da amizade, que um de nós lhe prestasse uma fiel colaboração, pois dela muito necessitava.

 Não foi, pois, o interesse que moveu a Nebrídio – que poderia auferir bem mais vantagens se ensinasse as letras – mas, como grande amigo que era, não quis recusar nosso pedido em obsequio à amizade. Agia, porém, com muita prudência, evitando fazer-se conhecido dos poderosos deste mundo, para evitar as inquietações do espírito que ele queria manter o mais possível livre e desocupado para investigar, ler ou ouvir algo sobre a sabedoria.

 Certo dia em que Nebrídio estava ausente, não sei por que motivo, Alípio e eu recebemos a visita de um tal Ponticiano, nosso compatriota da África, que servia em alto cargo do palácio. Não sei mais o que queria de nós.

 Sentamo-nos para conversar, e, por acaso, deu com os olhos em um livro que estava sobre a mesa de jogo, à nossa frente. Pegou-o, abriu-o, viu que eram as epístolas de Paulo e ficou surpreso, pois pensava que se tratasse de algum dos livros cujo estudo me preocupava. Então sorriu para mim e, cumprimentando-me, manifestou-me sua admiração por ter encontrado aquele livro, e só aquele, ao alcance dos meus olhos. Ponticiano era um cristão fiel, e muitas vezes prostrava-se diante de ti, nosso Deus, na igreja, em freqüentes e prolongadas orações.

 E quando lhe declarei que aquele livro ocupava o melhor de minha atenção, tomando a palavra, começou a falar-nos de Antão, monge do Egito, cujo nome era celebrado entre teus fiéis, mas que nós desconhecíamos até aquela hora. Informado disto, continuou a falar, revelando esse grande homem à nossa ignorância, que ele muito admirou.

 Ouvíamos, estupefatos, tuas autenticas maravilhas, realizadas na verdadeira fé, na Igreja Católica, tão recentes e quase contemporâneas. Todos nos admirávamos; nós, por serem coisas tão grandes; e ele, por ser-nos tão desconhecidas.

 Depois, passou a falar das multidões que vivem em mosteiros, e de seus costumes, que trazem teu doce perfume, e da fecunda solidão do ermo, coisas todas que desconhecíamos.

 Até em Milão havia, fora dos muros, um mosteiro cheio de bons irmãos sob a direção de Ambrósio, que também desconhecíamos.

 Ponticiano prosseguia, e falava sempre mais, e nós o ouvíamos atentos e calados. E assim veio a nos contar que um dia, não sei quando, estando em Tréveris, saiu em companhia de três companheiros, enquanto o imperador se concentrava nos jogos circenses da tarde, para dar um passeio pelos jardins que rodeavam os muros da cidade. Distraidamente passeando dois a dois, um com Ponticiano, e os outros dois juntos, separaram-se e tomaram caminhos diferentes.

 Caminhando a esmo, estes últimos deram com uma cabana, habitada por alguns servos teus, pobres de espírito, a quem pertence o reino dos céus. Lá encontraram um exemplar manuscrito da Vida de Santo Antão. Um deles começou a lê-lo, e, admirado e arrebatado cogitou, enquanto lia, em abraçar aquele gênero de vida, abandonando o serviço do mundo, para servir unicamente a ti.

 Estes dois eram os chamados agentes de negócios do imperador. De repente, tomado de amor santo e casto pudor, irado consigo mesmo, olha para o companheiro, e lhe diz: "Dize-me, te peço, onde pretendemos chegar com todos estes nossos trabalhos? Que buscamos? Qual a finalidade do nosso labor? Podemos aspirar mais no palácio do que ser amigos do imperador? E mesmo nisto, quanta incerteza, quantos perigos! E quantos perigos teremos de passar para chegar a um perigo ainda maior? E quando chegaremos a isso? Mas, se eu quiser ser amigo de Deus, posso sê-lo agora mesmo". Disse essas palavras, e exaltado pela gestação da nova vida voltou os olhos para o livro; ao ler, transformava-se interiormente, o que só tu sabias, e seu espírito se despia do mundo, como logo se evidenciou.

 Enquanto lia, o coração se lhe tornou um mar tempestuoso, sentiu um estremecimento e, intuindo o melhor caminho a tomar, resolveu abraçá-lo, dizendo ao amigo:

 "Já rompi com nossos sonhos: decidi dedicar-me ao serviço de Deus, e isso quero começar aqui e agora. Se não me queres imitar, ao menos não me contraries".

 O amigo respondeu que desejava ficar com ele, e ser companheiro de tão nobre mercê e de tão grande combate. Ambos já te pertenciam, e começavam a construir, com capital suficiente, uma torre de salvação, a tudo renunciando para te seguir.

 Então Ponticiano e seu companheiro, que passeavam em outro local do jardim, procurando-os, deram também com a mesma cabana, e os avisaram para que voltassem, pois já entardecia. Mas eles, relataram-lhes sua determinação e propósito, e o modo como nascera e se fixara neles tal desejo, pediram-lhes que, se não quisessem juntar-se a eles, que não os molestassem. Mas estes, sem se converterem, lamentaram a si mesmos, no dizer de Ponticiano, e felicitando-os piedosamente, recomendaram-se às suas orações; depois, arrastando o coração pela terra, voltaram ao palácio, enquanto que os convertidos, fixando seu coração no céu, ficaram na cabana.

 Ambos eram noivos; mas, quando suas noivas ouviram o sucedido, também te consagraram sua virgindade.