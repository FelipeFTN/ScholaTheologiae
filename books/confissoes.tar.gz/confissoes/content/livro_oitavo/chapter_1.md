## CAPÍTULO I

### Hesitações

 Faze, meu Deus, que eu recorde de ti em ação de graças, e proclame tuas misericórdias para comigo. Que meus ossos se penetrem do teu amor, e digam: Senhor quem semelhante a ti? Rompeste com grilhões, e te oferecerei um sacrifício de louvor. Contarei como os rompeste, e todos os que te adoram exclamarão quando me ouvirem: "Bendito seja o Senhor no céu e na terra! Grande e admirável é seu nome!

 Tuas palavras, Senhor, tinham-me gravado profundamente em meu coração, e me via cercado apenas por ti de todos os lados. Tinha certeza de tua vida eterna, embora apenas a visse em enigma e como em espelho. Já fora dissolvida toda dúvida quanto à tua substância incorruptível, ao saber que toda substância procedia dela. E o que desejava não era tanto estar mais certo de ti, mas mais firme em ti.

 Quanto à minha vida temporal, estava eu ainda vacilante, e era necessário que meu coração se purificasse do velho fermento. O caminho certo, que é o próprio Salvador, me encantava, mas titubeava ainda em caminhar por seus estreitos desfiladeiros.

 Então me inspiraste a idéia – que me pareceu excelente – de me dirigir a Simpliciano, que eu tinha como um de teus bons servidores, em quem brilhava tua graça. Sobre ele ouvira também que desde sua juventude te consagrava devotamente sua vida, e como já encanecia, achei que em tão longa vida, dedicada ao estudo de teus caminhos, teria acumulado grande experiência e instrução; e de fato assim era. Por isso queria confiar-lhe minhas inquietações, para que me apontasse o modo de vida mais idôneo de alguém, com minhas disposições interiores, seguir teu caminho.

Vi tua Igreja cheia de fiéis que, por um caminho ou por outro, progrediam.

 Quanto a mim, aborrecia-me a vida que levava no mundo, e era para mim fardo pesadíssimo, agora que os apetites mundanos, como a esperança de honras e riquezas, já não me animavam para suportar tão pesada servidão. Essas paixões haviam perdido para mim o encanto, diante de tua doçura e da beleza de tua casa, que já amava. Mas sentia-me ainda fortemente amarrado à mulher. Sem dúvida o Apóstolo não me proibia de casar, embora em seu ardente desejo de ver todos os homens semelhantes a ele, exortasse a um estado mais elevado. Mas eu, ainda muito fraco, escolhia a condição mais fácil; por isso, vivia hesitando em tudo o mais, e me desgastava com preocupações enervantes, pois a vida conjugal, a que me julgava destinado e obrigado, ter-me-ia obrigado a novas incumbências, que eu não queria suportar.

 Ouvira da boca da própria Verdade que há eunucos que mutilavam a si próprios por amor ao reino dos céus, embora acrescentando que o compreenda quem o puder compreender. São vãos, por certo, todos os homens nos quais não reside a ciência de Deus, e que nas coisas visíveis não puderam achar aquele que é. Mas eu já me livrara dessa vaidade, já a havia ultrapassado, e pelo testemunho de tua criação, te encontrara a ti, nosso Criador, e a teu Verbo, Deus em ti, e contigo um só Deus, por quem criaste todas as coisas.

 Há ainda outra espécie de ímpios; os que, conhecendo a Deus, não o glorificam como Deus, nem lhe renderam graças. Eu também tinha caído nesse pecado; mas tua destra me amparou e libertou, colocando-me em lugar onde me pudesse curar; e disseste ao homem: Eis que a piedade é a sabedoria. E ainda: Não queiras parecer sábio, porque os que se dizem sábios tornaram-se insensatos.

 Já havia encontrado, finalmente, a pérola preciosa, que devia comprar vendendo tudo o que possuía. Mas ainda hesitava.