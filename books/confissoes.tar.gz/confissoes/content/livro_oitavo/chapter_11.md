## CAPÍTULO XI

### Últimas resistências

 Assim sofria e me atormentava, com acusações mais acerbas que de costume, rolando-me e debatendo-me dentro de minha cadeias, para ver se as quebrava por completo. Elas mal me prendiam,mas ainda me prendiam. E tu, Senhor, me espicaçavas no fundo de minha alma, e com severa misericórdia redobravas os açoites do temor e da vergonha, para que eu não afrouxasse de novo, e para que quebrasse minha tênue e leve cadeia, antes que ela se revigorasse para me prender mais firmemente.

 E dizia comigo mesmo: "Vamos! Mãos à obra, sem demoras!" E quase passava da palavra à ação. Estava a ponto de agir, mas não agia. Eu já não recaía nas antigas paixões, mas delas estava bem próximo, e tomava ainda alento de seu ar. Quase a alcançava, faltava pouco, cada vez menos, e já quase chegava ao termo e a segurava; mas não a alcançava, nem a tocava; hesitava entre morrer para a morte e viver para a vida. O mal arraigado dominava-me mais do que o bem, cujo hábito eu não possuía; na medida que ia se aproximando o momento em que me transformaria em outro homem, maior era o horror que me incutia, sem contudo me fazer voltar para trás ou mudar de caminho. Simplesmente mantinha-me indeciso.

 Mantinham-me preso umas tantas bagatelas, umas vaidades de vaidades, antigas amigas minhas, que me puxavam por minhas vestes carnais, murmurando: "Então, nos abandonas? De agora em diante nunca mais estaremos contigo? Desde este momento nunca mais te será lícito isto ou aquilo?"

 E que coisas, meu Deus, que torpezas me sugeriam com o que chamei de isto ou aquilo! Por tua misericórdia, afasta-as da alma de teu servo! Oh! Que imundícies me sugeriam, que indecências! Já se reduzira a menos da metade o número de vezes que eu lhes dava ouvidos; não era mais um assalto aberto, frontal, mas segredado por cima dos ombros, e como que puxando-me furtivamente, se me afastava, para que me voltasse para trás.

 Contudo, faziam com que eu, vacilante, tardasse em me separar delas para correr para onde me chamavam, enquanto o hábito violento me dizia: "Julgas que poderás viver sem elas?"

 Mas isto já dizia com voz muito débil. Para onde voltava o rosto, e por onde temia passar, mostrava-se para mim a casta dignidade da continência, serena e alegre, sem desordens, acariciando-me honestamente para que me aproximasse sem medo. Estendia para mim, para me acolher e abraçar, suas mãos piedosas, cheias de uma multidão de bons exemplos.

 Junto dela, uma turba de meninos e meninas, uma juventude numerosa, e homens de toda idade, viúvas veneráveis e virgens idosas. Em todas essas almas, não era estéril, mas fecunda a mãe de filhos nascidos nas alegrias do esposo, que eras tu, Senhor!

 E a continência zombava de mim com ironia animadora, como se dissesse: "Então, não serás capaz de fazer o mesmo que eles? Ou será que estes e estas encontraram forças em si mesmos, e não no Senhor, seu Deus? Foi o Senhor Deus, quem me entregou a eles. Por que te apóias em ti, se és vacilante? Lança-te nele, não temas, que ele não se apartará de ti, e tu não cairás. Lança-te com confiança, que ele te receberá e te curará."

 E enchia-me de vergonha por ainda ouvir o murmúrio daquelas bagatelas e, vacilante, continuava indeciso.

 Mas de novo a voz da castidade parecia me dizer: Não dês ouvidos às tentações imundas da tua carne impura que te prende à terra, a fim de que seja mortificada. Ela te fala de deleites, contrários porém, à lei do Senhor teu Deus.

 Essa luta se desenrolava no fundo do meu espírito, de mim contra mim mesmo. Alípio, sem sair de perto de mim, aguardava em silêncio o desfecho de minha insólita agitação.