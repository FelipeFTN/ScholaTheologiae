### O prazer do pecado

 E que sentimento era aquele de minha alma? certamente, assaz torpe e eu um desgraçado por alimentá-lo. Mas, que era na realidade? E quem há que conheça os pecados? Era como um riso, como que a fazer-nos cócegas no coração, provocado por ver que enganávamos aos que não suspeitavam de nós tais coisas, e porque sabíamos que haviam de detestá-las.

 Porém, por que me deleitava o não perpetrar sozinho o roubo? Acaso alguém se ri facilmente quando está só? Ninguém o faz, é verdade; porém, também é verdade que às vezes o riso tenta e vence aos que estão sós, sem que ninguém os veja, quando se oferece aos sentidos ou à alma algo extraordinariamente ridículo. Porque a verdade é que eu sozinho nunca teria feito aquilo; não, eu sozinho jamais faria aquilo. Tenho viva, diante de mim, meu Deus, a lembrança daquele estado de alma, e repito que eu sozinho não teria cometido aquele furto, do qual não me deleitava o objeto, mas a razão do roubo, o que, sozinho, não me teria agradado de modo algum, nem eu o teria feito.

 Ó amizade inimiga! Sedução impenetrável da alma, vontade de fazer o mal por passatempo e brinquedo, apetite do dano alheio sem proveito algum e sem desejo de vingança! Só porque sentimos vergonha de não ser sem-vergonha quando ouvimos; "Vamos! Façamos!".

## CAPÍTULO X