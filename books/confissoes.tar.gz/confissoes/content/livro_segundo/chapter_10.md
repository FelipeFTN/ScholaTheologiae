## CAPÍTULO X

### Deus, o sumo bem

 Quem desatará este nó, tão enredado e emaranhado? Como é asqueroso! Não quero voltar para ele os olhos, não quero vê-lo. Só a ti quero, justiça e inocência, tão bela e graciosa aos olhos puros, e com insaciável saciedade. Só em ti se acha o descanso supremo e a vida imperturbável. Quem entra em ti, entra no gozo do seu Senhor, e não temerá, e estará perfeitamente bem no sumo bem. Eu me afastei de ti e andei errante, meu Deus, mui longe de teu esteio em minha adolescência, e cheguei a ser para mim mesmo uma região de esterilidade.