# LIVRO SEGUNDO

### Ação de graças

 Contudo, Senhor, graças te sejam dadas, excelso e ótimo criador e ordenador do universo, nosso Deus, mesmo que te limitasses a me fazer apenas menino. Porque então, eu já existia, vivia, sentia, cuidava da minha integridade, eco de tua profunda unidade, fonte de minha existência.

 Guardava também, com o secreto instinto, a integridade dos meus outros sentidos, e deleitava-me com a verdade nos pequenos pensamentos que formava sobre coisas pequenas. Não queria ser enganado, tinha boa memória, e me ia instruindo com a conversação. Alegrava-me com a amizade, fugia à dor, ao desprezo, à ignorância. E não seria isto, em tal criatura, digno de admiração e de louvor? Pois todas essas coisas são dons do meu Deus, que eu não dei a mim mesmo. E todos são bons, e tudo isso constitui o meu eu.

 O que me criou, portanto, é bom, e ele próprio é o meu bem; a ele louvo por todos estes bens que integravam meu ser de criança. Eu pecava em buscar em mim próprio e nas demais criaturas, e não nele, os deleites, grandezas e verdades; por isso caia logo em dores, confusões e erros.

 Graças a ti, minha doçura, minha esperança e meu Deus, graças a ti por teus dons; que eles fiquem em ti conservados. Assim me guardarás também a mim, e aumentarão e aperfeiçoarão os dons que me deste, e eu estarei contigo, porque também me deste a existência.

## CAPÍTULO I

### A adolescência

 Quero recordar minhas torpezas passadas e as degradações carnais de minha alma, não porque as ame, mas por te amar, ó meu Deus. É por amor de teu amor que o faço, percorrendo com a memória amargurada, aqueles meus perversos caminhos, para que tu me sejas doce, doçura sem engano, ditosa e eterna doçura. Resgata-me da dispersão em que me dissipei quando, afastando-me de tua unidade, me desvaneci em muitas coisas.

 Tempo houve de minha adolescência em que ardi em desejos de me fartar dos prazeres mais baixos, e ousei a bestialidade de vários e sombrios amores, e se murchou minha beleza, e me transformei em podridão diante de teus olhos, para agradar a mim mesmo e desejar agradar aos olhos dos homens.

## CAPÍTULO II

### As primeiras paixões

 E que me deleitava, senão amar e ser amada? Mas eu não era moderado, indo de alma para alma de acordo com os sinais luminosos da amizade, pois, da lodosa concupiscência de minha carne e do fervilhar da puberdade levantava-se como que uma névoa que obscurecia e ofuscava meu coração, a ponto de não discernir a serena amizade da tenebrosa libido. Uma e outra, confusamente, me abrasavam; arrastavam minha fraca idade pelo declive íngreme de meus apetites, afogando-me em um mar de torpezas. Tua ira se acumulava sobre mim, e eu não o sabia. Ensurdeci com o ruído da cadeia de minha mortalidade, e cada vez mais me afastava de ti, e tu o consentias; e me agitava, e me dissipava, e me derramava e fervia em minha devassidão, e tu te calavas – ó alegria que tão tarde encontrei! – tu te calavas então, e eu ia cada vez mais para longe de ti, sempre atrás de estéreis sementes de dores, com vil soberba e inquieto cansaço.

 Oh! Se alguém refreasse aquela minha miséria, para que fizesse bom uso da fugaz beleza das criaturas inferiores; limitasse suas delicias, a fim de que as vagas daquela minha idade rompessem na praia do matrimonio, já que de outro modo não podia haver paz – contendo-se nos limites da geração, como prescreve tua lei, Senhor, tu que crias o gérmen transmissor de nossa vida mortal, e que com mão bondosa podes suavizar a agudeza dos espinhos, que mantiveste fora do paraíso! Porque tua onipotência está perto de nós, mesmo quando vagueamos longe de ti.

 Pelo menos eu deveria atender com mais diligencia à voz de tuas nuvens: Também eles sofrerão as tribulações da carne; mas eu quisera poupar-vos; e bom é ao homem não tocar em mulher; o que está sem mulher pensa nas coisas de Deus, de como o há de agradar; mas o que está ligado pelo matrimonio pensa nas coisas do mundo, e em como há de agradar à mulher. Estas são as palavras que eu deveria ter ouvido mais atentamente; e, eunuco pelo amor ao reino de Deus, teria suspirado mais feliz por teus abraços.

 Mas eu, miserável, tornei-me em torrente, seguindo o ímpeto de minha paixão, te abandonei e transgredi a todos os teus preceitos, sem porém, escapar de teus castigos. E quem o poderia dentre os mortais? Sempre estavas ao meu lado, irritando-se misericordiosamente comigo, e aspergindo com amaríssimos desgostos todos os meus gozos ilícitos, para que eu buscasse a alegria sem te ofender e, quando a achasse, de modo algum fosse fora de ti, Senhor. Fora de ti, que impões a dor em mandamento, e feres para sarar, e nos tiras a vida para que não morramos sem ti.

 Mas onde estava eu? Oh! Quão longe, exilado das delicias de tua casa naqueles meus dezesseis anos de idade carnal, quando esta empunhou seu cetro sobre mim, e eu me rendi totalmente a ela, à fúria da concupiscência que a degradação humana legítima, porém, ilícita, de acordo com as tuas leis.

 Nem mesmo os meus cogitaram em me sustentar na queda, pelo casamento, ao ver-me cair; cuidavam apenas que eu aprendesse a compor discursos magníficos e a persuadir com a palavra.

### Cegueira do pai, cuidados da mãe

 Nesse mesmo ano tive de interromper meus estudos, quando voltei de Madaura, cidade vizinha, onde fora estudar literatura e oratória, enquanto se faziam os preparativos necessários para minha viagem mais longa a Cartago, levado mais pela ambição de meu pai que pelos seus parcos bens, pois, era mui modesto cidadão de Tagaste.

 Mas, a quem conto eu estes fatos? Certamente, não a ti, meu Deus, mas em tua presença conto estas coisas aos da minha estirpe, ao gênero humano, ainda que estas páginas chegassem às mãos de poucos. E para que então? Para que eu, e quem me ler, pensemos na profundeza do abismo de onde temos de clamar por ti? E que há de mais próximo a teus ouvidos que o coração contrito e a vida que procede da fé?

 Quem então não cumulava a meu pai de louvores, pois excedendo até seus deveres familiares, gastava com o filho o necessário para tão longa viagem por causa de seus estudos? Porque muitos cidadãos, muito mais ricos do que ele, não mostravam para com os filhos igual cuidado.

 Contudo, este mesmo pai não se importava de saber se eu crescia para ti, ou que fosse casto, contanto que fosse deserto; mas antes eu era deserto, por carecer de teu cultivo, ó Deus, único, verdadeiro e bom senhor de teu campo, o meu coração.

 Porém, no meu décimo-sexto ano foi necessária uma interrupção em meus estudos por falta de recursos familiares e, livre da escola, passei a viver com meus pais. Avassalaram então minha cabeça os espinhos de minhas paixões, sem que houvesse mãos que os arrancassem. Pelo contrário, meu pai, certo dia, percebendo ao banho sinais de minha puberdade e vendo-me revestido de inquieta adolescência, como se já se alegrasse pensando nos netos, foi contá-lo alegre à minha mãe. Alegria esta gerada pela embriaguez com que este mundo esquece de ti, seu criador, e em teu lugar ama tua criatura; embriaguez que nasce do vinho sutil de sua perversa e mal inclinada vontade para as coisas baixas.

 Mas, nessa época, já tinhas começado a levantar, no coração de minha mãe, teu templo e os alicerces de tua santa morada; meu pai não era mais que catecúmeno, recente ainda. Por isso minha mãe perturbou-se com santo temor. Embora eu ainda não fosse batizado, temia que eu seguisse as sendas tortuosas por onde andam os que te voltam as costas, e não o rosto.

 Ai de mim! Como me atrevo a dizer que te calavas quando me afastava de ti? Seria verdade que então te calavas comigo? E de quem eram, senão tuas, aquelas palavras que pela boca de minha mãe, tua serva fiel, sussurraste em meus ouvidos, embora nenhuma delas penetrasse no meu coração, para que a cumprisse?

 Lembro bem que um dia me admoestou em segredo, com grande solicitude, que me abstivesse da luxúria e, sobretudo, que não cometesse adultério com a mulher de ninguém. Porém, esses conselhos pareciam-me próprios de mulheres, e eu me envergonharia de segui-los. Mas, na realidade, eram teus, embora eu não o soubesse, e por isso julgava que te calavas, e que era ela quem me falava; e eu te desprezava em tua serva, eu, seu filho, filho de tua serva e servo teu, a ti que não cessavas de me falar pela sua boca.

 Mas eu não o sabia, e me precipitava com tanta cegueira, que me envergonhava entre os companheiros de minha idade, de ser menos torpe do que eles. Os ouvia jactar-se de suas maldades, e gloriar-se tanto mais quanto mais infames eram; assim eu gostava de fazer o mal, não só pelo prazer, mas ainda por vaidade. O que há de mais digno de vitupério do que o vicio? E, contudo, para não ser escarnecido, tornava-me mais viciado e, quando não houvesse cometido pecado que me igualasse aos mais perdidos, fingia ter feito o que não cometera, para que não parecesse mais abjeto quanto mais inocente, e tanto mais vil quanto mais casto.

 Eis com que companheiros andava eu pelas graças de Babilônia, revolvendo-me na lama, como em cinamomo e ungüentos preciosos. E, para que todo esse lodo me pegasse bem firme, subjugava-me o inimigo invisível, e me seduzia, por ser eu presa fácil da sedução.

 Nem então minha mãe carnal, que já fugira do meio da Babilônia, mas que em outras coisas caminhava mais devagar, cuidou – como fizera ao aconselhar-me a castidade – de conter com os laços do matrimonio aquilo de que seu marido lhe falara a meu respeito. Já percebera ela que me era pestilencial, e que mais adiante me seria perigoso – já que essa paixão não podia ser cortada pela raiz. Não pensou nisso, digo, por temer que o vínculo matrimonial frustrasse a esperança que sobre mim acalentava; não a esperança da vida futura, que ela já tinha posto em ti, mas a esperança das letras que ambos, meu pai e minha mãe, desejavam ardentemente; meu pai, porque não pensava quase nada de ti, mas apenas ambições vãs a meu respeito; minha mãe, porque considerava que tais tradicionais estudos das letras não só não me seriam de estorvo, sendo de não pouca ajuda para chegar a ti. Assim julgo eu, agora, enquanto me é possível pela lembrança, o caráter de meus pais.

 Por isso, soltavam-me as rédeas para o jogo mais do que o permite uma moderada severidade, deixando-me cair na dissolução de várias paixões; e de todas surgia uma obscuridade que me toldava, ó meu Deus, a luz da tua verdade; e, por assim dizer, de meu corpo, brotava minha iniqüidade.

## CAPÍTULO IV

### O furto das pêras

 É certo, Senhor, que tua lei pune o furto, lei tão arraigada no coração dos homens que nem a própria iniqüidade pode apagar. Que ladrão há que suporte com paciência que o roubem? Nem o rico tolera isto a quem o faz forçado pela indigência. Também eu quis roubar, e roubei não forçado pela necessidade, mas por penúria, fastio de justiça e abundância de maldade, pois roubei o que tinha em abundância, e muito melhor. Nem me atraía ao furto o gozo de seu resultado, mas atraía-me o furto em si, o pecado.

 Nas imediações de nossa vinha, havia uma pereira carregada de frutos, que nem pelo aspecto, nem pelo sabor tinham algo de tentador. Alta noite – pois até então ficaríamos jogando nas eiras, de acordo com nosso mau costume – dirigimo-nos ao local, eu e alguns jovens malvados, com o fim de sacudi-la e colher-lhe os frutos. E levamos grande quantidade deles, não para saboreá-los, mas para jogá-los aos porcos, embora comêssemos alguns; nosso deleite era fazer o que nos agradava justamente pelo fato de ser coisa proibida.

 Aí está meu coração, Senhor, meu coração que olhaste com misericórdia quando se encontrava na profundeza do abismo. Que este meu coração te diga agora que era o que ali buscava, para fazer o mal gratuitamente, não tendo minha maldade outra razão que a própria maldade. Era hedionda, e eu a amei; amei minha morte, amei meu pecado; não o objeto que me fazia cair, mas minha própria queda. Ó torpe minha alma, que saltando para fora do santo apoio, te lançavas na morte, não buscando na ignomínia senão a própria ignomínia?

## CAPÍTULO V

### A causa do pecado

 Todos os corpos formosos, o ouro, a prata, e todos os demais têm, com efeito, seu aspecto atraente. No contato carnal intervém grandemente a congruência das partes, e cada um dos sentidos percebe nos corpos certa modalidade própria. Também a honra temporal e o poder de mandar e dominar têm seu atrativo, de onde nasce o desejo de vingança.

 Todavia, para obtermos estas coisas, não é necessário abandonarmos a ti, nem nos desviar de tua lei. Também a vida que aqui vivemos tem seus encantos, por certa beleza que lhe é própria, e pela harmonia que tem com as demais belezas terrenas. Cara é, finalmente, a amizade dos homens pela união que une muitas almas com o doce laço do amor.

 Por todos estes motivos, e outros semelhantes, pecamos quando, por propensão imoderada para os bens ínfimos, são abandonados os melhores e mais altos, como tu, Senhor, nosso Deus, tua verdade e tua lei.

 É verdade que também esses bens ínfimos têm seus deleites, porém, não como os de Deus, criador de todas as coisas, porque nele se deleita o justo, e nele acham suas delicias os retos de coração.

 Portanto, quando indagamos a causa de um crime, não descansamos até averiguar qual o apetite dos bens chamados ínfimos, ou que temor de perdê-los foi capaz de provocá-lo. Sem dúvida são belos e atraentes, embora, comparados com os bens superiores e beatíficos, sejam abjetos e desprezíveis. Alguém comete um homicídio. Por que? Porque desejou a esposa do morto, ou suas terras, ou porque quis roubar alguma coisa, ou então, ferido, ardeu em desejos de vingança. Por acaso cometeria o crime sem motivo, apenas pelo gosto de matar? Quem pode acreditar em semelhante coisa?

 Mesmo de Catilina, homem sem entranhas e muito cruel, de quem se disse que era mau e cruel sem razão, acrescenta o historiador um motivo: "Para que a ociosidade não embotasse suas mãos e sentimento".

 Todavia, se indagares porque agia assim, dir-te-ei que mediante o exercício de crimes, depois de tomada a cidade, conseguisse honras, poderes e riquezas, libertando-se do medo das leis e das dificuldades da vida, causados pela pobreza de seu patrimônio e a consciência de seus crimes. Logo, nem o próprio Catilina amava seus crimes, mas aquilo por cujo motivo os cometia.

## CAPÍTULO VI

### O crime gratuito

 Que amei, então, em ti, ó meu furto, crime noturno dos meus dezesseis anos? Não eras belo, já que eras furto. Mas, por acaso és algo para que eu fale contigo? Belas eram as pêras que roubamos, por serem criaturas tuas, ó formosíssimo Criador de todas as coisas, bom Deus, Deus sumo, meu bem e meu verdadeiro bem; belas eram aquelas pêras! Porém, não eram elas que apeteciam minha alma depravada. Eu as tinha em abundância, e melhores. Colhi-as da árvore só para roubar; tanto que, tão logo colhidas, joguei-as fora, saboreando nelas apenas a iniqüidade, com que me regozijava. Se alguma delas entrou em minha boca, somente o crime é que lhe deu sabor.

 E agora pergunto, meu Deus: que é que me deleitava no furto? Pois não encontro nenhuma beleza nele. Já não falo da beleza que reside na justiça e na prudência, nem sequer da que resplandece na inteligência do homem, na memória, nos sentidos ou na vida vegetativa; nem da que brilha nos magníficos astros em suas órbitas, ou na terra e no mar, cheios de criaturas, que nascem para sucederem umas às outras; nem sequer da defeituosa e sombria formosura dos vícios enganadores.

 O orgulho imita a altura; mas só tu, Deus excelso, estás acima de todas as coisas. E a ambição, que busca, senão honras e glorias, quanto tu és o único sobre todas as coisas e ser honrado e glorificado eternamente? A crueldade dos tiranos quer ser temida; porém, quem há de ser temido senão Deus, a cujo poder ninguém, porém, quem há de ser temido senão Deus, a cujo poder ninguém, em tempo algum ou lugar, nem por nenhum meio pode subtrair-se e fugir? As carícias da volúpia buscam ser correspondidas; porém, não há nada mais carinhoso que tua caridade, nem que se ame de modo mais salutar que tua verdade, sobre todas as coisas formosa e resplandecente. A curiosidade sugere amor à ciência, enquanto só tu conheces plenamente todas as coisas. Até a própria ignorância e estultícia cobrem-se com o nome de simplicidade e inocência; das quais não acham nada mais simples do que tu. E que pode haver mais inocente do que tu, pois, até mesmo o castigo dos maus lhes vem de seus pecados? A indolência gosta do descanso; porém, que repouso seguro pode haver fora do Senhor? O luxo gosta de ser chamado de fartura; mas só tu és a plenitude e a abundância inesgotável de eterna suavidade. A prodigalidade veste-se com a capa da liberalidade; porém, só tu, és verdadeiro e liberalíssimo doador de todos os bens. A avareza quer possuir muitas coisas; porém, só tu as possui todas. A inveja litiga acerca de excelências; porém, que há mais excelente do que tu? A ira busca a vingança; e que vingança mais justa do que a tua? O temor aborrece as coisas repentinas e insólitas, contrárias ao que se ama ou se deseja manter seguro; mas haverá para ti algo de novo e repentino? Quem poderá separar de ti o que amas? E onde, senão em ti, se encontra inabalável segurança? A tristeza definha com a perda das coisas com que a cobiça se deleita, e não quer que se lhe tire nada, como nada pode ser tirado de ti.

 Assim peca a alma, quando se aparta e busca fora de ti o que não pode achar puro e ilibado senão quando se volta novamente para ti. Perversamente te imitam todos os que se afastam de ti e se levantam contra ti. Porém, mesmo imitando-te, mostram que és o criador de toda criatura e que, portanto, não existe lugar onde alguém se possa afastar de ti de modo absoluto.

 Que amei, então, naquele furto, e no que imitei, viciosa e imperfeitamente, a meu Senhor? Acaso foi o gosto de agir pela fraude contra a tua lei, já que não o podia fazer por força, simulando, cativo, uma falsa liberdade ao fazer impunemente o que estava proibido, imagem tenebrosa de tua onipotência?

 Eis aqui o servo que, fugindo do seu senhor, seguiu uma sombra. Ó podridão! Ó monstro da vida e abismo da morte! Como pôde agradar-me o ilícito, e não por outro motivo, senão porque era ilícito?

## CAPÍTULO VII

### Ação de graças

 Como agradecerei ao Senhor por poder recordar todas estas coisas sem que minha alma sinta medo algum? Amar-te-ei, Senhor, e dar-te-ei graças, e confessarei teu nome, pois me perdoaste tantas e tão nefandas ações. Devo à tua graça e misericórdia teres-me dissolvido os pecados como gelo, como também todo o mal que não pratiquei. De fato, de que pecados não seria capaz, eu que amei gratuitamente o erro?

 Confesso que todos já me foram perdoados; o mal cometido voluntariamente, e o que deixei de fazer pela tua graça. Quem dentre os homens, conhecendo tua fraqueza, poderá atribuir às próprias forças sua castidade e inocência para amar-te menos, como se tivesse menor necessidade de tua misericórdia, com a qual perdoas os pecados aos que se convertem a ti?

 Aquele, pois, que, chamado por ti, seguiu tua voz e evitou todas estas coisas que lê de mim, e que eu recordo e confesso, não se ria de mim por haver sido curado pelo mesmo médico que o preservou de cair enfermo, ou melhor, de que adoecesse tanto. Antes, esse deve amar-te tanto e ainda mais do que eu, porque o mesmo que me curou de tantas e tão graves enfermidades, esse mesmo o livrou de cair no pecado.

## CAPÍTULO VIII

### O prazer da cumplicidade

 E que fruto colhi eu, miserável, daquelas ações que agora recordo com rubor? Sobretudo daquele furto, em que amei o próprio furto, e nada mais? Nenhum, pois o furto, em si nada valia, ficando eu mais miserável com ele. Todavia, é certo que eu sozinho não o teria praticado – a julgar pela disposição de meu ânimo na ocasião; - não, de modo algum; eu sozinho não o faria. Portanto, apreciei também na ocasião a companhia daqueles com quem o cometi. Logo, também é certo que apreciei algo mais além do furto; embora não amasse de fato nada mais, pois também essa cumplicidade era nada.

 Mas, que é esta, na verdade? E quem mo poderá ensinar, senão o que ilumina meu coração e rasga minhas sombras? De onde vem à minha alma a idéia destas indagações, desta discussão e considerações? Se eu então amasse as pêras que roubei, e quisesse apenas seu desfrute, podia tê-las roubado sozinho, se isso bastasse. Poderia fazer a iniqüidade pela qual chegaria meu deleite sem necessidade de excitar o prurido da minha cobiça com a conivência de almas cúmplices.

 Porém, como não achava deleite algum nas pêras, colocava este no próprio pecado, que consistia na companhia dos que pecavam comigo.

## CAPÍTULO IX

### O prazer do pecado

 E que sentimento era aquele de minha alma? certamente, assaz torpe e eu um desgraçado por alimentá-lo. Mas, que era na realidade? E quem há que conheça os pecados? Era como um riso, como que a fazer-nos cócegas no coração, provocado por ver que enganávamos aos que não suspeitavam de nós tais coisas, e porque sabíamos que haviam de detestá-las.

 Porém, por que me deleitava o não perpetrar sozinho o roubo? Acaso alguém se ri facilmente quando está só? Ninguém o faz, é verdade; porém, também é verdade que às vezes o riso tenta e vence aos que estão sós, sem que ninguém os veja, quando se oferece aos sentidos ou à alma algo extraordinariamente ridículo. Porque a verdade é que eu sozinho nunca teria feito aquilo; não, eu sozinho jamais faria aquilo. Tenho viva, diante de mim, meu Deus, a lembrança daquele estado de alma, e repito que eu sozinho não teria cometido aquele furto, do qual não me deleitava o objeto, mas a razão do roubo, o que, sozinho, não me teria agradado de modo algum, nem eu o teria feito.

 Ó amizade inimiga! Sedução impenetrável da alma, vontade de fazer o mal por passatempo e brinquedo, apetite do dano alheio sem proveito algum e sem desejo de vingança! Só porque sentimos vergonha de não ser sem-vergonha quando ouvimos; "Vamos! Façamos!".

## CAPÍTULO X

### Deus, o sumo bem

 Quem desatará este nó, tão enredado e emaranhado? Como é asqueroso! Não quero voltar para ele os olhos, não quero vê-lo. Só a ti quero, justiça e inocência, tão bela e graciosa aos olhos puros, e com insaciável saciedade. Só em ti se acha o descanso supremo e a vida imperturbável. Quem entra em ti, entra no gozo do seu Senhor, e não temerá, e estará perfeitamente bem no sumo bem. Eu me afastei de ti e andei errante, meu Deus, mui longe de teu esteio em minha adolescência, e cheguei a ser para mim mesmo uma região de esterilidade.