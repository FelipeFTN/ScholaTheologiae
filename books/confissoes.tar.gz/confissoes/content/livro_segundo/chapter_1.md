## CAPÍTULO I

### A adolescência

 Quero recordar minhas torpezas passadas e as degradações carnais de minha alma, não porque as ame, mas por te amar, ó meu Deus. É por amor de teu amor que o faço, percorrendo com a memória amargurada, aqueles meus perversos caminhos, para que tu me sejas doce, doçura sem engano, ditosa e eterna doçura. Resgata-me da dispersão em que me dissipei quando, afastando-me de tua unidade, me desvaneci em muitas coisas.

 Tempo houve de minha adolescência em que ardi em desejos de me fartar dos prazeres mais baixos, e ousei a bestialidade de vários e sombrios amores, e se murchou minha beleza, e me transformei em podridão diante de teus olhos, para agradar a mim mesmo e desejar agradar aos olhos dos homens.