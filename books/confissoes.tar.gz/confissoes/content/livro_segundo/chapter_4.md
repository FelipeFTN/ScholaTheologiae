## CAPÍTULO IV

### O furto das pêras

 É certo, Senhor, que tua lei pune o furto, lei tão arraigada no coração dos homens que nem a própria iniqüidade pode apagar. Que ladrão há que suporte com paciência que o roubem? Nem o rico tolera isto a quem o faz forçado pela indigência. Também eu quis roubar, e roubei não forçado pela necessidade, mas por penúria, fastio de justiça e abundância de maldade, pois roubei o que tinha em abundância, e muito melhor. Nem me atraía ao furto o gozo de seu resultado, mas atraía-me o furto em si, o pecado.

 Nas imediações de nossa vinha, havia uma pereira carregada de frutos, que nem pelo aspecto, nem pelo sabor tinham algo de tentador. Alta noite – pois até então ficaríamos jogando nas eiras, de acordo com nosso mau costume – dirigimo-nos ao local, eu e alguns jovens malvados, com o fim de sacudi-la e colher-lhe os frutos. E levamos grande quantidade deles, não para saboreá-los, mas para jogá-los aos porcos, embora comêssemos alguns; nosso deleite era fazer o que nos agradava justamente pelo fato de ser coisa proibida.

 Aí está meu coração, Senhor, meu coração que olhaste com misericórdia quando se encontrava na profundeza do abismo. Que este meu coração te diga agora que era o que ali buscava, para fazer o mal gratuitamente, não tendo minha maldade outra razão que a própria maldade. Era hedionda, e eu a amei; amei minha morte, amei meu pecado; não o objeto que me fazia cair, mas minha própria queda. Ó torpe minha alma, que saltando para fora do santo apoio, te lançavas na morte, não buscando na ignomínia senão a própria ignomínia?