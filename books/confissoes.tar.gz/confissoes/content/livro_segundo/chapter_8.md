## CAPÍTULO VIII

### O prazer da cumplicidade

 E que fruto colhi eu, miserável, daquelas ações que agora recordo com rubor? Sobretudo daquele furto, em que amei o próprio furto, e nada mais? Nenhum, pois o furto, em si nada valia, ficando eu mais miserável com ele. Todavia, é certo que eu sozinho não o teria praticado – a julgar pela disposição de meu ânimo na ocasião; - não, de modo algum; eu sozinho não o faria. Portanto, apreciei também na ocasião a companhia daqueles com quem o cometi. Logo, também é certo que apreciei algo mais além do furto; embora não amasse de fato nada mais, pois também essa cumplicidade era nada.

 Mas, que é esta, na verdade? E quem mo poderá ensinar, senão o que ilumina meu coração e rasga minhas sombras? De onde vem à minha alma a idéia destas indagações, desta discussão e considerações? Se eu então amasse as pêras que roubei, e quisesse apenas seu desfrute, podia tê-las roubado sozinho, se isso bastasse. Poderia fazer a iniqüidade pela qual chegaria meu deleite sem necessidade de excitar o prurido da minha cobiça com a conivência de almas cúmplices.

 Porém, como não achava deleite algum nas pêras, colocava este no próprio pecado, que consistia na companhia dos que pecavam comigo.