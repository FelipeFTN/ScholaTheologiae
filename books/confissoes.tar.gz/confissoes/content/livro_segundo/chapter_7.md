## CAPÍTULO VII

### Ação de graças

 Como agradecerei ao Senhor por poder recordar todas estas coisas sem que minha alma sinta medo algum? Amar-te-ei, Senhor, e dar-te-ei graças, e confessarei teu nome, pois me perdoaste tantas e tão nefandas ações. Devo à tua graça e misericórdia teres-me dissolvido os pecados como gelo, como também todo o mal que não pratiquei. De fato, de que pecados não seria capaz, eu que amei gratuitamente o erro?

 Confesso que todos já me foram perdoados; o mal cometido voluntariamente, e o que deixei de fazer pela tua graça. Quem dentre os homens, conhecendo tua fraqueza, poderá atribuir às próprias forças sua castidade e inocência para amar-te menos, como se tivesse menor necessidade de tua misericórdia, com a qual perdoas os pecados aos que se convertem a ti?

 Aquele, pois, que, chamado por ti, seguiu tua voz e evitou todas estas coisas que lê de mim, e que eu recordo e confesso, não se ria de mim por haver sido curado pelo mesmo médico que o preservou de cair enfermo, ou melhor, de que adoecesse tanto. Antes, esse deve amar-te tanto e ainda mais do que eu, porque o mesmo que me curou de tantas e tão graves enfermidades, esse mesmo o livrou de cair no pecado.