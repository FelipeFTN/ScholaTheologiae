## CAPÍTULO V

### A causa do pecado

 Todos os corpos formosos, o ouro, a prata, e todos os demais têm, com efeito, seu aspecto atraente. No contato carnal intervém grandemente a congruência das partes, e cada um dos sentidos percebe nos corpos certa modalidade própria. Também a honra temporal e o poder de mandar e dominar têm seu atrativo, de onde nasce o desejo de vingança.

 Todavia, para obtermos estas coisas, não é necessário abandonarmos a ti, nem nos desviar de tua lei. Também a vida que aqui vivemos tem seus encantos, por certa beleza que lhe é própria, e pela harmonia que tem com as demais belezas terrenas. Cara é, finalmente, a amizade dos homens pela união que une muitas almas com o doce laço do amor.

 Por todos estes motivos, e outros semelhantes, pecamos quando, por propensão imoderada para os bens ínfimos, são abandonados os melhores e mais altos, como tu, Senhor, nosso Deus, tua verdade e tua lei.

 É verdade que também esses bens ínfimos têm seus deleites, porém, não como os de Deus, criador de todas as coisas, porque nele se deleita o justo, e nele acham suas delicias os retos de coração.

 Portanto, quando indagamos a causa de um crime, não descansamos até averiguar qual o apetite dos bens chamados ínfimos, ou que temor de perdê-los foi capaz de provocá-lo. Sem dúvida são belos e atraentes, embora, comparados com os bens superiores e beatíficos, sejam abjetos e desprezíveis. Alguém comete um homicídio. Por que? Porque desejou a esposa do morto, ou suas terras, ou porque quis roubar alguma coisa, ou então, ferido, ardeu em desejos de vingança. Por acaso cometeria o crime sem motivo, apenas pelo gosto de matar? Quem pode acreditar em semelhante coisa?

 Mesmo de Catilina, homem sem entranhas e muito cruel, de quem se disse que era mau e cruel sem razão, acrescenta o historiador um motivo: "Para que a ociosidade não embotasse suas mãos e sentimento".

 Todavia, se indagares porque agia assim, dir-te-ei que mediante o exercício de crimes, depois de tomada a cidade, conseguisse honras, poderes e riquezas, libertando-se do medo das leis e das dificuldades da vida, causados pela pobreza de seu patrimônio e a consciência de seus crimes. Logo, nem o próprio Catilina amava seus crimes, mas aquilo por cujo motivo os cometia.