### Ação de graças

 Contudo, Senhor, graças te sejam dadas, excelso e ótimo criador e ordenador do universo, nosso Deus, mesmo que te limitasses a me fazer apenas menino. Porque então, eu já existia, vivia, sentia, cuidava da minha integridade, eco de tua profunda unidade, fonte de minha existência.

 Guardava também, com o secreto instinto, a integridade dos meus outros sentidos, e deleitava-me com a verdade nos pequenos pensamentos que formava sobre coisas pequenas. Não queria ser enganado, tinha boa memória, e me ia instruindo com a conversação. Alegrava-me com a amizade, fugia à dor, ao desprezo, à ignorância. E não seria isto, em tal criatura, digno de admiração e de louvor? Pois todas essas coisas são dons do meu Deus, que eu não dei a mim mesmo. E todos são bons, e tudo isso constitui o meu eu.

 O que me criou, portanto, é bom, e ele próprio é o meu bem; a ele louvo por todos estes bens que integravam meu ser de criança. Eu pecava em buscar em mim próprio e nas demais criaturas, e não nele, os deleites, grandezas e verdades; por isso caia logo em dores, confusões e erros.

 Graças a ti, minha doçura, minha esperança e meu Deus, graças a ti por teus dons; que eles fiquem em ti conservados. Assim me guardarás também a mim, e aumentarão e aperfeiçoarão os dons que me deste, e eu estarei contigo, porque também me deste a existência.