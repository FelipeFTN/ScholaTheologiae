## CAPÍTULO XXII

### A verdadeira felicidade

 Longe de mim, longe do coração de teu servo, Senhor, que a ti se confessa, a idéia de encontrar a felicidade não importa em que alegria! A felicidade é uma alegria que não é concedida aos ímpios, mas àqueles que te servem por puro amor: tu és essa alegria! Alegrar-se de ti, em ti e por ti: isso é felicidade. E não há outra. Os que imaginam outra felicidade, apegam-se a uma alegria que não é a verdadeira. Contudo, sempre há uma imagem da alegria da qual sua vontade não se afasta.