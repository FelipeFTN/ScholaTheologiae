## CAPÍTULO IV

### O fruto das confissões

 Mas, com que propósito desejam ouvir-me? Desejarão talvez congratular-me comigo, ouvindo quanto me aproximei de ti por tua graça, e orar por mim, ao ouvir quanto me retardou o peso de minhas culpas? A estes mostrarei quem sou; já não é pequeno fruto, Senhor meu Deus, que muitos te dêem graças por mim, e que muitos te roguem por mim. possa o coração de meus irmãos amar em mim o que ensinas a amar, e, deplorar em mim o que ensinas a aborrecer! Mas que brotem tais sentimentos em uma alma irmã, e não em almas estranhas, ou nesses filhos espúrios, cuja boca fala vaidade, e cuja direita é a direita da iniqüidade, que o faça uma alma fraterna que se alegra por mim quando me aprova, e quando me reprova se aflige por mim, porque quer me aprove, quer não, me ama.

 É a esses que me revelarei. Que eles respirem diante de minhas boas ações, e suspirem à vista de meus pecados. As obras boas são tuas obras e teus dons; as más são meus pecados. As obras boas são tuas obras e teus dons; as más são meus pecados, objeto de teus juízos. Respirem pelo bem e suspirem pelo mal, e que subam à tua presença hinos e lágrimas desses corações fraternos, que são os teus turíbulos.

 E tu, Senhor, que te alegras com a fragrância de teu santo templo, tem piedade de mim, segundo tua grande misericórdia por causa de teu nome, e tu, que jamais abandonas uma obra começada, aperfeiçoa em mim o que há de incompleto.

 Este poderá ser fruto de minhas confissões, não do que fui, mas do que sou. Farei minha confissão não apenas a ti, com íntima alegria mesclada de temor, e com secreta tristeza mesclada de esperança, mas também para os homens, que compartilham minha alegria e de minha mortalidade, meus concidadãos e peregrinos como eu, quer os que me precederam, como os que me seguem ou me acompanham no caminho da vida. Estes são teus servos, meus irmãos, que tu quiseste fossem filhos teus e meus senhores, e a quem me mandaste servir se quisesse viver contigo e de ti.

 Mas este preceito teria sido de pouco valor para mim, se teu Verbo o tivesse proferido apenas com palavras, e não tivesse mostrado o caminho com a obra. Eis que eu o imito pela ação e pela palavras, e o faço à sombra de tuas asas, o perigo seria grande demais, se minha alma aí não se abrigasse, e se minha fraqueza não te fosse conhecida.

 Sou como uma criança, mas meu Pai vive sempre, e é meu tutor idôneo; ele é a um tempo o que me gerou e o que me protege. Tu és todo o meu bem, tu, onipotente, que estás comigo mesmo antes de eu estar contigo.

 Revelarei pois, a estes, a quem me mandas servir, não como fui, mas como já sou agora, e como ainda não sou. Mas não quero julgar-me a mim mesmo. Assim é que peço para ser ouvido.