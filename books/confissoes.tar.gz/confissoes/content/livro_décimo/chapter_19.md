## CAPÍTULO XIX

### A memória das lembranças

 E quando a própria memória perde uma lembrança, como acontece quando nos esquecemos de algo e procuramos recordá-la, o que se passa? Onde, afinal, a procuramos senão na própria memória? E se esta, por acaso, nos oferece uma coisa por outra, a repelimos até que apareça o que buscamos. E assim que aparece dizemos: "É isto". E assim não diríamos se não a reconhecêssemos, e não a reconheceríamos se dela não houvesse registro. É certo, portanto, que já a havíamos esquecido. Ou será que ela não se apagara totalmente de nossa memória, por meio da parte que nos ficou impressa procuramos a outra? A memória, nesse caso, teria ciência de não poder, como de ordinário, fornecer a lembrança em seu conjunto e, mutilada, reclamaria e parte faltante. É o que sucede quando vemos uma pessoa conhecida, ou nela pensamos sem poder recordar seu nome. Se outro nome nos apresenta ao espírito, não o associamos à tal pessoa; por isso o afastamos, até que se apresenta um que concorde com nossa representação habitual da pessoa.

 Mas donde nos vem este nome, senão da memória? Mesmo quando nos é sugerido por outrem, é pela memória que reconhecemos; não o aceitamos como um conhecimento novo, mas recordando-o, confirmamos ser esse o nome que nos disseram. Se fosse totalmente apagado da alma, nem mesmo avisados o reconheceríamos.

 Não podemos pois, afirmar que nos esquecemos completamente daquilo de que nos lembramos ter esquecido. De nenhum modo poderíamos resgatar uma lembrança perdida se seu esquecimento fosse total.