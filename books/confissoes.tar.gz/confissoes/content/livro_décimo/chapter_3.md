## CAPÍTULO III

### Por que se confessar aos homens?

 Que tenho eu que ver com os homens, para que me ouçam as confissões, como se eles pudessem curar as minhas enfermidades? São curiosos para conhecer a vida alheia, mas indolentes para corrigir a própria! Por que desejam ouvir de mim quem sou, quando não se importam em saber de ti o que são? E como podem saber, ao me ouvirem falar de mim mesmo, se lhes digo a verdade, uma vez que homem algum sabe o que se passa no outro, senão o espírito do homem, que nele, habita? Mas, se ouvissem a ti falar deles, não poderiam dizer: "O Senhor mente". E o que é ouvir-te falar de si, senão conhecerem-se a si mesmos? E quem, conhecendo a si mesmo, pode dizer "é falso", sem mentir?

 A caridade crê em tudo – pelo menos entre corações que ela unifica em si por seus laços – por isso também eu, Senhor, me confesso a ti para que me ouçam os homens. A eles não posso provar que falo a verdade; mas crêem-me aqueles cujos ouvidos a caridade abre para mim.

 Mas tu, Médico da minha alma, faze-me ver claramente a utilidade de meu propósito. As confissões de meus pecados passados – que já perdoaste e esqueceste, para me fazer feliz em ti, transformando minha alma com tua fé e teu sacramento – levam o coração dos que as lêem e ouvem a não dormir no desespero dizendo: "Não posso". Mas despertem para o amor pela tua misericórdia e para a doçura de tua graça, que fortalece o fraco e este se dá conta de sua debilidade.

 Os bons, por sua vez, se agradam em ouvir os pecados passados daqueles que já não sofrem. Agrada-lhes, não por serem pecados, mas porque o foram, e agora já não o são.

 Mas, Senhor meu – a quem todos os dias se confessa minha consciência, agora mais confiante com a esperança na tua misericórdia que na sua inocência – que proveito haverá em confessar aos homens, na tua presença, neste livro, não o que fui, mas o que sou agora? Sobre a confissão do passado, e dos seus eventuais proveitos, já falei acima.

 Há muitos porém, quer me conheçam, quer não, que desejam saber quem sou agora, neste momento em que escrevo as Confissões. Já ouviram de mim ou de outros alguma coisa a meu respeito, mas seu ouvido não ouve meu coração, onde eu sou o que sou. Querem, certamente, saber por confissão minha o que sou no íntimo, lá onde não podem penetrar com a vista, com o ouvido, ou com a mente. Estão dispostos a acreditar em mim. Mas poderão igualmente estar certos de me conhecer? A caridade, que os torna bons, lhes diz que eu não minto quando confesso tais coisas de mim. É ela que os faz acreditarem em mim.