## CAPÍTULO XXXII

### Os prazeres do olfato

 Quanto à sedução dos perfumes, não me preocupo demais. Quando ausentes, não os procuro; quando presentes, não os recuso, mas estou sempre disposto a deles me abster. Pelo menos assim me parece, embora talvez me engane. Trevas deploráveis me envolvem, que me escondem minhas faculdades reais; por isso, quando meu espírito indaga à respeito de suas forças, bem sabe que não pode confiar em si mesmo, por seu íntimo permanecer muitas vezes insondável, até que a experiência lho manifeste. Ninguém pois se deve ter seguro nesta vida, que é tentação perpétua. Pois. Como podemos nos tornar melhores, não aconteça de nos tornar piores. Nossa única esperança, nossa única confiança, nossa firme promessa é tua misericórdia.