## CAPÍTULO XXVI

### Onde encontrar Deus?

 Onde, então, te encontrei, para te conhecer? Não estavas ainda em minha memória antes de eu te conhecer. Onde, então, te encontrei, para te conhecer, senão em ti mesmo, acima de mim? No entanto, aí não existe espaço. Quer nos afastemos de ti, quer nos aproximemos, aí não existe espaço algum. Ó Verdade, por toda parte assistes aos que te consultam, e respondes ao mesmo tempo a todas essas diversas consultas. Tuas respostas são claras, mas nem para todos. Os homens te consultam sobre o que querem, mas nem sempre ouvem as respostas que querem. Teu servo fiel é o que não pensa em ouvir de ti a resposta que quer, mas em querer a resposta que lhe dás.