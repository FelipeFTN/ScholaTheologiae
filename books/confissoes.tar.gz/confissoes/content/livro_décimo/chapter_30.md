## CAPÍTULO XXX

### Sonho e voluptuosidade

 Ordenas que me abstenha da concupiscência da carne, da concupiscência dos olhos e da ambição do século. Proibiste as uniões luxuriosas, e embora tenhas permitido o casamento, ensinaste que há um estado bem melhor. E, pela tua graça, optei por esse estado, antes mesmo de me tornar dispensador de teu sacramento.

 Mas em minha memória, de que falei longamente, vivem ainda as imagens dessas voluptuosidades que meus costumes de outrora ali gravaram. Sem forças diante de mim quando estou acordado, durante o sono, elas não somente suscitam em mim o prazer, mas o consentimento do prazer e a ilusão da ação. Tais ilusões têm tal poder sobre minha alma e sobre meu corpo, apesar de tão falsas, que seus fantasmas impelem a meu sono o que a realidade não me pode induzir quando em vigília. Acaso então, Senhor meu Deus, será que eu não sou eu nessas horas? E como vai tão grande diferença dentro de mim mesmo, do momento em que passo da vigília para o sono e vice versa! Onde pois está a razão, que durante a vigília resiste a tais sugestões, e que não se abala mesmo diante da realidade? Acaso se fecha juntamente com os olhos? Ou adormece com os sentidos do corpo?

 E por que, muitas vezes, mesmo no sono, resistimos, lembrados de nosso propósito, e nele permanecemos castos, negando o consentimento a tais seduções? Todavia, a diferença é tanta que, no caso de não resistir durante o sono, ao acordar voltamos a encontrar a paz de consciência; e a própria diferença entre os dois estados indica que não fomos nós que fizemos aquilo, e lamentamos o que se fez em nós.

 Senhor onipotente, não poderia tua mão curar todas as enfermidades de minha alma, abolindo também, com maior abundância de graça, os movimentos lascivos de meu sono? cada vez mais multiplica, Senhor, o número de tuas bondades para comigo, para que minha alma, livre do visco da concupiscência, siga até chegar a ti. Para que não seja rebelde, nem mesmo durante o sono; para que, pelo estímulo de imagens bestiais, não só não cometa essas torpezas degradantes até a lascívia carnal, mas que nem mesmo consinta nisso.

 Não é muito para ti, ó Todo-Poderoso, que podes fazer mais do que pedimos e compreendemos, fazer com que, quer minha idade presente, quer na minha vida futura, eu me deleite nessas tentações – mesmo que sejam tão pequenas, que o primeiro esforço as venceria, quando adormeço com pensamentos castos.

 Agora digo exultando ao meu Senhor em que estado me encontro neste gênero de pecado, com tremor pelos dons que já me concedeste, e gemendo pelas minhas imperfeições. Espero que aperfeiçoes em mim tuas misericórdias, até que atinja a plenitude da paz de que gozarão em ti meu espírito e meu corpo, quando a morte for absorvida pela vitória.