## CAPÍTULO I

### Finalidade do livro

 Ó Deus, faz que eu te conheça, meu conhecedor, que eu te conheça como de ti sou conhecido. Virtude de minha alma, penetra-a, assemelha-a a ti, para que a tenhas e possuas sem mancha nem ruga.

 Esta é a esperança com que falo, e nesta esperança me alegro, quando gozo de sã alegria. Tudo o mais desta vida, tanto menos se há de chorar quanto mais o choramos, e tanto mais teríamos que chorar quanto menos o choramos.

 Mas tu amaste a verdade, porque quem a pratica alcança a luz. Eu desejo praticá-la em meu coração, diante de ti, por esta minha confissão, e diante de muitas testemunhas por meus escritos.