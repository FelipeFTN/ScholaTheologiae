## CAPÍTULO XXI

### A memória do que nunca tivemos

 Podemos comparar essa lembrança à que conserva de Cartago, quem a viu? Não, a felicidade não se vê com os olhos, pois não é corporal. Seria pois comparável à lembrança dos números? Também não, pois quem conhece os números não deseja adquiri-los. Pelo contrário, a idéia da felicidade nos inclina a amá-la e a querer possuí-la, para sermos felizes.

 Lembramos dela, talvez, como lembramos da eloqüência? Também não, embora ao ouvir essa palavra, muitos que não são eloqüentes a associam à realidade que ela exprime, e desejariam obtê-la, o que indica que já têm idéia de eloqüência. Foi porém pelos sentidos do corpo que ouviram a eloqüência alheia, deleitando-se com ela, e desejando também ser eloqüentes. E certamente não lhes daria prazer se já não tivessem uma idéia da eloqüência, e nem a desejariam se esta não os tivesse deleitado. Mas a felicidade não a percebemos nos outros por nenhum sentido corporal.

 Essa lembrança, será porventura comparável à da alegria? Talvez, pois quando estou triste me lembro da alegria passada, e quando infeliz, lembro-me da felicidade. Ora, esta alegria, eu jamais a vi, ou ouvi, ou senti, ou saboreei, ou toquei; apenas a experimentei em minha alma quando me alegrei. E esta idéia se fixou em minha memória para que eu pudesse recordá-la, às vezes com desgosto, outras com saudades, conforme as circunstâncias que a geraram.

 De fato me senti invadido de alegria causada por ações torpes, cuja lembrança agora aborreço e abomino; outras vezes alegrei-me por ações boas e honestas, das quais me lembro com saudade; mas já pertencem ao passado, e evoco com tristeza minha antiga alegria.

 Mas onde e quando, então, experimentei a felicidade para lembrar-me dela, para amá-la e deseja-la? Não sou eu apenas, ou alguns que a desejam; mas todos, sem exceção queremos ser felizes. Sem uma noção precisa da felicidade, nossa vontade não teria essa firmeza.

 Que significa isto? Se perguntarmos a dois homens se querem alistar-se no exército, talvez um responda que sim o outro que não. Mas, perguntemos se desejam ser felizes, e ambos responderão que sim, sem nenhuma hesitação. E desejando um engajar-se, e o outro não, têm ambos a mesma finalidade: ser felizes. Um gosta disto, outro daquilo, mas ambos concordam em ser felizes, como seria unânime a resposta afirmativa a quem lhes perguntasse se querem estar alegres. Essa alegria é o que eles chamam de felicidade. E ainda que um siga por um caminho e outro por outro, a finalidade de todos é um só: a alegria. Como a alegria é um sentimento do qual todos temos experiência, a encontramos em nossa memória, e a reconhecemos ao ouvir pronunciar a palavra felicidade.