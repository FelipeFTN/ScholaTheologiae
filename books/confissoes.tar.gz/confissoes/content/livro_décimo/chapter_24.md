## CAPÍTULO XXIV

### Deus e a memória

 Eis como esquadrinhei minha memória em tua procura, Senhor: não me foi possível encontrar-te fora dela. Nada encontrei de ti que não fosse lembrança, e nunca me esqueci de ti desde que te conheci. Onde encontrei a verdade, aí encontrei a meu Deus, que é a própria verdade; e desde que aprendi a conhecer a verdade, nunca mais a esqueci. Por isso, desde que te conheço, permaneces em minha memória. É lá que te encontro quando me lembro de ti e quando sou feliz em ti. Estas são as santas delicias que me deste em tua misericórdia, olhando para minha pobreza.