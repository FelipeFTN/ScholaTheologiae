## CAPÍTULO XLI

### Deus e a mentira

 Examinei minhas fraquezas de pecador nas três formas de concupiscência, e invoquei tua destra para me salvar. Apesar de ter coração ferido, vi teu esplendor, e forçado a recuar, disse: "Quem pode chegar lá? Fui lançado para longe de teus olhos". – Tu és a verdade que preside a todas as coisas. E eu, minha avareza, não queria perder-te, mas queria possuir ao mesmo tempo a ti e à mentira, como os que não querem mentir a ponto de perderem a noção de verdade. Assim te perdi, porque não admites, nem nenhum coração, conviver com a mentira.