## CAPÍTULO XXXIII

### Os prazeres do ouvido

 Os prazeres do ouvido me prendem e me subjugam com mais força, mas tu me desligaste, me libertaste.

 Agradam-me ainda, eu o confesso, os cânticos que tuas palavras vivificam, quando executados por voz suave e artística; todavia eles não me prendem, e dele posso me desvencilhar quando quero. Para assentarem no meu íntimo, em companhia com os pensamentos que lhe dão vida, buscam em meu coração um lugar de dignidade, mas eu me esforço ou me ofereço para ceder-lhes só o lugar conveniente.

 Às vezes parece-me tributar-lhe mais atenção do que devia: sinto que tuas palavras santas, acompanhadas do canto, me inflamam de piedade mais devota e mais ardente do que se fossem cantadas de outro modo. Sinto que as emoções da alma encontram na voz e no canto, conforme suas peculiaridades, seu modo de expressão próprio, um misterioso estímulo de afinidade.

 Mas o prazer dos sentidos, que não deveria seduzir o espírito, muitas vezes me engana. Os sentidos não se limitam a seguir, humildemente, a razão; o mesmo tendo sido admitidos graças à ela, buscam precedê-la e conduzi-la. É nisso que peco sem o sentir, embora depois o perceba.

 Outras vezes, porém, querendo exageradamente evitar este engano, peco por excessiva severidade; chego ao ponto de querer afastar de meus ouvidos, e da própria Igreja, a melodia dos suaves cânticos que habitualmente acompanham os salmos de Davi. Nessas ocasiões parece-me que o mais seguro seria adotar o costume de Atanásio, bispo de Alexandria. Segundo me relataram, ele os mandava recitar com tão fraca inflexão de voz, que era mais uma declamação do que um canto.

 Contudo, quando lembro das lágrimas que derramei ao ouvir os cantos de tua Igreja, nos primórdios de minha conversão, e que ainda agora me comovem, não tanto com o canto, mas com as letras cantadas, voz clara e modulações apropriadas, reconheço novamente a grande utilidade desse costume.

 Assim, oscilo entre o perigo do prazer e a constatação dos efeitos salutares do canto. Por isso, sem emitir juízo definitivo, inclino-me a aprovar o costume de cantar na igreja, para que, pelo prazer do ouvido, a alma ainda muito fraca, se eleve aos sentimentos de piedade. E quando me comovem mais os cantos do que as palavras cantadas, confesso meu pecado e mereço penitencia, e então preferiria não ouvir cantar.

 Eis em que estado me encontro! Chorai comigo, e chorai por mim, vós que alimentais no coração a virtude, fonte de boas obras. Porque vós, a quem isso não afeta, sois insensíveis a tudo isso. E tu, Senhor meu Deus, escuta, olha e vê; tem piedade de mim, cura-me. Eis que me tornei um problema para mim mesmo, sob teu olhar, e aí está precisamente meu mal.