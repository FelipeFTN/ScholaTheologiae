## CAPÍTULO XXXVIII

### A vanglória

 Sou pobre e necessitado, e só melhoro quando, com gemidos íntimos e com desagrado de mim mesmo, busco tua misericórdia, até que minha indigência seja reparada e sanada com a paz que o olho soberbo ignora! Todavia, as palavras de nossa boca, ou nossos atos conhecidos dos homens, encerram uma tentação muito perigosa, filha do amor dos louvores que, para nos iludir com certa excelência, recolhe e mendiga os aplausos alheios. A vanglória me tenta até quando a critico em mim, e é por isso mesmo que eu a desaprovo. Muitas vezes, por excesso de vaidade, há quem se glorie até mesmo do desprezo da vanglória; mas de fato não é mais do desprezo da vanglória que se orgulha, porque ninguém a despreza quando se gloria de a desprezar.