## CAPÍTULO XVIII

### A memória das coisas perdidas

 Uma mulher perdeu uma dracma, e a procurou com sua lanterna. Mas se não se lembrasse dela, não a haveria de encontrar; de fato, se dela não lembrasse, como poderia saber, ao acha-la, que era aquela?

 Lembro-me de ter procurado e achado muitas coisas perdidas, sei disso porque, estando eu à procura, me diziam: "Por acaso é esta?" "Por acaso é aquela?" – e eu sempre respondia que não, até encontrar o que procurava. Se não tivesse fixado a lembrança do objeto, fosse o que fosse, ainda que me fosse mostrado, não o encontraria, pois não o poderia reconhecer. E sempre que perdemos e achamos alguma coisa acontece o mesmo.

 Se alguma coisa desaparece de nossa vista, e não da memória – como sucede com um corpo visível – conservamos interiormente sua imagem e o procuramos até que apareça a nossos olhos. Quando for encontrado, será reconhecido de acordo com essa imagem interior. Não podemos dizer que encontramos um objeto perdido se não o reconhecemos; nem o podemos reconhecer se dele não lembramos. Tinha pois desaparecido da nossa vista, mas era conservado pela memória.