## CAPÍTULO XXV

### Recapitulação

 Onde habitas em minha memória, Senhor, em que lugar dela estás? Que esconderijo construíste aí? Que santuário aí edificaste para ti? Deste-me a honra de morar em minha memória; mas em que parte dela resides? É o que quero agora descobrir.

 Quando me recordei de ti, ultrapassei aquela região da memória que também os animais possuem, pois não te encontrei entre as imagens dos objetos corpóreos. E cheguei àquela parte onde depositei os afetos de minha alma, mas também aí não te encontrei. Cheguei à morada que meu próprio espírito possui na memória – porque também o espírito lembra de si mesmo – mas nem ali estavas. Isso porque não és imagem corpórea, nem afeto de ser vivo, como a alegria, a tristeza, o desejo, o temor, a lembrança, o esquecimento e outros semelhantes, e nem és meu próprio espírito, porque és o Senhor e Deus do espírito, e tudo isso é mutável, enquanto permaneces imutável e subsistes acima de todas as coisas, e te dignaste habitar em minha memória desde que te conheço.

 Mas, por que perguntar em que lugar da memória habitas, como se a memória tivesse compartimentos? Certo é que habitas nela desde que te conheço, e é nela que te encontro, quando penso em ti.