## CAPÍTULO V

### A ignorância do homem

 És tu, Senhor, quem me julga, porque ninguém conhece o que se passa no homem, a não ser o seu espírito que nele está, todavia há no homem coisas que até o espírito que nele habita ignora. Mas tu, Senhor, que o criaste, conheces todas as coisas. E eu, embora diante de ti me despreze e me considere como terra e cinza, sei algo de ti que ignoro de mim mesmo. É certo que agora vemos por espelho, em enigmas, e não face a face. Por isso, enquanto peregrino longe de ti, estou mais presente a mim do que a ti. Sei que em nada podes ser prejudicado, mas ignoro a que tentações posso resistir e a quais não posso. Todavia há esperança, pois és fiel, e não permites que sejamos tentados além de nossas forças; com a tentação, dás também meios para suportar, para que possamos resistir.

 Confessarei, portanto, o que sei de mim, e também o que de mim ignoro, porque o que sei de mim só o sei porque me iluminas, e o que de mim ignoro continuarei ignorando até que minhas trevas se transformem em meio-dia, em tua presença.