## CAPÍTULO VII

### Deus e os sentidos

 Que amo, então, quando amo a meu Deus? Quem é aquele que está acima da minha alma? É por minha alma; portanto, que subirei até ele. Hei de sobrepujar a força que me ata ao corpo, e que enche meu organismo de vida, pois não encontro nela o meu Deus. Se assim fosse, o cavalo e a mula, que não têm inteligência, também o encontrariam, porque essa mesma força vivifica seus corpos.

 E existe outra força, que não só vivifica, mas que também torna sensível minha carne que o Senhor me deu, ordenando ao olho que não ouça, e ao ouvido que não veja, mas àquele que sirva para ver, e a este para ouvir; e que determinou a cada um dos outros sentidos o respectivo lugar e ofício. É deles que se serve minha alma para exercer suas diversas funções, permanecendo, contudo, uma só.

 Vencerei também essa força, que também a possuem o cavalo e a mula, pois também eles sentem por meio do corpo.