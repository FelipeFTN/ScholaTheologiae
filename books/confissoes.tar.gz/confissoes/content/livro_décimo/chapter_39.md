## CAPÍTULO XXXIX

### O amor-próprio

 Há ainda entre nós, profundamente assentada, outra tentação do mesmo gênero, que torna vãos aqueles que se comprazem de si mesmos, ainda que não agradem aos outros, ou até lhes desagradem, ou sequer procuram lhes agradar. E quanto mais enfatuados estejam consigo mesmos, mais desagradam a ti, não só ao se gloriarem dos males como se fossem bens, mas sobretudo quando se gloriam de teus bens como se fossem deles; ou quando, reconhecendo-os em si, eles os atribuem a seus merecimentos; ou ainda quando, atribuindo-os à tua graça, eles não os gozam amigavelmente com os demais, gestando ciúmes e inveja.

 Em todos estes perigos e provas, tu vês o temor de meu coração, e sinto que são mas as feridas que curas em mim do que as que inflijo a mim mesmo.