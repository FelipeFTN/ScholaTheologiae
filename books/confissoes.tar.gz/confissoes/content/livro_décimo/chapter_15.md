## CAPÍTULO XV

### A memória das coisas ausentes

Mas quem poderá explicar se a recordação se faz por meio de imagens ou não?

 Por exemplo: se digo pedra, ou digo sol, sem que tais objetos estejam presentes a meus sentidos, certamente tenho suas imagens na memória, à minha disposição.

 Evoco uma dor do corpo, que está ausente de mim, já que nada me dói. Contudo, se a imagem da dor não estivesse em minha memória, não saberia o que dizia, e ao raciocinar não a distinguiria do prazer.

 Falo de saúde do corpo, estando são; neste caso, está em mim o próprio objeto. No entanto, se sua imagem não estivesse em minha memória, de modo algum lembraria o significado dessa palavra. Os doentes, ouvindo falar de saúde, não saberiam do que se trata, não fosse o poder da memória a conservar a imagem da ausência da realidade.

 Falo dos números com que calculamos, e eles se apresentam na memória, não suas imagens, mas os próprios números.

 Evoco a imagem do sol, e esta se apresenta à minha memória; e não evoco a imagem de uma imagem, mas a própria imagem, disponível à recordação.

 Falo em memória, e reconheço o que falo, mas de onde o sei, senão da própria memória? Estará ela presente a si própria por sua imagem, e não por si mesma?