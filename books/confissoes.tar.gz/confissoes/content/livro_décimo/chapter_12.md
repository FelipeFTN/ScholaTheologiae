## CAPÍTULO XII

### A memória e as matemáticas

 A memória guarda também as relações e inumeráveis leis dos números e dimensões, sendo que nenhuma dessas idéias foi impressa em nós pelos sentidos do corpo, porque não têm cor, nem som, nem têm cheiro, nem gosto, nem são tangíveis. Ouço, quando elas se fala, os sons das palavras que as exprimem; mas uma coisa são os sons, e outra bem diferente são as idéias que elas significam. As palavras soam de modo diferente em grego e em latim; mas as idéias nem são gregas, nem latinas, nem de nenhuma outra língua.

 Vi linhas traçadas por artistas, finas como um fio de aranha. Mas as linhas materiais não são a imagem das que vi com meus olhos carnais. Para reconhecê-las não há necessidade alguma de se pensar em um corpo qualquer, pois, é no espírito que as reconhecemos.

 Também conheci os números mediante os sentidos do corpo: mas a idéia de número é bem diferente: não são imagens dos primeiros, possuindo por isso mesmo um ser muito mais real.

Ria-se de mim quem não compreender o que disse; eu terei compaixão de seu riso.