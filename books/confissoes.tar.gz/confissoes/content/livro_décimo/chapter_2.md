## CAPÍTULO II

### O que é confessar a Deus

 E, para ti, Senhor, que conheces o abismo da consciência humana, que poderia haver de oculto em mim, ainda que não to quisesse confessar?

 Poderia apenas esconder-te de mim, e nunca me esconder de ti. Agora que meus gemidos dão testemunho do desagrado que sinto por mim, tu me iluminas e me agradas, e és amado e desejado a ponto de eu me envergonhar de mim. renuncio a mim para te escolher, e não quero agradar a ti ou a mim senão por teu amor.

 Portanto, assim como sou, Senhor, tu me conheces. Já te disse com que escopo me vou confessando a ti. Faço esta confissão não com palavras e vozes do corpo, mas com as palavras da alma e o brado da inteligência, que teus ouvidos conhecem. Quando sou mau, confessar-me ai é o mesmo que desprezar a mim próprio; quando sou bom, é apenas nada atribuir a mim mesmo. Porque tu, Senhor, abençoas o justo, mas antes tornas justo ao pecador.

 Assim, meu Deus, a confissão que faço em tua presença, é e não é silenciosa; a boca se cala, mas meu coração clama. Tudo o que digo aos homens de verdadeiro já tinhas ouvido de mim, e nem ouves nada de mim que antes não me tivesses dito.