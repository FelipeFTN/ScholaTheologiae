# LIVRO DÉCIMO

## CAPÍTULO I

### Finalidade do livro

 Ó Deus, faz que eu te conheça, meu conhecedor, que eu te conheça como de ti sou conhecido. Virtude de minha alma, penetra-a, assemelha-a a ti, para que a tenhas e possuas sem mancha nem ruga.

 Esta é a esperança com que falo, e nesta esperança me alegro, quando gozo de sã alegria. Tudo o mais desta vida, tanto menos se há de chorar quanto mais o choramos, e tanto mais teríamos que chorar quanto menos o choramos.

 Mas tu amaste a verdade, porque quem a pratica alcança a luz. Eu desejo praticá-la em meu coração, diante de ti, por esta minha confissão, e diante de muitas testemunhas por meus escritos.

## CAPÍTULO II

### O que é confessar a Deus

 E, para ti, Senhor, que conheces o abismo da consciência humana, que poderia haver de oculto em mim, ainda que não to quisesse confessar?

 Poderia apenas esconder-te de mim, e nunca me esconder de ti. Agora que meus gemidos dão testemunho do desagrado que sinto por mim, tu me iluminas e me agradas, e és amado e desejado a ponto de eu me envergonhar de mim. renuncio a mim para te escolher, e não quero agradar a ti ou a mim senão por teu amor.

 Portanto, assim como sou, Senhor, tu me conheces. Já te disse com que escopo me vou confessando a ti. Faço esta confissão não com palavras e vozes do corpo, mas com as palavras da alma e o brado da inteligência, que teus ouvidos conhecem. Quando sou mau, confessar-me ai é o mesmo que desprezar a mim próprio; quando sou bom, é apenas nada atribuir a mim mesmo. Porque tu, Senhor, abençoas o justo, mas antes tornas justo ao pecador.

 Assim, meu Deus, a confissão que faço em tua presença, é e não é silenciosa; a boca se cala, mas meu coração clama. Tudo o que digo aos homens de verdadeiro já tinhas ouvido de mim, e nem ouves nada de mim que antes não me tivesses dito.

## CAPÍTULO III

### Por que se confessar aos homens?

 Que tenho eu que ver com os homens, para que me ouçam as confissões, como se eles pudessem curar as minhas enfermidades? São curiosos para conhecer a vida alheia, mas indolentes para corrigir a própria! Por que desejam ouvir de mim quem sou, quando não se importam em saber de ti o que são? E como podem saber, ao me ouvirem falar de mim mesmo, se lhes digo a verdade, uma vez que homem algum sabe o que se passa no outro, senão o espírito do homem, que nele, habita? Mas, se ouvissem a ti falar deles, não poderiam dizer: "O Senhor mente". E o que é ouvir-te falar de si, senão conhecerem-se a si mesmos? E quem, conhecendo a si mesmo, pode dizer "é falso", sem mentir?

 A caridade crê em tudo – pelo menos entre corações que ela unifica em si por seus laços – por isso também eu, Senhor, me confesso a ti para que me ouçam os homens. A eles não posso provar que falo a verdade; mas crêem-me aqueles cujos ouvidos a caridade abre para mim.

 Mas tu, Médico da minha alma, faze-me ver claramente a utilidade de meu propósito. As confissões de meus pecados passados – que já perdoaste e esqueceste, para me fazer feliz em ti, transformando minha alma com tua fé e teu sacramento – levam o coração dos que as lêem e ouvem a não dormir no desespero dizendo: "Não posso". Mas despertem para o amor pela tua misericórdia e para a doçura de tua graça, que fortalece o fraco e este se dá conta de sua debilidade.

 Os bons, por sua vez, se agradam em ouvir os pecados passados daqueles que já não sofrem. Agrada-lhes, não por serem pecados, mas porque o foram, e agora já não o são.

 Mas, Senhor meu – a quem todos os dias se confessa minha consciência, agora mais confiante com a esperança na tua misericórdia que na sua inocência – que proveito haverá em confessar aos homens, na tua presença, neste livro, não o que fui, mas o que sou agora? Sobre a confissão do passado, e dos seus eventuais proveitos, já falei acima.

 Há muitos porém, quer me conheçam, quer não, que desejam saber quem sou agora, neste momento em que escrevo as Confissões. Já ouviram de mim ou de outros alguma coisa a meu respeito, mas seu ouvido não ouve meu coração, onde eu sou o que sou. Querem, certamente, saber por confissão minha o que sou no íntimo, lá onde não podem penetrar com a vista, com o ouvido, ou com a mente. Estão dispostos a acreditar em mim. Mas poderão igualmente estar certos de me conhecer? A caridade, que os torna bons, lhes diz que eu não minto quando confesso tais coisas de mim. É ela que os faz acreditarem em mim.

## CAPÍTULO IV

### O fruto das confissões

 Mas, com que propósito desejam ouvir-me? Desejarão talvez congratular-me comigo, ouvindo quanto me aproximei de ti por tua graça, e orar por mim, ao ouvir quanto me retardou o peso de minhas culpas? A estes mostrarei quem sou; já não é pequeno fruto, Senhor meu Deus, que muitos te dêem graças por mim, e que muitos te roguem por mim. possa o coração de meus irmãos amar em mim o que ensinas a amar, e, deplorar em mim o que ensinas a aborrecer! Mas que brotem tais sentimentos em uma alma irmã, e não em almas estranhas, ou nesses filhos espúrios, cuja boca fala vaidade, e cuja direita é a direita da iniqüidade, que o faça uma alma fraterna que se alegra por mim quando me aprova, e quando me reprova se aflige por mim, porque quer me aprove, quer não, me ama.

 É a esses que me revelarei. Que eles respirem diante de minhas boas ações, e suspirem à vista de meus pecados. As obras boas são tuas obras e teus dons; as más são meus pecados. As obras boas são tuas obras e teus dons; as más são meus pecados, objeto de teus juízos. Respirem pelo bem e suspirem pelo mal, e que subam à tua presença hinos e lágrimas desses corações fraternos, que são os teus turíbulos.

 E tu, Senhor, que te alegras com a fragrância de teu santo templo, tem piedade de mim, segundo tua grande misericórdia por causa de teu nome, e tu, que jamais abandonas uma obra começada, aperfeiçoa em mim o que há de incompleto.

 Este poderá ser fruto de minhas confissões, não do que fui, mas do que sou. Farei minha confissão não apenas a ti, com íntima alegria mesclada de temor, e com secreta tristeza mesclada de esperança, mas também para os homens, que compartilham minha alegria e de minha mortalidade, meus concidadãos e peregrinos como eu, quer os que me precederam, como os que me seguem ou me acompanham no caminho da vida. Estes são teus servos, meus irmãos, que tu quiseste fossem filhos teus e meus senhores, e a quem me mandaste servir se quisesse viver contigo e de ti.

 Mas este preceito teria sido de pouco valor para mim, se teu Verbo o tivesse proferido apenas com palavras, e não tivesse mostrado o caminho com a obra. Eis que eu o imito pela ação e pela palavras, e o faço à sombra de tuas asas, o perigo seria grande demais, se minha alma aí não se abrigasse, e se minha fraqueza não te fosse conhecida.

 Sou como uma criança, mas meu Pai vive sempre, e é meu tutor idôneo; ele é a um tempo o que me gerou e o que me protege. Tu és todo o meu bem, tu, onipotente, que estás comigo mesmo antes de eu estar contigo.

 Revelarei pois, a estes, a quem me mandas servir, não como fui, mas como já sou agora, e como ainda não sou. Mas não quero julgar-me a mim mesmo. Assim é que peço para ser ouvido.

## CAPÍTULO V

### A ignorância do homem

 És tu, Senhor, quem me julga, porque ninguém conhece o que se passa no homem, a não ser o seu espírito que nele está, todavia há no homem coisas que até o espírito que nele habita ignora. Mas tu, Senhor, que o criaste, conheces todas as coisas. E eu, embora diante de ti me despreze e me considere como terra e cinza, sei algo de ti que ignoro de mim mesmo. É certo que agora vemos por espelho, em enigmas, e não face a face. Por isso, enquanto peregrino longe de ti, estou mais presente a mim do que a ti. Sei que em nada podes ser prejudicado, mas ignoro a que tentações posso resistir e a quais não posso. Todavia há esperança, pois és fiel, e não permites que sejamos tentados além de nossas forças; com a tentação, dás também meios para suportar, para que possamos resistir.

 Confessarei, portanto, o que sei de mim, e também o que de mim ignoro, porque o que sei de mim só o sei porque me iluminas, e o que de mim ignoro continuarei ignorando até que minhas trevas se transformem em meio-dia, em tua presença.

## CAPÍTULO VI

### Quem é Deus?

 O que sei, Senhor, sem sombra de dúvida, é que te amo. Feriste meu coração com tua palavra, e te amei. O céu, a terra e tudo quanto neles existe, de todas as partes me dizem que te ame; nem cessam de repeti-lo a todos os homens, para que não tenham desculpas. Terás compaixão mais profunda de quem já te compadeceste; e usarás de misericórdia com quem já foste misericordioso. De outro modo, o céu e a terra cantariam teus louvores a surdos.

 Mas, que amo eu, quando te amo? Não amo a beleza do corpo, nem o esplendor fugaz, nem a claridade da luz, tão cara a estes meus olhos, nem as doces melodias das mais diversas canções, nem a fragrância de flores, de ungüentos e de aromas, nem o maná, nem o mel, nem os membros tão afeitos aos amplexos da carne. Nada disto amo quando amo o meu Deus. E, contudo, amo uma luz, uma voz, um perfume, um alimento, um abraço de meu homem interior, onde brilha para minha alma uma luz sem limites, onde ressoam melodias que o tempo não arrebata, onde exalam perfumes que o vento não dissipa, onde se provam iguarias que o apetite não diminui, onde se sentem abraços que a saciedade não desfaz. Eis o que amo quando amo o meu Deus!

 Então, o que é Deus? Perguntei à terra, e ela me disse: "Eu não sou Deus". E tudo o que nela existe me respondeu o mesmo. Perguntei ao mar, aos abismos e aos répteis viventes, e eles me responderam: "Não somos teu Deus; busca-o acima de nós". Perguntei aos ventos que sopram; e todo o ar, com seus habitantes, me disse: "Anaxímenes está enganado eu não sou Deus". Perguntei ao céu, ao sol, à luz e às estrelas. "Tampouco somos o Deus a quem procuras" – me responderam.

 Disse então à todas as coisas que meu corpo percebe: "Dizei-me algo de meu Deus, já que não sois Deus; dizei-me alguma coisa dele" – e todas exclamaram em coro: "Ele nos criou" – Minha pergunta era meu olhar, e sua resposta a sua beleza.

 Dirigi-me, então, a mim mesmo, e perguntei: "E tu, quem és?" – e respondi: "Um homem". Para me servirem, tenho um corpo e uma alma: aquele exterior, esta interior. Por qual deles deverei perguntar pelo meu Deus, a quem já havia procurado com o corpo desde a terra até o céu, até onde pude enviar os raios de meu olhar como mensageiros? Melhor, sem dúvida, é a parte interior de mim mesmo. É a ela que dirigem suas respostas todos os mensageiros de meu corpo, como a um presidente ou juiz, respostas do céu, da terra, e de tudo o que existe, e que proclamam: "Não somos Deus" – e ainda – "Ele nos criou". O homem interior conhece essas coisas por meio do homem exterior; mas o homem interior, que é a alma, também conhece essas coisas por meio dos sentidos do corpo.

 Interroguei a imensidão do universo acerca de meu Deus, e ele me respondeu: "Não sou eu, mas foi ele quem me criou".

 Mas essa beleza não se manifesta a quantos têm sentidos perfeitos? E por que não fala a todos a mesma linguagem?

 Os animais, pequenos ou grandes, a vêem; mas não podem interrogá-la, porque não receberam a razão que, como juiz, interprete as mensagens dos sentidos. Os homens, porém, podem interrogá-la, para que as perfeições invisíveis de Deus se manifestem pelas suas obras. Mas o amor às coisas criadas os escraviza, e assim os torna incapazes de julga-las. Ora, elas só respondem aos que podem julgar-lhes as respostas. Elas não mudam sua linguagem, isto é, sua beleza, quando um só as vê, e outro as interroga; elas não lhes aparecem diferentes mas, para uns ficam mudas, enquanto falam a outros. Ou melhor: eles falam a todos, mas apenas se entendem os que comparam sua expressão exterior com a verdade interior. De fato a verdade me diz: "Teu Deus não é nem o céu, nem a terra, nem corpo algum. A natureza das coisas o diz para quem sabe ver; a matéria é menor em seus elementos que em seu todo. Por isso, minha alma, digo-te que és superior ao corpo, pois vivificas sua matéria, dando-lhe vida, como nenhum corpo pode dar a outro corpo. Mas teu Deus é também para ti a vida de tua vida.

## CAPÍTULO VII

### Deus e os sentidos

 Que amo, então, quando amo a meu Deus? Quem é aquele que está acima da minha alma? É por minha alma; portanto, que subirei até ele. Hei de sobrepujar a força que me ata ao corpo, e que enche meu organismo de vida, pois não encontro nela o meu Deus. Se assim fosse, o cavalo e a mula, que não têm inteligência, também o encontrariam, porque essa mesma força vivifica seus corpos.

 E existe outra força, que não só vivifica, mas que também torna sensível minha carne que o Senhor me deu, ordenando ao olho que não ouça, e ao ouvido que não veja, mas àquele que sirva para ver, e a este para ouvir; e que determinou a cada um dos outros sentidos o respectivo lugar e ofício. É deles que se serve minha alma para exercer suas diversas funções, permanecendo, contudo, uma só.

 Vencerei também essa força, que também a possuem o cavalo e a mula, pois também eles sentem por meio do corpo.

## CAPÍTULO VIII

### O milagre da memória

Vencerei então esta força de minha natureza, subindo por degraus até meu Criador.

 Chegarei assim diante dos campos, dos vastos palácios da memória, onde estão os tesouros de inúmeras imagens trazidas por percepções de toda espécie. Lá também estão armazenados todos os nossos pensamentos, quer aumentando, quer diminuindo, ou até alterando de algum modo o que nossos sentidos apanharam, e tudo o que aí depositamos, se ainda não foi sepultado ou absorvido no esquecimento.

 Quando ali penetro, convoco todas as lembranças que quero. Algumas se apresentam de imediato, outras só após uma busca mais demorada, como se devessem ser extraídas de receptáculos mais recônditos. Outras irrompem em turbilhão e, quando se procura outra coisa, se interpõem como a dizer: "Não seremos nós que procuras?" Eu as afasto com a mão do espírito da frente da memória, até que se esclareça o que quero, surgindo do esconderijo para a vista.

 Há imagens que acodem à mente facilmente e em seqüência ordenada à medida que são chamadas, as primeiras cedendo lugar às seguintes, e desaparecem, para se apresentarem novamente quando eu o quiser. É o que sucede quando conto alguma coisa de memória.

 Ali se conservam também, distintas em espécies, as sensações que aí penetraram cada qual por sua porta: a luz, as cores, as formas dos corpos, pelos olhos; toda espécie de sons, pelos ouvidos; todos os odores, pelas narinas; todos os sabores, pela boca; enfim, pelo tato de todo o corpo, o duro e o brando, o quente e o frio, o suave e o áspero, o pesado e o leve, quer extrínseco, como intrínseco ao corpo. A memória armazena tudo isso em seus vastos recessos, em suas secretas e inefáveis sinuosidades, para lembra-lo e trazê-lo à luz conforme a necessidade. Todas essas imagens entram na memória por suas respectivas portas, sendo ali armazenadas.

 Todavia, não são as coisas em si que entram na memória, mas as imagens das coisas sensíveis, que ali ficam à disposição do pensamento que as evoca. Mas quem poderá explicar como se formaram tais imagens, apesar de se conhecer o sentido pelo qual foram captadas e escondidas em seu íntimo? Pois, mesmo quando estou em silêncio e no escuro, imagino, se quiser, as cores, e sei distinguir o branco do preto, e todas as outras entre si; e isto sem que os sons, mesmo os lembrados, perturbem minhas imagens visuais, e permanecem como que a parte. Se decido chama-los, eles se apresentam imediatamente. Mesmo quando minha língua descansa e minha garganta se cala, canto quanto quero, sem que as imagens das cores, também presentes, se interponham ou perturbem enquanto me sirvo do tesouro que me entrou pelos ouvidos.

 Do mesmo modo as demais impressões, introduzidas e armazenadas em mim por meio dos outros sentidos, posso recordar a meu talante; distingo o aroma dos lírios do das violetas, sem cheirar nenhuma flor; e sem provar nem tocar em nada, mas apenas com a lembrança, posso preferir o mel ao arrobe e o macio ao áspero.

 Tudo isto realizo interiormente, no imenso palácio da memória. Ali eu tenho às minhas ordens o céu, a terra, o mar, com tudo o que neles pude perceber, com exceção do que já me esqueci. Ali encontro a mim mesmo, recordo de mim e de minhas ações, de seu tempo e lugar, e dos sentimentos que me dominavam ao praticá-las. Ali encontro a mim mesmo, recordo de mim e de minhas ações, de seu tempo e lugar, e dos sentimentos que me dominavam ao praticá-las. Ali estão todas as lembranças do que aprendi, quer pelo testemunho alheio, quer pela experiência. Deste mesmo manancial provém as analogias entre fatos de minhas experiências pessoais, ou em que acreditei baseado nas experiências previas; ligo umas e outras ao passado, e medito no futuro, nas ações, nos acontecimentos, nas esperanças, e tudo como se estivesse presente. "Farei isto ou aquilo" – digo para mim, nesse vasto universo de minha alma, repleto de imagens de tantas e tão grandes coisas. E disso tiro esta ou aquela conclusão. "Oh! Se acontecesse isto ou aquilo!" "Queira Deus não aconteça isto ou aquilo!" isto digo em meu íntimo, e nisso visualizando as imagens das realidades que exprimo, saídas do mesmo tesouro da memória; sem elas, nada poderia dizer.

 Grande é realmente o poder da memória, prodigiosamente grande, meu Deus! É um santuário amplo e infinito. Quem o pôde sondar até suas profundezas? É um poder próprio de meu espírito, que pertence à minha natureza; mas eu não sou capaz de compreender inteiramente o que sou. Será o espírito demasiado estreito para se conter a si mesmo? Onde, então, está o que ele não pode conter de si? Estaria fora dele, e não nele? Como então não o contém?

 Esta idéia me provoca grande admiração, e me enche de espanto. Viajam os homens para admirar as alturas dos montes, as grandes ondas do mar, as largas correntes dos rios, a imensidão do oceano, a órbita dos astros, e se esquecem de si mesmos! Nem se admiram que eu fale dessas coisas sem vê-las com os olhos; contudo, eu não as poderia mencionar se esses montes, se essas ondas, esses rios, esses astros, que eu vi, se esse oceano, no qual acredito pelo testemunho alheio, eu não os visse na memória em toda sua dimensão, como se estivessem diante de mim. mas quando eu os vi com meus olhos, eu não os absorvi; não são as coisas que se encontram dentro de mim, mas apenas suas imagens. E sei por qual sentido do corpo recebi a impressão de cada uma delas.

## CAPÍTULO IX

### A memória intelectual

 E não se limita a isto a imensa capacidade de minha memória. Ali estão, como em um lugar recôndito, que alias, não é um lugar, todas as noções aprendidas das artes liberais, pelo menos as que ainda não esqueci. Mas, neste caso, não são as imagens delas que trago em mim, mas as próprias realidades em si. As noções de literatura, a dialética, as diferentes espécies de questões, tudo o que sei a respeito desses problemas estão em minha memória, mas não estão ali como a imagem solta de uma coisa, cuja realidade se deixou fora. Nesse caso seria como um som que se ouve e passa, como a voz que deixa no ouvido um rastro, que permite que a lembremos, como se ainda soasse embora já não soe; ou como o perfume que, ao passar e desvanecer-se no ar, atinge o olfato e grava sua imagem na memória, imagem que a lembrança reproduz; ou como o alimento, que perde o sabor no estômago, mas o conserva na memória; ou como um corpo que se sente pelo tato e que, ausente, é imaginado pela memória. Todas essas realidades não nos penetram a memória, mas tão somente são captadas as suas imagens com maravilhosa rapidez, e dispostas, digamos, em compartimentos admiráveis, de onde são extraídas pelo milagre da lembrança.

## CAPÍTULO X

### Memória dos sentidos

 Ouço dizer que há três gêneros de questões a saber: se uma coisa existe, qual a sua natureza e qual sua qualidade – retenho a imagem dos sons de que se compõem estas palavras, e sei que estes atravessaram o ar como ruído, e já não existem. Mas as realidades significadas por tais palavras, eu jamais atingi com nenhum sentido do corpo, nem as vi em nenhuma parte fora de meu espírito; o que gravei na minha memória não são suas imagens, mas as próprias realidades. Que me digam, se o puderem, por onde entraram em mim! percorro em vão todas as portas do meu corpo, e não descubro por onde poderiam ter entrado. Com efeito: os olhos dizem: "Se são coloridas, fomos nós que as transmitimos." – Os ouvidos dizem: "Se eram sonoras, foram por nós comunicadas". – As narinas dizem: "Se tinham cheiro, passaram por aqui". – E o gosto diz: "Se não têm sabor, nada me perguntem". – O tato declara: "Se não são corpóreas, eu não as toquei, e portanto não poderia revelá-las"

 De onde, então, e por onde entraram em minha memória? Ignoro-o. Aprendi-as não dando crédito ao testemunho alheio, mas as reconheci em mim e aprovei-as como verdadeiras; confieias a meu espírito como em depósito, de onde poderei tirá-las quando quiser. Estavam pois ali, antes mesmo que eu as aprendesse, mas não na memória. E onde estavam então? E porque, ao serem mencionadas, eu as reconheci e disse: "É assim mesmo, é verdade" – senão porque já estavam em minha memória? Mas tão escondidas e sepultadas em tão secretos recessos, que se alguém não as arrancasse dali com suas perguntas, talvez eu nem pudesse concebê-las.

## CAPÍTULO XI

### Idéias inatas

 Por isso descobrimos que adquirir tais noções – cujas imagens não atingimos por meio dos sentidos mas que percebemos em nós, sem o auxílio de imagens, tais como são em si mesmas, nada mais é do que coligir com o pensamento os elementos esparsos na memória e, pela reflexão, obrigá-los a estarem sempre disponíveis à memória, onde antes se ocultavam em desordem e abandono, de modo que se apresentem sem dificuldade ao chamado do nosso espírito. E quantas noções deste tipo não encerra minha memória, já descobertas e, como disse, postas como que à mão; eis o que chamamos de "aprender" e "saber". Se porém deixo de as recordar por uns tempos, de tal modo submergem e se dispersam em seus profundos esconderijos, que é preciso reuni-las uma segunda vez, como se fossem novas (cogente) – pois não têm outra habitação – e juntá-las de novo para que possam ser objeto do saber; isto é: preciso tirá-las de sua condição de dispersão e juntá-las novamente. Daí a palavra cogitare, porque cogo e cogito são como ago e agito, e facio, facito. Contudo, a inteligência reivindicou essa palavra (cogito) para si, de modo que essa operação de coligir, de reunir no espírito, e não em outra parte, é propriamente o que se chama pensar (cogitare).

## CAPÍTULO XII

### A memória e as matemáticas

 A memória guarda também as relações e inumeráveis leis dos números e dimensões, sendo que nenhuma dessas idéias foi impressa em nós pelos sentidos do corpo, porque não têm cor, nem som, nem têm cheiro, nem gosto, nem são tangíveis. Ouço, quando elas se fala, os sons das palavras que as exprimem; mas uma coisa são os sons, e outra bem diferente são as idéias que elas significam. As palavras soam de modo diferente em grego e em latim; mas as idéias nem são gregas, nem latinas, nem de nenhuma outra língua.

 Vi linhas traçadas por artistas, finas como um fio de aranha. Mas as linhas materiais não são a imagem das que vi com meus olhos carnais. Para reconhecê-las não há necessidade alguma de se pensar em um corpo qualquer, pois, é no espírito que as reconhecemos.

 Também conheci os números mediante os sentidos do corpo: mas a idéia de número é bem diferente: não são imagens dos primeiros, possuindo por isso mesmo um ser muito mais real.

Ria-se de mim quem não compreender o que disse; eu terei compaixão de seu riso.

## CAPÍTULO XIII

### A memória da memória

 Tudo isso eu guardo em minha memória, assim como o modo pelo qual o aprendi. Também guardo na memória as muitas argumentações infundadas que ouvi contra essas verdades. Essas objeções sem dúvida são falsas, mas não é falso recordá-las. E lembro de ter sabido distinguir entre essas verdades e os erros que se lhe opunham. Vejo agora que uma coisa é essa distinção, que faço hoje, e outra o recordar ter feito muitas vezes tal distinção, ao considerá-las. Lembro-me, portanto, de ter muitas vezes compreendido isso, e confio à memória o ato atual de distingui-las e compreendê-las, para me lembrar, mais tarde, de que hoje as compreendi. Lembro-me então de que me lembrei; e se mais tarde lembrar de que agora pude recordar essas coisas, será ainda por força da memória.

## CAPÍTULO XIV

### A lembrança dos sentimentos

 Essa mesma memória conserva também os afetos da alma, não do modo como os sente a alma quando da vivencia, mas de modo muito diverso, segundo o exige a força da memória. Lembro-me de ter estado alegre, ainda que não o esteja agora; recordo minha tristeza passada, sem estar triste; lembro-me de ter sentido medo, sem senti-lo de novo; lembro-me de antigo desejo, sem que o mesmo sinta agora. Outras vezes, pelo contrário, lembro-me com alegria a tristeza passada, e com tristeza uma alegria passada. Isto nada tem para admirar quando se trata de emoções corporais, porque uma coisa é a alma e outra o corpo; e assim não é maravilha que me lembre com alegria de um sofrimento físico já passado.

 Porém, aqui o espírito é a própria memória. Quando confiamos uma tarefa a alguém, dizemos: "Não o guardei no espírito", "fugiu-me do espírito". É, portanto, a memória que chamamos de espírito. Sendo assim, por que ao evocar com alegria uma tristeza passada, meu espírito sente alegria e minha memória, tristeza? Se meu espírito se alegra com a alegria que tem em si, por que a memória não se entristece com a tristeza, que também tem em si? Seria a memória estranha ao espírito? Quem ousará afirmá-lo? Sem dúvida a memória é como o estômago da alma, e a alegria e a tristeza são como alimentos, doce ou amargo; quando tais emoções são confiadas à memória, depois de passarem, digamos, por esse estômago, podem ali serem guardadas, mas já perderam o sabor. Seria ridículo comparar emoções e alimento como semelhantes. Contudo, elas não são totalmente diferentes.

 É ainda da memória que tiro a distinção entre as quatro emoções da alma: o desejo, a alegria, o medo e a tristeza. Assim, todo raciocínio que eu teça, dividindo cada uma delas nas espécies de seus gêneros, definindo-as, é na memória que encontro o que tenho a dizer, e de lá tiro tudo o que digo. Contudo, ao recordar essas emoções, não me perturbo com nenhuma delas. E antes mesmo que eu as recordasse para discuti-las, elas ali estavam, e por isso puderam ser tiradas da memória mediante a lembrança. Talvez a lembrança tire da memória essas emoções como o ato de ruminar tira do estômago os alimentos. Mas então, por que aquele que rumina sobre tais paixões não sente na boca do pensamento a doçura da alegria ou a amargura da tristeza? Estará justamente nisto a diferença entre tais fatos? De fato, quem gostaria de falar dessas emoções se, todas as vezes que falássemos do medo ou da tristeza, nos víssemos tristes ou temerosos?

 Contudo, certamente não poderíamos falar deles se não encontrássemos na memória não só os sons dessas palavras, segundo a imagem gravada em nós pelos sentidos, mas ainda as noções que elas exprimem. Essas noções, nós não a recebemos por nenhuma porta da carne, mas a própria alma, sentindo-as pela experiência das próprias emoções, confiou-as à memória; ou então a própria memória as reteve, sem que ninguém lhas confiasse.

## CAPÍTULO XV

### A memória das coisas ausentes

Mas quem poderá explicar se a recordação se faz por meio de imagens ou não?

 Por exemplo: se digo pedra, ou digo sol, sem que tais objetos estejam presentes a meus sentidos, certamente tenho suas imagens na memória, à minha disposição.

 Evoco uma dor do corpo, que está ausente de mim, já que nada me dói. Contudo, se a imagem da dor não estivesse em minha memória, não saberia o que dizia, e ao raciocinar não a distinguiria do prazer.

 Falo de saúde do corpo, estando são; neste caso, está em mim o próprio objeto. No entanto, se sua imagem não estivesse em minha memória, de modo algum lembraria o significado dessa palavra. Os doentes, ouvindo falar de saúde, não saberiam do que se trata, não fosse o poder da memória a conservar a imagem da ausência da realidade.

 Falo dos números com que calculamos, e eles se apresentam na memória, não suas imagens, mas os próprios números.

 Evoco a imagem do sol, e esta se apresenta à minha memória; e não evoco a imagem de uma imagem, mas a própria imagem, disponível à recordação.

 Falo em memória, e reconheço o que falo, mas de onde o sei, senão da própria memória? Estará ela presente a si própria por sua imagem, e não por si mesma?

## CAPÍTULO XVI

### A memória do esquecimento

 E quando falo do esquecimento, e reconheço de que falo, como poderia eu reconhecê-lo se dele não lembrasse? Não falo do som da palavra, mas da realidade que ela exprime. Se eu a tivesse esquecido, não seria capaz de reconhecer o significado de tal som. Por isso, quando me lembro da memória é por ela mesmo que se apresenta a mim; mas quando me lembro do esquecimento, este e a memória estão presentes simultaneamente: a memória, com que me recordo, e o esquecimento, de que me recordo.

 Mas, que é o esquecimento, senão falta de memória? E como pode ele estar presente na minha lembrança. Se sua lembrança significa não lembrar? Mas se nos lembramos, o guardamos na memória, e se nos é impossível reconhecer o que significa a palavra esquecimento, quando a ouvimos, a não ser que dele nos lembremos, logo a memória é a que retém o esquecimento. Ele está na memória, pois do contrário, nós o esqueceríamos; mas, ele presente, nós nos esquecemos. Segue-se que ele não está presente à memória por si mesmo, quando nos lembramos dele, mas por sua imagem. Do contrário, o esquecimento não faria com que nos lembrássemos, mas com que nos esquecêssemos. Mas, enfim, quem poderá descobrir, quem poderá compreender o modo como isto se realiza?

 Mas, Senhor, esgota-me esta busca e é, portanto, sobre mim mesmo que me canso; tornei-me para mim mesmo uma terra de dificuldades e árduos labores. Por que não exploro agora as regiões do firmamento, nem meço as distâncias dos astros, nem busco as leis do equilíbrio da terra. Sou eu que me lembro, eu, o meu espírito. Não é de admirar que esteja longe de mim tudo o que não sou eu. Todavia, que há mais perto de mim do que eu mesmo? No entanto, é-me impossível compreender a natureza de minha memória, sem a qual eu nem poderia pronunciar meu próprio nome.

 Que direi então, desde que tenho a certeza que lembro do esquecimento? Diria talvez que não está em minha memória o que recordo? Ou talvez direi que o esquecimento está em minha memória, para que não o esqueça? Ambas hipóteses são grandes absurdos. Vejamos uma terceira hipótese: poderei eu afirmar que minha memória retém a imagem do esquecimento, e não o esquecimento em si, quando dele me lembro? Com que fundamento, pois, poderei dizê-lo, se para que se grave na memória a imagem de um objeto, é necessário que este esteja presente antes, de onde emana a imagem a ser gravada? É assim que lembro de Cartago, e assim de todos os outros lugares por que passei; assim me lembro do rosto dos homens que vi e das coisas que meus sentidos me deram a conhecer; assim me lembro ainda da dor física, coisas cujas imagens a memória fixou quando estavam presentes, para que eu as pudesse contemplar e repassar em espírito, quando eu as evocasse na sua ausência.

 Se, pois, é a imagem do esquecimento que está na memória, e não ele mesmo, é evidente que nalgum momento esteve presente para que sua imagem fosse fixada. Mas, se estava presente, como podia gravar na memória sua imagem, se o esquecimento apaga com sua presença tudo o que lá está impresso? Contudo, seja qual for o mecanismo desse fenômeno, e por mais incompreensível e inexplicável que seja, estou certo de que me lembro do esquecimento, que apaga da memória, todas as nossas lembranças.

## CAPÍTULO XVII

### Deus e a memória

 Grande é o poder da memória! E ela tem algo de terrível, meu Deus, em sua complexidade infinita e profunda. E isto é o espírito, e isto sou eu mesmo. Que sou, pois meu Deus? Qual a minha natureza? Vida vária e multiforme, de amplidão imensa. Eis-me em minha memória, em seus campos, antros, inumeráveis cavernas, tudo isso infinitamente cheio de toda espécie de coisas, também inumeráveis. Umas gravadas em imagens, como os corpos; outras, estão sob a forma de não sei que noções e sinais, como os afetos da alma, que a memória conserva quando a alma já não os sente, embora tudo o que está na memória esteja também no espírito. Percorro em todas as direções este mundo interior, vou de um lado para outro, e nele me aprofundo o mais possível, sem encontrar-lhe os limites, tão grande é a vida que reside no homem mortal!

 Que hei de fazer, pois, meu Deus, minha verdadeira vida? Ultrapassarei também esta faculdade que se chama memória? Ultrapassá-la-ei para chegar a ti, doce luz? Que dizes? Subindo em espírito a ti, que estás acima de mim, ultrapassarei também esta minha força, que se chama memória, pois quero atingir-te onde és acessível, e unir-me a ti por onde possa fazê-lo. Também os animais e as aves têm memória, porque de outro modo não voltariam a seus ninhos e tocas, nem fariam outras coisas habituais, e nem mesmo poderiam adquiri hábitos sem a memória. Passarei, pois, além da memória para chegar àquele que me separou dos animais e me fez mais sábio que as aves do céu. Passarei além da memória, mas onde te hei de achar, ó Deus verdadeiramente bom, suavidade segura? Onde te hei de encontrar? Se te encontro sem minha memória, estou esquecido de ti, e se não me lembro de ti, como te poderei encontrar?

## CAPÍTULO XVIII

### A memória das coisas perdidas

 Uma mulher perdeu uma dracma, e a procurou com sua lanterna. Mas se não se lembrasse dela, não a haveria de encontrar; de fato, se dela não lembrasse, como poderia saber, ao acha-la, que era aquela?

 Lembro-me de ter procurado e achado muitas coisas perdidas, sei disso porque, estando eu à procura, me diziam: "Por acaso é esta?" "Por acaso é aquela?" – e eu sempre respondia que não, até encontrar o que procurava. Se não tivesse fixado a lembrança do objeto, fosse o que fosse, ainda que me fosse mostrado, não o encontraria, pois não o poderia reconhecer. E sempre que perdemos e achamos alguma coisa acontece o mesmo.

 Se alguma coisa desaparece de nossa vista, e não da memória – como sucede com um corpo visível – conservamos interiormente sua imagem e o procuramos até que apareça a nossos olhos. Quando for encontrado, será reconhecido de acordo com essa imagem interior. Não podemos dizer que encontramos um objeto perdido se não o reconhecemos; nem o podemos reconhecer se dele não lembramos. Tinha pois desaparecido da nossa vista, mas era conservado pela memória.

## CAPÍTULO XIX

### A memória das lembranças

 E quando a própria memória perde uma lembrança, como acontece quando nos esquecemos de algo e procuramos recordá-la, o que se passa? Onde, afinal, a procuramos senão na própria memória? E se esta, por acaso, nos oferece uma coisa por outra, a repelimos até que apareça o que buscamos. E assim que aparece dizemos: "É isto". E assim não diríamos se não a reconhecêssemos, e não a reconheceríamos se dela não houvesse registro. É certo, portanto, que já a havíamos esquecido. Ou será que ela não se apagara totalmente de nossa memória, por meio da parte que nos ficou impressa procuramos a outra? A memória, nesse caso, teria ciência de não poder, como de ordinário, fornecer a lembrança em seu conjunto e, mutilada, reclamaria e parte faltante. É o que sucede quando vemos uma pessoa conhecida, ou nela pensamos sem poder recordar seu nome. Se outro nome nos apresenta ao espírito, não o associamos à tal pessoa; por isso o afastamos, até que se apresenta um que concorde com nossa representação habitual da pessoa.

 Mas donde nos vem este nome, senão da memória? Mesmo quando nos é sugerido por outrem, é pela memória que reconhecemos; não o aceitamos como um conhecimento novo, mas recordando-o, confirmamos ser esse o nome que nos disseram. Se fosse totalmente apagado da alma, nem mesmo avisados o reconheceríamos.

 Não podemos pois, afirmar que nos esquecemos completamente daquilo de que nos lembramos ter esquecido. De nenhum modo poderíamos resgatar uma lembrança perdida se seu esquecimento fosse total.

## CAPÍTULO XX

### A memória da felicidade

 E como hei de te buscar, Senhor? Quando te procuro, meu Deus, estou à procura da felicidade. Procurar-te-ei para que minha alma viva, porque meu corpo vive de minha alma, e minha alma vive de ti. Como então devo buscar a felicidade? Porque não a possuirei até que possa dizer "basta". Como, pois, procurá-la? Talvez pela lembrança, como se a tivesse esquecido, guardando contudo a lembrança do esquecimento? Ou pelo desejo de conhecer algo desconhecido ou por nunca tê-lo vivido, ou por tê-lo esquecido a ponto de nem ter consciência do seu esquecimento?

 Mas não será justamente a felicidade que todos querem, sem exceção? E onde a conheceram para a desejarem tanto? Onde a viram para assim a amarem? O que é certo é que está em nós a sua imagem. Mas não sei como isto se dá. E há diversos modos de ser feliz: quer possuindo realmente a felicidade, quer possuindo apenas sua esperança. Este último modo é inferior ao dos que são realmente felizes, embora estejam melhor que os não felizes nem na realidade, nem na esperança. Mesmo estes, todavia, não desejariam tanto a felicidade se esta lhes fosse completamente estranha, e é certo que a desejam. Não sei como a conheceram, e portanto ignoro a noção que dela têm. O que me preocupa é saber se essa noção reside na memória, pois, se é lá que reside, é sinal de já fomos felizes alguma vez. Por ora não busco saber se todos fomos felizes individualmente, ou se o fomos naquele que pecou primeiro, e no qual todos morremos, e de quem nascemos na infelicidade. O que procuro saber é se a felicidade reside na memória, porque certamente não a amaríamos se não a conhecêssemos. Mal ouvimos esta palavra, e todos confessamos que desejamos a mesma coisa; e não é o som da palavra que nos deleita. Quando um grego a ouve pronunciar em latim, não se alegra, porque ignora seu sentido. Mas nós nos alegramos ao ouvi-la, como ele se a ouvisse em sua língua. A felicidade, com efeito, não é grega nem latina; mas gregos e latinos, assim como todos que falam outras línguas, desejam alcançá-la.

 Logo, a felicidade é conhecida de todos; e se fosse possível perguntar-lhes a uma voz:" Quereis ser felizes?" – todos, sem hesitar, responderiam que sim. E isso não aconteceria se a memória não tivesse em si a realidade, expressa por essa palavra.

## CAPÍTULO XXI

### A memória do que nunca tivemos

 Podemos comparar essa lembrança à que conserva de Cartago, quem a viu? Não, a felicidade não se vê com os olhos, pois não é corporal. Seria pois comparável à lembrança dos números? Também não, pois quem conhece os números não deseja adquiri-los. Pelo contrário, a idéia da felicidade nos inclina a amá-la e a querer possuí-la, para sermos felizes.

 Lembramos dela, talvez, como lembramos da eloqüência? Também não, embora ao ouvir essa palavra, muitos que não são eloqüentes a associam à realidade que ela exprime, e desejariam obtê-la, o que indica que já têm idéia de eloqüência. Foi porém pelos sentidos do corpo que ouviram a eloqüência alheia, deleitando-se com ela, e desejando também ser eloqüentes. E certamente não lhes daria prazer se já não tivessem uma idéia da eloqüência, e nem a desejariam se esta não os tivesse deleitado. Mas a felicidade não a percebemos nos outros por nenhum sentido corporal.

 Essa lembrança, será porventura comparável à da alegria? Talvez, pois quando estou triste me lembro da alegria passada, e quando infeliz, lembro-me da felicidade. Ora, esta alegria, eu jamais a vi, ou ouvi, ou senti, ou saboreei, ou toquei; apenas a experimentei em minha alma quando me alegrei. E esta idéia se fixou em minha memória para que eu pudesse recordá-la, às vezes com desgosto, outras com saudades, conforme as circunstâncias que a geraram.

 De fato me senti invadido de alegria causada por ações torpes, cuja lembrança agora aborreço e abomino; outras vezes alegrei-me por ações boas e honestas, das quais me lembro com saudade; mas já pertencem ao passado, e evoco com tristeza minha antiga alegria.

 Mas onde e quando, então, experimentei a felicidade para lembrar-me dela, para amá-la e deseja-la? Não sou eu apenas, ou alguns que a desejam; mas todos, sem exceção queremos ser felizes. Sem uma noção precisa da felicidade, nossa vontade não teria essa firmeza.

 Que significa isto? Se perguntarmos a dois homens se querem alistar-se no exército, talvez um responda que sim o outro que não. Mas, perguntemos se desejam ser felizes, e ambos responderão que sim, sem nenhuma hesitação. E desejando um engajar-se, e o outro não, têm ambos a mesma finalidade: ser felizes. Um gosta disto, outro daquilo, mas ambos concordam em ser felizes, como seria unânime a resposta afirmativa a quem lhes perguntasse se querem estar alegres. Essa alegria é o que eles chamam de felicidade. E ainda que um siga por um caminho e outro por outro, a finalidade de todos é um só: a alegria. Como a alegria é um sentimento do qual todos temos experiência, a encontramos em nossa memória, e a reconhecemos ao ouvir pronunciar a palavra felicidade.

## CAPÍTULO XXII

### A verdadeira felicidade

 Longe de mim, longe do coração de teu servo, Senhor, que a ti se confessa, a idéia de encontrar a felicidade não importa em que alegria! A felicidade é uma alegria que não é concedida aos ímpios, mas àqueles que te servem por puro amor: tu és essa alegria! Alegrar-se de ti, em ti e por ti: isso é felicidade. E não há outra. Os que imaginam outra felicidade, apegam-se a uma alegria que não é a verdadeira. Contudo, sempre há uma imagem da alegria da qual sua vontade não se afasta.

## CAPÍTULO XXIII

### Felicidade e verdade

 Poderemos então concluir que nem todos desejam ser felizes, pois há aqueles que não querem buscar em ti sua alegria, tu que és a única felicidade? Ou talvez todos a queiram, mas, como a carne combate contra o espírito, e o espírito contra a carne, e com isso se contentam. Porque não querem com força bastante aquilo que não podem, para obtê-lo.

 Pergunto a todos se preferem encontrar a alegria na verdade ou no erro; ninguém hesita em declarar que preferem a verdade, como em dizer que querem ser felizes. É que a felicidade é a alegria que provém da verdade. E essa alegria é a que nasce de ti, que és a própria Verdade, ó meu Deus, minha luz, saúde de meu rosto! Todos querem essa vida, a única feliz, essa alegria que se origina na verdade.

 Encontrei muitos que gostam de enganar, mas ninguém que quisesse ser enganado. Onde, então, conheceram a felicidade, senão onde conheceram a verdade? Visto que não querem ser enganados, também amam a verdade, e desde que amam a felicidade, que nada mais é que a alegria proveniente da verdade, certamente também amam a verdade; e não a amariam se não retivessem dela, na sua memória, alguma noção. Por que, então, não se alegram com ela? Por que não são felizes? Porque se empolgam demais com outras coisas, que os tornam mais infelizes do que a verdade, de que se recordam fracamente, e que os faria felizes.

 Há ainda um pouco de luz entre os homens: caminhem, caminhem, para que as trevas não os surpreendam.

 Mas por que a verdade gera o ódio? Por que os homens olham como inimigo aquele que a prega em teu nome, uma vez que amam a felicidade, que mais não é que a alegria nascida da verdade? Talvez por amarem a verdade de tal modo que tudo de diferente que amam, querem que seja verdade; e, não admitindo ser enganados, também não querem ser convencidos de seu erro. Desse modo, detestam a verdade por amarem aquilo que tomam pela verdade. Amam-na quando ela brilha, mas odeiam-na quando os repreende; e, como não querem ser enganados, mas enganar, eles a amam quando ela se manifesta, mas a odeiam quando ela os denuncia. Porém ela os castiga; não querem ser descobertos pela verdade, mas esta os denuncia, sem que por isso se manifeste a eles.

 É assim o coração do homem! Cego e lerdo, torpe e indecente: quer permanecer oculto, mas não quer que nada lhe seja ocultado. Em castigo, sucede-lhe o contrário: não consegue esconder-se da verdade, enquanto esta lhe continua oculta. Contudo, apesar de tão infeliz, prefere encontrar alegrias na verdade que no erro. Será, portanto, feliz quando, livre de perturbações, se alegrar somente na Verdade, origem de tudo o que é verdadeiro.

## CAPÍTULO XXIV

### Deus e a memória

 Eis como esquadrinhei minha memória em tua procura, Senhor: não me foi possível encontrar-te fora dela. Nada encontrei de ti que não fosse lembrança, e nunca me esqueci de ti desde que te conheci. Onde encontrei a verdade, aí encontrei a meu Deus, que é a própria verdade; e desde que aprendi a conhecer a verdade, nunca mais a esqueci. Por isso, desde que te conheço, permaneces em minha memória. É lá que te encontro quando me lembro de ti e quando sou feliz em ti. Estas são as santas delicias que me deste em tua misericórdia, olhando para minha pobreza.

## CAPÍTULO XXV

### Recapitulação

 Onde habitas em minha memória, Senhor, em que lugar dela estás? Que esconderijo construíste aí? Que santuário aí edificaste para ti? Deste-me a honra de morar em minha memória; mas em que parte dela resides? É o que quero agora descobrir.

 Quando me recordei de ti, ultrapassei aquela região da memória que também os animais possuem, pois não te encontrei entre as imagens dos objetos corpóreos. E cheguei àquela parte onde depositei os afetos de minha alma, mas também aí não te encontrei. Cheguei à morada que meu próprio espírito possui na memória – porque também o espírito lembra de si mesmo – mas nem ali estavas. Isso porque não és imagem corpórea, nem afeto de ser vivo, como a alegria, a tristeza, o desejo, o temor, a lembrança, o esquecimento e outros semelhantes, e nem és meu próprio espírito, porque és o Senhor e Deus do espírito, e tudo isso é mutável, enquanto permaneces imutável e subsistes acima de todas as coisas, e te dignaste habitar em minha memória desde que te conheço.

 Mas, por que perguntar em que lugar da memória habitas, como se a memória tivesse compartimentos? Certo é que habitas nela desde que te conheço, e é nela que te encontro, quando penso em ti.

## CAPÍTULO XXVI

### Onde encontrar Deus?

 Onde, então, te encontrei, para te conhecer? Não estavas ainda em minha memória antes de eu te conhecer. Onde, então, te encontrei, para te conhecer, senão em ti mesmo, acima de mim? No entanto, aí não existe espaço. Quer nos afastemos de ti, quer nos aproximemos, aí não existe espaço algum. Ó Verdade, por toda parte assistes aos que te consultam, e respondes ao mesmo tempo a todas essas diversas consultas. Tuas respostas são claras, mas nem para todos. Os homens te consultam sobre o que querem, mas nem sempre ouvem as respostas que querem. Teu servo fiel é o que não pensa em ouvir de ti a resposta que quer, mas em querer a resposta que lhe dás.

## CAPÍTULO XXVII

### Solilóquio de amor

 Tarde te amei, Beleza tão antiga e tão nova, tarde te amei! Eis que estavas dentro de mim, e eu lá fora, a te procurar! Eu, disforme, me atirava à beleza das formas que criaste. Estavas comigo, e eu não estava em ti. Retinham-me longe de ti aquilo que nem existiria se não existisse em ti. Tu me chamaste, gritaste por mim, e venceste minha surdez. Brilhaste, e teu esplendor afugentou minha cegueira. Exalaste teu perfume, respirei-o, e suspiro por ti. Eu te saboreei, e agora tenho fome e sede de ti. Tocaste-me, e o desejo de tua paz me inflama.

## CAPÍTULO XXVIII

### A vida do homem

 Quando me unir a ti com todo meu ser, não sentirei mais dor ou fadiga; minha vida, cheia de ti, será então a verdadeira vida. Alivias aqueles que enches de ti; mas, como ainda não estou cheio de ti, sou um peso para mim mesmo. Minhas alegrias, que deveriam ser choradas, lutam com minhas tristezas que deveriam alegrar-me, e ignoro de que lado está a vitória.

 Ai de mim, Senhor, tem piedade de mim! As tristezas do meu mal lutam com minhas santas alegrias, e eu não sei de que lado está a vitória. Ai de mim! Senhor, tem piedade de mim! Eis minhas feridas: eu não as escondo. Tu és o médico, eu o enfermo; és misericordioso, e eu, miserável. Não é contínua tentação a vida do homem sobre a terra? Quem quer aborrecimentos e dificuldades? Mandas que os suportemos, e não que os amemos. Ninguém ama o que tolera, ainda que goste de o tolerar; e mesmo que alguém se alegre em tolerar, preferiria nada ter que suportar. Na adversidade, desejo a prosperidade, e na prosperidade temo a adversidade. Entre estes dois extremos, qual será o termo médio onde a vida humana não seja tentação?

 Ai das prosperidades do século, onde se receia a adversidade e a alegria é corrompida! Ai das adversidades do século, uma, duas, três vezes ai! Pelo desejo da prosperidade, por ser dura a adversidade, e pelo temor que vença a nossa paciência! A vida do homem sobre a terra não é pois uma contínua tentação?

## CAPÍTULO XXIX

### Esperança em Deus

 Só na grandeza da Tua misericórdia coloco toda minha esperança. Dai-me o que me ordenas e ordena-me o que quiserdes. Mandas que sejamos castos. "Sabendo, diz um sábio, que ninguém pode ser casto se Deus não lhe der este dom, já é sabedoria saber de quem procede este dom". A continência reúne os elementos de nossa pessoa, reconduz-nos à unidade que perdemos dispersando-nos por tantas criaturas. Pouco te ama quem te ama juntamente com alguma criatura, e não a ama por tua causa.

 Ó amor, que sempre ardes e jamais te extingues! Ó caridade, meu Deus, inflama-me! Ordena-me a continência? Dá-me o que mandas, e ordena o que quiseres!

## CAPÍTULO XXX

### Sonho e voluptuosidade

 Ordenas que me abstenha da concupiscência da carne, da concupiscência dos olhos e da ambição do século. Proibiste as uniões luxuriosas, e embora tenhas permitido o casamento, ensinaste que há um estado bem melhor. E, pela tua graça, optei por esse estado, antes mesmo de me tornar dispensador de teu sacramento.

 Mas em minha memória, de que falei longamente, vivem ainda as imagens dessas voluptuosidades que meus costumes de outrora ali gravaram. Sem forças diante de mim quando estou acordado, durante o sono, elas não somente suscitam em mim o prazer, mas o consentimento do prazer e a ilusão da ação. Tais ilusões têm tal poder sobre minha alma e sobre meu corpo, apesar de tão falsas, que seus fantasmas impelem a meu sono o que a realidade não me pode induzir quando em vigília. Acaso então, Senhor meu Deus, será que eu não sou eu nessas horas? E como vai tão grande diferença dentro de mim mesmo, do momento em que passo da vigília para o sono e vice versa! Onde pois está a razão, que durante a vigília resiste a tais sugestões, e que não se abala mesmo diante da realidade? Acaso se fecha juntamente com os olhos? Ou adormece com os sentidos do corpo?

 E por que, muitas vezes, mesmo no sono, resistimos, lembrados de nosso propósito, e nele permanecemos castos, negando o consentimento a tais seduções? Todavia, a diferença é tanta que, no caso de não resistir durante o sono, ao acordar voltamos a encontrar a paz de consciência; e a própria diferença entre os dois estados indica que não fomos nós que fizemos aquilo, e lamentamos o que se fez em nós.

 Senhor onipotente, não poderia tua mão curar todas as enfermidades de minha alma, abolindo também, com maior abundância de graça, os movimentos lascivos de meu sono? cada vez mais multiplica, Senhor, o número de tuas bondades para comigo, para que minha alma, livre do visco da concupiscência, siga até chegar a ti. Para que não seja rebelde, nem mesmo durante o sono; para que, pelo estímulo de imagens bestiais, não só não cometa essas torpezas degradantes até a lascívia carnal, mas que nem mesmo consinta nisso.

 Não é muito para ti, ó Todo-Poderoso, que podes fazer mais do que pedimos e compreendemos, fazer com que, quer minha idade presente, quer na minha vida futura, eu me deleite nessas tentações – mesmo que sejam tão pequenas, que o primeiro esforço as venceria, quando adormeço com pensamentos castos.

 Agora digo exultando ao meu Senhor em que estado me encontro neste gênero de pecado, com tremor pelos dons que já me concedeste, e gemendo pelas minhas imperfeições. Espero que aperfeiçoes em mim tuas misericórdias, até que atinja a plenitude da paz de que gozarão em ti meu espírito e meu corpo, quando a morte for absorvida pela vitória.

## CAPÍTULO XXXI

### A intemperança

 O dia me traz novo pecado, e oxalá fosse o único! Comendo e bebendo, restauramos as diuturnas perdas de nosso corpo, até o dia em que destruirás o alimento e o estômago, matando minha necessidade com uma maravilhosa saciedade, e revestindo este corpo corruptível de eterna incorruptibilidade.

 Mas por ora esta necessidade me é grata, e luto contra essa delícia, para que não me domine; é uma guerra cotidiana que sustento com jejum, reduzindo meu corpo à escravidão. Mas minhas dores são eliminadas pelo prazer, porque a fome e a sede são sofrimentos: queimam e matam como a febre se os alimentos não lhe põem remédio. Mas como esse remédio está sempre à nossa disposição, graças à liberdade de teus dons que põe à disposição de nossa fraqueza a terra, a água e o céu, nossas misérias recebem por nós o nome de delícias.

 Tu me ensinaste a considerar os alimentos como remédios. Mas quando passo dessa penosa necessidade à paz da saciedade, nessa passagem a concupiscência arma para mim sua cilada. Esta passagem é prazerosa, e não há outra para se chegar onde a necessidade nos obriga. A razão do beber e do comer é a conservação da saúde; mas um prazer insidioso acompanha como lacaio essas funções, e sempre tenta tomar a dianteira, de modo que faço pelo prazer o que digo fazer por minha saúde.

 Ora, a medida do prazer não é a mesma da saúde; o que é bastante para a saúde não o é para o prazer, e muitas vezes é difícil discernir se é o cuidado com o corpo que pede reforço de alimento, ou se é a gula que nos engana e quer ser servida. Essa incerteza alegra nossa pobre alma, feliz por ter encontrado um álibi e uma desculpa na impossibilidade de determinar o que basta para o cuidado com a saúde, e sob o pretexto da sua conservação esconde a busca do prazer. Esforço-me para resistir a essas tentações diárias, e invoco tua mão para me socorrer. A ti confesso minha incerteza, porque sobre este ponto meu juízo ainda não é firme.

 Ouço a voz de meu Deus que ordena: "Não se façam pesados vossos corações com a intemperança e embriaguez". A embriaguez está longe de mim; que tua misericórdia não a deixe se aproximar. Mas a intemperança, ao contrário, chega às vezes a arrastar teu servo. Tua misericórdia há de afastá-la de mim, porque ninguém pode ser temperante senão por tua graça.

 Muitas coisas nos concedes quando te invocamos, e todo o bem que recebemos, mesmo antes de o pedir, é a ti que sempre o devemos. E o ato mesmo de reconhecermos que esses dons são teus, é ainda graça tua. Nunca estive embriagado, mas conheci muitos, dados a esse vicio, que se tornaram sóbrios por tua graça. Assim, é graças a ti que alguns não são o que nunca foram; e também é graças a ti que outros não são mais o que foram; e é graças a ti, enfim, que estes e aqueles sabem a quem devem essa graça.

 Ouvi ainda de ti outra palavra: "Não corras atrás de tuas concupiscências, e reprime teus apetites" – Tua graça ainda me fez ouvir outra palavra, de que tanto gostei: "Se comemos, não teremos abundância; e se não comemos, não sofreremos privação". – Ou seja: nem isto me fará rico, nem aquilo pobre. – E ouvi ainda esta outra: "Aprendi a me contentar com o que tenho: sei viver na abundância e suportar a penúria. Tudo posso naquele que me fortalece". – Eis como fala o bom soldado da milícia celeste: nada parecido ao pó que somos. Mas, Senhor, lembra-se que somos pó, e que de pó fizeste o homem; que este havia se perdido, e que foi reencontrado.

 Por si mesmo, formado do mesmo pó que nós, nada podia aquele cujas palavras inspiradas tanto amei: "Tudo posso naquele que me fortalece" – Concede-me forças, para que eu possa. Dá-me o que mandas, e manda o que quiseres. Paulo confessa que tudo recebeu de ti, e, quando se gloria, é no Senhor que ele se gloria.

 Ouvi também outro que te pedia esta graça: "Afasta de mim a intemperança". – De onde se conclui claramente, ó Deus santo, que dás a força de cumprir o que mandas.

 "Tu me ensinaste, Pai bondoso, que tudo é puro para os puros, mas que é mau para o homem comer com escândalo, que tudo o que fizeste é bom, e que nada deve ser rejeitado do que se recebe com ação de graças; que os alimentos não nos recomendam a Deus, que ninguém nos deve julgar pela comida ou pela bebida; que o que come não deve julgar o que não come". – Por essas lições, graças e louvores te dou, meu Deus, meu Mestre, que bateste à porta de meus ouvidos e iluminaste meu coração. Livra-me de toda tentação. Não receio a impureza dos alimentos, mas a impureza do prazer.

 Sei que Noé teve permissão de comer toda espécie de carne que pudesse servir de alimento, e que Elias comeu carne para reparar as forças; sei que João Batista, asceta admirável, não se manchou com os animais – os gafanhotos – de que se alimentava. Todavia eu sei que Esaú deixou-se enganar pelo desejo de um prato de lentilhas; que Davi se repreendeu a si mesmo por ter desejado água; que nosso Rei foi submetido à tentação, não de carne, mas de pão. Por isso o povo foi justamente repreendido no deserto, não por ter desejado comer carne, mas porque o desejo o fez murmurar contra o Senhor.

 Exposto a estas limitações, luto diuturnamente contra a concupiscência do comer e do beber, pois não é coisa que possa cortar de uma vez por todas, apenas com o propósito de nunca mais recair, como fiz com a luxúria. É uma rédea imposta a meu paladar, ora para afrouxá-la, ora para retesá-la. E quem é, Senhor, que não se deixa arrastar às vezes além dos limites do necessário? Se existe alguém assim, é de fato grande, e deve engrandecer teu nome. eu porém não sou desse número, porque sou pecador. Contudo, também, eu engrandeço teu nome, e Aquele que venceu o mundo intercede junto a ti por meus pecados. Conta-me entre os membros enfermos de seu corpo, porque teus olhos viram minhas imperfeições e porque todos serão inscritos em teu livro.

## CAPÍTULO XXXII

### Os prazeres do olfato

 Quanto à sedução dos perfumes, não me preocupo demais. Quando ausentes, não os procuro; quando presentes, não os recuso, mas estou sempre disposto a deles me abster. Pelo menos assim me parece, embora talvez me engane. Trevas deploráveis me envolvem, que me escondem minhas faculdades reais; por isso, quando meu espírito indaga à respeito de suas forças, bem sabe que não pode confiar em si mesmo, por seu íntimo permanecer muitas vezes insondável, até que a experiência lho manifeste. Ninguém pois se deve ter seguro nesta vida, que é tentação perpétua. Pois. Como podemos nos tornar melhores, não aconteça de nos tornar piores. Nossa única esperança, nossa única confiança, nossa firme promessa é tua misericórdia.

## CAPÍTULO XXXIII

### Os prazeres do ouvido

 Os prazeres do ouvido me prendem e me subjugam com mais força, mas tu me desligaste, me libertaste.

 Agradam-me ainda, eu o confesso, os cânticos que tuas palavras vivificam, quando executados por voz suave e artística; todavia eles não me prendem, e dele posso me desvencilhar quando quero. Para assentarem no meu íntimo, em companhia com os pensamentos que lhe dão vida, buscam em meu coração um lugar de dignidade, mas eu me esforço ou me ofereço para ceder-lhes só o lugar conveniente.

 Às vezes parece-me tributar-lhe mais atenção do que devia: sinto que tuas palavras santas, acompanhadas do canto, me inflamam de piedade mais devota e mais ardente do que se fossem cantadas de outro modo. Sinto que as emoções da alma encontram na voz e no canto, conforme suas peculiaridades, seu modo de expressão próprio, um misterioso estímulo de afinidade.

 Mas o prazer dos sentidos, que não deveria seduzir o espírito, muitas vezes me engana. Os sentidos não se limitam a seguir, humildemente, a razão; o mesmo tendo sido admitidos graças à ela, buscam precedê-la e conduzi-la. É nisso que peco sem o sentir, embora depois o perceba.

 Outras vezes, porém, querendo exageradamente evitar este engano, peco por excessiva severidade; chego ao ponto de querer afastar de meus ouvidos, e da própria Igreja, a melodia dos suaves cânticos que habitualmente acompanham os salmos de Davi. Nessas ocasiões parece-me que o mais seguro seria adotar o costume de Atanásio, bispo de Alexandria. Segundo me relataram, ele os mandava recitar com tão fraca inflexão de voz, que era mais uma declamação do que um canto.

 Contudo, quando lembro das lágrimas que derramei ao ouvir os cantos de tua Igreja, nos primórdios de minha conversão, e que ainda agora me comovem, não tanto com o canto, mas com as letras cantadas, voz clara e modulações apropriadas, reconheço novamente a grande utilidade desse costume.

 Assim, oscilo entre o perigo do prazer e a constatação dos efeitos salutares do canto. Por isso, sem emitir juízo definitivo, inclino-me a aprovar o costume de cantar na igreja, para que, pelo prazer do ouvido, a alma ainda muito fraca, se eleve aos sentimentos de piedade. E quando me comovem mais os cantos do que as palavras cantadas, confesso meu pecado e mereço penitencia, e então preferiria não ouvir cantar.

 Eis em que estado me encontro! Chorai comigo, e chorai por mim, vós que alimentais no coração a virtude, fonte de boas obras. Porque vós, a quem isso não afeta, sois insensíveis a tudo isso. E tu, Senhor meu Deus, escuta, olha e vê; tem piedade de mim, cura-me. Eis que me tornei um problema para mim mesmo, sob teu olhar, e aí está precisamente meu mal.

## CAPÍTULO XXXIV

### O prazer dos olhos

 Resta ainda falar do prazer destes olhos carnais. Oxalá que os ouvidos fraternos e piedosos de teu templo ouvissem a minha confissão! Encerrando assim as tentações da concupiscência que ainda me perseguem, apesar de meus gemidos e dos desejos de ser revestido de meu tabernáculo, que é o céu.

 Meus olhos apreciam as formas belas e variadas, as cores brilhantes e amenas. Oxalá elas não me acorrentassem a alma! Oxalá ela só fosse presa pelo Deus que criou coisas tão boas: ele é meu bem, e não elas. Todos os dias, estando acordado, elas me importunam sem o descanso das vozes que se calam, e às vezes de tudo o que existe, quando silencia. A própria rainha das cores, a luz que inunda tudo o que vemos, e onde quer que eu esteja durante o dia, acaricia-me de mil modos, mesmo quando estou ocupado em outra coisa e não lhe dou atenção. E ela se insinua tão fortemente que, se de repente me for tirada, a desejo, a procuro e, se sua ausência se prolonga, a alma se entristece.

 Ó luz que Tobias contemplava quando, cego, mostrava ao filho o caminho da vida, caminhando à sua frente com os passos da caridade, sem jamais se perder! Luz que via Isaac, quando seus olhos carnais, oprimidos e velados pela velhice, mereceram não abençoar os filhos reconhecendo-os, mas reconhecê-los ao abençoá-los! Luz que via Jacó, também cego pela idade provecta, irradiou os fulgores de seu coração iluminado sobre as gerações do povo futuro, representadas em seus filhos! E a seus netos, os filhos de José, impôs as mãos misticamente cruzadas, não na ordem em que queria dispô-los o pai, que via com os olhos corporais, mas de acordo com seu próprio discernimento interior! Eis a verdadeira luz; ela é uma, e todos os que a vêem e amam formam um único ser.

 Quanto à luz corporal, de que falava, com sua doçura sedutora e perigosa, é um dos prazeres da vida para os cegos amantes do mundo. Mas os que nela sabem encontrar motivos para te louvar, Deus, criador de todas as coisas, convertem-na em hino em teu louvor, sem se deixarem dominar por ela no sono. é assim que desejo ser. Resisto às seduções dos olhos, para que meus pés, que começam a trilhar teus caminhos, não fiquem enredados. Elevo a ti olhos invisíveis, para que libertes meus pés de seus laços. Tu não cessa de livrá-los, porque sempre estão a se prender. Tu não cessas de me livrar, e eu me deixo cair a cada passo nas insídias espalhadas por toda parte, porque não dormirás, nem cochilarás, tu que guardas a Israel.

 Quantos encantos os homens acrescentaram às seduções dos olhos, com a variedade de suas artes, com sua indústria de vestidos, de calçados, de vasos, de objetos de toda espécie, com pinturas e esculturas diversas que de longe ultrapassam os limites do necessário e moderado e da expressão piedosa. Exteriormente perseguem as produções de suas artes, e em seu interior abandonam Àquele que os criou, deturpando em si o que ele fez.

 Quanto a mim, meu Deus e minha glória, encontro nisto razão para cantar-te um hino, e oferecer um sacrifício de louvor àquele que sacrificou por mim. As belezas que da alma do artista passam para suas mãos, provêm desta beleza, que é superior às nossas almas e pela qual minha alma suspira dia e noite.

 Entretanto, os que geram e os amantes das belezas exteriores, tiram da beleza soberana apenas o critério para julgá-las, mas não uma regra para usá-las bem. Contudo, a norma ali está, mas eles não a vêem. Se a vissem, não se afastariam , e guardariam sua força para ti, e não a dissipariam em fatigantes delícias.

 Mesmo eu, que exponho e compreendo essas verdades, deixo-me enredar nessas belezas; mas tu me livras de seu laço, tu me libertas, porque tua misericórdia está diante de meus olhos. Miseravelmente eu caio, e tu me levantas misericordiosamente, às vezes sem que eu o perceba, quando minha queda foi suave, e outras infligindo-me uma pena, por ter ficado preso ao chão.

## CAPÍTULO XXXV

### A curiosidade

 Às anteriores acrescente-se outra tentação, que oferece maiores perigos. Além da concupiscência da carne, que consiste no deleite voluptuoso de todos os sentidos, e cuja servidão dana os que ela afasta de ti, insinua-se na alma um outro desejo, que se exerce pelos mesmos sentidos corporais, mas tende menos a uma satisfação carnal do que a tudo conhecer por meio da carne.

 É a vã curiosidade, que se disfarça sob o nome de conhecimento e de ciência. Como nasce do apetite de tudo conhecer, e como entre os sentidos os olhos são os mais aptos para o conhecimento, a Sagrada Escritura chamou-a de concupiscência dos olhos.

 De fato, ver é função própria dos olhos; mas muitas vezes nós usamos essa expressão mesmo quando se trata de outros sentidos, aplicados ao conhecimento. Nós não dizemos: "Ouve como isto brilha" – nem: "Sente como isso resplandece" – nem: "Apalpa como isto cintila". – Para exprimir tudo isso dizemos "ver ou olhar". E até não nos limitamos a dizer: "Olha que luz!", pois apenas os olhos nos podem dar esta sensação – mas, dizemos ainda: "Olha que som! Olha que cheiro! Olha que gosto! Olha como é duro!" Por isso toda experiência que é obra dos sentidos é chamada, como disse, concupiscência dos olhos. Essa função da visão, que pertence aos olhos, é usurpada metaforicamente pelos outros sentidos, quando buscam conhecer alguma coisa.

 Daqui podemos distinguir claramente o papel da volúpia e o da curiosidade na ação dos sentidos. O prazer procura o que é belo, melodioso, suave, saboroso, agradável ao todo; a curiosidade por sua vez deseja o contrário, não para se expor ao sofrimento, mas pela paixão de conhecer por meio da experiência. Que prazer pode ter na visão de um cadáver dilacerado, que causa horror? E todavia onde há um cadáver, para lá corre toda a gente para se entristecer e empalidecer. E temem depois revê-lo em sonhos, como se alguém os tivesse obrigado a contemplá-lo, ou como se a fama de alguma beleza os tivesse atraído. O mesmo acontece com os outros sentidos, o que seria enfadonho enumerar.

 É esse quê de mórbido de curiosidade que faz com que se exibam monstruosidades nos espetáculos. É ela que nos induz a perscrutar os segredos da natureza exterior, cujo conhecimento de nada serve, mas que os homens buscam conhecer apenas pelo prazer de conhecer. É ela também que inspira o homem a pesquisar, com fim semelhante, a ciência perversa, que é a arte da magia.

 E é ela, enfim, que, até na religião, nos induz a tentar a Deus, pedindo-lhe sinais e prodígios, não para a salvação da alma, mas apenas pela ânsia de vê-los.

 Nessa imensa floresta, cheia de insídias e perigos, cortei e lancei para fora de meu coração muitos males, graças à força que me concedeste para tanto, Deus de minha salvação. Contudo, no turbilhão diário de tantas e tão variadas tentações que atormentam minha vida, quando ousarei dizer que nenhuma delas atrai mais minha atenção e não cativa minha vã curiosidade? Certamente que o teatro já não me atrai, nem me importo mais em conhecer o curso dos astros; jamais, para obter uma resposta, consultei as sombras, pois detesto todos os ritos sacrílegos.

 Mas quantos artifícios inventa o inimigo para me tentar a que te peça algum milagre, a ti, Senhor, meu Deus, a quem devo servir humilde e simplesmente! Eu te suplico, por nosso Rei, por nossa pátria, a pura e casta Jerusalém, que o perigo de consentir nessas coisas, que até agora esteve longe de mim, se afaste cada vez mais! Mas quando te peço a salvação de uma alma, a finalidade de meu intento é bem diferente: ouve-me pois, e concede-me a graça de seguir de bom grado tua vontade.

 Mas incontáveis são as pequenas e desprezíveis bagatelas que tentam cada dia nossa curiosidade! E quem poderá contar nossas quedas? Quantas vezes ouvimos contar banalidades! Toleramo-las, de início, para não magoar os fracos, e depois, aos poucos, ouvimo-las com atenção sempre crescente!

 Não vou mais ao circo, para ver um cão correr atrás de uma lebre; mas, passando casualmente pelo campo e vendo algo assim, eis-me interessado pela caçada, talvez até distraindo-me de algum pensamento profundo. E, se não chega a me fazer mudar o caminho do meu cavalo, desvio o curso do meu coração. Se após tal demonstração de minha fraqueza tu não me alertares para que abandone esse espetáculo, elevando-me a ti por meio de alguma reflexão, ou desprezando tudo e passando adiante, ficaria ali, absorvido como um bobo.

 E que dizer quando, sentado em minha casa, observando uma lagartixa à caça de moscas, ou uma aranha que as enreda em sua teia? Acaso, por serem animais pequenos, a curiosidade que despertam em mim não é a mesma? É verdade que depois passo a te louvar; Criador admirável, ordenador do universo, mas não foi esse o pensamento que primeiro me moveu. Uma coisa é levantar-se depressa, e outra é não cair.

 Dessas quedas está repleta minha vida, e minha única esperança está em tua infinita misericórdia. Nosso coração é o receptáculo de tais misérias, e traz em si grande quantidade de vaidades, que muitas vezes até interrompem e perturbam nossas orações; e enquanto em tua presença levantamos a voz de nossa alma até teus ouvidos, tais pensamentos fúteis, vindos não sei de onde, vêm perturbar um ato tão importante.

## CAPÍTULO XXXVI

### O orgulho

 Terei também essa miséria como desprezível? Haverá algo que possa restituir-me a esperança, a não ser tua conhecida misericórdia, que começou a me transformar? Sabes o quanto já me transformaste; curaste-me primeiro da paixão da vingança, para perdoar-me também todos meus pecados, curar minhas fraquezas, resgatar minha vida da corrupção, conservar-me na piedade e misericórdia, e saciar dos teus bens meu desejo. Derrubaste meu orgulho pelo temor, dobrando minha cerviz a teu jugo. Agora eu trago o teu jugo, e o sinto suave, como prometeste e cumpriste. Na verdade, teu jugo já era suave, mas eu não o sabia quando receava tomá-lo sobre mim.

 Mas, Senhor, tu és o único que sabe mandar sem orgulho, porque és o único Senhor verdadeiro, que não tem senhor! Diga-me, terá cessado em mim, se isso pode acontecer nesta vida, esta terceira espécie de tentação, que consiste em querer ser temido e amado pelos homens, com o único fim de obter uma alegria que não é alegria? Que vida miserável, que arrogância indigna! Aí está o principal motivo porque não te amamos e tememos piamente. Por isso resistes aos soberbos, enquanto dás tua graça aos humildes. Trovejas contra as ambições do mundo, e faz abalar as montanhas até suas raízes.

 Ora, como é necessário, para se adequar à sociedade, fazer-se amar e temer pelos homens, o inimigo de nossa verdadeira felicidade nos alicia, e por toda parte semeia seus laços gritando: "Bravo! Muito bem!" – para que, ávidos, recolhamos as lisonjas e nos deixemos incautamente enredar. Seu intento é que deixemos de encontrar nossa alegria na verdade, para buscá-la na mentira dos homens; estimula em nós o prazer em nos fazer temer e amar, não pelo teu amor, mas em teu lugar. Com isso nos tornamos semelhantes a ele, não unidos na caridade, mas partilhando de suas penas. Ele quis fixar sua morada no aquilão (vento gelado do norte), para que nós, nas trevas e no frio, servíssemos o perverso e sinuoso imitador de teu poder.

 Nós, Senhor, somos teu pequeno rebanho: sê nosso dono. Estende tuas asas, para nosso refúgio. Sê nossa glória; que nos amem por tua causa, e que tua palavra seja observada por nós. Quem busca o louvor dos homens, quando tu o reprovas, não será por estes defendido quando o julgares, nem poderá subtrair á tua condenação. Mas quando não se louva um pecados pelos desejos de sua alma, nem se abençoa quem pratica iniqüidades, mas te louva um homem pelos dons que lhe concedeste, se ele se compraz mais no louvor do que no dom que lhe atrai os louvores, tu o reprovas, a despeito dos louvores que recebe dos homens. E quem o louva é melhor do que é louvado, porque um se agradou com o dom de Deus, e o outro alegrou-se com o dom do homem.

## CAPÍTULO XXXVII

### A tentação do orgulho

 Todos os dias somos acometidos por estas tentações, Senhor, somos tentados sem trégua. Os louvores dos homens são a fornalha onde todos os dias somos postos à prova. Também nisso mandas que sejamos continentes. Concede-nos o que mandas, e manda o que quiseres.

 A esse respeito, conheces os lamentos que meu coração te dirige, e os rios de lágrimas que brotam de meus olhos. É-me difícil distinguir o quanto estou purificado dessa peste; tenho muito medo de minhas faltas ocultas, que teus olhos conhecem, e os meus ignoram. Nos outros gêneros de tentação, tenho recursos para me examinar, mas quanto a este, quase nenhum. Posso avaliar o quanto dominei a minha alma a respeito dos prazeres da carne e das vãs curiosidades, quando me vejo privado de tais coisas por minha vontade ou por necessidade. Então me indago se é pena maior ou menor o ver-me privado desses dons.

 Quanto à riqueza, ambicionada apenas para satisfazer a uma, duas ou todas as três paixões, no caso em que a alma não perceba se as despreza quando as possui, depende só dela renunciar a elas para provar seu desapego. Todavia, para nos privar dos louvores e provar nosso poder sobre eles, será talvez necessário levar uma vida má, infame, horrível, a ponto de ninguém nos conhecer sem nos detestar? Pode-se dizer ou conceber maior insanidade?

 Se o louvor deve habitualmente acompanhar uma vida boa e de boas obras, não será por isso que deveremos abandonar a vida exemplar. Contudo, para distinguir se a privação de um bem me é indiferente ou penosa, é preciso que me prive desse bem.

 Então, Senhor, que devo confessar-te quanto a tais tentações? Que tenho em grande apreço o louvor? Mas agrada-me mais a verdade. Pois, se tivesse que escolher entre duas situações: ser louvado pela minha loucura ou por meus erros ou ser escarnecido por todos pela minha firme certeza da verdade, bem sei o que escolheria. Contudo, não gostaria que a aprovação alheia aumentasse para mim a alegria que sinto pelo pouco bem que faço. Mas tenho de te confessar que não só o louvor a aumenta, mas também que o vitupério a diminui.

 Quando me sinto perturbado por essa miséria, uma desculpa surge em mim. Só tu sabes, Senhor, se ela é válida, porque a mim me deixa perplexo. De fato, não nos ordenaste apenas a continência, que nos ensina a afastar certas coisas de nós, mas também a justiça, que direciona nosso amor. Não quiseste que amássemos somente a ti, mas também o nosso próximo. Ora, às vezes me parece que é o aproveitamento e as esperanças de que o próximo dá mostra que me encantam, quando me regozijo com um elogio inteligente; e que, pelo contrário, é sua maldade que me entristece quando o ouço censurar o que ignora ou o que é bom.

 Às vezes também me entristeço com os elogios que me fazem, quando louvam em mim qualidades que me desagradam, ou quando dão muita importância a qualidade medíocres e secundárias.

 Mas, repito-o, como saber se o desagrado não provém de minha repugnância pelo louvor que destoa do meu juízo a respeito de mim mesmo – não que seu interesse me preocupe – mas pelo maior agrado que sinto quando o bem que amo em mim é amado pelos outros? De algum modo, não me considero louvado quando o elogio contradiz a opinião que tenho de mim mesmo, quer o encômio seja para o que me desagrada, quer exagerando o valor do que pouco me agrada. Serei, pois, sobre isso tudo um enigma para mim mesmo?

 Mas é em ti, ó Verdade, que percebo que devo me alegrar com os louvores que me dirigem, não em meu interesse, mas no interesse do próximo. Não sei se é este o meu caso, pois neste assunto me conheces melhor do que eu mesmo. Suplico-te, meu Deus, que me dês a conhecer a mim mesmo, para que eu possa confessar a meus irmãos, dispostos a orar por mim, as chagas que achar em mim. Faze que me examine com mais diligencia. Se for de fato o bem do próximo que me alegra quando me louvam, porque sou menos sensível ao vitupério injustamente feito a outro, do que se fosse a mim? Porque o aguilhão da injúria me faz sofrer mais do que injúria igualmente injusta feita a uma outra pessoa diante de mim? Acaso também ignoro isto? Deveria então concluir que me iludo, e que meu coração e minha língua burlam diante de ti a verdade?

 Afasta de mim, Senhor, esta loucura, para que minhas palavras não sejam para mim óleo de pecador para ungir minha cabeça.

## CAPÍTULO XXXVIII

### A vanglória

 Sou pobre e necessitado, e só melhoro quando, com gemidos íntimos e com desagrado de mim mesmo, busco tua misericórdia, até que minha indigência seja reparada e sanada com a paz que o olho soberbo ignora! Todavia, as palavras de nossa boca, ou nossos atos conhecidos dos homens, encerram uma tentação muito perigosa, filha do amor dos louvores que, para nos iludir com certa excelência, recolhe e mendiga os aplausos alheios. A vanglória me tenta até quando a critico em mim, e é por isso mesmo que eu a desaprovo. Muitas vezes, por excesso de vaidade, há quem se glorie até mesmo do desprezo da vanglória; mas de fato não é mais do desprezo da vanglória que se orgulha, porque ninguém a despreza quando se gloria de a desprezar.

## CAPÍTULO XXXIX

### O amor-próprio

 Há ainda entre nós, profundamente assentada, outra tentação do mesmo gênero, que torna vãos aqueles que se comprazem de si mesmos, ainda que não agradem aos outros, ou até lhes desagradem, ou sequer procuram lhes agradar. E quanto mais enfatuados estejam consigo mesmos, mais desagradam a ti, não só ao se gloriarem dos males como se fossem bens, mas sobretudo quando se gloriam de teus bens como se fossem deles; ou quando, reconhecendo-os em si, eles os atribuem a seus merecimentos; ou ainda quando, atribuindo-os à tua graça, eles não os gozam amigavelmente com os demais, gestando ciúmes e inveja.

 Em todos estes perigos e provas, tu vês o temor de meu coração, e sinto que são mas as feridas que curas em mim do que as que inflijo a mim mesmo.

## CAPÍTULO XL

### À procura de Deus

 Quando deixaste de me acompanhar, ó Verdade, para me ensinar o que eu devia evitar ou procurar, sempre te consultei, a ti submetendo, dentro da minha limitação, meus medíocres pontos de vista? Percorri com os sentidos, como pude, o mundo exterior. Observei a vida de meu corpo e os meus próprios sentidos. Depois adentrei nas profundezas da memória em seus múltiplos domínios, tão maravilhosamente repletos de inúmeras riquezas; observei tudo isso, estupefato. Sem teu auxílio nada poderia distinguir, mas reconheci que nada disto eras tu. Nem era eu o descobridor de todas essas coisas; me esforcei para distingui-las e avaliá-las em seu devido valor, recebendo-a através dos sentidos e interrogando-as. Senti outras coisas unidas a mim, e as examinei, assim como aos sentidos que mas traziam; revolvi as vastas reservas da memória, analisando certas lembranças, guardando umas e trazendo outras à luz. Porque tu és a luz permanente que eu consultava sobre a existência, o valor e a qualidade de todas as coisas, e eu ouvia teus ensinamentos e tuas ordens. Costumo fazê-lo muitas vezes, pois essa é a minha alegria, e sempre que meus trabalhos me permitem algum descanso, refugio-me nesse prazer.

 Em nenhuma dessas coisas que percorro consultando-te, não encontro lugar seguro para minha alma senão em ti; só em ti se reúnem meus pensamentos esparsos, sem que nada meu se aparte de ti. Às vezes, me fazes conhecer uma extraordinária plenitude de vida interior, de inefável doçura que, se chegasse à contemplação, não seria certamente compatível com esta vida. Mas torno a cair nesta baixeza, cujo peso me acabrunha; volto a ser dominado pelos meus hábitos, que me tem cativo e, apesar de minhas lágrimas, não me libertam. Tão pesado é o fardo do hábito! Não quero estar onde posso e não posso estar onde quero: miséria em ambos os casos!

## CAPÍTULO XLI

### Deus e a mentira

 Examinei minhas fraquezas de pecador nas três formas de concupiscência, e invoquei tua destra para me salvar. Apesar de ter coração ferido, vi teu esplendor, e forçado a recuar, disse: "Quem pode chegar lá? Fui lançado para longe de teus olhos". – Tu és a verdade que preside a todas as coisas. E eu, minha avareza, não queria perder-te, mas queria possuir ao mesmo tempo a ti e à mentira, como os que não querem mentir a ponto de perderem a noção de verdade. Assim te perdi, porque não admites, nem nenhum coração, conviver com a mentira.

## CAPÍTULO XLII

### Os neoplatônicos e o caminho para Deus

 Poderia eu encontrar alguém que me reconciliasse contigo? Deveria eu recorrer aos anjos? E com que orações, com que ritos? Ouvi dizer que muitos dos que se esforçam para voltar a ti, e que não conseguiam por si mesmos, tentaram este caminho e caíram na curiosidade de visões estranhas, recebendo por isso o justo castigo das ilusões.

 Soberbos, procuravam-te com o coração inchado de sua ciência arrogante, e sem humildade. E atraíram para si, pela semelhança de sentimentos, os demônios do ar, que se fizeram cúmplices e aliados de sua soberba, e se tornaram iludidos de seus poderes mágicos. Procuravam um mediador para purifica-los, mas não o encontraram, senão ao demônio transfigurado em anjo de luz, que justamente por não possuir corpo de carne, seduziu-lhes fortemente a carne orgulhosa. Eram eles mortais e pecadores, e tu, Senhor, com quem eles procuravam com soberba reconciliar-se, és imortal e sem pecado.

 Era necessário que o mediador entre Deus e o homem tivesse alguma semelhança tanto com Deus como com os homens; pois se assemelhasse apenas aos homens, estaria muito longe de Deus; e se assemelhando só a Deus, estaria muito longe dos homens; em ambos os casos não poderia ser mediador.

 E aquele falso mediador que é o demônio, a quem teus ocultos juízos permitem que iluda a soberba, tem de comum com os homens apenas uma coisa, isto é, o pecado. Finge contudo, ter algum traço em comum com Deus, e como não está revestido de carne mortal, pretende ser imortal. Mas, como a morte é o salário do pecado, ele tem isso em comum com os homens: como eles, ele é condenado à morte.

## CAPÍTULO XLIII

### Cristo, o único mediador

 O verdadeiro mediador que tua insondável misericórdia enviou e revelou aos homens, para que aprendessem a humildade pelo seu exemplo, é esse mediador entre Deus e os homens, o homem Jesus Cristo. Apareceu como intermediário entre os pecadores mortais e o Justo imortal, mortal como os homens e justo como Deus. E, como a vida e a paz são a recompensa da justiça, pela justiça que o une a Deus ele suprimiu a morte entre os ímpios justificados, e quis compartilhá-la com eles. Foi revelado aos santos dos antigos tempos, para que eles se salvassem pela fé em sua paixão futura, como nós nos salvamos pela fé em sua paixão passada. De fato, só é mediador enquanto homem; enquanto Verbo não é intermediário, por ser igual a Deus: Deus em Deus e, ao mesmo tempo, Deus único.

 Como nos amaste, Pai bondoso! Não poupando teu Filho único, o entregaste por nós pecadores! Oh! Como nos amaste! Foi por amor a nós que teu Filho, que não considerava rapina o ser igual a ti, submeteu-se até a morte de cruz. Ele era o único livre entre os mortos, tendo o poder de dar sua vida e de novamente retomá-la. Por nós se fez diante de ti vencedor e vítima; por nós, diante de ti, se fez sacerdote e sacrifício, e sacerdote porque ele era o sacrifício; de escravos, fez de nós teus filhos; nascidos de ti, se fez nosso escravo. Com razão ponho nele a firme esperança que curarás todas as minhas enfermidades por intermédio dele, que está sentado à tua direita e intercede por nós junto de ti. De outro modo desesperaria, pois são muitos e grandes meus males; porém mais poderoso é o poder do teu remédio. Poderíamos pensar que teu Verbo estava muito longe para se unir ao homem, e desesperar de nós, se ele não se tivesse feito carne, habitando entre nós.

 Atemorizado por meus pecados e pelo peso de minhas misérias, meditei o projeto de fugir para o ermo; mas tu te opuseste e me fortaleceste dizendo: Cristo morreu por todos, para que os viventes já não vivam para si, mas por aquele que morreu por eles.

 Eis, Senhor, que lanço em ti os cuidados da minha vida, e contemplarei as maravilhas da tua lei. Conheces minha ignorância e minha fraqueza: ensina-me, cura-me. Teu Filho único, em que estão escondidos todos os tesouros da sabedoria e da ciência, me remiu com sangue. Não me caluniem os soberbos, porque eu conheço bem o preço de minha redenção. Como o corpo e bebo o sangue da vítima redentora, distribuo-a aos outros; pobre, desejo saciar-me dela em companhia daqueles que a comem e são saciados. E louvarão ao Senhor os que o buscam!