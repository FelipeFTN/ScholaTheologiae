## CAPÍTULO XXVIII

### A vida do homem

 Quando me unir a ti com todo meu ser, não sentirei mais dor ou fadiga; minha vida, cheia de ti, será então a verdadeira vida. Alivias aqueles que enches de ti; mas, como ainda não estou cheio de ti, sou um peso para mim mesmo. Minhas alegrias, que deveriam ser choradas, lutam com minhas tristezas que deveriam alegrar-me, e ignoro de que lado está a vitória.

 Ai de mim, Senhor, tem piedade de mim! As tristezas do meu mal lutam com minhas santas alegrias, e eu não sei de que lado está a vitória. Ai de mim! Senhor, tem piedade de mim! Eis minhas feridas: eu não as escondo. Tu és o médico, eu o enfermo; és misericordioso, e eu, miserável. Não é contínua tentação a vida do homem sobre a terra? Quem quer aborrecimentos e dificuldades? Mandas que os suportemos, e não que os amemos. Ninguém ama o que tolera, ainda que goste de o tolerar; e mesmo que alguém se alegre em tolerar, preferiria nada ter que suportar. Na adversidade, desejo a prosperidade, e na prosperidade temo a adversidade. Entre estes dois extremos, qual será o termo médio onde a vida humana não seja tentação?

 Ai das prosperidades do século, onde se receia a adversidade e a alegria é corrompida! Ai das adversidades do século, uma, duas, três vezes ai! Pelo desejo da prosperidade, por ser dura a adversidade, e pelo temor que vença a nossa paciência! A vida do homem sobre a terra não é pois uma contínua tentação?