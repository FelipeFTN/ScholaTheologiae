## CAPÍTULO XLII

### Os neoplatônicos e o caminho para Deus

 Poderia eu encontrar alguém que me reconciliasse contigo? Deveria eu recorrer aos anjos? E com que orações, com que ritos? Ouvi dizer que muitos dos que se esforçam para voltar a ti, e que não conseguiam por si mesmos, tentaram este caminho e caíram na curiosidade de visões estranhas, recebendo por isso o justo castigo das ilusões.

 Soberbos, procuravam-te com o coração inchado de sua ciência arrogante, e sem humildade. E atraíram para si, pela semelhança de sentimentos, os demônios do ar, que se fizeram cúmplices e aliados de sua soberba, e se tornaram iludidos de seus poderes mágicos. Procuravam um mediador para purifica-los, mas não o encontraram, senão ao demônio transfigurado em anjo de luz, que justamente por não possuir corpo de carne, seduziu-lhes fortemente a carne orgulhosa. Eram eles mortais e pecadores, e tu, Senhor, com quem eles procuravam com soberba reconciliar-se, és imortal e sem pecado.

 Era necessário que o mediador entre Deus e o homem tivesse alguma semelhança tanto com Deus como com os homens; pois se assemelhasse apenas aos homens, estaria muito longe de Deus; e se assemelhando só a Deus, estaria muito longe dos homens; em ambos os casos não poderia ser mediador.

 E aquele falso mediador que é o demônio, a quem teus ocultos juízos permitem que iluda a soberba, tem de comum com os homens apenas uma coisa, isto é, o pecado. Finge contudo, ter algum traço em comum com Deus, e como não está revestido de carne mortal, pretende ser imortal. Mas, como a morte é o salário do pecado, ele tem isso em comum com os homens: como eles, ele é condenado à morte.