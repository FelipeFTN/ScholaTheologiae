## CAPÍTULO XXIX

### Esperança em Deus

 Só na grandeza da Tua misericórdia coloco toda minha esperança. Dai-me o que me ordenas e ordena-me o que quiserdes. Mandas que sejamos castos. "Sabendo, diz um sábio, que ninguém pode ser casto se Deus não lhe der este dom, já é sabedoria saber de quem procede este dom". A continência reúne os elementos de nossa pessoa, reconduz-nos à unidade que perdemos dispersando-nos por tantas criaturas. Pouco te ama quem te ama juntamente com alguma criatura, e não a ama por tua causa.

 Ó amor, que sempre ardes e jamais te extingues! Ó caridade, meu Deus, inflama-me! Ordena-me a continência? Dá-me o que mandas, e ordena o que quiseres!