## CAPÍTULO XXXVII

### A tentação do orgulho

 Todos os dias somos acometidos por estas tentações, Senhor, somos tentados sem trégua. Os louvores dos homens são a fornalha onde todos os dias somos postos à prova. Também nisso mandas que sejamos continentes. Concede-nos o que mandas, e manda o que quiseres.

 A esse respeito, conheces os lamentos que meu coração te dirige, e os rios de lágrimas que brotam de meus olhos. É-me difícil distinguir o quanto estou purificado dessa peste; tenho muito medo de minhas faltas ocultas, que teus olhos conhecem, e os meus ignoram. Nos outros gêneros de tentação, tenho recursos para me examinar, mas quanto a este, quase nenhum. Posso avaliar o quanto dominei a minha alma a respeito dos prazeres da carne e das vãs curiosidades, quando me vejo privado de tais coisas por minha vontade ou por necessidade. Então me indago se é pena maior ou menor o ver-me privado desses dons.

 Quanto à riqueza, ambicionada apenas para satisfazer a uma, duas ou todas as três paixões, no caso em que a alma não perceba se as despreza quando as possui, depende só dela renunciar a elas para provar seu desapego. Todavia, para nos privar dos louvores e provar nosso poder sobre eles, será talvez necessário levar uma vida má, infame, horrível, a ponto de ninguém nos conhecer sem nos detestar? Pode-se dizer ou conceber maior insanidade?

 Se o louvor deve habitualmente acompanhar uma vida boa e de boas obras, não será por isso que deveremos abandonar a vida exemplar. Contudo, para distinguir se a privação de um bem me é indiferente ou penosa, é preciso que me prive desse bem.

 Então, Senhor, que devo confessar-te quanto a tais tentações? Que tenho em grande apreço o louvor? Mas agrada-me mais a verdade. Pois, se tivesse que escolher entre duas situações: ser louvado pela minha loucura ou por meus erros ou ser escarnecido por todos pela minha firme certeza da verdade, bem sei o que escolheria. Contudo, não gostaria que a aprovação alheia aumentasse para mim a alegria que sinto pelo pouco bem que faço. Mas tenho de te confessar que não só o louvor a aumenta, mas também que o vitupério a diminui.

 Quando me sinto perturbado por essa miséria, uma desculpa surge em mim. Só tu sabes, Senhor, se ela é válida, porque a mim me deixa perplexo. De fato, não nos ordenaste apenas a continência, que nos ensina a afastar certas coisas de nós, mas também a justiça, que direciona nosso amor. Não quiseste que amássemos somente a ti, mas também o nosso próximo. Ora, às vezes me parece que é o aproveitamento e as esperanças de que o próximo dá mostra que me encantam, quando me regozijo com um elogio inteligente; e que, pelo contrário, é sua maldade que me entristece quando o ouço censurar o que ignora ou o que é bom.

 Às vezes também me entristeço com os elogios que me fazem, quando louvam em mim qualidades que me desagradam, ou quando dão muita importância a qualidade medíocres e secundárias.

 Mas, repito-o, como saber se o desagrado não provém de minha repugnância pelo louvor que destoa do meu juízo a respeito de mim mesmo – não que seu interesse me preocupe – mas pelo maior agrado que sinto quando o bem que amo em mim é amado pelos outros? De algum modo, não me considero louvado quando o elogio contradiz a opinião que tenho de mim mesmo, quer o encômio seja para o que me desagrada, quer exagerando o valor do que pouco me agrada. Serei, pois, sobre isso tudo um enigma para mim mesmo?

 Mas é em ti, ó Verdade, que percebo que devo me alegrar com os louvores que me dirigem, não em meu interesse, mas no interesse do próximo. Não sei se é este o meu caso, pois neste assunto me conheces melhor do que eu mesmo. Suplico-te, meu Deus, que me dês a conhecer a mim mesmo, para que eu possa confessar a meus irmãos, dispostos a orar por mim, as chagas que achar em mim. Faze que me examine com mais diligencia. Se for de fato o bem do próximo que me alegra quando me louvam, porque sou menos sensível ao vitupério injustamente feito a outro, do que se fosse a mim? Porque o aguilhão da injúria me faz sofrer mais do que injúria igualmente injusta feita a uma outra pessoa diante de mim? Acaso também ignoro isto? Deveria então concluir que me iludo, e que meu coração e minha língua burlam diante de ti a verdade?

 Afasta de mim, Senhor, esta loucura, para que minhas palavras não sejam para mim óleo de pecador para ungir minha cabeça.