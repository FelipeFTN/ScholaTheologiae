## CAPÍTULO XXVII

### Solilóquio de amor

 Tarde te amei, Beleza tão antiga e tão nova, tarde te amei! Eis que estavas dentro de mim, e eu lá fora, a te procurar! Eu, disforme, me atirava à beleza das formas que criaste. Estavas comigo, e eu não estava em ti. Retinham-me longe de ti aquilo que nem existiria se não existisse em ti. Tu me chamaste, gritaste por mim, e venceste minha surdez. Brilhaste, e teu esplendor afugentou minha cegueira. Exalaste teu perfume, respirei-o, e suspiro por ti. Eu te saboreei, e agora tenho fome e sede de ti. Tocaste-me, e o desejo de tua paz me inflama.