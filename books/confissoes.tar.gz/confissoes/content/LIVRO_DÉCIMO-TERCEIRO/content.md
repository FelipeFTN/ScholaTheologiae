### O repouso da alma

 Então também repousarás em nós, como hoje opera em nós; e o repouso de que gozaremos será teu, como as obras que fazemos são tuas. Mas tu, Senhor, sempre estás ativo e sempre estás em repouso. Tu não vês o tempo, não ages no tempo nem repousas no tempo; todavia, concede-nos que vejamos no tempo,fazes o próprio tempo e o repouso além do tempo.

## CAPÍTULO XXXVIII