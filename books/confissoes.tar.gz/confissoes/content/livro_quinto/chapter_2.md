## CAPÍTULO II

### Os que fogem de Deus

 Afastem-se e fujam de ti os irrequietos e os pecadores. Tu os vês e distingues suas sombras. E eis que, apesar deles, todas as continuam belas; somente eles são feios. E que damos te poderiam causar? Ou em que poderia desonrar teu império, justo e íntegro desde os céus até as coisas mais ínfimas? E para onde fugiram, ao fugir de tua presença? E em que lugar não os encontrarás? Fugiram, sim, para não ver-te a ti, que os estás vendo, mas deparam contigo, que não abandonas nada do que criaste; tropeçaram contigo, injustos, e justamente são castigados; subtraindo-se á tua brandura, ofenderam tua santidade, e caíram sob teus rigores. Evidentemente eles ignoram que estás em toda parte, que nenhum lugar te limita, e que só tu estás presente mesmo nos que se afastam de ti.

 Que se convertam, pois, e te busquem, porque não abandonas tua criatura, como elas abandonaram a seu Criador. Que se convertam, e logo estarás em seus corações, nos corações dos que te confessam, dos que se lançam em ti, dos que choram em teu regaço depois de percorrerem penosos caminhos. E tu, bondoso, enxugarás suas lágrimas; e chorarão ainda mais, mas serão felizes por chorar, porque és tu, Senhor, e nenhum homem de carne e sangue, tu, Senhor, que os criaste, que os consolas e robusteces.

 E onde estava eu quando te buscava? Certamente, estavas diante de mim, mas eu me havia afastado de mim mesmo, e não me encontrava, e muito menos de ti!