## CAPÍTULO XI

### Desculpas dos maniqueus

 Além de tudo, eu já não estava convencido que se pudessem defender os pontos que os maniqueus criticavam em tuas Escrituras. Todavia, desejava por vezes discutir com sinceridade cada um desses pontos com algum varão, grande conhecedor de seus livros, para lhe indagar a opinião. Quando ainda em Cartago, já me despertara o interesse o discurso de um tal Elpídio, que falava e discutia publicamente contra os maniqueus, alegando citações da Sagrada Escritura que não me era fácil refutar.

 Por sua vez, as respostas dos maniqueus me pareciam fracas; e mesmo assim não as expunham em público, mas somente entre nós, e muito em segredo, alegando que as Escrituras do Novo Testamento haviam sido falsificadas por não sei quem, com o intuito de mesclar a lei dos judeus com a fé cristã; por isso eles próprios não podiam mostrar nenhum exemplar sem ser apócrifo.

 Mas o que principalmente me mantinha cativo, e como que sufocado, eram as tais "substâncias", que pareciam oprimir-me, e debaixo de cujo peso, arquejante, me era impossível respirar a atmosfera pura e simples de tua verdade.