## CAPÍTULO IV

### Ciência e ignorância

 Senhor, Deus da verdade, acaso te agradará quem conhecer essas coisas? Infeliz do homem que, conhecendo-a todas, te ignora ti; mas feliz de quem te conhece, embora as ignore! Quanto ao que conhece a ti e a elas, este não é mais bem-aventurado por causa de seu saber, mas só é feliz por ti, se, conhecendo-te, te glorifica como Deus, e te dá graças, e não se desvanece em seus pensamentos.

 É melhor aquele que reconhece estar na posse de uma árvore e te dá graças por sua utilidade, embora ignore quantos côvados tem de altura e de largura, que o que a mede, e conta todos os seus ramos, mas não a possui, nem conhece, nem ama a seu Criador. Assim o homem fiel, a quem pertencem todas as riquezas do mundo, e que, nada possuindo, possui tudo, por estar unido a ti, a quem servem todas as coisas – embora desconheça até o curso das estrelas da Ursa – e seria insensatez duvidar – é certamente melhor do que o que mede os céus, conta as estrelas e pesa os elementos, mas despreza a ti, que dispuseste todas as coisas em número, peso e medida.