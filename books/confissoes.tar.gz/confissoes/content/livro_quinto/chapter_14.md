## CAPÍTULO XIV

### Catecúmeno

 Não cuidava eu de aprender o que dizia, interessado apenas em como o dizia – era este gosto frívolo o único que ainda permanecia em mim, perdidas já as esperanças de que se abrisse para o homem o caminho para ti. Todavia, infiltravam-se em meu espírito, juntamente com as palavras que me agradavam, as coisas que desprezava. Já não me era possível discernir umas das outras, e assim, ao abrir meu coração à sua eloqüência, nele entrava ao mesmo tempo e aos poucos, a verdade.

 Parece-me, de bom início, que seus ensinamentos podiam ser defendidos e que as afirmações de fé católica – que eu julgava impotente contra os ataques dos maniqueus – não eram absolutamente temerárias, principalmente depois de me serem explicados uma, duas ou mais vezes, as passagens obscuras do Velho Testamento que, interpretadas no sentido literal, me davam a morte. Assim, interpretados no sentido espiritual muitos dos textos daqueles livros, comecei a repreender aquele meu desespero, que me levava a crer na impossibilidade de resistir aos que aborreciam e zombavam da lei e dos profetas.

 Contudo, não me julgava na obrigação de segui o caminho dos católicos, só porque também esta fé podia ter defensores doutos, capazes de refutar objeções com eloqüência e lógica. Nem por isso me parecia que devia condenar a fé que antes abraçara, pois as armas de defesa eram iguais. Assim, de um lado a fé católica não me parecia vencida, contudo ainda não me parecia vencedora.

 Apliquei então todas as forças de meu espírito para ver se podia de algum modo, com argumentos decisivos, convencer de falsidade os maniqueus. A verdade é que se eu então tivesse podido conceber uma substância espiritual, imediatamente todas as invenções daqueles se esvaeceriam e seriam arrancadas de minha alma. Mas não podia.

 Contudo, refletindo e comparando sempre mais o que os filósofos haviam teorizado acerca do mundo material e de toda a natureza sensível, cada vez mais me capacitava de que eram muito mais prováveis as doutrinas destes que as dos maniqueus. Por isso, duvidando de tudo e flutuando por entre as doutrinas, à maneira dos acadêmicos, como os julga a opinião geral, resolvi abandonar os maniqueus, julgando que enquanto tivesse em dúvida não devia permanecer em uma seita à qual eu já antepunha alguns filósofos. Recusava-me, contudo, terminantemente, a confiar-lhes a cura das enfermidades de minha alma, por ser-lhes desconhecido o nome salutar de Cristo.

 Por isso tudo, resolvi tornar-me catecúmeno na Igreja Católica, que me havia sido recomendada por meus pais, até que alguma claridade certa viesse dirigir meus passos.