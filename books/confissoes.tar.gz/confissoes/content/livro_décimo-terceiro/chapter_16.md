## CAPÍTULO XVI

### Deus, fonte de luz

 Assim como só tu existes plenamente, só tu possuis o conhecimento absoluto: imutável, com efeito, és em teu ser, imutável em teu saber, imutável na tua vontade. Tua essência sabe e quer imutavelmente, tua ciência é e quer imutavelmente, tua vontade é e sabe imutavelmente. Não é justo a teus olhos que a luz imutável seja conhecida pelo ser mutável, que ela ilumina, como ela se conhece a si própria. Por isso, minha alma é para ti como terra sem água, porque assim como não pode iluminar a si mesma, não se pode saciar por seus próprios meios. Porque em ti está a fonte da vida, e graças à tua luz é que veremos a luz.