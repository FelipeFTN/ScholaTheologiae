## CAPÍTULO VI

### O espírito sobre as águas

 Mas, ó luz da verdade, aproximo de ti meu coração para que ele não me ensine falsidades; dissipa-lhe as trevas e dize-me, eu to suplico por nossa mãe, a caridade, dize-me, por que só depois de ter nomeado o céu, a terra invisível e informe e as trevas sobre o abismo, por que só então é que as Escrituras falam de teu Espírito? Será porque convinha apresentá-lo assim pairando sobre alguma coisa? E seria isso possível se não mencionasse primeiro sobre o que pairava? De fato, não era sobre o Pai nem sobre o Filho que ele pairava, e seria impróprio falar assim se não pairasse sobre alguma coisa.

 Era pois, necessário, mencionar primeiro o elemento sobre o qual ele pairava, já que convinha falar dele apenas dizendo que pairava. Mas por que não convinha apresentá-lo senão dizendo que pairava?