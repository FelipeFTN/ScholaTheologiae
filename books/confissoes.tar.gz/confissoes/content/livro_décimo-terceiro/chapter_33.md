## CAPÍTULO XXXIII

### A matéria e a forma

 Que tuas obras te louvem para que te amemos! Que nós te amemos, para que tuas obras te louvem! Elas têm seu princípio e fim no tempo, seu nascimento e morte, seu progresso e decadência, sua beleza e sua imperfeição. Elas têm, portanto, sucessivamente sua manhã e sua noite, umas oculta; outras, manifestamente.

 Foram feitas por ti do nada, não de tua substância, nem de nenhuma substância estranha ou inferior a ti, mas de matéria concriada, isto é, criada por ti ao mesmo tempo em que lhe deste forma, sem nenhum intervalo de tempo. Sem dúvida a matéria do céu e da terra é uma coisa, e sua forma é outra; a matéria tua a fizeste do nada, a forma, tu a tiraste da matéria informe. Contudo, criaste uma e outra a um só tempo, de maneira que entre a matéria e a forma não houvesse nenhum intervalo de tempo.