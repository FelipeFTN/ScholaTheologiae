## CAPÍTULO XXXVI

### O repouso de Deus

 O sétimo dia, porém, não tem crepúsculo; não entardece porque o santificaste para que se prolongue eternamente. E o repouso de teu sétimo dia, depois de ter criado tantas e tão boas obras, embora sem te causar fadiga, a palavra de tua Escritura nos anuncia que também nós, depois de nossos trabalhos, que são bons porque assim nos o concedeste, encontraremos o repouso em ti, no sábado da vida eterna.