## CAPÍTULO XXXVIII

### O descanso de Deus

 Vemos, portanto, as tuas criaturas porque elas existem. Mas elas existem porque tu as vês. Olhando à nossa volta, vemos que elas existem; em nosso íntimo, vemos que são boas. Mas tu já as viste feitas quando e onde viste que deviam ser feitas. Agora somos inclinados a praticar o bem, depois que nosso coração concebeu essa idéia em teu Espírito. Outrora estávamos inclinados ao mal, desertando de ti. Tu, porém, ó Deus, único bem, nunca cessaste de nos fazer o bem. Por tua graça, algumas de nossas obras são boas, mas não são eternas. Esperamos, depois de realizá-las, repousar em tua grande santificação. Mas tu, que não precisas de nenhum outro bem, estás sempre em repouso, porque és teu próprio repouso.

 Que homem poderá dar ao homem a compreensão desta verdade? Que anjo a outro anjo? Que anjo ao homem? É a ti que devemos pedir, e em ti é que a devemos buscar, é à tua porta que devemos bater. E somente assim receberemos, somente assim encontraremos, somente assim se nos abrirá tua porta.

*GRATIAS TIBI DOMINE*