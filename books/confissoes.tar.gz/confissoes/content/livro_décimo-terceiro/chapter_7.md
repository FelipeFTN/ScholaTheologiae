## CAPÍTULO VII

### As águas sem substância

 Agora, quem o puder com a inteligência, siga a teu Apostolo, quando ele diz que tua caridade se difundiu em nossos corações pelo Espírito Santo que nos foi dado, quando nos instrui sobre as coisas espirituais e nos indica o caminho excelso da caridade, e dobra o joelho diante de ti por nossa causa, para que conheçamos a ciência altíssima da caridade de Cristo. E é porque era super eminente desde o princípio que pairava sobre as águas.

 A quem e como falarei do peso da concupiscência, que nos arrasta para um abismo profundo, e da caridade que nos eleva, com a ajuda de teu Espírito, que pairava sobre as águas? A quem falar, como falar? Nós submergimos e emergimos, mas não em abismos materiais. A metáfora é a um tempo correta e muito inexata. São nossas paixões, nossos amores, a impureza de nosso espírito que nos arrasta para baixo sob o peso das preocupações. E é tua santidade que nos eleva pelo amor de tua paz, para que levantemos nossos corações para junto de ti, onde teu Espírito paira sobre as águas, e alcancemos o sublime repouso, quando nossa alma tiver atravessado essas águas que são sem substância.