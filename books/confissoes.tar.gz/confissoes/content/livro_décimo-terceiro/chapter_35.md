## CAPÍTULO XXXV

### Prece

 Senhor Deus, tu que nos deste tudo, concede-nos a paz do repouso, a paz do sábado, a paz do ocaso. De fato, esta formosíssima ordem de coisas muito boas, passará quando atingir o termo de seu destino, e terá sua tarde como teve seu amanhecer.