## CAPÍTULO XXIX

### A palavra de Deus e o tempo

 Procurei ver com atenção se forma sete ou oito as vezes que constataste a bondade de tuas obras quando elas te agradaram. Mas não encontrei uma seqüência temporal não tua visão, de onde pudesse deduzir que foi esse o número de vezes que viste tuas criaturas. Então disse: "Senhor, não será verdadeira tua Escritura, inspirada por ti, que és a própria verdade? Por que então me dizes que tua visão das coisas não está sujeita ao tempo, enquanto tua Escritura me diz que dia por dia viste a bondade de tuas obras? E calculei quantas vezes o fizeste."

 A isto me respondes, porque és meu Deus, falando com voz forte no ouvido interior de teu servo, rompendo minha surdez, me exclamas: "Ó homem, o que minha Escritura diz, isto digo eu. Mas ela fala no tempo, enquanto este não atinge o meu verbo, que permanece em mim, eterno como eu. Assim, o que vês por meu Espírito, sou eu quem o vê; o que dizes por meu Espírito, sou eu quem o diz. Mas o que vês no tempo, eu não vejo no tempo; e o que dizes no tempo, eu não digo no tempo."