## CAPÍTULO XII

### A criação e a Igreja

 Ó minha fé, vai adiante em tua confissão. Dize a teu Senhor: "Santo, santo, santo! É o Senhor, meu Deus! – Em teu nome fomos batizados, Pai. Filho e Espírito Santo; em teu nome batizamos, Pai, Filho e Espírito Santo. Também entre nós Deus criou, pelo seu Cristo, um céu e uma terra, isto é, os espirituais e os carnais de sua Igreja. E nossa terra, antes de receber a forma da doutrina, era invisível e informe, e estávamos imersos nas trevas da ignorância, porque castigaste o homem por causa de sua iniqüidade, e teus justos juízos são como abismos profundos.

 Mas porque teu Espírito pairava sobre as águas, tua misericórdia não abandonou nossa miséria, e disseste: "Faça-se a luz". Fazei penitencia, porque está próximo o reino de Deus. Fazei penitencia, faça-se a luz! E porque tínhamos a alma conturbada, nos lembramos de ti, Senhor, às margens do Jordão, sobre essa montanha grande como tu, que te tornaste pequeno por nós. Nossas trevas te desagradaram, nós nos voltamos para ti, e a luz se fez. E eis que outrora fomos trevas e que agora somos luz no Senhor.