## CAPÍTULO I

### Invocação

 Eu te invoco, ó meu Deus, minha misericórdia, que me criaste, e que não olvidaste aquele que te esqueceu. Chamo-te à minha alma, que preparas para te receber fazendo-te desejar por ela.

 Não abandones ao que te invoca. Antes mesmo que eu te invocasse, já o tinhas prevenido. Muitas vezes me instaste, falando de mil modos diversos para que te ouvisse de longe, para que me convertesse e invocasse por ti que me chamavas.

 Senhor, apagaste todos os meus delitos para não ter de punir o que fizeram minhas iníquas mãos, e te antecipaste a meus atos meritórios para me recompensar do que fizeram tuas mãos, que me criaram; de fato, existias antes de mim, e eu não era digno de receber de ti o ser.

 Contudo, eis que existo, graças à tua bondade que precedeu tudo o que sou e do que me fizeste. Não tinhas necessidade de mim, eu não sou um bem que te possa ser útil, meu Senhor e meu Deus. Se estou a teu serviço, não é porque a ação te cansa ou porque teu poder, privado de meus serviços, diminua; nem porque meu culto seja para ti o que é a cultura para a terra, que sem ela ficaria estéril. Eu devo te honrar para ser feliz em ti, a quem devo meu ser, capaz de felicidade.