# LIVRO DÉCIMO-TERCEIRO

## CAPÍTULO I

### Invocação

 Eu te invoco, ó meu Deus, minha misericórdia, que me criaste, e que não olvidaste aquele que te esqueceu. Chamo-te à minha alma, que preparas para te receber fazendo-te desejar por ela.

 Não abandones ao que te invoca. Antes mesmo que eu te invocasse, já o tinhas prevenido. Muitas vezes me instaste, falando de mil modos diversos para que te ouvisse de longe, para que me convertesse e invocasse por ti que me chamavas.

 Senhor, apagaste todos os meus delitos para não ter de punir o que fizeram minhas iníquas mãos, e te antecipaste a meus atos meritórios para me recompensar do que fizeram tuas mãos, que me criaram; de fato, existias antes de mim, e eu não era digno de receber de ti o ser.

 Contudo, eis que existo, graças à tua bondade que precedeu tudo o que sou e do que me fizeste. Não tinhas necessidade de mim, eu não sou um bem que te possa ser útil, meu Senhor e meu Deus. Se estou a teu serviço, não é porque a ação te cansa ou porque teu poder, privado de meus serviços, diminua; nem porque meu culto seja para ti o que é a cultura para a terra, que sem ela ficaria estéril. Eu devo te honrar para ser feliz em ti, a quem devo meu ser, capaz de felicidade.

## CAPÍTULO II

### A criação e a bondade de Deus

 É pela plenitude de tua bondade que as criaturas subsistem, para que um bem, para ti de todo inútil, ou de nenhum modo igualável a ti, embora saído de ti, continuasse a existir, pois tu o criaste. Com efeito, que poderiam merecer de ti o céu e a terra, que criaste no princípio? E digam, as naturezas espirituais e corpórea, que méritos tinham a teus olhos, que as criaste em tua Sabedoria? Que méritos, para receber de ti o ser, que mostram inacabado e informe, quando tendem à desordem e se afastam de tua semelhança? O que é de natureza espiritual, mesmo informe, é ainda superior a um corpo que recebeu forma; um corpo sem forma é superior ao puro nada; ora, todas essas coisas continuariam informes em teu Verbo, se essa mesma palavra não as recolhesse à tua Unidade, comunicando-lhes a forma e a excelência graças apenas a ti, soberano Bem. Mas que merecimentos antecipados apresentaram a teus olhos, para existir mesmo informes essas criaturas que, sem que as criasses nem teriam existido?

 E o que a matéria corporal merecera de ti para existir, mesmo invisível e caótica? Nem mesmo essa existência teria, se não as tivesses criado. Não existindo ainda, não podia ter merecimento algum para existir. E a criatura espiritual, ainda no estado embrionário, que títulos teria, mesmo para ser essa coisa vagante e tenebrosa, semelhante ao abismo, diferente de ti, se por teu Verbo não fosse conduzida ao mesmo Verbo que a criou e se, iluminada por ele, também não se transformasse em luz, não igual, mas análoga à tua imagem? Para um corpo, não é a mesma coisa existir e ser belo, pois de outro modo não poderia viver e viver sabiamente não são a mesma coisa, porque, se fosse, todo espírito seria imutável em sua sabedoria.

 Mas seu bem reside em se manter unido a ti, para não perder, afastando-se, a luz que adquiriu com a tua proximidade, tornando a cair em uma vida semelhante a um abismo de trevas. E também nós, que por nossa alma somos criaturas espirituais, nós nos afastamos de ti, nossa luz, nós fomos outrora trevas nesta vida e ainda padecemos por entre os restos de nossas trevas, até que nos tornamos tua justiça em teu Filho único, como as montanhas de Deus. Pois fomos objetos de teus juízos, que são profundos como abismos.

## CAPÍTULO III

### A luz

 Sobre as palavras que proferiste no começo da criação: "Faça-se a luz, e a luz foi feita" – eu entendo que se adaptam com propriedade à criatura espiritual, que já era uma espécie de via apta a receber tua luz. Mas assim como ela não tinha merecido de ti ser essa espécie de vida apta a receber a luz, do mesmo modo, uma vez criada, ela como as demais formas não mereceu de ti essa iluminação. Porque sua informidade não te agradaria se não tivesse tornado luz, e isso não se contentando com existir, mas contemplando a luz que a iluminava, unindo-se intimamente a ela. Assim, ela devia a existência e o viver feliz apenas à tua graça; voltada, por uma escolha feliz, para o que não pode mudar nem para melhor, nem para pior. Voltou-se para ti, que és o único que existes, e só o teu ser é simples, pois o viver e a felicidade são para ti a mesma coisa, porque és tua própria felicidade.

## CAPÍTULO IV

### A bondade criadora

 Que faltaria, pois, a esse bem, que és tu mesmo, se nenhuma dessas criaturas existisse, ou se tivesse permanecido informes? Tu as criaste, não por ter necessidade delas, nem para aumentar tua felicidade, mas levado pela plenitude de tua bondade, comunicando-lhes uma forma. Na tua perfeição, desagrada-te sua imperfeição; tu as aperfeiçoas para que elas te agradem, e não, com isso, aperfeiçoar a ti mesmo.

 Com efeito, teu Espírito bom pairava sobre as águas, e não era por elas levado como se nelas descansasse. Se diz que teu Espírito nelas repousava; mas era ele que as fazia em si. Incorruptível, imutável, bastando-se a si mesma, tua vontade era suspensa acima da vida que tinhas criado, para a qual viver não é o mesmo que viver feliz, porque ela vive, mesmo quando flutua sobre as trevas. Esta vida carece ainda voltar-se para seu Criador, para viver cada vez mais próxima à fonte da vida, para ver a luz na Luz divina, e nela haurir perfeição, brilho e felicidade.

## CAPÍTULO V

### A trindade

 Mas eis que me aparece o enigma da Trindade que és, meu Deus. Porque tu, Pai, criaste o céu e a terra no princípio de nossa Sabedoria, que é tua Sabedoria, nascida de ti, igual e coeterna, a ti, isto é, em teu Filho.

 Já falei longamente do céu do céu, da terra invisível e informe e do abismo das trevas, onde a natureza espiritual errante e fluida permaneceria tal se não se voltasse para Aquele de quem toda vida procede, para que, por meio de sua luz, se tornasse viva e bela, o céu do céu, criado mais tarde entre a água superior e a água inferior.

 Pelo vocábulo "Deus" eu já entendia o Pai, que criou essas coisas; na palavra "princípio" eu entendia o Filho, em quem ele as criou. E, como eu acreditava na Trindade de meu Deus, eu a procurava em tuas santas palavras. E vi em tuas Escrituras que teu Espírito pairava sobre as águas. Eis tua Trindade, meu Deus, Pai, Filho, Espírito Santo, Criador de toda criatura!

## CAPÍTULO VI

### O espírito sobre as águas

 Mas, ó luz da verdade, aproximo de ti meu coração para que ele não me ensine falsidades; dissipa-lhe as trevas e dize-me, eu to suplico por nossa mãe, a caridade, dize-me, por que só depois de ter nomeado o céu, a terra invisível e informe e as trevas sobre o abismo, por que só então é que as Escrituras falam de teu Espírito? Será porque convinha apresentá-lo assim pairando sobre alguma coisa? E seria isso possível se não mencionasse primeiro sobre o que pairava? De fato, não era sobre o Pai nem sobre o Filho que ele pairava, e seria impróprio falar assim se não pairasse sobre alguma coisa.

 Era pois, necessário, mencionar primeiro o elemento sobre o qual ele pairava, já que convinha falar dele apenas dizendo que pairava. Mas por que não convinha apresentá-lo senão dizendo que pairava?

## CAPÍTULO VII

### As águas sem substância

 Agora, quem o puder com a inteligência, siga a teu Apostolo, quando ele diz que tua caridade se difundiu em nossos corações pelo Espírito Santo que nos foi dado, quando nos instrui sobre as coisas espirituais e nos indica o caminho excelso da caridade, e dobra o joelho diante de ti por nossa causa, para que conheçamos a ciência altíssima da caridade de Cristo. E é porque era super eminente desde o princípio que pairava sobre as águas.

 A quem e como falarei do peso da concupiscência, que nos arrasta para um abismo profundo, e da caridade que nos eleva, com a ajuda de teu Espírito, que pairava sobre as águas? A quem falar, como falar? Nós submergimos e emergimos, mas não em abismos materiais. A metáfora é a um tempo correta e muito inexata. São nossas paixões, nossos amores, a impureza de nosso espírito que nos arrasta para baixo sob o peso das preocupações. E é tua santidade que nos eleva pelo amor de tua paz, para que levantemos nossos corações para junto de ti, onde teu Espírito paira sobre as águas, e alcancemos o sublime repouso, quando nossa alma tiver atravessado essas águas que são sem substância.

## CAPÍTULO VIII

### À luz que ilumina as trevas

 O anjo caiu, a alma do homem caiu, revelando assim as profundas trevas em que teria caído o abismo que continha todas as criaturas espirituais, se não tivesses dito desde o começo: "Faça-se a luz!" – se a luz não se tivesse feito, se todas as inteligências de tua cidade celeste não se tivessem unido na obediência a ti, se não tivessem repousado em teu Espírito que paira, imutável, sobre os seres transitórios. De outro modo, até o céu do céu não seria mais que abismo de trevas, enquanto que agora é luz no Senhor.

 Nesta lamentável inquietação dos espíritos decaídos, que, despidos da veste de tua luz, manifestam as próprias trevas, mostras claramente a grandeza de tua criatura racional; na busca da felicidade, ela só se sacia com tua grandeza, onde encontra repouso – pois que ela não pode bastar-se a si própria. Porque tu, Senhor, iluminarás nossas trevas. De ti vêm nossas vestes de luz, e nossas trevas serão como o sol do meio-dia.

 Dá-te a mim, meu Deus, entrega-te a mim. Eu te amo. Se meu amor é pouco, faze que eu te ame com mais força. Não posso medir, não posso saber o que falta a meu amor para que seja suficiente para que minha vida corra para teus braços, e dali não saia antes de se esconder no segredo do teu rosto.

 Se isto reconheço: tudo me corre mal onde tu não estás, não somente à minha volta, mas até em mim mesmo; e toda a abundância que não é meu Deus, para não passa de indigência.

## CAPÍTULO IX

### O amor de Deus

 Mas o Pai e o Filho, não pairavam também sobre as águas? Se os imaginamos como um corpo pairando no espaço, isso não se pode aplicar nem mesmo ao Espírito Santo. Se porém entendermos por isso a excelência imutável da divindade acima de tudo o que é transitório, então o Pai, o Filho e o Espírito Santo pairavam igualmente sobre as águas. E por que só se menciona o Espírito Santo? Por que se menciona apenas a seu respeito um lugar onde estava, ele que, no entanto, não ocupa espaço? Também apenas dele se disse que era um dom de Deus, e é em teu dom que repousamos; é nele que gozamos de ti. Nosso repouso é nosso lugar. É para lá que o amor nos arrebata, e teu Espírito levanta nossa humildade para longe das portas da morte. A paz, para nós, reside na tua boa vontade. Os corpos tendem, por seu peso, para o lugar que lhes é próprio; mas um peso não tende só para baixo; tende para o lugar que lhe é próprio. O fogo sobe, a pedra cai. Cada um é movido por seu peso, e tende para seu justo lugar. O óleo, lançado à água, flutua; a água, lançada ao óleo, afunda. Ambos são impelidos por seu peso a procurarem o lugar que lhes é próprio. As coisas que não estão em seu lugar se agitam; mas quando o encontram, repousam.

 Meu peso é meu amor; para onde quer que eu vá, é ele quem me leva. Teu dom nos inflama e nos eleva; ardemos e partimos. Subimos os degraus do coração e cantamos o cântico gradual. É o teu fogo, o teu fogo benfazejo que nos consome e nos eleva, enquanto subimos para a paz de Jerusalém celeste. Regozijei-me ao ouvir essas palavras: "Vamos para a casa do Senhor!" – Ali nos há de instalar tua boa vontade, e não desejaremos nada mais do que permanecer ali eternamente.

## CAPÍTULO X

### Os dons de Deus

 Feliz a criatura que não conheceu outro estado! Seria porém diferente do que é se, apenas criada, teu Espírito, que paira sobre todas as coisas mutáveis, não a tivesse erguido com este apelo: "Faça- te a luz" – e a luz se fez. Em nós, o tempo em que éramos trevas distingue-se do tempo em que nos tornamos luz. Mas dessa criatura só se diz o que teria sido se não fosse iluminada. A Escritura fala dela como se tivesse sido flutuante e tenebrosa, para nos realçar a causa que a transformou, isto é, que a conduziu para a luz inextinguível, para que também fosse luz. Quem o puder, compreenda, quem não o puder, que te peça a graça de o compreender. Por que importunam, como seu fosse a luz que ilumina a todo homem que vem a este mundo?

## CAPÍTULO XI

### O homem e a trindade

 Quem é capaz de compreender a Trindade onipotente? E quem não fala dela, ainda que a não compreenda? Rara é a pessoa que, falando dela, sabe o que diz. Discute-se, disputa-se, mas ninguém sem paz interior contempla esta visão.

 Quisera que os homens refletissem sobre três coisas que têm dentro de si mesmos. Elas diferem muito da Trindade, e eu só as proponho para que as usem como exercício e experiência do pensamento, e com isso compreender como estão longe deste mistério. Eis as três coisas: ser, conhecer, querer. Porque existo, conheço, quero e vejo. Eu sou aquele que conhece e quer. Sei que existo e que quero, e quero existir e saber. Repare, quem puder, como nessas três coisas a vida é indivisível, a unidade da vida, a unidade da inteligência, a unidade da essência; veja a impossibilidade de distinguir elementos inseparáveis e, contudo, distintos. O homem está diante de si mesmo; que ele se examine, veja e me responda. Contudo, por ter encontrado e reconhecido esta analogia, não julgue por isso ter compreendido a essência do Ser imutável, que transcende tais movimentos da alma, que existe imutavelmente, conhece imutavelmente e quer imutavelmente. Mas é por causa de tais atributos que em deus há a Trindade, ou esses três atributos pertencem a cada pessoa divina, cada uma sendo assim uma e trina? Ou ambas as coisas são admiravelmente reais: a Trindade, misteriosamente simples e múltipla, sendo para si mesma seu próprio fim infinito, pelo qual existe, se conhece e se basta imutavelmente na magnitude superabundante de sua unidade? Quem conceberá facilmente este mistério? Quem poderia explicá-lo? Quem, temerariamente, ousaria enunciá-lo de algum modo?

## CAPÍTULO XII

### A criação e a Igreja

 Ó minha fé, vai adiante em tua confissão. Dize a teu Senhor: "Santo, santo, santo! É o Senhor, meu Deus! – Em teu nome fomos batizados, Pai. Filho e Espírito Santo; em teu nome batizamos, Pai, Filho e Espírito Santo. Também entre nós Deus criou, pelo seu Cristo, um céu e uma terra, isto é, os espirituais e os carnais de sua Igreja. E nossa terra, antes de receber a forma da doutrina, era invisível e informe, e estávamos imersos nas trevas da ignorância, porque castigaste o homem por causa de sua iniqüidade, e teus justos juízos são como abismos profundos.

 Mas porque teu Espírito pairava sobre as águas, tua misericórdia não abandonou nossa miséria, e disseste: "Faça-se a luz". Fazei penitencia, porque está próximo o reino de Deus. Fazei penitencia, faça-se a luz! E porque tínhamos a alma conturbada, nos lembramos de ti, Senhor, às margens do Jordão, sobre essa montanha grande como tu, que te tornaste pequeno por nós. Nossas trevas te desagradaram, nós nos voltamos para ti, e a luz se fez. E eis que outrora fomos trevas e que agora somos luz no Senhor.

## CAPÍTULO XIII

### Nós e a luz

 Contudo, somos luz apenas pela fé, e não por uma visão clara. É na esperança que fomos salvos, e a esperança que vê não é mais esperança. O abismo clama pelo abismo, mas é já pela voz de tuas cataratas. Não pude falar-vos como a homens espirituais, mas como a carnais. Quem assim fala, não julga ainda ter atingido sua meta e, esquecendo-se do que ficou para trás, avança para o que está vivo, como o cervo tem sede de água das fontes, e diz: "Quando chegarei?" – Ele deseja o abrigo de sua morada, que está no céu e chama o abismo inferior dizendo: "Não vos conformeis com este mundo, mas reformai-vos renovando vosso espírito, e não queirais ser crianças na mente, mas sede pequeninos quanto à malícia, para que sejais perfeitos no espírito..." E ainda: "Ó gálatas insensatos, quem vos fascinou?" – Mas não é mais sua voz que fala assim, e sim a tua voz, porque mandaste teu Espírito do alto do céu por intermédio de Jesus, que subiu ao céu e abriu as cataratas de seus dons, para que a torrente de alegria alegrasse tua cidade. É por essa cidade que suspira o amigo do esposo, ele que já possui as primícias do Espírito, mas que ainda geme, porque está à espera da adoção e do resgate do seu corpo. É por ela que suspira, porque ele é membro da Esposa de Cristo; por ela se abrasa em zelo, porque é o amigo do esposo. Zela por ela, não por si mesmo, pois é pela voz de tuas cataratas, e não com sua própria voz, que ele chama pelo outro abismo, objeto de seu zelo e de seus temores. Assim como a serpente enganou Eva com sua astúcia, ele receia que as inteligências débeis se corrompam e se afastem da pureza que está em teu Esposo, teu Filho único. Quão resplandecente será essa luz, quando o virmos tal como ele é, e quando tiverem passado essas lágrimas que se tornaram o pão de meus dias e de minhas noites, enquanto a cada dia me perguntam: Onde está o teu Deus?

## CAPÍTULO XIV

### Esperança

 Também eu pergunto: "Onde estás, meu Deus? Onde estás?" – Respiro um pouco de ti quando minha alma se expande dentro de mim mesmo em gritos de exaltação e de louvor, verdadeiro canto de festa. – Mas ela ainda está triste, porque torna a cair e a ser abismo, ou melhor, porque sente que ainda é abismo.

 Minha fé, que acendeste à noite para conduzir meus passos, lhe diz: "Por que está triste, ó minha alma, e por que me perturbas? Espera no Senhor. Seu Verbo é uma lâmpada para teus passos. Espera, persevera, até que a noite passe, a noite, mãe dos iníquos, até que passe a ira do Senhor, ira da qual outrora fomos filhos quando éramos trevas". – Dessas trevas ainda arrastamos os restos neste corpo morto pelo pecado, até que alvoreça o dia e se dissipem as sombras. Espera no Senhor. Desde a manhã estarei diante deles, e o contemplarei, e o louvarei eternamente. Desde a manhã estarei diante dele e verei a salvação de minha face, meu Deus, que vivificará nossos corpos mortais pelo seu Espírito que habita em nós, misericordiosamente levado por sobre as águas tenebrosas de nossas almas.

 Por isso, em nossa peregrinação, recebemos dele o penhor de já sermos luz; ele já nos salvou pela esperança e, de filhos da noite e das trevas que éramos, ele fez filhos da luz e do dia. Na incerteza da ciência humana, só tu és capaz de distinguir entre uns e outros, porque põe nossos corações à prova e chamas à luz dia e às trevas noite. Quem, senão tu, sabe nos distinguir? E que temos nós que não o tenhamos recebido de ti? Nós, feitos vasos de honra, fomos feitos da mesma argila que serviu para fazer os vasos de ignomínia.

## CAPÍTULO XV

### Símbolos

 E quem, senão tu, nosso Deus, estendeu sobre nós um firmamento de autoridade, da tua divina Escritura? O céu se dobrará como um livro, e agora ele se estende sobre nós como um pergaminho. Mais sublime é a autoridade de que goza tua divina Escritura depois que morreram aqueles que cujo intermédio no-las comunicaste. E sabes, Senhor, sabes como cobriste de peles os homens, quando o pecado os tornou mortais. Por isso estendeste como um pergaminho o firmamento de teu Livro, e tuas palavras em tudo concordes, que dispuseste sobre nós pelo ministério de homens mortais. Por sua morte, a autoridade de tuas palavras, por eles divulgadas, desdobra sua força sobre tudo o que existe em baixo; ela não se erguia tão alto enquanto eles viviam. É que ainda não tinhas desenrolado o céu como um pergaminho, nem tinhas ainda difundido a glória de sua morte por toda parte.

 Senhor, faze que contemplemos os céus, obra de tuas mãos! Dissipa de nossos olhares as nuvens com que os tens velado. Neles está teu testemunho, dando sabedoria aos humildes. Meu Deus completa teu louvor pela boca dos meninos que ainda mamam! Não conhecemos outros livros que assim destruam a soberba, e que abatam tão bem o inimigo que resiste a toda reconciliação contigo, e defende seus pecados. Não, Senhor, não conheci outras palavras tão puras, que tantos me persuadissem à confissão, e sujeitassem minha mente a teu jugo, convidando-me a te servir tão desinteressadamente. Oxalá eu as compreenda, bondoso Pai! Concede esta graça à minha submissão, pois as firmaste para os corações submissos.

 Há outras águas, creio eu, sobre esse firmamento: águas imortais e isentas da corrupção terrena. Que elas louvem teu nome! Que os povos celestes de teus anjos te bendigam, pois não têm necessidade de olhar esse firmamento, nem de ler para aprenderem a conhecer tua palavra! Eles sempre vêem tua face, e ali lêem, sem as sílabas transitórias, o objeto da tua vontade eterna. Lêem, escolhem, amam. Lêem perpetuamente, e o que eles lêem jamais fenece; escolhendo e amando, lêem tua imutável vontade. Teu códice jamais de fecha, jamais se enrola, porque tu mesmo és eternamente esse livro; tu os estabeleceste acima deste firmamento, levantado por ti acima da fraqueza dos povos da terra, para que estes, olhando-o, reconheçam tua misericórdia, que te anuncia no tempo, tu criador do tempo. Tua misericórdia está no céu, e tua verdade se eleva até às nuvens. As nuvens passam, mas o céu permanece. Os que pregam tua palavra passam para uma outra vida, mas tua Escritura se estende sobre os povos até o fim dos séculos. O céu e a terra passarão, mas tuas palavras não passarão. O pergaminho será enrolado, e a erva sobre o qual se estendia passará com seu esplendor, mas a tua palavra permanecerá eternamente. Agora ela nos aparece no enigma das nuvens e através do espelho dos céus, e não como é na realidade, porque ainda não se manifestou o que havemos de ser, apesar de amados pelo teu filho. Ele nos olhou através da teia da sua carne e nos acariciou, e nos inflamou de amor, e corremos atrás de sua fragrância. Mas quando ele aparecer seremos semelhantes a ele, porque o veremos tal como ele é. Vê-lo tal qual é será nossa felicidade, mas nós ainda não o podemos contemplar.

## CAPÍTULO XVI

### Deus, fonte de luz

 Assim como só tu existes plenamente, só tu possuis o conhecimento absoluto: imutável, com efeito, és em teu ser, imutável em teu saber, imutável na tua vontade. Tua essência sabe e quer imutavelmente, tua ciência é e quer imutavelmente, tua vontade é e sabe imutavelmente. Não é justo a teus olhos que a luz imutável seja conhecida pelo ser mutável, que ela ilumina, como ela se conhece a si própria. Por isso, minha alma é para ti como terra sem água, porque assim como não pode iluminar a si mesma, não se pode saciar por seus próprios meios. Porque em ti está a fonte da vida, e graças à tua luz é que veremos a luz.

## CAPÍTULO XVII

### As águas amargas

 Quem reuniu em um só mar as águas amargas? Seu objetivo é o mesmo: uma felicidade temporal, terrena, alvo de todas as suas ações a despeito da grande diversidade de cuidados que as agitam. Quem, senão tu, Senhor, poderia dizer a essas águas que se reunissem em um só lugar, e à terra enxuta que aparecesse, sedenta de ti? O mar é teu, pois tu o fizeste, e tuas mãos formaram a terra enxuta. Não é a amargura das vontades mas a reunião das águas que chamamos de mar. Também refreias as paixões más das almas e fixas os limites até onde permites que avancem as águas, para que suas ondas se quebrem sobre si mesmas; e assim, crias o mar, submetido a teu poder universal.

 As almas sedentas de ti, que aparecem a teu olhos separadas do mar com outra finalidade, tu as regas com um orvalho vivo, misterioso e doce, para que a terra produza seu fruto. E a terra o produz; ao teu comando, ó Senhor que és seu Deus, nossa alma germina obras de misericórdia, de acordo com sua condição: ela ama o próximo e vai em auxílio de suas necessidades materiais. Carrega em si a semente da compaixão, por uma semelhança de natureza, porque é o sentimento de nossa fraqueza que nos leva a compadecer as misérias dos que são necessitados, a socorre-los, como desejaríamos que nos socorressem se tivéssemos as mesmas necessidades. E não se trata só de dar apoio fácil, como ervas nascidas de sementes, mas de proteção enérgica, vigorosa como a árvore que carrega frutos, símbolos das obras que arrebatam à mão do poderoso a vítima da injustiça, dando-lhe um abrigo à sombra protetora de um julgamento justo.

## CAPÍTULO XVIII

### Meditação

 Senhor, assim como crias e concedes alegria e força, assim te peço que nasça da terra a vontade, e que a justiça lance os olhos sobre nós do alto dos céus, e que no firmamento brilhem os astros! Dividamos nosso pão com quem tem fome, acolhamos em nossa casa o pobre sem teto, vistamos quem está nu, e não desprezemos nossos semelhantes! Quando tais frutos nascem de nossa terra, olha, Senhor, e diz: Isso é bom; faze que tua luz brilho no momento oportuno. Por esta humilde messe de boas obras, faze que nos possamos elevar a uma contemplação deliciosa do Verbo da Vida, e que brilhemos no mundo como astros, fixados no firmamento de tua Escritura.

 E aí, de fato, que nos ensinas a distinguir entre as realidades inteligíveis e as sensíveis, entre as almas espirituais e as almas que se entregam aos sentidos, como entre o dia e a noite. Deste modo já não és mais o único, no segredo de teu discernimento, como eras antes da criação do firmamento, a distinguir entre a luz e as trevas. Também tuas criaturas espirituais, dispostas e ordenadas nesse mesmo firmamento, depois que tua graça se manifestou através do mundo, brilham sobre a terra, separam o dia da noite e marcam as diferenças dos tempos. De fato, as coisas antigas passaram, e eis que se fizeram novas, nossa salvação está mais próxima do que quando começamos a crer, a noite avançou e se aproximou o dia, coroas o ano com tua benção, envias teus operários à tua messe, semeada pelo trabalho de outros operários, enviando-os também para outra sementeira, cuja messe será colhida no fim dos séculos.

 Assim ouves as preces do justo e abençoas seus anos. Mas continuas eternamente o mesmo, e em teus anos, que não terão fim, preparas um celeiro para os anos que passam.

 Por desígnio eterno, lanças sobre a terra os bens do céu no tempo oportuno; a um, teu Espírito dá a palavra de sabedoria, luminar maior para os que encontram seu deleite na luz de uma verdade clara como o raiar do dia; a outro dás, pelo mesmo Espírito, a palavra de ciência, luminar menor; a outro a fé; a outro o poder de curar; a outro o dom dos milagres; a outro a graça da profecia; a este o discernimento dos espíritos, `aquele o dom das línguas. E todos esses dons são como estrelas, são obra de um só e mesmo Espírito, que reparte a cada um os seus dons como lhe agrada, e que faz aparecer tais astros para o bem comum.

 Mas a palavra de ciência em que estão encerradas todos os mistérios, que variam com o tempo, como varia a lua, e os outros dons que mencionei ao compará-los com as estrelas, diferem a tal ponto desse brilho de sabedoria de que goza o raiar do dia, que não passam de crepúsculo. Contudo, teus dons são necessários àqueles homens, a quem teu prudente servidor não pôde dirigir como a espirituais, mas como a carnais, ele que pregou a Sabedoria entre os perfeitos.

 Quanto ao homem carnal, semelhante a um menino em Cristo, que só se alimenta de leite, que não se julgue abandonado em sua noite, que saiba contentar-se com a luz da lua e das estrelas, até que possa tomar alimento sólido e olhar para o sol. Eis o que nos ensinas em tua sabedoria, nosso Deus, em teu livro, que é teu firmamento, para que distingamos todas as coisas em contemplação admirável, embora ainda estejamos sob a lei dos sinais, dos tempos, dos dias e dos anos.

## CAPÍTULO XIX

### Ainda a terra seca

Mas antes, lavai-vos, purificai-vos, arrancai a iniqüidade de vossos corações e de meus olhos, para que apareça a terra seca. Aprendei a fazer o bem, sede justos para com o órfão e defendei a viúva, para que a terra produza a erva tenra e árvores cheias de frutos. Vinde e dialoguemos, diz o Senhor, e assim no firmamento do céu se ascenderão luminares que brilharão por sobre a terra.

 Aquele rico perguntava ao bom Mestre o que deveria fazer para ganhar a vida eterna. E o bom Mestre, que é bom porque é Deus, e não um homem como o rico o considerava, lhe declarou: "O que deseja conseguir a vida deve observar os mandamentos, afastar de si a amargura da malícia e da iniqüidade, não matar, não cometer adultério, não roubar, não prestar falso testemunho, a fim de que se mostre a terra seca, geradora do respeito do pai e da mãe e do amor do próximo.

 – Tudo isto já fiz – diz o rico. – De onde vêm pois tantos espinhos, se a terra é fértil? – Vai, arranca os espessos emaranhados da avareza, vende teus bens, enriquece-te dando tudo aos pobres, e possuirás um tesouro no céu; segue o Senhor se queres ser perfeito, junta-te aos que ele instrui nas palavras de sabedoria, ele que sabe o que se deve dar ao dia e à noite. Também tu o saberás, e eles se tornarão para ti luminares no firmamento do céu. Mas isso não se realizará se ali não estiver teu coração, e teu coração, não estará onde não estiver teu tesouro – Assim falou teu bom Mestre. Mas a terra estéril entristeceu, e os espinhos sufocaram a Palavra divina.

 Mas vós, geração escolhida, fracos aos olhos do mundo, que tudo deixaste para seguir o Senhor, caminhais após ele, confundi os fortes; segui-lo com vossos pés resplandecentes, e brilhai no firmamento para que os céus cantem suas glórias, distinguindo a luz dos perfeitos, que ainda não são semelhantes aos anjos, e as trevas dos pequenos, que ainda não perderam a esperança. Brilhai sobre toda a terra! Que o dia resplandecente de sol transmita ao dia seguinte a palavra de Sabedoria, e que a noite, iluminada pela lua, transmita à noite a palavra de Ciência. A lua e as estrelas brilham na noite, mas a noite não as obscurece, porque são elas que iluminam a noite, de acordo com a sua capacidade.

 Como se Deus tivesse dito: Façam-se luminares no firmamento, e logo se fez ouvir um ruído vindo do céu, semelhante ao de um vento violento, e foram vistas línguas de fogo, que se dividiram e se colocaram sobre cada um deles. E apareceram luminares no céu, que possuíam a palavra de vida. Correi por toda parte, chamas sagradas, fogos admiráveis. Vós sois a luz do mundo, e não estais debaixo do alqueire. Aquele a quem vos unistes foi exaltado e ele vos exaltou. Correi e dai-vos a conhecer a todas as nações.

## CAPÍTULO XX

### Os répteis e as aves

 Que o mar também conceba e dê à luz tuas obras; que as águas produzam répteis dotados de almas vivas. De fato, separando o precioso do vil, vos tornastes a boca de Deus, pela qual ele diz: "Produzam as águas..." não a alma viva, filha da terra, mas répteis dotados de almas vivas, e pássaros que voam sobre a terra. Assim como esses répteis, teus sacramentos, ó meu Deus, deslizaram, graças às obras de teus santos, por entre as ondas das tentações do século para regenerarem os povos com teu nome, em teu batismo.

 Então se operaram grandes maravilhas, semelhantes a enormes cetáceos, e as palavras de teus mensageiros percorreram a terra, sob o firmamento de teu Livro, que com tua autoridade deveria proteger seu vôo para onde quer que fossem. Não há língua nem palavras em que não se ouçam suas vozes; seu som espalhou-se por toda a terra, e suas palavras até os confins do mundo, porque tu, Senhor, abençoando-os, os multiplicaste.

 Estaria eu mentindo? Ou confundindo a questão, não distinguindo as claras noções das coisas do firmamento das obras corpóreas que se realizam no mar agitado e sob o firmamento? Por certo que não. Há coisas cuja idéia é completa, acabada, que não se multiplicam no curso das gerações, tais como as luzes da sabedoria e da ciência. Mas esses seres são o objeto de operações materiais múltiplas e variadas e, crescendo umas de outras, se multiplicam sob tua benção, meu Deus. É assim que refreias a impertinência de nossos sentidos, dando a uma verdade única o meio de se exprimir de varias maneiras, por movimentos do corpo. Eis que produziram tuas águas, pela onipotência de teu Verbo. Tudo isto se originou das necessidades de povos afastados de tua verdade eterna, por meio do teu Evangelho. De fato foram essas águas que fizeram brotar essas coisas, e sua amargura estagnante foi causa de que teu Verbo as criasse.

 Todas tuas obras são belas, mas és indizivelmente mais belo tu, que criaste tudo o que existe. Se Adão não se tivesse separado de ti, em sua queda, de seu seio não teria saído o oceano amargo do gênero humano, com sua profunda curiosidade, seu orgulho cheio de tempestades, suas ondas instáveis. E os dispensadores de tuas palavras não teriam a necessidade de representar, no meio de tantas águas, por meio de sinais físicos e sensíveis, teus atos e palavras místicas. Foi nesse sentido que entendi esses répteis e essas aves. Mas até os homens iniciados nesses sinais e deles imbuídos, não avançariam no conhecimento desses mistérios, aos quais estão sujeitos, se sua alma não se elevasse á vida do espírito, e, após a palavra inicial, não aspirasse à perfeição.

## CAPÍTULO XXI

### A alma viva

 E assim não foi a profundeza do mar, mas a terra livre do amargor das águas que, impelida pelo teu Verbo gerou não mais os répteis dotados de almas vivas e os pássaros, mas a alma viva. E esta não mais tem necessidade de batismo (necessário para os gentios), como tinha necessidade enquanto as cobriam. Pois não se entra de outro modo no reino dos céus, desde que assim o determinaste. Para ter fé, ela já não exige grandes maravilhas. Ela crê sem ter visto sinais e prodígios, porque é terra fiel, já distinta das águas do mar que a incredulidade torna amargas: e as línguas são um sinal,não para os fiéis, mas para os infiéis.

 A terra que estendeste acima das águas não tem necessidade dessa espécie de aves que as águas produziram por ordem de teu Verbo. Envia-lhe, pois, teu Verbo, por meio de teus mensageiros. Nós falamos de suas obras, mas quem age por seu intermédio, para que produzam uma alma viva, és tu. A terra a germina porque é a causa dos fenômenos que ocorrem na superfície, assim como o mar foi causa da produção dos répteis dotados de almas vivas, e das aves sob o firmamento do céu. A terra já não necessita destas criaturas, embora ela se alimente de peixes pescados nas profundezas do mar, nessa mesa que preparaste na presença dos crentes; porque eles foram pescados nas profundezas do mar para alimentar a terra árida.

 Também as aves, ainda que nascidas no mar, multiplicam-se sobre a terra. As primeiras gerações evangélicas foram motivadas pela incredulidade dos homens, mas também fiéis nela encontram diariamente copiosas exortações e bênçãos. Todavia, a alma viva, extrai da terra sua origem, porque somente aos fiéis é meritório abster-se de amar este mundo, para que sua alma viva por ti, essa alma que estava morta quando vivia em delícias mortíferas. Ó Senhor, só tu fazes as delicias de um coração puro.

 Que teus ministros trabalhem na terra, não como nas águas da incredulidade, quando pregavam e falavam utilizando-se de milagres, de sinais misteriosos, de termos místicos, para capturar atenção da ignorância, mãe da admiração, pelo medo desses sinais secretos. Por esta porta, de fato, os filhos de Adão têm acesso à fé, esquecidos de ti enquanto se escondem de tua fade e se tornam abismos. Que teus ministros trabalhem como em terra seca, separada das fauces do abismo; e que sejam modelo para os fiéis, vivendo sob teus olhares e incitando-os à imitação. E assim ouve não só para ouvir, mas também para praticar. "Procurai a Deus, e vossa alma viverá, e a terra dará nascimento a uma alma viva. Não vos conformeis com este mundo em que vivemos, abstendo-vos dele. A alma vive evitando as coisas cujo desejo causa-lhe a morte. Abstende-vos das violências selvagens da soberba, das ociosas voluptuosidades da luxúria, da falsidade que engana em nome da ciência, para que os animais ferozes sejam domesticados, os brutos domados e para que as serpentes sejam inofensivas: todos representam alegoricamente os movimentos da alma humana. O fastio do orgulho, as delícias da luxúria, o veneno da curiosidade, são movimentos da alma morta, mas não morta a ponto de carecer de todo movimento; é afastando-se da fonte da vida que ela morre, o mundo a arrebata ao passar, e a este se amolda.

 Mas tua palavra, meu Deus, é a fonte da vida eterna, e não passa. Ela mesma nos proíbe que nos afastemos de ti por essas palavras: "Não vos conformeis com o mundo em que vivemos, para que a terra, fertilizada pela fonte da vida, produza uma alma viva, uma alma que busque em tua palavra, transmitida por teus evangelistas, se fortificar, imitando os imitadores de teu Cristo". – Eis o sentido da expressão "segundo sua espécie", porque o homem imita a quem ama. "Sede como eu" – diz o Apostolo, - porque sou como vós. – Assim haverá na alma viva apenas feras sem maldade, agindo com doçura. Pois nos deste este mandamento: "Fazei vossas obras com mansidão, e sereis amados por todos" – Também os animais domésticos serão bons: se comerem, não sofrerão fastio e, se não comerem, não terão fome. As serpentes, tornando-se boas, serão incapazes de causar danos, mas continuarão astutas e cautelosas; não investigarão a natureza temporal, senão na medida necessária para compreender e contemplar a eternidade através das coisas criadas. Esses animais, as paixões, obedecem à razão, quando refreados em seus caminhos mortais, vivem e se tornam bons.

## CAPÍTULO XXII

### Sentido místico da criação do homem

 Assim, Senhor, nosso Deus e nosso Criador, quando nossos afetos mundanos, que nos causam a morte porque nos faziam viver mal, se afastarem do amor do mundo, quando nossa alma, vivendo bem, se tornar alma viva, e quando se cumprir a palavra que proferiste pela boca de teu Apostolo: "Não vos conformeis com o mundo em que vivemos" – então seguir-se-á aquilo que acrescentaste imediatamente ao dizer: "Mas reformai-vos na novidade de vossa mente". – E já não será "segundo vossa espécie" – como se fosse imitar nossos predecessores ou viver seguindo os exemplos de alguém melhor que nós. Não disseste: "Que o homem seja feito de acordo com sua espécie" – mas "façamos o homem à nossa imagem e semelhança" – para que pudéssemos reconhecer tua vontade. Para tanto, o divulgador de teu pensamento, que gerou filhos pelo Evangelho, não querendo que continuassem como crianças os que alimentara com leite e agasalhara em teu seio como uma ama, dizia: "Reformai-vos renovando vosso coração, para discernir a vontade de Deus, que é bom, agradável e perfeito". – Também não dizes: "Façase o homem" – mas "à nossa imagem e semelhança". Aquele que é renovado no espírito, que compreende e conhece tua verdade, não mais carece que um outro lhe ensine a imitar sua espécie. Graças às tuas lições, ele reconhece por si qual é tua vontade, o que é bom, agradável e perfeito. Tu lhe ensinas, pois agora é capaz deste ensinamento, a ver a Trindade da Unidade e a Unidade da Trindade. Eis por que, depois de falar no plural: "Façamos o homem" se diz no singular: "E Deus criou o homem". Depois deste plural: "À nossa imagem" – este singular: "À imagem de Deus". Assim o homem "se renova pelo conhecimento de Deus, à imagem de seu criador" – e "tornando-se espiritual, julga todas as coisas", que certamente hão de ser julgadas, "mas ele não é julgado por ninguém".

## CAPÍTULO XXIII

### O julgamento do homem espiritual

 Ele julga tudo, significa que tem autoridade sobre os peixes do mar, sobre os pássaros do céu, sobre os animais domésticos e selvagens, sobre toda a terra e sobre todos os répteis que nela se arrastam. Exerce esse poder pela inteligência, pela qual percebe as coisas que são do Espírito de Deus. Mas, elevado a tão grande honra, o homem não entendeu sua dignidade, igualou-se aos jumentos insensatos, tornando-se semelhante a eles.

 Por isso, na tua Igreja, Senhor, pela graça que lhe concedeste – pois somos obra tua, e criados para obras boas, tanto os que governam como os que obedecem segundo o Espírito tem o dom de julgar. Porque assim fizeste a criatura humana homem e mulher, em tua graça espiritual, onde não há distinção conforme o sexo, nem judeu nem grego, nem escravo nem homem livre. Os espirituais, portanto, tanto os que presidem como os que obedecem, julgam espiritualmente. Eles não julgam conhecimentos espirituais que brilham no firmamento, pois não lhes cabe fazer juízos sobre tão sublime autoridade. Nem julgam tua Escritura, mesmo em suas passagens obscuras: nós lhe submetemos nossa inteligência, e temos certeza de que até aquilo que está oculto à nossa compreensão é justo e verdadeiro. O homem, pois, embora já espiritual e renovado pelo conhecimento, conforme a imagem de seu criador, deve ser cumpridor da lei, e não seu juiz. Nem pode ajuizar sobre o que distingue espirituais e carnais. Somente teus olhos, meu Senhor, os distinguem, mesmo que nenhuma obra sua os tenha revelado a nós, para que os reconheçamos por seus frutos. Mas tu, Senhor, já os conheces e os classificaste, e os chamaste no segredo de teu pensamento, antes de ter criado o firmamento.

 Tampouco julga, o homem espiritual, os povos inquietos deste mundo. De fato, por que julgaria ele os que estão fora, ignorando quem alcançará a doçura da tua graça, e quem permanecerá na eterna amargura da impiedade?

 Por isso, o homem que criaste à tua imagem, não recebeu poder sobre os astros do céu, nem sobre o mesmo céu misterioso, nem sobre o dia e a noite que chamaste á existência antes da criação do céu, nem sobre a massa das águas, que é o mar. Mas recebeu poder sobre os peixes do mar, sobre as aves do céu, sobre todos os animais, sobre toda a terra, e sobre tudo o que se arrasta pela superfície do solo.

 Ele julga e aprova o que acha bom, e reprova o que acha mau, quer na celebração dos sacramentos, com que são iniciados os que na tua misericórdia tira das águas profundas, quer no banquete em que se serve o peixe tirado das profundezas para alimento da terra fiel; quer nas palavras e expressões sujeitas à autoridade de teu Livro que, semelhantes aos pássaros, voam sob o firmamento: interpretações, exposições, discussões, bênçãos e invocações que brotam sonoras da boca, para que o povo responda: Amém! É necessário que essas palavras sejam enunciadas fisicamente, por causa do abismo do mundo e da cegueira da carne que, impossibilitada de ver o pensamento, tem necessidade de sons que firam os ouvidos. Assim, sem dúvida é sobre a terra que as aves se multiplicam, embora tenham suas origens na água.

 O homem espiritual julga também aprovando o que acha correto e reprovando o que é vicioso nas obras e nos costumes dos fiéis. Julga das suas esmolas, comparáveis aos frutos da terra; ele julga a alma viva pelas paixões domadas pela castidade, os jejuns, e pelos pensamentos piedosos, na medida em que essas coisas se manifestam aos sentidos do corpo. Em resumo, é juiz de tudo o que pode se corrigir.

## CAPÍTULO XXIV

### Crescei e multiplicai-vos

 Mas que é isto? Que mistério é este? Abençoas os homens, Senhor, para que eles cresçam, se multipliquem, e encham a terra. Não queres nisto dar-nos a entender alguma coisa? Por que não abençoaste também a luz, que chamaste dia, nem a terra, nem o mar? Eu diria, meu Deus, que nos criaste à tua imagem, diria que quiseste conceder especialmente ao homem esta benção, se não houvesses abençoado igualmente os peixes e os cetáceos, para que cresçam, se multipliquem, encham as águas do mar, e os pássaros para que se multipliquem sobre a terra.

 Afirmaria ainda que essa benção foi reservada às espécies vivas que se reproduzem por meio de geração, caso a encontrasse também nas árvores, nas plantas, nos animais da terra. Mas não foi dito nem às plantas, nem às árvore , nem aos répteis: "Crescei e multiplicai-vos" – embora todas essas criaturas se multipliquem pela procriação, como os peixes, os pássaros e os homens, conservando assim sua espécie.

 Quer dizer, então, ó minha Luz, ó Verdade? Que tais palavras carecem de senso e foram ditas em vão? De nenhum modo, ó Pai de misericórdia. Longe de mim, longe do servidor de teu Verbo, uma tal afirmação! Apenas não compreendo o sentido dessas palavras, e espero que os melhores que eu, ou seja, os mais inteligentes, a entendam melhor, segundo a sabedoria que deste, meu Deus, a cada um. Que te agrade ao menos a confissão, que faço diante de ti, de minha certeza de que não falaste em vão aquelas palavras.

 Não calarei as reflexões que me sugere a leitura dessas palavras. O que penso é verdadeiro, e nada vejo que impeça de explicar assim os textos figurados de teus livros. Sei que sinais corporais podem exprimir de vários modos uma idéia que o espírito concebe em um só sentido; uma idéia expressa de um só modo. Como exemplo, cito a simples idéia do amor de Deus e do próximo. Quantos símbolos, quantas línguas, e em cada uma inúmeras locuções lhe dão uma expressão concreta! É assim que crescem e se multiplicam os peixes das águas.

 E note ainda nisto, meu leitor. Há uma frase que a Escritura declara de uma só forma, e que a voz fala apenas dessa maneira: "No princípio criou Deus o céu e a terra" – E não pode a frase ser interpretada diversamente – descartando o erro ou o sofisma – conforme os diversos pontos de vista legítimos? É assim que crescem e se multiplicam as gerações dos homens!

 Se consideramos a natureza das coisas, não alegoricamente, mas em sentido próprio, a sentença: "Crescei e multiplicai-vos" – se aplica a todas as criaturas que nascem de uma semente. Se, ao contrário, a interpretamos em sentido figurado, como penso que foi a intenção da Escritura, que não limita inutilmente essa benção aos peixes e aos homens, encontramos então multidões de criaturas espirituais e temporais, como no céu e na terra; de almas justas e injustas, como na luz e nas trevas; de escritores sagrados que nos anunciaram a Lei, como no firmamento estabelecido entre as águas; na sociedade amargurada dos povos, como no mar; no zelo das almas piedosas, como em terra enxuta; nas obras de misericórdia praticadas nesta vida, como nas plantas que nascem de semente e nas árvore frutíferas; nos dons espirituais concedidos para o bem de todos, como nos luminares do céu; nas paixões dominadas pela temperança, como na alma viva. Em todas essas coisas encontramos multidões, fecundidade, crescimento. Mas que esse crescimento e essa proliferação exprimam uma mesma idéia de vários modos e que uma só expressão possa ser entendida de muitas maneiras, esse fato, apenas o encontramos nos sinais sensíveis e nos conceitos intelectuais.

 Os sinais corpóreos, originados da profundidade de nossa cegueira carnal, correspondem, segundo penso, às gerações das águas; os conceitos intelectuais, gerados pela fecundidade da inteligência, simbolizam,me parece, as gerações humanas.

 E é por isso, Senhor, creio que disseste tanto às águas como aos homens: "Crescei e multiplicai-vos" – Nessa benção, penso que nos deste a faculdade, o poder de formular de várias maneiras uma única idéia, e de compreender também de muitas maneiras uma expressão única, mas obscura.

 É assim que as águas do mar se povoam, e não se moveriam sem as várias interpretações das palavras. É assim que a terra se povoa de gerações humanas; sua aridez se fecunda pela sua paixão da verdade, sob o poder da razão.

## CAPÍTULO XXV

### Os frutos da terra

 Quero ainda dizer, Senhor meu Deus, o que me inspiram as palavras que seguem da tua Escritura. E o farei sem medo, porque direi a verdade; pois não vem de ti, por acaso, a inspiração do que queres que eu diga? Não creio que eu possa dizer a verdade se tu não me inspirares, pois tu és a própria verdade, e todo homem é mentiroso. Por isto, quem mente fala do que é seu. Logo, para falar a verdade, só falarei o que me inspiras.

 Tu nos deste para alimento todas as ervas que produzem semente e que cobrem a terra, e todas as árvore que contém em si, em germe, seus frutos. E não foi somente a nós que deste esse alimento, mas também às aves do céu, aos animais da terra e aos répteis, mas não aos peixes e aos grandes cetáceos. Dizíamos que esses frutos da terra significam e representam alegoricamente as obras de misericórdia, que a terra fecunda produz para as necessidades desta vida. Era semelhante a uma terra assim o piedoso Onesíforo, cuja casa recebeu a graça de tua misericórdia, porque muitas vezes assistira a teu Paulo, sem se envergonhar por suas cadeias.

 É o mesmo que fizeram os irmãos que, de Macedônia, lhe forneceram o que lhe era necessário, produzindo também abundante fruto. E contudo, o Apóstolo se queixa de certas árvore que não lhe tinham dado fruto devido, quando escreve: "em minha primeira defesa ninguém me assistiu; todos me abandonaram. Que isto não lhes seja imputado!" – Tais frutos são devidos aos que nos ministram doutrina racional, ajudando-nos a compreender os mistérios divinos. E nós lhes devemos exemplos de todas as virtudes; e também lhes devemos os frutos como a pássaros do céu, por causa das bênçãos que distribuem abundantemente sobre a terra, pois sua voz se fez ouvir por toda a terra.

## CAPÍTULO XXVI

### O dom e o fruto

 Nutrem-se com esses alimentos os que neles se alegram; não encontram neles alegria os homens cujo deus é seu ventre. E até entre os que ofertam esses frutos, o fruto não é o que eles dão, mas o espírito com que o oferecem. Por isso, naquele que servia a seu Deus e não a seu ventre percebo claramente a fonte de sua alegria; e participo fortemente de seu regozijo. Paulo recebera os presentes que os filipenses lhes tinham mandado por intermédio de Epafrodito. Vejo bem a razão de sua alegria. E é dela que se nutria, porque ele diz com verdade: "Alegrei-me muito no Senhor, vendo enfim reflorescer para mim vossa estima, da qual já andáveis desgostados".

 Eles, de fato, tinham estado realmente aborrecidos e, tornados áridos, não produziam mais o fruto das boas obras; e Paulo se alegra por eles, porque suas simpatias tornaram a florescer, e não por o terem socorrido na sua indigência. Porque ele diz em seguida: "Não é por causa das privações que sofro que falo assim: aprendi a me contentar com o que tenho. Sei acomodar-me às privações, e sei viver na abundância. Em tudo e por tudo habituei-me à saciedade e à fome, à abundância e à penúria. Tudo posso naquele que me fortalece".

 Qual então o motivo de tua alegria, ó grande Paulo? De onde vem tal júbilo, de que te alimentas, ó homem renovado para o conhecimento de Deus, conforme a imagem de teu Criador, alma viva que possui tal domínio de si, língua alada que exprime os mistérios? É certamente a tais almas que se deve este alimento. O que foi para ti esse alimento substancioso? A alegria. Ouçamos o que segue: "Contudo, fizestes bem ao partilhar de minhas tribulações" – Esta é a fonte da alegria, isto é o que o nutre, as boas obras, e não o conforto que aliviou sua miséria. Ele diz: "Na tribulação dilatastes meu coração" – pois ele aprendeu a viver na abundância e sofrer as privações, em ti, que o confortas. – "Bem sabeis, filipenses – diz ele – que nos primórdios de minha pregação do Evangelho, quando deixei a Macedônia, nenhuma Igreja me assistiu com seus bens quanto ao dar e receber, com exceção de vós, que, várias vezes me enviaste, para Tessalônica, com que suprir às minhas necessidades". – Alegra-se agora por voltarem à prática de boas ações, felicitando-se por terem eles reflorido como campo fértil e verdejante.

 Referia-se por acaso às próprias necessidades quando dizia: "Socorrestes às minhas necessidades"? – Será este o motivos de sua alegria? Certamente que não. E como o sabemos? Porque ele diz em seguida: "Eu não procuro a dádiva, mas o fruto". – Aprendi de ti, meu Deus, a discernir a dádiva do fruto. O dom é a própria coisa dada por aquele que acode às nossas necessidades; é o dinheiro, a comida, a bebida, a roupa, um abrigo, e auxílio. O fruto é a vontade boa e reta do doador. O bom Mestre não se limita a dizer: "Aquele que receber um profeta" – mas acrescenta: "Aquele que receber um justo..." – mas acrescenta: "na qualidade de justo". – E assim, aquele receberá a recompensa do profeta, e o outro, a do justo. Ele não diz apenas: "Aquele que der um copo de água fresca a um de meus pequeninos" – mas acrescenta: "na qualidade de discípulo". – E prossegue: "Na verdade vos digo: este não ficará sem recompensa". – Dom é receber o profeta, receber o justo, dar um copo de água fresca a um discípulo; fruto é fazer isso em consideração de sua qualidade de profeta, de justo, de discípulo. É com este fruto que Elias era alimentado pela viúva: ela sabia que alimentava um homem de Deus, e é por isso que o fazia. Os alimentos, porém, que lhe eram levados pelo corvo, não passavam de dom, e não era o Elias interior, mas o Elias exterior que recebia esse alimento, o que poderia morrer se lhe faltasse esse alimento.

## CAPÍTULO XXVII

### Peixes e cetáceos

 Por isso, Senhor, direi diante de ti a verdade. Por vezes, ignorantes e infiéis que, para serem iniciados e conquistados para a fé, precisam desses rituais de iniciação e de milagres mirabolantes, simbolizados, a meu ver, pelos peixes e pelos cetáceos, acolhem teus servos e os socorrem, ou os auxiliam nas necessidades da vida presente, sem saber por que o fazem nem em vista de que devem agir. Desse modo, nem aqueles os alimentam, nem estes são alimentados por eles, pois os primeiros não são movidos por vontade santa e reta, e os segundos não se alegram com os dons recebidos, não descobrindo neles fruto algum. Ora, a alma só se alimenta com o que lhe traz alegria. É esta a razão pela qual os peixes e os cetáceos se nutrem de alimentos que a terra só pode produzir depois de separados e purificados de amargura das águas do mar.

## CAPÍTULO XXVIII

### A bondade da criação

 Viste, meu Deus, que tudo o que criaste te pareceu excelente. Também nós vemos tua criação, e ela nos parece excelente. Para cada espécie de obra criada, disseste: "Faça-se" e quando elas se fizeram, viste que eram boas. Sete vezes está escrito – eu as contei – que viste a excelência de tua obra; e na oitava vez contemplaste toda a criação, e disseste que, no seu conjunto, era não apenas boa, mas muito boa. Tomadas separadamente, tuas obras eram boas; consideradas em seu conjunto, elas eram boas e até excelentes. O mesmo julgamento se pode fazer da beleza dos corpos. Um corpo, formado de membros todos belos, é muito mais bonito que cada um desses membros cuja harmoniosa organização forma o conjunto, embora, considerados à parte, também eles tenham sua beleza própria.

## CAPÍTULO XXIX

### A palavra de Deus e o tempo

 Procurei ver com atenção se forma sete ou oito as vezes que constataste a bondade de tuas obras quando elas te agradaram. Mas não encontrei uma seqüência temporal não tua visão, de onde pudesse deduzir que foi esse o número de vezes que viste tuas criaturas. Então disse: "Senhor, não será verdadeira tua Escritura, inspirada por ti, que és a própria verdade? Por que então me dizes que tua visão das coisas não está sujeita ao tempo, enquanto tua Escritura me diz que dia por dia viste a bondade de tuas obras? E calculei quantas vezes o fizeste."

 A isto me respondes, porque és meu Deus, falando com voz forte no ouvido interior de teu servo, rompendo minha surdez, me exclamas: "Ó homem, o que minha Escritura diz, isto digo eu. Mas ela fala no tempo, enquanto este não atinge o meu verbo, que permanece em mim, eterno como eu. Assim, o que vês por meu Espírito, sou eu quem o vê; o que dizes por meu Espírito, sou eu quem o diz. Mas o que vês no tempo, eu não vejo no tempo; e o que dizes no tempo, eu não digo no tempo."

## CAPÍTULO XXX

### Erro dos maniqueus

 Ouvi, Senhor, meu Deus, tua voz, e recolhi em meu coração uma gota de doçura de tua verdade. Compreendi que há uns aos quais tuas obras desagradam. Eles sustentam que muitas delas fizeste constrangido pela necessidade, como a estrutura dos céus, a ordem dos astros; afirmam que não as criaste por ti mesmo, mas que elas já existiam alhures, criadas por outra fonte; que te limitaste a reuni-las, a ordená-las, a entrelaçá-las; que com elas construíste as muralhas do mundo, depois de vencido teus inimigos, para que essa construção os mantivesse cativos, e não mais pudessem se revoltar contra ti; que não criaste nem organizaste outros seres, como os corpos carnais, os animais pequenos e tudo o que se prende à terra por meio de raízes; que foi um espírito hostil, uma outra natureza, não criada por ti, e que se opõe a ti nas regiões inferiores do mundo, que as gerou e organizou. Esses insensatos falam assim porque não vêem tuas obras através de teu Espírito, nem te reconhecem neles.

## CAPÍTULO XXXI

### A luz do espírito divino

 O oposto sucede aos que vêem tuas obras através de teu Espírito, pois és tu é quem as vê neles. Portanto, quando vêem que elas são boas, tu também vês essa bondade; em tudo o que lhes agrada por tua causa, tu és que nos agradas, e o que nos agrada através de teu Espírito é em nós que te agrada. Com efeito, quem dentre os homens sabe das coisas do homem, senão o espírito do homem que nele habita? Do mesmo modo o que pertence a Deus ninguém o sabe, a não ser o Espírito de Deus. "Quanto a nós, diz ainda Paulo, não recebemos e espírito deste mundo, mas o Espírito de Deus, para que conheçamos os dons que nos vêm de Deus".

 E isto me fez perguntar: Posto que certamente ninguém sabe das coisas de Deus, com exceção do Espírito de Deus, como então nós conhecemos os dons que nos vêm de Deus? Eis a resposta que recebi: As coisas que sabemos por seu Espírito, ninguém as sabe a não ser o Espírito de Deus. É pois justo que foi dito aos que falavam, inspirados pelo Espírito de Deus: "Não sois vós os que falais" – e aos que obtém seu saber do Espírito de Deus: "Não sois vós os que sabeis". – E com igual razão se diz aos que vêem através do Espírito de Deus: "Não sois vós os que vêem". Assim, em tudo o que vemos de bom pelo Espírito de Deus, não somos nós que vemos, mas Deus.

 Por isso, uma coisa é julgar mau o que é bom, como o fazem aqueles de quem falei acima, e outra coisa é o homem ver o que é bom. Todavia, muitos amam tua criação porque é boa, mas não tem amam nessa criação; e por isso preferem gozar dela que de ti. Há ainda outro caso, quando alguém vê que uma coisa é boa, mas é Deus que nele vê que essa coisa é boa, e é Deus que é amado em sua criação. Ele só o pode ser graças ao Espírito que Deus nos deu, porque o amor de Deus foi derramado em nossos corações pelo Espírito Santo que nos foi dado. Por ele, vemos que tudo o que de algum modo existe é bom, pois recebe seu ser daquele que é, não de um modo qualquer, mas de modo absoluto.

## CAPÍTULO XXXII

### A criação

 Graças te damos, Senhor! Vemos o céu e a terra, isto é, a parte superior e inferior do mundo material, assim como a criação espiritual e material. E, como adorno dessas partes que se compõe, o conjunto do Universo, e o conjunto de toda a criação, vemos a luz que foi criada e separada pelas trevas. Vemos o firmamento do céu, tanto o que está situado entre as águas espirituais superiores e as águas materiais inferiores, como ainda esses espaços de ar, chamados também de céu, onde volitam as aves do céu entre as águas que se evolam em vapores, e nas noites serenas se condensam em orvalho, e as que correm pesadas sobre a terra. Vemos a beleza das águas reunidas nas planícies do mar, e a terra enxuta, ora nua, ora tomando forma visível e ordenada, mãe das plantas e das árvore . vemos os luminares do céu brilhando acima de nós, o sol bastar para o dia, a lua e as estrelas consolando a noite, e todos esses astros marcando e assinalando a cadência do tempo. Vemos o elementos úmido habitado por peixes, monstros, animais alados, porque a densidade do ar que sustenta o vôo dos pássaros é aumentada pela evaporação das águas. Vemos a face da terra embelezar-se de animais terrestres, e o homem, criado à tua imagem e semelhança, senhor de todos os animais irracionais, precisamente porque foi feito à tua imagem e se assemelha a ti, em virtude da razão e da inteligência. E como na alma humana há uma parte que domina pela reflexão e outra que se submete na obediência, assim a mulher foi criada fisicamente para o homem; é fora de dúvida que ela possui um espírito e uma inteligência racional, iguais aos do homem, mas seu sexo a coloca sob a dependência do sexo masculino; é desse modo que o desejo, princípio da ação, se submete à razão que concebe a arte do agir retamente. Eis o que vemos, e que cada uma dessas coisas, tomadas por si, são boas, e que todas, em seu conjunto, são muito boas.

## CAPÍTULO XXXIII

### A matéria e a forma

 Que tuas obras te louvem para que te amemos! Que nós te amemos, para que tuas obras te louvem! Elas têm seu princípio e fim no tempo, seu nascimento e morte, seu progresso e decadência, sua beleza e sua imperfeição. Elas têm, portanto, sucessivamente sua manhã e sua noite, umas oculta; outras, manifestamente.

 Foram feitas por ti do nada, não de tua substância, nem de nenhuma substância estranha ou inferior a ti, mas de matéria concriada, isto é, criada por ti ao mesmo tempo em que lhe deste forma, sem nenhum intervalo de tempo. Sem dúvida a matéria do céu e da terra é uma coisa, e sua forma é outra; a matéria tua a fizeste do nada, a forma, tu a tiraste da matéria informe. Contudo, criaste uma e outra a um só tempo, de maneira que entre a matéria e a forma não houvesse nenhum intervalo de tempo.

## CAPÍTULO XXXIV

### Alegoria da criação

 Também meditei sobre o significado simbólico da ordem pela qual se fez tua criação e da ordem pela qual a Escritura relata. Vimos que tuas obras, consideradas cada uma em si, são boas, e em seu conjunto, muito boas. Em teu Verbo, em teu Filho único, vimos o céu e a terra, a cabeça e o corpo da Igreja, predestinadas antes de todos os tempos, quando ainda não havia nem manhã, nem tarde. Depois começaste a executar no tempo o que predestinaste antes do tempo, a fim de revelar teus desígnios ocultos e de dar ordem às nossas desordens – porque pesavam sobre nós nossos pecados, e nos perdíamos longe de ti em voragens de trevas. Teu Espírito misericordioso pairava sobre nós, para nos socorrer no momento oportuno. Justificaste os ímpios; tu os separaste dos pecadores e confirmaste a autoridade de teu Livro entre os superiores, que te eram dóceis, e os inferiores, para que a eles se submetessem. Reuniste em um corpo único, de mesmas aspirações, a sociedade dos infiéis, para que aparecesse o zelo dos fiéis fecundo em obras de misericórdia, e distribuindo aos pobres os bens da terra para adquirir os do céu.

 Acendeste então os luzeiros no firmamento: teus santos, que possuem a palavra de vida e brilham pela sublime autoridade dos seus dons espirituais. Depois, para difundir a fé entre as nações idólatras, fizeste com a matéria visível dos sacramentos os milagres bem perceptíveis, e determinaste as vozes das palavras sagradas, conformes ao firmamento de teu Livro, pelas quais seriam abençoados teus fiéis. Formaste depois a alma viva dos fiéis, pela disciplina das paixões bem ordenadas e pelo vigor da continência. Por fim renovaste a alma, que não estava sujeita senão a ti, e que não tinha mais necessidade de nenhuma autoridade humana para imitar, à tua imagem e semelhança; submeteste, como a mulher ao homem, a atividade racional ao poder da inteligência. Quiseste que a teus ministros que são necessários ao progresso dos fiéis nesta vida, que esses mesmos fiéis propiciassem o necessário para suas necessidades temporais; obras valiosas de caridade, cujos frutos colherão no futuro. vemos todas essas coisas, e todas são muito boas, porque tu as contemplas em nós, tu que nos deste o Espírito, para que por ele pudéssemos vê-las e amar-te nelas.

## CAPÍTULO XXXV

### Prece

 Senhor Deus, tu que nos deste tudo, concede-nos a paz do repouso, a paz do sábado, a paz do ocaso. De fato, esta formosíssima ordem de coisas muito boas, passará quando atingir o termo de seu destino, e terá sua tarde como teve seu amanhecer.

## CAPÍTULO XXXVI

### O repouso de Deus

 O sétimo dia, porém, não tem crepúsculo; não entardece porque o santificaste para que se prolongue eternamente. E o repouso de teu sétimo dia, depois de ter criado tantas e tão boas obras, embora sem te causar fadiga, a palavra de tua Escritura nos anuncia que também nós, depois de nossos trabalhos, que são bons porque assim nos o concedeste, encontraremos o repouso em ti, no sábado da vida eterna.

## CAPÍTULO XXXVII

### O repouso da alma

 Então também repousarás em nós, como hoje opera em nós; e o repouso de que gozaremos será teu, como as obras que fazemos são tuas. Mas tu, Senhor, sempre estás ativo e sempre estás em repouso. Tu não vês o tempo, não ages no tempo nem repousas no tempo; todavia, concede-nos que vejamos no tempo,fazes o próprio tempo e o repouso além do tempo.

## CAPÍTULO XXXVIII

### O descanso de Deus

 Vemos, portanto, as tuas criaturas porque elas existem. Mas elas existem porque tu as vês. Olhando à nossa volta, vemos que elas existem; em nosso íntimo, vemos que são boas. Mas tu já as viste feitas quando e onde viste que deviam ser feitas. Agora somos inclinados a praticar o bem, depois que nosso coração concebeu essa idéia em teu Espírito. Outrora estávamos inclinados ao mal, desertando de ti. Tu, porém, ó Deus, único bem, nunca cessaste de nos fazer o bem. Por tua graça, algumas de nossas obras são boas, mas não são eternas. Esperamos, depois de realizá-las, repousar em tua grande santificação. Mas tu, que não precisas de nenhum outro bem, estás sempre em repouso, porque és teu próprio repouso.

 Que homem poderá dar ao homem a compreensão desta verdade? Que anjo a outro anjo? Que anjo ao homem? É a ti que devemos pedir, e em ti é que a devemos buscar, é à tua porta que devemos bater. E somente assim receberemos, somente assim encontraremos, somente assim se nos abrirá tua porta.

*GRATIAS TIBI DOMINE*