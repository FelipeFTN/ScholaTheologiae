## CAPÍTULO V

### A trindade

 Mas eis que me aparece o enigma da Trindade que és, meu Deus. Porque tu, Pai, criaste o céu e a terra no princípio de nossa Sabedoria, que é tua Sabedoria, nascida de ti, igual e coeterna, a ti, isto é, em teu Filho.

 Já falei longamente do céu do céu, da terra invisível e informe e do abismo das trevas, onde a natureza espiritual errante e fluida permaneceria tal se não se voltasse para Aquele de quem toda vida procede, para que, por meio de sua luz, se tornasse viva e bela, o céu do céu, criado mais tarde entre a água superior e a água inferior.

 Pelo vocábulo "Deus" eu já entendia o Pai, que criou essas coisas; na palavra "princípio" eu entendia o Filho, em quem ele as criou. E, como eu acreditava na Trindade de meu Deus, eu a procurava em tuas santas palavras. E vi em tuas Escrituras que teu Espírito pairava sobre as águas. Eis tua Trindade, meu Deus, Pai, Filho, Espírito Santo, Criador de toda criatura!