## CAPÍTULO X

### Os dons de Deus

 Feliz a criatura que não conheceu outro estado! Seria porém diferente do que é se, apenas criada, teu Espírito, que paira sobre todas as coisas mutáveis, não a tivesse erguido com este apelo: "Faça- te a luz" – e a luz se fez. Em nós, o tempo em que éramos trevas distingue-se do tempo em que nos tornamos luz. Mas dessa criatura só se diz o que teria sido se não fosse iluminada. A Escritura fala dela como se tivesse sido flutuante e tenebrosa, para nos realçar a causa que a transformou, isto é, que a conduziu para a luz inextinguível, para que também fosse luz. Quem o puder, compreenda, quem não o puder, que te peça a graça de o compreender. Por que importunam, como seu fosse a luz que ilumina a todo homem que vem a este mundo?