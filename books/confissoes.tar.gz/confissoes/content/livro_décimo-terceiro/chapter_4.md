## CAPÍTULO IV

### A bondade criadora

 Que faltaria, pois, a esse bem, que és tu mesmo, se nenhuma dessas criaturas existisse, ou se tivesse permanecido informes? Tu as criaste, não por ter necessidade delas, nem para aumentar tua felicidade, mas levado pela plenitude de tua bondade, comunicando-lhes uma forma. Na tua perfeição, desagrada-te sua imperfeição; tu as aperfeiçoas para que elas te agradem, e não, com isso, aperfeiçoar a ti mesmo.

 Com efeito, teu Espírito bom pairava sobre as águas, e não era por elas levado como se nelas descansasse. Se diz que teu Espírito nelas repousava; mas era ele que as fazia em si. Incorruptível, imutável, bastando-se a si mesma, tua vontade era suspensa acima da vida que tinhas criado, para a qual viver não é o mesmo que viver feliz, porque ela vive, mesmo quando flutua sobre as trevas. Esta vida carece ainda voltar-se para seu Criador, para viver cada vez mais próxima à fonte da vida, para ver a luz na Luz divina, e nela haurir perfeição, brilho e felicidade.