## CAPÍTULO VIII

### À luz que ilumina as trevas

 O anjo caiu, a alma do homem caiu, revelando assim as profundas trevas em que teria caído o abismo que continha todas as criaturas espirituais, se não tivesses dito desde o começo: "Faça-se a luz!" – se a luz não se tivesse feito, se todas as inteligências de tua cidade celeste não se tivessem unido na obediência a ti, se não tivessem repousado em teu Espírito que paira, imutável, sobre os seres transitórios. De outro modo, até o céu do céu não seria mais que abismo de trevas, enquanto que agora é luz no Senhor.

 Nesta lamentável inquietação dos espíritos decaídos, que, despidos da veste de tua luz, manifestam as próprias trevas, mostras claramente a grandeza de tua criatura racional; na busca da felicidade, ela só se sacia com tua grandeza, onde encontra repouso – pois que ela não pode bastar-se a si própria. Porque tu, Senhor, iluminarás nossas trevas. De ti vêm nossas vestes de luz, e nossas trevas serão como o sol do meio-dia.

 Dá-te a mim, meu Deus, entrega-te a mim. Eu te amo. Se meu amor é pouco, faze que eu te ame com mais força. Não posso medir, não posso saber o que falta a meu amor para que seja suficiente para que minha vida corra para teus braços, e dali não saia antes de se esconder no segredo do teu rosto.

 Se isto reconheço: tudo me corre mal onde tu não estás, não somente à minha volta, mas até em mim mesmo; e toda a abundância que não é meu Deus, para não passa de indigência.