### As lágrimas negadas

 Fechei-lhe os olhos, e uma tristeza imensa invadiu-me o coração, e já me ia desfazer em lágrimas; ao mesmo tempo, meus olhos, obedecendo ao enérgico poder de minha vontade, fechavam sua fonte até secá-la. Como foi angustiosa essa luta! E foi quando ela deu o último suspiro, que o meu filho Adeodato rebentou em soluços; mas, instado por todos nós, se calou. Deste modo sua voz juvenil, voz do coração, calou em mim essa espécie de emoção pueril que me provocava o pranto. De fato, não julgávamos correto celebrar aquele funeral com lágrimas e choro, pois tais demonstrações deploram geralmente o triste destino dos que morrem, ou sua total extinção. A morte de minha mãe não era uma desgraça, e ela não morria para sempre, e disto estávamos certos pelo testemunho de seus costumes, por sua fé sincera e outras razões inequívocas.

 Que era então o que tanto me pungia, senão a ferida recente causada pelo rompimento repentino de nosso dulcíssimo e querido convívio?

 Era para mim grande consolação o testemunho que dera de mim, quando nesta última enfermidade, respondendo com ternura às minhas atenções, chamava-me de bom filho, e recordava com grande afeto o nunca ter ouvido de minha boca uma só palavra dura ou injuriosa contra ela. Entretanto, o que era, meu Deus e meu Criador, a solicitude que eu lhe tributava, em comparação com o devotamento servil que por mim suportava? Por me ver privado de tão grande consolo, sentia a alma ferida e minha vida, que era uma só com sua, estava despedaçada.

 Reprimido o pranto do Adeodato, Evódio tomou o saltério e começou a cantar um salmo, ao que todos respondíamos "Misericórdia e justiça te cantarei Senhor". Conhecia a notícia de sua morte, acorreram muitos irmãos e mulheres piedosas e, enquanto os encarregados dos funerais faziam seu ofício conforme o hábito, retirei-me para um lugar conveniente, junto com os amigos que julgavam oportuno não me deixar só. Falava sobre assuntos próprios das circunstâncias, e com o lenitivo da verdade mitigava meu sofrimento, só conhecido por ti. Eles o ignoravam e me ouviam atentamente, julgando que não sofria nenhuma dor.

 Mas eu, pertinho de teus ouvidos, onde ninguém me podia escutar, censurava a minha sensibilidade e fraqueza e reprimia a onda de tristeza que me invadia; esta cedia por uns instantes, e novamente me arrastava com seu ímpeto, embora não chegasse a derramar lágrimas ou alterar a face. Somente eu sabia quão oprimido estava meu coração! E como me desgostava profundamente que as vicissitudes humanas tivessem tanto poder sobre mim, que são inelutáveis pela ordem natural e a sorte de nossa condição; minha própria dor causava-me outra dor, e me afligia com dupla tristeza.

 Quando o corpo foi levado à sepultura, fui e voltei sem derramar uma lagrima. Nem mesmo nas orações que te fizemos, quando oferecemos o sacrifício de nossa redenção por intenção da morta, cujo cadáver jazia junto ao sepulcro antes de ser inumado, como ali é costume, nem mesmo nessas orações, chorei. Mas durante todo o dia andei oprimido por grande tristeza interior; pedia-te como podia, com a mente perturbada, que aliviasses minha dor. Mas não me atendias, sem dúvida para que fixasse, bem na memória, ao menos por esta única experiência, como são poderosos os laços do costume, mesmo em uma alma que já não se alimentava de palavras enganadoras.

 Lembrei então a ir aos banhos, por ter ouvido dizer que a palavra banho (bálneo, em latim) vinha dos gregos, que o chamaram balanéion (tirar fora a ania), porque o banho aliviava as tristezas da alma. Mas eu o confesso à tua misericórdia – ó Pai dos órfãos: depois do banho fiquei como estava antes, porque meu coração não expulsou o amargor de sua tristeza.

 Depois adormeci. Ao despertar, minha dor estava mitigada; só, em meu leito, lembrei-me dos versos cheios de verdade de teu Ambrósio. Porque, na verdade

Tu és Deus, criador de quanto existe,

De todo o mundo supremo governante,

Que o dia vestes com tua luz brilhante,

E de sonhos gratos a noite triste

 A fim de que os membros cansados O descanso ao trabalho prepare

E as mentes cansadas, repare

E os peitos de pena oprimidos

 Depois, pouco a pouco voltava aos sentimentos de antes sobre tua serva. Recordava de sua piedade para contigo, de sua solicitude e paciência comigo, da qual subitamente me via privado. E senti consolação em chorar diante de ti, por causa dela e por ela, e por minha causa e por mim. E deixei que as lágrimas reprimidas corressem à vontade, estendendo-as como um leito reparador sob meu coração. Teus ouvidos eram os que ali me escutavam, e não os de nenhum homem, que pudesse interpretar com soberba meu pranto.

 E agora, Senhor, to confesso nestas linhas: leia-o quem quiser, interprete-o como quiser. E se alguém julgar que pequei nessas lágrimas, que derramei sobre minha mãe por alguns instantes, por minha mãe então morta a meus olhos, ela que me havia chorado tantos anos para que eu vivesse aos teus olhos, não se ria. Antes, é grande sua caridade, chore por meus pecados diante de ti, Pai de todos os irmãos de teu Cristo!

## CAPÍTULO XIII