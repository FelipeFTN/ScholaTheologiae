## CAPÍTULO XIII

### O pedido de casamento

 Instavam solicitamente comigo para que me casasse. Já havia feito o pedido, já havia recebido uma promessa, ajudado sobretudo por minha mãe, que nutria a esperança que eu, uma vez casado, seria regenerado nas águas salutares do batismo. Minha mãe alegrava-se por me ver cada dia mais apto para recebê-lo, vendo que na minha fé se realizavam seus votos e tuas promessas.

 Contudo, nada revelaste à minha mãe que, a meu pedido e por seu desejo, te suplicava com forte clamor de coração, todos os dias que lhe desse alguma visão sobre meu futuro matrimonio. Via, sim, algumas coisas vãs e fantásticas, que o espírito humano engendra quando preocupado. Ela me relatava, sem a confiança que costumava dar às visões que lhe enviavas, mas com desprezo. Dizia que distinguia, por um vago discernimento que não podia explicar com palavras, a diferença que havia entre tuas revelações e os sonhos de sua alma.

 Contudo, insistia no matrimonio, e pediu-se a mão de uma jovem, à que ainda faltavam dois anos para ser núbil (em todo o Império Romano era a idade de 12 anos), mas, como ela agradava, era preciso esperar.