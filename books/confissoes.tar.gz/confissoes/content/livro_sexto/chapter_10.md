## CAPÍTULO X

### Os três amigos

 Encontrei Alípio em Roma, onde se uniu a mim com vínculo de amizade tão estreito, que foi comigo para Milão, tanto para evitar nosso afastamento como para exercer o Direito, embora mais para agradar aos pais do que por vontade própria. Já por três vezes fora assessor, sempre com admirável lisura, e ficando ele mais admirado ainda de que juizes preferissem o dinheiro à inocência.

 Ficou provada a integridade do seu caráter, não só contra os atrativos da cobiça, mas também contra o aguilhão do medo. Em Roma, era assessor do tesoureiro das finanças da Itália. Havia nesse tempo um senador poderosíssimo, a quem estavam sujeitos muitos clientes, uns por benefícios, outros por terror. Segundo o costume dos poderosos, este senador tentou fazer não sei que coisa era proibida pelas leis, e Alípio se lhe opôs. À tentativa de corrompê-lo, Alípio reconheceu com o riso. Zombou das ameaças que aquele lhe dirigiu, causando admiração geral pela rara qualidade de sua alma, que não desejava a amizade e nem temia a inimizade de homem tão poderoso, conhecido por seus inúmeros meios de prestar favores ou de prejudicar. Até o próprio juiz, de que Alípio era assessor, embora se opusesse também, não o fazia abertamente, responsabilizando a Alípio que, dizia ele, não lhe permitia fazer o que desejava, porque, se acedesse – e era verdade – demitir-se-ia imediatamente.

 Alípio quase se deixara seduzir pelo amor às letras, mandando copiar códigos segundo a tarifa paga aos trabalhos para o Estado; porém, consultando a justiça, inclinou-se pelo melhor, preferindo a integridade, que lhe proibia esta ação, ao poder que lha permitia.

 Isso é fato pequeno, mas o que é fiel no pouco também o é no muito, e de modo nenhum podem ser vãs aquelas palavras saídas da boca de tua Verdade. Se não fordes fiéis nas riquezas injustas, quem vos confiará as verdadeiras? E se nas alheias não fordes fiéis, quem vos dará o que é vosso?

 Assim era então este amigo, tão intimamente unido a mim, e que comigo buscava o tipo de vida que deveríamos seguir.

 Também Nebrídio deixou sua pátria, vizinha de Cartago, e a própria Cartago, onde gozava de boa fama. Abandonou as magníficas propriedades do pai, a casa e até a própria mãe, que não o quis seguir; veio para Milão apenas para viver comigo, na busca apaixonada da verdade e da sabedoria.

 Assim como eu, ele suspirava, partilhando minha perplexidade, mostrando-se investigador ardoroso da vida feliz e indagador acérrimo das questões mais difíceis.

 Eram três bocas famintas que comunicavam mutuamente a própria fome, esperando que lhes desses comida no tempo oportuno. Na amargura, que graças à tua misericórdia sempre seguia nossas ações mundanas, se desejávamos entender a causa dos sofrimentos, encontrávamos trevas. Afastávamos gemendo e dizendo: Até quando durará este sofrimento? E isto repetíamos com freqüência, mas não abandonávamos nosso modo de vida, porque não víamos nenhuma certeza a que nos pudéssemos abraçar, se o abandonássemos.