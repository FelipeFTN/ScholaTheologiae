## CAPÍTULO VIII

### A atração do anfiteatro

 Não querendo por nada deixar a carreira mundana, tão decantada por seus pais, partira antes de mim para Roma, a fim de estudar Direito; lá se deixou arrebatar de modo incrível, e com incrível avidez, pelos espetáculos de gladiadores.

 A princípio, detestava e aborrecia espetáculos semelhantes. Certa vez, encontrando-se com alguns amigos e condiscípulos que voltavam de um jantar, apesar de resistir, foi arrastado por eles com amigável violência para o anfiteatro, onde naquele dia se celebravam jogos funestos e cruéis.

 Dizia-lhes Alípio: "Mesmo que arrasteis para lá meu corpo, e o retenhais ali, podereis por acaso obrigar minha alma e meus olhos a contemplar tais espetáculos? Estarei ali como ausente, e assim triunfarei deles e de vós". Mas eles, não fazendo caso de tais palavras, levaram-no, talvez para verificar se poderia ou não cumprir a palavra.

 Quando chegaram, ocuparam os lugares que puderam, pois todo o anfiteatro já fervia nas paixões mais selvagens. Alípio, fechando a porta dos olhos, proibiu que sua alma se envolvesse em tal crueldade. E oxalá também tivesse tapado os ouvidos! Porque, em um lance da luta, foi tão grande o clamor da multidão que, vencido pela curiosidade, e julgando-se preparado para desprezar e vencer a cena, fosse o que fosse, abriu os olhos. Foi logo ferido na alma mais profundamente do que a ferida física do gladiador a quem desejou contemplar e caiu. Sua queda foi mais miserável que a do gladiador, causa de tantos gritos. Estes, entrando-lhe pelos ouvidos, abriram-lhe os olhos, para ferir e abater sua alma, mais temerária do que forte, e tanto mais fraca por apoiar-se em si mesma, em lugar de se apoiar em ti. Logo que viu sangue, bebeu junto a crueldade, e não se afastou do espetáculo; pelo contrário, prestou mais atenção. Assim, sem o saber, absorvia o furor popular e se deleitava naquela luta criminosa, inebriado de sangrento prazer.

 Já não era o mesmo que ali viera, era agora mais um da turba à qual se misturara, digno companheiro daqueles que para ali o arrastaram.

 Que mais direi? Contemplou o espetáculo, gritou, apaixonou-se, e foi contaminado de louco ardor, que o estimulava a voltar, não só com os que o haviam levado, mas à sua frente, e arrastando a outros. Mas tu te dignaste, Senhor, livrá-lo deste estado com mão forte e misericordiosa, ensinando-o a não confiar em si, mas em ti, embora isto acontecesse muito tempo depois.