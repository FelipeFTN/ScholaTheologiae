## CAPÍTULO I

### Esperanças

 Ó minha esperança desde a minha juventude! Onde estavas, ou a que lugar te havias retirado? Acaso não foste tu quem me criou, diferenciando-me dos animais, fazendo-me mais sábio que as aves do céu? Mas eu caminhava por trevas e resvaladouros, e te buscava fora de mim, e não encontrava o Deus de meu coração; caí nas profundezas do mar. Eu perdera a confiança e desesperava de encontrar a verdade.

 Minha mãe já viera a meu encontro, forte em sua piedade, seguindo-me por mar e por terra, confiando em ti em todos os perigos. Até na travessia do mar proceloso ela encorajava os marinheiros – os que costumam animar os navegadores inexperientes quando se perturbam – garantia-lhes que chegariam a salvo ao fim da viagem, porque assim lho tínheis prometido em visão.

 Encontrou-me em grave perigo, já sem esperança de buscar a verdade. Contudo, quando lhe disse que já não era maniqueísta, sem ser ainda católico, não pulou de alegria, como quem ouve algo inesperado, pois já estava segura sobre aquele ponto de minha miséria, que a fazia chorar por mim como por um morto que haveria de ressuscitar. Oferecia-me continuamente a ti em pensamento, como sobre um esquife, para que dissesses ao filho da viúva: Jovem, eu te digo: levanta-te, e seu filho revivesse, e voltasse a falar, e o entregasses à sua mãe.

 Nem se abalou seu coração com alegria exagerada ao ouvir quanto já se havia cumprido daquilo que com tantas lágrimas te suplicava todos os dias. Viu-me, senão na posse da verdade, já afastado do erro. E como estava certa de que me concederias o que faltava – pois lhe havias prometido a graça total – respondeu-me, com muita calma e com o coração cheio de confiança, que esperava em Cristo que, antes de sair desta vida, me havia de ver católico fiel.

 Foi o que me disse. Mas diante de ti, ó fonte das misericórdias, redobrava as súplicas e lágrimas, para que apressasses teu auxílio e aclarasses minhas trevas. Ia com maior solicitude à igreja para ficar suspensa dos lábios de Ambrosio, como da fonte de água viva que jorra para a vida eterna. Minha mãe amava este varão como a um anjo de Deus, pois sabia que fora ele quem me fizera mergulhar naquela dúvida, pela qual antevia, segura, que eu haveria de passar da enfermidade pela saúde, depois de um perigo mais grave, que os médicos chamam de crítico.