# LIVRO SEXTO

## CAPÍTULO I

### Esperanças

 Ó minha esperança desde a minha juventude! Onde estavas, ou a que lugar te havias retirado? Acaso não foste tu quem me criou, diferenciando-me dos animais, fazendo-me mais sábio que as aves do céu? Mas eu caminhava por trevas e resvaladouros, e te buscava fora de mim, e não encontrava o Deus de meu coração; caí nas profundezas do mar. Eu perdera a confiança e desesperava de encontrar a verdade.

 Minha mãe já viera a meu encontro, forte em sua piedade, seguindo-me por mar e por terra, confiando em ti em todos os perigos. Até na travessia do mar proceloso ela encorajava os marinheiros – os que costumam animar os navegadores inexperientes quando se perturbam – garantia-lhes que chegariam a salvo ao fim da viagem, porque assim lho tínheis prometido em visão.

 Encontrou-me em grave perigo, já sem esperança de buscar a verdade. Contudo, quando lhe disse que já não era maniqueísta, sem ser ainda católico, não pulou de alegria, como quem ouve algo inesperado, pois já estava segura sobre aquele ponto de minha miséria, que a fazia chorar por mim como por um morto que haveria de ressuscitar. Oferecia-me continuamente a ti em pensamento, como sobre um esquife, para que dissesses ao filho da viúva: Jovem, eu te digo: levanta-te, e seu filho revivesse, e voltasse a falar, e o entregasses à sua mãe.

 Nem se abalou seu coração com alegria exagerada ao ouvir quanto já se havia cumprido daquilo que com tantas lágrimas te suplicava todos os dias. Viu-me, senão na posse da verdade, já afastado do erro. E como estava certa de que me concederias o que faltava – pois lhe havias prometido a graça total – respondeu-me, com muita calma e com o coração cheio de confiança, que esperava em Cristo que, antes de sair desta vida, me havia de ver católico fiel.

 Foi o que me disse. Mas diante de ti, ó fonte das misericórdias, redobrava as súplicas e lágrimas, para que apressasses teu auxílio e aclarasses minhas trevas. Ia com maior solicitude à igreja para ficar suspensa dos lábios de Ambrosio, como da fonte de água viva que jorra para a vida eterna. Minha mãe amava este varão como a um anjo de Deus, pois sabia que fora ele quem me fizera mergulhar naquela dúvida, pela qual antevia, segura, que eu haveria de passar da enfermidade pela saúde, depois de um perigo mais grave, que os médicos chamam de crítico.

## CAPÍTULO II

### Obediência de Mônica

 Assim, um dia, como costumava na África, levou papas, pão e vinho puro à sepultura dos mártires, mas o porteiro não quis permitir suas ofertas. Quando soube que essa proibição vinha do bispo, resignou-se tão piedosamente e obedientemente, que eu mesmo me admirei de quão facilmente passasse a condenar o hábito, e não a criticar a proibição de Ambrósio.

 É que seu espírito não era dominado pela embriaguez, nem o amor do vinho a incitava ao ódio da verdade, como acontece a muitos homens e mulheres, que ao ouvir o cântico da sobriedade, sentem a mesma repulsa que os ébrios diante de um copo d'água. Mas ela, ao trazer as cestas com as oferendas usuais para serem provadas e repartidas, não bebia mais que um pequeno copo de vinho, temperado segundo seu paladar bastante sóbrio e condizente com sua dignidade. E se eram muitos os sepulcros que devia honrar desse modo, levava sempre o mesmo copo, usando-o para todos, de modo que o vinho não só estava muito aguado, mas até quente. Dividia-o em pequenos tragos com as pessoas presente, porque buscava a piedade, e não o prazer.

 Tão logo porém soube que o ilustre pregador e mestre a verdade proibira tal costume – mesmo para os que o praticavam sobriamente, para não dar aos ébrios azo de se embriagarem, e porque essa espécie de parentales (festas pagãs que se celebravam de 13 a 21 de fevereiro consagradas especialmente aos deuses lares) era muito semelhante à superstição dos pagãos – ela se absteve de muito boa vontade. No lugar da cesta cheia de frutos da terra, aprendeu a levar ao túmulo dos mártires um coração cheio de puros desejos, dando o que podia aos pobres. Celebrava assim a comunhão com o corpo do Senhor, cuja paixão serviu de modelo aos mártires em seu sacrifício e coroação.

 Mas, parece-me, meu Senhor e meu Deus – e assim o crê meu coração em tua presença – que minha mãe não teria abdicado tão facilmente desse costume – que todavia era necessário cortar – se outro a quem não amasse tanto como a Ambrosio o tivesse proibido. De fato, ela o estimava muito por ter-me salvado, e ele a tinha em grande estima pela religiosidade e solicitude com que freqüentava a igreja, na prática das boas obras. Por isso, muitas vezes quando me encontrava com ele, irrompia em louvores à minha mãe, e me felicitava por ser seu filho. Ignorava o filho que ela tinha em mim, filho que duvidava de tudo, e julgava impossível achar o caminho da vida.

## CAPÍTULO III

### Primeiras conquistas

 Na oração, eu ainda não implorava o teu socorro, mas meu espírito achava-se ocupado em investigar e inquieto por discutir. Considerava ao próprio Ambrósio como homem feliz aos olhos do mundo, vendo-o tão honrado pelas mais altas autoridades. Somente seu celibato me parecia difícil. Mas eu não podia aquilatar, por nunca as ter experimentado, as esperanças que o animavam, nem a luta que tinha de travar contra as tentações de sua alta posição; nem conhecia os consolos na adversidade, nem os saborosos deleites do interior do seu coração quando ruminava teu alimento. Ele, por sua vez, desconhecia minha inquietação e o abismo em que estava para cair, porque não lhe podia perguntar, como desejava, o que queria. Uma multidão de homens de negócios, a quem ele acudia nas dificuldades, impediam-me de o ouvir ou de lhe falar.

 No bem pouco tempo que lhe deixavam livre, dedicava-se a reparar as forças do corpo com o alimento necessário, ou as do espírito, com a leitura. Quando lia, seus olhos percorriam as páginas e seu espírito penetrava-lhes o sentido, mas sua voz e sua língua repousavam.

 Muitas vezes, estando eu presente – pois ninguém estava proibido de entrar, nem era costume anunciar quem se apresentava – vi-o ler em silêncio, e nunca de outra maneira. E ali ficava eu por muito tempo calado – pois, quem se atreveria molestar um homem tão atento? – e por fim me afastava. Conjeturava eu que nos curtos momentos que encontrava para repousar o espírito, livre do tumulto dos negócios alheios, não queria que o ocupassem com outra coisa. Lia em silêncio (era comum naqueles tempos ler em voz alta, tanto pela dificuldade dos textos como pela escassez dos livros, muitas vezes lidos em comum), talvez para evitar que algum ouvinte, suspenso e atento à leitura, encontrando alguma passagem obscura, pedisse explicações, ou o obrigasse a dissertar sobre questões difíceis. Gastaria o tempo em tais coisas, e impedido de ler todos os livros que desejava, embora fosse mais provável que lesse em silêncio para poupar a voz, que facilmente lhe enrouquecia.

 Em todo caso, qualquer que fosse sua intenção, só poderia ser boa em um homem como ele.

 O certo é que não se apresentava nenhum ensejo para interrogar a teu santo-oráculo que habitava em seu coração sobre o que desejava, exceto quando lhe ouvia uma breve resposta, e minhas inquietudes pediam muito tempo e vagar para consultá-lo, o que nunca encontrava. Ouviao, é certo, explicar perfeitamente ao povo a palavra da verdade todos os domingos, persuadindome sempre mais de que podiam ser desatados todos os nós das calúnias sagazes que aqueles que me enganavam teciam contra os livros sagrados.

 Logo verifiquei que vossos filhos espirituais, a quem regeneraste no sei da santo mãe, a Igreja, não interpretavam aquelas palavras: "Fizeste o homem à sua imagem" – de modo a acreditar que estavas encerrado na forma do corpo humano. E embora eu então não soubesse, nem sequer suspeitasse de longe o que fosse substância espiritual – alegrei-me com isso, envergonhando-me por ter ladrado durante tantos anos, não contra a fé católica, mas contra invenções de minha inteligência carnal. Tinha sido ímpio e temerário por criticar uma doutrina que eu deveria ter antes procurado conhecer. Mas tu – que estás ao mesmo tempo tão alto e tão perto de nós, tão escondido e tão presente, tu que não tens membros maiores nem menores, que estás inteiro em toda parte sem estar todo em nenhum lugar, certamente não tens nossa forma corpórea. Contudo, fizeste o homem à tua imagem, e eis que ele, da cabeça aos pés, é limitado pelo espaço.

## CAPÍTULO IV

### O espírito da letra

 Não compreendendo como poderia se espelhar esta tua imagem ao homem, eu deveria bater à porta, perguntando-te de que modo deveria entender essa crença, em lugar de me opor insolentemente, como se ela fosse o que eu imaginava. E assim, tanto mais fortemente me roia o coração o desejo de ter alguma certeza, quanto mais me envergonhava de ter sido o joguete dos que me haviam prometido a certeza, e por ter defendido com pueril empenho e animosidade tantas coisas duvidosas como sendo verdadeiras.

 Depois vi a razão por que eram falsas. Mas já estava então certo de que elas eram duvidosas, embora as tivesse julgado irrefutáveis por algum tempo, quando, com minhas cegas discussões, combatia tua Igreja Católica. Embora então não a reconhecesse como mestra da verdade, pelo menos sabia que não ensinava aquilo de que eu a acusava.

 Daí minha confusão, e a conversão que se operava em meu pensamento, ó meu Deus, vendo que tua Igreja única, corpo de teu Filho único, na qual, ainda menino me ensinaram o nome de Cisto, não gostava de bagatelas infantis. Regozijava-me que em sua doutrina sadia nada havia que te representasse, a ti, Criador de todas as coisas, circunscrito numa forma e num espaço que, embora amplo, seria contudo limitado.

 Também me alegrava de que as Antigas Escrituras da lei e os profetas já não me fossem propostas na interpretação anterior, em que me pareciam absurdas, quando eu acusava teus santos de pensamentos que nunca haviam tido. Alegrava-me ouvir a Ambrósio dizer muitas vezes em seus sermões ao povo, recomendando com muito zelo a verdade: a letra mata e o espírito vivifica. E, levantando o véu místico, revelava-me o significado espiritual de passagens que, segundo a letra, pareciam ensinar um erro. Nada dizia que me chocasse, embora eu ainda ignorasse se ele dizia a verdade.

 Abstinha-se meu coração de aderir a qualquer doutrina, temendo cair em um precipício; mas esta suspensão matava-me muito mais, porque queria estar tão certo das coisas que não via como o estava de que sete e três são dez. Eu não estava tão louco para pensar que a inteligência alcançaria tal evidência. Mas, assim como entendia isso, queria entender igualmente as outras verdades, quer fossem materiais, que não tinha presentes a meus sentidos, quer espirituais, nas quais não sabia pensar senão de modo material.

 É verdade que poderia sarar pela crença, e assim, purificado pela fé o olhar de meu espírito, pudesse dirigir-se de algum modo à tua verdade, sempre imutável e indefectível. Mas, como sói acontecer a quem caiu nas mãos de um médico ruim, e que depois receia as mãos de um bom, assim me sucedia quanto à saúde de minha alma que, não podendo sarar senão pela fé, recusava-se a sarar por temor de crer, novamente, em falsidades. Minha alma resistia às tuas mãos, ó meu Deus, que preparaste o remédio da fé, e o derramaste sobre as enfermidades da terra, dando-lhe tanta autoridade e eficácia.

## CAPÍTULO V

### Os mistérios da Bíblia

 Desde esse tempo, recaía minha preferência na doutrina católica, porque ajuizava que nela houvesse mais modéstia, e não mentira, ao impor a crença no que não era demonstrado – quer porque, mesmo havendo provas, estas não fossem acessíveis a todos, quer porque não existissem. Diferente do que ocorria entre os maniqueus, que desprezavam a fé, e prometiam, com temerária arrogância, a ciência, para depois nos obrigarem a acreditar em uma infinidade de fábulas completamente absurdas, impossíveis de demonstrar.

 Depois, com suavidade e misericórdia, começaste, Senhor, a cuidar e à preparar aos poucos o meu coração, e foi aceitando tudo o que eu acreditava sem o ter visto, e a cuja realização não presenciara. Tantos fatos da história dos povos, tantas notícias sobre lugares e cidades que não vira, tudo o que aceitava acreditando em amigos, em médicos e em outras pessoas que, se não as acreditássemos, não poderíamos dar um passo na vida. E, sobretudo, que fé inabalável eu tinha em ser filho de meus pais, coisa que não poderia saber sem prestar fé no que ouvia. Então me convenceste de que os dignos de censura não são os que acreditam em teus livros, cuja autoridade estabeleceste entre quase todos os povos, mas o que não crêem neles. E eu não devia dar ouvidos ao que talvez me dissessem: "Como sabes que esses livros foram dados aos homens pelo Espírito de Deus, único e verdadeiro?" Ora, era precisamente isto o que eu devia crer, porque nenhuma objeção caluniosa ou agressiva, das que eu havia lido nos escritos contraditórios dos filósofos, nunca conseguiram arrancar-me a certeza de tua existência, embora ignorasse o que eras, e a certeza de que o governo das coisas humanas está em tuas mãos.

 Eu acreditava nisso, ora mais fortemente, ora mais frouxamente; mas em tua existência e que cuidava do gênero humano, sempre acreditei, embora ignorasse a natureza, ou qual o caminho que nos conduz ou reconduz a ti. Por isso, persuadido de nossa impotência para achar a verdade só por meio da razão, e que para isso nos é necessária a autoridade das Sagradas Escrituras, comecei a crer que nunca terias conferido tão soberana autoridade a essas Escrituras em todo o mundo, se não quiséssemos que crêssemos e te buscássemos por elas.

 Sobre os mistérios em que costumava tropeçar, e que ouvira explicar muitas vezes de modo aceitável, eu os atribuía à sua profundidade, parecendo-me a autoridade das Escrituras tanto mais venerável e digna da fé sacrossanta, quando de leitura fácil para todos. E ela reserva porém, a uma percepção mais aguda a majestade de seu mistério. Pela clareza da linguagem e sua simplicidade do estilo, ela se abre a todos e, no entanto, estimula a reflexão dos que não são levianos de coração. Recebe a todos em seu vasto seio, mas não deixa ir a ti, por caminhos estreitos, senão um pequeno número; muito mais, porém, do que seriam se ela não tivesse essa elevada autoridade, e não atraísse as turbas do regaço de sua santa humildade.

 Pensava eu nessas coisas, e me assistias; suspirava, e me ouvias, vacilava, e me governavas; seguia pela via larga do mundo, e não me abandonavas.

## CAPÍTULO VI

### Alegria de bêbado

 Eu aspirava às honras, às riquezas e ao matrimonio, e tu te rias de mim. E nesses desejos sofria grandes amarguras; e tu me eras tanto mais propício quanto menos consentias que me fosse doçura o que não eras tu. Vê, Senhor, meu coração, tu que quiseste que recordasse estes fatos e os confessasse. Esta alma, a quem livraste do visco tenaz da morte, une-se agora a ti. Como era infeliz! E tu fustigavas o mais dolorido da ferida, para que deixasse tudo, e se convertesse a ti, que estás acima de tudo. Sem ti nada existiria. Ferias minha alma para que voltasse para ti, e fosse curada.

 Que miserável era eu então! E como agiste para que eu sentisse minha desgraça? Era o dia em que me preparava para declamar os louvores do imperador; neles ia mentir muito e, mentindo granjearia a aprovação dos que sabiam das mentiras. Preocupado, meu coração se consumia com a febre de pensamentos impuros quando, ao passar por uma rua de Milão, vi um mendigo já bêbado, creio eu, mas bem humorado e divertido. Suspirei então, e falei aos amigos que me acompanhavam sobre as muitas dores que nos provocavam nossas loucuras. Com todos os esforços, quais eram os que então me afligiam, apenas arrastava a carga de minha infelicidade cada vez mais pesada, aguilhoado por meus apetites, para conseguir somente uma alegria tranqüila, na qual já nos havia precedido aquele mendigo; alegria que nunca talvez alcançássemos. O que ele havia conseguido com umas poucas moedas de esmola, era exatamente o que eu aspirava com tão árduos caminhos e rodeios: a alegria de uma felicidade temporal.

 A alegria do mendigo não era certamente verdadeira, mas a que eu buscava com minhas ambições era ainda mais falsa. Ele, pelo menos, estava alegre, e eu, angustiado; ele seguro, e eu inquieto. Se alguém me perguntasse se preferia estar alegre ou triste eu responderia: alegre; mas se me perguntassem novamente se queria ser como aquele mendigo ou ser como eu era, sem dúvida escolheria a mim mesmo, embora cheio de cuidados e de temores. Mas isto eu faria por maldade ou com razão? Eu não devia preferir-me ao mendigo por ser mais culto, pois a ciência para mim não era fonte de felicidade, mas apenas um meio de agradar aos homens, e não instruílos. Por isso, Senhor, quebravas meus ossos com a vara de tua disciplina.

 Longe de minha alma os que dizem: "Importa levar em conta a causa da alegria; o mendigo se alegrava com a embriaguez, e tu com a glória". Que glória, Senhor? Com a que não está em ti. Porque como aquela não era verdadeira alegria, assim aquela glória não era a verdadeira, antes perturbava mais ainda meu coração. O ébrio, naquela mesma noite, curaria sua embriaguez, enquanto eu já dormia com a minha, e me levantara com ela, e tornaria a dormir e a levantar com ela, e tu sabes quantos dias!

 Importa, é certo, conhecer os motivos da alegria de cada um, eu o sei, e a alegria da esperança fiel dista infinitamente daquela vaidade. Mas então, havia entre nós outra diferença, pois certamente ele era o mais feliz, não só porque transbordava de alegria, enquanto eu me consumia de cuidados, mas também porque ele comprara o vinho desejando a felicidade dos benfeitores, enquanto eu procurava com mentiras uma vã ostentação.

 Muitas coisas disse então sobre isso a meus amigos, e muitas vezes eu costumava examinar minha vida, e achava-me infeliz. Isso me afligia e redobrava minha dor; se me sorria alguma ventura, não acudia para apanhá-la, porque escapava-me das mãos antes mesmo que a pudesse alcançar.

## CAPÍTULO VII

### Alípio

 Os que convivíamos em boa amizade lamentávamos estas coisas, mas de modo especial e muito intimamente eu falava com Alípio e Nebrídio. Alípio, como eu, era do município de Tagaste, nascido de uma das melhores famílias da cidade. Era mais jovem do que eu, pois havia sido meu discípulo quando comecei a ensinar em nossa cidade, de depois em Cartago. Ele me queria muito, por eu lhe parecer bom e douto, e eu o apreciava por sua grande inclinação à virtude, que já se manifestava em tenra idade.

 Contudo, o abismo dos costumes cartagineses, onde ferve o gosto dos espetáculos frívolos, engolfara-o na loucura dos jogos circenses. Alípio revolvia-se miseravelmente nesse abismo na época em que eu ensinava retórica na escola pública, mas ele não me tinha como mestre por causa de uma desavença que surgira entre mim e seu pai. Eu sabia que Alípio amava morbidamente o circo, e isso muito me angustiava, por me parecer que se iam se perder, se já não estivessem, magníficas esperanças. Mas não achava meios de alertá-lo e repreendê-lo, nem pela amizade, nem pelo magistério, pois julgava que tinha sobre mim a mesma opinião que seu pai. Mas não era assim. Pondo de parte a vontade paterna sobre isso, começou a me cumprimentar, comparecia à minha aula, ouvia-me um pouco, e logo se retirava.

 Eu já me esquecera de alertá-lo para não desperdiçar seu talento tão precioso com aquele cego e apaixonado gosto por jogos fúteis. Mas tu, Senhor, que governas o que criaste, não te esqueceste de que Alípio deveria ser ministro de teus sacramentos entre teus filhos; e para que fosse atribuída claramente a ti a sua emenda, a realizaste por meu intermédio, mas sem que eu o soubesse.

 Um dia, estando sentado ao lugar de costume, diante de meus discípulos, veio Alípio, saudou-me, sentou-se, atento ao assunto de que eu tratava. Por acaso trazia eu nas mãos uma lição; para melhor expô-la, e tornar mais clara e agradável sua explicação, pareceu-me oportuno fazer uma comparação com os jogos circenses, com mordaz sarcasmo aos escravos dessa loucura. Mas tu sabes, Senhor, que então não pensei em curar Alípio dessa peste. Todavia tomou para si minhas palavras, acreditando que eu só dissera por sua causa. Qualquer outro tomaria isso com desgosto; mas ele, jovem virtuoso, tomou-o como causa para censurar a si próprio, e para me estimar ainda mais.

 Já havias dito outrora, e escrito em teus livros: "Corrige o sábio, e ele te amará". Eu não o repreenderia, mas tu, servindo-te de todos, quer eles o saibam ou quer não, de acordo com a justa ordem que conheces, fizeste de meu coração e de minha língua carvões abrasadores, para cauterizar e curar aquela alma tão promissora, mas pervertida.

 Senhor, cale teus louvores quem não percebe tuas misericórdias, que eu te confesso do mais íntimo de meu ser. Depois de ouvidas minhas palavras, Alípio saiu daquele fosso profundo, onde gostosamente se enterrara, cegando-se com o torpe prazer, e sacudiu sua alma com corajosa temperança, afastando de si todas as imundícies dos jogos circenses, para onde nunca mais voltou.

 Depois venceu a resistência paterna para me escolher como mestre, e seu pai cedeu e consentiu. Voltando a ser meu discípulo, foi envolvido comigo na superstição dos maniqueus, apreciando neles aquela ostentação de continência, que ele julgava legítima e sincera. Na verdade, porém, era um desvario sedutor, um laço onde caíam almas preciosas, ainda incapazes de avaliar a sublimidade da virtude e, por isso mesmo, vítimas fáceis da aparência que mascara uma virtude hipócrita e fingida.

## CAPÍTULO VIII

### A atração do anfiteatro

 Não querendo por nada deixar a carreira mundana, tão decantada por seus pais, partira antes de mim para Roma, a fim de estudar Direito; lá se deixou arrebatar de modo incrível, e com incrível avidez, pelos espetáculos de gladiadores.

 A princípio, detestava e aborrecia espetáculos semelhantes. Certa vez, encontrando-se com alguns amigos e condiscípulos que voltavam de um jantar, apesar de resistir, foi arrastado por eles com amigável violência para o anfiteatro, onde naquele dia se celebravam jogos funestos e cruéis.

 Dizia-lhes Alípio: "Mesmo que arrasteis para lá meu corpo, e o retenhais ali, podereis por acaso obrigar minha alma e meus olhos a contemplar tais espetáculos? Estarei ali como ausente, e assim triunfarei deles e de vós". Mas eles, não fazendo caso de tais palavras, levaram-no, talvez para verificar se poderia ou não cumprir a palavra.

 Quando chegaram, ocuparam os lugares que puderam, pois todo o anfiteatro já fervia nas paixões mais selvagens. Alípio, fechando a porta dos olhos, proibiu que sua alma se envolvesse em tal crueldade. E oxalá também tivesse tapado os ouvidos! Porque, em um lance da luta, foi tão grande o clamor da multidão que, vencido pela curiosidade, e julgando-se preparado para desprezar e vencer a cena, fosse o que fosse, abriu os olhos. Foi logo ferido na alma mais profundamente do que a ferida física do gladiador a quem desejou contemplar e caiu. Sua queda foi mais miserável que a do gladiador, causa de tantos gritos. Estes, entrando-lhe pelos ouvidos, abriram-lhe os olhos, para ferir e abater sua alma, mais temerária do que forte, e tanto mais fraca por apoiar-se em si mesma, em lugar de se apoiar em ti. Logo que viu sangue, bebeu junto a crueldade, e não se afastou do espetáculo; pelo contrário, prestou mais atenção. Assim, sem o saber, absorvia o furor popular e se deleitava naquela luta criminosa, inebriado de sangrento prazer.

 Já não era o mesmo que ali viera, era agora mais um da turba à qual se misturara, digno companheiro daqueles que para ali o arrastaram.

 Que mais direi? Contemplou o espetáculo, gritou, apaixonou-se, e foi contaminado de louco ardor, que o estimulava a voltar, não só com os que o haviam levado, mas à sua frente, e arrastando a outros. Mas tu te dignaste, Senhor, livrá-lo deste estado com mão forte e misericordiosa, ensinando-o a não confiar em si, mas em ti, embora isto acontecesse muito tempo depois.

## CAPÍTULO IX

### Alípio, ladrão a contragosto

 Contudo, essa aventura gravara-se em sua memória como remédio para o futuro. o mesmo ocorreu com outro fato, quando ainda era estudante em Cartago, e seguia meus cursos. Era meio-dia. Alípio estava repassando uma declamação, segundo o costume dos estudantes, quando foi preso como ladrão pelos guardas do foro. Sem dúvida o permitiste, meu Deus, apenas para que esse jovem, tão grande no futuro, começasse já a aprender que, ao julgar outrem, ninguém deve condenar ninguém levianamente, e com temerária credulidade.

 Alípio, pois, passeava diante do tribunal, sozinho, com as tábuas e o estilete, quando um jovem estudante, o verdadeiro ladrão, levando escondido um machado, sem que Alípio o percebesse, entrou pelas grades que rodeiam a rua dos banqueiros, e se pôs a cortar o seu chumbo.

 Ao ruído dos golpes, os banqueiros que estavam embaixo alvoroçaram-se, e chamaram gente para prender o ladrão, fosse quem fosse. Mas este, ouvindo o vozerio, fugiu depressa, abandonando o machado para não ser preso com ele. Ora, Alípio, que não o vira entrar, viu-o sair e fugir precipitadamente. Curioso, porém, para saber a causa, entrou no lugar. Encontrou o machado e se pôs, admirado, a examiná-lo. Bem nessa hora chegaram os guardas dos banqueiros, e o surpreendem sozinho, empunhando o machado, a cujos golpes, alarmados, haviam acudido. Prendem-no, levam-no, e gloriam-se, diante dos inquilinos do foro por ter apanhado o ladrão em flagrante, e já o iam entregar aos rigores da justiça.

 Mas a lição devia ficar por aqui, Senhor, porque imediatamente saíste em socorro de sua inocência, da qual eras única testemunha. Quando o conduziam à prisão ou ao suplício, veio-lhes ao encontro um arquiteto, encarregado superior da direção dos edifícios públicos. Os guardas alegraram-se com esse encontro, pois sempre que faltava alguma coisa no foro o magistrado suspeitava deles. Agora ele saberia quem era o verdadeiro ladrão. Mas este senhor tinha visto várias vezes Alípio na casa de um senador, a quem visitava com freqüência. Reconheceu-o, tomou-o pela mão, separou-o da turba, e perguntou-lhe a causa de tamanha desgraça.

 Informado do que se passara, o arquiteto mandou à turba alvoroçada e enfurecida contra Alípio que o seguisse. Quando chegaram à casa do jovem autor do roubo, achava-se à porta um menino escravo, novo demais para recear comprometer seu amo, e que poderia revelar tudo, porque o seguira até o foro. Alípio, ao reconhecê-lo, apontou-o ao arquiteto; este, mostrando-lhe o machado, lhe disse: "Sabe de quem é este machado?" Ao que o menino respondeu sem demora: "Nosso". Depois de interrogado, confessou o resto.

 Deste modo, o processo foi transferido para aquela casa, para confusão da turba, que já imaginara tripudiar de Alípio. O futuro dispensador de tua palavra, e juiz de tantas causas de tua Igreja, saiu dessa aventura com mais experiência e sabedoria.

## CAPÍTULO X

### Os três amigos

 Encontrei Alípio em Roma, onde se uniu a mim com vínculo de amizade tão estreito, que foi comigo para Milão, tanto para evitar nosso afastamento como para exercer o Direito, embora mais para agradar aos pais do que por vontade própria. Já por três vezes fora assessor, sempre com admirável lisura, e ficando ele mais admirado ainda de que juizes preferissem o dinheiro à inocência.

 Ficou provada a integridade do seu caráter, não só contra os atrativos da cobiça, mas também contra o aguilhão do medo. Em Roma, era assessor do tesoureiro das finanças da Itália. Havia nesse tempo um senador poderosíssimo, a quem estavam sujeitos muitos clientes, uns por benefícios, outros por terror. Segundo o costume dos poderosos, este senador tentou fazer não sei que coisa era proibida pelas leis, e Alípio se lhe opôs. À tentativa de corrompê-lo, Alípio reconheceu com o riso. Zombou das ameaças que aquele lhe dirigiu, causando admiração geral pela rara qualidade de sua alma, que não desejava a amizade e nem temia a inimizade de homem tão poderoso, conhecido por seus inúmeros meios de prestar favores ou de prejudicar. Até o próprio juiz, de que Alípio era assessor, embora se opusesse também, não o fazia abertamente, responsabilizando a Alípio que, dizia ele, não lhe permitia fazer o que desejava, porque, se acedesse – e era verdade – demitir-se-ia imediatamente.

 Alípio quase se deixara seduzir pelo amor às letras, mandando copiar códigos segundo a tarifa paga aos trabalhos para o Estado; porém, consultando a justiça, inclinou-se pelo melhor, preferindo a integridade, que lhe proibia esta ação, ao poder que lha permitia.

 Isso é fato pequeno, mas o que é fiel no pouco também o é no muito, e de modo nenhum podem ser vãs aquelas palavras saídas da boca de tua Verdade. Se não fordes fiéis nas riquezas injustas, quem vos confiará as verdadeiras? E se nas alheias não fordes fiéis, quem vos dará o que é vosso?

 Assim era então este amigo, tão intimamente unido a mim, e que comigo buscava o tipo de vida que deveríamos seguir.

 Também Nebrídio deixou sua pátria, vizinha de Cartago, e a própria Cartago, onde gozava de boa fama. Abandonou as magníficas propriedades do pai, a casa e até a própria mãe, que não o quis seguir; veio para Milão apenas para viver comigo, na busca apaixonada da verdade e da sabedoria.

 Assim como eu, ele suspirava, partilhando minha perplexidade, mostrando-se investigador ardoroso da vida feliz e indagador acérrimo das questões mais difíceis.

 Eram três bocas famintas que comunicavam mutuamente a própria fome, esperando que lhes desses comida no tempo oportuno. Na amargura, que graças à tua misericórdia sempre seguia nossas ações mundanas, se desejávamos entender a causa dos sofrimentos, encontrávamos trevas. Afastávamos gemendo e dizendo: Até quando durará este sofrimento? E isto repetíamos com freqüência, mas não abandonávamos nosso modo de vida, porque não víamos nenhuma certeza a que nos pudéssemos abraçar, se o abandonássemos.

## CAPÍTULO XI

### Entre Deus e o mundo

 Era com admiração que me recordava diligentemente do longo tempo decorrido desde meus dezenove anos, quando comecei a arder no desejo da sabedoria, propondo-me, quando a achasse, abandonar todas as vãs esperanças e enganosas loucuras das paixões.

 Chegado porém aos trinta anos, ainda continuava preso ao mesmo lodaçal, ávido de gozar dos bens presentes, que me fugiam e me dissipavam. Entretanto, dizia: "Amanhã hei de encontrála; a verdade aparecerá clara, e a abraçarei. Fausto virá, e dará todas as explicações. Ó grandes varões da Academia: é verdade que não podemos compreender nenhuma coisa com certeza para a conduto de nossa vida?

 "Mas não! Procuremos com mais diligencia, sem desesperarmos. Já não me parecem absurdas nas Escrituras as coisas que antes me pareciam tais: posso compreendê-las de modo diferente, mais razoável. Fixarei, pois, os pés naquele degrau em que me colocaram meus pais quando criança, até que encontres a verdade em sua evidência.

 "Mas onde e quando buscá-la? Ambrósio não tem tempo livre para me ouvir, e a mim falta tempo para ler. E além do mais, onde encontrar os livros? E onde ou quando poderei comprá-los? A quem hei de pedi-los?

 "Repartamos o tempo, reservemos algumas horas para a salvação da alma. nasceu uma grande esperança: a fé católica não ensina o que eu pensava, e eu a criticava levianamente. Seus doutores têm como crime limitar Deus à figura humana; e eu ainda hesito em bater para que nos sejam reveladas as outras verdades! As horas da manhã eu dedico aos alunos; mas que faço das outras? Por que não as consagro a essa busca?

 "Mas quando então, visitar os amigos poderosos, de cujos favores necessito? Quando preparar as lições que os alunos me pagam? Quando reparar as forças do espírito, descansando em algo aprazível?

 "Perca-se tudo! Deixemos essas coisas vãs e fúteis. Entreguemo-nos por completo à busca da verdade. A vida é miserável, e a hora da morte, incerta. Se esta me surpreender de repente, em que estado sairei do mundo? E onde aprenderei o que deixei de aprender aqui? Não serei antes castigado por essa negligência? Mas, e se a própria morte cortar e for o fim a todo cuidado e sentimento? Também seria conveniente investigar este ponto. Mas afastemos tais pensamentos! Não é por acaso nem é em vão que se difunde por todo o mundo a fé cristã, com grande prestígio. Deus jamais teria criado tantas e tais coisas por nós, se com a morte do corpo terminasse também a vida da alma. porque hesitar, pois, em abandonar as esperanças do mundo para me consagrar à busca de Deus e da bem aventurança?

 Mas espere um pouco! Os bens mundanos também têm seus deleites, que não são pequenos. Não devo deixá-los sem pensar; seria feio ter de voltar a eles. Eis-me prestes a conseguir um cargo de honra. Que mais posso desejar? Tenho uma multidão de amigos poderosos. Sem me apressar muito poderia obter, no mínimo, uma presidência. Poderia então casar-me com uma mulher de alguma fortuna, para que meus gastos não fossem muito pesados. Aqui estariam os limites de meus desejos. Muitos homens grandes e dignos de imitação, apesar de casados, dedicaram-se ao estudo da sabedoria.

 Enquanto assim pensava, e os ventos cambiantes impeliam meu coração de um lado para outro, o tempo passava, e eu retardava minha conversão ao Senhor. Adiava de dia para dia o viver em ti, morrendo todavia todos os dias em mim mesmo. Amando a vida feliz, temia busca-la em sua morada; procurava-a fugindo dela! Pensava que seria mui desgraçado se me visse privado das carícias da mulher. Não pensava ainda no remédio de tua misericórdia, que cura esta enfermidade, porque nunca o havia experimentado. Julgava que a continência fosse obra de nossa própria força, que eu pensava não ter. Eu era bastante néscio para ignorar que ninguém, como está escrito, é casto sem que tu lhes dê a força. Essa força certamente ma darias se eu ferisse teus ouvidos com os gemidos de minha alma, e com fé firme lançasse em ti meus cuidados.

## CAPÍTULO XII

### Casar ou não?

 Opunha-se Alípio a que me casasse, repetindo-me que, se o fizesse, não poderíamos dedicar-nos juntos, com segura tranqüilidade, ao amor da sabedoria, como há muito desejávamos. Alípio, nessa matéria, era castíssimo de causar admiração, porque, ao entrar na juventude, experimentara o prazer carnal, mas não se prendera a ele. Antes, arrependeu-se muito, e o desprezou, vivendo depois em perfeita continência.

 Eu argumentava com os exemplos dos que, embora casados, haviam-se dedicado ao estudo da sabedoria, servindo a Deus, e guardando fidelidade e amor aos amigos. Contudo, eu estava longe dessa grandeza de alma. Prisioneiro da morbidade da carne, arrastava com prazer mortal minha cadeia, temendo que ela se rompesse e, rejeitando as palavras que bem me aconselhavam, como o ferido repele a mão que lhe desfaz as ataduras.

 Além do mais, a serpente falava por minha boca a Alípio, e pela língua lhe tecia doces laços em seu caminho, para que seus pés honestos e livres se enredassem.

 Ele admirava-se de que eu, a quem tanto estimava, estivesse tão preso ao visco do prazer a ponto de afirmar, sempre que tratávamos desse assunto, que me era impossível levar vida casta. Para esgrimir contra sua admiração, dizia-lhe que havia grande diferença entre sua rápida e furtiva experiência do prazer, de que mal se lembrava e que, por isso, podia desprezar facilmente, e as delícias de uma ligação verdadeira, à qual, se juntasse o honesto nome de matrimonio, já não causaria admiração se eu não pudesse desprezar aquela vida. Com isso, Alípio também começou a desejar o matrimonio, não certamente vencido pelo apetite do prazer, mas pela curiosidade. Desejava saber, dizia ele, o que era aquele bem sem o qual minha vida – que ele tanto apreciava – não me parecia vida, mas tormento. De fato, livre dessa prisão, sua alma pasmava de tal servidão, e do espanto passava ao desejo de experimentá-la. Depois talvez caísse naquela mesma servidão que o espantava, pois queria fazer um pacto com a morte, e o que ama o perigo, nele cairá.

 Certamente que nem ele, nem eu tínhamos grande interesse no que há de bonito e honesto no matrimonio, como a direção da família e a educação dos filhos. Mas o que me mantinha preso e com fortes tormentos era o hábito de saciar minha insaciável concupiscência; e a ele, era a admiração que o arrastava para o mesmo cativeiro. Assim éramos, Senhor, até que tu, ó Altíssimo, que não desamparas nosso lodo, compassivo, por caminhos maravilhosos e ocultos, viestes em socorro destes infelizes.

## CAPÍTULO XIII

### O pedido de casamento

 Instavam solicitamente comigo para que me casasse. Já havia feito o pedido, já havia recebido uma promessa, ajudado sobretudo por minha mãe, que nutria a esperança que eu, uma vez casado, seria regenerado nas águas salutares do batismo. Minha mãe alegrava-se por me ver cada dia mais apto para recebê-lo, vendo que na minha fé se realizavam seus votos e tuas promessas.

 Contudo, nada revelaste à minha mãe que, a meu pedido e por seu desejo, te suplicava com forte clamor de coração, todos os dias que lhe desse alguma visão sobre meu futuro matrimonio. Via, sim, algumas coisas vãs e fantásticas, que o espírito humano engendra quando preocupado. Ela me relatava, sem a confiança que costumava dar às visões que lhe enviavas, mas com desprezo. Dizia que distinguia, por um vago discernimento que não podia explicar com palavras, a diferença que havia entre tuas revelações e os sonhos de sua alma.

 Contudo, insistia no matrimonio, e pediu-se a mão de uma jovem, à que ainda faltavam dois anos para ser núbil (em todo o Império Romano era a idade de 12 anos), mas, como ela agradava, era preciso esperar.

## CAPÍTULO XIV

### Um projeto desfeito

 Éramos muitos os amigos, que aborrecíamos as mazelas da agitação da vida humana. Em nossas conversas, havíamos debatido e quase resolvido nos retirar da multidão para viver sossegadamente. Nosso projeto organizava a vida de tal sorte que tudo o que tivéssemos seria comunitário, formando de todos os patrimônios um patrimônio único. Graças à nossa amizade sincera não haveria mais a fortuna deste ou daquele, mas uma só fortuna comum.

 Seriamos cerca de dez homens os que desejávamos formar essa sociedade. Alguns de nós, muito ricos, como Romaniano, meu conterrâneo, cujos sérios cuidados de negócios o tinham trazido à corte imperial. Era muito amigo meu desde menino, e um dos que mais instavam nesse projeto, tendo sua opinião um grande peso pois sua riqueza era bem superior que a dos outros. Fora combinado que todos os anos, dois de nós, como magistrados, administrariam todo o necessário, ficando os outros em paz. Mas quando se começou a discutir se as mulheres consentiriam nesse acordo – alguns dentre nós eram casados, e outros pensavam em casar – todo o plano, tão bem construído, se desvaneceu entre nossas mãos, fez-se em pedaços e teve de ser abandonado.

 Novamente aos suspiros e gemidos, voltamos a caminhar pelos largos e batidos caminhos do século, porque em nosso coração havia mil pensamentos, mas teu conselho permanece eternamente. Na tua sabedoria te rias de nossos projetos, e preparavas o cumprimento dos teus, a fim de dar-nos alimento no tempo oportuno, abrindo tuas mãos e enchendo-nos de bênçãos.

## CAPÍTULO XV

### A separação da amante

 Entretanto, multiplicavam-se meus pecados. Quando arrancaram do meu lado, por ser impedimento ao meu matrimonio, aquela com quem partilhava o leito, meu coração, ao qual ela estava unida, ficou ferido e sangrando. Ela, por sua vez, voltando para a África, fez-te voto, Senhor, de jamais conhecer outro homem, deixando comigo o filho natural que dela tivera.

 Mas eu, desgraçado, fui incapaz de imitar aquela mulher. Estava impaciente pelo prazo de dois anos que deveria transcorrer até receber por esposa aquela que pedira em casamento – e porque eu não era amante do matrimonio, mas escravo da sensualidade – procurei pois outra mulher, não como esposa, mas para alimentar e manter íntegra ou agravada a doença da minha alma, sob a tutela do meu hábito, até que contraísse matrimonio. Mas nem por isso sarava a chaga causada pela separação da primeira mulher; mas, depois de ardor e sofrimento agudíssimos, começava a se corromper doendo tanto mais desesperadamente quanto mais fria se tornava.

## CAPÍTULO XVI

### A aproximação de Deus

 Louvor e glória a ti, ó fonte das misericórdias! Eu me tornava cada vez mais miserável, e tu te aproximavas cada vez mais de mim. já estava junto de mim tua destra, para me arrancar do lodo dos meus vícios, e em purificar, e eu não o sabia. Mas nada havia que me fizesse sair do profundo abismo dos prazeres carnais, a não ser o medo da morte e de teu juízo futuro, que jamais saiu do meu peito, através das várias doutrinas que segui.

 Discutia com meus amigos Alípio e Nebrídio, sobre o bem e o mal finais; facilmente meu juízo teria dado a palma a Epicuro, se eu não acreditasse na imortalidade da alma e do julgamento de nossos atos, coisas em que Epicuro nunca acreditou. E eu perguntava: "Se fossemos imortais, e vivêssemos em perpétuo gozo sensorial, sem temor algum de perde-lo, não seriamos felizes? Que mais poderíamos desejar?" Ignorava eu que isto era fruto duma grande miséria. Não podia, tão imerso no vício e cego como estava, imaginar a luz da virtude e uma beleza invisível aos olhos da carne, e somente visível das profundezas da alma. Na minha miséria, não indagava de que fonte provinha esse grande gosto em conversar com os amigos, por maior que fosse a abundância dos prazeres carnais, segundo a idéia que eu tinha então? Eu amava a meus amigos desinteressadamente, e também sentia que eles me amavam com o mesmo desinteresse.

 Ó caminhos tortuosos! Ai da alma temerária que, afastando-se de ti, esperava achar algo melhor! Dá voltas e mais voltas, para todos os lados, mas tudo lhe é duro, porque só tu és seu descanso. Mas eis que estás presente, e nos livras de nossos miseráveis erros, e nos pões em teu caminho, e nos consolas dizendo: "Correi, que eu vos levarei e conduzirei ao termo, e aí serei vosso sustento!