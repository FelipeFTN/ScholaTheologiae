## CAPÍTULO XIV

### Um projeto desfeito

 Éramos muitos os amigos, que aborrecíamos as mazelas da agitação da vida humana. Em nossas conversas, havíamos debatido e quase resolvido nos retirar da multidão para viver sossegadamente. Nosso projeto organizava a vida de tal sorte que tudo o que tivéssemos seria comunitário, formando de todos os patrimônios um patrimônio único. Graças à nossa amizade sincera não haveria mais a fortuna deste ou daquele, mas uma só fortuna comum.

 Seriamos cerca de dez homens os que desejávamos formar essa sociedade. Alguns de nós, muito ricos, como Romaniano, meu conterrâneo, cujos sérios cuidados de negócios o tinham trazido à corte imperial. Era muito amigo meu desde menino, e um dos que mais instavam nesse projeto, tendo sua opinião um grande peso pois sua riqueza era bem superior que a dos outros. Fora combinado que todos os anos, dois de nós, como magistrados, administrariam todo o necessário, ficando os outros em paz. Mas quando se começou a discutir se as mulheres consentiriam nesse acordo – alguns dentre nós eram casados, e outros pensavam em casar – todo o plano, tão bem construído, se desvaneceu entre nossas mãos, fez-se em pedaços e teve de ser abandonado.

 Novamente aos suspiros e gemidos, voltamos a caminhar pelos largos e batidos caminhos do século, porque em nosso coração havia mil pensamentos, mas teu conselho permanece eternamente. Na tua sabedoria te rias de nossos projetos, e preparavas o cumprimento dos teus, a fim de dar-nos alimento no tempo oportuno, abrindo tuas mãos e enchendo-nos de bênçãos.