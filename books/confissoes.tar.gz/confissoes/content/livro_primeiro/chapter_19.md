## CAPÍTULO XIX

### Mau perdedor

 À beira de tal lodaçal jazia eu, pobre criança, sendo esta a arena em que me exercitava, temendo mais cometer um barbarismo de linguagem do que cuidando de não invejar, se o cometia, aqueles que o tinham evitado.

 Digo e confesso diante de ti, meu Deus, essas misérias, que me angariavam o louvor daqueles cuja simpatia equivalia para mim a uma vida honesta, pois não via o abismo pois não via o abismo de torpeza em que tudo isso me lançara, longe dos teus olhos. A teus olhos quem era mais repelente do que eu? E eu até desagradava tais homens, enganando com infinidade de mentiras a meus criados, mestres e pais por amor dos jogos, por gosto de ver espetáculos frívolos e o desejo inquieto de os imitar.

 Também cometia furtos na despensa e na mesa de meus pais, ora impelido pela gula, ora para ter de dar aos meninos para brincar com eles, folguedos que os deleitavam tanto quanto a mim, e que eles me faziam pagar. No jogo, frequentemente, conseguia vitórias fraudulentas, vencido pelo desejo de me sobressair. Contudo, nada havia que eu quisesse mais evitar e que eu repreendesse mais atrozmente se o descobrisse em outros, que o mesmo eu fazia aos demais. Se acaso eu era o prejudicado, e o acusado ficava furioso, eu não cedia. Será esta a inocência infantil? Não, Senhor, não o é, eu to confesso, meu Deus. Porque essas mesmas coisas que se fazem com os criados e mestres por causa de nozes, bolas e passarinhos, se avultam na maioridade com os magistrados e reis por causa de dinheiro, palácios e servos, do mesmo modo que à palmatória sucedem-se maiores castigos.

 Assim, quando tu, nosso rei, disseste: Delas é o reino do céus – quiseste sem dúvida louvar na pequenez de sua estatura um símbolo de humildade.