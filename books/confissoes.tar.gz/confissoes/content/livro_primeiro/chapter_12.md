## CAPÍTULO XII 

### Ódio ao estudo 

 Nesta minha infância, na qual eu tinha menos que temer por mim do que em minha adolescência, eu não gostava dos estudos, e odiava que a eles me obrigassem. Contudo, era coagido, e me faziam grande bem. Quem não procedia bem era eu, que não estudava a não ser constrangido, pois ninguém faz bem o que faz contra a vontade, mesmo que seja bom o que faz.

 Tampouco os que obrigavam a estudar agiam corretamente; antes, todo o bem que eu recebia vinha de ti, meu Deus, porque eles não tinham outro fim ao me obrigarem a estudar senão saciar o apetite de abundante miséria e de gloria ignominiosa. Mas tu, Senhor, que tens contados os cabelos de nossa cabeça, usavas do erro de todos os que me coagiam a estudar para minha utilidade; e usavas da minha falta de vontade de estudar para meu castigo, de que certamente eu já era digno, sendo ainda tão pequeno, e tao grande pecador.

 Assim, convertias em bem o mal que eles me faziam, e dos meus pecados, me davas justa retribuição, porque é teu desígnio, e assim acontece, que toda alma desordenada seja castigo de si mesma.