# LIVRO PRIMEIRO 

## CAPÍTULO I

### Louvor e Invocação

 És grande, Senhor e infinitamente digno de ser louvado; grande é teu poder, e incomensurável tua sabedoria. E o homem, pequena parte de tua criação quer louvar-te, e precisamente o homem que, revestido de sua mortalidade, traz em si o testemunho do pecado e a prova de que resistes aos soberbos. Todavia, o homem, partícula de tua criação, deseja louvar-te. Tu mesmo que incitas ao deleite no teu louvor, porque nos fizeste para ti, e nosso coração está inquieto enquanto não encontrar em ti descanso.

 Concede, Senhor, que eu bem saiba se é mais importante invocar-te e louvar-te, ou se devo antes conhecer-te, para depois te invocar. Mas alguém te invocará antes de te conhecer? Porque, te ignorando, facilmente estará em perigo de invocar outrem. Porque, porventura, deves antes ser invocado para depois ser conhecido? Mas como invocarão aquele em que não crêem? Ou como haverão de crer que alguém lhos pregue?

 Com certeza, louvarão ao Senhor os que o buscam, porque os que o buscam o encontram e os que o encontram hão de louvá-lo.

 Que eu, Senhor, te procure invocando-te, e te invoque crendo em ti, pois me pregaram teu nome. invoca-te, Senhor, a fé que tu me deste, a fé que me inspiraste pela humanidade de teu Filho e o ministério de teu pregador.

## CAPÍTULO II

### Deus está no homem, e este em Deus

 E como invocarei meu Deus, meu Deus e meu Senhor, se ao invocá-lo o faria certamente dentro de mim? E que lugar há em mim para receber o meu Deus, por onde Deus desça a mim, o Deus que fez o céu e a terra? Senhor, haverá em mim algum espaço que te possa conter? Acaso te contêm o céu e a terra, que tu criaste, e dentro dos quais também criaste a mim? Será, talvez, pelo fato de nada do que existe sem Ti, que todas as coisas te contêm? E, assim, se existo, que motivo pode haver para Te pedir que venhas a mim, já que não existiria se em mim não habitásseis?

 Ainda não estive no inferno, mas também ali estás presente, pois, se descer ao inferno, ali estarás.

 Eu nada seria, meu Deus, nada seria em absoluto se não estivesses em mim; talvez seria melhor dizer que eu não existiria de modo algum se não estivesse em ti, de quem, por quem e em quem existem todas as coisas? Assim é, Senhor, assim é. Como, pois, posso chamar-te se já estou em ti, ou de onde hás de vir a mim, ou a que parte do céu ou da terra me hei de recolher, para que ali venha a mim o meu Deus, ele que disse: Eu encho o céu e a terra?

## CAPÍTULO III

### Onde está Deus?

 Porventura o céu e a terra te contêm, porque os enches? Ou será melhor dizer que os enches, mas que ainda resta alguma parte de ti, já que eles não te podem conter? E onde estenderás isso que sobra de ti, depois de cheios o céu e a terra? Mas será necessário que sejas contido em algum lugar, tu que conténs todas as coisas, visto que as que enches as ocupas contendo-as? Porque não são os vasos cheios de ti que te tornam estável, já que, quando se quebrarem, tu não te derramarás; e quando te derramas sobre nós, isso não o fazes porque cais, mas porque nos levantas, nem porque te dispersas, mas porque nos recolhes.

 No entanto, todas as coisas que enches, enche-as todas com todo o teu ser; ou talvez, por não te poderem conter totalmente todas as coisas, contêm apenas parte de ti? E essa parte de ti as contêm todas ao mesmo tempo, ou cada uma a sua, as maiores a maior parte, e as menores a menor parte? Mas haverá em ti partes maiores e partes menores? Acaso não estás todo em todas as partes, sem que haja coisa alguma que te contenha totalmente?

## CAPÍTULO IV

### As perfeições de Deus

 Que és, portanto, ó meu Deus? Que és, repito, senão o Senhor Deus? Ó Deus sumo, excelente, poderosíssimo, onipotentíssimo, misericordiosíssimo e justíssimo.

 Tao oculto e tão presente, formosíssimo e fortíssimo, estável e incompreensível; imutável, mudando todas as coisas; nunca novo e nunca velho; renovador de todas as coisas, conduzindo à ruína os soberbos sem que eles o saibam; sempre agindo e sempre repouso; sempre sustentando, enchendo e protegendo; sempre criando, nutrindo e aperfeiçoando, sempre buscando, ainda que nada te falte.

 Amas sem paixão; tens zelos, e estás tranqüilo; te arrependes, e não tens dor; te iras, e continuas calmo; mudas de obra, mas não de resolução; recebes o que encontras, e nunca perdeste nada; não és avaro, e exiges lucro. A ti oferecemos tudo, para que sejas nosso devedor; porém, quem terá algo que não seja teu, pois, pagas dívidas que a ninguém deves, e perdoas dívidas sem que nada percas com isso?

 E que é o que até aqui dissemos, meu Deus, minha vida, minha doçura santa, ou que poderá alguém dizer quando fala de ti? Mas ai dos que nada dizem de ti, pois, embora seu muito falar, não passam de mudos charlatães.

## CAPÍTULO V

### Súplica

 Quem me dera descansar em ti! Quem me dera que viesses a meu coração e que o embriagasses, para que eu me esqueça de minhas maldades e me abrace contigo, meu único bem! Que és para mim? Tem piedade de mim, para que eu possa falar. E que sou eu para ti, para que me ordenes amar-te e, se não o fizer, irar-te contra mim, ameaçando-me com terríveis castigos? Acaso é pequeno o castigo de não te amar? Ai de mim! Dize-me por tuas misericórdias, meu Senhor e meu Deus, que és para mim? Dize a minha alma: Eu sou a tua salvação. Que eu ouça e siga essa voz e te alcance. Não queiras esconder-me teu rosto. Morra eu para que possa vê-lo para não morrer eternamente.

 Estreita é a casa de minha alma para que venhas até ela: que seja por ti dilatada. Está em ruínas; restaura-a. Há nela nódoas que ofendem o teu olhar: confesso-o, pois eu o sei; porém, quem haverá de purificá-la? A quem clamarei senão a ti? Livra-me, Senhor, dos pecados ocultos, e perdoa a teu servo os alheios! Creio, e por isso falo. Tu o sabes, Senhor. Acaso não confessei diante de ti meus delitos contra mim, ó meu Deus? E não me perdoaste a impiedade de meu coração? Não quero contender em juízos contigo, que és a verdade, e não quero enganar-me a mim mesmo, para que não se engane a si mesma minha iniqüidade. Não quero contender em juízos contigo, porque, se dás atenção às iniqüidades, Senhor, quem, Senhor, subsistirá?

## CAPÍTULO VI

### Os primeiros anos

 Permita, porém, que eu fale em presença de tua misericórdia, a mim, terra e cinza; deixa que eu fale, porque é à tua misericórdia que falo, e não ao homem, que de mim escarnece. Talvez também tu te rias de mim, mas, voltado para mim, terás compaixão.

 E que pretendo dizer-te, Senhor, senão que ignoro de onde vim para aqui, para esta não sei se posso chamar vida mortal ou morte vital? Não o sei. Mas receberam-me os consolos de tuas misericórdias, conforme o que ouvi de meus pais carnais, de quem e em quem me formaste no tempo, pois eu de mim nada recordo. Receberam-me os consolos do leite humano, do qual nem minha mãe, nem minhas amas enchiam os seios; mas eras tu que, por meio delas, me davas aquele alimento da infância, de acordo com o seu desígnio, e segundo os tesouros dispostos por ti até no mais íntimo das coisas.

 Também por tua causa é que eu não queria mais do que me davas; por tua causa é que minhas amas queriam dar-me o que tu lhes davas, pois elas, movidas de sadio afeto, queriam darme aquilo que abundavam graças a ti, já que era um bem para elas ou delas receber aquele bem, embora realmente não fosse delas, meros instrumentos, porque de ti procedem, com certeza, todos os bens, ó Deus, e de ti, Deus meu, depende toda minha salvação.

 Tudo isto vim a saber mais tarde, quando me falaste por meio dos mesmos bens que me concedias interior e exteriormente. Porque então as únicas coisas que fazia era sugar o leite, aquietar-me com os afagos e chorar as dores de minha carne.

 Depois também comecei a rir, primeiro dormindo, depois acordado. Isto disseram de mim, e o creio, porque o mesmo acontece com outros meninos, pois eu não tenho a menor lembrança dessas coisas.

 Pouco a pouco comecei a me dar conta de onde estava, e a querer dar a conhecer meus desejos a quem os podia satisfazer, embora realmente não o pudessem, porque meus desejos estavam dentro, e eles fora; e por nenhum sentido podiam entrar em minha alma. assim, agitava os braços e dava gritos e sinais semelhantes a meus desejos, os poucos que podia e como podia, embora não fossem de fato sua expressão. Mas, se não era atendido, ou porque não me entendessem, ou porque o que desejava me fosse prejudicial, eu me indignava com os adultos, porque não me obedeciam, e sendo livres, por não quererem me servir; e deles me vingava chorando. Assim são as crianças que pude observar; e que eu também fosse assim, mais me ensinaram elas, sem o saber, do que os que me criaram, sabendo-o.

 Minha infância morreu há muito tempo, mas eu continuo vivo. Mas, dize-me, Senhor, tu que sempre vives, e em quem nada falece – porque existias antes do começo dos séculos, e antes de tudo o que há de anterior, e és Deus e Senhor de todas as coisas; e esse encontram em ti as causas de tudo o que é instável, e em ti permanecem os princípios imutáveis de tudo o que se transforma, e vivem as razões eternas de tudo o que é transitório – dize-me a mim, eu to suplico, ó meu Deus, diz-me, misericordioso, a mim que sou miserável, dize-me: porventura a minha infância sucedeu a outra idade minha, já morta? Será esta aquela que vivi no ventre de minha mãe? Porque também desta me revelaram algumas coisas, e eu mesmo já vi mulheres grávidas.

 E antes desse tempo, minha doçura e meu Deus, que era eu? Fui alguém, ou era parte de alguma coisa? Dize-mo, porque não tenho quem me responda, nem meu pai, nem minha mãe, nem a experiência dos outros, nem minha memória. Acaso te ris de mim, porque desejo saber estas coisas, e me mandas que te louve e te confesse pelo que conheci de ti?

 Eu te confesso, Senhor dos céus e da terra, louvando-te por meus princípios e por minha infância, de que não tenho memória, mas que, por tua graça, o homem pode conjectura de si pelos outros, crendo em muitas coisas, ainda que confiado na autoridade de humildes mulheres. Então eu já existia, já vivia de verdade; e, já no fim da infância procurava sinais com que pudesse exprimir aos outros as coisas que sentia. Com efeito, de onde poderia vir semelhante criatura, senão de ti, Senhor? Acaso alguém pode ser artífice de si mesmo? Porventura existirá algum outro manancial por onde corra até nos o ser e a vida, diferente da que nos dais, Senhor, tu em quem ser e vida não são coisas distintas, porque és o Sumo Ser e a Suprema Vida? Com efeito, és sumo, e não te mudas, nem caminha para ti o dia de hoje, apesar de caminhar por ti, apesar de estarem em ti com certeza todas estas coisas, que não teriam caminho por onde passar se não as contivesses. E porque teus anos não fenecem, teus anos são um perpétuo hoje. Oh! Quantos dias nossos e de nossos pais já passaram por este teu hoje, e dele receberam sua duração, e de alguma maneira existiram, e quantos passarão ainda, e receberão seu modo, e seu ser? Mas tu és sempre o mesmo, e todas as coisas de amanhã e do futuro, e todas as coisas de ontem e do passado, nesse hoje as fazes, nesse hoje as fizeste.

 Que importa que alguém não entenda essas coisas? Que este alguém se ria, e diga: que é isto? Que se ria assim, e que prefira encontrar-te sem indagação do que, indagando, não te encontrar.

## CAPÍTULO VII

### Os pecados da primeira infância

 Escuta-me, ó meu Deus! Ai dos pecados dos homens! E quem isto te diz é um homem, e tu te compadeces dele porque o criaste, e não foste autor do pecado que nele existe.

 Quem me poderá lembrar o pecado da infância, já que ninguém está diante de ti limpo de pecado, nem mesmo a criança cuja vida conta um só dia sobre a terra? Quem mo recordará? Acaso alguma criança pequena de hoje, em quem vejo a imagem do que não recordo de mim? E em que eu poderia pecar nesse tempo? Acaso por desejar o peito da nutriz, chorando? Se agora eu suspirasse com a mesma avidez, não pelo seio materno, mas pelo alimento próprio da minha idade, seria justamente escarnecido e censurado. Logo, era então digno de repreensão o meu proceder; mas como não podia entender a censura, nem o costume nem a razão permitiam que eu fosse repreendido. Prova está que, ao crescermos, extirpamos e afastamos de nós essa sofreguidão; e jamais vi homem sensato que, para limpar uma coisa viciosa, prive-a do que tem de bom.

 Acaso, mesmo para aquela idade, era bom pedir chorando o que não se me podia dar sem dano, indignar-me acremente com as pessoas livres que não se submetiam, assim como as pessoas respeitáveis, e até com meus próprios pais, e com muitos outros que, mais sensatos, não davam atenção aos sinais de meus caprichos, enquanto eu me esforçava por agredi-los com meus golpes, quanto podia, por não obedecerem às minhas ordens, que me teriam sido danosas? Daqui se segue que o que é inocente nas crianças é a debilidade dos membros infantis, e não a alma.

 Certa vez, vi e observei um menino invejoso. Ainda não falava, e já olhava pálido e com rosto amargurado para o irmãozinho colaço. Quem não terá testemunhado isso? Dizem que as mães e as amas tentam esconjurar este defeito com não sei que práticas. Mas se poderá considerar inocência o não suportar que se partilhe a fonte do leite, que mana copiosa e abundante, com quem está tão necessitado do mesmo socorro, e que sustenta a vida apenas com esse alimento? Mas costuma-se tolerar indulgentemente essas faltas, não porque sejam insignificantes, mas porque espera-se que desapareçam com os anos. Por isso, sendo tais coisas perdoáveis em um menino, quando se acham em um adulto, mal as podemos suportar.

 Assim, pois, meu Senhor e meu Deus, tu que me deste a vida e corpo, o qual dotaste, como vemos, de sentidos e proviste de membros, adornando-o de beleza e de instintos naturais, com os quais pudesse defender sua integridade e conservação, tu me mandas que te louve por esses dons e te confesse e cante teu nome altíssimo. Serias Deus onipotente e bom ainda que só tivesses criado apenas estas coisas, que nenhum outro pode fazer senão tu, ó Unidade, origem de todas as variedades, ó Beleza, que dás forma a todas as coisas, e com tua lei as ordenas!

 Tenho vergonha, Senhor, de ter de somar à vida terrena que vivo aquela idade que não recordo ter vivido, na qual acredito pelo testemunho de outros, por vê-lo assim em outras crianças, embora essa conjectura mereça toda a fé. As trevas em que está envolto meu esquecimento a seu respeito assemelham-se à vida que vivi no ventre de minha mãe.

 Assim, se fui concebido em iniqüidade, e se em pecado me alimentou minha mãe, onde, suplico-te, meu Deus, onde, Senhor, eu, teu servo, onde e quando fui inocente? Mas eis que silencio sobre esse tempo. Para que ocupar-se dele, se dele já não conservo nenhuma lembrança?

## CAPÍTULO VIII

### As primeiras palavras

 Acaso não foi caminhando da infância até aqui que cheguei à puerícia? Ou melhor, esta veio a mim e suplantou à infância sem que esta fosse embora, pois, para onde poderia ir? Contudo deixou de existir, porque eu já não era um bebezinho que não falava, mas um menino que aprendia a falar. Disso me recordo; mas como aprendi a falar, só mais tarde é que vim a perceber. Não mo ensinaram os mais velhos apresentando-me as palavras com certa ordem e método, como logo depois fizeram com as letras; mas foi por mim mesmo, com o entendimento que me deste, meu Deus, quando queria manifestar meus sentimentos com gemidos, gritinhos, e vários movimentos do corpo, a fim de que atendessem meus desejos; e também ao ver que não podia exteriorizar tudo o que queria, nem ser compreendido por todos aqueles a quem me dirigia. Assim, pois, quando chamavam alguma coisa pelo nome, eu a retinha na memória e, ao se pronunciar de novo a tal palavra, moviam o corpo na direção do objeto, eu entendia e notava que aquele objeto era o denominado com a palavra que pronunciavam, porque assim o chamavam quando o desejavam mostrar.

 Que esta fosse sua intenção, era-me revelado pelos movimentos do corpo, que são como uma linguagem universal, feita com a expressão rosto, a atitude dos membros e o tom da voz, que indicam os afetos da alma para pedir, reter, rejeitar ou evitar alguma coisa. Deste modo, das palavras usadas nas e colocadas em várias frases e ouvidas repetidas vezes, ia eu aos poucos notando o significado e, domada a dificuldade de minha boca, comecei a dar a entender minhas vontades por meio delas.

 Foi assim que comecei a comunicar meus desejos às pessoas entre as quais vivia, e entrei a fazer parte do tempestuoso mundo da sociedade, dependendo da autoridade de meus pais e obedecendo às pessoas mais velhas.

## CAPÍTULO IX

### Estudos e jogos

 Ó meu Deus, meu Deus! Que de misérias e enganos não experimentei então, quando se me propunha, em criança, como norma de bem viver, obedecer os mestres que me instigavam a brilhar neste mundo, e me ilustrar nas artes da língua, fiel instrumento para obter honras humanas e satisfazer a cobiça! Mudaram-me à escola, para que aprendesse as letras, nas quais eu, miserável, desconhecia o que havia de útil. Contudo, se era preguiçoso para aprendê-las, era fustigado, num sistema louvado pelos mais velhos; muitos deles, que levavam esse gênero de vida antes de nós, nos traçaram caminhos tão dolorosos pelos quais éramos obrigados a caminhar, multiplicando assim o trabalho e a dor aos filhos de Adão.

 Mas, por sorte, encontrei homens que te invocavam, Senhor, e com eles aprendi a te sentir, quanto possível, como a um Ser grande que podia escutar-nos e vir em nosso auxílio, embora sem a percepção dos sentidos. Ainda menino, pois, comecei a invocar-te como refúgio e amparo e, para te invocar, desatei os nós de minha língua; e, embora pequeno, te rogava já com grande fervor para que não me açoitassem na escola. E quando não me escutavas, o que servia para meu proveito os mestres, assim como meus próprios pais, que certamente não desejavam o meu mal, riam-se daquele castigo, que então era para mim grave suplício.

 Porventura, Senhor, haverá alguma alma tão grande, unida a ti com tão ardente afeto, pois isto também pode ser produzido pela estultice – repito, uma alma que alcance tal grandeza de ânimo que despreze os cavaletes e garfos de ferro, e os demais instrumentos de martírio – para fugir dos quais se te dirigem súplicas de todas as partes do mundo? Haverá uma alma que assim os despreze – rindo-se dos que têm deles tanto horror – como se riam nossos pais dos tormentos que éramos castigados por nossos mestres quando meninos? Porque, na verdade, não os temíamos menos, nem te rogávamos com menor fervor para que nos livrasses deles.

 Contudo, pecávamos por negligencia escrevendo ou lendo, estudando menos do que nos era exigido; e não era por falta de memória ou de inteligência, que para aquela idade, Senhor, me deste de modo suficiente, senão porque eu gostava de brincar, embora os que nos castigavam não fizessem outra coisa. Mas os jogos dos mais velhos chamavam-se negócios, enquanto que os dos meninos eram por eles castigados, sem que ninguém se compadecesse de uns e de outros, ou melhor, de ambos. Um juiz sensato poderia aprovar os castigos que eu, menino, recebia porque jogava bola, e porque com este jogo atrasava o aprendizado das letras, com as quais, adulto haveria de jogar menos inocentemente?

 Acaso fazia outra coisa naquele que me castigava? Se nalguma questiúncula era vencido por algum colega seu, não era mais atormentado pela cólera e pela inveja do que eu, quando uma partida de bola era vencido por meu companheiro?

## CAPÍTULO X

### Amor ao jogo 

 Contudo, Senhor meu, ordenador e criador da natureza, mas do pecado somente ordenador, eu pecava; pecava desobedecendo as ordens de meus pais e mestres, uma vez que podia no futuro fazer bom uso das letras que desejavam me ensinar, qualquer que fosse sua intenção.

 E não era desobediente para me ocupar de coisas melhores, mas por amor ao jogo; buscava nos combates orgulhosas vitórias; deleitava-me com histórias frívolas, com as quais incentivava sempre mais minha curiosidade. Igualmente curiosos, meus olhos se abriam sempre mais para os jogos e espetáculos dos adultos, jogos que dão tao grande dignidade a quem os oferece, que quase todos desejam as mesmas dignidades para seus filhos. Contudo, gostam de os castigar se com tais espetáculos fogem dos estudos, por meio dos quais desejam que eles venham um dia a oferecer espetáculos semelhantes. Senhor, olha misericordiosamente para essas coisas, e livra-nos delas a nós que já te invocamos; mas livra também aos que ainda não te invocam, a fim de que te invoquem, e sejam igualmente libertados.

## CAPÍTULO XI

### O batismo diferido

 Ainda menino, ouvi falar da vida eterna, que nos está prometida pela humildade de Jesus, nosso Senhor, que desceu até nossa soberba; e fui marcado com o sinal da cruz, sendo-me dado saborear de seu sal logo que saí do ventre de minha mãe, que sempre esperou muito em ti.

 Tu viste, Senhor, que numa ocasião, ainda menino, atacou-me repentinamente um dor de estômago que me abrasava, e que me aproximou da morte. Tu viste também, meu Deus, pois já me tinhas sob tua guarda, com que fervor de espírito e com que fé pedi à piedade de minha mãe, e da mãe de todos nós, tua Igreja, o batismo de teu Cristo, meu Deus e Senhor. Perturbou-se minha mãe carnal, pois que me criava com mais amor em seu casto coração em tua fé para a vida eterna e, solícita, já havia cuidado de que me iniciasse e purificasse com os sacramentos da salvação, confessando-te, ó meu Senhor Jesus, em remissão de meus pecados, quando, de repente, comecei a melhorar. Em vista disso, diferiu-se minha purificação, considerando que seria impossível, se eu vivesse, que não me tornasse a manchar; pois a culpa dos pecados cometidos depois do batismo é muito maior e mais perigosa.

 Nesta época eu já tinha fé verdadeira, juntamente com minha mãe e com todos da casa, à exceção de meu pai, que, porém, não pôde vencer em mim a ascendência da piedade materna, para que deixasse de acreditar em Cristo, tal como ele não acreditava; minha mãe, solícita, cuidava de que tu, meu Deus, fosses mais pai para mim do que ele, e a ajudavas a triunfar do marido, a quem servia melhor, porque nele te servia a ti e a tuas ordens.

 Mas, meu Deus, suplico-te que me mostres, se te apraz, por que motivo se diferiu então meu batismo; se foi ou não para meu bem que me soltaram as rédeas do pecado. Por que razão ainda hoje se diz de uns e de outros, como ouvimos em muitos lugares: "Deixe que faça o que quiser, porque ainda não está batizado" – embora não digamos da saúde do corpo: "Deixe que receba ainda mais feridas, porque ainda não está curado?"

 Quanto melhor teria sido para mim receber logo a saúde, e que meus cuidados e os dos meus fossem empregados em conservar intacta debaixo da tua proteção a saúde da minha alma, que me havias concedido! Melhor fora, certamente; porém, como minha mãe, sem dúvida, já previa quantas e quão grandes ondas de tentações me ameaçariam depois da meninice, preferiu expor-me a elas como terra grosseira que depois receberia forma, do que expor-me já como imagem tua.

## CAPÍTULO XII 

### Ódio ao estudo 

 Nesta minha infância, na qual eu tinha menos que temer por mim do que em minha adolescência, eu não gostava dos estudos, e odiava que a eles me obrigassem. Contudo, era coagido, e me faziam grande bem. Quem não procedia bem era eu, que não estudava a não ser constrangido, pois ninguém faz bem o que faz contra a vontade, mesmo que seja bom o que faz.

 Tampouco os que obrigavam a estudar agiam corretamente; antes, todo o bem que eu recebia vinha de ti, meu Deus, porque eles não tinham outro fim ao me obrigarem a estudar senão saciar o apetite de abundante miséria e de gloria ignominiosa. Mas tu, Senhor, que tens contados os cabelos de nossa cabeça, usavas do erro de todos os que me coagiam a estudar para minha utilidade; e usavas da minha falta de vontade de estudar para meu castigo, de que certamente eu já era digno, sendo ainda tão pequeno, e tao grande pecador.

 Assim, convertias em bem o mal que eles me faziam, e dos meus pecados, me davas justa retribuição, porque é teu desígnio, e assim acontece, que toda alma desordenada seja castigo de si mesma.

## CAPÍTULO XIII

### Gosto pelo latim

 Porque odiava eu as letras gregas, que me ensinavam quando eu era criança? Não o sei, e nem agora o posso explicar. Em compensação, as letras latinas me apaixonavam, não as ensinadas pelos professores primários, mas a que é explicada pelos chamados gramáticos, porque aquelas primeiras, com as quais se aprende a ler, a escrever e a contar, não me foram menos pesadas e insuportáveis que as gregas. Mas donde podia proceder essa aversão, senão do pecado e da vaidade da vida, porque eu era carne e vento que caminha e não volta?

 Aquelas primeiras letras, pelas quais podia, como ainda faço, chegar e ler tudo o que há escrito e a escrever tudo o que quero, eram melhores e mais úteis que aquelas outras nas quais me obrigavam a decorar os erros de um tal Enéias, esquecido dos meus, e a chorar a morte de Dido, que se suicidou por amor, enquanto isso, eu, miserabilíssimo, suportava a minha própria morte com olhos enxutos, morrendo para ti, ó meu Deus, minha vida!

 Na verdade, que pode haver de mais miserável do que um infeliz que não se compadece de si mesmo e que, chorando a morte de Dido por amor de Enéias, não chora sua própria morte por falta de amor a ti, ó Deus, luz de meu coração, pão interior de minha alma, virtude fecundante de meu pensamento? Não te amava; prevaricava longe de ti, e ouvia de todas as partes: "Muito bem! Muito bem!" – porque a amizade deste mundo é adultério contra ti; e se aclamam a alguém dizendo: "Muito bem! Muito bem!" – é para que este não se envergonhe de ser assim. Eu não chorava estas faltas, chorava a morte de Dido "que se suicidou com a espada", eu procurava as últimas de tuas criaturas, abandonando-te a ti, como terra que eu era, atraída pela terra. Se então me proibissem a leitura de tais coisas, me afligiriam por não ler aquilo que me comovia até a dor. Não obstante, semelhante loucura é considerada como coisa mais nobre e proveitosa que as letras pelas quais aprendemos a ler e a escrever.

 Mas agora, meu Deus, grite em minha alma tua verdade, e diga: Não é assim, não é assim, antes, aquela primeira instrução é absolutamente superior; pois eu preferiria esquecer todas as aventuras de Enéias, e outras histórias semelhantes, do que o saber ler e escrever. Sei que nas escolas dos gramáticos pendem cortinas às portas; porém, servem menos para velar o segredo que para encobrir o erro.

 Não gritem contra mim aqueles mestres a quem já não temo, enquanto confesso a ti os desejos de minha alma, e aborreço dos meus maus caminhos, a fim de amar os teus. Não gritem contra mim os comerciantes da gramática, pois, se eu os interrogar sobre se é verdade que Enéias veio uma vez a Cartago, como afirma o poeta, os néscios responderão que não sabem, e os sábios negarão o fato. Porém, se lhes perguntar como se escreve o nome de Enéias, todos os que estudaram me responderão a mesma coisa, de acordo com a convenção com que os homens fixaram o valor das letras do alfabeto.

 Do mesmo modo, se lhes perguntar o que seria mais prejudicial para a vida humana: esquecer o ler e o escrever, ou todas as ficções dos poetas, quem não vê o que logo responderia aquele que não estivesse de tudo esquecido de ti? Pequei, pois, em minha infância, ao preferir vãos aos proveitosos, ou para dizer melhor, ao amar àqueles e ao odiar a estes; era para mim uma cantiga odiosa aquele "um e um, dois; dois e dois, quatro; enquanto considerava espetáculo encantador a história do cavalo de madeira cheio de guerreiros e o incêndio de Tróia, "e até a sombra de Creuza".

## CAPÍTULO XIV

### Aversão ao grego

 Por que então aborrecia eu a literatura grega na qual se cantam tais coisas? Porque também Homero é mui habilidoso em tecer essas historietas, dulcíssimo na sua frivolidade, embora para mim, menino, fosse bem amargo. Creio que o mesmo ocorra com Virgilio para os meninos gregos obrigados a estudá-lo, como a mim com relação a Homero. Era a dificuldade de ter de aprender totalmente uma língua estranha que, como fel, aspergia de amargura todas as doçuras das fábulas gregas.

 Eu ainda não conhecia nenhuma palavra daquela língua, e já me obrigavam com veemência, com crueldades e terríveis castigos, a aprendê-la. Na verdade, eu, ainda criança, também não conhecia nenhuma palavra de latim; contudo, com um pouco de atenção, o aprendi entre o carinho das amas, os gracejos dos que se riam e as alegrias dos que brincavam, sem medo algum nem tormento. Eu o aprendi, sem a pressão dos castigos, impelido unicamente por meu coração desejoso de dar à luz seus sentimentos, e o único caminho para isso era aprender algumas palavras, não dos que as ensinavam, mas do que falavam, em cujos ouvidos ia eu depositando quanto sentia.

 Por aqui se evidencia claramente que, para instruir, tem mais eficácia e curiosidade livre do que a necessidade inspirada pelo medo. Contudo, os excessos da curiosidade encontram nessa violência um freio segundo tuas leis, ó Deus; que desde as palmatórias dos mestres até os tormentos dos mártires sabem dosar suas salutares amarguras, que nos reconduzem a ti do seio do pernicioso deleite que de ti nos apartara.

## CAPÍTULO XV

### Oração

 Ouvi, Senhor, minha oração, para que não desfaleça minha alma sob a tua lei, nem me canse em confessar tuas misericórdias, com as quais me arrancaste de meus perversos caminhos; que tua doçura sobrepuje todas as doçuras que segui, e assim te ame fortissimamente, e abrace tua mão com toda minha alma, e me livres de toda a tentação até o fim dos meus dias. Pois é, Senhor, meu rei e meu Deus, e a ti consagro quanto falo, escrevo, leio e conto, pois quando aprendia aquelas futilidades, tu eras o que me davas a verdadeira disciplina, e já me perdoaste os pecados de deleite cometidos naquelas vaidades. Muitas palavras úteis aprendi nelas, é verdade; porém, estas também se podem aprender em estudos sérios, e este é o caminho seguro pelo qual deveriam encaminhar as crianças.

## CAPÍTULO XVI

### O mal da mitologia

 Ai de ti, torrente dos hábitos humanos! Quem há que te resista? Quando te secarás? Até quando irás arrastar os filhos de Eva a esse mar imenso e tenebroso, que apenas logram passar os que embarcam sobre o lenho da cruz? Acaso não foi em ti que li a fábula de Júpiter que troveja e adultera? É verdade que não podia fazer tais coisas ao mesmo tempo, mas assim se representou para autorizar a imitação de um verdadeiro adultério com o encantamento de um falso trovão. Contudo, qual é o professor de pênula capaz de ouvir com paciência a um homem nascido do mesmo pó que clama e diz: "Homero imaginava essas ficções e atribuía aos deuses os vícios humanos; porém, eu preferiria que atribuísse a nós as qualidades divinas". Com mais verdade se diria que Homero imaginou tudo isso, atribuindo qualidades divinas a homens corrompidos, para que os vícios não fossem considerados como tais, e para que todo aquele que os cometesse parecesse que imitava a deuses celestes, e não a homens corrompidos.

 E contudo, ó torrente infernal, em ti se precipitam os filhos dos homens, com o dinheiro gasto para aprender tais coisas. E consideram acontecimento importante representá-lo, publicamente no Foro, à vista das leis que concedem aos mestres um prêmio, além de seus salários particulares.

 E ferindo os rochedos de tuas margens, gritas dizendo: "Aqui se aprendem as palavras; aqui se adquire a eloqüência, tao necessária para persuadir e explicar os pensamentos; não poderíamos pois aprender as palavras: chuva de ouro, regaço, templo celeste, logro e outras mais, escritas em determinada passagem, se Terêncio não nos apresentasse um jovem perdido que se propõe a imitar a luxúria de Júpiter? Contemplava ele uma pintura mural "na qual se representava o mesmo Júpiter no momento em que, segundo dizem, descia como chuva de ouro sobre o regaço de Dânae, para lograr assim à pobre mulher".

E vede como se excitava à luxúria a vista de tão celestial mestre:

- Mas que deus fez isto? – diz.

- Nada menos que aquele que faz retumbar a abóbada do céu com enorme trovão!

- E eu, homenzinho, não haveria de fazer o mesmo?

- Fi-lo, sim, e com muito gosto.

 De modo algum se aprendem com semelhante torpeza aquelas palavras; antes, essas palavras levam mais atrevidamente a cometer a mesma devassidão. Não incrimino as palavras, que são como vasos seletos e preciosos, mas condeno o vinho do erro que mestres ébrios nos davam a beber nelas e, se não o bebêssemos, éramos açoitados, sem que pudéssemos apelar para juiz mais sóbrio.

 E, não obstante, meu Deus, cuja presença me protege desta lembrança, confesso que aprendi estas coisas com gosto e que, miserável, nelas me comprazi, sendo por isso chamado menino de grandes esperanças.

## CAPÍTULO XVII

### Êxitos escolares

 Permite-me, Senhor, que diga também algo de meu talento, dádiva tua, e dos desatinos em que o empregava. Propunha-se-me como desafio – coisa mui preocupante para minha alma, tanto pelo louvor ou descrédito, como por medo dos açoites – que repetisse as palavras de Juno, irada e ressentida por não podem "afastar da Itália ao rei dos troianos", embora jamais tenha sabido que tivessem sido pronunciadas por Juno. Mas obrigavam-nos a errar seguindo os passos das ficções poéticas, e a repetir em prosa o que o poeta havia dito em verso. Era mais elogiado aquele que, conforme a dignidade da pessoa representada, soubesse pintar com mais vivacidade e semelhança, e revestir com palavras mais apropriadas seus afetos de ira ou de dor.

 Mas qual o proveito disso – ó vida verdadeira, meu Deus – de que me servia ser aplaudido por minha declamação mais que todos os meus coetâneos e condiscípulos? Não era tudo aquilo fumo e vento? Acaso não havia outra coisa em que exercitar meu talento e minha língua? Teus louvores, Senhor, teus louvores, consignados nas Escrituras, poderiam soerguer a frágil planta de meu coração, e eu não teria sido arrebatado pela vaidade de vãs quimeras, presa imunda das aves. Com efeito, há diversas maneiras de oferecer sacrifício aos anjos rebeldes.

## CAPÍTULO XVIII

### Leis gramaticais, lei de Deus

 Mas, por que admirar-se que eu me deixasse arrastar pelas vaidades e me afastar de ti, meu Deus, se me propunham como exemplos para imitar a uns homens que se, ao contar alguma boa ação, deslizassem nalgum barbarismo ou solecismo cobriam-me de críticas e, pelo contrário, que eram elogiados por narrar suas torpezas com palavras castiças e apropriadas, de modo eloqüente e elegante, e que os inchavam de vaidade?

 Tu vês, Senhor, estas coisas, e te calas compassivo, paciente, cheio de misericórdia e verdade. Mas te calarás para sempre? Arranca, pois, agora deste espantoso abismo a alma que te busca sedenta de teus deleites, e que te diz de coração: Busquei, Senhor, teu rosto; teu rosto, Senhor, buscarei ainda. Longe está de teu rosto quem anda ocupado com afetos tenebrosos, porque não é com os pés carnais, nem cobrindo distâncias que nos aproximamos ou nos afastamos de ti. Porventura aquele teu filho menor procurou cavalos, ou carros, ou naves, ou voou com asas invisíveis, ou viajou a pé para alcançar aquela região longínqua onde dissipou o que lhes havia dado, ó Pai, meigo ao lhe entregar a substância, e mais carinhoso ainda ao recebê-lo andrajoso? Assim, pois, viver nas paixões da luxúria, é o mesmo que viver em paixões tenebrosas, é viver longe de teu rosto.

 Olha, meu Senhor e meu Deus, é vê paciente, como costumas ver, de que modo diligente os filhos dos homens observam as regras de ortografia recebidas dos primeiros mestres, e desprezam as leis eternas de salvação perpétua recebidas de ti; de tal modo que, se alguns dos que sabem ou ensinam as regras antigas dos sons pronunciasse a palavra homo, sem aspirar a primeira letra, desagradaria mais aos homens do que se, contra teus preceitos, odiasse a outro homem, sendo este homem.

 Como se o homem pudesse ter inimigo mais pernicioso que o ódio com que se irrita contra si mesmo, ou como se pudesse causar a outrem maior dano, perseguindo-o, do que causa a seu próprio coração odiando! Com certeza, não nos é mais íntima a ciência das letras do que a consciência, que manda não fazer a outrem o que não queremos que não nos façam.

 Oh! Como és misericordioso, tu, que habitando silencioso nos céus, Deus grande e único, espalhas com lei infatigável cegueiras vingadoras sobre as paixões ilícitas! Quando o homem, aspirando à fama de eloqüente, ataca a seu inimigo com ódio feroz diante do juiz, rodeado de grande multidão de homens, toma todo o cuidado para que, por um lapsus linguae, não se lhe escape um inter ominibus, sem aspirar o h, sem cuidar que com o furor de seu ódio se tire um homem de entre os homens.

## CAPÍTULO XIX

### Mau perdedor

 À beira de tal lodaçal jazia eu, pobre criança, sendo esta a arena em que me exercitava, temendo mais cometer um barbarismo de linguagem do que cuidando de não invejar, se o cometia, aqueles que o tinham evitado.

 Digo e confesso diante de ti, meu Deus, essas misérias, que me angariavam o louvor daqueles cuja simpatia equivalia para mim a uma vida honesta, pois não via o abismo pois não via o abismo de torpeza em que tudo isso me lançara, longe dos teus olhos. A teus olhos quem era mais repelente do que eu? E eu até desagradava tais homens, enganando com infinidade de mentiras a meus criados, mestres e pais por amor dos jogos, por gosto de ver espetáculos frívolos e o desejo inquieto de os imitar.

 Também cometia furtos na despensa e na mesa de meus pais, ora impelido pela gula, ora para ter de dar aos meninos para brincar com eles, folguedos que os deleitavam tanto quanto a mim, e que eles me faziam pagar. No jogo, frequentemente, conseguia vitórias fraudulentas, vencido pelo desejo de me sobressair. Contudo, nada havia que eu quisesse mais evitar e que eu repreendesse mais atrozmente se o descobrisse em outros, que o mesmo eu fazia aos demais. Se acaso eu era o prejudicado, e o acusado ficava furioso, eu não cedia. Será esta a inocência infantil? Não, Senhor, não o é, eu to confesso, meu Deus. Porque essas mesmas coisas que se fazem com os criados e mestres por causa de nozes, bolas e passarinhos, se avultam na maioridade com os magistrados e reis por causa de dinheiro, palácios e servos, do mesmo modo que à palmatória sucedem-se maiores castigos.

 Assim, quando tu, nosso rei, disseste: Delas é o reino do céus – quiseste sem dúvida louvar na pequenez de sua estatura um símbolo de humildade.