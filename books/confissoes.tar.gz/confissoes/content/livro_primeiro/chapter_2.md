## CAPÍTULO II

### Deus está no homem, e este em Deus

 E como invocarei meu Deus, meu Deus e meu Senhor, se ao invocá-lo o faria certamente dentro de mim? E que lugar há em mim para receber o meu Deus, por onde Deus desça a mim, o Deus que fez o céu e a terra? Senhor, haverá em mim algum espaço que te possa conter? Acaso te contêm o céu e a terra, que tu criaste, e dentro dos quais também criaste a mim? Será, talvez, pelo fato de nada do que existe sem Ti, que todas as coisas te contêm? E, assim, se existo, que motivo pode haver para Te pedir que venhas a mim, já que não existiria se em mim não habitásseis?

 Ainda não estive no inferno, mas também ali estás presente, pois, se descer ao inferno, ali estarás.

 Eu nada seria, meu Deus, nada seria em absoluto se não estivesses em mim; talvez seria melhor dizer que eu não existiria de modo algum se não estivesse em ti, de quem, por quem e em quem existem todas as coisas? Assim é, Senhor, assim é. Como, pois, posso chamar-te se já estou em ti, ou de onde hás de vir a mim, ou a que parte do céu ou da terra me hei de recolher, para que ali venha a mim o meu Deus, ele que disse: Eu encho o céu e a terra?