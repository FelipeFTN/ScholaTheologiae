## CAPÍTULO X

### Amor ao jogo 

 Contudo, Senhor meu, ordenador e criador da natureza, mas do pecado somente ordenador, eu pecava; pecava desobedecendo as ordens de meus pais e mestres, uma vez que podia no futuro fazer bom uso das letras que desejavam me ensinar, qualquer que fosse sua intenção.

 E não era desobediente para me ocupar de coisas melhores, mas por amor ao jogo; buscava nos combates orgulhosas vitórias; deleitava-me com histórias frívolas, com as quais incentivava sempre mais minha curiosidade. Igualmente curiosos, meus olhos se abriam sempre mais para os jogos e espetáculos dos adultos, jogos que dão tao grande dignidade a quem os oferece, que quase todos desejam as mesmas dignidades para seus filhos. Contudo, gostam de os castigar se com tais espetáculos fogem dos estudos, por meio dos quais desejam que eles venham um dia a oferecer espetáculos semelhantes. Senhor, olha misericordiosamente para essas coisas, e livra-nos delas a nós que já te invocamos; mas livra também aos que ainda não te invocam, a fim de que te invoquem, e sejam igualmente libertados.