## CAPÍTULO XVI

### O mal da mitologia

 Ai de ti, torrente dos hábitos humanos! Quem há que te resista? Quando te secarás? Até quando irás arrastar os filhos de Eva a esse mar imenso e tenebroso, que apenas logram passar os que embarcam sobre o lenho da cruz? Acaso não foi em ti que li a fábula de Júpiter que troveja e adultera? É verdade que não podia fazer tais coisas ao mesmo tempo, mas assim se representou para autorizar a imitação de um verdadeiro adultério com o encantamento de um falso trovão. Contudo, qual é o professor de pênula capaz de ouvir com paciência a um homem nascido do mesmo pó que clama e diz: "Homero imaginava essas ficções e atribuía aos deuses os vícios humanos; porém, eu preferiria que atribuísse a nós as qualidades divinas". Com mais verdade se diria que Homero imaginou tudo isso, atribuindo qualidades divinas a homens corrompidos, para que os vícios não fossem considerados como tais, e para que todo aquele que os cometesse parecesse que imitava a deuses celestes, e não a homens corrompidos.

 E contudo, ó torrente infernal, em ti se precipitam os filhos dos homens, com o dinheiro gasto para aprender tais coisas. E consideram acontecimento importante representá-lo, publicamente no Foro, à vista das leis que concedem aos mestres um prêmio, além de seus salários particulares.

 E ferindo os rochedos de tuas margens, gritas dizendo: "Aqui se aprendem as palavras; aqui se adquire a eloqüência, tao necessária para persuadir e explicar os pensamentos; não poderíamos pois aprender as palavras: chuva de ouro, regaço, templo celeste, logro e outras mais, escritas em determinada passagem, se Terêncio não nos apresentasse um jovem perdido que se propõe a imitar a luxúria de Júpiter? Contemplava ele uma pintura mural "na qual se representava o mesmo Júpiter no momento em que, segundo dizem, descia como chuva de ouro sobre o regaço de Dânae, para lograr assim à pobre mulher".

E vede como se excitava à luxúria a vista de tão celestial mestre:

- Mas que deus fez isto? – diz.

- Nada menos que aquele que faz retumbar a abóbada do céu com enorme trovão!

- E eu, homenzinho, não haveria de fazer o mesmo?

- Fi-lo, sim, e com muito gosto.

 De modo algum se aprendem com semelhante torpeza aquelas palavras; antes, essas palavras levam mais atrevidamente a cometer a mesma devassidão. Não incrimino as palavras, que são como vasos seletos e preciosos, mas condeno o vinho do erro que mestres ébrios nos davam a beber nelas e, se não o bebêssemos, éramos açoitados, sem que pudéssemos apelar para juiz mais sóbrio.

 E, não obstante, meu Deus, cuja presença me protege desta lembrança, confesso que aprendi estas coisas com gosto e que, miserável, nelas me comprazi, sendo por isso chamado menino de grandes esperanças.