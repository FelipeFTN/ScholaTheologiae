## CAPÍTULO III

### Onde está Deus?

 Porventura o céu e a terra te contêm, porque os enches? Ou será melhor dizer que os enches, mas que ainda resta alguma parte de ti, já que eles não te podem conter? E onde estenderás isso que sobra de ti, depois de cheios o céu e a terra? Mas será necessário que sejas contido em algum lugar, tu que conténs todas as coisas, visto que as que enches as ocupas contendo-as? Porque não são os vasos cheios de ti que te tornam estável, já que, quando se quebrarem, tu não te derramarás; e quando te derramas sobre nós, isso não o fazes porque cais, mas porque nos levantas, nem porque te dispersas, mas porque nos recolhes.

 No entanto, todas as coisas que enches, enche-as todas com todo o teu ser; ou talvez, por não te poderem conter totalmente todas as coisas, contêm apenas parte de ti? E essa parte de ti as contêm todas ao mesmo tempo, ou cada uma a sua, as maiores a maior parte, e as menores a menor parte? Mas haverá em ti partes maiores e partes menores? Acaso não estás todo em todas as partes, sem que haja coisa alguma que te contenha totalmente?