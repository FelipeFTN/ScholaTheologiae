## CAPÍTULO IV

### As perfeições de Deus

 Que és, portanto, ó meu Deus? Que és, repito, senão o Senhor Deus? Ó Deus sumo, excelente, poderosíssimo, onipotentíssimo, misericordiosíssimo e justíssimo.

 Tao oculto e tão presente, formosíssimo e fortíssimo, estável e incompreensível; imutável, mudando todas as coisas; nunca novo e nunca velho; renovador de todas as coisas, conduzindo à ruína os soberbos sem que eles o saibam; sempre agindo e sempre repouso; sempre sustentando, enchendo e protegendo; sempre criando, nutrindo e aperfeiçoando, sempre buscando, ainda que nada te falte.

 Amas sem paixão; tens zelos, e estás tranqüilo; te arrependes, e não tens dor; te iras, e continuas calmo; mudas de obra, mas não de resolução; recebes o que encontras, e nunca perdeste nada; não és avaro, e exiges lucro. A ti oferecemos tudo, para que sejas nosso devedor; porém, quem terá algo que não seja teu, pois, pagas dívidas que a ninguém deves, e perdoas dívidas sem que nada percas com isso?

 E que é o que até aqui dissemos, meu Deus, minha vida, minha doçura santa, ou que poderá alguém dizer quando fala de ti? Mas ai dos que nada dizem de ti, pois, embora seu muito falar, não passam de mudos charlatães.