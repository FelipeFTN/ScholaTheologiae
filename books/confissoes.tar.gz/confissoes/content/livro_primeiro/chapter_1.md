## CAPÍTULO I

### Louvor e Invocação

 És grande, Senhor e infinitamente digno de ser louvado; grande é teu poder, e incomensurável tua sabedoria. E o homem, pequena parte de tua criação quer louvar-te, e precisamente o homem que, revestido de sua mortalidade, traz em si o testemunho do pecado e a prova de que resistes aos soberbos. Todavia, o homem, partícula de tua criação, deseja louvar-te. Tu mesmo que incitas ao deleite no teu louvor, porque nos fizeste para ti, e nosso coração está inquieto enquanto não encontrar em ti descanso.

 Concede, Senhor, que eu bem saiba se é mais importante invocar-te e louvar-te, ou se devo antes conhecer-te, para depois te invocar. Mas alguém te invocará antes de te conhecer? Porque, te ignorando, facilmente estará em perigo de invocar outrem. Porque, porventura, deves antes ser invocado para depois ser conhecido? Mas como invocarão aquele em que não crêem? Ou como haverão de crer que alguém lhos pregue?

 Com certeza, louvarão ao Senhor os que o buscam, porque os que o buscam o encontram e os que o encontram hão de louvá-lo.

 Que eu, Senhor, te procure invocando-te, e te invoque crendo em ti, pois me pregaram teu nome. invoca-te, Senhor, a fé que tu me deste, a fé que me inspiraste pela humanidade de teu Filho e o ministério de teu pregador.