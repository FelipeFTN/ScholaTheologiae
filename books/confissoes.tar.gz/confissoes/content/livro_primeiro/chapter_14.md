## CAPÍTULO XIV

### Aversão ao grego

 Por que então aborrecia eu a literatura grega na qual se cantam tais coisas? Porque também Homero é mui habilidoso em tecer essas historietas, dulcíssimo na sua frivolidade, embora para mim, menino, fosse bem amargo. Creio que o mesmo ocorra com Virgilio para os meninos gregos obrigados a estudá-lo, como a mim com relação a Homero. Era a dificuldade de ter de aprender totalmente uma língua estranha que, como fel, aspergia de amargura todas as doçuras das fábulas gregas.

 Eu ainda não conhecia nenhuma palavra daquela língua, e já me obrigavam com veemência, com crueldades e terríveis castigos, a aprendê-la. Na verdade, eu, ainda criança, também não conhecia nenhuma palavra de latim; contudo, com um pouco de atenção, o aprendi entre o carinho das amas, os gracejos dos que se riam e as alegrias dos que brincavam, sem medo algum nem tormento. Eu o aprendi, sem a pressão dos castigos, impelido unicamente por meu coração desejoso de dar à luz seus sentimentos, e o único caminho para isso era aprender algumas palavras, não dos que as ensinavam, mas do que falavam, em cujos ouvidos ia eu depositando quanto sentia.

 Por aqui se evidencia claramente que, para instruir, tem mais eficácia e curiosidade livre do que a necessidade inspirada pelo medo. Contudo, os excessos da curiosidade encontram nessa violência um freio segundo tuas leis, ó Deus; que desde as palmatórias dos mestres até os tormentos dos mártires sabem dosar suas salutares amarguras, que nos reconduzem a ti do seio do pernicioso deleite que de ti nos apartara.