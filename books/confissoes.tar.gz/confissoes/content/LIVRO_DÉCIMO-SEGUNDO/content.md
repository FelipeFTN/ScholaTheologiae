### O Gênesis e seu autor

 Assim, quando alguém me diz: "O pensamento de Moisés é o meu" – e outro diz: "Não, ele pensou como eu" – parece-me mais consoante ao espírito religioso dizer: "Por que não admitir ambos os pontos de vista, se ambos são verdadeiros?" – E se alguém descobrir um terceiro, um quarto sentido, e outros mais, desde que sejam verdadeiros, por que não acreditar que Moisés viu todos eles, ele por cujo intermédio o Deus único adaptou as Escrituras à inteligência da multidão, que deveria descobrir-lhe significados diversos e verdadeiros?

 Por mim, digo-o sem hesitar e do fundo do coração: se, investido da mais alta autoridade, tivesse algo a escrever, preferiria fazê-lo de modo que minhas palavras proclamassem tudo o que cada um pudesse conceber de verdadeiro sobre isso, em vez de propor um significado único e claro que excluísse todos os demais, cuja falsidade não me pudesse ofender. E também não quero, meu Deus, ser tão temerário ao ponto de acreditar que esse grande homem não mereceu de ti essa graça.

 Moisés, redigindo esses textos, pensou, concebeu todas as verdades que já fomos capazes de encontrar, e também as que não o pudemos, mas que podem ser descobertas.

## CAPÍTULO XXXII