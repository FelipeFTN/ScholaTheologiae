## CAPÍTULO XXIII

### A opinião de Agostinho

 Ouço e medito essas opiniões na medida de meu fraco entendimento, que confesso a Deus, embora ele bem o conheça. Vejo que se podem originar duas espécies de opiniões sobre um testemunho de interprete fidedigno. Uma é reativa à veracidade das coisas, e outra à intenção daquele que as enuncia. Procurar conhecer a verdade sobre a criação é uma coisa; procurar saber o que Moisés, grande servo de tua lei, quis o que o leitor ou ouvinte entendessem de suas palavras, é outra.

 Quanto à primeira opinião, longe de mim todos que têm como verdades os seus erros! Quanto à segunda, longe de mim todos os que julgam falsidade o que Moisés disse. Possa eu unir-me em ti, alegrar-me em ti, Senhor, com aqueles que se alimentam de tua verdade na imensidão da caridade. Aproximemo-nos juntos das palavras de teu Livro, procurando tua vontade nas intenções de teu servo, a cuja pena as revelaste.