## CAPÍTULO XXI

### A terra invisível

 O mesmo ocorre em relação à interpretação das palavras que se seguem. Entre essas, todas verdadeiras, cada um escolhe uma. Este diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, essa massa corpórea, que Deus fez, era a matéria ainda sem forma, sem ordem, sem luz, das coisas corpóreas.

 Outro diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, esse conjunto que chamamos de terra e céu era a matéria ainda informe e tenebrosa, da qual seriam tirados o céu e a terra corpóreos, com tudo o que nossos sentidos físicos neles percebem.

 Outro diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto e´, esse conjunto que chamamos de céu e de terra era a matéria ainda informe e tenebrosa, donde seriam feitos o céu inteligível, noutros termos, o céu do céu, e a terra, isto é, toda natureza corpórea, nela incluindo o céu material, ou seja, a matéria de toda criatura visível e invisível.

 Outro diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, não quis a Escritura chamar à massa informe de céu e de terra, porque ela já existia; é dessa massa que ela chamou de terra invisível, caótica, abismo de trevas, é dela, que Deus criou o céu e a terra, isto é, a criatura espiritual e a corporal.

 E outro ainda: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, já existia uma matéria informe, da qual a Escritura diz que Deus criou o céu e a terra, toda a massa corporal do mundo, dividido em duas grandes partes, uma superior, outra inferior, com todas as criaturas nelas existentes e que nos são familiares.