## CAPÍTULO IX

### A criação do tempo

 Por isso, o Espírito que instruiu teu servo, quando relata que no princípio criaste o céu e a terra, cala-se sobre o tempo, guarda silêncio sobre os dias. De fato, o céu do céu, que fizeste no começo, é de alguma maneira uma criatura racional que, mesmo sem ser coeterna contigo, ó Trindade, participava todavia de tua eternidade. A doçura de te contemplar beatamente a mantém imóvel e unida a ti sem movimento, e desde sua criação escapa às vicissitudes fugazes do tempo. Porém, esta massa informe, esta terra invisível, este caos, tu não o enumeraste entre os dias; de fato, onde não há forma nem ordem, nada vem, nada passa e, portanto não pode haver nem dias, nem sucessão de espaços temporais.