# LIVRO DÉCIMO-SEGUNDO

## CAPÍTULO I

### Prece

 Inquieto está meu coração, Senhor, quando, na miséria de minha vida é atingido pelas palavras de tua Escritura Sagrada. Por isso, geralmente, a abundância de palavras é testemunho da pobreza da inteligência humana. A busca usa mais palavras que a descoberta; é maior o pedir que o obter; a mão que bate cansa-se mais do que a mão que recebe. Mas nós temos tua promessa: quem a destruirá? Se Deus está conosco, quem será contra nós? Pedi, e recebereis; procurai e encontrareis; batei, e abrir-se-vos-á. Porque todo o que pede recebe, todo o que procura encontra, e a todo o que bate se lhe abrirá.

São promessas tuas. E quem temerá ser enganado, quando a promessa vem da Verdade?

## CAPÍTULO II

### O céu do céu

 Que a humildade de minha língua confesse à tua grandeza que criaste o céu e a terra; este céu que vejo, esta terra que piso, e de onde tiraste a terra que trago em mim. sim, criaste tudo isto.

 Mas, Senhor, onde está o céu de que nos falou a voz do salmista: "O céu do céu pertence ao Senhor, mas ele deu a terra aos filhos dos homens?" – Onde está esse céu que não vemos, e diante do qual tudo o que vemos é apenas terra?

 De fato, todo este mundo material, cuja base é a terra, embora não seja inteiramente belo em toda parte, recebeu até em seus últimos elementos, uma aparência atraente. Mas, comparado com esse céu do céu, o céu de nossa terra também não passa de terra. Por isso, não é absurdo chamar de terra esses dois grandes corpos visíveis, se os compararmos a esse céu misterioso que pertence ao Senhor, e não aos filhos dos homens.

## CAPÍTULO III

### As trevas sobre o abismo

 Mas esta terra era invisível e informe, era um profundo abismo acima do qual não pairava nenhuma luz, pois não tinha nenhuma forma. Por isso inspiraste estas palavras: "As trevas cobriam o abismo". – Mas que são trevas, senão ausência da luz? De fato, se então existisse, onde estaria a luz senão sobre a terra, para iluminá-la? Mas como a luz ainda não existia, o que era a presença das trevas, senão a ausência da luz? As trevas reinavam sobre o abismo porque a luz não existia, do mesmo modo que onde não há ruído reina o silêncio. E que significa reinar o silêncio, senão falta de som?

 Não ensinaste, Senhor, à alma que a ti se confessa? Não me ensinaste, Senhor, que antes de receber de ti forma e figura esta matéria informe, não existia nada, nem cor, nem figura, nem corpo, nem espírito? Não era um nada absoluto, mas massa informe, sem figura alguma.

## CAPÍTULO IV

### A matéria informe

 Que nome darei a esta matéria, como sugerir sua idéia às inteligências mais curtas, senão usando um termo de uso corrente? O que se pode encontrar no mundo que seja mais parecido com essa ausência total de forma, que a terra e o abismo? Colocados no mais baixo grau da criação, eles não têm a beleza dos corpos que no alto brilham de luz fulgurante.

 Por que, então, não aceitar que essa matéria informe, que criaste sem beleza para com ela moldar um mundo cheio de beleza, fosse comodamente designada aos homens pelos termos de terra invisível e informe?

## CAPÍTULO V

### Sua natureza

 Assim, quando o pensamento indaga o que nossos sentidos podem colher a respeito dessa matéria, responde a si mesmo: "Não é nem forma inteligível, como a vida, como a justiça, porque é a matéria corpórea, nem uma forma sensível, porque nada há que se possa ver ou perceber no que é invisível e sem forma". – Quando o pensamento humano fala desse modo, procura conhecê-la ignorando-a, ou ignorá-la conhecendo-a?

## CAPÍTULO VI

### Em que consiste

 Senhor, se pela boca e pela pena devo confessar-te o que me ensinaste sobre essa matéria, eu direi que outrora ouvi falar, sem nada compreender, a respeito desse nome por pessoas que também não entendiam. Tentei imaginá-la sob as formas mais diversas, e não o consegui. Meu espírito revolvia confusamente formas feias e horríveis, mas enfim sempre formas. Chamava de informe essa matéria, não porque a imaginasse sem forma, mas por tê-las tão estranhas e bizarras que, se a visse, afastaria meus sentidos e confundiria minha fraqueza de homem.

 Por isso, o que eu concebia era informe, não por ausência de qualquer forma, mas por comparação com formas mais belas. A reta razão me persuadia; se eu quisesse conceber algo absolutamente informe, a suprimir nele todo resquício de forma, mas eu não conseguia; pareciame bem mais fácil negar a existência do que estava privado de toda forma, do que conceber um ser a meio termo entre a forma e o nada, e que não fosse nem forma, nem nada, um ser informe, um quase nada.

 Então, minha inteligência deixou de inquirir minha imaginação, cheia de imagens de formas corpóreas, que ela variava e mudada a seu talante. Fixei a atenção nos próprios corpos, analisei mais profundamente essa mutabilidade pela qual eles cessam de ser o que eram e começam a ser o que não eram. Suspeitei que essa transição de uma forma para outra se fazia por meio de algo informe, e não do nada absoluto.

 Mas meu interesse era saber, e não apenas supor; e se minha voz e minha pena te confessassem em detalhes as soluções deste problema que me inspiraste, qual de meus leitores teria paciência para me entender? Contudo, meu coração não deixará de te honrar com cânticos de louvor por essas inspirações, por aquilo que não têm palavras capazes de exprimir.

 É a própria mutabilidade das coisas que é susceptível de assumir todas as formas em que se transfiguram as coisas mutáveis. E o que é essa mutabilidade? É espírito? Será talvez corpo? Seria uma espécie de espírito ou de corpo? Se pudéssemos dizer: um nada que é algo, ou o que é e não é, eu a chamaria assim. No entanto, era necessário que ela existisse de alguma maneira, para tomar essas formas visíveis e complexas.

## CAPÍTULO VII

### A criação do nada

 Mas de onde essa matéria tirava seu ser, senão de ti, por quem existe toda e qualquer coisa? Quanto mais difere de ti uma coisa, mais longe de ti está – e não se trata de distância espacial.

 Portanto, és tu, Senhor que não mudas ao sabor das circunstâncias, mas que és sempre o mesmo, o mesmo e o mesmo, santo e santo e santo, Senhor, Deus Todo-Poderoso, és tu, Senhor, que no princípio, que vem de ti, em tua Sabedoria, nascida de tua substância, fizeste algo do nada. Criaste o céu e a terra, e isso não com tua substância, pois nesse caso, tua criação seria igual a teu Filho unigênito e, por isso, iguais a ti mesmo. E não seria justo que o que não é da tua substância, fosse igual a ti.

 Mas fora de ti nada existia com que pudesses fazer o céu e a terra, ó Trindade una, Unidade trina. Por isso criaste do nada o céu e a terra; duas realidades, uma imensa e outra pequena. Porque és Todo-Poderoso e bom, e só podes criar coisas boas: o grande céu e a pequena terra.

 Fora de ti nada havia, e desse nada fizeste o céu e a terra, tuas duas obras: uma próxima de ti, a outra próxima do nada. Uma que tem acima de si apenas a ti mesmo, e outra que nada tem inferior a ela.

## CAPÍTULO VIII

### A terra invisível

 Mas o céu do céu pertence a ti, Senhor; a terra, que deste aos filhos dos homens para que a vissem e tocassem, não era tal como agora e vemos e tocamos. Era invisível e informe: um abismo sobre o qual não havia luz. As trevas se estendiam sobre o abismo – isto é: mais profundas que o abismo. Esse abismo das águas, agora visíveis, tem até em suas profundezas uma luminosidade, perceptível aos peixes e aos animais que se arrastam no fundo. Mas tudo isso era quase o nada, sendo ainda completamente informe; porém já era um ser apto a receber uma forma.

 Senhor, criaste o mundo de uma matéria sem forma; do nada fizeste este quase nada de onde tiraste as grandes coisas que admiramos, nós, os filhos dos homens. Porque este céu corpóreo é de fato admirável, este firmamento que separa uma água de outra, que criaste no segundo dia, depois da luz, dizendo: "Faça-se – e assim se fez". Chamaste a este firmamento de céu: o céu desta terra e deste mar que criaste no terceiro dia, dando forma visível à matéria informe, criado por ti antes de todos os dias.

 Já havias criado outro céu antes de haver dia; mas era o céu do céu, porque no princípio criaste o céu e a terra. Quanto a esta mesma terra, nada mais era que matéria informe, sendo invisível, caótica e as trevas reinando sobre o abismo. É desta terra invisível, caótica, desta massa informe, deste quase nada, que formaste todas as coisas de que é formado e não formado este mundo mutável, domínio da transformação, que torna possíveis a percepção e a medida do tempo. Porque o tempo é feito da mudança das coisas, de variações e transformações das formas, cuja matéria é esta terra invisível, de que falei acima.

## CAPÍTULO IX

### A criação do tempo

 Por isso, o Espírito que instruiu teu servo, quando relata que no princípio criaste o céu e a terra, cala-se sobre o tempo, guarda silêncio sobre os dias. De fato, o céu do céu, que fizeste no começo, é de alguma maneira uma criatura racional que, mesmo sem ser coeterna contigo, ó Trindade, participava todavia de tua eternidade. A doçura de te contemplar beatamente a mantém imóvel e unida a ti sem movimento, e desde sua criação escapa às vicissitudes fugazes do tempo. Porém, esta massa informe, esta terra invisível, este caos, tu não o enumeraste entre os dias; de fato, onde não há forma nem ordem, nada vem, nada passa e, portanto não pode haver nem dias, nem sucessão de espaços temporais.

## CAPÍTULO X

### Invocação à verdade

 Ó Verdade, luz de meu coração, faze com que se calem as minhas trevas. Deixei-me cair nelas e fiquei às escuras; mas, mesmo do fundo desse abismo, eu te amei ardentemente. Andei, errante, mas lembrei de ti. Ouvi tua voz atrás de mim, que me exortava a que voltasse; mas dificilmente podia escutá-la, por causa do tumulto de minha alma. e agora, eis que, ardente e anelante, volto à tua fonte. Que ninguém mo impeça; beberei de sua água, e assim viverei. Que não seja eu minha própria vida! Vivi mal por minha culpa, e fui a causa de minha morte. Em ti eu revivo! Fala-me, ensina-me. Creio em teus livros, e tuas palavras encerram profundos mistérios.

## CAPÍTULO XI

### As criaturas e o criador

 Já me disseste, Senhor, com voz forte ao ouvido de minha alma, que és eterno, e que só tu possuis a imortalidade, porque não mudas nem de forma, nem de movimento; tua vontade não varia conforme o tempo, pois a vontade mutável não é imortal. Esta verdade me é clara em tua presença. Peço-te que ela se torne para mim cada vez mais clara, e sob tuas asas eu me mantenha atento a esta evidência.

 Também disseste, Senhor, com voz forte ao ouvido de minha alma, que todas as naturezas, todas as substâncias que não são o que és, mas que existem, tu as criaste; que só o nada não provém de ti, assim como o movimento de uma vontade que se afasta de ti, Ser supremo. Enfim, que nenhum pecado te causa dano, nem perturba a ordem de teu império, superior ou inferior. Essa verdade é clara para mim em tua presença. Peço-te que se torne para mim cada vez mais clara, e que sob tuas asas eu me mantenha atento a esta evidência.

 Também disseste, Senhor, com voz forte ao ouvido de minha alma, que essa criatura, que tem em ti seu único deleite, não te é coeterna; que goza de ti em união casta e duradoura, sem nunca trair em parte alguma sua natureza mutável; que, se conserva sempre em tua presença e unida a ti com todo seu amor, não tem de esperar futuro, nem que recordar passado, imutável pois com o tempo e o vir a ser. Feliz criatura, se existe, por participar de tua felicidade, feliz de ser perenemente habitada e iluminada por ti! Nada encontro que melhor se possa chamar de céu de céu que pertence ao Senhor, que a esta habitação de tua divindade, que contempla tuas delícias sem que nada a afaste para outras partes. Puro espírito, intimamente ligado por um elo de paz com esses santos, espíritos, cidadãos de tua cidade, situada no céu e acima do nosso céu.

 Diante disso, possa a alma, cuja peregrinação afastou de ti, compreender se já tem sede de ti, se seu pranto se tornou seu pão, quando todos os dias lhe dizem: Onde está teu Deus? – se ela deseja apenas habitar em tua morada todos os dias de sua vida. E que é sua vida, senão tu? Que são teus dias, senão tua eternidade, como teus anos que não passam, porque és sempre o mesmo? Por isso, digo, faça compreender à alma, se possível, como tua eternidade transcende todos os temos. Tua morada, que nunca se afastou de ti, embora não te tendo coeterna, graças à sua incessante e ininterrupta união contigo, não padece de vicissitudes do tempo. Essa verdade é clara para mim em tua presença. Peço-te que se torne para mim cada vez mais clara, e que sob tuas asas eu me mantenha atento a esta evidência.

 Vejo, de fato, não sei que matéria informe nas transformações das coisas últimas e ínfimas. Mas quem dirá, a não ser o insensato, cujo espírito vagueia entre quimeras, à mercê de seus fantasmas, quem, salvo este, ousaria afirmar que, se toda forma fosse destruída, abolida, restando apenas a matéria informe, graças à qual as coisas se transformam e passam de uma forma para outra, ela poderia produzir as vicissitudes do tempo? Não, tal hipótese é absolutamente impossível, pois sem variedade de movimentos não há tempo; e não há variedade onde não há forma.

## CAPÍTULO XII

### A criação e a eternidade

 Bem consideradas estas coisas, por graça tua, meu Deus, e como me incitasse a bater, e como me abres quando bato, encontro duas criações tuas não afetadas pelo tempo, embora nenhuma delas te seja coeterna. Uma, que criaste tão perfeita que jamais deixa de te contemplar, que não sofre nenhuma mudança, embora de natureza mutável, e goza de tua eternidade e de tua imutabilidade. Outra, informe, a ponto de lhe ser impossível passar de uma forma para outra, quer no movimento, quer no repouso, e, portanto, incapaz de estar sujeito ao tempo. Mas tu não a deixaste informe pois, antes de qualquer dia, fizeste no principio o céu e a terra, as duas obras de que falava.

 Mas a terra era invisível e informe, e as trevas reinavam sobre o abismo. Por essas palavras, a Escritura sugere a idéia de algo informe, para ensinar aos poucos aos espíritos que não podem conceber que a falta absoluta de forma não se confunde com o nada. É dessa massa informe que deveria ser criado um segundo céu, uma terra visível, ordenada, a água cristalina, e enfim tudo o que foi feito na criação, de acordo com a tradição das Escrituras, em dias sucessivos. E essa obra é tal que, devido à mudanças regulares de seus movimentos e formas, está sujeita às vicissitudes do tempo.

## CAPÍTULO XIII

### O céu e a terra em Gênesis

 "No princípio criou Deus o céu e a terra. A terra era invisível e informe, e as trevas se estendiam sobre o abismo." Ouço estas palavras, meu Deus, e não encontrando menção do dia em que criaste essas coisas, concluo dessa omissão que se trata do céu do céu, do céu intelectual, onde a inteligência conhece simultaneamente e não por partes; não por enigma, ou como um espelho, mas por inteiro, em plena luz, face a face; conhece não ora isto, ora aquilo, mas, como disse, simultaneamente, sem a seqüência temporal. Concluo também que se trata da terra invisível, informe, estranha às vicissitudes do tempo, que ora causam isto, ora aquilo, pois onde não há forma não pode haver isto ou aquilo.

 Dessas realidades, uma de forma acabada desde o início, a outra absolutamente informe, o céu, isto é: o céu do céu, e a terra, isto é: terra invisível e informe, é bem a propósito delas que tua Escritura diz, sem mencionar o dia: "No princípio criou Deus o céu e a terra". E acrescenta imediatamente de que terra se trata. E, indicando que no segundo dia foi criado o firmamento, que foi chamado de céu, dá a entender também de que céu falara antes, sem precisar o dia.

## CAPÍTULO XIV

### A profundidade das Escrituras

 Admirável profundidade das tuas palavras! Sua aparência nos acaricia, como se acariciam as crianças! Sim, admirável profundidade, meu Deus, admirável profundidade! O meditá-las causa um arrepio sagrado, tremor de respeito, estremecimento de amor. Odeio com veemência seus inimigos. Oh! Se pudesses fazê-los morrer sob teu gládio de dois gumes, para que não tivessem mais inimigos! Desejaria que eles morressem para si mesmos, e que vivessem só para ti.

 Mas há outros que não censuram mas, pelo contrário, exaltam o livro de Gênesis, e que dizem: "Não é isto que quis dizer por essas palavras o Espírito de Deus, que as inspirou a teu servo Moisés. Não, o que ele quis dizer não é o que dizes, mas o que nós dizemos" – Eis, ó Deus de todos nós, o que eu lhes respondo: sê nosso árbitro.

## CAPÍTULO XV

### O que dizem seus inimigos

 Ousareis apontar como falso o que, com voz clara, a Verdade disse ao ouvido de minha alma sobre a verdadeira eternidade do Criador: ou seja, que sua substância não varia no tempo, e que sua vontade se confunde com sua substância? E que por isso ele não quer ora isto, ora aquilo, mas quer o que sempre quis, simultaneamente e para sempre. Sua vontade não se exerce repetidas vezes, não se propõe ora esta, ora aquela finalidade, não quer o que antes não queria, nem deixa de querer o que antes queria, uma vez que tal vontade seria mutável, e o que é mutável não é eterno; ora, nosso Deus é eterno.

 Tereis por falazes as palavras da Verdade faladas ao ouvido de minha alma: que a espera das coisas futuras se torna contemplação, quando presentes, e que depois se transforma em memória, quando passadas? Que todo pensamento que varia assim é mutável, e que nada do que é mutável é eterno? Ora, nosso Deus é eterno. E, reunindo e condensando estas verdades, deduzo que meu Deus, o Deus eterno, não criou o mundo por um novo ato de volição, e que sua ciência não admite nada que seja transitório.

 Que respondeis, então, meus contraditores? Será isso falso? – Não, dizem eles. – Mas então? Será que erro afirmar que toda criatura que tem forma, que toda matéria susceptível de têla recebe seu ser somente daquele que é Bondade soberana, porque ele é Ente supremo? – Também não o negamos. – Então, que negais? Negais talvez que haja uma criatura sublime, unida por um casto amor ao Deus verdadeiro e eterno, sem lhe ser coeterna, que dele não se separa nem se desvia para as várias vicissitudes do tempo, mas, pelo contrário, repousa apenas em sua contemplação? Com efeito, te ama tanto quanto pedes, ó Deus, e mostras a ela tua face e a sacias, e ela jamais se afasta de ti, nem rumo a sim mesma. Ela é a morada de Deus, não terrena, e nem formada de substância do céu material, habitáculo espiritual que participa de tua eternidade, imaculada por toda a eternidade. Tu a fundaste pelos séculos dos séculos; estabeleceste uma ordem, que não passará jamais. Contudo, essa lei não é coeterna, porque teve princípio, foi criada.

 Não encontramos o tempo antes dessa criação, porque a sabedoria foi a primeira de todas as tuas criações. E é claro que não me refiro à Sabedoria da qual és Pai, ó nosso Deus, e que te é perfeitamente igual e coeterna, por quem todas as coisas foram criadas, e que é o princípio em que criaste o céu e a terra; refiro-me à sabedoria criada, dessa essência intelectual que, pela contemplação da luz, também é luz; a esta, embora criada, também chamamos de sabedoria. E assim como a luz que ilumina difere da luz refletida, a sabedoria criada difere da sabedoria incriada; e a justiça justificante difere da justiça nascida da justificação. Nós fomos também chamados de tua justiça. Porque um de teus servos disse: "Para que, em Cristo, nos tornemos a justiça de Deus". – Há portanto, uma sabedoria criada antes de todas as coisas, e ela foi criada como espírito racional e inteligente, que habita tua cidade santa, nossa mãe, que está no alto, livre e eterna nos céus – e em que céus, senão aos céus dos céus, que te louvam, esse céu que pertence ao Senhor? – Se não encontramos o tempo antes dessa sabedoria, é porque ela precede à criação do tempo, tendo sido criada primeiro, mas antes dela há a eternidade de seu Criador, de quem recebeu sua origem, e não do tempo, pois este ainda não existia, mas pela sua condição de criatura criada.

 Ela procede pois, de ti, nosso Deus, embora seja de essência absolutamente diversa da tua. Não encontramos nenhum tempo, não apenas antes dela, mas nela própria, porque ela é capaz de contemplar sempre tua face sem jamais se apartar de ti, sendo incólume às mudanças e às variações. Contudo, há nela certa mutabilidade que poderia torná-la tenebrosa e gélida, não fosse o grande amor que a une a ti e que brilha como meridiana luz e calor.

 Ó morada luminosa e pura! Amei tua beleza e o lugar onde mora a glória de meu Senhor, teu criador e possuidor. Por ti eu suspiro durante meu exílio! Peço àquele que te criou que me possua também em ti, pois também me criou. Errei como ovelha desgarrada, mas espero ser reconduzido a ti nos ombros de meu pastor, teu arquiteto.

 Que me respondeis a isto, meus contraditores, vós que, também considerais Moisés um servo piedoso de Deus, e seus livros como oráculos do Espírito Santo? Não será esta a casa de Deus que, sem lhe ser coeterna, é contudo, á sua maneira, eterna nos céus? Em vão buscais aí as vicissitudes do tempo, pois não as encontrareis, uma vez que ela transcende toda extensão, toda volubilidade do tempo, e sua felicidade é estar intimamente unida a Deus para sempre.

– Assim é – dizem eles.

 Mas então, qual das verdades que meu coração proclamou diante de Deus, quando escutava em meu íntimo a voz que canta sal glória, podeis apontar como falsa? O que disse sobre matéria informe, na qual não podia haver ordem por carecer de forma? Mas onde não havia ordem não podia haver vicissitude de tempo; mas esse quase nada, enquanto não era o nada absoluto, provinha certamente daquele de onde nasce tudo o que, de algum modo, existe.

– Tampouco negamos isto – dizem eles.

## CAPÍTULO XVI

### Outros adversários das Escrituras

 Quero discutir diante de ti apenas com os que reconhecem por verdadeiras as afirmações que tua verdade revelou à minha inteligência. Os que o negam, que ladrem quanto quiserem, até ficar roucos. Tentarei persuadi-los a que se acalmem, e dêem acesso em seus corações à tua palavra. Se não o quiserem e me repelirem, peço-te, meu Deus, que não te cales, não te afastes de mim. fala com verdade em meu coração, porque só tu podes falar assim. E eu os deixarei fora, soprando o pó e levantando terra contra os próprios olhos. Retirar-me-ei em mim mesmo, levantando a ti cânticos de amor, soluçando altos gemidos durante meu exílio, lembrando-me de Jerusalém, voltando para ela meu coração – Jerusalém, minha pátria e minha mãe – e para ti, que reinas sobre ela, seu pai, sua luz, seu tutor, seu esposo, suas castas e grandes delícias, sua firme alegria, enfim, todos seus bens inefáveis, porque és o único, soberano e verdadeiro Bem. Não me apartarei de ti até que reúnas todas as partes dispersas e deformadas do meu ser na paz dessa mãe muito amada, onde estão as primícias de meu espírito, e de onde me vêm todas as certezas, e nela me reformes e confirmes por toda a eternidade, ó meu Deus, minha misericórdia.

 Àqueles que, sem negar essas verdades, respeitando tua Escritura Sagrada, obra do piedoso Moisés, e reconhecendo nela, conosco, a mais alta autoridade a seguir, e contudo nos opõem alguma objeções, dirijo estas palavras: "Tu, que és nosso Deus, serás árbitro entre minhas confissões e suas objeções".

## CAPÍTULO XVII

### Opiniões diversas sobre o céu e a terra

 Eles dizem: "Sem dúvida, isso é verdade, mas não era isso que Moisés queria exprimir quando, inspirado pelo Espírito Santo, escreveu: "No princípio criou Deus e céu e a terra" – Pela palavra céu, ele não quis significar essa criatura espiritual ou intelectual, que contempla eternamente a face de Deus; e pela palavra terra, uma matéria informe. – Que quis dizer então? – O que nós afirmamos – respondem – isso é o que Moisés quis dizer, e o que expressou naquelas palavras. – E que é que afirmais? – Pelas palavras céu e terra quis significar, em primeiro lugar, globalmente e de forma concisa, todo o mundo visível, para em seguida pormenorizar, enumerando os dias, ponto por ponto, esse conjunto que aprouve ao Espírito Santo designar com uma expressão global. O povo rude e carnal ao qual falava era constituído de homens tais que julgou conveniente dar-lhes a conhecer apenas as obras visíveis de Deus".

 Quanto a esta terra invisível e informe, a este abismo de trevas, com que, durante seis dias, foram sucessivamente criadas e ordenadas todas as coisas visíveis que são conhecidas de todos, eles concordam comigo em que se pode entender com isso, sem erro, essa matéria informe de que falei.

 Algum outro dirá, talvez, que a realidade invisível e visível não foi chamada impropriamente de céu e terra, e portanto, que o universo criado por Deus na sabedoria, isto é, no princípio, está compreendido sob esses dois termos. Porém as coisas não foram feitas da substância de Deus, mas do nada, e não se confundem com Deus, e nelas existe o princípio da mutabilidade, quer permaneçam como morada eterna de Deus, quer mudando-se como a alma e o corpo do homem. Por isso a matéria comum a todas as coisas invisíveis e visíveis, matéria ainda informe, mas susceptível de forma, e de onde se fariam o céu e a terra – em outras palavras, a criação invisível e visível – mas uma e outra tendo recebido forma, foi designada por essas expressões de terra invisível e informe, e de trevas reinando sobre o abismo. Com a seguinte distinção: por terra invisível e informe deve-se entender a matéria corpórea antes de ser qualificada pela forma; e por trevas reinando sobre o abismo, a matéria espiritual antes da restrição de sua, digamos, imoderada fluidez, e antes de ser iluminada pela sabedoria.

 Poderia alguém afirmar, se quisesse: Esses termos céu e terra não significam realidades perfeitas e acabadas, lá onde lemos: No princípio Deus criou o céu e a terra – mas um esboço ainda informe, uma matéria passível de receber forma e servir para a criação; nela já existiam, como que um embrião, sem distinção de formas e de qualidades, essas criaturas, uma espiritual, e outra material que, ordenadas como estão agora, são chamadas de céu e terra.

## CAPÍTULO XVIII

### Outras interpretações

 Ouço e considero todas essas teorias, mas não quero discutir por questões de palavras, o que não serve para nada, senão para a confusão dos ouvintes. Pelo contrário, a lei é boa para a edificação se dela se faz uso legítimo, porque sua finalidade é a caridade que nasce de um coração puro, de uma boa consciência e de uma fé não fingida. Nosso Mestre sabe quais dos dois preceitos em que resumiu toda a lei e os profetas. A mim, que observo com zelo tais preceitos, ó meu Deus, luz de meus olhos na escuridão, que me importa que possa que possa encontrar sentidos diferentes para essas palavras, se todos são verdadeiros? Que me interessa, digo eu, que outros compreendam o texto de Moisés de modo diferente do meu? Nós todos que o lemos procuramos indagar e compreender o pensamento do autor. E como o julgamos verídico, não ousamos admitir que ele pusesse dizer o que sabemos ou o que consideramos falso.

 Assim, nos esforços que fazemos para compreender, na Escritura Sagrada, a idéia que o escritor quis transmitir, onde está o mal se o leitor interpreta o sentido que tu, Luz de todas as inteligências sinceras, lhe fazes parecer verdadeiro, embora talvez não tenha sido este o pensamento do autor? E considerando que ele, pensando de outra maneira, só pensou verdades?

## CAPÍTULO XIX

### A verdade

 A verdade, Senhor é que criaste o céu e a terra. A verdade é que o princípio é tua Sabedoria, em que criaste todas as coisas. É também verdade que este mundo visível se compõe de duas grandes partes, o céu e a terra, síntese de todas as realidades criadas. É ainda verdade que tudo o que é mutável sugere a nosso pensamento a idéia de algo informe, susceptível de tomar forma, de mudar e de se transformar.

 A verdade é que um ser tão intimamente unido a uma forma mutável que, embora sujeito em si a mudanças, nunca se transforma, não está sujeito ao tempo. A verdade é que a massa sem forma, que é quase o nada, não pode conhecer as vicissitudes do tempo. A verdade é que a matéria que constitui uma coisa, se assim podemos falar, toma o nome dessa coisa, e portanto, podemos chamar de céu e de terra a essa massa informe com a qual foram feitos o céu e a terra. A verdade é que, de tudo o que recebeu forma, nada se aproxima mais do informe que a terra e o abismo. A verdade é que não apenas tudo o que foi criado e formado, mas ainda tudo o que possa ser criado se origina de ti, tu que és o autor de tudo que existe. A verdade é que tudo o que é formado a partir do informe, primeiro é informe, e depois recebe forma.

## CAPÍTULO XX

### O princípio e suas interpretações

 Todas essas verdades, das quais não duvidam os que de ti receberam a graça de ver com os olhos da alma, e que crêem firmemente que teu servo Moisés falou em espírito de verdade, há quem dê esta interpretação: "No princípio Deus criou o céu e a terra" – isto é, Deus criou, em seu Verbo, que lhe é coeterno, o mundo racional e sensível, ou espiritual e corporal. Outro diz: "No princípio Deus criou o céu e a terra" – isto é, Deus criou em seu Verbo, que lhe é coeterno, toda a massa do mundo corpóreo, com tudo o que contém de realidades, manifestamente conhecidas. Um terceiro diz: "No princípio Deus criou o céu e a terra" – isto é, Deus criou em seu Verbo, que lhe é coeterno, a matéria informe das criaturas espirituais e corporais. Outro afirma: "No princípio Deus criou o céu e a terra" – isto é, Deus criou a matéria informe das criaturas corporais, onde estavam ainda confundidos o céu e a terra, que agora distinguimos na massa do universo, com suas formas bem distintas e determinadas.

 Um último diz: "No princípio Deus criou o céu e a terra" – isto é, desde que começou a agir, Deus criou a matéria informe, onde estavam contidos confusamente em potencial o céu e a terra, que depois receberam forma própria, e que agora nos aparecem com tudo o que neles existe.

## CAPÍTULO XXI

### A terra invisível

 O mesmo ocorre em relação à interpretação das palavras que se seguem. Entre essas, todas verdadeiras, cada um escolhe uma. Este diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, essa massa corpórea, que Deus fez, era a matéria ainda sem forma, sem ordem, sem luz, das coisas corpóreas.

 Outro diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, esse conjunto que chamamos de terra e céu era a matéria ainda informe e tenebrosa, da qual seriam tirados o céu e a terra corpóreos, com tudo o que nossos sentidos físicos neles percebem.

 Outro diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto e´, esse conjunto que chamamos de céu e de terra era a matéria ainda informe e tenebrosa, donde seriam feitos o céu inteligível, noutros termos, o céu do céu, e a terra, isto é, toda natureza corpórea, nela incluindo o céu material, ou seja, a matéria de toda criatura visível e invisível.

 Outro diz: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, não quis a Escritura chamar à massa informe de céu e de terra, porque ela já existia; é dessa massa que ela chamou de terra invisível, caótica, abismo de trevas, é dela, que Deus criou o céu e a terra, isto é, a criatura espiritual e a corporal.

 E outro ainda: "A terra era invisível e caótica, e as trevas se estendiam sobre o abismo" – isto é, já existia uma matéria informe, da qual a Escritura diz que Deus criou o céu e a terra, toda a massa corporal do mundo, dividido em duas grandes partes, uma superior, outra inferior, com todas as criaturas nelas existentes e que nos são familiares.

## CAPÍTULO XXII

### Objeções

 Mas a essas últimas opiniões alguém poderia opor a seguinte objeção: "Se não quereis dar o nome de céu e terra à matéria informe, havia então alguma coisa não criada por Deus, e de que ele se serviria para criar o céu e a terra. De fato, a Escritura, não diz que Deus criou essa matéria, a menos que consideremos que seja ela o que chama céu e terra quando diz: "No princípio Deus criou o céu e a terra" – No que se segue: "A terra era invisível e informe" – ainda que a Escritura quisesse designar assim a matéria informe, nós apenas poderíamos entender com isso a matéria criada por Deus, conforme está escrito: "Criou o céu e a terra" – Aos que sustentam as duas últimas opiniões que acabamos de expor, ou de uma das duas, respondem assim: "Não negamos que esta matéria informe seja obra de Deus, de quem procede tudo o que é bom. De fato afirmamos ser um bem superior o que é criado e plenamente formado, mas também dizemos que aquilo que é passível de ser criado e receber forma, embora seja um bem inferior, é ainda um bem.

 A Escritura não menciona a criação por Deus dessa matéria informe, mas deixa também de falar de muitas outras coisas, como, por exemplo, da criação dos querubins, dos serafins, dos tronos, das dominações, dos principados, das potestades, todas criaturas que o Apóstolo menciona claramente, e que Deus evidentemente criou. Se as palavras: "Deus criou o céu e a terra" – compreendem todas as coisas, que diremos das águas sobre as quais pairava o Espírito de Deus?

 Se pretendemos que sejam parte do que designa a palavra terra, como conceber por isso uma matéria informe, quando vemos as águas tão belas? E, por outro lado, por que está escrito que dessa matéria informe foi criado o firmamento, chamado de céu, quando não se faz menção da criação das águas? Pois as águas que vemos correr com harmoniosa beleza e não são nem informes, nem invisíveis! E se elas receberam sua beleza quando Deus disse: "Que se reúnam as águas que estão sob o firmamento! – e se nessa reunião receberam sua formação, que dizer das águas que estão acima do firmamento? Informes, elas não teriam merecido lugar tão honroso, nem é referido com que palavras foram formadas.

 Assim, se o Gênesis é omisso quanto à criação de certas coisas, criação essa que está acima de dúvidas para uma fé sadia e uma inteligência segura, e se nenhuma doutrina racional ousa sustentar que essas águas são coeternas a Deus, pelo fato de as vermos mencionadas no Gênesis sem a menção do momento de sua criação , por que haveríamos de aceitar, à luz da verdade, que essa matéria informe, que a Escritura chama de terra invisível e desordenada e de abismo tenebroso, foi feita por Deus do nada e por isso não é coeterna a Deus, embora a narração da Escritura tenha deixado de referir o momento em que foi criada?

## CAPÍTULO XXIII

### A opinião de Agostinho

 Ouço e medito essas opiniões na medida de meu fraco entendimento, que confesso a Deus, embora ele bem o conheça. Vejo que se podem originar duas espécies de opiniões sobre um testemunho de interprete fidedigno. Uma é reativa à veracidade das coisas, e outra à intenção daquele que as enuncia. Procurar conhecer a verdade sobre a criação é uma coisa; procurar saber o que Moisés, grande servo de tua lei, quis o que o leitor ou ouvinte entendessem de suas palavras, é outra.

 Quanto à primeira opinião, longe de mim todos que têm como verdades os seus erros! Quanto à segunda, longe de mim todos os que julgam falsidade o que Moisés disse. Possa eu unir-me em ti, alegrar-me em ti, Senhor, com aqueles que se alimentam de tua verdade na imensidão da caridade. Aproximemo-nos juntos das palavras de teu Livro, procurando tua vontade nas intenções de teu servo, a cuja pena as revelaste.

## CAPÍTULO XXIV

### Qual a verdade?

 Quem de nós, entre tantos significados possíveis que ocorrem aos estudiosos quanto as varias interpretações de tuas palavras, poderá atinar com tais intenções e declarar com segurança: "Eis o pensamento de Moisés, este é o sentido que quis dar á sua narração". – Quem poderá declará-lo, com a mesma segurança que ele, que essa narração é verdadeira, qualquer que tenha sido o pensamento de Moisés?

 Eis que eu, meu Deus, teu servo, te consagrei nesta obra o sacrifício de minhas confissões; peço à tua misericórdia que me permita a realização desse desejo, e declaro com toda segurança que criaste todas as coisas, as invisíveis e as visíveis, pelo teu verbo imutável.

 Mas poderei dizer com a mesma certeza que Moisés teve essa intenção, e não outra, quando escreveu: "No princípio, criou Deus o céu e a terra"? – Embora esteja persuadido de que isto está claro na tua verdade, não vejo com igual certeza o que Moisés pretendia ao escrever tais palavras. Por essa expressão: "no princípio" pode ter significado: "no começo da criação". Por céu e terra, pode ter querido dar-nos a entender, a natureza espiritual e corporal, não já formada e perfeita, mas uma e outra, só esboçada e sem forma. Vejo que ambos os sentidos são igualmente plausíveis. Mas não posso atinar em qual dos dois pensava Moisés quando escrevia essas palavras. Fosse porém qual fosse sua intenção ao exprimir essas palavras, eu não poderia duvidar de que tão grande homem tenha entrevisto a verdade e a tenha formulado adequadamente.

## CAPÍTULO XXV

### Os diversos partidos

 Que ninguém me moleste portanto, dizendo: "O pensamento de Moisés não é o que tu dizes, mas o que eu digo". – Se apenas me dissessem: "Como sabes que Moisés de fato entendia essas palavras no sentido que lhe atribuis?" – Eu não me agastaria, e responderia talvez o que respondi acima, ou até mais explicitamente, se meu contraditor fosse insistente.

 Quando porém, me dizem: "O pensamento de Moisés não é o que dizes, é o que eu afirmo" – sem contudo provar a veracidade de uma ou outra interpretação, então, ó vida dos pobres, ó meu Deus, em cujo seio não há contradição, inunda de paz o meu coração, para que eu tenha paciência para suportar essas pessoas. Pois não emitem tais opiniões inspirados por Deus, ou porque tenham lido o pensamento de teu servo, mas porque são orgulhosos. Ignoram o pensamento de Moisés, mas só apreciam o deles, e não por que seja verdadeiro, mas por ser o deles. Assim não fosse, apreciariam igualmente a opinião alheia, quando verdadeira, assim como eu aprecio o que eles dizem de verdadeiro, não porque vem deles, mas porque é verdade, e que, por isso mesmo, é tanto deles como minha, pois pertence em comum a todos os amantes da verdade.

 Quanto à pretensão de que o pensamento de Moisés não está no que digo, mas no que eles dizem, isso eu não aceito. Ainda que assim fosse, sua temeridade não é da ciência, mas a da audácia; seria produzida não por uma intuição correta, mas pelo orgulho.

 Senhor, teu julgamento é terrível. Porque tua verdade nem é um bem meu, nem o bem deste ou daquele: a verdade é o bem de todos nós; e tu nos conclamas abertamente a que participemos dela, com a advertência severa de não a possuirmos como bem privativo, para não sermos privados dela. De fato, quem reivindica apenas para si o que ofereces para gozo de todos, e quer para si o que é de todos, é rejeitado desse bem comum para o que é seu, isto é, da verdade para a mentira: o que fala mentira fala do que é seu.

 Ouvem, pois, juiz excelente, ó Deus, que és a própria Verdade: ouve o que respondo a esse contraditor.

 É diante de ti que falo, e na presença de meus irmãos que usam legitimamente da lei, cujo fim á caridade. Escuta e vê o que lhes digo, se é de teu agrado. Eis as palavras fraternas e de paz que lhe dirijo: "Quando ambos vemos que tuas palavras são verdadeiras, ou as minhas palavras são verdadeiras, pergunto: onde o vemos? Certamente não é em ti que eu a vejo, nem tampouco é em mim que tu a vês. Ambos a vemos na verdade imutável, que está acima de nossas inteligências".

 Uma vez que não discordamos sobre essa luz do Senhor, nosso Deus, por que discutir sobre o pensamento de nosso próximo? Nós não o podemos ver como vemos a verdade imutável. Se o próprio Moisés nos aparecesse e nos explicasse seu pensamento – nem assim veríamos esse pensamento, mas apenas acreditaríamos nele. Cuidemos pois, de não nos levantarmos orgulhosamente um contra o outro a respeito das Escrituras. Amemos ao Senhor, nosso Deus, de todo o nosso coração, de toda nossa alma, de todo nosso espírito, e ao próximo como a nós mesmos. É segundo esses dois preceitos da caridade que Moisés pensou aquilo que escreveu em seus livros. Não acreditarmos nisso seria considerar o Senhor mentiroso, atribuindo a seu servo sentimentos distintos daqueles que ele próprio lhe ensinou. Diante de tantos pensamentos igualmente verdadeiros que podem ser deduzidos dessas palavras, vê que estultice é afirmar temerariamente que Moisés teve este pensamento e não aquele, ofendendo com nossas disputas perniciosas a caridade, por amor da qual ele escreveu as palavras que procuramos interpretar!

## CAPÍTULO XXVI

### Agostinho no lugar de Moisés

 Todavia, meu Deus, que me elevas em minha pequenez, que descansas minha fadiga, que ouves minhas confissões e perdoas meus pecados, tu me ordenas que eu ame a meu próximo como a mim mesmo; não posso crer que Moisés, teu servo tão fiel, tenha sido aquinhoado com menos dons do que eu teria desejado e apetecido se tivesse nascido em seu tempo, e me tivesses confiado a tarefa de te servir com meu coração e minha língua, e disseminar essas Escrituras. Estas, tanto tempo depois, deviam ser úteis a todos os homens e, pelo mundo afora, triunfar com o prestígio de sua autoridade sobre as afirmações das doutrinas falsas e orgulhosas.

 Quereria, se estivesse no lugar de Moisés – pois todos procedemos da mesma massa, e que é o homem se não te lembras dele? – e me tivesses confiado a missão de escrever o Gênesis, quereria receber de ti tal eloqüência, tal qualidade de estilo, que mesmo os espíritos incapazes de compreender como foi que Deus criou, não pudessem rejeitar minhas palavras como superiores às suas forças; que os que já o pudessem, descobrissem, nas poucas palavras de teu servo, todas as verdades que sua reflexão já lhes tivesse proporcionado; e que se alguém, à luz de tua verdade, nelas percebesse outro significado, também ele o pudesse encontrar nessas mesmas palavras.

## CAPÍTULO XXVII

### Os diversos sentidos da Escritura

 Assim como uma fonte, em seu pequeno leito, torna-se depois mais abundante e, pelos diversos regatos que alimenta, banha espaços muito mais amplos que qualquer um deles, que deslizam através de muitas regiões, assim também a narração do ministro de tua palavra, que deveria alimentar a tantos interpretes, faz brotar de seu estilo sóbrio e conciso torrentes de límpida verdade, de onde cada um tira para si a verdade que pode, para depois desenvolvê-la em longas sinuosidades de palavras.

 Alguns, lendo ou escutando aquelas palavras, imaginam a Deus como homem ou como massa material dotada de imenso poder que, por decisão nova e repentina, criara fora de si mesma e como que à distância, o céu e a terra, esses dois grandes corpos, um superior, outro inferior, onde estão contidas todas as coisas. E ao ouvirem dizer:"Deus disse: faça-se isto! E isto foi feito! – imaginam que se trata de palavras comuns, que começam e terminam, que soam no tempo e passam. Julgam que, logo após pronunciadas, começa existir o que ordenaram que existisse. Todas as suas demais concepções ressentem-se do mesmo hábito de pensar de modo carnal.

 Nisto são como crianças, pois enquanto essa linguagem humilde sustentar sua fraqueza como o seio de uma mãe, o que se fortifica salutarmente é a fé, que lhes faz ter como certo que Deus criou todas as realidades, cuja admirável variedade impressiona a seus sentidos.

 Mas, se alguém, desprezando a aparente simplicidade de tuas palavras, em sua orgulhosa fraqueza, se lançar para fora do ninho que o nutriu, então cairá miseravelmente, Senhor Deus, tem piedade dele! Que os transeuntes não pisem este passarinho implume; manda teu anjo para que o reponha no ninho, para que viva até que aprenda a voar!

## CAPÍTULO XXVIII

### Divergências

 Para outros essas palavras não são um ninho, mas um vergel (jardim) ensombreado onde descobrem frutos ocultos que procuram e colhem, voando e cantando alegremente.

 Quando lêem ou ouvem as palavras de Moisés, vêem que tua estável e eterna permanência, ó Deus, domina todos os tempos passados e futuros, e por isso não existe criatura corpórea que não seja obra tua. Vêem que tua vontade, confundindo-se com teu ser, criou todas as coisas sem sofrer modificação, sem que nasça nela uma decisão nova, que não existisse antes; que criaste o mundo, não tirando de tua substância uma imagem tua, forma substancial de toda realidade, mas tirando do nada uma matéria informe, diferente de ti mesmo; e esta poderia ser formada à tua imagem pela volta à tua Unidade, segundo a medida previamente estabelecida e concedida a cada ser, de acordo com sua espécie. Vêem assim que todas as obras da criação são excelentes, ou porque permanecem próximas a ti, ou porque, afastadas de ti no tempo e no espaço, fazem ou sofrem as admiráveis variedades do mundo. Reconhecem essas coisas, e por isso se alegram na luz de tua verdade, à medida que o podem com suas forças terrenas.

 Outros, refletindo o sentido destas palavras: "No princípio criou Deus..." – vê no princípio a Sabedoria, porque também ela nos fala.

 Outro, ao considerar as mesmas palavras, entende por princípio o começo da criação, e a expressão: "Deus criou no princípio" significa para ele: "Deus primeiramente fez". E entre os mesmos que por princípio entendem que Deus criou em sua Sabedoria o céu e a terra, um acredita que céu e terra designam a matéria da qual o céu e a terra foram criados; outro pensa que a expressão se aplica a naturezas já formadas e distintas; outro sustenta que a palavra céu significa natureza formada e espiritual, a terra, a natureza informe e material.

 Aqueles porém que entendem por céu e terra a matéria ainda informe, com a qual viriam a ser formados o céu e a terra, não têm unanimidade: um concebe essa matéria como origem comum das criaturas sensíveis e espirituais, outro apenas como fonte de massa sensível e corpórea, contendo em seu vasto seio todas as realidades visíveis, oferecidas a nossos sentidos.

 Tampouco são unânimes os que crêem que nesse texto céu e terra se referem às criaturas já formadas e dispostas; um acredita que se trata do mundo invisível e visível; outro, apenas do mundo visível, onde se contempla o céu luminoso e a terra tenebrosa, com tudo o que eles contêm.

## CAPÍTULO XXIX

### Dificuldades

 Mas quem interpreta a palavra: "No princípio criou..." como se ela quisesse dizer: "Primeiramente Deus criou..." – apenas pode entender, por céu e terra, se quiser se manter coerente à verdade, a matéria do céu e da terra, isto é, da criação universal, tanto espiritual como material.

 Pois, se quiser referir-se com isso a um universo já inteiramente formado, seríamos levados a indagar-lhe: "Se Deus criou isso antes, o que criou depois?" – Depois de ter criado tudo, não encontrará mais nada para criar e, gostando ou não, ouvirá a pergunta: "Como é possível que Deus tenha criado isso primeiro, se nada criou depois?"

 Se ele quer significar que Deus criou primeiro a matéria informe, e depois lhe deu forma, já não é uma tese absurda, desde que seja capaz de discernir a prioridade na eternidade, no tempo, na escolha, na origem. Na eternidade: Deus antecede todas as coisas; no tempo: a flor precede o fruto; na escolha: o fruto vale mais do que a flor; na origem: o som precede o canto.

 Dessas quatro prioridades, a primeira e a última dificilmente se compreendem, enquanto é bem fácil entender as outras duas. É de fato raro e dificultoso conceber a tua eternidade criando, mas conservando-se imutável, as coisas mutáveis e, por isso, antecedendo-as. E precisa ter uma inteligência penetrante para compreender, sem grande esforço, como o som antecede o canto, uma vez que o canto é o som organizado; e uma coisa pode muito bem existir sem forma, mas o que não existe não pode receber forma. Assim, a matéria é anterior ao que dela se forma. e não porque seja sua causa eficiente, pois também é objeto da criação; nem tampouco porque lhe seja anterior no tempo. De fato, não emitimos em um primeiro instante, sons desarticulados e informes, para depois os ligarmos e formar uma melodia e um canto, como se faz com a madeira e a prata ao fabricarmos uma arca ou um vaso.

 Com efeito, essas matérias precedem no tempo os objetos que delas são feitos. Mas com o canto não é assim. Quando se canta ouve-se o som do canto: não há em primeiro lugar sons desorganizados, que depois assumem a forma de canto. Logo que ele soa, o som se desvanece, e não deixa de si nada que se possa coordenar com arte. Por conseguinte, o canto é formado de sons: o som é sua matéria e, para se transformar em canto, recebe uma forma. A prioridade não se fundamenta em um poder criador, porque o som não é o artífice do canto, mas é apenas posto pelo corpo à disposição da alma do cantor, para que dele faça um canto. Nem se trata de prioridade temporal: o som é produzido ao mesmo tempo que o canto. Tampouco se trata de prioridade de escolha: o som não é superior ao canto, pois o canto nada mais é que som, mas um som bonito. Trata-se apenas de uma prioridade de origem, pois o canto não recebe forma para se tornar som, mas o som para se tornar canto.

 Compreende-se por esse exemplo, que a matéria das coisas foi criada antes, e chamada de céu e terra, porque dela foram formados o céu e a terá. Não foi criada antes em sentido cronológico, porque o tempo só tem início com a forma das coisas; ora, a matéria era informe, e se tornou perceptível juntamente com o tempo. Todavia, nada se pode mencionar dessa matéria a não ser alguma prioridade temporal, embora ocupe a última posição na escala de valores, pois o que tem forma é evidentemente superior ao que é informe. Ou que foi precedida pela eternidade do Criador, que a fez para que fossem feitas do nada todas as coisas.

## CAPÍTULO XXX

### Espírito de caridade

 Nessa diversidade de opiniões verdadeiras, que da própria verdade brote a concórdia! Que nosso Deus tenha compaixão de nós, para que usemos legitimamente da lei segundo o preceito que tem por fim a caridade pura.

 Por isso, se me perguntarem qual dessas opiniões foi a de teu servo Moisés, eu não seria coerente com minhas confissões se não te confessasse que o ignoro.

 Sei, contudo, que essas opiniões são verdadeiras, a não mera interpretações materialistas, sobre as quais já disse tudo o que pensava. São como meninos esperançosos aqueles que não temem as palavras do teu Livro, tão profundas em sua humildade, tão eloqüentes em sua concisão. Mas nós todos que, eu o declaro, distinguimos e dizemos a verdade sobre tais palavras, amemo-nos uns aos outros; e amemos igualmente a ti, nosso Deus, fonte da Verdade, pois temos sede, não de fantasias, mas da própria Verdade. Honremos a teu servo, que nos legou tua Escritura, cheio de teu espírito, e estejamos certos que, ao escrever as palavras que lhe revelaste, ele teve em mira as revelações mais salientes da verdade e seus frutos proveitosos.

## CAPÍTULO XXXI

### O Gênesis e seu autor

 Assim, quando alguém me diz: "O pensamento de Moisés é o meu" – e outro diz: "Não, ele pensou como eu" – parece-me mais consoante ao espírito religioso dizer: "Por que não admitir ambos os pontos de vista, se ambos são verdadeiros?" – E se alguém descobrir um terceiro, um quarto sentido, e outros mais, desde que sejam verdadeiros, por que não acreditar que Moisés viu todos eles, ele por cujo intermédio o Deus único adaptou as Escrituras à inteligência da multidão, que deveria descobrir-lhe significados diversos e verdadeiros?

 Por mim, digo-o sem hesitar e do fundo do coração: se, investido da mais alta autoridade, tivesse algo a escrever, preferiria fazê-lo de modo que minhas palavras proclamassem tudo o que cada um pudesse conceber de verdadeiro sobre isso, em vez de propor um significado único e claro que excluísse todos os demais, cuja falsidade não me pudesse ofender. E também não quero, meu Deus, ser tão temerário ao ponto de acreditar que esse grande homem não mereceu de ti essa graça.

 Moisés, redigindo esses textos, pensou, concebeu todas as verdades que já fomos capazes de encontrar, e também as que não o pudemos, mas que podem ser descobertas.

## CAPÍTULO XXXII

### Oração

 Enfim, Senhor, tu que és Deus, e não carne e sangue, se um homem não pôde ver tudo por completo, poderia teu Espírito bom, que me deve conduzir à terra da retidão, desconhecer algo do que tencionavas revelar por essas palavras a seus leitores vindouros, apesar de teu mensageiro não entender senão um dos numerosos sentidos verdadeiros? Se assim é, o sentido que ele pensou era o mais elevado de todos. Mas revela a nós, Senhor, esse sentido ou algum outro que for de teu agrado e real; e quer nos mostres o mesmo sentido que ao homem de Deus, quer seja outro, inspirado pelas mesmas palavras, alimenta nosso espírito, guarda-nos da ilusão do erro.

 Eis, Senhor meu Deus! Quantas páginas escrevi sobre tão poucas palavras! Deste modo, minhas forças e o meu tempo serão suficientes para examinar todos os teus livros? Permite-me, pois, abreviar minhas confissões e adotar uma única interpretação, que me farás escolher como verdadeira, certa e boa, entre as muitas outras que me poderão ocorrer. Que minha confissão seja fiel o bastante para que eu tenha exatidão ao exprimir o pensamento de teu servo, pois para tal me esforçarei; e, se não o conseguir, que eu pelo menos diga o que tua Verdade me quis dizer por suas palavras, como ela disse a Moisés o que lhe aprouve.