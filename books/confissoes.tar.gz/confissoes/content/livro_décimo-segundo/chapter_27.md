## CAPÍTULO XXVII

### Os diversos sentidos da Escritura

 Assim como uma fonte, em seu pequeno leito, torna-se depois mais abundante e, pelos diversos regatos que alimenta, banha espaços muito mais amplos que qualquer um deles, que deslizam através de muitas regiões, assim também a narração do ministro de tua palavra, que deveria alimentar a tantos interpretes, faz brotar de seu estilo sóbrio e conciso torrentes de límpida verdade, de onde cada um tira para si a verdade que pode, para depois desenvolvê-la em longas sinuosidades de palavras.

 Alguns, lendo ou escutando aquelas palavras, imaginam a Deus como homem ou como massa material dotada de imenso poder que, por decisão nova e repentina, criara fora de si mesma e como que à distância, o céu e a terra, esses dois grandes corpos, um superior, outro inferior, onde estão contidas todas as coisas. E ao ouvirem dizer:"Deus disse: faça-se isto! E isto foi feito! – imaginam que se trata de palavras comuns, que começam e terminam, que soam no tempo e passam. Julgam que, logo após pronunciadas, começa existir o que ordenaram que existisse. Todas as suas demais concepções ressentem-se do mesmo hábito de pensar de modo carnal.

 Nisto são como crianças, pois enquanto essa linguagem humilde sustentar sua fraqueza como o seio de uma mãe, o que se fortifica salutarmente é a fé, que lhes faz ter como certo que Deus criou todas as realidades, cuja admirável variedade impressiona a seus sentidos.

 Mas, se alguém, desprezando a aparente simplicidade de tuas palavras, em sua orgulhosa fraqueza, se lançar para fora do ninho que o nutriu, então cairá miseravelmente, Senhor Deus, tem piedade dele! Que os transeuntes não pisem este passarinho implume; manda teu anjo para que o reponha no ninho, para que viva até que aprenda a voar!