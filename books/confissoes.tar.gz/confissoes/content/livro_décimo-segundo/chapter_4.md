## CAPÍTULO IV

### A matéria informe

 Que nome darei a esta matéria, como sugerir sua idéia às inteligências mais curtas, senão usando um termo de uso corrente? O que se pode encontrar no mundo que seja mais parecido com essa ausência total de forma, que a terra e o abismo? Colocados no mais baixo grau da criação, eles não têm a beleza dos corpos que no alto brilham de luz fulgurante.

 Por que, então, não aceitar que essa matéria informe, que criaste sem beleza para com ela moldar um mundo cheio de beleza, fosse comodamente designada aos homens pelos termos de terra invisível e informe?