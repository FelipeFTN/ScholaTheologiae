## CAPÍTULO V

### Sua natureza

 Assim, quando o pensamento indaga o que nossos sentidos podem colher a respeito dessa matéria, responde a si mesmo: "Não é nem forma inteligível, como a vida, como a justiça, porque é a matéria corpórea, nem uma forma sensível, porque nada há que se possa ver ou perceber no que é invisível e sem forma". – Quando o pensamento humano fala desse modo, procura conhecê-la ignorando-a, ou ignorá-la conhecendo-a?