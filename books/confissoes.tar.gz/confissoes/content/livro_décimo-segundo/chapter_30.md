## CAPÍTULO XXX

### Espírito de caridade

 Nessa diversidade de opiniões verdadeiras, que da própria verdade brote a concórdia! Que nosso Deus tenha compaixão de nós, para que usemos legitimamente da lei segundo o preceito que tem por fim a caridade pura.

 Por isso, se me perguntarem qual dessas opiniões foi a de teu servo Moisés, eu não seria coerente com minhas confissões se não te confessasse que o ignoro.

 Sei, contudo, que essas opiniões são verdadeiras, a não mera interpretações materialistas, sobre as quais já disse tudo o que pensava. São como meninos esperançosos aqueles que não temem as palavras do teu Livro, tão profundas em sua humildade, tão eloqüentes em sua concisão. Mas nós todos que, eu o declaro, distinguimos e dizemos a verdade sobre tais palavras, amemo-nos uns aos outros; e amemos igualmente a ti, nosso Deus, fonte da Verdade, pois temos sede, não de fantasias, mas da própria Verdade. Honremos a teu servo, que nos legou tua Escritura, cheio de teu espírito, e estejamos certos que, ao escrever as palavras que lhe revelaste, ele teve em mira as revelações mais salientes da verdade e seus frutos proveitosos.