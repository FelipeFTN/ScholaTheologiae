## CAPÍTULO III

### As trevas sobre o abismo

 Mas esta terra era invisível e informe, era um profundo abismo acima do qual não pairava nenhuma luz, pois não tinha nenhuma forma. Por isso inspiraste estas palavras: "As trevas cobriam o abismo". – Mas que são trevas, senão ausência da luz? De fato, se então existisse, onde estaria a luz senão sobre a terra, para iluminá-la? Mas como a luz ainda não existia, o que era a presença das trevas, senão a ausência da luz? As trevas reinavam sobre o abismo porque a luz não existia, do mesmo modo que onde não há ruído reina o silêncio. E que significa reinar o silêncio, senão falta de som?

 Não ensinaste, Senhor, à alma que a ti se confessa? Não me ensinaste, Senhor, que antes de receber de ti forma e figura esta matéria informe, não existia nada, nem cor, nem figura, nem corpo, nem espírito? Não era um nada absoluto, mas massa informe, sem figura alguma.