## CAPÍTULO XIV

### A profundidade das Escrituras

 Admirável profundidade das tuas palavras! Sua aparência nos acaricia, como se acariciam as crianças! Sim, admirável profundidade, meu Deus, admirável profundidade! O meditá-las causa um arrepio sagrado, tremor de respeito, estremecimento de amor. Odeio com veemência seus inimigos. Oh! Se pudesses fazê-los morrer sob teu gládio de dois gumes, para que não tivessem mais inimigos! Desejaria que eles morressem para si mesmos, e que vivessem só para ti.

 Mas há outros que não censuram mas, pelo contrário, exaltam o livro de Gênesis, e que dizem: "Não é isto que quis dizer por essas palavras o Espírito de Deus, que as inspirou a teu servo Moisés. Não, o que ele quis dizer não é o que dizes, mas o que nós dizemos" – Eis, ó Deus de todos nós, o que eu lhes respondo: sê nosso árbitro.