## CAPÍTULO II

### O céu do céu

 Que a humildade de minha língua confesse à tua grandeza que criaste o céu e a terra; este céu que vejo, esta terra que piso, e de onde tiraste a terra que trago em mim. sim, criaste tudo isto.

 Mas, Senhor, onde está o céu de que nos falou a voz do salmista: "O céu do céu pertence ao Senhor, mas ele deu a terra aos filhos dos homens?" – Onde está esse céu que não vemos, e diante do qual tudo o que vemos é apenas terra?

 De fato, todo este mundo material, cuja base é a terra, embora não seja inteiramente belo em toda parte, recebeu até em seus últimos elementos, uma aparência atraente. Mas, comparado com esse céu do céu, o céu de nossa terra também não passa de terra. Por isso, não é absurdo chamar de terra esses dois grandes corpos visíveis, se os compararmos a esse céu misterioso que pertence ao Senhor, e não aos filhos dos homens.