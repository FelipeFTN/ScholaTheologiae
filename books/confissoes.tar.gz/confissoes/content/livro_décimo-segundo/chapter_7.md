## CAPÍTULO VII

### A criação do nada

 Mas de onde essa matéria tirava seu ser, senão de ti, por quem existe toda e qualquer coisa? Quanto mais difere de ti uma coisa, mais longe de ti está – e não se trata de distância espacial.

 Portanto, és tu, Senhor que não mudas ao sabor das circunstâncias, mas que és sempre o mesmo, o mesmo e o mesmo, santo e santo e santo, Senhor, Deus Todo-Poderoso, és tu, Senhor, que no princípio, que vem de ti, em tua Sabedoria, nascida de tua substância, fizeste algo do nada. Criaste o céu e a terra, e isso não com tua substância, pois nesse caso, tua criação seria igual a teu Filho unigênito e, por isso, iguais a ti mesmo. E não seria justo que o que não é da tua substância, fosse igual a ti.

 Mas fora de ti nada existia com que pudesses fazer o céu e a terra, ó Trindade una, Unidade trina. Por isso criaste do nada o céu e a terra; duas realidades, uma imensa e outra pequena. Porque és Todo-Poderoso e bom, e só podes criar coisas boas: o grande céu e a pequena terra.

 Fora de ti nada havia, e desse nada fizeste o céu e a terra, tuas duas obras: uma próxima de ti, a outra próxima do nada. Uma que tem acima de si apenas a ti mesmo, e outra que nada tem inferior a ela.