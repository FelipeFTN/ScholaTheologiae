## CAPÍTULO X

### Invocação à verdade

 Ó Verdade, luz de meu coração, faze com que se calem as minhas trevas. Deixei-me cair nelas e fiquei às escuras; mas, mesmo do fundo desse abismo, eu te amei ardentemente. Andei, errante, mas lembrei de ti. Ouvi tua voz atrás de mim, que me exortava a que voltasse; mas dificilmente podia escutá-la, por causa do tumulto de minha alma. e agora, eis que, ardente e anelante, volto à tua fonte. Que ninguém mo impeça; beberei de sua água, e assim viverei. Que não seja eu minha própria vida! Vivi mal por minha culpa, e fui a causa de minha morte. Em ti eu revivo! Fala-me, ensina-me. Creio em teus livros, e tuas palavras encerram profundos mistérios.