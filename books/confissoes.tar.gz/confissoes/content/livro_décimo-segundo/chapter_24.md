## CAPÍTULO XXIV

### Qual a verdade?

 Quem de nós, entre tantos significados possíveis que ocorrem aos estudiosos quanto as varias interpretações de tuas palavras, poderá atinar com tais intenções e declarar com segurança: "Eis o pensamento de Moisés, este é o sentido que quis dar á sua narração". – Quem poderá declará-lo, com a mesma segurança que ele, que essa narração é verdadeira, qualquer que tenha sido o pensamento de Moisés?

 Eis que eu, meu Deus, teu servo, te consagrei nesta obra o sacrifício de minhas confissões; peço à tua misericórdia que me permita a realização desse desejo, e declaro com toda segurança que criaste todas as coisas, as invisíveis e as visíveis, pelo teu verbo imutável.

 Mas poderei dizer com a mesma certeza que Moisés teve essa intenção, e não outra, quando escreveu: "No princípio, criou Deus o céu e a terra"? – Embora esteja persuadido de que isto está claro na tua verdade, não vejo com igual certeza o que Moisés pretendia ao escrever tais palavras. Por essa expressão: "no princípio" pode ter significado: "no começo da criação". Por céu e terra, pode ter querido dar-nos a entender, a natureza espiritual e corporal, não já formada e perfeita, mas uma e outra, só esboçada e sem forma. Vejo que ambos os sentidos são igualmente plausíveis. Mas não posso atinar em qual dos dois pensava Moisés quando escrevia essas palavras. Fosse porém qual fosse sua intenção ao exprimir essas palavras, eu não poderia duvidar de que tão grande homem tenha entrevisto a verdade e a tenha formulado adequadamente.