## CAPÍTULO XXVIII

### Divergências

 Para outros essas palavras não são um ninho, mas um vergel (jardim) ensombreado onde descobrem frutos ocultos que procuram e colhem, voando e cantando alegremente.

 Quando lêem ou ouvem as palavras de Moisés, vêem que tua estável e eterna permanência, ó Deus, domina todos os tempos passados e futuros, e por isso não existe criatura corpórea que não seja obra tua. Vêem que tua vontade, confundindo-se com teu ser, criou todas as coisas sem sofrer modificação, sem que nasça nela uma decisão nova, que não existisse antes; que criaste o mundo, não tirando de tua substância uma imagem tua, forma substancial de toda realidade, mas tirando do nada uma matéria informe, diferente de ti mesmo; e esta poderia ser formada à tua imagem pela volta à tua Unidade, segundo a medida previamente estabelecida e concedida a cada ser, de acordo com sua espécie. Vêem assim que todas as obras da criação são excelentes, ou porque permanecem próximas a ti, ou porque, afastadas de ti no tempo e no espaço, fazem ou sofrem as admiráveis variedades do mundo. Reconhecem essas coisas, e por isso se alegram na luz de tua verdade, à medida que o podem com suas forças terrenas.

 Outros, refletindo o sentido destas palavras: "No princípio criou Deus..." – vê no princípio a Sabedoria, porque também ela nos fala.

 Outro, ao considerar as mesmas palavras, entende por princípio o começo da criação, e a expressão: "Deus criou no princípio" significa para ele: "Deus primeiramente fez". E entre os mesmos que por princípio entendem que Deus criou em sua Sabedoria o céu e a terra, um acredita que céu e terra designam a matéria da qual o céu e a terra foram criados; outro pensa que a expressão se aplica a naturezas já formadas e distintas; outro sustenta que a palavra céu significa natureza formada e espiritual, a terra, a natureza informe e material.

 Aqueles porém que entendem por céu e terra a matéria ainda informe, com a qual viriam a ser formados o céu e a terra, não têm unanimidade: um concebe essa matéria como origem comum das criaturas sensíveis e espirituais, outro apenas como fonte de massa sensível e corpórea, contendo em seu vasto seio todas as realidades visíveis, oferecidas a nossos sentidos.

 Tampouco são unânimes os que crêem que nesse texto céu e terra se referem às criaturas já formadas e dispostas; um acredita que se trata do mundo invisível e visível; outro, apenas do mundo visível, onde se contempla o céu luminoso e a terra tenebrosa, com tudo o que eles contêm.