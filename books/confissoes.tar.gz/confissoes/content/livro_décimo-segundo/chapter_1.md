## CAPÍTULO I

### Prece

 Inquieto está meu coração, Senhor, quando, na miséria de minha vida é atingido pelas palavras de tua Escritura Sagrada. Por isso, geralmente, a abundância de palavras é testemunho da pobreza da inteligência humana. A busca usa mais palavras que a descoberta; é maior o pedir que o obter; a mão que bate cansa-se mais do que a mão que recebe. Mas nós temos tua promessa: quem a destruirá? Se Deus está conosco, quem será contra nós? Pedi, e recebereis; procurai e encontrareis; batei, e abrir-se-vos-á. Porque todo o que pede recebe, todo o que procura encontra, e a todo o que bate se lhe abrirá.

São promessas tuas. E quem temerá ser enganado, quando a promessa vem da Verdade?