## CAPÍTULO VI

### Em que consiste

 Senhor, se pela boca e pela pena devo confessar-te o que me ensinaste sobre essa matéria, eu direi que outrora ouvi falar, sem nada compreender, a respeito desse nome por pessoas que também não entendiam. Tentei imaginá-la sob as formas mais diversas, e não o consegui. Meu espírito revolvia confusamente formas feias e horríveis, mas enfim sempre formas. Chamava de informe essa matéria, não porque a imaginasse sem forma, mas por tê-las tão estranhas e bizarras que, se a visse, afastaria meus sentidos e confundiria minha fraqueza de homem.

 Por isso, o que eu concebia era informe, não por ausência de qualquer forma, mas por comparação com formas mais belas. A reta razão me persuadia; se eu quisesse conceber algo absolutamente informe, a suprimir nele todo resquício de forma, mas eu não conseguia; pareciame bem mais fácil negar a existência do que estava privado de toda forma, do que conceber um ser a meio termo entre a forma e o nada, e que não fosse nem forma, nem nada, um ser informe, um quase nada.

 Então, minha inteligência deixou de inquirir minha imaginação, cheia de imagens de formas corpóreas, que ela variava e mudada a seu talante. Fixei a atenção nos próprios corpos, analisei mais profundamente essa mutabilidade pela qual eles cessam de ser o que eram e começam a ser o que não eram. Suspeitei que essa transição de uma forma para outra se fazia por meio de algo informe, e não do nada absoluto.

 Mas meu interesse era saber, e não apenas supor; e se minha voz e minha pena te confessassem em detalhes as soluções deste problema que me inspiraste, qual de meus leitores teria paciência para me entender? Contudo, meu coração não deixará de te honrar com cânticos de louvor por essas inspirações, por aquilo que não têm palavras capazes de exprimir.

 É a própria mutabilidade das coisas que é susceptível de assumir todas as formas em que se transfiguram as coisas mutáveis. E o que é essa mutabilidade? É espírito? Será talvez corpo? Seria uma espécie de espírito ou de corpo? Se pudéssemos dizer: um nada que é algo, ou o que é e não é, eu a chamaria assim. No entanto, era necessário que ela existisse de alguma maneira, para tomar essas formas visíveis e complexas.