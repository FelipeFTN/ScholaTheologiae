## CAPÍTULO VIII

### Mônica

 Tu, que fazes morar na mesma casa os que têm coração unânime, trouxeste pra junto de nós Evódio, jovem de nosso município que, militando como agente de negócios do imperador, se convertera e recebera o batismo antes de nós, abandonara a milícia do século, alistando-se na tua.

 Estávamos juntos, e juntos pensávamos viver nosso santo propósito. Buscávamos um lugar onde nos pudéssemos instalar mais comodamente para te servir e juntos rumávamos para a África quando, chegando a Óstia, na foz do Tibre, faleceu minha mãe.

 Muitas coisas passo em silêncio, porque tenho pressa. Recebe minhas confissões e ações de graças, meu Deus, pelas inúmeras bondades que não menciono aqui. Mas não quero calar o que brota de minha alma a respeito desta tua serva, que me gerou na carne para a luz temporal, e no coração para a luz eterna. Não referirei suas qualidades, nem a si mesma se havia educado. Foste tu quem a educaste, nem seu pai, nem sua mãe sabiam o que viriam a ser aquela a quem geraram. A disciplina de teu Cristo, a doutrina de teu Filho único educaram-na em teu temor em uma família fiel, digno membro de tua Igreja.

 Nem ela mesma enaltecia o zelo da mãe em educá-la, quanto o de uma velha serva, que carregara seu pai quando menino, como hoje as meninas maiores costumam carregar as crianças, às costas.

 Estas recordações, sua idade avançada e hábitos exemplares lhe asseguravam naquela casa cristã o respeito de seus amos. Ela própria cuidava solicitamente das meninas que lhe haviam sido confiadas, ora repreendendo-as quando fosse o caso, com santa e enérgica severidade, ora instruindo-as com discreta prudência. Afora do horário em que tomavam uma sóbria refeição à mesa de seus pais, ainda que tivessem muita sede, nem água permitia que elas bebessem, precavendo com isso um mau costume. E acrescentava este sábio aviso: "Agora bebeis água, porque não tendes como beber vinho; mas quando estiverdes casadas, donas da despensa e da adega, deixareis a água, mas continuará o hábito de beber".

 E unindo assim o conselho à autoridade, refreava os apetites daquela tenra idade, e acostumava aquelas jovens à temperança, para que não tivesse desejo do que não lhes convinha.

 No entanto – como tua serva me contou a mim, seu filho – insinuou-se nela certo gosto pelo vinho. Julgando-a menina sóbria, seus pais a escolheram, como era costume, para tirar o vinho do tonel. Mergulhava a caneca pela parte superior do recipiente e, antes de passar o vinho para a garrafa, sorvia com a ponta dos lábios um pouquinho; era-lhe impossível beber mais, porque o vinho lhe repugnava. Não fazia isto movida pela inclinação à embriaguez, mas pela exuberância juvenil, que se manifestava em movimentos, em brincadeiras, e que na meninice costumam ser reprimidos pela autoridade severa dos mais velhos. Mas, acrescentando todos os dias uns goles àqueles goles – pois quem descuida das coisas pequenas pouco a pouco cai nas maiores – acostumou-se a esvaziar avidamente copos quase cheios de vinho puro.

 Onde estava então a prudente anciã, e sua severa proibição? Mas que remédio curaria um mal oculto se tua medicina, Senhor, não velasse sobre nós? Na ausência do pai, da mãe e das amas, estavas lá tu que nos criaste, que nos chamas, e que por meio dos que nos educam fazes o bem para a salvação das almas. Que fizeste então, meu Deus? Como a socorreste? Como a curaste? Fizeste sair de outra pessoa, segundo tuas secretas providências, um sarcasmo duro e pungente como ferro medicinal, para curar de um só golpe aquela gangrena.

 A criada que costumava acompanhá-la à adega, discutindo com sua jovem senhora, como às vezes acontece, estando as duas a sós, lançou-lhe em rosto sua intemperança, chamando-a insultuosamente de bêbada. Ferida por esse sarcasmo, a jovem reconheceu a fealdade daquele hábito, reprovou-o, e no mesmo instante o abandonou.

 Assim como muitas vezes as lisonjas dos amigos nos pervertem, assim os insultos dos inimigos nos corrigem. Mas não é o bem que nos fazem por seu intermédio que retribuis, mas a intenção com que o fazem. Aquela criada zangada pretendia ofender sua jovem senhora, e não corrigi-la; e se o fez às escondidas foi só por força da circunstância do lugar e tempo, ou para que não viesse a sofrer por denunciar tão tarde o costume de sua senhora.

 Mas, tu, Senhor, governador do céu e da terra, que desvias para teus desígnios as águas da torrente e regulas o curso turbulento dos séculos, curaste a loucura de uma alma com a insânia de outra. Por isso ninguém, ao considerar o caso, atribua a seu poder pessoal o mérito de ter corrigido com suas palavras a alguém cuja emenda deseja conseguir.