## CAPÍTULO VII

### O canto dos fiéis. Os corpos de São Gervásio e de São Protásio

 Não havia muito tempo que a igreja de Milão começara a adotar essa prática consoladora e edificante do canto, com grande regozijo dos fiéis, que uniam em um só coro as vozes e o coração. Havia um ano, ou pouco mais, que Justina, mãe do imperador Valentiniano, ainda menor, seduzida pelos arianos, perseguia, por causa de sua heresia, teu servo Ambrósio. O povo fiel passava as noites na igreja, disposto a morrer com seu bispo.

 Nesse meio estava minha mãe, tua serva, uma das primeiras no zelo dessas inquietações e vigílias, não vivendo senão de orações. Nós, apensar de ainda frios, sem o calor de teu Espírito, nos sentíamos comovidos pela perturbação e consternação da cidade.

 Foi então que se fixou o costume de cantar hinos e salmos, como se faz no Oriente, para que os fiéis não se consumissem no tédio e na tristeza. Desde esse dia esse costume mantevese, e no resto do mundo, quase todas as tuas comunidades de fiéis passaram a adotá-lo.

 Foi também nessa época que revelaste em sonho ao bispo Ambrósio o lugar em que jaziam ocultos os corpos dos mártires Gervásio e Protásio, que durante muito tempo, conservastes intactos no tesouro de teus segredos, a fim de revelá-los no momento oportuno para refrear o furor de uma mulher, embora imperatriz.

 Com efeito, depois de descobertos e desenterrados, ao serem transladados com as honras convenientes para a basílica ambrosiana, alguns possessos, atormentados pelos espíritos imundos, foram curados, conforme confissão dos próprios demônios. Também um cidadão, cego havia muitos anos, e muito conhecido na cidade, perguntou a razão daquele alvoroço e alegria populares; informado, pediu a seu guia que o levasse até ás relíquias. Lá chegando, obteve permissão para tocar com um lenço o ataúde de teus santos, cuja morte havia sido preciosa a teus olhos. Feito isto, aplicou o lenço aos olhos, que imediatamente se abriram.

 A noticia do milagre logo se propagou, e imediatamente se ouviram teus louvores com fervor, e o coração de tua inimiga, sem se converter à tua fé, reprimiu contudo o furor da perseguição.

 Graças te dou, meu Deus! De onde e para onde guiaste minha memória, para que também te confessasse estes acontecimentos que, embora grandes, eu já havia esquecido e omitido?

 Todavia, quando assim exalava o odor de teus perfumes, eu ainda não corria atrás de ti. Eis que redobrava minhas lágrimas ao ouvir teus cânticos. Outrora eu suspirava por ti, e enfim respirava o pouco ar de uma choça de feno (alusão ao profeta Isaias,40,6)