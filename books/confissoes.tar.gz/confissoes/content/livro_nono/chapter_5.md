## CAPÍTULO V

### O conselho de Ambrósio

 Terminadas as férias, informei aos milaneses que providenciassem para seus estudantes outro vendedor de palavras, visto que determinara consagrar-me a teu serviço; e mesmo porque não podia mais exercer aquela profissão pela dificuldade de respirar e pelas dores que sentia no peito.

 Também comuniquei por escrito a teu bispo e santo bispo Ambrosio, os meus antigos erros, minha intenção atual, para que me indicasse o que deveria ler de preferência em tuas Escrituras, a fim de me preparar e dispor melhor para receber tão grande graça.

 Ele me indicou o profeta Isaías, creio que porque anuncia mais claramente que os demais o Evangelho e vocação dos gentios. Contudo, nada tendo compreendido na primeira leitura, e julgando que toda a obra era assim, decidi voltar a ela quando estivesse mais familiarizado com a palavra do Senhor.