## CAPÍTULO I

### Colóquio

 Ó Senhor, sou teu servo e filho de tua serva. Rompeste minhas cadeias: eu te sacrificarei uma vítima de louvor. Louvem-te meu coração e minha língua, e que todos os meus ossos te digam: Senhor, quem semelhante a ti? Que eles te digam essas palavras e que me respondas e digas à minha alma: Eu sou tua salvação.

 Quem sou eu, e como era? Que males não tive em minhas obras, ou, se não em minhas obras, em minhas palavras, ou, se não em minhas palavras, em minha vontade! Mas tu, Senhor, bom e misericordioso, puseste os olhos na profundeza de minha morte, e purificaste com tua destra o abismo de corrupção de minha alma. Tratava-se agora apenas de não querer o que eu queria, e de querer o que tu querias.

 Mas, onde esteve meu livre arbítrio durante tantos anos? De que profundo e misterioso abismo foi ele chamado num instante, para que eu inclinasse a cerviz a teu jugo suave e o ombro a teu leve fardo, ó Cristo Jesus, meu auxílio e redenção?

 Quão suave foi para mim a privação de doçuras fúteis! Temia então perdê-las, como agora sentia prazer em deixa-las! Porque tu se afastavas de mim, e entravas em seu lugar, mais doce que qualquer prazer, mas não para a carne e o sangue; mais claro que toda luz, mais oculto que qualquer segredo; mais sublime que todas as honras, mas não para os que exaltam a si mesmos. Minha alma já estava livre dos devoradores cuidados da ambição, do ganho, e do prurido dos apetites carnais; e falava muito comigo, ó Deus e Senhor meu, minha luz, minha riqueza, minha salvação!