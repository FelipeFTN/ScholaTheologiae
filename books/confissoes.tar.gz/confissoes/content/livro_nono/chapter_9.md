## CAPÍTULO IX

### Esposa e mãe exemplar

 Educada assim na modéstia e na temperança, mais sujeita a seus pais pela tua mão que por seus pais a ti, logo que chegou à idade núbil, foi dada em matrimônio a um homem, a quem serviu como a senhor. Procurou conquistá-lo para ti, falando0lhe de ti com suas virtudes, com as quais tu a tornavas bela e reverentemente amável e admirável ante seus olhos. Suportou suas infidelidades conjugais com tanta paciência, que jamais teve com ele a menor briga por isso, pois esperava que tua misericórdia viria sobre ele, e que lhe trouxesse, com a fé, a castidade.

 Seu marido, se de um lado era sumamente afetuoso, por outro era extremamente colérico, mas ela tinha o cuidado de não contrariá-lo nem com ações, nem com palavras, se o visse irado. Logo que o via calmo e sossegado, oportunamente, mostrava-lhe o que havia feito, se por acaso se tivesse irritado desmedidamente.

 Muitas senhoras, embora tendo maridos mais calmos, traziam no rosto as marcas das pancadas que as desfiguravam. Conversando entre amigas, lamentavam a conduta dos maridos. Minha mãe reprovava-lhes a língua e, como por gracejo, lembrava-lhes que, desde a leitura do contrato matrimonial, deviam considerá-lo como documento que as tornava servas, e portanto proibia-lhes de serem altivas com seus senhores. Essas senhoras, que conheciam o mau gênio de seu marido, admiravam-se de que jamais ninguém tivesse ouvido ou percebido qualquer indício que Patrício maltratasse a mulher, nem sequer que algum dia tivessem brigado por questões domésticas. E como lhe pedissem confidencialmente a razão disso, minha mãe expunha-lhes seu agir habitual, como acima mencionei. Algumas, após experimentar, punham-no em prática e davam-lhe graças; as que não a imitavam continuavam a sofrer humilhações e violências.

 Sua sogra, a princípio irritara-se contra ela por causa dos mexericos de criadas malévolas. Mas conseguiu conquistá-la com respeito, contínua tolerância e mansidão, que ela mesma, espontaneamente, denunciou ao filho as línguas intrigantes das criadas, que perturbavam a paz doméstica entre ela e a nora, e pediu que as castigasse. Ele, em obediência à mãe, para manter a disciplina familiar e a harmonia entre os seus, mandou açoitar as acusadas, segundo a vontade da acusante; e esta prometeu-lhes ainda que esse era o prêmio que devia esperar quem, querendo agradá-la, lhe dissesse mal da nora. E ninguém mais se atreveu a fazê-lo, e viveram as duas em doce e memorável harmonia.

 A esta tua boa serva, em cujo seio me criaste, ó meu deus, minha misericórdia, dotaste de outra grande virtude: a de intervir como pacificadora, sempre que podia, nas discórdias e querelas. Daquilo que ouvia de queixas amargas, vomitadas com animosidade ressentida, quando na presença de uma amiga os ódios mal digeridos se desafogam em amargas confidencias a respeito de uma amiga ausente, ela nada referia uma à outra, senão o que poderia servir para a reconciliação.

 Este dom me pareceria de pouca monta se uma triste experiência não me houvesse mostrado grande número de pessoas – por não sei que horrível contagio de pecados, espalhados por toda parte – que não só revelam as palavras pesadas de inimigos irados, mas que ainda acrescentam coisas que não foram ditas. Quem fosse realmente humano, deveria ter em pouca conta ou não excitar nem fomentar as inimizades dos homens, e melhor ainda procurar extinguilas com boas palavras.

Assim era minha mãe, ensinada por ti, mestre interior, na escola de seu coração.

 Por fim, conquistou para ti o seu marido, já no fim da vida, não tendo que lamentar no cristão o que havia tolerado no infiel.

 Ela era verdadeiramente a serva de teus servos, e todos os que a conheciam te louvavam, honravam, te amavam em sua pessoa, porque percebiam tua presença em seu coração, confirmada pelos frutos de uma vida santa.

 Havia sido mulher de um só homem, cumprira sua dívida de gratidão com os pais, governara sua casa piedosamente e dava testemunho com suas boas obras. Educara os filhos, dando-os à luz tantas vezes quantas os via apartarem-se de ti.

 E de nós, que nos chamamos teus servos por liberalidade tua, nós que vivemos em comum na graça de teu batismo, antes de adormecer em tua paz, ela cuidou de nós como se todos fôssemos seus filhos, e de tal modo nos serviu como se fosse filha de cada um de nós.