# LIVRO NONO

## CAPÍTULO I

### Colóquio

 Ó Senhor, sou teu servo e filho de tua serva. Rompeste minhas cadeias: eu te sacrificarei uma vítima de louvor. Louvem-te meu coração e minha língua, e que todos os meus ossos te digam: Senhor, quem semelhante a ti? Que eles te digam essas palavras e que me respondas e digas à minha alma: Eu sou tua salvação.

 Quem sou eu, e como era? Que males não tive em minhas obras, ou, se não em minhas obras, em minhas palavras, ou, se não em minhas palavras, em minha vontade! Mas tu, Senhor, bom e misericordioso, puseste os olhos na profundeza de minha morte, e purificaste com tua destra o abismo de corrupção de minha alma. Tratava-se agora apenas de não querer o que eu queria, e de querer o que tu querias.

 Mas, onde esteve meu livre arbítrio durante tantos anos? De que profundo e misterioso abismo foi ele chamado num instante, para que eu inclinasse a cerviz a teu jugo suave e o ombro a teu leve fardo, ó Cristo Jesus, meu auxílio e redenção?

 Quão suave foi para mim a privação de doçuras fúteis! Temia então perdê-las, como agora sentia prazer em deixa-las! Porque tu se afastavas de mim, e entravas em seu lugar, mais doce que qualquer prazer, mas não para a carne e o sangue; mais claro que toda luz, mais oculto que qualquer segredo; mais sublime que todas as honras, mas não para os que exaltam a si mesmos. Minha alma já estava livre dos devoradores cuidados da ambição, do ganho, e do prurido dos apetites carnais; e falava muito comigo, ó Deus e Senhor meu, minha luz, minha riqueza, minha salvação!

## CAPÍTULO II

### Adeus ao magistério

 Pareceu-me de bom alvitre, em tua presença, não abandonar de modo ostensivo o ministério da minha língua, mas retirá-lo suavemente do mercado da loquacidade, para que dali por diante os jovens, que não se preocupam com tua lei ou paz, mas com as enganosas loucuras e contendas forenses, não comprassem de minha boca armas para seu furor. Felizmente faltavam pouquíssimos dias para as férias das vindimas (é provável que as férias de outono dos estudantes coincidissem com as férias dos tribunais, que se iniciavam em 22 de agosto, e terminavam em 15 de outubro). Decidi suportá-los até lá. Então me retiraria como de costume, e, resgatado por ti, não tornaria mais a vender meu ofícios.

 Esta minha determinação, te era conhecida; dos homens, só a conheciam os de minha intimidade. E, mesmo assim, tínhamos combinado de nada deixar transpirar. Contudo, quando subíamos do vale de lágrimas, cantando o cântico gradual (série de salmos cantados pelos peregrinos que sobem os degraus do templo de Jerusalém) nos tinhas dado setas agudas e carvões destruidores contra a língua pérfida que contradiz, sob o pretexto de aconselhar e, como quem se alimenta, consome o que ama.

 Tinhas alvejado nosso coração com as setas do teu amor, e levávamos tuas palavras cravadas em nossas entranhas; os exemplos de teus servos, que das trevas trouxeram para a luz, e da morte para a vida, ardiam no fundo de nosso espírito em uma espécie de fogueira, que inflamava e consumia nosso torpor, para que não mais nos inclinássemos para as baixezas. Estávamos inflamados de tal ardor, que o vento da contradição das línguas dolosas não nos apagaria, antes fazia-nos arder mais e mais.

 Contudo, por causa de teu nome, que santificaste em toda terra, nossa decisão e propósito teriam também quem os louvasse. Pareceria de certo modo jactância não aguardar as férias tão próximas; abandonar antes dessa data uma profissão pública, e exposta a todos, seria atrair sobre minha conduta todas as atenções, provocando comentários. Diriam que eu me adiantara às férias iminentes por querer parecer grande personagem. E de que me valeria que pensassem ou discutissem sobre minhas intenções, blasfemando sobre o meu bem?

 Além disso, nesse mesmo verão, devido ao excessivo trabalho didático, meus pulmões começaram a se ressentir; respirava com dificuldade, e as dores no peito e minha voz, que não saía clara ou prolongada, revelavam uma lesão. A princípio me senti angustiado, vendo-me quase obrigado a abandonar o fardo do magistério ou, para me curar e convalescer, teria certamente de o interromper. Mas, quando nasceu em mim e se firmou a vontade plena de repousar e de ver que és o Senhor, então, tu o sabes meu Deus, que cheguei a me alegrar de encontrar esta desculpa verdadeira para moderar o sentimento das famílias, que por causa de seus filhos nunca me permitiram ser livre.

 Cheio dessa consolação, esperava que escoasse aquele tempo – talvez uns vinte dias. Mas minguara minha coragem, porque já me abandonara a cobiça de ganho, que me ajudava a carregar este pesado encargo; e teria sucumbido se a paciência não tomasse o lugar da ambição.

 Talvez alguns de teus servos, meus irmãos, dirá que pequei nisso porque, estando com o coração já cheio de desejos de te servir, consenti ficar mais uma hora sentado na cátedra da mentira. Não discutirei. Mas tu, Senhor misericordiosíssimo, acaso não me perdoaste e resgataste também este pecado, junto com todos os demais horrendos e mortais na água santa do batismo?

## CAPÍTULO III

### Dois amigos

Angustiava-se Verecundo por este nosso bem, porque se via afastado de nossa companhia pelos vínculos matrimoniais que o aprisionavam fortemente. Não era ainda cristão, como sua mulher, mas justamente nela encontrava o maior obstáculo que o impedia de entrar pelo caminho que havíamos começado a trilhar; não queria ser cristão, dizia ele, senão do modo que justamente lhe era proibido.

 Contudo, com sua grande bondade, pôs à nossa disposição sua propriedade no campo pelo tempo que nos aprouvesse. Tu, Senhor, haverás de recompensá-lo no dia da retribuição dos justos, pois já concedeste a graça. Porque, estando nós ausentes e já em Roma, atacado de uma enfermidade corporal, Verecundo saiu desta vida depois de se fazer cristão e crente. Assim te compadeceste não apenas dele, mas também de nós, para que quando pensássemos na grande generosidade que teve conosco este amigo, não nos afligíssemos de dor intolerável por não poder contá-lo entre os de tua grei.

 Graças te sejam dadas, ó Deus nosso! Somos teus: tuas exortações e consolos o indicam. Fiel cumpridor de tuas promessas, concedes a Verecundo a amenidade de teu paraíso sempre florido, por nos ter oferecido sua propriedade de Cassicíaco, na qual descansamos em ti das angústias do século; lhe perdoaste os pecados sobre a terra, na tua montanha, a montanha da abundância.

 Verecundo, como disse, angustiava-se, mas Nebrídio partilhava a nossa alegria, porque, embora não sendo ainda cristão e houvesse caído no erro tão pernicioso de julgar que a carne verdadeira do teu Filho fosse mera aparência, já começava a se desvencilhar e, sem ter ainda recebido os sacramentos da tua Igreja, buscava ardentemente a verdade.

 Não muito depois de nossa conversão e regeneração por teu batismo, fez-se por fim católico fiel. Servia-te na África junto aos seus, em castidade e continência perfeitas; toda sua família, sob sua influência, se fizera cristã. Libertaste-o então dos laços da carne, vivendo agora no seio de Abraão, seja qual for o significado dessa expressão. Ali vive meu Nebrídio, meu doce amigo que, de liberto, se tornou teu filho adotivo. Ali vive – pois, que outro lugar conviria a uma alma assim? Ali vive, nesse lugar sobre o qual indagava muitas coisas a mim, pobre homem ignorante. Já não aproxima seu ouvido da boca, mas aproxima sua boca espiritual de tua fonte, e bebe avidamente de tua sabedoria, numa felicidade sem fim. Mas não creio que se embriague a ponto de esquecer de mim, enquanto tu, Senhor, que és sua bebida, te lembras de nós.

 Essa era a nossa situação. Consolávamos o Verecundo que, sem que a amizade fenecesse, andava desgostoso com nossa conversão; nós o exortávamos a se manter fiel à sua condição conjugal. Quanto a Nebrídio, esperávamos que nos seguisse, pois, facilmente poderia fazê-lo, e já estava a ponto de se decidir. Enfim, aqueles dias passaram, e me pareceram tantos e tão longos, tal era meu desejo de liberdade e descanso, para cantar do fundo do meu ser: A ti meu coração: Procurei teu rosto; teu rosto, Senhor, hei de buscar.

## CAPÍTULO IV

### A doçura dos salmos

 Por fim, chegou o dia da libertação da profissão de retórico, da qual já me libertara em pensamento. Assim aconteceu. Livraste minha língua da tarefa de que há havias livrado meu coração. Eu te bendizia contente, e parti com todos os meus, para a quinta de Verecundo. O que lá realizei nas letras, já a teu serviço, mas ainda com a respiração ofegante, como durante uma pausa da luta, e ainda respirando da soberba da erudição, é atestado pelos livros nos quais anotava meus debates com meus amigos ou comigo mesmo em tua presença (refere-se aos seguintes livros: Contra Acadêmicos, De beata vita, De ordine e dos Solilóquios). Do que tratei com Nebrídio, então ausente, claramente o indicam minhas cartas.

 Mas quando encontrei tempo suficiente para dar testemunho de todos os grandes benefícios que me concedeste nessa época da vida, uma vez que tenho pressa de chegar a outros assuntos mais importantes? Volta-me – e me é doce confessá-lo, Senhor – a lembrança dos estímulos internos com que me domaste; o modo como me aplanaste a alma derrubando as colinas e montanhas de meus pensamentos; como endireitaste meus caminhos tortuosos e suavizasse minhas asperezas; como também submeteste Alípio – o irmão de meu coração – ao nome de teu Filho único, Jesus Cristo, Senhor e Salvador nosso, nome que ele mal suportava em minhas obras, porque preferia o cheiro dos soberbos cedros das escolas, já abatidos pelo Senhor, ao odor das salutares ervas de tua Igreja, antídoto contra o veneno das serpentes.

 Que invocações elevei a ti, meu Deus, lendo os Salmos de Davi, cânticos de fé, hinos de piedade, que expulsavam de mim todo sentimento de orgulho? Eu era ainda inexperiente de teu verdadeiro amor, e dividia minhas horas de lazer com Alípio, catecúmeno como eu. Minha mãe estava conosco. Ao aspecto da mulher ela aliava fé varonil, a calma da velhice, a ternura de mãe e a piedade de cristã. Que exclamações elevei a ti naqueles salmos, e como me inflamava com eles em teu amor! Incendiava-me em desejos de recitá-los, se fosse possível, ao mundo inteiro, para rebater a soberba do gênero humano! Com efeito, em todo o mundo se cantam. Não há ninguém que se subtraia a teu calor.

 Com que veemente e dolorosa indagação me levantava contra os maniqueístas! E de novo me compadecia deles por ignorarem esses sacramentos, esses remédios, investindo loucamente contra o antídoto que poderia curá-los! Gostaria que estivessem perto de mim, sem que eu o soubesse, e que vissem meu rosto e ouvissem minhas exclamações quando lia o Salmo 4 naquelas minhas férias, e percebessem os efeitos salutares que me produzia este salmo: Quando te invoquei, tu me escutaste, ó Deus de minha justiça! Dilataste minha alma na tribulação. Compadece-te, Senhor, de mim, e ouve minha prece. Se me ouvissem – sem eu o saber, para que não pensassem que eram por causa deles as palavras que eu entremeava às do salmo, porque realmente nem eu diria tais coisas, nem as diria daquele modo, se soubesse da sua presença; e, mesmo que as palavras fossem as mesmas, ele não as entenderiam como eu as dizia a mim mesmo, diante de ti, na íntima efusão dos afetos de minha alma.

 Estremeci de medo, ao mesmo tempo me abrasei de alegre esperança em tua misericórdia, ó Pai! E todos estes sentimentos saíam pelos meus olhos e pela voz quando, dirigindo-se para nós, teu Espírito de bondade nos dizia: Filhos dos homens, até quando sereis duros de coração? Por que amais a vaidade e buscais a mentira?

 Também eu tinha amado a vaidade e buscado a mentira. Mas tu, Senhor, já havias glorificado teu eleito, ressuscitando-o de entre os mortos e colocando-o à tua direita, de onde haveria de nos enviar, segundo a promessa, o Paráclito, o Espírito da Verdade. O Senhor estava glorificado, ressuscitando de entre os mortos, e subindo aos céus. Antes o Espírito ainda não tinha sido dado, porque Jesus ainda não tinha sido glorificado.

 Clama o profeta: Até quando sereis duros de coração? Por que amais a vaidade e buscais a mentira? Sabeis que o Senhor já glorificou a seu santo. Clama: Até quando? Clama: Sabei! – E eu sem o saber durante tanto tempo, amando a vaidade e buscando a mentira!

 Por isso tremi quando o ouvi, porque me lembrei de ter sido igual àqueles a quem tais palavras eram dirigidas. Os fantasmas que eu havia tomado pela verdade nada mais eram do que vaidade e mentira.

 Ah! As queixas fortes e profundas que me inspiravam a dor da recordação! Oxalá as tivessem ouvido os que ainda amam a vaidade e buscam a mentira! Talvez também se perturbassem e vomitassem seu erro. E tu os terias ouvidos quando clamassem por ti, porque morreu por nós de verdadeira morte corporal aquele que intercede por nós diante de ti.

 Eu lia: Irai-vos, e não queirais pecar. Como me perturbavam tais palavras, meu Deus! Já havia aprendido a me irar contra mim mesmo pelos meus crimes passados, para não pecar mais; e de uma cólera justa, porque não era uma natureza estranha, da raça das trevas, a que em mim pecava, como dizem os que não se indignam contra si, e acumulam contra si a ira para o dia da ira e da revelação de teu justo juízo?

 Meus bens já não eram exteriores, e eu já não os buscava à luz deste sol, com olhos carnais. Os que querem gozar externamente, facilmente se dissipam e derramam pelas coisas visíveis e temporais, lambendo com pensamento faminto apenas as aparências. Oh! Se eles se esgotassem com a privação, e perguntassem: Quem nos mostrará o bem? E que ouvissem nossa resposta: Está gravada dentro de nós a luz de teu rosto, Senhor! – Porque não somos nós a luz que ilumina a todo homem, mas somos iluminados por ti, para que sejamos luz em ti, nós que outrora fomos trevas.

 Oh! Se eles vissem essa luz interior e eterna que eu havia visto! E como a havia saboreado, irritava-me por não poder mostrá-la. Se, pelo seus olhares dirigidos para fora, visse seu coração afastado de ti, me dissessem: "Quem nos mostrará o bem? Pois ali, onde me irritara contra mim mesmo, ali, no recôndito de meu coração onde, arrependido, eu havia sacrificado e imolado em mim o velho homem; onde, pondo em ti minha esperança, começara a meditar a renovação de mim mesmo, ali fizeste com que eu sentisse tua doçura, dando alegria a meu coração. E exclamava ao ler, fora de mim, essas palavras cuja verdade ecoava em mim; e não queria desdobrar-me pelos bens terrenos, devorando o tempo e sendo por ele devorado, porque possuía na eterna simplicidade outro trigo, outro vinho e outro azeite.

 E subia, no versículo seguinte, um profundo clamor de meu coração: Oh! Em paz! Oh! Em seu próprio Ser! Mas, que disse? Dormirei e descansarei! Com efeito, quem nos há de resistir quando se cumprir a palavra que está escrita: A morte foi devorada pela vitória?

 Tu és esse mesmo Ser, e não mudas, e em ti está o repouso que faz esquecer todos os sofrimentos. Porque ninguém pode ser comparado a ti e nem vale pensar em adquirir outras coisas que não sejam o que tu és; mas tu, Senhor, singularmente me firmaste na esperança.

 Eu lia isto, e me inflamava. Não sabia que fazer com aqueles surdos, de quem eu fora a peste, um cão raivoso e cego que ladrava contra a Bíblia, dulcificada por seu mel celestial e iluminada por tua luz. E me consumia de dor por causa dos inimigos de tuas Escrituras.

 Quando poderei recordar tudo o que aconteceu naqueles dias de descanso? Mas não esqueci, nem quero silenciar, a aspereza de um açoite que usaste em mim, e a admirável presteza de tua misericórdia.

 Atormentavas-me então com uma dor de dentes, que se agravara a tal ponto de me impedir até de falar. Ocorreu-me ao pensamento pedir a todos os amigos, que rogassem por mim, ó Deus da salvação! Escrevi meu pedido numa tabuleta encerada, e lha dei para que o lessem. Apenas dobramos os joelhos com suplicante afeto, logo a dor desapareceu. E que dor! E como desapareceu! Enchi-me de espanto, eu o confesso, meu Deus e Senhor. Nunca, desde minha infância, havia experimentado coisa semelhante.

 No fundo de meu coração penetrou o sinal da tua vontade e, alegre na fé, louvei teu nome. contudo, esta fé não me deixava viver tranqüilo quanto a meus pecados passados, que ainda não me haviam sido perdoados por teu batismo.

## CAPÍTULO V

### O conselho de Ambrósio

 Terminadas as férias, informei aos milaneses que providenciassem para seus estudantes outro vendedor de palavras, visto que determinara consagrar-me a teu serviço; e mesmo porque não podia mais exercer aquela profissão pela dificuldade de respirar e pelas dores que sentia no peito.

 Também comuniquei por escrito a teu bispo e santo bispo Ambrosio, os meus antigos erros, minha intenção atual, para que me indicasse o que deveria ler de preferência em tuas Escrituras, a fim de me preparar e dispor melhor para receber tão grande graça.

 Ele me indicou o profeta Isaías, creio que porque anuncia mais claramente que os demais o Evangelho e vocação dos gentios. Contudo, nada tendo compreendido na primeira leitura, e julgando que toda a obra era assim, decidi voltar a ela quando estivesse mais familiarizado com a palavra do Senhor.

## CAPÍTULO VI

### Batismo de Agostinho. Seu filho Adeodato

 Chegado o tempo em que convinha nos inscrever para receber o batismo, deixamos o campo, e voltamos para Milão.

 Alípio também quis renascer em ti comigo, já revestido de humildade tão conforme a teus sacramentos. Era tão enérgico domador do seu corpo, que caminhava com os pés descalços, com insólita coragem, sobre o chão gelado da Itália.

 Juntamos também a nós o jovem Adeodato, filho carnal de meu pecado; a quem dotaste de grandes qualidades. Tinha cerca de quinze anos, mas por seu talento ultrapassava já muitos homens maduros e doutos. Confesso-te que eram dons teus, meu Senhor e meu Deus, criador de todas as coisas, tão poderoso para corrigir nossas deformidades, pois este menino nada havia de meu, senão meu pecado. Se o criei em tua disciplina, foste tu, e mais ninguém, quem no-lo inspirou. Sim, confesso que eram dons teus.

 Há um livro meu que se intitula O Mestre, no qual Adeodato dialoga comigo. Tu sabes que todos os pensamentos ali manifestados são dele quando tinha dezesseis anos. Muitas outras qualidades maravilhosas notei ainda nele, admirado por sua inteligência. Mas quem, além de ti, poderia ser o autor dessas maravilhas? Cedo o arrebataste desta terra; e a lembrança dele se torna mais tranqüila, nada mais tendo a temer por sua infância, por sua adolescência ou por toda sua vida adulta. Associamo-lo a nós como irmão na graça, para educá-lo em tua lei. Fomos batizados, e os remorsos de nossa vida passada se afastaram de nós.

 Naqueles dias eu não me fartava de considerar a grandeza de teus desígnios para a salvação do gênero humano, pela inefável doçura que sentia. Quanto chorei ao ouvir, profundamente comovido, teus hinos e cânticos que ressoavam suavemente em tua Igreja! Penetravam aquelas vozes em meus ouvidos, e destilavam a verdade em meu coração. Acendiase em mim um afeto piedoso, corriam-me lágrimas dos olhos, e o pranto me consolava.

## CAPÍTULO VII

### O canto dos fiéis. Os corpos de São Gervásio e de São Protásio

 Não havia muito tempo que a igreja de Milão começara a adotar essa prática consoladora e edificante do canto, com grande regozijo dos fiéis, que uniam em um só coro as vozes e o coração. Havia um ano, ou pouco mais, que Justina, mãe do imperador Valentiniano, ainda menor, seduzida pelos arianos, perseguia, por causa de sua heresia, teu servo Ambrósio. O povo fiel passava as noites na igreja, disposto a morrer com seu bispo.

 Nesse meio estava minha mãe, tua serva, uma das primeiras no zelo dessas inquietações e vigílias, não vivendo senão de orações. Nós, apensar de ainda frios, sem o calor de teu Espírito, nos sentíamos comovidos pela perturbação e consternação da cidade.

 Foi então que se fixou o costume de cantar hinos e salmos, como se faz no Oriente, para que os fiéis não se consumissem no tédio e na tristeza. Desde esse dia esse costume mantevese, e no resto do mundo, quase todas as tuas comunidades de fiéis passaram a adotá-lo.

 Foi também nessa época que revelaste em sonho ao bispo Ambrósio o lugar em que jaziam ocultos os corpos dos mártires Gervásio e Protásio, que durante muito tempo, conservastes intactos no tesouro de teus segredos, a fim de revelá-los no momento oportuno para refrear o furor de uma mulher, embora imperatriz.

 Com efeito, depois de descobertos e desenterrados, ao serem transladados com as honras convenientes para a basílica ambrosiana, alguns possessos, atormentados pelos espíritos imundos, foram curados, conforme confissão dos próprios demônios. Também um cidadão, cego havia muitos anos, e muito conhecido na cidade, perguntou a razão daquele alvoroço e alegria populares; informado, pediu a seu guia que o levasse até ás relíquias. Lá chegando, obteve permissão para tocar com um lenço o ataúde de teus santos, cuja morte havia sido preciosa a teus olhos. Feito isto, aplicou o lenço aos olhos, que imediatamente se abriram.

 A noticia do milagre logo se propagou, e imediatamente se ouviram teus louvores com fervor, e o coração de tua inimiga, sem se converter à tua fé, reprimiu contudo o furor da perseguição.

 Graças te dou, meu Deus! De onde e para onde guiaste minha memória, para que também te confessasse estes acontecimentos que, embora grandes, eu já havia esquecido e omitido?

 Todavia, quando assim exalava o odor de teus perfumes, eu ainda não corria atrás de ti. Eis que redobrava minhas lágrimas ao ouvir teus cânticos. Outrora eu suspirava por ti, e enfim respirava o pouco ar de uma choça de feno (alusão ao profeta Isaias,40,6)

## CAPÍTULO VIII

### Mônica

 Tu, que fazes morar na mesma casa os que têm coração unânime, trouxeste pra junto de nós Evódio, jovem de nosso município que, militando como agente de negócios do imperador, se convertera e recebera o batismo antes de nós, abandonara a milícia do século, alistando-se na tua.

 Estávamos juntos, e juntos pensávamos viver nosso santo propósito. Buscávamos um lugar onde nos pudéssemos instalar mais comodamente para te servir e juntos rumávamos para a África quando, chegando a Óstia, na foz do Tibre, faleceu minha mãe.

 Muitas coisas passo em silêncio, porque tenho pressa. Recebe minhas confissões e ações de graças, meu Deus, pelas inúmeras bondades que não menciono aqui. Mas não quero calar o que brota de minha alma a respeito desta tua serva, que me gerou na carne para a luz temporal, e no coração para a luz eterna. Não referirei suas qualidades, nem a si mesma se havia educado. Foste tu quem a educaste, nem seu pai, nem sua mãe sabiam o que viriam a ser aquela a quem geraram. A disciplina de teu Cristo, a doutrina de teu Filho único educaram-na em teu temor em uma família fiel, digno membro de tua Igreja.

 Nem ela mesma enaltecia o zelo da mãe em educá-la, quanto o de uma velha serva, que carregara seu pai quando menino, como hoje as meninas maiores costumam carregar as crianças, às costas.

 Estas recordações, sua idade avançada e hábitos exemplares lhe asseguravam naquela casa cristã o respeito de seus amos. Ela própria cuidava solicitamente das meninas que lhe haviam sido confiadas, ora repreendendo-as quando fosse o caso, com santa e enérgica severidade, ora instruindo-as com discreta prudência. Afora do horário em que tomavam uma sóbria refeição à mesa de seus pais, ainda que tivessem muita sede, nem água permitia que elas bebessem, precavendo com isso um mau costume. E acrescentava este sábio aviso: "Agora bebeis água, porque não tendes como beber vinho; mas quando estiverdes casadas, donas da despensa e da adega, deixareis a água, mas continuará o hábito de beber".

 E unindo assim o conselho à autoridade, refreava os apetites daquela tenra idade, e acostumava aquelas jovens à temperança, para que não tivesse desejo do que não lhes convinha.

 No entanto – como tua serva me contou a mim, seu filho – insinuou-se nela certo gosto pelo vinho. Julgando-a menina sóbria, seus pais a escolheram, como era costume, para tirar o vinho do tonel. Mergulhava a caneca pela parte superior do recipiente e, antes de passar o vinho para a garrafa, sorvia com a ponta dos lábios um pouquinho; era-lhe impossível beber mais, porque o vinho lhe repugnava. Não fazia isto movida pela inclinação à embriaguez, mas pela exuberância juvenil, que se manifestava em movimentos, em brincadeiras, e que na meninice costumam ser reprimidos pela autoridade severa dos mais velhos. Mas, acrescentando todos os dias uns goles àqueles goles – pois quem descuida das coisas pequenas pouco a pouco cai nas maiores – acostumou-se a esvaziar avidamente copos quase cheios de vinho puro.

 Onde estava então a prudente anciã, e sua severa proibição? Mas que remédio curaria um mal oculto se tua medicina, Senhor, não velasse sobre nós? Na ausência do pai, da mãe e das amas, estavas lá tu que nos criaste, que nos chamas, e que por meio dos que nos educam fazes o bem para a salvação das almas. Que fizeste então, meu Deus? Como a socorreste? Como a curaste? Fizeste sair de outra pessoa, segundo tuas secretas providências, um sarcasmo duro e pungente como ferro medicinal, para curar de um só golpe aquela gangrena.

 A criada que costumava acompanhá-la à adega, discutindo com sua jovem senhora, como às vezes acontece, estando as duas a sós, lançou-lhe em rosto sua intemperança, chamando-a insultuosamente de bêbada. Ferida por esse sarcasmo, a jovem reconheceu a fealdade daquele hábito, reprovou-o, e no mesmo instante o abandonou.

 Assim como muitas vezes as lisonjas dos amigos nos pervertem, assim os insultos dos inimigos nos corrigem. Mas não é o bem que nos fazem por seu intermédio que retribuis, mas a intenção com que o fazem. Aquela criada zangada pretendia ofender sua jovem senhora, e não corrigi-la; e se o fez às escondidas foi só por força da circunstância do lugar e tempo, ou para que não viesse a sofrer por denunciar tão tarde o costume de sua senhora.

 Mas, tu, Senhor, governador do céu e da terra, que desvias para teus desígnios as águas da torrente e regulas o curso turbulento dos séculos, curaste a loucura de uma alma com a insânia de outra. Por isso ninguém, ao considerar o caso, atribua a seu poder pessoal o mérito de ter corrigido com suas palavras a alguém cuja emenda deseja conseguir.

## CAPÍTULO IX

### Esposa e mãe exemplar

 Educada assim na modéstia e na temperança, mais sujeita a seus pais pela tua mão que por seus pais a ti, logo que chegou à idade núbil, foi dada em matrimônio a um homem, a quem serviu como a senhor. Procurou conquistá-lo para ti, falando0lhe de ti com suas virtudes, com as quais tu a tornavas bela e reverentemente amável e admirável ante seus olhos. Suportou suas infidelidades conjugais com tanta paciência, que jamais teve com ele a menor briga por isso, pois esperava que tua misericórdia viria sobre ele, e que lhe trouxesse, com a fé, a castidade.

 Seu marido, se de um lado era sumamente afetuoso, por outro era extremamente colérico, mas ela tinha o cuidado de não contrariá-lo nem com ações, nem com palavras, se o visse irado. Logo que o via calmo e sossegado, oportunamente, mostrava-lhe o que havia feito, se por acaso se tivesse irritado desmedidamente.

 Muitas senhoras, embora tendo maridos mais calmos, traziam no rosto as marcas das pancadas que as desfiguravam. Conversando entre amigas, lamentavam a conduta dos maridos. Minha mãe reprovava-lhes a língua e, como por gracejo, lembrava-lhes que, desde a leitura do contrato matrimonial, deviam considerá-lo como documento que as tornava servas, e portanto proibia-lhes de serem altivas com seus senhores. Essas senhoras, que conheciam o mau gênio de seu marido, admiravam-se de que jamais ninguém tivesse ouvido ou percebido qualquer indício que Patrício maltratasse a mulher, nem sequer que algum dia tivessem brigado por questões domésticas. E como lhe pedissem confidencialmente a razão disso, minha mãe expunha-lhes seu agir habitual, como acima mencionei. Algumas, após experimentar, punham-no em prática e davam-lhe graças; as que não a imitavam continuavam a sofrer humilhações e violências.

 Sua sogra, a princípio irritara-se contra ela por causa dos mexericos de criadas malévolas. Mas conseguiu conquistá-la com respeito, contínua tolerância e mansidão, que ela mesma, espontaneamente, denunciou ao filho as línguas intrigantes das criadas, que perturbavam a paz doméstica entre ela e a nora, e pediu que as castigasse. Ele, em obediência à mãe, para manter a disciplina familiar e a harmonia entre os seus, mandou açoitar as acusadas, segundo a vontade da acusante; e esta prometeu-lhes ainda que esse era o prêmio que devia esperar quem, querendo agradá-la, lhe dissesse mal da nora. E ninguém mais se atreveu a fazê-lo, e viveram as duas em doce e memorável harmonia.

 A esta tua boa serva, em cujo seio me criaste, ó meu deus, minha misericórdia, dotaste de outra grande virtude: a de intervir como pacificadora, sempre que podia, nas discórdias e querelas. Daquilo que ouvia de queixas amargas, vomitadas com animosidade ressentida, quando na presença de uma amiga os ódios mal digeridos se desafogam em amargas confidencias a respeito de uma amiga ausente, ela nada referia uma à outra, senão o que poderia servir para a reconciliação.

 Este dom me pareceria de pouca monta se uma triste experiência não me houvesse mostrado grande número de pessoas – por não sei que horrível contagio de pecados, espalhados por toda parte – que não só revelam as palavras pesadas de inimigos irados, mas que ainda acrescentam coisas que não foram ditas. Quem fosse realmente humano, deveria ter em pouca conta ou não excitar nem fomentar as inimizades dos homens, e melhor ainda procurar extinguilas com boas palavras.

Assim era minha mãe, ensinada por ti, mestre interior, na escola de seu coração.

 Por fim, conquistou para ti o seu marido, já no fim da vida, não tendo que lamentar no cristão o que havia tolerado no infiel.

 Ela era verdadeiramente a serva de teus servos, e todos os que a conheciam te louvavam, honravam, te amavam em sua pessoa, porque percebiam tua presença em seu coração, confirmada pelos frutos de uma vida santa.

 Havia sido mulher de um só homem, cumprira sua dívida de gratidão com os pais, governara sua casa piedosamente e dava testemunho com suas boas obras. Educara os filhos, dando-os à luz tantas vezes quantas os via apartarem-se de ti.

 E de nós, que nos chamamos teus servos por liberalidade tua, nós que vivemos em comum na graça de teu batismo, antes de adormecer em tua paz, ela cuidou de nós como se todos fôssemos seus filhos, e de tal modo nos serviu como se fosse filha de cada um de nós.

## CAPÍTULO X

### O êxtase de Óstia

 Estando já próximo o dia em que teria de partir desta vida – que tu, Senhor, conhecias, e nós ignorávamos – sucedeu, creio, por disposição de teus ocultos desígnios – que nos encontrássemos sós, eu e ela, apoiados em uma janela que dava para o jardim interior da casa em que morávamos. Era em Óstia, sobre a foz do Tibre, onde, longe da multidão, depois do cansaço de uma longa viagem, recobrávamos forças para a travessia do mar.

 Ali, sozinhos, conversávamos com grande doçura, esquecendo o passado, ocupados apenas no futuro, indagávamos juntos, na presença da Verdade, que és tu, qual seria a vida eterna dos santos, que nem os olhos viram, nem os ouvidos ouviram, nem o coração do homem pode conceber. Abríamos ansiosos os lábios de nosso coração ao jorro celeste de tua fonte – da fonte da vida que está em ti – para que, banhados por ela, pudéssemos de algum modo meditar sobre coisa tão transcendente.

 Nossa conversa chegou à conclusão que nenhum prazer dos sentidos carnais, por maior que seja, e por mais brilhante e maior que seja a luz material que o cerca, não parece digno de ser comparado à felicidade daquela vida em ti. Elevando nosso sentimento para mais alto, mais ardentemente em direção ao próprio Ser, percorremos uma a uma todas as coisas corporais, até o próprio céu, de onde o sol, a luz e as estrelas iluminam a terra.

 E subimos ainda mais em espírito, meditando, celebrando e admirando tuas obras, e chegamos até o íntimo de nossas almas. E fomos além delas, para alcançar a região da abundância inesgotável, onde apascentas eternamente a Israel com o alimento da verdade, lá onde a vida é a própria Sabedoria, por quem foram criadas todas as coisas, as que já existem e as vindouras, sem que ela própria se crie a si mesma, pois existe agora como antes existiu e como sempre existirá. Antes, nela não há nem passado, nem futuro: ela apenas é, porque é eterna; mas ter sido ou haver de ser não é próprio do ser eterno.

 E enquanto assim falávamos dessa Sabedoria e por ela suspirávamos, chegamos a tocá-la momentaneamente com supremo ímpeto de nosso coração; e, suspirando, deixando ali atadas as primícias de nosso espírito, e voltamos ao ruído vazio de nossos lábios, onde nasce e morre a palavra humana, em nada semelhante a teu Verbo, Senhor nosso, que subsiste em si sem envelhecer, renovando todas as coisas!

 E dizíamos: Suponhamos que se calasse o tumulto da carne, as imagens da terra, da água, do ar e até dos céus; e que a própria alma se calasse, e se elevasse sobre si mesma não pensando mais em si; se calassem os sonhos e revelações imaginarias e, por fim, se calasse por completo toda língua, todo sinal, e tudo o que é fugaz – uma vez que todas as coisas dizem a quem sabe ouvi-las: Não fizemos a nós mesmas; fez-nos o que permanece eternamente – se, dito isto, todas se calassem, atentas a seu Criador; e se só ele falasse, não por suas obras, mas por si mesmo, de modo que ouvíssemos sua palavra, não por uma língua material, nem pela voz de um anjo, nem pelo ruído do trovão, nem por parábolas enigmáticas, mas o ouvíssemos a ele mesmo, a quem amamos nas suas criaturas, mas sem o intermédio delas, como agora acabamos de experimentar, atingindo em um relance a eterna Sabedoria, que permanece imutável sobre toda realidade, e supondo que essa visão se prolongasse, que todas as outras visões cessassem, e unicamente esta arrebatasse a alma de seu contemplador, e a absorvesse e abismasse em íntimas delícias, de modo que a vida eterna seja semelhante a este momento de intuição que nos fez suspirar, não seria isto a realização do entrar em gozo de teu Senhor? Mas quando se dará isto? Por acaso quando todos ressuscitarmos? Mas então não seremos todos transformados?

 Tais coisas dizíamos, embora não deste modo, nem com estas palavras. Mas tu sabes, Senhor, que naquele dia, à medida que falávamos dessas coisas, quanto nos parecia vil este mundo, com todos os seus deleites – disse-me minha mãe: "Filho, quanto a mim, já nada me atrai nesta vida. Não sei o que faço ainda aqui, nem por que ainda estou aqui, se já se desvaneceram pra mim todas as esperanças do mundo. Uma só coisa me fazia desejar viver um pouco mais, e era ver-te católico antes de morrer. Deus me concedeu esta graça superabundantemente, pois te vejo desprezar a felicidade terrena para servi-lo. Que faço, pois, aqui?"

## CAPÍTULO XI

### A morte de Mônica

 Não me lembro bem o que respondi a tais palavras. Mas cerca de cinco dias mais tarde, ou pouco mais, caiu de cama, com febre. Durante a doença, teve um dia um desmaio, ficando por pouco tempo sem sentidos e sem reconhecer os presentes. Acudimos de imediato, e logo voltou a si. Vendo-nos a seu lado, a mim e a meu irmão (chamava-se Navígio, e era o mais velho dos irmãos), perguntou-nos, como quem procura algo: "Onde estava eu?" – Depois, vendo-nos atônitos de tristeza, nos disse: "Sepultareis aqui a vossa mãe" – Eu me calava, retendo as lágrimas, mas meu irmão disse umas palavras em que desejava vê-la morrer na pátria e não em terras distantes. Ao ouvi-lo, minha mãe repreendeu-o com o olhar, e aflita por ter pensado em tais coisas; depois, olhando para mim, disse: "Vê o que ele diz" – E depois para ambos: "Sepultem este corpo em qualquer lugar, e não se preocupem mais com ele. Peço apenas que se lembrem de mim diante do altar do Senhor, onde quer que estejam". E tendo-nos exposto seu pensamento com as palavras que pôde, calou-se; sua moléstia agravou-se e suas dores aumentaram.

 Mas eu, ó Deus invisível, meditando nos dons que infundes no coração de teus fiéis, e nas admiráveis colheitas que deles brotam, alegrava-me e te dava graças. Lembrava-me do grande cuidado que sempre demonstrara acerca de sua sepultura, adquirida e preparada junto ao corpo do marido. Tendo vivido com ele na maior concórdia, assim também queria – visão própria da alma humana incapaz das coisas divinas – ter a felicidade de que os homens recordassem que, depois de sua viagem para além-mar, lhe fora concedida a graça de a mesma terra cobrir o pó de ambos os cônjuges.

 Quando esta vaidade havia deixado de existir em seu coração, pela plenitude de tua bondade, eu não o sabia, mas alegrava-me com admiração ao ouvi-la falar assim. No entanto, naquela conversa à janela quando me disse: "Que faço eu aqui?" – já estava patente que não mais desejava morrer na pátria.

 Soube também depois que em Óstia, estando eu ausente, falou certo dia com alguns amigos meus, com maternal confiança, sobre o desprezo desta vida e o benefício da morte. Eles, maravilhados da coragem dessa mulher – dádiva tua – perguntaram-lhe se não temia deixar o corpo tão longe da pátria. "Nada está longe para Deus – disse ela – nem preciso temer que ele ignore, no fim dos tempos, o lugar onde me ressuscitará".

 Por fim, nove dias após cair enferma, aos cinqüenta e seis anos de idade e aos trinta e três da minha, aquela alma santa e piedosa libertou-se do corpo.

## CAPÍTULO XII

### As lágrimas negadas

 Fechei-lhe os olhos, e uma tristeza imensa invadiu-me o coração, e já me ia desfazer em lágrimas; ao mesmo tempo, meus olhos, obedecendo ao enérgico poder de minha vontade, fechavam sua fonte até secá-la. Como foi angustiosa essa luta! E foi quando ela deu o último suspiro, que o meu filho Adeodato rebentou em soluços; mas, instado por todos nós, se calou. Deste modo sua voz juvenil, voz do coração, calou em mim essa espécie de emoção pueril que me provocava o pranto. De fato, não julgávamos correto celebrar aquele funeral com lágrimas e choro, pois tais demonstrações deploram geralmente o triste destino dos que morrem, ou sua total extinção. A morte de minha mãe não era uma desgraça, e ela não morria para sempre, e disto estávamos certos pelo testemunho de seus costumes, por sua fé sincera e outras razões inequívocas.

 Que era então o que tanto me pungia, senão a ferida recente causada pelo rompimento repentino de nosso dulcíssimo e querido convívio?

 Era para mim grande consolação o testemunho que dera de mim, quando nesta última enfermidade, respondendo com ternura às minhas atenções, chamava-me de bom filho, e recordava com grande afeto o nunca ter ouvido de minha boca uma só palavra dura ou injuriosa contra ela. Entretanto, o que era, meu Deus e meu Criador, a solicitude que eu lhe tributava, em comparação com o devotamento servil que por mim suportava? Por me ver privado de tão grande consolo, sentia a alma ferida e minha vida, que era uma só com sua, estava despedaçada.

 Reprimido o pranto do Adeodato, Evódio tomou o saltério e começou a cantar um salmo, ao que todos respondíamos "Misericórdia e justiça te cantarei Senhor". Conhecia a notícia de sua morte, acorreram muitos irmãos e mulheres piedosas e, enquanto os encarregados dos funerais faziam seu ofício conforme o hábito, retirei-me para um lugar conveniente, junto com os amigos que julgavam oportuno não me deixar só. Falava sobre assuntos próprios das circunstâncias, e com o lenitivo da verdade mitigava meu sofrimento, só conhecido por ti. Eles o ignoravam e me ouviam atentamente, julgando que não sofria nenhuma dor.

 Mas eu, pertinho de teus ouvidos, onde ninguém me podia escutar, censurava a minha sensibilidade e fraqueza e reprimia a onda de tristeza que me invadia; esta cedia por uns instantes, e novamente me arrastava com seu ímpeto, embora não chegasse a derramar lágrimas ou alterar a face. Somente eu sabia quão oprimido estava meu coração! E como me desgostava profundamente que as vicissitudes humanas tivessem tanto poder sobre mim, que são inelutáveis pela ordem natural e a sorte de nossa condição; minha própria dor causava-me outra dor, e me afligia com dupla tristeza.

 Quando o corpo foi levado à sepultura, fui e voltei sem derramar uma lagrima. Nem mesmo nas orações que te fizemos, quando oferecemos o sacrifício de nossa redenção por intenção da morta, cujo cadáver jazia junto ao sepulcro antes de ser inumado, como ali é costume, nem mesmo nessas orações, chorei. Mas durante todo o dia andei oprimido por grande tristeza interior; pedia-te como podia, com a mente perturbada, que aliviasses minha dor. Mas não me atendias, sem dúvida para que fixasse, bem na memória, ao menos por esta única experiência, como são poderosos os laços do costume, mesmo em uma alma que já não se alimentava de palavras enganadoras.

 Lembrei então a ir aos banhos, por ter ouvido dizer que a palavra banho (bálneo, em latim) vinha dos gregos, que o chamaram balanéion (tirar fora a ania), porque o banho aliviava as tristezas da alma. Mas eu o confesso à tua misericórdia – ó Pai dos órfãos: depois do banho fiquei como estava antes, porque meu coração não expulsou o amargor de sua tristeza.

 Depois adormeci. Ao despertar, minha dor estava mitigada; só, em meu leito, lembrei-me dos versos cheios de verdade de teu Ambrósio. Porque, na verdade

Tu és Deus, criador de quanto existe,

De todo o mundo supremo governante,

Que o dia vestes com tua luz brilhante,

E de sonhos gratos a noite triste

 A fim de que os membros cansados O descanso ao trabalho prepare

E as mentes cansadas, repare

E os peitos de pena oprimidos

 Depois, pouco a pouco voltava aos sentimentos de antes sobre tua serva. Recordava de sua piedade para contigo, de sua solicitude e paciência comigo, da qual subitamente me via privado. E senti consolação em chorar diante de ti, por causa dela e por ela, e por minha causa e por mim. E deixei que as lágrimas reprimidas corressem à vontade, estendendo-as como um leito reparador sob meu coração. Teus ouvidos eram os que ali me escutavam, e não os de nenhum homem, que pudesse interpretar com soberba meu pranto.

 E agora, Senhor, to confesso nestas linhas: leia-o quem quiser, interprete-o como quiser. E se alguém julgar que pequei nessas lágrimas, que derramei sobre minha mãe por alguns instantes, por minha mãe então morta a meus olhos, ela que me havia chorado tantos anos para que eu vivesse aos teus olhos, não se ria. Antes, é grande sua caridade, chore por meus pecados diante de ti, Pai de todos os irmãos de teu Cristo!

## CAPÍTULO XIII

### Preces pela mãe morta

 Agora, com a ferida do meu coração já sanada, na qual se podia censurar um afeto muito carnal, derramo diante de ti, meu Deus, por tua serva, outra espécie de lágrimas, bem diferentes, aquelas que brotam do espírito comovido à vista dos perigos que corre toda alma que morre em Adão. É verdade que minha mãe, vivificada em Cristo, antes mesmo de ser livre dos laços da carne, viveu de tal modo, que teu nome era louvado em sua fé e em seus costumes. Contudo, não me atrevo a dizer que desde que a regeneraste no batismo não saiu de sua boca nenhuma palavra contrária à tua lei. Porque a Verdade, que é teu Filho, disse: "Quem chamar a seu irmão de louco será réu do fogo da geena". Ai da vida dos homens, por mais louvável que seja, se tu a julgares sem a tua misericórdia! Mas porque não examinas nossos pecados com rigor, confiadamente esperamos tomar lugar a teu lado. Quem enumera diante de ti seus próprios méritos, que mais expõe senão teus dons? Oh! Se os homens se reconhecessem como homens! Se quem se glorifica se glorificasse no Senhor!

 Por isso, Deus de meu coração, minha vida e minha gloria, esquecendo por um momento as boas ações de minha mãe, pelas quais te dou graças com alegria, peço-te agora perdão por seus pecados. Ouve-me pelos méritos daquele que é o médico de nossas feridas, que foi suspenso do madeiro da cruz e que, sentado agora à tua direita, intercede por nós junto a ti. Eu sei que ela sempre agiu com misericórdia, e que perdoou de coração todas as faltas contra ela cometidas; perdoa-lhe também suas dívidas, se algumas contraiu em tantos anos que se seguiram ao batismo. Perdoa-lhe, Senhor, perdoa-lhe, te suplico, e não entres em juízo com ela.

 Triunfe a misericórdia sobre a justiça pois as tuas são palavras de verdade, e prometeste misericórdia aos misericordiosos. Se alguém o foi, deve-o à tua graça, tu que tens compaixão de quem te apraz, e usas de misericórdia com quem queres ser misericordioso.

 Creio que já fizeste o que te suplico, mas desejo, Senhor, que acolhas os desejos de minha boca. Estando iminente o dia de sua morte, ela não desejou sepultar o corpo com grande pompa, ou que fosse embalsamado com preciosos aromas, nem desejou um rico monumento, nem se preocupou em tê-lo na pátria. Nada disto nos pediu, mas desejou apenas que nos lembrássemos dela ante do teu altar, onde servira todos os dias de sua vida, sabendo que nele se oferece a vítima santa, com cujo sangue se destrói o libelo de nossa condenação, e pelo qual vencemos o inimigo que conta nossas faltas e procura com que nos acusar, nada achando naquele que é nossa vitória.

 Quem poderá devolver-lhe seu sangue inocente? Quem poderá restituir-lhe o preço pago por nosso resgate, para nos arrancar ao inimigo? A este mistério de nossa redenção ligou tua serva sua alma com o vínculo da fé. que ninguém a afaste de tua proteção. Que entre ela e ti não se interponha, nem pela força, nem pelo engano, o leão ou o dragão. Ela não responderá que nada deve, para não ser convencida e arrebatada pelo astuto acusador, responderá que suas dívidas lhe foram perdoadas por aquele a quem ninguém pode restituir o que por nós pagou sem nada dever.

 Que ela repouse em paz com seu marido, antes e depois do qual não teve outro; a quem serviu, com uma paciência cujo fruto te oferecia, para o ganhar também para ti. Mas inspira, meu Senhor e meu Deus, inspira a teus servos, meus irmãos, a teus filhos, meus senhores, a quem sirvo de coração, com a palavra e com a pena, para que, ao lerem estas páginas, diante do teu altar lembrem de Mônica, tua serva, e de Patrício, outrora seu esposo, pelos quais me introduziste misteriosamente nesta vida. Que lembrem com piedoso afeto daqueles que foram meus pais nesta vida transitória, e meus irmãos em ti, ó Pai, na Igreja Católica, nossa mãe, e meus concidadãos na eterna Jerusalém, pela qual suspira teu povo em sua peregrinação desde a saída até o regresso. Assim, graças às minhas confissões, o último desejo de Mônica será mais amplamente satisfeito com muitas orações do que só pelas minhas.