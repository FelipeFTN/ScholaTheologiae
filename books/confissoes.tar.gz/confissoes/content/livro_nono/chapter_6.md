## CAPÍTULO VI

### Batismo de Agostinho. Seu filho Adeodato

 Chegado o tempo em que convinha nos inscrever para receber o batismo, deixamos o campo, e voltamos para Milão.

 Alípio também quis renascer em ti comigo, já revestido de humildade tão conforme a teus sacramentos. Era tão enérgico domador do seu corpo, que caminhava com os pés descalços, com insólita coragem, sobre o chão gelado da Itália.

 Juntamos também a nós o jovem Adeodato, filho carnal de meu pecado; a quem dotaste de grandes qualidades. Tinha cerca de quinze anos, mas por seu talento ultrapassava já muitos homens maduros e doutos. Confesso-te que eram dons teus, meu Senhor e meu Deus, criador de todas as coisas, tão poderoso para corrigir nossas deformidades, pois este menino nada havia de meu, senão meu pecado. Se o criei em tua disciplina, foste tu, e mais ninguém, quem no-lo inspirou. Sim, confesso que eram dons teus.

 Há um livro meu que se intitula O Mestre, no qual Adeodato dialoga comigo. Tu sabes que todos os pensamentos ali manifestados são dele quando tinha dezesseis anos. Muitas outras qualidades maravilhosas notei ainda nele, admirado por sua inteligência. Mas quem, além de ti, poderia ser o autor dessas maravilhas? Cedo o arrebataste desta terra; e a lembrança dele se torna mais tranqüila, nada mais tendo a temer por sua infância, por sua adolescência ou por toda sua vida adulta. Associamo-lo a nós como irmão na graça, para educá-lo em tua lei. Fomos batizados, e os remorsos de nossa vida passada se afastaram de nós.

 Naqueles dias eu não me fartava de considerar a grandeza de teus desígnios para a salvação do gênero humano, pela inefável doçura que sentia. Quanto chorei ao ouvir, profundamente comovido, teus hinos e cânticos que ressoavam suavemente em tua Igreja! Penetravam aquelas vozes em meus ouvidos, e destilavam a verdade em meu coração. Acendiase em mim um afeto piedoso, corriam-me lágrimas dos olhos, e o pranto me consolava.