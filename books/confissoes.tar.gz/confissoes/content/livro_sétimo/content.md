# LIVRO SÉTIMO

## CAPÍTULO I

### A idéia de Deus

 Já havia morrido minha adolescência má e nefanda; entrava na juventude, e quanto mais crescia em idade, mais vergonhosa se tornava minha vaidade, a ponto de não poder imaginar uma substância além da que se pode perceber com os olhos.

 Desde que comecei receber as lições da sabedoria, não mais te imaginava, meu Deus, sob a forma de um corpo humano – sempre fugi dessa idéia, e me alegrava encontrar essa doutrina na fé de nossa mãe espiritual, a Igreja Católica; - mas não me ocorria outro modo de te imaginar. E sendo eu homem – e que homem – esforçava-me para imaginar a ti, o sumo, o único e verdadeiro Deus. Com toda minha alma eu te julgava incorruptível, inviolável e imutável. Mesmo não sabendo de onde nem como me vinha esta certeza, eu via com clareza e tinha como certo que o incorruptível é melhor do que o corruptível. Sem hesitar, colocava o que não pode ser vencido acima do que o pode ser, e o que não sofre mudança parecia-me melhor do que é suscetível a mudanças.

 Meu coração clamava violentamente contra todos os meus fantasmas. Esforçava-me por afugentar, com um só golpe, o redemoinho de imagens imundas que voluteavam ao meu redor. Mas, apenas disperso, em um piscar de olhos, tornava a se formar os atropelos sobre minha vista, obscurecendo-a. Apesar de não te atribuir uma figura humana, contudo, necessitava te conceber como algo corporal, situado no espaço, quer imanente ao mundo, quer difundido por fora do mundo, através do infinito; tal era o ser incorruptível, inviolável e imutável que eu colocava acima do que é corruptível, sujeito à deterioração e ás mudanças. O que não ocupava espaço me parecia um nada absoluto, perfeito, e não um simples vazio, como quando se tira um corpo de um lugar, permanecendo o lugar vazio de todo o corpo, terrestre, úmido, aéreo ou celeste, mas, enfim, um lugar vazio, como que um nada espaçoso.

 Assim, pois, com o coração pesado, sem consciência clara de mim mesmo, considerava como um perfeito nada tudo o que não tivesse extensão por determinado espaço, ou não se difundisse ou pudesse assumir um desses estados. As formas percorridas por meus olhos eram os moldes das imagens pelas quais andava meu espírito; não via que a mesma faculdade com que formava essas imagens não era da mesma natureza que elas, não obstante não pudesse formá-las se ela não fosse por sua vez algo grande.

 E também a ti, vida de minha vida, imaginava-te como um Ser imenso, penetrando por todas as partes, através dos espaços infinitos, toda a massa do mundo, alastrando-se sem limites na imensidão, de sorte que a terra, o céu e todas as coisas te continham, e tudo isso tinha em ti seu limite, sem que te limitasses em parte alguma. E assim como a massa do ar – deste ar que está sobre a terra – não impede a passagem da luz do sol, não o impede de a atravessar, de a penetrar sem romper ou cortar, antes enchendo-a totalmente, assim eu pensava que não somente a substância do céu, do ar e do mar, mas também a da terra se deixava atravessar e penetrar por ti em todas as suas partes, grandes e pequenas, que receberiam tua presença, que, com secreta inspiração, governa interior e exteriormente tudo o que criaste.

 Assim conjeturava eu, por não poder imaginar-te de outra forma; mas minha conjectura era falsa. Porque, se assim fosse, uma porção maior da terra conteria parte maior de ti; e uma porção menor da terra conteria parte menor. E de tal modo estariam as coisas impregnadas de ti, que o corpo de um elefante conteria tanto mais de teu ser que o corpo do passarinho, pois aquele é maior do que este, e ocupa mais espaço. Assim, fragmentado entre as partes do universo, estarias presente nas grandes partes do universo por grandes partes de ti, e nas pequenas por pequenas, o que não acontece. Mas ainda não tinhas iluminado minhas trevas.

## CAPÍTULO II

### Objeção contra o maniqueísmo

 Bastava-me, Senhor, para calar aqueles enganados enganadores e muitos charlatães – pois o que se ouvia de sua boca não era a tua palavra – bastava-me, certamente, o argumento que há muito tempo, estando ainda em Cartago, costumava propor-lhes Nebrídio, impressionando a todos os que então o ouvimos.

 "Que poderia fazer contra ti – dizia aquela não sei que raça de trevas, que os maniqueus costumam opor-te como massa hostil – se não quisesses lutar contra ela?"

 Se respondessem que te podia ser nociva em algo, então serias violável e corruptível. Se dissessem que não te podia prejudicar nada, não haveria razão para luta. Luta essa em que uma parte de ti mesmo, um de teus membros, produto de tua própria substância, se misturava às forças adversas, a naturezas não criadas por ti. Assim se corromperia, degradando-se a ponto de mudar sua felicidade em miséria e de necessitar de auxílio para se libertar e purificar. E essa parte de ti seria a alma que teu Verbo devia salvar da escravidão, ele que é livre de impurezas, ele que é imaculado da corrupção, ele que é intacto sem ser corruptível, sendo feito de uma só e mesma substância.

 E assim, se declaram incorruptível tudo o que és, isto é, a substância que te forma, todas essas proposições são erros execráveis; e se eles te consideram corruptível, essa mesma afirmação também é falsa, e abominável logo à primeira vista.

 Bastava-me, pois, este argumento contra aqueles que eu queria expulsar de vez de meu peito angustiado. De fato, sentindo e dizendo tais coisas de ti, não tinham outra saída senão um horrível sacrilégio de coração e de língua.

## CAPÍTULO III

### Deus e o mal

 Mas eu, mesmo quando afirmava e cria firmemente que és incorruptível, inalterável, absolutamente imutável, Senhor meu, Deus verdadeiro que não só criaste nossas almas e nossos corpos, e não somente nossas almas e corpos, mas todas as criaturas e todas as coisas. Todavia, faltava-me ainda uma explicação, a solução do problema da causa do mal. Qualquer que ela fosse, estava certo de que deveria buscá-la onde não me visse obrigado, por sua causa, a julgar mutável a um Deus imutável, porque isso seria transformar-me no mal que procurava.

 Por isso, buscava-a com segurança, certo de que era falsidade o que diziam os maniqueus; deles fugia com toda a alma, porque via suas indagações sobre a origem do mal cheias de malícia, preferindo crer que tua substância era passível de sofrer o mal do que a deles ser susceptível de o cometer.

 Esforçava-me por compreender a tese que ouvira professar, de que o livre-arbítrio da vontade é a causa de praticarmos o mal, e de teu reto juízo é a causa do mal que padecemos. Mas era incapaz de entendê-lo com clareza. E esforçando-me por afastar desse abismo os olhos do meu espírito, nele me precipitava de novo, e tentando reiteradamente fugir dele, sempre voltava a recair.

 O fato de eu ter a consciência de possuir uma vontade, como tinha consciência de minha vida, era o que me erguia para a tua luz. Assim, quando queria ou não queria alguma coisa, estava certíssimo de que era eu, e não outro, o que queria ou não queria, e então me convencia de que ali estava a causa do meu pecado. Quanto ao que fazia contra a vontade, notava que isso mais era padecer do mal do que praticá-lo; julgava que isso não era culpa, mas castigo, que me instava a confessar justamente ferido por ti, considerando tua justiça.

 Mas de novo refletia: "Quem me criou? Não foi o bom Deus, que não só é bom, mas a própria bondade? De onde, então, me vem essa vontade de querer o mal e de não querer o bem? Seria talvez para que eu sofra as penas merecidas? Quem depositou em mim, e semeou minha alma esta semente de amargura, sendo eu totalmente obra de meu dulcíssimo Deus? Se foi o demônio que me criou, de onde procede ele? E se este, de anjo bom se fez demônio, por decisão de sua vontade perversa, de onde lhe veio essa vontade má que o transformou em diabo, tendo ele sido criado anjo por um Criador boníssimo?"

 Tais pensamentos de novo me deprimiam e sufocavam, mas não me arrastavam até aquele abismo de erro, onde ninguém te confessa, e onde se antepõe a tese que tu és sujeito ao mal a considerar o homem capaz de o cometer.

## CAPÍTULO IV

### A substância de Deus

 Empenhava-me então por descobrir as outras verdades, como havia descoberto que o incorruptível é melhor que o corruptível, e por isso confessava que tu, qualquer que fosse tua natureza, devias ser incorruptível. Porque ninguém pôde nem poderá jamais conceber algo melhor do que tu, que és o sumo bem por excelência. Por isso, sendo certíssimo e inegável que o incorruptível é superior ao corruptível, o que eu já fazia, meu pensamento já poderia conceber algo melhor do que o meu Deus, se não fosses incorruptível.

 Portanto, logo que vi que o incorruptível deve ser preferido ao corruptível, imediatamente deveria buscar-te no incorruptível, para depois indagar a causa do mal, isto é, a origem da corrupção, que de nenhum modo pode afetar tua substância. É certo que, nem por vontade, nem por necessidade, nem por qualquer acontecimento imprevisto, pode a corrupção afetar nosso Deus, porque ele é Deus, e não pode querer senão o que é bom, e ele próprio é o sumo bem; e estar sujeito à corrupção não é nenhum bem.

 Tampouco poder ser obrigado, contra a tua vontade, seja ao que for, porque tua vontade não é maior do que teu poder. Seria maior caso pudesses ser maior do que és, pois a vontade e o poder de Deus são o mesmo Deus. E que pode haver de imprevisto para ti, se conheces todas as coisas, e se todas elas existem porque as conheces?

 Mas, por que tantas palavras para demonstrar que a substância de Deus não é corruptível, já que se o fosse não seria Deus?

## CAPÍTULO V

### A origem do mal

 Eu buscava a origem do mal, mas de modo errôneo, e não via o erro que havia em meu modo de buscá-la. Desfilava diante dos olhos de minha alma toda a criação, tanto o que podemos ver – como a terra, o mar, o ar, as estrelas, as árvores e os animais – como o que não podemos ver – como o firmamento, e todos os anjos e seres espirituais. Estes, porém, como se também fossem corpóreos, colocados em minha imaginação em seus respectivos lugares. Fiz de tua criação uma espécie de massa imensa, diferenciada em diversos gêneros de corpos; uns, corpos verdadeiros, e espíritos, que eu imaginava como corpos.

 E eu a imaginava não tão imensa quanto ela era realmente – o que seria impossível – mas quanto me agradava, embora limitada por todos os lados. E a ti, Senhor, como a um ser que a rodeava e penetrava por todas as partes, infinito em todas as direções, como se fosses um mar incomensurável, que tivesse dentro de si uma esponja tão grande quanto possível, limitada, e toda embebida, em todas as suas partes, desse imenso mar.

 Assim é que eu concebia a tua criação finita, cheia de ti, infinito, e dizia: "Eis aqui Deus, e eis aqui as coisas que Deus criou; Deus é bom, imenso e infinitamente mais excelente que suas criaturas; e, como é bom, fez boas todas as coisas; e vede como as abraça e penetra! Onde está pois o mal? De onde e por onde conseguiu penetrar no mundo? Qual é a sua raiz e sua semente? E se tememos em vão, o próprio temor já é certamente um mal que atormenta e espicaça sem motivo nosso coração; e tanto mais grave quanto é certo que não há razão para temer. Portanto, ou o mal que tememos existe, ou o próprio temor é o mal. De onde, pois, procede o mal se Deus, que é bom, fez boas todas as coisas? Bem superior a todos os bens, o Bem supremo, criou sem dúvida bens menores do que ele. De onde pois vem o mal? Acaso a matéria de que se serviu para a criação era corrompida e, ao dar-lhe forma e organização, deixou nela algo que não converteu em bem?

 E por que isto? Acaso, sendo onipotente, não podia mudá-la, transformá-la toda, para que não restasse nela semente do mal? Enfim, por que se utilizou dessa matéria para criar? Por que sua onipotência não a aniquilou totalmente? Poderia ela existir contra sua vontade? E, se é eterna, por que deixou-a existir por tanto tempo no infinito do passado, resolvendo tão tarde servirse dela para fazer alguma coisa? Ou, já que quis fazer de súbito alguma coisa, sendo onipotente, não poderia suprimir a matéria, ficando ele só, bem total verdadeiro, sumo e infinito? E, se não era conveniente que, sendo bom, não criasse nem produzisse bem algum, por que não destruiu e aniquilou essa matéria má, criando outra que fosse boa e com a qual plasmar toda a criação? Porque ele não seria onipotente se não pudesse criar algum bem sem a ajuda dessa matéria que não havia criado."

 Tais eram os pensamentos de meu pobre coração, oprimido pelos pungentes temores da morte, e sem ter encontrado a verdade. Contudo, arraigava sempre mais em meu coração a fé de teu Cristo, nosso Senhor e Salvador, professada pela Igreja Católica; fé ainda incerta, certamente, em muitos pontos, e como que flutuando fora das normas da doutrina. Minha alma porém não a abandonava, e cada dia mais se abraçava a ela.

## CAPÍTULO VI

### O absurdo dos horóscopos

Também já havia rechaçado as enganosas predições e ímpios delírios dos astrólogos.

 Ainda por isso, meu Deus, quero confessar-te tuas misericórdias desde o mais íntimo de minha alma! Foste tu, e só tu – pois, quem pode afastar-nos da morte do erro, senão a Vida que desconhece a morte, a Sabedoria que ilumina as pobres inteligências sem precisar de outra luz, e que governa o mundo até as folhas que tremulam nas árvores? Foste tu que medicaste a obstinação com que me opunha ao sábio velho Vindiciano e ao magnânimo jovem Nebrídio, que diziam – o primeiro, com veemência, o segundo com alguma hesitação, mas frequentemente – não existir a tal arte de predizer as coisas futuras, e que as conjecturas dos homens muitas vezes têm concurso do acaso e que, de tanto repetir, acertavam em predizer algumas coisas, sem que os mesmos que as diziam o soubessem.

 Foste tu que me fizeste encontrar um amigo mui afeiçoado a consultar os astrólogos, não entendido nessa ciência, mas que consultava por curiosidade. Conhecia ele uma história, que ouvira do pai, segundo dizia. Ignorava ele até que ponto essa história era valiosa para destruir a autoridade daquela arte.

 Esse homem, chamado Firmino, educado nas artes liberais e instruído na eloqüência, veiome consultar, como amigo íntimo, sobre alguns assuntos nos quais alimentava esperanças mundanas, para ver qual seria meu vaticínio conforme suas constelações, como eles dizem. Eu, que já começara a me inclinar à opinião de Nebrídio, embora não me negasse a fazer-lhe o horóscopo e expor-lhe as suas conclusões, acrescentei, contudo, que estava quase persuadido de que tudo aquilo era ridícula quimera.

 Então, ele me contou que seu pai tinha grande interesse na leitura de tais livros, e que tivera um amigo igualmente apaixonado. Conversando sobre a matéria, empolgaram-se cada vez mais no estudo daquelas tolices, e chegaram ao ponto de observar os momentos do nascimento até dos animais domésticos, notando a posição das estrelas a fim de coligir dados experimentais daquela pseudo-arte.

 Firmino me relatava ter ouvido o pai contar que, estando sua mãe para o dar à luz, também estava grávida uma serva daquele amigo de seu pai, coisa que não poderia passar despercebida a seu senhor, que cuidava com extrema diligência e precisão de conhecer até o parto das cadelas.

 E sucedeu que, contando com o maior esmero os dias, horas e suas menores parcelas, da esposa e da escrava, ambas as mulheres deram à luz no mesmo momento, o que os obrigou a fazer, até em seus menores detalhes os mesmos horóscopos para os nascidos, um para o filho e outro para o pequeno servo.

 Tendo começado o trabalho de parto, informaram um ao outro o que se passava em suas casas, e enviaram mensageiros um ao outro, a fim de anunciar com igual rapidez o nascimento das crianças; e conseguiram-no fazer facilmente, como se o fato se passasse em suas próprias casas. E Firmino contava que os mensageiros que haviam sido enviados vieram a se encontrar à mesma distância de suas respectivas casas, de modo que não se podia notar a menor diferença na posição das estrelas, assim como nas demais frações de tempo. No entanto Firmino, como filho de grande família, corria pelos mais brilhantes caminhos do mundo, crescia em riquezas e era coberto de honras, ao passo que o escravo, sujeito ainda ao jugo da escravidão, tinha que servir a seus senhores, segundo ele próprio contava, pois o conhecia.

 Ouvindo essa história, na qual acreditei pelo crédito que merecia seu narrador – toda minha resistência se quebrou. Esforcei-me em seguida para afastar Firmino daquela vã curiosidade, dizendo-lhe que, pelo seu horóscopo e para ser verdadeiro, deveria certamente considerar a seus pais como os primeiros entre seus concidadãos; o renome da sua família, a mais nobre da cidade; seu nascimento ilustre, sua educação esmerada e seus conhecimentos nas artes liberais. E, pelo contrário, se aquele servo me consultasse sobre o tal horóscopo – que era o mesmo de Firmino – se também tivesse de lhe dizer a verdade – deveria ver nos mesmo signos sua família paupérrima, sua condição servil e tantas outras coisas, tão diferentes e opostas às primeiras.

 Portanto, para dizer a verdade, vendo os mesmos sinais celestes deveria tirar conclusões divergentes, porque fazer prognósticos semelhantes seria mentir.

 De onde concluí, com toda certeza, que as predições verdadeiras não podem atribuir a uma arte, mas ao acaso, e que as falsas não se devem à ignorância dessa arte, mas à mentira do acaso.

 Após esta abertura e nela baseado, ruminava dentro de mim tais coisas, para que nenhum daqueles loucos que buscam nisso o lucro, e a quem eu então desejava refutar e ridicularizar, não me objetasse que Firmino ou o pai podia ter contado mentiras. Voltei pois minha atenção ao caso dos gêmeos, muitos dos quais saem do seio materno com tão breve intervalo de tempo, que por mais que o pretendam importante, não pode ser apreciado pela observação humana, nem pode ser considerado nos signos que o astrólogo lançará mão para fazer uma previsão certa. Mas os vaticínios não serão verdadeiros pois, vendo os mesmos signos, deveria predizer a mesma sorte para Esaú e Jacó, sendo que os sucessos da vida de ambos foram muito diversos.

 O astrólogo, portanto, deveria prognosticar coisas falsas, ou, no caso de falar coisas verdadeiras, estas forçosamente deveriam ser diferentes, a despeito da identidade das observações. Logo, se seus prognósticos fossem verdadeiros, não o seriam por efeito da arte, mas do acaso. Porque tu, Senhor, governador justíssimo do Universo, por inspiração secreta, desconhecida dos consulentes e astrólogos, fazes que cada um ouça a resposta que lhe convém, de acordo com os méritos das almas, do fundo do abismo de teu justo juízo. E que o homem não se atreva a dizer: Que é isto? Por que isto? Não o diga, não o diga, porque é um simples homem.

## CAPÍTULO VII

### Ainda a origem do mal

 Deste modo, ó meu auxílio, já me havias libertado daqueles grilhões. Contudo eu buscava ainda a origem do mal, e não encontrava solução. Mas não permitias que as vagas de meu pensamento me apartassem da fé. Fé na tua existência, na tua substância imutável, na tua providência para os homens, e na tua justiça que os julgará. Já acreditava que traçaste o caminho da salvação dos homens, rumo à vida que sobrevém depois da morte, em Cristo, teu Filho e Senhor nosso, e nas Sagradas Escrituras, recomendadas pela autoridade de tua Igreja Católica.

 Salvas e fortemente arraigadas estas verdades em meu espírito, buscava eu ansiosamente a origem do mal. E que tormentos, como que de parto, eram aqueles de meu coração! Que gemidos, meu Deus! E ali estavam teus ouvidos atentos, e eu não o sabia. Quando, em silêncio, me esforçava em pacientes buscas, altos clamores se elevavam até tua misericórdia: eram as silenciosas angústias de minha alma.

 Tu só sabes o que eu padecia, mas homem algum o sabia. De fato, quão pouco era o que minha palavra transmitia aos meus amigos mais íntimos! Chegava, porventura, a eles o tumulto de minha alma, que nem o tempo, nem as palavras bastavam para declarar? Contudo, chegavam a teus ouvidos as queixas que em meu coração rugiam, e meu desejo estava diante de ti, mas a luz de meus olhos não estava contigo, porque ela estava dentro, e eu olhava para fora. Ela não ocupava espaço algum, e eu só pensava nas coisas que ocupam lugar, e não achava nelas lugar de descanso, nem me acolhiam de modo que pudesse dizer: "Basta, Aqui estou bem!" – Nem me permitiam que eu fosse para onde me sentisse satisfeito. Eu era superior a estas coisas, mas sempre inferior a ti. Serias minha verdadeira alegria se eu te fosse submisso, pois sujeitasse a mim tudo o que criaste inferior a mim. Tal seria o justo equilíbrio e a região central de minha salvação: permanecer como imagem tua, e servindo-te, ser o senhor de meu corpo. Mas, como me levantei soberbamente contra ti, investindo contra meu Senhor coberto com o escudo de minha dura cerviz, até mesmo as criaturas inferiores se fizeram superiores a mim, e me oprimiam, e não me davam um momento de alívio e de descanso.

 Quando as olhava, elas me vinham ao encontro atabalhoadamente de todos os lados; mas quando nelas me concentrava, tais imagens corporais me barravam para que me retirasse, como se me dissessem: "Para onde vais, indigno e impuro?" E estas recobravam forças com a minha chaga, porque humilhaste o soberbo como a um homem ferido. Minha presunção me separava de ti, e meu rosto de tão inchado, fechava meus olhos.

## CAPÍTULO VIII

### A piedade de Deus

Mas tu, Senhor, permaneces eternamente, e não te iras eternamente contra nós, porque te compadeceste da terra e do pó, e foi de teu agrado corrigir minhas deformidades. Tu me aguilhoavas com estímulos interiores para que estivesse impaciente, até que por uma visão interior, te tornasses para mim uma certeza. O inchaço de meu orgulho baixava graças à mão secreta de tua medicina; a vista de minha alma, perturbada e obscurecida, ia sarando dia a dia graças ao colírio das dores salutares.

## CAPÍTULO IX

### Agostinho e o neoplatonismo

 Primeiramente, querendo tu mostrar-me como resistes aos soberbos e dás tua graça aos humildes, e com quanta misericórdia ensinaste aos homens o caminho da humildade, por se ter feito carne teu Verbo, e ter habitado entre os homens, me fizeste chegar às mãos por meio de um homem inchado de monstruoso orgulho, alguns livros dos platônicos, traduzidos do grego para o latim.

 Neles eu li – não com estas palavras, mas substancialmente o mesmo e expresso com muitos e diversos argumentos – que "no princípio era o Verbo, e o Verbo estava com Deus, e o Verbo era Deus. Este estava desde o princípio em Deus. Todas as coisas foram feitas por ele, e sem ele nada foi feito do que foi feito. O que foi feito é vida nele, e a vida era a luz dos homens. E a luz brilha nas trevas, mas as trevas não a compreenderam. Diziam também que a alma do homem, embora dê testemunho da luz, não é a luz, mas o Verbo, Deus, é a verdadeira luz, que ilumina a todo homem que vem a este mundo. E que neste mundo estava, e que o mundo é criatura sua, e que o mundo não o conheceu.

 E que ele veio para sua morada, e que os seus não o receberam, e que a quantos o receberam deu o poder de se fazerem filhos de Deus, desde que acreditem em seu nome, isto não o li nesses livros.

 Também neles li que o Verbo, Deus, não nasceu da carne nem do sangue, nem da vontade do varão, mas de Deus. Mas que o Verbo se fez carne, e habitou entre nós, isso não o li naqueles livros.

 Igualmente achei nesses livros, dito de diversos e múltiplos modos, que o Filho, consubstancial ao Pai, não considerou usurpação ser igual a Deus, porque o é por natureza. Não dizem porém que se aniquilou a si mesmo, tomando a forma de escravo, que se fez semelhante aos homens, sendo julgado homem por seu exterior; e que se humilhou, fazendo-se obediente até a morte, e morte de cruz, pelo que Deus o ressuscitou entre os mortos, e lhe deu um nome acima de todo nome, para que ao nome de Jesus se dobrem todos os joelhos no céu, na terra e no inferno, e toda língua confesse que o Senhor Jesus está na glória de Deus Pai.

 Neles se diz também que antes e sobre todos os tempos, teu Filho único permanece imutável, eterno consigo, e que de sua plenitude recebem as almas para sua bem-aventurança e que, para serem sábias, são renovadas participando da sabedoria que permanece em si mesma. Mas não se encontra escrito ali que morreu, no tempo marcado, pelos ímpios, e que não perdoaste a teu Filho único, mas que o entregaste por todos nós. Porque escondeste estas coisas aos sábios e as revelastes aos humildes, a fim de que os atribulados e sobrecarregados viessem a ele, para que os reconfortasse, porque ele é manso e humilde de coração. Dirige os pequenos na justiça e ensina aos mansos seu caminho, vendo nossa humildade e nosso trabalho, e perdoando todos os nossos pecados.

 Mas aqueles que, erguendo-se sobre uma doutrina, digamos, mais sublime, não ouvem ao que lhes diz: Aprendei de mim que sou manso e humilde de coração, e encontrareis descanso para vossas almas. E ainda que conheçam a Deus, não o glorificam como Deus, nem lhe dão graças, mas se desvanecem em seus pensamentos, e seu coração insensato se obscurece; e dizendo que são sábios, se tornam estultos.

 E por isso lia também nesses livros que a glória de tua natureza incorruptível havia sido transformada em ídolos e simulacros de todo tipo, à semelhança da imagem do homem corruptível, das aves, dos quadrúpedes e serpentes. Isto é, naquele alimento do Egito pelo qual Esaú perdeu sua primogenitura. Israel, teu povo primogênito, voltando o coração para o Egito, honrou em teu lugar a cabeça de um quadrúpede, curvando tua imagem, isto é, a própria alma, diante da imagem de um bezerro comendo feno.

 É o que encontrei nesses livros, mas delas não me alimentei, porque agradou-te, Senhor, tirar de Jacó o opróbrio de sua inferioridade, para que o maior servisse ao menor, chamando os gentios para tua herança.

 Também eu vinha dentre os gentios para ti, e interessei-me pelo ouro que, por tua vontade, teu povo trouxera do Egito, pois era teu onde quer que estivesse. E disseste aos atenienses, por boca de teu Apóstolo, que em ti vivemos, nos movemos e temos nosso ser, como alguns deles o disseram, e é deles que vinham os livros que me ocupavam. Mas não me fixei nos ídolos dos egípcios, aos quais sacrificavam, com teu ouro, os que mudaram a verdade de Deus em mentira, adorando e servindo ante à criatura do que ao Criador.

## CAPÍTULO X

### A descoberta de Deus

 Estimulado por estas leituras a voltar a mim mesmo, entrei, guiado por ti, no profundo de meu coração, e o pude fazer porque te fizeste minha ajuda. Entrei, e vi com os olhos da alma, acima desses mesmos olhos, acima de minha inteligência, a luz imutável; não esta vulgar e visível a todos os olhos de carne, nem outra do mesmo gênero, embora maior. Era muito mais clara e enchendo com sua força todo o espaço. Não, não era esta luz, mas uma luz diferente de todas estas.

 Ela não estava sobre meu espírito como o azeite sobre a água, como o céu sobre a terra, mas estava acima de mim porque me criou; eu lhe era inferior por ter sido criado por ela. Quem conhece a verdade conhece a luz, e quem a conhece, conhece a eternidade. O amor a conhece!

 Ó eterna verdade, amor verdadeiro, amada eternidade! Tu és meu Deus. Por ti suspiro dia e noite. Quando te conheci pela primeira vez, ergueste-me para me fazer ver que havia algo para ser visto, mas que eu ainda era incapaz de ver. E deslumbraste a fraqueza de minha vista com o fulgor do teu brilho, e eu estremeci de amor e temor. Pareceu-me estar longe de ti numa região desconhecida, como se ouvira tua voz do alto: "Sou o pão dos fortes; cresce, e comer-me-ás. Não me transformarás em ti, como fazes com o alimento da tua carne, mas tu serás mudado em mim".

 E conheci então que "castigaste o homem por causa de sua iniqüidade", e "que secaste minha alma como uma teia de aranha", e eu disse: Porventura não existe a verdade, por não ser difusa pelos espaços finitos e infinitos? E tu me gritaste de longe: Na verdade, Eu sou o que sou. E eu ouvi como se ouve no coração, sem deixar motivo para dúvidas; antes, mais facilmente duvidaria de minha vida que da existência da verdade, que se manifesta à inteligência pelas coisas da criação.

## CAPÍTULO XI

### Deus e as criaturas

 E contemplei as outras coisas que estão abaixo de ti, e vi que nem existem absolutamente, e nem absolutamente deixam de existir. Certamente existem, porque procedem de ti; mas não existem, pois, não são o que tu és,, porque só existe verdadeiramente o que permanece imutável. Com isso, para mim é bom apegar-me a Deus, porque, se não permanecer nele, tampouco poderei permanecer em mim. ele, porém, permanecendo em si, renova todas as coisas, e tu és o meu Senhor, porque não necessitas de meus bens.

## CAPÍTULO XII

### O mal e o bem da criação

 Também pode entender que são boas as coisas que se corrompem. Se fossem sumamente boas, não poderiam se corromper, como tampouco o poderiam se não fossem boas de algum modo. Com efeito, se fossem sumamente boas, seriam incorruptíveis; e se não tivessem nenhuma bondade, nada haveria nelas que se pudesse corromper. Porque a corrupção é um mal, e não poderia ser nociva se não diminuísse o bem real. Logo, ou a corrupção é inofensiva, o que é impossível, ou, o que é certo, tudo o que se corrompe é privado de algum bem. E assim, se algo for privado de todo o bem, deixará totalmente de existir. E se algo subsistisse sem já poder ser corrompido, seria ainda melhor, porque permaneceria incorruptível. E haverá maior absurdo do que afirmar que uma coisa se torna melhor pela perda de todo o bem? Logo, ser privado de todo o bem é o nada absoluto. De onde se segue que, enquanto as coisas existem, elas são boas. Portanto, tudo o que existe é bom; e o mal, cuja origem eu procurava, não é uma substância, porque se o fosse seria um bem. De fato, ou ele seria substância incorruptível, e portanto um grande bem; ou seria uma substância corruptível, que se não se poderia corromper se não fosse boa.

 Vi pois, e foi para mim evidente, que tu eras o autor de todos os bens, e que não há em absoluto substância alguma que não tenha sido criada por ti. E como não as fizeste todas iguais, toas as coisas existem, porque cada uma por si é boa, e todas juntas muito boas, porque nosso Deus fez todas as coisas muito boas.

## CAPÍTULO XIII

### Os louvores da criação

 E para ti, Senhor, não existe absolutamente o mal; e nem para universalidade da tua criação; porque nada existe fora dela, capaz de romper ou de corromper a ordem que tu lhe impuseste. Todavia, em algumas de suas partes, determinados elementos não se harmonizam com outros, e estes são considerados maus. Mas, como esses mesmos elementos combinam com outros, são da mesma forma bons, e bons em si mesmos. E mesmo esses elementos que não concordam entre si se harmonizam com a parte inferior das criaturas que chamamos terra, com seu céu cheio de nuvens e de ventos, como lhe é conveniente.

 Longe de mim dizer: Oxalá não existissem estas coisas! – Embora, considerando-as separadamente, eu as desejasse melhores, somente o fato de existirem deveria bastar para eu te louvar porque o proclamam os dragões da terra e todos os abismos; o fogo, o granizo, a neve, o vento da tempestade, que executam tuas ordens; os montes e todas as colinas; as árvores frutíferas e todos os cedros; as feras e todos os gados; os répteis e todas as aves; os reis da terra e todos os povos; os príncipes e todos os juízes da terra, os jovens e as virgens, os anciões e as crianças; todos louvam teu nome.

 Mas como também do alto dos céus é louvado, que seja louvado o nosso Deus, lá no alto por todos os teus anjos, todas as potestades, o sol e a lua, todas as estrelas e a luz, os céus dos céus, e a águas que estão sobre os céus glorificam teu nome, eu já não desejava nada melhor, porque, considerando o todo, os elementos superiores me pareciam sem dúvida melhores que os inferiores; mas um julgamento mais sadio me fazia considerar o todo melhor que os elementos superiores tomados à parte.

## CAPÍTULO XIV

### Recapitulação

 Não têm juízo sadio, nos que se desagradam com alguma parte de tua criação, como acontecia comigo, quando me desagradavam tantas de tuas obras. Mas, como minha alma não se atrevia a desgostar do meu Deus, não queria considerar como obra tua o que lhe desagradava.

 Por isso fora atrás da teoria das duas substâncias, na qual não achava descanso, e repetia coisas alheias. Desembaraçando-me desses erros, imaginara para si um Deus que se difundia pelos espaços infinitos e, julgando que eras tu, colocou-o em seu coração, e de novo se tornou o templo de seu ídolo, coisa abominável a teus olhos.

 Mas, depois que afagaste minha cabeça, sem que eu o percebesse, e fechaste meus olhos para não vissem a vaidade, desprendi-me um pouco de mim mesmo, e minha loucura adormeceu profundamente; quando despertei em teus braços, vi que eras infinito não daquele modo, e esta visão não procedia da carne.

## CAPÍTULO XV

### Deus e a criação

 Contemplei depois as outras coisas, e vi que deviam a ti sua existência, e que todas estão contidas em ti, não como em um lugar material, mas de modo diferente: conservas todas elas em tua verdade, sustentadas na tua mão; todas as coisas são verdadeiras enquanto existem, e só é falso o que julgamos existir, mas não existe.

 Também vi que cada coisa adapta-se não só a seus lugares, mas também a seus tempos, e que tu, que és o único eterno, não começaste a agir depois de infinitos espaços de tempos, porque todos os espaços de tempo – passados ou futuros – não teriam passado nem viriam se tu não agistes e não fosses permanente.

## CAPÍTULO XVI

### Onde está o mal

 Entendi por experiência que não é de admirar que o pão seja enjoativo ao paladar enfermo, mesmo tão agradável para o paladar sadio, e que olhos enfermos considerem odiosa a luz, que para os límpidos é tão cara. Se tua justiça desagrada aos maus, muito mais desagradam a víbora e o caruncho, que criaste bons e adaptados à parte inferior da tua criação, com a qual também os maus se assemelham, tanto mais quanto mais diferem de ti, assim como os justos se assemelham às partes superiores do mundo na medida em que se assemelham a ti.

 Indaguei o que era a iniqüidade, e não achei substância, mas a perversão de uma vontade que se afasta da suprema substância, de ti, meu Deus – e se inclina para as coisas baixas, e que derrama suas entranhas, e se intumesce exteriormente.

## CAPÍTULO XVII

### Caminho para Deus

 Admirava-me de já te amar, e não a um fantasma em teu lugar, mas não era estável no gozo de meu Deus. Era arrebatado a ti por tua beleza, e logo afastado de ti pelo meu peso, que me precipitava sobre a terra a gemer. Meu peso eram os hábitos carnais. Mas tua lembrança me acompanhava. Nem absolutamente duvidava da existência de um ser a quem eu devia me unir, embora não estivesse apto para esta união, porque o corpo, que se corrompe, sobrecarrega a alma, e a morada terrena oprime o espírito carregado de cuidados. Estava certíssimo de que tuas belezas invisíveis se descobrem à inteligência desde a criação do universo, por meio de tuas obras; bem como teu poder eterno e tua divindade.

 Buscava saber de onde me vinha minha faculdade de apreciar a beleza dos corpos – quer celestes, quer terrenos – e o que me permitia julgar rápida e cabalmente das coisas mutáveis quando dizia: "Isto deve ser assim, aquilo não deve ser assim". Procurando a origem de minha faculdade de julgar quando assim julgava, achei a eternidade imutável e verdadeira, acima de meu espírito mutável.

 E, gradualmente, fui subindo dos corpos para a alma, que sente por meio do corpo; e dela à sua força interior, à qual os sentidos comunicam as coisas exteriores, que é o limite alcançado pelos animais. Daqui passei para o poder do raciocínio, ao qual cabe julgar as percepções dos sentidos corporais; por sua vez, julgando-se sujeito a mudanças, levantou-se até a sua própria inteligência, e afastou o pensamento de suas cogitações habituais. Livrou-se da multidão de fantasmas contraditórios, para descobrir que luz a inundava quando, sem nenhuma dúvida, afirmava que o imutável deve ser preferido ao mutável; e também de onde lhe vinha o conhecimento do próprio imutável, porque, se não tivesse dele alguma noção, nunca o preferiria ao mutável com tanta certeza. E, finalmente, chegou àquele que é um único lampejo.

 Foi então que tuas perfeições invisíveis se manifestaram à minha inteligência por meio de tuas obras. Mas não pude fixar nelas meu olhar; minha fraqueza se recobrou, e voltei a meus hábitos, não levando comigo senão uma lembrança amorosa e, por assim dizer, o desejo do perfume do alimento saboroso que eu ainda não podia comer.

## CAPÍTULO XVIII

### A senda da humildade

 Buscava um meio que me desse força necessária para gozar de ti, e não a encontrei enquanto não me abracei ao Mediador entre Deus e os homens, o homem Cristo Jesus, que está sobre todas as coisas, Deus bendito por todos os séculos, que chama e diz: Eu sou o caminho, a verdade e a vida. Ele une o alimento à carne (alimento que eu não tinha forças para tomar), porque o Verbo se fez carne, para que tua Sabedoria, pela qual criaste todas as coisas, fosse o leite de nossa infância.

 Não tendo humildade, eu não possuía Jesus, o Deus da humildade, e não atinava o que nos poderia ensinar sua fraqueza. Porque teu Verbo, verdade eterna, dominando as criaturas mais sublimes da tua criação, levanta a si as que se lhe sujeitam e, nas partes inferiores, construiu para si, com o nosso lodo, uma humilde morada. Assim faz para humilhar e arrancar de si mesmos aqueles que deseja sujeitar e atrair, curando-lhes a soberba e alimentando-lhes o amor, para que, confiando em si, não se afastem para mais longe. Pelo contrário, que se humilhem, vendo a seus pés a humildade de um Deus que também se vestiu de nossa túnica de carne, e cansados, se prostrem diante dela para que, ao se levantar, os exalte.

## CAPÍTULO XIX

### A doutrina do verbo

 Mas eu então julgava de outro modo. Considerava meu Senhor Jesus Cristo apenas um homem de extraordinária sabedoria, a quem ninguém poderia igualar. Sobretudo seu miraculoso nascimento de uma virgem, que nos ensina a desprezar os bens temporais para adquirir a imortalidade. Parecia-me ter merecido, por decreto da Providência divina, uma soberana autoridade para ensinar os homens.

 Mas nem suspeitava o mistério que se encerra nestas palavras: o Verbo se fez carne. Somente conhecia, pelas coisas que dele nos deixaram escritas, que comeu, bebeu, dormiu, passeou, que se alegrou, se entristeceu e pregou, e que essa carne não se juntou a teu Verbo senão com alma e inteligência humanas. Tudo isso sabe quem conhece a imutabilidade de teu Verbo, que eu já conhecia quanto me era possível, sem que disso nada duvidasse. Com efeito, mover os membros do corpo à vontade, ou não movê-los, estar dominado por algum afeto ou não o estar, traduzir por palavras sábios pensamentos e depois calar, são caracteres próprios da mutabilidade da alma e da inteligência. Se esses testemunhos das Escrituras fossem falsos, tudo o mais correria o risco de ser mentira, e o gênero humano não teria mais nesses livros a fé, condição de salvação. Mas como são verdadeiras as coisas nela escritas, eu reconhecia em Cristo um homem completo, não somente o corpo de um homem, ou um corpo sem uma alma inteligente, mas um homem real, que eu julgava superior a todos os outros não por ser a personificação da verdade, mas em razão da singular excelência de sua natureza humana, e de uma mais perfeita participação na sabedoria.

 Alípio porém pensava que os católicos, crendo em um Deus revestido de carne, entendiam quem eu em Cristo, além de Deus e da carne, não havia alma humana; e não julgava que lhe atribuíssem inteligência humana. E como estava bem persuadido de que os atos atribuídos tradicionalmente a Cristo não podiam ser senão obras de um criatura cheia de vida e de inteligência, Alípio se aproximava com certa relutância da fé cristã. Mas depois, ao saber que este erro era próprios dos hereges apolinaristas, aderiu alegremente à fé católica.

 De minha parte, confesso que só aprendi mais tarde a diferença de interpretação das palavras "o Verbo se fez carne", entre a verdade católica e o erro do Fotino (bispo de Sírmio, afirmava que o Verbo não havia sido Filho de Deus até encarnar-se nas entranhas da Virgem Maria, negando toda união substancial entre a natureza humana e o Verbo divino). A reprovação dos hereges põe às claras o pensamento da tua Igreja e o que esta considera como doutrina sã. Convém pois que haja heresias, para que os fortes se distingam entre os fracos.

## CAPÍTULO XX

### Do platonismo às Escrituras

 Depois de ter lido aqueles livros dos platônicos, induzido por eles a buscar a verdade incorpórea, começaram a se tornarem patentes, por meio de tuas obras, tuas perfeições visíveis. Repelido para longe de ti, compreendi em que consistia essa verdade, que as trevas de minha alma me impediam de contemplar. Estava certo de tua existência e de que és infinito, sem contudo te estenderes por espaços finitos ou infinitos; e de que és verdadeiramente aquele que é sempre idêntico a si mesmo, sem te mudares em outro, nem sofrer alteração alguma, quer parcialmente ou com algum movimento, quer de qualquer outro modo; e de que tudo o mais vem de ti, pela única e irrefutável razão de que existe. Tinha certeza de todas estas verdades, mas me achava ainda demasiado fraco para gozar de ti. Tagarelava muito, como se fora competente nisso, mas se não procurasse o caminho da verdade em Cristo, nosso Salvador, não seria perito, mas perituro. Já começava a querer parecer sábio, cheio de meu castigo, e não chorava, mas orgulhava-me com a ciência. Onde estava aquela caridade erigida sobre o alicerce da humildade, que é Cristo Jesus? Ou talvez me a ensinariam aqueles livros? Creio que quiseste que com eles me encontrasse antes de meditar nas tuas Escrituras, para que fixassem em minha memória os afetos que nela experimentei. Depois, quando encontrasse em teus livros a paz do coração, sarada com tuas mãos as feridas de minha alma, pudesse discernir e perceber a diferença entre presunção e humildade, entre os que vêem para onde se deve ir, e não vêem por onde se vai, nem o caminho que conduz à pátria bem-aventurada, não só para contemplá-la, mas também para habitá-la.

 Porém, se me tivesse instruído em tuas sagradas letras, e em sua intimidade tivesse experimentado na doçura, para depois conhecer os livros dos platônicos, talvez eles me arrancassem dos sólidos fundamentos da piedade; ou, se eu tivesse persistido nos sentimentos salutares nelas hauridos, talvez julgasse que só por esses livros se poderia chegar ao mesmo proveito espiritual.

## CAPÍTULO XXI

### A verdade das escrituras

 Por isso lancei-me avidamente sobre as veneráveis escrituras inspiradas por teu Espírito, sobretudo ao do apóstolo Paulo. E desnaveceram em mim aquelas dificuldades nas quais julguei descobrir contradições entre ele e seu texto, em desacordo com os testemunhos da Lei e dos Profetas. Compreendi a unidade daqueles castos escritos, e aprendi a me alegrar com tremor.

 Comecei a lê-los e compreendi que tudo de verdadeiro que lera nos tratados dos neoplatônicos se encontrava ali, mas com o aval da tua graça, para que aquele que vê não se glorie como se não houvesse recebido não só o que vê, mas também a faculdade de ver. Com efeito, que tem ele que não tenha recebido? E tu, que és imutável, não só o alertas para que te veja, mas também para que seja curado, para te possuir. Aquele que está muito longe de te ver, tome, contudo, o caminho para chegar a ti, para te ver e te possuir.

 Porque, embora o homem se deleite com a lei de Deus, segundo o homem interior, que fará dessa outra lei que luta em seus membros contra a lei de seu espírito, e que o prende sob a lei do pecado, impressa em seus membros? Porque tu és justo, Senhor; nós, porém, pecamos, cometemos iniqüidades; procedemos como ímpios, e tua mão se fez pesada sobre nós, e é com justiça que fomos entregues ao pecador antigo, ao príncipe da morte, porque ele persuadiu nossa vontade a se conformar à sua, que não quis persistir com tua verdade.

 Que fará esse homem infeliz? Quem o livrará deste corpo de morte, senão tua graça, por Jesus Cristo, nosso Senhor, a quem tu geraste co-eterno e criaste no princípio de teus caminhos, ele, em quem o príncipe deste mundo não achou nada que merecesse a morte, e a quem, contudo, matou? Com o que foi anulada a sentença que havia contra nós?

 Nada disso dizem os livros platônicos. Nem têm naquelas páginas esse sentimento de piedade, as lágrimas da confissão, esse teu sacrifício, a alma abatida, esse coração contrito e humilhado, nem a salvação de teu povo, nem a cidade prometida, nem o penhor do Espírito Santo, nem o cálice de nossa redenção.

 Nos livros platônicos ninguém canta: "Minha alma não estará sujeita a Deus? Porque dele procede minha salvação, pois é meu Deus e meu amparo, do qual não mais me apartarei.

 Ninguém ali ouvi o convite: Vinde a mim os que sofreis. Desdenham teus ensinamentos, porque és manso e humilde de coração. Porque escondeste estas coisas dos sábios e doutos, e as revelaste aos pequeninos.

 Uma coisa é ver de um monte agreste a pátria da paz, e não encontrar o caminho que conduz a ela, e fatigar-se debalde por lugares inacessíveis, entre ataques e emboscadas dos desertores fugitivos, com seu chefe, o leão e o dragão, e outra coisa é conhecer o caminho que conduz até lá, defendido pelos cuidados do imperador celeste, e onde não roubam os desertores da milícia do céu, pois eles o evitam como um suplício.

 Esses pensamentos penetravam-me as entranhas de modo maravilhoso, quando eu lia o menor de teus apóstolos. Considerava tuas obras e enchia-me de assombro.