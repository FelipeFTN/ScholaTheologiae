## CAPÍTULO X

### A descoberta de Deus

 Estimulado por estas leituras a voltar a mim mesmo, entrei, guiado por ti, no profundo de meu coração, e o pude fazer porque te fizeste minha ajuda. Entrei, e vi com os olhos da alma, acima desses mesmos olhos, acima de minha inteligência, a luz imutável; não esta vulgar e visível a todos os olhos de carne, nem outra do mesmo gênero, embora maior. Era muito mais clara e enchendo com sua força todo o espaço. Não, não era esta luz, mas uma luz diferente de todas estas.

 Ela não estava sobre meu espírito como o azeite sobre a água, como o céu sobre a terra, mas estava acima de mim porque me criou; eu lhe era inferior por ter sido criado por ela. Quem conhece a verdade conhece a luz, e quem a conhece, conhece a eternidade. O amor a conhece!

 Ó eterna verdade, amor verdadeiro, amada eternidade! Tu és meu Deus. Por ti suspiro dia e noite. Quando te conheci pela primeira vez, ergueste-me para me fazer ver que havia algo para ser visto, mas que eu ainda era incapaz de ver. E deslumbraste a fraqueza de minha vista com o fulgor do teu brilho, e eu estremeci de amor e temor. Pareceu-me estar longe de ti numa região desconhecida, como se ouvira tua voz do alto: "Sou o pão dos fortes; cresce, e comer-me-ás. Não me transformarás em ti, como fazes com o alimento da tua carne, mas tu serás mudado em mim".

 E conheci então que "castigaste o homem por causa de sua iniqüidade", e "que secaste minha alma como uma teia de aranha", e eu disse: Porventura não existe a verdade, por não ser difusa pelos espaços finitos e infinitos? E tu me gritaste de longe: Na verdade, Eu sou o que sou. E eu ouvi como se ouve no coração, sem deixar motivo para dúvidas; antes, mais facilmente duvidaria de minha vida que da existência da verdade, que se manifesta à inteligência pelas coisas da criação.