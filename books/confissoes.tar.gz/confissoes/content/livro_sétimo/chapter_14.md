## CAPÍTULO XIV

### Recapitulação

 Não têm juízo sadio, nos que se desagradam com alguma parte de tua criação, como acontecia comigo, quando me desagradavam tantas de tuas obras. Mas, como minha alma não se atrevia a desgostar do meu Deus, não queria considerar como obra tua o que lhe desagradava.

 Por isso fora atrás da teoria das duas substâncias, na qual não achava descanso, e repetia coisas alheias. Desembaraçando-me desses erros, imaginara para si um Deus que se difundia pelos espaços infinitos e, julgando que eras tu, colocou-o em seu coração, e de novo se tornou o templo de seu ídolo, coisa abominável a teus olhos.

 Mas, depois que afagaste minha cabeça, sem que eu o percebesse, e fechaste meus olhos para não vissem a vaidade, desprendi-me um pouco de mim mesmo, e minha loucura adormeceu profundamente; quando despertei em teus braços, vi que eras infinito não daquele modo, e esta visão não procedia da carne.