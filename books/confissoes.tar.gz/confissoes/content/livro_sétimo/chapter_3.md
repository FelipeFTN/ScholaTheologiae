## CAPÍTULO III

### Deus e o mal

 Mas eu, mesmo quando afirmava e cria firmemente que és incorruptível, inalterável, absolutamente imutável, Senhor meu, Deus verdadeiro que não só criaste nossas almas e nossos corpos, e não somente nossas almas e corpos, mas todas as criaturas e todas as coisas. Todavia, faltava-me ainda uma explicação, a solução do problema da causa do mal. Qualquer que ela fosse, estava certo de que deveria buscá-la onde não me visse obrigado, por sua causa, a julgar mutável a um Deus imutável, porque isso seria transformar-me no mal que procurava.

 Por isso, buscava-a com segurança, certo de que era falsidade o que diziam os maniqueus; deles fugia com toda a alma, porque via suas indagações sobre a origem do mal cheias de malícia, preferindo crer que tua substância era passível de sofrer o mal do que a deles ser susceptível de o cometer.

 Esforçava-me por compreender a tese que ouvira professar, de que o livre-arbítrio da vontade é a causa de praticarmos o mal, e de teu reto juízo é a causa do mal que padecemos. Mas era incapaz de entendê-lo com clareza. E esforçando-me por afastar desse abismo os olhos do meu espírito, nele me precipitava de novo, e tentando reiteradamente fugir dele, sempre voltava a recair.

 O fato de eu ter a consciência de possuir uma vontade, como tinha consciência de minha vida, era o que me erguia para a tua luz. Assim, quando queria ou não queria alguma coisa, estava certíssimo de que era eu, e não outro, o que queria ou não queria, e então me convencia de que ali estava a causa do meu pecado. Quanto ao que fazia contra a vontade, notava que isso mais era padecer do mal do que praticá-lo; julgava que isso não era culpa, mas castigo, que me instava a confessar justamente ferido por ti, considerando tua justiça.

 Mas de novo refletia: "Quem me criou? Não foi o bom Deus, que não só é bom, mas a própria bondade? De onde, então, me vem essa vontade de querer o mal e de não querer o bem? Seria talvez para que eu sofra as penas merecidas? Quem depositou em mim, e semeou minha alma esta semente de amargura, sendo eu totalmente obra de meu dulcíssimo Deus? Se foi o demônio que me criou, de onde procede ele? E se este, de anjo bom se fez demônio, por decisão de sua vontade perversa, de onde lhe veio essa vontade má que o transformou em diabo, tendo ele sido criado anjo por um Criador boníssimo?"

 Tais pensamentos de novo me deprimiam e sufocavam, mas não me arrastavam até aquele abismo de erro, onde ninguém te confessa, e onde se antepõe a tese que tu és sujeito ao mal a considerar o homem capaz de o cometer.