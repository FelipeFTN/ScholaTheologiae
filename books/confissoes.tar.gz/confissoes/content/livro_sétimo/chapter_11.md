## CAPÍTULO XI

### Deus e as criaturas

 E contemplei as outras coisas que estão abaixo de ti, e vi que nem existem absolutamente, e nem absolutamente deixam de existir. Certamente existem, porque procedem de ti; mas não existem, pois, não são o que tu és,, porque só existe verdadeiramente o que permanece imutável. Com isso, para mim é bom apegar-me a Deus, porque, se não permanecer nele, tampouco poderei permanecer em mim. ele, porém, permanecendo em si, renova todas as coisas, e tu és o meu Senhor, porque não necessitas de meus bens.