## CAPÍTULO XXI

### A verdade das escrituras

 Por isso lancei-me avidamente sobre as veneráveis escrituras inspiradas por teu Espírito, sobretudo ao do apóstolo Paulo. E desnaveceram em mim aquelas dificuldades nas quais julguei descobrir contradições entre ele e seu texto, em desacordo com os testemunhos da Lei e dos Profetas. Compreendi a unidade daqueles castos escritos, e aprendi a me alegrar com tremor.

 Comecei a lê-los e compreendi que tudo de verdadeiro que lera nos tratados dos neoplatônicos se encontrava ali, mas com o aval da tua graça, para que aquele que vê não se glorie como se não houvesse recebido não só o que vê, mas também a faculdade de ver. Com efeito, que tem ele que não tenha recebido? E tu, que és imutável, não só o alertas para que te veja, mas também para que seja curado, para te possuir. Aquele que está muito longe de te ver, tome, contudo, o caminho para chegar a ti, para te ver e te possuir.

 Porque, embora o homem se deleite com a lei de Deus, segundo o homem interior, que fará dessa outra lei que luta em seus membros contra a lei de seu espírito, e que o prende sob a lei do pecado, impressa em seus membros? Porque tu és justo, Senhor; nós, porém, pecamos, cometemos iniqüidades; procedemos como ímpios, e tua mão se fez pesada sobre nós, e é com justiça que fomos entregues ao pecador antigo, ao príncipe da morte, porque ele persuadiu nossa vontade a se conformar à sua, que não quis persistir com tua verdade.

 Que fará esse homem infeliz? Quem o livrará deste corpo de morte, senão tua graça, por Jesus Cristo, nosso Senhor, a quem tu geraste co-eterno e criaste no princípio de teus caminhos, ele, em quem o príncipe deste mundo não achou nada que merecesse a morte, e a quem, contudo, matou? Com o que foi anulada a sentença que havia contra nós?

 Nada disso dizem os livros platônicos. Nem têm naquelas páginas esse sentimento de piedade, as lágrimas da confissão, esse teu sacrifício, a alma abatida, esse coração contrito e humilhado, nem a salvação de teu povo, nem a cidade prometida, nem o penhor do Espírito Santo, nem o cálice de nossa redenção.

 Nos livros platônicos ninguém canta: "Minha alma não estará sujeita a Deus? Porque dele procede minha salvação, pois é meu Deus e meu amparo, do qual não mais me apartarei.

 Ninguém ali ouvi o convite: Vinde a mim os que sofreis. Desdenham teus ensinamentos, porque és manso e humilde de coração. Porque escondeste estas coisas dos sábios e doutos, e as revelaste aos pequeninos.

 Uma coisa é ver de um monte agreste a pátria da paz, e não encontrar o caminho que conduz a ela, e fatigar-se debalde por lugares inacessíveis, entre ataques e emboscadas dos desertores fugitivos, com seu chefe, o leão e o dragão, e outra coisa é conhecer o caminho que conduz até lá, defendido pelos cuidados do imperador celeste, e onde não roubam os desertores da milícia do céu, pois eles o evitam como um suplício.

 Esses pensamentos penetravam-me as entranhas de modo maravilhoso, quando eu lia o menor de teus apóstolos. Considerava tuas obras e enchia-me de assombro.