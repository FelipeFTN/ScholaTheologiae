## CAPÍTULO II

### Objeção contra o maniqueísmo

 Bastava-me, Senhor, para calar aqueles enganados enganadores e muitos charlatães – pois o que se ouvia de sua boca não era a tua palavra – bastava-me, certamente, o argumento que há muito tempo, estando ainda em Cartago, costumava propor-lhes Nebrídio, impressionando a todos os que então o ouvimos.

 "Que poderia fazer contra ti – dizia aquela não sei que raça de trevas, que os maniqueus costumam opor-te como massa hostil – se não quisesses lutar contra ela?"

 Se respondessem que te podia ser nociva em algo, então serias violável e corruptível. Se dissessem que não te podia prejudicar nada, não haveria razão para luta. Luta essa em que uma parte de ti mesmo, um de teus membros, produto de tua própria substância, se misturava às forças adversas, a naturezas não criadas por ti. Assim se corromperia, degradando-se a ponto de mudar sua felicidade em miséria e de necessitar de auxílio para se libertar e purificar. E essa parte de ti seria a alma que teu Verbo devia salvar da escravidão, ele que é livre de impurezas, ele que é imaculado da corrupção, ele que é intacto sem ser corruptível, sendo feito de uma só e mesma substância.

 E assim, se declaram incorruptível tudo o que és, isto é, a substância que te forma, todas essas proposições são erros execráveis; e se eles te consideram corruptível, essa mesma afirmação também é falsa, e abominável logo à primeira vista.

 Bastava-me, pois, este argumento contra aqueles que eu queria expulsar de vez de meu peito angustiado. De fato, sentindo e dizendo tais coisas de ti, não tinham outra saída senão um horrível sacrilégio de coração e de língua.