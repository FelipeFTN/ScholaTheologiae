## CAPÍTULO XVI

### Onde está o mal

 Entendi por experiência que não é de admirar que o pão seja enjoativo ao paladar enfermo, mesmo tão agradável para o paladar sadio, e que olhos enfermos considerem odiosa a luz, que para os límpidos é tão cara. Se tua justiça desagrada aos maus, muito mais desagradam a víbora e o caruncho, que criaste bons e adaptados à parte inferior da tua criação, com a qual também os maus se assemelham, tanto mais quanto mais diferem de ti, assim como os justos se assemelham às partes superiores do mundo na medida em que se assemelham a ti.

 Indaguei o que era a iniqüidade, e não achei substância, mas a perversão de uma vontade que se afasta da suprema substância, de ti, meu Deus – e se inclina para as coisas baixas, e que derrama suas entranhas, e se intumesce exteriormente.