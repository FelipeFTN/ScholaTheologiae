## CAPÍTULO VIII

### A piedade de Deus

Mas tu, Senhor, permaneces eternamente, e não te iras eternamente contra nós, porque te compadeceste da terra e do pó, e foi de teu agrado corrigir minhas deformidades. Tu me aguilhoavas com estímulos interiores para que estivesse impaciente, até que por uma visão interior, te tornasses para mim uma certeza. O inchaço de meu orgulho baixava graças à mão secreta de tua medicina; a vista de minha alma, perturbada e obscurecida, ia sarando dia a dia graças ao colírio das dores salutares.