## CAPÍTULO IV

### A substância de Deus

 Empenhava-me então por descobrir as outras verdades, como havia descoberto que o incorruptível é melhor que o corruptível, e por isso confessava que tu, qualquer que fosse tua natureza, devias ser incorruptível. Porque ninguém pôde nem poderá jamais conceber algo melhor do que tu, que és o sumo bem por excelência. Por isso, sendo certíssimo e inegável que o incorruptível é superior ao corruptível, o que eu já fazia, meu pensamento já poderia conceber algo melhor do que o meu Deus, se não fosses incorruptível.

 Portanto, logo que vi que o incorruptível deve ser preferido ao corruptível, imediatamente deveria buscar-te no incorruptível, para depois indagar a causa do mal, isto é, a origem da corrupção, que de nenhum modo pode afetar tua substância. É certo que, nem por vontade, nem por necessidade, nem por qualquer acontecimento imprevisto, pode a corrupção afetar nosso Deus, porque ele é Deus, e não pode querer senão o que é bom, e ele próprio é o sumo bem; e estar sujeito à corrupção não é nenhum bem.

 Tampouco poder ser obrigado, contra a tua vontade, seja ao que for, porque tua vontade não é maior do que teu poder. Seria maior caso pudesses ser maior do que és, pois a vontade e o poder de Deus são o mesmo Deus. E que pode haver de imprevisto para ti, se conheces todas as coisas, e se todas elas existem porque as conheces?

 Mas, por que tantas palavras para demonstrar que a substância de Deus não é corruptível, já que se o fosse não seria Deus?