## CAPÍTULO XV

### Deus e a criação

 Contemplei depois as outras coisas, e vi que deviam a ti sua existência, e que todas estão contidas em ti, não como em um lugar material, mas de modo diferente: conservas todas elas em tua verdade, sustentadas na tua mão; todas as coisas são verdadeiras enquanto existem, e só é falso o que julgamos existir, mas não existe.

 Também vi que cada coisa adapta-se não só a seus lugares, mas também a seus tempos, e que tu, que és o único eterno, não começaste a agir depois de infinitos espaços de tempos, porque todos os espaços de tempo – passados ou futuros – não teriam passado nem viriam se tu não agistes e não fosses permanente.