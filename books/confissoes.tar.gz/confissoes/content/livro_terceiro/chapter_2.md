## CAPÍTULO II

### A paixão dos espetáculos

 Arrebatavam-me os espetáculos teatrais, cheios das imagens de minhas misérias e de alimento para o fogo de minha paixão. Mas, por que quer o homem condoer-se ao contemplar coisas tristes e trágicas, que de modo algum gostaria de suportar? Contudo, o espectador deseja sofrer com elas, e até essa mesma dor é seu deleite. Que é isso, senão rematada loucura? De fato, tanto mais se comove alguém com elas quanto menos livre se está de tais afetos, embora chamemos de misérias os sofrimentos próprios, e de compaixão a comiseração do mal alheio.

 Porém, que compaixão pode haver em coisas fictícias e representadas? Nelas não se incita o espectador a que socorra a alguém, senão que o mesmo é convidado apenas à angústia, apreciando tanto mais o autor daquelas histórias quanto maior é o sentimento que elas nos inspiram. De onde resulta que, se tais desgraças humanas – quer das histórias antigas, quer sejam inventadas – são representadas de forma a não se excitarem sofrimento ao expectador, este sai aborrecido e murmurando; se porém, pelo contrário, é levado à tristeza, fica atento e chora satisfeito.

 Quer isso dizer que amamos as lágrimas e a dor? Sem dúvida que todo homem busca o gozo; mas como não agrada a ninguém ser miserável, e sendo grato a todos ser misericordioso, e como a piedade é inseparável da dor, não seria esta a causa verdadeira para que apreciemos essas emoções dolorosas?

 Também isso provém da amizade. Mas para onde se dirige? Para onde vai? Por que se atira à torrente da pez ardente, às vagas horrendas de negras leviandades em que a amizade se transforma voluntariamente, afastada e privada de sua celestial serenidade que o homem repudia?

 Deve-se, pois, repelir a compaixão? De modo algum. Convém, pois, que alguma vez se amem as dores. Mas evita nisso a impureza, ó minha alma, sob proteção de Deus, do Deus de nossos pais, louvado e exaltado por todos os séculos; cuidado com a impureza. Porque nem agora me fecho a tal compaixão. Mas naquele tempo comprazia-me no teatro com os amantes, quando eles se gozavam em suas torpezas – embora estas não passassem de encenações. E quando um deles se perdia, eu quase piedosamente me contristava, e sentia prazer numa e noutra coisa.

 Hoje, porém, tenho mais compaixão do homem que se alegra em seus vícios, que do que sofre pela perda de um prazer funesto ou pela perda de uma mísera felicidade. Esta misericórdia é certamente mais verdadeira, mas nela a dor não encontra nenhum prazer. E embora seja certo que se aprove quem por caridade se compadece do miserável, contudo, quem é fraternalmente compassivo preferiria que não houvesse razões para se compadecer. Porque assim como não é possível que exista uma benevolência malévola, tampouco o é que haja miseráveis para deles se compadecer.

 Há, pois, dores que merecem compaixão, porém, nenhuma que mereça amor. Por isso tu, Deus, que amas as almas muito mais elevadamente que nós, te compadeces delas de modo muito mais puro, porque não sentes nenhuma dor. Mas quem será capaz de chegar a isso?

 Mas eu, desventurado, amava então a dor, e buscava motivos para senti-la. Naquelas desgraças alheias, falsas e mímicas, agradava-me tanto mais a ação do ator, e me mantinha tanto mais atento quanto mais copiosas lágrimas me fazia derramar.

 Mas, que admira que eu, infeliz ovelha transviada de teu rebanho, por não aceitar tua proteção, estivesse atacado de ronha asquerosa? De aqui nasciam, sem dúvida, os desejos daquelas emoções de dor que, todavia, não queria que fossem muito profundas em mim, porque não desejava padecer coisas como as que via representadas. Comprazia-me que aquelas coisas, ouvidas ou fingidas, me tocassem só superficialmente. Mas, como acontece aos que coçam a ferida com as unhas, terminava por provocar em mim mesmo um tumor abrasador, podridão e pus repelente.

Tal era minha vida. Mas, seria isto vida, meu Deus?