## CAPÍTULO X

### Ridicularias dos maniqueus

 Desconhecendo eu essas verdades, ria-me de teus santos e profetas. Mas, que fazia eu quando me ria deles, senão dar motivo para que te risses de mim? deixei-me cair insensivelmente, aos poucos, em tais extravagâncias, a ponto de acreditar que o figo, quando colhido, chora lágrimas de leite junto com a mãe figueira, e que se um "santo" da seita comesse o tal figo, colhido não por seu delito, mas de outrem, misturando-o em suas entranhas, gemendo e arrotando enquanto rezava, exalaria anjos e até mesmo partículas de Deus, partículas essas do verdadeiro Deus que ficariam cativas para sempre naquele fruto se não fossem libertadas pelos dentes e pelo estômago do "santo eleito"!

 Também acreditei, pobre de mim, que se devia ter mais misericórdia com os frutos da terra que com os homens para os quais foram criados. Pois, se algum faminto, que não fosse maniqueísta me pedisse de comer, parecia-me que atendê-lo era como merecer, por aquele bocado, a pena de morte.