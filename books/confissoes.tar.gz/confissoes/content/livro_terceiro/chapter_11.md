## CAPÍTULO XI

### O sonho de Mônica

 Mas estendeste tua mão do alto, e arrancaste minha alma deste abismo de trevas, enquanto minha mãe, tua fiel serva, chorava-me diante de ti muito mais do que as outras mães costumam chorar sobre o cadáver dos filhos, pois via a morte de minha alma com a fé e o espírito que havia recebido de ti. E tu a escutaste, Senhor, tu a ouviste e não desprezaste suas lágrimas que, brotando copiosas, regavam o solo debaixo de seus olhos por onde fazia sua oração; sim, tu a escutaste, Senhor. Com efeito, donde podia vir aquele sonho, com que a consolaste, ao ponto de me admitir em sua companhia e mesa, fato que havia me negado porque aborrecia e detestava as blasfêmias do meu erro?

 Nesse sonho viu-se de pé sobre uma régua de madeira; e um jovem resplandecente, alegre e risonho que vinha ao seu encontro, triste e amarga. Este lhe perguntou a causa de sua tristeza e lágrimas diárias, não por curiosidade, como sói acontecer, mas para instruí-la; e respondendo-lhe ela que chorava a minha perdição, mandou-lhe, para sua tranqüilidade, que prestasse atenção e visse por onde ela estava também estaria eu. Apenas olhou, viu-me junto de si, de pé sobre a mesma régua.

 De onde veio este sonho, senão dos ouvidos que tinhas atentos a seu coração, ó Deus bom e onipotente, que cuidas de cada um de nós como se não tivesses outro para cuidar, zelando de todos como de cada um!

 E como explicar o que se segue? Contou-me minha mãe esta visão, e querendo-a eu persuadir de que significava o contrário, e que não devia desesperar de ser algum dia o que eu era, isto é, maniqueísta, ela, sem nenhuma hesitação, me respondeu: "Não; não me foi dito: onde ele está ali estarás tu, mas onde tu estás ali estará ele também".

 Confesso, Senhor, e muitas vezes disse que, pelo que me recordo, me abalou mais esta tua resposta pela solicitude de minha mãe, imperturbável diante de explicação falsa e ardilosa, e por ter visto o que se devia ver – e que eu certamente não veria sem que ela o dissesse – que o mesmo sonho com o qual anunciaste a esta piedosa mulher com tanta antecedência, a fim de consolá-la em sua aflição presente, uma alegria que só havia de se realizar muito tempo depois.

 Seguiram-se, efetivamente, quase nove anos, durante os quais continuei a me revolver naquele abismo de lodo e trevas de erro, afundando-me tanto mais quanto mais esforços fazia para me libertar. Entretanto, aquela piedosa viúva, casta e sóbria como as que tu amas, já um pouco mais alegre com a esperança, porém, não menos solícita em suas lágrimas e gemidos, não cessava de chorar por mim em tua presença em todas as horas de suas orações; e suas preces eram aceitas a teus olhos, mas deixava-me ainda revolver-me e envolver-me naquela escuridão.