## CAPÍTULO IX

### Pecados e imperfeições

 Mas, entre tantas maldades, crimes e iniqüidades, estão os pecados dos que progridem, pecados que os homens de bom juízo vituperam, segundo a regra da perfeição, e louvam pela esperança de frutos futuros, como o verde é promissor das colheitas.

 Há outras ações semelhantes a ações maldosas ou a delitos, e que não são pecados, porque nem te ofendem a ti, Senhor, nosso Deus, nem tampouco à sociedade humana; como por exemplo quando procuramos coisas convenientes para o uso da vida e às circunstâncias, sem que se saiba se essa busca é cobiça, ou quando castigamos a alguém como desejo de que se corrija, fazendo uso do poder ordinário, e não se sabe se o fazemos por vontade de mortificar.

 Por isso, muitas ações que parecem condenáveis aos homens, são aprovadas por teu testemunho; e muitas, louvadas pelos homens, são condenadas por teu testemunho, porque muitas vezes as aparências do ato diferem das intenções do seu autor, assim como circunstâncias ocultas do tempo.

 Mas quando ordenas, algo insólito e imprevisto, mesmo que o tenhas proibido uma vez, mesmo que escondas por algum as razões do teu mandamento, mesmo que seja contra as convenções de alguns homens da sociedade, quem pode duvidar de que se há de obedecer, sendo que só é justa a sociedade humana que te obedece? Felizes dos que sabem o que tu ordenaste, porque os que te servem fazem tudo o que mandas, ou porque assim o exige o tempo presente, ou para preparar o futuro.