# LIVRO TERCEIRO

## CAPÍTULO I

### O gosto do amor

 Cheguei a Cartago, e por toda parte fervilhava a sertã de amores impuros. Ainda não amava, mas já gostava de amar; secretamente sedento, aborrecia a mim próprio por não me sentir mais indigente de amor. Gostando do amor buscava o que amar, e odiava a segurança e os meus caminhos sem perigos, porque tinha dentro de mim fonte de alimento interior, de ti mesmo, ó meu Deus. Eu não sentia essa fonte como tal; antes, estava sem apetite algum dos manjares incorruptíveis, não porque estivesse saciado deles, mas porque, quanto mais vazio, tanto mais enfastiado me sentia.

 E por isso minha alma não estava bem e, ferida, voltava-se para fora de si, ávida de se roçar miseravelmente às coisas sensíveis; se porém não tivessem alma, não seriam certamente amadas.

 Amar e ser amado era para mim a coisa mais doce, sobretudo se podia gozar do corpo da criatura amada. Deste modo manchava com torpe concupiscência a fonte da amizade, e obscurecia seu candor com os vapores infernais da luxúria. E apesar de tão torpe e impuro, desejava com afã e cheio de vaidade, passar por afável e cortês.

 Caí por fim no amor, em que desejava ser colhido. Porém, ó meu Deus, misericórdia minha, quanto fel não misturaste àquela suavidade, e quão bom foste ao fazê-lo! Fui amado, e cheguei secretamente aos laços do prazer, e me deixei alegremente enredar com trabalhosos laços, para ser logo açoitado com as varas de ferro ardente do ciúme, das suspeitas, dos temores, das iras e das contendas.

## CAPÍTULO II

### A paixão dos espetáculos

 Arrebatavam-me os espetáculos teatrais, cheios das imagens de minhas misérias e de alimento para o fogo de minha paixão. Mas, por que quer o homem condoer-se ao contemplar coisas tristes e trágicas, que de modo algum gostaria de suportar? Contudo, o espectador deseja sofrer com elas, e até essa mesma dor é seu deleite. Que é isso, senão rematada loucura? De fato, tanto mais se comove alguém com elas quanto menos livre se está de tais afetos, embora chamemos de misérias os sofrimentos próprios, e de compaixão a comiseração do mal alheio.

 Porém, que compaixão pode haver em coisas fictícias e representadas? Nelas não se incita o espectador a que socorra a alguém, senão que o mesmo é convidado apenas à angústia, apreciando tanto mais o autor daquelas histórias quanto maior é o sentimento que elas nos inspiram. De onde resulta que, se tais desgraças humanas – quer das histórias antigas, quer sejam inventadas – são representadas de forma a não se excitarem sofrimento ao expectador, este sai aborrecido e murmurando; se porém, pelo contrário, é levado à tristeza, fica atento e chora satisfeito.

 Quer isso dizer que amamos as lágrimas e a dor? Sem dúvida que todo homem busca o gozo; mas como não agrada a ninguém ser miserável, e sendo grato a todos ser misericordioso, e como a piedade é inseparável da dor, não seria esta a causa verdadeira para que apreciemos essas emoções dolorosas?

 Também isso provém da amizade. Mas para onde se dirige? Para onde vai? Por que se atira à torrente da pez ardente, às vagas horrendas de negras leviandades em que a amizade se transforma voluntariamente, afastada e privada de sua celestial serenidade que o homem repudia?

 Deve-se, pois, repelir a compaixão? De modo algum. Convém, pois, que alguma vez se amem as dores. Mas evita nisso a impureza, ó minha alma, sob proteção de Deus, do Deus de nossos pais, louvado e exaltado por todos os séculos; cuidado com a impureza. Porque nem agora me fecho a tal compaixão. Mas naquele tempo comprazia-me no teatro com os amantes, quando eles se gozavam em suas torpezas – embora estas não passassem de encenações. E quando um deles se perdia, eu quase piedosamente me contristava, e sentia prazer numa e noutra coisa.

 Hoje, porém, tenho mais compaixão do homem que se alegra em seus vícios, que do que sofre pela perda de um prazer funesto ou pela perda de uma mísera felicidade. Esta misericórdia é certamente mais verdadeira, mas nela a dor não encontra nenhum prazer. E embora seja certo que se aprove quem por caridade se compadece do miserável, contudo, quem é fraternalmente compassivo preferiria que não houvesse razões para se compadecer. Porque assim como não é possível que exista uma benevolência malévola, tampouco o é que haja miseráveis para deles se compadecer.

 Há, pois, dores que merecem compaixão, porém, nenhuma que mereça amor. Por isso tu, Deus, que amas as almas muito mais elevadamente que nós, te compadeces delas de modo muito mais puro, porque não sentes nenhuma dor. Mas quem será capaz de chegar a isso?

 Mas eu, desventurado, amava então a dor, e buscava motivos para senti-la. Naquelas desgraças alheias, falsas e mímicas, agradava-me tanto mais a ação do ator, e me mantinha tanto mais atento quanto mais copiosas lágrimas me fazia derramar.

 Mas, que admira que eu, infeliz ovelha transviada de teu rebanho, por não aceitar tua proteção, estivesse atacado de ronha asquerosa? De aqui nasciam, sem dúvida, os desejos daquelas emoções de dor que, todavia, não queria que fossem muito profundas em mim, porque não desejava padecer coisas como as que via representadas. Comprazia-me que aquelas coisas, ouvidas ou fingidas, me tocassem só superficialmente. Mas, como acontece aos que coçam a ferida com as unhas, terminava por provocar em mim mesmo um tumor abrasador, podridão e pus repelente.

Tal era minha vida. Mas, seria isto vida, meu Deus?

## CAPÍTULO III

### O estudo da retórica e os demolidores

 Entretanto, tua misericórdia, fiel, de longe pairava sobre mim. Em quantas iniqüidades não me corrompi, meu Deus, levado por sacrílega curiosidade que, separando-me de ti, conduzia-me aos mais baixos, desleais e enganosos serviços aos demônios, a quem sacrificava minhas más ações, sendo em todas flagelado com duro açoite por ti!

 Também ousei apetecer ardentemente e procurar meios para conseguir os frutos da morte na celebração de teus mistérios, dentro dos muros de tua igreja. Por isso me açoitaste com duras penas, que nada eram comparadas com minhas culpas, ó Deus, misericórdia infinita, e meu refúgio contra os terríveis malfeitores, com os quais vaguei de cabeça erguida, afastando-me cada vez mais de ti, preferindo meus caminhos aos teus, amando a liberdade fugitiva!

 Os estudos a que era entregue, que se denominavam honestos ou nobres, tinham por objetivo as contendas do foro, nas quais deveria me distinguir com tanto maior louvor quanto mais hábeis fossem as mentiras. Tal é a cegueira dos homens, que até de sua própria cegueira se gloriam!

 Eu já conseguira, naquele tempo, ser o primeiro da escola de retórica, e por isso me vangloriava soberbamente, e me inflava de orgulho. Contudo, tu sabes, Senhor, que eu era muito mais sossegado que os demais, e totalmente alheio às turbulências dos eversores – ou demolidores – nome sinistro e diabólico que eles consideravam distintivo de urbanidade, entre os quais vivia com imprudente pudor por não pertencer a seu grupo. É verdade que andava com eles, e que me deleitava, às vezes, com sua amizade, porém, sempre aborreci o que faziam, como as troças e a insolência com que surpreendiam e ridicularizavam a timidez dos novatos, sem outra finalidade senão rir de suas trapalhadas, fazendo disso alimento para suas malévolas alegrias. Nada há mais parecido a estas ações que as dos demônios, pelo que nenhum nome lhes cai melhor que o de eversores ou demolidores, por serem eles transformados e pervertidos totalmente pelos espíritos malignos, que assim os burlam e enganam, sem que o saibam, justamente no que eles gostam de ludibriar ou enganar os demais.

## CAPÍTULO IV

### O Hortênsio de Cícero

 Entre essa gente estudava eu, em tão tenra idade, os livros da eloqüência, na qual desejava sobressair com o fim condenável e vão de satisfazer à vaidade humana. Mas, seguindo o programa usado no ensino desses estudos, cheguei a um livro de Cícero, cuja linguagem, mais do que seu conteúdo, quase todos admiram. Esse livro contém uma exortação à filosofia, e se chama Hortênsio. Esse livro mudou meus sentimentos, e transferiu para ti, Senhor, minhas súplicas, e fez com que mudassem meus votos e desejos. Subitamente, tornou-se vil a meus olhos toda vã esperança, e com incrível ardor de meu coração suspirava pela sabedoria imortal, e comecei a me reerguer para voltar a ti. Não era para limar a linguagem – aperfeiçoamento que, parece, eu compraria com o dinheiro de minha mãe, naquela idade de meus dezenove anos, fazendo dois que morrera meu pai – não era, repito, para limar o estilo que eu me dedicava à leitura daquele livro, nem era seu estilo o que a ela me incitava, mas o que ele dizia.

 Como ardia, meu Deus, como ardia meus desejos de voar para ti das coisas terrenas, sem que eu soubesse o que obravas em mim! Porque em ti está a sabedoria, pela qual aquelas páginas me apaixonavam. Não faltam os que nos iludam servindo-se da filosofia, colocando ou encobrindo seus erros com nome tão grande, tão doce e honesto. Mas quase todos os que assim fizeram em seu tempo e em épocas anteriores, são apontados e refutados nesse livro. Também se encontra ali bem claro aquele salutar aviso de teu Espírito, dado por meio de teu servo bom e piedoso (Paulo): Vede que ninguém vos engane com vãs filosofias e argúcias sedutoras, de acordo com a tradição dos homens e os ensinamentos deste mundo, e não de acordo com Cristo, porque é nele que habita corporalmente toda a plenitude da divindade.

 Mas então – tu bem o sabes, luz de meu coração – eu ainda não conhecia o pensamento de teu Apóstolo. Só me deleitava naquelas palavras de exortação, o fato de me excitarem fortemente, inflamando-me a amar, a buscar, a conquistar, a reter e a abraçar não a esta ou àquela seita, senão à própria Sabedoria, onde quer que estivesse. Só uma coisa me arrefecia tão grande ardor: não ver ali o nome de Cristo. Porque este nome, Senhor, este nome de meu Salvador, teu filho, por tua misericórdia eu o bebera piedosamente com o leite materno, e o conservava, no mais profundo do meu coração, em alto apreço; e assim, tudo quanto fosse escrito sem este nome, por mais verídico, elegante e erudito que fosse, não me arrebatava totalmente.

## CAPÍTULO V

### A desilusão das escrituras

 Em vista disso, decidi dedicar-me ao estudo da Sagrada Escritura, para a conhecer. Vi ali algo encoberto para os soberbos e obscuro para as crianças, mas humilde a princípio e sublime à medida que se avança o velado de mistérios; e eu não estava disposto a poder entrar nela, dobrando a cerviz à sua passagem. Contudo, ao fixar nela a atenção, não pensei o que agora estou dizendo, mas simplesmente me pareceu indigna de ser comparada com a majestade dos escritos de Cícero. Meu orgulho recusava sua simplicidade, e minha mente não lhe penetrava o íntimo. Contudo, a agudeza desta visão haveria de crescer com os pequenos; mas eu de nenhum modo queria ser criança e, enfatuado de soberba, considerava-me grande.

## CAPÍTULO VI

### A sedução do maniqueísmo

 Deste modo vim cair com uns homens que deliravam orgulhosos, demasiado carnais e loquazes; em sua boca havia laços diabólicos e engodo pegajoso feito com as silabas de teu nome, do nosso Senhor, Jesus Cristo, e do nosso Paráclito e Consolador, o Espírito Santo. Estes nomes nunca saíam de seus lábios, porém, só no som e ruído da boca, pois de resto, seu coração estava vazio de toda verdade.

 Diziam: "Verdade! Verdade!" – e, incessantemente, falavam-me da verdade, que nunca existiu neles; antes, diziam muitas falsidades, não apenas de ti, que és verdade por excelência, mas também dos elementos deste mundo, criação tua. Sobre isso, mesmo quando os filósofos diziam a verdade, tive de ultrapassá-los nos raciocínios por amor de ti, ó pai sumamente bom, beleza de todas as belezas!

 Ó verdade, verdade! Quão intimamente suspiravam por ti as fibras da minha alma, quando eles te faziam soar ao meu redor frequentemente e de muitos modos, embora apenas com as palavras e em seus muitos e volumosos livros. Estes eram as bandejas nas quais, estando eu faminto de ti, serviam-me em teu lugar o sol e a lua, formosas obras de tuas mãos, porém, obras tuas, e não a ti, nem sequer das principais. De fato, tuas obras espirituais são superiores a estas corporais, ainda que estas sejam brilhantes e celestes. Mas eu tinha sede e fome não daquelas primeiras, mas de ti mesmo, ó verdade, na qual não há mudança nem obscuridade momentânea!

 E eles serviam-me nessas bandejas esplendidas ficções, de acordo com as quais teria sido melhor amar a este sol, verdadeiro pelo menos aos olhos, em lugar daquelas falsidades que pelos olhos do corpo enganavam o entendimento.

 Contudo, como as tomava por ti, alimentava-me delas, não certamente com avidez, porque não tinham o teu gosto – pois não eras aqueles vãos fantasmas – nem me nutria com elas, antes sentia-me cada vez mais debilitado. A comida que se toma em sonhos, não obstante ser muito semelhante à do estado de vigília, não alimenta aos que dormem, porque estão dormindo. Aquilo, porém, em nada era semelhantes a ti, como agora me certificou a verdade, pois que eram fantasmas corpóreos ou falsos corpos; comparados com eles, são mais reais estes corpos – celestes ou terrestres – que vemos com os olhos da carne assim como os vêem os animais e as aves.

 Vemos estas coisas, e são mais reais do que as conjecturas sobre outros corpos grandiosos, que, por sua vez, que, por sua vez, quando as imaginamos, são mais reais do que quando por meio delas conjeturamos outras maiores e infinitas, que de modo algum existem. Com tais quimeras me alimentava eu, então, e por isso não me saciava.

 Mas tu, meu amor, em quem desfaleço para me tornar forte, nem és estes corpos que vemos, mesmo no céu; nem os outros que não vemos, porque és o Criador e os ocultaste, e não os consideras como as obras primas de tua criação.

 Oh! Quão longe estavas daquelas minhas quimeras, fantasmas de corpos que jamais existiram em comparação, são mais reais as imagens dos corpos existentes; e, mais reais ainda essas imagens, esses mesmos corpos, os quais, todavia, não são tu! Mas também não és a alma que dá vida aos corpos – mas é a vida das almas, a vida das vidas, que vives, imutável, por ti mesma; a vida de minha alma.

 Mas onde estavas então para mim? e quão longe peregrinava eu, longe de ti, privado até as bolotas com que eu alimentava os porcos! Quão melhores eram as fábulas dos gramáticos e poetas que todos aqueles enganos! Porque os versos, a poesia e a fábula de Medeia soando pelo ar são certamente mais úteis que os cinco elementos do mundo em seus mil disfarces, conforme os cinco antros de trevas, que não existem, mas que matam a quem nele acredita. Porém, versos e poesia eu os posso converter em iguaria para meu espírito e, quanto ao vôo de Medeia, se o recitava bem, não lhe afirmava veracidade e, se me agradava ouvi-lo, não lhe dava crédito. Mas – ai de mim! – eu acreditei naqueles erros dos maniqueístas.

 Ai de mim, por que degraus fui descendo até a profundidade do abismo, exaurido e devorado pela falta de verdade quando te buscava! E tudo isso, meu Deus – a quem me confesso porque te compadeceste de mim quando ainda não te conhecia – tudo por buscar-te, não com a inteligência – com a qual quiseste que eu fosse superior aos animais – mas com os sentidos da carne. E tu estavas dentro de mim, mais profundo do que o que em mim existe de mais íntimo, e mais elevado do que o que em mim existe de mais alto.

 Assim encontrei aquela mulher insolente e sem prudência – enigma de Salomão – que, sentada em uma cadeira à porta de sua casa, diz aos que passam: Comei à vontade dos pães escondidos, e bebei da doçura da água roubada, a qual me seduziu por andar eu vagando fora de mim, sob o império da vista carnal, ruminando em meu íntimo o que meus olhos haviam devorado.

## CAPÍTULO VII

### Alguns erros dos maniqueus

 Não conhecia eu outra realidade – a verdadeira – e me sentia como que movido por um aguilhão a aceitar a opinião daqueles insensatos impostores quando me perguntavam de onde procedia o mal, se Deus estava limitado por forma corpórea, se tinha cabelos e unhas, e se deviam ser considerados justos os que tinham várias mulheres simultaneamente, e os que causavam a morte de outros ou sacrificavam animais.

 Eu, ignorando essas coisas, perturbava-me com essas perguntas. Afastando-me da verdade, parecia-me encaminhar para ela, porque não sabia que o mal é apenas privação do bem, até chegar ao seu limite, o próprio nada. E como poderia ter eu tal conhecimento, se com os olhos não conseguia ver mais do que corpos, e com a alma não ia além de fantasmas?

 Tampouco sabia que Deus é espírito, que não tem membros dotados de comprimento ou largura, nem quantidade material alguma, porque a quantidade ou matéria é sempre menor na parte que no todo e, mesmo que fosse infinita, sempre seria menor em uma parte definida por um espaço determinado do que em sua infinitude, não podendo estar toda inteira em todas as partes, como o espírito, como Deus.

 Ignorava totalmente o princípio de nossa existência, que há em nós, e pelo qual a Escritura nos chama de imagem e semelhança de Deus.

 Não conhecia tampouco a verdadeira justiça interior, que não julga pelo costume, mas pela lei retíssima do Deus onipotente. Por ela se hão de formar os costumes dos países conforme os mesmos países e tempos, e sendo a mesma em todas as partes e tempos, não varia de acordo com as latitudes e as épocas; lei essa segundo a qual foram justos Abraão, Isaac, Jacó e Davi, e todos os que são louvados pela boca de Deus. Os ignorantes, julgando as coisas de acordo com a sabedoria humana, e medindo a conduta alheia pela própria, os julgam iníquos. É como se um ignorante em armaduras, não sabendo o que é próprio de cada membro, quisesse cobrir a cabeça com a couraça e os pés com o elmo, e se queixasse de que as peças não se lhe adaptem convenientemente. Ou como se alguém se queixasse de que, em determinado dia considerado feriado do meio-dia em diante, não lhe permitissem vender a mercadoria à tarde, como acontecera pela manhã; ou porque vê que na mesma casa permite-se a um escravo qualquer tocar no que não é permitido ao copeiro; ou porque não se permite fazer diante dos comensais o que se faz atrás de uma estrebaria; ou, finalmente, se indignasse porque, sendo uma a casa e uma a família, não se atribuíssem a todos as mesmas coisas.

 Tais são os que se indignam quando ouvem dizer que em outros tempos se permitiam aos justos coisas que não se lhe permitem agora, e que Deus mandou àqueles uma coisa e a estes outra, conforme os tempos, servindo uns e outros à mesma norma de santidade. E, contudo, é bem visível que no mesmo homem, no mesmo dia e na mesma hora e na mesma casa, o que convém a um membro não convém a outro; e aquilo que há pouco era licito, já não o é mais; e que o que se concede em uma parte, é justamente proibido e castigado em outra.

 Diremos, por isso, que a justiça é vária e inconstante? O que acontece é que os tempos a que ela preside não caminham no mesmo passo, porque são tempos. Mas os homens, cuja vida terrestre é breve, por não saberem harmonizar as causas dos tempos idos, e das gentes que não viram nem conheceram, com as que agora vêem e experimentam e, como também vêem facilmente o que no mesmo corpo, na mesma hora e lugar convém a cada membro, a cada tempo, a cada parte e a cada pessoa, escandalizam-se com as coisas daqueles tempos, enquanto aceitam as de agora.

 Ignorava eu então estas coisas e não as refletia e, embora de todos os lados me ferissem os olhos, eu não as via. Quando declamava algum poema, não me era lícito por um pé em qualquer outra parte do verso, senão em uma espécie de metro uns e em outra outros, e em um mesmo verso não podia meter em todas as partes o mesmo pé; e a própria arte da prosódia, apesar de mandar coisas tão distintas, não era diversa em cada parte, senão uma só e coerente. Contudo, não via como a justiça, à qual serviram aqueles varões bons e santos, pudesse conter simultaneamente, de modo mais belo e sublime, preceitos tão diversos, sem variar em sua essência, apesar de não mandar ou distribuir aos diferentes tempos todas as coisas simultaneamente, mas a cada um as que lhe são próprias. E, cego, censurava àqueles piedosos patriarcas, que não só usavam do presente como Deus lhes mandava e inspirava, mas também prediziam o futuro conforme Deus lhes revelava.

## CAPÍTULO VIII

### Moral e costume

 Acaso será em alguma parte e momento injusto amar a Deus de todo o coração, com toda a alma e com todo o entendimento, e amar ao próximo como a nós mesmos? Por isso, todos os pecados contra a natureza, como o foram os do sodomitas, hão de ser detestados e castigados sempre e em toda a parte, pois, mesmo que todos os cometessem, não seriam menos réus de crime diante da lei divina, que não fez os homens para usar tão torpemente de si; de fato viola-se a união que deve existir com Deus quando a natureza, da qual ele é autor, se mancha com a depravação das paixões.

 Com relação aos pecados que são contra os costumes humanos, também hão de ser evitados de acordo com a diversidade dos costumes, a fim de que o pacto mútuo entre os povos e nações, firmado pelo costume ou pela lei, não seja quebrado por nenhum capricho de cidadão ou forasteiro, porque é indecorosa a parte que não se acomoda ao todo.

 Todavia, quando Deus ordena algo contra tais costumes ou pactos, sejam quais forem, deve ser obedecido, embora o que mande nunca tenha sido feito; e se não foi cumprido, deve ser restaurado, e se não estava estabelecido, deve-se estabelecer. Se é lícito a um rei mandar na cidade que governa coisas que ninguém antes dele e nem ele próprio havia mandado, e se não é contra o bem da sociedade obedecê-lo, antes o seria o não obedecê-lo – por ser pacto básico de toda sociedade humana obedecer a seus reis – quanto mais deveria ser Deus obedecido sem titubeios em tudo que mandar, como rei do universo? Porque, assim como entre os poderes humanos o maior poder se antepõe ao menor, para que este lhe preste obediência, assim Deus antepõe-se a todos.

 O mesmo se deve dizer dos crimes perpetrados com desejo de causar o mal, quer por agressão, quer por injúria; e ambas as coisas, ou por desejo de vingança, como ocorre entre inimigos, ou por alcançar algum bem sem trabalhar, como o ladrão que rouba ao viajante; ou para evitar algum mal, como acontece com o que teme; ou por inveja, como quando um miserável quer mal ao que é mais feliz, ou ao que conseguiu riquezas, temendo ser igualado ou que já lhe sejam iguais; ou unicamente pelo prazer de ver o mal alheio, como acontece com o espectador dos combates dos gladiadores, ou com o que se ri e zomba dos outros.

 Tais são os princípios ou fontes de iniqüidade, que nascem da paixão de mandar, de ver ou de sentir, quer de uma só dessas paixões, ou de duas, ou de todas juntas. Razão por que se vive do mal, ó Deus altíssimo e dulcíssimo, contra o saltério de dez cordas, teu decálogo.

 Mas, que pecado pode atingir a ti, que não és atingido pela corrupção? Ou que crimes podem ser cometidos contra ti, a quem ninguém pode causar dano? O que vingas são os crimes que os homens cometem contra si, porque, mesmo quando pecam contra ti, agem impiamente contra suas próprias almas, e sua iniqüidade engana-se a si própria, quer corrompendo e pervertendo sua natureza – feita e ordenada por ti – quer usando imoderadamente das coisas permitidas, ou até desejando imoderadamente as não permitidas, pelo uso daquilo que é contra a natureza.

 Pecam também os que com o pensamento e a palavra se revoltam contra ti, dando coices contra o aguilhão; ou quando, uma vez quebrados os limites da sociedade humana, alegram-se audaciosamente com as facções ou desuniões, de acordo com as suas simpatias ou antipatias. E tudo isso o homem faz quando és abandonado, fonte da vida, único e verdadeiro criador e senhor do universo, e com orgulho egoísta ama-se uma parte do todo como se fosse o todo.

 Essa a razão pela qual só se pode voltar para ti com piedade humilde, para assim nos purificares nossos maus costumes; pela piedade te mostras propício com os pecados dos que te confessam, e ouves os gemidos dos cativos, e nos livras dos grilhões que nós mesmo forjamos, contanto que não ergamos contra ti os chifres de uma falsa liberdade, quer arrastados pela cobiça de mais haveres, quer pelo temos de perder tudo, preferindo nosso próprio egoísmo a ti, Bem de todos.

## CAPÍTULO IX

### Pecados e imperfeições

 Mas, entre tantas maldades, crimes e iniqüidades, estão os pecados dos que progridem, pecados que os homens de bom juízo vituperam, segundo a regra da perfeição, e louvam pela esperança de frutos futuros, como o verde é promissor das colheitas.

 Há outras ações semelhantes a ações maldosas ou a delitos, e que não são pecados, porque nem te ofendem a ti, Senhor, nosso Deus, nem tampouco à sociedade humana; como por exemplo quando procuramos coisas convenientes para o uso da vida e às circunstâncias, sem que se saiba se essa busca é cobiça, ou quando castigamos a alguém como desejo de que se corrija, fazendo uso do poder ordinário, e não se sabe se o fazemos por vontade de mortificar.

 Por isso, muitas ações que parecem condenáveis aos homens, são aprovadas por teu testemunho; e muitas, louvadas pelos homens, são condenadas por teu testemunho, porque muitas vezes as aparências do ato diferem das intenções do seu autor, assim como circunstâncias ocultas do tempo.

 Mas quando ordenas, algo insólito e imprevisto, mesmo que o tenhas proibido uma vez, mesmo que escondas por algum as razões do teu mandamento, mesmo que seja contra as convenções de alguns homens da sociedade, quem pode duvidar de que se há de obedecer, sendo que só é justa a sociedade humana que te obedece? Felizes dos que sabem o que tu ordenaste, porque os que te servem fazem tudo o que mandas, ou porque assim o exige o tempo presente, ou para preparar o futuro.

## CAPÍTULO X

### Ridicularias dos maniqueus

 Desconhecendo eu essas verdades, ria-me de teus santos e profetas. Mas, que fazia eu quando me ria deles, senão dar motivo para que te risses de mim? deixei-me cair insensivelmente, aos poucos, em tais extravagâncias, a ponto de acreditar que o figo, quando colhido, chora lágrimas de leite junto com a mãe figueira, e que se um "santo" da seita comesse o tal figo, colhido não por seu delito, mas de outrem, misturando-o em suas entranhas, gemendo e arrotando enquanto rezava, exalaria anjos e até mesmo partículas de Deus, partículas essas do verdadeiro Deus que ficariam cativas para sempre naquele fruto se não fossem libertadas pelos dentes e pelo estômago do "santo eleito"!

 Também acreditei, pobre de mim, que se devia ter mais misericórdia com os frutos da terra que com os homens para os quais foram criados. Pois, se algum faminto, que não fosse maniqueísta me pedisse de comer, parecia-me que atendê-lo era como merecer, por aquele bocado, a pena de morte.

## CAPÍTULO XI

### O sonho de Mônica

 Mas estendeste tua mão do alto, e arrancaste minha alma deste abismo de trevas, enquanto minha mãe, tua fiel serva, chorava-me diante de ti muito mais do que as outras mães costumam chorar sobre o cadáver dos filhos, pois via a morte de minha alma com a fé e o espírito que havia recebido de ti. E tu a escutaste, Senhor, tu a ouviste e não desprezaste suas lágrimas que, brotando copiosas, regavam o solo debaixo de seus olhos por onde fazia sua oração; sim, tu a escutaste, Senhor. Com efeito, donde podia vir aquele sonho, com que a consolaste, ao ponto de me admitir em sua companhia e mesa, fato que havia me negado porque aborrecia e detestava as blasfêmias do meu erro?

 Nesse sonho viu-se de pé sobre uma régua de madeira; e um jovem resplandecente, alegre e risonho que vinha ao seu encontro, triste e amarga. Este lhe perguntou a causa de sua tristeza e lágrimas diárias, não por curiosidade, como sói acontecer, mas para instruí-la; e respondendo-lhe ela que chorava a minha perdição, mandou-lhe, para sua tranqüilidade, que prestasse atenção e visse por onde ela estava também estaria eu. Apenas olhou, viu-me junto de si, de pé sobre a mesma régua.

 De onde veio este sonho, senão dos ouvidos que tinhas atentos a seu coração, ó Deus bom e onipotente, que cuidas de cada um de nós como se não tivesses outro para cuidar, zelando de todos como de cada um!

 E como explicar o que se segue? Contou-me minha mãe esta visão, e querendo-a eu persuadir de que significava o contrário, e que não devia desesperar de ser algum dia o que eu era, isto é, maniqueísta, ela, sem nenhuma hesitação, me respondeu: "Não; não me foi dito: onde ele está ali estarás tu, mas onde tu estás ali estará ele também".

 Confesso, Senhor, e muitas vezes disse que, pelo que me recordo, me abalou mais esta tua resposta pela solicitude de minha mãe, imperturbável diante de explicação falsa e ardilosa, e por ter visto o que se devia ver – e que eu certamente não veria sem que ela o dissesse – que o mesmo sonho com o qual anunciaste a esta piedosa mulher com tanta antecedência, a fim de consolá-la em sua aflição presente, uma alegria que só havia de se realizar muito tempo depois.

 Seguiram-se, efetivamente, quase nove anos, durante os quais continuei a me revolver naquele abismo de lodo e trevas de erro, afundando-me tanto mais quanto mais esforços fazia para me libertar. Entretanto, aquela piedosa viúva, casta e sóbria como as que tu amas, já um pouco mais alegre com a esperança, porém, não menos solícita em suas lágrimas e gemidos, não cessava de chorar por mim em tua presença em todas as horas de suas orações; e suas preces eram aceitas a teus olhos, mas deixava-me ainda revolver-me e envolver-me naquela escuridão.

## CAPÍTULO XII

### Uma profecia

 Nessa mesma ocasião deste à minha mãe outra resposta, de que ainda me lembro – pois passo em silencio muitas circunstâncias, pela pressa que tenho de chegar àquelas que te devo confessar com mais urgência, ou porque não as recordo – deste-lhe outra resposta por meio de um teu bispo, educado em tua Igreja e exercitado em tuas Escrituras. Como ela pedisse que se dignasse falar comigo, para refutar meus erros e desenganar-me de minhas más doutrinas e ensinar-me as boas – pois assim fazia com quantos julgava idôneos – ele negou-se com muita prudência, como pude verificar depois; respondeu-lhe que eu estava incapacitado para receber qualquer ensinamento, por estar enfatuado com a novidade da heresia maniqueísta, e por haver criado embaraço a muitos ignorantes com algumas questões fáceis, como ela mesma lhe relatara. "Deixe-o – disse – e unicamente ore por ele ao Senhor! Ele mesmo, lendo os livros dos hereges, descobrirá o erro e reconhecerá sua grande impiedade". – Ao mesmo tempo contou-lhe que, quando criança, sua mãe, seduzida pelo erro, entregara-o aos maniqueus, chegando não só a ler, mas a copiar quase todas as suas obras; e que ele mesmo, sem necessidade de que ninguém o contestasse ou convencesse, chegara a perceber a falácia daquela doutrina, abandonando-a enfim.

 Depois de assim falar, minha mãe não se aquietava, instando com maiores rogos e mais copiosas lágrimas a que me visitasse, para discutir comigo sobre o tal assunto. O bispo, já com certo enfado de sua insistência, lhe disse: "Vai-te em paz, mulher, e continua a viver assim, que não é possível que pereça o filho de tantas lágrimas" – palavras que ela recebeu como vindas do céu, segundo me recordava muitas vezes em seus colóquios comigo.