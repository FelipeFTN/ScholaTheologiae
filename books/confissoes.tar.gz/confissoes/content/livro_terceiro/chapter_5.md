## CAPÍTULO V

### A desilusão das escrituras

 Em vista disso, decidi dedicar-me ao estudo da Sagrada Escritura, para a conhecer. Vi ali algo encoberto para os soberbos e obscuro para as crianças, mas humilde a princípio e sublime à medida que se avança o velado de mistérios; e eu não estava disposto a poder entrar nela, dobrando a cerviz à sua passagem. Contudo, ao fixar nela a atenção, não pensei o que agora estou dizendo, mas simplesmente me pareceu indigna de ser comparada com a majestade dos escritos de Cícero. Meu orgulho recusava sua simplicidade, e minha mente não lhe penetrava o íntimo. Contudo, a agudeza desta visão haveria de crescer com os pequenos; mas eu de nenhum modo queria ser criança e, enfatuado de soberba, considerava-me grande.