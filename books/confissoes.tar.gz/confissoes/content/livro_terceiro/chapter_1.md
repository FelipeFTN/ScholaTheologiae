## CAPÍTULO I

### O gosto do amor

 Cheguei a Cartago, e por toda parte fervilhava a sertã de amores impuros. Ainda não amava, mas já gostava de amar; secretamente sedento, aborrecia a mim próprio por não me sentir mais indigente de amor. Gostando do amor buscava o que amar, e odiava a segurança e os meus caminhos sem perigos, porque tinha dentro de mim fonte de alimento interior, de ti mesmo, ó meu Deus. Eu não sentia essa fonte como tal; antes, estava sem apetite algum dos manjares incorruptíveis, não porque estivesse saciado deles, mas porque, quanto mais vazio, tanto mais enfastiado me sentia.

 E por isso minha alma não estava bem e, ferida, voltava-se para fora de si, ávida de se roçar miseravelmente às coisas sensíveis; se porém não tivessem alma, não seriam certamente amadas.

 Amar e ser amado era para mim a coisa mais doce, sobretudo se podia gozar do corpo da criatura amada. Deste modo manchava com torpe concupiscência a fonte da amizade, e obscurecia seu candor com os vapores infernais da luxúria. E apesar de tão torpe e impuro, desejava com afã e cheio de vaidade, passar por afável e cortês.

 Caí por fim no amor, em que desejava ser colhido. Porém, ó meu Deus, misericórdia minha, quanto fel não misturaste àquela suavidade, e quão bom foste ao fazê-lo! Fui amado, e cheguei secretamente aos laços do prazer, e me deixei alegremente enredar com trabalhosos laços, para ser logo açoitado com as varas de ferro ardente do ciúme, das suspeitas, dos temores, das iras e das contendas.