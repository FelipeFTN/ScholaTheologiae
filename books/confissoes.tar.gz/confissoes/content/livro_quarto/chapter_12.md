## CAPÍTULO XII

### O amor em Deus

 Se te agradam os corpos, louva a Deus neles, e dirige teu amor para teu artífice, para não o desagradar nas mesmas coisas que te agradam.

 Se te agradam as almas, ama-as em Deus, porque, embora mutáveis, se fixas nele, terão estabilidade; de outro modo, passariam e pereceriam. Ama-as, pois, nele, e arrasta contigo até ele quantas almas puderes, dizendo-lhes: "Amemo-lo". Porque ele criou estas coisas, e não está longe; ele não as fez para depois ir embora, mas dele procedem e nele estão. E ele está onde aprecia a verdade: no mais íntimo do coração; mas o coração errante se afastou dele.

 Voltai, pecadores, ao coração, e ligai-vos àquele que é vosso criador. Firmai-vos nele, e estareis firmes; descansai nele, e estareis descansados. Para onde ides por esses ásperos caminhos? Para onde ides? O bem que amais, dele procede, mas só é bom e suave quando se dirige a ele; porém, será justamente amargo se, abandonando a Deus, amardes injustamente o que dele procede. Por que continuai por caminhos difíceis e trabalhosos? O descanso não está onde o buscais. Buscais a vida feliz na região das trevas: não está lá. Como achar a vida bemaventurada onde nem sequer há vida?

 Ele, nossa vida real veio até nós; sofreu nossa morte, e a suplantou com a abundância de sua vida; com voz de trovão clamou para que voltássemos a ele, para o lugar escondido de onde veio até nós, passando primeiro pelo seio de uma virgem, onde se desposou com ele a natureza humana, carne mortal, para não ficar sempre mortal.

 Dali, como o esposo que sai do tálamo, deu saltos como um gigante, para correr seu caminho. E não se deteve; correu clamando com suas palavras, com suas obras, com sua própria morte, com sua vida, com sua descida aos ínferos e com sua ascensão, clamando para que voltássemos a ele. Se ele se afastou de nossa vista, foi para que entremos em nosso coração, e ali o encontremos; se partiu, ainda está conosco. Não quis ficar por muito tempo entre nós, mas não nos abandonou. Retirou-se de onde nunca se afastou, pois o mundo foi criado por ele, e no mundo estava, e ao mundo veio para salvar os pecadores. E a ele se confessa minha alma, a ele que a cura e contra quem pecou.

 Filhos dos homens, até quando sereis duros de coração? Será possível que, depois de ter a vida descido até vós, não queirais subir e viver? Mas para onde subis, quando vos ergueis e abris vossa boca no céu? Descei para subir, para subir até Deus, já que caístes levantando-vos contra Deus.

 Dize-lhes isto, minha alma, para que chorem neste vale de lágrimas, e assim os arrebates contigo para Deus, pois, ao dizer estas palavras ardendo em chamas de caridade, é o espírito divino que te inspira.