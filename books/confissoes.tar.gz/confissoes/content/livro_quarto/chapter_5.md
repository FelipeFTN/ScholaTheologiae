## CAPÍTULO V

### O conforto das lágrimas

 E agora, Senhor, que essas coisas já passaram, agora que o tempo sarou minha ferida, poderei ouvir de ti, que és a própria verdade, aproximando o ouvido de meu coração de tua boca, o motivo por que o pranto é doce aos desgraçados? Acaso, mesmo presente em toda parte, repeliste para longe de ti nossa miséria, permanecendo imutável em ti, enquanto deixas que nos envolvamos em nossas provações? E, contudo, se nossos lamentos não chegarem a teus ouvidos, não haverá para nós esperança alguma.

 Mas, por que motivo dos gemidos, do choro, dos suspiros e das queixas colhe-se como fruto doce do amargor da vida? Esperamos que nos ouça? Virá daí a doçura? Isso acontece na oração que leva em si o desejo de chegar a ti; porém, poder-se-á dizer o mesmo da dor da perda ou do pranto que então me avassalavam?

 Eu não esperava ressuscitar meu amigo com minhas lágrimas, mas limitava-me a me condoer e a chorar minha miséria, pois eu havia perdido minha alegria.

 Ou será que o pranto, que é amargo em si mesmo, se torna um deleite quando, pelo fastio, aborrecemos os prazeres que antes nos eram gratos?