## CAPÍTULO VII

### De Tagaste para Cartago

 Ó loucura, que não sabe amar os homens humanamente! Ó homem insensato, que sofre desmedidamente os reveses humanos! Assim era eu então, e assim agitava-me, suspirava, chorava, perturbava-me, e não encontrava descanso nem conselho. Trazia a alma em farrapos e ensangüentada, indócil ao meu governo, e eu não encontrava lugar onde a pudesse depor. Nem os bosques amenos, nem os jogos e cantos, nem os lugares suavemente perfumados, nem os banquetes suntuosos, nem os prazeres da alcova e do leito, nem, finalmente, os livros e os versos podiam dar-lhe descanso. Tudo me causava horror, até a própria luz. Tudo o que não era o que ele era, era-me insuportável e odioso, exceto gemer e chorar, pois, somente nisto achava algum repouso. E se minha alma deixava de chorar, logo pesava sobre mim o grande fardo da desgraça.

 A ti, Senhor, deveria ser elevada, para ter cura. Eu o sabia, mas não o queria nem podia. Tanto mais que, ao pensar em ti, não tinha em mente algo sólido e firme, mas um fantasma, o meu erro. Se nele tentava descansar minha alma, logo deslizava como quem pisa em falso, e caía de novo sobre mim. Eu era para mim mesmo uma infeliz morada, na qual era ruim e da qual não podia sair. E para onde iria meu coração, fugindo de si mesmo? Para onde fugir de mim mesmo? Para onde não me seguiria?

 Por isso fugi de minha pátria, porque meus olhos buscariam menos meu amigo onde não estavam acostumados a vê-lo. E assim me fui de Tagaste para Cartago.