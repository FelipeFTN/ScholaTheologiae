## CAPÍTULO XIII

### O problema do belo

 Então eu ignorava tais coisas – e por isso amava belezas terrenas. Caminhava para o abismo, dizendo a meus amigos: "Será que amamos algo que não é belo? E que é o belo? E que é a beleza? Que é que nos atrai e apega às coisas que amamos? Pois, com certeza, se nelas não houvesse certa graça e formosura, não nos atrairiam.

 E eu observava e via que num mesmo corpo uma coisa era o todo, harmonioso e belo, e outra o que lhe era conveniente, sal aptidão de se ajustar de maneira perfeita a alguma coisa como, por exemplo, a parte do corpo em relação ao conjunto, o calçado em relação ao pé, e outras similares. Esta consideração brotou em minha alma do íntimo de meu coração, e escrevi alguns livros sobre o belo e o conveniente, creio que dois ou três – tu o sabes, Senhor – pois já me esqueci, e não os tenho mais porque se me extraviaram não sei como.