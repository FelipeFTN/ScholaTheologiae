# LIVRO QUARTO

## CAPÍTULO I

### Dos dezenove aos vinte e oito anos

 Durante esse período de nove anos – dos dezenove até os vinte e oito anos – fui seduzido e sedutor, enganado e enganador, conforme minhas muitas paixões; publicamente, com aquelas doutrinas que se chamam liberais; ocultamente, com o falso nome de religião, mostrando-me aqui soberbo, ali supersticioso, e em toda parte vaidoso. Ora perseguindo a aura da gloria popular até os aplausos do teatro, os certames poéticos, os torneios de coroas de feno, as bagatelas de espetáculos e a intemperança da luxúria; ora, desejando muito purificar-me dessas imundícies, levando alimento aos chamados "eleitos" e "santos", para que na oficina de seu estômago fabricasse anjos e deuses que me libertassem. Tais coisas seguia eu e praticava com meus amigos, iludidos comigo e por mim.

 Riam-se de mim os arrogantes, e os que ainda não foram prostrados e salutarmente esmagados por ti, meu Deus; mas eu, pelo contrário, hei de confessar diante de ti minhas torpezas para teu louvor. Permite-me, te suplico, e concede-me que me lembre fielmente dos desvios passados de meu erro, e que eu te sacrifique uma vítima de louvor.

 De fato, sem ti, que sou eu para mim mesmo senão um guia que conduz ao abismo? Ou que sou eu, quando tudo me corre bem, senão uma criança que suga o leite, e que se alimenta de ti, alimento incorruptível? E que é o homem, seja ele quem for, se é homem?

 Riam-se de nós os fortes e poderosos, que nós, débeis e pobres, confessaremos teu santo nome.

## CAPÍTULO II

### Professor de retórica

 Naqueles anos eu ensinava retórica e, movido pela cobiça, vendia a arte de vencer pela loquacidade. Contudo, bem sabes, Senhor, que preferia ter bons discípulos, dos que se chamam "bons", aos quais ensinava sem rodeios a arte de enganar, não para que usassem dela contra a vida de um inocente, mas para algum dia defender algum culpado. Mas, ó Deus, tu me viste de longe vacilar sobre um caminho escorregadio, viste brilhar, entre espesso fumo, os fulgores da boa fé que eu demonstrava ao ensinar àqueles amantes da vaidade, àqueles pesquisadores de mentiras, eu, seu irmão e semelhante.

 Por essa mesma época tive em minha companhia uma mulher, não reconhecida pelo chamado matrimônio legítimo, mas procurada pelo inquieto ardor de minha paixão imprudente; mas era só uma, e eu lhe era fiel. E assim experimentei pessoalmente a distância que há entre o amor conjugal contraído com o fim de ter filhos, e o amor lascivo, no qual a prole também nasce, mas contra o desejo dos pais, embora, uma vez nascida, os obrigue a amá-la.

 Lembro-me também de que, querendo participar de um certame de poesia, um arúspide mandou-me indagar que dádiva lhe daria para eu sair vencedor. Mas eu, que abominava aqueles nefandos sortilégios, respondi-lhe que não consentiria que se matasse uma mosca para obter a vitória, mesmo que o prêmio fosse uma coroa de ouro incorruptível; sabia eu que ele teria de matar animais em seus sacrifícios, julgando com tais honras assegurar para mim os votos do demônio.

 Mas, confesso, Deus de meu coração, que se repudiei tal crime, não o fiz por amor da tua pureza. Pois ainda não sabia te amar, eu, que sabia conceder apenas esplendores corpóreos. Não é pois verdade que a alma que suspira por semelhantes fábulas não se aniquila longe de ti, e se apóia na falsidade, e se apascenta de vento? Mas eis que, não querendo que se oferecessem sacrifícios aos demônios, eu mesmo me sacrificava a eles com aquela superstição. Com efeito, que significa apascentar ventos, senão apascentar os espíritos diabólicos, isto é, tornarmo-nos, por nossos erros, objeto de seu riso e escárnio?

## CAPÍTULO III

### A atração da astrologia

 Por isso, não cessava de consultar os impostores chamados matemáticos, já que estes não usavam em suas adivinhações de quase nenhum sacrifício, nem dirigiam preces a nenhum espírito o que, consequentemente, é condenado e repelido com razão pela piedade cristã e verdadeira. Porque o bom é confessar-te, Senhor, e dizer-te: Tem misericórdia de mim, e cura minha alma, porque pecou contra ti, e não abusar da tua indulgência para pecar mais livremente, mas ter sempre presente a sentença do Senhor: Eis-te curado: não peques mais, para que te não suceda algo pior – Estas palavras, cujo efeito salutar os astrólogos querem destruir, dizendo: "O impulso de pecar vem dos céus; foi Vênus, Saturno ou Marte que fizeram isto" – e tudo para que o homem, que é carne, e sangue, e soberba podridão, se sinta sem culpa, e atribua esta ao criador e ordenador do céu e das estrelas. E quem é este, senão tu, nosso Deus, suavidade e fonte de justiça, que dás a cada um de acordo com suas obras, e não desprezas ao coração contrito e humilhado?

 Havia então um varão muito sábio, peritíssimo na arte médica, na qual era celebre; sendo procônsul, pôs com suas próprias mãos sobre minha cabeça insana a coroa da vitória do concurso; foi como procônsul, e não como médico, porque daquela minha enfermidade só tu me podias sarar, pois resistes aos soberbos e dás tua graça aos humildes.

 Contudo, deixaste acaso de cuidar de mim também por meio daquele ancião? Ou talvez desistisse de curar minha alma? Tendo-me familiarizado muito com ele, passei a ser assistente assíduo e freqüente de suas conversas, que eram agradáveis e graves, não pela elegância da linguagem, mas pela vivacidade das sentenças. Assim que ficou sabendo, por conversa, que eu me dedicava à leitura dos livros dos astrólogos, admoestou-me benigna e paternalmente a que os deixasse, e a que não gastasse inutilmente nessas quimeras meus cuidados e trabalho, que melhor empregaria em coisas úteis. Acrescentou que também ele havia cultivado aquela arte, a ponto de querer adotá-la, em sua juventude, como profissão para ganhar a vida, pois, se havia entendido Hipócrates, podia também entender aqueles livros; por fim, deixara aqueles estudos pelos da medicina, por causa da sua falsidade, não querendo, como homem sério, ganhar o pão enganando os outros. "Mas tu, disse-me ele – que tens para manter entre os homens tuas aulas de retórica, segues essas mentiras não por necessidade, mas por mera curiosidade; mais um motivo para que acredites no que te digo, pois cuidei de aprendê-la tão perfeitamente que quis viver apenas de seu exercício".

 Indaguei-lhe então por que muitas das coisas prognosticadas pela tal ciência se revelavam verdadeiras, respondeu-me, como pôde, que a força do acaso está espalhada por toda a natureza. "Se alguém – dizia ele – consultando as vezes as páginas de um poeta qualquer, encontra um verso que, apesar do poeta pensar em coisas muito diversas quando o compôs, adapta-se admiravelmente ao assunto que o preocupa; assim pois nada tem de estranho que a alma humana, movida por instinto superior, inconsciente do que se passa no seu íntimo, diga, não por arte, mas por sorte, algo que corresponda aos atos e gestos do consulente".

 E isto, Senhor, me ensinou ele, ou melhor, me ensinaste por teu intermédio, e delineaste em minha memória o que eu mesmo mais tarde devia procurar. Mas então, nem ele, nem meu caríssimo Nebrídio, jovem muito bom e casto, que zombava de toda aquela arte divinatória, puderam me convencer a abandoná-la, porque ainda impressionava-me mais a autoridade daqueles autores. Não tinha eu encontrado ainda o argumento evidente que procurava, que me demonstrasse sem ambigüidade que os presságios acertados dos astrólogos são obra da sorte ou casualidade, e não da arte de observar os astros.

## CAPÍTULO IV

### A morte do amigo

 Por aqueles anos, quando comecei a ensinar em minha cidade natal, conheci um amigo, a quem amei em demasia por ser meu companheiro de estudos, de minha idade, e por estarmos ambos na flor da juventude. Juntos fomos criados quando crianças, juntos íamos à escola, juntos havíamos brincado. Mas nessa época não era amigo tão íntimo como o foi depois, embora também não o fosse tanto quanto o exige a verdadeira amizade, uma vez que esta só existe entre os que unes por meio da caridade, derramada em nossos corações pelo Espírito Santo que nos foi dado.

 Contudo, aquela amizade, aquecida ao calor de estudos semelhantes era-me sumamente grata. Consegui até afastá-lo da verdadeira fé, pouco profunda e arraigada em sua adolescência, arrastando-o para as fábulas supersticiosas e prejudiciais, razão das lágrimas de minha mãe. Esse homem já errava em espírito comigo, e minha alma não podia viver sem ele.

 Mas eis que, seguindo de perto no encalço de teus servos fugitivos, ó Deus das vinganças, que és a um tempo fonte de misericórdia, e nos converte a ti por estranhos caminhos, eis que tu o arrebataste desta vida, quando eu apenas havia gozado um ano de sua amizade, mais doce para mim que todas as doçuras da minha vida.

 Quem poderá enumerar teus louvores, mesmo limitando-se ao que experimentou em si mesmo? Que fizeste então, meu Deus! E quão impenetrável é o abismo de teus juízos! Lutando meu amigo contra a febre, ficou por muito tempo sem sentidos, banhado no suor da morte; e, como temessem por sua vida, batizaram-no sem que ele o soubesse, com o que não me importei, convencido que estava de que seu espírito reteria melhor aquilo que eu lhe havia inculcado do que o sinal que recebera sobre o corpo inconsciente.

 A realidade, contudo, foi muito outra. Melhorando, e estando fora de perigo, logo que lhe pude falar – e o fiz logo que ele o pôde, e como dependíamos mutuamente um do outro eu não me afastava do seu lado – tentei rir-me em sua presença do batismo, julgando que também ele zombaria comigo de um batismo recebido sem conhecimento nem sentidos, mas ele já sabia que o havia recebido. Olhando-me então com horror, como a um inimigo, admoestou-me com admirável e repentina franqueza, dizendo-me que se queria continuar a ser seu amigo deixasse de tais palavras. Admirado e perturbado, reprimi toda minha emoção, esperando que convalescesse primeiro, para, recobradas as forças, estar disposto a discutir comigo o que quisesse. Mas tu, Senhor, livraste-o de minha louca amizade, guardando-o em ti para o meu consolo, pois, poucos dias depois, na minha ausência, voltaram-lhe as febres e morreu.

 Que dor fez anoitecer o meu coração! Tudo o que via era morte para mim. a pátria me era um suplício, e a casa paterna tormento insuportável, e tudo o que o lembrava transformava-se para mim em crudelíssimo martírio. Buscavam-no por toda parte meus olhos, e o mundo não mo devolvia. Cheguei a odiar todas as coisas, porque nada o continha, e ninguém mais me podia dizer como antes, quando chegava depois de alguma ausência: "Ali vem ele". Transformara-me mesmo num grande problema. Perguntava à minha alma porque andava triste, e se perturbava tanto, e ela não sabia o que responder-me. E se eu lhe dizia: "Espera em Deus" – minha alma não me obedecia, e com razão, porque para mim, era mais real e melhor o amigo querido que perdera, que o fantasma em que mandava tivesse esperança. Só o pranto me era doce. Ocupava o lugar de meu amigo nas delicias de meu coração.

## CAPÍTULO V

### O conforto das lágrimas

 E agora, Senhor, que essas coisas já passaram, agora que o tempo sarou minha ferida, poderei ouvir de ti, que és a própria verdade, aproximando o ouvido de meu coração de tua boca, o motivo por que o pranto é doce aos desgraçados? Acaso, mesmo presente em toda parte, repeliste para longe de ti nossa miséria, permanecendo imutável em ti, enquanto deixas que nos envolvamos em nossas provações? E, contudo, se nossos lamentos não chegarem a teus ouvidos, não haverá para nós esperança alguma.

 Mas, por que motivo dos gemidos, do choro, dos suspiros e das queixas colhe-se como fruto doce do amargor da vida? Esperamos que nos ouça? Virá daí a doçura? Isso acontece na oração que leva em si o desejo de chegar a ti; porém, poder-se-á dizer o mesmo da dor da perda ou do pranto que então me avassalavam?

 Eu não esperava ressuscitar meu amigo com minhas lágrimas, mas limitava-me a me condoer e a chorar minha miséria, pois eu havia perdido minha alegria.

 Ou será que o pranto, que é amargo em si mesmo, se torna um deleite quando, pelo fastio, aborrecemos os prazeres que antes nos eram gratos?

## CAPÍTULO VI

### Inconsolável

 Mas para que falar dessas coisas, se agora não é tempo de investigar, mas de me confessar a ti? Eu era miserável, como o é toda alma prisioneira do amor pelas coisas temporais; se sente despedaçar quando as perde, sentindo então sua miséria, que a torna miserável antes mesmo de as perder. Assim é como eu era então e, chorando muito amargamente, descansava na amargura. E como era miserável! Contudo, mais que o amigo caríssimo, eu amava minha vida miserável, porque embora desejasse mudá-la, não queria perdê-la como ao amigo, não sei se gostaria de perdê-la por ele, como se conta de Orestes e Pílades – se não é ficção – que queriam morrer um pelo outro, porque para eles viver separados era pior que a morte. Mas não sei que novo sentimento nascera em mim, muito contrário a este: sentia pesado tédio de viver, e ao mesmo tempo tinha medo de morrer. Creio que quanto mais amava o amigo tanto mais odiava e temia a morte, como inimigo feroz que mo havia arrebatado; pensava que ela acabaria de repente com todos os homens, como o fizera com ele. Este era meu estado de espírito, pelo que me lembro.

 Meu Deus, eis aqui meu coração, ei seu conteúdo! Olha para o meu passado, porque sei, esperança minha, que me purificas da impureza desses afetos, atraindo para ti meus olhos, e libertando meus pés dos laços que me aprisionavam. Maravilhava-me de que sobrevivessem os outros mortais a seus amados se nunca houvessem de morrer; e mais me maravilhava ainda de que, morto ele, eu continuasse a viver, porque eu era outro ele. Bem disse um poeta quando chamou ao amigo "metade da sua alma". E eu senti que minha alma e a sua não eram mais que uma em dois corpos, e por isso causava-me horror a vida, porque não queria viver pela metade; e ao mesmo tempo tinha muito medo de morrer, para que não morresse de todo aquele a quem eu tanto amara.

## CAPÍTULO VII

### De Tagaste para Cartago

 Ó loucura, que não sabe amar os homens humanamente! Ó homem insensato, que sofre desmedidamente os reveses humanos! Assim era eu então, e assim agitava-me, suspirava, chorava, perturbava-me, e não encontrava descanso nem conselho. Trazia a alma em farrapos e ensangüentada, indócil ao meu governo, e eu não encontrava lugar onde a pudesse depor. Nem os bosques amenos, nem os jogos e cantos, nem os lugares suavemente perfumados, nem os banquetes suntuosos, nem os prazeres da alcova e do leito, nem, finalmente, os livros e os versos podiam dar-lhe descanso. Tudo me causava horror, até a própria luz. Tudo o que não era o que ele era, era-me insuportável e odioso, exceto gemer e chorar, pois, somente nisto achava algum repouso. E se minha alma deixava de chorar, logo pesava sobre mim o grande fardo da desgraça.

 A ti, Senhor, deveria ser elevada, para ter cura. Eu o sabia, mas não o queria nem podia. Tanto mais que, ao pensar em ti, não tinha em mente algo sólido e firme, mas um fantasma, o meu erro. Se nele tentava descansar minha alma, logo deslizava como quem pisa em falso, e caía de novo sobre mim. Eu era para mim mesmo uma infeliz morada, na qual era ruim e da qual não podia sair. E para onde iria meu coração, fugindo de si mesmo? Para onde fugir de mim mesmo? Para onde não me seguiria?

 Por isso fugi de minha pátria, porque meus olhos buscariam menos meu amigo onde não estavam acostumados a vê-lo. E assim me fui de Tagaste para Cartago.

## CAPÍTULO VIII

### O consolo do tempo e da amizade

 O tempo não corre debalde, nem passa inutilmente sobre nossos sentidos; antes, causa na alma efeitos maravilhosos. Assim vinha e passava, dias após dias, e passando deixava em mim novas esperanças e novas recordações; pouco a pouco restituía-me a meus prazeres de outrora, a que ia cedendo minha dor. Substituíam-na não novas dores, mas sementes de novas dores. Mas, por que me penetrara aquela dor tão profundamente, até o mais íntimo de meu ser, senão porque derramei minha alma sobre a areia, amando a um mortal como se não o fora? O que mais me confortava e alegrava eram sobretudo as consolações de outros amigos, com os quais partilhava o amor para o que amava tem teu lugar, isto é, uma fábula enorme, uma longa mentira, cujo contato impuro corrompia nossa mente, arrastada pelo prurido de ouvir aquilo que a agradava; fábula esta que não morria para mim, ainda que morresse algum de meus amigos.

 Outros prazeres havia neles que cativavam mais fortemente minha alma, como conversar, rir, agradar-nos mutuamente com amabilidade, ler juntos livros bem escritos, gracejar uns com os outros e divertir-nos juntos; às vezes discutir, mas sem ódio, como quando discordamos de nós mesmos para, com tais discórdias muito raras, temperar as muitas conformidades; ensinar ou aprender reciprocamente muitas coisas, suspirar impacientes pelos ausentes e receber alegres os recém-chegados. Estes sinais, e outros semelhantes, que procedem de corações que se amam, e que se manifestam no rosto, na fala, nos olhos, e em mil outros gestos graciosos, inflamavam nossas almas, como em uma centelha, fazendo de muitas uma só.

## CAPÍTULO IX

### O amigo de Deus

. É isto o que se ama nos amigos; e de tal modo se ama, que a consciência humana se julga culpada se não ama ao que a ama, ou se não retribui amor com amor procurando na pessoa do amigo apenas o sinal exterior de sua benevolência. Daqui o pranto do luto quando morre um amigo, as trevas de dores, e as lágrimas que inundam o coração quando a doçura se transforma em angústia, e a morte dos que morrem na morte dos que vivem.

 Bem-aventurado o que te ama, Senhor, e ama ao amigo em ti, e ao inimigo por amor a ti; só não perde o amigo quem tem a todos por amigos naquele que nunca se perde. E quem é este, senão nosso Deus, o Deus que fez o céu e a terra, e os enche, porque, enchendo-os, os criou? Ninguém, Senhor, te perde senão o que te abandona. Mas, quem te deixa, para onde vai, ou para onde foge, senão de ti benévolo para ti irado? Onde não achará tua lei para seu castigo? Porque tua lei é a verdade, e a verdade és tu mesmo.

## CAPÍTULO X

### As mentiras da beleza

 Ó Deus das virtudes! Converte-nos e mostra-nos tua face, e seremos salvos! Porque, para onde quer que se volte a alma humana, onde quer que se estabeleça fora de ti, sempre encontrará dor, mesmo que sejam as belezas que estão fora de ti e fora de si mesma; e todavia, estas nada seriam se não existissem em ti. Elas nascem e morrem; e, nascendo, começam a existir, e crescem para alcançar a perfeição e, uma vez perfeitas, começam a envelhecer e morrem. Embora nem tudo envelheça, tudo perece. Logo, quando os seres nascem e se esforçam para existir, quanto mais depressa crescem para existir, tanto mais se apressam para deixar de existir. Esta é a sua condição. Eis tudo o que lhes deste, porque são partes de coisas que não existem simultaneamente mas, morrendo e sucedendo-se umas às outras, formam o conjunto de que são partes.

 Assim forma-se também nosso discurso, por meio dos sinais sonoros; este nunca se realizaria se uma palavra não se extinguisse, depois de pronunciadas suas sílabas, para dar lugar à seguinte.

 Que minha alma te louve por tudo isto, ó Deus, criador de todas as coisas; mas não se pegue a elas com o visco do amor dos sentidos, pois também elas caminham para o não-ser, e dilaceram a alma com desejos pestilenciais, e ela quer existir e gosta de descansar nas coisas que ama. Mas nelas não acha onde, porque as coisas não são estáveis. Elas são fugazes, e quem poderá segui-las com os sentidos da carne? Ou quem as pode alcançar, mesmo estando presentes? Lento é o sentido da carne, por ser da carne, mas essa é a sua condição. É suficiente para o que foi criado, mas não o é para reter o curso das coisas, do princípio que lhes foi fixado, até o fim que lhes foi designado, porque em teu Verbo, que as criou, ouvem estas palavras: "Daqui até ali".

## CAPÍTULO XI

### A verdade de Deus

 Não seja vã, ó minha alma, nem ensurdeças o ouvido do coração com o tumulto de tua vaidade. Ouve também : o próprio Verbo clama que voltes, porque só acharás repouso imperturbável lá onde o amor não é abandonado, se ele não nos abandona antes. Eis que as coisas passam para ceder lugar as outras, e para que assim se forme este universo inferior, de todas as suas partes. "Mas, por acaso, afasto-me de um lugar para outro? – diz o Verbo de Deus – Fixa nele tua morada, confia a ele tudo o que dele recebeste, alma minha, já cansada de tantos enganos. Confia à Verdade quanto da Verdade recebeste, e nada perderás; antes, tua podridão reflorescerá e serão curadas todas as tuas fraquezas, e serão retomadas e renovadas, estreitamente unidas a ti, tuas partes inconscientes; e já não te arrastarão para a ladeira por onde descem, mas permanecerão contigo para sempre onde está Deus, eterno e imutável.

 Por que, perversa, segues o apelo de tua carne? Seja esta, convertida a te seguir. Tudo o que por ela sentes é parte, mas ignoras o todo de que é parte, ainda que te dê prazer. Mas, se os sentidos de tua carne fossem idôneos para compreender o todo, e se, para teu castigo, não tivessem sido justamente limitados a compreender apenas partes do universo, certamente desejarias que passasse tudo o que presentemente existe, para melhor desfrutar do conjunto.

 O que falamos também ouves com os ouvidos da carne, e com certeza não queres que as sílabas se detenham, mas que voem, para que outras lhes sucedam, e assim ouvires o conjunto. O mesmo acontece com todas as coisas que compõem um todo, quando essas partes constituintes não existem simultaneamente; há mais encanto no todo do que nas partes percebidas separadamente. Mas melhor do que todas elas, é o que as fez, que é nosso Deus, que não passa, porque nada vem depois dele.

## CAPÍTULO XII

### O amor em Deus

 Se te agradam os corpos, louva a Deus neles, e dirige teu amor para teu artífice, para não o desagradar nas mesmas coisas que te agradam.

 Se te agradam as almas, ama-as em Deus, porque, embora mutáveis, se fixas nele, terão estabilidade; de outro modo, passariam e pereceriam. Ama-as, pois, nele, e arrasta contigo até ele quantas almas puderes, dizendo-lhes: "Amemo-lo". Porque ele criou estas coisas, e não está longe; ele não as fez para depois ir embora, mas dele procedem e nele estão. E ele está onde aprecia a verdade: no mais íntimo do coração; mas o coração errante se afastou dele.

 Voltai, pecadores, ao coração, e ligai-vos àquele que é vosso criador. Firmai-vos nele, e estareis firmes; descansai nele, e estareis descansados. Para onde ides por esses ásperos caminhos? Para onde ides? O bem que amais, dele procede, mas só é bom e suave quando se dirige a ele; porém, será justamente amargo se, abandonando a Deus, amardes injustamente o que dele procede. Por que continuai por caminhos difíceis e trabalhosos? O descanso não está onde o buscais. Buscais a vida feliz na região das trevas: não está lá. Como achar a vida bemaventurada onde nem sequer há vida?

 Ele, nossa vida real veio até nós; sofreu nossa morte, e a suplantou com a abundância de sua vida; com voz de trovão clamou para que voltássemos a ele, para o lugar escondido de onde veio até nós, passando primeiro pelo seio de uma virgem, onde se desposou com ele a natureza humana, carne mortal, para não ficar sempre mortal.

 Dali, como o esposo que sai do tálamo, deu saltos como um gigante, para correr seu caminho. E não se deteve; correu clamando com suas palavras, com suas obras, com sua própria morte, com sua vida, com sua descida aos ínferos e com sua ascensão, clamando para que voltássemos a ele. Se ele se afastou de nossa vista, foi para que entremos em nosso coração, e ali o encontremos; se partiu, ainda está conosco. Não quis ficar por muito tempo entre nós, mas não nos abandonou. Retirou-se de onde nunca se afastou, pois o mundo foi criado por ele, e no mundo estava, e ao mundo veio para salvar os pecadores. E a ele se confessa minha alma, a ele que a cura e contra quem pecou.

 Filhos dos homens, até quando sereis duros de coração? Será possível que, depois de ter a vida descido até vós, não queirais subir e viver? Mas para onde subis, quando vos ergueis e abris vossa boca no céu? Descei para subir, para subir até Deus, já que caístes levantando-vos contra Deus.

 Dize-lhes isto, minha alma, para que chorem neste vale de lágrimas, e assim os arrebates contigo para Deus, pois, ao dizer estas palavras ardendo em chamas de caridade, é o espírito divino que te inspira.

## CAPÍTULO XIII

### O problema do belo

 Então eu ignorava tais coisas – e por isso amava belezas terrenas. Caminhava para o abismo, dizendo a meus amigos: "Será que amamos algo que não é belo? E que é o belo? E que é a beleza? Que é que nos atrai e apega às coisas que amamos? Pois, com certeza, se nelas não houvesse certa graça e formosura, não nos atrairiam.

 E eu observava e via que num mesmo corpo uma coisa era o todo, harmonioso e belo, e outra o que lhe era conveniente, sal aptidão de se ajustar de maneira perfeita a alguma coisa como, por exemplo, a parte do corpo em relação ao conjunto, o calçado em relação ao pé, e outras similares. Esta consideração brotou em minha alma do íntimo de meu coração, e escrevi alguns livros sobre o belo e o conveniente, creio que dois ou três – tu o sabes, Senhor – pois já me esqueci, e não os tenho mais porque se me extraviaram não sei como.

## CAPÍTULO XIV

### Razões de uma dedicatória

 Mas, meu Senhor e meu Deus, qual o motivo de dedicar esses livros a Hiério, orador de Roma? Não o conhecia, apreciando-o apenas pela fama de sua doutrina, que era grande, e por alguns ditos seus, que ouvira, e que me agradaram. Mas dele gostava principalmente porque ele agradava aos outros, que lhe tributavam grandes elogios, admirados de que um sírio, educado na eloqüência grega, chegasse a orador admirável na latina, e grande conhecedor de todos os assuntos, ligados à filosofia. Assim, ouve-se louvar a um homem, e, embora ausente, começa-se a amá-lo. Entrará o amor no coração do que ouve pela boca do que louva? É certo que não, mas o amor de um se inflama com amor do outro. Por isso se ama ao que é louvado; mas só quando se está persuadido de que o louvor vem de coração sincero, ou quando o louvor é inspirado pelo amor.

 Assim pois amava eu então aos homens, pelo juízo dos homens, e não pelo teu, meu Deus, em quem ninguém se engana. Contudo, por que não o louvava como se louva a uma auriga famoso ou a um caçador afamado pelas aclamações do povo, mas de modo mais distinto e mais ponderado, tal como eu gostaria de ser louvado?

 Certamente, eu não gostaria de ser louvado e amado como os comediantes, embora eu também os ame e louve; antes, preferiria mil vezes, permanecer desconhecido a ser louvado dessa maneira, e mesmo ser odiado a ser amado assim. De que modo convivem em uma alma gostos tão vários e diversos? Como é que amo em outro o que rejeitaria e afastaria para longe de mim, sendo ambos homens? Aprecia-se um bom cavalo, sem que se queira ser um cavalo, se isso fosse possível. Mas de um histrião não se pode dizer o mesmo, pois tem a mesma natureza que nós. Logo, amo em um homem o que teria horror de ser, embora também eu seja homem? Grande abismo é o homem, cujos cabelos tu, Senhor, tens contados; e não se perde um sem que tu o saibas; e, contudo, mais fáceis de contar são seus cabelos que suas paixões e os movimentos de seu coração.

 Mas aquele orador era do número dos que eu amava a ponto de desejar ser como ele; mas eu andava errante por meu orgulho e era arrastado por toda espécie de vento, embora em segredo fosse governado por ti. E como sei, e como te confesso com tanta certeza que o amava mais por amor dos que o louvavam do que pelos méritos que lhe valiam esses louvores?

 Se em vez de o louvarem aquelas mesmas pessoas o criticassem, e se me contassem dele as mesmas coisas, mas com censura e desprezo, certamente não me entusiasmaria por ele; não obstante, os fatos não seriam diferentes e nem o homem outro, mas unicamente os sentimentos dos narradores.

 Eis onde jaz enferma a alma que ainda não se apoiou na firmeza da verdade. É levada e trazida, atirada e rechaçada, segundo os sopros das línguas que ventam dos peitos dos que opinam! E de tal modo a luz lhe é toldada, que não distingue a verdade, apesar de estar ela à nossa vista.

 Para mim era importante que aquele homem conhecesse minhas palavras e meus trabalhos. Se ele os aprovasse, me entusiasmaria ainda mais por ele; mas se os reprovasse, meu coração fútil e vazio de tua firmeza, se lastimaria. Contudo, meu prazer era pensar e refletir no problema do belo e do conveniente, assunto do livro que lhe dedicara, admirando-o na minha imaginação, mesmo que ninguém mais o louvasse.

## CAPÍTULO XV

### Os primeiros livros

 Mas não atinava com a chave de tuas artes em tão grandes obras, ó Deus onipotente, único criador de maravilhas. Vagava minha alma pelas formas corpóreas, e definia o belo como o que agrada por si mesmo, e o conveniente como o que agrada por sua acomodação a outra coisa, e apoiava essa distinção com exemplos tomados dos corpos.

 Daqui passei à natureza da alma, mas o falso conceito que tinha das coisas espirituais não me permitia perceber a verdade. A própria força da verdade saltava-me aos olhos, mas logo eu afastava da realidade incorpórea meu espírito inquiridor, voltando-me para as figuras, as cores e as grandezas materiais. E como não podia ver nada semelhantes na alma, julgava que tampouco seria possível ver minha alma.

 Mas, como eu amava a paz da virtude, e aborrecia a discórdia do vício, notava naquela certa unidade e neste certa desunião; parecia-me que residisse nessa unidade a alma racional, a essência da verdade e do sumo bem. Na desunião, via eu não sei que substância de vida irracional e a natureza do sumo mal, que não era apenas substância, mas também verdadeira vida. Todavia não procedia de ti, meu Deus, de quem procedem todas as coisas. E chamava àquela unidade mônada, como alma sem sexo, e a esta multiplicidade díada, como a ira nos crimes, a concupiscência nas paixões, sem saber o que dizia. Ignorava então, ainda não havia aprendido que o mal não é substância alguma, nem que nosso espírito não é o bem soberano e imutável.

 Assim como se cometem crimes quando o movimento do espírito é vicioso e se atira insolente e turbulento, e se cometem infâmias quando o afeto da alma, fonte dos prazeres carnais, é imoderado, assim os erros e falsas opiniões contaminam a vida se a alma racional está viciada, como estava a minha então. Ignorava que ela deveria ser ilustrada por outra luz para participar da verdade, por não ser da mesma essência da verdade, porque tu, Senhor, alumiarás minha lâmpada; tu, meu Deus, iluminarás minhas trevas, e todos participamos de tua plenitude, porque és a luz verdadeira que ilumina a todo homem que vem a este mundo, e porque em ti não há mudança nem a momentânea obscuridade.

 Eu me esforçava para me aproximar de ti, mas tu me repelias para que experimentasse a morte, pois resistes aos soberbos. E que maior soberba haveria que afirmar, com inaudita loucura, que eu era da mesma natureza que tu? Porque, sendo eu mutável, e reconhecendo-me tal – pois, se queria ser sábio, era para fazer-me de menos para mais perfeito – preferia, contudo, julgar mutável a ti do que não ser o que tu és. Eis aqui por que era repelido, e por que resistias à minha soberba cheia de vento.

 Eu não imaginava mais que formas corpóreas; carne, acusava a carne; espírito errante, não conseguia voltar para ti, nem em mim, nem nos corpos; não eram sugeridas por tua verdade, mas imaginadas por minha vaidade, de acordo com os corpos. E dizia aos pequeninos teus fiéis concidadãos, dos quais eu, ignaro, ainda exilado, dizia-lhes eu, tagarela inepto: "Por que a alma, criatura de Deus, se engana?" Mas não queria que dissessem: "E por que Deus se engana?" E defendia antes que tua substância imutável era obrigada a errar, para não confessar que a minha, mutável, se desencaminhara espontaneamente, ou que era castigada pelo erro.

 Teria eu vinte e seis ou vinte e sete anos quando escrevi essas coisas, revolvendo dentro de mim apenas imagens corporais, cujo ruído aturdia os ouvidos do meu coração. Buscava eu aplicá-los – ó doce verdade – à tua melodia interior, quando meditava sobre o belo e o conveniente. Meu desejo era estar diante de ti, e ouvir tua voz, e alegrar-me intensamente com a voz do esposo, mas não o podia, porque o alarido do meu erro me arrebatava para fora e, sob o peso de minha soberba, caía no abismo. Pois ainda não davas gozo e alegria a meus ouvidos, nem exultavam meus ossos, porque ainda não haviam sido humilhados.

## CAPÍTULO XVI

### As dez categorias de Aristóteles

 E que lucro me trazia, tendo eu vinte anos de idade, mais ou menos, e chegando-me às mãos a obra de Aristóteles, intitulada As Dez Categorias – que meu mestre, o retórico de Cartago, e outros, considerados doutos, citavam com grande ênfase e ponderação, fazendo-me suspirar por ela como por algo grandioso e divino – de que me servia ler essa obra e compreendê-la sozinho? Falando com outros, que afirmavam ter conseguido entendê-la só por meio de mestres eruditíssimos, que lha haviam explicado não apenas com palavras, mas também com figuras pintadas na areia, nada me souberam dizer que eu já não tivesse entendido em minha leitura particular.

 Parecia-me que essa obra falava com muita clareza das substâncias, como o homem, e das coisas que nelas se encerram, como a forma do homem; a estatura, quantos pés mede; o parentesco, de quem é irmão; onde se encontra, quando nasceu; se está de pé, sentado, calçado ou armado; se faz alguma coisa ou se padece de alguma coisa, e, enfim, uma infinidade de relações que se contêm nestes nove gêneros, dos quais citei alguns exemplos, ou no próprio gênero da substância, que são também inumeráveis os que encerra.

 De que me aproveitava tudo isso, se até me prejudicava? Julgando que naqueles dez predicamentos se achavam compreendidas, de modo absoluto, todas as coisas, esforçava-me por compreender também a ti, meu Deus, Ser maravilhosamente simples e imutável, como se fosses subordinado à tua grandeza e formosura, como se estas estivessem em ti como em seu sujeito, como se fosses um corpo; tua grandeza e beleza são porém uma mesma coisa contigo, ao contrário dos corpos, que não são grandes ou belos por serem corpos, pois, embora fosses menores e menos belos, nem por isso deixariam de ser corpos.

 Era pois falso o que pensava de ti, e não verdade; ilusões de minha miséria, e não representação sólida de tua beleza. Havias ordenado, Senhor, e assim se cumpria em mim tua vontade, que a terra me produzisse abrolhos e espinhos, e que eu só conseguisse meu pão à custa de trabalho.

 De que me aproveitava também ler e compreender por mim mesmo todos os livros que pude ter nas mãos sobre as artes chamadas liberais, se eu era então escravo de minhas más inclinações? Comprazia-me em sua leitura, sem atinar de onde vinha quanto de verdadeiro e certo achava neles; eu estava de costas para a luz, e o rosto, para os objetos iluminados, e por isso meus olhos, que os viam iluminados, não recebiam luz.

 Tu sabes, Senhor, meu Deus, como sem ajuda de mestre, aprendi tudo o que li, quanto às leis da retórica, da dialética, da geometria, da música e da matemática, porque também a vivacidade da inteligência e a agudeza da intuição são dons teus. Mas não te oferecia por eles sacrifício algum, e por isso causavam-me mais dano do que proveito. Insisti em me apoderar da melhor parte da minha herança, e não guardei em ti minha força, mas afastei-me de ti para uma região longínqua, a fim de dissipá-la entre as meretrizes de minhas paixões.

 De que me serviam dons tão preciosos, se não usava bem deles? Só compreendi que aquelas artes eram tão difíceis de entender, mesmo para os estudiosos e sábios, quando me esforçava para expô-las: entre eles, o mais destacado era o que me compreendia menos vagarosamente.

 Mas qual o fruto disso, se eu te concebia, Senhor meu Deus, ó Verdade, como um corpo luminoso e infinito, e eu como uma parcela desse corpo? Que rematada perversidade! Assim era eu; não me envergonho agora, meu Deus, de confessar tuas misericórdias para comigo, e de te invocar, já que não me envergonhei então de proferir ante os homens tais blasfêmias e de ladrar contra ti. De que me aproveitava, repito, a inteligência ágil para entender aquelas ciências, e para explicar com clareza tantos livros complicados, sem que ninguém mos houvesse explicado, se errava monstruosamente na piedade com sacrílega torpeza? E que prejuízo sofriam teus pequeninos em serem de menor inteligência, se não se afastavam de ti, para que, seguros no ninho da tua Igreja, se cobrissem de penas, e lhes alimentassem as asas da caridade com o sadio alimento da fé?

 Ó Deus e Senhor nosso! Esperemos, ao abrigo de tuas asas; protege-nos, leva-nos! Tu levarás os pequeninos, e até escarnecidos tu os levarás, nossa firmeza só é firmeza quando está em ti; mas quando depende de nós, então é debilidade. Nosso bem vive sempre em ti, e somos perversos porque nos afastamos de ti. Voltemos já, Senhor, para não nos aniquilarmos, porque em ti vive nosso bem, sem deficiência alguma; sem medo de não o encontrar quando voltarmos para nossa origem e, embora ausentes, nem por isso desaba nossa casa, tua eternidade.