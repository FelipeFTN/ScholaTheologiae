## CAPÍTULO I

### Dos dezenove aos vinte e oito anos

 Durante esse período de nove anos – dos dezenove até os vinte e oito anos – fui seduzido e sedutor, enganado e enganador, conforme minhas muitas paixões; publicamente, com aquelas doutrinas que se chamam liberais; ocultamente, com o falso nome de religião, mostrando-me aqui soberbo, ali supersticioso, e em toda parte vaidoso. Ora perseguindo a aura da gloria popular até os aplausos do teatro, os certames poéticos, os torneios de coroas de feno, as bagatelas de espetáculos e a intemperança da luxúria; ora, desejando muito purificar-me dessas imundícies, levando alimento aos chamados "eleitos" e "santos", para que na oficina de seu estômago fabricasse anjos e deuses que me libertassem. Tais coisas seguia eu e praticava com meus amigos, iludidos comigo e por mim.

 Riam-se de mim os arrogantes, e os que ainda não foram prostrados e salutarmente esmagados por ti, meu Deus; mas eu, pelo contrário, hei de confessar diante de ti minhas torpezas para teu louvor. Permite-me, te suplico, e concede-me que me lembre fielmente dos desvios passados de meu erro, e que eu te sacrifique uma vítima de louvor.

 De fato, sem ti, que sou eu para mim mesmo senão um guia que conduz ao abismo? Ou que sou eu, quando tudo me corre bem, senão uma criança que suga o leite, e que se alimenta de ti, alimento incorruptível? E que é o homem, seja ele quem for, se é homem?

 Riam-se de nós os fortes e poderosos, que nós, débeis e pobres, confessaremos teu santo nome.