## CAPÍTULO IX

### O amigo de Deus

. É isto o que se ama nos amigos; e de tal modo se ama, que a consciência humana se julga culpada se não ama ao que a ama, ou se não retribui amor com amor procurando na pessoa do amigo apenas o sinal exterior de sua benevolência. Daqui o pranto do luto quando morre um amigo, as trevas de dores, e as lágrimas que inundam o coração quando a doçura se transforma em angústia, e a morte dos que morrem na morte dos que vivem.

 Bem-aventurado o que te ama, Senhor, e ama ao amigo em ti, e ao inimigo por amor a ti; só não perde o amigo quem tem a todos por amigos naquele que nunca se perde. E quem é este, senão nosso Deus, o Deus que fez o céu e a terra, e os enche, porque, enchendo-os, os criou? Ninguém, Senhor, te perde senão o que te abandona. Mas, quem te deixa, para onde vai, ou para onde foge, senão de ti benévolo para ti irado? Onde não achará tua lei para seu castigo? Porque tua lei é a verdade, e a verdade és tu mesmo.