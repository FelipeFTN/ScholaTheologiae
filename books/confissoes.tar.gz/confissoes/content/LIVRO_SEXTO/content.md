### A separação da amante

 Entretanto, multiplicavam-se meus pecados. Quando arrancaram do meu lado, por ser impedimento ao meu matrimonio, aquela com quem partilhava o leito, meu coração, ao qual ela estava unida, ficou ferido e sangrando. Ela, por sua vez, voltando para a África, fez-te voto, Senhor, de jamais conhecer outro homem, deixando comigo o filho natural que dela tivera.

 Mas eu, desgraçado, fui incapaz de imitar aquela mulher. Estava impaciente pelo prazo de dois anos que deveria transcorrer até receber por esposa aquela que pedira em casamento – e porque eu não era amante do matrimonio, mas escravo da sensualidade – procurei pois outra mulher, não como esposa, mas para alimentar e manter íntegra ou agravada a doença da minha alma, sob a tutela do meu hábito, até que contraísse matrimonio. Mas nem por isso sarava a chaga causada pela separação da primeira mulher; mas, depois de ardor e sofrimento agudíssimos, começava a se corromper doendo tanto mais desesperadamente quanto mais fria se tornava.

## CAPÍTULO XVI