## CAPÍTULO XXVIII

### A medida do futuro

 Mas o futuro, que ainda não existe, como pode diminuir ou consumir-se? E o passado, que já não existe, como pode aumentar, a não se por existirem no espírito, autor dessas três transformações: a espera, a atenção e a lembrança? O objeto de sua espera passa pela atenção e se transforma em lembrança.

 De fato, quem ousará negar que o futuro ainda não existe? Todavia, a espera do futuro já está no espírito. E quem poderá negar que o passado não mais existe? Contudo, a lembrança do passado ainda está no espírito. Enfim, haverá alguém que negue que o presente carece de duração, porque é um instante que passa? No entanto, perdura a atenção, diante da qual o seu objeto presente continuamente se retira. O futuro, portanto, não é longo, porque não existe. Um futuro longo seria apenas uma longa espera do futuro. nem pode ser longo o passado, que também não existe. Um passado longo é uma longa lembrança do passado.

 Digamos que eu queira cantar uma canção que conheço: antes de iniciar, minha expectativa se estende pela melodia como um todo. Quando começo, tudo o que vira passado é armazenada na memória. A atividade de meu espírito se divide em memória, onde guardo o que já disse, e em expectativa em relação ao que vou dizer. Contudo, a atenção está presente, e por seu intermédio o futuro se torna passado. Quanto mais se aproxima o fim da canção, tanto menos se torna a expectativa e tanto maior a memória, até que aquela se esgota e a ação cumprida passa inteiramente para a memória.

 E o que acontece com a canção tomada em seu conjunto, também ocorre com cada uma de suas partes, com cada sílaba; e também acontece com uma ação mais longa, da qual essa melodia talvez faça parte. O mesmo acontece com toda a vida do homem, da qual seus atos são partes. Sucede, enfim, com toda a história dos filhos do homem, da qual cada existência é apenas uma parte.