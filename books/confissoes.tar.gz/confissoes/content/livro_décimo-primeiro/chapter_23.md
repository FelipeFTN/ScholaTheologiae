## CAPÍTULO XXIII

### O tempo e o movimento

 Ouvi um homem instruído dizer que o tempo é nada mais do que o movimento do sol, da lua e dos astros. Não concordo. Por que não seria então o tempo o movimento de todos os corpos? Se os astros passassem, e a roda de um oleiro continuasse a rodar, deixaria acaso de existir tempo para medir suas voltas? Como poderíamos dizer que elas se davam a intervalos iguais, ou ora mais rápida, ora mais lentamente, e que umas demoravam mais e outras menos? E, dizendo isto, não estaríamos falando do tempo? Não haveria mais em nossas palavras sílabas longas e breves, porque umas ressoam por mais tempo e outras por menos tempo?

 E tu, Deus, concede aos homens que percebam, que reconheçam neste modesto exemplo, o que as coisas grandes e pequenas têm em comum. Há astros e luminares celestes que nos servem de sinais e marcam as estações, os dias e os anos. Isso é verdade; todavia, como eu jamais diria que a volta realizada por aquela roda de madeira representa o dia, nem o sábio cuja opinião transcrevo poderia afirmar que a volta da roda não representa o tempo.

 O meu desejo é conhecer a natureza e a essência do tempo, com que medimos os movimentos dos corpos, e nos autoriza a dizer, por exemplo, que um movimento dura duas vezes mais que outro. O que chamamos de dia não é apenas o tempo todo o percurso de oriente a oriente, e que nos faz dizer: "Passaram-se tantos dias" – entendendo por isso também as noites, que não são enumeradas separadamente. Portanto, já que o dia se completa pelo movimento do sol e o círculo que ele cumpre a partir do oriente, pergunto eu se o dia é o próprio movimento ou se é o tempo que dura esses movimentos, ou ambas as coisas.

 Na primeira hipótese, teríamos um dia mesmo se o sol fizesse seu percurso no intervalo de uma hora. Na hipótese da duração, não haveria dia se o sol fizesse seu percurso no breve espaço de uma hora; e o sol deveria cumprir vinte e quatro vezes seu percurso para formar um dia. Diremos então que o movimento do sol, e a duração desse movimento, é que fazem o dia? Mas então não se poderia chamar de dia se o sol efetuasse seu percurso no lapso de uma hora, mais do que se, parando o sol seu percurso, passasse o mesmo tempo que é necessário habitualmente ao sol para completar sua revolução de uma manhã a outra.

 Portanto, não mais buscarei conhecer em que consiste o dia, mas em que consiste o tempo, que usamos para medir o percurso do sol. Usando tal medida, diríamos que o sol gastara em seu giro a metade do tempo habitual , se o tivesse completado em um lapso de doze horas. E, comparando essas duas durações, diríamos que uma é o dobro da outra, mesmo que o sol demorasse umas vezes o tempo simples, outras o tempo duplo para ir de oriente para oriente.

 Ninguém, portanto, me diga que o tempo é o movimento dos corpos celestes. Quando a oração de um homem fez parar o sol para concluir vitoriosamente a batalha, o sol estava imóvel, mas o tempo caminhava; e a batalha terminou no espaço de tempo que lhe era necessário.

 Veja, pois, que o tempo é uma espécie de extensão. Mas eu o vejo, ou apenas tenho a impressão de vê-lo? Só tu mo demonstrarás, ó Luz, ó Verdade!