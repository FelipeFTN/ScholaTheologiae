## CAPÍTULO V

### A palavra e a criação

 De que modo criaste o céu e a terra, e de que instrumento te serviste para levar a cabo tão grandiosa obra? Pois não procedeste como artesão, que forma um corpo de outro, conforme a concepção de seu espírito, que tem o poder de exteriorizar a forma que vê em si mesmo com o olhar do espírito. De onde lhe vem esse poder do espírito, senão de ti, que o criaste? E essa forma, ele a impõe a uma matéria que preexistia, apta para ser transformada, como a terra, a pedra, a madeira, o outro e tantas outras substâncias.

 Mas de onde proviriam essas coisas se não as tivesse criado? Criaste o corpo do artista, a alma que governa seus membros, a matéria que ele plasma, a inspiração que concebe e vê interiormente o que executará exteriormente. Deste-lhe os órgãos dos sentidos, intérpretes pelos quais materializa as intenções de sua alma; informam o espírito do que fizeram, para que este consulte a verdade, o juiz interior, para saber se a obra é boa. Tudo isso te louva como criador de todas as coisas.

 Mas como os fizeste? Como criaste, meu Deus, o céu e a terra? Por certo não criaste o céu e a terra no céu e na terra. Nem tampouco os criaste no ar, nem sob as águas que pertencem ao céu e à terra. Não criaste o universo no universo, porque não havia espaço onde pudesse existir. Não tinhas à mão a matéria com que modelar o céu e a terra. E de onde viria essa matéria que não tinhas ainda feito para dela fazer alguma coisa? Que criatura pode existir que não exija tua existência? Contudo, falaste e o mundo foi feito. Tua palavra o criou.