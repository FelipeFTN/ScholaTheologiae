## CAPÍTULO XXIX

### A eternidade de Deus

 Mas porque tua misericórdia é superior a todas as vidas, e eis que minha vida não é mais que distensão, e tua destra me acolheu em meu Senhor, o Filho do homem, mediador entre ti, que és uno, e nós, que somos muitos e vivemos divididos por diversas paixões. Assim. Por ele me unirei àquele, que por ele se uniu a nós, e liberto dos antigos dias, recolherei meu ser seguindo tua Unidade. Esquecido do passado, sem me preocupar com as coisas futuras e transitórias, atento apenas àquilo que é eterno, não com dispersão mas com todas as minhas forças buscarei a palma da vocação celeste, onde ouvirei a voz de teu louvor, e onde contemplarei tua alegria, que não conhece futuro nem passado.

 Agora, porém, meus anos transcorrem em lamentos, e tu, meu consolo, ó Senhor, meu Pai, tu és eterno. Mas eu me dispersei no tempo, cuja ordem ignoro; tumultuosas vicissitudes despedaçam meus pensamentos, entranhas de minha alma, até o dia em que, purificado pelo fogo de teu amor, me una a ti.