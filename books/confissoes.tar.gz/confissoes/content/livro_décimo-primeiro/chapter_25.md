## CAPÍTULO XXV

### Prece

 Confesso-te, Senhor, que ainda não sei o que é tempo. E torno a confessar, Senhor, eu o sei, que digo estas coisas no tempo, e que de há muito estou falando do tempo, e que esse muito também não seria o que é senão pela duração do tempo. Mas como posso saber isto, se desconheço o que é o tempo? Talvez eu ignore a arte de exprimir o que sei. Ai de mim, que não sei nem mesmo o que ignoro! Eis-me diante de ti, meu Deus, tu vês que não minto e que falo de coração. Acenderás minha candeia, Senhor meu Deus, e iluminarás minhas trevas.