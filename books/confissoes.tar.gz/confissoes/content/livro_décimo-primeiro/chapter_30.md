## CAPÍTULO XXX

### Deus e o tempo

 E repousarei imutável em ti, em tua verdade, na minha forma. não mais tolerarei as perguntas das pessoas que, pela enfermidade que é a pena de seu pecado, tem mais sede de saber do que lhes permite sua capacidade, que dizem: "Que fazia Deus antes de criar o céu e a terra?" – ou ainda: "Como lhe veio a idéia de criar algo, se antes nunca fizera nada" – Concedelhes, Senhor, que reflitam no que dizem, que compreendam que não se pode falar nunca onde não há tempo. Quando se diz que alguém nunca fez nada, que se quer dizer senão que esse tal nada fez em tempo algum? Que eles compreendam que não pode existir tempo na ausência da criação, e deixem de semelhantes falácias.

 Que também atentem para o que têm diante de si, para compreender que tu, antes de todos os tempos, és o Criador eterno de todos os tempos, e que nenhum tempo te é coeterno, nem criatura alguma, embora algumas estejam acima dos tempos (Agostinho se refere aqui, aos anjos e demônios).