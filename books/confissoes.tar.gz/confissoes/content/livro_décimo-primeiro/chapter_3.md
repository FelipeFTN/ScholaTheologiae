## CAPÍTULO III

### O que disse Moisés

 Concede-me, Senhor, que eu ouça e compreenda como no princípio criaste o céu e a terra. Moisés assim o escreveu. Escreveu e partiu deste mundo, para onde lhe falaste, para junto de ti, e já não está presente para nós. Se estivesse aqui, detê-lo-ia, e dele indagaria, em teu nome, o sentido de tais palavras, e absorveria com atenção as palavras que brotassem de sua boca. Se me falasse em hebraico, em vão sua voz bateria em meus ouvidos, e nenhuma idéia chegaria à minha mente; mas se me falasse em latim, eu compreenderia suas palavras.

 Mas, como saberia eu se ele dizia a verdade? E, posto que o soubesse, sabê-lo-ia por seu intermédio? Não, mas seria dentro de mim, no íntimo recesso do pensamento que a Verdade, que nem é hebraica, nem grega, nem latina, nem bárbara, sem auxílio de lábios ou de língua, sem ruído de sílabas, me diria: "Ele fala a verdade". – e eu, imediatamente, com a certeza da fé, diria àquele teu servo: "Tu dizes a verdade!".

 Mas, como não posso consultar a Moisés, é a ti, ó Verdade, cuja plenitude ele possuía quando enunciou tais palavras, é a ti, meu Deus, que dirijo minha súplica, perdoa meus pecados. Concedeste que um tem servo dissesse essas coisas: faze agora com que eu as compreenda.