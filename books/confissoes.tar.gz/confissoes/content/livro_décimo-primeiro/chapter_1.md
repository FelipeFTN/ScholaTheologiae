## CAPÍTULO I

### Finalidade das confissões

 Porventura, Senhor, tu que és eterno, ignoras o que te digo, ou não vês no tempo o que se passa no tempo? Por que motivo, então, narrar-te essas coisas todas? Certamente não é para que as conheças; é para despertar em mim e nos que me lêem nosso amor por ti; para que todos exclamemos: Grande é o Senhor, e infinitamente digno de louvores! Já disse e torno a dizer: É pelo desejo de teu amor que narro isso.

 Também nós oramos e, não obstante, a Verdade nos diz: O Pai sabe do que haveis mister, antes mesmo de lho pedires. – Por isso manifestamos nosso amor por ti, confessando-te nossas misérias e tuas misericórdias para conosco, para que termines a nossa libertação que começaste, e para que deixemos de ser infelizes em nós para sermos felizes em ti. Pois nos chamaste para que fôssemos pobres de espírito, mansos, penitentes, famintos e sedentos de justiça, misericordiosos, puros de coração e pacíficos.

 Muitas coisas te narrei, conforme o pude e conforme o desejo de minha alma, porque o exigiste primeiro, para que te confessasse, Senhor, meu Deus, porque és bom, e porque tua misericórdia é eterna.