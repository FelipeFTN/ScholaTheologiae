# LIVRO DÉCIMO-PRIMEIRO

## CAPÍTULO I

### Finalidade das confissões

 Porventura, Senhor, tu que és eterno, ignoras o que te digo, ou não vês no tempo o que se passa no tempo? Por que motivo, então, narrar-te essas coisas todas? Certamente não é para que as conheças; é para despertar em mim e nos que me lêem nosso amor por ti; para que todos exclamemos: Grande é o Senhor, e infinitamente digno de louvores! Já disse e torno a dizer: É pelo desejo de teu amor que narro isso.

 Também nós oramos e, não obstante, a Verdade nos diz: O Pai sabe do que haveis mister, antes mesmo de lho pedires. – Por isso manifestamos nosso amor por ti, confessando-te nossas misérias e tuas misericórdias para conosco, para que termines a nossa libertação que começaste, e para que deixemos de ser infelizes em nós para sermos felizes em ti. Pois nos chamaste para que fôssemos pobres de espírito, mansos, penitentes, famintos e sedentos de justiça, misericordiosos, puros de coração e pacíficos.

 Muitas coisas te narrei, conforme o pude e conforme o desejo de minha alma, porque o exigiste primeiro, para que te confessasse, Senhor, meu Deus, porque és bom, e porque tua misericórdia é eterna.

## CAPÍTULO II

### A inteligência das Escrituras

 Quando poderei eu descrever, com o poder de minha pena, todas as exortações, todos os terrores, as consolações, as inspirações de que lançaste mão para me levar a pregar tua palavra e dispensar ao povo teu sacramento?

 Mesmo que eu fosse capaz de enumerar na ordem tais coisas, as gotas de meu tempo me são preciosas. De há muito que anseio ardentemente meditar sobre tua lei, e te confessar nela minha ciência e minha ignorância, os albores de tuas luzes na minha alma e o que ainda resta em mim de trevas, até que minha fraqueza seja absorvida por tua força. Não quero gastar em outros cuidados as horas de liberdade que me restam além dos cuidados indispensáveis do corpo, do trabalho intelectual, dos serviços que devemos aos homens, e dos que prestamos sem lhe dever.

 Senhor meu Deus, ouve minha prece; que tua misericórdia atenda ao meu desejo, pois não arde só por mim, mas também para servir ao amor fraternal, e bem vês em meu coração que é assim.

 Permitas que te sacrifique meu pensamento e minha língua, mas concede-me o que te devo oferecer, porque sou pobre e indigente, enquanto és rico para todos os que te invocam e, sem cuidados contigo, cuidas de nossa existência. Livra-me, Senhor, de toda temeridade e de toda mentira que meus lábios e meu coração possam proferir. Que tuas Escrituras sejam minhas castas delicias, que não me engane nelas, nem com elas engane a ninguém. Senhor, ouve-me, e tem compaixão, Senhor meu Deus, luz dos cegos e vigor dos fracos, mas também luz dos que vêem e força dos fortes; presta atenção à minha alma e ouve-a clamar do fundo do abismo. E se teus ouvidos estão ausentes do abismo, para onde iremos, por quem clamaremos?

 Teu é o dia e tua é a noite; a um aceno do teu querer, os minutos voam. Concede-me o tempo para meditar nos mistérios de tua lei, e não a feche para os que lhe batem à porta; não foi em vão que quiseste fossem escritas tantas páginas de obscuros segredos. Porventura, estes bosques não terão seus cervos, que ali se abrigam, se alimentam, que aí passeiam, descansam e ruminam? Ó Senhor, aperfeiçoa-me e revela-me o sentido desses mistérios. Tua palavra é minha alegria, tua voz está acima de todos os prazeres. Concede-me o que amo, porque ando enamorado, e amar é um dom que me concedeste. Não abandone teus dons, nem deixe de regar tua erva sedenta. Te exaltarei por tudo o que descobrir em teus livros; que eu ouça a voz de teus louvores. Faz que eu me inebrie de ti, e que eu contemple as maravilhas de tua lei, desde o começo dos tempos, quando fizeste o céu, a terra, até que partilharemos do reino do perpétuo de tua cidade santa.

 Senhor, tem piedade de mim, ouve meu desejo. Julgo que não desejo nada da terra, nem ouro, nem prata, nem pedras preciosas, nem belas roupas. Nem honrarias, nem prazeres carnais, nem de coisas necessárias ao corpo de nossa peregrinação desta vida. Tudo, alias, nos é dado por acréscimo quando procuramos teu reino e tua justiça.

 Vê, meu Deus, de onde nasce meu desejo. Os ímpios contaram-me suas alegrias, mas esses prazeres não são como os proporcionados por tua lei. É ela que inspira meu desejo. Olha, ó Pai, olha, e vê, e aprova. Queira tua misericórdia que eu encontre graça diante de ti, e que os arcanos secretos de tuas palavras se abram a meu espírito que bate às suas portas!

 Isso eu te suplico por nosso Senhor, Jesus Cristo, teu filho, aquele que está sentado à tua direita, o Filho do homem, a quem estabeleceste como mediador entre nós e ti. Por ele nos procuraste quanto não te procurávamos, e nos procuraste para que te buscássemos! Em nome de teu Verbo, por quem criaste todas as coisas, e a mim entre outras; de teu Filho unigênito, por quem chamaste à adoção o povo dos crentes, no qual também estou.

 Eu te conjuro por aquele que está sentado à tua direita, e que intercede por nós, no qual estão ocultos todos os tesouros da sabedoria e do conhecimento que procuro em teus livros. Moisés escreveu a respeito: "Isto diz ele, isto diz a Verdade".

## CAPÍTULO III

### O que disse Moisés

 Concede-me, Senhor, que eu ouça e compreenda como no princípio criaste o céu e a terra. Moisés assim o escreveu. Escreveu e partiu deste mundo, para onde lhe falaste, para junto de ti, e já não está presente para nós. Se estivesse aqui, detê-lo-ia, e dele indagaria, em teu nome, o sentido de tais palavras, e absorveria com atenção as palavras que brotassem de sua boca. Se me falasse em hebraico, em vão sua voz bateria em meus ouvidos, e nenhuma idéia chegaria à minha mente; mas se me falasse em latim, eu compreenderia suas palavras.

 Mas, como saberia eu se ele dizia a verdade? E, posto que o soubesse, sabê-lo-ia por seu intermédio? Não, mas seria dentro de mim, no íntimo recesso do pensamento que a Verdade, que nem é hebraica, nem grega, nem latina, nem bárbara, sem auxílio de lábios ou de língua, sem ruído de sílabas, me diria: "Ele fala a verdade". – e eu, imediatamente, com a certeza da fé, diria àquele teu servo: "Tu dizes a verdade!".

 Mas, como não posso consultar a Moisés, é a ti, ó Verdade, cuja plenitude ele possuía quando enunciou tais palavras, é a ti, meu Deus, que dirijo minha súplica, perdoa meus pecados. Concedeste que um tem servo dissesse essas coisas: faze agora com que eu as compreenda.

## CAPÍTULO IV

### O céu e a terra

 Existem pois o céu e a terra, e clamam que foram criados, mediante de suas transformações e mudanças. Mas o que não foi criado em sua forma definitiva, e todavia existe, nada pode conter que antes já não existisse em sua forma potencial, e nisso consiste a mudança e a variação. Proclamam também, os seres, que não foram criados por si mesmos: "Existimos porque fomos criados. Não existíamos antes, de modo que pudéssemos criar a nós mesmos." – E essa voz é a voz da própria evidência. És tu, Senhor, quem os criaste. E porque és belo, eles são belos; porque és bom, eles são bons; porque existes, eles existem. Mas tuas obras não são belas, não são boas, não existem de modo perfeito como tu, seu Criador. Comparados contigo, os seres nem são bons, nem belos, nem existem. Isso sabemos, e por isso te rendemos graças; mas nosso saber, comparado com tua ciência, é ignorância.

## CAPÍTULO V

### A palavra e a criação

 De que modo criaste o céu e a terra, e de que instrumento te serviste para levar a cabo tão grandiosa obra? Pois não procedeste como artesão, que forma um corpo de outro, conforme a concepção de seu espírito, que tem o poder de exteriorizar a forma que vê em si mesmo com o olhar do espírito. De onde lhe vem esse poder do espírito, senão de ti, que o criaste? E essa forma, ele a impõe a uma matéria que preexistia, apta para ser transformada, como a terra, a pedra, a madeira, o outro e tantas outras substâncias.

 Mas de onde proviriam essas coisas se não as tivesse criado? Criaste o corpo do artista, a alma que governa seus membros, a matéria que ele plasma, a inspiração que concebe e vê interiormente o que executará exteriormente. Deste-lhe os órgãos dos sentidos, intérpretes pelos quais materializa as intenções de sua alma; informam o espírito do que fizeram, para que este consulte a verdade, o juiz interior, para saber se a obra é boa. Tudo isso te louva como criador de todas as coisas.

 Mas como os fizeste? Como criaste, meu Deus, o céu e a terra? Por certo não criaste o céu e a terra no céu e na terra. Nem tampouco os criaste no ar, nem sob as águas que pertencem ao céu e à terra. Não criaste o universo no universo, porque não havia espaço onde pudesse existir. Não tinhas à mão a matéria com que modelar o céu e a terra. E de onde viria essa matéria que não tinhas ainda feito para dela fazer alguma coisa? Que criatura pode existir que não exija tua existência? Contudo, falaste e o mundo foi feito. Tua palavra o criou.

## CAPÍTULO VI

### Como falou Deus?

 Mas, como falaste? Porventura do mesmo modo como aquela voz que, saindo da nuvem, disse: Este é meu Filho bem-amado? – Essa voz fez-se ouvir, e passou; teve começo e fim; suas sílabas ressoaram, depois passaram, em sucessão ordenada até a última, que vem depois de todas as outras – e depois foi o silêncio. Por onde se vê claramente que essa voz foi gerada por órgão temporal de uma criatura a serviço de tua vontade eterna. E essas palavras, pronunciadas no tempo, foram comunicadas pelo ouvido material à inteligência, cujo ouvido interior está atento à tua palavra eterna. E a razão comparou essas palavras, proferidas no tempo, com o silêncio de teu Verbo eterno, e disse: "È diferente, muito diferente. Tais palavras estão bem abaixo de mim, nem sequer existem, pois fogem e passam; mas o Verbo de Deus permanece sobre mim eternamente".

 Se foi portanto com estas palavras sonoras e passageiras que ordenaste: Que se façam o céu e a terra! – se foi assim que os criaste, conclui-se que já havia, antes do céu e da terra, uma criatura temporal, cujos movimentos puderam fazer vibrar essa voz no tempo. Ora, não havia corpo algum antes do céu e da terra; ou se algum existia, tu certamente já o tinhas criado não por meio de uma voz passageira, justamente para que pudesse soar essa voz passageira para dizer: "Façam-se o céu e a terra!" E fosse o que fosse o ser de onde saísse tal voz, não teria existido se não o tivesses criado. Mas para criar esse corpo, necessário à emissão destas palavras, de que palavra e serviste?

## CAPÍTULO VII

### A palavra coeterna

 É assim que nos convidas a compreender o Verbo, que é Deus junto de ti, que também és Deus, Verbo pronunciado eternamente e pelo qual tudo é pronunciado eternamente. O que é dito, não é uma seqüência de palavras, ou uma palavra que é seguida por outra, como que a concluir uma frase; mas tudo é dito simultânea e eternamente. Do contrário, já haveria tempo e mudança, e não a verdadeira eternidade nem a verdadeira imortalidade.

 Isto eu o sei, meu Deus, e por isso te dou graças. Eu o sei, e eu to confesso, Senhor; e também o sabe todo aquele que não é ingrato à infalível verdade. Sabemos, Senhor, sabemos que não ser mais depois de ter existido, ou passar a ser quando ainda não se existia é o morrer e o nascer. Mas em teu Verbo, por ser verdadeiramente imortal e eterno, nada desaparece nem tem sucessão. Com o teu Verbo que é coeterno, enuncias eternamente e a um só tempo tudo o que dizes. E o que se realiza é o que dizes que se faça. Não é de outro modo, senão pelo Verbo, que crias. Todavia os seres criados por tua palavra não chegam à existência simultaneamente, desde toda a eternidade.

## CAPÍTULO VIII

### A verdadeira luz

 Imploro-te, Senhor meu Deus, qual o porquê disso tudo? De certo modo eu o compreendo, mas não sei como exprimi-lo. Poderei dizer que tudo o que tem começo e fim, começa e acaba quando a razão eterna, que não tem começo nem fim, sabe que deve começar ou acabar? Essa inteligência é teu Verbo, que é o princípio, porque também nos fala. Assim falou-nos no Evangelho com voz humana, e a palavra ecoou exteriormente nos ouvidos dos homens, para que cressem nele, e o buscassem em seu íntimo, e o encontrassem na eterna Verdade, onde um bom e único mestre instrui todos os seus discípulos.

 Aí, Senhor, ouço tua voz a me dizer que só nos fala verdadeiramente quem nos ensina, e quem não nos instrui, mesmo que fale, não nos diz nada. Mas quem nos ensina, senão a Verdade imutável? As lições da criatura mutável têm o único valor de nos conduzir à Verdade, que é imutável. Nela verdadeiramente aprendemos quando, de pé, a ouvimos, alegrando-nos por cauda da voz do Esposo, que nos reconduz àquele de quem viemos. Por isso, ele é o princípio, pois se ele não permanecesse, não teríamos para onde voltar de nossos erros. Quando voltamos de um erro, temos plena consciência dessa volta; e é para que tomemos consciência de nossos erros que ele nos instrui, porque ele é o princípio, e sua palavra é para nós.

## CAPÍTULO IX

### A voz do Verbo

 É nesse princípio, ó Deus, que criaste o céu e a terra; em teu Verbo, em teu Filho, em tua virtude, em tua sabedoria, em tua verdade, falando e agindo de modo admirável. Quem o poderá compreender ou explicar? Que luz é essa que por vezes me ilumina, e que fere meu coração sem o lesar? Atemorizo-me e inflamo-me: tremo porque, de certo modo, sou tão diferente dela; e inflamo-me, porque também sou semelhante a ela. A Sabedoria é a mesma sabedoria que brilha em mim de quando em quando: ela rasga as nuvens de minha alma, que novamente me encobrem quando dela me afasto, pelas trevas e pelo peso de minhas memórias. Na indigência, meu vigor enfraqueceu de tal modo, que nem posso mais suportar o meu bem, até que tu, Senhor que te mostraste compassivo com todas minhas iniqüidades, cures também todas as minhas fraquezas. Redimirás minha vida da corrupção; hás de me coroar na piedade e na misericórdia, e saciarás com teus bens meus desejos, porque minha juventude será renovada com a da águia. Pela esperança formos salvos, e aguardamos com paciência o cumprimento de tuas promessas.

 Ouça, pois, Tua voz em seu interior, quem puder, e eu quero clamar, cheio de fé em teu oráculo: "Como são magníficas as tuas obras, Senhor, que tudo criaste em tua Sabedoria! Ela é o princípio e nesse princípio criaste o céu e a terra".

## CAPÍTULO X

### Que fazia Deus antes da criação

 Com certeza ainda estão cheios do erro do velho homem os que nos dizem: "Que fazia Deus antes de criar o céu e a terra?" – Se estava ocioso, se nada fazia, porque não continuou a se abster sempre de qualquer ação? Se em Deus apareceu um movimento novo, uma vontade nova de dar o ser ao que ainda não tinha criado, como falar de uma verdadeira eternidade se nela nasce uma vontade que não existia antes? Mas a vontade de Deus não é uma criatura, ela é anterior a toda criatura; nenhuma criação seria possível se a vontade do Criador não a precedesse. A vontade, portanto, pertence à própria substância de Deus. Logo, se na substância de Deus nasce algo que antes não existia, não se pode mais com verdade chamá-la eterna. E se, desde toda eternidade, Deus quis a existência da criatura, por que a criatura também não é eterna?

## CAPÍTULO XI

### Tempo e eternidade

 Os que assim falam não te compreendem ainda, ó Sabedoria de Deus, luz das inteligências; não compreendem ainda como é criado o que é criado por ti e em ti. Esforçam-se por saborear as coisas eternas, mas seu espírito voa ainda sobre as realidades passadas e futuras. Quem poderá deter esse pensamento, quem o fixará por um momento, para que tenha um rápido vislumbre do esplendor da eternidade imutável, e a compare com os tempos impermanentes, para perceber que qualquer comparação é impossível? Então veria que a sucessão dos tempos não é feita senão de uma seqüência infindável de instantes, que não podem ser simultâneos; que, pelo contrário, na eternidade, nada é sucessivo, tudo é presente, enquanto o tempo não pode ser de todo presente. Veria que todo o passado é repelido pelo futuro, que todo futuro segue o passado, que tanto o passado como o futuro tiram seu ser e seu curso daquele que é sempre presente. Quem poderá deter a inteligência do homem para que pare e veja como a eternidade imóvel, que não é futura nem passada, determina o futuro e o passado? Acaso poderá realizar isso minha mão? Ou esta minha língua, com a palavra, poderia realizar tal obra?

## CAPÍTULO XII

### Deus antes da criação

 Eis minha resposta à questão: "Que fazia Deus antes de criar o céu e a terra?" – não responderei jocosamente como alguém para contornar a dificuldade do problema: "Preparava o inferno para os que perscrutam esses mistérios profundos". – Uma coisa é compreender e outra é brincar. Não, essa não será minha resposta. Prefiro dizer: "Não sei" – pois de fato não sei, que ridicularizar quem faz pergunta tão profunda, ou louvar quem responde com sofismas.

 Mas eu digo que tu, meu Deus, és o Criador de toda criatura; e, se por céu e terra se entende toda criatura, não temo afirmar: "Antes que Deus criasse o céu e a terra, nada fazia. De fato, se tivesse feito alguma coisa, o que poderia ser senão uma criatura? Oxalá eu soubesse tudo o que desejo saber, como sei que nenhuma criatura foi criada antes da criação.

## CAPÍTULO XIII

### O tempo antes da criação

 Se algum espírito leviano, vagando por tempos imaginários anteriores à criação, se admirar que o Deus Todo-Poderoso, tu, que criaste e conservas todas as coisas, ó autor do céu e da terra, tenha-te mantido inativo até o dia da criação, por séculos sem conta, que esse desperte e tome consciência do erra que gera sua admiração. Como, pois, poderiam transcorrer os séculos se tu, criador, ainda não os tinha criado? E poderia o tempo fluir se não existisse? E como poderiam os séculos passar, se jamais houvessem existido? Portanto, como és o criador de todos os tempos – se é que houve algum tempo antes da criação do céu e da terra – como se pode afirmar que ficaste ocioso? Pois também criaste esse mesmo tempo, e este não poderia passar antes que o criasses.

 Se porém, antes do céu e da terra não havia tempo algum, porque perguntam o que fazias então? Não poderia haver então se não existia o tempo.

 Não é no tempo que és anterior ao tempo: de outro modo não precederias a todos os tempos. Precedes porém a todo o passado na altura de tua eternidade sempre presente; dominas todo o futuro porque está por vir e que, quando chegar, já será passado. Contudo, tu és sempre o mesmo, e teus anos não passam jamais. Teus anos não vão nem vêm; mas os nossos vão e vêm, para que todos possam existir. Teus anos existem simultaneamente, pois não fluem; não passam, não são expulsos pelos que vêm, porque não passam. Os nossos, ao contrário, só existirão todos quando não mais existirem. Teus anos são como um só dia, e teu dia não é uma repetição cotidiana, é um perpétuo hoje, porque teu hoje não cede o lugar ao amanhã e nem sucede ao ontem. Teu hoje é a eternidade. Por isso geraste um filho coeterno, a quem disseste: "Hoje te gerei" – Todos os tempos são obra tua, e tu existes antes de todos os tempos; é pois inconcebível que tenha existido tempo quando o tempo ainda não existia.

## CAPÍTULO XIV

### Que é o tempo?

 Não houve, pois, tempo algum em que nada fizesses, pois fizeste o próprio tempo. E nenhum tempo pode ser coeterno contigo, pois és imutável; se, o tempo também o fosse, não seria tempo. Que é pois o tempo? Quem poderia explicá-lo de maneira breve e fácil? Quem pode concebê-lo, mesmo no pensamento, com bastante clareza para exprimir a idéia com palavras? E no entanto, haverá noção mais familiar e mais conhecida usada em nossas conversações? Quando falamos dele, certamente compreendemos o que dizemos; o mesmo acontece quando ouvimos alguém falar do tempo. Que é, pois, o tempo? Se ninguém me pergunta, eu sei; mas se quiser explicar a quem indaga, já não sei. Contudo, afirmo com certeza e sei que, se nada passasse, não haveria tempo passado; que se não houvesse os acontecimentos, não haveria tempo futuro; e que se nada existisse agora, não haveria tempo presente. Como então podem existir esses dois tempos, o passado e o futuro, se o passado já não existe e se o futuro ainda não chegou? Quanto ao presente, se continuasse sempre presente e não passasse ao pretérito, não seria tempo, mas eternidade. Portanto, se o presente, para ser tempo, deve tornar-se passado, como podemos afirmar que existe, se sua razão de ser é aquela pela qual deixará de existir? Por isso, o que nos permite afirmar que o tempo existe é a sua tendência para não existir.

## CAPÍTULO XV

### Tempo longo, tempo breve

 No entanto, dizemos que o tempo é longo ou breve, o que só podemos dizer do passado e do futuro. Chamamos longo, digamos, os cem anos passados, e longo também os cem anos posteriores ao presente; um passado curto para nós, seriam os dez dias anteriores a hoje, e breve futuro, os dez dias seguintes. Mas como pode ser longo ou curto o que não existe? O passado não existe mais e o futuro não existe ainda. Por isso não deveríamos dizer "o passado é longo" – mas o passado "foi longo" – e o futuro "será longo".

 Senhor, que és a minha luz, tua verdade não escarnecerá também nisso o homem? Esse tempo passado, foi longo quando já havia passado ou quando ainda estava presente? Porque ele só podia ser longo enquanto existia alguma coisa que pudesse ser longa. Mas uma vez passado, não existia mais: donde se conclui que não podia ser longo, porque já deixara de existir. Não digamos, portanto: "O tempo passado foi longo" – pois não encontraremos nada que pudesse ter sido longo; uma vez passado não existe mais. Mas digamos: "O tempo presente foi longo" – porque só era longo enquanto presente. Ainda não havia passado, ainda não havia deixado de existir, e por isso era susceptível de ser longo. Mas logo que passou, deixou de ser longo, porque cessou de existir.

 Mas vejamos, ó alma humana, se o tempo presente pode ser longo, porque foi-te dada a prerrogativa de perceber e medir os momentos. Que me respondes? Por acaso cem anos presentes são um tempo longo? Consideremos antes se cem anos podem ser presentes. Se for o primeiro ano que corre, está presente; mas os outros noventa e nove ainda são futuros, e portanto ainda não existem. Se estamos no segundo ano, já temos um ano passado, o segundo presente e todos os outros no futuro. Desse período de cem anos, seja qual for o ano que supomos presente, todos os que o precederam serão passados, e todos os que estão por vir, futuros. Portanto, os cem anos não podem estar simultaneamente presentes.

 Vejamos agora se, pelo menos, o ano em curso é presente. Se estamos no primeiro mês, os outros são futuros. Como acima, se estamos no segundo, o primeiro será passado, e os demais, futuros. Assim o ano que corre não está todo presente; e como não está todo presente, não é portanto verdade dizer-se que o ano esteja presente. Um ano compõe-se de doze meses, e seja qual for o mês considerado, será o único em curso. Mas o mês em curso não é presente, mas somente o dia. Vale o que dissemos antes: se estamos no primeiro dia, todos os outros são futuros; se estamos no último, todos os outros são passados; se estamos entre um desses dois dias, esse dia está entre os dias passados e os futuros.

 Eis, portanto, esse tempo presente, o único que julgávamos poder chamar de longo, reduzido ao espaço de um só dia. Mas, examinemos esse único dia, porque nem mesmo ele é todo presente. Compõe-se de dia e noite, num total de vinte e quatro horas; relativamente à primeira hora, todas as outras são futuras; em relação à última hora, todas as outras são passadas; cada hora intermediaria tem atrás de si horas passadas e diante de si horas futuras. Mas também essa única hora é composta de fugitivos instantes; tudo o que dela correu é passado, e tudo o que ainda lhe resta é futuro.

 Se pudermos conceber um lapso de tempo que não possa ser subdividido em frações, por menores que sejam, só essa fração poderá ser chamada de presente, mas sua passagem do futuro para o passado seria tão rápida, que não teria nenhuma duração. Se a tivesse, dividir-se-ia em passado e futuro, mas o presente não em duração alguma.

 Qual seria pois, o tempo que podemos chamar de longo? Seria acaso o futuro? mas nós não dizemos que o futuro é longo, porque ainda não existe, e por isso não pode ser longo. Dizemos: "Será longo". E quando se dará? Se atualmente ele ainda está no porvir, não pode ser longo: não existindo ainda, não pode ser longo. Mas somente poderá ser longo na hora em que emergir do futuro, que ainda não existe, em que começar a ser e a se tornar presente, de modo que possa ser longo. Nesse caso o presente nos clama, pelo que acima dissemos, que ele não pode ser longo.

## CAPÍTULO XVI

### A medida do presente

 E, contudo, Senhor, percebemos os intervalos de tempos, os comparamos entre si, e dizemos que uns são mais longos e outros mais breves. Medimos também o quanto uma duração é maior ou menor que outra, e respondemos que esta é o dobro ou o triplo de outra; que aquela é simples, ou que ambas são iguais. Mas é o tempo que passa que medimos quando o percebemos passar. Quanto ao passado, que não existe mais, e o futuro que não existe ainda, quem poderá medi-los, a menos que ouse afirmar que o nada pode ser medido? Assim, quando o tempo passa, pode ser percebido e medido. Porém quando já decorreu, ninguém o pode mentir ou sentir, porque já não existe.

## CAPÍTULO XVII

### O passado e o presente

 Pai, apenas pergunto, não estou afirmando; meu Deus, ajuda-me, dirige-me. Quem ousaria afirmar que não existe três tempos, como aprendemos na infância e como ensinamos às crianças, o passado, o presente e o futuro? será que só o presente existe, porque os demais, o passado e o futuro, não existem? Ou será que eles também existem, e então o presente provém de algum lugar oculto, quando de futuro se torna presente, e também se retira para outro esconderijo, quando de presente se torna passado? E os que predisseram o futuro, onde o viram, se ele ainda não existe? É impossível ver-se o que não existe. E os que narram o passado diriam mentiras se não vissem os acontecimentos com o espírito. Ora, se esse passado não tivesse existência alguma, seria absolutamente impossível vê-lo. Por conseguinte, o futuro e o passado também existem.

## CAPÍTULO XVIII

### As previsões

 Permite-me, Senhor, que eu leve adiante minhas investigações, tu que és minha esperança; faze que minha tentativa não seja perturbada. Se o futuro e o passado existem, quero saber onde estão. Se ainda não posso compreender, sei todavia que, onde quer que estejam, não existem nem como futuro, nem como passado, mas apenas como presente. Se também ali estiver enquanto futuro, então ainda não existirá; se o passado aí estiver como passado, já não estará lá. Portanto, no lugar e no modo que estiverem, só podem existir como presentes. Quando relatamos acontecimentos verídicos do passado, o que vêm à nossa memória não são os fatos em si, que já deixaram de existir, mas as palavras que exprimem as imagens dos fatos, que, através de nossos sentidos, gravaram em nosso espírito suas pegadas. Minha infância, por exemplo, que não existe mais, pertence a um passado que também desapareceu; mas quando eu a evoco e passo a relatá-la, vejo suas imagens no presente, imagens que ainda estão na minha memória. E a predição do futuro, meu Deus, seguiria um processo análogo? Os fatos que ainda não existem, serão representados antecipadamente em nosso espírito como imagens já existentes? Eu o ignoro. O que sei é que habitualmente premeditamos nossas ações futuras, e que essa premeditação pertence ao presente, enquanto esta começará a existir, pois então não será mais futura, mas presente.

 Seja qual for a natureza desse misterioso pressentimento do futuro, o certo é que apenas se pode ver aquilo que existe. Ora, o que já existe não é futuro, mas presente. Quando se diz que se vê o futuro, o que se vê não são os fatos futuros em si, que ainda não existem porque são futuros, mas suas causas ou talvez sinais prognósticos, causas e sinais que já existem. Estes não são pois futuros, mas presentes para os que as vêem, e é graças aos vaticínios que o futuro é concebido pelo espírito e profetizado. Esses conceitos já existem, e os que predizem o futuro vêem-nos presentes em si mesmos.

 Gostaria de apelar para um exemplo tomado entre os muitos possíveis. Vejo a aurora, e prognostico o nascimento do sol. O que vejo é presente, o que anuncio é futuro. Não o sol, que já existe, mas seu surgimento, que ainda não ocorreu. Contudo, se eu não tivesse uma imagem mental desse surgimento, como agora quando falo dele, ser-me-ia impossível a previsão. Mas essa aurora que vejo não é o nascimento do sol, embora o preceda; nem o é tampouco a imagem que trago em meu espírito. As duas coisas estão presentes, eu as vejo, e assim posso predizer o que vai acontecer. O futuro, portanto, ainda não existe; se ainda não existe, não existe no agora; e se não existe não pode ser visto de modo algum, mas pode ser prognosticado pelos sinais presentes, que já existem e podem ser vistos.

## CAPÍTULO XIX

### Oração

 Mas tu, que és soberano sobre tuas criaturas, de que modo ensinas às almas os fator porvir, como revelas aos teus profetas? De que modo ensinas o futuro, tu, para quem o futuro não existe? Ou antes, como ensinas os sinais presentes dos fatos futuros? Pois, o que ainda não existe não pode ser ensinado. O teu modo misterioso de agir está muito acima de minha inteligência, sobrepuja minhas forças. Por mim mesmo eu não o poderia alcançar, mas podê-lo-ei por ti, quando me concederes, ó doce Luz dos olhos de minha alma!

## CAPÍTULO XX

### Conclusão

 O que agora parece claro e evidente para mim é que nem o futuro, nem o passado existem, e é impróprio dizer que há três tempos: passado, presente e futuro. Talvez fosse mais correto dizer: há três tempos: o presente do passado, o presente do presente e o presente do futuro. E essas três espécies de tempos existem em nossa mente, e não as vejo em outra parte. O presente do passado é a memória; o presente do presente é a percepção direta; o presente do futuro é a esperança.

 Se me é lícito falar assim, vejo e confesso que há três tempos. Diga-se também que são três os tempos: presente, passado e futuro, como abusivamente afirma o costume. Não me importo, nem me oponho, nem critico o modo de falar, desde que fique bem entendido o que se diz, e que não se acredite que o futuro já existe e que o passado ainda existe. Uma linguagem que expresse com termos exatos é incomum: com muita freqüência falamos com impropriedade, mas entende-se o que queremos dizer.

## CAPÍTULO XXI

### A medida do tempo

 Disse há pouco que medimos o tempo que passa; de modo que podemos afirmar que um lapso de tempo é o dobro de outro, ou igual, e apontar entre os intervalos de tempo outras relações, mediante esse processo comparativo. Portanto, como eu dizia, medimos o tempo no momento em que passa. E se me perguntarem: Como o sabes? – eu responderia: Sei porque o medimos, e porque é impossível medir o que não existe; ora, o passado e o futuro não existem. Quanto ao presente, como podemos medi-lo, se não tem duração? Portanto, só podemos medi-lo enquanto passa; e quando passou, não o medimos mais, porque não há mais nada a mentir.

 Mas de onde se origina, por onde passa, para onde vai o tempo quando o medimos? De onde vem senão do futuro? Por onde passa, senão pelo presente? Para onde vai senão para o passado? Nasce pois do que ainda não existe, atravessa o que não tem duração, e corre para o que não existe mais. No entanto, o que é que medimos, senão o tempo relacionado ao espaço? Quando dizemos de um tempo que é simples, duplo, ou triplo, ou igual, ou quando formulamos qualquer outra relação dessa espécie, nada mais fazemos do que medir espaços de tempo. Em que espaço medimos então o tempo no momento em que passa? No futuro, talvez, donde procede? Mas o que ainda não existe não pode ser medido. Será no presente, por onde ele passa? Mas, como medir o que não tem extensão? Será no passado, para onde caminha? Mas o que não existe mais escapa à qualquer medida.

## CAPÍTULO XXII

### O enigma

 Minha alma se inflama no desejo de deslindar este enigma tão complicado! Senhor, meu Deus, meu bom Pai, eu to suplico por Cristo; não queiras tolher a meu desejo a solução de tais problemas, tão familiares mas tão obscuros; permite que eu os penetre, e faze com que a luz de tua misericórdia os ilumine, Senhor! A quem poderia eu consultar sobre isso? A quem confessaria minha ignorância com mais proveito do que a ti, que não se despraz com o forte zelo que me inflama por tuas Escrituras? Concede-me o que amo, pois este amor é um dom teu. Dá-me, ó Pai, esta graça, tu que sabes presentear com boas dádivas a teus filhos. Concede-me essa luz, porque determinei conhecê-las, e meu esforço será rude até que me reveles esses mistérios. Eu to suplico, por Cristo, em nome do Santo dos Santos, que ninguém perturbe minha investigação. Acreditei, e por isso falo. Minha esperança, a esperança pela qual vivo, é contemplar as delícias do Senhor. Eis que tornaste velhos os meus dias, e eles passam, não sei como.

 Nós só falamos de tempo, e de tempo, e de tempos e de tempos. Quanto tempo esse homem falou? Quanto tempo demorou para fazê-lo? Há quanto tempo não vejo isto! A duração desta sílaba é o dobro daquela, que é breve. Assim nos expressamos e assim ouvimos, e todos nos compreendem, e nós compreendemos. São palavras claras e de uso corrente, mas encerram mistérios, e compreendê-las requer melhor análise.

## CAPÍTULO XXIII

### O tempo e o movimento

 Ouvi um homem instruído dizer que o tempo é nada mais do que o movimento do sol, da lua e dos astros. Não concordo. Por que não seria então o tempo o movimento de todos os corpos? Se os astros passassem, e a roda de um oleiro continuasse a rodar, deixaria acaso de existir tempo para medir suas voltas? Como poderíamos dizer que elas se davam a intervalos iguais, ou ora mais rápida, ora mais lentamente, e que umas demoravam mais e outras menos? E, dizendo isto, não estaríamos falando do tempo? Não haveria mais em nossas palavras sílabas longas e breves, porque umas ressoam por mais tempo e outras por menos tempo?

 E tu, Deus, concede aos homens que percebam, que reconheçam neste modesto exemplo, o que as coisas grandes e pequenas têm em comum. Há astros e luminares celestes que nos servem de sinais e marcam as estações, os dias e os anos. Isso é verdade; todavia, como eu jamais diria que a volta realizada por aquela roda de madeira representa o dia, nem o sábio cuja opinião transcrevo poderia afirmar que a volta da roda não representa o tempo.

 O meu desejo é conhecer a natureza e a essência do tempo, com que medimos os movimentos dos corpos, e nos autoriza a dizer, por exemplo, que um movimento dura duas vezes mais que outro. O que chamamos de dia não é apenas o tempo todo o percurso de oriente a oriente, e que nos faz dizer: "Passaram-se tantos dias" – entendendo por isso também as noites, que não são enumeradas separadamente. Portanto, já que o dia se completa pelo movimento do sol e o círculo que ele cumpre a partir do oriente, pergunto eu se o dia é o próprio movimento ou se é o tempo que dura esses movimentos, ou ambas as coisas.

 Na primeira hipótese, teríamos um dia mesmo se o sol fizesse seu percurso no intervalo de uma hora. Na hipótese da duração, não haveria dia se o sol fizesse seu percurso no breve espaço de uma hora; e o sol deveria cumprir vinte e quatro vezes seu percurso para formar um dia. Diremos então que o movimento do sol, e a duração desse movimento, é que fazem o dia? Mas então não se poderia chamar de dia se o sol efetuasse seu percurso no lapso de uma hora, mais do que se, parando o sol seu percurso, passasse o mesmo tempo que é necessário habitualmente ao sol para completar sua revolução de uma manhã a outra.

 Portanto, não mais buscarei conhecer em que consiste o dia, mas em que consiste o tempo, que usamos para medir o percurso do sol. Usando tal medida, diríamos que o sol gastara em seu giro a metade do tempo habitual , se o tivesse completado em um lapso de doze horas. E, comparando essas duas durações, diríamos que uma é o dobro da outra, mesmo que o sol demorasse umas vezes o tempo simples, outras o tempo duplo para ir de oriente para oriente.

 Ninguém, portanto, me diga que o tempo é o movimento dos corpos celestes. Quando a oração de um homem fez parar o sol para concluir vitoriosamente a batalha, o sol estava imóvel, mas o tempo caminhava; e a batalha terminou no espaço de tempo que lhe era necessário.

 Veja, pois, que o tempo é uma espécie de extensão. Mas eu o vejo, ou apenas tenho a impressão de vê-lo? Só tu mo demonstrarás, ó Luz, ó Verdade!

## CAPÍTULO XXIV

### O tempo, medida do movimento

 Queres que eu aprove a quem diz que o tempo é o movimento de um corpo? Não, não aprovo. Sei que não há corpo que não se mova no tempo: tu mesmo o afirmas. Mas não acredito que o movimento de um corpo seja o tempo; isso nunca ouvi, e nem tu o dizes. Quando um corpo se move, sirvo-me do tempo para medir a duração de seu movimento do começo ao fim. Se não vejo o começo, e percebo seu movimento sem ver seu fim, só posso medi-lo do momento em que observo o corpo mover-se até o momento em que já não o vejo. Se o vejo por muito tempo, apenas posso afirmar que a duração de seu movimento é longa, mas não posso dizer quanto é longa, porque só determinamos o valor de uma duração comparando-a. Dizemos, por exemplo: "isso durou tanto quanto aquilo, ou essa duração é o dobro daquela", semelhantes. Se podemos notar o ponto do espaço onde se inicia um movimento, e o ponto de chegada, ou suas partes, se ele se movesse em círculo, poderíamos dizer quanto tempo levou para ir de um ponto a outro o movimento do corpo ou dessas partes.

 Assim, o movimento de um corpo é diferente da medida de sua duração; que não vê, pois, a qual dessas coisas se deve chamar de tempo? Se um corpo se move de forma irregular, e outras vezes se detém, ora, é o tempo que nos permite medir, não apenas seu movimento, mas também seu repouso, e afirmar: "Ficou em repouso por tanto tempo quanto em movimento – ou qualquer outro intervalo que tenhamos calculado ou estimado aproximadamente". O tempo não é pois a mesma coisa que o movimento.

## CAPÍTULO XXV

### Prece

 Confesso-te, Senhor, que ainda não sei o que é tempo. E torno a confessar, Senhor, eu o sei, que digo estas coisas no tempo, e que de há muito estou falando do tempo, e que esse muito também não seria o que é senão pela duração do tempo. Mas como posso saber isto, se desconheço o que é o tempo? Talvez eu ignore a arte de exprimir o que sei. Ai de mim, que não sei nem mesmo o que ignoro! Eis-me diante de ti, meu Deus, tu vês que não minto e que falo de coração. Acenderás minha candeia, Senhor meu Deus, e iluminarás minhas trevas.

## CAPÍTULO XXVI

### O tempo, distensão da alma

 Acaso minha alma não foi sincera confessando-te que posso medir o tempo? De fato, meu Deus, eu o meço, e não sei o que meço. Meço o movimento dos corpos com o auxílio do tempo, e não poderei medir o tempo do mesmo modo? E poderia eu medir o movimento de um corpo, sua duração, o tempo que gasta para ir de um lugar a outro, sem medir o tempo em que se move?

 Mas o tempo em si, com que o poderei medir? É com um tempo mais curto que medimos um mais longo, como medimos uma viga com o côvado? Do mesmo modo medimos a duração de uma sílaba longa com a duração de uma sílaba breve, dizendo que uma é o dobro da outra. Do mesmo modo medimos a extensão de um poema pelo número de versos, a extensão dos versos pelo número de pés, a extensão dos pés pelo número de sílabas, a duração das sílabas longas pela duração das breves. Não é pelas páginas dos livros que fazemos esse cálculo, o que seria medir o espaço e não o tempo. Conforme as palavras passam e as pronunciamos, dizemos: "Eis um poema longo, porque se compõe de tantos versos; esses versos são longos, porque são formados de tantos pés; esses pés são longos, porque se estendem por tantas sílabas; esta sílaba é longa, porque é o dobro de uma breve".

 Todavia, não conseguimos uma medida exata do tempo; pode acontecer que um verso mais curto, se pronunciado mais lentamente, se estenda por mais tempo que um verso mais longo, recitado depressa. O mesmo acontece com um poema, um pé, uma sílaba.

 Por esse motivo é que o tempo me pareceu não ser nada mais que uma extensão. Mas extensão de que? Não saberia dize-lo ao certo; seria de admirar que não fosse extensão da própria alma. portanto, dize-me , meu Deus, que é o que meço quando digo um tanto vagamente: "Este tempo é mais longo do que aquele" – ou mais exatamente: "Este tempo é o dobro daquele? – Meço o tempo, eu o sei; mas não o futuro, que ainda não existe, nem o presente, porque não tem duração, nem o passado, porque não existe mais. Que meço eu então? Acaso o tempo que passa, e não o tempo passado, como disse acima?

## CAPÍTULO XXVII

### A medida do passado

 Insiste, ó minha alma, e presta grande atenção: Deus é nosso apoio. Ele é que nos criou, e não nós. Olha para lá, par o lado onde desponta a aurora da verdade.

 Eis, por exemplo, que uma voz corpórea começa a ressoar, e soa, e continua vibrando e deixar de soar; faz-se silencio, a voz calou-se, passou e deixa de existir. Antes de soar, era futura, e não podia ser medida, pois ainda não existia; e agora também não o pode, porque já não existe mais. Só poderíamos medi-la quando ressoava, porque então havia o que medir. Mas mesmo então não era estável, porque vinha e passava. E não seria isso que a tornava mensurável? Porque enquanto passava, estendia-se por um espaço de tempo que a tornava capaz de ser medida, porque o presente não tem duração alguma.

 Admitamos que foi possível medi-la; eis, suponhamos agora, uma outra voz que começa a se fazer ouvir; ela vibra de modo contínuo, sem nenhuma interrupção. Meçamo-la enquanto vibra, porque no momento em que deixar de vibrar será passada, e já não poderá ser medida. Meçamola, então, e avaliemos sua duração. Mas ela vibra ainda, e só pode ser medida depois do início do fenômeno, quando começa a vibrar, até seu fim, quando deixa de vibrar. Porque é precisamente o intervalo que separa um começo de um fim que nós medimos. Por isso, uma voz, que ainda não terminou de ressoar, escapa à medida: é impossível dizer se ela será longa ou breve, se é igual a outra, simples ou dupla, ou qual a relação que tem com essa outra. Mas quando terminar de soar, deixará de existir. Como, então, poderemos medi-la?

 De fato, medimos o tempo; mas não o tempo que ainda não existe, nem o que já não existe, nem o que não tem duração alguma, nem o que está passando. Não é, portanto, nem o futuro, nem o passado, nem o presente, nem o que não tem limites que medimos: e, contudo, medimos o tempo.

Deus creator omnium (Deus, criador de tudo quanto existe): este verso é formado de oito sílabas, alternativamente breves e longas. As quatro breves, a primeira, a terceira, a quinta e a sétima – são simples em relação às quatro longas: a segunda, a quarta, a sexta e a oitava. Cada sílaba longa tem uma duração duas vezes maior que a breve. Eu pronuncio e percebo que é assim pelo testemunho claro de meus sentidos. E por esta testemunho que é fidedigno, meço uma longa por uma breve, e noto que ela a contém duas vezes.

 Mas como uma sílaba só se faz ouvir depois da outra, se a breve vem primeiro, e a longa a seguir, como poderei reter a breve, como aplicá-la à longa, para compará-las e ver que esta contém aquela duas vezes, uma vez que a longa só começa a soar quando a breve deixou de se ouvir? E a própria sílaba longa, não me é possível medi-la enquanto está soando, porque eu só poderia medi-la quando se calasse. Mas ela, ao terminar, passou. Que é pois que eu meço? Onde está a breve, que seria minha medida? Onde está a longa, que meço? Apenas vibraram, foramse, passaram, e não existem mais. Não obstante, eu as meço e respondo com a segurança que me pode dar um sentido bem educado, que evidentemente uma é de duração simples e a outra dupla. Mas só poderei fazê-lo depois que ambas passaram e terminaram.

 Logo, eu não meço as sílabas, que não existem mais, mas algo que permanece gravado em minha memória.

 É em ti, meu espírito, que meço o tempo. Não me objetes nada, pois é assim. Não te perturbes com as ondas desordenadas de tuas emoções. É em ti, digo, que meço o tempo. A impressão que em ti gravam as coisas em sua passagem, perduram ainda depois que os fatos passam. O que eu meço é esta impressão presente, e não as vibrações que a produziram e se foram. É ela que meço quando meço o tempo. Portanto, ou essa impressão é o tempo, ou eu não meço o tempo.

 Mas quando medimos silêncios, e dizemos que o silêncio teve a mesma duração que certa palavra, não estamos dirigindo nossa atenção para a medida dessa palavra, como se ainda pudéssemos ouvi-la, para podermos avaliar no espaço de tempo, o intervalo do silêncio? Com efeito, por vezes, sem abrir a boca ou dizer palavra, fazemos mentalmente poemas, versos, discursos; avaliamos a extensão do seu movimento, sua duração, uns em relação aos outros, exatamente como se usássemos a voz.

 Se alguém quisesse pronunciar um som prolongado, e regular antecipadamente, em pensamento, sua duração, estima em silêncio a medida dessa duração e, confiando à memória, começa a emitir o som, que vibra até atingir o limite fixado. Ou melhor: esse som vibrou e vibrará, porque a parte que passou soou; a que ainda resta, soará e chegará a seu fim. A atenção presente vai lançando o futuro para o passado, e o passado cresce com a diminuição do futuro, até que, esgotado o futuro, não haja mais que passado.

## CAPÍTULO XXVIII

### A medida do futuro

 Mas o futuro, que ainda não existe, como pode diminuir ou consumir-se? E o passado, que já não existe, como pode aumentar, a não se por existirem no espírito, autor dessas três transformações: a espera, a atenção e a lembrança? O objeto de sua espera passa pela atenção e se transforma em lembrança.

 De fato, quem ousará negar que o futuro ainda não existe? Todavia, a espera do futuro já está no espírito. E quem poderá negar que o passado não mais existe? Contudo, a lembrança do passado ainda está no espírito. Enfim, haverá alguém que negue que o presente carece de duração, porque é um instante que passa? No entanto, perdura a atenção, diante da qual o seu objeto presente continuamente se retira. O futuro, portanto, não é longo, porque não existe. Um futuro longo seria apenas uma longa espera do futuro. nem pode ser longo o passado, que também não existe. Um passado longo é uma longa lembrança do passado.

 Digamos que eu queira cantar uma canção que conheço: antes de iniciar, minha expectativa se estende pela melodia como um todo. Quando começo, tudo o que vira passado é armazenada na memória. A atividade de meu espírito se divide em memória, onde guardo o que já disse, e em expectativa em relação ao que vou dizer. Contudo, a atenção está presente, e por seu intermédio o futuro se torna passado. Quanto mais se aproxima o fim da canção, tanto menos se torna a expectativa e tanto maior a memória, até que aquela se esgota e a ação cumprida passa inteiramente para a memória.

 E o que acontece com a canção tomada em seu conjunto, também ocorre com cada uma de suas partes, com cada sílaba; e também acontece com uma ação mais longa, da qual essa melodia talvez faça parte. O mesmo acontece com toda a vida do homem, da qual seus atos são partes. Sucede, enfim, com toda a história dos filhos do homem, da qual cada existência é apenas uma parte.

## CAPÍTULO XXIX

### A eternidade de Deus

 Mas porque tua misericórdia é superior a todas as vidas, e eis que minha vida não é mais que distensão, e tua destra me acolheu em meu Senhor, o Filho do homem, mediador entre ti, que és uno, e nós, que somos muitos e vivemos divididos por diversas paixões. Assim. Por ele me unirei àquele, que por ele se uniu a nós, e liberto dos antigos dias, recolherei meu ser seguindo tua Unidade. Esquecido do passado, sem me preocupar com as coisas futuras e transitórias, atento apenas àquilo que é eterno, não com dispersão mas com todas as minhas forças buscarei a palma da vocação celeste, onde ouvirei a voz de teu louvor, e onde contemplarei tua alegria, que não conhece futuro nem passado.

 Agora, porém, meus anos transcorrem em lamentos, e tu, meu consolo, ó Senhor, meu Pai, tu és eterno. Mas eu me dispersei no tempo, cuja ordem ignoro; tumultuosas vicissitudes despedaçam meus pensamentos, entranhas de minha alma, até o dia em que, purificado pelo fogo de teu amor, me una a ti.

## CAPÍTULO XXX

### Deus e o tempo

 E repousarei imutável em ti, em tua verdade, na minha forma. não mais tolerarei as perguntas das pessoas que, pela enfermidade que é a pena de seu pecado, tem mais sede de saber do que lhes permite sua capacidade, que dizem: "Que fazia Deus antes de criar o céu e a terra?" – ou ainda: "Como lhe veio a idéia de criar algo, se antes nunca fizera nada" – Concedelhes, Senhor, que reflitam no que dizem, que compreendam que não se pode falar nunca onde não há tempo. Quando se diz que alguém nunca fez nada, que se quer dizer senão que esse tal nada fez em tempo algum? Que eles compreendam que não pode existir tempo na ausência da criação, e deixem de semelhantes falácias.

 Que também atentem para o que têm diante de si, para compreender que tu, antes de todos os tempos, és o Criador eterno de todos os tempos, e que nenhum tempo te é coeterno, nem criatura alguma, embora algumas estejam acima dos tempos (Agostinho se refere aqui, aos anjos e demônios).

## CAPÍTULO XXXI

### Conclusão

 Senhor, meu Deus, que abismos profundos os de teus segredos, e quão longe deles me levaram as conseqüências de meus pecados! Cura meus olhos, para que eu me alegre com tua luz!

 Se houvesse de fato um espírito de ciência e de presciência tão grandes para conhecer o passado e o futuro, como conheço qualquer canto popular, esse espírito nos encheria de extraordinária admiração e espanto. Nada, com efeito, lhe seria oculto no passado e nos séculos vindouros, exatamente como, ao entoar essa melodia, sei tudo o que cantei desde o começo, e tudo o que falta cantar até o fim. Mas longe de mim a idéia de identificar um tal conhecimento àquele que tens de todas as coisas futuras e passadas, ó Criador do Universo, Criador dos espíritos e dos corpos. Tua ciência é incomparavelmente mais admirável e mais misteriosa. Porque aquele que canta ou escuta uma melodia conhecida, dividido entre a expectativa das notas por vir e a lembrança das notas passadas, passa por impressões diferentes. Mas contigo não se dá nada semelhante, tu que és imutável e eterno, Criador verdadeiramente eterno dos espíritos. Como no princípio, conheceste o céu e a terra, sem que teu espírito mudasse seu saber, assim criaste o céu e a terra, sem que tua ação passasse por etapas distintas. Que aquele que compreende isto te louve, assim como o que não compreende. Oh! Como és sublime! E os de coração humildes são tua morada! Levantas os que caíram, e os que graças a ti continuam eretos, não caem nunca.