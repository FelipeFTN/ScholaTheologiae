## CAPÍTULO XIX

### Oração

 Mas tu, que és soberano sobre tuas criaturas, de que modo ensinas às almas os fator porvir, como revelas aos teus profetas? De que modo ensinas o futuro, tu, para quem o futuro não existe? Ou antes, como ensinas os sinais presentes dos fatos futuros? Pois, o que ainda não existe não pode ser ensinado. O teu modo misterioso de agir está muito acima de minha inteligência, sobrepuja minhas forças. Por mim mesmo eu não o poderia alcançar, mas podê-lo-ei por ti, quando me concederes, ó doce Luz dos olhos de minha alma!