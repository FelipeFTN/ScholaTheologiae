## CAPÍTULO XVI

### A medida do presente

 E, contudo, Senhor, percebemos os intervalos de tempos, os comparamos entre si, e dizemos que uns são mais longos e outros mais breves. Medimos também o quanto uma duração é maior ou menor que outra, e respondemos que esta é o dobro ou o triplo de outra; que aquela é simples, ou que ambas são iguais. Mas é o tempo que passa que medimos quando o percebemos passar. Quanto ao passado, que não existe mais, e o futuro que não existe ainda, quem poderá medi-los, a menos que ouse afirmar que o nada pode ser medido? Assim, quando o tempo passa, pode ser percebido e medido. Porém quando já decorreu, ninguém o pode mentir ou sentir, porque já não existe.