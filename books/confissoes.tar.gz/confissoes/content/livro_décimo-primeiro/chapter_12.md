## CAPÍTULO XII

### Deus antes da criação

 Eis minha resposta à questão: "Que fazia Deus antes de criar o céu e a terra?" – não responderei jocosamente como alguém para contornar a dificuldade do problema: "Preparava o inferno para os que perscrutam esses mistérios profundos". – Uma coisa é compreender e outra é brincar. Não, essa não será minha resposta. Prefiro dizer: "Não sei" – pois de fato não sei, que ridicularizar quem faz pergunta tão profunda, ou louvar quem responde com sofismas.

 Mas eu digo que tu, meu Deus, és o Criador de toda criatura; e, se por céu e terra se entende toda criatura, não temo afirmar: "Antes que Deus criasse o céu e a terra, nada fazia. De fato, se tivesse feito alguma coisa, o que poderia ser senão uma criatura? Oxalá eu soubesse tudo o que desejo saber, como sei que nenhuma criatura foi criada antes da criação.