## CAPÍTULO XX

### Conclusão

 O que agora parece claro e evidente para mim é que nem o futuro, nem o passado existem, e é impróprio dizer que há três tempos: passado, presente e futuro. Talvez fosse mais correto dizer: há três tempos: o presente do passado, o presente do presente e o presente do futuro. E essas três espécies de tempos existem em nossa mente, e não as vejo em outra parte. O presente do passado é a memória; o presente do presente é a percepção direta; o presente do futuro é a esperança.

 Se me é lícito falar assim, vejo e confesso que há três tempos. Diga-se também que são três os tempos: presente, passado e futuro, como abusivamente afirma o costume. Não me importo, nem me oponho, nem critico o modo de falar, desde que fique bem entendido o que se diz, e que não se acredite que o futuro já existe e que o passado ainda existe. Uma linguagem que expresse com termos exatos é incomum: com muita freqüência falamos com impropriedade, mas entende-se o que queremos dizer.