## CAPÍTULO VII

### A palavra coeterna

 É assim que nos convidas a compreender o Verbo, que é Deus junto de ti, que também és Deus, Verbo pronunciado eternamente e pelo qual tudo é pronunciado eternamente. O que é dito, não é uma seqüência de palavras, ou uma palavra que é seguida por outra, como que a concluir uma frase; mas tudo é dito simultânea e eternamente. Do contrário, já haveria tempo e mudança, e não a verdadeira eternidade nem a verdadeira imortalidade.

 Isto eu o sei, meu Deus, e por isso te dou graças. Eu o sei, e eu to confesso, Senhor; e também o sabe todo aquele que não é ingrato à infalível verdade. Sabemos, Senhor, sabemos que não ser mais depois de ter existido, ou passar a ser quando ainda não se existia é o morrer e o nascer. Mas em teu Verbo, por ser verdadeiramente imortal e eterno, nada desaparece nem tem sucessão. Com o teu Verbo que é coeterno, enuncias eternamente e a um só tempo tudo o que dizes. E o que se realiza é o que dizes que se faça. Não é de outro modo, senão pelo Verbo, que crias. Todavia os seres criados por tua palavra não chegam à existência simultaneamente, desde toda a eternidade.