### Capítulo V - O caminho da morte

1 Este é o caminho da morte: primeiro, é mau e cheio de maldições - homicídios, adultérios, paixões, fornicações, roubos, idolatria, magias, feitiçarias, rapinas, falsos testemunhos, hipocrisias, coração com duplo sentido, fraudes, orgulho, maldades, arrogância, avareza, palavras obscenas, ciúmes, insolência, altivez, ostentação e falta de temor de Deus.

2 Nesse caminho trilham os perseguidores dos justos, os inimigos da verdade, os amantes da mentira, os ignorantes da justiça, os que não desejam o bem nem o justo julgamento, os que não praticam o bem mas o mal.
A calma e a paciência estão longe deles.
Estes amam as coisas vãs, são ávidos por recompensas, não se compadecem com os pobres, não se importam com os perseguidos, não reconhecem o Criador.
São também assassinos de crianças, corruptores da imagem de Deus, desprezam os necessitados, oprimem os aflitos, defendem os ricos, julgam injustamente os pobres e, finalmente, são pecadores consumados.
Filho, afaste-se disso tudo.