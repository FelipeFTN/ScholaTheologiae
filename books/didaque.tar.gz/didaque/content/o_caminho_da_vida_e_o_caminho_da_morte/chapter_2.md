### Capítulo II - Mandamentos

1 O segundo mandamento da instrução é:

2 Não mate, não cometa adultério, não corrompa os jovens, não fornique, não roube, não pratique a magia nem a feitiçaria.
Não mate a criança no seio de sua mãe e nem depois que ela tenha nascido.

3 Não cobice os bens alheios, não cometa falso juramento, nem preste falso testemunho, não seja maldoso, nem vingativo.

4 Não tenha duplo pensamento ou linguajar pois o duplo sentido é armadilha fatal.

5 A sua palavra não deve ser em vão, mas comprovada na prática.

6 Não seja avarento, nem ladrão, nem fingido, nem malicioso, nem soberbo.
Não planeje o mal contra o seu próximo.

7 Não odeie a ninguém, mas corrija alguns, reze por outros e ame ainda aos outros, mais até do que a si mesmo.