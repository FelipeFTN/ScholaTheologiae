### Capítulo VI - Instrução sobre alimentos

1 Fique atento para que ninguém o afaste do caminho da instrução, pois quem faz isso
ensina coisas que não pertencem a Deus.

2 Você será perfeito se conseguir carregar todo
o jugo do Senhor. Se isso não for possível, faça o que puder.

3 A respeito da comida,
observe o que puder. Não coma nada do que é sacrificado aos ídolos pois esse culto é
destinado a deuses mortos.