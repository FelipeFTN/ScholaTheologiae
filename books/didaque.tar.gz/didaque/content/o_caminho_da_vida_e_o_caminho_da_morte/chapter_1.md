### Capítulo I - O caminho da vida

1 Existem dois caminhos: o caminho da vida e o caminho da morte. Há uma grande
diferença entre os dois.

2 Este é o caminho da vida: primeiro, ame a Deus que o criou;
segundo, ame a seu próximo como a si mesmo. Não faça ao outro aquilo que você não
quer que façam a você.

3 Este é o ensinamento derivado dessas palavras: bendiga
aqueles que o amaldiçoam, reze por seus inimigos e jejue por aqueles que o perseguem.
Ora, se você ama aqueles que o amam, que graça você merece? Os pagãos também não
fazem o mesmo? Quanto a você, ame aqueles que o odeiam e assim você não terá
nenhum inimigo.

4 Não se deixe levar pelo instinto. Se alguém lhe bofeteia na face
direita, ofereça-lhe também a outra face e assim você será perfeito. Se alguém o obriga
a acompanhá-lo por um quilometro, acompanhe-o por dois. Se alguém lhe tira o manto,
ofereça-lhe também a túnica. Se alguém toma alguma coisa que lhe pertence, não a peça
de volta porque não é direito.

5 Dê a quem lhe pede e não peças de volta pois o Pai quer
que os seus bens sejam dados a todos. Bem-aventurado aquele que dá conforme o
mandamento pois será considerado inocente. Ai daquele que recebe: se pede por estar
necessitado, será considerado inocente; mas se recebeu sem necessidade, prestará contas
do motivo e da finalidade. Será posto na prisão e será interrogado sobre o que fez... e
daí não sairá até que devolva o último centavo.

6 Sobre isso também foi dito: que a sua
esmola fique suando nas suas mãos até que você saiba para quem a está dando.