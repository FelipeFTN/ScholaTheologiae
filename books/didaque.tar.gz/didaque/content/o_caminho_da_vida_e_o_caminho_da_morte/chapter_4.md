### Capítulo IV - Instruções para a vida cristã

1 Filho, lembre-se dia e noite daquele que prega a Palavra de Deus para você. Honre-o
como se fosse o próprio Senhor, pois Ele está presente onde a soberania do Senhor é
anunciada.

2 Procure estar todos os dias na companhia dos fiéis para encontrar forças
em suas palavras.

3 Não provoque divisão. Ao contrário, reconcilia aqueles que brigam
entre si. Julgue de forma justa e corrija as culpas sem distinguir as pessoas.

4 Não hesite
sobre o que vai acontecer.

5 Não te pareças com aqueles que dão a mão quando
precisam e a retiram quando devem dar.

6 Se o trabalho de suas mãos te rendem algo, as
ofereça como reparação pelos seus pecados.

7 Não hesite em dar, nem dê reclamando
porque, na verdade, você sabe quem realmente pagou sua recompensa.

8 Não rejeite o
necessitado. Compartilhe tudo com seu irmão e não diga que as coisas são apenas suas.
Se vocês estão unidos nas coisas imortais, tanto mais estarão nas coisas perecíveis.

9 Não se descuide de seu filho ou filha. Muito pelo contrário, desde a infância instrua-os a
temer a Deus.

10 Não dê ordens com rudeza ao seu escravo ou escrava pois eles
também esperam no mesmo Deus que você; assim, não perderão o temor de Deus, que
está acima de todos. Certamente Ele não virá chamar a pessoa pela aparência, mas
somente aqueles que foram preparados pelo Espírito.

11 Quanto a vocês, escravos,
obedeçam aos seus senhores, com todo o respeito e reverência, como à própria imagem
de Deus.

12 Deteste toda a hipocrisia e tudo aquilo que não agrada o Senhor.

13 Não
viole os mandamentos dos Senhor. Guarde tudo aquilo que você recebeu: não
acrescente ou retire nada.

14 Confesse seus pecados na reunião dos fiéis e não comece a
orar estando com má consciência. Este é o caminho da vida.