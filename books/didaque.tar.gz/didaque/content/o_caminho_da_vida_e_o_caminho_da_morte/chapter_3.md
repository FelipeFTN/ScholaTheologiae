### Capítulo III - Exortações morais

1 Filho, procure evitar tudo aquilo que é mau e tudo que se parece com o mal.

2 Não
seja colérico porque a ira conduz à morte. Não seja ciumento também, nem briguento ou
violento, pois o homicídio nasce de todas essas coisas.

3 Filho, não cobice as mulheres
pois a cobiça leva à fornicação. Evite falar palavras obscenas e olhar maliciosamente já
que os adultérios surgem dessas coisas.

4 Filho, não se aproxime da adivinhação porque
ela leva à idolatria. Não pratique encantamentos, astrologia ou purificações, nem queira
ver ou ouvir sobre isso, pois disso tudo nasce a idolatria.

5 Filho, não seja mentiroso
pois a mentira leva ao roubo. Não persiga o dinheiro nem cobice a fama porque os
roubos nascem dessas coisas.

6 Filho, não fale demais pois falar muito leva à blasfêmia.
Não seja insolente, nem tenha mente perversa porque as blasfêmias nascem dessas
coisas.

7 Seja manso pois os mansos herdarão a terra.

8 Seja paciente, misericordioso,
sem maldade, tranquilo e bondoso. Respeite sempre as palavras que você escutou.

9 Não louve a si mesmo, nem se entrege à insolência. Não se junte com os poderosos, mas
aproxima dos justos e pobres.

10 Aceite tudo o que acontece contigo como coisa boa e
saiba que nada acontece sem a permissão de Deus.