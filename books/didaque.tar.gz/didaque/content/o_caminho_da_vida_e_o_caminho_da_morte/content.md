## O caminho da vida e o caminho da morte

### Capítulo I - O caminho da vida

1 Existem dois caminhos: o caminho da vida e o caminho da morte. Há uma grande
diferença entre os dois.

2 Este é o caminho da vida: primeiro, ame a Deus que o criou;
segundo, ame a seu próximo como a si mesmo. Não faça ao outro aquilo que você não
quer que façam a você.

3 Este é o ensinamento derivado dessas palavras: bendiga
aqueles que o amaldiçoam, reze por seus inimigos e jejue por aqueles que o perseguem.
Ora, se você ama aqueles que o amam, que graça você merece? Os pagãos também não
fazem o mesmo? Quanto a você, ame aqueles que o odeiam e assim você não terá
nenhum inimigo.

4 Não se deixe levar pelo instinto. Se alguém lhe bofeteia na face
direita, ofereça-lhe também a outra face e assim você será perfeito. Se alguém o obriga
a acompanhá-lo por um quilometro, acompanhe-o por dois. Se alguém lhe tira o manto,
ofereça-lhe também a túnica. Se alguém toma alguma coisa que lhe pertence, não a peça
de volta porque não é direito.

5 Dê a quem lhe pede e não peças de volta pois o Pai quer
que os seus bens sejam dados a todos. Bem-aventurado aquele que dá conforme o
mandamento pois será considerado inocente. Ai daquele que recebe: se pede por estar
necessitado, será considerado inocente; mas se recebeu sem necessidade, prestará contas
do motivo e da finalidade. Será posto na prisão e será interrogado sobre o que fez... e
daí não sairá até que devolva o último centavo.

6 Sobre isso também foi dito: que a sua
esmola fique suando nas suas mãos até que você saiba para quem a está dando.

### Capítulo II - Mandamentos

1 O segundo mandamento da instrução é: 2 Não mate, não cometa adultério, não
corrompa os jovens, não fornique, não roube, não pratique a magia nem a feitiçaria. Não
mate a criança no seio de sua mãe e nem depois que ela tenha nascido.

3 Não cobice os
bens alheios, não cometa falso juramento, nem preste falso testemunho, não seja
maldoso, nem vingativo.

4 Não tenha duplo pensamento ou linguajar pois o duplo
sentido é armadilha fatal.

5 A sua palavra não deve ser em vão, mas comprovada na
prática.

6 Não seja avarento, nem ladrão, nem fingido, nem malicioso, nem soberbo.
Não planeje o mal contra o seu próximo.

7 Não odeie a ninguém, mas corrija alguns,
reze por outros e ame ainda aos outros, mais até do que a si mesmo.

### Capítulo III - Exortações morais

1 Filho, procure evitar tudo aquilo que é mau e tudo que se parece com o mal.

2 Não
seja colérico porque a ira conduz à morte. Não seja ciumento também, nem briguento ou
violento, pois o homicídio nasce de todas essas coisas.

3 Filho, não cobice as mulheres
pois a cobiça leva à fornicação. Evite falar palavras obscenas e olhar maliciosamente já
que os adultérios surgem dessas coisas.

4 Filho, não se aproxime da adivinhação porque
ela leva à idolatria. Não pratique encantamentos, astrologia ou purificações, nem queira
ver ou ouvir sobre isso, pois disso tudo nasce a idolatria.

5 Filho, não seja mentiroso
pois a mentira leva ao roubo. Não persiga o dinheiro nem cobice a fama porque os
roubos nascem dessas coisas.

6 Filho, não fale demais pois falar muito leva à blasfêmia.
Não seja insolente, nem tenha mente perversa porque as blasfêmias nascem dessas
coisas.

7 Seja manso pois os mansos herdarão a terra.

8 Seja paciente, misericordioso,
sem maldade, tranquilo e bondoso. Respeite sempre as palavras que você escutou.

9 Não louve a si mesmo, nem se entrege à insolência. Não se junte com os poderosos, mas
aproxima dos justos e pobres.

10 Aceite tudo o que acontece contigo como coisa boa e
saiba que nada acontece sem a permissão de Deus.

### Capítulo IV - Instruções para a vida cristã

1 Filho, lembre-se dia e noite daquele que prega a Palavra de Deus para você. Honre-o
como se fosse o próprio Senhor, pois Ele está presente onde a soberania do Senhor é
anunciada.

2 Procure estar todos os dias na companhia dos fiéis para encontrar forças
em suas palavras.

3 Não provoque divisão. Ao contrário, reconcilia aqueles que brigam
entre si. Julgue de forma justa e corrija as culpas sem distinguir as pessoas.

4 Não hesite
sobre o que vai acontecer.

5 Não te pareças com aqueles que dão a mão quando
precisam e a retiram quando devem dar.

6 Se o trabalho de suas mãos te rendem algo, as
ofereça como reparação pelos seus pecados.

7 Não hesite em dar, nem dê reclamando
porque, na verdade, você sabe quem realmente pagou sua recompensa.

8 Não rejeite o
necessitado. Compartilhe tudo com seu irmão e não diga que as coisas são apenas suas.
Se vocês estão unidos nas coisas imortais, tanto mais estarão nas coisas perecíveis.

9 Não se descuide de seu filho ou filha. Muito pelo contrário, desde a infância instrua-os a
temer a Deus.

10 Não dê ordens com rudeza ao seu escravo ou escrava pois eles
também esperam no mesmo Deus que você; assim, não perderão o temor de Deus, que
está acima de todos. Certamente Ele não virá chamar a pessoa pela aparência, mas
somente aqueles que foram preparados pelo Espírito.

11 Quanto a vocês, escravos,
obedeçam aos seus senhores, com todo o respeito e reverência, como à própria imagem
de Deus.

12 Deteste toda a hipocrisia e tudo aquilo que não agrada o Senhor.

13 Não
viole os mandamentos dos Senhor. Guarde tudo aquilo que você recebeu: não
acrescente ou retire nada.

14 Confesse seus pecados na reunião dos fiéis e não comece a
orar estando com má consciência. Este é o caminho da vida.

### Capítulo V - O caminho da morte

1 Este é o caminho da morte: primeiro, é mau e cheio de maldições - homicídios,
adultérios, paixões, fornicações, roubos, idolatria, magias, feitiçarias, rapinas, falsos
testemunhos, hipocrisias, coração com duplo sentido, fraudes, orgulho, maldades,
arrogância, avareza, palavras obscenas, ciúmes, insolência, altivez, ostentação e falta de
temor de Deus.

2 Nesse caminho trilham os perseguidores dos justos, os inimigos da

3 verdade, os amantes da mentira, os ignorantes da justiça, os que não desejam o bem
nem o justo julgamento, os que não praticam o bem mas o mal. A calma e a paciência
estão longe deles. Estes amam as coisas vãs, são ávidos por recompensas, não se
compadecem com os pobres, não se importam com os perseguidos, não reconhecem o
Criador. São também assassinos de crianças, corruptores da imagem de Deus,
desprezam os necessitados, oprimem os aflitos, defendem os ricos, julgam injustamente
os pobres e, finalmente, são pecadores consumados. Filho, afaste-se disso tudo.

### Capítulo VI - Instrução sobre alimentos

1 Fique atento para que ninguém o afaste do caminho da instrução, pois quem faz isso
ensina coisas que não pertencem a Deus.

2 Você será perfeito se conseguir carregar todo
o jugo do Senhor. Se isso não for possível, faça o que puder.

3 A respeito da comida,
observe o que puder. Não coma nada do que é sacrificado aos ídolos pois esse culto é
destinado a deuses mortos.