### Capítulo XIV - Reunião dominical e confissão dos pecados

1 Reúna-se no dia do Senhor para partir o pão e agradecer após ter confessado seus pecados, para que o sacrifício seja puro.

2 Aquele que está brigado com seu companheiro não pode juntar-se antes de se reconciliar, para que o sacrifício oferecido não seja profanado.

3 Esse é o sacrifício do qual o Senhor disse:
"Em todo lugar e em todo tempo, seja oferecido um sacrifício puro porque sou um grande rei - diz o Senhor - e o meu nome é admirável entre as nações".