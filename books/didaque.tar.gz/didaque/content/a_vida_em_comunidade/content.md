## A vida em comunidade

### Capítulo XI - Falsos profetas e mestres

1 Se vier alguém até você e ensinar tudo o que foi dito anteriormente, deve ser acolhido.
2 Mas se aquele que ensina é perverso e ensinar outra doutrina para te destruir, não lhe
dê atenção. No entanto, se ele ensina para estabelecer a justiça e conhecimento do
Senhor, você deve acolhê-lo como se fosse o Senhor.

3 Já quanto aos apóstolos e
profetas, faça conforme o princípio do Evangelho.

4 Todo apóstolo que vem até você
deve ser recebido como o próprio Senhor.

5 Ele não deve ficar mais que um dia ou, se
necessário, mais outro. Se ficar três dias é um falso profeta.

6 Ao partir, o apóstolo não
deve levar nada a não ser o pão necessário para chegar ao lugar onde deve parar. Se
pedir dinheiro é um falso profeta.

7 Não ponha à prova nem julgue um profeta que fala
tudo sob inspiração, pois todo pecado será perdoado, mas esse não será perdoado.

8 Nem todo aquele que fala inspirado é profeta, a não ser que viva como o Senhor. É
desse modo que você reconhece o falso e o verdadeiro profeta.

9 Todo profeta que, sob
inspiração, manda preparar a mesa não deve comer dela. Caso contrário, é um falso
profeta.

10 Todo profeta que ensina a verdade mas não pratica o que ensina é um falso
profeta.

11 Todo profeta comprovado e verdadeiro, que age pelo mistério terreno da
Igreja, mas que não ensina a fazer como ele faz não deverá ser julgado por você; ele
será julgado por Deus. Assim fizeram também os antigos profetas.

12 Se alguém disser
sob inspiração: "Dê-me dinheiro" ou qualquer outra coisa, não o escutem. Porém, se ele
pedir para dar a outros necessitados, então ninguém o julgue.

### Capítulo XII - Hóspedes cristãos

1 Acolha toda aquele que vier em nome do Senhor. Depois, examine para conhecê-lo,
pois você tem discernimento para distinguir a esquerda da direita.

2 Se o hóspede
estiver de passagem, dê-lhe ajuda no que puder. Entretanto, ele não deve permanecer
com você mais que dois ou três dias, se necessário.

3 Se quiser se estabelecer e tiver
uma profissão, então que trabalhe para se sustentar.

4 Porém, se ele não tiver profissão,
proceda de acordo com a prudência, para que um cristão não viva ociosamente em seu
meio.

5 Se ele não aceitar isso, trata-se de um comerciante de Cristo. Tenha cuidado
com essa gente!

### Capítulo XIII - Esmolas

1 Todo verdadeiro profeta que queira estabelecer-se em seu meio é digno do alimento.

2 Assim também o verdadeiro mestre é digno do seu alimento, como qualquer operário.

3 Assim, tome os primeiros frutos de todos os produtos da vinha e da eira, dos bois e das
ovelhas, e os dê aos profetas, pois são eles os seus sumos-sacerdotes.

4 Porém, se você não tiver profetas, dê aos pobres.

5 Se você fizer pão, tome os primeiros e os dê
conforme o preceito.

6 Da mesma maneira, ao abrir um recipiente de vinho ou óleo,

5 tome a primeira parte e a dê aos profetas.

7 Tome uma parte de seu dinheiro, da sua
roupa e de todas as suas posses, conforme lhe parecer oportuno, e os dê de acordo com
o preceito.

### Capítulo XIV - Reunião dominical e confissão dos pecados

1 Reúna-se no dia do Senhor para partir o pão e agradecer após ter confessado seus
pecados, para que o sacrifício seja puro.

2 Aquele que está brigado com seu
companheiro não pode juntar-se antes de se reconciliar, para que o sacrifício oferecido
não seja profanado.

3 Esse é o sacrifício do qual o Senhor disse: "Em todo lugar e em
todo tempo, seja oferecido um sacrifício puro porque sou um grande rei - diz o Senhor -
e o meu nome é admirável entre as nações".

### Capítulo XV - Bispos e diáconos

1 Escolha bispos e diáconos dignos do Senhor. Eles devem ser homens mansos,
desprendidos do dinheiro, verazes e provados pois também exercem para vocês o
ministério dos profetas e dos mestres.

2 Não os despreze porque eles têm a mesma
dignidade que os profetas e os mestres.

3 Corrija uns aos outros, não com ódio, mas
com paz, como você tem no Evangelho. E ninguém fale com uma pessoa que tenha
ofendido o próximo; que essa pessoa não escute uma só palavra sua até que tenha se
arrependido.

4 Faça suas orações, esmolas e ações da forma que você tem no Evangelho
de nosso Senhor.