### Capítulo XI - Falsos profetas e mestres

1 Se vier alguém até você e ensinar tudo o que foi dito anteriormente, deve ser acolhido.
2 Mas se aquele que ensina é perverso e ensinar outra doutrina para te destruir, não lhe
dê atenção. No entanto, se ele ensina para estabelecer a justiça e conhecimento do
Senhor, você deve acolhê-lo como se fosse o Senhor.

3 Já quanto aos apóstolos e
profetas, faça conforme o princípio do Evangelho.

4 Todo apóstolo que vem até você
deve ser recebido como o próprio Senhor.

5 Ele não deve ficar mais que um dia ou, se
necessário, mais outro. Se ficar três dias é um falso profeta.

6 Ao partir, o apóstolo não
deve levar nada a não ser o pão necessário para chegar ao lugar onde deve parar. Se
pedir dinheiro é um falso profeta.

7 Não ponha à prova nem julgue um profeta que fala
tudo sob inspiração, pois todo pecado será perdoado, mas esse não será perdoado.

8 Nem todo aquele que fala inspirado é profeta, a não ser que viva como o Senhor. É
desse modo que você reconhece o falso e o verdadeiro profeta.

9 Todo profeta que, sob
inspiração, manda preparar a mesa não deve comer dela. Caso contrário, é um falso
profeta.

10 Todo profeta que ensina a verdade mas não pratica o que ensina é um falso
profeta.

11 Todo profeta comprovado e verdadeiro, que age pelo mistério terreno da
Igreja, mas que não ensina a fazer como ele faz não deverá ser julgado por você; ele
será julgado por Deus. Assim fizeram também os antigos profetas.

12 Se alguém disser
sob inspiração: "Dê-me dinheiro" ou qualquer outra coisa, não o escutem. Porém, se ele
pedir para dar a outros necessitados, então ninguém o julgue.