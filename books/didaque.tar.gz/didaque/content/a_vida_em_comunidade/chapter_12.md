### Capítulo XII - Hóspedes cristãos

1 Acolha toda aquele que vier em nome do Senhor.
Depois, examine para conhecê-lo, pois você tem discernimento para distinguir a esquerda da direita.

2 Se o hóspede estiver de passagem, dê-lhe ajuda no que puder.
Entretanto, ele não deve permanecer com você mais que dois ou três dias, se necessário.

3 Se quiser se estabelecer e tiver uma profissão, então que trabalhe para se sustentar.

4 Porém, se ele não tiver profissão, proceda de acordo com a prudência, para que um cristão não viva ociosamente em seu meio.

5 Se ele não aceitar isso, trata-se de um comerciante de Cristo. Tenha cuidado com essa gente!