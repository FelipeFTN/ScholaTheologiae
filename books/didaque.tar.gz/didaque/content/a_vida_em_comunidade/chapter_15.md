### Capítulo XV - Bispos e diáconos

1 Escolha bispos e diáconos dignos do Senhor. Eles devem ser homens mansos,
desprendidos do dinheiro, verazes e provados pois também exercem para vocês o
ministério dos profetas e dos mestres.

2 Não os despreze porque eles têm a mesma
dignidade que os profetas e os mestres.

3 Corrija uns aos outros, não com ódio, mas
com paz, como você tem no Evangelho. E ninguém fale com uma pessoa que tenha
ofendido o próximo; que essa pessoa não escute uma só palavra sua até que tenha se
arrependido.

4 Faça suas orações, esmolas e ações da forma que você tem no Evangelho
de nosso Senhor.