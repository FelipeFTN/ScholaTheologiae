### Capítulo XIII - Esmolas

1 Todo verdadeiro profeta que queira estabelecer-se em seu meio é digno do alimento.

2 Assim também o verdadeiro mestre é digno do seu alimento, como qualquer operário.

3 Assim, tome os primeiros frutos de todos os produtos da vinha e da eira, dos bois e das
ovelhas, e os dê aos profetas, pois são eles os seus sumos-sacerdotes.

4 Porém, se você não tiver profetas, dê aos pobres.

5 Se você fizer pão, tome os primeiros e os dê
conforme o preceito.

6 Da mesma maneira, ao abrir um recipiente de vinho ou óleo,

5 tome a primeira parte e a dê aos profetas.

7 Tome uma parte de seu dinheiro, da sua
roupa e de todas as suas posses, conforme lhe parecer oportuno, e os dê de acordo com
o preceito.