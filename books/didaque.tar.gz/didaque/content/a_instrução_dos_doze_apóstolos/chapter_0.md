### Introdução

A Didaqué é um catecismo cristão escrito entre 60 e 90 d.C. (talvez até antes da destruição do Templo de Jerusalém), provavelmente na Palestina ou na Síria.
Trata-se, certamente, do "documento mais importante da era pós-apostólica, a mais antiga fonte de legislação eclesiástica que possuímos"[^1].
Ao que parece, é fruto da reunião de diversas fontes orais e escritas e que bem retratam a tradição das primeiras comunidades cristãs.
Essa antiguidade explica porque algumas Igrejas chegaram a considerá-lo um escrito canônico.
Apesar de ter sido redigido nos primórdios do Cristianismo, sua mensagem é válida para os dias de hoje.
Entre os assuntos tratados, podemos destacar: a repetição das palavras de Mt 5,26[^2], que contribuíram para a definição da doutrina sobre o Purgatório[^3]; a proibição do aborto[^4] e do esoterismo e astrologia[^5]; a exortação pela unidade dos cristãos[^6]; os sacramentos do batismo[^7], confissão dos pecados[^8] e eucaristia[^9]; o batismo ministrado por imersão[^10] ou infusão[^11] e na forma trinitária[^12]; a eucaristia vista como alimento espiritual para o cristão[^13] e talvez como sacrifício[^14]; os cuidados a serem tomados contra os falsos profetas e mestres[^15]; a celebração eucarística realizada aos domingos[^16]; e a existência de bispos e diáconos substituindo ou com a mesma dignidade dos profetas e mestres[^17].
O documento está dividido em 4 partes, totalizando 16 capítulos.

[^1]: (Johannes Quasten, Patrologia, vol. I)
[^2]: ("Em verdade te digo que de maneira nenhuma sairás dali enquanto não pagares o último centavo")
[^3]: (Didaqué I,5)
[^4]: (Didaqué II,2)
[^5]: (Didaqué III,4)
[^6]: (Didaqué IV,3)
[^7]: (Didaqué VII)
[^8]: (Didaqué IV,14; XIV,1)
[^9]: (Didaqué IX-X)
[^10]: (Didaqué VII,1)
[^11]: (Didaqué VII,3)
[^12]: (Didaqué VII,1.3)
[^13]: (Didaqué X,3)
[^14]: (Didaqué XIV,2-3)
[^15]: (Didaqué XI-XII)
[^16]: (Didaqué XIV,1)
[^17]: (Didaqué XV,1-2)
