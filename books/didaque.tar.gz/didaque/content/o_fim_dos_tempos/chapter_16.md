### Capítulo XVI - Sinais do fim dos tempos

1 Vigie sobre a vida uns dos outros. Não deixe que sua lâmpada se apague, nem afrouxe o cinto dos rins.
Fique preparado porque você não sabe a que horas nosso Senhor chegará.

2 Reúna-se com freqüência para que, juntos, procurem o que convém a vocês; porque de nada lhe servirá todo o tempo que viveu a fé se no último instante não estiver perfeito.

3 De fato, nos últimos dias se multiplicarão os falsos profetas e os corruptores, as ovelhas se transformarão em lobos e o amor se converterá em ódio.

4 Aumentando a injustiça, os homens se odiarão, se perseguirão e se trairão mutuamente.
Então o sedutor do mundo aparecerá, como se fosse o Filho de Deus, e fará sinais e prodígios.
A terra será entregue em suas mãos e cometerá crimes como jamais foram cometidos desde o começo do mundo.

5 Então toda criatura humana passará pela prova de fogo e muitos, escandalizados, perecerão.
No entanto, aqueles que permanecerem firmes na fé serão salvos por aquele que os outros amaldiçoam.

6 Então aparecerão os sinais da verdade:
primeiro, o sinal da abertura no céu; depois, o sinal do toque da trombeta; e, em terceiro, a ressurreição dos mortos.

7 Sim, a ressurreição, mas não de todos, conforme foi dito:
"O Senhor virá e todos os santos estarão com ele".

8 Então o mundo assistirá o Senhor chegando sobre as nuvens do céu.