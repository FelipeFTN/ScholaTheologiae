## A celebração litúrgica

### Capítulo VII - Batismo

1 Quanto ao batismo, faça assim: depois de ditas todas essas coisas, batize em água corrente, em nome do Pai e do Filho e do Espírito Santo.

2 Se você não tiver água corrente, batize em outra água.
Se não puder batizar com água fria, faça com água quente.

3 Na falta de uma ou outra, derrame água três vezes sobre a cabeça, em nome do Pai e do Filho e do Espírito Santo.

4 Antes de batizar, tanto aquele que batiza como o batizando, bem como aqueles que puderem, devem observar o jejum.
Você deve ordenar ao batizando um jejum de um ou dois dias.

### Capítulo VIII - Oração e jejum

1 Os seus jejuns não devem coincidir com os dos hipócritas.
Eles jejuam no segundo e no quinto dia da semana. Porém, você deve jejuar no quarto dia e no dia da preparação.

2 Não reze como os hipócritas, mas como o Senhor ordenou em seu Evangelho.
Reze assim: "Pai nosso que estás no céu, santificado seja o teu nome, venha o teu Reino, seja feita a tua vontade, assim na terra como no céu; o pão-nosso de cada dia nos dai hoje, perdoai nossa dívida, assim como também perdoamos os nossos devedores e não nos deixes cair em tentação, mas livrai-nos do mal porque teu é o poder e a glória para sempre".

3 Rezem assim três vezes ao dia.

### Capítulo IX - Eucaristia

1 Celebre a Eucaristia assim:

2 Diga primeiro sobre o cálice:
"Nós te agradecemos, Pai nosso, por causa da santa vinha do teu servo Davi, que nos revelaste através do teu servo Jesus.
A ti, glória para sempre".

3 Depois diga sobre o pão partido:
"Nós te agradecemos, Pai nosso, por causa da vida e do conhecimento que nos revelaste através do teu servo Jesus.
A ti, glória para sempre".

4 Da mesma forma como este pão partido havia sido semeado sobre as colinas e depois foi recolhido para se tornar um, assim também seja reunida a tua Igreja desde os confins da terra no teu Reino, porque teu é o poder e a glória, por Jesus Cristo, para sempre".

5 Que ninguém coma nem beba da Eucaristia sem antes ter sido batizado em nome do Senhor pois sobre isso o Senhor disse: "Não dêem as coisas santas aos cães".

### Capítulo X - Comunhão

1 Após ser saciado, agradeça assim:

2 "Nós te agradecemos, Pai santo, por teu santo nome que fizeste habitar em nossos corações e pelo conhecimento, pela fé e imortalidade que nos revelaste através do teu servo Jesus.
A ti, glória para sempre.

3 Tu, Senhor onipotente, criaste todas as coisas por causa do teu nome e deste aos homens o prazer do alimento e da bebida, para que te agradeçam.
A nós, porém, deste uma comida e uma bebida espirituais e uma vida eterna através do teu servo.

4 Antes de tudo, te agradecemos porque és poderoso.
A ti, glória para sempre.

5 Lembra-te, Senhor, da tua Igreja, livrando-a de todo o mal e aperfeiçoando-a no teu amor.
Reúne dos quatro ventos esta Igreja santificada para o teu Reino que lhe preparaste, porque teu é o poder e a glória para sempre.

6 Que a tua graça venha e este mundo passe. Hosana ao Deus de Davi.
Venha quem é fiel, converta-se quem é infiel. Maranatha. Amém."

7 Deixe os profetas agradecerem à vontade.