### Capítulo VII - Batismo

1 Quanto ao batismo, faça assim: depois de ditas todas essas coisas, batize em água corrente, em nome do Pai e do Filho e do Espírito Santo.

2 Se você não tiver água corrente, batize em outra água.
Se não puder batizar com água fria, faça com água quente.

3 Na falta de uma ou outra, derrame água três vezes sobre a cabeça, em nome do Pai e do Filho e do Espírito Santo.

4 Antes de batizar, tanto aquele que batiza como o batizando, bem como aqueles que puderem, devem observar o jejum.
Você deve ordenar ao batizando um jejum de um ou dois dias.