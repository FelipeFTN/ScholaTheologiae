### Capítulo X - Comunhão

1 Após ser saciado, agradeça assim:

2 "Nós te agradecemos, Pai santo, por teu santo nome que fizeste habitar em nossos corações e pelo conhecimento, pela fé e imortalidade que nos revelaste através do teu servo Jesus.
A ti, glória para sempre.

3 Tu, Senhor onipotente, criaste todas as coisas por causa do teu nome e deste aos homens o prazer do alimento e da bebida, para que te agradeçam.
A nós, porém, deste uma comida e uma bebida espirituais e uma vida eterna através do teu servo.

4 Antes de tudo, te agradecemos porque és poderoso.
A ti, glória para sempre.

5 Lembra-te, Senhor, da tua Igreja, livrando-a de todo o mal e aperfeiçoando-a no teu amor.
Reúne dos quatro ventos esta Igreja santificada para o teu Reino que lhe preparaste, porque teu é o poder e a glória para sempre.

6 Que a tua graça venha e este mundo passe. Hosana ao Deus de Davi.
Venha quem é fiel, converta-se quem é infiel. Maranatha. Amém."

7 Deixe os profetas agradecerem à vontade.