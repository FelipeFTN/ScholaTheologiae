### Capítulo IX - Eucaristia

1 Celebre a Eucaristia assim:

2 Diga primeiro sobre o cálice:
"Nós te agradecemos, Pai nosso, por causa da santa vinha do teu servo Davi, que nos revelaste através do teu servo Jesus.
A ti, glória para sempre".

3 Depois diga sobre o pão partido:
"Nós te agradecemos, Pai nosso, por causa da vida e do conhecimento que nos revelaste através do teu servo Jesus.
A ti, glória para sempre".

4 Da mesma forma como este pão partido havia sido semeado sobre as colinas e depois foi recolhido para se tornar um, assim também seja reunida a tua Igreja desde os confins da terra no teu Reino, porque teu é o poder e a glória, por Jesus Cristo, para sempre".

5 Que ninguém coma nem beba da Eucaristia sem antes ter sido batizado em nome do Senhor pois sobre isso o Senhor disse: "Não dêem as coisas santas aos cães".