### Capítulo VIII - Oração e jejum

1 Os seus jejuns não devem coincidir com os dos hipócritas.
Eles jejuam no segundo e no quinto dia da semana. Porém, você deve jejuar no quarto dia e no dia da preparação.

2 Não reze como os hipócritas, mas como o Senhor ordenou em seu Evangelho.
Reze assim: "Pai nosso que estás no céu, santificado seja o teu nome, venha o teu Reino, seja feita a tua vontade, assim na terra como no céu; o pão-nosso de cada dia nos dai hoje, perdoai nossa dívida, assim como também perdoamos os nossos devedores e não nos deixes cair em tentação, mas livrai-nos do mal porque teu é o poder e a glória para sempre".

3 Rezem assim três vezes ao dia.