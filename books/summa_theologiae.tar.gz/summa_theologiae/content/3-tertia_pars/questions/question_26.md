# Questão 26: Da denominação dada a Cristo, de medianeiro entre Deus e os homens
Em seguida devemos tratar da denominação dada a Cristo, de medianeiro entre Deus e os homens.
E nesta questão discutem-se dois artigos:

## Art. 1 — Se é próprio de Cristo ser o medianeiro entre Deus e os homens.
O primeiro discute-se assim. — Parece que não é próprio de Cristo ser o medianeiro entre Deus e os
homens.

1. — Pois, assim como o sacerdote, assim também o profeta é mediador entre Deus e os homens,
segundo a Escritura: Eu fui o que intervim como mediador entre o Senhor e vós, naquele tempo. Ora,
ser sacerdote e profeta não convém a Cristo. Logo, nem ser medianeiro.

2. Demais. — O que convém aos anjos bons e maus não pode ser considerado próprio de Cristo. Ora, ser
medianeiro entre Deus e os homens convém aos anjos bons, como diz Dionísio. E convém também aos
anjos maus, isto é, aos demônios, que tem certa comunidade com Deus, pela sua imortalidade; e certa
outra com os homens, a saber, um espírito passível e, por consequência, sujeito à dor, como está claro
em Agostinho. Logo, ser o medianeiro entre Deus e os homens não é próprio de Cristo.

3. Demais. — Ao ofício do medianeiro pertence aproximar aqueles entre os quais se interpõe. Ora, o
Espírito Santo, no dizer do Apóstolo, intercede por nós a Deus com gemidos inexplicáveis. Logo, o
Espírito Santo é o medianeiro entre Deus e os homens. O que, portanto, não é próprio de Cristo.
Mas, em contrário, o Apóstolo: Só há um mediador entre Deus e os homens, que é Jesus Cristo homem.

SOLUÇÃO. — É ofício próprio do mediador unir aqueles entre os quais se interpôs; pois os extremos se
unem no meio. Ora, unir os homens a Deus, de modo perfeito, convém a Cristo, por meio de quem os
homens se reconciliaram com Deus, segundo o Apóstolo: Deus estava em Cristo reconciliando o mundo
consigo. Logo, só Cristo é o perfeito medianeiro entre Deus e os homens, por ter reconciliado o gênero
humano com Deus, pela sua morte. E por isso, depois de o Apóstolo ter dito – Mediador entre Deus e os
homens, que é Jesus Cristo homem – acrescenta: Que se deu a si mesmo para redenção de todos. Mas
nada impede certos outros serem, de algum modo, considerados mediadores entre Deus e os homens;
isto é, se cooperam para a união dos homens com Deus, por via de preparação ou de ministério.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os profetas e os sacerdotes da lei antiga foram
chamados mediadores entre Deus e os homens, por via de preparação e de ministério; isto é, enquanto
prenunciavam e prefiguravam o verdadeiro e perfeito mediador entre Deus e os homens. Ao passo que
os sacerdotes do Novo Testamento podem chamar-se mediadores entre Deus e os homens, enquanto
ministros do verdadeiro mediador, ministrando aos homens, em nome dele, os sacramentos da
salvação.

RESPOSTA À SEGUNDA. — Os anjos bons, como diz Agostinho, não podem chamar-se com propriedade
mediadores entre Deus e os homens. Pois, tendo de comum com Deus a beatitude e a imortalidade,
mas não as tendo em comum com os homens miseráveis e mortais, como não hão de antes, estar
afastados dos homens e unidos com Deus, do que serem constituídos medianeiros entre ambos? E
Dionísio também diz que são medianeiros, porque, segundo o grau da natureza, foram constituídos
inferiores a Deus e superiores aos homens, E exercem o ofício de mediador, não principal e
perfeitamente, mas ministerial e dispositivamente. Por isso, o Evangelho diz, que chegaram os anjos e o
serviam isto é, a Cristo. — Quanto aos demônios, eles tem de comum com Deus a imortalidade e, com
os homens, a miséria. E entre um ser imortal e outro sujeito a misérias, o demônio se interpõe como
mediador, a fim de impedir o homem de chegar à imortalidade feliz, fazendo cair na miséria imortal. Por
isso, é um mau medianeiro, que separa os amigos. Quanto a Cristo, ele tinha de comum com Deus a
beatitude, e com os homens, a mortalidade. Por isso, interpôs-se como mediador para que, depois de
passada a sua mortalidade, os fizesse, de mortos, imortais, o que demonstrou pela sua ressurreição; e
para que, de miseráveis, os tornasse felizes, nunca deixou de ter a felicidade. Donde o ser ele o bom
mediador, que reconcilia os inimigos.

RESPOSTA À TERCEIRA. — O Espírito Santo, sendo em tudo igual a Deus, não pode chamar-se mediador
entre Deus e os homens; mas só Cristo, que, embora pela divindade seja igual ao Pai, contudo, pela
humanidade é menor que o Pai, como se disse. Por isso, àquilo do Apóstolo — Cristo é mediador — diz a
Glosa: Não o Pai nem o Espírito Santo. Mas dizemos que o Espírito Santo intercede por nós, por nos
fazer orar.

## Art. 2 — Se Cristo enquanto homem é o mediador entre Deus e os homens.
O segundo discute-se assim. Parece que Cristo, enquanto homem não é o mediador entre Deus e os
homens.

1. — Pois, diz Agostinho: Uma só é a pessoa de Cristo, a fim de que não deixe de ser um. Cristo, não uma
substância; a fim de afastada a benefício de mediador, não ser considerado Filho ou só de Deus ou só do
homem. Ora, enquanto homem, não é Filho de Deus e do homem; mas simultaneamente, enquanto
Deus e homem. Logo, não devemos dizer que seja mediador entre Deus e o homem, só enquanto
homem.

2. Demais. — Assim como Cristo, enquanto Deus, tem a mesma natureza que o Pai e o Espírito Santo,
assim, enquanto homem, tem a mesma natureza que os homens. Ora, por ter, como Deus, a mesma
natureza que o Pai e o Espírito Santo, não pode chamar-se mediador. Assim, aquilo do Apóstolo: Ele é
mediador entre Deus e os homens, a Glosa: Enquanto Verbo não é mediador, por ser igual a Deus, Deus
perante Deus e simultaneamente uno com Deus. Logo, também enquanto homem não pode chamar-se
mediador, por ter a mesma natureza que os homens.

3. Demais. — Cristo é chamado mediador, por nos ter reconciliado com Deus, o que realizou, delindo-
nos do pecado, que nos separava de Deus. Ora, delir o pecado fá-lo Cristo, não como homem, mas como
Deus. Logo, Cristo, enquanto homem, não é mediador, mas, como Deus.
Mas, em contrário, diz Agostinho: Cristo não é mediador por ser o Verbo; pois, o Verbo, absolutamente
imortal e absolutamente feliz, está acima das misérias dos mortais. Mas é mediador enquanto homem.

SOLUÇÃO. — Duas coisas podemos considerar no mediador: primeiro, a natureza de mediador;
segundo, o ofício de unir. Ora, da natureza do mediador é distar de um e outro extremo. E quanto a
unir, o mediador o faz, transferindo a um dos extremos o que é do outro. Ora, nada disto pode convir a
Cristo, enquanto Deus, mas só enquanto homem. Pois, enquanto Deus, não difere do Pai e do Espírito
Santo em natureza nem em poder de domínio. Nem o Padre e o Espírito Santo tem nada que não seja
do Filho; de modo que pudesse deferir a outros o que é do Pai ou do Espírito Santo, como se de outrem
o fosse. Pois, enquanto homem, difere de Deus em natureza; e dos homens, em dignidade e graça. E
como homem, cabe-lhe unir os homens com Deus, transmitindo-lhes os preceitos e os dons, e satisfazer
e interceder pelos homens, perante Deus. Por isso, verdadeirissimante se chama mediador, enquanto
homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Eliminada de Cristo a natureza divina, ser-lhe à por
consequência eliminada a singular plenitude das graças, que lhe convém, enquanto unigênito do Pai,
como diz o Evangelho. De cuja plenitude lhe resulta o ser constituído superior de todos os homens, e
mais próximo de Deus.

RESPOSTA À SEGUNDA. — Cristo, enquanto Deus, é em tudo igual ao Pai. Mas também pela natureza
humana excede os outros homens. Por isso, enquanto homem, pode ser mediador; mas não como Deus.

RESPOSTA À TERCEIRA. — Embora convenha a Cristo, enquanto Deus, delir o pecado por autoridade
própria, contudo, satisfazer pelo pecado do gênero humano só lhe convém; como homem. E, por isso,
chama-se mediador entre Deus e os homens.
A vida de Cristo
