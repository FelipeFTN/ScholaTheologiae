# Questão 51: Da sepultura de Cristo
Em seguida devemos tratar da sepultura de Cristo. E nesta questão discutem-se quatro artigos:

## Art. 1 — Se foi conveniente Cristo ser sepultado.
O primeiro discute-se assim. — Parece que não foi conveniente Cristo ser sepultado.

1. — Pois, de Cristo diz a Escritura: Chegou a ser homem como sem socorro, livre entre os mortos. Ora,
nos sepulcros são encerrados os corpos dos mortos, o que, parece, é o contrário da liberdade. Logo,
parece que não foi conveniente fosse o corpo de Cristo sepultado.

2. Demais. – Nada, devia ser feito, em relação a Cristo, que não fosse salutífero. Ora, parece que em
nada contribuía para a salvação dos homens o ter sido Cristo sepultado. Logo, não foi conveniente que
fosse sepultado.

3. Demais. — Parece inconveniente que Deus, o excelso sobre os céus, fosse sepultado na terra. Ora, o
que convém a Cristo morto é atribuído a Deus, em virtude da união. Logo, parece inconveniente que
Cristo fosse remunerado.
Mas, em contrário, diz o Senhor, da mulher que o tenha ungido: No que fezme fezuma boa obra. E
depois acrescenta: Porquanto derramar ela este balsamo sobre o meu corpo foi ungir-me para ser
enterrado.

SOLUÇÃO. — Era conveniente que Cristo fosse sepultado. — Primeiro, para comprovar a verdade da sua
morte; pois, ninguém é posto num sepulcro senão quando consta que está verdadeiramente morto. Por
isso no Evangelho se lê que Pilatos, antes de permitir que Cristo fosse sepultado, procurou saber por
uma inquisição diligente, se estava morto. - Segundo, porque tendo ressurgido do sepulcro, deu a
esperança de ressurgir, por meio dele, aos que estão sepultas segundo aquilo do Evangelho: Todos os
que se acham nos sepulcros ouvirão a voz do Filho de Deus. - Terceiro, para exemplo dos que, pela
morte de Cristo, morreram espiritualmente aos pecados, conforme àquilo da Escritura: Estão
escondidos contra a turbação dos homens. Por isso diz o Apóstolo: Já estais mortos e a vossa vida está
escondida com Cristo em Deus. E assim também os batizados, que pela morte de Cristo morreram aos
pecados, são como consepultos com Cristo, pela imersão, segundo o Apóstolo: Nós fomos sepultados
com Cristo para morrer pelo batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. - Cristo, mesmo sepulto, mostrou que entre os mortos era
livre, pelo fato da inclusão no sepulcro não ter podido impedi-Ia sair dele pela ressurreição.

RESPOSTA À SEGUNDA. — Assim como a morte de Cristo obrou eficientemente a nossa salvação, assim
também a sua sepultura. Por isso diz Jerônimo: Ressurgimos pela sepultura de Cristo. E àquilo da
Escritura: E dará os ímpios pela sepultura, diz a Glosa: isto é, as gentes, que não tinham a piedade, da-
tos-á a Deus Padre, porque os ganhou pela sua morte e sepultura.

RESPOSTA À TERCEIRA. — Como se diz num Sermão do concílio Efesino, nenhuma das coisas que
servem a salvação dos homens fazem injúria a Deus; pois, mostram que ele não é passível, mas
clemente. E noutro sermão do mesmo Concílio lemos: Deus não considera como injurioso nada do que
pode ser para o homem ocasião de salvar-se. Pois, não irias ter por vil a natureza de Deus, admitido que
ela possa jamais considerar-se sujeita a injúrias.

## Art. 2 — Se Cristo foi sepulto de modo conveniente.
O segundo discute-se assim. — Parece que Cristo não foi sepulto de modo conveniente.

1. — Pois, a sua sepultura lhe correspondia à morte. Ora, Cristo sofreu morte objetíssima, segundo
aquilo da Escritura: Condenêmo-lo a uma morte a mais infame. Logo, parece inconveniente o ter sido
dada a Cristo uma sepultura honrosa, pelo fato de ter sido enterrado por homens ricos, isto é, por José
de Arimateia um decurião nobre, e por Nicodemos, senhor entre os judeus, como lemos no Evangelho.

2. Demais. — Com Cristo nada devia ter-se dado que fosse exemplo de superfluidade. Ora, parece ter
sido superfluidade que, para sepultá-lo, Nicodemos viesse trazendo uma composição de quase cem
libras de mirra e de aloé; sobretudo que uma mulher foi embalsamar-lhe antecipadamente o corpo para
a sepultura, segundo lemos no Evangelho. Logo, isso não se fez com Cristo, de maneira conveniente.

3. Demais. — Não pode estar uma coisa em dissonância consigo mesma. Ora, a sepultura de Cristo foi
simples, de um lado, pois, José amortalhou-o num asseado lençol, como refere o Evangelho; não,
porémcom ouro ou gemas ou seda, como explica Jerônimo. Mas, de outro lado, parece que esse
sepultamento foi faustoso, pois o sepultaram com aromas. Logo, parece que não foi conveniente o
modo do sepultamento de Cristo.

4. Demais. — Tudo quanto está escrito, e, sobretudo de Cristo, para nosso ensino está escrito, no dizer
do Apóstolo. Ora, certas coisas estão escritas no Evangelho sobre o sepultamento, que em nada
parecem contribuir para o nosso ensino. Assim, que foi sepulto numa horta, num sepulcro que lhe não
pertencia, que ainda não tinha servido e aberto numa rocha. Logo, foi inconveniente o modo do
sepultamento de Cristo.
Mas, em contrário, a Escritura: E será glorioso o seu sepulcro.

SOLUÇÃO. — O modo do sepultamento de Cristo prova-se que foi conveniente por três razões. -
Primeiro, para confirmar a nossa fé na sua morte e ressurreição. - Segundo para celebrar a piedade dos
que o sepultaram. E por isso diz Agostinho: O Evangelho celebra com razão os que, tirando-lhe o corpo
da cruz, cuidaram em envolvê-lo e sepultá-lo diligente e honrosamente. Terceiro, para representar o
mistério que envolve os que são sepultados com Cristo para morrer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Na morte, que Cristo sofreu, se lhe celebra a paciência e a
constância; e tanto mais quanto mais abjeta foi essa morte. Ao passo que no seu honorífico
sepultamento se considera a virtude de quem, contra a intenção dos que o mataram, mesmo depois de
morto foi sepultado honorificamente; e se prefigura a devoção dos fieis, que haviam de servir a Cristo
morto.

RESPOSTA À SEGUNDA. — O dito do Evangelista, que o sepultam como costumam os judeus sepultar,
adverte, conforme o explica Agostinho, que nesses deveres prestados aos mortos devem-se observar os
costumes de cada povo. Ora, o costume do povo judeu era embalsamar o corpo do morto com vários
aromas, para mais diuturnamente se conservar incorrupto. Por isso ele mesmo ainda diz, que em dados
os casos semelhantes, não é o uso das coisas que é culpável, mas o deleite que nele se põe. E a seguir
acrescenta: O que de ordinário é culposo, em relação às outras pessoas, é sinal de algo de grande
quando se trata de uma pessoa divina ou de um profeta. Quanto à mirra e ao aloé, pela sua amargura,
significam a penitência, pela qual conservamos a Cristo em nós sem a corrupção do pecado. E o odor
dos aromas simboliza a boa fama.

RESPOSTA À TERCEIRA. — A mirra e o aloé foram depositados no corpo de Cristo, para que fosse
conservado imune da corrupção, o que era pois exigido por essa necessidade. E nos serve de exemplo,
que podemos licitamente usar de certas coisas preciosas, como remédio exigido pela necessidade de
conservar o nosso corpo. Quanto ao envolvimento do corpo só tinha de certo modo por fim a
conveniência da honestidade. E, em tais casos, devemos nos contentar com a simplicidade. Mas, isso
significa como adverte Jerônimo, que aquele envolveu a Jesus num lençol asseado, que o tomou com
mente pura. Daí o dizer Beda: O costume da Igreja estabeleceu que o sacrifício do Altar fosse celebrado
sobre uma toalha, não de seda nem de pano tingido, senão de linho puro, assim como o corpo do
Senhor foi sepulto num lençol asseado.

RESPOSTA À QUARTA. — Cristo foi sepulto num jardim, para significar que pela sua morte e
sepultamento somos livrados da morte em que incorremos pelo pecado de Adão cometido no Jardim do
Paraíso. - E, depois, o Salvador foi sepultado num sepulcro que lhe não pertencia, porque, como diz
Agostinho num Sermão, morreu pela salvação dos outros; ora, o sepulcro é o habitáculo da morte. E isso
também pode nos fazer considerar a extrema pobreza que Cristo abraçou por nós. Pois, aquele que
durante a vida não teve uma habitação, depois da morte foi ainda sepulto em sepulcro alheio, sendo,
por estar nu coberto por José. Foi deposto num monumento novo, como adverte Jerônimo, afim de que,
se outros mortos tivessem repousado no túmulo, não se dissesse, depois da sua ressurreição, que foi
outro o ressuscitado. E também pode o sepulcro novo simbolizar o ventre virginal de Maria. E ainda nos
dá a entender que pela sepultura de Cristo todos somos renovados, destruída a morte e a corrupção. -
Foi encerrado num sepulcro aberto numa rocha, como explica Jerônimo, a fim de que, se fosse
construído com pedras destacadas, não se pudesse dizer que lhe tiraram furtivamente o corpo por uma
abertura, praticada nos fundamentos. Por isso, a grande pedra que lhe foi aposta mostra que o sepulcro
não podia ser aberto senão com a cooperação de muitos. E também, se tivesse sido sepulto na terra
poderiam dizer: Cavaram a terra e o furtaram, como ensina Agostinho. - A significação mística do corpo
de Cristo é como diz Hilário, que os Apóstolos, para introduzirem Cristo no coração da rude gentilidade,
tiveram de abri-lo, de certo modo, pelo esforço da doutrina, como se sulca um terreno novo e inculto,
impermeável até então ao ingresso do temor de Deus. E como nada além de Cristo deve ter entrada em
nosso coração, ao sepulcro se apôs uma pedra. - E, como diz Orígenes, não foi fortuitamente que se
escreveu que José envolveu o corpo de Cristo num lençol asseado e o depôs num monumento que ainda
não tinha servido e que lhe apôs uma grande pedra: porque tudo o respeitante ao corpo de Jesus é
puro, novo e excepcionalmente grande.

## Art. 3 — Se o corpo de Cristo se reduziu a cinza, no sepulcro.
O terceiro discute-se assim. — Parece que o corpo de Cristo se reduziu as cinzas, no sepulcro.

1. — Pois, assim como a morte foi a pena do pecado dos nossos primeiros pais, assim a redução àcinzas.
Porquanto foi dito ao primeiro homem - Tu és pó e em pó te tornarás, como refere a Escritura. Ora,
Cristo padeceu a morte para nos livrar dela. Logo, também o seu corpo devia reduzir-se a cinzas, a fim
de livrar o nosso dessa mesma redução.

2. Demais. — O corpo de Cristo era da mesma natureza que o nosso. Ora o nosso corpo logo depois da
morte, começa a desfazer-se e a entrar em putrefação; porque, desaparecido o calor natural, sobrevém
o calor estranho, causa da putrefação. Logo, parece que o mesmo devia ter-se dado com o corpo de
Cristo.

3. Demais. — Como se disse, Cristo quis ser sepulto, para nos dar a esperança de ressurgir, mesmo do
sepulcro. Logo, também devia ter sofrido a redução a cinzas, para dar a esperança de a ressurgir aos que
se acham reduzidos a cinzas, mesmo depois dessa redução.
Mas, em contrário, a Escritura: Não permitirás que o teu santo veja corrupção. O que, Damasceno
explica, se refere à corrupção resultante da redução aos elementos.

SOLUÇÃO. — Não convinha que o corpo de Cristo se putrefizesse ou fosse de qualquer modo reduzido a
cinzas. Porque a putrefação de qualquer corpo lhe provém da debilidade da natureza, que não pode
mais conservar-lhe a unidade. Ora, a morte de Cristo como dissemos, não podia ser resultante da
debilidade da natureza, a fim de que não se pensasse que não foi voluntária. Por isso quis morrer não de
doença, mas dos padecimentos que lhe foram impostos e aos quais se ofereceu espontaneamente. Por
onde, a fim de que a sua morte não lhe fosse atribuída à doença, Cristo não permitiu o seu corpo
putrefazer-se de nenhum modo, nem de nenhum modo corromper-se; mas, para mostrar o poder
divino, quis permanecesse incorrupto. Por isso diz Crisóstomo: Dos homens, os que procederam
heroicamente, os próprios feitos lhe ornam a vida; mas suas glórias perecem com a morte, totalmente o
contrário se deu com cristo. Pois, antes da cruz tudo lhe era tristeza e enfermidade; depois, porém de
crucificado, tudo se lhe torna glorioso — a fim de saberes que não era um puro homem esse crucificado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo, não estando sujeito ao pecado, também não o
estava à morte nem a ser reduzido a cinzas. Voluntàriamente, porém sofreu a morte pela nossa
salvação, pelas razões já apresentadas. Se, porém o corpo lhe tivesse sido putrefato ou decomposto,
isso teria sido antes em detrimento da salvação humana; pois então não lhe acreditaríamos no poder
divino. Por isso, da sua pessoa diz a Escritura: Que proveito há no meu sangue se desço à corrupção?
Como se dissesse: Se o meu corpo se putrefizer, perder-se-á o proveito do sangue derramado.

RESPOSTA À SEGUNDA. — O corpo de Cristo, quanto à condição da natureza passível, foi putrescível,
embora não quanto à causa do merecimento da putrefação, que é o pecado. Mas o poder divino
preservou o corpo de Cristo da putrefação, como o ressuscitou da morte.

RESPOSTA À TERCEIRA. — Cristo ressurgiu dos mortos pelo seu poder divino, que não é coaretado por
nenhum limite. Por onde, o fato de ter ressurgido do sepulcro era um argumento suficiente para
estabelecer que os homens haveriam de ressuscitar, por esse poder divino, não só dos sepulcros, mas
também de quaisquer cinzas.

## Art. 4 — Se Cristo permaneceu no sepulcro só um dia e duas noites.
O quarto discute-se assim. — Parece que Cristo não permaneceu no sepulcro só um dia e duas noites.

1. — Diz a Escritura: Assim como Jonas esteve no ventre da baleia três dias e três noites, assim estará o
Filho do homem três dias e três noites no coração da terra. Ora, no coração da terra esteve enquanto
demorou no sepulcro. Logo, não esteve no sepulcro só um dia e duas noites.

2. Demais. — Gregório diz que assim como Sansão tomou, à meia noite, as portas de Gaza, assim Cristo
ressurgiu tomando, à meia noite, as portas do inferno. Ora, tendo ressurgido, já não estava no sepulcro.
Logo, não esteve no sepulcro duas noites inteiras.

3. Demais. — Pela morte de Cristo a luz venceu as trevas. Ora, a noite são as trevas e o dia, a luz. Logo,
era conveniente que o corpo de Cristo estivesse no sepulcro, antes, dois dias e uma noite, que ao
contrário.
Mas, em contrário, diz Agostinho: Desde à tarde da sepultura até a manhã da ressurreição são trinta e
seis horas, isto é, uma noite toda seguida deum dia todo e mais uma noite inteira.

SOLUÇÃO. — O tempo mesmo que Cristo permaneceu no sepulcro representa o efeito da sua morte.
Pois, como dissemos pela morte de Cristo fomos libertos de uma dupla morte: a da alma e a do corpo. O
que é significado pelas duas noites, durante as quais Cristo permaneceu no sepulcro. A sua morte,
porém, não causada pelo pecado, mas motivada pela caridade, não é comparável à noite, mas ao dia.
Por isso é simbolizada pelo dia inteiro em que esteve no sepulcro. Por onde, era conveniente que Cristo
permanecesse no sepulcro um dia e duas noites.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz Agostinho: Certos, ignorando o modo de exprimir-se
da Escritura, quiseram considerar como noite aquelas três horas, da sexta até a nona, durante as quais o
sol se obscureceu; e como dia, as três outras horas quando de novo voltou o sol a iluminar a terra, isto
é, da nona até o ocaso. A isso acresce a noite seguinte, do sábado; e essa, contada com o seu dia, viria
tudo já a dar duas noites e dois dias. Ao sábado, porém se lhe segue a noite do primeiro sábado e, a do
dia seguinte, domingo, quando o Senhor ressurgiu. Mas mesmo assim não se chega a ter os três dias e
as três noites. Resta, pois que os descubramos de acordo com o modo de exprimir-se das Escrituras, que
compreende o todo na parte; de modo que tomemos uma noite e um dia por um dia natural. E assim, o
primeiro dia é contado desde a sua última parte, quando Cristo morreu e foi sepulto na sexta-feira; o
segundo dia inteiro se perfez pelas vinte e quatro horas diurnas e noturnas e a noite seguinte pertencia
ao terceiro dia. Pois, assim como os primeiros dias (da criação) se contavam a partir da luz até a noite,
por causa da queda futura do homem, assim, no caso vertente, por causa do resgate do homem, os dias
se contam partindo das trevas para a luz.

RESPOSTA À SEGUNDA. — Como diz Agostinho, Cristo ressurgiu no dilúculo quando já a luz começa a
aparecer e, contudo ainda resta algo das trevas da noite; por isso o Evangelho refere que as mulheres
vieram ao sepulcro de manhã, jazendo ainda escuro. E por causa dessas trevas, Gregório diz ter Cristo
ressurgido à meia noite, não dividindo-se a noite em duas partes iguais, mas considerada noite o que já
propriamente não o era. Pois, esse dilúculo pode considerar-se parte tanto do dia como da noite, pela
conveniência que tem com um e com a outra.

RESPOSTA À TERCEIRA. — Na morte de Cristo, a luz, significada por um dia inteiro, prevaleceu a ponto
de arredar as trevas de duas noites, isto é, da dupla morte nossa, como se disse.