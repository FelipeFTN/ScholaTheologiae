# Questão 35: Da natividade de Cristo
Em seguida devemos tratar da natividade de Cristo, depois de termos tratado da sua concepção. E
primeiro, da natividade em si mesma. Segundo, da manifestação da sua natividade.
Na primeira questão discutem-se oito artigos:

## Art. 1 — Se a natividade deve ser atribuída, antes, à natureza que à Pessoa.
O primeiro discute-se assim. — Parece que a natividade deve ser atribuída, antes, à natureza que à
Pessoa.

1. — Pois, diz Agostinho (Fulgêncio): Uma natureza eterna e divina não poderia ser concebida e nascer
da natureza humana, se não tivesse realmente assumido a natureza humana. Se, pois, à natureza divina
convém o ser concebida e nascer, em razão da natureza humana, muito mais o convém a natureza
humana.

2. Demais. — Segundo o Filósofo, o nome de natureza é derivado de nascer. Ora, as denominações se
fundam na conveniência de semelhança. Logo, parece que a natividade deve ser atribuída antes à
natureza que à Pessoa.

3. Demais. — Propriamente nasce o que começa a existir, pela natividade. Ora, pela sua natividade
Cristo não começou a existir, na sua Pessoa; mas sim, na sua natureza humana. Logo, parece que a
natividade pertence propriamente à natureza e não à Pessoa.
Mas, em contrário, Damasceno: A natividade é da hipóstase e não da natureza.

SOLUÇÃO. — A natividade pode ser atribuída a um ser de dois modos: como ao sujeito e como ao
termo. - Como ao sujeito, é atribuída ao ser nascido. Ora, este propriamente é hipóstase e não natureza.
Pois, nascer é um modo de ser gerado; porque, como um ser é gerado para existir, assim também para
existir é que nasce. Ora, a existência é própria do ser subsistente; e por isso da forma não subsistente
dizemos que existe só por ser o princípio da existência de algum ser. Ora, a pessoa ou hipóstase significa
uma subsistência; ao passo que a natureza é a expressão da forma, que é princípio da subsistência. Por
isso, a natividade é propriamente atribuída à pessoa ou à hipóstase, como ao sujeito que nasce, e não à
natureza. — Mas, como ao termo a natividade é atribuída à natureza. Pois, o termo da geração e de
qualquer natividade é a forma. Ora, a natureza é a expressão da forma. Por onde, como diz Aristóteles, a
natividade é chamada via para a natureza; pois a tendência da natureza tem como seu termo a forma ou
a natureza da espécie.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por causa da identidade existente em Deus entre a
natureza e a hipóstase, às vezes a natureza é tomada pela pessoa ou pela hipóstase. E, assim, Agostinho
diz que a natureza divina foi concebida e nascida; porque a pessoa do Filho, pela sua natureza humana,
foi concebida e nasceu.

RESPOSTA À SEGUNDA. — Nenhum movimento ou mudança tira a sua denominação do sujeito movido:
mas, do termo do movimento, que o especifica. Por isso a natividade não recebe a sua denominação da
pessoa nascida. mas da natureza. que é o seu termo.

RESPOSTA À TERCEIRA. — A natureza, propriamente falando, não começa a existir: mas, antes a pessoa
é que o começa numa determinada natureza. Pois, como dissemos, a natureza exprime o princípio da
existência de um ser; ao passo que a pessoa exprime um ser subsistente.

## Art. 2 — Se a Cristo deve atribuir-se uma natividade temporal.
O segundo discute-se assim. — Parece que a Cristo não deve ser atribuída nenhuma natividade
temporal.

1. — Pois o nascimento é um como movimento de um ser não existente, antes de nascido. e que para
existir tem necessidade do benefício do nascimento. Ora, Cristo existiu abeterno. Logo, não podia ter
nascido no tempo.

2. Demais. — O em si mesmo perfeito não precisa de nascer. Ora a pessoa do Filho de Deus é abeterno
perfeita. Logo, não precisa de nenhuma natividade temporal, assim, parece que não nasceu no tempo.

3. Demais. — A natividade é própria da pessoa. Ora, em Cristo só há uma pessoa. Logo, só teve uma
natividade.

4. Demais. — Quem nasceu em duas natividades nasceu duas vezes. Ora, é falsa a proposição: Cristo
nasceu duas vezes. Pois, a natividade. pela qual nasceu do Pai, não sofreu nenhuma interrupção, por ser
eterna. E isso contudo é o que exprime a expressão - duas vezes: assim, dizemos que correu duas vezes
quem interrompeu a primeira corrida. Logo, parece não deve ser atribuída a Cristo uma dupla
natividade.
Mas, em contrário, diz Damasceno: Confessamos em Cristo duas natividades: uma eterna, do Pai; outra
que se dará nos últimos tempos, por nosso amor.

SOLUÇÃO. — Como dissemos, a natureza está para a natividade como o termo para o movimento ou a
mudança. Ora, o movimento se diversifica pela diversidade dos seus termos, como está claro no
Filósofo. Ora, Cristo tem uma dupla natureza: a que recebeu abeterno do Pai e a que recebeu
temporalmente da mãe. Por onde e necessariamente, devem ser-lhe atribuídas duas natividades: a pela
qual eternamente nasceu do Pai e a pela qual nasceu temporalmente da mãe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção formulada foi a de um certo Feliciano,
herético, que Agostinho resolve do modo seguinte: Imaginemos, diz, como certos querem; que há no
universo uma alma geral, que pela sua influência inefável vivifica todos os germens, de tal sorte que se
não confunda com os seres gerados, mas de a vida aos que o vão ser. Então, quando chegar a formar, no
ventre materno, uma certa matéria adaptada aos seus fins, ela se unirá pessoalmente com a sua obra
que não constitui com ela uma mesma substância; e far-se-á um homem, de duas substâncias - a alma
ativa e a matéria passiva. Ora, é assim que afirmamos o nascer a alma, do ventre; e não que, antes de
nascer, absolutamente não existisse, no seu ser. E desse modo, antes, de um modo mais sublime,
nasceu o Filho de Deus, enquanto homem, no sentido em que se ensina que a alma nasce com o corpo;
não que ambos constituam uma só substância, mas, de ambos, resulta uma só pessoa. Mas nem por isso
dizemos que começou inicialmente a existir o Filho de Deus, não vá alguém crer numa divindade
temporal. Nem afirmamos que a carne do Filho de Deus existiu abeterno, para não levarmos a crer que
não teve um corpo verdadeiramente humano, e lho atribuímos somente em imagem.

RESPOSTA À SEGUNDA. — Essa objeção a formulou Nestório, mas Cirilo lhe deu uma solução dizendo o
seguinte: Não afirmamos que necessariamente o Filho de Deus, em si mesmo, precisasse de uma
segunda natividade, além da que tinha, do Pai; pois, seria de um fátuo e de um ignaro dizer, que o
existente antes de todos os séculos e consempiterno com o Pai, precisou de começar, e ter uma
segunda existência. Mas, dizemos que nasceu carnalmente, porque, por nosso amor e para a nossa
salvação, unindo-se à sua subsistência. a natureza humana nasceu de uma mulher.

RESPOSTA À TERCEIRA. — A natividade pertence à pessoa como ao sujeito; e à natureza, como ao
termo. Ora, é possível um mesmo sujeito sofrer várias transmutações, que contudo hão de
necessariamente variar com os seus termos. Mas isso não dizemos da natividade eterna, como se ela
fosse uma transmutação ou um movimento; mas, segundo o nosso modo de falar e que lhe atribuímos
mudança do movimento.

RESPOSTA À QUARTA. — Podemos dizer que Cristo nasceu duas vezes e teve duas natividades. Pois
assim como dizemos que corre duas vezes quem corre em dois tempos diferentes, assim podemos dizer
que nasceu duas vezes quem nasceu uma vez, na eternidade e, uma vez, no tempo. Porque a eternidade
e o tempo diferem muito mais entre si que dois tempos, embora uma e outro designem a medida da
duração.

## Art. 3 — Se pela natividade temporal de Cristo, a Santa Virgem possa ser considerada sua mãe.
O terceiro discute-se assim. — Parece que pela natividade temporal de Cristo, a Santa Virgem não
pode ser considerada sua mãe.

1. — Pois, como se disse, a Santa Virgem Maria não foi de nenhum modo princípio ativo na geração de
Cristo, mas só ministrou a matéria. Ora, isso não basta para ser mãe; do contrário, poderíamos dizer que
a madeira é mãe de um leito ou de um móvel. Logo, parece que a Santa Virgem não pode ser
considerada mãe de Cristo.

2. Demais. — Cristo nasceu milagrosamente da Santa Virgem. Ora, uma geração milagrosa não basta
para constituir a maternidade nem a filiação; assim, não dizemos que Eva foi filha de Adão. Logo, Cristo
não deve ser considerado filho da Santa Virgem.

3. Demais. — A função da mãe é emitir o sêmen. Ora, como diz Damasceno, o corpo de Cristo não foi
formado por via seminal, mas, constituído pelo Espírito Santo. Logo, parece que a santa Virgem não
deve ser considerada mãe de Cristo.
Mas, em contrário, o Evangelho: A conceição de Cristo foi desta maneira: Estando já Maria, sua mãe,
desposada com José, etc.

SOLUÇÃO. — A Santa Virgem foi verdadeira e naturalmente a mãe de Cristo. Pois, como dissemos, o
corpo de Cristo não foi trazido do céu, como o pretendeu o herético Valentino; mas foi formado no
ventre da virgem mãe do seu mais puro sangue. E isto basta para constituir a maternidade. como do
sobredito resulta. Por onde, a Santa Virgem é verdadeiramente a mãe de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como dissemos, a paternidade ou a maternidade e a
filiação não têm lugar em qualquer geração, mas só na geração dos seres vivos. Por onde, era seres
inanimados, feitos de qualquer matéria, não há relação de maternidade e de filiação; mas só na geração
dos vivos, chamada propriamente natividade,

RESPOSTA À SEGUNDA. — Como diz Damasceno; a natividade temporal, pela qual Cristo nasceu, para a
nossa salvação. é de certo modo, como a nossa, porque nasceu, como homem de uma mulher e dentro
do tempo natural à concepção. Mas. de maneira superior à nossa, porque foi fora da lei da concepção,
formado, não por via seminal. mas pelo Espirito Santo. no ventre da Santa Virgem. Assim, pois, pela sua
matéria a natividade de Cristo foi natural; mas foi milagrosa pela obra do Espírito Santo. Por onde,
verdadeira e naturalmente, a Santa Virgem foi a mãe de Cristo.

RESPOSTA À TERCEIRA. — Como dissemos, a emissão do sêmen feminino não é de necessidade para a
concepção. E por isso, essa emissão não é necessária para constituir a maternidade.

## Art. 4 — Se a Santa Virgem deve chamar-se Mãe de Deus.
O quanto discute-se assim. — Parece que a Santa Virgem não deve ser considerada mãe de Deus.

1. — Pois, não devemos dizer, dos divinos mistérios, senão o que está na Escritura. Ora não lemos nunca
na Escritura que seja a mãe ou a genitora de Deus, mas a mãe de Cristo ou a mãe do menino. Logo, não
devemos dizer que a Santa Virgem é a Mãe de Deus.

2. Demais. — Cristo é Deus pela sua natureza divina. Ora, a natureza divina não recebeu da Virgem o
início da sua existência: Logo a Santa Virgem não deve ser considerada Mãe de Deus.

3. Demais. — O nome de Deus é predicado em comum do Pai do Filho e do Espírito Santo. Se pois a
Santa Virgem é Mãe de Deus resulta que é Mãe do Pai, do Filho e do Espírito Santo o que é inadmissível.
Logo, a Santa Virgem não deve ser considerada Mãe de Deus.
Mas, em contrário, Cirilo diz: com a aprovação do sínodo Efesino: Quem não confessar, que Deus é
verdadeiramente o Emanuel e que, por isso, a Santa Virgem é a Mãe de Deus, por ter gerado
corporalmente o Verbo de Deus feito carne, seja anátema.

SOLUÇÃO. — Como dissemos, todo nome significativo de uma natureza qualquer concreta, pode ser
suposto por qualquer hipóstase dessa natureza. Ora, a união da Encarnação tendo se realizado na
hipóstase, como dissemos, é manifesto que o nome de Deus pode ser suposto pela hipóstase, na qual se
acham unidas a natureza divina e a humana. Logo, tudo o conveniente à natureza divina ou à humana.
pode ser atribuído a essa pessoa, quer seja suposto por ela o nome significativo da natureza divina, quer
o seja o significativo da natureza humana. Ora, a concepção e o nascimento se atribuem à pessoa e à
hipóstase em razão da natureza na qual se operam essas duas transformações. Mas, como no princípio
mesmo da concepção, a natureza humana foi assumida pela pessoa divina, como dissemos, resulta por
consequência, que podemos verdadeiramente afirmar que Deus foi concebido e nascido da Virgem.
Pois, dissemos que uma mulher é mãe de alguém, quando o concebeu e o gerou. Por onde e
consequentemente, a Santa Virgem é verdadeiramente chamada Mãe de Deus. E só seria possível negar
que a Santa Virgem foi a Mãe de Deus, se disséssemos, como o pretendia Fotino, que Cristo foi
concebido e gerado. antes de ser Filho de Deus; ou que, segundo o sentir de Nestório, a humanidade
não foi assumida na unidade da pessoa ou da hipóstase do Verbo de Deus. Ora, ambas essas opiniões
são errôneas. Logo, é herético negar, que a Santa Virgem fosse a Mãe de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa foi a objeção de Nestório, que se resolve dizendo o
seguinte. Embora não achemos propriamente dito na Escritura, que a Santa Virgem fosse a Mãe de
Deus, nela achamos porém expressamente, que Jesus Cristo é verdadeiro Deus; e que a Santa Virgem é
a Mãe de Jesus Cristo. Ora, dessas palavras da Escritura se segue necessariamente, que é a Mãe de
Deus. Assim, como diz o Apóstolo, dos Judeus nasceu Cristo, segundo a carne, que é Deus sobre todas as
coisas, bendito por todos os séculos dos séculos. Ora, não nasceu dos Judeus senão mediante sua Mãe.
Por onde, aquele que é sobre todas as coisas Deus bendito por todos os séculos, nasceu
verdadeiramente da Santa Virgem, como sua mãe.

RESPOSTA À SEGUNDA. — Essa foi a objeção de Nestório; mas Cirilo, numa certa Epístola contra
Nestório resolve-a dizendo: Assim como a alma do homem nasce com o seu corpo próprio e contudo é
considerada como formando uma unidade com ele; e quem ousasse afirmar que a gera triz da carne,
não é contudo a da alma, iria muito longe na sua afirmação, assim descobrimos algo de semelhante na
geração de Cristo. Pois, o Verbo de Deus nasceu da substância de Deus Padre; mas, como assumiu a
carne, devemos confessar que, pelo seu corpo, nasceu de uma mulher. Logo, devemos concluir que a
Santa Virgem deve ser considerada Mãe de Deus; não por ser mãe da divindade, mas que ser, da
humanidade de uma pessoa, que em si unia a divindade e a humanidade.

RESPOSTA À TERCEIRA. — O nome de Deus, embora comum às três Pessoas, contudo é suposto umas
vezes pela só pessoa do Pai: e outras, só pela pessoa do Filho ou do Espírito Santo, como se estabeleceu.
E assim, quando dizemos que a Santa Virgem é Mãe de Deus, o nome de Deus é suposto pela pessoa
encarnada do Filho.

## Art. 5 — Se Cristo teve duas filiações.
O quinto discute-se assim. — Parece que Cristo teve duas filiações.

1. — Pois, a natividade é a causa da filiação. Ora, Cristo teve duas natividades. Logo, também teve duas
filiações.

2. Demais. — A filiação que torna alguém filho de tal mãe ou de tal pai, depende de certa maneira do
filho, pois, a essência da relação está em referir-se de algum modo a um terceiro; por isso, desaparecido
um dos termos da relação, desapareceu também o outro. Ora, a filiação eterna, pela qual Cristo é o
Filho de Deus Padre, não depende da mãe, porque nenhum ser eterno depende do temporal. Logo,
Cristo não foi filho de sua mãe por filiação eterna. Portanto, ou de nenhum modo foi seu filho, o que
colide com o que já foi dito; ou havia de ser filho de Maria por outra filiação temporal. Logo, Cristo teve
duas filiações.

3. Demais. — De dois termos relativos, um entra na definição de outro; por onde, é claro que um é
especificado pelo outro. Ora, um mesmo ser não pode pertencer a espécies diversas. Logo, é impossível
uma mesma relação terminar em extremos absolutamente diversos. Mas, Cristo é, de um lado, Filho do
Padre eterno e, de outro, de uma mãe mortal, que são termos absolutamente diversos. Logo, parece
que não pode Cristo, pela mesma relação, ser considerado Filho do Padre Eterno e da Virgem Maria.
Portanto, teve Cristo duas filiações.
Mas, em contrário, como diz Damasceno, os atributos da natureza se multiplicam em Cristo, mas não os
da pessoa. Ora, a filiação é por excelência um atributo da pessoa, pois, é uma propriedade pessoal,
como se colhe do dito na Primeira Parte. Logo, em Cristo há só uma filiação.

SOLUÇÃO. — Nesta matéria há varias opiniões. - Uns, considerando a causa da filiação, que é a
natividade, atribuem a Cristo duas filiações, por lhe atribuírem duas natividades. — Outros porém,
considerando o sujeito da filiação, que é a pessoa ou a hipóstase, atribuem a Cristo uma só filiação,
assim como uma hipóstase ou pessoa. Ora, a unidade de relação ou a sua pluralidade não se fundam
nos termos, mas na causa ou no sujeito. Pois, se se fundassem nos termos, cada homem haveria de ter
duas filiações — uma referente ao pai e outra, à mãe. Mas, se bem considerarmos veremos, que pela
mesma relação o filho se refere ao pai e à mãe, por causa da unidade causal; pois, pela mesma
natividade nasce do pai e da mãe e, portanto, mantém com ambos a mesma relação. É o caso do
mestre, que ensina a mesma doutrina a muitos discípulos; e do senhor, que governa diversos súbditos
com o mesmo poder. — Mas se as causas forem diversas por diferenças específicas, também por
consequência hão de as relações diferir especificamente. Assim, nada impede caibam ao mesmo sujeito
várias atribuições dessa natureza. Tal o caso de quem fosse mestre de gramática para uns e de lógica,
para outros, pois, a razão desses dois magistérios não é a mesma; e assim, por diversas relações, um
mesmo homem pode ser mestre de pessoas diversas ou ensinar à mesma doutrinas diversas. — Pode
porém dar-se que alguém tenha relação com vários, segundo causas diversas, mas da mesma espécie;
tal o caso do pai de filhos diversos, mas por atos diversos de geração. Por onde, não pode haver
paternidades especificamente diversas, onde os atos de geração são especificamente os mesmos. E
como várias formas da mesma espécie não podem existir simultaneamente no mesmo sujeito, não é
possível ter várias paternidades quem é pai de vários filhos por geração natural. Diferentemente
poderia, porém, ser alguém pai por geração natural, de um filho, e por adoção de outro.
Ora, é manifesto que não nasceu Cristo, pela mesma natividade, do Pai e abeterno e, temporalmente,
da mãe. Nem foram essas natividades da mesma espécie. E por isso, quanto a esta matéria, devemos
atribuir a Cristo duas filiações diversas — uma temporal e outra, eterna. Mas como o sujeito da filiação
não é a natureza, ou parte dela, mas só a pessoa ou a hipóstase, e a hipóstase ou a pessoa de Cristo é
eterna, só pode ele ter filiação numa hipóstase eterna. E toda relação atribuída a Deus temporalmente,
nenhuma realidade introduz em Deus, em si mesmo eterno, mas é apenas uma relação de razão, como
estabelecemos na Primeira Parte. Por onde, a relação de filiação que Cristo tem com sua mãe não pode
ser uma relação real, mas só de razão.
Assim, há, de certo modo, verdade em ambas as opiniões. Pois, se atendermos à noção perfeita de
filiação, devemos atribuir a Cristo duas filiações, por causa da dualidade das natividades. Mas, se
atendermos ao sujeito da filiação, que só pode ser um suposto eterno, não pode em Cristo haver
realmente senão uma filiação eterna. — Mas Cristo é considerado filho, relativamente à sua mãe, pela
inseparável relação de maternidade que ela tem com Cristo. Assim também Deus é chamado Senhor
pela inseparável relação real por que a criatura depende de Deus. E embora a relação de domínio não
seja real em Deus, contudo Deus é realmente chamado Senhor, pela dependência real que a ele liga a
criatura. E semelhantemente, Cristo é realmente chamado Filho da Virgem mãe, pela relação real de
maternidade que ela mantém com Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A natividade temporal causaria em Cristo uma filiação
temporal real, se ele fosse um sujeito capaz dessa filiação. O que não é possível, pois, um suposto
eterno não pode ser susceptível de uma relação temporal, como se disse. — Nem se pode dizer que
fosse susceptível de filiação temporal em razão da natureza humana, como o foi, da natividade
temporal; porque seria necessário, de certo modo, que a natureza humana pudesse ser sujeito da
filiação, assim como de certo modo o foi da natividade; assim, quando dizemos que um Etíope é branco,
quanto aos dentes, necessariamente o dente do Etíope é o sujeito da brancura. Ora, a natureza humana
de nenhum modo pode ser sujeito da filiação, porque essa relação respeita diretamente à pessoa.

RESPOSTA À SEGUNDA. — A filiação eterna não depende da maternidade no tempo; mas a essa filiação
eterna o nosso pensamento atribui, uma relação temporal dependente da mãe, da qual Cristo é
chamado filho em virtude de tal relação.

RESPOSTA À TERCEIRA. — A unidade e o ser se supõem mutuamente, como diz Aristóteles. Ora, pode
dar-se que um dos extremos de uma relação seja um ser real e o outro um ser não real, mas só de razão,
como no caso de um objeto conhecido e da ciência, como diz o Filósofo. Donde resulta também, que da
parte de um extremo, será uma só a relação, e muitas da parte do outro. Assim, entre os homens, os
pais dão lugar a uma dupla relação - a de paternidade e a de maternidade, especificamente diferentes,
pois embora sejam ambos princípios da geração, o pai o é por uma relação e a mãe, por outra. Mas se
muitos sujeitos fossem, pela mesma razão, o princípio de uma ação, por exemplo, no caso de muitos
que tiram um banco, todos seriam o fundamento de uma só e mesma relação. Quanto ao filho, há na
realidade só uma filiação; mas dupla, quanto ao seu conceito racional, enquanto correspondente às
relações paterna e materna, conforme o duplo respeito da razão. E assim também há em Cristo, de
certo modo, só uma filiação real, relativa ao Padre eterno; mas ele é também o fundamento de uma
relação temporal, pelo que respeita a sua mãe, no tempo.

## Art. 6 — Se Cristo nasceu sem sua mãe sofrer dores.
O sexto discute-se assim. — Parece que Cristo não nasceu sem sua mãe sofrer dores.

1. — Pois, como a morte do homem resultou do pecado do primeiro casal, conforme aquilo da Escritura
- Em qualquer dia que comeres a ele morrerás de morte, assim também a dor do parto, conforme ainda
a Escritura: Em dor parirás teus filhos. Ora, Cristo quis sofrer a morte. Logo, parece que, pela mesma
razão, o seu nascimento devia ser acompanhado das dores do parto.

2. Demais. — O fim se proporciona ao princípio. Ora, o fim da vida de Cristo foi cheio de dores, segundo
a Escritura: Verdadeiramente ele foi o que tomou sobre si as nossas dores. Logo, parece que também a
sua natividade foi acompanhada das dores do parto.

3. Demais. — Narra um autor que parteiras assistiram ao nascimento de Cristo; e essas são necessárias
só por causa das dores da parturiente. Logo, parece que a Santa Virgem deu à luz com dores,
Mas, em contrário, diz Agostinho, referindo-se à Virgem Mãe: Assim como a sua concepção deixou-lhe
intacta a virgindade, assim no seu parto nenhuma dor sofreu.

SOLUÇÃO. — As dores da parturiente são causadas pela compressão dos meatos por onde vem à luz o
filho. Ora, como dissemos, Cristo veio à luz sem detrimento da virgindade de sua mãe, que portanto não
sofreu nenhuma espécie de compressão. E por isso, nesse parto não houve nenhuma dor, como não
houve nenhuma corrupção, mas antes, houve uma alegria máxima por ter vindo ao mundo o homem
Deus, conforme àquilo da Escritura: Lançando germens, ela copiosamente brotará, como o lírio, e com
intensa atearia e muitos louvores de prazer saltará.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A dor que a mulher sofre no parto resultou da
concepção. Donde, depois de ter dito a Escritura: Em dor parirás teus filhos, acrescenta: e estarás sob o
poder de teu marido. Donde o dizer Agostinho, que dessa sentença foi excluída a Virgem Mãe de Deus
que, por ter sido isenta do pecado e ter concebido a Cristo sem nenhuma união carnal, gerou sem dor e,
sem violação da sua integridade, permanecendo totalmente virgem. Ora, Cristo sofreu a morte por
espontânea vontade, para satisfazer por nós, e não porque estivesse sujeito à supra referida sentença
de condenação, pois não fora réu de morte.

RESPOSTA À SEGUNDA. — Assim como Cristo, morrendo, livrou-nos da morte eterna, assim com as suas
dores livrou-nos das nossas. Por isso quis morrer no meio delas. Mas, as dores do parto de sua mãe não
seriam as de Cristo, que veio para satisfazer pelos nossos pecados. Logo, não era necessário que sua
mãe tivesse um parto doloroso.

RESPOSTA À TERCEIRA. — O Evangelho diz que a Santa Virgem enfaixou e reclinou numa manjedoura o
filho que deu à luz. E isso mostra ser falsa a narração do autor citado, cujo livro é apócrifo. Donde c dizer
Jerônimo: Nenhuma parteira aí esteve, nenhum cuidado de mãos servis e práticas. A própria mãe cuidou
do fruto das suas entranhas. Enfaixou, diz o Evangelho, e reclinou o menino numa manjedoura. O que
convence de delírio a narração apócrifa.

## Art. 7 — Se Cristo devia ter nascido em Belém.
O sétimo discute-se assim. — Parece que Cristo não devia ter nascido em Belém.

1. — Pois, diz a Escritura: De Sião saíra a lei e de Jerusalém a palavra do Senhor. Ora, Cristo é
verdadeiramente o Verbo de Deus. Logo, em Jerusalém é que devia ter vindo ao mundo.

2. Demais. — O Evangelho refere ter sido escrito, de Cristo, que será chamado Nazareno; lugar referente
aquilo de Isaías: Uma flor brotará da sua raiz, pois, Nazaré significa flor. Ora, uma pessoa tira a sua
denominação sobretudo do lugar onde nasceu. Logo, parece que devia ter nascido em Nazaré, onde foi
concebido e criado.

3. Demais. — O Senhor veio ao mundo a fim de anunciar a verdade da fé, conforme àquilo do
Evangelho: Eu para isso nasci e ao que vim ao mundo foi para dar testemunho da verdade. Ora, Isso
mais facilmente podia dar-se na cidade de Roma, que então era a dominadora de todo o mundo. Donde
Paulo, escrevendo aos Romanos, diz: Em todo o mundo é divulgada a vossa fé. Logo, parece que não
devia ter nascido em Belém.
Mas, em contrário, a Escritura: E tu, Belém Efrata, de ti é que me há de sair aquele que há de reinar em
Israel.

SOLUÇÃO. — Cristo quis nascer em Belém por duas razões. - Primeiro, porque foi feito da linhagem de
Davi, segundo a carne, como diz o Apóstolo. Ora, a Davi foi feita uma promessa especial, sobre Cristo,
como diz a Escritura: Disse o varão a favor do qual se decretou sobre o Cristo do Deus de Jacó. Por isso,
em Belém, onde nasceu Davi, também quis nascer, para que se manifestasse, no lugar mesmo da sua
natividade, o cumprimento da promessa feita. E é o que significa o Evangelista quando diz: Porque era
da casa e da família de Davi. - Segundo, porque, como diz Gregório, Belém significa a casa do pão: E foi o
próprio Cristo quem disse: Eu sou o pão vivo descido do céu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como Davi nasceu em Belém, assim também
escolheu Jerusalém para nela constituir a sede do seu reino e edificar o templo de Deus, de modo que
Jerusalém fosse ao mesmo tempo cidade real e sacerdotal. Ora, o sacerdócio de Cristo e o seu reino se
consumaram sobretudo pela sua paixão. Por isso, escolheu acertadamente, para lugar da sua
natividade, Belém e Jerusalém, para o da sua paixão. - E além disso, por esse modo, desprezava a glória
humana, pois, os homens se gloriam quando trazem a sua origem de cidades nobres e fazem disso
cabedal de sua honra. Cristo, ao contrário, quis nascer numa cidade obscura e sofrer o opróbrio numa
cidade nobre.

RESPOSTA À SEGUNDA. — Cristo quis fazer-se conhecido pela sua vida virtuosa e não pelo nascimento
segundo a carne. Por isso quis ser educado e criado na cidade de Nazaré. E nascer em Belém quase
como peregrino; pois, no dizer de Gregório, pela humanidade que assumiu nasceu em terra, por assim
dizer, estranha; não, certo, pelo poder, mas pela sua origem carnal. E Beda também diz que, veio ao
mundo numa hospedaria a fim de nos preparar muitas mansões na casa de seu Pai.

RESPOSTA À TERCEIRA. — Lê-se no Concílio Efesino, que se Cristo tivesse escolhido como sua pátria
Roma, a grande; haveriam talvez de atribuir a transformação, que operou no mundo, ao poder dos seus
cidadãos. Se tivesse nascido de um imperador, diriam que triunfou pelo poder imperial. Mas, para que
todos compreendessem que transformou o mundo pelo seu poder divino, quis escolher uma mãe
humilde e uma pátria pobre. - E. como diz o Apóstolo, escolheu Deus as coisas fracas do mundo, para
confundir os fortes. Por isso, a fim de melhor manifestar o seu poder. fez da própria Roma, cabeça do
mundo, também a cabeça da sua Igreja, como sinal da sua perfeita vitória, para que dela derivasse a fé
ao mundo universo, segundo àquilo da Escritura: Humilhará a cidade altiva e pisa-la-á o pé do pobre,
isto é, de Cristo, e os passos dos necessitados, isto é, dos Apóstolos Pedro e Paulo.

## Art. 8 — Se Cristo nasceu no tempo conveniente.
O oitavo discute-se assim. — Parece que Cristo não nasceu no tempo conveniente.

1. — Pois, Cristo veio ao mundo a fim de dar liberdade aos seus filhos. Ora, nasceu num tempo de
escravidão, em que todo o mundo é descrito como sujeito ao império de Augusto, quase feito dele
tributário, como refere o Evangelho. Logo, parece que Cristo não nasceu no tempo conveniente.

2. Demais. — As promessas sobre o nascimento de Cristo não foram feitas aos gentios, segundo àquilo
do Apóstolo: Dos quais é a promessa. Ora, Cristo nasceu num tempo em que governava um rei
alienígena, como se lê no Evangelho: Tendo nascido Jesus no tempo do rei Herodes. Logo, parece que
não nasceu no tempo conveniente.

3. Demais. — O tempo da presença de Cristo no mundo é comparado ao dia, por ser a luz do mundo,
como ele próprio disse: Importa que eu faça as obras daquele que me enviou enquanto é dia. Ora, no
verão os dias são mais longos que no inverno. Logo, tendo nascido no rigor do inverno, no oitavo dia das
Kalendas de Janeiro, parece que não nasceu no tempo conveniente.
Mas, em contrário, O Apóstolo: Quando veio o cumprimento do tempo, enviou Deus a seu filho, feito de
mulher, feito sujeito à lei.

SOLUÇÃO. — A diferença entre Cristo e os outros homens está em que estes nascem sujeitos às
exigências do tempo, ao passo que Cristo, como Senhor e Criador de todos os tempos, escolheu para si
o tempo em que nascesse, como escolheu sua mãe e a sua pátria. E como as coisas que há foram por
Deus ordenadas e convenientemente dispostas, resulta que Cristo nasceu no tempo mais conveniente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo veio tirar-nos do estado de escravidão para nos
dar a liberdade. Por isso, assim como assumiu a nossa mortalidade, para nos dar a vida, assim, no dizer
de Beda. dignou-se incarnar no tempo em que logo depois de nascido, foi inscrito no censo o e César,
conquistando assim a nossa liberdade com a sua escravidão. - E além disso, nesse tempo, quando todo o
mundo estava sujeito ao mesmo poder, reinava a máxima paz. Por isso, convinha que em tal tempo
nascesse Cristo, que é a nossa paz, ele que de dous fez um, como diz o Apóstolo. Donde o dizer
Jerônimo: Se perscrutarmos as histórias antigas, veremos que até o vigésimo oitavo ano de César
Augusto, houve discórdias e m todo o universo: mas, com o nascimento do Senhor, cessaram todas as
guerras, como o diz a Escritura: Não levantará a espada uma nação contra outra nação. - Era também
conveniente que num tempo em que um só príncipe governava todo o mundo. Cristo nascesse, ele que
vinha congregar os seus numa mesma unidade, a fim de existir um só rebanho e um só pastor, no dizer
do Evangelho.

RESPOSTA À SEGUNDA. — Cristo quis nascer no tempo em que governava um rei alienígena para
cumprir-se a profecia de Jacó, que reza: Não se tirará o cetro de Judá, nem general que proceda da sua
coxa, a menos que não venha aquele que deve ser enviado. Pois, como diz Crisóstomo, enquanto a
gente judaica era governada pelos judeus, embora pecadores, os profetas eram enviados para salvá-la.
Mas então nasceu Cristo, quando a lei de Deus dependia do poder de um rei iníquo; porque, uma
doença grave e desesperadora exigia um médico mais perito.

RESPOSTA À TERCEIRA. — Como se disse, Cristo quis nascer quando começou a tomar incremento a luz
do dia, para mostrar que vinha para fazer crescerem os homens na luz divina, como diz o Evangelho:
Para alumiar os que vivem de assento nas trevas e na sombra da morte. - Semelhantemente, escolheu
para tempo da sua natividade o rigor do inverno, a fim de sofrer por nós os padecimentos da carne.