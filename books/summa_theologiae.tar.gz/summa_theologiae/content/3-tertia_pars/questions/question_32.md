# Questão 32: Do princípio ativo na concepção de Cristo
Em seguida, devemos tratar do princípio ativo na concepção de Cristo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a obra da concepção de Cristo deve ser atribuída ao Espírito Santo.
O primeiro discute-se assim. — Parece que a obra da concepção de Cristo não deve ser atribuída ao
Espírito Santo.

1. — Pois, conforme diz Agostinho, são indivisas as obras da Trindade, como indivisa é a essência da
Trindade. Ora, a obra da concepção de Cristo é uma obra divina. Logo, parece que não deve ser
atribuída, antes, ao Espírito Santo, que ao Pai ou ao Filho.

2. Demais. — O Apóstolo diz: Quando veio o cumprimento enviou Deus a seu Filho, feito de mulher.
Expondo o que, diz Agostinho: Foi certamente mandado por quem o fez nascer de uma mulher. Ora, a
missão do Filho é atribuída principalmente ao Pai, como se estabeleceu na Primeira Parte. Logo,
também a concepção, enquanto foi feito de mulher, deve ser principalmente atribuída ao Pai.

3. Demais. — A Escritura diz: A Sabedoria edificou para si uma casa. Ora, Cristo é a Sabedoria de Deus,
segundo o Apóstolo: Cristo, Virtude de Deus e Sabedoria de Deus. Ora, a casa dessa Sabedoria é o corpo
de Cristo, também chamado o seu templo, segundo o Evangelho: Mas ele falava do templo do seu
corpo. Logo, parece que a obra da concepção do corpo de Cristo deve ser atribuída principalmente ao
Filho. Portanto, não ao Espírito Santo.
Mas, em contrário, o Evangelho: O Espírito Santo descerá sobre ti, etc.

SOLUÇÃO. — A obra da concepção do corpo de Cristo foi realizada por toda a Trindade. Mas é atribuída
ao Espírito Santo, por três razões. — Primeiro, porque isso convinha à causa da Encarnação, considerada
relativamente a Deus. Pois, o Espírito Santo é o amor do Pai e do Filho, como estabelecemos na Primeira
Parte. Ora, é uma prova máxima do amor de Deus que o Filho de Deus tivesse assumido a carne no
ventre virginal; donde o dizer o Evangelho: Assim amou Deus ao mundo, que lhe deu a seu Filho
unigênito. — Segundo, porque isso convinha à causa da Encarnação, relativamente à natureza assumida.
Pois, por aí entendemos que a natureza humana foi assumida pelo Filho de Deus na unidade de pessoa,
não por causa de nenhum mérito, senão só pela graça. E esta é atribuída ao Espírito Santo, segundo o
Apóstolo: Há repartição de graça, mas um mesmo é o Espírito. Donde o dizer Agostinho: O modo pelo
qual Cristo nasceu do Espírito Santo nos insinua a graça de Deus; pois, o homem, no momento mesmo
em que a sua natureza começou a existir, e sem nenhum mérito anterior, foi tão perfeitamente unido
ao Verbo de Deus na unidade de pessoa, que o Filho do homem foi o mesmo que o Filho de Deus. —
Terceiro, porque convinha ao termo da Encarnação. Pois, o fim da Encarnação foi fazer com que o
homem Cristo concebido fosse santo e Filho de Deus. Ora, ambos esses efeitos se atribuem ao Espírito
Santo. Pois, por ele os homens se tornam filhos de Deus, segundo o Apóstolo: Porque vós sois filhos de
Deus, mandou Deus aos vossos corações o Espírito de seu Filho, que clama: Pai, Pai. E ele é também o
Espírito de santificação, no dizer ainda do Apóstolo. Ora, assim como os outros homens são santificados
espiritualmente para serem os filhos adotivos de Deus, assim Cristo foi concebido na santidade, pelo
Espírito Santo, para que fosse naturalmente o Filho de Deus. Donde, conforme uma glosa, a palavra do
Apóstolo — Que foi predestinado Filho de Deus com poder — é explicada pelo que imediatamente se
lhe segue - segundo o Espírito de santificação, isto é, por ter sido concebido do Espírito Santo. E o
próprio Anjo, anunciando pelas palavras que primeiro pronunciou — O Espírito Santo descerá sobre ti —
conclui: E por isso mesmo o santo que há de nascer de ti será chamado Filho de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A obra da concepção é por certo comum a toda a
Trindade; mas de um certo modo é atribuída a cada uma das Pessoas. Assim, ao Pai é atribuída a
autoridade sobre a pessoa do Filho, que por essa concepção assumiu para si a carne. Ao Filho é atribuída
a assunção mesma da carne. Mas ao Espírito Santo é atribuída a formação do corpo assumido pelo Filho.
Pois, o Espírito Santo é o Espírito do Filho, segundo o Apóstolo: Mandou Deus o Espírito de seu Filho.
Porque, assim como a virtude da alma, existente no sêmen, pelo espírito que o sêmen contém, forma o
corpo, na geração dos outros homens, assim a Virtude de Deus, que é o Filho mesmo, segundo aquilo do
Apóstolo - Cristo, virtude de Deus, formou, mediante o Espírito Santo. o corpo que assumiu. E isso
mesmo o significam as palavras do anjo quando declarou: O Espírito Santo descerá sobre ti, como para
preparar e formar a matéria do corpo de Cristo; é a Virtude do Altíssimo, isto é, Cristo, te cobrirá da sua
sombra, isto é, como ensina Gregório, o teu corpo humano receberá a luz incorpórea da Divindade; pois,
a sombra supõe a luz e um corpo. E a expressão - Altíssimo, significa o Pai, cuja virtude é o Filho.

RESPOSTA À SEGUNDA. — A missão se refere à pessoa assumente, enviada pelo Pai; enquanto que a
concepção se refere ao corpo assumido, formado por obra do Espírito Santo. E assim, embora a missão
e a concepção tivessem o mesmo sujeito, diferindo porém pelas suas noções respectivas, a missão se
atribui ao Pai; a obra da concepção, porém, ao Espírito Santo; e enfim, o assumir a carne, ao Filho.

RESPOSTA À TERCEIRA. — Diz Agostinho: A questão vertente pode ser entendida em dois sentidos. Num
primeiro sentido, a casa de Cristo é a Igreja, que edificou com o seu sangue. Depois, também podemos
chamar casa ao seu corpo, assim como foi chamado o seu templo. Quanto ao feito do Espírito Santo, foi
obra do Filho de Deus, por causa da unidade de natureza e de vontade.

## Art. 2 — Se Cristo deve ser considerado como concebido do Espírito Santo.
O segundo discute-se assim. — Parece que Cristo não deve ser considerado como concebido do
Espírito Santo.
1 — Pois, àquilo do Apóstolo: Dele e por ele e nele existem todas as coisas, diz a Glosa de Agostinho:
Atendamos a que não diz — de ipso, mas — ex ipso; porque dele (ex ipso) se originou o céu e a terra,
pelos ter feito; mas não dele (de ipso), como se o céu e a terra fossem substância sua. Ora, o Espírito
Santo não formou o corpo de Cristo da sua substância. Logo, não devemos considerar Cristo como
concebido do Espírito Santo.

2. Demais. — O principio ativo na concepção de um ser se comporta como o sêmen na geração. Ora, o
Espírito Santo não exerceu nenhuma função seminal na geração de Cristo. Assim, diz Jerônimo: Nós não
dizemos, como certos impissimamente o pretenderam, que o Espírito Santo desempenhou uma função
seminal; mas dizemos que o corpo de Cristo foi feito, isto é, formado pelo poder e pela virtude do
Criador. Logo, não podemos considerar Cristo como concebido do Espírito Santo.

3. Demais. — Um mesmo corpo não pode ser formado de dois outros sem que estes de certo modo se
misturem. Ora, o corpo de Cristo foi formado da Virgem Maria. Se, pois, dissermos que Cristo foi
concebido do Espírito Santo, parece que houve uma mistura entre o Espírito Santo e a matéria que a
Virgem ministrou: O que é claramente falso. Logo, Cristo não deve ser considerado como concebido do
Espírito Santo.
Mas, em contrário, o Evangelho: Antes de coabitarem, se achou ter ela concebido por obra do Espírito
Santo.

SOLUÇÃO. — Não dizemos que só o corpo de Cristo foi concebido mas também que o foi o próprio
Cristo, em razão do seu corpo. Ora, descobrimos no Espírito Santo uma dupla relação com Cristo. Assim,
com o Filho mesmo de Deus, que consideramos como concebido, tem a relação de consubstancialidade;
e com o corpo de Cristo tem a relação de causa eficiente. Ora, a preposição de designa ambas essas
relações; assim, como quando dizemos, que um certo homem nasceu de seu pai. Por onde, podemos
convenientemente dizer que Cristo foi concebido do Espírito Santo, para significar que a eficiência do
Espírito Santo se refere ao corpo assumido, e a consubstancialidade, à pessoa assumente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O corpo de Cristo, por não ser consubstancial com o
Espírito Santo, não pode ser propriamente considerado como concebido do Espírito Santo, mas antes,
em virtude (ex) do Espirito Santo. Por isso diz Ambrósio: O que procede de alguém (ex), ou procede da
sua substância ou do seu poder; da substância, como o Filho, que procede da substância do Pai; do
poder, como de Deus procede tudo, sendo também a esse modo que Maria concebeu no seu ventre, do
Espírito Santo.

RESPOSTA À SEGUNDA. — Neste ponto há divergência entre Jerônimo e certos outros doutores, que
afirmam ter o Espírito Santo, na concepção de Cristo, exercido uma função seminal. Assim, diz
Crísostomo: O Espírito Santo precedeu o Unigênito de Deus, que a Virgem ia conceber, de modo que a
divindade, exercendo a função do sêmen, o Cristo nascesse, segundo o corpo, na santidade. E
Damasceno diz: A Sabedoria e a Virtude de Deus, desempenhando o papel do sêmen, cobriram-na com
a sua sombra. — Mas esta divergência facilmente se resolve. Porque entendendo-se por sêmen uma
virtude ativa, então Crisóstomo e Damasceno comparam o Espírito Santo, ou também o Filho, que é a
Virtude do Altíssimo, ao sêmen. Mas, se se entende por sêmen a substância corporal, transmutada na
concepção, nesse caso Jerônimo nega, que o Espírito Santo tivesse exercido a função de sêmen.

RESPOSTA À TERCEIRA. — Como diz Agostinho, não é, no mesmo sentido que se diz ter sido Cristo
concebido ou nascido do Espírito Santo e da Santa Virgem. Pois de Maria Virgem nasceu materialmente;
mas, do Espírito Santo, como do princípio ativo. Por isso, não houve aí nenhuma mistura.

## Art. 3 — Se o Espírito Santo deve ser considerado pai de Cristo segundo a humanidade.
O terceiro discute-se assim. — Parece que o Espírito Santo deve ser considerado pai de Cristo segundo
a humanidade.

1. — Pois, segundo o Filósofo, o pai dá o princípio ativo na geração e a mãe ministra a matéria. Ora, a
Santa Virgem é considerada mãe de Cristo, por causa da matéria que ministrou na sua concepção. Logo,
parece que também o Espírito Santo pode ser considerado pai de Cristo, por ter sido o princípio ativo na
sua concepção.

2. Demais. — Assim como o coração dos outros santos foi formado pelo Espírito Santo, assim também o
foi o corpo de Cristo. Ora, por causa dessa formação, os outros são considerados filhos de toda a
Trindade; e por consequência, do Espírito Santo. Logo, parece que Cristo deve ser considerado filho do
Espírito Santo.

3. Demais. — Deus é considerado nosso pai por nos ter feito, segundo a Escritura: Não é ele teu pai, que
te possuiu, e te fez e te criou? Ora, o Espírito Santo fez o corpo de Cristo, como se disse. Logo, o Espírito
Santo deve ser considerado corpo de Cristo, por causa do corpo que formou.
Mas, em contrário, Agostinho diz: Cristo não nasceu como filho do Espírito Santo, mas sim, como filho
de Maria Virgem.

SOLUÇÃO. — As qualidades de paternidade, de maternidade e de filiação resultam da geração; não de
qualquer, mas propriamente, da geração dos seres vivos e sobretudo dos animais. Assim, não dizemos
que há um fogo gerado por outro, gerador, senão só metafóricamente. Mas assim o dizemos dos
animais, cuja geração é mais perfeita. Contudo, nem tudo o gerado nos animais recebe o nome de
filiação, mas só o gerado semelhante ao gerador, Por isso, como adverte Agostinho, não dizemos que o
cabelo nascido no homem é filho do homem; nem, que um recém-nascido é filho do sêmen. Pois, nem o
cabelo tem a semelhança do homem, nem o recém-nascido a semelhança do sêmen, mas, do homem
gerador. E se essa semelhança for perfeita, perfeita será a filiação, tanto na ordem divina como na
humana. Mas se a semelhança for imperfeita, imperfeita será também a filiação. Assim, o homem é uma
semelhança imperfeita de Deus, por ter sido criado à imagem de Deus e por ter sido criado uma
segunda vez pela semelhança da graça. Por onde, de um e outro modo, o homem pode ser considerado
filho de Deus, tanto por ter sido criado à sua imagem, como por se lhe ter assemelhado pela graça.
Devemos porém notar, que o nome atribuído perfeitamente a um ser, não se lhe deve atribuir de um
modo imperfeito. Assim, por ser Sócrates considerado homem, no sentido próprio desta expressão,
nunca lhe chamaremos homem no sentido em que consideramos homem o que só em pintura o é,
embora Sócrates se assemelhasse a outro homem.
Ora, Cristo é o Filho de Deus na acepção perfeita da palavra filiação. Por isso, embora pela sua natureza
humana fosse criado e justificado. não deve ser chamado Filho de Deus, nem em razão da criação, nem
em razão da justificação. Mas só em razão da geração eterna, pela qual é o Filho só do Pai. Portanto, de
nenhum modo deve Cristo ser considerado filho do Espírito Santo, nem também de toda a Trindade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na concepção de Cristo, de Maria Virgem, esta ministrou
a matéria com semelhança específica. Por isso dizemos que Cristo é seu filho. Mas Cristo, enquanto
homem, foi concebido do Espírito Santo como do princípio ativo: mas não pela semelhança específica
como dizemos que um filho nasce de seu pai. Por isso não dizemos que Cristo é filho do Espírito Santo.

RESPOSTA À SEGUNDA. — Os homens, formados espiritualmente pelo Espírito Santo, não podem
chamar-se filhos de Deus, na acepção perfeita da palavra filiação. Por isso, chamam-se filhos de Deus
por uma filiação imperfeita, fundada na semelhança da graça, que procede de toda a Trindade. Mas,
isso não se dá com Cristo, como dissemos.
E o mesmo devemos RESPONDER À TERCEIRA OBJEÇÃO.

## Art. 4 — Se a Santa Virgem foi de algum modo, princípio ativo na concepção do corpo de Cristo.
O quarto discute-se assim. — Parece que a Santa Virgem foi de algum modo princípio ativo na
concepção do corpo de Cristo.

1. — Pois, como diz Damasceno, o Espírito Santo desceu sobre a Virgem para purificá-la e dar-lhe a
virtude de receber o Verbo de Deus e simultaneamente a de gerar. Ora, a virtude geratriz passiva já ela
a tinha da natureza, como qualquer outra mulher. Logo, deu-lhe a virtude geratriz ativa. E assim foi, de
algum modo, princípio ativo na concepção de Cristo.

2. Demais. — Todas as potências da alma vegetativa são virtudes ativas, como diz o Comentador. Ora, a
potência geradora tanto na mãe como no pai, pertence à alma vegetativa. Logo, tanto o pai como a mãe
cooperam ativamente na concepção da prole.

3. Demais. — A mãe ministra a matéria da concepção, da qual naturalmente se forma o corpo do filho.
Ora, a natureza é um princípio intrínseco de movimento. Logo, parece que na matéria mesma, que a
Santa Virgem ministrou para a concepção de Cristo, houve um princípio ativo.
Mas, em contrário, o princípio ativo na geração é o chamado germen seminal. Ora, como diz Agostinho,
o corpo de Cristo só assumiu da Virgem a matéria corpórea, por virtude de uma concepção e formação
divina; logo, não por nenhum germen seminal humano. Logo, a Santa Virgem não exerceu nenhum
papel ativo na concepção do corpo de Cristo.

SOLUÇÃO. — Certos dizem que a Santa Virgem foi, de certo modo princípio ativo na concepção de
Cristo, por virtude natural e sobrenatural. — Por virtude natural, por dizerem que em toda matéria há
um princípio ativo; pois do contrário, como pensam, não haveria nenhuma transmutação natural. E
nisso se enganam. Porquanto o que produz as transmutações naturais é um princípio intrínseco, não só
ativo, mas também passivo. Assim, como expressamente o diz o Filósofo, nos corpos graves e leves há
um princípio passivo do movimento natural, e não ativo. Nem é possível a matéria contribuir para a sua
formação, porque não é atual. Também não é possível um corpo mover-se a si mesmo, sem se dividir
em duas partes - uma a motora e outra a movida, o que só se dá com os seres animados, como
Aristóteles o demonstra. — Por virtude sobrenatural, por ensinarem que a mãe não somente deve
ministrar a matéria, que é o sangue menstrual, mas também o sêmen, que misturado com o sêmen
masculino tem uma virtude ativa na geração. E como na Santa Virgem não houve nenhuma resolução do
sêmen, por causa da sua integérrima virgindade, dizem que o Espírito Santo lhe atribuiu uma virtude
sobrenatural ativa na concepção do corpo de Cristo, virtude que as outras mães tem pelo sêmen
emitido. — Mas isto é inadmissível. Porque, existindo todo ser em vista da sua operação como diz
Aristóteles, a natureza não distinguiria, na obra da geração, o sexo masculino do feminino, se não
houvesse distinção entre a obra do pai e a da mãe. Ora, na geração distingue-se a obra do agente da do
paciente. Donde se conclui, que a virtude ativa pertence toda ao pai; e a passiva, à mãe. Por isso, nas
plantas, em que essas duas virtudes coexistem juntas, não há distinção entre macho e fêmea. Como,
pois, não foi concedido à Santa Virgem ser o pai, mas a mãe de Cristo, resulta consequentemente que
não recebeu nenhuma função ativa, na concepção de Cristo. Em nenhuma hipótese; pois, se tivesse
agido ativamente, teria sido o pai de Cristo; e se, como certos afirmam, não tivesse exercido o poder
divino, que lhe foi conferido, tê-lo-ía recebido em vão. — Donde devemos concluir, que na concepção
de Cristo, a Santa Virgem nada obrou ativamente, mas só ministrou a matéria. Mas, exerceu de algum
modo, antes da concepção, uma função ativa, preparando a matéria para que fosse apta à concepção.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A referida concepção teve três privilégios: ter sido isenta
do pecado original, não ter sido obra só do homem, mas de Deus e do homem e, enfim, ter sido a
concepção de uma virgem. E esses três privilégios a Virgem os teve do Espírito Santo. Por isso, diz
Damasceno, quanto ao primeiro, que o Espírito Santo desceu sobre a Virgem, para purificá-la, isto é,
preservá-la de conceber com pecado original. Quanto ao segundo, diz: e dar-lhe a virtude de receber o
Verbo de Deus, isto é, de conceber o Verbo de Deus. Quanto ao terceiro: e simultaneamente a de gerar,
de modo que, pudesse gerar sem deixar de ser virgem — não, certo, ativamente, mas, passivamente,
como as outras mães o conseguem pelo sêmen masculino.

RESPOSTA À SEGUNDA. — A potência gera triz da mulher é imperfeita em relação à do homem. Por
isso, assim como nas artes, a arte inferior dispõe a matéria na qual a superior infunde a forma, como diz
Aristóteles, assim também a virtude geratriz feminina prepara a matéria, enquanto que a masculina
informa a matéria preparada.

RESPOSTA À TERCEIRA. — Para uma transmutação ser natural, não é preciso que exista na matéria um
principio ativo, mas apenas passivo, como se disse.