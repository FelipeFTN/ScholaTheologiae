# Questão 46: Da Paixão de Cristo
Em seguida devemos tratar do concernente à partida de Cristo, deste mundo. E primeiro, da sua paixão.
Segunda, da sua morte. Terceiro, da sua sepultura. Quarto, da descida aos infernos. Sobre a paixão
temos três considerações a fazer. Primeiro, da sua paixão em si mesma. Segunda, da causa eficiente da
paixão. Terceiro, do fruto da paixão.
Na primeira questão discutem-se doze artigos:

## Art. 1 — Se era necessário Cristo sofrer pela liberação do gênero humano.
O primeiro discute-se assim. Parece que não era necessário Cristo sofrer pela liberação do gênero
humano.

1. — Pois, só Deus podia liberar o gênero humano, segundo a Escritura: Porventura não sou eu o Senhor
e não é assim que não há outro Deus senão eu? Deus justo e salvador não no há fora de mim. Ora, Deus
não está sujeito a nenhuma necessidade, o que lhe repugnaria à onipotência. Logo, não era necessário
que Cristo sofresse.

2. Demais. — O necessário se opõe ao voluntário. Ora, Cristo sofreu por vontade própria, como o diz a
Escritura: Foi oferecido porque ele mesmo quis. Logo, não foi necessário que sofresse.

3. Demais. — Como diz a Escritura, todos os caminhos do Senhor são misericórdia e verdade. Ora, não
era necessário que sofresse, por parte da misericórdia divina, a qual, assim como distribui os seus dons
gratuitamente, assim também há de gratuitamente perdoar as dívidas sem satisfação. Nem por parte da
justiça divina, pela qual o homem merecera a condenação eterna. Logo, parece que não era necessário
ter Cristo sofrido pela liberação dos homens.

4. Demais. — A natureza angélica é mais excelente que a humana, como ensina Dionísio. Ora, Cristo não
sofreu para reparar a natureza angélica, que tinha pecado. Logo, parece que não lhe fora também
necessário sofrer pela salvação do gênero humano.
Mas, em contrário, o Evangelho: Como Moisés no deserto levantou a serpente, assim importa que seja
levantado o Filho do homem, para que todo o que crê nele não pereça, mas tenha a vida eterna. O que
se entende da exaItação na cruz. Logo, parece que Cristo devia ter sofrido.

SOLUÇÃO. — Como o ensina o Filósofo, a palavra necessária é susceptível de muitas acepções. — Numa,
significa o que não pode por sua natureza, apresentar-se de modo diferente. E, nesse sentido, é claro
que não foi necessário ter Cristo sofrido, nem da parte de Deus nem da do homem. — Noutra, o
necessário o é em virtude de uma causa exterior. Se essa causa for eficiente ou motriz, produz a
necessidade de coação; tal o caso de quem não pode andar por causa da violência do que o detém. Se
porém essa causa exterior geratriz da necessidade for o fim, o necessário o será pela suposição do fim;
isto é, quando o fim de nenhum modo pode ser atingido sem esse meio necessário, ou não o pode
convenientemente, senão recorrendo a tal meio. Logo, que Cristo sofresse não era necessário por uma
necessidade de coação: nem por parte de Deus, que o determinou a sofrer, nem por parte do próprio
Cristo, que sofreu voluntariamente.
Necessário, porém o foi pela necessidade de fim. O que podemos entender de três modos. — Primeiro,
relativamente a nós, que fomos liberados pela sua paixão, segundo o Evangelho: Importa que seja
levantado o Filho do homem, para que todo o que crê nele não pereça, mas tenha a vida eterna. —
Segundo, relativamente ao próprio Cristo, que pelas humilhações da paixão mereceu a glória da
exaltação. E a isso se refere o Evangelho quando pergunta: Porventura não importava que o Cristo
sofresse estas coisas e que assim entrasse na sua glória? — Terceiro, relativamente a Deus, cuja
determinação concernente à paixão de Cristo foi profetizada nas Escrituras e prefigurada, nas
observâncias do Velho Testamento. E é o que diz o Evangelho: O Filho do homem vai segundo o que
está decretado. E mais adiante: É o que queriam dizer as palavras que eu vos dizia quando ainda estava
convosco, que era necessário que se cumprisse tudo o que de mim estava escrito na lei de Moisés e nos
profetas e nos salmos. E ainda: Assim é que estava escrito que importava que o Cristo padecesse e que
ressurgisse dos mortos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. - A objeção colhe, quanto à necessidade imposta pela
coação, da parte de Deus.

RESPOSTA À SEGUNDA. — A objeção colhe, quanto à necessidade imposta pela coação, da parte do
homem Cristo.

RESPOSTA À TERCEIRA. — Liberar o homem pela paixão de Cristo, convinha tanto à misericórdia como à
justiça de Cristo. À justiça, porque com a sua paixão Cristo satisfez pelo pecado do gênero humano; e
assim o homem foi liberado pela justiça de Cristo. À misericórdia, de seu lado, porque não podendo o
homem por si mesmo satisfazer pelo pecado de toda a natureza humana, como se disse, Deus lhe deu o
seu Filho único como reparador, segundo aquilo do Apóstolo: Tendo sido justificados gratuitamente por
sua graça, pela redenção que tem em Jesus Cristo, ao qual propôs Deus para ser vítima de propiciação
pela fé no seu sangue. O que implicava uma misericórdia mais abundante que se tivesse perdoado os
pecados, sem satisfação. Donde o dizer o Apóstolo: Deus, que é rico em misericórdia, pela sua
extremada caridade, com que nos amou, ainda quando estávamos mortos pelos pecados, nos deu vida
juntamente em Cristo.

RESPOSTA À QUARTA. — O pecado do anjo não era reparável, como o era o do homem, como resulta
do que foi dito na Primeira Parte.

## Art. 2 — Se era possível outro modo da liberação humana que não fosse a paixão de Cristo.
O segundo discute-se assim. — Parece que não era possível outro modo da liberação humana que não
fosse a paixão de Cristo.

1. — Pois, diz o Senhor: Se o grão de trigo que cai na terra não morrer fica ele só; mas se ele morrer
produz muito fruto. E Agostinho explica, que ele se considerava como o grão. Se, portanto, não tivesse
sofrido a morte, não teria de outro modo produzido da nossa liberação.

2. Demais. — Como lemos no Evangelho, o Senhor diz ao Pai: Pai meu, se este cálice não pode passar
sem que eu o beba, faça-se a tua vontade. Ora, refere-se ao cálice da paixão. Logo, a paixão de Cristo
não podia ser evitada. E por isso diz Hilário: Esse cálice não podia passar sem que ele o bebesse porque
não podemos ser resgatados senão pela sua paixão.

3. Demais. — A justiça de Deus exigia que o homem fosse liberado do pecado, mediante a satisfação de
Cristo, pela sua paixão. Ora, Cristo não podia evitar a paixão, como o diz o Apóstolo: Se não cremos, ele
permanece fiel; não pode negar-se a si mesmo. Mas negar-se-ia a si mesmo, se negasse a sua justiça,
pois ele é a própria justiça. Logo, parece que não era possível o homem ser liberado de outro modo
senão pela paixão de Cristo.

4. Demais. — A fé é incompatível com todo e qualquer erro. Ora, os antigos Patriarcas acreditavam que
Cristo haveria de sofrer. Logo, parece que era inevitável, que Cristo sofresse.
Mas, em contrário, diz Agostinho: Afirmamos que é bom e consentâneo com a dignidade divina o modo
pelo qual o mediador entre Deus e os homens, o homem Jesus Cristo, Deus, se dignou nos liberar.
Contudo, mostremos também, que Deus dispunha ainda de outros modos possíveis, ao poder de quem
todas as causas estão igualmente sujeitas.

SOLUÇÃO. — De dois modos podemos dizer que uma coisa é possível ou impossível. Primeiro, simples e
absolutamente falando; de outro modo, por hipótese. - Ora, simples e absolutamente falando, era
possível a Deus liberar o homem de outro modo que não pela paixão de Cristo; pois, como diz o
Evangelho, a Deus nada é impossível. Mas, hipoteticamente falando, era. impossível. Pois, sendo
impossível a presciência de Deus enganar-se e a sua vontade ou disposição anular-se, não era
simultaneamente possível, suposta a presciência de Deus e a sua preordenação, relativamente à paixão
de Cristo, este não sofrer e o homem ser liberado por outro modo do que pela sua paixão. E o mesmo
devemos dizer de tudo o de que Deus tem presciência e que preordena, como na Primeira Parte ficou
preestabelecido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Senhor nesse lugar, fala, suposta a presciência e a
preordenação de Deus, pela qual fora ordenado que o fruto da salvação humana não resultaria senão da
paixão de Cristo. E do mesmo modo devemos entender o texto citado na SEGUNDA OBJEÇÃO: Se este
cálice não pode passar sem que eu o beba, isto é, porque tu assim o dispuseste. E por isso acrescenta:
Faça-se a tua vontade.

RESPOSTA À TERCEIRA. — Também a referida justiça depende da vontade divina, que exige do gênero
humano uma satisfação pelo pecado. Mas, se quisesse, sem qualquer satisfação, liberar o homem do
pecado, não agiria contra a justiça. Pois, o juiz que deve punir a culpa incorrida contra terceiros - por
exemplo, contra outra pessoa, ou contra toda a república ou contra um chefe elevado em dignidade -
não pode, por dever de justiça, demitir a culpa sem a pena. Mas, Deus não tem nenhum superior, sendo
ele o bem supremo e comum de todo o universo. Logo, demitindo o pecado que por natureza é culposo,
porque ofende a Deus, a ninguém lesa: assim como quem quer que perdoa uma ofensa contra si
cometida, sem nenhuma satisfação, age misericordiosa e não injustamente. Por isso Davi, implorando
misericórdia, dizia: Contra ti só pequei; como se dissesse: Podes me perdoar sem injustiça.

RESPOSTA À QUARTA. — A fé humana e também as divinas Escrituras, em que se funda a fé, apóiam-se
na presciência e na ordenação divina. Por isso a necessidade procedente da suposição da fé humana e
das divinas Escrituras, e a da presciência e vontade divinas, tem a mesma razão.

## Art. 3 — Se havia outro modo mais conveniente da liberação humana do que pela paixão de Cristo.
O terceiro discute-se assim. — Parece que havia outro modo mais conveniente da liberação humana
do que pela paixão de Cristo.

1. — Pois, a natureza nas suas obras imita as obras divinas, como regulada e movida que é por Deus.
Ora, a natureza não faz por dois meios o que pode fazer por um só. Logo, como Deus podia liberar o
homem pela sua só vontade, parece não era conveniente que se acrescentasse a paixão de Cristo para a
liberação do gênero humano.

2. Demais. — As obras da natureza se realizam de maneira mais conveniente que o que se faz por
violência; porque a violência é uma como ruína ou destruição do que faz a natureza, segundo o Filósofo.
Ora, a paixão de Cristo implicava a morte violenta. Logo, era mais conveniente que Cristo liberasse o
homem morrendo de morte natural, do que pela paixão.

3. Demais. — É convenientíssimo que quem retém uma coisa, violenta e injustamente, seja despojado
dela por um poder superior. Donde o dito da Escritura: Vós fostes vendidos por nada, e sem prata sereis
resgatados. Ora, o diabo não tinha nenhum poder sobre o homem, a quem enganava pela fraude e a
quem retinha, por uma como violência, na escravidão. Logo, parece que teria sido, mais conveniente
que Cristo despojasse o diabo, em virtude do seu simples poder, do que pela sua paixão.
Mas, em contrário, diz Agostinho: Não havia outro meio mais conveniente de curar a miséria do que
pela paixão de Cristo.

SOLUÇÃO. — Tanto um meio é mais conveniente para conseguir um fim, quanto mais ele faz
concorrerem elementos conducentes ao fim. Ora, o ser o homem liberado pela paixão de Cristo foi
causa de concorrerem muitos elementos conducentes à salvação do mesmo, além da liberação do
pecado. — Assim, primeiro, desse modo o homem conhece quanto Deus o ama; o que o excita a amá-lo
mais, e nisso consiste a perfeição da salvação humana. Donde o dizer o Apóstolo: Deus faz brilhar a sua
caridade em nós porque ainda quando éramos pecadores, morreu Cristo por nós. — Segundo, porque
por esse meio nos deu o exemplo da obediência, da humildade, da constância, da justiça e das demais
virtudes reveladas na paixão de Cristo e que são necessárias à salvação humana. Por isso diz a Escritura:
Cristo padeceu por nós, deixando-vos exemplo para que sigais as suas pisadas. — Terceiro, porque
Cristo, com a sua paixão, não somente liberou o homem do pecado, mas ainda lhe mereceu a graça
justificante e a glória da beatitude como a seguir se dirá. — Quarto, porque, assim, uma necessidade
maior impôs ao homem conservar-se imune do pecado, segundo aquilo do Apóstolo: Porque vós fostes
comprado por um grande preço; glorificai, pois, e trazei a Deus no vosso corpo. — Quinto, porque
contribuiu para maior dignidade do homem, de modo que assim como fora vencido e enganado pelo
diabo, assim também fosse ele mesmo quem vencesse o diabo; e assim como o homem mereceu a
morte, assim também, morrendo, a vencesse a ela, conforme o dizer do Apóstolo: Graças a Deus, que
nos deu a vitória, por Jesus Cristo. — Por isso foi mais conveniente que, pela paixão de Cristo fossemos
liberados, do que pela só vontade de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Também a natureza, para produzir uma obra de modo
mais conveniente, aplica vários meios para um mesmo fim; assim, dois olhos, para ver. E o mesmo faz
em casos semelhantes.

RESPOSTA À SEGUNDA. — Como diz Crisóstomo, Cristo veio destruir não a sua própria morte, pois,
sendo a vida não estava sujeito a morrer; mas a dos homens. Por isso não depôs o seu corpo por uma
morte natural, mas quis sofrê-la infligida pelos outros homens. Pois, se no seu corpo tivesse adoecido e
na presença de todos, morrido, seria incompreensível que quem veio curar as doenças alheias tivesse o
seu próprio corpo sujeito a elas. E se, sem nenhuma doença, tivesse se despojado do corpo, para se
mostrar em seguida, não lhe acreditariam quando falasse da sua ressurreição. Pois, como teria Cristo
manifestado a vitória sobre a morte, se não tivesse mostrado, sofrendo-a na presença de todos, que a
morte foi vencida pela incorrupção do corpo?

RESPOSTA À TERCEIRA. — Embora o diabo tivesse atacado o homem injustamente, contudo o homem
fora, por causa do pecado, justamente entregue por Deus à escravidão do diabo. Por isso foi
conveniente que, pela justiça, o homem fosse liberado da escravidão do diabo. Satisfazendo do Cristo
por ele, com a sua paixão. - E isso também foi conveniente para vencer a soberba do diabo, inimigo da
justiça e amante do poder: de modo que Cristo vencesse o diabo e liberasse o homem, não pelo só
poder da divindade, mas também pela justificação e pela humilhação da paixão, como diz Agostinho.

## Art. 4 — Se Cristo devia ter sofrido na cruz.
O quarto discute-se assim. — Parece que Cristo não devia ter sofrido na cruz.

1. — Pois, a verdade deve corresponder à figura. Ora, eram figuras de Cristo todos os sacrifícios do
Antigo Testamento, nos quais se matavam animais com a espada, que eram depois queimados no fogo.
Logo, parece que Cristo não devia ter sofrido na cruz, mas antes ser sacrificado pela espada ou no fogo.

2. Demais. — Damasceno diz, que Cristo não devia assumir sofrimentos degradantes. Ora a morte da
cruz era considerada como degradante e ignominiosa por excelência; por isso diz a Escritura:
Condenemo-Io a uma morte a mais infame. Logo, parece que Cristo não devia sofrer a morte da cruz.

3. Demais. — De Cristo diz o Evangelho: Bendito o que vem em nome do Senhor. Ora, a morte da Cruz
era uma morte de maldição, segundo a Escritura: Maldito é de Deus aquele que está pendente de um
lenho. Logo, parece que não foi conveniente que Cristo fosse crucificado.
Mas, em contrário, o Apóstolo: Feito obediente até a morte e morte de cruz.

SOLUÇÃO. — Era convenientíssimo que Cristo sofresse a morte da cruz. Primeiro, para dar o exemplo da
virtude. Por isso diz Agostinho: A sabedoria de Deus assumiu o homem para nos dar o exemplo de uma
vida reta. Ora, é próprio de uma vida reta não temer o que não deve ser temido. Há porém homens que,
embora não temam a morte em si mesma, tem horror contudo de um determinado gênero de morte.
Por isso, a fim de o homem, que vive retamente, não temer nenhum gênero de morte o Homem-Deus
quis morrer ostensivamente na cruz; pois, dentre todos os gêneros de morte nenhum era mais execrável
e temível que esse. Segundo, porque esse gênero de morte era o por excelência conveniente à
satisfação pelo pecado dos nossos primeiros pais, que consistiu em tomarem do fruto da árvore, contra
a ordem de Deus. Por isso era conveniente que Cristo, para satisfazer por esse pecado, consentisse ele
próprio ser pregado no madeiro, quase para restituir o que Adão subtraíra, como o diz a Escritura:
Paguei então oque não tinha roubado: Donde o dizer Agostinho: Adão desprezou o preceito, colhendo o
pomo da árvore; mas tudo o que Adão perdeu Cristo recuperou na cruz. A terceira razão é que, como diz
Crisóstomo. Cristo sofreu num madeiro elevado e não debaixo de um teto, a fim de purificar também o
ar. Mas também a terra sentiu um benefício semelhante, purificada pelo sangue que corria gota a gota
do lado do crucificado. E aquilo do Evangelho - Importa que seja levantado o Filho do Homem - diz: Por
levantado entende que foi elevado para o alto; para que santificasse o ar quem havia santificado a terra,
andando nela (Teofilacto). A quarta razão é que, morrendo no alto de um madeiro, preparou a nossa
subida ao céu, como diz Crisóstomo (Atanásio). Por isso ele próprio o diz no Evangelho: Eu, quando for
levantado da terra, todas as coisas atrairei a mim mesmo. A quinta razão é que isso convinha também à
completa liberação de todo o gênero humano. Por isso diz S. Gregório Nisseno, que a figura da cruz,
esgalhando-se, de um centro único, em quatro extremos opostos, significa o poder e a providência
daquele que dela pende, espalhados por toda parte. E Crisóstomo também diz que Cristo morreu na
cruz com os braços abertos, para com uma das mãos, atrair para si o povo fiel e, com a outra, os que
constituem a gentilidade. A sexta razão é que esse gênero de morte designa diversas virtudes. E por isso
diz Agostinho: Não escolheu em vão tal gênero de morte, a fim de que fosse o mestre da largura, do
comprimento, da altura e da profundidade, de que fala o Apóstolo. Assim, a largura desse madeiro é
representada pela travessa que nele está fixada — símbolo das boas obras, porque nela estão
estendidos os braços. O comprimento vai do ápice do madeiro à terra e nele é que o crucificado de
certo modo se apóia - símbolo da estabilidade e da perseverança atribuídas à longanimidade. A altura é
representada pela parte do lenho que se eleva acima da travessa e em que foi presa a cabeça do
crucificado — suprema expectativa dos que tem esperança perfeita. Enfim, a profundidade é
representada pela parte do madeiro oculta na terra e donde parece elevar-se toda a cruz - sim bolo da
profundidade da graça gratuita. E como ainda o nota Agostinho, o lenho onde estavam fixos os
membros do crucificado era uma como cátedra donde o mestre ensinava. A sétima razão é que esse
gênero de morte corresponde a várias figuras. Pois, como diz Agostinho, uma arca de madeira salvou o
gênero humano do dilúvio das águas. Quando o povo de Deus fugia do Egito, Moisés dividiu o mar com
uma vara, aniquilou o Faraó e remiu o povo de Deus. Essa mesma vara Moisés a mergulhou na água,
tornando-a doce, de amarga que era. Ainda com essa vara fez jorrar da pedra espiritual uma água
salutar. Para vencer Amalec, Moisés conservava as mãos estendidas ao longo da vara. E a lei de Deus
estava encerrada na arca do Testamento, que julgavam de madeira. Assim, pois, o gênero humano era
conduzido, como gradativamente, ao lenho da cruz.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O altar dos holocaustos, onde eram oferecidos os
sacrifícios dos animais, era feito de madeira, como se lê na Escritura; e, assim, a verdade corresponde à
figura. Mas não é necessário que a correspondência seja total, porque então já não seria semelhança,
mas identidade, como diz Damasceno. - Contudo e especialmente como diz Crisóstomo Atanásio, não se
lhe amputou a cabeça, como a João; nem foi serrado, como Isaias; para que, morto, conservasse integro
o corpo e indivisível, a fim de não dar ocasião aos que querem dividir a Igreja. — E em lugar do fogo
material estava, no holocausto de Cristo, o fogo da caridade.

RESPOSTA À SEGUNDA. — Cristo não quis assumir sofrimentos degradantes, que implicassem falta de
ciência ou de graça, ou ainda de virtude. Não porém os resultantes de injúrias externas; antes, como diz
o Apóstolo, sofreu a cruz, desprezando a ignomínia.

RESPOSTA À TERCEIRA. — Como diz Agostinho, o pecado é maldito, e por consequência a morte e a
mortalidade proveniente do pecado. Pois, a carne de Cristo era mortal, tendo a semelhança da carne de
pecado. E por isso Moisés lhe chama maldito, como o Apóstolo lhe chama pecado, quando diz: Aquele
que não havia conhecido pecado o fez pecado por nós, isto é, pela pena do pecado. Nem indica maior
ódio da parte de Deus o ter predito Moisés que Cristo é maldito de Deus. Pois, se Deus não odiasse o
pecado não teria mandado o seu Filho a tomar a morte sobre si e a destruí-la. É, portanto a mesma coisa
proclamar que ele aceitou a maldição em nosso lugar e dizer que morreu por nós. Donde o dito do
Apóstolo: Cristo nos remiu da maldição da lei, feito ele mesmo maldição por nós.

## Art. 5 — Se Cristo sofreu todos os sofrimentos.
O quinto discute-se assim. Parece que Cristo sofreu todos os sofrimentos.

1. — Pois, diz Hilário: O Unigênito de Deus, para completar o sacrifício da sua morte, atestou ter
consumado em si todos os sofrimentos do gênero humano, quando, inclinada a cabeça, rendeu o
espírito. Logo, parece que sofreu todosos sofrimentos humanos.

2. Demais. — A Escritura diz: Eis aí está que o meu servo terá inteligência; ele será exaltado e elevado e
ficará em alto grau sublimado; assim como pasmavam muitos à vista de ti, assim será sem glória o seu
aspecto entre os varões e sua figura entre os filhos dos homens. Ora, Cristo foi exaltado por ter a
totalidade da graça e da ciência, pelo que muitos pasmaram à vista dele, admirando-o. Logo, parece que
teria sido sem glória, sofrendo todos os sofrimentos humanos.

3. Demais. — A Paixão de Cristo tinha por fim libertar o homem do pecado, como se disse. Ora, Cristo
veio liberar os homens de todo gênero de pecados. Logo, devia sofrer todo gênero de sofrimentos.
Mas, em contrário, diz o Evangelho, que os soldados quebraram as pernas aoprimeiro eao outro que
com ele fora crucificado; tendo vindo depois a Jesus, não lhe quebraram as pernas. Logo não sofreu
todo o gênero de sofrimentos.

SOLUÇÃO. — Os sofrimentos humanos podem ser considerados à dupla luz. Primeiro, quanto à espécie.
E então, não devia Cristo sofrer todos os sofrimentos; pois, muitas espécies de sofrimentos são
contrárias entre si, tal a combustão pelo fogo e a submersão na água. Mas, agora tratamos dos
sofrimentos de proveniência extrínseca; pois, os sofrimentos procedentes de causas externas, como as
doenças do corpo, não devia ele sofrê-las, como dissemos. Mas, quanto ao gênero, sofreu todos os
sofrimentos humanos. O que é susceptível de tríplice consideração. — Primeiro, quanto aos homens que
lhe causaram sofrimentos. Pois, certos sofrimentos lhe foram infligidos pelos gentios e pelos judeus; por
homens e por mulheres, como o mostram as criadas acusadoras de Pedro. Também recebeu
sofrimentos dos príncipes, e de seus ministros, e do populacho, conforme a Escritura: Por que razão se
embraveceram as nações e os povos meditaram coisas vãs? Os reis da terra se sublevaram e os príncipes
se coligaram contra o Senhor e contra o seu Cristo. Sofreu também de seus discípulos e conhecidos;
como de Judas, que o traiu e de Pedro, que o negou. — Segundo, o mesmo se conclui relativamente
àquilo em que o homem pode sofrer. Assim, sofreu nos seus amigos, que o abandonaram; na sua
reputação, pelas blasfêmias contra ele proferidas; na sua honra e glória, pelas irrisões e contumélias
contra ele assacadas; nos bens, quando das suas próprias vestes foi espoliado; na alma, pela tristeza,
pelo tédio e pelo temor; no corpo, pelos ferimentos e flagelações. — Em terceiro lugar, podemos
considerá-las relativamente aos membros do corpo. Assim, Cristo sofreu, na cabeça, a coroa de
pungentes espinhos; nas mãos e nos pés, a pregação dos cravos; na face bofetadas e cuspe; e em todo o
corpo, flagelações. Sofreu também em todos os sentidos do corpo: no tato, quando flagelado e pregado
com cravos; no gosto, quando lhe deram de beber fel e vinagre; no olfato, quando suspenso no
patíbulo, num lugar fétido pelos cadáveres dos supliciados, chamado Calvário; no ouvido, ferido pelas
vociferações dos que o blasfemavam e faziam dele irrisão; na vista, ao ver sua mãe e o discípulo a quem
amava, chorando.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras citadas de Hilário devem entender-se quanto
a todos os gêneros de sofrimentos, mas não quanto a todas as espécies deles.

RESPOSTA À SEGUNDA. — A semelhança, no caso, se considera, não quanto ao número dos sofrimentos
e das graças, mas quanto à grandeza de uns e de outras. Porque, assim como foi levantado acima dos
outros nos dons das graças, assim foi abatido abaixo deles pela ignomínia da paixão.

RESPOSTA À TERCEIRA. — Quanto à suficiência, um sofrimento mínimo de Cristo bastava para remir o
gênero humano de todos os pecados. Mas, quanto à conveniência, foi suficiente que sofresse todos os
gêneros de sofrimentos, como já se disse.

## Art. 6 — Se a dor da paixão de Cristo foi maior que todas as outras dores.
O sexto discute-se assim. — Parece que a dor da paixão de Cristo não foi maior que todas as outras
dores.

1. — Pois, a dor do paciente aumenta conforme a gravidade e a duração do sofrimento. Ora, certos
mártires padeceram sofrimentos mais graves e mais longos do que Cristo; assim, Lourenço, assado em
grelhas, e Vicente cujas carnes foram laceradas por unhas de ferro. Logo, parece que a dor dos
sofrimentos de Cristo não foi a máxima.

2. Demais. — A força do espírito mitiga a dor, a ponto de os estóicos ensinarem que a alma do sábio não
é susceptível de tristeza. E Aristóteles diz que a virtude moral faz conservar o justo meio nas paixões.
Ora, Cristo teve a virtude perfeitíssima da alma. Logo, parece que Cristo sofreu a mínima das dores.

3. Demais. — Quanto mais sensível é um paciente, tanto maior é a dor da paixão. Ora, a alma é mais
sensível que o corpo, pois, pela alma é que o corpo sente. E também, Adão parece ter tido, no estado de
inocência, um corpo mais sensível que o de Cristo, que assumiu o corpo humano com as suas
deficiências naturais. Logo, parece que a dor da alma padecente no purgatório ou no inferno, ou ainda a
dor de Adão, se alguma sofreu, teria sido maior que a dor da paixão de Cristo.

4. Demais. — A perda de um maior bem causa uma dor maior. Ora, o pecador, pecando, perde um
maior bem que Cristo, sofrendo, porque a vida da graça é melhor que a da natureza humana. Demais,
Cristo, que perdeu a vida, havendo de ressurgir três dias depois, parece que perdeu um bem menor do
que aqueles que perdem a vida, havendo de permanecer mortos. Logo, parece que a dor de Cristo não
foi a máxima das dores.

5. Demais. — A inocência do paciente diminui a dor da paixão. Ora, Cristo sofreu inocentemente,
segundo a Escritura: Eu era como um manso cordeiro que élevado a ser vítima. .Logo, parece que a dor
da paixão de Cristo não foi a máxima.

6. Demais. — Nada do que teve Cristo era supérfluo. Ora, uma dor mínima de Cristo bastaria para o fim
da salvação humana, pois, teria uma virtude infinita, por causa da sua pessoa divina. Logo, foi supérfluo
assumir a máxima das dores.
Mas, em contrário, a Escritura diz, da pessoa de Cristo: Atendei e vê de se há dor semelhante à minha
dor.

SOLUÇÃO. — Como dissemos, quando tratamos das deficiências assumidas por Cristo, ele sofreu
verdadeiramente a dor, na sua paixão. Tanto a sensível, causada pelos tormentos corpóreos, como a
interior, causada pela apreensão do mal, que se chama tristeza. Ora, ambas essas dores foram máximas
em Cristo, entre as dores da vida presente. O que se explica por quatro razões. Primeiro, pelas causas da
dor. — Pois, a dor sensível teve como causa uma lesão corpórea cheia de acerbidade, tanto pela
generalidade da paixão, de que já tratamos, como pelo gênero da mesma. Pois, a morte dos crucificados
é acerbíssima, por serem trespassados em lugares nervosos e sobremaneira sensíveis, que são as mãos
e os pés. E além disso, o peso mesmo do corpo pendente continuamente aumenta a dor;
acrescentando-se ainda a diuturnidade dela, pois, os crucificados não morrem logo como os mortos pela
espada. — Quanto à dor interna teve as causas seguintes. Primeiro todos os pecados do gênero
humano, pelos quais satisfazia com os seus sofrimentos; por isso como que os avocou a si, dizendo: Os
clamores dos meus pecados. Segundo e especialmente, a culpa dos judeus e dos outros, que lhe
infligiram a morte; e sobretudo a dos discípulos, que se escandalizaram com a paixão de Cristo. Terceiro,
ainda, a perda da vida do corpo, naturalmente horrível à natureza humana. Em segundo lugar, a
grandeza da dor pode ser considerada relativamente à sensibilidade do paciente. — Assim, o seu corpo
tinha a melhor das compleições; pois, fora formado milagrosamente por obra do Espírito Santo. Porque
nada é mais perfeito que o produzido por milagre, como o nota S. João Crisóstomo, a propósito da água
convertida em vinho por Cristo, nas bodas. Assim, o sentido do tato, que serve para perceber a dor, era
em Cristo extremamente delicado. — Também a alma, nas suas potências interiores, apreendia com
grande eficácia todas as causas de tristeza. Terceiro, a grandeza da dor de Cristo na sua paixão, pode ser
considerada quanto à pureza da mesma dor. Pois, nos outros pacientes, mitiga-se a tristeza interior e
também a dor externa, pela reflexão racional, causando uma certa derivação ou redundância das
potências superiores para as inferiores. Oque não se deu na paixão de Cristo, pois. à cada uma das
potências permitia agir dentro do que lhe era próprio, como diz Damasceno. Em quarto lugar, a
grandeza da dor de Cristo pode ser considerada quanto ao fato de ser a sua paixão e a sua dor
assumidas voluntariamente, com o fim de livrar o homem do pecado. Por isso, assumiu uma dor tão
grande, que fosse proporcionada àgrandeza do fruto dela resultante. Assim, pois, de todas essas causas
simultaneamente consideradas resulta claro que a dor de Cristo foi a máxima das dores.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe quanto a uma só das causas de
sofrimento enumeradas, a saber, a lesão corpórea, causa da dor sensível. Mas, as outras causas
aumentaram muito mais a dor de Cristo na sua paixão, como se disse.

RESPOSTA À SEGUNDA. — A virtude moral não mitiga do mesmo modo a tristeza interior e ador
sensível externa, Assim, a tristeza interior ela a diminui diretamente, estabelecendo nela a mediedade,
como em matéria própria. Ao passo que a virtude moral constitui a mediedade nas paixões, como
estabelecemos na Segunda Parte, introduzindo nelas não uma quantidade real, mas uma quantidade
proporcional, de modo que a paixão não ultrapasse a regra racional. E como os estóicos reputavam a
tristeza totalmente inútil, por isso criam que ela se divorcia totalmente da razão e, por consequência,
deve ser totalmente evitada pelo sábio, Mas, na verdade das causas, há uma certa tristeza digna de
louvor, como o prova Agostinho: é a procedente de um amor santo, como quando nos entristecemos
dos pecados próprios ou dos alheios, e também é considerada como útil quando tem por fim satisfazer
pelas pecados, segundo aquilo do Apóstolo: A tristeza, que é segundo Deus, produz para a salvação uma
penitência estável. Por isso Cristo, a fim de satisfazer pelos pecados de todos os homens, assumiu uma
tristeza máxima pela sua quantidade absoluta, mas que não ultrapassava a regra racional. - Mas quanto
àdor exterior do sentido, a virtude moral não a diminui diretamente, porque essa dor não obedece
àrazão, mas resulta da natureza do corpo. Diminui-a, porém indiretamente pela redundância das
potências superiores para as inferiores. Oque não se deu com Cristo, como dissemos.

RESPOSTA À TERCEIRA. — A dor da alma do padecente, separada, é própria do estado futuro de
danação, que excede todos os males desta vida, como a glória dos Santos excede todos os bens da vida
presente. Por isso, quando dizemos que a dor de Cristo foi máxima, não a comparamos com a dor da
alma separada. - Quanto ao corpo de Adão, ele não podia sofrer se não tivesse pecado, tornando-se
assim mortal e passível. E, sofrendo, padeceria menos que o corpo de Cristo, pelas razões referidas. —
Donde também resulta que mesmo se, por impossível, considerássemos que Adão no estado de
inocência sofreu, a sua dor teria sido menor que a de Cristo.

RESPOSTA À QUARTA. — Cristo não somente sofreu perdendo a vida do seu próprio corpo, mas
também pelos pecados de todos os homens. Porque a dor de Cristo ultrapassou toda dor de qualquer
paciente. Quer porque procedia de uma sabedoria e caridade maiores, que aumentam a dor do
padecente; quer também porque sofreu simultaneamente por todos os pecados, segundo aquilo da
Escritura: Verdadeiramente ele foi oque tomou sobre si as nossas fraquezas. — Mas a vida corporal de
Cristo foi de tão grande dignidade, e, sobretudo, pela divindade que lhe estava unida, que sofreu mais,
perdendo-a, mesmo momentaneamente, que qualquer outro homem perdendo a sua, por qualquer
tempo que fosse. Donde o dizer o Filósofo, que o virtuoso tanto mais ama a sua vida, quanto mais a tem
como melhor; e, contudo, a expõe pelo bem da virtude, E semelhantemente, Cristo, tendo uma vida
amável por excelência, a expôs pelo bem da caridade, segundo aquilo da Escritura: Dei a minha amada
alma em mãos de seus inimigos.

RESPOSTA À QUINTA. — A inocência do paciente diminui numericamente a dor da paixão; porque
quando padece por culpa, sofre não só pela pena, mas também pela culpa; sendo inocente, porém,
sofre só pela pena. Contudo a sua inocência lhe aumenta a dor, porque sabe que não merece o mal que
lhe é infligido. E por isso são tanto mais repreensíveis os que não se compadecem dele, conforme a
Escritura: O justo perece e não há quem considere no seu coração.

RESPOSTA À SEXTA. — Cristo quis liberar o gênero humano dos pecados, não só pelo seu poder, mas
ainda por justiça. Por isso, não só levou em conta a grandeza do poder que tinha a sua dor, em virtude
da divindade que lhe estava unida, mas também o quanto bastava essa dor pela sua natureza humana,
para tão grande satisfação.

## Art. 7 — Se Cristo sofreu em toda a sua alma.
O sétimo discute-se assim. — Parece que Cristo não sofreu em toda a sua alma.

1. — Pois a alma sofre quando sofre o corpo, por acidente, por ser o ato do corpo. Ora, a alma não é ato
do corpo relativamente a qualquer das suas partes; assim, o intelecto não é ato de nenhum corpo, como
diz Aristóteles. Logo, parece que Cristo não sofreu em toda a sua alma.

2. Demais. — Toda potência da alma é passiva em relação ao seu objeto. Ora, o objeto da razão da parte
superior são as razões eternas, que ela se esforça por contemplar e consultar, como o diz Agostinho.
Mas, pelas razões eternas, Cristo não podia sofrer nenhum mal, pois em nada o contrariavam. Logo,
parece que não sofreu em toda a sua alma.

3. Demais. — Quando o sofrimento sensível atinge até a razão, então é considerado como sofrimento
completo. O que não se deu com Cristo, que só sofreu uma propaixão, como o nota Jerônimo. Donde o
dizer Dionísio que os sofrimentos que lhe foram infligidos ele os sofreu só pelos julgar. Logo, não parece
que Cristo sofresse em toda a sua alma.

4. Demais. — O sofrimento causa a dor. Ora, o intelecto especulativo não é susceptível de dor: pois, o
prazer nascido da contemplação não pode ser atingido por nenhuma dor, como o diz o Filósofo. Logo,
parece que Cristo não sofreu em toda a sua alma.
Mas, em contrário, a Escritura diz, da pessoa de Cristo: A minha alma está repleta de males. O que
aumenta a Glosa: Não de vícios, mas de dores, pelas quais a alma se compadece da carne ou dos males
do povo que perecia. Ora, a sua alma não estaria repleta desses males se não tivesse sofrido em toda
ela. Logo, Cristo sofreu em toda a sua alma.

SOLUÇÃO. — O todo é assim chamado relativamente às partes. Ora, partes da alma se chamam as suas
potências. Assim, pois, dizemos que toda a alma sofre quando sofre na sua essência ou em todas as suas
potências. Devemos, porém considerar que uma potência da alma pode sofrer de dois modos. De um
modo, por sofrimento próprio, isto é, quando o sofrimento lhe é causado pelo seu objeto; tal o caso da
visão que sofre por causa de uma excessiva visibilidade do objeto. De outro modo sofre uma potência
pela paixão do sujeito no qual se ela funda; assim a vista sofre quando sofre o sentido do tato nos olhos,
em que se funda a vista; por exemplo, quando os olhos são pungidos ou perturbados pelo calor. Donde,
pois, devemos concluir que, se considerarmos toda a alma, em razão da sua essência, então é manifesto
que toda a alma de Cristo sofreu. Pois, a alma está unida ao corpo na totalidade da sua essência, de
modo que está toda em todo o corpo e toda em qualquer parte dele. Por onde, sofrendo o corpo e em
disposição de ser separado da alma, toda a alma sofria. Se, porém, considerarmos toda a alma segundo
todas as suas potências, então, tratando das paixões próprias das potências, ela sofria certo, em todas
as suas potências inferiores. Pois, em cada uma das potências inferiores da alma, que tem por objeto
coisas temporais, havia alguma causa da dor de Cristo, como do sobredito resulta. Mas, então, a razão
superior de Cristo não sofria por parte do seu objeto, isto é, Deus, que não era causa de dor, mas de
prazer e de gáudio, para a alma de Cristo. — Mas, segundo aquele aspecto da paixão, em virtude do
qual dizemos que uma potência sofre por parte do seu objeto, todas as potências da alma de Cristo
sorriam. Pois, todas as potências da alma se lhe radicam na essência, que é atingida pela paixão, quando
sofre o corpo, de que a alma é o ato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o intelecto, enquanto determinada potência,
não seja o ato do corpo, contudo ato do corpo é a essência da alma, na qual se radica a potência
intelectiva, como estabelecemos na Primeira Parte.

RESPOSTA À SEGUNDA. — A objeção colhe quanto à paixão resultante do objeto próprio; segundo a
qual a razão superior de Cristo não sofreu.

RESPOSTA À TERCEIRA. — Dizemos que a dor é um sofrimento perfeito, que perturba a alma quando a
paixão da parte sensitiva chega até a desviar a razão da rectitude do seu ato, de modo que obedeça à
paixão e não exerça o livre arbítrio sobre ela. Assim, porém, a paixão da parte sensitiva não atingiu a
razão de Cristo: mas sim, no concernente ao sujeito, como se disse.

RESPOSTA À QUARTA. — O intelecto especulativo não é susceptível de dor nem de tristeza por parte do
seu objeto, que é a verdade absolutamente considerada, cuja perfeição é. Pode, porém atingi-lo a dor
ou a causa da dor, pelo modo já dito.

## Art. 8 — Se a alma de Cristo, durante o tempo da sua paixão, fruía totalmente o gozo da bem-aventurança.
O oitavo discute-se assim. — Parece que a alma de Cristo, durante o tempo da sua paixão, não fruía
totalmente o gozo da bem-aventurança.

1. — Pois, é impossível sofrer e gozar simultaneamente, por serem contrários a dor e o prazer. Ora, a
alma de Cristo sofria totalmente a dor no tempo da paixão, como se estabeleceu. Logo, não podia fruir
na sua totalidade.

2. Demais. — O Filósofo diz que a tristeza, sendo veemente, não só impede o prazer contrário, mas
qualquer prazer; e inversamente. Ora, a dor da paixão de Cristo foi a dor máxima, como se demonstrou;
e semelhantemente, o deleite do gozo é o máximo, como se estabeleceu na Segunda Parte. Logo, não
era possível a alma de Cristo na sua totalidade, simultaneamente sofrer e gozar.

3. Demais. — O gozo da bem-aventurança se funda no conhecimento e no amor divinos, como está claro
em Agostinho. Ora, nem todas as potências da alma são capazes de conhecer e amar a Deus. Logo,
Cristo não gozava com toda a sua alma.
Mas, em contrário, diz Damasceno, que a divindade de Cristo permitia à carne agir e sofrer como lhe era
próprio. Logo, pela mesma razão, sendo próprio à alma de Cristo, enquanto bem-aventurada, gozar a
sua paixão não lhe Impedia o gozo.

SOLUÇÃO. — Como dissemos antes, a alma na sua totalidade, podemos entendê-la, tanto na sua
essência como em todas as suas potências. — Se, pois, a considerarmos na sua essência então toda a
alma de Cristo gozava, enquanto o sujeito da sua parte superior, a que cabe gozar da divindade. De
modo que, assim como a paixão, em razão da essência, se atribui à parte superior da alma, assim
também e ao inverso, o gozo, em razão da parte superior da alma, há de atribuir-se à essência. — Se,
porém considerarmos toda a alma, em razão de todas as suas potências, então não era a alma na sua
totalidade a que fruía. Nem diretamente porque a fruição não pode ser ato ele nenhuma parte da alma.
Nem pela redundância da glória, pois enquanto Cristo era viandante, não havia nenhuma redundância
de glória da parte superior para a inferior, nem da alma para o corpo. Mas porque, do inverso também a
parte superior da alma não ficava impedida na sua ação própria pela parte inferior, resulta que a parte
superior da alma de Cristo fruía perfeitamente, durante a sua paixão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O gáudio da fruição diretamente não contraria à dor da
paixão porque um e outra não recaem sobre o mesmo objeto. Pois, nada impede os contrários existirem
num mesmo sujeito, mas não sob o mesmo aspecto. E assim, o gáudio da fruição pode pertencer à parte
superior da razão, pelo seu ato próprio: e a dor da paixão, pelo seu sujeito. Ora, a essência da alma
concerne a dor da paixão, quanto ao corpo, de que ela é a forma: e o gáudio da fruição, quanto à
potência, de que depende.

RESPOSTA À SEGUNDA. — As palavras citadas do Filósofo são verdadeiras em razão da redundância,
naturalmente resultante de uma potência da alma para outra. Mas isso não se deu com Cristo, como
dissemos.

RESPOSTA À TERCEIRA. — A objeção colhe no concernente à totalidade da alma, quanto às suas
potências.

## Art. 9 — Se Cristo sofreu no tempo conveniente.
O nono discute-se assim. — Parece que Cristo não sofreu no tempo conveniente.

1. — Pois, a paixão de Cristo era figurada pela imolação do cordeiro pascal donde o dizer o Apóstolo:
Cristo, que é a nossa Páscoa, foi imolado. Ora, o cordeiro pascal era imolado no dia quatorze à tarde,
como refere a Escritura. Logo, parece que então é que deveria Cristo sofrer. O que é falso, pois, então,
celebrou a Páscoa com os seus discípulos, segundo o Evangelho: No primeiro dia, em que se comiam os
pães asmos, quando se imolava o cordeiro pascal; e no dia seguinte sofreu a paixão.

2. Demais. — A paixão de Cristo foi a sua exaltação, segundo o Evangelho: Importa que seja levantado o
Filho do Homem, Ora, Cristo é chamado na Escritura o Sol de Justiça. Logo, parece que devia ter sofrido
na hora sexta, (meio dia), quando o sol está no ponto máximo de elevação. Ora, o contrário está no
Evangelho: Era, pois a hora de terça, tempo em que eles o crucificaram.

3. Demais. — Assim como o sol atinge cada dia o seu ponto mais alto na hora sexta (meio dia), assim no
solstício do verão é que está, cada ano, no seu ponto mais elevado. Logo, Cristo devia ter sofrido a
Paixão, antes no tempo do solsticio do verão que por ocasião do equinócio da primavera.

4. Demais. — A presença de Cristo no mundo iluminava-o a este, segundo o Evangelho: Eu, entretanto
que estou no mundo sou a luz do mundo. Logo, teria sido mais conveniente à salvação humana que
tivesse vivido por mais tempo neste mundo, de modo que não viesse a sofrer na idade de moço, mas
quando já idoso.
Mas, em contrário, o Evangelho: Sabendo Jesus que era chegada a sua hora de passar deste mundo ao
Pai. E noutro lugar: Ainda não é chegada a minha hora. Ao que diz Agostinho: Quando fez tanto quanto
julgava suficiente, então veio a sua hora; não imposta por necessidade, mas voluntária; não dependente
de uma condição, mas do seu poder. Logo, sofreu no tempo conveniente.

SOLUÇÃO. — Como dissemos, a Paixão de Cristo dependia da sua vontade. Ora, a sua vontade era
dirigida pela sabedoria divina, que dispõe todas as coisas convenientemente e com suavidade, no dizer
da Escritura, Donde devemos concluir que a Paixão de Cristo se consumou no tempo conveniente.
Donde o dizer um autor: O Salvador fez tudo em lugares e tempos próprios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Certos dizem que Cristo sofreu na décima quarta lua,
quando os judeus imolavam a Páscoa. Por isso refere o Evangelho, que os judeus não entraram no
Pretório do Pilatos, no dia mesmo da Paixão, por se não contaminarem, mas comerem a Páscoa, Ao que
diz Crisóstomo: Então os judeus celebravam a Páscoa; ao passo que Cristo celebrou a Páscoa um dia
antes, reservando-se a sua imolação para a sexta-feira quando se celebrava a Páscoa antiga. Com o que
parece estar de acordo o dito do Evangelho, que antes do dia da festa da Páscoa Cristo acabada a ceia,
lavou os pés dos discípulos. Mas contra este sentir é o lugar do Evangelho, onde se diz que no primeiro
dos dias em que se comiam os pães asmos, vieram ter com Jesus seus discípulos, dizendo: Onde queres
tu que te preparemos o que se há de comer na Páscoa? Donde resulta que chamando-se dia de asmos o
décimo quarto dia do primeiro mês, quando o cordeiro era imolado e era o plenilúnio, como adverte
Jerônimo, resulta que Cristo celebrou a ceia na décima quarta lua e sofreu a Paixão na décima quinta. E
isso é mais expressamente mencionado pelo dito do Evangelho: No primeiro dia em que se comiam os
pães asmos, quando se imolava o cordeiro pascal. etc. E noutro lugar: Chegou o dia dos pães asmos no
qual era necessário imolar-se a Páscoa. Por isso, certos dizem, que Cristo no dia conveniente, isto é, na
décima quarta lua, comeu a Páscoa com os seus discípulos, mostrando assim que até o último dia não
era contrário à lei, como ensina Crisóstomo. Mas os judeus, ocupados em condenar Cristo à morte,
adiaram para o dia seguinte a celebração da Páscoa, contrariando a lei. E por isso o Evangelho diz deles
que, no dia da Paixão de Cristo, não quiseram entrar no pretório, por não se contaminarem, mas
comerem a Páscoa.
Mas também este modo de ver não concorda com as palavras de Marcos quando diz: No primeiro dia
em que se comiam os pães asmos, quando se imolava o cordeiro pascal. Logo Cristo e os judeus
celebraram simultaneamente antiga Páscoa. E, como Beda diz: embora Cristo, que é a nossa Páscoa,
fosse crucificado no dia seguinte, isto é, na décima quinta lua, contudo na noite em que o cordeiro foi
imolado, entregou seu corpo e seu sangue aos discípulos para a celebração dos santos mistérios; e
então preso e ligado pelos judeus, consagrou o principio da sua imolação, isto. é da sua paixão. Quanto
ao dito do Evangelho — Antes do dia da festa da Páscoa — entende-se que foi a décima quarta lua, que
então teve lugar na quinta-feira; pois, a lua décima quinta era o dia solenissímo da Páscoa entre os
judeus. E assim, o mesmo dia a que João chama — antes do dia da festa da Páscoa — por causa da
distinção natural dos dias, Mateus denomina o primeiro dia em que se comiam os asmas. Porque,
segundo o rito da festividade judaica, a solenidade principiava na tarde do dia precedente. — Quanto ao
lugar, que os judeus haviam de comer a Páscoa na décima quinta lua, devemos entender que ai a Páscoa
não significa o cordeiro pascal, que fora imolado na décima quarta lua; mas a comida pascal, isto é, os
pães asmos, que deviam ser comidos pelos puros. E por isso Crisóstomo, comentando esse lugar refere
outra exposição: Páscoa pode se tomar por toda a festa dos judeus, que durava sete dias.

RESPOSTA À SEGUNDA. — Como diz Agostinho, era quase a hora sexta quando o Senhor foi entregue a
ser crucificado por Pilatos, segundo refere João. Assim, ainda não era plenamente a sexta, mas quase a
sexta, isto é, já se tinha passado a quinta e tinha decorrido já uma parte da sexta, até que, completa
esta estando Cristo pendente da cruz, fizeram-se as trevas. Entende-se, porém que era à terceira hora,
quando os Judeus vociferavam pedindo pela crucifixão do Senhor; e é muito verdade que o crucificaram
quando vociferavam. Por onde, a fim de que ninguém, afastando dos judeus o pensamento de um tão
grande crime, o fizesse recair sobre os soldados, o Evangelho diz que era a hora terceira e então o
crucificaram. De modo que se entenda, antes, terem sido os que vociferavam os que o crucificaram na
hora sexta. — Embora não falte quem queira entender como a terceira hora do dia a Parasceve, que
João comemora, ao dizer — Era então o dia da preparação da Páscoa (Parasceve), quase à hora sexta.
Porque Parasceve significa preparação. Porém e verdadeiramente, a Páscoa celebrada na Paixão do
Senhor, começou a ser preparada desde a nona hora ria noite, isto é, quando todos os príncipes dos
sacerdotes disseram — É réu da morte. Assim que, dessa hora da noite até a crucificação de Cristo,
decorreu a hora sexta da Parasceve, segundo João, e a terceira hora do dia, segundo Marcos. — Certos,
porém dizem que essa diversidade resulta de um erro do copista grego; pois, os números que
representam três e seis são muito semelhantes entre si.

RESPOSTA À TERCEIRA. — Diz um autor: O Senhor quis remir e reformar o mundo pela sua paixão, na
mesma época em que o criou, isto é, no equinócio. É então que o dia começa a ser mais longo que a
noite, porque pela paixão do Salvador somos tirados das trevas para a luz. E como a iluminação perfeita
será no segundo advento de Cristo, por isso o tempo do segundo advento é comparado ao estio, pelo
Evangelho, quando diz: Quando os seus ramos (da figueira) estão já tenros e as folhas tem brotado,
sabei que está perto o estio; assim também vós quando vides tudo isto, sabei que esta perto, às portas.
E então terá lugar a exaltação suprema de Cristo.

RESPOSTA À QUARTA. — Cristo quis sofrer na idade de moço por três razões. — Primeiro, para nos
demonstrar melhor o seu amor, dando a sua vida por nós, quando a tinha no seu estado mais perfeito.
— Segundo, porque não convinha que nele se manifestasse nenhuma decadência física, como nem
qualquer doença, segundo se disse. - Terceiro, a fim de que, morrendo e ressurgindo na quadra da
mocidade, mostrasse de antemão em si a qualidade futura dos ressurrectos. Por isso diz o Apóstolo: Até
que todos cheguemos à unidade da fé e ao conhecimento do Filho de Deus, a estado de varão perfeito,
segundo a medida de idade completa de Cristo.

## Art. 10 — Se Cristo sofreu no lugar conveniente.
O décimo discute-se assim. — Parece que Cristo não sofreu no lugar conveniente.

1. — Pois, Cristo sofreu na sua carne humana, que foi concebida de uma virgem em Nazaré, e nascida
em Belém. Logo, parece que devia ter sofrido não em Jerusalém, mas em Nazaré ou em Belém.

2. Demais. — A realidade deve corresponder à figura. Ora, a Paixão de Cristo era figurada pelos
sacrifícios da lei antiga. Mas, tais sacrifícios eram oferecidos no Templo. Logo, parece que Cristo devia
ter sofrido no Templo e não fora da porta da cidade.

3. Demais. — O remédio deve ser adequado à doença. Ora, a Paixão de Cristo foi o remédio do pecado
de Adão. Adão, porém não foi sepultado em Jerusalém, mas no Hebron, como o refere Josué: Hebron
chamava-se antes por nome Cariath-Arbe; ali foi enterrado Adão, que foi o máximo entre os Enacinos.
Logo, parece que Cristo devia ter sofrido em Hebron e não em Jerusalém.
Mas, em contrário, o Evangelho: Não convém que um profeta morra fora de Jerusalém. Logo, sofreu
como o devia, em Jerusalém.

SOLUÇÃO. — Como diz um Autor o Salvador fez tudo em lugares e tempos próprios; pois como todos os
tempos estão em suas mãos, assim também todos os lugares. Por onde, assim como Cristo sofreu no
tempo conveniente, assim também no lugar conveniente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo sofreu muito convenientemente em Jerusalém. —
Primeiro, porque Jerusalém foi o lugar escolhido por Deus para aí se lhe oferecerem os sacrifícios.
Sacrifícios esses que, sendo figurados, representavam a Paixão de Cristo, que é o verdadeiro sacrifício
segundo o Apóstolo: Entregou-se a si mesmo como oferenda e hóstia em odor de suavidade, Por isso diz
Beda, numa Homilía, que, aproximando-se a hora, da Paixão, o Senhor quis aproximar-se do lugar dela,
isto é de Jerusalém, onde chegou cinco dias antes da Páscoa, assim como o cordeiro pascal, era
conduzido ao lugar da imolação cinco dias antes da Páscoa, isto é, na décima lua, segundo o preceito da
lei. — Segundo, porque a virtude da sua Paixão devia difundir-se a todo o mundo; por isso quis sofrer no
meio da terra habitável, isto é, em Jerusalém. Donde o dizer a Escritura: Mas o Deus, rei nosso antes dos
séculos, obrou a salvação no meio da terra, isto é, Jerusalém, considerada como o umbigo da terra. —
Terceiro, porque isso lhe convinha sobremaneira à humildade; pois, assim como elegeu o mais
infamante dos gêneros de morte, assim também àhumildade lhe convinha não recusar sofrer a confusão
num lugar tão célebre. Por isso diz Leão Papa: Quem assumira a forma de servo, preelegeu Belém para a
sua natividade e Jerusalém, para a Paixão. — Quarto, para mostrar que a iniquidade cometida com a sua
morte foi oriunda dos chefes do povo. Por isso quis sofrer em Jerusalém, onde moravam os príncipes.
Daí, o dizer a Escritura: Ligaram-se nesta cidade contra o teu santo Filho Jesus, ao qual ungiste, Herodes
e Pôncio Pilatos, com os gentios e com os povos de Israel.

RESPOSTA À SEGUNDA. — Cristo não sofreu a sua Paixão no templo nem na cidade, mas fora da porta,
por três razões. - Primeiro, para que a realidade correspondesse ao figurado. Pois, o vitelo e o bode,
oferecidos em soleníssimo sacrifício para a expiação de toda a multidão, eram queimados fora dos
arraiais. Por isso diz o Apóstolo: Os corpos daqueles animais, cujo sangue é metido pelo pontífice no
santuário para expiação do pecado, são queimados fora dos arraiais. Pelo que também Jesus, para que
santificasse ao povo pelo seu sangue, padeceu fora da porta. - Segundo, para que assim nos ensinasse,
pelo seu exemplo, a nos apartar da vida do mundo. Por isso acrescenta o Apóstolo: Saiamos, pois a ela
fora dos arraiais, levando sobre nós o seu opróbrio. - Terceiro como diz Crisóstomo, o Senhor não quis
sofrer debaixo de um teto nem num templo judaico, a fim de que os judeus não nos privassem do
sacrifício da salvação e não pensássemos que só por esse povo fosse ele oferecido. - Por isso Cristo
sofreu fora ela cidade e fora dos muros para sabermos que esse sacrifício foi oferecido por todos, por
ser a oblação de toda a terra e a purificação de todos.

RESPOSTA À TERCEIRA. — Como diz Jerônimo, pretendeu-se que o Calvário, lugar onde fora enterrado
Adão, foi por isso chamado lugar do crânio por ter sido aí enterrada a cabeça do primeiro homem. Essa
interpretação foi bem aceita por lisonjear os ouvidos do povo, mas não é verdadeira. Porque na
verdade, fora da cidade e fora da porta, havia lugares onde eram decapitados os condenados; daí o
nome que lhes davam, de calvários, isto é, dos decapitados. E por isso aí foi crucificado Jesus para que,
onde primeiro fora o campo dos condenados, aí se erigisse o estandarte do martírio. Quanto a Adão, ele
foi sepulto perto de Hebron, como lemos no livro de Jesus, filho de Nave. — Mas Jesus devia ser
crucificado antes no lugar comum dos condenados, que perto do sepulcro de Adão, para que se
mostrasse ser a cruz de Cristo não só um remédio contra o pecado individual de Adão, mas ainda contra
o pecado de todo o mundo.

## Art. 11 — Se foi conveniente Cristo ser crucificado com os ladrões.
O undécimo discute-se assim. Parece que não foi conveniente Cristo ter sido crucificado com os
ladrões.

1. — Pois, diz o Apóstolo: Que união pode haver entre a justiça e a iniquidade? Ora, Cristo nos tem sido
feito por Deus justiça, e dos ladrões é própria a iniquidade. Logo, não foi conveniente que Cristo fosse
crucificado junto com os ladrões.

2. Demais. — Aquilo do Evangelho: Ainda que seja necessário morrer eu contigo, não te negarei — diz
Orígenes: Não convinha a nenhum homem morrer com Jesus, que morreu por todos. E comentando
aquele outro lugar. - Eu estou pronto a ir contigo, tanto para a prisão como a morrer, diz Ambrósio: A
Paixão de Cristo tem imitadores, mas não iguais. Logo, parece que era muito menos conveniente que
Cristo sofresse simultaneamente com os ladrões.

3. Demais. — O Evangelho diz num lugar. Impropérios lhe diziam também os ladrões que haviam sido
crucificados com ele. E noutro lugar se refere que um dos ladrões crucificados com Cristo lhe dizia:
Senhor lembra-te de mim, quando entrares no teu reino. Por onde se vê que, além dos ladrões, que
blasfemavam, foi crucificado com Cristo um que não blasfemava. Logo, parece inexato o narrado pelos
evangelistas, que Cristo foi crucificado com ladrões.
Mas, em contrário, a Escritura: E foi posto no número dos malfeitores.

SOLUÇÃO. — Cristo foi crucificado entre os ladrões, por uma razão se considerarmos a intenção dos
judeus, e por outra, considerada a ordem de Deus: Assim, quanto à intenção dos judeus, crucificaram
aos lados de Cristo dois ladrões, como adverte Crisóstomo, para que ele participasse da ignomínia deles.
Contudo, àqueles ninguém se refere, ao passo que a cruz de Cristo é honrada em toda parte. Os reis,
depondo os seus diademas, assumem a cruz: no meio das púrpuras, dos diademas, das armas, da mesa
sagrada, em toda a parte do mundo a cruz resplandece. De outro lado, quanto à ordenação de Deus,
Cristo foi crucificado entre ladrões, porque, segundo diz Jerônimo, assim como Cristo foi feito na cruz
maldição por nós, assim, foi crucificado como criminoso entre criminosos, para a salvação de todos. —
Segundo, como diz Leão Papa, dois ladrões foram crucificados, um ao lado direito e outro ao lado
esquerdo de Cristo, a fim de que nesse espetáculo mesmo do patíbulo se espelhasse aquela separação
que ele próprio há de fazer quando vier a julgar os homens. E Agostinho diz: Se bem refletires verás, que
essa cruz foi um tribunal. O juiz está posto no meio; o que acreditou foi salvo; o outro que insultou, foi
condenado. Por onde se vê o que Cristo fará um dia, dos vivos e dos mortos, colocando aqueles à sua
direita e os outros, à esquerda: — Terceiro, segundo Hilário, porque os dois ladrões, crucificados — um,
à direita, o outro à esquerda, mostram que toda a diversidade do gênero humano é chamada a
participar do mistério da paixão de Cristo. Mas como a divisão entre fiéis e infiéis é correspondente aos
lados direito e esquerdo, um dos dois, o colocado à direita, foi salvo pela justificação da fé. — Quarto,
porque, como diz Beda, os ladrões crucificados com o Senhor, simbolizam aqueles que, sob a fé e a
confissão de Cristo, sofrem a agonia do martírio, ou vivem sob as regras de uma disciplina mais austera.
E os que trabalham para a glória eterna são figurados pelo ladrão da direita; ao passo que os de olhos
postos na glória humana imitam os atos do ladrão da esquerda.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como Cristo não estava obrigado a morrer, mas
sofreu a morte voluntariamente para vencê-la com o seu poder, assim também não mereceu ser
crucificado com os ladrões, mas quis ser confundido com homens iníquos a fim de destruir a iniquidade
com a sua virtude. Donde o dizer Crisóstomo, que converter o ladrão na cruz e introduzi-lo no Paraíso,
não foi menos que fender rochedos.

RESPOSTA À SEGUNDA. — Não convinha que ninguém sofresse com Cristo pela mesma causa. Por isso
acrescenta Orígenes no mesmo lugar: Todos eram pecadores e todos tinham necessidade que um outro
morresse por eles, mas não eles pelos outros.

RESPOSTA À TERCEIRA. — Como adverte Agostinho, podemos entender que Mateus usou do número
plural pelo singular, ao narrar que os ladrões lhe diziam impropérios. - Ou podemos dizer segundo
Jerônimo, que a princípio tanto um como outro blasfemavam; depois um deles, vendo os milagres,
acreditou em Cristo.

## Art. 12 — Se a paixão deve ser atribuída à sua divindade.
O duodécimo discute-se assim. — Parece que a paixão de Cristo deve ser atribuída à sua divindade.

1. — Pois, diz o Apóstolo: Se eles o conhecessem não crucificariam nunca ao Senhor da Glória. Ora, o
Senhor da glória é Cristo, na sua divindade. Logo, a paixão de Cristo devia lhe ser atribuída àdivindade.

2. Demais. — O princípio da salvação humana é a divindade, segundo aquilo da Escritura: Mas a salvação
dos justos vem do Senhor. Se, logo, a paixão de Cristo não lhe pertencesse àdivindade, parece que
nenhum fruto podia produzir para nós.

3. Demais. — Os judeus foram punidos pelo pecado de matarem a Cristo, como homicidas do próprio
Deus, o que mostra a grandeza da pena em que incorreram. Ora, tal não se daria se a Paixão não fosse
atribuída à divindade. Logo a paixão de Cristo lhe pertencia à divindade.
Mas, em contrário, diz Atanásio: O Verbo, enquanto Deus é impassível. Ora, o impassível não pode
padecer. Logo, a paixão de Cristo não lhe devia ser atribuída à divindade.

SOLUÇÃO. — Como dissemos a união entre a natureza divina e a humana realizou-se na pessoa, na
hipóstase e no suposto, permanecendo, porém a distinção das naturezas. De modo que é a mesma a
pessoa e a hipóstase da natureza divina e da humana, salva, contudo a propriedade de uma e outra
natureza. Por isso, como dissemos, ao suposto da natureza divina foi atribuído a Paixão, não em razão
da natureza divina, que é impassível, mas em razão da natureza humana. Por isso diz a epístola sinodal
de Cirilo: Quem não confessar que o Verbo de Deus sofreu na sua carne e foi na sua carne crucificado,
seja anátema. Logo, a Paixão de Cristo deve ser atribuída ao suposto da natureza divina, em razão da
natureza passível assumida e não em razão da natureza divina impassível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que o Senhor da glória foi crucificado, não
enquanto Senhor da glória, mas enquanto homem passível.

RESPOSTA À SEGUNDA. — Como diz um sermão do Concílio Efesino, a morte de Cristo, foi à morte de
um Deus, por causa da união na pessoa; por isso destruiu a morte, porque quem sofria era Deus e
homem. Mas a natureza de Deus não padeceu nenhum detrimento, nem nenhum sofrimento por não
ter passado por qualquer mudança.

RESPOSTA À TERCEIRA. — Como no mesmo lugar se acrescenta, os judeus não crucificaram somente
um homem, mas foi o próprio Deus que fizeram o objeto das suas ofensas. Assim, suponde um príncipe
que dá instruções e as formula em uma carta, que envia às suas cidades. Se algum insubmisso rasgasse a
carta, seria condenado à morte, não por ter assim procedido, mas porque, desse modo, desfez as
instruções mesmas do príncipe. Os judeus não devem, portanto considerar-se em segurança, como se
tivessem crucificado apenas o homem. O que viam era uma como carta; e o que nela estava oculto era o
Verbo imperial, nascido da natureza, e não proferido pela língua.