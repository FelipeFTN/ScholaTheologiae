# Questão 20: Da sujeição de Cristo ao Pai
Em seguida devemos tratar do que convém a Cristo relativamente ao Pai. E nessa matéria certas coisas
se lhe atribuem relativamente ao Pai; por exemplo, o lhe ser sujeito, o lhe ter orado, o lhe ter servido
como sacerdote. Outras lhe são atribuídas ou lho podem ser pela relação do Pai para com ele; por
exemplo, o tê-lo o Pai adotado e predestinado.
Em primeiro lugar, pois, devemos tratar da sujeição de Cristo ao Pai. Segundo, da sua oração. Terceiro,
do seu sacerdócio. Quarto, se lhe convém a adoção. Quinto, da sua predestinação.
Na primeira questão discutem-se dois artigos:

## Art. 1 — Se devemos dizer que Cristo era sujeito ao Pai.
O primeiro discute-se assim. — Parece que não devemos dizer que Cristo fosse sujeito ao Pai.
1 — Pois, tudo o sujeito a Deus Pai é criatura; porque, como foi dito, na Trindade nada serve nem é
sujeito. Ora, não podemos dizer, em sentido absoluto, que Cristo seja uma criatura, como dissemos.
Logo, também não devemos dizer, em sentido absoluto, que Cristo fosse sujeito a Deus Pai.

2. Demais. — Dissemos que está sujeito a Deus o que lhe serve ao domínio. Ora, não podemos atribuir
nenhuma servidão à natureza humana de Cristo. Pois, diz Damasceno: Devemos saber, que não
podemos considerar sujeita à servidão a natureza humana de Cristo. Pois, as denominações de servidão
e de domínio não designam a natureza nem são sinais de conhecimento, mas exprimem relações, como
os nomes de paternidade e de filiação. Logo, Cristo, pela sua natureza humana, não está sujeito a Deus
Padre.

3. Demais. — O Apóstolo diz: E quando tudo lhe estiver sujeito, então ainda o mesmo Filho estará
sujeito aquele que sujeitou a ele todas as coisas. Ora, como diz ainda o Apóstolo, nós não vemos ainda
que lhe esteja sujeito tudo. Logo, Cristo ainda não está sujeito ao Pai, que lhe sujeitou tudo.
Mas, em contrario, o Senhor diz: O Pai é maior que eu. E Agostinho: Não impropriamente diz a Escritura
ser o Filho igual ao Pai e o Pai, maior que o Filho. Entendendo-se sem nenhuma confusão que é igual,
pela forma de Deus; e maior, por ter o Filho se revestido da forma de servo. Ora, o menor é sujeito ao
maior. Logo, Cristo, pela forma de servo, é sujeito ao Pai.

SOLUÇÃO. — Ao ser de uma determinada natureza convêm-lhe as propriedades dessa natureza. Ora, a
natureza humana, pela sua condição, está sujeita a Deus, de três modos. — Primeiro, pelo grau de
bondade. Pois, ao passo que a natureza divina é a bondade mesma por essência, como diz Dionísio, a
natureza criada tem uma certa participação da bondade divina, sendo como um raio projetado por ela.
— Segundo, a natureza humana está sujeita a Deus, quanto ao poder divino; isto é, enquanto que a
natureza humana, como qualquer outra criatura, está sujeita ao ato da disposição divina. — Terceiro, a
natureza humana especialmente está sujeita a Deus, pelo seu ato próprio; isto é, enquanto que, por
vontade própria, lhe obedece aos mandamentos.
E essa tríplice sujeição ao Pai, Cristo a confessa, de si mesmo. — A primeira, quando diz: Por que me
perguntas tu o que é bom? Bom só Deus o é. O que comenta Jerônimo: Aquele que chamara ao mestre,
bom e não o proclamara Deus ou Filho de Deus, fica sabendo que, apesar de ser um homem santo, não
é bom em comparação com Deus. Com o que quis significar que Cristo, pela sua natureza humana, não
chegava ao grau da bondade divina. E como, quando não se trata da grandeza material, ser maior é o
mesmo que ser melhor, na expressão de Agostinho, por isso, o Pai é considerado maior que Cristo,
quanto à natureza humana deste. — A segunda espécie de sujeição é atribuída a Cristo, por crermos que
o que Cristo praticou, na sua humanidade, ele o fez por disposição divina. Donde o dizer Dionísio, que
Cristo está sujeito às ordens de Deus Padre. E esta é uma sujeição de servidão, pela qual toda criatura
serve a Deus, sujeitando-se-lhe às ordens, conforme àquilo da Escritura: A criatura servindo-te a ti, seu
Criador. E neste sentido também o Apóstolo diz, que o Filho de Deus recebeu a forma de servo. — A
terceira sujeição, Cristo a si mesmo se atribui, quando diz: Eu sempre faço o que é do seu agrado. E essa
é a sujeição da obediência. Donde o dizer o Apóstolo: Feito obediente ao Pai até a morte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como não devemos pensar seja Cristo Criatura,
absolutamente falando, mas só em virtude da sua natureza humana, quer lhe acrescentemos, quer não,
qualquer restrição, como dissemos; assim também não devemos pensar, em sentido absoluto, que
Cristo fosse sujeito ao Pai, senão só pela sua natureza humana, mesmo se não lhe acrescentarmos essa
restrição. É conveniente porém lha acrescentarmos, para cortar o erro de Ario, que dizia ser o Filho
menor que o Pai.

RESPOSTA À SEGUNDA. — A relação de servidão e do domínio se funda na ação e na paixão; enquanto
que é próprio do servo ser movido pelo império do Senhor. Agir, porém, não o atribuímos à natureza
como agente, mas à pessoa; pois, o ato é próprio do suposto e do indivíduo, segundo o Filósofo. Mas, a
seção é atribuída à natureza como o meio pelo qual a pessoa ou a hipóstase age. Por onde, embora não
possamos dizer, propriamente, que a natureza é senhora ou serva podemos porém afirmar com
propriedade, que qualquer hipóstase ou pessoa seja senhora ou serva, segundo esta natureza
determinada, ou aquela outra. E assim, nada impede dizermos que Cristo está sujeito ao Pai ou lhe é
servo, pela sua natureza humana.

RESPOSTA À TERCEIRA. — Diz Agostinho: Então Cristo transmitirá o seu reino a Deus e ao Pai, quando
conduzir a plena visão os justos sobre os quais reina pela fé, de modo que contemplem a essência
comum do Pai e do Filho. E então estará totalmente sujeito ao Pai não só em si mesmo, mas também
nos seus membros, pela plena participação da vontade divina. Embora, pois, atualmente todas as causas
lhe estejam sujeitas, quanto ao seu poder, conforme o Evangelho: Tem-se me dado o poder no céu e na
terra.

## Art. 2 — Se Cristo estava sujeito a si próprio.
O segundo discute-se assim. — Parece que Cristo não estava sujeito a si próprio.

1. — Pois, diz Cirilo, numa Epístola aceita pelo Sínodo Efesino: Não era Cristo seu próprio servo nem
senhor. E assim, é fátuo, e ainda mais, impio, senti-lo e dizê-lo, O que também afirma Damasceno
quando diz: O mesmo ser, Cristo, não podia ser servo e senhor de si mesmo. Ora, Cristo é chamado
servo do Pai enquanto lhe está sujeito. Logo, Cristo não estava sujeito a si mesmo.

2. Demais. — O servo supõe o senhor. Ora, não pode haver relação de um ser para consigo mesmo; e
por isso diz Hilário, que nada é semelhante ou igual a si mesmo. Logo, não podemos dizer fosse Cristo
senhor de si mesmo. E por consequência, nem que a si mesmo estivesse sujeito.

3. Demais. — Assim como a alma racional e a carne constituem um só homem; assim o Deus e o homem
constituem um só Cristo, no dizer de Atanásio. Ora, não dizemos, de ninguém, que esteja sujeito a si
mesmo ou seja servo de si mesmo ou seja maior que si mesmo, pelo fato de ter o corpo sujeito à alma.
Logo, nem que Cristo fosse sujeito a si mesmo, pelo fato de ser a sua humanidade sujeita à divindade.
Mas, em contrario, Agostinho diz: A verdade mostra, deste modo, isto é, pelo qual o Pai é maior que
Cristo segundo a natureza humana, que o Filho é menor que si próprio.
Demais. — Como Agostinho argumenta no mesmo lugar, o Filho de Deus recebeu a forma de servo mas
de modo a não perder a forma de Deus. Ora, pela forma de Deus, comum ao Pai e ao Filho, o Pai é maior
que o Filho segundo a natureza humana. Logo, também o Filho é maior que si próprio segundo a
natureza humana.
Demais. — Cristo, segundo a natureza humana, é servo de Deus Padre, conforme àquilo do Evangelho.
Vou para meu Pai e vosso Pai, para meu Deus e vosso Deus. Ora, quem é servo do Pai o é também do
Filho; do contrário, nem tudo o que é do Pai seria do Filho. Logo, Cristo é servo de si mesmo e a si
mesmo sujeito.

SOLUÇÃO. — Como dissemos, ser senhor e servo é atributo da pessoa ou da hipóstase, segundo uma
certa natureza. Quando, pois, dizemos que Cristo é Senhor ou servo de si mesmo, ou que o Verbo de
Deus é Senhor do homem Cristo, essas expressões podemos entendê-las de dois modos. - Num sentido
se aplicam em razão de uma hipóstase ou pessoa; como se uma seja a Pessoa do Verbo de Deus, como
senhor, e outra a do homem, como servo; o que constitui a heresia de Nestório. Por isso, na condenação
de Nestório, diz o Sínodo Efesino: Quem disser que é Deus ou Senhor o Verbo de Cristo, procedente de
Deus Padre, e não o confessar simultaneamente como Deus é homem, por ter o Verbo sido feito carne,
segundo as Escrituras, seja anátema. E é nesse sentido que o negam Cirilo e Damasceno; devendo-se no
mesmo sentido negar que Cristo fosse menor que si próprio, ou a si próprio sujeito. — De outro modo
podemos entender as referidas expressões relativamente à diversidade de naturezas numa mesma
Pessoa ou hipóstase. E então podemos dizer, relativamente a uma delas, na qual convém com o Padre,
que Cristo, simultaneamente com o Pai é senhor e domina; relativamente porém à outra natureza, na
qual convém conosco, está sujeito e serve. E, neste sentido, Agostinho diz ser o Filho menor que si
próprio.
É mister porém saber que, sendo o nome de Cristo um nome de Pessoa, como o é o nome de Filho,
podemos atribuir a Cristo, essencial e absolutamente falando, o que lhe convém em razão da sua
Pessoa, que é eterna; e sobretudo essas relações consideradas como mais propriamente pertencentes à
pessoa ou à hipóstase. Ao passo que o que lhe convém segundo a natureza humana, devemos, antes,
lhe atribuir com restrição. Assim, podemos dizer que Cristo é, absolutamente falando, Máximo, Senhor
e Chefe; mas o ser sujeito ou servo ou menor devemos lhe atribuir com restrição, isto é, segundo a
natureza humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cirilo e Damasceno negam fosse Cristo Senhor de si
mesmo, se isso importar pluralidade de supostos, necessária para alguém ser senhor de si mesmo,
absolutamente falando.

RESPOSTA À SEGUNDA. — Absolutamente falando, é necessário que o senhor seja diferente do servo;
pode porém o domínio e a servidão se revestirem de um certo aspecto, de modo que possa alguém ser
senhor e servo de si mesmo, a luzes diversas.

RESPOSTA À TERCEIRA. — Por causa das partes diversas do homem, das quais uma é superior e outra
inferior, diz também o Filósofo, que pode haver justiça do homem para consigo mesmo, quando o
irascível e o concupiscível obedecem à razão. E assim, desse modo, pode um homem considerar-se
sujeito a si mesmo e de si mesmo servidor, conforme as suas partes diversas.
As RESPOSTAS aos outros argumentos resultam claras do que ficou dito. — Assim, Agostinho afirma que
o Filho é menor que si próprio, ou a si mesmo sujeito, segundo a natureza humana, não segundo a
diversidade de supostos.