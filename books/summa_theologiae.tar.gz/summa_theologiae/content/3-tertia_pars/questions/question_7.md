# Questão 7: Da graça de Cristo como um homem particular
Em seguida devemos tratar do que o Verbo de Deus consumiu, ao assumir a natureza humana. E
primeiro do que respeita à perfeição. Segundo, do que respeita aos defeitos.
No primeiro ponto consideram-se três outros. Primeiro, da graça de Cristo. Segundo, da sua ciência.
Terceiro, do seu poder.
Quanto à graça de Cristo dá ela lugar a duas considerações. Primeiro, da sua graça enquanto um homem
particular. Segundo, da sua graça enquanto Chefe da Igreja. Pois, da graça da união já tratamos.
Na primeira questão discutem-se treze artigos:

## Art. 1 — Se na alma assumida pelo Verbo havia a graça habitual.
O primeiro discute-se assim. — Parece que na alma assumida pelo Verbo não havia a graça habitual.

1. — Pois, a graça é uma certa participação da divindade na criatura racional, segundo a Escritura: Pelo
qual nos comunicou as mui grandes e preciosas graças que tinha prometido, para que sejamos feitos
participantes da natureza divina. Ora, Cristo é Deus, não participativa, mas verdadeiramente. Logo, nele
não houve graça habitual.

2. Demais. — A graça é necessária ao homem para proceder bem, segundo o Apóstolo: Tenho
trabalhado mais copiosamente que todos eles; não eu contudo, mas a graça de Deus comigo. E também
para alcançar a vida eterna, segundo ainda o Apóstolo: A graça de Deus é a Vida perdurável. Ora, a
Cristo, só pelo fato de ser naturalmente o Filho de Deus, era-lhe devida a herança da vida eterna; e
também por ser o Verbo, pelo qual todas as coisas foram feitas, tinha a faculdade de proceder bem em
todas as coisas. Logo, não precisava, em virtude da sua natureza humana, de outra graça, senão da
união com o Verbo.

3. Demais. — O que opera a modo de instrumento não precisa de nenhum hábito para as suas
operações próprias; porque o hábito se funda no agente principal. Ora, a natureza humana, em Cristo,
era como o instrumento da divindade, no dizer de Damasceno. Logo, não devia de haver, em Cristo,
nenhuma graça habitual.
Mas, em contrário, a Escritura: Descansará sobre ele o Espírito do Senhor, do qual se diz que está no
homem pela graça habitual, como se demonstrou na Primeira Parte. Logo, em Cristo havia a graça
habitual.

SOLUÇÃO. — Devemos admitir em Cristo a graça habitual, por três razões. — Primeiro, por causa da
união da sua alma com o Verbo de Deus. Pois, quanto mais próximo está um ser da causa que influi
sobre ele, tanto mais participa da sua influência. Ora, o influxo da graça vem de Deus, segundo a
Escritura: O Senhor dará a graça e a glória. Por isso era conveniente em máximo grau que a sua alma
recebesse o influxo da graça divina. — Segundo, por causa da nobreza da sua alma, cujas operações
deviam tocar a Deus de muito perto pelo conhecimento e pelo amor; e para isso é preciso a natureza
humana ser elevada pela graça. — Terceiro, por causa das relações de Cristo com o gênero humano.
Pois, Cristo enquanto homem é o mediador entre Deus e os homens, no dizer do Apóstolo. Por isso
deveria ter uma graça capaz de redundar nos outros, conforme o Evangelho: Todos nós participamos de
sua plenitude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo é verdadeiramente Deus pela pessoa e pela
natureza divina. Mas, como com a unidade de pessoa subsiste a distinção das naturezas, conforme do
sobredito se colige, a alma de Cristo não é por sua essência divina. Por onde, havia de se tornar divina
por participação, que é segundo a graça.

RESPOSTA À SEGUNDA. — A Cristo, enquanto por natureza filho de Deus, é devida a herança eterna,
que é a própria beatitude incriada, pelo ato incriado do conhecimento e do amor de Deus, ato que é o
mesmo pelo qual o Pai se conhece e ama a si mesmo. E desse ato a alma não era capaz por causa da
diferença de natureza. Por isso, era necessário que se alçasse a Deus por um ato criado de fruição. O
que não pode ser senão pela graça. — Semelhantemente, enquanto Verbo de Deus, tinha a faculdade
de proceder bem em tudo, por operação divina. Mas, como além da operação divina, devemos admitir
nele a operação humana, conforme a seguir se demonstrará, era mister que tivesse a graça habitual,
que torna perfeita a sua referida operação.

RESPOSTA À TERCEIRA. — A humanidade de Cristo é o instrumento da divindade; não, certo, como um
instrumento inanimado, que de nenhum modo, age, mas é manejado por outro; mas como um
instrumento animado pela alma racional, que é manejado por outro mas de modo que também age. E
portanto, para a sua ação própria era necessário tivesse a graça habitual.

## Art. 2 — Se em Cristo havia virtudes.
O segundo discute-se assim. — Parece que em Cristo não havia virtudes.
1 — Pois, Cristo tinha a abundância da graça. Ora, a graça basta para agirmos sempre retamente,
segundo o Apóstolo: Basta-te a minha graça. Logo, em Cristo não havia virtudes.

2. Demais. — Segundo o Filósofo, a virtude se divide, por oposição, de um certo hábito heroico ou
divino, atribuído aos homens divinos. Ora, isso convém sobremaneira a Cristo. Logo, Cristo não tinha
virtudes, mas algo mais elevado que a virtude.
Demais. — Como na Segunda Parte se demonstrou, todas as virtudes são possuídas simultaneamente.
Ora, a Cristo não convinha ter simultaneamente todas as virtudes; como é o caso da liberalidade e da
magnificência, cujos atos recaem sobre as riquezas, que Cristo desprezava, segundo o Evangelho: O
Filho do homem não tem onde reclinar a cabeça. E também a temperança e a continência, que
reprimem as concupiscências depravadas, que em Cristo não existiam. Logo, Cristo não tinha as
virtudes.
Mas, em contrário, àquilo da Escritura - A sua vontade está posta na lei do Senhor - diz a Glosa: Isto
mostra que Cristo era rico de todos os bens. Ora, a virtude é uma boa qualidade da alma. Logo, Cristo
teve a plenitude de todas as virtudes.

SOLUÇÃO. — Como estabelecemos na Segunda Parte, assim como a graça respeita à essência da alma,
assim a virtude lhe respeita a potência. Por onde e necessariamente,. assim: como a potências da alma
lhe derivam da essência. assim as virtudes são umas derivações da graça. Ora, quanto mais perfeito é
um princípio tanto mais imprime os seus efeitos. Por onde, tendo sido perfeitíssima a graça de Cristo,
consequentemente dela procederam virtudes para aperfeiçoarem cada uma das potências da sua alma,
quanto a todos os atos desta. É portanto Cristo teve todas as virtudes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A graça basta ao homem em relação a todas aquelas
coisas pelas quais se ordena à beatitude. Mas certas delas a graça as aperfeiçoa imediatamente por si
mesma como o torná-lo agradável a Deus e outras semelhantes; e certas outras. mediante as virtudes
procedentes da graça.

RESPOSTA À SEGUNDA. — Esse hábito heroico ou divino não difere da virtude em geral, senão pelo seu
modo mais perfeito; isto é, quando alguém tem uma disposição para o bem, de um certo modo mais
alto, quero que geralmente os homens tem. Por onde, isso não demonstra que Cristo não tivesse as.
virtudes, mas que as tinha perfeitíssima e superiormente ao modo comum. Assim também Plotino
admite um certo e sublime modo das virtudes, que dizia serem as da alma purificada.

RESPOSTA À TERCEIRA. — A liberdade e a magnificiência se exercem sobre as riquezas, porque quem é
dotado dessas virtudes não aprecia as riquezas a ponto de querer conservá-las omitindo o que com elas
devia fazer. Mas de nenhum. modo aprecia as riquezas quem as despreza de todo e as rejeita, pela
perfeição do amor. Por onde, por isso mesmo que Cristo desprezou todas as riquezas mostrou possuir
em sumo grau a liberalidade e a magnificiência. Embora também exercesse atos de liberalidade,
enquanto isso lhe era congruente, fazendo distribuir aos pobres os donativos que recebia. E assim,
quando o Senhor disse a Judas — O que fazes, faze-o depressa — entenderam os discípulos que lhe
mandou desse alguma coisa aos pobres. Quanto às baixas concupiscências, Cristo de nenhum modo as
teve, como a seguir demonstraremos. Mas isso não o impedia o exercício da temperança, tanto mais
perfeita no homem quanto mais ele carece dessas concupiscências depravadas. Por isso diz o Filósofo,
que o temperado difere do continente, por não existirem naquele as concupiscências depravadas, cujo
jugo este sofre. E portanto, entendendo assim a continência, como a entende o Filósofo, por isso
mesmo que Cristo teve todas as virtudes não teve a continência que não é uma virtude mas algo menos
que uma virtude.

## Art. 3 — Se em Cristo existiu a fé.
O terceiro discute-se assim. — Parece que em Cristo existiu a fé.

1. — Pois, a fé é uma virtude mais nobre que as virtudes morais como a temperança e a liberalidade.
Ora, estas virtudes existiram em Cristo, como se disse. Logo, com maior razão nele existiu a fé.

2. Demais. — Cristo não ensinou virtudes que não tinha, segundo aquilo da Escritura: Começou a jazer e
a ensinar. Ora, de Cristo também diz o Apóstolo: Autor e consumador da fé. Logo, nele existiu por
excelência a fé.

3. Demais. — Dos bem-aventurados se exclui toda imperfeição. Ora, os bem-aventurados tem a fé; pois,
àquilo do Apóstolo - A justiça de Deus se descobre nele de fé em fé - diz a Ciosa: A fé nas palavras e nos
bens que esperamos torna-se a jé nas coisas mesmas e a visão clara. Logo, parece que também Cristo
teve a fé, pois que nenhuma imperfeição nele existe.
Mas, em contrário, diz o Apóstolo: A fé é um argumento das coisas que não aparecem. Ora, para Cristo
nada houve de não aparente, conforme lho disse Pedro: Tu conheces tudo, Logo, em Cristo não havia fé.

SOLUÇÃO. — Como demonstramos na Segunda Parte, o objeto da fé é a realidade divina não vista. Ora,
o hábito da virtude, como qualquer outro, se especifica pelo seu objeto. E portanto suprimida essa
condição — que a realidade divina não é vista, excluída fica na sua essência a fé. Ora, Cristo, desde o
primeiro instante da sua concepção, viu plenamente a Deus em essência, como a seguir se verá. Logo,
nele não podia existir a fé.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A fé é uma virtude mais nobre que as virtudes morais
porque versa sobre matéria mais nobre; contudo implica uma certa deficiência relativamente a essa
matéria, deficiência que em Cristo não existiu. Logo, não podia nele existir a fé, embora tivesse ele as
virtudes morais, que por essência não implicam essa deficiência relativamente às suas matérias.

RESPOSTA À SEGUNDA. — O mérito da fé consiste em assentirmos, por obediência a Deus, no que não
vemos, segundo aquilo do Apóstolo: Para que se obedeça à fé em todas as gentes pelo seu nome. Ora,
Cristo praticou plenissimamente a obediência para com Deus, segundo o Apóstolo: Feito obediente até
à morte. E assim nada ensinou que fosse uma fonte de mérito que não o praticasse ele próprio de
maneira mais excelente.

RESPOSTA À TERCEIRA. — Como diz a Glosa no mesmo lugar, pela fé cremos propriamente no que não
vemos. E impropriamente se chama fé a que tem por objeto o que vemos, e só por certa semelhança,
quanto à certeza ou a firmeza da adesão.

## Art. 4 — Se em Cristo existia a esperança.
O quarto discute-se assim. — Parece que em Cristo existia a esperança.

1. — Pois, diz a Escritura, da pessoa de Cristo, segundo a Glosa: Em ti, Senhor, esperei. Ora, a virtude da
esperança é a pela qual esperamos em Deus. Logo, Cristo teve a virtude da esperança.

2. Demais. — A esperança é a expectação da beatitude futura, como demonstramos na Segunda Parte.
Ora, Cristo esperava algo de pertinente à beatitude, a saber, a glória do corpo. Logo, parece que nele
houve a esperança.

3. Demais. — Cada qual pode esperar o que lhe condisser com a perfeição, se for futuro. Ora, havia algo
de futuro, pertinente à perfeição de Cristo, segundo o Apóstolo: Para a consumação dos santos em
ordem à obra do ministério, para edificar o corpo de Cristo. Logo, parece que cabia a Cristo ter
esperança.
Mas, em contrário, o Apóstolo: O que qualquer vê como o espera? Por onde é claro que, como a fé tem
por objeto o que não vemos, assim, também a esperança. Ora, não havia fé em Cristo, como se disse.
Logo, nem esperança.

SOLUÇÃO. — Assim como é da essência da fé o assentirmos no que não vemos, assim, é da essência da
esperança termos a expectação do que ainda não possuímos. E assim como a fé, enquanto virtude
teologal, não tem por objeto qualquer ser não visto, mas só Deus, assim também a esperança, enquanto
virtude teologal tem por objeto a fruição mesma de Deus, o que principalmente temos em vista pela
virtude da esperança. Mas, por consequência, quem possui a virtude da esperança pode também
esperar o auxílio divino em outras matérias; assim como quem tem a virtude da fé não somente crê a
Deus, em se tratando das coisas divinas, mas de tudo o mais que lhe tenha sido divinamente revelado.
Ora, Cristo, desde o momento da sua concepção, teve a plena fruição divina, como a seguir
demonstraremos. E portanto, não teve a virtude da esperança. Mas tinha a esperança relativamente a
certas coisas que ainda não havia alcançado, embora não tivesse a fé relativamente a coisas quaisquer.
Pois, embora conhecesse todas as coisas, o que dele totalmente excluía a fé, contudo, ainda não tinha
plenamente tudo o que lhe pertencia à perfeição, por exemplo a imortalidade e a glória do corpo, que
podia esperar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lugar aduzido não se aplica a Cristo, quanto à
esperança, como virtude teologal; mas porque esperava certas coisas que ainda não tinha, como se
disse.

RESPOSTA À SEGUNDA. — A glória do corpo não pertence à beatitude como o em que ela
principalmente consiste; mas, por uma certa redundância da glória da alma, como se disse na Segunda
Parte. Por onde, a esperança, enquanto virtude teologal, não respeita à beatitude do corpo, mas à da
alma, que consiste na fruição divina.

RESPOSTA À TERCEIRA. — A edificação da Igreja, pela conversão dos fiéis, não pertence à perfeição de
Cristo, enquanto perfeito em si mesmo; mas enquanto leva os outros a participar da sua perfeição. E
como a esperança propriamente é dita em relação aquilo que quem espera está na expectativa de
possuir, não se pode propriamente dizer que a virtude da esperança conviesse a Cristo, pela razão
aduzida.

## Art. 5 — Se em Cristo existiam os dons.
O quinto discute-se assim. — Parece que em Cristo não existiam os dons.
1 — Pois, como geralmente se diz, os dons são conferidos como ajutórios das virtudes. Ora, o em si
mesmo perfeito não precisa de auxílio externo. Logo, como Cristo tinha a perfeição das virtudes, nele
não existiram os dons.

2. Demais. — Não pode a mesma pessoa conferir e receber os dons; pois, dá quem tem e recebe quem
não tem. Ora, Cristo podia conferir dons, segundo a Escritura: Tornaste dons para. os distribuíres aos
homens. Logo, não podia receber os dons do Espírito Santo.

3. Demais. — São quatro os dons próprios da vida contemplativa, a saber: a sabedoria, a ciência, o
intelecto e o conselho; o que pertence à prudência, enumerando por isso o Filósofo esses dons entre as
virtudes intelectuais. Ora, Cristo tinha a contemplação do céu. Logo, não tinha os referidos dons.
Mas, em contrário, a Escritura: Lançaram mão de um só homem sete mulheres. Ao que diz a Glosa: Isto
é, os sete dons do Espírito Santo, Cristo.

SOLUÇÃO. — Como dissemos na Segunda Parte, os dons são propriamente umas certas perfeições das
potências da alma, que lhes torna natural o serem movidas pelo Espírito Santo. Ora, como é manifesto,
a alma de Cristo era perfeitissimamente movida pelo Espírito Santo, segundo o Evangelho: Cheio, pois,
do Espírito Santo, voltou Jesus do Jordão e foi levado pelo Espírito ao deserto. Por onde, é manifesto
que em Cristo existiam excelentissimamente os dons.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O perfeito na ordem da sua natureza necessita ser
ajudado pelo que é de natureza superior; assim o homem, por mais perfeito que seja precisa de ser
ajudado por Deus. E deste modo as virtudes precisam ser fortificadas pelos dons, que aperfeiçoam as
potências de alma, enquanto movidas pelo Espírito Santo.

RESPOSTA À SEGUNDA. Cristo não recebe e confere os dons do Espírito Santo, aos mesmos respeitos;
mas, ele os confere como Deus, e os recebe como homem. Donde o dizer Gregório: O Espírito Santo não
abandonou nunca a humanidade de Cristo, de cuja divindade procede.

RESPOSTA À TERCEIRA. — Em Cristo não somente havia o conhecimento da pátria, mas também o da
via, como a seguir se dirá. E contudo, mesmo na pátria, existem de certo modo os dons do Espírito
Santo, como na Segunda Parte se estabeleceu.

## Art. 6 — Se em Cristo houve o dom do temor.
O sexto discute-se assim. — Parece que em Cristo não houve o dom do temor.

1. — Pois, a esperança parece mais principal que o temor, porque sendo o objeto dela o bem, o dele é o
mal, como na Segunda Parte se estabeleceu. Ora, em Cristo não havia a virtude da esperança, conforme
se demonstrou. Logo, também não havia nele o dom do temor.

2. Demais. — Pelo dom do temor tememos a separação de Deus, o que constitui o temor casto; ou o
sermos punidos por ele, o que constitui o temor servil, como diz Agostinho. Ora, Cristo não temia ser
separado de Deus, pelo pecado; nem ser punido por ele. por culpa; pois, era-lhe impossível pecar, como
depois se dirá. Ora, não há temor do impossível. Logo, em Cristo não houve o dom do temor.

3. Demais. — A Escritura diz: A caridade perfeita lança fora o temor. Ora, Cristo tinha a caridade
perfeitíssima, segundo o Apóstolo: A caridade de Cristo que excede todo entendimento. Logo. em Cristo
não havia o dom do temor.
Mas, em contrário, a Escritura: E enche-lo-á o Espírito do temor do Senhor.

SOLUÇÃO. — Como dissemos na Segunda Parte, o temor respeita dois objetos: um é o mal que
atemoriza; o outro, quem tem o poder de fazer o mal e assim teme-se o rei porque tem o poder de
matar. Ora, não temeríamos quem tem o poder se este não fosse de uma eminência tal que não lhe
pudéssemos facilmente resistir; pois, não tememos o que podemos prontamente repelir. Por onde, é
claro que não tememos a outrem senão por causa da sua eminência. E portanto, devemos concluir que
em Cristo houve o temor de Deus, não enquanto respeita o mal da separação de Deus pela culpa nem
enquanto respeita o mal da punição por causa da culpa; mas enquanto respeita a própria eminência
divina. Isto é, enquanto que a alma de Cristo eleva-se para Deus por um certo afeto de reverência,
levada do Espírito Santo. Donde o dizer o Apóstolo, que em tudo foi atendido pela sua reverência. Ora,
esse afeto de reverência para com Deus, Cristo, enquanto homem, teve-o em maior plenitude que os
demais. Por isso, a Escritura lhe atribui a plenitude do dom do temor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os hábitos das virtudes e dos dons própria e
essencialmente respeitam o bem; e o mal, por consequência. Pois, é da essência da virtude tornar a
obra boa, como diz Aristóteles. Por onde, não é da essência do dom do temor aquele mal a que se
refere o temor; mas,a eminência daquele bem, isto é, divino, por cujo poder um mal pode ser infligido.
Ora, a esperança, enquanto virtude, respeita não só o autor do bem, mas o próprio bem, enquanto não
possuído. Por onde, a Cristo, que já tinha o bem perfeito da beatitude, não se lhe atribui a virtude da
esperança, mas, o dom do temor.

RESPOSTA À SEGUNDA. — A objeção colhe, do temor enquanto respeita ao objeto, que é o mal.

RESPOSTA À TERCEIRA. — A caridade perfeita expulsa o temor servil, que respeita principalmente à
pena. Ora, nesse sentido, não houve temor em Cristo.

## Art. 7 — Se em Cristo havia as graças gratuitas.
O sétimo discute-se assim. — Parece que em Cristo não havia as graças gratuitas.

1. — Pois, quem possui a plenitude de um bem não irá possuí-lo por participação. Ora, Cristo tinha a
plenitude da graça, conforme o Evangelho: Cheio de graça e de verdade. Ora, as graças gratuitas parece
umas participações divinas atribuídas dividida e particularmente a diversos, segundo o Apóstolo: Há
repartição de graças. Logo, parece que em Cristo não havia as graças gratuitas.

2. Demais. — O devido a alguém não lhe é dado de graça. Ora, era devida ao homem Cristo a
abundância em palavras de sabedoria e de ciência, o ser eminente na prática das virtudes, e outras
semelhantes graças gratuitas; pois, ele é, no dizer do Apóstolo, a virtude de Deus e a sabedoria de Deus.
Logo, não convinha a Cristo ter as graças gratuitas.

3. Demais — As graças gratuitas se ordenam à utilidade dos fiéis, segundo o Apóstolo: A cada um é dada
a manifestação do Espírito para proveito. Ora, não constitui utilidade para ninguém um hábito ou uma
disposição qualquer, se deles não usa, segundo a Escritura: Suponha-se que a sabedoria se conserva
escondida e que o tesouro não está visível, que utilidade haverá em ambas estas coisas? Ora, não lemos
no Evangelho que Cristo usasse de todas as graças gratuitas, sobretudo quanto aos gêneros das línguas.
Logo, em Cristo não existiam todas as graças gratuitas.
Mas, em contrário, diz Agostinho, que assim como na cabeça estão todos os sentidos, assim em Cristo
existiam todas as graças.

SOLUÇÃO. — Como se estabeleceu na Segunda Parte, as graças gratuitas se ordenam à manifestação da
fé e da doutrina espiritual. Pois, é necessário quem ensina ter os meios de manifestar a sua doutrina,
que, do contrário, seria inútil. Ora, o primeiro e principal Doutor da doutrina espiritual e da fé é Cristo,
segundo o Apóstolo: A qual tendo sido começado a ser anunciada pelo Senhor, foi depois confirmada
entre nós pelos que a ouviram, confirmando-a ao mesmo tempo Deus com sinais e maravilhas, etc. Por
onde, é manifesto que Cristo teve excelentissimamente todas as graças gratuitas, como primeiro e
principal Doutor da fé.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como a graça santificante se ordena aos atos meritórios,
tanto interiores como exteriores, assim, as graças gratuitas se ordenam a certos atos exteriores
manifestativos da fé, como a operação de milagres e outros semelhantes. Ora, de ambas essas graças
Cristo teve a plenitude; pois, por estar a sua alma unida à divindade, tinha plena eficácia para praticar
com perfeição todos os referidos atos. Ao passo que os outros santos movidos por Deus como
instrumentos não unidos, mas separados, recebem uma eficácia particular para realizar tais atos ou tais
outros. Por isso, os outros santos tem essas graças divididas, mas não Cristo.

RESPOSTA À SEGUNDA. — Cristo é chamado a virtude de Deus e a sabedoria de Deus, enquanto Filho
eterno de Deus. E como tal não lhe cabe ter a graça, mas antes, ser o distribuidor dela. Cabe-lhe, porém,
ter a graça, pela sua natureza humana.

RESPOSTA À TERCEIRA. — O dom das línguas foi dado aos Apóstolos, porque foram enviados a ensinar:
todos os povos. Ao passo que Cristo quis pregar pessoalmente só à gente dos Judeus, como ele próprio
o disse: Eu não fui enviado senão às ovelhas que pereceram da casa de Israel. E o Apóstolo: Digo de
Jesus Cristo foi ministro da circuncisão. Por isso não tinha necessidade de falar muitas línguas. Mas nem
por isso lhe faltou o conhecimento delas; a ele a quem não se lhe esconde nem o oculto nas
profundezas dos corações, como depois diremos, do que as palavras, quaisquer que sejam, são os sinais.
Nem contudo lhe foi inútil esse conhecimento que tinha: assim como não tem inutilmente um hábito
quem dele não usa quando não é oportuno.

## Art. 8 — Se Cristo teve a profecia.
Oitavo discute-se assim. — Parece que Cristo não tinha o dom da profecia.

1. — Pois, a profecia implica um certo conhecimento obscuro e imperfeito, segundo a Escritura: Se entre
vós se achar algum profeta do Senhor, eu lhe aparecerei em visão ou lhe falarei em sonhos. Ora, Cristo
teve um conhecimento pleno e patente, muito mais que Moisés de quem a Escritura acrescenta no
mesmo lugar: Ele vê claramente o Senhor e não debaixo de enigmas. Logo, não devemos atribuir a
Cristo a profecia.

2. Demais. — Como o objeto da fé é o que nós não vemos, e o da esperança o que não temos assim o da
profecia é o que não está presente, mas distante; pois, profeta é chamado quem anuncia o que está
longe (procul fans). Ora, em Cristo não havia fé nem esperança, como se disse. Logo, também não
devemos atribuir a Cristo a profecia.

3. Demais. — O profeta é de ordem inferior ao anjo; por isso, de Moisés, que foi o supremo dos
profetas, como mostramos na Segunda Parte, diz o Apóstolo, este é o que falava com o anjo na solidão.
Ora, Cristo não foi menor que os anjos, pelo conhecimento da alma mas só pelo sofrimento do corpo.
Logo, parece que Cristo não foi profeta.
Mas, em contrário, dele diz a Escritura: O Senhor teu Deus te suscitará um profeta dentre teus irmãos. E
Cristo diz de si mesmo: Um profeta não tem honra na sua pátria.

SOLUÇÃO. — Profeta é chamado, por assim dizer quem anuncia ou vê o que está longe (procul stans);
isto é, quem conhece e anuncia o que está afastado dos sentidos dos homens, como também o diz
Agostinho. Ora, devemos considerar que não pode ser chamado profeta quem conhece e anuncia o que
está distante para outros, com os quais ele não convive. E isto é manifesto, quanto ao lugar e quanto ao
tempo. Assim, pois, quem, vivendo na França, conhecesse e anunciasse a outros, que também vivessem
nesse mesmo país, o que então se passasse na Síria, fazia um anúncio profético; tal como Eliseu, quando
anunciou a Giezi que um homem descia de um carro e lhe vinha ao encontro. Mas quem, vivendo na
Síria, anunciasse coisas que aí mesmo se passassem, não anunciaria nada de profético. E o mesmo se dá
no tempo. Assim, Isaías predisse profeticamente que Ciro, rei dos Persas, haveria de reedificar o templo
de Deus. Mas, nada houve de profético no que Esdras escreveu sobre o que se realizou no seu tempo.
Se, portanto, Deus e os anjos, ou também os santos, conhecem e anunciam o distante do nosso
conhecimento isso não constitui nenhuma profecia, porque em nada eles participam da nossa condição.
Ora, Cristo, antes da paixão, participava da nossa condição, porque não somente gozava da visão clara,
mas era também viandante como nós. E portanto, era profético o que, estando distante do
conhecimento dos outros viandantes, ele o conhecia e anunciava. E por isso dizemos que nele havia a
profecia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Responde-se que essas palavras não pretendem
significar seja da natureza da profecia o conhecimento enigmático, que se dá pelo sonho e na visão; mas
fazem uma comparação dos outros profetas, que perceberam as coisas divinas pelo sonho e em visão,
com Moisés, que viu a Deus face a face e não por enigmas; que contudo é chamado profeta, segundo
aquilo: Não se levantou mais em Israel profeta algum como Moisés. Entretanto, podemos dizer que,
embora Cristo tivesse um conhecimento pleno e compreensivo, quanto à sua faculdade intelectiva,
realizava todavia, na sua faculdade imaginativa, certas semelhanças, através das quais podia também
entender as coisas divinas, por ser não somente compreensor mas também viandante.

DONDE A RESPOSTA À SEGUNDA. — A fé tem por objeto o que é invisível ao crente; e
semelhantemente, a esperança, o que ainda não é possuído por quem espera. Mas, a profecia tem por
objeto o distante ao conhecimento do comum dos homens, com quem o profeta convive e comunica,
pela condição da vida presente. Por isso, a fé e a esperança repugnavam à perfeição da santidade de
Cristo, não porém, a profecia.

RESPOSTA À TERCEIRA. — O anjo, gozando da visão beatífica, é superior ao profeta, que ainda é
viandante; mas não, superior a Cristo, que ao mesmo tempo que era viandante, gozava da visão clara.

## Art. 9 — Se Cristo tinha a plenitude da graça.
O nono discute-se assim. — Parece que Cristo não tinha a plenitude da graça.

1. — Pois, da graça derivam as virtudes, como se disse na Segunda Parte. Ora, Cristo não tinha todas as
virtudes; assim, não tinha a fé nem a esperança, como se demonstrou. Logo, Cristo não tinha a
plenitude da graça.

2. Demais. — Como resulta do dito na Segunda Parte, a graça, se divide em operante e cooperante.
Chama-se graça operante a pela qual o ímpio se justifica; o que não tinha lugar em Cristo, que não caiu
nunca em nenhum pecado. Logo, Cristo não teve a plenitude da graça.

3. Demais. — A Escritura diz: Toda dádiva em extremo excelente e toda dom perfeito vem lá de cima e
desce do Pai das luzes. Ora, o que desce é possuído particular e não plenamente. Logo, nenhuma
criatura, nem mesmo a alma de Cristo, pode ter a plenitude dos dons da graça.
Mas, em contrário, diz o Evangelho: Nós o vimos cheio de graça e de verdade.

SOLUÇÃO. — Diz-se que é possuído plenamente o que o é perfeita e totalmente. Ora, a totalidade e a
perfeição podem ser consideradas a dupla luz. Primeiro, quanto à sua quantidade intensiva; por
exemplo, se disser que alguém tem a plenitude da brancura pela ter quanto lho permite a natureza. De
outro modo, pela virtude; por exemplo, quando dizemos de alguém que tem plenamente a vida pela ter
segundo todos os efeitos e operações vitais; e, assim, o homem tem plenamente a vida, mas não o
bruto nem a planta.
Ora, de ambos os modos, Cristo teve a plenitude da graça.
Primeiro, pela ter em sumo grau, do modo perfeitíssimo pelo qual ela pode ser possuída. E isto resulta,
primeiro, da proximidade da alma de Cristo, da causa da graça. Pois, como dissemos, quanto mais um
ser que recebe a influência de outro está próximo dessa causa influente, tanto mais abundantemente, a
recebe. E portanto, a alma de Cristo, mais estreitamente unida a Deus que todas as criaturas racionais,
recebeu em supremo grau a influência da sua graça. — Segundo, pela comparação com o seu efeito,
pois a alma de Cristo recebeu a graça para, de certo modo, transfundi-la nos outros. E por isso era
necessário que tivesse a graça máxima; assim como o fogo, causa do calor em todos os corpos quentes,
é quente por excelência.
Também e semelhantemente, quanto à virtude da graça, teve-a plenamente, pela ter em relação a
todas as operações ou efeitos da graça. E isto por lhe ter sido conferida a graça como a um certo
princípio universal, no gênero dos que a tem. Ora, a virtude do primeiro princípio de um determinado
gênero, se estende universalmente a todos os efeitos desse gênero; assim, o sol, causa universal da
geração, como diz Dionísio, estende a sua virtude a tudo o que entra a ser gerado. E assim, a segunda
plenitude da graça se funda, em Cristo, no estender-se a sua graça a todos os efeitos dela, que são as
virtudes, os dons e coisas semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A fé e a esperança designam efeitos da graça com uma
certa deficiência, por parte de quem a recebe; isto é, enquanto que a fé tem por objeto o invisível e a
esperança, o que não é possuído. Por onde, não poderia em Cristo, autor da graça, haver essas
deficiências implicadas pela fé e pela esperança. Mas tudo o que tem de perfeição a fé e a esperança
existiu em Cristo de modo muito mais perfeito. Assim como também o fogo não encerra todas as
modalidades do calor, defeituosas por deficiência do sujeito, mas, tudo o que a perfeição do calor
implica.

RESPOSTA À SEGUNDA. — É próprio da graça operante por si mesmo tornar alguém justo; mas, o fazer
do impio um justo lhe é acidental, relativamente ao sujeito em estado de pecado. Por onde, a alma de
Cristo se justificou pela graça operante, por ler sido por ela justa e perfeita, desde o princípio da sua
conceição; não que, antes, tivesse sido pecadora ou mesmo não justa.

## Art. 10 — Se a plenitude da graça é própria de Cristo.
O décimo discute-se assim. — Parece que a plenitude da graça não é própria de Cristo.
1 — Pois, o próprio a alguém só a ele convém. Ora, o Evangelho atribui a certos outros a plenitude da
graça; assim diz da Santa Virgem: Ave, cheia de graça. E o Apóstolo: - Estevão, cheio de graça e fortaleza.
Logo, a plenitude da graça não é própria de Cristo.

2. Demais. — O que pode ser comunicado aos outros por Cristo não parece próprio de Cristo. Ora, a
plenitude da graça pode ser comunicada aos outros por Cristo; assim, diz o Apóstolo: Para que sejamos
cheios segundo toda plenitude de Deus. Logo, a plenitude da graça não é própria de Cristo.

3. Demais. — O estado da via se proporciona ao estado da pátria. Ora, no estado da pátria haverá uma
certa plenitude; pois, na pátria celeste, onde há a plenitude de todos os bens, embora determinados
dons sejam aí concedidos a certos de modo mais excelente, ninguém possuirá nada como próprio, no
dizer de Gregório. Logo, cada homem tem, enquanto viandante a plenitude da graça. E portanto, a
plenitude da graça não é própria de Cristo.
Mas, em contrário, a plenitude da graça é atribuída a Cristo, pelo Evangelho, enquanto o Unigênito do
Pai: Vimos a sua glória, como do Filho Unigênito do Paz: cheio de graça e de verdade. Ora, ser Unigênito
do Pai é próprio de Cristo. Logo, também lhe é a plenitude da graça da verdade.

SOLUÇÃO. — A plenitude da graça pode ser considerada a dupla luz. Em relação à própria graça e a
quem além. — Em relação à própria graça, dizemos que há a plenitude dela quando alguém lhe chega
ao sumo grau quanto à sua essência e à sua virtude; isto é, quando tem a graça na máxima excelência
em que pode ser tida e na máxima extensão quanto a todos os seus efeitos. E tal plenitude da graça é
própria, de Cristo. Quanto ao sujeito, dizemos que há plenitude da graça, quando ele a tem plena,
segundo a sua condição. Quer quanto à intensidade, quando há nele a graça intensa até o limite que lhe
Deus prefixou, segundo a expressão do Apóstolo: A cada um de nós foi dada a graça segundo a medida
do dom de Cristo. Quer também segundo a virtude, isto é, quando tem a faculdade da graça para tudo o
que lhe concerne ao dever ou ao estado, conforme aquilo do Apóstolo: A mim, que sou o mínimo de
todos os santos, me foi dada esta graça de manifestar a todos. E tal plenitude da graça não é própria a
Cristo, mas é por Cristo comunicada aos outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Santa Virgem é chamada cheia de graça, não
relativamente à graça em si mesma pela não ter tido na suma excelência possível, nem em relação a
todos os efeitos da graça. Mas é chamada cheia de graça relativamente a si própria; isto é, por ter tido a
graça suficiente ao estado para o qual foi escolhida por Deus, que era o de ser mãe de Deus. — E
semelhantemente, Estevão foi chamado cheio de graça, pela ter suficiente para ser idôneo ministro e
testemunha de Deus, para o que foi escolhido. — E pela mesma razão devemos assim pensar dos
demais. Dessas plenitude porém uma é mais plena que outra, enquanto é um preordenado por Deus
para um mais elevado estado.

RESPOSTA À SEGUNDA. — O Apóstolo, no lugar aduzido, se refere àquela plenitude de graça recebida
pelo sujeito, relativamente ao que o homem foi divinamente preordenado. E isso é ou algo de comum,
para o que todos os santos são preordenados; ou algo de especial, pertinente à excelência de certos. E,
assim sendo, há uma certa plenitude de graça comum a todos os santos; isto é, o terem a graça
suficiente para merecerem a vida eterna, consistente na plena fruição de Deus. E essa plenitude o
Apóstolo a deseja aos fiéis a quem escreve.

RESPOSTA À TERCEIRA. — Esses dons comuns na pátria, a saber, a visão, a compreensão e a fruição e
outros semelhantes, tem certos dons que lhes correspondem, enquanto dura esta vida, e que são
também comuns aos santos. Contudo, os santos tem certas prerrogativas, tanto na pátria como na via,
que os outros não tem.

## Art. 11 — Se a graça de Cristo era infinita.
O undécimo discute-se assim. — Parece que a graça de Cristo é infinita.

1. — Pois, todo o imenso é infinito. Ora, a graça de Cristo é imensa, como o diz o Evangelho: Não lhe dá
Deus o Espírito por medida. Logo, a graça de Cristo é infinita.

2. Demais. — Um efeito infinito demonstra uma virtude infinita, que só pode fundar-se numa essência
infinita. Ora, o efeito da graça de Cristo é infinito, pois, abrange a salvação de todo o gênero humano;
pois, é a propiciação pelos pecados de todo o mundo como diz o Evangelho. Logo, a graça de Cristo é
infinita.

3. Demais. — Todo finito pode, por adição, atingir a quantidade de qualquer coisa finita. Se, pois, a graça
de Cristo fosse finita, a graça de um outro homem poderia crescer a ponto de igualar a graça de Cristo.
Contra o que vai a Escritura: Não se lhe igualará o ouro nem o cristal, segundo a exposição de Gregório.
Logo, a graça de Cristo é infinita.
Mas, em contrário, a graça é algo de criado na alma. Ora, todo criado é finito, segundo a Escritura: Todas
as causas dispuseste com medida e conta e peso. Logo, a graça de Cristo não é infinita.

SOLUÇÃO. — Como do sobredito se colhe, podemos considerar em Cristo uma dupla graça. — Uma, a
de união, consistente, como dissemos, no fato mesmo de estar unido pessoalmente ao Filho de Deus; e
isso foi gratuitamente concedido à natureza humana. E essa graça é infinita, por ser infinita a Pessoa
mesma do Verbo.
Outra, porém, é a graça habitual que também é suceptível de dupla consideração. — Primeiro, como um
determinado ser. E então há de necessariamente ser um ente finito. Pois, está na alma de Cristo como
no seu sujeito. Pois, a alma de Cristo é uma determinada criatura, tendo capacidade finita. Por onde, o
ser da graça, não excedendo a capacidade do seu sujeito, não pode ser infinito. — De outro modo, pode
ser considerada quanto à essência própria da graça. E então, a graça de Cristo pode ser dita infinita, por
não ser limitada; isto é, por ter tudo o que constitui a essência da graça, e não lhe ter sido dada segundo
nenhuma medida certa o que pertence à essência da graça, pela razão que, segundo o desígnio da graça
de Deus, a quem compete medi-la, a graça é conferida à alma de Cristo como a um princípio universal
da gratificação na natureza humana, segundo àquilo do Apóstolo: Ele, nos fez agradáveis a si no seu
amado Filho. Como se disséssemos infinita a luz do sol, não por essência, mas, em razão da luz, pois,
tem tudo o que pode constituir a essência da luz.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dito — O Pai não dá ao Filho o Espírito por medida —
num sentido é exposto como referente ao dom que Deus Padre abeterno conferiu ao Filho isto é, a
natureza divina, que é um dom infinito. Por isso, uma certa Glosa diz a esse lugar: De modo que tão
grande seja o Filho como o Pai. — Noutro sentido, pode referir-se ao dom conferido à natureza humana,
de se unir à Pessoa divina, o que também é um dom infinito. Donde o dizer a Glosa, no mesmo lugar:
Assim como o Pai engedrou o Verbo completo e perfeito assim, completo e perfeito ele se uniu à
natureza humana. — Em terceiro sentido, pode referir-se à graça habitual, enquanto que a graça de
Cristo abrange tudo o que respeita à graça. Por isso Agostinho, expondo essa matéria, diz: A medida é
uma certa divisão dos dons, pois, a um é dado pelo Espírito a linguagem da sabedoria, a outro a da
ciência. Mas Cristo, que dá, não recebeu com medida.

RESPOSTA À SEGUNDA. — A graça de Cristo tem um efeito infinito, quer por causa da infinidade predita
da graça; quer por causa d unidade da Pessoa divina, a que estava unida a alma de Cristo.

RESPOSTA À TERCEIRA. — O menor pode aumentando, igualar a quantidade do maior, quando se trata
de coisas cuja quantidade é da mesma natureza. Ora, a graça de um homem está para a de Cristo como
uma virtude particular para a universal. Por onde, assim como a virtude do fogo, por mais que cresça,
não pode igualar à, do sol, assim também, a graça de um homem, por mais que cresça, não pode igualar
a graça de Cristo.

## Art. 12 — Se a graça de Cristo podia aumentar.
O duodécimo discute-se assim. — Parece que a graça de Cristo podia aumentar.
1 — Pois, toda quantidade finita é susceptível de adição. Ora, a graça de Cristo era finita, como se disse.
Logo, podia aumentar.

2. Demais. — O aumento da graça se faz por virtude divina, segundo o Apóstolo: Poderoso é Deus para
fazer abundar em vós toda a graça. Ora, a virtude divina, sendo infinita, não se encerra em nenhuns
limites. Logo, parece que a graça de Cristo podia ser maior.

3. Demais. — O Evangelho diz: Jesus crescia em sabedoria e em idade e em graça diante de Deus e dos
homens. Logo, a graça de Cristo podia aumentar.
Mas, em contrário, o Evangelho: E nós o vimos, como de Filho unigênito do Pai, cheio de graça e de
verdade. Ora, não podemos conceber nada maior do que ser alguém o Unigênito do Pai. Logo, não pode
existir nem ser concebida nenhuma graça maior do que aquela da qual Cristo teve a plenitude.

SOLUÇÃO. — De dois modos pode dar-se que uma forma não possa aumentar; quanto ao sujeito e
quanto à forma em si mesma. Quanto ao sujeito, no caso em que este atinge o último grau no
participar, ao seu modo, dessa forma. Assim, se dissermos que o ar não pode aumentar em quentura,
quando chega ao último grau de calor de que ele, por natureza, é susceptível, embora possa haver
maior calor na natureza das coisas, que é o do fogo. Quanto à forma, exclui-se a possibilidade do
aumento, quando um sujeito atinge a última perfeição de que tal forma é susceptível. Assim , se
dissermos que o calor do fogo não pode aumentar, por não poder haver um grau mais perfeito de calor
que o atingido pelo fogo. — Ora, assim como foi determinada pela sabedoria divina ri medida própria
das outras formas, assim também a da graça, segundo a Escritura: Todas as coisas dispuseste com
medida e conta e peso, Ora, a medida de cada forma é predeterminada por comparação com o seu fim;
assim como não há maior gravidade que a da terra, por não poder existir um lugar inferior ao da terra.
Mas, o fim da graça é a união da criatura racional com Deus. Não pode, porém, existir nem ser
concebida uma união maior da criatura racional com Deus, do que a existente na pessoa. Por onde, a
graça de Cristo atingiu a medida suma da graça. E, portanto, é manifesto que a graça de Cristo não pode
crescer, no atinente à graça em si mesma. — Mas nem tão pouco relativamente ao sujeito; porque
Cristo, enquanto homem, desde o primeiro instante da sua concepção, tinha verdadeira e plenamente a
visão clara. Portanto, não podia nele haver aumento da graça; assim como nem nos demais santos, cuja
graça não pode aumentar, porque já chegaram ao termo Nos homens, porém, que ainda vivem neste
mundo, a graça pode aumentar, quanto à forma, pois, não atingem o sumo grau da graça; e quanto ao
sujeito porque ainda não chegaram ao termo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Se nos referimos às quantidades matemáticas, a
qualquer quantidade finita pode fazer-se adição; pois, da parte da quantidade finita nada há de
repugnante à adição. Mas se nos referimos à quantidade natural, então pode haver repugnância por
parte da forma, que deve ter uma quantidade determinada, assim como os outros acidentes
determinados. Donde o dizer o Filósofo: Têm o seu termo e sua razão a grandeza e o acréscimo de tudo
o que existe em uma natureza qualquer. E por isso não se pode fazer adição à quantidade total do céu. E
com muito maior razão consideramos, nas formas em si mesmas, um termo, que elas não ultrapassam.
Por onde, não é necessário que a graça de Cristo seja susceptível de adição, embora seja finita por
essência.

RESPOSTA À SEGUNDA. — A virtude divina, embora possa fazer algo de maior e de melhor que a graça
habitual de Cristo, não pode contudo fazê-la ordenar-se a algo de maior do que a união pessoal com o
Filho Unigênito do Pai, a cuja união suficientemente corresponde tal medida da graça, segundo a
determinação da divina sabedoria.

RESPOSTA À TERCEIRA. — De dois modos pode alguém progredir na sabedoria e na graça. — Primeiro,
quanto aos hábitos mesmos da sabedoria e da graça, aumentados. E, nesse sentido, Cristo não
progrediu nelas. — De outro modo, quanto aos efeitos, isto é, no sentido em que alguém pratica obras
mais sábias e mais virtuosas. E então, Cristo progredia em sabedoria e em graça, como em idade;
porque, a medida que crescia em idade, fazia obras mais perfeitas, para mostrar que era
verdadeiramente homem, tanto no que respeita a Deus como no que respeita aos homens.

## Art. 13 — Se a graça habitual em Cristo era uma consequência da união.
O décimo terceiro discute-se assim. — Parece que a graça habitual em Cristo não era uma
consequência da união.

1. — Pois, uma coisa não pode ser a consequência de si mesma. Ora, essa graça habitual parece ser a
mesma que a da união. Pois, diz Agostinho: Pela mesma graça pela qual, desde que recebeu a fé, o
homem se torna Cristão, por essa mesma aquele homem desde o princípio foi Cristo. E dessas coisas, a
primeira pertence à graça habitual; a segunda, à da união. Logo, parece que a graça habitual não resulta
da união.

2. Demais. — A disposição precede a perfeição temporalmente, ou pelo menos, intelectualmente. Ora,
parece que a graça habitual é uma como disposição da natureza humana para a união pessoal. Logo,
parece que longe de a graça habitual resultar da união, ela a precede.

3. Demais. — O comum é anterior ao próprio. Ora, a graça habitual é comum a Cristo e à todos os
homens; ao contrário, a graça da união é própria de Cristo. Logo, segundo o intelecto, a graça habitual é
anterior à união. E portanto, dela não resulta.
Mas, em contrario, a Escritura: Eis aqui o meu servo, eu o ampararei. E a seguir acrescenta: Sobre ele
derramei o meu espírito — o que pertence ao dom da graça habitual. Donde resulta, que a assunção da
natureza humana em a unidade de pessoa precede a graça habitual em Cristo.

SOLUÇÃO. — A união da natureza humana com a pessoa divina, da qual dissemos acima ser a graça
mesma da união, precede a graça habitual, em Cristo, não na ordem do tempo, mas na da natureza e do
intelecto. E isto por três razões.
Primeiro, quanto à ordem dos princípios de ambas. Assim, o princípio da união é a Pessoa do Filho,
assumente da natureza humana; por isso se diz que foi enviada ao mundo, por ter assumido a natureza
humana. Quanto ao princípio da graça habitual, dada com a caridade, ela é o Espírito Santo, do qual se
diz que é enviado por habitar na alma pela caridade. Ora, a missão do Filho, na ordem da natureza, é
anterior à do Espírito Santo; assim como, na ordem da natureza, o Espírito Santo procede do Filho e, da
sabedoria, o amor. Por onde, também a união pessoal pela qual concebemos a missão do Filho, é
anterior, na ordem da natureza, à graça habitual, pela qual se concebe a missão do Espírito Santo.
Em segundo lugar, a razão dessa ordem se seduz da relação da graça com a sua causa. Pois, a graça é
causada no homem pela presença da divindade, assim como a luz, no ar, pela presença do sol. Donde o
dizer a Escritura: Entrava a glória do Deus de Israel pela banda do oriente e a terra estava
resplandecente pela presença da sua majestade. Ora, a presença de Deus em Cristo é concebida
segundo a união da natureza humana com a Pessoa divina. Por onde, a graça habitual de Cristo é
entendida como consequente a essa união, como o esplendor, ao sol.
A terceira razão dessa ordem pode ser deduzida do dom da graça, a qual se ordena a fazer proceder
bem. Ora, os atos são dos supostos e dos indivíduos. Por onde, a ação, e por consequência, a graça, que
para ela ordena, pressupõe a natureza humana antes da união, como do sobredito resulta. Logo, a graça
da união, segundo o intelecto, precede à graça habitual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho, no lugar citado, chama graça gratuita à
vontade de. Deus, que confere benefícios gratuitamente. E por isso, diz que por essa mesma graça pela
qual foi feito o homem Cristo, todos os homens se tornam Cristãos. Porque ambas essas coisas se
realizam pela vontade gratuita de Deus, sem dependência de méritos.

RESPOSTA À SEGUNDA. — Assim como a disposição, na ordem da geração, precede à perfeição
dispositivamente; assim ela também é consequente naturalmente. à perfeição que já foi atingida. Tal o
calor que, tendo sido uma disposição à forma do fogo, é um efeito profluente da forma do fogo já
preexistente. Ora, a natureza humana em Cristo esteve unida à Pessoa do Verbo, desde o princípio, sem
sucessão. Por onde, a graça habitual não se entende como precedente à união, mas como consequente
a ela, como uma propriedade natural. Donde o dizer Agostinho: A graça é de certo modo natural ao
homem Cristo.

RESPOSTA À TERCEIRA. — O comum é anterior ao próprio, quando ambos são do mesmo gênero; mas,
quando de gênero diversos, nada impede seja o próprio anterior ao comum. Ora, a graça da união não
pertence ao mesmo gênero que a graça habitual, mas é superior a todos os gêneros como o é a Pessoa
divina. Por onde, nada impede seja esse próprio, anterior ao comum, pois não se relaciona com este por
adição, mas é, antes, o princípio e a origem do que é comum.