# Questão 69: Dos efeitos do batismo
Em seguida devemos tratar dos efeitos do batismo.
E nesta questão discutem-se dez artigos:

## Art. 1 — Se o batismo dele todos os pecados.
O primeiro discute-se assim. — Parece que o batismo não dele todos os pecados.

1. — Pois, o batismo é um renascimento espiritual, correspondente à geração carnal. Ora, pela geração
carnal só contraímos o pecado original. Logo, o batismo nos livra só do pecado original.

2. Demais. — A penitência é a causa suficiente da remissão dos pecados atuais. Ora, antes de receberem
o batismo, os adultos devem fazer penitência, segundo aquilo da Escritura: Fazei penitência e cada um
de vós seja batizado. Logo, o batismo não tem nenhum efeito, quanto à remissão dos pecados atuais.

3. Demais. — Para doenças diversas, remédios diversos; pois, como diz Jerônimo, não cura os olhos o
que cura o calcanhar. Ora, o pecado original, delido pelo batismo, é genericamente diferente do pecado
atual. Logo, o batismo não remite todos os pecados.
Mas, em contrário, a Escritura: Derramarei sobre vós uma água pura e sereis purificados de todas as
vossas imundícias.

SOLUÇÃO. — Diz o Apóstolo: Todos os que fomos batizados em Jesus Cristo fomos batizados em sua
morte. E depois conclui: Assim também vós considerai-vos que estais certamente mortos ao pecado,
porém vivos para Deus em Nosso Senhor Jesus Cristo. Por onde é claro que, pelo batismo, morremos à
vetustez do pecado e começamos a viver em a novidade da graça. Ora, todo pecado se prende a
vetustez primitiva. Logo e consequentemente, todo pecado é delido pelo batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz o Apóstolo, o pecado de Adão não pode tanto
quanto o dom de Cristo, que recebemos no batismo: Porque o juízo se originou de um pecado para
condenação, mas a graça procedeu de muitos delitos para justificação. Donde o dizer Agostinho: Com a
geração da carne contraímos somente o pecado original; mas a regeneração pelo Espírito produz a
remissão, não só do pecado original, mas também dos voluntários.

RESPOSTA À SEGUNDA. — A remissão de nenhum pecado pode dar-se, senão por virtude da paixão de
Cristo; por isso diz o Apóstolo, que sem efusão de sangue não há remissão. Por onde, o movimento da
vontade arrependida não bastaria para a remissão da culpa sem a fé na paixão de Cristo e o propósito
de participar dela, quer pelo recebimento do batismo, quer pela sujeição aos chefes da Igreja. Portanto,
quando um adulto penitente se achega ao batismo, recebe a remissão de todos os pecados, pelo desejo
desse sacramento; mais perfeitamente porém quando realmente o recebe.

RESPOSTA À TERCEIRA. — A objeção colhe quanto aos remédios particulares. Ora, o batismo obra em
virtude da paixão de Cristo remédio universal de todos os pecados; portanto, o batismo dele todos os
pecados.

## Art. 2 — Se o batismo nos libera totalmente do reato do pecado.
O segundo discute-se assim. — Parece que o batismo não nos libera totalmente do reato do pecado.

1. — Pois, diz o Apóstolo: As coisas de Deus são ordenadas. Ora, é a culpa que faz entrar na ordem a
pena, como diz Agostinho. Logo, o batismo não exclui o reato da pena dos pecados precedentes.

2. Demais. — O efeito do sacramento tem alguma semelhança com o próprio sacramento; pois, os
sacramentos da lei nova realizam realmente o que figuram como se disse. Ora, a ablução batismal, tem
por certo alguma semelhança com a ablução da mácula, mas nenhuma tem com a liberação do reato da
pena. Logo, o batismo não dele o reato da pena.

3. Demais. — Excluído o reato da pena, já ninguém continua digno dela, e portanto a punição é injusta.
Se, pois, o batismo tira o reato da pena, seria injusto depois do batismo enforcar um ladrão que antes
praticou um homicídio. E assim o batismo faria desaparecer o rigor da disciplina humana, o que é
inconveniente. Logo, a batismo não tira o reato da pena.
Mas, em contrário, àquilo do Apóstolo - Os dons e a vocação de Deus são imutáveis - diz Ambrósio: A
graça de Deus no batismo, tudo perdoa gratuitamente.

SOLUÇÃO. — Como dissemos pelo batismo nos incorporamos à paixão e à morte de Cristo, segundo
aquilo do Apóstolo: Se somos mortos com Cristo cremos que juntamente viveremos também com
Cristo. Por onde é claro que a todo batizado é comunicada a paixão de Cristo como remédio, como se
esse próprio batizado a tivesse sofrido e tivesses satisfação suficiente por todos os pecados de todos os
homens. Logo, o batizado fica livre totalmente do reato da pena que deveria sofrer, por causa do
pecado, como se tivesse suficientemente satisfeito por todos os seus pecados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A pena da paixão de Cristo se comunica ao batizado,
enquanto se torna membro de Cristo, como se ele próprio tivesse sofrido essa pena; por isso pela pena
da paixão de Cristo os pecados do batizado reentram na ordem.

RESPOSTA À SEGUNDA. — A água não somente lava, mas também refresca. E assim, o seu refrigério
significa o reato da pena, como a sua ablução significa a purificação da culpa.

RESPOSTA À TERCEIRA. — As penas impostas pelo juízo humano não só levam em conta a pena
merecida por um homem, relativamente a Deus, mas ainda em que fica obrigado para com os outros
homens, lesados e escandalizados pelo seu pecado. Por isso embora o homicida seja liberado pelo
batismo do reato da pena devida a Deus, fica ainda contudo obrigado a ela perante os homens, que é
justo se edifiquem pela pena assim como foram escandalizados pela culpa. Contudo e por um
sentimento de piedade, o príncipe poderá exercer a sua clemência para com esses tais.

## Art. 3 — Se o batismo deve livrar das penalidades da vida presente.
O terceiro discute-se assim. — Parece que o batismo deve livrar das penalidades da vida presente.

1. — Pois, como diz o Apóstolo, o dom de Cristo é mais forte que o pecado de Adão. Ora, pelo pecado
de Adão, como diz ainda ele no mesmo lugar, a morte entrou neste mundo e por consequência todas as
outras penalidades da vida presente. Logo e com muito maior razão, pelo dom de Cristo, recebido no
batismo, devíamos ser liberados de todas as penalidades da vida presente.

2. Demais. — O batismo dele a culpa original e a atual como se disse. Ora, dele a culpa atual liberando-
nos totalmente do reato da pena a ela consequente. Logo, também nos libera das penalidades da vida
presente, que são a pena do pecado original.

3. Demais. — Removida a causa, removido fica o efeito. Ora, a causa das referidas penalidades é o
pecado original, delido pelo batismo. Logo, não devem tais penalidades permanecer.
Mas, em contrário, aquilo do Apóstolo – Seja destruído o corpo do pecado - diz a Glosa: O batismo
produz o efeito de crucificar o homem velho e destruir o corpo do pecado; não de maneira que a
concupiscência enraizada na carne viva, com a qual nasceu, fique logo consumida e desapareça; mas de
modo, que presente em nós ao nascermos, já não nos possa fazer mal quando morremos. Logo, pela
mesma razão, o batismo tira as outras penalidades.

SOLUÇÃO. — O batismo tem a virtude de nos livrar das penalidades da vida presente. Não as tira porém
já nesta vida, mas, pela sua virtude são tiradas ao justo, na ressurreição, quando este corpo mortal se
revestir da imortalidade, na frase do Apóstolo. E isto racionalmente. - Primeiro, porque o batismo nos
incorpora com Cristo, tornando-nos membro dele, como dissemos. Por isso deve dar-se com o membro
incorporado os que deu com o chefe. Ora, Cristo desde o momento da sua concepção teve a plenitude
da graça e da verdade; mas teve um corpo passível, ressuscitado depois da paixão e da morte à vida
gloriosa. Por isto também o cristão no batismo alcança a graça para a alma, mas tem um corpo passível
no qual pode sofrer por Cristo. Ressuscitará porem para uma vida impassível. Por isso diz o Apóstolo:
Aquele que ressuscitou dos mortos a Jesus Cristo também dará vida aos vossos corpos mortais pelo seu
Espírito, que habita em vós. E mais abaixo: Herdeiros verdadeiramente de Deus e coerdeiros de Cristo,
se é que, todavia nós padecemos com ele para que sejamos também com ele glorificados. - Segundo,
em benefício do exercício espiritual; isto é, a fim de, lutando contra a concupiscência e as outras paixões
recebermos; a coroa da glória. Por isso, àquilo do Apóstolo: - Para que seja destruído o corpo do
pecado, - diz a Glosa: Se, uma vez batizado, o homem continua a viver na carne, terá que combater a
concupiscência e a vencerá com o auxílio de Deus. Luta que está simbolizada na Escritura: Estas são as
gentes que o Senhor deixou para instruir por meio delas a Israel, para que depois aprendessem seus
filhos a combater contra seus inimigos e se avezassem a pelejar. - Terceiro, a fim de que ninguém se
apresentasse ao batismo levado do desejo de fugir aos sofrimentos desta vida, em lugar de ter em mira
a glória da vida eterna. Donde o dizer o Apóstolo: Se nesta vida tão somente esperemos em Cristo,
somos nós os mais infelizes de todos os homens.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Aquilo do Apóstolo - Não sirvamos, jamais ao pecado -
diz a Glosa: Assim como quem se apodera de um inimigo atrocíssimo não o mata logo, mas o deixa viver
algum tempo na vergonha e na dor, assim Cristo começou limitando primeiro a pena, para fazê-la
desaparecer de todo no futuro.

RESPOSTA À SEGUNDA. — Como diz a Glosa no mesmo lugar, dupla é a pena do pecado - a da geena e a
temporal. A da geena Cristo aboliu completamente, de modo que os batizados e os verdadeiramente
penitentes não a sintam. Quanto à temporal, não a aboliu ainda de todo, pois, aí estão a sede, a fome e
a morte. Mas, tirou-lhe o domínio e o reinado, fazendo o homem não na temer; e por fim, no último dia,
a exterminara de todo.

RESPOSTA À TERCEIRA. — Como dissemos na Segunda Parte, o pecado original produz um contágio tal,
que foi primeiro a pessoa a contaminar a natureza, e depois a natureza, a pessoa. Mas Cristo, na ordem
inversa, restaura em primeiro lugar a pessoa para depois restaurar em todos ao mesmo tempo a
natureza. Por isso, o batismo faz-nos desaparecer imediatamente a culpa do pecado original e também
a pena da privação da visão de Deus, concernentes à pessoa. As penalidades da vida presente, porém,
como a morte, a fome, a sede e outras semelhantes respeitam a natureza, de cujos princípios são
causadas por ter ela decaído da justiça original. Por isso essas deficiências só desaparecerão na
restauração derradeira da natureza, pela ressurreição gloriosa.

## Art. 4 — Se o batismo confere ao homem a graça e as virtudes.
O quarto discute-se assim, — Parece que o batismo não confere ao homem a graça e as virtudes.

1. — Pois, como se disse, os sacramentos da lei nova realizam o que figuram. Ora, a ablução do batismo
significa a purificação da alma, da culpa; mas a informação da alma pela graça e pelas virtudes. Logo,
parece que o batismo não confere ao homem a graça e as virtudes.

2. Demais. — O que já alcançamos não precisamos receber de novo. Ora, certos se apresentam ao
batismo, tendo já a graça e as virtudes. Assim, lemos na Escritura: Havia em Cesaréia um homem, por
nome Cornélio, que era centurião da corte que se chama Italiana, cheio de religião e temente a Deus. E
contudo foi depois batizado por Pedro. Logo, o batismo não confere a graça e as virtudes.

3. Demais. — A virtude é um hábito; e este é por natureza uma qualidade que dificilmente perdemos e
que nos faz agir fácil e deleitávelmente. Ora, depois do batismo permanece em nós a inclinação para o
mal, inimigo da virtude e temos dificuldade de praticar o bem que é o ato virtuoso. Logo, o batismo não
nos confere a graça nem as virtudes.
Mas, em contrário, o Apóstolo: Salvou-nos pelo batismo de regeneração, isto é, pelo batismo e
renovação do Espírito Santo, o qual ele difundiu sobre nós abundantemente, isto é, para a remissão dos
pecados e a abundância das virtudes, como o expõe a Glosa a esse lugar. Assim, pois, o batismo confere
a graça do Espírito Santo e a abundância das virtudes.

SOLUÇÃO. — Como diz Agostinho, o efeito do batismo está em incorporar os batizados com Cristo,
tornando-os membros seus. Ora, de Cristo, que é a cabeça, deriva para todos os seus membros a
plenitude da graça e da virtude segundo aquilo do Evangelho: Todos nós participamos da sua plenitude.
Por onde, é manifesto que pelo batismo alcançamos a graça e as virtudes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como a água do batismo significa pela sua ablução
a purificação da culpa, e pelo seu refrigério, a liberação da pena, assim, pela sua natural cladade, o
esplendor da graça e das virtudes.

RESPOSTA À SEGUNDA. — Como dissemos, a remissão dos pecados pode alcançá-la antes do batismo
quem o deseja explícita ou implicitamente. E contudo quando realmente o recebe, faz-se-lhe mais plena
a remissão, ficando totalmente livre da pena. Assim também, antes do batismo, Cornélio e todos os da
mesma condição alcançam a graça e as virtudes pela fé de Cristo e o desejo do batismo, implícita ou
explicitamente; mas depois, no batismo, alcançam maior cópia de graça e de virtudes. Por isso, àquilo
da Escritura - Ele me conduziu junto a uma água de rejeição - diz a Glosa: Pelo aumento da virtude e de
obras santas nos fortificou no batismo.

RESPOSTA À TERCEIRA. — A dificuldade para o bem e a inclinação para o mal os batizados as sentem
não por deficiência do hábito das virtudes, mas pela concupiscência, não eliminada pelo batismo. Assim,
pois, como o batismo diminui a concupiscência, de modo que não possa ela dominar, assim também
diminui a inclinação para o mal e a concupiscência, para não nos vencerem.

## Art. 5 — Se se consideram convenientemente efeitos do batismo certos a dos de virtudes: a incorporação com Cristo, a iluminação e a fecundidade espiritual.
O quinto discute-se assim. — Parece que inconvenientemente se consideram efeitos do batismo
certos atos de virtudes: a incorporação com Cristo, a iluminação e a fecundidade espiritual.

1. — Pois, o batismo só é conferido ao adulto, quando tem fé, segundo aquilo do Evangelho: O que crer
e for batizado será salvo. Ora, pela fé nos incorporamos com Cristo, segundo o Apóstolo: Para que Cristo
habite pela fé em vossos corações. Logo, ninguém é batizado, que já não esteja incorporado com Cristo.
Portanto, não é efeito do batismo incorporar com Cristo.

2. Demais. — A iluminação se dá pela doutrina segundo o Apóstolo: A mim que sou o mínimo de todos
os santos me foi dada esta graça de anunciar a todos, etc. Ora, o ensino catequético precede ao
batismo. Logo, não é efeito dele.

3. Demais. — A fecundidade é efeito da geração ativa. Ora, o batismo nos regenera espiritualmente.
Logo, a fecundidade espiritual não é efeito do batismo.
Mas, em contrário, diz Agostinho, que é efeito do batismo incorporar os batizados com Cristo. E Dionísio
também atribui a iluminação ao batismo. E àquilo da Escritura - A uma água da rejeição - diz a Glosa: A
alma dos pecadores, estéril pela aridez, é fecundada pelo batismo.

SOLUÇÃO. — O batismo nos faz renascer para a vida espiritual, própria dos fiéis de Cristo, como o diz o
Apóstolo: Se eu vivo agora em carne, vivo na Fé do Filho de Deus. Ora, só vivem os membros unidos à
cabeça, donde recebem a sensibilidade e o movimento. Por onde e necessàriamente, o batismo nos
incorpora com Cristo quase membros dele. - Assim como da cabeça, no sentido natural, deriva para os
membros a sensibilidade e o movimento, assim da cabeça espiritual, que é Cristo, deriva para os seus
membros o senso do espiritual, consistente no conhecimento da verdade, e o movimento espiritual, por
inspiração da graça. Donde o dizer o Evangelho: Nós o vimos cheio de graça e de verdade e todos nós
participamos da sua plenitude. Por onde e conseqüentemente, hão de os batizados ser iluminados por
Cristo no concernente ao conhecimento da verdade, e por ele fecundados para a fecundidade das boas
obras, pela infusão da graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pela fé que lhes precede o batismo, os adultos são
incorporados com Cristo mentalmente. Mas depois, quando batizados, de certo modo são incorporados
com ele corporalmente, isto é, pelo sacramento visível, sem o desejo do qual nem mesmo a
incorporação espiritual lhes seria possível.

RESPOSTA À SEGUNDA. — Quem ensina ilumina externamente pelo ministério catequético; mas Deus
ilumina interiormente os batizados, preparando-lhes o coração para receber a doutrina da verdade,
segundo aquilo do Evangelho: Escrito está nos Projetas - Serão todos ensinados de Deus.

RESPOSTA À TERCEIRA. — Considera-se efeito do batismo a fecundidade pela qual praticamos as boas
obras; mas não a pela qual geramos outros para Cristo, como o diz o Apóstolo: Eu vos gerei em Jesus
Cristo pelo Evangelho.

## Art. 6 — Se às crianças o batismo confere a graça e as virtudes.
O sexto discute-se assim. — Parece que às crianças o batismo não confere a graça e as virtudes.

1. — Pois, graça e virtudes não se podem ter sem fé e caridade. Ora, a fé, como diz Agostinho, está na
vontade do crente. Semelhantemente, a caridade supõe a vontade de amar. Ora, as crianças não tendo
o uso da vontade, não têm fé nem caridade. Logo, as crianças com o batismo não recebem nem a graça
nem as virtudes.

2. Demais. — Aquilo do Evangelho - Fará obras ainda maiores - diz Agostinho: Para fazer de um ímpio
um justo, Cristo obra nele, mas não sem ele. Ora, a criança, não tendo o uso do livre arbítrio, não
coopera com Cristo para a sua justificação, e até, às vezes se lhe opõe o quanto pode. Logo, não é
justificada pela graça e pelas virtudes.

3. Demais. — O Apóstolo diz: Ao que não obra e crê naquele que justifica o ímpio, a sua fé lhe é
imputada a justiça, segundo o decreto da graça de Deus. Ora, a criança não crê naquele que justifica o
ímpio. Logo, não recebe a graça justificante nem as virtudes.

4. Demais. — O que fazemos com intenção carnal não tem efeito espiritual. Ora, às vezes as crianças são
levadas ao batismo com a intenção carnal de recuperarem a saúde do corpo. Logo não recebem o efeito
espiritual da graça e das virtudes.
Mas, em contrário, diz Agostinho: As crianças, renascendo pelo batismo, morrem ao pecado que
contraíram ao nascer. De tal sorte que se lhes aplica o dito do Apóstolo: Fomos sepultados com ele para
morrer pelo batismo. E acrescenta: Para que como Cristo ressurgiu dos mortos pela glória do Padre,
assim também nós andemos em novidade de vida. Ora, a novidade de vida resulta da graça e das
virtudes. Logo, às crianças o batismo confere a graça e as virtudes.

SOLUÇÃO. — Certos antigos ensinaram que o batismo não confere às crianças a graça nem as virtudes;
mas lhes imprime o caráter de Cristo, por cuja virtude, quando chegarem à idade de razão, receberão a
graça e as virtudes. Mas isto é falso por duas razões. - Primeiro, porque as crianças, como os adultos, se
tornam pelo batismo membros de Cristo por onde e necessàriamente, hão de receber da cabeça o
influxo da graça e da virtude. - Segundo, porque de acordo com tal opinião, as crianças mortas depois do
batismo não alcançariam a vida eterna, segundo o Apóstolo: A graça de Deus é a vida eterna. E assim de
nada lhes aproveitaria o terem sido batizadas. - Quanto à causa desse erro, foi não saberem distinguir
entre o habito e o ato. E assim, vendo as crianças incapazes de atos de virtude, pensavam que depois do
batismo de nenhum modo tinham a virtude. Ora, essa impotência de obrar não existe nas crianças por
defeito dos hábitos, mas por impedimento corporal; assim como os adormecidos, embora tenham o
hábito das virtudes, não lhes podem, contudo praticar os atos, por causa do sono.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A fé e a caridade residem na vontade humana, mas com
a diferença que os hábitos dessas virtudes e de todas as outras se fundam na potência da vontade,
existente nas crianças; ao passo que os atos das virtudes implicam o ato da vontade, e desse são elas
capazes. E em tal sentido Agostinho diz, no mesmo lugar: A criança, embora ainda não tenha a fé, que
supõe a vontade do crente, torna-a contudo fiel o sacramento mesmo da fé que causa o hábito dessa
virtude.

RESPOSTA À SEGUNDA. — Como diz Agostinho: Não renasce da água e do Espírito Santo senão quem
quer. E isso se deve entender, não das crianças, mas dos adultos. Do mesmo modo, dos adultos se deve
entender, que Cristo não nos justifica sem nós. - Quanto ao fato de as crianças, que vão ser batizadas,
relutarem o quanto as forças lhes permitem, não lhes é ele imputável; pois, não sabem o que fazem. a
ponto de não as considerarmos autores do ato praticado.

RESPOSTA À TERCEIRA. — Como diz Agostinho, aos pequeninos a Igreja empresta os pés dos outros
para virem, o coração dos outros para crerem, a língua dos outros para confessarem. E assim, as
crianças crêem não por ato próprio, mas pela fé da Igreja, que lhes é comunicada. E em virtude dessa fé
lhes é conferida a graça e as virtudes.

RESPOSTA À QUARTA. — A intenção carnal com que se levam as crianças ao batismo em nada as
prejudica; assim como também a culpa de um não prejudica a outro, que nela não consentiu. Donde o
dizer Agostinho: Não te deixes perturbar pelo facto de certos apresentarem as crianças ao batismo, não
na fé que a graça espiritual os fará nascer para a vida eterna, mas na idéia de ser o batismo um remédio
para conservarem ou adquirirem a saúde do corpo. Pois não lhes vai impedir a regeneração o jato de
não serem apresentados com a intenção de serem regenerados.

## Art. 7 — Se o batismo produz o efeito de se abrirem as portas do céu.
O sétimo discute-se assim. — Parece que o batismo não produz o efeito de se abrirem as portas do
céu.

1. — Pois, o que já está aberto não precisa de o ser. Ora, as portas do céu foram abertas pela paixão de
Cristo, conforme àquilo da Escritura: Depois disto olhei e vi uma porta aberta no céu. Logo, o batismo
não produz o efeito de abrir as portas do céu.

2. Demais. — O batismo, desde a sua instituição, produz em todos os tempos o seu efeito. Ora, certos
receberam o batismo de Cristo, antes da paixão de Cristo, como o refere o Evangelho. E a esses, se
então morressem, ainda não se lhes abriria a entrada do reino celeste, onde ninguém entrou antes de
Cristo, segundo aquilo da Escritura: Aquele que lhes há de abrir o caminho irá diante deles. Logo, o
batismo não produz o efeito de abrir as portas do céu.

3. Demais. — Os batizados estão ainda expostos à morte e às outras penalidades da vida presente, como
se disse. Ora, a ninguém foi franqueada a entrada do reino celeste, enquanto sujeito à pena, como o
demonstra o caso dos que estão no purgatório. Logo, o efeito do batismo não é a abertura das portas do
reino celeste.
Mas, em contrário, àquilo do Evangelho: Abriu-se o céu - diz a Glosa de Beda: Isto manifesta a virtude
que tem o batismo de abrir as portas do reino dos céus a quem o recebeu.

SOLUÇÃO. — Abrir as portas do reino celeste é remover o obstáculo que nos impede entrar nele. E esse
obstáculo é a culpa e o reato da pena. Ora, como já dissemos, o batismo dele toda culpa e todo reato da
pena. Por onde e consequentemente, o batismo produz o efeito de abrir as portas do reino celeste.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O batismo abre ao batizado as portas do reino celeste,
pelo incorporar com a paixão de Cristo, aplicando-lhe a virtude desta.

RESPOSTA À SEGUNDA. — Quando a paixão de Cristo ainda não estava consumada, só existindo na fé
dos crentes, o batismo produzia de acordo com ela a abertura das portas, não realmente, mas em
esperança. Pois então os batizados, morriam na certeza da esperança de haverem de entrar no reino
celeste.

RESPOSTA À TERCEIRA. — O batizado não está exposto à morte e às penalidades da vida presente por
causa do reato da pena, mas pela condição da natureza. Por isso não fica impedido de entrar no reino
celeste, quando a alma se separar do corpo pela morte, sendo por assim dizer pago o devido à natureza.

## Art. 8 — Se o batismo produz o mesmo efeito em todos.
O oitavo discute-se assim. — Parece que o batismo não produz o mesmo efeito em todos.

1. — Pois, o efeito do batismo é remover a culpa. Ora, dele mais pecados em uns que em outros; assim,
das crianças, o pecado original; e dos adultos também os pecados atuais, em uns mais, em outros
menos. Logo, o batismo não produz o mesmo efeito para todos.

2. Demais. — O batismo confere ao homem a graça e as virtudes. Ora, certos depois do batismo têm
maior graça e mais perfeita: virtude que os outros batizados. Logo, o batismo não tem o mesmo efeito
para todos.

3. Demais. — A natureza se aperfeiçoa pela graça como a matéria, pela forma. Ora, a forma é recebida
pela matéria segundo a capacidade desta. Logo, tendo certos batizados, ainda crianças, maior
capacidade natural que outros parece que uns alcançam maior graça que outros.

4. Demais. — Certos alcançam no batismo não só a saúde espiritual, mas também a do corpo; tal o caso
de Constantino, purificado da lepra pelo batismo. Ora, nem todos os doentes alcançam no batismo a
saúde do corpo. Logo, o batismo não produz o mesmo efeito para todos.
Mas, em contrário, o Apóstolo: Não há senão uma fé, senão um batismo. Ora, a mesma causa produz o
mesmo efeito. Logo, o batismo produz o mesmo efeito em todos.

SOLUÇÃO. — Dois efeitos produz o batismo: um essencial e outro acidental.
O efeito essencial do batismo é o para que ele foi instituído, isto é, para nos fazer renascer à vida
espiritual. Ora, sendo o batismo conferido igualmente a todas as crianças, batizadas não por terem fé
própria, mas na fé da Igreja, todas colhem o mesmo efeito do batismo. Mas os adultos, que se
apresentam a ele com fé própria, não lhe colhem igualmente os mesmos frutos. Pois, uns recebem o
batismo com maior devoção e outros, com menor. Por isso uns recebem as suas novas graças em maior
ou menor grau, assim como também do mesmo fogo recebe mais calor quem mais dele se aproxima,
embora o fogo, por natureza difunda igualmente para todo o seu calor.
Quanto ao efeito acidental do batismo, é aquele ao qual não é ordenado, mas o poder divino nele obra
milagrosamente. Assim, àquilo do Apóstolo - Não sirvamos jamais ao pecado; diz a Glosa: Só um milagre
inefável do Criador pode extinguir completamente nos nossos membros a lei do pecado. E tais efeitos
não o sentem igualmente todos os batizados, mesmo se receberem o batismo com igual devoção; mas
são eles dispensados conforme à ordem da providência divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A graça mínima do batismo é suficiente para delír todos
os pecados. Por onde, não é maior eficácia do batismo a absolver maior número de pecados em uns que
em outros. Mas isso depende da condição do sujeito, pois, em cada um dele todo o mal que nele
encontra.

RESPOSTA À SEGUNDA. — O fato de os batizados manifestarem maior ou menor graça pode se dar de
dois modos. Ou porque um no batismo recebe maior graça que outro por causa da maior devoção,
como se disse. Ou porque, mesmo recebendo graça igual, não usam igualmente dela, por aproveitá-la
um com maior estudo e ao outro, por causa da sua negligência, faltar a graça de Deus.

RESPOSTA À TERCEIRA. — A diversidade de capacidade entre os homens não provem da diversidade
das almas, renovadas pelo batismo, pois, sendo todos os homens da mesma espécie convêm na mesma
forma; mas da disposição diversa dos corpos. O contrário se dá com os anjos, que diferem
especificamente. Por isso aos anjos são conferidos dons gratuitos, segundo suas capacidades naturais
diversas; não porém aos homens.

RESPOSTA À QUARTA. — A saúde do corpo não é por si efeito do batismo, mas é uma obra milagrosa da
providência divina.

## Art. 9 — Se a ficção impede o efeito do batismo.
O nono discute-se assim. — Parece que a ficção não impede o efeito do batismo.

1. — Pois, diz o Apóstolo: Todos os que fostes batizados em Cristo revestistes-vos de Cristo. Ora, todos
os que recebem o batismo de Cristo são batizados em Cristo. Logo todos se revestem de Cristo. Ora, isso
é colher o efeito do batismo. Por tanto a ficção não impede o efeito do batismo.

2. Demais. — No batismo obra a graça divina, que pode mudar a vontade do homem para o bem. Ora, o
efeito da causa agente não pode ficar impedido pelo obstáculo mesmo que ela é capaz de eliminar.
Logo, a ficção não pode impedir o efeito do batismo.

3. Demais. — O efeito do batismo é a graça a que se opõe o pecado. Ora muitos pecados há mais graves
que a ficção, dos quais não se diz contudo que impidam o efeito do batismo. Logo também a ficção não
impede esse efeito.
Mas, em contrário, a Escritura: O Espírito Santo, mestre da disciplina, fugirá do fingido. Ora, o efeito do
batismo vem do Espírito Santo. Logo, a ficção impede o efeito do batismo.

SOLUÇÃO. — Como diz Damasceno, Deus não obriga o homem a ser justo. Por isso, para sermos
justificados pelo batismo, é necessário a nossa vontade querê-lo e ao seu efeito. Ora, fingido se chama
aquele cuja vontade contraria o batismo ou o seu efeito. Pois, segundo Agostinho, de quatro modos
podemos dizer que um é fingido.
Primeiro, se não crê, embora seja o batismo o sacramento da fé; segundo se despreza o próprio
sacramento; terceiro, se celebra o sacramento sem observar o rito da Igreja; e quarto, recebendo o
batismo indevotamente. Logo, é manifesto que a ficção impede o efeito do batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A expressão - ser batizado em Cristo - pode ser
entendida de dois modos. Num, em Cristo significa - em conformidade com Cristo. E assim, todos os
batiza dos em Cristo, conformados com ele pela fé e pela caridade, revestem-se de Cristo pela graça. -
Em outro, dizemos batizados em Cristo os que recebem o sacramento de Cristo. E assim todos se
revestem de Cristo pela configuração do caráter; mas não pela conformidade da graça.

RESPOSTA À SEGUNDA. — Se Deus muda a vontade do homem do mal para o bem, já ele não se
apresenta ao batismo em ficção. Ora, isso Deus nem sempre o faz. Nem o sacramento se ordena a
tornar o ficto não-ficto; mas a justificar quem se apresenta não-ficto ao batismo.

RESPOSTA À TERCEIRA. — Ficto se chama quem mostra querer o que não quer. Ora, quem se apresenta
ao batismo por isso mesmo mostra ter fé verdadeira em Cristo, venerar o sacramento, querer
conformar-se com a Igreja e abandonar o pecado. Por onde, quem se apresenta ao batismo, sem querer
abandonar o pecado, se apresenta fictamente, o que é recebê-lo sem devoção. Mas isto se deve
entender do pecado mortal, que contraria a graça; mas não do pecado venial. Por onde, neste sentido, a
ficção inclui de certo modo todos os pecados.

## Art. 10 — Se, desaparecida a ficção, o batismo produz o seu efeito.
O décimo discute-se assim. — Parece que, desaparecida a ficção, o batismo não produz o seu efeito.

1. — Pois, uma obra morta, por ser desprovida de caridade, nunca pode ser vivificada. Ora, quem recebe
o batismo, fictamente, sem caridade recebe o sacramento. Logo, este nunca pode ser vivificado de
modo a conferir a graça.

2. Demais. — A ficção, sendo um obstáculo para o batismo, é mais forte que ele. Ora, o mais forte não
pode ser vencido pelo mais fraco. Logo, o pecado da ficção não pode ser de lido pelo batismo, a que se
opõe obstáculo. Portanto, o batismo não produz o seu efeito, que é a remissão de todos os pecados.

3. Demais. — Pode acontecer que uma pessoa, depois de ter recebido o batismo, cometa muitos
pecados. E esses não serão delidos pelo batismo, que dele os pecados passados, mas não os futuros.
Logo, tal batismo nunca produz o seu efeito, que é a remissão de todos os pecados.
Mas, em contrário, diz Agostinho: O batismo começa a produzir a sua eficácia salutar quando uma
sincera confissão fizer desaparecer esse fingimento que, mantendo o coração na malícia ou no
sacrilégio, não deixava produzir-se a ablução dos pecados.

SOLUÇÃO. — Como dissemos o batismo é uma regeneração espiritual. Ora, quando um ser é gerado,
recebe simultaneamente a forma e o seu efeito, se nenhum impedimento houver removido o qual, a
forma do ser gerado produz o seu efeito. Assim, logo que um corpo gerado é produzido, move-se para
baixo, salvo havendo algum impedimento, removido o qual, o corpo começa logo a mover-se para baixo.
Semelhantemente, o batizado recebe o caráter como se fosse uma forma e lhe alcança o efeito próprio -
a graça que perdoa todos os pecados. Mas às vezes fica esse efeito impedido pela ficção. Por isso e
necessàriamente, removida esta pela penitência, o batismo produz imediatamente o seu efeito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O sacramento do batismo é obra de Deus e não do
homem. Logo, não é morto em quem o recebeu fingidamente e foi batizado sem caridade.

RESPOSTA À SEGUNDA. — A ficção não se remove pelo batismo, mas pela penitência; e desaparecida
ela, o batismo dele totalmente a culpa e o reato de todos os pecados precedentes ao batismo e também
os existentes quando foi ministrado. Por isso diz Agostinho: O dia de ontem foi perdoado com tudo o
que dele restava, bem como a hora e o momento precedentes ao batismo e o instante mesmo do
batismo. Só depois é que o batizado começa a se fazer réu. E assim, para se alcançar o efeito do
batismo, contribui o batismo e a penitência. Mas o batismo como causa agente essencial; e a penitência,
como - causa acidental, isto é, que remove o obstáculo.

RESPOSTA À TERCEIRA. — O efeito do batismo não é delir os pecados futuros, mas os presentes ou os
passados. Por onde, desaparecida a ficção, os pecados seguintes são perdoados, mas pela penitência,
não pelo batismo. Por isso não são perdoados totalmente quanto ao reato, como os pecados
precedentes ao batismo.