# Questão 71: Dos preparativos que se fazem junto com o batismo.
Em seguida devemos tratar dos preparativos que se fazem junto com o batismo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a catequese deve preceder ao batismo.
O primeiro discute-se assim. — Parece que a catequese não deve preceder ao batismo.

1. — Pois, pelo batismo renascemos para a vida espiritual. Ora, recebemos a vida antes da doutrina.
Logo, não deve ninguém ser catequizado, isto é, ensinado, antes de batizado.

2. Demais. — O batismo é conferido não só aos adultos como também às crianças, incapazes de
receberem a doutrina, por não terem o uso da razão. Logo, é ridículo catequizá-las.

3. Demais. — No catecismo o catecúmeno confessa a sua fé. Ora, a criança não pode confessar a fé, nem
por si mesma nem por outrem. Quer porque ninguém pode obrigar outrem a nada; quer também
porque ninguém pode saber se a criança, chegada à idade adulta, assentirá na fé. Logo, o catecismo não
deve preceder ao batismo.
Mas, em contrário, Rábano diz: Antes de batizar alguém há o dever de instruí-lo, a fim de que o
catecúmeno aprenda primeiro os rudimentos da fé.

SOLUÇÃO. — Como dissemos, o batismo é o sacramento da fé, por ser de certo modo uma profissão da
fé cristã. Ora, para alguém receber a fé é necessário seja instruído nela, segundo aquilo do Apóstolo:
Como crerão àquele que não ouviram? E como ouvirão sem pregador? Por isso, deve o catecismo
preceder ao batismo e o Senhor, ao dar aos discípulos o preceito de batizar, faz preceder a doutrina do
batismo, dizendo: Ide e ensinai a todos os povos, batizando-os, etc.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vida da graça, à qual renascemos pelo batismo,
pressupõe a vida da natureza racional com a qual podemos receber a doutrina.

RESPOSTA À SEGUNDA. — Assim como a Madre Igreja, conforme dissemos, acomoda às crianças, que
vão ser batizadas, os pés dos outros, para que venham, e o coração dos outros, para que creiam; assim
as faz se servirem de alheios ouvidos para ouvirem, e da razão alheia a fim de serem instruídas por
outros. Portanto e pela mesma razão por que devem ser ensinadas, devem também ser batizadas.

RESPOSTA À TERCEIRA. — Aquele que pela criança batizada responde - creio, não prediz que a criança
há de crer, quando tiver chegado à idade de adulto, pois, do contrário diria crerá. Mas proclama a fé da
Igreja na pessoa da criança, a quem ela é comunicada cujo sacramento lhe é conferido e a que se obriga
por meio de outrem. Pois, nenhum inconveniente há em alguém obrigar-se por meio de outrem, em
matéria necessária à salvação. Semelhantemente, também o padrinho, respondendo pela criança,
promete esforçar-se para que a criança creie. O que porem não bastaria aos adultos no uso da razão.

## Art. 2 — Se o exorcismo deve preceder ao batismo.
O segundo discute-se assim. — Parece que o exorcismo não deve preceder ao batismo.

1. — Pois, o exorcismo é contra os energúmenos, isto é, os arreptícios. Ora, nem todos os que se
apresentam ao batismo são tais. Logo, o exorcismo não deve preceder o batismo.

2. Demais. — Enquanto está um em estado de pecado o diabo o tem sob o seu poder; pois, como diz o
Evangelho, todo o que comete pecado é escravo do pecado. Ora o pecado é delido pelo batismo. Logo,
ninguém deve ser exorcizado antes do batismo.

3. Demais. — Para afastar o demônio foi introduzido o uso da água benta. Logo, não era preciso ir
buscar para isso outro remédio nos exorcismos.
Mas, em contrário, Celestino Papa diz: Quer sejam crianças, quer jovens os que vêm ao sacramento da
regeneração, não se acheguem à fonte da vida antes de ter sido expulso deles o espírito imundo pelos
exorcismos e pelas exsuflações dos clérigos.

SOLUÇÃO. — Quem se propõe a fazer com sabedoria uma obra qualquer há de primeiro remover-lhe os
impedimentos. Por isso diz a Escritura: Alqueivai-vos para vós o pousio e não semeieis sobre espinhos.
Ora, o diabo é inimigo da salvação humana que o homem alcança pelo batismo; e tem sobre nós um
certo poder pelo fato de estarmos sujeitos ao pecado original ou também ao atual. Por isso e
convenientemente, antes do batismo são expulsos os demônios pelos exorcismos para não impedirem a
nossa salvação. E é essa expulsão a significada pela exsuflação. Quanto à bênção, com imposição das
mãos, ela fecha ao expulso o caminho para que não volte. O sal posto na boca e a unção, com a saliva,
do nariz e dos ouvidos, significam, no concernente a estes a recepção da doutrina da fé; a sua
aprovação, no concernente ao nariz e, no atinente à boca, a confissão. Por fim, a unção com o óleo
significa a força do catecúmeno para lutar contra os demônios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Chamam-se energúmenos os que, por assim dizer,
sofrem interiormente de uma ação demoníaca exterior. E embora nem todos os que se achegam ao
batismo sejam vexados pelo demônio corporalmente, contudo todos os não-batizados estão sujeitos ao
poder dos demônios, ao menos pelo reato do pecado original.

RESPOSTA À SEGUNDA. — No batismo, pela ablução do pecado fica excluído do batizado o poder do
demônio, enquanto este nos impede de alcançar a glória do céu. Mas os exorcismos tiram ao demônio o
poder de nos impedir a recepção do sacramento.

RESPOSTA À TERCEIRA. — A água benta é usada contra as impugnações externas dos demônios. Mas o
exorcismo é empregado contra as impugnações internas deles; por isso os exorcizados se chamam
energúmenos, isto é, como que padecentes interiormente. - Ou podemos responder que, assim como a
penitência é um segundo remédio contra o pecado, porque o batismo não pode ser reiterado, assim a
água benta é um segundo remédio contra os ataques dos demônios, porque os exorcismos batismais
não se repetem.

## Art. 3 — Se as práticas do exorcismo têm alguma eficácia ou são apenas simbólicas.
O terceiro discute-se assim. — Parece que as práticas do exorcismo não têm nenhuma eficácia, mas
são apenas simbólicas.

1. — Pois, a criança, morta depois dos exorcismos e antes do batismo, não alcança a salvação. Ora, o
efeito de todas as práticas sacramentais é fazer-nos alcançar a salvação. Por isso diz o Evangelho:
Aquele que crer e for batizado será salvo. Logo, as práticas do exorcismo nenhuma eficácia têm, mas são
apenas simbólicas.

2. Demais. — Duas condições bastam a constituir um sacramento da lei nova: ser sinal e causa como se
disse. Logo, se as práticas do exorcismo têm alguma eficácia, resulta que cada uma é um sacramento.

3. Demais. — Assim como o exorcismo se ordena para o batismo, assim também qualquer efeito que ele
tenha se ordena ao efeito do batismo. Ora, a disposição necessàriamente precede à forma perfeita,
pois, a forma não é recebida senão pela matéria disposta. Donde, pois, se seguiria que ninguém poderia
conseguir o efeito do batismo, sem ser primeiro exorcizado; o que é evidentemente falso. Logo, as
práticas do exorcismo nenhuma eficácia têm.

4. Demais. — Assim como certas práticas do exorcismo se fazem antes do batismo, assim também
outras vêm depois dele; tal é a prática de o sacerdote ungir o batizado na cabeça. Ora, as que se fazem
depois do batismo nenhuma eficácia têm, porque do contrário os efeitos do batismo seriam imperfeitos.
Logo, também não a têm nenhuma as que se fazem antes do batismo, no exorcismo.
Mas, em contrário, diz Agostinho: As crianças são exsufladas e exorcizadas, para ser expulso delas o
poder inimigo do diabo, que engana o homem. Ora, a Igreja nada faz em vão. Logo, tais exsuflações têm
o efeito de eliminar o poder do demônio.

SOLUÇÃO. — Certos disseram que as práticas do exorcismo não têm nenhuma eficácia e são apenas
simbólicas. - Mas isto é evidentemente falso, pois a Igreja usa nos exorcismos de palavras imperativas
para expulsar o poder do demônio. Assim, quando diz: Portanto, maldito diabo, sai deste homem, etc.
Por isso devemos admitir que tem uma certa eficácia, mas diferente da do batismo. Porque o batismo
nos dá a graça da remissão plena das culpas. Ao passo que as práticas do exorcisme excluem o amplo
impedimento à consecução da graça da salvação. - Desses impedimentos um é extrínseco e consiste no
esforço que fazem os demônios para nos impedir a salvação. E esse fica anulado pelas exsuflações, que
tiram o poder ao demônio, como se deduz da autoridade citada de Agostinho; isto é, de modo que não
possa o demônio causar nenhum impedimento à recepção do sacramento. Continuam porem a ter
poder sobre o homem quanto à mácula do pecado e ao reato da pena, até ser o pecado delido pelo
batismo. E por isso Cipriano diz: Sabe que a nequicia do diabo pode permanecer até a ablução salutar;
mas toda essa nequícia é aniquilada pelo batismo. - O outro é um impedimento intrinseco, consistente
em termos os sentidos fechados à recepção dos mistérios da salvação, por causa da mácula do pecado
original. Por isso Rábano diz: Pela sabedoria e virtude de Deus, a saliva simbólica e o tato do sacerdote
cooperam para a salvação do catecúmeno abrindo-lhe as narinas, como a um perfume, ao
conhecimento de Deus, as orelhas, aos preceitos de Deus, e o seu senso íntimo a uma fiel
correspondência aos favores divinos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As práticas do exorcismo não tiram a culpa pela qual
somos punidos depois da morte; mas excluem apenas os impedimentos a se receber a remissão da
culpa pelo sacramento. Por isso depois da morte o exorcismo não é válido sem o batismo. Mas
Prepositivo diz, que as crianças exorcizadas, mortas antes do batismo, sofrem trevas menores. O que
não é verdade, por serem essas trevas a privação da visão divina, não susceptível de mais e de menos.

RESPOSTA À SEGUNDA. — É da essência do sacramento produzir o seu principal efeito - a graça, que
perdoa a culpa, ou supre alguma deficiência nossa. Ora, esse efeito não o produzem as práticas do
exorcismo, que apenas removem os referidos impedimentos. Por isso não são sacramentos, mas uns
sacramentais.

RESPOSTA À TERCEIRA. — A disposição suficiente para receber a graça batismal é a fé e a intenção - ou
a própria do batizado, se é adulto; ou a da Igreja, se é criança. Ora, as práticas do exorcismo se ordenam
a remover os impedimentos. Portanto, sem elas é possível alcançar-se o efeito do batismo. - Mas, não
devem ser omitidas senão em artigo de necessidade. E então, quando cessar o perigo, devem ser feitas,
para se conservar a uniformidade no batismo. Nem em vão se realizam depois do batismo, pois, assim
como fica impedido o efeito do batismo, antes de ser recebido, assim também pode ficá-lo, depois de
recebido.

RESPOSTA À QUARTA. — As práticas feitas sobre o batizado, depois do batismo, não são apenas
simbólicas, mas também têm eficácia. Assim, a unção feita na cabeça, cuja finalidade é a conservação da
graça batismal. Mas há práticas que nenhuma eficácia tem e são apenas simbólicas. Tais as vestes
brancas significativas da novidade da vida.

## Art. 4 — Se é próprio do sacerdote catequizar e exorcizar o catecúmeno.
O quarto discute-se assim. — Parece que não é próprio do sacerdote catequizar e exorcizar o
catecúmeno.

1. — Pois, ao ofício dos ministros pertence agir sobre os imundos, como diz Dionísio. Ora, os
catecúmenos, que são instruídos no catecismo, e os energúmenos, que são purificados no exorcismo,
contam-se entre os imundos, como diz Dionísio no mesmo lugar. Logo, catequizar e exorcizar não
pertence ao ofício do sacerdote, mas antes, dos ministros.

2. Demais. — Os catecúmenos são instruídos na fé pela Sagrada Escritura, lida na igreja pelos ministros.
Pois, assim como os leitores lêem na igreja o Testamento Velho, assim também os diáconos e os
subdiáconos lêem o Novo. Portanto, aos ministros pertence catequizar. E também exorcizar parece
pertencer aos ministros. Assim, diz Isidoro: O exorcista deve reter de memória os exorcismos e impor as
mãos sobre os energúmenos e os catecúmenos, que devem ser exorcizados. Logo, não é ofício do
sacerdote catequizar e exorcizar.

3. Demais. — Catequizar é o mesmo que ensinar, e ensinar é aperfeiçoar. O que é ofício dos bispos,
como diz Dionísio. Logo, não é ofício do sacerdote.
Mas, em contrário, Nicolau Papa diz: O catecismo dos que devem ser batizados pode ser feito pelos
sacerdotes de cada igreja. E Gregório também diz: Os sacerdotes, quando pela graça do exorcismo,
impõem as mãos aos crentes, que outra coisa fazem senão expulsar os demônios?

SOLUÇÃO. — O ministro está para o sacerdote como um agente secundário e instrumental para o
principal, como o indica o nome mesmo de ministro. E, o agente secundário não obra sem a cooperação
do agente principal. Ora, quanto mais importante é a operação tanto mais o agente principal precisa de
melhores instrumentos. Ora, é mais importante a ação do sacerdote conferir o sacramento que fazer os
preparativos para ele. Por isso os ministros mais elevados, chamados diáconos, cooperam com o
sacerdote no ato de conferir os sacramentos. Assim, diz Isidoro, que ao diácono pertence assistir aos
sacerdotes e servi-los nos atos sacramentais, isto é, no batismo, no crisma, na patena e no cálice.
Quantos aos ministros inferiores, eles cooperam com os sacerdotes nos preparativos para o
sacramento; assim, os leitores, no catecismo e os exorcistas no exorcismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Sobre os imundos os ministros exercem uma ação
ministerial e como que instrumental; mas o sacerdote, a principal.

RESPOSTA À SEGUNDA. — Os leitores e os exorcistas têm o ofício de catequizar e exorcizar, não como
causas principais, mas como os que servem ao sacerdote.

RESPOSTA À TERCEIRA. — A instrução pode ser de muitas espécies. - Uma é destinada a converter à fé.
E essa, Dionísio a atribui ao bispo; mas qualquer pregador ou ainda qualquer fiel pode exercê-la. — A
segunda espécie de instrução é a pela qual aprendemos os rudimentos da fé e o modo de recebermos
os sacramentos. E essa cabe, secundàriamente, aos ministros e, principalmente, aos sacerdotes. — A
terceira ensina-nos a vivermos cristamente. — E essa concerne os padrinhos. — A quarta versa sobre os
profundos mistérios da fé e a perfeição da vida cristã. E essa de ofício é reservada aos bispos.
O Sacramento da Confirmação