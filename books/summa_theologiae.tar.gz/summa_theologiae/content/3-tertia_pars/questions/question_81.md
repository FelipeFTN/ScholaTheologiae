# Questão 81: Do uso que Cristo fez deste sacramento
Em seguida devemos tratar do uso que Cristo fez deste sacramento, quando o instituiu.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se Cristo tomou o seu próprio corpo e sangue.
O primeiro discute-se assim. — Parece que Cristo não tomou o seu próprio corpo e sangue.

1. — Pois, não devemos afirmar dos atos e ditos de Cristo senão o que não nos transmitiu a autoridade
da Sagrada Escritura. Ora, os Evangelhos não referem ter Cristo comido, o seu corpo nem bebido o seu
sangue. Logo, também nós não podemos afirmá-la.

2. Demais. — Nenhum ser pode estar em si mesmo, salvo talvez em razão das partes, isto é, enquanto
uma parte está em outra, como o ensina Aristóteles. Ora, o que é comido e bebido está em quem come
e bebe. Logo, estando Cristo totalmente sob ambas as espécies do sacramento, parece impossível que
ele próprio recebesse este sacramento.

3. Demais. — De dois modos podemos receber este sacramento — o espiritual e sacramental. Ora,
recebê-lo espiritualmente não cabia a Cristo, pois, nenhuma graça tinha a receber deste sacramento. E
por conseqüência nem o modo sacramental, que sem o espiritual é imperfeito, como se estabeleceu.
Logo, Cristo de nenhum modo recebeu este sacramento.
Mas, em contrário, diz Jerônimo: Nosso Senhor Jesus Cristo foi ao mesmo tempo conviva e o banquete,
ele próprio a si mesmo se comeu.

SOLUÇÃO. — Certos disseram que Cristo, na Ceia, deu aos seus discípulos o seu corpo e sangue, mas ele
próprio não os tomou. — Mas esta opinião é inadmissível. Porque Cristo era o primeiro a observar o que
instituiu para os outros observarem. Por isso quis ser batizado antes de impor o batismo aos outros,
segundo aquilo da Escritura: Começou Jesus a fazer e a ensinar. Por onde, primeiro tomou o seu corpo e
o seu sangue e depois deu a tomá-las aos discípulos. Assim, àquilo da Escritura — Depois que comeu e
bebeu, etc. — diz a Glosa: Cristo comeu e bebeu na ceia, quando deu aos discípulos o sacramento do
seu corpo e sangue. Por onde, como os filhos tiveram carne e sangue comum, ele também participou
igualmente das mesmas causas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os Evangelhos referem que Cristo tomou o pão e o
cálice. Mas não devemos entendê-lo como os tivesse apenas tomado nas mãos, segundo certos dizem;
senão que os tomou para os dar a tomar aos outros. Por isso, o dizer aos discípulos: Tomai e comei, e
ainda — Tomai e bebei, deve-se entender como tendo ele próprio tomado para comer e beber. Assim é
que certos o disseram em verso:
O Rei está sentado, na Ceia, rodeado do grupo dos doze;
Tem-se a si mesmo nas mãos, é para si o seu próprio alimento.

RESPOSTA À SEGUNDA. — Como dissemos, Cristo, enquanto está neste sacramento, ocupa lugar, não
nas suas dimensões próprias, mas nas dimensões das espécies sacramentais. De modo que, em
qualquer lugar onde essas espécies estiverem aí está o próprio Cristo. E como tais espécies podiam estar
nas mãos e na boca de Cristo, o próprio Cristo podia estar totalmente nas suas mãos e na sua boca. Mas
isso não poderia dar-se se ocupasse um lugar segundo as suas espécies próprias.

RESPOSTA À TERCEIRA. — Como dissemos o efeito deste sacramento é não só o aumento da graça
habitual, mas também uma certa deleitação atual com a doçura espiritual. Mas embora a graça de
Cristo não aumentasse por ter recebido este sacramento, gozou contudo de um certo deleite espiritual,
pela nova instituição dele. Por isso ele próprio o disse: Tenho desejado ansiosamente comer convosco
esta Páscoa. O que Eusébio expõe como alusivo ao novo mistério do Testamento Novo, que transmitiu
aos discípulos. Por onde, comungou tanto espiritual como sacramentalmente, enquanto tomou o seu
corpo sob a forma de sacramento, sacramento que sabia e dispôs que era o do seu corpo. Mas de modo
diferente do que os demais, quando o recebem sacramental e espiritualmente, que recebem aumento
de graça e precisam dos sinais sacramentais para perceberem a verdade.

## Art. 2 — Se Cristo deu o seu corpo a Judas.
O segundo discute-se assim. — Parece que Cristo não deu o seu corpo a Judas.

1. — Pois, como lemos no Evangelho, depois de ter o Senhor dado o seu corpo e o seu sangue aos
discípulos, disse-lhes: Não beberei mais deste fruto da vida até àquele dia em que o beberei de novo
convosco no reino de meu Pai. Donde se conclui que aqueles a quem deu o seu corpo e o seu sangue de
novo haviam de beber com ele. Ora, Cristo não o bebeu de novo com ele. Logo, não recebeu com os
outros discípulos o corpo e o sangue de Cristo.

2. Demais. — O Senhor cumpriu o que mandou, segundo aquilo da Escritura: Começou Jesus a fazer e a
ensinar. Mas ele próprio ordenou: Não deis aos cães o que é santo. Logo, sabendo que Judas era
pecador, parece que não lhe deu o seu corpo nem o seu sangue.

3. Demais. — O Evangelho narra em particular, que Cristo deu a Judas o pão molhado. Se, portanto, deu-
lhe o seu corpo, parece que lh'o deu como um bocado. Tanto mais quanto lemos no mesmo lugar que
atrás do bocado entrou nele Satanás. Ao que diz Agostinho: Daqui aprendamos o quanto devemos nos
acautelar de receber mal o bem. Se, pois é condenado quem não distingue, isto é, não discerne dos
outros alimentos o corpo de Cristo, como não o será quem, fingindo-se-lhe amigo, achega-se-lhe à mesa
como inimigo? Ora, com o bocado molhado não recebeu o corpo de Cristo, conforme adverte
Agostinho, comentando aquilo do Evangelho: Tendo molhado o pão, deu-o a Judas, filho de Simão
Iscariotes: Mas então Judas não recebeu o corpo de Cristo, como o pensam certos, que lêem
desatentamente. Logo, parece que Judas não recebeu o corpo de Cristo.
Mas, em contrário, diz Crisóstomo: Judas, sendo participante dos mistérios, não se converteu. Por isso
mais monstruoso se lhe tornou o crime, tanto por se ter achegado ao sacramento, cheio já do seu mau
propósito, como por não se ter tornado melhor, achegando-se a ele, nem pelo medo, nem pelo
beneficia nem pela honra.

SOLUÇÃO. — Hilário afirmou que Cristo não deu a Judas nem o seu corpo nem o seu sangue. O que teria
sido conveniente, considerada a malícia de Judas. Mas, como Cristo devia ser-nos um exemplo de
justiça, não lhe convinha ao magistério separar a Judas, pecador oculto, sem acusador e provas
evidentes, da comunhão dos outros. A fim de não dar por aí aos prelados da Igreja o exemplo, pelo qual
procedessem semelhantemente. E para que o próprio Judas, exasperado com isso, não tirasse daí
ocasião de pecar. Por onde, devemos concluir, que Judas recebeu, com os outros discípulos, o corpo e o
sangue do Senhor, como diz Dionísio e Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa é a razão de Hilário, para mostrar que Judas não
recebeu o corpo de Cristo. Mas não é cogente, porque Cristo fala aos discípulos de cujo colégio Judas se
separou, sem que Cristo o tivesse excluído. Por onde, Cristo, da sua parte, também com Judas, bebe o
vinho no reino de Deus; mas esse convite o próprio Judas o repudia.

RESPOSTA À SEGUNDA. — Cristo, como Deus, conhecia a nequícia de Judas; mas não a conhecia ao
modo por que os homens conhecem. Por isso não excluiu a Judas da comunhão, para dar o exemplo aos
outros sacerdotes, de não excluírem tais pecadores ocultos.

RESPOSTA À TERCEIRA. — Sem dúvida Judas, comendo o pão molhado, não recebeu o corpo de Cristo,
mas um simples pão. Mas talvez, adverte Agostinho, o pão molhado significa o fingimento de Judas;
assim, certas coisas se molham para mudarem de cor. Mas, se esse pão molhado tem uma boa
significação, a saber, a doçura da bondade divina, porque o pão se torna de melhor sabor quando
molhado, ao que foi ingrato a esse bem se lhe seguiu merecidamente a condenação. Assim como se dá
com os que recebem o corpo de Cristo indignamente. — E segundo diz Agostinho no mesmo lugar
devemos compreender que o Senhor já antes distribuíra a todos os seus discípulos o sacramento do seu
corpo e do seu sangue e com eles estava o próprio Judas, como o narra Lucas. Mas depois, segundo a
narração de João, veio o Senhor a revelar o seu traidor, pelo bocado molhado que lhe deu.

## Art. 3 — Se Cristo, tomou e deu aos discípulos, o seu corpo impassível.
O terceiro discute-se assim. — Parece que Cristo tomou e deu aos discípulos o seu corpo impassível.

1. — Pois, àquilo do Evangelho — Transfigurou-se perante eles — diz uma glosa: Aquele corpo que tinha
por natureza, esse o deu aos discípulos na Ceia, não mortal e passível. E ao outro lugar da Escritura —
diz a Glosa: A Cruz, soberanamente forte, tornou capaz de ser comida a carne de Cristo, que antes da
paixão não o era. Ora, Cristo nos deu o seu corpo capaz de ser comido. Logo, deu-o tal qual o tinha
depois da paixão, isto é, impassível e imortal.

2. Demais. — Todo corpo passível sofre, sendo tocado e comido. Se, portanto, o corpo de Cristo fosse
passível, teria sofrido com o fato de os discípulos terem-no tocado e comido.

3. Demais. — As palavras sacramentais não tem então maior virtude quando proferidas pelo sacerdote
em nome de Cristo, que quando foram proferidas pelo próprio Cristo. Ora, o sacerdote, em virtude das
palavras sacramentais, consagra no altar o corpo de Cristo impassível e imortal. Logo, com maior razão o
fez Cristo.
Mas, em contrário como diz Inocêncio III, então deu aos discípulos um corpo tal qual tinha. Ora, tinha
então um corpo passível e mortal. Logo, foi um corpo passível e mortal que deu aos discípulos.

SOLUÇÃO. — Hugo Victorino (Inocenc. III), afirmou, que Cristo, antes da paixão e em diversas ocasiões,
assumiu quatro dotes do corpo glorificado, a saber: a subtileza, na natividade, quando saiu do ventre
virginal de Maria; a agilidade, quando andou sobre o mar, sem molhar os pés; a claridade, na
transfiguração; a impassibilidade, na Ceia, quando deu o seu corpo a comer aos discípulos. E, sendo
assim, deu aos discípulos o seu corpo impassível e imortal. Mas, seja o que for que se deva pensar dos
outros dotes, a cujo respeito já nos pronunciamos, sobre a impassibilidade porém é inadmissível a
opinião de Hugo. Pois, como é manifesto, era o mesmo verdadeiro corpo de Cristo que os discípulos
viam então na sua forma própria e tomaram na espécie sacramental. Mas, na sua forma própria, em que
era assim visto, não era impassível; ao contrário, estava preparado para a paixão. Por onde, também o
corpo de Cristo, dado sob a forma de sacramento, não era impassível. Mas estava de modo impassível,
sob a espécie do sacramento, o que em si havia de passível. Pois, assim como a visão requere o contato
do corpo visto, pelo meio atmosférico, assim, a paixão requere o contato do corpo paciente com o
agente que nele produz a paixão. Ora, o corpo de Cristo, do modo por que está neste sacramento, não
se relaciona com as coisas que o circundam, mediante as suas dimensões próprias, pelas quais os corpos
se tocam — como dissemos; mas mediante as dimensões das espécies do pão e do vinho. Por onde, são
essas espécies as pacientes e as que são vistas, mas não o corpo mesmo de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que Cristo, na Ceia, não deu o seu corpo mortal e
passível, pelo não haver dado de modo mortal e passível. Mas a cruz tornou o corpo de Cristo capaz de
ser comido, enquanto este sacramento representa a paixão de Cristo.

RESPOSTA À SEGUNDA. — A objeção colheria se o corpo de Cristo, assim como era passível, assim
também estivesse neste sacramento de maneira passível.

RESPOSTA À TERCEIRA. — Como dissemos, os acidentes do corpo de Cristo estão no sacramento por
concomitância real; não porém em virtude do sacramento, pela qual nele está a substância do corpo de
Cristo. Por onde, a virtude das palavras sacramentais faz com que esteja sob o sacramento o corpo de
Cristo, a saber, com todos os acidentes realmente nele existentes.

## Art. 4 — Se, na ocasião da morte de Cristo, este sacramento estivesse conservado numa píxide, ou fosse consagrado por um dos Apóstolos, Cristo ai morreria.
O quarto discute-se assim. — Parece que, se na ocasião da morte de Cristo, este sacramento estivesse
conservado numa píxide, ou fosse consagrado por um dos Apóstolos, Cristo aí não morreria.

1. — Pois, a morte de Cristo se cumpriu pela sua paixão. Ora, então, Cristo estava de modo impassível
neste sacramento. Logo, nele não podia morrer.

2. Demais. — Na morte de Cristo o sangue se lhe separou do corpo. Ora, neste sacramento estão
simultaneamente o seu corpo e o seu sangue. Logo, neste sacramento Cristo não morreria.

3. Demais. — A morte resulta da separação da alma, do corpo. Ora, este sacramento contém tanto o
corpo como a alma de Cristo. Logo, neste sacramento Cristo não podia morrer.
Mas, em contrário, o mesmo Cristo, que estava na cruz, estaria neste sacramento. Ora, na cruz estava
morto. Logo, também o havia de estar, conservado no sacramento.

SOLUÇÃO. — O corpo de Cristo é substancialmente o mesmo, tanto neste sacramento como na sua
forma própria, mas não do mesmo modo. Pois, na sua forma própria, se relaciona com os corpos
circunstantes pelas dimensões que lhe são naturais, o que não se dá com as espécies sacramentais. Por
onde, todos os atributos essenciais a Cristo — como viver, morrer, sofrer, ser animado ou inanimado e
semelhantes — podem ser dele predicados, tanto na sua existência própria como na sacramental. Mas
tudo o que lhe respeita, nas suas relações com os corpos externos — como ser objeto de irrisão e de
conspurcação, ser crucificado, flagelado e coisas semelhantes — podemos atribuir-lhe à sua existência
própria, mas não à sacramental. Por isso certos disseram em verso: Cristo, conservado numa píxide,
poderá sofrer as dores que o seu corpo é susceptível, mas não, novas que lhe adviessem de uma causa
exterior.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como dissemos, um corpo passível é susceptível da
paixão causada por um agente externo. Por isso Cristo, existente sob as espécies sacramentais, não
pode sofrer. Mas pode morrer.

RESPOSTA À SEGUNDA. — Como dissemos, sob a espécie do pão está o corpo de Cristo em virtude da
consagração; e o seu sangue, sob a espécie do vinho. Mas, nas circunstâncias atuais, em que realmente
o sangue de Cristo não lhe está separado do corpo, por concomitância real o seu sangue está sob a
espécie do pão simultaneamente com o corpo, e o corpo sob a espécie do vinho, simultaneamente com
o sangue. Mas, se na ocasião da paixão de Cristo, quando o seu sangue estava realmente separado do
seu corpo, este sacramento tivesse sido celebrado, sob a espécie do pão estaria o corpo de Cristo, e só o
seu sangue sob a espécie do vinho.

RESPOSTA À TERCEIRA. — Como dissemos, a alma de Cristo está neste sacramento por concomitância
real, que não pode ser sem o corpo; mas não por força da consagração. Por onde, se então tivesse sido
este sacramento celebrado ou consumado, quando a alma estava realmente separada do, corpo, a alma
de Cristo não estaria sob este sacramento. Não por falta de virtude das palavras, mas por uma
disposição real.