# Questão 38: Do batismo de João
Em seguida devemos tratar do batismo com que Cristo foi batizado. E como Cristo foi batizado pelo
batismo de João, primeiro devemos tratar do batismo de João, em geral. Segundo, do batismo de Cristo.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se era conveniente que João batizasse.
O primeiro discute-se assim. — Parece não era conveniente que João batizasse.

1. — Pois, todo rito sacramental supõe uma determinada lei. Ora, João não introduziu nenhuma lei
nova. Logo, era inconveniente que introduzisse um novo rito de batizar.

2. Demais. — João foi mandado por Deus em testemunha, como profeta, segundo o Evangelho: Tu, ó
menino, serás chamado o profeta do Altíssimo. Ora, os profetas anteriores a Cristo não introduziram
nenhum rito novo, mas advertiam à observância dos ritos legais, como está claro na Escritura: Lembrai-
vos da lei de Moisés, meu servo. Logo, também João não devia introduzir nenhum rito novo de batizar.

3. Demais. — Ao que já é supérfluo nada se lhe deve acrescentar. Ora, os Judeus tinham
superabundância de batismos, como se lê no Evangelho: Os Fariseus e todos os Judeus não comem sem
lavarem as mãos muitas vezes; e quando vêm do mercado não comem sem se purificarem; e assim
observam muitos outros costumes que lhes ficaram por tradição, como lavar os copos e os jarros e os
vasos de metal e os leitos. Logo, não devia João batizar.
Mas, em contrário, a autoridade da Escritura quando, depois de referida a santidade de João, acrescenta
que acorriam a ele muitos, que eram batizados no Jordão.

SOLUÇÃO. — Era conveniente que João batizasse, por quatro razões. - Primeiro, porque era necessário
Cristo fosse batizado por João, para que consagrasse o batismo, como diz Agostinho. - Segundo, para
que Cristo se manifestasse. Por isso diz o próprio João Batista: Por isso eu vim batizar em água, para ele,
isto é, Cristo ser conhecido em Israel. Pois, anunciava Cristo às turbas que acorriam; e isso era mais fácil,
que se tivesse de anunciá-lo a cada um em particular, como adverte Crisóstomo. - Terceiro, para
acostumar os homens, com o seu batismo, ao batismo de Cristo. Donde o dizer Gregório que João
batizava, a fim de desempenhar o seu papel de precursor; pois, assim como nascendo, prevenira o
nascimento do Senhor, assim, batizando, preveniu-lhe o batismo. - Quarto, a fim de, chamando os
homens à penitência, os preparasse a receber dignamente o batismo de Cristo. Por isso diz Beda. Tanto
aproveita aos catecumenos ainda não batizados a doutrina da fé, quanto aproveitava o batismo de João
antes do batismo de Cristo. Pois, assim como João pregava a penitência e prenunciava o batismo de
Cristo, e atraía para o conhecimento da verdade, que apareceu ao mundo, assim os ministros da Igreja
primeiro ensinam, depois corrigem dos pecados e enfim prometem pelo batismo de Cristo a remissão
deles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O batismo de João não era em si mesmo um
sacramento; mas um como sacramento, que dispunha para o batismo de Cristo. Por isso, de certo modo
pertencia à lei de Cristo e não à lei de Moisés.

RESPOSTA À SEGUNDA. — João não só foi profeta, mas maior que profeta, como diz a Escritura. Pois, foi
o termo da lei e o início do Evangelho. Por isso mais lhe incumbia trazer, pelas palavras e pelas obras, os
homens à lei de Cristo, que à observância da lei antiga.

RESPOSTA À TERCEIRA. — Esses batismos dos Fariseus eram vãos, por se ordenarem só à purificação do
corpo. Ao contrário, o batismo de João se ordenava à purificação espiritual, pois induzia os homens à
penitência, como se disse.

## Art. 2 — Se o batismo de João procedia de Deus.
O segundo discute-se assim. — Parece que o batismo de João não procedia de Deus.

1. — Pois, nenhum sacramental procedente de Deus tira a sua denominação de um simples homem;
assim, o batismo da lei nova não se chama de Pedro ou de Paulo, mas de Cristo. Ora, o batismo referido
se denomina de João, segundo O Evangelho: Donde era o batismo de João? Do céu ou dos homens?
Logo, o batismo de João não procedia de Deus.

2. Demais. — Toda nova doutrina procedente de Deus se confirma por certos milagres. Por isso, o
Senhor deu. a Moisés o poder de fazer milagres; e o Apóstolo diz: A nossa fé, tendo começado a ser
anunciada pelo Senhor, foi depois confirmada entre nós pelos que a ouviram, confirmando-a ao mesmo
tempo Deus com sinais e maravilhas. Ora, de João Batista diz o Evangelho: João não fez milagre algum.
Logo, parece que o batismo que ministrava não procedia de Deus.

3. Demais. — Os sacramentos instituídos por Deus estão contidos em certos preceitos da Sagrada
Escritura. Ora, o batismo de João não está incluído em nenhum preceito da Sagrada Escritura. Logo,
parece que não procedia de Deus.
Mas, em contrário, o Evangelho: O que me mandou batizar em água me disse — Aquele sobre que tu
vires descer o Espírito, etc.

SOLUÇÃO. — No batismo de João dois elementos podemos considerar: o rito de batizar e o efeito do
batismo. Quanto ao rito de batizar, não procedia dos homens, mas de Deus, que, por uma particular
revelação do Espírito Santo, mandou João a batizar. Mas, o efeito desse batismo era de procedência
humana, pois, nada se realizou nele que um homem não pudesse realizar. Por onde, não procedia só de
Deus, senão no sentido em que Deus agia por meio de um homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pelo batismo da lei nova os homens são batizados
interiormente pelo Espírito Santo, o que só Deus faz. Ao passo que o batismo de João purificava só o
corpo por meio da água. Por isso diz o Evangelho: Eu vos batizo em água; porém ele vos batizará no
Espírito Santo. Donde a denominação de batismo de João, porque não tinha nenhum efeito que não
fosse produzido por João. Ao passo que o batismo da lei nova não tira à sua denominação do ministro,
que não é o autor da purificação interior, principal efeito do batismo.

RESPOSTA À SEGUNDA. — Toda a doutrina e ação de João se ordenava para Cristo, que com inúmeros
milagres confirmou tanto a sua doutrina como a de João. Se, porém, João tivesse feito milagres, os
homens tanto seguiram a João como a Cristo. Por isso, para que ouvissem principalmente a Cristo, não
foi concedido a João fazer milagres. Mas, aos judeus, que o interrogavam porque batizava, confirmou o
seu ofício com a autoridade da Escritura, dizendo: Eu sou a voz do que clama no deserto, etc., como se
lê no Evangelho. E alem disso, a austeridade da sua vida recomendava-lhe o ofício; pois, como
Crisóstomo diz, era admirável ver tanta mortificação num corpo humano.

RESPOSTA À TERCEIRA. — O batismo de João não foi ordenado por Deus, senão para durar pouco
tempo, pelas causas referidas. Por isso não foi prescrito por nenhum preceito geral contido na Sagrada
Escritura, mas por uma particular revelação do Espírito Santo, como se disse.

## Art. 3 — Se o batismo de João conferia a graça.
O terceiro discute-se assim. — Parece que o batismo de João conferia a graça.

1. — Pois, diz o Evangelho: Estava João batizando no deserto e pregando o batismo de penitência para a
remissão de pecados. Ora, a penitência e a remissão dos pecados só é possível pela graça. Logo, o
batismo de João conferia a graça.

2. Demais. — Os que iam ser batizados por João confessavam os seus pecados como se lê no Evangelho.
Ora, a confissão dos pecados tem por fim a remissão deles, que se opera pela graça. Logo, o batismo de
João conferia a graça.

3. Demais. — O batismo de João se aproximava do de Cristo, mais que a circuncisão. Ora, a circuncisão
remetia o pecado original. Pois, como diz Beda, na vigência da lei antiga, a circuncisão era o mesmo
remédio salutar contra o ferimento do pecado original, que o batismo costuma ser no regime da lei da
graça. Logo, com maior razão, o batismo de João conferia a remissão dos pecados. O que não pode dar-
se sem a graça.
Mas, em contrário, o Evangelho: Eu na verdade vos batizo em água para vos trazer à penitência. Lugar
que Gregório assim explica numa homília: João batiza não pelo espírito mas pela água, porque não
podia perdoar os pecados. Ora, a graça, pela qual o pecado é delido, vem do Espírito Santo. Logo, o
batismo de João não conferia a graça.

SOLUÇÃO. — Como dissemos, toda a doutrina e ação de João era preparatória para a de Cristo; assim
como é próprio de um ministro ou de um artífice inferior preparar a matéria para a forma a ser
infundida pelo artífice principal. Ora, a graça devia ser conferida aos homens por Cristo, segundo àquilo
do Evangelho: A graça e a verdade foi trazida por Jesus Cristo. Logo, o batismo de João não conferia a
graça, mas só preparava para ela, de três modos. Primeiro, pela sua doutrina João induzia os ouvintes à
fé de Cristo. Segundo, acostumava-os ao rito do batismo. Terceiro, pela penitência, preparava os
homens a receberem o efeito do batismo de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Por essas palavras de Beda pode entender-se um duplo
batismo. Um, que João conferia, chamado batismo de penitência, porque de certo modo induzia à
penitência e era uma como afirmação pela qual os homens confessavam que haviam de fazer
penitência. Outro é o batismo de Cristo, pelo qual os pecados são perdoados; esse, João não o podia
ministrar, mas apenas o pregava quando dizia; Ele vos batizará no Espírito Santo. — Ou pode dizer-se
que pregava o batismo da penitência, isto é, inducente à penitência, a qual leva os homens ao perdão
dos pecados. — Ou pode dizer-se, que pelo batismo de Cristo, como explica Jerônimo, é dada a graça
pela qual os pecados são gratuitamente perdoados; o que porém se consuma pelo Esposo é iniciado
pelo paraninfo, isto é, por João. Por isso, diz que batizará e pregará o batismo de penitência para a
remissão de pecados; não que ele próprio o consumasse, mas porque começava, preparando.

RESPOSTA À SEGUNDA. — Essa confissão dos pecados não se fazia com o fim de o perdão deles ser logo
conferido pelo batismo de João; mas de ser conseguido pela penitência consequente, e pelo batismo de
Cristo, para o qual essa penitência preparava.

RESPOSTA À TERCEIRA. — A circuncisão foi instituída como remédio do pecado original. Mas para tal
não foi instituído o batismo de João, que era só preparatório para o batismo de Cristo, como se disse.
Ora, os sacramentos produzem o seu efeito de acordo com a força da sua instituição.

## Art. 4 — Se pelo batismo de João só Cristo devia ser batizado.
O quarto discute-se assim. — Parece que pelo batismo de João só Cristo devia ser batizado.

1. — Porque, como se disse, João batizou para que Cristo fosse batizado, no dizer de Agostinho. Ora, o
que é próprio de Cristo não deve convir aos outros. Logo, ninguém mais devia ser batizado com esse
batismo.

2. Demais. — Quem é batizado ou recebe alguma causa do batismo ou lhe confere algo. Ora pelo
batismo de João ninguém podia receber nada, porque ele não conferia a graça, como se disse. Nem
ninguém podia conferir nada ao batismo, senão Cristo, que com o contato do seu corpo santificou as
águas. Logo, parece que só Cristo devia ser batizado pelo batismo de João.

3. Demais. — Se outros receberam esse batismo, não era senão para se prepararem ao batismo de
Cristo; e, assim, parecia conveniente que, como o batismo de Cristo era conferido a todos grandes e
pequenos, gentios e judeus, também o devia ser o batismo de João. Ora, o Evangelho não fala de
crianças nem de gentios batizados por ele; mas diz Marcos, que saíam concorrendo a ele todos os de
Jerusalém e eram batizados por ele. Logo, parece que só Cristo devia ter sido batizado por João.
Mas, em contrário, o Evangelho: E aconteceu que, como recebesse o batismo todo o povo, depois de
batizado também Jesus, e estando em oração, abriu-se o céu.

SOLUÇÃO. — Por dupla causa deviam outros, além de Cristo, ter sido batizados por João. - Primeiro,
porque, como diz Agostinho, se só Cristo tivesse recebido o batismo de João, não faltaria quem dissesse
que o batismo de João, conferido a Cristo, era mais digno que o do próprio Cristo, pelo qual os outros
eram batizados. — Segundo, porque era necessário que os outros fossem preparados, pelo batismo de
João, ao batismo de Cristo, como dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O batismo de João não foi instituído só para Cristo ser
batizado, mas também por outras causas, como dissemos. E contudo, mesmo que tivesse sido instituído
só para que Cristo fosse batizado, era mister evitar o referido inconveniente, conferindo a outros esse
batismo.

RESPOSTA À SEGUNDA. — Os outros que recebiam o batismo de João, não podiam por certo conferir
nada a esse batismo; nem contudo dele recebiam a graça, mas só o sinal da penitência.

RESPOSTA À TERCEIRA. — O referido batismo era de penitência, imprópria das crianças; por isso é que
elas não o recebiam. — Quanto a abrir aos gentios o caminho da salvação, só a Cristo estava reservado,
que é a Expectação das Gentes, no dizer da Escritura. Mas o próprio Cristo proibiu aos Apóstolos pregar
o Evangelho aos gentios, antes da paixão e da ressurreição. Por onde, muito menos convinha que João
admitisse os gentios ao batismo.

## Art. 5 — Se o batismo de João devia cessar depois que Cristo foi batizado.
O quinto discute-se assim. — Parece que o batismo de João devia cessar depois que Cristo foi
batizado.

1. — Pois, diz o Evangelho: Por isso eu vim batizar em água, para ele ser conhecido em Israel. Ora, pelo
batismo que recebeu Cristo se manifestou suficientemente; quer também pelo testemunho de João;
quer pela descida da pomba; quer também pelo testemunho da voz paterna. Logo, parece que, depois,
não devia durar o batismo de João.

2. Demais. — Agostinho diz: Cristo batizado cessou o batismo de João. Logo, parece que João não devia
continuar a batizar, depois do batismo de Cristo.

3. Demais. — O batismo de João era preparatório ao de Cristo. Ora, o batismo de Cristo começou logo
depois de ele ter sido batizado; pois, pelo contato do seu puríssimo corpo conferiu às águas a virtude
regeneradora, como diz Beda. Logo, parece que o batismo de João cessou uma vez Cristo batizado.
Mas, em contrário, o Evangelho: Veio Jesus para a terra de Judéia e batizava; e João também batizava.
Ora, Cristo só batizou depois de ter sido batizado. Logo, parece que mesmo depois de Cristo ter sido
batizado, João ainda continuava a batizar.

SOLUÇÃO. — O batismo de João não devia cessar, depois de Cristo batizado. - Primeiro, porque, como
diz Crisóstomo, se João cessasse de batizar, uma vez Cristo batizado, haveriam de pensar que o fez por
ciúmes ou por cólera. - Segundo, porque se cessasse de batizar, depois de Cristo estar batizando,
poderia despertar maiores ciúmes nos seus discípulos. - Terceiro, porque continuando a batizar, enviava
à Cristo os seus ouvintes. - Quarto, porque, como diz Beda, ainda permaneciam as sombras da lei antiga;
nem devia cessar o precursor, antes da verdade manifestar-se.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo batizado, ainda não se tinha assim plenamente
manifestado. Por isso ainda era necessário João continuar a batizar.

RESPOSTA À SEGUNDA. — Batizado Cristo, cessou o batismo de João; não, porém imediatamente, mas
só quando ele foi encarcerado. Por isso diz Crisóstomo: Penso que a morte de João foi permitida, e que
sobretudo depois dessa morte é que Cristo começou a pregar, para que este concentrasse em si todas
as afeições do povo e desaparecessem os dissentimentos que, a propósito de um e de outro, já tinham
começado a manifestar-se.

RESPOSTA À TERCEIRA. — O batismo de João era preparatório não só ao batismo de Cristo, mas
também para que outros se achegassem a receber este último batismo. O que ainda não se tinha
realizado, mesmo depois que Cristo foi batizado.

## Art. 6 — Se os que já tinham recebido o batismo de João deviam receber também o batismo de Cristo.
O sexto discute-se assim. — Parece que os que já tinham recebido o batismo de João não deviam
receber depois o batismo de Cristo.

1. — Pois, João não era menor que os Apóstolos segundo a ele se refere o Evangelho: Entre os nascidos
de mulheres não se levantou outro maior que João Batista. Ora, os que foram batizados pelos Apóstolos
não o foram de novo, mas só se lhes acrescentou a imposição das mãos. Assim, diz a Escritura, que
certos foram somente batizados por Filipe em nome do Senhor Jesus; então os Apóstolos, isto é, Pedro
e João, punham as mãos sobre eles e recebiam o Espírito Santo. Logo, parece que os batizados por João
não deviam receber também o batismo de Cristo.

2. Demais. — Os Apóstolos receberam o batismo de João, pois, alguns foram discípulos dele. Ora, parece
que os Apóstolos não receberam o batismo de Cristo; assim, diz o Evangelho: Jesus não batizava, mas
sim os seus discípulos. Logo, parece que os que tinham recebido o batismo de João não deviam depois
receber o de Cristo.

3. Demais. — O batizado é inferior a quem o batiza. Ora, não diz a Escritura que João tivesse recebido o
batismo de Cristo. Logo, com maior razão, os batizados por João precisavam de ser depois batiza dos por
Cristo.

4. Demais. — Diz a Escritura: Paulo achou alguns discípulos e lhes disse: Vós recebestes já o Espírito
Santo quando abraçastes a fé? E eles lhe responderam: Antes nós nem sequer temos ainda ouvido se há
Espírito Santo. E ele lhes disse: Em que batismo fostes vós batizados? eles disseram: No batismo de
João. Por onde, foram batizados de novo em nome do Senhor Jesus. E assim, parece que era preciso
serem batizados de novo, por ignorarem a existência do Espírito Santo, como dizem Jerônimo e
Ambrósio. Ora, certos receberam o batismo de João, que tinham conhecimento pleno da Trindade.
Logo, não deviam receber de novo o batismo de Cristo.

5. Demais. — Aquilo do Apóstolo: Esta é a palavra da fé que pregamos - diz a Glosa de Agostinho: Donde
tira a água essa virtude tão maravilhosa de purificar à coração, ao mesmo tempo que lava o corpo,
senão por efeito da palavra, não precisamente porque pronunciada, mas porque crida? Por onde, é
claro que a virtude do batismo depende da fé. Ora, a forma do batismo de João simbolizava a fé com a
qual somos batizados, conforme àquilo do Apóstolo: João batizou ao povo com batismo de penitência,
dizendo: Que cressem naquele que havia de vir depois dele, isto é, em Jesus. Logo, parece não era
necessário os que receberam o batismo de João terem que receber de novo o de Cristo.
Mas, em contrário, Agostinho: Os que receberam o batismo de João era preciso receberem depois o de
Cristo.

SOLUÇÃO. — Segundo a opinião do Mestre das Sentenças, os que receberam o batismo de João,
ignorando, a existência do Espírito Santo, mas pondo a esperança nesse batismo, receberam depois o
batismo de Cristo; mas os que não punham a sua esperança no batismo de João e criam no Pai, no Filho
e no Espírito Santo, não foram batizado o depois, mas pela imposição das mãos feitas sobre eles pelos
apóstolos, receberam o Espírito Santo. E isto é por certo verdade, quanto à primeira parte, confirmado
por muitas autoridades. Mas, a segunda arte dessa afirmação é de todo irracional. - Primeiro, porque o
batismo de João não conferia a graça nem imprimia caráter, mas era só em água como ele próprio o diz.
Por isso, a fé ou a esperança que o batizado tivesse em Cristo não podia suprir essa falta. - Segundo,
porque quando num sacramento se omite o que faz essencialmente parte dele, não só há necessidade
de suprir essa omissão, mas é mister tornar a ministrar de novo o sacramento. Ora, o batismo de Cristo
essencialmente exigia fosse ministrado, não só em água, mas no Espírito Santo, conforme àquilo do
Evangelho: Quem não renascer da água e do Espírito Santo não pode entrar no reino de Deus. Por onde,
aos que só pela água receberam o batismo de João, não era preciso suprir o que lhes faltava, de modo
que lhes fosse conferido o Espírito Santo pela imposição das mãos, mas deviam de novo e totalmente
ser batizados na água e no Espírito Santo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho, houve outro batismo além do João,
por que estenão ministrava o batismo de Cristo, mas o seu. Mas, o que fosse conferido por Pedro ou
ainda por Judas, esse era de Cristo. Por isso, os que Judas batizou não precisavam de novo batismo;
pois, o batismo é tal qual foi instituído por quem tinha poderes para fazê-lo, em nada dependendo a sua
essência daquele que o ministra. Por isso também os batizados de Filipe diácono, que ministrava o
batismo de Cristo, não foram de novo batizados, mas receberam dos Apóstolos a imposição das mãos;
assim como os batizados pelos sacerdotes são confirmados pelos bispos.

RESPOSTA À SEGUNDA. — Como diz Agostinho, entendemos que os discípulos de Cristo foram
batizados, quer pelo batismo de João, como alguns pensam, quer, o que é mais crível, pelo batizado de
Cristo; pois, não podia deixar de regular o ministério do batismo, dando aos já batizados o poder de
batizar os outros, aquele que se não dedignou de lavar os pés aos seus discípulos, para dar-lhes maior
exemplo de humildade.

RESPOSTA À TERCEIRA. — Como ensina Crisóstomo, o ter Cristo a João que dizia - Eu sou o que devo ser
batizado por ti, respondido - Deixa por ora - mostra que depois Cristo batizou a João. E refere que tal
está claramente escrito em certos livros apócrifos. Mas é certo, como ensina Jerônimo, que assim como
Cristo foi batizado na água por João, assim João devia ser batizado por Cristo no Espírito.

RESPOSTA À QUARTA. — A causa total, desses tais terem sido batizados depois de haverem recebido o
batismo de João, não foi o desconhecerem o Espírito Santo, mas o não terem recebido o batismo de
Cristo.

RESPOSTA À QUINTA. — Como diz Agostinho, os nossos sacramentos são os sinais da graça presente; ao
passo que os da lei antiga eram os da graça futura. Por onde, o fato mesmo de João batizar, em nome
do que devia vir, prova que não conferia obatismo de Cristo, que é um sacramento da lei nova.