# Questão 10: Da ciência da beatitude da alma de Cristo
Em seguida devemos tratar de cada uma das referidas ciências. Mas, como já tratamos da ciência divina
na Primeira Parte, resta agora tratar das outras três. Primeiro, da ciência da beatitude. Segundo, da
ciência infusa. Terceiro, da ciência adquirida.
Mas como, da ciência da beatitude, consistente na união de Deus, já dissemos muito na Primeira Parte,
por isso agora só devemos tratar do que propriamente pertence à alma de Cristo.
Por onde, nesta questão discutem-se quatro artigos:

## Art. 1 — Se a alma de Cristo contemplava e contempla o Verbo, ou a essência divina.
O primeiro discute-se assim. — Parece que a alma de Cristo contemplava e contempla o Verbo, ou a
essência divina.
1 — Pois, diz Isidoro que a Trindade é conhecida só de si e do homem assumido, Logo, o homem
assumido participa, com a santa Trindade, daquele conhecimento que ela tem de si e só a ela é próprio :
Ora, tal é o conhecimento da visão beatífica. Logo, a alma de Cristo contempla a divina essência.

2. Demais. — Maior união é a com Deus pelo seu ser pessoal que pela visão. Ora, como Damasceno diz,
toda a divindade, na unidade de Pessoas, está unida à natureza humana em Cristo. Logo, com maior
razão toda a natureza divina é contemplada pela alma de Cristo. E, assim, parece que a alma de Cristo
contemplava a divina essência.

3. Demais. — O que convém ao Filho de Deus por natureza, ao Filho do Homem lhe convém pela graça,
com diz Agostinho. Ora, contemplar a divina essência convém ao Filho de Deus por natureza. Logo,
convém ao Filho do Homem pela graça. E assim, parece que a alma de Cristo contemplava, pela graça, o
Verbo.
Mas, em contrário, diz Agostinho; O que se contempla é para si finito. Ora, a essência divina não é finita
relativamente à alma de Cristo, pois, a esta excede em infinito. Logo, a alma de Cristo não contempla o
Verbo.

SOLUÇÃO. — Como do sobredito resulta, a união das naturezas na pessoa de Cristo se fez de modo tal
que a propriedade de uma e outra natureza permaneceu inconfusa; de maneira que o incriado
permaneceu incriado e o criado ficou dentro dos limites da criatura, como diz Damasceno, Ora, é
impossível uma criatura compreender a divina essência, como dissemos na Primeira Parte, porque o
infinito não pode ser compreendido pelo finito. Logo devemos concluir que a alma de Cristo de nenhum
modo compreende a divina essência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem assumido se acha associado com a divina
Trindade, no seu conhecimento, não em razão da compreensão, mas, de um certo excelentíssimo
conhecimento superior ao das outras criaturas.

RESPOSTA À SEGUNDA. — Nem mesmo pela união segundo o ser pessoal a natureza humana
compreende o Verbo de Deus ou a natureza divina, a qual, embora estivesse toda unida à natureza
humana na pessoa una do Filho, não era contudo a virtude total da divindade, quase circunscrita pela
natureza humana. Donde o dizer Agostinho; Quero que saibas que a doutrina cristã não ensina que Deus
se revestiu da carne humana de maneira a renunciar aos cuidados do governo universal, ou a tê-lo
perdido, ou a tê-la referido ao seu frágil corpo, concentrando-o nele por assim dizer. Semelhantemente,
a alma de Cristo vê toda a essência de Deus; não a compreende, porém, pela não ver totalmente, isto é,
de tão perfeita maneira como ela se oferece à visão, conforme expusemos na Primeira Parte.

RESPOSTA À TERCEIRA. — As palavras referidas de Agostinho devem entender-se da graça de união,
pela qual, tudo o atribuído à natureza divina do Filho de Deus o é ao Filho do Homem, por causa da
identidade do suposto. E, assim sendo, podemos, verdadeiramente dizer que o Filho do Homem
compreende a essência divina, não com a sua alma, mas, pela sua natureza divina. Por cujo modo
também podemos dizer que o Filho do Homem é criador.

## Art. 2 — Se a alma de Cristo conhece todas as coisas no Verbo.
O segundo discute-se assim. — Parece que a alma de Cristo não conhece todas as coisas no Verbo.
1 - Pois, diz o Evangelho; A respeito porém deste dia ninguém sabe quando há de ser nem os anjos do
céu, nem o Filho, mas só o Pai. Logo, não conhece todas as coisas no Verbo.

2. Demais. — Quanto mais perfeitamente alguém conhece um princípio tanto mais coisas conhece nesse
princípio. Ora, Deus vê mais perfeitamente a sua essência, que a vê a alma de Cristo. Logo, conhece
mais coisas no Verbo, que a alma de Cristo. Logo, a alma de Cristo não conhece todas as coisas no
Verbo.

3. Demais. — A extensão da ciência se mede pelo número de objetos que ela abrange. Se, pois, a. alma
de Cristo conhecesse no Verbo tudo o que o Verbo conhece, resultaria que a ciência da alma de Cristo
havia de igualar à ciência divina, isto é, o criado igualaria o incriado; o que é impossível.
Mas, em contrário, àquilo do Apocalípse. — Digno é o cordeiro, que foi morto, de receber a virtude e a
sabedoria — diz a Glosa: isto é, o conhecimento de todas as causas.

SOLUÇÃO. — Quando se pergunta se Cristo conhece todas as coisas no Verbo, devemos notar que a
expressão — todas as coisas — pode-se entender em dois sentidos. Num, o próprio, abrange todas as
coisas que de qualquer modo existem, existirão ou existiram; ou que foram feitas, ditas ou pensadas por
qualquer e em qualquer tempo. E então, devemos afirmar, que a alma de Cristo conhece todas as
causas no Verbo. Pois, cada intelecto criado conhece no Verbo, não todas as causas absolutamente
falando; mas tanto mais quanto mais perfeitamente vê no Verbo. Mas, nenhum intelecto de bem-
aventurado deixa de conhecer no Verbo tudo o que lhe concerne. Ora, a Cristo e à sua dignidade
concernem de certo modo todas as causas, enquanto que tudo está sujeito a ele, como diz o Apóstolo. E
também ele, no dizer do Evangelho, foi constituído por Deus juiz de todas as coisas, porque é Filho do
Homem. E portanto, a alma de Cristo conhece no Verbo tudo o que existe, em qualquer tempo, e
também os pensamentos dos homens, dos quais é juiz. Por isso, o dito do evangelista: Ele bem sabia por
si mesmo o que havia no homem, pode entender-se não só da ciência divina, mas também da ciência
que a sua alma tem no Verbo.
Noutro sentido, todas as coisas é uma expressão susceptível de sentido mais lato, abrangendo não só
todas as coisas atuais num tempo qualquer, mais ainda todas as potências, que nunca serão atualizadas.
— Ora, destas, certas dependem só do poder de Deus. E tais a alma de Cristo não as conhece a todas no
Verbo. Pois, o contrário seria compreender tudo o que Deus pode fazer; o que seria compreender o
poder divino e, portanto, a essência divina; pois, toda virtude se conhece conhecendo o que ela pode
fazer. — Mas há outras causas que estão no poder, não só de Deus, mas também da criatura. E essas a
alma de Cristo as conhece a todas no Verbo. Pois, compreende, no Verbo, a essência de toda criatura; e
por consequência, a potência, a virtude e tudo o que está no poder da criatura.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ario e Eunómio entenderam essas palavras, não quanto
à ciência da alma, que não admitiam em Cristo, como dissemos; mas, quanto ao conhecimento divino
do Filho, do qual ensinavam ser menor do que o Pai, pela ciência. — Mas esta Doutrina não pode
manter-se. Pois, pelo Verbo de Deus todas as coisas foram feitas, como diz o Evangelho; e, entre todas,
também por ele foram feitos todos os tempos. Logo, nada do feito por ele havia, que ele ignorasse. - Por
onde, diz-se que ignora o dia e a hora do juízo, pelo não dar a conhecer; assim, interrogado sobre isso
pelos Apóstolos, não lhes quis revelá-lo, Como, ao contrário, se lê na Escritura: Agora conheci que temes
a Deus, isto é, agora te fiz conhecer. E se diz que o Pai conhece, por ter transmitido ao Filho esse
conhecimento. Por onde, a expressão da Escritura — só o Pai — dá a entender que o Filho conhece, não
só pela sua natureza divina, mas também pela humana. Pois, como argui Crisóstomo, se a Cristo lhe foi
dado saber, enquanto homem, como deve julgar — o que é mais; com muito maior razão também lho
foi o tempo do juízo — que é menos —Orígenes, porém, expõe esse lugar, de Cristo, quanto ao seu
corpo, que é a Igreja, a qual ignora esse referido tempo. — Mas, certos dizem que essa expressão se
deve entender do filho de Deus adotivo e não, do natural.

RESPOSTA À SEGUNDA. — Deus conhece a sua essência mais perfeitamente que a conhece a alma de
Cristo, pela compreender. E portanto conhece todas as coisas, não só as que atualmente existem em
qualquer tempo — ao que chamamos ciência de visão; mas também conhece a todas, as que pode fazer,
ao que se chama conhecer pela simples inteligência, como se estabeleceu na Primeira Parte. Portanto, a
alma de Cristo conhece todas as coisas que Deus em si mesmo conhece pela ciência de visão; mas não,
todas as que Deus conhece em si mesmo pela simples ciência da inteligência. E assim, Deus, em si
mesmo, conhece mais coisas, que a alma de Cristo.

RESPOSTA À TERCEIRA. — A extensão da ciência não se funda só no número das coisas conhecidas, mas
também na clareza do conhecimento. Embora, pois, a ciência da alma de Cristo que tem no Verbo, seja
igual à ciência de visão que Deus tem em si mesmo, quanto ao úmero das coisas conhecidas, contudo a
ciência de Deus excede infinitamente, quanto à clareza do conhecimento, a ciência da alma de Cristo.
Porque a luz incriada do intelecto divino excede infinitamente a luz criada, qualquer que ela seja,
recebida na alma de Cristo. não só quanto ao modo de conhecer, mas também quanto ao número das
coisas conhecidas, conforme dissemos.

## Art. 3 — Se a alma de Cristo pode conhecer infinitas coisas no Verbo.
O terceiro discute-se assim. — Parece que a alma de Cristo não pode conhecer infinitas coisas no
Verbo.
1 — Pois, repugna à noção do infinito o ser ele conhecido; assim, como diz Aristóteles, infinita é a
quantidade a que sempre se lhe pode acrescentar. Ora, é impossível separar a definição, do definido,
porque então seria contraditório o existirem simultaneamente. Logo, é impossível a alma de Cristo
conhecer coisas infinitas.

2. Demais. — A ciência de coisas infinitas é infinita. Ora, a ciência da alma de Cristo não pode ser infinita,
pois, sendo criatura, a sua capacidade é finita. Logo, a alma de Cristo não pode conhecer coisas infinitas.

3. Demais. — Nada pode ser maior que o infinito. Ora, a ciência divina, absolutamente falando, abrange
mais coisas que a da alma de Cristo, como se disse. Logo, a alma de Cristo não conhece coisa infinitas.
Mas, em contrário. — A alma de Cristo conhece todo o seu poder e tudo o a que ele se estende. Ora,
pode ela purificar de pecados infinitos, segundo o Evangelho: Ele é a propiciação pelos nossos pecados;
e não somente pelos nossos, mas também pelos de todo o mundo. Logo, a alma de Cristo conhece
coisas infinitas.

SOLUÇÃO. — A ciência só pode ter por objeto o ser, porque o ser e a verdade se convertem. Ora, um
ente pode ser considerado a dupla luz: absolutamente, quando atual; ou relativamente, quando
potencial. E como um ser é conhecido enquanto atual e não enquanto potencial, segundo o ensina
Aristóteles, a ciência tem por objeto primário e principal o ser atual e secundariamente, o ser potencial,
não cognoscível em si mesmo, mas na medida em que o é o ser em cuja potência existe. Ora, quanto à
primeira modalidade da ciência, a alma de Cristo não conhece coisas infinitas. Pois; não são infinitas em
ato, em qualquer tempo; porque a estado de geração e de corrupção não, dura infinitamente. Por onde,
é certo o número tão só dos seres não sujeitos à geração e a corrupção, como dos susceptíveis de uma e
de outra. — Mas, quanto à segunda modalidade da ciência, a alma de Cristo conhece coisas infinitas no
Verbo. Pois, sabe, como se disse, tudo o que está na potência da criatura. Ora, como na potência da
criatura então coisas infinitas, deste modo conhece coisas infinitas, quase por uma certa ciência de
simples inteligência, não porém pela de visão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O infinito, como dissemos na primeira Parte, é
susceptível de dupla acepção. — Primeiro, em razão da forma. E então o infinito o é negativamente; isto
é, é a forma ou o ato não limitado pela matéria ou por um sujeito em que ela seja recebida. E esse
infinito, é, em si mesmo, cognoscível por excelência, por causa da perfeição do ato, embora não seja
compreensível pela potência finita da criatura, e diremos, nesse sentido que e Deus é infinito. Ora, tal
infinito a. alma de Cristo conhece, embora não o compreenda. — Noutro sentido, o infinito o é em razão
da matéria. E esse é o chamado infinito privativo; isto é, por não ter a forma que lhe era natural- tivesse,
E tal é o infinito quantitativo, desconhecido por natureza, por ser quase a matéria privada da forma,
como diz Aristóteles, ora, todo conhecimento é pela forma ou pelo ato. Por onde, se esse infinito
devesse ser conhecido ao modo do objeto conhecido seria impossível conhecê-lo. Pois, o seu modo é
serem consideradas as suas partes, uma depois da outra, como diz Aristóteles. E, neste sentido, é
verdade que quem lhe enumera as partes, isto é, tomando uma depois de outra, sempre lhe poderá
acrescentar outra. Ora, como as coisas materiais podem ser consideradas pelo intelecto imaterialmente,
e as coisas múltiplas, uníficadamente, assim também coisas infinitas o intelecto pode concebê-las, não
como infinitas, mas como finitas; de modo que, coisas em si mesmas infinitas sejam finitas para o
intelecto que a conhece. E, deste modo, a alma de Cristo conhece coisas infinitas, isto é, enquanto as
conhece, não considerando-as uma por uma mas numa certa unidade; por exemplo, numa criatura, em
cuja potência existem em número infinito, é principalmente no Verbo.

RESPOSTA À SEGUNDA. — Nada impede ser o infinito, a uma luz, finito, a outra; como se, na ordem da
quantidade, imaginemos uma superfície infinita em comprimento e finita em largura. Assim, pois, se
existissem infinitos homens, em número, teriam certamente a infinidade, de algum modo, isto é, quanto
à multidão; mas não a teriam quanto a ideia da essência, porque toda essência seria limitada pela ideia
de uma só espécie. Mas, o ser absolutamente infinito, pela sua essência mesma, é Deus, como
demonstramos na Primeira Parte. Ora, o objeto próprio do intelecto é a quididade, como diz Aristóteles,
na qual se inclui a ideia de espécie. Assim, portanto, a alma de Cristo, por ter uma capacidade finita,
atinge certamente o infinito absoluta e essencialmente, que é Deus, mas não o compreende, como
dissemos. Mas o infinito potencial das criaturas a alma de Cristo pode compreendê-lo; por se lhe referir
pela ideia de essência por onde não tem infinidade. Pois, também o nosso intelecto intelige o universal,
isto é, a natureza genérica e específica que tem de certo modo infinidade, por poder ser predicado de
infinitos seres.

RESPOSTA À TERCEIRA. — O infinito a todas as luzes não pode ser senão único. Donde o dizer o Filósofo
que, tendo o corpo dimensão em todos os sentidos, é impossível haver varias corpos infinitos. Mas, se
um corpo fosse infinito num só sentido, nada impediria que existissem vários corpos infinitos; assim, se
concebêssemos várias linhas infinitas em comprimento, tiradas ao longo de uma superfície finita em
largura. Ora, não sendo o infinito nenhuma substância, mas um acidente das coisas chamadas infinitas,
como diz Aristóteles; assim como o infinito se multiplica conforme a diversidade dos seus sujeitos, assim
há de a propriedade do infinito necessariamente multiplicar-se, de modo a convir em particular a cada
um desses sujeitos. Ora, uma propriedade do infinito é a de ser maior que qualquer ser. Assim, pois,
considerada uma linha como infinita, nela nada é maior que a sua infinidade; semelhantemente, se
considerarmos qualquer das outras linhas infinitas, é claro que de cada uma delas são as partes infinitas.
Logo e necessariamente, em todos esses infinitos nada há de maior, numa das referidas linhas; contudo,
na outra linha e na terceira, haverá várias partes também infinitas, além destas, O que também vemos
se dar com os números; pois, as espécies dos números pares são infinitas e, semelhantemente, as dos
números ímpares; e contudo os números pares e os impares são mais que os pares. Donde devemos
concluir, que nada há maior que o infinito em absoluto e a todos os respeitos; mas, quanto ao infinito
determinado segundo certo ponto de vista, nada há maior que ele na sua ordem; mas, podemos
conceber algo maior que ele, fora dessa ordem. E assim, deste modo, infinitas coisas estão no poder da
criatura; contudo, mais estão no poder de Deus que no da criatura. Semelhantemente, a alma de Cristo
conhece coisas infinitas pela ciência de simples inteligência; Deus porém conhece mais coisas por esse
modo de inteligir.

## Art. 4 — Se a alma de Cristo vê o Verbo mais perfeitamente que qualquer outra criatura.
O quarto discute-se assim. — Parece que a alma de Cristo não vê o Verbo mais perfeitamente que
qualquer outra criatura.

1. — Pois, a perfeição do conhecimento depende do modo de conhecer; assim, mais perfeito é o
conhecimento obtido por meio do silogismo demonstrativo, que o obtido por meio do silogismo
dialético. Ora, todos os bem-aventurados contemplam o Verbo imediatamente na sua mesma essência
divina, como se disse na Primeira Parte. Logo, a alma de Cristo não vê o Verbo mais perfeitamente que
qualquer outra criatura.

2. Demais. — A perfeição da visão não exclui a potência visiva. Ora, a potência, da alma racional, qual é
a alma de Cristo, é inferior à potência intelectiva do anjo, como está claro em Dionísio. Logo, a alma de
Cristo não vê o Verbo mais perfeitamente que os anjos.

3. Demais. — Deus vê o seu Verbo de maneira infinitamente mais perfeita que o vê a alma de Cristo.
Ora, há infinitos graus médios entre o pelo qual Deus vê o seu Verbo, e o pelo qual o contempla a alma
de Cristo. Logo, não devemos afirmar que a alma de Cristo vê o Verbo mais perfeitamente, ou a essência
divina, que qualquer outra criatura.
Mas, em contrário, o Apóstolo: Deus pôs Cristo à sua mão direita no céu, sobre todo Principado e
Potestade e Virtude e Dominação e sobre todo o nome que se nomeia, não só neste século mas ainda
no futuro. Ora, na glória celeste tanto mais superior é um quanto mais perfeitamente conhece a Deus.
Logo, a alma de Cristo contempla a Deus mais perfeitamente que qualquer outra criatura.

SOLUÇÃO. — A visão da essência divina convém a todos os bem-aventurados pela participação da luz
derivada para eles da fonte do Verbo de Deus, segundo a Escritura: A fonte da sabedoria é o Verbo de
Deus nas alturas. Ora, a esse Verbo de Deus mais proximadamente está unida a alma de Cristo, que o
está pessoalmente ao Verbo, que qualquer outra criatura. Por isso; mais plenamente recebe a influência
do lume, no qual Deus é contemplado pelo próprio Verbo, que qualquer outra criatura. Portanto, vê
mais perfeitamente que todas as outras criaturas a Verdade primeira, que é a essência de Deus. Donde
o dizer o Evangelho: Nós vimos a sua glória, a sua glória como de Filho unigênito do Pai, cheio não só de
graça, mas também de verdade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A perfeição do conhecimento, relativamente ao objeto
conhecido, depende de um meio termo; mas relativamente ao sujeito que conhece, depende da
potência ou do hábito. Donde vem que, mesmo entre os homens, por um meio termo um conhece certa
conclusão mais perfeitamente que outro. E deste modo a alma de Cristo, mais abundantemente repleta
do lume, mais perfeitamente conhece a essência divina que os outros bem-aventurados, embora todos
contemplem a essência de Deus, em si mesma,

RESPOSTA À SEGUNDA. — A visão da essência divina excede a capacidade natural de qualquer criatura,
como se disse na Primeira Parte. Por isso os seus graus se fundem mais na ordem da graça, em que
Cristo é excelentíssimo, que na ordem da natureza, pela qual a natureza angélica é superior à humana.

RESPOSTA À TERCEIRA. — O que dissemos, da graça que não pode haver maior que a graça de Cristo
relativamente à união com o Verbo, também agora devemos dizer da perfeição da divina contemplação;
embora, absolutamente falando, possa haver um grau mais sublime, quanto à infinidade da divina
potência.