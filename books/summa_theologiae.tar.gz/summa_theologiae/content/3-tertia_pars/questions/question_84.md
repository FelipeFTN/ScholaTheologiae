# Questão 84: Do sacramento da penitência
Na primeira questão discutem-se dez artigos:

## Art. 1 — Se a penitência é um sacramento.
O primeiro discute-se assim. — Parece que a penitência não é um sacramento.

1. — Pois, Gregório (Isidoro) diz e está nas Decretais: Os sacramentos são - o batismo, o crisma, o corpo
e o sangue de Cristo; e se chamam sacramentos porque, oculta sob elementos corpóreos, a virtude
divina opera invisivelmente a salvação. Ora, tal não se dá com a penitência, porque a virtude divina não
obra a salvação, por meio dela, servindo-se de quaisquer elementos corporeos. Logo, a penitência não é
um sacramento.

2. Demais. — Os sacramentos da Igreja são dispensados pelos ministros de Cristo, segundo aquilo do
Apóstolo: Os homens devem-nos considerar como uns ministros de Cristo, e como uns dispensa dores
dos mistérios de Deus. Ora, a penitência não é dispensada pelos ministros de Cristo, mas é inspirada aos
homens interiormente, por Deus, segundo aquilo da Escritura: Depois que me converteste, fiz
penitência. Logo, parece que a penitência não é um sacramento.

3. Demais. — Nos sacramentos, de que já tratamos, temos que distinguir o puro sacramento, a realidade
e o sacramento, e a simples realidade, como do sobredito resulta. Ora, nada disto há na penitência.
Logo, a penitência não é sacramento.
Mas, em contrário, como o batismo é conferido para purificar do pecado, assim também a penitência.
Por isso Pedro disse a Simão: Faze penitência desta tua maldade. Ora, o batismo é um sacramento,
como se estabeleceu. Logo, pela mesma razão, a penitência.

SOLUÇÃO. — Como Gregório (Isidoro) diz, no capitulo supra-citado, o sacramento consiste numa
cerimônia feita de modo tal, que nela recebamos simbolicamente o que devemos receber santamente.
Ora, é manifeste que na penitência, o ato praticado tem um significado santo, tanto da parte do pecado
penitente, como da parte do sacerdote que absolve. Pois, o pecador penitente, pelo que faz e diz,
mostra abandonar o pecado, no seu coração; semelhantemente, o sacerdote, pelo que faz e diz em
relação ao penitente, significa a obra de Deus, de remitir os pecados. Por onde, é manifesto que a
penitência praticada na Igreja é um sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por coisas corpóreas se entendem, em sentido lato,
também os atos exteriores sensíveis, que exercem neste sacramento a mesma função que a água no
batismo ou o crisma na confirmação. Ora, devemos considerar que nos sacramentos dispensa dores de
uma graça excelente, superior a toda a capacidade dos atos humanos, usa-se de uma certa matéria
corpórea externa. Assim no batismo, que dá a plena remissão dos pecados, quanto à culpa e quanto à
pena; na confirmação, que confere a plenitude do Espírito Santo; e na extrema-unção, que confere a
perfeita saúde espiritual, proveniente da virtude de Cristo, quase como de um principio extrínseco. Por
onde, se há atos humanos em tais sacramentos, não lhes pertencem à essência, servindo apenas de nos
dispor para eles. Nos sacramentos porém, que produzem um efeito correspondente aos atos humanos,
os próprios atos humanos sensíveis desempenham o papel de matéria; tal o caso da penitência e do
matrimônio. Assim como, nos remédios corpóreos, recorremos a certas coisas corpóreas, como os
emplastros e os leituários; e a certos atos curativos, como determinados exercícios.

RESPOSTA À SEGUNDA. — Nos sacramentos que têm matéria corpórea, é necessário seja ela aplicada
pelo ministro da Igreja, representante da pessoa de Cristo, em sinal de que a excelência da virtude, que
opera no sacramento, vem de Cristo. Ora, no sacramento da penitência, como dissemos, os atos
humanos desempenham o papel de matéria, provenientes de uma inspiração interna. Por isso, a
matéria não é aplicada pelo ministro, mas por Deus, que age interiormente; o ministro dá somente o
complemento do sacramento, absolvendo o penitente.

RESPOSTA À TERCEIRA. — Também na penitência podemos distinguir o que é só sacramento, a saber,
os atos praticados tanto pelo pecador penitente, como também pelo sacerdote absolvente. A realidade
e o sacramento é a penitência interna do pecador. Só realidade, e não sacramento é a remissão dos
pecados. Desses elementos, o primeiro, tomado total e simultaneamente, é a causa do segundo; e o
primeiro com o segundo são a causa do terceiro.

## Art. 2 — Se os pecados são a matéria própria deste sacramento.
O segundo discute-se assim. — Parece que os pecados não são a matéria própria deste sacramento.

1. — Pois, nos outros sacramentos, a matéria é santificada por certas palavras proferidas; e, santificada,
produz o efeito do sacramento. Ora, os pecados, contrariando ao efeito do sacramento, que é a graça
remitente do pecado, não podem ser santificados. Logo, os pecados não são a matéria própria deste
sacramento.

2. Demais. — Agostinho diz: Ninguém pode começar vida nova senão arrependendo-se da vida passada.
Ora, a vida passada inclui não só os pecados, como também certas penalidades. Logo, os pecados não
são a matéria própria da penitência.

3. Demais. — Dos pecados, um é o original, outros são mortais e outros, veniais. Ora, o sacramento da
penitência não se ordena contra o pecado original, delido pelo batismo; nem contra o pecado mortal,
perdoado pela confissão do pecador; nem enfim contra o venial, perdoado quando batemos no peito,
tomamos água benta ou praticamos atos semelhantes. Logo, os pecados não são a matéria própria da
penitência.
Mas, em contrário, o Apóstolo: Não fizeram penitência da imundície e fornicação e desonestidade que
cometeram.

SOLUÇÃO. — Há duas sortes de matéria – a próxima e a remota; assim, a matéria próxima da estátua é
o metal; a remota, a água. Ora como dissemos, a matéria próxima deste sacramento são os pecados de
que se arrepende que confessa e pelos quais satisfaz. Donde se conclui que a matéria remota da
penitência são os pecados, não enquanto queridos intencionalmente, mas enquanto devem ser
detestados e delidos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe, quanto à matéria próxima. do
sacramento.

RESPOSTA À SEGUNDA. — A vida passada e mortal é o objeto da penitência, não em razão da pena,
mas, da culpa anexa.

RESPOSTA À TERCEIRA. — Num certo sentido, a penitência tem como sua matéria todo gênero de
pecados; mas não do mesmo modo. - Assim, a matéria própria e principal da penitência é o pecado
mortal atual. Própria, porque propriamente nos penitenciamos do que voluntariamente cometemos.
Principal, porque este sacramento foi instituído para delir o pecado mortal. - Os pecados veniais
constituem matéria própria da penitência, enquanto voluntariamente os praticamos; mas o sacramento
não foi instituído para os ter como matéria principal. - Quanto ao pecado original, nem é matéria
principal da penitência, pois este sacramento não se ordena principalmente contra ele, mas antes o
batismo; nem matéria própria, porque o pecado original não o praticamos por nossa vontade, salvo
considerando-se como nossa a vontade de Adão, ao modo de falar do Apóstolo, quando diz: No qual
todos pecaram. Mas, tomando-se a penitência em sentido lato, pela detestação de atos passados,
podemos falar em penitência do pecado original, como o diz Agostinho.

## Art. 3 — Se esta é a forma deste sacramento: Eu te absolvo.
O terceiro discute-se assim. — Parece que esta não é a forma deste sacramento: Eu te absolvo.

1. — Pois, as formas dos sacramentos provêm da instituição de Cristo e do uso da Igreja. Ora, não lemos
que Cristo tivesse instituído esta forma. Nem está no uso comum; ao contrário, em certas absolvições
públicas na Igreja - como a da Prima, da Completas e da Ceia do Senhor - o absolvente não fala no modo
indicativo, dizendo - Eu te absolvo, mas de modo deprecativo, dizendo - Que Deus omnipotente se
amerceie de vós, ou, Deus omnipotente vos dê a absolvição. Logo, esta não é a forma deste sacramento
- Eu te absolvo.

2. Demais. — Leão Papa (I) diz: O perdão de Deus não no podemos obter senão pelas súplicas dos
sacerdotes. Ora, refere-se ao perdão que Deus concede aos penitentes. Logo, a forma deste sacramento
deve ser de modo deprecativo.

3. Demais. — É o mesmo absolver do pecado e perdoá-lo. Ora, só Deus pode perdoar o pecado, que só
pode purificar-nos interiormente dele, como diz Agostinho. Logo, parece que só Deus pode absolver do
pecado. Portanto, o sacerdote não deve dizer - Eu te absolvo, como não diz - Eu te perdôo os pecados.

4. Demais. — Assim como o Senhor deu aos discípulos o poder de absolver dos pecados, também lhes
deu o poder de curar as enfermidades, de expulsar os demônios e sanar as doenças. Ora, para curar os
enfermos os Apóstolos não pronunciavam as palavras - Eu te curo; mas O Senhor Jesus Cristo te cure.
Logo, parece que os sacerdotes, recebendo um poder outorgado por Cristo aos Apóstolos, não devem
usar da fórmula - Eu te absolvo; mas - Cristo te dê a absolvição.

5. Demais. — Certos, usando desta forma, assim a completam: Eu te absolvo, isto é, eu te declaro
absolvido. Ora, isto o sacerdote não o pode fazer, se Deus não lh'o revelar. Por isso, como lemos no
Evangelho, antes de Cristo ter dito a Pedro - Tudo o que ligares sobre a terra, etc., disse-lhe: Bem-
aventurado és, Simão, filho de João, porque não foi a carne e sangue quem te revelou, mas sim meu Pai,
que está nos céus. Logo, parece que o sacerdote, a quem não foi feita revelação, diz presunçosamente -
Eu te absolvo mesmo se acrescentar - isto é, te declaro absolvido.
Mas, em contrário, assim como o Senhor disse aos discípulos - Ide e ensinai a todas as gentes,
batizando-as, etc., assim disse a Pedro: Tudo o que ligares. Ora, o sacerdote, fundado na autoridade
daquelas palavras de Cristo, diz - Eu te batizo. Logo, apoiado na mesma autoridade, deve dizer, neste
sacramento - Eu te absolvo.

SOLUÇÃO. — A perfeição de todo ser se lhe atribui à forma. Ora, como dissemos este sacramento se
completa pelas palavras do sacerdote. Por onde e necessariamente, o concernente ao penitente -
palavras ou atos, são de certo modo a matéria deste sacramento; e o que faz o sacerdote exerce a
função de forma. Ora, como os sacramentos da lei nova realizam o que figuram, segundo dissemos, há
de a forma do sacramento significar o que faz o sacramento, em proporção com a matéria sacramental.
Por isso, a forma do batismo é - Eu te batizo; e a da confirmação - Eu te assinalo com o sinal da cruz e te
confirmo com o crisma da salvação, porque esses sacramentos se consumam pelo uso da matéria. No
sacramento da Eucaristia porém, consistente na consagração mesma da matéria, é expressa a verdade
da consagração, quando o sacerdote diz: Isto é o meu corpo. Mas o sacramento da penitência não
consiste na consagração de matéria nenhuma nem no uso de qualquer matéria santificada; mas antes,
na remoção da matéria do pecado, enquanto que estes se consideram matéria da penitência, como do
sobredito se colhe. Ora, é essa remoção a expressa pelo sacerdote quando diz: Eu te absolvo. Pois, os
pecados são uns quase vínculos, segundo aquilo da Escritura: As suas mesmas iniqüidades prendem ao
ímpio e é apertado com as ataduras de seus pecados. Por onde é claro que esta é a convenientissima
forma deste pecado: Eu te absolvo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A fórmula em questão é tirada das próprias palavras que
Cristo disse a Pedro: Tudo o que ligares sobre a terra, etc. E dessa fórmula usa a Igreja na absolvição
sacramental. Quanto às absolvições dadas em público, não são sacramentais, mas antes, umas quase
orações ordenadas à remissão dos pecados veniais. Por isso, na absolvição sacramental não bastaria
dizer - Deus omnipotente se amerceie de ti, ou Deus te dê a absolvição e a remissão, porque com tais
palavras o sacerdote não significa ser dada a absolvição, mas pede que o seja. - O sacerdote porém
recita, antes da absolvição sacramental, as referidas orações, a fim de não ficar impedido o efeito do
sacramento por parte do penitente, cujos atos constituem a matéria deste sacramento, mas não, do
batismo nem da confirmação.

RESPOSTA À SEGUNDA. — As palavras de Leão devem entender-se relativamente à deprecação feita
antes da absolvição; mas não excluem a absolvição sacerdotal.

RESPOSTA À TERCEIRA. — Só Deus, pela sua autoridade, pode desatar do pecado e perdoar os pecados.
Os sacerdotes o fazem pelo seu ministério; isto é, enquanto as suas palavras operam instrumentalmente
neste sacramento, como também nos outros; pois, a virtude divina é a que obra interiormente em todos
os sinais sacramentais, quer sejam palavras quer causas, como do sobredito se colhe. Por isso, o Senhor
exprimiu uma e outra coisa, quando disse a, Pedro - Tudo o que desatares sobre a terra, etc.; e aos
discípulos - Aos que vós perdoardes os pecados, ser-lhes-ão perdoados. Por isso também o sacerdote
diz, antes, - Eu te absolvo, do que - Eu te perdôo os pecados. Porque está mais de acordo com as
palavras ditas pelo Senhor, dando o poder das chaves, em virtude do qual os sacerdotes absolvem. -
Mas como o sacerdote absolve na qualidade de ministro, convenientemente se acrescentam palavras
concernentes à primária autoridade de Deus, e são: Eu te absolvo em nome do Padre e do Filho e do
Espírito Santo; ou, por virtude da paixão de Cristo; ou, por virtude da paixão de Cristo; ou, por
autoridade de Deus, como o expõe Dionísio. Não sendo porém esse acréscimo determinado pelas
palavras de Cristo, como no batismo, por isso é deixado ao arbítrio do sacerdote.

RESPOSTA À QUARTA. — Aos Apóstolos não foi dado o poder de por si mesmos curarem os enfermos,
mas que estes fossem curados pelas orações deles. Foi-lhes porém conferido o poder de obrar
instrumental ou ministerialmente, nos sacramentos. Por onde, podem exprimir o seu ato, antes pelas
formas sacramentais, que curando doenças. No que nem sempre falam de modo deprecativo, mas às
vezes, no indicativo; assim, quando Pedro disse ao coxo - O que tenho isso te dou. Em nome de Jesus
Cristo levanta-te e anda.

RESPOSTA À QUINTA. — Esta exposição da fórmula - Eu te absolvo, isto é, te declaro absolvido, é em
parte verdadeira, mas não é completa. Porque os sacramentos da Lei Nova não só significam, mas
também realizam o que significam. Por onde, assim como o sacerdote quando batiza alguém, o declara
interiormente purificado, por palavras e por atos que não somente significam, mas produzem essa
purificação; assim também quando diz - Eu te absolvo, declara o penitente absolvido, não só
significativa, mas também efetivamente. - E não o faz como se agisse com incerteza. Pois, assim como os
outros sacramentos da lei nova produzem por si mesmos um efeito certo, em virtude da paixão de
Cristo, embora possa ele ficar impedido por quem recebe o sacramento, o mesmo se dá com a
penitência. Donde o dizer Agostinho: Não é vergonhosa nem difícil, depois de perpetrado, mas expiado
o adultério, a reconciliação dos cônjuges, quando, pelo poder das chaves do reino dos céus, não se tem
mais dúvida sobre a remissão dos pecados. Por onde, nem o sacerdote precisa de nenhuma revelação
especial, bastando-lhe a revelação geral da fé, pela qual são perdoados os pecados. Por isso se diz ter
sido feita a Pedro a revelação da fé. - Seria, pois, mais perfeita a exposição: Eu te absolvo, isto é, dou-te
o sacramento da absolvição.

## Art. 4 — Se a imposição das mãos do sacerdote é necessária neste sacramento.
O quarto discute-se assim. — Parece necessária neste sacramento a imposição das mãos do
sacerdote.

1. — Pois, diz o Evangelho: Porão as mãos sobre os enfermos e sararão. - Ora, os pecadores são doentes
espirituais, que recebem um bom estado espiritual, por este sacramento. Logo, é necessária, nele, a
imposição das mãos.

2. Demais. — Pelo sacramento da Penitência recuperamos o Espírito Santo, que perdemos. Por isso diz a
Escritura, da pessoa do penitente: Dá-me a alegria da tua salvação e conforta-me por meio do espírito
principal. Ora, o Espírito Santo é dado pela imposição pelas mãos. Assim, como o refere a Escritura, os
Apóstolos punham a mão sobre eles e recebiam o Espírito Santo. E o Evangelho: Foram apresentados ao
Senhor vários meninos, para lhes impor as mãos. Logo, neste sacramento deve fazer-se a imposição das
mãos.

3. Demais. — As palavras do sacerdote neste sacramento não têm maior eficácia, que nos outros. Ora,
nos outros não bastam as palavras do ministro, salvo acompanhadas de um ato exterior. Assim no
batismo é necessário as palavras do sacerdote - Eu te batizo, serem acompanhadas da ablução. Logo,
também quando o sacerdote diz - Eu te absolvo, é necessário pratique o ato de impor as mãos sobre o
penitente.
Mas, em contrário, o Senhor disse a Pedro: Tudo o que desatares sobre a terra, sem fazer qualquer
menção da imposição das mãos. E nem a fez quando disse a todos: Aos que vós perdoardes os pecados
ser-lhes-ão perdoados. Logo, este sacramento não requer a imposição das mãos.

SOLUÇÃO. — A imposição das mãos nos sacramentos da Igreja é feita para designar um abundante
efeito da graça, pela qual, os que recebem essa imposição, por uma certa semelhança se associam aos
ministros, que devem ter uma graça mais abundante. Por onde, a imposição das mãos se faz no
sacramento da confirmação, que confere a plenitude do Espírito Santo; e no sacramento da ordem, que
confere uma certa excelência de poder nos divinos mistérios. Donde o dizer o Apóstolo: Tornes a
acender o fogo da graça de Deus, que recebeste pela imposição das minhas mãos. Ora, o sacramento da
penitência não se ordena à consecução de nenhuma excelência de graça, mas à remissão dos pecados.
Por isso este sacramento não requer a imposição das mãos, como também não a requer o batismo, no
qual contudo é dada uma remissão mais plena dos pecados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa imposição das mãos não é sacramental, mas se
ordena a realização de um milagre; isto é, curar, pelo contato da mão de um homem santificado, uma
doença, mesmo corporal. Assim como lemos, do Senhor, que curava os enfermos impondo-lhes as
mãos; e que curou o leproso, pelo contato.

RESPOSTA À SEGUNDA. — Não é qualquer recepção do Espírito Santo que requer a imposição das
mãos; pois, também no batismo recebemos o Espírito Santo e contudo não há imposição de mãos. Mas
essa imposição é requerida quando recebemos a plenitude do Espírito Santo, o que se dá na
confirmação.

RESPOSTA À TERCEIRA. — Nos sacramentos que se consumam no uso da matéria, tem o ministro que
praticar um ato corpóreo sobre quem recebe o sacramento; talo caso do batismo, da confirmação e da
extrema-unção. Ora, este sacramento não consiste no uso de matéria nenhuma externa; mas, em lugar
da matéria estão os atos do penitente. Por onde, assim como na Eucaristia o sacerdote, pela só prolação
das palavras sobre a matéria, celebra o sacramento; assim também, as só palavras do sacerdote que
absolve o penitente conferem o sacramento da absolvição. E se algum ato corpóreo fosse necessário da
parte do sacerdote, não teria menos lugar o sinal da cruz, próprio da Eucaristia, que a imposição às
mãos, como sinal de que os pecados são perdoados pelo sangue da cruz de Cristo. E contudo não é isso
de necessidade neste sacramento, como não o é na Eucaristia.

## Art. 5 — Se este sacramento é necessário à salvação.
O quinto discute-se assim. — Parece que este sacramento não é necessário à salvação.

1. — Pois, àquilo da Escritura. - Os que semeiam em lágrimas etc., diz a Glosa: Não andes triste, se tens
boa vontade, com que se mede a paz. Ora, a tristeza é da essência da penitência, segundo aquilo do
Apóstolo: A tristeza que é segundo Deus produz para a salvação uma penitência estável. Logo, a boa
vontade sem a penitência basta à salvação.

2. Demais. — A Escritura diz: A caridade cobre todos os delitos. E a seguir: Os pecados purificam-se pela
misericórdia e pela fé. Ora, o fim deste sacramento é só purificar dos pecados. Logo, tendo caridade, fé
e misericórdia, podemos alcançar a salvação, mesmo sem o sacramento da penitência.

3. Demais. — Os sacramentos da Igreja começaram com a instituição de Cristo. Ora, como lemos no
Evangelho, Cristo perdoou a mulher adúltera, sem penitência. Logo, parece não ser a penitência
necessária à salvação.
Mas, em contrário, o Senhor disse: Se vós outros não fizerdes penitência, todos assim mesmo haveis de
acabar.

SOLUÇÃO. — De dois modos pode uma coisa ser necessária à salvação: absoluta e condicionalmente.
Absolutamente é necessário à salvação aquilo sem o que ela não pode ser alcançada; assim, a graça de
Cristo e o sacramento do batismo pelo qual renascemos em Cristo. Condicionalmente é necessário o
sacramento da penitência; não por certo a todos, mas aos que estão em pecado. Assim, diz a Escritura: E
tu, Senhor Deus dos justos, não fizeste a penitência para os justos - Abraão, Isaac e Jacó, nem para os
que te não ofenderam. - Ora, o pecado, quando tiver sido consumado, gera a morte, no dizer da
Escritura. Logo, é necessário, para a sua salvação, que o pecador seja purificado do pecado. O que não
pode ser sem o sacramento da penitência, no qual obra a virtude da paixão de Cristo pela absolvição do
sacerdote simultânea com a confissão do pecador, que coopera com a graça para delir o pecado, como
o diz Agostinho: Quem te criou sem ti não te justificará sem ti. Por onde é claro que o sacramento da
penitência é necessário à salvação, depois do pecado; assim como o remédio é necessário ao corpo de
quem caiu em grave doença.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A glosa citada deve ser entendida de quem tem uma boa
vontade sem a interpolação causada pelo pecado; pois, essa nenhuma causa tem para tristezas. Mas,
quando a boa vontade foi suprimida pelo pecado, não pode ser restituída sem a tristeza, pela qual nos
penitenciamos do pecado passado; o que constitui a matéria da penitência.

RESPOSTA À SEGUNDA. — Nem a fé, nem a caridade nem a misericórdia podem, sem a penitência,
tirar-nos do estado de pecado. Pois, ao seu lado, a caridade exige que nos arrependamos da ofensa
cometida contra o amigo, e que empreguemos estudo em nos reconciliarmos com ele. A fé, por outro
lado, requere que, pela virtude da paixão de Cristo, que obra nos sacramentos da Igreja, nos
justifiquemos dos nossos pecados. E por fim também a misericórdia ordenada pede que reparemos pela
penitência a nossa miséria, em que nos precipitou o pecado, segundo aquilo da Escritura: O pecado faz
miseráveis os povos. Donde o outro dito da Escritura: Tem piedade com a tua alma, fazendo-te
agradável a Deus.

RESPOSTA À TERCEIRA. — Pela excelência do poder, que só Cristo tinha como dissemos, é que
concedeu à mulher adúltera o efeito do sacramento da penitência - a remissão dos pecados - sem esse
sacramento; embora não sem a penitência interior, que operou nela pela graça.

## Art. 6 — Se a penitência é a segunda tábua, depois do naufrágio.
O sexto discute-se assim. — Parece que a penitência não é a segunda tábua, depois do naufrágio.

1. — Pois, àquilo de Isaias - Fizeram como os de Sodoma, pública ostentação do seu pecado, diz a Glosa:
A segunda tábua, depois do naufrágio, é esconder os pecados. Ora, a penitência não esconde os
pecados; ao contrário, revela-os. Logo, a penitência não é a segunda tábua.

2. Demais. — O fundamento ocupa, no edifício, não o segundo, mas o primeiro lugar. Ora, a penitência é
o fundamento do edifício espiritual, segundo aquilo do - Apóstolo: Não lançando de novo o fundamento
da penitência das obras mortas. Por isso precede ao próprio batismo, conforme ainda aquilo da
Escritura: Fazei penitência e cada um de vós sela batizado. Logo, a penitência não é a segunda tábua.

3. Demais. — Todos os sacramentos são umas tábuas, isto é, remédios contra o pecado. Ora, a
penitência não ocupa o segundo lugar entre os sacramentos; mas antes, o quarto, como do sobredito se
colhe. Logo, a penitência não deve ser considerada como a segunda tábua depois do naufrágio.
Mas, em contrário, Jerônimo diz, que a segunda tábua depois do naufrágio é a penitência.

SOLUÇÃO. — O essencial é naturalmente anterior ao acidental; assim, a substância é anterior ao
acidente. Ora, certos sacramentos se ordenam à salvação do homem; tal o batismo, que um nascimento
espiritual; a confirmação, crescimento espiritual; e a Eucaristia, nutrição espiritual. A penitência porém
se ordena à nossa salvação acidental e condicionalmente, isto é, suposto o pecado. Pois, se atualmente
não pecássemos, não precisaríamos da penitência; mas precisaríamos do batismo, da confirmação e da
Eucaristia. Assim como para a vida do corpo não precisaríamos de remédios se não enfermássemos; mas
para vivermos é preciso, nascermos, crescermos e nutrirmo-nos. Por onde, a penitência ocupa o
segundo lugar relativamente ao estado de integridade conferido e conservado pelos referidos
sacramentos. Por isso dizemos metaforicamente que é a segunda tábua depois do naufrágio. Assim, O
primeiro remédio para os que atravessamos os mares é nos conservamos num navio em bom estado; o
segundo, se ele naufraga, apegar-mo-nos a uma tábua. Do mesmo modo, o primeiro remédio no mar
desta vida é conservarmos a nossa integridade; o segundo, recuperarmos essa integridade pela
penitência, se a perdemos pelo pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De dois modos podemos esconder os pecados. Primeiro,
quando os cometemos. Pois, é pior pecar em público que às ocultas; quer porque o pecador público se
considera como pecando com maior desprezo; quer também por pecar com escândalo dos outros. Por
isso, aplica-se um remédio aos pecados que cometemos às ocultas. E neste sentido diz a Glosa: A
segunda tábua depois do naufrágio é esconder os pecados; não que assim fique o pecado delido, como
o é pela penitência; mas pelo tornar menor. - De outro modo, podemos esconder o pecado
anteriormente cometido por negligência na confissão; e isso encontra a penitência. E então esconder o
pecado não é a segunda tábua, mas antes o contrário da tábua; pois, como diz a Escritura, aquele que
esconde as suas maldades não será bem sucedido.

RESPOSTA À SEGUNDA. — A penitência não pode ser considerada o fundamento do edifício espiritual,
absolutamente, falando, isto é, na primeira edificação; mas é o fundamento, na segunda reedificação,
que se opera pela destruição do pecado. Pois, é ela que antes de tudo se impõe aos que voltam para
Deus. Mas o Apóstolo, no lugar aduzido, fala do fundamento espiritual da doutrina. - Quanto à
penitência precedente ao batismo, não é o sacramento da penitência.

RESPOSTA À TERCEIRA. — Os três sacramentos precedentes respeitam à nau íntegra, isto é, ao estado
de integridade; em relação ao qual dizemos que a penitência é a segunda tábua.

## Art. 7 — Se este sacramento foi convenientemente instituído na Lei Nova.
O sétimo discute-se assim. — Parece que este sacramento não foi convenientemente instituído na Lei
Nova.

1. — Pois, o que é de direito natural não precisa ser instituído. Ora, penitenciarmos dos males que
praticamos é de direito natural; pois, não podemos amar o bem sem nos penitenciarmos de que lhe é
contrário. Logo, a penitência não foi convenientemente instituída na Lei Nova.

2. Demais. — O já existente na Lei Velha não precisava ser de novo instituído. Ora, na Lei Velha já existia
a penitência, e por isso o Senhor se queixa, perguntando: Ninguém há que faça penitência do seu
pecado, dizendo Que fiz eu? Logo, a penitência não devia ser instituída na Lei Nova.

3. Demais. — A penitência é conseqüente ao batismo, pois é a segunda tábua. Ora, a penitência foi
instituída pelo Senhor antes do batismo. Pois, no princípio da sua pregação o Senhor disse como lemos
no Evangelho: Fazei penitência porque está próximo o reino de Deus. Logo, este sacramento não foi
convenientemente instituído na Lei Nova.
Mas, em contrário, diz o Senhor: Assim é que importava que o Cristo padecesse e que ressurgisse dos
mortos ao terceiro dia, e que em seu nome se pregasse penitência e remissão de pecados em todas as
nações.

SOLUÇÃO. — Como dissemos, neste sacramento o ato do penitente se comporta como a matéria; e os
atos do sacerdote, obrando como ministro de Cristo, se comportam como o elemento formal e
completivo do sacramento. Ora, a matéria, mesmo nos outros sacramentos, preexiste por natureza,
como a água; ou por alguma arte, como o pão. Mas, é necessária uma instituição determinando que tal
matéria deva ser assumida para o sacramento. Ora, a forma do sacramento e a sua virtude procedem
totalmente da instituição de Cristo, de cuja paixão proveio a virtude dos sacramentos. Assim pois a
matéria preexiste por natureza; pois, pela razão natural somos levados a nos penitenciarmos dos males
que praticamos; mas, o fazermos penitência deste ou daquele modo, resulta de uma instituição divina. -
Por isso Senhor, no princípio da sua pregação, ordenou aos homens não só o se penitenciarem, mas
também que fizessem penitência, significando assim os determinados modos dos atos requeridos por
este sacramento. E o que respeita ao ofício dos ministros, o determinou quando disse a Pedro: Eu te
darei as chaves do reino nos céus. Quanto à eficácia deste sacramento e à origem da sua virtude, ele as
manifestou após a sua ressurreição, quando depois de ter-se referido à sua paixão e ressurreição, disse,
que importava que se pregasse em seu nome a penitência e a remissão de pecados em todas as nações.
Pois, em virtude do nome de Jesus Cristo que sofreu e ressurgiu, este sacramento tem a sua eficácia de
remitir os pecados. Por onde é claro que foi convenientemente instituído na Lei Nova.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É de direito natural o nos penitenciarmos dos males que
fizemos, arrependendo-nos de os haver praticado, buscando de algum modo remédio à nossa dor; e
ainda, dando certas mostras dela. Assim o fizeram os Ninívitas, como lemos na Escritura; os quais
tiveram mesmo, além da fé que neles tinha despertado a pregação de Jonas, de fazer o que essa fé
exigia, com a esperança de alcançarem de Deus o perdão, segundo as palavras do profeta - Quem sabe
se voltará Deus para nos perdoar e se aplacará ele o furor da sua ira, de sorte que nós não pereçamos?
Mas, como todas as outras prescrições da lei natural foram precisadas por uma leis divinas positivas,
conforme o dissemos na Segunda Parte, assim também a penitência.

RESPOSTA À SEGUNDA. — As prescrições do direito natural recebem a sua determinação diversamente
na Lei Velha e na Nova, conforme o vêem à imperfeição daquela e à perfeição desta. Por isso a
penitência, na Lei Velha, recebeu uma certa precisão. Primeiro, quanto à dor dos pecados, que devia
exprimir-se antes pelos afetos do coração do que por sinais externos, segundo aquilo da Escritura:
Rasgai os vossos corações e não os vossos vestidos. E quanto ao remédio que se devia buscar a dor; de
modo que os ministros de Deus de certa maneira confessarem os seus pecados, pelo menos em geral.
Donde o dizer o Senhor: Se uma pessoa pecar por ignorância oferecerá dos rebanhos um carneiro sem
defeito, conforme à medida e a consideração do pecado, ao sacerdote; o qual orará por ele, porque o
fez com ignorância e perdoar-se-lhe-á. E o fato de fazer um oblação pelo seu pecado já era de certo
modo confessá-lo ao sacerdote. Por isso diz a Escritura: Aquele que esconde as suas maldades não será
bem sucedido; aquele porém que as confessar e se retirar delas alcançará misericórdia. - Mas ainda não
havia o poder das chaves, derivada da paixão de Cristo. E por conseqüente ainda não estava instituída a
dor dos pecados com o propósito de o pecador se submeter, pela confissão e pela satisfação, às chaves
da Igreja, com a esperança de conseguir perdão em virtude da paixão de Cristo.

RESPOSTA À TERCEIRA. — Atentando isto mais consideradamente, veremos que o dito do Senhor sobre
a necessidade do batismo precedeu no tempo o que disse da necessidade da penitência. Pois, o que
disse a Nicodemos, sobre o batismo, foi antes do encarceramento de João, do qual depois se acrescenta
que batizava. Mas o que disse da penitência foi depois do encarceramento de João. - Se porém tivesse
primeiro induzido à penitência que ao batismo, sê-lo-ia porque também antes do batismo é necessária
uma certa penitência, como o diz Pedro: Fazei penitência e cada um de vós seja batizado.

RESPOSTA À QUARTA. — Cristo não recebeu o batismo que ele mesmo instituiu, mas foi batizado no
batismo de João, como dissemos. Mas nem mesmo exerceu ativamente o seu ministério, porque ele
próprio não batizava em geral, mas os seus discípulos como diz Agostinho. Pois, receber o sacramento
por ele próprio instituído de nenhum modo lhe convinha. Quer por não ter necessidade de penitência,
quem não tinha nenhum pecado; nem pelo fato de conferir este sacramento aos outros, pois, para
mostrar a sua misericórdia e o seu poder, conferia o efeito deste sacramento sem conferir o
sacramento, como dissemos. – Quanto porém ao sacramento da Eucaristia, ele próprio o recebeu e o
deu aos outros: quer para lhe mostrar a excelência; quer por ser esse sacramento o memorial da sua
paixão, enquanto é nele Cristo o sacerdote e a hóstia.

## Art. 8 — Se a penitência deve durar até ao fim da vida.
O oitavo discute-se assim. — Parece que a penitência não deve durar até ao fim da vida.

1. — Pois, a penitência se ordena a delir o pecado. Ora, o penitente recebe logo a remissão dos pecados,
conforme àquilo da Escritura: Se o ímpio fizer penitência de todos os seus pecados que cometeu viverá e
não morrerá. Logo, não é preciso prolongar ainda mais a penitência.

2. Demais. — Fazer penitência é próprio dos principiantes. Ora, desse estado devemos passar para o dos
que progridem e, depois, ao dos perfeitos. Logo, não devemos fazer penitência até ao fim da vida.

3. Demais. — Assim como nos outros sacramentos devemos observar as prescrições da Igreja, assim
também neste. Ora, segundo os cânones, há tempos determinados para a penitência; de modo que
quem cometeu um certo pecado ou tal outro faça tantos anos de penitência. Logo, parece que a
penitência não se nos deve estender até ao fim da vida.
Mas, em contrário, diz Agostinho: Que nos resta senão chorar durante esta vida? Pois, onde não há dor
não há penitência. E se não fazemos penitência, como alcançaremos perdão?

SOLUÇÃO. — Há duas espécies de penitência: a interior e a exterior. - A interior é a que nos faz chorar o
pecado cometido. E essa deve durar até ao fim da vida. Pois, sempre nos devemos doer do pecado
cometido; do contrário, se nos comprazemos no pecado, já por isso mesmo nele incorremos e
perdemos o fruto do perdão. Ora, a displicência do pecado cometido causa dor em quem é dela
susceptível, como o somos nós durante esta vida. Mas, depois dela, os bens aventurados não são mais
capazes de dor. E por isso, sem nenhuma dor, lhes repugnarão todos os pecados passados, segundo
aquilo da Escritura: Foram entregues ao esquecimento as primeiras angústias. - A penitência exterior é a
pela qual damos mostras externas de dor, confessamos verbalmente os nossos pecados ao confessor,
que os absolve, e satisfazemos conforme ele o ordenar. E essa penitência não há de durar até ao fim da
vida; mas até um certo tempo, segundo a medida do pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A verdadeira penitência não só remove os pecados
passados, mas também nos preserva dos futuros. Pois, embora no primeiro instante da verdadeira
penitência alcancemos a remissão dos pecados, devemos, contudo perseverar penitentes, para não
reincidirmos no pecado.

RESPOSTA À SEGUNDA. — Fazer penitência interior simultaneamente com a exterior é próprio dos
incipientes, que acabam de sair do pecado. Mas, fazer penitência interna cabe tanto aos que progridem
como aos perfeitos, segundo aquilo da Escritura: Por isso o próprio Paulo dizia: Não sou digno de ser
chamado apóstolo, porque persegui a Igreja de Deus.

RESPOSTA À TERCEIRA. — Esses tempos referidos são prefixados aos penitentes quanto ao ato da
penitência exterior.

## Art. 9 — Se a penitência pode ser contínua.
O nono discute-se assim. — Parece que a penitência não pode ser contínua.

1. — Pois, diz a Escritura: Cesse lá do choro a tua voz e de verterem lágrimas os teus olhos. Ora, isto não
poderia ser, se a penitência. consistente em choro e lágrimas, fosse contínua. Logo, a penitência não
pode ser contínua.

2. Demais. — Devemos nos com prazer com todas as nossas boas obras, segundo aquilo da Escritura:
Servi ao Senhor em alegria. Ora, fazendo penitência, praticamos uma boa obra. Logo, devemos nos
comprazer com ela. Mas, não podemos estar em alegria e tristeza ao mesmo tempo, conforme está
claro no Filósofo. Logo não pode o penitente chorar continuamente os pecados passados, como o exige
a penitência.

3. Demais. — O Apóstolo diz: Deveis consolá-lo, isto é, o penitente, para que não aconteça que seja
consumido de demasiada tristeza quem se acha em tais circunstâncias. Ora, a consolação expulsa as
lágrimas, que constituem a essência da penitência. Logo, a penitência não deve ser contínua.
Mas, em contrário, diz Agostinho: Cuidemos para que seja contínua a dor da nossa penitência.

SOLUÇÃO. — De dois modos podemos fazer penitência: por atos e pelo hábito. - Ora, atualmente é-nos
impossível fazer penitência contínua; pois seria necessário os atos do penitente, internos ou externos,
interpolarem-se ao menos no sono e na satisfação de outras necessidades corpóreas. - Noutro sentido
referimo-nos à penitência habitual. E então devemos fazer continua penitência. Tanto por nunca
devermos praticar nada de contrário à penitência e que nos viesse privar da disposição atual de
penitente; quanto por devermos trazer sempre no propósito a dor dos pecados passados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O choro e as lágrimas são atos externos de penitência,
os quais não só não devem ser contínuos, mas ainda não é necessário durem até ao fim da vida, como
dissemos. Por isso no mesmo lugar se diz sinaladamente: porque recompensa há para a tua obra. Ora, a
recompensa da obra do penitente é a plena remissão do pecado, quanto à culpa e quanto à pena; e
depois de alcançá-la, já não devemos mais fazer a penitência externa. Mas isto não exclui a continuidade
da penitência, tal como dissemos.

RESPOSTA À SEGUNDA. — A dupla luz podemos considerar a dor e a alegria. - Primeiro, enquanto
paixões do apetite sensitivo. E então de nenhum modo podem existir simultâneas, por serem
absolutamente contrárias quer pelos seus objetos - por exemplo, quando recaem sobre o mesmo
objeto; quer ao menos pelo movimento do coração - pois, ao passo que a alegria implica o dilatar-se do
coração, a tristeza é acompanhada da constrição dele. E é neste sentido que fala o Filósofo. - A outra luz
podemos considerar a alegria e a tristeza enquanto consistentes num simples ato da vontade, a que
uma cousa agrada ou desagrada. E então não podem ter contrariedade senão por parte do objeto - por
exemplo, quando recaem sobre o mesmo objeto e ao mesmo respeito. E nesse caso não podem
coexistir a alegria e a tristeza, porque uma mesma coisa não pode simultaneamente e ao mesmo
respeito agradar e desagradar. Se porém a alegria e a tristeza assim consideradas não recaírem sobre o
mesmo objeto e ao mesmo respeito; ou se recaírem sobre objetos diversos, ou sobre o mesmo mas a
respeitos diversos, então nenhuma contrariedade há entre a alegria e a tristeza. Por onde, nada impede
alegrarmo-nos e entristecermo-no; simultaneamente; por exemplo, vendo um justo sofrer, ao mesmo
tempo que nos apraz a sua justiça desagrada-nos o seu sofrimento. E deste modo pode nos desagradar
o termos pecado, e nos agradar a nossa displicência, pelo havermos feito, com a esperança do perdão,
de maneira que a própria tristeza nos seja matéria de alegria. Donde o dizer Agostinho: Tenha sempre o
penitente dor dos seus pecados e se alegre pela ter. Se porém a tristeza de nenhum modo fosse
compatível com a alegria, isso privaria, não da continuidade habitual da penitência, mas da atual.

RESPOSTA À TERCEIRA. — Segundo o Filósofo, à virtude pertence estabelecer a mediedade entre as
paixões. Ora, a tristeza que, no apetite sensitivo do penitente resulta da displicência da vontade, é uma
paixão. Por onde, deve ser moderada pela virtude; e é vicioso o seu excesso, por induzir em desespero.
O que significa o Apóstolo, dizendo no mesmo lugar: Para que não aconteça seja consumido de
demasiada tristeza, quem se acha em tais circunstâncias. E assim a consolação a que aí o Apóstolo
refere é moderadora da tristeza, mas não priva totalmente dela.

## Art. 10 — Se o sacramento da penitência deve reiterar-se.
O décimo discute-se assim. — Parece que o sacramento da penitência não deve reiterar-se.

1. — Pois. diz o Apóstolo: É impossível que os que foram uma vez iluminados, que tomaram já o gosto
ao dom celestial, e que foram feitos participantes do Espírito Santo, e depois disto caíram, é impossível,
digo, que eles tornem a ser renovados pela penitência. Ora, todos os que fizeram penitência foram
iluminados e receberam o dom do Espírito Santo. Logo, quem quer que peque, depois da penitência,
não na pode fazer de novo.

2. Demais. — Ambrósio diz: Encontram-se pessoas que pensam que devemos fazer penitência muitas
vezes; são uns luxuriosos em Cristo. Pois, se tivessem verdadeiramente feito penitência, não pensariam
que ela deve ser renovada; porquanto, como é um só o batismo, também uma só é a penitência. Ora, o
batismo não se reitera. Logo, nem a penitência.

3. Demais. — Os milagres com que Deus curou as enfermidades do corpo significam a cura das doenças
espirituais, pela qual somos livres dos pecados. Mas não lemos no Evangelho, que o Senhor tivesse dado
a vista a nenhum cego duas vezes, ou tivesse limpado duas vezes algum leproso, ou ainda duas vezes
ressuscitado algum morto. Logo, parece também que a nenhum pecador dá duas vezes o perdão, pela
penitência.

4. Demais. — Gregório diz: Penitência é chorar os pecados antes cometidos, e não tornar a cometer o
que devemos depois chorar. E Isidoro: É irrisor e não penitente quem continua a fazer o de que há de
penitenciar-se. Quem, pois, é verdadeiramente penitente não tornará a pecar. Logo, não é possível a
penitência ser reiterada.

5. Demais. — Assim como o batismo tira a sua eficácia da paixão de Cristo, assim também a penitência.
Ora, o batismo não é reiterado, por causa da unidade da paixão e da morte de Cristo. Logo, pela mesma
razão, nem a penitência.

6. Demais. — Gregório (Ambrósio) diz: A facilidade do perdão é um incentivo para pecar. Se, pois, Deus
dá freqüentemente perdão, pela penitência, parece que dá aos homens um incentivo para pecarem; e
assim pareceria comprazer-se com o pecado. O que não condiz com a sua bondade. Logo, a penitência
não pode ser reiterada.
Mas, em contrário, somos induzidos à misericórdia pelo exemplo da divina misericórdia, segundo aquilo
do Evangelho: Sêde misericordiosos, como também vosso Pai é misericordioso. Ora, o Senhor impõe
essa misericórdia aos seus discípulos, para que mais freqüentemente perdoem aos seus irmãos que os
ofenderem. Por isso, a Pedro que perguntava Senhor, quantas vezes poderá pecar meu irmão contra
mim, que eu lhe perdoe - respondeu Jesus: Não te digo que até sete vezes, mas que até setenta vezes
sete vezes. E por isso, o Senhor mui freqüentemente dá pela penitência o perdão aos que pecam; pois
sobretudo nos ensinou a fazer a oração: Perdoai-nos as nossas dívidas assim como nós perdoamos aos
nossos devedores.

SOLUÇÃO. — Sobre a penitência certos erraram, dizendo que não podemos por meio dela conseguir
duas vezes o perdão dos pecados. Desses uns, os Novacianos, deram a tal modo de ver uma extensão, a
ponto de dizerem, que depois da primeira penitência, feita no batismo, os pecadores não podem
alcançar novo perdão por uma nova penitência. - Outros heréticos houve porém, como o refere
Agostinho, de acordo com os quais, depois do batismo é útil a penitência, não porém várias vezes, mas
uma só. Estes erros procedem de duas causas. - Primeiro, porque esses heréticos erravam no tocante à
natureza da verdadeira penitência. Pois, sendo para a verdadeira penitência necessária a caridade, sem
a qual não podem ser delidos os pecados, criam que, uma vez possuída, a caridade não pode ser
perdida; e por conseqüência a penitência, sendo verdadeira, não pode nunca ser perdida pelo pecado, a
ponto de ser necessária a renovação. Mas isto foi refutado na Segunda Parte, onde mostramos, que a
caridade, uma vez possuída, pode ser perdida, por causa da liberdade do arbítrio; e portanto, depois de
uma verdadeira penitência podemos pecar mortalmente. - Segundo, porque erravam no ponderar a
gravidade do pecado. Pois, pensavam ser tão grave o pecado cometido depois de alcançado o perdão,
que não é possível se:- perdoado. E nisso erravam relativamente ao pecado, o qual, mesmo depois de
alcançada a absolvição, pode ser mais grave e mais leve mesmo, que o fora o primeiro pecado
perdoado. E erravam muito mais contra a infinidade da divina misericórdia, superior a qualquer número
e a qualquer grandeza de pecados, segundo aquilo da Escritura: Tem piedade de mim, ó Deus, segundo
a tua grande misericórdia; e segundo as muitas mostras da tua clemência, apaga a minha maldade. Por
isso é reprovada a palavra proferida por Caim: O meu pecado é muito grande para eu poder alcançar
perdão. Por onde, a misericórdia de Deus perdoa aos pecadores penitentes, sem nenhum limite. Donde
o dizer a Escritura: Imensa e inconcebível é a misericórdia de vossa promessa a respeito da malícia dos
homens. Por onde é manifesto, que a penitência pode ser reiterada muitas vezes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Porque entre os judeus a lei instituíra determinadas
abluções, pelas quais muitas vezes se purgavam das imundícies, certos deles criam que também pela
ablução do batismo podiam purificar-se várias vezes. E para excluir esse erro o Apóstolo escreve aos
Hebreus: É impossível que os que foram uma vez iluminados, isto é, pelo batismo, tornem a ser
renovados pela penitência, isto é, pelo batismo, que é a ablução de regeneração e renovação do Espírito
Santo. E dá a razão, a saber, que pelo batismo morremos com Cristo; e por isso acrescenta: Crucificam
de novo ao Filho de Deus em si mesmo.

RESPOSTA À SEGUNDA. — Ambrósio se refere à penitência solene, que na Igreja não se reitera, como
diremos a seguir.

RESPOSTA À TERCEIRA. — Diz Agostinho: Em ocasiões diversas o Senhor restituiu a vista a muitos cegos
e curou muitos enfermos, para mostrar que nesses casos diversos perdoava muitas vezes os mesmos
pecados. Assim, depois de ter curado um leproso, restituiu-lhe uma outra vez a vista. Se pois curou
tantos cegos, coxos e anemicos, foi para impedir o pecador de desesperar. Por isso o Evangelho não
narra que tivesse curado um doente senão uma vez, para nos inspirar a todos o temor dos pecados.
Chama-se a si mesmo médico, útil, não para os sãos, mas para os doentes. Mas que médico seria esse
que não soubesse curar males que se renovam? Pois um médico há de curar cem vezes quem cem vezes
adoeceu. Cristo seria, pois, inferior aos outros médicos, se não pudesse o que podem eles.

RESPOSTA À QUARTA. — Fazer penitência é chorarmos os pecados anteriormente cometidos e não
cometermos atual nem intencionalmente ao mesmo tempo que os choramos, atos a serem por sua vez
chorados. Pois, irrisor é e não penitente quem ao mesmo tempo que faz penitência, pratica atos de que
deve penitenciar-se. Quem se propõe a fazer de novo o que fez, ou quem comete atualmente o mesmo
ou outro gênero de pecado. Mas o fato de alguém pecar, atual ou intencionalmente, depois de ter feito
penitência, não impede que esta tenha sido verdadeira. Porque nunca a verdade de um ato anterior fica
exclui da pela do ato contrário subseqüente; pois, assim como correu verdadeiramente quem agora está
sentado, assim foi verdadeiramente penitente quem depois veio a pecar.

RESPOSTA À QUINTA. — O batismo tira a sua virtude da paixão de Cristo, como sendo um renascimento
espiritual, ligado com a morte espiritual da vida precedente. Ora, está decretado aos homens que
morram uma só vez e nasçam uma só vez. Por isso devemos ser batizados uma só vez. Mas a penitência
tira a sua virtude da paixão de Cristo, como sendo um remédio espiritual, que pode ser reiterado muitas
vezes.

RESPOSTA À SEXTA. — Agostinho diz que o grande ódio de Deus pelo pecado se revela por estar sempre
pronto a destruí-lo, a fim de não dissolver-se o que criou, nem se corrompa o que amou, isto é, pelo
desespero.