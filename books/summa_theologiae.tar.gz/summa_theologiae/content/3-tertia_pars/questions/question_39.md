# Questão 39: Do batizado de Cristo
Em seguida devemos tratar do batizado de Cristo. E nesta questão discutem-se oito artigos:

## Art. 1 — Se devia Cristo ser batizado.
O primeiro discute-se assim. — Parece que não devia Cristo ser batizado.

1. — Pois, o batismo é uma ablução. Ora, desta não precisava Cristo, isento de qualquer impureza. Logo,
parece que Cristo não devia ser batizado.

2. Demais. — Cristo recebeu a circuncisão para cumprir a lei. Ora, o batismo não era exigido pela lei.
Logo, não devia ser batizado.

3. Demais. — Em qualquer gênero de movimento o primeiro motor é imóvel; assim o céu, a causa
primeira da alteração, não é susceptível de ser alterado. Ora, Cristo foi o primeiro que batizou, segundo
àquilo do Evangelho: Aquele sobre que tu vires descer o Espírito Santo e repousar sobre ele, esse é o
que batiza. Logo, não convinha ele próprio ser batizado. Mas, em contrário, o Evangelho diz, que veio
Jesus de Galileia ao Jordão ter com João para ser batizado por ele.

SOLUÇÃO. — Cristo devia ser batizado. - Primeiro, porque, como diz Ambrósio, o Senhor foi batizado,
não por querer purificar-se; mas para purificar as águas que, purificadas assim pelo corpo de Cristo,
isento de pecado, pudessem servir para o batismo e a fim de deixar para o futuro as águas santificadas
para os que devessem ser batizados, como ensina Crisóstomo. Segundo, porque, como diz Crisóstomo,
embora Cristo não fosse pecador, contudo assumiu uma natureza pecadora e a semelhança da carne do
pecado. Por onde, embora não precisasse ele próprio de batismo, contudo deste precisava a natureza
carnal dos outros. E como diz Gregório Nazíanzeno, Cristo foi batizado, para imergir na água todo o
velho Adão. - Terceiro, quis ser batizado Cristo, porque como diz Agostinho, quis fazer o que ordenou a
todos fazerem. Tal o que significam as suas próprias palavras: Assim nos convém cumprir toda a justiça.
Pois, como diz Ambrósio, a justiça exige que comecemos por fazer o que queremos que os outros façam
e exortemos os outros a nos imitarem pelo nosso exemplo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo não foi batizado para abluir-se, mas para abluir,
como dissemos.

RESPOSTA À SEGUNDA. — Cristo não só devia cumprir os preceitos da lei antiga: mas ainda dar início
aos da nova. Por isso, não somente quis circuncidar-se, mas também batizar-se.

RESPOSTA À TERCEIRA. — Cristo foi o primeiro que conferiu o batismo espiritual. E assim, não foi
batizado senão só em água.

## Art. 2 — Se Cristo devia receber o batismo de João.
O segundo discute-se assim. — Parece que Cristo não devia receber o batismo de João.

1. — Pois, o batismo de João foi um batismo de penitência. Ora, a penitência não convinha a Cristo,
isento de todo pecado. Logo, parece que não devia receber o batismo de João.

2. Demais. — O batismo de João, como diz Crisóstomo, foi um meio termo entre o batismo dos Judeus e
o de Cristo. Ora, o termo médio
participa da natureza dos extremos, como diz Aristóteles. Ora, como Cristo não recebeu o batismo da lei
nem o seu próprio, parece que, pela mesma razão não devia receber o de João.

3. Demais. — Tudo o que é ótimo, na ordem humana deve ser atribuído a Cristo. Ora, o batismo de João
não é o supremo dos batismos. Logo, não devia Cristo receber o batismo de João.
Mas, em contrário, o Evangelho: Veio Jesus ao Jordão para ser batizado por João.

SOLUÇÃO. — Como diz Agostinho, o Senhor batizava, depois de batizado, mas não pelo batismo com
que o foi. Por onde, como administrava um batismo que lhe era próprio, não recebeu o seu próprio
batismo, mas o de João. E assim devia ser. - Primeiro, pela condição do batismo de João, que não
batizava no Espírito, mas só em água. Ora, Cristo não precisava de nenhum batismo espiritual, porque
desde o princípio da sua concepção teve a plenitude da graça do Espírito Santo, como do sobredito
resulta. E essa é a razão dada por Crisóstomo. Segundo, como diz Beda, recebeu o batismo de João, para
comprová-lo com o seu batismo. – Terceiro, como diz Gregório Nazianzeno, Cristo recebeu o batismo de
João para santificar o batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como dissemos, Cristo quis ser batizado a fim de, com o
seu exemplo, nos induzir a receber o batismo. E para ser mais eficaz a sua indução, quis receber um
batismo de que manifestamente não precisava, para que os homens recebam o de que precisam. Donde
o dizer Ambrósio: Ninguém recuse o lavacro da graça, pois Cristo não recusou o lavacro da penitência.

RESPOSTA À SEGUNDA. — O batismo dos judeus, preceituado pela lei, era somente figurado: ao passo
que o de João de certo modo era oral, por induzir os homens a se absterem do pecado: mas o batismo
de Cristo tinha a eficácia de purificar do pecado e conferir a graça. Quanto a Cristo, nem precisava de
receber a remissão dos pecados, dos quais estava isento, nem de receber a graça, da qual tinha a
plenitude. Semelhantemente, sendo ele a Verdade, não lhe podia convir o que se realizava só
figuradamente. Por isso, mais conforme lhe era receber um batismo médio, do que um dos extremos.

RESPOSTA À TERCEIRA. — O batismo é um certo remédio espiritual. Ora, mais um ser é perfeito e
menos necessidade tem de remédio. Por onde, sendo Cristo perfeito por excelência, não devia receber
o perfeitissimo dos batismos, assim como não precisa quem é são da eficácia de nenhum remédio.

## Art. 3 — Se Cristo foi batizado no tempo conveniente.
O terceiro discute-se assim. — Parece que Cristo não foi batizado no tempo conveniente.

1. — Pois, Cristo foi batizado para levar os outros a imitarem o seu exemplo. Ora, é louvável que os fiéis
de Cristo sejam batizados não só antes dos trinta anos, mas mesmo em idade infantil. Logo, parece que
Cristo não devia ter sido batizado na idade de trinta anos.

2. Demais. — Não lemos no Evangelho que Cristo ensinasse ou fizesse milagres antes do batismo. Ora,
teria sido mais útil ao mundo se tivesse ensinado antes, começando dos vinte anos ou ainda antes. Logo,
parece que Cristo, que veio ao mundo para bem dos homens, devia ter sido batizado antes dos trinta
anos.

3. Demais. — O sinal da sabedoria infundida por Deus devia manifestar-se sobretudo em Cristo. Ora,
manifestou-se em Daniel no tempo da sua puerícia, segundo o diz a Escritura: Suscitou o Senhor o santo
espírito de um moço ainda menino, cujo nome era Daniel. Logo, com maioria de razão, Cristo devia ter
sido batizado e ter começado a ensinar, na sua puerícia.

4. Demais. — O batismo de João se ordenava ao de Cristo como ao fim. Ora, o fim, primeiro na intenção,
é último na execução. Logo, Cristo ou devia ser o primeiro ou o último a ser batizado por João.
Mas, em contrário, o Evangelho: E aconteceu que como recebesse o batismo todo o povo depois de
batizado também Jesus e estando em oração. E mais adiante: E o mesmo Jesus começava a ser quase de
trinta anos.

SOLUÇÃO. — Cristo foi convenientemente batizado no seu trigésimo ano de idade. - Primeiro, porque
desde o seu batismo é que Cristo começou, por assim dizer, a ensinar e a pregar; o que exige uma idade
perfeita, qual é a dos trinta anos. Por isso, como lemos na Escritura, José tinha trinta anos quando
assumiu o governo do Egito. E também ela refere que Davi tinha trinta anos quando começou a reinar. E
ainda, que Ezequiel começou a profetizar aos trinta anos. - Segundo, porque, como diz Crisóstomo,
depois do batismo de Cristo a lei antiga começava a deixar de vigorar. Por isso, Cristo recebeu o batismo
numa idade em que podia assumir todos os pecados de modo que ninguém pudesse dizer que ele
abrogou a lei por não a poder observar. - Terceiro, porque o ter Cristo recebido o batismo numa idade
perfeita significa que o batismo gera os varões perfeitos, segundo àquilo do Apóstolo: Até que todos
cheguemos à unidade da fé e ao conhecimento do Filho de Deus, a estado de varão perfeito, segundo a
medida da idade completa de Cristo. Pois, o demonstram até as propriedades do número trinta
resultante da combinação de três e de dez: o número três significa a fé na Trindade; dez é o número dos
mandamentos da lei a serem cumpridos; e nessas duas coisas consiste a perfeição da vida cristã.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Gregório Nazianzeno, Cristo não foi batizado
porque precisasse de purificação, não havendo por isso nenhum perigo de lhe diferir o batismo. Mas
para qualquer outro redundará em perigo não pequeno partir desta vida sem estar revestido das vestes
da incorrupção, isto é, da graça. E embora seja bom conservar, depois do batismo, a pureza batismal,
contudo, como também o diz Agostinho, é às vezes melhor ficarmos expostos a pequenas máculas, do
que carecermos de todo da graça.

RESPOSTA À SEGUNDA. — Cristo é uma fonte de bens para os homens, que sobretudo obtemos pela fé
e pela humildade. E ele nos ensinou fortemente essas virtudes, não começando a ensinar senão depois
que saiu da puerícia e da adolescência e atingiu a idade perfeita. Ensinou-nos a fé, tornando evidente
por meio dela a verdade da sua natureza humana; pois, essa verdade se mostra no desenvolvimento do
seu corpo, relativamente aos anos. E para que não se pudesse dizer que esse desenvolvimento era
fantástico, não quis manifestar a sua sabedoria e a sua virtude senão quando atingiu a idade do seu
pleno desenvolvimento. Ensinou-nos ainda a humildade, a fim de que ninguém tenha a presunção de
subir às honrar, antes da idade, nem a de assumir o ofício de ensinar.

RESPOSTA À TERCEIRA. — Cristo foi proposto como exemplo para todos os homens. Por isso devia
mostrar em si o que a lei comum exige de todos; donde o não ter ensinado senão quando atingiu a
idade perfeita. Mas, como diz Gregório Nazianzeno, não é lei da Igreja o que raramente se dá, assim
como uma andorinha não faz primavera. Embora a certos, por uma dispensa especial fosse concedido,
por determinadas razões da sabedoria divina, o poder de governar ou de ensinar, antes de terem
atingido a idade perfeita; talo que se deu com Salomão, Daniel e Jeremias.

RESPOSTA À QUARTA. — Cristo nem foi o primeiro nem o último que devesse ser batizado por João.
Porque, como diz Crisóstomo, Cristo
foi batizado para confirmar a pregação e o batismo de João, e para que recebesse o testemunho deste.
Pois, não haveriam de crer no testemunho de João senão depois que muitos foram batizados por ele.
Por isso não devia ter sido o primeiro que João batizasse. - Semelhantemente, nem o último. Porque,
como Crisóstomo acrescenta no mesmo lugar, assim como a luz do sol não espera o ocaso da estrela da
manhã, mas a precede para em breve obscurecê-la com o esplendor do seu lume, assim também Cristo
não esperou que João terminasse o curso da sua vida, mas apareceu quando ainda ele ensinava e
batizava.

## Art. 4 — Se Cristo devia ter sido batizado no Jordão.
O quarto discute-se assim. — Parece que Cristo não devia ser batizado no Jordão.

1. — Pois, a verdade deve realizar o que a figurava. Ora, figura do batismo foi a passagem do Mar Roxo,
onde os Egípcios ficaram submersos, assim como os pecados são delidos pelo batismo. Logo, parece que
Cristo devia ter sido batizado, antes, no mar que no rio Jordão.

2. Demais. — Jordão significa descenço. Ora, pelo batismo nós antes ascendemos que descemos; donde
o dizer o Evangelho que depois que Jesus foi batizado, saiu logo para fora da água. Logo, parece ter sido
inconveniente o batismo de Cristo no Jordão.

3. Demais. — Tendo passado os filhos de Israel, as águas do Jordão tornaram à sua madre, como se lê na
Escritura. Ora, os batizados, longe de retrogredirem, marcham para a frente. Logo, não parece ter sido
conveniente o batismo de Cristo no Jordão.
Mas, em contrário, o Evangelho: Jesus foi batizado por João no Jordão,

SOLUÇÃO. — Pelo rio Jordão é que os filhos de Israel entraram na terra da promissão. Ora, o bati o de
Cristo tem isto de especial sobre os demais batismos, que introduz no reino de Deus, simbolizado pela
terra da promissão. Donde o dizer a Escritura: Quem não renascer da água e do Espírito Santo não pode
entrar no reino de Deus. Ao que também se refere o fato de ter Elias dividido as águas do Jordão,
quando foi arrebatado do céu num carro de fogo, segundo lemos na Escritura; assim também aos que
passam pela água do batismo se lhes torna patente a entrada do céu pelo fogo do Espírito Santo. Logo
foi conveniente que Cristo tivesse sido batizado no Jordão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. - O trânsito do Mar Roxo prefigurou o batismo, quanto ao
delir os pecados, causado pelo batismo. Mas o trânsito do Jordão, quanto ao abrir as portas do reino
celeste, que é o mais principal efeito do batismo, causado só por Cristo. Logo, foi conveniente que Cristo
tivesse sido batizado no Jordão e não no mar.

RESPOSTA À SEGUNDA. — O batismo é uma ascensão pelo progresso na graça; pois, exige o descenço
da humildade, segundo aquilo da Escritura: Aos humildes dá a graça. E a esse descenço é que deve ser
referido o nome de Jordão.

RESPOSTA À TERCEIRA. — Como diz Agostinho, assim como antes as águas do Jordão retrocederam,
assim também o batismo de Cristo faz retrocederem os pecados. - Ou ainda, esse descenço das águas
significava que, contrariamente a ele, o rio das bênçãos cresceria para o alto.

## Art. 5 — Se no batismo de Cristo os céus deviam abrir-se.
O quinto discute-se assim. — Parece que no batismo de Cristo os céus não deviam abrir-se.

1. — Pois, deve abrir-se o céu a quem estando de fora, precisa entrar nele. Ora, Cristo sempre esteve no
céu, como o diz o Evangelho. Logo, parece que os céus não se lhe deviam abrir.

2. Demais. — A abertura dos céus se entende em sentido espiritual ou material. Ora, não se pode
entender em sentido material, pois que os corpos celestes são impassíveis e infrangíveis, conforme o
dito da Escritura: Talvez formaste tu com ele os céus, que são tão sólidos como se fossem de metal.
Nem em sentido espiritual, porque ante os olhos de Deus os céus nunca estiveram fechados. Logo,
parece inconveniente
dizer que no batismo de Cristo se lhe abriram os céus.

3. Demais. — Aos fiéis o céu se abriu pela paixão de Cristo, segundo aquilo do Apóstolo: Temos
confiança de entrar no santuário pelo sangue de Cristo. Por isso, os que não receberam o batismo de
Cristo e que morreram antes da sua paixão, também não puderam entrar no céu. Logo, os céus deviam
ter-se aberto antes na paixão que no batismo de Cristo.
Mas, em contrário: o Evangelho: Depois de batizado Jesus e estando em oração, abriu-se o céu.

SOLUÇÃO. — Como se disse, Cristo quis batizar-se para consagrar, com o seu batismo o que nós
devíamos receber. Por isso o batismo de Cristo devia manifestar o que constitui a eficácia do nosso. No
que três pontos se apresentam à nossa consideração. Primeiro, a virtude principal donde o batismo tira
a sua eficácia, que é uma virtude celeste. Por isso, no batismo de Cristo, o céu se abriu para mostrar
como, no futuro, a virtude celeste santificaria o batismo. Segundo, a fé da Igreja e a do batizado
cooperam para a eficácia do batismo; por isso, os batizados fazem profissão da sua fé e o batismo se
chama o sacramento da fé. Ora, pela fé nós nos alçamos à contemplação das coisas celestes, excedentes
ao sentido e à razão humana. E para o significar, os céus se abriram no batismo de Cristo. Terceiro,
porque pelo batismo de Cristo nos é especialmente franqueada a entrada do reino celeste, que fora
fechada ao primeiro homem pelo pecado. Por isso, no batismo de Cristo, abriram-se os céus para
mostrar que aos batizados está patente o caminho para o céu. - Depois do batismo, porém é necessária
ao homem uma oração contínua, para entrar no céu. Embora, pois, pelo batismo se perdoem os
pecados, permanece contudo a concupiscência como um efeito dele, que nos impugna interiormente,
bem como o mundo e os demônios, nossos inimigos externos. Por isso, diz sinaladamente o Evangelho:
Depois de batizado Jesus e estando em oração, abriu-se o céu; porque aos fiéis é necessária a oração
depois do batismo. - Ou para compreendermos que o mesmo abrirem-se os céus aos crentes, pelo
batismo, foi em virtude da oração de Cristo. Donde o dizer o Evangelho sinaladamente, que se lhe abriu
o céu, isto é, a todos por causa de Cristo, assim como um imperador diria a quem lhe suplicasse por um
terceiro - eis não lhe dou esse benefício a ele, mas a ti, isto é, por tua causa é que lh'o dou, como diz
Crisóstomo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Crisóstomo, assim como Cristo foi batizado em
razão da sua natureza humana, embora em si mesmo não precisasse de batismo, assim os céus se lhe
abriram à sua natureza humana, embora pela sua natureza divina sempre estivesse no céu.

RESPOSTA À SEGUNDA. — Como diz Jerônimo, os céus se abriram a Cristo batizado, não pela divisão
dos elementos, mas aos olhos do espírito; assim como Ezequiel diz, no começo das suas profecias, que
os céus se lhe abriram. E isso o prova Crisóstomo quando diz, que se fosse a criatura mesma dos céus,
que se rompesse, não diria o evangelista - abriu-se-lhe; pois o que materialmente se abre a todos, está
aberto. Por isso, Marcos expressamente diz que logo que saiu da água, viu Jesus os céus abertos, como
referindo a abertura mesma dos céus à visão de Cristo. O que certos referem à visão corpórea, dizendo
ter sido tamanho o esplendor com que refulgiu Cristo no seu batismo, que parecia terem-se rasgado os
céus. Mas também podemos referi-lo à visão imaginária, modo pelo qual Ezequiel viu os céus abertos;
assim por ação da virtude divina e da vontade racional, formou-se uma tal visão na imaginação de
Cristo, para exprimir que obatismo abriu aos homens a entrada do céu. Enfim, podemos entendê-lo da
visão intelectual, isto é, Cristo viu, depois de santificado pelo batismo, o céu aberto aos homens; o que
já antes via como devendo realizar-se.

RESPOSTA À TERCEIRA. — A paixão de Cristo foi uma causa comum de os céus se abrirem aos homens.
Mas essa causa há de aplicar-se a cada um para lhe tornar possível a entrada no céu. E isso se dá pelo
batismo, segundo aquilo do Apóstolo: Todos os que fomos batizados em Jesus Cristo, fomos batizados
na sua morte. Por isso se faz menção da abertura dos céus, antes no batismo, que na paixão. - Ou, como
diz Crisóstomo, os céus só se abriram depois de Cristo batizado, mas depois que venceu o tirano, não
sendo mais necessárias as portas, pois que o céu não devia mais fechar-se, os anjos não disseram - Abri
as portas (pois já estavam abertas), mas - tirai as portas. Pelo que Crisóstomo dá a entender, que os
obstáculos, que antes impediam as almas dos defuntos de entrar no céu, foram totalmente arredados
pela paixão de Cristo; mas pelo batismo foram abertas, como para nos mostrar a via pela qual os
homens haviam de entrar no céu.

## Art. 6 — Se é exato dizer-se que o Espírito Santo desceu sobre Cristo batizado em forma de pomba.
O sexto discute-se assim. — Parece que não é exato dizer-se que o Espírito Santo desceu sobre Cristo
batizado em forma de pomba.

1. — Pois, o Espírito Santo habita no homem pela graça. Ora, o homem Cristo teve a plenitude da graça
desde o princípio da sua concepção, em que foi o Unigênito do Pai, como do sobredito resulta. Logo, o
Espírito Santo não devia ter-lhe sido enviado no batismo.

2. Demais. — O Apóstolo diz que, pelo mistério da Encarnação, Cristo desceu ao mundo, quando se
aniquilou a si mesmo, tomando a natureza de servo. Ora, o Espírito Santo não se encarnou. Logo, não é
exato dizer que o Espírito Santo desceu sobre ele.

3. Demais. — O batismo de Cristo devia mostrar, por um como exemplo, o que se dá com o nosso
batismo. Ora, no batismo que nós recebemos não há nenhuma missão visível do Espírito Santo. Logo, no
batismo de Cristo devia manifestar-se a missão visível do Espírito Santo.

4. Demais. — O Espírito Santo deriva para nós mediante Cristo, segundo aquilo do Evangelho: Todos nós
participamos da sua plenitude.
Ora, o Espírito Santo desceu sobre os Apóstolos, sob a forma, não de pomba, mas de fogo. Logo, não
devia ter descido sobre Cristo em forma de pomba, mas de fogo.
Mas, em contrário, o Evangelho: Desceu sobre ele o Espírito Santo em forma corpórea, como uma
pomba.

SOLUÇÃO. — O que se passou no batismo de Cristo, como diz Crisóstomo, constitui o mistério de todos
os que no futuro haviam de ser batizados. Pois, todos os batizados pelo batismo de Cristo recebem o
Espírito Santo, se não se apresentarem dolosamente para o receber, segundo aquilo do Evangelho: Ele
vos batizará no Espírito Santo. Por isso foi conveniente que o Espírito Santo descesse sobre o Senhor, no
seu batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho, é absurdíssimo dizer que Cristo
recebeu o Espírito Santo, quando já tinha trinta anos; pois, quando recebeu o batismo, assim como não
tinha pecado, assim também já tinha o Espírito Santo. Se, pois, foi escrito, de João, que seria cheio do
Espírito Santo desde o ventre da sua mãe, que devemos dizer do homem Cristo, cuja carne teve uma
concepção espiritual e não carnal? Pelo seu batismo dignou-se prefigurar o seu corpo, isto é, a Igreja; na
qual sobretudo os batizados recebem o Espírito Santo.

RESPOSTA À SEGUNDA. — Como diz Agostinho, quando a Escritura refere que o Espírito Santo desceu
sobre Cristo sob a forma corpórea de uma pomba, não quer com isso significar que se tivesse tornada
visível a substância mesma do Espírito Santo, que é invisível. Nem que essa criatura visível fosse
assumida na unidade da pessoa divina. Assim, não diz que o Espírito Santo é pomba, como diz que o
Filho de Deus é homem, em razão da união. E nem o Espírito Santo foi visto em forma de pomba, como
João viu o cordeiro imolado no Apocalipse, conforme aí se lê; pois, essa foi uma visão em: espírito,
mediante imagens espirituais dos corpos; ao passo que ninguém duvidou de ter visto realmente a
pomba. Nem o Espírito Santo apareceu sob forma de pomba, no sentido em que o Apóstolo diz - Cristo
porém era pedra; pois, a pedra referida no texto já existia anteriormente em a natureza e por analogia é
designada para significar o nome de Cristo; ao passo que a pomba teve uma rápida aparição só para
significar o Espírito, e depois 'desapareceu, como a chama' aparecida a Moisés na sarça ardente. -
Quando, pois, o Evangelho refere que o Espírito Santo desceu sobre Cristo não era em razão da sua
união com a pomba, mas em razão da pomba mesmo, símbolo do Espírito Santo, descendo sobre Cristo;
ou ainda em razão da graça espiritual que deriva de Deus, descendo sobre a criatura, segundo aquilo da
Escritura: Toda a dádiva em extremo excelente e todo o dom perfeito vem lá de cima e desce do Pai das
luzes.

RESPOSTA À TERCEIRA. — Como diz Crisóstomo, o começo das manifestações do mundo espiritual aos
homens é sempre mediante visões sensíveis, por causa dos incapazes de receber nenhuma inteligência
da natureza incorpórea; de modo que, se essesmesmos sinais não vierem outra vez a reproduzir-se,
fique a fé infundida pelas primeiras aparições. Por isso, sobre Cristo batizado o Espírito Santo desceu
visivelmente sob forma corpórea, para que depois se acreditasse na sua descida invisivelmente sobre
todos os batizados.

RESPOSTA À QUARTA. — O Espírito Santo desceu visivelmente sobre Cristo batizado em forma de
pomba, por quatro razões.
Primeiro, para mostrar a disposição que deve ter o batizado, de não achegar-se ao batismo
dolosamente; pois, como diz a Escritura, o Espírito Santo, mestre da disciplina, fugirá do fingido. Ora, a
pomba é um animal simples, sem astúcia nem dolo, donde o dizer o Evangelho: Sêde simples como as
pombas. Segundo, para designar os sete dons do Espírito Santo que as propriedades da pomba
simbolizam. - Assim, habita a pomba ao longo dos cursos de água, por onde mergulha e foge quando o
gavião a persegue. E isso simboliza o dom da sabedoria, que leva os santos a habitarem perto das águas
da divina Escritura, para fugirem aos ataques do diabo. - Do mesmo modo, a pomba escolhe os
melhores grãos: símbolo do dom da ciência pela qual os santos escolhem como alimento do espírito as
doutrinas sãs. - Igualmente, a pomba cria os filhotes das outras aves: símbolo do dom do conselho pelo
qual os santos educam pela doutrina e pelo exemplo os homens que, pequenos e fracos, foram como os
imitadores do diabo. - Depois, a pomba não dilacera com o bico: símbolo da inteligência, pela qual os
santos não pervertem, dilacerando-a, a sagrada doutrina, ao modo dos heréticos. - Ainda, a pomba não
tem fel: símbolo do dom de piedade, pela qual os santos não nutrem nenhuma cólera irracional. - Em
seguida, a pomba nidifica nas cavas dos rochedos: símbolo do dom da fortaleza, pela qual os santos
edificam o seu ninho na pedra firme das chagas de Cristo morto, isto é, nela buscam o seu refúgio e
colocam as suas esperanças. - Enfim, a pomba tem o gemido por canto: símbolo do dom do temor, pelo
qual os santos se comprazem em gemer pelos pecados. Em terceiro lugar, o Espírito Santo apareceu em
figura de pomba, por causa do efeito do batismo, que é a remissão dos pecados e a reconciliação com
Deus; pois, a pomba é um animal cheio de mansidão. Por isso, Crisóstomo diz que no dilúvio ela
apareceu trazendo um ramo de oliveira e anunciando a paz geral do mundo; e também apareceu no
batismo de Cristo para mostrar-nos o nosso Salvador. Quarto, o Espírito Santo desceu sob a forma de
pomba sobre o Senhor batizado, para mostrar o efeito comum do batismo, que é a construção da
unidade eclesiástica. Donde o dizer o Apóstolo, que Cristo se entregou a si mesmo para apresentar a si
mesmo a Igreja gloriosa sem mácula nem ruga, nem outro algum defeito semelhante, purificando-a no
batismo da água pela palavra da vida. Por isso, o Espírito Santo manifestou-se adequadamente, no
batismo de Cristo, sob a forma de pomba, animal pacífico e gregário. Eis porque diz a Escritura: Uma só
é a minha pomba.
Mas, sobre os Apóstolos o Espírito Santo desceu sob a forma de fogo, por duas razões. - Primeiro, para
mostrar o fervor que lhes devia inflamar o coração para pregarem a Cristo em toda parte, em meio de
quaisquer perseguições. Por isso, apareceu também em forma de línguas de fogo. Donde o dizer
Agostinho: De dois modos o Senhor manifestou visivelmente o Espírito Santo, a saber: pela pomba,
descida sobre o Senhor batizado; e pelo fogo, sobre os discípulos congregados. Lá mostrou-se a
simplicidade; aqui, o fervor. E assim, para não terem dobrez os santificados pelo Espírito, mostrou-se
como pomba; e para que a simplicidade não seja acompanhada da frigidez, sob a forma de fogo. Nem
nos perturbe o fato da divisão das línguas de fogo, pois a pomba representa a unidade. - Segundo,
porque, como diz Crisóstomo (Gregório), quando importava perdoar os delitos, o que o fez o batismo,
era necessária a mansidão, simbolizada pela pomba. Mas, depois que alcançamos a graça; só resta o
tempo do juízo, simbolizado pelo fogo.

## Art. 7 — Se a pomba, sob a forma da qual apareceu o Espírito Santo, era uma pomba verdadeira.
O sétimo discute-se assim. — Parece que a pomba, sob a forma da qual apareceu o Espírito Santo, não
era uma verdadeira pomba.

1. — Pois, o que aparece em figura apenas manifesta-se por semelhança. Ora, o Evangelho diz: Desceu
sobre ele o Espírito Santo em forma corpórea como uma pomba. Logo, não era uma verdadeira pomba,
mas só uma semelhança de pomba.

2. Demais. — Assim, como a natureza nada faz em vão, assim Deus, no dizer de Aristóteles. Ora, como a
pomba, no caso vertente, não apareceu senão para significar alguma causa e logo desaparecer, no dizer
de Agostinho, seria inútil uma pomba verdadeira, pois, o que acabamos de referir podia ser feito por
uma semelhança de pomba. Logo essa pomba não era verdadeira pomba.

3. Demais. — As propriedades de uma coisa nos conduzem ao conhecimento da sua natureza. Se, pois,
essa pomba o fosse verdadeiramente, as suas propriedades exprimiriam a natureza de um animal
verdadeiro, mas não o efeito do Espírito Santo. Logo, não parece que essa pomba o fosse
verdadeiramente.
Mas, em contrário, diz Agostinho: Não o dizemos para significar que Nosso Senhor Jesus Cristo foi quem
só teve um verdadeiro corpo, e que o Espírito Santo se mostrou enganosamente aos olhos dos homens;
mas cremos que ambos tiveram corpos verdadeiros.

SOLUÇÃO. — Como dissemos ao Filho de Deus, que é a verdade do Pai, não convinha recorrer a
nenhuma ficção. Por isso, assumiu um corpo, não fantástico, mas verdadeiro. E sendo o Espírito Santo o
Espírito de Verdade, como diz o Evangelho, por isso também ele formou uma verdadeira pomba pela
qual se manifestasse, embora não na assumisse na unidade de pessoa.
Eis porque, depois das palavras referidas, Agostinho acrescenta: Assim como o Filho de Deus não podia
enganar os homens, assim também não o podia o Espírito Santo. Ora, ao Deus onipotente, que formou
todas as criaturas do nada, não era difícil formar o corpo de uma verdadeira pomba, sem que fosse
nascida de outra, assim como não lhe foi difícil formar um corpo verdadeiro no ventre de Maria, sem a
cooperação masculina. Pois, a natureza material serve ao império e à vontade do Senhor, quer se trate
de formar um homem no ventre de uma mulher, quer de formar uma pomba, como as outras existentes
no mundo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Evangelho diz que o Espírito Santo desceu sob a forma
ou semelhança de pomba, não para excluir uma pomba verdadeira, mas para mostrar que ele próprio
não se manifestou como substancialmente é.

RESPOSTA À SEGUNDA. — Não foi supérfluo formar uma pomba verdadeira para ser a manifestação do
Espírito Santo; pois, essa pomba verdadeira significava a verdade do Espírito Santo e dos seus efeitos.

RESPOSTA À TERCEIRA. — As propriedades da pomba tanto servem de significar a sua natureza como os
efeitos do Espírito Santo. Pois, as suas propriedades mostram que ela significa o Espírito Santo.

## Art. 8 — Se convenientemente se fez ouvir, depois de Cristo batizado, a palavra do Pai, proclamando o seu Filho.
O oitavo discute-se assim. — Parece que inconvenientemente se fez ouvir, depois de Cristo batizado, a
palavra do Pai, proclamando o seu Filho.

1. — Pois, do Filho e do Espírito Santo, por terem aparecido sensivelmente, se diz que foram
'visivelmente mandados. Ora, ao Pai não convém ser mandado, como está claro em Agostinho. Logo,
nem aparecer.

2. Demais. — A voz significa o verbo concebido na mente. Ora, o Pai não é o Verbo. Logo,
inconvenientemente se manifestou pela palavra.

3. Demais. — O homem Cristo não começou a ser Filho de Deus no batismo, como o pensavam certos
heréticos; mas, desde o princípio da sua concepção foi Filho de Deus. Logo, antes na natividade do que
no batismo, que devia ter-se feito ouvir a palavra do Pai, proclamando a divindade de Cristo.
Mas, em contrário, o Evangelho: Eis uma voz dos céus, que dizia - Este é meu filho amado, no qual tenho
posto toda a minha complacência.

SOLUÇÃO. — Como dissemos, pelo seu batismo, que foi o exemplar do nosso, Cristo devia mostrar de
modo incompleto, o que em o nosso aparece consumado. Ora, o batismo que os fiéis recebem é
consagrado pela invocação e pela virtude da Trindade, segundo aquilo do Evangelho: Ide e ensinai a
todas as gentes, batizando-as em nome do Padre e do Filho e do Espírito Santo. E assim, no batismo de
Cristo, como diz Jerônimo, manifesta-se o mistério da Trindade; pois, é o Senhor mesmo, revestido da
natureza humana, o batizado; o Espírito Santo desceu sob a forma de pomba; foi ouvida a palavra do Pai
dando testemunho a seu Filho. Por onde, era conveniente que, nesse batismo, o Pai se manifestasse
verbalmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A missão visível é algo mais que a simples aparição, pois,
implica a autoridade de quem envia.
E assim, do Filho e do Espírito Santo, procedentes de outro, diz-se não só que aparecem, mas também
que são enviados visivelmente. Ao passo que o Pai, que de ninguém procede, pode por certo aparecer,
mas não pode ser visivelmente enviado.

RESPOSTA À SEGUNDA. — O Pai não se manifesta pela palavra, senão como o autor dela ou quem a
profere. E sendo própria do Pai produzir o Verbo, o que é dizer ou falar, por isso e convenientemente o
Pai se manifestou pela palavra, expressão do Verbo. Por isso, a palavra mesma proferida pelo Pai
proclama a filiação do Verbo. E assim como a forma da pomba, pela qual se manifestou o Espírito Santo,
não é a natureza mesma dele; nem a forma humana, pela qual se manifestou O· Filho, é a natureza
mesma do Filho de Deus, assim também a palavra não fez parte da natureza do Verbo ou do Pai, quando
usou dela. Por isso o Senhor diz: Vós nunca ouvistes a sua voz, nem vistes quem o representasse. Com o
que, como adverte Crisóstomo, querendo iniciá-los pouco a pouco na sua sublime filosofia, ensina-lhes
que Deus não usa da palavra nem tem forma, mas é superior a toda figura como a toda palavra. E assim
como toda a Trindade foi a que produziu a pomba e também a natureza humana assumida por Cristo,
assim também formou a palavra. Contudo, por ela se manifestou só o Pai quando falou, assim como só o
Filho foi quem assumiu a natureza humana e como pela pomba só se manifestou o Espírito Santo, como
está claro em Agostinho.

RESPOSTA À TERCEIRA. — A divindade de Cristo não devia manifestar-se a todos, na sua natividade,
mas antes ocultar-se, com as imperfeições da idade infantil. Mas, chegado à idade perfeita, quando
devia ensinar, fazer milagres e converter os homens, então, pelo testemunho do Pai, devia manifestar-
se-Ihe a divindade, para tornar mais crível a sua doutrina. Por onde, ele próprio disse: Meu pai, que me
enviou, esse é que deu testemunho de mim. E isso sobretudo no batismo, pelo qual os homens
renascem como filhos adotivos de Deus; pois, os filhos adotivos de Deus o são por semelhança com o
Filho por natureza, segundo o Apóstolo: Os que ele conheceu na sua presciência, também os
predestinou, para serem conformes à imagem de seu Filho. Donde o dizer Hilário, que o Espírito Santo
desceu sobre Jesus batizado e fez-se ouvir a voz do Pai que dizia: Este é 'meu Filho amado; para nos dar
a conhecer, pelo que se cumpriu em Cristo, que quando formos lavados na água do batismo, das portas
do céu o Espírito Santo desce sobre nós e a voz do Pai nos declara seus filhos adotivos.