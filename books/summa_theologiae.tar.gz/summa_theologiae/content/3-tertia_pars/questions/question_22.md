# Questão 22: Do sacerdócio de Cristo
Em seguida devemos tratar do sacerdócio de Cristo.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se a Cristo convém ser sacerdote.
O primeiro discute-se assim. — Parece que a Cristo não convém ser sacerdote.
1 — Pois, o sacerdote é menor que o anjo, e por isso diz a Escritura: O Senhor me mostrou o sumo
sacerdote Jesus, que estava diante do anjo do Senhor. Ora, Cristo é maior que os anjos, segundo o
Apóstolo: Feito tanto mais excelente que os anjos, quanto herdou mais excelente nome que eles. Logo,
a Cristo não convém ser sacerdote.

2. Demais. — No Antigo Testamento estavam as figuras de Cristo, segundo o Apóstolo: Que são sombra
das causas vindouras, mas o corpo é em Cristo. Ora. Cristo não era carnalmente descendente dos
sacerdotes da lei antiga; assim, diz o Apóstolo: Manifesta coisa é que da linhagem de Judá nasceu Nosso
Senhor; na qual tribo nada falou Moisés tocante aos sacerdotes. Logo, a Cristo não convém ser
sacerdote.

3. Demais. — Na lei antiga, que é figura de Cristo, não era o mesmo o legislador e o sacerdote, donde o
dizer o Senhor a Moisés, legislador: Faze chegar a ti Arão, teu irmão, para que exercite diante de mim as
funções do sacerdócio. Ora, Cristo é o legislador da lei nova, segundo a Escritura: Imprimirei a minha lei
nas suas entranhas. Logo, a Cristo não convém ser sacerdote.
Mas, em contrário, o Apóstolo: Temos aquele pontífice que penetrou os céus, Jesus, Filho de Deus.

SOLUÇÃO. — O ofício próprio do sacerdote é ser mediador entre Deus e o povo, porque transmite ao
povo os dons divinos, chamando-se sacerdote por ser o como dados das coisas sacras, segundo aquilo
da Escritura: Da sua boca, isto é, do sacerdote, os mais buscarão a inteligência da lei. E também por ser
quem oferece a Deus as preces do povo, e de certo medo satisfaz a Deus pelos pecados dele. Donde o
dizer o Apóstolo: Todo pontífice assunto dentre os homens é constituído o favor dos homens naquelas
causas que tocam a Deus, para que ofereça dons e sacrifícios pelos pecados. Ora, isto sobremaneira
convém a Cristo. Pois por ele, os bens divinos foram conferidos aos homens, segundo aquilo da
Escritura: Pelo qual, isto é, por Cristo, nos comunicou as mui grandes e preciosas graças, que tinha
prometido, para que por elas sejais feitos participantes da natureza divina. E também ele reconciliou o
gênero humano com Deus, segundo o Apostolo: Foi do agrado do Pai que nele, isto é, em Cristo.
residisse toda a plenitude e o reconciliar por ele a si mesmo todas as coisas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O poder hierárquico convém aos anjos, enquanto
medianeiros entre Deus e os homens, como está claro em Dionísio; por isso o sacerdote, enquanto
medianeiro entre Deus e o povo, tem o nome de anjo, segundo a Escritura: É o anjo do Senhor dos
exércitos. Ora, Cristo foi maior que os anjos, não só pela divindade, mas também pela humanidade, por
ter a plenitude da graça e da glória. Por onde e de modo mais excelente, teve, acima dos anjos, o poder
hierárquico ou sacerdotal, de modo tal que os próprios anjos lhe foram ministros do sacerdócio, como
se lê no Evangelho: Chegaram os anjos e o serviam. Mas, pela passibilidade da carne, por um pouco foi
feito menor que os anjos, no dizer do Apóstolo. E, assim, foi comparável aos mortais constituídos
sacerdotes.

RESPOSTA À SEGUNDA. — Como diz Damasceno, duas coisas em tudo iguais são idênticas e não,
semelhantes. Ora, sendo o sacerdócio da lei antiga a figura do sacerdócio de Cristo, não quis Cristo
nascer da estirpe dos sacerdotes, que o figuravam, para mostrar que o seu sacerdócio não era
absolutamente idêntico ao deles, mas que diferia como o verdadeiro, do figurado.

RESPOSTA À TERCEIRA. — Como dissemos, os outros homens tem certas graças particulares; mas
Cristo, enquanto cabeça de todos, tem a perfeição de todas as graças. Por onde, no atinente aos mais, o
legislador difere do sacerdote, que difere do rei; ao passo que Cristo era tudo isso ao mesmo tempo,
como a fonte de todas as graças. Donde o dizer a Escritura: O Senhor é o nosso juiz, o Senhor o nosso
legislador, o Senhor o nosso rei, ele mesmo nos salvará.

## Art. 2 — Se Cristo foi ao mesmo tempo sacerdote e vítima.
O segundo discute-se assim. — Parece que Cristo não foi ao mesmo tempo sacerdote e vítima.
1 — Pois, é função do sacerdote imolar a vitima. Ora, Cristo não se imolou a si mesmo. Logo, não foi
simultaneamente sacerdote e vítima.

2. Demais. — O sacerdócio de Cristo era mais semelhante ao sacerdócio dos Judeus, instituído por Deus,
que ao sacerdócio dos gentios, adoradores do demônio. Ora, na lei antiga, nunca o homem era
oferecido em sacrifício, o que a Escritura sobretudo incrimina nos sacrifícios gentílicos, quando diz:
Derramaram o sangue inocente, o sangue de seus filhos e de suas filhas, que haviam sacrificado aos
ídolos de Canaã, Logo, o sacerdócio de Cristo não devia ter o próprio homem Cristo como vítima.

3. Demais. — Toda hóstia, por ser oferecida a Deus, é santificada por Deus. Ora a humanidade mesma
de Cristo foi desde o princípio santificada por Deus, com quem estava unida. Logo, não podemos
convenientemente dizer que Cristo, enquanto homem, fosse vítima.
Mas, em contrário, o Apóstolo: Cristo nos amou e se entregou a si mesmo por nós outros, como
oferenda e hóstia a Deus em odor de suavidade.

SOLUÇÃO. — Como diz Agostinho, todo sacrifício visível é sacramento, isto é, sinal sagrado, do sacrifício
invisível. Ora, pelo sacrifício invisível, o homem oferece a Deus o seu espírito, segundo aquilo da
Escritura: Sacrifício para Deus é o espírito tributado. Por onde, tudo o oferecido a Deus, para elevarmos
a ele o nosso espírito, pode chamar-se sacrifício.
Ora, o homem precisa de sacrifícios por três razões. — Primeiro, para remissão dos pecados, que o
afastam de Deus. E por isso diz o Apóstolo, que ao sacerdote pertence oferecer dons e sacrifícios pelo
pecado. — Segundo, para conservar-se em estado de graça, sempre unido a Deus, que lhe constitui a
paz e a salvação. Por isso, na lei antiga imolavam-se hóstias pacíficas pela saúde dos oferentes, como se
lê na Escrituras. — Terceiro, para o seu espírito se unir perfeitamente com Deus, o que sobretudo se
dará na glória. Por isso, na lei antiga oferecia-se o holocausto, que quer dizer como totalmente
queimado.
Ora, tudo isso nos resultou da humanidade de Cristo. — Assim, primeiro, os nossos pecados foram
delidos, conforme àquilo do Apóstolo: Foi entregue por nossos pecados. — Segundo, por ele recebemos
a graça salvífica, como se lê no Apóstolo: Veio a fazer-se autor da salvação eterna para todos os que lhe
obedecerem. — Terceiro, por alcançarmos a perfeição da glória, ainda no dizer do Apóstolo: Temos
confiança de entrar no santuário, pelo seu sangue, isto é, na glória celeste. Por onde, o próprio Cristo,
enquanto homem, não só foi sacerdote, mas também hóstia perfeita, ao mesmo tempo hóstia pelo
pecado, hóstia pacífica e holocausto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo não se imolou a si mesmo, mas se expôs
voluntariamente à morte, conforme o diz a Escritura: Foi oferecido porque ele mesmo quis. Por isso
dizemos que ele se ofereceu.

RESPOSTA À SEGUNDA. — A imolação do homem Cristo é relativa a uma dupla vontade. - Primeiro, à
vontade dos que o imolaram. E então, não tem natureza de vítima; pois, não dizemos que os imoladores
de Cristo ofereceram uma hóstia a Deus, mas que delinquiram gravemente. E semelhança desse pecado
eram os ímpios sacrifícios dos Gentios, nos quais imolavam homens aos ídolos. - Noutro sentido,
podemos considerar a imolação de Cristo relativamente à sua vontade de paciente, que
voluntariamente se ofereceu à paixão. E por aí tem natureza de vítima. No que não convém com os
sacrifícios dos Gentios.

## Art. 3 — Se o efeito do sacerdócio de Cristo é a expiação dos pecados.
O terceiro discute-se assim. — Parece que o efeito do sacerdócio de Cristo não é a expiação dos
pecados.

1. — Pois, só Cristo pode apagar os pecados, conforme àquilo da Escritura: Eu sou o que apaga as tuas
iniquidades. Ora, Cristo não é sacerdote enquanto Deus, mas enquanto homem. Logo, o sacerdócio de
Cristo não é expiativo dos pecados.

2. Demais. — O Apóstolo diz que as vítimas do Antigo Testamento não podiam fazer perfeitos; doutra
sorte teriam elas cessado de se oferecer, pelo motivo de que não teriam de ali em diante consciência de
pecado algum os ministros que uma vez fossem purificados; mas nos mesmos sacrifícios se faz memória
dos pecados todos os anos. Ora, semelhantemente, no sacrifício de Cristo há uma comemoração de
pecados, quando se diz — Perdoai-nos as nossas dívidas. E também é oferecido continuamente o
sacrifício na Igreja, donde o dizer-se ainda — o Pão nosso de cada da nos dai hoje. Logo, pelo sacerdócio
de Cristo não se expiam os pecados.

3. Demais. a lei antiga sobretudo era imolado um bode pelo pecado do príncipe; ou uma cabra pelo
pecado de alguém do povo; ou um vitela, pelo pecado do sacerdote, como se lê na Escritura. Ora, Cristo
a nenhum desses animais é comparado, mas ao cordeiro, como se lê na Escritura: Eu era como um
manso cordeiro, que é levado a ser vítima. Logo, parece que o seu sacerdócio não é expiativo dos
pecados.
Mas, em contrário, o Apóstolo: O sangue de Cristo, que pelo Espírito Santo se ofereceu a si mesmo sem
mácula a Deus, alimpará a nossa consciência das obras da morte, para servir ao Deus vivo. Ora, obras da
morte chamam-se os pecados. Logo, o sacerdócio de Cristo tem a virtude de purificar os pecados.

SOLUÇÃO. — Duas condições são necessárias para a perfeita purificação dos pecados, pois que duas
coisas há no pecado, o saber, a mácula da culpa e o reato da pena. Quanto à mácula da culpa, ela se
apaga pela graça, que converte para Deus o coração do pecador; e quanto ao reato da pena, fica
totalmente eliminado pelo satisfazer do homem a Deus Ora, ambos esses efeitos os realizou o
sacerdócio de Cristo. Assim, pela sua virtude, foi-nos dada a graça, pela qual os nossos corações se
convertem a Deus, segundo aquilo do Apóstolo: Tendo sido justificados gratuitamente por sua graça,
pela redenção que tem em Jesus Cristo, ao qual propôs Deus para ser vítima de propiciação pela fé no
seu sangue. E também ele plenariamente satisfez por nós, enquanto tornou sobre si as nossas fraquezas
e ele mesmo carregou com as nossas dores. Por onde é claro que o sacerdócio de Cristo tem plena
virtude de expiar os pecados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora Cristo não fosse sacerdote, enquanto Deus, mas
enquanto homem, contudo ele mesmo foi sacerdote e simultaneamente Deus. E por isso se lê no Sínodo
Efesino: Quem disser, que aquele que se fez nosso Pontífice e Apóstolo não foi o Verbo de Deus, mas
um como homem especialmente nascido da mulher e diferente dele, seja anátema. Por onde, na
medida em que a sua humanidade obrava em virtude da divindade, o seu sacrifício foi eficacíssimo para
apagar os pecados. Donde o dizer Agostinho: Em todo sacrifício quatro causas se consideram — a quem
é oferecido, por quem é oferecido,. o que; oferecido, por quem é oferecido. Por onde, Cristo, sendo o
único e verdadeiro mediador, que nos reconciliou com Deus pelo sacrifício da paz, permanecia um com
aquele a quem oferecia, reduziu em si à unidade todos aqueles por quem oferecia, e era uma mesma
unidade, ele que oferecia, com o que oferecia.

RESPOSTA À SEGUNDA. — Os pecados não lembram, na lei nova, por causa da ineficácia do sacerdócio
de Cristo, como se por ele os pecados não estivessem suficientemente expiados. Mas, são lembrados,
relativamente àqueles que ou não lhe querem participar do sacrifício, como os infiéis, por cujos pecados
oramos, para que se convertam; ou também relativamente àqueles, que depois de terem participado,
desse sacrifício, desviam-se de qualquer modo dele, pelo pecado. Quanto ao sacrifício que
quotidianamente na Igreja se oferece, não é diverso do sacrifício que Cristo mesmo ofereceu. mas,
comemoração dele. E por isso diz Agostinho: O próprio Cristo, que ofereceu o sacrifício, foi a oblação
dele; cujo sinal sagrado e quotidiano, quer que fosse o sacrifício da Igreja.

RESPOSTA À TERCEIRA. — Como diz Orígenes, embora na lei antiga se oferecessem diversos animais,
contudo o sacrifício quotidiano, que era oferecido de manhã e de tarde, era o cordeiro, como se lê na
Escritura. E por isso significava, que a oblação do verdadeiro cordeiro, isto é, de Cristo, seria o sacrifício
consumativo de todos os outros. Donde o dizer a Escritura: Eis aqui o cordeiro de Deus, eis aqui o que
tira o pecado do mundo.

## Art. 4 — Se o efeito do sacerdócio de Cristo não só pertencia aos outros, mas também a ele próprio.
O quarto discute-se assim. — Parece que o efeito do sacerdócio de Cristo não pertencia só aos outros,
mas também a ele próprio.

1. — Pois, é ofício do sacerdote orar pelo povo, segundo aquilo da Escritura: Os sacerdotes estavam
fazendo oração enquanto o sacrifício se consumava. Ora, não somente orou pelos outros, mas também
por si mesmo, como se disse e como expressamente o afirma o Apóstolo, quando escreve que nos dias
da sua mortalidade ofereceu com um grande brado e com lágrimas preces e rogos a Deus que o podia
salvar da morte. Logo, o sacerdócio de Cristo teve o efeito não só para os outros mas também para si.

2. Demais. — Cristo ofereceu-se a si mesmo em sacrifício, na sua paixão. Ora, pela sua paixão mereceu
não somente pelos outros, mas também para si, como se estabeleceu. Logo, o sacerdócio de Cristo
produziu efeito não só para os outros mas também para si.

3. Demais. — O sacerdócio da lei antiga foi figura do sacerdócio de Cristo. Ora, o sacerdote da lei antiga
oferecia sacrifício não só pelos outros, mas também por si mesmo, no dizer da Escritura: O pontífice
entra no santuário para orar por si e pela sua casa e por todo o ajuntamento de Israel. Logo, também o
sacerdócio de Cristo produziu efeito não só para ele próprio, mas ainda para os outros.
Mas, em contrário, lê-se no Sínodo Efesino: Quem disser que Cristo ofereceu sacrifício por si e não,
antes, só por nós — pois não precisava de sacrifício quem era isento de pecado — esse seja anátema.
Ora, o ofício do sacerdote consistia sobretudo em oferecer sacrifícios. Logo, o sacerdócio de Cristo
nenhum efeito produziu para Cristo.

SOLUÇÃO. — Como dissemos, o sacerdote é constituído medianeiro entre Deus e o povo. Ora, precisa
de um medianeiro quem por si só não pode chegar a Deus; e por isso depende do sacerdócio e participa
do efeito dele. Ora, de tal não precisava Cristo e assim diz o Apóstolo: Chegando-se por si mesmo a
Deus, vivendo sempre para interceder por nós. Por isso não cabia a Cristo beneficiar do efeito do
sacerdócio; ao contrário, comunicava-o ele aos outros. Pois, o agente primeiro, em qualquer gênero, é,
nesse gênero, influente e não recipiente; assim, o sol ilumina e não é iluminado e o fogo não é aquecido,
que aquece. Ora, Cristo é a fonte de todo sacerdócio; pois, se figura dele era o sacerdócio da lei, o
sacerdote da lei nova obra, na pessoa dele, segundo aquilo do Apóstolo: Pois eu a indulgência de que
usei, se de alguma tenho usado, foi por amor de vós em pessoa de Cristo. Por isso não cabia a Cristo
beneficiar do efeito do sacerdócio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A oração, embora própria dos sacerdotes, contudo não é
o ofício peculiar deles; pois, qualquer pode orar por si e por outrem, segundo a Escritura: Orai uns pelos
outros para serdes salvos. E assim, poderíamos dizer que a oração, na qual Cristo rogou por si, não era
ato de sacerdócio seu. Mas essa resposta fica excluída pelas Palavras que o Apóstolo, depois de ter dito
— Tu és sacerdote eternamente, segundo a ordem de Melquisedeque acrescenta: O qual nos dias da
sua mortalidade, preces etc., como acima; e assim, a oração feita por Cristo pertencia-lhe ao sacerdócio.
E por isso devemos dizer, que os outros sacerdotes participam-lhe o efeito do sacerdócio, não enquanto
sacerdotes, mas enquanto pecadores, como mais abaixo diremos. Ora Cristo, absolutamente falando,
não teve nenhum pecado. Mas teve na sua carne a semelhança do pecado. Por isso não devemos, em
sentido absoluto, afirmar que participou do efeito do sacerdócio; mas só, de certo modo, isto é, pela
passibilidade da carne. Donde o dizer sinaladamente: Que o podia salvar da morte.

RESPOSTA À SEGUNDA. — Na oblação do sacrifício de qualquer sacerdote duas coisas podemos
considerar: o sacrifício mesmo oferecido e a devotação do .oferente. Ora, o efeito próprio do sacerdócio
é o resultado mesmo do sacrifício. Ora, Cristo alcançou, pela sua paixão, a glória do ressurgir; não quase
em virtude do sacrifício, oferecido a modo de satisfação, mas pela devotação mesma, pelo qual sofreu a
paixão humildemente e segundo a caridade.

RESPOSTA À TERCEIRA. — A figura não pode adequar-se à verdade. Por isso o sacerdócio figurado da lei
antiga não podia chegar à perfeição de não precisar do sacrifício satisfatório, do qual Cristo não
precisava. Por onde, não há semelhanças de razão em ambos os casos. E tal é o que diz o Apóstolo: A lei
constituiu sacerdotes a homens que tem enfermidade; mas a palavra do juramento, que é depois da lei,
constitui ao Filho perfeito eternamente.

## Art. 5 — Se o sacerdócio de Cristo permanece eternamente.
O quinto discute-se assim. — Parece que o sacerdócio de Cristo não permanece eternamente.

1. — Pois, como se disse, só precisam do efeito do sacerdócio os contaminados pela enfermidade do
pecado, que pode ser expiada pelo sacrifício do sacerdote. Ora, isso não se dará nunca, porque os
santos não tem nenhum pecado, segundo aquilo da Escritura: O teu povo serão todos os justos; e
quanto ao pecado dos pecadores será inexpiável, porque não há para o inferno nenhuma redenção.
Logo, o sacerdócio de Cristo não é eterno.

2. Demais. — O sacerdócio de Cristo sobretudo se manifestou pela sua paixão e morte, quando pelo seu
próprio sangue entrou no santuário, como diz o Apóstolo. Ora, Cristo não sofrerá paixão nem morrerá
eternamente, segundo o Apóstolo: Tendo Cristo ressurgido dos mortos, já não morre. Logo, o
sacerdócio de Cristo não é eterno.

3. Demais. — Cristo é sacerdote, não enquanto Deus, mas enquanto homem. Ora, Cristo algum tempo
não foi homem, isto é, no tríduo da sua morte. Logo, o sacerdócio de Cristo não é eterno.
Mas, em contrário, a Escritura: Tu és sacerdote eternamente.

SOLUÇÃO. — No ofício do sacerdote duas coisas, podemos considerar: primeiro, a oblação mesma; do
sacrifício; segundo, a consumação do sacrifício, consistente em lhe alcançarem o fim aqueles por quem
é oferecido. Ora, o fim do sacrifício que Cristo ofereceu não foram os bens temporais, mas os eternos,
que pela sua morte alcançamos. Por isso diz o Apóstolo, que Cristo é o Pontífice presente dos bens
vindouros; em razão do que se diz ser eterno o sacerdócio de Cristo. E essa consumação do sacrifício de
Cristo foi prefigurada no fato mesmo de que o pontífice da lei entrava uma vez no ano no santo dos
santos com o sangue de um bode e de um novilho, como lemos na Escritura; embora o bode e o novilho
não os imolasse no santo dos santos, mas fora. Semelhantemente, Cristo entrou no santo dos santos,
isto é, no céu, e nos preparou o caminho para nele entrarmos por virtude do seu sangue, que por nós
derramou em terra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os santos que estiverem na pátria, não precisam mais de
expiar, pelo sacerdócio de Cristo; mas, tendo já expiado, precisarão de consumar, mediante o mesmo
Cristo, de quem lhes depende a glória. Donde o dizer a Escritura: A claridade de Deus a alumia, isto é, a
cidade dos santos, e a lâmpada dela é o Cordeiro.

RESPOSTA À SEGUNDA. — Embora a paixão e a morte de Cristo não devam renovar-se para o futuro,
contudo a virtude de uma tal vítima, já oferecida, permanece eternamente; pois, como diz o Apóstolo,
com uma só oferenda fez perfeitos para sempre os que tem santificado.
Donde se deduz clara A RESPOSTA À TERCEIRA OBJEÇÃO. — Mas a unidade dessa oblação era figurada
na lei pelo fato de uma vez no ano o pontífice da lei entrar no santo dos santos com a solene oblação,
como se lê na Escritura. Mas a verdade da figuração não era completa por não ter essa vítima uma
virtude sempiterna, e por isso haver necessidade de ser renovada anualmente.

## Art. 6 — Se o sacerdócio de Cristo era segundo a ordem de Melquisedeque.
O sexto discute-se assim. — Parece que o sacerdócio de Cristo não era segundo a ordem de
Melquisedeque.

1. — Pois, Cristo é a fonte de todo sacerdócio, como sacerdote principal. Ora, o principal não depende
da ordem alheia, antes, esta é que depende daquele. Logo, Cristo não deve ser chamado sacerdote
segundo a ordem Melquisedeque.

2. Demais. — O sacerdócio da lei antiga estava mais próximo do sacerdócio de Cristo do que o
sacerdócio anterior ao da lei. Ora, os sacramentos tanto mais expressamente significavam a Cristo,
quanto mais próximos dele estavam, como resulta do que foi dito na Segunda Parte. Logo, o sacerdócio
de Cristo deve ser antes denominado segundo o Sacerdócio da lei, que segundo o sacerdócio de
Melquisedeque, anterior à lei.

3. Demais. — O Apóstolo diz, que o rei da paz, sem pai nem mãe, sem genealogia, não tem princípio de
dias nem fim de vida, coisas que convêm só ao Filho de Deus. Logo, Cristo não deve chamar-se
sacerdote segundo a ordem de Melquisedeque, como se fosse de outrem; mas, segundo a sua própria
ordem.
Mas, em contrário, diz a Escritura: Tu és sacerdote eternamente segundo a ordem de Melquisedeque.

SOLUÇÃO. — Como dissemos, o sacerdócio legal foi a figura do sacerdócio de Cristo; não que o
exprimisse verdadeira e adequadamente, pois dele muito distava. Quer porque o sacerdócio legal não
purificava dos pecados, quer também porque não era eterno, como o sacerdócio de Cristo. Mas a
excelência do sacerdócio de Cristo sobre o sacerdócio levítico foi figurado no sacerdócio de
Melquisedeque, que recebeu dízimos de Abraão, de cujos lombos recebia dízimos, de certo modo, o
sacerdócio da lei. Por onde, o sacerdócio de Cristo é chamado segundo à ordem de Melquisedeque, por
causa da excelência do verdadeiro sacerdócio sobre o sacerdócio figurado da lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo não é considerado como da ordem de
Melquisedeque, quase de um sacerdote mais principal; mas como do que prefigura a excelência do
sacerdócio de Cristo sobre o sacerdócio levítico.

RESPOSTA À SEGUNDA. — Duas coisas podemos considerar no sacerdócio de Cristo: a oblação mesma
de Cristo e a sua participação. Quanto à oblação, o sacerdócio da lei mais expressamente figurava, pela
efusão do sangue, o sacerdócio de Cristo, que o sacerdócio de Melquisedeque, onde não havia essa
efusão. Mas, quanto à participação do sacrifício de Cristo e do seu efeito, pela qual principalmente se
lhe manifesta a excelência do sacerdócio sobre o sacerdócio da lei, ele era mais expressamente
prefigurado pelo sacerdócio de Melquisedeque, que oferecia pão e vinho, significativos, como diz
Agostinho, da união eclesiástica, constituída pela participação do sacrifício de Cristo. Por isso também
na lei nova o verdadeiro sacrifício de Cristo é comunicado aos fiéis sob a espécie de pão e de vinho.

RESPOSTA À TERCEIRA. — Diz-se que Melquisedeque é sem pai nem mãe e sem genealogia, e que não
tem princípio de dias nem fim de vida, não pelos não ter, mas por não lermos na Escritura que os
tivesse. E por isso mesmo, como diz o Apóstolo no mesmo lugar, foi feito semelhante ao Filho de Deus,
que não tem na terra pai e, no céu, não tem mãe nem genealogia, conforme àquilo da Escritura: Quem
contara a sua geração? E, segundo a divindade, não tem princípio nem fim de dias.