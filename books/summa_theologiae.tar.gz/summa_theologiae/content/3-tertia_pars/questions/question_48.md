# Questão 48: Do modo da paixão de Cristo
Em seguida devemos tratar do efeito da paixão de Cristo. E, primeiro do modo pelo qual o produziu.
Segundo, do efeito em si. Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a Paixão de Cristo causou a nossa salvação a modo de mérito.
O primeiro discute-se assim. — Parece que a Paixão de Cristo não causou a nossa salvação a modo de
mérito.

1. — Pois, os princípios das paixões não estão em nós. Ora, ninguém merece nem é louvado senão em
virtude de um princípio em si existente. Logo, a Paixão de Cristo nada operou em nós a modo de mérito.

2. Demais. — Cristo desde o princípio da sua concepção mereceu tanto para si como para nós, segundo
se disse. Ora, é supérfluo merecer alguém de novo o que já antes merecera. Logo, Cristo pela sua Paixão
não mereceu a nossa salvação.

3. Demais. — A raiz do mérito é a caridade. Ora, a caridade de Cristo não aumentou mais na Paixão, que
antes. Logo, não mereceu a nossa salvação mais, sofrendo, que antes.
Mas, em contrário, àquilo do Apóstolo — Pelo que Deus o exaltou - diz Agostinho: A humildade da
paixão é o mérito da glória; a glória é o prêmio da humildade. Ora, Cristo foi o glorificado, não só em si
mesmo, mas também nos seus fiéis, como ele próprio o disse. Logo, parece que Cristo mereceu a
salvação dos seus fiéis.

SOLUÇÃO. — Como dissemos, a Cristo foi dada à graça, não só como a uma pessoa singular, mas
enquanto cabeça da Igreja, de modo que dele redundasse para os membros dela. Por isso as obras de
Cristo estão para o mesmo e para as suas obras, assim como estão às obras de um homem constituído
em graça para com ele próprio. Ora, é manifesto que quem, constituído em graça, sofre pela justiça, por
isso mesmo merece para si a salvação, segundo aquilo do Apóstolo: Bem-aventurados os que padecem
perseguição por amor da justiça. Por onde, Cristo, pela sua paixão, merecem a salvação não somente
para si mas também para todos os seus membros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Apaixão, como tal, procede de um princípio exterior.
Mas, enquanto sofrida por um paciente voluntariamente, procede de um princípio interno.

RESPOSTA À SEGUNDA. — Cristo, desde o princípio da sua concepção, mereceu-nos a salvação eterna.
Mas, de nosso lado, certos impedimentos constituíam um obstáculo a conseguirmos o efeito dos
méritos precedentes. Por isso, a fim de remover esses impedimentos é que Cristo teve de sofrer, como
dissemos.

RESPOSTA À TERCEIRA. — A Paixão de Cristo teve certo efeito que não tiveram os méritos precedentes;
não por causa de uma caridade maior, mas pelo gênero da obra, que era concordante com esse efeito,
como ficou claro pelas razões supra - aduzidas referentes à conveniência da Paixão de Cristo.

## Art. 2 — Se a Paixão de Cristo causou a nossa salvação a modo de satisfação.
O segundo discute-se assim. — Parece que a Paixão de Cristo não causou a nossa salvação a modo de
satisfação.

1. — Quem pecou é que deve dar satisfação, como demonstram as outras partes da penitência; assim,
quem pecou deve arrepender-se e confessar o pecado. Ora, Cristo não pecou segundo o diz a Escritura:
O qual não cometeu pecado. Logo, não satisfez pela sua Paixão própria.

2. Demais. — Não satisfazemos a ninguém por meio de uma ofensa maior. Ora, a ofensa máxima foi a
perpetrada na Paixão de Cristo; pois, pecaram gravissimamente os que o mataram como dissemos.
Logo, parece que pela Paixão de Cristo não podia Deus ser satisfeito.

3. Demais. — A satisfação implica uma certa igualdade com a culpa, por ser um ato de justiça. Ora,
parece que a Paixão de Cristo não foi igual a todos os pecados do gênero humano, porque Cristo não
sofreu nas divindades, mas na sua carne, segundo aquilo da Escritura: Havendo, pois, Cristo padecido na
carne. Ora, a alma que é a contaminada pelo pecado, é superior à carne. Logo, pela sua Paixão Cristo
não satisfez pelos nossos pecados.
Mas, em contrário, da sua pessoa diz a Escritura: Paguei então o que não tinha roubado. Ora, não pagou
o que perfeitamente não satisfez. Logo, pela sua Paixão Cristo satisfez perfeitamente pelos nossos
pecados.

SOLUÇÃO. — Propriamente satisfaz pela ofensa, quem oferece o que ama tanto ou mais oque odeia a
ofensa. Ora, Cristo, sofrendo por obediência e caridade, ofereceu a Deus um bem maior do que o
exigido pela recompensa da ofensa total do gênero humano. Assim, primeiro, pela grandeza da
caridade, pelo qual sofria. Segundo, pela dignidade de sua vida, que oferecia em satisfação, que era a
vida de Deus e do homem. Terceiro, por causa da generalidade da Paixão e da grandeza da dor
assumida, como dissemos. Por onde, a Paixão de Cristo foi uma satisfação só suficiente, mas também
superabundante pelos pecados do gênero humano, segundo aquilo do Evangelho: Ele é a propiciação
pelos nossos pecados, e não somente pelos nossos, mas também pelos de todo o mundo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A cabeça e os membros constituem uma como pessoa
mística. Por isso a satisfação de Cristo pertence a todos os fiéis, como aos seus membros. Assim,
também quando dois homens estão unidos pela caridade, um pode satisfazer por outro, como a seguir
se dirá. Mas o mesmo não se dá com a confissão e o arrependimento; porque a satisfação consiste num
ato exterior, para o qual se podem empregar instrumentos, entre os quais se contam também os
amigos.

RESPOSTA À SEGUNDA. — Maior foi à caridade de Cristo na sua Paixão do que a malícia dos que o
crucificaram. Por isto Cristo pôde satisfazer mais pela sua Paixão, do que ofendê-lo os que o
crucificaram e o mataram. Porquanto a Paixão de Cristo foi suficiente e superabundante para satisfazer
pelos pecados dos que o mataram.

RESPOSTA À TERCEIRA. — A dignidade da carne de Cristo não deve ser a validade só pela natureza da
carne, mas pela pessoa assumente; isto é, enquanto carne de Deus, donde lhe derivava a dignidade
infinita.

## Art. 3 — Se a Paixão de Cristo se realizou a modo de sacrifício.
O terceiro discute-se assim. — Parece que a Paixão de Cristo não se realizou a modo de sacrifício.

1. — Pois, a realidade deve corresponder à figura. Ora, nos sacrifícios da lei antiga, que eram a figura de
Cristo, nunca era oferecida a carne humana; ao contrário, esses sacrifícios eram considerados como
nefandos, segundo se lê na Escritura: Derramavam o sangue inocente, o sangue de seus filhos e de suas
filhas, que haviam sacrificado aos ídolos de Canaam. Logo, parece que a Paixão de Cristo não pode ser
chamada sacrifício.

2. Demais. — Agostinho diz que o sacrifício visível é o sacramento, isto é, sacro sinal do sacrifício
invisível. Ora, a Paixão de Cristo não é um sinal, mas antes, foi significada por outros sinais. Logo, parece
que a Paixão de Cristo não foi um sacrifício.

3. Demais. — Quem quer que ofereça um sacrifício faz algo de sagrado, como o demonstra a palavra
mesma de sacrifício. Ora, os que mataram a Cristo nada fizeram de sagrado; ao contrário, perpetraram
uma grande malícia. Logo a Paixão de Cristo foi antes um malefício que um sacrifício.
Mas, em contrário, o Apóstolo: Entregou-se a si mesmo por nós outros, como oferenda e hóstia a Deus
em odor de suavidade.

SOLUÇÃO. — Chama-se sacrifício em sentido próprio o que é feito como uma honra propriamente
devida a Deus, com o fim de o aplacar. E por isso diz Agostinho: É verdadeiramente sacrifício toda obra
feita com o fim de nos unirmos com Deus numa sociedade santa; isto é, uma obra referida ao fim bom,
cuja posse é capaz de nos dar verdadeiramente a felicidade. Ora, Cristo, como no mesmo lugar se
acrescenta, se ofereceu a si mesmo a sofrer por nós; e o próprio fato de ter padecido voluntàriamente a
sua Paixão foi sobremaneira aceito de Deus, como proveniente de uma caridade máxima. Por onde é
manifesto, que a Paixão de Cristo foi um verdadeiro sacrifício. E como Agostinho acrescenta a seguir, no
mesmo livro, os sacrifícios primitivos dos santos foram sinais variados e múltiplos desse verdadeiro
sacrifício, esse sacrifício único foi simbolizado por numerosos sacrifícios, do mesmo modo que uma
mesma realidade é designada por numerosas palavras, a fim de que fosse grandemente recomendado,
sem nenhum inútil encarecimento. Mas, continua Agostinho, consideramos quatro elementos num
sacrifício: aquele a quem o oferecemos, quem o oferece, o que é oferecido e por quem o é. Assim, o
mesmo, só único e verdadeiro mediador, reconciliando-nos com Deus pelo sacrifício da paz, devia
permanecer uno com aquele a quem oferecia esse sacrifício, reunir em si, numa unidade, aqueles por
quem o oferecia, e ser simultânea e identicamente o oferente e a oferenda.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a realidade corresponda à figura, de certo
modo, não corresponde totalmente, pois, a verdade há de necessàriamente ultrapassar a figura. Por isso
e convenientemente a figura deste sacrifício pelo qual a carne de Cristo é oferecida por nós, foi a carne,
não dos homens, mas de animais irracionais que significavam a carne de Cristo. A carne de Cristo é o
perfeitíssimo dos sacrifícios pelas razões seguintes. Primeiro porque, sendo carne de natureza humana,
é convenientemente oferecida pelos homens, que a tomam sob a forma de sacramento. Segundo,
porque, sendo passível e mortal, era apta para a imolação. Terceiro, porque, sendo isenta de pecado,
tinha a eficiência para purificar dos pecados. Quarto, porque, sendo a carne mesma do oferente, era
aceita de Deus por causa da caridade com que a oferecia. Donde o dizer Agostinho: Que oferenda
podiam os homens tomar, que lhes fosse mais adaptada, que uma carne humana? Que de mais apto à
imolação do que uma carne mortal? Que haveria de mais puro para delir os vícios dos mortais que uma
carne nascida sem o contágio da concupiscência carnal, de um ventre e de um ventre virginal? Que
poderia ser oferecido e aceito com mais graça que a carne de nosso sacrifício, tornado o corpo de nosso
Sacerdote?

RESPOSTA À SEGUNDA. — Agostinho, no lugar aduzido, refere-se aos sacrifícios visíveis figurados. E,
contudo a Paixão mesma de Cristo, embora fosse significada por outros sacrifícios figurados, é contudo
o sinal de uma realidade que nós devemos guardar, segundo aquilo da Escritura: Havendo pois Cristo
padecido na carne, armai-vos também vós outros desta mesma consideração: que aquele que padeceu
na carne cessou de pecados; de sorte que o tempo que lhe resta da vida mortal, ele não vive mais
segundo as paixões do homem, mas segundo a vontade de Deus.

RESPOSTA À TERCEIRA. — A Paixão de Cristo, relativamente aos que o mataram, foi um malefício; foi
porém um sacrifício por parte dele mesmo, que sofreu levado da caridade. Por isso se diz, que quem
ofereceu esse sacrifício foi o próprio Cristo e não os que o mataram.

## Art. 4 — Se a Paixão de Cristo obrou a nossa salvação a modo de redenção.
O quarto discute-se assim. — Parece que a Paixão de Cristo não obrou a nossa salvação a modo de
redenção.

1. — Pois, ninguém compra ou redime o que nunca deixou de lhe pertencer. Ora, os homens nunca
deixaram de ser de Deus, conforme aquilo da Escritura: Do Senhor é a terra e tudo o que a enche, a
redondeza da terra e todos os seus habitantes. Logo, parece que Cristo não nos remiu com a sua Paixão.

2. Demais. — Como diz Agostinho, Cristo devia vencer o demônio pela justiça. Ora, a justiça exige, que
quem se apoderou dolosamente da coisa alheia deve ser privado dela, porque a ninguém deve
aproveitar a fraude e o dolo, como também o exigem as leis humanas. Logo, tendo o diabo enganado e
a si subjugado dolosamente o homem, criatura de Deus, parece que não devia o homem ser-lhe
arrebatado ao pode por meio da redenção.

3. Demais. — Quem compra ou redime uma coisa paga o preço a quem antes a possuía. Ora, Cristo não
pagou o seu sangue, considerado preço da nossa redenção, ao diabo, que nos retinha captívos. Logo,
Cristo não nos remiu com a Paixão.
Mas, em contrário, a Escritura: Não por ouro nem por prata, que são coisas corruptíveis, haveis sido
resgatados da vossa vã conversação que recebestes de vossos pais; mas pelo precioso sangue de Cristo,
como de um cordeiro imaculado e sem contaminação alguma. Noutro lugar: Cristo nos remiu da
maldição da lei, feito ele mesmo maldição por nós. E dito do Apóstolo — feito maldição por nós —
significa que sofreu por nós no madeiro, como antes se disse. Logo, pela sua Paixão nos remiu.

SOLUÇÃO. — Pelo pecado o homem estava escravizado, de dois modos. — Primeiro pela servidão do
pecado; pois, todo o que comete pecado é escravo do pecado; e todo o que é vencido é escravo daquele
que venceu - como se lê na Escritura. Ora, como o diabo venceu ao homem, induzindo-o ao pecado, o
homem foi feito escravo do diabo. — Segundo, quanto ao reato da pena pelo qual o homem estava
ligado, segundo a justiça de Deus. E esta também é uma escravidão; pois, é próprio do escravo sofrer o
que não quer, ao contrário do homem livre, que pode dispor de si mesmo como quer. Por onde, sendo a
Paixão de Cristo uma satisfação suficiente e superabundante pelo pecado e pelo reato do gênero
humano, a sua Paixão foi um como preço, pelo qual fomos livrados de uma e outra escravidão. Assim, a
satisfação pela qual satisfazemos por nós ou por outrem é considerada um preço pelo qual nos remimos
do pecado e da pena, segundo a Escritura: Redime os teus pecados com a esmola. Ora, Cristo satisfez
não certo dando dinheiro nem por qualquer forma semelhante, mas dando-se a ele próprio - bem
máximo - por nós. Por isso é que se diz ser a Paixão de Cristo a nossa redenção.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De dois modos dizemos que o homem pertence a Deus.
Primeiro, por lhe estar sujeito ao poder. E, neste sentido, o homem nunca deixa de pertencer a Deus,
segundo aquilo da Escritura: o Excelso tem debaixo da sua dominação os reinos dos homens e os dá a
quem lhe aprazo Noutro sentido, pela união da caridade com ele, segundo o dito do Apóstolo: Se algum
não tem o Espírito de Cristo, este tal não é dele. — Ora, do primeiro modo o homem nunca deixou de
ser de Deus. Mas, do segundo, o deixa, pelo pecado. Por onde, quando liberado do pecado, pela Paixão
satisfaciente de Cristo, dizemos que o homem foi remido pela Paixão de Cristo.

RESPOSTA À SEGUNDA. — O homem, pecando, contraiu uma obrigação tanto para com Deus como
para o diabo. Pois, pela culpa, ofendeu a Deus e, sujeitou-se ao diabo, pelo seu consentimento. E assim,
em razão da culpa, não se tornou servo de Deus; mas antes, afastando-se doseu serviço, incorreu na
servidão do diabo, por justa permissão de Deus, por causa da ofensa contra ele cometida. Mas, quanto à
pena, o homem contraiu principalmente uma obrigação para com Deus, como supremo juiz; e para com
o diabo, como seu algoz, segundo aquilo do Evangelho: Para que não suceda que o teu adversário te
entregue ao juiz e que o juiz te entregue ao seu ministro, isto é, ao anjo cruel da pena, como interpreta
Crisóstomo. Embora, pois, o diabo retivesse, injustamente e na medida do seu poder, sob o seu jugo o
homem, enganado pela sua fraude, tanto quanto à culpa como quanto à pena, contudo, era justo que
isso o homem o sofresse, por permissão de Deus, quanto à culpa, e pela ordem do mesmo Deus, quanto
à pena. Por onde, relativamente a Deus, a justiça exigia fosse o homem redimido; não, porém
relativamente ao diabo.

RESPOSTA À TERCEIRA. — Como a redenção era necessária para a liberação do homem, relativamente a
Deus, mas não relativamente ao diabo, o preço não devia ser pago ao diabo, mas a Deus. Por isso, não
se diz que Cristo tivesse oferecido ao diabo, mas a Deus o seu sangue, que é o preço da nossa redenção.

## Art. 5 — Se ser Redentor é próprio de Cristo.
O quinto discute-se assim. — Parece que ser Redentor não é próprio de Cristo.

1. — Pois, diz a Escritura: Tu me remiste Senhor Deus da Verdade. Ora, Deus da verdade toda a Trindade
o é. Logo, não é próprio de Cristo.

2. Demais. — Redime quem paga o preço da redenção. Ora, Deus Padre deu o seu Filho como redentor
pelos nossos pecados, segundo a Escritura: O Senhor enviou ao seu povo redenção, isto é, diz a Glosa,
Cristo, que dá a redenção aos cativos. Logo, não só Cristo, mas também Deus Padre nos remiu.

3. Demais. — Não só a Paixão de Cristo, mas também a dos outros santos, foi profícua ànossa salvação
segundo o Apóstolo: Eu me alegro nas penalidades que sofro por vós e cumpro na minha carne o que
resta a padecer a Jesus Cristo pelo seu corpo, que é a Igreja. Logo, não só Cristo, mas também os outros
santos devem ser considerados o Redentor.
Mas, em contrário, o Apóstolo: Cristo nos remiu na maldição da lei, feito ele maldição por nós. Ora, só
Cristo foi feito maldição por nós. Logo, só ele deve ser considerado nosso Redentor.

SOLUÇÃO. — Para alguém redimir duas condições se requerem: o ato de pagar e o preço pago. Assim,
pois, não dizemos que redime principalmente, quem paga, para remir uma coisa, um dinheiro que não é
seu, mas de outrem; e antes, o redentor aquele que pagou o preço. Ora, o preço da nossa redenção é o
sangue de Cristo, ou a sua vida corpórea, que estava no sangue; e esse preço Cristo mesmo o pagou. Por
onde, o ato de pagamento e o preço do pagamento pertenceu imediatamente a Cristo, enquanto
homem; mas a toda a Trindade como àcausa primeira e remota, a quem pertencia a vida mesma de
Cristo, como primeiro autor dela; e também porque foi a Trindade que inspirou ao homem Cristo sofrer
por nós. Por isso ser imediatamente o Redentor é próprio de Cristo, enquanto homem; embora a
redenção mesma possa ser atribuída a toda a Trindade como àcausa primeira.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Otexto citado a Glosa assim o expõe: Tu, ó Deus de
verdade, me remiste em Cristo, que exclamou: — Nas tuas mãos Senhor entrega o meu espírito. Assim,
a redenção pertenceu imediatamente ao homem Cristo; mas, como causa principal dela, a Deus.

RESPOSTA À SEGUNDA. — O preço da nossa redenção o homem Cristo o pagou imediatamente; mas,
por mandado do Pai, como autor primordial.

RESPOSTA À TERCEIRA. — Os sofrimentos dos santos aproveitam à Igreja, não certo a modo de
redenção, mas a modo de exemplo e de exortação, segundo aquilo do Apóstolo: Se somos atribulados,
para vossa exortação e é salvação.

## Art. 6 — Se a Paixão de Cristo obrou a nossa salvação a modo de eficiência.
O sexto discute-se assim. — Parece que a Paixão de Cristo não obrou a nossa salvação a modo de
eficiência.

1. — Pois, a causa eficiente da nossa salvação é a grandeza da virtude divina, segundo aquilo da
Escritura: Eis ai está que a mão do Senhor não é abreviada para não poder salvar. Ora, Cristo foi
crucificado por enfermidade. Logo, a Paixão de Cristo não obrou eficientemente a nossa salvação.

2. Demais. — Nenhum agente material age eficientemente senão por contato; assim, o próprio Cristo
curou o leproso tocando-o, para mostrar que a sua carne tinha uma virtude curativa, como diz
Crisóstomo (Teofilacto). Ora, a Paixão de Cristo não podia estar em contato com todos os homens. Logo,
não podia obrar eficientemente a salvação de todos.

3. Demais. — Não pode um mesmo agente obrar o modo de mérito e de eficiência; porque quem
merece espera receber o efeito, de outrem. Ora, a Paixão de Cristo obrou a nossa salvação a modo de
mérito. Logo, não a modo de eficiência.
Mas, em contrário, o Apóstolo diz que a palavra da cruz é a virtude de Deus para os que se salvam. Ora,
a virtude de Deus obra eficientemente a nossa salvação. Logo, a Paixão de Cristo na cruz obrou
eficientemente a nossa salvação.

SOLUÇÃO. — Há uma dupla espécie de eficiência: a principal e a instrumental. Ora, o eficiente principal
da salvação humana é Deus. Sendo, porém a humanidade de Cristo o instrumento da divindade, como
se disse, por isso e consequentemente, todas as ações e paixões de Cristo obram instrumentalmente,
em virtude de divindade, para a salvação humana. E, a esta luz, a Paixão de Cristo causa eficientemente
a salvação humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A paixão de Cristo, referida àcarne de Cristo, convinha
àenfermidade que assumiu. Referida, porém àdivindade, resulta dela uma virtude infinita, segundo
aquilo do Apóstolo: O que parece em Deus uma fraqueza é mais forte que os homens. Isto é, porque a
enfermidade mesma de Cristo, enquanto de Deus, tem uma virtude excedente a toda virtude humana.

RESPOSTA À SEGUNDA. — A Paixão de Cristo, embora fosse a do seu corpo, contudo tem uma virtude
espiritual procedente da divindade que lhe estava unida. E desse contato espiritual lhe advém a eficácia;
isto é, pela fé e pelos sacramentos da fé, segundo aquilo do Apóstolo: Ao qual propôs Deus para ser
vítima de propiciação pela fé no seu sangue.

RESPOSTA À TERCEIRA. — A Paixão de Cristo referida àsua divindade, age a modo de eficiência.
Referida, porém àvontade da alma de Cristo, age a modo de mérito, Referida ainda àcarne mesma de
Cristo age a modo de satisfação, enquanto que por ela somos liberados do reato da pena; mas a modo
de redenção, enquanto por ela somos liberados da servidão da culpa; e enfim a modo de sacrifício,
enquanto fomos por ela reconciliados com Deus, como a seguir se dirá.