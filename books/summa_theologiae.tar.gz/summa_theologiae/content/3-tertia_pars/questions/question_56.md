# Questão 56: Da causalidade da ressurreição de Cristo
Em seguida devemos tratar da causalidade da ressurreição de Cristo. E nesta questão discutem-se dois
artigos:

## Art. 1 — Se a ressurreição de Cristo é a causa da ressurreição dos corpos.
O primeiro discute-se assim. — Parece que a ressurreição de Cristo não é a causa da ressurreição dos
corpos.

1. — Pois, posta a causa suficiente, necessariamente se lhe segue o efeito. Se, pois, a ressurreição de
Cristo é a causa suficiente da ressurreição dos corpos, imediatamente depois da ressurreição dele todos
os mortos deviam ressurgir.

2. Demais. — A causa da ressurreição dos mortos é a justiça divina; e esta exige que os corpos sejam
premiados ou punidos simultaneamente com as almas, com a qual participaram do mérito ou do
pecado, como diz Dionísio e também Damasceno. Ora, a justiça de Deus haveria de cumprir-se
necessariamente, mesmo se Cristo não tivesse ressurgido. Logo, ainda sem ter Cristo ressurgido, os
mortos ressurgiriam. Portanto, a ressurreição de Cristo não é a causa da ressurreição dos corpos.

3. Demais. — Se a ressurreição de Cristo é a causa da ressurreição dos corpos, ou é a causa exemplar, ou
a eficiente ou a meritória. — Ora, não é a causa exemplar, porque Deus é quem operará a ressurreição
dos corpos, segundo o Evangelho: o Pai ressuscita os mortos. E demais, Deus não precisa voltar-se para
nenhum exemplar exterior a si. — Semelhantemente, também não é a causa eficiente. Pois a causa
eficiente não age senão por contato, espiritual ou corpóreo. Ora, é manifesto que a ressurreição de
Cristo nenhum contato corpóreo tem com os mortos que ressurgem, por causa da distância de tempo e
de lugar. Nem tão pouco contato espiritual, mediante a fé e a caridade, pois, também os infiéis e os
pecadores ressurgirão. — Nem é a causa meritória, enfim; porque Cristo ressurrecto já não era
viandante e portanto não podia mais merecer. — E portanto de nenhum modo a ressurreição de Cristo
parece ser a causa da nossa ressurreição.

4. Demais. — Sendo a morte a privação da vida, destruir a morte nenhuma outra causa há de ser senão
tornar a infundir a vida, o que constitui a ressurreição. Ora, Cristo, morrendo, destruiu a nossa morte.
Logo, a morte de Cristo, e não portanto a sua ressurreição, é a causa da nossa ressurreição.
Mas, em contrário, o Apóstolo: Se se prega que Cristo ressuscitou dentre os mortos, etc. E a Glosa: Que
é a causa eficiente da nossa ressurreição.

SOLUÇÃO. — Tudo o primário em qualquer gênero é a causa do mais que se lhe segue, como diz
Aristóteles. Ora, o que é primário no gênero da verdadeira ressurreição é a ressurreição de Cristo, como
do sobredito resulta. Por onde, há de necessariamente a ressurreição de Cristo ser a causa da nossa
ressurreição. E tal o diz o Apóstolo: Ressuscitou Cristo dentre os mortos, sendo ele as primícias dos que
dormem; porque como a morte veio na verdade por um homem, também por um homem deve vir a
ressurreição dos mortos. — E com razão. Pois, o princípio da vida humana é o Verbo de Deus, do qual
diz a Escritura: Em ti está a fonte da vida. Donde o dizer o próprio Senhor: Assim como o Pai ressuscita
os mortos e lhes dá vida, assim também dá o Filho vida àqueles a quem quer. Ora, a ordem natural das
causas instituídas por Deus exige que qualquer causa primeiro obre sobre o que lhe mais próximo está e
depois, por esse meio, ao que lhe está mais remoto. Assim, o fogo primeiro aquece o ar que lhe está
próximo e, mediante o ar, aquece os corpos distantes. E Deus mesmo primeiro ilumina as substâncias
que lhe estão mais próximas e, por meio delas, as mais remotas, como diz Dionísio. Por onde, o Verbo
de Deus primeiro dá a vida imortal ao corpo, que lhe está naturalmente unido e, por ele, causa a
ressurreição em todos os outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como dissemos, a ressurreição de Cristo é a causa da
nossa, por virtude do Verbo que lhe está unido. O qual a opera pela sua vontade. Por onde, não é
necessário que o seu efeito se lhe siga imediatamente, mas segundo a disposição do Verbo de Deus; de
modo que primeiro nos afeiçoemos com Cristo, que sofreu e morreu, em nossa vida passível e mortal;
em seguida, cheguemos àparticipar da semelhança da ressurreição.

RESPOSTA À SEGUNDA. — A justiça de Deus é a causa primeira da nossa ressurreição; a ressurreição de
Cristo, porém, a causa secundária e como instrumental. Pois, embora a virtude do agente principal não
fique determinada por nenhum instrumento em particular, contudo desde que obra mediante esse
instrumento, este é a causa eficiente. Assim, pois, a justiça divina, quanto é de si, não é obrigada a
causar a nossa ressurreição, pela ressurreição de Cristo. Pois, Deus podia nos salvar por outro modo que
não a Paixão e a ressurreição de Cristo, como dissemos. Mas desde que decretou esse modo de nos
salvar, é manifesto que a ressurreição de Cristo é a causa da nossa.

RESPOSTA À TERCEIRA. — A ressurreição de Cristo não é, propriamente falando, a causa meritória da
nossa, mas a causa eficiente e exemplar. — Eficiente, porque a humanidade de Cristo, segundo a qual
ressurgiu, é de certo modo o instrumento da sua divindade, e obra em virtude dela, como se disse. Por
onde, assim como o mais que Cristo na sua humanidade fez ou sofreu contribui, em virtude da sua
divindade, para salvação nossa, como dissemos, assim também a sua ressurreição é a causa eficiente da
nossa, pela virtude divina, que tem o poder de vivificar os mortos. E essa virtude atinge com a sua
presença dos os lugares e tempos; sendo que esse contacto virtual basta para a referida eficiência
causal. Ora, segundo dissemos, a causa primordial da ressurreição humana é a justiça divina, pela qual
Cristo tem o poder de emitir o seu juízo, enquanto Filho do homem. Por onde, a causalidade eficiente da
sua ressurreição se estende não só nos bons, mas também aos maus, que lhe estão sujeitos ao juízo. —
Mas, assim como a ressurreição do corpo de Cristo, por estar ele pessoalmente unido ao Verbo, foi a
primeira no tempo, assim também foi a primeira em dignidade, como diz a Glosa a um lugar do
Apóstolo. Ora, o perfeitíssimo é sempre o exemplar imitado pelo menos perfeito, ao seu modo. Por
onde, a ressurreição de Cristo é a causa exemplar da nossa. O que é necessário, não da parte do autor
da ressurreição que não precisa de exemplar; mas da dos ressuscitados, que hão de afeiçoar-se à
ressurreição de Cristo, segundo aquilo do Apóstolo: Reformará o nosso corpo abatido para o fazer
conforme ao seu corpo glorioso. Embora, pois, a eficiência da ressurreição de Cristo se estenda à
ressurreição tanto dos bons como dos maus, contudo a sua exemplaridade se estende propriamente só
aos bons, que fez conformes à sua filiação, na frase do Apóstolo.

RESPOSTA À QUARTA. — Pela causalidade eficiente, dependente da poder divino, em geral tanto a
morte de Cristo como também a sua ressurreição é a causa tanto da destruição da morte como da
reparação da vida. Mas, quanto àcausa exemplar, a morte de Cristo, pela qual deixou a vida mortal, é a
causa da destruição da nossa morte. Ao passo que a sua ressurreição, pela qual entrou na vida imortal, é
a causa da reparação da nossa vida. Mas além disso a Paixão de Cristo é a causa meritória, como
dissemos.

## Art. 2 — Se a ressurreição de Cristo é a causa da ressurreição das almas.
O segundo discute-se assim. — Parece que a ressurreição de Cristo não é a causa da ressurreição das
almas.

1. — Pois, diz Agostinho, que os corpos ressurgem por uma exceção à lei da vida humana, mas as almas
ressurgem pelo substância de Deus, Ora, a ressurreição de Cristo não concerne àsubstância de Deus,
mas àuma exceção àlei da vida humana. Logo, a ressurreição de Cristo, embora causa da ressurreição
dos corpos, não pode contudo ser considerada causa da ressurreição das almas.

2. Demais. — O corpo não age sobre o espírito. Ora, a ressurreição de Cristo foi a do seu corpo, ferido
pela morte. Logo, a ressurreição de Cristo não é a causa da ressurreição das almas.

3. Demais. — Sendo a ressurreição de Cristo a causa da ressurreição dos corpos, todos os corpos
ressurgirão, segundo aquilo do Apóstolo. Todos certamente ressuscitaremos. Ora, nem todas as almas
ressuscitarão, porque certas irão para o suplício eterno, como diz o Evangelho. Logo, a ressurreição de
Cristo não é a causa da ressurreição das almas.

4. Demais. — A ressurreição das almas se opera pela remissão dos pecados. Ora, isto se deu pela Paixão
de Cristo, segundo a Escritura: Lavou-nos dos nossos pecados no seu sangue. Logo, da ressurreição das
almas foi antes a causa a Paixão de Cristo que a sua ressurreição.
Mas, em contrário, o Apóstolo diz: Ressuscitou para nossa justificação, que outra coisa não é senão a
ressurreição das almas. E àquilo da Escritura — De tarde estaremos em lágrimas — diz a Glosa: A
ressurreição de Cristo é a causa da nossa — da alma, presentemente, e do corpo, no futuro.

SOLUÇÃO. — Como dissemos, a ressurreição de Cristo age em virtude da divindade. — E essa se
estende não só àressurreição dos corpos, mas também àdas almas; pois Deus é quem dá à alma a vida
da graça e faz o corpo vivermediante a alma. Por onde, a ressurreição de Cristo tem uma virtude
instrumentalmente eficiente, não só em relação à ressurreição dos corpos, mas também à das almas. —
Semelhantemente, age também como causa exemplar no atínente àressurreição das almas. Pois,
devemos nos conformar com Cristo ressurrecto, quanto à nossa alma; para que, no dizer do Apóstolo,
assim como Cristo ressurgiu dos mortos pela glória do Padre, assim também nós andemos em novidade
de vida; e assim como ele ressurgido dos mortos já não morre, assim também nós nos consideremos
mortos ao pecado, para que de novo vivamos com ele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando Agostinho diz que a ressurreição das almas se
opera pela substância de Deus, ele o entende quanto àparticipação: pois, participando da divina
bondade é que as almas se tornam justas e boas, não porém participando de qualquer criatura. Por isso,
depois de ter dito — as almas ressurgem pela substância de Deus, acrescenta: Pois, pela participação de
Deus a alma se faz bem-aventurada, e não pela participação de qualquer alma santa. Ora, participando
da glória do corpo de Cristo, os nossos corpos se tornarão gloriosos.

RESPOSTA À SEGUNDA. — A eficiência da ressurreição de Cristo se faz sentir nas almas, não pela virtude
própria do corpo de Cristo ressurrecto, mas por virtude da divindade, a que está unido.

RESPOSTA À TERCEIRA. — A ressurreição das almas respeita ao mérito efeito da justificação; ao passo
que a ressurreição dos corpos se ordena à pena ou ao prêmio, efeitos da judicação. Ora, não é o papel
de Cristo justificar a todos, mas sim julgá-las. Por isso ressuscita o corpo de todos, mas não a alma.

RESPOSTA À QUARTA. — Dois elementos concorreram para a justificação das almas: a remissão da
culpa e a novidade da vida da graça. — Ora, quanto àeficiência fundada na virtude divina, tanto a Paixão
de Cristo como a sua ressurreição é a causa da justificação, relativamente aos dois elementos supra
referidos. — Mas, quanto àexemplaridade, propriamente a Paixão e a morte de Cristo é a causa da
remissão da culpa, pela qual morremos ao pecado; ao passo que a sua ressurreição é a causa da
novidade da vida, causada pela graça ou pela justiça. Donde o dizer o Apóstolo, que Cristo foi entregue,
isto é, à morte, por nossos pecados, isto é, para tirá-los, e ressuscitou para nossa justificação. Mas a
Paixão de Cristo também é meritória, como dissemos.