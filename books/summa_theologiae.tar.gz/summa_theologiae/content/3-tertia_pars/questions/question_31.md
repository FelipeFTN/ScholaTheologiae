# Questão 31: Da concepção do Salvador quanto à matéria de que o Seu
corpo foi concebido
Em seguida devemos tratar da concepção mesma do Salvador. Primeiro, quanto à matéria da qual o seu
corpo foi concebido. Segundo, quanto ao autor da concepção. Terceiro, quanto ao modo e à ordem da
concepção.

## Art. 1 — Se a carne de Cristo foi tomada de Adão.
O primeiro discute-se assim. — Parece que a carne de Cristo não foi tomada de Adão.

1. — Pois, diz o Apóstolo: O primeiro homem, formado da terra, é terreno; o segundo homem, do céu,
celestial. Ora, o primeiro homem foi Adão; o segundo é Cristo. Logo, Cristo não descende de Adão, mas
teve uma origem distinta dele.

2. Demais. — A concepção de Cristo devia ser miraculosa por excelência. Ora, maior milagre foi formar o
corpo do homem do limo da terra, do que de uma humana matéria, tirada de Adão. Logo, parece que
não era conveniente Cristo tirar a sua carne, de Adão. Portanto, parece que o corpo de Cristo não devia
ser formado da massa do gênero humano derivada de Adão, mas de uma outra matéria.

3. Demais. — O pecado entrou neste mundo por um homem, isto é, por Adão, porque todas as gentes
nele pecaram originalmente, como está claro no Apóstolo. Mas, se o corpo de Cristo tivesse sido
tomado de Adão, também ele teria estado originalmente em Adão, quando este pecou. Logo, teria
contraído o pecado original. O que não condizia com a pureza de Cristo. Logo, o corpo de Cristo não foi
formado da matéria tirada de Adão.
Mas, em contrário, diz o Apóstolo: Ele, isto é, o Filho de Deus, em nenhum lugar tomou os anjos, mas
tomou a descendência de Abraão. Ora, a descendência de Abraão foi originada em Adão. Logo, o corpo
de Cristo foi formado de matéria tomada de Adão.

SOLUÇÃO. — Cristo assumiu a natureza humana para purificá-la da sua corrupção. Ora, a natureza
humana não precisava de purificação senão porque estava contaminada pela origem viciada da sua
descendência de Adão. Por isso foi conveniente que tomasse Cristo uma carne derivada de Adão, de
modo que a natureza mesma fosse curada por essa assunção.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que o segundo homem, isto é, Cristo procedia do
céu, não quanto à matéria do seu corpo, mas, ou quanto à virtude formativa dele, ou também quanto à
sua própria divindade. Pois, quanto à matéria, o corpo de Cristo era terreno, como o foi o de Adão.

RESPOSTA À SEGUNDA. — Como dissemos, o mistério da Encarnação de Cristo é um fato milagroso, não
como ordenado à confirmação da fé, mas como um artigo de fé. Por isso, esse mistério não precisa de
ser contado entre os maiores milagres, como o hão de ser os milagres feitos para a confirmação da fé.
Mas, devemos descobrir nele uma conveniência maior com a divina sabedoria e mais expediente à
salvação humana, o que é necessário a tudo o que é objeto de fé. Já podemos dizer que no mistério da
Encarnação não consideramos o milagre relativamente à matéria da concepção, mas sobretudo quanto
ao modo da concepção e do parto, isto é, por ter sido uma virgem a que concebe e deu a luz a Deus.

RESPOSTA À TERCEIRA. — Como se disse, o corpo de Cristo existiu em Adão pela sua origem material,
isto é, porque a matéria mesma do corpo de Cristo foi derivada de Adão. Mas nele não existiu pela
origem seminal, pois não foi gerado do sêmen humano. Por isso não contraiu o pecado original, como os
outros homens, derivados de Adão por via de origem seminal.

## Art. 2 — Se Cristo tomou a sua carne da raça de Davi.
O segundo discute-se assim. — Parece que Cristo não tomou a sua carne da raça de Davi.

1. — Pois, quando Mateus descrimina genealogia de Cristo ele a conduz até José. Ora, José não foi pai
de Cristo, como se disse. Logo, parece que Cristo não descendia da raça de Davi.

2. Demais. — Arão foi da tribo de Levi. Ora, Maria, Mãe de Cristo, é chamada prima de Isabel,
descendente de Adão. Como, pois, Davi era da tribo de Judá, parece que Cristo não descendia da raça de
Davi.

3. Demais. — O profeta Jeremias diz, de Jeconias: Escreve que este homem será estéril, pois não sairá de
sua linhagem varão que se assente sobre o trono de Davi. Ora, de Cristo diz a Escritura: Assentar-se à
sobre o trono de Davi. Logo, Cristo não era da raça de Jeconias. E por consequência, nem da raça de
Davi, pois, Mateus conduz a série das gerações partindo de Davi e passando por Jeconias.
Mas, em contrário, o Apóstolo: Que foi feito da linhagem de Davi segundo a carne.

SOLUÇÃO. — Como se lê no Evangelho, Cristo era especialmente considerado filho dos dois antigos
Patriarcas, Abraão e Davi. E isso por muitas razões. - Primeiro, porque a eles foi especialmente feita a
promessa, da descendência de Cristo. Assim, foi dito a Abraão: Todas as gentes da terra serão benditas
naquele que há de proceder de ti. O que o Apóstolo aplica a Cristo, quando diz: As promessas foram
feitas a Abraão e à sua semente. Não diz – e às sementes, como de muitos; senão como de um – e à tua
semente, que é Cristo. E a Davi foi dito: Do fruto do teu ventre porei sobre o teu trono. Por isso, o povo
dos Judeus, ao receber honoríncamente o seu rei, clamava: Hosana ao filho de Davi. - Segundo, porque
Cristo havia de ser rei, profeta e sacerdote. Pois, Abraão foi sacerdote, como se conclui das palavras que
o Senhor lhe disse: Toma-me uma vaca de três anos, etc. Foi também profeta, segundo aquele outro
lugar: ele é profeta e rogará por ti. Ora, Davi foi rei e profeta. - Terceiro. porque com Abraão teve início
a circuncisão; e em Davi manifestou-se sobretudo a eleição de Deus, segundo o dito da Escritura: O
Senhor buscou para si um homem conforme ao seu coração. Por isso, Cristo é especialissimamente
chamado filho de um e de outro, para mostrar que veio trazer a salvação aos Judeus circuncisos e aos
pagãos eleitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa objeção foi feita por Fausto Maniqueu, que
pretendia provar não ser Cristo filho de Davi, por não ter sido concebido de José, até quem Mateus
conduz a série das gerações. Mas Agostinho assim lhe responde: Como o mesmo Evangelista diz que
José era o esposo de Maria e Cristo era da raça de Davi, que resta senão crermos que Maria não era
estranha ao parentesco com Davi? Que não foi em vão chamada a esposa de José, em razão da união
das suas almas e não de seus corpos? E que a série das gerações foi conduzida até José, antes por causa
da dignidade inerente à descendência masculina? Assim, pois, cremos que Maria era do parentesco de
Davi, por crermos na Escritura. E esta diz, tanto que Cristo era da raça de Davi segundo a carne, como
que sua Mãe Maria não teve nenhum comércio com o esposo, mas permaneceu virgem. Pois, como diz
Jerônimo, José e Maria eram da mesma tribo; donde o estar ele obrigado pela lei a recebê-la, como
parenta. Por isso figuravam juntos no censo, em Belém, como gerados de um mesmo tronco.

RESPOSTA À SEGUNDA. — Gregório Nazianzeno responde a essa objeção quando diz, que foi por
vontade divina que uma raça real se uniu à uma família sacerdotal, a fim de que Cristo, ao mesmo
tempo rei e sacerdote, nascesse de ambos, segundo a carne. Por isso, Arão, o primeiro sacerdote da lei,
casou com Isabel, da tribo de Judá, e filha de Anínadab. E assim foi também possível que o pai de Isabel
tivesse uma esposa da estirpe de Davi, em razão do que a Santa Virgem Maria. pertencente à raça de
Davi, foi prima de Isabel. Ou antes e inversamente, que o Pai da Santa Maria, sendo da estirpe de Davi,
casou na estirpe de Arão. - Ou, como diz Agostinho, se Joaquim, pai de Maria, foi da estirpe de Arão,
como o herético Fausto afirmava, fundado em certas escrituras apócrifas, devemos crer que a mãe de
Joaquim foi da estirpe de Davi, ou também a sua mulher; e assim, de algum modo, podemos dizer que
Maria era da raça de Davi.

RESPOSTA À TERCEIRA. — A citada autoridade profética, como diz Ambrósio, não nega que nenhuma
descendência houvesse de nascer da raça de Jeconias. Por isso Cristo fez parte da sua estirpe. E o ter
Cristo reinado não vai contra a profecia. Pois, o seu reino não era temporal; e ele próprio o confessou
quando disse: O meu reino não é deste mundo.

## Art. 3 — Se a genealogia de Cristo foi bem discriminada pelos Evangelistas.
O terceiro discute-se assim. — Parece que a genealogia de Cristo não foi bem discriminada pelos
Evangelistas.

1. — Pois, diz a Escritura, de Cristo: Quem contará a sua geração? Logo, não se devia contar a geração
de Cristo.

2. Demais. — É impossível um mesmo homem ter dois pais. Ora, Mateus diz, que Jacó gerou a José,
esposo de Maria; e Lucas, por seu lado, que José era filho de Heli. Logo, escreveu um o contrário do
outro.

3. Demais. — Mateus e Lucas fazem relações diversas. Assim, Mateus, no princípio do livro, começando
de Abraão e descendo até José, enumera quarenta e duas gerações. Lucas, por seu lado, depois do
batismo de Cristo, refere a geração de Cristo, começando por ele e, levando o número das gerações até
Deus, conta setenta e sete gerações, computando os extremos. Logo, parece que discriminam mal a
geração de Cristo.

4. Demais. — Na Escritura se lê, que Jorão gerou Ocosias: a quem sucedeu o filho Joás; a este, o seu filho
Amásias; depois, reinou o filho deste, Azarias; chamado Osias: a quem sucedeu Joatan, seu filho.
Mateus, porém, diz que Jorão gerou Osias. Logo, parece mal discriminada uma geração de Cristo, que
omite , no meio, três reis.

5. Demais. — Todos os assolados na geração de Cristo tiveram pais e mães; e muitos deles, também
irmãos. Ora, Mateus, na geração de Cristo, enumera só três mães, a saber, Tamar, Rut e a esposa de
Urias. Como irmãos designa Judas e Jeconias, e além deles, Fares e Zarâo. Ora, nenhum desses Lucas
menciona. Logo, parece que os Evangelistas discriminaram mal a genealogia de Cristo.
Mas, em contrário, a autoridade da Escritura.

SOLUÇÃO. — Como diz o Apóstolo, toda a Escritura é divinamente inspirada. Ora, as coisas divinas se
realizam de maneira ordenadíssima, segundo ainda o Apóstolo: As causas de Deus são ordenadas. Por
onde, a genealogia de Cristo foi bem discriminada pelos Evangelistas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como ensina Jerônimo, Isaías se refere à geração da
divindade de Cristo. Ao passo que Mateus narra a geração de Cristo segundo a humanidade; não, certo,
explicando o modo da Encarnação, que é inefável também; mas, enumerando os pais de que Cristo
procedeu segundo a carne.

RESPOSTA À SEGUNDA. — Essa objeção, suscitada por Juliano o Apóstata, recebeu soluções diversas.
Assim, certos, como Gregório Nazianzeno opinam, que ambos os Evangelistas enumeram o mesmo
personagem, Jacó e Heli, mas com dois nomes diferentes. - O que não é admissível, porque Mateus
enumera Salomão um dos filhos de Davi; ao passo que Lucas enumera outro, que é Natan, os quais
consta terem sido irmãos, segundo a Escritura.
Por isso, outros disseram, que Mateus nos dá a verdadeira genealogia de Cristo; ao passo que a de Lucas
é putativa, e o começar assim – Jesus era, como se julgava, filho de José. Pois, havia certo judeus, que
por causa dos pecados dos reis de Judá, criam que Cristo nasceria de Davi, não mediante os reis, mas
por uma linhagem privada. Outros, porém, disseram que Mateus numerou os pais carnais; ao passo que
Lucas, os espirituais, isto é, os varões justos, denominados pais pela honestidade da sua vida.
Segundo outra opinião, responde-se que não devemos pensar que Lucas chama a José filho de Heli, mas
sim, que diz terem sido Heli e José pais de Cristo, descendente diversamente de Davi. Por isso diz que
Cristo em, como se julgava, Filho de José, e que também o próprio Cristo foi filho de Reli; quase como se
dissesse que Cristo pela mesma razão por que é chamado filho de José pode ser também cognominado
filho de Heli e de todos os reis descendentes da raça de Davi. Assim, diz o Apóstolo: de quem, isto é, dos
judeus, descende também segundo a carne.
Mas Agostinho, resolve essa dificuldade de três modos, dizendo: Há três vias seguidas singularmente
pelos Evangelistas. — Ou então um Evangelista designa o pai que realmente gerou a José, ao passo que
o outro designou-lhe o avô materno ou um dos seus mais próximos parentes. Ou um era o pai natural
de José e o outro o pai adotivo. — Ou, segundo o costume dos Judeus, quando um homem morria sem
deixar filhos, um dos seus próximos tomava-lhe a mulher, sendo o filho que ele: engendrasse imputado
ao morto. O que também constitui um certo gênero de adoção legal, como o próprio Agostinho o
afirma. E esta última via é a mais verdadeira, que também Jerônimo apresenta; e Eusébio Cesariense
refere. o historiador Júlio Africano e preconiza. Assim, dizem que Matan e Melqui procriaram em
tempos diversos, da mesma esposa, chamada Esta, um filho chamado Jacó. Porque Matan, descendente
de Salomão, foi quem primeiro a tomou por mulher e morreu deixando um filho chamado Jacó. Mas
depois da morte de Matan, como a lei não proibia a viúva casar com outro homem, Melqui, também da
mesma tribo, por Matan, embora não da mesma família, tomou como esposa a viúva de Matan, da qual
também houve um filho chamado Reli. Donde vem que, nascidos de pais diferentes, Jacó e Heli eram
irmãos uterinos. Desses, um, Jacó, tendo casado, por disposição da lei, com a viúva de seu irmão Heli,
morto sem filhos, gerou a José, na verdade e naturalmente filho seu, tornado porém, pelo preceito da
lei, filho de Heli. Por isso diz Mateus que Jacó gerou a José; enquanto que Lucas, descrevendo a geração
legal, não usa, na sua genealogia, o verbo gerar. Embora, porém, Damasceno diga que a Santa Virgem
Maria era parente de José, por descender este de Heli, considerado como seu pai, e isto porque ele a faz
descender de Heli, devemos contudo. crer que ela também descendia de Salomão de algum modo,
mediante os antepassados da enumeração de Mateus. que narra a geração carnal de Cristo; sobretudo
que Ambrósio diz ter Cristo. descendido da raça de Jeconias.

RESPOSTA À TERCEIRA. — Como diz Agostinho, o desígnio de Mateus era fazer conhecer a pessoa real
de Cristo, ao passo que Lucas, a sua pessoa sacerdotal. Por isso, a genealogia de Mateus indica que N. S.
J. Cristo assumiu os nossos pecados, tendo assumido a semelhança da carne do pecado, pela sua origem
carnal. Ao passo que a genealogia de Lucas significa que os nossos pecados foram delidos pelo sacrifício
de Cristo. Por isso a genealogia de Mateus enumera os descendentes, e a de Lucas, os ascendentes. -
Também por isso é que Mateus desce de David, passando por Salomão, em cuja mãe Davi pecou; ao
passo que Lucas sobe até Davi, por Matan, porque foi por um profeta desse nome que Deus perdoou o
pecado de Davi. - Donde vem ainda que, querendo Mateus significar que Cristo desceu até a nossa
mortalidade, mencionou, desde o início, no seu Evangelho, as gerações desde Abraão, até José, em
ordem descendente, até a natividade de Cristo. Ao passo que Lucas começa a enumerar as gerações,
não do início, mas do batismo de Cristo, e não em ordem descendente, mas ascendente, querendo
assim frisar que Cristo foi o sacerdote da expiação dos pecados e por isso invocou o testemunho de
João, quando este disse: Eis o que tira os pecados do mundo. E, na ordem ascendente, Lucas passou por
Abraão e chegou a Deus com o qual fomos reconciliados depois de purificados e expiados. - E com razão
também, na sua genealogia, Lucas indicou a ordem de adoção, pois, esta nos torna filhos de Deus; ao
passo que pela geração carnal o Filho de Deus foi feito filho do homem. E suficientemente demonstrou
que, quando disse ser José filho de Heli, não quis com isso considerá-lo como gerado por Heli, mas,
como adotado por este; pois, também disse que Adão foi filho de Deus, embora fosse feito por Deus.
Quanto ao número quadragenário, refere-se ao tempo da vida presente, por causa das quatro partes do
mundo, onde transcorre a nossa vida mortal, guiados por Cristo nosso rei. Pois, quarenta contém quatro
vezes dez; e este último número, por sua vez, resulta da adição dos números que vão de um a quatro.
Mas também o número denário podia referir-se ao Decálogo; e o quaternário, à vida presente, ou ainda
aos quatro Evangelhos, pelos quais Cristo reina em nós. Por isso Mateus, a fim de louvar a pessoa real
de Cristo, enumerou quarenta personagens, excetuando a Cristo mesmo. Mas isto deve entender-se
assim, se o Jeconias enumerado no fim do segundo quaternário e no princípio do terceiro é o mesmo
personagem. Conforme Santo Agostinho, essa dupla menção de Jeconias significa que por ele, quando
do cativeiro de Babilônia, fez-se um êxodo para as nações estrangeiras; o que também prefigurava
Cristo, que passou dos povos circuncisos para os incircuncisos. Mas Jerônimo diz, que houve dois
Joaquina, isto é, Jeconias, a saber, o pai e o filho; ambos os quais foram incluídos na geração de Cristo,
para que constasse a distinção das gerações, que o Evangelista divide em três séries de quatorze. O que
sobe a quarenta e duas pessoas. Número esse que também se adapta à santa Igreja. Pois, quarenta e
dois é formado de seis, que significa o labor da vida quotidiana, e do número sete, que significa o
repouso da vida futura; pois, seis vezes sete são quarenta e dois. E também o número quatorze,
resultante da soma de dez e de quatro, é susceptível do mesmo simbolismo atribuído ao número
quarenta, cujo total é o produto da multiplicação dos mesmos números quatro e dez.
Quanto ao número, de que se serve Lucas, das gerações até Cristo, ele representa a totalidade dos
pecados. Pois, o número dez, como o número da Justiça, manifesta-se nos dez preceitos da lei. Ora, o
pecado é a transgressão da lei. E o número que vai além de dez ou o transgride é o número onze.
Quanto ao número sete, ele significa a totalidade, porque o tempo consumou-se totalmente com o
número dos sete dias. Ora, como sete vezes onze são setenta e sete, esse total significa a universalidade
dos pecados, que Cristo deline.

RESPOSTA À QUARTA. — Como diz Jerônimo, por ter-se o rei Jorão aliado à família da impíssima
Jesabel, por isso a sua memória foi suprimida até a terceira geração, a fim de que ela não aparecesse na
genealogia sagrada da natividade. E assim, como diz Crisóstomo, tão grande foi a bênção derramada
sobre Jehu, por ter exercido vingança sobre a casa de Acab e de Jesabel, como foi grande a maldição
sobre a casa de Jorão, por causa da filha do iníquo Acab e Jesabel; e seus filhos foram eliminados do
número dos reis até a quarta geração, como se lê na Escritura: Vingarei a inquidade dos pais nos filhos
até a terceira e quarta geração. E ainda devemos atender a que também os outros reis, enumerados na
genealogia de Cristo, foram pecadores; mas a impiedade deles não foi continuada. Assim, como diz um
autor, Salomão foi mantido como rei, pelos méritos de seu pai; Roboão, pelos méritos de Osa, filho de
Abias e seu neto. Pelo contrário, a impiedade dos três reis em questão perdurou até o fim.

RESPOSTA À QUINTA. — Como diz Jerônimo, a genealogia do Salvador não enumera nenhuma das
santas mulheres, mas só as censuradas na Escritura; porque aquele que veio por causa dos pecadores
devia, nascendo de pecadoras, delir os pecados de todos. Por isso é mencionada Tamar, censurada por
causa das suas relações com o cunhado; e Raab, que foi meretriz; e Rut, que era alienígena; e Bersabé,
mulher de Urias, que foi adúltera. A qual, porém, não é designada com o seu nome próprio, mas com o
nome de seu marido. Quer por causa do seu pecado, pois praticou consciamente o adultério e o
homicídio; quer também para, com a nomeação do marido, fazer memória do pecado de Davi. - E como
Lucas visava designar a Cristo como expiador dos pecados, não faz menção dessas mulheres. - Faz
menção porém dos irmãos de Judas, para mostrar que pertenciam ao povo de Deus, embora Ismael,
irmão de Isaac, e Esaú, irmão de Jacó, fossem separados do povo de Deus, e por isso não se faz menção
deles na genealogia de Cristo. E também para excluir o orgulho da nobreza. Pois, muitos dos irmãos de
Judas. nasceram de escravos; mas todos foram a um tempo Patriarcas e chefes de tribos. - Quanto a
Fares e a Zarão, foram simultaneamente nomeados, como diz Ambrósio, como símbolos das duas vidas
que vivem os povos – uma, segundo a lei, significa da por Zarão; outra, segundo a fé, significada por
Fares. - Quanto aos irmãos de Jeconias, são mencionados porque todos reinaram em tempos diversos; o
que não se deu com os outros reis. Ou porque foi semelhante a iniquidade e a miséria deles.

## Art. 4 — Se a matéria do corpo de Cristo devia ser tomada de uma mulher.
O quarto discute-se assim. — Parece que a matéria do corpo de Cristo não devia ter sido tomada de
nenhuma mulher.

1. — Pois, o sexo masculino é mais nobre que o feminino. Ora, convinha sobretudo que Cristo assumisse
e que a natureza humana tem de mais perfeito. Logo, parece que não devia assumir a carne, nascendo
de uma mulher, mas antes assumir a carne de um homem, assim como Eva foi formada da costela de
Adão.

2. Demais. — Todo o concebido de mulher ficou-lhe algum tempo incluído no ventre. Ora, a Deus, que
enche o céu e a terra, não lhe convinha o ter sido encerrado no ventre materno. Logo, parece que não
devia ser concebido de nenhuma mulher.

3. Demais. — Os concebidos de mulher contraem de algum modo uma impureza. Donde o dizer a
Escritura: Acaso pode justificar-se o homem comparado com Deus? Ou aparecer puro o que nasceu de
mulher? Ora, em Cristo não devia haver nenhuma impureza, pois, ele é a sabedoria de Deus, da qual diz
a Escritura: Nada manchado cabe nela. Logo, parece que não devia tomar a carne, de uma mulher.
Mas, em contrário, o Apóstolo: Enviou Deus a seu filho, feito de mulher.

SOLUÇÃO. — Embora o Filho pudesse assumir a carne humana, de qualquer matéria que quisesse,
convenientíssimo era contudo que recebesse a carne, de uma mulher. - Primeiro, porque assim
nobilitou toda a natureza humana. Donde o dizer Agostinho: O perdão concedido à humanidade devia
manifestar-se em ambos os sexos. O sexo masculino, sendo o mais nobre, o Cristo devia tomar-lhe a
natureza; e, pois que nascia de uma mulher, poder-se-ia concluir consequentemente, que também o
sexo feminino participava do perdão. - Segundo, porque vinha reforçar a verdade da Encarnação. Por
isso diz Ambrósio: Descobrirás em Cristo muitas coisas conformes à natureza e muitas outras superiores
a ela. Assim, era sujeitar-se à condição da natureza existir no ventre, isto é de um corpo feminino; mas,
o que é superior à natureza, é uma virgem tê-lo concebido e gerado. Para acreditares que era Deus o
introdutor dessa novidade na natureza e que era homem quem ia, segundo a natureza, nascer do
homem. E Agostinho diz: Se o Deus Todo-poderoso tivesse criado um homem, formando-o sem recorrer
ao ventre materno e apresentando-o repentinamente aos olhos humanos, não teria confirmado o
sentimento do erro? E que de nenhum modo assumiu verdadeiramente a natureza humana? E ele, que
produz tudo de maneira maravilhosa, teria destruído o que fez com misericórdia? Ao contrário,
mediador entre Deus e o homem, reunindo na unidade da sua pessoa uma e outra natureza, quis
sublimar o habitual pelo insólito e temperar o insólito pelo habitual. - Terceiro, porque desse modo,
completa as diversas maneiras por que foi produzido o homem. Pois, primeiro, o homem foi produzido
do limo da terra, sem homem e sem mulher; depois, Eva foi produzida do homem, sem mulher; e enfim,
os outros homens foram produzidos do homem e da mulher. E esse como quarto modo foi deixado
como o próprio de Cristo, para que fosse produzido da mulher, sem o homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por ser o sexo masculino mais nobre que o feminino, é
que Cristo assumiu a natureza humana, nesse sexo. Mas para que não ficasse desprezado o sexo
feminino, foi congruente que assumisse a carne, de uma mulher. Donde o dizer Agostinho: Não queirais
vos desprezar uns aos outros, homens, pois o Filho de Deus quis ser homem. Não vos desprezeis a vós
mesmas, mulheres, pois, o Filho de Deus nasceu de uma mulher.

RESPOSTA À SEGUNDA. — Respondendo a essa objeção, Agostinho diz: Sem dúvida a fé católica crê que
Cristo, Filho de Deus, nasceu de uma virgem, segundo a carne; mas de nenhum modo nos ensina que o
Filho de Deus tivesse ficado encerrado no ventre de uma mulher, de sorte que não mais existisse fora
dele e que tivesse abandonado o governo do céu e da terra, como que separado do seu Pai. Sois vós, ó
Maniqueus, quem de nenhum modo compreende tais coisas, com um coração incapaz de conceber
senão imagens corpóreas. E em outro lugar: Tal o sentimento de homens incapazes de pensar senão na
matéria, a qual não pode estar toda em toda parte, por ter necessariamente o seu ser dividido em
partes inumeráveis, ocupando cada uma um ponto diferente. Ora, a natureza da nossa alma é muito
diferente da natureza corpórea. Quanto mais não o é a de Deus, Criador da alma e do corpo! Deus sabe
que está todo em toda parte, sem que nenhum lugar o contenha; sabe que vai a um lugar sem se afastar
de onde estava; sabe que o seu afastar-se não implica em sair donde viera.

RESPOSTA À TERCEIRA. — Na obra de conceber a mulher, de um homem, nada há de impuro, porque
foi instituída por Deus. Donde o dizer o Apóstolo: Ao que Deus purificou não chames tu comum, isto é,
impuro. Há aí porém uma certa impureza proveniente do pecado, pois, a concepção, resultante da
conjunção do homem e da mulher, é acompanhada de concupiscência. O que, porém, não existiu em
Cristo, como demonstramos. - Mas mesmo que houvesse no referido ato qualquer impureza, dela não
teria sido inquinado o Verbo de Deus, que de nenhum modo é mutável. Donde o dizer Agostinho:
Pergunta Deus, o Criador do homem. - que te move, na minha natividade? Não fui concebido no desejo
da concupiscência. Fiz eu a mãe de quem havia de nascer. Se o raio do sol pode secar a imundície das
cloacas, sem se contaminar, muito mais capaz é o Esplendor da luz eterna de purificar o que irradia, sem
se deixar com isso macular.

## Art. 5 — Se a carne de Cristo foi concebida do sangue mais puro da Virgem.
O quinto discute-se assim. — Parece que a carne de Cristo não foi concebida do sangue mais puro da
Virgem.

1. — Pois, diz a coleta (da festa da anunciação da Santa Virgem Maria), que Deus quis que o seu Verbo
assumisse a carne,de uma Virgem. Ora, carne não é o mesmo que sangue. Logo, o corpo de Cristo não
foi assumido do sangue da Virgem.

2. Demais. — Assim como a mulher foi milagrosamente formada do varão, assim o corpo de Cristo foi
milagrosamente formado da Virgem. Ora, não se diz que a mulher foi formada do sangue do varão, mas
antes, da sua carne e dos seus ossos. segundo aquilo da Escritura: Eis aqui agora o osso de meus ossos e
a carne de minha carne. Logo, parece que também o corpo de Cristo não devia ser formado do sangue
da Virgem, mas das suas carnes e dos seus ossos.

3. Demais. — O corpo de Cristo era da mesma espécie que o corpo dos outros homens. Ora, o corpo dos
outros homens não é formado do sangue mais puro, mas do sêmen e do sangue menstrual. Logo,
parece que também o corpo de Cristo não foi concebido do sangue mais puro da Virgem.
Mas, em contrário, Damasceno diz, que o Filho de Deus formou para si, do mais casto e mais puro
sangue da Virgem, o seu corpo animado da alma racional.

SOLUÇÃO. — Como dissemos, na concepção de Cristo o ter ele nascido de uma mulher foi condição da
natureza; mais ultrapassou a condição da natureza o ter nascido de uma virgem. Ora, a condição natural
da geração animal. é que a fêmea ministre a matéria, sendo o macho o princípio ativo da geração, como
o prova o filósofo. Por onde, a mulher que concebe de um homem não pode ser virgem. Por onde, o
modo sobrenatural da geração de Cristo esteve no principio ativo dela ter sido um poder sobrenatural
divino. E o modo natural da mesma esteve na matéria de que o seu corpo foi concebido ter sido a
mesma que as outras mulheres subministram na concepção dos filhos. E essa matéria, segundo o
Filósofo, é o sangue da mulher, não qualquer, mas tendo já sofrido uma transformação maior pela
virtude geratriz da mãe, de modo a tornar-se matéria apta à concepção. E assim, dessa matéria é que foi
concebido o corpo de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como a Santa Virgem era da mesma natureza que as
outras mulheres, havia consequentemente de ter carne e ossos dessa mesma natureza. Ora, nas outras
mulheres, as carnes e os ossos são lhes partes atuais do corpo, dos quais consta a integridade dele; e
por isso não podem dele separar-se sem lhe causar a destruição ou um detrimento. Mas Cristo, que veio
reparar a corrupção do pecado, não podia ser causa de nenhuma corrupção ou detrimento da
integridade de sua mãe. Por isso, o corpo de Cristo não devia ser formado da carne nem dos ossos da
Virgem; mas do sangue, que ainda não é parte atual, mas é o todo só potencialmente, como diz
Aristóteles. Por isso quando se diz, que assumiu a carne da Virgem, não significa isso que a matéria do
seu corpo fosse carne atualmente, mas sangue, que é carne em potência.

RESPOSTA À SEGUNDA. — Como se disse na Primeira Parte, Adão que foi instituído como o principio da
natureza humana, tinha no seu corpo carne e ossos que não lhe faziam parte da integridade pessoal,
mas só enquanto era principio da natureza humana. E dessa carne foi formada a mulher, sem
detrimento do homem. Mas nada de tal existiu no corpo da Virgem, de que pudesse formar-se o corpo
de Cristo sem corrupção do corpo materno.

RESPOSTA À TERCEIRA. — O sêmen da mulher não é capaz de geração, mas é um gênero imperfeito do
sêmen, que não podia chegar à perfeição da natureza seminal, por causa da imperfeição da virtude
feminina. Por isso, um tal sêmen não é matéria necessária para a concepção, como o ensina o Filósofo.
Donde, o não ter existido na concepção do corpo de Cristo; sobretudo porque, apesar de um gênero
imperfeito de sêmen, é emitido com uma certa concupiscência, como o sêmen masculino. Ora, na
conceição virginal de Cristo não podia haver nenhum lugar para a concupiscência. Por isso, Damasceno
diz, que o corpo de Cristo não foi concebido seminalmente.
Quanto ao sangue menstrual, que as mulheres emitem cada mês, ele traz consigo uma certa impureza e
corrupção natural. como as outras superfluidades, que a natureza expele, por não precisar delas. E
desse menstruo corrupto, que a natureza expulsa, não se forma o ser concebido; mas constitui uma
como purificação daquele sangue puro, preparado para a concepção depoisde mais elaborado, e sendo
um sangue como mais puro e mais perfeito que qualquer outro. É acompanhado porém da impureza da
concupiscência, na concepção dos outros homens, pois pela: conjunção do macho e da fêmea é que
esse sangue é levado ao local apto para a geração. Ora, tal não teve lugar na concepção de Cristo,
porque por obra do Espírito Santo é que esse sangue se acumulou no ventre virginal e formou o corpo
de Cristo. Por isso é que se diz que o corpo de Cristo foi formado de sangue mais casto e mais puro da
Virgem.

## Art. 6 — Se uma parte determinada do corpo de Cristo existiu em Adão e nos outros patriarcas.
O sexto discute-se assim. — Parece que uma parte determinada do corpo de Cristo existiu em Adão e
nos outros patriarcas.

1. — Pois, diz Agostinho, que a carne de Cristo existiu em Adão e em Abraão, pela sua substância
corpórea. Ora, a substância corpórea é algo de determinado. Logo, a carne de Cristo existiu em Adão e
em Abraão e nos demais patriarcas segundo uma parte determinada.

2. Demais. — O Apóstolo diz, que Cristo foi feito do sêmen de Davi segundo a carne. Ora, o sêmen de
Davi era algo de determinado nele existente. Logo, Cristo existiu em Davi segundo algo de determinado
e, pela mesma razão, nos outros patriarcas.

3. Demais. — Cristo tem afinidade com o gênero humano, pois, assumiu a carne do gênero humano.
Ora, se essa carne de nenhum modo existiu determinadamente em Adão, parece que nenhuma
afinidade tem com o gênero humano, derivado de Adão; mas antes, com os demais seres de que foi
tirada a matéria da sua carne. Logo, parece que a carne de Cristo existiu em Adão e nos outros
patriarcas de uma determinada maneira.
Mas, em contrário, diz Agostinho: Do medo pelo qual Cristo existiu em Adão e em Abraão e nos outros
patriarcas, desse mesmo os outros homens neles existiram; mas não inversamente. Ora, os outros
homens não existiram em Adão nem em Abraão por nenhuma determinada matéria, mas só pela
origem, como se estabeleceu na Primeira Parte. Logo, nem Cristo existiu em Adão e em Abraão de
nenhuma determinada maneira; e, pela mesma razão, nem nos outros patriarcas.

SOLUÇÃO. — Como dissemos, a matéria do corpo de Cristo. não foi a carne nem os ossos da Santa
Virgem, nem nenhuma parte atual do corpo dela, mas o sangue, que é carne em potência. Ora, tudo o
que a Santa Virgem recebeu de seus pais existia atualmente como parte do seu corpo. Logo, o que a
Santa Virgem recebeu dos pais não foi matéria do corpo de Cristo. Donde devemos concluir, que o corpo
de Cristo não existiu em Adão e nos outros patriarcas de nenhuma determinada maneira, de modo que
alguma parte do corpo de Adão ou de algum outro pudesse ser designada determinadamente, a ponto
de dizer-se que determinadamente dessa matéria seria formado o corpo de Cristo; mas aí existiu só pela
origem, como o corpo dos outros homens. Pois, o corpo de Cristo se relaciona com o de Adão e dos
outros patriarcas mediante o corpo de sua mãe. Por onde, de nenhum outro modo existiu nos patriarcas
o corpo de Cristo, senão do que pelo qual ai existiu o corpo de sua mãe; e esse não existiu nos patriarcas
com nenhuma determinada matéria. como assim não existiram, os corpos dos outros homens, segundo
se demonstrou na Primeira Parte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A expressão – Cristo existiu em Adão pela sua substância
corpórea — não significa que o corpo de Cristo fosse em Adão uma substância corpórea, mas que a
substância corpórea do corpo de Cristo. isto é, a matéria que recebeu da virgem, existiu em Adão como
no seu princípio ativo, e não como um principio material. Porque a virtude geratriz de Adão e dos
demais patriarcas descendentes de Adão, até a Santa Virgem, torna apta a referida matéria para a
concepção do corpo de Cristo. Mas essa matéria não foi formada no corpo de Cristo por uma virtude
derivada do sêmen de Adão. Por isso se diz, que Cristo existiu em Adão originalmente, pela sua
substância corpórea, mas não por via seminal.

RESPOSTA À SEGUNDA. — Embora o corpo de Cristo não tivesse existido em Adão e nos outros
patriarcas por via seminal, contudo o corpo da Santa Virgem, concebido do sêmen masculino, existiu por
via seminal em Adão e nos outros patriarcas. Por isso, mediante a Santa Virgem, Cristo é considerado,
quanto à sua carne, descendente originariamente da raça de Davi.

RESPOSTA À TERCEIRA. — Cristo tem afinidade com o gênero humano por semelhança específica. Ora, a
semelhança específica não se tunda na matéria remota, mas na matéria próxima e num principio ativo,
que gera o seu semelhante específico. Assim, pois, a afinidade de Cristo com o gênero humano fica
suficientemente salva por ter sido o corpo de Cristo formado do sangue da Virgem derivado
originalmente de Adão e dos demais patriarcas. Nem importa a essa afinidade a matéria de que tal
sangue foi formado, como não o importa à geração dos outros homens, como se disse na Primeira
Parte.

## Art. 7 — Se a carne de Cristo foi contaminada do pecado, nos antigos patriarcas.
O sétimo discute-se assim. — Parece que a carne de Cristo não foi contaminada pelo pecado, nos
antigos patriarcas.

1. — Pois, diz a Escritura que na divina sabedoria nada de manchado caiu. Ora, Cristo é a sabedoria de
Deus, no dizer do Apóstolo. Logo, a sua carne não foi nunca manchada do pecado.

2. Demais. — Damasceno diz que Cristo assumiu as primícias da nossa natureza. Ora, no seu primeiro
estado, a carne humana não foi manchada do pecado. Logo, a carne de Cristo não foi contaminada do
pecado, nem em Adão nem nos outros patriarcas.

3. Demais. — Agostinho diz, que a natureza humana sempre teve para os seus ferimentos, os remédios
apropriados. Ora, o que foi contaminado não pode, por isso mesmo, ser remédio de nenhum ferimento;
antes, precisa de remédio. Logo, sempre teve a natureza humana uma parte não contaminada, da qual
foi depois formado o corpo de Cristo.
Mas, em contrário, o corpo de Cristo não se reporta a Adão e aos outros patriarcas senão mediante o
corpo da Santa Virgem, da qual assumiu a carne. Ora, o corpo da Santa Virgem foi totalmente concebido
no pecado original, como se disse; e assim, mesmo enquanto existente nos patriarcas foi contaminado
pelo pecado. Logo, a carne de Cristo, enquanto existente nos patriarcas, foi contaminada pelo pecado.

SOLUÇÃO. — Quando dizemos que Cristo ou a sua carne existiu em Adão e nos outros patriarcas,
comparamos a ele ou a sua carne com Adão e com os demais patriarcas. Ora, é manifesto, que uma era
a condição dos patriarcas e outra a de Cristo; pois, ao passo que os patriarcas estavam sob o jugo do
pecado, Cristo foi absolutamente isento dele. Por onde, de dois modos pode haver erro nessa
comparação. — Primeiro, se atribuirmos a Cristo ou à sua carne a condição dos patriarcas; por exemplo,
se dissermos que Cristo pecou em Adão, porque de certo modo existiu nele. O que é falso, porque nele
não existiu, de modo que o pecado de Adão o contaminasse, porque não penetrou nele pela lei da
concupiscência, nem por via seminal, como dissemos. — De outro modo podemos errar se atribuirmos
ao que existiu atualmente nos patriarcas, a condição de Cristo ou da sua carne. De modo que, por não
ter sido a carne de Cristo, tal como Cristo a teve, contaminada pelo pecado, por isso em Adão e nos
outros patriarcas existiu uma parte do seu corpo isenta de pecado, da qual foi depois formado o corpo
de Cristo, como certos pensaram. O que não pode ser. Primeiro, porque a carne de Cristo não existiu em
Adão e nos outros patriarcas com nenhuma determinada matéria, que pudesse ser distinta da mais
carne sua como o puro se distingue do impuro, conforme já dissemos. Segundo, porque, sendo a carne
humana contaminada pelo pecado, porque é concebida na concupiscência, assim como toda carne de
todos os homens é concebida pela concupiscência, assim também é totalmente contaminada pelo
pecado. Donde devemos concluir, que a carne dos antigos patriarcas foi totalmente contaminada pelo
pecado; nem houve neles nada isento do pecado do que depois fosse formado o corpo de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo não assumiu a carne do gênero humano sujeita ao
pecado, mas pura de toda contaminação pecaminosa. Por isso, na sabedoria de Deus nada de manchado
cai.

RESPOSTA À SEGUNDA. — Diremos que Cristo assumiu as primícias da nossa natureza, quanto à
semelhança de condição; porque assumiu a carne não contaminada pelo pecado, como o era a carne
antes do pecado. Mas essa expressão não se entende quanto à continuidade da pureza, de modo que a
carne do primeiro homem fosse conservada imune do pecado, até a formação do corpo de Cristo.

RESPOSTA À TERCEIRA. — Antes de Cristo, a natureza humana estava ferida, isto é, contaminada pelo
pecado original em ato. Mas, o remédio a esse ferimento não existia nela em ato, mas só pela virtude da
origem, enquanto desses patriarcas nasceria no tempo a carne de Cristo.

## Art. 8 — Se Cristo foi dizimado na pessoa de Abraão.
O oitavo discute-se assim. — Parece que Cristo foi dizimado, na pessoa de Abraão.

1. — Pois diz o Apóstolo, que Levi, bisneto de Abraão, foi dizimado em Abraão, porque quando este
pagou dízimos a Melquisedeque, ainda Levi estava nos lombos de seu pai. Ora, semelhantemente, Cristo
estava nos lombos de Abraão, quando pagou dízimos. Logo, também Cristo pagou dízimos na pessoa de
Abraão.

2. Demais. — Cristo é da raça de Abraão, pela carne que recebeu de sua mãe. Ora, sua mãe pagou
dízimos na pessoa de Abraão. Logo, pela mesma razão, Cristo.

3. Demais. — Pagou dízimos em Abraão tudo o que tinha necessidade de cura, como diz Agostinho. Ora,
toda carne sujeita ao pecado tem necessidade de cura. Como, pois, a carne de Cristo estava sujeita ao
pecado, como se disse, resulta que a carne de Cristo pagou dízimos em Abraão.

4. Demais. — Isto não encontra de nenhum modo à dignidade de Cristo. Pois, nada impede que um
pontífice, cujo pai pagou o dizimo a um simples sacerdote, o sobrepuje a este em dignidade. Embora,
pois, se diga que Cristo pagou dízimos, quando Abraão os pagou a Melquisedeque, nem por isso fica
excluído que Cristo fosse maior que Melquisedeque.
Mas, em contrário, Agostinho diz, que Cristo não pagou dízimos em Abraão, porque a sua carne não
tirou daí a virulência de um ferimento, mas a matéria de um remédio.

SOLUÇÃO. — Segundo a intenção do Apóstolo, devemos dizer que Cristo não foi dizimado nos lombos
de Abraão. Pois, como o mesmo Apóstolo o prova, o sacerdócio segundo a ordem de Melquisedeque era
maior que o sacerdócio levítico, pelo qual Abraão pagou dízimos a Melquisedeque, quando ainda Levi
existia nos lombos dele, Abraão, a quem pertencia o sacerdócio legal. Se, pois, Cristo fosse dizimado em
Abraão, o seu sacerdócio não seria segundo a ordem de Melquisedeque, mas seria menor que este
sacerdócio. Donde devemos concluir, que Cristo não foi, como Levi, dizimado nos lombos de Abraão.
Pois, como aquele que pagava os dízimos, retinha nove partes para si e entregava a décima a outrem, o
que é sinal de perfeição, por ser de certo modo o número dez o termo de todos os números, que
chegam até dez, daí vinha que quem pagava os dízimos proclamava-se imperfeito e atribuía a outrem a
perfeição. Ora, a imperfeição do gênero humano resulta do pecado, que por isso precisa da perfeição de
quem o cure. Mas, se Cristo pode curar do recado, pois, é o Cordeiro, que tira o pecado do mundo,
como diz o Evangelho. Ora, figura de Cristo foi Melquisedeque, segundo o prova o Apóstolo. Por onde,
quando Abraão pagou dízimos a Melquisedeque, confessou em figura que foi concebido no pecado e
que todos os que dele houvessem de descender, por terem contraído o pecado original, precisavam da
cura, que Cristo havia de trazer. Quanto a Isaac, a Jacó e a Levi e todos os outros, esses existiram em
Abraão, de modo que dele derivaram não só pela substância corpórea, mas ainda por via seminal, pela
qual se contrai o pecado original. Por isso, todos foram dizimados em Abraão, isto é, prefiguravam a
necessidade da cura, que viria de Cristo. Mas só Cristo existiu em Abraão de modo que dele procedesse
não por via seminal, mas pela substância corpórea. Por isso, não existiu em Abraão como os que
precisavam de cura, mas antes, como o remédio dos ferimentos. Logo, não foi dizimado nos lombos de
Abraão.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — A Santa Virgem foi concebida no pecado original e por isso existiu em Abraão
como quem precisava de cura. Por isso foi dizimada nele, como nele descendente por via seminal. Mas
tal não se deu com o corpo de Cristo, como dissemos.

RESPOSTA À TERCEIRA. — Diz-se que a carne de Cristo foi contaminada do pecado, nos antigos
patriarcas, pela qualidade que tinha nesses patriarcas, que foram dizimados, Mas não pela qualidade
que tem em Cristo, atualmente nele existente, pois assim não foi dizimado.

RESPOSTA À QUARTA. — O sacerdócio Levítico tinha uma origem carnal. Por isso, não existiu menos em
Abraão que em Levi. Por onde, o fato de ter Abraão pago dízimos a Melquisedeque, como seu maior,
mostra que o sacerdócio de Melquisedeque, como simbolizando a figura de Cristo, é maior que o
sacerdócio levítico. Mas o sacerdócio de Cristo não teve uma origem carnal, mas se transmite pela graça
espiritual. E assim podia dar-se que o pai pagasse dízimos a um sacerdote, como o maior o paga ao
menor; e contudo o filho, sendo pontífice, fosse maior que esse sacerdote, não pela origem carnal, mas
pela graça espiritual, que recebeu de Cristo.