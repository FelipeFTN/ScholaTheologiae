# Questão 5: Da assunção das partes da natureza humana
Em seguida devemos tratar da assunção das partes da natureza humana.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se o Filho de Deus assumiu um verdadeiro corpo.
O primeiro discute-se assim. — Parece que o Filho de Deus não assumiu um verdadeiro corpo.

1. — Pois, diz o Apóstolo, que ele, se fez semelhante aos homens. Ora, o que verdadeiramente existe
não existe por semelhança. Logo, o Filho de Deus não assumiu um verdadeiro corpo.

2. Demais. — A assunção do corpo em nada contrariava à dignidade da divindade; assim, como diz Leão
Papa, nem a glorificação destruiu a natureza inferior, nem a assunção diminuiu a superior. Ora, a
dignidade de Deus exige que seja totalmente separado do corpo. Logo, parece que, pela assunção, Deus
não: se uniu a um corpo.

3. Demais. — Os sinais devem responder aos assinalados. Ora, as aparições do Antigo Testamento, que
foram os sinais e as figuras da aparição de Cristo, não eram realmente de natureza corpórea, mas
construíam visões imaginárias, como o adverte a Escritura: Vi ao Senhor assentado, etc. Logo, parece
que também a aparição do Filho de Deus no mundo não foi a de um corpo real, mas só em figura.
Mas, em contrario, diz Agostinho, se o corpo de Cristo foi um fantasma, Cristo enganou; e se enganou,
não é a verdade. Ora, Cristo é a verdade. Logo, fantasma não foi o seu corpo. E assim, é claro que
assumiu um verdadeiro corpo.

SOLUÇÃO. — Como foi dito, o Filho de Deus não nasceu patativamente, quase com um corpo figurado,
mas, com um verdadeiro corpo. E disto podemos dar três razões. — A primeira é deduzida da natureza
humana, à qual é próprio ter um corpo. Suposto, pois, pelo que já dissemos, que era conveniente o Filho
de Deus assumir a natureza humana, resulta, como consequência, que teve um verdadeiro corpo. — A
segunda razão pode ser deduzida do que se realizou no mistério da Encarnação. Pois, se o corpo de
Cristo não era real mas fantástico, também consequentemente não padeceu uma verdadeira morte,
nem nada do que dele narram os Evangelistas realmente o praticou, mas só na aparência. Donde
também resultaria que não operou a verdadeira salvação do gênero humano, pois, há de o efeito
proporcionar-se à causa. — A terceira razão pode ser concluída da dignidade mesma da Pessoa
assumente, a qual, sendo a verdade, não lhe era decente existir qualquer ficção na sua obra. Por isso, o
próprio Senhor se dignou excluir esse erro. quando os discípulos, conturbados e aterrados, julgavam ver
um espírito e não um corpo verdadeiro. Por isso, ofereceu-se lhes a que o apalpassem, dizendo: Apalpai
e vede, que um espírito não tem carne nem ossos, como vós vedes que eu tenho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A referida semelhança exprime a verdade da natureza
humana em Cristo, ao modo pelo qual todos os que têm verdadeiramente a natureza humana se
consideram semelhantes, pela espécie. Mas não se entende por ela uma semelhança fantástica. E para
evidenciá-lo o Apóstolo acrescenta — Feito obediente até à morte e morte de cruz, o que não poderia
ser, se a semelhança fosse somente em imagem.

RESPOSTA À SEGUNDA. — Pelo fato do Filho de Deus ter assumido um corpo real em nada se lhe
diminuiu a dignidade. Por isso diz Agostinho: Abateu-se a si mesmo, tomando a forma de servo, para
que se tornasse servo; mas não perdeu a plenitude da forma de Deus. Pois o Filho de Deus não assumiu
um corpo real para que se fizesse a forma do corpo, o que repugna à divina simplicidade e pureza, pois
tal seria assumir um corpo na unidade de natureza; o que é impossível, como do sobredito se colhe.
Mas, salva a distinção da natureza, assumiu um corpo na unidade da pessoa.

RESPOSTA À TERCEIRA. — A figura deve corresponder à realidade quanto à semelhança e não quanto à
verdade mesma dessa realidade; pois, se a semelhança o fosse em tudo, já não seria um sinal, mas a
realidade mesma, como diz Damasceno. Logo, era conveniente que as aparições do Antigo Testamento
fossem só aparências, quase figuras; mas a aparição do Filho de Deus no mundo seria segundo a
verdade do corpo, quase uma realidade figurada pelas anteriores figuras. Donde o dizer o Apóstolo: Que
são sombra das coisas vindouras, mas o corpo é de Cristo.

## Art. 2 — Se Cristo tinha um corpo carnal ou terrestre ou celeste.
O segundo discute-se assim. — Parece que Cristo não tinha um corpo carnal nem terrestre nem
celeste.

1. — Pois, diz o Apóstolo: O primeiro homem, formado da terra é terreno; o segundo homem, do céu,
celestial. Ora, Adão, o primeiro homem, era de terra, quanto ao corpo, como se lê na Escritura. Logo,
também Cristo, o segundo homem, era do céu, pelo corpo.

2. Demais. — O Apóstolo diz: A carne e o sangue não podem possuir o reino de Deus. Ora, o reino de
Deus está principalmente em Cristo, Logo, ele não tem carne, nem sangue mas é, antes, um corpo
celeste.

3. Demais. — Tudo o que é ótimo devemos atribuir a Deus. Ora, dentre todos os corpos o nobilíssimo é
o corpo celeste. Logo, tal corpo é o que Cristo devia assumir,
Mas, em contrário, diz o Senhor: Um espírito não tem carne nem ossos, como vós vedes que eu tenho.
Ora, a carne e os ossos não são compostos de matéria do corpo celeste, mas dos elementos inferiores.
Logo, o corpo de Cristo não foi um corpo celeste, mas carnal e terreno.

SOLUÇÃO. — Pelas mesmas razões pelas quais demonstramos que o corpo de Cristo não devia ser um
corpo ficto, resulta que também não devia ser celeste. — Pois, primeiro, porque assim como a natureza
verdadeiramente humana não existiria em Cristo, se o seu corpo fosse ficto como ensinavam os
Maniqueus, assim também não o seria se o seu corpo fosse celeste, como ensinava Valentino. Ora,
sendo a forma do homem uma realidade natural, exige uma determinada matéria a saber, carnes e
ossos, que é mister introduzir na definição do homem, como está claro no Filósofo. — Segundo, porque
também contrariaria a verdade do que Cristo fez, na sua vida corpórea. Pois, sendo o corpo celeste
impassível e incorruptível, como o prova Aristóteles, se o Filho de Deus tivesse assumido um corpo
celeste, não teria tido verdadeiramente fome, nem sede, nem teria sofrido a paixão e a morte. —
Terceiro, também contrariaria à verdade divina. Pois, o Filho de Deus, tendo se manifestado aos homens
com um corpo de carne e terrestre, teria se manifestado falsamente, se tivesse um corpo celeste. Por
isso; foi dito: Nasceu o Filho de Deus, recebendo a carne do corpo de uma virgem, e não trazendo-a do
Céu consigo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De dois modos dizemos que Cristo desceu do céu. —
Primeiro, em razão da natureza divina; não que a natureza divina deixasse por isso de estar no céu, mas
porque começou a existir de uma nova maneira no mundo inferior, isto é, segundo a natureza assumida,
conforme aquilo do Evangelho: Ninguém subiu ao céu senão aquele que desceu do céu, a saber, o Filho
do homem, que. está no céu. — de outro modo, em razão do corpo; não porque o corpo mesmo de
Cristo, na sua substância, descesse do céu; mas porque o seu corpo foi formado por virtude celeste, isto
é, do Espírito Santo. Donde o dizer Agostinho, expondo a autoridade citada:digo que Cristo é celeste, pai
não ter sido concebido do ser humano. E nesse sentido também o expõe Hilário.

RESPOSTA À SEGUNDA. — Carne e sangue não se tomam, no lugar citado, pela substância da carne e do
sangue, mas pela corrupção da carne e do sangue. O que não existiu em Cristo por causa de nenhuma
culpa. Mas existiu temporalmente, quanto à pena, para que cumprisse a obra da redenção.

RESPOSTA À TERCEIRA. — Isso mesmo de um corpo enfermo e terrestre ter sido elevado a tanta
sublimidade, manifesta a grande glória de Deus. Por isso, no Sínodo Efesino se leem as palavras de Santo
Teófilo que dizem: Assim como não admiramos os melhores artistas somente quando exibem a sua arte
em matérias preciosas, mas fazemos deles uma opinião muito mais elevada quando, no mais das vezes,
tomam de um barro vil e da terra em dissolução, para mostrarem a sua capacidade; assim também o
Verbo, o melhor artífice de todos, não escolheu, para descer até nós, a matéria preciosa de nenhum
corpo celeste, mas nas fez ver a perfeição da sua arte exercendo-a no barro.

## Art. 3 — Se o Filho de Deus assumiu a alma.
O terceiro discute-se assim. Parece que o Filho de Deus não assumiu a alma.

1. — Pois, João expondo o mistério da Encarnação, disse: o Verbo se fez carne, sem fazer menção
nenhuma da alma, Ora, não diz que se fez carne porque nela se tivesse convertido, mas pela ter
assumido. Logo, parece que não assumiu a alma.

2. Demais. - A alma é necessária ao corpo para ser vivificado por ela. Ora, para isso não era necessária
ao corpo de Cristo como parece; pois é do próprio Verbo de Deus que diz a Escritura: Senhor, em ti está
a fonte da vida. Logo, era supérflua a presença da alma onde estava a do Verbo. Mas, Deus e a natureza
nada fazem em vão, como também o diz o Filósofo. Logo, parece que o Filho de Deus não assumiu a
alma.

3. Demais. — Da união da alma e do corpo constitui-se uma natureza comum, que é a espécie humana.
Ora, em Nosso Senhor Jesus Cristo não podemos admitir uma espécie. comum, como diz Damasceno.
Logo, não assumiu a alma.
Mas, em contrário, diz Agostinho: Não ouçamos aqueles que dizem ter sido só o corpo humano o
assumido pelo Verbo de Deus; esses ouvem o que foi dito - O Verbo se fez carne - para negarem que
esse homem tivesse a alma ou qualquer outra causa humana, além só da carne.

SOLUÇÃO. — Como diz Agostinho, foi primeiro opinião de Ário, e depois, de Apolinário; que o Filho de
Deus assumiu , só a carne, sem a alma, e ensinavam que o Verbo estava unido a carne, como se lhe
fosse a alma. Donde resultava que em Cristo não existiam duas naturezas, mas uma só; pois, da alma e
da carne constitui-se uma só natureza.
Mas esta opinião não pode subsistir, por três razões.
Primeiro, porque repugna à autoridade da Escritura, na qual o Senhor faz menção da sua alma. Assim,
dizem o Evangelhos: A minha alma está numa tristeza mortal e: Tenho o poder de pôr a minha alma. —
Mas a isto respondia Apolinário que, nessas palavras, a alma é tomada metaforicamente; assim, desse
modo é que o Antigo Testamento se refere à alma, quando diz: A minha alma aborrece as vossas
calendas e as vossas solenidades. - Mas, como diz Agostinho, os Evangelistas nas narrações dos
Evangelhos narram que Jesus se admirou, que se encolerizou que se contristou e teve fome. E isso tudo
demonstra que tinha verdadeiramente uma alma; assim como os fatos de comer, de dormir, de fatigar-
se demonstram que tinha verdadeiramente um corpo humano. Do contrário, se fossem essas
expressões metafóricas, como lemos coisas semelhantes no Antigo Testamento, de Deus, desapareceria
a fé da narração Evangélica. Pois, é uma coisa a anunciação profética figurada; e outra o que, com
propriedade real, constitui a narração histórica dos Evangelistas.
Segundo, o referido erro contraria à utilidade da Encarnação, que é a libertação do homem. Eis como a
esse respeito argumenta Agostinho: Por que, tendo assumido a carne, o Filho de Deus deixou de
assumir a alma? Era talvez ou porque, considerando-a inocente, pensou não ter ela necessidade de
remédio; ou tendo-a como estranha a si, não a gratificou com o benefício da redenção; ou renunciou a
curá-la julgando-a de todo incurável; ou enfim porque a rejeitou como um ser vil e totalmente inútil.
Ora, duas dessas hipóteses implicam uma blasfêmia contra Deus; pois, como ser chamado onipotente se
não pôde curar uma alma, de que desesperava? Ou como é o Deus de todos, se não foi ele mesmo que
criou a nossa alma? Das duas outras, uma desconhece a causa da alma, a outra não lhe leva em conta o
mérito. Pois, podemos crer que conheça a causa da alma quem pretende eximi-la do pecado de uma
transgressão voluntária, embora tenha sido preparada pelo hábito incluso da razão natural a receber a
lei? Ou como teria a ideia da sua nobreza, quem a representa como desprezível pela sua vileza? Se lhe
atenderes à origem, a alma é a mais preciosa das duas substâncias; se à culpa da transgressão, a sua
causa é a pior, dada a sua inteligência. Ora, eu de um lado conheço a perfeita sabedoria de Cristo e, de
outro, não duvido que seja misericordiosíssimo. A primeira dessas perfeições impediu-o de desdenhar a
melhor substância, a que é capaz de sabedoria; a segunda, a unir-se à que tinha sido mais
profundamente ferida.
Em terceiro lugar, essa opinião é contrária à verdade mesma da Encarnação. Pois, a carne e as outras
partes do homem se especificam pela alma. Por onde, ausentando-se a alma, já não há ossos nem carne
senão equivocamente, como está claro no Filósofo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando o Evangelho diz — O Verbo se fez carne —
carne significa todo o homem, como se dissesse: O Verbo se fez homem, no sentido em que diz a
Escritura: Toda a carne verá a salvação do nosso Deus. E todo o homem é significado pela carne, porque,
como diz o passo aduzido, pela carne o Filho de Deus manifestou-se visivelmente, sendo por isso que o
texto acrescenta: E vimos a sua glória. Ou então porque, como diz Agostinho, em toda a unidade dessa
assunção o principal é o Verbo; a carne vem em extremo e último lugar. Querendo, pois, o Evangelista
mostrar-nos até que ponto foi Deus, na abjecção da humildade, por amor de nós, referiu-se ao Verbo e
à carne, deixando de parte a alma, inferior, de um lado, ao Verbo e, de outro, superior à carne. E
também era racional que designasse a carne que, por distar mais do Verbo, parecia menos digna de ser
assumida.

RESPOSTA À SEGUNDA. — O Verbo é a fonte da vida, como a primeira causa efetiva dela. Mas, a alma é
o princípio da vida do corpo, como forma dele. Ora, a forma é o efeito de um agente. Por onde, da
presença do Verbo poderíamos antes concluir que o corpo era animado, assim como o poderíamos, da
presença do fogo, que é quente o corpo que ele atingiu.

RESPOSTA À TERCEIRA. — Não é inconveniente, mas antes, necessário dizer-se que Cristo tinha uma
natureza constituída pela alma que veio unir-se ao corpo. Mas Damasceno nega haja em Nosso Senhor
Jesus Cristo uma espécie comum, como um terceiro ser resultante da união da divindade à humanidade.

## Art. 4 — Se o Filho de Deus assumiu o entendimento humano ou intelecto.
O quarto discute-se assim. — Parece que o Filho de Deus não assumiu o entendimento humano ou
intelecto.
1 — Onde uma coisa está presente, nenhuma necessidade há da sua imagem. Ora, o homem, pela
inteligência, é a imagem de Deus, como diz Agostinho. E portanto, como em Cristo estava presente o
Verbo divino, não era necessário nele também o estivesse o intelecto humano.

2. Demais. — A luz maior ofusca a menor. Ora, o Verbo de Deus, a luz que alumia todo o homem que
vem a este mundo, como diz o Evangelho, está para a nossa inteligência, como a luz maior para a
menor; pois, também a inteligência é uma luz, quase uma lucerna iluminada pela luz primeira, no dizer a
Escritura. O espiráculo do homem é uma lucerna do Senhor. Logo, em Cristo, que é o Verbo de Deus,
não havia necessidade de existir a inteligência humana.

3. Demais. — A assunção da natureza humana pelo Verbo de Deus chama-se a sua Encarnação. Ora, o
intelecto ou entendimento humano nem é carne nem ato da carne, porque não é ato de nenhum corpo,
como .o prova Aristóteles. Logo, parece que o Filho de Deus não assumiu o entendimento humano.
Mas, em contrário, Agostinho diz: Crê firmissimamente e de nenhum modo duvides, que Cristo, Filho de
Deus, tem verdadeiramente a carne da nossa raça e uma alma racional. E da sua carne disse ele próprio:
Apalpei e vede; que um espírito não tem carne nem osso como vós vedes que eu tenho. E também
mostra que tem uma alma, quando diz: Eu ponho a minha vida para outra vez a assumir. E ainda mostra
que tem o intelecto da alma, ao dizer: Aprendei de mim que sou manso e humilde de coração. Enfim, o
Senhor diz de. si mesmo, pelo Profeta: Eis aí está que o meu servo terá inteligência.

SOLUÇÃO. — Agostinho diz: Os Apolinaristas dissentiam da Igreja Católica, no tocante à alma de Cristo,
ensinando como os Arianos, que Cristo assumiu só a carne sem a alma. Mas nessa questão, vencidos
pelo testemunho do Evangelho, disseram que o lugar da inteligência humana, que não existia na alma
de Cristo, ocupou-o o próprio Verbo.
Mas, essa doutrina, como a referida antes, se refuta pelas mesmas razões. Pois, primeiro, contraria à
narração Evangélica. quando refere que ele se admirava. Ora, a admiração não pode existir sem a razão,
porque implica na relação do efeito com a causa, isto é, porque a alma, vendo um efeito cuja causa
ignora, busca-lhe a causa, como diz Aristóteles. — Segundo, repugna à utilidade da Encarnação, que é a
justificação do homem pecador. Pois, a alma humana não é capaz de pecado, nem da graça justificante,
senão pelo intelecto. Por isso e principalmente era necessário que o entendimento humano fosse
assumido. Donde o dizer Damasceno, que o Verbo de Deus assumiu o corpo e a alma intelectual e
racional. E depois acrescenta: O todo foi unido ao todo para que a mim me gratificasse totalmente com
a salvação isto é, me desse graça santificante; pois, o que não pode ser assumido é incurável. —
Terceiro, repugna à Verdade da Encarnação. Pois, proporcionando-se o corpo à alma, como a matéria à
sua forma própria, não é verdadeiramente carne humana a que não é aperfeiçoada pela alma humana,
isto é, racional. Por onde, se Cristo tivesse a alma, sem a inteligência, não teria verdadeiramente a carne
humana, mas uma carne animal; porque só pela inteligência difere a nossa alma da alma do animal.
Donde o dizer Agostinho; que desse erro resultaria ter o Filho deDeus assumido um animal irracional
com a figura do corpo humano. O que, de novo repugna à verdade divina, que não se compadece com a
falsidade de nenhuma ficção.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Onde uma coisa está realmente presente não há
necessidade da sua imagem para se colocar em lugar ela coisa, Assim, onde está o imperador os
soldados não lhe irão venerar a imagem. Contudo, é necessário coexistir com a presença da coisa a sua
imagem, para completar-se com essa presença mesma Assim, uma imagem na cera se completa pela
impressão do sê-lo; e a imagem do homem se reflete no espelho pela presença dele. Por onde, para a
perfeição do entendimento humano foi necessário que o Verbo de Deus o unisse a si.

RESPOSTA À SEGUNDA. — Uma luz maior inutiliza a menor, de outro corpo luminoso; mas longe de
inutilizá-la aperfeiçoa a luz do corpo iluminado. Assim, a presença do sol obscurece a luz das estrelas ;
mas, aumenta a do ar. Ora, o intelecto ou o entendimento do homem é quase uma luz iluminada pela
do Verbo divino. Por onde, a luz do divino Verbo não inutiliza o entendimento humano, mas antes, a
completa.

RESPOSTA À TERCEIRA. — Embora a potência intelectiva não seja ato de nenhum corpo. contudo, a
essência mesma da alma humana, que é a forma do corpo, há de ser mais nobre para ter o poder de
inteligir. Por onde, é necessário lhe corresponda um corpo melhor disposto.