# Questão 64: Da causa dos sacramentos
Em seguida devemos tratar da causa dos sacramentos, quer quanto à autoria quer quanto ao ministério.
E nesta questão discutem-se dez artigos:

## Art. 1 — Se só Deus, ou também o ministro contribui interiormente para o efeito do sacramento.
O primeiro discute-se assim. — Parece que não só Deus, mas também, o ministro contribui para o
efeito do sacramento.

1. — Pois, o efeito interior do sacramento é purificar-nos do pecado e iluminar-nos pela graça. Ora, aos
ministros da Igreja compete purificar, iluminar e aperfeiçoar, como está claro em Dionísio. Logo, parece
que não só Deus, mas também os ministros da Igreja contribuem para o efeito do sacramento.

2. Demais. — Ao conferir os sacramentos se propõem certos sufrágios de orações. Ora, às orações dos
justos Deus as ouve melhor do que as de quaisquer outros, segundo aquilo do Evangelho: Se alguém dá
culto a Deus e faz a sua vontade, a este escuta Deus. Logo, parece que alcança maior efeito do
sacramento aquele que o recebe de um bom ministro. Assim, pois, também o ministro obra para o
efeito interior do sacramento e não só Deus.

3. Demais. — Mais digno é um homem que um ser inanimado. Ora, o ser inanimado contribui de certo
modo para o efeito interior, pois, a água toca o corpo e purifica o coração, no dizer de Agostinho. Logo,
o homem contribui de certo modo para o efeito do sacramento e não só Deus.
Mas, em contrário, o Apóstolo: Deus é quem justifica. Sendo, pois, a justificação o efeito interior de
todos os sacramentos, parece que só Deus causa o efeito interior do sacramento.

SOLUÇÃO. — De dois modos pode ser causado um efeito - a modo de agente principal e a modo de
instrumento. - Ora, do primeiro modo só Deus causa o efeito interior do sacramento.
Quer porque só Deus penetra na alma, no que recebe o efeito do sacramento, e não pode nenhum
agente obrar imediatamente onde não está. Quer também porque a graça, efeito interior do
sacramento, vem só de Deus, como dissemos na Segunda Parte. E ainda o caráter, efeito interior de
certos sacramentos, é uma virtude instrumental, que dimana do principio agente que é Deus. Mas, do
segundo modo, o homem pode contribuir para o efeito interior do sacramento, enquanto age como
ministro. Pois, o mesmo que se dá com o ministro se dá com o instrumento: o ato de um e de outro é de
origem extrínseca, mas produz um efeito interno em virtude do agente principal que é Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A purificação, enquanto atribuída aos ministros da
Igreja, não se refere à do pecado. Mas, dizemos que os diáconos purificam, ou porque expulsam os
imundos da sociedade dos fiéis, ou com sacras admoestações os dispõem à recepção dos sacramentos.
Semelhantemente também se diz dos sacerdotes, que iluminam o povo fiel, não por certo infundindo a
graça, mas comunicando os sacramentos da graça, como está claro no mesmo lugar de Dionísio.

RESPOSTA À SEGUNDA. — As orações ditas ao se conferirem os sacramentos são feitas a Deus, não em
nome de uma pessoa particular, mas em nome de toda a Igreja, cujas preces são ouvidas por Deus,
segundo o diz o Evangelho: Se dois de vós se unirem entre si sobre a terra, seja qual for a causa que eles
pedirem, meu Pai que está no céu lh'a fará. Ora, nada impede a oração de um varão justo em algo
contribuir para isso. Mas aquele que é realmente o efeito do sacramento não é impetrado por oração da
Igreja ou do ministro, mas resulta do mérito da paixão de Cristo, cuja virtude opera nos sacramentos,
como se disse. Por isso o efeito do sacramento não se torna melhor por ser melhor o ministro. Mas,
junto com esse efeito, pode ser impetrada uma graça àquele que recebe o sacramento, pela devoção do
ministro; mas essa não é obra do ministro, que pede a Deus a conceda.

RESPOSTA À TERCEIRA. — As coisas inanimadas não contribuem para o efeito interior, senão
instrumentalmente, como se disse. E semelhantemente, os homens não contribuem para o efeito dos
sacramentos senão a modo de ministério, como dissemos.

## Art. 2 — Se os sacramentos procedem só da instituição divina.
O segundo discute-se assim. — Parece que os sacramentos não procedem só da instituição divina.

1. — Pois, as instituições divinas nô-las transmite a Escritura. Ora, há certas práticas sacramentais de
que nenhuma menção faz a Escritura Sagrada. Assim, o crisma pelo qual os homens são confirmados; o
óleo com o qual são ungidos os sacerdotes; e muitas outras palavras e atos, de que se usa nos
sacramentos. Logo os sacramentos não procedem só da instituição divina.

2. Demais. — Os sacramentos são uns sinais.
Ora, as coisas sensíveis têm naturalmente uma significação. Nem se pode dizer que Deus se compraz
com umas significações e não com outras, pois ele aprova tudo quanto fez. E é procedimento próprio do
demônio aliciar a algum fim por meio de certos sinais. Assim, diz Agostinho: Criaturas que os demônios
não fizeram, mas que são a obra de Deus, os atraem a habitar nelas por encantos que variam segundo
suas diversas espécies. Não por alimentos, como se dá com os animais, mas por sinais, como convém
aos espíritos. Logo, parece que os sacramentos não precisam ser instituídos por Deus.

3. Demais. — Os Apóstolos fizeram as vezes de Deus no mundo, donde o dizer o Apóstolo: Pois eu
também a indulgência de que usei, se de alguma tenha usado, foi por amor de vós em pessoa de Cristo,
isto é, como o próprio Cristo o fizesse. Donde se conclui que os Apóstolos e os seus sucessores podiam
instituir novos sacramentos.
Mas, em contrário, faz uma instituição quem lhe dá vigor e virtude, como o demonstram os que
instituem leis. Ora, a virtude dos sacramentos vem só de Deus, como do sobredito resulta. Logo, só Deus
pode instituir o sacramento.

SOLUÇÃO. — Como do sobredito se infere os sacramentos produzem, como instrumentos, efeitos
espirituais. E, o instrumento tira a sua virtude do agente principal. Ora, o agente, com respeito ao
sacramento, é duplo, a saber: quem o institui e quem usa do sacramento instituído, aplicando-o à
produção do seu efeito. Mas, a virtude do sacramento não pode provir de quem usa dele, que não age
senão como ministro. Donde se conclui que a virtude do sacramento procede de quem o instituiu. Logo,
provindo à virtude do sacramento só de Deus, resulta por consequência que só Deus é o instituidor dos
sacramentos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As práticas instituídas pelos homens, no ministrar os
sacramentos, não são de necessidade para a existência deles; mas constituem uma certa solenidade, a
eles acrescentada para excitar a devoção e a reverência nos que· os recebem. Pois o que o sacramento
implica necessàriamente, o próprio Cristo o instituiu que é Deus e homem. E embora tudo não tenha
sido comunicado pela Escrituras, a Igreja, contudo o tem da tradição familiar dos Apóstolos, como o diz
o Apóstolo: No tocante às demais causas e as ordenarei quando for.

RESPOSTA À SEGUNDA. — As coisas sensíveis têm uma certa aptidão, por sua natureza, a significar
efeitos espirituais; mas essa aptidão é determinada a uma significação especial, por instituição divina.
Por isso diz Hugo de S. Victor, que o sacramento significa em virtude de uma instituição. Deus, porém
escolheu de preferência certas coisas, de entre outras, para as significações sacramentais, não porque a
isso lhes reduzisse os efeitos, mas para que a significação fosse mais conveniente.

RESPOSTA À TERCEIRA. — Os Apóstolos e os seus sucessores são os vigários de Deus quanto ao regime
da Igreja constituída pela fé e pelos sacramentos da fé. Por onde, assim como não lhes era lícito
constituir outra Igreja, assim também não lhes era permitido comunicar outra fé nem instituir outros
sacramentos; mas está dito, que pelos sacramentos que emanaram do lado de Cristo pendente da cruz,
foi fabricada a Igreja de Cristo.

## Art. 3 — Se Cristo, enquanto homem tinha o poder de produzir o efeito interior dos sacramentos.
O terceiro discute-se assim. — Parece que Cristo, enquanto homem tinha o poder de produzir o efeito
interior dos sacramentos.

1. — Pois, diz João Batista, como refere o evangelista: O que me mandou batizar em água me disse -
Aquele sobre que tu vires descer o Espírito e repousar sobre ele, esse é o que batiza no Espírito Santo.
Ora, batizar no Espírito Santo é conferir interiormente a graça do Espírito Santo. Ora, este desceu sobre
Cristo enquanto homem e não enquanto Deus, porque enquanto Deus é que ele dá o Espírito Santo.
Logo, parece que Cristo, enquanto homem tinha o poder de causar o efeito interior dos sacramentos.

2. - Demais. — O Senhor diz no Evangelho: Sabei que o Filho do homem tem o poder sobre a terra de
perdoar os pecados. Ora, o perdão dos pecados é o efeito interior dos sacramentos. Logo, parece que
Cristo, enquanto homem, produz o efeito interno dos sacramentos.

3. Demais. —- A instituição dos sacramentos pertence aquele que como agente principal, produz o
efeito interno deles. Ora, é manifesto que Cristo instituiu os sacramentos. Logo, ele é quem produz o
efeito interno deles.

4. Demais. —- Ninguém pode, prescindindo do sacramento, conferir-lhe o efeito, salvo se produzir por
virtude própria o efeito do mesmo. Ora, Cristo, sem sacramento, conferiu-lhe o efeito, como é claro pelo
que disse a Madalena: Perdoados te são teus pecados. Logo, parece que Cristo, enquanto homem,
produz o efeito interior dos sacramentos.

5. Demais. — Aquele por virtude de quem o sacramento é produzido é o agente principal do efeito
interior. Ora, os sacramentos tiram a sua virtude da paixão de Cristo e da invocação do seu nome,
segundo aquilo do Apóstolo: Porventura Paulo foi crucificado por vós, ou haveis sido batiza dos em
nome de Paulo? Logo, Cristo enquanto homem produz o efeito interno dos sacramentos.
Mas, em contrário, diz Agostinho: Nos sacramentos a virtude divina produz mais secretamente a
salvação. Ora, a virtude divina é Cristo, enquanto Deus e não enquanto homem. Logo, Cristo não produz
o efeito interior dos sacramentos enquanto homem, mas enquanto Deus.

SOLUÇÃO. — Cristo produz o efeito interior dos sacramentos enquanto Deus e enquanto homem, mas
de modos diferentes. Pois, enquanto Deus age como autor dos sacramentos; e enquanto homem
produz os efeitos internos dos sacramentos meritória e eficientemente, mas instrumentalmente. Pois,
como dissemos a paixão de Cristo, que sofreu enquanto revestido da natureza humana, é a causa da
nossa justificação e meritoriamente. E efetivamente, não a modo de agente principal, ou como antes,
mas a modo de instrumento, enquanto a humanidade é o instrumento de sua divindade, como se disse.
Contudo, como é um instrumento unido à divindade na pessoa, tem uma certa principalidade e
causalidade em relação aos instrumentos extrínsecos, que são os ministros da Igreja, como do sobre
dito se colhe. Por onde, assim como Cristo, enquanto Deus tem nos sacramentos o poder de autor
deles, assim também, enquanto homem, tem o poder de ministério principal ou poder de excelência. E
este consiste em quatro coisas. - Primeiro, em que o mérito e a virtude da sua paixão opera nos
sacramentos, como se disse. - Ora, a virtude da paixão se nos une pela fé, segundo aquilo do Apóstolo:
Ao qual propôs Deus para ser vítima de propiciação pela fé no seu sangue, fé que manifestamos pela
invocação do nome de Cristo. Por onde e em segundo lugar, do poder de excelência que Cristo tem nos
sacramentos resulta que no seu nome os sacramentos são santificados. - E como pela sua instituição é
que os sacramentos têm a sua virtude, dai vem, em terceiro lugar, que por causa da excelência do seu
poder é que Cristo, que deu a virtude aos sacramentos, podia instituí-los. E não dependendo a causa do
efeito, mas antes ao contrário, em quarto lugar, pela excelência do seu poder Cristo podia conferir o
efeito dos sacramentos sem nenhum sacramento externo.
Donde se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES; pois uma e outra parte das objeções é
verdadeira de certo modo, como se disse.

## Art. 4 — Se Cristo podia comunicar aos ministros o poder que tem nos sacra¬mentos.
O quarto discute-se assim. — Parece que Cristo não podia comunicar aos ministros o poder que tem
nos sacramentos.

1. — Pois, como argumenta Agostinho, se podia e não queria era invejoso. Ora, a inveja de nenhum
modo existia em Cristo, que tinha a suma plenitude da caridade. Logo, não tendo Cristo comunicado o
seu poder aos ministros parece que não podia comunicar.

2. Demais. — Aquilo de João - Fará coisas maiores que esta - diz Agostinho: Dizia que é certamente
maior, isto é, de um ímpio fazer um justo, do que criar o céu e a terra. Ora, Cristo não podia comunicar
aos ministros o criarem o céu e a terra. Logo, nem o justificarem o ímpio. Ora, a justificação do ímpio,
fazendo-se pelo poder que Cristo tem nos sacramentos, parece que o seu poder, que tinha nos
sacramentos, não no podia comunicar aos ministros.

3. Demais. — A Cristo, enquanto cabeça da Igreja competia derivar de si a graça para os outros, segundo
aquilo do Evangelho: Da sua plenitude todos nós recebemos. Ora, isso não era comunicável a outrem,
porque então a Igreja seria monstruosa, por ter muitas cabeças. Logo, parece que Cristo não podia
comunicar o seu poder aos ministros.
Mas, em contrário, àquilo do Evangelho Eu não no conhecia - diz Agostinho: Não sabia que o poder
mesmo do batismo o Senhor o teria e guardaria para si. Ora, isso não o havia de ignorar João, se tal
poder não fosse comunicável. Logo, Cristo podia comunicar o seu poder aos ministros.

SOLUÇÃO. — Como dissemos, Cristo nos sacramentos tem um duplo poder. - Um, como autor, que lhe
compete enquanto Deus. E esse a nenhuma criatura podia comunicar, como não podia comunicar a
divina essência. - Mas tinha outro poder, o de excelência, que lhe cabia como homem, e esse podia
comunicar aos ministros, dando-lhes tão grande plenitude de graça, que o mérito deles contribuísse
para o efeito do sacramento; de modo que pela invocação do nome deles fossem santificados os
sacramentos, que eles próprios pudessem instituir sacramentos e, sem o rito destes, conferissem pelo
seu só império os efeitos sacramentais. Pois um instrumento conjunto, quanto mais forte for, tanto mais
pode influir a sua virtude ao instrumento separado; como as mãos, ao bastão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não foi por inveja que Cristo deixou de comunicar aos
ministros o poder da excelência da Igreja, mas para utilidade dos fiéis, a fim de que não pusessem no
homem a sua esperança. E não houvesse diversos sacramentos donde nascesse a divisão na Igreja,
como entre aqueles que diziam: Eu sou de Paulo e eu de Apolo e eu de Cefas, segundo refere o
Apóstolo.

RESPOSTA À SEGUNDA. — A objeção procede, no atinente ao poder de autoria, que convém a Cristo
enquanto Deus. Embora também o poder de excelência possa chamar-se autoria por comparação com
os outros ministros. Por onde, àquilo do Apóstolo - Está dividido Cristo - diz a Glosa, que podia dar a
autoridade de batizar aqueles a quem conferiu o ministério.

RESPOSTA À TERCEIRA. — Para evitar o inconveniente de haver muitas cabeças na Igreja. Cristo não
quis comunicar o poder da sua excelência aos ministros. Se, porém a tivesse comunicado, seria ele o
chefe principal e os outros, secundários.

## Art. 5 — Se o sacramento pode ser conferido por maus ministros.
O quinto discute-se assim. — Parece que o sacramento não pode ser conferido por maus ministros.

1. — Pois, os sacramentos da lei nova se ordenam à purificação da culpa e à colação da graça. Ora, os
maus, sendo imundos, não podem purificar os outros do pecado, segundo aquilo da Escritura: Que coisa
será alimpada por um imundo? E, além disso, não tendo a graça, não na podem conferir, porque
ninguém dá o que não tem. Logo, parece que os sacramentos não podem ser conferidos pelos maus.

2. Demais. — Toda a virtude dos sacramentos deriva de Cristo, como se disse. Ora, os maus estão
separados de Cristo, por não terem a caridade, que une os membros à cabeça segundo aquilo da
Escritura: Aquele que permanece na caridade permanece em Deus. Logo, parece que pelos maus os
sacramentos não podem ser conferidos.

3. Demais. — Faltando alguma das condições necessárias para o sacramento, este não tem lugar; assim,
se faltar a forma ou as matérias devidas. Ora, o ministro competente do sacramento é o que não tem a
mácula do pecado, segundo aquilo da Escritura: O homem de qualquer das famílias da tua linhagem,
que tiver deformidade não oferecerá pães ao seu Deus nem se chegará ao seu ministério. Logo, parece
que, sendo o ministro mau, não se realiza o sacramento.
Mas, em contrário, àquilo do Evangelho sobre quem vires o Espírito - diz Agostinho: João não sabia que
o próprio Senhor haveria de ter e reservar para si o poder de batizar, mas haveria de conferir
completamente o ministério, tanto aos bons como aos maus. Que te importa o mau ministro, quando o
Senhor é bom?

SOLUÇÃO. — Como dissemos os ministros da Igreja atuam nos sacramentos instrumentalmente, pois,
de certo modo o ministro e o instrumento têm a mesma natureza. Porque, como dissemos o
instrumento não age pela sua forma própria, mas por virtude de quem o move. Por isso o instrumento,
como tal, pode acidentalmente ter qualquer forma ou virtude, além do que exige a sua natureza de
instrumento. Assim, o corpo do médico, instrumento da alma possuidora da arte, pode ser são ou
enfermo; o tubo, por onde passa a água, pode ser de prata ou de chumbo. Por onde, os ministros da
Igreja podem conferir os sacramentos, mesmo sendo maus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. - Os ministros da Igreja nem purificam dos pecados os que
se achegam aos sacramentos, nem têm o poder de conferir a graça; mas isso tudo o faz Cristo com o seu
poder, mediante os ministros como uns instrumentos. Por onde, alcançam os efeitos dos sacramentos
os que os recebem, não por serem esses efeitos semelhanças dos ministros, mas por serem
configuração de Cristo.

RESPOSTA À SEGUNDA. — Pela caridade os membros de Cristo se unem com o chefe, de modo a
receberem dele a vida; pois, como diz a Escritura: aquele que não ama permanece na morte. Mas,
podemos obrar por meio de um instrumento sem vida e sem união corporal conosco, contanto que nos
esteja unido por algum movimento; pois, de um modo obra o artista com as mãos e, de outro, com um
machado. Assim, portanto, Cristo atua nos sacramentos: pelos bons, como por membros vivos; e pelos
maus, como por instrumentos carecentes de vida.

RESPOSTA À TERCEIRA. — Uma condição pode ser necessária a um sacramento, de dois modos. -
Primeiro como sendo de necessidade para o sacramento. E então, faltando, não se perfaz o sacramento;
talo caso de falhar a forma ou a matéria própria. - De outro modo uma condição é necessária ao
sacramento por uma certa conveniência. E assim, é necessário que os ministros dos sacramentos sejam
bons.

## Art. 6 — Se os maus, ministrando os sacramentos, pecam.
O sexto discute-se assim. — Parece que os maus, ministrando os sacramentos não pecam.

1. — Pois, assim como se serve a Deus com os sacramentos, assim também por meio de obras de
caridade conforme àquilo do Apóstolo: Não vos esqueçais de fazer bem e de repartir dos vossos bens
com os outros, porque com tais oferendas é que Deus se dá por obrigado. Ora, os maus não pecam,
servindo a Deus com obras de caridade; antes deve lhes ser isso aconselhado, conforme àquilo da
Escritura: Segue o conselho que te doa e rime o teu pecado com esmolas. Logo, parece que os maus não
pecam ministrando os sacramentos.

2. Demais. — Todo o que é cúmplice do pecado de outrem é também réu do pecado, segundo aquilo do
Apóstolo: São dignos de morte não somente os que cometem pecados, mas também os que consentem
aos que os cometem. Ora, se os maus ministros pecam ministrando os sacramentos, os que deles
recebem os sacramentos também participam desse pecado. Logo, também pecariam; o que é
inadmissível.

3. Demais. — Ninguém deve viver perplexo, porque então seríamos levados ao desespero, por não
podermos fugir o pecado. Ora, se os maus pecassem ministrando os sacramentos ficariam perplexos,
porque às vezes pecariam não os ministrando por exemplo, quando por dever são a isso
necessàriamente obrigados. Assim, diz o Apóstolo: Ai de mim se não evangelizar, pois me é imposta essa
obrigação. E outras vezes por perigo; tal o caso do pecado a quem se apresenta para ser batizada uma
criança em perigo de morte. Logo, parece que os maus não pecam ministrando os sacramentos,
Mas, em contrário, Dionísio diz, que aos maus não é permitido nem tocar os símbolos, isto é, os sinais
sacramentais. E noutro lugar: Esse tal, isto é, o pecador, será audacioso se tocar com as mãos nas cousas
sacerdotais, despido de tremor e de decência, buscando a divindade, sem respeito ao divino, e julgando
que Deus ignora o que ele em si mesmo conhecia. Pensando enganar aquele a quem chama
mentirosamente de Pai, ousa formalmente, pronunciar, em nome de Cristo, não direi orações, mas
infames e impuras palavras sobre os sinais divinos.

SOLUÇÃO. — Peca, na sua ação, quem obra diferentemente do que deve como diz o Filósofo. Ora, como
dissemos, convém os ministros dos sacramentos serem justos, pois devem os ministros se conformar
com o Senhor, segundo aquilo da Escritura: Sede santos porque eu sou santo. E noutro lugar: Qual é o
juiz do povo tais são também os seus ministros. Não há, pois, dúvida que os maus, procedendo como
ministros de Deus e da Igreja na dispensação dos sacramentos, pecam. E como esse pecado implica uma
irreverência a Deus e profanação dos sacramentos, por parte do pecado embora, santos em si mesmos,
não sejam os sacramentos susceptíveis de profanação, resulta por consequência que tal pecado é no
seu gênero mortal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As obras de caridade não são santificadas por nenhuma
consagração, mas estão incluídas na santidade da justiça, como partes desta. Por isso o homem que se
exibe dá a Deus como ministro nas obras de caridade - se for justo, mais se santificará; se porem for
pecador, assim se disporá para a santidade. Mas os sacramentos em si mesmos encerram uma certa,
santificação pela consagração mística. Por isso, preexige-se do ministro a santidade da justiça, para bem
exercer o seu ministério. Por onde, age inconvenientemente e peca se, vivendo no pecado exercer tal
ministério.

RESPOSTA À SEGUNDA. — O que se acerca dos sacramentos recebe-os do ministro da Igreja, não
enquanto é este uma determinada pessoa, mas enquanto ministro. Por isso, enquanto a Igreja o tolera
no ministério, quem dele receber o sacramento não lhe participa do pecado: mas está em comunhão
com a Igreja, que o tem como ministro. Se, porém a Igreja não o tolera - por exemplo, quando é
degradado ou excomungado ou suspenso - peca quem dele receber o sacramento, porque lhe participa
do pecado.

RESPOSTA À TERCEIRA. — Quem está em pecado mortal não está perplexo, absolutamente falando, se
por dever tem de dispensar os sacramentos; porque pode arrepender-se do pecado e ministrar
licitamente. Mas não há inconveniente se estiver perplexo, feita a suposição que queira perseverar no
pecado. - Mas em artigo de necessidade não pecaria batizando, em caso em que mesmo um leigo
pudesse batizar. Por onde é claro que não procederia como ministro da Igreja, mas em socorro da
necessidade do paciente. Mas o mesmo não se dá com aqueles sacramentos que não são de tanta
necessidade como o batismo, como a seguir se dirá.

## Art. 7 — Se os anjos podem ministrar os sacramentos.
O sétimo discute-se assim. — Parece que os anjos podem ministrar os sacramentos.

1. — Pois, tudo o que pode um ministro inferior pode também um superior; assim, tudo o que pode o
diácono pode também o sacerdote, mas não inversamente. Ora, os anjos são ministros superiores na
ordem hierárquica a qualquer homem, como está claro em Dionísio. Logo, podendo o homem ministrar
os sacramentos, parece que, com muito maior razão também o podem os anjos.

2. Demais. — Os varões santos são comparáveis aos anjos do céu, como diz o Evangelho. Ora, certos
santos dos que estão no céu podem ministrar os sacramentos, porque o caráter sacramental é indelével,
como se disse. Logo, parece que também os anjos podem ministrar os sacramentos.

3. Demais. — Como dissemos, o diabo é o chefe dos maus e os maus são os seus membros. Ora, os maus
podem dispensar os sacramentos. Logo, parece que também os demônios.
Mas em contrário, o Apóstolo: Todo pontífice, assunto dentre os homens é constituído a favor dos
homens naquelas coisas que tocam à Deus. Ora, os anjos bons ou maus não são assuntos dentre os
homens. Logo, não são constituídos ministros naquelas coisas que tocam a Deus, isto é, dos
sacramentos.

SOLUÇÃO. — Como dissemos, toda a virtude dos sacramentos deriva da paixão de Cristo, que Cristo
sofreu enquanto homem. E a ele se conformam os homens pela natureza; mas não os anjos, pois antes
pela sua paixão, como diz o Apóstolo, por um pouco foi menor que os anjos. Logo, pertence aos homens
dispensar os sacramentos e ser ministros deles, mas não aos anjos. Devemos porém, saber que, assim
como Deus não aligou a sua virtude aos sacramentos, de modo que não pudesse conferir, sem ele, o
efeito deles, assim também não na ligou aos ministros da Igreja, de modo que não pudesse atribuir aos
anjos o poder de ministrar os sacramentos. E como os bons anjos são os núncios da verdade, o
ministério sacramental que fosse exercido por eles deveria ser considerado como correto. Porque
devíamos concluir que assim foi feito por vontade divina, como dizemos que certos templos foram
consagrados pelo ministério angélico. Se porem os demônios; espíritos da mentira, exercessem algum
ministério sacramental, não o deveríamos ter por bom.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Aquilo que os homens fazem de um modo inferior, isto
é, por meio dos sacramentos sensíveis, proporcionados à natura deles, fazem-nos os anjos, como
ministros superiores, de modo superior, isto é, invisivelmente purificando, iluminando e aperfeiçoando.

RESPOSTA À SEGUNDA. — Os santos que estão no céu são semelhantes aos anjos quanto à participação
da glória, mas não quanto à condição da natureza. E por consequência nem quanto aos sacramentos.

RESPOSTA À TERCEIRA. — Os homens maus não têm o poder de ministrar os sacramentos pelo fato de,
pela sua malícia, serem membros do diabo. Donde, pois, não se segue que o diabo, chefe deles, o possa,
mais que eles.

## Art. 8 — Se a intenção do ministro é necessária para a perfeição do sacramento.
O oitavo discute-se assim. — Parece que a intenção do ministro não é necessária para a perfeição do
sacramento.

1. — Pois, o ministro obra nos sacramentos instrumentalmente. Ora, a ação não se torna perfeita pela
intenção do ministro, mas pela do agente principal. Logo, a intenção do ministro não é necessária para a
perfeição do sacramento.

2. Demais. — Não pode um homem conhecer a intenção de outro. Se, pois, a intenção do ministro fosse
necessária para a perfeição do sacramento, não poderia quem se achegasse a recebê-lo saber que o
recebeu; e assim, não poderia ter certeza da sua salvação, sobretudo que certos sacramentos são de
necessidade para a salvação, como a seguir se dirá.

3. Demais. — A nossa intenção não pode existir quando não estamos atentos ao que fazemos. Ora, às
vezes os que ministram os sacramentos não pensam no que dizem ou fazem, estando a pensar em outra
coisa. Logo, assim sendo, não se consumaria o sacramento por falta de intenção.
Mas, em contrário, o que está fora da nossa intenção é casual. O que se não pode dizer da celebração
dos sacramentos. Logo, os sacramentos implicam a intenção do ministro.

SOLUÇÃO. — Quando um agente é capaz de muitas atividades, é necessário de algum modo
determinar-se a uma delas, se essa deve ser efetivada. Ora, as práticas sacramentais podem ser feitas
de diversos modos. Assim, a ablução da água, no batismo, pode ordenar-se tanto à limpeza como à
saúde do corpo, ou a divertimento ou a muitas outras finalidades semelhantes. Logo, é necessário que
seja determinada a um fim particular, isto é, ao efeito sacramental, pela intenção de quem faz a
ablução. E essa intenção se exprime pelas palavras proferidas nos sacramentos; por exemplo, quando se
diz - Eu te batizo em nome do Padre, etc.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um instrumento inanimado não tem nenhuma intenção
relativamente ao efeito; mas em lugar da intenção está o movimento, que lhe imprime o agente
principal. Um instrumento animado porém, como um ministro, não só é movido, mas também de certo
modo move-se a si mesmo, porque por vontade sua move os membros _ a agir. Logo, é necessária a sua
intenção de sujeitar-se ao agente principal de modo que tenha a intenção de fazer o que faz Cristo e a
Igreja.

RESPOSTA À SEGUNDA. — Há duas opiniões nesta matéria. - Uns dizem que para haver sacramento é
necessária a intenção mental do ministro, na falta da qual não haverá. Mas essa falta Cristo, que batiza
internamente, supre, em se tratando de crianças que não têm a intenção de receber o sacramento. E
em se tratando de adultos, com a intenção de recebê-lo, a fé e a devoção suprem a falta. Mas esta
opinião seria admissível quanto ao efeito último, que é a justificação dos pecados; mas quanto ao
consistente na matéria e no sacramento, isto é, o caráter, a devoção de quem recebe o sacramento não
pode suprir, porque nunca é impresso o caráter senão pelo sacramento. Por isso outros, e melhor dizem
que o ministro do sacramento age em nome de toda a Igreja, da qual é ministro. Pois, as palavras que
profere exprimem a intenção da Igreja, bastando à perfeição do sacramento. a menos que o contrário
não seja exteriormente expresso pelo ministro e pelo que recebe o sacramento.

RESPOSTA À TERCEIRA. — Embora aquele que pensa em outra coisa não tenha a intenção atual, tem-na
contudo habital e essa basta para haver o sacramento. Assim, o sacerdote que for batizar e tiver a
intenção de fazer o que a Igreja faz quando batiza. Por isso se depois, no ato de batizar, o seu
pensamento for desviado para outros objetos, o sacramento se perfaz pela virtude da primeira
intenção. Embora deva o ministro do sacramento empregar estudo para também ter a intenção atual.
Mas isso não depende totalmente do nosso poder porque, quando queremos vivamente aplicar a nossa
intenção, começamos a pensar em outras coisas que nela não estão, conforme aquilo da Escritura: O
meu coração me desamparou.

## Art. 9 — Se a fé do ministro é necessária para o sacramento.
O nono discute-se assim. — Parece que a fé do ministro não é necessária para a existência do
sacramento.

1. — Pois, como se disse, a intenção do ministro é necessária para a existência do sacramento. Ora, a fé
dirige a intenção, como diz Agostinho. Logo, faltando à verdadeira fé no ministro, não se perfaz o
sacramento.

2. Demais. — O ministro da Igreja que não tiver a verdadeira fé é herético. Ora, segundo parece, os
heréticos não podem conferir os sacramentos. Assim, diz Cipriano: Tudo o feito pelos heréticos é carnal,
vão e falso; de modo que nada do que façam devemos aprovar. E Leão Papa: É manifesto que pela
cruelíssima e insaníssima, vesânia da sé de Alexandria extinguiu-se todo o lume celeste dos
sacramentos. Cessou a oblação do sacrifício, desapareceu a santificação do crisma e todos os mistérios
se eclipsaram às mãos parricidas dos ímpios. Logo, para o sacramento é necessária a fé verdadeira do
ministro.

3. Demais. — Os que não têm a verdadeira fé são pela excomunhão separados da Igreja. Assim, segundo
epístola canônica de João: Se alguém vem a vós e não traz essa doutrina, não no recebais em vossa casa,
nem lhe digais: Deus te salve. E o Apóstolo: Foge do homem herege depois da primeira e segunda
correção. Ora, o excomungado parece que não pode conferir o sacramento da Igreja, desde que dela
está separado, dela a quem pertence à dispensação dos sacramentos. Logo, parece que a verdadeira fé
do ministro é necessária para haver sacramento.
Mas, em contrário, Agostinho: Lembra-te que aos sacramentos de Deus em nada podem obstruir os
maus costumes dos homens, de modo que por causa destes viessem eles a não ser santos ou a o serem
menos.

SOLUÇÃO. — Como já dissemos o ministro, agindo instrumentalmente nos sacramentos não obra por
virtude própria, mas por virtude de Cristo. Ora, assim como à virtude própria do homem pertence à
caridade, assim também a fé. Por onde, como não é preciso a perfeição do sacramento que o ministro
viva na caridade, mas mesmo os pecadores podem conferi-lo, conforme se disse assim a perfeição do
sacramento não lhe exige a fé, mas os infiéis podem conferir verdadeiramente o sacramento, contanto
que existam as outras condições que são de necessidade para o sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pode se dar que alguém tenha uma fé deficiente nalgum
ponto e não quanto ao sacramento que ministra. Por exemplo, se Crê que o juramento é em todos os
casos ilícito e contudo crê que o batismo tem eficácia para a salvação. E assim, essa infidelidade não
dissipa a intenção de conferir o sacramento. Se porém não tem fé no sacramento mesmo que ministra,
embora creia que do ato que exteriormente pratica não resulta nenhum efeito interior, não ignora
contudo que a Igreja católica tem a intenção de, mediante esses atos internos, conferir o sacramento.
Por onde não obstante a infidelidade, pode ter a intenção de fazer o que faz a Igreja, embora julgue que
isso nada é. E tal intenção basta para o sacramento, porque, como dissemos, o ministro do sacramento
age em nome de roda a Igreja, cuja fé supre o que falta à fé do ministro.

RESPOSTA À SEGUNDA. — Certos heréticos ao conferirem os sacramentos não observam a formalidade
da Igreja. E esses não conferem nem o sacramento nem a realidade dele. - Certos porem observam a
formalidade da Igreja. E esses conferem verdadeiramente o sacramento, mas não a matéria do mesmo.
E isto digo, se estão manifestamente separados da Igreja. Porque pelo fato mesmo de alguém receber
deles o sacramento peca; e isso impede de ser alcançado o efeito do sacramento. Donde o dizer
Agostinho: Crê firmissimamente e de nenhum modo duvides que aos batizados fora da Igreja, se a ela
não voltarem, ao batismo se lhes acrescenta o pecado. E nesse sentido diz Leão Papa, que na sé de
Alexandria se extinguiu totalmente o lume dos sacramentos, isto é, quanto à matéria sacramental, mas
não quanto aos sacramentos em si mesmos. - Cipriano porem cria que nem o sacramento os heréticos
oferecem. Mas, neste ponto, não se lhe sustenta a opinião. Por isso diz Agostinho: O mártir Cipriano não
quis reconhecer o batismo conferido pelos heréticos ou cismáticos. Foram porem tão grandes os
méritos, até o triunfo do martírio, que ganhou, que a refulgente luz da sua caridade fez desaparecer
essa sombra e, se de algo devia ser purificado, isso radicalmente o fez a sua paixão.

RESPOSTA À TERCEIRA. — O poder de ministrar os sacramentos pertence ao caráter espiritual, que é
indelével como do sobredito se colhe. E por isso o facto de ser um suspenso pela Igreja ou
excomungado, ou ainda degradado, não lhe tira o poder de conferir o sacramento, mas só a licença de
usar desse poder. Por isso, confere seguramente o sacramento, contudo peca conferindo-o. E o mesmo
passa com quem dele recebe o sacramento; e assim, não recebe a realidade deste, salvo se tiver a
escusa da ignorância.

## Art. 10 — Se a intenção reta do ministro é necessária para a perfeição do sacramento.
O décimo discute-se assim. — Parece necessária a intenção reta do ministro para a perfeição do
sacramento.

1. — Pois, a intenção do ministro deve ser conforme à da Igreja, como do sobredito se colhe. Ora, a
intenção da Igreja sempre é reta. Logo e necessàriamente para a perfeição do sacramento é necessária a
intenção reta do ministro.

2. Demais. — A intenção perversa parece pior que a jocosa. Ora a intenção jocosa excluí o sacramento;
talo caso de quem batizasse a outrem não seriamente mas por brincadeira. Logo, com maior razão, a
intenção perversa exclui o sacramento; por exemplo, se alguém batizasse a outrem para depois matá-lo.

3. Demais. — A intenção perversa torna toda uma obra viciosa, segundo aquilo do Evangelho: Se o teu
olho for mau todo o teu corpo será tenebroso. Ora, os sacramentos de Cristo não podem ser inquinados
pelos maus como diz Agostinho. Logo, parece que, sendo perversa a intenção do ministro, não há no
caso verdadeiro sacramento.
Mas, em contrário, a intenção perversa vem da malícia do ministro. Ora, a malícia do ministro não exclui
o sacramento. Logo, nem a intenção perversa.

SOLUÇÃO. — A intenção do ministro pode perverter-se de dois modos. – Primeiro relativamente ao
sacramento mesmo; por exemplo, quando não há intenção de conferir o sacramento, mas de fazer uma
brincadeira. E essa perversidade exclui a realidade do sacramento, sobretudo quando a intenção é
manifestada exteriormente. - De outro modo, pode perverter-se a intenção do ministro, relativamente
ao que a ele se segue; por exemplo, se o sacerdote tivesse a intenção de batizar uma mulher para
abusar dela; ou a de consagrar o corpo de Cristo a fim de usar dele para benefícios. E como o anterior
não depende do posterior, daí resulta que a perversidade de tal intenção não exclui a realidade do
sacramento. Mas o ministro, por ter tido tal intenção, peca gravemente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A intenção reta da Igreja concerne à perfeição e ao uso
do sacramento. Mas a primeira retidão perfaz o sacramento; a segunda produz efeito relativamente ao
mérito. Por onde, o ministro que conforma a sua intenção com a da Igreja quanto à primeira retidão,
mas não quanto à segunda, perfaz por certo o sacramento, mas não lhe traz isso nenhum mérito.

RESPOSTA À SEGUNDA. — A intenção lúdica ou jocosa exclui a primeira retidão da intenção pela qual se
perfaz o sacramento. Logo, não há semelhança de razão.

RESPOSTA À TERCEIRA. — A intenção perversa torna má o ato de quem a nutre, mas não o ato de
outrem. Por onde, a intenção perversa do ministro torna má a celebração do sacramento como obra
sua, mas não enquanto obra de Cristo, do qual é ministro. O mesmo se daria se o ministro de outrem
distribuísse com má intenção aos pobres a esmola que o senhor com boa intenção mandou distribuir.