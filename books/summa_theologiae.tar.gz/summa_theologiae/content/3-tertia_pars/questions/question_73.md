# Questão 73: Do sacramento da Eucaristia em si mesmo
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a Eucaristia é um sacramento.
O primeiro discute-se assim. — Parece que a Eucaristia não é um sacramento.

1. — Pois, dois sacramentos não devem ter o mesmo fim, porque cada um é eficaz para produzir o seu
efeito. Ora, ordenando-se à perfeição tanto a confirmação como a Eucaristia, no dizer de Dionísio, sendo
a confirmação um sacramento, como se estabeleceu, parece que não o é a Eucaristia.

2. Demais. — Em todos os sacramentos da lei nova, o que visivelmente está ao alcance dos sentidos
produz o efeito visível do sacramento. Assim, a ablução da água causa o caráter batismal e a ablução
espiritual, como se disse. Ora, as espécies do pão e do vinho, que neste sacramento, são perceptíveis
pelos sentidos, não produzem nem o verdadeiro corpo de Cristo, que é a realidade e o sacramento, nem
o corpo místico, que é somente a realidade na Eucaristia. Logo, parece que a Eucaristia não é um
sacramento da lei nova.

3. Demais. — Os sacramentos da lei nova, que têm matéria, consumam-se com o uso da matéria; assim
o batismo na ablução, é a confirmação na assinalação da crisma. Se, portanto, a Eucaristia fosse um
sacramento, consumar-se-ia com o uso da matéria e não com a consagração dela. O que é
evidentemente falso, pois, a forma deste sacramento são as palavras proferidas na consagração da
matéria, como a seguir se dirá. Logo, a Eucaristia não é um sacramento.
Mas, em contrário, uma coleta reza: Este teu sacramento não nos redunde em reato para a pena.

SOLUÇÃO. — Os sacramentos da Igreja têm por fim socorrer-nos na vida espiritual. Ora, a vida espiritual
se conforma com a corporal, porque com as causas corpóreas têm semelhanças as espirituais. Ora, é
manifesto que, assim como pela geração recebemos a vida do corpo e pelo crescimento chegamos à
plenitude dessa vida, assim também nos é necessário o alimento para conservarmos a vida. Por onde,
assim como para a vida espiritual há necessidade do batismo, que é a geração espiritual, e da
confirmação, que é o crescimento espiritual, assim também é necessária a Eucaristia, que é o alimento
espiritual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Há duas sortes de perfeição. - Uma intrínseca ao
homem, a que chega pelo crescimento. E essa é a própria da confirmação. - Outra é a que obtemos pela
adjunção do alimento, do vestuário ou por modo semelhante. E essa é a perfeição própria da Eucaristia,
que é o alimento espiritual.

RESPOSTA À SEGUNDA. — A água do batismo não é por nenhuma virtude própria sua que causa um
efeito espiritual, mas por virtude do Espírito Santo nela existente. Por isso Crisóstomo diz, comentando
aquilo do Evangelho - Um anjo do Senhor em certo tempo: Nos batizados a água não opera por si
mesma; mas, quando receber a graça do Espírito Santo, então perdoa todos os pecados. Ora, a virtude
do Espírito Santo está para a água do batismo, assim como o verdadeiro corpo de Cristo, para as
espécies do pão e do vinho. Por onde, as espécies do pão e do vinho nenhuma eficácia têm senão em
virtude do verdadeiro corpo de Cristo.

RESPOSTA À TERCEIRA. — O sacramento é assim chamado por conter algo de sagrado. Ora, uma causa
pode ser sagrada de dois modos, absoluta e relativamente. Ora, a diferença entre a Eucaristia e os
outros sacramentos, que têm matéria sensível, está em aquele conter o que é absolutamente sagrado, a
saber, o próprio Cristo; ao passo que o batismo tem um conteúdo sagrado relativo, a saber, a virtude de
santificar. E o mesmo se dá com a crisma e sacramentos semelhantes. Por onde, o sacramento da
Eucaristia se consuma na consagração mesma da matéria; ao passo que os outros sacramentos, na
aplicação da matéria à nossa santificação. - E daqui também resulta outra diferença, a saber. A realidade
e o sacramento, na Eucaristia, é a própria matéria dela, mas o que é somente a realidade, isto é, a graça
conferida, está em quem a recebe. Ao passo que no batismo uma e outra coisa está em quem o recebe;
a saber, o caráter, que é realidade e sacramento; e a graça da remissão dos pecados, que é somente a
realidade. E o mesmo se dá com os outros sacramentos.

## Art. 2 — Se a Eucaristia é um só ou vários sacramentos.
O segundo discute-se assim. — Parece que a Eucaristia não é um só, mas vários sacramentos.

1. — Pois, reza uma Coleta: Que os sacramentos nos purifiquem, Senhor, que recebemos; sendo isto
aplicado à recepção da Eucaristia. Logo, a Eucaristia não é um só, mas vários sacramentos.

2. Demais. — É impossível multiplicar-se o gênero, sem multiplicar-se a espécie; assim, que um só
homem sejam vários animais. Ora, o sinal é o gênero do sacramento, como se disse. Havendo, pois, na
Eucaristia vários sinais, a saber, o pão e o vinho, resulta por consequência que são vários sacramentos.

3. Demais. — Este sacramento se consuma com a consagração da matéria, como se disse. Ora, há nele
uma dupla consagração da matéria. Logo, são dois sacramentos.
Mas, em contrário, diz o Apóstolo: Nós todos somos um pão e um corpo, nós todos que participamos de
um mesmo pão e de um mesmo cálice. Por onde é claro que a Eucaristia é o sacramento da unidade
eclesiástica. Ora, um sacramento produz a semelhança da coisa de que é o sacramento. Logo, a
Eucaristia é um só sacramento.

SOLUÇÃO. — Como diz Aristóteles, atribuímos à unidade não só ao indivisível ou ao contínuo, mas
também ao perfeito; assim dizemos - uma casa e um homem. Ora, tem unidade de perfeição o ser para
cuja integridade concorre tudo o necessário ao seu fim. Assim, o homem se integra por todos os
membros necessários à operação da alma; e uma casa, por todas as partes necessárias a tornarem-na
habitável. E neste sentido atribuímos a unidade a este sacramento; pois, se ordena à nutrição espiritual,
semelhante à corporal. Ora, a nutrição corporal requere dois elementos: a comida, alimento seco, e a
bebida, alimento úmido. Do mesmo modo, para a integridade deste sacramento concorrem duas coisas:
a comida e a bebida espirituais, segundo aquilo do Evangelho - a minha carne verdadeiramente é
comida e o meu sangue verdadeiramente é bebida. Logo, apesar ser este sacramento múltiplo,
materialmente, é uno formal e' perfectivamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A mesma coleta reza, no plural. e em primeiro lugar:
Que nos purifiquem os sacramentos que recebemos. E depois acrescenta, no singular: Que este teu
sacramento não nos redunde em reato para a pena, para mostrar que, de certo modo múltiplo, é
contudo, absolutamente, uno.

RESPOSTA À SEGUNDA. — O pão e o vinho são por certo, materialmente considerados, sinais
diferentes; mas, formal e perfectivamente, são um só, pois, constituem uma só nutrição.

RESPOSTA À TERCEIRA. — Do fato de ser dupla a consagração da matéria deste sacramento. não
podemos concluir senão que ele tem multiplicidade material, como se disse.

## Art. 3 — Se este sacramento é de necessidade para a salvação.
O terceiro discute-se assim. — Parece que este sacramento é de necessidade para a salvação.

1. — Pois, diz o Senhor: Se não comerdes a carne do filho do homem e beberdes o seu sangue, não
tereis a vida em vós. Ora, neste sacramento comemos a carne de Cristo e bebemos o seu sangue. Logo,
sem ele não podemos ter a saúde da vida espiritual.

2. Demais. — Este sacramento é um alimento espiritual. Ora, o alimento corporal é necessário à saúde
do corpo. Logo, também este sacramento é necessário à vida espiritual.

3. Demais. — Assim como o batismo é o sacramento da paixão do Senhor, sem o qual não pode haver
salvação, assim também a Eucaristia. Por isso diz o Apóstolo: Todas as vezes que comerdes este pão e
beberdes este cálice, anunciareis a morte do Senhor até que ele venha. Logo, como o batismo é de
necessidade para a salvação, assim também a Eucaristia.
Mas, em contrário, escreve Agostinho à Bonifácio: Nem penseis que as crianças, que não receberam o
corpo e o sangue de Cristo, não possam ter a vida.

SOLUÇÃO. — Neste sacramento duas causas podemos considerar: o sacramento em si mesmo e a
realidade dele. Ora, como dissemos, a realidade deste sacramento é a unidade do corpo místico, sem a
qual não pode haver salvação. Pois, nenhum outro caminho há para a salvação fora da Igreja, assim
como nem no dilúvio, fora da Arca de Noé, símbolo da Igreja, conforme lemos na Escritura. Mas, como
dissemos. podemos ter a realidade de um sacramento, antes de a receber, pelo desejo mesmo de o
receber. Por onde, antes de receber a Eucaristia, podemos alcançar a salvação, pelo desejo de a receber;
assim como o batismo, pelo desejo dele, conforme foi dito. Mas há uma dupla diferença entre a
Eucaristia e o batismo. — Primeiro, porque o batismo é o princípio da vida espiritual e a porta dos
sacramentos. Ao passo que a Eucaristia é quase a consumação da vida espiritual e o fim de todos os
sacramentos, como dissemos; pois, pelas santificações de todos os sacramentos se faz a preparação
para receber ou consagrar a Eucaristia. Por onde, a recepção do batismo é necessária para entrarmos na
vida espiritual; enquanto que a recepção da Eucaristia o é, para consumá-la; não para possuí-la. em
absoluto, bastando que a tenhamos pelo desejo, assim como alcançamos o fim pelo desejo e pela
intenção. — A outra diferença está em o batismo nos preparar para a Eucaristia. Por onde, o fato
mesmo de serem as crianças batizadas as dispõe, pela Igreja, a receber a Eucaristia. E assim, do mesmo
modo que crêem pela fé da Igreja, também pela intenção da Igreja desejam a Eucaristia e, por
conseqüência, recebem-lhe a realidade. Mas ao batismo não se preparam por outro sacramento
precedente. Por isso, antes de receberem o batismo, as crianças de nenhum modo o receberam em
desejo, o que só o podem os adultos. Portanto, não podem receber a realidade do sacramento sem
receberem o sacramento. Logo, a Eucaristia não é de necessidade para a salvação do mesmo modo por
que o é o batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Expondo as palavras do Evangelho - Esta comida e esta
bebida, isto é, da carne e do sangue, diz Agostinho: Quer referir-se ao conjunto do corpo e dos seus
membros, que é a Igreja, nos seus santos e fiéis predestinados, eleitos, justificados e glorificados. E por
isso o mesmo Doutor diz: Ninguém deve de nenhum modo pôr em dúvida que os fiéis então se tornam
participantes do corpo e do sangue do Senhor quando se fazem pelo batismo membros do corpo de
Cristo e que não se lhes solve a união com esse pão e esse cálice mesmo se, antes de comerem desse
pão e beberem desse cálice, partirem desta vida constituídos na unidade do corpo de Cristo.

RESPOSTA À SEGUNDA. — Entre o alimento corporal e o espiritual há a diferença seguinte. O corporal
se converte na substância de quem dele te nutre; e portanto tal alimento não pode concorrer para a
conservação da nossa vida, se não o tomarmos realmente. Ao contrário, o alimento espiritual nos
converte nele, segundo as palavras de Agostinho, onde diz que ouviu a voz de Cristo falando: Nem tu me
mudarás em ti, como se fosse eu o alimento do teu corpo, mas tu é que te mudarás em mim. Podemos
porém nos mudar em Cristo e com ele nos incorporarmos pelo desejo do coração, mesmo sem termos
recebido a Eucaristia. Logo, a comparação não colhe.

RESPOSTA À TERCEIRA. — O batismo é o sacramento da morte e da paixão de Cristo, pois nos regenera
em Cristo, por virtude da sua paixão. Ao passo que a Eucaristia é o sacramento da paixão de Cristo,
enquanto nos faz unir perfeitamente com os sofrimentos que Cristo padeceu. Por onde, assim como o
batismo se chama sacramento da fé, fundamento da vida espiritual, assim a Eucaristia se chama
sacramento da caridade, que é o vinculo da perfeição, na frase do Apóstolo.

## Art. 4 — Se a este sacramento se dão acertadamente vários nomes.
O quarto discute-se assim. — Parece que não se dão acertadamente vários nomes a este sacramento.

1. — Pois, os nomes devem responder às causas. Ora, este sacramento é uno, como se disse. Logo, não
deve ser designado com vários nomes.

2. Demais. — A espécie não se dá convenientemente a conhecer pelo que é comum a todo o gênero.
Ora, a Eucaristia é um sacramento da lei nova. Mas, é comum a todos os sacramentos o ser, por eles,
conferida a graça; e tal é o significado da palavra eucaristia, o mesmo que boa graça. Também todos os
sacramentos nos servem de remédios no decurso da vida presente, o que é essencialmente o viático. E
ainda todos os sacramentos implicam algo de sagrado, o que constitui por essência o sacrifício. Enfim,
todos os sacramentos são meios por que os fiéis se comunicam; e isso significa o nome em grego, ou
communio (comunhão) em latim. Logo, estes nomes não se adaptam convenientemente a este
sacramento.

3. Hóstia significa o mesmo que o sacrifício. Logo, assim como não é propriamente chamado sacrifício,
assim também não é com propriedade denominado hóstia.
Mas, em contrário, o uso dos fiéis.

SOLUÇÃO. — Este sacramento tem tríplice significação. - Uma com respeito ao pretérito, enquanto
comemorativo da paixão do Senhor, que foi um verdadeiro sacrifício, como se disse. E, neste sentido, se
chama sacrifício. - Outra significação tem relativamente à realidade presente da upidade eclesiástica, à
qual os homens se agregam por este sacramento. E então se chama communio (comunhão). Pois, como
ensina Damasceno, chama-se communio porque por ela comunicamos com Cristo; e porque lhe
participamos da carne e da divindade; e porque nos comunicamos e unimos por ela uns com os outros. -
A terceira significação é relativa ao futuro, enquanto este sacramento é prefigurativo da função de
Deus, que haverá na. pátria. E, neste sentido, chama-se viático, pois, nesta vida nos indica o caminho
para lá chegar. E também, nesta acepção, se chama Eucaristia, isto é, boa graça, porque a graça de Deus
é a vida eterna, na expressão do Apóstolo; ou porque realmente contém Cristo, que é cheio de graça.
Em grego também se chama, isto é, assunção, porque, como diz Damasceno, por este meio assumimos a
deidade do Filho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede uma mesma coisa ter vários nomes,
conforme as suas diversas propriedades ou efeitos.

RESPOSTA À SEGUNDA. — O comum a todos os sacramentos atribui-se antonomasicamente a este, por
causa da sua excelência.

RESPOSTA À TERCEIRA. — Este sacramento se chama sacrifício, enquanto representa a paixão mesma
de Cristo; e se chama hóstia, enquanto contém o próprio Cristo que é a hóstia de suavidade, na
expressão do Apóstolo.

## Art. 5 — Se era conveniente a instituição deste sacramento.
O quinto discute-se assim. — Parece que não era conveniente a instituição deste sacramento.

1. — Pois, como diz o Filósofo, nós nos nutrimos da matéria idêntica à de que somos constituídos. Ora,
pelo batismo, que é uma regeneração espiritual, recebemos o ser espiritual. Logo, pelo batismo também
nos nutrimos. E portanto não era necessário instituir este sacramento como nutrição espiritual.

2. Demais. — Por este sacramento os homens se unem com Cristo como os membros com a cabeça.
Ora, Cristo é a cabeça de todos os homens, inclusive dos que existiram desde o princípio do mundo,
como se disse. Logo, a instituição deste sacramento não devia ser definidoaté a ceia do Senhor.

3. Demais. — Este sacramento se chama memorial da paixão do senhor, segundo aquilo do Evangelho:
Fazei isto em memória de mim. Ora, a memória é das coisas passadas. Logo, este sacramento não devia
ser instituído antes da paixão de Cristo.

4. Demais. — Pelo batismo estamos aptos a receber a Eucaristia, que não é dada senão aos batizados.
Ora, o batismo foi instituído depois da paixão e da ressurreição de cristo, como o refere o Evangelho.
Logo e inconvenientemente, este sacramento foi instituído antes da paixão de Cristo.
Mas, em contrário, este sacramento foi instituído por Cristo, de quem o Evangelho diz: Ele tudo tem
feito bem.

SOLUÇÃO. — Este sacramento foi convenientemente instituído na ceia, na qual Cristo pela última vez
esteve reunido com os discípulos. - Primeiro, em razão do conteúdo desse sacramento. - Pois, o próprio
Cristo está contido na Eucaristia como num sacramento. Por isso, quando Cristo teve de se separar
corporalmente dos discípulos, en.tregou-se-Ihes a si mesmo sob a espécie sacramental, assim como na
ausência do imperador se mostra a sua veneranda imagem. Por isso Eusébio (aut. inc.) diz: Porque o
corpo que assumira devia se separar dos olhos dos discípulos e subir ao céu, era necessário que no dia
ela ceia nos consagrasse o sacramento elo seu corpo e sangue, a fim ele que fosse adorado
perenemente no mistério quem uma vez se ofereceu como o preço ela nossa redenção. - segundo,
porque sem a fé da paixão de Cristo nunca poderia haver salvação, segundo aquilo do Apóstolo: Ao qual
propôs Deus para ser vítima ele propiciação pela fé no seu sangue. Por isso era necessário que em todos
os tempos houvesse entre os homens o que representasse a paixão do senhor. Do que, no Testamento
Velho, o sacramento precípuo era o Cordeiro Pascal; donde o dizer o Apóstolo: Cristo, que é a nossa
Páscoa, foi imolado. Mas lhe sucedeu, no Testamento Novo, o sacramento da Eucaristia, rememorativo
da paixão passada, assim como o Cordeiro Pascal era prefigurativo da futura. Por isso era conveniente
instituir o novo sacramento, na iminência da paixão, depois de celebrado o anterior, como diz Leão Papa
(I). - Terceiro. porque as palavras pronunciadas por último, sobretudo entre amigos que se separam, são
as que mais se gravam na memória, principalmente porque então são mais intensos os afetos para com
eles; ora, o para o que temos maior hábito mais profundamente se nos grava na alma. Mas, como diz S.
Alexandre Papa (I), como nenhum sacrifício pode ser maior que o do corpo e do sangue de Cristo, nem
nenhuma oblação lhe é superior, por isso, para que o tivéssemos em maior veneração, Cristo instituiu
este sacramento na última despedida dos seus discípulos. E tal é o que diz Agostinho: O Salvador,
desejando inculcar mais veementemente a profundeza deste mistério, quis que fosse a última coisa a
fíxar-se no coração e na memória dos discípulos, dos quais devia separar-se para sofrer a sua paixão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nós nos nutrimos da matéria idêntica à de que somos
constituídos, mas não a recebemos do mesmo modo. Assim, aquilo de que somos feitos o recebemos
pela geração; e isso mesmo, enquanto nos serve de nutrição, o recebemos pela manducação. Por onde,
assim como pelo batismo renascemos em Cristo, assim pela Eucaristia, comemos a Cristo.

RESPOSTA À SEGUNDA. — A Eucaristia é o sacramento perfeito da paixão do Senhor, pois contém o
próprio Cristo padecente. Por isso não podia ser instituído antes da Encarnação; mas então vigoravam
os sacramentos que apenas eram prefigurativos da paixão do Senhor.

RESPOSTA À TERCEIRA. — Este sacramento foi instituído na ceia, a fim de ser no futuro o memorial da
paixão do Senhor. depois de ela consumada. Por isso o Senhor diz sinaladamente:
Todas as vezes que o fizerdes, falando no futuro.

RESPOSTA À QUARTA. — A instituição responde à ordem da intenção. Ora, o sacramento da Eucaristia,
embora posterior ao batismo em perfeição, foi contudo anterior na intenção. Por isso tinha de ser
instituído primeiro. - Ou podemos dizer que o batismo já de certo modo estava instituído por ocasião do
batismo mesmo de Cristo. Por isso já certos foram batiza dos no batismo de Cristo, como lemos na
Escritura.

## Art. 6 — Se o cordeiro pascal foi a figura precípua deste sacramento.
O sexto discute-se assim. — Parece que o cordeiro pascal não foi a figura precípua deste sacramento.

1. — Pois, Cristo é chamado sacerdote segundo a ordem de Melquisedeque, porque Melquisedeque fez
a figura do sacrifício de Cristo, oferecendo o pão e o vinho, como lemos na Escritura. Ora, a expressão
da semelhança faz com que os semelhantes sejam designados um pelo outro. Logo, parece que a
oblação de Melquisedeque foi a figura precípua dêste sacramento.

2. Demais. — A passagem do Mar Vermelho foi a figura do batismo, segundo aquilo do Apóstolo: Todos
foram batizados na nuvem e no mar. Ora, a imolação do cordeiro pascal precedeu à passagem do Mar
Roxo, a que se seguiu o maná, como a Eucaristia é subsequente ao batismo. Logo, o maná é uma figura
mais expressiva deste sacramento, do que o cordeiro pascal.

3. Demais. — A principal virtude deste sacramento é introduzir-nos no reino dos céus, como um viático.
Ora, isso foi sobretudo o prefigurado no sacramento da expiação, quando o pontífice entrava uma vez
no ano com o sangue, no santo dos santos, como o explica o Apóstolo. Logo, parece que esse sacrifício
era uma figura mais expressiva da Eucaristia que o cordeiro pascal.
Mas, em contrário, o Apóstolo: Cristo, que é a nossa Páscoa, foi imolado e assim solenizemos o nosso
convite com os asmos da sinceridade e da verdade.

SOLUÇÃO. — Três coisas podemos considerar neste sacramento, a saber: o que é só sacramento — o
pão e o vinho; o que é realidade e sacramento — o verdadeiro corpo de Cristo; e o que é só realidade - o
efeito deste sacramento. Quanto, pois, ao que é só sacramento, a principalíssima figura dele foi a
oblação de Melquisedeque, que ofereceu o pão e o vinho. — Quando o Cristo padecente, que está
contido neste sacramento, figura dele foram todos os sacrifícios do Testamento Velho; e sobretudo o
sacramento da expiação, que era soleníssimo. — Quanto enfim ao efeito, a sua principal figura foi o
maná, que tinha em si a suavidade de todo o saber no dizer da Escritura, assim como a graça deste
sacramento nos fortalece a alma para tudo. Mas o cordeiro pascal prefigurava a Eucaristia nos seus três
elementos referidos. — Quanto ao primeiro, porque era comido com os pães asmos, segundo a
Escritura: Comerão a carne e pães asmos. - Quanto ao segundo, porque era imolado por toda a multidão
dos filhos de Israel na décima quarta lua; o que era a figura da paixão de Cristo, chamado cordeiro, por
causa da sua inocência. — Quanto enfim ao efeito, porque pelo sangue do cordeiro pascal os filhos de
Israel foram protegidos contra o anjo devastador, e tirados da escravidão do Egito.
E por isso é considerado como a figura precípua deste sacramento o cordeiro pascal, pela representar
em tudo. Donde se deduzem claras as respostas às objeções.