# Questão 80: Do uso ou da recepção deste sacramento em geral
Em seguida devemos tratar do uso ou da recepção deste sacramento. E primeiro em geral. Segundo, do
modo pelo qual Cristo está neste sacramento.
Na primeira questão discutem-se doze artigos:

## Art. 1 — Se se devem distinguir dois modos de receber o corpo de Cristo — o sacramental e o espiritual.
O primeiro discute-se assim. — Parece que se não devem distinguir dois modos de receber o corpo de
Cristo — o sacramental e o espiritual.

1. — Pois, o batismo é uma regeneração espiritual, segundo àquilo do Evangelho: Quem não renascer da
água e do Espírito Santo, etc. Assim também este sacramento é uma comida espiritual, e por isso o
Senhor, falando dele, disse: As palavras que eu vos disse são espírito e vida. Ora, no batismo não se
distingue um duplo modo de o receber — o sacramental e o espiritual. Logo, também não os devemos
distinguir no tocante a este sacramento.

2. Demais. — Duas coisas, das quais uma é para a outra, não se devem uma da outra dividir; pois
pertencem ambas a mesma espécie. Ora, a comunhão sacramental se ordena à espiritual como ao fim.
Logo, não se deve dividir a comunhão sacramental, da espiritual, por contrariedade.

3. Demais. — Duas coisas, das quais uma não pode existir sem a outra, não devem dividir-se uma da
outra, por contrariedade. Ora, parece que ninguém pode receber este sacramento espiritualmente,
senão o receber também sacramentalmente. Do contrário, os antigos Patriarcas o teriam recebido de
modo espiritual. E também seria vã a comunhão sacramental, se pudesse ser sem ela a espiritual. Logo,
não se distingue convenientemente uma dupla comunhão — a sacramental e a espiritual.
Mas, em contrário, àquilo do Apóstolo — Quem come e bebe indignamente, etc., diz a Glosa:
Distinguimos dois modos de comunhão: o sacramental e o espiritual.

SOLUÇÃO. — Na recepção deste sacramento duas coisas devemos distinguir: o sacramento em si
mesmo e o seu efeito, de ambas as quais já tratamos. Por onde, o modo perfeito de receber este
sacramento é recebermos de maneira a lhe colhermos o efeito. Pode se dar porém, como dissemos, que
estejamos impedidos de colher o efeito deste sacramento; e esse modo de o receber é imperfeito. Ora,
assim como o perfeito se opõe ao imperfeito, assim a comunhão sacramental, na qual recebemos
apenas o sacramento, sem o seu efeito, se opõe à comunhão espiritual, na qual recebemos o efeito
deste sacramento, por onde nos unimos espiritualmente com Cristo pela fé e pela caridade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No tocante ao batismo e os outros sacramentos
semelhantes, tem lugar a mesma distinção. Assim, certos recebem só o sacramento; outros, o
sacramento e a realidade do sacramento. Mas nisto diferem, pelo seguinte. Como os outros
sacramentos se consumam pelo uso da matéria, receber o sacramento é a perfeição mesma dele. Ao
passo que este sacramento se consuma pela consagração da matéria e por isso um e outro uso resulta
do sacramento. Também no batismo e nos outros sacramentos que imprimem caráter, os que recebem
o sacramento recebem o efeito especial, que é o caráter; o que não se dá neste. Por isso antes neste
sacramento se distingue, que no batismo, o uso sacramental, do espiritual.

RESPOSTA À SEGUNDA. — A comunhão sacramental, que chega a ser espiritual, não se divide, por
oposição, da comunhão espiritual, mas está inclui da nesta. A manducação sacramental, porém se
divide, por oposição, da espiritual que não produz o seu efeito; assim, o imperfeito, por não atingir a
perfeição da espécie, se divide do perfeito, por oposição.

RESPOSTA À TERCEIRA. — Como dissemos, o efeito do sacramento pode ser gozado por quem deseja
receber o sacramento, embora realmente não o receba. Por isso, assim como certos são batizados pelo
batismo de desejo, pelo desejar, antes de serem batizados na água, assim também certos recebem
espiritualmente este sacramento, antes de o receberem sacramentalmente. Mas isto de dois modos
pode dar-se. Ou pelo desejo de receber realmente o sacramento; e então dizemos que são batizados e
comem espiritualmente, e não sacramentalmente, os que desejam receber esses sacramentos já
instituídos. Ou, de modo figurado; assim, diz o Apóstolo, que os antigos Patriarcas foram batizados na
nuvem e no mar; e que comeram de um mesmo manjar espiritual e beberam de uma mesma bebida
espiritual. Mas nem por isso é inútil a comunhão sacramental, porque induz um efeito mais pleno do
sacramento o recebê-lo realmente do que só em desejo, como dissemos ao tratar, acima, do batismo.

## Art. 2 — Se só os homens ou se também os anjos podem receber este sacramento espiritualmente.
O segundo discute-se assim. — Parece que não só os homens, mas também os anjos, podem receber
este sacramento espiritualmente.

1. — Pois, àquilo da Escritura — Pão dos anjos come o homem — diz a Glosa: I, é, o corpo de Cristo, que
é verdadeiramente comida dos anjos. Ora, tal não seria se os anjos não pudessem receber
espiritualmente a Cristo. Logo, os anjos podem receber espiritualmente a Cristo.

2. Demais. — Agostinho diz: Por esta comida e esta bebida se entende a sociedade do corpo e dos seus
membros, que é a Igreja nos seus predestinados. Ora, a esta sociedade não pertencem só os homens,
mas também os santos anjos. Logo, os santos anjos podem receber espiritualmente a Cristo.

3. Demais. — Agostinho diz: Devemos receber espiritualmente a Cristo, pois ele próprio disse — Quem
come a minha carne e bebe o meu sangue permanece em mim e eu nele. Ora, isto podem não só os
homens, mas também os santos anjos, nos quais Cristo habita pela caridade, e eles em Cristo. Logo,
parece que receber a Cristo espiritualmente o podem não só os homens, mas também os anjos.
Mas, em contrário, diz Agostinho: Comei espiritualmente o pão do altar, achegai-vos ao altar revestidos
de inocência. Ora, os anjos não podem aproximar-se do altar como se devessem de receber dele alguma
coisa. Logo, os anjos não podem receber espiritualmente a Cristo.

SOLUÇÃO. — Neste sacramento está contido Cristo, não em espécie própria, mas em espécie
sacramental. Ora, de dois modos é possível receber a Cristo espiritualmente. — Primeiro, recebendo-o
tal como ele em espécie é. E deste modo os anjos o recebem espiritualmente, enquanto estão com ele
unidos pela função da caridade perfeita e pela visão clara, que nós esperamos na pátria; e não pela fé,
como é a nossa união com Cristo. — De outro modo, pode-se receber espiritualmente a Cristo, como ele
está sob as espécies deste sacramento; isto é, acreditando nele, com o desejo de o receber neste
sacramento. E isto não só é receber a Cristo espiritualmente, mas ainda receber espiritualmente este
sacramento. O que não podem os anjos. Por onde, embora os anjos recebam espiritualmente a Cristo,
não podem contudo receber este sacramento espiritualmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O receber a Cristo neste sacramento se ordena como ao
fim, ao gozo da pátria, do modo pelo qual os anjos o gozam. E como os meios derivam do fim, o
recebermos a Cristo, como o recebemos neste sacramento, de certa maneira deriva do modo de o
receber pelo qual os anjos dele gozam na pátria. Por isso dizemos que o homem come o pão dos anjos,
porque primária e principalmente é dos anjos, que o gozam no céu; secundàriamente porém é dos
homens, que recebem a Cristo neste sacramento.

RESPOSTA À SEGUNDA. — A sociedade do corpo místico pertence certamente os homens pela fé; mas
os anjos, pela visão manifesta. Os sacramentos porém são, proporcionados à fé, pela qual a verdade é
contemplada como por um espelho, em enigmas. Por onde, propriamente falando, não aos anjos, mas
aos homens convém receber espiritualmente este sacramento.

RESPOSTA À TERCEIRA. — Cristo permaneceu em nós, na condição da nossa vida presente, pela fé; mas,
nos santos anjos, pela visão clara. Logo, o símile não colhe, como dissemos.

## Art. 3 — Se ninguém, a não ser o justo, pode receber sacramentalmente a Cristo.
O terceiro discute-se assim. — Parece que ninguém a não ser o justo, pode receber sacramentalmente
a Cristo.

1. — Pois, diz Agostinho: Para que preparas dentes e ventre? Crê e já comeste. Pois, crer nele é comer o
pão da vida. Ora, o pecador não crê em Deus por não ter fé formada, que nos faz crer em Deus, como
estabelecemos na Segunda Parte. Logo, o pecador não pode receber este sacramento, que é o pão dos
vivos.

2. Demais. — Este sacramento é chamado o sacramento da caridade, por excelência. Ora, assim como
os infiéis estão privados da fé, assim todos os pecadores o estão da caridade. Ora, os infiéis não podem
receber sacramentalmente este sacramento; pois, a sua fórmula reza — mistério da fé. Logo, pela
mesma razão, também nenhum pecador pode receber sacramentalmente o corpo de Cristo.

3. Demais. — O pecador é mais abominável a Deus que uma criatura irracional. Assim, diz a Escritura, do
homem pecador: O homem que vive na opulência e não reflete, assemelha-se aos animais que perecem.
Ora, o animal bruto, por exemplo, um rato ou um cão, não pode receber este sacramento; como
também não pode receber o sacramento do batismo. Logo, parece que, pela mesma razão, os
pecadores não podem receber este sacramento.
Mas, em contrário, àquilo do Evangelho — Os vossos pais comeram o maná no deserto e morreram, diz
Agostinho: Muitos que recebem do altar recebem a morte: donde dizer o apóstolo, que comem e
bebem o próprio juízo. Ora, por terem recebido o corpo de Cristo, não morrem senão os pecadores.
Logo também os pecadores, e não só os justos, podem receber sacramentalmente o corpo de Cristo.

SOLUÇÃO. — Nesta matéria certo antigo erram, dizendo que o Corpo de Cristo não o podem
sacramentalmente receber os pecadores; mas, logo que lhes toca os lábios, imediatamente deixa o
corpo de Cristo de estar sob as espécies sacramentais. — Mas isto é errôneo. Pois, encontra a verdade
deste sacramento, no qual, como dissemos, o corpo de Cristo não deixa de estar enquanto permanecem
as espécies. Ora, as espécies permanecem, enquanto permaneceria a espécie do pão, se aí estivesse,
como dissemos. Mas, é manifesto que a substância do pão, recebida pelo pecador, não deixa por isso
imediatamente de existir, mas permanece, até ser digerida pelo calor natural. Por onde, durante esse
mesmo tempo o corpo de Cristo existe sob as espécies sacramentais recebidas pelos pecadores. Donde
devemos concluir, que o pecador pode receber sacramentalmente o corpo de Cristo, e não só o justo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras citadas e outras semelhantes devem
entender-se da recepção espiritual do sacramento, que não cabe aos pecadores. Por onde, foi de uma
errada interpretação dessas palavras, que nasceu o erro referido, por não saberem distinguir entre a
manducação corporal e a espiritual.

RESPOSTA À SEGUNDA. — Mesmo que um infiel receba as espécies sacramentais, recebe o corpo de
Cristo sob o sacramento. E portanto, recebe a Cristo sacramentalmente, se o advérbio —
sacramentalmente — determina o verbo por parte do sacramento recebido. Se o for porém da parte de
quem o recebe, então este, propriamente falando, não o recebe sacramentalmente, por não usar do
que recebe como sacramento, mas como simples comida. Salvo se o infiel tiver a intenção de receber o
que a Igreja confere, embora não professe a verdadeira fé relativamente aos outros artigos do mesmo
sobre este sacramento.

RESPOSTA À TERCEIRA. — Mesmo que um rato ou um cão coma a hóstia consagrada a substância do
corpo de Cristo não deixa de estar sob as espécies, enquanto essas espécies permanecerem, isto é,
enquanto permanecer a espécie do pão. Assim também, se fosse atirada no lodo. Nem isso redunda em
detrimento da dignidade do corpo de Cristo, que, quis ser crucificado pelos pecadores, sem diminuição
da sua dignidade. Sobretudo que o rato nem o cão tocam o corpo de Cristo na sua espécie própria, mas
só nas espécies sacramentais. — Certos porém (Guilmundo, Abelardo, Pedro Lombardo) disseram que
logo que o sacramento é tocado pelo rato ou pelo cão, deixa nele estar o corpo de Cristo. O que
encontra a verdade do sacramento como dissemos. — Nem contudo, devemos dizer que o animal bruto
coma sacramentalmente o corpo de Cristo, por não ser de natureza a poder usar deste sacramento. Por
onde, come o corpo de Cristo, não sacramental, mas acidentalmente; assim como o comeria quem
recebesse a hóstia consagrada, sem saber que estava consagrada. E como o acidental não entra na
divisão de nenhum gênero, por isso, este modo de comer o corpo de Cristo não é considerado como um
terceiro, além do sacramental e do espiritual.

## Art. 4 — Se o pecador, recebendo o corpo de Cristo, sacramentalmente, peca.
O quarto discute-se assim. — Parece que o pecador, recebendo sacramentalmente o corpo de Cristo,
não peca.
1 — Pois, não tem maior dignidade Cristo, sob a espécie sacramental, que sob a espécie própria. Ora, os
pecadores, que tocavam o corpo de Cristo na sua espécie própria, não pecavam; antes, alcançavam o
perdão dos pecados. Talo relato evangélico, da mulher pecadora; e noutro lugar diz o Evangelista: Todos
os que lhe tocavam a orla do vestido ficavam sãos. Logo, longe de pecar, alcançam a salvação,
recebendo o sacramento do corpo de Cristo.

2. Demais. — Este sacramento, como os outros, é um remédio espiritual. Ora, remédio se dá ao doente,
para recuperar a saúde, segundo aquilo do Evangelho: Os sãos não têm necessidade de médico, mas sim
os enfermos. Ora, os enfermos ou doentes são espiritualmente pecadores. Logo, este sacramento eles o
podem receber, sem culpa.

3. Demais. — Este sacramento, contendo Cristo, em si mesmo, é dos máximos bens. Ora, dos bens
máximos ninguém como diz Agostinho, pode usar mal. Pois, ninguém peca senão pelo abuso de um
bem. Logo, nenhum pecador, que receba este sacramento, peca.

4. Demais. — Assim como este sacramento é percebido pelo gosto e pelo tato, assim também pela vista.
Se portanto o pecador peca recebendo este sacramento, parece que também pecará, vendo-o. O que é
evidentemente falso, pois, a Igreja propõe este sacramento a ser visto e adorado. Logo, o pecador não
peca, recebendo este sacramento.

5. Demais. — Pode dar-se às vezes que um pecador não tenha consciência do seu pecado. E esse não
pecaria recebendo o corpo de Cristo; porque, do contrário, todos pecariam, que o recebem, por se
exporém ao perigo de pecar, conforme àquilo do apóstolo: De nada me argúi a consciência, mas nem
por isso me dou por justificado. Logo, não incorre em culpa, segundo parece, o pecador que receber
este sacramento.
Mas, em contrário, diz O Apóstolo: Todo aquele que o come e bebe indignamente, come e bebe para si
a condenação. E a Glosa a esse lugar: Come e bebe indignamente quem está em estado de pecado ou o
trata com irreverência. Logo, quem está em pecado mortal, recebendo este sacramento, busca a sua
própria condenação, pecando mortalmente.

SOLUÇÃO. — Neste sacramento, como nos outros, o sacramento é o sinal da sua realidade. Ora, a
realidade deste sacramento é dupla, como dissemos: uma a significa da e contida, a saber, o próprio
Cristo; outra, a significada, mas não contida, a saber, o corpo místico de Cristo, que é a sociedade dos
santos. Por onde, quem quer que receba este sacramento, por isso mesmo se confessa unido com Cristo
e incorporado aos seus membros. O que se dá pela fé formada, que ninguém pode ter em estado de
pecado mortal. Por onde, é manifesto que quem quer que receba este sacramento, em estado de
pecado mortal, comete contra ele uma falsidade. E por isso incorre em sacrilégio, como violador do
sacramento. Portanto, peca mortalmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo, manifestando-se na sua figura própria, não se
oferecia a ser tocado pelos homens como sinal de união espiritual com ele, como se oferece a ser
recebido neste sacramento. Por isso, os pecadores, tocando-lhe o corpo, não incorriam no pecado de
falsidade contra Deus, como incorrem os que recebem este sacramento em estado de pecado mortal. —
Além disso. Cristo ainda tinha, neste mundo, a semelhança da carne de pecado; por isso podia permitir
aos pecadores, que o tocassem. Mas, desaparecida a semelhança da carne de pecado pela glória da
ressurreição, proibiu que a mulher o tocasse, a qual não tinha nele uma fé completa, segundo àquilo do
Evangelho: Não me toques porque ainda não subi a meu pai, isto é, no teu coração, como expõe
Agostinho. Por isso, os pecadores, que não tem nele uma fé formada, são repelidos do contato com este
sacramento.

RESPOSTA À SEGUNDA. — Não é qualquer remédio que convém a qualquer doente. Assim, o remédio
para fortificar os que já não têm febre, faria mal dos febricitantes. Assim também o batismo e a
penitência são remédios purificativos, para tirar a febre do pecado. Ao passo que este sacramento é um
remédio fortificante, que não deve ter dados senão aos que se livraram do pecado.

RESPOSTA À TERCEIRA. — Por bens máximos Agostinho entende as virtudes da alma, de que ninguém
pode usar mal, como a modo de princípios do mal. Podemos, porém usar mal delas, usando-as como de
objetos para o mal, como no caso de quem se ensoberbece da sua virtude. Assim também este
sacramento não é, em si mesmo, princípio de mau uso, mas objeto dele. Donde o dizer Agostinho:
Muitos recebem indignamente o corpo de Cristo, o que nos adverte do quanto nos devemos acautelar
de receber mal um bem. Assim, procedemos mal; ao contrário, o Apóstolo fez bem recebendo bem o
mal, isto é, quando suportou pacientemente o estímulo ele Satan.

RESPOSTA À QUARTA. — Pela vista não recebemos o corpo de Cristo, mas só o seu sacramento; porque
a vista não alcança a substância do corpo de Cristo, mas só as espécies sacramentais, como se disse.
Mas quem comunga, não só toma as espécies sacramentais, mas também o corpo mesmo de Cristo, que
está sob elas. Por onde, da visão do corpo de Cristo ninguém fica impedido, que já tenha recebido o
batismo, sacramento de Cristo. Mas os não-batizados não podem ser admitidos nem mesmo à
contemplação deste sacramento, como está claro em Dionísio. À comunhão porém só podem ser
admitidos os unidos com Cristo, só sacramentalmente, mas também realmente.

RESPOSTA À QUINTA. — De dois modos pode dar-se que não tenha uma consciência do seu pecado.
Primeiro culpa própria. Quer por ignorância do direito, que não excusa, reputando não ser pecado o que
o é — por exemplo, quem considerasse o seu pecado de simples fornicação como não sendo mortal.
Quer por ser negligente ao examinar-se, contrariando àquilo do Apóstolo — Examine-se, pois a si
mesmo o homem e assim, coma deste pão e beba deste cálice; e então, peca o pecador que receber o
corpo de Cristo, embora não tenha consciência do seu pecado, porque já a sua mesma ignorância é
pecaminosa. — De outro modo pode dar-se, sem culpa própria — por exemplo, quando se arrependem
do pecado, mas sem contrição suficiente. E em tal caso não peca, recebendo o corpo de Cristo; porque
não podemos saber com certeza se tivemos verdadeiramente contrição. Basta porém sentir em si sinais
de contrição; por exemplo, se tiver dor dos pecados passados e propuser acautelar-se no futuro. — Se
porém ignorar que seja pecado o ato que praticou, por ser a ignorância de fato, que excusa, não deve
ser por isso, considerado pecador; tal o caso de quem tivesse relações com uma mulher que julga a sua,
sem que o fosse. — O mesmo se dará se lhe esqueceu totalmente o pecado; bastando então, para ser
delido, uma contrição geral, como a seguir se dirá. E portanto, não deve ser considerado pecador.

## Art. 5 — Se achegar-se a este sacramento com a consciência do pecado é o gravíssimo de todos os pecados.
O quinto discute-se assim. — Parece que o achegar-se a este sacramento com a consciência do pecado
é o gravíssimo de todos os pecados.
1 — Pois, diz o Apóstolo: Todo aquele que comer este pão ou beber o cálice do Senhor indignamente,
será réu do corpo e do sangue do Senhor. O que comenta a Glosa: Será punido como se matasse a
Cristo. Ora, o pecado dos que mataram a Cristo foi o gravíssimo. Logo, o pecado de quem se achega à
mesa de Cristo com consciência do pecado, parece ser o gravíssimo.

2. Demais. — Jerônimo diz: Por que te metes com mulheres tu que no altar conversas com Deus? Dize, ó
sacerdote, dize, ó clerigo, como, com esses mesmos lábios osculas o Filho de Deus, com que osculaste
os lábios da meretriz? Com Judas, entregas o Filho do homem com um beijo? Donde se conclui, que
quem fornicou e depois se achega à mesa de Cristo, peca como pecou Judas, cujo pecado foi gravíssimo.
Ora, muitos outros pecados são mais graves que o da fornicação, e sobretudo o da infidelidade. Logo, o
pecado de qualquer pecador, que se achegar à mesa de Cristo, é o gravíssimo.
3 Demais. — Mais abominável perante Deus é a imundície espiritual que a corporal. Ora, quem atirasse
com o corpo de Cristo no lodo ou no esterquilínio, gravíssimo se lhe havia de reputar o pecado. Logo,
peca mais gravemente recebendo a Cristo em estado de pecado, o que é a imundícia espiritual. Logo,
este é o gravíssimo dos pecados.
Mas, em contrário, àquilo de João — Se eu não viera e não lhe tivera falado, não teriam eles pecado, diz
Agostinho que esse lugar deve entender-se do pecado de infidelidade, que abrange todos os pecados.
Donde, parece, não ser este pecado o gravíssimo mas antes, o de infidelidade.

SOLUÇÃO. — Como dissemos na Segunda Parte, em dois sentidos podemos dizer que um pecado é mais
grave que outro: essencial e acidentalmente. Essencialmente, pela sua natureza específica, que se funda
no objeto. E então, quanto mais elevado é o objeto contra o qual se peca, tanto mais grave é o pecado.
E como a divindade de Cristo é mais elevada que a sua humanidade; e essa mesma humanidade, mais
que os sacramentos da humanidade, daí resulta que os gravíssimos dos pecados são os cometidos
diretamente contra a divindade, como o pecado de infidelidade e o de blasfêmia. Secundàriamente,
porém são mais graves os pecados cometidos contra a humanidade de Cristo. Donde o dizer o
Evangelho: Todo o que disser alguma; palavra contra o Filho do homem, perdoar-se-lhe-á; porém o que
a disser contra o Espírito Santo, não se lhe perdoara nem neste mundo nem no outro. Em terceiro lugar
vem os pecados cometidos contra os sacramentos, que concernem à humanidade de Cristo. E depois
desses, os que são contra as puras criaturas. Acidentalmente porém, pela parte do pecador, pode um
pecado ser mais grave que outro. Por exemplo, o pecado por ignorância ou fraqueza é mais leve que o
pecado por desprezo ou ciência certa; e o mesmo se dá com as mais circunstâncias. E a esta luz, o
pecado, no caso vertente, pode ser mais grave em certos, como nos que recebem este sacramento, for
desprezo atual, com a consciência do pecado. Em outros pode ser menos grave, por exemplo, nos que
se aproximam deste sacramento levados com a consciência pecaminosa, do temor de serem
apreendidos no pecado. Por onde é claro que este pecado é, especificamente, mais grave que muitos
outros, mas não é o gravíssimo de todos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pecado dos que recebem este sacramento
indignamente é comparável ao pecado dos que mataram a Cristo, por uma certa semelhança, pois
ambos foram cometidos contra o corpo de Cristo; mas não, pela gravidade do crime. Porque o pecado
dos que mataram a Cristo foi muito mais grave. Primeiro, por ter sido esse pecado contra o corpo de
Cristo na sua espécie própria, ao passo que este pecado é contra o corpo de Cristo na espécie do
sacramento. Segundo, porque aquele procedeu da intenção de fazer mal a Cristo, e este, não.

RESPOSTA À SEGUNDA. — O impuro, recebendo o corpo de Cristo, é comparado a Judas, que beijou a
Cristo — quanto à semelhança do crime, pois ambos, dando mostras de caridade, ofenderam a Cristo;
mas não quanto à gravidade do crime, segundo dissemos. Mas, essa semelhança de crimes tem lugar
tanto em relação aos outros pecadores como as que cometeram o pecado de impureza. Pois, também
os outros pecados mortais vão contra a caridade de Cristo, cujo sinal é este sacramento; e tanto mais
quanto mais graves forem os pecados. Acidentalmente porém, o pecado de fornicação, torna o homem
menos capaz de receber neste sacramento, por que esse pecado é o que mais sujeita o espírito à carne,
impedindo assim o fervor da caridade. Que este sacramento requer. Pois, o impedimento mesmo da
Caridade prepondera sobre o seu fervor, Por isso também o pecado de infidelidade, que separa
totalmente o homem da unidade da Igreja, absolutamente falando, é o que sobretudo o torna incapaz
de receber este sacramento, que é o sacramento da unidade eclesiástica, como se disse. Por onde, mais
gravemente peca o infiel recebendo este sacramento, que o fiel pecador; e mais despreza a Cristo,
existente sob este sacramento, principalmente se não acreditar que Cristo nele verdadeiramente está.
Pois, diminui o quanto pode a santidade da Eucaristia e a virtude de Cristo que nela obra — o que é
desprezar o sacramento em si mesmo. Quanto ao fiel que o recebe com consciência do pecado, esse o
despreza, não em si mesmo, mas no seu uso, tomando-o indignamente. Por isso o Apóstolo, assinalando
a razão desse pecado, diz: Não discernindo o corpo do Senhor; isto é, não discernindo essa comida, de
outra, como o explica a Glosa. O que sobretudo, faz quem não crê que Cristo está sob esse sacramento.

RESPOSTA À TERCEIRA. — Quem atirasse esse sacramento ao lodo pecaria muito mais gravemente que
quem o recebesse com consciêncía do pecado mortal. — Primeiro, pelo fazer com a intenção de injuriá-
lo; intenção que não tem o pecador que recebe indignamente o corpo de Cristo. — Segundo, por ser o
pecador capaz da graça; e por isso também mais capaz de receber este sacramento, que qualquer
criatura irracional. Por onde, muitíssimo mais desordenadamente usaria deste sacramento quem o
atirasse a comer aos cães ou quem o atirasse a ser calcado no lodo.

## Art. 6 — Se o sacerdote deve negar o corpo de Cristo ao pecador que o pede.
O sexto discute-se assim. — Parece que o sacerdote deve negar o corpo de Cristo ao pecador que o
pede.

1. — Pois, não devemos agir contra um preceito de Cristo, para evitar escândalo, nem por livrar alguém
da infâmia. Ora, o Senhor ordena: Não deis aos cães o que é santo. Mas, por excelência se dá aos cães o
que é santo, quando se dá este sacramento ao pecador. Logo, nem por evitar escândalo, nem por livrar
a outrem da infâmia, se deve dar este sacramento ao pecador que o pede.

2. Demais. — De dois males devemos escolher o menor. Ora, parece menor mal um pecador ser
infamado, ou mesmo dar-lhe uma hóstia não consagrada, do que pecar ele mortalmente, recebendo o
corpo de Cristo. Logo, parece antes preferível O pecador, que pede o corpo de Cristo, ser infamado, ou
mesmo dar-lhe uma hóstia não-consagrada.

3. Demais. — O corpo de Cristo às vezes é dado aos suspeitos de crime, para a manifestação deles.
Assim, uma Decretal dispõe: Muitas vezes se dão furtos nos mosteiros de monges. Por isso,
determinamos que, quando os frades deverem purificar-se de tais atos, seja celebrada missa pelo abade
ou por um dos frades presentes. E assim, terminada a missa, todos comunguem dizendo estas palavras:
O corpo de Cristo sirva hoje de prova em meu favor. E mais abaixo: O bispo ou o presbítero a quem for
imputado um malefício, celebre missa e comungue, tantas vezes quantas forem as imputações, e mostre
que é inocente de cada uma delas. Ora, não se devem manifestar os pecadores ocultos; porque se a
vergonha não mais lhes ruborizar a fronte, pecarão mais desabridamente, como diz Agostinho. Logo,
aos pecadores ocultos não se lhes deve dar o corpo de Cristo, mesmo se pedirem.
Mas, em contrário, àquilo da Escritura: Comeram e adoraram todos os poderosos da terra — diz
Agostinho: Que o dispensador dos sacramentos não proíba os poderosos da terra, isto é, os pecadores
— de comerem à mesa do Senhor.

SOLUÇÃO. — Sobre os pecadores devemos distinguir. Uns são ocultos. Outros manifestos, pela
evidência dos seus atos, como os usurários ou os roubadores públicos; ou ainda por algum juízo
eclesiástico ou secular. Por onde, aos pecadores manifestos não deve ser dada a sagrada comunhão,
mesmo que a peçam. Por isso Cipriano, numa de suas epístolas, escreve: A amizade que me devotas
levou-te a consultar-me qual a minha opinião sobre os histriões e o mago que, instalado no reino do teu
povo, ainda persevera nas suas artes indecorosas: a esses tais se lhes deve dar a sagrada comunhão
junto com os demais cristãos? Ora, eu penso, que nem a majestade divina nem a disciplina evangélica
permitem que o decoro e a honra da Igreja seja contaminada com tão torpe e infame contágio. Se
porém não forem manifestos os pecadores, mas ocultos, e pedirem a sagrada comunhão, não se lhes
pode negar. Pois, como qualquer cristão, pelo simples fato de ser batizado, é admitido à mesa do
Senhor, não se lhes pode tirar o seu direito, senão por alguma causa manifesta. Por isso, àquilo do
Apóstolo — Se aquele que se nomeia vosso irmão, etc., diz a Glosa de Agostinho: Não podemos proibir
ninguém de receber a comunhão, a menos que não tenha confessado espontaneamente o seu crime, ou
fosse citado e condenado em juízo secular ou eclesiástico: Pode porém o sacerdote, cônscio do crime,
advertir ocultamente o pecador oculto; ou também em público, a todos em geral, que não se acheguem
à mesa do Senhor antes de fazerem penitência e se reconciliarem com a Igreja. Pois, após a penitência e
a reconciliação, não se deve negar a comunhão mesmo aos pecadores públicos, sobretudo em artigo de
morte. Por isso, no concílio Cartaginês se lê: Aos comediantes, aos histriões e a outras pessoas tais, ou
aos apóstatas, convertidos a Deus não se lhes negue a reconciliação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Evangelho proíbe dar o que é santo aos cães, isto é,
aos pecadores manifestos. Pois, os pecados ocultos não podem ser punidos publicamente, ficando
reservados ao juízo divino.

RESPOSTA À SEGUNDA. — Embora seja pior ao pecador oculto pecar mortalmente, recebendo o corpo
de Cristo, do que ficar infamado, contudo, ao sacerdote, que ministra o corpo de Cristo, é pior pecar
mortalmente, infamando injustamente um pecador oculto, do que pecar este mortalmente. Porque
ninguém deve cometer pecado mortal para livrar a outrem do pecado. Por isso diz Agostinho: É muito
perigoso admitir-se esta compensação — fazermos nós um mal para não o fazer outrem, mais grave.
Quanto ao pecador oculto, porém deveria preferir, antes, infamar-se que se aproximar indignamente da
mesa do Senhor. — Uma hóstia não-consagrada, contudo, de nenhum modo lhe deve ser dada, em vez
da consagrada. Porque o sacerdote, assim procedendo, concorreria para o pecado de idolatria dos que
cressem ser a hóstia consagrada — quer fossem os presentes, quer o próprio que a recebesse; pois,
como diz Agostinho, ninguém deve comer a carne de Cristo, sem primeiro adorá-la. Por isso, uma
disposição canônica determina: Embora quem, tendo consciência do seu crime e reputando-se indigno,
peque gravemente, recebendo a Cristo, contudo, mais gravemente ofende a Deus quem ousar simulá-lo
fraudulentamente.

RESPOSTA À TERCEIRA. — Os referidos decretos foram abrogados pelos documentos contrários dos
Romanos Pontífices. Assim, diz Estevam Papa (V): Os sagrados cânones não permitem extorquir de
ninguém uma confissão pela prova do ferro em brasa ou da água fervendo. Pois, as nossas leis só podem
julgar os delitos cometidos, pela confissão espontânea ou afirmação pública de testemunhas. Quanto
aos crimes ocultos e desconhecidos, devem ser abandonados aquele que só conhece o coração dos
filhos dos homens. E o mesmo se lê em outras disposições. Pois, em todas essas práticas, incorre-se em
tentação a Deus; e portanto não podem ser feitas sem pecado. E mais grave seria que se incorresse em
condenação de morte pelo sacramento, instituído para remédio da salvação. Por onde, de nenhum
modo o corpo de Cristo deve ser dado a ninguém suspeito de crime, como meio de o descobrir.

## Art. 7 — Se a polução noturna impede de se receber o corpo de Cristo.
O sétimo discute-se assim. — Parece que a polução noturna não impede ninguém de receber o corpo
de Cristo.

1. — Pois, ninguém fica impedido de receber o corpo de Cristo, senão por pecado. Ora, a polução
noturna é sem pecado. Assim, diz Agostinho: A própria fantasia, surgida no pensamento de quem fala,
pode ser de tal modo viva na visão de quem sonha, a ponto de não poder este distinguir entre essa
fingida e a verdadeira conjunção sexual. Donde resulta o movimento da carne com a conseqüência que
se lhe costuma seguir. O que é tão isento de pecado como isentas de pecado são as palavras proferidas
por quem está acordado, as quais sem nenhuma dúvida foram pensadas, antes de serem ditas. Logo, a
polução noturna não impede ninguém de receber este sacramento.

2. Demais. — Gregório diz: Quem usa da sua esposa, não aliciado pela concupiscência da volúpia, mas
somente com o fim de ter filhos, esse seja deixado ao seu juízo sobre se deve entrar na Igreja ou receber
o mistério do corpo do Senhor. Pois não podemos nós proibir de recebê-lo quem, posto no fogo, não se
deixa arder. Donde se conclui que a polução carnal, mesmo do acordado, se é sem pecado, não o
impede de receber o corpo de Cristo. Logo, com maior razão, não o impede a polução noturna de quem
está adormecido.

3. Demais. — A polução noturna só implica uma impureza do corpo. Ora, as outras impurezas corporais,
que pela Lei Velha impediam de entrar no santuário do templo, não impedem, pela Lei Nova, de receber
o corpo de Cristo. Como é o caso da mulher parturiente, menstruada, ou que sofre de fluxo sanguíneo
— escreve S. Gregório a Agostinho, bispo dos ingleses. Logo, parece que também a polução noturna não
impede ninguém de receber este sacramento.

4. Demais. — O pecado venial não impede uma pessoa de receber este sacramento; e nem também o
pecado mortal, depois de feita penitência. Ora, dado que a polução noturna provenha de um pecado
precedente, quer de atos libertinos, quer de pensamentos torpes, — Quase sempre esse pecado é
venial. E se for mortal é possível fazer-se penitência dele pela manhã e confessá-lo. Logo, parece que
não deve esta pessoa ser impedida de receber este sacramento.

5. Demais. — Mais grave pecado é o homicídio que a fornicação. Ora, quem sonhasse de noite, que
perpetrou um homicídio ou um furto ou qualquer outro pecado, nem por isso ficaria impedido de
receber o corpo de Cristo. Logo, parece que, com maior razão, a fornicação acompanhada de polução
noturna, durante o sonho, não impede de receber este sacramento.
Mas, em contrário, a Escritura: Será imundo até a tarde do mesmo dia o homem que tiver ejaculado o
sêmen no coito. Ora, o imundo não pode achegar-se a este sacramento. Logo, parece que a polução
noturna impede de receber este sacramento, que é o máximo dos sacramentos.

SOLUÇÃO. — A respeito da polução noturna, duas coisas podemos considerar: uma, em razão da qual
absolutamente impede de receber este sacramento; outra, em razão da qual impede, não
necessariamente, mas por uma certa conveniência. Absolutamente impede receber-se este sacramento
só o pecado mortal. E embora a polução noturna, em si mesma considerada, não possa constituir
pecado mortal, nem por isso, contudo, em razão da sua causa, deixa às vezes de ter anexo o pecado
mortal. Por isso devemos atentar a causa da polução noturna. Ora, ela às vezes provém de uma causa
extrínseca espiritual, a saber, da ilusão dos demônios que, como dissemos na Primeira Parte, podem pôr
em movimento os fantasmas, de cuja aparição resulta às vezes a polução. Outras vezes, a polução
resulta de uma causa intrínseca espiritual, a saber, dos pensamentos precedentes. Outras vezes ainda,
de uma causa intrínseca corporal, quer da superabundância ou debilidade da natureza; quer ainda do
excesso de comida ou de bebida. Ora, qualquer destas três causas pode agir sem pecado, e com pecado
venial ou mortal. Assim, se o fizer sem pecado ou com pecado venial, não impede necessàriamente de
receber este sacramento, de modo que quem o recebesse fosse réu do corpo e do sangue do Senhor.
Se, porém, implicar pecado mortal, necessàriamente o impede.
Quanto à ilusão dos demônios, provém de uma negligência precedente ao preparo à devoção; e essa
negligência pode ser pecado mortal ou venial. Outras vezes porém, provém da só maldade dos
demônios, que querem impedir de receber este sacramento. Por isso, como se lê nas Conferências dos
Padres, a um certo que sempre padecia de polução, nos dias de festas em que devia comungar, os
monges mais velhos, depois de terem verificado que nenhuma culpa lhe cabia, determinaram não
deixasse por isso a comunhão; e assim cessou a ilusão dos demônios.
Semelhantemente, também os pensamentos lascivos, precedentes, às vezes podem ser totalmente
isentos de pecado. Por exemplo, quando alguém, por causa de uma lição ou de uma disputa, é obrigado
a ter tais pensamentos. E se não forem acompanhados de concupiscência e de deleitação, esses
pensamentos não serão imundos, mas honestos; dos quais entretanto pode resultar a polução, como o
prova a autoridade supra-citada, de Agostinho. Outras vezes porém os pensamentos precedentes foram
filhos da concupiscência e da deleitação; e então, se houve consentimento, o pecado será mortal; mas
se não houve, será venial. Também semelhantemente, a causa corporal às vezes age sem pecado; por
exemplo, quando a debilidade da natureza leva um a padecer, acordado e sem pecar, o fluxo seminal.
Ou se isso resulta da superabundância natural; pois, assim como podemos derramar sangue sem
pecado, assim também o sêmen, resultante do excesso do sangue, segundo o Filósofo. Mas outras vezes
há nisso pecado, como quando resulta do excesso da comida ou da bebida. Pecado esse que também
pode ser venial ou mortal; embora mais freqüentemente o pecado mortal seja provocado pelos
pensamentos torpes, por causa da facilidade do consentimento — que pelo tomar da comida e da
bebida. Por isso Gregório, escrevendo a Agostinho, bispo dos ingleses, diz que não se pode comungar,
quando a polução provém de pensamentos torpes; mas não, quando procede do excesso de comida e
de bebida, sobretudo se destas houve necessidade. Assim, pois, pela sua causa podemos saber se
polução noturna impede absolutamente de receber este sacramento. Quanto, de outro lado, à
conveniência, impede por duas causas. – Das quais uma, a imundícía corpórea, sempre impede; pois,
quem a tem não deve achegar-se ao altar, como exige a reverência para com o sacramento; por isso os
que querem tocar o que é sagrado lavam as mãos. Salvo se essa imundícia for perpétua ou diuturna,
como a lepra, o fluxo de sangue e outras semelhantes. — Outra causa é a dissipação do espírito,
conseqüente à polução noturna, sobretudo quando esta provém de imaginações torpes. Mas este
impedimento, fundado em conveniência, deve ser desprezado, se alguma necessidade o exigir. Por
exemplo, como adverte Gregório, se assim o requerer um dia festivo, ou se, faltando outro sacerdote, o
compelir a necessidade de exercer o ministério.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Necessariamente ninguém fica impedido de receber
este sacramento; salvo se estiver em estado de pecado mortal. Mas, por conveniência, pode haver
impedimento, em virtude de outras causas, como se disse.

RESPOSTA À SEGUNDA. — O coito conjugal, sendo sem pecado, por exemplo, praticado com a só causa
de gerar filhos ou de pagar o débito, não impede receber este sacramento por outra causa senão a que
já expusemos no tocante à polução noturna isenta de pecado — a saber, por imundície corporal ou
dissipação do coração. Em razão do que Jerônimo diz: Se o pão da proposição não podia ser comido
pelos que tinham tido contato com suas mulheres, com quanto maior razão esse pão descido do céu
não pode ser violado nem tocado pelos que pouco estiveram unidos pelo amplexo conjugal! Não que
condenemos o casamento; mas, no tempo em que devemos comer as carnes do cordeiro, é mister
deixarmos as obras carnais. Mas, isto devemos entender como conveniente e não como necessário; por
isso Gregorio diz que cada um deve julgar o seu caso. — Se porém, não o amor de procriar filhos, mas a
volúpia, for a dominante nesse ato, como acrescenta Gregório no mesmo lugar, então deve haver
proibição de receber o sacramento.

RESPOSTA À TERCEIRA. — Como diz Gregório, na epístola supra-citada, no Testamento Velho, certos
eram considerados imundos figuradamente, o que no regime da Lei Nova se entende em sentido
espiritual. Por onde, essas imundíceis corporais, se forem perpétuas e diuturnas, não impedem de
receber este sacramento de salvação, como impediam o acesso aos sacramentos figurados. Se, porém
forem passageiras, como as imundícias da polução noturna, por uma certa conveniência impedem de
receber este sacramento, no dia em que tiverem ocorrido. Por isso diz a Escritura: Se houver de entre
vós homem que de noite tenha padecido de impurezas entre sonhos, sairá para fora do arraial, e não
voltará sem à tarde se ter lavado em água.

RESPOSTA À QUARTA. — Embora a contrição e a confissão livrem do reato da culpa, nem por isso
elimina a imundície corporal e a dissipação da mente conseqüentes à polução noturna.

RESPOSTA À QUINTA. — O sonho de um homicídio não induz imundície corpórea, nem ainda uma tão
grande dissipação da alma, como a fornicação, por causa da intensidade do prazer desta. Se porém o
sonhar com um homicídio provier de uma causa pecaminosa, sobretudo sendo pecado mortal, impede
de receber este sacramento, em razão da sua causa.

## Art. 8 — Se a comida ou a bebida tomadas antes impedem de receber este sacramento.
O oitavo discute-se assim. — Parece que a comida ou a bebida tomada antes, não impedem de
receber este sacramento.

1. — Pois, este sacramento foi instituído pelo Senhor, na Ceia. Ora, o Senhor, depois que ceou,
outorgou-o aos seus discípulos, como o refere a Escritura. Logo parece que devamos receber este
sacramento, mesmo depois de tomados outros alimentos.

2. Demais. — O Apóstolo diz: Quando vos ajuntais a comer, isto é, o corpo do Senhor, esperai uns pelos
outros; se alguém tem fome coma em casa. Logo, parece que depois de termos comido em casa,
podemos comer na Igreja o corpo de Cristo.

3. Demais. — No terceiro Concílio Cartaginês se determina: Os sacramentos do altar sejam celebrados
só por quem estiver em jejum, exceto unicamente no dia em que se celebra o aniversário da Ceia do
Senhor. Logo, ao menos nesse dia pode-se receber o corpo de Cristo depois de tomados outros
alimentos.

4. Demais. — Tomar água ou um remédio, ou uma comida ou bebida em mínima quantidade, ou engulir
os restos de comida que ficaram na boca, nem quebra o jejum da Igreja nem é contra a sobriedade
exigida para receber-se com reverência este sacramento. Logo, por essas razões ninguém fica impedido
de receber este sacramento.

5. Demais. — Certos comem ou bebem em alta noite e talvez, ficando acordados toda a noite, de
manhã, sem ainda terem feito completamente a digestão, recebem os sagrados mistérios. Ora, menos
contrariaria a sobriedade quem comesse um pouco de manhã e depois, pelas três horas da tarde
recebesse este sacramento; pois, poríamos assim maior distância entre a hora da comida e a comunhão.
Logo, parece que comer, antes de receber este sacramento não impede de o fazer.

6. Demais. — Não menor reverência é devida a este sacramento já recebido, que antes de o
recebermos. Ora, recebido o sacramento, é lícito comer ou beber. Logo, também o é antes.
Mas, em contrário, diz Agostinho: Aprouve ao Espírito Santo que, em honra de tão grande sacramento,
recebesse na sua boca o cristão o corpo do Senhor, antes dos outros alimentos.

SOLUÇÃO. — De dois modos podemos ficar impedidos de receber este sacramento. Por um
impedimento absoluto, como o pecado mortal, que repugna ao significado deste sacramento, como
dissemos. Ou por proibição da Igreja. E assim, ficamos impedidos de receber este sacramento, depois de
termos tomado comida ou bebida, por três razões. — Primeiro como diz Agostinho, para honrar este
sacramento; isto é, para que nos entre na boca ainda não toca da de nenhuma comida nem bebida. —
Segundo, pela sua significação; isto é, para dar-nos a entender que Cristo, realidade deste sacramento, e
a sua caridade devem ser os primeiros a tomar posse dos nossos corações, segundo aquilo do
Evangelho: Buscai primeiro o reino de Deus. — Terceiro, por perigo de vômito ou embriaguez, que às
vezes resultaria do comer desordenadamente. Assim diz o Apóstolo: Uns tem na verdade fome, e outros
estão mui fartos. Mas desta regra geral estão excetuados os enfermos, que devem comungar logo,
mesmo depois de terem comido, se se tema perigo de morrerem sem comunhão, pois a necessidade
não tem lei. Donde o determinar uma disposição canônica: O sacerdote de logo a comunhão ao
enfermo, não vá morrer sem ela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho no mesmo livro, nem pelo Senhor
ter dado o seu corpo, depois de ter comido, devem os fiéis, após terem jantado ou ceado, se reunir para
receberem este sacramento, ou misturá-la com os seus repastos, como o jaziam os que o Apóstolo argui
e corrige. Pois o Salvador, a fim de mais veementemente realçar a grandeza dêsse mistério, qui-lo
infundir por último e mais profundamente no coração e na memória dos discipulos. Por isso não
determinou que, no futuro, fosse recebido na ordem em que o é, deixando-o fazê-lo aos Apóstolos,
pelos quais ia reger as igrejas.

RESPOSTA À SEGUNDA. — As palavras referidas assim as expõe a Glosa: Quem tiver fome e, cheio de
impaciência, não quiser esperar a sua vez, coma em casa a seu repasto, isto é, nutra-se do pão da terra,
nem vá depois tomar a Eucaristia.

RESPOSTA À TERCEIRA. — A disposição citada se funda no costume observado outrora por certos de, no
dia da comemoração da Ceia do Senhor, ser recebido o corpo de Cristo pelos que não estavam em
jejum. Mas este costume está atualmente abrogado. Pois, como diz Agostinho no livro supra-referido,
em todo o mundo se observa este costume, isto é, o de ser recebido o corpo de Cristo por quem está
em jejum.

RESPOSTA À QUARTA. — Como estabelecemos na Segunda Parte, há duas sortes de jejuns. Um é o
jejum natural, que importa na privação de qualquer alimento tomado antes da comunhão, a modo de
comida ou bebida. E tal é o jejum exigido para receber este sacramento, pelas razões dadas. Por onde
não é lícito recebê-lo, por pequena que seja a quantidade, que se tenha tomado antes, de água, ou de
qualquer comida ou bebida, ou mesmo de um remédio. Nem importa se o que se tomou, nutre ou não,
por si só ou de mistura com outro alimento; basta que se tenha tomado a modo de comida ou bebida.
Mas os restos da comida que ficaram na boca, casualmente engulidos, não impedem de receber este
sacramento; porque não atravessam a garganta como comida, mas como saliva. E o mesmo se diga dos
restos de água ou de vinho, com que se lavou a boca, contanto que não sejam engulidos em grande
quantidade, mas de mistura com a saliva — o que não se pode impedir. — Outro é o jejum da Igreja,
instituído para a maceração da carne. E esse não fica quebrado das maneiras que acabamos de referir;
pois, o que desse modo se ingere não nutre propriamente, mas antes altera a disposição do corpo.

RESPOSTA À QUINTA. — O dizer-se que este sacramento deve entrar na boca do cristão, antes de
qualquer outra comida, não deve ser entendido de maneira absoluta, em relação a qualquer tempo. Do
contrário quem uma vez comesse ou bebesse, nunca poderia depois recebê-lo. Mas devemos entendê-
lo relativamente ao mesmo dia. E embora o princípio do dia seja contado diversamente por diversos —
pois, uns o fazem começar ao meio-dia, outros ao ocaso, outros à meia-noite, outros ao nascer do sol –
contudo a Igreja, segundo os romanos, fá-lo começar à meia-noite. Portanto, quem depois da meia-
noite tomar alguma coisa, a modo de comida ou bebida, não poderá no mesmo dia receber este
sacramento; podê-lo-á porém, se o fez antes da meia-noite. Nem importa à razão do preceito se depois
da comida ou da bebida dormiu ou não ou se fez ou não a digestão. Importa porém, quanto à
perturbação da mente, que certos padecem por não terem dormido ou feito a digestão; pois, essa
perturbação pode ser de ordem tal que torne a pessoa incapaz de receber o sacramento.

RESPOSTA À SEXTA. — É necessária máxima devoção para se receber este sacramento, a fim de se
sentir o efeito dele. Ora, essa devoção fica impedida mais pelo que a precede que pelo que se lhe segue.
Por isso instituiu-se, sobretudo que se jejue, antes de se receber este sacramento, que depois. Deve,
contudo haver alguma demora entre o ato de o receber e o de tomar outros alimentos. Por isso, na
missa, reza-se a oração de ação de graças, depois da comunhão, e os que comungaram também fazem
as suas orações privadas. – Segundo, porém os antigos cânones, foi estatuído pelo Papa Clemente: Os
ministros que tomaram a sua refeição dominical, pela manhã, jejuem até a sexta hora; e os que o
fizeram, na terceira ou na quarta hora, jejuem até a tarde. Porque antigamente mais raro era o
celebrarem-se as solenidades da missa, e exigir-se mais preparação. Atualmente porém, devendo
celebrar-se com mais freqüência os sagrados mistérios, tais exigências não seria fácil observá-las. Por
isso foram abrogadas pelo costume contrário.

## Art. 9 — Se os que não tem o uso da razão devem receber este sacramento.
O nono discute-se assim. — Parece que os destituídos do uso da razão não devem receber este
sacramento.

1. — Pois, é necessário achegar-se a este sacramento com devoção e depois do exame de consciência,
segundo aquilo do Apóstolo: Examine-se a si mesmo o homem e assim coma deste pão e beba deste
cálice. Ora isto, não o podem fazer os que não têm o uso da razão. Logo, não se lhes deve dar este
sacramento.

2. Demais. — Entre os privados do uso da razão, estão os arreptícios, chamados energúmenos. Ora,
esses são afastados mesmo da contemplação deste sacramento, segundo Dionísio. Logo, este
sacramento não deve ser dado aos privados do uso da razão.

3. Demais. — Entre os privados do uso da razão, sobretudo se consideram inocentes as
temporariamente de recebê-lo. Logo, não é aconselhável recebermos todos os dias este sacramento.
Mas, em contrário, diz Agostinho: Este é o pão quotidiano; recebe todos os dias o que todos os dias te
aproveita.

SOLUÇÃO. — A respeito do uso deste sacramento duas coisas podemos considerar. Uma relativa ao
próprio sacramento, cuja virtude é salutar aos homens. Por isso é útil o recebermos quotidianamente,
para quotidianamente lhe colhermos o fruto. Por onde diz Ambrósio: Se todas as vezes que o sangue de
Cristo é derramado, pela remissão dos pecados o é, devo sempre recebê-lo, que sempre peco; devo
sempre ter o remédio. A outra luz. podemos considerá-la relativamente a quem o recebe, que deve se
achegar a este sacramento com grande devoção e grande reverência. Portanto, quem quotidianamente
se julgar preparado para tal, é aconselhável que quotidianamente o receba. Por isso Agostinho, depois
de ter dito — recebe o que todos os dias te é útil, acrescenta: Vive de modo que mereças recebê-lo
quotidianamente. Mas como muitas. vezes, em casos freqüentes, muitos impedimentos ocorrem contra
esta devoção, por indisposição do corpo ou da alma, não é útil a todos achegar-se a este sacramento
quotidianamente, mas só as vezes em que um se julgue preparado. Por isso um autor diz: Receber
quotidianamente a comunhão eucarística, não o louvo nem o censuro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pelo sacramento do batismo nos configuramos à morte
de Cristo, recebendo em nós o seu caráter. Por onde, assim como Cristo morreu uma só vez, devemos
ser batizados uma só vez. Neste sacramento porém não recebemos o caráter de Cristo, mas o próprio
Cristo, cuja virtude permanece eternamente. Donde o dizer o Apóstolo: Com uma só oferenda fez
perfeitos para sempre aos que tem santificado. Por onde, como quotidianamente precisamos da virtude
salutífera de Cristo, podemos, e louvavelmente, receber todos os dias este sacramento. — E sendo o
batismo sobretudo uma regeneração espiritual, por isso, assim como nascemos carnalmente só uma
vez, assim devemos só uma vez renascer espiritualmente pelo batismo, como adverte Agostinho, àquilo
do Evangelho. Como pode um homem nascer, sendo velho? Ora, este sacramento é uma comida
espiritual; por onde, assim como tomamos o alimento do corpo quotidianamente, assim também é
aconselhável receber quotidianamente este sacramento. Por isso o senhor nos ensina a pedir: o pão
nosso de cada dia nos dai hoje. Expondo o que, diz Agostinho: Se todos os dias o receberes, isto é, este
sacramento todos os dias são para ti o dia de hoje; pois qualquer dia é para ti o dia de hoje, em que
Cristo para ti ressurgiu.

RESPOSTA À SEGUNDA. — O cordeiro pascal foi a figura precípua deste sacramento, quanto à paixão de
Cristo, que a Eucaristia representa. Por isso era tomado uma só vez no ano, porque Cristo morreu uma
vez. E por isso também a Igreja celebra uma vez no ano a memória da paixão de Cristo. Mas este
sacramento nos transmite o memorial da paixão de Cristo a modo de comida, o qual tomamos todos os
dias. E assim, sob este aspecto, era significado pelo maná, dado quotidianamente ao povo no deserto.

RESPOSTA À TERCEIRA. — Na reverência para com este sacramento o temor vai junto com o amor; por
Isso o temor de reverência para com Deus se chama temor filial, como dissemos na Segunda Parte. Pois,
ao passo que o amor provoca o desejo de receber a Eucaristia, do temor nasce a humildade reverente.
Por isso, tanto constitui reverência ao sacramento recebê-lo quotidianamente como dele nos
abstermos. Donde o dizer Agostinho: Se um e outro disser o contrário, faça cada qual aquilo que, na sua
fé piedosa, julga dever fazer. Nem litigaram entre si Zaqueu e aquele centurião, recebendo um deles,
cheio de alegria, ao Senhor, e dizendo-lhe o outro — Não sou digno de que entreis em minha casa.
Ambos louvaram ao Senhor, embora não do mesmo modo. Contudo, o amor e a esperança, que a
Escritura procura sempre despertar em nós, são preferíveis ao temor. Por isso, quando Pedro exclamou:
Retira-te de mim, Senhor, que sou um homem pecador — Jesus respondeu: Não temais.

RESPOSTA À QUARTA. — De ter dito o Senhor — O pão nosso de cada dia nos dai hoje, não se segue
que devemos comungar várias vezes por dia. Mas o comungarmos uma vez representa a unidade da
paixão de Cristo.

RESPOSTA À QUINTA. — A Igreja estabeleceu legislações diversas conforme as circunstâncias diversas
dos tempos. Assim, na Igreja primitiva, quando era intenso o fervor da fé cristã, determinou que os fiéis
comungassem diariamente. Por isso Anacleto Papa estatuiu: Terminada a consagração, comunguem
todos os que não quiserem ficar excluídos da assembléia dos fiéis; pois, assim o determinaram os
Apóstolos e o tem a santa Igreja Romana. Mais tarde, porém, diminuindo o fervor da fé, Fabiano Papa
permitiu que, se não mais freqüentem ente, pelo menos três vezes no ano todos comungassem — na
Páscoa, no Pentecostes e no Natal do Senhor. Também o Papa Sotero determinou que se comungasse
pela Ceia do Senhor. Mas depois, pela multiplicação da iniquidade, resfriando-se a caridade de muitos,
Inocêncio III estatuiu, que os fiéis comungassem pelo menos uma vez no ano, na Páscoa. — Aconselha
porém, o livro dos dogmas eclesiásticos, que se deve comungar todos os domingos.

## Art. 10 — Se é lícito receber este sacramento cotidianamente.
O décimo discute-se assim. — Parece que não é lícito receber este sacramento cotidianamente.

1. — Pois, assim como o batismo representa a paixão do Senhor, assim também este sacramento. Ora,
não é lícito batizar várias vezes, mas uma só; porque Cristo morreu uma vez só, pelos nossos pecados,
como diz a Escritura. Logo, parece que não é lícito receber este sacramento cotidianamente.

2. Demais. — A verdade deve corresponder à figura. Ora, o cordeiro pascal, figura precípua deste
sacramento, como se disse, não era comido senão uma só vez no ano. Mas, a Igreja celebra uma vez no
ano a paixão de Cristo, da qual este sacramento é o memorial. Logo, parece que não é lícito receber
cotidianamente este sacramento, mas uma só vez no ano.

3. Demais. — A este sacramento, em que todo Cristo está contido, é devido a máxima reverência. Ora,
essa mesma reverência exige que dele nos abstenhamos, sendo pr isso que no Evangelho é louvado o
centurião que disse — Senhor não sou digno que entreis na minha casa. E Pedro, que exclamou: Retirate
de mim, Senhor, que sou homem pecador. Logo, não é louvável o recebermos cotidianamente neste
sacramento.

4. Demais. — Se fosse aconselhável receber frequentemente este sacramento, quanto mais
frequentemente o recebêssemos tanto melhor procederíamos. Ora, mais freqüência ainda haveria se o
recebêssemos várias vezes por dia. Logo, seria aconselhável comungarmos várias vezes por dia. O que
não é contudo costume da Igreja. Portanto, não é aconselhável recebermos cotidianamente este
sacramento.

5. Demais. — A Igreja visa, com a sua legislação, prover à utilidade dos fiéis. Ora, por determinação da
Igreja, os fiéis são obrigados a comungar só uma vez por ano. Assim, reza uma disposição canônica:
Todos os fiéis de um e outro sexo recebam reverentemente, pelo menos na Páscoa, o sacramento da
Eucaristia; salvo talvez se por conselho do sacramento próprio, por alguma causa racional, for levado a
se abster temporariamente de recebê-lo. Logo, não é aconselhável recebermos todos os dias este
sacramento.
Mas, em contrário, diz Agostinho: Este é o pão cotidiano; recebe todos os dias o que todos os dias se
aproveita.

SOLUÇÃO. — A respeito do uso deste sacramento, duas coisas podemos considerar. Uma, relativa ao
próprio sacramento, cuja virtude é salutar aos homens. Por isso é útil o recebermos cotidianamente,
para cotidianamente lhe colhermos o fruto. Por onde diz Ambrósio: Se todas as vezes que o sangue de
Cristo é derramadno, pela remissão dos pecados o é, devo sempre recebê-lo, que sempre peco; devo
sempre ter o remédio. — A outra luz, podemos considerá-la relativamente a quem o recebe, que deve
se achegar a este sacramento com grande devoção e grande reverência. Portanto, quem
cotidianamente se julgar preparado para tal, é aconselhável que cotidianamente o receba. Por isso
Agostinho, depois de ter dito — recebe o que todos os dias te é útil — acrescenta: Vive de modo que
mereças recebê-lo cotidianamente. Mas como muitas vezes, em casos freqüentes, muitos
impedimentos ocorrem contra essa devoção, por indisposição do corpo ou da alma, não é útil a todos
achegar-se a este sacramento cotidianamente, mas só as vezes em que um se julgue preparado. Por isso
um autor diz: Receber cotidianamente a comunhão eucarística, não o louvo nem o censuro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pelo sacramento do batismo nos configuramos à morte
de Cristo, recebendo em nós o seu caráter. Por onde, assim como Cristo morreu uma só vez, devemos
ser batizados uma só vez. Neste sacramento porém não recebemos o caráter de Cristo, mas o próprio
Cristo, cuja virtude permanece eternamente. Donde o dizer o Apóstolo: Com uma só oferenda fez
perfeitos para sempre aos que tem santificado. Por onde, como cotidianamente precisamos da virtude
salutífera de Cristo, podemos, e louvavelmente, receber todos os dias este sacramento. — E sendo o
batismo sobretudo uma regeneração espiritual, por isso, assim como nascemos carnalmente só uma
vez, assim devemos só uma vez renascer espiritualmente pelo batismo, como adverte Agostinho, àquilo
do Evangelho: Como pode um homem nascer, sendo velho? Ora, este sacramento é uma comida
espiritual; por onde, assim como tomamos o alimento do corpo cotidianamente, assim também é
aconselhável receber cotidianamente este sacramento. Por isso o Senhor nos ensina a pedir: o pão
nosso de cada dia nos dai hoje. Expondo o que, diz Agostinho: Se todos os dias o receberes, isto é, este
sacramento, todos os dias são para ti o dia de hoje; pois qualquer dia é para ti o dia de hoje, em que
Cristo para ti ressurgiu.

RESPOSTA À SEGUNDA. — O cordeiro pascal foi a figura precípua deste sacramento, quanto à paixão de
Cristo, que a Eucaristia representa. Por isso era tomado uma só vez no ano, porque Cristo morreu uma
vez. E por isso também a Igreja celebra uma vez no ano a memória da paixão de Crito. Mas este
sacramento nos transmite o memorial da paixão de Cristo a modo de comida, o qual tomamos todos os
dias. E assim, sob este aspecto, era significado pelo maná, dado cotidianamente ao povo no deserto.

RESPOSTA À TERCEIRA. — Na reverência para com este sacramento o temor vai junto com o amor; por
isso o temor de reverência para com Deus se chama temor filial, como dissemos na Segunda Parte. Pois,
ao passo que o amor provoca o desejo de receber a Eucaristia, do temor nasce a humildade reverente.
Por isso, tanto constitui reverência ao sacramento recebe-lo cotidianamente como dele nos abstermos.
Donde o dizer Agostinho: Se um e outro disser o contrário, faça cada qual aquilo que, na sua fé piedosa,
julga deve fazer. Nem litigaram entre si Zaqueu e aquele centurião, recebendo um deles, cheio de
alegria, ao Senhor, e dizendo-lhe o outro — Não sou digno de que entreis em minha casa. Ambos
louvaram ao Senhor, embora não do mesmo modo. Contudo, o amor e a esperança, que a Escritura
procura sempre despertar em nós, são preferíveis ao temor. Por isso, quando Pedro exclamou: Retira-te
de mim, Senhor, que sou um homem pecador — Jesus respondeu: Não temais.

RESPOSTA À QUARTA. — A Igreja estabeleceu legislações diversas conforme as circunstâncias diversas
dos tempos. Assim, na Igreja primitiva, quando era intenso o fervor da fé cristã, determinou que os fiéis
comungassem diariamente. Por isso Anacleto Papa estatuiu: Terminada a consagração, comunguem
todos os que não quiserem ficar excluídos da assembléia dos fiéis; pois, assim o determinaram os
Apóstolos e o tem a santa Igreja Romana. Mais tarde porém, diminuindo o fervor da fé, Fabiano Papa
permitiu que, se não mais frequentemente, pelo menos três vezes no ano todos comungassem — na
Páscoa, no Pentecostes e no Natal do Senhor. Também o Papa Sotero determinou que se comungasse
pela Ceia do Senhor. Mas depois, pela multiplicação da iniqüidade, resfriando-se a caridade de muitos,
Inocêncio III estatuiu, que os fiéis comungassem pelo menos uma vez no ano, na Páscoa. — Aconselha
porém o livro Dos dogmas eclesiásticos, que se deve comungar todos os domingos.

## Art. 11 — Se é lícito deixar de todo a comunhão.
O undécimo discute-se assim. — Parece que é lícito deixar de todo a comunhão.

1. — Pois, foi louvado o Centurião por ter dito: Senhor não sou digno de que entres em minha casa. E a
ele é comparável quem julga que deve abster-se da comunhão, como se disse. Ora, o Evangelho, não
referindo que Cristo algum dia viesse à casa do centurião, parece que é lícito abstermo-nos por toda a
vida, da comunhão.

2. Demais. — A todos é lícito absterem-se do que não é necessário à salvação. Ora, este sacramento não
é de necessidade para a salvação, como se disse. Logo, é lícito deixar totalmente de recebê-lo.

3. Demais. — Os pecadores não são obrigados a comungar. Por isso Fabiano Papa, depois de ter dito —
Todos comunguem três vezes por ano — acrescentou: salvo quem estiver impedido, por crimes maiores.
Se, pois, os que não estão em pecado devem comungar, parece que em melhores condições estão os
justos, que os pecadores o que é inadmissível. Logo, parece que também aos justos é lícito deixar
completamente a comunhão.
Mas, em contrário, o Senhor disse: Se não comerdes a carne do Filho do homem e beberdes o seu
sangue, não tereis a vida em vós.

SOLUÇÃO. — Como dissemos de dois modos podemos receber este sacramento — espiritual e
sacramentalmente. Ora, é manifesto que todos estão obrigados a comungar ao menos espiritualmente,
como dissemos. Logo, sem o desejo de receber este sacramento ninguém pode salvar-se. Mas o desejo
seria vão se não se cumprisse quando se oferecesse a oportunidade. Por onde, é manifesto que estamos
obrigados a receber este sacramento, não só por determinação da Igreja, como também por
mandamento do Senhor, quando disse: Fazei isto em memória de mim. E pelas suas determinações a
Igreja marcou os tempos de se cumprir o preceito de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Gregório, a verdadeira humildade consiste em
não desobedecermos com pertinácia ao que é preceituado para nossa utilidade. Por onde, não pode ser
uma humildade louvável se, contra o preceito de Cristo e da Igreja, nos abstivermos completamente da
comunhão. Quanto ao centurião, não lhe estava preceituado que recebesse a Cristo na sua casa.

RESPOSTA À SEGUNDA. — Diz-se que este sacramento não é de necessidade para a salvação, como o
batismo — relativamente às crianças, que podem salvar-se sem ele, mas não sem o batismo. Mas, para
os adultos, ambos são necessários.

RESPOSTA À TERCEIRA. — Os pecadores sofrem grande detrimento por serem privados de receberem
este sacramento; e por isso não vêm a ficar em melhores condições. E, embora permanecendo no
pecado, não sejam por isso escusados da transgressão do preceito, contudo, quando fizerem penitência,
se se abstiverem da comunhão por conselho de um sacerdote, ficam excusados, como diz Inocência.

## Art. 12 — Se é lícito receber o corpo de Cristo sem o sangue.
O duodécimo discute-se assim. — Parece que não é licito receber o corpo de Cristo, sem o sangue.

1. — Pois, diz Gelásio Papa: Chegou ao nosso conhecimento que certos, tomam somente a porção do
sagrado corpo e abstém-se do cálice do sagrado sangue. Esses e sem nenhuma dúvida pois, não sei que
superstição os leva a se absterem — ou recebam todo o sacramento ou o deixem todo. Logo, não é lícito
tomar o corpo de Cristo sem o seu sangue.

2. Demais. — A perfeição deste sacramento consiste em comermos o corpo de Cristo e lhe bebermos o
sangue, como se disse. Logo, tomando o corpo sem o sangue, o sacramento será imperfeito. O que
constitui sacrifício. Por isso Gelásio acrescenta, no mesmo lugar: Porque a divisão de um e mesmo
mistério não pode ir sem um grande sacrilégio.

3. Demais. — Este sacramento é celebrado em memória da paixão do Senhor, como se disse; e é
recebido para a salvação da nossa alma. Ora, a paixão de Cristo se manifesta antes pelo sangue, que
pelo corpo; e também o sangue é oferecido pela salvação da alma, como se estabeleceu. Logo,
deveríamos antes nos abster de receber o corpo, que o sangue. Portanto, os que se achegam a este
sacramento não devem receber o corpo de Cristo sem o seu sangue.
Mas, em contrário, o uso de muitas Igrejas, nas quais se dá aos comungantes a receber o corpo de Cristo
e não o sangue.

SOLUÇÃO. — Sobre o uso deste sacramento duas coisas podemos considerar — uma relativa ao
sacramento; a outra relativa aos que o recebem. — Relativamente ao sacramento deve-se receber a
ambos, isto é, ao corpo e ao sangue, porque em receber ambos consiste a perfeição do sacramento.
Portanto, o sacerdote, que deve consagrar este sacramento e consumá-lo, de nenhum modo deve
tomar o corpo de Cristo, sem o sangue. — Relativamente aos que o recebem, é necessária uma
reverência e cautela para não acontecer nada que redunde em ofensa de tão grande mistério. E isso
pode dar-se sobretudo no beber-se o sangue, que, tomado sem precauções, facilmente se derrama.
Ora, como foi aumentando a multidão do povo cristão, composto de velhos, moços e crianças, nem
todos os quais aplicam a discreção e a cautela devidas, ao uso deste sacramento, por isso e
acertadamente certas igrejas seguem o costume de não dar o sangue a beber ao povo, que é tomado só
pelo sacerdote.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Gelásio se refere aos sacerdotes que, assim como
consagram o sacramento completo, assim também devem comungá-lo todo. Pois, como se lê no
Concílio Toledano (XII), que sacrifício será aquele onde não se vê dele participar nem mesmo o
sacrificante?

RESPOSTA À SEGUNDA. — A plenitude deste sacramento não está no uso dos fiéis, mas na consagração
da matéria. Por onde, em nada derroga à perfeição dele se o povo o tomar sem o sangue; contanto que
o sacerdote que o consagrou, tome ambas as espécies.

RESPOSTA À TERCEIRA. — A memória da paixão do Senhor se opera na consagração mesma deste
sacramento, em que não deve ser consagrado o corpo sem o sangue. Porém o povo pode tomar o corpo
sem o sangue, sem que daí resulte nenhum detrimento. Porque o sacerdote em nome de todos oferece
e toma o sangue; e sob ambas as espécies está contido todo Cristo, como estabelecemos.