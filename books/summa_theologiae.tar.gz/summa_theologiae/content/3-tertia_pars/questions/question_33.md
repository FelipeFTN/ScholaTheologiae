# Questão 33: Do modo e da ordem da concepção de Cristo
Em seguida devemos tratar do modo e da ordem da concepção de Cristo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se o corpo de Cristo foi formado desde o primeiro instante da sua concepção.
O primeiro discute-se assim. — Parece que o corpo de Cristo não foi formado desde o primeiro
instante da sua concepção.

1. — Pois, diz o Evangelho: Em se edificar este templo gastaram-se quarenta e seis anos. Expondo o que
diz Agostinho: Este número manifestamente convém à perfeição do corpo do Senhor. E em outro lugar:
Não sem razão se diz que o Templo foi fabricado em quarenta e seis anos, o qual lhe significava o corpo;
de modo que quantos anos se gastaram na fabricação do templo, outros tantos se empregaram na
perfeição do corpo do Senhor. Logo, o corpo de Cristo não foi perfeitamente formado desde o primeiro
instante da sua concepção.

2. Demais. — A formação do corpo de Cristo exigia o movimento local, que levasse o mais puro sangue
do corpo da Virgem para o órgão próprio da geração. Ora, nenhum corpo pode mover-se local e
instantaneamente, porque o tempo do movimento se divide pelas divisões do móvel, como Aristóteles o
prova. Logo, o corpo de Cristo não foi formado num instante.

3. Demais. — O corpo de Cristo foi formado do sangue mais puro da Virgem, como se estabeleceu. Ora,
essa matéria não podia ser no mesmo instante sangue e carne, porque teria tido então duas formas ao
mesmo tempo. Logo, houve um instante em que foi ultimamente sangue, e outro em que primeiro a
carne começou a ser formada. Mas, entre dois instantes quaisquer há um tempo intermédio. Logo, o
corpo de Cristo não foi formado num instante, mas num determinado tempo.

4. Demais. — Assim como a potência aumentativa exige para o seu ato um tempo determinado, assim
também a virtude geratriz; pois, ambas são potências naturais pertencentes à alma vegetativa. Ora, o
corpo de Cristo cresceu num tempo determinado, como os corpos dos outros homens; assim, diz o
Evangelho, que progredia em sabedoria e em idade. Logo, parece que pela mesma razão, a formação do
seu corpo, que pertence à potência geratriz, não se realizou num instante, mas no tempo determinado
em que se formam os corpos dos outros homens.
Mas, em contrário, Gregório diz: Depois da anunciação do Anjo e da descida do Espírito Santo, desde o
momento em que o Verbo existiu no ventre da Virgem, tornou-se carne.

SOLUÇÃO. - Na concepção do corpo de Cristo três fases devemos considerar. Primeira, o movimento
local do sangue para o órgão da geração; segunda, a formação do corpo, de tal matéria; e terceira, o
crescimento pelo qual chegou ao seu perfeito desenvolvimento. E dessas, é a segunda que constitui a
essência mesma da concepção, da qual a primeira é o preâmbulo e a terceira, a consequência. - Ora, a
primeira não pode dar-se instantaneamente, porque iria contra a natureza mesma do movimento local
de qualquer corpo, cujas partes ocupam sucessivamente um lugar determinado. Semelhantemente,
também a terceira deve ser sucessiva, quer por não haver aumento sem movimento local, quer por
proceder da virtude da alma, que obra num corpo já formado, o qual para agir supõe o tempo.
Mas, a formação do corpo, que constitui a essência mesma da concepção, foi instantânea, por duas
razões. - Primeiro, pela virtude infinita do agente, isto é, do Espírito Santo, pelo qual foi formado o
corpo de Cristo, como dissemos. Pois, tanto mais prontamente pode um agente dispor a matéria,
quanto maior for a virtude dele. Por onde, um agente de virtude infinita pode dispor num instante a
matéria, para receber a forma devida. - Segundo, quanto à pessoa do Filho, cujo era formado o corpo.
Pois, não lhe fora conveniente assumir um corpo humano senão formado. Se, pois, à formação perfeita
tivesse precedido algum tempo, da concepção, esta não poderia ser totalmente atribuída ao Filho de
Deus, pois não se lhe atribui senão em razão da assunção. Por isso, no primeiro instante em que a
matéria preparada chegou ao órgão da geração, nesse mesmo momento foi perfeitamente formado e
assumido o corpo de Cristo. E por isso dizemos, que o concebido foi o Filho de Deus mesmo, o que, de
outro modo, não poderia dizer-se.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras citadas de Agostinho não se referem a só
formação do corpo de Cristo; mas simultaneamente à formação e ao crescimento correspondente até
ao tempo do parto. E por isso, diz ele que o referido número representa o tempo completo de nove
meses, durante o qual Cristo esteve no ventre da Virgem.

RESPOSTA À SEGUNDA. — Esse movimento local não está incluído na concepção mesmo, mas é um
preâmbulo para ela.

RESPOSTA À TERCEIRA. — Não é possível determinar o último instante em que a matéria referida
tornou-se sangue, mas podemos determinar o tempo último, continuado, sem nenhum intervalo, até o
primeiro instante em que foi formada a carne de Cristo. E esse instante foi o termo do tempo do
movimento local da matéria, para o órgão da geração.

RESPOSTA À QUARTA. — O crescimento se faz pela potência aumentativa do ser mesmo que cresce; ao
passo que a formação do corpo é obra da potência geratriz, não do ser gerado, mas do pai gerador, pelo
sêmen, por obra da virtude formativa, derivada da alma do pai. O corpo de Cristo, porém, não foi
formado do sêmen masculino, como se disse, mas por obra do Espírito Santo. Por onde, a formação
devia ser tal, que conviesse ao Espírito Santo. Mas, o crescimento do corpo de Cristo se realizou pela
potência aumentativa da sua alma; que, sendo especificamente da mesma forma que a nossa, o seu
corpo devia crescer do mesmo modo por que crescem os corpos dos outros homens, para ficar assim
demonstrada que a sua natureza era verdadeiramente humana.

## Art. 2 — Se o corpo de Cristo foi animado no primeiro instante da sua concepção.
O segundo discute-se assim. — Parece que o corpo de Cristo não foi animado no primeiro instante da
sua concepção.

1. — Pois, diz Leão Papa: A carne de Cristo não foi de uma natureza diferente da nossa; nem a sua alma
proveio de um princípio diferente donde provêm as almas dos outros homens. Ora, nos outros homens
a alma não é infundida no primeiro instante da sua concepção. Logo, nem no corpo de Cristo a alma
devia ser infundida no primeiro instante da sua concepção.

2. Demais. — A alma, como qualquer forma natural, exige um certo desenvolvimento do corpo. Ora, no
primeiro instante da sua concepção, o corpo de Cristo não tinha a mesma quantidade que tem os corpos
dos outros homens, quando animados. Pois, do contrário, tendo crescido continuamente, ou teria
nascido mais cedo, ou, ao nascer, seria mais desenvolvido que o corpo das demais crianças. Ora, a
primeira hipótese vai contra Agostinho, quando prova que o corpo de Cristo esteve no ventre da Virgem
durante o espaço de nove meses. A segunda, contra Leão Papa, quando diz: Encontraram o menino
Jesus em nada dissemelhante da generalidade da infância humana. Logo, o corpo de Cristo não foi
animado desde o primeiro instante da sua concepção.

3. Demais. — Onde há anterioridade e posterioridade há de necessariamente haver muitos instantes.
Ora, segundo o Filósofo, a geração do homem implica anterioridade e posterioridade; assim, primeiro é
vivo, depois animal e, enfim, homem. Logo, não podia Cristo ter recebido a alma desde o primeiro
instante da sua concepção.
Mas, em contrário, diz Damasceno: Simultaneamente existiu a carne, o Verbo de Deus feito carne e a
carne animada pela alma racional e intelectual.

SOLUÇÃO. — Para a concepção ser atribuída ao Filho de Deus, como confessamos no Símbolo. - Que foi
concebido do Espírito Santo, devemos necessariamente admitir que o corpo de Cristo, ao ser concebido,
foi assumido pelo Verbo de Deus. Ora, como já demonstramos, o Verbo de Deus assumiu o corpo
mediante a alma; e a alma, mediante o espírito, isto é, o intelecto. Por onde e necessariamente, desde o
primeiro instante da sua concepção o corpo de Cristo foi animado da alma racional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. - O princípio em virtude do qual a alma é infundida no
corpo pode ser considerado a dupla luz. - Primeiro, relativamente à disposição do corpo. E assim, a alma
não foi infundida no corpo de Cristo em virtude de um princípio diferente do por que o é no corpo dos
outros homens. Pois, assim como a alma é infundida em nosso corpo desde que está formado, assim
também o foi em Cristo. - Segundo, o referido princípio pode ser considerado só relativamente ao
tempo. E assim, como o corpo de Cristo foi formado perfeitamente antes do tempo formal, também
antes desse tempo foi animado.

RESPOSTA À SEGUNDA. — A alma supõe o corpo suficientemente desenvolvido em que é infundida;
mas esse desenvolvimento tem uma certa latitude, pois, pode ser mais ou menos considerável. Em nós,
o desenvolvimento do corpo, quando a alma acaba de ser nele infundida, é proporcionado ao tamanho
normal que terá quando chegar ao seu desenvolvimento perfeito. De modo que indivíduos maiores
terão já corpo mais desenvolvido, por ocasião de lhe ser a alma infundida. Ora, Cristo, na sua idade
perfeita, tinha uma estatura normal e média, e a ela foi proporcionado o desenvolvimento do seu corpo
no momento correspondente ao em que o corpo dos outros homens recebe a alma. Por onde, o seu
volume físico foi menor no momento da sua concepção. Mas não foi menor a ponto de não poder nele
subsistir a alma racional. Pois, a alma subsiste mesmo no pequeno volume do que será mais tarde o
corpo de homens anões.

RESPOSTA À TERCEIRA. — O dito do Filósofo se refere à geração dos outros homens, porque o corpo
deles é sucessivamente formado e disposto para receber a alma. Por isso, enquanto ainda tem uma
disposição imperfeita, recebe uma alma imperfeita; e depois recebe uma alma perfeita, quando já
perfeitamente disposto. Mas o corpo de Cristo, por causa do poder infinito do seu princípio ativo, foi
perfeitamente disposto, num instante. E por isso, desde o primeiro instante da sua concepção, recebeu
logo uma forma perfeita, isto é, a alma racional.

## Art. 3 — Se a carne de Cristo foi primeiro concebida e depois assumida.
O terceiro discute-se assim. — Parece que a carne de Cristo foi primeiro concebida e depois assumida.

1. — O que não existe não pode ser assumido. Ora, a carne de Cristo começou a existi na concepção.
Logo, parece que foi assumida pelo Verbo de Deus depois de concebida.

2. Demais. — A carne de Cristo foi assumida pelo Verbo de Deus mediante a alma racional. Ora, a alma
racional a recebeu no termo da sua concepção. Logo, no termo da concepção é que foi assumida. Ora,
no termo da concepção já estava concebida de todo. Logo, foi primeiro concebida e depois assumida.

3. Demais. — Todo ser gerado foi imperfeito antes de ser perfeito, como está claro no Filósofo. Ora, o
corpo de Cristo foi um corpo gerado. Portanto, não chegou logo, desde o primeiro instante da sua
concepção, à perfeição última, consistente na união com o Verbo de Deus; mas, primeiro, foi a carne
concebida e, depois, assumida.
Mas, em contrário, Agostinho (Fulgêncío) diz: Crê firmissimamente e de nenhum modo duvides, que a
carne de Cristo não foi concebida no ventre da Virgem antes de assumida pelo Verbo.

SOLUÇÃO. — Como já mostramos, dizemos propriamente que Deus se fez homem, mas propriamente
não dizemos, que o homem se fez Deus. Porque Deus assumiu para si a natureza humana; mas antes de
assumida pelo Verbo a natureza humana não existia, por si mesma subsístente. Se, pois, a carne de
Cristo tivesse sido concebida, antes de assumida pelo Verbo, teria tido, então, uma determinada
hipóstase, além da hipóstase do Verbo de Deus. Ora, isto vai contra a natureza da Encarnação, pela qual
o Verbo de Deus se uniu à natureza humana e a todas as suas partes, na unidade da hipóstase. Nem
convinha que, pela sua assunção, o Verbo de Deus destruísse a hipóstase preexistente da natureza
humana ou de alguma das suas partes. Por onde, é contra a fé dizer que a carne de Cristo foi primeiro
concebida e depois concebida pelo Verbo de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Se a carne de Cristo não tivesse sido formada ou
concebida num instante, mas na sucessão do tempo, resultaria necessariamente uma ou outra destas
duas consequências: ou o Verbo assumiu o que ainda não era carne, ou a concepção da carne foi
anterior à assunção. Ora, como provamos a concepção se realizou perfeitamente num instante; por
consequência, a carne veio à existência e foi concebida simultaneamente. E assim, como diz Agostinho,
afirmamos que que o Verbo de Deus foi concebido em razão da sua união com a carne, e a carne, por
seu lado, foi concebida em razão da encarnação do Verbo.
Donde se deduz clara também A RESPOSTA À SEGUNDA OBJEÇÃO. — Pois, desde que a carne foi
concebida, o foi perfeitamente e, desde logo, animada.

RESPOSTA À TERCEIRA. — No mistério da Encarnação não há nenhuma ascensão, como seria a de um
ser preexistente que se fosse alcançado até a dignidade da união, como o pretendeu o herético Fotino.
Mas, o que nele descobrimos é um descenço , consistente em ter o Verbo perfeito de Deus assumido a
imperfeição da nossa natureza, conforme o dito do Evangelho: Desci do céu.

## Art. 4 — Se a concepção de Cristo foi natural.
O quarto discute-se assim. — Parece que a concepção de Cristo foi natural.

1. — Pois, pela concepção da carne é Cristo chamado Filho do homem. Ora, é verdadeiro e
naturalmente filho do homem, como verdadeiro e naturalmente é Filho de Deus. Logo, a sua concepção
foi natural.

2. Demais. — Nenhuma criatura é capaz de realizar um ato milagroso. Ora, a concepção de Cristo é
atribuída à Santa Virgem, que é uma simples criatura; assim, diz-se que a Virgem concebeu a Cristo.
Logo, a sua concepção não foi miraculosa, mas natural.

3. Demais. — Para uma transformação ser natural, basta que o seu princípio passivo o seja, como se
estabeleceu. Ora, o princípio passivo, pelo lado da mãe, na concepção de Cristo, foi natural, como do
sobredito se colhe. Logo, a concepção de Cristo. foi natural.
Mas, em contrário, diz Dionísio: Cristo praticou as ações humanas de um modo sobre-humano; e isso
demonstra ter sido sobrenatural a concepção da Virgem.

SOLUÇÃO. — Como diz Ambrósio, neste mistérios descobrirás muitas causas naturais e muitas outras
sobrenaturais. Assim, se atendermos à matéria da concepção, que a Mãe ministrou, tudo é natural. E se
considerarmos a influência do principio ativo, tudo é milagroso. Ora, nós julgamos um ser, fundados
antes na sua forma, que na sua matéria; e semelhantemente, antes, pelo seu princípio ativo que pelo
passivo. Donde, a concepção de Cristo devemos considerá-la absolutamente milagrosa e sobrenatural;
mas, de certo modo, natural.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dizemos que Cristo é naturalmente filho do homem, por
ter verdadeiramente a natureza humana, que o torna filho do homem embora por milagre a tivesse.
Assim, um cego, que recobrou a vista, vê naturalmente pela potência visiva que milagrosamente
recebeu.

RESPOSTA À SEGUNDA. — A concepção é atribuída à Santa Virgem, não como ao princípio ativo; mas
por ter ministrado a matéria da concepção e por ter-se esta consumado no seu ventre.

RESPOSTA À TERCEIRA. — O principio passivo natural basta para uma transformação natural, quando
for, do modo natural e costumado, movido pelo princípio ativo próprio. Mas, isto não tem lugar no caso
vertente. Logo, a concepção de Cristo não pode ser considerada simplesmente natural.