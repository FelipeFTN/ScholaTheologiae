# Questão 87: Da remissão dos pecados veniais.
Em seguida devemos tratar da remissão dos pecados veniais.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se o pecado venial pode ser perdoado sem a penitência.
O primeiro discute-se assim. — Parece que o pecado venial pode ser perdoado sem a penitência.

1. — Pois, a verdadeira penitência exige, como se disse, que não só nos arrependamos do pecado
passado, mas também formemos o propósito de não mais pecar no futuro. Ora, sem esse propósito
ficam perdoados os pecados veniais; pois é certo que não podemos viver neste mundo sem cometermos
pecados veniais. Logo, os pecados veniais pedem ser perdoados sem penitência.

2. Demais. — Não há penitência sem a displicência atual dos pecados. Ora, os pecados veniais podem
ser perdoados sem que nos causem nenhuma displicência; assim, quem, durante o sono, fosse morto
por Cristo, entraria imediatamente no céu; o que não lhe seria possível se permanecesse em pecado
venial. Logo, os pecados veniais podem ser perdoados sem penitência.

3. Demais. — Os pecados veniais se opõem ao fervor da caridade, como se disse na Segunda Parte. Ora,
um contrário destrói o outro. Logo, pelo fervor da caridade, que pode existir sem a displicência atual do
pecado venial, se opera a remissão dos pecados veniais.
Mas, em contrário, Agostinho diz que há uma penitência quotidiana na Igreja pelos pecados veniais, a
qual seria inútil se sem penitência pudessem eles ser perdoados.

SOLUÇÃO. — O perdão da culpa como dissemos, se opera pela união do homem com Deus de quem, de
certo modo, ela o separa. Ora, essa separação é total pelo pecado mortal, e parcial pelo pecado venial.
Pois, pelo pecado mortal a nossa alma se separa completamente de Deus, porque agimos contra a
caridade; ao passo que o pecado venial retarda-nos o afeto, impedindo de aplicar-se prontamente a
Deus. Por onde, ambos esses pecados podem ser perdoados pela penitência, pois por ambos a vontade
se nos desordena pela imoderada conversão aos bens criados. Pois, assim como o pecado mortal não
pode ser remitido, enquanto a vontade adere ao pecado, assim também não o pode o pecado venial,
porquanto, permanecendo a causa, permanece o efeito. É necessária porém para a remissão do pecado
mortal uma perfeita penitência, que nos leva a detestar atualmente o pecado mortal cometido, o
quanto podemos, isto é, aplicando estudo em rememorar cada pecado mortal cometido para
detestarmos cada um de per si. Mas isto não é necessário para a remissão dos pecados veniais; não
bastando contudo a displicência habitual que temos, pelo hábito da caridade ou da virtude da
penitência. Porque então a caridade não sofreria o pecado venial, o que é evidentemente falso. Donde
resulta que é preciso uma certa displicência virtual; por exemplo, se o nosso afeto de modo nos leva
para Deus e as coisas divinas, que nos desagrade e nos pese ter cometido tudo o que nos retarde o
movimento para Deus, mesmo se nisso não pensemos atualmente. O que porém não basta para a
remissão do pecado mortal, senão quanto aos pecados esquecidos depois de um exame diligente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Constituídos em graça, podemos evitar todos os pecados
mortais e cada um em particular; também podemos evitar cada pecado venial de per si, mas não todos
como resulta do que dissemos na Segunda Parte. Por onde a penitência pelos pecados mortais requere
do pecador o propósito de se abster de todos os pecados mortais e de cada um em particular. Mas para
a penitência dos pecados veniais basta o propósito de se abster de cada um em particular, mas não de
todos, o que não sofre a fraqueza da nossa vida mortal. Deve porém ter o propósito de preparar-se para
diminuir os pecados veniais; do contrário correria o risco de regredir, por abandonar o desejo de
progredir ou de arredar os impedimentos ao avanço espiritual — que são pecados veniais.

RESPOSTA À SEGUNDA. — O sofrimento aceito por amor de Cristo tem força de batismo, como
dissemos. E por isso purifica de roda culpa venial e mortal, salvo se a nossa vontade estiver atualmente
presa ao pecado.

RESPOSTA À TERCEIRA. — O fervor da caridade virtualmente implica a displicência dos pecados veniais,
como dissemos.

## Art. 2 — Se para a remissão dos pecados veniais é necessária a infusão da graça.
O segundo discute-se assim. — Parece que para a remissão dos pecados veniais é necessária a infusão
da graça.

1. — Pois, não há efeito sem causa própria. Ora, a causa própria da remissão dos pecados é a graça, pois
não é pelos nossos próprios méritos que os pecados nos são perdoados. Donde o dizer o Apóstolo: Mas
Deus, que é rico em misericórdia, pela sua extremada caridade com que nos amou, ainda quando
estávamos mortos pelos pecados, nos deu vida juntamente em Cristo, por cuja graça sois salvos. Logo os
pecados veniais não se remi tem sem a infusão da graça.

2. Demais. — Os pecados veniais não se perdoam sem a penitência. Ora, pela penitência se infunde a
graça, como pelos outros sacramentos da Lei Nova. Logo, os pecados veniais não se perdoam sem a
infusão da graça.

3. Demais. — O pecado venial deixa uma certa mácula na alma. Ora a mácula não se apaga senão pela
graça, que é a brilho espiritual da alma. Logo, parece que os pecados veniais não são perdoados sem a
infusão da graça.
Mas, em contrário, o pecado venial sobreveniente não priva da graça nem a diminui, como
estabelecemos na Segunda Parte. Logo, pela mesma razão, para ser perdoado o pecado venial não é
necessária nova infusão da graça.

SOLUÇÃO. — Qualquer realidade fica destruída pela sua contrária. Ora, o pecado venial não é contrário
à graça habitual ou à caridade; apenas lhe retarda o ato, por nos prendermos demasiado aos bens
criados, embora sem contrariar a vontade de Deus, como estabelecemos na Segunda Parte. Por onde,
para ser apagado o pecado, não é necessária nenhuma graça habitual; mas basta, para a sua remissão
um certo movimento da graça ou da caridade. Mas nos que têm o uso do livre arbítrio, únicos
susceptíveis de pecado venial, não é possível a infusão da graça sem um movimento atual do livre
arbítrio levando para Deus e fazendo abandonar o pecado. Por onde, sempre que uma nova graça é
infundida, ficam remetidos os pecados veniais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Também a remissão dos pecados veniais é efeito da
graça pelo ato elícito que ela de novo produz; mas não por uma nova infusão na alma de alguma
disposição habitual.

RESPOSTA À SEGUNDA. — O pecado venial nunca é perdoado sem um certo ato da virtude de
penitência, explícito ou implícito, como dissemos. Mas esse pecado pode ser apagado sem o sacramento
da penitência ministrado formalmente pela absolvição do sacerdote, como dissemos. Donde, pois não
se segue que para a remissão do pecado venial seja necessária a infusão da graça, a qual, embora exista
em cada sacramento, não existe contudo em qualquer ato virtuoso.

RESPOSTA À TERCEIRA. — No corpo pode haver mancha, de dois modos — pela privação do que lhe
exige o esplendor da beleza, por exemplo, da cor conveniente ou da devida proporção dos membros; ou
pela aderência de um corpo estranho, como o lodo ou o pó, que lhe ofusca a beleza. Assim também a
alma pode ficar manchada pela privação do esplendor da graça em virtude de um pecado mortal; ou
pela inclinação desordenada do afeto para algum bem temporal, resultado do pecado venial. Donde,
para apagar a mancha do pecado mortal é necessária a infusão da graça; mas para apagar a do pecado
venial basta algum ato procedente da graça que remova a adesão desordenada aos bens temporais.

## Art. 3 — Se os pecados veniais ficam perdoados pela aspersão da água benta, pela bênção episcopal e práticas semelhantes.
O terceiro discute-se assim. — Parece que os pecados veniais não ficam perdoados pela aspersão da
água benta, pela bênção episcopal e práticas semelhantes.

1. — Pois, os pecados veniais não se perdoam sem a penitência, como se disse. Ora, a penitência, por si,
basta para a remissão dos pecados veniais. Logo, as práticas referidas em nada contribuem para a
remissão de tais pecados.

2. Demais. — Qualquer das práticas referidas tem a mesma relação com um pecado venial e com todos.
Se portanto uma delas apaga um pecado venial, resulta, pela mesma razão, que apaga a todos. E assim,
batendo no peito uma vez, fazendo uma vez aspersão de água benta, ficamos imunes de todos os
pecados veniais — o que é inadmissível.

3. Demais. — Os pecados veniais induzem o reato da pena temporal. Assim, o Apóstolo, falando daquele
que levanta sobre tal fundamento edifício de madeira, de feno e de palha, diz: O tal será salvo, se bem
desta maneira como por intervenção do fogo. Ora, essas práticas, pelas quais se diz que os pecados
veniais são perdoados, implicam uma pena mínima ou nula. Logo, não bastam para a plena remissão dos
pecados veniais.
Mas, em contrário, diz Agostinho, que pelos pecados leves batemos no peito e dizemos — Perdoai-nos
as nossas dívidas. Por onde, o bater no peito e a Oração Dominical causam a remissão dos pecados
veniais. E o mesmo se diga das outras práticas.

SOLUÇÃO. — Como dissemos, para a remissão do pecado venial não é necessária a infusão de nova
graça, mas basta um ato procedente da graça, pelo qual detestamos o pecado explicitamente, ou pelo
menos implicitamente, como quando nos entregamos com fervor a amar a Deus. E assim, por três
razões podem certas práticas causar a remissão dos pecados veniais. — Primeiro como meios pelos
quais se infunde a graça; pois, a infusão da graça apaga os pecados veniais, como dissemos. E deste
modo, pela Eucaristia e pela extrema unção, e universalmente por todos os pecados da Lei Nova, pelos
quais é conferida a graça, ficam perdoados os pecados veniais. — Segundo por serem essas práticas
acompanhadas de um certo movimento de detestação dos pecados. Assim, a confissão geral, o bater no
peito e a Oração Dominical contribuem para a remissão dos pecados veniais. Pois, na Oração Dominical
pedimos: Perdoai-nos as nossas dívidas. — Terceiro, em quanto implicam um certo movimento de
reverência para com Deus e para com as coisas divinas. E, assim, a bênção episcopal, a aspersão da água
benta, qualquer unção sacramental, a oração numa igreja consagrada e outras práticas semelhantes,
contribuem para a remissão dos pecados veniais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todas as práticas referidas causam a remissão dos
pecados veniais, enquanto inclinam a alma ao movimento da penitência, consistente em detestarmos o
pecado implícita ou explicitamente.

RESPOSTA À SEGUNDA. — Todas as práticas referidas, por si mesmas, obram a remissão de todos os
pecados veniais. Pode porém ficar impedida a remissão de certos pecados veniais, a que a nossa alma
atualmente adere; assim como a simulação impede as vezes o efeito do batismo.

RESPOSTA À TERCEIRA. — As práticas em questão apagam por certo a culpa dos pecados veniais, quer
em virtude de alguma satisfação, quer também em virtude da caridade, cujo movimento tais práticas
provocam. Mas, qualquer delas nem sempre apaga totalmente o reato da pena, porque então, quem
estivesse de todo isento do pecado mortal, pela aspersão da água benta tomaria logo o vôo para as
alturas. O reato da pena porém é perdoado por essas práticas conforme o fervor com que nos damos a
Deus, que se deixa mais ou menos mover pelos referidos meios.

## Art. 4 — Se o pecado venial pode ser remitido, sem que o mortal o seja.
O quarto discute-se assim. — Parece que o pecado venial pode ser remitido sem que o mortal o seja.

1. — Pois, aquilo do Evangelho — O que de vós outros está sem pecado seja o primeiro que a apedrejá-
la — diz uma Glosa: Todos esses estavam em pecado mortal; pois, os veniais lhes eram perdoados pelas
cerimônias da Lei. Logo, o pecado venial pode ser remitido sem que o mortal o seja.

2. Demais. — Para a remissão do pecado venial não é necessária a infusão da graça. Mas é necessária
para a remissão do pecado mortal. Logo, o pecado venial pode ser remitido sem que o mortal o seja.

3. Demais. — Mais dista um pecado venial de um mortal que de outro venial. Ora, um venial pode ser
perdoado sem o ser outro, como se disse. Logo, um pecado venial pode ser perdoado sem que o seja o
mortal.
Mas, em contrário, o Evangelho: Em verdade te digo que não sairás de lá, isto é, do cárcere, no qual o
pecado mortal mete o homem, até não pagares o último ceitil, que significa o pecado venial. Logo, o
pecado venial não pode ser perdoado sem que o seja também o mortal.

SOLUÇÃO. — Como dissemos o perdão de qualquer culpa nunca é possível senão em virtude da graça.
Pois, como diz o Apóstolo, a graça divina faz com que o pecado de um homem não lhe seja imputado
por Deus. O que a Glosa a esse lugar expõe como relativo ao pecado venial. Ora, quem vive em pecado
mortal está privado da graça de Deus. Por onde, nenhum pecado venial lhe pode ser perdoado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por pecados veniais se entendem, no lugar aduzido, as
irregularidades ou imundícies, que se contraiam em virtude da Lei.

RESPOSTA À SEGUNDA. — Embora para a remissão do pecado venial não seja necessária uma nova
infusão da graça habitual, é preciso porém algum ato da graça, de que não é susceptível quem está em
pecado mortal.

RESPOSTA À TERCEIRA. — O pecado venial não exclui totalmente a ação da graça, pela qual podem ser
perdoados todos os pecados veniais. Ao passo que o pecado mortal exclui totalmente o hábito da graça,
sem o qual não pode ser perdoado nenhum pecado — mortal ou venial. Logo, não há semelhança de
razão.