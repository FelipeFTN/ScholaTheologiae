# Questão 63: Do efeito dos sacramentos que é o caráter
Em seguida devemos tratar de outro efeito dos sacramentos que é o caráter. E nesta questão discutem-
se seis artigos:

## Art. 1 — Se os sacramentos imprimem algum caráter na alma.
O primeiro discute-se assim. — Parece que o sacramento não imprime nenhum caráter na alma.

1. — Pois, caráter significa um sinal de certo modo distintivo. Ora, a distinção entre os membros de
Cristo e os outros se faz pela predestinação eterna, que nada implica no predestinado, mas só em Deus
predestinante, como se estabeleceu na Primeira Parte. Assim, diz o Apóstolo: O fundamento de Deus
está firme, o qual tem este selo - o Senhor conhece aos que são dele. Logo, os sacramentos não
imprimem caráter na alma.

2. Demais. — O caráter é um sinal distintivo. Ora, o sinal, como diz Agostinho, apresenta uma espécie
aos sentidos para causar o conhecimento de outra coisa no intelecto. Ora, nada há na alma que
introduza alguma espécie nos sentidos. Logo, parece que na alma não imprimem os sacramentos
nenhum caráter.

3. Demais. — Assim como pelo sacramento da lei nova distingue-se o fiel do infiel, assim também pelos
da lei antiga. Ora, os sacramentos da lei antiga não imprimiam nenhum caráter na alma, por isso o
Apóstolo lhes chama justiça da carne. Logo parece que nem os sacramentos da lei antiga. Mas, em
contrário, o Apóstolo: O que nos ungiu é Deus o qual também nos selou e deu em nossos corações a
prenda do Espírito. Ora, o caráter nada mais importa senão um certo sinalamento. Logo, parece que
Deus com os seus sacramentos imprime em nós um caráter.

SOLUÇÃO. — Como do sobre dito se colhe, os sacramentos da lei nova se ordenam a dois fins: são
remédios contra os pecados e aperfeiçoam a alma no concernente ao culto de Deus segundo o rito da
vida cristã. Ora, todos os que se destinam a um determinado fim costumam ser para isso sinalados;
assim os soldados que eram adscritos à milícia antigamente costumavam ser marcados com certos
caracteres corpóreos, por serem destinados a um fim material, Ora, como os homens pelos sacramentos
são destinados ao fim espiritual de adorar a Deus, resulta por consequência que por eles os fieis são
sinalados por um certo caráter espiritual. Por isso diz Agostinho: Se o que não cumpre os seus deveres
militares, apesar de ter o caráter da milícia impresso no seu corpo, arrepende-se do seu procedimento e
se, cheio de medo, pedir a clemência do Imperador e derramando-se em súplicas e pedindo perdão,
começar a militar, porventura, tendo sido perdoado e estando em regra, vão – no privar do seu caráter
em vez de reconhecidamente o aprovarem? Ora, por acaso serão menos impressos os sacramentos
cristãos que essa nota material?

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os fiéis de Cristo são por certo destinados ao prêmio da
glória futura pelo sinal da predestinação divina. Mas são destinados aos atos convenientes à Igreja
presente por um certo sinal espiritual que lhes é impresso e que se chama caráter.

RESPOSTA À SEGUNDA. — O caráter impresso na alma tem natureza de sinal enquanto impresso por
um sacramento sensível; pois sabemos que nos foi impresso o caráter batismal por termos sidos lavados
sensivelmente pela água. Contudo, também pode chamar-se caráter ou sinal, por uma certa
semelhança, tudo o que torna um ser semelhante a outro, ou distingue um de outro, mesmo se não o
for sensivelmente. Assim Cristo é chamado figura ou caráter da substância paterna, pelo Apóstolo.

RESPOSTA À TERCEIRA. — Como dissemos, os sacramentos da lei antiga não tinham em si nenhuma
virtude espiritual para produzir algum efeito espiritual. Por isso, nesses sacramentos, não era necessário
nenhum caráter espiritual, mas bastava-lhe a circunscisão no corpo, a que o Apóstolo chama sinal.

## Art. 2 — Se o caráter é um poder espiritual.
O segundo discute-se assim. — Parece que o caráter não é um poder espiritual.

1. – Pois, caráter é o mesmo que figura; por isso no lugar em que o Apóstolo fala da figura da sua
substância no grego se lê, em lugar de figura caráter. Ora a figura pertence à quarta espécie de
qualidade; e assim difere do poder, pertencente à segunda espécie de qualidade. Logo, o caráter não é
um poder espiritual.

2. – Demais. — Dionísio diz: A divina beatitude recebe a participação de si o que busca a beatitude e
com o seu lume próprio, por um como sinal, permite-lhe a sua participação. E assim parece que o
caráter é um certo lume. Ora, o lume pertence antes à terceira espécie de qualidade. Logo, o caráter
não é um poder, considerado como pertencente à segunda espécie de qualidade.

3. Demais. — Certos definem o caráter assim: O caráter é o sinal santo da comunhão da fé e da santa
ordenação dado pelo hierarca. Ora, o sinal pertence ao gênero da relação, mas não ao gênero do poder.
Logo, o caráter não é um poder espiritual.

4. Demais. — O poder exerce a função de causa e de principio, como se lê em Aristóteles. Ora, o sinal,
que entra na definição do caráter, antes implica a noção de efeito. Logo o caráter não é um poder
espiritual.
Mas, em contrário, o Filósofo diz: Três elementos há na alma - a potência, o hábito e a paixão. Ora, o
caráter não é paixão porque a paixão logo passa e, ao contrário, o caráter é indelével, como a seguir se
dirá. Semelhantemente, também não é um hábito. Porque nenhum hábito há que possa ser usado tanto
para o bem como para o mal. Ora, o caráter pode sê-la de um e de outro modo, pois, certos usam bem
dele e outros, mal. O que não se dá com os hábitos, pois, do hábito da virtude ninguém pode usar mal, e
do hábito do mal ninguém pode usar bem. Logo, conclui-se que o caráter é uma potência.

SOLUÇÃO. — Como dissemos, os sacramentos da lei nova imprimem caráter, porque por eles se
destinam os homens ao culto de Deus segundo o rito da religião cristã. Por isso Dionísio, depois de ter
dito, que Deus por um certo sinal, concede a participação de si ao que recebe o batismo, acrescenta:
tornando-o divino e dispensado de bens divinos. Ora, o culto divino consiste ou em receber bens divinos
ou em comunicá-los aos outros. Ora, para ambas essas coisas é necessária uma potência; pois, para dar
alguma coisa a alguém é necessária uma potência ativa; e para receber é necessária a potência passiva.
Por isso o caráter implica uma certa potência espiritual ordenada às cousas do culto divino. - Mas,
devemos saber que essa potência espiritual é instrumental, como também já antes dissemos da virtude
existente nos sacramentos. Pois, ter o caráter do sacramento compete aos ministros de Deus, porque o
ministro se comporta como instrumento, no dizer do Filósofo. Por onde, assim como a virtude que têm
os sacramentos, não pertence essencialmente a um gênero, mas só por uma redução porque tem uma
existência emanada de outra e incompleta, assim também o caráter não pertence propriamente a
nenhum gênero ou espécie, mas se reduz à segunda espécie de qualidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. A figura é de certo modo uma terminação da quantidade.
Por isso, propriamente falando, só os seres materiais têm figura; os espirituais só a têm
metaforicamente. Ora, nenhum ser pertence a um gênero ou a uma espécie, senão pelo que dele se
predica propriamente. Por isso o caráter não pode pertencer à quarta espécie de qualidade, embora
certos o dissessem.

RESPOSTA À SEGUNDA. – A terceira espécie de qualidade só pertencem as paixões sensíveis ou as
qualidades sensíveis. Ora, o caráter não é um lume sensível. E por isso não pertence à terceira espécie
de qualidade, como certos disseram.

RESPOSTA À TERCEIRA. — A relação que implica o nome de sinal há de forçosamente ter algum
fundamento. Ora, a relação desse sinal, que é o caráter, não pode fundar-se imediatamente sobre a
essência da alma, porque então conviria naturalmente a toda alma. E por isso é necessário supor alguma
coisa na alma sobre o que se funde essa relação. E essa é a essência do caráter. Por onde, não é
necessário pertença ao gênero da relação, como o disseram certos.

RESPOSTA À QUARTA. — O caráter tem natureza de sinal por comparação com o sacramento sensível
pelo qual é impresso. Mas, em si mesmo considerado tem natureza de princípio, do modo já referido.

## Art. 3 — Se o caráter sacramental é o caráter de Cristo.
O terceiro discute-se assim. — Parece que o caráter sacramental não é o caráter de Cristo.

1. — Pois, diz o Apóstolo: Não entristeçais ao Espírito Santo de Deus, no qual estais selados. Ora, a
sinalação é implicada pelo nome mesmo de caráter. Logo, o caráter sacramental deve ser atribuído
antes ao Espírito Santo, que a Cristo.

2. Demais. — O caráter tem natureza de sinal. Ora, o sinal da graça é o conferido pelos sacramentos.
Mas a graça é infundida na alma por toda a Trindade, donde o dizer a Escritura: O Senhor dará a graça e
a glória. Logo, parece que o caráter sacramental não deve ser especialmente atribuído a Cristo.

3. Demais. — Quem recebe um caráter é para se distinguir dos outros. Ora, a distinção entre os santos e
os demais se faz pela caridade, que só distingue entre os filhos do reino e os filhos da perdição, no dizer
de Agostinho. Por isso, como refere à Escritura, diz-se dos filhos da perdição que têm o caráter da besta.
Ora, a caridade não é atribuída a Cristo, mas antes ao Espírito Santo conforme àquilo do Apóstolo: A
caridade de Deus está derramada em nossos corações pelo Espírito Santo, que nos foi dado. Ou ainda ao
Padre, conforme outro lugar do Apóstolo: A graça de Nosso Senhor Jesus Cristo e, a caridade de Deus.
Logo, parece que não se deve atribuir a Cristo o caráter sacramental.
Mas, em contrário, certos definem o caráter: O caráter é a distinção impressa pelo caráter eterno na
alma racional, segundo uma imagem que, sendo uma trindade criada, é o sinal da Trindade criadora e
conservadora, e que distingue, mediante o estado da fé, dos que não têm essa imagem. Ora, o caráter
eterno é Cristo mesmo, segundo aquilo do Apóstolo: O qual, sendo o resplendor da glória e a figura, ou
o caráter, da sua substância. Logo, parece que o caráter se deve propriamente atribuir a Cristo.

SOLUÇÃO. — Como do sobredito se infere o caráter é propriamente um sinal que marca alguém como
devendo ordenar-se a um certo fim. Assim, o dinheiro é marcado com um caráter para o fim das trocas;
e os soldados são marcados por um caráter, como destinados à milícia. Ora, um fiel é ordenado a um
duplo destino. - Primeiro e principalmente, para o gozo da glória. E para isso é marcado com o sinal da
graça, segundo aquilo da Escritura: Com um thau marca as testas dos homens que gemem e que se
doem. E noutro lugar: Não faças mal à terra nem ao mar, nem às árvores, até que assinalemos os servos
do nosso Deus nas suas testas. - Depois, cada fiel é destinado a receber ou a comunicar aos outros o
concernente ao culto de Deus. E a isso é propriamente destinado o caráter sacramental. Pois, todo o rito
da religião cristã deriva do sacerdócio de Cristo. Por onde, é manifesto que o caráter sacramental e
especialmente o caráter de Cristo, a cujo sacerdócio se assemelham os fiéis pelos caracteres
sacramentais, que outra causa não são senão umas participações do sacerdório de Cristo, derivadas do
próprio Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Apóstolo, no lugar aduzido, se refere ao sinalamento
pelo qual alguém é destinado à glória futura, conferida pela graça. O qual é atribuído ao Espírito Santo
enquanto Deus, movido de amor, confere-nos gratuitamente um dom, o que implica a graça; pois o
Espírito Santo é amor. Donde o dizer o Apóstolo: Há repartição de graças, mas um mesmo é o Espírito.

RESPOSTA À SEGUNDA. — O caráter sacramental é uma realidade, em respeito do sacramento exterior;
e é um sacramento, em respeito do efeito último. Por isso, de dois modos podemos fazer uma
atribuição ao caráter. - Primeiro, enquanto sacramento. E deste modo, é o sinal da graça invisível, que
confere. - De outro modo, levando em conta a idéia mesma do caráter. E então, um sinal que configura
a um ser principal, onde reside a autoria daquilo a que é alguém destinado. Assim, os soldados,
destinados à luta são marcados com os sinais do chefe, pelo que de certo modo, com ele se configuram.
E assim, os destinados ao culto cristão, cujo autor é Cristo, recebem o caráter pelo qual se configuram
com Cristo, a quem pois propriamente pertence o caráter.

RESPOSTA À TERCEIRA. — Pelo caráter se distingue uma pessoa de outra por comparação a algum fim a
que se ordena, ela que recebeu o caráter. Assim o dissemos a respeito do caráter militar, pelo qual,
relativamente à luta, se distingue o soldado do rei do soldado do inimigo. E semelhantemente, o caráter
dos fiéis é o pelo qual se distinguem, os fiéis de Cristo dos servos do diabo, quer em relação à vida
eterna, quer em relação ao culto da Igreja presente. E dessas finalidades a primeira resulta da caridade e
da graça, como o diz com procedência a objeção. E a segunda, do caráter sacramental. Por onde e ao
contrário, pelo caráter da besta podemos entender: ou a malícia obstinada, pela qual certos são
destinados à pena eterna; ou a prática de um culto ilícito.

## Art. 4 — Se o caráter está nas potências da alma como no seu sujeito.
O quarto discute-se assim. — Parece que o caráter não está nas potências da alma como no seu
sujeito.

1. — Pois, caráter se chama uma disposição para a graça. Ora, a graça tem na essência da alma o seu
sujeito, como se disse na Segunda Parte. Logo, parece que o caráter está na essência da alma e não nas
potências.

2. Demais. — Uma potência da alma não pode ser sujeito senão de um hábito ou de uma disposição.
Ora, o caráter, como se disse, não é hábito nem disposição, mas antes, uma potência, cujo sujeito não é
senão a essência da alma. Logo, parece que o caráter não tem o seu sujeito na potência da alma, mas
antes, na essência dela.

3. Demais. — As potências da alma racional se dividem em cognitivas e apetitivas. Ora, não se pode
dizer que o caráter esteja somente na potência cognitiva, nem só também na potência apetitiva; pois
não se ordena nem só a conhecer nem só a apetir. E também não se pode dizer que esteja em ambas,
porque um mesmo acidente não pode existir em diversos sujeitos. Logo, parece que o caráter não tem
na potência da alma, mas antes na essência dela o seu sujeito.
Mas, em contrário, na definição do caráter anteriormente citada, o caráter é impresso na alma recional
segundo a imagem. Ora, a imagem da Trindade na alma se funda nas potências Logo, o caráter existe
nas potências da alma.

SOLUÇÃO. — Como dissemos, o caráter é um sinal que marca uma alma para receber ou comunicar aos
outros o concernente ao culto divino. Ora, o culto divino consiste em certos atos. E a agir propriamente
se ordenam as potências da alma, como a essência se ordena a existir. Logo, o caráter tem o seu sujeito,
não na essência da alma, mas na sua potência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O sujeito é atribuído a um acidente relativamente àquilo
a que ele proximamente dispõe e não relativamente ao que dispõe remota ou indiretamente. Ora, o
caráter direta e proximamente dispõe a alma à prática do concernente ao culto divino. E como essa não
se faz convenientemente sem o auxílio da graça, porque, no dizer do Evangelho, em espírito e verdade é
que devem adorar a Deus os que o adoram, por consequência a divina liberalidade confere a graça aos
que recebem o caráter, a fim de cumprirem bem aquilo a que são destinados. Por onde ao caráter
devemos antes atribuir um sujeito no ponto de vista dos atos concernentes ao culto divino, que no
ponto de vista da graça.

RESPOSTA À SEGUNDA. — A essência da alma é o sujeito da potência natural, procedente dos princípios
da essência. Ora, tal potência não é o caráter, que é uma certa potência espiritual de procedência
extrínseca. Por onde, assim como a essência da alma, da qual se origina a vida natural do homem, se
aperfeiçoa pela graça, pela qual a alma vive espiritualmente, assim também a potência natural da alma
se aperfeiçoa pela potência espiritual, que é o caráter. Quanto ao hábito e à disposição, pertencem à
potência da alma, porque se ordenam aos atos, dos quais as potências são os princípios. E pela mesma
razão, tudo o que se ordena ao ato deve atribuir-se à potência.

RESPOSTA À TERCEIRA. — Como dissemos, o caráter se ordena às coisas do culto divino. E este é uma
manifestação da fé mediante sinais exteriores. Por onde, é necessário que o caráter exista na potência
cognitiva da alma, onde reside a fé.

## Art. 5 — Se o caráter existe na alma indelevelmente.
O quinto discute-se assim. — Parece que o caráter não existe na alma indelevelmente.

1. — Pois, quanto mais perfeito é um acidente tanto mais firme é a sua inerência. Ora, a graça é mais
perfeita que o caráter, porque este se ordena àquela como a um fim ulterior. Mas a graça se perde pelo
pecado. Logo, com muito maior razão o caráter.

2. Demais. — O caráter destina uma pessoa ao culto divino, como se disse. Ora, certos abandonam o
culto divino e, apostatando da fé, passam a um culto contrário. Logo, parece que esses tais perdem o
caráter sacramental.

3. Demais. — Desaparecido o fim, deve também desaparecer o meio que, aliás, permaneceria em vão.
Assim, depois da ressurreição não haverá matrimônio porque terá cessado a geração, a que se o
matrimônio ordena. Ora, o culto externo, a que se ordena o caráter, não permaneceria na pátria, onde
nada haverá de figurado, sendo tudo a nua verdade. Logo, o caráter sacramental não permanece
perpetuamente na alma. E, portanto não existe nela de modo indelével.
Mas, em contrário, diz Agostinho: Os sacramentos cristãos não se imprimem menos que a nota material
da milícia. Ora, o caráter militar não é tirado, mas é reconhecido e aprovado naquele que depois da
culpa, merece o perdão do imperador. Logo, nem o caráter sacramental pode ser delido.

SOLUÇÃO. — Como dissemos, o caráter sacramental é uma certa participação do sacerdócio de Cristo
nos seus fiéis. De modo que, assim como Cristo tem o pleno poder do sacerdócio espiritual, assim os
fiéis com ele se configurem participando de alguma sorte do poder espiritual com respeito aos
sacramentos e ao concernente ao culto divino. E também por isto não compete a Cristo ter caráter, mas
o poder do seu sacerdócio está para o caráter como o pleno e perfeito para qualquer participação dele.
Ora, o sacerdócio de Cristo é eterno, segundo aquilo da Escritura: Tu és sacerdote em eterno segundo a
ordem de Melquisedeque. Donde vem que toda santificação causada pelo seu sacerdócio é perpétua,
enquanto permanece o ser consagrado. O que é patente mesmo com as causas inanimadas; assim, a
consagração de uma igreja ou de um altar permanece sempre enquanto não forem destruídos. Ora,
sendo a alma, na sua parte intelectual, o sujeito do caráter, na qual reside a fé, como dissemos, é
manifesto que assim como o intelecto é perpétuo e incorruptível, assim o caráter permanece
indelevelmente na alma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De um modo existe na alma a graça e de outro o caráter.
Assim, a graça está na alma como uma forma que tem nela o seu ser completo; ao passo que o caráter
nela está, como uma virtude instrumental, segundo dissemos. Ora, uma forma completa está no sujeito
segundo a condição deste. E sendo a alma mutável pelo seu livre arbítrio, enquanto permanece nesta
vida, resulta por consequência que a graça está na alma de modo mudável. A virtude instrumental,
porém mais se funda na condição do agente principal. Por onde, o caráter está na alma de maneira
indelével, não por perfeição sua, mas pela perfeição do sacerdócio de Cristo, do qual deriva como uma
virtude instrumental.

RESPOSTA À SEGUNDA. — Agostinho diz no mesmo lugar: Sabemos que nem nos apóstatas fica delido o
batismo; pois, quando voltam pela penitência, não se lhes renova e por isso julgamos que não o podem
perder. E a razão é que o caráter é uma virtude instrumental, como se disse. Ora, a natureza do
instrumento está em ser movido por outro agente, e não em mover-se a si mesmo o que é próprio da
vontade. Por onde, embora a vontade se mova para o contrário, o caráter não desaparece, por causa da
imobilidade do motor principal.

RESPOSTA À TERCEIRA. — Embora depois desta vida desapareça o culto externo, permanece contudo o
fim desse culto. E portanto, após esta vida, permanece o caráter - nos bons, para a glória deles; e para
sua ignomínia, nos maus. Assim como também o caráter militar permanece nos soldados depois de
alcançada a vitória - nos que venceram, para glória; e nos vencidos, para pena.

## Art. 6 — Se todos os sacramentos da lei nova imprimem caráter.
O sexto discute-se assim. — Parece que todos os sacramentos da lei nova imprimem caráter.

1. — Pois, todos os sacramentos da lei nova tornam participante do sacerdócio de Cristo. Ora, o caráter
sacramental outra causa não é senão a participação do sacerdócio de Cristo, como se disse. Logo,
parece que todos os sacramentos da lei nova imprimem caráter.

2. Demais. — O caráter está para a alma onde existe como a consagração para as coisas consagradas.
Ora, por qualquer sacramento da lei nova o homem recebe a graça santificante como se disse. Logo,
parece que qualquer sacramento da lei nova imprime caráter.

3. Demais. — O caráter em uma parte material é um sacramento. Ora, em qualquer sacramento da lei
nova há uma parte que é somente material e outra que somente é sacramento, e ainda outra que é
material e sacramento. Logo, qualquer sacramento da lei nova imprime caráter.
Mas, em contrário, os sacramentos que imprimem caráter não se reiteram, por ser o caráter indelével,
como se disse. Ora, certos sacramentos se reiteram, como é o caso da penitência e do matrimônio. Logo
nem todos sacramentos imprimem caráter.

SOLUÇÃO. — Como dissemos, os sacramentos da lei nova a dois fins se ordenam, a saber, a serem
remédio do pecado e ao culto divino. Pois, é comum a todos os sacramentos o serem remédios contra o
pecado, porque conferem a graça. Mas, nem todos se ordenam diretamente ao culto divino, como
claramente o mostra a penitência, pela qual nos livramos do pecado; pois nada de novo nos confere
pertinente ao culto divino, mas nos restitui ao primeiro estado.
Pode, porém um sacramento respeitar ao culto divino de três modos: atualmente e em si mesmo, ou
como de agente ou como recipiente - A modo de ação em si mesma considerada concerne ao culto
divino a Eucaristia, na qual principalmente esse culto consiste, enquanto ela é um sacrifício da Igreja. E
esse sacramento não imprime caráter porque não ordena o homem à nada de ulterior, que deva ser
feito ou recebido, pois, antes é o fim e a consumação de todos os sacramentos, como diz Dionísio.
Porque em si mesmo contém a Cristo, em quem não existe caráter, mas é a plenitude total do
sacerdócio. - Mas, aos que devem agir ministrando os sacramentos concerne o sacramento da ordem;
pois, por esse sacramento são destinados certos a comunicar os sacramentos aos outros. - Enfim, aos
que recebem respeita o sacramento do batismo, porque confere ao homem o poder de receber os
outros sacramentos da Igreja; por isso se chama o batismo a porta dos sacramentos. Ao mesmo fim
também de certo modo se ordena a confirmação, como em seu lugar se dirá. - E assim esses três
sacramentos imprimem caráter, a saber, o batismo, a confirmação e a ordem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todos os sacramentos tornam o homem participante do
sacerdócio de Cristo, porque recebe assim um certo, efeito dele. Mas nem por todos os sacramentos
somos destinados a fazer alguma coisa ou a receber o que pertença ao culto do sacerdócio de Cristo. O
que é necessário para o sacramento imprimir caráter.

RESPOSTA À SEGUNDA. — Por todos os sacramentos se santifica o homem, porque a santidade implica
a purificação do pecado, resultante da graça. Mas especialmente por certos sacramentos, que
imprimem caráter, o homem se santifica por uma certa consagração, como destinado ao culto divino.
Assim também dizemos que as coisas inanimadas santificam, enquanto destinadas ao culto divino.

RESPOSTA À TERCEIRA. — Embora o caráter implique uma coisa material e seja um sacramento, nem
por isso tudo o que é coisa material e sacramento há de ser caráter. O que seja, porém a coisa material
e o sacramento, diremos quando tratarmos dos outros sacramentos (nos lugares próprios).