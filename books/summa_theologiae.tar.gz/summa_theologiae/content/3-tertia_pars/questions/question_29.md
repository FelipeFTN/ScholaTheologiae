# Questão 29: Dos desposórios da Mãe de Deus
Em seguida devemos tratar dos desposórios da Mãe de Deus; e nesta questão discutem-se dois artigos:

## Art. 1 — Se Cristo devia nascer de uma virgem esposada.
O primeiro discute-se assim. — Parece que Cristo não devia nascer de uma virgem esposada.

1. — Pois, os desposórios se ordenam a cópula carnal. Ora, a Mãe de Deus não queria jamais usar da
cópula carnal, que iria contra a virgindade do seu coração. Logo, não devia ser esposada.

2. Demais. — Que Cristo nascesse de uma virgem foi milagre. Donde o dizer Agostinho: Foi ao poder
mesmo de Deus que aprouve a fazer saírem. os membros de uma criança através do seio virginal de sua
Mãe inviolada, como lhe aprouverá mais tarde fazer entrar os membros de um homem feito através de
portas fechadas. Se se procura aqui uma razão, desvanece-se o milagre; se se pede um exemplo, nada
mais tem de singular. Ora, os milagres feitos para confirmar a fé devem ser manifestos. Logo, como os
desposórios obumbraram esse milagre, parece não foi conveniente que Cristo nascesse de uma
desposada.

3. Demais. — Inácio Mártir, como refere Jerônimo, assinalou como causa aos desposórios da Mãe de
Deus, que o seu parto fosse oculto ao demônio, de modo a ficar este pensando que ele foi gerado, não
por uma virgem, mas de uma casada. Quer porque o diabo com a perspicácia dos seus sentidos conhece
o que se realiza materialmente. Quer também porque, depois, por muitos sinais evidentes, os demônios
de certo modo conheceram a Cristo. Donde o dizer o Evangelho, que um homem possesso do espírito
imundo gritava dizendo: Que tens tu conosco, Jesus Nazareno? Vieste a perder-nos? Bem sei quem és:
que és o Santo de Deus. Logo, parece não foi conveniente que a Mãe de Deus fosse desposada.

4. Demais. — Jerônimo assinala outra razão: a fim de que a Mãe de Deus não fosse lapidada pelos
Judeus como adúltera. Ora, essa razão nada vale; pois, se não fosse desposada não podia ser condenada
como adúltera. Logo, parece não era racional que Cristo tivesse nascido de uma desposada.
Mas, em contrário, o Evangelho: Estando já Maria, sua mãe, desposada com José. E noutro lugar: Foi
enviado o anjo Gabriel à Virgem Maria desposada com um varão que se chamava José.

SOLUÇÃO. — Era conveniente que Cristo nascesse de uma virgem casada: quer por causa dele próprio,
quer por causa da mãe, quer também por causa de nós.
Por causa do próprio Cristo, por quatro razões. — Primeiro, para que não fosse rejeitado dos infiéis,
como ilegítimo de nascimento. Donde o dizer Ambrósio: Que se poderia censurar aos Judeus e a
Herodes se tivessem perseguido a quem nasceu de um adultério? — Segundo, para que, ao modo
acostumado, fosse descrita a sua genealogia pela linha paterna. Por isso diz Ambrósio: Quem veio ao
século deve ser descrito ao modo do século. Pois, no Senado e nas outras assembleias, procura-se um
varão a quem caibam as honras devidas a sua família. E o mesmo costume testemunham as Escrituras,
que sempre buscam a origem viril. — Terceiro, em defesa do menino nascido: para o diabo não suscitar
mais violentas ciladas contra ele. Por isso diz Inácio, que a Virgem foi desposada para que o seu parto
ficasse oculto ao diabo. — Quarto, para que fosse se educado por José. Por isso este foi chamado seu
pai, quase o educador.
Foi também conveniente relativamente à Virgem. — Primeiro, porque assim ficou imune da pena, isto é,
para que não fosse lapidada pelos Judeus, como adúltera. — Segundo, para que assim ficasse livre da
infâmia. Donde o dizer Ambrósio: Foi desposada para não ser marcada com a infâmia de uma virgindade
profanada, quando a gravidez pudesse ser sinal da corrupção. — Terceiro, para que José lhe prestasse o
seu ministério, como diz Jerônimo.
Também foi conveniente relativamente a nós. — Primeiro, porque pelo testemunho de José ficou
comprovado o nascimento de Cristo, de uma virgem. — Donde o dizer Ambrósio: O testemunho do
marido é o melhor testemunho do pudor da mulher; pois se não tivesse conhecido o mistério, o marido
é quem teria maior direito a se afligir com a injúria e vingar o opróbrio. — Segundo, porque as palavras
mesmas da Virgem se tornavam mais dignas de crédito quando afirmava a sua virgindade. Por isso diz
Ambrósio: A fé nas palavras de Maria é mais firme, que remove as causas de mentira. Se tivesse ficado
grávida, sem ser casada, parecia querer, mentirosamente, esconder a sua culpa. Ao passo que casada,
nenhum motivo tinha para mentir, pois, o prêmio do casamento e a glória das núpcias é, para as
mulheres, o parto. E essas duas razões concernem à firmeza da nossa fé. — Terceiro, para que não
tivessem desculpa as virgens que, por incautela, não evitam a infâmia. Por isso, diz Ambrósio: Não
convinha deixar às virgens, que vivem com má reputação, pudessem velar-se com a escusa de também a
Mãe do Senhor ter tido uma semelhante reputação. — Quarto, porque os desposórios da Virgem são o
símbolo da Igreja universal, que, sendo virgem, desposou contudo um esposo, o Cristo, como diz
Agostinho. — Pode-se ainda aduzir uma quinta razão, a saber, que a Mãe do Senhor foi casada e virgem,
porque na sua pessoa, é honrada tanto a virgindade como o matrimônio, contra os heréticos que
detramem aquela e este.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Devemos crer que foi por uma familiar inspiração do
Espírito Santo que a Santa Virgem. Mãe de Deus quis ser desposada. Confiando no divino auxílio, que
nunca haveria de usar da cópula carnal; contudo, cometeu essa matéria ao divino arbítrio. Por isso,
nenhum detrimento sofreu na sua virgindade.

RESPOSTA À SEGUNDA. — Como diz Ambrósio, o Senhor preferiu que certos duvidassem antes da sua
origem que do pudor de sua mãe. Pois, sabia quão delicado é o pudor de uma virgem e de quanto
resguardo precisa a sua reputação; nem pensava que a fé na sua origem precisasse defender-se em
detrimento de sua mãe. — Devemos porém saber que em certos milagres de Deus devemos ter fé,
como. o milagre do parto virginal, da ressurreição do Senhor e também o do Sacramento do Altar. Por
isso o Senhor quis que esses mistérios fossem mais ocultos, para que fosse mais meritória a fé neles. —
Mas, outros milagres servem para comprovação da fé. E esses devem ser mais manifestos.

RESPOSTA À TERCEIRA. — Como diz Agostinho, o diabo pode muitas coisas em virtude da sua natureza,
que contudo o poder divino lhe impede. E, assim, podemos dizer que em virtude da sua natureza, o
diabo podia saber que a Mãe de Deus não tinha se corrompido, mas era virgem; mas Deus lhe proibiu
conhecer o modo do parto divino. — Nem obsta que depois o diabo de certo modo conhecesse, que
esse parto fora o do Filho de Deus; porque já era o tempo de Cristo manifestar o seu poder contra ele e
sofrer a perseguição por ele concitada. Mas, durante a infância, era preciso impedir a malícia do diabo; a
fim de que não o perseguisse mais cruelmente, numa idade em que Cristo não determinara que
houvesse de sofrer nem de manifestar o seu poder, mas em que se mostrava semelhante a todas as
mais crianças. Por isso o Papa Leão diz: Os Magos viram a Jesus pequeno de corpo, necessitado do
socorro alheio, incapaz de falar e em nada diferente do comum à infância humana. - Ambrósio porém
parece ter em conta sobretudo os adeptos do diabo. Pois, depois de ter proposto a razão, do engano do
príncipe do mundo, acrescenta: Contudo, esse mistério enganou sobretudo os príncipes deste mundo.
Pois, embora a malícia dos demônios também facilmente depreenda as coisas ocultas, contudo as que
se ocupam com as vaidades da século não podem saber as coisas divinas.

RESPOSTA À QUARTA. — Pela condenação de adultério eram lapidadas não só as já desposadas ou
casadas, mas também as que eram conservadas como virgens na casa paterna para casarem um dia. Por
isso diz Escritura: Se a moça não se achou virgem, os habitantes da cidade a apedrejarão e morrerá;
porque cometeu um crime detestável em Israel, tenda caído em fornicação em casa de seu pai. — Ou
podemos dizer, segundo certos, que a Santa Virgem era da estirpe ou da parentela de Aarão, sendo por
isso cognata de Isabel, como diz o Evangelho. Ora, uma virgem de raça sacerdotal se cometia estupro
era condenada à morte, como se lê na Escritura: Se a filha de um sacerdote apanhada em estupro e
desonrar o nome de seu pai, será entregue às chamas. - Mas certos referem as palavras de Jerônimo ao
apedrejamento por infâmia.

## Art. 2 — Se entre Maria e José houve verdadeiro matrimônio.
O segundo discute-se assim. — Parece que entre Maria e José não houve verdadeiro matrimônio.

1. — Pois, diz Jerônimo, que José foi guarda de Maria, antes que seu marido. Ora, se entre eles tivesse
havido verdadeiro matrimônio, José teria sido verdadeiramente seu marido. Logo, parece que não
houve verdadeiro matrimônio entre Maria e José.

2. Demais. — Aquilo do Evangelho – Jacó gerou a José, esposo de Maria – diz Jerônimo: Quando ouvires
o nome de esposo, não vás logo pensar que se trate de núpcias; mas lembra-te que as Escrituras
costumam chamar aos noivos, esposos e as noivas, esposas. Ora, o verdadeiro matrimônio não são os
esponsais, mas as núpcias. Logo, não houve verdadeiro matrimônio entre a Santa Virgem e José.

3. Demais. — O Evangelho diz: José seu esposo, como era justo, não queria infamá-la, isto é, levá-la para
sua casa para com ela coabitar habitualmente; mas resolveu deixá-la secretamente, isto é, transferir o
tempo das núpcias, como expõe Remígio. Logo, parece que, antes de celebradas as núpcias, ainda não
havia verdadeiro casamento; sobretudo porque, depois de contraído o matrimônio, a ninguém é lícito
abandonar a mulher.
Mas, em contrário, diz Agostinho: Não devemos crer que, segundo o Evangelista, José tivesse recusado
receber Maria em casamento, a pretexto que ela teria, como virgem, dado à luz Cristo, sem o seu
concurso. Mas esse exemplo prova claramente aos fiéis casados, que podem ser verdadeiros esposos e
merecer tal nome, ao mesmo tempo que guardam a promessa de recíproca continência, sem ter
comércio conjugal.

SOLUÇÃO. — Chama-se verdadeiro matrimônio ou casamento o que realiza a sua perfeição. Ora, dupla
pode ser a perfeição de uma coisa: primária e secundária. A perfeição primária de uma coisa consiste na
sua forma, donde tira a sua espécie. A perfeição secundária consiste na sua operação, pela qual de certo
modo atinge o seu fim. Ora, a forma do matrimônio consiste numa certa e indivisível conjunção das
almas, pela qual cada cônjuge está obrigado a conservar uma fé íntegra para com o outro. Quanto ao
fim do matrimônio, é a geração e a educação da prole; e esse é atingido, primeiramente, pelo concúbito
conjugal; e, secundariamente, pela cooperação do homem e da mulher, que mutuamente se ajudam,
para a manutenção dos filhos.
Assim, pois, devemos dizer, quanto à primeira perfeição, que houve matrimônio absolutamente
verdadeiro entre a Virgem Mãe de Deus e José. Pois, ambos consentiram na convivência conjugal; mas
não expressamente, na cópula carnal, senão sob a condição, se isso aprouvesse a Deus, por isso, o Anjo
chama a Maria esposa de José, quando lhe disse a este: Não temas receber a Maria, tua mulher.
Expondo o que, diz Agostinho: Chama-lhe esposa, pela fé primeira dos desposórios, aquela que jamais
conhecera nem nunca haveria de conhecer pelo concúbito. — Quanto porém à segunda perfeição, pelo
ato do matrimônio, se a referirmos ao concúbito carnal, gerador dos filhos, então não se consumou o
matrimônio entre José e Maria. Donde o dizer de Ambrósio: Não te perturbes com o chamar
frequentemente a Escritura a Maria de esposa; pois, a celebração do casamento não implica em perda
da virgindade, sendo apenas a testificação das núpcias. - Contudo, o matrimônio em questão foi
também perfeito quanto à educação da prole. Por isso diz Agostinho: Os pais de Cristo tiveram o bem
completo das núpcias – a prole, a fé e o sacramento. Pela prole, significamos o próprio Senhor Jesus;
pela fé, a ausência de todo adultério; pelo sacramento, a não existência do divórcio. Só não houve o
concúbito nupcial.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Jerônimo, no lugar citado, se refere ao marido, quanto
ao ato da consumação do matrimônio.

RESPOSTA À SEGUNDA. — Jerônimo chama às núpcias concúbito nupcial.

RESPOSTA À TERCEIRA. — Como diz Crisóstomo, a Santa Virgem quando desposou a José já lhe habitava
a casa. Pois, se a concepção de uma mulher, na casa de seu marido, é considerada regular, é suspeita a
da que concebeu fora de casa. Por isso, não teria sido suficientemente acautelada a reputação da Santa
Virgem só pelo fato de ter casado, sem que estivesse habitando no domicílio conjugal. Por onde, a
expressão — não queria levá-la para casa — entende-se melhor como significando que não queria
difamá-la em público, do que como significativa do ato de levá-la para a casa. Por isso o Evangelista
acrescenta, que resolveu deixá-la secretamente. Embora porém estivesse habitando a casa de José, pela
fé primeira dos desposórios, antes ainda de celebradas solenemente as núpcias; por causa do que,
também ainda não tinha tido comércio carnal. Por isso, como ensina Crisóstomo, o Evangelista não disse
– Antes de ter sido levada para a casa do esposo — pois já lhe habitava a casa. Porque era costume
entre os antigos que a noiva habitasse a casa do noivo. Donde o ter também dito o Anjo: Não temas
receber a Maria tua mulher, isto é, não temas celebrar núpcias solenes com ela. - Embora outros digam,
que ainda não habitava a casa de José, mas era somente noiva. Mas, a anterior explicação melhor
concorda com o Evangelho.