# Questão 85: Da penitência enquanto virtude.
Em seguida devemos considerar a penitência enquanto virtude.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se a penitência é uma virtude.
O primeiro discute-se assim. — Parece que a penitência não é uma virtude.

1. — Pois, a penitência é um sacramento enumerado entre os demais sacramentos; como do sobredito
se colhe. Ora, nenhum outro sacramento é virtude. Logo, nem a penitência o é.

2. Demais. — Segundo o Filósofo, a vergonha não é virtude, tanto por ser uma paixão acompanhada de
alteração corpórea, como também por não ser uma disposição de um ser em estado de perfeição; pois,
tem por objeto atos vergonhosos, que não pratica o homem virtuoso. Ora, semelhantemente, a
penitência é uma paixão acompanhada de alteração corpórea, a saber, as lágrimas; pois, como diz
Gregório, fazer penitência é chorar os pecados passados. E também a penitência tem por objeto atos
vergonhosos, isto é, os pecados, que um homem virtuoso não pratica. Logo, a penitência não é uma
virtude.

3. Demais. — Segundo o Filósofo, ninguém que seja virtuoso é estulto. Ora, parece estulto chorar o
pecado cometido e passado, que não pode deixar de ser o que é o que contudo constitui a penitência.
Logo, a penitência não é virtude.
Mas, em contrário, os preceitos da lei têm por objeto os atos virtuosos; pois, o fim do legislador é tornar
os cidadãos virtuosos, como diz Aristóteles. Ora, a lei divina preceitua a penitência, segundo aquilo do
Evangelho - Fazei penitência, etc. Logo, a penitência é uma virtude.

SOLUÇÃO. — Como do sobredito resulta, a penitência tem por objeto a dor de um pecado que
anteriormente cometemos. Ora, como já dissemos a dor ou a tristeza tem duplo sentido. - Num, é uma
das paixões do apetite sensitivo. E, por aí, a penitência não é virtude, mas paixão. Noutro sentido, ela
afeta a vontade; e então supõe uma certa eleição. E esta, sendo reta, necessariamente a penitência é
um ato de virtude; pois, como diz Aristóteles, a virtude é um hábito eletivo segundo a razão reta. Ora, a
razão reta exige que lamentemos o que devemos lamentar. E isso se dá com a penitência de que agora
tratamos; pois, o penitente se entrega a uma dor moderada dos pecados passados, com a intenção de
não tornar a os cometer. Por onde é manifesto, que a penitência, no caso vertente, ou é virtude, ou um
ato de virtude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como dissemos, os atos humanos constituem a matéria
da penitência; o que não se dá com o batismo nem com a confirmação. Por onde, sendo a virtude o
princípio de determinados atos, a penitência, mais que o batismo ou a confirmação, é uma virtude, ou é
acompanhada desta.

RESPOSTA À SEGUNDA. — A penitência, como paixão, não é virtude, como dissemos. Como tal, é
acompanhada de alteração corporal. Mas é virtude enquanto li, vontade se decide fundada numa
eleição reta. - O que porém podemos dizer, antes, da penitência, que da vergonha. Pois, a vergonha tem
por objeto um ato vergonhoso presente, por causa do qual tememos a confusão, ao passo que a
penitência, um ato passado. Ora, é contra a perfeição da virtude o sermos o autor de um ato
vergonhoso presente do qual devamos nos envergonhar. Mas não é contra a perfeição da virtude o
termos cometidos, antes, atos vergonhosos de que devamos mais tarde fazer penitência, quando, de
viciosos, passarmos a ser virtuosos.

RESPOSTA À TERCEIRA. — Lamentarmos o que já cometemos com a intenção de envidar esforços para
que deixe de ser o que foi feito, seria estulto. Ora, tal não é a intenção do penitente. Pois, a sua dor é
uma displicência ou reprovação do fato passado com a intenção de lhe evitar a conseqüência, a saber, a
ofensa a Deus e o reato da pena. E isto não é estulto.

## Art. 2 — Se a penitência é uma virtude especial.
O segundo discute-se assim. — Parece que a penitência não é uma virtude especial.

1. — Pois, a mesma razão que nos leva a nos comprazermos com os bons atos anteriormente
praticados, faz-nos lamentar os males perpetrados. Ora, comprazermo-nos com o bem anteriormente
feito não é uma virtude especial; mas, um afeto louvável, proveniente da caridade, como está claro em
Agostinho. E por isso também o Apóstolo diz: A caridade não folga com a injustiça, mas folga com a
verdade. Logo, pela mesma razão, nem a penitência, que é a dor dos pecados passados, é uma virtude
especial; senão um afeto proveniente da caridade.

2. Demais. — Toda virtude especial tem matéria especial; pois, os hábitos se distinguem pelos Pactos; e
os atos, pelos seus objetos. Ora, a penitência não tem matéria especial; pois, a sua matéria são os
pecados passados, sejam de que natureza forem. Logo, a penitência não é uma virtude especial.

3. Demais. — Nada é expulso senão pelo seu contrário. Ora, a penitência expulsa todos os pecados.
Logo, encontra. todos os pecados. Portanto, não é uma virtude especial.
Mas, em contrário, é matéria especial de um preceito de lei, como se estabeleceu.

SOLUÇÃO. — Como dissemos na Segunda Parte, as espécies de hábitos se distinguem pelas espécies dos
atos; portanto, a um ato louvável de uma determinada espécie necessariamente corresponde um
especial hábito virtuoso. Ora, é manifesto que a penitência constitui um ato louvável de natureza
especial, consistente no estudo posto em destruir o pecado passado, enquanto ofensa a Deus; o que
não é da natureza de nenhuma outra virtude. Logo e necessariamente devemos considerar a penitência
como uma virtude especial.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um ato pode derivar da caridade, de dois modos. -
Primeiro, como elícito dela. E um tal ato virtuoso não supõe nenhuma virtude além da caridade; tal o
ato de amarmos bem e nos comprazermos nele, e o de nos entristecermos com o seu oposto. - De outro
modo, um ato pode proceder da caridade como imperado por ela. E assim, como ela impera sobre todas
as virtudes, como ordenando-as para o seu fim, o ato procedente da caridade pode também pertencer a
uma virtude especial. - Se, pois, no ato do penitente considerarmos só a displicência do pecado passado,
procede imediatamente da caridade, assim como o ato de nos comprazermos com o bem passado. Mas,
a intenção de pôr estudo em delir o pecado passado requer uma virtude especial dependente da
caridade.

RESPOSTA À SEGUNDA. — A penitência tem por certo e realmente matéria geral, enquanto respeita
todos os pecados; mas sob uma razão especial, enquanto esses atos podem ser emendados pelo ato do
homem cooperando com Deus para a sua justificação.

RESPOSTA À TERCEIRA. — Qualquer virtude especial expulsa o hábito do vício oposto; assim como a
brancura expulsa a negrura, de um mesmo sujeito. Mas a penitência expulsa efetivamente todos os
pecados, contribuindo para a destruição deles, enquanto susceptíveis de ser perdoado pela graça divina,
com a cooperação do homem. Donde não se segue que seja uma virtude especial.

## Art. 3 — Se a virtude da penitência é uma espécie de justiça.
O terceiro discute-se assim. — Parece que a virtude da penitência não é uma espécie de justiça.

1. — Pois, a justiça não é uma virtude teologal, mas moral, como se disse na Segunda Parte. Ora, a
penitência parece que é uma virtude teologal, por ter Deus como objeto; pois, satisfaz a Deus, com o
qual também reconcilia o pecador. Logo, parece que a penitência não é uma espécie de justiça.

2. Demais. — A justiça, sendo virtude moral, consiste numa mediedade. Ora, a penitência, longe de
consistir numa mediedade, constitui um excesso, segundo àquilo da Escritura: Toma luto como por um
filho único, pranto amargo. Logo, a penitência não é uma espécie de justiça.

3. Demais. — Duas são as espécies de justiça, a saber, a distributiva e a comutativa. Ora, parece, em
nenhuma delas está contida a penitência. Logo, parece que a penitência não é uma espécie de justiça.

4. Demais. — Àquilo do Evangelho – Bem-aventurados os que agora chorais - diz a Glosa: Eis a prudência
a nos mostrar quão miseráveis são as coisas da terra, e quão santas as do céu. Ora, chorar é um ato de
penitência. Logo, a penitência é, antes, ato de prudência que de justiça.
Mas, em contrário, diz Agostinho: A penitência é uma como vingança que tira de si quem chora seus
pecados, sempre a castigar em si próprio o que lamenta haver cometido. Ora, tirar vingança é próprio
da justiça; por isso Túlio considera a vindicta como uma espécie de justiça. Logo, parece que a
penitência é uma espécie de justiça.

SOLUÇÃO. — Como dissemos a penitência não é uma virtude especial só por nos fazer lamentar o mal
cometido, para o que bastaria a caridade; mas porque o penitente se arrepende do pecado cometido,
enquanto ofensa a Deus, e com o propósito de emendar-se. Ora, a reparação da ofensa cometida contra
outrem não se produz pelo só cessar dessa ofensa; mas é necessário ulteriormente uma recompensa,
que tem lugar nas ofensas cometidas contra terceiro, bem como uma retribuição. Salvo que a
recompensa deve provir do ofensor, por exemplo, satisfação; ao passo que a retribuição pertence
aquele contra quem foi a ofensa cometida. Ora, uma e outra coisa constitui matéria da justiça, porque
são ambas uma comutação, de certo modo. Por onde, é manifesto que a penitência, enquanto virtude
faz parte da justiça. Devemos, porém saber que, segundo o Filósofo, o justo tem dupla acepção - uma
absoluta e outra, relativa. - O justo absoluto é entre iguais; por ser a justiça uma espécie de igualdade. E
a esse dá Aristóteles o nome de justo político ou civil; porque todos os cidadãos são iguais por estarem,
como livres, sujeitos imediatamente ao mesmo chefe. - Justo relativo se chama o que tem lugar entre
pessoas, das quais uma está sujeita a outra; assim, o escravo, ao senhor; o filho, ao pai; a esposa, ao
marido. E tal é o justo que consideramos na penitência. Por onde, o penitente recorre a Deus, com o
propósito de emenda, como o servo ao senhor, segundo aquilo da Escritura: Assim como os olhos dos
servos estão pregados nas mãos de seus senhores, assim os nossos olhos estão fitos no Senhor nosso
Deus, até que tenha misericórdia de nós. E assim como o filho, ao pai, conforme ao Evangelho: Pai
pequei contra o céu e diante de ti. E como a mulher ao marido, segundo ainda a Escritura: Tu tens te
prostituído a muitos amadores; ainda assim torna para mim, diz o Senhor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Aristóteles, a justiça implica relação com
terceiro. Ora, aquele para com quem se pratica a justiça não se considera como a matéria dela, que são
antes as coisas distribuídas ou comutadas. Por onde, também a matéria da penitência não é Deus, mas
os atos humanos, com que ofendemos ou aplacamos a Deus; e Deus é como aquele para com quem
praticamos a justiça. Por onde é claro, que a penitência não é uma virtude teologal, por não ter a Deus
como objeto ou matéria.

RESPOSTA À SEGUNDA. — A mediedade da justiça é uma igualdade constituída entre aqueles cujas
relações são regidas pela justiça, como diz Aristóteles. Entre certos porém não pode haver perfeita
igualdade, por causa da excelência de um sobre o outro; assim, entre o pai e o filho, ou entre Deus e o
homem, como diz o Filósofo. Por onde, em tais casos, o inferior deve fazer o que puder. O que porém
não será suficiente senão só pela aceitação do superior. E isto significa o excesso atribuído à penitência.

RESPOSTA À TERCEIRA. — Assim como há uma certa comutação de benefícios, quando damos graça
pelo beneficio recebido, assim também há uma comutação nas ofensas, como quando, pela ofensa que
assacámos contra outrem, somos punidos contra a nossa vontade - o que constitui a justiça comutativa;
ou recompensamos voluntariamente pela emenda - e isso constitui a penitência, que respeita a pessoa
do pecador, como a justiça vindicativa respeita a pessoa do juiz. Por onde é manifesto, que a justiça
vindicativa e a penitência estão incluídas na justiça comutativa.

RESPOSTA À QUARTA. — A penitência, embora seja diretamente uma espécie de justiça, compreende
contudo de certo modo a matéria de todas as virtudes. - Pois, enquanto é de certo modo uma justiça
existente entre o homem e Deus, há de necessariamente participar da natureza das virtudes teologais,
que têm Deus por objeto. Por isso a penitência supõe a fé na paixão de Cristo, pela qual somos
justificados dos pecados; e a esperança do perdão; e o ódio dos vícios, o que implica a caridade. - Mas
com virtude moral, participa algo da prudência, diretiva de todas as virtudes morais. Mas, por isso
mesmo que é justiça, não só participa da natureza da justiça, mas também da natureza da temperança e
da fortaleza; isto é, enquanto as coisas que nos causam prazer, moderado pela temperança; ou incutem
o temor, acalmado pela fortaleza - vêm a encontrar-se com a matéria da justiça. E a esta luz, pertence à
justiça tanto a abstenção dos prazeres - matéria da temperança, como o suportar o que nos contraria os
sentidos - matéria da fortaleza.

## Art. 4 — Se o sujeito próprio da penitência é a vontade.
O quarto discute-se assim. — Parece que o sujeito próprio da penitência não é a vontade.

1. — Pois, a penitência é uma espécie de tristeza. Ora, a tristeza como a alegria, pertence ao apetite
concupiscível. Logo, a penitência pertence ao concupiscível.

2. Demais. — A penitência é uma sorte de vindicta, como diz Agostinho. Ora a vindicta pertence ao
irascível, porque a ira é o desejo da vindicta. Logo, parece que a penitência pertence ao irascível.

3. Demais. — O passado é o objeto próprio da memória, segundo o prova o Filósofo. Ora a penitência
tem por objeto o passado, como se disse. Logo, a penitência tem na memória o seu sujeito.

4. Demais. — Nenhum ser age onde não está. Ora a penitência exclui os pecados de todas as potências
da alma. Logo, a penitência está em qualquer potência da alma, e não só na vontade.
Mas, em contrário. - A penitência é uma espécie de sacrifício, segundo aquilo da Escritura: Sacrifício para
Deus é o espírito atribulado. Ora, oferecer um sacrifício é ato da vontade, segundo ainda a Escritura: Eu
te oferecerei um sacrifício voluntário. Logo, a penitência está na vontade.

SOLUÇÃO. — Podemos encarar a penitência à dupla luz. - Primeiro como paixão. E assim, sendo uma
espécie de tristeza, tem no concupiscível o seu sujeito. - Segundo como virtude. E então, como
dissemos, é uma espécie de justiça. Ora, o sujeito da justiça como estabelecemos na Segunda Parte, é a
vontade, apetite racional. Por onde é manifesto, que a penitência, enquanto virtude tem na vontade o
seu sujeito. E o seu ato próprio é o propósito feito a Deus de emendarmos o que contra ele cometemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe considerando-se a penitência como
paixão.

RESPOSTA À SEGUNDA. — Tomar por paixão, vingança de outrem é próprio do irascível. Mas desejar ou
tirar vingança, racionalmente, de nós mesmos ou de outrem, é próprio da vontade.

RESPOSTA À TERCEIRA. — A memória é uma potência apreensiva do passado. Ora, a penitência não
pertence à potência apreensiva, mas à apetitiva, que supõe o ato da apreensiva. Por onde, a penitência
não reside na memória, mas a pressupõe.

RESPOSTA À QUARTA. — A vontade, como estabelecemos na Primeira Parte, move todas as outras
potências da alma. Não há pois nenhuma contrariedade se a penitência, tendo na vontade o seu sujeito,
produza certos efeitos em cada uma das potências da alma.

## Art. 5 — Se o princípio da penitência resulta do temor.
O quinto discute-se assim. — Parece que o princípio da penitência não resulta do temor.

1. — Pois, a penitência começa pela displicência dos pecados. Ora, essa é própria da caridade, como
dissemos. Logo, a penitência nasce, antes, do amor que do temor.

2. Demais. — Os homens são provocados à penitência pela esperança do reino celeste, Segundo àquilo
do Evangelho: Fazei penitência, porque está próximo a reino dos céus. Ora, o reino dos céus é o objeto
da esperança. Logo, a penitência procede, antes, da esperança, que do temor.

3. Demais. — O temor é um ato interno do homem. Ora, a penitência não resulta em nós de uma ação
nossa, mas é obra de Deus, segundo àquilo da Escritura: Depois que me converteste, fiz penitência.
Logo, a penitência não procede do temor.
Mas, em contrário, a Escritura: Assim como a que concebe, quando estiver próximo ao parto,
confrangendo-se, dá gritos nas suas dores, do mesmo modo nos tornamos nós, isto é, pela penitência. E
depois acrescenta segundo outra letra: O vosso temor, nos fez conceber Senhor, e demos à luz e
parimos o espírito de salvação, isto é, da penitência salutar, como se colhe do que foi anteriormente
dito. Logo, a penitência procede do temor.

SOLUÇÃO. — Podemos encarar a penitência a dupla luz. - Primeiro como hábito. E então é infundida
imediatamente por Deus, sem nós como colaboradores principais; mas não sem nós como cooperadores
pela nossa disposição, mediante certos atos. - De outro modo podemos encarar a penitência quanto aos
atos pelos quais cooperamos com a ação de Deus, ao nos infundir essa virtude. Desses atos o princípio
primeiro é a ação de Deus, convertendo-nos o coração, segundo àquilo da Escritura: Converte-nos,
Senhor a ti, e nós nos converteremos. - O segundo ato é o movimento da fé. - O terceiro ato é o
movimento do temor servil, pelo qual nos apartamos do pecado pelo medo dos suplícios. - O quarto ato
é o movimento da esperança, pelo qual formamos o propósito da emenda, na esperança de
alcançarmos o perdão. - O quinto ato é o movimento da caridade, pelo qual o pecado nos desagrada em
si mesmo e já não por causa dos suplícios. - O sexto ato é o movimento do temor filial, em virtude do
qual, pela reverência para com Deus, oferecemos voluntàriamente a Deus a nossa satisfação. - Por onde
é claro que o ato de penitência procede do temor servil como do primeiro movimento do afeto que para
tal ordena; mas do temor filial, como do princípio próprio e imediato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pecado começa, por desagradar ao homem,
sobretudo pecador, por causa dos suplícios visados pelo temor servil, antes de lhe desagradar por causa
da ofensa a Deus ou da torpeza do pecado, o que é próprio da caridade.

RESPOSTA À SEGUNDA. — Pelo aproximar-se do reino dos céus se entende o advento do rei, não só
para premiar, mas também para punir. Por isso, como lemos no Evangelho, João Batista dizia: Raça de
víboras, quem vos ensinou a fugir da ira vindoura?

RESPOSTA À TERCEIRA. — O próprio movimento do temor também procede do ato de Deus, que
converte o coração. Donde o dizer da Escritura: Quem dera que eles tivessem tal coração, que me
temessem? Por onde, o fato de a penitência proceder do temor não exclui que proceda do ato pelo qual
Deus converte o coração.

## Art. 6 — Se a penitência é a primeira das virtudes.
O sexto discute-se assim. — Parece que a penitência é a primeira das virtudes.

1. — Pois, aquilo do Evangelho - Fazei penitência, diz a Glosa: A primeira virtude é, pela penitência,
punir o homem velho e odiar os vícios.

2. Demais. — Antes de chegarmos ao termo final, começamos por sair do ponto de partida. Ora, parece
que todas as outras virtudes têm por objeto a nossa marcha para o ponto de chegada; pois, todas se
ordenam a nos fazer agir retamente. Ora, parece que a penitência tem por fim fazer-nos deixar o mal.
Logo, segundo parece, a penitência é a primeira de todas as virtudes.

3. Demais. — Antes da penitência há o pecado na alma. Ora, nenhuma virtude pode coexistir na alma
com o pecado. Logo, não há nenhuma virtude, antes da penitência; mas ela deve ser considerada a
primeira, que prepara o caminho às outras, excluindo o pecado.
Mas, em contrário, a penitência procede da fé, da esperança e da caridade, como já dissemos. Logo, não
é a penitência a primeira das virtudes.

SOI.UÇÃO. — Nas virtudes não se considera a ordem do tempo, quanto à existência delas como hábitos;
porque, sendo as virtudes conexas, conforme estabelecemos na Segunda Parte, todas começam
simultaneamente a existir na alma. Mas dizemos que uma delas tem prioridade sobre outra na ordem
da natureza, cuja ordem é dependente da ordem dos atos, quando o ato de uma virtude pressupõe o de
outra.
Donde devemos concluir que certos atos meritórios podem preceder, mesmo temporalmente, o ato e o
hábito da penitência; assim, o ato da fé e da esperança informes, e o ato do temor servil. Quanto ao ato
e ao hábito da caridade, são simultâneos no tempo com o ato e o hábito da penitência, e com os hábitos
das outras virtudes. Pois, como estabelecemos na Segunda Parte, na justificação do ímpio são
simultâneos o movimento do livre arbítrio para Deus, que ê um ato de fé informado pela caridade; e o
movimento do livre arbítrio relativamente ao pecado, que é um ato de penitência. Ora, destes dois atos,
o primeiro naturalmente precede o segundo; pois, o ato da virtude de penitência encontra o pecado,
pelo amor de Deus que implica; portanto, o primeiro ato é a razão e a causa do segundo. Assim, pois, a
penitência não é, absolutamente falando, a primeira das virtudes, nem na ordem do tempo, nem na
ordem da natureza; pois, na ordem da natureza e absolutamente falando, as virtudes teologais a
precedem.
Mas, de certo modo, é a primeira entre as outras virtudes na ordem do tempo, quanto ao seu ato, que
vem em primeiro lugar na justificação do ímpio. Mas, na ordem da natureza, as outras virtudes têm
prioridade, assim como o essencial tem prioridade sobre o acidental. Pois, as outras virtudes são
essencialmente necessárias ao bem do homem, ao passo que a penitência é necessária
condicionalmente, isto é, no caso de preexistir o pecado, como o dissemos quando tratamos da relação
entre o sacramento da penitência e os outros sacramentos referidos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Glosa referida alude ao ato de penitência como o
primeiro, na ordem do tempo, entre os atos das outras virtudes.

RESPOSTA À SEGUNDA. — Nos movimentos sucessivos o afastar-se do ponto de partida é
temporalmente anterior, à chegada ao termo; e anterior, por natureza, no concernente ao sujeito, ou na
ordem da causa material. Mas na ordem da causa agente e final, primeiro chegamos ao termo, pois, é o
que vem em primeiro lugar na intenção do agente. E tal é a ordem a que primeiro atendemos, nos atos
da alma, como diz Aristóteles.

RESPOSTA À TERCEIRA. — A penitência abre o caminho às virtudes, expulsando o pecado pelas virtudes
da fé e da caridade, que são anteriores por natureza. Mas abre-lhes o caminho de modo que entram
simultaneamente com ela; pois, na justificação do ímpio, ao mesmo tempo que o movimento do livre
arbítrio para Deus e o relativo ao pecado, vem a remissão da culpa e a infusão da graça, com o que
simultaneamente são infundidas todas as virtudes, conforme estabelecemos na Segunda Parte.