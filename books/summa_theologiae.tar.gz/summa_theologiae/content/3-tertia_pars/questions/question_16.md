# Questão 16: Do conveniente a Cristo no seu ser e no seu dever
E, primeiro, do conveniente a Cristo em si mesmo considerado. Segundo, do que lhe convém por
comparação com Deus Padre. Terceiro, do que convém a Cristo, quanto a nós.
O primeiro ponto abrange uma dupla questão. A primeira sobre o que convém a Cristo no seu ser e no
seu dever; a segunda sobre o que convém a Cristo em razão da unidade.
Na primeira questão discutem-se doze artigos:

## Art. 1 — Se é falsa a proposição: Deus é homem.
O primeiro discute-se assim. — Parece que é falsa o proposição: Deus é homem.
1 — Pois, toda proposição afirmativa, em matéria remota, é falsa. Ora, a proposição – Deus é homem, é
em matéria remota, porque as formas significadas pelo sujeito e pelo predicado distam em máximo
grau. Ora, sendo essa proposição afirmativa, é falsa.

2. Demais. — Mais convêm as três Pessoas divinas entre si, que a natureza humana com a divina. Ora,
no mistério da Trindade, uma pessoa não é predicada de outra; assim, não dizemos que o Pai é o Filho,
ou inversamente. Logo, parece que também a natureza humana não pode predicar-se de Deus, de modo
a dizer-se que Deus é homem.

3. Demais. — Atanásio diz, que assim como a alma e a carne são um só homem, assim, Deus e homem
constituem um só Cristo. Ora, é falsa a proposição – A alma é o corpo. Logo, também falsa é a outra:
Deus é homem.

4. Demais. — Como se demonstrou na Primeira Parte, o predicado de Deus, não relativa mas
absolutamente, convém a toda a Trindade e a cada uma das Pessoas. Ora, o nome homem não é
relativo, mas absoluto. Se, pois, é verdadeiramente predicado de Deus, segue-se que toda a Trindade e
qualquer das suas pessoas é homem. O que é evidentemente falso.
Mas, em contrário, o Apóstolo: O qual, tendo a natureza de Deus, se aniquilou a si mesmo, tomando a
natureza de servo fazendo-se semelhante aos homens e sendo reconhecido na condição como homem.
E assim, aquele que tem a natureza de Deus é homem. Ora, aquele que tem a natureza de Deus é Deus.
Logo, Deus é homem.

SOLUÇÃO. — A proposição – Deus é homem todos os cristãos a concedem; mas não todos pela mesma
razão. Pois, certos a concedem, mas não na acepção própria dos seus termos. — Assim, os Maniqueus
consideram o Verbo de Deus como homem, mas não verdadeiro, senão só por semelhança, dizendo que
o Filho de Deus assumiu um corpo imaginário; e então, dizemos que Deus é homem no mesmo sentido
em que dizemos que é homem uma figura de cobre, por ter a semelhança humana. —
Semelhantemente, também os que ensinavam não terem sido unidos, em Cristo, a alma e o corpo, não
admitiam fosse Deus verdadeiro homem; mas que o era só figuradamente, em razão das partes. — Ora,
ambas estas opiniões já foram refutadas.
Outros, porém, ao inverso, ensinam a verdade em relação ao homem, mas a negam. em relação a Deus.
Pois, dizem que Cristo, sendo Deus e homem, é Deus, não por natureza, mas por participação, isto é,
pela graça; assim como todos os varões santos se chamam deuses, mas, mais excelentemente, Cristo,
que todos, por ter uma graça. mais abundante. E assim, quando dizemos — Deus é homem — a palavra
Deus não supõe um Deus verdadeiro e de natureza divina. E tal foi a heresia de Fotino, supra refutada.
Outros, porém, concedem a referida proposição admitindo como verdadeiros ambos os seus termos e,
portanto, que Cristo é verdadeiro Deus e verdadeiro homem; mas nem por isso salvam a verdade da
predicação. Pois, dizem que homem é predicado, de Deus, por uma certa união de dignidade ou de
autoridade ou ainda de afeto ou de habilitação. E assim Nestório ensinava que Deus é homem, não
querendo com isso significar senão que Deus está unido ao homem por uma tal união, que Deus nele
habita e lhe está unido pelo afeto e pela participação da autoridade e da honra divina. — E em
semelhante erro caem todos os que introduzem duas hipóstases ou dois supostos em Cristo. Pois, não é
possível entender-se que, de dois seres distintos pelo suposto ou pela hipóstase, um seja propriamente
predicado do outro, senão só por um modo figurado de falar, enquanto tem algum ponto de união.
Assim, se dissermos que Pedro é João, por terem alguma coisa que os une entre si. Ora, estas opiniões
também já foram refutadas.
Por onde, supondo, segundo a verdade da fé, Católica, a união da verdadeira natureza divina com a
verdadeira natureza humana, não só na pessoa, mas também no suposto ou na hipóstase, dizemos ser
verdadeira e própria a proposição — Deus é homem. Não só pela verdade dos termos, isto é, por ser
Cristo verdadeiro Deus e verdadeiro homem, mas ainda pela verdade da predicação. Pois o nome que
significa a natureza comum em concreto, pode ser suposto seja pelo que for que estiver contido nessa
natureza comum; assim o nome de homem pode ser suposto por qualquer homem particular. Por onde,
o nome de Deus, pelo modo mesmo da sua significação, pode ser suposto pela pessoa do Filho de Deus,
como também já demonstramos na Primeira Parte. De qualquer suposto, porém, de uma natureza,
pode ser verdadeira e propriamente predicado o nome significativo dessa natureza em concreto; assim,
de Sócrates e de Platão é própria e verdadeiramente predicado a palavra homem. Ora, sendo a pessoa
do Filho de Deus, pela qual é suposto o nome de Deus, o suposto da natureza humana, verdadeira e
propriamente o nome de homem pode ser predicado do nome Deus, enquanto suposto pela pessoa do
Filho de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando formas diversas não podem convir num mesmo
suposto, então a proposição versa necessariamente sobre matéria remota, da qual o sujeito significa
uma dessas formas e o predicado, a outra. Mas, quando duas formas podem convir num mesmo
suposto, a matéria não é remota, mas, natural ou contingente, como quando digo – um homem branco
é músico. Ora, a natureza divina e a humana, embora distantes uma da outra em máximo grau, contudo
convêm, pelo mistério da Encarnação, num mesmo suposto, no qual nenhuma delas existe por acidente,
mas por essência, Por onde, a proposição — Deus é homem — nem é em matéria remota nem em
matéria contingente, mas em matéria natural. E o nome de homem é predicado de Deus, não
acidentalmente, mas por essência, como da sua hipóstase; não por certo em razão da forma significada
pelo nome de Deus, mas em razão do suposto, que é a hipóstase da natureza humana.

RESPOSTA À SEGUNDA. — As três Pessoas divinas convêm na mesma natureza, mas distinguem-se pelo
suposto; e portanto não podem predicar-se uma de outra. Mas no mistério da Encarnação, as naturezas,
por serem distintas, certamente não se predicam uma da outra, enquanto de significação abstrata, pois,
não é a natureza divina a humana; mas, por terem o mesmo suposto, predicam-se uma da outra em
concreto.

RESPOSTA À TERCEIRA. — Alma e carne tem significação abstrata, como a tem divindade e
humanidade; mas, em significação concreta, dizemos animado e carnal ou corpóreo, assim como
dizemos, de outro lado, Deus e homem. Por onde, de ambos os lados, não é predicado o abstrato, do
abstrato, mas só, o concreto, do concreto,

RESPOSTA À QUARTA. — O nome de homem é predicado de Deus em razão da união pessoal; e essa
união implica relação. E por isso, não segue a regra daqueles nomes que absolutamente e abeterno são
predicados de Deus.

## Art. 2 — Se é falsa a proposição: o homem é Deus.
O segundo discute-se assim. — Parece falsa a proposição – o homem é Deus.

1. — Pois, o nome de Deus é incomunicável; donde o repreender a Escritura os idólatras, porque deram
o nome incomunicável de Deus às pedras e ao pau. Logo, pela mesma razão, parece inconveniente
predicar o nome de Deus, do homem.

2. Demais. — Tudo o predicado do predicado também o é do sujeito. Ora, é verdadeira a proposição —
Deus é o Pai, ou Deus é a Trindade. Se, pois, é verdadeira a proposição — O homem é Deus —
verdadeira também há de ser esta outra — O homem é o Pai ou, O homem é a Trindade. As quais são
evidentemente falsas. Logo, também o é a primeira.

3. Demais. — A Escritura diz: Não haverá em ti Deus novo. Ora, o homem é de certo modo novo, pois,
Cristo nem sempre foi homem. Logo, é falsa a proposição: O homem é Deus.
Mas, em contrário, o Apóstolo: De quem descende Cristo segundo a carne, que é Deus sobre todas as
coisas bendito por todos os séculos. Ora, Cristo, segundo a carne, é homem. Logo, é verdadeira a
proposição – O homem é Deus.

SOLUÇÃO. — Suposta a verdade de uma e outra natureza — a divina e a humana — e a união na pessoa
e na hipóstase, é verdadeira e própria a proposição — O homem é Deus, como o é esta outra — Deus é
homem. Pois, o nome de homem pode ser suposto por qualquer hipóstase da natureza humana; e
portanto pode ser suposto pela pessoa do Filho de Deus, que dissemos ser a hipóstase da natureza
humana. Ora, é manifesto que da pessoa do Filho de Deus pode verdadeira e propriamente ser
predicado o nome de Deus, como demonstramos na Primeira Parte. Donde se conclui que é verdadeira
e própria a proposição — O homem é Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os idólatras davam o nome da divindade à pedra e ao
pau, considerados na sua natureza mesma, por pensarem que havia neles algo da divindade. Nós porém
não atribuímos o nome de Deus a Cristo homem, segundo a natureza humana, mas segundo o suposto
eterno, que também é pela união, o suposto da natureza humana, como se disse.

RESPOSTA À SEGUNDA. — O nome Pai predica-se do nome Deus quando o nome de Deus é suposto
pela pessoa do Pai. E nesse sentido não se predica da pessoa do Filho, porque a pessoa do Filho não é a
pessoa do Pai. E por consequência não é necessário o nome de Pai ser predicado do nome homem, do
qual é predicado o nome de Deus, quando o nome de homem é suposto pela pessoa do Filho.

RESPOSTA À TERCEIRA. — Embora a natureza humana em Cristo fosse assumida no tempo, contudo o
suposto dela não é temporal, mas eterno. E o nome Deus, não se predicando do homem em razão da
natureza humana, mas em razão do suposto, não resulta daí que concebamos Deus como temporal. O
que resultaria se disséssemos que o homem supõe um suposto criado; o que devem ensinar
necessariamente os que introduzem em Cristo dois supostos.

## Art. 3 — Se Cristo pode ser chamado o homem do Senhor.
O terceiro discute-se assim. — Parece que Cristo pode ser chamado. o homem do Senhor.

1. — Pois, diz Agostinho: Devemos advertir que são de se esperar os bens que existiam naquele homem
do Senhor. Ora, refere-se a Cristo, Logo, parece que Cristo é homem do Senhor.

2. Demais. — Assim como o domínio convém a Cristo em razão da natureza divina, assim também a
humanidade pertence à natureza humana. Ora, Deus é dito humanado, como o faz Damasceno quando,
se refere à humanação, que demonstra a união com o homem. Logo, pela mesma razão, pode-se dar ao
homem Cristo a denominação de homem do Senhor.

3. Demais. — Assim como a denominação latina dominicus (do Senhor) deriva de dominas, assim divino
deriva de Deus. Ora, Dionísio diz que Cristo denomina o diviníssimo Jesus. Logo, pela mesma razão,
podemos dizer que Cristo é o homem do Senhor.
Mas, em contrário, Agostinho diz: Não vejo se se chama com acerto a Jesus Cristo homem do Senhor,
pois é propriamente Senhor.

SOLUÇÃO. — Como dissemos, quando dizemos o homem. Jesus Cristo, designamos o suposto eterno,
que é a pessoa do Filho de Deus, porque ambas as suas naturezas tem o mesmo suposto. Ora, da pessoa
do Filho de Deus se predica Deus e Senhor, essencialmente. Logo, não devem ser predicados
denominativamente, porque iria contra a verdade da união. Por onde, como dominicus (do Senhor) tira
a sua denominação de dominus (Senhor), não podemos dizer verdadeira e propriamente que Cristo seja
o homem do Senhor, mas antes, que é Senhor, Mas, se pela expressão Jesus Cristo homem designamos
um suposto criado, como o ensinam os que introduzem em Cristo dois supostos, podemos então dizer
que Cristo é homem do Senhor, por ter sido assumido para participar da honra divina, como o
ensinavam os Nestorianos. E também deste modo não dizemos que a natureza é essencialmente deusa,
mas, deificada; não, certo, por se converter em a natureza divina, mas pela união com a natureza divina,
na unidade da hipóstase, como está claro em Damasceno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essas expressões e outras semelhantes Agostinho as
retratou. Por isso, depois das palavras dessa retração acrescenta: Onde disse, que Cristo Jesus fosse
homem do Senhor, não queria tê-lo dito, Pois, vi depois que não devia ser assim, porque nenhuma razão
o pode sustentar. Isto é, porque poderia alguém dizer que é chamado homem do Senhor em razão da
natureza humana, significada pela palavra homem, mas não em razão do suposto.

RESPOSTA À SEGUNDA. — Esse suposto único, da natureza divina e da humana foi, primeiro, da
natureza divina isto é, abeterno; mas depois temporalmente, pela Encarnação foi feito o suposto da
natureza humana. E por isso se chama humanado, não por ter assumido o homem, mas porque assumiu
a natureza humana. Mas não se dá o inverso, a saber, que o suposto da natureza humana tivesse
assumido a natureza humana. Por isso, Cristo não pode ser chamado homem deificado ou do Senhor.

RESPOSTA À TERCEIRA. — O nome divino costuma predicar-se também daquilo de que se predica
essencialmente o nome de Deus. Assim, dizemos que a essência divina é Deus, em razão da identidade;
e que a essência é de Deus ou divina, pelo modo diverso de significar; e Verbo divino, embora o Verbo
seja Deus. E semelhantemente, dizemos pessoa divina como dizemos também a pessoa de Platão, por
causa do modo diverso de significar. Ora, a expressão — do Senhor — não se predica daquilo de que se
predica o nome de Senhor; assim, não se costuma dizer que um homem, que é senhor, seja do senhor;
mas, o que de algum modo é do senhor se chama do senhor, como quando dizemos: a vontade do
Senhor ou a mão do Senhor ou a paixão do Senhor. Por onde, o homem Cristo, que é Senhor, não pode
ser chamado do Senhor; mas a sua carne pode ser denominada carne do Senhor e a sua paixão do
Senhor.

## Art. 4 — Se o próprio à natureza humana pode-se atribuir a Deus.
O quarto discute-se assim. — Parece que o próprio à natureza humana não se pode atribuir a Deus.

1. — Pois, é impossível os contrários serem predicados do mesmo sujeito. Ora, as propriedades da
natureza humana são contrárias às de Deus: porquanto, sendo Deus incriado, imutável e eterno é
próprio da natureza humana ser criada, temporal e mutável. Logo, o próprio à natureza humana não
pode ser atribuído a Deus.

2. Demais. — Atribuir a Deus o que constitui uma deficiência, contraria à honra divina e é uma
blasfêmia. Ora, o próprio à natureza humana, como sofrer, morrer e causas semelhantes, são
deficiências. Logo, parece que de nenhum modo podemos atribuir a Deus o próprio à criatura.

3. Demais. — Ser assumida convém à natureza divina. Ora, não convém a Deus ser assumido. Logo, não
podemos atribuir a Deus o próprio à natureza humana.
Mas, em contrário, Damasceno diz que Deus assumiu as particularidades da carne, isto é, as
propriedades, por lhe convir a denominação de passível e ter sido o Deus da glória, crucificado.

SOLUÇÃO. — Nesta questão divergem os Nestorianos e os Católicos.
Assim, os Nestorianos queriam dividir as denominações atribuídas a Cristo, de modo que não se
atribuíssem a Deus as que o são à natureza humana; nem ao homem, as próprias da natureza divina.
Donde o dizer Nestório: Quem tentar atribuir paixões ao Verbo de Deus seja anátema. Mas os nomes
atribuíveis a ambas as naturezas, desses se pode predicar o que delas é próprio; assim, o nome de Cristo
ou de Senhor. Por isso concediam que Cristo nasceu da Virgem Maria e existiu abeterno; mas não
admitiam que Deus tivesse nascido da Virgem ou que o homem fosse abeterno.
Mas os Católicos ensinavam que o atribuído a Cristo, quer segundo a natureza divina, quer segundo a
humana, tanto se pode dizer de Deus como do homem. Por isso Cirilo ensina: Quem atribuir
separadamente às duas pessoas ou substâncias, isto é, hipóstases, as denominações dos livros
evangélico é apostólicos, quer essas denominações os santos as atribuíssem a Cristo, quer as tivesse
Cristo dito de si mesmo; de modo a crer serem umas delas aplicáveis, ao homem e destinar as outras só
para o Verbo, esse tal seja anátema. E a razão disto está em que, sendo uma mesma a hipóstase das
duas naturezas, a mesma hipóstase é suposta no nome de ambas. Por onde, quer digamos homem, quer
digamos Deus, supomos a hipóstase das naturezas divina e humana. Portanto, podemos atribuir ao
homem o próprio à natureza divina; e a Deus, o próprio à natureza humana.
Devemos, porém, saber que numa proposição onde se predica uma coisa, de outra, não somente se
atende à coisa a que se atribui o predicado, mas também ao modo da predicação. E assim, embora não
se distinguam entre si as predicações feitas de Cristo, distinguem-se contudo pelo modo pelo qual cada
uma é feita. Pois, as propriedades da natureza divina são predicadas da natureza divina de Cristo; e as
da natureza humana, da sua natureza humana. Por isso diz Agostinho: Distingamos as expressões que a
Escritura atribui a Cristo, enquanto Deus, por onde é igual ao Pai, daquelas que lhe aplica segundo a
forma de servo,que assumiu, pela qual é menor que o Pai. E a seguir: O leitor prudente, diligente e pio
compreenderá o que é atribuído essencialmente, do que o é de certo modo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os contrários serem predicados de um mesmo sujeito,
num mesmo ponto de vista, é impossível; mas nada impede o sejam, a luzes diversas. Ora, é neste
último sentido que os contrários se predicam de Cristo: não no mesmo ponto de vista, mas, segundo as
naturezas diversas.

RESPOSTA À SEGUNDA. — Atribuir uma deficiência a Deus, segundo a sua natureza divina, seria
blasfêmia, por lhe diminuir a honra; mas não seria uma injúria a Deus atribuir-lhe essa deficiência
segundo a natureza assumida. Por isso, um sermão pronunciado no Concílio Efesino diz: Deus não
considera de nenhum modo como injúria o que é uma ocasião para os homens se salvarem. Assim,
nenhuma das abjeções que escolheu, por nosso amor, pode causar injúria àquela natureza que não
pode estar sujeita a injúrias; pois, tomou as coisas inferiores como próprias para salvar a nossa natureza.
Quando, pois; as abjeções e as vilezas longe de injuriar a natureza divina, obram a salvação do homem,
como dizer que aquilo que é carne da nossa salvação foi ocasião de injúria a Deus?

RESPOSTA À TERCEIRA. — Ser assumida convém à natureza humana, não em razão do suposto, mas em
razão dela mesma. E por isso não convém a Deus.

## Art. 5 — Se as propriedades da natureza humana podem ser atribuídas à natureza divina.
O quinto discute-se assim — Parece que as propriedades da natureza humana podem ser atribuídas à
natureza divina.

1. — Pois, as propriedades da natureza humana se predicam do Filho de Deus e de Deus. Ora, Deus é a
sua natureza. Logo, as propriedades da natureza humana podem predicar-se da natureza divina.

2. Demais. — A carne faz parte da natureza humana. Ora, como diz Damasceno, afirmamos, segundo os
santos Atanásio e Cirilo, a natureza encarnada do Verbo. Logo, parece que, pela mesma razão, as
propriedades, da natureza humana podem predicar-se da natureza divina.

3. Demais. — As propriedades da natureza divina convêm à natureza humana de Cristo, assim, conhecer
o futuro e ter o poder de salvar. Logo, parece que, pela mesma razão, as propriedades da natureza
humana podem predicar-se da natureza divina.
Mas, em contrário, Damasceno diz: Quando falamos da divindade não lhe atribuímos as particularidades
da humanidade, isto é, as propriedades; assim não dizemos ser a divindade passível ou um ser criável.
Ora, a divindade é a natureza divina. Logo, as propriedades da natureza humana não podem predicar-se
da natureza divina.

SOLUÇÃO. — As propriedades de um ser não podem verdadeiramente se predicar de outro, a menos
que seja idêntico com ele; assim, a faculdade de rir-se só convém ao homem. Ora, no mistério da
Encarnação, não se identifica a natureza divina com a humana; é a mesma porém a hipóstase de ambas.
Por onde, as propriedades de uma natureza não podem predicar-se da outra, enquanto significadas em
abstrato. Mas os nomes concretos supõem a hipóstase da natureza. Por isso, as propriedades de uma e
de outra natureza podem, sem diferenças, ser predicadas dos nomes concretos. Quer o nome de que se
predicam exprima uma e outra natureza, como o nome Cristo, pelo qual se entende a divindade que
unge a humanidade, que é ungida; quer exprima só a natureza divina, como o nome de Deus, ou de
Filho de Deus; quer, só a natureza humana, como o nome de homem ou de Jesus. Donde o dizer Leão
Papa: Não importa a substância pela qual designemos Cristo; desde que, subsistindo a unidade de
pessoa, o mesmo ser é totalmente o filho do homem, por causa da carne, e totalmente o filho de Deus,
por causa da divindade, que lhe é comum com o Pai.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Em Deus realmente se identifica a pessoa com a
natureza; e em razão dessa identidade a natureza divina se predica do Filho de Deus. Mas, o modo de
significar não é o mesmo. Por isso, certas atribuições convêm ao Filho de Deus, que não convêm à
natureza divina; assim, dizemos ser o Filho de Deus gerado, mas não dizemos que o seja a natureza
divina, como se estabeleceu na Primeira Parte. E semelhantemente, no mistério da Encarnação dizemos
que o Filho de Deus sofreu; mas não dizemos que sofreu a natureza divina .

RESPOSTA À SEGUNDA. — A Encarnação supõe antes a união com a carne do que as propriedades da
carne. Ora, cada natureza, em Cristo, se uniu à outra, na pessoa; em razão de cuja união dizemos, de um
lado, que a natureza humana encarnou-se e que a natureza humana deificou-se, como mostramos.

RESPOSTA À TERCEIRA. — As propriedades da natureza divina predicam-se da natureza humana, não
segundo convêm essencialmente à natureza divina, mas enquanto deriva participativamente para a
natureza humana. Por onde, o que não pode ser participado pela natureza humana, como ser incriada
ou onipotente, de nenhum modo é dela predicado. Ora, a natureza divina nada recebe, por
participação, da natureza humana. Logo, as propriedades da natureza humana de nenhum modo podem
predicar-se da natureza divina.

## Art. 6 — Se é falsa a proposição; Deus se fez homem.
O sexto discute-se assim. — Parece falsa a proposição: Deus se fez homem.

1. — Pois, homem, significando uma substância, fazer-se homem é fazer-se em sentido absoluto. Ora, é
falsa a proposição: Deus se fez, em sentido absoluto. Logo também é falsa esta outra: Deus se fez
homem.

2. Demais. — Fazer-se homem é mudar-se. Ora, Deus não pode ser sujeito de mudança, conforme a
Escritura: Eu sou o Senhor e não me mudo. Logo, parece falsa a proposição: Deus se fez homem.

3. Demais. — A palavra homem, predicada de Deus, supõe a pessoa do Filho de Deus. Ora, é falsa a
proposição: Deus se fez a pessoa do Filho de Deus. Logo, é falsa também esta outra: Deus se fez homem.
Mas, em contrário, o Evangelho: O Verbo se fez carne. Ora, como diz Atanásio, o dito — O Verbo se fez
carne — é semelhante ao outro — Deus se fez homem.

SOLUÇÃO. — Dizemos que um ser é feito quando podemos lhe atribuir uma qualificação nova. Ora, ser
homem verdadeiramente se predica de Deus, como dissemos. Mas, no sentido em que não convém a
Deus ser homem abeterno, senão só temporalmente, pela assunção da natureza humana. Logo, é
verdadeira a proposição — Deus se fez homem. Mas essa proposição – bem como a outra: Deus é
homem — diversos a entendem diversamente, como se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Fazer-se homem é fazer-se em sentido absoluto, para
todos aqueles nos quais a natureza humana começa a existir num suposto criado no tempo. Mas,
dizemos que Deus se fez homem, por ter a natureza humana começado a existir, no suposto da natureza
divina preexistente abeterno. Logo, o fazer-se Deus, homem, não é fazer-se absolutamente falando.

RESPOSTA À SEGUNDA. — Como dissemos ser feito implica uma predicação nova atribuída a um ser.
Por onde, sempre que uma predicação nova é atribuída a um ser, implicando neste uma mudança,
fazer-se é mudar-se. E isto se aplica a tudo o que se diz em sentido absoluto; assim, não pode a brancura
ou a negrura ser uma atribuição nova de um sujeito, senão porque este sofreu uma mudança no sentido
da brancura ou da cor negra. As predicações relativas, porém, podem começar a ser atribuídas a um
sujeito, sem nenhuma mudança deste; assim um homem poderá passar à direita sem sofrer nenhuma
mudança pelo movimento do que passou à esquerda. E tais casos, não implicam nenhuma mudança
naquilo de que se diz que foi feito; pois, isto pode resultar da mudança de outro ser. E é nesse sentido
que dizemos a Deus: Senhor, tu tens sido o nosso refúgio. — Ora, ser homem convém a Deus em virtude
da união, que é uma relação. Por onde, ser homem começa a ser predicado de Deus, sem nenhuma
mudança nele, por mudança da natureza humana, assumida na Pessoa divina. E assim, quando dizemos
— Deus se fez homem — não implica isso nenhuma mudança por parte de Deus; mas só da parte da
natureza humana.

RESPOSTA À TERCEIRA. — Homem supõe a pessoa do Filho de Deus, não pura e simples, mas enquanto
subsistente em a natureza humana. Por onde, embora seja falsa a proposição — Deus se fez a pessoa do
Filho de Deus — contudo é verdadeira esta outra — Deus se fez homem — por se ter unido à natureza
humana.

## Art. 7 — Se é verdadeira a proposição: o homem foi feito Deus.
O sétimo discute-se assim. — Parece verdadeira a proposição: o homem foi feito Deus.

1. — Pois, diz a Escritura: O que tinha ele antes prometido pelos seus profetas nas Santas Escrituras
sobre seu Filho, .que lhe foi feito da linhagem de Davi segundo a carne. Ora, Cristo enquanto homem, é
da raça de Davi segundo a carne. Logo, o homem se fez filho de Deus.

2. Demais. — Agostinho diz: Foi tal aquela assunção, que fez Deus homem e o homem, Deus. Ora, em
virtude dessa assunção, é verdadeira a proposição: Deus se fez homem. Logo e semelhante, é
verdadeira a proposição; o homem foi feito Deus.

3. Demais. — Gregório Nazianzeno diz: Deus se humanou e o homem ficou glorificado, ou seja como for
que o digamos. Ora, dizemos que Deus se humanou porque se fez homem. Logo, dizemos que o homem
foi deificado porque se fez Deus. Portanto, é verdadeira a proposição: o homem foi feito Deus.

4. Demais. — Quando dizemos — Deus foi feito homem — o sujeito da feitura ou da mutação não é
Deus, mas, a natureza humana, significada pelo nome de homem. Ora, é sujeito de uma feitura aquilo a
que ela é atribuída. Logo, a proposição — O homem foi feito Deus — é mais verdadeira que a outra —
Deus foi feito homem,
Mas, em contrário, Damasceno diz: Não dizemos que o homem foi deificado, mas que Deus foi
humanado. Ora, o mesmo é fazer-se Deus, que deificar-se. Logo, é falsa a proposição: O homem foi feito
Deus.

SOLUÇÃO. — A proposição — O homem foi feito Deus — pode ser entendida em três sentidos. Primeiro,
determinando o particípio feito, absolutamente, ou ao sujeito ou ao predicado. E então, a proposição é
falsa, porque nem o homem Cristo, de quem esse particípio se predica, foi feito, nem Deus foi feito,
como depois diremos, E, no mesmo sentido, é falsa a proposição — Deus foi feito homem. Mas, neste
sentido não se trata agora, dessas proposições.
Noutro sentido podemos entender — feito — como determinando toda a proposição, que significará
então — o homem foi feito Deus, isto é, foi feito que o homem seja Deus — como a outra — Deus foi
feito homem. Mas esse não é o sentido próprio dessas expressões, salvo se se entender que a palavra
homem não tem uma suposição pessoal, mas, simples. Pois, embora o homem Cristo não fosse feito
Deus, porque o suposto, isto é, a pessoa do Filho de Deus, era Deus abeterno, contudo o homem
comumente falando, não foi sempre Deus.
Num terceiro sentido, entende-se propriamente que o particípio supõe uma mudança sofrida pelo
homem, como o termo da ação de Deus. E neste sentido, admitido que, em Cristo, a pessoa, a hipóstase
e o suposto de Deus e do homem sejam os mesmos, como demonstramos, a referida proposição é falsa.
Pois, quando dizemos — O homem foi feito Deus — a palavra homem tem uma suposição pessoal.
Porque o ser Deus não se verifica do homem em razão da natureza humana, mas em razão do seu
suposto. Ora, esse suposto da natureza humana, a que se atribui com verdade o nome de Deus, é
idêntico à hipóstase ou à pessoa do Filho de Deus, que foi sempre Deus. Por isso, não podemos dizer
que o homem Cristo começou a ser Deus, ou que se faça Deus, ou que foi feito Deus.
Se, porém, fosse uma a pessoa ou a hipóstase de Deus e do homem, de modo que ser Deus fosse
predicado do homem e inversamente, por uma certa união dos supostos, ou da dignidade pessoal, ou
do afeto, eu da habitação, como diziam os Nestorianos, então pela mesma razão, poderíamos dizer que
o homem foi feito Deus, isto é, foi unido a Deus, como também que Deus foi feito homem, isto é, foi
unido ao homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nas palavras do Apóstolo citadas, o relativo que,
referente à pessoa do Filho de Deus, não deve ser entendido como aplicado ao predicado, como se
Cristo descendente de Davi, segundo a carne, fosse feito Deus — sentido em que a objeção procederia.
Mas deve ser entendido em relação ao sujeito, sendo o sentido: O Filho de Deus foi feito para ele (isto é,
para a honra do Pai, como expõe a Glosa), descendente da raça de Davi segundo a carne; como se
dissesse — O Filho de Deus- foi feito revestido de carne, da raça de Davi, para a honra de Deus.

RESPOSTA À SEGUNDA. — As palavras citadas de Agostinho, devem entender-se como significando que,
da assunção da Encarnação, resultou que o homem se tornou Deus e Deus, homem. E nesse sentido
ambas as locuções são verdadeiras, como se disse.
E o mesmo devemos RESPONDER À TERCEIRA OBJEÇÃO. — Pois, ser deificado é o mesmo que ser feito
Deus.

RESPOSTA À QUARTA. — Quando o termo reside no sujeito, é tomado materialmente, isto é, pelo
suposto; mas quando reside no predicado, é tomá-lo formalmente, isto é, pela natureza significada. Por
onde, quando dizemos — o homem foi feito Deus — o ser feito não se atribui à natureza humana, mas
ao suposto da natureza humana, o qual é Deus abeterno e, portanto, não lhe convém o ser feito Deus.
Mas quando dizemos Deus foi feito homem – entende-se que o ser feito tem o seu termo na natureza
humana. E por isso, propriamente falando, é verdadeira a proposição — Deus se fez homem; mas é falsa
esta outra: o homem foi feito Deus. Assim se Sócrates, tendo sido, primeiro, homem, se tornou branco,
é verdadeira esta proposição de quem, mostrando Sócrates, dissesse: Este homem hoje foi feito branco;
mas seria falso dizer: Este branco hoje foi feito homem. Se, porém, se aplicasse ao sujeito um nome
significativo da natureza humana em abstrato, poderia ser designado com sujeito da facção; como se se
dissesse que a natureza humana foi feita Filho de Deus.

## Art. 8 — Se é verdadeira a proposição; Cristo é uma criatura.
O oitavo discute-se assim. — Parece verdadeira a proposição – Cristo é uma criatura.

1. — Pois, diz Leão Papa: Nova e inaudita união — Deus, que é e era, torna-se criatura. Ora, podemos
predicar, de Cristo, que foi feito Filho de Deus pela Encarnação. Logo, é verdadeira a proposição: Cristo é
uma criatura.

2. Demais. — As propriedades de uma e outra natureza podem ser predicadas da hipóstase comum
delas, seja qual for o nome que a cada uma delas signifique, como se disse. Ora, é propriedade da
natureza humana ser criatura; assim como é propriedade da natureza divina ser Criador. Logo, ambas
estas coisas podemos dizer de Cristo: que é criatura e que é incriado e Criador.

3. Demais. — A alma é mais principal parte do homem do que o corpo. Ora, em razão do corpo, que
Cristo recebeu da Virgem, dizemos, absolutamente falando, que nasceu da Virgem. Logo, em razão da
alma, criada por Deus, devemos dizer, absolutamente falando, que Cristo é criatura.
Mas, em contrário, Ambrósio diz: Porventura foi o Cristo feito, com uma palavra? foi porventura criado
por um ato da vontade suprema? quase se respondesse – não. Por isso acrescenta: Como, pois, pode
Deus ser uma criatura? Pois, que a natureza de Deus é simples e não, composta. Logo, não devemos
conceder a proposição: Cristo é uma criatura.

SOLUÇÃO. — Como diz Jerônimo, palavras proferidas inconsideradamente podem-nos fazer incorrer em
heresia. Ora, não devemos ter nenhuma comunidade de expressão com os heréticos, para não
parecermos participar-lhes do erros. Ora, os heréticos Arianos diziam ser Cristo uma criatura e menor
que o Pai; não só em razão da natureza humana, mas ainda em razão da Pessoa divina. Por onde, não
devemos dizer, em sentido absoluto, que Cristo é uma criatura, ou menor que o Pai, senão em sentido
determinado, isto é, pela natureza humana. Mas, quando se trata de uma atribuição da qual nem ainda
podemos suspeitar que convenha à Pessoa divina em si mesma, podemos então em sentido absoluto
atribuí-la à natureza humana de Cristo; assim, absolutamente falando, dizemos que Cristo sofreu,
morreu e foi sepultado. Assim também, na ordem das coisas materiais e humanas, quando podemos
duvidar se uma atribuição convém ao todo ou à parte, se convém a uma parte não a aplicamos ao todo
em sentido absoluto, isto é, sem determinação; por isso não dizemos que um Etíope é branco, mas, de
dentes brancos. Dizemos porém, sem determinação, que é crespo, porque isto só lhe pode convir aos
cabelos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Às vezes os santos doutores, por brevidade, aplicam a
palavra criatura a Cristo sem nenhuma determinação. Mas devemo-la subentender nas expressões
deles.

RESPOSTA À SEGUNDA. — Todas as propriedades da natureza humana, como da divina, podem de certo
modo ser atribuídas a Cristo. Por isso diz Damasceno: Cristo que é Deus e homem, é chamado criável e
incriável, passível e impassível. Contudo, expressões duvidosas em relação a qualquer das suas
naturezas, não se lhe devem aplicar sem restrição. Por isso, a seguir, o mesmo doutor acrescenta: A sua
hipóstase única é, em si mesma, incriada, pela divindade, e criada, pela humanidade. Assim como e ao
inverso, não devemos dizer sem restrição — Cristo é incorpóreo — ou — impassível — para evitar o erro
de Maniqueu, que ensinava não ter Cristo um verdadeiro corpo nem ter verdadeiramente sofrido. Mas
devemos dizer, em sentido restrito, que Cristo, pela sua divindade, é incorpóreo e impassível.

RESPOSTA À TERCEIRA. — Não podemos de modo nenhum duvidar que a natividade, da Virgem,
convenha à pessoa do Filho de Deus; como podemos, que lhe convenha a criação. Logo, não há paridade
em ambos esses casos.

## Art. 9 — Se referente a Cristo, é verdadeira a proposição: o homem começou a existir.
O nono discute-se assim. Parece verdadeira a proposição, referente a Cristo: o homem começou a
existir.
1 — Pois, diz Agostinho: Antes de existir o mundo, nem nós existíamos, nem o mediador entre Deus e os
homens – o homem Jesus Cristo. Ora, o que não existiu sempre, começou a existir. Logo, o homem, com
referência a Cristo, começou a existir.

2. Demais. — Cristo começou a ser homem. Ora, ser homem é existir em sentido absoluto. Logo, o
homem Cristo começou a existir absolutamente falando.

3. Demais. — Homem implica o suposto da natureza humana. Ora, Cristo nem sempre foi suposto da
natureza humana. Logo, o homem Cristo começou a existir.
Mas, em contrário, o Apóstolo: Jesus Cristo era ontem e é hoje; o mesmo também será por todos os
séculos.

SOLUÇÃO. — Não se pode dizer, sem acrescentar nenhuma restrição, que o homem Cristo começou a
existir. E isto por duas razões. — Primeiro, porque essa afirmação é falsa, absolutamente falando,
segundo a doutrina da fé católica, que nos ensina haver em Cristo um suposto e uma hipóstase, assim
como uma só pessoa. Neste sentido, pois, quando aplicamos a palavra homem a Cristo, designamos um
suposto eterno, a cuja eternidade repugna tenha começado a existir. Por isso, é falsa a proposição: O
homem Cristo começou a existir. Nem obsta que o começar a existir convenha à natureza humana,
expressa pela palavra homem; pois, o termo atribuído ao sujeito não é tomado formalmente pela
natureza mas antes, formalmente, pelo suposto, como dissemos. — Segundo, porque mesmo se essa
proposição fosse verdadeira, nem por isso deveríamos usar dela, sem restrição, para evitar heresia de
Ario que, assim como atribui à pessoa do Filho de Deus o ser criatura, e menor que o Pai, assim também
lhe atribui o começar a existir, dizendo que existia quando não existia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lugar citado se entende em sentido restrito,
significando que o homem Jesus Cristo não existia, na sua humanidade, antes de existir o mundo.

RESPOSTA À SEGUNDA. — O Verbo começar não nos autoriza a argumentar do inferior para o superior.
Pois, não há sequência se dissermos: Isto começou a ser branco, logo começou a ser colorido. Porque
começar implica em existir num determinado tempo e não, antes. Assim, não há sequência neste
raciocínio: Isto antes não era branco, logo não era antes colorido. Ora, existir, em sentido absoluto, é
superior ao homem. Logo, não há sequência no raciocínio: Cristo começou a ser homem, logo, começou
a existir.

RESPOSTA À TERCEIRA. — O nome de homem, quando tomado por Cristo, embora signifique a natureza
humana, que começou a existir, contudo implica um suposto eterno, que não o começou. Por onde,
quando atribuído ao sujeito, é tomado pelo suposto; e quando atribuído ao predicado, refere-se à
natureza. E por isso: é falsa a proposição — O homem Cristo começou a existir; mas é verdadeira esta
outra: Cristo começou a ser homem.

## Art. 10 — Se é falsa a proposição – Cristo, enquanto homem, é criatura, ou começou a existir.
O décimo discute-se assim. — Parece falsa a proposição: Cristo, enquanto homem, é criatura, ou,
começou a existir.

1. — Pois, nada há de criado em Cristo, senão a natureza humana. Ora, é falsa a proposição: Cristo,
enquanto homem é a natureza humana. Logo, também esta outra o é: Cristo, enquanto homem, é
criatura.

2. Demais. — O predicado se aplica mais estreitamente a um termo restritivo do sujeito do que ao
próprio sujeito da proposição. Assim, se dissermos — o corpo, enquanto colorido, é visível — segue-se
que o colorido é visível. Ora, como foi dito, não podemos conceder em sentido absoluto a proposição —
o homem Cristo é uma criatura. Logo, nem esta: Cristo enquanto homem é criatura.

3. Demais. — Tudo o predicado de um homem, como tal, é dele predicado essencial e absolutamente;
pois, falar de uma coisa, considerada como tal e de maneira essencial, é o mesmo; como diz Aristóteles.
Ora, é falsa a proposição: Cristo é, em si e absolutamente considerado, criatura. Logo, também esta
outra é falsa: Cristo, enquanto homem, é criatura.
Mas, em contrário. — Tudo o existente ou é o Criador ou é criatura. Ora, é falsa a proposição: Cristo,
enquanto homem, é Criador. Logo é verdadeira a outra: Cristo, enquanto homem, é criatura.

SOLUÇÃO. — Quando dizemos — Cristo, enquanto homem — a palavra homem. pode ser retomada na
explicação, em razão do suposto ou em razão da natureza. Se for em razão do suposto, sendo o suposto
da natureza humana em Cristo eterno e incriado, será falsa a proposição: Cristo, enquanto homem, é
criatura. Se porém o for em razão da natureza humana, então é verdadeira; pois, em razão da natureza
humana, ou segundo a natureza humana, convêm-lhe ser criatura, como dissemos.
Devemos porém saber, que o nome, assim retomado na explicação, mais propriamente é tomado pela
natureza que pelo suposto; pois, é reaplicado com força de predicado, que é tomado formalmente. Pois,
a expressão — Cristo enquanto homem — equivale a esta — Cristo, segundo é homem. Logo, mais é
para conceder que para negar a proposição: Cristo, segundo é homem, é uma criatura. Se, porém,
fizéssemos alguns acréscimo, por onde o termo se referisse ao suposto, a proposição deveríamos antes
negá-la que concedê-la; por exemplo, se dissessemos: Cristo, enquanto um determinado homem, é uma
criatura.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora Cristo não seja a natureza humana, contudo
tem a natureza humana. Ora, o nome de criatura, por natureza, se predica não só em abstrato, mas
ainda em concreto; assim, dizemos que a humanidade é criatura, e que o homem é uma criatura.

RESPOSTA À SEGUNDA. — A palavra homem, aplicada ao sujeito, mais se refere ao suposto; mas,
quando usada em sentido restritivo, refere-se, antes, à natureza, como se disse. Ora, sendo a natureza
criada, e o suposto incriado, embora não concedamos em sentido absoluto a proposição — Este homem
não é criatura concedemos porém esta outra: Cristo, segundo é homem, é criatura.

RESPOSTA À TERCEIRA. — A todo homem, que é suposto só da natureza humana, é lhe natural não
existir senão segundo a natureza humana. Por onde, de qualquer suposto tal segue-se, se segundo é
homem é uma criatura, que é criatura absolutamente falando. Ora, Cristo, não somente é o suposto da
natureza humana, mas também da divina, segundo a qual tem o ser incriado. Donde, pois, não se segue,
se, enquanto homem é uma criatura, que o seja absolutamente falando.

## Art. 11 — Se Cristo, enquanto homem, é Deus.
O undécimo discute-se assim. — Parece que Cristo, enquanto homem, é Deus.

1. — Pois, Cristo é Deus pela graça da união. Ora, Cristo, enquanto homem, tem a graça da união. Logo,
Cristo, enquanto homem, é Deus.

2. Demais. — Perdoar os pecados é próprio de Deus, segundo a Escritura: Eu. sou, eu mesmo sou o que
apago as tuas iniquidades por amor de mim. Ora, Cristo, enquanto homem, perdoa os pecados,
conforme o diz o Evangelho: Pois, para que saibais que o Filho do homem tem poder sobre a terra de
perdoar pecados, etc. Logo, Cristo, enquanto homem, é Deus.

3. Demais. — Cristo não é homem, em geral, mas este determinado homem. Ora, Cristo, enquanto este
determinado homem, é Deus; pois, este homem determinado designa um suposto eterno que, por
natureza, é Deus. Logo, Cristo, enquanto homem, é Deus.
Mas, em contrário. — O conveniente a Cristo, enquanto homem, convém a qualquer homem. Se, logo,
Cristo, enquanto homem, fosse Deus, resultaria que todo homem seria Deus, o que evidentemente é
falso.

SOLUÇÃO. — A palavra homem, tomada em sentido restritivo, pode entender-se de dois modos. —
Primeiro, na sua natureza. E então, não é verdade que Cristo, enquanto homem, seja Deus; porque a
natureza humana é distinta da divina, por uma diferença de natureza. — Noutro sentido, pode ser
entendida em razão do suposto. E então, sendo o suposto da natureza humana, em Cristo, a pessoa do
Filho de Deus, a que convém por natureza ser Deus, é verdade que Cristo, enquanto homem, é Deus.
Como porém o termo, tomado em sentido restritivo, mais propriamente significa a natureza, que o
suposto, como se disse, por isso, a proposição — Cristo, enquanto homem, é Deus — deve antes ser
negada que afirmada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não é pela mesma razão que um ser se move para um
termo e constitui esse termo; pois, um ser se move em razão da matéria ou do sujeito; e é atual, em
razão da forma. Semelhantemente, não convém a Cristo, à mesma luz, ordenar-se a ser Deus pela graça
da união, e ser Deus. Mas, aquilo lhe convém, segundo a natureza humana; e isto, segundo a divina. Por
onde, é verdadeira a proposição — Cristo, enquanto homem, tem a graça da união; mas não esta —
Cristo, enquanto homem, é Deus.

RESPOSTA À SEGUNDA. — O Filho do homem tem na terra o poder de perdoar os pecados, não em
virtude da natureza humana, mas, da natureza divina. Dessa natureza divina promana o poder de
perdoar os pecados por autoridade própria; ao passo que a natureza humana exerce a função de
instrumento e de ministro. Donde, expondo esse assunto, o dizer Crisóstomo: O Evangelho disse
sinaladamente — na terra, de perdoar os pecados — para mostrar que à natureza humana uniu, por
uma união indivisível, o poder da divindade. Pois, embora feito homem, continuou sendo o Verbo de
Deus.

RESPOSTA À TERCEIRA. — Quando se diz — este homem — o pronome demonstrativo liga a palavra
homem – ao suposto. Por isso, a proposição — Cristo, enquanto este homem, é Deus, é mais verdadeira
que a outra — Cristo enquanto homem é Deus.

## Art. 12 — Se Cristo, enquanto homem, é hípóstase ou pessoa.
O duodécimo discute-se assim. — Parece que Cristo, enquanto homem, é hipóstase ou pessoa.
1 — Pois, o conveniente a qualquer homem convém a Cristo, enquanto homem. Porque é semelhante
aos outros homens, conforme à Escritura: Fazendo-se semelhante aos homens. Ora, todo homem é
pessoa. Logo, Cristo, enquanto homem, é pessoa.

2. Demais. — Cristo, enquanto homem, é uma substância de natureza racional. Não porém uma
substância universal. Logo, uma substância individual. Ora, a pessoa não é senão uma substância
individual de natureza racional, como define Boécio. Logo, Cristo, enquanto homem é uma pessoa.
Mas, em contrário. — Cristo, enquanto homem, não é uma pessoa eterna. Se, pois, Cristo, enquanto
homem, é pessoa, segue-se que há em Cristo duas pessoas — uma temporal e outra eterna. O que é
errôneo, como se disse.

SOLUÇÃO. — Como dissemos, a palavra homem, tomada em sentido restritivo, pode significar o suposto
ou a natureza. Assim, pois, quando dizemos, Cristo, enquanto homem, é pessoa, se homem é tomado
como suposto, é manifesto que, enquanto homem, Cristo é pessoa; pois, o suposto da natureza humana
não é senão a pessoa do Filho de Deus. Se, porém, for tomado pela natureza, então é susceptível de
dupla interpretação. Num sentido, significa que à natureza humana é próprio existir numa pessoa. E
então, neste sentido também a proposição é verdadeira; pois tudo o subsistente em a natureza humana
é pessoa. Noutro sentido pode entender-se como significando que a natureza humana em Cristo tem
uma personalidade própria causada pelos princípios da natureza humana. E então Cristo enquanto
homem, não é pessoa; porque a natureza humana não subsiste por si, separadamente da natureza
divina, ao contrário do que exige a noção de pessoa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todo homem é propriamente pessoa, porque é pessoa
todo o ser subsistente da natureza humana. Mas é próprio ao homem Cristo, que a pessoa subsistente
na sua natureza humana seja eterna e não causada pelos princípios da natureza humana. Por onde, é
pessoa, de um modo, enquanto homem; mas de outro modo não o é, como dissemos.

RESPOSTA À SEGUNDA. — A substância individual, posta na definição de pessoa, supõe uma substância
completa subsistente por si, separada das outras. Do contrário, a mão do homem podia chamar-se
pessoa, pois é uma certa substância individual; mas, por ser uma substância individual existente em
outra, não pode chamar se pessoa. Pela mesma razão, também não o pode a natureza humana em
Cristo, que contudo pode chamar-se indivíduo ou um ser particular.

RESPOSTA À TERCEIRA. — Assim como pessoa significa um ser completo e por si subsistente em a
natureza racional; assim também, a hipóstase, o suposto e um ser da natureza pertencente ao gênero
da substância significam um ente subsistente por si mesmo. Por onde, assim como a natureza humana
não é em si mesma uma pessoa separada da pessoa do Filho de Deus, assim também não é em si
mesma uma hipóstase ou um suposto ou um ser da natureza. E portanto, no sentido em que deve ser
negada a proposição — Cristo, enquanto homem, é pessoa — devem também sê-lo todas as outras.