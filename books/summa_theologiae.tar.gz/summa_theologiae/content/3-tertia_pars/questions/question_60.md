# Questão 60: Dos Sacramentos
Na primeira questão discutem-se oito artigos:

## Art. 1 — Se o sacramento é genericamente um sinal.
O primeiro discute-se assim. — Parece que o sacramento não é genericamente um sinal.

1. Pois a palavra sacramento vem de sacrar, como medicamento de medicar. Ora, essa noção implica
antes a idéia de causa que a de sinal. Logo, o sacramento é genericamente antes uma causa que um
sinal.

2. Demais. — Sacramento significa alguma coisa de oculto, segundo aquilo da Escritura: É bom conservar
escondido o sacramento do rei. E o Apóstolo diz: Qual seja a comunicação do sacramento escondido
desde os séculos em Deus. Ora, o escondido é contrário à idéia de sinal, pois, como diz Agostinho, sinal é
aquilo que sugere ao nosso pensamento uma realidade diferente da apreendida pelos sentidos. Logo,
parece que o sacramento não é genericamente um sinal.

3. Demais. — Às vezes o juramento é chamado sacramento. Assim, diz um Decretal: As crianças, ainda
sem o uso da razão, não sejam compelidas a jurar; e a que uma vez tiver perguntado, nem seja depois
disso testemunha, nem se achegue ao sacramento, isto é, ao juramento. Ora, o juramento não inclui
nenhuma idéia de sinal. Logo, parece que o sacramento não é genericamente um sinal.
Mas, em contrário, Agostinho diz: O sacrifício visível é o sacramento, isto é, o sinal sacro do sacrifício
invisível.

SOLUÇÃO. — Todas as coisas ordenadas a uma terceira, embora de modos diversos, podem receber
dessa a sua denominação. Assim, da sua saúde tira o apelativo de são não somente o animal, sujeito da
saúde, mas também — a medicina, sã enquanto efetiva da saúde; a dieta, enquanto conservadora dela,
e a urina, enquanto significativa da mesma. Do mesmo modo, podemos chamar sacramento ao que tem
em si uma santidade oculta, e então sacramento é o mesmo que segredo sacro; ou ao que se ordena de
certo modo a essa santidade como causa, ou o sinal ou segundo outra relação qualquer. E neste sentido
o sacramento é considerado genericamente como um sinal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A medicina se comporta como causa eficiente da saúde;
donde vem que tudo o que dela tira a sua denominação implica dependência de um agente primeiro; e
por isso o medicamento supõe de certo modo uma causalidade. Mas a santidade, onde haure o
sacramento o seu apelativo, não implica um sentido de causa eficiente, mas antes, o de causa formal ou
final. Por onde, não é necessário que o sacramento suponha sempre a causalidade.

RESPOSTA À SEGUNDA. — A objeção colhe, sendo sacramento o mesmo que sacro segredo. Assim,
chamamos secreto não só o que é de Deus, mas também dizemos que é sacro e sacramento o que
respeita a um rei. Porque os antigos denominavam santo ou sacramento tudo o que não era lícito violar;
tais os muros da cidade e as pessoas constituídas em dignidade. Por isso aqueles segredos, divinos ou
humanos, que a ninguém é lícito violar, publicando-os, chamam-se sacros ou sacramentos.

RESPOSTAS À TERCEIRA. — Também o juramento tem de certo modo relação com as coisas sagradas,
enquanto é uma espécie de contestação feita mediante algo de sagrado. Por isso dizemos que o
juramento é um sacramento não no mesmo sentido em que agora nos referimos aos sacramentos. Pois,
não é a denominação de sacramento tomada equivocamente, mas em sentido analógico, isto é,
segundo a diversidade de relação com um termo determinado, isto é, a causa sagrada.

## Art. 2 — Se todo sinal de uma coisa sagrada é sacramento.
O segundo discute-se assim. — Parece que nem todo sinal de uma coisa sagrada é sacramento.

1. Pois, todas as criaturas sensíveis são sinais de coisas sagradas, segundo aquilo do Apóstolo: As causas
invisíveis de Deus se vêem consideradas pelas obras que foram feitas. Mas nem por isso todas as causas
sensíveis podem chamar-se sacramentos. Logo, nem todo sinal de uma coisa sagrada é sacramento.

2. Demais. — Tudo o que se fazia na lei antiga figurava a Cristo, que é O Santo dos santos, segundo
aquilo do Apóstolo: Todas estas coisas lhes aconteciam a eles em figuras. E noutro lugar: Que são
sombras das causas vindouras, mas o corpo é em Cristo. Ora, nem todos os efeitos dos Patriarcas do
Antigo Testamento e nem todas as cerimônias da lei são sacramentos, mas só certas em especial, como
se disse na segunda Parte. Logo, parece que nem todo sinal de uma coisa sagrada é sacramento.

3. Demais. — Também ao regime do Novo Testamento muitos atos se praticam como sinal de uma coisa
sagrada, que contudo não se chamam sacramentos; tal a aspersão da água benta, a consagração do
altar e outras semelhantes. Logo, parece que nem todo sinal de uma coisa sagrada é sacramento.
Mas, em contrário, a definição se converte com a causa definida. Ora certos definem o sacramento
dizendo que é o sinal de uma coisa sagrada; e isso resulta também do lugar de Agostinho supra citado.
Logo parece que todo sinal de uma coisa sagrada é sacramento.

SOLUÇÃO. — Os homens se servem de sinais para, por meio do conhecido, chegar ao desconhecido. Por
onde, propriamente se chama sacramento ao sinal de uma coisa sagrada concernente aos homens; isto
é, propriamente se chamará sacramento, no sentido em que agora o vejamos, o sinal de uma coisa
sagrada enquanto santificadora dos homens.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. As criaturas sensíveis significam algo de sagrado, isto é, a
sabedoria e a bondade divinas, enquanto estas são em si mesmas sagradas; mas não enquanto nós nos
santifiquemos por meio delas. Por onde, não podem chamar-se sacramentos, no sentido em que agora
tratamos dos sacramentos.

RESPOSTA À SEGUNDA. — Certas cerimônias do Antigo Testamento significavam a santidade de Cristo,
enquanto ele em si mesmo é santo. Outras porem lhe significavam a santidade, enquanto por meio
delas nós nos santificamos; assim, a imolação do cordeiro pascal significava a imolação de Cristo, pela
qual fomos santificados. E essas cerimônias propriamente se chamam sacramentos da lei antiga.

RESPOSTA À TERCEIRA. — As coisas se denominam pelo seu fim e pelo seu complemento. Ora, a
disposição não é fim nem perfeição. Logo o que significa a disposição para a santidade não se chama
sacramento, no sentido em que se funda a objeção. Mas o que significa a perfeição da santidade
humana.

## Art. 3 — Se o sacramento não é sinal senão de uma só coisa.
O terceiro discute-se assim. Parece que o sacramento não é sinal senão de uma só coisa.

1. Pois, o que significa muitas coisas é um sinal ambíguo e, por consequência, ocasião de engano; tais os
nomes equívocos. Ora, nenhuma falácia pode se atribuir à religião cristã, segundo aquilo do Apóstolo:
Estai sobre aviso para que ninguém vos engane com filosofias e com os seus falaces sofismas. Logo,
parece que o sacramento não é sinal de várias coisas.

2. Demais. — Como se disse, o sacramento significa uma coisa sagrada enquanto causa de santificação
humana. Ora, uma só é a causa da santificação humana, a saber, o sangue de Cristo, segundo aquilo do
Apóstolo: Jesus, para que santificasse ao povo pelo seu sangue, padeceu fora da porta. Logo, parece que
o sacramento não significa várias coisas.

3. Demais. — Como se disse, o sacramento significa propriamente o fim mesmo da santificação. Ora, o
fim da santificação é a vida eterna, segundo o Apóstolo: Tendes o vosso fruto em santificação e por fim
a vida eterna. Logo, parece que o sacramento não significa senão uma só coisa, isto é, a vida eterna.
Mas, em contrário, o sacramento do Altar tem dupla significação — o corpo de Cristo verdadeiro e
místico, como diz Agostinho.

SOLUÇÃO. — Como dissemos, o sacramento propriamente se chama o que se ordena a significar a
nossa santificação. Na qual podemos distinguir tríplice elemento: a causa mesma da nossa santificação
que é a Paixão de Cristo; a forma da nossa santificação, que consiste na graça e nas virtudes; e o fim
último da nossa santificação, que é a vida eterna. E tudo isto os sacramentos o significam. Por isso o
sacramento é: o sinal rememorativo do que passou, isto é, da Paixão de Cristo; e demonstrativo do que
em nós obra a Paixão de Cristo, isto é, da graça; e prognóstico, isto é, prenunciativo da futura glória.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O sinal ambíguo é ocasião de engano, quando significa
muitas coisas, das quais uma não se ordena à outra. Mas, quando significa muitas mas de modo que
constituam de certo modo uma unidade, então o sinal não é ambíguo, mas certo. Assim, a palavra
homem significa a alma e o corpo, enquanto constitutivos da natureza humana. E, dest'arte, o
sacramento tem a tríplice significação deferida, enquanto há aí a unidade, numa certa ordem.

RESPOSTA À SEGUNDA. — O sacramento, enquanto significativo da coisa santificante, há de
necessariamente significar o efeito, compreendido da causa mesma santificante, como tal.

RESPOSTA À TERCEIRA. — O sacramento, na sua noção, baste que signifique a perfeição, como, forma;
nem é necessário signifique só a perfeição, como fim.

## Art. 4 — Se um sacramento é sempre uma realidade sensível.
O quarto discute-se assim. — Parece que um sacramento nem sempre é uma realidade sensível.

1. Porque, segundo o Filósofo, todo efeito é sinal da sua causa. Ora, como há certos efeitos sensíveis, há
também certos inteligíveis; assim a ciência, efeito da demonstração. Logo, nem todo sinal é sensível.
Ora, para um sacramento existir basta seja o sinal de uma coisa sagrada pela qual o homem se
santifique, conforme se disse. Logo, não é necessário seja um sacramento nenhuma realidade sensível.

2. Demais. — Os sacramentos dizem respeito ao culto ou ao reino de Deus. Ora, as coisas sensíveis não
respeitam ao culto de Deus, segundo aquilo do Evangelho: Deus é espírito e em espírito e verdade é que
o devem adorar os que o adoram. E o Apóstolo: O reino de Deus não é comida nem bebida. Logo, não é
necessário seja o sacramento uma realidade sensível.

3. Demais. — Agostinho diz, que as coisas sensíveis são os mínimos bens, sem os quais o homem pode
viver rectamente. Ora, os sacramentos são necessários à salvação do homem como a seguir se dirá, e
portanto não pode o homem viver bem sem eles. Logo, não é preciso que os sacramentos sejam
realidades sensíveis.
Mas, em contrário, Agostinho diz: Acrescenta-se a palavra ao elemento e nasce o sacramento. E refere-
se nesse lugar à água, elemento sensível. Logo, os sacramentos supõem coisas sensíveis.

SOLUÇÃO. — A sabedoria divina provê a cada coisa conforme à natureza desta; por isso diz a Escritura,
que dispõe tudo com suavidade. Donde a expressão do Evangelho: Deu a cada um segundo a sua
capacidade. Ora, é conatural ao homem chegar, por meio das coisas sensíveis ao conhecimento das
inteligíveis. Ora, o sinal é o meio de chegarmos a um conhecimento ulterior. E assim, sendo as coisas
sagradas, significadas pelos salvamentos, uns bens espirituais e inteligíveis pelos quais o homem se
santifica, resulta por conseqüência, que a significação do sacramento se manifesta completamente
mediante certas coisas sensíveis. Assim também é pela semelhança das coisas sensíveis que a divina
Escritura nos descreve as coisas espirituais. Por isso é que os sacramentos requerem as coisas sensíveis,
como também o prova Dionísio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um ser é denominado e definido principalmente pelo
que lhe convém primária e essencialmente e não pelo que acidentalmente lhe convém. Ora, a essência
do efeito sensível, como sendo o que o homem conhece primária e essencialmente, é levá-lo a um
conhecimento ulterior, pois, todo o nosso conhecimento nasce dos sentidos. Ora, nos efeitos inteligíveis
não está o poderem conduzir a um conhecimento ulterior senão enquanto manifestados por outros
meios, que são as realidades sensíveis. Donde vem que primária e principalmente se chamam sinais os
que nos afetam os sentidos; por isso diz Agostinho que sinal é aquilo que sugere ao nosso pensamento
uma realidade diferente da apreendida pelos sentidos. Ora, os efeitos inteligíveis não têm a natureza de
sinal, senão enquanto manifestados por certos sinais. E também deste modo certas coisas que não são
sensíveis se chamam de algum modo sacramentos, enquanto significados por meio de realidades
sensíveis, do que mais adiante se tratará.

RESPOSTA À SEGUNDA. — As coisas sensíveis, consideradas em sua natureza, não concernem ao culto
ou ao reino de Deus; mas só enquanto sinais das coisas espirituais, nas quais consiste o reino de Deus.

RESPOSTA À TERCEIRA. — Agostinho se refere às coisas sensíveis consideradas em a natureza delas; não
porém quando assumidas a significar as coisas espirituais, que são os máximos bens.

## Art. 5 — Se os sacramentos implicam coisas determinadas.
O quinto discute-se assim. — Parece que os sacramentos não implicam coisas determinadas.

1. Pois, as coisas sensíveis são usadas, nos sacramentos, como meios de significar, conforme se disse.
Ora, nada impede diversas coisas sensíveis significarem a mesma realidade; assim, na Sagrada Escritura
Deus é significado, metaforicamente umas vezes pela pedra, outras pelo leão, outras pelo solou por
coisas semelhantes. Logo, parece que coisas diversas podem convir ao mesmo sacramento. Portanto, os
sacramentos não implicam coisas determinadas.

2. Demais. — Mais necessária é a salvação da alma que a do corpo. Ora, dos remédios materiais,
ordenados à saúde do corpo, um pode ser usado na falta de outro. Logo e com maior razão, nos
sacramentos, remédios espirituais ordenados à salvação da alma pode ser usada uma coisa, em falta de
outra.

3. Demais. — A salvação do homem não deve ser dificultada pela lei divina; e sobretudo pela lei de
Cristo, que veio salvar a todos. Ora, na condição da lei da natureza não eram necessárias, para os
sacramentos, nenhumas coisas determinadas, mas estas eram tomadas em virtude de um voto. Assim,
como lemos na Escritura, Jacó obrigou-se por voto a oferecer a Deus dízimos e hóstias pacíficas. Logo,
parece que não devia o homem ficar adstrito a usar, na ministração dos sacramentos, coisas
determinadas, sobretudo no regime da lei nova.
Mas, em contrário, diz ó Senhor: Quem não renascer da água e do Espírito Santo não pode entrar no
reino de Deus.

SOLUÇÃO. — No uso dos sacramentos, duas coisas podemos considerar: o culto divino e a nossa
santificação. Dessas, a primeira concerne ao homem relativamente a Deus; e a segunda, a Deus,
relativamente ao homem. Ora, a ninguém pertence determinar o que depende do poder de outrem,
mas só o que depende do poder próprio. Ora, a salvação do homem, dependendo do poder de Deus,
que o santifica não nos pertence a nós, de nosso próprio juízo, escolher as coisas com que nos
santifiquemos; mas deve ser determinado por instituição divina. Por isso nos sacramentos da lei nova,
com que os homens se santificam, segundo aquilo do Apóstolo. — Haveis sido lavados, haveis sido
santificados é necessário usar de coisas determinadas por divina instituição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Uma mesma coisa pode ser significada por sinais diversos;
mas ao agente que usa do sinal pertence determinar o sinal a ser usado para significar. Ora, Deus foi
quem nos significou as coisas espirituais por meio das coisas sensíveis, nos sacramentos, e pelas
palavras similitudinares nas Escrituras. Por onde, assim como por juízo do Espírito Santo foi
determinado por que semelhanças, em certos lugares da Escritura as causas espirituais fossem
significadas; assim também deve ser determinado por instituição divina que causas devam ser tomadas
para significar, neste ou naquele sacramento.

RESPOSTA À SEGUNDA. — As causas sensíveis têm virtudes em si naturalmente infundidas e
apropriadas à saúde do corpo; por isso não importa se duas delas tenham a mesma virtude, de que nos
sirvamos. Mas, a santificarem não se ordenam por nenhuma virtude que lhes seja naturalmente infusa,
mas só por instituição divina. Por isso foi necessário ser determinado por Deus que coisas sensíveis se
devem usar, na ministração dos sacramentos.

RESPOSTA À TERCEIRA. — Como diz Agostinho, a sacramentos diversos concernem tempos diversos;
assim como também por palavras diversas são significados tempos diversos, a saber, o presente, o
pretérito e o futuro. Por onde, assim como na condição da lei natural os homens eram levados a adorar
a Deus, não por qualquer lei que lhes fosse imposta de fora, mas só pela inspiração interior, assim
também por uma inspiração interior lhes era determinado de que coisas sensíveis usassem para o culto
de Deus. Mas depois foi necessário dar-lhes também uma lei externa, quer por ter, o pecado dos
homens obscurecido a lei da natureza; quer ainda para significar mais expressamente a graça de Cristo,
pela qual o gênero humano se santifica. E por isso também foi necessário determinar as coisas de que os
homens usassem, nos sacramentos. Nem por isso, contudo, se dificulta a via à salvação; pois, as coisas
cujo uso é necessário nos sacramentos, ou se encontram em toda parte ou podem ser obtidas com
emprego de pequeno esforço.

## Art. 6 — Se para significar os sacramentos são necessárias palavras.
O sexto discute-se assim. — Parece que para significar os sacramentos não são necessárias palavras.

1. — Pois, diz Agostinho: Que outra coisa, são os sacramentos corpóreos senão umas como palavras
visíveis? E assim acrescentar palavras às coisas sensíveis, nos sacramentos, é acrescentar palavras a
palavras. Ora, isso é supérfluo. Logo não é necessário que, nos sacramentos, sejam as palavras
acrescentadas às coisas sensíveis.

2. Demais. — Um sacramento, é uma certa unidade. Ora, de coisas de gêneros diversos não pode
resultar nenhuma unidade. Pertencendo, pois, as coisas sensíveis e as palavras a gêneros diversos,
porque as coisas sensíveis provêm da natureza, e as palavras da razão parece que nos sacramentos não
é necessário acrescentar as palavras às coisas sensíveis.

3. Demais. — Os sacramentos da lei nova sucederam aos da antiga; pois, desaparecidos aqueles, foram
institui dos estes, como ensina Agostinho. Ora, nos sacramentos da lei antiga não era necessária
nenhuma forma de palavras. Logo, nem nos sacramentos da lei nova o são.
Mas, em contrário, o Apóstolo: Cristo amou a Igreja e por ela se entregou a si mesmo, para a santificar
purificando-a no batismo da água pela palavra da vida. E Agostinho diz: Acrescentou-se a palavra ao
elemento e nasceu o sacramento.

SOLUÇÃO. — Os sacramentos como foi dito, se aplicam à santificação dos homens, como uns sinais. Por
isso pode ser considerados a tríplice luz, e de qualquer modo convém-lhes que se acrescentem as
palavras às coisas sensíveis. — Assim, primeiro, podem ser considerados em relação à causa santificante
que é o Verbo encarnado, ao qual o sacramento de certo modo se conforma por ser acrescentada a
palavra à coisa sensível, como no mistério da Encarnação o Verbo de Deus se uniu à carne sensível. —
Segundo, podem ser considerados os sacramentos relativamente ao homem que se santifica, composto
de alma e de corpo; — ao qual se proporciona o remédio sacramental que, por meio de uma coisa
visível toca o corpo e é crido pela alma por meio da palavra. Por isso, àquilo do Evangelho — Vós já
estais puros em virtude da palavra etc., diz Agostinho: Donde vem essa tão grande virtude da água, de
tocar o corpo e purificar o coração, senão causada pelo verbo, não enquanto proferido, mas enquanto
crido? Terceiro, podem ser considerados relativamente à própria significação sacramental. Assim, como
diz Agostinho, as palavras obtiveram entre os homens o principado no significar; porque as palavras
podem ser formadas diversamente para significar os diversos conceitos da mente, donde vem que pelas
palavras podemos mais distintamente exprimir o que na mente concebemos. Por isso, para a perfeição
da significação sacramental foi necessário que a significação das coisas sensíveis fosse determinada por
certas palavras. Assim a água pode significar tanto a ablução, por causa da sua humildade, como o
refrigério por causa da sua frigidez. Mas quando dizemos — Eu te batizo — manifestamos que usamos
da água no batismo para significar a purificação espiritual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. As coisas visíveis dos sacramentos se chamam palavras por
uma certa semelhança; isto é, enquanto participam de uma certa virtude significativa, que
principalmente está nas palavras mesmo, como se disse. Por isso não há supérflua duplicação de
palavras quando nos sacramentos o verbo se acrescenta às coisas visíveis; pois, uma dessas realidades é
determinada pela outra.

RESPOSTA À SEGUNDA. — Embora as palavras e as outras coisas sensíveis sejam de gênero diverso, no
concernente à natureza delas, contudo convêm pelo modo de significar, mais perfeito nas palavras do
que nas outras coisas. Por isso, das palavras e das coisas resulta de certo modo uma unidade nos
sacramentos, como da forma e da matéria; isto é, enquanto que pelas palavras se completa a
significação das coisas, como se disse. Pois, nas palavras também se compreendem os próprios atos
sensíveis, como a ablução, a unção e outros semelhantes; porque têm elas o mesmo modo de significar
que as coisas.

RESPOSTA À TERCEIRA. — Como diz Agostinho, uns são os sacramentos da realidade presente e outros
os da futura. Assim, os sacramentos da lei antiga eram o prenúncio de Cristo que devia vir. Por isso não
significavam a Cristo de modo tão expressivo como os sacramentos da lei nova, que emanam do próprio
Cristo, e encerram em si mesmos uma certa semelhança, como se disse. — Na vigência da lei antiga,
porém usavam de certas palavras, no atinente ao culto de Deus, tanto os sacerdotes, que eram os
ministros desses sacramentos, segundo aquilo da Escritura — Assim abençoareis os filhos de Israel e
lhes direis: O Senhor te abençoe, etc.; como também os que se serviam desses sacramentos, segundo
aquele outro lugar: Confesso hoje diante do Senhor teu Deus, que, etc.

## Art. 7 — Se os sacramentos exigem palavras determinadas.
O sétimo discute-se assim. — Parece que os sacramentos não exigem palavras determinadas.

1. — Pois, como diz o Filósofo as palavras não são as mesmas para todos. Ora, a salvação que
alcançamos por meio dos sacramentos, é a mesma para todos. Logo, os sacramentos não exigem
palavras determinadas.

2. Demais. — Os sacramentos implicam a palavra, cuja principal função dela é ser significativa, como se
disse. Ora, diversas palavras podem significar a mesma coisa. Logo, os sacramentos não exigem palavras
determinadas.

3. Demais. — A corrupção de um ser muda-lhe a espécie. Ora, certos proferem corruptamente as
palavras, mas nem por isso se crê que fica impedido o efeito dos sacramentos; do contrário os iletrados
e os gagos, que conferissem os sacramentos, frequentemente introduziram defeitos neles. Logo, parece
que os sacramentos não requerem palavras determinadas.
Mas, em contrário, o Senhor proferiu palavras determinadas na consagração do sacramento da
Eucaristia, dizendo: Este é o meu corpo. Semelhantemente, também mandou aos discípulos batizarem
sob uma determinada forma de palavras, conforme está no Evangelho: Ide e ensinai a todas as gentes,
batizando-as em nome do Padre e do Filho e do Espírito Santo.

SOLUÇÃO. — Como dissemos, nos sacramentos as palavras desempenham o papel de forma, e as coisas
sensíveis o de matéria. Ora, em todos os seres compostos de matéria e forma, o princípio da
determinação procede da forma, que é de certo modo o fim e o termo da matéria. Por isso, um ser, na
sua essência, implica mais principalmente uma forma determinada, que uma determinada matéria; pois,
a matéria determinada é necessário seja proporcionada a uma determinada forma. Ora como os
sacramentos requerem determinadas coisas sensíveis, que neles desempenham o papel de matéria,
com muito maior razão exigem uma determinada forma de palavras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Como diz Agostinho, a palavra opera nos sacramentos, não
por serem proferidas, isto é, não pelo som exterior da voz, mas por serem cridas, isto é, pelo sentido
delas, apreendido pela fé. Ora, esse sentido é o mesmo para todos, embora as palavras não tenham o
mesmo som. Por onde, o sacramento se perfaz, uma vez existente o referido sentido das palavras,
qualquer que seja a língua.

RESPOSTA À SEGUNDA. — Embora em qualquer língua palavras diversas possam significar a mesma
coisa, sempre contudo uma dessas palavras é a que mais principal e comumente usam os que falam a
língua, para significar tal coisa. E essa deve ser a palavra empregada na significação do sacramento.
Assim como também dentre as coisas sensíveis tornamos aquela, para a significação do sacramento,
cujo uso é mais comum, para exprimir o ato pelo qual é significado o efeito do sacramento. Tal a água,
de que os homens usam mais comumente para lavar o corpo, o que significa a ablução espiritual; por
isso foi à água escolhida como a matéria do batismo.

RESPOSTA À TERCEIRA. — Quem profere corruptas as palavras sacramentais, se por indústria o fizer,
não intenciona fazer o que faz a Igreja e, portanto não consuma o sacramento. Se o fizer, porém por
erro ou lapso da língua e for a corruptela tanta que prive totalmente de sentido a locução, não perfaz o
sacramento. E isto, sobretudo se dá quando a corruptela está no princípio da dicção; tal o caso de quem
em vez de dizer — em nome do Padre, dissesse — em nome da mãe. – Se, porém a referida corruptela
não privar totalmente de sentido a locução, então perfaz-se o sacramento. O que, sobretudo acontece
quando a corruptela vem no fim; por exemplo: se alguém dissesse pátrias et filias. Pois, embora essas
palavras assim proferidas nada signifiquem quando empregadas, concede-se, porém que sejam
significativas pela acomodação do uso. Por isso, embora seja mudado o som sensível, permanece.
contudo, o mesmo sentido. Isso, porém que fica dito, sobre a diferença da corruptela no princípio ou no
fim da dicção, se funda em que, para nós, o variar da dicção no princípio muda o sentido, ao passo que a
variação final não o muda, no mais das vezes. Mas entre os gregos o sentido varia, mesmo no princípio
da dicção, em declinação das palavras. Mas sobretudo devemos atender à grandeza da corruptela
relativamente a dicção. Pois, tanto no fim como no principio pode ela ser tão pequena que não tire o
sentido às palavras; e tão grande que o tire. Um desses defeitos porém mais facilmente resulta da
corrupção no princípio e o outro, na do fim.

## Art. 8 — Se é lícito fazer algum acréscimo às palavras nas quais consiste a forma dos sacramentos.
O oitavo discute-se assim. — Parece que não é lícito fazer nenhum acréscimo às palavras nas quais
consiste a forma dos sacramentos.

1. — Pois, não impõem menor necessidade essas palavras sacramentais que as da Sagrada Escritura.
Ora, às palavras da Sagrada Escritura não é lícito acrescentar nem diminuir nada. Assim, diz a Escritura:
Vós não ajuntareis nem tirareis nada às palavras que eu vos digo. E noutro lugar: Eu protesto a todos os
que ouvem as palavras da profecia deste livro. Que se alguém lhe ajuntar alguma causa, Deus o
castigará com as pragas que estão escritas neste livro; e se algum tirar qualquer causa, tirará Deus a sua
parte do livro da vida. Logo, parece que também à forma dos sacramentos não é lícito fazer nenhum
acréscimo ou diminuição.

2. Demais. — As palavras desempenham, nos sacramentos, o papel de forma, como se disse. Ora,
qualquer adição ou subtração varia a espécie da forma como também se dá com os números, no dizer
de Aristóteles. Logo, parece que se fizer algum acréscimo ou subtração à forma do sacramento, já este
não será o mesmo.

3. Demais. — Assim como a forma do sacramento requer um número determinado de palavras, assim
também uma ordem determinada delas e mesmo a continuidade da oração. Se pois, a adição ou a
subtração não elimina a realidade do sacramento, parece que, pela mesma razão, não a elimina nem a
transposição das palavras nem a interpolação na pronúncia.
Mas, em contrário, nas formas dos sacramentos, uns fazem certos acréscimos que outros não fazem.
Assim os latinos batizam sob esta forma — Eu te batizo em nome do Padre e do Filho e do Espírito
Santo; ao passo que os gregos, sob est'outra — Seja batizado o servo de Cristo N. em nome do Padre,
etc. E, contudo ambos conferem verdadeiramente o sacramento. Logo, é lícito fazer acréscimos ou
diminuições nas formas dos sacramentos.

SOLUÇÃO. — Acerca de todas as mudanças que podem ocorrer nas formas dos sacramentos, duas
coisas devemos considerar. — Uma relativa a quem profere as palavras, cuja intenção é necessária à
existência do sacramento, como a seguir se dirá. E assim, se tiver a intenção, por essa adição ou
subtração de introduzir outro rito que não o recebido pela Igreja, não perfaz o sacramento, por não ter
a intenção de fazer o que faz a Igreja. — A outra causa a considerar é relativa à significação das palavras.
Pois como as palavras operam, nos sacramentos, pelo sentido que fazem, conforme dissemos devemos
considerar se a referida alteração tira às palavras o sentido próprio, porque então é manifesto que
elimina a realidade sacramental.
Ora, é manifesto que, feita uma diminuição na substância da forma sacramental, desaparece o sentido
próprio das palavras e portanto não se perfaz o sacramento. Por isso Dídimo diz: Quem pretender
batizar, mas omitindo uma das referidas palavras, isto é, do Padre, do Filho e do Espírito Santo, não
batiza completamente. Mas se a subtração for do que não é da substância da forma, essa diminuição
não tira o sentido próprio das palavras e por conseqüência não priva o sacramento da sua perfeição.
Assim, na forma da Eucaristia, que é — Este pois é o meu corpo — o vocábulo pois, eliminado, não
exclui o sentido próprio das palavras e portanto não priva o sacramento da sua perfeição. Embora possa
dar-se que quem o omitiu peque por negligência ou desprezo.
Quanto à adição, sucede o fazer-se um acréscimo corruptivo do sentido próprio; assim se alguém
dissesse modo de batizar dos Arianos: Eu te batizo em nome do Padre maior e do Filho menor. E então
esse acréscimo elimina a verdade do sacramento. Mas se o acréscimo for tal que não faça desaparecer o
sentido próprio, não desaparece a realidade sacramental. Nem importa se essa adição se faça no
princípio, no meio ou no fim. Assim, se disser — Eu te batizo em nome de Deus Padre onipotente e do
seu Filho Unigênito e do Espírito Santo Paráclito, haverá verdadeiramente batismo. E semelhantemente,
se disser — Eu te batizo em nome do Padre e do Filho e do Espírito Santo, e a Santa Virgem te ajude,
haverá verdadeiramente batismo.
Talvez, porém se dissesse — Eu te batizo em nome do Padre e do Filho e do Espírito Santo e da Santa
Virgem Maria — não haveria batismo, porque diz o Apóstolo: Porventura Paulo foi crucificado por vós?
Ou haveis sido batizados em nome de Paulo? E isto é verdade se entender o ser batizado em nome da
Santa Virgem, como se o fosse em o da Trindade, pelo qual foi o batismo consagrado; pois, tal sentido
seria contrário à verdadeira fé e por consequência excluiria a realidade do sacramento. Se porém se
entender o acréscimo — em nome da Santa Virgem — como significando não que o nome da Santa
Virgem tenha qualquer operação no batismo, mas que a sua intercessão seja útil para o batizado
conservar a graça batismal, não desaparece a perfeição do sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Às palavras da Sagrada Escritura não é lícito fazer nenhum
acréscimo, quanto ao sentido delas; mas para explicá-las, os doutores lhes ajuntam muitas outras. Mas,
essas não se lhes podem acrescentar como se considerassem partes integrantes delas, porque haveria
então o vício da falsidade. E semelhantemente, se alguém dissesse ser de necessidade para a existência
da forma o que não o é.

RESPOSTA À SEGUNDA. — As palavras pertencem à forma do sacramento em razão do sentido
significado. Por isso, qualquer acréscimo ou subtração de palavras, que nada acrescente ou subtraia ao
sentido próprio, não elimina a espécie do sacramento.

RESPOSTA À TERCEIRA. — Se a interrupção das palavras for tão grande que intercepte a intenção de
quem as pronuncia, desaparece o sentido do sacramento, e por consequência a sua realidade. Mas não
desaparece, quando a interrupção, sendo pequena não faz interromper a intenção mental. — E o
mesmo se deve dizer da transposição das palavras. A qual, destruindo o sentido da locução, não se
perfaz o sacramento; tal o caso da negação preposta ou posposta ao sinal. Se porém a transposição for
tal que não altere o sentido da locução, não desaparece a realidade sacramental; pois, segundo diz o
Filósofo, os nomes e as palavras transpostas significam o mesmo.