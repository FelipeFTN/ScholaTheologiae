# Questão 79: Dos efeitos deste sacramento
Em seguida devemos tratar dos efeitos deste sacramento. E nesta questão discutem-se oito artigos:

## Art. 1 — Se este sacramento confere a graça.
O primeiro discute-se assim. — Parece que este sacramento não confere a graça.

1. — Pois, este sacramento é uma nutrição espiritual. Ora, nutrição não se dá senão ao ser vivo. Mas, a
vida espiritual, provindo da graça. não pode receber este sacramento senão quem está em graça. Logo,
este sacramento não confere a graça a quem ainda não a tem. Semelhantemente, nem vem aumentar a
graça, porque o crescimento espiritual é efeito do sacramento da confirmação, como se disse. Logo,
este sacramento não confere a graça.

2. Demais. — Este sacramento é conferido a modo de uma como refeição espiritual. Ora, a refeição
espiritual implica antes no uso, que na conservação da graça. Logo, parece que este sacramento não
confere a graça.

3. Demais. — Como dissemos, neste sacramento é oferecido o corpo de Cristo, para saúde do corpo, e o
sangue para saúde da alma. Ora, não o corpo, mas a alma é o sujeito da graça, como se estabeleceu na
Segunda Parte. Logo, pelo menos, quanto ao corpo, este sacramento não confere a graça.
Mas, em contrário, diz o Senhor: O pão que eu darei é a minha carne, para ser a vida do mundo. Ora, a
vida espiritual provém da graça. Logo, este sacramento confere a graça.

SOLUÇÃO. — O efeito deste sacramento deve ser considerado, primária e principalmente, pelo que nele
se contém, que é Cristo. O qual, assim como vindo visivelmente ao mundo, deu ao mundo a vida da
graça, segundo àquilo do Evangelho — A graça e a verdade foram trazidas por Jesus Cristo; assim
também, dando-se-nos sacramentalmente obra em nós a vida da graça, segundo aquilo do Evangelho -
O que me come a mim, esse mesmo também viverá por mim. Donde o dizer Cirilo: O verbo vivificante
de Deus, unindo-se a si mesmo à nossa carne, tornou-a vivificante. Pois, era-lhe decente unir-se de certo
modo dos nossos corpos pela sua carne e pelo seu precioso sangue, que recebemos sob a forma de pão
e de vinho, depois da consagração vivificante. Secundariamente, o seu efeito é considerado no que este
sacramento representa, o saber, a paixão de Cristo, como se disse. E assim, o efeito produzido para o
mundo pela paixão de Cristo, este sacramento o produz em nós. Por isso, aquilo do Evangelho —
Imediatamente saiu sangue é água, diz Crisóstomo: Como dai tiveram origem os sagrados mistérios,
quando amares o tremendo cálice, fá-lo como se o bebesses do lado mesmo de Cristo. Por isso o próprio
Senhor disse: Este é o meu sangue, que será derramado por muito para remissão de pecados. Em
terceiro lugar, o efeito deste sacramento é considerado quanto ao modo pelo qual é dado, a saber, a
modo de comida e bebida. Por onde, todo o efeito produzido pela comida e pela bebida materiais,
quanto à vida do corpo, que é sustentá-lo, fazê-lo crescer; separá-lo e deleitá-lo, todo ele produz este
sacramento para a vida espiritual. Por isso, diz Ambrósio: Este é o pão da vida eterna; que sustenta a
substância da nossa alma. E Crisóstomo: Dá-se-nos aos que o desejamos, a ser tocado, comido e
abraçado. Por onde o próprio Senhor diz: A minha carne verdadeiramente é comida e o meu sangue
verdadeiramente é bebida. Em quarto lugar, o efeito deste sacramento é considerado relativamente às
espécies, sob as quais é dado. Por isso, Agostinho diz no mesmo lugar: Nosso Senhor quis usar, para que
se transformassem no seu sangue, de coisas que constituem uma unidade formada de muitos
elementos. Pois uma — o pão, é unidade constituída de muitos grãos; a outra — o vinho é unidade
formada da confluência de muitos. Donde o dizer ele ainda, em outro lugar: O sacramento da piedade, o
sinal da unidade, o vínculo da caridade. E sendo Cristo e a sua paixão a causa da graça, e não podendo
haver nutrição e caridade espiritual sem graça, de tudo o que dissemos é manifesto, que este
sacramento confere a graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Este sacramento tem por si mesmo o poder de conferir a
graça. Nem há quem tenha a graça antes de recebê-lo, a não ser que disso tenha o desejo, ou por si
mesmo - como os adultos, ou por desejo da Igreja - como as crianças, segundo dissemos. Por onde, já é
eficácia da sua virtude, que pelo desejo desse sacramento alcancemos a graça, que nos vivifica
espiritualmente. Resta, pois, que, ao recebermos realmente o sacramento, a graça aumenta em nós, e a
vida espiritual se aperfeiçoa. Mas de modo diferente do que pelo sacramento da confirmação, que nos
faz crescer e aperfeiçoar na graça, para arrostar os ataques exteriores dos inimigos de Cristo. Pois, este
sacramento nos aumenta a graça e aperfeiçoa a vida espiritual, para em nós mesmos levamos uma
existência perfeita, pela união com Deus.

RESPOSTA À SEGUNDA. — Este sacramento confere a graça espiritualmente, com a virtude da caridade.
Por isso Damasceno o compara a brasa que Isaias viu; pois, a brasa não é simples lenha, mas unida ao
jogo; assim também o pão da comunhão não é simples pão, mais unido à divindade. Porque como diz
Gregório, na homília de Pentecostes, o amor de Deus não é ocioso; e. quando existe em nós obra
grandes causas. Por onde, este sacramento tem por si mesmo o poder de nos conferir, não só o hábito
da graça e da virtude, mas também o de nos levar a ação, segundo aquilo do Apóstolo: O amor de Cristo
nos constrange. Donde vem que, por virtude deste sacramento, a alma se nutre espiritualmente
deleitando-se e de certo modo inebriando-se com a doçura da bondade divina. segundo àquilo da
Eucaristia: Comei, amigos e bebei e embriagai-vos, caríssimos.

RESPOSTA À TERCEIRA. — Os sacramentos, obrando conforme a semelhança que significam, por uma
certa assimilação dizemos, que neste sacramento o corpo é oferecido para saúde do corpo; e o sangue,
para saúde da alma. Embora o corpo e o sangue operem a saúde do corpo e da alma. pois sob ambas as
espécies está Cristo totalmente, como dissemos. E embora não seja o corpo o sujeito imediato da graça,
contudo da alma, o efeito da graça redunda no corpo, enquanto que na vida presente os nossos
membros como os instrumentos da justiça os oferecemos a Deus, na frase do Apóstolo. E na vida futura
o nosso corpo participará da incorrupção e da glória da alma.

## Art. 2 — Se o efeito deste sacramento é fazer-nos alcançar a glória.
O segundo discute-se assim. — Parece não ser efeito deste sacramento fazer-nos alcançar a glória.

1. — Pois, o efeito é proporcionado à causa. Ora, este sacramento é próprio dos que viandamos neste
mundo, chamando-se por isso viático. Ora, não sendo as viandantes capazes ainda da glória, parece que
este sacramento não nos faz alcançar a glória.

2. Demais. — Posta a causa suficiente, resulta o efeito. Ora, muitos recebem este sacramento que nunca
chegarão à glória, como o diz Agostinho. Logo, este sacramento não é causa de alcançarmos a glória.

3. Demais. — O mais não pode ser produzido pelo menos, pois a ação de nenhum ser lhe ultrapassa a
espécie. Ora, é menos receber a Cristo sob uma espécie alheia, como o recebemos neste sacramento,
do que gozá-lo na sua espécie própria, o que constitui a glória. Logo, este sacramento não nos faz
alcançar a glória.
Mas, em contrário, o Evangelho: Se qualquer comer deste pão viverá eternamente. Ora, a vida eterna é
a vida da glória. Logo, o efeito deste sacramento é fazer-nos alcançar a glória.

SOLUÇÃO. — Duas coisas podemos considerar neste sacramento. A causa do efeito, a saber, o próprio
Cristo nele contido, e a sua paixão representada. E o meio pelo qual alcançamos o efeito, a saber, a
recepção do sacramento e das suas espécies. E, de ambos os modos este sacramento é apto a fazer-nos
alcançar a vida eterna. Pois, quanto a Cristo, ele próprio pela sua paixão franqueou-nos a entrada da
vida eterna, segundo àquilo do Apóstolo: É mediador de um novo testamento, para que, intervindo a
morte, recebam a promessa da herança eterna os que tem sido chamado. Por isso a forma desse
sacramento reza: Este é o cálice do meu sangue, do novo e eterno Testamento. - Semelhantemente,
também a nutrição da comida espiritual e a unidade, significada pelas espécies do pão e do vinho temo-
las por certo nesta vida, mas imperfeitamente; perfeitamente, porém os teremos na vida da glória. Por
isso Agostinho, aquilo do Evangelho - A minha carne é verdadeiramente comida diz: Os homens
buscamos o comer e o beber para saciarmos a fome e a sede, mas isso só o produz verdadeiramente
esta comida e esta bebida, tornando imortais e incorruptíveis os que o tomamos e fazendo-nos entrar
na sociedade dos santos, onde haverá paz e unidade plena e perfeita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — — A paixão de Cristo, por cuja virtude obra este
sacramento, é por certo a causa eficiente da glória. não porém de modo que nele nos faça entrar
imediatamente, pois devemos primeiro padecer com ele, para que depois sejamos com ele glorificados.
Assim também, este sacramento não nos introduz imediatamente na glória. mas nos dá o poder de a ela
chegarmos. Por isso se chama viático. E como figura dele lemos na Escritura, que Elias comeu e bebeu e
com o vigor daquela comida caminhou quarenta dias e quarenta noites até o monte de Deus, Horeb.

RESPOSTA À SEGUNDA. — Assim como a paixão de Cristo não produz efeito naqueles. que não estão
para com ela na disposição devida, assim também por este sacramento não alcançam a glória os que o
recebem indignamente. Por isso Agostinho, expondo aquelas palavras do Evangelho - Comeram o maná
e morreram - diz: Uma coisa é o Sacramento e outra, a virtude do sacramento. Muitos se achegam ao
altar e dele recebem a morte. Por onde, comei espiritualmente o pão celeste, aproximando-vos do altar
vestidos de inocência. Por isso nada há para admirar, se os que não conservam a inocência não recebem
o efeito deste sacramento.

RESPOSTA À TERCEIRA. — O ser Cristo recebido sob espécie alheia, resulta da natureza co sacramento,
que atua instrumentalmente. Ora, nada impede uma causa instrumental produzir um efeito mais amplo,
como dissemos.

## Art. 3 — Se o efeito deste sacramento é a remissão do pecado mortal.
O terceiro discute-se assim. — Parece que o efeito deste sacramento é a remissão do pecado mortal.

1. — Pois, reza uma coleta: Seja este sacramento a ablução dos crimes. Ora, crimes se chamam os
pecados mortais. Logo, este sacramento lava dos pecados mortais.

2. Demais. — Este sacramento age em virtude da paixão de Cristo, como o batismo. Ora, pelo batismo se
perdoam os pecados mortais, como se disse. Logo, também por este sacramento; sobretudo que a sua
forma diz - Que será derramado por muitos para remissão dos pecados.

3. Demais. — Este sacramento confere a graça, como se deve. Ora, a graça nos justifica dos pecados
mortais, segundo àquilo do Apóstolo: Tendo sido justificados gratuitamente por sua graça. Logo, por
este sacramento se remitem os pecados mortais.
Mas, em contrário, o Apóstolo: Todo aquele que come e bebe indignamente, come e bebe para si a
condenação. O que a Glosa comenta: Aquele come e bebe indignamente, que vive no crime ou o trata
com irreverência o sacramento; e esse come e bebe para si o juízo, isto é, a condenação. Logo, quem
está em pecado mortal, recebendo este sacramento, aumenta ainda o seu pecado. em lugar de alcançar
a remissão dele.

SOLUÇÃO. — A virtude deste sacramento pode ser considerada a dupla luz. – Primeiro, em si mesmo. E
então tem o poder de remitir quaisquer pecados, em virtude da paixão de Cristo, fonte e causa do
perdão dos pecados. - Segundo, relativamente a quem recebe este sacramento, conforme está ou não
impedido de o fazer. Assim, quem tem consciência de estar em pecado mortal traz em si um
impedimento de alcançar o efeito deste sacramento, por não estar em condições de o receber
convenientemente. Quer por não viver espiritualmente e, portanto, não digno de um alimento
espiritual, de que só quem vive o é. Quer por não poder unir-se com Cristo - efeito deste sacramento,
pois tem o afeto de pecar mortalmente. E por isso se diz, que se no coração se aninha o afeto ao
pecado, o ato de receber a Eucaristia antes o agrava do que purifica dele. Por onde, este sacramento
não produz a remissão do pecado em quem o recebe com a consciência do pecado mortal. Pode porém
este sacramento obrar a remissão dos pecados de dois modos. - De um modo, quando não é recebido
realmente, mas só em desejo; tal o caso de quem foi primeiro justificado do pecado. - de outro, quando
recebido mesmo por quem está em estado de pecado mortal, mas do qual não tem a consciência nem
nela põe o seu afeto. Pois, talvez não foi antes suficientemente contrito; mas, achegando-se ao
sacramento com devoção e reverência, consegue por ele a graça da caridade, que tornará íntegra o
contrição e a remissão do pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pedimos que este sacramento nos seja a ablução dos
crimes, ou de aqueles de que não temos consciência, segundo aquilo da Escritura: Purifica-me dos meus
pecados ocultos, Senhor. Ou para que se nos inteire a contrição para a remissão dos pecados. Ou ainda
para nos ser concedida a força de os evitar.

RESPOSTA À SEGUNDA. — O batismo é uma geração espiritual, consistente na mudança do não ser
espiritual para o ser espiritual; e é conferido a modo de ablução. Por onde, relativamente a mudança
como à ablução não se apresenta inconvenientemente ao batismo que tem a consciência de estar em
pecado mortal. Ao passo que neste sacramento recebemos a Cristo como nutrimento espiritual; e isso
não é possível a quem está morto pelos pecados. Logo, a comparação não colhe.

RESPOSTA À TERCEIRA. — A graça é causa suficiente da remissão do pecado mortal; mas não o remite
senão depois de tê-la o pecador recebido. Ora, este sacramento não confere tal graça. Logo, a objeção
não colhe.

## Art. 4 — Se por este sacramento se perdoam os pecados veniais.
O quarto discute- se assim. — Parece que por este sacramento não se perdoam os pecados veniais.

1. — Pois, este sacramento, no dizer de Agostinho, é o sacramento da caridade. Ora, os pecados veniais
não contrariam a caridade, conforme se estabeleceu na Segunda Parte. Logo, como os contrários entre
si se repelem, parece que os pecados veniais não são perdoados por este sacramento.

2. Demais. — Se os pecados veniais fossem perdoados por este sacramento, da mesma razão se
perdoaria um como se perdoariam todos. Ora, parece que todos não se perdoariam porque então seria
frequente estarmos sem nenhum pecado venial, contra o dito do Evangelho: Se dissermos que estamos
sem pecado nós mesmos nos enganamos. Logo, por este sacramento são perdoados só alguns pecados
veniais.

3. Demais. — Os contrários mutualmente se repelem. Ora, os pecados veniais não impedem de receber
este sacramento. Assim, Agostinho, aquilo do Evangelho - Vossos pais comeram o maná no deserto e
morreram - diz: Apresentai-vos ao altar vestidos de inocência; pois, os pecados, ainda quotidianos, não
são mortais. Logo, nem os pecados veniais são delidos por este sacramento.
Mas, em contrário, diz lnocêncio III: Este sacramento dele os pecados veniais e fortifica contra os
mortais.

SOLUÇÃO. — Duas coisas podemos considerar neste sacramento; o sacramento mesmo e a sua
realidade. E de ambos resulta a sua virtude de remitir os pecados veniais. Pois, este sacramento é
recebido sob a espécie de uma comida nutritiva. Ora, a nutrição pela comida é necessária para refazer o
calor natural quotidianamente perdido pelo nosso corpo. Assim também, espiritualmente cada dia
perdemos, pelos pecados veniais, do calor da concupiscência, que diminuem o fervor da caridade, como
na Segunda Parte estabelecemos. Por onde, é próprio deste sacramento remitir-nos os pecados veniais.
Por isso diz Ambrósio, que este pão quotidiano nós o comemos, como remédio de uma quotidiana
enfermidade. - Quanto à realidade deste sacramento, é a caridade, não só habitual como também atual,
que ele desperta; pelo que os pecados veniais são delidos. Por onde é manifesto, que este sacramento
tem a virtude de delir os pecados veniais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os pecados veniais, embora não contrariem ao hábito da
caridade, contrariam-lhe contudo, o fervor do ato, excitado por este sacramento. Em razão do que, os
pecados veniais são delidos.

RESPOSTA À SEGUNDA. — As palavras citadas não devem entender-se no sentido em que não
possamos, em nenhum tempo, estar sem o reato do pecado venial; mas como significando que esta vida
os santos não o passam, sem pecados veniais.

RESPOSTA À TERCEIRA. — Maior é o poder da caridade, da qual é este sacramento, que o dos pecados
veniais. Pois um ato de caridade dele os pecados veniais, que contudo, não no podem impedir
totalmente. E o mesmo se dá com este sacramento.

## Art. 5 — Se este sacramento remite totalmente a pena do pecado.
O quinto discute-se assim. — Parece que este sacramento remite totalmente a pena do pecado.

1. — Pois, por este sacramento, assim como pelo batismo, recebemos em nós o efeito da paixão de
Cristo, conforme se disse: - Ora, pelo batismo recebemos a remissão total da pena, em virtude da paixão
de Cristo, que satisfaz suficientemente por todos os pecados, como do sobredito se colhe. Logo, parece
que por este sacramento é-nos remitido totalmente o reato da pena.

2. Demais. — Alexandre Papa (I) diz: Nenhum sacrifício pode ser maior que o do corpo e do sangue de
Cristo. Ora, pelos sacrifícios da Lei Velha o homem satisfazia pelos seus pecados. Assim, diz a Escritura:
Se o homem pecar, que ofereça (isto ou aquilo) por seu pecado, e será perdoado. Logo, com maior
razão, este sacramento tem o poder de remitir totalmente a pena.

3. Demais. — Sabemos que por este sacramento é remitida em parte o reato da pena; por isso é
imposta a certos a satisfação de mandar celebrar missas por si. Ora, pela razão por que é remitida uma
parte da pena, por essa mesma o será outra; pois, a virtude de Cristo contida no sacramento é infinita.
Logo, parece que por este sacramento é totalmente perdoada a pena.
Mas, em contrário, se assim fosse, não se devia impor a ninguém nenhuma pena, como não se impõe ao
batizado.

SOLUÇÃO. — Este sacramento é simultaneamente sacrifício e sacramento. Mas, tem natureza de
sacrifício, quando oferecido, e de sacramento, quando recebido. Por onde, produz o efeito de
sacramento em quem o receber e o de sacrifício, em quem o oferecer, ou nos por quem é oferecido. Se,
pois, o consideramos como sacramento, produz duplo efeito - um, direto, por força de sacramento;
outro, quase por certa concomitância, como o dissemos acerca do conteúdo do sacramento. Por força
do sacramento, produz diretamente o efeito para que foi instituído. Ora, não foi instituído para
satisfazer; mas para nos nutrir espiritualmente pela união com Cristo e os seus membros, como·a
nutrição fica unida ao nutrido. Mas, operando-se essa união pela caridade, por cujo poder alcançamos a
remissão tanto da culpa como da pena, daí resulta por consequência e por concomitância com o efeito
principal, o alcançarmos, não a remissão total da pena, mas uma remissão relativa a intensidade da
nossa devoção e fervor. Por outro lado, enquanto sacrifício tem uma virtude satisfativa. Ora, na
satisfação levamos em conta, antes o afeto do oferente, que a quantidade da oblação. Por isso o senhor
disse da viúva que ofereceu dois dinheiros, que deu mais que todos. Embora pois, esta oblação baste
quantitativamente a satisfazer por toda pena, contudo é satisfatória para aqueles por quem é oferecida;
ou também para os oferentes, conforme a intensidade da sua devoção, e não pela totalidade da pena.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O sacramento do batismo se ordena diretamente à
remissão da pena e da culpa; não porém a Eucaristia. Porque quando recebemos o batismo como que
morremos com Cristo; a Eucaristia porém, por assim dizer nos nutre e aperfeiçoa, por Cristo. Por onde, o
símile não colhe.

RESPOSTA À SEGUNDA. — Esses sacrifícios e oblações não operam a remissão total da pena, nem
quanto à quantidade do oferecido - como a Eucaristia, nem quanto à devoção do sujeito Donde resulta
que também por aí não se livra totalmente da pena.

RESPOSTA À TERCEIRA. — O ser perdoada parte da pena e não toda, por este sacramento, não é por
deficiência da virtude de Cristo, mas da devoção humana.

## Art. 6 — Se este sacramento nos preserva dos pecados futuros.
O sexto discute-se assim. – Parece que este sacramento não nos preserva dos pecados futuros.

1. — Pois, muitos dos que recebem dignamente este sacramento depois caem em pecado. Ora, isso não
se daria se ele preservasse dos pecados futuros. Logo, o efeito deste sacramento não é preservar dos
pecados futuros.

2. Demais. — A Eucaristia é o sacramento da caridade, como se disse. Ora, a caridade podendo, depois
de possuída, ser perdida pelo pecado, como se estabeleceu, parece que não preserva dos pecados
futuros. Logo, parece que nem este sacramento nos preserva do pecado.

3. Demais. — A origem do pecado em nós é a lei do pecado, que está nos nossos membros, segundo o
Apóstolo. Ora, a mitigação da concupiscência, que é a lei do pecado, não é considerada efeito deste
sacramento, mas antes, do batismo. Logo, preservar-nos dos pecados futuros não é o efeito deste
sacramento.
Mas, em contrário, diz o Senhor: Este é o pão que desceu do céu, para que todo o que dele comer não
morrer. O que, manifestamente, não se entende da morte do corpo. Logo, entende-se da morte
espiritual, causada do pecado, e da qual este sacramento nos preserva.

SOLUÇÃO. — O pecado é uma espiritual morte da alma. Por onde, preservamo-nos do pecado futuro,
do mesmo modo pelo qual o nosso corpo é preservado da morte futura. E isso de dois modos se dá.
Primeiro, fortificando interiormente a nossa natureza contra as causas internas de corrupção; assim,
preservamo-nos da morte pela comida e pelos remédios. De outro modo, defendendo-nos contra os
ataques externos; e assim, preservamo-nos pelas armas, defesa do nosso corpo. Ora, de um e de outro
modo este sacramento nos preserva do pecado. - Primeiro, unindo-se com Cristo por meio da graça,
robustecer-nos a vida espiritual, sendo uma comida, por assim dizer, e um remédio espiritual, segundo
àquilo da Escritura; o pão fortifica o coração do homem. E Agostinho diz: Aproxima-te confiante - é pão
e não, veneno. - De outro modo, enquanto sinal da paixão de Cristo, pela qual os demônios foram
vencidos, repele todo ataque dos demônios. Por isso diz Crisóstomo: Com leões expirando chamas,
assim, saiamos dessa mesa inimigos terríveis ao diabo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O efeito deste sacramento nós o sentimos, conforme as
nossas condições. Pois, o mesmo se dá com qualquer causa ativa, cujos efeitos são recebidos na
matéria, ao modo desta. Ora, pela nossa condição nesta vida, podemos, usando do livre arbítrio
escolher entre o bem e o mal. Por onde, embora este sacramento tenha em si mesmo a virtude de nos
preservar do pecado, não nos tira a possibilidade de pecar.

RESPOSTA À SEGUNDA. — Também a caridade em si mesma, preserva o homem do pecado, segundo
àquilo do Apóstolo: O amor do próximo, não obra mal. Mas, da mutabilidade do livre arbítrio resulta o
pecarmos, depois de termos tido a graça; assim como, depois de termos recebido este sacramento.

RESPOSTA À TERCEIRA. — Embora este sacramento não se ordene diretamente à diminuição da
concupiscência, diminui-a contudo, pela conseqüência de aumentar a caridade. Pois, como diz
Agostinho, o aumento da caridade é a diminuição da concupiscência. E diretamente confirma-nos o
coração no bem. O que também nos preserva do pecado.

## Art. 7 — Se este sacramento não aproveita senão a quem o recebe.
O sétimo discute-se assim. — Parece que este sacramento não aproveita senão a quem o recebe.

1. — Pois, este sacramento, entrando na mesma divisão que os outros, é do mesmo gênero que eles.
Ora, os outros sacramentos não aproveitam senão a quem os recebe; assim, o efeito do batismo não o
colhe senão o batizado. Logo, também este sacramento não pode aproveitar senão a quem o recebe.

2. Demais. — O efeito deste sacramento é fazer-nos alcançar a graça e a glória, é remitir-nos pelo menos
a culpa venial. Ora, se este sacramento produzisse efeito para outros, que não quem o recebe, seria
possível alcançarmos a graça e a glória e a remissão da culpa, sem ação nem paixão própria nossa e só
pelo fato de receber outrem ou oferecer este sacramento.

3. Demais. — Multiplicada a causa, multiplica-se o efeito. Se, portanto, este sacramento aproveitasse a
outrem, que não quem o recebe, resultaria que tanto mais lhe aproveitaria, quanto mais os que o
recebessem, consagradas muitas hóstias em uma só missa. Mas não é esse o costume da Igreja, o
comungarem muitos pela salvação de um só. Logo, parece que este sacramento não aproveita senão a
quem o recebe.
Mas, em contrário, na celebração deste sacramento faz-se deprecação por muitos. O que saia Em vão,
se ele lhes não aproveitasse. Logo, este sacramento não aproveita só a quem o recebe.

SOLUÇÃO. — Como dissemos este sacramento não é somente sacramento, mas também sacrifício. Pois,
enquanto nele se representa a paixão de Cristo, pela qual Cristo se ofereceu como vítima a Deus, na
linguagem do Apóstolo, tem natureza de sacrifício. Mas enquanto nos confere a graça invisível sob
forma visível, tem natureza de sacramento. E assim este sacramento aproveita a quem o recebe, tanto a
modo de sacramento, como de sacrifício; pois, é oferecido por todos os que o recebem, conforme o reza
o canon da missa: Todos os que, participando deste altar, recebermos o sacramento corpo e sangue de
teu Filho, fiquemos cheios de toda bênção celeste e graça. Mas, dos que não o recebem aproveita o
modo de sacrifício, enquanto oferecido pela salvação deles. Por isso também se diz no canon da missa:
Lembra-te, Senhor, dos teus servos e servas, por quem te oferecemos ou que te oferecem este sacrifício
de louvor, por si e por todos os seus, pela redenção das suas almas, por sua salvação e conservação. E
uma e outra coisa o Senhor exprime, ao dizer: Que por vós, isto é, pelos que o recebem, e por muitos
outros, será derramado para remissão de pecados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Este sacramento é por excelência e mais que os outros,
sacrifício. Logo, o simile não colhe.

RESPOSTA À SEGUNDA. — A paixão de Cristo aproveita a muitos para a remissão da culpa e a obtenção
da graça e da glória; mas o efeito não se cumpre senão nos que estão unidos com a paixão de Cristo pela
fé e pela caridade. Assim também este sacrifício, que é o memorial da paixão do Senhor, não produz
efeito senão naqueles que estão unidos com este sacramento, pela fé e pela caridade. Por isso diz
Agostinho: Quem oferecerá o corpo de Cristo senão por aqueles que são membros de Cristo? Por isso
no canon da missa não se reza pelos que estão fora da Igreja. Aos quais porém o sacrifício aproveita,
conforme o modo da devoção deles.

RESPOSTA À TERCEIRA. — Por natureza um sacramento existe para ser recebido; mas é como sacrifício,
que é recebido. Por isso, o fato de um ou muitos receberem o corpo de Cristo, não produz nenhum
auxílio para outrem. Semelhantemente, nem por consagrar o sacerdote várias hóstias numa só missa,
multiplica-se o efeito deste sacramento pois, o sacrifício é um só. Nem muitas hóstias consagradas têm
maior virtude, que uma apenas; porque, tanto sob todas como sob cada uma está todo Cristo. Por onde
quem, na mesma missa, tomasse simultaneamente muitas hóstias consagradas, não participaria, por
isso de maior efeito do sacramento. Mas, em várias missas, multiplica-se a oblação do sacrifício. E
portanto multiplica-se o efeito do sacrifício e do sacramento.

## Art. 8 — Se o pecado venial impede o efeito deste sacramento.
O oitavo discute-se assim. — Parece que o pecado venial não impede o efeito deste sacramento.

1. — Pois, diz Agostinho; comentando àquilo do Evangelho - Os vossos pais comeram o maná: Comei
espiritualmente o pão celeste; aproximai-vos do altar revestidos de inocência, os pecados, embora
quotidianos, não são mortíferos. Por onde é claro, que os pecados quotidianos, chamados veniais, não
impedem a manducação espiritual. Ora, os que o comem espiritualmente recebem o efeito deste
sacramento. Logo, os pecados veniais não impedem esse efeito.

2. Demais. — Este sacramento não tem menor virtude que o batismo. Ora, o efeito do batismo só
dissimulação o impede, como dissemos; e essa não pode constituir um pecado venial. Pois, como diz a
Escritura, o Espírito Santo, mestre da disciplina, fugirá do fingido, que contudo, não fugirá de quem
comete pecado venial. Portanto, os pecados veniais não impedem o efeito deste.

3. Demais. — Nada do que é removido pela ação de uma causa pode impedir-lhe o efeito. Ora, este
sacramento dele os pecados veniais. Logo, estes não lhe impedem o efeito.
Mas, em contrário, diz Damasceno: O fogo do desejo, que arde em nós, de receber a Cristo, acendendo-
se no braseiro da Eucaristia, delirá os nossos pecados e nos iluminará os corações, a fim de nos
inflamarmos pela participação do fogo divino e nos deificarmos. Ora, o fogo do nosso desejo ou amor
fica apagado pelos pecados veniais, que impedem o fervor da caridade, como se estabeleceu na
Segunda Parte. Logo, os pecados veniais impedem o efeito deste sacramento.

SOLUÇÃO. — Os pecados veniais podem ser considerados a dupla luz: enquanto passados ou enquanto
atualmente praticados. - A primeira luz de nenhum modo impedem o efeito deste sacramento. Pois,
pode dar-se que alguém depois de ter cometido muitos pecados veniais se achegue devotamente a este
sacramento e lhe alcance plenamente o efeito. - A outra luz, os pecados veniais não impedem de todo o
efeito deste sacramento, mas só em parte. Pois, como dissemos, é efeito deste sacramento não só
fazer-nos alcançar a graça habitual ou da caridade, mas ser também uma como nutrição da doçura
espiritual. E essa fica impedida para quem o receber com o coração dissipado pelos pecados veniais.
Mas isso não impede o aumento da graça ou da caridade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quem em estado atual de pecado venial se achega a
este sacramento, come espiritualmente, de maneira habitual; mas não de maneira atual. E portanto,
recebe o efeito habitual deste sacramento, não porém, o atual.

RESPOSTA À SEGUNDA. — O batismo não se ordena a um efeito atual, isto é, ao fervor da caridade,
como este sacramento. Pois, o batismo é uma regeneração espiritual, pela qual, adquirimos a perfeição
primeira, que é o hábito ou a forma. Ao passo que este sacramento é uma espiritual manducação, que
traz consigo um prazer atual.

RESPOSTA À TERCEIRA. — A objeção colhe, quanto aos pecados passados que este sacramento dele.