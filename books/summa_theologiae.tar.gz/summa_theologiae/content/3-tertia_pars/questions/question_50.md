# Questão 50: A morte de Cristo
Em seguida devemos tratar da morte de Cristo. E nesta questão discutem-se seis artigos:

## Art. 1 — Se foi conveniente que Cristo morresse.
O primeiro discute-se assim. — Parece que não foi conveniente que Cristo morresse.

1. — Pois, o primeiro princípio, num gênero, não pode ser subordinado ao que é contrário a esse
gênero; assim o fogo, princípio do calor, nunca pode ser frio. Ora, o Filho de Deus é a fonte e o princípio
de toda a vida, segundo aquilo da Escritura: Em ti está a fonte da vida. Logo, parece que não foi
conveniente que Cristo morresse.

2. Demais. — Maior miséria é a morte que a doença, por que por esta se chega àquela. Ora, não é
conveniente que Cristo sofresse nenhuma doença, como diz Crisóstomo. Logo, também não o era que
morresse.

3. O Senhor diz: Eu vim para terem vida e para a terem em maior abundância. Ora, um contrário não
conduz a outro. Logo, parece que não era conveniente que Cristo morresse.
Mas, em contrário, o Evangelho: Convém-vos que morra um homem pelo povo e que não pereça toda a
nação.

SOLUÇÃO. — Foi conveniente que Cristo morresse. — Primeiro, para satisfazer pelo gênero humano,
que tinha sido condenado à morte por causa do pecado, segundo aquilo da Escritura: Em qualquer dia
que comeres dele, morrerás de morte. Ora, o modo conveniente de satisfazermos por outrem é nos
sujeitarmos àpena que ele merecia. Por isso Cristo quis morrer a fim de morrendo, satisfazer por nós,
segundo a Escritura: Cristo uma vez morreu pelos nossos pecados. — Segundo, para mostrar que
assumiu verdadeiramente a natureza humana. Pois, como diz Eusébio, se Cristo, depois de ter vivido no
meio dos homens, houvesse, para evitar a morte, desaparecido inopinadamente, ocultando-se-lhes aos
olhos, todos os teriam julgado um fantasma. — Terceiro, a fim de morrendo, livrar-nos do temor da
morte. Donde o dizer o Apóstolo: Ele participou igualmente da carne e do sangue, para destruir pela sua
morte ao que tinha o império da morte, isto é, ao diabo; e para livrar aqueles que pelo temor da morte
estavam em escravidão toda a vida. — Quarto, a fim de que, morrendo corporalmente, à semelhança do
pecado, isto é, da pena, nos desse exemplo de morrer espiritualmente para o pecado. Donde o dizer o
Apóstolo: Porque, enquanto a ele morrer pelo pecado, morreu uma só vez; mas, quanto a viver, vive
para Deus. Assim também vós considerai-vos como estando mortos para o pecado, mas vivos para Deus,
em Nosso Senhor Jesus Cristo. — Quinto, a fim de, ressurgindo dos mortos, mostrasse ao mesmo tempo
o seu poder, pelo qual venceu a morte, e nos desse a esperança de ressurgir dos mortos. Donde o dizer
o Apóstolo: Se se prega que Cristo ressuscitou dentre os mortos, como dizem alguns dentre vós outros
que não há ressurreição de mortos?

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo é a fonte da vida, como Deus, mas não como
homem. Ora, morreu como homem e não como Deus. Donde o dizer Agostinho: Longe de nós pensar
que Cristo, sendo ele próprio a vida, morreu perdendo-a; pois, se tal tivesse acontecido, a fonte da vida
teria secado. Mas, padeceu a morte enquanto participante da fraqueza humana, que assumira
espontaneamente, sem contudo perder o poder da sua natureza, pelo qual tudo vivifica.

RESPOSTA À SEGUNDA. — Cristo não sofreu a morte originada de nenhuma doença, para que não se
pensasse que morreu por enfermidade imposta pela natureza. Mas sim, a morte que lhe foi infligida
exteriormente, ao que espontaneamente se submeteu para mostrar que era morte voluntária.

RESPOSTA À TERCEIRA. — Um contrário não conduz a outro, essencialmente falando; mas tal pode dar-
se por acidente, como quando, por exemplo, o frio aquece acidentalmente. E deste modo Cristo, pela
sua morte, nos conduziu àvi ,destru

## Art. 2 — Se na morte de Cristo a divindade separou-se da carne.
O segundo discute-se assim. — Parece que na morte de Cristo a divindade separou-se da carne.

1. — Pois, como refere o Evangelho, o Senhor pendente da cruz exclamou: Deus meu, Deus meu,
porque me abandonaste? O que Ambrósio assim explica: Era o clamor do homem, no momento de
morrer, pela separação da divindade; pois, a morte não tendo poder sobre a sua divindade, Cristo não
podia morrer senão por ter-se a divindade, que é a vida, separado dele. Por onde parece que na morte
de Cristo a divindade se lhe separou da carne.

2. Demais. — A remoção do meio separa os extremos. Ora, a divindade está unida àcarne mediante a
alma, como se estabeleceu. Por onde parece que, na morte de Cristo, a alma se lhe separou da carne e,
por consequência, dela também se separou a divindade.

3. Demais. — Maior é o poder vivificador de Deus que o da alma. Ora, o corpo não podia morrer senão
pela separação da alma. Logo, com maior razão, não podia senão pela separação da divindade.
Mas, em contrário, os atributos da natureza humana não se predicam do Filho de Deus senão por causa
da união, como se estabeleceu. Ora, do Filho de Deus se atribui o ser sepulto, que convém ao corpo de
Cristo depois da morte. Isso o mostra o símbolo da fé, quando diz: O Filho de Deus foi concebido, nasceu
da Virgem, sofreu, foi morto e sepultado. Logo, o corpo de Cristo não se separou, na morte, da sua
divindade.

SOLUÇÃO. — O que Deus concede por graça nunca nos é tirado senão por nossa culpa. Por isso diz o
Apóstolo: Os dons e a vocação de Deus são imutáveis. Ora, muito maior é a graça da união, pela qual a
divindade se uniu àcarne na pessoa de Cristo, que a graça da adoção, pela qual os outros são
santificados. E também perdura mais, por natureza, porque essa graça se ordena à união pessoal, ao
passo que a graça de adoção se ordena a uma união de certo modo afetiva. E, contudo vemos que a
graça de adoção nunca é perdida sem culpa. Ora, Cristo não teve nenhum pecado. Logo, era impossível
se lhe rompesse a união entre a divindade e a carne. Por onde, assim como antes da morte, a carne de
Cristo estava unida, segundo a pessoa e a hipóstase, ao Verbo de Deus, assim lhe permaneceu unida
depois da morte. De modo que não fosse uma a hipóstase do Verbo de Deus e outra a da carne de
Cristo, depois da morte, como o diz Damasceno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O abandono referido não respeita àsolução da união
pessoal, mas ao fato de Deus Padre fê-lo exposto à Paixão. Assim, abandonar, no lugar citado, não
significa senão proteger contra os perseguidores. — Ou Cristo se dizia abandonado, referindo-se ao
pedido em que dizia: Pai, se é possível, passe este cálice de mim, como o expõe Agostinho.

RESPOSTA À SEGUNDA. — Diz-se que o Verbo de Deus está unido àcarne mediante a alma, porque a
carne faz parte, por meio da alma, da natureza humana, que o Filho de Deus pretendia assumir. Não,
porém que a alma estivesse unida como um meio termo de ligação. Pois, a carne pertence à natureza
humana, em virtude da alma, mesmo depois de separada esta daquela. Porque na carne morta conserva
ainda, por ordenação divina, uma certa disposição para a ressurreição. Por isso não desapareceu a união
da divindade com a carne.

RESPOSTA À TERCEIRA. — A alma tem o poder de vivificar, como forma. Por onde, enquanto presente
ao corpo e com ele unida formalmente, há de ele necessàriamente ser vivo. Ora, a divindade não tem a
virtude de vivificar formalmente, mas efetivamente; pois, não pode ser a forma do corpo. Por onde, não
é necessário que, enquanto permanece a união da divindade com a carne esta seja viva; porque Deus
não age por necessidade, mas voluntariamente.

## Art. 3 — Se na morte de Cristo houve separação entre a divindade e a alma.
O terceiro discute-se assim. — Parece que na morte de Cristo houve separação entre a divindade e a
alma.

1. — Pois, diz o Senhor: Ninguém tira a minha alma de mim, mas eu de mim mesmo a ponho e de novo a
reassumo. Logo, parece que corpo não pode depor a alma, separando-se dela; porque não está a alma
sujeita ao poder do corpo, mas antes ao contrário. Donde resulta que Cristo, enquanto Verbo de Deus
podia depor a sua alma; isto é, separa-la. Logo, depois da morte de Cristo a alma se lhe separou da
divindade.

2. Demais. — Atanásio diz: Maldito seja quem não confessar que a natureza humana, na sua totalidade,
assumida pelo Filho de Deus, não ressurgiu dos mortos, de novo assumida ou liberada no terceiro dia.
Ora, a natureza humana em sua totalidade não podia ser de novo assumida, se não tivesse algum tempo
sido separada do Verbo de Deus. Mas, o homem total é composto de alma e de corpo. Logo, houve
durante algum tempo separação da divindade, tanto do corpo como da alma.

3. Demais. — Por causa da união com a natureza humana total, é o Filho de Deus verdadeiramente
considerado homem. Se, pois, desaparecida a união entre a alma e o corpo pela morte, o Verbo de Deus
permanecesse unido à alma, resultaria o podermos dizer que o Filho de Deus era verdadeiramente a
alma. Ora. isso é falso, porque, sendo a alma a forma do corpo, resultaria que o Verbo de Deus seria a
forma do corpo - o que é impossível. Logo, na morte de Cristo a alma ficou separada do Verbo de Deus.

4. Demais. — A alma e o corpo, separado um do outro, não constituem uma só hipótese, mas duas. Se,
portanto, o Verbo de Deus permaneceu unido tanto ao corpo como à alma de Cristo, separada esta
daquele pela morte de Cristo, resulta que o Verbo de Deus, durante a morte de Cristo, constituía duas
hipóteses. O que é inadmissível. Logo, depois da morte de Cristo, a alma não permaneceu unida ao
Verbo.
Mas, em contrário, diz Damasceno: Embora Cristo morresse como homem e a sua alma santa se lhe
ficasse separada do corpo imaculado, contudo a divindade continuava inseparável de uma e de outra,
isto é, da alma e do corpo.

SOLUÇÃO. — A alma está unida ao Verbo de Deus mais imediatamente que ao corpo, e anteriormente a
essa segunda união; pois, o corpo está unido ao Verbo de Deus mediante a alma, como dissemos. Ora,
como o Verbo de Deus não se separou, na morte, do corpo, com muito maior razão não se separou da
alma. Por onde, assim como predicamos do Filho de Deus o que convém ao corpo separado da alma,
isto é, que foi sepultado, assim também dele dizemos no símbolo. que desceu aos infernos, porque a
sua alma, separada do corpo, desceu aos infernos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho, expondo as palavras referidas de João,
pergunta se, sendo Cristo o Verbo, separou-se da alma, enquanto era alma ou, de novo, enquanto era
carne. E afirma que, se dissermos que depôs a alma enquanto o Verbo de Deus, resulta que algum
tempo essa alma esteve separada do Verbo. Ora, isso é falso. Pois, a morte separou o corpo, da alma;
mas não afirmo com isso que a alma ficou separada do Verbo. Se, porém dissermos que a própria alma
se separou a si mesma, resulta que a alma mesma se separou de si própria. O que é absurdissimo. Resta,
pois, que a carne mesmo depôs a alma e de novo a assumiu, não por poder próprio, mas por poder do
Verbo que nela habitava; porque, como dissemos, depois da morte a divindade do Verbo não se separou
da carne.

RESPOSTA À SEGUNDA. — Com as palavras aduzidas, Atanásio não quis dizer que a natureza humana
em sua totalidade foi de novo assumida, isto é, todas as suas partes, como se o Verbo de Deus
deparasse, pela morte, as partes da natureza humana. Mas que a totalidade da natureza humana, de
novo assumida na ressurreição, foi reintegrada pela renovada união da alma e do corpo.

RESPOSTA À TERCEIRA. — O Verbo de Deus, por causa da união da natureza humana, não é
considerado por isso como a natureza humana; mas é chamado homem, isto é, o que tem a natureza
humana. Pois, a alma e o corpo são partes essenciais da natureza humana. Por onde, da união do Verbo
com elas ambas não resulta que o Verbo de Deus seja alma ou corpo, mas , sim, que tem alma ou corpo.

RESPOSTA À QUARTA. — Como diz Damasceno, na morte de Cristo separou-se a alma, da carne, mas
não se dividiu uma mesma hipóstase em duas. Pois, tanto o corpo como a alma de Cristo, à mesma luz,
tiraram a sua existência, desde o principio, da hipóstase do Verbo. E na morte, separadas entre si, cada
qual continuou tendo a mesma hipóstase do Verbo. Porque a mesma hipóstase do Verbo permaneceu a
hipóstase do Verbo, da alma e do corpo. Pois, nunca nem a alma nem o corpo tiveram nenhuma
hipóstase própria, além da hipóstase do Verbo; porque sempre é uma hipóstase do Verbo e nunca duas.

## Art. 4 — Se Cristo, no tríduo da morte, cessou de ser homem.
O quarto discute-se assim. — Parece que Cristo, no tríduo da morte, não cessou de ser homem.

1. — Pois, diz Agostinho: Foi tal a união do Verbo com a natureza humana, que tornou Deus, homem, e
o homem, Deus. Ora, essa união não cessou com a morte. Logo, não cessou Cristo de ser homem,
durante a morte.

2. Demais. — O Filósofo diz: Cada homem é o seu próprio intelecto. Por isso, dirigindo-nos à alma de S.
Pedro, depois da morte dele, dizemos: São Pedro, ora por nós. Ora, depois da morte, o Filho de Deus
não se separou da sua alma racional. Logo, nesse tríduo o Filho de Deus continuou a ser homem.

3. Demais. — Todo sacerdote é homem. Ora, durante o tríduo da sua morte Cristo foi sacerdote, do
contrário não seria verdadeiro o dito da Escritura - Tu és sacerdote eternamente. Logo, durante esse
tríduo Cristo foi homem.
Mas, em contrário. — Removido o superior, removido fica o inferior. Ora, ser vivo ou animado é superior
ao a ser animal e homem; pois, o animal é uma substância animada sensível. Mas, no tríduo da sua
morte, o corpo de Cristo não foi nem vivo nem animado. Logo, não foi homem.

SOLUÇÃO. — Que Cristo verdadeiramente morreu é artigo de fé. Portanto, qualquer afirmação contrária
à verdade da morte de Cristo é erro contra a fé. Por isso se diz numa Epístola Sinodal de Cirilo: Quem
não confessar que o Verbo de Deus sofreu na sua carne, foi crucificado ria sua carne e na sua carne
padeceu a morte, seja anátema. Ora, um homem ou um animal verdadeiramente morto deixa de ser
homem ou animal; pois, a morte do homem ou do animal resulta da separação da alma, por ser esta a
que completa a natureza animal ou humana. Por onde, é errôneo dizer que Cristo, durante o tríduo da
sua morte, foi homem, simples e absolutamente falando. Podemos, porém dizer, que durante esse
tríduo Cristo foi um homem morto. Certos, porém confessaram que Cristo, nesse tríduo, foi homem,
servindo-se assim de uma expressão errônea, sem, contudo darem à sua fé um sentido errôneo. Tal
Hugo de S. Vitor, que disse ter sido Cristo homem no tríduo da sua morte, porque considerava a alma
como o homem. Isso, porém é falso, como demonstramos na Primeira Parte. Também o Mestre das
Sentenças afirmou que Cristo foi homem no tríduo da sua morte, mas por outra razão. Era essa a de crer
que a união da alma e do corpo não é da natureza do homem, bastando para alguém ser homem uma
alma humana e um corpo, quer estejam unidas quer separadas. Mas a falsidade dessa opinião também
já o mostramos na Primeira Parte e pelo que antes dissemos sobre o modo da união.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Verbo de Deus assumiu a alma unida com o corpo; e
por isso essa assunção tornou Deus o homem e o homem, Deus. Mas tal assunção não cessou pela
separação do Verbo, da alma e do corpo; cessou porém a união entre o corpo e a alma.

RESPOSTA À SEGUNDA. — O dizer-se que o homem é o seu intelecto não significa que o intelecto é o
homem na sua totalidade, mas que é a principal parte do homem, no qual existe virtualmente a
disposição total deste. Como se disséssemos que o chefe do Estado fosse todo o Estado, porque é ele
quem lhe dá a sua disposição total.

RESPOSTA À TERCEIRA. — Ser sacerdote convém ao homem em razão da alma, na qual está o caráter
da ordem. Por isso, pela morte, o homem não perde a ordem sacerdotal. E muito menos Cristo, origem
de todo sacerdócio.

## Art. 5 — Se o corpo de Cristo foi identicamente o mesmo quando vivo e quando morto.
O quinto discute-se assim. — Parece que o corpo de Cristo não foi identicamente o mesmo quando
vivo e quando morto.

1. — Pois, Cristo morreu verdadeiramente, como morrem os outros homens. Ora, o corpo de qualquer
forma não é identicamente o mesmo quando vivo e quando morto, absolutamente falando, porque há
entre um e outro uma diferença essencial. Logo, nem o corpo de Cristo foi identicamente o mesmo
quando vivo e quando morto.

2. Demais. — Segundo o Filósofo, coisas especificamente diversas são também diversas numericamente.
Ora, o corpo de Cristo foi especificamente diverso quando vivo e quando morto; pois, não dizemos que
um morto tem olhos ou carne senão em sentido equívoco, como ensina o Filósofo. Logo e em sentido
absoluto, o corpo de Cristo não foi identicamente o mesmo, quando vivo e quando morto.

3. Demais. — A morte é uma forma da corrupção. Ora o que sofre uma corrupção substancial já não
existe, depois de corrupto; pois, a corrupção é a passagem do ser para o não-ser. Logo, o corpo de
Cristo, depois de morto, não permaneceu identicamente o mesmo que antes era, pois a morte é uma
corrupção substancial.
Mas, em contrário, diz Atanásio: O corpo de Cristo quando circunciso, quando andava, quando
trabalhava e quando foi pregado na cruz era o Verbo de Deus impassível e incorpóreo; o mesmo se
conservou quando deposto no sepulcro. Ora, o corpo de Cristo estava vivo quando foi circunciciado e
pregado no madeiro; e estava morto, quando depositado no sepulcro. Logo, foi o mesmo o corpo vivo e
o morto.

SOLUÇÃO. — A expressão simplesmente falando é susceptível de dois sentidos. — Num, simplesmente
significa o mesmo que absolutamente; assim é dito absolutamente o que o é sem nenhum acréscimo,
como explica o Filósofo. E, neste sentido, o corpo de Cristo tanto vivo como morto foi simplesmente o
mesmo. Pois, dizemos que é simples e identicamente o mesmo o que o é pelo seu suposto. Ora, o corpo
de Cristo, tanto vivo como morto, teve o mesmo suposto, pois, vivo e morto não teve outra hipóstase
além da do Verbo de Deus, como dissemos. E é este o sentido das palavras citadas de Atanásio. —
Noutro sentido, simplesmente quer dizer completamente ou totalmente. E então, o corpo de Cristo vivo
não foi simplesmente o mesmo que quando morto. Porque não foi totalmente o mesmo; pois, fazendo a
vida parte da essência do corpo vivo, é dele um predicado essencial e não acidental. Donde resulta por
consequência que o corpo, deixando de ser vivo, não permanece totalmente o mesmo. Se, porém
disséssemos que o corpo de Cristo morto permaneceu totalmente o mesmo, seguir-se-ia que não ficou
corrupto, pela corrupção, digo, da morte. E essa é a heresia dos Gaianitas, como refere Isidoro e está
nas Decretais. E Damasceno diz, que a palavra corrupção tem dois sentidos: num significa a separação
das almas, do corpo e fenômenos semelhantes; noutro, a resolução perfeita aos elementos. Por onde,
dizer com Juliano e Gaiano, que o corpo do Senhor ficou incorruptível, conforme ao primeiro sentido da
corrupção, antes de ter ressurgido, é ímpio. Porque então o corpo de Cristo não teria sido
consubstancial com o nosso, nem teria verdadeiramente morrido, nem nós teríamos verdadeiramente
sido salvos. Mas, no segundo sentido, o corpo de Cristo foi incorrupto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O corpo morto de qualquer homem não continua unido
a nenhuma hipóstase permanente, como o corpo de Cristo morto. Por isso, o corpo morto de qualquer
homem não é absolutamente idêntico ao que era quando vivo, mas só de certo modo; porque conserva
a identidade material sem conservar a mesma forma. Ao contrário, o corpo de Cristo permaneceu
identicamente o mesmo, em sentido absoluto, por causa da identidade do suposto, como dissemos.

RESPOSTA À SEGUNDA. — Dizemos que um ser é identicamente o mesmo, pelo seu suposto; e
especificamente idêntico quando pela forma o é. Sempre que o suposto subsiste numa só natureza, por
força desapareceu a unidade numérica com a disparição da unidade específica. Ora, a hipóstase do
Verbo de Deus subsiste nas duas naturezas. Por onde, embora Cristo não continuasse a ter um corpo
idêntico, quanto à espécie da natureza humana, esse corpo continuou contudo a ser identicamente o
mesmo pelo suposto do Verbo de Deus.

RESPOSTA À TERCEIRA. — A corrupção e a morte não as teve que sofrer Cristo em razão do suposto,
tomando-se por suposto a unidade; mas em razão da natureza humana, segundo a qual havia no corpo
de Cristo uma diferença entre a morte e a vida.

## Art. 6 — Se a morte de Cristo produziu algum efeito para a nossa salvação.
O sexto discute-se assim. — Parece que a morte de Cristo não produziu nenhum efeito para a nossa
salvação.

1. — Pois, a morte é uma certa privação a da vida. Ora, a privação, não sendo nenhuma realidade, não
tem nenhuma virtude ativa. Logo, nada podia produzir para a nossa salvação.

2. Demais. — A Paixão de Cristo obrou a nossa salvação a modo de mérito. Ora, assim não podia
produza-Ia a sua morte; pois pela morte separa-se do corpo e alma, a qual é o princípio do mérito. Logo,
a morte de Cristo nada produziu para a nossa salvação.

3. Demais. — O corporal não pode ser a causa do espiritual. Ora, a morte de Cristo foi corporal. Logo,
não podia ser a causa espiritual da nossa salvação.
Mas, em contrário, diz Agostinho: A morte única do nosso Salvador, isto é, a corpórea, foi a salvação
para as duas mortes nossas, a saber, a da alma e a do corpo.

SOLUÇÃO. — De dois modos podemos considerar a morte de Cristo: no seu devir e na sua realização. -
Assim, dizemos que a morte de alguém está no seu devir, quando tende para ela, por algum sofrimento
natural ou violento. E neste sentido, o mesmo é falar da morte e da Paixão de Cristo. Em tal acepção,
pois, a morte de Cristo é a causa da nossa salvação, conforme ao que dissemos ao tratar da Paixão. -
Mas a morte de Cristo é considerada como realizada, pelo fato da separação entre o seu corpo e a sua
alma. E tal é o sentido em que agora tratamos dessa morte. Ora, nesta acepção, a morte de Cristo não
pode ser causa da nossa salvação a modo de mérito, mas só a modo de eficiência; isto é, enquanto que
nem pela morte a divindade se separou do corpo de Cristo. Donde, tudo o que se passou com o corpo
de Cristo, mesmo depois de separado da alma, foi-nos salutífero, era virtude da divindade que lhe
estava unida. - Mas, o efeito de uma causa é propriamente considerado tendo-se em vista a semelhança
com ela. Por onde, sendo a morte uma privação da vida própria, o efeito da morte de Cristo deve ser
considerado relativamente àremoção dos obstáculos contrários ànossa salvação; a esses são a morte da
alma e a do corpo. Por isso, dizemos, que a morte de Cristo destruiu em nós tanto a morte da alma -
segundo aquilo do Apóstolo: O qual foi entregue por nossos pecados - como a do corpo, consistente na
separação da alma - segundo aquele outro lugar: Flagrada foi à morte na vitória.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A morte de Cristo obrou a nossa salvação em virtude da
divindade que lhe estava unida, e não só em razão da morte.

RESPOSTA À SEGUNDA. — A morte de Cristo, considerada como realizada, embora não tenha obrado a
nossa salvação a modo de mérito, operou-a, contudo a modo de eficiência como dissemos.

RESPOSTA À TERCEIRA. — A morte de Cristo foi, por certo, corporal; mas o seu corpo foi o instrumento
da divindade que lhe estava unida, obrando em virtude dela, mesmo enquanto morto.