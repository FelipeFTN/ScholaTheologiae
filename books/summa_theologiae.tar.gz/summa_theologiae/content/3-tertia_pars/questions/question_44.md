# Questão 44: De cada uma das espécies de milagres.
Em seguida devemos tratar de cada uma das espécies de milagres.

## Art. 1 — Se houve conveniência nos milagres que Cristo fez em relação a substâncias espirituais.
O primeiro discute-se assim. — Parece que não houve conveniência nos milagres que Cristo fez em
relação a substâncias espirituais.

1. — Pois, entre as substâncias espirituais; os santos anjos governam os demônios; porque, como diz
Agostinho, o espírito pecador divorciado da vida racional, é governado pelo espírito de vida racional, pio
e justo. Ora, não lemos nos Evangelhos que Cristo tivesse feito nenhum milagre relativamente aos anjos
bons. Logo, também não devia ter feito nenhum relativamente aos demônios.

2. Demais. — Os milagres de Cristo tinham por fim manifestar-lhe a divindade. Ora, a divindade de
Cristo não devia ser manifestada aos demônios, o que viria impedir o mistério da sua paixão, segundo o
Apóstolo: Se eles a conheceram, nunca crucificariam ao Senhor da glória. Logo, nenhum milagre devia
Cristo fazer relativamente aos demônios.

3. Demais. — Os milagres de Cristo se ordenavam à glória de Deus; por isso diz o Evangelho, que as
turbas, vendo um paralítico curado por Cristo, temeram e glorificaram a Deus porque deu tal poder aos
homens. Ora, não é próprio dos demônios glorificar a Deus, porque o louvor não tem beleza na boca do
pecador, no dizer da Escritura. Por onde, como dizem Marcos e Lucas, Cristo não permitia aos demônios
proclamarem nada do atinente à sua glória. Logo, parece não era conveniente que fizesse nenhum
milagre relativamente a eles.

4. Demais. — Os milagres feitos por Cristo se ordenam à salvação dos homens. Ora, certos demônios
foram expulsos de certos homens, em detrimento deles. Às vezes corporal; assim; refere o Evangelho,
que o demônio, por ordem de Cristo, dando grandes gritos e maltratando muito o homem, saiu dele; e
ficou como morto, de sorte que muitos diziam — está morto. Outras vezes também em detrimento das
coisas, como quando se fez os demônios se introduzirem em porcos, que se precipitaram no mar; sendo
por isso Cristo rogado pelos habitantes da região a sair do país deles, como lemos no Evangelho. Logo,
parece que esses milagres eram inconvenientes.
Mas, em contrário, a Escritura o prenunciou, quando disse: Exterminarei da terra o espírito imundo.

SOLUÇÃO. — Os milagres que Cristo fez serviam de argumentos em favor da fé que pregava. Pois,
haveriam de vir homens crentes nele que, por virtude da sua divindade, suplantassem o poder dos
demônios, conforme lemos no Evangelho: Agora será lançado fora o príncipe deste mundo. Por isso, foi
conveniente que, entre outros milagres, também livrasse os obsessos dos demônios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como os homens deviam ser livrados por Cristo do
poder dos demônios, assim também deviam ser por ele associados aos anjos, segundo aquilo do
Apóstolo: Pacificando pelo sangue da sua cruz tanto o que está na terra como o que está no céu. Por
isso, o único milagre que convinha fazer, relativamente aos anjos, é que estes aparecessem aos homens;
e isso se deu na natividade, a ressurreição e a ascensão.

RESPOSTA À SEGUNDA. — Como diz Agostinho, Cristo deu-se a conhecer aos demônios na medida em
que lh'o aprouve; e tanto lhe aprouve quanto era necessário. Mas deu-se-lhes a conhecer não como aos
santos anjos, pelas causas da vida eterna, mas por certos efeitos temporais do seu poder. Assim,
primeiro, vendo Cristo ter fome depois do jejum, não o tiveram por Filho de Deus. Por isso, àquilo do
Evangelho — Se és o Filho de Deus — diz Ambrósio: Que quer o demônio significar, começando com
essa pergunta, senão que sabe que o Filho de Deus havia de vir, mas não o julgava sujeito às
necessidades do corpo? Mas depois, à vista dos milagres, conjeturou, por suspeitas, que fosse o Filho de
Deus. Por isso, aquilo do Evangelho — Bem sei quem és: que és o Santo de Deus — diz Crisóstomo, que
não tinha um conhecimento certo ou firme do advento de Deus. Sabia, porém que Cristo tinha sido
prometido pela lei, sendo por isso que diz o Evangelho: Sabiam que ele mesmo era o Cristo. E quanto ao
terem-no confessado Filho de Deus, o fizeram mais por suspeita que por certeza. Por isso Beda diz: Os
demônios confessam o Filho de Deus; e como a seguir se refere: Sabiam que ele era o Cristo. Porque,
vendo-o o diabo exausto pelo jejum, tomou-o como um verdadeiro homem; mas, pelo não ter vencido
com a tentação, entrou a duvidar se não seria o Filho de Deus. Mas quando deu provas do seu poder,
pelos milagres, ou compreendeu, ou antes, suspeitou que fosse o Filho de Deus. E se persuadiu aos
judeus que o crucificassem, não foi pelo não reputar Filho de Deus, mas por não prever que seria
vencido pela morte dele. Assim, desse mistério recôndito aos séculos, diz o Apóstolo, que ninguém, dos
príncipes deste mundo, o conheceu; pois, se o tivessem conhecido nunca teriam crucificado o Senhor da
glória.

RESPOSTA À TERCEIRA. — O milagre da expulsão dos demônios Cristo não o fez para utilidade deles,
mas para a dos homens, a fim de que o glorificassem. E por isso proibiu-os proclamarem-lhe o louvor. —
Primeiro, para exemplo. Pois, como diz Atanásio, impedia o demônio de falar, embora fosse para
proclamar a verdade, para também nós nos acostumarmos a desprezar tais ditos, mesmo pareçam
traduzir a verdade. Pois, é pecaminoso deixarmo-nos instruir pelo diabo, quando temos à nossa
disposição a Escritura divina; o contrário seria perigoso, porque os demônios frequentemente misturam
a mentira com a verdade. — Segundo, porque, como diz Crisóstomo (Cirilo Alexandrín.) não deviam eles
arrebatar a glória do ofício apostólico. Nem convinha que uma boca impura fosse a que publicasse o
mistério de Cristo, porque o louvor não tem beleza na boca do pecador. — Terceiro, porque, como diz
Beda (Teofílacto), não queria desse modo despertar a inveja dos Judeus. Por isso também os próprios
Apóstolos foram mandados calar a respeito dele, a fim de não diferirem o mistério da paixão com a
proclamação da divina majestade.

RESPOSTA À QUARTA. — Cristo veio especialmente ensinar e fazer milagres para utilidade dos homens,
sobretudo quanto à salvação da alma. Por isso permitiu aos diabos, que expulsava, causar certos danos
aos homens, quer na pessoa quer nos bens deles, para a salvação da alma humana, por meio da
instrução deles. Por isso diz Crisóstomo, que Cristo permitiu aos demônios introduzirem-se nos porcos.
Não que disso o persuadissem aqueles; mas, primeiro, para nos mostrar a grandeza do dano que
causam aos homens as insídias dos demônios. Segundo, para que todos compreendessem que nem
contra porcos ousam fazer nada, sem o consentimento dele, Cristo. Terceiro, para mostrar que
causariam maiores danos aqueles homens, que aos referidos porcos, se os homens não fossem ajudados
da providência divina. E também por essas mesmas causas permitiu que o libertado dos demônios fosse
na mesma hora afligido mais gravemente, de cuja aflição porém logo o livrou. O que também mostra,
como diz Beda, que muitas vezes, quando nos esforçamos por nos converter a Deus, depois dos
pecados, o nosso antigo inimigo nos arma maiores e novas insídias. E isso faz ou para nos incutir o ódio
da virtude ou para vingar-se da injúria sua expulsão. E enfim, o homem curado tornou-se como morto,
porque, explica Jerônimo, aos curados foi dito: Já estais mortos e a vossa vida está escondida com'
Cristo em Deus.

## Art. 2 — Se Cristo fez convenientemente milagres em relação aos corpos celestes.
O segundo discute-se assim. — Parece que Cristo não fez convenientemente milagres em relação aos
corpos celestes.

1. — Pois, como diz Dionísio, não é próprio da divina providência destruir, mas conservar. Ora, os corpos
celestes são de natureza incorruptível e inalterável, como o prova Aristóteles. Logo, não devia Cristo
fazer nenhuma mudança na ordem dos corpos celestes.

2. Demais. — Pelo movimento dos corpos celestes é que se demarca o curso dos tempos, segunda a
Escritura: Façam-se uns luzeiros no firmamento do céu e sirvam de sinais para mostrar os tempos, os
dias e os anos. Assim, pois, mudado o curso dos corpos celestes, muda-se também a distinção e a ordem
dos tempos. Ora, não há notícia que essa mudança fosse percebida pelos astrólogos, que contemplavam
os astros e contavam os meses, no dizer da Escritura. Logo, parece que Cristo não fez nenhuma
mudança relativamente ao curso dos corpos celestes.

3. Demais. — Era mais curial que Cristo fizesse milagres, quando vivia e ensinava, que na sua morte. Ou
porque, como diz o Apóstolo. Foi crucificado por enfermidade, mas vive pelo poder de Deus, pelo qual
fazia milagres; e quer também por lhe serem os milagres a confirmação da doutrina. Ora, não nos diz o
Evangelho, que durante a sua vida Cristo fizesse algum milagre relativo aos corpos celestes; ao
contrário, aos f'ariseus que lhe pediam um sinal do céu, recusou dar-lhes, como lemos no Evangelho.
Logo, parece que na ocasião da sua morte também não devia fazer nenhum milagre relativamente aos
corpos celestes.
Mas, em contrário, o Evangelho: Toda a terra ficou coberta de trevas até a hora nona e escureceu-se
também o sol.

SOLUÇÃO. — Como dissemos os milagres de Cristo deviam ser tais que lhe patenteassem
suficientemente a divindade. Ora, não a manifestam evidentemente as transmutações dos corpos
inferiores, que também podem ser alterados por outras causas, como pela transmutação do curso dos
corpos celestes, o qual só por Deus foi ordenado de maneira imutável. E é o que diz Dionísio: Devemos
saber que se alguma mudança pode houver na ordem e no movimento dos céus, só o poderá ser pela
causa que fez e muda todas as causas por uma simples palavra. Por isso houve conveniência em Cristo
fazer milagres mesmo em relação aos corpos celestes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como é natural aos corpos inferiores serem
movidos pelos corpos celestes, que lhes são superiores na ordem da natureza, assim também é natural
a qualquer criatura ser mudada por Deus conforme os decretos da sua vontade. Por isso diz Agostinho, e
também se lê na Glosa àquilo do Apóstolo — Contra a natureza foste enxertado etc. Deus, Criador e
Autor de todas as naturezas, nada faz contra a natureza, pois a natureza de cada ser tem nele a sua
fonte. Por isso, não se corrompe a natureza dos campos celestes quando Deus lhes altera o curso;
corromper-se-ia porém se fosse alterado por alguma outra causa.

RESPOSTA À SEGUNDA. — O milagre feito por Cristo não perverteu a ordem dos tempos. Pois, segundo
certos, essas trevas ou obscurecimento do sol, que se verificaram na paixão de Cristo, tiveram a sua
causa na retração dos raios solares, sem nenhuma mudança causada no movimento dos corpos celestes,
pelo qual se medem ostempos. Donde o dizer Jerônimo: O Campadário maior retraiu os seus raios ou
para que não visse o Senhor pendente da cruz, ou para que não lhe gozassem dos raios ou ímpios
blasfemadores. — Essa retração dos raios porém não deve entender-se como significando que o sol
tenha o poder de emitir ou retrair raios, pois, ele os emite não por eleição, mas por natureza, como diz
Dionísio. Mas se diz que o sol retraiu os raios por não terem eles, por virtude do poder divino, chegado
até a terra. Orígenes, porém explica esse fato pela interposição das nuvens. Devemos por consequência
entender, diz, que muitas e grandes nuvens tenebrosissímas se acumulavam sobre o céu de Jerusalém,
terra da Judéia donde resultaram as trevas profundas desde a sexta até a nona hora. Penso, pois, que
assim como o ter-se cindido o véu do templo, o tremor da terra e outros fenômenos que se verificaram
durante a paixão, só se deram em Jerusalém, assim também no caso vertente. Podemos, porém,
tomando o texto - Toda a terra ficou coberta de trevas num sentido mais lato, aplicá-lo a toda a terra de
Judéia pois, em tal sentido a elo se aplica, como quando, conforme lemos na Escritura, disse Abdias a
Elias — Viva o Senhor teu Deus, que não há nação nem reino onde meu amo te não tenha mandado
buscar — mostrando que o buscara entre as gentes que habitavam perto da Judéia.
Mas, nesta matéria, devemos seguir antes a Dionísio, que, como testemunha ocular, compreendeu que
tal fato foi possível pela interposição da lua entre nós e o sol. Assim, diz: Vimos — estava então no Egito
— inopinadamente a lua ocultar o sol. E descobre aí quatro milagres. — O primeiro é que naturalmente
o eclipse do sol, por interposição da lua, nunca se dá senão quando esses astros estão em conjunção.
Ora, então a lua estava em oposição com o sol, pois era o décimo quinto dia, depois da lua nova,
quando se celebrou a Páscoa dos Judeus. Por isso: Pois, não era o tempo oportuno. — O segundo
milagre consistiu em ter a lua sido vista simultaneamente com o sol, no meio do céu, cerca da hora
sexta; e de tarde apareceu no seu lugar, isto é, no oriente, oposta ao sol. Por isso diz: E de novo a vimos,
isto é, a lua, desde a hora nona, quando se afastou do sol e cessaram as trevas, até a tarde, imposta por
uma ação sobrenatural na linha dia me trai do sol, isto é, diametralmente oposta do sol. Donde se
concluiu que não foi perturbado o curso habitual dos tempos, pois o poder divino fez com que a lua,
sobrenaturalmente, se aproximasse do sol no tempo oportuno, e depois, afastando-se do sol, no tempo
devido se colocasse de modo no seu lugar próprio. — O terceiro milagre esteve no seguinte. Uma
eclipse natural sempre com cada parte ocidental do sol para acabar na parte oriental; porque a lua tem
o seu movimento próprio, do ocidente para o oriente, mais veloz que o movimento próprio do sol; por
isso, vindo do ocidente, alcança o sol e o ultrapassa, tendendo para o oriente. Mas, no caso vertente, a
lua já tinha ultrapassado o sol e distava dele a metade do círculo, estando-lhe em oposição. Por onde
havia necessàriamente de voltar para o oriente em direção ao sol e alcançá-lo primeiro pela parte
oriental, dirigindo-se para o ocidente. E é o que diz Dionísio: Também vimos a eclipse, começando da
parte oriental, chegar ao termo do sol, porque eclipsou-o todo, e depois retroceder. — O quarto milagre
consistiu no seguinte. No eclipse natural o sol começa a reaparecer pela parte que principiou primeiro a
obscurecer-se: porque a lua, pondo-se na frente do sol, pelo seu movimento natural o ultrapassa em
direção ao oriente; e assim, a parte ocidental do sol, que primeiro ocupou, é também a que primeiro
abandona. Mas, no caso em discussão, a lua, voltando milagrosamente do oriente para o ocidente, não
ultrapassou o sol, de modo a ficar mais ao ocidente, que ele. Mas, depois de ter chegado ao termo do
sol, voltou para a parte oriental; e assim, a parte do sol, que por último ocupou, foi também a que
primeiro abandonou. Por onde, o eclipse começou pela parte oriental, mas a claridade começou
primeiro a manifestar-se pela parte ocidental. E é o que diz Dionísio: E de novo vimos, não do mesmo
lugar, isto é, não da mesma parte do sol, mas ao contrário no sentido do diâmetro, começar o eclipse e
acabar. — Crisóstomo acrescenta ainda um quinto milagre dizendo, que as trevas duraram três horas,
apesar do eclipse solar ter se consumado num instante; pois, não foi demorado, como o sabem os que o
observaram. Pelo que dá a entender que a lua parou diante do sol. A não ser que preferíssemos dizer
que o tempo das trevas deve ser contado desde o instante em que o sol começou a obscurecer-se até o
momento em que ficou de novo totalmente livre. Mas, diz Orígenes, os filhos deste século objetam
contra um tal prodígio, perguntando: — Como é que um fato tão admirável nenhum dos gregos nem
dos bárbaros o descreveu? E refere que um certo Flegonte escreveu, nas suas Crônicas, que esse fato se
deu no principado de Tibério César; mas não especificou que foi por ocasião de uma lua cheia. E isso
podia ter acontecido, porque os astrólogos de todas as terras, que viviam nesse tempo, não se
preocupavam em observar nenhum eclipse por não ser então ocasião de nenhum; de modo que
atribuíram as trevas que presenciavam, a algum fenômeno atmosférico. Mas no Egito, onde raramente
aparecem nuvens, por causa da serenidade do ar, Dionísio e os seus companheiros foram levados a
observar o eclipse referido, causa da obscuridade.

RESPOSTA À TERCEIRA. — Cristo devia, sobretudo, manifestar por milagres a sua divindade, quando
mais se lhe faziam sentir as necessidades da natureza humana. Por isso, na sua natividade apareceu
uma nova estrela no céu. Donde o dizer Máximo: Se desprezas o presépio, levanta um pouco os olhos e
contempla a nova estrela do céu, anunciando ao mundo a natividade do Senhor. — Mas na paixão a
humanidade de Cristo foi sujeita a uma miséria ainda maior. Por isso era necessário que maiores
milagres se realizassem no tocante aos principais Iuzeiros do mundo. E, como diz Crisóstomo, esse foi o
sinal prometido aos que o pediam, quando disse, aludindo à sua cruz e ressurreição: Esta geração
pervessa e adúltera pede um prodígio e não lhe será dado outro prodígio senão o prodígio do profeta
Jonas. Pois, isso era muito mais admirável que o fizesse, quando crucificado, do que quando andava na
terra.

## Art. 3 — Se Cristo fez com conveniência milagres em relação aos homens.
O terceiro discute-se assim. — Parece que Cristo não fez com conveniência milagres em relação aos
homens.

1. — Pois, no homem a alma é superior ao corpo. Ora, Cristo fez muitos milagres em relação aos corpos;
mas não lemos que fizesse nenhuns sobre as almas. Pois, nem converteu miraculosamente nenhuns
incrédulos a fé, mas advertindo-os e mostrando-lhes os milagres exteriores; nem referem os Evangelhos
que desse sabedoria a nenhuns fatuos. Logo, parece que não obrou com conveniência milagres em
relação aos homens.

2. Demais. — Como se disse, Cristo fazia milagres pelo seu poder divino, ao qual é próprio obrar súbita e
perfeitamente e sem o auxílio de ninguém. Ora, Cristo nem sempre curava subitamente o corpo
humano. Assim, refere o Evangelho, que tomando o cego pela mão, o tirou para fora da aldeia; e
cuspindo-lhe nos olhos, tendo-lhe imposto as suas mãos, lhe perguntou se via alguma coisa. E
levantando ele os olhos disse: Vejo os homens como árvores que andam. Depois tornou-lhe Jesus a pôr
as mãos sobre os olhos, e começou ele a ver e ficou de todo curado, de sorte que via distintamente
todos os objetos. Por onde é claro que não o curou subitamente, mas, primeiro de um modo imperfeito,
cuspindo-lhe nos olhos. Logo, parece que não fez com conveniência milagres em relação aos homens.

3. Demais. — Não é necessário eliminarem-se simultaneamente coisas que não resultam uma da outra.
Ora, as doenças do corpo nem sempre são causadas pelo pecado, como é claro pelas palavras do
Senhor: Não nasceu cego por pecado que ele fizesse, nem seus pais. Logo, não devia perdoar os pecados
a quem só lhe vinha pedir a cura do corpo, como lemos no Evangelho que fez com o paralítico.
Sobretudo que, sendo a restituição da saúde do corpo menor bem que a remissão dos pecados, não
constituía prova suficiente do seu poder de perdoar os pecados.

4. Demais. — Os milagres de Cristo foram feitos em confirmação da sua doutrina e do testemunho da
sua divindade, como se disse. Ora, ninguém deve opor obstáculo ao fim da sua própria obra. Logo,
parece que Cristo não devia ter ordenado a certos curados milagrosamente não publicarem os milagres
de que foram objeto. Assim, sobretudo que a certos outros mandou proclamarem os milagres que lhes
fez; assim, como lemos no Evangelho, disse aquele a quem livraria dos demônios: Vai para a tua casa,
para os teus, e anuncia-lhes quão grandes coisas o Senhor te fez.
Mas, em contrário, o Evangelho: Ele tudo tem bem jeito; fez não só que ouvissem os surdos, mas que
falassem os mudos.

SOLUÇÃO. — Os meios conducentes a um fim devem ser-lhe proporcionados. Ora, Cristo veio ao mundo
ensinar, para salvar os homens, segundo aquilo do Evangelho: Deus não enviou seu filho ao mundo para
condenar o mundo, mas para que o mundo seja salvo por ele. Logo, era conveniente que, em particular,
curando milagrosamente os homens, se mostrasse o Salvador universal e espiritual deles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os meios conducentes a um fim são destes distintos.
Ora, os milagres feitos por Cristo ordenavam-se, como ao fim, à salvação da parte racional, consistente
na iluminação da sabedoria e na justificação dos homens. E desses fins o primeiro pressupõe o segundo;
pois, como diz a Escritura, na alma que é maligna não entrará a sabedoria nem habitará no corpo sujeito
a pecados. Ora, justificar os homens não era possível sem a cooperação da vontade deles; o contrário se
oporia à justiça, que por essência implica a retidão da vontade, e também à essência da natureza
humana, que deve ser conduzida ao bem pelo livre arbítrio e não pela coação. Ora, Cristo pelo seu
poder divino justificava os homens interiormente, mas não contra a vontade deles. Nem isso constituía
a essência, mas o fim dos milagres. Semelhantemente, também pelo seu poder divino, infundiu a
sabedoria divina em homens simples como eram os discípulos; donde o dizer-lhes: Eu vos darei uma
boca e uma sabedoria à qual não poderão resistir nem contradizer todos os vossos inimigos. O que,
quanto à iluminação interior, não se enumera entre os milagres visíveis; mas só quanto ao ato exterior,
pois viram falar tão sábia e constantemente homens os que eram iletrados e simples. Por isso diz a
Escritura: Vendo os judeus a firmeza de Pedro e de João, depois de saberem que eram homens sem
letras e idiotas, se admiravam. — E contudo esses efeitos espirituais; embora distintos dos milagres
visíveis, são todavia uns testemunhos da doutrina e do poder de Cristo, segundo aquilo do Apóstolo:
Confirmando-o com maravilhas e sinais e com virtudes diversas e com dons do Espírito Santo. Cristo,
porém fez certos milagres sobre as almas dos homens, sobretudo atinentes a transformações nas
potências inferiores delas. Por isso, àquilo doEvangelho. — Levantando-se ele, a seguiu — diz Jerônimo:
O próprio resplendor e a majestade da divindade oculta que lhe iluminava mesmo a face humana, podia
desde logo atrair para si os que uma vez o contemplavam. E aquele outro lugar doEvangelho — Os
príncipes dos sacerdotes, etc., diz o mesmo Jerônimo: Dentre todos os milagres que fez o Senhor
parece-me o mais admirável o ter podido ele só, como homem, e desprezível nesse tempo, expulsar
uma tão grande multidão aos golpes de um chicote. Os olhos resplendiam-lhe como com raios ígneos de
sol e a majestade divina iluminava-lhe a face. E Origines considera esse, maior milagre que o da
conversão da água em vinha; pois, neste a matéria subsistia inanimada, ao passo que no primeiro o seu
engenho dominou tantos milhares de homens. — E sobre aquele dito do evangelista — Recuaram para
trás e caíram por terra - diz Agostinho: Com uma palavra, sem nenhuma arma abateu, repeliu e
dispersou uma turba tão feroz pelo ódio quão terrível pelas armas: é que Deus animava aquele corpo. —
E a isto também respeita aquele outro passo, que Jesus passando pelo meio deles, se retirou; à cerca do
qual diz Crisóstomo, que o estar no meio dos que o buscavam para prender, e não ser preso mostrava a
eminência da sua divindade. E ainda há outro passo - Jesus escondeu-se e saiu do templo - que
Agostinho explica assim: Não se escondeu num canto do Templo nem se ocultou atrás de uma parede
ou de uma coluna, como quem teme, mas tornando-se invisível, por um poder celeste, aos que o
buscavam, saiu passando pelo meio deles. — E tudo isso mostra que Cristo, pelo seu poder divina,
causou mudanças nas almas doshomens, quando o quis, não só justificando e infundindo a sabedoria —
a que constitui a fim dos milagres, mas também exteriormente aliciando, aterrorizando ou
estupefazendo - o que constitui a essência mesma dos milagres.

RESPOSTA À SEGUNDA. — Cristo veio salvar o mundo, não só pela seu poder divino, mas também pelo
mistério da sua Encarnação. Por isso frequentemente, ao curar os enfermas, não somente usava esse,
fazendo-os sarar por uma simples ordem, mas ainda fazia contribuir para tal a sua humanidade. Por isso,
aquilo doEvangelho — Pondo as mãos sobre cada um deles, os sarava — diz Cirílo: Embora, como Deus,
pudesse curar com uma palavra todas as doenças, contudo toca os doentes, mostrando assim ser o seu
próprio corpo capaz de contribuir como um remédio eficaz. E aquele outra lugar — Cuspindo-lhe nos
olhos, tendo lhe imposto as mãos, etc. diz Crisóstomo. (Vítor Antíoqueno): Cuspiu-lhe nos olhos e impôs
as mãos ao cego, a fim de mostrar que a palavra divina, acompanhada do ato, perfazia os milagres; pois,
a mão indica o ato; o cuspir, a palavra proferida pela boca. — E a propósito do outro passo evangélico -
Cuspiu no chão e fez lodo do cuspe e untou com o lodo os olhos do cego, diz Agostinho: Com a sua saliva
fez o lodo, porque o Verbo se fez carne. Ou também para significar que foi ele quem formou o homem
do limo da terra, como diz Crisóstomo.
Também devemos considerar, sobre os milagres de Cristo, que comumente as suas obras eram
perfeitíssimas. Por isso, àquilo do Evangelho - Todo homem põe primeiro o bom vinho — diz
Crisóstomo: Os milagres de Cristo são tais que em muito soprepujando em utilidade e beleza quanto a
natureza pode produzir. — E semelhantemente, num instante restituía aos enfermos a saúde perfeita.
Por isso, ao lugar do Evangelho — Tendo chegado Jesus, diz Jerônimo: O Senhor restituía a saúde, total e
simultâneamente.
Especialmente, porém, no caso do cego, deu-se o contrário, por causa da infidelidade dele, como diz
Crisóstomo (Vítor Antroqueno) Ou, como diz Beda, aquele a quem podia curar total e simultaneamente,
a esse o cura aos poucos para mostrar a magnitude da cegueira humana, que aos poucos e como
gradualmente é que pode iluminar-se; a fim de nos chamar a atenção sobre a sua graça, com a qual
auxilia cada progresso na perfeição.

RESPOSTA À TERCEIRA. — Como dissemos Cristo fazia milagres pelo seu poder divino. Ora, as obras de
Deus são perfeitas, como diz a Escritura. Mas, só é perfeito o que atinge o seu fim. E o fim da cura do
corpo, operada por Cristo, era a cura da alma. Por isso, não devia Cristo curar o corpo de ninguém, sem
lhe curar a alma. Por onde, aquilo do Evangelho — Em dia de sábado curei a todo um homem — diz
Agostinho: Por ter sido curado, para ter a saúde do corpo, também acreditou, para que tivesse a saúde
da alma. — Mas especialmente disse ao paralítico — São te perdoados os pecados: porque, como diz
Jerônimo, nos der assim a entender que os pecados causam em nosso corpo muitas enfermidades, e foi
essa talvez a razão de Cristo perdoar primeiro os pecados a fim de eliminadas as causas da doença, ser
restituída a saúde. Por isso diz o Evangelho: Não peques mais, para que te não suceda alguma coisa pior.
O que Crisóstomo explica dizendo: Ficamos assim informados que do pecado é que lhe nasceu a doença.
— Embora também, como diz Crisóstomo, quanto mais principal é a alma, que o corpo, tanto mais
importante é perdoar os pecados, que restituir a saúde do corpo; mas, como esse perdão não se
manifesta exteriormente, Cristo obra o menos importante, mas mais manifesto, para dar a conhecer o
mais importante, embora não manifesto.

RESPOSTA À QUARTA. — Aquilo do Evangelho — Vede lá que o não saiba alguém — diz Crisóstomo: O
que aqui diz não é contrário ao que tinha dito ao outro: Vai e anuncia a glória de Deus. Pois, assim nos
adverte a impedir de nos louvarem os que o fazem, tendo em vista a nossa pessoa como tal. Mas, se o
louvor que nos tributam se referir à glória de Deus, não devemos impedi-los, mas ao contrário, desejar
que o façam.

## Art. 4 — Se Cristo fez convenientemente milagres atinentes às criaturas irracionais.
O quarto discute-se assim. — Parece que Cristo não fez convenientemente milagres atinentes às
criaturas irracionais.

1. — Pois, os brutos são superiores às plantas. Ora, Cristo fez milagres relativos as plantas; assim, a sua
palavra fez secar uma figueira, como lemos no Evangelho. Logo, parece que também devia ter feito
milagres relativos aos brutos.

2. Demais. — A pena só por uma culpa éque é justamente aplicada. Ora, a figueira não tinha culpa de
Cristo não a ter encontrado com frutos, pois, deles não era tempo. Logo, parece que não devia tê-la
feito secar.

3. Demais. — A água e o ar estão entre o céu e a terra. Ora, Cristo fez certos milagres no céu, como se
disse. E também na terra, quando esta tremeu, por ocasião da paixão. Logo, parece que também devia
ter feito como objeto de seus milagres O ar e a água; e assim, dividir o mar, como o fez Moisés; ou ainda
um rio, como o fizeram Josué e Elias; e também causar trovões no ar, como se deu no monte Sinai,
quando foi dada a lei, e como o fez Elias.

4. Demais. — A divina Providêncía se serve das obras milagrosas para governar o mundo. Ora, essas
obras pressupõem a criação. Logo, Cristo não devia, nos seus milagres, recorrer à criação, como quando,
por exemplo, multiplicou os pães. Logo, parece que não houve conveniêncía nos seus milagres, relativos
às criaturas irracionais.
Mas, em contrário, Cristo é a sabedoria de Deus, da qual diz a Escritura: Dispõe todas as causas com
suavidade.

SOLUÇÃO. — Como dissemos, os milagres de Cristo se ordenavam a manifestar-lhe o poder divino, para
a salvação dos homens. Ora, por natureza ao poder divino hão de lhe estar sujeitas todas as criaturas.
Logo, devia ele ter feito milagres em relação a todo gênero de criaturas; e assim, não só em relação aos
homens, mas também em relação às criaturas irracionais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os brutos são genericamente próximos ao homem,
sendo por isso feitos no mesmo dia que ele. E como Cristo fez muitos milagres atinentes ao corpo
humano, não estava obrigado a fazer nenhuns relativos ao corpo dos brutos. Sobretudo porque, quanto
à natureza sensível e corpórea, o homem tem a mesma natureza que os outros animais, sobretudo
terrestres. Os peixes, porém, vivendo na água, diferem mais da natureza dos homens, e por isso foram
feitos em outro dia. E em relação a eles Cristo fez o milagre da copiosa pesca, que refere oEvangelho; e
também o do peixe que Pedro pescou e no qual achou um estater. — Quanto ao fato dos porcos
precipitados no mal, não foi essa uma obra milagrosa de Deus, mas ato dos demônios, por permissão
divina.

RESPOSTA À SEGUNDA. — Como diz Crisóstomo, quando o Senhor opera obras tais sobre os plantas ou
os brutos, não indagues se houve justiça no fazer secar-se a figueira, por não ter frutos, apesar de não
ser tempo deles; pois, essa indagação seria grande demência, porque tais seres não são susceptíveis de
culpa nem de pena; mas antes, atende ao milagre e admira-lhe o autor. Nem faz o Criador nenhuma
injustiça a quem possui, quando usa da criatura, a seu talante, para a salvação dos homens. Ao
contrário, como nota Hilário, nisso descobrimos um argumento da bondade divina. Pois, quando quis
dar um exemplo da salvação, que veio trazer, exerceu a força do seu poder sobre corpos humanos;
quando porém aplicou a sua severidade contra os contumazes, indicou o que havia de acontecer,
amaldiçoando a figura. E sobretudo como diz Crisóstomo, a figura, que é humudíssima, manifesta um
maior milagre.

RESPOSTA À TERCEIRA. — Cristo também fez milagres, que convinha fazer, em relação à água e ao ar;
assim, quando, segundo lemos no Evangelho, pôs preceito ao mar e aos ventos e logo se seguiu uma
grande bonança. Não era conveniente, porém, a quem vinha repor tudo no estado de paz e de
tranquilidade causar qualquer perturbação no ar ou divisão nas águas. Donde o dizer o Apóstolo: Não
vos haveis ainda chegado ao monte palpável e ao fogo incendido e ao turbilhão e à obscuridade e à
tempestade. Na sua paixão, porém, rasgou-se o véu do templo, em duas partes, para mostrar a
revelação dos mistérios da lei; abriram-se as sepulturas, para mostrar que pela sua morte seria dada aos
mortos a vida; tremeu a terra e partiram-se as pedras, a fim de mostrar que os corações empedernidos
dos homens se abrandariam com a sua paixão e que todo o mundo, por virtude dessa paixão, se
mudaria para melhor.

RESPOSTA À QUARTA. — A multiplicação dos pães não se fez a modo de criação, mas pelo
acrescentamento de uma certa matéria estranha, convertida em pães. Donde o dizer Agostinho: Do
mesmo modo que com poucos grãos multiplica as sementeiras, assim nas suas mãos multiplicou os
cinco pães. Ora, é manifesto que, por conversão de matéria, os grãos produzem colheitas abundantes.