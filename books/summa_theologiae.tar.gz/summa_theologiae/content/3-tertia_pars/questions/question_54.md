# Questão 54: Da qualidade de Cristo ressurrecto
Em seguida devemos tratar da qualidade de Cristo ressurrecto, E nesta questão discutem-se quatro
artigos:

## Art. 1 — Se Cristo depois da ressurreição tinha um verdadeiro corpo.
O primeiro discute-se assim. Parece que Cristo depois da ressurreição não tinha um verdadeiro corpo.

1. — Pois, um corpo verdadeiro não pode coexistir com outro num mesmo lugar. Ora, o corpo de Cristo
depois da ressurreição coexistiu com outro corpo num mesmo lugar; pois, entrou a ter com os seus
discípulos, estando as portas fechadas, como refere o Evangelho. Logo, parece que Cristo, depois da
ressurreição não teve um verdadeiro corpo.

2. Demais. — Um corpo verdadeiro não se desvanece aos olhos dos que o vêem, salvo se corromper-se.
Ora, o corpo de Cristo desvaneceu-se aos olhos dos discípulos que o contemplavam, como diz o
Evangelho. Logo parece que Cristo depois da ressurreição não teve um verdadeiro corpo.

3. Demais. — Todo corpo verdadeiro tem uma figura determinada. Ora, o corpo de Cristo apareceu aos
discípulos, em outra forma, como está claro no Evangelho. Logo, parece que Cristo, depois da
ressurreição, não tinha um corpo verdadeiramente humano.
Mas, em contrário, diz o Evangelho, que tendo Cristo aparecido aos discípulos, eles achando-se
perturbados e espantados, cuidavam que viam algum espírito, por pensarem que tinha um corpo, não
verdadeiro, mas fantástico. E para desiludi-los Cristo depois acrescentou: Apalpai e vê de que um
espírito não tem carne nem ossos como vós vedes que eu tenho. Logo, não tinha um corpo fantástico,
mas verdadeiro.

SOLUÇÃO. — Como diz Damasceno, ressurgir é próprio de quem caiu. Ora, o corpo de Cristo caiu pela
morte, por se ter dele separada a alma, que era a sua perfeição formal. Por isso, para ser verdadeira a
ressurreição de Cristo, era necessário que o mesmo corpo de Cristo de novo se lhe unisse à alma. E
como a verdadeira natureza do corpo lhe advém da forma, consequentemente, o corpo de Cristo,
depois da ressurreição, tanto foi um corpo verdadeiro, como tinha a mesma natureza de antes. Se, ao
contrário o seu corpo fosse fantástico, a ressurreição não teria sido verdadeira, mas aparente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O corpo de Cristo. depois da ressurreição, não por
milagre, mas pela sua condição gloriosa - dizem certos — entrou a ter com os discípulos, estando as
portas fechadas, ocupando simultaneamente com outro corpo o mesmo lugar. O fato porém de poder o
corpo glorioso, em virtude de uma propriedade que lhe seja inerente, coexistir com outro corpo num
mesmo lugar, será discutido mais adiante, quando tratarmos da ressurreição geral. Mas agora, no caso
vertente, basta dizermos que não foi pela natureza do corpo de Cristo, mas antes em virtude da
divindade que lhe estava unida, que chegou até os discípulos, embora fosse verdade que entrou
estando as portas fechadas. Por isso diz Agostinho, num Sermão pascal, que certos disputam e
perguntam como, sendo realmente corpo o que morreu na cruz e ressurgiu do sepulcro, pôde entrar
estando as portas fechadas? E responde: Se compreenderes o modo, verás que não houve nenhum
milagre. O que a razão não alcança a fé nos faz aceitar. E noutro lugar: Ao corpo material, ao qual estava
unida a divindade, não podiam portas fechadas constituir um obstáculo; pois, quem nasceu, sem causar
detrimento à inviolabilidade da virgindade materna, bem podia também entrar por portas fechadas. E o
mesmo diz Gregório numa homilia.

RESPOSTA À SEGUNDA. — Como dissemos, Cristo ressurgiu para a vida imortal da glória. Ora, por
disposição o corpo glorioso é espiritual, isto é, sujeito do espírito, como diz o Apóstolo. Mas, para um
corpo ser plenamente sujeito do espírito é necessário que a totalidade da sua ação esteja sujeita
àvontade do espírito: Por outro lado, é pela ação do objeto visível sobre a vista, que nós o vemos, como
está claro no Filósofo. Por onde, quem quer que tenha um corpo glorificado tem o poder de ser visto
quando quiser e, quando não quiser, o de não o ser. Ora, Cristo, não só pela condição do corpo glorioso,
mas também por virtude da divindade - que pode tornar milagrosamente invisíveis mesmo os corpos —
teve esse poder. Tal o caso de S. Bartolomeu, a quem foi milagrosamente concedido o poder de se
tornar visível ou não, conforme o quisesse. E diz a Escritura que Cristo se desvaneceu aos olhos dos
discípulos, não por se ter decomposto ou resolvido num ser invisível, mas que, por vontade sua, se lhes
desapareceu aos olhares, ou estando ainda presente. ou por ter se separado deles pelo dom da
agilidade.

RESPOSTA À TERCEIRA. — Como diz Severiano num Sermão pascal, ninguém deve pensar que Cristo,
com a sua ressurreição, mudou a forma do seu corpo. O que se deve entender da disposição dos
membros, pois nada de desordenado e disforme havia no corpo de Cristo, concebido pelo Espírito
Santo, que devesse ser corrigido na ressurreição. Nesta, somente recebeu a glória da claridade. Por isso
no mesmo lugar se acrescenta: Mas a sua figura se mudou, tornando-se de mortal, imortal; de modo
que assim adquiriu uma figura gloriosa, sem perder nada da sua substância real. — Nem contudo
apareceu aos discípulos sob forma gloriosa; mas, como no seu poder estava tornar o seu corpo visível ou
invisível, assim também tinha o poder de manifestar-se aos olhos dos que o contemplavam sob forma
gloriosa, não gloriosa ou ainda mista, ou de qualquer outro modo. Ora, basta uma pequena diferença
para parecermos diferentes do que somos.

## Art. 2 — Se o corpo de Cristo ressurgiu inteiro.
O segundo discute-se assim. — Parece que o corpo de Cristo não ressurgiu inteiro.

1. — Pois, a carne e o sangue pertencem à integridade do corpo humano. Ora, Cristo parece que não os
teve, conforme aquilo do Apóstolo: A carne e o sangue não podem possuir o reino de Deus. Ora, Cristo
ressurgiu na glória do reino de Deus. Logo, parece que não tinha carne nem sangue.

2. Demais. — O sangue é um dos quatro humores. Se pois Cristo teve sangue, pela mesma razão
também teve os outros humores, donde resulta a corrupção aos corpos dos animais. Donde se seguirá,
que o corpo de Cristo era corruptível. O que é inadmissível. Logo, não teve carne nem sangue.

3. Demais. — O corpo de Cristo ressurrecto subiu aos céus. Ora, uma parte do seu sangue é reservado
como relíquia em certas Igrejas. Logo, o corpo de Cristo não ressurgiu na integridade de todas as suas
partes.
Mas, em contrário, o Senhor diz, falando aos discípulos, depois da ressurreição: Um espírito não tem
carne nem ossos como vós vedes que eu tenho.

SOLUÇÃO. — Como dissemos, o corpo de Cristo teve, ressurrecto, a mesma natureza, mas uma glória
diferente. Por onde, tudo o pertencente ànatureza do corpo humano existiu totalmente no corpo de
Cristo ressurrecto. Ora, é manifesto que da natureza do corpo humano fazem parte as carnes, os ossos,
os sangues e atributos semelhantes. Por onde, tudo isso existiu no corpo de Cristo ressurrecto; e
também integralmente, sem nenhuma diminuição do contrário a ressurreição não seria perfeita, se não
se reintegrasse tudo o que se desagregou pela morte. Por isso o Senhor fez aos seus fiéis a seguinte
promessa: Até os mesmos cabelos da vossa cabeça, todos eles estão contados. E noutro lugar: Não se
perderá um cabelo da vossa cabeça. — Quanto a afirmar que o corpo de Cristo não tinha carne nem
ossos nem as demais partes naturais ao corpo humano, isso constitui o erro de Entíquio, bispo da cidade
de Constantinopla. Dizia ele que o nosso corpo, na glória da ressurreição, será impalpável e mais subtil
que o vento e o ar. E que o Senhor, depois de ter confirmado o coração de seus discípulos, fazendo-os
lhe apalpar o corpo, tornou então subtil tudo o que antes nele podia ser tocado. Mas essa doutrina
Gregório a refuta no mesmo lugar, pois o corpo de Cristo não sofreu, depois da ressurreição, nenhuma
mudança, segundo aquilo do Apóstolo: Tendo Cristo ressurgido dos mortos, já não morre. De modo que
o bispo infiel retratou-se na morte, do que disse. Pois, se é inadmissível que Cristo tivesse recebido, na
sua concepção, um corpo de outra natureza, por exemplo, celeste, como Valentiniano afirmava, muito
mais inadmissível é que, na ressurreição, reassumisse um corpo de natureza diferente, pois que o corpo
reassumido na ressurreição, para a vida imortal, foi o mesmo que assumiu, na concepção, para a vida
mortal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Carne e sangue, no lugar citado, não se tomam pela
natureza deste e daquela, mas ou pela culpa da carne e do sangue, como diz Gregório; ou pela
corrupção da carne e do sangue, porque, no dizer de Agostinho, não havia aí corrupção nem
mortalidade da carne e do sangue. Ora, a carne, na sua substância, possui o reino de Deus, conforme o
lugar — Um espírito não tem carne nem ossos como vós vedes que eu tenho, Mas a carne, entendida
como corruptível, não o possui. Por isso imediatamente o Apóstolo acrescentou as palavras: Nem a
corrupção possuirá a incorruptibilidade.

RESPOSTA À SEGUNDA. — Como diz Agostinho, talvez o tratar-se do sangue dará a ocasião a um
esmerilhador mais minucioso de objetar, que se houve sangue no corpo de Cristo ressurrecto, porque
não houve também a pituita, isto é, o flegma; porque não o fel amarelo, isto é, a bílis e o fel negro ou a
melancolia, cujos quatro humores a ciência médica declara constituídos da natureza da carne?
Acrescente-se-lhes o que se quiser, mas evitando acrescentar a corrupção — não vá contaminar-se a
integridade e a pureza da fé. Mas Deus pode deixar algumas de suas propriedades a corpos, de natureza
visíveis e palpáveis e privá-los contudo de outras, conforme quiser; de sorte que guardem a sua forma
exterior sem nenhuma falha ou corrupção, o movimento sem a fadiga, o poder de comer sem a
necessidade. de nutrir-se.

RESPOSTA À TERCEIRA. — Todo o sangue corrido do corpo de Cristo, pertencendo realmente ànatureza
humana, ressurgiu com o seu corpo. E o mesmo devemos dizer de todas as partículas realmente
pertencentes á natureza humana em sua integridade. Quanto ao sangue conservado por certas Igrejas
como relíquias, esse não correu do lado de Cristo; mas é considerado como tendo jorrado
milagrosamente de alguma imagem sua, objeto de qualquer violência.

## Art. 3 — Se o corpo de Cristo ressurgiu glorioso.
O terceiro discute-se assim. — Parece que o corpo de Cristo não ressurgiu glorioso.

1. — Pois, os corpos gloriosos são refulgentes, segundo aquilo do Evangelho: Resplandecerão os justos,
como o sol, no reino de seu Pai. Ora o que torna os corpos resplandecentes é a luz e não a cor. Mas,
tendo o corpo de Cristo sido visto sob a espécie de cor, como antes era visto, parece que não foi
glorioso.

2. Demais. — O corpo glorioso é incorruptível. Ora, parece que o corpo de Cristo não foi incorruptível.
Pois, podia ser apalpado, como ele próprio o disse: Apalpai e vede. E Gregório diz que necessàriamente
o que pode corromper-se pode ser apalpado, e apalpado não pode ser o que não se corrompe. Logo, o
corpo de Cristo não foi glorioso.

3. Demais. — O corpo glorioso não é animal, mas espiritual, como está claro no Apóstolo. Ora, parece
que o corpo de Cristo, depois da ressurreição, era animal, pois comeu e bebeu com os discípulos, como
se lê no Evangelho. Logo, parece que o corpo de Cristo não era glorioso.
Mas, em contrário, o Apóstolo: Reformará o nosso corpo abatido, para o fazer conforme ao seu corpo
glorioso.

SOLUÇÃO. — O corpo de Cristo ressurgiu glorioso e três razões o demonstram. - Primeiro, porque a
ressurreição de Cristo foi o exemplar e a causa da nossa, como se lê no Apóstolo. Ora, os santos,
ressurrectos, terão corpos gloriosos, como diz ainda o Apóstolo: Semeia-se em vileza, ressuscitará em
glória. Ora, sem a causa mais digna que o causado, e o exemplar, que o exemplado, com muito maior
razão o corpo de Cristo ressurgiu glorioso. — Segundo, porque pelas humilhações da Paixão mereceu a
glória da ressurreição. Por isso ele próprio o dizia: Agora presentemente está turbada a minha alma, o
que concernia à Paixão. E no que acrescenta - Pai, glorifica o teu nome, pede a glória da ressurreição. —
Terceiro, porque, como dissemos a alma de Cristo, desde o princípio da sua concepção, era gloriosa pela
fruição perfeita da divindade. E só por exceção se deu, como dissemos, que a glória da alma não
redundasse para o corpo, a fim de cumprir-se, pela sua Paixão, o mistério da nossa redenção. Por onde,
consumado o mistério da Paixão e da morte de Cristo, imediatamente a alma derivou a sua glória para o
corpo reassumido na ressurreição; e assim o seu corpo se lhe tornou glorioso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tudo o que é recebido por outro ser é recebido ao modo
do recipiente. Ora, derivando a glória do corpo, da alma, como diz Agostinho, a refulgência ou a
claridade do corpo glorificado se funda na cor natural ao corpo humano; assim como o vidro
diversamente colorido torna-se resplendente pela iluminação do sol, em dependência da sua cor. Ora,
assim como no poder do homem glorificado está tornar o seu corpo sensível ou não, conforme
dissemos, assim no seu poder está o ser ou não vista a sua resplandecência. Por isso pode ser visto na
sua cor, sem ter nenhuma claridade. E foi desse modo que Cristo apareceu aos discípulos depois da
ressurreição.

RESPOSTA À SEGUNDA. — Um corpo é susceptível de ser tocado não só em razão da sua resistência
como também em razão da sua espessura. Ora, da rarefação e da espessura resultam o peso e a levidão,
a calidez e a frieza e outras qualidades contrárias, que são os princípios da corrupção dos corpos
elementares. Por onde, o corpo susceptível de ser apalpado pelo tato humano é naturalmente
corruptível. E não podemos considerar como capaz de ser tocado um corpo, como o celeste, resistente
ao tato, mas cuja disposição não implica as referidas qualidades, que os objetos próprios do tato
humano. Ora, o corpo de Cristo, depois da ressurreição foi realmente composto de elementos, tendo
em si qualidades tangíveis como o requer a natureza do corpo humano. Por isso era naturalmente
susceptível de ser tocado; e se nada mais tivesse, além da natureza do corpo humano, também teria
sido corruptível. Mas tinha um atributo que o tornava incorruptível; e esse não era, certo, a natureza de
corpo celeste, como alguns dizem, de cuja opinião mais adiante trataremos; mas, a glória redundante da
alma bem-aventurada. Pois, como diz Agostinho, Deus dotou a alma de uma tão poderosa natureza, que
redundasse, da sua pleníssima beatitude, para o corpo, a plenitude da saúde, isto é, o vigor da
incorrupção. Por onde, como diz Gregório se demonstra que o corpo de Cristo, depois da ressurreição,
não mudou de natureza, mas teve uma glória diferente.

RESPOSTA À TERCEIRA. — Como diz Agostinho, o nosso Salvador, depois da ressurreição, revestido de
uma carne espiritual, mas verdadeira, tomou comida e bebida com os discípulos; não que precisasse de
alimentos, mas para manifestar que tinha o poder de fazê-lo. Pois, como diz Beda, de um modo a terra
seca absorve a água e de outro, o raio candente do sol; aquela por indigência, este pela intensidade.
Assim, Cristo comeu, depois da ressurreição, não que precisasse de alimento, mas para, desse modo,
manifestar a natureza do corpo ressurrecto. Mas daqui não se segue que tivesse um corpo de natureza
animal, necessitado de alimentar-se.

## Art. 4 — Se o corpo de Cristo devia ressurgir com cicatrizes.
O quarto discute-se assim. — Parece que o corpo de Cristo não devia ressurgir com cicatrizes.

1. — Pois, diz o Apóstolo, que os mortos ressurgirão incorruptíveis. Ora, tanto as cicatrizes como as
feridas implicam de certo modo corrupção e defeito. Logo, não devia Cristo, autor da ressurreição,
ressurgir com cicatrizes.

2. Demais. — O corpo de Cristo ressurgiu íntegro. Ora, feridas abertas contrariam a integridade do
corpo, pois causam nele descontinuidade. Por onde, parece que não devia o corpo de Cristo conservar
quaisquer aberturas de feridas, embora nele se conservassem certos sinais delas, suficientes para
percebê-las a vista à qual Tomé acreditou, ele a quem foi dito: Tu creste, Tomé, porque me viste.

3. Demais. — Damasceno diz: Depois da ressurreição de Cristo, certas causas lhe atribuímos, como as
cicatrizes em sentido próprio, não porém segundo a natureza, senão só excepcionalmente, para
significar que o mesmo corpo que sofreu foi também o que ressurgiu. Ora, cessada a causa, cessa o
efeito. Por onde, parece que uma vez certificados os discípulos da sua ressurreição, não era já
necessário que conservasse as cicatrizes. Mas não convinha à imutabilidade da sua glória, que assumisse
qualquer causa que perpetuamente nele não existisse. Logo, parece que não devia, ressurgido, assumir
um corpo com cicatrizes. Mas, em contrário, o Senhor diz a Tomé: Mete aqui o teu dedo e vê as minhas
mãos; chega também a tua mão e mete-a no meu lado.

SOLUÇÃO. — Devia a alma de Cristo, na ressurreição, reassumir o seu corpo com as cicatrizes. —
Primeiro, por causa da glória mesma de Cristo. Assim, como diz Beda, conservou as cicatrizes, não pelas
não poder fazer desaparecer, mas a fim de manifestar a todos e perpetuamente o triunfo da sua vitória.
E por isso diz Agostinho, que talvez no reino celeste veremos nos corpos dos mártires as cicatrizes das
feridas, que sofreram pelo nome de Cristo. O que lhes constituirá, não uma deformidade, mas uma
dignidade; e então há de refulgir neles a beleza da virtude existente no corpo, mas sem ser do corpo. —
Segundo, para confirmar o coração dos discípulos na fé da sua ressurreição. — Terceiro, para mostrar
sempre, ao orar ao Pai por nós, que gênero de morte sofreu pelo homem. — Quarto, para relembrar
incessantemente àqueles a quem resgatou com a morte, a misericórdia de que usou para com eles. — E
enfim, para também desse modo mostrar, no juízo, aos condenados, quão justamente o foram. Pois,
como diz Agostinho, Cristo sabia porque queria conservar no seu corpo as cicatrizes. Porque, assim
como as mostrou a Tomé, que não queria crer senão tocando-as e vendo-as, assim também há de
mostrar, mesmo aos seus inimigos, as suas feridas, para que a Verdade, ao confundi-Ias, lhes declare: Eis
o homem a quem crucificaste. Vedes as feridas que me causastes. Reconhecei o lado que trespassastes
— aberto por vós e por causa vossa, sem contudo nele terdes querido entrar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essas cicatrizes que permaneceram no corpo de Cristo,
não implicam nenhuma corrupção nem qualquer defeito, mas um maior cúmulo de glória, como uns
sinais da sua virtude. E nesses lugares mesmo das feridas se manifestará um esplendor especial.

RESPOSTA À SEGUNDA. — Embora essas feridas abertas impliquem uma certa solução de continuidade,
tudo isso é recompensado porém por um maior esplendor da glória, de modo que o corpo longe de
perder da sua integridade, mais perfeito se tornará. Tomé, porém não só viu, mas também tocou as
feridas; porque, como diz Leão Papa, bastava-lhe à sua fé ter insto o que vira; mas foi em nosso proveito
o ter tocado aquele a quem via.

RESPOSTA À TERCEIRA. — Cristo quis que as cicatrizes permanecessem no seu corpo, não só para
certificar a fé dos discípulos, mas ainda por outras razões. Donde se conclui que essas cicatrizes sempre
lhe permaneceram no corpo. Pois, diz Agostinho: Creio que o corpo do Senhor está no céu como existia
quando a ele subiu. E Gregório diz, se alguma causa podia mudar-se no corpo de Cristo, depois da
ressurreição, o Senhor podia voltar a morrer, depois de ressurrecto — contra a afirmação verídica de
Paulo. Mas quem com estultície ousará dizê-lo, senão quem negar a verdadeira ressurreição da carne?
Por onde é claro que as cicatrizes que Cristo mostrava no seu corpo, depois da ressurreição, nunca mais
se lhe deliram dele.