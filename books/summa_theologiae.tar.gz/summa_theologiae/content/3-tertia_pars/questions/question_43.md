# Questão 43: Dos milagres feitos por Cristo em geral
Em seguida devemos tratar dos milagres feitos por Cristo. Primeiro em geral. Segundo, em especial, de
cada gênero de milagres. Terceiro, em particular, da sua transfiguração.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se Cristo devia fazer milagres.
O primeiro discute-se assim. — Parece que Cristo não devia fazer milagres.

1. — Pois, as obras de Cristo deviam concordar com as suas palavras. Ora, ele próprio disse: Esta
geração má e adúltera pede um prodígio; mas não lhe será dado outro prodígio senão o prodígio do
profeta Jonas. Logo, não devia fazer milagres.

2. Demais. — Assim como Cristo, no seu segundo advento, há de vir com grande poder e majestade,
como diz o Evangelho; assim no primeiro se manifestou como fraco, segundo a Escritura: Varão de dores
e experimentado nos trabalhos. Ora, fazer milagres é antes próprio do poder que da fraqueza. Logo, não
foi conveniente que no seu primeiro advento fizesse milagres.

3. Demais. — Cristo veio salvar os homens pela fé, segundo aquilo do Apóstolo: Pondo os olhos no autor
e consumador da fé, Jesus. Ora, os milagres diminuem o mérito da fé, donde o dizer o Senhor: Vós se
não vedes milagres e prodígios não credes. Logo, parece que Cristo não devia fazer milagres.
Mas, em contrário, o Evangelho diz, das pessoas dos adversários de Deus: que fazemos nós? Que este
homem faz muitos milagres.

SOLUÇÃO. — Deus permite ao homem fazer milagres por duas razões. - Primeiro e principalmente para
confirmar a verdade que se ensina. Pois, como as verdades da fé excedem a razão, não podem ser
provadas por meio de razões humanas, mas é preciso que tirem a sua prova do poder divino. E assim,
quando alguém faz obras, que só Deus pode fazer, devemos crer que tais obras têm em Deus a sua
causa; do mesmo modo que quando alguém expede cartas assinadas com o selo do rei, devemos crer
que da vontade do rei procede o que elas contêm - Segundo, para mostrar a presença de Deus no
homem, pela graça do Espírito Santo; de modo que creiamos que Deus habita pela graça em quem faz
as obras de Deus. Donde o dizer o Apóstolo: Aquele que vos dá o Espírito Santo obra milagres no meio
de vós. Ora, devia tornar-se manifesto aos homens, que Deus habitava em Cristo pela graça, não de
adoção, mas de união; e que a sua doutrina sobrenatural procedia de Deus. Por isso foi
convenientíssimo que fizesse milagres. Donde o dizer o Evangelho: Quando não queirais crer em mim,
crede as minhas obras. E noutro lugar: As obras que meu Pai me deu que cumprisse, essas mesmas são
as que dão testemunhos de mim.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dito do Evangelho — Não lhe será dado outro prodígio
senão o prodígio do profeta Jonas — significa, segundo Crisóstomo, que então não receberam o
prodígio que pediram, isto é, do céu; e não, que não lhes deu nenhum prodígio. — Ou porque fazia
prodígios, não por causa daqueles que sabia terem coração de pedra, mas para que purificasse os
outros. Por isso, esses milagres eram feitos, não para eles, mas para os outros.

RESPOSTA À SEGUNDA. — Embora Cristo viesse na fraqueza da carne que se manifesta pelo sofrimento,
veio, contudo com o poder de Deus, que devia manifestar-se pelos milagres.

RESPOSTA À TERCEIRA. — Os milagres diminuem o mérito da fé na medida em que manifestam a
dureza daqueles que não querem crer no que a Escritura divina ensina, senão por meio de milagres. E,
contudo melhor lhes é que, por meio de milagres, se convertem à fé, do que permanecerem totalmente
na infidelidade. Mas, o Apóstolo diz que os milagres foram feitos para os infiéis.

## Art. 2 — Se Cristo fez milagres por poder divino.
O segundo discute-se assim. — Parece que Cristo não fez milagres por poder divino.

1. — Pois, a virtude divina é onipotente. Ora, parece que Cristo não foi onipotente nos seus milagres;
assim, como diz o Evangelho, não podia ali, istoé, na sua pátria, fazer milagre algum. Logo, parece que
não fez milagres por poder divino.

2. Demais. — Não é próprio de Deus orar. Ora, Cristo às vezes orou na ocasião de fazer milagres, como o
demonstra a ressurreição de Lázaro e a multiplicação dos pães. Logo, parece que não fez milagres por
poder divino.

3. Demais. — O que o poder divino faz não o pode o de nenhuma criatura. Ora, o que Cristo fazia
também qualquer criatura podia fazer; por isso os fariseus diziam, que expelia os demônios em virtude
de Belzebu, príncipe dos demônios. Logo, parece que Cristo não fez milagres por poder divino.
Mas, em contrário, diz o Senhor: O Pai, que está em mim, esse é o que faz as obras.

SOLUÇÃO. — Como estabelecemos na Primeira Parte, verdadeiros milagres só o poder divino pode fazê-
las; pois, só Deus pode mudar a ordem da natureza, o que constitui o milagre. Por isso Leão Papa diz,
que tendo Cristo duas naturezas, uma delas — a divina, refulge pelos seus milagres; a outra — a
humana, é a que sucumbe ao sofrimento. E, contudo uma delas age pela comunicação da outra, isto é,
enquanto a natureza humana é instrumento da ação divina, e a ação humana recebe a sua virtude da
natureza divina, como estabelecemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dito do Evangelho — não podia ali jazer milagre algum
— não se refere ao poder absoluto, mas ao que Cristo fazia por conveniência. Assim, não era
conveniente operasse milagres entre incrédulos; por isso o evangelista acrescenta: E se admirava da
incredulidade deles. E neste sentido a Escritura diz: Acaso poderei eu ocultar a Abraão o que estou para
fazer? E ainda: Não poderei fazer nada enquanto tu lá não tiveres entrado.

RESPOSTA À SEGUNDA. — Comentando aquele lugar do Evangelho — Tomando os cinco pães e os dois
peixes, com os olhos no céu abençoou e partiu os pães — diz Crisóstomo: Era necessário crer que Cristo
vinha do Pai, de quem era o igual. Por isso, a fim de manifestar uma e outra causa, ora faz milagres pelo
seu próprio poder, outras vezes depois de ter orado. Assim, quando se trata de milagres menores, como
a da multiplicação dos pães, levanta os olhos para o céu; mas, em se tratando dos milagres maiores,
como o de perdoar os pecados ou ressuscitar os mortos, que só Deus pode fazer, então age por poder
próprio. — Quanto ao dito do Evangelho, que na ressurreição de Lázaro, levantou os olhos ao céu, não
para implorar um socorro celeste, mas para dar exemplo, assim procedeu. Por isso diz: Falei assim por
atender a este povo, que está à roda de mim, para que eles creiam que tu me enviaste.

RESPOSTA À TERCEIRA. — Cristo expelia os demônios por uma virtude diferente da com que os
demônios o fazem. Pois, pelo poder dos demônios superiores os demônios são expulsos do corpo
humano, continuando porém a ter domínio sobre a alma; porque o diabo não age contra o seu próprio
reino. Ao passo que Cristo expulsava os demônios não só do corpo, mas sobretudo da alma. Por isso o
Senhor reprovou a blasfêmia dos fariseus que diziam expulsar ele os demônios com o poder destes, E
reprovou, primeiro, porque Satanás não entra em divisão consigo mesmo; segundo, para exemplo dos
outros, que expulsavam os demônios pelo Espírito de Deus; terceiro, porque não poderia expulsar o
demônio se não o tivesse vencido pelo seu poder divino; quarto, porque nada de comum tinha com
Satanás, nem pelas suas obras nem pelo efeito delas; pois, Satanás procurava dispersar aqueles que
Cristo unia.

## Art. 3 — Se Cristo começou a fazer milagres por ocasião das bodas de Cana, mudando água em vinho.
O terceiro discute-se assim. — Parece que Cristo não começou a fazer milagres por ocasião das bodas
de Caná, mudando água em vinho.

1. — Pois, um autor diz que Cristo, na sua puerícia, fez muitos milagres. Ora, o milagre da conversão da
água em vinho ele o fez nas bodas de Caná, no trigésimo ou no trigésimo primeiro ano da sua idade.
Logo, parece que não foi então que começou a fazer milagres.

2. Demais. — Cristo fazia milagres pelo seu poder divino. Ora, esse poder divino ele o teve desde o
princípio da sua concepção: pois, desde então era Deus e homem. Logo, parece que desde o princípio
fez milagres.

3. Demais. — Cristo, depois do batismo e da tentação começou a congregar os discípulos, com se lê no
Evangelho. Ora, foram sobretudo os seus milagres que o levaram a angariar discípulos; assim, como
refere o Evangelho, chamou a Pedro, estupefato pelo milagre que fizera, na captura dos peixes. Logo,
parece que antes do milagre das bodas de Caná, fez outros.
Mas, em contrário, o Evangelho: Por este milagre deu Jesus princípio aos seus, em Caná de Galiléia.

SOLUÇÃO. — Cristo fez milagres para confirmar a sua doutrina e para manifestar o seu poder divino. —
Por isso, quanto à confirmação, não devia fazer milagres antes de começar a ensinar. E não devia
começar a ensinar antes de atingir à idade perfeita, como dissemos, quando tratamos do batismo. —
Quanto àmanifestação do seu poder, devia mostrar a sua divindade pelos seus milagres; de modo que
acreditassem na sua humanidade verdadeira. Por isso, como diz Crisóstomo, fez bem não começando
fazer milagres desde a sua primeira idade; do contrário, pensariam que a sua Encarnação era fantástica,
e antes do tempo oportuno tê-lo-iam crucificado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Crisóstomo, pelas palavras de João Batista,
quando diz - Eu vim batizar em água, para ele ser conhecido em Israel — é manifesto que esses
milagres, que certos consideram como feitos por Cristo na sua puerícia, são mentiras e ficções. Pois, se
na sua primeira idade Cristo tivesse feito milagres, nem João os teria ignorado nem a restante multidão
teria necessidade do mestre para manifestá-lo.

RESPOSTA À SEGUNDA. — Cristo obrava pelo seu poder divino quando era necessário para a salvação
humana, por causa da qual se encarnava. Por isso, fez milagres com o seu poder divino, de modo que
não prejudicasse à verdade da sua encarnação.

RESPOSTA À TERCEIRA. — Os discípulos merecem louvor por terem seguido a Cristo, apesar de não o
verem fazer nenhum milagre, como diz Gregório numa homilia. E, como diz Crisóstomo, era necessário
fazer milagres, sobretudo quando os discípulos já estavam reunidos e devotados a Cristo e atentos às
suas obras. Por isso, o evangelista acrescenta: E acreditaram nele os seus discípulos. Não que então
começassem a crer; mas, que então acreditaram mais diligente e perfeitamente. - Ou que chama
discípulos aos que haveriam de sê-lo, como expõe Agostinho.

## Art. 4 — Se os milagres que Cristo fez foram suficientes a lhe manifestar a divindade.
O quarto discute-se assim. — Parece que os milagres que Cristo fez não eram suficientes a lhe
manifestar a divindade.

1. — Pois, ser Deus e homem é propriedade de Cristo. Ora, os milagres que fez Cristo também outros o
fizeram. Logo, parece que não eram suficientes a manifestar-lhe a divindade.

2. Demais. — Nenhum poder é maior que o da divindade. Ora, houve quem fizesse maiores milagres que
Cristo; assim, diz o Evangelho: Aquele que crê em mim esse fará também as obras que eu faça e fará
outras ainda maiores. Logo, parece que os milagres feitos por Cristo não eram suficientes a manifestar-
lhe a divindade.

3. Demais. — O universal não se manifesta suficientemente pelo particular. Ora, cada um dos milagres
de Cristo foi uma obra particular. Logo, por nenhum deles podia manifestar-se suficientemente a
divindade de Cristo, que tem um poder universal sobre todas as coisas.
Mas, em contrário, o Senhor diz: As obras que meu Pai me deu que cumprisse, as mesmas obras que eu
faço dão por mim testemunho.

SOLUÇÃO. —0s milagres que Cristo fez eram suficientes para manifestar-lhe a divindade, num tríplice
ponto de vista. — Primeiro, pela mesma espécie dessas obras, que transcendiam todo poder de
qualquer virtude criada; e portanto não podiam ser feitas senão por virtude divina. Por isso, o cego que
recobrou a vista dizia: Desde que há mundo, nunca se ouviu que alguém abrisse os olhos a um cego de
nascença. Se este não fosse Deus não podia ele obrar coisa alguma. — Segundo, pelo modo de fazer os
milagres; pois, ele os fazia quase por poder próprio e não depois de ter orado, como os outros. Donde o
dizer o Evangelho: Dele saía uma virtude que os curava a todos. O que demonstra, como nota Cirílo, que
não dependia de nenhum poder alheio; mas, sendo naturalmente Deus, agia por virtude própria sobre
os enfermos. E por isso também jazia inumeráveis milagres. Por isso, àquilo do Evangelho — Com sua
palavra expelia os espíritos e curava todos os enfermos — diz Crisóstomo: Notai como os evangelistas
reterem uma multidão de pessoas curadas, sem nomear nenhuma em particular, indicando apenas com
uma palavra, a multidão inumerável de milagres. E assim mostrava uma virtude igual a de Deus Padre,
conforme aquilo do Evangelho: Tudo o que fizer o Pai, o faz também semelhantemente o Filho. E ainda:
Assim como o Pai. ressuscita os mortos e lhes dá vida, assim também dá o Filho vida aqueles que quer.
— Terceiro, pela doutrina mesma em virtude da qual se afirmava Deus, a qual se não fosse verdadeira
não fora confirmada por milagres feitos pelo seu poder divino. Por isso se diz no Evangelho: Que nova
doutrina é esta? Porque ele põe preceito com império até aos espíritos imundos e obedecem-lhe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Era essa uma objeção dos gentios. Donde o dizer
Agostinho: Cristo, afirmam, não fez milagres que fossem sinais suficientes da sua tão grande majestade.
Pois, aquela purificação figurada, pela qual expulsava os demônios, a cura de doentes, a vida restituída
aos mortos e outras obras tais são pequenas para Deus. Ao que Agostinho responde assim: Também nós
confessamos que os profetas fizeram coisas semelhantes. Mas Moisés e os outros profetas
prenunciaram o Senhor Jesus e lhe deram grande glória. E essas mesmas obras também Cristo quis
fazer, pois seria absurdo que não as fizesse ele depois de havê-las feito por meio dos profetas. Certas
coisas porém fez, que só ele podia fazer: nascer de uma Virgem, ressurgir dos mortos e subir ao céu. E
quem pensar que isso é pouco para Deus, ignoro o que mais espera. Por ventura, depois de assumida a
humanidade, devia fazer outro mundo para acreditarmos que foi ele quem fez o mundo? Mas não podia
ser feito um mundo nem maior nem igual ao das obras referidas; e então, se fizesse algo menor que
elas, também isso seria tido em pouca conta.
Quanto ao que outros fizeram, Cristo o fez mais excelentemente. Por isso, aquilo do Evangelho — Se eu
não tivesse feito entre elestais obras quais não fezoutro algum, etc., diz Agostinho: Nenhuma obra de
Cristo é maior que a ressurreição de um morto, da qual sabemos que também os profetas a fizeram.
Mas Cristo operou milagres que ninguém mais obrou. Responder-nos-ão, porém, que outros fizeram o
que nem ele nem ninguém jamais fez. Contudo, não há nenhuma prova que algum dos antigos fizesse o
que ele fez curar tão numerosos vícios, tantas doenças perigosas e tantas vexações dos mortais, com tão
grande poder. Pois, não podendo dar o nome de cada um dos que curou com a sua palavra, a medida
que se lhe apresentavam, Marcos diz: E aonde quer que ele entrava, fosse nas aldeias, ou nos casais, ou
nas cidades, punham os enfermos no meio das praças e pediam-lhe que os deixasse tocar ao menos a
orla do seu vestido; e todos os que o tocavam ficavam sãos. Ora, essas obras ninguém mais as fez neles
senão Cristo. E nesse sentido devemos entender a expressão do Evangelho, que é — neles — e não
entre eles — ou — na presença deles; mas exatamente — neles — porque os curou. E quem quer que
tivesse feito neles essas curas, não as fez tais quais; pois, quem quer que as tivesse feito algumas delas,
tê-Ias-ia feito por autoria de Cristo; ao passo que Cristo as realizou por si mesmo e não por autoria de
outros

RESPOSTA À SEGUNDA. — Agostinho, interpretando essas palavras de João, indaga quais fossem essas
obras maiores, que haviam de fazer os crentes em Cristo. Seriam porventura as de curar os doentes a
simples sombra delesao passarem? Pois, maior obra é curá-las com a sombra do que Cristo com a
fímbria da sua túnica. Contudo, quando assim falava, queria fazer ver os efeitos e as obras da sua
palavra. Pois, quando dizia — O Pai que está em mim esse é o que faz as obras — a que obras se referia
senão às palavras que proferia? E o fruto dessas mesmas palavras era a fé dos discípulos. Contudo pela
evangelização dos discípulos, não foram tão poucos esses que nele creram, pois também os gentios
vieram a ser crentes. Assim, não se partiu triste da presença a ele aquele rico que pedia conselhos de
vida eterna? E todavia o conselho que ele ouviu e não praticou, muitos o praticaram quando Cristo o
pregava por meio dos discípulos. Eis porque as obras que realizou, pregadas pelos que nele criam, eram
maiores que as que ensinou aos seus ouvintes. Mas ainda mais nos move o fato de ter operado essas
obras maiores por meio dos Apóstolos. Assim, referindo-se a eles não disse somente: Quem crer em
mim. Mas, ouvi o que disse: Quem crer em mim, esse fará também as obras que eu faço. Primeiro as
farei eu — diz — depois as fará os que crerem em mim, porque eu o farei fazê-las. E essas obras em que
consistem, senão em fazer do ímpio um justo? O que Cristo opera em nós mas não sem nós. E isso eu
até mesmo direi que é mais do que criar o céu e a terra. Pois, o céu e a terra passarão; ao passo que a
salvação e a justificação dos predestinados permanecerá. — Mas no céu os anjos são as obras de Deus.
Porventura também fará maiores obras que essa quem coopera com Cristo na sua justificação própria?
Julgue quem puder, se é mais criar os justos, que justificar os ímpios. Por certo, se ambas essas obras
supõem o mesmo poder, esta última necessita de maior misericórdia. Mas nenhuma necessidade nos
obriga a compreender todas as obras de Cristo, implicadas no seu dito - Fará obras maiores que estas.
Pois, talvez dissesse isso das obras que nesse momento fazia; porque então procurava infundir a fé. E
por certo, é menos pregar verbalmente a justiça, o que fez por nosso amor; do que justificar os ímpios, o
que realiza em nós para também nós o fazermos.

RESPOSTA À TERCEIRA. — Quando uma obra determinada é uma obra própria de um certo agente,
então dessa obra determinada se deduz a virtude total do agente. Assim, raciocinar, sendo uma
atividade própria do homem, mostra que é homem quem raciocina qualquer propósito deliberado que
tome. E semelhantemente, como só Deus pode fazer milagres por virtude própria, fica suficientemente
provado que Cristo é Deus por qualquer dos milagres que fez por virtude própria.