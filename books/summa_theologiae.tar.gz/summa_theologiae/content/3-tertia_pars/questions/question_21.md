# Questão 21: Da oração de Cristo
Em seguida devemos tratar da oração de Cristo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se convinha a Cristo orar.
O primeiro discute-se assim. — Parece que a Cristo não convinha o orar.

1. — Pois, como diz Damasceno, orar é pedir o que convém, a Deus. Ora, podendo Cristo fazer tudo, não
lhe convém pedir nada a ninguém. Logo, parece que não convinha a Cristo o orar.

2. Demais. — Não devemos pedir, em nossas orações, o que sabemos haver certamente de se dar;
assim, não oramos para o sol nascer amanhã. Também não é conveniente pedir em nossas orações o
que sabemos que de nenhum modo se dará. Ora, Cristo sabia, em tudo, o que haveria de suceder. Logo,
não lhe cabia pedir nada, pela oração.

3. Demais. — Damasceno diz que a oração é ascensão do nosso intelecto para Deus. Ora, o intelecto de
Cristo não precisava ascender para Deus, com quem estava sempre unido, não só pela união hipostática
mas também pela fruição da beatitude. Logo, a Cristo. não convinha orar.
Mas, em contrario, o Evangelho: Aconteceu naqueles dias que saiu ao monte a orar e passou toda a
noite em oração a Deus.

SOLUÇÃO. — Como dissemos na Segunda Parte, a oração é um como expandir-se da nossa vontade para
com Deus, para que a satisfaça. Se, pois, Cristo tivesse uma só vontade – a divina, de nenhum modo lhe
cabia orar; pois, a vontade divina faz por si mesma tudo quanto quer, segundo a Escritura: Quantas
coisas quis todas fez o Senhor. Mas, tendo Cristo uma vontade divina e outra, humana, e não sendo a
sua vontade humana capaz, por si mesma, de fazer o que quer, senão por virtude divina, daí vem que
era natural a Cristo orar, enquanto homem e dotado de uma vontade humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo, como Deus, podia fazer tudo o que queria; mas
não como homem, pois, como tal, não tinha a onipotência, como dissemos. Contudo quis ele, mesmo
como homem e Deus, fazer oração ao Pai, não porque não fosse onipotente, mas para nossa instrução.
— Primeiro, para mostrar que vinha do Pai, sendo por isso que disse: Falei assim, isto e, orei por atender
a este povo que está à roda de mim, para que eles creiam que tu me enviaste. Donde o dizer Hilário:
Não precisava de orar; orou por nós, para que o Filho não fosse ignorado. — Segundo, para nos dar o
exemplo da oração. E por isso diz Ambrósio : Não escuteis com ouvidos enganosos, pensando que o
Filho de Deus orava, por fraqueza, pedindo se realizar o que não podia ele realizar. Mas, como fonte de
todo poder, como mestre da obediência, ensina-nos, com o seu exemplo, os preceitos da virtude. Daí o
dizer Agostinho: O Senhor podia, sob a forma de servo, e se o fosse necessário, orar em silêncio; mas
quis se apresentar ao Pai como pecador, para lembrar que era o nosso Mestre.

RESPOSTA À SEGUNDA. — Entre as várias coisas futuras que Cristo sabia, sabia que certas se realizariam
mediante suas orações. E essas não era inconveniente as pedisse a Deus.

RESPOSTA À TERCEIRA. — A ascensão não é mais que o movimento para o que está em cima. Ora, o
movimento, conforme Aristóteles, é susceptível de duplo sentido. - Num sentido próprio implica a
passagem a potencia para o ato, enquanto é o ato do que é imperfeito. E assim, ascender é próprio do
que é potencial, e não atual, em relação ao que está em cima. E neste sentido Damasceno diz: O
intelecto humano de Cristo não precisava de ascender para Deus, pois, estava sempre unido com Deus,
tanto pela sua existência pessoal, como pela contemplação beatífica. — Noutro sentido, o movimento é
o ato do perfeito, isto é, do que existe em ato; e assim chamamos movimento ao inteligir e ao sentir. E
neste sentido, o intelecto de Cristo sempre ascende para Deus, pois sempre o contemplava como o que
tinha uma existência superior.

## Art. 2 — Se a Cristo, considerado na sua sensibilidade, convinha orar.
O segundo discute-se assim. — Parece que a Cristo, considerado na sua sensibilidade, convinha orar.

1. — Pois, diz a Escritura, da pessoa de Cristo: O meu coração e a minha carne se regozijaram no Deus
vivo. Ora, a sensibilidade significa um desejo da carne. Logo, a sensibilidade de Cristo podia ascender
para o Deus vivo, regozijando-se e, pela mesma razão, orando.

2. Demais. — Ora quem deseja o que pede. Mas, Cristo pediu o que desejava a sua sensibilidade,
quando disse – Passe de mim este cálice, como se lê no Evangelho. Logo Cristo, na sua sensibilidade,
orou.

3. Demais. — É mais unir-se a Deus em pessoa, que ascender a ele pela oração. Ora, a sensibilidade foi
assumida por Deus na unidade de pessoa, assim como qualquer outra parte da natureza humana. Logo,
com maior razão, podia ascender a Deus pela oração.
Mas, em contrário, o Apóstolo diz que o Filho de Deus, pela natureza que assumiu, fez-se semelhante
aos homens. Ora, os outros homens não oram pela sensibilidade. Logo, também Cristo não orou pela
sensibilidade.

SOLUÇÃO. — Orar, mediante a sensibilidade, podemos entendê-la de dois modos.
Primeiro, de modo que a oração mesma seja um ato sensível. E deste modo, Cristo não orou
sensivelmente; pois. a sua sensibilidade foi da mesma natureza e da mesma espécie que a nossa. Ora,
em nós a sensibilidade não pode orar, por duas razões. — Primeiro, porque o movimento da
sensibilidade não pode transcender o sensível, e portanto, não pode subir até Deus, como o exige a
oração. — Segundo, porque a oração implica uma certa ordem. consistente em desejarmos alguma
coisa, como devendo ser realizada por Deus; o que é próprio só da razão. Por onde, a oração é um ato
de razão.
Noutro sentido, dizemos que alguém ora mediante a sensibilidade, porque quando faz a sua oração
propõe a Deus o objeto do desejo da sua sensibilidade. E neste sentido Cristo orou mediante a sua
sensibilidade: enquanto que a sua oração exprimia o afeto da sensibilidade, como se fosse advogado
desta. E para assim nos dar uma tríplice instrução. Primeiro, para mostrar que assumiu verdadeiramente
a natureza humana, com todos os seus afetos naturais. Segundo, para mostrar que é lícito ao homem,
pelo seu afeto natural, querer o que Deus não quer. Terceiro, para mostrar que o homem deve sujeitar
o seu afeto próprio à vontade divina. Donde o dizer Agostinho: Cristo, enquanto homem, mostra uma
certa vontade particularmente humana, quando diz — Passe de mim este cálice; pois, essa era urna
vontade humana, a querer uma causa propriamente particular. Mas como quer, com coração recto, ser
homem e ser dirigido para Deus, acrescenta — Contudo, não se faça a minha vontade, senão a tua;
como se dissesse — considera-te em mim pois, posso querer algo como próprio, embora Deus queira de
outro modo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A carne se regozija em Deus vivo, não pelo ato pelo qual
ascende para o Deus vivo, mas pelo redundar nela o coração; isto é, enquanto o apetite sensitivo segue
o movimento racional.

RESPOSTA À SEGUNDA. — Embora a sensibilidade quisesse o que a razão pedia, pedi-lo, contudo, nas
suas orações, não era próprio da sensibilidade, mas, da razão.

RESPOSTA À TERCEIRA. — A união, na pessoa, se funda no ser pessoal, implicado em qualquer parte da
natureza humana. Mas, a ascensão da oração é mediante um ato só próprio da razão, como se disse.
Logo, a comparação não colhe.

## Art. 3 — Se convinha a Cristo orar por si.
O terceiro discute-se assim. — Parece que não era conveniente a Cristo orar por si.

1. — Pois, diz Hilário: Embora de nada lhe servisse proferir palavras, contudo falou, para proveito da
nossa fé. Assim, pois, parece que Cristo não orou por si, mas por nós.

2. Demais. — Ninguém ora senão pelo que quer; pois, como já dissemos, a oração é uma expansão da
nossa vontade afim de ser satisfeita por Deus. Ora, Cristo queria sofrer o que sofria; e assim diz
Agostinho: O homem, muitas vezes, encoleriza-se contra a sua vontade; embora não queira, se
entristece; dorme embora não queira; e contra a vontade tem fome e sede. Ora, Cristo por tudo isso
passou porque quis. Logo, não lhe competia orar por si.

3. Demais. — Cipriano diz: O Mestre da paz e da unidade não quis orar secreta e privadamente, como
quem, quando ora, não pede só por si. Ore, Cristo fez o que ensinou, como o diz a Escritura: Jesus
começou a fazer e a ensinar. Logo, Cristo não orou nunca só por si.
Mas, em contrário, o próprio Senhor, ao orar, dizia: Glorifica ao teu Filho.

SOLUÇÃO. — Cristo orou por si, de dois modos. Primeiro, exprimindo o afeto da sua sensibilidade, como
se disse; ou ainda o da simples vontade, considerada como natureza, como quando pediu que passasse
de si o cálice da paixão. De outro modo, exprimindo o afeto da vontade deliberada, considerada como
razão, como quando pediu a glória da ressurreição. E isto racionalmente. Pois, como dissemos, Cristo
quis recorrer ao Pai, na sua oração, para nos dar o exemplo de orar e para nos mostrar, que o seu Pai é o
autor de que eternamente procede, segundo a sua natureza divina e que dele tem, segundo a sua
natureza humana, todo bem que tem. Assim, pois, como pela sua natureza humana já tinha recebido do
Pai certos bens, assim também dele esperava certos outros, que ainda não tinha, mas que devia
receber. Por onde, assim como pelos bens já recebidos, na sua natureza humana, dava graças ao Pai,
reconhecendo-lhe a autoridade deles conforme o lemos nos Evangelhos, assim também para que
reconhecesse o Pai como autor, pedia-lhe nas suas orações o que lhe faltava à natureza humana, por
exemplo, a glória do corpo e outros bens semelhantes. E nisto também nos deixou o exemplo, para que
demos graças pelos bens que recebemos e peçamos também os que ainda não temos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Hilário se refere à oração vocal, que não precisava, por si
mesmo, mas só por causa de nós; por isso diz sinaladamente, que de nada lhe servia proferir palavras.
Se, pois, o Senhor ouviu o desejo dos pobres, como diz a Escritura, com muito maior razão só a vontade
de Cristo tem o poder da oração, perante o Pai. E por isso ele mesmo dizia: Eu bem sabia que tu sempre
me ouves; mas falei assim por atender a este povo que está à roda de mim, para que eles creiam que tu
me enviaste.

RESPOSTA À SEGUNDA. — Cristo por certo queria sofrer o que sofria, e no tempo em que o sofria;
queria contudo, depois da paixão, ser glorificado no seu corpo, glória que ainda não tinha. E essa ele a
esperava do Pai como autor dela. Donde, e convenientemente, o pedir lho.

RESPOSTA À TERCEIRA. — A glória mesma que Cristo pedia nas suas orações, era pertinente à salvação
dos outros, segundo aquilo do Apóstolo: Ressuscitou para nossa justificação. E por isso, as orações que
fazia, por si, de certo modo também redundavam para os outros. Assim como quando pedimos um bem
a Deus para o empregarmos em benefício alheio, oramos não só por nós mesmos mas também pelos
outros.

## Art. 4 — Se a oração de Cristo sempre foi ouvida.
O quarto discute-se assim: — Parece que a o oração de Cristo nem sempre foi ouvida.

1. — Pois, pediu que passasse de si o cálice da paixão, e contudo dele não passou. Logo, parece que nem
toda oração sua foi ouvida.

2. Demais. — Cristo pediu fosse perdoado o pecado dos que o crucificaram, como se lê no Evangelho.
Contudo esse pecado não foi perdoado a todos, pois os Judeus foram punidos por ele. Logo parece que
nem todas as suas orações foram ouvidas.

3. Demais. — O Senhor orou por aqueles que haviam de crer nele, por meio da palavra dos Apóstolos,
para que todos fossem. nele um e chegassem à união com ele. Ora, nem todos chegam a tal. Logo, nem
todas as suas orações foram ouvidas.

4. Demais. — A Escritura diz, da Pessoa de Cristo: Clamarei durante o dia e tu não me ouvirás. Logo, nem
todas as suas orações foram ouvidas.
Mas, em contrário, diz o Apóstolo: Oferecendo com um grande brado e com lágrimas, foi atendido pela
sua reverência.

SOLUÇÃO. — Como dissemos, a oração é de certo modo interpretativa da vontade humana. Pois,
quando oramos, a nossa oração é ouvida, se a nossa vontade é satisfeita. Ora, em sentido absoluto, a
vontade do homem é a vontade racional; pois, queremos, absolutamente falando, o que queremos com
razão deliberada. Mas, o que queremos por um movimento da sensualidade, ou ainda por um
movimento de simples vontade, considerada como natureza, não o queremos absolutamente falando,
mas só relativamente, isto é, se não se opuser nenhum obstáculo proveniente da deliberação da razão.
Por isso essa vontade se chama antes veleidade que vontade absoluta; isto é, consiste em querermos
uma determinada coisa, se nenhum obstáculo se nos opuser. Ora, pela vontade racional, Cristo não
queria senão o que sabia estar de acordo com a vontade de Deus. Por isso, toda vontade absoluta de
Cristo, mesmo humana, foi cumprida, porque era conforme a Deus; e por consequência todas as suas
orações foram ouvidas. Pois, também as orações dos outros são exalçadas, quando as suas vontades
estão conformes com Deus, segundo àquilo do Apóstolo: Aquele que esquadrinha os corações sabe, isto
é, aprova, o que deseja o Espírito, isto é, que faz os santos desejarem, porque ele só pede pelos santos
segundo Deus, isto é, de conformidade com a vontade divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pedido de Cristo de se lhe passar o cálice os santos e
expõem diversamente. - Assim, Hilário diz: Quando rogava que de si passasse aquele cálice, não pedia
que fosse livre dele, mas que recaísse sobre outros o que de si passasse. E desse modo orava pelos que
depois dele haveriam de sofrer, sendo o sentido: Assim como eu bebo este cálice da paixão, assim
também o bebam com esperança confiante, sem sentir dor e sem medo da morte. - Ou, segundo
Jerônimo: Diz sinaladamente – este cálice, isto é, do povo judeu, que não tem nenhuma escusa de
ignorância, se me matar, porque tem as leis e os profetas que todos os dias vaticinam a meu respeito. —
Ou segundo Dionísio Alexandrino: Quando disse — Passe de mim este cálice — não quis significar —
Não me seja oferecido — pois, sem lho ter sido oferecido, dele não podia passar. Mas significava que
assim como o pretérito nem é intacto nem permanente, assim o Salvador pede seja afastado a tentação
que de leve ia penetrando. — Ambrósio, porém, Orígenes e Crisóstomo, dizem que pediu como homem,
que por vontade natural foge a morte. — Se, pois, entendermos que pedia, com essas palavras, que os
outros mártires lhe viessem a ser os imitadores da paixão, segundo Hilário; ou se pediu que o temor de
beber o cálice não o perturbasse; ou que a morte não o detivesse, de qualquer modo cumpriu-se o que
ele pediu. — Se porém se entende que pediu para não beber o cálice da morte e da paixão; ou que não
o bebesse, dado pelos Judeus, por certo não se cumpriu o que pediu, porque a razão, que propôs a
petição, não queria que tal se cumprisse; mas, para nossa instrução, quis nos mostrar a sua vontade
natural e o movimento da sensibilidade, que, como homem. tinha.

RESPOSTA À SEGUNDA. — O Senhor não orou por todos os que o crucificaram, nem também por todos
os que haviam de acreditar nele; mas só pelos predestinados para que, por ele, conseguissem a vida
eterna.
Donde se deduz também a RESPOSTA À TERCEIRA OBJEÇÃO.

RESPOSTA À QUARTA. — A expressão — Clamarei e tu não me ouvirás — devemos entendê-la quanto
ao efeito da sensibilidade, a que repugnava a morte. Cristo foi porém ouvido quanto ao afeto da razão,
como se disse.