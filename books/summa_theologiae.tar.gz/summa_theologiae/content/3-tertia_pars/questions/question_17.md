# Questão 17: Do que pertence à unidade de Cristo quanto ao seu ser
mesmo
Em seguida devemos tratar do pertinente à unidade de Cristo em geral. Pois, o pertinente à unidade ou
à pluralidade, em especial, devemos determiná-lo no lugar oportuno; assim, como já determinamos que
em Cristo não há uma só ciência, assim, mais adiante será determinado que em Cristo não há uma só
natividade.
Por onde, devemos considerar, primeiro, a unidade de Cristo, quanto ao seu ser mesmo. Segundo,
quanto ao querer. Terceiro, quanto ao obrar.
Na primeira questão discutem-se dois artigos:

## Art. 1 — Se em Cristo há unidade ou dualidade.
O primeiro discute-se assim. — Parece que em Cristo não há unidade, mas dualidade.
1 — Pois, diz Agostinho: A forma de Deus assumiu a forma de servo; ambos Deus, por causa do Deus
assumente; ambos homem, por causa do homem assumido. Ora, ambas essas afirmações não se podem
fazer senão por serem dois. Logo, em Cristo há dualidade.

2. Demais. — Onde quer que haja uma coisa e outra coisa, aí há duas coisas. Ora, Cristo é uma coisa e
outra coisa, conforme o diz Agostinho: Sendo a forma de Deus, tomou a forma de servo, essas duas
coisas reduzidas à unidade; mas é uma coisa por causa do Verbo e outra, por causa do homem. Logo,
em Cristo há duas coisas.

3. Demais. — Cristo não é só homem, porque se fosse um puro homem não seria Deus. Logo, é ainda
algo mais, além de homem. E assim há em Cristo uma coisa e outra coisa. Logo, em Cristo há dualidade.

4. Demais. — Cristo é algo, que é o Pai, e algo, que não é o Pai. Logo, Cristo é uma coisa e outra coisa.
Logo, em Cristo há dualidade.

5. Demais. — Assim como no mistério da Trindade há três pessoas numa só natureza, assim no mistério
da Encarnação há duas naturezas numa só pessoa. Ora, por causa da unidade da natureza, não obstante
a distinção da pessoa, o Pai e o Filho são um só, segundo aquilo do Evangelho: Eu e o pai somos uma
mesma coisa. Logo, não obstante a unidade de pessoa, por causa da dualidade das naturezas, em Cristo
há dualidade,

6. Demais. — O Filósofo diz, que unidade e dualidade são predicações denominativas. Ora, Cristo tem
dualidade de naturezas. Logo, em Cristo há dualidade.

7. Demais. — Assim como a forma acidental é causa da alteridade, assim a forma substancial, da
aliedade, como diz Porfírio. Ora, em Cristo há duas naturezas substanciais — a humana e a divina. Logo,
Cristo é uma coisa e outra coisa e portanto há nele dualidade.
Mas, em contrário, Boécio diz: Tudo o que é, enquanto é, é um. Ora, nós confessamos ser Cristo uno.
Logo, é Cristo uno.

SOLUÇÃO. — A natureza, em si mesma considerada, em significação abstrata, não pode ser
verdadeiramente predicada do suposto ou pessoa, a não ser de Deus em quem não difere a existência
(quod est) e a essência (quo est), como demonstramos na Primeira Parte. Mas, havendo em Cristo duas
naturezas, a divina e a humana, uma delas, a divina, pode ser predicada de Deus em abstrato e em
concreto. Assim, dizemos que o Filho de Deus, suposto em o nome de Cristo, é a natureza divina e é
Deus. A natureza humana, porém, não pode ser, em si mesma, predicada de Cristo, em abstrato, mas só
em concreto, isto é, enquanto significada no suposto. Pois, não podemos verdadeiramente dizer que
Cristo é a natureza humana, por não ser próprio da natureza humana predicar-se do seu suposto. Mas
dizemos que Cristo é homem, assim como — Cristo é Deus. Ora, Deus significa quem tem a divindade e
homem, quem tem a humanidade. Mas, uma coisa é ter a humanidade, expressa pela palavra homem; e
outra, o tê-la, significada pelos vocábulos Jesus ou Pedro. Pois, a palavra homem significa ter a
humanidade indistintamente, assim como o nome de Deus implica em ter indistintamente a divindade.
Ao passo que o nome de Pedro ou o de Jesus implica em ter a humanidade distintamente, isto é, com
certas propriedades individuais; assim como o nome de Filho de Deus importa em ter a divindade com
uma determinada propriedade pessoal.
Ora, a dualidade numérica existe em Cristo em relação às naturezas mesmas. Por onde, se ambas as
naturezas fossem predicadas de Cristo em abstrato, resultaria a existência de dois Cristos. Mas, como as
duas naturezas não se predicam de Cristo, senão enquanto significa das no suposto, é forçoso dizer- se,
em razão do suposto, que em Cristo há unidade ou dualidade. — Ora, certos atribuíram a Cristo dois
supostos, mas uma só peso soa, a qual, na opinião deles, desempenha o papel de suposto completo,
perfeitamente completo. Por onde, os que introduziram em Cristo dois supostos atribuíam- lhe a
dualidade, em sentido neutro; mas como lhe atribuíam uma só pessoa, admitiam nele a unidade em
sentido masculino. Porque o gênero neutro designa uma realidade informe e imperfeita; ao passo que o
gênero masculino designa um ser formado e perfeito. - Os Nestorianos, por seu lado, atribuindo a Cristo
duas pessoas, diziam que Cristo encerra uma dualidade, não só em sentido neutro, mas ainda
masculino. — Nós, porém, que admitimos em Cristo uma só pessoa e um suposto, como do sobredito se
colige, temos também que admitir a unidade de Cristo, não só em sentido masculino, mas ainda em
sentido neutro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nas palavras citadas de Agostinho a expressão ambos
não deve ser entendida como aplicada ao predicado e quase significando que Cristo é ambos, mas,
como aplicada ao sujeito. E então o vocábulo ambos é tomado, não quase significando os dois supostos,
mas sim, os dois nomes expressivos das duas naturezas em concreto. E também podemos dizer que
ambos, isto é, Deus e homem, são Deus, por causa do Deus assumente; e ambos, isto é, Deus e homem,
são homem, por causa do homem assumido.

RESPOSTA À SEGUNDA. — Quando se diz — Cristo é uma causa e outra causa — devemos tomar essa
expressão como significando que tem uma e outra natureza. Tal é a exposição de Agostinho quando,
depois de ter dito — no mediador entre Deus e os homens, uma causa é o Filho de Deus e outra, o Filho
do homem — acrescenta: Digo uma coisa — para distinguir as substâncias; não digo outro – por causa
da unidade de pessoa. Donde o dizer Gregório Nazianzeno: Se devemos nos exprimir
compendiosamente, o Salvador é uma coisa e outra coisa quanto às duas substâncias de que é
composto; entendendo-se que não quero identificar o invisível com o visível, e o atemporal com o
temporal. Mas longe de mim o querer ver nele um ser e outro ser; pois, ambos não fazer mais que um.

RESPOSTA À TERCEIRA. — É falsa a proposição — Cristo é somente homem — porque não exclui outro
suposto, mas, a outra natureza; pois, os termos postos no predicado são tomados formalmente. Mas,
um acréscimo, que os fizesse aplicar ao suposto; tornaria verdadeira a proposição — Cristo é somente
aquilo que é o homem. Donde porém não se segue seja algo outro que o homem, porque sendo – outro
– um relativo, que exprime a diversidade de substância, refere-se propriamente ao suposto, como todos
os relativos expressivos de uma relação pessoal. Mas a consequência é: Logo, tem outra natureza.

RESPOSTA À QUARTA. — Quando dizemos — Cristo é algo, que é o Pai — algo é aí tomado pela
natureza divina, que mesmo em abstrato se predica do Pai e do Filho. Mas, quando dizemos — Cristo é
algo que não o Pai — algo é tomado, não pela natureza humana mesmo enquanto significada em
abstrato, mas enquanto significada em concreto. Não, certo, segundo um suposto distinto, mas segundo
um suposto indistinto; isto é, segundo sub-está à natureza e não, às propriedades individuantes. E por
isso, daí não se segue que Cristo seja uma e outra coisa, ou que seja dois; pois, o suposto da natureza
humana em Cristo, que é a pessoa do Filho de Deus, não faz número com a natureza divina, predicada
do Pai e do Filho.

RESPOSTA À QUINTA. — No mistério da divina Trindade, a natureza divina é predicada, mesmo em
abstrato, das três Pessoas; e por isso podemos dizer, absolutamente falando, que as três Pessoas são
uma só realidade. Mas, no mistério da Encarnação, ambas as naturezas não são predicadas, em
abstrato, de Cristo; e por isso não podemos dizer, em sentido absoluto, que Cristo seja dois.

RESPOSTA À SEXTA. — Dois significa dualidade, não num outro ser, mas no ser mesmo de que é
predicado. Ora, a predicação é feita, do suposto, implicado em o nome de Cristo. Embora, pois, Cristo
tenha dualidade de naturezas, como porém não tem dualidade de supostos, não podemos dizer que
seja dois.

RESPOSTA À SÉTIMA. — A alteridade implica diversidade acidental. Por onde, a diversidade acidental
basta para que o vocábulo outro se aplique em sentido absoluto, a um ser. Ao passo que a aliedade
implica diversidade substancial. Ora, a substância designa não só a natureza, mas também o suposto,
como diz Aristóteles. Por onde, a diversidade de natureza não basta para se atribuir a aliedade a um ser,
em sentido absoluto, salvo se houver diversidade quanto ao suposto. A diversidade de natureza porém
é causa da aliedade relativa, isto é, segundo a natureza, se não houver diversidade do suposto.

## Art. 2 — Se em Cristo há um só ser ou dois.
O segundo discute-se assim. — Parece que em Cristo não há um só ser, mas dois.

1. — Pois, diz Damasceno, as coisas resultantes da natureza se duplicam, em Cristo. Ora, o ser resulta da
natureza, pois, vem da forma. Logo, em Cristo há dois seres.

2. Demais. — O ser do Filho de Deus é a natureza divina mesma, e é eterno. Ora, o ser do homem Cristo
não é a natureza divina, mas um ser temporal. Logo, em Cristo não há só um ser.

3. Demais. — Na Trindade, embora sejam três as pessoas, há contudo um só ser, por causa da unidade
da natureza. Ora, em Cristo há duas naturezas, embora haja uma só pessoa. Logo, em Cristo não há só
um ser, mas dois.

4. Demais. — Em Cristo, a alma dá um certo ser ao corpo, por ser a forma dele. Ora, não lhe dá o ser
divino, pois, é incriado. Logo, em Cristo há outro ser além do divino. E assim, em Cristo, não há só um
ser.
Mas, em contrário. — Um ente é ser na medida em que é um, pois, unidade e ser se convertem. Se, pois,
em Cristo houvesse dois seres e não um só, haveria em Cristo dualidade e não, unidade.

SOLUÇÃO. — Havendo em Cristo duas naturezas e uma hipóstase, há de necessariamente haver
dualidade no que pertence à natureza, e unidade no que só respeita à hipóstase. Ora, o ser diz respeito
tanto à natureza como à hipóstase: à hipóstase, como ao que tem o ser; à natureza, como ao pelo que
um ente existe. Pois, a natureza é significada a modo de forma, chamada ser por ser o princípio da
existência dos entes; assim a brancura é a que torna um ser branco e a humanidade, homem. Ora,
devemos considerar que, havendo uma forma ou natureza, não pertinente ao ser pessoal da hipóstase
subsistente, esse ser não se considera como próprio dessa pessoa, em sentido absoluto, mas sim
relativamente; assim, ser branco é próprio a Sócrates, não enquanto Sócrates, mas enquanto branco. E
nada impede um tal ser multiplicar-se numa hipóstase ou pessoa; pois, um é o ser pelo qual Sócrates é
branco, e outro o pelo qual é músico. Mas aquele ser próprio à hipóstase mesma ou à pessoa em si
mesma, é impossível multiplicar-se numa hipóstase ou numa pessoa; pois, é impossível não seja um só o
ser de uma coisa.
Se, pois, a natureza humana o Filho de Deus a tivesse, não hipostaticamente ou pessoalmente,mas
acidentalmente, como certos ensinaram. seria forçoso admitir em Cristo duas existências: uma
enquanto Deus e outra, enquanto homem. Como Sócrates tem um ser enquanto branco, e outro,
enquanto homem; porque, ser branco não pertence ao ser mesmo pessoal de Sócrates; ao passo que ter
cabeça, corpo e alma, tudo pertence à pessoa mesma de Sócrates; e assim, tudo isso não faz de Sócrates
senão um único ser. E se se desse, que depois da constituição da pessoa de Sócrates, é que ele viesse, a
ter mãos, pés, ou olhos — como acontece com um cego nato — tudo isso não enriqueceria o ser de
Sócrates, mas só constituiria uma relação com tais coisas. Pois, então, lhe atribuíamos o ser, não só pelo
que já antes tinha, mas também pelo que depois se lhe acrescentou. Assim, pois, como a natureza
humana está unida ao Filho de Deus hipostática ou pessoalmente, como dissemos, e não
acidentalmente, resulta por consequência que, com a natureza humana, não adquiriu Cristo nenhum ser
pessoal, mas só uma nova relação do ser pessoal preexistente com a natureza humana; de modo que a
sua pessoa já a devíamos considerar como subsistente, não só segundo a natureza divina, mas também,
segundo a humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O ser resulta da natureza, não pelo ter ela, mas por ser o
princípio dele; ao passo que resulta da pessoa ou da hipóstase, que o têm. Por isso, Cristo tem, antes, a
unidade hipostática do que a dualidade resultante da natureza.

RESPOSTA À SEGUNDA. — O ser eterno do Filho de Deus, que é a natureza divina, torna-se o ser do
homem, por ser a natureza humana assumida pelo Filho de Deus na unidade de pessoa.

RESPOSTA À TERCEIRA. — Como dissemos na Primeira Parte, por ser a pessoa divina idêntica à
natureza, não há nas pessoas divinas outro ser além do ser da natureza; e por isso, as três pessoas não
tem senão um ser. Ora, teriam um ser tríplice, se fosse nelas uma coisa o ser da pessoa e outro, o da
natureza.

RESPOSTA À QUARTA. — A alma de Cristo lhe dá o ser ao corpo, pelo tornar atualmente animado; o
que é dar-lhe o complemento da natureza e da espécie. Mas se entendemos o corpo como perfeito pela
alma, sem a hipóstase que os contém a um e a outra, esse todo composto da alma e de corpo, enquanto
significado pelo nome de humanidade, não o é como um: ser, mas, como o princípio de um ser, E por
isso é o ser mesmo da pessoa subsistente, enquanto tem relação com tal natureza; e dessa relação a
causa é a alma, enquanto aperfeiçoa a natureza humana, informando o corpo.