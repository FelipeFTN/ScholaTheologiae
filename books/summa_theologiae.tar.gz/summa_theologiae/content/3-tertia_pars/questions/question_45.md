# Questão 45: Da transfiguração de Cristo
Em seguida devemos tratar da transfiguração de Cristo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se devia Cristo transfigurar-se.
O primeiro discute-se assim. — Parece que não devia Cristo transfigurar-se.

1. — Pois, não pode um corpo verdadeiro, mas só um corpo fantástico, transformar-se em figuras
diversas. Ora, o corpo de Cristo não era fantástico, mas verdadeiro, como se disse. Logo, parece que não
devia transfigurar-se.

2. Demais. — A figura é a quarta espécie de qualidade; e a glória, sendo uma qualidade sensível, é a
terceira. Logo, o ter-se tornado Cristo glorioso não pode ler considerado transfiguração.

3. Demais. — Os corpos gloriosos têm os quatro dotes seguintes, como mais adiante se dará: a
impassibilidade, a agilidade, a subtileza e a luminosidade. Logo, não devia transfigurar-se tornando-se,
antes, glorioso, que revestindo-se dos outros dotes.
Mas, em contrário, o Evangelho: E transfigurou-se diante dos seus três discípulos.

SOLUÇÃO. — O Senhor, depois de haver anunciado a sua paixão aos discípulos, convidou-os a que lhe
imitassem o exemplo. Ora, é necessário, para trilharmos bem um caminho, termos um conhecimento
prévio do fim. Assim, o sagitário não lança com acerto a seta, senão mirando primeiro o alvo que deve
alcançar. Por isso perguntou Tomé, no Evangelho: Senhor, não sabemos para onde vais; e como
podemos nós saber o caminho? E isso, sobretudo é necessário quando o caminho é difícil e áspero, a
jornada laboriosa, mas belo o fim. Ora, o fim de Cristo, na sua paixão, era alcançar não somente a glória
da alma que, tinha desde o princípio da sua concepção; mas também a do corpo, segundo aquilo do
Evangelho — Importava que o Cristo sofresse estas causas e assim entrar na sua glória. E a essa glória
também conduz os que lhe imitam o exemplo da paixão, segundo a Escritura: Por muitas tribulações nos
é necessário entrar no reino de Deus. Por isso era conveniente que manifestasse aos seus discípulos a
sua claridade luminosa; e tal é a transfiguração, que também concederá aos seus, segundo aquilo do
Apóstolo: Reformará o nosso corpo abatido para o fazer conforme ao seu corpo glorioso. Donde o dizer
Beda: Foi consequência de uma pia providência que, tendo gozado por breve tempo da contemplação
da felicidade eterna, tolerassem mais fortemente as adversidades.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz Jerônimo, comentando o Evangelho: Ninguém pense
que Cristo, por dizer o Evangelho que se transfigurou, tivesse perdido a sua forma e figura natural, ou
que lhe fosse substituído o corpo verdadeiro por outro, espiritual e aéreo. Mas o próprio evangelista
explica a sua transfiguração, quando diz: O seu rosto ficou refulgente como o sol e as suas vestiduras se
fizeram brancas como a neve. Com o que lhe manifesta o esplendor das faces e os luminosos das vestes;
assim a substância do seu corpo não desapareceu, mas somente transformou-se pela glória.

RESPOSTA À SEGUNDA. — A figura depende da extremidade dos corpos; pois, está compreendida no
termo ou nos termos. Por onde, tudo o considerado em dependência das extremidades de um corpo de
certo modo constituiu a figura. Ora, como a cor, também a luminosidade do corpo não transparente
depende-lhe da superfície. Por isso, dizemos que está transfigurando o corpo revestido de
luminosidade.

RESPOSTA À TERCEIRA. — Dentre os quatro dotes referidos, só a luminosidade é uma qualidade da
pessoa em si mesma; quanto aos outros três dotes, eles não são percebidos senão mediante um ato,
movimento ou paixão. Ora, Cristo manifestou na sua pessoa certos sinais de ter os três dotes referidos:
o da agilidade, quando andou sobre as ondas; o da subtileza, quando nasceu do ventre virginal de
Maria; o da impassibilidade, quando saiu ileso das mãos dos Judeus, que o queriam precipitar ou
lapidar. Mas nem por isso diz o Evangelho que se transfigurasse, senão só quando se tornou luminoso, o
que lhe respeita ao aspecto da pessoa.

## Art. 2 — Se a referida luminosidade era gloriosa.
O segundo discute-se assim. — Parece que a referida luminosidade não era gloriosa.

1. — Pois, diz uma Glosa de Beda àquilo do Evangelho — Transfigurou-se na presença deles: No seu
corpo mortal, diz, mostra, não a imortalidade, mas a luminosidade semelhante à imortalidade futura.
Ora, a luminosidade da glória é a luminosidade da imortalidade. Logo, aquela luminosidade, que Cristo
manifestou aos discípulos, era a luminosidade da glória.

2. Demais. — Aquilo do Evangelho — Não hão de gostar a morte até não verem o reino de Deus — diz a
Glosa de Beda: isto é, a glorificação do corpo, numa representação imaginária da beatitude futura. Ora,
a imagem de uma coisa não se confunde com esta. Logo, a referida luminosidade o era a da beatitude.

3. Demais. — Da luminosidade da gloria só é susceptível o corpo humano. Ora, a luminosidade da
transfiguração se manifestou não só no corpo de Cristo, mas também nas suas vestes e na nuvem lúcida
que obumbrou os discípulos. Logo, parece que essa luminosidade não era a da glória.
Mas, em contrário, àquilo de Mateus. — Transfigurou-se perante eles, diz Jerônimo: Tal como há de
aparecer no dia do juízo, assim apareceu aos Apóstolos. E àquele outro lugar do mesmo evangelista —
até que vejam o Filho do homem vir na gloria do seu reino — diz Crisóstomo: Querendo mostrar aquela
glória, com a qual virá mais tarde, manifestou-se-lhes na vida presente, como podiam eles suportar, de
modo que não viessem a se condoer com a morte do Senhor.

SOLUÇÃO. — A luminosidade de que Cristo se revestiu na transfiguração foi a da glória, quanto ao modo
de ser. Pois, a luminosidade do corpo glorioso deriva da luminosidade da alma, como diz Agostinho. E
semelhantemente a claridade do corpo de Cristo na transfiguração deriva da sua divindade, como diz
Damasceno, e da glória da sua alma. E só por uma dispensa divina é que a glória da alma, que Cristo teve
desde o princípio da sua concepção, não redundou no corpo, a fim de que consumasse num corpo
passive os mistérios da nessa redenção, como dissemos. Mas isso não privou Cristo do poder de derivar
a glória da alma para o corpo. E isso o fez quanto à luminosidade, na transfiguração. Mas de modo
diferente que no corpo glorificado. Pois, no corpo glorificado redunda a luminosidade da alma, como
uma qualidade permanente que afeta o corpo; por isso, o refulgir corporalmente o corpo glorioso não é
nenhum milagre. Mas, para o corpo de Cristo, na transfiguração, derivou-lhe a luminosidade da sua
divindade e da sua alma, não a modo de uma qualidade imanente e afectante do corpo em si mesmo,
mas antes a modo de paixão transeunte, como quando o ar é iluminado pelo sol. Por isso, aquele fulgor
de que então se revestiu o corpo de Cristo, foi miraculoso, como também o foi o fato de ter andado
sobre as ondas do mar. Donde o dizer Dionísio: Cristo pratica, com um poder sobre humano, atos que o
homem pode praticar; como o demonstra o fato de ter a Virgem concebido sobrenaturalmente e o de
ter a mobilidade da água sustentado o peso dos seus pés materiais e terrenos. — E por isso não
devemos admitir, como o ensina Hugo de S. Vitor, que Cristo assumiu o dote da luminosidade, na
transfiguração; o da agilidade, quando andou sobre o mar; o da subtileza, quando nasceu do Ventre
Virginal de Maria. Porque dote nomeia uma certa qualidade imanente do corpo glorioso. Cristo, porém,
teve milagrosamente tudo o referente aos dotes. E o mesmo, se deu, quanto à alma, relativamente à
visão pela qual Paulo viu a Deus num rapto, como dissemos na Segunda Parte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Das palavras citadas não se conclui que a luminosidade
de Cristo não fosse a luminosidade da glória; mas, que irão foi a do Corpo glorioso, porque o corpo de
Cristo ainda não era imortal. Pois, como por permissão divina a glória da alma de Cristo não lhe
redundou para o corpo, assim, pela mesma dispensação, pode redundar-lhe quanto ao dote da
claridade, e não quanto ao da impassibilidade.

RESPOSTA À SEGUNDA. — Diz-se que a referida claridade ora imaginária, não por não ser a verdadeira
claridade da glória, mas por ser uma imagem representativa da perfeição da glória, que tornará glorioso
o corpo.

RESPOSTA À TERCEIRA. — Assim como a claridade do corpo de Cristo, na transfiguração, representava a
claridade futura desse mesmo corpo, assim a claridade das suas vestes designava a futura claridade dos
santos, que será superada pela de Cristo, como o candor da neve o é pelo do sol. Por isso diz Gregório,
que as vestes de Cristo se tornaram refulgentes, porque na culminância da claridade superna, todos os
santos unir-se-lhe-ão na refulgência da luz da justiça. E quanto às vestes, elas designam os justos que ele
unirá a si, segundo aquilo da Escritura. — Quanto à nuvem lúcida, ela significa a glória do Espírito Santo,
ou a virtude paterna, como diz Orígenes, pela qual os santos serão garantidos na sua glória futura. —
Embora também com propriedade possa significar a claridade do mundo renovado, que será o
tabernáculo dos santos. Por isso, quando Pedro se dispor a fazer os tabernáculos, a nuvem lúcida
obumbrou os discípulos.

## Art. 3 — Se foram escolhidas testemunhas convenientes da transfiguração.
O terceiro discute-se assim. — Parece que não foram escolhidas testemunhas convenientes da
transfiguração.

1. — Pois, cada um só pode testemunhar o que conhece. Ora, no tempo da transfiguração de Cristo,
ninguém, a não ser os anjos, conhecia por experiência o que fosse a glória futura. Logo, testemunhas da
transfiguração deviam ter sido antes os anjos que os homens.

2. Demais. — Testemunhas da verdade só podem ser pessoas reais e não fictícias. Ora, na transfiguração
Moisés e Elias não estiveram presentes senão ficticiamente. Assim, àquilo do Evangelho — Eis que ali
estavam Moisés e Elias — diz uma Glosa: Devemos saber que Moisés e Elias não apareceram, nessa
ocasião, em corpo e alma, mas com corpos formados numa criatura ocasional. E podemos crer também
que isso foi feito por ministério angélico, de modo que os anjos lhes assumissem as pessoas. Logo, não
foram testemunhas convenientes.

3. Demais. — A Escritura diz, que de Cristo dão testemunho todos os profetas. Logo, não somente
Moisés e Elias deviam ter estado presentes como testemunhas, mas também todos os profetas.

4. Demais. — A glória de Cristo era prometida a todos os seus fiéis, nos quais quis acender, pela sua
transfiguração, o desejo dessa glória. Logo, não devia ter assumido só Pedro, Tiago e João como
testemunhas da sua transfiguração, mas todos os discípulos.
Mas, em contrário, a autoridade da Escritura Evangélica.

SOLUÇÃO. — Cristo quis transfigurar-se, para mostrar a sua glória aos homens e para despertar-lhes o
desejo dela, como dissemos. Ora, à glória da eterna beatitude os homens são levados por Cristo, não só
os que existiram antes, como também depois dele. Por isso, quando caminhava para a sua paixão, tanto
as gentes que iam adiante, como as que iam atrás, gritavam dizendo — Hosana, como esperando dele a
salvação. Por isso era conveniente que, dentre os que o precederam, estivessem como testemunhas
Moisés e Elias; e dos que existiram depois, Pedro, Tiago e João, para que por boca de duas ou três
testemunhas ficasse confirmada essa palavra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Isto, pela sua transfiguração, manifestou aos discípulos a
glória do seu corpo, que só aos homens respeita. Por isso e convenientemente, foram trazidos como
testemunhas dela, não anjos, mas homens.

RESPOSTA À SEGUNDA. — Essa glosa considera-se como extraída do livro intitulado - Dos milagres da
Sagrada Escritura, que não é um livro autêntico, mas falsamente atribuído o Agostinho. Por isso não
devemos nos apoiar nela. Pois, Jerônimo diz expressamente: Devemos notar que aos escribas e aos
fariseus, que lhe pediam um sinal do céu, Cristo não lhes quis dar; mas, na sua transfiguração, para
aumentar a fé dos discípulos, dá-lhes um sinal do céu, a saber, o descenço de Elias, do lugar para onde
ascendera; e a ressurreição de Moisés, dos mortos. Mas não o devemos entender como significando que
a. alma de Moisés retomasse o seu corpo; mas que a sua alma se manifestou, como o fazem os anjos,
por um corpo assumido. Mas Elias apareceu com o seu próprio corpo, não vindo do céu empíreo, mas
de um lugar elevado, para o qual foi arrebatado num carro de fogo.

RESPOSTA À TERCEIRA. — Como diz Crisóstomo, Moisés e Elias foram trazidos como testemunhas, por
muitas razões. — A primeira é a seguinte: Porque como as turbas consideravam-no como Elias ou
Jeremias, ou um dos profetas, fezaparecerem os principais dos profetas, para ao menos assim
manifestar a diferença entre os servos e o Senhor. — A segunda razão é, porque Moisés deu a lei e Elias
foi o zelador da glória do Senhor. Assim, aparecendo simultaneamente com Cristo, ficava aniquilada a
calúnia dos judeus, que acusavam a Cristo de transgressor da lei, e de blasfemo por usurpar para si a
glória de Deus. — A terceira razão é: mostrar que tinha poder sobre a vida e a morte, que era o juiz dos
mortos e dos vivos, por ter tido ao seu lado Moisés, que já morrera, e Elias, ainda vivo. — A quarta razão
é que: como diz o Evangelho falavam da sua saída deste mundo que havia de cumprir em Jerusalém, isto
é, da sua paixão e da sua morte. E assim, para fortalecer, nesse ponto, a alma dos discípulos, fá-Ios se
apresentarem em sua companhia os que se expuseram à morte por Deus; pois, Moisés, com perigo de
morte, se apresentou perante o Faraó e Elias, perante Acab. — A quinta razão é porque queria que os
seus discípulos fossem imitadores da mansidão de Moisés e do zelo de Elias. — A sexta razão,
acrescentada por Hilário, era mostrar que foi anunciado pela lei de Moisés e pelos profetas, entre os
quais era Elias o principal.

RESPOSTA À QUARTA. — Mistérios sublimes não devem ser revelados a todos imediatamente mas
devem oportunamente chegar aos outros homens por meio dos chefes. Por isso, como diz Crisóstomo,
Cristo levou consigo os três discípulos mais principais: Pois, Pedro foi executado pelo amor, que teve
para com Cristo e também pelo poder que lhe foi cometido; João, pelo privilégio do amor com que, por
causa da sua virgindade, era amado de Cristo, e também pela prerrogativa de ter pregado a doutrina
Evangélica: e Tiago enfim, pela prerrogativa do martírio. E contudo Cristo não quis que esses mesmo
anunciassem, o que viram antes da sua ressurreição. A fim de como explica Jerônimo. fato de tão
grande magnitude não ser tido como incrível; nem viesse, depois de tão grande glória, a causar
escândalo, entre almas rudes, a cruz, que lhe havia de suceder; ou também a fim de o povo não se lhe
opor invencivelmente; e para que, quando estivessem cheios do Espírito Santo, então fossem
testemunhas desses fatos espirituais.

## Art. 4 — Se convenientemente se acrescentou o testemunho da voz paterna que dizia: Este é o meu filho dileto.
O quarto discute-se assim. — Parece que se acrescentou inconvenientemente o testemunho da voz
paterna que dizia: este é o meu filho dileto.

1. — Pois, como diz a Escritura, Deus fala uma vez e segunda vez não repete uma mesma causa. Ora, no
batismo, isso mesmo o proclamara a voz paterna. Logo, não era conveniente que ainda fosse de novo
proclamado na transfiguração.

2. Demais. — No batismo, simultaneamente com a voz paterna apareceu o Espírito Santo em forma de
pomba. O que não se deu na transfiguração. Logo, parece não devia ter havido a proclamação do Pai.

3. Demais. — Cristo começou a ensinar depois do batismo. E contudo no batismo a voz do Pai não veio
advertir os homens a ouví-Io. Logo, nem o devia ter feito na transfiguração.

4. Demais. — Não devemos dizer a outros o que não poderiam suportar, conforme aquilo do Evangelho:
Eu tenho ainda muitas coisas, que vos dizer, mas vós não nas podeis suportar agora. Ora, os discípulos
não podiam suportar a voz do Pai, pois, diz o Evangelho: Ouvindo isto, os discípulos caíram de braços e
tiveram grande medo. Logo, a voz paterna não se lhes devia manifestar.
Mas, em contrário, a autoridade da Escritura Evangélica.

SOLUÇÃO. — A adoção de filhos de Deus supõe uma certa conformidade entre a imagem e quem é
realmente Filho de Deus. O que de dois modos se dá. Primeiro, pela graça, conferida nesta vida; que é
uma conformidade imperfeita. Segundo, pela glória da pátria, que será a conformidade perfeita,
segundo aquilo do Evangelho: Agora somos filhos de Deus e não apareceu ainda o que havemos de ser.
Sabemos que, quando ele aparecer, seremos semelhantes a ele; porquanto nos outros o teremos bem
como ele é. Ora, como recebemos a graça pelo batismo, e a transfiguração foi um prenúncio do
esplendor da glória futura, por isso, tanto no batismo como na transfiguração foi conveniente
manifestar-se a filiação natural de Cristo, pelo testemunho do Pai. Por que só o Pai é perfeitamente
cônscio dessa perfeita geração, simultaneamente com o Filho e o Espírito Santo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lugar citado deve ser referido à eterna locução de
Deus, pela qual Deus Padre proferiu o Verbo, coeterno consigo. E contudo podemos dizer que Deus,
com voz material, proferiu duas vezes o mesmo verbo, mas não com o mesmo fundamento; mas para
mostrar o modo diverso pelo qual os homens podem participar da semelhança da filiação eterna.

RESPOSTA À SEGUNDA. — No batismo quando foi anunciado o mistério da primeira regeneração,
manifestou-se a obra de toda a Trindade, porque aí se manifestou o Filho encarnado, apareceu o
Espírito Santo em figura de pomba e o Pai se anunciou verbalmente. Assim também na transfiguração,
que é o sacramento da segunda regeneração, toda a Trindade manifestou-se — o Pai, pela voz; o Filho,
pela sua humanidade; o Espírito Santo, pela nuvem luminosa. Porque, assim como, no batismo dá a
inocência, designada pela simplicidade da pomba, assim na ressurreição dará aos eleitos o esplendor da
sua glória e a libertação de todo mal, simbolizados pela nuvem lúcida.

RESPOSTA À TERCEIRA. — Cristo veio nos dar a graça atual, mas só prometer a glória, com a sua
palavra. Por isso e convenientemente na transfiguração os homens são advertidos a ouvi-lo, não porem
no batismo.

RESPOSTA À QUARTA. — Foi conveniente os discípulos se aterrorizarem com a voz do Pai e se
prosternarem, a fim de ficar assim claro que a excelência dessa glória que então se manifestava, excede
toda a compreensão e toda a capacidade dos mortais, segundo aquilo da Escritura: Nenhum homem me
verá e depois viverá. E por isso diz Jerônimo, que a fragilidade humana não pode suportar o esplendor
de uma tão grande glória. Mas Cristo nos cura dessa fragilidade, introduzindo-nos na glória. O que
significam as, palavras que lhes disse: Levantai-vos e não temais.