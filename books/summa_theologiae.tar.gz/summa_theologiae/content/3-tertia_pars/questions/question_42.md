# Questão 42: Da doutrina de Cristo
Em seguida devemos tratar da doutrina de Cristo. E nesta questão discutem-se quatro artigos:

## Art. 1 — Se Cristo devia pregar não só aos Judeus, mas também aos gentios.
O primeiro discute-se assim. — Parece que Cristo devia pregar, não somente aos judeus, mas também
aos gentios.

1. — Pois, diz a Escritura: Pouco é que tu sejas meu servo para suscitar as tribos de Israel e converter as
fezes de Jacó. Eis aqui estou eu que te estabeleci para luz das gentes a fim de seres tu a salvação que eu
envio até a última extremidade da terra. Ora, a luz e a salvação Cristo nos trouxe com a sua doutrina.
Logo, parece que não devia ter pregado só, aos judeus, com exclusão dos gentios.

2. Demais. — Como diz o Evangelho, Ele os ensinava como quem tinha autoridade. Ora, maior
necessidade havia de ensinar doutrina para a instrução daqueles que nunca o ouviram pregar, como'
eram os gentios; donde o dizer o Apóstolo - Assim tenho anunciado este Evangelho, não onde se havia
feito já menção de Cristo, por não edificar sobre fundamento de outro. Logo, com muito maior razão,
Cristo devia pregar, antes, aos gentios que aos judeus.

3. Demais. — É mais útil a instrução de muitos que a de um só. Ora. Cristo instruiu certos gentios, como
a mulher Samaritana e a Cananía. Logo, parece que Cristo devia com muito maior razão pregar à
multidão dos gentios.
Mas, em contrário, o Senhor diz, no Evangelho: Eu não fui enviado senão às ovelhas que pereceram da
casa de Israel. E o Apóstolo: Como pregarão eles se não forem enviados? Logo, Cristo não devia pregar
aos gentios.

SOLUÇÃO. — Tanto Cristo como os Apóstolos deviam ter começado por pregar só aos Judeus. —
Primeiro, para mostrar que, pelo seu advento, se cumpriram as promessas anteriormente feitas aos
judeus e não aos gentios. Donde o dizer o Apóstolo: Digo que Jesus Cristo foi ministro da circunscrição,
isto é, Apóstolo e pregador dos judeus, pela verdade de Deus, para confirmar as promessas dos pais. —
Segundo, para provar que o seu advento procedia de Deus; pois, as coisas de Deus são ordenadas, como
diz o Apóstolo. Ora, a ordem devida exigia que a doutrina de Cristo fosse proposta primeiro aos Judeus,
mais próximos de Deus pela fé e pelo culto monoteísta, para ser depois, por meio deles, transmitida aos
gentios; assim como também, na hierarquia celeste as iluminações divinas são transmitidas aos anjos
inferiores pelos superiores. Por isso, àquilo do Evangelho — Eu não fui enviado senão às ovelhas que
pereceram da casa de Israel — diz Jerônimo: Não quer isso significar que não foi mandado aos gentios,
mas que o foi primeiro a Israel. Donde o dizer a Escritura: E os que dentre eles forem salvos, isto é, dos
judeus, eu os enviarei às gentes de além mar e eles anunciarão a minha glória as gentes. — Terceiro,
para tirar aos judeus a ocasião de caluniá-lo. Por isso, àquilo do Evangelho — Não ireis caminho de
gentios, diz Jerônimo: O advento de Cristo devia ser anunciado primeiro aos judeus, para não terem
justa excusa de dizer, que rejeitaram o Senhor, porque mandou os seus apóstolos aos gentios e aos
samaritanos. — Quarto, porque Cristo, pela vitória da cruz, mereceu o poder e o domínio sobre as
gentes. Por isso diz a Escritura: Aquele que vencer eu lhe darei poder sobre as nações, assim como
também eu a recebi de meu Pai. E o Apóstolo diz que porque foi feito obediente até a morte da cruz,
Deus o exaltou para que ao nome de Jesus se dobre todo o joelho e toda língua e confesse. E eis porque
antes da paixão não quis pregar a sua doutrina aos gentios; mas depois dela disse aos discípulos: Ide e
ensinai a todas as gentes. Por isso, como se lê no Evangelho, quando, na iminência da paixão, certos
gentios queriam ver a Jesus, respondeu: Se o grão de trigo que cai na terra não morrer, fica ele só; mas
se ele morrer produz muito fruto. E, como explica Agostinho, dizia de si que era um grão à ser morto,
pela infidelidade dos judeus; e multiplicado, pela fé de todos os povos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo foi a luz e a salvação das gentes por meio dos seus
discípulos, que mandou a pregarem aos gentios.

RESPOSTA À SEGUNDA. — Agir antes por meio de outrem que por si mesmo é sinal, não de um poder
inferior, mas de um poder maior. Por isso o poder divino de Cristo se manifestou sobretudo por ter
conferido aos seus discípulos um tão grande poder de ensinar, que converteram para Cristo os gentios,
que nunca tinham ouvido falar dele. — Ora, o poder de ensinar, que Cristo tinha, pode ser considerado
quanto aos milagres, pelos quais confirmava a sua doutrina; quanto à eficácia de persuadir; e quanto à
autoridade da sua palavra, porque falava como quem tinha o domínio sobre a lei, quando afirmava — Eu
porém vos digo; e também quanto à virtude da retidão, que mostrava na sua vida isenta de pecados.

RESPOSTA À TERCEIRA. — Assim como Cristo não devia comunicar indiferentemente, desde o princípio,
a sua doutrina aos gentios, a fim de mostrar que fora dado aos Judeus, como ao povo primogênito,
assim também não devia repelir de todo os gentios, para não serem privados da esperança da salvação.
E por isso certos gentios foram particularmente admitidos por causa da excelência da sua fé e devoção.

## Art. 2 — Se Cristo devia pregar aos judeus sem os chocar.
O segundo discute-se assim. — Parece que Cristo devia pregar aos judeus sem os chocar.

1. — Pois, como diz Agostinho, Jesus Cristo, homem e Filho de Deus, deu-se-nos como exemplo de vida.
Ora, devemos evitar não só o escândalo dos fiéis, mas também o dos infiéis, conforme aquilo do
Apóstolo: Portai-vos sem dar escândalo, nem aos Judeus nem aos gentios. Logo, parece que também
Cristo devia ensinar aos judeus sem os chocar.

2. Demais. — Ninguém que proceda com sabedoria deve agir de modo a contrariar o efeito da sua obra.
Ora, Cristo contrariando os judeus com a sua doutrina encontrava-lhe os efeitos. Assim, quando
repreendeu os escribas e os fariseus, começaram a apertá-lo com fortes instâncias e a quererem-no
fazer calar com a multidão das questões a que o obrigavam a responder, armando-lhe desta maneira
laços e buscando ocasião de lhe apanharem da boca alguma palavra para o acusarem. Logo, parece que
não devia chocá-las com a sua doutrina.

3. Demais. — O Apóstolo diz: Não repreendas com aspereza ao velho, mas adverte-o como o pai. Ora, os
sacerdotes e os príncipes dos judeus eram os anciãos do povo. Logo, parece que não devia arguí-los com
duras íncrepações.
Mas, em contrário, a Escritura profetizou que Cristo seria pedra de tropeço e pedra de escândalo às
duas casas de Israel.

SOLUÇÃO. — O bem comum é preferível ao de qualquer particular. Por onde, o pregador ou o doutor,
para prover ao bem comum, não deve temer atacar aqueles que perversamente se opõem a esse bem.
Ora, os escribas, os fariseus e os príncipes dos judeus eram, com a sua malicia, um grande obstáculo ao
bem do povo, quer por se oporem à doutrina de Cristo, única donde podia provir a salvação; quer
também porque corrompiam com os seus maus costumes a vida do povo. Por isso o Senhor ensinava
publicamente a verdade, que eles odiavam, e lhes íncrepava os vícios, embora assim os chocasse.
Donde, como se lê no Evangelho, aos discípulos que diziam ao Senhor — Sabes que os fariseus, depois
que ouviram o que disseste, ficaram escandalizados? Respondeu: Deixai-os, cegos são e condutores de
cegos; e se um cego guia a outro cego, ambos vêm a cair no barranco.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Devemos proceder sem chocar a ninguém, não dando a
quem quer que seja ocasião de queda por algum dito ou ato nosso menos certo. Mas se a verdade for
ocasião de escândalo, devemos antes arrastar o escândalo que abandonar a verdade, como diz
Gregório.

RESPOSTA À SEGUNDA. — Cristo, arguindo publicamente os escribas e fariseus, longe de impedir,
promovia o efeito da sua doutrina. Pois, como o povo lhes conhecia os vícios, as palavras dos escribas e
dos fariseus, que sempre se opunham à doutrina de Cristo, tinham menos poder para o desviarem dele.

RESPOSTA À TERCEIRA. — Essas palavras do Apóstolo devem sei entendidas dos anciãos que o eram,
não só pela idade ou pela autoridade, mas também pela honorabilidade, conforme àquilo da Escritura
— Ajunta-me setenta homens dos anciãos de Israel que tu souberes serem os mais experimentados do
povo, Mas, se a autoridade da velhice a transformarem em instrumento da malícia, pecando
publicamente, devem ser manifesta e acremente increpados, como o fez Daniel quando objurgou:
Homem inveterado no mal, etc.

## Art. 3 — Se Cristo devia ensinar tudo publicamente.
O terceiro discute-se assim. — Parece que Cristo não devia ensinar tudo publicamente.

1. — Pois, como lemos no Evangelho, Cristo ensinou muitas coisas particularmente aos discípulos, como
o demonstra o sermão da Ceia. Por isso refere o evangelista: O que se vos diz ao ouvido, publicai-o dos
telhados. Logo, não devia ensinar tudo publicamente.

2. Demais. — As profundezas da sabedoria não devem ser transmitidas senão aos perfeitos, segundo
aquilo do Apóstolo: Entre os perfeitos falamos da sabedoria. Ora, a doutrina de Cristo continha a
profundíssima das sabedorias. Logo, não devia ser comunica da à multidão imperfeita.

3. Demais. — Ocultar uma verdade pelo silêncio é o mesmo que a envolver em palavras obscuras. Ora,
Cristo ocultava a verdade que pregava as turbas, com a obscuridade das palavras; pois, não lhes falava
sem parábolas, como diz o Evangelho. Logo, pela mesma razão, poderia ocultá-la com o silêncio.
Mas, em contrário, o próprio Cristo o proclamou: Eu nada disse em segredo.

SOLUÇÃO. — Quem ensina uma doutrina pode ocultá-la de três modos. — Primeiro, intencionalmente,
quando tem a intenção não de a manifestar a muitos, mas antes, de ocultá-la. Oque de dois modos pode
dar-se. — Às vezes, por inveja do docente, que querendo ser excelente pela sua ciência, não quer
comunica-la aos outros. O que não se dava com Cristo, de cuja pessoa diz a Escritura: Eu a aprendi sem
fingimento e a reparto com os outros sem inveja e não escondo as riquezas que ela encerra. — Outras
vezes tal se dá por causa da inhonestidade das coisas ensinadas, como o diz Agostinho: Há certas coisas
tão más que nenhum pudor humano pode suportá-las. Por isso, da doutrina dos heréticos diz a
Escritura: As águas furtivas são mais doces. Ora, a doutrina de Cristo, como diz o Apóstolo, não foi de
erro nem de imundície. Donde o dizer o Senhor: Porventura vem a lucerna, isto é, a doutrina verdadeira
e honesta, para a meterem debaixo do alqueire? De outro modo, uma doutrina fica oculta quando
exposta a poucos. E, nesse sentido, Cristo também nada ensinou ocultamente, porque propunha toda a
sua doutrina ou a todo o povo ou a todos os seus discípulos em comum. Donde o dizer Agostinho: Falará
ocultamente quem fala na presença de todos? Sobretudo que, se o faz a poucos, é que quer por meio
desses ensinar a todos. Em terceiro lugar uma doutrina pode ser oculta quanto ao modo de ensinar.
Assim, Cristo expunha certas coisas às turbas, ocultamente, usando de parábolas a fim de anunciar os
mistérios espirituais, para cuja compreensão não eram idôneos nem dignos. E contudo era-Ihes melhor,
mesmo assim, oculta em parábolas, ouvir a doutrina espiritual, do que ficarem de todo privadas dela.
Mas a verdade patente e nua dessas parábolas o Senhor a expunha aos seus discípulos, por meio dos
quais pudessem chegar a outros, que delas fossem capazes, segundo aquilo do Apóstolo: O que ouviste
da minha boca diante de muitas testemunhas, entrega-o a homens fiéis, que sejam capazes de instruir
também a outros. E é o que significa aquele lugar da Escritura, onde se manda aos filhos de Aarão
envolver os vasos do Santuário, que os Levitas assim haveriam de levar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Hilário, não lemos no Evangelho, que o Senhor
costumasse pregar à noite ou ensinar a sua doutrina nas trevas; e quando o diz isso significa que todas
as suas pregações eram trevas para os homens carnais e sua palavra, a noite para os infiéis. Por isso, o
que disse quer que entre os infiéis, seja publicado entenda com a liberdade da fé e da pregação. - Ou,
segundo Jerônimo, falava em sentido comparativo, porque os ensinava no país da Judia, pequeno
relativamente a todo o mundo, no qual deveria publicar-se a doutrina de Cristo, pela pregação dos
Apóstolos.

RESPOSTA À SEGUNDA. — O Senhor não manifestou, com a sua doutrina, toda a profundeza da sua
sabedoria, nem às multidões nem ainda aos seus discípulos, a quem disse: Eu tenho ainda muitas coisas
que vos dizer, mas vós não nas podeis suportar agora. Contudo, o que julgou digno de transmitir aos
outros, da sua sabedoria, não o propôs às ocultas, mas publicamente, embora não fosse entendido por
todos. Donde o dizer Agostinho: Quando oSenhor disse - falei publicamente ao mundo, é como se
tivesse dito - muitos me ouviram. Mas não era público o seu ensino para quem não o entendesse.

RESPOSTA À TERCEIRA. — O Senhor falava à multidão em parábolas, como se disse, porque ela não era
digna nem capaz de receber a verdade plena, que expunha aos discípulos. — Quanto ao dito do
Evangelho - não lhes falava em parábolas - ele se refere, segundo Crisóstomo, ao que pregava nessa
ocasião; pois em outras ocasiões muitas outras coisas ensinou às turbas, sem parábolas. — Ou, segundo
Agostinho, esse dito não significa que não explicasse nada com expressões apropriadas, mas que quase
não deu nenhum ensinamento em que não se servisse de alguma parábola, embora empregasse então
expressões claras.

## Art. 4 — Se Cristo devia ensinar a sua doutrina por escrito.
O quarto discute-se assim. — Parece que Cristo não devia ensinar a sua doutrina por escrito.

1. — Pois, a escrita foi inventada para, no futuro, gravar a doutrina na memória. Ora, a doutrina de
Cristo devia durar eternamente, segundo aquilo do Evangelho: Passará o céu e a terra, mas as minhas
palavras não passarão. Logo, parece que Cristo devia ter ensinado a sua doutrina por escrito.

2. Demais. — A lei antiga foi uma figura de Cristo, segundo aquilo do Apóstolo: A lei tendo a sombra dos
bens futuros. Ora, a lei antiga foi escrita por Deus, segundo a Escritura: Dar-te-ei duas tabuas de pedra e
a lei e os mandamentos que eu escrevi. Logo, parece que também Cristo devia ter escrito a sua doutrina.

3. Demais. — A Cristo, que veio alumiar os que vivem de assento nas trevas e na sombra da morte,
como diz o Evangelho, pertencia eliminar as ocasiões de erro e abrir o caminho à fé. Ora, tal o faria
escrevendo a sua doutrina. Assim, diz Agostinho: Certos costumam achar dificuldade no fato do Senhor
nada ter escrito, de modo que devamos crer no que os outros dele escreveram. E quem isso diz são
sobretudo os pagãos, que, não ousando culpar a Cristo ou blasfemar contra Ele, atribuem-lhe uma
sabedoria excelentíssima, mas como a homem. E dizem que os discípulos atribuíram ao mestre mais do
que lhe era devido, quando afirmavam que era o Filho e o Verbo de Deus, por quem foram feitas todas
as coisas. E depois acrescenta: Estão prontos a crer o que Cristo mesmo disse de si e não o que outros
arbitrariamente lhe atribuíram. Logo, parece que Cristo devia ele próprio transmitir a sua doutrina por
escrito.
Mas, em contrário, entre as Escrituras canônicas, não há nenhum livro escrito por ele.

SOLUÇÃO. — Cristo não devia ter deixado a sua doutrina por escrito. — Primeiro, por causa da sua
dignidade. Pois, tanto mais excelente é quem ensina e tanto mais excelente deve ser o seu modo de
ensinar. Sendo, portanto Cristo o mais excelente dos doutores, o seu modo de ensinar devia consistir
em imprimir a sua doutrina no coração dos ouvintes. E por isso diz o Evangelho, que eleos ensinava
como quem tinha autoridade. Assim também entre os gentios, Pitágoras e Sócrates, que foram
excelentíssimos doutrinadores, nada quiseram escrever. Pois, a escrita tem como fim a impressão da
doutrina no coração dos ouvintes. — Segundo, por causa da excelência da doutrina de Cristo, que não
pode ser abrangida pela escrita, segundo aquilo do Evangelho: Muitas outras causas porém há ainda,
que fez Jesus; as quais se escrevessem uma por uma, creio que nem no mundo todo poderiam caber os
livros que delas se houvessem de escrever. O que não significa que devemos crer, como diz Agostinho,
não pudesse o mundo conter tais livros, localmente falando, mas que talvez não pudesse compreendê-
los a capacidade dos leitores. Se, porém, Cristo tivesse deixado a sua doutrina por escrito, os homens
não a julgariam senão pelo que estava escrito. — Terceiro, para que a doutrina promanada dele
chegasse a todos numa certa ordem, de modo que sendo primeiro os discípulos os ensinados,
ensinassem depois aos outros com as suas palavras e os seus escritos. Se, ao contrário, ele próprio
tivesse, escrito, a sua doutrina chegaria a todos imediatamente. Por isso a Escritura diz da sabedoria de
Deus: Enviou as suas escravas a chamar à fortaleza. Devemos, porém saber que, como refere Agostinho,
certos gentios pensavam ter Cristo escrito certos livros que continham mágicas com as quais fazia
milagres, condenados pela doutrina cristã. É contudo os que afirmam ter lido esses tais livros de Cristo
não fazem nada de comparável ao que admiram que ele com tais livros tivesse feito. E por juízo divino
erram, a ponto de dizerem que esses tais livros eram dedicados a Pedro e a Paulo, porque em vários
passos viram esses apóstolos pintados em companhia de Cristo. Nem é de espantar se foram enganados
esses falsários pelas figuras pintadas. Pois, durante todo o tempo em que Cristo viveu em corpo mortal,
com os seus discípulos, Paulo ainda não era do número deles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho no mesmo livro, Cristo é a cabeça
de todos os seus discípulos, como membros do seu corpo. Por isso, o que eles relataram como ensinado
e dito por ele, de nenhum modo devemos dizer que não o tivesse ele próprio escrito. Pois, às vezes os
seus membros fizeram o que sabiam que o chefe mandou. Assim, todos os seus fatos e ditos que quis
que nos lêssemos, mandou-os escrever, como se ele próprio o tivesse escrito.

RESPOSTA À SEGUNDA. — Por ter a lei antiga sido dada sob figuras sensíveis, também foi
convenientemente escrita com sinais sensíveis. Mas a doutrina de Cristo, que é a lei do Espírito de vida,
devia ter sido escrita, não com tinta, mas com o espírito de Deus vivo, não em tábuas de pedra, mas em
taboas de carne do coração, como diz o Apóstolo.

RESPOSTA À TERCEIRA. — Os que não quiseram crer no que os Apóstolos escreveram de Cristo não
acreditariam nem mesmo no que o próprio Cristo escrevesse; de quem opinavam que fazia milagres por
meio de artes mágicas.