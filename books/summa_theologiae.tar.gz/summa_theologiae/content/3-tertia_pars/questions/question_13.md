# Questão 13: Da potência da alma de Cristo
Em seguida devemos tratar da potência da alma de Cristo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a alma de Cristo tinha a onipotência.
O primeiro discute-se assim. — Parece que a alma de Cristo tinha a onipotência.
1 — Pois, diz Ambrósio: O poder que o Filho de Deus tem naturalmente, o homem o teria num certo
tempo. Ora, parece que isso se aplica sobretudo à alma, a parte mais importante do homem. Ora, como
o Filho de Deus tinha a onipotência abeterno, parece que a alma de Cristo recebeu a onipotência no
tempo.

2. Demais. — Como o poder de Deus é onipotente, assim também a sua ciência. Ora, a alma de Cristo
tem de certo modo a ciência de tudo o que Deus sabe, como se disse. Logo, também tem o poder sobre
tudo. E assim, é onipotente.

3. Demais. — A alma de Cristo tem a ciência total. Ora, das ciências, umas são práticas, outras
especulativas. Logo, tem, daquilo que sabe, uma ciência prática, de modo que saiba que faz o que sabe.
E assim, parece que pode fazer tudo.
Mas, em contrário. — O que é próprio a Deus não pode sê-lo a nenhuma criatura. Ora, é próprio de
Deus ser onipotente, segundo aquilo da Escritura: Este é o meu Deus e eu o glorificarei; e depois
acrescenta: Seu nome é onipotente. Logo, a alma de Cristo sendo uma criatura, não tem a onipotência.

SOLUÇÃO. — Como dissemos, no mistério, da Encarnação a união com a pessoa se fez sem destruir a
distinção das naturezas, conservando cada natureza o que lhe é próprio. Ora, a potência ativa de um ser
resulta-lhe da forma, que é o princípio de ação. Ora, a forma ou é a natureza mesma do ser, como nos
simples; ou a constitui, como nos compostos de matéria e forma. Por onde, é manifesto que a potência
ativa de todo ser resulta da natureza dele. E, deste modo, a onipotência resulta, como uma
consequência, da natureza divina. Mas, sendo a natureza divina o ser mesmo incircunscrito de Deus,
segundo o diz Dionísio, daí vem o ter ele a potência ativa em relação a tudo o que por essência é um ser
- o que é ter a onipotência; assim, qualquer outro ser tem a potência ativa em relação ao que se estende
a perfeição da sua natureza, como o corpo quente, ao aquecer. Ora, sendo a alma de Cristo parte da
natureza humana, é lhe impossível ter a onipotência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem recebeu no tempo a onipotência, que o Filho
de Deus tinha abeterno em virtude da união pessoal; donde resultava que, assim como o homem era
Deus, também era onipotente. Não que a onipotência do homem seja diferente da do Filho de Deus,
como não o é a divindade; mas, por ser uma só a pessoa de Deus e a do homem.

RESPOSTA À SEGUNDA. — Certos dizem que não se pode atribuir à ciência o mesmo que se atribui à
potência ativa; pois, a potência ativa resulta da natureza mesma do ser, porque a ação se considera
como originária do agente. Ao passo que a ciência nem sempre resulta da essência mesma do ciente;
mas pode ser adquirida pela assimilação do ciente com as causas sabidas, pelas semelhanças por ele
recebidas. — Mas esta razão não é suficiente. Pois, se podemos conhecer mediante a semelhança
recebida de outro, também podemos agir pela forma de outro recebida; assim, a água ou o ferro aquece
pelo calor recebido do fogo. Mas isto não impede que, assim como a alma de Cristo, mediante as
semelhanças de todas as coisas nela infundidas por Deus, pode conhecer tudo, assim também possa
fazê-las, mediante essas mesmas semelhanças. — Por isso, devemos ainda considerar, ulteriormente,
que o recebido, de uma natureza superior, por outra, inferior, o é ao modo da inferior; assim, a água
não recebe o calor com â mesma perfeição que ele tem no fogo. Ora, a alma de Cristo, sendo de
natureza inferior à natureza divina, as semelhanças das coisas não as recebe ela com a mesma perfeição
e a mesma virtude com que existem em a natureza divina. Donde vem que a ciência da alma de Cristo é
inferior à ciência divina, quanto ao modo de conhecer porque Deus conhece as coisas mais
perfeitamente que a alma de Cristo; e também quanto ao número das coisas conhecidas, porque a alma
de Cristo não conhece todas as causas que Deus pode fazer, as quais contudo Deus conhece pela ciência
da simples inteligência; embora, a alma de Cristo conheça todas as coisas presentes, passadas e futuras,
que Deus conhece pela ciência de visão. Semelhantemente, as semelhanças das coisas, infundidas na
alma de Cristo, não igualam a ação do poder divino, de modo que possa fazer tudo o que Deus o pode;
ou ainda, agir, do mesmo modo com que Deus age; o qual age pelo seu poder infinito, de que a criatura
não é capaz. Ora, nenhum ser existe que, para ser conhecido, exija uma virtude de algum modo infinita,
embora haja um modo de conhecer cujo poder é infinito, Mas, há certas coisas que só podem ser feitas
por um poder infinito, como a criação e outras tais, segundo se colige do que dissemos na Primeira
Parte, Por onde, a alma de Cristo que, sendo criatura, tem um poder finito, pode certo, conhecer tudo,
mas não, omnimodamente, Assim não pode fazer tudo que essencialmente supõe a onipotência; e,
quanto ao mais, é claro que não podia criar-se a si mesma.

RESPOSTA À TERCEIRA. — A alma de Cristo tinha tanto a ciência prática como a especulativa; mas isso
não implica que tivesse a ciência prática de tudo o de que tinha a especulativa. Pois, para se adquirir a
ciência especulativa basta só a conformidade ou a assimulação do ciente com a coisa sabida. Ao passo
que a aquisição da ciência prática exige que sejam factivas as coisas cujas formas estão no intelecto,
Ora, mais é ter uma forma e imprimir essa forma em outro, que somente tê-la; assim como luzir e
iluminar é mais que somente luzir. Donde vem que a alma de Cristo tem, por certo, a ciência
especulativa de criar, pois, sabe como Deus cria; mas disso não tem a ciência prática, por não ter a
ciência factiva da criação.

## Art. 2 — Se a alma de Cristo tem a onipotêncía para causar mudanças nas criaturas.
O segundo discute-se assim, - Parece que a alma de Cristo tem a onipotência para causar mudanças
nas criaturas.

1. — Pois, diz o próprio Cristo: Tem-se-me dado todo o poder no céu e na terra, Ora, os nomes de céu e
de terra abrangem todas as criaturas, como se lê na Escritura: No princípio criou Deus o céu e a terra,
Logo, parece que a alma de Cristo tem a onipotência para causar mudanças nas criaturas.

2. Demais. — A alma de Cristo é mais perfeita que qualquer outra .criatura. Ora, qualquer criatura pode
ser movida por outra. Assim, diz Agostinho: Como os corpos mais rudes e inferiores são governados
pelos mais subtis e poderosos,numa certa ordem, também todos os corpos o são pelo espírito vital; e o
espírito vital racional trânsfuga e pecador, pelo espírito vital racional pio e justo. Ora, a alma de Cristo
move mesmo os próprios espíritos supremos, iluminando-os, como diz Dionísio. Logo, parece que a
alma de Cristo tem a onipotência para causar mudanças nas criaturas.

3. Demais. — A alma de Cristo tinha, na sua plenitude, a graça dos milagres ou das virtudes, como tinha
as demais graças. Ora, toda mudança, causada na criatura pode implicar a graça dos milagres. Assim,
como o prova Dionísio, os corpos celestes foram mudados na sua ordem, milagrosamente. Logo, a alma
de Cristo tinha a onipotência para causar mudanças nas criaturas.
Mas, em contrário, a quem pertence causar mudanças nas criaturas também pertence conservá-las. Ora,
isto só Deus o pode fazer, segundo aquilo do Apóstolo: Sustentando tudo com a palavra da sua virtude.
Logo, só Deus tem a onipotência para causar mudanças nas criaturas. E portanto tal não convém à alma
de Cristo.

SOLUÇÃO. — Temos necessidade de fazer, nesta matéria, uma dupla distinção. — A primeira relativa às
transmutações das criaturas, e essa é tríplice. Uma é natural, resultante do próprio agente, na ordem da
natureza. Outra, miraculosa, resultante de um agente sobrenatural, acima da ordem habitual e do censo
da natureza, tal a ressurreição dos mortos. A terceira resulta de poder toda criatura ser convertida em
nada. — Ora, a segunda distinção devemos aplicá-la à alma de Cristo, a qual pode ser considerada a
dupla luz. Primeiro, quanto à sua natureza própria e à sua virtude, quer natural, quer gratuita. Segundo,
enquanto instrumento do Verbo de Deus a ela pessoalmente unido.
Se, pois, consideramos a alma de Cristo na sua natureza própria e na sua virtude, quer natural, quer
gratuita, tinha ela o poder de produzir aqueles efeitos próprios da alma; por exemplo, governar o corpo
e dispor os atos humanos; e ainda o de iluminar pela plenitude da graça e da ciência todas as criaturas
racionais, menos perfeitas que ela, ao modo conveniente à criatura racional. Se, porém, consideramos a
alma de Cristo, enquanto instrumento do Verbo a ela pessoalmente unido, então, tinha uma virtude
instrumental para fazer todas as transformações miraculosas, ordenáveis ao fim da Encarnação, que é,
como diz o Apóstolo, restaurar em Cristo todas as coisas, assim as que há no céu como as que há na
terra. Quanto às transformações das criaturas, enquanto redutíveis ao nada, elas correspondem à
criação das coisas, isto é, enquanto produzidas do nada. Por onde, assim como só Deus pode criar,
assim, só ele pode reduzir as criaturas ao nada; e é também só ele quem as conserva no ser para não
caírem em o nada.
Por onde devemos concluir que a alma de Cristo não tem a onipotência relativamente às
transformações das criaturas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Jerônimo, o referido poder foi dado a quem
pouco antes tinha sido crucificado, que foi sepultado no túmulo, que depois ressurgiu, isto é, a Cristo
enquanto homem. E se diz que todo o poder lhe foi dado, é em razão da união, que fez com que o
homem fosse onipotente, como dissemos. E embora disso os anjos tivessem tido conhecimento, antes
da ressurreição, depois desta, contudo, é que todos os homens o souberam, como diz Remígio. Pois
dissemos que as coisas são feitas quando o sabemos. Por isso, depois da ressurreição, o Senhor disse
que todo poder lhe foi dado no céu e na terra.

RESPOSTA À SEGUNDA. — Embora toda criatura possa ser mudada por outra, menos o anjo supremo,
que contudo pode ser iluminado pela graça de Cristo, contudo, nem toda mudança que uma criatura
pode sofrer pode ser causada por outra; mas, há certas transmutações que só Deus pode fazer. Porém,
quaisquer mudanças das criaturas, que podem ser causadas por outras, podem também ser feitas pela
alma de Cristo, enquanto instrumento do Verbo. Não, contudo, pela sua natureza e virtude próprias;
pois, certas dessas mudanças não estão ao alcance da alma, nem na ordem natural nem na da graça.

RESPOSTA À TERCEIRA. — Como dissemos na Segunda Parte, a graça das virtudes ou dos milagres é
dada à alma de um determinado santo, não como virtude própria dele, mas, por virtude, divina é que
poderá operar tais milagres. Ora, essa graça excelentíssima foi dada à alma de Cristo: de modo que não
somente ele fizesse milagres, mas ainda que a transfundisse nos outros. Donde o dizer a Escritura:
Convocados os seus doze discípulos. deu-lhes Jesus poder sobre os espíritos imundos, para os expelirem
e para curarem todas as doenças e todas as enfermidades.

## Art. 3 — Se a alma de Cristo tinha a onipotência em relação ao próprio corpo.
O terceiro discute-se assim. — Parece que a alma de Cristo tinha a onipotência em relação ao próprio
corpo.
1 — Pois, diz Dasmaceno, todos os sofrimentos naturais Cristo os padeceu voluntariamente; assim, teve
fome, sêde, temor e morreu porque assim o quis, etc. Ora, é considerado onipotente por ter feito tudo
quanto quis. Logo, parece que a alma de Cristo tinha a onipotência em relação às operações naturais do
seu próprio corpo.

2. Demais. — Em Cristo a natureza humana era mais perfeita que em Adão. Ora, este, pela justiça
original que tinha no estado de inocência, trazia o corpo absolutamente sujeito à alma a ponto de nada
se operar no corpo contra a vontade da alma. Logo, com maior razão, a alma de Cristo era onipotente
em relação ao seu corpo.

3. Demais. — O corpo naturalmente sofre alterações por efeito da imaginação da alma; e tanto mais
quanto mais a alma tiver a imaginação viva, como se estabeleceu na Primeira Parte. Ora, a alma de
Cristo tinha uma virtude perfeitíssima, tanto em relação à imaginação como às outras potências, Logo, a
alma de Cristo era onipotente em relação ao próprio corpo.
Mas, em contrario, o Apóstolo diz que foi conveniente se fizesse ele em tudo semelhante a seus irmãos;
e sobretudo no atinente à condição da natureza humana. Ora, é da condição da natureza humana não
estarem sujeitos ao império da razão ou da vontade a saúde do corpo, a sua nutrição e o seu
crescimento; porque o natural está sujeito só a Deus; autor da natureza. Logo, nem em Cristo essas
unções naturais estavam sujeitas à razão e à vontade. E, portanto, a alma de Cristo não era onipotente
em relação ao próprio corpo.

SOLUÇÃO. — Como dissemos, a alma de Cristo pode ser considerada a dupla luz. — Primeiro, na sua
virtude e natureza próprias. E então, assim como não podia mudar o curso e a ordem natural dos corpos
externos, não podia também subtrair o próprio corpo à sua disposição natural; pois, a alma de Cristo, na
sua natureza própria, é determinadamente proporcionada ao seu corpo. — A outra luz podemos
considerar a alma de Cristo enquanto instrumento unido pessoalmente ao Verbo de Deus. E então
estava totalmente sujeito ao seu poder a disposição do próprio corpo. Mas, como a virtude da ação
propriamente não é atribuída ao instrumento, mas ao agente principal, tal onipotência é atribuída antes
ao Verbo mesmo de Deus que à alma de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras de Damasceno se devem entender quanto à
vontade divina de Cristo. Pois, como ele próprio o disse no capítulo 'antecedente, por beneplácito da
vontade divina fora permitido à carne sofrer e realizar as suas operações próprias.

RESPOSTA À SEGUNDA. — O ter a alma do homem o poder de mudar o próprio corpo para qualquer
forma não pertencia à justiça original de Adão, no estado de inocência; mas só, conservá-lo sem
nenhum sofrimento. Ora, também essa virtude Cristo podia ter assumido, se tivesse querido. Mas sendo
três os estados do homem — o da inocência, o da culpa e o da glória — assim como do estado da glória
assumiu a compreensão e do de inocência, a imunidade do pecado, assim também do estado da culpa
assumiu a necessidade de sujeitar-se às penalidades desta vida como depois diremos.

RESPOSTA À TERCEIRA. — A imaginação, sendo viva, naturalmente o corpo lhe obedece, de certo modo.
Por exemplo, no caso da queda de uma trave pendurada no alto; pois, é natural à imaginação ser o
princípio do movimento local, como diz Aristóteles. Semelhantemente, também quanto à alteração
proveniente do calor e do frio e às suas consequências. Pois, a imaginação naturalmente provoca as
paixões da alma, que movem o coração; e assim, pela comoção dos espíritos, todo o corpo fica alterado.
Mas as outras disposições corporais, não dependentes naturalmente da imaginação, por ela não são
alteradas, por mais viva que seja; por exemplo, a figura das mãos, dos pés ou coisas semelhantes.

## Art. 4 — Se a alma de Cristo tinha a onipotência quanto à execução da própria vontade.
O quarto discute-se assim. — Parece que a alma de Cristo não tinha a onipotência quanto à execução
da própria vontade.

1. — Pois, diz o Evangelho que Jesus, tendo entrado numa casa, quis que ninguém o soubesse mas não
pôde ocultar-se. Logo, não podia em tudo executar o propósito da sua vontade.

2. Demais. — Uma ordem é manifestação da vontade, como na Primeira Parte se disse. Ora, o Senhor
mandou fazer certas coisas, cujo contrário veio a acontecer. Assim refere o Evangelho, que aos cegos
depois de terem recuperado a vista, Jesus os ameaçou dizendo: Vede lá que o não saiba alguém. Mas
eles, saindo dali, divulgaram por toda aquela terra o seu nome. Logo, não podia em tudo executar o
propósito da sua vontade.

3. Demais. — O que podemos fazer por nós mesmos não o pedimos a outrem. Ora, o Senhor pediu ao
Pai, na sua oração, o que queria fosse feito como se lê no Evangelho: Saiu ao monte a orar e passou toda
a noite em oração a Deus. Logo, não podia executar em tudo o propósito da sua vontade.
Mas, em contrário, diz Agostinho: É impossível não se cumprir a vontade do Salvador; nem pode querer
o que sabe não se dever fazer.

SOLUÇÃO. — De dois modos pode a alma de Cristo querer alguma coisa. — Primeiro, como devendo
realizá-la ela própria. E então, devemos dizer que pôde tudo quanto quis. Pois, não lhe conviria à
sapiência quisesse fazer por si o que não estava ao alcance do seu poder. — De outro modo, podia
querer uma coisa como devendo ser feita pela virtude divina como a ressurreição do seu próprio corpo
e outras obras milagrosas semelhantes. As quais não podia por virtude própria, mas sim enquanto
instrumento da divindade, como se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz Agostinho; devemos afirmar que Cristo quis o que foi
feito. Pois, é mister advertirmos que tais coisas se realizavam nos confins da gentilidade, aos quais ainda
não era tempo de pregar. Embora fosse inveja não aceitar os que espontaneamente se apresentavam a
receber a fé. Por isso não quis ser anunciado pelos seus discípulos; mas, sim ser procurado pelos
gentios. E assim se fez. — Ou podemos dizer que essa vontade de Cristo não se referia ao que por ela se
devia fazer, mas ao que devia ser feito por outros e que não dependia da sua vontade humana. Por isso
na Epístola do Papa Ágato, recebida pelo Sexto Sínodo, se lê: Pois então ele, criador e Redentor de tudo,
não podia viver escondido na terra? Não, se o entendemos em relação à sua vontade humana, que se
dignou assumir temporalmente.

RESPOSTA À SEGUNDA. — Como diz Gregório, mandando calarem-se as suas virtudes o Senhor deu-se
como exemplo aos servos que o seguiam, para também eles terem o desejo de ocultar as suas, embora
manifestassem contra a vontade deles os outros, para aproveitarem do seu exemplo. Assim, pois, a sua
ordem manifestava-lhe a vontade de fugir à glória humana, segundo aquilo do Evangelho: Eu não busco
a minha glória. Mas, absolutamente falando, queria, sobretudo pela vontade divina, se publicasse o
milagre feito, para utilidade dos outros.

RESPOSTA À TERCEIRA. — Cristo orava tanto para a realização do que devia ser feito por vontade
divina, como para a do que havia de fazer pela sua vontade humana. Pois, a virtude e a operação da
alma de Cristo dependiam de Deus, que é quem obra em nós o querer e o fazer, como diz o Apóstolo.