# Questão 36: Da manifestação de Cristo nascido
Em seguida devemos tratar da manifestação de Cristo nascido.
E nesta questão discutem-se oito artigos:

## Art. 1 — Se a natividade de Cristo devia ser manifesta a todos.
O primeiro discute-se assim. — Parece que a natividade de Cristo devia ser manifesta a todos.

1. — Pois, uma promessa deve ser cumprida. Ora, da promessa do advento de Cristo diz a Escritura:
Deus virá manifestamente. Ora, veio pela natividade da carne. Logo, parece que a sua natividade devia
ser manifesta a todos.

2. Demais. — O Apóstolo diz: Jesus Cristo veio a este mundo para salvar os pecadores. Ora, isso só se dá
por se lhes manifestar a graça de Cristo, segundo ainda o Apóstolo: A Graça de Deus nosso Salvador
apareceu a todos os homens, ensinando-nos que, renunciando à impiedade e às paixões mundanas,
vivamos neste século sóbria, justa e piamente. Logo, parece que a natividade de Cristo devia ser
manifesta a todos.

3. Demais. — Deus é, por excelência, inclinado à compaixão, segundo a Escritura: As suas misericórdias
são sobre todas as suas obras. Ora, no seu segundo advento, quando julgar as justiças, virá de um modo
manifesto a todos, segundo o dito do Evangelho: Como um relâmpago sai do oriente e se mostra até o
ocidente, assim há de ser também a vida do Filho do Homem. Logo, com muito maior razão, a sua
primeira ainda, quando nasceu neste mundo, segundo a carne, devia ser manifesta a todos.
Mas, em contrário, a Escritura: Tu verdadeiramente és um Deus escondido, o Deus d'Israel, o salvador. E
noutro lugar: O seu rosto se achava como encoberto e parecia desprezível.

SOLUÇÃO. — A natividade de Cristo não devia ser, em geral, manifesta a todos. - Primeiro, porque teria
assim ficado impedida a redenção humana, que havia de realizar-se pela sua cruz; pois, como diz o
Apóstolo, se eles a conheceram, não crucificaram nunca ao Senhor da glória. - Segundo, por que ficaria
diminuído o mérito da fé, pela qual viera justificar os homens, segundo o Apóstolo: A justiça de Deus é
infundida pela fé de Jesus Cristo. Se, pois, por indícios manifestos, a natividade de Cristo fosse, na
ocasião do seu nascimento, manifesta a todos, desapareceria a razão de ser da fé, que é um argumento
das coisas que não aparecem. - Terceiro, porque lançaria dúvidas sobre a verdade da sua humanidade.
Por isso diz Agostinho: Se não mudasse de idade, passando da infância para a juventude: se não tomasse
nenhum alimento nem o repouso do sono, não confirmaria assim uma opinião errônea e não daria a
crer que de nenhum modo assumiu verdadeiramente a humanidade? E depois de ter feito tantos
milagres iria privar-nos das riquezas da sua misericórdia?

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lugar citado se entende do advento de Cristo no dia do
juízo, como o expõe a Glosa a esse lugar.

RESPOSTA À SEGUNDA. — Todos os homens deviam, para se salvarem, ser instruídos na graça de Deus
Salvador. Não porém logo, no princípio da sua natividade, mas num tempo mais avançado, quando
obrou a salvação no meio da terra. Por isso, depois da sua paixão e ressurreição, disse aos seus
discípulos: Ide e ensinai a todas as gentes.

RESPOSTA À TERCEIRA. — O juízo implica no conhecimento da autoridade do juiz; e por isso é
necessário seja manifesto o advento de Cristo quando vier julgar. Ora, o seu primeiro advento foi para a
salvação de todos, que se operam pela fé; e esta tem por argumento as coisas que não aparecem. Por
isso o primeiro advento de Cristo devia ser oculto.

## Art. 2 — Se a natividade de Cristo devia manifestar-se a certos.
O segundo discute-se assim. — Parece que a natividade de Cristo a ninguém devia manifestar-se.

1. — Pois, como se disse, convinha à salvação humana, que c primeiro advento de Cristo fosse oculto.
Ora, Cristo veio salvar a todos segundo àquilo do Apóstolo: Que é o Salvador de todos os homens,
Principalmente dos fiéis. Logo, a natividade de Cristo a ninguém devia manifestar-se.

2. Demais. — Antes da natividade de Cristo, foi revelado que haveria ela de realizar-se, à Santa Virgem e
a José. Logo, uma vez Cristo nascido, não era necessário que a sua natividade fosse revelada a outros.

3. Demais. — Nenhum homem prudente manifesta o que pode ser causa de turbação e de detrimento a
outrem. Ora, da manifestação da natividade de Cristo resultou uma turbação, conforme o refere o
Evangelho: O rei Herodes ouvindo isto, isto é, a notícia da natividade de Cristo, se turbou e toda
Jerusalém com ele. E também foi em detrimento de outros; pois, por esse motivo, Herodes mandou
matar todos os meninos que havia em Belém e em todo o seu termo, que tivessem dois anos e dai para
baixo. Logo, parece que não foi conveniente a natividade de Cristo manifestar-se a certos.
Mas, em contrário, a natividade de Cristo a ninguém aproveitaria se a todos tivesse sido oculta. Ora, a
natividade de Cristo devia ser útil; do contrário teria vindo a este mundo em vão. Logo, parece que a
natividade de Cristo devia manifestar-se a certos.

SOLUÇÃO. — Como diz o Apóstolo, as causas de Deus são ordenadas. Ora, a ordem da sabedoria divina
exige que os dons de Deus e os arcanos dessa mesma sabedoria não os recebam todos igualmente, mas
sim, uns, imediatamente e, mediante esses, outros. Por isso, diz a Escritura, referindo-se ao mistério da
ressurreição: Deus quis que se manifestasse Cristo ressurrecto não a todo o povo, mas às testemunhas
que Deus havia ordenado antes. Por isso, o mesmo devia dar-se com a sua natividade, de modo que
Cristo não se manifestasse a todos, mas só a certos, que transmitissem a outros o conhecimento dela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como seria em detrimento da salvação humana se
a natividade de Deus tivesse sido conhecida de todos os homens, assim também o teria sido se ninguém
a conhecesse. Pois, de ambos os modos ficaria prejudicada a fé: tanto por ser o seu objeto totalmente
manifesto, como por não ser conhecido de ninguém, de quem os demais pudessem ouvi-la; porque a fé
é pelo ouvido, na expressão do Apóstolo.

RESPOSTA À SEGUNDA. — Maria e José deviam ser instruídos sobre a natividade de Cristo, já antes de
ele ter nascido, porque a eles lhes competia tributar-lhe a veneração devida, quando ainda no ventre
materno, e servir-lhe quando houvesse de nascer. Mas teria sido suspeito o testemunho deles, sobre a
magnificência de Cristo, por provir de pessoa da família. Por isso era necessário fosse manifesto aos
estranhos o mistério, pois o testemunho desses não poderia ser suspeito.

RESPOSTA À TERCEIRA. — Essa própria turbação, subsequente, manifestada pela natividade de Cristo,
convinha-lhe à natividade. — Primeiro, porque manifestou a dignidade celeste de Cristo. Por isso diz
Gregório: Nascido o rei do céu, turba-se o rei da terra; porque quando se manifesta a celsitude do
celeste, abatem-se de todo as grandezas terrenas. — Segundo, porque figurava o poder judiciário de
Cristo. Por isso diz Agostinho: Que será o tribunal do juiz, quando o berço de uma criança enchia de
terror a soberba dos reis? — Terceiro, porque figurava a destruição do reino do diabo. Assim, diz Leão
Papa: Não era tanto Herodes que se enchia de turbação, quanto o diabo, em Herodes. Pois, Herodes
tinha a Cristo em conta de mortal, ao passo que o diabo lhe conhecia a divindade. E ambos esses reis
temiam o sucessor: o diabo — o rei celeste; e Herodes — o terreno. Mas sem razão, porque Cristo não
veio reinar na terra, como o diz Leão Papa, dirigindo-se a Herodes: Cristo não vem tomar o teu reinado;
nem o Senhor do mundo se contenta com a mesquinhez do poder do teu cetro. — Quanto a ficarem
turbados os Judeus em vez de, ao contrário, deverem alegrar-se, isso se compreende. Ou era porque,
como diz Crisóstomo, sendo iníquos, não podiam regozijar-se com o advento de Cristo; ou porque
queriam agradar a Herodes a quem temiam, pois, o povo é inclinado a agradar, mais do que o deve, ao
tirano, cujas crueldades suporta. — Quanto aos inocentes degolados por Herodes, isso não lhes
redundou em mal, mas ao contrário, em glória. Assim, diz Agostinho: Longe de nós pensar que Cristo,
tendo vindo salvar os homens, nenhuma recompensa deu aos que foram imolados por ele; ele que,
pendente da cruz, orava pelos seus crucificadores.

## Art. 3 — Se foram bem escolhidos aqueles a quem foi manifestada a natividade de Cristo.
O terceiro discute-se assim. — Parece que não foram bem escolhidos aqueles a quem foi manifestada
a natividade de Cristo.

1. — Pois, o Senhor ordenou aos discípulos: Não ireis caminho de gentios, i. é, para que fosse
manifestado aos Judeus antes de o ser aos gentios. Logo, parece, com maioria de razão, que a
natividade de Cristo não devia, desde o princípio, ser revelada aos gentios, que vieram do Oriente, como
se lê no Evangelho.

2. Demais — A manifestação da verdade divina deve ser feita sobretudo aos amigos de Deus, segundo
àquilo da Escritura: Não vos encaminheis aos mágicos, nem procureis saber causa alguma dos adivinhos.
Logo, a natividade de Cristo não devia ser manifestada aos Magos.

3. Demais. — Cristo veio libertar todo o mundo do poder do diabo; donde o dizer a Escritura: Desde o
nascente do sol até o poente é o meu nome grande entre as gentes. Logo, não só aos habitantes do
Oriente devia manifestar-se a natividade de Cristo, mas a certos outros, no resto do mundo.

4. Demais — Todos os sacramentos da lei antiga foram a figura de Cristo, Ora, os sacramentos da lei
antiga eram dispensados pelo ministério dos sacerdotes da lei. Logo, parece que a natividade de Cristo
devia manifestar-se, antes, aos sacerdotes no templo, que aos pastores no campo.

5. Demais - Cristo nasceu da Virgem Mãe e em forma de criancinha, Logo, fora mais conveniente Cristo
ter-se manifestado aos jovens e às virgens, que aos velhos e aos casados ou viúvos, como a Simeão e a
Ana.
Mas, em contrário, o Evangelho: Eu sei os que tenho escolhido. Ora, a sabedoria de Deus faz bem tudo o
que faz. Logo, foram bem escolhidos aqueles a quem se manifestou a natividade de Cristo.

SOLUÇÃO. — A salvação que Cristo vinha trazer era a da totalidade dos homens, sem diferenças,
conforme àquilo do Apóstolo: Em Cristo não há diferença de homem e de mulher, de gentio e de judeu,
de servo e de livre, como não há nenhuma outra diferença semelhante. E a fim de o anunciar, a
natividade de Cristo foi manifestada aos homens de todas as condições. Pois, como diz Agostinho, os
pastores eram Israelitas, os Magos gentios; aqueles estavam próximos, estes afastados; tanto uns como
outros, porém, vieram apoiar-se na pedra angular. Mas ainda havia entre eles outra diversidade; pois,
ao passo que os Magos eram sábios e poderosos, simples e humildes eram os pastores. E também
manifestou-se aos justos, como Simeão e Ana, e aos pecadores, como os Magos. E enfim, aos homens e
às mulheres como Ana. E isso tudo mostra que Cristo não privou da sua salvação nenhuma condição
humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa manifestação da natividade de Cristo foi uma como
prelibação da manifestação plena, que havia de realizar-se. E assim como na segunda manifestação,
primeiro foi anunciada a graça de Cristo aos Judeus, pelo próprio Cristo e pelos seus Apóstolos, e depois
aos gentios, assim também com Cristo vieram ter primeiro os pastores, as primícias dos Judeus, como
habitando mais perto, e depois vieram de regiões remotas os Magos, que foram as primícias das gentes,
na expressão de Agostinho.

RESPOSTA À SEGUNDA. — Diz Agostinho: Assim como domina a ignorância na rusticidade dos pastores,
assim a impiedade nos sacrilégios dos magos. A uns e outros, porém, deu abrigo aquela pedra angular,
como quem veio escolher os ignorantes para confundir os sábios, e chamar, não os justos, mas o:
pecadores; de modo que os nenhum grande se intumescesse de soberba e nenhum humilde
desesperasse. — Mas certos dizem, que esses Magos não eram maléficos, senão astrólogos sábios, que
recebem aquela denominação, entre os Persas e os Caldeus.

RESPOSTA À TERCEIRA. — Como diz Crisóstomo, do Oriente vieram os Magos, porque, donde nasce o
dia, daí começasse a irradiar a fé, ela - a luz das almas. - Ou, porque todos os que vêm a Cristo, dele e
por ele vêm, donde o dizer a Escritura: Eis aqui o homem, que tem por nome o Oriente. — Mas, diz a
Escritura que os Magos vieram do Oriente, ou por terem partido dos últimos confins dele, segundo uns;
ou de certas partes vizinhas da Judéia situadas porem ao Oriente da região dos Judeus. — É contudo
crível, que também nas outras partes do mundo aparecessem uns indícios da natividade de Cristo;
assim, em Roma, correu óleo, e na Espanha surgiram três sóis, aos poucos confundidos em um só.

RESPOSTA À QUARTA. — Como diz Crisóstomo, o Anjo que revelou a natividade, não foi a Jerusalém,
não procurou Escribas nem Fariseus, cheios de corrupção e ralados de inveja. Ao contrário, os pastores
eram retos e viviam no espírito dos Patriarcas e de Moisés. — E além disso esses pastores significavam
os Doutores da Igreja, a quem Cristo revelou os seus mistérios, que permaneceram ocultos aos Judeus.

RESPOSTA À QUINTA. — Como diz Ambrósio, a geração do Senhor devia ser testemunhada não só pelos
pastores, mas também pelos anciãos e pelos justos. E também por ser esse testemunho, mais digno de
crédito, pela santidade de tais personagens.

## Art. 4 — Se Cristo devia por si mesmo manifestar a sua natividade.
O quarto discute-se assim. — Parece que Cristo devia manifestar por si mesmo a sua natividade.

1. — Pois, a que é causa, por si mesma é mais principal que a causa dependente de outra, como diz
Aristóteles. Ora, Cristo manifestou por outros a sua natividade, a saber, pelos pastores e pelos anjos, e
aos Magos pela estrela. Logo, com maior razão, devia manifestar por si mesmo a sua natividade.

2. Demais. — A Escritura diz: Se a sabedoria se conserva escondida e o tesouro não está visível, que
utilidade haverá em ambas estas coisas? Ora, Cristo teve desde o princípio da sua concepção
plenamente o tesouro da sabedoria e da graça. Logo, se não manifestasse essa plenitude por obras e
palavras, em vão lhe teria sido dado a sabedoria e a graça. Ora, tal é inadmissível, porque Deus e a
natureza nada jazem em vão, como diz Aristóteles.

3. Demais. — No livro, Da infância do Salvador se lê, que Cristo na sua puerícia fez muitos milagres. E
assim parece que manifestou por si mesmo a sua natividade.
Mas, em contrário, Leão Papa diz que os Magos encontraram o menino Jesus, em nada diferente da
generalidade da infância humana. Ora, as outras crianças não se manifestam a si mesmas. Logo,
também não convinha que Cristo por si mesmo manifestasse a sua natividade.

SOLUÇÃO. — A natividade de Cristo se ordenava à salvação humana, e esta se realiza pela fé. Ora, a fé
salvadora confessa a divindade e a humanidade de Cristo. Por onde, era necessário manifestar-se a
natividade de Cristo, a fim de que a demonstração da sua divindade não prejudicasse à fé na sua
humanidade. Ora, isso se fez por ter Cristo manifestado em si mesmo a semelhança da fraqueza
humana, ao mesmo tempo que pelas criaturas de Deus mostrou, na sua pessoa, o poder da divindade.
Por onde, Cristo não manifestou por si mesmo a sua natividade, mas por meio de certas outras
criaturas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na via da geração e do movimento é necessário partir
do imperfeito para chegar ao perfeito. Por isso Cristo primeiro manifestou-se por outras criaturas e
depois, por si mesmo, numa perfeita manifestação.

RESPOSTA À SEGUNDA. — Embora uma sabedoria oculta seja inútil, contudo não deve a sabedoria
manifestar-se a si mesma em qualquer tempo, mas no tempo oportuno. Assim, diz a Escritura: Suponha-
se que a sabedoria se conserva escondida e que o tesouro não está visível, que utilidade haverá em
ambas estas coisas? Por onde, a sabedoria dada a Cristo não foi inútil, porque se manifestou em tempo
oportuno. E o mesmo ter-se escondido no tempo conveniente era sinal de sabedoria.

RESPOSTA À TERCEIRA. — O livro Da infância do Salvador é apócrifo. E Crisóstomo diz que Cristo não fez
nenhum milagre, antes do de converter a água em vinho, segundo àquilo da Escritura: Por este milagre
deu Jesus princípio aos seus. — Pois, se já desde os seus primeiros anos tivesse feito milagres, não
teriam os Israelitas precisado de ninguém que o manifestasse. E contudo João Batista diz: Por isso eu
vim batizar em água, para ele ser conhecido em Israel. E era conveniente que não começasse a fazer
milagres desde a sua primeira idade. Pois, haveriam de pensar que se tinha encarnado figuradamente; e
antes do tempo oportuno tê-lo-iam crucificado, consumidos de inveja.

## Art. 5 — Se a natividade de Cristo devia manifestar-se pelos anjos e pela estrela.
O quinto discute-se assim. — Parece que a natividade de Cristo não devia manifestar-se pelos anjos
nem pela estrela.

1. — Pois, os anjos são substâncias espirituais, segundo a Escritura: Que faz os seus anjos espíritos. Ora,
a natividade de Cristo era segundo a carne, e não segundo a sua substância espiritual. Logo, não devia
ser manifestada pelos anjos.

2. Demais. — Maior é a afinidade dos justos com os anjos do que com quaisquer outros, segundo a
Escritura: O anjo do Senhor andará à roda dos que o temem e os livrará. Ora aos justos Simeão e Ana a
natividade de Cristo não se manifestou pelos anjos. Logo, nem aos pastores devia ter-se manifestado
pelos anjos. Item. - Parece que também aos Magos não devia ter-se manifestado pela estrela.

3. — Pois, o fato de o ter seria ocasião de engano para os que pensam que os astros influem no
nascimento dos homens. Ora, aos homens se lhes devem poupar as ocasiões de pecar. Logo, não era
conveniente que a natividade de Cristo fosse manifestada por uma estrela.

4. Demais. — Um sinal há de ser segura manifestação de uma realidade determinada. Ora, unia estrela
não é sinal certo da natividade. Logo, inconveniente era a natividade de Cristo manifestar-se por uma
estrela.
Mas, em contrário, a Escritura: As obras de Deus são perfeitas. Ora, a referida manifestação foi obra
divina. Logo, realizou-se pelos sinais convenientes.

SOLUÇÃO. — Assim como a demonstração silogística nós a fazemos partindo do que nos é mais
conhecido, assim o que se nos manifesta por sinais deve apoiar-se em sinais, que nos sejam mais
familiares. Ora, é claro que aos varões justos é familiar e habitual serem ensinados pela inspiração
interna do Espírito Santo, sem manifestação de sinais sensíveis, ou seja, pelo espírito de profecia. Ao
contrário, os dados às causas corpóreas são conduzidos ao inteligível pelo sensível. Ora, os Judeus
estavam habituados a receber as determinações divinas por ministério dos anjos, mediante os quais
também receberam a lei, segundo a Escritura: Recebestes a lei por ministério dos anjos. Ao passo que os
gentios, e sobretudo os astrólogos, estavam habituados a observar o curso dos astros. Por isso aos
justos Simeão e Ana, manifestou-se a natividade de Cristo por inspiração interior do Espírito Santo,
segundo àquilo do Evangelho: Havia recebido resposta do Espírito santo, que ele não veria a morte sem
ver primeiro ao Cristo do Senhor. Mas aos pastores e aos Magos, como dados as causas materiais, a
natividade de Cristo manifestou-se por aparições visíveis. E como a sua um sinal. E assim como o
Senhor, quando lá falava, o anunciaram, aos gentios, pregadores, por meio da palavra, assim, enquanto
ainda não falava foi anunciado pelos elementos mudos. Mas Agostinho dá ainda a razão seguinte: A
Abraão, diz, foi-lhe prometida uma sucessão inumerável, que devia ser gerada, não por via seminal, mas
pela fecundidade da fé. Por isso foi comparada à multidão das estrelas, para que fosse esperada uma
progênie celeste. E eis porque os gentios designados pelas estrelas, são advertidos, pelo nascimento de
um novo astro, a se darem a Cristo, que os tornará filhos de Abraão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Precisa de manifestação o que em si mesmo é oculto,
mas não o que já por si é manifesto. Ora, ao passo que o corpo de Cristo se tornou manifesto pela sua
natividade, a sua divindade permanecia oculta. Por isso foi convenientemente manifestada a sua
natividade pelos anjos, que são os ministros de Deus. Donde o anjo ter aparecido resplendente de luz,
para mostrar que quem tinha nascido era o esplendor da glória paterna, no dizer do Apóstolo.

RESPOSTA À SEGUNDA. — Os justos não precisavam de nenhuma aparição visível dos anjos, mas lhes
bastava a inspiração interior do Espírito Santo, para a perfeição deles.

RESPOSTA À TERCEIRA. — A estrela, que manifestou a natividade de Cristo, não deu lugar a nenhuma
ocasião de erro. Pois, como diz Agostinho, nenhum astrólogo jamais ensinou que o destino dos homens,
ao nascerem, estivesse de tal modo dependente das estrelas, que por ocasião do nascimento de um
deles, ela abandonasse o seu curso normal, para projetar-se sobre o recém-nascido, como se deu com a
estrela que manifestou o nascimento de Cristo. O que, pois, não vinha confirmar o erro daqueles que
pensam depender a sorte dos que nascem ao curso dos astros, mas não crêem que podem eles mudar o
seu curso, para anunciar a natividade de um homem. – E semelhantemente como diz Crisóstomo, não é
a função da Astronomia saber, por meio das estrelas, quais os recém-nascidos, mas, predizer o futuro
desde, hora da natividade. Ora, os Magos não conheceram o tempo da natividade para, partindo daí,
desvendarem o futuro pelo movimento das estrelas; mas antes, ao contrário.

RESPOSTA À QUARTA. — Como refere Crisóstomo, em algumas escrituras apócrifas se lê que um certo
povo do extremo Oriente, nas margens do Oceano, possuía um escrito, com a assinatura de Set,
referindo-se à estrela, de que tratamos, e aos dons que deviam ser oferecidos ao recém-nascido. E esse
povo, esperando atentamente o momento do nascer a estrela, tendo destacado, para o saber, doze
observadores, que, em tempos determinados, subiam indefectivelmente a um monte, do Alto do qual
enfim a descobriram, deixando de aparecer como a figura de um menino e, acima, a semelhança de uma
cruz. Ou devemos dizer com um autor: Os referidos Magos seguiam a tradição de Balaão, que disse - A
estrela nascerá de Jacó. Por isso vendo eles uma estrela extraordinária entenderam ser essa. a que
Balaão profetizou que haveria de anunciar a vinda do Rei dos Judeus. Ou podemos dizer, com S.
Agostinho, por alguma advertência dos anjos, concernente à revelação, os Magos souberam que uma
estrela: havia de manifestar o nascimento de Cristo. E provàvelmente, dos bons anjos, pois, o adorarem
a Cristo já lhes redundava em benefício da salvação deles. Ou, como ensina Leão Papa, além daquela
aparição que lhes feria a visão corpórea, o raio mais refulgente da verdade enriqueceu-lhes os corações
com a iluminação da fé.

## Art. 6 — Se a natividade de Cristo foi manifestada na ordem conveniente.
O sexto discute-se assim. — Parece que a a natividade de Cristo foi manifestada numa ordem
inconveniente.

1. — Pois, a natividade de Cristo devia ser manifestada primeiro aos mais chegados a ele e que mais o
desejavam, conforme o lugar da Escritura: Ela se antecipa aos que a cobiçam, de tal sorte que se lhes
patenteia primeiro. Ora, os justos eram os mais chegados a Cristo pela fé e os que mais lhe desejavam o
advento. Por isso, diz o Evangelho, de Simeão, que era homem justo e timorato e esperava a redenção
de Israel. Logo, a natividade de Cristo devia ser manifestado primeiro a Simeão, que aos pastores ou
magos.

2. Demais. — Os Magos eram as primícias dos gentios, que haviam de crer em Cristo. Ora, primeiro, a
multidão das gentes recebe a fé e depois todo Israel há de salvar-se, como ensina o Apóstolo. Logo, a
natividade de Cristo devia manifestar-se primeiro aos Magos, que aos pastores.

3. Demais. — O Evangelho diz: Herodes mandou matar todos os meninos que havia em Belém e em todo
o seu termo, que tivessem dois anos e daí para baixo, regulando-se nisto pelo tempo que tinha
exatamente averiguado dos Magos. Donde se conclui que dois anos depois da natividade de Cristo é que
os Magos chegavam a Cristo: Logo, a natividade de Cristo foi inconvenientemente, só depois de tanto
tempo, manifestada aos gentio.
Mas em contrário, a Escritura: E ele mesmo é o que muda os tempos e os séculos. E assim, o tempo da
manifestação da natividade de Cristo foi disposto na ordem conveniente.

SOLUÇÃO. — A natividade de Cristo foi primeiro manifestada aos Pastores, no dia mesmo da natividade
de Cristo. Assim, diz o Evangelho: Naquela mesma comarca havia uns pastores que vigiavam e
revezavam entre si as vigílias da noite para guardarem o seu rebanho. E aconteceu que, depois que os
anjos se retiravam deles para o céu falavam entre si os pastores dizendo: Passemos até Belém. E foram
com grande pressa. - Em segundo lugar, os Magos vieram adorar a Cristo, no décimo terceiro dia da sua
natividade, dia em que se celebra a festa da Epifania. Assim que, se tivessem vindo depois de passado
um ano, ou ainda dois, não o teriam já encontrado em Belém, pois, como se lê no Evangelho, depois que
eles deram fim a tudo, segundo o que mandava a lei do Senhor, isto é tendo apresentado o menino
Jesus no templo, voltaram à Galileu para a sua cidade de Nazaré. — Em terceiro lugar manifestou-se aos
justos no templo, no quadragésimo dia da natividade, como se lê no Evangelho.
A razão dessa ordem é, que os Pastores significavam os Apóstolos e os outros judeus crentes, a quem
primeiro foi revelada a fé de Cristo; e entre esses não houve muitos poderosos nem muitos nobres,
segundo o Apóstolo. - Em segundo lugar a fé de Cristo chegou à plenitude das gentes, prefigurada pelos
Magos - Enfim, em terceiro, à plenitude dos judeus, prefigurada pelos justos. Por isso, no Templo dos
judeus é que Cristo se lhes manifestou.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz o Apóstolo, Israel, que seguia a lei da justiça,
não chegou à lei da justiça; ao passo que os gentios, que não seguiam a justiça, em geral preveniram os
judeus na justiça da fé. E na figura, destes, Simeão, que esperava a consolação de Israel, foi o último a
saber do nascimento de Cristo; e foi procedido pelos Magos e pelos Pastores, que não esperavam essa
natividade tão solicitamente.

RESPOSTA À SEGUNDA. — Embora a plenitude dos gentios recebesse a fé primeiro que a plenitude dos
judeus, contudo as primícias dos judeus preveniram na fé as primícias dos gentios. Por isso aos Pastores
foí-Ihes manifestada a natividade de Cristo, antes de o ser aos Magos.

RESPOSTA À TERCEIRA. — Há duas opiniões a respeito da estrela que apareceu aos Magos. - Crisóstomo
e Agostinho dizem que a estrela apareceu aos Magos dois anos antes da natividade de Cristo. E só
então, começando a meditar na viagem e a preparar-se para ela, das remotíssimas partes do Oriente
chegaram até Cristo no décimo terceiro dia da sua natividade. E por isso Herodes, logo depois da partida
dos Magos, vendo-se iludido por eles, mandou matar os meninos que tivessem dois anos e daí para
baixo, estando na dúvida se Cristo nasceu quando apareceu a estrela, conforme ouvira dos Magos. -
Mas outros dizem, que a estrela apareceu só quando Cristo nasceu; e desde então os Magos, ao verem a
estrela pondo-se a caminho, realizaram a longuíssima jornada em treze dias, em parte ajudados do
poder divino, e em parte pela velocidade dos dromedários. E isto, digo, no caso em que tivessem vindo
das extremas partes do Oriente. Mas outros são de opinião que eles vieram de uma região próxima,
donde era Balaão, de cuja doutrina eram os sucessores. E só o Evangelho diz que vieram do Oriente, é
que essa terra está na parte oriental da terra dos judeus. E então, Herodes mandou matar os meninos,
não logo depois da partida dos Magos, mas depois de um biênio. E isso, ou porque, como se diz, tendo
sido acusado, foi durante esse tempo a Roma; ou porque, agitado pelo terror de certos perigos, desistiu
por enquanto da idéia de matar o menino. Ou por ter sido levado a crer, que os Magos, enganados pela
visão falaz da estrela, tiveram vergonha de voltarem a ele, depois de não terem encontrado o recém-
nascido que procuravam, como opina Agostinho. E por isso, não só mandou matar os meninos de dois
anos, mas ainda daí para baixo; porque, como diz Agostinho, temia que o menino, a quem as estrelas
serviam, transformasse o seu corpo no de idade superior ou inferior.

## Art. 7 — Se a estrela, que apareceu aos Magos era uma das estrelas do céu.
O sétimo discute-se assim. — Parece que a estrela que apareceu aos Magos, era uma das estrelas do
céu.

1. — Pois, diz Agostinho: Enquanto um Deus pende dos peitos maternos e sofre ser envolvido em panos
vis, de repente brilhou no céu uma nova estrela. Logo, foi uma estrela do céu a que apareceu aos
Magos.

2. — Demais. — Agostinho diz: Aos pastores, os anjos; aos Magos, uma estrela revelou o Cristo. A ambos
fala a língua dos céus por ter se calado a língua dos Profetas. Ora, os anjos que apareceram aos Pastores
foram verdadeiramente anjos do céu. Logo, também a estrela dos Magos foi verdadeiramente uma
estrela do céu.

3. Demais. — As estrelas que aparecem, não no céu, mas no ar, chamam-se cometas; e essas não
anunciam natividade dos reis, mas antes são o prenúncio da morte deles. Ora, a referida estrela
anunciava a natividade do Rei; donde o perguntarem os Magos: Onde está orei dos Judeus, que é
nascido? Porque nós vimos no Oriente a sua estrela.
Mas, em contrário, Agostinho diz: Essa estrela não era daquelas que, desde o início do mundo, guardam
a lei do seu curso que o Criador lhes traçou; mas, uma nova estrela que apareceu por ocasião do parto
da Virgem.

SOLUÇÃO. — Como diz Crisóstomo, por muitas razões é manifesto que a estrela aparecida aos Magos
não foi nenhuma das estrelas do céu. Primeiro, porque nenhuma dessas estrelas descreve tal trajetória.
E, essa dirigia-se do setrentrião para o meio dia; pois, a Judéia está ao sul da Pérsia, donde os Magos
vieram. - Segundo, por causa do tempo. Pois, aparecia não só de noite, mas também ao meio dia. O que
não o podem as estrelas e nem mesmo a lua. - Terceiro, porque ora aparecia e ora se ocultava. Assim,
quando entraram em Jerusalém, ocultou-se; e depois, quando deixaram Herodes, mostrou-se de novo. -
Quarto, porque não tinha movimento contínuo; mas, quando os Magos deviam caminhar, caminhava; e
quando deviam parar, parava como acontecia com a coluna de nuvem no deserto. - Quinto, porque
indicou o lugar do parto da Virgem, não permanecendo no alto, mas descendo até ele. Assim, diz o
Evangelho: A estrela que tinham visto no Oriente lhes apareceu, indo diante deles, até que, chegando,
parou sobre onde estava o menino. Donde se conclui que as palavras dos Magos - Vimos no Oriente a
sua estrela - não se devem entender como significando, que a eles, vivendo no Oriente, apareceu-lhes
uma estrela na terra de Judá; mas, que o viram no Oriente, e ela os precedeu até a Judéia; embora
certos ponham isto em dúvida. Pois, não poderia indicar distintamente uma casa, se não estivesse
vizinha da terra. Ora, como o Santo Doutor acrescenta, isso não é próprio de nenhuma estrela, mas, de
algum poder racional. Donde se conclui que essa estrela era um poder invisível transformado em tal
aparição.
Por isso, certos opinam que assim como o Espírito Santo desceu sobre o Senhor batizado em forma de
pomba, assim apareceu aos Magos em forma de estrela. - Mas outros pensam que o Anjo que apareceu
aos Pastores em forma humana apareceu aos Magos em forma de estrela. - Parece mais provável porém
que essa foi estrela criada de novo, não no céu, mas no ar vizinho à terra, que se movia segundo a
vontade divina. Donde o diz Leão Papa: Aos três Magos apareceu na região do Oriente uma estrela de
nova claridade, que, mais refulgente e mais bela que as outras, atraía a si os olhos e os pensamentos dos
que a contemplavam; de modo que logo advertiam não ser vão o que tão insólito lhes parecia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O céu, na Sagrada Escritura, é às vezes chamado ar
como naquele lugar: As aves do céu e os peixes do mar.

RESPOSTA À SEGUNDA. — Os anjos do céu tem por ofício descer até nós, mandados em algum
ministério. Ora, as estrelas do céu não mudam de lugar. Logo, a comparação não colhe.

RESPOSTA À TERCEIRA. — Assim como a estrela dos Magos não seguiu o curso das estrelas do céu,
assim também os cometas, que não aparecem de dia, não mudam o seu curso habitual. - E contudo essa
estrela desempenhava de certo modo a função dos cometas. Pois, o reino celeste de Cristo esmigalhará
e consumirará a todos os reinos e ele mesmo subsistirá para sempre no dizer da Escritura.

## Art. 8 — Se era conveniente que os Magos viessem adorar e venerar a Cristo.
O oitavo discute-se assim. — Parece não era conveniente os Magos terem vindo a adorar e venerar a
Cristo.

1. — Pois aos reis devem-lhes reverência os súbditos. Ora, os Magos não pertenciam ao reino dos
Judeus, Logo, quando souberam, pela vista da estrela, do nascimento do Rei dos Judeus parece que não
andaram bem em ter vindo adorá-la.

2. Demais. — É estulto anunciar o nascimento de um rei enquanto ainda há outro vivo. Ora, no reino da
Judéia reinava Herodes. Logo, os Magos procederam com estultícia anunciando a natividade desse rei.

3. Demais. — Um indício celeste é mais certo que o humano. Ora, os Magos, dirigidos por um indício
celeste, vieram do Oriente para a Judéia. Logo, procederam estultamente quando pediam alem do
indício da estrela, um indício humano, ao interrogarem: Onde está o rei dos judeus, que é nascido?

4. Demais. — A oferenda de presentes e a reverência da adoração só se devem aos reis enquanto
reinam. Ora, os Magos não encontraram a Cristo refulgindo com a dignidade real. Logo, andaram mal
oferecendo-lhe presentes e reverenciando-lhe a realeza.
Mas, em contrário, a Escritura: Andaram as gentes na tua luz e os reis no esplendor do teu nascimento.
Ora, os dirigidos pela luz divina não erram. Logo, os Magos puderam, sem engano, prestar reverência a
Cristo.

SOLUÇÃO. — Como dissemos, os Magos foram as primícias dos gentios que acreditaram em Cristo. E
neles se manifestou, como um presságio, a fé e a devoção das gentes que vieram a Cristo, das mais
remotas regiões. Por onde, assim como a devoção e a fé dos gentios não estava contaminada de
nenhum erro, por inspiração do Espírito Santo, assim também devemos crer que os Magos inspirados
pelo Espírito Santo, prestaram sabiamente reverência a Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz Agostinho: Dos muitos reis dos judeus, nascidos e
mortos, a nenhum os Magos vieram procurar para adorá-la. Não era, pois, a nenhum dos reis, como
eram os dos judeus, que os Magos, habitantes de uma região longínqua, alienígenas e tão
completamente estranhos ao reino judaico não era a eles que julgavam ser devida a tão grande honra
que vinham prestar. Mas sabiam, sem a menor dúvida, que o recém-nascido era um rei tal, por cuja
adoração obteriam a salvação segundo Deus.

RESPOSTA À SEGUNDA. — A anunciação dos Magos prefigurava a constância dos gentios, que
confessaram a Cristo até a morte. Donde o dizer Crisóstomo: Considerando no Rei futuro, não temiam o
presente. Pois, ainda não viam à Cristo, e já estavam prontos a morrer por ele.

RESPOSTA À TERCEIRA. — Diz Agostinho: A estrela, que conduziu os Magos ao lugar onde o Deus
infante estava com sua mãe, podia também tê-las conduzido à cidade mesma de Belém, onde nasceu
Cristo. Contudo, escondeu-se-lhes aos olhares, até que os próprios judeus dessem testemunho da
cidade onde nasceu Cristo. E assim, confirmados por um testemunho duplo, como diz Leão Papa,
buscassem com fé mais ardente aquele que punham de manifesto o clarão da estrela e a autoridade das
profecias. E assim os Magos anunciam a natividade de Cristo e interrogam qual o lugar, crêem e
procuram, como pronunciando os que vivem na fé e desejam a visão, conforme ensina Agostinho. -
Quanto aos judeus, que lhes mostraram aos Magos o lugar da natividade de Cristo, tornaram-se
semelhantes aos fabricantes da Arca de Noé, que, proporcionando aos outros o meio de se livrarem,
pereceram eles próprios no dilúvio. Os que vieram a procura do menino viram-no e foram-se; ao passo
que os judeus, que lhes deram as informações e os instruíram ficaram no mesmo lugar, semelhantes
aqueles marcos miliários, que mostram o caminho mas não andam. - E foi também por determinação
divina que os Magos, mesmo sem avistarem então a estrela, guiados pelo senso humano, chegaram à
Jerusalém onde, na cidade real, buscaram o Rei nascido; e assim foi Jerusalém o primeiro lugar onde se
anunciou publicamente a natividade de Cristo, segundo aquilo da Escritura: De Sião sairá a lei e de
Jerusalém a palavra do Senhor. E também para que o trabalho a que se deram os Magos, vindos de tão
longe, condenasse a displicência dos judeus, que viviam tão perto.

RESPOSTA À QUARTA. — Como diz Crisóstomo, se os Magos tivessem saído à procura de um rei terreno
ficariam confundidos por terem sem causa se dado ao trabalho de uma viagem tão longa. E por isso não
o teriam adorado nem lhe oferecido presentes. Mas, porque buscavam um Rei celeste, embora nada
descobrissem nele denotador da excelência real, contudo, contentes com o só testemunho da estrela,
adoraram-no. Pois, reconhecem um Deus no homem que vem. E oferecem dois convenientes à
dignidade de Cristo: ouro, como a um grande Rei; o incenso, usado nos sacrifícios divinos, como a Deus;
e a Mirra, com que se embalsamam os corpos dos mortos, lh'o oferecem como a quem havia de morrer
pela salvação de todos. Desse modo como adverte Gregório, somos instruídos a fim de oferecermos ao
Rei nascido o ouro, símbolo da sabedoria, por cujo lume resplenderemos na sua presença; o incenso,
símbolo da oração devota, oferece-Io-emos e Deus se, pela oração frequente, soubermos exalar ao céu
o perfume da nossa vida santa; enfim, ofereceremos a mirra, símbolo da mortificação da carne, se pela
abstinência mortificarmos os vícios carnais.