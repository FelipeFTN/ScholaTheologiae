# Questão 18: Da unidade de Cristo quanto a vontade
Em seguida devemos tratar da unidade de Cristo quanto à vontade.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se Cristo tem duas vontades – uma divina e outra humana.
O primeiro discute-se assim. — Parece que Cristo não tem duas vontades – uma divina e outra
humana.

1. — Pois, a vontade é o motor primeiro e o primeiro imperante em todo sujeito dela dotado. Ora, em
Cristo o primeiro motor e o primeiro imperante era a vontade divina; porque tudo o humano em Cristo
era movido pela vontade divina. Logo, parece que em Cristo só havia uma vontade – a divina.

2. Demais. — Um instrumento não se move por vontade própria, mas pela vontade do movente. Ora, a
natureza humana era em Cristo instrumento da sua divindade, Logo, a natureza humana de Cristo não
se movia por vontade própria, mas pela divina.

3. Demais. — Em Cristo só há multiplicidade no atinente à natureza. Ora, a vontade não pertence à
natureza, pois, ao passo que o natural é necessário, o voluntário não o é. Logo, Cristo tinha uma só
vontade.

4. Demais. — Damasceno diz, que querer de certo modo não é próprio da natureza, mas da nossa
inteligência, isto é, pessoal. Ora, toda vontade é uma determinada vontade, porque não pertence a um
gênero o que não pertence a nenhuma espécie dele. Logo, toda vontade pertence à pessoa. Ora, em
Cristo houve e há uma só pessoa. Logo, Cristo tem uma só vontade.
Mas, em contrário, o Evangelho: Pai, se é do teu agrado, transfere de mim este cálix não se faça contudo
a minha vontade, senão a tua. O que Ambrósio comenta: Assim como assumiu a minha vontade,
assumiu a minha tristeza. E noutro lugar: Refere ao homem a sua vontade e ao Pai a divindade. Pois, a
vontade do homem é temporal e a vontade divina, eterna.

SOLUÇÃO. — Certos disseram que Cristo tem uma só vontade. Mas, para o afirmarem foram levados
por diversas razões. — Assim; Apolinário não admitia que Cristo tivesse uma alma racional; mas, que o
Verbo estava em lugar da alma, ou ainda, do intelecto. Ora, como a sede da vontade é a razão, no dizer
do Filósofo, resultava não ter Cristo uma vontade humana. E portanto, só tinha uma vontade. — E
semelhantemente Eutiques e todos os que admitiam como composta a natureza de Cristo eram
forçados a lhe atribuir uma só vontade. — Também Nestório, que ensinava ser a união de Deus e do
homem feita só pelo afeto e pela vontade, admitia só uma vontade em Cristo. — Depois, porém,
Macário, o patriarca Antioqueno, Ciro Alexandrino, Sérgio Constantinopolitano e certos sequazes deles
atribuíam a Cristo uma só vontade, embora lhe atribuíssem duas naturezas unidas na hipóstase. Porque
diziam que a natureza humana de Cristo não tinha nunca nenhum movimento próprio, mas que só era
movida pela divindade, como se lê na Epístola Sinódica do Papa Ágato. — Por isso, no Sexto Sínodo,
celebrado. em Constantinopla, foi determinado que se devem admitir em Cristo duas vontades. Assim,
nele se lê: De acordo com o que os Profetas outrora disseram de Cristo, e com o que ele próprio nos
ensinou, e nos transmitiu o símbolo dos santos Padres, confessamos haver nele duas vontades naturais
e dois modos naturais de agir.
E era necessário dizer assim. Pois é manifesto que o Filho de Deus assumiu a natureza humana perfeita,
como demonstramos. Ora, a natureza humana completa supõe a vontade, faculdade natural dela como
o intelecto, segundo resulta do dito na Primeira Parte. Donde forçosamente devemos concluir que o
Filho de Deus assumiu a vontade humana ao mesmo tempo que a natureza humana. Ora, pela assunção
da natureza humana a natureza divina do Filho de Deus não sofreu nenhum detrimento; deve portanto
ter vontade, como demonstramos na Primeira Parte. Donde necessariamente concluímos, que em Cristo
há duas vontades, a divina e a humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tudo o existente em a natureza humana de Cristo estava
sujeito ao nuto da vontade divina; mas daí se não segue que em Cristo não houvesse movimentos da
vontade próprios à natureza humana. Pois, também os pios atos de vontade dos outros santos
obedecem à vontade de Deus, que obra neles o querer e o perfazer, como diz o Apóstolo. Embora, pois,
a vontade não possa ser interiormente movida por nenhuma criatura, é porem, interiormente movida
por Deus, como dissemos na Primeira Parte. E assim também a vontade humana de Cristo obedecia à
vontade divina, segundo aquilo da Escritura: Para fazer a tua vontade, Deus meu, eu o quis. Daí o dizer
Agostinho: Quando o Filho disse ao Pai — não o que eu quero, mas o que tu queres — de que te serve
ajuntares as palavras seguintes e dizeres — mostrou verdadeiramente ter a vontade sujeita ao seu Pai
— como se nós negássemos que a vontade do homem deve estar sujeita à vontade de Deus?

RESPOSTA À SEGUNDA. — O instrumento é propriamente movido pelo agente principal; mas de modos
diversos conforme a propriedade da natureza dele, Pois o instrumento inanimado como o machado ou a
serra é movido pelo artífice pelo só movimento corpóreo; ao passo que o instrumento animado pela
alma sensível é movido pelo apetite sensitivo como o cavalo pelo cavaleiro; e enfim o instrumento
animado pela alma racional é movido pela vontade dela como pelo império do senhor é movido o
escravo a praticar um ato, cujo escravo é como um instrumento animado, no dizer do Filósofo. Assim,
pois, a natureza humana em Cristo foi o instrumento da divindade, para que fosse movido pela vontade
própria.

RESPOSTA À TERCEIRA. — O poder mesmo da vontade é natural e resulta necessariamente da natureza.
Mas, o movimento ou o ato mesmo dessa potência, também chamado vontade, é às vezes natural e
necessário, por exemplo, em respeito à felicidade; outras vezes provém do livre arbítrio da razão e não é
necessário nem natural, como resulta do dito na Segunda Parte. E contudo, também a razão em si
mesma, princípio desse movimento, é natural. E portanto, além da vontade divina é mister admitirmos
em Cristo a vontade humana não só enquanto potência natural, ou como movimento natural, mas
também como um movimento da razão.

RESPOSTA À QUARTA. — A expressão — querer de certo modo — designa um modo determinado de
querer. Ora, um modo determinado pertence à coisa mesma de que é modo. Ora, a vontade,
pertencendo à natureza, o princípio do querer de certo modo também pertence à natureza, não
absolutamente considerada mas enquanto existente numa determinada hipóstase. Por onde, também a
vontade humana de Cristo teve um certo modo determinado por ter existido na hipóstase divina, de
modo que se movia sempre ao nuto da divina vontade.

## Art. 2 — Se em Cristo havia uma vontade sensitiva, além da vontade racional.
O segundo discute-se assim. — Parece que em Cristo não havia uma vontade sensitiva além da
vontade racional.

1. — Pois, diz o Filósofo, que a vontade está na razão; ao passo que no apetite sensitivo tem sua sede o
irascível e o concupiscível. Ora, a sensibilidade significa o apetite sensitivo. Logo, em. Cristo não havia
nenhuma vontade sensitiva.

2. Demais. — Segundo Agostinho, a sensualidade é significada pela serpente. Ora, nada de serpentino
houve em Cristo; pois, teve a semelhança do animal venenoso, sem veneno, no dizer de Agostinho,
comentando aquilo da Escritura. - Como Moisés no deserto levantou a serpente. Logo, em Cristo não
havia nenhuma vontade sensitiva.

3. Demais. — A vontade resulta da natureza, como se disse. Ora, Cristo não teve senão uma natureza,
além da divina. Logo, em Cristo não houve senão uma vontade humana.
Mas, em contrário, diz Ambrósio: É minha a vontade a que chama sua, porque, como homem, assumiu a
minha tristeza. E isso significa que a tristeza respeita à vontade humana de Cristo. Ora, a tristeza diz
respeito à sensibilidade, como se estabeleceu na Segunda Parte. Logo, parece que houve em Cristo uma
vontade sensitiva, além da racional.

SOLUÇÃO. — Como dissemos, o Filho de Deus assumiu — natureza humana com todas as perfeições
que ela encerra., Ora, a natureza humana implica também a animal, como na especie se inclui o gênero.
Por onde e necessariamente, o Filho de Deus assumiu, com a natureza humana, também o pertencente
à perfeição da natureza animal. O que inclui o apetite sensitivo, chamado sensualidade. Donde devemos
concluir, que houve em Cristo o apetite sensitivo ou sensualidade. Devemos porém saber que a
sensualidade ou o apetite sensível, enquanto por natureza obedece à razão, chama-se racional por
participação, como está claro no Filósofo. E, estando a vontade na razão, como se disse, pelo mesmo
motivo devemos dizer, que a sensualidade é vontade por participação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe, quanto à vontade essencialmente dita
que só existe na parte intelectiva. Ora, a vontade, como participação, pode residir na parte sensitiva,
enquanto esta obedece à razão.

RESPOSTA À SEGUNDA. — A sensualidade é significada pela serpente, não quanto à natureza da
sensualidade, que Cristo assumiu; mas, quanto à corrupção da concupiscência, que não existiu em
Cristo.

RESPOSTA À TERCEIRA. — Aquilo que existe por causa de outra coisa com esta se identifica; assim a
superfície, visível pela cor, faz com esta um só visível. Semelhantemente, porque a sensualidade não se
chama vontade senão por participar da razão, assim como Cristo só tem uma natureza humana, assim
também lhe atribuímos uma só vontade humana.

## Art. 3 — Se Cristo tinha duas vontades racionais.
O terceiro discute-se assim. — Parece que Cristo tinha duas vontades racionais.

1. — Pois, como diz Damasceno, há duas vontades no homem a natural, chamada e a racional, chamada.
Ora, Cristo na sua natureza humana tinha tudo o concernente à perfeição da natureza humana. Ora,
ambas as referidas vontades existiam em Cristo.

2. Demais. — A potência apetitiva se diversifica no homem conforme as diversidades da potência
apreensiva; e portanto, da diferença entre o sentido e o intelecto deriva para o homem a diferença
entre o sensitivo e o intelectivo. Ora, semelhantemente, quanto à apreensão no homem, há diferença
entre a razão e o intelecto, que ambos existiram em Cristo. Logo, houve nele dupla vontade — uma
intelectual e outra, racional.

3. Demais. — Certos atribuem a Cristo uma vontade de piedade que só pode pertencer à parte racional.
Logo, em Cristo há várias vontades racionais.
Mas, em contrário, em toda ordem há um primeiro motor. Ora, a vontade é primeiro motor na ordem
dos atos humanos. Logo, cada homem não tem senão uma vontade propriamente dita, e é a racional.
Ora, Cristo é homem. Logo, em Cristo só há a vontade humana.

SOLUÇÃO. — Como se disse, a vontade é umas vezes, tomada pela potência e outras, pelo ato. Se, pois,
a vontade é tomada pelo ato, então, devemos atribuir a Cristo duas vontades racionais, isto é, duas
espécies de atos de vontade. Pois, a vontade, como se disse, na Segunda Parte, tanto tem por objeto o
fim, como os meios para consegui-lo; e num outro sentido, é levada para ambos.
Pois, o fim ela o quer simples e absolutamente falando, como o bem essencial; e os meios ela os quer
com uma certa dependência, enquanto tiram a sua bondade do fim a que se ordenam. Por onde, o ato
da vontade tem uma natureza quando é levada a querer o que é em si mesmo digno de ser querido,
como a saúde, e a essa Damasceno chama, isto é, simples vontade, ao que os Mestres lhe dão o nome
de vontade como natureza. É porém de outra natureza, quando é levada a querer um objeto como meio
para conseguir um fim, como quando tomamos um remédio; a cuja vontade Damasceno chama, isto é,
vontade conciliativa, e os Mestres lhe dão o nome de vontade como razão. Mas, essa diversidade de
atos não constitui diversidade de potências, pois uns e outros se fundam num objeto da mesma
natureza, que é o bem. Por onde, devemos dizer, que se falamos da potência da vontade, há em Cristo
uma só vontade humana essencialmente dita e não participativamente. Mas se nos referimos à vontade
como ato, então distinguimos em Cristo uma vontade como natureza, chamada e uma vontade como
razão, chamada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essas duas vontades não constituem potências diversas,
mas só se diferenciam pelos seus atos, como se disse.

RESPOSTA À SEGUNDA. — Mesmo o intelecto e a razão não constituem potências diversas, como
dissemos na Primeira Parte.

RESPOSTA À TERCEIRA. — A vontade de piedade não difere da vontade considerada como natureza,
pois, ela evita o mal alheio, absolutamente considerado.

## Art. 4 — Se em Cristo havia livre arbítrio.
O quarto discute-se assim. — Parece que em Cristo não havia livre arbítrio.

1. — Pois, diz Damasceno: Se quisermos falar com propriedade, a gnome (isto é, o juízo, o pensamento
ou o raciocínio) e a proairesis (isto é, a eleição) não podemos atribuí-las a Deus. Ora, sobretudo em
matéria de fé, devemos falar com propriedade de expressão. Logo, em Cristo não houve eleição. E por
consequência, nem livre arbítrio, do qual a eleição é ato.

2. Demais. — Como diz o Filósofo, a eleição é o desejo do que já foi deliberado. Ora, parece que em
Cristo não houve conselho, pois, não deliberamos sobre aquilo de que estamos certos; ora, Cristo tinha
certeza de tudo. Logo, em Cristo não houve eleição. E portanto, nem livre arbítrio.

3. Demais. — O livre arbítrio não é determinado. Ora, a vontade de Cristo queria determinadamente o
bem, pois, não podia pecar, como dissemos. Logo, em Cristo não houve livre arbítrio.
Mas, em contrário, a Escritura: Ele comerá manteiga e mel até que saiba rejeitar o mal e escolher o bem,
o que é um ato de livre arbítrio. Logo, em Cristo houve livre arbítrio.

SOLUÇÃO. — Como dissemos, havia em Cristo duplo ato de vontade. Um pelo qual a sua vontade era
levada para um objeto como querido em si mesmo, e que tem a natureza de fim; outro, pelo qual a sua
vontade queria um objeto conducente a outro, o que tem a natureza de meio. Ora, como diz o Filósofo,
a eleição difere da vontade em que a vontade, propriamente falando, busca o fruir, ao passo que a
eleição tem por objeto os meios. E assim, em sentido absoluto, a vontade é o mesmo que a vontade
como natureza; ao passo que a eleição é o mesmo que a vontade como razão e é o próprio ato do livre
arbítrio, como dissemos na Primeira Parte. Ora, como atribuindo a Cristo a vontade, enquanto razão,
havemos necessariamente de admitir nele a eleição; e por consequência o livre arbítrio, do qual a
eleição é um ato, conforme estabelecemos na Primeira Parte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Damasceno exclui de Cristo a eleição, por entender que
a denominação de eleição inclui a ideia de dúvida. Contudo, a dúvida não é de necessidade, à eleição;
pois, também Deus pode eleger, como se lê na Escritura: Elegeu-nos nele mesmo antes do
estabelecimento do mundo, embora em Deus não haja nenhuma dúvida. Mas, a eleição inclui a dúvida,
quando quem elege é por natureza sujeito à ignorância. E o mesmo devemos dizer do mais a que se
refere a referida autoridade.

RESPOSTA À SEGUNDA. — A eleição pressupõe o conselho; mas, não resulta do conselho, senão quando
já determinado pelo juízo; pois, o que julgamos devemos praticar, depois da perquisição do conselho,
isso escolhemos, como diz Aristóteles. Por onde, se julgamos que revemos praticar um ato, sem ter
precedido nenhuma dúvida e nenhuma perquisição, isso basta para a eleição. Por onde é claro, que a
dúvida ou a perquisição não se incluem, como tais, na eleição, mas só quando se trata de quem por
natureza está sujeito à ignorância.

RESPOSTA À TERCEIRA. — A vontade de Cristo, embora determinada para o bem, não está contudo
determinada a um ou outro bem particular. E por isso, era próprio de Cristo eleger pelo livre arbítrio
confirmado no bem, como se dá com os bem-aventurados.

## Art. 5 — Se a vontade humana de Cristo quis coisas diferentes das que Deus quer.
O quinto discute-se assim. — Parece que a vontade humana de Cristo não quis coisas diferentes das
que Deus quer.

1. — Pois, diz a Escritura: Para fazer a tua vontade, Deus meu, eu o quis. Ora, quem quer fazer a vontade
de outrem quer o que este quer. Logo, parece que a vontade humana de Cristo não queria senão o que
a sua vontade divina queria.

2. Demais. — A alma de Cristo tinha uma caridade perfeitíssima, excelente mesmo à compreensão da
nossa ciência, segundo aquilo do Apóstolo: A caridade de Cristo, que excede todo entendimento. Ora, a
caridade faz querermos o que Deus quer; donde o dizer o Filósofo, que uma das características dos
amigos é querer e escolher as mesmas coisas. Logo, a vontade humana de Cristo nada mais queria do
que queria a sua vontade divina.

3. Demais. — Cristo gozava realmente da visão beatifica, Ora, os santos que gozam da visão beatifica no
céu, não querem senão o que Deus quer. Do contrário, não seriam santos, por não terem tudo quanto
quisessem; pois, como diz Agostinho, bem-aventurado é quem tem tudo o que quer e nada quer de
mau. Logo, Cristo nada mais quis, pela sua vontade humana, senão o que a vontade divina queria.
Mas, em contrário, Agostinho diz: Quando Cristo disse — não o que eu quero, mas o que tu queres —
mostrou querer cousa diferente que a querida pelo Pai. E isso só o podia pela sua vontade humana, pois,
transfigurou a nossa fraqueza no seu desejo, não divino, mas humano.

SOLUÇÃO. — Como dissemos, a natureza humana de Cristo encerra dupla vontade, a sensitiva, chamada
vontade por participação, e a racional, considerada quer como natureza, quer como razão. Ora, como
dissemos, o Filho de Deus, por uma certa dispensa e antes da sua paixão, permitia à carne fazer e sofrer
como carne. E semelhantemente, permitia a todas as suas faculdades agir como lhes era próprio. Ora, é
manifesto que a vontade sensitiva evita naturalmente as dores sensíveis e os sofrimentos do corpo.
Semelhantemente, a vontade como natureza evita o que lhe é contrário e o mal em si mesmo, como a
morte e males semelhantes. Ora, tais coisas a vontade, como razão, pode às vezes eleger, em
dependência do fim, assim como a sensualidade, e mesmo a vontade, absolutamente considerada, de
um homem tal, enquanto tal, evita uma queimadura, que contudo a vontade racional elege, em vista da
saúde a adquirir. Ora, a vontade de Deus era, que Cristo padecesse dores, sofrimentos e a morte, não
pelos querer Deus como tais; mas em ordem ao fim da salvação humana. Por onde é claro, que Cristo,
pela vontade da sensualidade, e pela vontade racional, considerada como natureza, podia querer coisas
diversas das queridas por Deus. Mas, pela vontade racional queria sempre o mesmo que Deus. Isso
resulta das palavras mesmas de Cristo: Não se faça a minha vontade, mas sim a tua. Pois, queria, pela
vontade racional, cumprir a vontade divina, embora diga que quer coisa diversa, pela sua outra vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo queria que a vontade do Pai se cumprisse; não
porém pela vontade sensitiva, cujo movimento não se alça até a vontade de Deus; nem pela vontade
considerada como natureza, que busca um objeto absolutamente considerado, e não em ordem à
vontade divina.

RESPOSTA À SEGUNDA. — A conformidade da vontade humana com a divina se funda na vontade
racional, pela qual também concordam as vontades dos amigos, enquanto a razão considera a coisa
querida, relativamente à vontade do amigo.

RESPOSTA À TERCEIRA. — Cristo ao mesmo tempo que vivia esta vida, contemplava a essência divina,
enquanto que a sua alma gozava de Deus, e tinha uma carne passível. E por isso, pela sua carne passível,
podia padecer certos sofrimentos repugnantes à sua vontade natural e mesmo ao apetite sensitivo.

## Art. 6 — Se havia em Cristo vontades contrárias.
O sexto discute-se assim. — Parece que havia em Cristo vontades contrárias.
1 — Pois, vontades contrárias supõem a contrariedade dos seus objetos; assim como também a
contrariedade dos movimentos supõe a contrariedade dos seus termos, como está claro no Filósofo.
Ora, Cristo, pelas suas vontades diversas, queria coisas contrárias; assim, pela vontade divina queria a
morte, que repugnava à sua vontade humana. Donde o dizer Atanásio: Quando o Cristo exclama — Pai,
se é possível, passe de mim este cálix, todavia não se faça nisto a minha vontade, mas sim: a tua; e ainda
— o espírito está pronto mas a carne é fraca; revela ter duas vontades, - a humana que, pela fraqueza
da carne, fugia o sofrimento; e a divina, pronta para a paixão. Logo, havia em Cristo vontades contrárias.

2. Demais. — O Apóstolo diz: Porque a carne deseja contra o espírito e o espírito contra a carne. Há,
pois, vontades contrárias, quando o espírito deseja uma coisa e a carne, outra. Ora, tal se dava com
Cristo; pois, pela vontade de caridade, que o Espírito Santo lhe causava na. alma, queria o sofrimento,
segundo aquilo da Escritura. — Foi oferecido porque ele mesmo quis; ao contrário, pela carne, fugia o
sofrimento. Logo, havia nele contrariedade de vontades.

3. Demais. — O Evangelho diz, que posto em agonia orava Jesus com maior instância. Ora, a agonia
implica uma luta da alma, que tende para uma direção oposta. Logo, parece que em Cristo havia
vontades contrárias.
Mas, em contrário, determina o Sexto Sínodo: Afirmamos duas vontades naturais não contrárias, ao
invés do que os impios ensinam hereticamente; e que a vontade humana de Cristo obedece, sem
resistência nem relutância, antes com sujeição, à sua vontade divina e onipotente.

SOLUÇÃO. — Não pode haver contrariedade, sem haver oposição fundada num mesmo sujeito e no
mesmo ponto de vista. Pois, a diversidade fundada em coisas diferentes e a luzes diversas não basta
para constituir uma contrariedade, nem ainda uma contradição; assim, se um homem for belo ou são de
mãos e não de pés.
Por onde, para haver vontades contrárias é necessário, primeiro, que essa contrariedade tenha o
mesmo sujeito. Assim, se a vontade de um quiser fazer uma coisa fundada numa razão universal, e a de
outro não quiser fazer a mesma coisa por uma razão particular, não há absolutamente contrariedade de
vontades. Por exemplo, se o rei quiser que um ladrão seja enforcado, para o bem da república, e um dos
parentes deste não o quiser, pelo amor particular que lhe tem, não haverá contrariedade de vontades.
Salvo talvez se a vontade do particular chegar a ponto de querer impedir o bem público, para conservar
o seu bem particular; pois, então, a repugnância das vontades se funda no mesmo objeto.
Em segundo lugar é necessário, para haver vontades contrárias. que a contrariedade se funde na mesma
vontade. Assim, se quisermos uma coisa pelo apetite racional e outra, pelo sensitivo, não há aí nenhuma
contrariedade; salvo se o apetite sensitivo prevalecer a ponto de alterar ou retardar o apetite racional;
pois, então, já o movimento contrário do apetite sensitivo teria, de certo modo, atingido a vontade
racional em si mesma.
Donde devemos concluir, que embora a vontade natural e a vontade sensitiva, em Cristo, quisessem
coisas diferentes das queridas pela vontade divina e pela sua própria vontade racional, não havia
contudo nele nenhuma contrariedade de vontades. — Primeiro, porque nem a vontade sensitiva
repudiava aquela razão pela qual a vontade divina e a vontade da razão humana, em Cristo, queriam a
paixão. Pois, a vontade absoluta de Cristo queria a salvação do gênero humano; não podiam porém
querê-la como um meio. Quanto, ao movimento da sensibilidade, ele não podia elevar-se até aí. —
Segundo, porque nem a vontade divina nem a racional eram impedidas ou retardadas em Cristo pela
vontade natural ou pelo apetite sensível. Semelhantemente e ao contrário, nem a sua vontade divina ou
a vontade racional evitavam ou retardavam o movimento da vontade natural humana e o movimento da
sensibilidade. Pois, aprazia a Cristo, pela sua vontade divina e também pela vontade racional, que a sua
vontade natural e a sua vontade sensível se movessem conforme a ordem das suas naturezas. — Por
onde é claro, que em Cristo não havia nenhuma repugnância ou contrariedade de vontades.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O mesmo querer a vontade humana de Cristo coisa
diferente do que quisesse a sua vontade divina procedia da própria vontade divina, a cujo beneplácito a
natureza humana de Cristo se movia com seu movimento próprio; como diz Damasceno.

RESPOSTA À SEGUNDA. — A concupiscência da carne retarda ou impede em nós a concupiscência do
espírito; o que não se dava em Cristo. E por isso em Cristo não havia, como há em nós, contrariedade
entre a carne e o espírito.

RESPOSTA À TERCEIRA. — Cristo não sofreu agonia na parte racional da alma, enquanto isso implica um
choque de vontades procedente de razões diversas; por exemplo, quando queremos uma coisa que a
razão nos oferece, e queremos também o contrário, que ela nos propõe. O que provém da fraqueza da
razão, incapaz de discernir o que é absolutamente melhor. E tal não se dava em Cristo, que, com a sua
razão julgava ser, absolutamente, melhor cumprir pela sua paixão a vontade divina, no tocante à
salvação do gênero humano. Houve porém agonia em Cristo quanto à parte sensitiva, que implica o
temor do infortúnio iminente, como diz Damasceno.