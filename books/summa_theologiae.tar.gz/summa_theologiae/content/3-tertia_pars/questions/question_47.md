# Questão 47: Da causa eficiente da paixão de Cristo
Em seguida devemos tratar da causa eficiente da Paixão de Cristo. E nesta questão discutem-se seis
artigos:

## Art. 1 — Se Cristo foi morto por outrem ou por si mesmo.
O primeiro discute-se assim. — Parece que Cristo não foi morto por outrem, mas por si mesmo.

1. — Pois, Ele próprio o diz no Evangelho: Ninguém tira de mim a vida, mas eu de mim mesmo a ponho.
Ora, diz-se que mata a outrem quem lhe tira a vida. Logo, Cristo não foi morto por outrem, mas por si
mesmo.

2. Demais. — Os mortos por outrem perecem pouco a pouco, àmedida que se lhe enfraquece a
natureza. O que, sobretudo se dá com os crucificados; pois, como diz Agostinho, suspensos no madeiro
são cruciados por uma morte prolongada. Ora, tal não aconteceu com Cristo, pois, dando um grande
brado, rendeu o espírito, como refere o Evangelho. Logo, Cristo não foi morto por outro, mas por si
mesmo.

3. Demais. — Os mortos por outrem sofrem morte violenta, e não voluntária, portanto; porque o
violento se opõe ao voluntário. Ora, Agostinho diz que o espírito de Cristo não se separou do corpo sem
que ele o quisesse, mas porque o quis, quando o quis e como o quis. Logo, Cristo não foi morto por
outros, mas por si mesmo.
Mas, em contrário, o Evangelho: E depois de açoitá-lo tirar-lhe-ão a vida.

SOLUÇÃO. — Um agente pode causar um efeito, de dois modos. — Primeiro, produzindo-o diretamente
pela sua ação. E, assim, os perseguidores de Cristo o mataram, porque lhe infligiram intencionalmente
tratamentos capazes de lhe causarem a morte, com que efetivamente causaram, pois, das referidas
causas proveio a morte subsequente. — Noutro sentido, um agente pode produzir um efeito
indiretamente, quando, podendo impedi-la, não o faz; assim dizemos que é causa de outrem ser
molhado quem não fechou a janela por onde entrou a chuva. E deste modo Cristo foi, ele próprio, causa
da sua paixão e morte, pois, podia impedir tanto uma como outra. Primeiro, coibindo os seus
adversários, de maneira que não o quisessem ou não o pudessem matar. Segundo, porque o seu espírito
tinha o poder de conservar a natureza da sua carne, de modo que nenhuma ofensa física pudesse fazê-
lo sucumbir. E esse poder a alma de Cristo o tinha, por estar unida a Deus na unidade de pessoa, como o
diz Agostinho. Como, pois, a alma de Cristo não livrou o seu próprio corpo das injúrias que lhe eram
feitas, mas quis que a sua natureza corpórea a elas sucumbisse por isso o Evangelho diz que pôs a sua
vida ou morreu voluntàriamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No dito do Evangelho — Ninguém tira de mim a vida,
subentende-se — contra a minha vontade. Pois, a palavra tirar, em sentido próprio, significa arrebatar
alguma coisa a alguém, que não pode resistir, contra a sua vontade.

RESPOSTA À SEGUNDA. — Para mostrar que a paixão sofrida por violência não o privava da vida, Cristo
conservou toda a sua vitalidade corpórea, a ponto de, no momento de expirar, ter clamado com alta
voz. O que se lhe enumera entre outros milagres da sua morte. Donde o dizer o Evangelho: O Centurião,
que estava bem defronte, vendo que Jesus expirava dando este brado, disse: Verdadeiramente este
homem era Filho de Deus. - Também foi admirável na morte de Cristo o ter morrido mais ràpidamente
que quaisquer outros padeceram sofrimentos semelhantes. Por isso, como refere o Evangelho, os que
morreram com Cristo lhes quebraram as pernas, para morrerem mais depressa; tendo vindo depois a
Jesus, como viram que estava já morto, não lhe quebraram as pernas. E Marcos diz que Pilatos se
admirava que Jesus morresse tão depressa. Assim, pois, como por sua vontade a sua natureza corpórea
conservou-se vigorosa até o fim assim também, quando quis; subitamente cedeu aos ferimentos que lhe
tinham sido feitos.

RESPOSTA À TERCEIRA. — Simultaneamente Cristo sofreu a violência de que morreu, e contudo morreu
porque o quis; pois a violência, que lhe foi feita ao corpo, só veio a prevalecer sobre ele, quando o quis
Cristo.

## Art. 2 — Se Cristo morreu por obediência.
O segundo discute-se assim. — Parece que Cristo não morreu por obediência

1. — Pois, a obediência implica um preceito: Ora, não lemos na Escritura fosse preceituado que Cristo
houvesse de sofrer. Logo, não sofreu por obediência.

2. Demais. — Dizemos que age por obediência quem age em virtude da necessidade de um preceito.
Ora, Cristo não sofreu necessária, mas voluntariamente. Logo, não sofreu por obediência.

3. Demais. — A caridade é virtude mais excelente que a obediência. Ora, o Apóstolo diz, que Cristo
sofreu pela caridade: Andai em caridade, assim como também Cristo nos amou e se entregou a si
mesmo por nós outros. Logo, a Paixão de Cristo deve ser atribuída, antes à caridade que à obediência.
Mas, em contrário, o Apóstolo: Feito obediente ao Pai até à morte.

SOLUÇÃO. — Foi convenientíssimo que Cristo sofresse por obediência. — Primeiro, porque isso
convinha à justificação humana; pois, assim como pela desobediência de um só homem foram muitos
feitos pecadores, assim também pela obediência de um só muitos se tornaram justos, como diz o
Apóstolo. — Segundo, foi conveniente, para reconciliar os homens com Deus, segundo aquilo do
Apóstolo: Fomos reconciliados com Deus pela morte de seu Filho; isto é, enquanto que a morte mesma
de Cristo foi um sacrifício muito aceito de Deus, como o diz o Apóstolo: E se entregou a si mesmo por
nós outros como oferenda e hóstia a Deus em odor de suavidade. Ora, a obediência se antepõe a todos
os sacrifícios, segundo a Escritura: A obediência é melhor que as vítimas. Por isso foi conveniente que o
sacrifício da Paixão e da morte de Cristo procedesse da obediência. - Terceiro, foi conveniente à vitória
pela qual triunfou da morte e do autor dela. Pois, um soldado não pode vencer sem obedecer ao
general. E assim Cristo alcançou a vitória por ter sido obediente a Deus, segundo aquilo da Escritura: O
homem obediente cantará a vitória.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo recebeu do Pai o preceito de sofrer. Assim, diz o
Evangelho: Tenho o poder de pôr a minha vida e tenho o poder de reassumir este mandamento recebi
de meu Pai, isto é, o de pôr e reassumir a vida. Pelo que, como ensina Crisóstomo, não se deve
entender, que primeiro tivesse que ouvir esse preceito, com a necessidade de aprendê-lo; mas mostrou
que agia voluntàriamente, desfazendo toda suspeita de oposição entre ele e o Pai. Mas, na morte de
Cristo consumou-se a lei antiga, conforme as palavras mesmas que disse ao esperar: Tudo está
cumprido. Por isso podemos entender que, sofrendo, cumpriu todos os preceitos da lei antiga. — Os
preceitos morais, porém, fundados no da caridade ele os cumpriu, sofrendo por amor de seu Pai,
segundo o lugar do Evangelho: Para que conheça o mundo que amo ao Pai e que faço como ele me
ordenou; levantai-vos, vamo-nos daqui, a saber, para o lugar da Paixão. E sofreu também por amor do
próximo, segundo o Apóstolo: Amou-me e se entregou a si mesmo por amor de mim. — Quanto aos
preceitos cerimoniais da lei, ordenados sobretudo os sacrifícios e às oblações, Cristo os cumpriu na sua
Paixão, porque todos os sacrifícios antigos foram figuras desse verdadeiro sacrifício que Cristo sofreu
morrendo por nós. Donde o dizer o Apóstolo: Ninguém vos julgue pelo comer ou pelo beber nem por
causa dos dias de festa, ou das luas novas ou dos sábados, que são sombra das coisas vindouras; mas o
corpo é em Cristo; e isso porque Cristo está para esses sacrifícios como o corpo para a sombra. —
Quanto aos preceitos judiciais da lei, sobretudo ordenados à satisfação das injúrias sofridas, Cristo os
cumpriu na sua Paixão. Pois, como diz a Escritura, pagou então o que não tinha roubado, deixando-se
pregar no madeiro, pela fruta que o homem roubara da árvore, contra o mandado de Deus.

RESPOSTA À SEGUNDA. — A obediência, embora implique obrigação relativamente ao que foi
mandado, contudo supõe a vontade de cumprir a ordem. E tal foi à obediência de Cristo. Pois, a Paixão
mesma e a morte, em si considerada repugnavam àvontade natural. Contudo Cristo queria que a
vontade de Deus se cumprisse nessa matéria, segundo a Escritura: Para fazer a tua vontade, Deus meu,
eu o quis. Por isso dizia: Se este cálice não pode passar sem que eu o beba, faça-se a tua vontade.

RESPOSTA À TERCEIRA. — Pela mesma razão Cristo sofreu por obediência e caridade. Porque só por
obediência cumpriu os preceitos da caridade e foi obediente por amor para com o Pai, que lhe
mandava.

## Art. 3 — Se Deus Pai entregou Cristo à Paixão.
O terceiro discute-se assim. — Parece que Deus Padre não entregou Cristo à Paixão.

1. — Pois, é iníquo e cruel entregar um inocente à Paixão e à morte. Ora, como diz a Escritura, Deus é
fiel e sem nenhuma iniquidade. Logo, não entregou Cristo inocente à Paixão e à morte.

2. Demais. — Ninguém pode ser entregue à morte por si mesmo e por outrem. Ora, Cristo entregou-se a
si mesmo por nós, segundo aquilo da Escritura: Entregou a sua alma àmorte. Logo, parece que não o
entregou o Pai.

3. Demais. — Judas foi censurado por ter entregue Cristo aos judeus, como o lemos no Evangelho: Um
de vós é o diabo; o que ele dizia por Judas Iscariotes, que o havia de entregar. Semelhantemente,
também foram censurados os judeus, que o entregaram a Pilatos, como o próprio Cristo o disse: A tua
nação e os teus pontífices são os que te entregaram nas minhas mãos: Pilatos também o entregou para
que fosse crucificado, como se lê no Evangelho. Ora, segundo o Apóstolo, não há nenhuma união entre
a justiça e a iniquidade. Logo, parece que Deus Padre não entregou Cristo à Paixão.
Mas, em contrário, o Apóstolo: A seu próprio Filho não perdoou Deus, mas por nós todos o entregou.

SOLUÇÃO. — Como se disse, Cristo sofreu voluntariamente, por' obedecer ao Pai. Por onde de três
modos Deus Padre entregou Cristo à Paixão. — Primeiro, porque, na sua vontade eterna, preordenou a
Paixão de Cristo para a liberação do gênero humano, segundo aquilo da Escritura: O Senhor carregou
sobre ele a iniquidade de todos nós. E ainda: O Senhor quis quebrantá-Ia na sua enfermidade. —
Segundo, por lhe ter inspirado a vontade de sofrer por nós, infundindo-lhe a caridade. Por isso, a
Escritura acrescenta: Foi oferecido porque ele mesmo o quis. — Terceiro, porque, longe de o livrá-lo da
paixão, ele o expôs aos perseguidores. Donde o dito do Evangelho, que, pendente da Cruz, Cristo
exclamava: Meu Deus, meu Deus, porque me abandonaste? E isso porque o entregou ao poder dos que
o perseguiam como diz Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É ímpio e cruel entregar ao sofrimento e à morte um
homem inocente, contra a sua vontade. Mas não foi assim que Deus Pai entregou a Cristo, senão
inspirando-lhe a vontade de sofrer por nós. E isso mostra a severidade de Deus, na expressão do
Apóstolo, que não quis perdoar o pecado, sem a pena: o que o Apóstolo o indica sinaladamente com as
palavras: Não poupou ao seu próprio Filho. E também mostra a sua bondade, pois, como o homem não
lhe pudesse suficientemente satisfazer por nenhuma pena que sofresse, deu-lhe quem o satisfizesse por
ele; o que o Apóstolo assinala, dizendo: Por nós todos o entregou. E noutro lugar: Ao qual, isto é, Cristo,
propôs Deus para ser vítima de propiciação pela fé no seu sangue.

RESPOSTA À SEGUNDA. — Cristo, enquanto Deus entregou-se a si mesmo àmorte, pela mesma vontade
e ação pela qual também o Pai o entregou. Mas, enquanto homem entregou-se a si mesmo por uma
vontade inspirada pelo Pai. Por isso não houve contradição entre o Pai ter entregado a Cristo e o ter-se
ele entregue a si mesmo.

RESPOSTA À TERCEIRA. — Uma mesma ação é diversamente julgada como boa ou má, segundo a raiz
diversa donde ela procede. O Padre, pois, entregou a Cristo, e este a si mesmo, pela caridade; por isso
são louvados. Ao passo que Judas o entregou por cobiça, os Judeus, de seu lado, por inveja; e Pilatos,
pelo temor mundano, com que temia a César. Por isso é que foram censurados.

## Art. 4 — Se foi conveniente que Cristo sofresse da parte dos gentios.
O quarto discute-se assim. — Parece que não foi conveniente que Cristo sofresse da parte dos gentios.

1. — Pois, como pela morte de Cristo os homens deviam ser liberados do pecado, parecia conveniente
que pouquíssimos tivessem cometido o pecado da morte de Cristo. Ora, pecaram, entregando-o à
morte, os Judeus, das pessoas dos quais diz o Evangelho: Este é o herdeiro; vinde, matemo-la. Logo,
parecia conveniente que no pecado da morte de Cristo não se tivessem implicado os gentios.

2. Demais. — A verdade deve corresponder à realidade. Ora, os sacrifícios figurados da lei antiga não os
ofereciam os gentios, mas os judeus. Logo, nem a Paixão de Cristo, que foi um verdadeiro sacrifício,
devia ter sido infligida por mãos dos gentios.

3. Demais. — Narra o Evangelho que os judeus queriam matar a Cristo, não só porque violava o sábado,
mas ainda por dizer que seu Pai era Deus, equiparando-se a este. Ora, isso parece que só contrariava a
lei dos judeus: por isso eles próprios diziam: Ele deve morrer segundo a lei, pois se fez Filho de Deus.
Parecia, logo, conveniente que Cristo sofresse, não da parte dos gentios, mas do dos judeus; e que era
falso o que diziam - A nós não nos é permitido matar ninguém, porque muitos pecados eram pela lei
punidos de morte, como está claro na Escritura.
Mas, em contrário, o próprio Senhor disse: Entregá-lo-ão aos gentios para ser escarnecido, açoitado e
crucificado.

SOLUÇÃO. — No modo mesmo da paixão de Cristo lhe estava prefigurado o efeito. Assim, o primeiro
efeito da morte de Cristo aproveitou aos judeus, muitos dos quais foram batizados na ocasião dessa
morte, como se lê na Escritura. Depois, mediante a pregação dos judeus, o efeito da paixão de Cristo o
sentiram os gentios. Por onde, foi conveniente que Cristo começasse a sofrer da parte dos judeus e em
seguida, entregue por estes, a sua Paixão se consumasse pelas mãos dos gentios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo, para mostrar a abundância da sua caridade, que o
levou a sofrer, pediu do alto da cruz perdão pelos seus perseguidores. Por isso, a fim de os frutos dessa
petição chegar aos judeus e aos gentios, quis Cristo sofrer da parte de uns, como de outros.

RESPOSTA À SEGUNDA. — A Paixão de Cristo foi à oblação de um sacrifício, pois Cristo sofreu a morte
movido da caridade, por vontade própria. Mas o sofrimento que lhe infligiram os perseguidores não foi
sacrifício, mas pecado gravíssimo.

RESPOSTA À TERCEIRA. — Como pondera Agostinho quando os judeus disseram - A nós não nos e
permitido matar ninguém — entendiam significar que não lhes era lícito matar ninguém por causa da
santidade do dia festivo, que já começavam a celebrar. — Ou isso diziam, como ensina Crisóstomo,
porque queriam matar a Jesus, não como transgressor da lei, mas como inimigo público, por se ter feito
rei — do que não lhes competia julgar. — Ou porque não lhes era lícito crucificá-la, como desejavam,
mas sim lapidar — o que fizeram com Estevam. — Ou, melhor é dizer, que pelos Romanos, a quem
estavam sujeitos, era-Ihes denegado o poder de matar.

## Art. 5 — Se os perseguidores de Cristo o conheceram.
O quinto discute-se assim. — Parece que os perseguidores de Cristo o conheciam.

1. — Pois, como diz o Evangelho, os lavradores, vendo o filho, disseram entre si - este é o herdeiro;
vinde, matemo-lo, o que comenta Jerônimo: Manifestissimamente o Senhor prova, com essas palavras,
que os príncipes dos judeus crucificaram o Filho de Deus não por ignorância, mas por inveja; pois
entendiam ser ele a quem o Pai disse, por meio do Profeta — Pede-me e eu te darei as nações em tua
herança. Logo, parece que sabiam ser Cristo o Filho de Deus.

2. Demais. — No Evangelho o Senhor diz: Agora eles não somente viram, mas ainda me aborreceram
tanto a mim como a meu Pai. Ora, o que é visto é manifestamente conhecido. Logo, os judeus
conhecendo a Cristo, infligiram-lhe a Paixão levados do ódio.

3. Demais. — Um sermão do Concilio Efesino diz: Quem rasga uma carta imperial é conduzido à morte,
por ter como infringido uma ordem do imperador. Assim também o judeu, tendo crucificado aquele a
quem via, será punido como se tivesse feito injúria ao Verbo mesmo de Deus. Ora, tal não se daria se
não conhecesse que Cristo era o Filho de Deus, ignorância que os escusaria. Logo, parece que os judeus,
crucificando a Cristo, sabiam ser ele o Filho de Deus.
Mas, em contrário, o Apóstolo: Se elesa conhecessem, nunca crucificariam ao Senhor da glória. E Pedro
diz, dirigindo-se aos Judeus: Sei que o fizestes por ignorância, como também os vossos magistrados. E o
Senhor, pendente da cruz, exclamou: Pai perdoai-lhes, porque não sabem o que fazem.

SOLUÇÃO. — Dentre os Judeus, uns eram os grandes e outros, a plebe. — Os grandes chamados
príncipes deles, sabiam como também os demônios, que Jesus era o Cristo prometido na lei; pois, viam
realizarem-se nele todos os sinais preditos pelos profetas. Mas lhe ignoravam o mistério da divindade;
por isso o Apóstolo diz, que se a conhecessem nunca crucificariam ao Senhor da glória. Devemos, porém
saber que a ignorância deles não os excusava do crime; pois era de certo modo uma ignorância afetada.
Porquanto viam sinais evidentes da sua divindade; mas por ódio e inveja de Cristo, pervertiam-lhes o
sentido e não queriam acreditar nas palavras com que se confessava Filho de Deus. Por isso deles disse
Cristo: Se eu não viera e não lhes tivera falado, não teriam eles pecado; mas agora não têm desculpa do
seu pecado. E assim podemos considerar como referentes à pessoa deles as palavras da Escritura:
Disseram a Deus — Retira-te de nós, pois nós não queremos conhecer os teus caminhos. — Quanto à
plebe, isto é, a gente do povo, não conhecedores dos mistérios da Escritura, não sabiam plenamente
que ele fosse nem Cristo nem Filho de Deus. Assim, embora certos cressem em Cristo, contudo nele não
cria a multidão. E se por vezes duvidavam se era Cristo, por causa dos inúmeros milagres e da eficácia da
sua doutrina, como se lê no Evangelho, contudo, foram depois iludidos pelos seus chefes de modo a não
acreditarem que fosse o Filho de Deus nem Cristo. Donde o dizer Pedro: Sei que o fiz estes por
ignorância, como também os vossos magistrados, isto é, porque foram enganados pelos magistrados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras citadas se referem àpessoa dos lavradores
da vinha, os quais são os símbolos dos chefes do povo judaico, que sabiam ser ele o herdeiro, porque
sabiam que era o Cristo prometido na lei. - Mas, contra essa resposta parece irem às palavras do salmo
— Pede-me e eu te darei as nações em tua herança, dirigidas ao mesmo a quem o foram àquelas outras
— Tu és meu filho, eu te gerei hoje. Se, pois, sabiam que Cristo era aquele a quem foi dito — Pede-me e
eu te darei as nações emtua herança, segue-se que sabiam ser o Filho de Deus. — E Crisóstomo também
diz, no mesmo lugar, que sabiam ser ele o Filho de Deus. — Beda, por sua vez, comentando aquilo do
Evangelho — não sabem o que fazem, diz: Devemos notar que não ora por aqueles que, sabendo ser
Cristo o Filho de Deus, preferiram antes crucificá-lo que o confessar. — Mas a isto pode-se responder,
que o conheceram como Filho de Deus, não por natureza, mas pela excelência de uma graça singular. —
Podemos contudo dizer que são considerados como conhecedores que Cristo era o verdadeiro Filho de
Deus por terem sinais evidentes disso; não quiseram, porém assentir neles, por ódio e inveja, de modo a
o reconhecerem como Filho de Deus.

RESPOSTA À SEGUNDA. — Antes das palavras citadas vêem as seguintes: Se eu não tivera feito entre
eles tais obras quais não fez outro algum, não haveria da parte deles pecado. E a seguir acrescenta: Mas
agora as viram e me aborreceram tanto a mim como a meu Pai. O que mostra ter sido por ódio que não
o reconheceram como Filho de Deus, depois de terem presenciado as obras milagrosas de Cristo.

RESPOSTA À TERCEIRA. — A ignorância afetada não escusa da culpa, mas ao contrário, a agrava: pois,
mostra que o agente tem um afeto tão veemente pelo pecado que quer incorrer em ignorância a fim de
não o evitar. Por isso os Judeus pecaram, tendo crucificado a Cristo, não só como homem, mas também
como Deus.

## Art. 6 — Se o pecado dos que crucificaram a Cristo foi o gravíssimo dos pecados.
O sexto discute-se assim — Parece que o pecado dos que crucificaram a Cristo não foi o gravíssimo
dos pecados.

1. — Pois, não é o gravíssimo dos pecados o que tem perdão. Ora, o próprio Senhor perdoou o pecado
dos que os crucificaram, quando disse: Pai perdoai-lhes porque não sabem o que fazem. Logo, o pecado
deles não foi o gravíssimo.

2. Demais. — O Senhor disse a Pilatos: O que me entregou a ti tem maior pecado. Ora, foi Pilatos
mesmo que entregou Cristo para ser crucificados pelos seus ministros. Logo, parece ter sido maior
pecado o de Judas traidor, que o dos crucificadores de Cristo.

3. Demais. — Segundo o Filósofo, ninguém sofre injustiça voluntàriamente; e como ainda diz no mesmo
lugar, se ninguém sofre injustiça, ninguém a comete. Logo, ninguém comete injustiça contra quem a
sofre voluntàriamente. Ora, Cristo sofreu voluntàriamente, como se estabeleceu. Logo, os que o
crucificaram nenhuma injustiça cometeram contra ele. E assim o pecado deles não foi o gravíssimo.
Mas, em contrário, aquilo do Evangelho — Acabai vós, pois, de encher a medida de vossos pais - diz
Crisóstomo: Na verdade, excederam a medida dos pais. Pois, aqueles mataram homens, ao passo que
estes crucificaram a Deus.

SOLUÇÃO. — Como dissemos, os magistrados dos judeus conheceram a Cristo; se em alguma ignorância
incorreram, essa foi à afetada, que não podaria escusá-las. Por isso foi gravíssimo o pecado deles, quer
genericamente considerado, quer pela malícia da vontade. — Quanto aos Judeus do povo, esses
pecaram gravissimamente quanto ao gênero do pecado; mas a ignorância em que faziam de certo modo
diminuía-lhes o pecado. Por isso, aquilo do Evangelho — Não sabem o que fazem — diz Beda: Roga por
aqueles que não sabiam o que faziam, tendo, é verdade, zelo pelas causas de Deus, mas não fundado
em ciência. — Muito mais escusável, porém foi o pecado dos gentios, pelas mãos de quem Cristo foi
crucificado, pois não tinham a ciência da lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa excusa do Senhor não se refere aos príncipes dos
judeus, mas à gente do povo, como dissemos.

RESPOSTA À SEGUNDA. — Judas entregou a Cristo, não a Pilatos, mas ao príncipe dos sacerdotes, que o
entregaram a Pilatos, segundo o Evangelho: A tua nação e os pontífices são os que te entregaram nas
minhas mãos. O pecado de todos esses, porém foi maior que o de Pilatos, que por temor de César
matou a Cristo; e também que o pecado dos soldados, que obedecendo ao mandado do governador, o
crucificaram, não por avareza, como Judas, nem por inveja e ódio, como os príncipes dos sacerdotes.

RESPOSTA À TERCEIRA. — Cristo quis por certo a sua Paixão, como também a quis Deus; mas não quis a
ação iníqua dos judeus. Por isso, os imoladores de Cristo não ficam escusados da injustiça. E, contudo,
quem assassina um homem comete uma injustiça, não só contra ele, mas também contra Deus e a
república, como o ensina o Filósofo. Por isso Davi condenou à morte aquele que não temeu estender a
mão para matar ao ungido do Senhor, não obstante as suas suplicas, conforme lemos na Escritura.