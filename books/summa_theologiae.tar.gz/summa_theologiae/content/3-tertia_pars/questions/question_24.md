# Questão 24: Da predestinação de Cristo
Em seguida devemos tratar da predestinação de Cristo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a Cristo cabia ser predestinado.
O primeiro discute-se assim. — Parece que a Cristo não cabia ser predestinado.
1 — Pois, o termo da predestinação é a adoção como filho, segundo o Apóstolo: O qual nos predestinou
para sermos seus filhos adotivos. Ora, a Cristo não cabia ser filho adotivo. Logo, não lhe cabia ser
predestinado.

2. Demais. — Em Cristo duas coisas devemos considerar — a natureza humana e a pessoa. Ora, não
podemos dizer que Cristo fosse predestinado em razão da natureza humana; pois, é falsa a proposição
— A natureza humana é filho de Deus. Semelhantemente, nem em razão da pessoa; porque a sua
pessoa é a do Filho de Deus, não por graça, mas por natureza; ora, a predestinação implica a graça,
como se disse na Primeira Parte. Logo, Cristo não foi Filho de Deus por predestinação.

3. Demais. — Assim, como o feito nem sempre existiu, assim, o predestinado, porque a predestinação
importa uma certa anterioridade. Ora, como Cristo sempre foi Deus e Filho de Deus, não se diz
propriamente que o homem Cristo fosse feito Filho de Deus. Logo, pela mesma razão, não devemos
dizer que Cristo foi Filho de Deus por predestinação.
Mas, em contrário, diz o Apóstolo, falando de Cristo: Que foi predestinado Filho de Deus com poder.

SOLUÇÃO. — Como resulta do que dissemos na na Primeira Parte, a predestinação em sentido próprio é
uma certa divina e abeterna preordenação do que a graça de Deus realizará no tempo. Ora, Deus, com a
graça da união, tornou o homem temporalmente, Deus e Deus, homem. Nem pode dizer-se que Deus
não preordenasse abeterno que isso se realizasse no tempo; pois, daí resultaria que Deus seria
susceptível de uma ideia nova. Donde portanto devemos concluir que a união mesma das naturezas, na
pessoa de Cristo inclui-se na predestinação eterna de Deus. É, em razão disso, dissemos que Cristo foi
predestinado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Apóstolo se refere, no lugar aduzido, à predestinação
pela qual nós somos predestinados para filhos adotivos. Pois, assim como Cristo é de um modo singular
e excelente Filho de Deus por natureza, assim também foi predestinado, de modo singular.

RESPOSTA À SEGUNDA. — Como diz a Glosa, certos ensinaram que a predestinação deve ser entendida
da natureza e não, da pessoa; e isso por ter sido feita à natureza humana à graça de ser unida ao Filho
de Deus, na unidade de pessoa. — Mas, neste sentido, a locução do Apóstolo é imprópria, por duas
razões. Primeiro, por uma razão geral. Pois, não dizemos que é a natureza de alguém a predestinada,
mas o suposto; pois, predestinar é dirigir para a salvação, a qual é própria do suposto, que age em vista
do fim da beatitude. Segundo, por uma razão especial, porque ser Filho de Deus não convém à natureza
humana; pois, é falsa a proposição. — A natureza humana é Filho de Deus. Salvo se alguém quisesse
compreender o pensamento do Apóstolo, forçando-lhe o sentido, assim: Que foi predestinado Filho de
Deus com poder, isto é, foi predestinado que a natureza humana se unisse ao Filho de Deus em pessoa.
- Donde se conclui que a predestinação é atribuída à pessoa de Cristo, não em si mesma, ou enquanto
subsistente em a natureza divina, mas enquanto subsistente em a natureza humana. Por isso, o
Apóstolo, depois de ter dito – Que foi jeito da linhagem de Davi segundo a carne, acrescenta: Que foi
predestinado Filho de Deus com poder. Para nos fazer compreender que, por ter sido feito da linhagem
de Davi segundo a carne, foi predestinado Filho de Deus com poder. Embora seja natural à pessoa de
Cristo, em si mesma considerada, ser Filho de Deus com poder; o que porém não lho é pela natureza
humana, pela qual essa filiação lhe convém pela graça da união.

RESPOSTA À TERCEIRA. — Origines ensina ser o seguinte o que o Apóstolo literalmente diz: Que foi
destinado Filho de Deus com poder, que não supõe nenhuma anterioridade, não havendo, pois aí
qualquer dificuldade. — Mas outros, a anterioridade implicada no particípio predestinado a referem,
não ao fato de ser Filho de Filho de Deus, mas à sua manifestação, segundo o modo habitual de a
Escritura se exprimir, pelo qual considera feito o que é conhecido. E então será o sentido: Cristo foi
predestinado para manifestar-se como Filho de Deus. — Mas nesse caso, predestinação não é tomada
em sentido próprio. Pois, consideramos propriamente predestinado quem é dirigido ao fim da
beatitude; ora, a beatitude de Cristo não depende do nosso conhecimento.
E por isso é melhor dizermos, que a anterioridade implicada no particípio predestinado não se refere à
pessoa, em si mesma, mas em razão da natureza. Pois, essa pessoa, embora fosse abeterno Filho de
Deus, contudo não foi sempre Filho de Deus o subsistente em a natureza humana. E por isso diz
Agostinho: Jesus, que havia de ser pela carne filho de Davi, foi contudo predestinado para ser Filho de
Deus pelo poder.
E devemos considerar que, embora o particípio — predestinado implique anterioridade, como o
particípio — feito não o significa contudo do mesmo modo. Pois, ser efeito exprime uma realidade como
ela em si mesma é; ao passo que ser predestinado se refere ao que está na apreensão de quem
preordena. Ora, o que subsiste como tal, em virtude de uma forma e de uma natureza, pode ser
apreendido enquanto ligado a essa forma, ou ainda absolutamente. E como, em sentido absoluto, não
convém à pessoa de Cristo o ter começado a ser Filho de Deus, convém-lhe contudo enquanto inteligida
ou apreendida como existente em a natureza humana; pois, teve um começo temporal a existência do
Filho de Deus revestido da natureza humana. Por onde, é mais verdadeira a proposição — Cristo foi
predestinado Filho de Deus que a outra: Cristo foi feito Filho de Deus.

## Art. 2 — Se é falsa a proposição – Cristo, enquanto homem, foi predestinado para Filho de Deus.
O segundo discute-se assim — Parece falsa a proposição: Cristo, enquanto homem, foi predestinado
para Filho de Deus.

1. — Pois, cada qual é num determinado tempo, o para que foi predestinado, porque a predestinação de
Deus não falha. Se, portanto, Cristo, enquanto homem, foi predestinado para Filho de Deus, resulta que
é Filho de Deus, enquanto homem. Ora, isto é falso. Logo, também a primeira proposição.

2. Demais. — O que convém a Cristo, enquanto homem, convém a qualquer homem, pois, ele é da
mesma espécie que os outros homens. Se, pois, Cristo, enquanto homem, foi predestinado Filho de
Deus, resulta que isso também cabe a qualquer homem. Ora, tal é falso. Logo, também a primeira
proposição.

3. Demais. — O que se fará no tempo foi predestinado abeterno. Ora, a proposição — O Filho de Deus
foi feito homem — é mais verdadeira que a outra — O homem foi feito filho de Deus. Logo, a
proposição — Cristo, enquanto Filho de Deus foi predestinado para ser homem — é mais verdadeira
que a sua inversa — Cristo, enquanto homem, foi predestinado para Filho de Deus.
Mas, em contrário, Agostinho: Dizemos que foi predestinado o próprio Senhor da glória, por ter sido
feito homem o Filho de Deus.

SOLUÇÃO. — Duas coisas podemos considerar na predestinação. Uma, relativa à própria predestinação
eterna; que, então, implica uma certa anterioridade relativa ao suposto da predestinação. Noutro
sentido, pode ser considerada quanto ao seu efeito temporal, dom gratuito de Deus. Por onde, devemos
concluir que, de ambos estes modos a predestinação é atribuída a Cristo em razão da só natureza
humana. Pois, a natureza humana nem sempre esteve unida ao Verbo; e também lhe foi conferido pela
graça, que se unisse à pessoa do Filho de Deus. E portanto, só em razão da natureza humana é que a
predestinação convém a Cristo. Donde o dizer Agostinho: Uma elevação tão grande, tão alta e tão
sublime foi predestinada à natureza humana, que não podia, assim, ser mais exaltada. Ora, dizemos que
convém a alguém, enquanto homem, o que lhe convém em razão da natureza humana. Donde, pois,
devemos concluir, que Cristo, enquanto homem, foi predestinado para Filho de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na proposição — Cristo, enquanto homem, foi
predestinado para Filho de Deus — a restritiva — enquanto homem, pode referir-se ao ato significado
pelo particípio, de dois modos. — Primeiro, quanto ao que está materialmente incluído na
predestinação. E então é falsa. Pois, o sentido é: ter sido predestinado que Cristo, enquanto homem
fosse Filho de Deus. E neste sentido a objeção colhe. De outro modo, pode referir-se à razão mesma do
ato; isto é, enquanto que a predestinação implica, por natureza, anterioridade e efeito gratuito. E, neste
sentido, a predestinação convém a Cristo em razão da natureza humana, como se disse; é considerado
então predestinado, enquanto homem.

RESPOSTA À SEGUNDA. — Uma causa pode convir a um homem, em razão da natureza humana, de dois
modos. — Primeiro, por ser dela a causa a natureza humana; assim a faculdade de rir convém a Sócrates
em razão da natureza humana, de cujos princípios procede essa faculdade. E, neste sentido, ser
predestinado não convém a Cristo nem a nenhum homem, em razão da natureza humana. Neste
sentido, pois, procede a objeção. — De outro modo, dizemos que uma causa convém a alguém, em
razão da natureza humana, quando a natureza humana é susceptível de tal causa. E então dizemos que
Cristo foi predestinado em razão da natureza humana porque a predestinação se refere à exaltação da
natureza humana em Cristo, como dissemos.

RESPOSTA À TERCEIRA. — O Verbo de Deus assumiu a natureza humana de um modo tão
inefavelmente singular, que simultaneamente se chamassem Deus — o filho do homem por causa da
natureza humana assumida; e o Filho de Deus, por causa do Unigênito, assumente — como diz
Agostinho. E portanto, como essa assunção se inclui na predestinação, como gratuita, podemos dizer
tanto que o Filho de Deus foi predestinado para ser homem, como que o foi o Filho do Homem, para ser
Filho de Deus. Mas, como não foi ao Filho de Deus a graça de ser homem, mas antes, à natureza
humana, para que se unisse ao Filho de Deus, podemos mais propriamente dizer, que Cristo, enquanto
homem, foi predestinado para ser Filho de Deus, do que: Cristo, enquanto Filho de Deus, foi
predestinado para ser homem.

## Art. 3 — Se a predestinação de Cristo é o exemplar da nossa predestinação.
O terceiro discute-se assim. — Parece que a predestinação de Cristo não foi o exemplar da nossa
predestinação.
1 — Pois, o exemplar preexiste ao exemplado. Ora, nada preexiste ao eterno. Sendo, pois, a nossa
predestinação eterna, parece que a predestinação de Cristo não é o exemplar da nossa.

2. Demais. — O exemplar conduz ao conhecimento da nossa predestinação, do exemplado. Ora, mão
precisava Deus de lhe ser trazido o conhecimento por um terceiro, segundo o Apóstolo: Os que ele
conheceu na sua presciência também os predestinou, Logo, a predestinação de Cristo não é o exemplar
da nossa predestinação.

3. Demais. — O exemplar é conforme ao exemplado, Ora, uma é a razão da predestinação de Cristo e
outra, a da nossa. Porque, nós somos predestinados para filhos da adoção, e Cristo foi predestinado
como Filho de Deus com poder, na expressão do Apóstolo. Logo, a sua predestinação não é o exemplar
da nossa.
Mas, em contrário, diz Agostinho: Ele, o Salvador, o mediador entre Deus e os homens, o homem Cristo
Jesus, é a preclaríssima luz da predestinação e da graça. Ora, é chamado luz da predestinação e da
graça, porque pela sua predestinação e a sua graça se manifesta a nossa predestinação; o que é próprio
do exemplar. Logo, a predestinação de Cristo é o exemplar da nossa.

SOLUÇÃO. — A predestinação pode ser considerada a dupla luz. — Primeiro, quanto ao ato mesmo do
predestinante. E então a predestinação de Cristo não pode ser chamada exemplar da nossa
predestinação; pois, de um modo pelo mesmo ato eterno, Deus nos predestinou a nós e a Cristo. — De
outro modo, a predestinação pode ser considerada relativamente àquilo para que alguém é
predestinado; o que é o termo e o efeito da predestinação. — E assim, a predestinação de Cristo é o
exemplar da nossa predestinação. E isto de dois modos. Primeiro, quanto ao bem ao qual somos
predestinados. Pois, Cristo foi predestinado a ser por natureza o Filho de Deus; ao passo que nós somos
predestinados à filiação de adoção, que é uma semelhança participada pela filiação natural.
Donde o dizer o Apóstolo: Os que ele conheceu na sua presciência também os predestinou para serem
conformes à imagem de seu Filho. De outro modo, quanto à maneira de conseguir o referido bem, que é
mediante a graça. O que em Cristo é manifestíssimo; porque a natureza humana em Cristo está unida ao
Filho de Deus, sem precedência de nenhum mérito seu. E, como diz o Evangelho, todos nós
participamos da plenitude da sua graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe relativamente ao ato mesmo do
predestinante.
E o mesmo devemos RESPONDER À SEGUNDA.

RESPOSTA À TERCEIRA. — Não é necessário o exemplado conformar-se em tudo ao exemplar; mas
basta que o exemplado de algum modo imite o seu exemplar.

## Art. 4 — Se a predestinação de Cristo é a causa da nossa predestinação.
O quarto discute-se assim. — Parece que a predestinação de Cristo não é a causa da nossa
predestinação.
1 — Pois, o eterno não tem causa. Ora, a nossa predestinação é eterna. Logo, a predestina ão de Cristo
não é a causa da nossa predestinação.

2. Demais. — O que depende da simples vontade de Deus não tem outra causa senão essa vontade. Ora,
a predestinação depende da simples vontade de Deus, ao dizer do Apóstolo: Sendo predestinados pelo
decreto daquele que obra todas as coisas seguido o conselho da sua vontade. Logo, a predestinação de
Cristo não é causa da nossa.

3. Demais. — Removida a causa, removido fica o efeito. Ora, removida a predestinação de Cristo,
removida não fica a nossa predestinação; porque, mesmo se o Filho de Deus não se tivesse encarnado,
haveria algum modo possível de operar a nossa salvação, como diz Agostinho. Logo, a predestinação de
Cristo não é a causa da nossa predestinação.
Mas, em contrário, o Apóstolo: O qual nos predestinou para sermos seus filhos adotivos por Jesus Cristo.

SOLUÇÃO. — Considerada a predestinação no seu ato mesmo, a predestinação de Cristo não é a causa
da nossa, pois, por um mesmo ato Deus predestinou a Cristo e a nós. Se, porém, considerarmos a
predestinação, quanto ao seu termo, então a predestinação de Cristo é a causa da nossa; porque Deus
preordenou a nossa salvação, predestinando abterno, que seria ela operada por Cristo. Pois, a
predestinação eterna não só inclui o que se fará no tempo, mas ainda o modo e a ordem pelos quais
nele e se cumprirá.

DONDE A RESPOSTA À PRIMEIRA E À SEGUNDA OBJEÇÕES. — Essas objeções procedem, quanto ao ato
da predestinação.

RESPOSTA À TERCEIRA. — Se Cristo não devesse encarnar-se, Deus teria preordenado, que os homens
se salvassem por outra causa. Mas, como preordenou a Encarnação de Cristo, simultaneamente
preordenou que ele fosse a causa da nossa salvação.