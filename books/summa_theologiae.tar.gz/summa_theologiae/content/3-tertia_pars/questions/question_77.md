# Questão 77: Dos acidentes remanescentes neste sacramento
Em seguida devemos tratar dos acidentes remanescentes neste sacramento.
E nesta questão, discute-se oito artigos:

## Art. 1 — Se os acidentes remanescem neste sacramento, sem sujeito.
O primeiro discute-se assim. — Parece que os acidentes não remanescem neste sacramento, sem
sujeito.

1. — Pois, este sacramento da verdade nada deve ter de desordenado ou de enganoso. Ora, existirem
acidentes sem sujeito é contra a ordem das coisas, que Deus infundiu na natureza. Logo, parece que
supõe uma certa falácia, pois, os acidentes são os sinais da natureza do sujeito. Portanto, não há neste
sacramento acidentes sem sujeito.

2. Demais. — Não pode, mesmo milagrosamente, a definição de uma coisa separar-se dela, ou a
definição de uma convém a outra; por exemplo, não é possível um homem, enquanto tal, ser animal
irracional. Pois, dai resultaria a existência simultânea dos contraditórios, pois, o que significa o nome de
uma coisa é a sua definição, como diz Aristóteles. Ora, o acidente, por definição, deve existir em um
sujeito; e a substância, por definição existe por si e não em um sujeito. Logo, não pode dar-se
miraculosamente, que neste sacramento existam acidentes sem sujeito.

3. Demais. — Um acidente se individua pelo seu sujeito. Se portanto os acidentes permanecem sem
sujeito, neste sacramento, não serão individuais, mas universais. O que evidentemente é falso, porque
então não seriam sensíveis, mas apenas inteligíveis.

4. Demais. — Os acidentes, pela consagração deste sacramento, não são susceptíveis de nenhuma
composição. Ora, antes da consagração, não eram compostos nem de matéria e forma, nem de essência
e existência. Logo, também depois da consagração, não tem nenhuma dessas composições. O que é
inadmissível, porque então seriam mais simples que os anjos, apesar de serem esses acidentes sensíveis.
Logo, os acidentes não permanecem, neste sacramento sem sujeito.
Mas, em contrário, Gregório diz: As espécies sacramentais são as denominações do que antes fora pão e
vinho. E assim, não remanescendo a substância do pão e do vinho resulta que tais espécies não tem
sujeito.

SOLUÇÃO. — Os acidentes do pão e do vinho, que os sentidos apreendem como remanescentes neste
sacramento, depois da consagração, não têm como sujeito a substância do pão e do vinho, que não
permanece, como dissemos. Nem tão pouco a forma substancial, que não permanece; e se
permanecesse, não poderia ser sujeito, como está claro em Boécio. Também é manifesto que tais
acidentes não têm como sujeito a substância do corpo e do sangue de Cristo; porque a substância do
corpo humano de nenhum modo pode ser afetada por esses acidentes. Nem é possível que o corpo de
Cristo, na sua existência gloriosa e impassível, se altere para receber tais qualidades.
Certos porém dizem, que têm como sujeito o ar circunstante. - Mas isto não pode ser. Primeiro, por não
ser o ar susceptível de tais acidentes. - Segundo, por não estarem esses acidentes onde está o ar; ao
contrário, o movimento dessas espécies o expulsa. - Terceiro, porque os acidentes não passam de um
sujeito para outro, isto é, de modo que um acidente, numericamente o mesmo, existente primeiro em
um sujeito, venha depois a existir em outro. Pois, um acidente recebe do seu sujeito a unidade
numérica. Por onde, não é possível, permanecendo numericamente o mesmo, estar ora em um sujeito,
ora em outro. - Quarto, porque o ar, não podendo então os seus acidentes próprios, teria
simultaneamente os próprios e os alheios. - Nem se pode dizer que isso se opera miraculosamente em
virtude da consagração; porque as palavras da consagração não significam tal, e contudo não obram
senão o que significam. Donde se conclui que os acidentes remanescem neste sacramento, sem sujeito.
O que pode ser feito pelo poder divino. Ora, o efeito, dependendo mais da causa primeira que da causa
segunda, Deus, causa primeira da substância e dos acidentes, por seu poder infinito pode conservar a
existência do acidente, subtraindo-lhe a substância que lhe dava a existência, como causa própria dela.
Assim como também pode Deus produzir os outros efeitos das causas naturais, sem as causas naturais;
tal o corpo humano, que formou no ventre da Virgem, sem o sêmen viril.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede ser um ente ordenado segundo a lei
comum da natureza, e o seu contrário sê-la segundo um especial privilégio da graça. Tal o que se dá com
a ressurreição dos mortos e com a iluminação dos cegos. Pois, também na ordem humana, certas
vantagens são concedidas a uns por especial privilegio, fora da lei comum. E assim, embora a ordem
comum da natureza exija que o acidente exista no seu sujeito, contudo por uma razão especial, segundo
a ordem da graça, os acidentes existem neste sacramento, sem sujeito, pelas razões supra-aduzidas.

RESPOSTA À SEGUNDA. — O ser, não sendo um gênero, não pode em si mesmo ser a essência da
substância ou do acidente. Não é, pois, a definição da substância - ser, por si, sem sujeito, nem a
definição do acidente - ser existente num sujeito. Mas à quididade ou à essência da substância é que
cabe ter o ser independente de um sujeito. A qüididade porém ou à essência do acidente é próprio
existir num sujeito. Ora, neste sacramento não se diz que haja acidentes que, em virtude da sua
essência, não estejam num sujeito, senão só por ação do poder divino. Por isso não deixam de ser
acidentes, pois nem deles se separa a definição do acidente, nem lhes cabe a definição da substância.

RESPOSTA À TERCEIRA. — Os acidentes em questão adquiriram o ser individual na substância do pão e
do vinho; convertida esta porem no corpo e no sangue de Cristo, remanescem, por virtude divina, os
acidentes no ser individuado que antes tinham. Por onde, são particulares e sensíveis.

RESPOSTA À QUARTA. — Os acidentes em discussão, enquanto permanece a substância do pão e do
vinho, não existem por si mesmos, nem os outros acidentes, mas os sujeitos deles é que tinham por si
mesmos, tal ser. Assim, a neve é branca pela brancura. Mas depois da consagração, os acidentes
remanescentes têm eles próprios o ser. Por isso são compostos de essência e de existência, como
dissemos na Primeira Parte, ao tratar dos anjos. E, com isso, têm a composição quantitativa das partes.

## Art. 2 — Se neste sacramento a quantidade dimensiva do pão ou do vinho é sujeito dos outros acidentes.
O segundo discute-se assim. — Parece que neste sacramento quantidade dimensiva do pão e do vinho
não é o sujeito dos outros acidentes.

1. — Pois, não há acidente de acidente, porque nenhuma forma pode ser sujeito, por ser próprio da
matéria o estar sujeita. Ora, a quantidade dimensiva é um acidente. "Logo, a quantidade dimensiva não
pode ser o sujeito dos outros acidentes.

2. Demais. — Assim como a quantidade se individua pela substância, assim também os outros acidentes.
Se, portanto a quantidade dimensiva do pão e do vinho permanecer individuada no ser que antes tinha,
no qual se conserva, pela mesma razão também os outros acidentes permanecem individuado no ser
que antes tinham na substância. Logo, não estão na quantidade dimensiva como sujeito, pois, todo
acidente se individua pelo seu sujeito.

3. Demais. — Entre os outros acidentes do pão e do vinho remanescentes, os nossos sentidos aprendem
também a rarefação e a condensação. Os quais não podem existir na quantidade dimensiva existente
fora da matéria, pois, rarefeito é o que tem pouca matéria, sob grandes dimensões, e condensado, o
que tem muita matéria, sob pequenas dimensões, como diz Aristóteles. Logo, parece que a quantidade
dimensiva não pode ser sujeito dos acidentes remanescentes neste sacramento.

4. Demais. — A quantidade separada do sujeito é a quantidade matemática, que não é sujeito de
qualidades sensíveis. Ora, os acidentes remanescentes, neste sacramento sendo sensíveis, parece que
não podem estar, como no sujeito, na quantidade do pão e do vinho, remanescente depois da
consagração.
Mas, em contrário, as qualidades não são divisíveis, senão por acidente, isto é, em razão do sujeito. Ora,
as qualidades remanescentes neste sacramento são susceptíveis das divisões da quantidade dimensiva,
como os nossos sentidos o revelam. Logo, a quantidade dimensiva é o sujeito dos acidentes
remanescentes neste sacramento.

SOLUÇÃO. — É forçoso admitir que os outros acidentes remanescentes neste sacramento têm como
sujeito a quantidade dimensiva do pão e do vinho, que permanecem. Primeiro, porque os nossos
sentidos aí percebem um ser colorido e afetado pelos outros acidentes, e nisso não se enganam.
Segundo, porque a primeira disposição da matéria é a quantidade dimensiva; por isso disse Platão que
as diferenças primeiras da matéria são o grande e o pequeno. E sendo a matéria o sujeito primeiro,
resulta por consequência, que todos os outros acidentes se referem ao sujeito, mediante a quantidade
dimensiva, sendo assim que dizemos ser a superfície o sujeito da cor. Donde veio o terem certos
considerado as dimensões como as substâncias dos corpos. E como, desaparecido o sujeito,
permanecem os acidentes com o ser que antes tinham é consequente que todos os acidentes
remanescem, fundados na quantidade dimensiva.
Terceiro, porque, sendo o sujeito o princípio da individuação dos acidentes, necessàriamente será de
algum modo princípio de individuação de certos acidentes o que é considerado sujeito deles. Pois, é da
essência do indivíduo não poder existir em vários seres. Por duas razões. Primeiro, por lhe não ser
natural existir em outro ser; e deste modo as formas imateriais separadas e por si subsistentes se
individuam por si mesmas. Segundo, porque apesar de à forma substancial ou a acidental lhe ser natural
existir em outro ser, contudo não lhe é natural existir vários; tal uma determinada brancura de um
determinado corpo. Ora, quanto ao primeiro modo, a matéria é o princípio de individuação de todas as
formas que a ela se unem. Pois, sendo natural a essas formas, por essência, existirem em outro ser
como no sujeito, no qual uma delas é recebida na matéria, que não é unida a outro ser, por isso mesmo
também não pode unir-se a outro ser essa forma assim existente. Quanto ao segundo modo, devemos
dizer que o princípio de individuação é quantidade dimensiva. Pois, o que toma um ente naturalmente
existente em um s6 jeito é o ser em si mesmo indiviso e dividido em todos os outros. Ora, a divisão recai
sobre a substância em razão da quantidade, como ensina Aristóteles.
Por onde, a quantidade dimensiva é um determinado princípio de individuação, nessas formas; isto é,
enquanto formas numericamente diversas estão unidas a partes diversas da matéria. Por isso, também
a quantidade dimensiva tem, em si mesma, uma certa individuação, de modo que podemos imaginar
várias linhas da mesma espécie diferentes pela posição, resultante da quantidade; pois, a dimensão não
é mais do que uma quantidade dotada de posição. Por onde, a quantidade dimensiva pode, antes, ser o
sujeito dos outros acidentes, que ao inverso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um acidente não pode por si ser sujeito de outro; pois,
não existe por si mesmo. Mas, enquanto existente em outro ser, dizemos que um acidente é sujeito de
outro, quando este é recebido pelo sujeito, mediante aquele; neste sentido dizemos que a superfície é o
sujeito da cor. Por onde, quando Deus faz um acidente existir por si, pode também ser ele por si o
sujeito de outro.

RESPOSTA À SEGUNDA. — Os outros acidentes, mesmo enquanto estavam na substância do pão, eram
individuados mediante a quantidade dimensiva, como dissemos. E assim, é antes a quantidade
dimensiva o sujeito dos outros acidentes remanescentes neste sacramento, do que inversamente.

RESPOSTA À TERCEIRA. — O rarefeito e o condensado são certas qualidades resultantes dos corpos,
quando têm muita ou pouca matéria, em determinadas dimensões; assim como também todos os
outros acidentes resultam dos princípios da substância. Por onde, assim como, desaparecida a
substância, por virtude divina se conservam os outros acidentes, assim também, desaparecida a
matéria, por virtude divina se conservam as qualidades dela resultante, como a rarefação e a
condensação.

RESPOSTA À QUARTA. — A quantidade matemática não abstrai da matéria inteligível, mas da sensível,
como diz Aristóteles. Ora, matéria sensível se chama a que é sujeito de qualidades sensíveis. Por onde é
manifesto, que a quantidade dimensiva, remanescente neste sacramento sem sujeito, não é a
quantidade matemática.

## Art. 3 — Se as espécies remanescentes neste sacramento podem alterar a matéria exterior.
O terceiro discute-se assim. — Parece que as espécies remanescentes neste sacramento não podem
alterar a matéria exterior.

1. — Pois, como Aristóteles o prova, as formas unidas à matéria são produzidas por outras também na
matéria existentes, e não por formas sem matéria; porque o semelhante produz o seu semelhante. Ora,
as espécies sacramentais são espécies sem matéria; pois, remanescem sem sujeito, como do sobre dito
se colige. Logo nenhuma alteração podem causar na matéria exterior, infundindo-lhe alguma forma.

2. Demais. — Cessada a ação do agente principal, necessàriamente cessa a ação do instrumento. Assim,
cessada a ação do ferreiro, cessa a do martelo. Ora, todas as formas acidentais agem como
instrumentos, em virtude da forma substancial, agente principal. Logo, não permanecendo neste
sacramento a forma substancial do pão nem a do vinho, como se demonstrou, resulta que as formas
acidentais remanescentes não podem alterar a matéria exterior.

3. Demais. — Nenhum ser age mais do que o permite a sua espécie, porque o efeito não pode ser
superior à causa. Ora, todas as espécies sacramentais são acidentes. Logo, não podem alterar a matéria
exterior, pelo menos na forma substancial.
Mas, em contrário, se não pudessem alterar a matéria exterior, não poderiam ser percebidas; ora, um
objeto é percebido porque o sentido é alterado pelo sensível, como diz Aristóteles.

SOLUÇÃO. — Todo ser, agindo enquanto atual, resulta por consequência que cada ser, assim como
existe, assim age. Ora, segundo o que foi dito, as espécies sacramentais o poder divino permite que
conservem o ser que tinham, enquanto existia a substância do pão e a do vinho. Logo, também lhes
permite conservem a sua atividade. Por onde, todas ação que podiam exercer enquanto existia a
substância do pão e a do vinho, continuam a podê-lo, quando as substâncias do pão e do vinho se
transformaram no corpo e no sangue de Cristo. Não há, portanto nenhuma dúvida, que podem alterar
os corpos externos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As espécies sacramentais, embora sejam formas
existentes sem matéria, conservam contudo, o mesmo ser que tinham anteriormente na matéria. Logo,
têm um ser assimilável às formas existentes na matéria.

RESPOSTA À SEGUNDA. — A ação da forma acidental depende da ação da forma substancial, assim
como o ser do acidente depende do da substância. Por onde, assim como por virtude divina as espécies
sacramentais podem existir sem a substância, assim também podem agir sem a forma substancial, por
virtude de Deus, de quem, como do agente primeiro depende totalmente a atividade da forma, tanto
substancial como acidental.

RESPOSTA À TERCEIRA. — A alteração sofrida pela substancial não é operada pela forma substancial
imediata, mas mediante as qualidades ativas e passivas, que agem em virtude da forma substancial. Ora,
essa virtude instrumental se conserva nas espécies sacramentais, por virtude divina, como era dantes.
Por isso podem agir como instrumento, para armar uma forma substancial. Por cujo modo, um ser pode
agir ultrapassando a sua espécie, não por virtude própria, mas em virtude do agente principal.

## Art. 4 — Se as espécies sacramentais podem corromper-se.
O quarto discute-se assim. — Parece que as espécies sacramentais não podem corromper-se.

1. — Pois, a corrupção resulta de separar-se a forma, da matéria. Ora, assim como a matéria do pão
permanece neste sacramento, como se disse. Logo, tais espécies não podem corromper-se.

2. Demais. — A corrupção do sujeito não acarreta senão acidentalmente a corrupção da forma; por isso
as formas por si subsistentes são incorruptíveis, como demonstram as, substâncias espirituais. Ora, as
espécies sacramentais são formas sem sujeito. Logo, não podem corromper-se.

3. Demais. — Se as espécies sacramentais se corromperem, se-lo-á natural ou milagrosamente. Ora,
naturalmente, não porque não têm elas nenhum sujeito de corrupção, que permaneça consumada a
corrupção. Nem tão pouco milagrosamente, porque os milagres que se realizam neste sacramento se
fazem em virtude da consagração, pela qual se conservam as espécies sacramentais; mas, a conservação
e a corrupção não têm a mesma causa. Logo, de nenhum modo as espécies sacramentais podem
corromper-se.
Mas, em contrário, os nossos sentidos percebem quando as hóstias se putrefazem e corrompem.

SOLUÇÃO. — A corrupção é um movimento do ser para o não ser. Ora, como dissemos, as espécies
sacramentais conservam o mesmo ser que antes tinham quando existiam as substâncias do pão e do
vinho. Portanto, assim como a substância desses acidentes podia corromper-se, quando existiam as
substâncias do pão e do vinho, assim também o pedem desaparecidas essas substâncias. Ora, esses
acidentes podiam primeiro, corromper-se de dois modos: essencial e acidentalmente. - Essencialmente,
como pela alteração das qualidades, e pelo aumento ou diminuição da quantidade. Não, certo, ao modo
do aumento ou diminuição de que só os corpos animados são susceptíveis, e tais não são as substâncias
do pão nem a do vinho mas por adição ou divisão. Pois, como diz Aristóteles, pela divisão uma dimensão
se corrompe e se torna em duas; pela adição, ao contrário, de duas se faz uma só. E deste modo,
manifestamente podem corromper-se tais acidentes, depois da consagração. Porque a própria
quantidade dimensiva remanescente é susceptível de divisão e de adição; e sendo sujeito de qualidades
sensíveis, como dissemos, pode também ser o sujeito da alteração delas, como, por exemplo, se se
alterasse a cor ou o sabor do pão e do vinho. De outro modo, poderiam corromper-se acidentalmente,
pela corrupção do sujeito. E, desta maneira, podem corromper-se mesmo depois da consagração.
Embora, pois, o sujeito não permaneça, permanece porem o ser que tais acidentes tenham no sujeito,
ser próprio e conforme a esse sujeito. Por onde, esse ser pode corromper-se por força de um agente
contrário, assim como se corrompia a substância do pão ou do vinho; a qual também não se corrompia,
senão por alteração precedente dos acidentes.
Devemos porém distinguir entre esses dois modos das referidas corrupções. Pois o corpo e o sangue de
Cristo, sucedendo-se neste sacramento à substância do pão e do vinho, desde que os acidentes sofram
uma alteração tal, que não bastasse a corromper o pão e o vinho, por causa dessa alteração não deixa o
corpo e o sangue de Cristo de estar neste sacramento. Quer a alteração se opere no concernente à
qualidade, por exemplo, quando se muda um pouco a cor ou o sabor do pão e do vinho; Quer no
concernente à qualidade, como quando se divide o pão ou o vinho em partes tais, que ainda possam
conservar a natureza do pão ou do vinho. Se porem a alteração for tão grande, a ponto de corromper-se
a substância do pão ou do vinho, o corpo e o sangue de Cristo não permanecem neste sacramento. E
isso, quer no tocante às qualidades, como quando de modo tal alteram-se a cor, o sabor e outras
qualidades do pão e do vinho, que já não podem com essa alteração conservar·se a natureza de um ou
de outro. Ou também no tocante à qualidade, por exemplo, se o pão se reduzisse a pó ou o vinho se
dividisse em partes tão diminutas, que já não permitissem as espécies deste ou de aquele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É da essência da corrupção destruir a substância do ser.
Por onde, enquanto o ser de uma forma permanece unido à matéria, é consequência da corrupção o
separar-se a forma, da matéria. Se, porém tal, ser não existisse unido à matéria, mas fosse semelhante
ao que a ela está unido, poderia a forma ser destruída pela corrupção, mesmo sem a existência da
matéria, e é o que se dá neste sacramento, como do sobredito se colhe.

RESPOSTA À SEGUNDA. — As espécies sacramentais, embora sejam formas sem matéria, conservam,
contudo o ser que antes na matéria tinham.

RESPOSTA À TERCEIRA. — A corrupção dessas espécies não é milagrosa, mas natural. Pressupõe,
contudo o milagre feito na consagração, a saber, que essas espécies sacramentais conservam o ser, sem
sujeito, que antes tinham num sujeito: assim como um cego milagrosamente iluminado vê de maneira
natural.

## Art. 5 — Se das espécies sacramentais pode provir alguma geração.
O quinto discute-se assim. — Parece que das espécies sacramentais nada pode ser gerado.

1. — Pois, o gerado, de alguma matéria o é, porque do nada é gerado, embora do nada possa provir o
ser, por criação. Ora, as espécies sacramentais nenhuma outra matéria têm a não ser o corpo de Cristo,
que é incorruptível. Logo, parece que das espécies sacramentais nada pode ser gerado.

2. Demais. — Coisas que não são do mesmo gênero não podem provir umas das outras; assim, da
brancura não procede a linha. Ora, o acidente e a substância diferem genericamente. Logo, as espécies
sacramentais, sendo acidentes, parece que delas nenhuma substância pode ser gerada.

3. Demais. — A substância corpórea que delas for gerada há de ter acidentes. Se, portanto das espécies
sacramentais for gerada alguma substância corpórea, necessàriamente do acidente será gerada a
substância e o acidente, isto é, dois, de um; o que é impossível. Logo, é impossível, das espécies
sacramentais ser gerada uma substância corpórea.
Mas, em contrário, pelos sentidos podemos aprender que certos seres são gerados, das espécies
sacramentais, ou cinzas, se forem queimadas; ou vermes, se se putrefizerem; ou pó, se forem trituradas.

SOLUÇÃO. — Sendo a corrupção de um ser a geração de outro, como diz Aristóteles, necessariamente
alguma geração há de provir, das espécies sacramentais corruptas, como dissemos. Pois, não se
corrompem de modo a desaparecerem totalmente, quase reduzidas ao nada; mas manifestamente lhes
sucede um corpo sensível. Como, porém, delas pode algum ser gerar-se, é difícil compreender. Pois,
como é manifesto, do corpo e do sangue de Cristo, que aí verdadeiramente estão nada é gerado, por
serem as espécies sacramentais incorruptíveis. Se, pois, a substância do pão ou do vinho permanecesse
neste sacramento, ou a matéria deles, seria fácil compreender que deles é gerado o sensível que lhes
sucede, como certos afirmaram. Mas isto é falso, como estabelecemos. Por isso disseram outros, que as
causas geradas não o são das espécies sacramentais, mas do ar circunstante. - O que por muitas razões
aparece ser impossível. - Primeiro, porque o ser delas gerado aparece logo como alterado e corrupto.
Ora, nenhuma alteração ou corrupção se manifestou antes, no ar circunstante. Por onde daí não se
poderiam gerar vermes ou cinzas. Segundo, porque a natureza do ar não é tal, que dele, por tais
alterações, sejam gerados tais seres. - Terceiro, porque pode dar-se que em grande quantidade sejam
queimadas ou putrefatas hóstias consagradas, nem seria possível uma tão grande quantidade de corpo
térreo ser gerado do ar, sem que este se tornasse de uma grande e muito sensível espessidão. - Quarto,
porque o mesmo poderia dar-se com os corpos sólidos circunstantes, como o ferro ou as pedras, que
permanecem intactos depois da geração dos referidos corpos. Por onde, essa posição não pode manter-
se, por contrariar o que manifestamente aparece aos sentidos.
Por isso outros disseram, que, corrompendo-se as espécies, reaparece a substância do pão e do vinho; e
assim, reaparecendo a substância do pão e do vinho são geradas as cinzas, ou os vermes ou matérias
semelhantes. - Mas esta posição deve ser tida como insustentável. - Primeiro, porque se a substância do
pão e do vinho se convertem no corpo e no sangue de Cristo, como dissemos, não pode a substância do
pão ou do vinho reaparecer, a não ser que o corpo ou o sangue de Cristo de novo se convertem na
substância do pão ou do vinho, o que é impossível; assim como, se o ar se convertesse no fogo, não
poderá o ar retornar, senão convertendo-se de novo o fogo em ar. Uma vez aniquilada porem a
substância do pão ou do vinho, não pode voltar de novo; porque o ser reduzido ao nada não pode
tornar-se no mesmo que numericamente era. Salvo se se disser, que as referidas substâncias voltam
porque Deus cria de novo outra nova substância, em lugar da primeira. - Segundo isso é impossível,
porque não podemos determinar quando reapareça a substância do pão. Pois, é manifesto, pelo
sobredito, que permanecendo as espécies do pão e do vinho, permanece o corpo e o sangue de Cristo,
que não existem simultaneamente com a substância do pão e do vinho neste sacramento, segundo o
que estabelecemos. Por onde a substância do pão e do vinho não pode voltar, permanecendo as
espécies sacramentais. Do mesmo modo, nem quando elas desaparecem, porque já a substância do pão
e do vinho existiria sem os acidentes próprios, o que é impossível Salvo se se disser que volta, no último
instante mesmo da corrupção das espécies, não por certo a substância do pão e do vinho - porque esse
instante mesmo é o em que começam a existir as substâncias geradas das espécies -, mas a matéria do
pão e do vinho, da qual, propriamente falando, diríamos que foi antes criado de novo, do que voltou. E,
nesta interpretação, poderia ser sustentada a referida posição. Mas, não é racional admitir-se nenhum
milagre neste sacramento senão em virtude mesmo da consagração, e esta não faz a matéria ser criada
nem retornar à existência. Por isso é melhor dizer que a própria consagração faz milagrosamente com
que a quantidade dimensiva do pão e do vinho seja o sujeito primeiro das formas subsequentes. Ora,
isto é próprio da matéria. Por onde e consequentemente, a essa referida quantidade dimensiva é
atribuído tudo o pertinente à matéria. Portanto, tudo o que poderia ser gerado da matéria do pão ou do
vinho, se ela fosse a existente, isso mesmo poderia ser gerado da quantidade dimensiva do pão ou do
vinho, não por um novo milagre, mas em virtude do milagre anteriormente feito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora ai não exista a matéria de que um ser é gerado,
contudo a quantidade dimensiva faz as vezes da matéria, como dissemos.

RESPOSTA À SEGUNDA. — Essas espécies sacramentais não são, por certo, acidentes; têm porém a
atividade e a virtude da substância, como se disse.

RESPOSTA À TERCEIRA. – A quantidade dimensiva do pão e do vinho conserva a natureza própria, e
recebe milagrosamente a virtude e a propriedade da substância. Por isso, pode se transformar em uma
e outra, isto é, na substância e na dimensão.

## Art. 6 — Se as espécies sacramentais podem nutrir.
O sexto discute-se assim. — Parece que as espécies sacramentais não podem nutrir.

1. — Pois, diz Ambrósio: Este não é o pão material que comemos, mas o pão da vida eterna, que
sustenta a substância da nossa alma. Ora, tudo o que nutre entra no corpo. Logo, este pão não nutre. E
o mesmo se diga do vinho.

2. Demais. — Como diz o livro De generatione, nós nos nutrimos de aquilo mesmo de que somos feitos.
Ora, não espécies sacramentais são acidentes de que o homem não é feito; pois, o acidente não é parte
da substância. Logo parece que as espécies sacramentais não podem nutrir.

3. Demais. — O Filósofo diz que o alimento nutre enquanto determinada substância; e faz crescer
enquanto tem uma certa quantidade. Ora as espécies sacramentais não são substâncias. Logo, não
podem nutrir.
Mas, em contrário, o Apóstolo, falando deste sacramento, diz: Uns têm fome e outros estão mui fartos.
E diz a Glosa a esse lugar, que ele se refere aqueles que, depois da celebração do sagrado mistério e da
consagração do pão e do vinho, reclamavam as suas oblações e, não comungando com os outros, as
tornavam sós a ponto de com isso se fartarem. O que não poderia ser se as espécies sacramentais não
nutrissem. Logo, a espécies sacramentais nutrem.

SOLUÇÃO. — Esta questão não oferece dificuldades, tendo sido já resolvida a precedente. Pois, a
comida nutre por se converter na substância do ser nutrido. Ora, como dissemos, as espécies
sacramentais podem converter-se em qualquer substância delas geradas. E pela mesma razão podem
converter-se no corpo humano mediante a qual podem converter-se em cinzas ou em vermes. Logo, é
claro que nutrem. Certos, porém, dizem, que não nutrem verdadeiramente, como se se convertessem
no corpo humano, mas nutrem e confortam, por uma certa alteração dos sentidos, assim como nós nos
confortamos pelo odor da comida e nos inebriamos com o cheiro do vinho. Mas essa opinião os nossos
sentidos a demonstram como falha. Pois, tal nutrição não nos basta por muito tempo, por necessitar o
nosso corpo de uma nutrição continua, por causa das perdas das suas energias. E, contudo poderíamos
sustentar-nos por muito tempo, tomando hóstias e vinho consagrado, em grande quantidade.
Semelhantemente, é insustentável a opinião segundo a qual as espécies sacramentais nutrem por causa
da forma substancial do pão e do vinho, que remanesce. E o é, quer porque essa substância não
remanesce, como dissemos. Quer por não ser ato da forma o nutrir, mas, antes da matéria, que recebe
a forma do ser nutrido, quando desaparece a da nutrição. Por isso diz Aristóteles, que a nutrição,
começando por dissemelhança, acaba pela semelhança.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Feita a consagração, em dois sentidos podemos dizer
que há pão neste sacramento. Num considerando as espécies mesmas do pão, que conservam o nome
da substância primitiva, como ensina Gregório. Em outro sentido podemos chamar pão ao corpo mesmo
de Cristo, pão místico, que desceu do céu. Assim, quando Ambrósio diz este pão não se transforma no
corpo, toma a palavra pão no segundo sentido, porque o corpo de Cristo não se converte no corpo
nosso, mas nos conforta a alma. Mas não se refere ao pão no primeiro sentido.

RESPOSTA À SEGUNDA. — As espécies sacramentais, embora não entrem na composição do corpo
humano, contudo nele se convertem, como dissemos.

RESPOSTA À TERCEIRA. — As espécies sacramentais, embora não sejam substâncias, têm contudo a
virtude da substância, como dissemos.

## Art. 7 — Se as espécies sacramentais se fracionam neste sacramento.
O sétimo discute-se assim. — Parece que as espécies sacramentais não se fracionam, neste
sacramento.

1. — Pois, segundo o Filósofo, dizemos que os corpos podem fracionar-se, por causa da determinada
posição dos seus poros. O que não se pode atribuir ás espécies sacramentais. Logo, as espécies
sacramentais não podem fracionar-se.

2. Demais. — Da fração resulta o som. Ora. às espécies sacramentais não dão nenhum som; pois, como
diz o Filósofo, produz som o corpo duro com superfície plana. Logo, as espécies sacramentais não se
fracionam.

3. Demais. — O que comemos também, fracionamos e mastigamos. Ora, comemos o verdadeiro corpo
de Cristo, segundo o diz o Evangelho: O que come a minha carne e bebe o meu sangue. Logo, também
fracionamos e mastigamos o corpo de Cristo. Por isso diz a confissão de Berengário: Estou de acordo
com a santa Igreja Romana, confessando de coração e de boca, que o pão e o vinho postos no altar,
depois da consagração são o verdadeiro corpo e sangue de Cristo, verdadeiramente tocado pelas mãos
dos sacerdotes, fracionado e torturado pelos dentes dos fiéis. Logo, não podemos dizer que as espécies
sacramentais são fracionadas.
Mas, em contrário, a fração resulta da divisão da quantidade. Ora, no caso vertente, nenhuma
quantidade se divide, senão as espécies sacramentais; pois, nem o corpo de Cristo, que é incorruptível,
nem a substância do pão, que não permanece. Logo, as espécies sacramentais se fracionam.

SOLUÇÃO. — Os antigos professavam várias opiniões sobre essa matéria. Assim, certos, (como Abelardo
e Hugo Vitorino), diziam que neste sacramento não havia real e verdadeiramente fração senão só para
os olhos dos espectadores. - Mas isto é insustentável. Porque neste sacramento da verdade os sentidos
não se enganam naquilo que podem legitimamente julgar; e entre essas coisas está a fração pela qual a
multiplicidade resulta da unidade, sendo uma e outra sensíveis comuns, como o mostra Aristóteles. Por
isso outros disseram haver aí verdadeira fração, sem substância existente. - Mas também isso encontra
os nossos sentidos. Pois vemos neste sacramento uma quantidade, primeira dotada de unidade, depois
dividida em muitas partes; a qual é forçosamente o objeto da fração. - Não podemos porém dizer que o
corpo mesmo de Cristo seja fracionado. Primeiro, por ser incorruptível e impossível. Segundo, por estar
em cada parte, como estabelecemos o que por certo encontra a possibilidade de fracionar-se. Donde se
concluí que a fração se funda, como no sujeito, na quantidade dimensiva do pão, como os outros
acidentes. E sendo as espécies sacramentais n sacramento do verdadeiro corpo de Cristo, a fração
dessas espécies é o sacramento da paixão do Senhor, que sofrem verdadeiramente o corpo de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como as espécies sacramentais são susceptíveis
de rarefação e de condensação, consequentemente também o são de porosidade e portanto, de ser
fracionadas.

RESPOSTA À SEGUNDA. — Da condensação resulta a dureza. E portanto desde que as espécies
sacramentais são susceptíveis de condensação, resulta por consequência que o são da dureza e
portanto da sonoridade.

RESPOSTA À TERCEIRA. — Aquilo que comemos, na sua espécie própria, isso mesmo fracionamos e
mastigamos, nessa espécie. Ora, o corpo de Cristo não é comido em sua espécie própria, mas na espécie
sacramental. Por isso, àquilo do Evangelho - A carne para nada aproveita - diz Agostinho: Isto deve
entender-se no sentido dos que carnalmente o entendiam. Pois, por carne entendiam a cortada do
cadáver ou a vendida nos açougues. Por isso o corpo mesmo de Cristo não se fraciona, senão na espécie
sacramental. - Sendo neste sentido, que deve entender- se a confissão de Berengário: referindo-se a
fração e a tortura dos dentes à espécie sacramental, sob a qual verdadeiramente está o corpo de Cristo.

## Art. 8 — Se com o vinho consagrado pode-se misturar outro líquido.
O oitavo discute-se assim. — Parece que o vinho consagrado não pode misturar-se com outro líquido.

1. — Pois toda causa misturada com outra recebe a qualidade desta. Ora, nenhum liquido pode receber
a qualidade das espécies sacramentais, porque esses acidentes não tem sujeito como se disse. Logo,
parece que nenhum liquido pode misturar-se com as espécies sacramentais do vinho.

2. Demais. — Se um líquido fosse misturado com as referidas espécies, necessariamente de ambas se
faria um só. Ora, não podem resultar uma unidade, nem do liquido, que é uma substância, e mais das
espécies sacramentais, que são acidentes; nem do líquido, e mais do sangue de Cristo, o qual em razão
da sua incorruptibilidade, não é susceptível de adição nem de diminuição. Logo, nenhum líquido pode
ser misturado com o vinho consagrado.

3. Demais. — O líquido misturado com o vinho consagrado parece que também se tornaria consagrado,
assim como a água misturada com água benta também fica benta. Ora, o vinho consagrado é o
verdadeiro sangue de Cristo. Logo, também o líquido misturado com ele seria o sangue de Cristo. E
assim, existiria sangue de Cristo de outro modo que não a consagração, o que é inadmissível. Logo, com
o vinho consagrado não pode misturar-se nenhum líquido.

4. Demais. — Não há mistura de dois seres, quando um deles se corrompe totalmente, como diz
Aristóteles. Misturada com qualquer líquido, parece que se corrompe totalmente a espécie sacramental
do vinho de modo que sob ela deixa de estar o sangue de Cristo. Quer por serem a grandeza e a
pequenez diferenças de quantidade, que diversificam, como o branco e o negro diversificam a cor. Quer
também porque o liquido misturado, não se lhe oferecendo nenhum obstáculo havia de difundir-se por
todo o outro; e assim desapareceria o sangue de Cristo, cuja existência neste sacramento não se
compadece com o de nenhuma outra substância. Logo, nenhum líquido pode misturar-se com o vinho
consagrado.
Mas, em contrário, os sentidos nos atestam que pode um líquido misturar-se com o vinho, tanto depois
como antes da consagração.

SOLUÇÃO. — A verdade, nesta questão, se manifesta pelo que já foi dito. Pois, como dissemos as
espécies remanescentes neste sacramento, assim como adquirem, em virtude da consagração, o modo
de existir da substância, assim também adquirem o modo da atividade e da passividade dela, de
maneira que podem agir e sofrer tudo o que agiria e sofreria a substância se estivesse presente. Ora, é
manifesto que se aí estivesse a substância do vinho, poderia um outro líquido misturar-se com ela. Mas
dessa mistura diverso seria o efeito, quanto à forma do líquido e quanto à quantidade. Se pois, um
líquido se misturasse em tão grande quantidade que pudesse difundir-se por todo o vinho, todo este
ficaria misturado. Ora, o misto de dois outros corpos nenhum deles é; mas cada um deles passa a ser um
terceiro, composto de ambos. Donde resultaria que o vinho primeiro existente não permaneceria, se o
líquido misturado fosse de outra espécie. - se porem o liquido adjunto fosse da mesma espécie, por
exemplo, vinho misturado com vinho, permaneceria por certo a mesma espécie, mas o vinho não ficaria
numericamente o mesmo. O que o declara a diversidade dos acidentes; por exemplo, sendo um vinho
branco e outro, tinto. Se porém o líquido adjunto fosse em tão pequena quantidade que não pudesse
difundir-se por todo o vinho, não ficaria todo este misturado, mas só uma parte dele. A qual não
permaneceria idêntica e individualmente a mesma, por causa da mistura de matéria estranha. Mas
permaneceria da mesma espécie, não só se fosse misturada uma quantidade pequena de líquido da
mesma espécie, mas ainda se fosse de espécie diferente. Porque uma gota de água, misturada com
muito vinho, transforma-se na espécie do vinho, como o diz Aristóteles.
Ora, ê manifesto pelo sobredito, que o corpo e o sangue de Cristo permanecem neste sacramento
enquanto as referidas espécies permanecem numericamente as mesmas; pois, é consagrado um
determinado pão e um determinado vinho. Por onde, se a mistura de um líquido qualquer for tanta que
atinja todo o vinho consagrado, tornando-o misto, já será ele numericamente outro e aí não mais estará
o sangue de Cristo. Se porem a adjunção do líquido for em tão pequena quantidade que não possa
difundir-se pelo todo, mas só por uma parte das espécies, nessa parte do vinho consagrado deixa de
estar o sangue de Cristo, permanecendo porém na outra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Inocêncio III diz em uma Decretal: Os acidentes também
afetam o vinho acrescentado; porque acrescentada água, fica com o sabor do vinho. Pois, tanto podem
os acidentes mudar de sujeito como o sujeito, de acidentes. Assim que a natureza cede ao milagre e o
poder tem império sobre o que nos é habitual. Não podemos porem entendê-lo no sentido em que o
acidente do vinho, anteriormente à consagração, venha depois a existir numericamente o mesmo, no
vinho acrescentado; senão que essa mudança se dá mediante ação da substância. Assim, os acidentes
remanescentes do vinho conservam a ação substancial, conforme dissemos; de modo que afetam o
líquido acrescentando, alterando-o.

RESPOSTA À SEGUNDA. — O líquido acrescentado ao vinho consagrado de nenhum modo se mistura
com a substância do sangue de Cristo. Mistura-se porem com as espécies sacramentais; mas de modo
que, feita a mistura, corrompem-se as referidas espécies, total ou parcialmente, da maneira pela qual,
como dissemos antes, essas espécies podem gerar a certos seres. Mas se se corromperem totalmente,
já não haverá nenhuma questão, pois o todo será uniforme. Sendo porem parcial a corrupção delas,
haverá por certo uma só dimensão quanto à continuidade quantitativa, mas não quanto ao modo de
existir. Porque, uma parte dela existirá sem sujeito, e a outra num sujeito. Como se um corpo fosse
constituído de dois metais haverá um só corpo sob o aspecto quantitativo mas não um só
especificamente.

RESPOSTA À TERCEIRA. — Como diz Inocêncio III, na Decretal citada se depois da consagração do cálice
se lhe acrescentar mais vinho, este por certo não se transforma em sangue nem com o sangue se
mistura; mas, misturado com os acidentes do vinho já existente, difunde-se por todos os lados no corpo
sob eles latente, sem o molhar. Mas isto se dá quando a mistura do líquido estranho não for tamanha a
ponto de o corpo de Cristo deixar de existir no todo. Então diz que se difunde por todos os lados; não
que atinja o sangue de Cristo nas suas dimensões próprias, mas nas dimensões sacramentais, sob as
quais está contido. - Nem colhe o símile da água benta; pois, essa bênção nenhuma alteração causa na
substância da água, como o faz a consagração do vinho.

RESPOSTA À QUARTA. — Certos disseram que, por pequena que seja a mistura do líquido estranho, a
substância do corpo de Cristo deixa de estar sob o todo. E isso pela razão aduzida. Mas esta não é
cogente. Pois a grandeza e a pequenez diversificam a quantidade dimensiva, não quanto à essência dela,
mas quanto à determinação da medida. – Semelhantemente, também o líquido acrescentado pode ser
de tal modo pouco, que pela sua pouquidade fique impedido de difundir-se pelo corpo; e não só pelas
suas dimensões. As quais, embora não tenham sujeito, contudo obstam ao outro líquido, como o fazia a
substância se ai existisse. conforme o que já dissemos antes.