# Questão 14: Das fraquezas do corpo, que Cristo assumiu na natureza
humana.
Em seguida devemos tratar das fraquezas que Cristo assumiu em a natureza humana. E, primeiro, das
fraquezas do corpo. Segundo, das fraquezas da alma.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se o Filho de Deus devia assumir a natureza humana com as suas fraquezas corpóreas.
O primeiro discute-se assim. — Parece que o Filho de Deus não devia ter assumido a natureza humana
com as suas fraquezas corpóreas.

1. — Pois, assim como a alma está unida pessoalmente ao Verbo de Deus, assim também o corpo. Ora, a
alma de Cristo tinha uma omnimoda perfeição, quanto à graça e quanto à ciência, como se disse. Logo,
também o seu corpo devia ser a todas as luzes perfeito, sem nenhuma fraqueza.

2. Demais. — A alma de Cristo contemplava o Verbo de Deus pela contemplação com que o vêem os
bem aventurados, como se disse; e assim, era bem-aventurada. Ora, a beatitude da alma glorifica o
corpo. Assim, diz Agostinho: Deus fez a alma de tão potente natureza, que da sua plenissima beatitude
redunda também em a natureza inferior, que é o corpo, não beatitude, própria de quem frui e
contempla; mas, a plenitude da saúde, isto é, o vigor da incorrupção. Logo, o corpo de Cristo foi
incorruptível e sem nenhuma fraqueza.

3. Demais. — A pena resulta da culpa. Ora, Cristo são tinha nenhuma culpa, segundo a Escritura: O qual
não cometeu pecado. Logo, também não deviam existir nele as fraquezas corpóreas, que são penais.

4. Demais. — Ninguém, que tenha sabedoria, assume o que o priva do seu fim próprio. Ora, as referidas
fraquezas do corpo impedem de muitos modos o fim da Encarnação. Primeiro, porque, por elas os
homens ficavam impedidos de conhecê-la, segundo aquilo da Escritura: Vimo-lo e não tinha parecença
do que era; feito um objeto de desprezo e o último dos homens, um varão de dores e experimentado
nos trabalhos; e o seu rosto se achava como encoberto e parecia desprezível; por onde, nenhum caso
fizemos dele. Segundo, porque assim não se cumpria o desejo dos Santos Patriarcas, de cuja pessoa diz
a Escritura: Levanta-te, levanta-te, arma-te de fortaleza, o braço do Senhor. Terceiro, porque mais
convenientemente pela fortaleza do que pela fraqueza podia ser superado o poder do diabo e sanada a
fraqueza humana. Logo, parece que era conveniente que o Filho de Deus assumisse a natureza humana
com as suas fraquezas ou deficiências corpóreas.
Mas, em contrário, o Apostolo: À vista de tudo quanto ele padeceu e em que foi tentado é poderoso
para ajudar também aqueles que são tentados. Ora, ele veio pará nos auxiliar, donde o dizer a Escritura:
Levantei os meus olhos aos montes, de donde me virá socorro. Logo, era conveniente que o Filho de
Deus assumisse a carne sujeita às fraquezas humanas de modo que pudesse por ela sofrer e ser tentado
e assim trazer-nos auxílio.

SOLUÇÃO. — Era conveniente que o Filho de Deus assumisse um corpo sujeito às fraquezas e às
deficiências humanas, sobretudo por três razões. — Primeiro porque o Filho de Deus, tendo assumido a
carne, veio ao mundo para satisfazer pelo pecado do gênero humano. Ora, satisfaz pelo pecado de
outrem quem assume a pena devida ao pecado deste. Ora, essas misérias do corpo, a saber, a morte, a
fome, a sede e outras semelhantes, são a pena do pecado, introduzido no mundo por Adão, segundo
aquilo do Apóstolo: Por um homem entrou o pecado neste mundo e pelo pecado a morte. Por onde, era
conveniente, quanto ao fim da Encarnação, que tais penalidades ele as sofresse em nossa carne, por
nós, conforme a Escritura: Verdadeiramente ele foi o que tomou sobre si as nossas fraquezas. —
Segundo, para fundar a fé na Encarnação. Pois, como não seria a natureza humana conhecida dos
homens senão enquanto sujeita a essas misérias do corpo, se o Filho de Deus a tivesse assumido sem
elas, não seria considerado verdadeiro homem, nem teria uma carne verdadeira, mas fantástica, como o
ensinavam os Maniques. E por isso, no dizer do Apóstolo, ele se aniquilou a si mesmo, tomando a
natureza de servo, fazendo-se semelhante aos homens e sendo reconhecido na condição como homem.
Donde o ter Tomás refeito a sua fé em Cristo, depois de lhe haver contemplado as chagas, segundo
refere o Evangelho. Terceiro, para nos dar um exemplo de paciência, suportando virilmente os
sofrimentos e as misérias humanas. Donde o dizer o Apóstolo: Sofreu tal contradição dos pecadores
contra a sua pessoa, para que não vos fatigueis, desfalecendo em vossos ânimos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A satisfação pelo pecado de outrem tem, como sua
matéria; as penas sofridas por esse pecado; mas tem como princípio o hábito da alma que inclina a
vontade a satisfazer por outro, donde tira a satisfação a sua eficácia; pois, não seria eficaz a satisfação se
não procedesse da caridade, como depois se dirá. E por isso era necessário fosse a alma de Cristo
perfeita quanto ao hábito das ciências e das virtudes, para que tivesse a faculdade de satisfazer; e
necessário também era que o seu corpo estivesse sujeito às misérias para que lhe não faltasse a matéria
da satisfação.

RESPOSTA À SEGUNDA. — Da relação natural que há entre a alma e o corpo resulta o redundar no
corpo a glória da alma. Mas, essa relação natural, em Cristo, depende da vontade da sua divindade, em
virtude da qual a beatitude permanecia na alma, sem derivar para o corpo, ao passo que a carne sofria
os sofrimentos da natureza passível, segundo aquelas palavras de Damasceno: Por beneplácito da divina
vontade era permitido à carne sofrer e realizar as suas operações próprias.

RESPOSTA À TERCEIRA. — A pena sempre resulta da culpa atual ou original daquele que é punido, umas
vezes; e outras, daquele que satisfaz as penas por ele. Tal o que se deu com Cristo, conforme à Escritura:
Ele foi ferido pelas nossas iniquidades, foi quebrantado pelos nossos crimes.

RESPOSTA À QUARTA. — As fraquezas assumidas por Cristo não impediam a fé na Encarnação; ao
contrário, a promovia, como dissemos. Embora essas fraquezas lhe ocultassem a divindade,
manifestavam-lhe contudo a humanidade, que é via conducente à divindade, segundo o Apóstolo:
Temos acesso a Deus por Jesus Cristo. Quanto aos antigos Patriarcas, eles desejavam em Cristo não
certamente a força do corpo, mas a espiritual, pela qual venceu o diabo e sanou a fraqueza humana.

## Art. 2 — Se Cristo estava necessariamente sujeito às misérias humanas.
O segundo discute-se assim. — Parece que Cristo não estava necessariamente sujeito às misérias
humanas.

1. — Pois, diz a Escritura : Foi oferecido porque ele mesmo quis, referindo-se à oblação à paixão. Ora, a
vontade se opõe à necessidade. Logo, Cristo não estava necessariamente sujeito às misérias do corpo.

2. Demais. — Damasceno diz: Cristo nada fez coagido, mas tudo o fez voluntariamente. Ora, o voluntário
não é necessário. Logo, às referidas misérias não estava Cristo necessariamente sujeito.

3. Demais. — A necessidade imposta por quem é mais poderoso. Ora, nenhuma criatura é mais
poderosa que a alma de Cristo, a quem pertencia conservar o corpo próprio. Logo, essas misérias ou
fraquezas não as sofreu Cristo necessariamente.
Mas, em contrário, o Apóstolo: Enviou Deus a seu Filho em semelhança de carne de pecado. Ora, é
condição da carne de pecado estar sujeita à necessidade de morrer e de padecer outros sofrimentos
semelhantes. Logo, estava a carne de Cristo sujeita a sofrer necessariamente essas misérias.

SOLUÇÃO. — Há duas espécies de necessidade. — Uma de coação, proveniente de um agente
extrínseco. E essa necessidade contraria a natureza e a vontade, pois, tanto esta como aquela implicam
um princípio intrínseco. — Outra é necessidade natural, resultante dos princípios naturais; por exemplo,
a forma e, assim, o fogo aquece necessariamente; ou a matéria e, assim, necessariamente se dissolve o
corpo composto de elementos contrários.
Ora, pela necessidade resultante da matéria, o corpo de Cristo havia necessariamente de morrer e
sofrer misérias semelhantes; pois, como dissemos, por beneplácito da divina vontade era permitido à
carne de Cristo agir e sofrer como lhe era apropriado. E essa necessidade é causada pelos princípios da
natureza humana, segundo dissemos. — Se nos referimos, porém, à vontade de coação, na medida em
que repugna à natureza corpórea, então, de novo, o corpo de Cristo, pela condição da sua natureza
própria, estava necessariamente sujeito à perfuração do cravo e às dores da flagelação. Mas, na medida
em que essa necessidade repugna à vontade, é manifesto que Cristo não padeceu necessariamente as
referidas misérias; nem relativamente à vontade divina, nem relativamente à sua vontade, em sentido
absoluto, enquanto dependente da deliberação da razão; mas só quanto ao movimento natural da
vontade, pelo qual ela naturalmente procura evitar a morte e os sofrimentos do corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando a Escritura diz que Cristo foi oferecido porque
ele mesmo quis, isso e refere à sua vontade divina, e à sua vontade humana enquanto dependente da
deliberação; embora a morte lhe fosse contra o movimento natural da sua vontade humana, como diz
Damasceno.

RESPOSTA À SEGUNDA. — A resposta resulta do que foi dito.

RESPOSTA À TERCEIRA. — Nada era mais poderoso que a alma de Cristo, absolutamente falando. Mas
nada impede que houvesse um poder maior para produzir tal efeito particular; assim, o cravo, para
perfurar. E isto digo, considerando unicamente a alma de Cristo na sua natureza e vontade próprias.

## Art. 3 — Se Cristo contraiu alguma fraqueza corporal.
O terceiro discute-se assim. — Parece que Cristo contraiu certas fraquezas corporais.
1 — Pois, diz-se que contraímos o que temos desde a origem da nossa natureza. Ora, Cristo, juntamente
com a natureza humana, trouxe originariamente, de sua mãe, as misérias e as fraquezas do corpo. Logo,
parece que contraiu essas fraquezas.

2. Demais. — O causado pelos princípios da natureza nós o recebemos juntamente com ela e isso se
chama contrair. Ora, as referidas penalidades são causadas pelos princípios da natureza humana. Logo,
Cristo as contraiu.

3. Demais. — Pelas referidas misérias Cristo é semelhante aos outros homens, como diz o Apóstolo. Ora,
os outros homens contraem essas misérias. Logo, parece que também Cristo as costraiu.
Mas, em contrário, essas misérias foram contraídas pelo pecado, segundo o Apóstolo: Por um homem
entrou o pecado neste mundo e pelo pecado a morte. Ora, em Cristo não existia nenhum pecado. Logo,
Cristo não contraiu essas misérias de que tratamos.

SOLUÇÃO. — A palavra, contrair implica uma relação entre causa e efeito: isto é, diz-se contraído o
efeito simultânea e necessariamente resultante da sua causa. Ora, a causa da morte e outras misérias
da natureza humana é o pecado, pois, pelo pecado entrou a morte neste mundo, na frase do Apóstolo.
Por onde, diz-se propriamente que contraem os referidos defeitos os que neles incorrem como uma
consequência do pecado. Ora, Cristo não tinha essas misérias como consequência do pecado; pois,
conforme Agostinho, comentando aquilo do Evangelho. - O que vem lá de riba é sobre todos, Cristo veio
lá de riba, isto é, das alturas da natureza humana, que tinha antes do pecado do primeiro homem. Pois,
assumiu a natureza humana sem pecado, na pureza que ela tinha no estado de inocência. E, do mesmo
modo, podia ter assumido a natureza humana sem as suas misérias. Por onde é claro que Cristo não
contraiu as referidas fraquezas, como se as tivesse em consequência do pecado; mas, por vontade
própria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A carne da Virgem foi concebida no pecado original e
por isso contraiu as referidas fraquezas. Mas a carne de Cristo assumiu, da Virgem, a natureza sem a
culpa. E semelhantemente, podia ter assumido a natureza sem a pena. Quis porém assumir a pena para
realizar a obra da nossa redenção, como se disse. E por isso teve as referidas fraquezas, não pelas
contrair, mas pelas voluntariamente assumir.

RESPOSTA À SEGUNDA. — A causa da morte e das outras misérias da natureza humana é dupla. Uma
remota, resultante dos princípios materiais do corpo humano; enquanto composto de elementos
contrários. Mas, essa causa ficava impedida pela justiça original. Por onde, a causa próxima da morte e
das outras misérias é o pecado, que privou da justiça original. E por isso, por Cristo não ter tido pecado,
dissemos que não contraiu tais misérias, senão que as assumiu voluntariamente.

RESPOSTA À TERCEIRA. — Cristo, por essas misérias, se equiparou aos outros homens, quanto à
qualidade delas, mas não quanto à causa, Por isso não as contraiu como os outros.

## Art. 4 — Se Cristo devia ter assumido todas as misérias corporais dos homens.
O quarto discute-se assim. — Parece que Cristo devia ter assumido todas as misérias corporais dos
homens.

1. — Pois, diz Damasceno: O inassuncível é incurável. Ora, Cristo veio curar todos os nossos males. Logo,
devia assumir todas as nossas misérias.

2. Demais. — Foi dito que, para Cristo satisfazer por nós, devia ter os hábitos perfectivos da alma e as
deficiências do corpo. Ora, a alma de Cristo assumiu a plenitude de todas as graças. Logo, o seu corpo
devia assumir todas as misérias.

3. Demais. — Dentre todas as misérias do corpo a principal é a morte. Ora, Cristo sofreu a morte. Logo,
com maior razão, devia ter assumido todas as outras misérias.
Mas, em contrário, não pode um mesmo sujeito ser sede de causas opostas. Ora, certas fraquezas são
opostas entre si, como causadas de princípios contrários. Logo, não podia Cristo ter assumido todas as
enfermidades humanas.

SOLUÇÃO. — Como dissemos, Cristo assumiu as misérias humanas para satisfazer pelo pecado da
natureza humana; e para isso era necessário que a sua alma tivesse a perfeição da ciência e da graça.
Por onde, Cristo devia assumir aquelas misérias resultantes do pecado comum de toda a natureza, mas
não repugnantes à perfeição da ciência e da graça. Assim, não era conveniente que assumisse todas as
deficiências ou enfermidades humanas. Pois, certas fraquezas repugnam à perfeição da ciência e da
graça, como a ignorância, a inclinação para o mal e a dificuldade para o bem. Outras não atingem geral e
totalmente a natureza humana, como se fossem resultantes do pecado dos nossos primeiros pais, mas
são provocadas em certos homens por causas particulares, como a lepra, o mal caduco e outras
semelhantes. E essas misérias são às vezes causadas pela culpa pessoal, por exemplo, pela alimentação
desordenada; outras, resultam da deficiência da virtude formativa. Ora, nada disso podia se dar com
Cristo, tanto por ter sido a sua carne concebida do Espírito Santo, de sabedoria e virtude infinitas e,
portanto, isenta do erro e da miséria; quanto por não ter Cristo praticado nada de desordenado no
regime da sua vida. Mas, há uma terceira categoria de misérias existente comumente em todos os
homens, em virtude do pecado dos nossos primeiros pais, como, a fome, a sede e outras tais. E todas
essas Cristo as assumiu. A elas lhes chama Damasceno sofrimentos naturais e sem· desonra; naturais
porque resultam em geral de toda a natureza humana; sem desonra, por não implicarem falta de ciência
nem de graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todas as misérias particulares dos homens são causadas
pela corruptibilidade e pela passibilidade do corpo, com a colaboração de certas causas particulares. Por
onde, quando Cristo sanou a passibilidade e a corruptibilidade do nosso corpo, pelas ter assumido,
sanou por consequência todos os outros defeitos.

RESPOSTA À SEGUNDA. — A plenitude de toda graça e ciência da alma de Cristo era, em si mesma, a
esta devida, por isso mesmo que foi assumida pelo Verbo de Deus. Mas, as nossas misérias ele as
assumiu por condescendência, para satisfazer pelos nossos pecados, e não porque em si mesmo
devesse assumi-las. Por isso não devia assumi-las todas, mas só aquelas que bastavam para satisfazer
pelo pecado de todo o gênero humano.

RESPOSTA À TERCEIRA. — A morte fere todos os homens em virtude do pecado dos nossos primeiros
pais; não porém certas outras misérias, embora sejam menores que a morte. Por onde não colhe a
comparação.