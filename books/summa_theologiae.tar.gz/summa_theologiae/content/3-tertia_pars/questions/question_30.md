# Questão 30: Da Anunciação da Santa Virgem
Em seguida devemos tratar da anunciação da Santa Virgem.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se era necessário fosse anunciado à Santa Virgem o que nela haveria de cumprir-se.
O primeiro discute-se assim. — Parece que não era necessário fosse anunciado à Santa Virgem o que
nela haveria de cumprir-se.

1. — Pois, parece que a anunciação só era necessária para obter o consentimento da Virgem. Ora,
parece que não era necessário o seu consentimento; pois, a conceição da Virgem foi prenunciada pela
profecia da predestinação, que se cumpre sem a cooperação do nosso arbítrio, como diz uma certa
glosa. Logo, não era necessário que tal anunciação se fizesse.

2. Demais. — A Santa Virgem tinha fé na Encarnação, sem a qual ninguém podia trilhar a via da salvação;
pois, como diz o Apóstolo, a justiça de Deus é infundida pela fé de Jesus Cristo em todos. Ora, quem crê
com certeza não precisa ser instruído ulteriormente. Logo, à Santa Virgem não lhe era necessário fosse
anunciada a encarnação do Filho de Deus.

3. Demais. — Assim como a Santa Virgem concebeu corporalmente a Cristo, assim também qualquer
alma santa o concebe espiritualmente. Donde o dizer o Apóstolo: Filhinhos meus, por quem eu de novo
sinto as dores do parto, até que Jesus Cristo se forme em vós. Ora, aos que devem conceber
espiritualmente a Cristo, essa conceição não lhes é anunciada. Logo, também não devia ser anunciado à
Santa Virgem, que conceberia no seu ventre ao Filho de Deus.
Mas, em contrário, está no Evangelho que o Anjo lhe disse: Eis conceberás no teu ventre e parirás um
filho.

SOLUÇÃO. — Era conveniente fosse anunciado à Santa Virgem que havia de conceber a Cristo. —
Primeiro, para que se observasse a ordem devida da união do Filho de Deus com a Virgem; isto é, para
que, antes da sua carne concebê-lo, a sua alma tivesse disso conhecimento. Donde o dizer Agostinho:
Maria foi mais feliz percebendo a fidelidade de Cristo que lhe concebendo a carne. E depois acrescenta:
A proximidade de seu Filho em nada teria sido útil a Maria, se não tivesse com maior felicidade trazido a
Cristo no seu coração, que na sua carne. — Segundo, para que pudesse ser mais certa testemunha desse
sacramento, quando nele fosse instruída por Deus. — Terceiro, para que oferecesse a Deus o voluntário
dom da sua submissão, ao que prontamente se ofereceu quando disse: Eis a escrava do Senhor. —
Quarto, para que se mostrasse haver um como matrimônio espiritual entre o Filho de Deus e a natureza
humana. Por isso, pela anunciação foi pedido o consentimento da Virgem, como representante de toda
a natureza humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A profecia da predestinação se cumpre sem a
cooperação causal do nosso arbítrio; não porém sem o consentimento dele.

RESPOSTA À SEGUNDA. — A Santa Virgem tinha fé expressa na Encarnação futura; mas, humilde como
era, não se julgava digna de tão altas coisas. Por isso, necessitava de ser instruída nessa matéria.

RESPOSTA À TERCEIRA. — A concepção espiritual de Cristo, mediante a fé, precede a anunciação,
realizada pela fé da pregação, segundo o dito do Apóstolo, que a fé é pelo ouvido. Mas nem por isso
sabe ninguém com certeza que tem a graça; conhece, porém, como verdadeira a fé que recebeu.

## Art. 2 — Se à Santa Virgem a anunciação devia ser feita por um anjo.
O segundo discute-se assim. — Parece que à Santa Virgem a anunciação não devia ter sido feita por
um anjo.

1. — Pois, aos anjos supremos a revelação se faz imediatamente por Deus, como diz Dionísio. Ora, a
Mãe de Deus foi exaltada acima de todos os anjos. Logo, parece que o mistério da Encarnação devia ter-
lhe sido feito imediatamente por Deus e não, por um anjo.

2. Demais. — Se nesta matéria era necessário observar a ordem comum, pela qual as coisas divinas são
reveladas aos homens pelos anjos, semelhantemente devem tais coisas ser reveladas a uma mulher, por
um homem; donde o dizer o Apóstolo: As mulheres estejam caladas nas igrejas, e se querem aprender
alguma coisa, perguntem-na em casa aos seus maridos. Logo, parece que à Santa Virgem devia ter sido
anunciado o mistério da Encarnação por algum homem, sobretudo que José, seu marido, foi nesse
assunto instruído pelo Anjo, como se lê no Evangelho.

3. Demais. — Ninguém pode anunciar convenientemente o que ignora. Ora, mesmo os anjos supremos
não conheceram plenamente o mistério da Encarnação; por isso Dionísio diz que da pessoa deles se
deve entender a pergunta da Escritura – Quem é este que vem de Edom? Logo, parece que por nenhum
anjo podia ser convenientemente anunciada a realização da Encarnação.

4. Demais. — Coisas maiores devem ser anunciadas por maiores embaixadores. Ora, o mistério da
Encarnação é o máximo, dos anunciados aos homens, pelos anjos. Logo, parece que se por algum anjo
devia ser anunciado, este deveria ser um dos da ordem suprema. Ora, Gabriel não é da ordem suprema,
mas da ordem dos arcanjos, que é a penúltima. Por isso a Igreja canta: Sabemos que, mandado por
Deus, Gabriel Arcanjo te anunciou. Logo, essa anunciação não foi convenientemente feita, por meio de
Gabriel Arcanjo.
Mas, em contrário, o Evangelho: Foi enviado por Deus o anjo Gabriel, etc.

SOLUÇÃO. — Foi conveniente que o mistério da Encarnação fosse anunciado à Mãe de Deus, por meio
de um anjo, por três razões. — Primeiro, para que, assim, se observasse a ordem divina, pela qual as
coisas divinas são transmitidas aos homens, mediante os anjos. Donde o dizer Dionísio, que do mistério
divino do amor de Jesus foram primeiro instruídos os anjos; depois, por meio deles a graça desse
conhecimento chegou até nós. Assim, pois, o diviníssimo Gabriel anunciou a Zacarias que dele havia de
nascer um profeta: e a Maria, como nela se cumpriria o mistério Trierárquico da inefável formação de
Deus. — Segundo, porque era conveniente a restauração do gênero humano, que Cristo havia de
realizar. E por isso diz Beda: Convinha à restauração da humanidade, que um anjo fosse enviado por
Deus à Virgem. que devia consagrar o parto de um Deus. Pois, a causa primeira da perdição da
humanidade foi o diabo, quando mandou a serpente ir ter com a mulher a fim de enganá-la com o
espírito de soberba. — Terceiro, porque convinha à virgindade da Mãe de Deus. E por isso diz Jerônimo:
Foi bem o anjo ter sido enviado à Virgem, pois, a virgindade é cognata da natureza angélica. Pois, na
verdade, viver na carne, como se esta não existisse, não é vida terrena, mas celeste.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Mãe de Deus era superior aos anjos quanto à
dignidade, para que Deus a elegeu. Mas, quanto ao estado da vida presente, era inferior aos anjos; pois,
o próprio Cristo, em razão da sua vida passível, por um pouco foi feito menor que os anjos, na frase do
Apóstolo. Contudo, como Cristo foi ao mesmo tempo mortal e bem-aventurado, não precisava ser
instruído pelos anjos, quanto ao conhecimento das coisas divinas. Mas, a Mãe de Deus ainda não se
achava no estado de bem-aventurança. Por isso, precisava ser instruída pelos anjos, quanto à sua divina
conceição.

RESPOSTA À SEGUNDA. — Como diz Agostinho, a Santa Virgem escapa a certas leis gerais humanas.
Pois, nem teve muitas concepções, nem viveu sob poder de um homem, isto é, de um marido, ela que,
conservando a sua virgindade íntegra, concebeu Cristo, do Espírito Santo. Por isso não lhe devia ser
instruída no mistério da Encarnação, por nenhum homem, mas pelo anjo. E por isso também foi ela
instruída nele, antes de José; pois, ao passo que o foi antes da sua concepção, José só depois dela o foi.

RESPOSTA À TERCEIRA. — Como é claro pela autoridade citada de Dionísio, os anjos conheceram o
mistério da Encarnação; contudo interrogavam, desejando saber, de Cristo, mais perfeitamente, as
razões desse mistério, que são incompreensíveis a todo intelecto criado. Por isso Máximo diz, que não
podemos duvidar se os anjos conheceram a Encarnação futura. Mas escapou-lhes a investigável
concepção do Senhor, e o modo pelo qual o Filho, todo inteiro no Pai que o engendrou, podia também
ficar inteiramente em todos, e mesmo num seio virginal.

RESPOSTA À QUARTA. — Certos afirmam que Gabriel era da suprema ordem dos anjos, fundados no
dito de Gregório: Era digno de ter vindo o anjo supremo a anunciar o sumo dos mistérios. Mas, daí não
se conclui que fosse ele o supremo de todas as ordens, mas só quanto aos anjos; pois era da ordem dos
arcanjos. Por isso, a Igreja lhe dá o nome de arcanjo e o próprio Gregório diz que se chamam arcanjos os
que anunciam as coisas mais elevadas. É bastante crível, pois, que foi ele o primeiro na ordem dos
arcanjos. E, como diz Gregório, esse nome lhe quadra ao ofício, pois, Gabriel significa força de Deus. E
assim, onde, pela força de Deus devia ser anunciado aquele que, Senhor das virtudes e poderoso no
combate, vinha para vencer os poderes do ar.

## Art. 3 — Se o anjo anunciante devia aparecer à Virgem em forma corpórea.
O terceiro discute-se assim. — Parece que o anjo anunciante não devia aparecer à Virgem em forma
corpórea.

1. — Pois, ver em espírito é mais nobre que ver materialmente, como diz Agostinho; e sobretudo é mais
conveniente ao anjo, porque pela visão do espírito o anjo é visto na sua substância e, pela material, é
visto na figura corpórea que assumiu. Ora, assim como o anunciar da concepção divina era conveniente
fosse feito por um núncio supremo, assim também parece que lhe competia o sumo gênero de visão.
Logo, parece que o anjo anunciante apareceu à Virgem em visão espiritual.

2. Demais. — Parece que a visão imaginária também é mais nobre que a visão corpórea, tanto quanto a
imaginação é mais elevada potência que os sentidos. Ora, o anjo apareceu a José durante o sono, em
visão imaginária, como se lê no Evangelho. Logo, parece que também devia aparecer à Santa Virgem em
visão imaginária e não em visão material.

3. Demais. — A visão corpórea de uma substância espiritual perturba quem a vê; por isso a Igreja canta,
da Virgem — e a Virgem pasmou à vista da luz. Ora, melhor teria sido que a sua alma tivesse sido
preservada de tal perturbação. Logo, não foi conveniente que a referida anunciação se fizesse por uma
visão corpórea.
Mas, em contrário, Agostinho põe na boca da Santa Virgem as palavras seguintes: Veio a mim o Arcanjo
Gabriel com as faces rútilas, com vestes coruscantes, de aspecto admirável. Ora, isso só pode pertencer
a uma visão corpórea. Logo, o anjo que anunciou à Santa Virgem lhe apareceu em forma corpórea.

SOLUÇÃO. — O anjo anunciante apareceu à Mãe de Deus em forma corpórea. E isto era conveniente. —
Primeiro, quanto ao anunciado. Pois, o anjo vinha anunciar a Encarnação do Deus invisível. Portanto, era
conveniente que, para anunciar esse acontecimento, uma criatura invisível assumisse uma forma que
lhe permitisse aparecer visivelmente. Porque, além disso, todas as aparições do Antigo Testamento se
ordenem à aparição pela qual o Filho de Deus se manifestou encarnado. — Segundo, era conveniente à
dignidade da Mãe de Deus, que havia de receber o Filho de Deus não somente na sua alma, mas
também corporalmente, no seu ventre. Por isso, não somente a sua alma, mas também os sentidos do
seu corpo deviam ser favorecidos com a visão angélica: — Terceiro, era isso conveniente à certeza do
que foi anunciado. Pois, o que é visto com os olhos nós o apreendemos mais certamente do que aquilo
que imaginamos. Donde o dizer Crisóstomo, que o Anjo se apresentou real e visivelmente à Virgem e
não em sonhos. Pois, devendo receber do anjo uma comunicação de tão alta importância, ela tinha
necessidade de uma aparição solene, núncia de um acontecimento tão relevante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A visão intelectual é superior à visão imaginária ou
corporal, se for só. Mas, o próprio Agostinho diz ser mais excelente a profecia acompanhada
simultaneamente da visão intelectual e da imaginária, que a que o é só de uma delas. Ora, a Santa
Virgem não somente percebeu uma manifestação espiritual. Por isso, essa aparição foi mais nobre. Mas
teria sido ainda mais, se tivesse visto o próprio anjo, na sua substância, por uma visão Intelectual. Mas o
estado de um mortal não se compadecia com ver um anjo em essência.

RESPOSTA À SEGUNDA. — A imaginação é certamente uma potência mais alta que os sentidos
exteriores. Como porém a base do conhecimento humano são os sentidos, o conhecimento sensível é o
dotado da máxima certeza, pois, os princípios do conhecimento hão de sempre ter maior certeza. Por
isso José, a quem o anjo apareceu durante o sono, não viu uma aparição tão excelente com o que viu a
Santa Virgem.

RESPOSTA À TERCEIRA. — Como diz Ambrósio, ficamos perturbados e alheiados dos sentidos quando
surpreendidos pela ação inesperada de uma força superior. E isto se dá não só em se tratando de uma
visão real como também imaginária. Donde o dizer a Escritura, que ao pôr do sol veio um profundo sono
sobre Abraão e um horror grande e temeroso o acometeu. Mas, essa perturbação não pode ser nociva
ao homem ao ponto de dever ficar ele privado de uma aparição angélica. — Primeiro, porque o fato
mesmo de ser o homem elevado acima de si mesmo, como o requer a sua dignidade, enfraquece a parte
inferior da sua natureza, donde procede a perturbação referida, assim como a concentração do calor
natural no interior do corpo faz tremerem os membros exteriores. — Segundo porque, como diz
Orígenes, o anjo que apareceu, conhecedor da natureza humana, começou por acalmar a perturbação.
Por isso, tanto a Zacarias como a Maria, vendo-os: perturbados, disse-lhes: Não temas. Razão pela qual,
como se lê na vida de Antão, não é difícil discernirmos os espíritos bem-aventurados, dos maus. Se, pois,
ao temor suceder a alegria, saibamos que o auxílio vem de Deus, porque a segurança da alma é sinal da
presença da majestade. Se, ao contrário, o temor incutido permanecer, é inimigo o que vemos. — E,
além disso, a perturbação mesma da Virgem era própria do pudor virginal. Pois, como diz Ambrósio,
tremer é próprio dos virgens, bem como o temerem com a aproximação de qualquer homem e se
amedrontarem quando algum lhes dirige a palavra. — Mas certos dizem, que como a Santa Virgem
estava acostumada a ver os anjos, não ficou perturbada com a aparição angélica; mas, tomada de
espanto com o que o anjo lhe dizia por não se julgar digna de coisas tão sublimes. Por isso o Evangelista
não diz que ficou perturbada com a visão, mas sim, com as palavras do anjo.

## Art. 4 — Se a anunciação se cumpriu em perfeita ordem.
O quarto discute-se assim. — Parece que a anunciação não se cumpriu em perfeita ordem.

1. — Pois, a dignidade de Mãe de Deus depende da prole concebida. Ora, a causa deve manifestar-se
antes do efeito. Logo, o Anjo devia ter anunciado à Virgem a conceição do filho antes de a ter saudado
com a proclamação da sua dignidade.

2. Demais. — Não podemos exigir prova em matéria onde não pode haver dúvida nem em matéria que
pode ser sujeita a dúvidas. Ora, parece que o Anjo anunciou, primeiro, o de que a Virgem duvidava e,
por duvidar, perguntou. Como se fará isso? E só depois acrescentou a prova tirada tanto do exemplo de
Isabel, como da omnipotência de Deus. Logo, a anunciação do anjo se realizou numa ordem
inconveniente.

3. Demais. — O mais não pode ser suficientemente provado pelo menos. Ora, mais admirável foi dar à
luz uma virgem, que se o fizesse uma velha. Logo, não foi prova suficiente a do Anjo, provando a
conceição virginal pela conceição de uma velha.
Mas, em contrário, o Apóstolo: Tudo o proveniente de Deus é ordenado. Ora, o Anjo foi enviado por
Deus para anunciar à Virgem, como diz o Evangelho. Logo, a anunciação pelo Anjo se cumpriu de
maneira mui ordenada.

SOLUÇÃO. — A anunciação se cumpriu pelo Anjo na ordem conveniente. Pois, o Anjo tinha tríplice
desígnio em relação à Virgem. — Primeiro, tornar-lhe o coração atento à consideração de um tão
grande acontecimento. O que fez, saudando-a com uma nova e insólita saudação. Por isso diz Orígenes,
que se a Virgem, que conhecia a lei judaica, soubesse que uma saudação semelhante tivesse algum dia
sido feita a alguém, não teria ficado amedrontada do seu caráter estranho. E nessa saudação o Anjo
anunciou-lhe em primeiro lugar a sua idoneidade para a concepção, quando disse — Cheia de graça;
depois, anunciou a conceição, ao declarar-lhe — O Senhor é contigo; e enfim prenunciou-lhe a honra
consequente, com as palavras – Bendita tu entre as mulheres. - O segundo desígnio do anjo era instruí-
la no mistério da Encarnação, que nela devia cumprir-se. E isso o fez, prenunciando-lhe a conceição e o
parto, quando disse – Eis, conceberás no teu ventre, etc.; e lhe mostrou a dignidade do filho concebido,
dizendo — Este será grande, etc. E também quando lhe revelou o modo da conceição, com as palavras
— O Espírito Santo descerá sobre ti. — O terceiro desígnio ao Anjo era induzir-lhe o ânimo ao
consentimento. O que fez com o exemplo de Isabel e pela razão deduzida da omnipotência divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Para uma alma humilde nada causa maior admiração
que ouvir falar da sua própria excelência. Pois, a admiração desperta soberanamente a atenção da alma.
Por isso o Anjo, querendo tornar atenta a mente da Virgem, para ouvir a revelação de um tão grande
mistério, começou por elogiá-la.

RESPOSTA À SEGUNDA. — Ambrósio diz expressamente que a Santa Virgem não duvidou das palavras
do Anjo. São palavras suas: Mais comedida é a resposta de Maria que as palavras do sacerdote. Esta
pergunta: Como se fará isto? Aquele responde: Por onde conhecerei eu a verdade dessas coisas? Recusa
assim a sua fé, negando conhecer tais coisas. A Virgem, porém, não duvida, no momento em que
pergunta como se fará, da sua realização. — Agostinho, porém, parece dizer que a Virgem deixou-se
invadir da dúvida, quando afirmou: A Maria que hesita sobre a concepção, o anjo afirma a sua
possibilidade. Mas, essa dúvida foi, antes, de admiração que de incredulidade. Por isso, o anjo aduz a
sua prova, não para adquirir a confiança da Virgem, mas antes para lhe remover a admiração.

RESPOSTA À TERCEIRA. — Como diz Ambrósio, se muitas mulheres estéreis conceberam, foi para que se
acreditasse no parto da Virgem. Por isso foi aduzido o exemplo da estéril Isabel; não como um
argumento suficiente, mas como um exemplo figurado. Por isso, para confirmação desse exemplo,
acrescenta o argumento peremptório da omnipotência de Deus.