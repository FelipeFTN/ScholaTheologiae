# Questão 40: Do gênero de vida que levou Cristo
Em seguida, depois do pertencente a vinda de Cristo ao mundo ou ao seu princípio, resta tratar do mais
da sua vida. E primeiro, devemos considerar o gênero de vida que levou. Segundo, a sua tentação.
Terceiro, a doutrina. Quarto, os milagres.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se Cristo devia participar da sociedade humana ou viver uma vida solitária.
O primeiro discute-se assim. — Parece que Cisto não devia participar da natureza humana, mas viver
uma vida solitária.

1. — Pois, Cristo, na sua vida, devia mostrar que era não somente homem, mas também Deus. Ora, a
Deus não cabe participar da sociedade humana, como diz a Escritura: Exceto os deuses, que não tem
comércio com os homens. E o Filósofo diz que quem vive solitário, ou é um animal feroz, isto é, se o fizer
por selvageria, ou é Deus, se o fizer a fim de contemplar a verdade. Logo, parece que não devia Cristo
participar da sociedade humana.

2. Demais. — Cristo enquanto viveu a vida mortal, devia tê-la vivido perfeitíssima. Ora a perfeitíssima
das vidas é a contemplativa, como se estabeleceu na Segunda Parte. Ora, a vida contemplativa é por
excelência uma vida solitária, segundo aquilo da Escritura: Eu o levarei
à soledade e lhe falarei ao coração. Logo, parece que Cristo devia viver uma vida solitária.

3. Demais. — O gênero de vida de Cristo devia ser uniforme, pois, devia sempre aparecer como a mais
perfeita. Ora, às vezes Cristo procurava lugares solitários, fugindo à multidão; donde o dizer Remígio:
Como lemos no Evangelho, o Senhor tinha três refúgios - a barca, o monte, o deserto, e a um deles se
acolhia sempre que a multidão o cercava. Logo, devia viver sempre uma vida solitária.
Mas, em contrário, a Escritura: Depois disto foi ele visto na terra e conversou com os homens.

SOLUÇÃO. — O gênero de vida de Cristo devia ser tal que se enquadrasse nos fins da Encarnação para a
qual veio ao mundo. Pois, veio ao mundo: primeiro, para manifestar a verdade, como ele próprio o
disse: Eu para isso nasci e ao que vim ao mundo foi para dar testemunho da verdade. Logo, não devia
ocultar-se, levando uma vida solitária, mas aparecer em público, pregando publicamente. Por isso, diz
no Evangelho aos que queriam retê-lo: Às outras cidades é necessário também que eu anuncie o reino
de Deus; que para isso é que fui enviado. - Segundo, veio para livrar os homens do pecado, segundo
aquilo do Apóstolo: Cristo veio a este mundo para salvar os pecadores. Donde o dizer Crisóstomo:
Embora fixando-se num lugar qualquer, Cristo pudesse atrair todos a si para lhe ouvirem a pregação,
contudo não o fez, dando-nos o exemplo, a fim de perambularmos na busca dos que correm o risco de
perecer, como o pastor procura a ovelha perdida e o médico procura curar o doente. - Terceiro, veio
para nos fazer entrar na posse de Deus, no dizer do Apóstolo. Por isso, vivendo na familiaridade dos
homens, era conveniente lhes inspirasse a confiança para se lhe achegarem a ele. Donde o dizer o
Evangelho: E aconteceu que estando Jesus sentado à mesa numa casa, eis que, vindo muitos publicanos
e pecadores, se sentaram a comer com ele e com os seus discípulos. Expondo o que, diz Jerónimo: Os
pecadores, vendo o publicano converter-se dos seus pecados para uma vida melhor, tendo feito
penitência a eles também não desesperavam da sua salvação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo quis pela sua humanidade manifestar a divindade.
Por isso, convivendo com os homens, como é próprio do homem, manifestou a todos a sua divindade,
pregando e fazendo milagres, e vivendo uma vida inocente e justa no meio deles.

RESPOSTA À SEGUNDA. — Como dissemos na Segunda Parte, a vida contemplativa, absolutamente
considerada, é melhor que a ativa, cuja atividade versa sobre coisas materiais. Mas a vida ativa, pela
qual, pregando e ensinando, se transmite aos outros o fruto da contemplação, é
mais perfeita que a puramente contemplativa; porque uma tal vida pressupõe as riquezas da
contemplação. Por isso Cristo escolheu tal vida.

RESPOSTA À TERCEIRA. — A atividade de Cristo foi para instrução nossa. E assim, a fim de dar exemplo
aos pregadores, que nem sempre devem se apresentar em público, às vezes o Senhor se retraía da
multidão. E assim procedeu por três razões, como lemos no Evangelho. - Umas vezes, para o seu
repouso corporal. Assim, lemos que o Senhor disse aos seus discípulos = Vinde, retirai-vos a algum lugar
deserto e descansai um pouco. Porque eram muitos os que entravam e saíam e não tinham tempo para
comerem. - Outras vezes, porém, por causa de oração, conforme aquele passo: E aconteceu naqueles
dias, que saiu ao monte a orar e passou toda a noite em oração a Deus. Ao que diz Ambrósio: Leva-nos
pelo seu exemplo aos preceitos da virtude. - Enfim, outras vezes, para nos ensinar a evitar os favores
humanos. Donde aquilo do Evangelho - Vendo Jesus a grande multidão do povo, subiu a um monte - diz
Crisóstomo: Preferindo o monte e a solidão à cidade e à praça pública, ensinou-nos a não fazer nada por
ostentação e a fugir da agitação, sobretudo quando devermos tratar das coisas necessárias.

## Art. 2 — Se Cristo devia viver neste mundo uma vida austera.
O segundo discute-se assim - Parece que Cristo devia levar uma vida austera neste mundo.

1. — Pois, Cristo muito mais que João pregou a perfeição da vida. Ora. João levou uma vida austera,
para com o seu exemplo despertar nos homens o desejo de uma vida perfeita. Assim, diz Mateus: O
mesmo João tinha um vestido de peles de camelo e uma cinta de couro em roda dos seus rins; e a sua
comida eram gafanhotos e mel silvestre. Expondo o que diz Crisóstomo: Era admirável ver tão grande
mortificação num corpo humano, o que mais lhe atraía os judeus. Logo, parece, com muito maior razão,
que a Cristo convinha a austeridade de vida.

2. Demais. — A abstinência se ordena à continência; assim, diz a Escritura - Comerão e não ficarão
fartos; eles se deram à fornicação
e não cuidaram de se retirar dela. Ora, Cristo guardava continência e propunha a ser observada pelos
outros, como lemos no Evangelho: Há uns castrados que a si mesmos se castraram por amor do reino
dos céus. O que é capaz de compreender isto compreenda-o. Logo, parece
que tanto Cristo como os seus discípulos deviam levar uma vida de austeridades.

3. Demais. — É risível começar alguém uma vida austera para depois passar a vive-Ia às soltas; contra
esse poderíamos aplicar o lugar do Evangelho, este homem começou a praticar e não no pode acabar.
Ora, Cristo viveu uma vida rigorosíssima, depois do batismo, permanecendo no deserto e jejuando
quarenta dias e quarenta noites. Logo, não era admissível que depois de tão grandes austeridades
passasse a viver uma vida comum.
Mas, em contrário, o Evangelho: Veio o Filho do homem, que come e bebe.

SOLUÇÃO. — Como dissemos, convinha aos fins da Encarnação que Cristo não vivesse uma vida
solitária, mas participasse da sociedade humana. Ora, quem convive com outros é convenientíssimo que
se conforme com o gênero de vida deles, segundo o Apóstolo: Fiz-me tudo para todos. Por isso, foi
convenientíssimo que Cristo tomasse comida e bebida como os homens comumente o fazem. Donde o
dizer Agostinho. O Evangelho refere que João não comia nem bebia, porque não tomava aquela
alimentação de que os judeus se serviam. E se o Senhor não usasse de alimentos, o Evangelho não diria
que, comparado com João, ele comia e bebia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Senhor, no gênero de vida que abraçou, deu exemplo
de perfeição em tudo o que respeita à salvação de maneira essencial. Ora, a abstinência da comida e da
bebida não é de necessidade essencial para a salvação, segundo aquilo do Apóstolo: O reino de Deus
não é comida nem bebida. E expondo o lugar do Evangelho - a sabedoria foi justificada por seus filhos -
diz Agostinho: Porque os santos Apóstolos entendem que o reino de Deus não consiste em comida nem
bebida, mas em sofrer com equanimidade, de modo que nem a abundância os ensoberbeça nem os
deprima a pobreza. E acrescenta, que não é o uso de tais causas, mas a sensualidade com que é feito,
que constitui culpa. Pois, tanto uma como outra vida são lícitas e louváveis: guardarmos a abstinência,
separados da convivência habitual com os homens; e vivermos a vida comum na sociedade dos outros.
Por isso o Senhor quis nos dar o exemplo de ambos esses gêneros de vida. Ao passo que João, como diz
Crisóstomo, não tinha por si mais que a sua vida e a sua santidade, Cristo tinha o testemunho dos seus
milagres. Deixando, pois, a João os rigores do jejum escolheu um caminho contrário, sentando-se à
mesa dos publicanos, a comer e beber com eles.

RESPOSTA À SEGUNDA. — Assim como os outros homens alcançam, pela abstinência, a virtude da
continência, assim Cristo, em si e nos seus discípulos, continha a carne pela virtude da sua divindade.
Donde o dizer o Evangelho: Os fariseus e os discípulos de João jejuavam, mas não os discípulos de Cristo.
Explicando o que Beda diz, que João não bebia vinho nem outra alguma bebida que pudesse embriagar;
assim, não dispondo de nenhum poder superior à natureza, ganha um aumento de mérito na
abstinência. Ao passo que o Senhor, tendo por natureza o poder de perdoar os pecados, porque havia
de afastar-se dos homens que podia tornar mais puros do que os entregues à abstinência?

RESPOSTA À TERCEIRA. — Como diz Crisóstomo, para aprenderes quão grande éo bem do jejum, e que
escudo é contra o diabo e o quanto, depois do batismo, devemos nos dar ao jejum e fugir a
sensualidade, Cristo jejuou, não por precisar, mas para nos instruir. Mas não ultrapassou os limites do
jejum marcados pelos exemplos de Moisés e de Elias, para não inspirar nenhuma dúvida sobre a
realidade da carne que assumiu. - No sentido místico, porém, Gregório explica, que o número quarenta
é observado, no jejum, ao exemplo de Cristo, porque a virtude do decálogo se exerce nos quatro livros
do santo Evangelho; e o número dez, quatro vezes repetidos, produz o de quarenta. Ou porque o nosso
corpo mortal consta de quatro elementos, e pelos prazeres sensíveis resistimos aos preceitos do Senhor,
que nos foram transmitidos pelo Decálogo. - Ou, segundo Agostinho: Todas as regras da sabedoria se
reduzem a conhecer o Criador e a Criatura. O Criador é a Trindade, o Pai, o Filho e o Espírito Santo.
Quanto à criatura, uma parte dela, a alma, é invisível, a qual é atribuído o número ternário; pois, o
mandamento nos ordena amar a Deus de três modos - de todo o coração, de todo a alma e de todo o
entendimento; a outra parte - o corpo, é visível, e se lhe atribui o número quaternário, por causa do
calor, da humildade, da frigidez e da secura. Por onde, o número dez, que resume toda a disciplina,
multiplicado por quatro, isto é, pelo número atribuído ao corpo - pois, por meio do corpo é que a alma
governa - forma o número quarenta. Por isso, o tempo durante o qual gememos e sofremos é designado
pelo número quarenta. - Nem por isso houve inconveniente em Cristo, depois do jejum no deserto,
voltar à vida comum. Pois esse é o gênero de vida conveniente aquele que deve transmitir aos outros o
fruto da contemplação; e tal foi a vida que Cristo assumiu: primeiro, vacar à contemplação, para depois
descer a agir em público, convivendo com os outros. Por isso diz Beda: Cristo jejuou, para não
transgredir o preceito: comeu com os pecadores a fim de sentindo os efeitos da sua graça, tu lhe
reconheças o poder.

## Art. 3 — Se Cristo devia viver neste mundo uma vida pobre.
O terceiro discute-se assim. — Parece que Cristo não devia viver neste mundo uma vida pobre.

1. — Pois, Cristo devia assumir a vida mais digna de escolha. Ora, a vida mais digna de escolha é a
média, entre as riquezas e a pobreza, conforme àquilo da Escritura: Não me dês nem a pobreza nem as
riquezas; dá-me somente o que for necessário para viver. Logo, Cristo não devia viver uma vida pobre,
mas medíocre.

2. Demais. — As riquezas exteriores se ordenam a alimentar e vestir o corpo. Ora, Cristo alimentava-se e
vestia-se de acordo com a vida ordinária daqueles com quem convivia. Logo parece que devia viver do
modo comum, uma vida mediana entre rica e pobre, e não na extrema pobreza.

3. Demais. — Cristo nos deu a todos o exemplo da humildade, segundo aquilo do Evangelho: Aprendei
de mim que sou manso e humilde de coração. Ora, sobretudo aos ricos é que se deve pregar a
humildade, no dizer do Apóstolo: Manda os ricos deste mundo que não sejam altivos. Logo, parece que
Cristo não devia levar uma vida pobre.
Mas, em contrário, o Evangelho: O Filho do homem não tem onde reclinar a cabeça. Como se dissesse,
segundo o explica Jerônimo: Desejais seguir-me por causa das riquezas e dos bens do século, a mim tão
pobre que nem mesmo tenho um tugúrio e vivo sob o teto alheio? E aquilo do Evangelho - Para que os
não escandalizemos, vai ao mar - diz Jerônimo: Entendidas essas palavras pelo que significam, são uma
edificação para o ouvinte, advertindo-o ter sido tão grande a pobreza do Senhor a ponto de não ter com
que pagasse o tributo por si e pelo Apóstolo.

SOLUÇÃO. — Convinha a Cristo viver neste mundo uma vida pobre. - Primeiro, por condizer com o ofício
da pregação, por causa da qual disse ter vindo ao mundo: Vamos para as aldeias e cidades
circunvizinhas, porque também quero lá pregar; que a isso é que vim. Pois, os pregadores da palavra de
Deus hão de dar-se totalmente à pregação, desapegados completamente do cuidado das coisas
seculares. O que não podem fazer os possuidores de riquezas. Por isso, o próprio Senhor, enviando os
Apóstolos a pregar, disse-lhes: Não possuais ouro nem prata: E os próprios Apóstolos diziam: Não é
justo que nós deixemos a palavra de Deus e que sirvamos às mesas. - Segundo, porque assim como
sujeitou seu corpo à morte para nos conquistar a vida espiritual, assim sofreu a pobreza de bens
materiais, para nos conquistar as riquezas espirituais, segunda aquilo do Apóstolo: Sabeis que graça não
foi a de nosso Senhor Jesus Cristo que, sendo rico, se fez pobre por vosso amor, a fim de que vós fosseis
ricos pela sua pobreza. - Terceiro, porque, se tivesse riquezas, podiam atribuir-lhe a pregação à cobiça.
Por isso, diz Jerônimo, que se os discípulos tivessem riquezas, pareceria pregarem não com a vista na
salvação dos homens. mas no ganho. - Quarto, para tanto mais manifestar a grandeza da sua divindade,
quanto mais pobre a vida que levava. Por isso se diz no Concílio Efesino: Escolheu uma vida pobre e
humilde, tudo o que constitui mediania e obscuridade para o maior número para que se visse que foi a
divindade quem transformou a face da terra. Por isso, escolheu como sua mãe uma pobrezinha, uma
pátria paupérrima e foi pobre de bens; e isso mesmo te mostra o seu presépio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A superabundância das riquezas e a mendicidade,
enquanto ocasiões de pecar, devem ser cortadas pelos que querem viver uma vida virtuosa. Pois, a
abundância de riquezas é ocasião de soberba; a mendicidade, de roubo e de mentira ou ainda de
perjúrio. Ora, como Cristo era isento de todo pecado, não devia evitar uma e outra causa pela mesma
causa por que as evitava Salomão. Nem, além disso, qualquer mendicidade é ocasião de furto e de
perjúrio, como no mesmo lugar o ensina Salomão, mas só a que nos contraria a vontade para evitar a
qual o homem furta e perjura. Pois, a pobreza voluntária não tem esse perigo. E foi essa a escolhida por
Cristo.

RESPOSTA À SEGUNDA. — Alimentar-se e vestir-se ao modo ordinário qualquer o pode, não só
possuindo riquezas, mas ainda recebendo dos ricos o necessário. O que também se deu com Cristo.
Assim, como o Evangelho diz certas mulheres que seguiam a Cristo, que lhe assistiam de suas posses.
Pois, como diz Jerônimo, era uso dos judeus e em nada colidia com o costume antigo desse povo, que as
mulheres fornecessem de seus próprios bens o alimento e a roupa aos que as instruíam. Mas, como isso
podia causar escândalo aos gentios, Paulo declarou que rejeitou tais auxílios. Assim, pois, comum
subsistência podia existir sem os cuidados impedientes do dever da pregação; mas não a posse das
riquezas.

RESPOSTA À TERCEIRA. - No pobre por necessidade a humildade não é muito meritória. Mas no pobre
voluntário, como Cristo, a própria pobreza é sinal de uma humildade máxima.

## Art. 4 — Se Cristo viveu segundo a lei.
O quarto discute-se assim. — Parece que Cristo não viveu segundo a lei.

1. — Pois, a lei ordenava que nenhuma obra se fizesse no sábado, assim como Deus descansou no
sétimo dia de toda obra que fizera. Ora,
Cristo curou um homem no sábado e mandou-o levar o seu leito. Logo, parece que não viveu segundo a
lei.

2. Demais. — Cristo fez o que ensinou, segundo a Escritura: Jesus começou a fazer e a ensinar. Mas, ele
próprio ensinou que não é o que entra pela boca o que faz imundo o homem, o que vai contra o
preceito da lei, que dizia tornar-se o homem imundo por comer certos animais e ter contacto com eles.
Logo, parece que não viveu segundo a lei.

3. Demais. — Julgamos do mesmo modo tanto quem faz como quem consente, conforme aquilo do
Apóstolo: Não somente os que estas coisas fazem, senão também os que consentem aos que as fazem.
Ora, Cristo consentiu pelos excusar, os seus discípulos transgredirem a lei, quando arrancavam as
espigas no sábado. Logo, parece que Cristo não viveu segundo a lei.
Mas, em contrário, o Evangelho: Não julgueis que vim destruir a lei ou os profetas. Expondo o que,
Crisóstomo diz: Cumpriu a lei - primeiro, por não ter transgredido nenhuma das suas injunções;
segundo, justificando pela fé, o que a letra da lei não podia fazer.

SOLUÇÃO. — Cristo conformou totalmente a sua vida aos preceitos da lei. E para prová-la, quis
circuncidar-se: ora, a circuncisão é uma demonstração de cumprimento da lei, segundo aquilo do
Apóstolo: Protesto a todo homem que se circuncida que está obrigado a guardar toda a lei. - Ora, Cristo
quis viver obediente à lei: primeiro para assim aprovar a lei antiga. - Segundo, a fim de, observando-a,
consumá-la em si mesmo e terminá-la, mostrando como ela a si se ordenava. - Terceiro, para não dar
aos judeus ocasião de caluniá-lo. - Quarto, para livrar os homens da escravidão da lei, segundo o
Apóstolo: Enviou Deus a seu Filho, feito sujeito à lei, a fim de remir aqueles que estavam debaixo da lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nessa matéria, o Senhor se excusa de haver
transgredido a lei por três razões. - Primeiro, porque o preceito da santificação do sábado não proíbe as
obras divinas, mas, as humanas. Assim, embora Deus tivesse cessado de produzir novas criaturas no
sétimo dia, sempre porém a sua ação aparece na conservação e no governo das coisas. Ora, os milagres
operados por Cristo eram obras divinas. Donde o dizer o Evangelho: Meu Pai até agora não cessa de
obrar e eu obro também incessantemente. - Segundo, excusa-se por não proibir o referido preceito as
obras necessárias à saúde do corpo. Assim, ele próprio o disse: Não desprende cada um de vós nos
sábados o seu boi ou o seu jumento e não os tira da estribaria para os levar a beber? E mais adiante:
Quem há de entre vós que se o seu jumento ou o seu boi cair num poço em dia de sábado, o não tire
logo no mesmo dia? Ora, é manifesto que as obras milagrosas, feitas por Cristo, tinham em vista a saúde
do corpo e da alma. - Terceiro, porque esse preceito não proíbe as obras relativas ao culto de Deus.
Donde o 'dizer o Evangelho: Ou não tendes lido na lei que os sacerdotes nos sábados, no templo
quebrantam o sábado e ficam sem pecado? E noutro lugar diz que recebe um homem a circuncisão em
dia de sábado. Quanto ao fato de ter Cristo mandado ao paralítico levar o seu leito, no sábado, isso era
em vista do culto a Deus, isto é, para louvor da virtude divina. - Por onde é claro que não violava a lei do
sábado; embora os judeus falsamente lh’o exprobrassem, quando diziam: Este homem, que não guarda
o sábado não é de Deus.

RESPOSTA À SEGUNDA. — Com as palavras citadas, Cristo quis mostrar que a alma do homem não se
torna imunda pelo uso de nenhuns alimentos, quanto à natureza mesma deles, senão só quanto a
alguma significação que tenham. Por isso, diz Agostinho: A quem perguntar se o porco e o cordeiro são
de natureza pura, respondemos que toda criatura de Deus é pura; mas, em certo sentido, o cordeiro é
puro e o porco, impuro.

RESPOSTA À TERCEIRA. — Também os discípulos, quando, por terem fome, arrancaram as espigas ao
sábado, ficam excusados da transgressão à lei, pela necessidade da fome; assim como Davi não foi
transgressor da lei quando, ungido pela fome, comeu os pães que lhes era lícito comer.