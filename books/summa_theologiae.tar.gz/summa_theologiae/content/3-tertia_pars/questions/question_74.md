# Questão 74: Da matéria específica da Eucaristia
Em segunda devemos tratar da matéria deste sacramento. E primeiro da espécie da matéria. Segundo,
da conversão do pão e do vinho no corpo de Cristo. Terceiro, do modo de existir do corpo de Cristo
neste sacramento. Quarto, dos acidentes do pão e do vinho, que permanecem neste sacramento.
Na primeira questão discutem-se oito artigos:

## Art. 1 — Se a matéria deste sacramento é o pão e o vinho.
O primeiro discute-se assim: — Parece que a matéria deste sacramento não é o pão e o vinho.

1. — Pois, este sacramento deve representar mais perfeitamente a paixão de Cristo do que os
sacramentos da Lei Velha. Ora, as carnes dos animais, que eram a matéria dos sacramentos da Lei Velha,
representam mais expressivamente a paixão de Cristo, que o pão e o vinho. Logo, a matéria deste
sacramento devem ser antes as carnes dos animais, que o pão e o vinho.

2. Demais. — Este sacramento deve ser celebrado em toda parte. Ora, em muitas terras não há pão, e
em muitas outras não há vinho. Logo, o pão e o vinho não são a matéria conveniente deste sacramento.

3. Demais. — Este sacramento o recebem tanto sãos como enfermos. Ora, o vinho faz mal a certos
enfermos. Logo, parece que o vinho não deve ser matéria deste sacramento.
Mas, em contrário, Alexandre Papa (I) diz: Nas oblações dos sacramentos ofereçam-se no sacrifício só
pão e vinho misturado com água.

SOLUÇÃO. — Sobre a matéria deste sacramento cometeram-se muitos erros. - Assim, uns, chamados
Artotiritas, como o refere Agostinho, ofereciam pão e queijo neste sacramento, por pensarem que os
primeiros homens faziam oblações dos frutos da terra e das ovelhas. - Outros, os Catafrígios e os
Pepuzianos, como deles se conta, extratam o sangue de uma criança, por meio de pequenos ferimentos
feitos com punções em todo o corpo dela; e preparavam a sua como eucaristia, misturando esse sangue
com farinha e confeccionando assim um pão. — E outros enfim chamados Aquários, ofereciam neste
sacramento só água, a pretexto de sobriedade. Mas todos estes erros e outros semelhantes ficaram
excluídos por ter Cristo instituído este sacramento sob as espécies de pão e de vinho. E com razão. —
Primeiro, quanto ao uso de tal sacramento, que é a manducação. Pois, assim como a água é tomada no
sacramento do batismo para o uso da ablução espiritual, porque a ablução corporal é comumente feita
com água, assim o pão e o vinho, de que os homens comumente se nutrem, são tomados neste
sacramento para uso da manducação espiritual. — Segundo, quanto à paixão de Cristo, na qual o sangue
foi separado do corpo. Razão por que neste sacramento, memorial da paixão do Senhor, toma-se o pão
separadamente como o sacramento do corpo, e o vinho como o sacramento do sangue. — Terceiro,
quanto ao efeito considerado em cada um dos que o recebem. Porque, como diz Ambrósio, este
sacramento tem o poder de nos fortificar o corpo e a alma; e por isso a carne de Cristo é oferecida sob a
espécie de pão, para a saúde do corpo, e sob a espécie de vinho, para a salvação da alma; pois, como o
diz a Escritura, a alma da carne está no sangue. — Quarto, quanto ao efeito, em relação a toda a Igreja,
constitui da de diversos fiéis, assim como o pão é confeccionado de diversos grãos e o vinho corre de
diversas uvas, conforme à glosa, aquilo do Apóstolo: Todos nós somos um corpo, etc.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora as carnes dos animais imolados representem
expressivamente a paixão de Cristo, contudo convêm menos ao uso comum deste sacramento, e para
significar a unidade eclesiástica.

RESPOSTA À SEGUNDA. — Embora nem todas as terras produzam trigo e vinho, contudo podem ser
facilmente transportados a todas no quanto baste ao uso deste sacramento. Nem por falta de um
desses elementos, deve-se consagrar só o outro, pois, o sacramento não seria perfeito.

RESPOSTA À TERCEIRA. — O vinho tomado em pequena quantidade não pode fazer muito mal a
nenhum doente. Se contudo se teme que seja nocivo, não é necessário todos os que tomam o corpo de
Cristo tomarem também o sangue, como a seguir se dirá.

## Art. 2 — Se a matéria deste sacramento deve ser uma determinada quantidade de pão e de vinho.
O segundo discute-se assim. — Parece que a matéria deste sacramento deve ter uma determinada
quantidade de pão e de vinho.

1. — Pois, os efeitos da graça não são menos ordenados que os da natureza. Ora, como diz Aristóteles,
todos os seres existentes têm certos limites de grandeza e de crescimento. Logo e com muito maior
razão, a chamada Eucaristia, é, boa graça, implica uma quantidade determinada de pão e vinho.

2. Demais. — Aos ministros da Igreja não foi dado por Cristo um poder que redundasse em irrisão da fé
e dos seus sacramentos, segundo aquilo do Apóstolo: segundo o meu poder, que o Senhor me deu para
vossa edificação e não para a vossa destruição. Ora, seria a irrisão do sacramento se o sacerdote
quisesse consagrar todo o pão à venda no mercado e todo o vinho da adega. Logo, não pode fazer tal.

3. Demais. — Se alguém fosse batizado no mar, nem por isso toda a água do mar se santificaria pela
forma do batismo, mas só aquela com que recebe a ablução o corpo do batizado. Logo, nem neste
sacramento se pode consagrar uma quantidade supérflua de pão.
Mas, em contrário, o muito se apõe ao pouco e o grande, ao pequeno. Ora, nenhuma quantidade há tão
pequena, de pão ou de vinho, que não possa ser consagrada. Logo, nenhuma há tão grande, que
também não o possa ser.

SOLUÇÃO. — Certos foram de opinião, que o sacerdote não poderia consagrar uma quantidade imensa
de pão ou de vinho, por exemplo, todo o pão à venda no mercado, ou todo o vinho de um tonel. Mas
esta opinião não é verdadeira. Porque, em todos os seres materiais a versão de determinação da
matéria se deduz da ordenação para o fim; assim, a matéria da serra é o ferro, para que seja capaz de
cortar. Ora, o fim deste sacramento é o uso dos fiéis. Por onde e necessàriamente, a sua quantidade de
matéria é determinada relativamente ao uso deles. Mas não pode ser determinada relativamente ao
uso dos fiéis existentes atualmente; do contrário, um sacerdote com poucos paroquianos não poderia
consagrar muitas hóstias. Donde se conclui que a matéria deste sacramento deve ser determinada
relativamente ao uso dos fiéis, em absoluto ora, o número dos fiéis é indeterminado. Portanto, não se
pode dizer que a quantidade de matéria deste sacramento seja determinada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A matéria natural de um ser recebe a determinação da
sua quantidade, pela relação com a sua forma determinada. Ora, o número dos fiéis a que se o número
deste sacramento ordena, é indeterminado. Logo, a comparação não colhe.

RESPOSTA À SEGUNDA. — O poder dos ministros da Igreja a duas coisas se ordena: ao efeito próprio e
ao fim do efeito. Das quais a primeira não exclui a segunda. Por onde, se um sacerdote tiver a intenção
de consagrar o corpo de Cristo, visando um mau fim, por exemplo, por irrisão ou por venefício, pela
intenção desse mau fim peca; nem por isso, porém, pelo poder que lhe foi conferido, deixa de consagrar
o sacramento.

RESPOSTA À TERCEIRA. — O sacramento do batismo se consuma no uso da matéria. Por isso, pela
forma do batismo, não é santificada mais água do que a necessária do uso. Mas o sacramento da
Eucaristia se consuma na consagração da matéria. Logo, o símile não colhe.

## Art. 3 — Se a matéria deste sacramento deve ser pão de trigo.
O terceiro discute-se assim. Parece não ser necessário que a matéria deste sacramento seja pão de
trigo.

1. — Pois, este sacramento é comemorativo da paixão do Senhor. Ora, parece mais conveniente à
paixão do Senhor o pão de cevada, que é mais áspero, e do qual o Senhor deu de comer à multidão no
Monte, como o refere o Evangelho, que o pão de trigo. Logo, o pão de trigo não é a matéria própria
deste sacramento.

2. Demais. — A figura é o sinal da espécie, nos seres naturais. Ora, há certos grãos semelhantes em
figura ao grão de trigo, como o centeio e a aspelta, de que também em certos lugares se confecciona o
pão, para o uso deste sacramento. Logo, o pão de trigo não é a matéria própria dele.

3. Demais. — A mistura destrói a espécie. Ora, apenas se encontra farinha de trigo sem mistura de
outros grãos, se se fizer uma escolha especial de grãos. Logo, parece que o pão de trigo não é a matéria
própria deste sacramento.

4. Demais. — O que se corrompeu muda de espécie. Ora, há quem consagre com pão de trigo estragado
e que, portanto já não é pão de trigo. Logo, parece que tal pão não é matéria própria deste sacramento.
Mas, em contrário, neste sacramento está contido Cristo que se comparou ao grão de trigo, quando
disse: se o grão de trigo, que cai na terra, não morrer, fica êle só. Logo, o pão de trigo, ou tritica, é a
matéria deste sacramento.

SOLUÇÃO. — Como dissemos, para o uso deste sacramento escolhe-se matéria de uso mais comum
entre os homens. Ora, mais comumente usam os homens de pão de trigo; pois, os outros pães só foram
introduzidos por falta deste. E por isso cremos que Cristo instituiu a Eucaristia sob a espécie de tal pão.
Além disso, este pão é o mais nutritivo e, assim, mais convenientemente significa o efeito deste
sacramento. Logo, a matéria própria dele é o pão de trigo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pão de cevada é próprio a significar a dureza da Lei
Velha. Quer por causa da sua dureza, quer também porque, como diz Agostinho, o grão da cevada,
coberto de uma palha sigidíssima, ou significa a própria lei, dada para que nela o alimento vital da alma
ficasse oculto nos sacramentos corporíeos: ou o próprio povo ainda não purgado dos desejos carnais,
que como palha lhes aderia ao coração. Mas, o sacramento eucarístico pertence ao suave jugo de Cristo
e à verdade já manifestada e ao povo espiritual. Por isso, não seria a matéria conveniente dele o pão de
cevada.

RESPOSTA À SEGUNDA. — O gerador gera um ser semelhante em espécie; mas há uma certa
dissemelhança entre o gerador e o gerado, quanto aos acidentes, quer por causa da matéria, quer pela
debilidade da virtude gera triz. Se, pois, há grãos que possam ser gerados do grão do trigo — assim
como do grão semeado em terra má nasce o trigo candeal — desses pode ser confeccionada a matéria
deste sacramento. O que porem não se dá nem com a cevada, nem com a espelta, nem com o centeio, a
grão de todos mais semelhante ao do trigo. Quanto à semelhança de figura em tais casos, significa antes
a proximidade que a identidade específica; assim como a semelhança de figura põe de manifesto a
propinquidade, mas não a identidade de espécie, entre o lobo e o cão. Por onde, de tais grãos, que de
nenhum modo podem ser gerados da semente do trigo, não pode confeccionar-se um pão que seja a
matéria conveniente a este sacramento.

RESPOSTA À TERCEIRA. — Uma pequena mistura não destrói a espécie, porque o pouco é de certo
modo absolvido pelo muito. Por onde, sendo pequena mistura da farinha de outro grão com uma
quantidade muito maior de trigo, pode-se com isso fazer um pão que seja matéria conveniente a este
sacramento. Se porem a mistura for grande, por exemplo, em partes iguais ou quase, tal mistura muda a
espécie. Por onde, o pão assim feito não será matéria conveniente à Eucaristia.

RESPOSTA À QUARTA. — A corrupção do pão pode ser tal que lhe destrua a espécie; por exemplo,
quando se lhe muda a consistência, o sabor, a cor e acidentes semelhantes. Por isso, dessa matéria não
pode produzir-se o corpo de Cristo. Mas outras vezes a corrupção não é tamanha que destrua a espécie,
havendo apenas uma disposição para a corrupção, como o denunciará uma certa mudança de sabor. E
esse pão pode transformar-se no corpo de Cristo; mas peca quem o fez, por irreverência para com o
sacramento. Quanto ao amido, sendo trigo corrupto, não se pode confeccionar com ele pão que possa
transformar-se no corpo de Cristo; embora certos digam o contrário.

## Art. 4 — Se este sacramento deve celebrar-se com pão asmo.
O quarto discute-se assim. — Parece que este sacramento não deve ser celebrado com pão asma.

1. — Pois, devemos neste sacramento imitar a instituição de Cristo. Ora, parece que Cristo o instituiu
com pão fermentado, pois, como lemos na Escritura, os judeus de conformidade com a lei, começavam
a usar dos asmos no dia da Páscoa, celebrado na décima quarta lua; ao passo que Cristo instituiu este
sacramento na ceia que celebrou antes do dia da Páscoa, como o refere o Evangelho. Logo, também nós
devemos celebrar este sacramento com pão fermentado.

2. Demais. — As cerimônias legais já não devem observar-se no tempo da graça. Ora, usar de asmos era
uma cerimônia legal, como se lê na Escritura. Logo, neste sacramento da graça não devemos usar de
asmos.

3. Demais. — Como se disse, a Eucaristia é o ·sacramento da caridade, como o batismo, o da fé. Ora, o
fervor da caridade é simbolizado pelo fermento, como o ensina a Glosa àquilo do Evangelho: O reino dos
céus semelhante ao fermento, etc. Logo, este sacramento deve ser celebrado com pão fermentado.

4. Demais. — O ser asmo e fermentado são acidentes do pão, que lhe não variam a espécie. Ora, na
matéria do batismo nenhuma distinção se faz quanto à diferença nos acidentes da água; por exemplo,
se é salgada ou doce, quente ou fria. Logo neste sacramento nenhuma distinção se deve fazer, se o pão
é asmo ou fermentado.
Mas, em contrário, uma disposição canônica pune o sacerdote que ousar com pão fermentado e cálice
de madeira celebrar a solenidade da missa.

SOLUÇÃO. — Sobre a matéria deste sacramento duas coisas podemos considerar: o que é necessário e o
que é conveniente. - Necessário é ser o pão de trigo, como se disse; sem o que não há o sacramento.
Mas não é necessário que o pão seja asma ou fermentado, pois com qualquer deles pode ser o
sacramento celebrado. Conveniente é que cada um conserve o rito da sua Igreja ao celebrá-la. Sobre o
que são diversos os costumes das Igrejas. Assim, diz S. Gregório: A Igreja Romana oferece pães asmos;
porque o Senhor assumiu a nossa carne sem nenhuma mistura. Mas as Igrejas Gregas oferecem o pão
fermentado, porque o Verbo do Pai se revestiu de carne, assim como o fermento é misturado com
farinha. Por onde, assim como peca o presbítero da Igreja Latina que celebrar com pão fermentado,
assim também pecará o presbítero grego que na Igreja dos Gregos celebrar com pão asmo, perverter
assim o rito da sua Igreja. E contudo o costume de celebrar com pão asmo é mais racional. - Primeiro,
pela instituição de Cristo, que instituiu este sacramento no primeiro dia dos asmos, como lemos nos
Evangelhos. - Segundo, porque o pão é propriamente o sacramento do corpo de Cristo, concebido sem
nenhuma corrupção, mais que o da sua divindade, como a seguir se dirá. - Terceiro, porque isso melhor
convém à sinceridade dos fiéis, requerida pelo uso deste sacramento, segundo àquilo do Apóstolo:
Cristo, que é a nossa Páscoa, foi imolado, e assim solenizemos o nosso convite com os asmas da
sinceridade e da verdade. Contudo, o costume dos gregos tem alguma razão de ser, tanto pela
significação, a que alude Gregório; como pela detestação da heresia dos Nazareus, que misturavam com
o Evangelho as cerimônias da Lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como lemos na Escritura, a solenidade pascal começava
nas vésperas da décima quarta lua. E então Cristo, depois da imolação do cordeiro pascal, instituiu este
sacramento. Por isso, João diz que esse dia precedeu o dia da Páscoa: e os três outros Evangelistas
chamam primeiro dia dos asmas, aquele em que não conservavam os judeus em casa nada de
fermentado. O que já versámos antes, mais desenvolvidamente, no tratado da paixão do Senhor.

RESPOSTA À SEGUNDA. — Os que celebram com o asma não têm a intenção de observar as cerimônias
da lei, mas de se conformar com a instituição de Cristo. E por isso não são judaizantes. Do contrário
também o revidam os que celebram com pão fermentado, porque os judeus ofereciam fermentados os
pães das primícias.

RESPOSTA À TERCEIRA. — O fermento, pelo seu efeito de tornar o pão mais saboroso e maior, é o
símbolo da caridade. Mas, pela sua própria natureza especifica, significa a corrupção.

RESPOSTA À QUARTA. — O fermentado de certo modo é corrupto, e com pão corrupto não se pode
celebrar este sacramento, como se disse. Por isso, leva-se em maior conta a diferença, entre o pão asmo
e o fermentado, que a diferença da água quente e fria, no batismo. Poderia, porém, ser tão grande a
corrupção do pão fermentado, que com êle não se pudesse celebrar o sacramento.

## Art. 5 — Se é matéria própria deste sacramento o vinho da vide.
O quinto discute-se assim. — Parece que não é a matéria própria deste sacramento o vinho da vide.

1. — Pois, assim como a água é a matéria do batismo, assim o vinho, a deste sacramento. Ora, com
qualquer água pode-se celebrar o batismo. Logo, com qualquer vinho, por exemplo, com o de maçãs
granadas, de amoras ou de frutas semelhantes, pode-se celebrar este sacramento; tanto mais quanto
em certas terras não cresce a videira.

2. Demais. — O vinagre é uma espécie de vinho, extraído da uva, como diz Isidoro. Ora, com vinagre não
se pode celebrar este sacramento. Logo, parece que o vinho da vide não é a matéria própria dele.

3. Demais. — Assim como da vide se extrai o vinho puro, assim também o agraço e o mosto. Ora, com
estes não se pode celebrar a Eucaristia, conforme àquela disposição do Sexto Sínodo: Fomos informados
que em certas Igrejas os sacerdotes ajustavam uvas ao sacrifício da oblação; e assim distribuíam ao povo
uvas e vinho. Nós determinamos porém que os sacerdotes não mais assim procedam. E Júlio Papa
repreende certos que oferecem no sacramento do cálice do Senhor vinho que acabara de expremer, da
uva. Logo, parece que o vinho da uva não é a matéria própria deste sacramento.
Mas, em contrário, assim como o Senhor se comparou ao grão de trigo, assim também se comparou ao
da vide, quando disse: Eu sou a videira verdadeira. Ora, só o pão de trigo é a matéria deste sacramento,
como se disse. Logo, só o vinho da videira é a matéria própria dele.

SOLUÇÃO. — Só com o vinho da videira se pode celebrar este sacramento. — Primeiro, por causa da
instituição de Cristo, que o instituiu com esse vinho, como o demonstra o que êle próprio disse quando
o fez: Não tomarei a beber do fruto da vide. — Segundo, porque, como dissemos, para matéria deste
sacramento se toma o que própria e geralmente tem tal espécie. Ora, propriamente se chama vinho ao
extraído da uva; ao passo que outros líquidos assim se chamam por causa de certa semelhança com o
vinho da vide. — Terceiro, porque o vinho da vide, é mais conducente ao efeito deste sacramento. que é
a alegria espiritual; pois, está escrito o vinho alegra o coração do homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Esses líquidos não se chamam propriamente vinho,
senão por certa semelhança. Quanto ao verdadeiro vinho, pode ser levado às terras onde não crescem
as vides, o quanto baste para este sacramento.

RESPOSTA À SEGUNDA. — O vinho pela corrupção se torna vinagre; por isso, o vinagre não vem de novo
a ser vinho, como o explica Aristóteles. Por onde, assim como com pão totalmente corrupto não se pode
celebrar este sacramento, assim nem com vinagre. Podemos porém celebrá-lo com vinho que se vai
azedando, como com o pão em via de corrupção, embora peque quem assim o fizer, como dissemos.

RESPOSTA À TERCEIRA. — O agraço, estando em via de geração, ainda não tem a espécie de vinho. E
por isso não se pode com êle celebrar este sacramento. - Ao contrário, o mosto já tem essa espécie;
pois, como a sua doçura o prova, o vinho já está formado; isto é, que o calor natural já lhe deu seu
complemento, como o diz Aristóteles. E portanto, com o mosto pode-se celebrar este sacramento. —
Mas uvas inteiras a êle se não devem acrescentar, porque então já ai haveria outra coisa além do vinho.
- Também é proibido oferecer no cálice o mosto recém-exprimido da uva, o que não convém por causa
da impureza do mosto. É permitido porém oferecê-lo em caso de necessidade, pois, o mesmo Papa Júlio
diz (no logo cit.): Se for necessário, esprema-se um cacho de uvas no cálice.

## Art. 6 — Se deve ser misturada a água com o vinho.
O sexto discute-se assim. — Parece que a água não deve ser misturada com o vinho.

1. — Pois, o sacrifício de Cristo foi significado pela oblação de Melquisedeque, de quem não diz a
Escritura que oferecesse outra coisa senão pão e vinho. Logo, parece que neste sacramento não se deve
acrescentar a água.

2. Demais. — Sacramentos diversos têm matérias diversas. Ora, a água é a matéria do batismo. Logo,
não deve ser tomada como a deste sacramento.

3. Demais. — O pão e o vinho são a matéria deste sacramento. Ora, ao pão nada se acrescenta. Logo,
nem ao vinho se deve acrescentar nada.
Mas, em contrário, Alexandre Papa (I) determina: Nas oblações dos sacramentos que na solenidade da
missa, se ofereçam ao Senhor, ofereçam-se no sacrifício somente pão e vinho misturado com água.

SOLUÇÃO. — O vinho oferecido neste sacramento deve ser misturado com água. - Primeiro, por causa
da instituição. Pois, crê-se com probabilidade que o senhor instituiu este sacramento tomando vinho
misturado com água, conforme ao costume da sua terra. Donde o dizer a Escritura: Bebei o vinho que
vos preparei. - segundo, por assim convir à representação da paixão do senhor. Por isso dispõe
Alexandre Papa: Não deve no cálice do Senhor, ser oferecido vinho só nem só água, mas ambos
misturados; vais, como lemos no Evangelho, ambos conservam do lado de Cristo, na sua paixão. -
Terceiro, porque assim convém para significar o efeito deste sacramento que é a união do povo crístão
com Cristo. Pois, como diz Júlio Papa, vemos que pela água se entende o povo, e pelo vinho, o sangue
de Cristo. Por isso, quando no cálice se mistura a água com o vinho, o povo se aduna com Cristo. Quarto
porque tal convém ao efeito último deste sacramento, que é a entrada na vida eterna. Por isso, diz
Ambrósio: A água redunda no cálice e jorra em vida eterna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Ambrósio no mesmo lugar, assim como o
sacrifício de Cristo foi significado pela oblação de Melquisedeque, assim também o foi pela água, que no
deserto jorrou da pedra, segundo aquilo do Apóstolo: E todos bebiam da pedra misteriosa que os
seguia.

RESPOSTA À SEGUNDA. — A água é tomada no batismo para o uso da ablução. Ao passo que neste
sacramento ela serve para a refeição espiritual, segundo aquilo da Escritura: ele me conduziu junto a
uma água de refeição.

RESPOSTA À TERCEIRA. — O pão é confeccionado de água e de farinha. E portanto, sendo a água é
misturada com o vinho tanto deste como do pão faz ela parte.

## Art. 7 — Se a mistura da água é indispensável neste sacramento.
O sétimo discute-se assim. — Parece que a mistura da água é indispensável neste sacramento.

1. — Pois, diz Cipriano: Como no cálice do Senhor não há somente água nem vinho somente, mas ambos
misturados, do mesmo modo o seu corpo não pode ser farinha só, mas um misto de farinha e água. Ora,
a mistura da água com a farinha é indispensável neste sacramento. Logo, e pela mesma razão, a mistura
da água com o vinho.

2. Demais. — Na paixão do Senhor, de que este sacramento é o memorial, assim como do seu lado saiu
sangue, assim também água. Ora, o vinho, sacramento do sangue, é indispensável neste sacramento.
Logo, pela mesma razão, a água.

3. Demais. — Se a água não fosse indispensável neste sacramento, não importaria de que água se
usasse; portanto, poder-se-ia usar de água rosada, ou qualquer água semelhante, o que é o uso da
Igreja. Logo, a água é indispensável neste sacramento.
Mas, em contrário, diz Cipriano: Se algum dos nossos antecessores, por ignorância ou simplicidade, não
observou, isto é, se não misturou água com vinho neste sacramento, concedemos perdão à sua
simplicidade. O que não se daria, se a água fosse indispensável neste sacramento, como o é o vinho ou o
pão. Logo, a mistura com a água não é indispensável, neste sacramento.

SOLUÇÃO. — Devemos julgar um sinal por aquilo que êle significa. Ora, a razão de se misturar a água
com o vinho é significar a participação deste sacramento pelos fiéis, pois, essa mistura simboliza o povo
amado com Cristo, como se disse. E o mesmo ter comido a água do lado de Cristo pendente da cruz,
tem idêntica significação, pois, a água significa a ablução dos pecados, feita pela paixão de Cristo. Ora,
como dissemos, este sacramento se consuma pela consagração da matéria: mas o uso dos fiéis não lhe é
indispensável a êle, sendo apenas uma consequência do sacramento. Por onde, a mistura com a água
não é indispensável neste sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essas palavras de Cipriano devem entender-se no
sentido em que dizemos não poder existir o que não pode convenientemente existir. E assim, a referida
semelhança se funda no que deve ser feito, e não na necessidade de o fazer, pois, a água é da essência
do pão, mas não da do vinho.

RESPOSTA À SEGUNDA. — A efusão do sangue resultava diretamente da paixão mesma de Cristo; pois,
é natural do corpo humano ferido promanar o sangue. Ao contrário, a efusão da água não havia
necessàriamente de se dar na paixão, senão para lhe mostrar o efeito, que é a ablução dos pecados e o
refrigério contra o ardor da concupiscência. Por isso a água não é oferecida separadamente do vinho,
neste sacramento, como o vinho é separadamente do pão; mas a água é oferecida misturada com vinho,
para mostrar que o vinho por si é indispensável à existência mesma deste sacramento, ao passo que a
água só é misturada com o vinho.

RESPOSTA À TERCEIRA. — A mistura da água com o vinho não é de necessidade neste sacramento; por
isso não importa à validade dele que água seja misturada com o vinho – natural, artificial ou rosada.
Embora, quanto à conveniência do sacramento, peque quem misturar água que não seja a natural e
verdadeira. Porque do lado de Cristo pendente da cruz, manou verdadeira água e não um humor
fleugmático, como certos disseram, para mostrar que o corpo de Cristo era verdadeiramente composto
dos quatro elementos; assim como o sangue que correu mostrava ser o seu corpo composto dos quatro
humores, conforme diz Inocêncio III, numa Decretal. Sendo porem a mistura da água com a farinha
indispensável neste sacramento, por constituir a substância do pão, se se misturar farinha com água
rosada, ou com qualquer outro líquido que não a verdadeira água, não pode com essa matéria ser
celebrado o sacramento, porque não haveria verdadeiro pão.

## Art. 8 — Se a água deve ser misturada em grande quantidade.
O oitavo discute-se assim. — Parece que a água deve ser misturada em grande quantidade.

1. — Pois, assim como o sangue correu sensivelmente do lado de Cristo, assim também a água. Ora, a
água não poderia ser misturada sensivelmente neste sacramento, senão em grande quantidade. Logo,
parece que a água deve ser misturada em grande quantidade.

2. Demais. — Pouca água, misturada a muito vinho, corrompe-se. Ora o que está corrupto não existe.
Logo, por pouca água neste sacramento é o mesmo que não pôr nada. Ora não é lícito não pôr nada.
Logo, não é lícito pôr pouca água.

3. Demais. — Se bastasse acrescentar pouca água, seria por conseqüência suficiente derramar uma gota
de água em toda uma pipa de vinho. Ora, isto é ridículo. Logo, não basta misturar uma pequena
quantidade de água.
Mas, em contrário, uma disposição canônica reza: No teu país introduziu-se o abuso pernicioso de pôr,
no sacrifício, mais quantidade de água que de vinho; sendo, ao contrário, o uso comum da Igreja
universal, pôr mais vinho que água.

SOLUÇÃO. - Sobre a água misturada com o vinho, como o diz Inocêncio III numa Decretal, há tríplice
opinião. Assim, uns dizem que a água misturada com o vinho permanece água, quando o vinho se
converte em sangue. - Mas esta opinião não pode sustentar-se. Porque no sacramento do Altar, depois
da consagração, não há senão o corpo e o sangue de Cristo. Pois, diz Ambrósio: Antes da bênção há uma
espécie que, depois da consagração, se transforma no corpo de Cristo. Do contrário, este não seria
adorado com a veneração de latria. E por isso outros opinaram que assim como o vinho se converte em
sangue, assim a água se converte na água que correu do corpo de Cristo. - Mas isto não se pode dizer
com razão. Porque, se assim fosse, a água separadamente do vinho seria consagrada, como o vinho
separadamente do pão. Por onde, como o mesmo Inocêncio III diz, é mais provável a opinião de outros,
que dizem que a água se converte em vinho e o vinho em sangue. Mas isto não pode dar-se a não ser
que se misturasse tão pouca água, que se convertesse em vinho. Por isso é sempre mais seguro pôr
pouca água, sobretudo sendo fraco o vinho; pois, se se pusesse tanta água que desaparecesse a espécie
do vinho, não se poderia celebrar o sacramento. Donde o repreender Júlio Papa (I) a certos que
conservam durante o ano um pano de linho tinto de mosto· e na ocasião do sacrifício lavam com água
uma parte dele e assim sacrificam.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Basta para a significação deste sacramento sentir-se que
a água é misturada com o vinho; mas não é preciso que ainda a percebamos depois da mistura.

RESPOSTA À SEGUNDA. —Se a água fosse totalmente excluída, excluída de todo também ficaria a
significação; mas, a conversão da água no vinho significa a incorporação do povo com Cristo.

RESPOSTA À TERCEIRA. — O fato de se pôr água numa pipa de vinho, não bastaria à significação deste
sacramento: mas é necessário misturá-la com o vinho na celebração mesma do sacramento.