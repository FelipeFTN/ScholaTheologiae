# Questão 72: Do sacramento da confirmação
Em seguida devemos tratar do sacramento da confirmação.
E nesta questão discutem-se doze artigos:

## Art. 1 — Se a confirmação é um sacramento.
O primeiro discute-se assim. — Parece que a confirmação não é um sacramento.

1. — Pois. os sacramentos tiram a sua eficácia da instituição divina, como se disse. Ora, em nenhum
lugar se lê que Cristo tivesse instituído a confirmação. Logo, não é sacramento.

2. Demais. — Os sacramentos da Lei Nova estavam prefigurados na Velha. Por isso diz o Apóstolo: Todos
foram batizados debaixo da conduta de Moisés na nuvem e no mar, e todos comeram de um mesmo
manjar espiritual e todos beberam de uma mesma bebida espiritual. Ora, a confirmação não foi
prefigurada no Testamento Velho. Logo, não é um sacramento.

3. Demais. — Os sacramentos se ordenam à nossa salvação. Ora, podemos nos salvar sem a
confirmação; assim as crianças batizadas, mortas sem confirmação, salvam-se. Logo, a confirmação não
é um sacramento.

4. Demais. — Por todos os sacramentos da Igreja o homem se conforma com Cristo autor deles. Ora,
pela confirmação não pode os nos conformar com Cristo, de quem não lemos que fosse confirmado.
Mas, em contrário, Melquíades Papa escreve aos bispos da Espanha: Quanto à questão sobre a qual me
pedistes informações, a saber, se é maior sacramento a imposição das mãos pelo bispo ou o batismo,
sabei que são ambos grandes sacramentos.

SOLUÇÃO. — Os sacramentos da lei nova, ordenam-se a efeitos especiais da graça. Por onde, cada
efeito especial da graça se ordena um sacramento especial. Mas como as coisas sensíveis e corpóreas
geram semelhanças das espirituais e inteligíveis, pelo que se passa na vida material podemos perceber o
que é especial à vida espiritual. Ora, é manifesto que é uma perfeição especial da vida do corpo o chegar
o homem à idade perfeita e poder fazer ações perfeitas. Por isso o Apóstolo diz: Depois que eu cheguei
a ser homem jeito, dei de mãos às coisas que eram de menino. E por isso também, além do movimento
da geração, pelo qual recebemos a vida do corpo, há o do crescimento pelo qual chegamos à idade
perfeita. Assim também recebemos a vida espiritual pelo batismo, que é a regeneração espiritual. . E
pela confirmação atingimos a como idade perfeita da vida espiritual. Por isso Melquíades Papa diz: O
Espírito Santo, que desceu sobre as águas do batismo, para nossa salvação, concede, na fonte batismal,
a plenitude da inocência, e na confirmação o aumento da graça. No batismo renascemos para a vida e
depois do batismo somos confirmados para a luta. No batismo somos purificados, e depois do batismo
somos fortalecidos. Por onde é manifesto que a confirmação é um sacramento especial.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Sobre a instituição deste sacramento há tríplice opinião.
- Certos (Alex. de Hales, S. Boaventura) disseram que esse sacramento não foi instituído nem por Cristo
nem pelos Apóstolos; mas depois, no decenso do tempo, num certo concílio. - Mas outros (Petr. Tarent)
disseram ter sido instituído pelos Apóstolos. - Mas isto não pode ser, porque instituir um novo
sacramento implica um poder por excelência, que só cabe a Cristo. - E por isso devemos responder, que
Cristo institui este sacramento, não conferindo-o, mas prometendo-o, segundo aquilo do Evangelho: Se
eu não for não virá a vós o Consolador; mas se for enviarvo-lo-ei. E isto é assim porque neste
sacramento é dada a plenitude do Espírito Santo, que não devia ser dada antes da ressurreição e da
ascensão de Cristo, segundo o diz o Evangelho.

RESPOSTA À SEGUNDA. — A confirmação é o sacramento da plenitude da graça; e portanto nada podia
haver que lhe correspondesse no Velho Testamento, pois a lei nenhuma coisa levou à perfeição, no
dizer do Apóstolo.

RESPOSTA À TERCEIRA. — Como dissemos, todos os sacramentos são de certo modo necessários à
salvação; mas há certos sem os quais não a alcançamos; e outros que contribuem para a plenitude dela.
E assim a confirmação é de necessidade para a salvação embora sem ela possamos nos salvar, contanto
que não a omitamos por desprezo do sacramento.

RESPOSTA À QUARTA. — Os que recebem a confirmação, sacramento da plenitude da graça,
conformam-se com Cristo, que desde o primeiro instante da sua concepção foi cheio de graça e de
verdade, como diz o Evangelho. E essa plenitude se declarou no batismo, quando desceu sobre ele o
Espírito Santo em forma corpórea. Por isso o Evangelho também diz, que cheio do Espírito Santo voltou
Jesus do Jordão. Mas não convinha à dignidade de Cristo, autor dos sacramentos, receber de um
sacramento a plenitude da graça.

## Art. 2 — Se o crisma é a matéria conveniente deste sacramento.
O segundo discute-se assim. — Parece que a crisma não é a matéria conveniente deste sacramento.

1. — Pois, este sacramento foi instituído por Cristo, quando prometeu aos discípulos o Espírito Santo.
Ora, ele próprio enviou-lhes o Espírito Santo sem fazer nenhuma unção do Crisma. E também os
Apóstolos conferiam este sacramento pela só imposição das mãos, sem crisma. Assim, diz a Escritura,
que os Apóstolos punham as mãos sobre os batizados e estes recebiam o Espírito Santo. Logo, o crisma
não é a matéria deste sacramento, porque a matéria é necessária para o sacramento ser válido.

2. Demais. — A confirmação de certo modo completa o sacramento do batismo, como se disse; e assim
deve conformar-se com ele como a perfeição com o perfectível. Ora, a matéria do batismo é a água,
elemento simples. Logo, a crisma, feito de óleo e de bálsamo, não é a matéria conveniente deste
sacramento.

3. Demais. — O óleo é tomado, na matéria deste sacramento, para ungir. Ora, com qualquer óleo se
pode ungir, por exemplo, com o óleo de nozes ou de qualquer outra matéria. Logo, não é só o óleo de
azeitonas que deve ser tomado para esse sacramento.

4. Demais. — Como se disse, a água é tomada como matéria para o batismo, porque em toda parte se
encontra facilmente. Ora, o óleo de azeitonas não se encontra em toda parte, e muito menos o
bálsamo. Logo, a crisma, composto dessas duas matérias, não é a matéria conveniente deste
sacramento.
Mas, em contrário, Gregório diz: Os sacerdotes não se permitam assinalar com o santo crisma a fronte
das crianças que acabam de ser batizadas. Logo, a crisma é a matéria deste sacramento.

SOLUÇÃO. — A crisma é a matéria conveniente deste sacramento. Pois, como se disse, ele confere a
plenitude do Espírito Santo, para termos a força espiritual da idade perfeita. Ora, quando chegamos à
idade perfeita, já começamos a comunicar com os outros pelos nossos atos, ao passo que antes como
que vivíamos particularmente só para nós. Ora, a graça do Espírito Santo é significada pelo óleo; por isso
a Escritura diz que Cristo foi ungido com o óleo da alegria, por causa da plenitude do Espírito Santo, que
tinha. Por isso é o óleo a matéria própria deste sacramento. Mas é misturado com o bálsamo por causa
da fragrância do odor que este exala. Donde o dizer o Apóstolo: Somos o bom odor de Cristo. E embora
haja muitas outras matérias odoríferas, contudo o bálsamo é preferido pela excelência do seu perfume
e por ser incorruptível. Dai o dizer na Escritura: A minha fragrância é como a do bálsamo sem mistura.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo pelo seu poder de excelência comunicou aos
Apóstolos, sem intermediário do rito sacramental, o fruto da confirmação, que é a plenitude do Espírito
Santo, porque, como diz o Apóstolo, eles receberam as primícias do Espírito Santo. — Contudo, os sinais
exteriores que acompanharam essa colação aos Apóstolos não foram sem analogia com a matéria deste
sacramento. Pois, o fato de ter o Espírito Santo descido sensivelmente sobre eles em forma de fogo,
prende-se à mesma significação a que se prende o óleo: salvo que o fogo tem uma virtude ativa, e o
óleo, passiva, enquanto matéria e fomento do fogo. Diferença bastante legitima, pois, pelos Apóstolos a
graça do Espírito Santo devia derivar para os outros. — Também sobre os Apóstolos o Espírito Santo
desceu em forma de língua, o que se prende à mesma significação, que significava o bálsamo. Salvo que
a língua nos põe em comunicação com outrem pela locução, e o bálsamo pelo odor. Porque os
Apóstolos foram cheios do Espírito Santo como doutores da fé, ao passo que os outros fiéis, como
causadores da edificação dos fiéis. — Semelhantemente, pela imposição das mãos dos Apóstolos bem
como pela pregação deles, a plenitude do Espírito Santo descia sobre os fiéis sob sinais visíveis, como no
princípio descera sobre os Apóstolos. Por isso Pedra diz: Como eu tivesse começado a falar, desceu o
Espírito Santo sobre eles, assim como tinha descido sobre nós no princípio. — Por onde, não era
necessária uma sensível matéria sacramental, quando eram miraculosamente manifestados sinais
sensíveis da divindade. — Mas os Apóstolos usavam comumente da crisma ao conferir o sacramento,
quando não se manifestavam esses sinais sensíveis. Assim, diz Dionísio: Há uma operação perfectiva, a
que os nossos chefes, isto é, os Apóstolos, chamam hóstia do crisma.

RESPOSTA À SEGUNDA. — O batismo é conferido para alcançarmos pura e simplesmente a vida
espiritual; por isso a matéria desse sacramento deve ser simples. Mas esse sacramento é conferido para
conseguirmos a plenitude do Espírito Santo, cuja operação é multiforme, segundo aquilo da Escritura:
Há nele um espírito de inteligência santo, único, múltiplice. E o Apóstolo: Há, pois, repartição de graças,
mas um mesmo é o Espírito. Por isso, a matéria desse sacramento é acertadamente composta.

RESPOSTA À TERCEIRA. — As propriedades do óleo, que significam o Espírito Santo, se encontram antes
no óleo da oliveira do que em qualquer outro óleo. Por isso a própria oliveira, de frondes sempre
viridentes, significa a viridência e a misericórdia do Espírito Santo. - Demais, esse óleo é o óleo por
excelência e o empregado de preferência em toda parte onde é encontrado. E qualquer outro licor é
chamado óleo por semelhança com ele; nem é de uso comum senão como suplemento para aqueles a
quem falta o óleo da oliveira. Por isso esse óleo só é o usado neste e em certos outros sacramentos.

RESPOSTA À QUARTA. — O batismo é um sacramento de absoluta necessidade, por isso a sua matéria
deve ser encontrada em toda parte. Mas basta que a matéria deste sacramento, que não é de tão
grande necessidade, possa ser levada facilmente a todos os lugares da terra.

## Art. 3 — Se é necessário para este sacramento ser válido que a sua matéria, a crisma, tenha sido primeiro consagrado pelo bispo.
O terceiro discute-se assim. — Parece não ser necessário, para este sacramento ser válido que a sua
matéria, a crisma, tenha sido primeiro consagrado pelo bispo.

1. — Pois, o batismo, que produz a plena remissão dos pecados não tem menor eficácia que este
sacramento. Ora, embora uma certa santificação seja lançada sobre a água batismal antes do batismo,
não é contudo necessária para a validade do sacramento: pois em artigo de necessidade pode ser
omitida. Logo, não é de necessidade para este sacramento que a crisma tenha sido antes consagrado
pelo bispo.

2. Demais. — Uma mesma coisa não deve ser consagrada duas vezes. Ora, a matéria do sacramento é
santificada na colação mesma dele, pela forma das palavras por que se confere o sacramento. Por isso
Agostinho diz: Acrescenta-se a palavra ao elemento e forma-se o sacramento. Logo a crisma não deve
ser conservado antes de ser esse sacramento conferido.

3. Demais. — Toda consagração feita nos sacramentos se ordena à consecução da graça. Ora, a matéria
sensível preparada com óleo e bálsamo não é capaz da graça. Logo, não se lhe deve lançar nenhuma
consagração.
Mas, em contrário, Inocêncio Papa diz: Aos presbíteros, quando batizam, seja-lhes lícito ungir com a
crisma os batizados, que foi consagrado pelo bispo; mas não ungir a fronte com o mesmo óleo, o que só
podem fazer os bispos quando conferem o Paráclito; o que se faz pela confirmação. Logo, é necessário
que a matéria deste sacramento seja primeiro consagrada pelo bispo.

SOLUÇÃO. — A santificação dos sacramentos deriva totalmente de Cristo, como dissemos. Mas
devemos considerar que Cristo usou de certos sacramentos que têm matéria sensível, como o batismo e
também a Eucaristia. Por isso, pelo uso mesmo de Cristo, as matérias desses sacramentos receberam a
aptidão para dar ao sacramento a sua plenitude. Por onde, diz Crisóstomo (Cromácio): Nunca as águas
do batismo poderiam purificar os pecados dos crentes, se não fossem santificadas pelo contato do
corpo do Senhor. Do mesmo modo, o próprio Senhor, tomou o pão e o benzeu; e semelhantemente
tomou o cálice, como referem os Evangelhos. E por isso não é necessário, para a validade desses
sacramentos, que a matéria seja benta antes, porque basta a bênção de Cristo. E qualquer bênção que
se lhe acrescente é para a solenidade do sacramento, mas não para a sua validade. De unções visíveis
porem Cristo não usou a fim de não menoscabar a unção invisível, pela qual foi ungido, sobre os seus
companheiros. Por onde, tanto o crisma como o óleo santo e o óleo dos enfermos são bentos antes de
virem ao uso do sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A resposta resulta do que acaba de ser dito.

RESPOSTA À SEGUNDA. — As duas consagrações da crisma não têm o mesmo fim. Pois, assim como um
instrumento de dois modos adquire a sua virtude instrumental — quando recebe a forma de
instrumento e quando movido pelo agente principal, assim também a matéria do sacramento necessita
de dupla santificação, por uma das quais se torna a matéria própria do sacramento e pela outra é
aplicada à produção do efeito.

RESPOSTA À TERCEIRA. — A matéria corpórea não é capaz de graça, como sujeito, mas só como
instrumento da graça conforme dissemos. E para isso é consagrada a matéria do sacramento, ou pelo
próprio Cristo, ou pelo bispo, representante na Igreja da pessoa de Cristo.

## Art. 4 — Se esta é a forma conveniente deste sacramento: Eu te assinalo com o sinal da cruz e te confirmo com a crisma da salvação, em nome do Padre e do Filho e do Espírito Santo, Amem.
O quarto discute-se assim. — Parece que esta não é a forma conveniente deste sacramento: Eu te
assinalo com o sinal da cruz e te confirmo com o crisma da salvação, em nome do Padre e do Filho e
do Espírito Santo, amém.

1. — Pois, o uso dos sacramentos deriva de Cristo e dos Apóstolos. Ora, nem Cristo instituiu essa forma
nem lemos na Escritura que dela tivessem usado os Apóstolos. Logo, não é essa a forma conveniente
deste sacramento.

2. Demais. — Assim como o sacramento é o mesmo entre todos, assim também a sua forma deve ser a
mesma, porque qualquer ser terá a sua unidade, como o seu ser, da sua forma. Ora, da referida forma
nem todos usam; pois, certos dizem: Eu te confirmo com a crisma da santificação. Logo, a forma supra
não é a conveniente a este sacramento.

3. Demais. — Este sacramento deve conformar-se com o batismo como a perfeição com o perfectível,
conforme se disse. Ora, a forma do batismo não faz menção da impressão do caráter, nem também da
cruz de Cristo, embora pelo batismo morramos com Cristo, na frase do Apóstolo. Nem tão pouco se faz
menção do efeito da salvação, embora o batismo seja necessário para a alcançarmos. E também a forma
do batismo implica um ato único e é expressa a pessoa de quem batiza, quando diz: Eu te batizo. Ora, o
contrário, aparece na forma supra-referida. Logo, não é a forma conveniente deste sacramento.
Mas, em contrário, a autoridade da Igreja, que usa comumente dessa forma.

SOLUÇÃO. — A referida forma é conveniente a este sacramento. Pois, assim como a forma de um ser
físico lhe dá a espécie, assim a do sacramento deve conter tudo o que lhe pertence à espécie. Ora, como
do sobredito se colhe, nesse sacramento recebemos o Espírito Santo para nos fortificar na luta
espiritual. Por onde, três coisas são necessárias neste sacramento, contidas na referida forma. — A
primeira delas é a causa que confere a plenitude da força espiritual, que é a santa Trindade, expressa
quando se diz: Em nome do Padre, etc. - A segunda é a própria robustez espiritual, comunica da pelo
sacramento de uma matéria visível, em vista da salvação. E é o que indicam as palavras — Eu te
confirmo com a crisma da salvação. — A terceira é o sinal dado ao combatente, assim como na pugna
corporal os soldados são marcados com as insígnias dos seus chefes. Tal é o significado das palavras: Eu
te assinalo com o sinal da cruz, no qual triunfou o nosso Rei, no dizer do Apóstolo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como dissemos, pelo ministério dos Apóstolos às vezes
era conferido o efeito deste sacramento, a saber, a plenitude do Espírito Santo, por certos sinais visíveis
milagrosamente produzidos por Deus, que pode conferir os efeitos do sacramento sem conferir o
sacramento. E então não era necessária nem a matéria nem a forma deste. - Outras vezes, porém, como
ministros dos sacramentos é que conferiam a este. E então assim como da matéria, usavam também da
forma dele, por mandado de Cristo. Pois, os Apóstolos, na colação dos sacramentos, observavam muitas
cerimônias não outorgadas nas Escrituras comuns a todos. Por isso diz Dionísio: Não é justo os
intérpretes das Escrituras tirar ocultamente e trazerem a público quer as invocações eficientes, isto é, as
palavras constitutivas dos sacramentos, quer o mistério delas ou as virtudes obradas por Deus mediante
elas; mas que o nosso santo ensino as comunique sem pompa, isto é, ocultamente. Por isso o Apóstolo
diz, falando da celebração da Eucaristia: No tocante às demais causas, eu as ordenarei quando for.

RESPOSTA À SEGUNDA. — A santidade é a causa da salvação. Por isso vem a dar no mesmo dizer pela
crisma da salvação e da santificação.

RESPOSTA À TERCEIRA. — O batismo é o renascer para a vida espiritual, que é a nossa vida individual.
Por isso a forma do batismo não inclui senão o ato mesmo conducente à nossa santificação. Ao passo
que o sacramento em questão não só se ordena à nossa santificação individual, mas também à luta
exterior à qual estamos expostos. Por onde, nele se menciona não sô a santificação interior, quando se
diz. Eu te confirmo, com a crisma da salvação, mas também se nos assinala exteriormente como que
com o estandarte da cruz, para a luta espiritual externa, e isso significam as palavras. — Eu te assinalo
com o sinal da cruz. — Quanto à palavra — batizar, significativo da ablução, podemos por ela
compreender tanto a matéria, que é a água da ablução, como o efeito da salvação. O que não inclui a
palavra confirmar, e por isso se lhe deviam acrescentar. — Como já dissemos a expressão pronominal —
eu — não é de necessidade na forma batismal, pois está incluída no verbo da primeira pessoa. É
acrescentada porem para exprimir a intenção. O que não é igualmente necessário na confirmação,
conferida só pelos ministros superiores, como a seguir se dirá.

## Art. 5 — Se o sacramento da confirmação imprime caráter.
O quinto discute-se assim. Parece que o sacramento da confirmação não imprime caráter.

1. — Pois, o caráter implica um sinal distintivo. Ora, pelo sacramento da confirmação não se distingue o
fiel do infiel, efeito do batismo; nem um fiel dos outros, porque este sacramento se ordena ao combate
espiritual imposto a todos os fiéis. Logo, este sacramento não imprime nenhum caráter.

2. Demais. — Acima se disse ser o caráter uma potência espiritual. Ora a potência ou é ativa ou passiva.
Mas, a potência ativa, nos sacramentos, é conferida pelo sacramento da ordem; e a passiva ou
receptiva, pelo do batismo. Logo, o sacramento da confirmação nenhum caráter imprime.

3. Demais. — A circuncisão, que é um caráter impresso no corpo, não imprime nenhum caráter
espiritual. Ora, este sacramento imprime um certo caráter corporal, pois, o confirmando é assinalado
pela crisma com o sinal da cruz na fronte. Logo, este sacramento não imprime caráter espiritual.
Mas, em contrário. - Todo sacramento que não pode ser renovado imprime caráter. Ora, este
sacramento não pode ser renovado, como o dispõe Gregório: Quanto ao que teria sido de novo
confirmado pelo pontífice, essa reiteração deve ser proibida. Logo, a confirmação imprime caráter.

SOLUÇÃO. — Como dissemos, o caráter é um poder espiritual ordenado a certas ações sagradas. Ora,
conforme foi dito, assim como o batismo é um renascimento espiritual para a vida cristã, assim também
a confirmação é um crescimento espiritual que nos conduz à idade espiritual perfeita. Ora, é manifesto,
por semelhança com a vida do corpo, que um é o modo de agir do recém-nascido e outro o do que já
atingiu a idade perfeita. Por onde, o sacramento da confirmação nos confere o poder espiritual de fazer
certas outras ações sagradas além das que o batismo nos torna possíveis. Pois, no batismo recebemos a
faculdade de praticar o que conduz à nossa salvação própria, isto é, o que respeita à nossa vida
individual; ao passo que a confirmação nos dá o poder de praticar atos pertinentes ao combate
espiritual contra os inimigos da fé. Como o demonstra o exemplo dos Apóstolos, que antes de
receberem a plenitude do Espírito Santo, estavam no cenáculo perseverando na oração; depois, porém,
quando dele saíram, não temiam confessar publicamente a fé, mesmo perante os inimigos da fé cristã.
Por onde é manifesto, que o sacramento da confirmação imprime caráter.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O combate espiritual contra os inimigos invisíveis todos
devemos combatê-lo. Mas contra os inimigos visíveis, isto é, contra os perseguidores da fé só combatem
os confirmados, confessando publicamente o nome de Cristo, pois já atingiram a idade viril espiritual.
Tal o diz o Evangelho: Eu vos escrevo, moços, porque sois fortes e porque a palavra de Deus permanece
em vós e porque vencestes o maligno. Por onde, o caráter da confirmação é o sinal distintivo não entre
infiéis e fiéis, mas entre os espiritualmente provectos e aqueles de quem diz Pedro: Como a meninos
recém-nascidos.

RESPOSTA À SEGUNDA. — Todos os sacramentos são umas profissões de fé. Assim, pois, como o
batizado recebe o poder espiritual de confessar a fé pela recepção dos outros sacramentos, assim
também o confirmado recebe o poder de confessar, como que por dever, pública e verbalmente a fé de
Cristo.

RESPOSTA À TERCEIRA. — Aos sacramentos da Lei Velha o Apóstolo lhes chama justiça da carne, por
não produzirem nenhum efeito interior. Por isso a circuncisão só imprimia um caráter no corpo, mas
não na alma. Ao passo que a confirmação imprime por igual um caráter corpóreo e outro espiritual, por
ser sacramento da lei nova.

## Art. 6 — Se o caráter da confirmação pressupõe necessàriamente o caráter do batismo.
O sexto discute-se assim. — Parece que o caráter da confirmação não pressupõe necessàriamente o
caráter batismal.

1. — Pois, o sacramento da confirmação se ordena à confissão pública da fé de Cristo. Mas muitos
mesmo antes do batismo, confessaram publicamente a fé de Cristo, derramando o sangue pela fé. Logo,
o caráter da confirmação não pressupõe o caráter batismal.

2. Demais. — Não se lê dos Apóstolos, que fossem batizados; sobretudo que o Evangelho diz que o
Cristo não batizava ele próprio, mas sim os seus discípulos. E contudo, foram depois confirmados pelo
advento do Espírito Santo. Logo e semelhantemente, outros podem ser confirmados antes de batizados.

3. Demais. — A Escritura diz: Estando Pedro ainda proferindo estas palavras, desceu o Espírito Santo
sobre todos os que ouviam a palavra e os ouviam falar diversas línguas. E depois Pedro mandou batizá-
los. Logo, por igual razão, podem os demais ser confirmados antes de batizados.
Mas, em contrário, Rabano diz: Em último lugar, pela imposição das mãos do sumo sacerdote, o
batizado recebe o Paráclito, a fim de ser fortificado pelo Espírito Santo, para pregar a fé.

SOLUÇÃO. — O caráter da confirmação necessàriamente supõe o batismal. De modo que o não-
batizado que fosse confirmado nada receberia, mas seria necessário de novo receber a confirmação,
depois de batizado. E a razão é que a confirmação está para o batismo como o crescimento para a
geração, conforme do sobredito resulta. Ora, é manifesto que ninguém pode atingir a idade perfeita
antes de nascido. E semelhantemente, quem não for primeiro batizado não pode receber a
confirmação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A virtude divina não está adstrita aos sacramentos. E por
isso pode nos conferir a força espiritual para confessar publicamente a fé de Cristo sem o sacramento da
confirmação; assim como também podemos alcançar a remissão dos pecados sem batismo. Contudo,
assim como ninguém alcança o efeito do batismo sem o desejo deste, assim ninguém consegue o efeito
da confirmação sem a desejar, o que se pode dar antes da recepção do batismo.

RESPOSTA À SEGUNDA. — Como diz Agostinho, pelo dito do Senhor - Aquele que está lavado não tem
necessidade de lavar senão os pés, entendemos que Pedro e os outros discípulos de Cristo foram
batizados, quer pelo batismo de João, como alguns pensam, e quer, como é mais crível, pelo batismo de
Cristo. Pois, nem recusou o ministério de batizar, a fim de ter servos pelos quais batizasse os outros.

RESPOSTA À TERCEIRA. — Os ouvintes da pregação de Pedro receberam o efeito da confirmação
milagrosamente, mas não o sacramento da confirmação. Pois como dissemos, o efeito da confirmação
nos pode ser conferido antes do batismo; não porem o sacramento da confirmação. Porque assim como
o efeito da confirmação, que é a robustez espiritual, pressupõe o efeito do batismo, que é a justificação,
assim o sacramento da confirmação pressupõe o sacramento do batismo.

## Art. 7 — Se este sacramento confere a graça santificante.
O sétimo discute-se assim. — Parece que este sacramento não confere a graça santificante.

1. — Pois, a graça santificante é um remédio contra a culpa. Ora, este sacramento como dissemos, só é
conferido aos batizados, que estão purificados da culpa. Logo, este sacramento não confere a graça
santificante.

2. Demais. — Sobretudo os pecadores é que precisam da graça santificante, que só os pode justificar. Se
portanto este sacramento confere a graça santificante parece que devia ser dada aos que estão em
estado de pecado. O que contudo não é verdade.

3. Demais. — A graça santificante não é susceptível de espécies, pois se ordena a um só efeito. Ora, duas
formas da mesma espécie não podem coexistir no mesmo sujeito. Sendo, pois, a graça santificante
conferida ao homem pelo batismo, parece que o sacramento da confirmação, conferido só ao batizado,
não dá a graça santificante.
Mas, em contrário, Melquíades Papa diz: O Espírito Santo, na fonte batismal, dá a plenitude da
inocência; e na confirmação, o aumento da graça.

SOLUÇÃO. — Este sacramento, como se disse, confere ao batizado o Espírito Santo para o robustecer
como o foi aos Apóstolos no dia de Pentecostes e como o era aos batizados pela imposição das mãos
dos Apóstolos, segundo o refere a Escritura. Ora conforme se mostrou na Primeira Parte, a missão ou a
dação do Espírito Santo é acompanhada da graça santificante. Por onde é manifesto que o sacramento
da confirmação confere a graça santificante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pela graça santificante fica perdoada a culpa. Mas
também produz outros efeitos, pois basta a nos conduzir, por todos os graus, até a vida eterna. Por isso
foi dito a Paulo: Basta-te a minha graça. E o próprio Apóstolo disse: Pela graça de Deus sou o que sou.
Por onde, a graça santificante não só produz a remissão da culpa, mas também o aumento e a
fortificação da justiça. E assim a confere o sacramento em questão.

RESPOSTA À SEGUNDA. — Como o próprio nome o diz, este sacramento é conferido para confirmar o
que já existia. Por isso não deve sê-lo aos que não têm a graça; e portanto, assim como não o é aos não-
batizados, também não deve sê-lo aos adultos pecadores, salvo aos que fizeram penitência dos pecados.
Por isso no concílio aurelianense se dispõe: Venham à confirmação em jejum e sejam advertidos a se
confessarem primeiro a fim de poderem, purificados, receber o dom do Espírito Santo. Assim, este
sacramento completa o efeito da penitência, bem como o do batismo; porque, pela graça conferida por
ele o penitente conseguirá uma remissão mais plena do pecado. E o adulto em estado de pecado, mas
sem disso ter consciência, ou sem contrição perfeita, que receber a confirmação, alcançará a remissão
dos pecados pela graça conferida por ela.

RESPOSTA À TERCEIRA. — Como dissemos, a graça sacramental acrescenta à santificante, geralmente
considerada, o poder de produzir o efeito especial, a que se ordena o sacramento. Considerada, pois, a
graça conferida neste sacramento, no que ela tem de geral, então ele não confere nenhuma outra graça
além da conferida pelo batismo, mas aumenta a que já existia. Mas considerada na eficácia especial que
é acrescentada, então é de espécie diferente.

## Art. 8 — Se este sacramento deve ser conferido a todos.
O oitavo discute-se assim. — Parece que este sacramento não deve ser conferido a todos.

1. — Pois, este sacramento confere uma certa excelência, como se disse. Ora, o excelente não cabe a
todos. Logo não deve a confirmação ser conferida a todos.

2. Demais. — Por este sacramento crescemos espiritualmente para atingir a idade perfeita. Ora, a idade
perfeita exclui a idade pueril. Logo, ao menos às crianças não deve ser conferido.

3. Demais. — Como diz Melquíades Papa, depois do batismo somos confirmados, para o combate. Ora,
combater não compete às mulheres, pela fraqueza do seu sexo. Logo, também às mulheres não deve a
confirmação ser conferida.

4. Demais. — Melquíades Papa diz: Embora aos que vão partir bastem os benefícios da regeneração, aos
que devem vencer são necessários os da confirmação. A confirmação arma e instrui os que ficam para
os combates e os prélios deste mundo. Quanto ao que, depois do batismo, chegar à morte imaculado e
com a inocência batismal, esse é confirmado pela morte pois, já não pode pecar depois da morte. Logo,
aos moribundos não se lhes deve conferir a confirmação, que, portanto, não deve ser conferida a todos.
Mas, em contrário, diz a Escritura, que o Espírito Santo, chegando, encheu toda a casa - a que simboliza
a Igreja. E depois acrescenta que foram todos cheios do Espírito Santo. Ora, este sacramento é conferido
para a consecução dessa plenitude. Logo, deve sê-lo a todos que estão na Igreja:

SOLUÇÃO. — Como dissemos este sacramento nos eleva espiritualmente a idade perfeita. Ora, é da
intenção ria natureza, que todos os nascidos corporalmente atinjam a idade perfeita; o que fica às vezes
impedido pela corruptibilidade do corpo, prematuramente aniquilado pela morte. Mas, com maior
razão, está na intenção de Deus conduzir todos os seres ao termo da sua perfeição, de cuja imitação a
natureza participa. Por isso a Escritura diz: As obras de Deus são perfeitas. Ora, a alma, sujeito da
natividade espiritual e capaz da perfeição da idade espiritual, é imortal; e assim como é capaz, na idade
da velhice, da natividade espiritual, assim também, na da juventude ou da puerícia, pode atingir a idade
perfeita, porque essas idades do corpo não prejudicam à alma. Logo, o sacramento da confirmação deve
ser conferido a. todos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Este sacramento confere uma certa excelência, não de
um homem sôbre outro como o confere o sacramento da ordem, mas de nós sôbre nós mesmos no
sentido em que quando adulto, temos excelência sôbre a idade que tínhamos quando eramos criança, o
que é uma superioridade de nós sôbre nós mesmos.

RESPOSTA À SEGUNDA. — Como se disse, a idade do corpo não prejudica à da alma. Por isso, mesmo.
na idade pueril é possível a consecução da perfeição da idade espiritual, da qual diz a Escritura: A velhice
venerável não é a diuturna nem a computada pelo número dos anos. Donde vem que muitos, na idade
pueril, fortalecidos pelo Espírito Santo, que receberam, lutaram corajosamente por Cristo até a efusão
do sangue.

RESPOSTA À TERCEIRA. — Como diz Crisóstomo, as lutas deste mundo exigem certas qualidades de
idade de forma e de nascimento, que as tornam interditas aos escravos, às mulheres, aos velhos e às
crianças. Mas nos combates, cujo prêmio é o céu, o estádio está aberto a todos sem distinção de
pessoa, nem de idade nem de sexo. E noutro lugar: Perante Deus, mesmo o sexo feminino combate;
pois, muitas mulheres combateram o combate espiritual com ânimo viril. Assim, certas, nas lutas do
martírio, igualaram os varões, pela força do homem interior; e outras se revelaram ainda mais fortes
que eles. E por isso este sacramento deve ser conferido às mulheres.

RESPOSTA À QUARTA. — Como dissemos, a alma, sujeito da idade espiritual, é imortal. Por isso, este
sacramento deve ser conferido também aos moribundos, para aparecerem perfeitos na ressurreição,
segundo aquilo do Apóstolo: Até que todos cheguemos a estado de varão perfeito, segundo a medida
da idade completa de Cristo. Donde o dizer Hugo de S. Victor: Seria muito perigoso o sair alguém desta
vida sem a confirmação; não porque houvesse de se condenar, salvo se deixasse de receber esse
sacramento por desprezo, mas porque sofreria detrimento na perfeição da glória. Por isso também as
crianças mortas confirmadas alcançam uma glória maior, assim como nesta vida, uma graça maior. Por
isso também as crianças mortas confirmadas alcançam uma glória maior, assim como nesta vida, uma
graça maior. — Quanto à autoridade aduzida, significa que aos moribundos não é necessário este
sacramento por causa do perigo do combate presente.

## Art. 9 — Se deve-se conferir a confirmação na fronte.
O nono discute-se assim. — Parece que não se deve conferir este sacramento na fronte.

1. — Pois, este sacramento é um complemento do batismo, como se disse. Ora, o sacramento do
batismo é conferido em todo o corpo. Logo, este não deve ser conferido só na fronte.

2. Demais. — O fim deste sacramento é robustecer-nos espiritualmente, como se disse. Ora, a robustez
espiritual reside sobretudo no coração. Logo, este sacramento devia ser conferido antes sobre o coração
que na fronte.

3. Demais. — Este sacramento nos é conferido para confessarmos livremente a fé de Cristo. Mas com a
boca se faz a confissão para conseguir a salvação, como diz o Apóstolo. Logo, este sacramento deve ser
conferido antes ao redor da boca que na fronte.
Mas, em contrário Rabano diz: O batizado é assinalado com crisma no alto da cabeça pelo sacerdote,
mas pelo pontífice na fronte.

SOLUÇÃO. — Como dissemos este sacramento nos faz receber o Espírito Santo para nos tornar robustos
no combate espiritual, a fim de também confessarmos valorosamente à fé entre os adversários da fé de
Cristo. Por onde, convenientemente é assinalado na fronte com a crisma o sinal da cruz, por duas
razões. - Primeiro porque, como o soldado é marcado com o sinal do chefe, nós devemos sê-lo com o da
cruz, o qual deve ser visível e manifesto. Ora, dentre todos os lugares do corpo humano, a fronte é a
mais aparente, que, por assim dizer, nunca se cobre. Por isso o confirmado é ungido na fronte com o
crisma a fim de mostrar·se manifestamente cristão; assim como os Apóstolos, depois de terem recebido
o Espírito Santo se manifestaram, que antes estavam escondidos no cenáculo. - Segundo, porque duas
causas nos impedem de confessarmos livremente o nome de Cristo, a saber, o temor e a vergonha. Ora,
essas duas paixões se manifestam particularmente na fronte, por causa da vizinhança da imaginação e
porque os espíritos vitais sobem diretamente do coração à fronte. Por isso os envergonhados
enrubescem ao passo que os amedrontados empalidecem como diz Aristóteles. Por onde, o confirmado
é assinalado na fronte com a crisma para não fugir a confessar o nome de Cristo, nem por temor nem
por vergonha.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O batismo nos faz renascer para a vida espiritual, que
abrange o homem na sua totalidade. Ao passo que a confirmação nos fortalece para o combate, cujo
sinal devemos trazer na fronte, como num lugar visível.

RESPOSTA À SEGUNDA. — O principio da fortaleza está no coração, mas o sinal se manifesta na fronte.
Por isso, diz a Escritura: Eis - aí te dei eu uma cara mais de aço que as suas caras. Por isso, O sacramento
da Eucaristia, que nos firma dentro de nós mesmos, é o sacramento do coração, conforme àquilo da
Escritura: O pão alegra o coração do homem. Mas, o sacramento da confirmação requer um sinal de
fortaleza, em relação aos outros. Por isso é posto na fronte.

RESPOSTA À TERCEIRA. — Este sacramento é conferido para confessarmos livremente a fé; não porém
para confessá-la pura e simplesmente, porque esse é o efeito do batismo. Por isso não devem ser
assinalado na boca, mas na fronte, onde se manifestam os sinais das paixões que nos impedem a livre
confissão.

## Art. 10 — Se o confirmado deve ser sustido por outrem ao receber a confirmação.
O décimo discute-se assim. — Parece que o confirmado não deve ser sustido por ninguém ao receber
a confirmação.

1. — Pois, este sacramento é conferido não só às crianças, mas também aos adultos. Ora, os adultos
podem estar em pé por si mesmos. Logo, é ridículo serem sustidos por outrem.

2. Demais. — Quem já pertence à Igreja tem acesso livre ao príncipe dela, que é o bispo. Ora, este
sacramento, como se disse, só é conferido ao batizado, que já é membro da Igreja. Logo, parece que não
deve ser conduzido por outrem ao bispo, para receber esse sacramento.

3. Demais. — Este sacramento é conferido para nos dar a robustez espiritualmente. Ora esta é maior no
homem que na mulher, segundo aquilo da Escritura: Quem achará uma mulher forte? Logo pelo menos
a mulher não deve suster o homem, na confirmação.
Mas, em contrário, Inocêncio Papa diz e está nas Decretais: Se um dos dois cônjuges recebeu ao sair da
fonte ou susteve para o crisma uma criança, filho ou filha de outra família, etc. Logo, assim como é
necessário que outrem retire o batizado da sagrada fonte, assim é preciso que também alguém
sustenha o que vai receber o sacramento da confirmação.

SOLUÇÃO. — Como dissemos, este sacramento é conferido para nos dar a força no combate espiritual.
Pois, assim como um recém-nascido precisa de quem o guie na manutenção da vida segundo àquilo do
Apóstolo - Na verdade tivemos a nossos pais carnais, que nos corrigiam, e os olhávamos, com respeito -
assim também os que devem sustentar o combate precisam de guias que os instruam no pertinente ao
modo de combater. Por isso, nas guerras deste mundo constituem-se chefes e centuriões pelos quais os
outros são governados. Pela mesma razão também aquele que recebe este sacramento é sustido por
outrem, que por assim dizer deverá atingi-lo no combate. - Semelhantemente como este sacramento
nos confere a perfeição da idade espiritual, como se disse, por isso quem a ele se achega é sustido,
como tendo espiritualmente a fraqueza da criança.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o confirmado seja adulto corporalmente, não o
é espiritualmente.

RESPOSTA À SEGUNDA. — Embora o batizado se torne membro da Igreja, contudo não está ainda
adscrito na milícia cristã. Por isso é conduzido ao bispo, como ao chefe do exército, por outro já adscrito
nessa milícia. Pois, não é quem ainda não recebeu a confirmação, que deve acompanhá-lo.

RESPOSTA À TERCEIRA. — Como diz o Apóstolo, em Jesus Cristo não há homem nem mulher. Por isso
não importa que seja um homem ou uma mulher quem sustem o confirmando.

## Art. 11 — Se só o bispo pode conferir este sacramento.
O undécimo discute-se assim. — Parece que nem só o bispo pode conferir este sacramento.

1. — Pois, Gregório, escrevendo o Januário bispo, diz: Chegou ao nosso conhecimento que certos se
escandalizaram por termos proibido aos presbíteros ungir com o crisma os neófitos. Ora, nós o fizemos
de conformidade com o uso antigo da nossa Igreja. Se houver porem quem demasiado se contriste com
isso, permitimos que, na falta do bispo, também os presbíteros possam ungir os batizados com o crisma,
mesmo na fronte. Ora, o necessário à validade do sacramento não deve mudar-se, por evitar escândalo.
Logo, parece não ser de necessidade para este sacramento, que seja conferido pelo bispo.

2. Demais. — O sacramento do batismo tem maior eficácia que o da confirmação; porque o batismo
confere o perdão pleno dos pecados, quanto à culpa e quanto à pena, o que a confirmação não faz. Ora,
um simples sacerdote, pelo seu próprio ofício, pode ministrar o sacramento do batismo; e em caso de
necessidade qualquer, mesmo um não-ordenado, pode fazê-lo. Logo não é necessário, para a validade
deste sacramento, que seja ministrado pelo bispo.

3. Demais. — O vértice da cabeça, onde segundo os médicos se localiza a razão particular, chamada
faculdade cognitiva, é mais nobre que a fronte, que é a sede da potência imaginativa. Ora, um simples
sacerdote pode ungir os batizados com a crisma, no vértice. Logo, com muito maior razão pode assinalá-
los na fronte com o crisma, o que constitui a confirmação.
Mas, em contrário, Eusébio Papa diz: O sacramento da imposição das mãos deve ser tido em grande
reverência, pois, não pode ser conferido senão pelos sumos sacerdotes. Nem lemos nem chegou ao
nosso conhecimento, que no tempo dos Apóstolos fosse conferido por outros que os próprios
Apóstolos; nem pode nunca ser conferido nem deve ser ministrado senão por aqueles que estão no
lugar deles. Portanto, se se agir de outro modo, o ato será írrito e nulo, nem será contado nunca entre
os sacramentos da igreja. Logo, para ser válido, deve a confirmação, chamada Sacramento da imposição
das mãos, ser conferida pelo bispo.

SOLUÇÃO. — A perfeição última de uma obra deve ser reservado à arte ou à virtude superior. Assim, a
preparação da matéria pertence aos artífices inferiores; o superior dá a forma; e ao chefe supremo
pertence o uso, fim das obras de arte; por isso a carta, escrita pelo notário, é assinalada pelo seu autor.
Ora, os fiéis de Cristo constituem uma obra divina, segundo àquilo do Apóstolo: Vós sois edifício de
Deus. São também uma como carta escrita com o Espírito de Deus, na expressão do Apóstolo. Ora, o
sacramento da confirmação é como a última consumação do sacramento do batismo. Pois, no batismo o
homem foi erigido numa como morada espiritual e escrito, como uma carta espiritual; e depois a
confirmação, por assim dizer consagra a casa edificada como templo do Espírito Santo, e assim a carta
escrita, com o sinal da cruz. Por isto a colação deste sacramento é reservada aos bispos, que têm o
poder sumo da Igreja; assim como na primitiva Igreja pela imposição das mãos dos Apóstolos, cujas
vezes fazem os bispos, era dada a plenitude do Espírito Santo, como se lê na Escritura. Por isso Urbano
Papa (I) diz: Todos os fiéis, pela imposição das mãos dos bispos, devem receber o Espírito Santo, depois
do batismo, para que se tornem plenamente cristãos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Papa tem na Igreja a plenitude do poder, em virtude
da qual pode cometer a certos inferiores determinadas faculdades, da alçada de ordens superiores.
Assim, a certos presbíteros concede o poder de conferir ordens menores, o que pertence ao poder
episcopal. E por essa plenitude de poder S. Gregório Papa concedeu que simples sacerdotes conferissem
esse sacramento, até cessar o escândalo.

RESPOSTA À SEGUNDA. — O sacramento do batismo é mais eficaz que a confirmação, quanto à
remoção do mal; pois, é uma geração espiritual, e esta implica mudança do não ser para o ser. Mas, o
sacramento da confirmação é mais eficaz para fazer-nos progredir no bem; pois, é um crescimento
espiritual, do imperfeito para o perfeito. Por isso, este sacramento é cometido a um ministro mais
digno.

RESPOSTA À TERCEIRA. — Rábano diz: O batizado é assinalado com a crisma no vértice da cabeça pelo
sacerdote, pelo pontífice na fronte, a fim de a primeira unção significar a descida do Espírito Santo a
uma morada que deve ser consagrada a Deus; e a segunda, a graça septiforme do mesmo Espírito Santo,
descendo ao homem com toda a sua plenitude da santidade, de ciência e de virtude. Logo, essa unção é
reservada aos bispos, não por causa da superioridade da parte do corpo que a recebe, mas pela sua
maior eficácia.

## Art. 12 — Se o rito deste sacramento é o que deve ser.
O duodécimo discute-se assim. — Parece que rito deste sacramento não é o que deve ser.

1. — Pois o sacramento do batismo é de maior necessidade que o da confirmação, como se disse. Ora, o
batismo se celebra nos tempos determinados da Páscoa e do Pentecostes. Logo, também a este
sacramento deve ser prefinado um tempo certo.

2. Demais. — Assim como este sacramento requer a devoção em quem o confere e em quem o recebe,
assim também o batismo. Ora, para receber o batismo não é necessário estar em jejum, nem para
conferi-lo. Logo, parece que o Concílio Aurelianense não estatuiu acertadamente, que estejam em jejum
os que vierem receber a confirmação. E nem o Concílio Meldense: Os bispos não dêem o Espírito Santo,
pela imposição das mãos, senão em estado de jejum.

3. Demais. — A crisma é um sinal da plenitude do Espírito Santo, como se disse. Ora, a plenitude do
Espírito Santo é dada aos fiéís de Cristo no dia de Pentecostes, como se lê na Escritura. Logo, com maior
razão, a crisma deve ser confeccionado e bento, antes, na festa de Pentecostes que na da ceia do
Senhor.
Mas em contrário, o uso da Igreja, governada pelo Espírito Santo.

SOLUÇÃO. — Deve-se dizer que o senhor fez a seguinte promessa aos seus fiéis: Onde se acham dois ou
três congregados em meu nome, aí estou eu no meio deles. Por isso devemos crer firmemente que as
ordenações da Igreja são dirigidas pela sabedoria de Cristo. E por isso, deve ser certo que o rito
observado pela Igreja neste e nos outros sacramento é o que deve ser.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Melquiades Papa, este dois sacramentos,
unidos, a saber, o batismo e a confirmação, de tal modo estão unidos, que salvo em perigo de morte,
não podem ser separados um do outro, e não pode um ser ministrado sem o outro. Por isso, foram
prefixados os mesmos tempos para a celebração solene do batismo e da confirmação. Mas, sendo a
confirmação conferida só pelos bispos, que nem sempre estão presentes quando os presbíteros
batizam, as exigências do uso comum levaram a diferir para tempos diferentes o sacramento da
confirmação.

RESPOSTA À SEGUNDA. — Da referida proibição se excetuam os enfermos e os que estão em perigo de
morte, como se lê nas atas do Concílio Meldense. Por isso, por causa da multidão dos fiéis e de perigos
iminentes, admite-se que a confirmação, que pode ser conferida só pelos bispos, seja recebida e
conferida mesmo por quem não estivesse em jejum. Porque um só bispo, sobretudo numa grande
diocese, não bastaria para confirmar a todos, se o tempo lhe fosse determinado pelo jejum. Mas
quando essa observância puder ser obedecida sem incômodo, é mais conveniente que observem o
jejum tanto quem confere como quem recebe o sacramento.

RESPOSTA À TERCEIRA. — Como se determina no concílio de Martinho Papa, em qualquer tempo em
lícito confeccionar a crisma. Mas como o batismo solene, que exige o uso da crisma; é celebrado na
vigília da Páscoa, ordenou-se acertadamente que dois dias antes o crisma fosse bento pelo bispo, a fim
de poder ser distribuído por toda a diocese. - Demais, esse dia é assaz próprio à bênção das matérias
sacramentais, em que foi instituído o sacramento da Eucaristia, ao qual se ordenam de certo modo
todos os outros sacramentos, como dissemos.
O Sacramento da Eucaristia
Em seguida, devemos tratar do sacramento da Eucaristia. E primeiro, do sacramento em si mesmo.
Segundo, da sua matéria. Terceiro, da sua forma. Quarto; dos seus efeitos. Quinto, dos que o recebem.
Sexto, do seu ministro. Sétimo, do seu rito.