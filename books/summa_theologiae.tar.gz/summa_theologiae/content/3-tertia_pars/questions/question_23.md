# Questão 23: Se a adoção convém a Cristo
Em seguida devemos tratar da adoção – se ela convém a Cristo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a Deus convém adotar filhos.
O primeiro discute-se assim. — Parece que a Deus não convém adotar filhos.

1. — Pois, ninguém adota como filho senão uma pessoa estranha, conforme o ensinam os juristas. Ora,
Deus, sendo criador de todas as coisas, nenhuma pessoa lhe é estranha. Logo, parece que a Deus não
convém adotar.

2. Demais. — A adoção foi introduzida para suprir a falta de filiação natural. Ora, em Deus há filiação
natural, como se estabeleceu. Logo, não convém a Deus adotar filhos

3. Demais. — A adoção tem por fim fazer o adotado suceder na herança do adotante. Ora, ninguém
pode suceder na herança de Deus, porque este nunca morrerá. Logo, a Deus não convém adotar.
Mas, em contrário, o Apóstolo: O qual nos predestinou para sermos seus filhos adotivos. Ora, a
predestinação de Deus não é vã. Logo, Deus adota para si certos como filhos.

SOLUÇÃO. — Adotamos alguém como filho para, por nossa bondade, fazê-lo participar da nossa
herança. Ora, a bondade de Deus é infinita, e por isso admite as suas criaturas a lhe participarem dos
bens; e sobretudo as criaturas racionais, que enquanto feitas à imagem de Deus são capazes da
beatitude divina. E esta consiste na fruição de Deus; pela qual também o próprio Deus é feliz e rico por
si mesmo, por fruir de si mesmo. Ora, chama-se herança de alguém o que o torna rico. Por onde, por
Deus na sua bondade admitir certos homens à herança da beatitude, dizemos que os adota. Mas a
adoção divina tem sobre a humana a vantagem de Deus tornar o homem que adota idôneo, pelo dom
da graça, a receber a herança celeste; ao contrário, o homem não torna idôneo aquele que adota, mas o
escolhe para a adoção já idôneo

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem, considerado na sua natureza, não é estranho
para que Deus, quanto aos bens naturais que recebe, mas é estranho quanto aos bens da graça e da
glória; e é por causa disto que é adaptado.

RESPOSTA À SEGUNDA. — É próprio do homem agir para suprir a sua indigência; mas não, de Deus, a
quem convém o obrar para comunicar a abundância da sua perfeição. Por onde, assim como, pelo ato
de criação, a bondade divina é comunicada a todas as criaturas segundo uma certa semelhança, assim,
pelo ato de adoção é comunicada uma semelhança de filiação natural aos homens, segundo aquilo dos
Apóstolo: Os que ele conheceu na sua presciência também os predestinou para serem conformes à
imagem de seu Filho.

RESPOSTA À TERCEIRA. — Os bens espirituais podem ser possuídos simultaneamente por muitos, mas
não os materiais. Por isso, ninguém pode receber uma herança material senão sucedendo ao morto;
mas a herança espiritual todos a recebem simultânea e integralmente, sem detrimento do Pai sempre
vivo. Embora possamos dizer que o Deus, existente em nós pela fé, morre, para começar a existir em
nós, pela visão, segundo a Glosa àquilo do Apóstolo: Se filhos, também herdeiros.

## Art. 2 — Se adotar convém a toda a Trindade.
O segundo discute-se assim. — Parece que adotar não convém a toda a Trindade.

1. — Pois, a adoção divina é assim chamada por semelhança com as coisas humanas Ora, na ordem
humana, só podem adotar os que podem gerar filhos; o que, em Deus, só cabe ao Pai. Logo, na ordem
divina só o Pai pode adotar.

2. Demais. — Os homens, pela adoção, tornam-se irmãos de Cristo, segundo aquilo do Apóstolo: Para
que ele seja o primogênito de muitos irmãos. Ora, irmãos se chamam os filhos do mesmo pai, donde o
dizer o Senhor: Vou para meu Pai e vosso Pai. Logo, só o Pai de Cristo tem filhos adotivos.

3. Demais. — O Apóstolo diz: Enviou Deus a seu Filho, para que recebêssemos a adoção de filhos. E
porque vós sois filhos, mandou Deus aos vossos corações o Espírito de seu Filho que clama nos vossos
corações Pai, Pai. Logo, é próprio adotar àquele a que o é ter o Filho e o Espírito Santo. Ora, isto só é
próprio à pessoa do Pai. Logo, adotar ó convém à pessoa do Pai.
Mas, em contrário. — É próprio adotar-nos como filhos àquele a quem podemos denominar pai. Donde
o dizer, o Apóstolo: Recebeste a adoção de filhos, no qual clamamos — Pai, Pai. Ora, quando dizemos a
Deus — Padre nosso, referimo-nos a toda a Trindade, como a ele lhe pertencem os outros nomes que
lhe aplicamos relativamente à criatura, como demonstramos na Primeira Parte. Logo, adotar convém a
toda a Trindade.

SOLUÇÃO. — A diferença entre o Filho adotivo e o Filho natural de Deus está em que o Filho natural de
Deus é gerado e não, feito; ao passo que o. filho adotivo é feito, segundo aquilo do Evangelho: Deu-lhes
ele o poder de se fazerem filhos de Deus. Mas às vezes dizemos que o filho adotivo é gerado, por ter
recebido uma nova geração espiritual. que é gratuita e não, natural; donde o dizer a Escritura: De pura
vontade sua é que ele nos gerou. Embora, pois, gerar. em Deus, seja próprio da pessoa do Pai, contudo
produzir qualquer efeito. nas criatura é comum a toda a Trindade. por causa da unidade de natureza:
porque onde há uma natureza é necessário haver uma virtude e uma operação. Donde o dizer o Senhor:
Tudo o que fizer o Pai o faz também semelhantemente o Filho. Por onde, adotar os homens como filhos
de Deus convém a toda a Trindade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todas as pessoas humanas não são numericamente da
mesma natureza, para que tenham todas a mesma operação e um mesmo efeito, como acontece com
Deus. E por isso, aí não há fundamento para semelhança, em ambos os casos.

RESPOSTA À SEGUNDA. — Nós por adoção nos tornamos irmãos de Cristo, quase tendo o mesmo Pai
que ele. O qual, contudo, de um modo, é Pai de Cristo e, de outro. nosso Pai. Por isso sinaladamente diz
o Evangelho, em separado – Meu Pai, e em separado, Vosso Pai. Pois, é Pai de Cristo, naturalmente, pela
geração, o que lhe é próprio a ele; mas é nosso Pai, por agir voluntariamente, o que lhe é comum a ele,
ao Filho e ao Espírito Santo. Por isso não é filho de toda a Trindade, como nós.

RESPOSTA À TERCEIRA. — Como dissemos, a filiação adotiva é uma certa semelhança da filiação eterna;
assim como tudo o que foi feito no tempo é de certo modo semelhança das coisas abeterno existentes.
Ora, o homem é assimilado ao esplendor do Filho eterno pela claridade da graça, atribuída ao Espírito
Santo. Por onde, a adoção, embora comum a toda a Trindade, é contudo apropriada ao Pai como autor,
ao Filho como exemplar, ao Espírito Santo como o que imprime em nós a semelhança desse exemplar.

## Art. 3 — Se ser adotado é próprio da criatura racional.
O terceiro discute-se assim. — Parece que ser adaptado não é próprio da criatura racional.

1. — Pois, Deus não é chamado Pai da criatura racional senão por adoção. Pois, é também chamado Pai
da criatura irracional, como quando a Escritura diz: Quem é o Pai da chuva? ou quem produziu as gotas
de orvalho? Logo, ser adaptado não é próprio da criatura racional.

2. Demais. — Certos se chamam filhos de Deus por adoção Ora, o serem filhos de Deus a Escritura
propriamente o atribui aos anjos, como naquele passo: Mas um certo dia como os filhos de Deus se
tivessem apresentado na frente do Senhor. Logo, não é próprio da criatura racional o ser adaptado.

3. Demais. — O próprio a uma natureza convém a todos os seres que a tem; assim, a faculdade de rir
convém a todos os homens. Ora, ser adaptado não convém a toda natureza racional. Logo, ser adaptado
não é próprio à natureza racional.
Mas, em contrário, os filhos adaptados são herdeiros de Deus, como diz o Apóstolo. Ora, tal herança
convém à criatura racional. Logo, é próprio da criatura racional ser adaptada.

SOLUÇÃO. — Como dissemos, a filiação da adoção é uma certa semelhança da filiação natural. Pois, o
Filho de Deus naturalmente procede do Pai, como Verbo mental, tendo unidade de existência com ele.
Ora, a esse Verbo pode um ser se assemelhar, de três modos. De um modo, em razão da forma, mas não
pela mente; assim, a forma exterior de uma casa construída se assemelha ao Verbo mental do artífice,
pela espécie formal; mas não pela mente, porque a forma da casa, na matéria; não é inteligível, quando
o era na mente do artífice. E deste modo, qualquer criatura se assimila ao Verbo eterno, por ter sido
feita pelo Verbo. - De um segundo modo, uma criatura se assimila ao Verbo, não só em razão da forma,
mas ainda quanto a sua mente, assim, a ciência, que nasce na mente do discípulo, se assimila ao Verbo
existente na mente do Mestre. E deste modo, a criatura racional, mesmo pela sua natureza, se
assemelha ao Verbo de Deus, pela unidade que tem com o Pai; resultante da graça e da caridade. Por
isso o Senhor orava: Para que eles sejam um, como também nós somos um. E tal assimilação completa a
ideia de adoção, pois, a seres assim assimilados é lhes devida a herança eterna. — Por onde é manifesto,
que ser adotado convém só à criatura racional, mas não a todas, senão só as que tem a caridade, que
está derramada em nossos corações pelo Espírito Santo, no dizer do Apóstolo. E por isso, ainda na frase
do Apóstolo, o Espírito Santo se chama espírito de adoção de filhos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus é chamado Pai da criatura irracional, não
propriamente pela adoção, mas pela criação, participando da semelhança, no primeiro sentido.

RESPOSTA À SEGUNDA. — Os anjos se chamam filhos de Deus pela filiação adotiva; não que ela lhes
convenha primariamente, mas por terem sido eles os primeiros que receberam a adoção de filhos.

RESPOSTA À TERCEIRA. — A adoção não é uma propriedade resultante da natureza, mas, da graça da
qual a natureza racional é capaz. Por isso, não é necessário convenha a toda criatura racional. Mas sim,
que toda criatura racional seja capaz da filiação adotiva.

## Art. 4 — Se Cristo, enquanto homem, é filho adotivo de Deus.
O quarto discute-se assim. — Parece que Cristo, enquanto homem, é filho adotivo de Deus.

1. — Pois, diz Hilário, referindo-se a Cristo: Não perde a dignidade do poder quando adapta a humildade
da carne. Logo, Cristo, enquanto homem, é filho adotivo.

2. Demais. — Agostinho diz, que Cristo é homem pela mesma graça pela qual alguém se torna Cristão
em virtude da fé inicial. Ora, os outros homens são Cristãos pela graça da adoção. Logo, também Cristo
é homem por adoção E portanto, é filho adotivo.

3. Demais. — Cristo, enquanto homem, é servo. Ora, é mais digno ser filho adotivo, que servo. Logo,
com maior razão, Cristo, enquanto homem é filho adotivo.
Mas, em contrário, diz Ambrósio: Não consideramos o filho adotivo como filho por natureza; mas
dizemos filho por natureza o que verdadeiramente o é. Ora, Cristo é verdadeiro e natural Filho de Deus,
segundo o Evangelho: Para que estejamos em seu verdadeiro Filho, Jesus Cristo. Logo, Cristo, enquanto
homem, não é filho adotivo.

SOLUÇÃO. — A filiação propriamente convém à hipóstase ou à pessoa, mas não à natureza; por isso na
Primeira Parte dissemos, que a filiação é uma propriedade pessoal. Ora, em Cristo não há outra pessoa
ou hipóstase além da incriada, o que convém ser Filho por natureza. Pois, como dissemos, a filiação da
adoção é uma semelhança participada da filiação natural. Ora, não dizemos que existe
participativamente o que por si mesmo existe. E por isso, Cristo. que é por natureza Filho de Deus, de
nenhum modo pode ser chamado filho adotivo. — Quanto aos que atribuem a Deus duas pessoas ou
duas hipóstases ou dois supostos, nada racionalmente os impediria dizer que Cristo, enquanto homem,
é filho adotivo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como a filiação propriamente não convém à
natureza, assim também não, a adoção. E por isso, é expressão imprópria dizer que foi adotada a
humildade da carne; entendendo-se aí por adoção a união da natureza humana com a pessoa do Filho.

RESPOSTA À SEGUNDA. — Essa semelhança de Agostinho devemos entendê-la quanto ao princípio; isto
é, porque, assim como não é por méritos de sua parte que qualquer homem é Cristão, assim não foi por
nenhum mérito que o homem Cristo foi Cristo. Mas esses dois casos diferem pelo termo, porque Cristo,
pela graça da união, é Filho por natureza; ao passo que qualquer homem é filho adotivo pela graça
habitual. Mas, a graça habitual, em Cristo, não o fez passar, de não filho, a filho adotivo; é apenas uma
consequência da filiação natural, na alma de Cristo, segundo aquilo do Evangelho: Nós vimos a sua
glória, como de Filho unigênito do Pai, cheio de graça e de verdade.

RESPOSTA À TERCEIRA. — O ser criatura e também a servidão ou a sujeição a Deus não respeitam só à
pessoa mas ainda à natureza; o que não pode dizer-se da filiação. Por isso não colhe a comparação.