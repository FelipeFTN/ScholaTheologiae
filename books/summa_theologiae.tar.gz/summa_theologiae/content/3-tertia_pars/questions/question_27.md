# Questão 27: Da santificação da Virgem Maria
Depois de termos tratado da união de Deus e do homem e do que resulta dessa união, resta tratarmos
do que fez ou sofreu o Filho de Deus encarnado na natureza humana a que se uniu. Cujo tratado é
quadripartido. Assim, primeiro, consideraremos o pertinente ao seu ingresso no mundo. Segundo, o
pertinente ao desenrolar-se da sua vida neste mundo. Terceiro, a sua partida deste mundo. Quarto, do
relativo à sua exaltação, depois desta vida.
No primeiro tratado, quatro pontos devem ser considerados. Primeiro, a concepção de Cristo. Segundo,
a sua natividade. Terceiro, a sua circuncisão. Quarto, o seu batismo. Sobre a sua concepção, devemos,
primeiro, tratar de certos pontos relativos à conceição de sua mãe. Segundo, do modo da conceição.
Terceiro, da perfeição do filho concebido. Quanto à mãe, quatro questões se oferecem ao nosso exame.
Primeiro, a sua santificação. Segundo, a sua virgindade. Terceiro, os seus desposórios. Quarto, a sua
anunciação. Quinto, a sua preparação para conceber.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a Santa Virgem foi santificada antes de nascer, no ventre materno.
O primeiro discute-se assim. — Parece que a Santa Virgem não foi santificada antes de nascer, no
ventre materno.
1 — Pois, diz o Apóstolo: Não primeiro o que é espiritual, senão o que é animal, depois o que é
espiritual. Ora, pela graça da santificação o homem nasce espiritualmente filho de Deus, segundo aquilo
do Evangelho: Nasceram de Deus. Mas, a natividade, do ventre, é uma natividade corpórea. Logo, a
Santa Virgem não foi santificada, antes de nascer do ventre materno.
2 — Demais. Agostinho diz: A santificação, que nos torna templos de Deus, só é a dos renascidos. Ora,
ninguém renasce senão depois de nascer. Logo, a Santa Virgem não foi santificada, ante de nascida do
ventre materno.
3 — Demais. Todo santificado pela graça é purificado do pecado original e do atual. Se, pois, a Santa
Virgem foi santificada antes da natividade no ventre materno, foi então, por consequência purificada do
pecado original. Ora, só o pecado original podia impedir-lhe a entrada no reino celeste. Se, portanto,
tivesse morrido, então, teria transposto as portas do reino celeste. O que contudo não podia dar-se,
antes da paixão de Cristo; pois, como diz o Apóstolo, temos confiança de entrar no santuário, pelo
sangue de Cristo. Donde se conclui, portanto, que a Santa Virgem não foi santificada antes de nascida do
ventre materno.
4 — Demais. O pecado original é o que vem de origem, assim como o pecado atual, o que pressupõe um
ato. Ora, enquanto praticamos o ato de pecar não podemos ser purificados do pecado. Logo, também a
Beata Virgem não podia ser purificada do pecado original, enquanto existia original e atualmente no
ventre materno.
Mas, em contrário, a Igreja celebra a natividade da Santa Virgem; ora, a Igreja não celebra nenhuma
festa senão por algum santo. Logo, a Santa Virgem, na sua natividade mesma, não foi santa. Logo, foi
santificada no ventre materno.

SOLUÇÃO. — Sobre se a Santa Virgem foi santificada no ventre materno, nada nos ensina a Escritura
canônica, a qual também não faz menção da sua atividade. Mas, assim como Agostinho prova com
razões que a Virgem foi assunta ao céu em corpo, o que contudo não o diz a Escritura, assim também
podemos pensar racionalmente que foi santificada no ventre materno. Pois, é racional crermos, que
aquela que gerou o Unigênito do Pai, cheio de graça e de verdade, recebeu maiores privilégios de graça
que as demais mulheres. E por isso diz o Evangelho, que o Anjo lhe anunciou: Ave, cheia de graça. Pois,
sabemos que a certos foi concedido esse privilégio da santificação no ventre materno; assim, a Jeremias,
a quem foi dito – Antes que tu saísses da clausura do ventre materno, te santifiquei. E a João Batista, de
quem foi dito. Já desde o ventre de sua mãe será cheio do Espírito Santo. Por onde e racionalmente,
cremos que a Santa Virgem foi santificada, antes de nascer, no ventre materno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Também na Santa Virgem primeiro existiu o corpo e
depois, o espírito; pois, foi primeiro concebida carnalmente e depois, santificada no seu espírito.

RESPOSTA À SEGUNDA. — Agostinho se exprime segundo a lei comum, pela qual ninguém se regenera
pelos sacramentos senão depois de ter nascido. Mas Deus não sujeitou o seu poder a essa lei dos
sacramentos, que não pudesse conferir a sua graça, por um especial privilégio, a certos, mesmo antes
de nascidos do ventre materno.

RESPOSTA À TERCEIRA. — A Santa Virgem foi purificada, no ventre materno, do pecado original, quanto
à mácula pessoal; mas não ficou isenta do reato, a que toda natureza estava sujeita, não podendo por
isso entrar no paraíso, senão mediante o sacrifício de Cristo; como também se deu com os santos
Patriarcas que existiram antes de Cristo.

RESPOSTA À QUARTA. — O pecado original foi contraído na origem, pois é pela origem que se comunica
a natureza humana, a que propriamente respeita o pecado original. O que se dá quando a criatura
concebida recebe a alma. E por isso nada impede seja ela purificada, depois de recebida a alma; pois,
depois disso, se ainda continua no ventre materno, é para receber, não a natureza humana, mas uma
certa perfeição da natureza já recebida.

## Art. 2 — Se a Santa Virgem foi santificada antes de ser animada.
O segundo discute-se assim. — Parece que a Santa Virgem foi santificada antes de ser animada.
1 - Pois, como se disse, mais graças foram conferidas à Virgem Mãe de Deus, que a qualquer santo. Ora,
a certos foi concedido o serem santificados antes da animação. Pois, diz a Escritura: Antes que eu te
formasse no ventre de tua mãe, te conheci; ora, a alma não é infundida antes da formação do corpo.
Semelhantemente, diz, de João Batista, Ambrósio: Ainda não tinha o espírito da vida e já nele existia o
Espírito da graça. Logo, com muito maior razão, a Santa Virgem podia ser santificada, antes da
animação.

2. Demais. — Era conveniente, como diz Anselmo, que a Santa Virgem resplendesse pela maior pureza
possível, logo abaixo de Deus. Donde o dizer a Escritura: Toda tu és formosa, amiga minha, e em ti não
há mácula. Ora, maior seria a pureza da Santa Virgem se nunca a sua alma tivesse sido inquinada do
contágio do pecado original. Logo, foi-lhe concedida a santificação da carne, antes de animada.

3. Demais. — Como se disse, não se celebra festa senão de quem é santo. Ora, certos celebram a festa
da Conceição da Santa Virgem. Logo, parece que foi santa na sua concepção mesma. E assim foi
santificada antes da animação.

4. Demais. — O Apóstolo diz: Se a raiz é Santa, também os ramos. Ora, a raiz dos filhos são os seus pais.
Logo, a Santa Virgem também podia ser santificada nos seus pais antes da animação.
Mas, em contrário, as coisas do Antigo Testamento são as figuras do Novo, conforme aquilo do
Apóstolo: Todas estas coisas lhes aconteciam a eles em figura. Ora, parece que a santificação do
tabernáculo, do qual diz a Escritura — santificou o seu tabernáculo o Altíssimo — significa a santificação
da Mãe de Deus, chamada também pela Escritura, tabernáculo de Deus, como se lê: No sol pôs o seu
tabernáculo. E do tabernáculo foi ainda dito: Depois de acabadas todas estas coisas, cobriu uma nuvem
o tabernáculo do testemunho e a glória do Senhor o encheu. Logo, também a Santa Virgem não foi
santificada, senão depois de perfeitas todas as suas partes, isto é, o corpo e a alma.

SOLUÇÃO. — Dupla razão podemos dar, da santificação da Santa Virgem, antes de animada. A primeira
é que, a santificação, de que tratamos não é mais que a purificação do pecado original; pois, a santidade
é a pureza perfeita, como diz Dionísio. Ora, a culpa só pode ser delida pela graça, cujo sujeito só é a
criatura racional. E por isso, antes, da infusão da alma racional, a Santa Virgem não foi purificada. —
Segundo, porque, sendo susceptível de culpa só a criatura racional, o ser concebido não é contaminado
pela culpa senão depois da infusão da alma racional. Assim, de qualquer modo que a Santa Virgem fosse
santificada, antes da animação, não teria nunca incorrido na mácula da culpa original; e, portanto, não
teria precisado da redenção e da salvação, operada por Cristo, de quem diz o Evangelho: Ele salvará o
seu povo dos pecados deles. Ora, é inadmissível que Cristo não seja o Salvador de todos os homens,
como diz o Apóstolo. - Donde se conclui, que a santificação da Santa Virgem se deu depois da sua
animação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando o Senhor diz que conheceu Jeremias, antes de
formado no ventre materno, isso se entende, pela ciência de predestinação; mas diz que o santificou,
não antes de formado, mas antes de saído do ventre materno. — Quanto ao dizer Ambrósio, que João
Batista ainda não tinha o espírito da vida e já tinha o Espírito da graça, não se deve entender como
significando o espírito da vida a alma vivificante, mas significando espírito o ar exterior respirado. Ou
podemos dizer, que ainda não tinha o espírito da vida, isto é, a alma, nas suas operações manifestas e
completas.

RESPOSTA À SEGUNDA. — O não ter sido nunca a alma da Santa Virgem inquinada do contágio do
pecado original, se oporia à dignidade de Cristo, como Salvador universal de todos. Por isso, logo abaixo
de Cristo, que não precisava ser salvo, como Salvador universal, a máxima pureza foi a de Santa. Virgem.
Pois, Cristo de nenhum modo contraiu o pecado original, mas foi santo desde a sua conceição, segundo
aquilo do Evangelho: O santo que há de nascer de ti será chamado Filho de Deus. Mas, a Santa Virgem
contraiu por certo o pecado original, sendo contudo dele purificada, antes de nascida do ventre
materno. E é o que significa a Escritura quando diz, referindo-se à noite do pecado original. Espere a luz,
isto é, Cristo, e não a veja – porque nada mais manchado cai nela; nem o nascimento da aurora quando
raia, isto é, da Santa Virgem, que, no seu nascimento, foi imune do pecado original.

RESPOSTA À TERCEIRA. — Embora não celebre a Igreja Romana a Conceição da Santa Virgem, tolera
contudo o costume de certas igrejas celebrarem essa festividade. Por isso, não deve essa celebração ser
totalmente reprovada. Nem o fato, porém, de ser celebrada a festa da Conceição, significa que a Virgem
foi santa na sua Conceição. Mas sim, que por se lhe ignorar o tempo da santificação, celebram-lhe a
festa da santificação, antes que a da conceição, no dia da conceição.

RESPOSTA À QUARTA. — Há duas espécies de santificação. — Uma, de toda a natureza, isto é,
enquanto que toda a natureza é liberada totalmente da corrupção da culpa e da pena. O que se dará na
ressurreição. — Outra é a santificação pessoal, que não se transmite à prole carnalmente gerada,
porque não diz respeito essa santificação à carne, mas, ao espírito. Por onde, se os pais da Santa Virgem
foram purificados do pecado original, contudo a Santa Virgem não deixou de contrair o pecado original,
por ter sido concebida na concupiscência da carne e pela conjunção do homem e da mulher. Assim, diz
Agostinho: Tudo o nascido do concúbito é carne de pecado.

## Art. 3 — Se a Santa Virgem foi purificada do contágio do gérmen da concupiscência.
O terceiro discute-se assim. — Parece que a Santa Virgem não foi purificada do contágio do gérmen da
concupiscência.

1. Pois, assim como a pena do pecado original é a concupiscência, consistente na rebelião das potências
inferiores contra a razão, assim também a pena do pecado original é a morte e as demais penalidades
corpóreas. Ora, a Santa Virgem foi sujeita a essas penalidades. Logo, também não foi totalmente isenta
da concupiscência.

2. Demais. — O Apóstolo diz: A virtude se aperfeiçoa na enfermidade, referindo-se à enfermidade da
concupiscência, por causa da qual sofria o estímulo da carne. Ora, a Santa Virgem não foi privada de
nada do que exige a perfeição da virtude. Logo, não foi de todo isenta da concupiscência.

3. Demais. — Damasceno diz, que o Espírito Santo sobrevém à Santa Virgem, purificando-a antes da
concepção do Filho de Deus. O que não pode entender-se senão da purificação da concupiscência, pois,
nenhum pecado cometeu, como diz Agostinho. Logo, pela santificação no ventre materno não foi de
todo isenta da concupiscência.
Mas, em contrário, a Escritura: Toda tu és formosa, amiga minha, e em ti não há mácula. Ora, a
concupiscência é mácula, pelo menos da carne. Logo, na Santa Virgem não houve concupiscência.

SOLUÇÃO. — Nesta matéria divergem as opiniões. — Assim, uns disseram que a Santa Virgem, pela sua
santificação mesma, operada no ventre materno, ficou totalmente isenta da concupiscência. — Mas
outros dizem que lhe permaneceu a concupiscência, enquanto causa de dificuldade na prática do bem;
ficou porém dela isenta, enquanto inclinação para o mal. — Outros, ainda, disseram que ficou isenta da
concupiscência, no atinente à corrupção da pessoa, enquanto impede para o mal e dificulta o bem; mas
não o ficou, quanto à corrupção da natureza, isto é, enquanto a concupiscência é a causa da transmissão
do pecado original aos filhos. — Outros, enfim, dizem que, a primeira santificação não eliminou a
concupiscência, mas a deixou travada nos seus efeitos; sendo porém totalmente eliminada na
concepção mesma do Filho de Deus.
Mas, para bem compreendermos, neste assunto, devemos notar que contágio do pecado nada mais é
que uma concupiscência desordenada do apetite sensível; mas, habitual, porque a concupiscência atual
é o movimento do pecado. Diremos porém que a concupiscência da sensualidade é desordenada,
porque repugna à razão; o que se dá, por inclinar para o mal ou opor dificuldades ao bem. Por onde, é
da natureza mesma da concupiscência inclinar para o mal, ou dificultar a prática do bem. Por isso, dizer
que a concupiscência existiu na Santa Virgem, sem a inclinar para o mal, é querer que coexistam duas
coisas opostas. - Semelhantemente, também implica oposição o permanecer da concupiscência
enquanto corrupção da natureza e não enquanto corrupção da pessoa. Pois, segundo Agostinho, é a
concupiscência que transmite para a prole o pecado original. Ora, essa é uma concupiscência
desordenada e não totalmente sujeita à razão. Se, pois, a concupiscência tivesse sido totalmente
eliminada, enquanto corrupção da pessoa, não poderia permanecer enquanto corrupção da natureza.
Resta, pois, admitirmos ou que a primeira santificação a isentou totalmente da concupiscência ou que,
se esta subsistiu, ficou travada nos seus efeitos. Pois, poder-se-ia entender que a concupiscência ficou
totalmente eliminada, na Santa Virgem, por lhe ter sido concedida, pela abundância da graça que lhe foi
conferida, uma tal disposição das potências da alma, que as inferiores nunca se movessem sem o
assentimento da razão. Tal o que dissemos ter passado com Cristo, de quem sabemos que não teve
inclinação para o pecado, e com Adão, antes do pecado, pela justiça original. De modo que, assim, nesta
matéria, a graça da santificação teve para a Virgem a virtude da justiça original. Mas, embora esta
opinião venha salvar a dignidade da Virgem Mãe, contraria de algum modo à dignidade de Cristo, sem
cuja virtude ninguém pode livrar-se da condenação primitiva. E embora pela fé de Cristo, e, antes da sua
Encarnação, certos fossem espiritualmente livres dessa condenação, contudo ninguém poderia livrar-se
dela, quanto à carne, senão depois da Encarnação, pela qual devia primariamente manifestar-se a
imunidade dessa condenação. Por onde, assim como antes da imortalidade da carne de Cristo
ressurrecto, ninguém alcançou a imortalidade da carne, assim é inconveniente admitirmos que, antes da
carne de Cristo, que não teve nenhum pecado, a carne da Virgem sua Mãe, ou de quem quer que seja,
fosse isenta da concupiscência, chamada lei da carne ou dos membros.
Por isso parece melhor pensarmos que, a santificação no ventre materno não isentou a Santa Virgem da
concupiscência, na sua essência, mas os seus efeitos ficaram paralisados. Não por ato da sua razão,
como se deu com os varões santos; pois, não teve o uso do livre arbítrio logo que começou a existir no
ventre materno – privilégio especial de Cristo; mas, a abundância da graça, recebida na santificação, e
ainda mais perfeitamente por ação da divina providência, paralisou-lhe todo movimento desordenado
dos sentidos. Mas, depois, na concepção mesma da carne de Cristo, quando primeiramente devia
refulgir a imunidade do pecado, devemos crer que do filho redundou ela para a mãe, ficando então
totalmente eliminada a inclinação para o pecado. E já isso estava figurado na Escritura, quando diz: Eis
que entrava a glória do Deus de Israel pela banda do oriente, isto é, por meio da Santa Virgem; e a terra
estava resplandecente pela presença da sua majestade, isto é de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A morte e outras penalidades semelhantes por si
mesmas não inclinam ao pecado. E por isso Cristo, embora assumisse a elas, não se sujeitou à
concupiscência. E por isso também na Santa Virgem, para conformar-se ao Filho, de cuja plenitude
recebeu a graça - primeiro, a concupiscência ficou impedida nos seus efeitos e, depois, foi eliminada;
mas não ficou livre da morte e de outras penalidades semelhantes.

RESPOSTA À SEGUNDA. — A fraqueza da carne constituída pela sua inclinação ao pecado, é certo, para
os varões santos uma ocasião de virtude perfeita; mas não a causa sem a qual não possa a perfeição ser
alcançada. Basta, pois, atribuir à Santa Virgem a virtude perfeita pela abundância da graça; nem lhe é
preciso atribuir toda ocasião possível de perfeição.

RESPOSTA À TERCEIRA. — O Espírito Santo operou na Santa Virgem uma dupla purificação. - Uma,
quase preparatória à conceição de Cristo, que veio, não purificá-la de qualquer impureza da culpa ou da
concupiscência, mas imprimir mais profundamente na sua alma o caráter de unidade e elevá-la acima da
multidão. Assim, também dizemos que são purificados os anjos, nos quais não há nenhuma impureza,
como diz Dionísio. - A outra purificação o Espírito Santo operou na Santa Virgem, mediante a concepção
de Cristo, obra do mesmo Espírito. E, por ela, podemos dizer que a purificou totalmente da
concupiscência.

## Art. 4 — Se pela santificação no ventre materno a Santa Virgem foi preservada de todo pecado atual.
O quarto discute-se assim. — Parece que, pela santificação no ventre materno, a Santa Virgem não foi
preservada de todo pecado atual.

1. — Pois, como se disse, depois da primeira purificação, permaneceu na Virgem a inclinação para o
pecado. Ora, o movimento da concupiscência, mesmo se prevenir a razão, é pecado venial, embora
levíssimo, como diz Agostinho. Logo, na Santa Virgem houve algum pecado venial.

2. Demais. — Aquilo do Evangelho — Uma espada transpassará a tua mesma alma — diz Agostinho, que
a Santa Virgem, na morte do Senhor, duvidou por causa da sua dor imensa. Ora, duvidar da fé é pecado.
Logo, não foi preservada imune de todo pecado.

3. Demais. — Crisóstomo, expondo aquilo do Evangelho — Olha que tua mãe e teus irmãos estão ali fora
e te buscam — diz: É manifesto que só por vanglória o faziam. E aquele outro lugar do Evangelho — não
tem vinho — diz o mesmo Crisóstomo, que ela queria assim fazer-lhes uma graça e tornar-se mais
ilustre, pelo seu Filho; e talvez resolvia algo de humano em seu coração, como os seus irmãos que
diziam — manifesta-te a ti mesmo ao mundo. E logo depois acrescenta: Ainda não tinha dele a opinião
que devia ter. O que tudo constitui pecado. Logo, a Santa Virgem não foi preservada imune de todo
pecado.
Mas, em contrário, Agostinho: Quando se trata da Santa Virgem, de nenhum modo admito que se fale
em pecado, por causa da honra de Cristo. Não podemos duvidar tivesse ela recebido uma graça
excepcional para vencer inteiramente o pecado, pois mereceu conceber e dar a luz àquele que sabemos
foi absolutamente isento de pecado.

SOLUÇÃO. — Aqueles que Deus escolhe para algum fim, ele os prepara e dispõe, para serem idôneos ao
fim para que foram escolhidos, segundo aquilo do Apóstolo: O qual nos fez idôneos ministros do Novo
Testamento. Ora, a Santa Virgem foi divinamente escolhida para ser a Mãe de Deus. E por isso não
devemos duvidar não a tenha Deus tornado idônea para tal, pela sua graça, segundo o anjo lhe
anunciou: Achaste graça diante de Deus – eis conceberás, etc. Ora, não teria sido idônea para Mãe de
Deus, se algum pecado tivesse cometido. — Quer porque a honra dos pais redunda para os filhos,
segundo a Escritura: A glória dos filhos são os pais deles; e, por oposição, a ignomínia da mãe redundaria
para o Filho. — Quer também porque tinha uma singular afinidade com Cristo, que dela recebeu a
carne. Donde o dizer o Apóstolo: Que concórdia entre Cristo e Belial? - Quer ainda porque de um modo
singular o Filho de Deus, que é a sabedoria de Deus, nela habitou; não só na alma, mas também no
ventre. Assim, diz a Escritura: na alma maligna não entrará a sabedoria, nem habitará no corpo sujeito a
pecados. - E por isso devemos pura e simplesmente confessar que a Santa Virgem não cometeu nenhum
pecado atual, nem mortal e nem venial, de modo que nela se cumpriu o lugar da Escritura: Toda tu és
formosa, amiga minha, e em ti não há mácula, etc.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na Santa Virgem, depois de santificada no ventre,
permaneceu por certo a inclinação para o pecado, mas sem produzir efeitos, não podendo por isso
prorromper em nenhum movimento desordenado, que prevenisse a razão. E embora para isso
contribuísse a graça da santificação, contudo para tal não bastava; do contrário, em virtude dessa graça,
lhe teria sido concedido não existir nenhum movimento nos seus sentidos que não fosse prevenido pela
razão; e então, nenhuma concupiscência teria, o que vai contra o já estabelecido. Donde devemos
concluir, que o complemento a essa paralisação da concupiscência proveio da divina providência, que
não permitia brotar nenhum movimento desordenado, da concupiscência.

RESPOSTA À SEGUNDA. — Às referidas palavras de Simeão Orígenes, certos outros doutores as aplicam
a dor sofrida por Cristo na paixão. - Quanto a Ambrósio, pela espada entende significar a prudência de
Maria, não ignorante do mistério celeste. Pois, vivo é o verbo de Deus, válido e mais agudo que toda
espada de dois gumes. - Outros, porém, entendem por isso a espada da dúvida não devendo, porém,
entender-se se por esta a dúvida da infidelidade, mas a da admiração e da discussão. Assim, diz Basílio,
que a Santa Virgem, aos pés da cruz e presenciando tudo o que se passou, depois mesmo do
testemunho de Gabriel, depois do inefável conhecimento da divina concepção, depois da ingente
realização dos milagres, flutuava na sua alma, vendo, de um lado, as humilhações que sofria seu Filho e,
de outro, as maravilhas que realizava.

RESPOSTA À TERCEIRA. — As palavras citadas de Crisóstomo são exageradas. Podem, porém, ser
interpretadas de modo a significar que o Senhor coibiu, não o movimento desordenado da vanglória, em
si mesma, mas em relação à opinião que podiam ter os outros.

## Art. 5 — Se a Santa Virgem, pela santificação no ventre materno, obteve a plenitude ou a perfeição da graça.
O quinto discute-se assim. — Parece que a Santa Virgem, pela santificação no ventre materno, não
obteve a plenitude ou a perfeição da graça.

1. — Pois, isso constitui privilégio de Cristo, segundo o Evangelho: Nós vimos a sua glória de Filho
unigênito do Pai, cheio de graça e de verdade. Ora. o próprio de Cristo a ninguém mais deve ser
atribuído. Logo, a Santa Virgem, não recebeu, na santificação, a plenitude das graças.

2. Demais. — Ao que tem a plenitude e a perfeição nada se lhe pode acrescentar, pois, perfeito é o ao
que nada falta, segundo Aristóteles. Ora, a Santa Virgem recebeu, depois da sua santificação. um
aumento de graça, quando concebeu a Cristo; pois, diz o Evangelho: O Espírito Santo descerá sobre ti. E
ainda, quando foi da sua assunção para a glória. Logo, parece que não teve, na sua primeira santificação,
a plenitude das graças.

3. Demais. — Deus nada faz em vão, como diz Aristóteles. Ora, a Santa Virgem teria tido em vão certas
graças, cujo uso nunca exerceu; pois, o Evangelho não nos diz que ela tivesse ensinado, o que seria o
exercício da sabedoria; nem que tivesse feito milagres, exercício da graça gratuita. Logo, não teve a
plenitude das graças.
Mas, em contrário, o Anjo lhe disse: Ave cheia de graça. O que Jerônimo assim explica: Na verdade,
cheia de graça; pois, ao passo que os outros as recebem por partes, em Maria se lhe infundiu total e
simultaneamente a plenitude das graças.

SOLUÇÃO. Quanto mais uma coisa se aproxima do princípio, num determinado gênero, tanto mais
participa do efeito desse princípio; por isto diz Dionísio, que os anjos, mais próximos de Deus, mais,
participam da bondade divina, que os homens. Ora, Cristo é o princípio da graça; pela divindade, como
autor dela; pela humanidade, como instrumento. Donde o dizer o Evangelho: A graça e a verdade foi
trazida por Jesus Cristo. Ora, a Santa Virgem Maria foi a mais próxima de Cristo pela humanidade, pois
dela recebeu ele a natureza humana. Por isso, mais que ninguém, devia receber de Cristo a plenitude da
graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A cada um Deus dá a graça conforme o para que é
escolhido. E como Cristo, enquanto homem foi predestinado e escolhido para que fosse, no dizer do
Apóstolo, predestinado Filho de Deus com poder, segundo o espírito de santificação, era-lhe próprio ter
uma plenitude de graça tal que redundasse para os outros, conforme aquilo do Evangelho: Todos nós
participamos da sua plenitude. A Santa Virgem Maria, porém, obteve a plenitude de modo a ser a mais
chegada ao autor da graça; de maneira que recebesse em si o que é a plenitude de todas as graças e,
dando-o a luz, a graça em algum sentido derivasse para todos.

RESPOSTA À SEGUNDA. — Na ordem natural, o que primeiro existe é a perfeição da disposição, por
exemplo, a perfeição da matéria para receber a forma. Depois vem a perfeição da forma superior;
assim, mais perfeito é o calor em si, proveniente da forma do fogo, que o que dispôs para a forma ígnea.
Em terceiro lugar, vem a perfeição do fim: assim, o fogo tem as suas qualidades no grau mais perfeito,
quando chegado ao seu lugar.
Semelhantemente, tríplice perfeição houve na Santa Virgem. — A primeira, e como dispositiva, que a
tornava idônea para ser Mãe de Cristo. É essa foi a perfeição da santificação. — A segunda perfeição da
graça foi na Santa Virgem, a presença do Filho de Deus incarnado no seu ventre. — A terceira foi a
perfeição do fim, que desfruta na glória.
Ora, que a segunda perfeição é superior à primeira e à terceira, que a segunda, é claro, de um modo,
pela liberação do mal. Pois, primeiro, pela sua santificação foi liberta da culpa original; depois, na
conceição do Filho de Deus, foi totalmente purifica da da concupiscência; enfim, em terceiro lugar pela
sua glorificação, foi libertada também de todas as misérias da vida. — De segundo modo, pela
ordenação para o bem. Assim, primeiro, na sua santificação, alcançou a graça, que inclina para o bem;
depois, na concepção do Filho de Deus, consumou-se-lhe a graça, tendo sido confirmada no bem; e
enfim na sua glorificação, consumou-se-lhe a graça, que lhe deu a fruição perfeita de todos os bens.

RESPOSTA À TERCEIRA. — Não podemos duvidar que recebesse a Santa Virgem, e excelentemente, o
dom da sabedoria e a graça das virtudes e também a graça da profecia, como a teve Cristo. Não as
recebeu, porém, de modo a ter o uso de todas essas graças e de outras semelhantes, como o teve
Cristo; mas só na medida em que lhe convinha à sua condição. — Assim, teve o uso da sabedoria, na
contemplação, segundo o Evangelho: Maria conservava todas essas palavras, conferindo lá no fundo do
seu coração umas com as outras. Mas, não teve o uso da sabedoria, porque ensinasse, pois isso não
convinha ao sexo feminino, segundo aquilo do Apóstolo: Eu não permito à mulher que ensine. —
Quanto à realizar milagre, não lhe convinha durante a vida, porque, nesse tempo a doutrina devia
confirmar-se pelos milagres de Cristo; por isso só a Cristo e aos seus discípulos, portadores da doutrina
de Cristo, convinha fazer milagres. Por isso, mesmo de João Batista diz o Evangelho, que não fez
nenhum milagre; e isso para que todos buscassem a Cristo. — E enfim, o uso da profecia ela o teve,
como o declara o Cântico que fez: A minha alma magnifica o Senhor.

## Art. 6 — Se ser santificada no ventre materno foi, depois de Cristo, próprio à Santa Virgem.
O sexto discute-se assim. — Parece que ser santificada no ventre materno foi, depois de Cristo,
próprio à Santa Virgem.

1. — Pois, corno se disse, a Santa Virgem foi santificada no ventre materno para tornar-se, assim, idônea
a ser Mãe de Deus. Ora, isto lhe foi próprio a ela. Logo, só ela foi santificada no ventre materno.

2. Demais. — Certos foram mais próximos de Cristo, que Jeremias e João Batista, dos quais refere a
Escritura, que foram santificados no ventre materno. Pois, Cristo é especialmente chamado filho de Davi
e de Abraão, por causa da promessa a eles especialmente feita, a respeito de Cristo. E também Isaías
mui expressamente profetou sobre Cristo. Os Apóstolos, por seu lado, conviveram com o próprio Cristo.
E contudo de nenhum desses se lê que fosse santificado no ventre materno. Logo, nem Jeremias nem
João Batista poderiam tê-lo sido.

3. Demais. — Jó diz de si: Desde a minha infância cresceu comigo a comiseração, e do ventre de minha
mãe saía comigo. Nem por isso, contudo, dizemos que foi santificado no ventre materno. Logo, também
não somos forçados a admitir que João Batista e Jeremias foram santificados no ventre materno.
Mas, em contrário, diz a Escritura, de Jeremias: Antes que eu te formasse no ventre de tua mãe, te
santifiquei. E, de João Batista: Já desde o ventre de sua mãe será cheio do Espírito Santo.

SOLUÇÃO. — Agostinho manifesta alguma dúvida quanto à santificação das duas referidas personagens,
no ventre materno. Pois, diz, o saltor de João no ventre materno podia significar que esse tão grande
acontecimento, a saber, que a mulher seria a Mãe de Deus, deveria ser conhecido pelos pais da criança
concebida, e não por ela. Por isso, o Evangelho não diz – O menino creu, no ventre, mas — deu saltos.
Ora, saltos nós os vemos darem não só as crianças, mas também os animais. Mas, os de que tratamos
foram insólitos, por terem sido no ventre materno. E assim, como soem se fazerem os milagres, esses
saltos o menino os deu por ação divina e não por suas próprias e humanas forças. Embora também
pudéssemos admitir que, nesse menino, o uso da razão e da vontade foi de tal modo precoce que, ainda
nas vísceras maternas, já pudesse conhecer, crer, consentir, o que só em idade mais avançada o podem
as outras crianças; e isso penso dever ser atribuído a milagre do poder divino.
Mas, como o Evangelho diz expressamente de João, que já desde o ventre de sua mãe será cheio do
Espírito Santo; e também expressamente, de Jeremias: Antes que eu te formasse no ventre de tua mãe
te santifiquei, devemos admitir, que foram santificados no ventre materno, embora não tivessem o uso
do livre arbítrio, que é questão levantada por Agostinho; assim como também as crianças santificadas
pelo batismo não tem desde então o uso do livre arbítrio. Nem devemos crer que quaisquer outros
fossem santificados no ventre materno, dos quais nenhuma menção faz a Escritura; pois, tais privilégios
da graça, conferidos a certos fora da lei geral, ordenam-se ao privilégio dos outros, segundo o Apóstolo:
A cada um é dada a manifestação do Espírito para proveito. Ora, essa utilidade seria nula se a Igreja não
soubesse quem fosse santificado no ventre materno. E embora não possamos par razão dos juízos de
Deus e porque foi esse dom da graça conferido a um, de preferência a outro, foi contudo conveniente
que João Batista e Jeremias fossem santificados no ventre materno, para prefigurarem a santificação
que havia de ser operada por Cristo. Primeiro, pela sua paixão, conforme aquilo do Apóstolo: Também
Jesus, para que santificasse ao povo pelo seu sangue, padeceu fora da porta. Cuja paixão, Jeremias mui
claramente anunciou, com palavras e com mistérios, e pelos seus sofrimentos muito expressamente
prefigurou. Segundo, pelo batismo, como o diz o Apóstolo: Mas haveis sido lavados, mas haveis sido
santificados. Para cujo batismo João preparou os homens, pelo seu batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Santa Virgem, escolhida por Deus como mãe, recebeu
mais ampla graça de santificação que João Batista e Jeremias, que foram eleitos com especiais
prefigurantes da santificação de Cristo. E a prova é que à Santa Virgem foi concedido que, no futuro, não
pecasse, nem mortal nem venialmente; ao passo que aos outros santificados cremos lhes foi concedido
que, no futuro não pecassem, por proteção da graça divina.

RESPOSTA À SEGUNDA. — Por outros lados podiam os santos estar mais unidos a Cristo, que Jeremias e
João Batista; os quais, contudo mais unidos estavam com ele, como figuras expressivas que eram, da
santificação dele, como se disse.

RESPOSTA À TERCEIRA. — A comiseração a que se refere Jó não significa a virtude infusa, mas uma
certa inclinação natural para o ato.