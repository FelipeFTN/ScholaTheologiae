# Questão 12: Da ciência adquirida da alma de Cristo
Em seguida devemos tratar da ciência adquirida ou experimental da alma de Cristo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se mediante essa ciência Cristo sabia tudo.
O primeiro discute-se assim. — Parece que mediante essa ciência Cristo não sabia tudo.

1. — Pois, tal ciência se adquire por experiênria. Ora, Cristo não tinha experiência de tudo. Logo, não
sabia tudo mediante essa ciência.

2. Demais. — O homem adquire a ciência pelos sentidos. Ora, nem todos os sensíveis estavam ao
alcance dos sentidos do corpo de Cristo. Logo, por essa ciência não sabia tudo.

3. Demais. — A extensão da ciência depende dos objetos cognoscíveis. Se, pois, por essa ciência, Cristo
soubesse tudo, teria ele uma ciência adquirida igual à ciência infusa e à dos bem-aventurados, o que é
inadmissível. Logo, por essa ciência Cristo não sabia tudo.
Mas, em contrário, nada de imperfeito havia na alma de Cristo. Ora, essa sua ciência teria sido
imperfeita se, mediante ela, não soubesse tudo, pois, é imperfeito o a que pode fazer-se uma adição.
Logo, por essa ciência Cristo sabia tudo.

SOLUÇÃO. — Atribuímos à alma de Cristo a ciência adquirida, como dissemos, por conveniência com o
intelecto agente, para que não fosse inútil a sua atividade, a esse intelecto que atualiza os inteligíveis;
assim como atribuímos a ciência inata ou infusa à alma de Cristo, para complemento do intelecto
possível. Ora, assim como o intelecto possível pode tornar-se todas as causas, assim o intelecto agente
pode fazer todas as causas, segundo o diz Aristóteles. Logo, assim como pela ciência infusa a alma de
Cristo sabia tudo aquilo em relação ao que o intelecto possível é de certo modo potencial; assim, pela
ciência adquirida, sabia tudo o que pode ser sabido pela ação do intelecto agente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ciência das coisas pode ser adquirida não só pela
experiência delas mas ainda pela de certas outras. Pois, em virtude do lume do intelecto agente, pode o
homem chegar a inteligir os efeitos pelas causas e as causas pelos efeitos, e os semelhantes pelos
semelhantes, e os contrários pelos contrários. Por onde, embora a alma de Cristo não tivesse a
experiência de tudo, entretanto, pelo que conhecia por experiência, chegava ao conhecimento de tudo
o mais.

RESPOSTA À SEGUNDA. — Embora todos os sensíveis não estivessem ao alcance dos sentidos corpóreos
de Cristo, estavam-lhe porém ao alcance dos sentidos determinados sensíveis, pelos quais mediante
excelentíssima virtude da sua razão, podia chegar a outros conhecimentos, do modo referido. Assim,
vendo os corpos celestes, podia compreender-lhes as virtudes e os efeitos que exercem sobre os seres
terrestres, que não lhe estivessem ao alcance dos sentidos. E pela mesma razão, mediante certas outras
coisas, podia chegar a conhecimento mais extenso.

RESPOSTA À TERCEIRA. — Para referida ciência, a alma de Cristo não conhecia todas as coisas,
absolutamente falando; mas todas as que são cognoscíveis ao homem pelo lume do intelecto agente. E
assim, mediante essa ciência não tinha conhecimento: das substâncias separadas, nem também dos
acontecimentos particulares passados e futuros. Os quais, porém, conhecia pela ciência infusa, como
dissemos.

## Art. 2 — Se Cristo progredia nessa ciência.
O segundo discute-se assim. Parece que Cristo não progredia nessa ciência.
1 — Pois, assim como pela ciência habitual ou pela ciência infusa, Deus conhecia todas as coisas, assim
também por essa ciência adquirida, como do sobredito resulta. Ora, naquelas ciências não progredia.
Logo, nem nesta.

2. Demais. — Progredir implica imperfeição, porque o perfeito não é susceptível de adição. Ora, não
podemos atribuir a Cristo uma ciência imperfeita. Logo, Cristo não progredia na referida ciência.

3. Demais. — Damasceno diz: Os que dizem ter Cristo progredido em sabedoria e em graça como
acréscimos que assim recebia; não veneram a união. Ora, é ímpio não venerar a união. Logo, ímpio
também o é dizer que a sua ciência era susceptível de acréscimo.
Mas, em contrário, o Evangelho diz, que Jesus crescia em sabedoria e em idade e em graça diante de
Deus e dos homens. E, Ambrósio acrescenta, que progredia na sabedoria humana. Ora, a sabedoria
humana é a adquirida de modo humano, isto é, pelo lume do intelecto agente. Logo, Cristo progredia na
referida ciência.

SOLUÇÃO. — Duplo é o progresso na ciência. Um, segundo a essência: enquanto o mesmo hábito da
ciência aumenta. O outro, quanto ao efeito, por exemplo, quando alguém, pelo mesmo igual hábito da
ciência, demonstra aos outros, primeiro, verdades menores, e depois, maiores e mais subtis. Ora, deste
segundo modo, é manifesto que Cristo progredia em ciência e em graça, como em idade; pois, conforme
crescia em idade, fazia maiores obras, reveladoras de maior ciência e graça.
Mas, quanto ao hábito mesmo da ciência, é manifesto que o hábito da ciência infusa nele não
aumentou; pois, toda a sua ciência infusa ele a teve plenariamente desde o principio. E muito menos
podia aumentar-lhe a ciência da visão beatífica. Quanto à ciência divina, que não pode aumentar, já
tratamos na Primeira Parte. Se, pois, além do hábito da ciência infusa, não há na alma de Cristo outro
hábito — o da ciência adquirida, como certos pensam e como a mim também me parecia, nenhuma
ciência, na sua essência, aumentou, em Cristo, mas só por experiência, isto é, pela aplicação das
espécies inteligíveis infusas aos fantasmas. E, assim sendo, dizem que a ciência de Cristo aumentou
quanto à experiência; isto é, aplicando as espécies inteligíveis infusas aos novos conhecimentos que
pelos sentidos adquiria. Mas, sendo inadmissível que qualquer ato natural inteligível faltasse a Cristo
pois que tirar as espécies inteligíveis, dos fantasmas é um ato natural do intelecto agente do homem -
devemos atribuir também tal ato a Cristo. Donde resulta, que a alma de Cristo tinha um certo hábito da
ciência, susceptível de aumento, mediante essa abstração, das espécies; isto é, por poder o intelecto
agente, depois de ter abstraído, dos fantasmas, as primeiras espécies inteligíveis, abstrair ainda outras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tanto a ciência infusa da alma de Cristo, como a da visão
beatifica, era efeito de uma virtude agente infinita, que pode obrar simultânea e totalmente; e assim,
em nenhuma dessas ciências Cristo progrediu; mas as tinha perfeitas desde o princípio. Ora, a ciência
adquirida é causada pelo intelecto agente, cuja ação não é simultânea e total, mas sucessiva. Por onde,
mediante essa ciência, Cristo não sabia tudo, desde o princípio, mas paulatinamente e depois de um
certo tempo, isto é, na sua idade perfeita; o que se conclui de dizer o Evangelista, que ele
simultaneamente progredia em ciência e em idade.

RESPOSTA À SEGUNDA. — A referida ciência em Cristo também sempre foi perfeita no tempo, embora
não a tivesse sempre sido, absolutamente falando e por natureza. Logo, era susceptível de aumento.

RESPOSTA À TERCEIRA. — As palavras de Damasceno se entendem daqueles que dizem que a ciência de
Cristo recebeu acréscimos absolutamente falando, isto é, relativamente a qualquer ciência sua; e
sobretudo, à infusa, causada na alma de Cristo pela união com o Verbo. Mas, não se estende do
aumento da ciência causada por um agente natural.

## Art. 3 — Se Cristo aprendia dos homens.
O terceiro discute-se assim. — Parece que Cristo aprendia dos homens.
1 — Pois, diz o Evangelho que o encontravam no templo, no meio dos Doutores, respondendo-lhes e
fazendo-lhes perguntas. Ora, perguntar e responder é próprio de quem aprende. Logo, Cristo aprendia
dos homens.

2. Demais. — Adquirir a ciência de um mestre é mais nobre que adquiri-la pelos sentidos; porque a alma
do docente tem as espécies inteligíveis em ato, ao passo que nas coisas sensíveis elas só estão em
potência. Ora, Cristo hauria a ciência experimental nas coisas sensíveis; como se disse. Logo, com muito
maior razão, podia adquirir a ciência, aprendendo-a dos homens.

3. Demais. — Cristo não sabia tudo, desde o princípio, por uma ciência experimental, mas progredia
nela, como se disse. Ora, quem quer que ouça uma palavra significativa, de outrem, pode aprender o
que não sabe. Logo, Cristo podia aprender certas causas, dos homens, que por essa ciência não sabia.
Mas, em contrário, a Escritura: Eis aí o dei por testemunha aos povos, por capitão e por mestre às
gentes. Ora, não é próprio do mestre ser ensinado, mas, ensinar. Logo, Cristo não recebeu, pela
doutrina, nenhuma ciência, de ninguém.

SOLUÇÃO. — Em qualquer gênero, o primeiro motor não é movido por aquela forma de movimento;
assim, o princípio primeiro de uma alteração não é alterado. Ora, Cristo foi constituído cabeça da Igreja,
ou melhor, de todos os homens, como se disse, de modo que não somente todos recebessem dele a
graça, mas ainda, que todos haurissem nele a dourina da verdade. Por isso, ele próprio diz: Eu para isso
nasci e ao que vim ao mundo foi para dar testemunho da verdade. Por onde, não lhe era conveniente à
dignidade que fosse ensinado por qualquer homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Orígenes, o Senhor interrogava, não para
aprender mas para ensinar o interrogando. Pois, é de uma mesma fonte de doutrina que emana o
interrogar e o responder com sabedoria. Por isso, no mesmo lugar o Evangelho acrescenta, que todos os
que o ouviram estavam pasmados da sua inteligência e das suas respostas.

RESPOSTA À SEGUNDA. — Quem aprende de outrem, não recebe imediatamente a ciência, das
espécies inteligíveis, que estão na mente do que ensina, mas, mediante as palavras sensíveis, como
sinais das concepções inteligíveis: Ora, como as palavras pronunciadas são os sinais da ciência
intelectual de quem as pronuncia, assim as criaturas feitas por Deus são sinais da sua sabedoria. Donde
o dizer a Escritura: Ele difundiu a sabedoria por todas as suas obras. Ora, como é mais digno ser
ensinado por Deus que pelos homens, assim é mais digno receber a ciência mediante as criaturas
sensíveis que mediante o ensino humano.

RESPOSTA À TERCEIRA. — Jesus progredia na ciência experimental, como também em idade, segundo
se disse. Ora, assim como é necessária uma idade oportuna para o homem adquirir a ciência por
invenção, assim também o é para a adquirir pela aprendizagem. Ora, o Senhor nada fazia que não lhe
conviesse à idade. Logo, não se pôs a ouvir as palavras do ensino senão no tempo em que podia,
também por via da experiência, atingir ao grau dessa ciência. Donde o dizer Gregório: No duodécimo
ano da sua idade dignou-se interrogar os homens na terra, pois, conforme o desenvolvimento da razão,
o ensino não é próprio senão à idade perfeita.

## Art. 4 — Se Cristo recebeu alguma ciência dos anjos.
O quarto, discute-se assim. - Parece que Cristo recebeu alguma ciência, dos anjos.

1. — Pois, diz o Evangelho, que apareceu a Cristo um anjo do céu, que o confortava. Ora, confortar
supõe palavras de ensino, segundo aquilo da Escritura: Eis aqui ensinaste a muitos e deste vigor a mãos
cansadas; as tuas palavras firmaram aos que vacilavam. Logo, Cristo foi ensinado pelos anjos.

2. Demais. — Dionísio diz: Pois, eu vejo que o próprio Jesus, substância supersubstancial das substâncias
super-celestes, assumindo a nossa natureza sem alterar a sua, obedece com humilde submissão à
instruções que Deus, seu Pai, lhe transmite por meio dos anjos. Donde se conclui que o próprio Cristo
quis submeter-se à ordem da lei divina, que manda os homens serem ensinados pelos anjos.

3. Demais. — Assim como o corpo humano, por uma ordem natural, está sujeito aos corpos celestes,
assim também a inteligência humana às angelicas. Ora, o corpo de Cristo estava sujeito às impressões
dos corpos celestes; assim, sofria o calor do verão, o frio do inverno como tudo o mais que o homem
padece. Logo, também a sua inteligência recebia as iluminações dos espíritos super-celestes.
Mas, em contrário, diz Dionísio, que os anjos supremos fazem, eles, interrogações a Jesus conhecendo
dele a sua obra divina e a assunção da nossa carne, por amor de nós; e Jesus os ensina sem, medianeiro.
Ora, não pode um mesmo sujeito ensinar e ser ensinado. Logo, Cristo nada aprendeu dos anjos.

SOLUÇÃO. — Assim como a alma humana é um meio termo entre as substâncias espirituais e os seres
corpóreos, assim de dois modos lhe é natural o aperfeiçoar-se: pela ciência haurida nas coisas sensíveis
e pela ciência infusa ou impressa pela iluminação das substâncias espirituais. Ora, de ambos esses
modos a alma de Cristo era perfeita. Quanto aos sensíveis, pela ciência experimental, para adquirir a
qual não é necessário a iluminação angélica, pois, basta o lume do intelecto agente; quanto à impressão
superior, pela ciência infusa, que imediatamente recebia de Deus. Pois, assim como a alma de Cristo
estava unida, de um modo superior ao que é comum à criatura, ao Verbo na unidade da pessoa, assim
também, de um modo superior ao que é comum aos homens, a sua alma abundava na ciência e na graça
recebidas imediatamente do próprio Verbo de Deus; não, pois mediante os anjos, que também, pela
influência do Verbo, receberam, quando começaram a existir, a ciência das coisas como diz Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O confortar do anjo, que refere a Escritura, não foi a
modo de instrução, mas, para mostrar a propriedade da natureza humana. Donde o dizer Beda: Foi para
nos mostrar a propriedade das duas naturezas, da humana e da divina, que os anjos vieram confortá-lo
e servi-lo, Pois, o Criador não precisava do socorro da sua criatura; mas, Cristo feito homem assim como
quis se entristecer por nós, assim, por causa nossa, quis ser consolado. De modo que em nós se
confirmasse a fé na sua Encarnação.

RESPOSTA À SEGUNDA. — Dionísio diz, que Cristo foi submetido à iluminação dos anjos, não que por
natureza delas precisasse, mas por ocasião das diversas circunstâncias da sua Encarnação, e da fraqueza
de que se revestiu, fazendo-se criança, por amor de nós. Por isso, no mesmo lugar acrescenta que, por
meio dos anjos o Pai anunciou a José que foi determinado a partida de Jesus para o Egito, e de novo,
que devia reconduzir o menino do Egito para a Judéia.

RESPOSTA À TERCEIRA. — O Filho de Deus assumiu um corpo passível, como diremos depois; mas uma
alma com ciência e graça perfeitas. Por isso e convenientemente, o seu corpo foi sujeito a impressão
dos corpos ce1estes; mas a sua alma não o foi à dos espíritos celestes.