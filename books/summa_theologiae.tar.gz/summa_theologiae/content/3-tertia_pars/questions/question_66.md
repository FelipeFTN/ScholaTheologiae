# Questão 66: Do concernente ao sacramento do batismo.
Na primeira questão discutem-se doze artigos:

## Art. 1 — Se o batismo é uma ablução.
O primeiro discute-se assim. — Parece que o batismo não é uma ablução.

1. Pois, a ablução material passa, ao passo que o batismo permanece. Logo, o batismo não é a ablução
mesma, mas antes, a regeneração e o selo, a custódia e a iluminação, como diz Damasceno.

2. Demais. — Hugo de S. Vitor diz que o batismo é a água santificada pelo Verbo de Deus para lavar os
pecados. Ora, a água não é a ablução mesma; mas a ablução é um dos usos da água.

3. Demais. — Agostinho diz: Acrescenta-se as palavras ao elemento e nasce o sacramento. Ora, o
elemento é a própria água. Logo, o batismo é a água mesma e não a ablução.
Mas, em contrário, a Escritura: Se alguém se lava depois de ter tocado um morto e o toca outra vez, de
que lhe serve o ter-se lavado? Logo, parece que o batismo é ablução mesma ou o ato de lavar.

SOLUÇÃO. — Três coisas devemos considerar no sacramento do batismo: uma é o sacramento só em si
mesmo; outra, a realidade e o sacramento; a terceira, só a realidade. O sacramento tem uma existência
externamente visível a qual é o sinal do efeito interior; e isso constitui a essência do sacramento. Ora, o
elemento exterior percebido pelos sentidos é a água e o seu uso, a ablução. Certos porem pensaram
que a água mesma fosse o sacramento; e é o que parece soarem as palavras de Hugo de S. Vitor. Pois,
na sua definição geral dos sacramentos, diz que é um elemento material; e, na definição do batismo, diz
que é a água. Mas esta doutrina não é verdadeira. Porque os sacramentos da lei nova, obrando de certo
modo a santificação, onde se perfaz o sacramento também se perfaz a santificação. Ora, a água não é
causa da santificação, senão como causa instrumental, não permanente, mas que de flui para o homem,
que é o sujeito da verdadeira santificação. Por onde, o sacramento não se perfaz na água, em si mesma,
mas na sua aplicação ao homem, que é a ablução. Donde o dizer o Mestre das Sentenças que o batismo
é a ablução exterior do corpo, feita sob a forma das palavras prescritas. — Quanto à realidade e ao
sacramento, é o caráter batismal, que é a realidade significa da pela ablução exterior; e é o sinal
sacramental da justificação interior. E esta é em si a realidade deste sacramento, isto é, significa da e
não significante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O caráter, que é ao mesmo tempo realidade e
sacramento; e a justificação interior, que é a realidade somente, permanecem. Mas o caráter
permanece de modo indelével, como dissemos; ao passo que a justificação também permanece, mas
pode ser perdida. Por isso Damasceno definiu o batismo, não pelo que exteriormente se manifesta que
é o sacramento, por si mesmo; mas, pelo que é interior. Dai o ter atribuído ao caráter duas
denominações — a de selo, e de custódia; porque o caráter, considerado selo, guarda, como tal, a alma
no bem. E ainda, atribuiu duas denominações à realidade última do sacramento: a de regeneração, pelo
fato de o batismo fazer-nos começar a vida nova da justiça; e a de iluminação, concernente em especial
à fé, pela qual recebemos a vida espiritual segundo aquilo da Escritura: O justo viverá na sua fé. Ora, o
batismo é de certo modo uma proclamação da fé; por isso se chama o sacramento da fé. — E
semelhantemente, Dionísio definiu o batismo relativamente aos outros sacramentos, dizendo: É de
algum modo o princípio dessas instituições sagradas da vida cristã, e dá à nossa alma disposições que a
tornam capaz de os receber. E ainda, relativamente à glória celeste, que é o fim último dos sacramentos,
quando acrescenta: O batismo abre o caminho que nos conduz ao repouso do céu. E enfim, quanto ao
princípio da vida espiritual, quando acrescenta: É a transmissão da nossa sagrada e diviníssima
regeneração.

RESPOSTA À SEGUNDA. — Como dissemos, não devemos seguir neste ponto a opinião de Hugo de S.
Vitor. – Podemos, contudo aceitar que o batismo se denomine água, porque a água é o seu princípio
material. É um caso da denominação fundada na causa.

RESPOSTA À TERCEIRA. — Acrescentada a palavra ao elemento, nasce o sacramento, não no próprio
elemento, mas no homem, que o recebe pela ablução. E isso mesmo significam as palavras que se
pronunciam nessa ocasião. / Eu te batizo, etc.

## Art. 2 — Se o batismo foi instituído depois da paixão de Cristo.
O segundo discute-se assim. — Parece que o batismo foi instituído depois da paixão de Cristo.
1 — Pois a causa precede o efeito. Ora, a paixão de Cristo, é a que obra nos sacramentos da lei nova.
Logo, a paixão de Cristo precede à instituição dos sacramentos da lei nova; e sobretudo à instituição do
batismo. Por isso, o Apóstolo diz: Todos os que fomos batizados em Jesus Cristo fomos batizados na sua
morte, etc.
2 — Demais — Os sacramentos da lei nova tiram a sua eficácia do mandamento de Cristo. Ora, Cristo
deu aos discípulos o poder de batizar depois da sua paixão e ressurreição, dizendo: Ide e ensinai a todas
as gentes, batizando-as em nome do Padre, etc. Logo, parece que o batismo foi instituído depois da
paixão de Cristo.

3. — Demais. — O batismo é um sacramento de necessidade para a salvação, como se disse. Donde se
conclui que, desde que o batismo foi instituído, os homens estavam obrigados a ele. Ora, não o
estavam, antes da paixão de Cristo, porque ainda então vigorava a circuncisão, que o batismo veio
substituir. Logo, parece que o batismo não foi instituído antes da paixão de Cristo.
Mas, em contrário, diz Agostinho: Desde que Cristo foi imerso na água, desde então lavou com a água o
pecado de todos. Ora, tal se deu antes da paixão de Cristo. Logo, o batismo foi instituído antes da paixão
de Cristo.

SOLUÇÃO. — Como dissemos, os sacramentos, pela sua instituição, têm o poder de conferir a graça. Por
onde, conclui-se que um sacramento foi instituído, quando recebeu o poder de produzir o seu efeito.
Ora essa virtude o batismo a teve quando Cristo foi batizado. Logo, então o batismo foi
verdadeiramente instituído como sacramento. Mas, a necessidade de usar desse sacramento foi
imposta aos homens depois da paixão e da ressurreição. Quer porque com a paixão de Cristo
extinguiram-se os sacramentos figurados, a que sucedeu o batismo e os outros sacramentos da lei nova.
Quer também porque o batismo nos configura com a paixão e a ressurreição de Cristo, porque
morremos assim ao pecado e começamos a vida nova da justiça. Por onde, era forçoso que Cristo
primeiro sofresse e ressurgisse, para depois impor-nos a necessidade de nos configurarmos com a sua
morte e ressurreição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Mesmo antes da paixão de Cristo o batismo tirava a sua
eficácia da paixão de Cristo, pela prefigurar. Mas diferentemente dos sacramentos da lei antiga. Pois,
aqueles eram apenas figuras; ao passo que o batismo hauria no próprio Cristo o poder de justificar, por
cuja virtude também foi salvadora a sua paixão.

RESPOSTA À SEGUNDA. — Não convinha que Cristo, que veio com a sua verdade abolir os símbolos
antigos, realizando-os, nos fizesse prisioneiros de símbolos mais numerosos. Por isso, antes da sua
paixão, não pôs como preceito o batismo já instituído, mas quis acostumar os homens a praticá-lo; e
sobretudo O povo judeu cujos atos religiosos eram figurados, como diz Agostinho. Mas depois da paixão
e da ressurreição, não só aos judeus mas também aos gentios impôs-lhes o batismo sob preceito de
necessidade, dizendo: Ide e ensinai a todas as gentes.

RESPOSTA À TERCEIRA. — Os sacramentos não são obrigatórios senão quando ordenados sob preceito.
O que não se dava antes da paixão, como se disse. E quanto a ter o senhor dito, antes da paixão, a
Nicodemos – Quem não renascer da água e do Espírito Santo não pode entrar no reino de Deus – refere-
se antes ao futuro que ao tempo presente.

## Art. 3 — Se a água é a matéria própria do batismo.
O terceiro discute-se assim. — Parece que a água não é a matéria própria do batismo.

1. — Pois, o batismo, segundo Dionísio e Damasceno, tem uma virtude iluminativa. Ora, a iluminação é
sobretudo própria do fogo. Logo, o batismo devia ser feito antes em fogo que em água, sobretudo que
João Batista, prenunciando o batismo de Cristo, disse: Ela vos batizará no Espírito Santo e em jogo.

2. — Demais. — O batismo significa a ablução dos pecados. Ora, muitos líquidos, além da água, como o
vinho, o óleo e outros, podem lavar Logo, também podiam ser a matéria do batismo. Logo, não é a água
a matéria própria do batismo.

3. — Demais. — Os sacramentos da Igreja manaram do lado de Cristo pendente da cruz, como se disse.
Ora, dele manou não só a água, mas também o sangue. Logo, parece que também se pode batizar com
sangue, o que parece convir mais com a causa e o efeito do batismo, 5egundo aquilo: Lavou-nos dos
nossos pecados no seu sangue.

4. — Demais. — Como diz Agostinho e Beda, Cristo, pelo contacto da sua puríssima carne, conferiu à
água a virtude regenerativa e purificadora. Ora, nem toda água comunica com a do Jordão que Cristo
tocou com o seu corpo. Logo, parece que nem com toda água pode-se batizar. E, portanto a água, como
tal, não é a matéria própria do batismo.

5. — Demais. — Se a água, como tal fosse a matéria própria do batismo, não seria necessário sujeitá-la a
nenhum preparativo, para que com ela se pudesse batizar. Ora, no batismo solene a água com que vai
ser celebrado, é exorcizada e benta. Logo, parece que a água como tal não é a matéria própria do
batismo.
Mas, em contrário, o Senhor diz: Quem não renascer da água e do Espírito Santo não pode entrar no
reino de Deus.

SOLUÇÃO. — Por instituição divina a água é a matéria própria do batismo. E com conveniência. —
Primeiro, pela natureza mesma do batismo, que é a regeneração para a vida espiritual, o que convém
por excelência à água. Por isso as sementes, de que se geram todos os seres vivos, plantas e animais —
são úmidas e contêm água. Razão pela qual certos.— filósofos disseram ser ela o princípio de todas as
coisas. Segundo, pelos efeitos do batismo, a que convêm as propriedades da água. A qual lava, com a
sua humildade; por isso é própria a significar e a causar a ablução dos pecados. Pela sua frescura
também faz diminuir o excesso do calor; por isso serve para mitigar os ardores da concupiscência. Pela
sua diafaneidade é susceptiva da luz; daí o ser acomodada ao batismo enquanto sacramento da fé. —
Terceiro, porque é própria para representar os mistérios de Cristo, pelos quais somos justificados. Pois,
diz Crisóstomo, aquilo do Evangelho — Quem não renascer: Como num sepulcro, o homem velho fica
sepulto na água, quando a pessoa batizada é submersa até a cabeça; e, submerso, fica no fundo, para
dar lugar ao homem novo que emerge. — Quarto, porque, em razão da sua comunidade e abundância,
é a matéria conveniente da necessidade deste sacramento; pois, pode ser obtida em toda parte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A iluminação é uma atividade do fogo. Ora, o batizado
não ilumina, mas é iluminado pela fé, que é pelo ouvido, na frase do Apóstolo. Por isso mais apropriada
ao batismo é a água que o fogo. — Quanto ao dito: Ele vos batizará no Espírito Santo e em fogo —
podemos entender pelo fogo como diz Jerônimo, o Espírito Santo, que desceu sobre os discípulos em
forma de línguas ígneas, como o narra a Escritura. — Ou pelo fogo podemos entender a tribulação,
como diz Crisóstomo; porque a tribulação purifica dos pecados e diminui a concupiscência. — Ou
porque, como diz Hilário, aos que foram batizados no Espírito Santo resta ainda o serem purificados
pelo fogo do juízo.

RESPOSTA À SEGUNDA. — O vinho e o óleo não são comumente usados para a ablução, como a água.
Além disso, não lavam tão perfeitamente, porque sempre deixam, depois da lavagem, mau odor, o que
se não dá com a água. Enfim não são obtidos tão geral e abundantemente como a água.

RESPOSTA À TERCEIRA. — Do lado de Cristo manou a água para lavar, e o sangue para remir. Por isso, o
sangue é apropriado ao sacramento da Eucaristia; a água, ao do batismo; a qual porém tira o seu poder
de lavar, da virtude do sangue de Cristo.

RESPOSTA À QUARTA. — A virtude de Cristo derivou para todas as águas, não por causa da
comunicação local delas com o Jordão, mas pela comunidade específica. Donde o dizer Agostinho: A
bênção manada do batismo do Salvador, como se fosse um rio espiritual, encheu o leito de todos os rios
e as profundezas de todas as fontes.

RESPOSTA À QUINTA. — A bênção lançada sobre a água não é de necessidade para o batismo; mas
constitui uma certa solenidade, que desperta a devoção dos fiéis e neutraliza a astúcia do demônio para
impedir o efeito do batismo.

## Art. 4 — Se para o batismo é necessária água pura.
O quarto discute-se assim. — Parece que para o batismo não é necessária água pura.

1. — Pois, a água ordinária não é pura; como sobretudo o mostra a água do mar, que vai de mistura com
detritos de terra, conforme o ensina o Filósofo. E contudo com tal água se pode ministrar o batismo.
Logo, não é necessária a água simples e pura para o batismo.

2. Demais. — Na celebração solene do batismo o crisma é infuso na água. Ora, perde assim a água a sua
pureza e simplicidade. Logo, não é necessária água pura e simples no batismo.

3. Demais. — A água que manou do lado de Cristo pendente da cruz era significativa do batismo, como
se disse. Ora, parece que essa água não era pura, porque num corpo misto, como era o de Cristo, os
elementos não existem na sua pureza. Logo, parece que não é necessária água pura ou simples para o
batismo.

4. Demais. — A água de lixívia não é pura, pois têm as propriedades contrárias às da água — a de
aquecer e secar. E contudo com a água de lixívia pode-se batizar; assim como as águas balneares, que
correm por terrenos sulfúreos, como as de lixívia, através das cinzas. Logo, parece que não é necessária
a água pura para o batismo.

5. Demais. — A água de rosas se obtém pela condensação delas, assim as águas alquímicas são
produzidas pela sublimação de certos corpos. Ora, com essas águas, segundo parece, pode-se
administrar o batismo, assim como com as águas pluviais, geradas pela condensação dos vapores. Ora,
não sendo essas águas puras e simples, parece que não é necessária água pura e simples para o
batismo.
Mas, em contrário, a matéria própria do batismo é a água, como se disse. Ora, só a água pura é
especificamente água. Logo, a água pura e simples é de necessidade para o batismo.

SOLUÇÃO. — A água pode perder a sua pureza e simplicidade de dois modos: pela mistura com outro
corpo e por alteração. O que pode dar-se de duas maneiras: pela arte e pela natureza. A arte é menos
poderosa que a natureza, pois esta dá a forma substancial, e aquela não na pode dar. Porque, todas as
formas artificiais são acidentais, salvo se a arte puser em presença um agente apropriado e a matéria
correspondente, como o fogo e o combustível. Assim de determinadas matérias em putrescência
nascem certos animais.
Por onde, todas as transmutações feitas na água pela arte, quer misturando, quer alterando, não lhe
mudam a espécie. Portanto, com tal água pode-se ministrar o batismo; salvo talvez se a água for
misturada pela arte em tão pequena quantidade com um determinado corpo, que o composto seja
antes da natureza deste que dela. Assim, o lodo é mais terra que água; e o vinho aguado é mais vinho
que água.
As transmutações porem feitas pela natureza às vezes fazem desaparecer a espécie da água; e isso se dá
quando a natureza faz água da substância de um corpo misto. Assim, quando convertida em suco de uva
é vinho e portanto perde a sua espécie. Outras vezes a natureza a transmuta sem lhe fazer desaparecer
a espécie. E isto tanto por alteração, como no caso da água aquecida pelo sol, como também por
mistura, como quando a água fluvial torna-se turva pela mistura com partes de terra. — Donde
devemos pois, concluir, que com qualquer água, transformada de qualquer maneira, contanto que a sua
espécie não desapareça, pode-se ministrar o batismo, se porém a sua espécie desaparecer, não se pode
ministrar esse sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A transformação feita na água do mar e também nas
outras águas, que nos são comuns, não é tanta que lhe faça desaparecer a espécie. Logo, com tais águas
se pode batizar.

RESPOSTA À SEGUNDA. — A mistura com o crisma não destrói a espécie da água. — Assim como
também a água da decocção das carnes e de matérias semelhantes; salvo se for tão grande a dissolução
dos corpos cozidos nela, que o líquido tenha mais da substância alheia que da água; o que pode ser
deduzido da sua consistência se porém do líquido assim consistente se puder extrair uma água límpida,
pode-se com ela batizar; assim como com a água extraída do lodo, embora com o lodo não se possa
celebrar o batismo.

RESPOSTA À TERCEIRA. — A água emanada do lado de Cristo pendente da cruz não era um humor
linfático, como certos o disseram. Pois com tal humor não se podia celebrar o batismo; como nem com
o sangue animal ou com vinho ou com o líquido extraído de uma planta. Mas foi uma água pura
milagrosamente emanada do corpo morto, assim como o sangue para provar que o corpo do Senhor o
era verdadeiramente, contra o erro dos maniqueus. De modo que pela água, que é um dos quatro
elementos, o corpo de Cristo se mostrasse realmente composto deles quatro; e pelo sangue se
mostrasse composto dos quatro humores.

RESPOSTA À QUARTA. — A água de lixívia e as águas dos banhos sulfurosos podem servir para o
batismo. Porque não são incorporadas pela arte ou pela natureza a quaisquer corpos mistos, mas
sofrem apenas uma alteração por terem atravessado certas substâncias.

RESPOSTA À QUINTA. — A água de rosas é um suco extraído da rosa. Portanto não pode servir para o
batismo. E pela mesma razão as águas alquímicas e o vinho. Mas o mesmo não se dá com as águas
pluviais, produzidas na sua maior parte pela condensação dos vapores nelas resolvidos. Há nelas um
mínimo do líquido dos corpos mistos; que contudo, por essa condensação e por obra da natureza, que é
mais poderosa que a arte, resolvem-se em verdadeira água, o que a arte não é capaz de fazer. Por onde,
a água pluvial não conserva a propriedade de nenhum corpo misto; o que não se pode dizer da água de
rosas e das águas alquímicas.

## Art. 5 — Se esta é a forma conveniente do batismo: Eu te batizo em nome do Padre e do Filho e do Espírito Santo.
O quinto discute-se assim. — Parece que esta não é a forma conveniente do batismo: Eu te batizo em
nome do Padre e do Filho e do Espírito Santo.

1. — Pois, um ato deve ser atribuído antes ao agente principal que ao ministro. Ora, no sacramento o
ministro age a modo instrumental, como se disse. E o agente principal no batismo é Cristo, segundo
aquilo do Evangelho: Aquele sobre que tu vires descer o Espírito e repousar sobre ele, esse é o que
batiza. Logo não deve o ministro dizer — Eu te batizo; sobretudo quando diz — batizo, subtendeu-se —
eu, o que portanto se acrescenta superfluamente.

2. Demais. — Não é necessário que quem pratica um ato faça menção do exercício desse ato; assim, não
é preciso que quem ensina diga — eu vos ensino. Ora, o Senhor deu simultaneamente o preceito de
batizar e de ensinar, dizendo: Ide e ensinai a todas as gentes, etc. Logo, não é necessário que na forma
do batismo se faça menção do ato do batismo.

3. Demais. — O que é batizado às vezes não entende as palavras, por exemplo se for surdo ou criança.
Logo é inútil dirigir-lhes a palavra, segundo a Escritura: Onde não fores ouvidos, não derrames teu
sermão. Portanto, não se deve dizer: Eu te batizo, diretamente falando com o batizado.

4. Demais. — Pode acontecer que muitos sejam os batizados e por muitos; assim os Apóstolos batizaram
num dia três mil e, noutro, cinco mil, como refere à Escritura. Logo, a forma do batismo não deve ser
determinada em o número singular, dizendo-se: Eu te batizo. Mas pode-se dizer: Nós vos batizamos.

5. Demais. — O batismo tira a sua virtude, da paixão de Cristo. Ora, pela forma o batismo santifica. Logo,
parece que na forma do batismo deve-se fazer menção da paixão de Cristo.

6. Demais, — O nome designa as propriedades da coisa. Ora, três são as propriedades pessoais das
divinas Pessoas, como se disse na Primeira Parte. Logo, não se deve dizer — Em nome do Padre e do
Filho e do Espírito Santo — mas nos nomes.

7. Demais. — A pessoa do Pai é significada não só pelo nome de Padre, mas também pelo de lnascível e
Genitor; o Filho, também pelo de Verbo, Imagem e Génito; e o Espírito Santo também pelo de Dom e de
Amor precedente. Logo, parece que quem usar também desses nomes celebra o batismo.
Mas, em contrário, o Senhor diz: Ide e ensinai a todas as gentes, batizando-as em nome do Padre e do
Filho e do Espírito Santo.

SOLUÇÃO. — O batismo é consagrado pela sua forma, segundo aquilo do Apóstolo: Para a santificar,
purificando-a no batismo da água pela palavra da vida. E Agostinho diz que o batismo é consagrado
pelas palavras evangélicas. Logo, a forma do batismo há de necessàriamente exprimir-lhe a causa. Ora, a
sua causa é dupla. A principal e de que tira a sua virtude é a santa Trindade. A instrumental é o ministro
que celebra exteriormente o sacramento. Por onde, é necessário na forma do batismo fazer menção de
uma e de outra. Assim, a sua parte o ministro a exerce quando diz — Eu te batizo. E a causa principal a
sua, quando ele pronuncia — em nome do Padre e do Filho e do Espírito Santo. Por isso é essa a forma
conveniente do batismo: Eu te batizo em nome do Padre e do Filho e do Espírito Santo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ação é atribuída ao instrumento como ao agente
imediato; mas, ao agente principal como o em virtude do qual o instrumento age. Por onde, na forma
do batismo o ministro é conveniente designado como o que exerce o ato de batizar quando diz: Eu te
batizo. Assim o próprio Senhor atribuiu aos ministros esse ato quando disse: Batizando-os, etc. Quanto à
causa principal, ela é designada como a em virtude da qual o sacramento é ministrado, conforme o
significam as palavras — em nome do Padre e do Filho e do Espírito Santo; pois, Cristo não batiza sem o
Padre e o Espírito Santo. — Os gregos porem não atribuem o ato do batismo aos ministros, para evitar o
erro dos antigos, que atribuíam a virtude do batismo aos que batizavam, dizendo: Eu sou de Paulo e eu
de Cefas. E por isso dizem: Seja batizado o servo de Cristo tal em nome do Padre. etc. E como se
exprime o ato exercido pelo ministro com a invocação da Trindade, celebra-se verdadeiramente o
sacramento. — Quanto ao acréscimo — Eu — na forma nossa não pertence à substância dessa forma,
mas é posto para dar maior expressão à intenção.

RESPOSTA À SEGUNDA. — Como podemos fazer ablução com a água para muitos fins, é necessário
determinar com palavras formais, o fim intencionado. E isso não o fazem as palavras pronunciadas —
em nome do Padre e do Filho e do Espírito Santo, pois tudo devemos fazer invocando tais nomes, como
o diz o Apóstolo. Por onde, se não se exprimir o ato do batismo, ao modo nosso ou ao dos gregos, não
fica celebrado o sacramento. E o que dispõe um Decretal de Alexandre III: Quem imergir três vezes uma
criança na água em nome do Padre e do Filho e do Espírito Santo, amém; e não disser — Eu te batizo em
nome do Padre e do Filho e do Espírito Santo, amem — não na terá batizado.

RESPOSTA À TERCEIRA. — As palavras pronunciadas nas formas sacramentais não o são só para
significarem, mas também pela sua eficiência, por tirarem a sua eficácia daquele Verbo por quem todas
as causas foram feitas. Por isso são convenientemente dirigidas não só aos homens, mas também às
criaturas insensíveis, como quando se diz — Eu te exorcizo criatura sal.

RESPOSTA À QUARTA. — Vários não podem batizar uma pessoa ao mesmo tempo, porque os atos se
multiplicam como a multiplicação dos agentes, se cada um agir como deve. E assim, se duas pessoas se
encontrassem, das quais uma não pudesse proferir palavra, por ser muda; e não pudesse a outra, por
não ter mãos, praticar o ato — não poderiam batizar simultaneamente, pronunciando uma as palavras e
praticando o ato a outra. – Podem, contudo, se a necessidade o exigir, vários ser batizados
simultaneamente, porque nenhum deles receberia senão um batismo. Mas então será necessário dizer:
Eu vos batizo. Nem haverá mudança na forma, porque vós não é senão tu e tu. Ao passo que o pronome
nós não é o mesmo que eu e eu, mas que eu e tu; o que causaria mudança.na forma. — Do mesmo
modo, esta se mudaria se se dissesse: Eu me batizo. Portanto, ninguém pode batizar-se a si mesmo. Por
isso Cristo quis ser batizado por João.

RESPOSTA À QUINTA. — A paixão de Cristo, embora seja ·a causa principal em comparação com o
ministro, é contudo causa instrumental em comparação com a santa Trindade. Por isso, é antes
comemorada a Trindade que a paixão de Cristo.

RESPOSTA À SEXTA. — Embora sejam três os nomes pessoais das três Pessoas, o nome essencial,
contudo é um só. Ora, a virtude divina, que obra no batismo, pertence à essência. Por isso se diz — em
nome — e não — nos nomes.

RESPOSTA À SÉTIMA. — Assim como a água é a escolhida para o batismo, porque o seu uso mais
comum é para lavar, assim, para significar as três Pessoas, na forma do batismo, usam-se dos nomes
com que mais comumente se costumam elas designar língua a que eles pertencem. Nem seria válido o
sacramento com outras palavras.

## Art. 6 — Se se pode batizar em nome de Cristo.
O sexto discute-se assim. — Parece que se pode batizar em nome de Cristo.

1. Pois, como não há senão uma fé, assim também não há senão um batismo, no dizer do Apóstolo. Ora,
a Escritura refere que em nome de Cristo íam-se batizando homens e mulheres. Logo, também agora se
pode batizar em nome de Cristo.

2. Demais. — Ambrósio diz: Nomeando Cristo, terás designado o Pai, de quem recebeu a unção; o
próprio Filho, que foi o ungido; e o Espírito Santo, por quem foi ungido. Ora, pode-se batizar em nome
da Trindade. Logo, também em nome de Cristo.

3. Demais. — Nicolau I Papa, respondendo às consultas dos Búlgaros, diz: Os batizados em nome da
Santa Trindade, ou somente em nome de Cristo — como lemos nos Atos dos Apóstolos — não devem
ser rebatizados, porque num como noutro caso o batismo é o mesmo, conforme o diz Santo Ambrósio.
Ora, seriam rebatizados se nessa forma de batismo não tivessem recebido esse sacramento. Logo, pode
ser ministrado o batismo em nome de Cristo, sob a forma — Eu te batizo em nome de Cristo.
Mas, em contrário, Pelágio Papa escreve ao Bispo Gaudêncio: Se os que se diz que moram em lugares
vizinhos da vossa Dilecção, declaram terem sido batizados só em nome do Senhor, sem vacilação de
nenhuma dúvida batizá-los-eis em nome da Santa Trindade, se vierem à fé católica. — E Dídimo também
diz: Se houver quem, por distracção de espírito, batizar e esquecendo um dos referidos nomes — isto é,
das três Pessoas não terá conferido verdadeiro batismo.

SOLUÇÃO. — Como dissemos, os sacramentos haurem a sua eficácia na instituição de Cristo. Portanto, a
emissão de alguma das condições estabelecidas por Cristo para cada sacramento, suprime-lhe a eficácia;
salvo por dispensa especial do próprio Cristo, que não ligou o seu poder a esses ritos. Ora, Cristo
instituiu que o sacramento do batismo fosse ministrado com a invocação da Trindade. Portanto, tudo o
que faltar, para a plena invocação da Trindade, tira ao batismo a sua integridade. — Nem obsta que pelo
nome de uma Pessoa se entenda outra, assim como no nome do Pai se entende o Filho. Ou que quem
nomeia uma só pessoa possa ter fé verdadeira nas três. Pois, assim como o sacramento requere matéria
sensível, assim também forma sensível. Por onde não basta à inteligência ou a fé da Trindade para a
perfeição do sacramento, se a Trindade não for expressa sensivelmente por palavras. Por isso, no
batismo de Cristo, origem da santificação do nosso batismo, esteve presente a Trindade sob sinais
sensíveis, a saber: O Pai, pela voz; o Filho, pela natureza humana; o Espírito Santo, pela pomba.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por uma especial revelação de Cristo, os Apóstolos, na
primitiva Igreja, batizavam em nome dele; a fim de o nome de Cristo, odioso aos judeus e aos gentios, se
tornar estimado por ser, à sua invocação, conferido o Espírito Santo no batismo.

RESPOSTA À SEGUNDA. — Ambrósio dá a razão porque convenientemente essa dispensa podia ser
dada na primitiva Igreja. E é porque pelo nome de Cristo se entende toda a Trindade. E assim se
observava ao menos numa integridade inteligível, a forma que Cristo transmitiu no Evangelho.

RESPOSTA À TERCEIRA. — O Papa Nicolau confirma o seu dito pelas duas autoridades precedentes. E
por isso a resposta se deduz das duas primeiras soluções.

## Art. 7 — Se a imersão na água é necessária no batismo.
O sétimo discute-se assim. — Parece que a imersão na água é necessária no batismo.

1. — Pois, como diz o Apóstolo, não há senão uma fé e um batismo. Ora, para muitos o modo comum de
batizar é pôr imersão. Logo, parece que não pode haver batismo sem imersão.

2. Demais. — O Apóstolo diz: Todos os que fomos batizados em Jesus Cristo fomos batizados na sua
morte: porque nós fomos sepultados com ele para morrer ao pecado pelo batismo. Ora, isso se faz pela
imersão. Assim, àquilo do Evangelho — Quem não renascer da água e do Espírito Santo — diz
Crisóstomo: Como num sepulcro o homem velho fica sepulto na água, quando a pessoa batizada é
submersa até a cabeça; e, submerso, fica no fundo, para dar lugar ao homem novo, que emerge. Logo,
parece que a imersão é necessária no batismo.

3. Demais. — Se sem a imersão total do corpo se pudesse ministrar o batismo, pela mesma razão
bastaria à aspersão de uma quantidade qualquer de água. O que é inconveniente, porque o pecado
original, contra o qual sobretudo é, conferido o batismo, não está numa só parte do corpo. Logo, parece
necessária a imerso no batismo, não bastando só à aspersão.
Mas, em contrário, o Apóstolo: Cheguemo-nos a ele com verdadeiro coração, revestidos de uma
completa fé, tendo os corações purificados de consciência má e lavados os corpos com água limpa.

SOLUÇÃO. — A água é empregada, no sacramento do batismo, para uso da ablução corporal,
significativa da ablução interior dos pecados. Ora, a ablução com a água pode ser feita não só a modo de
imersão, mas também a modo de aspersão ou efusão. Por onde, embora seja mais seguro batizar por
meio de imersão, por ser o uso mais comum, pode-se também batizar por meio da aspersão ou ainda da
efusão, conforme aquilo da Escritura: Derramarei sobre vós uma água pura. E assim se lê que São
Lourenço batizou. E isso sobretudo por necessidade ou quando for muito grande o número dos que
devem ser batizados; assim, ao caso referido pela Escritura de três mil que creram num dia, e cinco mil,
no outro. As vezes também pode ser premente a necessidade pela escassez da água; ou pela pouca
resistência do ministro que não pode sustentar o batizando; ou pela fraqueza deste, que poderia na
imersão correr o perigo de morte. Logo, devemos concluir não ser a imersão necessária no batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Os acidentes não variam a substância da coisa. Ora, o
batismo requer essencialmente a ablução corporal por meio da água. Por isso o Apóstolo chama ao
batismo, batismo de água: Purificando-a no batismo da água pela palavra da vida. Ora, fazer a ablução
de tal ou tal modo é acidental ao batismo. Por isso essa diversidade não lhe tira a ele a unidade.

RESPOSTA À SEGUNDA. — A imersão representa mais expressamente a figura da sepultura de Cristo,
por isso este modo de batizar é mais comum e mais recomendável. Mas os outros também a
representam de certo modo, embora não tão expressamente. Pois, de qualquer modo que se faça a
ablução, o corpo humano, ou alguma parte dele, é sob oposto à água como o corpo de Cristo foi posto
sob a terra.

RESPOSTA À TERCEIRA. — A parte principal do corpo, sobretudo dentre os membros externos, é a
cabeça, onde haurem a sua energia os sentidos internos e externos: Por onde, sendo a água tão pouca
que não baste para derramar-se por todo o corpo, ou por outra causa qualquer, é necessário derramá-la
na cabeça, onde se manifesta o principio da vida animal. — E embora seja pelos membros da geração
que o pecado original se transmite, não são contudo, antes, esses membros, que a cabeça os que devem
ser aspergidos. Pois, o batismo não exclui a transmissão do pecado original à prole, pelo ato da geração,
senão que livra a alma da mácula e do reato do pecado cometido. Por isso, deve ser lavada de
preferência a parte do corpo onde se manifesta a atividade da alma. — A lei velha porem aplicava o
remédio contra o pecado original no membro da geração, porque então ainda aquele, que viria delir o
pecado original, estava por nascer da estirpe de Abraão, cuja fé a circuncisão significava, como diz o
Apóstolo.

## Art. 8 — Se é necessária no batismo a tríplice imersão.
O oitavo discute-se assim. — Parece que a tríplice imersão é necessária no batismo.

1. — Pois, diz Agostinho: Com razão fostes imersos três vezes, porque recebestes o batismo em nome
da santa Trindade. Com razão fostes imersos três vezes, pois recebestes o batismo em nome de Jesus
Cristo, que ressurgiu dos mortos ao terceiro dia. Porquanto essa imersão repetida três vezes reproduz
tipicamente a sepultura do Senhor, pela qual fostes sepultados com Cristo no batismo. Ora, ambas essas
coisas são necessárias no batismo: o significar ele a Trindade das Pessoas e figurar a sepultura de Cristo.
Logo, parece que a tríplice imersão é necessária no batismo.

2. Demais. — Os sacramentos haurem a sua eficácia na instituição de Cristo. Ora, Cristo instituiu a
tríplice imersão. Assim o diz Pelágio Papa: O preceito evangélico, estabelecido por Jesus Cristo Nosso
Senhor e Salvador, nos adverte ministremos a cada um o santo batismo em nome da Trindade, por uma
imersão tríplice. Logo assim como é necessário batizar em nome da Trindade, assim também parece que
o é por uma tríplice imersão.

3. Demais. — Se não é necessária no batismo a tríplice imersão, então com a primeira imersão já o
sacramento está celebrado. E se pois, se acrescentar a segunda ou a terceira resulta que se terá
conferido segundo e terceiro batismo, o que é inadmissível. Logo, não basta para o batismo uma só
imersão, mas parece necessária a tríplice.
Mas, em contrário, Gregório escreve ao Bispo Leandro: De nenhum modo pode ser repreensível imergir
uma criança, ao batizá-la, três vezes ou uma só. Porque a tríplice imersão pode designar a Trindade das
Pessoas e sendo uma só pode simbolizar a unidade de Deus.

SOLUÇÃO. — Como dissemos, o batismo, por natureza, requer a ablução da água, de necessidade para o
sacramento; mas o modo de fazer a ablução é acidental. Por onde, como se deduz de autoridade citada
de Gregório essas duas coisas, em si mesmas consideradas, podem fazer-se licitamente — imergir tanto
uma como três vezes. Pois. a imersão única significa a unidade da morte de Cristo e a unidade divina; e a
tríplice, os três dias em que Cristo esteve na sepultura e também a Trindade das Pessoas.
Mas por causas diversas e por disposição da Igreja, foi instituído ora um modo, ora outro. Assim, nos
inícios da Igreja nascente certos opinavam erradamente sobre a Trindade, professando que Cristo era
puro homem, nem podia ser chamado Filho de Deus e Deus senão em virtude do seu merecimento
ganho sobretudo na morte. Por isso não batizavam em nome da Trindade, mas como comemoração da
morte de Cristo e só com uma imersão. O que foi reprovado na primitiva Igreja. Por isso dispõem os
Cânones dos Apóstolos: O presbítero ou o bispo que não fizer tríplice imersão ao celebrar o batismo,
mas uma só, como o mandam certos, em comemoração da morte do Senhor — seja deposto. Pois, o
Senhor não disse — Batizai em comemoração da minha morte; mas — Em nome do Padre e do Filho e
do Espírito Santo.
Mais tarde apareceu o erro de certos cismáticos e heréticos, que reiteravam o batismo, como o narra
Agostinho, dos Donatistas. Por isso, como reprovação desse erro, foi estabelecido no Concílio de Toledo,
que se fizesse uma só imersão. Para evitar — determina — o escândalo do cisma ou o uso de doutrinas
heréticas, faça-se uma só imersão no batismo. — Mas, cessando essa causa, comum ente se pratica no
batismo a tríplice imersão. E, portanto gravemente peca quem batizar de outro modo, como não
observante do rito da Igreja. Contudo, o batismo não deixa de ser feito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Trindade é como o agente principal no batismo. Ora, a
semelhança do agente se manifesta no efeito pela forma e não pela matéria. Por onde, a significação da
Trindade se faz no batismo pelas palavras da forma. Nem é de necessidade seja a Trindade significa da
pelo uso da matéria, o que só se pratica para dar maior expressão. — Semelhantemente, a morte de
Cristo é suficientemente figurada por uma só imersão. Quanto ao tríduo em que ficou na sepultura, não
é de necessidade para a nossa salvação; pois se num só dia tivesse sido morto e sepultado, isso bastaria
para a nossa redenção. Mas, os três dias em que ficou sepulto se ordenavam a manifestar a verdade da
sua morte, como dissemos. — Por onde é claro que a tríplice imersão não é necessária no batismo,
concernente nem à Trindade nem à paixão de Cristo.

RESPOSTA À SEGUNDA. — Pelágio Papa entende que a tríplice imersão foi instituída por Cristo, em
virtude de uma analogia; isto é, por ter Cristo mandado batizar em nome do Padre, do Filho e do Espírito
Santo. Mas a forma e o uso da matéria não têm a mesma razão de ser.

RESPOSTA À TERCEIRA. — Como dissemos, a intenção é necessária no batismo. Portanto, o ministro da
Igreja que tiver a intenção de ministrar um só batismo com a tríplice imersão, só um batismo ministrará.
Por isso diz Jerônimo:
Embora se batize três vezes, isto é, se faça a imersão, por causa do mistério da Trindade, contudo
reputa-se por um só batismo. — Se porem tivesse a intenção de ministrar um batismo em cada imersão,
repetindo as palavras da forma em cada imersão, pecaria, pelo que lhe concerne, batizando várias
vezes.

## Art. 9 — Se o batismo pode ser reiterado.
O nono discute-se assim. — Parece que o batismo pode ser reiterado.

1. — Pois, o batismo foi instituído para purificar dos pecados. Ora, os pecados se reiteram. Logo, com
maior razão, se deveria reiterar o batismo, porque a misericórdia de Cristo se eleva acima da culpa do
homem.

2. Demais. — João Batista foi sobretudo o que Cristo elogiou, quando dele disse: Entre os nascidos de
mulheres não se levantou outro maior do que João Batista. Ora, os batizados por João foram batizados
de novo, como refere a Escritura, quando diz que Paulo batizou os que já o tinham sido por João. Logo,
com muito maior razão os batizados pelos heréticos ou pecadores devem ser rebatizados.

3. Demais. — No Concílio Niceno está estatuído: Qualquer dos Paulianistas e dos Catafrígios que se
voltar para a Igreja Católica deve ser rebatizado. Ora, o mesmo deve dar-se com os outros heréticos.
Logo, os batizados pelos heréticos devem ser rebatizados.

4. Demais. — O batismo é de necessidade para a salvação. Ora, às vezes se duvida se um batizado
realmente o foi. Logo, parece que devem de novo ser batizados.

5. Demais. — A Eucaristia é um sacramento mais perfeito que o batismo, como se disse. Ora. O
sacramento da Eucaristia se reitera. Logo e com maior razão, parece que se pode reiterar o batismo.
Mas, em contrário, o Apóstolo: Não há senão uma fé e senão um batismo.

SOLUÇÃO. — O batismo não pode ser reiterado. — Primeiro, porque o batismo é uma regeneração
espiritual, pela qual morremos à vida velha e começamos a viver a vida nova. Donde o dizer o
Evangelho: Quem não renascer na água e do Espírito Santo não pode entrar no reino de Deus. Ora, cada
um tem uma só geração. Logo, não pode ó batismo ser reiterado, como também reiterada não pode ser
a geração carnal. Por isso, àquilo do Evangelho — Por ventura pode um homem tornar a entrar no
ventre de sua mãe e nascer outra vez? — diz Agostinho: Entende tu a natividade do Espírito do mesmo
modo por que Nicodemos entendia a natividade da carne. Assim como o nascimento não pode repetir-
se, assim não o batismo. Segundo, porque na frase do Apóstolo, somos batizados na morte de Cristo,
pela qual morremos ao pecado e ressurgimos para uma nova vida. Ora, Cristo só morreu uma vez. Logo,
o batismo não deve ser reiterado. Por isso, o Apóstolo diz, contra certos que queriam que se
rebatizasse: Crucificam de novo ao Filho de Deus em si mesmo. Ao que diz a Glosa: A morte única de
Cristo consagrou um batismo único. — Terceiro porque o batismo imprime caráter indelével e
acompanhado de uma certa consagração. Por onde, assim como as outras consagrações não se reiteram
na Igreja, assim também não o batismo. E tal é o que diz Agostinho, que o caráter militar não se retira. E
que o sacramento de Cristo não adere menos do que esse distintivo material, pois, vemos que nem os
apóstatas são privados de batismo, aos quais, quando voltam, não se lhes reitera. Quarto, porque o
batismo é principalmente conferido contra o pecado original. Por onde, assim como o pecado original
não se reitera, assim nem o batismo. Pois, no dizer do Apóstolo, assim como pelo pecado de um só
incorreram todos os homens na condenação, assim também pela justiça de um só recebem todos os
homens a justificação da vida.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O batismo produz o seu efeito em virtude da paixão de
Cristo, como dissemos. Por onde, assim como os pecados seguintes não tiram a virtude dessa paixão
assim não delem o batismo, de modo que fosse preciso renová-lo. Mas, a penitência posterior purifica
do pecado, que era obstáculo ao efeito do batismo.

RESPOSTA À SEGUNDA. — Aquilo do Evangelho — Eu não no conhecia — diz Agostinho: Eis que se
batiza depois de João ter batizado e não se torna a batizar depois de o ter feito um homicida! É porque
João conferiu o seu batismo e o homicida, o batismo de Cristo. Pois, tão santo é esse sacramento que
não se torna impuro por ser conferido por um homicida.

RESPOSTA À TERCEIRA. — Os Paulianos e os Catafrígios não batizavam em nome da Trindade. Por isso
diz Gregório, escrevendo ao Bispo Quirino: Os heréticos que de nenhum modo batizam em nome da
Trindade, como os Bonosianos e os Catafrígios, que partilham as opiníões dos Paulianos — estes por não
crerem na divindade do Cristo, vendo nele apenas um homem; aqueles, os Catafrígios, por terem a
extravagância de crerem que o Espírito. Santo é um homem, Montano — todos, quando voltam para a
santa Igreja, devem ser rebatizados, pois, não é batismo o que, na sua heresia, receberam, fora da
invocação trinitária. Aliás, lemos nas Regras eclesiásticas: Os que, dentre aqueles heréticos, foram batiza
dos que batizam confessando a santa Trindade, e vem à fé católica, sejam recebidos como batizados.

RESPOSTA À QUARTA. — Uma decretal de Alexandre III dispõe: Aqueles de quem se tiver dúvida se
foram batizados, o sejam, dizendo-se antes — se és batizado eu não te torno a batizar; mas se não és
batizado eu te batizo, etc. Pois, não podemos reiterar o que não sabemos se foi feito.

RESPOSTA À QUINTA. — Um e outro sacramento — o do batismo e o da Eucaristia, representam a
morte e a paixão do Senhor. Mas de modos diferentes. Pois, no batismo se comemora a morte de Cristo,
enquanto nós morremos com Cristo a fim de renascermos para uma nova vida. Ao passo que no
sacramento da Eucaristia se comemora a morte de Cristo, enquanto ele com a sua paixão, como nos
oferece o banquete pascal; segundo aquilo do Apóstolo: Cristo, que é a nossa Páscoa, foi imolado, e
assim solenizemos o nosso convite. E como nós nascemos uma só vez mas nos alimentamos muitas, o
batismo é conferido uma só vez, muitas porém a Eucaristia.

## Art. 10 — Se é conveniente o rito de que usa a Igreja ao batizar.
O décimo discute-se assim. Parece que não é conveniente o rito de que usa a Igreja ao batizar.

1. — Pois, corno diz Crisóstomo, nunca as águas do batismo poderiam purificar os pecados dos crentes,
se não fossem santificadas pelo contacto do corpo do Senhor. Ora isto foi feito no batismo de Cristo,
celebrado na festa da Epifania. Logo, com maior razão devia ser celebrado o batismo solene, antes na
festa da Epifania do que na vigília da Páscoa e na de Pentecostes.

2. Demais. — No mesmo sacramento não se pode usar de matérias diversas. Ora, ao batismo é própria a
ablução pela água. Logo, quem é batizado não devia ser ungido com o óleo sagrado, primeiro no peito,
depois entre as espáduas e em terceiro lugar com o crisma na cabeça.

3. Demais. — Em Jesus Cristo não há diferença de homem e mulher, de bárbaro e de cita, no dizer do
Apóstolo; e pela mesma razão, nem outras diferenças tais. Portanto e com maior razão, a diferença do
vestuário em nada atinge a fé de Cristo. Logo, não deve-se vestir os batizados, de roupas brancas.

4. Demais. — Sem todas essas práticas o batismo pode ser válido. Portanto, todas as que se referiram
são supérfluas e logo não devia a Igreja restituí-las no rito do batismo.
Mas, em contrário, a Igreja é governada pelo Espírito Santo, que nada faz em vão.

SOLUÇÃO. — Entre os elementos do batismo uns são de necessidade para o sacramento e outros fazem
parte de uma certa solenidade do mesmo. De necessidade para o sacramento são: a forma, causa
principal do sacramento; o ministro, causa instrumental; e o uso da matéria, isto é, a ablução com a
água, que designa o efeito principal do sacramento.
Todas as demais práticas, que a Igreja observa no rito de batizar, constituem antes uma certa solenidade
do sacramento. E se fazem por três razões. — Primeiro, para despertar a devoção dos fiéis e a
reverência para com o sacramento. Se, pois, se fizesse simplesmente a ablução com a água, sem
solenidade, facilmente pensariam certos que se tratava de uma ablução comum. — Segundo, para
instrução dos fiéis. Pois, os simples e iletrados devem ser ensinados mediante sinais sensíveis; por
exemplo, por pinturas e meios semelhantes. E assim, por tais práticas sacramentais, ou se instruem ou
são solicitados a procurar saber o significado desses sinais sensíveis. Por onde, como além do efeito
principal do sacramento, outras coisas devem-se saber concernentes ao batismo; é conveniente serem
manifestadas por certos sinais exteriores. Terceiro, porque as orações, bênçãos e práticas semelhantes
coíbem o poder do demônio de impedir o efeito sacramental.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo na Epifania recebeu o batismo de João, como
dissemos; e esse não no recebem os fiéis, mas antes o de Cristo. E este tira a sua eficácia da paixão de
Cristo, conforme o diz o Apóstolo: Todos os que tomos batizados em Jesus Cristo fomos batizados na
sua morte. E do Espírito Santo, segundo o Evangelho: Quem não renascer da água e do Espírito Santo.
Por isso, na Igreja se celebra solenemente o batismo na vigília da Páscoa, quando se comemora a
sepultura e a ressurreição do Senhor, o qual por isso depois da ressurreição deu aos discípulos o
preceito do batismo, como lemos no Evangelho. E na vigília de Pentecostes, quando se começa a
celebrar a solenidade do Espírito Santo; por isso, como lemos na Escritura, os Apóstolos, no dia mesmo
de Pentecostes, em que receberam o Espírito Santo, batizaram três mil homens.

RESPOSTA À SEGUNDA. — Faz-se no batismo uso da água, como pertinente à substância do
sacramento; ao passo que se faz uso do óleo ou do crisma por maior solenidade. — Assim, primeiro, o
batizando é ungido com o santo óleo no peito e nas espáduas, como atleta de Deus, na frase de
Ambrósio, como costumavam untar-se os lutadores. Ou, como diz Inocêncio III, o batizando é ungido no
peito, a fim de, por dom do Espírito Santo, rejeitar o erro e a ignorância e receber a verdadeira fé, pois
de fé vive o justo. É ungido entre as espáduas para que, com a graça do Espírito Santo, expulse a
negligência e a tibieza e pratique as boas obras; e para que o sacramento da fé seja, no seu coração, a
pureza dos pensamentos e, nas espáduas, a força nos trabalhos. — Depois do batismo como diz Rábão,
é o neófito logo sinalado na testa com o santo crisma pelo presbítero, dizendo este ao mesmo tempo
uma oração, para que se torne participante do reino de Cristo e, como discípulo de Cristo, possa
chamar-se Cristão. Ou, no dizer de Ambrósio, o óleo é derramado sobre a cabeça, porque é a sede da
inteligência do sábio e para que o batizado esteja pronto a dar razão da sua fé a quem lh'a pedir.

RESPOSTA À TERCEIRA. — O batizado é revestido de roupas brancas, não por lhe não ser lícito usar de
outras, mas em sinal da gloriosa ressurreição, para a qual o batismo nos faz renascer. E para simbolizar a
pureza de vida, que devemos conservar depois do batismo, segundo aquilo do Apóstolo: Andemos em
novidade de vida.

RESPOSTA À QUARTA. — O concernente à solenidade do sacramento, embora não lhe seja de
necessidade, nem por isso é supérfluo, pois lhe contribui para a perfeição, como dissemos.

## Art. 11 — Se são convenientemente admitidos três batismos: o de água, o de sangue e o de espírito ou do Espírito Santo.
O undécimo discute-se assim. — Parece que não são convenientemente admitidos três batismos: o de
água, o de sangue e o de espírito ou do Espírito Santo.

1. — Pois, no dizer do Apóstolo, não há senão uma fé e senão um batismo. Ora, não havendo senão uma
fé, não podem portanto haver três batismos.

2. Demais. — O batismo é um sacramento como do sobredito se colhe. Ora, só o batismo de água é
sacramento. Logo, não se devem admitir os dois outros batismos.

3. Demais. — Damasceno determina vários outros gêneros de batismos. Logo, não se devem admitir só
três.
Mas, em contrário, àquilo do Apóstolo Doutrinas sobre o batismo — diz a Glosa: Emprega o plural,
porque há o batismo de água, o de penitência e o de sangue.

SOLUÇÃO. — Como dissemos, o batismo de água tira a sua eficácia da paixão de Cristo, com a qual com
ele nos configuramos. E depois, como da primeira causa, haure-a no Espírito Santo. Embora, porém o
efeito dependa da primeira causa, a causa, contudo sobre excede o efeito nem dele depende. – E
portanto além do batismo da água, podemos conseguir o efeito do sacramento, em virtude da paixão de
Cristo, conformando-nos com essa paixão, sofrendo por ele. Donde o dizer a Escritura: Estes são os que
vieram de uma grande tribulação e livraram as suas roupas e as embranqueceram no sangue do
cordeiro. — Também pela mesma razão podemos, por virtude do Espírito Santo, conseguir o efeito do
batismo, não só sem o batismo de água como também sem o de sangue — se o Espírito Santo nos
mover o coração a crer e a amar a Deus e a nos arrependermos dos pecados; e esse também se chama
batismo de penitência. Do qual diz a Escritura: Quando o Senhor alimpar as manchas das filhas de Sião e
lavar o sangue do meio de Jerusalém com espírito de justiça e com espírito de ardor. Assim pois cada um
dos outros batismos se chama tal, por fazer as vezes do batismo. Por isso diz Agostinho: Que o martírio
às vezes substitui o batismo, S. Cipriano acha disso uma prova, não sem valor, na promessa do Salvador
ao ladrão que contudo não era batizado: Hoje estarás comigo no Paraíso. Quanto a mim, refletindo cada
vez mais sobre este assunto, chego à conclusão que o martírio pelo nome de Cristo não é o único meio
de suprir o batismo; mas que a fé e a conversão do coração podem chegar ao mesmo resultado, se
circunstâncias desfavoráveis impedirem a celebração do sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os outros dois batismos se incluem no de água, que
haure a sua eficácia na paixão de Cristo e do Espírito Santo. O que pois não tira a unidade do batismo.

RESPOSTA À SEGUNDA. — Como dissemos o sacramento é por natureza um sinal. Ora os outros dois
batismos convêm com o batismo de água, não pela razão de sinal, mas pelos efeitos que produzem. E
portanto não são sacramentos.

RESPOSTA À TERCEIRA. — Os batismos de que fala Damasceno, não o são senão figuradamente. Tal, o
dilúvio, que foi um sinal do nosso batismo, quanto à salvação dos fiéis na Igreja, assim como poucas
pessoas se salvaram na arca, no dizer da Escritura — Fala também na passagem do mar Vermelho,
símbolo do nosso batismo, quanto à liberação da servitude do pecado. Donde o dizer o Apóstolo: Todos
foram batizados na nuvem e no mar. — Acrescenta ainda as abluções diversas que se faziam na lei
Velha, que prefiguravam o nosso batismo quanto à purificação dos pecados. — E enfim, o batismo de
João, preparatório do nosso.

## Art. 12 — Se o batismo de sangue é o mais principal dos três.
O duodécimo discute-se assim. — Parece que o batismo de sangue não é o mais principal dos três.

1. — Pois, o batismo de água imprime caráter. O que não faz o sangue. Logo, o batismo de sangue não é
mais principal que o de água.

2. Demais. — O batismo de sangue não vale sem o de espírito, que é pela caridade, como diz o Apóstolo:
Se entregar o meu corpo para ser queimado se todavia não tiver caridade, nada disto me aproveita. Ora,
o batismo de espírito vale sem o de sangue, pois, não são só os mártires que se salvam. Logo, o batismo
de sangue não é o mais principal.

3. Demais. — Assim como o batismo de água tira a sua eficácia da paixão de Cristo; ao qual, segundo se
disse, corresponde o batismo de sangue, assim a paixão de Cristo haure a sua eficácia no Espírito Santo,
segundo aquilo do Apóstolo: O sangue de Cristo, que pelo Espírito Santo se oferece a si mesmo por nós,
limpará a nossa consciência das obras da morte, etc. Logo, o batismo de espírito é mais principal que o
de sangue. Portanto, não é o batismo de sangue o mais principal.
Mas, em contrário, Agostinho, comparando os batismos, diz: O batizado confessa a sua fé diante do
verdugo. Aquele, depois da sua confissão, é aspergido com água; este, com sangue. Aquele, pela
imposição da mão do pontífice, recebe o Espírito Santo; este se torna o tempo do Espírito Santo.

SOLUÇÃO. — Como dissemos, a efusão do sangue por amor de Cristo e a ação interior do Espírito Santo
se chamam batismos por fazerem o efeito do batismo de água. Ora, este tira a sua eficácia da paixão de
Cristo e do Espírito Santo, como se disse. E essas duas causas operam em qualquer desses três batismos,
mas de modo mais excelente no batismo de sangue. Pois, a paixão de Cristo opera por certo no batismo
de água por uma representação de algum modo figurada: no batismo de espírito ou de penitência por
uma determinada afeição; mas no batismo de sangue, pela imitação das obras. Semelhantemente, a
virtude do Espírito Santo obra no batismo de água por uma certa virtude latente; no de penitência, pela
noção de coração; no de sangue, pelo ardente fervor da dileção e do afeto, segundo aquilo de João:
Ninguém tem maior amor do que este, de dar um a própria vida por seus amigos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O caráter é uma realidade e um sacramento. Mas não
dizemos que o batismo de sangue tenha preeminência, quanto à essência do sacramento, senão quanto
ao efeito deste.

RESPOSTA À SEGUNDA. — A efusão de sangue não é por si mesma um batismo, se o for sem a caridade.
Por onde é claro que o batismo de sangue inclui o de espírito e não ao inverso. E isso mesmo prova que
é mais perfeito.

RESPOSTA À TERCEIRA. — O batismo de sangue tem preeminência não só em virtude da paixão de
Cristo, mas também em virtude do Espírito Santo, como se disse.