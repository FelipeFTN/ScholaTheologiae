# Questão 55: Da manifestação da ressurreição
Em seguida devemos tratar da manifestação da ressurreição.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se a ressurreição de Cristo devia manifestar-se a todos.
O primeiro discute-se assim. — Parece que a ressurreição de Cristo devia manifesta-se a todos.
1 — Pois, a um pecado público é devida uma pena pública, segundo aquilo do Apóstolo: Aos que
pecarem repreende-os diante de todos. Assim também a quem publicamente mereceu é devido um
premio público. Ora, a glória da ressurreição foi o premio das humilhações da Paixão, como diz
Agostinho. Logo, tendo a Paixão de Cristo sido manifesta a todos, pois publicamente a sofreu, parece
que a glória da sua ressurreição também devia manifestar-se a todos.

2. Demais. — Assim como a Paixão de Cristo se ordenava à nossa salvação, assim também a sua
ressurreição, conforme àquilo do Apóstolo: Ressuscitou para a nossa justificação. Ora, o respeitante à
utilidade pública deve manifestar-se a todos. Logo, a ressurreição de Cristo devia manifestar-se a todos
e não especialmente a certos.

3. Demais. — Aqueles a quem se manifestou a ressurreição de Cristo foram testemunhas da
ressurreição, conforme aquilo da Escritura: A quem Deus ressuscitou dentre os mortos, do que nós
somos testemunha. Ora, esse testemunho o davam proclamando-o publicamente. O que não é próprio
das mulheres, segundo o Apóstolo: As mulheres estejam caladas na Igreja. E noutro lugar: Eu não
permito à mulher, que ensine. Logo, parece que inconvenientemente a ressurreição de Cristo foi
manifesta primeiro às mulheres que aos homens em geral.
Mas, em contrário, a Escritura: A quem Deus ressuscitou ao terceiro dia e quis que se manifestasse, não
a todo o povo, mas às testemunhas que Deus havia ordenado antes.

SOLUÇÃO. — As coisas que conhecemos, umas as conhecemos pela lei geral da natureza; outras por um
especial dom da graça, como as reveladas por Deus. E estas como diz Dionísio, estão sujeitos à lei divina,
de serem por Deus revelados imediatamente ao superior, mediante aos quais chegam ao conhecimento
dos inferiores, como o demonstra a ordenação dos espíritos celestes. Ora, o concernente àglória futura
excede o conhecimento comum dos homens, conforme àquilo da Escritura: O olho não viu, exceto tu, ó
Deus, o que tens preparado para os que te esperam. Por isso, tais coisas o homem não as conhece
senão revelados por Deus conforme o diz o Apóstolo: Deus nô-lo revelou a nós pelo seu Espírito. Ora,
como Cristo ressurgiu gloriosamente, por isso a sua ressurreição não foi manifesta a todo o povo, mas
só a certos, cujo testemunho deu-a a conhecer aos demais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Paixão de Cristo se consumou num corpo dotado
ainda de uma natureza passível, conhecida de todos por uma lei comum. Por isso a Paixão de Cristo
podia manifestar-se imediatamente a todo o povo. Ao passo que a Ressurreição de Cristo se operou
pela glória do Pai, como diz o Apóstolo. Por isso manifestou-se imediatamente, não a todos, mas a
certos. — Quanto a ser uma pena pública imposta aos pecadores públicos, isso se entende das penas da
vida presente. E semelhantemente, méritos públicos hão de premiar-se em público, para estímulo dos
outros. Mas as penas e os prêmios da vida futura não são manifestados publicamente a todos; mas
especialmente àqueles a quem Deus o pre-ordenou.

RESPOSTA À SEGUNDA. — A ressurreição de Cristo, ordenada à salvação de todos, também chegou ao
conhecimento de todos, não que se manifestasse a todos Imediatamente, mas a certos, mediante cujo
testemunho, a conhecessem os demais.

RESPOSTA À TERCEIRA. — À mulher não é permitido ensinar publicamente na Igreja; mas permitido lhe
é instruir privadamente a certos, num ensinamento doméstico. Por onde como Ambrósio diz, uma
mulher foi enviada aos da família de Cristo; mas não a dar testemunho da ressurreição do povo. — E se
Cristo apareceu primeiro às mulheres, foi para a mulher, que fora a primeira a levar ao homem a
mensagem da morte, fosse também a primeira a anunciar a vida de Cristo ressurecto para a glória.
Donde o dizer Cirilo: A mulher, outrora ministra da morte, foi a primeira a perceber e a anunciar o
venerando mistério da redenção. Assim, o gênero feminino alcançou tanto a absolvição da ignomínia
como o repúdio da maldição. E também se mostrava desse modo simultaneamente que no concernente
ao estado da glória, nenhum detrimento sofreria o sexo feminino; mas, se tiverem mais ardente a
caridade, de maior glória também gozarão da visão divina. Por isso as mulheres, que mais ardentemente
amaram o Senhor, a ponto de não se afastarem do seu sepulcro, que os próprios discípulos tinham
abandonado, também foram as primeiras a ver o Senhor na glória da ressurreição.

## Art. 2 — Se deviam os discípulos ver Cristo ressurgir.
O segundo discute-se assim. — Parece que deviam os discípulos ver Cristo ressurgir.

1. — Pois os discípulos deviam testificar a ressurreição de Cristo, segundo aquilo da Escritura: Os
apóstolos com grande valor davam testemunho da ressurreição de Jesus Cristo Nosso Senhor. Ora, o
testemunho mais certo é o da vista. Logo, deviam eles por si mesmos presenciar a ressurreição de
Cristo.

2. Demais. — Para terem a certeza da fé os discípulos presenciaram a ascensão de Cristo, segundo a
Escritura: Vendo-o eles, se foi elevando. Ora, também era necessário que tivessem uma fé certa na
ressurreição de Cristo. Logo parece que Cristo devia ressurgir na presença deles.

3. Demais. — A ressurreição de Lázaro foi um sinal da ressurreição futura de Cristo. Ora, o Senhor
ressuscitou Lázaro àvista dos discípulos. Logo, parece que também Cristo devia ressurgir na presença
deles. .
Mas, em contrário, o Evangelho: O Senhor, tendo ressurgido de manhã no primeiro dia da semana,
apareceu primeiramente a Maria Madalena. Ora, Maria Madalena não o viu ressurgir, mas, estando à
procura dele no sepulcro ouviu do Anjo: Ressurgiu, não está aqui. Logo, ninguém o viu ressurgir.

SOLUÇÃO. — Como diz o Apóstolo, as causas de Deus são ordenadas. Ora, é ordem instituída por Deus
que as verdades superiores ao homem lhes sejam reveladas pelos anjos, como está claro em Dionísio:
Ora, Cristo ressurrecto não voltou a viver uma vida habitual dos homens. mas passou a uma vida imortal
como a que é própria de Deus, segundo o Apóstolo: Mas enquanto ao viver, vive para Deus. Por isso, a
ressurreição mesma de Cristo não devia ser imediatamente presenciada pelos homens, mas a eles
anunciada pelos anjos. Donde o dizer Hilário: O anjo foi o primeiro mensageiro da ressurreição, para que
esta fosse anunciada por um ministro familiar da vontade paterna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os Apóstolos puderam ser testemunha de vista da
ressurreição de Cristo, porque com os próprios olhos viram-no vivo, depois de ressurrecto, a ele que
sabiam tinha morrido. Ora, assim como chegamos à visão da bem-aventurança pela fé que ouvimos
pregar, assim os homens chegaram à visão de Cristo ressurrecto pelo que primeiro ouviram dos anjos.

RESPOSTA À SEGUNDA. — A ascensão de Cristo, quanto ao seu ponto de partida, não transcendia o
conhecimento comum aos homens; mas só quanto ao seu termo de chegada. Por isso os discípulos
puderam presenciar o início da ascensão de Cristo, isto é, quando se elevava da terra. Mas não a viram
no seu termo, porque não viram como foi recebido no céu. Ao passo que a ressurreição de Cristo
transcendia o conhecimento comum quanto ao seu ponto de partida, que foi a volta da sua alma dos
infernos e a saída do corpo do sepulcro fechado. E também quanto ao ponto de chegada, pelo qual
alcançou a vida gloriosa. Por isso a ressurreição não devia ser tal que fosse vista pelos homens

RESPOSTA À TERCEIRA. — Lázaro ressuscitou para voltar àvida que antes vivia, e que não ultrapassava o
conhecimento comum dos homens. Por onde, não há semelhança de razão.

## Art. 3 — Se Cristo, depois da ressurreição devia conviver continuamente com os discípulos.
O terceiro discute-se assim. — Parece que Cristo, depois da ressurreição, devia conviver
continuamente com os discípulos.

1. — Pois, apareceu aos discípulos depois da ressurreição para dar-Ihes a certeza dela e consolá-Ias na
sua perturbação, segundo o Evangelho: Alegraram-se os discípulos de terem visto o Senhor. Ora, mais se
teriam certificado e consolado se lhes tivesse logo manifestado a eles. Logo, parece que devia conviver
continuamente com eles.

2. Demais. — Cristo ressurrecto dos mortos não subiu logo ao céu, só depois de quarenta dias, como se
lê na Escritura. Ora, no tempo intermediário em nenhum outro lugar podia mais convenientemente
estar que onde os seus discípulos estavam todos congregados. Logo, parece que devia conviver
continuamente com eles.

3. Demais. — No domingo mesmo da ressurreição Cristo apareceu cinco vezes, como lemos no
Evangelho e o adverte Agostinho com as palavras seguintes. Primeiro, às mulheres no sepulcro;
segundo, ainda a elas quando voltavam do sepulcro; terceiro, a Pedro; quarto, aos dois discípulos que
iam a uma aldeia; quinto, a vários em Jerusalém, entre os quais não estava Tomás. Logo, parece que
também nos outros dias, antes da sua ascensão, devia aparecer-Ihes, ao menos várias vezes por dia.

4. Demais. — O Senhor, antes da Paixão, disse aos discípulos. Depois que eu ressurgir irei adiante de vós
para a Galileia. O que também o anjo e o próprio Senhor disse às mulheres depois da ressurreição. E,
contudo foi antes visto deles em Jerusalém; e no dia mesmo da ressurreição, como se disse; e também
no oitavo dia como lemos no Evangelho. Logo, parece que não conviveu com os discípulos, de modo
conveniente, depois da ressurreição.
Mas, em contrário, o Evangelho, diz que depois de oito dias é que Cristo apareceu aos discípulos. Logo,
não conviveu com eles continuamente.

SOLUÇÃO. — Duas coisas deviam ser manifestas aos discípulos concernentes à ressurreição de Cristo: a
verdade da ressurreição e a glória do ressurgente, Ora, para manifestar a verdade da ressurreição
bastava que lhes aparecesse várias vezes cem eles familiarmente falasse, comesse, bebesse e lhes
oferecesse o corpo a tocarem. Quanto à manifestar a sua glória de ressurrecto, não quis conviver com
eles continuamente, como fizera antes, a fim de que não parecesse ter ressurgido para a mesma vida
que vivia antes. Por isso lhes disse: Isto é o que queriam dizer as palavras que eu vos dizia quando ainda
estava convosco. Ora, então lhes estava presente corporalmente; ao passo que antes lhes estava
presente não só corporalmente, mas ainda sob a aparência de um corpo mortal. Por isso Beda, expondo
as palavras supra referidas diz: Quando ainda estava convosco, isto é, quando ainda tinha um corpo
mortal, como o que ainda tendes. E verdade que então ressuscitou com a mesma carne, mas já não
tinha a mesma mortalidade que eles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As frequentes aparições de Cristo bastavam para
certificar os discípulos da verdade da ressurreição. Mas o conviver continuadamente com eles podia
induzi-Ios em erro, se acreditassem ter ele ressurgido para uma vida semelhante a que antes vivera.
Quanto à consolação com a sua contínua presença, prometeu que a teriam na outra vida, consoante ao
Evangelho: Eu hei-de ver-vos de novo e o vosso coração ficará cheio de gozo; e o vosso gozo ninguém
vo-to tirará.

RESPOSTA À SEGUNDA. — Se Cristo não conviveu continuamente com os discípulos não é porque
pensasse fosse mais conveniente estar alhures. Mas porque julgava mais conveniente para a instrução
deles, com eles não conviver continuamente, pela razão já dada. Ignoramos porém em que lugares lhes
apareceu corporalmente, nesse meio tempo, pois não no-lo refere a Escritura; demais, em todo lugar é
o seu senhorio na mesma frase.

RESPOSTA À TERCEIRA. — Se no primeiro dia apareceu mais frequentemente, foi porque os Apóstolos
deviam ser advertidos por meio de sinais, de modo que desde o princípio tivessem fé na ressurreição. —
Mas depois de a terem recebido, não era preciso que, já certificados, fossem instruídos com tão
frequentes aparições. Por isso não lemos no Evangelho que lhes aparecesse depois do primeiro dia,
senão cinco vezes. Pois, como diz Agostinho, depois das primeiras cincos aparições, apareceu-lhes pela
sexta vez quando Tomás o viu; pela sétima, no mar de Tiberíades, na captura dos peixes; pela oitava, no
monte da Galileia segundo Mateus; pela nona, como relata Marcos, numa última ceia, porque já não
haveriam de conviver com ele na terra; pela décima, no dia mesmo em que, não já na terra, mas
elevado nas nuvens, quando subiu ao céu. Mas nem tudo o que fez está escrito, como o confessa João.
Assim, pois, conviveu frequentemente com eles antes de ter subido aos céus. E isto tudo para a
consolação deles. Por isso o Apóstolo diz: Foi visto por mais de quinhentos irmãos estando juntos;
depois foi visto de Tiago. Mas dessas aparições não faz menção o Evangelho.

RESPOSTA À QUARTA. — Crisóstomo, assim expõe aquilo do Evangelho — Depois que eu ressurgir irei
adiante de vós para a Galileia. Não vai, diz, a nenhuma região longínqua para se lhes manifestar; mas
lhes aparece no meio mesmo da sua nação e nos próprios lugares onde sempre convivera com eles. De
modo que, assim, cressem que o crucificado foi o mesmo que ressurgiu. E diz que iria para a Galileia
para se libertarem ele do temor dos judeus. Assim, pois, como diz Ambrósio, o Senhor anunciou aos
discípulos que o veriam na Galileia mas como o tremor os retinha encerrados no cenáculo, foi aí que
primeiro se lhes mostrou. Nem por isso faltou ao cumprimento da promessa ao contrário, foi um
cumprimento prematuro e misericordioso dela. Mas depois, quando já tinha a alma confortada,
dirigiram-se para a Galileia. Podemos porem dizer igualmente que, tendo-se revelado a poucos no
cenáculo, quis mostrar-se a muitos, na montanha. Pois, como adverte Eusébio, os dois evangelistas,
Lucas e João, escrevem que Cristo apareceu em Jerusalém só aos onze. Mas os outros dois nos referem
que ele foi para a Galileia: para se manifestar, não somente aos onze, mas ainda a todos os discípulos e
irmãos, como o tinha ordenado o Anjo e o Salvador. O que também Paulo menciona, quando diz: Depois
apareceu simultaneamente a mais de quinhentos irmãos. Mas a solução mais verdadeira é que primeiro
foi visto uma ou duas vezes dos que estavam escondidos em Jerusalém, para consolação deles. Ao passo
que na Galileia, não as oculta nem uma ou duas vezes se manifestou, mas ostentando toda a grandeza
do seu poder, mostrando-se-lhes vivo, depois da Paixão, por muitos milagres, como o atesta Lucas no
Atos, ou, como quer Agostinho, o dito do anjo e do Senhor, que haveria de ir adiante deles para a
Galileia deve ser tomado em sentido profético. Pois, essa espécie de transmigração, representada pela
Galileia; dava-lhes a entender que os Apóstolos passariam a pregar do povo de Israel para os gentios.
Aos quais não teriam ousado ensinar o Evangelho se o Senhor mesmo não lhes tivesse preparado o
caminho no coração dos homens. Tal o sentido das palavras do Evangelho: Eu irei adiante de vós para a
Galileia; mas a palavra Galileia também significa revelação; e neste sentido podemos entender que
Cristo não teria mais a forma de servo, mas a que o torna igual ao Pai e da qual prometem aos seus
amigos fieis a participação. E que partiu para um lugar donde não se afastaria, vindo ter conosco, e
partindo para o qual, não nos abandonaria.

## Art. 4 — Se Cristo devia aparecer aos discípulos sob figura diferente.
O quarto discute-se assim. — Parece que Cristo não devia aparecer aos discípulos sob uma figura
diferente.

1. — Pois, não pode realmente aparecer senão o que existe. Ora Cristo só tinha uma figura. Se,
portanto, apareceu com figura diferente a sua aparição não era real mas ficta. O que é inadmissível,
porque, como diz Agostinho, se Cristo engana, não é a Verdade; ora Cristo é a Verdade. Logo, parece
que Cristo não devia aparecer aos discípulos sob uma figura diferente.

2. Demais. — Ninguém pode aparecer aos outros com uma forma diferente da que tem, salvo se os
olhos dos que contemplam forem iludidos com fantasmagorias. Ora, essas fantasmagorias sendo
produto das artes mágicas, não convinham a Cristo, segundo o Apóstolo: Que concórdia entre Cristo e
Belial? Logo, parece que não devia aparecer sob uma forma diferente.

3. Demais. — Assim como pela Sagrada Escritura a nossa fé se certifica. assim os discípulos certificados
foram na fé da ressurreição de Cristo por meio das aparições. Ora, como diz Agostinho, uma só
inverdade que contenha a Sagrada Escritura infirma-lhe totalmente a autoridade. Se. portanto Cristo
apareceu aos discípulos uma só vez, sob forma diferente da sua, ficou infirmado tudo quanto eles,
depois da ressurreição, viram em Cristo. O que é inadmissível. Logo, não devia ter-lhes aparecido sob
forma diferente.
Mas, em contrário, o Evangelho: Depois disto se mostrou em outra forma a dois deles que iam
caminhando para uma aldeia.

SOLUÇÃO. — Como dissemos, a ressurreição de Cristo devia manifestar-se aos homens do modo pelo
qual as coisas divinas lhes são reveladas. Ora, as coisas divinas são reveladas aos homens diversamente,
conforme as disposições diversas que eles apresentam. Assim, os de mente bem disposta as percebem
como verdadeiramente são. Os que, porém são desprovidos dessa disposição, as percebem com um
misto de dúvidas e erros; pois, como diz o Apóstolo, o homem animal não percebe aquelas coisas que
são do Espírito de Deus. Por isso Cristo a certos que, depois da ressurreição, estavam dispostos a crer se
lhes manifestou com a sua forma própria. Mas a outros se apresentou com forma diversa, que já parecia
entibiarem na fé. Donde o dizer o Evangelho: Ora, nós esperávamos que ele fosse o que resgatasse
Israel. E por isso diz Gregório, que Cristo se lhes manifestou corporalmente tal como eles pensavam que
fosse. Senâo-lhes ainda estranho aos corações, de fé tíbia, fingiu que ia mais longe, isto é. como se fosse
estrangeiro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho, nem tudo o que fingimos é
mentira, senão só quando fingimos o que nada significa. Não há, pois, mentira, mas verdade figurada
quando a nossa ficção significa alguma coisa. Do contrário, por mentiras se reputariam todas as
expressões figuradas usadas pelos sábios e varões santos, ou mesmo pelo Senhor, porque conforme o
uso corrente nenhuma verdade encerram tais expressões. Ora, como os ditos, também os- fatos podem
ser fictos, sem mentira, para significar alguma realidade. E tal é o caso presente, como se disse.

RESPOSTA À SEGUNDA. — Como diz Agostinho, o Senhor podia transformar a sua carne, de modo que
exibisse figura realmente diferente daquela que costumavam ver; assim como, antes da Paixão,
transformou-se no monte, de maneira que a face lhe resplandecia como o sol. Mas tal não se deu no
caso presente E talvez não repugnasse também acreditar que os olhos dos discípulos fossem vítima da
ilusão de Satan para impedi-los de reconhecer a Jesus. Daí o referir o Evangelho, que os olhos deles
estavam como fechados, para o não reconhecerem.

RESPOSTA À TERCEIRA. — A razão aduzida colheria, se pelo aspecto de uma figura estranha os
discípulos não tivessem sido levados a contemplar a verdadeira figura de Cristo. Pois, como diz
Agostinho no mesmo lugar, que os olhos deles estivessem iludidos do modo referido, Cristo não o
permitiu senão até a fração do pão, ensinando-nos assim que o participar à unidade do seu corpo tem o
efeito de afastar todos os obstáculos suscitados pelo inimigo para nos impedir de reconhecer a Cristo.
Por isso, no mesmo lugar se acrescenta que, abriram-se-lhes os olhos e o reconheceram; não que
andassem antes com os olhos fechados, mas se lhes interpunha um obstáculo que não lhes permitia
reconhecer o que viam efeito esse habitual da caligem de algum humor.

## Art. 5 — Se Cristo devia declarar com provas a verdade da sua ressurreição.
O quinto discute-se assim. — Parece que Cristo não devia declarar com provas a verdade da sua
ressurreição.

1. — Pois, diz Ambrósio: Deixa-te de provas, quando se trata da fé. Ora, a ressurreição de Cristo é
matéria de fé. Logo, não é susceptível de provas.

2. Demais. — Gregório diz: Nenhum mérito tem a fé, quando a razão humana se funda na experiência.
Ora, Cristo não devia privar-nos do mérito da fé. Logo, não devia confirmar com provas a sua
ressurreição.

3. Demais. — Cristo veio ao mundo para tornar possível aos homens a aquisição da felicidade, segundo a
Escritura: Eu vim para terem a vida e para terem em maior abundância. Logo, parece que Cristo não
devia manifestar com provas a sua ressurreição.
Mas, em contrário, a Escritura refere que Cristo apareceu aos discípulos por quarenta dias, com muitas
provas, falando-lhes do reino de Deus.

SOLUÇÃO. — O vocábulo - prova - é susceptível de duplo sentido. Num, assim se chama qualquer razão
que nos leve a dar fé a uma causa duvidosa. Noutro, é às vezes um sinal sensível que induz a
manifestação de alguma verdade; assim, Aristóteles nas suas obras usa às vezes ao referido vocábulo
neste sentido. Ora, tomando a palavra no primeiro sentido, Cristo não deu aos seus discípulos prova da
sua ressurreição. Porque tal prova seria um argumento resultante de determinados princípios: e estes,
não sendo conhecidos dos discípulos, nada por eles se lhes poderia provar, pois, do desconhecido não
podemos tirar nenhum conhecimento. E, de outro lado, se lhes fossem conhecidos, não transcenderiam
a razão humana e portanto, não seriam eficazes para fundar a fé na ressurreição, que excede a nossa
razão: pois os princípios devem ser do mesmo gênero que as coisas que pretendem provar, como diz
Aristóteles. Ora, Cristo provou aos discípulos a sua ressurreição pela autoridade da Sagrada Escritura,
fundamento da fé, quando disse: Era necessário que se cumprisse tudo o que de mim estava escrito na
lei de Moisés, nos profetas e nos salmos.
Mas, se considerarmos a prova na segunda acepção então dizemos que Cristo declarou por provas a sua
ressurreição, porque mostrou por certos sinais evidentíssimos, que verdadeiramente ressurgiu. Por isso,
o grego, em lugar de dizer como a vulgata - com muitas provas - diz TfXJJ.'YJPW'" isto é, sinal evidente
para provar. E esses sinais de ressurreição Cristo os manifestou aos discípulos, por duas razões.
Primeiro, porque os corações deles não estavam dispostos a dar fàcilmente fé à ressurreição. Por isso
Cristo lhes disse: ó estultos e tardas de coração para crer! E noutro lugar o Evangelho diz que Cristo lhes
lançou em rosto a sua incredulidade e dureza de coração. — Segundo, para que, mediante tais sinais a
eles manifestados, o testemunho que dessem fosse mais eficaz, segundo aquilo da Escritura: O que
vimos e ouvimos e palparam as nossas mãos, disso damos testemunho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ambrósio, no lugar citado, funda-se em argumentos
baseados na razão humana. Os quais não são válidos para demonstrar as coisas da fé, como dissemos.

RESPOSTA À SEGUNDA. — O mérito da fé está em crermos por ordem de Deus o que não vemos. Por
onde, só exclui o mérito aquela razão que no, dá a ver pela ciência o que nos foi proposto a crer; e tal é
a razão demonstrativa. Ora, a tais razões Cristo não recorreu para declarar a sua ressurreição.

RESPOSTA À TERCEIRA. — Como dissemos, o mérito da beatitude, cuja causa é a fé, não fica totalmente
excluído, salvo se não quiséssemos crer senão no que vemos. O fato porém de alguém crer o que não
vê, mediante sinais visíveis, não elimina totalmente a fé nem o seu mérito. Assim Tomé, a quem o
Senhor disse - Porque me viste, creste, viu uma causa e creu outra: viu as chagas e creu em Deus. É,
porém fé mais perfeita a que, para crer, não exige esses auxílios. Por isso, para arguir a falta de fé em
certo, o Senhor disse: Vós, se não vedes milagres e prodígios, não credes. E, assim sendo, podemos
entender que os de alma pronta a crer a Deus, mesmo sem nenhuns sinais visíveis, são bem-
aventurados, por comparação com os que não crêem sem que vejam tais sinais.

## Art. 6 — Se as provas aduzidas por Cristo manifestaram suficientemente a verdade da sua ressurreição.
O sexto discute-se assim. — Parece que as provas aduzidas por Cristo não manifestaram
suficientemente a verdade da sua ressurreição.

1. — Pois, Cristo não manifestou nada aos discípulos. depois da sua ressurreição, que também não
pudessem os anjos manifestar ou deixar de o fazer, quando aparecem aos homens. Assim, os anjos
frequentemente se mostravam aos homens em forma humana, com eles falavam conviviam e comiam
como se verdadeiramente fossem homens. Tal o lemos na Escritura quando refere que Abraão deu
hospitalidade a anjos; e que um anjo levou e reconduziu a Tobias. E contudo não tem corpo real a que
estejam unidos naturalmente. o que é necessário para a ressurreição. Logo, os sinais que Cristo mostrou
aos discípulos não eram suficientes para manifestar-lhe a ressurreição.

2. Demais. — Cristo ressurgiu glorioso, isto é. tendo a natureza humana, mas simultaneamente gloriosa.
Ora, certas manifestações fez Cristo aos discípulos, contrárias à natureza humana; tal o se lhes
desvanecer aos olhos e o entrar a ter com eles através de portas fechadas. E também eram contrárias à
glória certas outras, como o comer e beber e o conservar as cicatrizes das chagas. Logo, parece que as
referidas provas não eram suficientes nem convenientes a despertar a fé na ressurreição.

3. Demais. — O corpo de Cristo depois da ressurreição não era tal que pudesse se tocado pelos mortais;
por isso ele próprio disse a Madalena: Não me toques porque ainda não subi a meu Pai. Logo, não era
conveniente que, para manifestar a verdade da .sua ressurreição, se deixasse tocar pelos discípulos.

4. Demais. — Dentre os dotes do corpo glorificado o mais importante é a claridade. Ora, desse não tem
Cristo, na ressurreição, nenhuma prova. Logo, parece que insuficientes eram as referidas provas para
manifestar a qualidade da sua ressurreição.

5. Demais. — Os anjos apresentados como testemunhas da ressurreição a própria dissonância entre os
Evangelistas mostra que eram insuficientes. Assim, Mateus nos mostra o anjo sobre a pedra revolvida e
Marcos, no interior mesmo do monumento, quando as mulheres nele entraram. Além disso, esses dois
evangelistas nos falam de um só anjo; ao passo que João, de dois, sentados; e Lucas, de dois também,
mas de pé. Logo, parecem inconvenientes os testemunhos da ressurreição.
Mas, em contrário, Cristo que é a Sabedoria de Deus, dispõe todas as coisas com suavidade e
conveniência, na frase da Escritura.

SOLUÇÃO. — Cristo manifestou de dois modos a sua ressurreição: pelo testemunho e por provas ou
sinais. E arribas essas manifestações foram, no seu gênero, suficientes. Assim, serviu-se de duplo
testemunho para manifestar a ressurreição aos discípulos, e nenhum deles pode ser recusado. — O
primeiro foi o dos anjos, que anunciaram a ressurreição às mulheres, como o narram todos os
evangelistas. Outro é o testemunho das Escrituras, que ele próprio aduziu para provar a sua
ressurreição, como o relata o Evangelho. Quanto às provas, também foram suficientes para declarar a
sua verdadeira ressurreição, mesmo enquanto gloriosa. Ora, que a sua ressurreição foi verdadeira ele o
mostrou, primeiro, quanto ao seu corpo. Relativamente a esta três coisas manifestou. - Primeiro, que
era um corpo verdadeiro e real, e não um corpo fantástico ou rarefeito, como o ar. E isso o mostrou
deixando que o tocassem. Por isso, ele próprio o disse: Apalpai e vede, que um espírito não tem carne
nem ossos, como vós vedes que eu tenho. — Segundo. mostrou que tinha um corpo humano. deixando
verem os discípulos a sua verdadeira figura. que contemplavam com os olhos. — Terceiro, mostrou-lhes
que era o corpo identicamente o mesmo que antes tinha, mostrando-lhes as cicatrizes das chagas. —
Por isso diz, no Evangelho: Olha para as minhas mãos e pés, porque sou eu mesmo. De outro modo,
mostrou-lhes a verdade da sua ressurreição quanto à alma, de novo unida ao corpo. E isso, pelas
atividades de uma tríplice vida. — Primeiro, pela atividade da vida nutritiva, comendo e bebendo com os
discípulos, como lemos no Evangelho. — Segundo. pela atividade da vida sensitiva, quando respondia às
interrogações dos discípulos e saudava os presentes, mostrando assim que via e ouvia. - Terceiro, pela
atividade da vida intelectiva, pelo que os discípulos com ele falavam e discorriam sobre as Escrituras. E
para nada faltar a essa perfeita manifestação, revelou também a sua natureza divina pelo milagre feito
na pesca maravilhosa e, além disso, por ter subido ao céu à vista dos discípulos. Pois, como diz o
Evangelho, ninguém subiu ao céu senão aquele que desceu do céu, a saber, o Filho do homem,que está
no céu. E também manifestou a glória da sua ressurreição aos discípulos por ter entrado a eles, estando
as portas fechadas. Tal o que diz Gregório: O Senhor deu a tocar o seu corpo, que entrava estando as
portas fechadas, para mostrar que, depois da ressurreição, tinha a mesma natureza mas com uma glória
diferente. - Semelhantemente, também foi por uma propriedade da glória, que de súbito desapareceu-
Ihes de diante dos olhos, na frase do Evangelho; pois, assim mostrava que tinha o poder de deixar-se ver
ou não, e isso é uma propriedade do corpo glorioso, como dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora cada uma das provas, em particular, não
bastasse a manifestar a ressurreição de Cristo, contudo todas tomadas simultaneamente a manifestam
de modo perfeito, sobretudo pelo testemunho da Escritura, pelas palavras dos anjos e também pela
afirmação mesma de Cristo confirmada por milagres. Quanto aos anjos que apareceram, não afirmavam
que fossem homens como Cristo se afirmou verdadeiramente homem. — E contudo foi um o modo de
comer de Cristo e outro o do anjo. Pois, por não serem os corpos assumidos pelos anjos vivos ou
animados, não comeram eles verdadeiramente, embora na realidade triturassem os alimentos que iam
ter à parte interior do corpo assumido. Por isso o anjo disse a Tobias: Quando eu estava convosco, a vós
parecia-vos que eu comia e bebia convosco, mas eu sustento-me de um manjar invisível. Mas, como o
corpo de Cristo era verdadeiramente animado, comeu verdadeiramente. Pois, no dizer de Agostinho, o
corpo ressurrecto fica isento não do poder, mas da necessidade de comer. Donde o dizer Beda, Cristo
comeu por poder e não por necessidade.

RESPOSTA À SEGUNDA. — Como dissemos Cristo se serviu de várias provas para manifestar a sua
verdadeira natureza humana; e de certas outras para mostrar a glória de ressurrecto. Ora, a condição da
natureza humana, considerada em si mesma, no estado da vida presente, contraria à condição da glória,
segundo aquilo do Apóstolo: Semeia-se em vileza, ressuscitará em glória. Por onde, as provas para
manifestar o estado glorioso estão em oposição à natureza, não considerada absolutamente, mas ao
seu estado presente, e ao inverso. Por isso diz Gregório, que duas causas admiráveis o Senhor mostrou e
muito contraditórias aos olhos da razão humana: conservar, depois da ressurreição, o seu corpo
simultaneamente incorruptível e capaz de ser tocado.

RESPOSTA À TERCEIRA. — Como adverte Agostinho, o Senhor disse: Não me toques porque ainda não
subi a meu Pai, para que essa mulher figurasse a Igreja formada pelos gentios, que só acreditou em
Cristo quando ele subiu ao Pai. Ou quis Jesus que se acreditasse nele, isto é, que fosse tocado
espiritualmente, de modo a ser considerado na sua unidade com o Pai. Porque, no seu senso íntimo,
quem assim o considera, crê que de certo modo Cristo, subindo ao Pai, subiu a quem o reconhece como
seu igual. Ao passo que a mulher, chorando-o como homem, só carnalmente cria nele. Quanto ao que se
lê em outro lugar do Evangelho, que Maria o tocou, quando se lhe achegou, junto com outras mulheres,
e lhes abraçou os pés, não encerra isso nenhuma dificuldade, diz Severiano. Porque no primeiro caso
trata-se de uma figura e no segundo, do sexo; naquele da graça divina; neste, da natureza humana. —
Ou como o explica Crisóstomo, essa mulher queria tratar ainda o Cristo como se fosse antes da Paixão.
Invadida de atearia, esquecia-se da grandeza do seu Salvador; pois, o corpo de Cristo tinha-se, com
efeito, revestido de uma glória incomparável, depois de ressurrecto . Por isso lhe disse: Ainda não subi a
meu Pai, como se lhe dissesse: Não penses que ainda vivo uma vida mortal. Se ainda na terra me vês, é
porque inda não subi a meu Pai; mas dentro em pouco para ele subirei. E por isso acrescenta: Subo para
meu Pai e vosso Pai.

RESPOSTA À QUARTA. — Como diz Agostinho, o Senhor ressurgiu com seu corpo glorificado; mas não
quis aparecer assim glorioso aos discípulos, porque os olhos a ele não podiam suportar a grande glória.
Pois, antes de ter morrido por nós e ressurgido, quando foi da transfiguração no monte, já os discípulos
não no puderam contemplar; com maior razão não poderiam fitar o corpo do Senhor glorificado. -
Devemos também considerar que depois da ressurreição o Senhor queria sobretudo mostrar que era o
mesmo que tinha morrido. O que poderia ficar grandemente impedido se lhes manifestasse a glória do
seu corpo. Pois, as mudanças de figura são as que sobretudo revelam a diversidade do que vemos;
porque os sensíveis comuns, entre os quais se contam a unidade e a multiplicidade, ou a identidade e a
diversidade, a vista é a que sobretudo julga deles. Mas antes da Paixão a fim de que os discípulos não o
desprezassem pelas humilhações dela, quis Cristo mostrar-lhes a glória da sua majestade, revelada
principalmente pela glória do corpo, Por isso, antes da Paixão, manifestou aos discípulos a sua glória
refulgente; Iras, depois da ressurreição, por outros indícios.

RESPOSTA À QUINTA. — Como diz Agostinho, podemos, com Mateus e Marcos, entender que as
mulheres viram um anjo, supondo que o foi quando entraram no monumento, isto é, num certo espaço
cercado por um muro de pedras, e aí viram o anjo sentado na pedra revolvida do sepulcro, como refere
Mateus; isto é, sentado à direita, como requer Marcos. Em seguida, enquanto examinavam o lugar,
onde tinha jazido o corpo do Senhor, viram os dois anjos, primeiro, sentados, no dizer de João, e depois
levantados, de modo que pareciam estar de pé, como relata Lucas.