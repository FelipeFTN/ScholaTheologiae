# Questão 53: Da ressurreição de Cristo
Em seguida devemos tratar do concernente à exaltação de Cristo. E, primeiro, da sua ressurreição.
Segundo, da sua ascensão. Terceiro, do lugar que ocupa, sentado à direita do Pai. Quarto, do seu poder
judiciário. O primeiro ponto é susceptível de quatro questões. - Delas a primeira é sobre a ressurreição
mesma de Cristo. A segunda, sobre Cristo ressurgente. A terceira, sobre a manifestação da ressurreição.
A quarta, sobre a causa dela.
Na primeira discutem-se quatro artigos:

## Art. 1 — Se era necessário Cristo ressurgir.
O primeiro discute-se assim. — Parece que não era necessário Cristo ressurgir.

1. — Pois, diz Damasceno: Chama-se ressurreição ao fato de tornar a surgir um ser animado, que caiu e
se decompôs. Ora, Cristo não caiu por causa de nenhum pecado, nem o corpo se lhe decompôs, como
do sobredito se colhe. Logo, não podemos propriamente dizer que ressurgiu.

2. Demais. — Quem ressurge é levado a um estado mais alto, porque surgir é ser movido para cima. Ora,
o corpo de Cristo depois da morte permaneceu unido àdivindade e, portanto, não podia ser elevado a
um estado mais alto. Logo, não lhe cabia o ressurgir.

3. Demais. — Tudo o que sofreu a humanidade de Cristo se ordenava ànossa salvação. Ora, bastava à
nossa salvação a Paixão de Cristo, pela qual fomos livres da pena e da culpa, como do sobredito se
colhe. Logo, não era necessário que Cristo ressurgisse dos mortos.
Mas, em contrário, o Evangelho: Importava que Cristo sofresse e ressurgisse dos mortos.

SOLUÇÃO. — Era necessário que Cristo ressurgisse, por cinco razões. — Primeiro para a manifestação da
divina justiça, a qual compete exaltar aos que se humilham por amor de Deus, segundo aquilo do
Evangelho: Depôs do trono os poderosos e elevou os humildes. Tendo, pois, Cristo, levado da caridade e
da obediência, se humilhado até à morte da cruz, importava fosse exaltado por Deus até a ressurreição
gloriosa. Por isso a Escritura diz, da sua pessoa: Tu me conheceste, isto é, aprovaste ao assentar-me, isto
é, a glorificação na ressurreição, como o interpreta a Glosa. — Segundo, para ilustração da nossa fé.
Pois, a sua ressurreição confirmou a nossa fé na divindade de Cristo; porque, como diz o Apóstolo, ainda
que foi crucificado por enfermidade, vive todavia pelo poder de Deus. Donde o dizer ainda o Apóstolo:
Se Cristo não ressuscitou é vã a nossa pregação, é também vã a nossa fé. E noutro lugar diz a Escritura:
Que proveito há no meu sangue, i. é, na efusão do meu sangue, se desço à corrupção, como que por
degraus de males? Quase se respondesse: Nenhum. Pois, se não ressurgir logo e se me corromper o
corpo, a ninguém anunciarei, a ningué serei de proveito, como expõe a Glosa. — Terceiro, para
sustentar a nossa esperança. Pois, vendo Cristo ressurgir, ele que é nossa cabeça, esperamos que
também havemos de ressurgir. Donde o dizer o Apóstolo: Se se prega que Cristo ressuscitou dentre os
mortos, como dizem alguns entre vós outros que não há ressurreição de mortos? E noutro lugar da
Escritura: Eu sei, isto é, pela certeza da fé, que o meu Redentor, isto é, Cristo vive, tendo ressurgido dos
mortos, e portanto, eu no derradeiro dia surgirei da terra: esta minha esperança esta depositada no
meu peito. — Quarto, para nos dar um modelo pelo qual possamos regular a nossa vida, segundo aquilo
do Apóstolo: Como Cristo ressurgiu dos mortos pela glória do Padre, assim também nós andemos em
novidade de vida. E mais abaixo: Tendo Cristo ressurgido dos mortos, já não morre nem a morte terá
sobre ele mais domínio; assim também vós considerai-vos que estais certamente mortos ao pecado,
porém vivos para Deus. — Quinto, para complemento da nossa salvação. Pois, assim como sofreu tantos
males e morreu, para dos males nos livrar, assim também foi glorificado ressurgindo, para nos dar a
posse do bem, segundo aquilo do Apóstolo: Foi entregue por nossos pecados e ressuscitou para nossa
justificação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora Cristo não caísse por causa do pecado, caiu
contudo pela morte. Pois, assim com o pecado consiste em decair da justiça, assim a morte em decair da
vida. Por isso, podemos entender da pessoa de Cristo o lugar da Escritura: Não te alegres, inimiga
minha, a meu respeito, por eu ter caído - eu me tornarei a levantar. Semelhantemente, embora o corpo
de Cristo não se tivesse decomposto, reduzindo-se a cinzas, o fato mesmo porém de a alma ter-se
separado do corpo foi de certo modo uma decomposição.

RESPOSTA À SEGUNDA. — A divindade estava unida àcarne de Cristo, depois da morte, por uma união
pessoal; não porém por uma união de natureza, como a alma está unida ao corpo, como forma, para
constituir a natureza humana. E assim, por estar o corpo de Cristo unido àsua alma, foi elevado a um
estado mais alto da natureza, mas não a um estado mais alto da pessoa.

RESPOSTA À TERCEIRA. — A Paixão de Cristo obrou a nossa salvação propriamente falando, quanto à
libertação dos males; mas a ressurreição foi o começo e o penhor dos bens.

## Art. 2 — Se Cristo devia ressurgir no terceiro dia.
O segundo discute-se assim. — Parece que Cristo não devia ressurgir no terceiro dia.

1. — Pois, os membros devem harmonizar-se com a cabeça. Ora, nós, membros de Cristo, não
ressurgimos da morte no terceiro dia, senão que a ressurreição nos é diferida até o fim do mundo. Logo,
parece que Cristo, nossa cabeça, não devia ter ressurgido no terceiro dia, mas a ressurreição devia ter-
lhe sido diferida até o fim do mundo.

2. Demais. — Diz Pedro que era impossível ser Cristo prisioneiro do inferno e da morte. Ora, quem está
morto é prisioneiro da morte. Logo, parece que a ressurreição de Cristo não devia ser diferida até o
terceiro dia, mas devia ressurgir logo no mesmo dia. Sobretudo que a Glosa Supra referida diz:
Nenhuma utilidade haveria na efusão do sangue de Cristo, se não ressurgisse logo.

3. Demais. — O dia começa ao nascer do sol, que com a sua presença é a causa dele. Ora, Cristo
ressurgiu antes do nascer do sol, segundo o Evangelho: No primeiro dia da semana veio Maria Madalena
ao sepulcro de manhã, fazendo ainda escuro. E então já Cristo tinha ressurgido, conforme o diz a
continuação desse lugar do Evangelho: E viu que a tampa estava tirada do sepulcro. Logo Cristo não
ressurgiu no terceiro dia.
Mas, em contrário, o Evangelho: Entrega-lo-ão aos gentios para ser escarnecido e açoitado e crucificado,
mas ao terceiro dia ressurgirá

SOLUÇÃO. — Como se disse, a ressurreição ele Cristo era necessária para a ilustração da nossa fé. Ora, a
nossa fé tem por objeto tanto a divindade como a humanidade de Cristo; pois, não basta crer numa sem
crer na outra, como do sobredito se colhe. Por onde, para que se confirmasse a nossa fé na verdade da
sua divindade, era necessário ressurgisse logo, nem lhe fosse diferida a ressurreição até ao fim do
mundo. Mas, para que fosse confirmada a fé na verdade da sua humanidade e da sua morte, era
necessário houvesse um intervalo entre a morte e a ressurreição. Se, ao contrário, tivesse ressurgido
imediatamente depois da morte poderia parecer que não tinha verdadeiramente morrido, e por
consequência que também não era verdadeira a sua ressurreição. Ora para manifestar a verdade da
morte de Cristo, bastava que a sua ressurreição fosse diferida até ao terceiro dia; pois, não é necessário,
que um homem aparentemente morto manifeste, dentro desse tempo, quaisquer sinais de vida. — E
também o fato de ter ressurgido no terceiro dia proclama a perfeição do número três, número próprio
de todas as causas, por ter princípio, meio e fim, como diz Aristóteles. - E mostra ainda
misteriosamente, que Cristo, com a morte única do seu corpo, que foi uma luz, por causa da sua justiça,
destruiu as nossas duas mortes - a do corpo e a da alma, envoltas nas trevas, do pecado. Por isso Cristo
permaneceu morto um dia inteiro e duas noites como diz Agostinho. - E além disso significa que com a
ressurreição de Cristo começava o terceiro tempo. Pois, o primeiro foi o anterior àlei; o segundo, o da
lei; o terceiro, o da graça. — Enfim, com a ressurreição de Cristo começou o terceiro estado dos Santos.
Pois, o primeiro foi o figurado, sob a lei; o segundo, o da realidade da fé; o terceiro será o da eternidade
da glória, que começou com a ressurreição de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A cabeça e os membros harmonizam-se pela natureza,
mas não pela virtude; pois, a virtude da cabeça é mais excelente que a dos membros. Por isso, para
manifestar a excelência da virtude de Cristo, devia ele ressurgir no terceiro dia, sendo a ressurreição dos
demais dilatada a ao fim do mundo.

RESPOSTA À SEGUNDA. — A prisão implica uma coação. Ora, Cristo não estava adstrito a nenhuma
necessidade que lhe a morte tivesse imposto; mas era livre entre os mortos. Por isso, permaneceu
algum tempo morto, não como prisioneiro da morte, mas por vontade própria, enquanto o julgava
necessário para a ilustração de nossa fé. Pois, dizemos que se realiza imediatamente o que se faz com
breve interpolação de tempo.

RESPOSTA À TERCEIRA. — Como dissemos, Cristo ressuscitou pela alta, quando já iluminava o dia, para
significar que mediante a sua ressurreição nos conduzia àluz da glória. Assim como morreu quando já o
dia entardecia e declinava para as trevas, a fim de mostrar que pela sua morte destruiria as trevas da
culpa e da pena. E contudo se diz, que ressurgiu no terceiro dia, tomando esta palavra pelo dia natural,
que abrange o espaço de vinte e quatro horas. E, no dizer de Agostinho, a noite, até o dilúculo em que
se deu a ressurreição do Senhor, pertence ao terceiro dia. Pois, Deus mesmo, ordenando que das trevas
resplandecesse a luz, a fim de que pela graça do Novo Testamento e pela participação da ressurreição
de Cristo, pudéssemos nos aplicar as palavras do Apóstolo — Noutro tempo éreis trevas, mas agora sais
luz no Senhor — Deus mesmo nos insinua de certo modo que o dia começa pela noite. Assim pois como
os primeiros dias da criação se contavam a partir da luz até a noite, por causa da queda futura do
homem, assim no caso vertente, por causa da redenção, os dias se contam partindo das trevas à luz. —
Por onde é claro, que ainda que tivesse ressurgido à meia noite, poderíamos dizer que ressurgiu no
terceiro dia, entendendo-se este como dia natural. Mas, como na verdade ressurgiu no dilúculo,
podemos dizer que ressurgiu no terceiro dia, mesmo considerando este como dia artificial, causado pela
presença do sol; porque já o sol começava a iluminar o ar. Por isso S. Marcos diz, que as mulheres
chegaram ao sepulcro, quando já o sol era nascido. O que não encontra o dito de João, segundo o
explica Agostinho: pois, no surgir do dia, as trevas remanescentes tanto mais se dissipam quanto mais se
intensifica a luz; por onde, o dito de Marcos - já o sol era nascido - não devem.os entendê-la como se
esse astro já estivesse acima do horizonte, mas significam somente que ia aparecer logo.

## Art. 3 — Se Cristo foi o primeiro que ressurgiu.
O terceiro discute-se assim. — Parece que Cristo não foi o primeiro que ressurgiu.

1. — Pois, lemos no Antigo Testamento que Elias e Eliseu fizeram ressurgir certos, como o diz o
Apóstolo: As mulheres recobraram os seus filhos mortos por meio de ressurreição. Semelhantemente
Cristo, antes da sua Paixão, ressuscitou três mortos. Logo, Cristo não foi o primeiro dos rescritos.

2. Demais. — O Evangelho, entre os outros milagres que se deram na Paixão de Cristo, narra que se
abriram as sepulturas e muitos corpos de santos, que eram mortos, ressurgiram. Logo, Cristo não foi o
primeiro dos ressurrectos.

3. Demais. — Assim como Cristo, pela sua ressurreição é a causa da nossa, assim pela sua graça é a
causa da nossa graça, segundo aquilo do Evangelho: Todos nós participamos da sua plenitude. Ora,
outros, como todos os Patriarcas do Antigo Testamento, tiveram a graça antes de Cristo. Logo, tiveram
também a ressurreição do corpo, antes de Cristo.
Mas, em contrário, o Apóstolo: Cristo ressuscitou dentre os mortos, sendo ele as primícias dos que
dormem. Ao que diz a Glosa: Porque ressurgiu antes, no tempo, e em dignidade.

SOLUÇÃO. — A ressurreição consiste em um morto retomar à vida. Ora, de dois modos pode alguém ser
retomado à morte: ou de uma morte atual, como quando recomeça simplesmente a viver, depois de ter
morrido; ou quando fica livre não só da morte, mas também da necessidade, e o que é mais, da
possibilidade de morrer. E esta é a verdadeira e perfeita ressurreição. Porque, enquanto vivemos
sujeitos à necessidade de morrer, de certo modo a morte nos domina, segundo aquilo do Apóstolo: O
corpo verdadeiramente está morto pelo pecado. Ora, o que existe como possível existe de certo modo,
isto é, potencialmente. Por onde é claro, que a ressurreição pela qual alguém é retomado somente à
uma morte atual é uma ressurreição imperfeita. — Assim, pois, falando-se da ressurreição perfeita,
Cristo foi o primeiro que ressurgiu, porque ele foi o primeiro que, ressurgindo, chegou à vida
perfeitamente imortal, segundo o Apóstolo: Tendo Cristo ressurgido dos mortos, já não morre. Mas, por
uma ressurreição imperfeita certos outros ressurgiram, antes de Cristo, para serem uma como indicação
prévia da ressurreição do mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pois também os que ressurgiram como o narra o Antigo
Testamento, e os ressurgidos por Cristo, voltaram à vida mas ficando sujeitos a morrerem de novo.

RESPOSTA À SEGUNDA. — Há dupla opinião referente aos que ressurgiram com Cristo. Assim, uns
afirmam que, voltando àvida, ficaram livres de tornar a morrer; pois, o morrerem de novo ser-Ihes-ia
maior tormento que não terem ressurgido. E tal é o sentido que se deve dar, segundo Jerônimo, àquele
lugar: Não ressurgiram antes de o Senhor ter ressurgido. E por isso diz o evangelista: Saindo das
sepulturas depois da ressurreição de Jesus, vieram à cidade santa e apareceram a muitos. Mas
Agostinho, referindo essa opinião, diz: Sei que há certos de opinião, que os justos, ressuscitados na
ocasião da morte de Nosso Senhor Jesus Cristo, se encontraram desde logo em todas as condições da
ressurreição última. Mas se não depuseram o novo corpo, para reentrarem no sono do túmulo,
pergunto como se entende o dito que Cristo é o primogênito dentre os mortos, se tantos outros
ressuscitaram antes dele. Responderão que o evangelista antecipou, falando do segundo fato, de modo
que devamos entender o lugar citado no sentido que os túmulos se abriram por ocasião do tremor de
terra, quando Cristo expirou na cruz, mas que os justos, de que se trata, só depois de ter Cristo
ressuscitado é que ressurgiram. Mas, então, resta outra dificuldade: como S. Pedro, querendo provar
aos judeus, que não a Davi mas a Cristo, era referente a predição que a sua carne não viria a corrupção,
faz-lhes observar que o túmulo desse rei se via ainda entre eles? Pois, não podia convencê-los com essa
razão, se o corpo de Davi já no túmulo não estava. Porque, ainda mesmo que Davi tivesse ressuscitado
pouco tempo depois da sua morte, e que o seu corpo não tivesse sofrido a corrupção, poderia contudo
ainda existir o seu túmulo. Entretanto, supondo que esses justos ressurgindo alcançaram uma vida
imortal, é duro pensar que Davi não foi do número deles, apesar de considerarmos como um título de
glória para Cristo o ter nascido da raça de Davi. E também será difícil entender-se o que o Apóstolo diz
aos Hebreus, dos justos do Velho Testamento — Para que eles, sem nós não fossem consumados - se já
por efeito dessa ressurreição foram constituídos no estado de incorruptibilidade, que nos é prometido
no fim dos tempos, como nossa perfeição. Por onde, Agostinho é de opinião que ressurgiram, mas para
morrer de novo. Com o que também concorda o dito de Jerônimo: Assim como Lázaro ressurgiu, assim
também muitos corpos de santos, para mostrarem que o Senhor deveras ressurgiu. Embora, num
Sermão, deixe o assunto duvidoso. As razões de Agostinho porém parecem muito mais concludentes.

RESPOSTA À TERCEIRA. — Assim como o que precedeu o advento de Cristo foi preparatório da sua
vinda, assim a graça é uma disposição para a glória. Por onde, o que pertence àglória, tanto quanto à
alma - tal o perfeito gozo de Deus - como quanto ao corpo — e tal é a ressurreição gloriosa, tudo isso
Cristo devia tê-la com anterioridade no tempo, como sendo o autor da glória. No concernente àgraça,
convinha existisse ela primeiro nos que para Cristo se ordenavam.

## Art. 4 — Se Cristo foi à causa da sua ressurreição.
O quarto discute-se assim. — Parece que Cristo não foi a causa da sua ressurreição.

1. — Pois, quem é ressuscitado por outro não é a causa da sua ressurreição. Ora, Cristo foi ressuscitado
por outro, segundo o Evangelho: Ao qual Deus ressuscitou, soltas as dores do inferno. E o Apóstolo:
Aquele que ressuscitou dos mortos a Jesus Cristo também dará vida aos vossos corpos mortais, etc.
Logo, Cristo não é a causa da sua ressurreição.

2. Demais. — Quem pede uma causa a outro não dizemos que a merece nem que dela é causa. Ora,
Cristo com a sua Paixão mereceu a ressurreição; assim, como diz Agostinho, as humilhações da Paixão
mereceram a glória da ressurreição. E também pediu ele ao Pai lhe concedesse a ressurreição, segundo
aquilo da Escritura: Tu, pois, Senhor, tem compaixão de mim e ressuscita-me. Logo, Cristo não foi a
causa da sua ressurreição.

3. Demais. — Como o prova Damasceno, quem ressurge não é a alma, mas o corpo ferido pela morte.
Ora, o corpo não pode unir a si a alma, mais nobre que ele. Logo, oque em Cristo ressurgiu não podia ser
a causa da sua ressurreição.
Mas, em contrário, o Senhor diz: Ninguém tira de mim a minha alma, mas eu de mim mesmo a ponho e
tenho o poder de a reassumir. Ora, ressurgir não é senão assumir de novo a alma. Logo, parece que
Cristo ressurgiu por virtude própria.

SOLUÇÃO. — Como dissemos, pela morte não ficou separada a divindade nem da alma nem do corpo de
Cristo. Ora, tanto a alma de Cristo morto, como o seu corpo podem ser considerados a dupla luz: em
razão da divindade e em razão da natureza mesma criada. - Segundo, pois, a virtude da divindade que
lhe estava unida tanto o corpo reassumiu a alma, que depuzara, como a culpa reassumiu o corpo, que
demitira. E tal o diz o Apóstolo, de Cristo: Ainda que foi crucificado por enfermidade, vive todavia pelo
poder de Deus. - Se porém considerarmos o corpo e a alma de Cristo morto, quanto à virtude da
natureza criada, então não podiam ser reunidos um àoutra, mas era mister fosse Cristo ressuscitado
por Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O mesmo é a virtude divina que a obra do Pai e do Filho.
Por onde, Cristo ressuscitou tanto pela virtude divina do Pai, como pela sua própria.

RESPOSTA À SEGUNDA. — Cristo, orando, pediu e mereceu a sua ressurreição, enquanto homem, mas
não como Deus.

RESPOSTA À TERCEIRA. — O corpo, pela sua natureza criada, não tem maior poder que a alma de Cristo;
mais poderoso é que ela porém, por virtude divina. Mas a alma, por sua vez, pela divindade que lhe
estava unida, tem maior poder que o corpo na sua natureza criada. E assim, segundo a virtude divina, o
corpo e a alma se reassumiram mutuamente, mas não segundo a virtude da natureza criada.