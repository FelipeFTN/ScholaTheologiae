# Questão 82: Do ministro deste sacramento
Em seguida devemos tratar do ministro deste sacramento.
E nesta questão discutem-se dez artigos:

## Art. 1 — Se a consagração deste sacramento é própria do sacerdote.
O primeiro discute-se assim. — Parece que a consagração deste sacramento não é própria do
sacerdote.

1. — Pois, como se disse, este sacramento é consagrado em virtude de palavras, que são a forma dele.
Ora, essas palavras não se mudam quer pronunciadas pelo sacerdote, quer por qualquer outro. Logo,
parece que nem só o sacerdote, mas qualquer outro pode consagrar este sacramento.

2. Demais. — O sacerdote celebra este sacramento em nome de Cristo. Ora, um leigo santo está unido a
Cristo pela caridade. Logo, parece que também um leigo, pode consagrá-lo. Por isso Crisóstomo diz, que
todo santo é sacerdote.

3. Demais. — Assim como o batismo se ordena à nossa salvação, assim este sacramento, como se disse.
Ora, também um leigo pode batizar, conforme foi dito. Logo, não é próprio do sacerdote celebrar este
sacramento.

4. Demais. — Este sacramento se consuma pela consagração da matéria. Ora, consagrar as outras
matérias - o crisma, os santos óleos e o óleo bento - só o pode o bispo. E, contudo essa consagração não
tem a mesma dignidade, que a da Eucaristia, na qual está todo Cristo. Logo, não é próprio do sacerdote,
mas só do bispo celebrar este sacramento.
Mas, em contrário, Isidoro diz e está nas Decretais: É próprio do presbítero celebrar no altar o
sacramento do corpo e do sangue do Senhor.

SOLUÇÃO. — Como dissemos, este sacramento tem tão grande dignidade que não é celebrado senão
em nome de Cristo, Mas quem age em nome de outrem há-de fazê-lo por poder que lhe tenha sido por
este conferido. Ora, assim como ao batizado é conferido por Cristo o poder de receber este sacramento,
assim, ao sacerdote, quando ordenado, o poder de consagrá-lo em nome de Cristo. Pois, assim, é
colocado na posição daqueles a quem foi dito: Fazei isto em memória de mim. Por onde, devemos
concluir, que é próprio do sacerdote celebrar este sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A virtude sacramental tem vários elementos e não um
só; assim como a virtude do batismo está nas palavras da forma e na água. Por onde e do mesmo modo,
a virtude consagrativa não está só nas palavras mas também no poder conferido ao sacerdote, quando
ao ordenar-se lhe diz o bispo: Recebe o poder de oferecer na Igreja o sacrifício tanto pelos vivos como
pelos mortos. Assim, da virtude instrumental são dotados os vários instrumentos pelos quais age o
agente principal.

RESPOSTA À SEGUNDA. — O leigo justo está unido a Cristo pela união espiritual da fé e da caridade,
mas não pelo poder sacramental. Por isso tem o sacerdócio espiritual para oferecer hóstias espirituais,
das quais diz a Escritura: Sacrifício para Deus é o espírito atribulado. E noutro lugar: Oferecei os vossos
corpos como uma hóstia viva. E ainda: Em sacerdócio santo, para oferecer sacrifícios espirituais.

RESPOSTA À TERCEIRA. — A recepção deste sacramento não é de tanta necessidade como a do
batismo, segundo do sobre dito se colhe. E por isso, embora em artigo de necessidade, um leigo possa
batizar, não pode contudo celebrar este sacramento.

RESPOSTA À QUARTA. — O' bispo recebe o poder de agir em nome de Cristo sobre o seu corpo místico,
isto é, sobre a Igreja; poder esse que não recebe o sacerdote na sua ordenação, embora possa tê-lo por
delegação do bispo. Por isso, o não concernente ao corpo místico não é reservado ao bispo, como a
consagração deste sacramento. Ao bispo porém pertence conferir, não só ao povo, mas também aos
sacerdotes, aquilo de que podem usar por ofício próprio. E como a bênção do crisma, dos santos óleos,
do óleo dos enfermos e do mais que é consagrado - por exemplo, do altar, da igreja, das vestes e dos
vasos - confiram uma certa idoneidade para celebrar os sacramentos - o que pertence ao ofício do
sacerdote, por isso essas consagrações são reservadas ao bispo como ao chefe de toda a ordem
eclesiástica.

## Art. 2 — Se vários sacerdotes podem consagrar uma mesma hóstia.
O segundo discute-se assim. — Parece que vários sacerdotes não podem consagrar uma mesma
hóstia.
1 - Pois, como dissemos vários não podem batizar um só. Ora, não menos poder tem o sacerdote
quando consagra, que quando batiza. Logo, também não podem vários sacerdotes consagrar
simultaneamente uma mesma hóstia.

2. Demais. — O que pode ser feito por um só é inútil fazer-se por muitos; pois, nada deve haver de
supérfluo nos sacramentos. Logo, como um só sacerdote basta para consagrar, parece que vários não
podem consagrar uma mesma hóstia.

3. Demais. — Como diz Agostinho, este sacramento é o sacramento da unidade. Ora, o contrário da
unidade é multidão. Logo, não parece conveniente a este sacramento que muitos sacerdotes consagrem
uma mesma hóstia.
Mas, em contrário, segundo o costume de certas igrejas, os sacerdotes ordenados de novo celebram
conjuntamente com o bispo, que os ordenou.

SOLUÇÃO. — Como dissemos, o sacerdote, quando se ordena, é equiparados aos que receberam do
Senhor na Ceia, o poder de consagrar. Por isso, segundo o costume de várias igrejas, assim como os
Apóstolos cearam juntamente com Cristo, assim os recém-ordenados celebram com o bispo que os
ordenou. Mas nem por isso se reitera a consagração sobre a mesma hóstia, porque, como diz Inocêncio

III, a intenção de todos deve concentrar-se no instante mesmo da consagração.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não lemos no Evangelho, que Cristo batizasse
simultaneamente com os Apóstolos quando lhes cometeu o poder de batizar. Logo, não há semelhança
de razões.

RESPOSTA À SEGUNDA. — Se cada sacerdote obrasse por virtude própria, seria inútil os outros
celebrarem, desde que bastava um para fazer. Mas como os sacerdotes consagram tão somente em
nome de Cristo, e muitos são um só em Cristo, não importa por isso se este sacramento é consagrado
por um só ou por muitos, contanto, e isso é o necessário, que observem o rito da Igreja.

RESPOSTA À TERCEIRA. — A Eucaristia é o sacramento da unidade eclesiástica, cujo fundamento é
constituírem todos uma unidade em Cristo.

## Art. 3 — Se cabe só aos sacerdotes a dispensação deste sacramento.
O terceiro discute-se assim. — Parece que não cabe só aos sacerdotes a dispensação deste
sacramento.

1. — Pois, deste sacramento não faz menos porte o sangue que o corpo de Cristo. Ora, o sangue de
Cristo é dispensado pelos diáconos, por isso S. Lourenço disse a S. Sixto: Experimenta se escolheste um
ministro idôneo a quem cometeste a dispensação do corpo do Senhor. Logo, e pela mesma razão, a
dispensação do corpo de Cristo não cabe só aos sacerdotes.

2. Demais. — Os sacerdotes são constituídos ministros dos sacramentos. Ora, este sacramento se
consuma na consagração da matéria, e não no uso, que é o objeto da dispensação. Logo, parece que
não cabe ao sacerdote dispensar o corpo do Senhor.

3. Demais. — Dionísio diz que este sacramento tem uma virtude perfectiva, assim como o crisma. Ora,
assinalar com o crisma o batizado não pertence ao sacerdote, mas ao bispo. Logo, também dispensar
este sacramento pertence ao bispo e não ao sacerdote.
Mas, em contrário, dispõe um cânone: Chegou ao nosso conhecimento que certos presbíteros entregam
o corpo do Senhor a um leigo ou a uma mulher, para o levarem aos enfermos. Por isso o Sinodo interdiz
que não se ouse mais proceder assim para o futuro; mas o próprio presbítero é quem deve, por mãos
próprias, dar a comunhão aos doentes.

SOLUÇÃO. — Ao sacerdote pertence a dispensação do corpo de Cristo, por três razões. - Primeiro,
porque, como dissemos, ele consagra em nome de Cristo. Ora, o próprio Cristo, assim como consagrou o
seu corpo na Ceia, assim o deu a tomar aos outros. Por onde, assim como ao sacerdote pertence a
consagração do corpo de Cristo, assim também lhe cabe dispensá-lo. - Segundo, porque o sacerdote é
constituído mediatário entre Deus e o povo. Portanto, assim como lhe cabe oferecer a Deus os dons do
povo, assim também lhe pertence dispensar ao povo os dons santificados por Deus. - Terceiro. - porque
a reverência devida a este sacramento requer que não seja tocado senão pelo que é consagrado; por
isso é consagrado o corporal e o cálice e consagradas são as mãos do sacerdote, para tocá-lo. E ninguém
o pode tocar senão em caso de necessidade; por exemplo, se caísse no chão ou em outro caso
semelhante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O diácono quase próximo da ordem sacerdotal, de certo
modo participa-lhe do ofício, porque pode dispensar o sangue de Cristo, mas não o corpo, senão em
caso de necessidade e por ordem do bispo ou do presbítero. - Primeiro, porque o sangue de Cristo está
contido num vaso. E por isso não é necessário seja tocado por quem o dispensa, ao contrário do que se
dá com o corpo de Cristo. - Segundo, porque o sangue designa redenção, derivada de Cristo para o
povo; por isso se lhe mistura a água, símbolo do povo. E sendo o diácono o mediatário entre o sacerdote
e o povo, pertence-lhe dispensar, antes, o sangue que o corpo de Cristo.

RESPOSTA À SEGUNDA. — Ao mesmo que pertence dispensar este sacramento pertence também
consagrá-lo, pela razão aduzida.

RESPOSTA À TERCEIRA. — Assim como o diácono de certo modo participa da virtude iluminativa do
sacerdote, por dispensar o sangue de Cristo, assim também o sacerdote participa da dispensação
perjectiva do bispo, por dispensar este sacramento, pelo qual o homem se aperfeiçoa em si mesmo,
tornando-se semelhante a Cristo. Quanto as outras perfeições, que aperfeiçoam o homem nas suas
relações com os seus semelhantes, o dispensá-las é reservado ao bispo.

## Art. 4 — Se o sacerdote, que consagra, esta obrigado a tomar este sacramento.
O quarto discute-se assim. — Parece que o sacerdote que consagra, não está obrigado a tomar este
sacramento.

1. — Pois, nas outras consagrações, quem consagra a matéria dela não usa; assim, o bispo consagra o
crisma, mas não se unge com ele. Ora, este sacramento consiste na consagração da matéria. Logo, o
sacerdote que o celebra não há-de necessariamente usar dele, mas lhe é lícito abster-se de receber.

2. Demais. — Nos outros sacramentos o ministro não confere a si mesmo o sacramento; assim, ninguém
pode batizar-se a si próprio, como se estabeleceu. Ora, como o batismo é dispensado numa certa
ordem, assim também este sacramento. Logo, o sacerdote que o celebra não o deve receber de si
mesmo,

3. Demais. — Sucede às vezes milagrosamente o aparecer o corpo de Cristo no altar sob a espécie de
carne, e o sangue, sob a de sangue; Ora, essas espécies não são como tais, susceptíveis de ser comidas e
bebidas; e é a razão de serem dispensadas sob outra forma, para não repugnarem aos que as tomam.
Logo, o sacerdote que consagra nem sempre está obrigado a receber este sacramento.
Mas, em contrário, no Concilio Toledano (XII) se lê, e é uma disposição canônica: Devemos admitir
absolutamente que tantas vezes quantas o sacerdote imola no altar o corpo e o sangue de N. S. J. Cristo,
outras tantas deve participar do corpo e do sangue de Cristo.

SOLUÇÃO. — Como dissemos a Eucaristia não só é sacramento, mas também sacrifício. Ora, todo aquele
que oferece um sacrifício deve fazer-se dele participante. Porque o sacrifício exteriormente oferecido é
sinal do sacrifício interior, pelo qual nos oferecemos a nós mesmos a Deus, como diz Agostinho. Por
onde, o sacerdote, participando do sacrifício mostra que se oferece interiormente em sacrifício.
Semelhantemente, dispensado o sacrifício do povo, também mostra ser o dispensador dos bens divinos.
Dos quais deve ser ele o primeiro participante, como o diz Dionísio. E por isso deve recebê-lo antes de o
dispensar ao povo. Por isso se lê também no referido concilio: Que sacrifício é esse, do qual não vemos
participar nem o próprio sacrificante? Ora, tornar-se participante, comendo da vítima, segundo àquilo
do Apóstolo: Os que comem as vítimas porventura não têm parte com o altar? Por onde e
necessàriamente, o sacerdote, sempre que consagra, deve receber este sacramento na sua
integralidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A consagração do crisma ou de qualquer outra matéria,
não é sacrifício, como o é a consagração da Eucaristia. Por onde, não há semelhança de razões.

RESPOSTA À SEGUNDA. — O sacramento do batismo tem a sua plenitude no uso mesmo da matéria.
Por isso ninguém pode batizar-se a si mesmo; porque no sacramento não pode o agente identificar-se
com o paciente. Por onde, nem neste sacramento o sacerdote se consagra a si mesmo, mas, o pão e o
vinho, em cuja consagração se consuma a Eucaristia. Mas, o uso do sacramento é-lhe conseqüente a
este. Portanto, o símile não colhe.

RESPOSTA À TERCEIRA. — Se milagrosamente aparecer o corpo de Cristo no altar, sob a espécie de
carne, ou o sangue, sob a de sangue, não devem ser tomados. Assim, diz Jerônimo: Por certo é licito
comer da hóstia milagrosamente consagrada em comemoração de Cristo; mas de nenhum modo é
permitido comer aquela mesma, que Cristo ofereceu no altar da cruz. Mas nem por isso o sacerdote
transgride a lei; pois, fatos milagrosos não estão sujeitos à lei. Contudo, dever-se-ia aconselhar ao
sacerdote que consagrasse e recebesse reiteradamente o corpo e o sangue do Senhor.

## Art. 5 — Se um mau sacerdote pode consagrar a Eucaristia.
O quinto discute-se assim. — Parece que um mau sacerdote não pode consagrar a Eucaristia.

1. — Pois, diz Jerônimo: Os sacerdotes, que dispensam a Eucaristia e distribuem ao povo o sangue do
Senhor, agem impiamente contra a lei de Cristo, pensando atribuir a consagração desse sacramento às
palavras e não à vida do celebrante; e pensando ser necessariamente a solenidade da oração, e não à
vida do sacerdote. E desses sacerdotes se diz: O sacerdote, que tiver qualquer pecado, não ouse fazer
oblações ao Senhor. Ora, o sacerdote pecador, manchado pelo pecado, nem vive uma vida nem tem
méritos condicentes com este sacramento. Logo, o sacerdote pecador não pode consagrar a Eucaristia.

2. Demais. — Damasceno diz, que o pão e o vinho, sobrenaturalmente se transforma no corpo e no
sangue do Senhor, por virtude do Espírito Santo. Ora, Gelásio Papa (I) diz e está nas Decretais: Como o
Espírito celeste invocado descerá, à consagração do divino mistério, se o sacerdote, que lhe depreca a
presença, se apresenta maculado de atos pecaminosos? Logo, um mau sacerdote não pode consagrar a
Eucaristia.

3. Demais. — Este sacramento é consagrado pela bênção do sacerdote. Ora, a bênção do sacerdote
pecador não é eficaz para a consagração dele, segundo aquilo da Escritura: Eu amaldiçoarei as vossas
bênçãos, e Dionísio diz: Decai totalmente da ordem sacerdotal quem não é iluminado; e o considero
como soberanamente audacioso, se ousar por a mão sobre as causas sacerdotais e pronunciar, em
nome de Jesus Cristo, sobre os divinos símbolos, não direi orações, mas imundas infâmias.
Mas, em contrário, Agostinho: Na Igreja Católica, a consagração do mistério do corpo e do sangue do
Senhor não resulta, em nada melhor, das palavras de um bom sacerdote, que das de um sacerdote mau;
porque não se opera pelo mérito do consagrante, mas pela palavra do Criador e por virtude do Espírito
Santo.

SOLUÇÃO. — Como dissemos, o sacerdote consagra este sacramento, não por virtude própria, mas
como ministro de Cristo, em cujo nome consagra a Eucaristia mas, nem por ser mau um ministro de
Cristo deixa de o ser; pois, o Senhor tem bons e maus ministros ou servos. Assim, lemos no Evangelho:
Quem crês que é o servo fiel e prudente? E acrescenta: Se aquele servo sendo mau disser no meu
coração, etc. E o Apóstolo diz: Os homens devem-nos considerar como uns ministros de Cristo. Mas
acrescenta: De nada me argüi a consciência, mas nem por isso me dou por justificado. Logo, era certo
ser ele ministro de Cristo, mas não tinha a certeza de ser justo. Portanto, pode um ser ministro de
Cristo, mesmo sem ser justo. E isso revela a excelência de Cristo, a quem, como a verdadeiro Deus, serve
não só o bem mas ainda o mal, que a divina providência faz redundar em glória de Deus. Por onde é
manifesto que os sacerdotes mesmo não sendo justos, mas pecadores, podem consagrar a Eucaristia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Jerônimo, com as palavras citadas, refuta o erro dos
sacerdotes que julgavam poder consagrar dignamente a Eucaristia, pelo só facto de serem sacerdotes,
mesmo sendo pecadores. E Jerônimo os refuta lembrando que os maculados pelo pecado eram
proibidos de subir aos altares. Mas não o eram a ponto de se o fizessem não poderem verdadeiramente
de oferecer o sacrifício.

RESPOSTA À SEGUNDA. — Antes das palavras citadas, Gelásio Papa tinha dito: A sacrosanta religião,
que contém a disciplina católica requere uma tão grande reverência que ninguém ouse querer achegar-
se a ela senão com consciência pura. Donde resulta manifestamente, que era sua intenção dizer que o
sacerdote pecador não deve celebrar este sacramento. E quando acrescenta - Como o Espírito celeste
invocado descerá? - devemos entender que o Espírito celeste não desce por mérito do sacerdote, mas
por virtude de Cristo, cujas palavras o sacerdote profere.

RESPOSTA À TERCEIRA. — Assim como uma mesma ação pode ser má, quando feita por má intenção do
ministro, e boa quando praticada pela boa intenção do Senhor, assim a bênção do sacerdote pecador,
enquanto procedente dele indignamente, é digna de maldição e é reputada como infâmia ou blasfêmia
e não como oração; mas é santa e eficaz enquanto proferida em nome de Cristo. Por isso a Escritura diz
sinaladamente: Eu amaldiçoarei as vossas bênçãos.

## Art. 6 — Se a missa do sacerdote mau vale menos que a de um bom.
O sexto díscute-se assim. — Parece que a missa de um sacerdote mau não vale menos que a de um
bom.

1. — Pois, diz Gregório: Oh! Em quão grande engano caem os que pensam que os divinos e ocultos
mistérios podem ser mais santificados pelos outros, quando é o mesmo e único Espírito Santo quem
santifica esses mistérios pela sua ação oculta e invisível. Ora, esses mistérios ocultos são os celebrados
na missa. Logo, a missa de um mau sacerdote não vale menos que a de um bom.

2. Demais. — Assim como o batismo é conferido pelo ministro em virtude de Cristo que batiza, assim
também este sacramento é consagrado em nome de Cristo. Ora, um batismo não vale mais por ser
conferido por um ministro melhor, como se disse. Logo nem vale mais uma missa por ser celebrada por
um sacerdote melhor.

3. Demais. — Assim como os sacerdotes diferem por terem bom ou melhor mérito, assim também pelo
bem e pelo mal. Se pois, a missa de um sacerdote melhor é melhor, segue-se que é má a de um
sacerdote mau. Ora, isso é inadmissível, porque a malícia dos ministros não pode redundar nos
mistérios de Cristo, como diz Agostinho. Logo, nem é melhor a missa de um sacerdote melhor.
Mas, em contrário - Quanto mais dignos forem os sacerdotes, tanto mais facilmente são ouvidos nas
necessidades pelas quais rezam.

SOLUÇÃO. — Duas coisas podemos considerar na missa: o sacramento em si mesmo, que é a principal: e
as orações nela rezadas pelos vivos e pelos mortos. - Quanto, pois, ao sacramento, não vale menos a
missa de um sacerdote mau que a de um bom, pois, ambos celebram o mesmo sacramento. Também
relativamente às orações rezadas na missa, duas coisas podemos considerar. Primeiro, quanto à eficácia
que tiram da devoção do sacerdote que as reza. E então não há dúvida que a missa de um sacerdote
melhor é mais frutuosa. - Depois, quanto ao facto de o sacerdote proferi-las em nome de toda a Igreja,
da qual é ministro. Ora, esse ministério podem exercê-la mesmo os sacerdotes pecadores, como acima
dissemos ao tratar do ministério de Cristo. E por aí é frutuosa não só a oração do sacerdote pecador na
missa, mas também todas as orações que reza nos ofícios eclesiásticos, onde representa a pessoa da
Igreja. Mas, as suas orações privadas não são frutuosas, segundo aquilo da Escritura: D'aquele que
desvia os seus ouvidos para não ouvir a lei, a mesma oração será execrável.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Gregório se refere à santidade do divino sacramento.

RESPOSTA À SEGUNDA. — No sacramento do batismo não se fazem, como na missa. Orações solenes
por todos os fiéis. Portanto, por ai o símile não colhe. Mas sim, quanto ao efeito do sacramento.

RESPOSTA À TERCEIRA. — A virtude do Espírito Santo, que pela unidade da caridade põe em comum os
bens dos membros de Cristo, torna aproveitável a todos o bem privado da missa de um bom sacerdote.
Quanto ao mal particular de um não pode prejudicar a outro sem o consentimento deste, como diz
Agostinho.

## Art. 7 — Se os heréticos, os cismáticos e os excomungados podem consagrar.
O sétimo discute-se assim. — Parece que os heréticos, os cismáticos e os excomungados não podem
consagrar.

1. — Pois, diz Agostinho, que fora da Igreja Católica não há lugar para verdadeiro sacrifício. E Leão Papa
diz como também está nas Decretais: Só na Igreja, que é o corpo de Cristo os sacerdotes são legítimos e
os sacrifícios verdadeiros. Ora, os heréticos, os cismáticos e os excomungados estão separados na Igreja.
Logo, não podem celebrar um verdadeiro sacrifício.

2. Demais. — Como no mesmo lugar se lê, diz Inocência Papa: Embora acolhamos os leigos, que deixam
os Arianos, e as outras heresias pestilenciais dessa espécie, quando parecem querer se penitenciar
delas, contudo não pensamos que se devam receber os seus clérigos com a dignidade do sacerdócio ou
de qualquer outro ministério, se só lhes permitimos o poder de batizar. Ora, ninguém pode consagrar a
Eucaristia senão tendo a dignidade do sacerdócio. Logo, os heréticos e outros tais não podem consagrar
a Eucaristia.

3. Demais. — Quem está fora da Igreja nada pode fazer em nome de toda a Igreja. Ora, o sacerdote,
consagrando a Eucaristia, fá-lo em nome de toda ela, como se conclui de fazer todas as orações em
nome da Igreja. Logo, parece que os que estão fora da Igreja, isto é, os heréticos, os cismáticos e os
excomungados, não podem consagrar a Eucaristia.
Mas, em contrário, diz Agostinho: Assim como o batismo produz neles, isto é, nos heréticos, nos
cismáticos e nos excomungados todos os seus efeitos, assim também a ordenação. Ora, por força da
ordenação o sacerdote pode consagrar a Eucaristia. Logo, os heréticos, os cismáticos e os
excomungados, desde que neles permanece íntegra a ordenação, parece que podem consagrar a
Eucaristia.

SOLUÇÃO. — Certos disseram, que os heréticos, os cismáticos e os excomungados, estando fora da
Igreja, não podem celebrar este sacramento. - Mas nisso se enganam. Porque, como diz Agostinho, não
é o mesmo estar absolutamente privado de uma causa e o não usar bem dela; assim também, difere o
não dar do não dar bem. Ora, os que, fazendo parte da Igreja, receberam o poder de consagrar, quando
se ordenaram sacerdotes, têm a faculdade legítima de o fazer, mas não usam bem dela se depois se
separaram da Igreja pela heresia e pelo cisma, ou pela excomunhão. Quanto aos que se ordenaram
depois de assim separados, nem possuem um poder legítimo nem usam bem dele. Mas que têm uns e
outros esse poder, resulta de dizer Agostinho no mesmo lugar, que, tomados à unidade da Igreja, não
precisam ser reordenados, mas são recebidos nas suas ordens. E sendo a consagração da Eucaristia um
ato conseqüente ao poder conferido pela Ordem, os separados da Igreja pela heresia e pelo cisma ou
pela excomunhão, podem por certo consagrar a Eucaristia, que, consagrada por eles, contém
verdadeiramente o corpo e o sangue de Cristo; mas, assim procedendo, não procedem bem e pecam.
Por isso não colhem o fruto do sacrifício, que é um sacrifício espiritual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As autoridades citadas e outras semelhantes devem
entender-se como significando que os separados da Igreja não têm o poder legítimo de oferecer o
sacramento. Por onde, fora da Igreja não pode haver sacrifício espiritual, verdadeiro pela verdade do
sacrifício, embora o seja pela verdade do sacramento. Assim também, como dissemos, o pecador recebe
o corpo de Cristo sacramentalmente, mas não espiritualmente.

RESPOSTA À SEGUNDA. — Os heréticos e os císmáticos só se lhes permite conferir legitimamente o
batismo, porque podem licitamente batizar em artigo de necessidade: Mas em nenhum caso podem
licitamente consagrar a Eucaristia nem conferir os outros sacramentos.

RESPOSTA À TERCEIRA. — Ao rezar as orações da missa, o sacerdote o faz sem dúvida em nome da
Igreja, de cuja utidade faz parte. Mas, na consagração do sacramento age em nome de Cristo, cujas
vezes faz pelo poder que lhe foi conferido na sua ordenação. Por onde, o sacerdote separado da
unidade da Igreja que celebrar a missa, por não ter perdido o poder da ordem, consagra
verdadeiramente o corpo e o sangue de Cristo; mas por estar separado da unidade da Igreja, as suas
orações não têm eficácia.

## Art. 8 — Se o sacerdote degradado pode celebrar este sacramento.
O oitavo discute-se assim. - Parece que o sacerdote degradado não pode celebrar este sacramento.

1. — Pois, ninguém celebra este sacramento senão pelo poder que tem de· consagrar. Ora, o degradado
não tem o poder de consagrar, embora tenha o de batizar, como dispõe um cânone. Logo, parece que o
presbítero degradado não pode consagrar a Eucaristia.

2. Demais. — Quem dá também pode tirar. Ora, o bispo dá ao presbítero o poder de consagrar, quando
o ordena. Logo, também lh'o pode tirar, degradando-o.

3. Demais. — O sacerdote, pela degradação, ou perde o poder de consagrar ou só o exercício dele. Ora,
não só o exercício, porque então o degradado não perderia mais que o excomungado, que também não
possui o exercício. Logo, parece que perde o poder de consagrar. Donde se conclui que não pode
consagrar este sacramento.
Mas, em contrário, como o prova Agostinho, os apóstatas da fé não perdem o poder de batizar; pois,
quando voltam pela penitência, não lhes é ele reiterado, o que demonstra não no haverem perdido.
Ora, semelhantemente, o degradado, uma vez que se reconcilia, não deve ser ordenado de novo. Logo,
não perdeu o poder de consagrar. Por onde, o sacerdote degradado pode celebrar este sacramento.

SOLUÇÃO. — O poder de consagrar a Eucaristia pertence ao caráter da ordem sacerdotal. Ora todo
caráter, por ser conferido com uma certa ordenação, é indelével, como dissemos; assim como a
consagração de quaisquer objetos são perpétuas e não podem ser perdidas nem reiteradas. Por onde, é
manifesto, que o poder de consagrar não se perde pela degradação. Assim, diz Agostinho: Ambos, isto é,
o batismo e a ordem, são sacramentos e são conferidos por uma certa consagração: o batismo, quando
o catecúmeno é o batizado; a ordenação, quando o sacerdote é ordenado. Logo, não podem ambos ser
reiterados pelos católicos. Por onde é claro que o sacerdote degradado pode conferir este sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O cânon referido não é assertório, mas apenas indaga,
como nô-Io assegura o seu contexto.

RESPOSTA À SEGUNDA. — O bispo não confere o poder à ordem sacerdotal por virtude própria, mas
instrumental, como ministro de Deus; cujo efeito não pode o homem destruir, segundo aquilo do
Evangelho: Não separe o homem o que Deus ajuntou. Por isso, o bispo não pode retirar o poder que
conferiu, assim como quem batiza não pode privar do caráter batismal.

RESPOSTA À TERCEIRA. — A excomunhão é um remédio. Por isso não priva o excomungado do exercício
do poder sacerdotal, quase em perpétuo; mas temporàriamente, e para correção sua. Ao passo que os
degradados são privados dele, como condenados à perpetuidade.

## Art. 9 — Se podemos receber licitamente a comunhão, dos sacerdotes heréticos ou excomungados, ou também pecadores, e ouvir a missa dita por eles.
O nono discute-se assim. — Parece que podemos receber licitamente a comunhão, dos sacerdotes
heréticos ou excomungados, ou também pecadores, e ouvir a missa celebrada por eles.

1. — Pois, como diz Agostinho, não devemos fugir dos sacramentos quer administrado por um homem
bom, quer por um homem mau. Ora, os sacerdotes, embora pecadores, e os heréticos ou
excomungados, celebram um verdadeiro sacramento. Logo, parece que não devemos evitar o receber
deles a comunhão, ou ouvir-lhes a missa.

2. Demais. — O corpo verdadeiro de Cristo é figurativo do corpo místico, como se disse. Ora, o
verdadeiro corpo de Cristo é consagrado pelos referidos sacerdotes. Logo, parece que os pertencentes
ao corpo místico podem comungar no sacrifício deles.

3. Demais. — Muitos pecados são mais graves que a fornicação. Ora, não é proibido ouvir missa dos
sacerdotes que cometeram outros pecados. Logo, também não deve sê-lo ouvi-las dos sacerdotes
fornicários.
Mas, em contrário, dispõe um cânone: Ninguém ouça a missa de um sacerdote de quem tem certeza
que vive em concubinato. E Gregório narra: Um pai pérfido mandou ao filho um bispo ariano, a fim de
que das mãos deste recebesse a comunhão sacrilegamente consagrada. Ora, aquele, varão temente a
Deus, vendo-o chegar, exprobrou como devia o bispo ariano.

SOLUÇÃO. — Como dissemos os sacerdotes, sendo heréticos, cismáticos ou excomungados, ou ainda
pecadores, embora tenham o poder de consagrar a Eucaristia, contudo pecam usando dela, pelo não
fazerem retamente. Ora, quem comunica com uma pessoa em estado de pecado participa do pecado
dela. Por isso diz João na sua epístola canónica: O que lhe diz (ao herético) - Deus te salve, comunica
com as suas malignas obras. Logo, não é lícito receber a comunhão dos referidos sacerdotes, nem deles
ouvir a missa. Mas é preciso distinguir as seitas a que pertençam. - Assim, os heréticos, os cismáticos e
os excomungados estão, por sentença da Igreja, privados de fazer a consagração. Portanto pecam todos
os que lhes ouvem a missa ou deles recebem os sacramentos. Mas nem todos os sacerdotes pecadores
estão privados, por sentença da Igreja, de exercer esse poder. E então, embora suspensos em virtude de
sentença divina, não o estão contudo, em relação a terceiros por sentença da Igreja. Por onde, até a
Igreja dar a sua sentença, é lícito receber deles a comunhão e ouvir-lhes a missa. Por isso, àquilo do
Apóstolo - Com este tal nem comer deveis diz a Glosa de Agostinho: Assim dizendo, não quis autorizar
ninguém a julgar o próximo por uma suspeita não fundada nem por usurpar esse direito em
circunstâncias extraordinárias; mas ensinar-nos, antes, que o juízo deve fundar-se na lei de Deus e ser
proferido de acordo com a legislação da Igreja, quer o culpado confesse o seu pecado, quer seja acusado
e convencido dele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Evitando ouvir a missa de tais sacerdotes ou receber
deles a comunhão, longe de evitarmos os sacramentos de Deus, nós os veneramos. Por isso a hóstia
consagrada por esses sacerdotes deve ser adorada e, se guardada, pode ser licitamente recebida por um
sacerdote legitimo. Mas, evitamos a culpa dos que ministram indignamente.

RESPOSTA À SEGUNDA. — A unidade do corpo místico é o fruto do corpo verdadeiramente recebido.
Mas os que o recebem ou celebram indignamente ficam privados do fruto, como se disse. Por onde, os
pertencentes à unidade da Igreja não devem receber o sacramento dispensado por eles.

RESPOSTA À TERCEIRA. — Embora a fornicação não seja mais grave que os outros pecados, contudo os
homens são mais inclinados a ela pela concupiscência da carne. Por isso, tal pecado é especialmente
proibido aos sacerdotes, pela Igreja, bem como a assistência à missa de sacerdotes concubinários. Mas
isto se deve entender assim quando o fato é notório, quer por sentença dada e que os argüi do pecado,
quer por confissão feita em juízo, quer quando não pode haver nenhuma dúvida sobre o pecado.

## Art. 10 — Se é lícito ao sacerdote abster-se totalmente de consagrar a Eucaristia.
O décimo discute-se assim. — Parece lícito ao sacerdote abster-se totalmente de consagrar a
Eucaristia.

1. — Pois, assim é ofício do sacerdote consagrar a Eucaristia, assim também batizar e ministrar os outros
sacramentos. Ora, o sacerdote não está obrigado a ministrar os outros sacramentos, senão pela cura
d'almas, que assumiu. Logo, não tendo cura d'almas, parece que também não está obrigado a consagrar
a Eucaristia.

2. Demais. — Ninguém está obrigado a fazer o ilícito; do contrário ficaria com a consciência perplexa.
Ora, ao sacerdote pecador ou também excomungado não é lícito consagrar a Eucaristia, como do
sobredito resulta. Logo, parece que esses tais não estão obrigados a celebrar. E assim, nem os outros;
do contrário da culpa lhes proviria uma vantagem.

3. Demais. — A dignidade sacerdotal não se perde pela enfermidade subseqüente. Assim, dispõe Gelásio
Papa (I), e está nas Decretais: As leis canônicas não permitem sejam admitidos ao sacerdócio os débeis
de corpo; mas quem foi constituído nessa dignidade e depois adoeceu, não pode perder o que recebeu
quando gozava saúde. Ora, acontece às vezes que os ordenados sacerdotes vêm a padecer certas
doenças, como a lepra, a epilepsia e outros, que os impedem de celebrar. Logo, parece que os
sacerdotes não estão obrigados a fazê-la.
Mas, em contrário, diz Ambrósia numa oração: Pecado grave é o nosso por não termos vindo à tua mesa
com pureza de coração e mãos inocentes; mais grave porém seria ele se, pelo temer, não quiséssemos
oferecer o sacrifício.

SOLUÇÃO. — Certos disseram, que o sacerdote pode licitamente abster-se de todo da consagração,
salvo se lhe foi cometido o dever de celebrar e dispensar os sacramentos ao povo. Mas esta opinião não
é racional. Pois todos estamos obrigados a usar, em tempo oportuno, da graça que nos foi dada,
segundo aquilo do Apóstolo: Nós vos exortamos a que não recebais a graça de Deus em vão. Ora, a
oportunidade de oferecer o sacrifício deve ser considerada não só tendo em vista os fiéis de Cristo, a
que devem ser ministrado os sacramentos, mas principalmente em relação a Deus, a quem é oferecido
o sacrifício na consagração deste sacramento. Por onde, os sacerdotes, mesmo sem cura d'almas, não
lhes é lícito cessar de todo de celebrar; mas estão obrigados a fazê-lo ao menos nas festas principais e
sobretudo nos dias em que os fiéis costumam comungar. Por isso, a Escritura repreende certos
sacerdotes; que não se aplicavam já às funções do altar, desprezando o templo e descuidando dos
sacrifícios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os outros sacramentos se celebram para o uso dos fiéis
e, portanto não estão obrigados a ministrá-los senão aqueles que assumiram a cura deles. Mas, este
sacramento se celebra consagrando a Eucaristia, na qual se oferece um sacrifício a Deus, a que o
sacerdote está obrigado pela ordem divina que recebeu.

RESPOSTA À SEGUNDA. — O sacerdote pecador privado do exercício da ordem por sentença da Igreja,
perpétua ou temporariamente, fica privado do poder de oferecer o sacrifício; e portanto fica
desonerado da obrigação. Mas isto lhe redunda antes em detrimento do fruto espiritual que em
vantagem. Não estando porém privado do poder de celebrar, não fica isento da obrigação. Mas nem por
isso cai em perplexidade de consciência, porque pode penitenciar-se do pecado e celebrar.

RESPOSTA À TERCEIRA. — A debilidade ou doença supervenientes à ordenação sacerdotal não priva
dela; mas impede ao sacerdote exercê-la quanto à consagração da Eucaristia. As vezes por
impossibilidade de o fazer, como no caso da privação da vista, dos dedos ou do uso da língua. Outras
vezes por perigo, como se o sacerdote sofre de epilepsia ou ainda de qualquer alienação mental. Outras
vezes ainda em razão da repugnância que a doença inspira, como no caso do leproso, que não deve
celebrar em público. Pode porém dizer missa privadamente, salvo se a lepra progredir a ponto de, pela
corrosão dos membros, torná-lo incapaz de celebrar.