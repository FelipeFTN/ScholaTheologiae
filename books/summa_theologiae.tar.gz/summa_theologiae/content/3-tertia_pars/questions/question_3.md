# Questão 3: Da união relativamente à pessoa que assumiu
Em seguida devemos tratar da união relativamente à pessoa que assumiu.
E nesta questão discutem-se oito artigos:

## Art. 1 — Se à Pessoa divina convém assumir a natureza criada.
O primeiro discute-se assim. — Parece que não convém a Pessoa divina assumir a natureza criada.

1. — Pois, uma Pessoa divina significa um ser perfeito em sumo grau. Ora, perfeito é aquilo a que não se
pode fazer nenhum acréscimo. Mas, sendo assumir o tomar para si. (ad se sumerey); de modo a ficar o
assumido acrescentado ao que assume, parece que à Pessoa divina não convém assumir a natureza
criada.

2. Demais. — O ser para o qual um outro é assumido se comunica de certo modo ao primeiro; assim,
uma dignidade se comunica a quem foi a ela elevada. Ora, a pessoa é por natureza incomunicável, como
se disse na' Primeira Parte. Logo, não convém à Pessoa divina assumir, isto é, tomar para si. (ad se
sumere).

3. Demais. — A pessoa é constituída pela natureza. Ora, é inconveniente que o constituído assuma o
constituinte, porque o efeito não age sobre a sua causa. Logo, não convém à Pessoa assumir a natureza.
Mas, em contrário, Agostinho diz: Esse Deus, isto é, o Unigênito, recebeu a forma, isto é, a natureza do
servo, na sua Pessoa. Ora, o Deus Unigênito é uma Pessoa. Logo, à Pessoa convém receber a natureza, o
que é assumi-la.

SOLUÇÃO. — A palavra assunção implica duas coisas, isto é, o princípio e o termo do ato, pois, assumir é
como tomar para si (ad se sumeres). Ora, dessa assunção a Pessoa é o princípio e o termo. O princípio,
porque à pessoa propriamente cabe o agir; ora, essa assunção da carne foi feita pela pessoa divina.
Semelhantemente, também a Pessoa é o termo dessa assunção; pois, como se disse, a união se fez na
Pessoa, não em a natureza. Por onde é claro que proprissimarnente cabe à Pessoa assumir a natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Sendo a Pessoa divina infinita, não se lhe pode fazer
nenhuma adição. Por isso Cirilo diz: Nós não entendemos esse modo de união como uma adição, assim
como na união do homem com Deus, pela graça de adoção, nada se acrescenta a Deus, mas, o divino se
opõe ao homem. Por onde não é Deus, mas o homem, quem se aperfeiçoa.

RESPOSTA À SEGUNDA. — Dizemos que a pessoa é incomunicável, por não poder ser predicada de
muitos supostos. Mas, nada impede que da pessoa se façam muitas predicações. Por onde, não é contra
a essência da pessoa comunicar-se de modo que subsista em várias naturezas. Pois, também na pessoa
criada podem concorrer várias naturezas acidentalmente, assim como a pessoa de um determinado
homem tem quantidade e qualidade. Mas, por causa da sua. infinidade, é próprio da divina Pessoa, que
nela exista o concurso das naturezas, não acidentalmente, mas segundo a subsistência.

RESPOSTA À TERCEIRA. — Como se disse, a natureza humana não constitui a Pessoa divina,
absolutamente falando; mas a constitui enquanto denominada por uma tal natureza. Assim, não é da
natureza humana que o Filho de Deus tira a sua existência absoluta, pois já existia abeterno, mas só a
sua existência humana. Mas, segundo a natureza divina a Pessoa divina é constituída de modo absoluto.
Por onde, da Pessoa divina não dizemos que assumiu a natureza divina, mas a humana.

## Art. 2 — Se à natureza divina convém assumir.
O segundo discute-se assim. — Parece que à natureza divina não convém o assumir.
1 — Pois, como se disse, assumir é como tomar para si (ad se sumere). Ora, a natureza divina não tomou
para si a natureza humana, pois, não se fez a união em a natureza, mas na pessoa, como se disse. Logo,
à natureza divina não cabe assumir a natureza humana.

2. Demais. — A natureza divina é comum às três Pessoas. Se, pois, à natureza convém o assumir, segue-
se que convém às três Pessoas. E assim, o Pai assumiu a natureza humana, como o Filho - O que é
errôneo.

3. Demais. — Assumir é agir. Ora, agir convém à pessoa; não à natureza, que antes exprime o princípio
pelo qual o agente age. Logo, assumir não convém à natureza.
Mas, em contrário, Agostinho diz: Aquela natureza que é sempre. gerada do Pai, isto é, que foi pela
geração eterna recebida do Pai, recebeu a nossa natureza, sem pecado.

SOLUÇÃO. — Como dissemos, a palavra assunção abrange duas coisas - o princípio e o termo da ação.
Ora, ser princípio da assunção convém à natureza divina em si mesma, pois, pelo seu poder se lhe
realizou a assunção. Mas, ser termo da assunção não convém a essa natureza em si mesma, mas, em
razão da Pessoa na qual a consideramos. Por onde, primária e proprissimamente, dizemos que a Pessoa
assume; mas, secundariamente podemos dizer que também a natureza assumiu a natureza à sua
Pessoa. E também deste modo dizemos que a natureza se encarnou, não por ter-se convertido em
carne, mas por ter assumido a natureza da carne. Donde o dizer Damasceno. Afirmamos que a natureza
de Deus se encarnou, segundo os santos Atanásio e. Cirilo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pronome se é recíproco e se refere ao mesmo
suposto. Ora, a natureza divina não difere, pelo suposto, da Pessoa do Verbo. Por onde, por ter a
natureza do Verbo assumido a natureza humana à sua Pessoa, dizemos que a assumiu a si. Mas, embora
o Padre assuma a natureza humana à Pessoa do Verbo, nem por isso a assume a si; pois, não é o mesmo
o suposto do Pai e do Verbo. Por onde, não se pode propriamente dizer que o Pai assume a natureza
humana.

RESPOSTA À SEGUNDA. — O conveniente à natureza humana em si mesma convém às três Pessoas;
assim a bondade, a sabedoria e atributos semelhantes. Mas assumir lhe convém em razão da Pessoa do
Verbo, como se disse. Por isso .só a essa Pessoa o convém.

RESPOSTA À TERCEIRA. — Assim corno em Deus se identificam o seu ser e o princípio deste, assim
também; o que faz e o princípio da sua ação; pois, todo ser age enquanto ser. Por onde, a natureza
divina é o princípio do agir de Deus e é o próprio Deus agente.

## Art. 3 — Se, abstraída a personalidade pelo intelecto, a natureza pode assumir.
O terceiro discute-se assim. — Parece que, abstraída a personalidade pelo intelecto, a natureza não
pode assumir.

1. — Pois, como se disse, à natureza convém assumir em razão da pessoa. Ora, o que convém a um ser
em razão de outro, separado deste último já não lhe pode convir. Assim, o corpo, visível em razão da
cor, não pode ser visto sem esta. Logo, abstraída a personalidade pelo intelecto, a natureza não pode
assumir.

2. Demais. — A assunção importa o termo da união, como se disse. Ora, não pode a união fazer-se em a
natureza, mas só na pessoa. Logo, abstraída da personalidade, a natureza divina não pode assumir.

3. Demais. — Na primeira parte se disse que, abstraída a personalidade, nada resta. Ora, o que assume é
uma realidade. Logo, abstraída a personalidade, a natureza divina não pode assumir.
Mas, em contrário, em Deus, a personalidade é considerada uma propriedade natural, e é tríplice, a
saber: a paternidade, a filiação e a processão, como se disse na Primeira Parte. Ora, afastadas essas
propriedades naturais pelo intelecto, ainda resta a onipotência de Deus, pela qual se fêz a Encarnação,
como o disse o Anjo: Porque a Deus nada é impossível. Logo, parece que, mesmo removida a
personalidade, a natureza divina pode assumir.

SOLUÇÃO. — O intelecto mantém com Deus uma dupla relação. — Primeiro, conhecendo a Deus como
ele é. E assim, é impossível ele circunscrever algo em Deus, de modo que reste além disso outra coisa;
pois, tudo o que há em Deus é uma unidade, salva a distinção das Pessoas. Das quais, uma
desapareceria com a eliminação de outra, pois, elas se distinguem só pelas relações, que são
necessariamente simultâneas. —De outro modo o intelecto se relaciona com Deus, não pelo conhecer
como ele é, mas conhecendo-o ao seu modo, isto é, multiplicada e divididamente o que em Deus é uno.
E deste modo, o nosso intelecto pode inteligir a bondade e a sabedoria divina e outros atributos
semelhantes, chamados atributos essenciais, sem aí se compreender a paternidade ou a filiação, que se
chamam personalidades. E sendo assim, abstraída a personalidade pelo intelecto, podemos ainda
inteligir a natureza que assume.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como o ser de Deus se identifica com o princípio mesmo
dele, todo o atribuído a Deus, considerado abstractamente e em si mesmo e separado do mais, será
algo de subsistente; e por consequência o será a pessoa, que existe em a natureza intelectual. Assim
como, pois, postas as propriedades pessoais em Deus, dissemos serem três as Pessoas, assim, excluídas
pelo intelecto as propriedades pessoais, restará em nossa consideração a natureza divina como
subsistente e como pessoa. E deste modo, podemos inteligir que assuma a natureza humana, em razão
da sua subsistência ou personalidade.

RESPOSTA À SEGUNDA. — Mesmo circunscritas pelo intelecto as personalidades das três Pessoas,
restará no intelecto a personalidade una de Deus, como o entendem os Judeus; e essa pode ser o termo
da assunção, assim como dizemos ter ela o seu termo na Pessoa do Verbo.

RESPOSTA À TERCEIRA. — Abstraída a personalidade pelo intelecto, diz-se que nada resta a modo de
resolução. Quase sendo uma coisa o que está sujeito à relação e outra, a relação mesma; pois, tudo o
considerado em Deus o é como suposto subsistente. Contudo, pode uma predicação feita, de Deus, ser
entendida sem outra, não a modo de resolução, mas do modo já dito.

## Art. 4 — Se uma Pessoa pode assumir a natureza criada, sem a assumir outra.
O quarto discute-se assim. — Parece que não pode uma Pessoa assumir a natureza, sem a assumir
outra.

1. — Pois, as obras da Trindade são indivisas, como diz Agostinho. Ora, como das três Pessoas é só uma
a essência, assim também uma só operação. Ora, assumir é uma determinada operação. Logo, não pode
convir a uma Pessoa divina sem que o convenha a outra.

2. Demais. — Assim como falamos da pessoa encarnada do Filho, assim, da natureza: pois, toda a
natureza divina se encarnou numa das suas hipóstases, como diz Damasceno. Ora, a natureza é comum
às três Pessoas. Logo, também a assunção.

3. Demais. — Assim como a natureza humana em Cristo foi assumida por Deus, assim também pela
graça, os homens são assumidos por ele, segundo aquilo do Apóstolo: Deus o recebeu por seu. Ora, esta
assunção comumente pertence a todas as Pessoas. Logo, também a primeira.
Mas, em contrário, Dionísio diz que o mistério da Encarnação pertence à teologia discretiva, pela qual se
introduz a distinção das divinas Pessoas.

SOLUÇÃO. — Como dissemos, a as unção implica duas coisas: o ato de quem assume e o termo da
assunção. Ora, o ato de quem assume procede da divina virtude, comum às três Pessoas; mas o termo
da assunção é a pessoa, como se disse. Logo, o que implica uma ação, na assunção, é comum às três
Pessoas; mas o que implica a ideia de termo convém de modo a uma Pessoa, que não convém às outras.
Pois, as três Pessoas fizeram com que a natureza humana se unisse à Pessoa do Filho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe quanto à operação. E a conclusão seria
consequente se importasse só essa operação sem o termo, que é a Pessoa.

RESPOSTA À SEGUNDA. — Dizemos que a natureza se encarnou e que assumiu, em razão da Pessoa na
qual se terminou a união, como se disse; não porém enquanto comum às três Pessoas, Pois dizemos que
toda a natureza divina se encarnou, não por ter se encarnado em todas as Pessoas, mas por não faltar
nenhuma das perfeições divinas à natureza da Pessoa encarnada.

RESPOSTA À TERCEIRA. — A assunção feita pela graça da adoção se termina numa determinada
participação da natureza divina, por assimilação com a bondade dela, conforme àquilo da Escritura. Para
que sejais feitos participantes, etc. E essa assunção é comum às três Pessoas, tanto quanto ao princípio,
como ao termo. Mas; a assunção feita pela graça da união é comum quanto ao princípio, mas não
quanto ao termo, como se disse.

## Art. 5 — Se alguma outra Pessoa divina, que não a Pessoa do Filho, podia ter assumido a natureza humana.
O quinto discute-se assim. — Parece que nenhuma outra Pessoa divina, que não a Pessoa do Filho,
podia ter assumido a natureza humana.

1. — Pois, essa assunção tornou Deus o Filho do homem. Ora, seria inconveniente que conviesse ao Pai
ou ao Espírito Santo o ser filho, o que redundaria em confusão das divinas Pessoas. Logo, o Pai e o
Espírito Santo não poderiam assumir a carne.

2. Demais. — Pela Encarnação divina os homens alcançaram a adoção de filhos, segundo as palavras do
Apóstolo. Vós não recebestes o espírito de escravidão para estardes outra vez com temor mas
recebestes o espírito de adoção de filhos. Ora, a filiação adotiva é uma semelhança participada da
filiação natural, que não convém ao Padre nem ao Espírito Santo. Donde o dizer o Apóstolo: Os que ele
conheceu na sua presciência também os predestinou para serem conformes à imagem de seu Filho.
Logo, parece que nenhuma outra Pessoa podia ter-se encarnado, que não a Pessoa do Filho.

3. Demais. — Diz-se que o Filho foi enviado, e gerado, na sua natividade temporal, como encarnado que
foi. Ora, ao Pai não convém o ser enviado, pois é inascível, como se estabeleceu na Primeira Parte. Logo,
ao menos a Pessoa do Pai não podia encarnar-se.
Mas, em contrário, tudo o que pode o Filho pode o Pai; do contrário os três não teriam o mesmo poder.
Ora, o Filho pôde encarnar-se, Logo semelhantemente, o Pai e o Espírito Santo.

SOLUÇÃO. — Como dissemos, a assunção implica duas coisas: o ato mesmo de quem assume e o termo
da assunção. Ora, o princípio do ato é a virtude divina; e o termo é a pessoa. Mas, o poder divino todas
as Pessoas o têm comum e igualmente. E a mesma é a razão comum da personalidade nas três Pessoas,
embora as propriedades pessoais sejam diferentes. Ora, sempre que uma virtude existe igualmente em
vários sujeitos, pode terminar a sua ação em qualquer deles; tal o (que se dá com as potências racionais,
que podem se aplicar a coisas opostas, podendo realizar uma ou outra delas. Por onde, a divina virtude
podia unir a natureza humana à pessoa do Pai ou à do Espírito Santo, como a uniu à pessoa do Filho. Por
isso, concluímos que o Pai ou o Espírito Santo podiam, tão bem como o Filho, assumir a carne.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A filiação temporal em virtude da qual Cristo é chamado
Filho do Homem, não lhe constitui a pessoa, como a filiação eterna, mas é uma certa consequência da
natividade temporal. Por onde se deste modo o nome de filiação se transferisse ao Pai ou ao Espírito
Santo, daí não resultaria nenhuma confusão das divinas Pessoas.

RESPOSTA À SEGUNDA. — A filiação adotiva é uma certa semelhança participada da filiação natural;
mas se realiza em nós apropriadamente pelo Pai, que é o princípio da filiação natural e pelo dom do
Espírito Santo, que é o amor do Pai e do Filho, segundo aquilo do Apóstolo: Mandou Deus o Espírito de
seu Filho, que chama — Pai, Pai. Por onde, assim como pela encarnação do Filho, recebemos a filiação
adotiva, à semelhança da sua filiação natural, assim, se o Pai se tivesse encarnado, teriamos recebido
dele a filiação adotiva como do princípio da filiação natural, e do Espírito Santo, como do nexo comum
entre o Pai e o Filho.

RESPOSTA À TERCEIRA. — Ao Pai convém ser inascível, segundo a natividade eterna; o que não excluiria
a natividade temporal. Mas, dizemos que o Filho é enviado, segundo a Encarnação como procedente de
outro, sem o que a Encarnação não realizaria plenamente a ideia de missão.

## Art. 6 — Se duas Pessoas divinas poderiam assumir uma natureza numericamente a mesma.
O sexto discute-se assim. — Parece que duas Pessoas divinas não poderiam assumir uma natureza
numericamente a mesma.
1 — Pois, isso suposto, ou seriam um só homem ou vários. Ora, vários não; pois, assim como uma
mesma natureza divina em várias Pessoas não poderia constituir vários deuses, assim urna mesma
natureza humana em várias pessoas não poderia constituir vários homens. Também e
semelhantemente, não poderiam ser um só homem, pois, um homem o é determinadamente, que
revela uma certa pessoa; e então desapareceria a distinção das três Pessoas, o que é inadmissível. Logo,
nem duas nem três pessoas podem receber uma mesma natureza humana.

2. Demais. — Assunção se perfaz na unidade da Pessoa, como se disse. Ora, a Pessoa do Pai. do Filho e
do Espírito Santo não é uma só. Logo, não podem três Pessoas assumir uma mesma natureza humana,
Demais — Damasceno e Agostinho dizem, que a Encarnação do Filho de Deus resulta que tudo o
predicado do Filho de Deus o é também do Filho do Homem, e vice-versa. Se, pois, as três Pessoas
assumissem uma mesma natureza humana, resultaria que tudo o predicado de qualquer das três
Pessoas, sê-lo-ia também desse homem; e inversamente, tudo o predicado desse homem poderia sê-lo
de qualquer das três Pessoas. Por onde, o gerar o Filho abeterno, que é próprio do Pai, seria predicado
desse homem e, por consequência, do Filho de Deus, o que e inadmissível. Logo, não é possível, que três
Pessoas divinas assumam uma mesma natureza humana.
Mas, em contrário, a pessoa encarnada subsiste em duas naturezas, a saber, a divina e a humana. Ora,
três Pessoas podem subsistir em uma mesma natureza divina. Logo, também o podem numa mesma
natureza humana de modo que seria uma mesma natureza humana a assumida pelas três Pessoas.

SOLUÇÃO. — Como dissemos da união da alma e do corpo, em Cristo, não resulta uma nova pessoa nem
hipóstase; mas, uma mesma natureza assumida na Pessoa ou hipóstase divina. O que, certo, não se faz
pelo poder da natureza humana, mas pelo da Pessoa divina. Ora, a condição das divinas Pessoas é tal
que uma delas não exclui as outras da comunhão da mesma natureza, mas foi da comunhão da mesma
Pessoa. Mas, como no mistério da Encarnação a razão total do feito é o poder de quem o faz, como diz
Agostinho, devemos, nesta matéria, julgar, antes, segundo a condição da divina Pessoa assumente, que
segundo a da natureza humana assumida. Assim, pois, não é impossível que duas ou três das divinas
Pessoas assumam uma mesma natureza humana. Mas seria impossível assumirem uma hipótese ou
uma pessoa humana; assim, como diz Anselmo, várias Pessoas não poderiam assumir um mesmo
homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Admitido que .três Pessoas assumissem uma mesma
natureza humana, seria verdadeiro dizer que três Pessoas constituiriam um mesmo homem, por causa
da natureza humana una; assim como, na realidade, é verdadeiro dizer que são um só Deus, por causa
da só uma natureza divina. Nem o vocábulo — um — implica unidade de pessoa, mas unidade em a
natureza humana. Pois, não se poderia arguir, do fato de constituírem três Pessoas um só homem, que o
seriam absolutamente falando; pois, nada impede dizer-se que homens, vários absolutamente falando,
sejam um só, de certo modo, por exemplo, um só povo. Assim, diz Agostinho: É diverso por natureza o
espírito de Deus, do espírito do homem, mas, unindo-se, formam um só espírito, segundo aquilo do
Apóstolo. O que está unido a Deus é um mesmo espírito com ele.

RESPOSTA À SEGUNDA. — Admitida essa posição, a natureza humana seria assumida na unidade, não
de uma só Pessoa, mas na de cada uma delas, de modo que, assim como a natureza divina tem uma
unidade natural com cada uma das Pessoas, assim, a natureza humana teria unidade com cada uma
delas, pela assunção.

RESPOSTA À TERCEIRA. — No tocante ao mistério da Encarnação, há comunicação das propriedades
pertinentes à natureza; pois, tudo o conveniente à natureza pode ser predicado da pessoa subsistente
nessa natureza, seja qual for a natureza donde se tira o nome designativo da Pessoa. Por onde, aceita
essa posição, da Pessoa do Pai pode ser predicado o que é próprio tanto à natureza humana como à
divina; e semelhantemente, da Pessoa do Filho e da do Espírito Santo. Mas, o conveniente à Pessoa do
Pai, em razão da própria Pessoa, não poderia atribuir-se à Pessoa do Filho ou à do Espírito Santo, por
causa da distinção das Pessoas, que permaneceria. Poderia, pois, dizer-se que, assim como o Pai é
ingênito, assim se-lo-ia o homem, tomando-se a palavra homem pela Pessoa do Pai. Mas quem
continuasse dizendo: O homem é ingênito; ora, o Filho é homem; logo, é ingênito, cometeria o sofisma
de figura de dicção ou de acidente. Assim como na realidade dizemos que Deus é ingênito, porque o é o
Pai; mas daí não podemos concluir que o Filho seja ingênito, embora o seja o Pai.

## Art. 7 — Se uma mesma Pessoa divina pode assumir duas naturezas humanas.
O sétimo discute-se assim. — Parece que uma mesma Pessoa divina não pode assumir duas naturezas
humanas.

1. — Pois, a natureza assumida do mistério da Encarnação não tem outro suposto além do suposto da
pessoa divina, como do sobredito resulta. Se, pois. admitimos que uma mesma Pessoa divina assumiu
duas naturezas humanas, haveria um só suposto para duas naturezas da mesma espécie. O que implica
contradição, pois, a natureza de uma mesma espécie não se multiplica senão pela distinção do supostos.

2. Demais. — Na hipótese que examinamos não se poderia dizer que a Pessoa divina encarnada fosse
um só homem, porque não teria uma só natureza humana. Semelhantemente, não Se poderia dizer, que
a seriam muitos homens, porque muitos homens são distintos pelo suposto, e então haveria aí um só
suposto. Logo, a referida posição é absolutamente impossível.

3. Demais. — No mistério da Encarnação toda a natureza divina se uniu a toda a natureza assumida, isto
é, a cada uma das partes dela; pois, Cristo é Deus perfeito e homem perfeito, totalmente Deus e
totalmente homem, como diz Damasceno. Ora, duas naturezas humanas não poderiam se unir
totalmente uma à outra; pois, seria necessário a alma de uma estar unida ao corpo da outra; e ainda
que os dois corpos existissem simultaneamente, o que também causaria a confusão das naturezas, Logo,
não é possível que uma Pessoa divina assuma duas naturezas humanas.
Mas, em contrário, tudo o que o Pai pode o Filho pode. Ora, o Pai, depois da Encarnação do Filho pode
assumir uma natureza humana numericamente diversa da que assumiu o Filho; pois, em nada, pela
Encarnação do Filho, diminuiu o poder do Pai nem o do Filho. Logo, parece que o Filho, depois da
Encarnação, pode assumir outra natureza humana, além daquela que assumiu.

SOLUÇÃO. — O agente que não pode ultrapassar —uma certa ação tem o seu poder limitado. Ora, o
poder da Pessoa divina é infinito nem pode ser limitado a nada de criado. Por isso, não devemos dizer
que a Pessoa divina assumiu uma natureza humana tal que não podia assumir outra. Pois, daí se seguiria
que a personalidade da natureza divina seria de tal modo circunscrita por uma mesma natureza
humana, que não poderia a sua personalidade assumir outra. O que é impossível, pois, o incriado não
pode ser compreendido pelo criado. Por onde, é claro que quer consideremos a Pessoa divina na sua
virtude, que é o princípio da união, quer na sua personalidade, que é o termo da união, é necessário
admitir que a Pessoa divina podia, além da natureza humana que assumiu, assumir outra
numericamente diferente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A natureza criada se aperfeiçoa na sua essência, pela
forma, que se multiplica pela divisão da matéria. Por onde, se a composição da matéria e da forma
constituir um novo suposto, consequentemente há de a natureza multiplicar-se conforme a
multiplicação dos supostos. Mas, no mistério da Encarnação a união da forma e da matéria, isto é, da
alma e do corpo, não constitui um novo suposto, como se disse. E portanto poderia haver multidão,
numericamente, quanto à natureza, por causa da divisão da matéria, sem distinção dos supostos.

RESPOSTA À SEGUNDA. — Poder-se-ia deduzir, da hipótese que propusemos, a existência de dois
homens, por causa das duas naturezas sem que aí houvesse dois supostos; assim como, universamente,
as três Pessoas constituíram um só homem, por causa da mesma natureza humana assumida, como se
disse. Mas essa dedução não seria verdadeira. Porque devemos empregar os nomes na significação em
que são usados, o que resulta das coisas no meio das quais vivemos. Portanto, acerca do modo de
significar e de consignificar devemos levar em conta tais coisas. Ora, em relação a elas, nunca se aplica
um nome, em virtude de uma forma, com significação plural, senão por causa da pluralidade dos
supostos. Assim, de um homem vestido com duas roupas não dizemos que constitui dois homens
vestidos, mas, um só, vestido de dois fatos; e quem tem duas qualidades o consideramos tal, segundo
essas duas qualidades. Ora, a natureza assumida, sob certo aspecto, se comporta a modo de uma veste,
embora a semelhança não seja total, como dissemos. Por onde, se uma Pessoa divina assumisse duas
naturezas humanas, por causa da unidade do suposto diríamos existir um homem com duas naturezas
humanas.Pois, muitos homens podem constituir um povo, por convirem nalguma unidade, mas não por
unidade de suposto. E semelhantemente, se duas Pessoas divinas assumissem uma natureza humana,
numericamente a mesma, seriam consideradas um só homem, como dissemos; não pela unidade do
suposto, mas por convirem numa certa unidade.

RESPOSTA À TERCEIRA. — A natureza divina e a humana não se referem na mesma ordem a uma
mesma Pessoa divina, mas a que primeiro se lhe refere é a natureza divina, como o que abeterno
constitui com ela uma unidade; ao passo que a natureza humana se lhe refere posteriormente, como
assumida temporalmente pela Pessoa divina, não por certo, de modo que a natureza seja a Pessoa
mesma, mas porque a Pessoa nela subsiste, pois, o Filho de Deus é a sua divindade mas não, a sua
humanidade. Por onde, para a natureza humana ser assumida pela Pessoa divina, resta que a natureza
divina se una por uma união pessoal a toda a natureza assumida, isto é, segundo todas as partes desta.
Ora, duas naturezas assumidas manteriam uma relação uniforme com a Pessoa divina, nem uma
assumiria a outra. Por onde, não seria necessário que uma delas se unisse totalmente à outra, isto é,
todas as partes de uma a todas as partes de outra.

## Art. 8 — Se era mais conveniente ter-se encarnado o Filho de Deus, que o Padre ou o Espírito Santo.
O oitavo discute-se assim. — Parece que não foi mais conveniente ter-se encarnado o Filho de Deus,
que o Padre ou o Espírito Santo.

1. — Pois, pelo mistério da Encarnação os homens foram levados ao verdadeiro conhecimento de Deus,
segundo aquilo do Evangelho. Eu para isso nasci e ao que vim ao mundo foi para dar testemunho da
verdade. Ora, pelo fato da pessoa do Filho de Deus ter-se encarnado, muitos ficaram impedidos do
verdadeiro conhecimento de Deus, porque referiam à pessoa mesma do Filho o que se predica da
natureza humana dele. Tal Ario, que ensinou a desigualdade das Pessoas, fundado no dito do
Evangelho: O Pai é maior do que eu. Ora, esse erro não teria surgido, se a Pessoa do Pai se tivesse
encarnado ; pois, então, ninguém julgaria o Pai menor que o Filho. Por onde, parece teria sido mais
conveniente ter-se a Pessoa do Pai encarnado, que a pessoa do Filho.

2. Demais. — Parece que o efeito da Encarnação foi uma certa e nova criação da natureza humana,
segundo aquilo do Apóstolo : Em Jesus Cristo nem a circuncisão nem a incincuncisão valem nada, mas o
ser uma nova criatura. Ora, o poder de criar é apropriado ao Pai. Logo, mais conveniente seria ter-se
encarnado o Pai que o Filho.

3. Demais. — A Encarnação se ordena à remissão dos pecados, segundo aquilo do Evangelho: E lhe
chamarás por nome Jesus, porque ele salvará o seu povo dos pecados deles. Ora, a remissão dos
pecados é atribuída ao Espírito Santo, segundo ainda o Evangelho: Recebei o Espírito Santo: aos que vós
perdoardes os pecados ser-lhes-ão perdoados. Logo, era mais conveniente ter-se encarnado a pessoa do
Espírito Santo que a do Filho.
Mas, em contrário, diz Damasceno: O mistério da Encarnação manifestou a sabedoria e o poder de
Deus; a sabedoria, porque descobria a melhor solução de um preço dificílimo; o poder, porque tornou
de novo o vencido vencedor. Ora, a virtude e a sabedoria se apropriam ao Filho, segundo aquilo do
Apóstolo: Cristo, virtude de Deus e sabedoria de Deus. Logo, foi conveniente ter-se encarnado a pessoa
do Filho.

SOLUÇÃO. — Foi convenientíssinio que se tivesse encarnado a pessoa do Filho.
Primeiro, quanto à união. Pois, convenientemente se unem as causas semelhantes. —Ora, de um modo,
a pessoa mesma do Filho, que é o Verbo de Deus, tem uma conveniência comum com toda criatura.
Porque a palavra do artífice, isto é, o seu conceito, é uma semelhança exemplar das obras feitas pelo
artífice. Por onde, o Verbo de Deus, que é o seu eterno conceito, é uma semelhança exemplar de todas
as criaturas. E portanto, assim como pela participação dessa semelhança as criaturas foram instituídas
nas suas espécies próprias, mas de um modo mutável, assim também, pela união do Verbo com a
criatura, não de modo participativo, mas pessoal, foi ela convenientemente reparada, em ordem à
perfeição eterna e imutável; pois, também o artífice, pela forma artística concebida, por meio da qual
fez a sua obra, por essa mesma também a refaz se ela se estragar. De outro modo, tem uma
conveniência especial com a natureza humana por ser o Verbo o conceito da eterna sabedoria, donde
deriva toda a sabedoria humana. Por isso, o homem se aperfeiçoa na sabedoria, que é a sua perfeição
própria, enquanto racional, porque participa do Verbo de Deus, assim como o discípulo se instrui
recebendo as palavras do mestre. Donde o dizer a Escritura: A fonte da sabedoria é o Verbo de Deus nas
alturas. Por onde, para consumar-se a perfeição do homem, foi conveniente que o Verbo mesmo de
Deus se unisse pessoalmente à natureza humana.
Segundo, a razão dessa conveniência pode ser deduzida do fim da união, que é o implemento da
predestinação, isto é, dos preordenados à herança celeste, que não é devida senão aos filhos, segundo
aquilo do Apóstolo: Se somos filhos, também herdeiros. Por onde, era conveniente que, por meio
daquele que é naturalmente Filho, os homens participassem, por adoção, da semelhança dessa filiação,
como o Apóstolo o diz no mesmo lugar: Os que ele conheceu. na sua presciência também os
predestinou para serem conformes à imagem de seu Filho.
Em terceiro lugar, a razão dessa conveniência pode ser deduzida do pecado dos nossos primeiros pais, a
que a Encarnação veio dar remédio. Pois, o primeiro homem pecou desejando a ciência do bem e do
mal. Por isso foi conveniente que, pelo Verbo da Verdadeira sabedoria, o homem voltasse para Deus, ele
que pelo desordenado desejo da ciência se afastara de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não há nada de que a malícia humana não possa abusar,
pois abusa da própria bondade de Deus, segundo aquilo do Apóstolo: Acaso desprezas tu as riquezas da
sua bondade? Por onde, mesmo se a pessoa do Padre fosse a encarnada, o homem poderia daí tirar
alguma ocasião de erro, como se o Filho não pudesse ser suficiente para reparar a natureza humana.

RESPOSTA À SEGUNDA. — A primeira criação das coisas foi feita pelo poder de Deus Padre, pelo Verbo.
Donde, a nova criação deveria ser feita pelo poder de Deus Padre, para que esta nova criação
respondesse à criação conforme aquilo do Apóstolo: Deus estava em Cristo reconciliando o mundo
consigo.

RESPOSTA À TERCEIRA. — É próprio ao Espírito Santo ser o dom do Pai e do Filho. Ora, a remissão dos
pecados se faz pelo Espírito Santo, como pelo dom de Deus. Por isso foi conveniente, para a justificação
dos homens, que se encarnasse o Filho, do qual o Espírito Santo é o dom.