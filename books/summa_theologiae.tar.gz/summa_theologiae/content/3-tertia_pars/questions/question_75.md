# Questão 75: Da conversão do pão e do vinho no corpo e no sangue de Cristo
Em seguida devemos tratar da conversão do pão e do vinho no corpo e no sangue de Cristo.
E nesta questão discutem-se oito artigos:

## Art. 1 — Se neste sacramento está o corpo de Cristo verdadeiramente ou se só em figura e como em sinal.
O primeiro discute-se assim. — Parece que neste sacramento não está o corpo de Cristo
verdadeiramente, mas só em forma e como em sinal.

1. — Pois, refere o Evangelho, que tendo o Senhor dito - Se não comerdes a carne do Filho do homem e
beberdes o seu sangue, etc. - muitos dos seus discípulos, ouvindo isto, disseram: duro é este discurso, a
que Cristo replicou: O espírito é o que vivifica; a carne para nada aproveita. Como se dissesse, segundo a
exposição de Agostinho: Entendei o que falei, em sentido espiritual. Não havereis de comer este corpo
que vedes, nem haveis de beber o sangue que hão de derramar os que me vão crucificar. É de um
sacramento que vos falei. Entendei em sentido espiritual a expressão - vos vivificará, a carne para nada
aproveita.

2. Demais. — O Evangelho diz: Eu estou convosco todos os dias, até a consumação do século. Expondo o
que, Agostinho diz: Até que o século termine Deus está no céu, contudo está conosco a verdade do
Senhor. Pois, o corpo com que ressurgiu há de necessàriamente estar num lugar; mas a sua verdade
difundiu-se por toda parte. Logo, o corpo de Cristo não está verdadeiramente neste sacramento, mas só
como em sinal.

3. Demais. — Nenhum corpo pode estar simultaneamente em vários lugares, porque isso nem o anjo o
pode; do contrário, poderia pela mesma razão estar em toda parte. Ora, o corpo de Cristo é
verdadeiramente corpo e está no céu. Logo, parece que não está verdadeiramente no sacramento do
Altar, senão só como em sinal.

4. Demais. — Os sacramentos da Igreja se ordenam à utilidade dos fiéis. Ora, segundo Gregório, numa
Homília, o régulo foi repreendido porque buscava a presença corporal de Cristo; e os Apóstolos também
ficaram impedidos de receber o Espírito Santo, porque estavam acostumados à presença corporal de
Cristo, como o diz Agostinho, àquilo do Evangelho: Se eu não for, não virá a vós o Consolador. Logo,
Cristo não está no Sacramento do Altar por uma presença corpórea.
Mas, em contrário, diz Hilário: Sobre a verdade concernente ao corpo e ao sangue de Cristo, não há
lugar para dúvidas. Pois, conforme a afirmação mesma do Senhor e a nossa fé, a sua carne é
verdadeiramente comida e o seu sangue verdadeiramente bebida. E Ambrósio: Assim como N. S. Jesus
Cristo é verdadeiramente Filho de Deus, assim a carne que recebemos é verdadeiramente carne de
Cristo, e bebida é verdadeiramente o seu sangue.

SOLUÇÃO. — Que o corpo e sangue de Cristo estão verdadeiramente no sacramento do Altar, não
podemos apreendê-la nem pelos sentidos nem pelo intelecto; mas só pela fé, que se apóia na
autoridade divina. Por isso, àquilo do Evangelho - este é o meu corpo, que se dá por vós, diz Cirilo: Não
duvides da verdade disto, mas antes tem fé nas palavras do Salvador, que, sendo a verdade, não mente.
O que é conveniente é primeiro, a perfeição da Lei Nova. Pois, os sacrifícios da Lei Velha só
representavam em figura o verdadeiro sacrifício da paixão de Cristo, segundo aquilo do Apóstolo: A lei,
tendo a sombra dos bens futuros, não a imagem mesma das coisas. Por onde, era necessário, que o
sacrifício da Lei Nova, instituído por Cristo, tivesse mais rico conteúdo, a saber, o próprio Cristo com a
sua paixão, não só simbólica ou figuradamente, mas, também na realidade. E por isso este sacramento,
que contém realmente o próprio Cristo, como diz Dionísio, é perfectivo de todos os outros sacramentos,
nos quais é participada a virtude de Cristo. Em segundo lugar, convém à caridade de Cristo, levado da
qual assumiu um corpo verdadeiramente da nossa natureza, para a nossa salvação. E porque é próprio
por excelência à amizade, conviver com os amigos, como diz o Filósofo, por isso nos reprometeu como
prêmio a sua presença corporal, segundo aquilo do Evangelho: Em qualquer lugar em que estiver o
corpo ali se hão de ajuntar também as águias. Mas, entretanto não nos privou da sua presença corporal
nesta peregrinação, mas nos uniu a si neste sacramento, pelo seu verdadeiro corpo e sangue. Por isso
êle próprio disse: O que come a minha carne e bebe o meu sangue, esse fica em mim e eu nele. Por
onde, este sacramento é o máximo sinal da caridade e o sublevamento da nossa esperança pela união
tão familiar de Cristo conosco. Em terceiro lugar convém à perfeição da fé, que tem por objeto tanto a
divindade de Cristo como a sua humanidade, segundo aquilo do Evangelho: Se credes em Deus crede
também em mim. E como a fé tem por objeto o invisível, do mesmo modo que Cristo nos revela a sua
divindade invisivelmente, assim também neste sacramento nos dá a conhecer a sua carne de um modo
invisível. Por não terem atendido a isto, certos disseram que o corpo e o sangue de Cristo não esta neste
sacramento senão como num sinal. Opinião que deve ser rejeitada como herética, por contrária às
palavras de Cristo. Por isso Berengário, primeiro autor desse erro, foi depois coagido a abjurá-lo e a
confessar a verdade da fé.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Fundados nessa autoridade, os referidos heréticos
foram induzidos em erro, por entenderem mal as palavras de Agostinho. Pois, quando Agostinho diz -
Não havereis de comer este corpo que vedes - não teve a intenção de negar que o corpo de Cristo o
fosse verdadeiramente; mas que não ia ser comido sob a forma em que eles o viam. E pelo que
acrescenta - O sacramento de que vos falei vos vivificará, entendendo-o em sentido espiritual, não quis
dizer que o corpo de Cristo estivesse neste sacramento só na sua significação mística, mas
espiritualmente, isto é, invisivelmente, e por virtude do espírito. Por isso, expondo aquilo do Evangelho -
A carne para nada aproveita - diz: Mas do modo por que o entenderam. Pois, entenderam que a carne
deve ser comida no sentido em que a cortamos do animal morto, ou como é vendida no açougue, e não
no sentido em que nutre o nosso espírito. Que o espírito nela penetre e de muito aproveita; pois, se a
carne de nada aproveitasse, o Verbo não se faria carne para habitar entre nós.

RESPOSTA À SEGUNDA. — As palavras citadas de Agostinho e expressões semelhantes devem entender-
se do corpo de Cristo, enquanto visto na sua figura própria, no sentido em que também o Senhor
mesmo disse: A mim nem sempre me tereis. Invisivelmente porém e sob as espécies deste sacramento,
está em toda parte onde tal sacramento é celebrado.

RESPOSTA À TERCEIRA. — O corpo de Cristo não está neste sacramento do mesmo modo por que um
corpo está num lugar, comensurado pelas dimensões locais; mas de um modo especial próprio a este
sacramento. Por isso dizemos que o corpo de Cristo está em diversos altares, não como em lugares
diversos, mas como no sacramento. Pelo que não entendemos que Cristo ai esteja só como num sinal,
embora o sacramento seja um gênero de sinais. Mas entendemos que ai está o corpo de Cristo, como
dissemos, segundo o modo próprio a este sacramento.

RESPOSTA À QUARTA. - A objeção procede quanto à presença do corpo de Cristo, presente como corpo,
isto é, na sua espécie visível; não porém na sua presença espiritual, isto é, de modo invisível e em
virtude do espírito. Por isso diz Agostinho: Se entendeste espiritualmente as palavras de Cristo
referentes à sua carne, terás em ti o espírito e a vida; se as entendeste carnalmente, também são
espírito e vida, mas não para ti.

## Art. 2 — Se neste sacramento permanece a substância do pão e do vinho depois da consagração.
O segundo discute-se assim. — Parece que neste sacramento permanece a substância do pão e do
vinho depois da consagração.

1. — Pois, Damasceno diz: Por ter o homem o costume de comer o pão e beber o vinho, Deus lhes uniu
a divindade, fazendo deles o seu corpo e o seu sangue. E mais abaixo: O pão da comunhão não é um pão
simples, mas o unido à divindade. Ora, união só há entre causas existentes em ato. Logo, o pão e o vinho
estão simultaneamente neste sacramento com o corpo e o sangue de Cristo.

2. Demais. — Entre os sacramentos de Cristo deve haver conformidade. Ora, nos outros sacramentos
permanece a substância da matéria; assim, no batismo a substância da água e na confirmação, a do
crisma. Logo, neste sacramento permanece a substância do pão e do vinho.

3. Demais. — O pão e o vinho são usados neste sacramento para significar a unidade da Igreja, pois, um
pão é feito de muitos grãos e um vinho de muitos racimos, como diz Agostinho. Ora, isto concerne à
substância mesma do pão e do vinho. Logo a substância do pão e do vinho permanecem neste
sacramento.
Mas, em contrário, diz Ambrósio: Embora vejamos a figura do pão e do vinho, devemos porém crer que,
depois da consagração, não são mais que a carne e o sangue de Cristo.

SOLUÇÃO. — Certos disseram que depois da consagração permanece a substância do pão e do vinho
neste sacramento. - Mas esta opinião não pode sustentar-se. Primeiro, porque destrói a verdade da
Eucaristia, na qual está verdadeiramente o corpo de Cristo; que aí não está antes da consagração. Ora,
um corpo não pode estar onde antes não estava, senão por mudança de lugar, ou pela transformação
de outro corpo nesse. Assim, o fogo começa a existir numa casa ou porque foi para ela levado ou nela
gerado. Mas é manifesto que o corpo de Cristo não começa a estar neste sacramento pelo movimento
local. - Primeiro, porque daí resultaria que deixava de estar no céu. Pois, o que se move localmente não
passa a ocupar novo lugar senão depois de sair donde primeiro estava. - segundo, porque todo corpo
sujeito ao movimento local transpõe todas as posições intermédias. O que neste caso não se pode dizer.
- Terceiro, por ser impossível um movimento do mesmo corpo, localmente movido, terminar
simultaneamente em lugares diversos; ao passo que o corpo de Cristo, neste sacramento, começa a
estar simultaneamente em vários lugares. - Donde se conclui que o corpo de Cristo não pode começar a
existir neste sacramento senão pela transformação nele, da substância do pão. Ora, o que se converte
em outro já não permanece depois da conversão. Donde resulta que, salva a verdade deste sacramento,
a substância do pão não pode permanecer depois da consagração. Segundo, porque tal opinião
contraria a forma deste sacramento, que reza: Isto é o meu corpo. O que não seria verdade se a
substância do pão aí permanecesse; pois, nunca a substância do pão é o corpo de Cristo. Pois então,
devia ter dito: Aqui está o meu corpo. Terceiro, porque contraria à veneração deste sacramento, se nele
existisse alguma substância criada que não pudesse ser adorada com adoração de latria. Quarto, porque
contraria ao rito da Igreja, segundo o qual não é lícito tomar nenhum alimento antes de receber o corpo
de Cristo; e contudo depois de uma hóstia consagrada podemos receber outra. Por onde, devemos
rejeitar esta opinião como herética.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus uniu a sua divindade, isto é, a virtude divina, ao
pão e ao vinho, não por permanecerem neste sacramento, mas para se transformarem no seu corpo e
no seu sangue.

RESPOSTA À SEGUNDA. — Nos outros sacramentos não está Cristo mesmo realmente, como neste. Por
isso nos outros permanece a substância da matéria, mas não neste.

RESPOSTA À TERCEIRA. — As espécies remanescentes neste sacramento, como mais abaixo diremos,
bastam à significação dele; pois, pelos acidentes se conhece a natureza da substância.

## Art. 3 — Se a substância do pão, depois da consagração deste sacramento, se aniquila, ou se resolve na matéria primitiva.
O terceiro discute-se assim. — Parece que a substância do pão, depois da consagração deste
sacramento, se aniquila ou se resolve na matéria primitiva.

1. — Pois, tudo o que é corpóreo deve estar em algum lugar. Ora, a substância do pão, que é corpórea,
não permanece neste sacramento, como se disse; mas não se lhe pode assinalar nenhum lugar onde
esteja. Logo, nada mais é depois da consagração. Portanto, ou se aniquilou ou se resolveu na primitiva
matéria.

2. Demais. — O termo de origem de uma mudança não permanece, senão só na potência da matéria.
Assim, quando do ar nasce o fogo, a forma do ar não permanece senão na potência da matéria; e o
mesmo se dá quando do branco procede o preto. Ora, neste sacramento a substância do pão e a do
vinho se comportam como termo de origem, e o corpo ou o sangue de Cristo, como termo de chegada.
Assim, diz Ambrósio: Antes da consagração há uma espécie, depois, o corpo de Cristo. Logo, feita a
consagração, a substância do pão ou do vinho não permanece, salvo talvez resoluta na sua matéria.

3. Demais. — Necessàriamente um dos contraditórios é verdadeiro. Ora, esta proposição é falsa: Feita a
consagração, a substância do pão ou do vinho é uma realidade. Logo, é verdadeira a proposição: A
substância do pão ou do vinho não é nada.
Mas, em contrário, Agostinho diz: Deus não é causa da tendência para o não-ser. Ora, este sacramento
se consuma pela virtude divina. Logo, neste sacramento não fica aniquilada a substância do pão ou do
vinho.

SOLUÇÃO. — Porque a substância do pão ou do vinho não permanece neste sacramento, certos,
reputando impossível a conversão da substância do pão ou do vinho no corpo ou no sangue de Cristo
afirmaram que pela consagração a substância do pão ou do vinho ou se resolve na matéria primitiva ou
se aniquila. (Cf. Guilherme de Paris, de Euch. cap. I). Ora, a matéria primitiva, em que os corpos mistos
podem resolver-se, são os quatro elementos. Pois, a resolução não pode fazer-se na matéria-prima, de
modo a existir sem a forma, porque a matéria não pode existir sem a forma. Ora, como depois da
consagração, nada permanece sob as espécies do sacramento, a não ser o corpo e o sangue de Cristo,
será necessário concluir que os elementos, em que se resolveu a substância do pão ou do vinho, daí se
separaram pelo movimento local, o que os sentidos perceberiam. - Semelhantemente, também a
substância do pão ou do vinho permanece até o último instante da consagração. Ora, no último instante
da consagração, já aí existe a substância do corpo ou do sangue de Cristo, assim como no último
instante da geração já existe a forma. Por onde não se pode admitir nenhum instante no qual aí exista a
matéria primitiva. Pois, não se pode dizer que a substância do pão ou do vinho se resolva aos poucos na
matéria primitiva, ou saia sucessivamente do lugar das espécies. Porque, se isso começasse a realizar-se
no último instante da sua consagração, simultaneamente existiria numa mesma parte da hóstia o corpo
de Cristo e a substância do pão, o que vai contra o já dito. Se porem isso começasse a realizar-se antes
da consagração, deveríamos admitir um tempo em que numa mesma parte da hóstia não existiria nem a
substância do pão nem o corpo de cristo - o que é inadmissível.
E essa conseqüência eles próprios a ponderaram. E por isso à dijunctiva acrescentaram a hipótese da
aniquilação da substância do pão. - Mas isto também não pode sustentar-se. Porque não podemos
admitir nenhum modo pelo qual o corpo de Cristo comece a estar verdadeiramente neste sacramento,
senão pela conversão nele da substância do pão. Conversão que fica anulada, posta a aniquilação da
substância do pão ou a resolução na primitiva matéria. – Semelhantemente, também não podemos
descobrir a causa de tal resolução ou aniquilação neste sacramento, pois que o efeito do sacramento é
significado pela forma, e nem a resolução nem a significação pelas palavras da forma - Isto é o meu
corpo. Por onde é clara a falsidade da opinião referida.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A substância do pão ou do vinho, feita a consagração,
não permanece nem sob as espécies do sacramento, nem em nenhum outro lugar. Mas dai não se segue
que fique aniquilada, pois se converte no corpo de Cristo. Como não se segue que o ar, donde se gera o
fogo, desapareça, porque não ocupa o lugar onde está o fogo, nem nenhum outro.

RESPOSTA À SEGUNDA. — A forma termo de origem, não se converte noutra forma, mas uma sucede à
outra, no sujeito; e portanto a primeira forma não permanece senão na potência da matéria. Ora, no
caso vertente, a substância do pão se converte no corpo de Cristo, como dissemos. Logo, a objeção não
colhe.

RESPOSTA À TERCEIRA. — Embora depois da consagração seja falsa a proposição - A substância do pão
é uma realidade - contudo o em que a substância do pão se converteu é uma realidade. E, portanto a
substância do pão não ficou aniquilada.

## Art. 4 — Se o pão pode converter-se no corpo de Cristo.
O quarto discute-se assim. — Parece que o pão não pode converter-se no corpo de Cristo.

1. — Pois, a conversão é uma mudança. Ora. toda mudança supõe um sujeito anteriormente em
potência e depois um ato; porque, como diz Aristóteles, o movimento é o ato do ser existente em
potência. Ora, não é possível haver nenhum sujeito da substância do pão e do corpo de Cristo, porque é
da essência da substância não existir num sujeito, como o diz Aristóteles. Logo, não é possível a
substância do pão converter-se totalmente no corpo de Cristo.

2. Demais. — A forma de um ser, no qual outro se converteu, começa a existir no primeiro. Assim,
quando o ar se converte no fogo ainda não existente, a forma do fogo começa a existir na matéria do ar;
e semelhantemente, quando o alimento se converte num homem, antes não existente, a forma deste
começa a existir na matéria do alimento. Se, portanto, o pão se converte no corpo de Cristo,
necessàriamente a forma do corpo de Cristo começa a existir na matéria do pão - o que é falso. Logo, o
pão não se converte na substância do corpo de Cristo.

3. Demais. — De seres essencialmente diversos, nunca um se converte em outro; assim, a brancura
nunca vem a ser negrura, mas o sujeito da brancura é que se transforma no da negrura, como diz
Aristóteles. Ora, sendo duas formas contrárias essencialmente diversas, por serem os principias da
diferença formal, também duas matérias signadas são essencialmente diversas, por serem os princípios
da distinção material. Logo, não é possível a matéria do pão vir a ser a matéria pela qual se individua o
corpo de Cristo. E assim, não é possível a substância de tal pão converter-se na substância do corpo de
Cristo.
Mas, em contrário, Eusébio Emisseno diz: Não ter como uma impossível novidade a conversão do que é
terreno e mortal na substância do corpo de Cristo.

SOLUÇÃO. — Como dissemos, está verdadeiramente neste sacramento o corpo de Cristo, nem começa a
existir nele pelo movimento local; porque ai não está como num lugar, conforme do sobredito se
mostra. Donde devemos necessàriamente concluir, que começa a nele existir por ser o resultado da
conversão da substância do pão. Mas esta conversão não é semelhante às conversões naturais, porque
é absolutamente sobrenatural, produzida pelo só poder de Deus. Por isso diz Ambrósio: É claro que a
Virgem gerou fora da ordem da natureza. E no sacramento que celebramos está o corpo nascido da
Virgem. Por que buscas, pois, a ordem da natureza no corpo de Cristo, pois que fora das leis da natureza
nasceu da Virgem N. S. Jesus Cristo? E àquilo do Evangelho: As palavras que eu vos disse, isto é, sobre
este sacramento, são espírito e vida, diz Crisóstomo: Isto é, são espirituais, por nada terem de carnal
nem consequência natural; mas estarem acima de toda necessidade terrestre e das leis deste mundo.
Pois, é manifesto, que todo agente age enquanto atual. Ora, todo agente criado é determinado no seu
ato, por ser de gênero e espécie determinados. Por onde, a ação de todo agente criado recai sobre um
ato determinado. Ora a existência atual e determinada, de um ser, se realiza mediante a sua forma. Por
onde, nenhum agente natural ou criado pode agir senão mudar uma forma. E por isso toda conversão,
feita segundo as leis da natureza, é formal. Ora, Deus é o ato infinito, como estabelecemos na Primeira
Parte. Logo, a sua ação se estende à natureza total do ser. Por onde, não só pode realizar a conversão
formal, de modo que formas diversas se sucedam, no mesmo sujeito; mas a conversão total do ser, de
modo que toda a substância de um se converta totalmente na substância de outro.
E é o que faz o poder divino neste sacramento. Pois, a substância do pão se converte todo na substância
total do corpo de Cristo; e toda a substância do vinho, na substância total do sangue de Cristo. Por onde,
tal conversão não é formal, mas substancial. Nem está contida entre as espécies de movimento natural,
mas pode receber a denominação própria de transubstanciação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe quanto à mutação formal, por ser
próprio à forma existir na matéria ou num sujeito. Mas não, quanto à conversão substancial, implicando
uma certa ordem das substâncias, das quais uma se converte em outra, se realiza, como no sujeito, em
cada substância, como a ordem e o número.

RESPOSTA À SEGUNDA. — A objeção colhe quanto à conversão ou mutação formal; porque, como
dissemos, a forma existe necessàriamente na matéria ou num sujeito. Mas não, quanto à conversão
total da substância, a que não pode mos atribuir nenhum sujeito.

RESPOSTA À TERCEIRA. — O poder de um agente finito não pode mudar uma forma em outra, nem uma
em outra matéria. Mas a virtude de um agente infinito, cuja ação se estende à totalidade do ser, pode
operar essa conversão; porque uma e outra forma e uma e outra matéria têm a natureza comum de ser;
e a entidade de uma pode o Autor do ser converter na entidade de outra, desaparecendo a diferença
que a distinguia desta.

## Art. 5 — Se neste sacramento permanecem os acidentes do pão e do vinho.
O quinto discute-se assim. — Parece que neste sacramento não permanecem os acidentes do pão e do
vinho.

1. — Pois, removido o anterior, removido fica o posterior. Ora, a substância é naturalmente anterior ao
acidente, como o prova Aristóteles. Como, portanto, depois da consagração, não permanece a
substância do pão neste sacramento, parece que não lhe podem permanecer os acidentes.

2. Demais. — No sacramento da verdade não pode haver nenhum engano. Ora, pelos acidentes
julgamos da substância. Logo, parece que o nosso juízo se engana se, permanecendo os acidentes não
permanece a substância do pão. Logo, não pode ser tal conveniente a este sacramento.

3. Demais. — Embora a nossa fé não dependa da razão, não é, contudo contrária, mas superior a ela,
como se disse no principio desta obra. Ora, a nossa razão se apóia em dados dos sentidos. Logo, a nossa
fé não deve ser contrária aos sentidos. Mas, é contrária a eles, porque, onde julgam haver pão, a nossa
fé crê que está a substância do corpo de Cristo. Logo, não é conveniente a este sacramento que os
acidentes do pão permaneçam sujeitos aos sentidos e não, a substância do pão.

4. Demais. — O que permanece, depois da conversão, é o sujeito da mutação. Se, pois, os acidentes do
pão permanecem depois da conversão, os próprios acidentes é que seriam o sujeito da conversão. Ora,
tal é impossível, pois, não há acidente de acidente. Logo, neste sacramento devem permanecer os
acidentes do pão e do vinho.
Mas, em contrário, Agostinho diz: Nós, nas espécies do pão e do vinho, que vemos, honramos as
realidades invisíveis da carne e do sangue.

SOLUÇÃO. — Percebemos pelos sentidos que, feita a consagração, permanecem os acidentes do pão e
do vinho. O que a Divina Providência racionalmente o faz. - Primeiro, porque não costumamos os
homens, antes temos horror, de comer a carne e beber o sangue humano. E por isso são nos propostos,
para que os tomemos, a carne e o sangue de Cristo, sob as espécies do pão e do vinho, de que mais
frequentemente nos servimos. - Segundo, para este sacramento não vir a ser a irrisão dos infiéis, se
comêssemos a N. Senhor, sob espécie própria. Terceiro, para nos aproveitar ao mérito da fé o
comermos invisivelmente o corpo e o sangue do Senhor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz o livro Das causas, um efeito depende mais da
causa primeira que da segunda. Por isso, o poder de Deus causa primeira de tudo, pode fazer com que
permaneça o posterior, desaparecido o anterior.

RESPOSTA À SEGUNDA. — Neste sacramento não há nenhum engano, pois, nele estão verdadeiros
acidentes, percebidos pelos sentidos. Pois, o intelecto, cujo objeto próprio é a substância, como diz
Aristóteles, é preservado do engano pela fé.
Donde se deduz a RESPOSTA À TERCEIRA. — Pois, a fé não é contrária ao sentido, mas tem por objeto o
que os sentidos não atingem.

RESPOSTA À QUARTA. — Esta conversão não tem sujeito próprio, como se disse. Mas, os acidentes
remanescentes conservam alguma semelhança do sujeito.

## Art. 6 — Se feita a consagração, remanesce neste sacramento a forma substancial do pão.
O sexto discute-se assim. — Parece que, feita a consagração, remanesce neste sacramento a forma
substancial do pão.

1. — Pois, como se disse, feita a consagração, remanescem os acidentes. Ora, o pão, sendo um produto
artificial, também a sua forma é acidental. Logo, remanesce, feita a consagração.

2. Demais. — A forma do corpo de Cristo é a alma, pois, como diz Aristóteles, a alma é o ato do corpo
físico, tendo a vida em potência. Ora, não se pode dizer que a forma substancial do pão se converta na
alma. Logo, remanesce, feita a consagração.

3. Demais. — A operação própria de um ser resulta da sua forma substancial. Ora, o remanescente neste
sacramento nutre, e produz todos os efeitos produzidos pelo pão real. Logo, a forma substancial do pão
permanece feita a consagração.
Mas em contrário. - A forma substancial do pão faz parte da substância do pão. Ora, a substância do pão
se converte no Corpo de Cristo, como se disse. Logo, a forma substancial do pão não permanece.

SOLUÇÃO. — Certos disseram que depois da consagração, não só permanecem os acidentes do pão,
mas também a forma substancial dele. Mas isto não pode ser. Primeiro, porque se a forma substancial
do pão permanecesse só a matéria do pão é que se converteria no corpo de Cristo. Donde a conclusão,
que não se converteria totalmente no corpo de Cristo, mas na matéria dele. O que repugna à fórmula do
sacramento que reza: Isto é o meu corpo. - Segundo, porque se a forma substancial do pão
permanecesse, ou permaneceria na matéria ou separada da matéria: ora, a primeira alternativa não
pode ser. Porque se permanecesse na matéria do pão, então a substância do pão permaneceria
totalmente,- o que vai contra o que já dissemos. E em outra matéria não poderia permanecer, porque
uma forma própria não existe senão na matéria própria. Se porem permanecesse separada da matéria,
então seria uma forma inteligível em ato, e também inteligente, pois, tais são todas as formas separadas
da matéria: - Terceiro, tal seria inconveniente a este sacramento. Pois, os acidentes do pão neste
sacramento permanecem para, sob eles, ser visto o corpo de Cristo, mas não na sua espécie própria,
como se disse. Donde devemos concluir que a forma substancial do pão não permanece.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede uma produção da arte ter forma, não
acidental, mas substancial: assim, a arte pode produzir rãs e serpentes. Mas tal forma a arte não na
produz por virtude própria, senão em virtude dos princípios naturais. E deste modo produz a forma
substancial do pão, em virtude do fogo, que coze a matéria feita de farinha e água.

RESPOSTA À SEGUNDA. — A alma é a forma do corpo, que lhe dá a ordem total do ser perfeito: o ser, o
ser corpóreo, o ser animado e assim por diante. Por onde, a forma do pão se converte na forma do
corpo de Cristo, enquanto lhe dá o ser corpóreo, não porem enquanto lhe dá o ser animado de uma
determinada alma.

RESPOSTA À TERCEIRA. — Dos efeitos do pão uns dele resultam em razão dos acidentes, como o de
afetar os nossos sentidos. E tais efeitos os produzem as espécies do pão, depois da consagração, por
causa dos seus acidentes remanescentes. Mas outros efeitos o pão os produz, ou em razão da matéria -
tal a sua conversão em outro ser; ou em razão da sua forma substancial - tal o resultante da sua espécie,
como o de nos alimentar a vida. E tais efeitos os encontramos neste sacramento, não em virtude da
forma ou da matéria, que permanecem, mas por serem milagrosamente conferidos aos próprios
acidentes, como diremos mais abaixo.

## Art. 7 — Se a conversão de que se trata se faz instantânea ou sucessivamente.
O sétimo discute-se assim. — Parece que a conversão de que se trata não se faz instantânea, mas
sucessivamente.

1. — Pois, nessa conversão existe primeiro, a substância do pão e, depois, a substância do corpo de
Cristo. Logo, uma e outra existe não num mesmo instante, mas em dois. Ora, entre dois instantes
quaisquer há um tempo intermédio. Logo, há de necessàriamente essa conversão operar-se no tempo
sucessivo que medeia entre o último instante, em que ainda existe o pão, e o primeiro instante, em que
já aí existe o corpo de Cristo.

2. Demais. — Toda conversão implica o vir a ser e o ser feito. Ora, um não se identifica com o outro,
pois, o vir a ser não existe; e o feito já deixou de existir. Logo, nesta conversão há anterioridade e
posterioridade. E, portanto não pode ser instantânea, mas é sucessiva.

3. Demais. — Ambrósio diz que este sacramento se celebra pela palavra de Cristo. Ora, a palavra de
Cristo é proferida sucessivamente. Logo, esta conversão se opera sucessivamente.
Mas, em contrário, esta conversão se opera pelo poder infinito, cuja operação é subitânea.

SOLUÇÃO. — Uma mudança pode ser instantânea por três razões. - De um modo, por parte da forma,
termo da mutação. Se, pois, houver uma forma susceptível de mais e de menos, como a saúde, o sujeito
a recebe sucessivamente. Ora, a forma substancial, não sendo susceptível de mais nem de menos, é
recebida pela matéria instantaneamente. - De outro modo, por parte do sujeito, que às vezes é
preparado sucessivamente para receber a forma. Por isso a água se aquece sucessivamente. Mas
quando já o sujeito está na disposição última para receber a forma, recebe-a instantaneamente. Assim,
um corpo diáfano é iluminado subitamente. - De um terceiro modo, quando o agente tem um poder
infinito pode dispor imediatamente a matéria, para receber a forma. Assim, refere o Evangelho, que
quando Cristo disse: Epheta, que quer dizer - abre-te, no mesmo instante se abriram os olhos do
paciente e se lhe soltou a prisão da língua.
E, por estas três razões, a conversão de que se trata é instantânea. - Primeiro, porque a substância do
corpo de Cristo, em que termina esta conversão, não é susceptível de mais nem de menos. - Segundo,
porque nesta conversão não há nenhum sujeito preparado sucessivamente. - Terceiro, porque a
operação resulta do poder infinito de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Certos (como Alberto Magno e S. Boaventura) não
concedem, absolutamente falando, que entre dois instantes quaisquer haja um tempo intermediário.
Isto, dizem se dá com dois instantes referidos ao mesmo movimento; não porem com dois instantes
relativos a termos diversos. Por onde, entre o instante que mede o fim do repouso, e outro instante que
mede o princípio do movimento, não há tempo intermediário. - Mas nisto se enganam. Porque a
unidade do tempo e do instante, ou ainda a pluralidade deles, não dependem de movimentos
quaisquer, mas do movimento do céu, medida de todos os movimentos e repouso. Por isso outros o
concedem, em se tratando do tempo que mede o movimento dependente do movimento do céu. Mas
há certos movimentos não dependentes do movimento do céu nem por este medidos, como na
Primeira Parte dissemos, dos movimentos dos anjos. Por onde, entre esses dois instantes,
correspondentes aos referidos movimentos, não há tempo intermediário. - Mas isto não se dá no caso
vertente. Porque, embora a conversão, de que se trata não dependa em si mesma do movimento do
céu, depende porém da prol ação de certas palavras, que necessàriamente há de medir-se pelo
movimento do céu. E, portanto, é forçoso haver um tempo médio entre dois instantes determinados
quaisquer na conversão em questão.
Por isso outros dizem, que o instante em que por último existe o pão e o em que primeiro existe o corpo
de Cristo, são por certo dois, relativamente ao medido, mas são um só relativamente ao tempo que os
mede; assim como quando duas linhas se tocam, são dois os pontos pertencentes a duas linhas, mas
apenas um ponto da parte da linha continente. - Mas este símile não colhe. Porque o instante e o tempo
não são medida intrínseca aos movimentos particulares, como a linha e o ponto o são, dos corpos; mas
são uma medida extrínseca, como o lugar, para os corpos.
Donde, outros opinam pela identidade entre o instante e a realidade, embora difiram racionalmente. -
Mas, segundo esta opinião, os contrários existiriam real e simultaneamente. Pois, a diversidade de razão
não introduz nenhuma variação na realidade. Portanto, devemos concluir, que esta conversão, como
dissemos, se opera pelas palavras de Cristo, proferidas pelo sacerdote, de modo que o instante último
da prolação das palavras é o primeiro da existência do corpo de Cristo no sacramento, havendo ai, em
todo o tempo precedente, a substância do pão. Em cujo tempo não devemos supor nenhum instante
proximamente precedente ao último, porque o tempo não se compõe de instantes consecutivos uns aos
outros, como o prova Aristóteles. Portanto, devemos por certo admitir um primeiro instante da
existência do corpo de Cristo, mas não um último instante, em que existe a substância do pão; mas sim,
um último tempo. E o mesmo se dá nas mutações naturais, como está claro no Filósofo.

RESPOSTA À SEGUNDA. — Nas mutações instantâneas, vir a ser e ser feito são simultâneos, assim como
simultâneos são o iluminar-se e o estar iluminado. Pois, em tais casos, ser feito, diremos do que já
existe; e vir a ser, do que não existia antes.

RESPOSTA À TERCEIRA. — Esta conversão, como se disse, se opera no último instante da prolação das
palavras; porque então se completa a significação delas, que é eficaz nas formas dos sacramentos.
Donde não se segue que esta conversão seja sucessiva.

## Art. 8 — Se é falsa a proposição: o pão se torna no corpo de Cristo.
O oitavo discute-se assim. — Parece falsa a proposição: O pão se torna no corpo de Cristo.

1. — Pois, o de que outra coisa se faz também dizemos que nesta se torna, mas não ao inverso. Assim,
dizemos que do branco se faz o negro e que o branco se torna negro. Mas, embora digamos que um
homem se fez negro, contudo não dizemos que do homem se faça o negro, como está claro em
Aristóteles. Se portanto, é verdade que do pão se faz o corpo de Cristo, será verdade dizer-se que o pão
se torna no corpo de Cristo. O que é falso, pois o pão não é sujeito da facção, mas é antes o termo dela.
Logo, não se diz com verdade, que do pão se faz o corpo de Cristo.

2. Demais. — O devir se termina no ser ou no ser feito. Ora a proposição seguinte nunca é verdadeira: O
pão é o corpo de Cristo ou, o pão foi feito o corpo de Cristo; ou ainda, o pão será o corpo de Cristo.
Logo, parece que também esta não é verdadeira: Do pão se faz o corpo de Cristo.

3. Demais. — Tudo aquilo, de que outra causa se faz, nesta se converte. Ora, esta proposição é falsa: O
pão se converte no corpo de Cristo, porque tal conversão seria mais miraculosa que a criação, na qual,
contudo não se diz, que o não ser se convertesse no ser. Logo, resulta que também esta é falsa: Do pão
se faz o corpo de Cristo.

4. Demais. — Aquilo de que uma coisa se faz pode ser tal coisa. Ora, esta é falsa: O pão pode ser o corpo
de Cristo. Logo, também est'outra o é: Do pão se, faz o corpo de Cristo.
Mas, em contrário, diz Ambrósio: Quando se opera a consagração do pão se faz o corpo de Cristo.

SOLUÇÃO. — A conversão do pão no corpo de Cristo, de certo modo convém com a criação e a
transmutação natural; e de certo outro, difere de ambas. Pois, é comum a essas três ordens de termos o
ser um consecutivo ao outro, a saber: na criação, o ser depois do não ser; neste sacramento, o corpo de
Cristo, depois da substância do pão; na transmutação natural, o branco depois do preto ou o fogo
depois do ar. É que esses termos não são simultâneos. Ora, a conversão de que agora falamos convém
com a criação, porque em nenhuma delas há um sujeito comum a um e outros dos extremos. Cujo
contrário aparece em toda transmutação natural. Por outro lado, esta conversão tem dupla
conveniência com a transmutação natural, embora não semelhantemente. - Primeiro, porque em uma e
outra um dos extremos se converte no outro, como o pão, no corpo de Cristo e o ar, no fogo: mas o não
ser não se converte no ser. Essa conversão, porém de um extremo a outro não se processa do mesmo
modo em ambos os casos. Pois, neste sacramento, toda substância do pão se transforma totalmente no
corpo de Cristo; ao passo que nas transmutações naturais a matéria de um corpo recebe a forma do
outro, depois de ter perdido a forma anterior. - A segunda conveniência está que em ambas as
transformações, há algo que não muda o que não acontece na criação. Mas diferentemente; pois, nas
transmutações naturais permanece a mesma a matéria ou o sujeito; ao passo que neste sacramento os
acidentes é que permanecem os mesmos. Donde podemos concluir os diferentes modos com que
nesses casos devemos predicar. Pois, não existindo os extremos simultaneamente em nenhuma das três
transformações referidas, por isso em nenhuma delas pode um extremo ser predicado de outro pelo
verbo substantivo no tempo presente. Assim, não dizemos - o não ser, é ser ou o pão é o corpo de
Cristo, ou o ar é fogo, ou o preto é branco.
Mas, levando em conta a ordem dos extremos, podemos usar em todas estas proposições, da
preposição de (ex), designativa da ordem. Assim, podemos própria e verdadeiramente dizer: do não ser
se faz o ser; e, do pão, o corpo de Cristo; e, do ar, o fogo; ou, do branco o negro. Como, porém; na
criação um extremo não se transforma no outro não podemos nela, usar da palavra - conversão, de
modo a dizermos que o não ser se converte no ser. Palavra porem de que podemos usar neste
sacramento, bem como nas transformações naturais. Mas como neste sacramento uma substância se
muda totalmente em outra, por isso, essa conversão se chama propriamente transsubstanciação. Além
disso, como a essa conversão não podemos atribuir nenhum sujeito, o que se verifica, nas
transformações naturais, em relação ao sujeito, não o podemos atribuir, nesta conversão. - E primeiro, é
manifesto, que do sujeito resulta a possibilidade para termos opostos; em razão do que, dizemos, que o
branco pode ser preto, e, o ar pode ser fogo. Embora esta última proposição não seja tão própria como
a primeira; porque o sujeito de branco, que tem a possibilidade de vir a ser a negrura, é a substância do
branco na sua totalidade, pois a brancura não é parte dela; ao passo que o sujeito da forma do ar é
parte dele; por isso, quando dizemos - o ar pode ser fogo, isso é verdade em razão da parte, por
sinédoque. Mas, na conversão eucarística, e semelhantemente na criação, por não haver nenhum
sujeito, não dizemos que um extremo pode se transformar no outro; assim, que o não-ser possa se
transformar no ser, ou que o pão possa ser o corpo de Cristo. E pela mesma razão não podemos
propriamente dizer que do não ser se faça o ser, ou que o pão se torne no corpo de Cristo, porque a
preposição de (de) designa a causa consubstancial; e essa consubstancialidade dos extremos, nas
transmutações naturais, consiste na sua conveniência no mesmo sujeito. - E por semelhante razão, não
se pode conceder que o pão será o corpo de Cristo, ou que se faça o corpo de Cristo, como também não
se concede, na criação, que o não ser será o ser, ou que o não ser se faça o ser. Porque esses modos de
falar se verificam nas transmutações naturais em razão do sujeito, por exemplo, quando dizemos - o
branco se faz negro, ou, o branco será negro.
Como porem neste sacramento, feita a conversão, ainda há um remanescente, a saber, os acidentes do
pão, como dissemos, algumas dessas locuções podem, por uma certa semelhança, ser concedidas.
Assim; o pão se faz o corpo de Cristo, ou, o pão será o corpo de Cristo, ou do pão se faz o corpo de
Cristo. Entendendo-se pela palavra - pão - não a substância do pão, mas em universal, o conteúdo das
espécies do pão, sob as quais estava primeiro contida a substância do pão e depois, o corpo de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Aquilo de que uma coisa se faz, às vezes importa
simultaneamente o sujeito com um dos extremos da transmutação; assim, quando dizemos - do (ex)
branco se faz o negro. Mas outras vêzes importa só o oposto ou o extremo, como quando dizemos - da
(ex) manhã se faz o dia. E assim também no caso proposto, embora propriamente digamos, que do (ex)
pão se faz o corpo de Cristo, mas não possamos dizer, com propriedade - o pão se faz o corpo de Cristo
salvo por uma certa semelhança, como dissemos.

RESPOSTA À SEGUNDA. — Aquilo, de que alguma coisa se faz, será às vezes essa coisa, por causa do
sujeito que implica. Ora, como a conversão de que se trata, não tem nenhum sujeito, não há
semelhança de razão.

RESPOSTA À TERCEIRA. — Nesta conversão há maiores dificuldades que na criação, onde a única
dificuldade é fazer alguma coisa, do nada; o que porem pertence ao modo próprio de produção da
primeira causa que nenhuma coisa pressupõe. Ao passo que nesta conversão não só é difícil a conversão
de uma totalidade em outra, de modo que nada reste da primeira o que não se dá com o modo comum
de produção de nenhuma causa; mas também outra dificuldade é a permanência dos acidentes,
corrupta a substância. E há ainda muitas outras dificuldades de que a seguir trataremos. Contudo,
empregamos neste sacramento a palavra conversão, não, porém na criação, como dissemos.

RESPOSTA À QUARTA. — Como dissemos, a potência respeita ao sujeito, o que não podemos admitir na
conversão vertente. Por isso não concedemos que o pão, possa ser o corpo de Cristo; pois, esta
conversão não se faz pela potência passiva da criatura, mas pela só potência ativa do Criador.
