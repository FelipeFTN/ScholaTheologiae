# Questão 68: Dos que recebem o batismo
Em seguida devemos tratar dos que recebem o batismo.
E nesta questão discutem-se doze artigos:

## Art. 1 — Se todos estão obrigados a receber o batismo.
O primeiro discute-se assim. — Parece que nem todos estão obrigados a receber o batismo.

1. — Pois, Cristo não veio dificultar aos homens a salvação. Ora, antes do advento de Cristo os homens
podiam salvar-se sem o batismo. Logo, também depois do advento de Cristo.

2. Demais. — O batismo foi instituído sobretudo, como remédio ao pecado original. Ora, o batizado, não
tendo pecado original, não pode transmiti-lo aos filhos. Logo, os filhos dos batizados parece que não
devem ser batizados.

3. Demais. — O batismo é conferido para que, pela graça, sejamos purificados do pecado. Ora, isso o
conseguem os que foram santificados no ventre materno, sem batismo. Logo, esses não estão obrigados
a receber o batismo.
Mas em contrário, o Evangelho: Quem não renascer da água e do Espírito Santo não pode entrar no
reino de Deus. E no livro De Eccl. dogmatibus: Cremos que o caminho da salvação é aberto só aos
batizados.

SOLUÇÃO. — Estamos obrigados ao batismo, sem o que não podemos alcançar a salvação. Ora, é
manifesto que ninguém pode alcançar a salvação senão por Cristo. Donde o dizer o Apóstolo: Assim
como pela desobediência de um só homem foram muitos feitos pecadores, assim também pela
obediência de um só, muitos se tornaram justos. Ora, o batismo é conferido para que, regenerados por
ele, nos incorporemos com Cristo, tornando-nos membros dele. Por isso diz o Apóstolo: Todos os que
fostes batizados em Cristo revestiste-vos de Cristo. Por onde é manifesto que todos estão obrigados ao
batismo e sem ele não nos podemos salvar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nunca os homens puderam salvar-se, mesmo antes da
vinda de Cristo, sem se tornarem seus membros. Porque, como diz a Escritura, nenhum outro nome foi
dado aos homens pela qual nós devamos ser salvos. Ora, antes da vinda de Cristo, os homens se
incorporavam com Cristo pela fé no seu futuro advento; e dessa fé a circuncisão era o sinal, como diz o
Apóstolo. Mas antes de ser instituída a circuncisão, só pela fé, no dizer de Gregório, com a oferenda de
sacrifícios, pelos quais os antigos Patriarcas manifestavam a sua fé, os homens eram incorporados com
Cristo. E também depois do advento de Cristo, os homens se incorporavam com ele pela fé, segundo
aquilo do Apóstolo: Para que Cristo habite pela fé em vossos corações. Mas, a fé numa realidade
presente se manifesta por um sinal diferente do com que se manifestava quando era futura, assim como
por palavras diferentes significamos o presente, o pretérito e o futuro. Por onde, embora o sacramento
mesmo do batismo nem sempre fosse necessário à salvação, contudo a fé, da qual o batismo é o
sacramento, sempre foi necessária.

RESPOSTA À SEGUNDA. — Como se disse na segunda Parte, os batizados são renovados pelo batismo,
em espírito; o corpo porem permanece sujeito à vetustez do pecado conforme àquilo do Apóstolo: O
corpo verdadeiramente está morto pelo pecado, mas o espírito vive pela justificação. E por isso, como
Agostinho o prova, não é batizado tudo quanto há no homem. Ora, é manifesto, que o homem não gera
carnalmente, segundo o espírito, mas segundo a carne. Por onde, os filhos dos batizados nascem com o
pecado original, e portanto, precisam ser batizados.

RESPOSTA À TERCEIRA. — Os santificados no ventre materno alcançam por certo a graça que purifica
do pecado original; nem por isso, contudo, recebem o caráter pelo qual se configuram com Cristo. Por
onde, quem agora fosse santificado no ventre materno teria necessidade de ser batizado a fim de, tendo
recebido o caráter, conformar-se com os outros membros de Cristo.

## Art. 2 — Se nos podemos salvar sem batismo.
O segundo discute-se assim. — Parece que sem batismo ninguém pode salvar-se.

1. — Pois, diz o Senhor: Quem não renascer da água e do Espírito Santo não pode entrar no reino de
Deus. Ora, só se salvam os que entram no reino de Deus. Logo, ninguém pode salvar-se sem o batismo
que nos regenera pela água e pelo Espírito Santo.

2. Demais. — Foi dito: Cremos que nenhum catecúmeno, embora morto com boas obras, alcança a vida
eterna, exceto pelo martírio, que dá a plenitude à virtude do sacramento do batismo. Ora, se alguém
pudesse salvar-se sem batismo, seriam sobretudo os catecúmenos que praticaram boas obras,
possuidores da fé que obra por caridade. Logo, parece que sem batismo ninguém pode salvar-se.

3. Demais. — Como se disse, o sacramento do batismo é necessário à salvação. Ora, necessário é aquilo
sem o que uma coisa não pode existir, como diz Aristóteles. Logo, parece que sem batismo ninguém
pode alcançar a salvação.
Mas, em contrário, Agostinho: Certos receberam, e com proveito, a santificação invisível, fora dos
sacramentos visíveis; mas a santificação visível, que opera o sacramento visível, pode ser conferida,
embora não aproveite sem a santificação invisível. Ora, o sacramento do batismo, sendo uma
santificação visível, sem ele ninguém pode alcançar a santificação, pela santificação invisível.

SOLUÇÃO. — O sacramento do batismo pode faltar-nos de dois modos. - Primeiro realmente e por
vontade, como no caso dos que não foram batizados nem querem sê-lo. E isso implica manifesto
desprezo do sacramento, nos que têm o uso do livre arbítrio. Portanto, aqueles que não receberam o
batismo por essa razão não podem salvar-se; pois, nem mental nem sacramentalmente estão
incorporados com Cristo, causa única da salvação. - De outro modo, pode alguém não ter recebido o
sacramento do batismo, realmente, mas não por desejo. Tal o caso de quem, desejando ser batizado, é
tomado de improviso pela morte, antes de receber o batismo. Mas esse pode alcançar a salvação, sem
ter sido batizado, por causa do desejo do batismo, procedente da fé que obra por caridade, pela qual
Deus nos santifica interiormente pela caridade. Por isso diz Ambrósio, de Valentiniano, morto
catecúmeno: Perdi a quem deveria ser regenerado; mas ele não perdeu a graça que pediu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz a Escritura, o homem vê o que está patente,
mas o Senhor olha para o coração. Ora, quem deseja pelo batismo ser regenerado pela água e pelo
Espírito Santo, é por certo regenerado de coração, embora não corporalmente. Assim, diz o Apóstolo: A
circuncisão do coração é no espírito, não segundo a letra; cujo louvor não vem dos homens, senão de
Deus.

RESPOSTA À SEGUNDA. — Ninguém chega à vida eterna, senão absolvido de toda culpa e reato da
pena. E essa absolvição universal é efeito do batismo e do martírio. Por isso se diz que o martírio dá a
plenitude a todas a ação sacramental do batismo, isto é, quanto à plena libertação da culpa e da pena. O
catecúmeno, pois que tiver o desejo do batismo - porque do contrário não morreria com boas obras -
que não podem existir sem a fé que obra por caridade, esse, morrendo, não chega logo à vida eterna,
mas sofrerá as penas pelos pecados passados. Mas o tal será salvo, se bem desta maneira como por
intervenção do fogo, diz o Apóstolo.

RESPOSTA À TERCEIRA. — Dissemos que o batismo é de necessidade para a salvação, no sentido em
que ninguém pode se salvar sem ao menos ter disso o desejo, o que Deus considera uma realidade
(Agost.)

## Art. 3 — Se o batismo deve ser diferido.
O terceiro discute-se assim. — Parece que o batismo deve ser diferido.

1. — Pois, Leão Papa diz: Dois tempos - o da Páscoa e o de Pentecostes - foram legalmente
estabelecidos pelo Romano Pontífice, para batizar. Por isso advertimos a vossa Dilecção, não confirais
esse sacramento em nenhum outro tempo. Logo, parece que não se deve batizar ninguém logo, mas
diferir o batismo até os tempos preditos.

2. Demais. — O Concílio Agatense dispõe: Os judeus, cuja perfídia frequentemente volta ao vômito, se
quiserem viver dentro das leis católicas, permaneçam com os catecúmenos oito meses, no limiar da
Igreja; e se se reconhecer que vêm de boa fé, enfim mereçam a graça do batismo. Logo, ninguém deve
ser batizado logo, mas o batismo deve ser diferido até certo tempo.

3. Demais. — Diz a Escritura: Todo este fruto se reduz a que seja tirado o pecado. Ora, o pecado se tira
melhor e mesmo diminui, se o batismo for diferido longamente. Primeiro, porque os que pecam depois
do batismo pecam mais gravemente, segundo aquilo do Apóstolo: Quanto maiores tormentos credes
que merece o que tiver em conta de profano o sangue do testamento em que foi santificado, pelo
batismo? Segundo, porque o batismo dele os pecados passados, mas não os futuros; portanto, quanto
mais for diferido, tanto mais pecados apagará. Logo parece que o batismo deve ser diferido o mais
possível.
Mas, em contrário, a Escritura: Não tardes em te converter ao Senhor e não o difiras de dia em dia. Ora;
a perfeita conversão para Deus é a dos regenerados em Cristo pelo batismo. Logo o batismo não deve
ser diferido de um dia para outro.

SOLUÇÃO. — Nesta matéria devemos distinguir se se trata de batismo de infantes ou de adultos. Assim,
se o batizando é uma criança, não deve o batismo ser diferido. - Primeiro, porque não se pode esperar
de crianças uma instrução maior ou uma conversão mais plena. - Segundo, por causa do perigo de
morte: pois, não se lhe pode dar nenhum outro remédio senão o do sacramento do batismo. Ao passo
que os adultos podem supri-lo pelo batismo de desejo, como se disse. Por isso, aos adultos não se lhes
deve conferir o batismo logo depois da conversão, mas é mister diferi-lo ate certo tempo. - Primeiro,
para cautela da Igreja: Não vá enganar-se conferindo o sacramento aos que o recebem simuladamente,
segundo aquilo do Evangelho: Não creiais a todo espírito, mas provai se os espíritos são de Deus. E essa
prova se tira dos que se achegam ao batismo, quando se lhes examinam durante algum tempo a fé e os
costumes. - Segundo tal é necessário para utilidade dos batizados, que precisam de um espaço de
tempo para serem plenamente instruídos na fé e exercitados nas práticas da vida cristã. - Terceiro, é
necessário por uma certa reverência para com o sacramento; assim, a admissão ao batismo nas
solenidades mais principais, da Páscoa e de Pentecostes, faz com que seja recebido mais
devotadamente o sacramento.
Mas essa dilação deve ser posta de parte por duas razões. - Primeiro, quando os que vão ser batizados
mostram-se perfeitamente instruídos na fé e aptos para o batismo; assim Filipe batizou imediatamente
o Eunuco e Pedro, a Cornélio e aos seus companheiros, como refere a Escritura. - Segundo, por
enfermidade ou em perigo de morte. Por isso Leão Papa diz: Os acometidos pela morte, pela doença,
pela guerra, pela perseguição ou em perigo de naufrágio devem ser batizados sem consideração de
tempo.
Quanto aos que, esperando o tempo instituído pela Igreja, foram salteados pela morte, a ponto de lhes
ser impossível receber o batismo esses se salvam, embora pelo fogo, como dissemos. Pecam porem se
dilatarem a recepção do batismo além do tempo instituído pela Igreja, a não ser por uma causa
necessária e com licença dos prelados da Igreja. Contudo esse pecado pode ser delido com os outros
pela subsequente contrição, que faz as vezes do batismo, como dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Esse mandamento de Leão Papa, sobre a observância
dos dois tempos, para o batismo, entende-se dos adultos, salvo em perigo de morte, que sempre se
deve temer nas crianças, como se disse.

RESPOSTA À SEGUNDA. — Essa disposição sobre os judeus a Igreja a estabeleceu como cautela, a fim de
não corromperem a fé dos simples se não se converterem plenamente. E contudo como no mesmo
lugar se aconselha, se antes do tempo prescrito correm perigo de alguma doença, devem ser batizados.

RESPOSTA À TERCEIRA. — O batismo pela graça que confere, não só dele os pecados passados, mas
também nos impede de cometer os futuros. Pois, o que sobretudo é pura desejar é que os homens não
pequem; depois, que os pecados sejam menos graves e que sejam delidos, segundo aquilo da Escritura:
Filhinhos meus, eu vos escrevo estas causas para que não pequeis; mas se algum ainda pecar, temos
como advogado para com o Padre a Jesus Cristo justo; porque ele é a propiciação pelos nossos pecados.

## Art. 4 — Se os pecadores devem ser batizados.
O quarto discute-se assim. Parece que os pecadores devem ser batizados.

1. — Pois, diz a Escritura: Naqueles dias haverá uma fonte patente para a casa de Davi e os habitantes
de Jerusalém, para se lavarem nela as imundícias do pecador e da mulher menstruada - o que se
entende da fonte batismal. Logo parece que o sacramento do batismo deve ser conferido também aos
pecadores.

2. Demais. — O Senhor diz: Os sãos não têm necessidade de médico mas sim os enfermos. Ora, os
pecadores são enfermos. Logo, sendo o batismo o remédio do médico espiritual que é Cristo parece que
aos pecadores deve ser conferido o sacramento do batismo.

3. Demais. — Os pecadores não devem ser privados de nenhum socorro. Ora, os pecadores batizados,
têm um socorro espiritual no próprio caráter batismal, que é uma certa disposição para a graça. Logo,
parece que aos pecadores se deve conferir o sacramento do batismo.
Mas, em contrário, Agostinho: Quem te fez sem ti não te justificará sem ti. Ora, o pecador, não tendo a
vontade disposta, não coopera com Deus. Logo, em vão se lhe confere o batismo para a sua justificação.

SOLUÇÃO. — De dois modos pode um ser pecador. Ou pela mácula e o reato passado. E então deve-se
conferir o sacramento do batismo aos pecadores, pois, foi para isso especialmente instituído, para
purificá-los das suas misérias, segundo aquilo do Apóstolo: Para a purificar, isto é, a Igreja, no batismo
de água pela palavra da vida. Noutro sentido pode um ser considerado pecador pela vontade de pecar
com o propósito de perseverar no pecado. E, a tais pecadores não se lhes deve conferir o sacramento do
batismo. Primeiro, porque pelo batismo nos encorporamos com Cristo, segundo aquilo do Apóstolo:
Todos os que fostes batizados em Cristo revestistes-vos de Cristo. Ora, enquanto alguém está na
vontade de pecar, não pode estar unido a Cristo, segundo aquilo do Apóstolo: Que união pode haver
entre a justiça e a iniquidade? Por isso diz Agostinho: Ninguém que esteja de posse do livre arbítrio pode
começar uma vida nova sem se arrepender da antiga. - Segundo, porque em matéria de obras de Cristo
e da Igreja nada devemos fazer em vão. E vão é o que não consegue o fim visado. Portanto, quem está
na vontade de pecar não pode simultaneamente purificar-se do pecado, que é o fim do batismo; pois
isso seria querer a existência simultânea dos contraditórios. - Terceiro, porque os sinais sacramentais
não devem encerrar nenhuma falsidade. E é falso o sinal a que não corresponde à realidade significada.
Ora, quem vai lavar-se nas águas do batismo dá a entender que se dispõe à ablução interior; o que não
se dá com quem está no propósito de persistir no pecado. Por onde é manifesto que a tais não deve ser
conferido o sacramento do batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa autoridade deve ser entendida dos pecadores que
têm a vontade de deixar o pecado.

RESPOSTA À SEGUNDA. — Cristo, médico espiritual, obra de dois modos. De um modo, interiormente e
por si mesmo. E assim prepara a vontade do homem a querer o bem e a odiar o mal. - De outro modo,
obra pelos seus ministros, conferindo exteriormente os sacramentos. E assim dá a perfeição ao que foi
externamente começado. Por onde, o sacramento do batismo não deve ser conferido senão a quem
manifesta algum sinal de conversão interior; assim como não se dá remédio a um doente senão
enquanto manifesta algum movimento de natureza vital

RESPOSTA À TERCEIRA. — O batismo é o sacramento da fé. Ora, a fé informe não basta à salvação, nem
é mesmo o fundamento desta. Mas só a fé informada, que obra por caridade, como diz Agostinho. Por
onde nem o sacramento do batismo pode conferir a salvação, se existe a vontade de pecar, que exclui a
forma da fé. Pois, pela impressão do caráter batismal não se dispõe à graça quem manifesta a vontade
de pecar. Porque Deus não compele ninguém à virtude, como diz Damasceno.

## Art. 5 — Se aos pecadores batizados se lhes devem impor obras satisfatórias.
O quinto discute-se assim. — Parece que aos pecadores batizados se lhes devem impor obras
satisfatórias.

1. — Pois, a justiça de Deus requer a punição do pecador, pelo seu pecado, conforme a Escritura: De
tudo quanto se comete fará Deus dar no seu juízo. Ora, as obras satisfatórias são impostas aos
pecadores como penas dos pecados passados. Logo, parece que aos pecadores batizados se lhes devem
impor obras satisfatórias.

2. Demais. — Pelas obras satisfatórias os pecadores recém-convertidos se exercitam na justiça, livrando-
se das ocasiões de pecar; pois, satisfazer é destruir as causas dos pecados e não mais lhes dar entrada.
Ora, isto sobretudo é o necessário aos recém-batizados. Logo, parece que aos batiza dos se lhes deve
impor obras satisfatórias.

3. Demais. — Não devemos satisfazer menos a Deus que ao próximo. Ora, aos recém-batizados se lhes
impõe a satisfação pelos próximos, que lesaram. Logo, também se lhes deve impor que satisfaçam a
Deus pelas obras de penitência.
Mas, em contrário, Ambrósio, aquilo do Apóstolo - Os dons e a vocação de Deus são imutáveis - diz: A
graça de Deus no batismo não requer gemidos nem prantos, nem qualquer obra; mas só a fé e tudo dá
gratuitamente.

SOLUÇÃO. — Como diz o Apóstolo, todos os que fomos batizados em Cristo fomos batizados na sua
morte; porque nós fomos sepultados com ele para morrer ao pecado pelo batismo. De modo que pelo
batismo nós nos incorporamos com a morte mesma de Cristo. Ora, é manifesto pelo sobredito que a
morte de Cristo foi suficientemente satisfatória pelos pecados, não só nossos, mas também de todo o
mundo, como diz o Evangelho. Portanto ao batizado não se lhe deve impor, por quaisquer pecados,
nenhuma satisfação. Pois isso seria fazer injúria à paixão e à morte de Cristo, como se ela não fosse
suficiente à plenária satisfação pelos pecados dos batizados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho, o valor do batismo está em
incorporar os batizados com Cristo e torná-los seus membros. Por isso a pena mesma sofrida por Cristo
foi satisfatória pelos pecados dos batizados, assim como a pena de um membro pode ser satisfatória
pelo pecado de outro. Donde o dizer a Escritura: Verdadeiramente ele foi o que tomou sobre si as
nossas fraquezas e ele mesmo carregou com as nossas dores.

RESPOSTA À SEGUNDA. — Os recém-batizados devem exercitar-se na justiça, mas por obras fáceis e
não por obras penais, a fim de, começando pelo como leite de um fácil exercício, chegarem à prática da
perfeição, conforme o diz a Glosa àquilo da Escritura: Como o menino apartado já do leite da mãe. Por
isso o Senhor excusou do jejum os seus discípulos recém-convertidos, como o refere o Evangelho. E é o
que diz a Escritura: Como meninos recém-nascidos desejai o leite racional, sem dolo, para com ele
crescerdes para a salvação.

RESPOSTA À TERCEIRA. — Restituir o que se retirou aos próximos indevidamente e dar-lhes satisfação
pelas injustiças contra eles cometidas é cessar de pecar. Pois, o fato mesmo de reter o alheio e não
satisfazer ao próximo lesado é pecado. Por isso, aos pecadores batizados se lhes deve impor que
satisfaçam aos próximos assim como que deixem de pecar. Não se lhes deve impor porém nenhuma
pena, a sofrer pelos pecados passados.

## Art. 6 — Se os pecadores que se apresentam ao batismo devem confessar os seus pecados.
O sexto discute-se assim. — Parece que os pecadores, que se apresentam ao batismo, devem
confessar os seus pecados.

1. — Pois, diz o Evangelho, que muitos, confessando os seus pecados, eram batizados no Jordão por
João. Ora, o batismo de Cristo é mais perfeito que o de João. Logo, com muito maior razão, os batizados
pelo batismo de Cristo devem confessar os seus pecados.

2. Demais. — A Escritura diz: Aquele que esconde as suas maldades não será bem sucedido; aquele
porém que as confessar e retirar delas alcançará misericórdia. Ora, somos batizados para alcançar
misericórdia pelos nossos pecados. Logo, os batizados devem confessar os seus pecados.

3. Demais. — A penitência é necessária antes do batismo, segundo o diz a Escritura: Fazei penitência e
cada um de vós seja batizado. Ora, a confissão faz parte da penitência. Logo, parece que a confissão dos
pecados é necessária antes do batismo.
Mas, em contrário a confissão dos pecadores deve ser acompanhada de lágrimas. Assim, diz Agostinho:
Toda esta inconstância deve ser confessada e chorada. Ora, como diz Ambrósio (Anón.), a graça de Deus
no batismo não requer gemidos nem prantos. Logo, aos que vão ser batizados não se exige a confissão
dos pecados.

SOLUÇÃO. — Dupla é a confissão dos pecados. - Uma, interior, feita a Deus. E essa é necessária antes do
batismo, de modo que, repassando os nossos pecados deles nos arrependemos. Pois, não pode começar
vida nova quem não faz penitência da vida passada, como diz Agostinho. Outra: porém, é a confissão
exterior dos pecados, feita ao sacerdote. E essa não é necessária antes do batismo. - Primeiro, porque
essa confissão, sendo feita ao ministro, pertence ao sacramento da penitência; o que não é requerido
antes do batismo, porta de todos os sacramentos. - Segundo porque a confissão exterior feita ao
sacerdote tem por fim a absolvição dos pecados dada por ele ao confitente, ao mesmo tempo que o
adstringe às obras satisfatórias, as quais não se devem impor aos que vão ser batizados, como dissemos.
Nem além disso os batizados precisam da remissão dos pecados pelas chaves da Igreja, pois, a eles tudo
fica perdoado pelo batismo. - Terceiro, porque a própria confissão feita particularmente a um homem é
penosa, por causa da vergonha do confitente. Ora, ao batizado não se lhe impõe nenhuma pena
exterior. Portanto, não devem eles fazer uma confissão especial dos pecados; mas basta a geral, que
fazem quando, segundo o rito da Igreja, renunciam a Satanás e a todas as suas obras. E deste modo, diz
uma Glosa de Mateus, que batismo de João dá aos que vão ser batizados exemplo da confissão dos
pecados e da promessa de melhor vida. - Mas, se quem se apresenta ao batismo quiser por devoção
confessar os pecados, devia-se-lhe ouvir a confissão; não para que se lhes impusesse uma satisfação,
mas para se lhe dar direção espiritual a fim de combaterem os pecados habituais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O batismo de João não perdoava os pecados, mas era
um batismo de penitência. Por isso os que iam receber esse batismo convenientemente confessavam os
pecados, a fim de, segundo a qualidade destes, se lhes determinar a penitência. Ao passo que o batismo
de Cristo não tem nenhuma penitência exterior, como diz Ambrósia. Logo, o símile não colhe.

RESPOSTA À SEGUNDA. — Aos batizados basta a confissão interior feita a Deus e também a exterior
geral, para receberem a direção e alcançarem misericórdia. Nem é necessária uma confissão exterior
especial, como dissemos.

RESPOSTA À TERCEIRA. — A confissão faz parte da penitência sacramental e não é necessária antes do
batismo, como dissemos, mas é necessária a virtude da penitência interna.

## Art. 7 — Se da parte do batizado é necessário a intenção de receber o sacramento do batismo.
O sétimo discute-se assim. — Parece que da parte do batizado não é necessária a intenção de receber
o sacramento do batismo.

1. — Pois, o batizado se comporta como paciente no sacramento. Ora, a intenção é necessária da parte
do agente e não da do paciente. Logo, parece que da parte do batizado não é necessária a intenção de
receber o batismo.

2. Demais. — Se se omitir um elemento essencial do batismo, por exemplo, a invocação trinitária é
preciso renovar o batismo como se disse. Ora, ninguém deve ser rebatizado por não ter tido a intenção
de receber o batismo. Do contrário, como não se pode julgar da intenção do batizado, qualquer poderia
pedir que, por falta de intenção, se lhe reiterasse o batismo. Logo, parece que não é necessária a
intenção, da parte do batizado, para receber o batismo.

3. Demais. — O batismo é remédio contra o pecado original. Ora, o pecado original se contrai sem
intenção do nascido. Logo, parece que o batismo não requer a intenção, por parte do batizado.
Mas, em contrário, segundo o rito da Igreja os que se apresentam ao batismo confessam que o pedem à
Igreja. E assim revelam a intenção de recebê-lo.

SOLUÇÃO. — Pelo batismo morremos à vida passada do pecado e começamos vida nova, segundo
aquilo do Apóstolo: Nós fomos sepultados com Cristo para morrer ao pecado pelo batismo; para que
como Cristo ressurgiu dos mortos pela glória do Padre, assim também nós andemos em novidade de
vida. Portanto, assim como para morrermos à vida passada é necessária, em quem tem o uso do livre
arbítrio, segundo Agostinho, a vontade pela qual se arrependa da antiga vida, assim também é
necessária a vontade de começar uma vida nova, cujo princípio é o fato mesmo de receber o
sacramento. Por isso, da parte do batizado, é necessária à vontade ou a intenção de receber o
sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na justificação pelo batismo a paixão não é coacta, mas
voluntária. Por isso é necessária a intenção de receber o que é dado.

RESPOSTA À SEGUNDA. — O adulto que não tivesse a intenção de receber o batismo devia ser
rebatizado. Se porém não se lhe soubesse da intenção se lhe deveria dizer: Se não és batizado eu te
batizo.

RESPOSTA À TERCEIRA. — O batismo não só é um remédio contra o pecado original, mas também
contra os atuais, causados pela vontade e pela intenção.

## Art. 8 — Se a fé é necessária da parte do batizado.
O oitavo discute-se assim. — Parece que a fé é necessária da parte do batizado.

1. Pois, o sacramento do batismo foi instituído por Cristo. Ora, Cristo, quando determinou a forma do
batismo, exigiu antes a fé: Quem crer e for batizado será salvo. Logo, parece que sem fé não pode haver
batismo.

2. Demais. — Nada há de vão nos sacramentos da Igreja. Ora, segundo o rito da Igreja, quem recebe o
batismo é interrogado sobre a fé, quando se lhe pergunta: Crês em Deus Padre omnipotente? Logo,
parece que a fé é necessária ao batismo.

3. Demais. — Para o batismo é necessária a intenção de receber o sacramento. Ora, isso se não pode dar
e sem uma fé perfeita, por ser o batismo o sacramento dessa fé, pois nos incorpora com Cristo, como diz
Agostinho. O que não é possível sem tal fé, segundo aquilo do Apóstolo: Para que Cristo habite pela fé
nos vossos corações. Logo, quem não tem fé perfeita não pode receber o sacramento do batismo.

4. Demais. — A infidelidade é um gravíssimo pecado, como se estabeleceu na Segunda Parte. Ora, os
que perseveram no pecado não devem ser batizados. Logo, nem os que perseveram na infidelidade.
Mas, em contrário, Gregório, escrevendo ao Bispo Quirino, diz: Sabemos pela instituição dos antigos
patriarcas que os batizados pelos heréticos o nome da Trindade, quando voltarem ao seio da Igreja
devem ser nela recebidos pela unção da crisma ou pela imposição das mãos ou pela só profissão da fé.
Ora, isso não se daria se a fé fosse a fé necessária para receber o batismo.

SOLUÇÃO. — Como do sobre dito se colhe, dois efeitos causa o batismo na alma: o caráter e a graça.
Logo duas necessidades incluem o batismo. A do que é indispensável para se obter a graça, que é o
efeito último do sacramento; e deste modo a fé perfeita é necessária ao batismo; porque, como diz o
Apóstolo, a justiça de Deus é infundida pela fé de Jesus Cristo - A outra é a sem a qual o caráter do
batismo não pode ser impresso. E assim, a fé perfeita do batizado não é necessàriamente exigida para
receber o batismo, como nem a fé perfeita de quem batiza, contanto que se realizem as outras
condições necessárias para o sacramento Pois, este não se perfaz pela justiça de quem o confere nem
do que o recebe, mas por virtude de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Senhor se refere ao batismo enquanto nos conduz à
salvação pela graça justificante, o que não pode ser sem a fé perfeita. Por isso diz sinaladamente: Quem
crê e for batizado será salvo.

RESPOSTA À SEGUNDA. — A Igreja confere o batismo com a intenção de nos purificar do pecado,
segundo aquilo da Escritura: Todo este fruto se reduz a que seja tirado o seu pecado. Por onde da sua
parte, não tem a intenção de conferir o batismo senão aos de fé perfeita, sem a qual não há perdão dos
pecados. E por isso interroga aos que se apresentam ao batismo, se crêem. Quem receber porem o
batismo sem fé perfeita, fora da Igreja, não o recebe para sua salvação. Por isso diz Agostinho: A
comparação da Igreja com o Paraíso nos indica que mesmo os que não lhe pertencem ao grêmio podem
receber o batismo, mas ninguém pode fora dela receber nem conservar a beatitude.

RESPOSTA À TERCEIRA. — Mesmos os que não têm uma fé verdadeira em relação aos outros artigos,
podem tê-la sobre o sacramento do batismo; o que, pois, não os impede tenham a intenção de receber
esse sacramento. Mas se mesmo sobre esse não tivessem uma fé esclarecida, basta para recebê-lo a
intenção geral de o fazer, como o instituiu Cristo e o ensina a Igreja.

RESPOSTA À QUARTA. — Assim como o sacramento do batismo não deve ser conferido a quem não
quiser deixar o pecado, assim também não o deve a quem não quiser abandonar a infidelidade. Ambos,
porém, receberão o sacramento se lhes for conferido, mas não para salvação.

## Art. 9 — Se as crianças devem ser batizadas.
O nono discute-se assim. — Parece que não devem as crianças ser batizadas.

1. — Pois, de quem se apresenta ao batismo exige-se a intenção de recebê-lo, como se disse. Ora, tal
intenção não na podem ter as crianças, que não têm o uso do livre arbítrio. Logo, parece que não
podem receber o sacramento do batismo.

2. Demais. — O batismo é o sacramento da fé, como se disse. Ora, as crianças não têm fé, que consiste
na vontade do crente, como diz Agostinho. Nem se pode dizer que se salvem pela fé dos pais; pois estes
às vezes são infiéis e, então, seriam antes condenadas pela infidelidade deles. Logo, parece que as
crianças não podem ser batizadas.

3. Demais. — A Escritura diz: O batismo nos salva; não a purificação das imundícies da carne, mas a
promessa da boa consciência para com Deus. Ora, as crianças, não tendo o uso da razão, não têm
consciência boa nem má; nem podem ser convenientemente interrogados por não terem compreensão.
Logo, as crianças não devem ser batizadas.
Mas, em contrário, diz Dionísio: Os nossos divinos chefes, isto é, os Apóstolos aprovaram que as crianças
recebessem o batismo.

SOLUÇÃO. — Como diz o Apóstolo se pelo pecado de um reinou a morte por um só homem, isto é, por
Adão, muito mais reinarão em vida por um só, que é Jesus Cristo, os que recebem abundância da graça
e do dom e da justiça. Ora, as crianças, pelo pecado de Adão, contraem o pecado original, como o
mostra o fato de estarem sujeitos à morte que, pelo pecado do primeiro homem passou para todos, na
linguagem do Apóstolo. Logo, com muito maior razão, podem elas, mediante Cristo, receber a graça,
para reinarem na vida eterna. Pois, o próprio Senhor diz: Quem não renascer da água e do Espírito Santo
não pode entrar no reino de Deus. Por isso é necessário batizá-las, para que, assim como por Adão
incorreram na condenação ao nascer, assim, renascendo, consigam a salvação por Cristo. - É também
conveniente sejam as crianças batiza das a fim de, educa das desde a puerícía nas verdades da vida
cristã mais firmemente nela perseverem - segundo aquilo da Escritura: O homem, segundo o caminho
que tomou sendo mancebo, dele se não apartará, ainda quando for velho. E essa razão a apresenta
Dionísio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — - A regeneração espiritual produzida pelo batismo, é de
certo modo semelhante à natividade carnal. Pois, assim como as crianças, formadas no ventre materno,
não se nutrem por si mesmas, mas se sustentam da nutrição materna, assim também as que ainda não
têm o uso da razão, como se fossem constituídas no ventre da madre Igreja, alcançam a salvação, não
por si mesmas, mas por ato da Igreja. Donde o dizer Agostinho: A Madre Igreja deixa os seus filhinhos se
servirem da sua boca maternal, para que se abeberem dos sagrados mistérios; pois, ainda não podem
crer de próprio coração na justiça, nem por boca própria confessar a fé, para se salvarem. Se porém
podem ser chamados fiéis por proclamarem de certo modo a sua fé pela boca de quem os traz no seu
seio, por que não podem também ser considerados como penitentes, pois, por essa mesma boca,
mostraram ter renunciado ao diabo e a este mundo? E pela mesma razão podemos dizer que têm
intenção, não por ato próprio, pois, às vezes se lhe opõem e choram, mas pelo ato de quem os
apresenta.

RESPOSTA À SEGUNDA. — Como diz Agostinho, escrevendo a Bonifácio, na Igreja do Salvador, as
crianças crêem pelos outros, como pelos outros é que contraíram os pecados de que os livra o batismo.
Nem lhes impede a salvação o fato de serem os pais infiéis. Pois, como diz Agostinho, escrevendo ao
mesmo Bonifácio, as crianças são apresentadas a receberem a graça espiritual, não tanto pelos que os
carregam nos braços (embora também por eles, se forem bons fiéis), como por toda a sociedade dos
santos e dos fiéis. E temos razão de crer que os apresentam todos aqueles a quem é agradável que
sejam oferecidos e por cuja caridade são admitido à comunhão do Espírito Santo. Quanto à infidelidade
mesma dos pais, mesmo se depois do batismo dos filhos se esforçarem pelos iniciar no culto dos
demônios, ela não prejudica aos filhos. Pois, como diz Agostinho no mesmo lugar, a criança, uma vez
gerada por vontade alheia, não pode depois ficar adstrita ao vínculo da alheia iniquidade, a que de
nenhum modo deu o consentimento da sua vontade, segundo aquilo da Escritura assim como é minha a
alma do pai, assim também o é a da filha, a alma que pecar, essa morrerá. E se a alma contraiu de Adão
a mácula de que o pecado há de lavar, é que ela não vivia ainda por si mesma. Ora a fé de um só, antes,
de toda a Igreja, aproveita a criança por obra do Espírito Santo, que une a Igreja e comunica o bem de
um aos outros.

RESPOSTA À TERCEIRA. — Assim como a criança batizada não crê por si mesma, mas por outrem, assim
não por si mesma, mas por outrem é interrogada; e os interrogados confessam a fé da Igreja· na pessoa
da criança, a qual é a ela incorporada pelo sacramento da fé. Quanto à boa consciência a criança a tem
por si mesma, não certo em ato, mas por hábito pela graça justificante.

## Art. 10 — Se os filhos dos judeus ou de outros infiéis devem ser batizados, mesmo contra a vontade dos pais.
O décimo discute-se assim. — Parece que os filhos dos judeus ou de outros infiéis devem ser
batizados, mesmo contra a vontade dos pais.

1. — Pois, o homem deve ser preservado, antes contra o perigo da morte eterna, que contra o da morte
temporal. Ora, a criança em perigo de morte temporal, deve ser preservada, mesmo se por malícia os
pais a isso se opuserem. Logo, com maior razão, deve-se preservar às crianças filhos dos infiéis, pelo
batismo, contra o perigo de morte eterna, mesmo contra a vontade dos pais.

2. Demais. — Os filhos dos escravos são servos e estão sob o poder do senhor. Ora, os judeus são
escravos dos reis e dos príncipes, bem como quaisquer outros infiéis. Logo, sem nenhuma injustiça
podem os príncipes fazer batizar os filhos dos judeus ou de outros escravos infiéis.

3. Demais. — Qualquer homem pertence mais a Deus, de quem recebeu a alma, do que do pai carnal,
de quem recebeu o corpo. Logo, não é injusto tirar as crianças, filhos de infiéis, aos pais carnais, para as
consagrar a Deus pelo batismo.
Mas, em contrário, uma Decretal assim dispõe: O santo Sínodo, ordena que, no futuro, nenhum judeu
sela compelido por força a crer, pois, não devem ser salvos contra a vontade, mas se o quiserem, para
ser integral a forma da justiça.

SOLUÇÃO. — As crianças, filhos de infiéis, ou têm ou não têm o uso da razão. - Se a têm, já então, no
concernente ao direito divino natural começam a depender de si mesmas. E portanto, podem, por
vontade própria e contra a dos pais, receber o batismo, bem como contrair matrimônio. E portanto,
podem licitamente ser advertidas e induzidas a receber o batismo. - Se porém não têm ainda o uso do
livre arbítrio, estão por direito natural sujeitas à direção dos pais, enquanto não puderem se bastar a si
mesmos. Por isso se diz que os filhos dos antigos se salvavam na fé dos pais. Seria portanto contra a
justiça natural se essas crianças fossem batizadas contra a vontade dos pais, como o seria batizar contra
a vontade a quem tem o uso da razão. Alem disso seria perigoso batizar desse modo os filhos dos infiéis,
pois facilmente voltariam à infidelidade, pelo afeto natural para com os pais. Por isso, a Igreja não tem o
costume de batizar os filhos dos infiéis contra a vontade destes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ninguém deve ser subtraído à condenação à morte,
contra as exigências da lei civil; assim, o condenado à morte pelo juiz competente ninguém o deve livrar
dela com violência. Por onde, ninguém deve violar a ordem do direito natural, pelo qual o filho está sob
o poder do pai, a fim de o arrancar ao perigo da morte eterna.

RESPOSTA À SEGUNDA. — Os judeus são escravos dos príncipes por uma servidão civil, não exclusiva ela
ordem do direito natural ou divino.

RESPOSTA À TERCEIRA. — O homem se ordena a Deus pela razão, pela qual pode conhecê-lo. Por isso, a
criança, antes do uso da razão, ordena-se naturalmente para Deus pela razão dos pais, de quem por
natureza depender. E é a disposição deles que indica como se deve agir com ela no concernente às
coisas divinas.

## Art. 11 — Se se deve batizar as crianças ainda no ventre materno.
O undécimo discute-se assim. — Parece que se deve batizar as crianças ainda no ventre materno.

1. — Pois, mais eficaz é o dom de Cristo para a nossa salvação que o pecado de Adão para nos condenar,
como diz o Apóstolo. Ora, as crianças ainda no ventre materno são condenadas por causa do pecado de
Adão. Logo e muito mais, podem se salvar pelo dom de Cristo.

2. Demais. — A criança ainda no ventre materno faz parte da mãe. Ora batizada a mãe, tudo o nela
existente está batizado. Logo, batizada a mãe estará batizada a criança existente no ventre.

3. Demais. — A morte eterna é pior que a do corpo. Ora, de dois males devemos escolher o menor. Se,
pois, a criança no ventre materno não pode ser batizada, melhor seria abrir o ventre e extrair a criança
do que deixá-la condenar-se eternamente, morrendo sem batismo.

4. Demais. — Acontece às vezes uma parte da criança nascer primeiro. Assim, lemos na Escritura: No
parto de Tamar, na mesma ação de parir os meninos, um deitou fora a mão, na qual a parteira atou uma
fita encarnada, dizendo - este sairá primeiro. Porém, recolhendo ele a mão, saiu o outro. Outras vezes é
iminente em tal caso o perigo de morte. Logo, parece dever ser batizada a parte susceptível de atingir-
se, embora a criança esteja ainda no ventre materno.
Mas, em contrário, diz Agostinho: Ninguém renasce senão depois de haver nascido. Ora, o batismo é de
certo modo um renascimento espiritual. Logo, ninguém deve ser batizado antes de nascer do ventre.

SOLUÇÃO. — Para o batismo ser válido é necessário ser o corpo do batizando de certo modo abluído
com água, pois, o batismo é uma ablução, como se disse. Ora, o corpo da criança, antes de nascer do
ventre materno, não pode receber a ablução da água; salvo se se disser que a ablução batismal, lavando
o ventre materno, atinge o filho nele existente. Mas isto não pode ser, quer por ser a alma da criança, a
cuja santificação se ordena o batismo, distinta da alma da mãe; quer por ser o corpo da criança animada
já formado e por consequência distinto do corpo da mãe. E portanto o batismo recebido pela mãe não
redunda em benefício do filho existente no ventre. Por isso diz Agostinho: Se se considera o feto como
pertencendo à mãe a ponto de fazer parte dela, tendo esta sido já batizada, a criança não deve ser
batizada mesmo se, durante a gravidez, sobrevier perigo de morte. Como entretanto costuma-se batizar
a criança, é por não fazer parte da mãe, mesmo enquanto ainda no ventre. Donde se conclui que de
nenhum modo as crianças ainda existentes no ventre materno podem ser batizadas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As crianças existentes no ventre materno ainda não
vieram à luz, para fazer parte da sociedade humana. Não podem portanto estar sujeitas à ação dos
homens de modo a receberem por ministério deles, os sacramentos da salvação. Podem, porém sofrer a
ação de Deus, junto de quem vivem, de modo a conseguirem a santificação por um privilégio da graça;
tal o caso dos santificados no ventre materno.

RESPOSTA À SEGUNDA. — Os órgãos internos da mãe fazem parte dela pela continuidade e unidade da
parte material com o todo. Mas, o feto existente no ventre da mãe faz parte desta por uma ligação de
dois corpos distintos. Logo, a comparação não colhe.

RESPOSTA À TERCEIRA. — Não façamos males para que venham bens, diz o Apóstolo. Logo, não se deve
matar a mãe para batizar o filho. Se porém, morta a mãe, ainda lhe sobrevive o filho no ventre, deve
este ser aberto e a criança batizada.

RESPOSTA À QUARTA. — É preciso esperar a total expulsão do filho do ventre materno, para batizá-lo,
salvo se houver perigo de morte. Se porém se mostrar primeiro a cabeça, sede de todos os sentidos,
deve-se batizar, em perigo de morte; nem se reiterará o batismo, se vier a criança a nascer perfeita. E se
deve fazer o mesmo seja qual for a parte que nasça primeiro, havendo perigo de morte. Como porem a
integridade da vida em nenhum dos membros externos se manifesta como na cabeça, certos opinam
que, na dúvida, seja qual for a parte do corpo em que se tiver feito a ablução, a criança deve, depois de
totalmente nascida, ser batizada sob esta forma: Se não és batizada, eu te batizo, etc.

## Art. 12 — Se os loucos e os dementes devem ser batizados.
O duodécimo discute-se assim. — Parece que os loucos e os dementes não devem ser batizados.

1. — Pois, quem vai ser batizado deve ter a intenção de receber o batismo, como se disse. Ora, os loucos
e os dementes, não tendo o uso da razão, não podem ter senão uma intenção desordenada. Logo, não
devem ser batizados.

2. Demais. — O homem supera os brutos por ter o uso da razão. Ora, os loucos e os dementes não têm
esse uso; e às vezes nem mesmo se pode esperar que o venham a ter, como sabemos que o terão as
crianças. Logo, não podendo os irracionais ser batizados, também não o devem ser os loucos e os
dementes.

3. Demais. — Mais privados estão do uso da razão os loucos e os dementes que os adormecidos. Ora,
não se costuma conferir o batismo aos adormecidos. Logo, não deve ser também conferido aos loucos e
aos furiosos.
Mas, em contrário, Agostinho refere o caso de ter sido batizado um amigo seu, de quem se tinha
desesperado. E contudo, o batismo nele foi válido. Logo, aos sem o uso da razão o batismo deve ser às
vezes conferido.

SOLUÇÃO. — Sobre os loucos e os dementes é necessário distinguir. Certos o são de nascença, sem
nenhum intervalo lúcido, não manifestando nenhum uso da razão. E esses, quanto ao recebimento do
batismo, devemos tratá-los do mesmo modo que as crianças, batizados na fé da Igreja, como se disse. -
outros, porém, são dementes, caídos nesse estado depois de terem tido o uso da razão. E a esses
devemos tratá-los levando em conta a vontade que tinham quando eram sãos. Assim, se então
manifestaram a vontade de receber o batismo, devemos ministrá-lo, quando loucos mesmo se a isso
opuserem resistência. Ao contrário, se antes nunca manifestaram a vontade de o receber, quando
estavam em juízo perfeito, não devem ser batizados. - Outros há, porém, loucos ou dementes de
nascença, dotados contudo de certos intervalos lúcidos, podendo então usar bem da razão se, pois, num
desses intervalos quiserem ser batizados, podem sê-lo mesmo quando em estado de loucura; e há dever
de lhe conferir o sacramento, estando em caso de perigo; do contrário é melhor esperar o tempo da
lucidez, a fim de receberem o batismo com maior devoção. Se, porém, no intervalo de lucidez, não
manifestarem o desejo do batismo, não devem ser batizados quando caírem de novo na loucura. Outros
há ainda que, embora não sendo totalmente sãos de mente, têm o uso suficiente da razão para
poderem pensar na salvação e compreender a virtude do sacramento. E com esses devemos proceder
como com os sãos: batizá-los, se o quiserem; mas não, se forem contrários.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os loucos, que nunca tiveram o uso da razão, são
batizados de acordo com a intenção da Igreja, assim como por ato da Igreja crêem e fazem penitência,
tal como dissemos a respeito das crianças. Os que porém em certo tempo tiveram ou têm o uso da
razão são batizados conforme a intenção própria que têm ou tiveram quando estavam sãos.

RESPOSTA À SEGUNDA. — Os loucos e os dementes estão privados acidentalmente do uso da razão,
isto é, por insuficiência de algum órgão corpóreo; não porem por deficiência da alma racional, como é o
caso dos brutos. Logo, a comparação não colhe.

RESPOSTA À TERCEIRA. — Os adormecidos não devem ser batizados senão em perigo de morte
iminente. E então devem ser batizados, se antes manifestaram o desejo de o ser, como o dissemos a
propósito dos loucos. Assim, Agostinho conta, de um seu amigo, que foi batizado sem o saber, por estar
em perigo de morte.