# Questão 90: Das partes da penitência em geral
Em seguida devemos tratar das partes da penitência. E primeiro em geral, segundo, de cada uma em
especial.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se devemos distinguir partes na penitência.
O primeiro discute-se assim. — Parece que não devemos distinguir partes na penitência.

1. — Pois, é por via dos sacramentos que a virtude divina obra secretamente a nossa salvação. Ora, a
virtude divina é una e simples. Logo, não devemos distinguir parte na penitência, que é um sacramento.

2. Demais. — A penitência tanto é virtude como sacramento. Ora, enquanto virtude, não tem partes,
porque a virtude é um hábito, que é uma simples qualidade da alma, semelhantemente, não devemos
atribuir partes à penitência, como sacramento, porque não distinguimos partes no batismo e nos outros
sacramentos. Logo, de nenhum modo devemos introduzir partes na penitência.

3. Demais. — A matéria da penitência é o pecado, como se disse. Ora, no pecado não distinguimos
partes. Logo, nem na penitência devemos distingui-las.
Mas, em contrário, as partes são as que integram a perfeição de um ser. Ora, a perfeição da penitência
se integra por muitos elementos, a saber: a contrição, a confissão e a satisfação. Logo, a penitência tem
partes.

SOLUÇÃO. — Partes de um todo se chamam as em que ele materialmente se divide; pois, as partes
estão para o todo, como a matéria para a forma. Por isso Aristóteles coloca as partes no gênero da
causa material; mas o todo, no gênero da causa formal. Por isso, onde quer que encontremos uma
pluralidade material, aí encontraremos partes. Ora, como dissemos da penitência são os atos humanos a
matéria. Por onde, sendo vários os atos humanos necessários à perfeição da penitência, a saber - a
contrição, a confissão e a satisfação, como se dirá mais abaixo, resulta que o sacramento da penitência
tem partes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todos os sacramentos têm a simplicidade em razão da
virtude divina que neles obra. Ora, a virtude divina, por causa da sua magnitude, pode obrar por um só
ou por muitos. Razão por que podemos distinguir partes em certos sacramentos.

RESPOSTA À SEGUNDA. — A penitência, como virtude, não é susceptível de partes; pois, os atos
humanos, multiplicados na penitência, não se relacionam com o hábito da virtude como partes, mas
como efeitos. Donde se conclui que a penitência é susceptível de partes como sacramento, do qual os
atos humanos constituem a matéria. Ao passo que esses atos não constituem a matéria dos outros
sacramentos, que é a realidade exterior; ou simples, como a água ou composta, como o óleo, ou crisma.
Por isso os outros sacramentos não são susceptíveis de partes.

RESPOSTA À TERCEIRA. — Os pecados são a matéria remota da penitência, isto é, enquanto matéria ou
objeto dos atos humanos, que constituem a matéria própria da penitência, como sacramento.

## Art. 2 — Se são convenientemente assinaladas as seguintes partes da penitência — a contrição, a confissão e a satisfação.
O segundo discute-se assim. — Parece que não são convenientemente assinaladas as seguintes partes
da penitência - a contrição, a confissão e a satisfação.

1. — Pois, a contrição existe no coração; e assim constitui penitência interior. Ao passo que a confissão
se faz pela boca e a satisfação pelas obras; e assim essas duas últimas pertencem à penitência exterior.
Ora, a penitência interior não é sacramento; mas só a penitência exterior, dependente dos sentidos.
Logo, não estão convenientemente assinaladas essas partes da penitência.

2. Demais. — Pelos sacramentos da Lei Nova é conferida a graça, como se disse. Ora, pela satisfação
nenhuma graça é conferida. Logo, a satisfação não é parte do sacramento.

3. Demais. — Não é o mesmo ser fruto e parte de uma coisa. Ora, a satisfação é fruto da penitência,
segundo aquilo da Escritura: Fazei frutos dignos da penitência. Logo, não é parte da penitência.

4. Demais. — A penitência se ordena contra o pecado. Ora, o pecado podemos cometê-lo só no coração,
pelo consentimento, como se estabeleceu na Segunda Parte. Logo, também a penitência. Portanto, não
devem considerar-se partes da penitência a confissão oral e a satisfação das obras.
Mas, em contrário. — Parece que devemos distinguir várias partes na penitência. Pois, parte do homem
se considera, não só o corpo, que é a sua matéria; mas também a alma, que é a sua forma. Ora, os três
elementos referidos, sendo atos do penitente, constituem a matéria dela; sendo a forma a absolvição
dada pelo sacerdote. Logo, a absolvição do sacerdote deve ser considerada a quarta parte da penitência.

SOLUÇÃO. — Há duas espécies de partes, como o ensina Aristóteles: a parte da essência e a parte da
quantidade. As partes da essência são, naturalmente, a forma e a matéria; e logicamente, o gênero e a
diferença. Ora, deste modo, em cada sacramento distinguimos a matéria e a forma como partes da
essência deles; por isso dissemos que os sacramentos consistem em realidades e palavras. Mas como a
quantidade faz parte da matéria, as partes quantitativas são partes da matéria. E assim, especialmente
no sacramento da penitência distinguimos partes, como dissemos, relativas aos atos do penitente, que
são a matéria deste sacramento. Mas, como dissemos, compensa-se de um modo a ofensa na
penitência e, de outro, na justiça vindicativa. Pois, na justiça vindicativa a compensação depende
arbítrio do juiz e não da vontade do ofensor ou do ofendido. Ao passo que na penitência a compensação
da ofensa se realiza segundo a vontade do pecador e o arbítrio de Deus contra quem pecou. Porque aí
não se requer só a reintegração da igualdade da justiça, como no caso da justiça vindicativa, mas ainda a
reconciliação da amizade, o que se realiza pela recompensa do ofensor segundo a vontade do ofendido.
Assim, pois, exige-se, da parte do penitente: primeiro, a vontade de compensar, o que se realiza pela
contrição; segundo, a sujeição ao arbítrio do sacerdote, representante de Deus, o que se realiza pela
confissão, e terceiro, recompensar segundo o arbítrio do ministro de Deus, e isso se opera pela
satisfação. Por onde, a contrição, a confissão e a satisfação se consideram partes da penitência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A contrição existe, essencialmente no coração e
pertence à penitência interior; mas virtualmente, pertence à penitência exterior, isto é, enquanto
implica o propósito de confessar e satisfazer.

RESPOSTA À SEGUNDA. — A satisfação confere a graça, enquanto querida, e a aumenta, enquanto
executada, como o faz o batismo com os adultos, conforme dissemos.

RESPOSTA À TERCEIRA. — A satisfação é parte do sacramento da penitência, e fruto da virtude da
penitência.

RESPOSTA À QUARTA. — Mais elementos requerem o bem, que procede de uma causa íntegra, que o
mal, que nasce de qualquer deleito, segundo Dionísio. Por isso, embora o pecado se consume no
consentimento do coração, contudo para ser completa, a penitência requere a contrição do coração, a
confissão oral e a obra satisfatória.

## Art. 3 — Se as três partes referidas são partes integrantes da penitência.
O terceiro discute-se assim. — Parece que as três partes referidas não são partes integrantes da
penitência.

1. — Pois, a penitência, como se ordena contra o pecado. Ora, o pecado de coração de boca e de obras
são partes subjetivas do pecado e não partes integrantes; pois, qualquer delas se chama pecado. Logo,
também a contrição do coração, a confissão oral e a obra satisfatória não são partes integrantes da
confissão.

2. Demais. — Nenhuma parte integrante compreende em si outras partes que se dela distinguem. Ora, a
contrição contém em si a confissão e o propósito da satisfação. Logo, não são partes integrantes.

3. Demais. — O todo se constitui, simultânea e igualmente, das suas partes integrantes; assim, a linha,
das suas partes. Ora, tal não se dá no caso vertente. Logo, os referidos elementos não são partes
integrantes da penitência.
Mas, em contrário. - Partes integrantes se chamam aquelas com que se completa a perfeição do todo.
Ora, as três partes referidas integram a perfeição mesma da penitência. Logo são partes integrantes da
penitência.

SOLUÇÃO. — Certos consideraram essas três partes como partes subjetivas da penitência. Mas isto não
pode ser. Porque cada parte subjetiva encerra igual e simultaneamente, a virtude do todo; assim tudo o
existente de poder ativo na animalidade, como tal, se manifesta em cada uma das espécies animais, que
são simultânea e igualmente as divisões do gênero animal. O que não se dá com o nosso caso. Por isso
outros disseram que são partes potenciais. - O que também não pode ser verdade. Porque em cada
parte potencial está o todo na totalidade da sua essência; assim a essência total da alma está em
qualquer das suas potências. O que não se dá no caso vertente. Donde se conclui, que as referidas
partes são partes integrantes da penitência; e a essência delas exige, que o todo não esteja em cada
uma das partes, nem na totalidade da sua virtude, nem na totalidade da sua essência, mas em todas
simultaneamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pecado, sendo por essência mau pode consumar-se na
desordem de um só dos elementos dos nossos atos, como dissemos. Por isso, o pecado que se consuma
só no coração, é uma espécie de pecado. Outra espécie é a do que se consuma por palavras e por obras.
E a terceira espécie é a do que se consuma no coração e por obras. E de tal pecado as como partes
integrantes são as que se consumam no coração, por palavras e pelas obras. Ora, o mesmo passa com a
penitência, que tem, como partes integrantes, o que lhe advém do coração, da boca e das obras.

RESPOSTA À SEGUNDA. — Uma parte integrante pode conter o todo, embora, não na sua essência;
pois, os alicerces contêm de certo modo todo o edifício, virtualmente. E é desta maneira que a contrição
abrange virtualmente toda a penitência.

RESPOSTA À TERCEIRA. — Todas as partes integrantes ordenam-se umas para as outras, de certo modo.
Mas umas ocupam uma ordem apenas local, quer se sigam umas às outras, como as partes de um
exército; quer se toquem como as partes de um acervo; quer constituam um conjunto, como as partes
de uma casa; quer formem uma continuidade, como as partes de uma linha. Mas outras partes supõem,
além dessa, uma ordem de virtudes ativas, como as partes de um animal, das quais a primeira em
virtude ativa é o coração, dependendo as outras, entre si, numa certa ordem de virtudes ativas. A
terceira ordenação de partes é a temporal, como as partes do tempo e do movimento. Por onde, as
partes da penitência mantêm entre si uma ordem de virtudes ativas e de tempo, que são os atos; mas
não uma ordem de situação, porque não têm posição.

## Art. 4 — Se a penitência está convenientemente dividida em penitência anterior ao batismo, penitência dos pecados mortais e penitência dos pecados veniais.
O quarto discute-se assim. — Parece que a penitência está inconvenientemente dividida em
penitência anterior ao batismo, penitência dos pecados mortais e penitência dos pecados veniais.

1. — Pois, a penitência é a segunda tábua depois do batismo, como se disse; sendo o batismo a primeira
tábua. Logo, o que é anterior ao batismo não deve ser considerado espécie da penitência.

2. Demais. — O que pode destruir o mais também pode destruir o menos. Ora, o pecado mortal é maior
pecado que o venial. Logo, a penitência dos pecados mortais também serve para os veniais. Portanto,
não se devem distinguir diversas espécies de penitência.

3. Demais. — Assim como depois do batismo pecamos venial e mortalmente, assim também antes do
batismo. Se, portanto, antes do batismo, distingue-se a penitência dos pecados veniais da dos mortais,
pela mesma razão devemos fazer essa distinção antes do batismo. Logo, a penitência não se divide
convenientemente nas três espécies referidas.
Mas, em contrário, Agostinho dá as três referidas espécies de penitência.

SOLUÇÃO. — Essa divisão é da penitência como virtude. Ora, devemos considerar que qualquer virtude
regula a sua ação pelas exigências da circunstância de tempo, como das outras circunstâncias. Donde,
também a virtude da penitência se conforma atualmente com as prescrições da Lei Nova. Ora, pertence
à penitência fazer-nos detestar os pecados passados, com o propósito de começar uma vida melhor, que
é como o fim da penitência. E como os atos morais se especificam pelo fim, como estabelecemos na
Segunda Parte, resulta por conseqüência que as diversas espécies de penitência se deduzem das
diversas mudanças que o penitente tem em vista. Ora, há uma tríplice mudança que o penitente pode
visar. - A primeira, renascer para uma vida nova. E isso pertence à penitência anterior ao batismo. - A
segunda mudança é a reforma da vida passada já corrompida. E isso pertence à penitência dos pecados
mortais, depois do batismo. - A terceira mudança é para uma vida de atividade mais perfeita. E isso
pertence à penitência dos pecados veniais, que se perdoam por um fervoroso ato de caridade, como
dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A penitência anterior ao batismo não é sacramento, mas
um ato de virtude preparatório ao sacramento do batismo.

RESPOSTA À SEGUNDA. — A penitência, que apaga os pecados mortais, apaga também os veniais, mas
não ao inverso. Por isso essas duas espécies de penitência estão entre si como o perfeito para o
imperfeito.

RESPOSTA À TERCEIRA. — Antes do batismo não há pecados veniais nem mortais. E como o venial não
pode ser perdoado sem que o seja o mortal, como dissemos, por isso, antes do batismo não se distingue
entre penitência dos pecados mortais e dos veniais.