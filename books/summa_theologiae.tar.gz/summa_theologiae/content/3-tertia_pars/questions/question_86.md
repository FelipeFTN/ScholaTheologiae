# Questão 86: Do efeito da penitência quanto à remissão dos pecados
mortais.
Em seguida devemos tratar do efeito da penitência. E primeiro, quanto à remissão dos pecados mortais.
Segundo, quanto à remissão dos pecados veniais. Terceiro quanto à volta dos pecados perdoados.
Quarto, quanto à restauração das virtudes.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a penitência apaga todos os pecados.
O primeiro discute-se assim. — Parece que a penitência não apaga todos os pecados.

1. — Pois, diz o Apóstolo, que Esaú não achou lugar de arrependimento, ainda que o solicitou com
lágrimas. Ao que diz a Glosa: i. é não achou lugar de perdão e de bênção, mediante a penitência. E a
Escritura diz de Antíoco: Este malvado orava a Deus, do qual não havia de conseguir misericórdia. Logo,
parece que não se apagam todos os pecados.

2. Demais. — Agostinho diz: Tão grande é a mácula desse pecado - isto é, depois de ter um conhecido a
Deus pela graça, atacar a fraternidade cristã e deixar-se agitar pelos fogos da inveja contra a própria
graça - que não pode mais sofrer a humildade da oração, mesmo se a má consciência o obriga a
reconhecer e proclamar o seu pecado. Logo, nem todo pecado pode ser apagado pela penitência.

3. Demais. — O Senhor diz: Todo o que disser alguma palavra contra o Espírito Santo não se lhe
perdoará nem neste mundo nem no outro. Logo, nem todo pecado pode remitir-se pela penitência.
Mas, em contrário, a Escritura: Eu não me recordarei de nenhuma das suas iniqüidades, que obrou.

SOLUÇÃO. — De dois modos pode suceder que um pecado não seja susceptível de ser apagado pela
penitência: ou porque o pecador não pode penitenciar-se do pecado; ou porque a penitência não pode
delir o pecado. Do primeiro modo, não podem ser apagados pela penitência os pecados dos demônios e
os das almas condenadas, por terem o afeto confirmado no mal, a ponto de não lhes ser impossível a
displicência do pecado, como culpa, que só lhes desagrada enquanto pena, que sofrem. Em razão do
que praticam uma certa penitência, mas estéril, segundo aquilo da Escritura: Tocados de
arrependimento e com angústia do espírito gemendo. Por onde, esta penitência não é acompanhada da
esperança do perdão, mas do desespero. — Mas tal não pode ser o caso de nenhum pecado, dos que
vivemos neste mundo, pois o nosso livre arbítrio é susceptível de bem e de mal. Por onde, dizer que há
pecados nesta vida, de que não possamos alcançar perdão, é errôneo. — Primeiro, porque esse modo
de ver tiraria a liberdade do arbítrio. Segundo, porque derrogaria à virtude da graça, que pode mover o
coração de qualquer pecador à penitência, segundo aquilo da Escritura: O coração do rei se acha na mão
do Senhor e ele o inclinará para qualquer parte que quiser. E dizer, do segundo modo, que não pode
nenhum pecado ser perdoado pela verdadeira penitência, também é errôneo. — Primeiro, porque
repugna à misericórdia de Deus, do qual diz a Escritura, que é benigno e mavioso, paciente e de muita
misericórdia e pode arrepender-se do mal. Ora, de certo modo Deus seria vencido pelo homem, se este
quisesse que se delisse um pecado que Deus não quisesse deliro — Segundo, porque encontra a paixão
de Cristo, pela qual a penitência é eficaz, assim como os outros sacramentos; pois, está escrito — Ele é a
propiciação pelos nossos pecados, e não somente pelos nossos, mas também pelos de todo o mundo.
Donde devemos concluir que, absolutamente falando, todo o pecado pode ser apagado nesta vida, pela
penitência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Esaú não fez verdadeiramente penitência. O que se
deduz do lugar da Escritura: Virão os dias do luto por meu pai e eu matarei a Jacó, meu irmão. —
Semelhantemente, nem Antíoco fez verdadeira penitência. — Pois, lamentava-se da passada culpa, não
por causa da ofensa a Deus, mas por causa da doença que no corpo sofria.

RESPOSTA À SEGUNDA. — As palavras citadas de Agostinho devem entender-se assim: Tão grande é a
mácula desse pecado, que não pode mais sofrer a humildade da oração, isto é, facilmente. No mesmo
sentido dizemos que não pode ser curado quem não pode facilmente sarar. Mas pode fazê-lo o poder
da graça divina que às vezes converte no profundo do mar, no dizer da Escritura.

RESPOSTA À TERCEIRA. — Essa palavra ou blasfêmia contra o Espírito Santo é a impenitência final,
como explica Agostinho. A qual é absolutamente irremissível, porque acabada esta vida não há mais
perdão dos pecados. — Ou se entendermos por blasfêmia contra o Espírito Santo o pecado cometido
por malícia premeditada, ou ainda a blasfêmia direta contra o Espírito Santo, no dizer-se que não pode
esse pecado ser perdoado, subentende-se facilmente, porque tal pecado não tem em si nenhuma causa
de excusa. Ou então, que quem cometer tal pecado será punido nesta vida e na outra, como expusemos
na Segunda Parte.

## Art. 2 — Se o pecado pode ser perdoado sem a penitência.
O segundo discute-se assim. — Parece que o pecado pode ser perdoado sem a penitência.

1. — Pois, o poder de Deus sobre os adultos não é menor que sobre as crianças. Ora, às crianças se lhes
perdoam os pecados sem a penitência. Logo, também aos adultos.

2. Demais. — Deus não ligou o seu poder aos sacramentos. Ora, a penitência é um sacramento. Logo
pelo poder divino podem os pecados ser perdoados sem a penitência.

3. Demais. — Maior é a misericórdia de Deus que a do homem. Ora, por vezes um homem perdoa a
ofensa recebida de outrem, mesmo que este se não penitencie dela. Pois, o próprio Senhor manda:
Amai a vossos inimigos, fazei bem aos que vos têm ódio. Logo, com maior razão, Deus pode perdoar as
ofensas, sem que os seus ofensores se penitenciem delas.
Mas, em contrário, o Senhor diz: Se aquela gente se arrepender do seu mal, também eu me
arrependerei do mal que tenho pensado fazer contra ela. E assim, ao contrário, parece que, se não
fizermos penitência, Deus não nos perdoará os pecados.

SOLUÇÃO. — É impossível o pecado atual mortal ser perdoado sem a penitência, tratando-se da
penitência como virtude. Pois, sendo o pecado uma ofensa a Deus, do mesmo modo Deus perdoa o
pecado, pelo qual perdoa a ofensa contra si cometida. Ora, a ofensa opõe-se diretamente à graça; pois,
dizemos que uma pessoa ofendeu a outra pela repelir a esta da sua graça. Mas, como dissemos na
Segunda Parte, entre a graça de Deus e a dos homens há a diferença seguinte: Ao passo que a graça dos
homens não causa, mas pressupõe a bondade, verdadeira ou aparente, na pessoa grata, a graça de Deus
causa a bondade no homem grato, porque a boa vontade de Deus, significada pela denominação de
graça, é a causa do bem criado. Por isso pode dar-se que perdoemos a ofensa feita contra nós, sem
nenhuma mudança da nossa vontade; mas não é possível Deus perdoar a ofensa feita por uma pessoa
sem que haja mudança na vontade desta. Ora, a ofensa do pecado mortal procede da aversão da nossa
vontade, de Deus, e da conversão aos bens efêmeros. Por isso é necessário, para repararmos a ofensa
feita contra Deus, a nossa vontade mudar-se de modo a converter-se para Deus e detestar a conversão
supra-referida, com o propósito de emenda. O que constitui a penitência como virtude. Por onde, é
impossível o pecado de alguém ser perdoado sem a penitência, como virtude. O sacramento da
penitência porém, como dissemos, se perfaz pela mediação do sacerdote que liga e absolve, sem o qual
pode Deus perdoar os pecados, como Cristo, perdoou à mulher adúltera e à pecadora, como lemos nos
Evangelhos. As quais porém não perdoou os pecados, sem a virtude da penitência; pois, como diz
Gregório, pela graça atraiu interiormente à penitência a pecadora que, por misericórdia acolhia
exteriormente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As crianças são contaminadas apenas pelo pecado
original, que não consiste numa desordem atual da vontade, mas numa certa desordem habitual da
natureza, como dissemos na Segunda Parte. Por isso é-lhes perdoado o pecado, bastando a mudança da
disposição habitual delas, pela infusão da graça e das virtudes, sem necessidade da mudança da
inclinação atual. Mas ao adulto, sujeito de pecados atuais, consistentes numa desordem atual da
vontade, não se lhe perdoam os pecados, mesmo na batismo, sem uma atual mudança da vontade, o
que é obra da penitência.

RESPOSTA À SEGUNDA. — A objeção procede, considerada a penitência como sacramento.

RESPOSTA À TERCEIRA. — A misericórdia de Deus tem maior poder que a dos homens, por mudar a
vontade humana, levando-nos a fazer penitência; o que a misericórdia do homem não pode fazer.

## Art. 3 — Se pela penitência pode ser perdoado um pecado sem o serem os outros.
O terceiro discute-se assim. — Parece que pela penitência um pecado pode ser perdoado sem o serem
os outros.

1. — Pois, diz a Escritura: fiz que chovesse sobre uma cidade e sobre outra cidade não chovesse; uma
parte ficou regada com a chuva, e outra parte, sobre a qual não dei chuva, secou-se. Expondo o que, diz
Gregório: Quando aquele que odeia o próximo se corrige dos outros vícios, uma só e mesma cidade é
em parte regada com a chuva e outra parte seca-se; pois, há pecadores que, vencendo certos vícios,
continuam a cometer pecados graves. Logo, pode um pecado ser perdoado pela penitência, sem o
serem os outros.

2. Demais. — Ambrósio diz: A primeira consolação é que Deus não esquece de fazer misericórdia; a
segunda é a punição, quando na falta de fé, essa punição mesma serve de satisfação e de emenda. Logo,
podemos nos emendar de um pecado, permanecendo no pecado de infidelidade.

3. Demais. — De coisas que de necessidade não existem simultaneamente, uma pode ser eliminada sem
que a outra o seja. Ora, os pecados, como se estabeleceu na segunda Parte, não são conexos; e portanto
um pode existir sem os outros. Logo, também um deles pode ser perdoado pela penitência, sem que o
sejam os outros.

4. Demais. — Os pecados são dívidas que pedimos sejam perdoadas, quando rezamos na Oração
Dominical: Perdoai-nos as nossas dívidas. Ora, às vezes perdoamos uma dívida sem perdoarmos outra.
Logo, também Deus pode perdoar, pela penitência, um pecado, sem perdoar os outros.

5. Demais. — Pelo amor de Deus são perdoados os nossos pecados, segundo aquilo da Escritura: Com
amor eterno te amei; por isso, compadecido de ti, te atraí a mim. Ora, nada impede que Deus nos ame
por um lado, e continue ofendido por outro. Assim, ama o pecador na sua natureza, mas o odeia pela
culpa. Logo, parece que Deus pode, pela penitência, perdoar-nos um pecado, sem perdoar os outros.
Mas, em contrário, diz Agostinho: Há muitos que se arrependem de ter pecado, mas não
completamente, reservando-se certos pecados com os quais se comprazem. E não notam que o Senhor
livrou do demônio possesso, curando-lhe ao mesmo tempo a surdez e a mudez, ensinando-nos por aí
que só podemos ser curados de todos os pecados ao mesmo tempo.

SOLUÇÃO. — É impossível ser perdoado, pela penitência, um pecado, sem o serem os outros. —
Primeiro, porque o ser o pecado perdoado consiste em ser perdoada a ofensa a Deus, pela graça. Por
isso estabelecemos na Segunda Parte, que nenhum pecado pode ser perdoado sem a graça. Ora, todo
pecado mortal contraria a graça e a exclui. Por onde, é impossível um pecado ser perdoado sem que o
sejam os outros. — segundo, porque, como já dissemos o pecado mortal não pode ser perdoado sem
verdadeira penitência, e esta requere que abandonemos o pecado, por ser contra Deus — o que é
comum a todos os pecados mortais. Ora, o mesmo princípio de ação produz o mesmo efeito. Por onde,
não pode ser verdadeiro penitente quem se arrepende de um pecado, e não dos outros. Pois, se lhe
repugnassem os outros, por serem contra Deus, amável sobre todas as coisas — e isso o requer a
verdadeira penitência pela sua natureza mesma — necessariamente havia de arrepender-se de todos.
Donde se segue a impossibilidade de ser um pecado perdoado, sem que o sejam os outros. — Terceiro,
porque encontraria a perfeição da misericórdia de Deus, cujas obras são perfeitas, na frase da Escritura.
Por isso, de quem tem misericórdia a tem de maneira total. E tal é o que diz Agostinho: É de certo modo
impiedade de infiel esperar meio perdão daquele que é a justiça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essas palavras de Gregório não devem entender-se
como referentes à remissão da culpa, mas quanto à cessação do ato. Porque às vezes quem estava
acostumado a cometer muitos pecados deixa um, mas não os outros. Isso certamente o faz por auxílio
divino, o qual contudo, não chega até a remissão da culpa.

RESPOSTA À SEGUNDA. — Essas palavras de Ambrósio não podem significar a fé pela qual cremos em
Cristo. Pois, comentando aquilo do Evangelho — Se eu não viera e não lhes tivesse falado, não teriam
eles o pecado, isto é, de infidelidade — diz Agostinho: Esse é o pecado que faz serem retidos todos os
outros. Mas é a fé aí tomada pela consciência, porque às vezes, pelas penas sofridas pacientemente,
conseguimos a remissão dos pecados de que não temos consciência.

RESPOSTA À TERCEIRA. — Os pecados, embora não conexos quanto à conversão para os bens
transitórios, são-no contudo quanto à aversão do bem incomutável, no que convêm todos os pecados
mortais. E por aí têm a natureza de ofensa, que deve ser delida pela penitência.

RESPOSTA À QUARTA. — A dívida de uma coisa externa, por exemplo, de dinheiro, não contraria a
amizade, que perdoa as dívidas. Por onde, pode uma ser perdoada, sem o serem as outras. Mas, a dívida
da culpa contraria a amizade. Por isso não pode uma culpa ser perdoada sem que o sejam as outras.
Pois, mesmo entre os homens, seria ridículo quem pedisse perdão de uma ofensa, mas não de outra.

RESPOSTA À QUINTA. — O amor com que Deus ama a natureza humana não se ordena ao bem da
glória, da qual ficamos impedidos por qualquer pecado. Mas o amor da graça, pelo qual se faz a
remissão do pecado mortal, ordena-nos para a vida eterna, segundo aquilo do Apóstolo: A graça de
Deus é a vida eterna. Por onde, não há semelhança de razões.

## Art. 4 — Se, perdoada a culpa pela penitência permanece o reato da pena.
O quarto discute-se assim. — Parece que perdoada a culpa pela penitência, não permanece o reato da
pena.

1. — Pois, removida a causa, removido fica o efeito. Ora, a culpa é a causa do reato da pena; pois, somos
dignos da pena, porque cometemos a culpa. Logo, perdoada a culpa, não pode permanecer o reato da
pena.

2. Demais. — Como diz o Apóstolo, o dom de Cristo é mais eficaz que o pecado. Ora, pecando,
incorremos simultaneamente na culpa e no reato da pena. Logo e com maior razão, o dom da graça
perdoa simultânea mente a culpa e dele o reato da pena.

3. Demais. — O perdão dos pecados se dá, na penitência, pela virtude da paixão, segundo aquilo do
Apóstolo: Ao qual propôs Deus para ser vítima de propiciação pela fé no seu sangue, pela remissão dos
delitos passados. Ora, a paixão de Cristo é suficientemente satisfatória por todos os pecados, como se
disse. Logo, depois da remissão da culpa, não permanece nenhum reato da pena.
Mas, em contrário, a Escritura refere que, tendo Davi penitente dito a Natan - Pequei contra o Senhor,
respondeu-lhe Natan: Também o Senhor transferiu o teu pecado - não morrerás; todavia morrerá
certamente o filho que te nasceu. O que foi pena de um pecado precedente, como no mesmo lugar se
diz. Logo, perdoada a culpa, permanece o reato de uma certa pena.

SOLUÇÃO. — Como estabelecemos na Segunda Parte, dois elementos constituem o pecado mortal - a
aversão do bem incomutável e a conversão desordenada para um bem mutável. Ora, da parte da
aversão do bem incomutável, resulta para o pecado mortal o reato da pena eterna, que requere seja
eternamente punido quem pecou contra o bem eterno. Da parte da conversão para o bem mutável,
enquanto desordenada, resulta para o pecado mortal o reato de alguma pena; porque a desordem da
culpa não se reduz à ordem da justiça senão pela pena. Pois é justo que quem concedeu à sua vontade
mais do que devia, sofra alguma pena contra a vontade; assim haverá igualdade. Donde o dizer a
Escritura: Quanto se tem glorificado e vivido em deleites, tanto lhe dai de tormento e pranto. Mas como
a conversão ao bem comutável é finita, não é devida, por ai, ao pecado mortal uma pena eterna. Por
onde, se a conversão desordenada para o bem mutável não for acompanhada da a versão de Deus,
como se dá no caso dos pecados veniais, não é devida ao pecado uma pena eterna, mas só temporal.
Quando, pois, pela graça se perdoa a culpa, desaparece a versão de Deus, que tinha a alma, pois, pela
graça ela se une com Deus. Portanto e conseqüentemente, fica simultaneamente eliminado o reato da
pena eterna. Mas pode permanecer o reato de uma pena temporal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A culpa mortal implica ao mesmo tempo a aversão de
Deus e a conversão a um bem criado. Ora, como estabelecemos na Segunda Parte, a aversão de Deus é
como o elemento formal dessa culpa; e a conversão ao bem criado, como o elemento material. Ora,
removido de um ser o seu elemento formal, desaparece-lhe a espécie; assim, removido o racional,
desaparece a espécie humana. Por onde, dizemos que é perdoada uma culpa mortal, por isso mesmo
que a graça elimina a aversão que tem a alma de Deus, simultaneamente com o reato da pena eterna.
Mas permanece o elemento material, isto é, a conversão desordenada para o bem criado, a que
responde o reato da pena temporal.

RESPOSTA À SEGUNDA. — Como estabelecemos na Segunda Parte, é próprio da graça agir em nós para
nos justificar do pecado e cooperar conosco para agirmos retamente. Por onde, é a graça operante que
nos perdoa a culpa e o reato da pena eterna. Mas é a graça cooperante que nos perdoa o reato da pena
temporal, enquanto que, sofrendo as penas pacientemente, com o auxilio da divina graça, somos
absolvidos também do reato da pena temporal. Assim pois, o efeito da graça operante é anterior ao da
graça cooperante; e por isso também a remissão da culpa e da pena eterna é anterior à plena absolvição
da pena temporal. É verdade que ambas são efeitos da graça, mas a primeira vem só da graça, ao passo
que a segunda, da graça e do livre arbítrio.

RESPOSTA À TERCEIRA. — A paixão de Cristo é por si mesma suficiente para delir totalmente o reato da
pena, não só eterna, mas ainda temporal. E, segundo o modo por que participamos da virtude da paixão
de Cristo, recebemos também a absolvição do reato da pena. Ora, no batismo participamos totalmente
da virtude da paixão de Cristo, pois pela água e pelo Espírito morremos com Cristo para o pecado e
renascemos para uma vida nova. Por isso, no batismo alcançamos a remissão total do reato da pena.
Mas na penitência participamos da paixão de Cristo ao modo dos nossos atos próprios e que são a
matéria desse sacramento, como a água é a matéria do batismo, conforme dissemos. E por isso não
ficamos absolvidos totalmente do reato da pena, logo depois do primeiro ato de penitência; pelo qual
somos perdoados da culpa, mas só depois de completos todos os atos de penitência.

## Art. 5 — Se, perdoada a culpa mortal, são delidos todos os resquícios do pecado.
O quinto discute-se assim. — Parece que, perdoada a culpa mortal, são delidos todos os resquícios do
pecado.

1. — Pois, diz Agostinho: Nunca o Senhor curou ninguém, que não o livrasse totalmente; assim curou
totalmente um homem no sábado, curando-lhe ao mesmo passo e totalmente o corpo de toda doença e
a alma de todo contágio do mal. Ora, os resquícios do pecado resultam da nossa inclinação para ele.
Logo, não parece possível que, perdoada a culpa, permaneçam tais resquícios.

2. Demais. — Segundo Dionísio, o bem é mais eficaz que o mal, porque o mal não atua senão em virtude
do bem. Ora, pecando caímos totalmente na miséria do pecado. Logo, com maior razão, fazendo
penitência, ficamos também purificados de todos os resquícios do pecado.

3. Demais. — As obras de Deus são mais eficazes que as dos homens. Ora, pela prática de atos bons se
nos desaparecem os restos do pecado contrário. Logo, com maior razão desaparecem pela remissão da
culpa, que é obra de Deus.
Mas, em contrário, lemos no Evangelho que o cego a quem o Senhor restituiu a vista, recuperou
primeiro uma vista imperfeita e por isso disse: Vejo os homens como árvores que andam. Depois foi-lhe
restituída a vista completa, de sorte que via distintamente todos os objetos. Ora, a iluminação do cego
significa a libertação do pecador. Logo, depois da primeira remissão da culpa, pela qual lhe é restituída a
vista espiritual, ainda permanecem nele certos resquícios do pecado passado.

SOLUÇÃO. — O pecado mortal, pela conversão desordenada a um bem mutável, que implica, causa uma
certa disposição na alma; ou mesmo um hábito, se os atos forem repetidos muitas vezes. Ora, como
dissemos, a culpa do pecado mortal é perdoada, enquanto a graça faz desaparecer da alma a sua
aversão de Deus. E desaparecido o concernente à aversão, pode contudo, ainda permanecer o
concernente à conversão desordenada, porque esta pode existir sem aquela, como dissemos. Por onde,
nada impede que, perdoada a culpa, permaneçam as disposições causadas pelos atos precedentes, que
se chamam resquícios do pecado. Mas permanecem enfraquecidas e diminuídas, de modo que não nos
dominam. E isso, antes, a modo de disposições, que a modo de hábitos; assim como tambem
permanece a concupiscência depois do batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus quando cura o homem, fá-lo total e perfeitamente.
Mas às vezes o faz de súbito, como quando restituiu imediatamente à sogra de Pedro a sua perfeita
saúde, de modo que ela, levantando-se logo, se pôs a servi-los, como lemos, no Evangelho. Mas outras
vezes o faz sucessivamente, como no caso referido, do cego iluminado. E ainda outras vezes, converte
espiritualmente e com tanta comoção o coração humano, que o convertido de súbito alcança a perfeita
saúde espiritual, não só com o perdão da culpa, mas com a disparição de todos os resquícios do pecado,
como foi o caso da Madalena. Outras vezes enfim, primeiro perdoa a culpa pela graça operante; e
depois, pela graça cooperante, elimina sucessivamente os resquícios do pecado.

RESPOSTA À SEGUNDA. — O pecado, às vezes, produz logo uma fraca disposição, quando esta é
causada por um só ato; outras vezes, uma disposição mais forte, quando esta é causada por muitos atos.

RESPOSTA À TERCEIRA. — Um só ato humano não faz desaparecer todos os resquícios do pecado; pois,
como diz Aristóteles, o homem depravado, conduzido a melhores práticas, começará aproveitando um
pouco até tornar-se melhor. Mas, com o exercício multiplicado, chegará a ser bom, pela virtude
adquirida. Ora, isso muito mais eficazmente o produz a divina graça, acompanhada de um só ou de
vários atos.

## Art. 6 — Se a remissão da culpa é efeito da penitência como virtude.
O sexto discute-se assim. — Parece que a remissão da culpa não é efeito da penitência como virtude.

1. — Pois, a penitência é considerada virtude, enquanto princípio de atos humanos. Ora, os atos
humanos não produzem a remissão da culpa, que é efeito da graça operante. Logo, a remissão da culpa
não é efeito da penitência; enquanto virtude.

2. Demais. — Há certas outras virtudes mais excelentes que a penitência. Ora, a remissão da culpa não é
considerada efeito de nenhuma outra virtude. Logo, também não é efeito da penitência, como virtude.

3. Demais. — A remissão da culpa não procede senão da virtude da paixão de Cristo, segundo aquilo do
Apóstolo: Sem efusão de sangue não há remissão. Ora, a penitência, enquanto sacramento, obra em
virtude da paixão de Cristo, assim como os outros sacramentos, conforme do sobredito se colige. Logo,
a remissão da culpa não é efeito da penitência como virtude, mas enquanto sacramento.
Mas, em contrário. — Aquilo é propriamente causa de um efeito, sem o qual este não pode existir; pois,
todo efeito depende da sua causa. Ora, a remissão da culpa Deus pode dá-Ia sem o sacramento da
penitência; mas não, sem a penitência enquanto virtude, como se disse. Por isso, antes dos sacramentos
da Lei Nova, Deus perdoava os pecados aos penitentes. Logo, a remissão da culpa não é efeito da
penitência, como virtude.

SOLUÇÃO. — A penitência é virtude enquanto princípio de certos atos humanos. Ora, os atos humanos
praticados por um pecador, como tal, constituem a matéria do sacramento da penitência. Mas, todos os
sacramentos produzem o seu efeito, não só em virtude da forma, mas também em virtude da matéria;
pois, de ambas se constitui a unidade do sacramento, como estabelecemos. Por onde, assim como a
remissão da culpa se dá no batismo, não só em virtude da forma, mas também em virtude da matéria a
saber, da água; mas mais principalmente em virtude da forma, da qual a própria água tira a sua virtude,
assim também a remissão da culpa é efeito da penitência. Mais principalmente porém por virtude das
chaves, a qual os ministros têm, donde deriva o que este sacramento tem de formal, como dissemos.
Secundariamente porém, o formal do sacramento deriva dos atos do penitente concernentes à virtude
da penitência, mas enquanto esses atos de certo modo se ordenam às chaves da Igreja. Por onde é
claro, que a remissão da culpa é efeito da penitência enquanto virtude; mas mais principalmente,
enquanto é sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O efeito da graça operante é a justificação do ímpio,
como dissemos na Segunda Parte. E essa justificação implica conforme mostramos no mesmo lugar, não
só a infusão da graça e a remissão da culpa, como também o movimento do livre arbítrio, que de um
lado, nos leva para Deus, um ato de fé formada, e de outro, nos afasta do pecado, por um ato de
penitência. Mas esses atos humanos são aí como efeitos da graça operante, produzidos
simultaneamente com a remissão da culpa. Por onde, a remissão da culpa não se opera sem o ato da
virtude da penitência; embora seja efeito da graça operante.

RESPOSTA À SEGUNDA. — A justificação do ímpio implica, não só um ato de penitência, mas também
um ato de fé como dissemos. Por onde, a remissão da culpa não é considerada como efeito só da
virtude da penitência, mas mais principalmente, da fé e da caridade.

RESPOSTA À TERCEIRA. — A paixão de Cristo se ordena o ato da virtude da penitência, tanto pela fé
como pela sua subordinação ao poder das chaves, que tem a Igreja. Por onde, de um e outro modo
causa a remissão da culpa em virtude da paixão de Cristo.
Quanto ao objetado em contrário, respondemos, que o ato da virtude da penitência tem um caráter de
necessidade tal, que sem ela não pode haver remissão da culpa, enquanto esta é um efeito inseparável
da graça, pela qual principalmente a culpa é perdoada e que opera também em todos os sacramentos. E
por isso daí se não pode concluir, que a graça é causa da· remissão da culpa, mais principal que o
sacramento da penitência. Mas devemos saber, que mesmo na vigência da Lei Velha e na da natureza,
havia de certo modo o sacramento da penitência, como dissemos.