# Questão 52: Da descida de Cristo aos infernos
Em seguida devemos tratar da descida e Cristo aos infernos. E nesta questão discutem-se oito artigos:

## Art. 1 — Se devia Cristo descer ao inferno.
O primeiro discute-se assim. — Parece que não devia Cristo ter descido aos infernos.

1. — Pois, diz Agostinho: Nunca pude encontrar na Escritura a palavra inferno significativa de qualquer
bem. Ora, a alma de Cristo não desceu para nenhum mal, porque nem as almas dos justos para nenhum
mal desceram. Logo parece que não devia Cristo ter descido aos infernos.

2. Demais. — Descer aos infernos não podia convir a Cristo em razão da natureza divina, absolutamente
imutável; mas só lhe podia convir em razão da natureza assumida. Ora, tudo o que Cristo fez ou sofreu,
em virtude da natureza assumida, se ordena à salvação humana. E para isso não era necessário que
descesse aos infernos; pois, pela sua paixão, que padeceu neste mundo, livrou-nos da culpa da pena,
como se disse. Logo, não devia Cristo ter descido aos infernos.

3. Pela morte de Cristo a alma se lhe separou do corpo, o qual foi depositado no sepulcro, como se
disse. Ora, parece que não foi a sua alma isolada, a que desceu aos infernos. Pois, a alma, sendo
incorpórea, não pode mover-se localmente, o que é um movimento material, como o prova Aristóteles;
e a descida implica um movimento material. Logo, não devia Cristo ter descido aos infernos.
Mas, em contrário, o Símbolo (dos apóstolos): desceu aos infernos. E o Apóstolo: Quanto a dizer subiu,
porque é isto senão porque também antes havia descido aos lugares mais baixos da terra? Comentário
de Glosa: isto é, aos infernos.

SOLUÇÃO. — Cristo devia ter descido ao inferno. — Primeiro, porque veio carregar com a nossa pena,
para dela nos livrar, segundo aquilo da Escritura: Verdadeiramente ele foi o que tomou sobre si as
nossas fraquezas e ele mesmo carregou com as nossas dores. Pois, pelo pecado o homem não somente
incorreu na morte do corpo, mas também teve que descer aos infernos. Por onde, assim como devia
morrer para nos livrar da morte, conveniente foi que descesse aos infernos para nos livrar dessa
descida. Por isso diz a Escritura: ómorte, eu serei a tua morte; óinferno, eu serei a tua mordedura. -
Segundo, porque devia, uma vez vencido o diabo pela Paixão, arrebatar-lhe os que tinha encarcerados
no inferno, segundo a Escritura: Tu também pelo sangue do teu testamento fizeste sair os teus presos
do lago. E o Apóstolo: Despojando os principados e potestades, os trouxe confiadamente. - Terceiro, a
fim de, como mostrou o seu poder na terra, nela vivendo e morrendo, assim também mostrasse o seu
poder sobre o inferno, visitando-o e iluminando-o. Donde o dizer a Escritura: Levantai, ópríncipes, as
vossas portas; isto é, comenta a Glosa, ópríncipes do inferno; deponde o vosso poder, com que até
agora detínheis as almas no inferno; e assim, segundo diz o Apóstolo, ao nome de Jesus se dobre todo o
joelho, não só dos que estão nos céus, mas também nos infernos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O nome de infernos exprime o mal da pena e não o da
culpa. Por isso devia Cristo descer ao inferno: não que fosse devedor da pena, mas para livrar os que a
ela tinham sido entregues.

RESPOSTA À SEGUNDA. — A Paixão de Cristo foi a como causa universal da salvação humana, tanto dos
vivos como dos mortos. Ora, uma causa universal se aplica a efeitos particulares por algum meio
especial. Por onde, assim como a virtude da Paixão de Cristo se aplica aos vivos pelos sacramentos, que
nos assemelham a Cristo padecente, assim também se aplicou aos mortos pela descida de Cristo aos
infernos. Por isso a Escritura diz sinaladamente: Pelo sangue do teu testamento fizeste sair os teus
presos do lago, isto é, pela virtude da tua paixão.

RESPOSTA À TERCEIRA. — A alma de Cristo não desceu aos infernos por aquele gênero de movimentos
com que se movem os corpos; mas pelo gênero de movimento com que se movem os anjos, como
estabelecemos na Primeira Parte.

## Art. 2 — Se Cristo também desceu ao inferno dos condenados.
O segundo discute-se assim. — Parece que Cristo também desceu ao inferno dos condenados.

1. — Pois, diz a divina Sabedoria: Penetrarei todas as partes inferiores da terra. Ora, entre as partes
inferiores da terra também se conta o inferno dos condenados, segundo a Escritura: Entrarão nas
profundezas da terra. Logo, Cristo, a sabedoria de Deus, desceu também até ao inferno dos condenados.

2. Demais. — Diz Pedro, que Deus ressuscitou a Cristo, soltas as dores do inferno, porquanto era
impossível que por este fosse ele retido. Ora, não havia dores no inferno dos Patriarcas, nem também
no das crianças, que não sofrem a pena dos sentidos, por causa do pecado atual, mas só a pena do
dano, por causa do pecado original. Logo, Cristo desceu ao inferno dos condenados, ou mesmo ao
purgatório onde as almas sofrem a pena dos sentidos, por causa dos pecados atuais.

3. Demais. — A Escritura diz que Cristo foi pregar aos espíritos que estavam no cárcere, que noutro
tempo tinham sido incrédulos. E isso, como o explica Atanásio, se entende da descida de Cristo aos
infernos. Pois, diz, que o corpo de Cristo foi deposto no sepulcro, quando se adiantou a pregar aos
espíritos que estavam no cárcere, como diz Pedro. Ora, sabemos que os incrédulos estavam no inferno
dos condenados. Logo, Cristo desceu ao inferno dos condenados.

4. Demais. — Diz Agostinho: Se a Escritura, dizendo que Cristo, depois da sua morte, foi ao seio de
Abraão, não quis com isso designar o inferno e as suas dores, admiro-me de quem ousasse afirmar que
desceu aos infernos. Mas desde que o inferno e os seus tormentos aí estão designados por um
testemunho evidente, nenhuma causa ocorre de crermos que ao inferno desceu o Salvador, senão para
livrar os que tais tormentos sofriam. Ora, o lugar dos tormentos é o inferno dos condenados, Logo,
Cristo desceu ao inferno dos condenados.

5. Demais. — Diz Agostinho, num Sermão sobre a Ressurreição, - que Cristo, descendo aos infernos,
libertou todos os justos, que nele estavam encerrados, por causa do pecado original. Ora, entre eles
estava também Jó, que diz de si mesmo: Todas as minhas causas desceram ao mais profundo dos
infernos. Logo, Cristo também desceu ao profundíssimo dos infernos.
Mas, em contrário, diz Jó do inferno dos condenados: Antes que vá para não tornar, para aquela terra
tenebrosa e coberta da escuridade da morte, etc. Ora, nenhum comércio pode haver entre a luz e as
trevas, diz o Apóstolo. Logo, Cristo, que é luz, não desceu ao interno dos condenados.

SOLUÇÃO. — De dois modos podemos dizer que um ser está num lugar. — Primeiro pelo seu efeito. E,
neste sentido, Cristo desceu a cada um dos infernos, mas de, maneiras diferentes. Assim, sobre o
inferno dos condenados produziu o efeito de descendo a eles, convencê-las da sua malícia e
incredulidade. Quanto aos detidos no purgatório, deu-lhes a esperança de alcançarem a glória. E aos
Santos Patriarcas, que só pelo pecado original estavam enclausurados no inferno, infundiu-lhes o lume
da glória eterna. - De outro modo, dizemos que um ser está num lugar, pela sua essência. E, neste
sentido a alma de Cristo desceu só ao lugar do inferno onde estavam encerrados os justos, a fim de que
os interiormente visitados pela graça da sua divindade, a esses também os visitasse localmente a sua
alma. Assim, pois, embora não estivesse localmente senão numa parte do inferno, contudo o seu efeito
de certo modo derivou para todas as partes dele; como também, tendo sofrido num lugar da terra,
libertou todo o mundo com a sua Paixão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo, a Sabedoria de Deus, penetrou todas as partes
inferiores da terra, não percorrendo-as todas, localmente, a sua alma, mas estendendo de certo modo a
todas o efeito do seu poder; mas de modo que iluminou só os justos. Assim, o lugar citado continua: E
esclarecerei a todos os que esperam no Senhor.

RESPOSTA À SEGUNDA. — Há duas espécies de dor. Uma é a resultante do sofrimento da pena que os
homens padecem, pelo pecado atual — segundo aquilo da Escritura: Dores do inferno me cercaram.
Outra é a dor resultante da dilatação da glória esperada, conforme o lugar da Escritura: A esperança que
se retarda aflige a alma. E essa era a. dor sofrida pelos santos Patriarcas no inferno. E para o significar
Agostinho diz, que oravam a Cristo, obscecando-o com lágrimas. — Ora, uma e outra dor Cristo fez
cessar, descendo aos infernos, mas de modos diferentes. Assim, solveu as dores das penas, preservando
delas, como dizemos que o médico cura a doença da qual nos preserva com o seu remédio. E as dores
causadas pela dilatação da glória solveu-as atualmente, dando a glória.

RESPOSTA À TERCEIRA. — O que diz Pedro, no lugar citado, alguns o referem àdescida de Cristo aos
infernos, expondo-o desta maneira: Aos que estavam no cárcere encerrados, isto é, no inferno, em
espírito, isto é, quanto àalma, a esse Cristo veio pregar, que foram antes incrédulos. Por isso diz
Damasceno: Assim como evangelizou aos que viviam na terra, assim também aos que estavam no
inferno; não certo para converter os incrédulos àfé, mas para convencê-los de infidelidade. Pois, não
podemos entender por essa pregação senão a manifestação da sua divindade aos encarcerados do
inferno pela milagrosa descida de Cristo até eles. - Mas Agostinho expõe melhor, referindo tais palavras,
não à descida de Cristo aos infernos, mas a um ato da sua divindade, que exerceu desde o princípio do
mundo. Sendo então o sentido: aos que estavam encerrados no cárcere, isto é, vivendo num corpo
mortal, que é um como cárcere da alma, a esses adiantou-se a pregar pelo espírito da sua divindade, por
inspirações internas e ainda mediante advertências externas pela boca dos justos. A esses, digo, pregou,
que outr'ora tinham sido incrédulos, isto é, a Noé que lhes pregou, quando contavam com a paciência
de Deus, pela qual diferisse a pena do dilúvio. E por isso Pedro acrescenta: Nos dias de Noé, quando se
fabricava a arca.

RESPOSTA À QUARTA. — O seio de Abraão pode ser entendido de dois modos. - Primeiro, pela isenção
que nele havia de toda pena sensível. E por aí, nem lhe cabia o nome de inferno, nem nenhumas dores
nele haviam. - Noutro sentido podemos considerá-la quando à privação da glória esperada. E então
implica a idéia de inferno e de dor. Por isso costumamos chamar seio de Abraão a esse repouso dos
bem-aventurados, sem contudo lhe chamar inferno; nem dizemos que houvesse dores no seio de
Abraão.

RESPOSTA À QUINTA. — Como diz Gregório no mesmo lugar, Jó chama inferno profundíssimo mesmo
às partes superiores do inferno. Se, pois, consideradas as alturas do céu, o nosso ar é um inferno
caliginoso; considerada a altura desse mesmo ar, a terra, que está na parte inferior, pode ser tomada
como um inferno profundo. Quanto, porém à altura mesma da terra, aqueles lugares do inferno,
superiores aos demais compartimentos dele, podem ser significados pela denominação, ora usada, de
inferno profundíssimo.

## Art. 3 — Se Cristo esteve todo no inferno.
O terceiro discute-se assim. — Parece que Cristo não esteve todo no inferno.

1. — Pois, o corpo de Cristo é uma das suas partes. Ora, o corpo de Cristo não esteve no inferno. Logo,
Cristo não esteve todo no inferno.

2. Demais. — Não pode ser considerado um todo o ser cujas partes estão separadas. Ora, o corpo e a
alma, partes da natureza humana, separaram-se um do outro depois da morte, como se disse. Mas,
Cristo desceu ao inferno, quando o seu corpo estava no sepulcro. Logo, não esteve todo no inferno.

3. Demais. — Dizemos que está todo num lugar o ser que não tem parte nenhuma fora desse lugar. Ora,
algo de Cristo estava fora do inferno, porque o corpo estava no sepulcro e a divindade, em toda parte.
Logo Cristo não esteve todo no inferno.
Mas em contrário, diz Agostinho: O Filho está todo junto ao Pai, todo no céu, todo naterra; esteve todo
no ventre da Virgem, todo na cruz, todo no inferno, e está todo no paraíso, onde introduziu o ladrão.

SOLUÇÃO. — Como se colhe do que dissemos na Primeira Parte, o gênero masculino se refere à
hipóstase ou à pessoa; e o gênero neutro, à natureza. Ora, na morte de Cristo, embora a alma estivesse
separada do corpo, nem este nem aquela porém estavam separados da pessoa do Filho de Deus, como
dissemos. Por onde, durante o tríduo da morte de Cristo, devemos admitir que Cristo esteve todo
inteiro no sepulcro; pois a sua pessoa aí esteve toda, mediante o corpo que lhe estava unido. E
semelhantemente, esteve todo no inferno, porque nele esteve toda a pessoa de Cristo, em razão da
alma que lhe estava unida. Etambém Cristo estava então todo em toda parte, em razão da natureza
divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O corpo que então esteve no sepulcro, não era parte da
pessoa incriada, mas da natureza assumida. Por onde, o fato de o corpo de Cristo não ter descido do
inferno, não impedia o Cristo de nele ter estado todo; mas mostra que nele não esteve o todo
constitutivo da natureza humana.

RESPOSTA À SEGUNDA. — Da alma e do corpo unidos constitui-se a totalidade da natureza humana,
mas não a totalidade da pessoa divina. Por onde, separada a alma do corpo pela morte, permaneceu
Cristo íntegro; mas não permaneceu a natureza humana em sua totalidade.

RESPOSTA À TERCEIRA. — A pessoa de Cristo está toda em qualquer lugar, mas não totalmente por não
ser circunscrita por nenhum lugar. Mas, nem todos os lugares tomados simultaneamente podem
compreender-lhe a imensidade; ao contrário, é a sua imensidade que os abrange a todos. O que a
objeção diz é exato, quando se trata de seres que estão corporal e circunscritivamente num lugar; pois,
estando um corpo num lugar, nenhuma parte dele está fora desse lugar. Ora, tal não se dá com Deus.
Donde o dizer Agostinho: Não afirmamos que Cristo está todo nos diversos tempos ou nos diversos
lugares, de maneira que esteja todo num lugar, durante um certo tempo, e todo em outro, noutro
tempo; mas que sempre está todo em toda parte.

## Art. 4 — Se Cristo se demorou algum tempo no inferno.
O quarto discute-se assim. — Parece que Cristo não se demorou nenhum tempo no inferno.

1. — Pois, Cristo desceu ao inferno para que dele livrasse os homens. Ora, ele o fez imediatamente com
a sua descida; pois, é fácil a Deus enriquecer de repente ao pobre, como diz a Escritura. Logo, parece
que não se demorou nenhum tempo no inferno.

2. Demais. — Agostinho diz: Por ordem do Senhor e Salvador, sem nenhuma demora se quebraram
todas as portas de ferro. Por isso, da pessoa dos anjos, que acompanhavam a Cristo, diz a Escritura:
Levantai, ópríncipes, as vossas portas. Ora, Cristo desceu ao inferno para lhe quebrar as trancas. Logo,
Cristo não se demorou nenhum tempo no inferno.

3. Demais. — O Evangelho refere que Cristo, pendente da Cruz, disse ao ladrão: Hoje estarás comigo no
Paraíso — e isso mostra que no mesmo dia Cristo esteve no Paraíso. Ora, não pelo corpo, que estava
depositado no sepulcro. Logo, pela alma, que descera ao inferna. E, portanto parece que nenhum tempo
se demorou no inferno.
Mas, em contrário, diz Pedro: Ao qual, Deus ressuscitou soltas as dores do inferno, porquanto era
impossível que por este fosse ele retido. Logo, parece que até à hora da ressurreição permaneceu no
inferno.

SOLUÇÃO. — Assim como Cristo, para tomar sobre si as nossas penas, quis que o seu corpo fosse
depositado no sepulcro, assim também quis que a sua alma descesse ao inferno. Ora, o seu corpo
permaneceu no sepulcro por um dia inteiro e duas noites, para comprovar a verdade da sua morte. E
por isso devemos crer que outro tanto a sua alma se demorou no inferno; de modo a saírem
simultaneamente - a alma, do inferno e o corpo, do sepulcro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo, tendo descido aos infernos, tirou de lá os santos
que nele permaneciam; não pelos livrar imediatamente do cárcere infernal, mas pelos iluminar, mesmo
no inferno, com a luz da glória. E, contudo era conveniente, que a sua alma permanecesse no inferno
por tanto tempo quanto o corpo lhe permaneceu no sepulcro.

RESPOSTA À SEGUNDA. — Trancas do inferno se chamam os obstáculos que impediam os santos
Patriarcas de sair dele, pelo reato da culpa dos nossos primeiros Pais. As quais Cristo, descendo aos
infernos, as quebrou imediatamente pela virtude da sua paixão e morte. E, contudo quis permanecer no
inferno durante algum tempo, pela razão predita.

RESPOSTA À TERCEIRA. — Essas palavras do Senhor devem entender-se, não do paraíso terrestre
material, mas do paraíso espiritual, onde dizemos que estão todos os que gozam da glória divina. Por
isso o ladrão, desceu certo, localmente com Cristo ao inferno, para estar com Cristo, conforme lhe tinha
sido dito - hoje estarás comigo no Paraíso. Mas por premio esteve no. Paraíso porque aí gozava da
divindade de Cristo, como dela gozavam os outros Santos.

## Art. 5 — Se Cristo, descendo aos infernos, dele livrou os Santos Patriarcas.
O quinto discute-se assim. — Parece que Cristo, descendo aos infernos, dele não livrou os santos
Patriarcas.

1. — Pois, diz Agostinho: Ainda não pude descobrir em que a descida de Cristo aos infernos foi útil aos
que estavam no seio de Abraão; pois, não vejo que jamais estivessem privados da presença beatifica da
sua divindade. Ora, muito útil lhes teria sido se os tivesse livrado dos infernos. Logo parece que Cristo
não livrou os santos Patriarcas, dos infernos.

2. Demais. — Ninguém é retido no inferno senão por causa de pecado. Ora, os santos Patriarcas,
enquanto viviam, foram justificados do pecado pela fé de Cristo. Logo, não precisavam de ser libertos do
inferno, pela descida de Cristo a esse lugar.

3. Demais. — Removida a causa, removido fica o efeito. Ora, a causa da descida aos infernos é o pecado
que foi removido pela Paixão de Cristo, como se disse. Logo, a descida de Cristo ao inferno não livrou
dele os santos Patriarcas.
Mas, em contrário, diz Agostinho: Cristo, quando desceu aos infernos, quebrou a porta e as trancas
infernais e libertou todos os justos, que estavam encarcerados em virtude do pecado original.

SOLUÇÃO. — Como dissemos Cristo, descendo aos infernos, operou em virtude da sua Paixão. Ora, a
Paixão de Cristo liberou o gênero humano, não só do pecado, mas também do reato da pena, como se
disse. Ora, de dois modos os homens estavam adstritos ao reato da pena: pelo pecado atual, que todos
pessoalmente cometeram, e pelo pecado de toda a natureza humana, que se transmitiu originalmente
dos primeiros Pais a todos, como diz o Apóstolo. E desse pecado a pena é a morte do corpo e a exclusão
da vida da glória, conforme resulta do que refere a Escritura; pois, Deus expulsou o homem do Paraíso,
depois do pecado, a quem, antes do Pecado, fora cominada a morte, se pecasse. Por isso Cristo,
descendo aos infernos, em virtude da sua Paixão livrou os santos Patriarcas desse reato pelo qual
estavam excluídos da vida da glória de modo a não poderem ver a Deus em essência, no que consiste a
perfeita beatitude do homem, como dissemos na Segunda Parte. Ora, os santos Patriarcas estavam
detidos no inferno por não lhe ser franqueada a vida da glória, por causa do pecado dos nossos
primeiros Pais. E assim Cristo, descendo aos infernos, deles livrou os santos Patriarcas. E tal é o que diz a
Escritura: Tu também pelo sangue do teu testamento fizeste sair os teus presos do lago em que não há
água. E o Apóstolo: Despojando os principados e potestades, isto é, infernais; e livrando, como comenta
a Glosa a esse lugar, Abraão, Isaac, Jacó e os demais justos, transportou-os, isto é, conduziu-os para o
céu, longe desse reino das trevas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No lugar referido Agostinho se dirige contra certos que
pensavam estarem os justos antigos antes do advento de Cristo, sujeitos às dores das penas, no inferno.
Por isso, pouco antes das palavras citadas, tinha dito: Certos acrescentam, que foi concedido também
aos antigos santos, o benefício de ficarem livres das suas dores, quando o Senhor desceu aos infernos.
Mas eu por mim não vejo de que modo se possa compreender, que sofresse as referidas dores Abraão,
em cujo seio foi também recebido o pobre do Evangelho. Por isso, o que depois acrescenta, que ainda
não pode descobrir em que a descida de Cristo aos infernos fosse útil aos referidos justos, devemos
entendê-la quanto ao livramento das dores das penas. Isso porém lhes aproveitou para alcançarem a
glória; e por consequência libertou-os da dor que sofriam pelo diferimento dessa glória. Cuja esperança
porém lhes causava grande alegria, segundo aquilo do Evangelho: Vosso pai Abraão desejou
ansiosamente ver o meu dia. E por isso acrescenta Agostinho: Não vejo que Cristo tivesse jamais se
afastado dele pela presença beatifica da sua divindade: Isto é, porque antes do advento de Cristo já
eram bem-aventurados em esperança, embora ainda não o fossem perfeitamente na realidade.

RESPOSTA À SEGUNDA. — Os santos Patriarcas, enquanto ainda viviam, foram liberados por Cristo de
todo pecado, tanto original, como atual, e do reato da pena dos pecados atuais. Mas não do reato da
pena do pecado original, pelo qual ficavam excluídos da glória, porque ainda não estava pago o preço da
redenção humana. Assim como agora os fiéis de Cristo são liberados pelo batismo do reato dos pecados
atuais, e do reato do original, quanto à exclusão da glória. Mas ainda ficam ligados ao reato do pecado
original, quanto à necessidade de sofrerem a morte do corpo. Porque são renovados em espírito, mas
não na carne, segundo aquilo do Apóstolo: O corpo verdadeiramente está morto pelo pecado, mas o
espírito vive pela justificação.

RESPOSTA À TERCEIRA. — Logo que Cristo morreu, a sua alma desceu ao inferno e fez aproveitar o fruto
da sua Paixão aos santos detidos nesse lugar. Embora daí não saísse enquanto Cristo se conservava no
meio deles; pois a presença mesma de Cristo constituia-lhes o cúmulo da glória.

## Art. 6 — Se Cristo livrou alguns condenados do inferno.
O sexto discute-se assim. — Parece que Cristo livrou certos condenados do inferno.

1. — Pois, diz a Escritura: Serão atados todos juntos num feixe para serem lançados no lago e ficarão ali
encerrados no cárcere e depois de muitos dias serão visitados. E esse lugar se refere aos condenados
que adoraram a milícia do céu. Logo, parece que também os condenados Cristo os visitou na sua descida
dos infernos. O que portanto lhes dizia respeito àliberação.

2. Demais. — Ao lugar da Escritura: Tu também pelo sangue do teu testamento fizeste sair os teus
presos do lago em que não há água — diz a Glosa: Tu livraste os que estavam retidos presos nos
cárceres, onde não os refrigerava em nada aquela misericórdia pedida pelo rico do Evangelho. Ora, só os
condenados são os encerrados em cárceres, sem misericórdia. Logo, Cristo libertou certos condenados
do inferno.

3. Demais. — O poder de Cristo não foi menor no inferno que neste mundo; pois, em ambos esses
lugares ele agiu pelo poder da sua divindade. Ora, neste mundo libertou muitos, de todos os estados.
Logo, também livrou certos dos condenados do inferno.
Mas, em contrário, a Escritura: Òmorte, eu serei a tua morte; ó inferno, eu serei a tua mordedura! E
comenta a Glosa: Tirando do inferno os eleitos, mas lá deixando os réprobos. Ora, só os réprobos estão
no inferno dos condenados. Logo, pela descida de Cristo aos infernos não foi livrado nenhum dos
condenados.

SOLUÇÃO. — Como dissemos Cristo, descendo aos infernos, obrou em virtude da sua Paixão. Por onde,
a sua descida aos infernos só produziu o fruto da libertação aos que estavam unidos à Paixão de Cristo
pela féinformada pela caridade, que tira os pecados. Quanto aos condenados ao inferno, ou de todo não
tinham fé na Paixão de Cristo, como os infiéis; ou se a tinham, nenhuma conformidade tinham com a
caridade de Cristo padecente. Por isso também não foram purificados dos seus pecados. Por onde, a
descida de Cristo aos infernos não lhes causou a liberação do reato da pena infernal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pela sua descida aos infernos Cristo de certo modo
visitou todos os que estavam em qualquer parte deles. Mas certos, para consolação e libertação; e
certos outros, os condenados, para vergonha e confusão. Por isso, no mesmo lugar se acrescenta: E a
lua se envergonhará e se confundirá o sol, etc. — Mas a passagem pode ainda referir-se à visitação que
hão de receber os condenados no dia de juízo, não para serem livrados, mas para serem mais
confirmados na sua condenação, segundo aquilo da Escritura: Virei com a minha visita sobre os homens
que estão encravados nas suas fezes.

RESPOSTA À SEGUNDA. — O dito da Glosa — nenhuma misericórdia os refrigerava, entende-se do
refrigério da perfeita liberação. Porque os santos Patriarcas não podiam ser livrados dos cárceres do
inferno, antes do advento de Cristo.

RESPOSTA À TERCEIRA. — Não foi por falta de poder que Cristo não livrou a certos de cada um dos
estados do inferno, como livrou a muitos dos vários estados da terra; mas por causa das condições
diversas destes e daqueles. Pois, os homens, enquanto vivem podem converter-se àfé e àcaridade;
porque nesta vida não estão confirmados no bem nem no mal, como o estarão depois de saírem dela.

## Art. 7 — Se as crianças mortas no pecado original foram livradas pela descida de Cristo.
O sétimo discute-se assim. — Parece que as crianças mortas no pecado original foram livradas pela
descida de Cristo.

1. — Pois, não estavam encerradas no inferno por causa do pecado original, como o estavam os santos
Patriarcas. Ora, os santos Patriarcas foram livrados do inferno por Cristo, como se disse. Logo e
semelhantemente, também as crianças foram livradas do inferno por Cristo.

2. Demais. — O Apóstolo diz: Se pelo pecado de um morreram muitos, muito mais a graça de Deus e o
dorn pela graça de um só homem, que é Jesus Cristo, abundou sobre rnuitos. Ora, por causa do pecado
de nossos Primeiros Pais, as crianças, mortas só no estado do pecado original são retidas no inferno.
Logo, com maior razão, pela graça de Cristo são dele livradas.

3. Demais. — Assim como o batismo obra em virtude da Paixão de Cristo, assim também a sua descida
aos internos, como do sobredito resulta. Ora, as crianças são livradas pelo batismo do pecado original e
do inferno. Logo e semelhantemente, foram livradas pela descida de Cristo aos infernos.
Mas, em contrário, o Apóstolo diz: Deus propôs a Cristo para ser vítima de propiciação pela fé no seu
sangue. Ora, as crianças mortas no estado do só pecado original de nenhum modo foram participantes
da fé de Cristo. Logo, não receberam o fruto da propiciação de Cristo, de modo que por ele ficassem
livres do inferno.

SOLUÇÃO. — Como se disse, a descida de Cristo aos internos só teve o efeito de libertar aqueles que
estavam unidos pela fé e pela caridade à sua Paixão, em virtude da qual essa descida do inferno era
liberatória. Ora, as crianças mortas no estado de pecado original de nenhum modo estavam unidas à
Paixão de Cristo pela fé e pelo amor; nem podiam ter fé própria, porque não tinham o uso do livre
arbítrio; nem foram purificadas do pecado original pela fé dos pais nem por nenhum sacramento da fé.
Por onde, a descida de Cristo aos infernos não libertou essas crianças do inferno. — E além disso, os
santos Patriarcas foram liberados doinferno por terem sido admitidos àglória da visão divina; àqual
ninguém pode chegar senão pela graça, segundo aquilo do Apóstolo — A graça de Deus é a vida eterna.
Ora, como as crianças mortas em estado de pecado original não tinham a graça, não foram libertadas do
inferno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os santos Patriarcas, embora ainda estivessem adstritos
ao reato do pecado original, por causa de sua natureza humana, contudo foram liberados pela fé de
Cristo de toda mácula de pecado. E por isso eram capazes daquela liberação que Cristo trouxe,
descendo aos infernos. Mas o mesmo não podemos dizer das crianças, como do sobre dito resulta.

RESPOSTA À SEGUNDA. — Quando o Apóstolo diz — A graça de Deus abundou sobre muitos, a palavra
muitos não deve ser tomada em sentido comparativo, como se fossem em maior número os salvos pela
graça de Cristo do que os condenados pelo pecado de Adão. Mas em sentido absoluto, quase se dissesse
que a graça do só Cristo abundou sobre muitos, assim como o pecado único de Adão contaminou a
muito. Mas, o pecado de Adão contaminou só aqueles que descenderam dele carnalmente por via de
geração; assim também a graça de Cristo só a receberam aqueles que se tornaram membros seus; pela
regeneração espiritual. O que não convém às crianças mortas era pecado original.

RESPOSTA À TERCEIRA. — O batismo é aplicado aos homens nesta vida, quando podemos passar da
culpa para a graça. Ora, pela descida aos infernos Cristo visitou as almas saídas desta vida, quando já
não eram capazes da referida mudança. Por isso, as crianças pelo batismo são libertadas do pecado
original e do inferno; mas não pela descida de Cristo aos infernos.

## Art. 8 — Se Cristo, com a sua descida aos infernos, livrou as almas do purgatório.
O oitavo discute-se assim. — Parece que Cristo, com a sua descida aos infernos livrou as almas do
purgatório.

1. — Pois, diz Agostinho: Como há testemunhos evidentes que nos falam do inferno e das suas dores,
nenhuma razão temos de crer que o Salvador a ele descesse senão para livrar dessas dores os infelizes
que as sofriam. Mas o que ainda queria saber é se livrou todos os que nesse lugar encontrou, ou só os
que julgou dignos desses benefícios. Contudo não duvido ter Cristo descido aos infernos e ter conferido
tal benefício aos que sofriam as suas dores. Ora, não conferiu o benefício da liberação aos condenados,
como se disse. Mas, além deles não há outros que padeçam tais dores senão os que estão no
purgatório. Logo, Cristo livrou as almas do purgatório.

2. Demais. — A presença mesma da alma de Cristo não produziu efeito menor que os seus sacramentos.
Ora, pelos sacramentos de Cristo as almas são libertas do purgatório; e sobretudo pelo sacramento da
Eucaristia, como se disse. Logo, com maior razão, pela presença de Cristo descendo aos infernos, foram
livradas as almas do purgatório.

3. Demais. — Cristo curou totalmente os que nesta vida curou, como diz Agostinho. E no Evangelho o
Senhor diz: Em dia de sábado curei a todo um homem. Ora, Cristo livrou os que estavam no purgatório
do reato da pena do dano, que os excluía da glória. Logo, também os livrou do reato da pena do
purgatório.
Mas, em contrário, diz Gregório: O nosso Criador e Redentor, peneirando as clausuras do inferno, de lá
tirou as almas dos eleitos e não nos permite mais ir para esse lugar, donde livrou a outros com a sua
descida. Ora, permite que vamos ao purgatório. Logo, descendo aos infernos, não libertou as almas do
purgatório.

SOLUÇÃO. — Como dissemos, a descida de Cristo aos infernos teve um efeito liberatório em virtude da
sua Paixão. Ora, a sua Paixão não produz efeito temporal e transitório, mas sempiterno, segundo aquilo
do Apóstolo: Com uma só oferenda fezperfeitos para sempre aos que tem santificado. Por onde é claro,
que a Paixão de Cristo não teve maior eficácia que a que atualmente tem. Portanto, os que então
estavam em situação semelhante às almas atualmente detidas no purgatório não foram livrados deste
pela descida de Cristo aos infernos. Mas se porventura então existiam tais quais os que agora são
livrados do purgatório em virtude da Paixão de Cristo, esses nada impede fossem livrados do purgatório
pela descida de Cristo aos infernos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Do lugar citado de Agostinho não se pode concluir que
todos os detidos no purgatório foram dele livrados, mas que só a alguns deles foi conferido esse
benefício. Isto é, aos que estavam suficientemente purificados; ou então aos que, ainda vivendo,
mereceram, pela fé, amor e devoção para com a Paixão de Cristo, serem livrados, pela descida de Cristo,
da pena temporal do purgatório.

RESPOSTA À SEGUNDA. — A virtude de Cristo obra nos sacramentos sanando e expiando. Por isso, o
sacramento da Igreja livra o homem do purgatório, por ser um sacrifício satisfatório pelo pecado. Ora, o
descenço de Cristo aos infernos não foi satisfatório. Mas obrava em virtude da Paixão, que era
satisfatória, como estabelecemos; mas era satisfatória em geral, devendo a sua virtude ser aplicada a
cada um por algo a cada um especial. Por onde, não era necessário que pela descida de Cristo aos
infernos, todos fossem libertos do purgatório.

RESPOSTA À TERCEIRA. — Os defeitos, de que Cristo livrava todos os homens simultaneamente neste
mundo, eram pessoais, atinentes propriamente a cada um. Mas a exclusão da glória de Deus era uma
miséria geral atinente a toda a natureza humana. Por onde, nada impedia terem sido livrados por Cristo
os que estavam no purgatório, da exclusão da glória, mas não do reato da pena do purgatório,
necessitada pelos defeitos próprios de cada um. Assim como ao inverso, os santos Patriarcas, antes do
advento de Cristo, foram liberados dos seus defeitos próprios, mas não do defeito comum à natureza
humana, como se disse.