# Questão 88: Do redito dos pecados perdoados pela penitência
Em seguida devemos tratar do rédito dos pecados perdoados pela penitência.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se os pecados perdoados ressurgem por causa de um pecado subseqüente.
O primeiro discute-se assim. — Parece que os pecados subsequentes fazem ressurgir os pecados
perdoados.

1. — Pois, diz Agostinho: Que os pecados perdoados ressurgem na alma sem caridade fraterna, Cristo
nô-lo ensina mui claramente na parábola do servo a quem o Senhor repetiu a dívida perdoada, por não
querer esse servo perdoar a de seu companheiro. Ora, a caridade fraterna qualquer pecado mortal a faz
desaparecer. Logo, qualquer pecado mortal subsequente faz ressurgirem os pecados já perdoados pela
penitência.

2. Demais. — Aquilo do Evangelho: Tornarei para minha casa, de onde saí — diz Beda: Versículo para
temer-se e não para explicar-se; ar fim de que a culpa que já críamos extinta em nós, não nos esmague
quando a nossa incúria nos trazia descuidados. Ora, tal não se daria se ela não voltasse. Logo, a culpa
perdoada pela penitência ressurge.

3. Demais. — O Senhor diz: Se o justo se afasta da sua justiça e vier a cometer a inquidade de nenhuma
das obras de justiça que tiver feito se fará memória. Ora, nas obras de justiça que fez também se inclui a
penitência precedente; pois, como dissemos, a penitência faz parte da justiça. Logo, ao penitente
recaído no pecado não se lhe imputa a penitência precedente, pela qual alcançou o perdão dos pecados.
Portanto, tais pecados ressurgem.

4. Demais. — Os pecados passados são cobertos pela graça, como claramente o diz o Apóstolo, citando
aquilo da Escritura: Bem aventurados aqueles cujas iniqüidades são perdoadas e cujos pecados são
cobertos. Ora, um pecado mortal subsequente expulsa a graça. Logo, os pecados anteriormente
cometidos ficam descobertos. E assim, parece que ressurgem.
Mas, em contrário, o Apóstolo: Os dons e a vocação de Deus são imutáveis. Ora os pecados do penitente
são perdoados por um dom de Deus. Logo, os pecados subsequentes não fazem ressurgir os pecados
cometidos, como se Deus se arrependesse do dom do perdão.

2. Demais. — Agostinho diz: Quem se separou de Cristo e acabou esta vida privado da graça, para onde
pode ir senão para a perdição? Mas não tem que dar contas dos pecados que lhe foram perdoados nem
será condenado por causa do pecado original.

SOLUÇÃO. — Como dissemos, dois elementos encerra o pecado mortal — a versão de Deus e a
conversão para os bens criados. — Ora, tudo o que o pecado mortal encerra da parte da aversão, em si
mesmo considerado, é comum a todos os pecados mortais; porque por qualquer pecado mortal o
homem se separa de Deus. Por onde e consequentemente, a mácula resultante da privação da graça e o
reato da pena eterna são comuns a todos os pecados mortais. E é este o sentido daquele lugar da
Escritura: Quem faltar em um só ponto faz-se réu de ter violado a todos. — Mas da parte da conversão,
os pecados mortais são diversos e às vezes contrários. Por onde, é manifesto, que da parte da
conversão, o pecado mortal subsequente não faz ressurgirem os pecados mortais já perdoados; do
contrário resultaria, que o pecado de prodigalidade faria renascer em nós o hábito ou a disposição da
avareza já perdoada; e então, um contrário seria a causa de outro, o que é impossível. — Mas
considerando nos pecados mortais e de maneira absoluta o resultado da aversão, o pecado mortal
subsequente nos priva da graça e nos torna réu da pena, eterna, como anteriormente o fôramos. — A
aversão porém no pecado mortal se diversifica de certo modo pela sua relação com os diversos
movimentos de conversão para os bens criados, que são deles as causas diversas. De maneira que
diferem a aversão, a mácula e o reato, conforme o pecado mortal donde resultam. E assim a questão
vertente vem a ser o seguinte: se a mácula e o reato da pena eterna, enquanto causados pelos atos dos
pecados já perdoados ressurgem em virtude do pecado subsequente. Ora, certos pensam que desse
modo, os pecados mortais ressurgem, absolutamente falando. — Mas isto não é possível. Porque as
obras do homem não podem tornar irritas as de Deus.
Ora, o perdão dos pecados anteriores foi obra da misericórdia divina. Portanto, não pode torná-lo írrito
o pecado subsequente. Donde o dizer o Apóstolo: Porventura a sua incredulidade destruirá a fidelidade
de Deus? Por isso outros, admitindo que os pecados ressurgem disseram, que Deus não perdoa os
pecados ao penitente do qual sabe, na sua presciência, que tornará a pecar, mas só o perdoa pela sua
justiça atual. Pois, embora preveja a punição eterna do pecador, por causa desses pecados, contudo a
sua graça o torna atualmente justo. — Mas também isto não pode manter-se. Pois, posta
absolutamente a causa, também resulta absolutamente o efeito. Se portanto a graça e os sacramentos
da graça não obrassem a remissão dos pecados absolutamente, mas só condicionalmente e num futuro
dependente, resultaria que a graça e os sacramentos da graça não seriam causa suficiente da remissão
dos pecados. O que é errôneo por derrogar à graça de Deus. Por onde, de nenhum modo podem
ressurgir a mácula e o reato dos pecados precedentes, enquanto foram por tais atos causados. Pode
dar-se porém, que o ato pecaminoso subsequente contenha virtualmente o reato do pecado anterior;
isto é, quando, recaindo no pecado, por isso mesmo pecamos mais gravemente que antes o fizéramos,
segundo àquilo do Apóstolo: Pela tua dureza e coração impenitente entesouras para ti ira no dia da ira,
pelo só fato de ser desprezada a bondade de Deus, que espera pela nossa penitência. Pois, supõe um
desprezo muito maior da bondade de Deus reincidirmos no pecado anteriormente perdoado; e tanto
mais quanto maior é o beneficio do perdão que o da simples paciência para com o pecador.
Assim, pois, pelo pecado subsequente, à penitência, ressurge de certo modo o reato dos pecados
anteriormente perdoados, não enquanto causado por esses pecados já perdoados mas enquanto
causado pelo pecado perpetrado em último lugar, que fica mais grave, em virtude dos pecados
anteriores. O que não é ressurgirem os pecados perdoados, absolutamente falando, mas de certo modo;
isto é, enquanto virtualmente contidos no pecado subseqüente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — — As palavras citadas de Agostinho devem entender-se
como referentes à volta dos pecados, quanto ao reato da pena eterna em si mesmo considerado.
Porque a reincidente no pecado, após a penitência feita, incorre no reato da pena eterna, como já
incorrera antes; mas não pela razão absolutamente o mesmo. Por isso Agostinho, depois de ter dito não
reincide no mesmo pecado já perdoado, nem será condenado por causa do pecado original, acrescenta:
Contudo, esse mesmo pecado sofrerá a morte que lhe era devida por causa dos pecados cometidos;
pois incorrerá na morte eterna, merecida pelos pecados passados.

RESPOSTA À SEGUNDA. — Com essas palavras não pretende dizer Beda, que a culpa antes perdoada
nos oprima pela volta do reato passado; mas, pela reiteração do ato.

RESPOSTA À TERCEIRA. — O pecado cometido depois da penitência faz cair no esquecimento os
precedentes atos de justiça, enquanto merecedores da vida eterna; mas não enquanto obstáculos ao
pecado. Por onde, quem peca mortalmente, depois de ter pago o devido, não fica sendo réu como se
não no tivesse pago. E muito menos cai no esquecimento o ato de penitência antes praticado, quanto à
remissão da culpa, que é obra mais de Deus que do homem.

RESPOSTA À QUARTA. — A graça apaga a mácula e o reato da pena eterna, absolutamente falando: mas
cobre os atos pecaminosos passados, de modo que por causa deles Deus não nos prive da graça e nos
faça réu de pena eterna. E o que a graça faz uma vez, permanece perpetuamente.

## Art. 2 — Se os pecados perdoados fá-los ressurgir a ingratidão, que se manifesta especialmente por quatro gêneros de pecados.
O segundo discute-se assim. — Parece que os pecados perdoados não os faz ressurgir a ingratidão,
que se manifesta especialmente pelos quatro gêneros seguintes de pecado: o ódio fraterno a
apostasia da fé, o desprezo da confissão e a dor da penitência praticada, segundo alguém o disse em
versos; Odeia os irmãos, torna-se apóstata, despreza a confissão. Pesa-se da penitência, a antiga culpa
volta.

1. — Pois, tanto maior é a ingratidão, quanto mais grave é o pecado que cometemos contra Deus,
depois do benefício da remissão dos pecados. Ora, certos pecados, como a blasfémia contra Deus e o
pecado contra o Espírito Santo, não mais graves que esses. Logo, parece que os pecados perdoados não
voltam por via, antes, da ingratidão causada pelos referidos pecados, que pelos outros.

2. Demais. — Rabão diz: O Senhor entregou aos tormentos o servo mau, até que pagasse toda a dívida,
porque não só os pecados que cometeu depois do batismo foram-lhe reputados a pena, mas também as
manchas originais que no batismo se lhe apagaram. Ora, também os pecados veniais se contam como
dívidas, e por causa deles pedimos: Perdoai-nos as nossas dívidas. Logo, também eles a ingratidão os faz
voltar. E pela mesma razão, parece que os pecados veniais fazem ressurgir os pecados já perdoados, e
não só os pecados referidos é que produzem esse efeito.

3. Demais. — Tanto maior é a ingratidão quando o pecado é cometido depois de se receber um
benefício. Ora, entre os benefícios de Deus está também a inocência, pela qual evitamos o pecado.
Assim, diz Agostinho: A tua graça devo não ter praticado todos os pecados que não cometi. Ora, a
inocência é maior dom mesmo que a remissão de todos os pecados. Logo, não menos ingrato é para
com Deus quem comete o primeiro pecado, depois da inocência que quem peca depois da penitência. E
assim, parece que a ingratidão dos pecados referidos não é a maior causa da volta desses mesmos
pecados.
Mas, em contrário, Gregório diz: Das palavras do Evangelho consta, que se não perdoamos de coração
as injúrias que nos são feitas, também será exigido de nós o que já nos comprazíamos como perdoados
pela penitência. E assim, a ingratidão especial, que supõe o ódio ao próximo, faz ressurgir os pecados já
perdoados, o mesmo devendo dizer-se dos demais pecados referidos.

SOLUÇÃO. — Como dissemos, afirmamos que os pecados perdoados pela penitência ressurgem
enquanto o reato deles, por força da ingratidão, estão virtualmente contidos no pecado subsequente.
Ora, a ingratidão pode ser cometida de dois modos. — Primeiro, agindo contra o beneficio recebido. E
deste modo, por qualquer pecado mortal subsequente à penitência voltam os pecados já cometidos, em
virtude da ingratidão. — De outro modo, comete-se a ingratidão, não só agindo diretamente contra o
benefício, mas ainda contra a forma do benefício recebido. E essa forma, considerada em relação ao
benfeitor, é a remissão das dívidas. Portanto, procede contra essa forma quem não perdoa ao irmão
que lh'o pede, mas continua a odiá-lo. Considerada em relação ao penitente, que recebe esse benefício,
descobrimos nele um duplo movimento do livre arbítrio. O primeiro para Deus, o que é um ato de fé
informada; e contra isso procede quem apostata da fé. O segundo é o movimento do livre arbítrio para
o pecado, que é um ato de penitência. Ora, pelo primeiro, como dissemos, detestamos os pecados
passados: e contra isso procede quem se arrepende de ter feito penitência. Pelo segundo o ato de
penitência desperta no penitente o propósito de sujeitar-se às chaves da Igreja pela confissão, segundo
aquilo da Escritura: Eu disse: confessarei ao Senhor contra mim a minha injustiça; e tu me perdoaste a
impiedade do meu pecado. E contra isto vai quem deixa de confessar-se, como havia prometido. — Por
isso se diz que a ingratidão, que os referidos pecados supõem, faz ressurgirem os pecados
anteriormente perdoados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O que se atribui especialmente a esses dois pecados,
referidos não é por serem mais graves que os outros; mas por se oporém mais diretamente ao benefício
da remissão dos pecados.

RESPOSTA À SEGUNDA. — Mesmo os pecados veniais e o pecado original voltam da maneira predita,
assim como os pecados mortais, por se desprezar o benefício de Deus, pelo qual esses pecados foram
perdoados. Nem por isso o pecado venial nos faz incorrer na ingratidão; porque, pecando venialmente,
não agimos contra Deus, mas contra nós mesmos. Portanto, os pecados veniais de nenhum modo fazem
ressurgir os pecados perdoados.

RESPOSTA À TERCEIRA. — Qualquer benefício pode ser apreciado de dois modos. Pela sua quantidade e
então a inocência é maior beneficio de Deus que a penitência, chamada a segunda tábua depois do
naufrágio. Ou relativamente a quem o recebe que é menos digno. E então é lhe feita uma graça maior e
portanto, é mais ingrato se despreza o beneficio. E deste modo, o benefício da remissão da culpa é
maior quanto feito a quem é dele totalmente indigno. Donde, pois, resulta maior ingratidão.

## Art. 3 — Se a ingratidão do pecado subseqüente à penitência faz ressurgir um tão grande reato quanto o fora o dos pecados antes perdoados.
O terceiro discute-se assim. — Parece que a ingratidão do pecado subseqüente à penitência faz
ressurgir um tão grande reato quanto o fora o dos pecados antes perdoados.

1. — Pois, tal a grandeza do pecado e tal a grandeza do benefício pelo qual ele é perdoado. E por
conseqüência, a grandeza da ingratidão, pela qual esse benefício é desprezado. Ora, a quantidade de
ingratidão depende da quantidade do reato subseqüente. Logo, a ingratidão do pecado subseqüente à
penitência faz ressurgir um tão grande reato quanto o fora o reato de todos os pecados procedentes.

2. Demais. — Mais peca quem ofende a Deus que quem nos ofende. Ora, o servo manumisso e culpado
é reduzido pelo Senhor à mesma escravidão que antes, e talvez pior. Logo e com maior razão, quem
peca contra Deus depois de liberto pelo pecado recai no mesmo reato da pena em que estava antes.

3. Demais. — Refere o Evangelho que o Senhor, cheio de cólera, mandou Que o entregassem, aquele a
quem os pecados perdoados tinham sido reimputados por causa da sua ingratidão, aos algozes até
pagar toda a dívida. Ora, tal não se daria se a ingratidão causasse um tão grande reato como o foi o de
todos os pecados passados. Logo, a ingratidão faz ressurgir um reato igual.
Mas, em contrário, diz a Escritura: O número dos golpes regular-se-á pela qualidade do pecado. Por
onde, é claro, que um pequeno pecado não causa um grande reato, Mas às vezes o pecado mortal
subseqüente à penitência é muito menor que qualquer dos pecados antes perdoados. Logo, o pecado
subseqüente à penitência não faz surgir um tão grande reato quanto o fora o dos pecados já perdoados.

SOLUÇÃO. — Certos disseram, que o pecado subseqüente produz, por causa da sua ingratidão, um tão
grande reato quanto o fora o dos pecados já perdoados, além do reato próprio a esse pecado. — Mas
não é necessário que assim seja. Porque, como vimos o reato dos pecados precedentes não volta por
causa do pecado subsequente, enquanto resultava dos atos pecaminosos passados, mas enquanto
procedente do ato desse pecado consecutivo à penitência. Por onde e necessariamente, a intensidade
do reato, que ressurge, há de depender da gravidade do pecado subsequente. Mas isto nem sempre se
dá necessariamente, quer nos referimos à sua gravidade especifica, como, por exemplo, no caso de ser
o pecado subsequente uma fornicação simples, e os pecados terem sido adultérios, homicídios ou
sacrilégios; quer consideremos a sua gravidade resultante da ingratidão anexa. Pois não é necessário
seja a extensão da ingratidão absolutamente igual à quantidade do benefício recebido cuja quantidade
depende da quantidade dos pecados anteriormente perdoados. Pode dar-se porém que, em relação ao
mesmo benefício, um seja muito ingrato ou pela importância do benefício desprezado, ou pela
gravidade da culpa cometida contra o benfeitor; ao passo que outro o se a pouco, ou por ter desprezado
menos, ou por ter agido menos contra o benfeitor. Mas, proporcionalmente, a quantidade da ingratidão
se mude pela quantidade do beneficio; suposto, pois um desprezo igual do benefício, ou igual a ofensa
ao benfeitor, tanto mais grave será a ingratidão quanto maior for o benefício. — Por onde é manifesto,
que não é de necessidade que, por causa da ingratidão, sempre o pecado subseqüente cause um tão
grande reato da pena quanto o era o dos pecados procedentes. Mas o é, que proporcionalmente,
quanto mais e maiores foram os pecados perdoados, tanto maior volta o reato causado por qualquer
pecado mortal subseqüente à penitência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O benefício da remissão da culpa tira a sua quantidade
absoluta da quantidade dos pecados antes perdoados. Mas a extensão da ingratidão não recebe a sua
quantidade absoluta da quantidade do benefício, senão da grandeza do desprezo ou da ofensa, como se
disse. Por isso a objeção não colhe.

RESPOSTA À SEGUNDA. — O escravo manumisso não volta à anterior servidão por causa de qualquer
ingratidão, mas por uma ingratidão grave.

RESPOSTA À TERCEIRA. — Aquele a quem os pecados remitidos são reimputados por uma ingratidão
subsequente, responde por toda a sua divida, enquanto que o grau de culpabilidade incorrida pelos
pecados precedentes reaparece proporcionalmente, e não absolutamente, na ingratidão subseqüente,
como dissemos.

## Art. 4 — Se a ingratidão, por causa da qual o pecado subseqüente faz voltarem os pecados já perdoados, é um pecado especial.
O quarto discute-se assim. — Parece que a ingratidão, por causa da qual o pecado subseqüente faz
voltarem os pecados já perdoados é um pecado especial.

1. — Pois, a retribuição às graças referidas constitui a reciprocidade (contrapassum) exigida pela justiça,
como está claro no Filósofo. Ora, a justiça é uma virtude especial. Logo, a ingratidão é um pecado
especial.

2. Demais. — Túlio introduz a gratidão como uma virtude especial. Ora, a ingratidão se opõe à gratidão.
Logo, a ingratidão é um pecado especial.

3. Demais. — Um efeito especial procede de uma causa especial. Ora, a ingratidão produz o efeito
especial de fazer de certo modo voltarem os pecados já perdoados. Logo, a ingratidão é um pecado
especial.
Mas, em contrário. — O efeito de todos os pecados não constitui um pecado especial. Ora, qualquer
pecado mortal nos torna ingratos para com Deus como do sobredito se colhe. Logo, a ingratidão não é
um pecado especial.

SOLUÇÃO. — A ingratidão do pecador é às vezes um pecado especial; outras vezes não o é, não
passando de uma circunstância geralmente conseqüente a todo pecado mortal cometido contra, Deus.
Ora, o pecado se especifica pela intenção do pecador; por isso diz Aristóteles, quem adultera a fim de
furtar, é, antes, ladrão, que adúltero. O pecador, pois, que por desprezo de Deus e do benefício recebido
cometa um pecado, constitui este pecado uma espécie de ingratidão, e essa ingratidão do pecador é um
pecado especial. Quem tiver porém tendo a intenção de cometer um pecado, por exemplo, o homicídio
ou o adultério, dele não desiste porque implique desprezo de Deus, não será tal pecado um pecado
especial, mas entrará na espécie de outro pecado como uma circunstância. Ora, como diz Agostinho,
nem todo pecado é cometido por desprezo; e contudo por todos os pecados Deus é desprezado nos
seus preceitos. Por onde, é manifesto que a ingratidão do pecador é às vezes um pecado especial; mas
nem sempre. Donde se deduzem claras as respostas as objeções. — Pois, as primeiras concluem que a
ingratidão, em si mesma, é uma espécie de pecado. — E a última objeção conclui que a ingratidão
enquanto existente em todos os pecados, não é um pecado especial.