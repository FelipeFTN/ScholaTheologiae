# Questão 34: Da perfeição do filho concebido
Em seguida devemos tratar da concepção do filho concebido.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se Cristo foi santificado no primeiro instante da sua concepção.
O primeiro discute-se assim. — Parece que Cristo não foi santificado no primeiro instante da sua
concepção.

1. — Pois, diz o Apóstolo: Não primeiro o que é espiritual, senão o que é animal; depois o que é
espiritual. Ora, a santificação da graça pertence ao espiritual. Logo, Cristo não recebeu a graça da
santificação imediatamente, desde o princípio da sua concepção, mas depois de um certo espaço de
tempo.

2. Demais. — Nós nos santificamos é do pecado, conforme aquilo do Apóstolo: E tais haveis sido alguns,
isto é, pecadores, mas haveis sido justificados Ora. em Cristo nunca houve pecado. Logo, não devia ser
santificado pela graça.

3. Demais. — Assim como pelo Verbo de Deus todas as coisas foram feitas, assim pelo Verbo encarnado
todos os homens foram santificados, que são santificados, como diz o Apóstolo: O que santifica e os que
são santificados todos veem de um mesmo princípio. Ora, o Verbo de Deus, por quem foram feitas
todas as coisas, não foi feito, como diz Agostinho. Logo, Cristo, por quem todos são santificados, não foi
santificado.
Mas, em contrário, o Evangelho: O santo, que há de nascer de ti, será chamado Filho de Deus. E noutro
lugar: A quem o Pai santificou e enviou ao mundo.

SOLUÇÃO. — Como dissemos, a abundância da graça santificante da alma de Cristo derivou da união
mesma com c Verbo, segundo o Evangelho: Nós vimos a sua glória, como de Filho unigênito do Pai,
cheio de graça e de verdade. Pois, como já demonstramos, no primeiro instante da sua concepção o
corpo de Cristo foi animado e assumido pelo Verbo de Deus. Por onde e consequentemente, no
primeiro instante da sua concepção Cristo teve a plenitude da graça que lhe santificou o corpo e a alma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. - A ordem expressa pelo Apóstolo respeita aqueles que
progridem até chegar ao estado espiritual. Ora, no mistério da Encarnação consideramos, antes, o
descenço da divina plenitude à natureza humana, que um progresso da natureza humana, suposta
preexistente, até Deus. Por isso, o homem Cristo teve, desde o princípio, o estado espiritual do homem.

RESPOSTA À SEGUNDA. — Ser santificado é tornar-se uma coisa santa. Ora, uma coisa vem a ser, não
somente partindo de um estado contrário, mas também de um termo contrário simplesmente negativo
ou privativo; assim, o branco vem do preto e também do não branco. Ora, nós, de pecadores, tornamo-
nos santos; e assim, a nossa santificação tem no pecado a sua causa. Ora, Cristo, enquanto homem, foi
santificado, pois, nem sempre teve a santidade da graça; mas não se tornou santo, de pecador que
antes fosse, porque nunca teve pecado. Santificou-se, portanto, de não santo que era, enquanto
homem; não privativamente, como se antes, tendo sido homem, não tivesse sido santo; mas
negativamente. isto é, porque enquanto não foi homem não teve a santidade humana. Por onde, foi
simultaneamente feito homem e homem santo. Por isso disse o Anjo: O santo que há de nascer de ti.
Expondo o que, diz Gregório: Afirma-se que Jesus nascerá santo, para distinguir a sua da nossa
santidade; pois, nós, se nos tornamos santos, não nascemos santos, por estarmos sujeitos à condição de
uma natureza corruptível. Mas só aquele verdadeiramente nasceu santo, que foi concebido sem o
congresso sexual.

RESPOSTA À TERCEIRA. — De um modo o Pai produz a criação das coisas pelo Filho, e de outra toda a
Trindade, a santificação dos homens, pelo homem Cristo. Pois, o Verbo de Deus tem uma operação da
mesma virtude que a de Deus Padre; e assim. o Pai não opera pelo Filho, como por um instrumento
movido, que move. Mas, a humanidade de Cristo, é como o instrumento da divindade. no sentido
explicado antes. Por onde, a humanidade de Cristo é santificante e santificada.

## Art. 2 — Se Cristo, como homem, teve o uso do livre-arbítrio no primeiro instante da sua concepção.
O segundo discute-se assim. — Parece que Cristo, como homem, não teve o uso do livre arbítrio desde
o primeiro instante da sua concepção.

1. — Pois, antes de um ser agir ou obrar, deve existir. Ora, o uso do livre arbítrio é uma ação. Mas, como
a alma de Cristo começou a existir no primeiro instante da sua concepção, segundo do sobredito se
colhe, parece impossível que tivesse o uso do livre arbítrio no primeiro instante da sua concepção.

2. Demais. — O uso do livre arbítrio é a eleição. Ora, a eleição pressupõe a deliberação do conselho;
assim, como diz o Filósofo, a eleição é o desejo do que foi deliberado. Logo, parece impossível que no
primeiro instante da sua concepção Cristo tivesse o uso do livre arbítrio.

3. Demais. — O livre arbítrio é uma faculdade da vontade e da razão, como se estabeleceu na Primeira
Parte; e assim, o uso do livre arbítrio é o ato da vontade e da razão, ou do intelecto. Ora, o ato do
intelecto pressupõe o ato do sentido, que não pode existir sem órgãos capazes. Ora, tais órgãos nos os
tinha Cristo no primeiro instante da sua concepção. Logo, parece que Cristo não podia ter tido o uso do
livre arbítrio no primeiro instante da sua concepção.
Mas, em contrário, Agostinho diz: Logo que o Verbo desceu ao ventre da Virgem, como nada perdeu da
sua natureza, tornou-se carne e homem perfeito. Ora, o homem perfeito tem o uso do livre arbítrio.
Logo, Cristo teve o uso do livre arbítrio desde o primeiro instante da sua concepção.

SOLUÇÃO. — Como dissemos, à natureza humana assumida por Cristo, é própria a perfeição espiritual,
na qual não progrediu por tê-la perfeita desde o princípio. Ora, a perfeição última não consiste na
potência nem no hábito, mas na operação. Por isso, Aristóteles diz, que a operação é um ato segundo.
Donde devemos concluir, que Cristo, no primeiro instante da sua concepção, teve aquela operação da
alma que se pode ter num instante. Ora, tal é a operação da vontade e do intelecto, na qual consiste o
uso do livre arbítrio. Pois mais súbita e instantaneamente se desfaz a operação do intelecto e da
vontade, que a da visão corpórea. Porque inteligir, querer e sentir não são movimentos, atos do
imperfeito, que se realizam sucessivamente; mas são atos do ser já perfeito, como diz Aristóteles.
Donde devemos concluir, que Cristo, no primeiro instante da sua concepção teve o uso do livre arbítrio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Existir é por natureza anterior ao agir, mas não
temporalmente; ao mesmo tempo porém que o agente começa a ser perfeito começa a agir, se nada
lh'o impede. Assim, o fogo logo que é gerado começa a esquecer e a iluminar; mas a calefação não
termina num instante, senão num tempo sucessivo; ao passo que a iluminação se perfaz
instantaneamente. E tal modo de agir é o uso do livre arbítrio, como dissemos.

RESPOSTA À SEGUNDA. — Simultaneamente com o termo do conselho ou da deliberação pode existir a
eleição. Assim, os que precisam da deliberação do conselho, logo que este está terminado, adquirem a
certeza do que devem eleger e por isso imediatamente o fazem. Por onde é claro, que a deliberação do
conselho não é preexigida para a eleição, senão para sairmos da incerteza. Ora, Cristo, no primeiro
instante da sua concepção, assim como teve a plenitude da graça santificante, assim teve conhecimento
pleno da verdade, segundo o Evangelho: Cheio de graça e de verdade. Por onde, como quem tinha a
certeza total, podia eleger logo e instantaneamente.

RESPOSTA À TERCEIRA. — O intelecto de Cristo podia, pela sua ciência infusa, inteligir, mesmo sem se
servir dos fantasmas, como estabelecemos. Por isso podia exercer a atividade da vontade e do intelecto
separadamente da operação dos sentidos. Contudo, pode exercer a operação dos sentidos, no primeiro
instante da sua concepção, sobretudo a do sentido do tato. Por este sentido é que filho concebido já
tem sensibilidade, no ventre materno, mesmo antes de receber a alma racional, como diz Aristóteles.
Por onde, tendo Cristo no primeiro instante da sua concepção a alma racional, quando já tinha o corpo
formado e organizado, com muito maior razão podia exercer, no mesmo instante, a atividade do sentido
do tato.

## Art. 3 — Se Cristo, no primeiro instante da sua concepção, podia merecer.
O terceiro discute-se assim. — Parece que Cristo, no primeiro instante da sua concepção, não podia
merecer.

1. — Pois, o livre arbítrio tanto é principio de mérito como de demérito. Ora, o diabo, no primeiro
instante da sua criação não podia pecar, como se estabeleceu na Primeira Parte. Logo, nem a alma de
Cristo, no primeiro instante da sua criação, que foi o primeiro instante da sua concepção, podia
merecer.

2. Demais. — O que o homem tem, desde o primeiro instante da sua concepção, é lhe natural; pois, é o
termo da sua geração natural. Ora, nós não podemos merecer pelo que nos é natural, como se colige do
dito na Segunda Parte. Logo, o uso do livre arbítrio, que Cristo teve, como homem, desde o primeiro
instante da sua concepção, não era meritório.

3. Demais. — O que uma vez o merecemos já se tornou nosso de certo modo e assim, parece que não
podemos de novo merecê-la, pois, ninguém merece o que já tem. Se, pois, Cristo mereceu, no primeiro
instante da sua concepção, por consequência nada mais mereceu depois. O que é evidentemente falso.
Logo, Cristo não mereceu no primeiro instante da sua concepção.
Mas, em contrário, diz Agostinho: Cristo não tinha absolutamente nada que progredir, quanto ao mérito
da sua alma. Ora, poderia progredir no mérito, se não tivesse merecido no primeiro instante da sua
concepção.

SOLUÇÃO. — Como dissemos, Cristo no primeiro instante da sua concepção foi santificado pela graça.
Ora, há duas espécies de santificação; a dos adultos, santificados pelos seus atos próprios; e a das
crianças, santificadas, não pelo seu ato próprio de fé, mas pela fé dos pais ou da Igreja. Ora, a primeira
espécie de santificação é mais perfeita que a segunda, assim como o ato é mais perfeito que o hábito, e
o que existe por si mesmo o é mais que o existente por outro. Mas, como a santificação de Cristo foi
perfeitíssima, pois, foi santificado para ser o santificador dos outros, consequentemente foi ele
santificado pelo movimento próprio do seu livre arbítrio para Deus; e esse movimento do livre arbítrio
foi meritório. Portanto, Cristo mereceu, desde o primeiro instante da sua concepção.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O livre arbítrio não se comporta do mesmo modo em
relação ao bem e ao mal. Pois, aplica-se ao bem naturalmente e por si mesmo; mas só por deficiência e
contrariamente à sua natureza é que quer o mal. Ora, como diz o Filósofo, o oposto à natureza é
posterior ao natural; porque o oposto à natureza é um como corte feito no natural. Por onde, o livre
arbítrio da criatura pode, no primeiro instante da sua criação, buscar o bem, pelo mérito; não porém o
mal, pelo pecado, dado que a natureza seja íntegra.

RESPOSTA À SEGUNDA. — O que o homem tem no princípio da sua criação, conforme ao curso comum
da natureza, é lhe natural. Nada porém impede uma criatura de receber, no princípio da sua criação, um
benefício da graça de Deus. E deste modo a alma de Cristo, no princípio da sua criação, recebeu a graça
pela qual pudesse merecer. E, por essa razão, dessa graça, por uma certa semelhança, dizemos que foi
natural ao homem Cristo, como está claro em Agostinho.

RESPOSTA À TERCEIRA. — Nada impede uma mesma coisa pertencer a alguém por diferentes causas. E
assim, Cristo podia merecer a glória da imortalidade, que mereceu no primeiro instante da sua
concepção, também por atos e sofrimentos posteriores. Não, certo, que tivesse assim mais direitos a
essa glória, mas por lhe ter ela sido devida a vários títulos.

## Art. 4 — Se Cristo, no primeiro instante da sua concepção, gozou plenamente da visão beatífica.
O quarto discute-se assim. — Parece que Cristo, no primeiro instante da sua concepção, não gozou
plenamente da visão beatifica.

1. — Pois, o mérito precede o prêmio, assim como a culpa, a pena. Ora, Cristo no primeiro instante da
sua concepção mereceu, como se disse. Mas, como a visão beatífica é a principal recompensa do mérito,
parece que Cristo, no primeiro instante da sua concepção não gozou da visão beatífica.

2. Demais. — O Senhor diz: Importava que Cristo sofresse estas coisas e assim entrasse na sua glória.
Ora, a glória é própria dos que gozam da visão beatifica. Logo, Cristo, no primeiro instante da sua
concepção, quando ainda não tinha padecido nenhum sofrimento, não gozava da visão beatífica.

3. Demais. — O que não convém nem ao homem nem ao Anjo, parece próprio de Deus; e portanto não
convém a Cristo enquanto homem. Ora, ser sempre bem-aventurado não convém ao homem nem ao
anjo; pois, se tivessem sido criados bem-aventurados, não teriam depois pecado. Logo, Cristo, enquanto
homem, não foi bem-aventurado desde o primeiro instante da sua concepção.
Mas, em contrário, a Escritura: Bem-aventurado o que elegeste e tomaste para o teu serviço; o que,
segundo a Glosa, se refere à natureza humana de Cristo, assumida pelo Verbo no unidade da pessoa.
Ora, no primeiro instante da sua concepção a natureza humana foi assumida pelo Verbo de Deus. Logo,
no primeiro instante da sua concepção Cristo, enquanto homem, foi bem-aventurado; isto é, gozou da
visão beatifica.

SOLUÇÃO. — Como do sobredito resulta, não era conveniente que Cristo, na sua concepção, recebesse
a graça habitual somente, - sem lhe exercer os atos. Mas, recebeu a graça sem medida, como
estabelecemos. Ora, a graça de um peregrino terrestre, distante da graça do bem-aventurado, tem uma
medida menor que a deste. Por onde é manifesto, que Cristo, no primeiro instante da sua concepção,
recebeu não somente tanta graça como a tem os que vem a Deus, mas ainda maior que a de todos eles.
E como a sua graça era acompanhada do exercício dela, resulta por consequência, que gozou em ato da
visão beatífica, vendo a Deus por essência mais claramente que as outras criaturas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como dissemos, Cristo não mereceu a glória da alma,
pela qual gozava da visão beatífica; mas, a glória do corpo, que conquistou com a sua paixão.
Donde se deduz clara a RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — Cristo, por ser Deus e homem, mesmo pela sua humanidade teve algo de
superior às outras criaturas, pois, gozou da visão beatífica logo desde o principio da sua concepção.