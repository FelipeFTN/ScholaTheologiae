# Questão 2: Do modo da união do Verbo Encarnado
Em seguida devemos tratar do modo da união do Verbo encarnado. E primeiro, quanto à união mesma.
Segundo, quanto à pessoa que assumiu Terceiro, quanto à natureza assumida.
Na segunda questão discutem-se doze artigos:

## Art. 1 — Se a união do Verbo encarnado se operou numa só natureza.
O primeiro discute-se assim. — Parece que a união do Verbo se operou numa só natureza.
1 — Pois, diz Cirilo e está nas atas do Concílio Calcedonense: Não devemos entender serem duas as
naturezas, mas uma só a natureza encarnada do Deus Verbo; o que não se daria se a união não se
realizasse em a natureza. Logo, a união do Verbo encamado foi feita em a natureza.

2. Demais. — Atanásio diz: Assim como a alma racional e a carne convêm na constituição de uma
natureza humana, assim Deus e o homem convêm na constituição de qualquer uma natureza. Logo, a
união foi feita em a natureza.

3. Demais. — Duas naturezas não são denominadas uma pela outra, salvo se de algum modo se
transmuda uma na outra, Ora, a natureza, divina e a humana em Cristo se denominam uma pela outra;
assim, diz Cirilo, que a natureza divina se encarnou; e Gregório Nazianzeno diz, que a natureza humana
se deificou, como está claro em Damasceno. Logo, parece que de duas naturezas fez-se uma só
natureza,
Mas, em contrário, diz uma determinação do concílio Calcedonense: Confessamos, que agora devemos
reconhecer que o filho unigênito de Deus existe em duas naturezas, sem confusão, imutavelmente,
indivisivelmente, inseparavelmente, sem que jamais a diferença da naturezas tenha sido destruída por
causa da união — Logo, não se fez a união em a natureza.

SOLUÇÃO. — Para resolver com clareza a questão presente, devemos considerar o que é a natureza.
Ora, é mister saber-se que o nome de natureza é assim dito ou derivado de nascer. Por isso, esse nome
foi primariamente usado para significar a geração dos viventes, chamada atividade ou reprodução de
modo que natureza quer dizer quase nascitura. Em seguida o nome de natureza foi aplicado
translatamente para significar o princípio dessa geração. E como o princípio da geração, nos seres vivos,
é intrínseco, o nome de natureza, foi ulteriormente aplicado para significar qualquer princípio intrínseco
de movimento; e assim o Filósofo diz, que a natureza é o princípio do movimento, pelo que ele tem de
essencial, e não de acidental. Ora, este princípio ou é forma ou matéria. Por isso, às vezes a natureza é
chamada forma; outras vezes, porém, matéria. E como o fim da geração natural é o ser gerado, isto é, a
essência da espécie expressa pela definição, daí vem que essa essência específica também se chama
natureza. E neste sentido, Boécio define a natureza, dizendo: A natureza é a diferença específica que
informa cada coisa, isto é, que realiza a definição da espécie. Ora, é neste sentido que agora
empregamos a palavra natureza, enquanto significativa da essência, ou àquilo que a coisa é (quod quid
est) ou a quididade específica.
Ora, tomando a palavra natureza nesta acepção, é impossível que a união do Verbo encarnado se
tivesse realizado em a natureza. Pois, de três modos uma coisa pode ser constituída de duas ou várias.
De um modo, permanecendo os dois componentes íntegros e perfeitos. O que não pode dar-se senão
nos seres cuja forma é uma composição, ordem ou figura. Assim, muitas pedras acumuladas sem
nenhuma ordem, e só pela composição, formam um monte, mas, pedras e madeiras, dispostas numa
certa ordem e mesmo reduzidas a uma certa figura, formam uma casa. E neste sentido, ensinaram
certos que a união se realizou a modo de confusão, na qual não existe ordem; ou a modo de
comensuração, que supõe a ordem. — Mas isto não pode ser. Primeiro, porque a composição, a ordem
ou a figura não são formas substanciais, mas, acidentais, e então daí resultaria que a união da
Encarnação não seria substancial, mas acidental, o que mais adiante será refutado. Segundo, porque
uma tal união não o é, absolutamente falando, mas, de certo modo, pois, permanece a pluralidade
atual. Terceiro, porque a forma de tais elementos não é natural, mas antes artificial, como a forma de
uma casa; e então não existiria uma só natureza em Cristo, como eles querem.
De outro modo, um ser é formado de elementos perfeitos, mas transformados; assim, dos elementos se
forma o misto. E neste sentido ensinaram outros que a união da Encarnação se realiza por. modo de
complexão. — O que não pode ser. Primeiro, porque a natureza divina é absolutamente imutável, como
na Primeira Parte se demonstrou (q. 9, a. 1, 2). Portanto, nem ela pode se converter em outro ser, como
incorruptível; nem outro, nela, pois é ingerável. Segundo, porque o resultante de uma mixão a nenhum
outro misto é idêntico especificamente; assim, a carne difere de qualquer das espécies dos elementos; e
então, Cristo não seria da mesma natureza que o Pai nem que a mãe. Terceiro, de seres muito
desproporcionados pode resultar nenhuma mixão, porque um faz desaparecer a espécie do outro, como
se puséssemos uma gota de água numa ânfora de vinho. E então, como a natureza divina excede
infinitamente a humana, não poderia haver misto, mas permaneceria só a natureza divina.
De terceiro modo, um ser é formado de elementos não transformados, mas imperfeitos; assim da alma
e do corpo se faz o homem e, semelhantemente, dos diversos membros. — Mas, isto não pode dizer-se,
do mistério da Encarnação. Primeiro, porque ambas as naturezas, a divina e a humana, são por essência
perfeita. Segundo, porque a natureza divina e a humana não podem constituir um todo a modo de
partes quantitativas, como os membros constituem o corpo, porque a natureza divina é incorpórea.
Nem a modo de forma e de matéria, porque não pode a natureza divina ser forma de nenhum ente,
sobretudo corpóreo; pois, do contrário, se seguiria que a espécie resultante seria comunicável a muitos,
havendo então vários Cristos, Terceiro, porque Cristo não seria nem de natureza humana, nem de
divina; pois, a diferença acrescentada varia a espécie, como se dá com a unidade, nos números, segundo
diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A citação aduzida, de Cirilo, é assim exposta no Quinto
Sínodo: Quem disser ser uma só a natureza encarnada do Verbo de Deus, e não o entender no sentido
em que o ensinaram os Padres, que, um só Cristo foi feito pela união, por subsistência, das naturezas
divina e humana; mas pretender introduzir a doutrina de uma só natureza ou substância da divindade e
da carne de Cristo, esse tal seja anátema. Logo, o sentido não é que, na Encarnação de duas naturezas
constituiu-se uma só, mas que uma só natureza do Verbo de Deus se uniu a si a carne, pessoalmente.

RESPOSTA À SEGUNDA. — Em cada um de nós, a união da alma e do corpo constitui dupla unidade, da
natureza e da pessoa. Da natureza, como a de uma alma que, unida ao corpo, normalmente o
aperfeiçoa, de modo a fazer de duas uma só natureza, como do ato e da potência ou da matéria e da
forma. E, por aí, não há semelhança, porque não pode a natureza divina ser forma de nenhum corpo,
como provamos na Primeira Parte (q. 3, a. 8). Mas, a unidade da pessoa é constituída da alma e do
corpo, por haver um só ser subsistente em carne e alma. E, então, há semelhança, pois, um só Cristo
subsiste em as naturezas, divina e humana.

RESPOSTA À TERCEIRA. — Como diz Damasceno, dizemos encarnada a natureza divina, por estar unida
pessoalmente à carne; não por ter-se convertido em a natureza da carne. Semelhantemente, também a
carne consideramos deificada, como o mesmo Damasceno o diz, não por conversão, mas por união com
o Verbo, salvas as suas propriedades, de modo que se entenda ser a carne deificada, por ter-se tornado
a carne do Verbo de Deus e não por ter-se tornado Deus.

## Art. 2 — Se a união do Verbo encarnado se fez na Pessoa.
O segundo discute-se assim — Parece que a união do Verbo encarnado não se fez na pessoa.

1. — Pois, a Pessoa de Deus não difere da sua natureza, como se demonstrou na Primeira Parte. Se,
portanto, não se fez a união em a natureza, segue-se que também não se fez na pessoa.

2. Demais. — A natureza humana não teve menor dignidade em Cristo do que a tem em nós. Ora, a
personalidade respeita à dignidade, como se demonstrou na Primeira Parte. Por onde, tendo a natureza
humana em nós uma personalidade própria, com maior razão teve uma personalidade própria em
Cristo.

3. Demais. — Como diz Boécio, a pessoa é uma substância individual de natureza racional. Ora, o Verbo
de Deus assumiu a natureza humana individual, pois a natureza universal não subsiste em si mesma,
mas é considerada pela só contemplação, como diz Damasceno. Logo, a natureza humana tem a sua
personalidade. Portanto, parece que não se fez a união na Pessoa.
Mas, em contrário, lê-se no Sínodo Calcedonense: Nós confessamos que Nosso Senhor Jesus Cristo é o
Deus Verbo, um e mesmo Filho unigênito, não repartido ou dividido em duas pessoas. Logo fez-se a
união do Verbo na Pessoa.

SOLUÇÃO. — Pessoa tem uma significação diferente de natureza. Pois, a natureza significa a essência
específica, expressa pela definição. E se a essência específica não fosse susceptível de nenhum
acréscimo, nenhuma necessidade haveria de distinguir a natureza, do seu suposto, que é o indivíduo
nela subsistente; pois, então, todo indivíduo subsistente numa natureza seria absolutamente idêntico a
esta. Mas, há certas coisas subsistentes, susceptíveis do que não se inclui em a essência específica,
como os acidentes e os princípios individuantes; como sobretudo o manifestam os seres compostos de
matéria e forma. Donde o diferir, mesmo realmente, em tais seres, a natureza, do suposto; não como
coisas absolutamente separadas mas porque o suposto inclui a natureza mesma da espécie, e se lhe
fazem certos outros acréscimos, estranhos à essência específica. Por isso, o suposto é significado como
um todo, tendo a natureza como a sua parte formal e perfectiva. E por isso, nos compostos de matéria e
forma, a natureza não é predicada do suposto; assim, não dizemos que tal homem é a sua humanidade.
Mas um ser como Deus em que absolutamente nada houver, além da essência da espécie ou da sua
natureza, em tal ser não há diferença real entre o suposto e a natureza, mas somente lógica. Pois,
natureza se chama ao que é uma certa essência; e ela mesma também se chama suposto, enquanto é
subsistente. E o que se disse do suposto devemos entender da pessoa, na criatura racional ou
intelectual; pois, a pessoa nada mais é do que a substância individual de natureza racional, segundo
Boécio.
Portanto, tudo o que existe numa determinada pessoa, quer lhe pertença à natureza, quer não, está lhe
unido na pessoa. Se, pois, a natureza humana não esta unida à Pessoa do Verbo de Deus, de nenhum
modo lhe está unida. - E então, desaparece totalmente a fé na Encarnação, o que é fazer em ruínas toda
a fé cristã. Como, pois, o Verbo tem a natureza humana unida a si, e não como pertinente à sua
natureza divina, é consequente que a união foi feita na Pessoa do Verbo, e não, na natureza.

DONDE A RESPOSTA À OBJEÇÃO. — Embora em Deus não difira realmente a natureza da pessoa, difere
contudo pelo modo de significar, como se disse; porque a pessoa significa uma subsistência. E como a
natureza humana está assim unida ao Verbo, que o Verbo nela subsista, e não que algo se lhe
acrescente à essência da sua natureza, ou que a sua natureza se transforme em outra, por isso a união
foi feita na Pessoa e não em a natureza.

RESPOSTA À SEGUNDA. — A personalidade pertence necessariamente, à dignidade e à perfeição de um
ser, na medida em que lhe é próprio à dignidade e à perfeição existir por si, o que se entende pelo nome
de pessoa. Pois, será mais digno para um ser existir num outro de maior dignidade, do que existir por si
mesmo. Por onde, a natureza humana é mais digna em Cristo, do que em nós, por isso que em nós,
quase existindo por si, tem a sua personalidade própria; ao passo que em Cristo existe na Pessoa do
Verbo. Assim, embora o ser completivo da espécie pertença à dignidade da forma, contudo o sensitivo é
mais nobre no homem, por causa da união com uma forma completiva mais nobre, do que no animal
bruto, do qual é a forma completiva.

RESPOSTA À TERCEIRA. — O Verbo de Deus não assumiu a natureza humana em universal, mas na sua
indivisibilidade isto é, no indivíduo, como diz Damasceno; do contrário, a qualquer homem
necessariamente conviria ser o Verbo de Deus, como o convém a Cristo. Devemos porém saber, que não
qualquer indivíduo, no gênero da substância, mesmo em a natureza racional, tem a natureza de pessoa;
mas só o que existe por si, não, porém, o que existe num ser mais perfeito. Por onde, a mão de Sócrates,
embora seja um indeterminado indivíduo, não é contudo uma pessoa; porque não existe por si, mas,
num ser mais perfeito, isto é, no seu todo. E isto também pode ser significado quando se diz, que a
pessoa é uma substância individual; pois, não é a mão uma substância completa, mas, parte da
substância. Embora, portanto, esta natureza humana seja um determinado indivíduo no gênero da
substância, porque contudo não existe por si separadamente, mas, num ser mais perfeito, a saber, na
pessoa do Verbo de Deus, é consequente que não tenha personalidade própria. E portanto a união se
fez na Pessoa.

## Art. 3 — Se a união do Verbo encarnado se fez no suposto ou na hipóstase.
O terceiro discute-se assim. — Parece que a união do Verbo encarnado não se fez no suposto, mas, na
hipóstase.

1. — Pois, diz Agostinho: Tanto a substância divina como a humana são o Filho único de Deus; mas uma
pelo Verbo, a outra pelo homem. E Leão Papa também diz: Um destes refulge pelos milagres e o outro
sucumbe pelas injúrias. Ora, dois seres entre si diferentes diferem pelo suposto. Logo, a união do Verbo
.encarnado não se fez no suposto.

2. Demais. — A hipóstase não é senão uma substância particular, como diz Boécio. Ora, é manifesto que
em Cristo há outra substância particular além da hipóstase do Verbo, isto é, o corpo, a alma e o
composto deles. Logo, em Cristo há outra hipóstase além da hipóstase do Verbo.

3. Demais. — A hipóstase do Verbo não está contida em nenhum gênero nem espécie como resulta do
que se disse na Primeira Parte. Ora, Cristo, enquanto feito homem, está contido na espécie humana.
Pois, diz Dionísio: Encerrou-se nos termos da nossa natureza aquele que excede sobreeminente e
totalmente toda a ordem da natureza. Ora, não estaria ele contido na espécie humana se não fosse uma
determinada hipóstase dessa espécie. Logo, em Cristo há outra hipóstase além da hipóstase do Verbo. E
assim, a mesma conclusão que antes.
Mas, em contrário, diz Damasceno: Em Nosso Senhor Jesus Cristo reconhecemos duas naturezas, mas
uma só hipóstase.

SOLUÇÃO. — Certos, ignorando a relação da hipóstase com a pessoa, embora concedam que há em
Cristo uma só pessoa, ensinaram contudo ser uma a hipóstase de Deus e outra, a do homem, como se a
união fosse feita na pessoa e não na hipóstase. O que é uma doutrina errônea, por três razões.
Primeiro, porque a pessoa não acrescenta à hipóstase senão uma natureza determinada, isto é, racional,
e por isso Boécio diz, que a pessoa é uma substância individual de natureza racional. Por onde, o mesmo
é atribuir uma hipóstase própria à natureza humana de Cristo, que uma pessoa própria. E assim o
entendendo, os santos Padres, condenaram ambas essas doutrinas no Quinto Concílio celebrado em
Constantinopla. E determinaram: Quem pretender introduzir no mistério de Cristo duas substâncias ou
duas pessoas, esse seja anátema; pois, a santa Trindade não sofre nenhum acréscimo de pessoa ou de
subsistência, depois de encarnado o uno Verbo de Deus, da santa Trindade. Ora, a subsistência é
idêntica ao seu subsistente, o que é próprio da hipóstase, como está claro em Boécio.
Segundo, porque dado que a pessoa faça algum acréscimo à hipóstase, no que se possa fazer a união,
isso não seria senão uma propriedade pertinente à dignidade. E por isso certos dizem, que a pessoa é a
hipóstase distinta pela propriedade e pertinente à dignidade. Se, portanto, a união fosse feita na pessoa
e não na hipóstase, seria consequência que não se teria feito a união senão segundo uma certa
dignidade. E isto foi, com a aprovação do Sínodo Efesino, condenado por Cirilo, nestas palavras: Quem,
no Cristo uno, dividir as subsistências, depois de adunadas copulando as por uma união fundada numa
certa dignidade, autoridade ou potência, e não antes, pelo concurso fundado na adunação natural - esse
seja anátema.
Terceiro, porque tanto é hipóstase aquela a que são atribuídas as operações e as propriedades da
natureza, como aquela a que é atribuído o que concreta e essencialmente pertence à natureza. Assim,
dizemos que este homem determinado é um suposto, porque se supõe aquilo que pertence ao homem,
disso recebendo a predicação. Se, portanto houver outra hipóstase em Cristo, além da hipóstase do
Verbo, resulta que se verificará de algum outro ser, que não o Verbo, o que pertence ao homem; como,
o ter nascido de uma Virgem, o ter sofrido, sido crucificado e sepultado. Mas esta doutrina também foi
condenada, com a aprovação do Concílio Efesino. com estas palavras: Quem, às duas pessoas ou
subsistências, de que falam as Escrituras Evangélicas e Apostólicas, atribui as expressões aplicadas pelos
santos a Cristo, ou que ele a si mesmo se atribuir; e aplicar certas dessas expressões a Cristo enquanto
homem, sem se referir ao que é especialmente considerado como Verbo proveniente de Deus; e certas
outras como atribuídas a Deus, como sendo o Verbo, de Deus Padre, seja anátema.
Por onde, é claro é uma heresia já primitivamente condenada, dizer que em Cristo há duas hipóstases
ou dois supostos, ou que a união não foi feita na hipóstase ou no suposto. Donde o ler-se no mesmo
Sínodo: Quem não confessar que o Verbo, de Deus Padre, se uniu à carne, segundo a subsistência, e que
Cristo faz um mesmo ser com a sua carne, sendo ao mesmo tempo Deus e homem - seja anátema.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como uma diferença acidental causa uma
alteração no sujeito, assim, uma diferença essencial o torna outro, Pois, é manifesto que a alteração
proveniente de uma diferença acidental pode, nas causas criadas, pertencer à mesma hipóstase ou ao
mesmo suposto, porque a identidade numérica pode ser substrato de diversos acidentes; mas não é
possível nas coisas criadas, que a identidade numérica possa subsistir em diversas essências ou
naturezas Por onde, assim como as alterações numa criatura não significam diversidade de suposto, mas
só diversidade de formas acidentais; assim quando dissermos de Cristo tal causa e tal outra, isso não
implica diversidade de suposto ou de hipóstase, mas, diversidade de naturezas. Por isso diz Gregório
Nazianzeno: O Salvador subsiste em tal causa e tal outra, sem ser contudo um e outro. Digo tal causa e
tal outra, contrariamente ao que há na Trindade; pois, referindo-nos a este mistério, dizemos um e
outro, para não confundir as subsistências, e não dizemos tal causa e tal outra.

RESPOSTA À SEGUNDA. — A hipóstase significa uma substância particular, não de qualquer modo, mas
enquanto existente no seu complemento. Mas, quando entra na união de um ser mais completo, como
se dá com as mãos e os pés, já não se chama hipóstase. E semelhantemente, a natureza humana em
Cristo, embora seja uma substância particular, como porém entra na união de um ser completo, isto é,
de Cristo na sua totalidade, enquanto Deus e homem, não pode chamar-se hipóstase ou suposto; mas é
esse ser completo, para o qual concorre, que se chama hipóstase ou suposto.

RESPOSTA À TERCEIRA. — Na ordem da criação, uma coisa singular não entra no gênero ou na espécie,
em razão do que a ela lhe pertence à individuação, mas, em razão da natureza, determinada pela forma;
pois, a individuação das coisas compostas é fundada, antes, na matéria: Por onde, devemos dizer que
Cristo pertence à espécie humana, em razão da natureza assumida, e não em razão da hipóstase, em si
mesma.

## Art. 4 — Se a pessoa de Cristo é composta.
O quarto discute-se assim. — Parece que a pessoa de Cristo não é composta.

1. — Pois a pessoa de Cristo não difere da pessoa ou hipóstase do Verbo, como se demonstrou. Ora, no
Verbo não é uma coisa a pessoa e outra, a natureza, como resulta do que foi dito na Primeira Parte.
Sendo, pois, a natureza do Verbo simples, segundo se demonstrou na Primeira Parte, é impossível que a
pessoa de Cristo seja composta.

2. Demais. — Toda composição se compõe de partes. Ora, a natureza divina não pode incluir a noção de
parte, porque toda parte é, por natureza, imperfeita. Logo, é impossível a pessoa de Cristo ser composta
de duas naturezas.

3. Demais. — O que é composto de partes há de ser homogêneo com elas; assim de corpos não há de
compor-se senão o corpo. Se, pois, há em Cristo uma composição de duas naturezas, essa não será, por
consequência, pessoa, mas, natureza.E assim, a união em Cristo ter-se-á sido feita em a natureza. O que
é contra o dito antes.
Mas, em contrário, diz Damasceno: Em Nosso Senhor Jesus Cristo conhecemos duas naturezas mas, uma
só hipóstase, composta de ambas.

SOLUÇÃO. — A pessoa ou a hipóstase de Cristo pode ser considerada a dupla luz. — Primeiro, quanto ao
que essencialmente é. E então, é absolutamente simples, como o é a natureza do Verbo. — De outro
modo, segundo a essência da pessoa ou da hipóstase, à qual é próprio subsistir em alguma natureza. E,
então, a pessoa de Cristo subsiste em duas naturezas. Por onde embora seja um só ser subsistente tem
contudo vários fundamentos o seu subsistir. E assim, a pessoa é chamada composta, enquanto subsiste
em duas coisas distintas·
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Essa composição da pessoa, de naturezas, não se diz que é em razão de
partes; mas antes, em razão de número, como tudo aquilo, em que duas coisas convêm, pode ser
considerado composto delas.

RESPOSTA À TERCEIRA. — Não em toda composição verifica-se que o composto é homogêneo com os
componentes, mas só quando se trata de partes do contínuo; pois, o contínuo não se compõe senão de
contínuos. Mas, o animal se compõe de alma e de corpo, não sendo nenhum deles o animal.

## Art. 5 — Se em Cristo houve união de alma e de corpo.
O quinto discute-se assim — Parece que em Cristo não houve união de alma e de corpo.

1. — Pois, a união da nossa alma como o nosso corpo causa a pessoa ou a hipóstase do homem. Se pois,
em Cristo, a alma estava unida ao corpo, resulta que constitui-se alguma hipóstase, da união de ambos.
Ora, não a hipóstase do Verbo de Deus, que é eterna. Logo, haverá em Cristo alguma pessoa ou
hipóstase, além da hipóstase do Verbo. O que vai contra o dito antes.

2. Demais. — Da união da alma e do corpo constitui-se a natureza da espécie humana. Ora, Damasceno
diz, que em Nosso Senhor Jesus Cristo não podemos admitir unia espécie comum, Logo, nele não houve
composição de alma e de corpo.

3. Demais. — A alma não se une ao corpo senão para vivificá-lo. Ora, o corpo de Cristo por dia ser
vivificado pelo Verbo mesmo de Deus. fonte e princípio da vida. Logo, em Cristo não houve união da
alma e do corpo.
Mas, em contrário; o corpo não se chama animado senão pela sua união com a alma. Ora, dizemos que
o corpo de Cristo é animado, segundo o canta a Igreja: Assumindo um corpo animado, dignou-se nascer
de uma Virgem. Logo, em Cristo houve união da alma e do corpo.

SOLUÇÃO. — Cristo é chamado homem univocamente com os outros homens, como sendo da mesma
espécie que eles, segundo aquilo do Apóstolo: Fazendo-se semelhante aos homens. Ora, é da essência
da espécie humana que a alma seja unida ao corpo; pois. a forma não especifica senão por ser o ato da
matéria, sendo este o termo da geração, pelo qual a natureza tende a realizar a espécie. Por onde, é
necessário admitir-se que em Cristo a alma estava unida ao corpo; sendo o contrário herético porque
contraria a verdade da humanidade de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Foram levados por essa razão os que negaram a união
da alma como o corpo, em Cristo, para não serem, assim, obrigados a admitir uma nova pessoa ou
hipóstase em Cristo, pois, viam que no homem puro e simples a união da alma e do corpo constitui a
pessoa. Mas isto se dá no homem, que pura e simplesmente o é, porque a alma e o corpo nele estão
unidos de modo a existirem por si. Mas em Cristo está um unido à outra corno adjuntos a um mais
principal subsistente em a natureza deles composta. E por isso, a união da alma e do corpo, em Cristo
não constitui nova hipóstase ou pessoa; mas, esse conjunto advém à pessoa ou hipóstase preexistente. -
Mas nem por isso daí se segue seja de menor eficácia a união da alma e do corpo em Cristo, do que em
nós. Pois, em si mesma a união com o que é mais nobre não destrói a virtude ou a dignidade, mas as
aumenta. Assim, a alma sensitiva, nos animais, constitui uma espécie, porque é considerada como
forma última; não porém nos homens, embora em nós ela seja de maior poder e mais nobre, por causa
da adjunção da ulterior e mais nobre perfeição da alma racional, como dissemos acima.

RESPOSTA À SEGUNDA. — As palavras de Damasceno podem entender-se em duplo sentido. — Num,
como referentes à natureza humana. A qual não tem a essência de espécie comum, segundo existe num
só indivíduo; mas enquanto abstrata de todos os indivíduos, quando objeto de uma pura contemplação
do espírito; ou enquanto existente em todos os indivíduos. Ora, o Filho de Deus não assumiu a natureza
humana, enquanto objeto da pura contemplação do intelecto, porque, assim, não teria assumido a
natureza humana em a sua realidade. A menos que se não dissesse que a natureza humana é uma das
ideias separadas, como os Platônicos concebiam o homem sem a matéria. Mas então o Filho de Deus
não teria assumido a carne, contra as palavras do Evangelho; Um espírito não tem carne nem ossos,
como vós vedes que eu tenho. Semelhantemente, também não se pode dizer que o Filho de Deus
assumiu a natureza humana como ela existe em todos os indivíduos de uma mesma espécie, porque
então teria assumido todos os homens. Resta, pois, como Damasceno diz em seguida, no mesmo livro,
que assumiu a natureza humana em a sua indivisibilidade (in átomo), isto é, na sua individualidade, mas
não em outro indivíduo — que seja o suposto ou a hipóstase da referida natureza — diferente da pessoa
do Filho de Deus. — Noutro sentido pode entender-se o dito de Damasceno, não como referente à
natureza humana, de modo que da união da alma e do corpo não resulte uma natureza comum, que é a
humana; mas deve referir-se à união das duas naturezas — a divina e a humana — das quais não resulta
nenhuma terceira composição, que seria uma determinada natureza comum, porque então esse
terceiro composto seria naturalmente predicado de muitos indivíduos. E tal é o que Damasceno
pretende dizer, sendo por isso que acrescenta; Pois, nunca foi gerado, nem nunca o será, outro Cristo,
ao mesmo tempo sujeito da divindade e da humanidade, na divindade e na humanidade, Deus perfeito
e simultaneamente homem perfeito.

RESPOSTA À TERCEIRA. — Duplo é o princípio da vida corporal. — Um, efetivo. E, deste modo, o Verbo
de Deus é o princípio de toda vida. De outro modo, um princípio de vida o é normalmente. Pois, sendo a
vida a essência dos viventes, como diz o Filósofo, assim como cada ser é formalmente o que é pela sua
forma, assim o corpo vive pela alma. E, deste modo, não é possível o corpo viver pelo Verbo, que não
pode ser forma do corpo.

## Art. 6 — Se a natureza humana se uniu ao Verbo de Deus acidentalmente.
O sexto discute-se assim. — Parece que a natureza humana se uniu ao Verbo de Deus acidentalmente.

1. — Pois, diz o Apóstolo, do Filho de Deus, que foi reconhecido no hábito isto é, na condição como
homem. Ora, o hábito se acrescenta acidentalmente ao seu sujeito, quer consideremos o hábito como
um dos dez predicamentos, quer como espécie de qualidade. Logo, a natureza humana se uniu
acidentalmente ao Filho de Deus.

2. Demais. — Tudo o que se acrescenta a um ser completo, acidentalmente se lhe acrescenta; pois,
chamamos acidente ao que pode existir ou não num sujeito sem que este por isso se corrompa. Ora, a
natureza humana se acrescenta temporalmente ao Filho de Deus, cujo ser é abeter no perfeito. Logo,
acidentalmente se lhe acrescenta.

3. Demais. — Tudo o que não pertence à natureza ou à essência de um ser lhe é acidente; porque tudo
o que existe é substância ou acidente. Ora, a natureza humana não pertence à essência ou à natureza
divina do Filho de Deus, porque não foi feita a união em a natureza, como se disse. Logo, à natureza
humana necessariamente o Filho de Deus se uniu por acidente.

4. Demais. — O instrumento se une acidentalmente ao agente. Ora, a natureza humana em Cristo foi
instrumento da divindade; pois, como diz Damasceno, a carne de Cristo foi o instrumento da sua
divindade. Logo, parece que a natureza humana se uniu ao Filho de Deus acidentalmente.
Mas, em contrário, o que é predicado acidentalmente não predica a quididade, mas a quantidade ou a
qualidade ou a existência modal. Se, pois, à natureza humana se uniu Cristo acidentalmente, quando se
dissesse Cristo é homem, não se predicaria uma unidade, mas uma qualidade, uma quantidade ou uma
existência modal. O que é contra uma decretal de Alexandre Papa, que diz: Sendo Cristo Deus perfeito e
homem. perfeito, qual não é a temeridade de certos que ousam dizer que Cristo não tem nenhuma
quididade, enquanto homem?

SOLUÇÃO. — Para responder com clareza à questão proposta, devemos saber que, sobre o mistério da
união das duas naturezas em Cristo, apareceram duas heresias — Uma, a dos que confundem as
naturezas; tal a de Eutíquio e de Diáscoro, ensinando que das duas naturezas se constituiu uma só
natureza. E assim confessavam que Cristo tem duas naturezas, quase distintas antes da união; mas não
existia em duas naturezas, quase cessada a distinção depois da união das naturezas. — Outra foi a
heresia de Nestório e de Teodoro de Mopsueste, que separavam as pessoas. Assim, ensinavam ser uma
a pessoa do Filho de Deus e outra, a do filho do homem, e essas as consideravam como entre si unidas,
primeiro, segundo a habitação de uma na outra, isto é, enquanto o Verbo de Deus habitava nesse
homem como templo. Segundo, quando à unidade de desejo isto é, enquanto a vontade do referido
homem é sempre conforme à vontade do Verbo de Deus. Terceiro, pela operação, isto é, enquanto
diziam ser esse homem o instrumento do Verbo de Deus. Quarto, pela dignidade do honra, enquanto
toda honra prestada ao Filho de Deus o é ao mesmo tempo ao filho do homem, por causa da sua união
com o Filho de Deus. Quinto, pela equivocação, isto é, pela comunicação dos nomes isto é, enquanto
dizemos que esse homem é Deus e Filho de Deus. Ora, como é manifesto, todos esses modos importam
numa união acidental.
Porém, certos mestres posteriores, pensando evitar essas heresias, nelas incidiram por ignorância. —
Assim, uns deles concediam a unidade da pessoa de Cristo, mas admitiam duas hipóstases ou dois
supostos, dizendo que o Verbo de Deus assumiu um homem composto de corpo e alma desde o
princípio da sua concepção. E esta é a primeira opinião enumerada pelo Mestre das Sentenças. —Mas
outros querendo salvar a unidade da pessoa, ensinavam que a alma de Cristo não estava unida ao
corpo, mas que ambos separados um do outro, estavam unidos ao Verbo acidentalmente, de modo que
assim não aumentava o número das pessoas, E esta é a terceira opinião enumerada no mesmo lugar
pelo Mestre das Sentenças.
Ora, ambas estas opiniões incidem na heresia de Nestório. —A primeira, porque o mesmo é atribuir
duas hipóstases ou dois supostos a Cristo e lhe atribuir duas pessoas, como dissemos acima. E se se
apoiarem na expressão — pessoa — devemos notar que também Nestório admitia a anidade de pessoa
por causa da unidade da dignidade da honra. Por isso o Quinto Sínodo determinou como anátema quem
disse ser uma só pessoa pela dignidade, pela honra e pela do ração, como, na sua insânia, escreveu
Teodoro juntamente com Nestário. —Quanto à outra opinião, ela incide no erro de Nestório quanto à
admissão da união acidental. Pois, não há diferença entre dizer que o Verbo de Deus se unia a Cristo
homem, por habitar neste como num templo, segundo ensinava Nestório, e dizer que o Verbo se uniu
ao homem por se ter dele revestido como de uma roupagem, como o ensina a terceira opinião. A qual
professa mesmo uma doutrina pior que a de Nestório, a saber, que a alma e o corpo não estão unidos.
Mas a fé católica, tomando uma posição média entre as referidas, não diz que a união de Deus e do
homem foi feita segundo a essência ou a natureza, nem de modo acidental; mas, de um modo médio,
segundo a subsistência ou a hipóstase. Por isso lemos no Quinto Sínodo: Sendo a unidade susceptível de
muitas acepções, os sequazes da impiedade de Apolinário e de Eutiquio, operando a destruição de
coisas que estavam unidas, isto é, suprimindo uma e outra natureza, concebiam a união como confusão;
ao passo que os sequazes de Teodoro e de Nestório, comprazendo-se na divisão introduzem a unidade
de afeição. Mas a santa Igreja de Deus, rejeitando a impiedade de uma e outra perfídia, confessa a união
do Verba de Deus com a carne segundo a composição, que se funda na subsistência. Por onde é claro
que a segunda das três opiniões enumeradas pelo Mestre das Sentenças, que
afirma a unidade da hipóstase de Deus e do homem, não se há de considerar opinião, mas sentença da
fé Católica. Também semelhantemente, a primeira opinião, que admite duas hipóstases; e a terceira,
que admite a união acidental, não se devem considerar opiniões, mas heresias condenadas nos concílios
pela Igreja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Damasceno, uma semelhança não implica
igualdade completa e total, pois, o que é em tudo semelhante, é igual, não é semelhante; e sobretudo
na ordem divina; assim, é impossível encontrar igualdade na Teologia, isto é, na divindade das pessoas,
e na Dispensação, isto é, no mistério da Encarnação. Por onde, a natureza humana de Cristo é
comparável a um hábito, isto é, a um vestimento, não pela união acidental, mas porque o Verbo é visível
pela natureza humana como o homem pelo seu vestimento. E também porque o vestimento se muda,
por ser feito segundo a figura de quem o veste, mas que nem por isso muda a sua forma por causa da
roupa que veste; e semelhantemente, a natureza humana assumida pelo Verbo de Deus melhorou, sem
que o Verbo de Deus se tenha mudado, como expõe Agostinho.

RESPOSTA À SEGUNDA. — O que se une a um ser completo, acidentalmente se lhe une a menos que
não seja levado à comunhão com esse ser completo. Assim, na ressurreição o corpo se une à alma
preexistente, mas não, acidentalmente, pois, é assumida numa identidade de assistência, de modo que
o corpo recebe da alma o seu ser vital. Mal, tal não se dá com a brancura, pois, uma coisa é o ser da
brancura, e outra o do homem a que se ela acrescenta. Ora, o Verbo de Deus já tinha abeterno o seu ser
completo, segundo a hipóstase ou pessoa; mas, temporalmente se uniu à natureza humana, não que
esta fosse assumida numa unidade de ser, quanto à natureza, como o corpo está unido à alma, mas,
numa unidade de ser quanto à hipóstase ou pessoa. Por onde, a natureza humana não está unida
acidentalmente ao Filho de Deus.

RESPOSTA À TERCEIRA. — O acidente se divide por contrariedade, da substância. Ora, a substância,
como diz Aristóteles, é susceptível de dupla acepção: numa, é tomada como essência ou natureza;
noutra, como suposto ou hipóstase. Por onde, basta para a união não ser acidental, que ela se faça
segundo o hipóstase, embora não se tenha feito segundo a natureza.

RESPOSTA À QUARTA. — Nem todo o assumido como instrumento pertence à hipóstase do assumente,
corno o demonstra o machado e a espada. Mas; nada impede que o assumido na unidade da hipóstase
se comporte como instrumento, como o corpo do homem ou os seus membros. Ora, Nestório ensinava
que a natureza humana foi assumida pelo Verbo, só a modo de instrumento, mas não, na unidade da
hipóstase. Por onde, não concedia que Cristo homem fosse verdadeiramente Filho de Deus, mas,
instrumento seu. Por isso ensina Cirilo: A Escritura diz que este Emanuel, isto é, Cristo, foi assumido não
para exercer a função de instrumento, mas como Deus verdadeiramente humanado, isto eito homem. -
Quanto a Damasceno, ensinou que a natureza humana em Cristo era um como instrumento pertencente
à unidade da hipóstase.

## Art. 7 — Se a união da natureza divina e humana é algo de criado.
O sétimo discute-se assim. — Parece que a união da natureza divina e humana nada é de criado.

1. — Pois, em Deus nada pode haver de criado, porque tudo o que nele existe é Deus. Ora, há união em
Deus, porque Deus mesmo está unido à natureza humana. Logo, parece que a união não é nada de
criado.

2. Demais. — Em tudo, o principal é o fim. Ora, o fim da união é a divina hipóstase ou pessoa, na qual a
união tem o seu termo, Logo, parece que tal união deve ser apreciada sobretudo pela condição da
divina hipóstase, que nada tem de criado. Logo, também não é nada de criado a união.

3. Demais. — O princípio donde uma coisa tira tal propriedade esse a possui a ela em mais alto grau,
segundo o Filosofo. Ora, o homem é dito Criador por causa da união. Logo, com maior razão, a união
mesma nada é de criado, mas, o Criador.
Mas, em contrário — Tudo o que começa temporalmente é criado. Ora, a referida união não existiu
abeterno, mas começou a existir no tempo.Logo, a união é algo de criado.

SOLUÇÃO. — A união de que falamos é uma relação considerada entre a natureza divina e a humana,
enquanto convêm na pessoa una do Filho de Deus. Ora, como dissemos na Primeira Parte, toda relação
considerada entre Deus e a criatura, está, sem dúvida, realmente na criatura, cuja mudança dá origem a
essa relação, mas não existe realmente em Deus, senão só segundo a razão, porque não nasce de
nenhuma mudança em Deus. Donde devemos concluir que a união em questão não existe em Deus
realmente, mas só segundo a razão; mas existe realmente a natureza humana, que é uma criatura. Por
onde, é necessário admitir que é algo de criado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa união em Deus não existe realmente mas só
segundo a razão; pois, dizemos que Deus está unido à criatura, porque a criatura está unida com ele,
sem mudança em Deus.

RESPOSTA À SEGUNDA. — Por sua noção, a relação, como o movimento, depende do fim ou termo;
mas a sua existência depende do sujeito. E como essa união não tem um ser real senão em a natureza
criada, segundo dissemos, há de necessariamente ter o ser criado.

RESPOSTA À TERCEIRA. — O homem é chamado e é Deus por causa da união, enquanto terminada na
hipóstase divina; mas daí se não segue que a união mesma seja Criador ou Deus; pois, quando dizemos
que um ser é criado levamos em conta, antes, a sua existência que a sua noção.

## Art. 8 — Se união e assunção se identificam.
O oitavo discute-se assim. — Parece que união e assunção se identificam.

1. — Pois, as relações, como os movimentos, se especificam pelo termo. Ora, os termos da assunção e
da união são idênticos, isto é, são a divina hipóstase. Logo, parece que não diferem a união e a
assunção.

2. Demais. — Parece que no mistério da Encarnação se identificam o que une e o que assume, o unido e
o assumido. Ora, a união e a assunção resulta da ação e da paixão do que une e do unido, do que
assume e do assumido. Logo, parece se identificarem a união e a assunção.

3. Demais. — Damasceno diz: Uma coisa é a união e outra, a encarnação, Pois, a união significa só a
conjunção, mas não indica com o que é feita esta. Mas, a encarnação e a humanação determinam com o
que se faz a conjunção. Ora, semelhantemente, a assunção não determina com o que se faz a
conjunção. Logo, parecem idênticos a união e a assunção.
Mas, em contrário, dizemos que a natureza divina foi unida e não, assumida.

SOLUÇÃO. — Como dissemos, a união importa relação da natureza divina e da humana, enquanto
convêm numa mesma pessoa. Ora, toda relação com um começo temporal é causada por alguma
mudança. Ora, a mudança consiste na ação e na paixão. Donde devemos concluir, que a primeira e
principal diferença entre a assunção e a união é que a união implica a relação em si mesma, ao passo
que a assunção implica a ação que faz alguém assumir, ou a paixão que torna alguma coisa assumida. - E
desta diferença se deduz, em segundo lugar, uma. outra. Pois, a assunção significa um como vir-a-ser; ao
passo que a união exprime o que já é como feito. Por isso, considera-se o que une como o unido, mas
não dizemos ser o que assume, o assumido. Ora, a natureza humana é significada como o termo da
assunção relativamente à hipóstase divina, pelo ser chamado homem; por isso verdadeiramente
dizemos que o Filho de Deus, que se uniu a si a natureza humana, é homem. Mas; a natureza humana
em si mesmo considerada, isto é, em abstrato, é significada como assumida; assim, não dizemos que o
Filho de Deus seja a natureza humana. - E daí mesmo resulta uma terceira diferença a saber; a relação,
sobretudo a de equiparação, não se relaciona mais com um extremo do que com outro; ao passo que a
ação e a paixão se relacionam diversamente com o agente e o paciente e com os termos diversos. Por
onde, a assunção determina o termo origem (a quo) e o de chegada (ad quem); pois, a assunção
significa, em latim, quase ab alio ad se sumptio (ato de assumir outra coisa para si). Ao passo que a
união nada disso determina; por isso dizemos indiferentemente que a natureza humana está unida à
divina inversamente. Pois, não dizemos que a natureza divina foi assumida pela humana, mas ao
inverso, que a natureza humana foi adjunta à personalidade divina, isto é, de modo que a pessoa divina
subsista em a natureza humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A união e a assunção não se relacionam do mesmo
modo com o termo, mas diversamente, como dissemos.

RESPOSTA À SEGUNDA. — O que une e o que assume não são absolutamente o mesmo. Assim, toda
pessoa que assume une, mas não inversamente. Pois, a pessoa do Pai uniu a natureza humana ao Filho,
mas não a si; por isso dizemos que une, mas não que assume. E semelhantemente, não se identifica o
unido com o assumido; assim dizemos que a natureza divina é unida, mas não, assumida.

RESPOSTA À TERCEIRA. — A assunção determina com o que foi feita a conjunção por parte de quem
assumiu, pois, assunção em latim (assumptio) significa quase ad se sumptio; mas a encarnaçâo e a
humanação determinam relativamente ao assumido, que é a carne ou a natureza humana. Por onde, a
assunção difere, logicamente, da união e da encarnação ou humanação,

## Art. 9 — Se a união das duas naturezas em Cristo é a máxima das uniões.
O nono discute-se assim. — Parece que a união das duas naturezas em Cristo não é a máxima das
uniões.

1. — Pois, o unido é inferior, em razão da unidade, ao que é uno, porque o unido o é por participação, e
o uno, por essência- Ora, nas coisas criadas uma coisa é dita, absolutamente, una, como principalmente
o demonstra a unidade mesma, que é o princípio do número. Logo, a união de que falamos, não implica
a máxima unidade.

2. Demais. — Quanto mais distam as coisas unidas tanto menor é a união. Ora, a natureza divina e a
humana, unidas pela união de que tratamos, distam entre si em máximo grau, porque distam
infinitamente. Logo, tal união é mínima.

3. Demais. — Da união. resulta a unidade. Ora, da união da alma e do corpo em nós resulta a unidade da
pessoa e da natureza; ao passo que da união da natureza divina com a humana resulta só a unidade da
pessoa. Logo, maior é a união da alma com o corpo do que da natureza divina com a humana; e assim, a
união de que agora tratamos não implica a máxima unidade.
Mas em contrário, diz Agostinho, que antes está o homem no Filho de Deus, que o Filho no Padre. Ora, o
Filho está no Padre pela unidade de essência; ao passo que o homem está no Filho pela união da
Encarnação. Logo, maior é a união da Encarnação que a unidade da divina essência. A qual porém é a
máxima das unidades. E assim, por consequência, a união da Encarnação implica a máxima unidade.

SOLUÇÃO. — A união implica a conjunção de dois seres num só ser. Por onde, a união da Encarnação
pode ser considerada a dupla luz: relativamente aos elementos unidos e relativamente ao em que se
unem. E, por este lado, a referida união tem a preeminência sobre as outras uniões ; pois, a unidade da
pessoa divina, em que se unem ias duas naturezas, é máxima. Portanto, não tem a preeminência
relativamente aos elementos unidos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A unidade da pessoa divina é maior que a unidade
numérica, isto é. que é o princípio do número. Pois, a unidade da pessoa divina é uma unidade por si
subsistente, não recebida em outro ser por participação. E também é em si mesma completa,
encerrando em si tudo o que compreende a noção de unidade. Por isso não lhe convém ser parte, como
à unidade numeral, que é parte do número e é participada pelas coisas numeradas. E assim, a este
respeito, a união da Encarnação tem preeminência sobre a unidade numeral, isto é, em razão da
unidade de pessoa. Não porém em razão da natureza humana, que não é a unidade mesma da divina
pessoa, mas a esta está unida.

RESPOSTA À SEGUNDA. — A objeção colhe quanto aos elementos conjuntos; não, quanto à pessoa em
que se fez a união.

RESPOSTA À TERCEIRA. — A unidade da pessoa divina é uma unidade maior que a da pessoa e da
natureza, em nós. Por isso, a união da Encarnação é maior que a da alma e do corpo em nós. Quanto a
objeção em contrário, ela supõe uma falsidade, a saber, que maior é a união da Encarnação que a
unidade das pessoas divinas, na essência. E então devemos responder, quanto à autoridade de
Agostinho, que a natureza humana não existe, mais, no Filho de Deus, que o Filho de Deus, no Padre,
mas, muito menos. Mas, o homem mesmo está, de certo modo, mais no Filho, que o Filho no Pai; isto é,
quando digo — homem, tomando-o por Cristo, e quando digo — Filho de Deus, o suposto é o mesmo;
mas não é o mesmo o suposto do Pai e do Filho.

## Art. 10 — Se a união da Encarnação se fez pela graça.
O décimo discute se assim. — Parece que a união da Encarnação não se fez pela graça.

1. — Pois, a graça é um acidente, como se demonstrou na Segunda Parte. Ora, a união da natureza
humana com a divina não é uma união acidental, como se demonstrou. Logo, parece que a união da
Encarnação não se fez pela graça.

2. Demais. — O sujeito da graça é a alma. Ora, como diz o Apóstolo, em Cristo habita toda a plenitude
da divindade corporalmente. Logo, parece que essa união não se fez pela graça.

3. Demais. — Todo santo está unido a Deus pela graça. Se, pois, a união da Encarnação se fez pela graça,
parece que Cristo não é chamado Deus, diferentemente dos outros varões santos.
Mas, em contrário, diz Agostinho: Todo o homem se torna Cristão desde o início da sua fé, por aquela
graça pela qual esse homem desde o princípio fez-se Cristo. Ora, este homem se fez Cristo pela união
com a natureza divina. Logo, tal união se realizou pela graça.

SOLUÇÃO. — Como dissemos na Segunda Parte, a graça pode ser considerada a dupla luz: A uma, é a
vontade mesma de Deus, que faz um dom gratuito; a outra, é esse dom gratuito mesmo de Deus. Ora, a
natureza humana precisa da gratuita vontade de Deus para elevar-se até ele, pois, tal lhe sobrepuja a
faculdade da natureza. Ora, a natureza humana se eleva a Deus de dois modos: pela operação, pela qual
os santos conhecem e amam a Deus; e pelo ser pessoal, modo que é o singular, de Cristo, em quem a
natureza humana foi assumida para que fosse da pessoa do Filho de Deus. Ora, é manifesto que para a
perfeição de uma operação, é necessário seja a potência aperfeiçoada pelo hábito; mas, que a natureza
tenha o ser no seu suposto, isso não se realiza mediante nenhum hábito.
Donde devemos concluir, que se consideramos como graça a vontade mesma de Deus, que faz um dom
gratuito, ou que tem alguém como grato ou aceito, nesse caso a união da Encarnação se fez pela graça,
assim como a união dos santos com Deus, pelo conhecimento e pelo amor. Mas, se considerarmos como
graça o dom mesmo gratuito de Deus, assim, o mesmo ser a natureza humana unida à pessoa divina
pode-se considerar uma determinada graça, por tal não se ter dado em virtude de nenhuns méritos
precedentes; mas não como existindo alguma graça habitual, mediante a qual tal união se tenha feito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A graça acidental é uma certa semelhança da divindade
participada no homem. Ora, pela Encarnação não se diz que a natureza humana participa de qualquer
semelhança da natureza divina, mas que está unida à natureza divina mesma, na pessoa do Filho. Ora,
uma realidade em si mesma é superior à sua semelhança participada.

RESPOSTA À SEGUNDA. — A graça habitual só existe na alma; mas a graça, isto é, o dom gratuito de
Deus, que produz a união com a pessoa divina, pertence a toda a natureza humana, composta de alma e
corpo. E deste modo dizemos que a plenitude da divindade habitou corporalmente em Cristo, porque a
natureza divina se uniu não só à alma mas também ao corpo. Embora também se possa dizer que
quando se afirma que habitou em Cristo corporalmente, isto é, não como sombra, como habitou nos
sacramentos da lei antiga, dos quais no mesmo lugar acrescenta o Apóstolo, que são como sombra das
coisas vindouras, mas o corpo é Cristo, enquanto que o corpo se opõe à sombra. E também certos
ensinam, que quando se diz ter habitado corporalmente a divindade em Cristo, isso o foi de três modos,
como o corpo tem três dimensões. Primeiro, pela essência, pela presença e pelo poder, como nas outras
criaturas; segundo, pela graça santificante, como nos santos; terceiro, pela união pessoal, que é a
própria de Cristo.
Donde se deduz clara a RESPOSTA À TERCEIRA OBJEÇÃO. — isto é, porque a união da Encarnação não
se fez pela só graça habitual, como nos outros santos que estão unidos a Deus; mas, pela subsistência
ou pessoa.

## Art. 11 — Se à união da Encarnação precederam alguns méritos.
O undécimo discute-se assim. — Parece que certos méritos precederam à união da Encarnação.

1. — Pois, àquilo da Escritura — Faça-se sobre nós a tua misericórdia da maneira que em ti temos
esperado — diz a Glosa: Isto ensina o desejo que o profeta tinha da Encarnação e merecia que ela se
realizasse. Logo, a Encarnação pode ser merecida.

2. Demais. — Quem merece alguma coisa merece aquilo sem o que essa coisa não pode ser obtida. Ora,
os antigos Padres mereciam a vida eterna à qual não podiam chegar senão pela Encarnação. Assim, diz
Gregório: Os que. vieram a este mundo antes do advento de Cristo, por maior que tivessem a virtude da
justiça, de nenhum modo podiam, separados do corpo, ser logo introduzidos no seio da pátria celeste;
porque. ainda não tinha vindo aquele que haveria de introduzir na sua perpétua morada as almas dos
justos. Logo, parece que mereceram a Encarnação.

3. Demais. — Da B. V. Maria se canta que mereceu trazer o Senhor de todas as causas, o que se deu pela
Encarnação. Logo, a Encarnação é susceptível de ser merecida.
Mas, em contrário, diz Agostinho: Aquele que descobrir em o nosso chefe os méritos precedentes da sua
singular geração, descubra também em nós, seus membros, os méritos precedentes da multiplicada
regeneração. Ora, nenhuns méritos precederam a nossa regeneração, como o diz o Apóstolo : Não por
obras de justiça que. tivéssemos feito nós outros mas segundo a sua misericórdia nos salvou pelo
batismo de regeneração. Logo, nem a geração de Cristo foi precedida de quaisquer méritos.

SOLUÇÃO. — Em relação a Cristo mesmo, é manifesto, pelo que já dissemos, que nenhuns méritos seus
lhe puderam preceder à união. Pois, não admitimos que antes tivesse sido um puro homem e depois,
pelo mérito de uma boa vida, tivesse obtido ser Filho de Deus, como o ensinou Fotino. Mas, dizemos
que desde o princípio da sua concepção esse homem foi verdadeiramente Filho de Deus, como não
tendo nenhuma outra hipóstase senão a de Filho de Deus, segundo aquilo do Evangelho: O Santo que há
de nascer de ti será chamado Filho de Deus. Por onde, todas as obras desse homem se lhe seguiram à
união. E portanto, nenhuma obra sua podia ter merecido a união.
Mas nem também as obras de qualquer outro homem podiam ter sido meritórias dessa união, por um
mérito de condignidade (ex condigno). Primeiro, porque as obras meritórias do homem se ordenam
propriamente à beatitude, que o é prêmio da virtude e consiste no pleno gozo de Deus. Ora, a união da
Encarnação, realizada no ser pessoal, transcende a união da alma bem-aventurada, com Deus, que
supõe da parte dela um ato de fruição. E por isso não é susceptível de mérito. — Segundo, porque a
graça não é susceptível de mérito, pois é o princípio do merecer. Por onde, com maior razão, não pode a
Encarnação ser merecida, ela que é o princípio da graça, segundo o Evangelho: A graça e a verdade foi
traz ida por Jesus Cristo. — Terceiro, porque a Encarnação de Cristo é reformadora de toda a natureza
humana. E portanto, não pode ser merecida pelo mérito de nenhum homem particular: porque o bem
de qualquer puro homem não pode ser a causa do bem de toda a natureza.
Contudo, por congruência (ex congruo) mereceram os Santos Padres a Encarnação, desejando e
pedindo. Pois, era congruente que Deus os ouvi-se a eles que lhe obedeciam. Donde se deduz clara ares
posta à primeira objeção.

RESPOSTA À SEGUNDA. — É falso dizer que o mérito compreende tudo àquilo sem o que o prêmio não
pode ser conseguido. Pois, certas coisas não somente são necessárias para o prêmio, mas as preexige o
mérito; assim, a bondade divina, e a natureza mesma do homem. E semelhantemente, o mistério da
Encarnação é o princípio do mérito, pois, todos nós participamos da plenitude de Cristo, como diz o
Evangelho.

RESPOSTA À TERCEIRA. — Dizemos que a Bem-aventurada Virgem mereceu trazer o Senhor de todas as
coisas não por ter merecido que ele se encarnasse, mas por ter merecido, pela graça que lhe foi dada,
um tal grau de pureza e de santidade. que pudesse congruamente ser a mãe de Deus.

## Art. 12 — Se a graça da união era natural ao homem Cristo.
O duodécimo discute-se a graça da união não era natural ao homem Cristo.

1. — Pois, a união da Encarnação não se fez em a natureza, mas na pessoa, como se disse. Ora, um
movimento se designa pelo seu termo. Logo, essa graça deve ser considerada, antes, pessoal que
natural.

2. Demais. — A graça se divide da natureza por oposição, assim como o que é gratuito, procedente de
Deus, se distingue do natural, procedente de um princípio intrínseco. Ora, de coisas que se dividem por
oposição, uma não tira da outra a sua denominação. Logo, a graça de Cristo não lhe é natural.

3. Demais. — Chama-se natural ao que é segundo a natureza. Ora, a graça da união não é natural a
Cristo pela sua natureza divina, porque então conviria também às outras pessoas. Nem lhe é natural
pela sua natureza humana, porque então conviria a todos os homens, que são da mesma natureza que
ele. Logo, parece que de nenhum modo a Graça da união é natural a Cristo.
Mas, em contrário, Agostinho diz: Por ter assumido a natureza humana a graça mesma de algum modo
se tornou natural a esse homem, e nenhum pecado o poderia privar dela.

SOLUÇÃO. — Segundo o Filósofo, num sentido chama-se natureza a natividade mesma; noutro, a
essência de um ser. Por onde, natural pode ter dupla significação. Numa, é o resultado dos princípios
essenciais de um ser; assim, é natural ao fogo ser levado para o alto. Noutra, dizemos natural ao homem
o que ele tem pela sua natividade, segundo aquilo do Apóstolo: Éramos por natureza filhos da ira. E
noutro lugar da Escritura: A sua nação é malvada e a malícia lhes é natural. Logo, a graça de Cristo, quer
a de união, quer a habitual, não pode chamar-se natural, quase causada nele pelos princípios da
natureza humana; embora possa chamar-se natural, quase proveniente à natureza humana de Cristo,
pela causalidade da sua natureza divina. Mas dissemos que ambas essas graças são naturais a Cristo,
pelas ter desde a sua natividade; pois, desde o início da sua concepção a natureza humana esteve unida
à pessoa divina; e a sua alma tinha a plenitude do dom da graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a união não se tivesse feito em a natureza, foi
contudo causada pelo poder da natureza divina, que é verdadeiramente a natureza de Cristo. E também
convinha a Cristo desde o princípio da sua natividade.

RESPOSTA À SEGUNDA. — As expressões — graça e natural — não têm idêntico sentido. Mas, chama-se
graça ao que não provém do mérito; e natural, ao que provém da virtude da natureza divina, para a
humanidade de Cristo, desde o seu nascimento.

RESPOSTA À TERCEIRA. — A graça da união não é natural a Cristo segundo a sua natureza humana,
quase causada dos princípios dessa natureza. Por onde, não é necessário convenha a todos os homens.
Mas natural lhe é segundo a natureza humana, por causa da propriedade da sua natividade; isto é, foi
concebido do Espírito Santo de modo que fosse naturalmente Filho de Deus e do homem. Mas, segundo
a natureza divina é lhe natural, enquanto a natureza divina é o princípio ativo dessa graça. E isto convém
à toda a Trindade, isto é, ser o princípio ativo dessa graça.