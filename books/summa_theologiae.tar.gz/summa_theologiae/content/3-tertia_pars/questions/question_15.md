# Questão 15: Das fraquezas atinentes à alma que Cristo assumiu com a natureza humana.
Em seguida devemos tratar das misérias atinentes à alma.
E nesta questão discutem-se dez artigos:

## Art. 1 — Se em Cristo houve pecado.
O primeiro, discute-se assim. -- Parece que em Cristo houve pecado.

1. — Pois, diz a Escritura: Deus, Deus meu, meu, porque me desamparaste? Os clamores de meus
pecados são causa de estar longe de mim a salvação. Ora, as palavras foram ditas. da pessoa mesma de
Cristo, como o mostram as que ele proferiu na cruz. Logo, parece que Cristo cometeu pecados.

2. Demais. — O Apóstolo diz que em Adão todos pecaram, porque nele estavam originalmente. Ora,
Cristo também. estava originalmente em Adão. Logo, nele pecou.

3. Demais. — O Apostolo diz: À vista de tudo quanto ele padeceu e em que foi tentado, é poderoso para
ajudar também aqueles que são tentados. Ora, nós precisávamos do, seu auxílio sobretudo contra o
pecado. Logo, pareceu que nele houve pecado.

4. Demais. — O Apóstolo diz que Deus aquele que não havia conhecido pecado, isto é, Cristo, o fez
pecado por nós. Ora, verdadeiramente é aquilo que Deus faz. Logo, em Cristo houve verdadeiramente
pecado.

5. Demais. — Como diz Agostinho, no homem Cristo o Filho de Deus se deu a nós como um exemplo
para a vida. Ora, o homem precisa de exemplo não só para viver retamente, mas também para fazer
penitência dos pecados, Logo, parece que em Cristo devia haver pecado para que, fazendo penitência
deles, nos desse o exemplo da penitência.
Mas, em contrário, o Evangelho: Qual de Vós me arguirá de pecado?

SOLUÇÃO. — Como dissemos, Cristo assumiu os nossos defeitos para que satisfizesse por nós e
comprovasse a verdade da natureza humana e nos desse exemplo de virtude. E por essas três razões é
manifesto que não devia assumir a miséria do pecado. - Primeiro, porque, o pecado em nada concorre
para a satisfação; antes, impede a virtude da satisfação; pois, como diz a Escritura, o Altíssimo não
aprova os dons dos iníquos. - Semelhantemente, também pelo pecado não se mostra a verdade da
natureza humana, pois ele não pertence à natureza humana de que Deus é causa; antes, é .contra a
natureza, introduzido pelo contágio do diabo, como diz Damasceno. - Terceiro, porque, pecando, não
podia dar exemplo de virtude, pois, o pecado contraria. a virtude. Por isso Cristo de nenhum modo
assumiu a miséria do pecado, nem do original nem do atual, segundo aquilo da Escritura: O que não
cometeu pecado nem foi achado engano na sua boca.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Damasceno, de dois modos podemos afirmar
alguma causa de Cristo. De um modo, referente à sua propriedade natural e hipostática, como quando
dizemos que Deus se fez homem e sofreu por nós. De outro modo, quanto à sua propriedade pessoal e
num sentido relativo, como quando dizemos alguma causa de nossa pessoa aplicando-a a ele, a qual de
nenhum modo lhe convém em si mesmo considerado. Por isso, entre as sete regras de Ticónio,
enunciadas por Agostinho, a primeira respeita, ao Senhor e ao seu corpo, pois que as pessoas de Cristo e
da Igreja consideram-se uma só pessoa. E, a esta luz, Cristo, falando das pessoas dos seus membros, diz:
Os clamores dos meus pecados; não querendo com isso significar que no próprio chefe houvesse
pecados.

RESPOSTA À SEGUNDA. — Como diz Agostinho, Cristo não existia em Adão e nos outros patriarcas
absolutamente do mesmo modo pelo qual nós nele existimos. Pois, nós existimos em Adão pelo
germem da nossa natureza e pela substância do nosso corpo porque, como ele próprio o diz no mesmo
lugar, devemos distinguir na nossa origem a substância corpórea, visível, e a razão seminal, invisível.
Mas Cristo assumiu da carne da Virgem a substância visível da sua carne; ao passo que a sua concepção
original tem uma causa muito diferente do semem viril e muito superior a ele. Por isso não existiu em
Adão pelo semem original, mas só pela substância do corpo. E portanto não recebeu ativamente de
Adão a natureza humana, mas só materialmente, pois que, ativamente a recebeu do Espírito Santo;
assim como também o próprio Adão recebeu o seu corpo, materialmente, do limo da terra, mas,
ativamente, de Deus. Por onde, Cristo não pecou em Adão, em quem só pela matéria existiu.

RESPOSTA À TERCEIRA. — Cristo, com a sua tentação e a sua paixão veio em nosso socorro,
satisfazendo por nós. Ora, o pecado não coopera para a satisfação; ao contrário; a impede, como
dissemos. Por onde, importava não que em si tivesse pecado, mas que fosse absolutamente puro dele;
do contrário, a pena que sofreu lhe teria sido devida pelo próprio pecado.

RESPOSTA À QUARTA. — Deus fez Cristo pecado, não para que tivesse em si o pecado, mas pelo ter
feito hóstia pelo pecado, como diz a Escritura: Eles comerão dos pecados do meu povo, isto é, os
sacerdotes que, segundo a lei, comiam as vítimas oferecidas pelo pecado. E, deste modo, diz a Escritura:
O Senhor carregou sobre ele a iniquidade de todos nós, pelo ter entregado como vítima pelo pecado de
todos os homens. Ou o fez pecado por ter a semelhança da carne do pecado, na expressão do Apóstolo.
E isto por causa do corpo passível e mortal que assumiu.

RESPOSTA À QUINTA. — Um penitente pode dar exemplo louvável não pelo pecado que cometeu, mas
por ter voluntariamente sofrido uma pena pelo pecado. E assim Cristo deu o exemplo máximo aos
penitentes, querendo sofrer uma pena, não por qualquer pecado próprio, mas pelo pecado dos outros.

## Art. 2 — Se em Cristo houve o atrativo do pecado.
O segundo discute-se assim. — Parece que em Cristo houve o atrativo do pecado.

1. — Pois, do mesmo princípio - privação da justiça original - deriva o atrativo do pecado e a
passibilidade do corpo ou mortalidade; e dessa justiça original é que resultava a sujeição das potências
inferiores da alma à razão e do corpo à alma. Ora, em Cristo havia a passibilidade do corpo e a
mortalidade. Logo, houve também nele o atrativo do pecado.

2. Demais. — Como diz Damasceno, pelo beneplácito da divina vontade fora permitido à carne de Cristo
sofrer e operar o que lhe era apropriado. Ora, é próprio à carne desejar o que lhe é agradável. Mas,
como o atrativo do pecado não é senão a concupiscência, na expressão do Apóstolo, parece que em
Cristo havia o atrativo do pecado.

3. Demais. — Em razão do atrativo do pecado, a carne deseja contra o espírito, como diz o Apóstolo.
Ora, tanto mais forte e mais digno da coroa se mostra o espírito, quanto mais supera o inimigo, isto é, a
concupiscência da carne, segundo o Apóstolo: Não é coroado senão quem combate conforme à lei: Ora,
Cristo tinha um espírito fortíssimo e vitoriosíssimo e digno, por excelência, da coroa, segundo a
Escritura: E lhe foi dada uma coroa e saiu vitorioso para vencer. Logo, parece que em Cristo devia haver,
em máximo grau, o atrativo do pecado.
Mas, em contrário, o Apóstolo: O que nela se gerou é obra do Espírito Santo. Ora, o Espírito Santo exclui
o pecado e a inclinação para o pecado, implicada na denominação de atrativo, Logo, em Cristo não
houve o atrativo do pecado.

SOLUÇÃO. — Como se disse, Cristo teve perfeitíssima a graça e todas as virtudes. Ora, a virtude moral,
reguladora da parte irracional, fá-la sujeita à razão e tanto mais quanto mais perfeita for tal virtude.
Assim, a temperança regula o concupiscivel; a fortaleza e a mansidão, o irascível, como dissemos na
Segunda Parte. Mas, por sua natureza, o atrativo do pecado inclina o apetite sensual ao que é contra a
razão. Por onde é claro, que quanto mais alguém for de virtude perfeita tanto mais se lhe diminuirá o
atrativo do pecado. Mas, tendo Cristo a virtude em perfeitíssimo grau, não houve nele, por
consequência, o atrativo do pecado; pois, além disso, essa fraqueza não se ordena a satisfazer mas,
antes, inclina ao que é contrário à satisfação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As virtudes inferiores, pertinentes ao apetite sensível
são naturalmente obedientes à razão; não porém as virtudes do corpo ou dos humores corpóreos ou
ainda as da alma vegetativa, como está claro em Aristóteles.· Por onde, a perfeição da virtude conforme
à razão reta não exclui a passibilidade do corpo; exclui porém o atrativo do pecado, cuja essência
consiste na resistência do apetite sensual à razão.

RESPOSTA À SEGUNDA. — A carne naturalmente deseja o que lhe é agradável, pela concupiscência do
apetite sensitivo; mas a carne do homem, que é um animal racional, deseja o que lhe agrada, ao modo e
conforme à ordem da razão. E assim, a carne de Cristo, pela concupiscência do apetite sensitivo,
desejava naturalmente a comida, a bebida, o sono e o mais que podemos desejar de acordo com a razão
reta, como está claro em Damasceno. Daí porém não se segue que em Cristo houvesse o atrativo do
pecado, que implica a concuspicência do prazer contrário à ordem da razão.

RESPOSTA À TERCEIRA. — É prova de uma certa força de espírito o resistir à concupiscência da carne
que se lhe opõe; demonstra porém maior fortaleza, o espírito que reprime totalmente o ímpeto da
carne, impedindo-a de exercer a sua concupiscência contra o espírito. E por isso, esta última fortaleza
era a própria a Cristo, cujo espírito atingira o sumo grau nessa virtude. E embora não sofresse nenhuma
impugnação interior, quanto ao atrativo do pecado, sofreu-a contudo anterior, da parte do mundo e do
diabo, vencendo os quais mereceu a coroa da vitória.

## Art. 3 — Se em Cristo houve ignorância.
O terceiro discute-se assim. — Parece que em Cristo houve ignorância.

1. — Pois, Cristo tinha verdadeiramente o que lhe convinha à natureza humana, embora não lho
conviesse à natureza divina, assim, a paixão e a morte. Ora, a ignorância convinha à natureza humana de
Cristo; assim, diz Damasceno, que ele assumiu uma natureza servil e ignorante. Logo, em Cristo houve
realmente ignorância.

2. Demais. — Chama-se ignorante quem tem falta de conhecimento. Ora, certos conhecimentos Cristo
não os teve; assim, diz o Apóstolo: Aquele que não havia conhecido pecado o fez pecado por nós. Logo,
em Cristo houve ignorância.

3. Demais. — A Escritura diz: Antes que o menino saiba chamar por seu pai e por sua mãe, tirar-se-à a
fortaleza de Damasco. Ora, esse menino é Cristo. Logo, Cristo ignorava certas coisas.
Mas, em contrário. — A ignorância não se elimina com a ignorância. Ora, Cristo veio nos redimir das
nossas ignorância; pois, como diz o Evangelho, veio para alumiar os que vivem de assento nas trevas e
nas sombras da morte. Logo, em Cristo não houve ignorância.

SOLUÇÃO. — Assim como Cristo tinha a plenitude da graça e da virtude, assim também teve a plenitude
de toda a ciência, como do sobredito se colhe. Ora, assim como em Cristo a plenitude da graça e da
virtude exclui a concupiscência nascida do pecado, assim também a plenitude da ciência exclui a
ignorância, imposta à ciência. Por onde, assim como em Cristo não houve inclinação para o pecado,
assim também nenhuma ignorância.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A natureza assumida por Cristo pode ser considerada a
dupla luz. — Primeiro, quanto à sua essência específica. E, neste sentido, Damasceno diz que ela é
ignorante e servil. E por isso acrescenta: Pois, a natureza do homem é escrava de Deus, que a fez, e ela
não tem o conhecimento, das causas futuras. — A outra luz pode ser considerada pelo que tem, da
união com a hipóstase divina, da qual recebeu a plenitude da ciência e da graça, conforme o Evangelho:
Nós vimos a sua glória como de Filho unigénito do Pai, cheio de graça e de verdade. E, neste sentido, a
natureza humana de Cristo não estava sujeita a nenhuma ignorância.

RESPOSTA À SEGUNDA. — Diz-se que Cristo não conheceu o pecado, pelo não conhecer por
experiência. Mas o conhecia por simples conhecimento.

RESPOSTA À TERCEIRA. — No lugar aduzido o Profeta se refere à ciência humana de Cristo. Pois diz:
Antes que o menino saiba, isto é, pela sua humanidade, chamar por seu pai, isto é, José, que era o seu
pai putativo, e por sua mãe, isto é, Maria, tirar-se-á a fortaleza de Damasco. O que não se deve entender
como significando que um dia foi homem e não o soube; mas sim que, antes que saiba, isto é, antes que
se torne homem dotado da ciência humana, tirar-se-ão: ou, literalmente, a fortaleza de Damasco e os
despojos de Somaria pelo rei dos Assírios; ou, em sentido espiritual, que, ainda antes de nascido, salvará
o povo de Israel, só com a invocação do seu nome. — Agostinho, porém; diz que isso se completou na
adoração dos Magos. São suas palavras: Antes de poder falar a língua dos homens por meio da natureza
humana, recebeu a fortaleza de Damasco, isto é, as riquezas de que Damasco presumia; e dessas
riquezas o ouro designa a sua realeza. Quanto aos despojos de Somaria eles significam os seus próprios
habitantes. Pois, Samaria representa a idolatria; porque lá o povo de Israel afastou-se do Senhor e se
entregou ao culto dos ídolos. E são esses os primeiros despojos que o menino arrancou ao poder da
idolatria. E, segundo esta interpretação, as palavras — antes que saiba — entendem-se como
significando — antes que mostre que sabe.

## Art. 4 — Se a alma de Cristo era passível.
O quarto discute-se assim. — Parece que a alma de Cristo não era passível.

1. — Pois, nenhum ser é paciente senão em relação a outro mais forte, como o provam Agostinho e
Aristóteles. Ora, nenhuma criatura era mais forte que a alma de Cristo. Logo, não podia ela sofrer nada
de nenhuma criatura e, portanto, não era passível; e assim teria em vão a potência passiva se de
nenhum ser podia ser paciente.

2. Demais. — Túlio diz que as paixões são umas doenças da alma. Ora, na alma de Cristo não havia
nenhuma doença, pois, as doenças da alma resultam do pecado, como está claro na Escritura: Salva a
minha alma porque pequei contra ti. Logo, a alma de Cristo não era susceptível de nenhuma paixão.

3. Demais. — Parece que as paixões da alma são umas inclinações para o pecado; por isso o Apóstolo
lhes chama paixões dos pecados. Ora, em Cristo não havia nenhuma inclinação para o pecado, como se
disse. Logo, parece que na sua alma não havia paixões. E assim, a alma de Cristo não era passível.
Mas, em contrário, a Escritura diz, da pessoa de Cristo: A minha alma está repleta de males; não, certo,
de pecados, mas de males humanos, isto é, de dores, como expõe a Glosa. Portanto, a alma de Cristo
era passível.

SOLUÇÃO. — A alma unida ao corpo é susceptível de duas espécies de paixões: as do corpo e as da
alma. — As paixões do corpo vêm de uma perturbação corpórea. Pois, sendo a alma a forma do corpo,
resulta por consequência que uno é o ser da alma e do corpo; e portanto, perturbado o corpo por
alguma paixão corpórea, há de a alma necessariamente, perturbar-se, embora: por acidente, isto é, na
existência que tem enquanto unida ao corpo. Ora, o corpo de Cristo, tendo sido passível e mortal, como
estabelecemos, havia também necessariamente a sua alma de ser passível. — Quanto à alma, diz-se que
é susceptível de paixão pela operação que lhe é própria ou é dela mais principalmente que do corpo. É
embora digamos, neste sentido, que a alma sofre, mesmo na sua inteligência e na sua sensibilidade,
contudo, como provamos na Segunda Parte, chamam-se proprissimamente paixões da alma as afeições
do apetite sensitivo, que existiram em Cristo, como tudo quanto constitui a natureza da alma. Donde o
dizer Agostinho: O Senhor, tendo se dignado viver a vida humana em forma de escravo, quis sentir essas
paixões quando julgou que as devia sentir; pois, um verdadeiro corpo humano e uma verdadeira alma
humana não deviam ter sentimentos que não fossem verdadeiramente humanos.
Devemos porém saber, que essas paixões existiram em Cristo diferentemente do que existem em nós,
em três pontos. — Primeiro, quando ao objeto. Pois, as paixões da nossa alma tendem geralmente para
objetos ilícitos; o que não se dava com Cristo. — Segundo, quanto ao princípio. Porque tais paixões
frequentemente previnem em nós o juízo da razão; ao passo que em Cristo todos os movimentos
sensitivos do apetite se orientavam conforme a disposição racional. Donde o dizer Agostinho: Pela
admirável disposição da graça nele existente, Cristo não sentia esses movimentos na sua alma humana
senão quando queria, assim como se fez homem quando quis. — Terceiro, quanto ao afeto. Pois, em
nós às vezes esses movimentos não se limitam ao apetite sensitivo, mas arrastam a razão. O que não se
dava com Cristo; pois, os movimento naturalmente próprios da carne humana existiam no seu apetite
sensitivo com uma disposição tal, que não impediam de nenhum modo a razão de exercer a sua
atividade. Donde o dizer Jerônimo: Nosso Senhor sofreu verdadeiramente a tristeza para provar que
verdadeiramente assumiu a natureza humana; mas, para que a paixão não lhe dominasse a alma, o
Evangelho diz que ele começou a sofrer a tristeza, por uma como propaixão, De modo que se entenda
por paixão perfeita a que domina totalmente a alma, isto é, a razão; e por propaixão a paixão que,
começada no apetite sensitivo, não se estendeu mais além.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A alma de Cristo podia por certo resistir às paixões, para
se lhe elas não manifestarem; sobretudo pelo seu poder divino. Mas, por vontade própria, sujeitou-se às
paixões tanto corpóreas como da alma.

RESPOSTA À SEGUNDA. — Túlio se exprime, no lugar citado, ao modo dos estóicos, que chamavam
paixões, não a quaisquer movimentos do apetite sensitivo, mas só aos desordenados. Ora, tais paixões,
manifestamente não existiam em Cristo.

RESPOSTA À TERCEIRA. — As paixões dos pecadores são movimentos do apetite sensitivo que tendem
para objetos ilícitos. O que não existiu em Cristo, como nele não existiu a inclinação para o pecado.

## Art. 5 — Se Cristo sofreu verdadeiramente a dor sensível.
O quinto discute-se assim. — Parece que Cristo não sofreu verdadeiramente a dor sensível.

1. — Pois, diz Hilário: Sendo para Cristo a morte, vida, que devemos crer tenha sofrido no sacramento
da sua morte, ele que dá a vida pelos que lhe sacrificam a deles? E a seguir: O Deus unigênito realmente
assumiu a naturezas humana, sem deixar por isso de ser Deus. E assim, embora recebesse golpes ou
fosse varado de ferimentos, ou amassado ou suspenso na cruz, tudo isso bem lhe podia fazer sofrer os
assaltos da paixão, mas não causar-lhe dor; pois, era lhe tudo como um dardo que transpassasse a água.
Logo, em Cristo não houve verdadeira dor.

2. Demais. — E próprio à carne concebida no pecado ficar sujeita ao jugo da dor. Ora, a carne de Cristo
não foi concebida no pecado, mas, do Espírito Santo, no ventre virginal. Logo, não estava sujeita à
necessidade de sofrer a dor.

3. Demais. — A contemplação das coisas divinas diminui o sentimento da dor, por isso os mártires
suportaram melhor os seus tormentos, por terem a consideração posta no divino amor. Ora, a alma de
Cristo estava toda engolfada nas delícias da contemplação de Deus, cuja essência via, como dissemos.
Logo, não podia sentir nenhuma dor.
Mas, em contrário, a Escritura: Verdadeiramente ele foi o que tomou sobre si as nossas fraquezas e ele
mesmo carregou com as nossas dores.

SOLUÇÃO. — Como resulta do que dissemos na Segunda Parte, a dor sensível real implica uma lesão
corpórea e o sentimento dessa lesão. Ora, o corpo de Cristo, sendo passível e mortal, como
demonstramos, podia sofrer uma lesão; e como a alma de Cristo era dotada de todas as potências
naturais, não lhe faltava o sentimento da lesão. Por onde, nenhuma dúvida pode haver que Cristo
tivesse realmente sofrido a dor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Em todas as palavras citadas e em outras semelhantes,
Hilário pretende excluir da carne de Cristo não a verdadeira dor, mas a necessidade de sofrê-la. Por isso,
depois das palavras citadas, acrescenta: Quando o Senhor teve sede, teve fome ou chorou, não
mostrou. com isso que verdadeiramente bebesse, comesse ou sofresse dor; mas, para mostrar que
tinha verdadeiramente um corpo, assumiu os hábitos do corpo; de modo que, pelo que é habitual à
nossa natureza, satisfizesse às exigências do corpo. Ou, quando tomou a bebida e a comida, cedeu, não
à necessidade, mas aos hábitos do corpo. E toma a palavra necessidade na sua relação com a causa
primeira delas, que é o pecado, como dissemos; de modo que compreendamos que a carne de Cristo
não estava sujeita ao jugo das referidas necessidades, porque nela não havia pecado. Por isso
acrescenta Hilário: Teve Cristo um corpo, mas próprio da sua origem; nem trazia em si os vícios da
concepção humana; mas se revestiu da forma do nosso corpo, em virtude do seu poder. Quanto à causa
próxima dessas necessidades, que é a composição de elementos contrários, a carne de Cristo estava
sujeita ao jugo delas, como estabelecemos.

RESPOSTA À SEGUNDA. — A carne concebida no pecado está sujeita à dor; não só por necessidade dos
princípios naturais, mas ainda pela necessidade do reato do pecado. Cuja necessidade em Cristo não
existia; mas só, a imposta pelos princípios naturais.

RESPOSTA À TERCEIRA. — Como dissemos, por uma sábia disposição da sua divindade, a beatitude, a
alma de Cristo de tal modo a tinha que ela não derivava para o corpo, para lhe não tolher a passibilidade
e a mortalidade. E pela mesma razão, o prazer da contemplação de tal modo o gozava a sua inteligência,
que não derivava para as potências sensíveis, a fim de não excluir assim a dor sensível.

## Art. 6 — Se Cristo sofreu a tristeza.
O sexto discute-se assim. — Parece que Cristo não sofreu a tristeza.

1. — Pois, diz de Cristo a Escritura : Não será triste nem turbulento.

2. Demais. — Diz a Escritura : Não entristecerá ao justo coisa alguma, qualquer que for o que lhe
acontecer. E a razão disto os estóicos a davam dizendo, que ninguém se entristece senão pela perda dos
seus bens; ora o justo não considera bens senão a justiça e a virtude, que não pode perder. Do
contrário, estaria sujeito à fortuna, se se entristecesse quando perdesse os bens dela. Ora, Cristo era o
justo por excelência, segundo a Escritura: Este é o nome que lhe chamaram, o Senhor nosso justo. Logo,
não sofreu a tristeza,

3. Demais. — O Filosofo diz, que toda tristeza deve ser evitada como um mal. Ora, Cristo não tinha que
evitar nenhum mal. Logo, não sofreu a tristeza.

4. Demais. — Como diz Agostinho, Nós nos entristecemos com o que nos contraria a vontade. Ora,
Cristo nada sofreu contra a sua vontade; pois, como diz a Escritura, foi oferecido porque ele mesmo
quis. Logo, Cristo não sofreu a tristeza.
Mas, em contrário, diz o Senhor: A minha alma está numa tristeza mortal. E Ambrósio: Como homem,
sofreu tristeza; pois, assumiu a minha tristeza, Pois, exprimo por certo a tristeza quando me refiro à
cruz.

SOLUÇÃO. — Como dissemos, o prazer da contemplação divina concentrava-se, por disposição do poder
de Deus, na alma de Cristo, a ponto de não derivar para as potências sensitivas e, assim, excluir a dor
sensível. Ora, como a dor sensível tem a sua sede no apetite sensitivo, assim também a tristeza; mas
diferentemente, pelo seu motivo ou objeto. Pois, o objeto e o motivo da dor é uma lesão percebida pelo
sentido do tato; como quando alguém é ferido. Ora, o objeto e o motivo da tristeza é um dano ou um
mal interiormente apreendido, pela razão ou pela imaginação, como dissemos na Segunda Parte; tal o
caso de quem se entristece pela perda da graça ou do dinheiro. Ora, e alma de Cristo podia apreender
interiormente uma coisa como nociva, tanta para si mesmo, como o foi a sua paixão e morte; quanto
para os outros, como o pecado dos discípulos ou ainda dos Judeus que o mataram. Por onde, assim
como Cristo podia sofrer realmente a dor, também podia padecer realmente a tristeza; mas de maneira
diferente de nós, daqueles três modos que assinalamos, quando tratamos em geral das paixões da alma
de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo não sofreu a tristeza, como paixão, no seu sentido
prefeito; mas houve nele uma tristeza incoativa, como propaixão. Donde o dizer a Escritura: Começou a
entristecer-se e a angustiar-se. — Ora, uma coisa é entristecer-se e outra, começar a entristecer -se.

RESPOSTA À SEGUNDA. — Como diz Agostinho, os estóicos ensinavam que há na alma do sábio três
eupatias, isto é, boas paixões, correspondentes às três perturbações - a cobiça, a alegria e o temor.
Essas três eupatias correspondentes são: à cobiça, a vontade; à alegria, o gáudio; ao medo, a cautela.
Mas negavam pudesse haver algo na alma do sábio de correspondente à tristeza; porque a tristeza
supõe um mal já acontecido; ora, julgavam que nenhum mal podia atingir o sábio. E pensavam assim por
só considerarem como bem o honesto, que torna os homens bons; e como sendo mal só o desonesto,
que torna os homens maus. — Mas, embora o honesto seja o principal bem do homem, e o desonesto o
mal principal, por dizerem respeito à razão, que é o principal no homem, há contudo, certos bens
humanos secundários, relativos ao corpo ou às coisas exteriores que servem ao corpo. E, assim sendo,
pode haver tristeza na alma do sábio, quando o apetite sensitivo venha a apreender algum dos referidos
males; não vai porém essa tristeza até perturbar a razão. E também a esta luz entende-se que o justo
não se contristará, seja o que for que lhe suceda; pois, nenhum acontecimento lhe perturba a razão, Por
onde, Cristo sofreu tristeza, quanto à propaixão; mas não quanto à paixão.

RESPOSTA À TERCEIRA. — Toda tristeza implica o mal da pena; mas nem sempre o mal da culpa, senão
só quando procede do afeto desordenado. Donde o dizer Agostinho: Quando estas paixões obedecem à
razão reta e lhes cedemos em tempo e lugar oportunos, quem ousará chamar-lhes doenças ou paixões
más?

RESPOSTA À QUARTA. — Nada impede ser uma coisa contrária à vontade, em si mesma considerada e,
contudo, querida, em razão do fim a que se ordena. Assim, um remédio amargo não o queremos em si
mesmo, mas enquanto ordenado à saúde. Ora, deste modo, a morte de Cristo e a sua paixão foram, em
si mesmas consideradas, involuntárias e causas de tristeza; embora fossem voluntárias quanto ao fim,
que é a redenção do gênero humano.

## Art. 7 — Se em Cristo houve temor.
O sétimo discute-se assim. — Parece que em Cristo não houve temor.

1. — Pois, diz a Escritura: O justo, como leão afouto, sem terror. Ora, Cristo era o justo por excelência.
Logo, em Cristo não houve nenhum terror.

2. Demais. — Hilário diz: Pergunto aqueles, que tem tal persuasão, se é racional pensar que temesse a
morte quem, expulsando da alma dos Apóstolos todo terror da morte, os exportava à glória do martírio.
Logo, não é racional que houvesse em Cristo o temor.

3. Demais. — O homem só tem temor daquilo que não pode evitar. Ora, Cristo podia evitar tanto o mal
da pena que sofreu, como o da culpa que atingiu os demais. Logo, em Cristo não houve nenhum temor.
Mas, em contrário, o Evangelho: Jesus começou a ter pavor e a angustiar-se.

SOLUÇÃO. — Assim como a tristeza é causada pela apreensão do mal presente, assim o temor, pela do
mal futuro. Ora, a apreensão do mal futuro, mesmo revestida de toda certeza, não causa temor. Donde
o dizer o Filósofo, só há temor do que não temos nenhuma esperança de evitar; pois, o que nenhuma
esperança de evitar; pois, o que nenhuma esperança temos de evitar apreendemos como um mal
presente e, assim, causa antes tristeza que temor.
Por onde, o temor pode ser considerado a dupla luz. — Primeiro, quanto ao fato de o apetite sensitivo
fugir naturalmente ao mal corpóreo presente, pela tristeza; e pelo temor, se for futuro. Ora, deste
modo, houve temor em Cristo, como houve tristeza. — A outra luz, pode ser considerado quanto à
incerteza do acontecimento futuro; assim, quando tememos, de noite, por um som que ouvimos e cuja
proveniência ignoramos. E deste modo, em Cristo não houve temor, como diz Damasceno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dissemos que o justo não tem terror, compreendendo-
se o terror como uma paixão perfeita, que priva o homem do bem da razão. E assim, não houve terror
em Cristo, senão só na propaixão. Por isso, o Evangelho refere que Jesus começou a ter pavor e a
angustiar-se, quase pela propaixão, como expõe Jerônimo.

RESPOSTA À SEGUNDA. — Hilário exclui de Cristo o temor no mesmo sentido em que dele exclui a
tristeza; isto é, quanto à necessidade que ele impõe. Contudo, para provar que assumiu
verdadeiramente a natureza humana, Jesus assumiu voluntàriamente o temor, como também a tristeza.

RESPOSTA À TERCEIRA. — Embora Cristo pudesse evitar os males futuros, pelo poder da sua divindade;
contudo eles eram inevitáveis, ou não fàcilmente evitáveis, por causa da fraqueza da carne.

## Art. 8 — Se em Cristo houve admiração.
O oitavo discute-se assim. — Parece que em Cristo não havia admiração.

1. — Pois, a admiração é causada de conhecermos um efeito e lhe ignorarmos a causa; e assim, admirar-
se é próprio só do ignorante. Ora, em Cristo não houve ignorância, como se disse. Logo, em Cristo não
houve admiração.

2. Demais. — Damasceno diz, que a admiração é o temor oriundo de uma grande imaginação; donde o
dizer o Filósofo, que o magnânimo não é admirativo. Ora, Cristo foi magnânimo por excelência. Logo,
em Cristo não houve admiração.

3. Demais. — Ninguém, se admira daquilo que pode fazer. Ora, Cristo podia fazer tudo quanto de grande
havia na realidade. Logo, de nada podia admirar-se.
Mas, em contrário, o Evangelho: Ouvindo Jesus (as palavras do Centurião) admirou-se.

SOLUÇÃO. — A admiração nasce propriamente do que é novo e insólito. Ora, para a ciência divina de
Cristo nada podia haver de novo nem de insólito; nem para a sua ciência humana, pela qual conhecia as
causas no Verbo, ou as causas, pelas espécies infusas. Mas algo podia haver de novo e de insólito à sua
ciência experimental, pela qual lhe podiam ocorrer todos os dias causas novas. Por onde, se nos
referimos à sua ciência divina ou à da visão beatífica ou ainda à infusa, em Cristo não houve admiração:
mas, se lias referimos à sua ciência experimental, então podia nele haver admiração. E assumiu esse
sentimento, para a nossa instrução; isto é, para nos ensinar que devemos admirar o que também ele
admirou. Donde o dizer Agostinho: Cristo nos advertiu que deviamos admirar o que também ele
admirou, a nós que temos necessidades de tais movimentos. Logo, todos os seus movimentos como
esses não eram sinais de perturbação de alma, mas exprimiam o magistério docente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora Cristo nada ignorasse, podia contudo ocorrer
alguma novidade à sua ciência experimental, que lhe causasse admiração.

RESPOSTA À SEGUNDA. — Cristo não se admirava da fé do Centurião por ser grande relativamente a
ele, mas pelo ser relativamente aos homens.

RESPOSTA À TERCEIRA. — Cristo podia fazer tudo pelo seu poder divino, que não deixava lugar nele à
admiração; mas só era susceptível de admiração experimental, como dissemos.

## Art. 9 — Se em Cristo havia a ira.
O nono discute-se assim. — Parece que em Cristo não havia a ira.

1. — Pois, diz a Escritura: A ira do homem não compõe a justiça de Deus. Ora, tudo o que havia em
Cristo estava compreendido na justiça de Deus; pois, ele nos foi feito por Deus justiça. Logo, parece que
em Cristo não houve ira.

2. Demais. — A ira se opõe à mansidão, como se lê em Aristóteles. Ora, Cristo foi manso por excelência.
Logo, nele não houve ira.

3. Demais. — Gregório diz: A ira, como pecado, cega os olhos da alma; mas, como zelo, ela os perturba.
Ora, em Cristo os olhos da alma nem ficaram cegos nem perturbados. Logo, em Cristo não houve ira,
nem como pedado nem como zelo.
Mas, em contrário, o Evangelho diz que dele se cumpriu aquela palavra da Escritura: O zelo da tua casa
me devora.

SOLUÇÃO. — Como dissemos na Segunda Parte, a ira é o efeito da tristeza. Pois, a tristeza que sofremos
nos provoca o. apetite sensitivo a repelir a ofensa causada a nós ou a outrem. E assim a ira é uma paixão
composta da tristeza e do desejo da vindicta. Ora, dissemos que em Cristo podia haver tristeza. Quanto
ao desejo da vindicta, ele é às vezes acompanhado do pecado, quando procuramos vingar-nos
contrariamente à ordem da razão. E então não podia haver ira em Cristo, pois, é essa ira pecaminosa.
Mas outras vezes esse desejo não só é isento de pecado, mas até é louvável; como quando exercemos a
vindicta segundo a ordem da justiça. E essa se chama a ira do zelo, Assim, diz Agostinho: É devorado
pelo zelo da casa de Deus quem procura emendar todos os males que vê; e quando não pode emendá-
los, tolera-os e geme sobre eles. E tal foi a ira de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como ensina Gregório, de dois modos pode o homem
ceder a ira. — Ás vezes ela previne a razão e a arrasta ao seu ato. Então a ira é propriamente uma
operação; e esta se atribui ao agente principal. E neste sentido se diz que a ira do homem não cumpre a
justiça de Deus. — Mas, outras vezes a ira é consequência do ato da razão e quase instrumento dela. E
então o ato da justiça não se atribui à ira, mas, à razão.

RESPOSTA À SEGUNDA. — A ira, que transgride a ordem da razão. se opõe à mansidão; não porém a ira
moderada e conservada no meio termo, pela razão. Pois, a mansidão mantém o meio termo da ira.

RESPOSTA À TERCEIRA. — Em nós, pela ordem natural, as potências da alma podem ser obstáculo umas
às outras. Assim, a operação intensa de uma potência enfraquece a de outra. Donde vem que o
movimento da ira, mesmo quando moderado pela razão, de certo modo impede aos olhos da alma a
contemplação. Mas, em Cristo, por força do poder divino, a cada potência lhe era garantida a sua ação
própria, de modo que uma não oferecia obstáculo a outra. Por onde, assim como o prazer da
contemplação da mente não impedia a tristeza ou a dor da parte inferior, assim também e
inversamente, as paixões da parte inferior em nada impediam o ato da razão.

## Art. 10 — Se Cristo, enquanto viandante neste mundo simultaneamente gozava da visão beatífica.
O décimo discute-se assim. Parece que Cristo, enquanto viandante neste mundo, não gozava
simultaneamente da visão beatífica.

1. — Pois, o viandante precisa ser conduzido ao fim da beatitude; ao passo que quem contempla a Deus
repousa no fim. Ora, não é possível a um mesmo ser mover-se para o fim e repousar nele. Logo, Cristo
não podia simultaneamente ser viandante e gozar da visão beatifica.

2. Demais. — Ser levado à beatitude ou obtê-la não é possível ao corpo do homem. mas só à sua alma.
Por isso diz Agostinho: Da alma redunda, para a natureza inferior, que é o corpo, não a beatitude
própria de quem frui e contempla, mas a plenitude da saúde que é o vigor da incorrupção, Ora, Cristo,
embora tivesse um corpo passível, contudo pela alma. fruía plenamente de Deus, Logo, Cristo não era
viandante. mas gozava da pura visão de Deus.

3. Demais. — Os santos, dos quais as almas estão no céu e os corpos, no sepulcro, gozam por certo da
beatitude, pela alma, embora os corpos lhes estejam sob o jugo da morte. E contudo deles não se diz
que são viandantes, mas somente que contemplam a Deus. Logo, pela mesma razão, embora o corpo de
Cristo fosse mortal, como a sua alma gozava de Deus, parece que vivia na pura contemplação e de
nenhum modo era viandante.
Mas, em contrário, diz a Escritura: Porque hás de ser nesta terra como um estranho e como um
viandante que toma o seu caminho para albergar na estalagem por pouco tempo?

SOLUÇÃO. — Diz-se que é viandante quem tende para a beatitude; e vidente quem já alcançou a
beatitude, conforme àquilo do Apóstolo: Correi de tal maneira que alcanceis, E noutro lugar: Mas eu
prossigo para ver se de algum modo poderei alcançar. Ora, a beatitude completa do homem é a da alma
e a do corpo, como demonstramos na Segunda Parte. A alma é próprio contemplar e gozar Deus; o
corpo, como tal, ressuscitará espiritual e em vigor e em glória e em incorrupção, na linguagem do
Apóstolo. Ora, antes da paixão, a alma de Cristo contemplava plenamente a Deus; e assim tinha a
beatitude pelo que ela compete à alma. Mas, quanto ao mais, faltava-lhe a beatitude, tanto por lhe ser
passível a alma, como passível e mortal o corpo, segundo do sobredito se colhe. Por onde, era
simultaneamente vidente, por ter a beatitude na medida em que não a tinha.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É impossível simultaneamente ser movido para o fim e
descansar nele. Mas nada o impede, se o for a luzes diversas; assim, simultaneamente sabemos o que já
aprendemos e aprendemos o que ainda não sabemos.

RESPOSTA À SEGUNDA. — A beatitude, principal e propriamente, consiste na contemplação da alma;
mas, secundaria e quase instrumentalmente, ela supõe os bens do corpo; assim, como diz o Filósofo, os
bens exteriores servem de instrumento à beatitude.

RESPOSTA À TERCEIRA. — Não se dá o mesmo com as almas dos santos já mortos e com Cristo, por
duas razões. Primeiro, porque as almas dos santos não são passíveis, como o foi a alma de Cristo.
Segundo, porque os corpos deles nenhuma ação tinham para chegarem à beatitude; ao passo que
Cristo, pelas paixões do seu corpo, tendia à beatitude, quanto à glória deste.
