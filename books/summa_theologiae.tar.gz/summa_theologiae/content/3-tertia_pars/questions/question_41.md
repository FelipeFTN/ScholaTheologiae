# Questão 41: Da tentação de Cristo
Em seguida devemos tratar da tentação de Cristo. E nesta questão discutem-se quatro artigos:

## Art. 1 — Se Cristo devia ser tentado.
O primeiro discute-se assim. — Parece que Cristo não devia ser tentado.

1. — Pois, tentar é fazer uma experiência, e esta não a fazemos senão do que ignoramos. Ora, também
os demônios conheciam a virtude de Cristo, conforme odiz o Evangelho: Não permitia os demônios
falarem, pois sabiam que ele mesmo era o Cristo. Logo, parece que não devia Cristo ser tentado.

2. Demais. — Cristo veio destruir as obras do diabo, segunda a Escritura: Para destruir as obras do diabo
é que o Filho de Deus vez ao mundo. Ora, ninguém pode ao mesmo tempo destruir as obras de outrem
e sofrer-lhes a ação. Por onde, parece Que Cristo não devia ter sofrido ser tentado pelo diabo.

3. Demais. — Há três formas de tentação: a da carne, a do mundo e a do diabo. Ora, Cristo não foi
tentado nem pela carne nem pelo mundo. Logo, também não devia ter sido tentado pelo diabo.
Mas, em contrário, o Evangelho: Foi levado Jesus pelo Espírito ao deserto, para ser tentado pelo diabo.

SOLUÇÃO. — Cristo quis ser tentado, primeiro, para nos dar auxílio contra as tentações. Por isso diz
Gregório: Não era indigno do nosso Redentor querer ser tentado, ele que veio para ser imolado; para
que assim vencesse as nossas tentações com as suas, assim como venceu com a sua a nossa morte. —
Segundo para nossa cautela: a fim de que ninguém, por santo que seja, se julgue seguro eimune da
tentação. Por isso quis ser tentado depois do batismo; porque, como diz Hilário, as tentações do diabo
são mais freqüentes, sobretudo contra os santos, porque sobre estes é que ela mais deseja a vitória.
Donde o dizer a Escritura: Filho, quando entrares no serviço de Deus, tem ser firme na justiça e no
temor e prepara a tua alma para a tentação. — Terceiro, para nos dar o exemplo de como devemos
vencer as tentações do diabo. Donde o dizer Agostinho: Cristo deixou-se tentar pelo diabo, para nos
mostrar como venceremos as suas tentações, não somente pelo seu auxílio, mas também pelo seu
exemplo. — Quarto, para nos excitar à confiança na sua misericórdia. Donde o dizer o Apóstolo: Não
temos um pontífice que não possa compadecer-se das nossas enfermidades, mas que foi tentado em
todas as coisas à nossa semelhança, exceto o pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho, Cristo deixou-se conhecer pelos
demônios tanto quanto quis não pelo concernente à sua vida eterna, mas por certos efeitos temporais
do seu poder, por onde podiam de certo modo conjeturar que Cristo era Filho de Deus. Mas como, por
outro lado, viam nele certos sinais da fraqueza humana, não tinham como certo que fosse Filho de Deus.
E por isso não quiseram tentá-lo conforme ao que diz o Evangelho: Depois que teve fome chegou-se a
ele o tentador. Porque, como diz Hilário, o diabo não teria ousado tentar a Cristo, senão o
reconhecesse: como homem, quando o virou; sujeito à miséria da fome. E isto mesmo se conclui do seu
modo de tentar quando disse - Se és o Filho de Deus. Expondo o que, diz Gregório: Que quer significar
começando com tais palavras, senão que, embora sabedor que o Filho de Deus devia vir ao mundo, não
pensava, contudo que viesse sujeito a essas misérias do corpo?

RESPOSTA À SEGUNDA. — Cristo veio destruir as obras do diabo, não pelo emprego do seu poder, mas
antes sofrendo-lhe a ação e a dos seus partidários, de modo a vencê-la pela justiça e não pela
onipotência. Por isso diz Agostinho: O diabo foi vencido, não pelo poder, mas pela justiça de Deus. Por
onde, a respeito da tentação de Cristo devemos considerar o que fez por vontade própria e o que sofreu
do diabo. Assim por vontade própria deixou-se tentar do diabo, como está no Evangelho: Foi levado
Jesus pelo Espírito ao deserto, para ser tentado pelo diabo. Lugar que Gregório diz dever ser entendido
do Espírito Santo, e significa que o seu Espírito o levou onde o espírito maligno o encontrasse para
tentá-lo. Mas, sofreu a ação do diabo quando este o levou para sobre o pináculo do Templo, ou para um
monte muito alto. Nem é para admirar, como diz Gregório, que se deixasse conduzir pelo diabo a um
monte, quem permitiu que os seus partidários o crucificassem. Mas não devemos pensar que fosse
tomado à força pelo diabo, mas que, como nota Orígenes, o seguia a este para o lugar da tentação,
como um atleta que marcha voluntàriamente para o combate.

RESPOSTA À TERCEIRA. — Como diz o Apóstolo, Cristo quis ser tentado em todas as causas, exceto o
pecado. Ora, a tentação proveniente do diabo pode ser sem pecado, pois, ela se faz pela só sugestão
intervir. Ao passo que originada na carne não pode deixar de ser pecaminosa, porque se faz pela
deleitação e pela concupiscência. E, como diz Agostinho, há sempre pecado quando a carne deseja
contra o espírito. Donde o ter Cristo querido a tentação do diabo, mas não a da carne.

## Art. 2 — Se Cristo devia ser tentado no deserto.
O segundo discute-se assim. — Parece que Cristo não devia ser tentado no deserto.

1. — Pois, Cristo quis ser tentado para nosso exemplo, como se desse. Ora, o exemplo deve ser
claramente proposto aos que devem aproveitar dele, Logo, não devia ser tentado no deserto.

2. Demais. — Crisóstomo diz que contra os solitários é que o diabo emprega toda a força da sua
tentação. Por isso, no princípio tentou a mulher, quando a viu desacompanhada de Adão. E assim,
Cristo, indo ao deserto para ser tentado, parece que se expôs à tentação. Ora, como se deixou tentar
para nosso exemplo, parece que também nós devemos nos expor à tentação. O que, contudo é
perigoso; pois, ao contrário, devemos contar as ocasiões das tentações.

3. Demais. — A segunda tentação de Cristo referida pelo Evangelho é a seguinte: O diabo, tomando-o, o
levou à cidade santa e o pôs sobre o pináculo do Templo, o qual certamente não estava num deserto.
Logo, nem só no deserto foi tentado.
Mas, em contrário, o Evangelho: Jesus estava no deserto quarenta dias e quarenta noites e ali foi
tentado por Satanás,

SOLUÇÃO. — Como se disse Cristo por vontade própria deixou-se tentar pelo diabo, assim como
voluntàriamente entregou o corpo à morte; do contrário, o diabo não ousaria aproximar-se dele. Ora, o
diabo atenta de preferência os solitários; pois, como diz a Escritura, se alguém prevalecer contra um,
dois lhe resistem, Por isso foi Cristo para o deserto, como para o campo da luta, para ser nele tentado
pelo diabo. Donde o dizer Ambrósio, que Cristo foi ao deserto deliberadamente, para provocar o diabo.
Pois, se este não viesse atacá-la, isto é, o diabo, Cristo não o teria vencido. - Mas acrescenta ainda
outras razões, dizendo que Cristo assim procedeu misteriosamente para livrar Adão do exílio; pois, este
fora precipitado, do paraíso, num deserto. Para nos mostrar, com o seu exemplo, que o diabo inveja os
que progridem no bem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo é proposto como exemplo a todos, pela fé,
segundo aquilo do Apóstolo. Pondo os olhos no autor e consumador da fé, Jesus. Ora, a fé, como ainda
o diz o Apóstolo, é pelo ouvido e não, pelos olhos. Antes, na expressão do Evangelho, bem-aventurados
os que não viram e creram. Assim, para a tentação de Cristo nos servir de exemplo, não era necessário
fosse presenciada pelos homens, bastando que lhes fosse narrada.

RESPOSTA À SEGUNDA. — Há duas espécies de ocasião à tentação. - Uma da parte do homem, como
quando não evitamos as ocasiões próximas de pecar. Pois tais ocasiões devemos evitá-las, como foi dito
a Lot: Não pares em parte alguma dos arredores de Sodoma. A outra espécie de ocasião vem do diabo,
sempre invejoso de quem e esforça por ser melhor. E essa ocasião de tentação não devemos evitá-la.
Por isso diz Crisóstomo: Não só Cristo foi levado pelo Espírito ao deserto, mas também todos os filhos
de Deus possuidores do Espírito Santo, que não consentem em ficar ociosos, mas são ungidos pelo
Espírito Santo a empreender grandes obras; e isso, para o diabo, é estar no deserto, onde não há o
pecado com que ele se compraz. Também todas as boas obras constituem um deserto, para a carne e
para o mundo, porque contrariam as tendências de uma e de outro. Ora, dar tal ocasião de tentação ao
diabo não é perigoso, porque maior é o auxílio do Espírito Santo, autor das obras perfeitas, do que o
ataque do diabo invejoso.

RESPOSTA À TERCEIRA. — Certos dizem que todas as tentações tiveram por teatro o deserto. Desses,
uns dizem que Cristo foi levado à cidade santa, não realmente, mas em visão imaginária. Outros porém
opinam que a própria cidade santa, isto é, Jerusalém, é chamada deserto, por ter sido abandonada por
Deus. - Mas não há necessidade de tais interpretações, porque Marcos diz ter sido Cristo tentado pelo
diabo no deserto, mas não que o fosse só no deserto.

## Art. 3 — Se Cristo devia ser tentado depois do jejum.
O terceiro discute-se assim. — Parece que Cristo não devia ser tentado depois do jejum

1. — Pois, como se disse Cristo não devia viver uma vida de austeridades. Ora, parece que nenhuma
austeridade era maior que a de passar sem comer nada quarenta dias e quarenta noites; pois a
expressão — jejuou quarenta dias e quarenta noites — entende-se como significando que durante esses
dias não tomou absolutamente nenhum alimento, como diz Gregório. Logo, parece que não devia ter-se
sujeitado a um tal jejum antes da tentação.

2. Demais. — O Evangelho diz que esteve no deserto quarenta dias e quarenta noites e ali foi tentado
por Satanás. Ora, jejuou durante quarenta dias e quarenta noites. Logo, parece que foi tentado pelo
diabo, não depois do jejum, mas durante ele.

3. Demais. — No Evangelho não lemos que Cristo jejuasse, senão uma vez. Ora, não foi tentado pelo
diabo só uma vez; assim, lemos que, acabada toda a tentação, se retirou dele o demônio até certo
tempo. Logo, assim como a segunda tentação não foi precedida de jejum, nem a primeira devera tê-la
sido.
Mas, em contrário, o Evangelho: Tendo jejuado quarenta dias e quarenta noites, depois teve fome; e
então chegou-se a ele o tentador.

SOLUÇÃO. — Era conveniente que Cristo quisesse ser tentado depois do jejum. — Primeiro, para nos
dar exemplo. Pois, como todos temos o dever de nos defender contra as tentações, o ter Cristo jejuado
antes da tentação futura, nos adverte que devemos nos armar contra as tentações pelo jejum. Por isso,
o Apóstolo enumera o jejum entre as armas da justiça. — Segundo, para nos mostrar que mesmo os que
jejuam o diabo os ataca com as suas tentações, assim como o faz os que vacam às boas obras. Por isso,
assim como tentou a Cristo depois do batismo; assim também depois do jejum. Donde o dizer
Crisóstomo: Cristo jejuou, sem precisar de o fazer só para nos instruir quão grande bem é o jejum e que
escudo é contra o diabo; e que, depois do batismo devemos nos entregar ao jejum e não à sensualidade.
— Terceiro, porque ao jejum se lhe seguiu a fome, que deu ao diabo a audácia para atacá-la, como
dissemos. Pois, diz Hilário, se o Senhor teve fome, não foi que a necessidade o surpreendesse, mas
porque quis abandonar o homem à sua natureza. Também, como diz Crisóstomo, não prolongou o seu
jejum mais do que o fizeram Moisés e Elias, para que se não duvidasse da realidade do seu corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Cristo não convinha abraçar uma vida de austeridades,
senão viver a mesma vida que aqueles a quem pregava. Ora, ninguém deve assumir o ofício de
pregador, antes de ter-se purificado e aperfeiçoado na virtude, como de Cristo diz a Escritura, que
começou a fazer e a ensinar. Por isso, Cristo, logo depois do batismo assumiu uma vida de austeridades,
para ensinar que os pregadores só devem exercer o seu ofício depois de terem dominado a carne,
segunda aquilo do Apóstolo: Castigo o meu corpo e o reduzo à servidão para que não suceda que,
havendo pregado ao outros venha eu mesmo a ser reprovado.

RESPOSTA À SEGUNDA. — As palavras de Marcos podem entender-se no sentido que Cristo
permaneceu no deserto quarenta dias e quarenta noites durante os quais jejuou. Quanto à expressão -
foi tentado por Satanás — significa que Cristo o foi, não nesses quarenta dias e quarenta noites em que
jejuou, mas depois deles; pois, na versão de Mateus, tendo jejuado quarenta dias e quarenta noites,
depois teve fome, o que ofereceu ocasião ao tentador de aproximar-se dele. E o que se acrescenta — e
eis que os anjos o serviam — deve entender-se como tendo sucedido depois da tentação, pelo que
Mateus diz: Então o deixou o diabo, isto é, depois da tentação, e eis que os anjos o serviam. Quando à
interpolação de Marcos — e habitava com as feras — ela é para mostrar, segundo Crisóstomo, qual era
o deserto, isto é, envio de homens e cheio de animais selvagens. — Contudo, segundo a exposição de
Beda, o Senhor foi tentado durante os quarenta dias e as quarenta noites. Mas isso se entende, não
daquelas tentações visíveis. Referidos por Mateus e Lucas, que tiveram lugar depois do jejum; mas de
certos outros ataques que talvez Cristo sofreu do diabo no tempo desse jejum.

RESPOSTA À TERCEIRA. — Como diz Ambrósio, o diabo retirou-se de Cristo, até certo tempo, porque
depois se aproximou dele no tempo da paixão, não para tentá-lo, mas para combatê-la abertamente. -
Porém, nessa segunda tentação, Cristo foi tentado a cair em tristeza e no ódio dos próximos; assim
como no deserto o foi pelo prazer da gula e pelo desprezo de Deus, mediante a idolatria.

## Art. 4 — Se foi conveniente o modo e a ordem da tentação.
O quarto discute-se assim. — Parece que não foi conveniente o modo nem a ordem da tentação.

1. — Pois, a tentação do diabo é para induzir a pecar. Ora, se Cristo satisfizesse à fome do seu corpo
convertendo as pedras em pão, não pecaria; assim como não pecou quando multiplico os pães - milagre
não menor - para matar a fome à multidão. Logo, parece que não houve no caso nenhuma tentação.

2. Demais. — Ninguém que queira persuadir a outrem irá persuadi-lo do contrário do que pretende.
Ora, o diabo, colocando a Cristo sobre o pináculo do templo, pretendia tentá-lo com a soberba ou a
vanglória. Logo, não devia tê-lo persuadido a atirar-se abaixo, o que é o contrário da soberba ou da
vanglória, que busca sempre subir.

3. Demais. — Cada tentação há de ter por objeto um pecado. Ora, a tentação do monte persuadiu à
prática de dois pecados — o da cobiça e o da idolatria. Logo, parece que o modo da tentação não foi o
devido.

4. Demais. — As tentações têm por fim os pecados. Ora, sete são os vícios capitais, como se estabeleceu
na Segunda Parte. Ora, o diabo não tentou senão com os três — da gula, da vanglória e da cobiça. Logo,
parece não ter sido suficiente a tentação.

5. Demais. — Depois da vitória sobre todos os vícios, fica o homem sujeito à tentação da soberba e da
vanglória; porque, a soberba também arma cilada às boas obras, para perdê-las, como diz Agostinho.
Logo, inconvenientemente, Mateus situa no monte a última tentação — a da cobiça: e no templo, a
média — a da vanglória; sobretudo quando Lucas segue a ordem inversa.

6. Demais. — Jerônimo diz, que o propósito de Cristo foi vencer o diabo pela humildade e não pelo
poder. Logo, não devia tê-lo repelido imperiosamente, objurando-o: vai-te, Satanás.

7. Demais. — Parece que há falsidade na narração do Evangelho. Pois, não era possível Cristo ser
colocado no pináculo do Templo, sem que fosse visto por todos. Nem há nenhum monte tão alto donde
pudesse ser descortinado todo o mundo, de modo que pudesse aparecer a: Cristo todos os reinos dele.
Logo, parece mal referida a tentação de Cristo.
Mas, em contrário, a autoridade da Sagrada Escritura.

SOLUÇÃO. — O nosso inimigo nos tenta por meio de sugestões, como diz Gregório. Ora, não é do
mesmo modo que faz sugestão a todos, mas a cada um sugere aquilo a que oinclina o afeto. E é a razão
do diabo não tentar as pessoas espirituais, entrando logo a sugerir-lhes pecados graves; mas começa
paulatinamente, sugerindo-lhes os mais leves para passar depois aos mais graves. Por isso, Gregório,
expondo aquilo da Escritura — Cheira de longe a batalha, a exortação dos capitães e o alarido do
exército. — Comenta: Acertadamente se fala na exortação dos capitães e no alarido do exército. Porque
os primeiros vícios à sorrelfa e com aparências de razão, se introduzem na alma transviada mas todos os
mais daí resultantes confundem-na com um como clamor bestial, arrastando-a a toda espécie de
demências.
E foi essa ordem a mesma que o diabo observou na tentação do primeiro homem. Assim, primeiro
despertou-lhe na alma o desejo de comer do fruto da árvore proibida, ao dizer-lhe: Por que vos mandou
Deus que não comêsseis de toda árvore do paraíso? Depois, tentou-o com a vanglória, quando disse:
Abrir-se-vos-ão os olhos. E em terceiro lugar, levou a tentação ao extremo da soberba, quando disse:
Vós sereis como uns deuses, conhecendo o bem e o mal. E também observou a mesma ordem quando
tentou a Cristo. Assim, primeiro tentou-o com o desejo natural do sustento da vida do corpo, por meio
da comida, que têm todos os homens, por mais espirituais que sejam. Depois passou à tentação de
obrar por ostentação, em que os varões espirituais às vezes caem, e que constitui a vanglória: E em
terceiro lugar, despertou a tentação do desejo das riquezas e da glória do mundo até ao desprezo de
Deus, na qual não caem os homens espirituais, mas só os carnais. Por isso, nas primeiras duas tentações
o diabo disse — Se és o filho de Deus; não porém na terceira, na qual não caem os varões espirituais,
por serem filhos adotivos de Deus, podendo porém cair nas duas primeiras.
E assim, Cristo resistiu a essas tentações, invocando o testemunho da lei e não recorrendo ao seu poder,
para desse modo honrar mais o homem e dar maior punição ao adversário, que foi vencido não por
Deus mas pelo homem, como escreve Leão Papa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Usar do necessário para o sustento não é pecado de
gula; mas proceder desordenadamente, levado do desejo desse sustento, pode constituir o referido
pecado. Assim, é proceder desordenadamente querermos que a comida nos seja fornecida
milagrosamente, só para sustentarmos o corpo, quando podemos fazê-lo pelo subsídio humano. Por
isso o Senhor distribuiu milagrosamente o maná aos filhos de Israel no deserto, porque de nenhuma
outra maneira podiam alimentar-se. Do mesmo modo Cristo alimentou milagrosamente a multidão no
deserto, que não podia ser nutrida de outra maneira. Ora, Cristo, para satisfazer a sua fome, podia
recorrer a outros meios que não o milagre, como o fez João Batista; ou também dirigindo-se a
povoações próximas. Por isso, o diabo pensava que Cristo pecaria se, na qualidade de puro homem,
tentasse fazer milagre, para satisfazer a fome.

RESPOSTA À SEGUNDA. — É comum fazer-se da humildade exterior um meio de buscar a glória que nos
exalte, pelos nossos bens espirituais. Por isso diz Agostinho: Devemos notar que pode haver jactância,
não somente no esplendor e na pompa dos bens externos, mas também nas mortificações da
humildade. E para o significar o diabo persuadir a Cristo que se despenhasse abaixo, corporalmente,
para ganhar a glória espiritual.

RESPOSTA À TERCEIRA. — É pecado desejar desordenadamente as riquezas e as honras do mundo. O
que sobretudo se dá quando para alcançá-las, procedemos desonestamente. Por isso o diabo não se
contentou com persuadir a cobiça das riquezas e das honras: mas induzir a Cristo que, para alcançá-las,
o adorasse, o que é o máximo crime e contra Deus. Nem só disse — Se me adorares, mas acrescentou —
se prostrado, porque, como diz Ambrósio, há na ambição um perigo iminente — o de primeiro servir
para depois dominar os outros; de curvar-se em obséquios para depois ser honrada; e de se tornar
remissa para em seguida guindar-se. — E semelhantemente, nas precedentes tentações, procurou
despertar o desejo de um pecado, — para fazer cair em outro; assim, pela desejo da comida procurou
levar à vaidade de fazer milagres sem causa; e pelo desejo da glória, quis fazer Cristo tentar a Deus,
atirando-se do templo abaixo.

RESPOSTA À QUARTA. — Como diz Ambrósio, a Escritura não teria dito que o diabo se afastou de Cristo,
depois de consumadas todas as três tentações, se nessas três não incluíssem a matéria de todos os
pecados. Pois, as causas das tentações são as causas das seguintes cobiças: os deleites da carne, a
esperança da glória e o desejo do poder.

RESPOSTA À QUINTA. — Como diz Agostinho, é incerto o que se passou em primeiro lugar se primeiro
forem mostrados a Cristo os reinos da terra e depois foi levado ao pináculo do Templo, ou se foi este
último fato anterior àquele. Mas nada importa para o caso, pois, é certo que ambos se deram. Os
Evangelhos, porém os narram em ordem diferente, pois, ora referem a vanglória antes da cobiça, ora
inversamente.

RESPOSTA À SEXTA. — Quando Cristo sofreu a injúria da tentação ao dizer-lhe o diabo - Se és Filho de
Deus, lança-te daqui abaixo, não se perturbou nem o increpou. Mas quando o diabo, usurpando para si
a honra devida a Deus, disse — Dar-te-ei todas estas coisas se prostrado me adorares — Cristo
exasperou-se e repeliu-o dizendo — vai-te, Satanás; querendo ensinar-nos com esse exemplo que
devemos suportar magnanimamente as injúrias, feitas a nós mas não toleramos, nem sequer para os
ouvir, as injúrias feitas a Deus.

RESPÓSTA À SÉTIMA. — Como diz Crisóstomo o diabo levou a Cristo (ao pináculo do Templo) para que
fosse visto de todos; mas ele, sem o diabo saber, dispôs-se de modo a não ser vista de ninguém. — E
enquanto ao dito - E lhe mostrou todos os reinos da terra não devemos entendê-lo como significando,
que os viu a esses reinos, materialmente falando, nem as cidades ou os povos ou o ouro ou a prata, que
contivessem; mas sim, que o diabo mostrava com o dedo a Cristo as partes da terra, nos quais cada um
desses reinos ou cidades estava situado e expunha verbalmente as honras e o estado de cada um deles.
— Ou, segundo Orígenes, mostrava-lhe como ele, por meio dos diversos vícios, reinava no mundo.