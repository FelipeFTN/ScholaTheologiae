# Questão 11: Da ciência inata ou infusa da alma de Cristo
Em seguida devemos tratar da ciência. inata ou infusa da alma de Cristo.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se pela ciência infusa Cristo sabia tudo.
O primeiro discute-se assim. — Parece que pela ciência infusa Cristo não sabia tudo.
1 — Pois, essa ciência foi infusa em Cristo para a perfeição do seu intelecto possível. Ora, o intelecto
passível da alma humana não é potencial relativamente a todas as coisas, absolutamente falando, mas
só àquelas em relação às quais pode ser atualizada pelo intelecto agente, que é propriamente o seu
princípio de ação; e essas coisas são cognoscíveis pela razão natural. Logo, por essa ciência Cristo não
conhecia o que excede a razão natural.

2. Demais. — Os fantasmas estão para o intelecto humano como as cores para a visão, como diz
Aristóteles. Ora, não constitui uma perfeição da potência visiva conhecer o que é absolutamente
desprovido de cor. Logo, nem a perfeição do intelecto humano, conhecer aquilo que não pode ter
fantasma, como são as substâncias separadas. Assim, pois, como a referida ciência existia em Cristo,
para a perfeição da sua alma intelectiva, parece que, como essa ciência, não conhecia as substâncias
separadas.

3. Demais. — Não é da perfeição do intelecto conhecer o particular. Logo, parece que por essa ciência a
alma de Cristo não conhecia o particular.
Mas, em contrário, a Escritura: Enchê-lo-ei do Espírito da sabedoria e de entendimento, de ciência e de
conselho, no que está compreendido todo o cognoscível. Pois, o objeto da sabedoria é o conhecimento
de todas as coisas divinas; o do intelecto, o de todas os seres imateriais; o da ciência, o de todas as
conclusões; e enfim, o do conselho, o de tudo o que podemos fazer. Logo, parece que Cristo, pela
ciência nele infusa pelo Espírito Santo, teve conhecimento de todas as coisas.

SOLUÇÃO. — Como dissemos, para a alma de Cristo ser perfeita em tudo, havia de ser reduzida ao ato
toda a sua potencialidade. Ora, devemos notar que na alma humana, como em qualquer criatura,
distinguimos uma dupla potência passiva. Uma, por comparação com o agente natural; outra, por
comparação com o agente primeiro, capaz de reduzir qualquer criatura a um ato mais elevado, ao que
não é reduzida por um agente natural. E a isto se costuma chamar o poder de obediência na criatura.
Ora, uma e outra potência da alma de Cristo foi reduzida ao ato por essa ciência divinamente infusa, E
assim, por ela, a alma de Cristo, primeiro; conhecia tudo o que o homem pode conhecer por virtude do
lume do intelecto agente, como é tudo o que pertence às ciências humanas. Segundo, por essa ciência
conhecia Cristo tudo o que o homem conhece pela revelação divina, quer isso pertença ao dom da
sabedoria, quer ao da profecia, quer a qualquer dom do Espírito Santo; pois, tudo isso a alma de Cristo
conhecia mais abundante plenamente que os outros homens. Mas não conhecia por essa ciência a
essência mesma de Deus, mas só pela primeira, de que tratamos antes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe quanto à potência natural da alma
intelectiva, em dependência do seu agente natural, que é o intelecto ativo.

RESPOSTA À SEGUNDA. — A alma humana, no estado desta vida, por estar de certo modo presa ao
corpo de maneira a não poder inteligir sem fantasma, não pode inteligir as substâncias separadas. Mas,
após o estado desta vida, a alma separada poderá de certo modo conhecer por si mesma as substâncias
separadas, como dissemos na Primeira Parte. O que sobretudo é manifesto quanto à alma dos bem-
aventurados. Ora, Cristo, antes da paixão, ao mesmo tempo que vivia nesta vida contemplava a essência
divina. Por isso, a sua alma podia conhecer as substâncias separadas, pelo modo pelo qual a alma
separada conhece.

RESPOSTA À TERCEIRA. — O conhecimento do particular não constitui uma perfeição da alma
intelectiva, por um conhecimento especulativo; constitui-lhe porém uma perfeição, pelo conhecimento
prático, que não se realiza perfeitamente sem o conhecimento do particular, que é o objeto da ação,
como diz Aristóteles. Por isso a prudência supõe a memória dos fatos passados, o conhecimento dos
presentes e a previdência dos futuros, como diz Túlio. Ora, Cristo tendo tido a plenitude da prudência,
pelo dom do conselho, era consequente que conhecesse todos os particulares passados, presentes e
futuros.

## Art. 2 — Se a alma de Cristo não podia conhecer pela ciência infusa, senão servindo-se dos fantasmas.
O segundo discute-se assim. — Parece que a alma de Cristo não podia conhecer pela ciência infusa,
senão servindo-se dos fantasmas.
1 - Pois, os fantasmas estão para a alma intelectiva como as cores, para a vista, consoante o diz
Aristóteles. Ora, a potência visiva de Cristo não pedia atualizar-se senão em dependência das cores.
Logo, também a sua alma intelectiva nada podia inteligir sem recorrer aos fantasmas.

2. Demais. — A alma de Cristo tem a mesma natureza que a nossa; do contrário não seria da mesma
espécie que nós, em oposição ao dito do Apóstolo: Fez-se semelhante aos homens. Ora, a nossa alma
não pode inteligir sem se servir dos fantasmas. Logo, nem a alma de Cristo.

3. Demais. — Os sentidos foram dados ao honem para servirem ao intelecto. Se, pois, a alma de Cristo
podia inteligir sem se servir dos fantasmas, recebidos pelos sentidos, então os sentidos lhe teriam sido
inúteis, o que é inadmissível. Logo, parece que a alma de Cristo não podia inteligir senão servindo-se dos
fantasmas.

SOLUÇÃO. — Cristo, no estado anterior à paixão, tinha a sua alma unida ao corpo e simultaneamente
contemplava a essência divina, como a seguir melhor se dirá. E sobretudo, o seu corpo, pela sua
passibilidade, estava sujeito à condição do corpo mortal; ao passo que sobretudo pela sua alma
intelectiva é que estava sujeito as condições da visão. Ora, é condição da alma, que frui da visão
beatífica, não estar sujeita de modo nenhum ao corpo, nem dele depender, mas ao contrário, dominá-lo
totalmente; por isso, depois da ressurreição, a glória da alma redundará para o corpo. Ora, a alma do
homem, enquanto unida ao corpo, precisa recorrer aos fantasmas, por estar ligada a ele, e, de certo
modo, ao corpo sujeita e dele dependente. Por isso, as almas bem-aventuradas, antes e depois da
ressurreição, podem inteligir sem recorrer aos fantasmas. O que devemos dizer da alma de Cristo, que
teve na sua plenitude a faculdade da visão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A semelhança referida, de que fala o Filósofo, não é uma
semelhança total. Pois, como é manifesto, o fim da potência visiva é conhecer as cores; mas, o fim da
potência intelectiva não é conhecer os fantasmas, mas as espécies inteligíveis que apreende dos
fantasmas e nos fantasmas, no estado da vida presente. Há, pois, semelhança quanto ao referente a
uma e a outra potência, mas não quanto ao termo da condição de uma e de outra. Pois, nada impede,
segundo os estados diversos, por meios diversos tender um ente para o seu fim. Ora, o fim próprio de
um ser é só um. Por onde, embora a vista nada conheça sem a cor, contudo o intelecto, conforme o seu
estado, pode conhecer sem fantasma, mas não, sem espécie inteligível.

RESPOSTA À SEGUNDA. — Embora a obra de Cristo fosse da mesma natureza que a nossa, tinha
contudo um estado que a nossa alma atual e realmente não tem, senão só em esperança, a saber, o
estado da visão beatífica.

RESPOSTA À TERCEIRA. Embora a alma de Cristo pudesse inteligir sem recorrer aos fantasmas, podia
contudo inteligir também recorrendo a eles. Por isso não tinha em vão os seus sentidos, sobretudo
porque os sentidos não são dados ao homem só para os efeitos da ciência intelectiva, mas também para
as necessidades da vida animal.

## Art. 3 — Se a alma de Cristo tinha a ciência Infusa por via de comparação.
O terceiro discute-se assim. Parece que a alma de Cristo não tinha a ciência infusa por via de
comparação.
1 - Pois, diz Damasceno: Não atribuímos a Cristo nem conselho sem eleição. Ora, aquele e esta não se
lhe negam senão porque implicam a comparação e o discurso. Logo, parece que em Cristo não havia
ciência comparativa nem discursiva.

2. Demais. — O homem necessita da comparação e do discurso racional para inquirir o que ignora. Ora,
a alma de Cristo sabia tudo, como se disse. Logo, nele não havia ciência comparativa nem discursiva.

3. Demais. — A ciência da alma de Cristo era igual a dos que gozam da visão beatífica, como os anjos,
segundo diz o Evangelho. Ora, os anjos não têm ciência discursiva ou comparativa, como está claro em
Dionísio. Logo, nem também a alma de Cristo tinha ciência discursiva ou comparativa.
Mas, em contrário, Cristo tinha uma alma racional, como se estabeleceu. Ora, é próprio da alma racional
comparar e discorrer de um conhecimento para outro. Logo, em Cristo havia ciência discursiva ou
comparativa.

SOLUÇÃO. — Uma ciência pode ser discursiva ou comparativa de dois modos. - Primeiro, quanto à sua
aquisição, como se dá conosco que chegamos a um conhecimento por meio de outro - assim, dos
efeitos, pelas causas e inversamente. Ora, deste modo, a ciência da alma de Cristo não era discursiva ou
comparativa, pois, essa ciência inata, de que agora tratamos, foi-lhe infundida por Deus, e não adquirida
pela investigação racional. — Noutro sentido, uma ciência pode ser chamada discursiva ou comparativa,
quanto ao seu uso. Assim, às vezes, do conhecimento das causas concluímos os efeitos; e não
adquirimos assim um novo conhecimento, mas usamos de uma ciência que já possuíamos. E, deste
modo, a ciência da alma de Cristo podia ser comparativa e discursiva, pois, podia de uma conclusão
deduzir outra, como lhe aprouvesse. Assim, como se lê no Evangelho,
quando o Senhor perguntou a Pedro, de quem os reis da terra recebiam tributo se dos seus ou dos
estranhos; e como Pedro respondesse, que dos estranhos, o Senhor concluiu — Logo são isentos os
filhos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De Cristo se exclui o conselho acompanhado de dúvida;
e por consequência, a eleição, que por essência inclui um tal conselho. Mas, Cristo não estava privado
do uso do conselho.

RESPOSTA À SEGUNDA. — A referida objeção procede, quanto ao discurso e à comparação, enquanto
ordenados à aquisição da ciência.

RESPOSTA À TERCEIRA. — Os bem-aventurados são iguais aos anjos quanto aos dons das graças; mas
permanece entre eles a diferença de natureza. Por onde, usar da comparação e do discurso é conatural
às almas dos bem-aventurados; mas não, à dos anjos.

## Art. 4 — Se a ciência infusa em Cristo era menor que nos anjos.
O quarto discute-se assim. — Parece que a ciência infusa era menor em Cristo que nos anjos.

1. — Pois, a perfeição se proporciona ao perfectível. Ora, a alma humana, na ordem da natureza, é
inferior à natureza angélica. Ora, como a ciência de que agora tratamos, foi infusa na alma de Cristo,
para a perfeição deste, parece que tal ciência era inferior à ciência que é uma perfeição da natureza
angélica.

2. Demais. — A ciência da alma de Cristo era, de certo modo, comparativa e discursiva; o que não se
pode dizer da ciência angélica. Logo, a ciência da alma de Cristo foi inferior à ciência dos anjos.

3. Demais. — Quanto mais imaterial é uma ciência, tanto mais superior é. Ora, a ciência dos anjos é mais
imaterial que a da alma de Cristo; porque a alma de Cristo é um ato do corpo e se serve dos fantasmas,
o que não se pode dizer dos anjos. Logo, a ciência dos anjos é superior à da alma de Cristo.
Mas, em contrário, o Apóstolo: Mas aquele que por um pouco foi feito menor que os anjos, nós o vemos
pela paixão da morte coroado de glória e de honra. Donde resulta que, só pela paixão da morte, foi
Cristo considerado como menor que os anjos. Logo, não pela sua ciência.

SOLUÇÃO. — A ciência infusa na alma de Cristo pode ser considerada de dois modos: pelo que teve da
causa influente, de um lado, e do sujeito que a recebeu, de outro. — Ora, quanto ao primeiro, a ciência
infusa da alma de Cristo foi muito mais excelente que a dos anjos, tanto quanto ao número das coisas
conhecidas, quanto à certeza da ciência. Porque o lume espiritual infuso na alma de Cristo é muito mais
excelente que o lume pertencente à natureza angélica. — Quanto ao segundo, a ciência infusa na alma
de Cristo é inferior a ciência angélica, isto é, pelo modo de conhecer, que é natural à alma humana e o
qual se serve dos fantasmas pela comparação e pelo discurso.
Donde se deduz clara a RESPOSTA ÀS OBJEÇÕES.

## Art. 5 — Se em Cristo havia a ciência habitual.
O quinto discute-se assim. — Parece que a alma de Cristo não tinha a ciência habitual.

1. — Pois, como se disse, a alma de Cristo era ornada da máxima perfeição. Ora, maior é a perfeição da
ciência atual que a da habitual. Logo, parece que era - conveniente que soubesse tudo em ato. Portanto,
não tinha a ciência habitual.

2. Demais. — Ordenando-se o hábito para o ato, seria vã toda ciência habitual que nunca se atualizasse.
Ora, como Cristo sabia tudo, conforme se disse, não poderia considerar tudo atualmente, tendo um
conhecimento depois de outro, porque não é possível transpor o infinito enumerando-lhe as partes.
Portanto, teria Cristo em vão a ciência habitual - o que é inadmissível. Logo, tinha a ciência atual de tudo
quanto sabia e não a habitual.

3. Demais. — A ciência habitual é uma certa perfeição da ciência. Ora, a perfeição é mais nobre que o
perfectível. Se, pois, a alma de Cristo tivesse algum habitual criado, de ciência, seguir-se-ia que algo de
criado seria mais nobre que a alma de Cristo. Logo, na alma de Cristo não havia nenhuma ciência
habitual.
Mas, em contrário. — A ciência de Cristo, de que agora falamos, era unívoca com a nossa; assim como a
sua alma era da mesma espécie que a nossa. Ora, a nossa ciência é genericamente habitual. Logo,
também a de Cristo o era.

SOLUÇÃO. — Como dissemos, o modo da ciência infusa da alma de Cristo era o conveniente do sujeito
que a recebeu. Pois, o recebido está no recipiente ao modo deste. Mas o modo conatural à alma
humana é inteligir, ora, em ato e, ora, em potência. Ora. a mediedade entre a potência pura e ao ato
completo é o hábito. Mas, o meio termo e os extremos são do mesmo gênero. Por onde, é claro que o
modo conatural à alma humana é receber a ciência habitualmente. Donde devemos concluir, que a
ciência infusa na alma de Cristo era a habitual, pois, dela podia usar quando queria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na alma de Cristo havia um duplo conhecimento e,
ambos, cada um a seu modo, perfeitíssimos. — Um, excedente ao modo da natureza humana, pelo qual
contempla a essência de Deus e as mais coisas, nela. E esta, que era perfeitíssima absolutamente
falando, não era habitual, mas atual em relação a tudo o que ele desse modo conhecia. — Outro
conhecimento de Cristo era do modo proporcionado à natureza humana, enquanto conhecia as coisas
por meio de espécies nele infusas por Deus, conhecimento esse de que agora falamos. E esse
conhecimento não era perfeitíssimo, absolutamente falando, mas só no gênero do conhecimento
humano. Por onde não tinha de ser necessariamente e sempre atual.

RESPOSTA À SEGUNDA. — O hábito se atualiza pelo império da vontade; pois, é por meio do hábito que
agimos quando queremos. Ora, a vontade é indeterminada em relação a objetos infinitos. Mas nem por
isso é vã, por não tender atualmente a todos eles; contanto que tenda atualmente ao que lhe convém,
local e temporalmente. Logo, também o hábito não é inútil, embora nem tudo o que ele inclui se
atualize; contanto que se atualize o que convém ao fim devido da vontade, segundo as exigências das
situações e do tempo.

RESPOSTA À TERCEIRA. — O bem e o ser se tomam em dupla acepção. — Numa, absoluta. E assim a
substância, subsistente no seu ser e na sua bondade, é chamada uma substância. — Noutra, o ser e o
bem o são relativamente. E, nesse sentido, é considerado ser e bem o acidente; não que por si mesmo
tenha o ser a bondade mas porque o seu sujeito é ser e bom. E assim, pois, a ciência habitual não é
absolutamente falando, melhor ou mais digna que a alma de Cristo; mas o é, relativamente considerada,
porque toda a bondade habitual da ciência redunda em vantagem do sujeito.

## Art. 6 — Se a alma de Cristo só tinha um hábito de ciência.
O sexto discute-se assim. — Parece que a alma de Cristo tinha só um hábito de ciência.

1. — Pois, quanto mais a ciência é perfeita tanto mais una é; por isso os anjos superiores conhecem
mediante formas mais universais, como se disse na Primeira Parte. Ora, a ciência de Cristo era
perfeitíssima. Logo, una por excelência. Portanto não se distinguia por muitos hábitos.

2. Demais. — A nossa fé deriva da ciência de Cristo, como diz o Apóstolo: Pondo os olhos no autor e
consumador da fé; Jesus. Ora, há um só hábito da fé para todas as coisas que ela faz crer, como se disse
na Segunda Parte. Logo, com maior razão, Cristo só tinha um hábito da ciência.

3. Demais. — As ciências se distinguem pela diversidade formal dos seus objetos, Ora, a alma de Cristo
sabia tudo por uma só razão formal - o lume infuso por Deus. Logo, em Cristo só havia um hábito de
ciência.
Mas, em contrário, a Escritura diz que, sobre uma pedra única, isto é, Cristo, estão sete olhos. E por
olhos se entende a ciência. Logo em Cristo havia muitos hábitos de ciência.

SOLUÇÃO. — Como se disse, a ciência infusa na alma de Cristo assumia um modo conatural à alma
humana. Ora, é conatural à alma humana receber as espécies em menor universalidade que o anjo, de
modo que conheça diversas naturezas especificas mediante diversas espécies inteligíveis. Donde vem
que há em nós diversos hábitos de ciência, por haver diversos gêneros de cognoscíveis; isto é, enquanto
que tudo o que está compreendido num mesmo gênero é conhecido pelo mesmo hábito de ciência;
assim, como diz Aristóteles, a ciência é una quando pertence ao mesmo gênero do sujeito. Logo, a
ciência infusa da alma de Cristo distinguia-se conforme a diversidade dos hábitos

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como se disse, a ciência da alma de Cristo é
perfeitíssima e excede à ciência dos anjos, si considerarmos nele o que procede da influência de Deus;
mas é inferior à ciência angélica quanto ao modo do sujeito recipiente. E é fundada nesse modo que a
sua ciência se distingue por muitos hábitos, como existindo por espécies mais particulares.

RESPOSTA À SEGUNDA. — A nossa fé se baseia na Verdade primeira. Por onde, Cristo é o autor da nossa
fé, pela sua ciência divina, una, absolutamente falando.

RESPOSTA À TERCEIRA. — O lume infuso da divindade é a razão comum de inteligir o que é revelado por
Deus; assim como o lume do intelecto, o de inteligir o que naturalmente conhecemos. Por onde, é
necessário atribuir à alma de Cristo espécies próprias das coisas particulares, para que conhecesse cada
uma delas por um conhecimento próprio. E, assim sendo, era necessário tivesse a alma de Cristo
diversos hábitos de ciência, como se disse.