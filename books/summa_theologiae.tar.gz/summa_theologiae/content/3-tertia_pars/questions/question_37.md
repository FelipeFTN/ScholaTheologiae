# Questão 37: Da circuncisão de Cristo
Em seguida devemos tratar da circuncisão de Cristo. E como a circuncisão é uma profissão da lei a ser
observada, segundo àquilo do Apóstolo — Protesto a todo o homem, que se circuncida, que está
obrigado a guardar toda a lei — devemos tratar ao mesmo tempo das outras prescrições legais
observadas a respeito do menino Jesus.
Donde quatro artigos a serem discutidos:

## Art. 1 — Se Cristo devia ser circuncidado.
O primeiro discute-se assim. — Parece que Cristo não devia ser circuncidado.

1. — Pois, a realização da verdade elimina o que a prefigurava. Ora, a circuncisão foi ordenada a Abraão
como sinal da aliança que devia provir da sua raça, como se lê na Escritura. Ora, essa aliança se cumpriu
com a natividade de Cristo. Logo, devia ter feito desde logo cessar a circuncisão.

2. Demais. — Toda ação de Cristo serve de instrução para nós. Donde o dizer o Evangelho: Eu dei-vos o
exemplo, para que como eu vos fiz, assim façais vós também. Ora nós não devemos ser circuncidados,
conforme ao dito do Apóstolo: Se vos faz eis circuncidar, Cristo vos não aproveitará nada. Logo, parece
que também Cristo não devia ser circuncidado.

3. Demais. — A circuncisão foi ordenada como remédio do pecado original. Ora, Cristo não contraiu o
pecado original, como do sobredito resulta. Logo, Cristo não devia ser circuncidado.
Mas, em contrário, o Evangelho: Depois que foram cumpridos os oito dias para ser circuncidado o
menino.

SOLUÇÃO. — Por várias causas Cristo devia ser circuncidado. — Primeiro, para demonstrar que se tinha
verdadeiramente encarnado, contra Maniqueu, que dizia ter sido fantástico o corpo de Cristo; e contra
Apolinário, que dizia ser o corpo de Cristo consubstancial com a divindade; e contra Valentiniano, que
dizia ter Cristo trazido do céu o seu corpo. — Segundo, para que aprovasse a circuncisão, que Deus
outrora instituíra. — Terceiro, para provar que era da raça de Abraão, que recebera o mandado de
circuncisão em sinal da fé que tinha na vinda de Cristo. — Quarto, para tirar aos judeus a ocasião de não
o receberem, se fosse incircunciso. — Quinto, para os recomendar, com o seu exemplo, a virtude da
obediência. Por isso foi circuncidado no oitavo dia, como estava preceituado na lei. — Sexto, para que,
quem se revestiu da semelhança da carne de pecado, não rejeitasse o remédio habitual de purificar essa
carne pecaminosa. — Sétimo, para que, suportando sobre si todo o peso da lei, nos libertasse dele,
segundo àquilo do Apóstolo: Enviou Deus a seu Filho feito sujeito à lei; a fim de servir aqueles que
estavam debaixo da lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A circuncisão, feita pela remoção deuma película carnal
no membro da geração, significava a liberação da antiga geração, da qual nos libertamos pela paixão de
Cristo. Por onde, a verdade dessa figura não foi plenamente realizada na natividade de Cristo; mas na
sua paixão, antes da qual a circuncisão tinha a sua virtude e a sua razão de ser. Por isso convinha Cristo,
antes da sua paixão, ser circuncidado, como filho de Abraão.

RESPOSTA À SEGUNDA. — Cristo recebeu a circuncisão no tempo em que ela era de preceito. Por onde,
a sua ação devemos nós imita-la, observando o que em nosso tempo é de preceito; pois, todas as coisas
têm seu tempo e sua oportunidade, como diz a Escritura.
Além disso, diz Orígenes: Assim como morremos com a morte de Cristo e ressurgimos com a sua
ressurreição, assim também por Cristo recebemos a circuncisão espiritual. Por isso não precisamos da
circuncisão carnal. E tal é o que diz o Apóstolo: Nele, isto é, em Cristo, é que vós estais circuncidados de
circuncisão não feita por mão de homem no despojo do corpo da carne, mas sim na circuncisão de
Cristo"

RESPOSTA À TERCEIRA. — Cristo, que não tinha nenhum pecado sofreu por nós, de vontade própria, a
morte, que é o efeito do pecado, para nos livrar dela e fazer-nos morrer espiritualmente para o pecado.
Assim também sujeitou-se à circuncisão, remédio do pecado original, sem que tivesse esse pecado, para
nos livrar dojugo da lei e produzirem nós a circuncisão espiritual, de modo que realizasse a verdade,
abolindo a figura.

## Art. 2 — Se foi imposto a Cristo o nome conveniente.
O segundo discute-se assim. — Parece que não foi imposto a Cristo o nome conveniente.

1. — Pois, a verdade evangélica deve ser a realização do que foi profetizado. Ora, os profetas
prenunciaram outro nome, de Cristo. Assim, Isaías diz: Eis que uma virgem conceberá e parirá um filho e
será chamado o seu nome Emanuel. E noutro lugar: Põe-lhe por nome — Apressa-te a tirar os despojos,
faze velozmente a presa. Ainda noutro: O nome com que se apelide será — Admirável, Conselheiro.
Deus, Forte, Pai do futuro século, Príncipe da Paz. E Zacarias diz: Eis aqui o homem que tem por nome o
Oriente. Logo. Cristo foi inconvenientemente chamado Jesus.

2. Demais. — A Escritura diz: Chamar-te-ão por um nome novo, que o Senhor nomeará pela sua boca.
Ora, o nome de Jesus não é um nome novo, mas foi imposto a muitos na vigência do Velho Testamento,
como se vê também na genealogia de Cristo. Logo, parece que lhe foi inconvenientemente posto o
nome de Jesus.

3. Demais. — O nome de Jesus significa salvação, como se lê no Evangelho: Ela parirá um filho e lhe
chamarás por nome Jesus, por que ele salvará o seu povo dos pecados deles. Ora, a salvação por Cristo
não se realizou só na circuncisão, mas também no prepúcio, como está claro no Apóstolo. Logo, foi-lhe
imposto a Cristo, na sua circuncisão, um nome impróprio.
Mas, em contrário, a autoridade da Escritura, que diz: Depois que foram cumpridos os oito dias para ser
circuncidado o menino, foi-lhe posto o nome de Jesus.

SOLUÇÃO. — Os nomes devem cor responder às propriedades das causas. Assim o demonstram os
nomes dos gêneros e das espécies; pois, como ensina Aristóteles, a essência significada pelo nome é a
definição que designa a natureza própria do ser. Ora, a cada pessoa impomos seu nome fundado em
alguma propriedade dela. Quer em virtude do tempo, como quando se dá a alguém o nome do santo do
dia em que nasceu. Ou em virtude do parentesco, como quando se impõe ao filho o nome do pai ou de
algum parente; assim, os parentes de João Batista queriam dar-lhe o nome do pai, Zacarias, e não o de
João, porque ninguém havia na sua geração que tivesse esse nome. Ou ainda em virtude de um
acontecimento; assim, José chamou ao seu primogênito Manassés, dizendo: Deus me fez esquecer de
todos os meus trabalhos. Ou também por causa de alguma qualidade daquele a quem se impõe o nome;
assim, como se lê na Escritura, o que saiu primeiro do ventre materno era vermelho e todo áspero a
modo de uma pele; e foi-lhe imposto o nome de Esaú, -que significa vermelho. — Quanto aos nomes
impostos por inspiração divina, sempre significam algum dom gratuito dado por Deus; assim, foi dito a
Abraão: Chamar-te-ás Abraão, porque eu te tenho destinado para pai de muitas gentes. E o Evangelho
diz, de Pedra: Tu és Pedra e sobre esta pedra edificarei a minha Igreja. — Ora, como a Cristo foi
conferido o dom da graça pelo qual foi constituído o Salvador de todos, foi convenientemente chamado
Jesus, isto é, Salvador; tendo o anjo anunciado esse nome, não só à mãe, mas também a José, que lhe
havia de ser o pai putativo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todos esses nomes referidos significam de certo modo o
nome de Jesus, que implica a idéia de salvação. Assim, o nome de Emanuel, que significa — Deus
conosco, designa a causa da salvação, que é a união da natureza divina com a humana na pessoa do
Filho de Deus, em virtude da qual Deus esteve conosco. — Quanto ao lugar da Escritura — Põe-lhe por
nome, apressa-te a tirar os despojos, etc., designa de que nos salvou, a saber, do diabo, cujos despojos
arrebatou, segundo àquilo do Apóstolo: Despojando os principados e potestades, os trouxe
confiadamente. Quanto à outra — O nome com que se apelide será admirável, etc., designa a via e o
termo da nossa salvação, pois é pela admirável sabedoria de Deus e pela sua força que alcançaremos a
herança do século futuro, em que gozaremos da paz perfeita dos filhos de Deus, sob a chefia do próprio
Deus. — Quanto enfim ao dito — Eis aqui o homem que tem por nome o Oriente — refere-se ao mesmo
que a primeira denominação. isto é ao mistério da Encarnação, pois, como diz a Escritura, nas trevas
nasceu a luz dos retos.

RESPOSTA À SEGUNDA. — Aos que viveram antes de Cristo podia convir-lhes o nome de Jesus por
alguma outra razão; por exemplo, por terem sido causa de alguma salvação particular e temporal. Mas,
por causa da salvação espiritual e universal, esse nome é próprio a Cristo. Por isso é que se diz ser um
nome novo.

RESPOSTA À TERCEIRA. — Como se lê na Escritura, Abraão recebeu simultaneamente de Deus a
imposição do nome e a ordem da circuncisão. Por isso era costume entre os Judeus impor um nome à
criança no dia mesmo da circuncisão, como por não ter ainda o seu ser perfeito, antes de circuncisa;
assim como agora impomos à criança o nome no batismo. Donde, àquilo da Escritura — Eu também fui
filho de meu pai, tenrinho e unigênito de minha mãe. — diz a Glosa: Porque se chama Salomão
unigênito diante de sua mãe, quando a Escritura nos informa que foi precedido de um irmão uterino,
senão porque este, morto logo depois de nascido e sem nome, era como se nunca tivesse existido? Por
isso Cristo, simultaneamente com a circuncisão, recebeu a imposição do nome.

## Art. 3 — Se Cristo foi convenientemente oferecido no Templo.
O terceiro discute-se assim. — Parece que Cristo não foi convenientemente oferecido no Templo.

1. — Pois, diz a Escritura: Consagra-me todos os primogênitos, que abrem o útero de sua mãe entre os
filhos de Israel. Ora, Cristo veio ao mundo sem detrimento da virgindade de sua mãe, que portanto deu
à luz por um parto miraculoso. Logo, em virtude da lei referida, Cristo não devia ser oferecido no
Templo.

2. Demais. — O que está sempre presente a alguém não lhe pode ser apresentado. Ora, a humanidade
de Cristo era por excelência sempre presente a Deus, como sempre unida com ela pela unidade de
pessoa. Logo, não era necessário que Cristo fosse apresentado ao Senhor.

3. Demais. — Cristo é a hóstia principal a quem se referem todas as hóstias da lei antiga, como a figura
se refere à verdade. Ora, uma hóstia não deve ser referida a outra. Logo, não foi conveniente que por
Cristo se oferecesse outra hóstia.

4. Demais. — Entre as vítimas legais a principal era o cordeiro, que constituía um sacrifício perpétuo. Por
isso Cristo é também chamado Cordeiro no Evangelho: Eis o Cordeiro de Deus. Logo, era mais
conveniente fosse oferecido por Cristo um cordeiro do que um par de rolas ou dois pombinhos.
Mas, em contrário, a autoridade da Escritura, que atesta o fato.

SOLUÇÃO. — Como se disse, Cristo quis submeter-se à lei, a fim de remir aqueles que estavam debaixo
da lei; e para que a justificação da lei se cumprisse espiritualmente nos seus membros. Ora, sobre os
filhos recém-nascidos há na lei um duplo preceito. — Um geral, abrangendo a todos, pelo qual, depois
de completos os dias da purificação da mãe, fosse oferecido um sacrifício pelo filho, ou pela filha, como
se lê na Escritura. E esse sacrifício era em expiação do pecado, no qual a prole foi concebida e nascida; e
também para a consagração do recém-nascido, que era então pela primeira vez apresentado no
Templo. Por isso, fazia-se uma oferenda em holocausto e outra pelo pecado. — O outro preceito da lei
era especial, sobre os primogênitos, tanto dos homens como dos animais. Pois, o Senhor se reservou
todos os primogênitos em Israel, porque, para a libertação do povo de Israel matara os primogênitos do
Egito, desde os homens até aos animais, excetuados os primogênitos dos filhos de Israel. E esse
mandamento se lê na Escritura. O que também prefigurava a Cristo, que é o primogênito entre muitos
irmãos. — E como Cristo, nascida de uma mulher, era quase primogênito, e quis sujeitar-se à lei, o
evangelista Lucas nos mostra que esses dois preceitos foram observados a respeito dele. Primeiro, o
atinente aos primogênitos, quando diz: Levaram-no a Jerusalém para o apresentarem ao Senhor;
segundo o que está escrito na lei do Senhor: Todo filho macho que for primogênito será consagrado ao
Senhor. — Segundo o que se aplica em geral a todos, quando diz: E para oferecerem em sacrifício,
conforme ao que está mandado na lei do Senhor, um par de rolas ou dois pombinhos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz Gregório Nisseno: Esse preceito da lei se cumpriu, de
maneira singular e diferentemente do que o cumpriam os outros, só com Deus encarnado. Pois, só ele,
concebido de um modo inefável e dado à luz de maneira incompreensível, saiu do ventre virginal de sua
mãe, que antes não conhecera a relação conjugal e conservou inviolavelmente depois do parto os
atributos da sua virgindade. E assim, a expressão da Escritura — adaperiens vulvam — significa que o
parto virginal de Maria foi o primeiro e único. E por isso também especialmente a Escritura diz —
masculino: porque não teve nenhum contágio da culpa da mulher. E ainda, singularmente santo: porque
pela singularidade do seu parto imaculado não sofreu qualquer contágio da corrupção terrena.

RESPOSTA À SEGUNDA. — Assim como o Filho de Deus não se fez homem nem foi circuncidado na sua
carne por causa de si mesmo, mas para nos divinizar pela graça e nos circuncidar espiritualmente, assim
por nossa causa foi oferecido ao Senhor, para aprendermos a nos oferecermos nós mesmos a Deus. E
isso se fez depois da sua circuncisão, para mostrar que ninguém, se não se circuncidar aos vícios, é digno
de ver a Deus.

RESPOSTA À TERCEIRA. — Aquele que era a verdadeira vítima quis que por si se oferecesse as hóstias
da lei, para ficar a figura unida à realidade e por esta ficar demonstrada aquela. Contra aqueles que
negam ter Cristo pregado no Evangelho o Deus da lei: Pois, como diz Orígenes, não devemos pensar que
o Deus bom sujeitou o seu Filho a lei do inimigo, a qual não tivesse ele mesmo jeito.

RESPOSTA À QUARTA. — A Escritura ordena que quem pudesse oferecesse, por filho ou por filha,
simultaneamente com um cordeiro um pombinho ou uma rola; os que porém não tivessem nas suas
posses nem pudessem oferecer um cordeiro, oferecessem duas rolas ou dois pombinhos. Porque, como
diz o Apóstolo, o Senhor que, sendo rico, se fez pobre por nosso amor, a fim de que nós fôssemos ricos
pela sua pobreza, quis que se lhe fizesse a oferta dos pobres; assim como, na sua natividade foi envolto
em panos e reclinado no presépio. - Nem por isso, contudo essas aves deixavam de se adaptar ao que
figuravam. Assim, a rola, ave gárrula, significa a pregação e a confissão da fé; mas por ser casta, exprime
a castidade; e enfim, por ser solitária, é o símbolo da contemplação. Por seu lado, a pomba, mansa e
simples, figura por isso a mansidão e a simplicidade. É também ave gregária, símbolo da vida ativa. Por
onde, tais vítimas figuravam a perfeição de Cristo e a dos seus membros. Pois, ambas essas aves, pelo
costume que têm de gemer, simbolizam as lágrimas dos santos nesta vida; mas a rola, como solitária,
significa as lágrimas da oração; ao passo que a pomba, que é gregária, exprime as orações públicas da
Igreja. - E tanto uma como outra eram oferecidas em dobro, para significar que a santidade deve ser,
não só do corpo, mas também da alma.

## Art. 4 — Se à Mãe de Deus era conveniente se apresentasse no Templo para purificar-se.
O quarto discute-se assim. — Parece que não devia a Mãe de Deus apresentar-se no Templo para
purificar-se.

1. — Pois, de purificação só precisa o que é impuro. Ora, a Santa Virgem não tinha nenhuma Impureza,
como do sobredito se colhe, Logo, não devia ir ao Templo purificar-se.

2. Demais. — A Escritura diz: Se uma mulher, tendo concebido de varão, parir macho, será imunda sete
dias. E por isso lhe ordena que não entrará no santuário até se acabarem os dias da sua purificação. Ora,
a Santa Virgem deu à luz um filho, conservando íntegra a sua virgindade. Logo, não devia ir ao Templo
purificar-se.

3. Demais. — A purificação de uma impureza só é possível pela graça. Ora, os sacramentos da lei antiga
não conferiam a graça; antes, Maria é que trazia em si o autor da graça. Logo, não era necessário fosse a
Santa Virgem ao Templo purificar-se.
Mas, em contrário, a autoridade da Escritura, quando diz que foram concluídos os dias da purificação de
Maria, segundo a lei de Moisés.

SOLUÇÃO. — Assim como a plenitude da graça derivou de Cristo para a sua mãe, assim convinha que a
mãe se assemelhasse ao seu filho humilhado, pois. Deus dá a sua graça aos humildes, como diz a
Escritura. Por onde, assim como Cristo, embora não estivesse sujeito à lei, quis contudo sofrer a
circuncisão e as outras exigências legais, para nos ser um exemplo de humildade e de obediência, dar a
sua aprovação à lei e tirar aos Judeus a ocasião de caluniá-Io, por essas mesmas razões quis que sua mãe
se submetesse às observâncias da lei, à qual contudo não estava sujeita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a Santa Virgem não tivesse nenhuma impureza,
quis contudo observar o preceito da purificação; não porque o precisasse, mas por ser uma disposição
legal. Por Isso, o Evangelho diz sinaladamente, que foram concluídos os dias da sua purificação, segundo
a lei; pois, em si mesma, não precisava purificar-se.

RESPOSTA À SEGUNDA. — Moisés, se referiu sinaIadamente à Mãe de Deus, como Isenta de qualquer
impureza; pois, ela não deu à luz, tendo concebido de varão. Por onde é claro, que não estava obrigada
a observar o referido preceito, mas cumpriu voluntariamente a disposição legal sobre a purificação,
como dissemos.

RESPOSTA À TERCEIRA. — Os sacramentos da lei não purificavam; impureza da culpa, purificação que é
obra da graça, mas prefiguravam essa purificação. Pois, só purificavam, por uma purificação puramente
corpórea, da impureza de uma certa irregularidade, como se disse na Segunda Parte. Ora, nem uma
nem outra impureza a Santa Virgem contraiu. Logo, não precisava de purificar-se.