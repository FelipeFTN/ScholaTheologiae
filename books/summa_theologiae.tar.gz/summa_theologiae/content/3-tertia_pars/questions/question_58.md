# Questão 58: De Cristo sentado à direita do Pai
Em seguida devemos tratar de Cristo enquanto sentado à direita do Pai.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se deve Cristo sentar-se à direita de Deus Padre.
O primeiro discute-se assim. — Parece que não deve Cristo sentar-se à direita de Deus Padre.

1. — Pois, à direita e a esquerda são diferentes posições dos corpos. Ora, a Deus nada de corpóreo
convém, como diz o Evangelho. Logo parece que Cristo não está sentado à direita do Pai.

2. Demais. — Quem se assenta àdireita de outrem tem-no a esse à esquerda. Se, pois, Cristo está
sentado à direita do Padre resulta que o Padre está sentado àesquerda de Cristo – o que é
inconveniente.

3. Demais. — Sentar e estar de pé entre si se opõem. Ora, Estevam diz: Eis estou eu vendo os céus
abertos e o Filho do homem que está em pé à direita de Deus. Logo, parece que Cristo não está sentado
à direita do Padre.
Mas, em contrário, o Evangelho: Na realidade o Senhor Jesus, depois de assim lhes haver falado, foi
assunto ao céu, onde está assentado à mão direita de Deus.

SOLUÇÃO. — Pela expressão — estar sentado podemos entender duas coisas: o repouso, segundo
aquilo do Evangelho - Ficai de assento na cidade; e também o poder real ou judiciário, segundo aquele
outro lugar - O rei que está assentado no seu trono de justiça, dissipa todo o mal só com o seu olhar.
Ora, de ambos os modos convém a Cristo estar sentado à direita do Pai. — Primeiro, enquanto
permanece eternamente incorruptível na beatitude do Pai, denominada à sua direita, segundo a
Escritura: Deleitações à tua direita para sempre. Por isso diz Agostinho: Está sentado à direita do Pai.
Estar sentado significa habitar, no sentido em que dizemos de alguém — habita naquela terra há três
anos. Por estar, pois, Cristo sentado à direita do Padre, entendei que é bem-aventurado, sendo a dextra
do Padre o nome da sua felicidade. - De outro modo dizemos que Cristo está sentado à direita do Pai,
porque reina com ele, recebendo dele o seu poder de julgar; assim como quem se senta à direita do rei
assiste-o nas suas funções de reinar e julgar. Donde o dizer Agostinho: Pela direita entendei o poder que
Cristo homem recebeu de Deus, a fim de vir a julgar quem veio antes a ser julgado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como ensina Damasceno, não supomos um lugar
material quando falamos na direita do Pai. Pois, como poderia ocupar a direita, enquanto lugar, aquele
que é incircunscriptível? Porque direita e esquerda, materialmente falando, são propriedades dos seres
circunscriptíveis. Por onde, o que entendemos pela direita do Padre é a glória e a honra da divindade.

RESPOSTA À SEGUNDA. — A objeção colhe, entendendo-se que Cristo está materialmente sentado à
direita do Padre. Por isso diz Agostinho: Se entendermos que Cristo está corporalmente sentado à
direita do Pai, então lhe estará à esquerda. Pois, lá, isto é, na bem-aventurança eterna, só há direita,
porque não existe aí nenhuma miséria.

RESPOSTA À TERCEIRA. — Diz Gregório: Estar sentado é próprio do juiz, ao passo que estar de pé o é de
quem combate ou serve. Por isso Estevam, no meio dos trabalhos da luta, viu de pé quem o fortalecia.
Marcos, porém refere que o viu sentado depois da ascensão; porque o juiz será visto ao fim, depois da
glória da sua ascensão.

## Art. 2 — Se estar sentado à direita do Padre convém a Cristo enquanto Deus.
O segundo discute-se assim. — Parece que estar sentado à direita do Padre não convém a Cristo
enquanto Deus.

1. — Pois Cristo, enquanto Deus é à direita do Padre. Ora, ser a direita de alguém e estar-lhe sentado à
direita não é o mesmo. Logo, Cristo, enquanto Deus, não está sentado à direita do Padre.

2. Demais. — O Evangelho diz: O Senhor Jesus foi assunto ao céu onde está sentado à mão direita de
Deus. Ora, Cristo não foi assunto do céu enquanto Deus. Logo, também não é como Deus que está
sentado à direita de Deus.

3. Demais. — Cristo, enquanto Deus é igual ao Padre e ao Espírito Santo. Logo, se Cristo, enquanto Deus,
está sentado à direita do Padre, pela mesma razão o Espírito Santo estará sentado à direita do Pai e do
Filho; e o próprio Pai, à direita do Filho. O que não se lê em nenhum lugar da Escritura.
Mas, em contrário, diz Damasceno: Chamamos direita do Padre à glória e às honras da divindade, onde
o Filho de Deus tem o seu lugar antes de todos os séculos como Deus e consubstancial com o Pai.

SOLUÇÃO. — Como do sobredito se colige, ao vocábulo — direita — podemos atribuir três sentidos:
primeiro, conforme Damasceno, a glória da divindade; segundo, de acordo com Agostinho, a beatitude
do Padre; terceiro, ainda de acordo com o mesmo, o poder judiciário. Ora, o fato de estar sentado,
como se disse, designa uma habitação, ou uma dignidade régia ou judiciária. Por onde, estar sentado à
direita do Padre outra causa não é senão participar simultaneamente com ele da glória da divindade, da
beatitude e do poder judiciário, e isso de modo imutável e como rei. Ora, isso convém ao Filho enquanto
Deus. Por onde, é manifesto que Cristo, enquanto Deus, está sentado àdireita do Padre: contanto que a
preposição a, (ad) que é transitiva, signifique a ordem da origem, e não o grau de natureza ou de
dignidade, que nenhum existe nas Pessoas divinas, como estabelecemos na Primeira Parte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filho de Deus é chamado a direita do Padre em
sentido próprio, do mesmo modo por que também é chamado a virtude do Pai. Ora, a direita do Padre,
nas três significações supra-referidas, é algo de comum às três Pessoas.

RESPOSTA À SEGUNDA. — Cristo, enquanto homem foi assunto à honra divina, que supõe o fato de
estar sentado àdireita do Padre. Contudo, essa honra convém por disposição divina, a Cristo enquanto
Deus, não em virtude de qualquer assunção, mas pela origem eterna.

RESPOSTA À TERCEIRA. — De nenhum modo podemos dizer que o Padre está sentado àdireita do Filho
ou do Espírito Santo; porque o Filho e o Espírito Santo tiram a sua origem do Pai e não inversamente.
Mas o Espírito Santo podemos propriamente dizer, que está sentado à direita do Pai ou do Filho, no
sentido referido; embora por uma certa apropriação o estar sentado seja atribuído ao Filho, de quem é
próprio a igualdade; porque, como dizAgostinho, ao Padre é própria a unidade, ao Filho a igualdade e ao
Espírito Santo a conexão entre a unidade e a igualdade.

## Art. 3 — Se estar sentado à direita do Padre convém a Cristo enquanto homem.
O terceiro discute-se assim. — Parece que estar sentado àdireita do Padre não convém a Cristo
enquanto homem.

1. — Pois, como diz Damasceno, chamamos direita do Padre à glória e às honras da divindade. Ora, a
glória e as honras da divindade não convém a Cristo enquanto homem. Logo parece que Cristo,
enquanto homem, não está sentado à direita do Pai.

2. Demais. — O fato de estar sentado àdireita de quem reina parece que exclui a sujeição; porque o
sentado àdireita de quem reina de certo modo reina com ele. Ora, Cristo enquanto homem, está sujeito
ao Pai, segundo o Apóstolo. Logo, parece que Cristo, enquanto homem, não está sentado à direita do
Pai.

3. Demais. — Aquilo do Apóstolo - Que está à mão direita de Deus, diz a Glosa: isto é, igual ao Pai pela
honra em virtude da qual o Pai é Deus; ou, à direita do Pai. isto é, participante dos mais elevados dons
de Deus. E àquele outro lugar: Está sentado à direita da majestade nas alturas. comenta: isto é. como
tendo a igualdade com o Padre. acima de iodos os seres, pelo lugar e pela dignidade. Ora. ser igual a
Deus não convém a Cristo enquanto homem, pois nessa qualidade, ele próprio o disse: O Pai é maior do
que eu. Logo, parece que estar sentado à direita do Pai não convém a Cristo enquanto homem.
Mas, em contrário, diz Agostinho: Pela direita entendei o poder que tinha Cristo, recebido de Deus, pelo
qual virá a julgar, ele que viera para ser julgado.

SOLUÇÃO. — Como dissemos pela direita do Padre entende-se ou a glória mesma de Cristo, ou a sua
bem-aventurança eterna ou o seu poder judiciário e real. Pois a preposição - a - designa de certo modo
o acesso à direita, o que implica a conveniência com uma certa distinção, como se disse. O que de três
modos pode ser. — Primeiro, sendo a conveniência da natureza e a distinção da pessoa. E assim, Cristo,
como Filho de Deus está sentado àdireita do Padre porque tem a mesma natureza que ele. Por onde, a
conveniência e a distinção referidas cabem essencialmente tanto ao Filho como ao Pai. E isso é ter o
Filho a igualdade com o Pai. — De outro modo, pela graça da união; e esta implica, ao inverso, a
distinção de natureza e a unidade de pessoa. E, por aí, Cristo, enquanto homem, é o Filho de Deus e, por
consequência, está sentado àdireita do Pai; mas de modo que a expressão enquanto não designe a
condição da natureza, mas a unidade do suposto como já expusemos. — Em terceiro sentido, o referido
acesso pode ser entendido segundo a graça habitual, mais abundante em Cristo que em todas as demais
criaturas por ter a natureza humana de Cristo, em si mesma maior beatitude que a das outras criaturas:
e por ter ainda sobre todas o poder real e judiciário.
Assim, pois, a expressão enquanto, designando a condição da natureza, Cristo, enquanto Deus, está
sentado à direita do Padre, isto é, tem igualdade com o Padre. Mas, enquanto homem, está sentado
àdireita do Padre, isto é, participa dos bens paternos mais elevados que os de todas as criaturas, isto é,
tem uma beatitude maior e exerce o poder judiciário. Se porém — enquanto — designa a unidade de
suposto, então também, enquanto homem, está sentado à direita do Padre, pela igualdade de honras,
isto é, enquanto que em nossa veneração atribuímos as mesmas honras ao Filho de Deus e à natureza
assumida como dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A humanidade de Cristo, segundo as condições da sua
natureza, não tem a glória ou as honras da divindade; tem-nas porém, em razão da pessoa a que está
unida. Por isso Damasceno acrescenta no mesmo lugar: Dela, isto é, da glória da divindade, o Filho de
Deus frui, antes de todos os séculos, enquanto Deus; e, com a sua carne glorificada, está sentado à
dextra do Pai com quem é consubstancial. Assim, todas as criaturas lhe atribuem a mesma adoração,
como Deus e homem.

RESPOSTA À SEGUNDA. — Cristo, enquanto homem está sujeito ao Padre, designando - enquanto - a
condição da natureza. E, assim não lhe cabe estar sentado à direita do Padre, por uma razão de
igualdade que, como homem, não lhe assiste. Mas, cabe-lhe estar sentado à direita do Padre,
entendendo-se por isso a excelência de beatitude e o seu poder judiciário sobre todas as criaturas.

RESPOSTA À TERCEIRA. — Fruir da igualdade com o Padre não convém à natureza humana de Cristo em
si mesma, senão só à pessoa assumente. Mas, participar dos dons mais elevados de Deus, enquanto
excedentes às demais criaturas, isso o pode a natureza assumida, em si mesma.

## Art. 4 — Se estar sentado à direita do Padre é próprio de Cristo.
O quarto discute-se assim. — Parece que estar sentado à direita do Padre não é próprio de Cristo.

1. — Pois, diz o Apóstolo: Deus nos ressuscitou e nos fez assentar nos céus com Jesus Cristo. Ora, ser
ressuscitado não convém a Cristo. Logo, nem, pela mesma razão, estar sentado à direita de Deus, nas
alturas.

2. Demais. — Como diz Agostinho, o estar Cristo sentado à direita do Padre é participar-lhe da
beatitude. Ora isso o podem muitas criaturas. Logo, parece que estar sentado à direita do Padre não é
próprio de Cristo.

3. Demais. — O próprio Cristo disse: Aquele que vencer eu o farei assentar comigo no meu trono, assim
como eu mesmo, também depois que venci, me assentei igualmente com meu Pai no seu trono. Ora,
Cristo está sentado à direita do Padre por lhe estar sentado no trono. Logo, também os outros que
vencem estão sentados à direita do Padre.

4. Demais. — O Senhor diz: Terdes assento à minha mão direita ou à esquerda não me pertence a mim o
dar-vo-lo, mas isso é para quem está preparado por meu Pai. Ora, tê-Ia-ia dito em vão se isso a ninguém
estivesse preparado. Logo, estar sentado à direita do Padre não convém só a Cristo.
Mas, em contrário, o Apóstolo pergunta: A qual dos anjos disse alguma vez - Senta-te àminha direita,
isto é, participa dos meus melhores bens, ou se o meu igual pela divindade? E como que responde: A
nenhum. Ora, os anjos são superiores às outras criaturas. Logo, com maior razão, a ninguém mais, senão
a Cristo, convém ter assento à direita do Pai.

SOLUÇÃO. — Como explicamos, dizemos que Cristo está sentado à direita do Padre, por ser igual a ele,
pela sua natureza divina; e, pela sua natureza humana, frui de modo excelente, mais que qualquer outra
criatura, dos bens divinos. Ora, uma e outra causa só a Cristo compete. Por onde, ninguém mais, nem
anjo nem homem, pode sentar-se à direita do Padre, senão Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Sendo Cristo a nossa cabeça, tudo o que lhe é conferido,
também a nós o é por meio dele. E por isso, tendo já ressuscitado, diz o Apóstolo que de certo modo
nos ressuscitou consigo, que contudo ainda não ressuscitamos, mas havemos de ressuscitar, segundo
aquilo do Apóstolo: Aquele que ressuscitou dos mortos a Jesus Cristo também dará vida aos vossos
corpos mortais. E, conforme do mesmo modo de exprimir-se, acrescenta que nos fez assentar nos céus,
isto é, pelo fato mesmo de aí estar sentado Cristo, nossa cabeça.

RESPOSTA À SEGUNDA. — Sendo a direita a felicidade divina, estar sentado àdireita não significa
somente gozar da felicidade mas fruí-la, de certo modo com poder dominical, como própria e natural. O
que só a Cristo convém, e a nenhuma outra criatura. — Podemos porém dizer, quetodo santo que goza
da bem-aventurança está constituído à direita de Deus. Por isso diz o Evangelho: Porá as ovelhas
àdireita.

RESPOSTA À TERCEIRA. — Trono, no lugar aduzido, significa o poder judiciário que Cristo tem, do Padre.
E nesse sentido se diz que está sentado no trono do Pai. Os outros santos, porém, recebem o poder
judiciário, de Cristo. E nessa acepção se diz que estão sentados no trono de Cristo conforme aquilo do
Evangelho: Bastareis sentados sobre doze tronos e julgareis as doze tribos de Israel.

RESPOSTA À QUARTA. — Como explica Crisóstomo, esse lugar, isto é, o de quem está sentado à direita,
é inacessível a todos, não só aos homens, mas também aos anjos. Pois, Paulo nos mostra o privilégio do
Unigênito quando pergunta: A qual dos anjos disse alguma vez - senta-te à minha direita? O Senhor,
assim, responde para condescender à suplicação dos que o interrogavam, e não que houvesse certos
que haveriam de se assentar à direita do Padre. Pois, o que só pediam era ocupar ao lado dele lugar
superior aos dos outros. - Mas também podemos dizer, que os filhos de Zebedeu pediam terem maior
excelência que os outros, por participarem do poder judiciário de Cristo. E assim, não pediam os fizesse
sentar à direita ou à esquerda do Padre, mas à direita ou à esquerda de Cristo.