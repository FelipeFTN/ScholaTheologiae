# Questão 57: Da Ascensão de Cristo
Em seguida devemos tratar da ascensão de Cristo.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se devia Cristo ascender ao céu.
O primeiro discute-se assim. — Parece que não devia Cristo ascender ao céu.

1. — Pois, segundo o Filósofo, os seres dotados da maior perfeição possível fruem bem próprio sem
precisar mover-se. Ora, Cristo tinha a maior perfeição possível, por ser o sumo bem, em virtude da sua
natureza divina, e ser, pela sua natureza humana soberanamente glorificado. Logo, fruía sem nenhum
movimento a seu bem. Ora, a ascensão é um movimento. Logo, não devia Cristo ascender ao céu.

2. Demais. — Tudo o que se move visa um fim melhor. Ora a Cristo não era melhor estar no céu que na
terra; pois, nenhum bem se lhe acrescentou por estar no céu, nem quanto àalma nem quanto ao corpo.
Logo, parece que Cristo não devia subir ao céu.

3. Demais. — O Filho de Deus assumiu a natureza humana para a nossa salvação. Ora, seria melhor para
a salvação dos homens que sempre se conservasse conosco na terra, e por isso ele próprio disse aos
discípulos: Lá virá tempo que em vós desejareis ver um dia do Filho do homem e não no vereis. Parece,
logo, que não devia Cristo subir ao céu.

4. Demais. — Como diz Gregório, o corpo de Cristo nenhuma mudança sofreu depois da ressurreição.
Ora, não subiu ao céu imediatamente depois da ressurreição; pois, ele próprio o disse depois dela: Ainda
não subi a meu Pai. Logo, parece que nem depois dos quarenta dias devia subir ao céu.
Mas, em contrário, o Senhor diz: Vou para meu Pai e vosso Pai.

SOLUÇÃO. — O lugar deve proporcionar-se ao que nele está colocado. Ora, Cristo depois da
ressurreição entrou na sua vida imortal e incorruptível. Ora, a terra que habitamos é um lugar em que
seres nascem e morrem; ao contrário, o céu é um lugar onde não há morte. Logo não devia Cristo,
depois da ressurreição, permanecer na terra, mas devia subir ao céu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O ser soberanamente perfeito que possui o seu bem
sem ter necessidade nenhuma de mover-se, é Deus: pois é absolutamente imutável, segundo aquilo da
Escritura - Eu sou o Senhor e não mudo. Ao contrario, toda criatura é de certo modo mutável, como o
adverte Agostinho. E como a natureza assumida pelo Filho de Deus permaneceu criatura, conforme do
sobre dito se colige, não há inconveniência em lhe atribuir algum movimento.

RESPOSTA À SEGUNDA. — Por ter subido, ao céu nenhum bem se lhe acrescentou a Cristo, sua glória
essencial, nem quanto ao corpo nem quanto àsua alma. Mas lhe constituiu um novo bem o esplendor da
sua mansão gloriosa. Não que ao corpo lhe adviesse, do corpo celeste, maior perfeição ou conservação,
senão só o conveniente esplendor. O que de certo modo lhe redundava em glória. E esse esplendor lhe
causava alegria; não que começasse então a gozá-la, quando subiu ao céu; mas porque de novo modo
gozou dele, como de um bem completo. Por isso, aquilo da Escritura — Deleites na tua direita para
sempre, diz a Glosa: As minhas delícias e a minha alegria serão quando estiver sentado ao teu lado,
longe dos olhares humanos.

RESPOSTA À TERCEIRA. — Embora da presença corporal de Cristo ficassem privados os fiéis pela
ascensão, contudo a presença da sua divindade sempre a têm eles, segundo o Evangelho: Eu estou
convosco todos os dias, até à consumação do século. Pois, o que subiu aos céus não abandonou os seus
filhos adotivos, como diz Leão Papa.
Mas, a ascensão mesma de Cristo ao céu, fazendo-nos ficar privados da sua presença corporal, nos foi
mais útil que essa presença. — Primeiro, pelo aumento da fé, cujo objeto é o invisível. Por isso o próprio
Senhor disse aos seus discípulos, que o Espírito Santo, quando vier, arguirá o mundo da justiça, isto é,
dos que crêem; pois, a simples comparação dos fiéis com infiéis é a condenação a destes últimos. E por
isso acrescenta: Porque vou para o Pai e vós não me vereis mais. Mas felizes são os que, não vendo,
crêem. Será pois, vossa a justiça, de que será o mundo arguido, por crerdes em mim, a quem não vedes.
— Segundo, para fundar a nossa esperança. Por isso ele próprio o disse: Depois que eu for e vos
aparelhar o lugar, virei outra vez e tomar-vos-ei para mim mesmo, para que onde eu estou estejais
também. Elevando assim ao céu Cristo a natureza humana assumida, deu-nos a esperança de lá chegar:
porque em qualquer lugar em que estiver o corpo, aí se hão de ajuntar também as águias. E por isso diz
a Escritura: Ascende abrindo o caminho adiante deles. — Terceiro, a fim de elevar o afeto da caridade
para os bens celestes. Donde o dizer o Apóstolo: Buscais as coisas que são lá de cima, onde Cristo está
sentado à dextra de Deus; cuidai nas coisas que são lá de cima, não nas que há sobre a terra. Pois, na
frase do Evangelho, onde está o teu tesouro aí está também o teu coração. E sendo o Espírito Santo o
Amor que nos arrebata para os bens celestes, por isso o Senhor diz aos discípulos: A vós convém-vos
que eu vá, porque se eu não for, não virá a vós o Consolador; mas se for enviar vô-lo-ei. O que
Agostinho assim expõe: Não sois capazes de receber o Espírito, enquanto persistis a só conhecer a Cristo
segundo a carne. Cristo, separando-se deles corporalmente, não somente o Espírito Santo, mas ainda o
Pai e o Filho residiram neles espiritualmente.

RESPOSTA À QUARTA. — Embora o lugar conveniente a Cristo ressurrecto para a vida imortal fosse
morada celeste, contudo diferiu a sua ascensão para que comprovasse a verdade da sua ressurreição.
Por isso declara a Escritura: Depois da sua Paixão manifestou-se a si mesmo vivos os discípulos com
muitas provas, por quarenta dias. Ao que uma certa glossa diz: Por ter estado morto durante quarenta
horas, confirma que está vivo, durante quarenta dias. Ou podemos entender que esses quarenta dias
são a imagem da vida presente, durante a qual Cristo reside na sua Igreja. Neste sentido, que o homem
se compõe de quatro elementos e que a Igreja o educa para a observação do decálogo.

## Art. 2 — Se ascender ao céu convinha a Cristo enquanto de natureza divina.
O segundo discute-se assim. — Parece que ascender ao céu convinha a Cristo enquanto de natureza
divina.

1. — Pois, diz a Escritura: Subiu Deus com júbilo. E noutro lugar: O teu protetor é aquele que sobe ao
mais alto dos céus. Ora, isso foi dito de Deus mesmo antes da Encarnação de Cristo. Logo, convinha a
Cristo, como Deus, subir ao céu.

2. Demais. — Sobe ao céu quem dele desceu, segundo aquilo do Evangelho: Ninguém subiu ao céu
senão aquele que desceu do céu. E o
Apóstolo: Aquele que desceu esse mesmo é também o que subiu. Ora, Cristo desceu do céu, não como
homem mas como Deus, pois, não era a sua natureza humana, mas a divina, que já antes existia no céu.
Logo, parece que Cristo subiu ao céu como Deus.

3. Demais. — Cristo, na sua ascensão, subiu ao Pai. Ora, não tinha nenhuma igualdade com o Pai
enquanto homem; pois, diz, nesse sentido: O Pai é maior que eu, como lemos no Evangelho. Logo,
parece que Cristo subiu ao céu como Deus.
Mas, em contrário, àquilo do Apóstolo - Aquele que subiu não foi também o que desceu? - diz a Glosa:
Foi na sua humanidade que Cristo desceu e subiu.

SOLUÇÃO. — A expressão — enquanto que no caso vertente, pode designar duas coisas: a condição de
quem sobe e a causa da ascenção. — Se designa a condição de quem subiu, então ascender não podia
convir a Cristo segundo a condição da sua natureza divina. Quer por não haver nada mais alto que a
divindade, para onde pudesse subir. Quer também por implicar a ascensão o movimento local, de que
não é susceptível a natureza divina, que é imóvel e não ocupa nenhum lugar. Mas, subir desse modo o
podia Cristo na sua natureza humana que ocupava lugar no espaço e era susceptível de movimento. Por
onde, neste sentido, poderemos dizer que Cristo subiu ao céu, enquanto homem e não enquanto Deus.
- Mas se - enquanto que - designa a causa da ascençâo, como Cristo subiu ao céu pelo seu poder divino
e não em virtude da natureza humana, devemos concluir que subiu ao céu não enquanto homem, mas
enquanto Deus. Donde o dizer Agostinho: Enquanto dotado de natureza humana é que Cristo foi
crucificado; mas como Deus é que subiu ao céu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os lugares citados são profecias referentes a Deus,
enquanto encarnado. – Podemos, porém dizer, que subir ao céu, embora não conviesse à natureza
divina, pode contudo lhe ser atribuído metaforicamente; no mesmo sentido em que dizemos que Deus
sobe ao coração do homem, quando este se lhe sujeita e humilha. E, do mesmo modo, dizemos
metaforicamente que sobe, em relação a qualquer criatura quando a sujeita à sua lei.

RESPOSTA À SEGUNDA. — O que subiu foi o mesmo que desceu. Assim, diz Agostinho: Quem foi o que
desceu? Deus homem. Quem foi o que subiu? O mesmo Deus homem. A descida, porém se atribui a
Cristo em dois sentidos. Num, dizemos que desceu do céu. E isto o atribuímos a Deus homem enquanto
Deus. Mas essa descida não na devemos entender como implicando um movimento local; mas pela sua
aniquilação, tendo a natureza de Deus, tomou a natureza de servo. Pois como dissemos que se
aniquilou, não por ter perdido a sua plenitude, mas por ter se revestido das nossas misérias, assim
também, que desceu do céu, não pelo ter abandonado, mas por ter assumido a natureza terrena, na
unidade da pessoa. – Outra, porém foi à descida pela qual descem às partes ínfimas da terra, no dizer do
Apóstolo. E essa foi a um local determinado, e a pôde fazer Cristo, segundo a condição da natureza
humana.

RESPOSTA À TERCEIRA. — Diz-se que Cristo subiu ao céu, por ter subido a sentar-se à dextra paterna. O
que convinha, de certo modo, à natureza divina de Cristo; mas, de certo outro, ànatureza humana,
como a seguir se dirá.

## Art. 3 — Se Cristo subiu por virtude própria.
O terceiro discute-se assim. — Parece que Cristo não subiu ao céu por virtude própria.

1. — Pois, diz o Evangelho, que o Senhor Jesus, depois de haver falado aos discípulos, foi assunto ao céu.
E os Atos: Vendo-o eles, se foi elevando e o recebeu uma nuvem que o ocultou a seus olhos. Ora, o que
é assunto e elevado parece que é movido por outro. Logo, Cristo foi levado ao céu não por virtude
própria, mas por alheia.

2. Demais. — O corpo de Cristo era terreno, como o nosso. Ora, é contra a natureza do corpo terreno
ser levado para cima. Assim, nenhum movimento tem, por virtude própria, o ser movido contrariamente
à sua natureza. Logo, Cristo não subiu ao céu por virtude própria.

3. Demais. — A virtude própria de Cristo é a virtude divina. Ora, o movimento da ascensão não provinha
da virtude divina, porque esta é infinita e aquele instantâneo; de modo que não podiam os discípulos
verem-no elevar-se aos céus, como refere a Escritura. Logo, parece que Cristo não subiu ao céu por
virtude própria.
Mas, em contrário, a Escritura: este formoso em seu traje que caminha na multidão da sua fortaleza. E
Gregório diz: Notemos que a Escritura refere que Elias subiu ao céu num carro, como para mostrar
abertamente que um simples homem precisava do auxílio alheio. Narra, porém, que o nosso Redentor
se elevou sem o auxílio de nenhum carro e nem de anjos, porque o autor de todas as coisas subia, por
seu poder próprio, acima de todas.

SOLUÇÃO. — Tem Cristo dupla natureza: a divina e a humana. Por onde, podemos lhe atribuir um poder
próprio a cada uma dessas naturezas. Mas, já a natureza humana de Cristo é por si só, dotada de duplo
poder. Um natural procedente dos princípios da natureza. E em virtude desse poder é manifestado que
Cristo não subiu ao céu. Outro poder, porém, da natureza humana de Cristo é o da Glória. E em virtude
desse Cristo subiu ao céu. Mas, o fundamento desse poder certos o vão buscar em a natureza da quinta
essência, que é a luz, como dizem, que fazem entrar na composição do corpo humano, de modo a, por
meio dela, adunarem os elementos contrários. De modo que, no seu estado mortal, predomine no
corpo humano a sua natureza elementar; e assim, segundo a natureza do elemento predominante, o
corpo humano tende para baixo pela sua virtude natural. Mas no estado da glória predomina a natureza
celeste, por cuja inclinação e virtude o corpo de Cristo e os corpos dos santos são levados para o céu.
Mas, dessa opinião já tratamos na Primeira Parte, e mais adiante tornaremos a vê-la no tratado da
ressurreição em geral. Deixando, pois, de lado essa opinião, vão outros buscar a razão do referido poder
na alma glorificada, por cuja redundância é glorificado o corpo, como diz Agostinho. Pois, tão sujeito
estará o corpo glorioso àalma beata, que, como diz Agostinho, o corpo estará imediatamente onde o
quiser o espírito, e este não quererá nada que não lhe convenha ao mesmo tempo, e ao corpo. Ora, ao
corpo glorioso e imortal na morada celeste é o seu lugar conveniente. Por onde, levado pela vontade da
sua alma, Cristo subiu ao céu. - Mas, assim como o corpo se torna glorioso por participar da alma, assim,
como diz Agostinho, participando de Deus, a alma se torna bem-aventurada. Por onde, a causa primeira
da ascensão de Cristo ao céu foi o poder divino. Assim, pois, Cristo subiu ao céu por virtude própria:
primeiro, pela sua virtude divina; segundo, pela virtude da sua alma glorificada, que movia o corpo
como queria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como Cristo ressurgiu pela sua vontade própria, e
contudo dizemos que foi ressuscitado pelo Padre, por terem o Pai e o Filho o mesmo poder, assim
também Cristo subiu ao céu por virtude própria, sendo contudo elevado e assunto pelo Pai.

RESPOSTA À SEGUNDA. — A razão aduzida prova que Cristo não subiu ao céu pela virtude própria,
inerente ànatureza humana. Subiu ao céu porém pela sua virtude, enquanto poder divino; e pela virtude
própria à sua alma bem-aventurada. E embora subir para as alturas seja contrário à condição presente
da natureza do corpo humano, em que o corpo não está inteiramente sujeito ao espírito, não será
porém contrário à natureza do corpo glorioso, nem lhe constituirá uma violência, a ele cuja natureza
está totalmente sujeita ao espírito.

RESPOSTA À TERCEIRA. — Embora o poder divino seja infinito, e tenha pelo seu sujeito, capacidade
infinita, contudo o efeito da sua ação é recebido pelas causas segundo a capacidade delas e a disposição
de Deus. Ora, o corpo não é capaz de um movimento local instantâneo, porque há de comensurar-se
com o espaço, por cuja divisão e divide o tempo, como o prova Aristóteles. Por onde, não é necessário
que o corpo seja movido por Deus instantaneamente, mas que o seja pela velocidade que Deus dispõe.

## Art. 4 — Se Cristo subiu acima de todos os céus.
O quarto discute-se assim. — Parece que Cristo não subiu acima de todos os céus.

1. — Pois, diz a Escritura: O Senhor habita no seu santo templo, o trono do Senhor é no céu. Ora, o que
está no céu não está acima dele. Logo, Cristo não subiu acima de todos os céus.

2. Demais. — Dois corpos não podem estar no mesmo lugar. Ora, como não passou de um extremo para
outro, transitando pelo meio, parece que Cristo não podia subir além de todos os céus, a menos que o
céu não se dividisse. O que é impossível.

3. Demais. — A Escritura refere que uma nuvem o ocultou aos olhos deles. Ora, as nuvens não podem
elevar-se acima dos céus. Logo, Cristo não subiu acima de todos os céus.

4. Demais. — Cremos que Cristo há de permanecer perpetuamente no lugar onde subiu. Ora, o
contrário à natureza não pode ser sempiterno; pois, o que é segundo a natureza se realiza no mais das
vezes e mais frequentemente. Ora, sendo contra a natureza de um corpo terrestre existir acima do céu,
parece que o corpo de Cristo não subiu acima dele.
Mas, em contrário, o Apóstolo: Subiu acima de todos os céus, para encher todas as causas.

SOLUÇÃO. — Tanto mais perfeitamente um corpo participa da bondade divina, tanto mais de ordem
corpórea superior é, que é a ordem local. Assim, os corpos que têm maior formalidade são
naturalmente superiores, como está claro no Filósofo; pois, pela forma é que cada corpo participa do ser
divino. Ora, mais participa da divina bondade o corpo, pela glória, do que qualquer corpo natural, pela
forma da sua natureza. E dentre os outros corpos gloriosos é manifesto que o corpo de Cristo tem glória
mais refulgente. Por onde, convenientíssimo lhe é estar constituído no alto, acima de todos os corpos.
Por isso àquilo do Apóstolo — subindo ao alto, diz a Glosa: Em lugar e dignidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dizemos que o trono de Deus e no céu, não que este o
contenha, mas antes, como contido por ele. Por onde, não é necessário haja nenhuma parte do céu
superior a ele, mas sim, que ele seja superior a todos os céus, como o diz a Escritura: A tua
magnificência se elevou sobre os céus.

RESPOSTA À SEGUNDA. — Embora um corpo não possa por natureza, ocupar o mesmo lugar que outro,
contudo Deus pode fazer milagrosamente com que ambos ocupem o mesmo lugar. Assim fez o corpo de
Cristo nascer do ventre virginal de Maria e passou através de portas fechadas, como diz S. Gregório.
Logo, podia o corpo de Cristo ocupar o mesmo lugar que outro, não por propriedade corpórea sua, mas
por auxílio e obra do poder divino.

RESPOSTA À TERCEIRA. — A nuvem referida não prestou nenhum auxílio, como meio pelo qual Cristo
fosse conduzido ao céu; mas apareceu, como sinal manifestativo da divindade, assim como a glória do
Deus de Israel aparecia sobre o tabernáculo em forma de nuvem.

RESPOSTA À QUARTA. — O corpo glorioso não é em virtude dos princípios mesmos da sua natureza que
pode estar no céu ou acima dele; mas recebe essa capacidade, da alma bem-aventurada, donde tiraa
sua glória. E, assim como o movimento do corpo glorioso para cima não é violento, também não o é o
repouso. Por onde, nada impede seja este sempiterno.

## Art. 5 — Se o corpo de Cristo subiu acima de todas as criaturas espirituais.
O quinto discute-se assim. — Parece que o corpo de Cristo não subiu acima de todas as criaturas
espirituais.

1. — Pois, seres que não respondem à mesma acepção não podem ser comparados entre si. Ora, o lugar
não é atribuído na mesma acepção às criaturas corporais e espirituais, como resulta do que foi dito na
Primeira Parte. Logo, parece que não podemos dizer que o corpo de Cristo subiu acima de todas as
criaturas espirituais.

2. Demais. — Agostinho diz que o espírito tem preeminência sobre todos os corpos. Ora, ao ser mais
nobre é devido um lugar mais nobre. Logo, parece que não ascendeu sobre todas as criaturas
espirituais.

3. Demais. — Todo lugar é ocupado por um corpo, porque não há vácuo em a natureza. Se portanto
nenhum corpo ocupa um lugar mais elevado que o espírito, na ordem dos corpos naturais, nenhum
lugar haverá superior ao das criaturas espirituais. Logo, o corpo de Cristo não podia subir acima de todas
as criaturas espirituais.
Mas, em contrário, o Apóstolo: Constitui sobre todo o principado e potestade e sobre todo o nome que
se nomeia não só neste século, mas ainda no futuro.

SOLUÇÃO. — Tanto mais elevado lugar é devido a um ser quanto mais nobre é, quer esse lugar seja
próprio, como o é aos corpos, por contato material, quer por contato espiritual, como às substâncias
espirituais. Donde, pois, às substâncias espirituais é próprio, por conveniência, o lugar celeste, o
supremo dos lugares, por serem essas as substâncias supremas na ordem das substâncias. Ora, o corpo
de Cristo, embora inferior às substâncias espirituais, se levarmos em conta as condições da natureza
corpórea; considerando-se porém a dignidade da união, conjunta com Deus pessoalmente, sobrepuja a
dignidade de todas as substâncias espirituais. Por onde, pela razão da conveniência referida, é-lhe
devido um lugar mais elevado, acima de todas as criaturas, mesmo espirituais. Donde o dizer Gregório:
Quem fez todas as causas foi exaltado sobre todas pelo seu poder.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por uma razão é atribuído o lugar à substância corpórea
e, por outra, àsubstância espiritual. Contudo o principio é comum a ambas, que ao ser mais digno é
atribuído um lugar superior.

RESPOSTA À SEGUNDA. — A objeção colhe em relação ao corpo de Cristo, quanto à condição da
natureza corpórea, mas não quanto à noção de união.

RESPOSTA À TERCEIRA. — A comparação aduzida pode fundar-se na noção de lugar; e então nenhum
lugar há tão alto que exceda a dignidade das substâncias espirituais; e nesse sentido a objeção colhe. Ou
pode fundar-se na dignidade dos seres aos quais o lugar é atribuído. E então ao corpo de Cristo compete
estar acima de todas as criaturas espirituais.

## Art. 6 — Se a ascensão de Cristo é a causa da nossa salvação.
O sexto discute-se assim. — Parece que a ascensão de Cristo não é a causa da nossa salvação.

1. — Pois, Cristo foi à causa da nossa salvação, pela ter merecido. Ora, com a sua ascensão nada nos
mereceu; porque foi ela um premio da sua exaltação, e não se identifica o mérito com o premio como
não é a via idêntica ao seu termo. Logo, parece que a ascensão de Cristo não é a causa da nossa
salvação.

2. Demais. — Se a ascensão de Cristo fosse a causa da nossa salvação, sê-lo-ia sobretudo porque a sua
ascensão teria sido a causa da nossa. Ora, a nossa ascensão nó-Ia mereceu a sua Paixão, conforme
aquilo do Apóstolo: Temos confiança de entrar no santuário pelo sangue de Cristo. Logo, parece que a
ascensão de Cristo não foi a causa da nossa salvação.

3. Demais. — Cristo nos conferiu uma salvação sempiterna conforme à Escritura: A minha salvação será
para sempre. Ora, Cristo não subiu ao céu a fim de nele permanecer para sempre; pois, diz a Escritura:
Assim como o vistes assunto ao céu, assim virá. E também refere ela que apareceu a muitos santos, em
vários lugares, depois da sua ascensão; assim, a Paulo. Logo, parece que a sua ascensão não é a causa da
nossa salvação.
Mas, em contrário, o Evangelho: A vós convém-vos que eu vá, isto é que me separe de vós pela
ascensão.

SOLUÇÃO. — A ascensão de Cristo é a causa da nossa salvação, de dois modos: por nosso lado e por
parte de Cristo. Por nosso lado, porque a ascensão de Cristo eleva-nos o espírito para ele. Pois, a sua
ascensão, como dissemos, anima-nos, primeiro, a fé: depois, a esperança; enfim, a caridade. Em quarto
lugar, aumenta-nos a reverência para com ele, por já não o considerarmos homem da terra, mas o Deus
do céu, conforme o diz o Apóstolo: Se houve tempo em que conhecemos a Cristo segundo a carne - isto
é, como mortal, tendo-o somente na conta de homem, conforme o expõe a Glosa - já agora o não
conhecemos deste modo.
Por parte de Cristo, relativamente ao que fez, subindo ao céu em bem da nossa salvação. Assim,
primeiro, preparou-nos o caminho para subirmos ao céu, conforme ele próprio o disse: Vou aparelhar-
vos o lugar. E noutro passo diz a Escritura: Subiu abrindo o caminho adiante deles. Pois, sendo a nossa
cabeça, hão de os membros acompanhá-la para onde for. Daí o seu dito: Onde eu estou estejais vós
também. E como sinal disso, levou para o céu as almas dos santos, que livrou do inferno, segundo aquilo
da Escritura: Subindo Cristo ao alto, fez escrava a escravidão; porque os que foram escravizados pelo
diabo conduziu-os consigo ao céu, como para um lugar estranho à natureza humana — felizes captívos,
pois ganhou-os para si com a sua vitória. — Segundo, porque assim como o pontífice do Antigo
Testamento entrava no santuário para interceder junto de Deus pelo povo, assim também Cristo entrou
no céu para interceder por nós, na frase do Apóstolo. Pois a sua própria figura, de natureza humana,
com que entrou no céu, é de certo modo uma intercessão por nós; porquanto, o ter Deus exaltado a
natureza humana em Cristo leva-o também a ter misericórdia daqueles por quem o Filho de Deus
assumiu a natureza humana. - Terceiro para que, constituído quase Deus e Senhor no trono celeste, nos
conferisse assim aos homens os seus dons divinos, segundo aquilo do Apóstolo: Subiu acima de todos os
céus para encher todas as causas - de seus dons, segundo a Glosa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ascensão de Cristo é a causa da nossa salvação, não a
modo de mérito, mas a modo de eficiência, como dissemos acima a propósito da ressurreição.

RESPOSTA À SEGUNDA. — A Paixão de Cristo é a causa da nossa ascensão ao céu, propriamente
falando, por nos livrar do pecado que nô-Ia impedia; e a modo de mérito. Mas a ascensão de Cristo é
diretamente a causa da nossa ascensão, quase fazendo-a começar no nosso chefe, ao qual hão de os
membros estar unidos.

RESPOSTA À TERCEIRA. — Cristo, uma vez subido ao céu, ganhou para si e para nós e perpetuamente o
direito e a dignidade à mansão celeste. E a essa dignidade não derroga o fato de às vezes e
excepcionalmente descer em corpo à terra, quer para mostrar-se a todos, como o fará no juízo, quer
para se mostrar a alguém especialmente, como a Paulo, segundo o refere a Escritura. E para não crer
ninguém que isso se deu, não, estando Cristo presente corporalmente, mas apenas alguma aparência
sua, o contrário resulta do que diz o Apóstolo para confirmar a fé na ressurreição: última mente foi
também visto de mim como de um abortivo. Visão essa que não provaria a verdade da ressurreição, se
não fosse o seu verdadeiro corpo o visto por ele.