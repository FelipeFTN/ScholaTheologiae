# Questão 8: Da graça de Cristo, enquanto Ele é a cabeça da Igreja
Em seguida devemos tratar da graça de Cristo enquanto cabeça da Igreja.
E nesta questão discutem-se oito artigos:

## Art. 1 — Se a Cristo, enquanto homem, compete ser a cabeça da Igreja.
O primeiro discute-se assim. — Parece que a Cristo, enquanto homem, não compete ser a cabeça da
Igreja.

1. — Pois, a cabeça influi o sentimento e o movimento nos membros. Ora, o sentimento e o movimento
espirituais, oriundos, da graça não os influi em nós Cristo homem. Pois, como diz Agostinho, não Cristo
enquanto homem, mas só enquanto Deus, é quem dá o Espírito Santo. Logo, não lhe compete,
enquanto homem, ser a cabeça da Igreja.

2. Demais. — Uma cabeça não poder pertencer a outra. Ora, de Cristo, enquanto homem, a cabeça é
Deus, conforme o Apóstolo: Deus é a cabeça de Cristo. Logo, Cristo em si mesmo não é cabeça.

3. Demais. — A cabeça, no homem, é um membro particular, e recebendo a sua influência do coração.
Ora, Cristo é o princípio universal de toda a Igreja. Logo, não é cabeça da Igreja.
Mas, em contrário, o Apóstolo: Constituiu-o a ele mesmo cabeça de toda a Igreja.

SOLUÇÃO. — Assim como toda a Igreja é considerada um corpo místico, por semelhança com o corpo
natural do homem, o qual tem atos diversos distribuídos por membros diversos, consoante o ensina o
Apóstolo; assim também Cristo é chamado cabeça da Igreja por semelhança com a cabeça do homem.
No que podemos considerar três coisas: a ordem, a perfeição e a virtude. A ordem, por ser a cabeça a
primeira parte do corpo humano, principiando de cima. Donde vem o costume de chamar cabeça a todo
princípio, segundo a Escritura: Puseste na cabeça de todas as ruas o sinal público da tua prostituição. —
A perfeição, porque a cabeça dá o vigor a todos os sentidos interiores e exteriores, ao passo que os
outros membros só têm o tato. Donde o dizer a Escritura: O ancião e o homem respeitável, esse é a
cabeça. — A virtude, enfim, porque a virtude e o movimento dos outros membros, e a governação dos
atos deles vêm da cabeça, por causa da virtude sensitiva e motiva aí dominante. Por isso, o dirigente se
chama cabeça do povo, segundo àquilo da Escritura: Porventura, quando tu eras pequeno aos teus
olhos, não foste feito cabeça de toda as tribos de Israel? Ora, essas três coisas cabem a Cristo
espiritualmente. — Assim, primeiro, pela sua proximidade com Deus, a sua graça é a mais alta e a
primeira, embora não no tempo; porque todos os outros receberam a graça em dependência da graça
dele, conforme as palavras do Apóstolo: Os que ele conheceu na sua presciência, também os
predestinou para serem conformes à imagem de seu Filho, para que ele seja o primogênito entre muitos
irmãos. — Segundo, a perfeição ele a tem, quanto à plenitude de todas as graças, conforme o
Evangelho: E nós o vimos cheio de graça e de verdade, como se demonstrou. — Terceiro, tem a virtude
de influir a graça em todos os membros da Igreja, conforme ainda o Evangelho: E todos nós
participamos da sua plenitude. — Por onde é claro que Cristo é convenientemente chamado cabeça da
Igreja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dar a graça ou o Espírito Santo convém a Cristo,
enquanto Deus, autoritativamente; mas instrumentalmente lhe convém enquanto homem, isto é,
enquanto a sua humanidade foi instrumento da sua divindade. E assim, os seus atos, em virtude da
divindade, foram salutíferos para nós, como causadores em nós da graça, tanto por meio do mérito
como de uma certa eficácia. Ora, Agostinho nega que Cristo, enquanto homem, dê o Espírito Santo por
autoridade. Mas, instrumental ou ministerialmente também se diz que os outros santos dão o Espírito
Santo, segundo o Apóstolo: Aquele que vos dá o Espírito Santo, etc.

RESPOSTA À SEGUNDA. — Nas locuções metafóricas a semelhança não deve ser buscada na sua
totalidade; pois, do contrário, já não seria semelhança, mas a realidade mesma. Ora, a cabeça natural
não tem outra cabeça, por não ser o corpo humano, parte de outro corpo. Mas o corpo, assim chamado
por semelhança, isto é, uma multidão ordenada, é parte de outra multidão; assim como a multidão
doméstica é parte da multidão civil; por onde, o pai de família, cabeça da multidão doméstica, tem
como cabeça superior o regente da cidade. E, deste modo, nada impede seja Deus a cabeça de Cristo,
embora seja este a cabeça da Igreja.

RESPOSTA À TERCEIRA. — A cabeça tem uma eminência manifesta em relação aos outros memdo
corpo, ao passo que o coração tem uma certa influência oculta. E por isso é comparado ao Espírito
Santo, que invisivelmente vivifica e une a Igreja; enquanto que Cristo mesmo é comparado à cabeça,
segundo a natureza visível, que o coloca, como homem, acima dos outros homens.

## Art. 2 — Se Cristo é a cabeça dos homens quanto aos corpos.
O segundo discute-se assim. — Parece que Cristo não é a cabeça dos homens quanto aos corpos.

1. — Pois, Cristo é chamado cabeça da Igreja, enquanto influi o senso espiritual e o movimento da graça
na Igreja. Ora, o corpo não é capaz desse senso nem desse movimento espiritual. Logo, Cristo não é a
cabeça de todos, quanto aos corpos.

2. Demais. — Temos o corpo de comum com os brutos. Se pois Cristo fosse a cabeça dos homens quanto
aos corpos, resultaria que também dos brutos sê-la-ia. O que é inadmissível.

3. Demais. — Cristo tinha um corpo da mesma natureza que o dos outros homens, como se lê no
Evangelho. Ora, a cabeça ocupa o primeiro lugar entre os outros membros, como se disse. Logo, não é a
cabeça da Igreja, quanto aos corpos.
Mas, em contrário, o Apóstolo: Reformará o nosso corpo abatido para o fazer conforme ao seu corpo
glorioso.

SOLUÇÃO. — O corpo humano se ordena naturalmente à alma racional, dele a forma própria e o motor.
E enquanto sua forma, dela recebe ele a vida e as outras propriedades convenientes ao corpo humano
segundo a sua espécie. E enquanto a alma é o motor do corpo, este lhe serve a ela instrumentalmente.
Donde devemos concluir que a humanidade de Cristo tem o poder de influir, enquanto unida ao Verbo
de Deus, a quem o corpo está unido, pela alma, como se disse. Donde, toda a humanidade de Cristo,
isto é, quanto à alma e quanto ao corpo, influi nos corpos e nas almas dos homens; mas, principalmente
na alma e, secundàriamente, no corpo. De um modo, no dizer do Apóstolo enquanto os membros do
corpo são oferecidos a Deus como instrumentos de justiça, na alma existente, por Cristo. De outro modo
enquanto a vida da glória deriva da alma para o corpo, segundo o Apóstolo: Aquele que ressuscitou dos
mortos a Jesus Cristo também dará vida aos vossos corpos mortais, pelo seu Espírito, que habita em vós.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O senso espiritual da graça não chega ao corpo, primária
e principalmente; mas, secundária e instrumentalmente, como se disse.

RESPOSTA À SEGUNDA. — O corpo do animal bruto nenhuma aptidão tem para a alma racional, como a
tem o corpo humano. Logo, a comparação não colhe.

RESPOSTA À TERCEIRA. — Embora Cristo tivesse o seu corpo feito da matéria igual a do corpo dos
outros homens, contudo, a vida imortal do corpo todos os homens a recebem dele, segundo o Apóstolo:
Assim como em Adão morrem todos, assim também- todos serão vivificados em Cristo.

## Art. 3 — Se Cristo é a cabeça de todos os homens.
O terceiro discute-se assim. — Parece que Cristo não é a cabeça de todos os homens.

1. — Pois, a cabeça não não tem relação senão com os membros do seu corpo. Ora, os infiéis de
nenhum modo são membros da Igreja, que é o corpo de Cristo, como diz o Apóstolo. Logo, Cristo não é
a cabeça de todos os homens.

2. Demais. — O Apóstolo diz: Cristo se entregou a si mesmo pela Igreja, para a apresentar a si mesmo
Igreja gloriosa, sem mácula nem ruga, nem outro algum defeito semelhante. Ora, há ainda muito fiéis
enfeiados pela mácula e a ruga do pecado. Logo, não será Cristo a cabeça de todos os fiéis,

3. Demais. — Os sacramentos da lei antiga estão para Cristo como a sombra para o corpo, no dizer do
Apóstolo. Ora, os Padres do Antigo Testamento viviam no regime desses sacramentos, segundo o
Apóstolo: Os quais servissem de modelo e sombra das causas celestiais. Logo, não pertenciam ao corpo
de Cristo. E, portanto, Cristo não é a cabeça de todos os homens.
Mas, em contrário, a Escritura: É o Salvador de todos os homens e principalmente dos fiéis. E noutro
lugar: Ele é a propiciação pelos nossos pecados; não somente pelos nossos, mas também pelos de todo
o mundo. Ora, salvar os homens ou ser propiciação pelos pecados deles compete a Cristo enquanto
cabeça. Logo, Cristo é a cabeça de todos os homens.

SOLUÇÃO. — A diferença entre o corpo natural do homem e o corpo místico da Igreja está em os
membros todos do corpo natural coexistirem, ao passo que não coexistem os membros do corpo
místico. Nem quanto ao ser natural deles, porque o corpo da Igreja é constituído dos homens existentes
desde o princípio do mundo e que existirão até o fim dele, Nem quanto ao ser da graça, pois, dos que
vivem num determinado tempo, uns não têm a graça, mas te-la-âo mais tarde, ao passo que já a tem
outros. Assim, pois, consideram-se como membros do corpo místico os que não somente o são em ato,
mas ainda os que o são em potência. Mas, certos o são, em potência, que nunca serão reduzidos ao ato;
outros, porém, serão reduzidos ao ato, segundo tríplice grau - um, pela fé, o segundo, pela caridade
desta vida, o terceiro, pela fruição da pátria.
Donde devemos concluir, que, considerando-o geralmente, segundo o tempo total do mundo, Cristo é a
cabeça de todos os homens, mas em graus diversos. Assim, primária e principalmente, é a cabeça
daqueles que atualmente lhe estão unidos pela glória. Em segundo lugar, dos que lhe estão unidos pela
caridade. Em terceiro, dos que lhe estão unidos pela fé. Em quarto, dos que lhe estão unidos só em
potência sem ainda terem sido reduzidos ao ato, mas que a este devem ser reduzidos, segundo a divina
predestinação. O quinto, enfim, os que lhe estão unidos em potência e nunca serão reduzidos a ato,
como os homens que vivem neste mundo e que não são predestinados. Mas que, partindo deste
mundo, deixam totalmente de ser membros de Cristo, por já não poderem ser unidos a Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os infiéis, embora atualmente não sejam da Igreja, são-
no contudo, em potência. E essa potência tem duplo fundamento. O primeiro e principal, a virtude de
Cristo, suficiente à salvação de todo gênero humano. O segundo, o arbítrio da liberdade.

RESPOSTA À SEGUNDA. — Constituir a Igreja gloriosa, sem mácula nem ruga, é o fim último a se dará no
estado da pátria, mas não no da via, no qual, se dissermos que estamos sem pecado, nós mesmos nos
enganamos, como diz a Escritura. Mas os membros de Cristo, pela união atual da caridade, já estão
isentos de certos pecados, que são os mortais. Ao contrário, os que vivem sob o jugo desses pecados
não são membros de Cristo atualmente, mas só potencialmente. Salvo talvez se, de maneira imperfeita,
pela fé informe, que une a Cristo decerto modo, mas não absolutamente falando, a saber, de modo que,
por Cristo, o homem consiga a vida da graça, segundo aquilo da Escritura: pois, a fé sem as obras é
morta. Contudo, esses tais já recebem de Cristo um certo ato de vida, que é crer, como se um membro
já atacado da morte fosse, de algum modo, movido pelo homem.

RESPOSTA À TERCEIRA. — Os santos Patriarcas não se apegavam aos sacramentos legais como a
determinadas realidades, mas como a imagens e a sombras das coisas futuras. Ora, o movimento para a
imagem, como tal, é o mesmo que o para a realidade, segundo está claro no Filósofo. Por isso, os
antigos Padres, observando os sacramentos da lei, eram levados para Cristo pela mesma fé e pelo
mesmo amor pelos quais também nós para ele somos levados. Por onde, os Patriarcas antigos
pertenciam ao mesmo corpo da Igreja a que nós pertencemos.

## Art. 4 — Se Cristo, enquanto homem, é a cabeça dos anjos.
O quarto discute-se assim. — Parece que Cristo, enquanto homem, não é a cabeça dos anjos.

1. — Pois, a cabeça e os membros são da mesma natureza. Ora, Cristo, enquanto homem, não tem a
mesma natureza dos anjos, mas a dos homens; porque, como diz o Apóstolo, ele em nenhum lugar
tomou aos anjos, mas tomou a descendência de Abraão, Logo, Cristo, enquanto homem, não é a cabeça
dos anjos.

2. Demais. — Cristo é a cabeça dos que pertencem à Igreja, que é o seu corpo, como diz o Apóstolo. Ora,
os anjos não pertencem à Igreja; pois, esta é a congregação dos fiéis; ora, não há fé nos anjos, que não
andam por fé, mas, por visão; do contrário, andariam ausentes do Senhor, como argumenta o Apóstolo.
Logo, Cristo, enquanto homem, não é a cabeça dos anjos.

3. Demais. — Agostinho diz, que assim como o Verbo que estava no princípio junto de Deus, vivifica as
almas, assim o Verbo feito carne vivifica os corpos, que os anjos não têm. Ora, o Verbo feito carne é
Cristo enquanto homem. Logo, Cristo, enquanto homem, não influi a vida nos anjos. E portanto,
enquanto homem, não é a cabeça dos anjos.
Mas, em contrário, o Apóstolo diz: Ele que é a cabeça de todos os Principados e Potestades. E o mesmo
se dá com os anjos das outras ordens. Logo, Cristo é a cabeça dos anjos.

SOLUÇÃO. — Como se disse, onde há um corpo há-de haver necessariamente uma cabeça. Ora, por
semelhança se chama um corpo a uma multidão ordenada em unidade, segundo atos — ou ofícios
distintos, Ora, é manifesto que os homens e os anjos se ordenam ao mesmo fim da fruição da glória
divina. Por onde, o corpo místico da Igreja não consta só dos homens mas também, dos anjos. Ora, de
toda essa multidão a cabeça é Cristo, porque está mais próximo de Deus e mais perfeitamente lhe
participa dos dons, não somente que os homens, mas também que os anjos; e da sua influência
participam não só os homens mas também os anjos. Assim, diz o Apóstolo, que Deus Padre o pôs a ele,
isto é, a Cristo, à sua mão direita no céu, sobre todo Principado e Potestade e Virtude e Dominação e
sobre todo nome que se nomeia, não só neste século, mas ainda no futuro; e lhe meteu debaixo dos pés
todas as coisas. Logo, Cristo é cabeça, não só dos homens, mas também dos anjos. Por isso lemos no
Evangelho, que chegaram os anjos e o serviram.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A influência de Cristo sobre os homens se exerce
principalmente quanto às almas, pelas quais os homens convém com os anjos em a natureza genérica,
embora não em a natureza específica. E em razão dessa conformidade, Cristo pode ser considerado
cabeça dos anjos, embora falte a conformidade quanto ao corpo.

RESPOSTA À SEGUNDA. — A Igreja, neste mundo, é a congregação dos fiéis; mas, na pátria, é a dos que
gozam da visão beatífica. Ora, Cristo, ao mesmo tempo que vivia esta vida mortal gozava da visão
beatífica. Por onde, é a cabeça não somente dos fiéis mas também dos que gozam da glória, por ter
plenissimamente a graça e a glória.

RESPOSTA À TERCEIRA. — Agostinho, no lugar aduzido, fala fundado numa certa assimilação de causa a
efeito, isto é, enquanto que os corpos agem sobre os corpos e os espíritos, sobre os espíritos.
Contudo, a humanidade de Cristo, em virtude da natureza espiritual, isto é, divina, pode causar efeitos,
não só nos espíritos dos homens, mas também nos dos anjos, pela conjunção máxima dele com Deus,
isto é, por causa da união pessoal.

## Art. 5 — Se a graça pela qual Cristo é a cabeça da Igreja é idêntica à que tinha como um homem particular.
O quinto discute-se assim. — Parece que a graça pela qual Cristo é a cabeça da Igreja não é idêntica à
que tinha como um homem particular.

1. — Pois, diz o Apóstolo: Se pelo pecado dum morreram muitos, muito mais a graça de Deus e o dom
pela graça dum só homem, que é Jesus Cristo, abundou sobre muitos. Ora, um é o pecado atual de Adão
e outro, o pecado original, que transmitiu aos pósteros. Logo, uma é a graça pessoal, própria de Cristo e
outra, a sua graça enquanto cabeça da Igreja, que dele deriva para nós outros,

2. Demais. — Os hábitos distinguem-se pelos atos. Ora, a um ato se ordena a graça pessoal de Cristo, a
saber, à santificação da sua alma; e a outro, a sua graça como cabeça, isto é, à santificação dos outros.
Logo, uma é a graça pessoal de Cristo, é outra a sua graça como cabeça da Igreja.

3. Demais. — Como se disse, em Cristo distingue-se uma tríplice graça: a da união, a de cabeça e a que
tem como um homem particular. Ora, a graça de Cristo é diferente da graça de união. Logo, também o é
da graça de cabeça.
Mas, em contrário, o Evangelho: Todos nós participamos da sua plenitude. Ora, ele é nosso chefe pelo
que dele participamos. Logo, é nosso chefe ou cabeça porque tinha a plenitude da graça. Mas, a
plenitude da graça ele a teve porque perfeitamente teve a graça pessoal, como se disse. Logo, por essa
graça pessoal é que é a nossa cabeça. E portanto, a graça de cabeça não é diferente da graça pessoal.

SOLUÇÃO. — Todo ser age enquanto atual. Por onde e necessariamente, é em virtude do mesmo ato
que o agente existe atualmente e age; assim, pelo mesmo calor o fogo é quente e aquece. Mas, nem
todo ato pelo qual um agente é atual basta para que seja princípio de seção sobre outros seres. Pois,
sendo o agente superior ao paciente, como diz Agostinho e o Filósofo, é necessário que o ser agente
sobre outros tenha o seu ato segundo uma certa eminência. Ora, como dissemos, a alma de Cristo
recebeu a graça segundo uma eminência máxima. Por isso, pela eminência da graça que recebeu,
compete-lhe distribuir essa graça aos outros, o que se inclui na ideia de chefia. E portanto, a graça
pessoal que justifica a alma de Cristo é essencialmente a mesma pela qual é a cabeça da Igreja, que
justifica os outros, embora desta difira racionalmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pecado original em Adão, que é um pecado de
natureza, derivou do pecado atual do mesmo, que foi um pecado pessoal. Porque nele a pessoa
corrompeu a natureza; mediante a qual corrupção, o pecado do primeiro homem derivou para os
pósteros, porque a natureza corrupta corrompe a pessoa. Mas, a graça não deriva de Cristo para nós
mediante a natureza humana, mas pela só ação pessoal de Cristo mesmo. Por onde, não devemos
distinguir em Cristo dupla graça, das quais uma responda à natureza e outra, à pessoa, como em Adão
se distingue o pecado ela natureza e o da pessoa.

RESPOSTA À SEGUNDA. — Atos diversos, dos quais um é a razão e a causa do outro; não diversificam o
hábito. Ora, o ato pessoal da graça, que torna santo quem formalmente a tem, é a razão da justificação
dos outros, a qual pertence à graça de chefe. Donde vem que tal diferença não diversifica a essência do
hábito.

RESPOSTA À TERCEIRA. — A graça pessoal e a graça de chefe se ordena a algum ato; ao passo que a
graça de união não se ordena ao ato mas, ao ser pessoal. Por onde, a graça pessoal e a graça de cabeça
convêm na essência do hábito, mas não a graça de união. — Embora a graça pessoal possa de certo
modo chamar-se graça de união, enquanto produtora de uma certa aptidão para a união. E, assim
sendo, a graça de união, a de chefe e a da pessoa particular são uma mesma graça, só diferentes pela
razão.

## Art. 6 — Se ser cabeça da Igreja é próprio de Cristo.
O sexto assim se discute. — Parece que ser cabeça da Igreja não é próprio de Cristo.

1. — Pois, diz a Escritura: Quando tu eras pequeno aos seus olhos não foste feito chefe de todas as
tribos de Israel? Ora, a mesma é a Igreja do Novo e do Antigo Testamento. Logo, parece que pela
mesma razão algum outro homem, que não Cristo, poderia ser cabeça da Igreja.

2. Demais. — Cristo é chamado cabeça da Igreja por influir a graça nos membros dela. Ora, também
outros podem dar a graça aos homens, conforme o Apóstolo: Nenhuma palavra má saia da vossa boca,
senão só a que seja boa para a edificação da fé, de maneira que dê graças aos que a ouvem. Logo,
parece que também a outros, além de Cristo, compete ser cabeça da Igreja.

3. Demais. — Cristo, por ter a chefia da Igreja, não só é chamado cabeça, mas também pastor e
fundamento dela. Ora, não só para si Cristo se reservou o nome de pastor, segundo a Escritura: Quando
aparecer o príncipe dos pastores, recebereis a coroa da glória, que nunca se poderá murchar. Nem o
nome de fundamento, segundo aquele outro lugar: O muro da cidade, que tinha doze fundamentos.
Logo, parece que também não se reservou só para si o nome de cabeça.
Mas, em contrário, diz o Apóstolo: É da cabeça da Igreja que todo o corpo é fornido e organizado pelas
suas ligaduras e juntas e cresce em aumento de Deus. Ora, isto só a Cristo convém. Logo, só Cristo é
cabeça da Igreja.

SOLUÇÃO. — A cabeça influi nos outros membros de dois modos. Primeiro, por um certo influxo
intrínseco; isto é, enquanto que a virtude motiva e a sensitiva deriva da cabeça para os outros membros.
De outro modo, por um certo governo exterior, isto é, enquanto que a vista e os outros sentidos, com
sede na cabeça, dirigem o homem nos seus atos externos. Ora, o influxo interior da graça não deriva
para os demais senão só de Cristo, cuja humanidade, por ser conjunta com a divindade, tem a virtude de
justificar. Mas, o influxo para os membros da Igreja, quanto ao governo exterior, pode convir aos outros.
E neste sentido, certos podem ser considerados cabeças da Igreja, segundo a Escritura: Grandes, que
sois os chefes dos povos. Mas, diferentemente de Cristo. Primeiro, porque Cristo é a cabeça de todos os
que pertencem à Igreja em todos os lugares, tempos e estados; ao passo que os outros homens se
chamam cabeças relativamente a certos lugares especiais — assim, os Bispos, das suas Igrejas; ou ainda,
num tempo determinado - assim o Papa é a cabeça de toda a Igreja, isto é, durante o tempo do seu
pontificado; ou enfim, num estado determinado, isto é, enquanto ainda peregrinam nesta vida. Noutro
sentido Cristo é a cabeça da Igreja por virtude e autoridade próprias; ao passo que os outros se chamam
cabeças por fazerem as vezes de Cristo, segundo o Apóstolo: Pois eu também, a indulgência de que usei,
se de alguma causa tenho usado, foi por amor de vós em pessoa de Cristo. E noutro lugar: Fazemos o
ofício de embaixadores em nome de Cristo, como se Deus vos admoestasse por nós outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras citadas se entendem no sentido em que o
nome de chefe designa o governo exterior, como quando se diz que o rei é o chefe do seu reino.

RESPOSTA À SEGUNDA. — O homem não dá a graça influindo interiormente, mas persuadindo
exteriormente às causas da graça.

RESPOSTA À TERCEIRA. — Conforme diz Agostinho, se os prepostos à Igreja são pastores, como há um
só Pastor, senão por serem todos os outros os membros de um só? E semelhantemente, os outros
podem ser chamados fundamento e cabeça, por serem os membros de uma mesma cabeça e de um
mesmo fundamento. E contudo, como diz Agostinho no mesmo lugar, ele outorgou aos seus membros o
serem pastores, mas nenhum de nós se intitula porta; isso ele só a si próprio se reservou. E isto porque
a porta representa a autoridade principal; pois, por ela é que todos entram na casa. Ora, só Cristo é o
pelo qual temos acesso a esta graça na qual estamos firmes, como diz o Apóstolo. Quanto aos outros
nomes referidos, eles podem implicar não só a autoridade principal, mas também, as secundárias.

## Art. 7 — Se o diabo é a cabeça dos maus.
O sétimo discute-se assim. — Parece que o diabo não é a Cabeça dos maus.

1. — Pois, a ideia de cabeça implica a sua influência da sensibilidade e do movimento nos membros,
como diz uma Glosa àquilo do Apóstolo: Deu-o como cabeça, etc. Ora, o diabo não tem o poder de
influir a malícia do pecado, que procede da vontade do pecador. Logo, o diabo não pode ser chamado
cabeça dos maus.

2. Demais — Qualquer pecado torna o homem mau. Ora, nem todos os pecados vêm do diabo. O que é
manifesto pelos pecados dos demônios, que não pecaram por persuasão de outrem. Nem,
semelhantemente, todo pecado dos homens procede do diabo, como diz um autor: Nem todos os
nossos maus pensamentos são provocados por excitação do diabo; pois, às vezes, nascem do
movimento do nosso arbítrio. Logo, o diabo não é a cabeça de todos os maus.

3. Demais. — Uma cabeça dirige um corpo. Ora, parece que toda a multidão dos maus não se unem por
nenhum laço, pois, o mal é contrário ao mal, como diz Aristóteles; e também procede de defeitos
diversos na expressão de Dionísio. Logo, o diabo não pode ser chamado cabeça de todos os males.
Mas, em contrário, aquilo de Jó — A sua memória perecerá da terra. diz a Glosa: De todo homem-
iníquo se diz que volte para seu chefe, isto é, o diabo.

SOLUÇÃO. — Como dissemos, a cabeça não só influi interiormente nos membros, mas também governa
exteriormente, dirigindo-lhe os atos para um determinado fim. Por onde, quem é considerado chefe de
uma multidão o é da maneira seguinte: ou de ambos os modos, isto é, pelo influxo interior e pelo
governo exterior e nesse sentido Cristo é a cabeça da Igreja, como dissemos; ou pelo governo exterior, e
então qualquer príncipe ou prelado é cabeça da multidão que lhe está subordinada. E, neste sentido se
diz que o diabo é o chefe de todos os maus. Pois, como refere a Escritura, ele é o rei de todos os filhos
da soberba. Mas, o papel do governador é conduzir aos seus fins aqueles que governa. Ora, o fim do
diabo é afastar a criatura racional, de Deus; por isso tentou, desde o princípio, afastar o homem da
obediência ao preceito divino. Ora, o afastamento mesmo de Deus exerce a função de fim enquanto
desejado sob a forma de liberdade, segundo o Apóstolo: Tu desde o princípio quebraste o meu jugo,
rompeste os meus laços e disseste — não servirei. E na medida em que, pelo pecado, certos são levados
a esse fim, caem sob o regime e o governo do diabo, que, por isso, se lhes chama o chefe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o diabo não tenha nenhuma influência interior
na alma racional, contudo a induz ao mal pelo lhe sugerir.

RESPOSTA À SEGUNDA. — O governador nem sempre sugere a cada um dos seus súditos que lhe
obedeçam à vontade; mas propõe a todos um sinal dela, a cuja obediência certos são levados a se
conformarem e outros o fazem espontaneamente. Tal o procedimento do chefe de um exército, a cuja
bandeira seguem os soldados embora sem ninguém lhes persuadir. Assim, pois, o primeiro pecado do
diabo, que peca desde o principio, como diz a Escritura, foi proposta a todos para que o seguissem. O
que certos imitam por sugestão dele, e outros o fazem espontaneamente, sem nenhuma sugestão. E
assim, de todos os maus o chefe é o diabo, pelo imitarem, segundo a Escritura: Por inveja do diabo
entrou no mundo a morte, e a ela imitam os que são do seu partido.

RESPOSTA À TERCEIRA. — Todos os pecados tem de comum o fazerem nos afastarmos de Deus, embora
difiram uns dos outros por levarem a nos convertermos a diversos bens efémeros.

## Art. 8 — Se o Anti-Cristo é a cabeça dos maus.
O oitavo discute-se assim. — Parece que o Anti-Cristo não é a cabeça dos maus.

1. — Pois, um mesmo corpo não pode ter cabeças diversas. Ora, o diabo é a cabeça da multidão dos
maus. Logo, - o Anti-Cristo não é a cabeça deles.

2. Demais — O Anti-Cristo é membro do diabo. Ora, a cabeça se distingue dos membros. Logo, o Anti-
Cristo não é a cabeça dos maus.

3. Demais. — A cabeça influi nos membros Ora, o Anti-Cristo não teve nenhuma influência sobre os
maus homens que o precederam. Logo, o Anti-Cristo não é a cabeça dos maus.
Mas, em contrário, àquilo da Escritura — Perguntai a qualquer dos viandantes — diz a Glosa: Estando se
referindo ao corpo de todos os maus, de súbito converte as suas palavras ao Anti-Cristo, chefe de todos
os maus.

SOLUÇÃO. — Como dissemos, três coisas se encontram na cabeça natural - a ordem, a perfeição e a
virtude de influir. Ora, quanto à ordem do tempo, não é o Anti-Cristo considerado chefe dos maus,
como se o pecado dele tivesse tido a precedência, como a teve o do diabo. Nem semelhantemente, se
chama cabeça dos maus por causa do poder de influir. Pois, embora, no seu tempo, haja de converter
certos ao mal, induzindo-os exteriormente, contudo os que existiram antes dele não foram por ele
levados ao mal, nem lhe imitavam a malícia. E assim, neste sentido, não poderia ser chamado cabeça de
todos os maus, senão só de certos. Donde se conclui que é chamado cabeça de todos os maus por causa
da perfeição da malícia. Donde, àquilo do Apóstolo — ostentando-se como se fosse Deus — diz a Glosa:
Assim como em Cristo habitou toda a plenitude da divindade, assim no Anti-Cristo, a plenitude de toda
malicia. Não certo, que a sua humanidade seja assumida pelo diabo na unidade da pessoa, como a
humanidade de Cristo pelo Filho de Deus; mas porque o diabo lhe influirá de maneira mais eminente a
sua malícia, por sugestão, que aos outros todos. E, assim sendo, todos os outros maus que o
precederam, são uma como figuras do Anti-Cristo, segundo o Apóstolo: O mistério da iniquidade já de
presente se obra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O diabo e o Anti-cristo não são duas cabeças, mas uma
só; porque o Anti-cristo é chamado cabeça por ter plenissimamente impressa em si a malícia do diabo.
Donde, aquilo do Apóstolo — ostentando-se como se fosse Deus — diz a Glosa: Ele será a cabeça de
todos os males, isto é, o diabo, que é o rei de todos o filho da soberba. Mas não se diz que está nele por
uma união pessoal, nem por habitação intrínseca, pois, só a Trindade penetra na alma; senão, pelo
efeito da malícia.

RESPOSTA À SEGUNDA. — Assim como a cabeça de Cristo é Deus e contudo ele é a cabeça da Igreja,
segundo dissemos, assim o Anti-Cristo é membro do diabo e contudo é o chefe dos maus.

RESPOSTA À TERCEIRA. — Não se diz que o Anti-Cristo é a cabeça de todos os maus por semelhança de
influência, mas por semelhança de perfeição. Pois, nele o diabo levará a sua malícia ao cabo, por assim
dizer, no sentido em que dizemos de alguém que leva ao cabo o seu propósito, quando o realizou.