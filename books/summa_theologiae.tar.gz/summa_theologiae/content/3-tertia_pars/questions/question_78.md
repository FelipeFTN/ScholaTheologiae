# Questão 78: Da forma do sacramento da Eucaristia.
Em seguida devemos tratar da forma deste sacramento. E nesta questão discutem-se seis artigos:

## Art. 1 — Se esta é a forma deste sacramento: Isto é o meu corpo; e: Este é o cálice do meu sangue.
O primeiro discute-se assim. – Parece que esta não é a forma deste sacramento: Isto é o meu corpo; e:
este é o cálice do meu sangue.

1. — Pois, essas palavras parece pertencerem à forma do sacramento, com as quais Cristo consagrou o
seu corpo e o seu sangue. Ora, Cristo benzeu antes o pão que tomou, e depois disse: Tomai e comei, isto
é o meu corpo, como se lê no Evangelho. E o mesmo fez com o cálice. Logo, as referidas palavras não
são a forma deste sacramento.

2. Demais. — Eusébio Emisseno (Pseudônimo) diz: O sacerdote invisível converte no seu corpo as
criaturas visíveis, dizendo — Tomai e comei, isto é o meu corpo. Logo, parece que todas essas palavras
constituem a forma deste sacramento. E portanto o mesmo devemos dizer das palavras referentes ao
sangue.

3. Demais. — A forma do batismo exprime a pessoa do ministro e o seu ato, quando diz Eu te batizo.
Ora, as referidas palavras não fazem menção nenhuma da pessoa do ministro nem do seu ato. Logo, não
é a forma conveniente do sacramento.

4. Demais. — A forma do sacramento basta à perfeição dele. Por isso o sacramento do batismo pode às
vezes ser ministrado com a pronunciação das sós palavras da forma, omitindo-se todas as mais. Se, pois,
as palavras referidas são a forma deste sacramento, parece que às vezes ele poderá ser celebrado com a
só pronunciação delas, omitindo-se tudo o mais dito na missa. O que, contudo é falso, porque se as
outras palavras fossem omitidas, as de que se trata seriam aplicadas à pessoa do sacerdote que as
profere, em cujo corpo e sangue o pão e o vinho não se convertem. Logo, as referidas palavras não são a
forma deste sacramento.
Mas, em contrário, diz Ambrósio: A consagração se faz pelas palavras e expressões de Jesus, Senhor
Nosso, pois, todas as mais palavras que se pronunciam são ou em louvor de Deus, ou são orações em
que se pede pelo povo, pelos reis, pelos demais. Mas quando o sacerdote chega ao ponto de consumar
o venerável sacramento, já não emprega palavras suas, mas de Cristo. Logo, são as palavras de Cristo
que consumam esse sacramento.

SOLUÇÃO. — Este sacramento difere duplamente dos outros. — Primeiro, porque este se consuma pela
consagração da matéria; ao passo que os outros, pelo uso da matéria consagrada. — Segundo, porque
nos outros sacramento a consagração recebe instrumentalmente uma certa, virtude espiritual, que
mediante o ministro, que é um instrumento animado, pode agir como os instrumentos inanimados. Ao
passo que neste sacramento a consagração da substância, que só por Deus pode ser operada. Por onde,
o ministro, ao celebrar este sacramento, nenhum outro ato exerce senão o de pronunciar as palavras.
Ora, como a forma deve ter conveniência com o seu objeto, por isso a forma deste sacramento
duplamente difere da dos outros. — Primeiro, porque a forma dos outros implicam uso da matéria, por
exemplo, a ablução ou a assimilação; ao passo que a forma deste implica a só consagração da matéria,
consistente na transubstanciação. A saber, quando o sacerdote diz: Isto é o meu corpo, ou, este é o
cálice do meu sangue. — Segundo, porque as formas dos outros sacramentos são proferidas pela pessoa
do ministro. Quer o modo de quem pratica um ato, como quando diz — Eu te batizo, ou Eu te confirmo.
Quer de modo imperativo, como quando diz no sacramento da ordem — Por esta unção e pela nossa
intercessão, etc. Ao passo que a forma deste sacramento é proferida quase pela pessoa do próprio
Cristo, que fala. Para dar a entender que o ministro, ao celebrar este sacramento, outra causa não faz
senão o que significam as palavras de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Muitas são as opiniões relativas a esta matéria. Certos
(Prepositivo) disseram que Cristo, tendo o poder de excelência, nos sacramentos, celebrou este
sacramento sem nenhuma forma verbal; e depois proferiu as palavras com as quais outros no futuro
celebrassem. E é o que parecem significar as palavras de Inocência III, quando diz: Podemos sem engano
dizer que Cristo celebrou este sacramento pelo seu poder exprimindo depois a forma sob a qual os
pósteros deviam celebrá-lo. — Mas contra isto vão expressamente as palavras do Evangelho. que
referem que Cristo benzeu, cuja bênção com certas palavras foi dada. Por onde, as referidas palavras de
Inocência têm sentido, antes, opinativo que determinativo. Mas outros (Odon bispo cameracense)
disseram, que essa bênção foi dada com outras palavras que desconhecemos. — Mas nem isto é
sustentável. Porque a bênção da consagração é ora dada, pela narração do que então foi feito. Por
onde, se então essas palavras não operaram a consagração, nem operam. Por isso outros (Estevam,
Bispo eduense) disseram que a bênção foi lançada com as mesmas palavras com que agora o é. Mas
Cristo as pronunciou duas vezes: primeiro, secretamente, para consagrar; depois, manifestamente, para
instruir. Mas também isto não é sustentável. Porque o sacerdote consagra, proferindo tais palavras, não
como as tendo sido por Cristo numa bênção oculta, mas como as tendo proferido publicamente. Por
onde, essas palavras nenhuma força tendo senão pelas ter proferido Cristo, resulta que também Cristo,
ao proferi-las consagrou manifestamente. E por isso outros (Antissiod.) disseram, que os Evangelistas
não observam sempre a mesma ordem ao narrarem como se passaram as causas. conforme está claro
em Agostinho. Por onde, devemos entender que se pode exprimir assim a ordem dos fatos realizados:
Tomando o pão, benzeu-o dizendo — Isto é o meu corpo; e depois o fracionou e deu aos seus discípulos.
— Mas o mesmo sentido pode se dar às palavras do Evangelho sem as mudar. Pois, o particípio —
dizendo — implica uma certa concomitância das palavras proferidas, com as precedentes. Mas não é
preciso entender-se essa concomitância só em relação às palavras ultimamente proferidas, como se
Cristo então as tivesse proferidas, quando deu o pão aos seus discípulos. Mas podemos entender essa
concomitância em relação a tudo o precedente, sendo então o sentido: Enquanto benzia, partia e dava
aos seus discípulos, dizia: Tomai etc.

RESPOSTA À SEGUNDA. — Por estas palavras Tomai e comei — entende-se o uso da matéria
consagrada, não necessário para a validade deste sacramento, como estabelecemos. Por isso, também
essas palavras não são da substância da forma. — Como porem o emprego da matéria consagrada
contribui para maior perfeição do sacramento, assim como a operação não é a primeira, mas a segunda
perfeição do ser, por isso, todas essas palavras exprimem a perfeição total deste sacramento. E neste
sentido Eusébio entendeu que este sacramento se celebra, no tocante a primeira e a segunda perfeição.

RESPOSTA À TERCEIRA. — No sacramento do batismo, o ministro exerce uma certa ação sobre o uso da
matéria, que é da essência do sacramento; o que com este sacramento não se dá. Logo, não colhe a
comparação.

RESPOSTA À QUARTA. — Certos disseram que este sacramento não pode consumar-se pela prolação
das referidas palavras e a omissão de outras, sobretudo as do canon da missa. — Mas isto é
evidentemente falso. Quer em virtude das palavras de Ambrósio supra referidas. Quer também por não
ser o canon da missa o mesmo para todos, nem em todos os tempos, mas serem feitos acréscimos
diversos, por diversos. — Donde, devemos dizer, que se o sacerdote proferisse só as palavras referidas
com a intenção de celebrar este sacramento, celebrá-lo-ia. Pois a intenção faria com que essas palavras
se entendessem como proferidas pela pessoa de Cristo, mesmo se se deixassem de recitar as palavras
precedentes. Gravemente pecaria porem o sacerdote assim celebrando, por não observar o rito da
Igreja. Nem há símile com o batismo, sacramento de necessidade para a salvação; pois, a falta do
sacramento da Eucaristia pode supri-la a manducação espiritual, como diz Agostinho.

## Art. 2 — Se esta é a forma conveniente da consagração do pão: Isto é o meu corpo.
O segundo discute-se assim. — Parece que esta não é a forma conveniente da consagração do pão:
Isto é o meu corpo.

1. — Pois, a forma do sacramento deve exprimir-lhe o efeito. Ora, o efeito da consagração do pão é a
conversão da substância do pão no corpo de cristo, a qual antes se exprime pelo verbo — torna-se (fit)
— do que pelo verbo é. Logo, a forma da consagração deveria dizer: Isto se torna o meu corpo.

2. Demais. — Ambrósio diz: As palavras de Cristo obraram este sacramento. Que palavras de Cristo? As
pelas quais todas as causas foram feitas. O Senhor mandou e se fez o céu e a terra. Logo, também a
forma deste sacramento seria mais conveniente em forma imperativa, dizendo-se assim: Isto seja o meu
corpo.

3. Demais. — O sujeito dessa oração declara o que se converte; assim como o predicado, o termo da
conversão. Ora, assim como é determinado aquilo no que se faz a conversão, pois, ela não se faz senão
no corpo de Cristo; assim, é determinado o que é convertido, pois, só o pão é o convertido no corpo de
Cristo. Logo, como se emprega um nome relativo do predicado, também se deve empregar outro
relativo ao sujeito, de modo a dizer: este pão é o meu corpo.

4. Demais. — Assim como aquilo no que termina a conversão tem uma determinada natureza, pois é
corpo; assim também tem uma pessoa determinada. Logo, para determinar a pessoa deveria dizer-se:
Isto é o corpo de Cristo.

5. Demais. — Nas palavras da forma nada se deve introduzir que não lhe seja da substância. Logo, certos
livros acrescentam inconvenientemente a conjugação, pois, que não é da substância da forma.
Mas, em contrário, o Senhor usou dessa forma ao consagrar, como o refere o Evangelho.

SOLUÇÃO. — A referida forma da consagração do pão é a conveniente. Pois, como dissemos, a
consagração consiste na conversão do pão no corpo de Cristo. Ora, a forma do sacramento há de
necessariamente significar o que nele se opera. Por onde, a forma da consagração do pão deve significar
a conversão mesma do pão no corpo de Cristo. Na qual três coisas se consideram, a saber: a própria
conversão, o termo de origem e o termo final. Quanto à conversão, pode ser considerada à dupla luz: no
seu devir c na sua realização. Ora, a conversão nesta forma não devia significar como em devir, mas
como realização. — Primeiro, porque esta conversão não é sucessiva, como dissemos, mas instantânea:
pois, em tais transformações, o devir não é senão o ser realizado. — Segundo, porque as formas
sacramentais significam o efeito do sacramento, como as formas artificiais representam o efeito da arte.
Ora, uma forma artificial é semelhança do efeito último buscado pela intenção do artífice; assim como a
forma da arte na mente do edificador é principalmente a forma da casa edificada; e por consequência,
da edificação. Por isso, também esta forma deve exprimir a conversão como sendo a realização buscada
pela intenção. E a conversão exprimindo-se nesta forma como o que é realizado, necessàriamente os
extremos da conversão hão de ser significados do modo pelo qual existem em uma conversão realizada.
Pois então o termo final tem a natureza própria à sua substância; mas o termo de origem não
permanece na sua substância, mas só, nos seus acidentes, pelos Quais é percebida pelos sentidos e por
estes pode ser determinada. Por onde e convenientemente, o termo original da conversão se exprime
pelo pronome demonstrativo referido aos acidentes sensíveis, que permanecem. Ao passo que o termo
final é expresso pelo nome significativo da natureza do em que a conversão se faz, a saber, todo o corpo
de Cristo, e não só a carne, como dissemos. Por onde, é convenientemente a forma: Este é o meu corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O devir não é o efeito último desta consagração; mas o
ser feito, como se disse. Por onde, isto deve de preferência ser expresso na forma.

RESPOSTA À SEGUNDA. — As palavras de Deus observam na criação das coisas, que também obram
nesta consagração. Mas de maneiras diferentes. Pois, aqui obram efetiva e sacramentalmente, isto é,
por força da sua significação. Por isso, nas palavras sacramentais é mister que o efeito último da
consagração seja significado pelo verbo substantivo no modo indicativo e no tempo presente. — Ao
passo que, na criação das coisas essas palavras observam só efetivamente, eficiência resultante do
império da sua sabedoria. Por isso, na criação das coisas a palavra divina exprimiu-se com o verbo no
modo imperativo, segundo àquilo da Escritura: Faça-se a luz, e foi feita a luz.

RESPOSTA À TERCEIRA. — O termo de origem, no fato mesmo da conversão, não conserva a natureza
de sua substância, como o termo final. Logo o símile não colhe.

RESPOSTA À QUARTA. — O pronome meu, indicativo da primeira pessoa, a pessoa que fala, exprime
suficientemente a pessoa de Cristo, à qual as referidas palavras se referem.

RESPOSTA À QUINTA. — A conjunção — pois acrescentou-se na forma, por costume da Igreja Romana,
derivado de S. Pedro Apóstolo. E isto, para ter continuidade com as palavras precedentes. Por onde, não
faz parte da forma, como dela não o fazem as palavras precedentes.

## Art. 3 — Se esta é a forma conveniente da consagração do vinho: Este é o cálice do meu sangue...
O terceiro discute-se assim. — Parece que esta não é a forma conveniente da consagração do vinho:
Este é o cálice do meu sangue, do novo e eterno testamento, mistério da fé, que será derramado por
vós e por muitos, para remissão de pecados.

1. — Pois, assim como o pão se converte no corpo de Cristo em virtude da consagração assim também o
vinho no sangue de Cristo conforme do sobredito se colhe. Ora na forma da consagração a palavra pão
está no caso recto (panis), significando o corpo de Cristo, nem se lhe faz nenhum acréscimo. Logo, está,
na forma, inconvenientemente posto num caso oblíquo a expressão sangue de Cristo (sanguinis),
acrescentando-se a palavra cálice no caso recto (calix), quando se diz: Este é o cálice do meu sangue.

2. Demais. — Não têm maior eficácia as palavras proferidas na consagração do pão, que as proferidas e
a consagração do vinho, sendo todas palavras de Cristo. Ora, uma vez pronunciadas as palavras — Isto é
o meu corpo, consuma-se a consagração do pão. Logo, desde que forem pronunciadas as palavras —
Este é o cálice do meu sangue, está perfeita a consagração do sangue. E assim, as palavras seguintes não
parece serem da substância da forma, sobretudo por exprimirem propriedades deste sacramento.

3. Demais. — O Testamento Novo parece constituir uma inspiração interna, como resulta das palavras
de Jeremias citadas pelo Apóstolo: Consumarei sobre a casa de Israel um testamento novo, imprimindo
a minha lei nas suas entranhas. Ora, o sacramento opera de um modo visível. Logo, está
inconvenientemente dito na forma: do novo Testamento.

4. Demais. — Chama-se novo o que é propriamente o princípio do seu ser. Ora, o eterno não tem
princípio do seu existir. Logo, está inconvenientemente dito — do novo e do eterno, pois implica uma
contradição.

5. Demais. — Devemos evitar aos outros, ocasiões de erro, segundo àquilo da Escritura: Tirai os tropeços
do caminho do meu povo. Ora, certos erraram, pensando que o corpo e o sangue de Cristo só
misticamente estão neste sacramento. Logo, na forma se acrescenta inconvenientemente: mistério da
fé.

6. Demais. — Conforme se disse, assim como o batismo é o sacramento da fé. E assim a Eucarisia é o
sacramento da caridade. Logo, na forma se devia pôr, antes, caridade, que, fé.

7. Demais. — Todo este sacramento, tanto no concernente ao corpo como ao sangue, é um memorial da
paixão do Senhor, segundo àquilo do Apóstolo: Todas as vezes que comerdes este pão e beberdes este
cálice, anunciareis a morte do Senhor. Logo, na forma da consagração do sangue não se devia, mais do
que na da consagração do corpo, fazer-se menção da paixão de Cristo, sobretudo que o Senhor disse:
Isto é o meu corpo, que se dá por vós.

8. Demais. — A paixão de Cristo, como se disse, quanto à sua suficiência, aproveita a todos; mas, quanto
à sua eficiência, aproveita a muitos. Logo, a forma devia dizer — será derramado por todos, ou por
muitos, sem se acrescentar — por vós.

9. Demais. — As palavras com que se celebram este sacramento haurem a sua eficácia na instituição de
Cristo. Ora, nenhum Evangelista refere às tivesse Cristo pronunciado. Logo, não é conveniente a forma
da consagração do vinho.
Mas, em contrário, a Igreja, instituída pelos Apóstolos, usa dessa forma na consagração do vinho.

SOLUÇÃO. Sobre esta forma duas são as opiniões. Uns (Alex. Hal. S, Boav., P. de Tarant), disseram que
da substância desta forma são só as palavras — Este é o cálice do meu sangue; mas não as que se lhe
seguem. — Mas isto é inadmissível porque as palavras seguintes são umas determinações do predicado,
isto é, do sangue de Cristo; e portanto pertencem à integridade da locução. E por isso outros dizem,
melhor, que todas as palavras seguintes são da substância da forma. até o que depois se segue: —
Todas as vezes que o fizerdes significativas do uso deste sacramento, sem fazerem parte da substância
da forma. Donde vem que o sacerdote profere todas essas palavras no mesmo rito e modo, isto é, tendo
o cálice nas mãos. Mas no Evangelho de S. Lucas, interpõem-se as primeiras, as palavras seguintes: Este
é o novo testamento em meu sangue. Donde devemos concluir que todas as palavras referidas são da
substância da forma. Mas as primeiras — Este é o cálice do meu sangue significam a conversão mesma
do vinho no meu sangue, do modo que referimos na forma da consagração do pão. As palavras
seguintes designam a virtude do sangue derramado na paixão, que obra neste sacramento. As quais têm
um tríplice fim. — Primeira e principalmente, fazer-nos alcançar a herança eterna, segundo àquilo do
Apóstolo: Tende confiança de entrar no santuário, pelo sangue de Cristo. E para significá-lo diz a forma:
do novo e eterno Testamento. Segundo para a justificação da graça, que é pela fé, segundo aquilo do
Apóstolo: Ao qual propôs Deus para ser vítima de propiciação pela fé no seu sangue, a fim de que ele
seja achado justo e justificador de aquele que tem a fé de Jesus Cristo. Por isso na forma se diz: mistério
da fé. — Terceiro, para remover os pecados impedimentos à herança eterna e à justificação da graça,
segundo aquilo do Apóstolo: O sangue de Cristo alimpará a nossa consciência das obras da morte, isto é,
dos pecados. E por isso se acrescenta: Que será derramado por vós e por muitos para remissão de
pecados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A locução — Este é o cálice do meu sangue — é figurada.
E pode ser entendida em duplo sentido: — Primeiro por metonímia, que põe o continente pelo
conteúdo, sendo o sentido: Este é o meu sangue contido no cálice. Do qual se faz aí menção, porque o
sangue de Cristo é consagrado neste sacramento como bebida dos fiéis, o que não está incluído na idéia
de sangue; donde a necessidade de ser isso significado pelo vaso acomodado a tal uso. — Em outro
sentido, podemos tomá-lo metaforicamente, entendendo-se pelo cálice, e por semelhança, a paixão de
Cristo, que, como o cálice, inebria, segundo aquilo da Escritura: Encheu-me de amargura, embriagou-me
de absinto. Donde o chamar o próprio Senhor à sua paixão, cálice quando disse: Passe de mim este
cálice. De modo que o sentido da forma é: Este é o cálice da minha paixão. Da qual se faz menção,
quanto ao sangue, reparadamente do corpo consagrado; porque a paixão operou a separação entre o
corpo e o sangue.

RESPOSTA À SEGUNDA. — Como se disse, o sangue, consagrado separadamente, representa de modo
expressivo a paixão de Cristo. Por isso, na consagração do sangue, se faz menção do efeito da paixão, de
preferência a fazê-lo na consagração do corpo, que é o sujeito da paixão. O que também está significado
nas palavras do Senhor — que será entregue por vós, quase dizendo que será sujeito à paixão por vós.

RESPOSTA À TERCEIRA. — O testamento é a disposição da herança. Ora, a herança celeste o senhor
dispôs, que devia ser dada aos homens pela virtude do sangue de Cristo Jesus. Pois, como diz o
Apóstolo, onde há um testamento, é necessário que intervenha a morte do testador. Ora, o sangue de
Cristo foi derramado duas vezes pelos homens. — Primeiro, em figura, na vigência do Testamento
Velho. Por isso o Apóstolo conclui no mesmo lugar: Por onde, nem ainda o primeiro testamento foi
celebrado sem sangue. O que é claro, pelo dito do Exodo: Moisés, depois de ter lido todas as
ordenações da lei, aspergiu todo o povo dizendo: Eis o sangue do testamento que Deus fez convosco —
segundo, foi derramado verdadeira e realmente, como o sabemos pelo Testamento Novo. Por onde, o
Apóstolo no mesmo lugar, tinha dito antes: Por isso Cristo é mediador de um novo testamento, para
que, intervindo a morte, recebam a promessa da herança eterna os que têm sido chamados. Dai o dizer
a forma diz — sangue do Novo Testamento, por ter sido derramado, não já em figura, mas
verdadeiramente. — Por isso se acrescenta: que será derramado por vós. — Quanto à inspiração
interna, ela procede da virtude do sangue, porque somos justificados pela paixão de Cristo.

RESPOSTA À QUARTA. — O Testamento Novo o é em razão da sua manifestação. Mas é considerado
eterno, tanto em razão da eterna pré-ordenação de Deus, como pela razão da herança eterna, disposta
por meio deste Testamento. Também a pessoa mesma de Cristo, pelo sangue de quem foi o Testamento
disposto, é eterna.

RESPOSTA À QUINTA. — A palavra mistério é usada na forma, não por excluir a verdadeira realidade,
mas por mostrar a sua ocultação. Pois, o sangue mesmo de Cristo está neste sacramento de modo
oculto; e a própria paixão de Cristo foi figurada ocultamente no Testamento Velho.

RESPOSTA À SEXTA. — A expressão — mistério da fé — significa o quase objeto da fé; porque só pela fé
sabemos que o sangue de Cristo está verdadeiramente neste sacramento. E também a paixão mesma de
Cristo justifica pela fé, Quanto ao batismo, chama-se sacramento da fé, por ser uma protestação dela. —
Mas este é o sacramento da caridade, pela figurar e produzir.

RESPOSTA À SÉTIMA. — Como dissemos, o sangue, consagrado separadamente do corpo, representa de
maneira mais expressiva a paixão de Cristo. Por isso, na consagração do sangue, antes que na
consagração do corpo, faz-se menção da paixão de Cristo e do seu fruto.

RESPOSTA À OITAVA. — O sangue da paixão de Cristo não só tinha eficácia para os judeus eleitos, por
quem era derramado o sangue do Testamento Velho, mas também para os gentios. Nem só para os
sacerdotes, que celebram esse sacramento, ou para os que o recebem, mas também para aqueles por
quem é oferecido. Por isso diz a forma sinaladamente — por vós, judeus; e por muitos, isto é, pelos
gentios; ou — por vós, os que comeis, e — por muitos por quem é oferecido.

RESPOSTA À NONA. — Os Evangelistas não intencionavam transmitir as formas dos sacramentos que na
Igreja primitiva deveriam ser ocultas, como diz Dionísio: mas intencionavam narrar a história de Cristo. –
E, contudo quase todas as palavras das formas podem ser deduzidas de diversos lugares da Escritura.
Assim o dito — Este é o cálice — Está em S. Lucas e no Apóstolo. E Mateus diz: — este é o meu sangue
do novo testamento, que será derramado por muitos, para remissão de pecados. – Quanto à expressão
do eterno, e a outra mistério da fé, fundam-se na tradição do Senhor, transmitida à Igreja pelos
Apóstolos, segundo o lugar: Eu recebi do Senhor o que também vos ensinei a vós.

## Art. 4 — Se as referidas palavras das formas encerram alguma virtude criada, efetiva da consagração.
O quarto discute-se assim. — Parece que as referidas palavras das formas não encerram nenhuma
virtude criada, efetiva da consagração.

1. — Pois, diz Damasceno: Pela só virtude do Espírito Santo se opera a conversão do pão no corpo de
Cristo. Ora, a virtude do Espírito Santo é uma virtude incriada. Logo, este sacramento não se consuma
por nenhuma virtude criada das referidas palavras.

2. Demais. — Nenhum poder criado pode fazer obras milagrosas, mas só o poder divino, como se
estabeleceu na Primeira Parte. Ora, a conversão do pão e do vinho no corpo e no sangue de Cristo é
obra não menos milagrosa que a criação do mundo ou mesmo que a formação do corpo de Cristo no
ventre virginal — causas que nenhum poder criado poderia fazer. Logo, nem este sacramento é
consagrado por nenhuma virtude criada das referidas palavras.

3. Demais. — As referidas frases não são simples, mas compostas de muitas; nem se proferem
simultânea, senão sucessivamente. Ora, a conversão discutida se opera instantaneamente, como se
disse. Logo, há de fazer-se por uma virtude simples e não por virtude das referidas palavras.
Mas, em contrário, diz Ambrósio: Se tão grande poder, tem a palavra de N. S. Jesus Cristo, a ponto de
fazer existir o que não existia, com quanto maior razão não é capaz de transformar o ser já existente,
em outro? Assim, o que era pão antes da consagração, já é corpo de Cristo, depois dela, porque a
palavra de Cristo pode mudar a criatura.

SOLUÇÃO. — Alguns disseram, que as referidas palavras nenhuma virtude criada tem para obrar a
transubstanciação, nem as formas dos outros sacramentos, ou mesmo os próprios sacramentos, para
produzir os efeitos deles. — Ora, isto como já estabelecemos, repugna às palavras dos Santos e derroga
a dignidade dos sacramentos da Lei Nova. Por onde, sendo este sacramento o mais digno de todos,
conforme estabelecemos, resulta por consequência, que as suas palavras formais têm uma certa virtude
criada para obrar a conversão que nele se opera. Mas virtude instrumental, como a do outros
sacramentos, conforme dissemos. Ora, sendo as referidas palavras proferidas em nome de Cristo, por
disposição dele recebem uma virtude instrumental; assim como os demais atos ou ditos seus tem uma
virtude salutífera instrumental, conforme mostramos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dizer-se que pela só virtude do Espírito Santo o pão se
converte no sangue de Cristo, não exclui a virtude instrumental, que é a forma deste sacramento. Como
o dizer-se que o ferreiro faz uma faca, por si só, não exclui a virtude do martelo.

RESPOSTA À SEGUNDA. — Obras milagrosas nenhuma criatura pode fazê-las, como agente principal;
pode porém fazê-las como agente instrumental, como quando o simples contacto da mão de Cristo
curou o leproso. E deste modo as palavras de Cristo convertem o pão no corpo de Cristo. O que não
podia dar-se na concepção, pela qual se formou o corpo de Cristo, de modo que qualquer· ação
procedente desse corpo tivesse a virtude instrumental de o formar. Também na criação nenhum
extremo houve que pudesse ser o termo da ação instrumental da criatura. Logo o símile não colhe.

RESPOSTA À TERCEIRA. — As referidas palavras, que obram a consagração, operam sacramentalmente.
Por onde, a virtude conversiva das formas deste sacramento, resulta da significação; completa com a
prolação da última dicção. Por onde, no último instante da prolação das referidas palavras, elas se
revestem da virtude em questão; ordenadamente, porém, às precedentes. E tal virtude é simples em
razão do significado; embora as palavras exteriormente proferidas tenham uma certa composição.

## Art. 5 — Se as referidas locuções são verdadeiras.
O quinto discute-se assim. — Parece que as referidas locuções não são verdadeiras.

1. — Pois, na expressão — Isto é o meu corpo — o vocábulo — isto — é designativo da substância. Ora,
conforme foi dito, quanto se profere o pronome — isto — ainda é existente a substância do pão; porque
o transubstanciação se opera no último instante da prolação das palavras. Ora, esta proposição é falsa.
— O pão é o corpo de Cristo. Logo, também est’outra o é: Isto é o meu corpo.

2. Demais. — O pronome — isto — designa alguma coisa aos sentidos. Ora, as espécies sensíveis, neste
sacramento, nem são o corpo mesmo de Cristo, nem acidentes dele. Logo. esta SOLUÇÃO. não pode ser
verdadeira — Isto é o meu corpo.

3. Demais. — Estas palavras, como se disse, pela sua significação, produzem a conversão do pão no
corpo de Cristo. Ora, a causa eficiente nós a concebemos como anterior ao efeito. Logo, a significação
dessas palavras se entende com anterior à conversão do pão nó corpo de Cristo. Ora, antes da
conversão, é falsa a preposição — Isto é o meu corpo. Logo, devemos julgá-la como falsa,
absolutamente falando. E o mesmo se dá com a locução — isto é o cálice do meu sangue, etc.
Mas, em contrário, estas palavras são proferidas da pessoa de Cristo, que de si diz: Eu sou a verdade.

SOLUÇÃO. — Nesta matéria são muitas as opiniões. Uns (Inoc. III) disseram que na locução — Isto é o
meu corpo — adição — isto — implica uma designação concebida e não, realizada; pois, toda esta
locução é tomada materialmente, quanto proferida declarativamente. Assim, o sacerdote declara ter
dito — Isto é o meu corpo. Mas esta opinião é insustentável. Porque, segundo ela, as referidas palavras
não se aplicariam à matéria corporal presente de modo que o sacramento não se celebraria. Por isso diz
Agostinho: Acrescentou-se a palavra ao elemento e resultou o sacramento. — Nem assim não se evita
totalmente a dificuldade desta questão. Pois, as mesmas dificuldades permanecem relativamente à
primeira prolação, com que Cristo proferiu tais palavras. Por onde é claro, que não foram tomadas
materiais, mas, significativamente. Donde devemos concluir que, mesmo proferidas pelo sacerdote, são
tomadas significativa e não só materialmente. — Nem atesta que o sacerdote as profira
declarativamente, como se fossem ditas por Cristo. Porque, pelo infinito poder de Cristo, assim como
pelo contacto da sua carne, a virtude regenerativa foi infundida, não só naquelas águas que o tocaram,
mas em todas as águas da terra, por todos os séculos futuros; assim também, pela prolação do próprio
Cristo, as palavras formais adquiriram a virtude de consagrar, ditas seja por que sacerdote for, como se
o próprio Cristo fosse quem as pronunciasse. Por isso outros (Alex. Hal.) disseram que a partícula — isto
— nesta locução, designa não aos sentidos, mas à inteligência, significando — Isto é o meu corpo, isto é,
o que isto significa é o meu corpo. — Mas também tal é insustentável. Porque, como, nos sacramentos,
o significado é realizado, não estaria por essa forma verdadeiramente o corpo de Cristo neste
sacramento. Mas só como em sinal. O que e herético, como dissemos. E por isso outros disseram que o
pronome — isto — faz uma designação aos sentidos; mas essa designação se entende como realizada
não no instante da locução em que a partícula é proferida, mas no último instante da locução. Assim
como quando dizemos — agora me calo — o advérbio agora designa o instante imediatamente seguinte
à locução, sendo o sentido — assim que forem ditas essas palavras, calo-me. — Mas também isto é
inadmissível. Porque então, o sentido da locução discutida seria — o meu corpo é o meu corpo. O que
não é o significado da locução, pois, assim já era mesmo antes da prolação das palavras. Por onde, nem
isso significa a referida locução.
Portanto, devemos dizer de outro modo, que, como ficou estabelecido, esta locução tem a virtude de
operar a conversão do pão no corpo de Cristo. E assim está para as outras locuções, cuja força é apenas
significativa e não eficiente como está à concepção do intelecto prático. que é eficiente realmente, para
a concepção do nosso intelecto especulativo, derivada das coisas; pois, as vozes são sinais do intelecto,
segundo o Filósofo. Por onde, assim como a concepção do intelecto prático não pressupõe a causa
concebida, mas a faz, assim, a verdade desta locução não pressupõe a causa significa da, mas a produz;
pois, tal é a relação da palavra de Deus com as coisas feitas pelo verbo. Essa conversão, porém não se
opera sucessivamente, mas num instante, como dissemos. Por onde, havemos de entender a referida
locução relativamente ao último instante da prolação das palavras. Não, porém supondo, em relação ao
sujeito, aquilo que é o termo da conversão, a saber, que O corpo de Cristo seja o corpo de Cristo. Nem
também o que existia antes da conversão, a saber, o pão. Mas o que se refere em comum a um e outro,
isto é, o conteúdo em geral de essas espécies. Pois, não fazem essas palavras com que o corpo de Cristo
seja o corpo de Cristo; nem que o pão seja o corpo de Cristo; mas, que o conteúdo dessas espécies, que
antes era pão, seja o corpo de Cristo. Por isso o Senhor não diz sinaladamente — este pão é o meu
corpo — o que estaria de acordo com o modo de entender da segunda opinião. Nem — este meu corpo
é o meu corpo — o que o estaria com o modo de entender da terceira. Mas em geral — Isto é o meu
corpo — sem acrescentar nenhum nome relativo ao sujeito, mas empregando apenas o pronome, que
significa a substância em geral, sem nenhuma qualidade, isto é, sem forma determinada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A dicção — isto — designa a substância, mas sem
determinação da natureza própria, como se disse.

RESPOSTA À SEGUNDA. — O pronome — isto não designa os acidentes, mas a substância sob eles
contida, o qual de pão, que era, veio a ser o corpo de Cristo, que, embora não informado por esses
acidentes, está contudo, contado sob eles.

RESPOSTA À TERCEIRA. — A significação desta locução se pre-intelige à realidade significada, na ordem
da natureza, assim como a causa é naturalmente anterior ao efeito. Mas não em a ordem do tempo,
pois, esta causa produz simultaneamente consigo o seu efeito. E isto basta à verdade da locução.

## Art. 6 — Se a forma da consagração do pão não produz o seu efeito até que se profira a forma da consagração do vinho.
O sexto discute-se assim. — Parece que a forma da consagração do pão não produz o seu efeito, até
que se profira a forma de consagração do vinho.

1. — Pois, assim como pela consagração do pão começa o corpo de Cristo a estar neste sacramento,
assim, pela consagração do vinho começa a nele estar o sangue. Se, pois, as palavras da consagração do
pão produzissem o seu efeito, antes da consagração do vinho, resultaria neste sacramento a existência
do corpo de Cristo, sem o sangue. O que é inadmissível.

2. Demais. — Cada sacramento tem o seu complemento; por onde, embora no batismo haja três
imersões, contudo a primeira não produz o seu efeito antes de estar terminada a terceira. Ora, todo o
sacramento da Eucaristia é uno, como se disse. Logo, as palavras com que se consagra o pão não
produzem o seu efeito sem as palavras sacramentais com que é consagrado o vinho.

3. Demais. — Na forma mesma da consagração do pão há várias palavras, a primeira das quais não
produz o seu efeito sem a prolação da última, conforme se disse. Logo e pela mesma razão, nem as
palavras com que se consagra o corpo de Cristo têm efeito, senão pronunciadas as com que é
consagrado o sangue de Cristo.
Mas, em contrário, logo que são pronunciadas as palavras da consagração do pão, a hóstia consagrada é
oferecida à adoração do povo. O que não se daria se nela não estivesse o corpo de Cristo; o contrário
constituiria idolatria. Logo, as palavras da consagração do pão produzem o seu efeito, antes de
proferidas as da consagração do vinho.

SOLUÇÃO. — Certos doutores antigos disseram que as duas formas — a da consagração do pão e a do
vinho dependem nos seus efeitos uma da outra. De modo que a primeira não produz o seu efeito, antes
de proferida a segunda. Mas isto não pode ser. Porque, como dissemos, para ser verdadeira a locução
— Isto é o meu corpo — é necessário, por causa do verbo no tempo presente, que a realidade significa
da seja simultânea no tempo com a significação mesmo da locução. Do contrário, se se esperasse, como
futura, a realidade significada, o verbo seria usado no tempo futuro e não no presente. De modo que
não se diria — Isto é o meu corpo — mas isto será o meu corpo. Pois, o significado desta locução se
realiza logo que as suas palavras foram completamente pronunciadas. Por onde, há de a realidade
significa da existir desde então, que é o efeito deste sacramento; do contrário a locução não seria
verdadeira. — Além disso, a referida opinião encontra o rito da Igreja, que adora o corpo de Cristo
imediatamente depois da prolação das palavras. Donde devemos concluir que a primeira forma não
depende da segunda para produzir o seu efeito, mas o produz imediatamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por essa razão se enganaram os que se colocaram em tal
posição. Donde devemos concluir que, feita a consagração do pão, transforma-se ele no corpo de Cristo
em virtude do sacramento; e o sangue também, por concomitância real. E em seguida, e inversamente
pela consagração do vinho, este se torna no sangue de Cristo; e o corpo também por concomitância
real. De modo Que Cristo está todo numa e noutra espécie, como dissemos.

RESPOSTA À SEGUNDA. — Este sacramento é uno em sua perfeição, como dissemos, por ser constituído
de dois elementos, a comida e a bebida. cada um dos quais tem por si a sua perfeição. Ao passo que as
três imersões do batismo se ordenam a um único efeito. Logo, o símile não colhe.

RESPOSTA À TERCEIRA. — As diversas palavras da forma da consagração do pão constituem
verdadeiramente uma só locução; mas não as palavras das diversas formas. Logo, o simile não colhe.