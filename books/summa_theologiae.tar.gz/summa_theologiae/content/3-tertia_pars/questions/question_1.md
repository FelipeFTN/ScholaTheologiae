# Questão 1: Da conveniência da encarnação
No primeiro ponto três questões devem ser tratadas. A primeira, sobre a conveniência da Encarnação de
Cristo. A segunda, do modo de união do Verbo encarnado. A terceira, dos resultados dessa união.
Na primeira questão discutem-se seis artigos:
Art. 1 —Se foi conveniente que Deus se encarnasse.
O primeiro discute-se assim. — Parece que não foi conveniente que Deus se encarnasse.

1. — Pois, sendo Deus abeterno a mesma bondade essencial, melhor é existir ele como abeterno existiu.
Ora, Deus existiu abeterno sem nenhuma carne. Logo, convenientíssimo lhe era não se unir à carne.
Portanto, não foi conveniente que Deus se encarnasse.

2. Demais. — Seres infinitamente diferentes inconvenientemente se unem; assim, faria inconveniente
junção quem pintasse uma imagem, onde se ligasse a uma cabeça humana um pescoço de cavalo. Ora,
Deus e a carne diferem infinitamente; pois, ao passo que Deus é simplicíssimo, a carne é composta, e
sobretudo a humana. Logo, foi inconveniente que Deus se tivesse unido à carne humana.

3. Demais. — O corpo dista do sumo espírito tanto quanto a malícia, da suma bondade. Ora,
absolutamente inconveniente era que Deus, a suma bondade, assumisse a malícia. Logo, não foi
conveniente que o sumo espírito incriado assumisse um corpo.

4. Demais. — É inconveniente estar contido num ser mínimo o que excede os grandes; e que se aplique
a coisas pequenas aquele a quem incumbe cuidado das grandes. Ora, toda a universidade das coisas não
é suficiente a abranger a Deus, que exerce o governo de todo o mundo. Logo parece inconveniente
esconder-se no corpinho de uma criança, a vagir, aquele em cuja comparação é nada o universo; e um
tal, rei, abandonar tão longamente as suas moradas e transferir para um corpúsculo o governo de todo
o mundo, como Volusiano escreve a Agostinho.
Mas, em contrário. — Convenientíssimo parece que as coisas invisíveis de Deus se manifestem pelas
visíveis; pois, para tal foi feito todo o mundo, segundo as palavras do Apóstolo (Rom 1, 20) — As coisas
invisíveis de Deus se vêem consideradas pelas obras que foram feitas. Ora, como diz Damasceno, pelo
mistério da encarnação se manifesta ao mesmo tempo a bondade, a sabedoria, a justiça e o poder ou
virtude de Deus. A bondade, pois não desprezou a fraqueza da sua própria criatura; a justiça porque não
deu a outrem senão ao homem o poder de vencer o tirano, nem livrou o homem da morte pela
violência; a sabedoria, porque deu a mais cabal solução a um problema dificílimo; o poder enfim ou a
virtude infinita, pois nada há de maior ao fato de Deus ter-se feito homem. Logo, foi conveniente Deus
ter-se encarnado.

SOLUÇÃO. — A cada coisa é conveniente o que lhe cabe segundo à essência da sua própria natureza;
assim, convém ao homem raciocinar por ser de natureza racional. Ora, a natureza mesma de Deus é a
bondade, como está claro em Dionísio. Por onde, tudo o que pertence essencialmente ao bem convém a
Deus. Ora, pertence essencialmente ao bem o comunicar-se aos outros, como está claro em Dionísio.
Por onde, pertence à essência do sumo bem comunicar-se de maneira suma à criatura. O que sobretudo
se realiza por ter-se a si mesmo unido a natureza criada, de modo a fazer uma só pessoa dos três o
Verbo, a alma e a carne como diz Agostinho. Por onde, é manifesto que foi conveniente que Deus se
tivesse encarnado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. O mistério da Encarnação não se realizou porque tivesse
Deus, de certo modo, obtido uma mudança do seu estado para outro, em que não existia abeterno;
mas, por ter-se unido de um modo novo com a criatura, ou antes, a criatura a si: Pois, é conveniente que
a criatura, mutável por natureza, não se apresente sempre do mesmo modo. Por onde, assim como a
criatura, que primeiro não existia, foi depois produzida, assim também, não estando desde o princípio
unida a Deus, veio depois a lhe ser unida.

RESPOSTA À SEGUNDA. — Ser unida a Deus, na unidade de pessoa, não era conveniente à carne
humana, pela condição da sua natureza, porque isso lhe sobrepujava a dignidade dela. Mas, foi
conveniente a Deus, pela infinita excelência da sua bondade uni-la a si, para a salvação humana.

RESPOSTA À TERCEIRA. — Qualquer outra condição, pela qual cada criatura difere do Criador, foi
instituída pela sabedoria de Deus e ordenada à bondade divina. Pois, Deus pela sua bondade, sendo
incriado, imutável e incorpóreo, produziu criaturas mutáveis e corpóreas; e semelhantemente o mal da
pena foi introduzido pela justiça de Deus em vista da sua glória. Quanto ao mal da culpa, ele procede
pelo afastamento da arte da sabedoria divina e da ordem da bondade divina. Por onde, podia ser
conveniente a Deus assumir a natureza criada, mutável, corpórea e sujeita à penalidade: mas não lhe
era assumir o mal da culpa.

RESPOSTA À QUARTA. — Agostinho responde: A doutrina Cristã não ensina que Deus, por ter-se unido à
carne humana, abandonou ou perdeu o exercício do governo universal, ou encerrou-o, como que
compresso nesse corpúsculo. Mas são esses pensamentos do homem, só capaz de cogitar no que é
corpóreo, Pois, Deus é grande, não como uma mole, mas, pela sua virtude. Por isso, a grandeza da sua
virtude não se comprimiu com a exiguidade local. Não é, portanto, incrível ao passo que o verbo
transitório do homem, seja total e simultaneamente ouvido por muitos e por cada um, que o Verbo
Deus, permanente, esteja total e simultaneamente em toda parte. Por onde, nenhum inconveniente
resulta para Deus encarnado.

## Art. 2 — Se foi necessário, para a salvação do gênero humano, que o Verbo de Deus se encarnasse.
O segundo discute-se assim. — Parece que não foi necessário, para a salvação do gênero humano, que
o Verbo de Deus se encarnasse.

1. — Pois, o Verbo de Deus, sendo Deus perfeito, como demonstramos (Ia., q. 27, a. 2, ad 2; q. 4, a. 1, 2),
nenhuma virtude se lhe acrescentou, por ter assumido a carne. Se, pois, o Verbo encarnado de Deus
reparou a natureza humana, podia tê-la reparado mesmo sem ter assumido a carne.

2. Demais. — A reparação da natureza humana, caída no pecado, parece que nada mais exigia senão
que o homem satisfizesse pelo seu pecado. Pois, Deus não deve exigir do homem mais do que ele pode
fazer. E, sendo antes inclinado a compadecer-se do que punir, assim como imputa ao homem o ato do
pecado, assim também parece que lhe há de imputar, para delir o pecado, o ato contrário. Logo, não foi
necessário, para a reparação da natureza humana, que o Verbo de Deus se encarnasse.

3. Demais. — Para salvar-se o homem deve sobretudo honrar a Deus; donde o dizer a Escritura (Ml 1,
6): Se eu sou vosso Senhor, onde está o temor que se me deve? Mas, por isso mesmo os homens mais
honram a Deus, que o consideram mais elevado que todas as coisas e mais remoto dos sentidos dos
homens. Donde o dito da Escritura (Sl 112, 4): Excelso é o Senhor sobre todas as gentes e a sua glória é
sobre os céus. E depois acrescenta: Quem há como o Senhor nosso Deus? O que respeita a reverência.
Logo, parece que não convinha à salvação humana que Deus se fizesse semelhante a nós pela assunção
da carne.
Mas, em contrário. — Aquilo pelo que o gênero humano é livrado da perdição é necessário à salvação
humana. Ora, tal é o mistério da divina Encarnação, segundo o Evangelho (Jo 3, 16): Assim amou Deus
ao mundo, que lhe deu a seu Filho unigênito, para que todo o que nele crê não pereça, mas tenha a vida
eterna. Logo, foi necessário, para a salvação humana, que Deus se encarnasse.

SOLUÇÃO. — De dois modos pode uma coisa ser considerada necessária para um determinado fim.
Primeiro, como aquilo sem o que o fim não pode existir; assim, o alimento é necessário à conservação
da vida humana. De outro modo, como o meio pelo qual melhor e mais convenientemente se chega ao
fim: assim, o cavalo é necessário para viajar. — Do primeiro modo não era necessário, para a reparação
da natureza humana, que Deus se encarnasse. Pois, pela sua onipotente virtude, Deus podia reparar por
muitos outros modos a natureza humana. — Do segundo, modo, era necessário que Deus se
encarnasse, para a reparação da natureza humana. Por isso, Agostinho diz: mostremos que não faltava a
Deus nenhum outro modo possível, a cujo poder todas as coisas estão igualmente sujeitas; mas, não
existia nenhum outro modo mais conveniente para obviar à nossa miséria.
E isto podemos considerar relativamente à promoção do homem no bem. — Primeiro, quanto à fé, que
mais se certifica por crer na palavra mesma de Deus, Donde o dizer Agostinho: Para que o homem mais
confiadamente trilhasse o caminho da verdade, a própria Verdade, o Filho de Deus, assumindo a
humanidade, constituiu e fundou, a fé — Segundo, quanto à esperança, que assim por excelência se
exalça. Donde o dizer Agostinho: Nada foi tão necessário para exalçar a nossa esperança, do que a
demonstração de quanto Deus nos ama. Pois, que indício mais manifesto desse amor do que ter-se o
Filho de Deus dignado entrar em consórcio com a nossa natureza. — Terceiro, quanto à caridade, que
assim sobremaneira se excita. Por isso, diz Agostinho: Que maior causa foi a do advento do Senhor
senão mostrar Deus o seu amor para conosco? E depois acrescenta: Se nos custava amá-lo, que ao
menos não custe corresponder-lhe ao amor. — Quarto, quanto a orar retamente, do que se nos deu
como exemplo. Donde o dizer Agostinho: Não se devia seguir o homem que podia ser visto; devia-se
seguir a Deus, que não podia ser visto. Pois, para que se manifestasse ao homem e fosse visto do
homem e o seguisse o homem, Deus fez-se homem. — Quinto, quanto à participação da divindade, que
é a Verdadeira beatitude do homem e o fim da vida humana. O que nos foi conferido pela humanidade
de Cristo; assim, diz Agostinho: Deus se fez homem para o homem fazer-se Deus.Semelhantemente,
também tal foi útil para a remoção do mal. — Primeiro, porque assim o homem é instruído para não
preferir o diabo a si nem venerá-lo a ele, o autor do pecado. Por isso diz Agostinho: Pois que a natureza
humana pode assim unir-se a Deus, de modo a fazer com ele uma só pessoa, aqueles soberbos espíritos
malignos não ousem antepor-se ao homem, pois não têm carne. — Segundo, porque isso nos adverte
quão grande seja a dignidade da natureza humana, para não a inquinarmos pelo pecado. Por onde, diz
Agostinho: Deus nos mostrou quão excelso lugar tem a natureza humana entre as criaturas, por ter se
manifestado aos homens como verdadeiro homem. E Leão Papa diz:Reconhece, ó Cristão, a tua
dignidade; e, feito consorte da natureza divina, não queiras por uma volta degenerada tornar à antiga
vileza. — Terceiro, porque, para eliminar a presunção humana, a graça de Deus, sem nenhuns méritos
precedentes, se nos inculca no homem Cristo. — Quarto, porque a soberba do homem, que é o máximo
impedimento para nos unirmos a Deus, pode ser neutralizada e curada pela tão grande humildade de
Deus, como no mesmo lugar diz Agostinho. — Quinto, para livrar o homem da servidão do pecado. O
que, no dizer de Agostinho, devia realizar-se de modo que o diabo fosse vencido pela justiça do homem
Jesus Cristo; e isso se deu por ter Cristo satisfeito por nós. Pois, um puro homem não podia satisfazer
por todo o gênero humano; e Deus não devia satisfazer. Por onde era necessário que Jesus Cristo fosse
Deus e homem. Por isso diz Leão Papa: A fraqueza é assumida pela força, pela majestade a humildade;
de modo que, como convinha ao remédio à nossa salvação, um mesmo mediador entre Deus e os
homens pudesse, como homem, nascer, e como Deus, ressurgir. Pois, se não fosse verdadeiro Deus não
daria remédio; e se não fosse verdadeiro homem, não daria o exemplo.
E há ainda muitas outras utilidades daí resultantes, superiores à compreensão dos sentidos do homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe quanto ao necessário, do primeiro
modo, sem o qual não se pode alcançar o fim.

RESPOSTA À SEGUNDA. — Uma satisfação pode ser considerada suficiente de duplo modo. — Primeiro,
perfeitamente; quando é condigna por uma certa adequação, para recompensar a culpa cometida. E,
assim, uma suficiente satisfação não podia existir da parte do homem; pois, a natureza humana estava
corrupta na sua totalidade pelo pecado; nem o bem de nenhuma pessoa, nem ainda o de muitas, podia,
por equiparação, recompensar o detrimento de toda a natureza. Quer também porque o pecado.
cometido contra Deus implica uma certa infinidade, relativamente à infinidade da majestade divina;
pois, tanto mais grave é a ofensa, quanto maior é aquele contra quem se delinqüiu. Por onde, uma
satisfação condigna exigia que o ato do satisfaciente tivesse uma eficácia infinita, como dizendo respeito
a Deus e ao homem. — Noutro sentido, uma satisfação pode ser considerada suficiente,
imperfeitamente; isto é, quanto à aceitação de quem com ela se contenta, embora não seja condigna. E,
deste modo, a satisfação do puro homem é suficiente. E como tudo o que é imperfeito pressupõe algo
de perfeito, em que se funda, daí vem que toda a satisfação de um puro homem, tira a sua eficácia da
satisfação de Cristo.

RESPOSTA À TERCEIRA. — Deus, assumindo a carne, não diminuiu a sua majestade; e por consequência
não fica diminuída a razão da reverência para com ele. A qual cresce com o aumento do conhecimento
que dele temos. Pois, por ter querido aproximar-se de nós pela assunção da carne, mais nos levou a
conhecê-lo.

## Art. 3 — Se, mesmo que o homem não tivesse pecado, Deus ter-se-ia encarnado.
O terceiro discute-se assim. — Parece que mesmo que o homem não tivesse pecado, Deus ter-se-ia
encarnado.
1 — Pois, permanecendo a causa, permanece o efeito. Ora, como diz Agostinho, muitas outras causas
devemos levar em conta, na Encarnação de Cristo, além do resgate do pecado, do qual já se tratou (a.
2). Logo, mesmo que o homem não tivesse pecado, Deus ter-se-ia encarnado.

2. Demais. — É próprio da onipotência do poder divino levar as suas obras à perfeição, e manifestar-se
por algum efeito infinito. Ora, nenhuma pura criatura pode ser considerada um efeito infinito pois, toda
criatura é finita por essência. Ora, só na obra da Encarnação, se manifesta por excelência um efeito
infinito do poder divino, pois nela se acham unidos seres infinitamente distantes, por ter-se o homem
feito Deus. Em cuja obra também em sumo grau se aperfeiçoou o universo, por ter-se a última
criatura — o homem, unido ao primeiro principio — Deus. Logo, mesmo se o homem não tivesse
pecado, Deus ter-se-ia encarnado.

3. Demais. — A natureza humana não se tornou, pelo pecado, mais capaz da graça. Ora, depois do
pecado, é capaz da graça da união, que é a graça máxima. Logo, se o homem não tivesse pecado, a
natureza humana teria sido capaz dessa graça; nem Deus subtrairia à natureza humana um bem de que
ela era capaz. Logo, se o homem não tivesse pecado Deus ter-se-ia encarnado.

4. Demais. — A predestinação de Deus é eterna. Ora o Apóstolo diz, de Cristo (Rom 1, 4): Que foi
predestinado Filho de Deus com poder. Logo, mesmo antes do pecado, foi necessário o Filho de Deus
encarnar-se para cumprir-se a predestinação de Deus.5. Demais. — O mistério da Encarnação foi o
primeiro revelado ao homem, como se conclui do dito da Escritura (Gn 2, 23): Eis aqui agora o osso de
meus ossos, etc., o qual o Apóstolo diz que é um sacramento grande em Cristo e na Igreja (Ef 5, 22). Ora,
pela mesma razão porque não o podia o anjo, também o homem não podia ter presciência da sua
queda, como o prova Agostinho. Logo, mesmo que o homem não tivesse pecado, Deus ter-se-ia
encarnado.Mas, em contrário, Agostinho diz expondo aquilo do Evangelho (Lc 19, 10) — O Filho do
homem veio buscar e salvar o que tinha perecido: Logo, se o homem não tivesse pecado, o Filho do
homem não teria vindo. E àquilo do Apóstolo (1Tm 1, 15) — Jesus Cristo veio a este mundo para salvar
os pecadores, diz a Glosa: Nenhuma outra causa houve da vinda de Cristo a este mundo senão salvar os
pecadores. Elimina as doenças, elimina as chagas: já nenhuma razão há de remédio.

SOLUÇÃO. — São diversas as opiniões sobre esta matéria — Uns dizem que, mesmo sem o pecado do
homem, o Filho de Deus ter-se-ia encarnado. Outros afirmam o contrário. E a esta afirmação devemos
dar assentimento. Pois, as obras puramente voluntárias de Deus, sem haver nenhum débito para com a
criatura, nós não as podemos conhecer, senão enquanto manifestadas pela Sagrada Escritura, que nos
torna conhecida a vontade divina. Ora, como a Sagrada Escritura, sempre dá como razão à Encarnação o
pecado do primeiro homem, mais convenientemente se diz que a obra da Encarnação foi ordenada por
Deus como remédio do pecado, de modo que, se o pecado não existisse, a Encarnação não teria lugar.
Embora por aí não fique limitado o poder de Deus; pois, Deus teria podido encarnar-se mesmo sem ter
existido o pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todas as outras causas assinaladas respeitam o remédio
do pecado. Pois, se o homem não tivesse pecado, teria infuso em si o lume da sabedoria divina e teria,
de Deus, a perfeita retidão da justiça, para conhecer e, praticar todo o necessário. Mas, tendo o homem,
pelo abandono de Deus, caído ao nível das coisas corpóreas, foi conveniente que Deus, tendo assumido
a carne, também lhe desse o remédio da salvação por meio de coisas corpóreas. Por isso àquilo do
Evangelho (Jo 1, 14) — O Verbo se fez carne — Diz Agostinho: A carne te cegou, a carne te cura; pois,
Cristo veio para, com a carne, extirpar os vícios da carne.

RESPOSTA À SEGUNDA. — No modo mesmo da produção das coisas, do nada, se manifesta o infinito
poder divino. E também à perfeição do universo basta que a criatura se ordene para Deus, de um modo
natural, como para o fim. Mas, excede os limites da perfeição da natureza o unir-se criatura
pessoalmente a Deus.

RESPOSTA À TERCEIRA. — Podemos considerar em a natureza humana uma dupla capacidade — Uma,
conforme à ordem da potência natural. E esse Deus sempre a satisfaz, pois dá a cada coisa conforme à
sua capacidade natural — Outra conforme à ordem do poder divino, a cujo nuto toda criatura obedece.
E a esta pertence a capacidade em questão. Pois, Deus não satisfaz toda essa capacidade da natureza,
do contrário não poderia fazer na criatura senão o que faz. O que é falso, como já demonstramos na
Primeira Parte (q. 25, a. 5; q. 105, a. 6). Pois nada impede que a natureza humana, depois pecado não
seja susceptível de maior elevação. Porque Deus permite se faça o mal para dele tirar um bem melhor.
Donde o dizer o Apóstolo (Rom 5, 20): Onde abundou o pecado superabundou a graça. E o dizer-se na
benção do Círio Pascal: Ó culpa feliz, que mereceu ter um tal e tão grande Redentor.

RESPOSTA À QUARTA. — À predestinação pressupõe a presciência dos futuros. Por onde, assim como
Deus predestina que a salvação de um homem deve se cumprir pela oração de outros; assim também
predestinou a obra da Encarnação como médio do pecado.RESPOSTA À QUINTA. — Nada impede que
seja revelado um efeito a quem não o é a causa. Por onde, ao primeiro homem podia ser revelado
mistério da Encarnação sem que tivesse a presciência da sua queda; pois, quem quer que conheça um
efeito não há de por isso conhecer a causa.

## Art. 4 — Se Deus mais principalmente se encarnou para remédio dos pecados atuais do que para remédio do pecado original.
O quarto discute-se assim. — Parece que Deus mais principalmente se encarnou para remédio dos
pecados atuais do que para remédio do pecado original.

1. — Pois, quanto mais grave é um pecado tanto mais se opõe à salvação humana, por causa da qual
Deus se encarnou. Ora, o pecado atual é mais grave que o original; pois, o pecado original merece uma
pena mínima, como diz Agostinho. Logo, mais principalmente a Encarnação de Cristo se ordena a delir
os pecados atuais.

2. Demais. — O pecado original não merece a pena do sentido, mas só a do dano, como se demonstrou
na Segunda Parte da Primeira Parte (Ia. IIae, q. 87, a. 5 arg. 2). Ora, Cristo veio para, em satisfação dos
pecados sofrer na cruz a pena dos sentidos, mas não, a do dano, porque não careceu nunca da divina
visão nem da divina fruição. Logo, mais principalmente veio para delir o pecado atual, que o original.

3. Demais. — Crisóstomo diz: É disposição de um servo fiel reputar por prestados como que só a si os
benefícios do seu Senhor, feitos quase geralmente a todos. Pois, como que de si só falando, Paulo
escreve assim (Gl 2, 20): Amou-me e se entregou a si mesmo por mim. Ora, os pecados propriamente
nossos são os atuais, pois o original é um pecado comum. Logo, devemos ter uma disposição tal, que
julguemos ter ele vindo principalmente por causa dos pecados atuais.
Mas, em contrário, o Evangelho diz (Jo 1, 29): Eis o Cordeiro de Deus, que tira o pecado do mundo.
Expondo o que diz, a Glosa: Pecado do mundo se chama o pecado original, comum a todo o mundo.

SOLUÇÃO. — É certo ter vindo Cristo a este mundo não só para delir o pecado transmitido
originalmente aos pósteros, mas também para delir todos os pecados que depois se lhe acrescentaram.
Não que todos sejam delidos, pois o impede a culpa dos homens que não inerem a Cristo, segundo
aquilo do Evangelho (Jo 3, 19): A luz veio ao mundo e os homens amaram mais as trevas que a luz; mas
porque ele fez o suficiente para delir a todos. Donde o dizer o Apóstolo (Rom 5, 16): Não foi assim o
dom como o pecado; porque o juízo na verdade se originou de um pecado para condenação, mas a
graça padeceu de muitos delitos para justificação.
Mas, tanto mais principalmente Cristo veio para delir um pecado, quanto maior ele é. Ora, a noção de
maior é susceptível de dupla acepção. — Numa, intensivamente; assim, tanto maior é a brancura
quanto mais intensa. E deste modo, maior é o pecado atual que o original, porque é mais
essencialmente voluntário, como se demonstrou na Segunda Parte. — Noutra, diz-se maior o que o é
extensivamente; assim, dizemos maior a brancura que cobre uma superfície maior. E, deste modo, o
pecado original, que contaminou todo o gênero humano, é maior que qualquer pecado atual próprio de
uma pessoa particular. E, sendo assim, Cristo veio mais principalmente para tirar o pecado original, pois,
o bem do povo é mais divino que o de um só, como diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe quanto à grandeza intensiva do pecado.

RESPOSTA À SEGUNDA. — O pecado original, na retribuição futura, não merece a pena do sentido.
Contudo, as penalidades que sofremos sensivelmente nesta vida, como a fome, a sede, a morte e outras
semelhantes, procedem do pecado original. Por isso Cristo, para satisfazer plenamente pelo pecado
original, quis sofrer a dor sensível, consumando em si mesmo a morte e outros sofrimentos
semelhantes.

RESPOSTA À TERCEIRA. — Como Crisóstomo induz no mesmo lugar, o Apóstolo dizia as referidas
palavras, não como querendo diminuir os dons amplíssimos de Cristo e derramados pela universa terra;
mas como se julgando exposto ele só por todos. Pois que importa, se fez também aos outros o que, feito
a ti, é de tal modo íntegro e perfeito como se não fosse feito a nenhum outro? Por onde, pelo fato, de
dever alguém reputar por feitos a si os benefícios de Cristo, não deve julgar que não foram feitos para
os outros. O que portanto não exclui que viesse mais principalmente abolir o pecado de toda a natureza
do que o pecado de uma só pessoa. Mas, esse pecado comum foi de tal modo remediado, em cada um,
como se só nele o fosse, E assim, por causa da união da caridade, o todo que foi distribuído a todos cada
um deve se atribuir a si.

## Art. 5 — Se foi conveniente Cristo encarnar-se desde o princípio do gênero humano.
O quinto discute-se assim. — Parece que era conveniente que Deus se tivesse encarnado desde o
princípio do gênero humano.

1. — Pois, a obra da Encarnação procede da imensidade da caridade divina, segundo aquilo do Apóstolo
(Ef 2, 4):Deus que é rico em misericórdia, pela sua extrema caridade com que nos amou, ainda quando
estavam os mortos pelos pecados nos deu vida juntamente em Cristo. Ora, a caridade não tarda em
socorrer ao amigo que padece necessidade, segundo a Escritura (Pr 3, 28): Não digas ao teu amigo: Vai e
torna, amanhã te darei, quando tu lhe podes dar logo. Portanto Deus não devia ter diferido a obra da
Encarnação, mas, imediatamente, desde o princípio, devia ter socorrido o gênero humano pela sua
encarnação.

2. Demais. — O Apóstolo diz (1Tim 1, 15): Jesus Cristo veio a este mundo para salvar os pecadores. Ora,
os salvos teriam sido em maior número se desde o princípio do gênero humano Deus se tivesse
encarnado; pois, muitos, ignorando Deus, pereceram no seu pecado, em diversos séculos. Logo, era
mais conveniente que Deus se tivesse encarnado desde o princípio do gênero humano.

3. Demais. — A obra de graça não é menos ordenada que a da natureza. Ora, a natureza começa pelo
perfeito, como diz Boécio. Logo, a obra da graça devia ter sido perfeita desde o começo. Ora, na obra da
Encarnação consideramos a perfeição da graça, segundo o Evangelho (Jo 1, 14): O Verbo se fez carne; e
depois acrescenta: Cheio de graça e de verdade. Logo, Cristo devia ter-se encarnado desde o princípio
do gênero humano.
Mas, em contrário, o Apóstolo (Gl 4, 4): Mas quando veio o cumprimento do tempo, enviou Deus a seu
Filho, feito de mulher, feito sujeito à lei — ao que diz a Glosa, que a plenitude do tempo foi a
predeterminada por Deus Padre para quando houvesse de mandar o seu Filho. Ora, Deus determina
tudo pela sua sabedoria. Logo, Deus encarnou-se no tempo convenientíssimo. E, assim, não era
conveniente que Deus se tivesse encarnado desde o princípio do gênero humano.

SOLUÇÃO. — Sendo a obra da Encarnação principalmente ordenada à reparação da natureza humana
pela abolição do pecado, é manifesto que não foi conveniente, desde o princípio do gênero humano,
antes do pecado, que Deus se tivesse encarnado. Pois, remédio não se dá senão aos doentes. Donde o
dizer o próprio Senhor (Mt 9, 12): Os sãos não têm necessidade de médico, mas sim os enfermos; eu
não vim chamar os justos, mas os pecadores.
Mas, nem ainda imediatamente, depois do pecado, era conveniente que Deus se tivesse encarnado. —
Primeiro, por causa da condição do pecado humano, que proviera da soberba; por onde, o homem
devia ser libertado de modo que, humilhado, se reconhecesse necessitado de um libertador. Por isso,
àquilo do Apóstolo (Gl 3, 19): Ordenada por anjos na mão de um mediador, diz a Glosa: Foi obra de um
grande conselho o não ter sido o Filho de Deus enviado imediatamente depois da queda do homem.
Pois, Deus primeiro abandonou o homem à liberdade do arbítrio, na lei natural, para que assim
reconhecesse as forças da sua natureza. E então, quando essa se tornou deficiente, recebeu a lei. Dada
ela, o morbo se fortificou, não por vício da lei, mas, da natureza; de modo que, reconhecendo assim a
sua fraqueza, chamasse pelo médico e buscasse o auxílio da graça. — Segundo por causa da ordem da
promoção no bem, pela qual do imperfeito se chega ao perfeito. Donde o dizer o Apóstolo (1Cor 15,
46): Não primeiro o que é espiritual, senão o que é animal, depois o que é espiritual. O primeiro homem
formado da terra é terreno, o segundo homem, do céu, celestial. — Terceiro, por causa da dignidade do
próprio Verbo encarnado. Pois, àquilo do Apóstolo (Gl 4, 4): Mas quanto veio o cumprimento do
tempo, diz a Glosa: Quanto maior era o juiz que vinha, tanto mais longa devia ser a série dos arautos
que o precedessem — Quarto, a fim de não se entibiar, pela longura do tempo, o fervor da fé e a
caridade de muitos. Donde o dizer o Evangelho (Lc 18, 8): Quando vier o Filho do homem, julgais vós
que achará ele alguma fé na terra?

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A caridade não tarda em socorrer ao amigo, salva
contudo a oportunidade do seu ato e a condição da pessoa. Se, pois, um médico, logo desde o princípio
da doença, desse o remédio ao doente, o remédio lhe aproveitaria menos ou até mesmo faria mal em
lugar de curar. Por isso também o Senhor não deu desde logo ao gênero humano o remédio da
Encarnação, a fim de que ele por soberba não o desprezasse sem ter antes reconhecido a
sua enfermidade.

RESPOSTA À SEGUNDA. — À objeção Agostinho responde do modo seguinte: Cristo quis aparecer aos
homens e pregar-lhes a sua doutrina quando e onde sabia que haveria quem acreditasse nele. Pois,
nesses tempos e nesses lugares, em que o seu Evangelho não foi pregado, previa que as gentes
haveriam de ser todas, relativamente à sua pregação, tais quais eram, senão todos, a maior parte dos
que lhe viam a presença corporal, que nele não quiseram crer, mesmo depois de ressuscitado dos
mortos. Mas, reprovando essa resposta diz o mesmo Agostinho: Porventura podemos dizer que os Sírios
e os Sidônios não queriam crer nos prodígios que presenciassem, ou não houvessem de crer se eles se
fizessem, pois que o próprio Deus atestava que haveriam de fazer penitência com grande humildade, se
na presença deles se tivessem operados aqueles prodígios do poder divino? — Donde, ele próprio
solvendo a dificuldade, acrescenta: Como diz o Apóstolo, isto não depende do que quer nem do que
corre, mas de usar Deus da sua misericórdia; o qual, de um lado, quis socorrer aqueles que previa
haveriam de acreditar nos seus milagres, se entre eles tivessem sido feitos; de outro lado, não socorreu
aqueles que julgou de maneira diferente, ocultamente, é certo, mas justamente, na sua predestinação.
Por onde, acreditamos, sem duvidar, na sua misericórdia, em relação aos que são salvos, e na sua
verdade, em relação aos que são punidos.

RESPOSTA À TERCEIRA. — O perfeito é anterior ao imperfeito em seres diversos pelo tempo e pela
natureza; pois, há de necessariamente ser o perfeito que leve os seres imperfeitos à perfeição, mas,
relativamente a um mesmo ser, o imperfeito tem anterioridade no tempo, embora seja posterior por
natureza. Assim, pois, a perfeição eterna de Deus precede, na duração, a imperfeição da natureza
humana; mas é posterior a ela a perfeição consumada na união com Deus.

## Art. 6 — Se a obra da Encarnação devia ser diferida até o fim do mundo.
O sexto discute-se assim. — Parece que a obra da Encarnação devia ser diferida até o fim mundo.

1. — Pois diz a Escritura: A minha velhice com abundância de misericórdia — o que se entende como os
últimos tempos, como diz a Glosa. Ora, o tempo da Encarnação é sobretudo o tempo da misericórdia,
segundo a Escritura: É tempo de teres piedade dela. Logo, a Encarnação devia ser diferida até o fim do
mundo.

2. Demais. — Como se disse, o perfeito, relativamente a um mesmo ser, é temporalmente posterior ao
imperfeito. Logo, o perfeito por excelência deve ser o último no tempo. Ora, a perfeição suma da
natureza humana é a união com o Verbo; pois, como diz o Apóstolo, foi do agrado do Pai que residisse
em Cristo a plenitude da divindade. Logo, a Encarnação devia ser diferida até o fim mundo.

3. Demais. — Não se deve fazer por meio de dois agentes o que por um só pode ser feito. Ora, um só
advento de Cristo pode bastar à salvação da natureza humana, e esse se dará no fim do mundo. Logo,
não era necessário que viesse antes, pela Encarnação. — E assim, a Encarnação devia ser diferida até o
fim do mundo.Mas, em contrário a Escritura: No meio dos anos tu a farás notória. Logo, o mistério da
Encarnação, pelo qual Deus se fez conhecer, não devia ser diferido, até o fim do mundo.

SOLUÇÃO. — Assim como não era conveniente que Deus se tivesse encarnado desde o princípio do
mundo, assim não o era que a Encarnação fosse diferida até o fim do mundo.O que se evidencia,
primeiro, da união da natureza divina com a humana. Pois, como se disse (a. 5, ad 3), o perfeito, de um
modo, precede temporalmente o imperfeito. Pois, no que de imperfeito passa a perfeito, o imperfeito
precede temporalmente o perfeito; mas na causa eficiente da perfeição, o perfeito precede
temporalmente o imperfeito. Ora, ambos concorreram na obra da Encarnação. Porque, pela própria
Encarnação, a natureza humana foi elevada à suma perfeição; por isso não convinha que a Encarnação
se tivesse realizado desde o princípio do gênero humano. Mas, o Verbo Encarnado é ele mesmo a causa
eficiente da perfeição humana, segundo o Evangelho: Todos nós participamos da sua plenitude; e por
isso não devia a obra da Encarnação ser diferida até o fim do mundo. Ao passo que a perfeição da glória,
a qual ultimamente será elevada a natureza humana, pelo Verbo encarnado, se realizará no fim do
mundo.Segundo, pelo efeito da salvação humana. Pois, como diz Agostinho, está no poder de quem dá
compadecer-se quando e quanto quiser. Por isso veio quando sabia que devia socorrer e que o benefício
havia de ser grato. Assim, quando, por um certo languor do gênero humano, o conhecimento de Deus
começou a apagar-se entre os homens e os costumes a se mudarem, dignou-se escolher a Abraão, que
realizasse a forma da renovação do conhecimento de Deus, e dos costumes. E como ainda a reverência
que lhe deviam fosse diminuindo, deu a lei escrita, por meio de Moisés. E como as gentes a
desprezaram, sem quererem se lhe submeter, e nem a observaram os que a receberam, o Senhor,
movido pela misericórdia, mandou o seu Filho, que, feita a todos a remissão dos pecados, ofereceu-os
justificados a Deus Padre. Ora, se o remédio fosse diferido até o fim do mundo, o conhecimento de
Deus, a reverência a ele devida e a honestidade dos costumes teriam totalmente desaparecido da
terra.Terceiro, a conveniência da Encarnação resulta da manifestação do poder divino, que salvou os
homens de muitos modos, não só pela fé do futuro, mas pela do presente e do pretérito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Glosa aduzida se refere à misericórdia conducente à
glória. Mas, referida à misericórdia feita ao gênero humano pela Encarnação de Cristo, devemos então
saber, como diz Agostinho, que o tempo da Encarnação pode ser comparado à juventude do gênero
humano, por causa do vigor e do fervor da fé, que obra pelo amor; à velhice porém, que é a sexta idade,
por causa do número dos tempos, por que Cristo veio na sexta idade. E embora no corpo não possam
coexistir a juventude. com a velhice podem contudo existir simultaneamente na alma, aquela, pela
alegria, esta, pela gravidade. E por isso como diz ainda noutro lugar Agostinho, não devia o mestre
divino, por cuja imitação os costumes do gênero humano viriam a ser ótimos, ter vindo senão no tempo
da juventude. E noutro passo diz que Cristo veio na sexta idade do gênero humano, como no tempo da
velhice.

RESPOSTA À SEGUNDA. — A obra da Encarnação não devemos considerá-la só como termo e
movimento do imperfeito para o perfeito, mas também como princípio da perfeição da natureza
humana, como se disse.

RESPOSTA À TERCEIRA. — Como diz Crisóstomo àquilo do Evangelho — Deus não enviou seu Filho ao
mundo para condenar o mundo: Dois são o adventos de Cristo: o primeiro, para remir os pecados; o
segundo, para julgar. Pois, se tal não tivesse feito, todos ter-se-iam simultaneamente perdido, porque
todos pecaram e precisam da graça de Deus. Por onde é claro, que o advento da misericórdia não devia
ser diferido até o fim do mundo.