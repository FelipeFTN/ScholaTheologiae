# Questão 28: Da virgindade da Santa Virgem Maria
Em seguida devemos tratar da virgindade da Mãe de Deus.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a Mãe de Deus foi virgem quando concebeu a Cristo.
O primeiro discute-se assim. — Parece que a Mãe de Deus não foi virgem quando concebeu a Cristo.

1. — Pois, nenhum filho de pai e mãe é concebido de mãe virgem. Ora, o Evangelho não somente diz
que Cristo teve mãe, mas também pai. Assim, no lugar: Seu pai e sua mãe estavam admirados daquelas
coisas que dele se diziam. E mais adiante: Sabe que teu pai e eu te andávamos buscando cheios de
aflição. Logo, Cristo não foi concebido de mãe virgem.

2. Demais. — O Evangelho prova que Cristo foi filho de Abraão e de Davi, pelo fato de ser José
descendente de Davi; prova essa que seria nula se José não fosse o pai de Cristo. Donde se conclui que a
mãe de Cristo concebeu-o do sêmen de José. E portanto, não foi virgem na sua conceição.

3. Demais. — O Apóstolo diz: Enviou Deus a seu filho, feito de mulher. Ora, no modo habitual de falar,
chama-se mulher a que tem marido. Logo, Cristo não foi concebido de mãe virgem.

4. Demais. — Seres da mesma espécie são gerados do mesmo modo; pois, a geração, como todo
movimento, se específica pelo seu termo. Ora, Cristo era da mesma espécie que os outros homens,
segundo aquilo do Apóstolo: Fazendo-se semelhante aos homens e sendo reconhecido na condição,
como homem. E, como os outros homens nasceu da união do homem com a mulher, resulte que Cristo
foi também gerado do mesmo homem. Portanto, não foi concebido de mãe virgem.

5. Demais. — Toda forma natural corresponde a uma determinada matéria, separada da qual não pode
existir. Ora, a matéria da forma humana é o sêmen do homem e o da mulher. Se, pois, o corpo de Cristo
não foi concebido do sêmen do homem e da mulher, não foi verdadeiramente um corpo humano, o que
é admissível. Logo, parece que não foi concebido de mãe virgem.
Mas, em contrário, a Escritura: Eis que uma virgem conceberá.

SOLUÇÃO. — Devemos confessar, absolutamente, que a Mãe de Cristo concebeu virgem. O contrário
constituiu a heresia dos Elionitas e de Cerinto, que consideravam Cristo como puro homem e o tinham
como nascido da união dos dois sexos. Ora, o ser Cristo concebido de uma virgem foi conveniente por
quatro razões. — Primeiro, para conservar a dignidade do Pai, que o enviou. Pois, sendo Cristo, natural e
verdadeiramente, Filho de Deus, não era conveniente tivesse outro pai, que Deus, a fim de não se
transferir para outro a dignidade de Deus. — Segundo, tal convinha à propriedade do Filho mesmo, que
é enviado. O qual é o Verbo de Deus. Ora, o Verbo é concebido sem nenhuma corrupção da mente; ao
contrário, a corrupção da mente não se compadece com a concepção do verbo perfeito. Sendo, pois, a
carne assumida pelo Verbo de Deus para ser a sua carne, era conveniente fosse também ela concebida
sem a corrupção da mãe. — Em terceiro lugar tal convinha à dignidade humana de Cristo, na qual não
devia haver lugar para o pecado, pois devia tirar o pecado do mundo, segundo aquilo do Evangelho: Eis
o Cordeiro de Deus, isto é, o inocente, que tira o pecado do mundo. Ora, na natureza já corrupta pelo
concúbito, a carne não podia deixar de ficar contaminada pelo pecado original. Por isso, diz Agostinho:
No matrimônio de Maria e de José não houve o concúbito nupcial; pois, na carne do pecado este não
pode ter lugar sem a concupiscência resultante do pecado; ora, Deus quis que fosse concebido sem ela
aquele que devia ser sem pecado. - Quarto, por causa do fim mesmo da encarnação de Cristo. que foi
fazer os homens renascerem filhos de Deus, não da vontade da carne, nem da vontade do varão, mas de
Deus, isto é, pelo poder de Deus. E exemplar disso devia ser a concepção mesma de Cristo. Por isso diz
Agostinho: Devia o nosso chefe, por um insigne milagre, nascer, segundo o corpo, de uma virgem, para
significar que os seus membros deviam nascer, segundo o espírito, da Igreja virgem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz Beda: O pai do Salvador foi chamado José, não por
ter este sido, realmente, o seu pai, como ensinam os Focinianos; mas, para conservar-se a pureza de
Maria, os homens o consideraram como pai. Por isso o Evangelho diz: Filho, como se julgava, de José. —
Ou, como diz Agostinho, José é chamado pai de Cristo, do mesmo modo porque é considerado esposo
de Maria: sem conjunção carnal, só por uma união conjugal espiritual; o que o une mais estreitamente a
Cristo do que o faria uma simples adoção. Mas nem por isso, pelo não ter gerado carnalmente, devia
José ser menos considerado pai de Cristo; pois, poderá ser pai mesmo se tivesse adotado quem não
tivesse sido nascido de sua esposa.

RESPOSTA À SEGUNDA. — Como diz Jerônimo, embora José não seja o pai do Salvador e Senhor,
contudo a ordem da sua geração se estende até José, primeiro, por não ser costume das Escrituras
incluir as mulheres na ordem das gerações. — Segundo, porque José e Maria eram da mesma tribo. E
por isso está obrigado pela lei a recebê-la, como parenta. — E, como diz Agostinho, a ordem das
gerações devia ser conduzida até José, para que não houvesse, nesse casamento, injúria ao sexo, em
definitivo, mais nobre; sem nenhum detrimento para a verdade, porque tanto José como Maria eram da
raça de Deus.

RESPOSTA À TERCEIRA. — Como diz a Glosa, o Apóstolo usou da palavra mulher, em vez de feminina, ao
modo de falar dos Hebreus. Pois, no uso comum da língua hebraica, mulher significa toda pessoa do
sexo feminino, e não a que perdeu a virgindade.

RESPOSTA À QUARTA. — O fato aduzido na objeção não se dá senão com os seres procedentes por via
da natureza; porque a natureza, assim como é determinada a um só efeito, assim também o é a um só
modo de produzi-lo. Mas o poder sobrenatural divino, sendo infinito, assim como não é determinado a
um só efeito, assim também não o é ao modo de produzir qualquer efeito. Por onde, assim como o
poder divino foi capaz de formar o primeiro homem do limo da terra, assim também o foi, de formar o
corpo de Cristo, de uma virgem, sem cooperação masculina.

RESPOSTA À QUINTA. — Segundo o Filósofo, o sêmen masculino não exerce a função de matéria na
concepção carnal, mas só a de agente; pois, é a fêmea que subministra a matéria para a concepção. Por
onde, não tendo havido o sêmen masculino na concepção do corpo de Cristo, daí não se segue que lhe
tivesse faltado a matéria devida. — Se porém o sêmen masculino fosse a matéria do feto animal
concebido, é manifesto que não é matéria sempre dotada da mesma forma, mas, transmutada. E como
a virtude natural não transmuda para uma certa forma senão uma determinada matéria, contudo o
poder divino, que é infinito, pode dar a toda matéria qualquer forma. Por onde, assim como
transformou o limo da terra no corpo de Adão, assim também pode transmutar no corpo de Cristo a
matéria ministrada pela mãe, mesmo se essa não fosse matéria suficiente para a concepção natural.

## Art. 2 — Se a mãe de Cristo foi virgem no parto.
O segundo discute-se assim. — Parece que a mãe de Cristo não foi virgem no parto.

1. — Pois, diz Ambrósio: Quem santificou o ventre de uma mulher para que dela nascesse um profeta,
esse foi o mesmo que abriu o ventre de sua mãe, para sair dele imaculado. Ora, tal fato exclui a
virgindade. Logo, a mãe de Cristo não foi virgem no parto.

2. Demais. — No mistério de Cristo nada devia haver, que nos levasse a lhe considerar o corpo como
imaginária. Ora, não convém a um corpo verdadeiro, mas só a um fantástico, poder atravessar o que
está fechado; porque dois corpos não podem ocupar simultaneamente o mesmo lugar. Logo, não devia
o corpo de Cristo sair do ventre materno, sem ele romper-se. Portanto, a virgem não pôde ser virgem no
parto.

3. Demais. — Como diz Gregório, quando, depois da ressurreição, o Senhor passou através de portas
fechadas e entrou a ter com os discípulos, mostrou ser o seu corpo da mesma natureza, mas revestido
de uma outra glória. E assim, é próprio do corpo glorioso atravessar portas fechadas. Ora, o corpo de
Cristo, na sua concepção, não foi glorioso, mas passível, tendo a Semelhança da carne do pecado, no
dizer do Apóstolo. Logo, não saiu do ventre materno, sem que ele se abrisse.
Mas, em contrário, diz o concílio Efesino: A natureza destrói, com o parto, a virgindade. Mas a graça
uniu o parto e a maternidade com a virgindade. Logo, a mãe de Cristo foi Virgem, mesmo no parto.

SOLUÇÃO. — Sem nenhuma dúvida devemos afirmar que a mãe de Cristo foi Virgem, mesmo no parto.
Pois, o Profeta não só disse — Eis que uma Virgem conceberá, mas acrescentou — e parirá um filho. E
isto se funda numa tríplice conveniência. — Primeiro, por convir à propriedade do que ia nascer, Que
era o Verbo de Deus. Pois, o Verbo não somente é concebido no coração, sem nenhum detrimento, mas
também sem nenhuma corrupção dele procede. E por Isso, para mostrar que esse era o corpo mesmo
do Verbo de Deus, foi conveniente nascesse do ventre incorrupto da virgem. Por isso, lemos no concílio
Efesino: A que gera uma carne puramente humana perde a sua virgindade. Mas o Verbo de Deus,
nascendo na carne, conserva a virgindade da Mãe, mostrando assim ser lealmente o Verbo. Pois
também o nosso verbo, quando gerado, não corrompe a mente; nem o Verbo substancial, que é
Deus,havia de destruir a virgindade, quando nasceu. — Segundo, tal foi conveniente quanto ao efeito da
Encarnação de Cristo. Pois, veio para tirar a nossa corrupção. E por isso não convinha que, ao nascer,
destruísse a virgindade materna. Donde o dizer Agostinho, que não era justo que quem veio sanar a
corrupção violasse, com o seu advento, a integridade virginal. — Terceiro, isso foi conveniente a fim de
que quem mandou honrarmos os pais não viesse, com o seu nascimento, diminuir a honra materna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ambrósio assim o diz, quando expõe as palavras da lei
citadas pelo evangelista. Todo filho macho que for primogênito será consagrado ao Senhor. O que,
como diz o Venerável Beda, é um modo habitual de se referir à natividade, sem querer significar
devamos crer que o Senhor desvirginou, ao nascer, o ventre que lhe serviu de asilo e que santificou.
Donde, o abrir, a que se refere Ambrósio, não significa a ruptura do claustro do pudor virginal, mas só o
nascer do filho, do ventre materno.

RESPOSTA À SEGUNDA. — Cristo quis mostrar que tinha verdadeiramente corpo, mas de modo que
também manifestasse a sua divindade. Por isso ajuntou causas miraculosas com coisas humildes. Assim,
para mostrar que tinha um verdadeiro corpo, nasce de uma mulher; e para mostrar a sua divindade,
nasce de uma virgem, pois, tal é o parto que convém a Deus, como diz Jerônimo.

RESPOSTA À TERCEIRA. — Certos disseram que Cristo, na sua natividade, assumiu o dote da subtileza;
assim, quando andou, sem molhar os pés, sobre o mar, dizem que assumiu o dote da agilidade. - Mas,
isto não concorda com o que foi determinado antes. Pois, tais dotes do corpo glorioso provêm da
redundância da glória da alma para o corpo, como diremos quando tratarmos dos corpos gloriosos. Ora,
segundo dissemos, Cristo, antes da sua paixão permitia ao seu corpo fazer e sofrer o que lhe é próprio;
nem havia tal redundância da glória, da alma para o corpo. Por onde, devemos concluir serem
miraculosos todos esses fatos supra referidos, por virtude divina. Por isso diz Agostinho: Um corpo tal
unido à divindade, não era impedido por nenhum obstáculo. Pois, aquele podia entrar, sem que portas
lhe fossem abertas, que veio ao mundo sem que sua mãe perdesse a virgindade. E Dionísio diz que
Cristo realizava as obras próprias do homem, de um modo superior; e isso o demonstra a conceição
sobrenatural da virgem, e o lhe ser o peso material dos pés suportado pela superfície móvel das águas.

## Art. 3 — Se a mãe de Cristo permaneceu Virgem depois do parto.
O terceiro discute-se assim. — Parece que a mãe de Cristo não permaneceu Virgem depois do parto.

1. — Pois, diz o Evangelho: Antes de coabitarem José e Maria, se achou ela ter concebido por obra do
Espírito Santo. Ora, o Evangelista não teria dito – antes de coabitarem – se não fosse certo que haveriam
de coabitar; assim não diremos, que não vai comer, quem não ia comer. Logo, parece que a Santa
Virgem chegou a ter conjunção carnal com José. E portanto não permaneceu virgem depois do parto.

2. Demais. — No mesmo lugar, o Evangelho refere as palavras do anjo a José: Não temas receber a
Maria, tua mulher. Ora, o casamento se consuma pela cópula carnal. Logo, parece que houve cópula
carnal entre Maria e José. Donde, pois, resulta que não permaneceu virgem depois do parto.

3. Demais. — Logo a seguir, acrescenta o Evangelho: E recebeu a sua mulher; e ele não na conheceu,
enquanto ela não pariu o seu primogênito. Ora, a expressão adverbial – até que – costuma significar um
tempo determinado; completo o qual, se faz o que até então não se fez. E quanto ao verbo conhecer –
ele significa o coito; assim, como quando a Escritura diz: Adão conheceu a sua mulher. Logo, parece que
depois do parto a Santa Virgem foi conhecida de José. E portanto, parece que não permaneceu virgem
depois do parto.

4. Demais. — Primogênito não pode chamar-se senão quem teve outros irmãos mais moços. Por isso,
diz o Apóstolo: Os que ele conheceu na sua presciência, também os predestinou para serem conforme a
imagem Filho, para que ele seja o primogênito entre muitos irmãos. Ora, o Evangelista chama a Cristo
primogênito da sua mãe. Logo, teve ela outros filhos além de Cristo. E assim, parece que a mãe de Cristo
não permaneceu virgem depois do parto.

5. Demais — O Evangelho diz: Depois disto vieram para Cafarnaum, ele, isto é, Cristo, e sua mãe e seus
irmãos. Ora, chamam-se irmãos os que tem os mesmos pais. Logo, parece que a santa Virgem teve
outros filhos, além de Cristo.

6. Demais. — O Evangelho diz: Achavam-se também ali, isto é, ao pé da cruz de Cristo, vindo de longe,
muitas mulheres, que desde Galileia tinham seguido a Jesus, subministrando-lhe o necessário; entre as
quais estavam Maria Madalena e Maria, Mãe de Tiago e de José, e a Mãe dos filhos de Zebedeu. Ora,
essa era Maria, chamada aí mãe de Tiago e de José, é também a mãe de Cristo; pois, como diz o
Evangelho, estava em pé junto à cruz de Jesus, sua mãe. Logo, parece que a mãe de Cristo não
permaneceu virgem depois do parto.
Mas, em contrário, a Escritura: Esta porta estará fechada; ela não se abrir e nenhum homem passará por
ela, porque o Senhor Deus de Israel entrou por esta porta. Expondo o que, diz Agostinho: Que significa a
porta fechada na casa do Senhor, senão que Maria sempre será intacta? E que significa a expressão –
nenhum homem passará por ela – senão que José não a conhecerá? E só o Senhor entrará e sairá por
ela – que quer dizer, senão que o Espírito Santo a fecundará e dela nascerá o Senhor dos anjos? E que
significa – estará eternamente fechada – senão que Maria será virgem antes, durante e depois do parto?

SOLUÇÃO. — Sem nenhuma dúvida devemos detestar o erro de Celvídio, que pretendia ter sido a mãe
de Cristo, depois do parto, conhecida de José e ter gerado outros filhos. - Pois, isto, primeiro, vai contra
a perfeição de Cristo, que, assim como, pela sua natureza divina, é o Unigênito do Pai, como o seu Filho
em tudo perfeito, assim também convinha que fosse o unigênito da mãe, como o perfeitíssimo gerado
dela. - Segundo, esse erro faz injúria ao Espirito Santo, cujo sacrário foi o ventre virginal, no qual formou
a carne de Cristo; por isso não convinha, que a seguir fosse violado pela conjunção marital. - Terceiro,
vai contra a dignidade e a santidade da Mãe de Deus, que seria ingratíssima se não se tivesse
contentado com um tão grande Filho; se a virgindade, nela conservada milagrosamente, quisesse
espontaneamente perdê-la pelo concúbito carnal. - Quarto, seria também uma pretensão
soberanamente imputável a José, tentar poluir aquela que, por uma revelação do Anjo, sabia que
concebeu do Espírito Santo. - Donde devemos absolutamente concluir que a Mãe de Deus, assim como
concebeu virgem e virgem deu à luz, assim também permaneceu sempre virgem depois do parto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Jerônimo, devemos entender a palavra – antes
– como indicativa, às vezes, somente do que foi anteriormente pensado, embora de ordinário indique
uma consequência. Nem é necessário o realizar-se do que foi pensado, pois, às vezes um obstáculo
interveniente impede essa realização. Assim, o dizer alguém – antes de ter comido, no porto, naveguei –
não significa que comeu no porto, depois de ter navegado; mas, que pensava haver de comer, no porto.
Semelhantemente, o evangelista diz – Antes de coabitarem, se achou ela ter concebido por obra tio
Espírito Santo; não que depois coabitassem: concepção pelo Espírito Santo e, pois não realizaram o
concúbito.

RESPOSTA À SEGUNDA. — Como diz Agostinho, a Mãe de Deus é chamada esposa, pela fé primeira dos
desposórios, ela que nem conheceu nem havia de conhecer o concúbito. Pois, no dizer de Ambrósio, a
celebração das núpcias não declara a perda da virgindade, mas a testificação do casamento.

RESPOSTA À TERCEIRA. — Certos disseram que esse lugar do Evangelho não deve entender-se do
conhecimento carnal, mas do conhecimento informativo. Assim, diz Crisóstomo, que José não lhe
conhecia a dignidade, antes de ela ter dado à luz; mas, depois do parto, então o soube. Pois,
concebendo um tal filho, tornou-se maior e mais digna que todo o mundo; por ter, só ela, recebido no
augusto âmbito do seu ventre, aquele a quem todo o mundo não podia conter. — Mas outros referem o
lugar em questão ao conhecimento de visão. Pois, assim como o rosto de Moisés, quando falava com
Deus, se lhe glorificou de modo que não podiam fitá-lo os filhos de Israel, assim Maria, obumbrada pelo
esplendor da virtude do Altíssimo, não podia ser reconhecida por José, antes do parto. Mas, depois do
parto, José reconheceu-lhe a feição das faces, sem nenhum contato corpóreo. — Mas Jerônimo, que
concede devamos entender a expressão evangélica, do conhecimento carnal, diz que até (usque) ou até
que (donec), na Escritura, pode ser entendido de dois modos. Assim, às vezes designa o tempo,
conforme aquilo do Apóstolo: Por causa das transgressões foi posta a lei, até que viesse a semente, a
quem havia feito a promessa. Outras vezes, porém, significa o tempo infinito, segundo aquilo: Os nossos
olhos estão fitos no Senhor nosso Deus, até que tenha misericórdia de nós; o que não se deve entender
como significando que, depois de pedida a misericórdia, os nossos olhos se afastam de Deus. E, segundo
este modo de falar, são-nos expressas as coisas de que poderíamos duvidar, se não estivessem escritas;
quanto as demais, são confiadas à nossa inteligência. E, assim, o Evangelista diz que a Mãe de Deus não
foi conhecida por nenhum homem, até o parto, para entendermos que, com maior razão, não o foi
depois do parto.

RESPOSTA À QUARTA. — É costume das divinas Escrituras chamar primogênito não só aquele que teve
outros irmãos, como o que nasceu em primeiro lugar. Do contrário se não fosse primogênito senão
quem teve irmãos, os direitos de primogenitura não seriam, pela lei, devidos enquanto não
sobreviessem mais irmãos. O que é claramente falso, pois, a lei mandava que, dentro de um mês,
fossem os primogênitos resgatados.

RESPOSTA À QUINTA. — Certos, como refere Jerônimo, pensam que os referidos irmãos do Senhor José
os teve de outra mulher. Mas nós pensamos que os irmãos do Senhor não eram filhos de José, mas
primos do Salvador, filhos de uma outra Maria, tia dele. Pois, na Escritura, há quatro espécies de irmão:
por natureza, pela raça, pela cognação e pelo afeto. Donde o serem chamados irmãos do Senhor, não
por natureza, como se fossem nascidos da mesma mãe; mas, por cognação, quase como sendo os seus
consanguíneos. José, porém, como diz Jerônimo, devemos antes crer que permaneceu virgem, pois, de
um lado, dele não diz a Escritura que tivesse outra mulher e, de outro, não se pode atribuir a fornicação
a um varão santo.

RESPOSTA À SEXTA. — A Maria chamada Mãe de Tiago e de José não se entende que fosse a mãe do
Senhor, a que não se refere o Evangelho senão atribuindo-lhe a sua dignidade de Mãe de Jesus. Ora,
essa Maria se entende que era a mulher de Alfeu, cujo filho era Tiago menor, chamado irmão do
Senhor.

## Art. 4 — Se a Mãe de Deus fez voto de virgindade.
O quarto discute-se assim. — Parece que a Mãe de Deus não fez voto de virgindade.

1. — Pois, diz a Escritura: Não haverá em ti estéril nem de um nem de outro sexo. Ora, a esterilidade é
consequente à virgindade Logo, a conservação da virgindade era contra o preceito da lei antiga. Ora, a
lei antiga ainda vigorava quando Cristo nasceu. Logo, nesse tempo, a Santa Virgem não podia
licitamente fazer voto de virgindade.

2. Demais. — O Apóstolo diz: Quanto porém às virgens, não tenho mandamento do Senhor, mas dou
conselho. Ora, a perfeição do conselho devia começar com Cristo, que é o fim da lei, como diz o
Apóstolo. Logo, não foi conveniente que a Virgem fizesse voto de virgindade.

3. Demais. — A Glosa de Jerônimo diz: Aos que fizeram voto de castidade é condenável não só casar,
mas querer casar. Ora, a Mãe de Cristo não cometeu nenhum pecado condenável, como se estabeleceu.
Logo, como foi desposada, parece que não fez voto de virgindade.
Mas, em contrário, Agostinho: Ao anjo que lhe anunciava, Maria respondeu: Como se fará isso, pois eu
não conheço varão? O que certamente não diria, se antes não tivesse feito voto da sua virgindade a
Deus.

SOLUÇÃO. — Como estabelecemos na Segunda Parte, as obras de perfeição mais louváveis são quando
celebradas com voto. Ora, a Virgindade devia por excelência resplender na Virgem Mãe, pelas razões já
aduzidas. Por isso foi conveniente consagrasse por voto a sua virgindade a Deus. Ora, no tempo da lei,
tanto as mulheres como os varões deviam gerar, porque a propagação do culto de Deus dependia de
uma nação rica em homens, antes de Deus ter nascido desse povo. Por onde, não se crê que a Mãe de
Deus tivesse, absolutamente falando, feito voto de virgindade, antes de desposar José; mas, embora
tivesse o desejo de o fazer, cometeu, contudo, a sua vontade ao arbítrio divino. Mas depois que recebeu
esposo, como o exigiam os costumes do tempo, simultaneamente fez voto de virgindade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como era proibido pela lei o não se esforçar um por
deixar descendência na terra, por isso a Mãe de Deus não fez voto de virgindade, absolutamente, mas,
condicionalmente, isto é, se agradasse a Deus. Mas depois de ter conhecido que Deus assim o aceitara,
fez voto absoluto de virgindade, antes de receber o anúncio do anjo.

RESPOSTA À SEGUNDA. — Assim como Cristo teve a plenitude da graça perfeitamente, e contudo certas
graças preexistiram incoativamente em sua mãe, assim também a observância dos conselhos, que se
realiza pela graça de Deus, começou, certo, perfeitamente em Cristo, mas de algum modo teve início em
sua mãe.

RESPOSTA À TERCEIRA. — As palavras citadas do Apóstolo devem entender-se como aplicáveis aos que
fazem voto absoluto de castidade, o que a Mãe de Deus não fez antes de ter desposado José. Mas,
depois de tê-lo desposado, de vontade própria juntamente com seu esposo, existiu o voto de
virgindade.