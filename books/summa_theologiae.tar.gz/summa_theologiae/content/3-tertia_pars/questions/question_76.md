# Questão 76: Do modo pelo qual Cristo está neste sacramento
Em seguida devemos tratar do modo pelo qual Cristo está neste sacramento.
E nesta questão discute-se oito artigos:

## Art. 1 — Se Cristo está totalmente contido neste sacramento.
O primeiro discute-se assim. — Parece que Cristo não está totalmente contido neste sacramento.

1. — Pois Cristo começa a existir neste sacramento pela conversão do pão e do vinho. Ora, é manifesto
que o pão e o vinho não podem converter-se nem na divindade de Cristo nem na sua alma. Logo,
havendo em Cristo três substâncias - a da divindade, a da alma e a do corpo, como se disse - resulta que
ele não está totalmente neste sacramento.

2. Demais. — Cristo está neste sacramento do modo por que o convém à alimentação dos fiéis, que
consiste na comida e na bebida, como se disse. Ora, o Senhor diz: A minha carne verdadeiramente é
comida, e o meu sangue verdadeiramente é bebida. Logo, só a carne e o sangue de Cristo estão contidos
neste sacramento. Mas o corpo de Cristo tem muitas outras partes - nervos, ossos e semelhantes. Logo,
o corpo de Cristo não está totalmente contido neste sacramento.

3. Demais. — Um corpo de maior quantidade não pode ser totalmente contido pela medida de um de
menor quantidade. Ora, a medida do pão e do vinho consagrados é muito menor que a medida própria
ao corpo de Cristo. Logo, não é possível Cristo estar totalmente contido neste sacramento.
Mas, em contrário, diz Ambrósio: Naquele sacramento está Cristo.

SOLUÇÃO. — É absolutamente necessário confessarmos, segundo a fé, católica, que Cristo está
totalmente neste sacramento. Devemos porém saber que algo de Cristo está neste sacramento de dois
modos: quase por força do sacramento e por natural concomitância. - Por força do sacramento, está sob
as espécies deste aquilo em que diretamente se converte a substância preexistente do pão e do vinho,
como o significam as palavras de forma, que são eficazes neste sacramento, bem como nos outros, e
que são: Isto é o meu corpo, Isto é o meu sangue. - Por concomitância natural, porém, está neste
sacramento o com que realmente está unido àquilo em que termina a referida conversão. Ora, quando
duas coisas estão realmente unidas, onde quer Que uma esteja realmente, aí há de a outra também
estar. Mas só por operação da alma se discernem as coisas realmente unidas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A conversão do pão e do vinho não têm por termo a
divindade ou a alma de Cristo; e por consequência a divindade ou a alma de Cristo não estão neste
sacramento por força do mesmo, mas por concomitância real. Mas, como a divindade nunca depôs o
corpo assumido, onde quer que esteja o corpo de Cristo, aí estará necessàriamente também a sua
divindade. Por isso, neste sacramento está necessariamente a divindade de Cristo, concomitante ao seu
corpo. Daí o ler-se rio Símbolo Efesino: Tomamo-nos participantes do corpo e do sangue de Cristo, não
como se comêssemos uma carne comum, ou a de um varão santificado e unido ao Verbo pela unidade
da dignidade, mas uma carne verdadeiramente santificante e feita própria do Verbo mesmo. Quanto
porem à alma, foi realmente separada do corpo, como se disse. Por onde, se no tríduo da morte de
Cristo fosse celebrada este sacramento, nele não estaria a sua alma, nem por força do sacramento nem
por concomitância real. Mas, como Cristo, ressurgido dos mortos, já não morre, na frase do Apóstolo, a
sua alma lhe está sempre realmente unida ao corpo. Por onde, neste sacramento o corpo de Cristo está
pela força mesma do sacramento; mas a alma de Cristo nele está por concomitância real.

RESPOSTA À SEGUNDA. — Por força do sacramento, este contém, quanto à espécie do pão, não só a
carne, mas todo o corpo de Cristo, a saber, os ossos, os nervos e partes semelhantes. O que resulta da
forma mesma deste sacramento, que não reza - Esta é a minha carne, mas - Isto é o meu corpo. Por
onde, quando o Senhor disse A minha carne é verdadeiramente comida carne aí significa todo o corpo,
porque, segundo o costume humano, é mais própria para ser comida, pois comumente nos nutrimos da
carne dos animais, não porém dos OSSOS e partes semelhantes.

RESPOSTA À TERCEIRA. — Como dissemos, feita a conversão do pão no corpo de Cristo ou a do vinho
no sangue, os acidentes de um e de outro permanecem. Por onde é claro que as dimensões do pão e do
vinho não se convertem nas do corpo de Cristo, mas uma substância é a que se converte em outra. E
assim a substância do corpo de Cristo ou do sangue está neste sacramento por força mesma do
sacramento, não porem as dimensões do corpo ou do sangue de Cristo. Por onde, é claro que o corpo
de Cristo está neste sacramento substancialmente e não, quantitativamente. Ora, a totalidade própria à
substância contém-se indiferentemente numa quantidade pequena ou grande; assim como a natureza
total do ar está numa quantidade grande ou pequena dele, e a total natureza do homem num homem
grande ou num pequeno. Por onde, a substância total do corpo e do sangue de Cristo está contida neste
sacramento, depois da consagração, assim como antes da consagração, estava aí contida a substância
do pão e do vinho na sua totalidade.

## Art. 2 — Se sob uma e outra espécie deste sacramento Cristo está contido totalmente.
O segundo discute-se assim. — Parece que sob uma e outra espécie deste sacramento Cristo não está
totalmente contido.

1. — Pois, este sacramento se ordena à salvação dos fiéis, não em virtude das espécies, mas em virtude
do que está nelas, contido. Porque as espécies já existiam antes da consagração, donde tira este
sacramento a sua virtude. Se, portanto, nada contém uma espécie que também não contenha a outra,
mas Cristo está totalmente numa e noutro, resulta ser inútil uma delas neste sacramento.

2. Demais. — Como se disse, na denominação de carne estão contidas todas as outras partes do corpo,
como os ossos, os nervos e outras semelhantes. Ora, o sangue é uma das partes do corpo humano,
como está claro em Aristóteles. se pois, o sangue de Cristo está contido na espécie do pão, assim como
nele estão contidas as outras partes do corpo, não deveria o sangue ser consagrado separadamente,
assim como não é consagrada separadamente a outra parte do corpo.

3. Demais. — O já feito não pode sê-lo de novo. Ora, o corpo de Cristo já começou a existir neste
sacramento pela consagração do pão. Logo não pode começar a existir de novo pela consagração do
vinho. E assim, na espécie do vinho não estará contido o corpo de Cristo e, por consequência, nem todo
Cristo. Logo, sob uma e outra espécie não esta contido, Cristo totalmente.
Mas, em contrário, àquilo do Apóstolo - o cálice - diz a Glosa: sob uma e outra espécie, isto é, do pão e
do vinho, tomamos o mesmo Cristo. Donde se conclui que Cristo está totalmente sob uma e outra
espécie.

SOLUÇÃO. — Devemos ter certissímamente que sob uma e outra espécie está todo Cristo. Mas de
modos diferentes. Assim, sob as espécies do pão está o corpo de Cristo por força do sacramento; e o
sangue, por concomitância real, como dissemos quando tratamos da alma e da divindade de Cristo. De
outro lado sob as espécies do vinho está o sangue de Cristo, por força do sacramento, e o corpo de
Cristo, por concomitância real, como a alma e a divindade. Porque, no sacramento o sangue de Cristo
não lhe está separado do corpo, como o esteve no tempo da paixão e da morte. Por onde, se então
fosse este sacramento celebrado, sob as espécies do pão estaria o corpo de Cristo, sem o sangue; e sob
as espécies do vinho, o sangue sem o corpo, como o era da realidade das coisas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora Cristo esteja totalmente sob uma e outra
espécie, contudo nenhuma delas é inútil. - Primeiro porque serve de representar a paixão de Cristo, em
que o sangue se separou do corpo. Por isso, na forma da consagração do sangue se faz menção da sua
efusão. - Segundo tal é conveniente ao uso deste sacramento, a fim de ser dado separadamente aos
fiéis - o corpo de Cristo, como comida e o sangue como bebida. Terceiro, quanto ao efeito, pois, como
dissemos, o corpo é dado para a salvação do nosso corpo e sangue, para a salvação da alma.

RESPOSTA À SEGUNDA. — Na paixão de Cristo de que este sacramento é o memorial, não houve outras
partes do corpo separadas das demais como, o sangue; mas o corpo permaneceu na sua integridade,
conforme àquilo da Escritura: Por isso, neste sacramento o sangue é consagrado separadamente do
corpo, mas não outra parte qualquer, separada do conjunto.

RESPOSTA À TERCEIRA. — Como dissemos o corpo de Cristo não está sob a espécie do vinho, por força
do sacramento, mas por concomitância real. Por onde depois de consagrado o vinho aí não está o corpo
de Cristo por si mesmo, mas por concomitância.

## Art. 3 — Se o corpo de Cristo está todo em qualquer parte das espécies do pão ou do vinho.
O terceiro discute-se assim. — Parece que o corpo de Cristo não está todo em qualquer parte das
espécies do pão e do vinho.

1. — Pois. essas espécies não podem dividir-se ao infinito. Se portanto Cristo estivesse todo em cada
uma das partes das espécies referidas, estaria por consequência infinitas vezes neste sacramento. O que
é inadmissível, porque o infinito repugna, não só à natureza, mas também à graça.

2. Demais. — O corpo de Cristo, sendo orgânico, tem partes em determinadas distantes uma das outras,
como um olho, do outro, e os olhos, dos ouvidos. Ora, tal não podia dar-se se Cristo estivesse todo em
qualquer das espécies: porque então, qualquer parte estaria necessàriamente em qualquer outra e,
portanto, onde estivesse uma estaria também à outra. Logo, não pode Cristo estar todo em qualquer
parte da hóstia ou do vinho contido no cálice.

3. Demais. — O corpo de Cristo conserva sempre a natureza de um verdadeiro corpo, nem se
transforma nunca no espírito. Ora, é da natureza do corpo ter uma quantidade numa certa posição,
como o ensina Aristóteles. Mas essa quantidade requer essencialmente que partes diversas ocupem
partes diversas do lugar. Logo, parece que não é possível o corpo de Cristo estar todo em qualquer parte
das espécies.
Mas, em contrário, diz Agostinho: Cada qual recebe a N. S. Jesus Cristo que está todo em cada uma das
partes nem fica diminuído por estar em cada uma mas ao contrário da se todo em cada uma delas.

SOLUÇÃO. — Como do sobredito resulta, neste sacramento a substância do corpo de Cristo está por
força mesma do sacramento ao passo que a quantidade dimensiva nele está em virtude da
concomitância real. Logo, o corpo de Cristo está neste sacramento substancialmente, isto é, ao modo
pelo qual a substância está contida nas suas dimensões; não porem ao modo das dimensões, isto é, não
do modo pelo qual a quantidade dimensiva de um corpo está na quantidade dimensiva do lugar. Ora,
como é manifesto, substância, por natureza, esta toda em qualquer parte das dimensões em que esta
contida, assim como em qualquer parte do ar esta todo ele, por natureza, em qualquer parte do pão
está, por natureza, todo o pão. E isto indiferentemente: quer estejam as dimensões divididas
atualmente, como quando o ar é dividido ou o pão cortado; quer também se estivessem indivisas em
ato, mas forem divisíveis em potência. Por onde é manifesto que o corpo de Cristo está todo em cada
parte das espécies do pão, mesmo a hóstia permanecendo inteira, e não somente quando é fracionada
como dizem certos, aduzindo o exemplo da imagem que aparece num espelho, a qual aparece una, num
espelho inteiro, ao passo que, num espelho partido, aparece cada imagem em cada uma das partes do
espelho. Pois, esse símile não é perfeito. Porque, a multiplicação dessas imagens se dá num espelho
quebrado por causa das diversas reflexões das partes diversas ao espelho; ao passo que no caso
vertente não há senão uma consagração em virtude da qual o corpo de Cristo está neste sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O número resulta da divisão. Por onde, enquanto a
quantidade permanece indivisa, nem o substância da coisa está várias vezes sob as suas dimensões
próprias nem o corpo de Cristo sob as dimensões do pão. E por conseqüência nem infinitas vezes; mas
tantas vezes quantas as partes divididas.

RESPOSTA À SEGUNDA. — Essa distância determinada das partes de um corpo orgânico se funda na
quantidade dimensiva dele; mas a natureza da substância precede mesmo a quantidade dimensiva. Por
onde a conversão da substância do pão, tendo como termo direto a substância do corpo de Cristo,
segundo cujo modo o corpo de Cristo está própria e diretamente neste sacramento, essa distância entre
as partes existe por certo no corpo mesmo verdadeiro de Cristo: mas não é segundo essa distância que
está neste sacramento, mas ao modo da sua substância, como se disse.

RESPOSTA À TERCEIRA. — A objeção colhe quanto à natureza que um corpo tem pela quantidade
dimensiva. Ora, dissemos que o corpo de Cristo não está neste sacramento em razão da quantidade
dimensiva, mas substancialmente como dissemos.

## Art. 4 — Se a quantidade dimensiva do corpo de Cristo está toda neste sacramento.
O quarto discute-se assim. — Parece que a quantidade dimensiva do corpo de Cristo não está toda
neste sacramento.

1. — Pois, como se disse, todo o corpo de Cristo está contido em qualquer parte da hóstia consagrada.
Ora, nenhuma quantidade dimensiva está contida roda num todo e em qualquer das partes dele. Logo é
impossível que toda a quantidade dimensiva do corpo de Cristo esteja contida neste sacramento.

2. Demais. — É impossível duas quantidades dimensivas existirem simultaneamente, mesmo se uma
esteja separada, e a outra num corpo natural, como está claro no Filósofo. Ora, neste sacramento
permanece a quantidade dimensiva do pão, como os nossos sentidos o atestam. Logo, aí não está o
corpo de Cristo quantitativamente.

3. Demais. — Se duas quantidades dimensivas desiguais forem justapostas, a maior se estende além da
menor. Ora, a quantidade dimensiva do corpo de Cristo é muito maior que a quantidade dimensiva da
hóstia consagrada em todas as dimensões. Se portanto, neste sacramento coexiste a quantidade
dimensiva do corpo de Cristo como a quantidade dimensiva da hóstia, a quantidade dimensiva do corpo
de Cristo se estende além da quantidade da hóstia que contudo não existe sem a substância do corpo de
Cristo. Logo, a substância do corpo de Cristo estará neste sacramento, mesmo sem a espécie do pão. O
que é inadmissível, pois, a substância do corpo de Cristo não está neste sacramento senão pela
consagração do pão, como se disse. Logo, é impossível o corpo de Cristo estar quantitativa e totalmente
neste sacramento.
Mas, em contrário, a quantidade dimensiva de um corpo não se separa, quanto ao ser, da substância
dele. Ora, neste sacramento está totalmente a substância do corpo de Cristo, como se estabeleceu.
Logo', a quantidade dimensiva do corpo de Cristo está toda neste sacramento.

SOLUÇÃO. — Como dissemos de dois modos algo de Cristo está neste sacramento: por força do
sacramento e por concomitância real. - Por força do sacramento, a quantidade dimensiva do corpo de
Cristo não está neste sacramento. Mas por força do sacramento neste está aquilo que é diretamente o
termo da conversão. Ora, a conversão neste sacramento operado diretamente, termina na substância
do corpo de Cristo mas não nas suas dimensões. O que resulta de permanecer a quantidade dimensiva,
feita a consagração e desaparecida só a substância do pão. Como porem a substância do corpo de Cristo
não fica realmente dividida da sua quantidade dimensiva e dos outros acidentes, daí vem que, em
virtude da concomitância real, está neste sacramento totalmente a quantidade dimensiva do corpo de
Cristo e todos os seus acidentes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O modo de ser de uma coisa se determina pelo que lhe é
essencial e não pelo que lhe é acidental. Assim, um corpo é visível por ser branco e não por ser doce;
embora esse mesmo corpo possa ser branco e doce. Por onde, a doçura é visível enquanto brancura, e
não enquanto doçura. Ora, como em virtude deste sacramento está no altar a substância do corpo de
Cristo, e a sua quantidade dimensiva aí está concomitantemente e quase por acidente, por isso a
quantidade dimensiva do corpo de Cristo está neste sacramento, não ao modo que lhe é a ele próprio,
isto é, estando toda no todo e cada parte em cada parte - mas a modo de substância, que por natureza
está toda no todo e toda em cada parte.

RESPOSTA À SEGUNDA. — Duas quantidades dimensivas não podem coexistir simultaneamente no
mesmo sujeito, de maneira que cada uma aí esteja ao modo próprio de quantidade dimensiva. Ora,
neste sacramento, a quantidade dimensiva do pão está ao seu modo próprio, isto é, segundo uma certa
comensuração; mas não a quantidade dimensiva do corpo de Cristo, que aí está ao modo da substância,
como dissemos.

RESPOSTA À TERCEIRA. — A quantidade dimensiva do corpo de Cristo não está neste sacramento
enquanto susceptível de comensuração, próprio à quantidade, em virtude do qual uma quantidade
maior é mais extensa que uma menor; mas aí está do modo já referido.

## Art. 5 — Se o corpo de Cristo está neste sacramento como em um lugar.
O quinto discute-se assim. — Parece que o corpo de Cristo está neste sacramento como em um lugar.

1. — Pois, estar em alguma coisa definida ou circunscritivamente, é um modo de estar locativamente.
Ora, o corpo de Cristo está definidamente neste sacramento, porque aí está onde estão as espécies do
pão ou do vinho, que não estão num outro lugar do altar. E também aí está circunscritivamente, porque
de modo está contido na superfície da hóstia consagrada, que nem a excede nem é dela excedida. Logo,
o corpo de Cristo está neste sacramento como num lugar.

2. Demais. — O lugar das espécies do pão não é o vácuo porque a natureza não se compadece com o
vácuo. Nem ai está a substância do pão como se estabeleceu mas só o corpo de Cristo. Logo o corpo de
Cristo enche esse lugar. Ora, tudo o que enche um lugar, nele está situado localmente. Logo, o corpo de
Cristo está neste sacramento localmente.

3. Demais. — Como se disse, neste sacramento está o corpo de Cristo com a sua quantidade dimensiva e
com todos os seus acidentes. Ora, estar num lugar é acidente do corpo, por isso a ubicação se enumera
entre os nove gêneros de acidentes. Logo, o corpo de Cristo está neste sacramento localmente.
Mas, em contrário, lugar e locado devem ser iguais, como está claro no Filósofo. Ora, o lugar onde está
este sacramento é muito menor que o corpo de Cristo. Logo, o corpo de Cristo não está neste
sacramento como num lugar.

SOLUÇÃO. — Como dissemos o corpo de Cristo não está neste sacramento ao modo próprio da
quantidade dimensiva, mas antes ao modo da substância. Ora, todo corpo locado está no lugar ao modo
da quantidade dimensiva, isto é, enquanto é comensurado com o lugar segundo a sua quantidade
dimensiva. Donde se conclui, que o corpo de Cristo não está neste sacramento como em um lugar, mas
ao modo da substância, isto é, do modo pelo qual a substância está contida nas dimensões. Pois, sucede
a substância do corpo de Cristo, neste sacramento, à substância do pão. Por onde assim como a
substância do pão não estava localmente contida nas suas dimensões, mas ao modo da substância,
assim nem o está a substância do corpo de Cristo. Não é porem a substância do corpo de Cristo o sujeito
dessas dimensões, como o era a substância do pão. Por onde, o pão, em virtude das suas dimensões aí
estava localmente, porque ocupava um lugar condizente com as próprias dimensões. Ao passo que a
substância do corpo de Cristo ocupava esse lugar mediante dimensões alheias; de modo que,
inversamente as dimensões próprias do corpo de Cristo ocupam esse lugar mediante a substância. O
que é contrário à natureza do corpo locado. Por onde, de nenhum modo o corpo de Cristo está neste
sacramento localmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo não está neste sacramento de maneira definida,
porque então não estaria a não ser no altar onde o sacramento é celebrado; e contudo está também no
céu em espécie própria e em muitos altares sob a espécie sacramental. Semelhantemente é também
claro que não está neste sacramento circunscritivamente, porque nele não está segundo a
comensuração da quantidade própria, como se disse. O que porém não está fora da superfície do
sacramento, nem está em outra parte do altar, aí não está definida e circunscritivamente, mas aí
começa a estar pela consagração e pela conversão do pão e do vinho, como dissemos.

RESPOSTA À SEGUNDA. — O lugar em que está o corpo de Cristo não está vazio. Nem contudo está
propriamente cheio da substância do corpo de Cristo, que aí não está localmente, como se disse. Mas
está cheio das espécies sacramentais, que podem ocupar o lugar, ou pela natureza das dimensões, ou
pelo menos miraculosamente, assim como subsistem miraculosamente a modo de substância.

RESPOSTA À TERCEIRA. — Os acidentes do corpo de Cristo estão neste sacramento, segundo se disse,
por concomitância real. Por onde, aqueles acidentes do corpo de Cristo estão neste sacramento, que lhe
são intrínsecos. Ora, estar em um lugar é um acidente relativamente ao continente extrínseco. Por isso
não está Cristo necessàriamente neste sacramento como num lugar.

## Art. 6 — Se o corpo de Cristo se moveu, movendo-se o sacramento.
O sexto discute-se assim. — Parece que o corpo de Cristo se move, movendo-se o sacramento.

1. — Pois, diz o Filósofo, que quando nos movemos, move-se tudo o existente em nós. Isso é verdade,
mesmo da substância espiritual da alma. Ora, Cristo está neste sacramento, como se disse. Logo, move-
se quando se ele move.

2. Demais. — A verdade deve responder à figura. Ora, do Cordeiro Pascal, que era a figura deste
sacramento, nada restava até a manhã, como preceituava a Lei. Logo, nem neste sacramento, se for
conservado para o dia seguinte, estará o corpo de Cristo. Portanto, nele não está de um modo imóvel.

3. Demais. — Se Cristo permanecesse neste sacramento até o dia seguinte, pela mesma razão nele
permaneceria por todo o tempo subsequente; pois, não se pode dizer que aí cesse de estar
desaparecendo as espécies, porque a existência do corpo de Cristo não depende dessas espécies. Ora,
Cristo não permanece neste sacramento por todo o tempo futuro. Logo, parece que já no dia seguinte,
ou depois de pouco tempo, deixa de estar neste sacramento. Donde se concluí, que Cristo está neste
sacramento, sujeito ao movimento.
Mas, em contrário. – Impossível, é um ente estar em movimento e em repouso, porque então, nele se
realizariam os contraditórios. Ora, o corpo de Cristo está no céu em repouso. Logo, não está neste
sacramento sujeito ao movimento.

SOLUÇÃO. — Um ser uno quanto ao seu sujeito, mas multiplo por natureza, nada impede que se mova,
de um modo, e permaneça imóvel, de outro. Assim, uma coisa é ser um corpo branco e outra, grande; e
por isso, pode mover-se no concernente à brancura, e ficar imóvel quanto à grandeza. Ora, Cristo não
tem o mesmo ser, em si mesmo e neste sacramento; pois, quando dizemos que está neste sacramento,
queremos significar uma certa relação sua com ele. Por onde, segundo este modo de ser, Cristo não se
move nenhuma outra mutação; por exemplo, deixando de nele estar. Pois o ser em si mesmo
indefectível não pode ser princípio de defecção; mas quando o ser em que ele está desaparece deixa
então de nele estar. Assim Deus, cujo ser é indefectível e imortal deixa de estar em uma criatura
corruptível quando esta perde o ser. E deste modo, tendo Cristo em si mesmo um ser indefectível e
incorruptível, não deixa de estar neste sacramento, nem quando este deixa de existir, nem por se mover
localmente, como do sobre dito se mostra, mas só quando as espécies deste sacramento deixam de
existir. Por onde é claro que Cristo, absolutamente falando, nele está imovelmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe quanto ao movimento acidental, em
virtude do qual, quando nos movemos também se move tudo o existente em nós. Mas, o que passa com
os seres que por natureza podem estar num lugar, como os corpos, não passa com os que por natureza
nele não podem estar como as formas e as substâncias espirituais. E a este modo pode reduzir-se o
dizermos que Cristo pode mover-se acidentalmente segundo o ser que tem neste sacramento onde não
está como em lugar.

RESPOSTA À SEGUNDA. — Pela razão aduzida foram levados certos, dizendo que o corpo de Cristo não
permanece neste sacramento, se for guardado para o dia seguinte. Contra o que diz Cirilo: É uma
insanidade a dos que dizem que a mística bênção cessa de existir, em qualquer parte do sacramento,
guardada para o dia seguinte. Pois, não se muda o corpo sagrado de Cristo, mas a virtude da bênção e a
graça vivificada nele permanecem permanente. Assim como também todas as outras consagrações
permanecem imutáveis, permanecendo as coisas consagradas; e por isso não são reiteradas. - Pois,
embora a verdade corresponda à figura, contudo esta não poder ser igual a ela.

RESPOSTA À TERCEIRA. — O corpo de Cristo permanece neste sacramento não só até o dia seguinte,
mas também para o futuro, enquanto permanecem as espécies sacramentais. Desaparecidas elas, sob
elas deixa de estar o corpo de Cristo; não que delas dependa, mas por desaparecer a relação que com
elas tem. Por cujo modo Deus deixa de ser Senhor da criatura desaparecida.

## Art. 7 — Se o corpo de Cristo enquanto está neste sacramento, pode ser visto por certos olhos, ao menos pelos dos glorificados.
O sétimo discute-se assim. — Parece que o corpo de Cristo, enquanto está neste sacramento, pode ser
visto por certos olhos, ao menos pelos dos glorificados.

1. — Pois, os nossos olhos ficam impedidos de ver o corpo de Cristo, existente neste sacramento, por
causa das espécies sacramentais que o velam. Ora, os olhos dos glorificados não sofrem nenhum
impedimento que o impedisse de ver quaisquer corpos como são. Logo, os olhos dos glorificados podem
ver o corpo de Cristo como está neste sacramento.

2. Demais. — Os corpos gloriosos; dos santos serão conformes ao corpo glorioso de Cristo, como diz a
Escritura. Ora os olhos de Cristo o vêem a ele tal qual está neste sacramento. Lugo, pela mesma razão,
quaisquer outros olhos glorificados podem vê-la.

3. Demais. — Os santos na ressurreição serão iguais aos anjos, no dizer do Evangelho. Ora, os anjos
vêem o corpo de Cristo tal qual está neste sacramento; pois, mesmo os demônios foram vistos prestar-
lhe reverência e temê-lo. Logo, pela mesma razão, os olhos dos glorificados podem vê-la tal como neste
sacramento está.
Mas, em contrário. - O que existe sempre do mesmo modo não· pode ser visto por ninguém sob
espécies diversas. Ora, os olhos dos glorificados sempre vêem a Cristo como ele é em espécie, segundo
àquilo da Escritura: Verão o rei no seu esplendor. Logo, parece que não vêem a Cristo na espécie que
tem neste sacramento.

SOLUÇÃO. — Há duas espécies de olhos: os do corpo, que são propriamente, e os da inteligência, assim
chamados por semelhança. Ora, por nenhuns olhos corpóreos pode o corpo de Cristo ser visto tal como
está neste sacramento. Primeiro, porque o corpo visível, pelos seus acidentes modifica o meio. Ora, os
acidentes do corpo de Cristo estão neste sacramento mediante a substância. Mas de modo que os
acidentes do corpo de Cristo não têm relação imediata nem com este sacramento, nem com os corpos
que o circundam. E assim nenhuma mudança podem causar no meio, de maneira a poderem ser vistos
por quaisquer olhos corpóreos. - Segundo, porque, como dissemos, o corpo de Cristo está neste
sacramento a modo de substância. Ora, a substância como tal não é visível pelos olhos do corpo, nem é
perceptível por nenhum sentido, nem mesmo pela imaginação, mas só pelo intelecto, chamado olho do
espírito, cujo objeto é a quididade, como diz Aristóteles. - Por onde, propriamente falando, o corpo de
Cristo, pelo modo de ser que tem neste sacramento, não é perceptível nem pelos sentidos nem pela
imaginação, mas só pelo intelecto, que são os olhos do espírito. É percebido porém diversamente pelos
diversos intelectos. Pois, o modo de ser pelo qual Cristo está neste sacramento sendo completamente
sobrenatural, pelo intelecto sobrenatural, isto é, divino, é em si mesmo visível; e por consequência, pelo
intelecto do anjo ou do homem bem-aventurados - que, segundo a claridade participada do intelecto
divino vêem o sobrenatural - pela visão da essência divina. Mas, pelo intelecto do homem nesta vida,
não pode ser visto senão ajudado da fé, pois é assim que também percebe tudo o mais sobrenatural.
Mas nem ainda o intelecto angélico, pela suas potências naturais, é capaz dessa visão. Por isso os
demônios não podem pelo intelecto ver a Cristo neste sacramento, senão com olhos da fé; à qual não
assentem voluntàriamente, mas a evidência dos sinais disso os convencem, conforme àquilo da
Escritura - os demônios crêem e estremecem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os olhos do nosso corpo ficam pelas espécies
sacramentais impedidos de ver o corpo de Cristo sob elas existentes. E não só por nos impedirem, por
serem eles uma como cobertura, assim como ficamos impedidos de ver o que está velado por qualquer
velame corpóreos; mas porque o corpo de Cristo não tem relação com o meio que circunda este
sacramento, mediante os acidentes próprios, senão mediante as espécies sacramentais.

RESPOSTA À SEGUNDA. — Os olhos corpóreos de Cristo vêm-no a ele mesmo existente sob o
sacramento; mas não podem ver o modo mesmo pelo qual existe sob o sacramento, o que só o intelecto
o pode. Mas não há aí símile com a visão dos bem aventurados, porque os olhos mesmos de Cristo estão
sob este sacramento, no que com ele não se conformam nenhuns olhos de bem aventurados.

RESPOSTA À TERCEIRA. — O anjo bom ou mau não pode ver com olhos corpóreos, mas unicamente
com os olhos do intelecto. Logo, não há semelhança de razão, como se infere do que ficou dito.

## Art. 8 — Se quando neste sacramento aparece miraculosamente a carne ou um menino, aí está o verdadeiro corpo de Cristo.
O oitavo discute-se assim. — Parece que quando neste sacramento aparece miraculosamente a carne
ou um menino, aí não está o verdadeiro corpo de Cristo.

1. — Pois, o corpo de Cristo deixa de estar neste sacramento, quando deixam de existir as espécies
sacramentais, como se disse. Ora, quando aparece a carne ou um menino, deixam de existir as espécies
sacramentais. Logo, aí não está o verdadeiro corpo de Cristo.

2. Demais. — Onde quer que esteja o corpo de Cristo, aí está ou sob a espécie própria ou sob a espécie
sacramental. Ora, quando se dão tais aparições, é manifesto que aí não está o corpo de Cristo sob a
espécie própria. Pois, neste sacramento está Cristo contido totalmente, que permanece na forma
íntegra com que subiu ao céu. E, contudo, o que aparece milagrosamente neste sacramento umas vezes
é visto sob a forma de um pequeno corpo, e outras sob a de um menino pequeno. Mas, como é
manifesto, também aí não está sob a espécie sacramental, que é a espécie do pão ou do vinho. Logo,
parece que de nenhum modo aí está o corpo de Cristo.

3. Demais. — O corpo de Cristo começa a existir neste sacramento pela consagração e pela conversão,
como se disse. Ora, a carne e o sangue milagrosamente aparecidos, não foram consagrados nem
convertidos no verdadeiro corpo e sangue de Cristo. Logo, sob tais espécies não está o corpo nem o
sangue de Cristo.
Mas, em contrário dada à aparição, prestasse a mesma reverência ao aparecido, que também se
prestava à hóstia consagrada. O que se não faria se ai não estivesse verdadeiramente Cristo, a quem
prestamos a reverência de latria. Logo, mesmo quando tem lugar tal aparição, Cristo está sob este
sacramento.

SOLUÇÃO. — De dois modos pode dar-se essa aparição, pela qual às vezes miraculosamente se vê neste
sacramento a carne, o sangue ou também um menino. Assim, às vezes isso se dá da parte dos videntes,
cuja vista sofre uma tal alteração, como se vissem exterior e expressivamente a carne, ou o sangue ou
um menino, sem o sacramento sofrer nenhuma alteração. E isto acontece quando um vê sob a espécie
de carne ou de um menino, continuando os outros a ver, como de antes, a espécie do pão; ou quando o
mesmo corpo de Cristo é visto primeiro sob a espécie de carne ou de um menino, e depois sob a espécie
de pão. Nem isto induz em qualquer engano, como o fazem as prestigitações dos magos; porque tal
espécie é formada por Deus nos olhos, para figurar alguma verdade, isto é, para manifestar que o corpo
de Cristo está verdadeiramente sob esse sacramento, assim como também Cristo, sem engano,
apareceu aos discípulos que iam para Emaús. Pois, como diz Agostinho, quando a nossa ficção implica
um significado, não há mentira, mas uma verdade figurada. E não sofrendo deste modo nenhuma
alteração o sacramento, é claro que Cristo não deixa de nele estar, realizada a aparição.
Outras vezes porém se dá essa aparição, não pela só alteração nos olhos dos videntes, mas também na
forma vista, real e exteriormente. E isto se dá quando todos vêem o corpo de Cristo sob tal espécie, e
não momentaneamente, mas permanecendo durante longo tempo. E neste caso, certos dizem que se
trata da espécie própria do corpo de Cristo. Nem importa que, às vezes, não seja aí visto todo o corpo
de Cristo, mas só uma parte; ou ainda, que não seja visto sob uma figura juvenil, mas em efígie pueril.
Pois, está no poder de um corpo glorioso deixar-se ver por olhos não glorificados, total ou parcialmente,
e em efígie própria ou alheia, como a seguir se dirá. Mas esta opinião não é admissível. - Primeiro,
porque o corpo de Cristo não pode ser visto da sua figura própria, senão no lugar em que definidamente
está. Por onde, sendo contemplado e adorado nos céus, na sua figura própria, não pode ser sob essa
mesma figura contemplado neste sacramento. - Segundo, porque o corpo glorioso, que aparece como
quer, desaparece quando quer, depois da aparição; assim, refere o Evangelho, que o Senhor
desapareceu aos olhos dos discípulos. Ora, o que aparece sob a espécie de carne neste sacramento,
permanece longamente; e até mesmo, como se lê, foi às vezes encerrado e conservado numa pixide,
por conselho de muitos bispos; o que não se poderia pensar, de Cristo, na sua figura própria. Por onde,
devemos concluir que, enquanto permanecem as dimensões anteriormente existentes, opera-se
milagrosamente uma alteração sobre certos acidentes, por exemplo, a figura, a cor e outros
semelhantes, de modo a ser vista a carne ou o sangue ou ainda um menino. E, como dissemos, não há aí
nenhum engano; porque isso se dá para figurar uma verdade, isto é, para mostrar, por essa milagrosa
aparição, que no sacramento está verdadeiramente o corpo e o sangue de Cristo. Por onde, é claro que,
permanecendo as dimensões, fundamentos dos outros acidentes, como depois dizemos permanece o
verdadeiro corpo de Cristo neste sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Durante essa aparição, as espécies sacramentais às
vezes permanecem totalmente tais quais são; outras vezes porem, só no que têm de principal, como
dissemos.

RESPOSTA À SEGUNDA. — Em tais aparições, como dissemos, não é visto o corpo de Cristo na sua
forma própria, mas uma espécie formada milagrosamente ou nos olhos dos videntes, ou então nas
próprias dimensões sacramentais, como se disse.

RESPOSTA À TERCEIRA. — As dimensões do pão e do vinho consagradas permanecem, sofrendo
alteração milagrosa só os outros acidentes delas, como se disse.