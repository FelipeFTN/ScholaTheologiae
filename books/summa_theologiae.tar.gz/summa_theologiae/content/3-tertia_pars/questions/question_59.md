# Questão 59: Do poder judiciário de Cristo
Em seguida devemos tratar do poder judiciário de Cristo. Da execução do juízo final trataremos mais
desenvolvidamente quanto examinarmos o concernente ao fim do mundo. Por agora basta tratarmos só
do que respeita à dignidade de Cristo.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se o poder judiciário deve ser especialmente atribuído a Cristo.
Parece que o poder judiciário não deve ser especialmente atribuído a Cristo.

1. — Pois, julgar é um poder próprio de quem é senhor, em relação aos seus súditos. Por isso pergunta o
Apóstolo: Quem és tu que julgas o servo alheio. Ora, ter o domínio das criaturas é comum a toda a
Trindade. Logo, o poder judiciário não deve ser atribuído especialmente a Cristo.

2. Demais. — Daniel diz: O antigo dos dias se assentou. E acrescenta: Assentou-se o juízo e abriram-se os
livros. Ora, pelo Antigo dos dias entende-se o Padre; porque, como diz Hilárío, o Padre é eterno. Logo, o
poder judiciário deve ser atribuído antes ao Pai que a Cristo.

3. Demais. — Compete julgar a quem compete arguir. Ora, arguir compete ao Espírito Santo, conforme o
diz o Senhor: Ele quando vier, isto é, o Espírito Santo, arguirá o mundo do pecado e da justiça e do juízo.
Logo, o poder judiciário deve ser atribuído antes ao Espírito Santo que a Cristo.
Mas, em contrário, a Escritura, referindo-se a Cristo: Ele é o que por Deus foi constituído juiz de vivos e
mortos.

SOLUÇÃO. — A emissão de um juízo exige três condições. Primeiro, o poder de governar súditos, donde
o dizer a Escritura: Não pretendas ser juiz se não tens valor para romperes com esforço por entre as
iniquidades. Em segundo lugar é necessário a retidão do zelo, isto é, não devemos proferir o juízo por
ódio ou inveja, mas por amor da justiça, segundo aquilo da Escritura: Porque o Senhor castiga aquele a
quem ama e acha nele a sua complacência como um pai a seu filho. Terceiro, é necessária a sabedoria,
fundada na qual formamos o juízo, donde o dizer a Escritura: O juiz sábio fará justiça ao seu povo. Ora,
as duas primeiras condições o juízo as preexige; mas na terceira é que propriamente se funda a forma
dele, pois, a razão mesma do juízo é a lei da sabedoria ou da verdade, segundo a qual julgamos. — E
como o Filho é a Sabedoria gerada e a Verdade procedente do Pai, que perfeitamente o representa, por
isso o poder judiciário é atribuído como próprio ao Filho de Deus. Por isso diz Agostinho: Esta é aquela
Verdade incomutável, acertadamente chamada a lei de todas as artes e a arte do Artífice onipotente.
Pois, assim como nós e todas as almas racionais julgamos com retidão os nossos inferiores, fundados na
Verdade, assim só a Verdade é quem nos julga, quando estamos a ela unidos. Mas julgá-la a ela nem o
Pai o pode, pois não é menor que ele. Por isso, o que o Pai julga, por meio dela é que julga. E depois
conclui: Portanto o Pai não julga a ninguém, mas deu ao Filho todo poder de julgar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A razão aduzida prova que o poder judiciário é comum a
toda a Trindade; o que é verdade. Contudo e por uma certa apropriação, o poder judiciário é atribuído
ao Filho, como dissemos.

RESPOSTA À SEGUNDA. — Como diz Agostinho, ao Pai é atribuída à eternidade para pôr em evidência o
princípio, implicado na idéia de eternidade. Assim, no mesmo lugar diz ainda, que o Filho é a arte do Pai.
Por onde, a autoridade de julgar é atribuída ao Pai enquanto princípio do Filho; mas a função mesma de
julgar é atribuída ao Filho, que é a arte e a sabedoria do Pai. De modo que, assim como o Pai faz tudo
pelo Filho, como a arte sua que é, assim também tudo julga pelo Filho, por ser este a sua sabedoria e ·a
sua verdade. Tal é o significado das palavras de Daniel, quando diz que o Antigo dos dias se assentou,
acrescentando depois, que o Filho do homem chegou até o Antigo dos dias e lhe deu o poder e a honra
e o reino. Dando assim a entender, que a autoridade de julgar é própria do Pai, de quem o Filho recebe
o poder de julgar.

RESPOSTA À TERCEIRA. — Como explica Agostinho, quando Cristo disse que o Espírito Santo arguirá o
mundo do pecado, é como se tivesse dito: Ele difundirá nos nossos corações a caridade. E é assim que,
livres do temor, tereis a liberdade de arguir. Por onde, ao Espírito Santo é atribuído o juízo, não quanto
à essência dele, mas quanto ao desejo de julgar, que os homens têm.

## Art. 2 — Se o poder judiciário convém a Cristo enquanto homem.
O segundo discute-se assim. — Parece que o poder judiciário não convém a Cristo enquanto homem.

1. — Pois, diz Agostinho, que o juízo é atribuído ao Filho, enquanto a lei primeira da verdade. Ora, isto é
próprio de Cristo, como Deus. Logo, o poder judiciário não convém a Cristo, enquanto homem, mas
enquanto Deus.

2. Demais. — Ao poder judiciário pertence premiar os que procedem bem, assim como punir os maus.
Ora, o prêmio das boas obras é a beatitude eterna, só dada por Deus. Assim, diz Agostinho, que pela
participação de Deus, e não pela de nenhuma alma santa, é que a alma se torna feliz. Logo, parece que o
poder judiciário não compete a Cristo, enquanto homem, mas enquanto Deus.

3. Demais. — Ao poder judiciário de Cristo pertence o poder de julgar as cogitações ocultas dos
corações, segundo aquilo do Apóstolo: Não julgueis antes do tempo, até que venha o Senhor, o qual não
só porá às claras o que se acha escondido nas mais profundas trevas, mas descobrirá ainda o que há de
mais secreto nos corações. Ora, isso só ao poder divino pertence, conforme à Escritura: Depravado é o
coração de todos e impenetrável: quem o conhecerá? Eu sou o Senhor, que esquadrinha o coração e
que sondo os afetos, que dou a cada um segundo o seu caminho. Logo, o poder judiciário não convém a
Cristo, enquanto homem, mas enquanto Deus.
Mas, em contrário: o Evangelho: Deu-lhe o poder de exercitar o juízo porque é Filho do homem.

SOLUÇÃO. — Crisóstomo parece ser de opinião que o poder judiciário não convém a Cristo enquanto
homem, mas só enquanto Deus. E por isso expõe assim o lugar citado de João: Deu-lhe o poder de
exercitar o juízo, Nem vos admireis disso, pois, é o Filho de Deus. Assim, não recebeu o exercício do juízo
por ser homem; mas por ser o Filho do Deus inefável, por isso é juiz. Como, porém, exceda tudo o que
dizia à capacidade humana, por isso o Evangelho resolve a dificuldade dizendo: Não vos admireis, ser
Filho do homem, pois esse mesmo é também Filho de Deus. E isso o prova pelo efeito da ressurreição, e
acrescenta: Porque veio à hora em que todos os que estão nos sepulcros ouvirão a voz de Deus.
Devemos porém notar que, embora em Deus resida a autoridade primeira de julgar, contudo comete
aos homens o poder judiciário relativamente dos que lhes estão sujeitos àjurisdição. Donde o dizer a
Escritura: Julgai o que for justo; acrescentando depois - Porque é o juízo de Deus, isto é, pela autoridade
dele é que julgais. Ora, como dissemos, Cristo, mesmo na sua natureza humana, é a cabeça de toda a
Igreja, pois debaixo de seus pés Deus sujeitou todas as coisas. Por isso lhe pertence, mesmo enquanto
homem exercer o poder judiciário. Donde o dizer Agostinho, que o lugar citado do Evangelho deve ser
entendido como significando: Deu-lhe o poder de proferir juízo, por ser o Filho do Homem. Não certo
pela condição da natureza humana, porque então todos os homens teriam tal poder como objeta
Crisóstomo, mas por lh'o pertencer à graça de chefe que Cristo como homem recebeu.
Deste modo cabe, pois, a Cristo, enquanto homem, o poder judiciário, por três razões. — Primeiro, pela
sua união e afinidade com os homens. Pois, assim como Deus obra, por causas mediatárias, como as
mais próximas dos efeitos, assim julga os homens por meio de Cristo homem, para se lhes tornar o juízo
mais suave. Donde o dizer o Apóstolo: Não temos um pontífice que não possa compadecer-se das
nossas enfermidades, mas que foi tentado em todas as coisas ànossa semelhança, exceto o pecado.
Cheguemo-nos pois confiadamente ao trono da graça. — Segundo, porque no juízo final, como ensina
Agostinho, haverá a ressurreição dos corpos dos mortos, que Deus ressuscitará mediante o Filho do
Homem; assim como peio mesmo Cristo ressuscita as almas, enquanto Filho de Deus. — Terceiro,
porque, como ensina Agostinho, era justo que os que iam ser julgados vissem o juiz. Ora, iam ser
julgados os bons e os maus. Restava, pois, que no juízo a forma de servo se manifestasse aos bons e aos
maus, mas a forma de Deus fosse reservada só para os bons.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O juízo deve ter na verdade a sua regra; mas ao homem
conformado com a verdade pertence julgar enquanto fazendo com ela uma só realidade, quase como a
lei e a justiça animada. Por isso, no mesmo lugar Agostinho aduz o passo do Apóstolo: O espiritual julga
de todas as coisas. Ora, a alma de Cristo, mais que as outras criaturas, estava unida à verdade e dela
cheia, segundo o Evangelho: Vimo-lo cheio de graça e de verdade. E, assim sendo, à alma de Cristo
sobretudo pertence julgar de todas as coisas.

RESPOSTA À SEGUNDA. — Só Deus pode tornar, pela sua participação; bem-aventuradas as almas. Mas,
levar o homem à bem-aventurança pode-o Cristo enquanto cabeça e autor da salvação deles, segundo
aquilo do Apóstolo: Havendo de levar muitos filhos à glória, convinha consumasse pela paixão o autor
da salvação deles.

RESPOSTA À TERCEIRA. — Conhecer as cogitações ocultas dos corações e julgar delas essencialmente só
o pode Deus; mas pela refluência da divindade na alma de Cristo, pode também ele conter e julgar os
segredos do coração, como dissemos quando tratamos da ciência de Cristo. Por isso diz o Apóstolo: No
dia em que Deus há de julgar as coisas ocultas dos homens por Jesus Cristo.

## Art. 3 — Se Cristo conquistou por seus méritos o poder judiciário.
O terceiro discute-se assim. — Parece que Cristo não conquistou por seus méritos o poder judiciário.

1. — Pois, o poder judiciário procede da dignidade real, segundo aquilo da Escritura: O rei que está
assentado no seu trono de justiça, dissipa todo o mal só com o seu olhar. Ora, Cristo alcançou a
dignidade real, sem méritos. Pois, essa lhe cabe pelo só fato de ser o unigênito de Deus, conforme o diz
o Evangelho: O Senhor Deus lhe dará o trono do seu pai Davi e reinará eternamente na casa de Jacó.
Logo, Cristo não obteve o poder judiciário pelos seus méritos.

2. Demais. — Como se disse, o poder judiciário cabe a Cristo, enquanto nosso chefe. Ora, a graça de
Cristo não lhe cabe em virtude de méritos, mas resulta da união pessoal entre a natureza divina e a
humana, segundo o Evangelho: Nós vimos a sua glória como de Filho unigênito do Pai, cheio de graça e
de verdade; e todos nós participamos da sua plenitude. Logo, parece que não foi por méritos seus que
Cristo teve o poder judiciário.

3. Demais. — O Apóstolo diz: O espiritual julga todas as coisas. Ora, o homem se torna espiritual pela
graça, que não depende de méritos, doutra sorte a graça não será graça, na frase do Apóstolo. Logo
parece que Cristo não tem o poder judiciário, como ninguém o tem, em virtude de méritos, mas só pela
graça.
Mas, em contrário, a Escritura: A tua causa tem sido julgada como a de um ímpio; ganharás a causa e
sentença. E Agostinho diz: Sentar-se-á como juiz aquele que foi julgado; condenará os verdadeiros réus
quem foi falsamente feito o réu.

SOLUÇÃO. — Nada impede ao mesmo sujeito serem devida a mesma causa a luzes diversas; assim, a
glória do corpo ressurrecto convinha a Cristo não só por congruente à divindade e para glória da alma,
mas ainda pelo mérito das humilhações da Paixão. Semelhantemente, devemos dizer que o poder
judiciário cabe a Cristo homem, tanto por causa da sua pessoa divina, como da dignidade de chefe e da
plenitude da graça habitual. E, contudo também a obteve por mérito, de modo que, pela justiça de
Deus, fosse juiz quem, por essa justiça pugnou e venceu, sendo julgado injustamente. Por isso ele
mesmo diz: Eu venci e me assentei no trono de meu Pai. Ora, por trono se entende o poder judiciário,
segundo aquilo da Escritura: Tu te assentaste sobre o trono, tu que julgas segundo a justiça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe, quanto ao poder judiciário, enquanto
devido a Cristo em virtude da sua união mesma com o Verbo de Deus.

RESPOSTA À SEGUNDA. — A objeção colhe relativamente à graça de chefe.

RESPOSTA À TERCEIRA. — A objeção procede relativamente à graça habitual, perfectiva da alma de
Cristo. Mas o ser o poder judiciário devido a Cristo, desse modo, não exclui também lh'o seja por mérito.

## Art. 4 — Se Cristo tem o poder judiciário sobre todas as coisas humanas.
O quarto discute-se assim. — Parece que Cristo não tem o poder judiciário sobre todas as coisas
humanas.

1. — Pois, como lemos no Evangelho, a um certo da multidão, que pedia a Cristo - Dize a meu irmão que
reparta comigo da herança - respondeu: Homem, quem me constituiu a um juiz ou partido sobre vós
outros? Logo, não tem o poder judiciário sobre todas as coisas humanas.

2. Demais. — Ninguém pode julgar senão o que lhe está sujeito. Ora, ainda não vemos que todas as
coisas estejam sujeitas a Cristo, como diz o Apóstolo. Logo, parece que Cristo não tem o poder judiciário
sobre todas as coisas humanas.

3. Demais. — Agostinho diz, que o juízo divino faz com que às vezes os bons sejam afligidos neste
mundo e às vezes prosperem, dando-se o mesmo com os maus. Ora, isso já se passava antes da
Encarnação de Cristo. Logo, nem todos os juízos de Deus sobre as causas humanas pertencem ao poder
judiciário de Cristo.
Mas, em contrário, o Evangelho: O Pai deu todo o juízo ao Filho.

SOLUÇÃO. — Se considerarmos a natureza divina de Cristo, então é manifesto que todo o juízo do Pai
pertence ao Filho; pois, assim como o Pai faz todas as coisas pelo seu Verbo, assim também pelo seu
Verbo julga de todas. — Mas se considerarmos a natureza humana de Cristo, também assim é manifesto
que todas as causas lhe estão sujeitas ao juízo. — O que é claro se, primeiro, atendermos à relação da
alma de Cristo com o Verbo de Deus. Se, pois, o espiritual julga de todas as coisas, na frase do Apóstolo,
enquanto a alma lhe está unida ao Verbo de Deus, com muito maior razão a alma de Cristo, cheia da
verdade do Verbo de Deus, exerce o seu juízo sobre todas as coisas. — O mesmo resulta, segundo, do
mérito da sua morte. Porque, como diz o Apóstolo, por isso é que morreu Cristo e ressuscitou, para ser
Senhor tanto de mortos como de vivos. Donde o seu poder de julgar a todos. E daí o dizer o Apóstolo no
mesmo lugar: Todos compareceremos ante o tribunal de Cristo. E noutro passo da Escritura: Ele lhe deu
o poder e a honra e o reino e todos os povos, todas as tribos e todas as línguas o virão. — Em terceiro
lugar, isso mesmo se conclui comparando as coisas humanas com o fim da salvação do homem. Pois, a
quem cometemos o principal a esse cometemos também o acessório. Ora, todas as coisas humanas se
ordenam ao fim da felicidade, que e a salvação eterna, a que os homens são admitidos ou da qual são
excluídos, pelo juízo de Cristo, como o diz o Evangelho. Por onde, é manifesto que Cristo exerce o seu
poder judiciário sobre todas as coisas humanas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como dissemos, o poder judiciário resulta da dignidade
real. Ora, Cristo embora fosse constituído rei por Deus, contudo, enquanto viveu na terra, não quis
administrar temporalmente o reino terrestre. Assim, ele próprio o disse: O meu reino não é deste
mundo. Do mesmo modo, não quis exercer o poder judiciário sobre as coisas temporais, ele que viera
elevar os homens ao plano das divinas. Por isso, Ambrósio diz no mesmo lugar: Com razão se abstém
dos bens terrenos aquele que descera à terra para nos conquistar os divinos; nem se digna ser juiz de
processo e árbitro de riquezas, quem tem o poder de julgar vivos e mortos e é o arbítrio dos méritos.

RESPOSTA À SEGUNDA. — Todas as causas estão sujeitas a Cristo, quanto ao poder que o Pai lhe deu
sobre todas, segundo aquilo do Evangelho: Tem-se-me dado todo o poder no céu e na terra. Mas não
lhe estão todas sujeitas, quanto à execução do seu poder; o que se dará no futuro, quando consumará a
sua vontade sobre todos, salvando a uns e punindo a outros.

RESPOSTA À TERCEIRA. — Antes da Encarnação esses juízos eram proferidos por Cristo, enquanto
Verbo de Deus; de cujo poder se tornou participante, pela Encarnação a alma que lhe está pessoalmente
unida.

## Art. 5 — Se além do juízo proferido no tempo presente haverá um outro juízo universal.
O quinto discute-se assim. — Parece que além do juízo proferido no tempo presente, não haverá
nenhum outro juízo, universal.

1. — Pois, é inútil acrescentar qualquer juízo, depois da atribuição dos últimos prêmios. Ora, no tempo
presente é que se faz a atribuição dos prêmios e das penas. Assim, o Senhor disse ao ladrão, na cruz:
Hoje serás comigo no paraíso. E noutro lugar o Evangelho diz: Morreu o rico e foi sepultado no inferno.
Logo, é vão esperar o juízo final.

2. Demais. — A Escritura, segundo outra letra: Deus não julgará duas vezes a mesma causa. Ora, no
tempo presente o juízo de Deus se exerce na ordem temporal e na espiritual. Logo, parece que não
devemos esperar nenhum juízo final.

3. Demais. — O prêmio e a pena correspondem ao mérito e ao demérito. Ora, o mérito e o demérito
não recaem sobre o corpo senão enquanto instrumento da alma. Logo, nem o prêmio ou a pena são
devidos aos corpos senão por causa da alma. Logo, não há necessidade de nenhum juízo final para ser o
homem premiado ou punido no seu corpo, além daquele pelo qual são punidas ou premiadas as almas.
Mas em contrário, o Evangelho: A palavra que eu tenho falado, essa o julgará no dia último. Logo,
haverá em juízo no dia último além do juízo exercido no presente.

SOLUÇÃO. — Um ser mutável não pode ser julgado perfeitamente senão depois de consumado. Assim,
nenhum juízo perfeito sobre a qualidade de uma ação pode ser proferido, antes de consumada, em si e
nos seus efeitos. Pois, muitas ações, que parecem úteis, demonstram-se nocivas pelos seus efeitos.
Semelhantemente, nenhum juízo perfeito pode ser proferido de um homem, enquanto não se lhe
terminar a vida; porque pode de muitos modos mudar do bem para o mal ou vice-versa, ou do bem para
o melhor, ou do mal para o pior. Donde o dizer o Apóstolo: Está decretado aos homens que morram
uma só vez e que depois disto se siga o juízo. Devemos, porém, saber que, embora a morte termine a
vida de um homem em si mesma, contudo permanece, de certo modo, dependente do futuro. —
Primeiro, por viver ainda na memória dos outros, que às vezes dele guardam uma fama boa ou má, que
não corresponde à verdade. — Segundo, por perdurar nos filhos, que são como parte do pai, segundo
aquilo da Escritura: Morreu o pai dele e foi como se não morresse, porque deixou depois de si um seu
semelhante. E contudo, muitos que foram bons deixaram maus filhos e inversamente. — Terceiro,
quanto ao efeito das suas obras; assim, o sofisma de Ari e de outros sedutores gerarão a infidelidade até
ao fim do mundo, bem como até o fim progredirá a fé nascida da pregação dos Apóstolos. — Quarto,
quanto ao corpo que umas vezes é dado honras e, outras, é deixado insepulto ; e contudo vem ao cabo
a resolver-se de todo em cinzas. — Quinto, quanto às coisas em que o homem fixou o seu afeto, por
exemplo, em certos bens temporais, dos quais uns acabam mais depressa e outros duram mais
diuturnamente. Ora, todas essas coisas estão sujeitas à estimativa do juízo divino. Por onde, não podem
elas todas ser perfeita e manifestamente julgadas, enquanto dura o curso desta vida. Donde a
necessidade de um juízo final, no dia derradeiro, quando o que concerne a cada homem em particular,
perfeitamente e de qualquer modo, será perfeita e manifestamente julgado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Certos foram de opinião que nem as almas dos santos
serão premiadas no céu, nem as dos condenados punidas no inferno, até o dia do juízo. O que é
manifestamente falso, pelo dito do Apóstolo: Temos confiança e ansiosos queremos mais ausentar-nos
do corpo e estar presentes ao Senhor; o que é já não andar por fé, mas por visão, como resulta da
sequência do texto. Ora, isso é ver a Deus em essência, no que consiste a vida eterna, conforme está
claro no Evangelho. Por onde é manifesto que as almas separadas do corpo vivem na vida eterna. Donde
se conclui que depois da morte, no concernente à alma, o homem está posto num estado imutável. E
assim, para prêmio da alma não é necessário seja o juízo diferido para depois. Mas, como há outras
causas que dizem respeito ao homem e se desenrolam em todo o decurso do tempo e que são alheias
ao juízo divino, é necessário que de novo, ao fim dos tempos, sejam trazidas a juízo. Embora, pois, por
elas o homem não mereça nem desmereça, contudo lhe redundam de certo modo em prêmio ou em
pena. E por isso é necessário seja tudo ponderado no juízo final.

RESPOSTA À SEGUNDA. — Deus não julgará duas vezes a mesma causa, istoé, àmesma luz. Mas, a luzes
diversas, nenhum inconveniente há em julgar ele duas vezes.

RESPOSTA À TERCEIRA. — Embora o prêmio ou a pena do corpo dependa do prêmio ou da pena da
alma, contudo, não sendo a alma mutável, em virtude do corpo, senão por acidente, desde que estiver
separada dele ficará num estado imutável e receberá então a sua sentença. Ao contrário, o corpo
permanecerá mutável até ao fim dos tempos. Logo e necessàriamente, no juízo final é que há de
receber o prêmio ou a pena.

## Art. 6 — Se o poder judiciário de Cristo se estende aos anjos.
O sexto discute-se assim. — Parece que o poder judiciário de Cristo não se estende aos anjos.

1. — Pois, os anjos, tanto os bons como os maus, foram julgados desde o princípio do mundo, quando
uns caíram pelo pecado e os outros foram confirmados na beatitude. Ora, os que já foram julgados não
precisam sê-la de novo. Logo, o poder judiciário de Cristo não se estende aos anjos.

2. Demais. — Não pertence à mesma pessoa julgar e ser julgada. Ora, os anjos virão com Cristo para
julgar, segundo o Evangelho: Quando vier o Filho do homem na sua majestade e todos os anjos com ele.
Logo, parece que os anjos não devem ser julgados por Cristo.

3. Demais. — Os anjos são superiores às outras criaturas. Se, pois, Cristo é juiz não só dos homens mas,
também dos anjos, pela mesma razão será juiz de todas as criaturas. O que é falso, porque esse é uma
atribuição própria da providência de Deus, donde o dizer a Escritura: A qual outro estabeleceu sobre a
terra ou a quem pôs sobre o mundo que fabricou? Logo não é Cristo o juiz dos anjos.
Mas, em contrário, o Apóstolo: Não sabeis que havemos de julgar aos anjos? Ora, os santos não julgarão
senão pela autoridade de Cristo. Logo, com maior razão, tem Cristo o poder judiciário sobre os anjos.

SOLUÇÃO. — Os anjos estão sujeitos ao poder judiciário de Cristo, não só pela natureza divina deste,
enquanto Verbo de Deus, mas também em razão da sua natureza humana. O que resulta de três razões.
— Primeiro, da proximidade que tem com Deus a natureza assumida, pois, como diz o Apóstolo, ele em
nenhum lugar tomou aos anjos, mas tomou a descendência de Abraão. Por isso a alma de Cristo, mais
que nenhum dos anjos, está cheia da virtude do Verbo de Deus. Daí vem que ilumina os anjos, como diz
Dionísio e, portanto, pode julgá-los, — Segundo, porque, pela humilhações da Paixão, a natureza
humana mereceu ser exaltado, em Cristo acima dos anjos; de modo que, como diz oApóstolo, ao nome
de Jesus se dobre todo o joelho dos que estão nos céus, na terra e nos infernos. Por isso Cristo exerce o
poder judiciário também sobre todos os anjos, tanto bons como maus. Em prova do que diz a Escritura:
Todos os anjos estavam em pé ao derredor do trono. — Terceiro, em razão do que obram em relação
aos homens, dos quais Cristo é, de certo modo especial, a cabeça. Donde o dizer o Apóstolo: Todos os
espíritos são uns administradores enviados para exercer o seu ministério a favor daqueles que hão de
receber a herança da salvação. Estão sujeitos, pois, ao juízo de Cristo, primeiro quanto à ministração das
obras que devem ser feitas por eles. Ministração essa que também lhes advém do homem Cristo, a
quem os anjos serviam, e a quem os demônios pediam lhes permitissem entrar nos porcos, como refere
o Evangelho. — Segundo, quanto aos demais prêmios acidentais dos bons anjos, que são o alegrarem-se
com a salvação dos homens, segundo aquilo do Evangelho: Haverá júbilo entre os anjos de Deus por um
pecador que faz penitência. E também quanto às penas acidentais do demônio, que os afligem na terra
ou encerrados no inferno. O que também depende do homem Cristo. Por isso o Evangelho conta que o
demônio clamava: Que tens tu conosco, Jesus Nazareno? Vieste a perder-nos antes do tempo? —
Terceiro, quanto ao prêmio essencial dos bons anjos, que é a beatitude eterna; e quanto à pena
essencial dos maus anjos, que é a condenação eterna. O que tudo advém de Cristo enquanto Verbo de
Deus, desde o princípio do mundo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe, quanto ao juízo concernente ao prêmio
essencial e à pena principal.

RESPOSTA À SEGUNDA. — Como diz Agostinho, embora o espiritual julgue de todasas coisas, contudo
pela verdade é ele julgado. Por onde, embora os anjos, por serem espirituais, julguem, são contudo
julgados por Cristo, enquanto é a Verdade.

RESPOSTA À TERCEIRA. — Cristo tem o poder de julgar não só os anjos, mas também as atividades de
todas as criaturas. Se, pois, como ensina Agostinho, os inferiores são, numa certa ordem, governados
por Deus mediante os superiores, é necessário admitirmos que todos os seres são governados pela alma
de Cristo, superior a todas as criaturas. Daí o dizer o Apóstolo: Deus não submeteu aos anjos o mundo
vindouro, isto é, aquele de quem falamos, isto é, a Cristo. Nem, contudo, por causa disso, estabeleceu
Deus outro sobre a terra. Porque Deus tem unidade e identidade de ser com Nosso Senhor Jesus Cristo
homem. De cujo mistério da Encarnação basta o que até aqui dissemos.
Os Sacramentos em geral
Depois de termos tratado do que respeita ao mistério do Verbo Encarnado, devemos estudar os
sacramentos da Igreja, que desse Verbo encarnado tiram a sua eficácia. E o primeiro tratado será o dos
sacramentos em geral. O segundo o de cada sacramento em especial.
No primeiro tratado há cinco questões a serem consideradas. Primeiro, que é o sacramento. Segundo,
da necessidade dos sacramentos. Terceiro, dos efeitos dos sacramentos. Quarto da causa deles. Quinto,
do seu número.