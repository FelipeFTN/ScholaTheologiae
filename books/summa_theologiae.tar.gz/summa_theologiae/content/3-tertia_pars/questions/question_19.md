# Questão 19: Da unidade de operação em Cristo
Em seguida devemos tratar da unidade de operação em Cristo.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se em Cristo é uma só a operação da divindade e da humanidade.
O primeiro discute-se assim. — Parece que em Cristo é só uma a operação da divindade e da
humanidade.

1. — Pois, diz Dionísio: A operação de Deus para conosco foi discernidamente benigníssima, porquanto
o Verbo supersubstancial humanou-se, íntegra e verdadeiramente, assumindo uma natureza
semelhante à nossa, de nós mesmos recebida, e operou e sofreu tudo o que se compadecia com a sua
operação divina e humana. E isso a que aí chama operação humana e divina, em grego se denomina,
isto é, divino humano. Logo, parece que havia em Cristo uma operação composta.

2. Demais. — O agente principal e o instrumento tem uma mesma operação. Ora, a natureza humana
em Cristo era instrumento da divina, como se disse. Logo, em Cristo, as operações divina e humana se
identificam.

3. Demais. — Havendo em Cristo duas naturezas numa só hipóstase ou pessoa, necessariamente é um
mesmo o ser da hipóstase ou da pessoa, pois, só o suposto subsistente é que opera; donde o dizer o
Filósofo, que agir é próprio do indivíduo. Logo, em Cristo é uma mesma a operação da divindade e da
humanidade.

4. Demais. — Assim como o existir é próprio da hipóstase subsistente, assim também o agir. Ora, por
causa da unidade da hipóstase, Cristo tem um só ser, como se disse. Logo, também pela mesma
unidade, há em Cristo unidade de operação.

5. Demais. — A uma obra corresponde uma operação. Ora, uma mesma era a obra da divindade e da
humanidade, como a cura de um leproso ou a ressurreição de um morto. Logo, parece que em Cristo é
uma mesma a operação da divindade e da humanidade.
Mas, em contrário, diz Ambrósio: Como pode uma mesma operação provir de potências diversas? Por
ventura poderá o menor operar como o maior e haverá uma só operação onde há diversidade de
substâncias?

SOLUÇÃO. — Como dissemos, os heréticos, que atribuíram a Cristo uma só vontade, atribuíram-lhe
também uma só operação. E para que melhor compreendamos quão errônea é essa opinião, devemos
considerar que quando há muitos agentes ordenados, o inferior é movido pelo superior; assim, no
homem, o corpo é movido pela alma e as potências inferiores pela razão. Por onde, as ações e os
movimentos do princípio inferior são, antes, efeitos operados, que operações; ao passo que as
operações do princípio supremo são operações propriamente ditas. Assim, se disséssemos, que no
homem o andar dos pés e o apalpar das mãos são operações dele, operando-os a alma — pelos pés, a
primeira, e a segunda, pelas mãos. E sendo a mesma alma que opera, desses dois modos, da parte do
agente, que é o primeiro princípio motor, há uma só e mesma operação; diferem elas porém quanto aos
efeitos operados. Assim, pois, como, no homem, enquanto tal, o corpo é movido pela alma e o apetite
sensitivo, pela razão, assim também, em Nosso Senhor Jesus Cristo, a natureza humana era movida e
governada pela divina. Por isso, os referidos heréticos diziam que as operações são as mesmas, sem
nenhuma diferença, relativamente à divindade que opera, mas são diversas as coisas operadas. E assim,
a divindade de Cristo agia, de um modo, por si mesma, enquanto sustentava todas as coisas com o
poder da palavra; e agia de outro modo, pela sua natureza humana, assim, por exemplo, andava
corporalmente. Por isso, o Sexto Sínodo cita as palavras do herético Severo, que soam: As ações e as
operações mesmas de Cristo muito diferiam entre si. Pois, umas eram próprias de Deus e outras, do
homem. Assim, andar corporalmente sobre a terra por certo o pode o homem; mas, fazer andar os
coxos e os que de nenhum modo são capazes de se mover, é próprio de Deus. Ora, uma e outra cousa o
fez o Verbo encarnado, sem que fossem umas próprias de uma determinada natureza e outras, de
outra, nem por serem diversas as obras diríamos, com acerto, que procedem de duas naturezas.
Mas, assim pensando, enganava-se. Pois, a ação do que é movido por outro é dupla: uma a tem pela sua
forma própria, outra, enquanto recebe de fora o movimento. Assim, a ação do machado; pela forma
própria dele, é cortar; mas, enquanto movido pelo artífice, a sua ação própria é fazer um móvel. Por
onde, a operação própria de um ser é a que ele realiza em virtude da sua forma; nem pertence ao motor
senão na medida em que dele se serve para a sua ação própria. Assim, aquecer é operação própria do
fogo; não porém, do ferreiro, senão na medida em que se serve do fogo para aquecer o ferro. Mas a
operação de um ser, só enquanto movido por outro, não difere da do agente que o move; assim, fazer
um móvel não é operação diferente da do artífice. Por onde, sempre que o motor e o movido tem forma
ou virtudes operativas diversas, então e necessariamente, uma é a operação do motor e outra, a do
movido; embora o movido participe da operação do motor e o motor se sirva da operação do movido, e
assim um obre com a cooperação do outro.
Assim, pois, em Cristo, a natureza humana tem uma forma e virtude próprias, pelas quais obra; e
também a natureza divina. E portanto, a natureza humana tem uma operação própria distinta da
operação divina, e vice-versa. Contudo, a natureza divina se serve da operação da natureza humana,
como sendo a operação do seu instrumento; e semelhantemente, a natureza humana participa da
operação da natureza divina, como o instrumento participa da operação do agente principal. E é o que
diz Leão Papa: Uma e outra forma, isto é, tanto a natureza divina de Cristo como a humana, em
comunhão com a outra, jaz o que lhe é próprio: o Verbo obra o que é próprio do Verbo, e a carne
executa o que lhe pertence executar. Se, porém, a operação, da divindade e da humanidade fosse uma
só em Cristo, deveríamos admitir ou que a natureza humana não tinha forma e virtude próprias, donde
— sendo impossível dizê-lo, da natureza divina — se seguiria que em Cristo só havia a operação divina;
ou que a divina virtude e a humana se fundiram em Cristo numa só virtude. Ora, tudo isso é impossível,
pois, pela primeira hipótese teríamos de admitir a imperfeição da natureza humana de Cristo; e pela
segunda, a confusão das naturezas.
Por isso e com razão o Sexto Sínodo condenando a opinião referida, dispõe: Glorificamos no mesmo
Cristo Senhor nosso e verdadeiro Deus duas operações naturais indivisas, inconvertíveis, inconfusas,
inseparáveis, isto é, uma operação divina e outra humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A operação teândrica isto é, divino humana ou humano
divina, que Dionísio atribui a Cristo, ele não a funda em nenhuma confusão de operações ou de virtudes
de ambas as naturezas; mas porque a divina operação de Cristo se serve da humana e a humana
participa da virtude da divina. E por isso diz numa Epístola: Os seus atos humanos ele os realizava de
modo superior ao humano, como o demonstra a conceição sobrenatural da Virgem e o fato de ter-se
sustentado à tona da água apesar do peso do seu corpo. Ora, é manifesto, que tanto conceber como
andar, a natureza humana o pode; mas, uma e outra coisa Cristo a fez sobrenaturalmente; do mesmo
modo, quando curou o leproso pelo simplesmente tocar, obrava humanamente, enquanto Deus. Por
isso Dionísio acrescenta: Não agia divinamente, como Deus, nem humanamente, como homem; mas
tendo o Deus sido feito homem, obrava, por uma nova operação, obras próprias de Deus e do homem. -
Mas, que entendia serem duas as operações em Cristo — uma da natureza divina e outra, da humana,
resulta claro do passo onde, declara: Do pertinente à sua ação humana nem o Pai nem o Espírito Santo
participam, por nenhuma razão, salvo se disséssemos participarem, por uma benigníssima e
misericordiosa vontade, isto é, enquanto que o Pai e o Espírito Santo quiseram por sua misericórdia, que
Cristo agisse como homem e sofresse. Mas acrescenta: Em todas as sublimíssimas e inefáveis obras
divinas que obrou, feito homem, mostra-se imutavelmente Deus e Verbo de Deus. Por onde é claro que
uma é a sua operação humana, da qual nem o Pai nem o Espírito Santo participam, salvo pela aceitação
da sua misericórdia, e outra a que obra como Verbo de Deus, da qual participam o Pai e o Espírito Santo.

RESPOSTA À SEGUNDA. — Dissemos que um instrumento age quando movido pelo agente principal;
mas, além dessa ação, pode o instrumento ter uma operação própria resultante da sua forma, como
dissemos a respeito do fogo. Assim, pois, a ação do instrumento, como tal, não difere da do agente
principal; mas pode, como um determinado ser que é, ter outra operação. Por onde, a operação da
natureza humana de Cristo, enquanto instrumento da divindade, não difere da operação da divindade;
assim, a salvação obrada pela humanidade não difere da operada pela divindade. Mas, a natureza
humana em Cristo, enquanto uma determinada natureza, tem uma operação própria, além da divina,
como dissemos.

RESPOSTA À TERCEIRA. — Operar é próprio da hipóstase subsistente; mas, segundo a forma e a
natureza da qual a operação recebe a sua espécie. Por onde, da diversidade das formas ou naturezas
resultam espécies diversas de operações, ao passo que da unidade da hipóstase resulta a unidade
numérica da operação especificada. Assim, o fogo tem duas operações especificamente diversas —
iluminar e aquecer — por causa da diferença entre a luz e o calor; contudo, a iluminação é uma
operação única e simultânea produzida pelo fogo. Semelhantemente, pelas suas duas naturezas, hão de
ser por força duas e especificamente diferentes as operações de Cristo; mas, cada uma delas é
numericamente uma e simultaneamente realizada por Cristo; assim um é o seu ato de andar e um, o de
curar.

RESPOSTA À QUARTA. — Existir e operar a pessoa o tem da natureza, mas de modos diferentes. Pois, a
existência pertence à constituição mesma da pessoa; e assim considerada, ela exerce a função de termo;
e por isso a unidade de pessoa supõe a unidade do ser mesmo completo e pessoal. Mas a operação é
um efeito da pessoa, em virtude de uma determinada forma ou natureza. Por isso, a pluralidade de
operações não prejudica a unidade pessoal.

RESPOSTA À QUINTA. — Um é o efeito próprio da operação divina e outro, o da humana, em Cristo.
Assim, efeito próprio da operação divina é a cura do leproso; ao passo que efeito próprio da natureza
humana é o tê-lo tocado. Mas, ambas essas operações concorrem para o mesmo efeito, porque uma
natureza age com a participação da outra, como dissemos.

## Art. 2 — Se em Cristo há várias operações humanas.
O segundo discute-se assim. — Parece que há em Cristo várias operações humanas.

1. — Pois, Cristo, enquanto, homem, participa da natureza vegetativa das plantas e da natureza
sensitiva dos animais; e, pela sua natureza intelectual, é como os outros homens, semelhante aos anjos.
Ora, uma é a atividade da planta, como planta e outra, a do animal, como animal. Logo, Cristo, enquanto
homem, tem várias operações.

2. Demais. — As potências e os hábitos distinguem-se pelos seus atos. Ora, a alma de Cristo tinha
diversas potências e diversos hábitos. Logo, também diversas operações.

3. Demais. — Os instrumentos devem ser proporcionados às operações. Ora, o corpo humano tem
diversos membros de formas diferentes e portanto acomodados a operações diferentes. Logo, a
natureza humana de Cristo tem diversas operações.
Mas, em contrário diz Damasceno: a operação resulta da natureza. Ora em Cristo há uma só natureza
humana. Logo, em Cristo havia uma só operação humana.

SOLUÇÃO. — Sendo o homem o que é pela sua razão, chama-se operação humana, em sentido
absoluto, a procedente da razão por meio da vontade, que é o apetite racional. Se houver porém no
homem alguma operação não procedente da razão e da vontade, essa não será humana em sentido
absoluto, mas convém ao homem por uma parte da natureza humana. E, ora, pela natureza mesma do
elemento corpóreo, como ser levado para baixo; ora, pela virtude da alma vegetativa, como nutrir-se e
crescer; ora, pela parte sensitiva, como ver e ouvir, imaginar e lembrar-se, desejar e encolerizar-se. E
entre essas operações há diferenças. Pois, as operações da alma sensitiva são de certo modo obedientes
à razão; e portanto são de certo modo racionais e humanas, isto é, enquanto obedientes à razão, como
está claro no Filósofo. Quanto às operações resultantes da alma vegetativa, ou ainda da natureza
elementar do corpo, essas não estão sujeitas à razão e portanto de nenhum modo são racionais nem
humanas em sentido absoluto, mas só por uma parte da natureza humana.
Pois, como dissemos, quando o agente inferior age pela sua forma própria então a sua ação difere da do
agente superior; mas quando o agente inferior não age senão enquanto movido pelo superior então
ambos os agentes tem a mesma operação. Assim, pois, em qualquer homem puramente homem, uma é
a operação do corpo elementar e da alma vegetativa e outra, a da vontade, que é propriamente
humana; também e semelhantemente, uma é a operação da alma sensitiva, enquanto não movida pela
razão e outra enquanto movida por ela, pois então, é a mesma que a da parte racional. Quanto à alma
racional, ela só tem uma operação, se lhe atendermos ao princípio da operação, que é a razão ou a
vontade; mas ela se diversifica pelos seus objetos diversos. E essa diversidade uns a chamaram
diversidade, antes, de efeitos operados, que de operações, julgando a unidade de operação só
relativamente ao princípio operativo. E é neste sentido que agora indagamos da unidade ou da
pluralidade das operações de Cristo.
Portanto, no homem puro e simples, há só uma operação, chamada propriamente humana; além da
qual, porém, há nele certas outras operações, não propriamente humanas, como dissemos. Mas no
homem Jesus Cristo nenhum movimento havia da parte sensitiva que não fosse ordenado pela razão.
Mesmo as operações naturais e corpóreas de certo modo lhe pertenciam à vontade, por querer a sua
vontade que a sua carne agisse e sofresse como lhe é próprio, segundo dissemos. E, pois, muito mais é
una a operação de Cristo, que em qualquer outro homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A operação da parte sensitiva e também da nutritiva não
é propriamente humana, como se disse. E contudo, em Cristo essas operações eram mais humanas, que
nos outros.

RESPOSTA À SEGUNDA. — As potências e os hábitos se diversificam por comparação com os seus
objetos. Por onde, a diversidade de operações responde à diversidade de potências e de hábitos, do
mesmo modo pelo qual responde a objetos diversos. Ora, tal diversidade de operações não
pretendemos excluir da humanidade de Cristo; assim como a determinada pela diversidade de
instrumentos; mas só a procedente de um primeiro princípio ativo, como se disse.
Donde se deduz clara a RESPOSTA À TERCEIRA OBJEÇÃO.

## Art. 3 — Se a ação humana de Cristo podia ser meritória.
O terceiro discute-se assim. — Parece que a ação humana de Cristo não podia ser meritória.

1. — Pois, Cristo, antes da sua morte, já gozava da visão beatífica tal como agora a goza. Ora, quem goza
da visão beatifica não pode merecer. Pois, a sua caridade é o prêmio da bem-aventurança, porquanto
nesta se funda o gozo da visão; portanto, não pode ser princípio de merecimento, porque o mérito não
se confunde com o prêmio. Logo, Cristo, antes da paixão não merecia, como atualmente não merece.

2. Demais. — Não merecemos o que nos é devido. Ora, por natureza Filho de Deus, Cristo tem direito à
herança eterna que os outros homens merecem pelas suas boas obras. Logo, Cristo, que desde o
princípio foi Filho de Deus, nada podia merecer para si.

3. Demais. — Se temos um bem principal, não merecemos propriamente o que desse bem resulta. Ora,
Cristo tinha a glória da alma, da qual ordinariamente resulta a glória do corpo, como diz Agostinho; em
Cristo, porém, por exceção, a glória da alma não derivava para o corpo. Logo, Cristo não mereceu a
glória do corpo.

4. Demais. — A manifestação da excelência de Cristo não é um bem de Cristo mesmo, mas, dos que o
conhecem. Pois, como prêmio aos seus amantes Cristo promete que há de se lhes manifestar, como
está no Evangelho: Aquele que me ama será amado de meu Pai e eu o amarei também e me
manifestarei a ele. Logo, Cristo não mereceu a manifestação da sua grandeza.
Mas, em contrário, o Apóstolo diz: Feito obediente até a morte; pelo que Deus também o exaltou. Logo,
obedecendo mereceu a sua exaltação e, portanto, algo para si mereceu.

SOLUÇÃO. — Ter um bem, por si mesmo, é mais nobre que tê-lo por outrem; pois, como diz Aristóteles,
a coisa que por si. mesma o é, é mais nobre que a que o é mediante outro. Ora, dizemos que tem uma
causa por si mesmo quem de certo modo é causa dela, para si mesmo. Ora, a causa primeira de todos os
nossos bens como autor deles, é Deus. E, assim, nenhuma criatura tem qualquer bem por si mesma,
segundo aquilo da Escritura: Que tens tu que não recebesses? Mas, podemos, de modo secundário, ser
a causa de um bem que tenhamos, como um resultado da nossa colaboração com Deus; e então, o que
temos pelo nosso próprio mérito nós o temos de certo modo por nós mesmo. Por onde, o que temos
por mérito o temos mais nobremente que o que temos sem mérito.
Ora, toda perfeição e toda nobreza devemos atribuí-las a Cristo. Logo e consequentemente, também ele
terá por mérito o que os outros por mérito o tem; salvo se se tratar daquilo cuja carência mais
prejudique à dignidade e à perfeição de Cristo do que a aumente, pelo mérito. Por isso, Cristo não
mereceu a graça, nem a ciência, nem a beatitude da alma, nem a divindade; pois, como não merecemos
senão o que não temos, havia Cristo, algum tempo, de ter carecido desses bens; ora, carecer deles mais
diminui a dignidade de Cristo, do que a aumenta o merecê-las. A glória do corpo porém, ou de um bem
semelhante, é menor que a dignidade de merecer, que pertence à virtude da caridade. Donde devemos
concluir, que Cristo teve por mérito a glória do corpo e o que implica uma excelência exterior sua, como
a ascensão, a veneração e bens tais. Por onde é claro que podia merecer para si.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O gozo, que é um ato de caridade, pertence à glória da
alma, que Cristo não mereceu. Por onde, de ter merecido pela caridade, não se segue a confusão do
mérito e do prêmio. Mas não mereceu pela caridade, enquanto era a sua caridade a de quem frui da
visão beatífica, mas a do viandante. Pois, ao mesmo tempo foi viandante e vidente, como
demonstramos. Logo, como já agora não é viandante, não está em estado de merecer.

RESPOSTA À SEGUNDA. — A Cristo, enquanto Filho de Deus e Deus por natureza é lhe devida a glória
divina e o domínio sobre todas as coisas, como ao primeiro e supremo Senhor. Nem por isso, contudo,
deixa de lhe ser devida a glória, como a quem é bem-aventurado; e essa, de certo modo, devia tê-la sem
mérito; e de certo outro, com mérito, como do sobredito se colige.

RESPOSTA À TERCEIRA. — O redundar da glória, do alma para o corpo, resulta da ordenação divina, de
conformidade com os méritos humanos. Assim, como merecemos pelo ato, que a alma exerce sobre o
corpo, assim, também somos remunerados pela glória, redundante, da alma, para o corpo. E por isso,
não somente a glória da alma, mas também a do corpo é susceptível de mérito, segundo aquilo do
Apóstolo: Dará vida aos vossos corpos mortais, pelo seu Espírito, que habita em vós. E assim podia ser
merecida por Cristo.

RESPOSTA À QUARTA. — A manifestação da excelência de Cristo inclui-se-lhe no bem, que lhe resulta
do conhecimento dos outros, embora mais principalmente pertença ao bem dos que o conhecem, pelo
ser que em si mesmos tem. Mas isso mesmo se refere a Cristo, enquanto membros dele.

## Art. 4 — Se Cristo podia merecer para os outros.
O quarto procede-se assim. — Parece que Cristo não podia merecer para os outros.
1 — Pois, diz a Escritura: A alma que pecar essa morrerá. Logo, e pela mesma razão, a alma que merecer
será remunerada. Logo, não é possível tivesse Cristo merecido pelos outros.

2. Demais. — Todos nós participamos da plenitude da graça de Cristo, diz o Evangelho. Ora, os outros
homens, tendo a graça de Cristo, não podem merecer pelos outros, segundo aquilo da Escritura: Se Noé,
Daniel e Jó se acharem na cidade não livrarão nem a seus filhos nem a suas filhas, mas eles livrarão as
suas almas pela sua própria justiça. Logo, também Cristo não podia merecer nada por nós.

3. Demais. — A recompensa que merecemos nos é devida por justiça e não por graça, como o diz o
Apóstolo. Se, pois, Cristo mereceu a nossa salvação, segue-se que a nossa salvação não provém da graça
de Deus, mas da sua justiça; e que procede injustamente com os que não salva, pois que o mérito de
Cristo se estende a todos.
Mas, em contrario, o Apóstolo: Assim como pelo pecado de um só incorreram todos os homens na
condenação, assim também pela justiça de um só recebem todos os homens a justificação da vida. Ora,
o demérito de Adão redundou em condenação dos outros. Logo, com maior razão, o mérito de Cristo
deriva para os demais.

SOLUÇÃO. — Como dissemos, Cristo teve a graça, não só como um homem particular, mas como cabeça
de toda a Igreja, a que todos estão unidos como os membros à cabeça, com o que se constitui
misticamente uma pessoa. Donde vem, que o mérito de Cristo se estende aos demais, como membros
seus; assim corno num homem a ação da cabeça de certo modo pertencente a todos os membros, pois,
não sente só para si, mas por todos eles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pecado de uma pessoa particular não é nocivo senão a
si mesma; mas o pecado de Adão, constituído por Deus princípio de toda a natureza, se transmitiu aos
outros pela propagação da carne. E semelhantemente, o mérito de Cristo, constituído por Deus, cabeça
de todos os homens, quanto à graça, estende-se a todos os seus membros.

RESPOSTA À SEGUNDA. — Os outros recebem da plenitude de Cristo, não certo a fonte da graça, mas
uma certa graça particular. Por onde, não é necessário que os outros homens possam merecer para os
demais, como Cristo.

RESPOSTA À TERCEIRA. — Assim como o pecado de Adão não se transmite aos outros senão pela
geração carnal, assim também aos outros não se transmite o mérito de Cristo senão pela regeneração
espiritual, operada pelo batismo, pelo qual nos incorporamos em Cristo, segundo aquilo do Apóstolo:
Todos os que fostes batizados em Cristo revestiste-vos de Cristo. E isto mesmo é uma graça, o ser
concedido ao homem regenerar-se em Cristo. E assim, a salvação do homem provém da graça.