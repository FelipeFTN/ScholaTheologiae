# Questão 49: Dos efeitos da paixão de Cristo
Em seguida devemos tratar dos efeitos da Paixão de Cristo. E nesta questão discutem-se seis artigos:

## Art. 1 — Se pela Paixão de Cristo somos liberados do pecado.
O primeiro discute-se assim. — Parece que pela Paixão de Cristo não somos liberados do pecado.

1. — Pois, liberar do pecado é próprio de Deus, segundo a Escritura: Eu sou, eu mesmo o que apago as
tuas iniqüidades por amor de mim. Ora, Cristo não sofreu enquanto Deus, mas enquanto homem. Logo,
a Paixão de Cristo não nos liberta do pecado.

2. Demais. — O corporal não age sobre o espiritual. Ora, a Paixão de Cristo foi corporal; ao passo que o
pecado existe na alma, criatura espiritual. Logo, a Paixão de Cristo não podia purificar do pecado.

3. Demais. — Ninguém pode ser liberado de pecado que ainda não cometem, mas do que no futuro
cometerá. Ora, como muitos pecados foram cometidos e todos os dias o são, posteriores à Paixão de
Cristo, parece que pela sua Paixão não fomos liberados do pecado.

4. Demais. — Posta a causa suficiente, nada mais énecessário para a produção do efeito. Ora, além da
Paixão de Cristo se requerem outras causas como o batismo e a penitência, para a remissão dos
pecados. Logo, parece que a Paixão de Cristo não foi causa suficiente da remissão dos pecados.

5. Demais. — A Escritura diz: A caridade cobre todos os delitos. E nou'tro lugar. Os pecados purificam-se
pela misericórdia e pela fé. Ora, há muitos outros objetos de fé e motivos da caridade, além da Paixão
de Cristo. Logo, a Paixão de Cristo não é a causa própria da remissão
dos pecados.
Mas, em contrário, a Escritura: Amou-nos e nos lavou dos pecados no seu sangue.

SOLUÇÃO. — A Paixão de Cristo é a causa própria da remissão dos pecados, por três razões. — Primeiro,
como causa excitante à caridade. Pois, no dizer do Apóstolo, Deus faz brilhar asua caridade em nós,
porque ainda quando éramos pecadores, em seu tempo morreu Cristo por nós. Ora, pela caridade
conseguimos o perdão dos pecados, conforme o Evangelho: Perdoados lhe são seus muitos pecados,
porque amou muito. — Segundo, a Paixão de Cristo causa a remissão dos pecados a modo de redenção.
Pois, sendo Cristo a nossa cabeça, pela Paixão que sofreu por obediência e caridade, liberou-nos, como
o seus membros, do pecado, quase pelo preço da sua Paixão; como no caso de alguém que, por uma
obra meritória manual, se resgatasse do pecado que com os pés tivesse cometido. Assim como, pois, o
corpo natural é uno, na diversidade dos seus membros, assim a Igreja na sua totalidade, que é o corpo
místico de Cristo, é considerada quase uma mesma pessoa com a sua beça que é Cristo. — Terceiro, o
modo de eficiência, enquanto a carne, na qual Cristo sofreu àsua Paixão, é o instrumento da divindade;
pelo qual os padecimentos e as ações de Cristo agem com virtude divina, com o fim de deliro pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora Cristo, como Deus, não sofresse, contudo a sua
carne foi o instrumento da divindade. Donde houve a sua Paixão, uma certa virtude divina de perdoar os
pecados, como se disse.

RESPOSTA À SEGUNDA. — A Paixão de Cristo, embora corpórea, produz contudo uma certa virtude
espiritual por causa da divindade à qual a sua carne estava unida, como instrumento. E por força dessa
virtude a Paixão de Cristo é a causa da remissão dos pecados.

RESPOSTA À TERCEIRA. — Cristo pela sua Paixão nos livrou dos pecados, causalmente, istoé, por ter
instituído a causa da nossa liberação, em virtude da qual pudesse perdoar num momento dado
quaisquer pecados - passados, presentes ou futuros. Tal o médico que preparasse um remédio capaz de
curar quaisquer doenças, mesmo futuras.

RESPOSTA À QUARTA. — A Paixão de Cristo é, como dissemos, a causa universal antecedente da
remissão dos pecados. Mas é necessário aplicá-la a cada um a fim de delir os pecados próprios. O que se
dá pelo batismo, pela penitência e pelos outros sacramentos, que tiram a sua virtude da Paixão de
Cristo, como a seguir se dirá.

RESPOSTA À QUINTA. — Também pela fé nos é aplicada a Paixão de Cristo, a fim de lhe colhermos os
frutos, segundo aquilodo Apostolo: Ao qual propôs Deus para ser; vitima de propiciação pela fé no seu
sangue. Mas a fé, pela qual nos purificamos do pecado, não é uma fé informe, que pode coexistir com o
pecado, mas a fé informada pela caridade. De modo que uma Paixão de Cristo nos é aplicada, não só
quanto ao intelecto, mas também quanto ao afeto. E também deste modo os pecados são perdoados
por virtude da Paixão de Cristo.

## Art. 2 — Se pela Paixão de Cristo fomos livrados do poder do diabo.
O segundo discute-se assim. — Parece que pela Paixão de Cristo não fomos livrados do poder do
diabo.

1. — Pois, não temos poder sobre outrem se não o podemos exercer sem a permissão alheia. Ora o
diabo nunca pode fazer nenhum mal ao homem senão por permissão divina; Tal o caso de Jó a quem
lesou, por ter recebido de Deus esse poder, primeiro nos seus bens e depois no corpo.
Semelhantemente, como lemos no Evangelho, os demônios não puderam entrar nos porcos senão com
a permissão de Cristo. Logo, o diabo não teve nunca poder sobre os homens. E portanto não fomos
livrados do poder do diabo, pela Paixão de Cristo.

2. Demais — O diabo exerce o seu poder sobre os homens tentando-os e vexando-os corporalmente.
Ora isso eles ainda o fazem, depois da Paixão de Cristo. Logo, pela Paixão de Cristo não fomos livrados
do poder do diabo.

3. Demais. — A virtude da Paixão de Cristo dura perpetuamente, segundo aquilo do Apóstolo: Com uma
só oferenda fez perfeitos para sempre os que tem santificados. E também ela se estendem a todos os
lugares. Ora, a liberação do poder do diabo nem se estende a todos os lugares porque em muitas partes
do mundo ainda há idólatras; nem perdurará sempre, porque no tempo do Anticristo é que o diabo
sobretudo exercerá o seu poder em detrimento dos homens. Ao que se referem as palavras do
Apóstolo, A vinda ao qual é segundo a obra de Satanás em todo o poder e em sinais e em prodígios
mentirosos e em toda a sedução da iniquidade. Logo, parece que a Paixão de Cristo não é causa da
liberação do gênero humano, do poder do diabo.
Mas, em contrário, o Senhor disse, na iminência da Paixão: Agora será lançado fora o príncipe deste
mundo, e eu, quando for levantado da. Terra, todas as coisas atrairei a mim mesmo. Ora, foi levantado
da terra pela Paixão da cruz. Logo, por ela o diabo foi privado do seu poder sobre os homens.

SOLUÇÃO. — Sobre o poder que o diabo exercia sobre os homens, antes da Paixão de Cristo, devemos
fazer tríplice consideração. — A primeira relativa ao homem, que pelo seu pecado mereceu ser entregue
ao poder do diabo, por cuja tentação fora vencido. — A outra relativa a Deus; a quem o homem
ofendera pecando, e que na sua justiça abandonou o homem ao poder do diabo. — A terceira é relativa
ao diabo, que com a sua vontade perversíssima impedia o homem de alcançar a sua salvação. Assim,
pois, no tocante àprimeira consideração, o homem foi liberado do poder do diabo pela Paixão de Cristo,
porque a Paixão de Cristo é a causa da remissão dos pecados; como dissemos. — Quanto à segunda, a
Paixão de Cristo nos livrou do poder do diabo, por nos ter reconciliado com Deus, como depois diremos.
— No tocante à terceira, a Paixão de Cristo nos liberou do diabo; porque nela o diabo ultrapassou a
medida do poder que Deus lhe conferira, maquinando a morte de Cristo, que não merecera morrer por
não ter nenhum pecado. Donde o dizer Agostinho: Peça justiça de Cristo foi vencido o diabo, porque
apesar de nada ter encontrado nele digno de morte, contudo o matou. E, portanto era justo que os
devedores que detinha em seu poder fossem mandados livres, crentes em Cristo, que o diabo matou,
apesar de não ter nenhum débito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não se diz que o diabo tivesse poder tal sobre os
homens que lhes pudesse fazer mal, sem a permissão de Deus: mas, que justamente lhe era permitido
fazer mal aos homens, os quais, tentando-os, levou a consentir nos seus desígnios.

RESPOSTA À SEGUNDA. — O diabo, ainda agora pode, com a permissão de Deus, tentar os homens na
alma e vexar-lhas o corpo; contudo, foi-lhe preparado ao homem o remédio da Paixão de Cristo, com o
qual pode defender-se contra os ataques do inimigo, a fim de não ser arrastado àperdição da morte
eterna. E todos os que, antes da Paixão, resistiam ao diabo, assim o puderam fazer pela fé na Paixão de
Cristo. Embora, não estando essa Paixão ainda consumada, de certo modo ninguém pudesse escapar às
mãos do diabo, livrando-se assim de descer ao inferno; ao passo que depois da Paixão de Cristo todos
podemos nos defender contra o poder diabólico.

RESPOSTA À TERCEIRA. — Deus permite ao diabo enganar certas pessoas, em certos tempos e lugares,
por uma razão oculta dos seus juízos. Mas sempre, pela Paixão de Cristo está preparado aos homens o
remédio para se defenderem das perversidades dos demônios, mesmo no tempo do Anticristo. E o fato
de certos descuidarem de servir-se desse remédio em nada faz diminuir a eficácia da Paixão de Cristo.

## Art. 3 — Se pela Paixão de Cristo os homens foram liberados da pena do pecado.
O terceiro discute-se assim. — Pela Paixão de Cristo os homens não foram liberados da pena do
pecado:

1. — Pois, a pena principal do pecado éa condenação eterna. Ora, os condenados ao inferno pelos seus
pecados não foram liberados pela Paixão de Cristo, porque para o inferno não há nenhuma redenção.
Logo, parece que a Paixão de Cristo não liberou os homens da pena.

2. Demais. — Aos livres do reato da pena não se lhes deve acrescentar nenhuma pena. Ora, aos
penitentes se lhes acrescenta a pena satisfatória. Logo, pela Paixão de Cristo os homens não foram
livrados do reato da pena.

3. Demais. — A morte é a pena do pecado, segundo aquilo do Apóstolo: O estipêndio do pecado é a
morte. Ora, mesmo depois da Paixão de Cristo os homens morrem. Logo, pela Paixão de Cristo não
fomos liberados do reato da pena.
Mas, em contrário, a Escritura: Ele foi o que tomou sobre sias nossas fraquezas e ele mesmo carregou
com as nossas dores.

SOLUÇÃO. — Pela Paixão de Cristo fomos liberados do reato da pena, de dois modos. - Primeiro
diretamente; isto é, porque a Paixão de Cristo foi uma satisfação suficiente e superabundante pelos
pecados de todo o gênero humano; ora, dada a satisfação suficiente, eliminado fica o reato da pena. -
De outro modo, indiretamente, isto é, enquanto a Paixão de Cristo é a causa da remissão do pecado, no
qual se funda o reato da pena.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Paixão de Cristo produz o seu efeito naqueles a quem
se aplica pela fé, pela caridade e pelos sacramentos da fé. Por isso, os condenados ao inferno, que não
estão unidos à Paixão de Cristo ao modo por que acabamos de referir, não lhe podem colher o efeito.

RESPOSTA À SEGUNDA. — Como dissemos, para conseguirmos o efeito da Paixão de Cristo, é necessária
com ela nos assemelhemos. Ora, com ela nos assemelhamos no batismo, sacramentalmente, segundo
aquilo do Apóstolo: Fomos sepultados com ele para morrer ao pecado pelo batismo. Por isso aos
batizados não se lhes impõe nenhuma pena satisfatória, por estarem totalmente liberados pela
satisfação de Cristo. Mas porque Cristo uma só vez morreu pelos nossos pecados, no dizer da Escritura,
por isso não pode o homem uma segunda vez se assemelhar com a morte de Cristo pelo sacramento do
batismo. E por isso, os que depois do batismo pecam hão de assemelhar-se com Cristo, padecente por
alguma penalidade ou sofrimento, que suportem na sua pessoa. Mas essa penalidade basta, apesar de
muito menor que a merecida pelo pecado, por causa da cooperação da satisfação de Cristo.

RESPOSTA À TERCEIRA. — A satisfação de Cristo produz efeito em nós, se nos incorporarmos com ele
como os membros com a cabeça, conforme dissemos. Ora, os membros hão de conformar-se com a
cabeça, Por onde, assim como Cristo teve primeiro a graça na alma com a passibilidade do corpo, e
chegou pela Paixão àglória da imortalidade, assim também nós, que somos os seus membros, somos
pela sua Paixão liberados do reato de qualquer pena. Mas para isso devemos primeiro receber na alma
o Espírito da adoção de filhos pelo qual adimos a herança da glória da imortalidade, enquanto ainda
temos um corpo passível e mortal. Mas depois assemelhados aos sofrimentos e à morte de Cristo,
chegaremos à glória imortal segundo aquilo do Apóstolo: Se somos filhos somos também herdeiros;
herdeiros verdadeiramente de Deus e co-herdeiros de Cristo, se é que, todavia nós padecemos com ele
para que sejamos também com ele glorificados.

## Art. 4 — Se pela Paixão de Cristo fomos reconciliados com Deus.
O quarto discute-se assim. — Parece que pela Paixão de Cristo não fomos reconciliados com Deus.

1. — Pois, a reconciliação não tem lugar entre amigos. Ora, Deus sempre nos amou, como o diz a
Escritura: Tu amas todas as causas que existem e não aborreces nada de quanto fizeste. Logo, a Paixão
de Cristo não nos reconciliou com Deus.

2. Demais. — Não pode o princípio também ser efeito; e por isso a graça, que é o princípio do mérito,
não é susceptível de mérito. Ora, o amor de Deus foi o princípio da Paixão de Cristo, segundo o
Evangelho: Assim amou Deus ao mundo que lhe deu a seu Filho unigênito. Logo parece que pela Paixão
de Cristo não fomos reconciliados com Deus, de modo que ele então começasse a nos amar de novo.

3. Demais. — A Paixão de Cristo se cumpriu mediante os que o mataram, que assim gravemente
ofenderam a Deus. Logo, a Paixão de Cristo é antes a causa da Indignação de Deus que a da
reconciliação com ele.
Mas, em contrário, diz o Apóstolo: Fomos reconciliados com Deus pela morte deseu Filho.

SOLUÇÃO. — A Paixão de Cristo é a causa da nossa reconciliação com Deus, de dois modos. — Primeiro,
porque remove o pecado pelo quais os homens são constituídos inimigos de Deus, segundo aquilo da
Escritura: Deus igualmente aborreceu ao ímpio e a sua impiedade. E noutro lugar: Aborreces a todos os
que obram a iniquidade. - De outro modo, como sacrifício muito aceito de Deus. Pois, o efeito próprio
do sacrifício é aplacar a Deus; assim como perdoamos a ofensa cometida contra nós quando recebemos
um serviço que nos é prestado. Donde o dizer a Escritura: Se o Senhor te incita contra mim, receba ele o
cheiro do sacrifício. Semelhantemente, o ter Cristo sofrido voluntariamente foi um bem tão grande, que
em razão desse bem descoberto em a natureza humana, Deus se aplacou no tocante a qualquer ofensa
do gênero humano, contanto que o homem se una com a Paixão de Cristo, do modo referido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus ama em todos os homens a natureza que ele
mesmo fez. Odeia-os, porém por causa da culpa que contra ele cometeram, segundo a Escritura:
Aborrece o Altíssimo aos pecadores.

RESPOSTA À SEGUNDA. — Não se diz que a Paixão de Cristo nos reconciliou com Deus porque de novo
nos começasse a amar, pois está na Escritura: Com amor eterno te amei. Mas porque a Paixão de Cristo
eliminou a causa do ódio, quer por ter delido o pecado, quer pela compensação de um bem mais
aceitável.

RESPOSTA À TERCEIRA. — Assim como os imoladores de Cristo foram homens, assim também Cristo, o
morto, era homem. Mas foi maior a caridade de Cristo padecente que a iniquidade dos que o mataram.
Por isso a Paixão de Cristo foi mais valiosa para reconciliar Deus com todo o gênero humano do que para
lhe provocar as iras.

## Art. 5 — Se Cristo com a sua Paixão nos abriu as portas do céu.
O quinto discute-se assim. — Parece que Cristo com a sua Paixão não nos abriu as portas do céu.

1. — Pois, diz a Escritura: Para o que semeia justiça há fiel recompensa. Ora, a recompensa da justiça é a
entrada do reino celeste. Logo, parece que os Santos Patriarcas, que praticaram obras de justiça, teriam
obtido pela fé a entrada no reino celeste, mesmo sem a Paixão de Cristo. Logo, a Paixão de Cristo não foi
a causa de abertura das portas do reino celeste.

2. Demais. — Antes da Paixão de Cristo Elias foi arrebatado ao céu, como se lê na Escritura. Ora, o efeito
não é anterior àcausa. Logo, parece que a abertura das portas do céu não foi efeito da Paixão de Cristo.

3. Demais. — Como se lê no Evangelho no batismo de Cristo abriram-se os céus. Ora, o batismo foi
anterior àPaixão. Logo, a abertura do céu não foi efeito da Paixão de Cristo.

4. Demais. — A Escritura diz: Aquele que lhes há de abrir o caminho irá adiante deles. Ora, parece que
abrir o caminho do céu outra coisa não é senão abrir-lhe as portas. Logo, parece que as portas do céu
nos foram abertas, não pela Paixão, mas pela ascensão de Cristo.
Mas, em contrário, diz o Apóstolo: Temos confiança de entrar no santuário, isto é, celeste, pelo sangue
de Cristo.

SOLUÇÃO. — Portas fechadas são um obstáculo a nos impedirem a entrada. Ora, os homens estavam
impedidos de entrar no reino celeste por causa do pecado; pois, como diz a Escritura, haverá um
caminho que se chamará o caminho santo e não passará por ele o impuro. Ora, há duas espécies de
pecado que impedem a entrada no reino celeste. — Um é comum a roda a natureza humana, e esse é o
pecado dos nossos primeiros pais, o qual fechou ao homem a entrada do reino celeste. Por isso, como
lemos na Escritura, depois do pecado do primeiro homem, pôs Deus um querubim com uma espada de
fogo e versátil para guardar o caminho da árvore da vida. — Outro é o pecado especial de cada pessoa,
cometido por ato próprio de cada um.
Ora, pela Paixão de Cristo fomos liberados, não só do pecado comum de roda a natureza humana, tanto
quanto àculpa como quanto ao reato da pena, porque Cristo pagou o preço por nós, mas também dos
pecados próprios de cada um de nós, que comungamos com a sua Paixão pela fé, pela caridade e pelos
sacramentos da fé. E assim pela Paixão de Cristo se nos abriram as portas do reino celeste. E tal é o que
diz o Apóstolo: Estando Cristo já presente, pontífice dos bens vindouros, pelo seu próprio sangue entrou
uma só vez no santuário, havendo achado uma redenção eterna. O mesmo significa a Escritura onde diz
que o homicida ali ficará, isto é na cidade a que se tinha refugiado, até à morte do sumo sacerdote, que
foi sagrado com o óleo santo; e morto este poderia voltar aquele para a sua casa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os santos Patriarcas, tendo praticado obras justas,
mereceram a entrada no reino do céu pela fé na Paixão de Cristo, segundo aquilo do Apóstolo: Os
Santos pela fé conquistaram reinos, obraram ações de justiça; pela qual também cada um se purificava
do pecado, o quanto condizia com a purificação da pessoa própria. Mas a fé ou a justiça de cada um não
bastava a remover o impedimento proveniente do reato de toda a natureza humana. Mas esse
impedimento foi removido pelo preço do sangue de Cristo. Por onde, antes da Paixão de Cristo,
ninguém podia entrar no reino celeste, isto é, alcançando a beatitude eterna, consistente no gozo pleno
de Deus.

RESPOSTA À SEGUNDA. — Elias foi arrebatado ao céu aéreo não ao céu empíreo, que é o lugar dos
santos. O mesmo se deu com Enoch; mas foi arrebatado ao paraíso terrestre, onde cremos que vive
junto com Elias até o advento do Anticristo.

RESPOSTA À TERCEIRA. — Como dissemos os céus se abriram por ocasião do batismo de Cristo, não em
benefício de Cristo mesmo, a quem sempre o céu estava patente; mas para significar que o céu se abre
aos batizados, pelo batismo de Cristo, que tira a sua eficácia da Paixão do mesmo.

RESPOSTA À QUARTA. — Cristo pela sua Paixão mereceu-nos a entrada no reino celeste e removeu o
obstáculo que nô-lo impedia. Mas, pela sua ascensão, como que nos introduzia na posse do reino
celeste. Por isso a Escritura diz que aquele que lhes há de abrir o caminho irá adiante deles.

## Art. 6 — Se Cristo pela sua Paixão mereceu ser exaltado.
O sexto discute-se assim. — Parece que Cristo não mereceu ser exaltado pela sua Paixão.

1. — Pois, assim como o conhecimento da verdade é próprio de Deus, assim também a exaltação
gloriosa, segundo aquilo da Escritura: Excelso é o Senhor sobre todas as gentes e a sua glória é sobre os
céus. Ora, Cristo, enquanto homem tinha conhecimento de toda a verdade, não em virtude de nenhum
mérito precedente, mas pela união mesma de Deus com o homem, segundo aquilo do Evangelho: Nós
vimos a sua glória, a sua glória como de Filho unigênito do Pai, cheio de graça e de verdade. Logo, não
mereceu a sua exaltação pela Paixão, mas só pela união.

2. Demais. — Cristo mereceu para si desde o primeiro instante da sua concepção, como se estabeleceu.
Ora, a sua caridade no tempo da Paixão não foi maior que antes. Por onde, sendo a caridade o princípio
do mérito, parece que não mereceu mais pela Paixão a sua exaltação, que
antes.

3. Demais. — A glória do corpo resulta da glória da alma, como diz Agostinho. Ora, pela sua Paixão, não
mereceu Cristo ser exaltado, quanto àglória da alma; pois, a sua alma foi bem-aventurada desde o
primeiro instante da sua concepção. Logo, nem pela Paixão mereceu a exaltação quanto à glória do
corpo.
Mas, em contrário, o Apóstolo: Feito obediente até à morte e morte da cruz; pelo que Deus o exaltou.

SOLUÇÃO. — O mérito implica uma certa igualdade com a justiça; donde o dizer o Apóstolo, ao que
obra o jornal se lhe conta por dívida. Mas, quem, por injusta vontade, se atribui mais do que lhe é
devido, é justo que se lhe diminua mesmo naquilo que lhe era devido; assim, como diz a Escritura, se
alguém furtar uma ovelha restituirá quatro. E dizemos que assim mereceu por lhe ter sido desse modo
punida a vontade iníqua. Do mesmo modo, quem se privou, por uma justa vontade, do que devia
possuir, merece que se lhe acrescente mais do que tinha, como recompensa da sua vontade justa.
Donde o dizer o Evangelho que quem se humilha será exaltado. Ora, Cristo, na sua Paixão, humilhou-se
a si mesmo, descendo abaixo da sua dignidade, de quatro maneiras. — Primeiro, pela sua Paixão e
morte, de que não era réu. — Segundo, quanto ao lugar, pois o seu corpo foi posto no sepulcro e a
alma, no inferno. — Terceiro, quanto àconfusão e aos opróbrios que sofreu. — Quarto, por ter sido
entregue ao poder humano, conforme ele mesmo o disse a Pilatos: Tu não terias sobre mim poder
algum se ele não te fora dado de cima. E assim, pela sua Paixão mereceu de quatro modos ser exaltado.
— Primeiro, pela ressurreição gloriosa. Por isso diz a Escritura: Tu me conheceste ao assentar-me, isto é,
a humildade da minha Paixão, e ao levantar-me — Segundo, pela ascensão do céu. Donde o dizer o
Apóstolo: Antes havia descido aos lugares mais baixos da terra; aquele que desceu esse mesmo é
também o que subiu acima de todos os céus. — Terceiro, por se ter sentado à dextra paterna e pela
manifestação da sua divindade, segundo aquilo da Escritura: Ele será exaltado e elevado e ficará em alto
grau sublimado; assim como pasmaram muitos à vista de ti, assim será sem glória o seu aspecto entre os
varões. E o Apóstolo. Feito obediente até à morte da cruz; pelo que Deus também o exaltou e lhe deu
um nome que é sobre todo nome, isto é, para que todos o tenham por Deus e como a Deus lhe prestem
reverência. Tal é o que o Apóstolo acrescenta: Para que ao nome de Jesus se dobre todo joelho dos que
estão nos céus, na terra e nos infernos. - Quarto, quanto ao seu poder judiciário, conforme aquilo da
Escritura: A tua causa tem sido julgada como a de um ímpio; ganharás a causa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O princípio do mérito está na alma; quanto ao corpo, ele
é o instrumento do ato meritório. Por onde, a perfeição da alma de Cristo, que foi o princípio de seu
merecimento, não a devia ele adquirir pelo mérito, como a perfeição do corpo, que foi o sujeito da
Paixão, sendo por isso o instrumento mesmo do mérito.

RESPOSTA À SEGUNDA. — Pelos méritos anteriores, Cristo mereceu a exaltação no concernente à sua
alma, cuja vontade era informada pela caridade e pelas outras virtudes. Mas na Paixão mereceu ser
exaltado a modo de uma certa recompensa, mesmo quanto ao corpo; pois, é justo que o corpo, que fora
pela caridade sujeito àPaixão, recebesse a sua recompensa na glória.

RESPOSTA À TERCEIRA. — Em virtude de uma permissão divina é que a glória da alma de Cristo não lhe
redundou, antes da Paixão, ao corpo; para que assim alcançasse uma glória mais esplêndida para o
corpo, quando a tivesse merecido pela Paixão. Mas, não convinha que fosse diferida a gloria da alma,
por estar esta unida imediatamente ao verbo; e por isso devia ficar cheio de glória, pela Verbo mesmo.
Ao contrário, o corpo estava unido ao Verbo mediante a alma.