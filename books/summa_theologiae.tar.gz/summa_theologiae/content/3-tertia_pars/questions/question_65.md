# Questão 65: Do número dos sacramentos
Em seguida devemos tratar do número dos sacramentos. E nesta questão discutem-se quatro artigos:

## Art. 1 — Se devem ser sete os sacramentos.
O primeiro discute-se assim. — Parece que não devem ser sete os sacramentos.

1. — Pois, os sacramentos tiram a sua eficácia da virtude divina e da virtude da paixão de Cristo. Ora,
uma só é a virtude divina, e uma só a paixão de Cristo; pois, no dizer do Apóstolo, com uma só oferenda
fez perfeitos para sempre os que têm santificados. Logo, devia haver só um sacramento.

2. Demais. — O sacramento se ordena a sanar a falta do pecado. Ora, esta é dupla: a pena e a culpa.
Logo, bastavam dois sacramentos.

3. Demais. — Os sacramentos são relativos aos atos da hierarquia eclesiástica, como está claro em
Dionísio. Ora como diz ainda Dionísio, três são as ações hierárquicas: a purgação, a iluminação e a
perfeição. Logo, não deve haver senão três sacramentos.

4. Demais. — Agostinho diz que os sacramentos da lei nova são em menor número que os da velha. Ora,
na lei velha nenhum sacramento havia correspondente à confirmação e à extrema unção. Logo, não
devem também estes ser contados entre os sacramentos da lei nova.

5. Demais. — A luxúria não é mais grave que os outros pecados, como se infere do dito na segunda
Parte. Ora, para remédio dos outros pecados não se instituem nenhum sacramento. Logo, nem contra a
luxúria devia ser instituído o sacramento do matrimônio.
Mas, em contrário. — Parece que são mais de sete os sacramentos.

6. — Demais. — Os sacramentos assim se chamam por serem uns quase sinais sagrados. Ora, muitas
outras santificações se fazem na Igreja por meio de sinais sensíveis; assim, a água benta, a consagração
dos altares e outras semelhantes. Logo, há mais de sete sacramentos.

7. Demais. — Hugo de S. Vitor diz que os sacramentos da lei velha eram as oferendas os dízimos e os
sacrifícios. Ora, o sacrifício da Igreja é um sacramento e se chama Eucaristia. Logo, também as oferendas
e os dízimos devem considerar-se sacramentos.

8. Demais. — Três são os gêneros de pecados: o original, o mortal e o venial. Ora, contra o pecado
original foi instituído o batismo; e contra o mortal, a penitência. Logo, deveria haver mais um
sacramento, além dos sete, ordenado contra o pecado venial.

SOLUÇÃO. — Como dissemos, os sacramentos da Igreja se ordenam a dois fins: à perfeição do homem
no concernente ao culto de Deus, segundo a religião da vida cristã; e também como remédio contra a
falta do pecado. Ora, em relação a esses dois fins foram convenientemente instituídos sete
sacramentos. Pois, a vida espiritual tem uma certa conformidade com a vida do corpo; assim como
também as coisas materiais têm uma certa conformidade com as espirituais. Ora, a vida do nosso corpo
é susceptível de dupla perfeição; quanto à nossa própria pessoa e quanto à toda a comunidade da
sociedade em que vivemos, porque o homem é um animal naturalmente social. Ora, em relação a si
mesmo a nossa vida corpórea é susceptível de dupla perfeição. Uma consiste em adquirirmos uma
perfeição vital, essencialmente falando. Outra é acidental e consiste na remoção dos obstáculos à vida,
como a doença e outras semelhantes.
Ora, essencialmente falando, a vida do nosso corpo é capaz de tríplice perfeição. — A primeira, é a
geração, pela qual começa a nossa existência e a nossa vida. E a esta corresponde, na ordem espiritual,
o batismo, que é uma regeneração espiritual, segundo o Apóstolo: Pelo batismo da regeneração etc. —
A segunda é o crescimento, pelo qual chegamos à perfeição da estatura e da robustez. E a esta
corresponde, na vida espiritual, a confirmação, pela qual o Espírito Santo nos fortifica. Por isso, Jesus diz
aos discípulos já batizados: Ficai vós de assento na cidade, até que sejais revestidos da virtude lá do alto.
— Terceiro, a nutrição pela qual conservamos a vida e vigor. E a esta corresponde na vida espiritual, a
Eucaristia. Por isso disse Jesus: Se não comerdes a carne do Filho do homem e beberdes o seu sangue,
não tereis vida em vós. E isto nos bastaria se tivéssemos corporal e espiritualmente falando, uma vida
impassível. Mas, como às vezes sofremos a doença do corpo, e a do espírito, que é o pecado, é nos
necessário curarmo-nos dela. E essa cura é dupla. Uma nos sana, de modo a nos restituir a saúde. E li
essa corresponde, na ordem espiritual, a penitência, segundo aquilo da Escritura: Sara a minha alma
porque pequei contra ti. — Outra é a restauração da nossa saúde anterior por um regime e exercício
convenientes. E a isto corresponde, na vida espiritual a extrema unção, que dele os resíduos do pecado
e nos torna preparados para a glória final. Donde o dizer a Escritura: E se estiver em alguns pecados, ser-
lhe-hão perdoados.
Quanto à universal comunidade, no seu total nós nos aperfeiçoamos de dois modos. — Primeiro,
recebendo o poder de governar o povo e de exercer atos públicos. E a isto corresponde, na ordem
espiritual, o sacramento da ordem, segundo o dito do Apóstolo, que os sacerdotes oferecem as vítimas
não só por si, mas ainda por todo o povo. — Segundo, quanto à propagação natural da espécie. O que se
dá pelo matrimônio tanto na vida do corpo como na espiritual: pois, não só é um sacramento mas uma
função da natureza.
Do que acabamos de dizer também resulta claro o número dos sacramentos, enquanto têm a finalidade
de reparar as faltas introduzidas pelo pecado. Assim, o batismo supre à privação da vida espiritual; a
confirmação se ordena a fortalecer a alma fraca dos que têm pouca idade; a Eucaristia é contra a
inclinação da alma ao pecado; a penitência, contra o pecado atual cometido depois do batismo; a
extrema unção, contra os resíduos dos pecados que, por negligência ou ignorância, não foram
suficientemente delidos pela penitência; a ordem contra a indisciplina do povo; o matrimônio, como
remédio contra a concupiscência individual e contra a diminuição da população, causada pela morte.
Certos porém consideram o número dos sacramentos por uma adaptação às virtudes e aos defeitos das
culpas e das penas. E dizem que à fé corresponde o batismo, que é dado como remédio à culpa original;
à esperança, a extrema unção, aplicada contra a culpa venial; à caridade, a Eucaristia, para obviar à
penalidade da malícia; à prudência, a ordem, remédio à ignorância; à justiça, a penitência; remédio
contra o pecado mortal; à temperança, o matrimônio, remédio contra a concupiscência; à fortaleza, a
confirmação, remédio para a fraqueza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Um mesmo agente principal pode servir—se de diversos
instrumentos para efeitos diversos, conforme a exigência da obra. Semelhantemente, a virtude divina e
a paixão de Cristo obram em nós pelos diversos sacramentos, quase como por instrumentos diversos.

RESPOSTA À SEGUNDA. — A culpa e a pena são diversas, pela espécie, por serem diversas as espécies
de culpas e de penas, e também os estados e as relações dos homens. E por isso era necessário
multiplicarem-se os sacramentos, como do sobredito resulta.

RESPOSTA À TERCEIRA. — Nas ações hierárquicas consideram—se os agentes, os que recebem e as
ações. — Quanto aos agentes, são os ministros da Igreja, a quem concerne o sacramento da ordem. —
Os que recebem são os que se achegam ao sacramento, e são produzidos pelo matrimônio. — As ações
são: a purgação, a iluminação e a perfeição. Mas só a purgação não pode ser sacramento da lei nova,
que confere a graça; mas se inclui em certos sacramentais que são a catequese e o exorcismo. Quanto à
purgação e à iluminação, pertencem simultâneamente, segundo Dionísio, ao batismo; e, por causa das
recidivas, incluem-se secundàriamente na penitência e na extrema unção. A perfeição enfim — quanto à
sua virtude, que é uma quase perfeição formal, pertence à confirmação: e quanto à consecução do fim
pertence à Eucaristia.

RESPOSTA À QUARTA. — O sacramento da confirmação dá—nos a força pela plenitude do Espírito
Santo; e pela extrema unção preparamo-nos a receber imediatamente a glória. Nada do que podia
existir no tempo do Testamento Velho. Por isso, na lei Velha nada podia corresponder a esses
sacramentos. Nem por isso porem os sacramentos da lei Velha deixaram de ser mais numerosos, por
causa da diversidade dos sacrifícios e das cerimônias.

RESPOSTA À QUINTA. — Contra a concupiscência da carne era necessário instituir um sacramento que
fosse especialmente um remédio para tal. Primeiro, porque essa concupiscência não só contamina o
individuo pessoalmente mas, também a natureza. Segundo, por causa da sua veemência, que priva da
razão.

RESPOSTA À SEXTA. — A água benta e as outras coisas consagradas não se chamam sacramentos, por
não produzirem o efeito do sacramento, que é a consecução da graça. Mas são umas disposições para o
sacramento. Ou porque removem os obstáculos, como a água benta eficaz contra as insídias dos
demônios e contra os pecados veniais. Ou produzem maior dignidade à solenidade do sacramento;
assim, consagra-se o altar e os vasos pela reverência para com a Eucaristia.

RESPOSTA À SÉTIMA. — As oferendas e os dízimos eram, tanto na lei da natureza como na de Moisés,
ordenadas não só ao subsídio dos ministros e dos pobres, mas também para serem figuras; e por isso
eram sacramentos. Mas não ficaram, até ao presente como figuras que eram e por isso já não são
sacramentos.

RESPOSTA À OITAVA. — Para delir o pecado venial não é necessária a infusão da graça. Por onde, como
por qualquer dos sacramentos da lei nova se infunde a graça, nenhum sacramento dessa lei é instituído
diretamente contra o pecado venial, que é delido por certos sacramentais, como a água benta e outros
semelhantes. — Mas certos, dizem que a extrema unção vale contra o pecado venial. Disto porem
trataremos em seu lugar.

## Art. 2 — Se os sacramentos convenientemente se ordenam segundo o modo predito.
O segundo discute—se assim. — Parece que os sacramentos não se ordenam convenientemente
segundo o modo predito.

1. Pois, como diz o Apóstolo, primeiro o que é animal, depois o que é espiritual. Ora; o matrimônio dá ao
homem a primeira geração, que é a animal; o batismo o regenera pela segunda, que é a espiritual. Logo,
o matrimônio deve preceder o batismo.

2. Demais. — Pelo sacramento da ordem recebe-se o poder de praticar atos sacramentais. Ora, o agente
é anterior à sua ação. Logo, a ordem deve preceder o batismo e os outros sacramentos.

3. Demais. — A Eucaristia é uma nutrição espiritual; e a confirmação é comparável ao crescimento. Ora,
a nutrição é a causa do crescimento e, por consequência, lhe é anterior. Logo, a Eucaristia é anterior à
confirmação.

4. Demais. — A penitência prepara o homem para a Eucaristia. Ora, a disposição precede a perfeição.
Logo, a penitência deve preceder a Eucaristia.

5. Demais. — O que está próximo do fim último é posterior. Ora, a extrema unção, dentre todos os
sacramentos, está mais próxima ao fim último da beatitude. Logo, deve ocupar o último lugar entre os
sacramentos.
Em contrário, é que todos em geral classificam os sacramentos como o fizemos antes.

SOLUÇÃO. — A razão da ordem entre os sacramentos resulta do que dissemos antes. Pois, sendo a
unidade anterior à multidão, assim os sacramentos ordenados à perfeição pessoal de cada um
naturalmente precedem os ordenados à da multidão. Por onde, entre os sacramentos ocupam o último
lugar a ordem e o matrimônio, ordenados à perfeição da coletividade. Mas o matrimônio vem depois da
ordem, por participar menos da natureza da vida espiritual, a que se ordenam os sacramentos. — Mas
dentre os sacramentos ordenados à perfeição de cada um em particular, ocupam naturalmente o
primeiro lugar os que essencialmente se ordenam à perfeição da vida espiritual, de preferência aos que
a ela se ordenam por acidente, isto é porque removeu. O acidente nocivo sobreveniente, como é o caso
da penitência e da extrema unção. Enfim, naturalmente em último lugar vem a extrema unção, que
consuma a sanação começada pela penitência. — Quanto aos outros três, é manifesto que o batismo,
como regeneração espiritual, tem prioridade; depois vem a confirmação, ordenada à perfeição formal
da virtude; enfim a Eucaristia, ordenada à perfeição final.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O matrimônio, enquanto ordenado à vida animal, é
função da natureza. Mas, enquanto é de certo modo espiritual, é sacramento. Por ter porem uma
espiritualidade mínima, é colocado em último lugar entre os sacramentos.

RESPOSTA À SEGUNDA. — Um agente, para o ser, pressupõe-se que é em si mesmo perfeito. Por onde
tem prioridade os sacramentos, que nos aperfeiçoam em nós mesmos, sobre o sacramento da ordem,
que nos torna mais perfeitos que os outros.

RESPOSTA À TERCEIRA. — A nutrição precede o crescimento como causa deste; mas lhe é posterior,
como a que nos conserva n.a plenitude do nosso corpo e saúde. Por isso pode-se dar à Eucaristia
prioridade sobre a confirmação, como faz Dionísio; e pode também vir depois, como faz o Mestre das
Sentenças.

RESPOSTA À QUARTA. — A objeção colheria se a penitência fosse necessàriamente preparatória à
Eucaristia. O que não é verdade, pois, quem não estiver em pecado mortal não precisa da penitência
para receber a Eucaristia. Por onde, é claro que por acidente a penitência prepara à Eucaristia, isto é,
supondo-se o pecado. Donde o dizer a Escritura: Tu, Senhor dos justos, não impuseste penitência aos
justos.

RESPOSTA À QUINTA. — A extrema unção, pela razão aduzida, é o último entre os sacramentos
ordenados à perfeição pessoal.

## Art. 3 — Se o sacramento da Eucaristia é o primeiro de todos os sacramentos.
O terceiro discute—se assim. — Parece que o sacramento da Eucaristia não é o primeiro entre os
sacramentos.

1. Pois, o bem comum tem prioridade sobre o bem particular, como diz Aristóteles. Ora, o matrimônio
se ordena ao bem comum da espécie humana, por via da geração; ao passo que o sacramento da
Eucaristia, ao bem próprio de quem o recebe. Logo, não é o primeiro dos sacramentos.

2. Demais. — Parece que mais dignos são os sacramentos conferidos por ministros de maior dignidade.
Ora, o sacramento da confirmação e o da ordem são conferidos só pelo bispo, ministro de maior
dignidade que o sacerdote, que confere o sacramento da Eucaristia. Logo, esses sacramentos são mais
principais.

3. Demais. — Os sacramentos são tanto mais principais quanto maior virtude tem. Ora, certos
sacramentos, como o batismo, a confirmação e a ordem, imprimem caráter — o que não faz a
Eucaristia. Logo, esses sacramentos são mais importantes.

4. Demais. — De duas coisas é mais importante aquela de que a outra depende e não ao invés. Ora, do
batismo depende a Eucaristia; pois, não pode receber a Eucaristia quem não for batizado. Logo, o
batismo é mais principal que a Eucaristia.
Mas, em contrário, diz Dionísio, que ninguém pode chegar à perfeição hierárquica senão pela
diviníssima Eucaristia. Logo, este sacramento é o mais digno e perfectivo, que todos os outros.

SOLUÇÃO. — Absolutamente falando, o sacramento da Eucaristia é o principalmente entre os outros
sacramentos. O que resulta de três razões. — Primeiro, porque nele está contido o próprio Cristo
substancialmente; ao passo que nos outros sacramentos está contida uma certa virtude instrumental
participada de Cristo, como do sobredito se colhe. Ora, sempre o essencial é mais principal do que o
participado. — Segundo isso mesmo resulta da ordem dos sacramentos entre si; pois, todos os outros
sacramentos se ordenam para este como para o fim. Pois, é manifesto que o sacramento da ordem tem
como fim a consagração da Eucaristia. Quanto ao do batismo, ele se ordena à recepção da Eucaristia.
Para o que também nos aperfeiçoa a confirmação, fazendo—nos não temer de nos achegar a esse
sacramento. Também a penitência e a extrema unção nos preparam a receber dignamente o corpo de
Cristo. O matrimônio, enfim, ao menos pela sua significação, concerne a esse sacramento, enquanto
significa a união de Cristo e da Igreja, cuja unidade é figurada pelo sacramento da Eucaristia. Por isso, diz
o Apóstolo: este sacramento é grande, mas eu digo em Cristo e na Igreja. — Terceiro, o mesmo resulta
do rito dos sacramentos. Pois, quase todos os sacramentos, vem a se resumir na Eucaristia, como diz
Dionísio; e isso o demonstra o fato de os ordenados comungarem e também os batizados, se forem
adultos.
Quanto à relação mútua entre os outros sacramentos ela pode ser múltipla. Assim, quanto à
necessidade, o batismo é o primeiro de todos os sacramentos; quanto à perfeição, o da ordem; em
posição intermediária está o sacramento da confirmação. Quanto aos sacramentos da penitência e da
extrema unção, estão num grau inferior aos outros sacramentos referidos; pois, como dissemos,
ordenam—se à vida cristã não por si mesmos, mas quase por acidente, isto é, como remédio à uma falta
sobreveniente. Entre os quais porém a extrema unção está para a penitência, como a confirmação para
o batismo; de modo que a penitência é de mais necessidade, mas a extrema unção é de maior perfeição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O matrimônio se ordena ao bem comum corporal. Mas o
bem espiritual de toda a Igreja está substancialmente contido no próprio sacramento da Eucaristia.

RESPOSTA À SEGUNDA. — Pela ordem e pela confirmação os fiéis de Cristo são destinados a certos
ofícios; e assim destiná—las é função do chefe. Por isso, comunicar esses sacramentos pertence só ao
bispo, que é quase príncipe da Igreja. Ao passo que pelo sacramento da Eucaristia não somos destinados
a nenhum ofício; ao contrário, esse sacramento é a finalidade de todos os ofícios, como se disse.

RESPOSTA À TERCEIRA. — O caráter sacramental, como dissemos, é de certo modo participação do
sacerdócio de Cristo. Por onde, o sacramento que une a Cristo mesmo, com o homem é mais digno que
o sacramento que imprime o caráter de Cristo.

RESPOSTA À QUARTA. — A objeção colhe quanto à necessidade. Pois, o batismo, sendo o de mais
necessidade, é o principalissimo dos sacramentos. Assim como a ordem e a confirmação tem uma certa
excelência, em razão do ministério; e o matrimônio, em razão da significação. Pois, nada impede ser
uma causa, de certo modo, mais digna, sem o ser absolutamente falando.

## Art. 4 — Se todos os sacramentos são necessários à salvação.
O quarto discute—se assim. — Parece que todos os sacramentos são necessários à salvação.

1. Pois, o que não é necessário é supérfluo. Ora, nenhum sacramento é supérfluo porque Deus não faz
nada em vão. Logo, todos os sacramentos são necessários à salvação.

2. Demais. — Assim como do batismo, diz o Evangelho: Quem não renascer da água e do Espírito Santo
não pode entrar no reino de Deus — assim também da Eucaristia: Se não comerdes a carne do Filho do
homem e não beberdes o seu sangue não tereis vida em vós. Logo, assim como o batismo é um
sacramento de necessidade para a salvação, assim também a Eucaristia.

3. Demais. — Sem o sacramento do batismo pode uma pessoa salvar—se contanto que não o deixasse
de o receber por desprezo, mas por necessidade, como a seguir se dirá. Ora, em Qualquer sacramento o
desprezo da religião impede—nos a salvação. Logo, pela mesma razão, todos os sacramentos são
necessários à salvação.
Mas, em contrário, as crianças se salvam só pelo batismo, sem os outros sacramentos.

SOLUÇÃO. — De dois modos podemos considerar a necessidade relativamente ao fim, da qual agora
tratamos. — Num sentido, é tal quem sem ela não pode ser conseguido o fim; assim a comida é
necessária à vida humana. E esta é a necessidade absoluta, para a consecução do fim. — Noutro
sentido, necessário é aquilo sem o que não podemos atingir convenientemente o fim; assim o cavalo é
necessário para uma viagem. E esta necessidade não é necessária, absolutamente falando, para
atingirmos o fim. Ora no primeiro sentido da necessidade, três sacramentos são necessários. Dois a cada
pessoa em particular: o batismo, simples e absolutamente falando; e a penitência, suposto o pecado
mortal depois do batismo. Quanto ao sacramento da ordem, ele é necessário à Igreja, porque, no dizer
da Escritura, onde não há quem governe perecerá o povo. — Mas, no segundo sentido, os outros
sacramentos são necessários. Assim, a confirmação de certo modo aperfeiçoa o batismo; a extrema
unção, a penitência; e o matrimônio enfim conserva, pela propagação, o povo fiel.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Para uma coisa não ser supérflua basta que seja
necessária no primeiro ou no segundo sentido. E assim são necessários todos os sacramentos, como
dissemos.

RESPOSTA À SEGUNDA. — Essas palavras do Senhor devem ser entendidas da manducação espiritual, e
não só da sacramental, como o explica Agostinho.

RESPOSTA À TERCEIRA. — Embora o desprezo de todos os sacramentos seja contrário à salvação, não
há contudo desprezo do sacramento no fato de quem não cuida de receber o que não é de necessidade
à salvação. Do contrário, todos os que não recebessem a ordem e não contraíssem matrimônio
desprezariam esses sacramentos.
O Batismo
Em seguida devemos tratar de cada sacramento em especial. E primeiro do batismo. Segundo, da
confirmação. Terceiro, da Eucaristia. Quarto, da penitência. Quinto, da extrema unção. Sexto, da ordem.
Sétimo, do matrimônio.
Sobre o primeiro há uma dupla consideração a fazer. A primeira, sobre o batismo em si mesmo. A
segunda, dos preparativos para o batismo. Na primeira, consideram-se quatro questões. Primeiro, do
concernente ao sacramento do batismo. Segundo do ministro deste sacramento. Terceiro, dos que
recebem esse sacramento. Quarto, do efeito desse sacramento.