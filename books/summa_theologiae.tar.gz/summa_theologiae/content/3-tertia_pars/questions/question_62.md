# Questão 62: Do efeito principal dos Sacramentos, que é a graça.
Em seguida devemos tratar do efeito dos sacramentos. E primeiro, do efeito principal, que é a graça.
Segundo, do efeito secundário que é o caráter.
Na primeira, discutem-se seis artigos:

## Art. 1 — Se os sacramentos são a causa da graça.
O primeiro discute-se assim. — Parece que os sacramentos não são a causa da graça.

1. — Pois, o mesmo não pode ser o sinal que a causa, porque ser sinal é por natureza mais próprio do
efeito. Ora, o sacramento é o sinal da graça. Logo, não é a causa dela.

2. Demais. — Nenhum ser material pode agir sobre o ser espiritual, porque O agente é mais digno que o
paciente, como diz Agostinho. Ora, o sujeito da graça é a inteligência do homem, de natureza espiritual.
Logo, os sacramentos não podem causar a graça.

3. Demais. — O que é próprio de Deus não deve ser atribuído a nenhuma criatura ora, causar a graça é
próprio de Deus, segundo aquilo da Escritura: o Senhor dará a graça e a glória. Logo, consistindo os
sacramentos em certas palavras ou coisas criadas, parece que não podem conferir a graça.
Mas, em contrário, diz Agostinho, que a água batismal toca o corpo e lava o coração. Ora, o coração só
pode ser lavado pela graça. Logo causa a graça. E, pela mesma razão, os outros sacramentos da Igreja.

SOLUÇÃO. — É necessário admitir-se que os sacramentos da lei nova de certo modo causam a graça.
Pois, é manifesto que pelos sacramentos da lei nova o homem se incorpora a Cristo, como do batismo
diz o Apóstolo: Todos os que tostes batizados em Cristo revestiste-vos de Cristo. Ora, só pela graça se
torna o homem membro de Cristo.
Certos porém opinam que os sacramentos não são causa da graça por produzirem alguma operação,
mas porque Deus, conferidos eles, opera na alma. E aduzem o exemplo daquele que, trazendo um
dinheiro de chumbo, recebeu cem libras por ordem do rei; não que esse dinheiro em nada contribuísse
para receber a quantia das referidas libras, porque isso só o foi por vontade do rei. Donde o dizer
Bernardo: Assim como o cônego recebe a sua investidura pelo livro, o abade pelo báculo, o bispo pelo
anel, assim os sacramentos transmitem espécies diversas de graças.
Mas, quem considerar acertadamente verá que esse modo de obrar não transcende a natureza do sinal.
Pois, o dinheiro de chumbo não era mais do que um sinal da ordem régia indicativo de terem as libras
sido recebidas pelo que o entregou. Semelhantemente, o livro é um sinal indicador de que foi conferido
o canonicato. Ora, a ser assim os sacramentos da lei nova não seriam senão o sinal da graça; e contudo
das autoridades de muitos santos resulta que esses sacramentos não só significam, mas causam a graça.
Portanto devemos pensar de outro modo, que dupla é a causa agente - principal e instrumental. - Ora, a
principal opera por virtude da sua forma, à qual o efeito se assimila, assim o fogo aquece com o calor. E,
desta maneira, só Deus pode causar a graça; pois, a graça outra coisa não é senão uma semelhança
participada da natureza divina, segundo aquilo da Escritura: Comunicou-nos as mui grandes e preciosas
graças que tinha prometido, para que sejamos feitos participantes da natureza divina. - Quanto à causa
instrumental, ela não age em virtude da sua forma, mas só pelo movimento que recebe do agente
principal. Por isso o efeito não se assemelha ao instrumento, mas ao agente principal; assim um leito
não se assemelha ao machado, mas à arte que o artista tinha em mente. E, desta maneira, os
sacramentos da lei nova causam a graça; pois, são conferidos por disposição divina aos homens para
neles a causarem. Donde o dizer Agostinho: Todas estas coisas, isto é, os sacramentais, operam e
passam; mas a virtude (de Deus) que eles obram, permanece perenemente. Ora, instrumento
propriamente se chama aquilo com que obramos. Por isso diz o Apóstolo: O salvador nos salvou pelo
batismo de regeneração.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A causa principal não pode propriamente considerar-se
sinal do efeito, embora oculto, mesmo se ela for sensível e manifesta, Mas a causa instrumental, sendo
manifesta, pode chamar-se o sinal do efeito oculto. Porque não somente é causa, mas também de certo
modo efeito, enquanto movida pelo agente principal. E, assim sendo, os sacramentos da lei nova são
simultaneamente causas e sinais. Donde vem que, como se diz comumente, realizam o que figuram. Por
onde também é claro que têm perfeitamente natureza de sacramento, enquanto se ordenam a um fim
sagrado não só a modo de sinal, mas também a modo de causa.

RESPOSTA À SEGUNDA. — Um instrumento produz duas ações: uma instrumental, pela qual opera, não
por virtude própria, senão por virtude do agente principal; mas tem outra ação, que lhe é própria, e lhe
cabe pela sua forma própria. Assim ao machado é próprio o cortar, em razão da sua acuidade; mas,
fazer um leito, enquanto instrumento da arte. Mas, não efetiva a sua ação instrumental, senão
exercendo a sua ação própria; pois, cortando é que faz o leito. E semelhantemente, os sacramentos
corpóreos, pela própria operação que exercem sobre o corpo, que tocam, realizam uma operação
instrumental por virtude divina sobre a alma. Assim a água do batismo, lavando o corpo pela sua virtude
própria lava a alma enquanto instrumento da virtude divina, pois, corpo e alma constituem uma
unidade. Tal o sentido das palavras de Agostinho - toca o corpo e lava a alma.

RESPOSTA À TERCEIRA. — A objeção colhe, do que é causa da graça a modo de agente principal; o que é
próprio de Deus, como se disse.

## Art. 2 — Se a graça sacramental faz algum acréscimo à graça das virtudes e à dos dons.
O segundo discute-se assim. — Parece que a graça sacramental nada acrescenta à graça das virtudes e
à dos dons.

1. — Pois, pela graça das virtudes e dos dons a alma se aperfeiçoa suficientemente, tanto na sua
essência como nas suas potências, conforme resulta do que foi dito na Segunda Parte. Ora, a graça se
ordena à perfeição da alma. Logo, a graça sacramental nada pode acrescentar à graça das virtudes e dos
dons.

2. Demais. — Os defeitos da alma são causados pelo pecado. Ora, todos os pecados são suficientemente
evitados pela graça das virtudes e dos dons; pois, não há nenhum pecado que não contrarie alguma
virtude. Logo, a graça sacramental, ordenada a purificar a alma dos seus defeitos, nada pode
acrescentar à graça das virtudes e dos dons.

3. Demais. — Toda adição ou subtração na forma faz variar a espécie, como diz Aristóteles. Se, pois, a
graça sacramental faz algum acréscimo à graça das virtudes e dos dons, segue-se que a palavra graça é
empregada em sentido equívoco. E assim, nada se nos afirma de certo em dizer-se que os sacramentos
causam a graça.
Mas, em contrário, se a graça sacramental nada acrescenta à graça dos dons e das virtudes, em vão se
conferenciam os sacramentos aos que têm os dons e as virtudes. Logo, parece que graça sacramental
algo acrescenta à graça das virtudes e dos dons.

SOLUÇÃO. — Como dissemos na Segunda Parte, a graça, em si mesmo considerada, aperfeiçoa a
essência da alma, fazendo-a participar de certo modo da semelhança do ser divino. E assim como da
essência da alma emanam as suas potências, assim da graça efluem certas perfeições para as potências
da alma, chamadas virtudes e dons, que aperfeiçoam essas potências em relação aos seus atos. Ora, os
sacramentos se ordenam a certos efeitos especiais necessários à vida cristã. Assim, o batismo se ordena
de algum modo à regeneração especial pela qual o homem morre aos vícios e se torna membro de
Cristo; e esse é um efeito especial, além dos atos das potências da alma. E o mesmo se dá com os outros
sacramentos. Portanto, assim como as virtudes e os dons acrescentam à graça comum uma certa
perfeição determinadamente ordenada aos atos próprios das potências, assim também a graça
sacramental acrescenta à graça comum e às virtudes e aos dons um certo auxílio divino para se
conseguir o fim do sacramento. E deste modo a graça sacramental algo acrescenta à graça das virtudes e
dos dons.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A graça das virtudes e a dos dons aperfeiçoa
suficientemente a essência e as potências da alma em relação aos atos a que geralmente se ordenam.
Mas para certos efeitos especiais, necessários à vida cristã, é preciso a graça sacramental.

RESPOSTA À SEGUNDA. — Com as virtudes e os dons evitamos suficientemente os vícios e os pecados
presentes e futuros, porque essas virtudes e esses dons nos fortalecem para os evitarmos. Mas, quanto
aos pecados pretéritos que, como atos, já passaram, permanecendo porém, quanto ao reato, os
sacramentos conferem ao homem um remédio especial.

RESPOSTA À TERCEIRA. — A noção de graça sacramental está para a graça comumente chamada, como
a noção de espécie para a de gênero. Por onde, assim como a palavra animal, comumente usada e
tomada para significar o homem, não se emprega em sentido equívoco, assim também em sentido
equívoco não se emprega a graça usada na significação comum e a graça sacramental.

## Art. 3 — Se os sacramentos da lei nova contêm a graça.
O terceiro discute-se assim. — Parece que os sacramentos da lei nova não contêm a graça.

1. — Pois, o conteúdo está incluído no continente. Ora, a graça não a inclui o sacramento, nem como
sujeito, porque o sujeito da graça não é o corpo, mas o espírito; nem como um vaso, porque um vaso é
um local móvel como diz Aristóteles, e ocupar um lugar não o pode o acidente. Logo, parece que os
sacramentos da lei nova não contêm a graça.

2. Demais. — O fim dos sacramentos é nos tornar possível a consecução da graça. Ora, a graça, sendo
um acidente não pode passar de um sujeito para outro. Logo, nela seria a graça sacramental.

3. Demais. — O espiritual não pode ser contido pelo corporal, mesmo se nele estiver; assim, a alma não
é contida pelo corpo, mas, antes, contém o corpo. Logo, parece que a graça, sendo de natureza
espiritual, não está contida num sacramento corporal.
Mas, em contrário, Hugo de S. Vitor diz que o sacramento, por santificação, contém a graça invisível.

SOLUÇÃO. — De muitos modos podemos dizer que um ser está em outro; e desses, há dois pelos quais
a graça está no sacramento. Primeiro por serem eles sinais; pois, um sacramento é sinal da graça.
Depois, por serem causa; pois, como dissemos, o sacramento da lei nova é causa instrumental da graça.
Por onde, a graça existe nos sacramentos da lei nova, não por semelhança específica, como o efeito está
contido na causa unívoca; nem ainda segundo nenhuma forma própria e permanente, proporcionada a
tal efeito, como se dá com os efeitos nas causas não unívocas, por exemplo, no caso das causas geradas,
que estão no sol; mas segundo uma certa virtude instrumental,cujo ser é natureza transitiva e
incompleta, como a seguir se dirá.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não se diz eu a graça esta no sacramento como no
sujeito; nem como num vaso, enquanto é este uma espécie de lugar. Mas no sentido em que dizemos
ser um vaso um instrumento com que fazemos uma obra, conforme aquilo da Escritura: Cada um tem
na sua mão um instrumento de morte.

RESPOSTA À SEGUNDA. — Embora o acidente não passe de um sujeito para outro passa contudo de
certo modo, da causa para o sujeito, mediante o instrumento. Não que de maneira idêntica existe em
ambos, mas em cada um de modo próprio.

RESPOSTA À TERCEIRA. — O espiritual existente de maneira perfeita em outro ser, contém-no e não é
contido por este. Ora, a graça esta no sacramento como um ser transitivo e incompleto. E por isso não é
inexato dizer-se que o sacramento contém a graça.

## Art. 4 — Se nos sacramentos há alguma virtude causadora da graça.
O quarto discute-se assim. – Parece que nos sacramentos não há nenhuma virtude causadora da
graça.

1. Pois, a virtude causadora da graça é a virtude espiritual. Ora, no corpo não pode haver nenhuma
virtude espiritual. Nem de modo que lhe seja própria, porque a virtude emana da essência do ser e, por
consequência, não pode transcendê-la; nem pela receber de outro ser, porque o recebido de fora nele
existiria como em recipiente. Logo, nos sacramentos não pode haver nenhuma virtude causadora da
graça.

2. Demais. — Tudo o existente se reduz a algum gênero de ser e a algum grau do bem. Ora, não é
possível dizer a que gênero de ser pertenceria a referida virtude, como o verá quem passar em revista
os casos particulares. Assim, não pode reduzir-se a nenhum grau de bondade; pois, nem se classifica
entre os bens mínimos porque os sacramentos são de necessidade para a salvação; nem ainda entre os
bens máximos, pois, nem é graça nem virtude do intelecto. Logo, parece que nos sacramentos não há
nenhuma virtude causativa da graça.

3. Demais. — Se a referida graça existe nos sacramentos, neles não é causada senão pela criação de
Deus. Ora, parece inconveniente que tão nobre criatura desapareça, logo que o sacramento foi
consumado. Logo, parece que nenhuma virtude há nos sacramentos para causar a graça.

4. Demais. — Um mesmo elemento não pode existir em coisas diversas. Ora, para os sacramentos
concorrem diversos elementos, a saber, palavras e coisas; mas um sacramento não pode ter senão uma
virtude. Logo, parece que nos sacramentos não há nenhuma virtude.
Mas, em contrário, Agostinho diz: Que tão grande virtude tem a água para tocar o corpo e lavar o
coração? E Beda: O Senhor, pelo contacto da sua puríssima carne, conferiu à água a virtude
regenerativa.

SOLUÇÃO. — Os que afirmam que os sacramentos não causam a graça senão por uma certa
concomitância, admitem que não há no sacramento nenhuma virtude que lhe cause o efeito; há porém
uma virtude divina, coassistente ao sacramento, que produz o efeito sacramental. Mas, admitindo que o
sacramento é a causa instrumental da graça, necessário é simultaneamente admitir-se que há no
sacramento uma virtude instrumental que produz o efeito sacramental. E essa virtude se proporciona ao
instrumento. Por onde, está para a virtude absoluta e perfeita de um ser como está o instrumento para
o agente principal. Pois, o instrumento, como se disse, não obra senão quando movido pelo agente
principal, que age por si mesmo. Por isso a virtude do agente principal tem um ser de natureza
permanente e completo; ao passo que a virtude instrumental tem um ser transitivo de um para outro e
incompleto; assim como o movimento é um ato imperfeito que passa do agente para o paciente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Uma virtude espiritual não pode existir num ser
corpóreo a modo de virtude permanente e completa, como o prova a razão. Nada impede porem haver
num corpo uma virtude espiritual instrumental; isto é, enquanto esse corpo pode ser movido por uma
substância espiritual a produzir um efeito espiritual. Assim como na palavra sensível há uma certa
virtude espiritual capaz de despertar o nosso intelecto, por proceder ela da concepção da mente. E,
deste modo, a virtude espiritual existe nos sacramentos enquanto ordenados por Deus a um efeito
espiritual.

RESPOSTA À SEGUNDA. — Assim como o movimento, por ser um ato imperfeito, não entra
propriamente em nenhum gênero, mas se reduz ao gênero de ato perfeito, como a alteração à
qualidade, assim, a virtude instrumental não está propriamente falando, em nenhum gênero, mas se
reduz ao gênero e à espécie da virtude perfeita.

RESPOSTA À TERCEIRA. — Assim como a virtude instrumental o instrumento a adquire por isso mesmo
que é movido pelo agente principal, assim também um sacramento adquire a virtude espiritual pela
bênção de Cristo e pela aplicação do ministro ao uso desse sacramento. Por isso diz Agostinho: Nada há
para admirar, quando dizemos que a água, substância material, chega a purificar a alma. Chega-o de
fato e penetra todos os latíbulos da consciência. Embora seja de natureza subtil e leve, torna-se ainda
mais subtil pela graça de Cristo e penetra com a subtileza do seu orvalho as fontes da vida e os
recônditos da alma.

RESPOSTA À QUARTA. — Assim como a mesma virtude do agente principal existe instrumentalmente
em todos os instrumentos ordenados a produzir um efeito enquanto formam numa certa ordem uma
unidade; assim também a mesma virtude sacramental existe nas palavras e nas coisas, enquanto que
cada sacramento se perfaz por meio de certas palavras e coisas.

## Art. 5 — Se os sacramentos da lei nova tiram a sua virtude da Paixão de Cristo.
O quinto discute-se assim. — Parece que os sacramentos da lei nova não tiram a sua virtude da Paixão
de Cristo.

1. — Pois, o fim da virtude dos sacramentos é causar a graça na alma, que a faz viver espiritualmente.
Ora, como diz Agostinho, O Verbo, como estava no princípio junto de Deus, assim vivifica as almas; mas,
enquanto feito carne, vivifica os corpos. Ora, a Paixão de Cristo concernindo ao Verbo, enquanto feito
carne, parece que não pode causar a virtude dos sacramentos.

2. Demais. — A virtude dos sacramentos depende da fé, porque, como diz Agostinho, o Verbo de Deus
perfaz os sacramentos, não por ser proferido, mas por ser crido. Ora, a nossa fé não só respeita à Paixão
de Cristo, mas também outros mistérios da sua humanidade, e mais principalmente ainda da sua
divindade. Logo. parece que os sacramentos não têm especialmente a sua virtude, da Paixão de Cristo.

3. Demais. — Os sacramentos se ordenam à santificação do homem, segundo aquilo do Apóstolo:
Haveis sido lavados e haveis sido justificados. Ora, a justificação é atribuída à ressurreição, segundo o
Apóstolo: Ressuscitou para nossa justificação. Logo, parece que os sacramentos tiram a sua virtude
antes da ressurreição que da Paixão de Cristo.
Mas, em contrário, àquilo do Apóstolo - Por uma transgressão semelhante à de Adão, diz a Glosa: Ao
lado de Cristo, expirado na cruz, manavam os sacramentos, pelos quais se salvou a Igreja. Assim os
sacramentos parece que tiram a sua virtude da Paixão de Cristo.

SOLUÇÃO. — Como dissemos, o sacramento contribui para causar a graça, a modo de instrumento. Ora,
há duas espécies de instrumentos: um separado, como o bastão; outro conjunto, como as mãos. Ora,
pelo instrumento conjunto é movido o instrumento separado; assim. o bastão, pela mão. Ora, a causa
eficiente principal da graça é Deus mesmo, para quem esta a humanidade de Cristo como um
instrumento conjunto, e o sacramento como um instrumento separado. Por onde e necessariamente, a
virtude salutífera deriva da divindade de Cristo,por meio de sua humanidade, para os sacramentos. Ora,
a graça sacramental sobretudo se ordena a duas coisas, a saber: polir a mácula dos pecados passados,
que passam quanto ao ato, porém ficam quanto ao reato; e além disso, aperfeiçoar a alma no atinente
ao culto de Deus, segundo a religião da vida cristã. Ora, é manifesto, pelo que foi dito antes, que Cristo
livrou-nos dos nossos pecados sobretudo pela sua paixão, não só suficiente e meritoriamente, mas
também satisfatoriamente. Do mesmo modo, com a sua paixão iniciou o rito da religião cristã, entregou-
se a si mesmo como oferenda e hóstia a Deus, no dizer do Apostolo. Por onde, é manifesto que os
sacramentos da igreja tiram especialmente a sua virtude da Paixão de Cristo, cuja virtude de algum
modo se nos une a nós pela suscepção dos sacramentos. Para sinal do que, do lado de Cristo pendente
da Cruz correu água e sangue, simbolizando aquela o batismo e este à Eucaristia os mais principais dos
sacramentos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Verbo, enquanto existente no princípio junto de Deus,
vivifica as almas, como agente principal; mas a sua carne e os mistérios nela perpetrados, obram
instrumentalmente a vida da alma. Mas a vida do corpo, não só instrumentalmente senão ainda por
uma certa exemplaridade como dissemos.

RESPOSTA À SEGUNDA. — Pela fé Cristo habita em nós, como diz o Apóstolo. E assim a virtude de Cristo
se nos aplica pela fé. Mas, a virtude remissiva dos pecados de certo modo especial pertence à Paixão de
Cristo. Por isso, pela fé na sua Paixão os homens são especialmente libertados dos pecados, segundo
aquilo dos Apóstolos: Ao qual propôs Deus para ser vitima de propiciação pela fé no seu sangue. Por
onde, a virtude dos sacramentos, ordenada a delir os pecados, emana principalmente da fé na Paixão de
Cristo.

RESPOSTA À TERCEIRA. — A justificação é atribuída à ressurreição relativamente ao termo final, que é a
vida nova da graça. Mas é atribuída à Paixão em razão do termo de origem, isto é, quanto ao perdão da
culpa.

## Art. 6 — Se os sacramentos da lei antiga causavam a graça.
O sexto discute-se assim. – Parece que os sacramentos da lei antiga causavam a graça.

1. Pois como dissemos. os sacramentos da lei nova tiram a sua eficácia da fé na Paixão de Cristo. Ora, a
fé na Paixão de Cristo existia na lei antiga, como em a nova, conforme diz o Apóstolo: Pois, nós temos
um mesmo espírito de fé. Logo, assim como os sacramentos da lei nova conferem a graça, assim
também os da lei antiga a cumpriam.

2. Demais. — A santificação não se faz senão pela graça. Ora, pelos sacramentos da lei antiga os homens
eram santificados, como lemos na Escritura: Como Moisés santificasse Arão e seus filhos nos seus
vestidos, etc. Logo, parece que os sacramentos da lei antiga conferiam a graça.

3. Demais. — Beda diz: A circuncisão, na vigência da lei, exercia a mesma cura salutar contra o ferimento
do pecado original, que costuma exercer o batismo no tempo da graça revelada. Ora, o batismo confere
a graça. Logo, também a conferia a circuncisão; e pela mesma razão os outros sacramentos da lei nova,
assim o era a circuncisão aos sacramentos da lei antiga. Por isso diz o Apóstolo: Protesto a todo homem
que se circuncida, que está obrigado a guardar toda a lei.
Mas, em contrário. o Apóstolo: Tornai-vos outra vez aos rudimentos fracos e pobres? E a Glosa: Isto é, à
lei, chamada fraca porque não justifica perfeitamente. Logo os sacramentos da lei antiga não conferiam
a graça.

SOLUÇÃO. — Não se pode dizer que os sacramentos da lei antiga conferissem a graça justificante por si
mesma, isto é, por virtude própria, porque então a paixão de Cristo não seria necessária, segundo aquilo
do Apóstolo: Se a justiça é pela lei, segue-se que morreu Cristo em vão. – Mas nem se pode dizer que da
paixão de Cristo tenham a virtude de conferir a graça justificante. Pois, como do sobredito se infere, a
virtude da paixão de Cristo se nos aplica pela fé e pelos sacramentos, mas diferentemente. Assim a
continuidade fundada na fé resulta de um ato da alma; ao passo que a fundada nos sacramentos resulta
do uso exterior das coisas. Ora, nada impede ao que é posterior no tempo mover, antes de existir,
enquanto tem precedência, por um ato da alma; assim o fim, posterior no tempo, move o agente,
enquanto apreendido e desejado por ele. Mas, o ainda não existente como realidade da natureza, não
move pelo uso que disso se faça; por isso a causa eficiente não pode ser posterior na sua existência pela
ordem de duração, como a causa final. Assim, pois, é manifesto, que da paixão de Cristo, causa da
justificação humana, convenientemente deriva a justificativa para os sacramentos da lei nova, mas não
para os da lei antiga. E, contudo pela fé da paixão de Cristo foram justificados os antigos Patriarcas,
como o somos nós. Pois, os sacramentos da lei antiga eram uma quase manifestação dessa fé, enquanto
significavam a paixão de Cristo e os seus efeitos. - Por onde é claro que os sacramentos da lei antiga não
tinham em si nenhuma virtude pela qual pudessem conferir a graça justificante: mas somente
significavam a fé, pela qual se operava a justificação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os antigos Patriarcas tinham fé na paixão futura de
Cristo, a qual, enquanto já apreendida pela alma, podia justificar. Ao passo que nós temos fé na Paixão
de Cristo consumada, que pode justificar mesmo pelo uso real das coisas sacramentais, como se disse.

RESPOSTA À SEGUNDA. — Essa santificação era figurada; pois, os sacramentos da lei antiga se
consideravam como santificantes por serem aplicados ao culto divino conforme o dito dessa lei, que
toda se ordenava a figurar a paixão de Cristo.

RESPOSTA À TERCEIRA. — Muitas foram as opiniões a respeito da circuncisão. Assim, certos disseram
que não era pela circuncisão conferida a graça, mas apenas delido o pecado. – Isto, porém não é
admissível, porque o homem não é justificado do pecado senão pela graça, segundo aquilo do Apóstolo:
Tendo sido justificados gratuitamente por sua graça. Por isso opinavam outros que pela circuncisão era
conferida a graça, quanto aos seus efeitos de removerem a culpa, mas não quanto aos efeitos positivos
dela. - Mas também esta opinião é falsa. Pois, a circuncisão dava às crianças a faculdade de chegar à
glória, que é o último efeito positivo da graça. E, além disso, segundo a ordem da causa formal, os
efeitos positivos têm naturalmente prioridade sobre os privativos, embora o contrário se dê segundo a
ordem da causa material; pois, a forma não exclui a privação, senão informando o sujeito.
E por isso outros dizem que a circuncisão conferia a graça mesmo quanto a um certo efeito positivo, que
é tornar digno da vida. eterna: mas não porque reprimisse a concupiscência, que excita a pecar. E assim
me pareceu algum tempo. - Mas, mais atentamente refletindo, verifiquei que também isto não é
verdadeiro; porque uma graça mínima pode resistir a qualquer concupiscência e merecer a vida eterna.
Por onde e melhor, devemos concluir que a circuncisão era só o sinal da fé justificante. Donde o dizer o
Apóstolo: que Abraão recebeu o sinal da circuncisão como selo da justiça da fé. Por isso a circuncisão
conferia a graça, enquanto sinal da futura paixão de Cristo, como a seguir se dirá.