# Questão 9: Da ciência de Cristo em geral
Em seguida devemos tratar da ciência de Cristo em geral. Sobre a qual há duas questões a tratar. A
primeira, sobre a ciência que Cristo teve. A segunda, sobre cada uma das suas ciências.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se Cristo tinha alguma ciência além da divina.
O primeiro discute-se assim. — Parece que Cristo não tinha uma ciência, além da divina.
1 — Pois, a ciência é necessária para, por meio dela, adquirirmos certos conhecimentos. Ora, Cristo, pela
ciência divina, conhecia todas as coisas. Portanto, era-lhe supérflua outra ciência.

2. Demais. — A luz maior ofusca a menor. Ora, toda ciência criada está para a ciência de Deus incriada
como a luz menor, para a maior. Logo, em Cristo não refulgiu outra ciência além da divina.

3. Demais. — A união da natureza humana com a divina fez-se na pessoa, como do sobredito resulta.
Ora, segundo alguns, Cristo teve uma certa ciência de união, pela qual sabia o atinente ao mistério da
Encarnação, mais plenamente que qualquer outro. Ora, como a união pessoal contém duas naturezas,
parece que não havia em Cristo duas ciências, mas uma só, pertinente a uma e outra natureza.
Mas, em contrário, diz Ambrósio: Deus assumiu, na carne, a perfeição da natureza humana; assumiu a
alma sensitiva do homem, mas não a entumescida pela soberba da carne. Logo, Cristo teve uma ciência
criada.

SOLUÇÃO. — Como do sobredito resulta, o Filho de Deus assumiu a natureza humana criada; isto é, não
só o corpo, mas também a alma, não só a sensitiva, mas também a racional. Logo, tinha
necessariamente a ciência criada, por três razões. — Primeiro, por causa da perfeição da alma. Pois, em
si mesma considerada, a alma é potencial em relação ao conhecimento dos inteligíveis; pois, é como
uma tábua em que nada está escrito; e contudo. é possível escrever nela, por meio do intelecto possível,
pelo qual pode tornar-se todas as causas, como diz Aristóteles. Pois, o potencial é imperfeito, se não for
reduzido ao ato. Ora, não era conveniente que o Filho de Deus assumisse a natureza humana imperfeita,
mas, a perfeita, como a mediante a qual todo o gênero humano devesse ser reduzido à perfeição. E por
isso era necessário fosse a alma de Cristo perfeita, por meio de uma ciência, que fosse a perfeição
própria dele. Logo, também devia necessariamente ter uma outra ciência além da divina. Do contrário, a
alma de Cristo seria mais imperfeita que a dos outros homens. — Segundo, como todas as causas
existem em vista das suas operações, conforme diz Aristóteles, teria em vão Cristo a alma intelectiva, se
não inteligisse por ela. O que constitui a ciência criada. — Terceiro, porque, há uma ciência criada
própria da natureza da alma humana, e é a pela qual naturalmente conhecemos os primeiros princípios;
pois, aqui tomamos a palavra ciência em sentido lato, por qualquer conhecimento do intelecto humano.
Ora, nada de natural faltou a Cristo, porque assumiu toda a natureza humana, como dissemos. Por isso,
no Sexto Sínodo foi condenada a opinião dos que negavam tivesse Cristo duas ciências ou duas
sabedorias.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo conhecia todas as coisas pela sua ciência divina
por operação incriada, que é a essência mesma de Deus; pois, inteligir é a própria substância de Deus,
como o prova Aristóteles. Por onde, esse ato, sendo de outra natureza, não podia pertencer à alma
humana de Cristo. Se, pois, a alma de Cristo não tivesse outra ciência, além da divina, nada conheceria.
E então teria sido assumida em vão, pois, as coisas existem em vista das suas operações.

RESPOSTA À SEGUNDA. — De duas luzes consideradas da mesma ordem, a menor é ofuscada pela
maior; assim, a luz do sol ofusca a da candeia, pertencendo uma e a outra à ordem do corpo que
iluminam. Mas, se considerarmos a maior como a que ilumina e a menor com a iluminada, o menor
lume não é ofuscado pelo maior, mas ao contrário, é aumentado; assim a luz do ar não é ofuscada pela
do sol. E, deste modo, a luz da ciência não é ofuscada, mas antes, mais se esclarece na alma de Cristo,
pelo lume da ciência divina, que é a luz verdadeira, que alumia a todo o homem que vem a este, mundo
no dizer do Evangelho.

RESPOSTA À TERCEIRA. — Quanto às coisas unidas, tem ciência, em Cristo, tanto a natureza divina
como a humana; assim que, por causa da união, pela qual o Deus e o homem tem a mesma hipóstase, o
que é de Deus se atribui ao homem e o que é do homem se atribui a Deus, como se disse. Mas, quanto à
união mesma, não podemos admitir em Cristo nenhuma ciência. Pois aquela união refere-se ao ser
pessoal; a ciência, porém, não convém à pessoa senão em razão de alguma natureza.

## Art. 2 — Se Cristo teve a ciência dos santos ou dos que gozam da visão beatífica.
O segundo discute-se assim. — Parece que Cristo não teve a ciência dos santos ou dos que gozam da
visão beatífica.
1 - Pois, a ciência dos santos é uma participação do lume divino, segundo a Escritura: No leu lume
veremos o lume. Ora, Cristo não tinha o lume divino corno participado, mas tinha a própria divindade
emanente em si substancialmente, conforme o diz o Apóstolo: Nele habita toda a plenitude da
divindade corporalmente. Logo, Cristo não tinha a ciência dos santos.

2. — Demais. - A ciência dos santos os torna santos, segundo o Evangelho: A vida eterna consiste em
que eles conheçam por um só verdadeiro Deus a ti e a Jesus Cristo, que tu enviaste. Ora, o homem
Cristo foi santo desde que foi unido pessoalmente a Deus, segundo a Escritura: Bem-aventurado o que
elegeste e tomaste para o teu serviço. Logo, não devemos atribuir a Cristo a ciência dos santos.

3. Demais. — Ao homem compete uma dupla ciência, a que lhe é conforme e a que lhe é superior à
natureza. Ora, a ciência dos santos, consistente na visão divina, não é conforme à natureza do homem,
mas lhe é superior. Mas, Cristo teve outra ciência sobrenatural muito mais elevada, que era a ciência
divina. Logo, não era necessário tivesse Cristo a ciência dos santos.
Mas, em contrário. — A ciência dos santos consiste na visão ou no conhecimento de Deus. Ora, Cristo
conheceu a Deus plenamente, mesmo enquanto homem, segundo o Evangelho. Mas eu o conheço e
guardo a sua palavra. Logo, Cristo teve a ciência dos santos.

SOLUÇÃO. — O potencial se reduz ao atual pelo que já é atual. Assim, há-de ser quente o que aquece.
Ora, o homem tem em potência a ciência dos santos, consistente na visão de Deus, a qual se ordena
como ao fim; pois, é uma criatura racional capaz desse conhecimento dos bem-aventurados, como feito
que é à imagem de Deus. Ora, a esse fim da beatitude os homens são levados pela humanidade de
Cristo, segundo o Apóstolo: Convinha que aquele para quem são todas as coisas e por quem todas
existem, havendo de levar muitos filhos à glória, consumasse pela paixão ao autor da salvação deles.
Logo, era necessário que o conhecimento consistente na visão beatífica de Deus, excelentissimamente o
tivesse o homem Cristo, pois, sempre e necessariamente a causa é superior ao causado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A divindade se uniu à humanidade de Cristo,
pessoalmente; não pela essência ou pela natureza, mas com a unidade da pessoa permanece a distinção
das naturezas. Por onde, a alma de Cristo, que faz parte da natureza humana, teve, por um lume
participado da natureza divina, a ciência perfeita dos santos, pela qual veem a essência de Deus.

RESPOSTA À SEGUNDA. — Em virtude mesmo da união, o homem Cristo é santo por santidade incriada,
assim como é Deus pela união. Mas, além da beatitude incriada, era necessário que a natureza humana
de Cristo tivesse uma certa beatitude criada, pela qual a sua alma fosse constituída no fim último da
natureza humana.

RESPOSTA À TERCEIRA. — A visão ou a ciência dos santos é de certo modo superior à natureza da alma
racional; isto é, enquanto não pode esta chegar, pelas suas próprias forças, a ela. Mas, num outro
sentido, essa ciência lhe é natural, isto é, enquanto que por Sua natureza, é capaz dela, por ser a alma
racional feita à imagem de Deus, como se disse. Mas, a ciência incriada é, de todos os modos, superior à
natureza da alma humana.

## Art. 3 — Se em Cristo há uma outra ciência infusa além da ciência beatífica.
O terceiro discute-se assim. — Parece que em Cristo não há outra ciência infusa, além da beatífica.

1. — Pois, qualquer ciência criada está para a ciência da visão beatífica como o imperfeito, para o
perfeito. Ora, a presença do conhecimento perfeito exclui a do imperfeito, assim como a visão
manifesta face a face exclui a enigmática, da fé, segundo se lê no Apóstolo. Ora, como Cristo tinha a
ciência da visão beatífica, conforme dissemos, parece que não podia ter outra ciência, infusa.

2. Demais. — O modo imperfeito do conhecimento dispõe para o perfeito; assim a opinião, fundada no
silogismo dialético, dispõe para a ciência, fundada no silogismo demonstrativo. Ora, quem já tem a
perfeição não precisa de nenhuma disposição ulterior, assim como não há necessidade de movimento
quando o termo foi atingido. Mas, qualquer conhecimento criado, estando para o da visão beatífica
como o imperfeito, para o perfeito e como a disposição, para o termo, parece que a Cristo não lhe era
necessário nenhum outro conhecimento, desde que tinha o da visão beatífica.

3. Demais. — Assim como a matéria corpórea está em potência para a forma sensível assim o intelecto
possível para a forma inteligível. Ora, a matéria corpórea não pode receber simultaneamente duas
formas sensíveis - mais perfeita uma e outra menos perfeita. Logo, nem a alma pode simultaneamente
ter duas ciências, mais perfeita uma e outra menos perfeita. Donde se conclui o mesmo que antes.
Mas, em contrário, o Apóstolo: Em Cristo estão encerrados todos os tesouros da sabedoria e da ciência.

SOLUÇÃO. — Como dissemos, convinha que a natureza humana assumida pelo Verbo não fosse
imperfeita. Ora, todo o potencial é imperfeito, que não for reduzido ao ato. Mas, o intelecto humano é
potencial em relação a todos os inteligíveis; reduz-se ao ato porém pelas espécies inteligíveis que lhe
são umas formas completivas conforme resulta do que já dissemos. Logo, devemos atribuir a Cristo uma
ciência infusa enquanto que, pelo Verbo de Deus, na alma de Cristo, pessoalmente unida ao Verbo, se
lhe imprimiram as espécies inteligíveis relativas a tudo o para o que o intelecto possível é potencial.
Assim como também, pelo Verbo de Deus foram impressas as espécies inteligíveis na mente angelica, no
princípio da criação das coisas, conforme diz Agostinho. Por onde, como os anjos, segundo o mesmo
Agostinho, tem duplo conhecimento — Um matutino, pelo qual conhecem as coisas no Verbo; e outro,
vespertino pelo qual as conhecem nas suas naturezas próprias, por meio das espécies neles infusas,
assim também, além da ciência incriada, tem a alma de Cristo a ciência da visão beatífica, pela qual
conhece o Verbo e as coisas, nele; e a ciência infusa ou inata, pela qual as conhece em a natureza
própria delas, por meio das espécies inteligíveis proporcionadas à mente humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A visão imperfeita da fé inclui por essência o oposto à
visão manifesta, por ser da natureza da fé ter por objeto o invisível, como se disse na Segunda Parte. Ao
passo que o conhecimento por meio das espécies infusas nada inclui de oposto ao conhecimento
beatífico. Por onde, não há paridade em ambos os casos.

RESPOSTA À SEGUNDA. — A disposição se relaciona com a perfeição, de dois modos; como a via
conducente a ela e como um efeito dela procedente. Assim, pelo calor a matéria se dispõe a receber a
forma do fogo, cuja presença não faz cessar o calor, que permanece, quase como um efeito de tal
forma. Semelhantemente, a opinião causada pelo silogismo dialético é via à ciência adquirida por
demonstração, com cuja aquisição pode coexistir o conhecimento pelo silogismo dilético, como uma
consequência da ciência demonstrativa, que é um conhecimento pela causa, pois, quem conhece a
causa pode também, por ela, com maior razão, conhecer os sinais prováveis, dos quais procede o
silogismo dialético. Do mesmo modo, em Cristo, com a ciência da beatitude coexiste a ciência infusa,
não como via para a beatitude, mas como confirmada por ela.

RESPOSTA À TERCEIRA. — O conhecimento da beatitude não se opera por uma espécie que seja
semelhança da essência divina ou das coisas que na espécie divina se conhecem, como resulta do que
foi dito na Primeira Parte. Mas tal conhecimento atinge a própria essência imediatamente, por estar a
essência divina unida à alma beata como o inteligível ao inteligente. Ora, a essência divina é uma forma
que excede à proporção de qualquer criatura. Por onde, nada impede coexistirem, na alma racional,
com essa forma sobreexcedente, espécies inteligíveis proporcionadas à sua natureza.

## Art. 4 — Se Cristo tinha alguma ciência experimental adquirida.
O quarto discute-se assim. — Parece que Cristo não tinha nenhuma ciência experimental adquirida.
1 — Pois, tudo o conveniente a Cristo ele o tinha excelentissimamente. Ora, Cristo não tinha uma
ciência adquirida excelentíssima, pois, não se aplicou ao estudo das letras pelo qual se adquire
perfeitissimamente a ciência. Assim, refere o Evangelho: E admiravam-se os Judeus dizendo — Como
sabe este letras, não as tendo estudado? Logo, parece que Cristo não tinha nenhuma ciência adquirida.
2 Demais. — Ao completo nada se lhe pode acrescentar. Ora, a potência da alma de Cristo ficou
completada pelas espécies inteligíveis infundidas por Deus, como se disse. Logo, não se lhe podiam
acrescentar à alma quaisquer espécies adquiridas.
Demais. — Quem já possui o hábito da ciência não adquire novos hábitos pelo que conhece por meio
dos sentidos; porque então nele coexistiriam duas formas da mesma espécie; mas, o hábito que havia
antes é confirmado e aumentado. logo, como Cristo tinha o hábito da ciência infusa, parece que, pelo
que percebia pelos sentidos, não adquiriu nenhuma outra ciência.
Mas, em contrário, o Apóstolo: Sendo Filho de Deus, aprendeu a obediência pelas coisas que padeceu;
isto é, que experimentou, comenta a Glosa. Logo, Cristo teve uma ciência experimental, que é a ciência
adquirida.

SOLUÇÃO. — Como do sobredito resulta, nada do que Deus infundiu em nossa natureza faltou à
natureza humana assumida pelo Verbo de Deus. Ora, é manifesto que em a natureza humana Deus não
somente infundiu o intelecto possível, mas também o intelecto agente. Donde necessariamente se
conclui, que a alma de Cristo não somente tinha o intelecto possível, mas também o agente. Se pois, nos
outros seres, Deus e a natureza nada fizeram em vão, como diz o Filósofo, com muito maior razão nada
fez de vão na alma de Cristo. Ora, é vão o que não tem uma operação própria, no dizer de Aristóteles;
pois, todo ser é feito para as suas operações, como também ele o diz. Ora, a operação própria do
intelecto agente é tornar as espécies inteligíveis em ato, abstraindo-as dos fantasmas, donde o dizer-se
que o intelecto agente é o que tem o poder de fazer todas as coisas. Donde é necessário concluir-se que
em Cristo havia certas espécies inteligíveis, pela ação do intelecto agente recebidos no seu intelecto
possível. O que é ter tido ele uma ciência adquirida, a que certos chamam experimental.
Portanto, embora noutro lugar tivesse escrito diferentemente, devemos dizer que Cristo teve uma
ciência adquirida. A qual é propriamente uma ciência ao modo humano, não só por parte do sujeito
recipiente, mas ainda pelo lado da causa agente. Pois, atribuímos a Cristo essa ciência segundo o lume
do intelecto agente, conatural à alma humana. Ao passo que a ciência infusa lhe é atribuída segundo o
lume infuso do alto, e esse modo de conhecer é proporcionado à natureza angélica. Mas a ciência da
beatitude, pela qual é vista a essência mesma de Deus, é própria e conatural só a Deus, como dissemos
na Primeira Parte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Há dois modos de se adquirir a ciência: a invenção e a
disciplina. A invenção é o modo principal; o pela disciplina é secundário. Donde o dizer Aristóteles:
Ultimo é o que sabe tudo por si mesmo; bom, porém, quem aproveita tudo que lhe ensinam. Por isso, a
Cristo antes cabia ter a ciência adquirida pela invenção do que pela disciplina, sobretudo porque Deus o
ia dar a todos como Doutor, segundo a Escritura: Alegrai-vos no Senhor vosso Deus, porque ele vos deu
um doutor que ensinará a justiça.

RESPOSTA À SEGUNDA. — A inteligência é capaz de uma dupla contemplação. Uma, do que lhe é
superior. E por esta a alma de Cristo tinha a plenitude que lhe dava a ciência infusa. A outra é do que lhe
é inferior, isto é, dos fantasmas, cuja natureza é mover a inteligência humana por virtude do intelecto
agente. Ora, era necessário, que também por essa contemplação a alma de Cristo tivesse a plenitude da
ciência. Não que a primeira plenitude não bastasse por si mesma, à inteligência humana; mas porque
lhe era necessária a perfeição também relativamente aos fantasmas.

RESPOSTA À TERCEIRA. — Uma é a natureza do hábito adquirido e outra, a do hábito infuso. Assim, o
hábito da ciência se adquire pela relação da alma humana com os fantasmas; por isso, ao mesmo ponto
de vista não pode um hábito ser repetidamente adquirido. Mas, o hábito da ciência infusa tem outra
natureza, como descendo de um superior, para a alma e não segundo uma proporção com os
fantasmas. Logo, não há paridade entre um e outro hábito.