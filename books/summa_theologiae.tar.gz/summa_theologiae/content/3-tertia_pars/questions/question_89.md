# Questão 89: Da recuperação das virtudes pela penitência.
Em seguida devemos tratar da recuperação das virtudes pela penitência.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se as virtudes se recuperam pela penitência.
O primeiro discute-se assim. — Parece que as virtudes não se recuperam pela penitência.

1. — Pois, as virtudes perdoadas pela penitência não se poderiam recuperar se a penitência não
causasse as virtudes. Ora, a penitência, sendo uma virtude, não pode ser causa de todas; sobretudo por,
serem certas virtudes, como a fé, a esperança e a caridade, conforme foi dito; naturalmente anteriores à
penitência. Logo, não se recuperam pela penitência.

2. Demais. — A penitência consiste em certos atos do penitente. Ora, as virtudes gratuitas não são
causadas pelos nossos atos; pois, como diz Agostinho, as virtudes Deus as faz nascerem em nós, sem
nossa cooperação. Logo, parece que pela penitência não recuperamos as virtudes.

3. Demais. — O virtuoso pratica atos virtuosos sem dificuldades e com prazer; por isso diz o Filósofo,
que não é justo quem não se compraz em atos justos. Ora, muitos penitentes ainda praticam com
dificuldades atos virtuosos. Logo, pela penitência não recuperamos as virtudes.
Mas, em contrário, como lemos no Evangelho, o pai mandou ao filho penitente se lhe desse o seu
primeiro vestido, que, segundo Ambrósio, representa o manto da sabedoria, que é acompanhada
simultaneamente por todas as virtudes, segundo aquilo da Escritura: Ensina a temperança e a prudência
e a justiça e a fortaleza, que é o mais útil que há na vida para os homens. Logo, pela penitência
recuperamos todas as virtudes.

SOLUÇÃO. — Pela penitência, como dissemos, remitem-se os pecados. Ora, a remissão dos pecados não
pode ser senão pela infusão da graça. Donde se conclui que pela penitência se nos infunde a graça. Ora,
da graça resultam todas as virtudes gratuitas, assim como da essência da alma fluem todas as potências,
conforme estabelecemos na Segunda Parte. Donde se conclui que pela penitência recuperamos todas as
virtudes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A penitência é a causa de recuperamos as virtudes do
mesmo modo pelo qual é a causa da graça, como já dissemos. Ora, é causa da graça enquanto
sacramento: pois, como virtude é, antes, efeito da graça. Por onde, não é necessário que a penitência,
enquanto virtude, seja a causa de todas as outras virtudes; mas, que o hábito da penitência seja causado
simultaneamente com os hábitos das outras virtudes pelo sacramento da penitência.

RESPOSTA À SEGUNDA. — Os atos humanos constituem a matéria do sacramento da penitência; mas o
princípio formal deste sacramento depende do poder das chaves. Por onde, o poder das chaves é o que
causa efetivamente a graça e as virtudes; mas instrumentalmente. E o ato primeiro do penitente se
comporta como disposição última para conseguir a graça, isto é, a contrição; ao passo que os outros
atos consequentes à penitência já procedem da graça e das virtudes.

RESPOSTA À TERCEIRA. — Como dissemos, às vezes depois do primeiro ato da penitência, que é a
contrição, permanecem certos resquícios dos pecados, isto é, disposições causadas pelos anteriores atos
pecaminosos, donde resulta para o penitente uma certa dificuldade em praticar obras virtuosas. Mas,
no concernente à inclinação mesma da caridade e das outras virtudes, o penitente pratica atos virtuosos
com prazer e sem dificuldade. Assim, o homem virtuoso pode, por acidente, experimentar dificuldade
na prática de atos virtuosos, por causa do sono ou de alguma disposição do corpo.

## Art. 2 — Se depois da penitência recuperamos o mesmo grau de virtude que antes tínhamos.
O segundo discute-se assim. Parece que depois da penitência recuperamos o mesmo grau de virtude
que antes tínhamos.

1. — Pois, diz o Apóstolo: Aos que amam a Deus todas as coisas lhe contribuem para seu bem. Ao que
diz a Glosa de Agostinho, ser isso de tal modo verdadeiro, que se qualquer desses eleitos se desviarem e
saírem do bom caminho, Deus lhes faz esses mesmos desvios redundarem úteis ao progresso no bem.
Ora, tal não se daria se não recuperássemos o mesmo grau de virtude que antes tínhamos.

2. Demais. — Ambrósio diz: A penitência é uma ótima coisa, que reduz à perfeição todos os nossos
defeitos. Ora, não seria tal, se não recuperássemos depois delas as nossas virtudes no mesmo grau que
antes tínhamos.

3. Demais. — Aquilo da Escritura: — E da tarde e da manhã se fez o dia primeiro, diz a Glosa: A luz
vespertina é a que perdemos pela nossa queda; a matutina é a que nos ilumina a ressurreição. Ora, a luz
matutina é mais intensa que a vespertina. Logo, depois da penitência ressurgimos com maior graça ou
caridade que antes tínhamos. O que também resulta das palavras do Apóstolo: onde abundou o pecado
superabundou a graça.
Mas, em contrário. — A caridade progressiva ou a perfeita é maior que a caridade incipiente. Ora, às
vezes decaímos da caridade progressiva para recomeçarmos pela caridade incipiente. Logo, sempre
ressurgimos com menor virtude.

SOLUÇÃO. — Como dissemos, o movimento do livre arbítrio, suposta pela justificação do ímpio, é uma
disposição última para a graça; por onde, a infusão da graça é concomitante com esse referido
movimento do livre arbítrio, como estabelecemos na Segunda Parte. E nesse movimento está
compreendido o ato de penitência, como dissemos. Ora, é manifesto que as formas suscetíveis de mais
e de menos, tornam-se mais intensas ou mais remissas, segundo a disposição diversa do sujeito,
conforme o mostramos na Segunda Parte. Donde vem que conforme o movimento do livre arbítrio, na
penitência, é mais intenso ou mais remisso assim é maior ou menor a graça alcançada pelo penitente.
Pode dar-se porém as vezes, que a intensidade do movimento da penitência seja proporcionado a uma
graça maior que o era aquela donde o pecador decaiu pelo seu pecado; outras vezes pode ser
proporcional a uma graça igual; enfim, outras, a uma menor. Por isso o penitente ora ressurge com
maior graça que primeiro tivera; ora, com graça igual; e ora, enfim, com menor. E o mesmo passa com
as virtudes resultantes da graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nem em todos os que amam a Deus contribui para o
bem o fato de decaírem do amor de Deus pelo pecado. E isso bem o demonstram os que caem e nunca
mais se levantam; ou se levantam é para cair de novo. Só contribui para os que por desígnio divino são
chamados à santidade, isto é, os predestinados, cujas quedas são afinal seguidas da ressurreição. Assim,
redundam-lhes em bem essas quedas, não porque sempre ressurjam em maior graça, mas numa graça
mais permanente. Não, certo, da parte da graça, pois, quanto maior é a graça mais permanente é em si
mesma; mas da parte mesma deles, que tanto mais estavelmente permanecer em graça, quanto mais
cautos são e humildes. Por isso a Glosa ao mesmo lugar acrescenta, que progridem no bem, os que
caem, por voltarem mais humildes e se tornarem mais experimentados.

RESPOSTA À SEGUNDA. — A penitência, em si mesma, tem a virtude de reparar todas as deficiências,
em vista, da perfeição, e mesmo de promover a um estado ulterior. Mas isso fica as vezes impedido da
nossa parte, que nos movemos para Deus e detestamos o pecado de modo mais remisso. Assim
também no batismo, certos adultos alcançam maior ou menor graça, conforme as disposições diversas
em que se encontram.

RESPOSTA À TERCEIRA. — Essa assimilação de uma e outra graça à luz vespertina e matutina se funda
na semelhança de ordem; porque à luz vespertina seguem-se as trevas da noite, e a luz do dia sucede à
luz matutina; mas não visa a fazer uma comparação com os graus da graça. E também essas palavras do
Apóstolo entendem da graça de Cristo, que supera toda a multidão dos pecados humanos. Não é porém
verdade, em relação a todos, que quanto mais abundantemente pequem tanto mais abundante graça
consigam; pesada a quantidade da graça habitual. Mas a graça é superabundante quanto à sua natureza
mesma, porque tanto mais grátis é o benefício do perdão quanto é conferido a um maior pecador. —
Embora às vezes os que pecaram muito também choram mais os seus pecados e alcançam assim um
hábito mais abundante de graça e de virtudes, como foi o caso da Madalena.
Quanto ao objetado em contrário — devemos responder que, num mesmo sujeito, a graça do progresso
é maior que a do começo; mas em pessoas diversas não é necessariamente assim. Pois, pode uma
começar tendo maior graça que tem outra já no estado de progresso. Assim, diz Gregório: Que os
homens dos tempos atuais e os do futuro saibam todos de quão grande perfeição, Bento, desde criança,
recebeu a graça da conversão.

## Art. 3 — Se pela penitência recobramos a nossa anterior dignidade.
O terceiro discute-se assim. — Parece que pela penitência não recobramos a nossa anterior dignidade.

1. — Pois, aquilo da Escritura — A virgem de Israel caiu — diz a Glosa: Não nega que ressurja a virgem,
mas que possa ressurgir; pois a ovelha que uma vez se transviou, embora reconduzida aos ombros do
Pastor, não ascende contudo a uma tão grande glória, como a que nunca aberrou. Logo, pela penitência
não recobramos a nossa anterior dignidade.

2. Demais. — Jerônimo diz: Os que não conservarem a dignidade do grau da sua vida divina contentem-
se com salvar a alma; pois, retornar ao grau anterior é difícil. E Inocêncio Papa (I) diz, que os cânones
constituídos em Nicéia excluem os penitentes, mesmo dos ínfimos graus do clericato. Logo, pela
penitência não recobramos a nossa dignidade anterior.

3. Demais. — Antes de pecarmos podemos ascender a um grau mais elevado. Mas isso não é dado ao
penitente, depois do pecado. Assim, diz a Escritura: Os levitas que se apararam longe de mim, nunca se
achegarão a mim para fazerem a função do sacerdócio. E uma disposição do concilio Hilerdense
determina: Os que servem aos santos altares se forem vítimas da lamentável fragilidade da carne e, os
olhos postos em Deus, fizerem penitência, recobrem os lugares dos seus ofícios, mas não possam ser
promovidos a mais altas dignidades. Logo, pela penitência não recobramos a nossa anterior dignidade.
Mas, em contrário, como se lê na mesma distinção, Gregório, escrevendo a Secundino, diz: Depois de ter
dado a devida satisfação, permitimos que possa, um readquirir as suas honras. E o concilio Agatense
dispõe: Os clérigos contumazes, conforme o permitir a ordem da dignidade, sejam corrigidos pelo bispo;
mas de modo que, quando emendados pela penitência, recobrem o grau da sua dignidade.

SOLUÇÃO. — Pelo pecado perde o homem uma dupla dignidade — uma relativa a Deus; a outra, relativa
à Igreja. Ora, relativamente a Deus, perde duas dignidades. — Uma principal, pela qual era contado
entre os filhos de Deus, em virtude da graça. E esta dignidade a recupera pela penitência. O que é
significado pelo filho pródigo, ao qual arrependido o pai mandou restituir o seu primeiro vestido, o anel
e os sapatos. — A outra dignidade que perde, e essa secundária, é a inocência. Dela, como lemos no
mesmo lugar, se gloriava o filho mais velho, dizendo: Há tantos anos que te sirvo sem transgredir
mandamento algum teu. E tal dignidade o penitente não na pode recuperar. Mas as vezes adquire uma
outra maior, conforme o diz Gregório: Os que refletem na sua aberração de Deus, compensam suas
perdas precedentes com os lucros subsequentes. Maior alegria por isso causam ao céu, assim como
também o chefe, no combate, mais ama o soldado que, voltando, depois de ter fugido, ataca o inimigo
mais impetuosamente, que o que nunca voltou as costas mas também nunca lutou com coragem. A
dignidade eclesiástica perde-a o clérigo pelo pecado, se se tornou indigno do exercício dela. E essa não
na pode recuperar. — Primeiro, se não fizer penitência. Por isso Isidoro escreve como lemos na referida
distinção: Os cânones ordenam que recuperem os graus que ocupavam, os que deram a satisfação da
penitência, ou fizeram uma condigna confissão dos pecados. Mas, ao contrário, os que não se emendam
do vício da sua corrupção, não recuperem o grau das dignidades que tinham, nem a graça da comunhão.
— Segundo, se fizer com negligência a penitência. Donde o dizer-se na mesma distinção: Quando esses
clérigos penitentes não derem quaisquer mostras de humilde compunção, de nenhuma assiduidade na
oração, de nenhuma prática do jejum ou de leituras piedosas, não podemos prever a negligência com
que, se as recobrarem, exercerão as suas primitivas dignidades. — Terceiro, se cometer algum pecado
que implique irregularidade. Por isso, na mesma distinção, dispõe um cânone de um concílio convocado
pelo Papa Martinho: Quem desposar uma viúva, ou, mulher abandonada pelo marido, não seja admitido
ao clericato. Se nele se intrometeu subrepticiamente, seja expulso. Semelhantemente, quem, depois do
batismo, for réu de homicídio por ato, por conselho ou defesa do assassino. Isto porém não é em razão
do pecado, mas da irregularidade. — Quarto, por causa do escândalo. Por isso lemos na mesma
distinção: Os surpreendidos ou apanhados publicamente na prática do perjúrio, do furto ou da
fornicação ou de outros crimes, decaiam das suas dignidades, segundo o estatuído pelos sagrados
cânones. Pois, seria escândalo para o povo de Deus ter essas pessoas como superiores. Os que porém se
confessarem em particular a um sacerdote de terem cometido esses pecados às ocultas, se tratarem de
as expiar por jejuns, esmolas, vigílias e santas práticas, a esses também, conservadas as suas dignidades
próprias, seja prometida a esperança do perdão da misericórdia de Deus. E ainda: Se os crimes irrogados
não foram estabelecidos por uma sentença judicial ou não são notórios de nenhum outro modo, salvo
os homicidas, não podem, depois da penitência, ser afastados do exercício das ordens já recebidas ou de
as receberem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O que se dá com a recuperação da virgindade também
se dá com a da inocência, concernente à dignidade secundária relativamente a Deus.

RESPOSTA À SEGUNDA. — Com as palavras citadas, Jerônimo não quer dizer que é impossível, mas
difícil, recuperarmos, depois do pecado, a nossa primitiva dignidade. Porque isto não é concedido senão
ao perfeito penitente, como se disse. — Quanto às prescrições dos cânones, que parece proibirem essa
concessão, responde Agostinho escrevendo a Bonifácio: Não é porque desesperasse de poder perdoar,
mas pelo rigor da sua disciplina, que a Igreja proibiu receber o clericato, a ele voltar ou nele
permanecer, a quem fez penitência de algum crime. O contrário seria pôr em discussão o poder das
chaves dado à Igreja e do qual foi dito: Tudo o que tiverdes desatado na terra será desatado no céu. E
depois acrescenta: Assim, o santo rei Davi fez penitência dos seus crimes e contudo permaneceu na sua
dignidade. E S. Pedro fez profunda penitência de ter negado ao Senhor, derramando amaríssimas
lágrimas; e contudo permaneceu Apóstolo. Mas nem por isso julguemos supervacâneo o estudo
daqueles que, mais tarde, aumentaram as humilhações da penitência, quando já isso nenhum
detrimento causava à penitência. Tinham, como creio aprendido pela experiência que o apego ao poder
das dignidades tornava, fictícia a penitência de certos pecadores.

RESPOSTA À TERCEIRA. — E essa disposição se entende dos que fazem penitência pública e não podem
por isso ser alçados depois a uma dignidade maior. Assim também Pedro, depois da negação, foi
constituído pastor das ovelhas de Cristo, como lemos no Evangelho. Ao que diz Crisóstomo: Pedro,
depois da negação e da penitência, ficou com maior confiança em Cristo. Pois, aquele que na Ceia não
ousava interrogar e pediu a João que o fizesse em seu lugar, a esse foi confiada depois a chefia sobre
seus irmãos, e não só não cometeu a outrem o interrogar o que lhe concernia, mas, quanto ao mais, ele
próprio interrogou o Mestre em nome de João.

## Art. 4 — Se as obras virtuosas feitas com caridade, podem ser mortificadas.
O quarto discute-se assim. — Parece que as obras virtuosas feitas com caridades não podem ser
mortificadas.

1. — Pois, o não existente não é susceptível de qualquer mudança. Ora, morrer é passar da vida para a
morte. Logo, como as obras virtuosas, depois de feitas, já não existem, parece que não podem já ser
mortificadas.

2. Demais. — Pelas obras virtuosas feitas com caridade merecemos a vida eterna. Ora, subtrair o prêmio
a quem o merece é injustiça, de que Deus não é capaz. Logo, não é possível as obras virtuosas feitas com
caridade serem mortificadas pelo pecado subsequente.

3. Demais. — O mais forte não pode ser destruído pelo mais fraco. Ora, as obras de caridade são mais
fortes que quaisquer pecados; pois, como diz a Escritura, a caridade cobre todos os delitos. Logo, parece
que as obras feitas com caridade não podem ser mortificadas pelo pecado mortal.
Mas, em contrário, a Escritura: Se o justo se apartar da sua justiça, de nenhuma das obras de justiça que
tiver leito se fará memória.

SOLUÇÃO. — Os seres vivos perdem pela morte as suas operações vitais. Por isso, em virtude de uma
certa semelhança, dizemos que estão mortificadas as coisas impedidas de produzir o seu efeito ou
operação própria. Ora, o efeito das obras virtuosas, feitas com caridade, é levar à vida eterna. E esta fica
impedida pelo pecado mortal subsequente, que priva da graça. E assim, dizemos que as obras feitas com
caridade são mortificadas pelo pecado mortal subsequente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como as obras pecaminosas passam em ato, mas
ficam em reato, assim as obras feitas com caridade, depois de passadas em ato, permanecem pelo
mérito na aceitação de Deus. E sendo assim, são mortificadas, enquanto ficamos impedidos de obter a
recompensa delas.

RESPOSTA À SEGUNDA. — Sem injustiça podemos ficar privados das recompensas que merecemos,
quando delas nos tornamos indignos pela culpa subsequente. Pois, o que já recebemos as vezes
justamente o perdemos, por nossa culpa.

RESPOSTA À TERCEIRA. — Não é pelo poder das obras pecaminosas que são mortificadas as obras
anteriormente feitas com caridade; mas, pela liberdade da vontade, em virtude da qual podemos decair
do bem para o mal.

## Art. 5 — Se as obras mortificadas pelo pecado revivem pela penitência.
O quinto discute-se assim. — Parece que as obras mortificadas pelo pecado não revivem pela
penitência.

1. — Pois, assim como pela penitência subsequente se perdoam os pecados passados, assim também
pelo pecado subsequente são mortificadas as obras anteriormente feitas com caridade. Ora, os pecados
perdoados pela penitência não tornam, como se disse. Logo, parece que também as obras mortificadas,
pela caridade não revivem.

2. Demais. — Dizemos que as obras são mortificadas, por semelhança com os animais que morrem
como se disse. Ora, o animal morto não pode voltar de novo à vida. Logo, nem as obras mortificadas
podem de novo reviver pela penitência.

3. Demais. — As obras feitas com caridade merecem a glória conforme a intensidade da graça ou da
caridade. Ora, pode dar-se que, pela penitência, retornemos a um estado de menor graça ou caridade.
Logo, não conseguiremos a glória relativa ao mérito das obras anteriores. E assim parece, que as obras
mortificadas pelo pecado não revivem.
Mas, em contrário, aquilo da Escritura — Eu vos recompensarei os anos, cujos frutos comeu o
gafanhoto, diz a Glosa: Não sofrerei se perca a abundância que perdestes pela perturbação do vosso
espírito. Ora, essa abundância é o mérito das boas obras, perdido pelo pecado. Logo, pela penitência
revivem as obras meritórias anteriormente praticadas.

SOLUÇÃO. — Certos disseram, que as obras meritórias, mortificadas pelo pecado subsequente, não
revivem pela subsequente penitência, considerando que essas obras não permanecem de modo a
poderem ser vivificadas de novo. — Mas isto não as pode impedir de se vivificarem. Pois; a virtude de
conduzir à vida eterna, e que constitui a vida delas, não a têm só enquanto atualmente existem; mas
ainda depois de deixarem de existir em ato, enquanto permanecem na aceitação divina. Pois assim
permanecem, em si mesmas consideradas mesmo depois de mortificadas pelo pecado; porque Deus
sempre aceitará essas obras, como foram feitas, e os santos se regozijarão com elas, segundo aquilo da
Escritura: Guarda o que tens, para que ninguém tome a tua coroa. Mas o não serem eficazes, para
conduzir à vida eterna quem as fez, provém do impedimento do pecado sobreveniente que tornou o
autor delas indigno da vida eterna. Mas esse impedimento desaparece pela penitência, enquanto que
por ela se perdoam os pecados. Donde se conclui que as obras, primeiro mortificadas, recuperam pela
penitência a eficácia de conduzir o seu autor a vida eterna, e isso é reviverem. Por onde é claro que as
obras mortificadas revivem pela penitência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — — As obras do pecado ficam em si mesmas apagadas
pela penitência; de modo que delas, pela misericórdia de Deus, não permanece nem a mancha nem o
reato. Ao contrário, as obras feitas com caridade não são mortificadas por Deus, mas lhe permanecem
na aceitação; encontram porém obstáculo da parte do homem, que as pratica. E assim, removido o
impedimento da parte do homem, autor delas, Deus dá da sua parte, o que essas obras mereciam.

RESPOSTA À SEGUNDA. — As obras feitas com caridade não são em si mesmas mortificadas como
dissemos; mas só pelo impedimento superveniente por parte do autor delas. Ora, os animais morrem
em si mesmos considerados, quando privados do princípio vital. Logo, o símile não colhe.

RESPOSTA À TERCEIRA. — O que pela penitência ressurge a um estado de menor caridade, alcança por
certo o prêmio essencial, conforme a intensidade da caridade em que vive. Terá porém alegria maior
com as obras feitas no estado da primeira caridade, que com as que praticou no estado ulterior — e isso
constitui um prêmio acidental.

## Art. 6 — Se pela penitência subseqüente também as obras mortas, isto é, não feitas com caridade, revivem.
O sexto discute-se assim. — Parece que pela penitência subsequente, mesmo as obras mortas, isto é,
não feitas com caridade, revivem.

1. — Pois, é mais difícil chegar a vida eterna o mortificado — o que nunca se dá na ordem da natureza —
que o ser vivificado o que nunca foi vivo — pois, de seres não vivos podem ser naturalmente gerados
certos seres vivos. Ora, as obras mortificadas revivem pela penitência, como se disse. Logo, e com maior
razão, as obras mortas podem reviver.

2. Demais. — Removida a causa, removido fica o efeito. Ora, a causa pela qual as obras pertencentes ao
gênero das boas obras, feitas sem caridade, não foram vivas, foi a falta da caridade e da graça. Ora, essa
falta desaparece pela penitência. Logo, pela penitência as obras mortas revivem.

3. Demais. — Jerônimo, comentando o lugar da Escritura — Semeaste muito, diz: Quando vires alguém
praticar, entre muitas obras pecaminosas, certas que são justas, não creias seja Deus tão injusto a ponto
de esquecer-se de umas poucas obras boas por causa de muitas más. Ora, isto sobretudo se dá quando
os males passados são apagados pela penitência. Logo, parece que pela penitência Deus remunera as
obras boas praticadas, antes da penitência, no estado de pecado; e isso é vivificá-las.
Mas, em contrário, diz o Apóstolo: Se eu distribuir todos os meus bens em sustento dos pobres e se
entregar o meu corpo para ser queimado se todavia, não tiver caridade, nada disto me aproveita. Ora,
assim não seria se ao menos fossem vivifica das pela penitência subsequente. Logo, a penitência não
vivifica as obras mortificadas.

SOLUÇÃO. — De dois modos podemos dizer que uma obra é morta. — Primeiro, efetivamente, isto é,
por ser causa da morte. E neste sentido dizemos que as obras do pecado são mortas, segundo aquilo do
Apóstolo: O sangue de Cristo limpará a nossa consciência das obras da morte. Ora, essas obras mortas a
penitência não as vivifica, mas antes as destrói; segundo ainda o Apóstolo, não lançando de novo o
fundamento da penitência das obras mortas. — Noutro sentido as obras mortas assim se chamam
privativamente, isto é, por carecerem da vida espiritual, procedente da caridade, pela qual a alma se nos
une com Deus, de qual vive, como o corpo, pela alma. E neste sentido também a fé sem a caridade se
chama morta, segundo a Escritura: A fé sem obras é morta. Também neste sentido todas as obras
genericamente boas, se forem feitas sem caridade, chamam-se mortas; isto é, por não procederem do
principio da vida; como se disséssemos que o som de uma citara da uma voz morta. Por onde, a
diferença entre obras de morte e de vida se funda na relação com o principio donde procedem. Ora, as
obras não podem resultar duas vezes do seu principio, porque passam e não podem tornar a ser
numericamente as mesmas. Por isso é impossível obras mortas tornarem a reviver pela penitência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na ordem natural, tanto os seres mortos como os
mortificados estão privados do princípio vital. Ora, as obras se chamam mortificadas, não relativamente
ao principio donde procederam, mas em relação a um impedimento intrínseco. Mortas porém se
chamam relativamente ao seu princípio. Logo, não colhe a comparação.

RESPOSTA À SEGUNDA. — As obras do gênero das boas, feitas sem caridade, chamam-se mortas por
falta da caridade e da graça, como seus principias. Ora, a penitência subsequente não faz com que
procedam desse tal princípio. Por isso, a objeção não colhe.

RESPOSTA À TERCEIRA. — Deus se lembra das boas obras que praticamos no estado de pecado; não
para as remunerar na vida eterna, o que só cabe às obras vivas, isto é, às feitas com caridade. Mas lhes
dá uma remuneração temporal. Assim, diz Gregório: Se o rico do Evangelho não tivesse feito algum bem
e não tivesse por ele recebido já em vida uma remuneração, não lhe diria de nenhum modo Abraão —
Recebeste bens em tua vida — Ou também podemos referir esse lembrar-se das boas obras no
abrandamento da condenação contra o pecador pronunciada. Donde o dizer Agostinho: Não podemos
dizer que fosse melhor ao cismático martirizado evitar todos os sofrimentos padecidos, negando a
Cristo. De modo que o lugar do Apóstolo — Se entregar o meu corpo para ser queimado, se todavia não
tiver caridade, de nada me aproveita — seja entendido como significando que nada aproveita para
alcançar o reino dos céus; mas que aproveita para abrandar os suplícios da condenação final.