# Questão 67: Dos ministros pelo quais se confere o sacramento do batismo.
Em seguida devemos tratar dos ministros pelos quais se confere o sacramento do batismo.
Nesta questão discutem-se oito artigos:

## Art. 1 — Se é do ofício do diácono batizar.
O primeiro discute-se assim. — Parece que é do ofício do diácono batizar.

1. — Pois o Senhor ordenou, por um mesmo preceito, pregar e batizar, como está no Evangelho: Ide e
ensinai a todas as gentes, batizando-as etc. Ora, é ofício do diácono evangelizar. Longo, parece que
também é do seu ofício batizar.

2. Demais. — Segundo Dionísio, purificar é do ofício do diácono. Ora, é sobretudo pelo batismo que nos
purificamos dos pecados segundo aquilo do Apóstolo: Purificando-a no batismo da água pela palavra da
vida. Logo, parece que batizar é ofício próprio do diácono.

3. Demais. — Lemos, de S. Lourenço, que, sendo diácono, batizava a muitos. Logo, parece ser do ofício
do diácono batizar.
Mas, em contrário, Gelásio Papa disse e está numa Decretal: Queremos que o diácono cumpra o seu
dever. E mais abaixo: Na ausência do bispo ou do presbítero não se atreva a batizar, salvo se, estando
este e aquele longe, a extrema necessidade o obrigue a fazê-lo.

SOLUÇÃO. — Assim como as propriedades e ofícios das ordens celestes se lhes deduzem dos nomes, no
dizer de Dionísio, assim também dos nomes das ordens eclesiásticas se pode deduzir o que a cada
ordem concerne. Ora, os diáconos são uns quase ministros, pois, não lhes incumbe conferir o
sacramento, principalmente e como por ofício próprio, mas assistir com o seu ministério os ministros
superiores, quando conferem o sacramento. E assim não cabe ao diácono, como por ofício próprio,
conferir o sacramento do batismo, mas assistir e ministrar aos maiores quando conferem esse e os
outros sacramentos. Por isso diz Isidoro: Aos diáconos pertence assistir e servir os sacerdotes em todas
as suas funções sacramentais, isto é, no batismo, no crisma, na patena e no cálice.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ao diácono pertence recitar o Evangelho na igreja e
prega-lo como catequista. Por isso diz Dionísio, que o diácono exerce o seu ofício sobre os impuros,
entre os quais coloca os catecúmenos. Ensinar porém e expor o Evangelho pertence propriamente ao
bispo, cujo ato é de aperfeiçoar, segundo Dionísio; e aperfeiçoar é o mesmo que ensinar. Donde não se
segue que aos diáconos pertença o ofício de batizar.

RESPOSTA À SEGUNDA. — Como diz Dionísio, o batismo não somente tem uma virtude purificativa, mas
também iluminativa. O que, pois, excede o ofício do diácono, a quem só pertence purificar — ou
afastando dos sacramentos os impuros, ou dispondo-os para os receberem.

RESPOSTA À TERCEIRA. — Sendo o batismo um sacramento necessário à salvação, é permitido aos
diáconos, em caso de urgência, batizar, na ausência de um sacerdote maior, como se deduz da
autoridade de Gelásio, supra-citada. E assim é que Lourenço, sendo diácono, batizava.

## Art. 2 — Se batizar é ofício dos presbíteros ou só dos bispos.
O segundo discute-se assim. — Parece que batizar não é ofício dos presbíteros, mas só dos bispos.

1. — Pois, como se disse, o senhor ordenou, por um mesmo preceito, ensinar e batizar. Ora, ensinar,
isto é, aperfeiçoar, é ofício do bispo, como está claro em Dionísio. Logo, também batizar é ofício próprio
só do bispo.

2. Demais. — Pelo batismo entramos a fazer parte do povo cristão, e permiti-lo é ofício só do chefe. Ora,
a chefia da Igreja pertence aos bispos, como o confirma a Glosa; além disso, eles estão em lugar dos
Apóstolos, dos quais diz a Escritura: Estabelece-los-ás príncipes sobre toda a terra. Logo, parece que
batizar é ofício só dos bispos.

3. Demais. — Isidoro diz: Ao bispo incumbe a consagração das basílicas, a unção do altar, a preparação
do crisma ele é quem distribui as ordens eclesiásticas e abençoa as virgens sagradas. Ora, o sacramento
do batismo é mais que tudo isso. Logo e com maioria de razão, parece que só o bispo tem o oficio de
batizar.
Mas, em contrário, Isidoro: É reconhecido que o batismo não foi confiado senão aos sacerdotes.

SOLUÇÃO. — Os sacerdotes são consagrados para celebrarem o sacramento do corpo de Cristo, como
dissemos. Pois, esse é o sacramento da unidade eclesiástica, segundo aquilo do Apóstolo: Nós todos
somos um pão e um corpo, nós todos que participamos de um mesmo pão e de um mesmo cálice. Ora,
o batismo nos faz participantes da unidade eclesiástica e portanto dá o direito de nos achegarmos à
mesa do Senhor. Por onde, assim como aos sacerdotes pertence consagrar a Eucaristia, para o que
principalmente são ordenados, assim o ofício próprio deles é batizar; pois, quem obra o todo deve
também nele dispor as partes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um e outro ofício - o de ensinar e o de batizar - O
Senhor cometeu aos Apóstolos, no lugar dos quais estão os bispos. Mas de modos diferentes. Assim, o
ofício de ensinar cristo lhes confiou, de maneira que o exercessem por si mesmos, como o
principalíssimo. Por isso os próprios Apóstolos disseram: Não é justo que nós deixemos a palavra de
Deus e que sirvamos às mesas. O ofício de batizar cometeu-o aos Apóstolos, mas para o exercerem por
meio de outros. Donde o dizer o Apóstolo: Não me enviou Cristo a batizar, mas a pregar o Evangelho. E
isto porque, para batizar em nada contribui o mérito e a sabedoria do ministro, dando-se o contrário
com o ensino, como do sobredito se colhe. - Em sinal também do que, nem o próprio Senhor batizou,
mas sim os seus discípulos, segundo refere o Evangelho. — Mas isso não exclui que os bispos possam
batizar, pois, o que pode a autoridade inferior pode também a superior. Assim, o Apóstolo diz no
mesmo lugar, que batizou a certos.

RESPOSTA À SEGUNDA. — Em toda república as funções menores são exercidas por funcionários
menores, sendo as maiores reservadas aos superiores, segundo aquilo da Escritura: Dêm-te conta do
que for de mais suposição e eles julguem somente os negócios menos graves. Por isso, aos chefes
menores da cidade compete governar o povo ínfimo; e aos supremos bispos o que atinente aos maiores.
Ora pelo batismo não alcançamos senão um lugar ínfimo entre o povo cristão. Portanto, batizar
pertence aos chefes menores da Igreja, isto é, aos presbíteros, que estão em lugar dos setenta e dois
discípulos de Cristo, como diz a Glosa.

RESPOSTA À TERCEIRA. — Como dissemos, o sacramento do batismo é de todos os mais necessários;
mas quanto à perfeição, há outros mais principais reservados aos bispos.

## Art. 3 — Se um leigo pode batizar.
O terceiro discute-se assim. — Parece que um leigo não pode batizar.

1. — Pois, batizar, como se disse, propriamente pertence à ordem sacerdotal. Ora, o próprio à ordem
não pode ser cometido a quem não na tem. Logo, parece que o leigo, não tendo ordem, não pode
batizar.

2. Demais. — É mais batizar que exercer os outros sacramentais do batismo, como catequizar, exorcizar
e benzer a água batismal. Ora, estas coisas não podem ser feitas pelos leigos, mas só pelos sacerdotes.
Logo e com maior razão, parece que os leigos não podem batizar.

3. Demais. — Assim como o batismo é necessário à salvação, assim também a penitência. Ora, o leigo
não pode absolver no foro da penitência. Logo, também não pode batizar.
Mas, em contrário, Gelásio Papa e Isidoro dizem: Batizar, em necessidade iminente, é muitas vezes
permitido aos leigos cristãos.

SOLUÇÃO. — A misericórdia daquele que quer que todos os homens se salvem pertence dar fácil
remédio em matéria necessária para a salvação. Ora, dentre todos os sacramentos, o mais necessário à
salvação é o batismo, pelo qual renascemos para a vida espiritual. Pois, as crianças não podem de outro
modo salvar-se; e aos adultos não é possível, por um meio diferente do batismo, conseguir o perdão
completo, quanto à culpa e quanto à pena. Por onde a fim de não nos vir a faltar um remédio tão
necessário, foi instituído que a água, a matéria do batismo fosse comum, de modo que esteja ao alcance
de qualquer; e também qualquer o seu ministro, ainda que não ordenado, a fim de não corrermos o
risco de não alcançarmos a nossa salvação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Batizar pertence à ordem sacerdotal segundo, uma
certa, conveniência e solenidade, que porém não é de necessidade para o sacramento. Portanto, se um
leigo batizar, mas não em artigo de necessidade, certamente peca, contudo confere o sacramento; nem
deve ser rebatizado quem ele batizou.

RESPOSTA À SEGUNDA. — Esses sacramentais do batismo pertencem-lhe à solenidade, mas não à
essência dele. Por isso não devem nem podem ser conferidos por um leigo, mas só pelo sacerdote, que
tem o poder de batizar solenemente.

RESPOSTA À TERCEIRA. — Como dissemos a penitência não é de tanta necessidade como o batismo;
pois, a contrição pode suprir a falta de absolvição sacerdotal, que não isenta totalmente da pena, nem
pode ser dada às crianças. Logo não é o mesmo caso do batismo, cujo efeito não pode ser suprido de
nenhum outro modo.

## Art. 4 — Se uma mulher pode batizar.
O quarto discute-se assim. — Parece que uma mulher não pode batizar.

1. — Pois, lemos no Concílio Cartaginêz: A mulher, embora douta e santa não tenha a ousadia de ensinar
a homens nas reuniões cristãs, nem de batizá-los. Ora, de nenhum modo é lícito as mulheres ensinarem
nessas reuniões, segundo aquilo do Apóstolo: É coisa indecente para uma mulher o falar na Igreja. Logo,
parece que nem de qualquer modo é lícito a uma mulher batizar.

2. Demais. — Batizar é função do prelado; por isso o batismo deve ser recebido dos sacerdotes com cura
de almas. Ora, não pode isso convir à mulher, segundo o Apóstolo: Eu não permito à mulher que ensine
nem que tenha domínio sobre o marido, senão que esteja em silêncio. Logo, uma mulher não pode
batizar.

3. Demais. — No renascimento espiritual a água exerce a função do ventre materno, como diz
Agostinho, a propósito daquilo de João: Porventura pode um homem tornar a entrar no ventre de sua
mãe e nascer outra vez? Ora, quem batiza exerce antes a função de pai, o que não cabe à mulher. Logo,
uma mulher não pode batizar.
Mas, em contrário, Urbano Papa: A consulta da tua Dilecção eis a minha resposta: é válido o batismo
conferido, sob instante necessidade, por uma mulher a uma criança, em nome da santa Trindade.

SOLUÇÃO. — Cristo é a causa principal do batismo, segundo o Evangelho: Aquele sobre que tu vires
descer o Espírito Santo e repousar sobre ele, esse é o que batiza. Ora, o Apóstolo diz, que em Cristo não
há homem nem mulher. Logo, assim como um homem leigo pode batizar, como ministro de Cristo,
assim também uma mulher. - Mas, sendo o varão a cabeça da mulher e Cristo a cabeça do varão, não
deve uma mulher batizar se um homem puder fazê-lo. Assim como não o deve um leigo, onde houver
um clérigo; nem o clérigo, estando presente um sacerdote; o qual porem pode batizar, ainda com o
bispo presente, porque lhe pertence o ofício.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como à mulher não lhe é permitido ensinar em
público, mas nada a impede de ensinar ou aconselhar a outrem privadamente, assim também não lhe é
permitido batizar pública e solenemente, podendo, contudo batizar em artigo de necessidade.

RESPOSTA À SEGUNDA. — Quando o batismo é celebrado solene e ordinàriamente, deve o batizando
receber esse sacramento do presbítero com cura de almas, ou de quem lhe fizer as vezes. Mas isto não é
preciso em artigo de necessidade, em que uma mulher pode batizar.

RESPOSTA À TERCEIRA. — Para a geração carnal contribui o homem e a mulher segundo a virtude da
natureza de cada um; por isso a mulher não pode ser o princípio ativo da geração, mas só passivo. Mas
na geração espiritual nenhum opera em virtude própria, mas instrumentalmente, por virtude de Cristo.
Por isso pode, em caso de necessidade, batizar tanto o homem como a mulher. Se porém a mulher
batizasse, mesmo que não em caso de necessidade, não se deve rebatizar, como dissemos, no caso do
batismo do leigo. Mas pecaria ela, batizando, e os que para tal cooperaram, quer recebendo dela o
batismo, quer trazendo-lhe alguém para que batizasse.

## Art. 5 — Se o não-batizado pode conferir o sacramento do batismo.
O quinto discute-se assim. — Parece que o não batizado não pode conferir o sacramento do batismo.

1. — Pois, ninguém dá o que não tem. Ora, o não-batizado não tem o sacramento do batismo. Logo, não
no pode conferir.

2. Demais. — O sacramento do batismo confere-o o ministro da Igreja como tal. Ora, o não-batizado de
nenhum modo pertence à Igreja, isto é, nem realmente nem pelo sacramento. Logo, não pode conferir o
sacramento do batismo.

3. Demais. — É mais conferir, que receber o sacramento. Ora, o não-batizado não pode receber os
outros sacramentos. Logo, com maior razão, não pode conferir um sacramento.
Mas, em contrário, Isidoro: O Pontífice Romano não se ocupa com quem batiza, mas somente com o
Espírito Santo que subministra a graça do batismo, embora seja pagão quem batiza. Ora, o batizado não
é pagão. Logo mesmo o não-batizado pode conferir o sacramento do batismo.

SOLUÇÃO. — Agostinho deixou essa questão indeterminada. Assim diz: Outra questão é a de saber se os
que nunca foram cristãos podem conferir o batismo; e nessa matéria nada devemos afirmar com
temeridade que não se apoiaria num concílio munido de autoridade em relação com a importância do
assunto. Mas depois foi determinado pela Igreja que os não-batizados, quer judeus quer pagãos,
pudessem conferir o sacramento do batismo, contanto que o façam na forma da Igreja. Por isso, Nicolau
Papa responde à Consulta dos Búlgaros: Afirmais que um certo, não sabeis se cristão ou pagão, batizou a
muitos na vossa Pátria. Esses, sem dúvida, se foram batizados em nome da Trindade, não devem ser
rebatizados se, porém a forma da Igreja não for observada, o sacramento do batismo não é conferido. E
assim se deve entender o que Gregório II escreve ao Bispo Bonifácio: Os que afirmas terem sido
batizados por pagãos, isto é, sem a observância da forma da Igreja, mandamos que de novo os batizes
em nome da Trindade.
E a razão é que, como quanto à matéria, qualquer água serve para a validade do batismo, assim também
qualquer homem pode como ministro, conferi-lo. Portanto, também um não-batizado pode, em caso de
necessidade, batizar. De modo que os dois não-batizados se batizem mutuamente, batizando primeiro
um ao outro, pelo qual será depois batizado; e assim ambos receberiam não só o sacramento como
também a realidade do sacramento. Mas se isso se fizesse fora de caso de necessidade, ambos pecariam
gravemente, tanto o batizante como o batizado; o que impediria o efeito do batismo, embora não
deixassem de receber o batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quem batiza só exerce o ministério exteriormente;
Cristo, porém é quem batiza internamente, que pode usar de todos os homens para o que quiser. Por
onde os não-batizados podem batizar, porque, como diz Nicolau Papa, não confere o batismo quem
batiza, mas Cristo.

RESPOSTA À SEGUNDA. — O não-batizado, embora não pertença à Igreja na realidade nem por
sacramento, pode contudo pertencer-lhe por intenção e semelhança de ato, tendo a intenção de fazer o
que faz à Igreja e observar a forma da Igreja ao batizar. E assim obra como ministro de Cristo, que não
jungiu a sua virtude aos batiza dos nem tão pouco ao sacramento.

RESPOSTA À TERCEIRA. — Os outros sacramentos não são de tamanha necessidade como o batismo.
Por isso antes se concede que um não-batizado possa batizar, do que receber os outros sacramentos.

## Art. 6 — Se vários podem simultaneamente batizar.
O sexto discute-se assim. — Parece que vários podem simultaneamente batizar.

1. — Pois, a multidão contém a unidade, mas não inversamente. — Portanto, o que pode fazer um,
podem fazer muitos, e não ao inverso; assim, muitos podem puxar um barco, mas um só não o pode.
Ora, um só pode batizar ao mesmo tempo muitos. Logo, também muitos podem batizar a um
simultaneamente.

2. Demais. — É mais difícil um agente atuar sobre muitos pacientes, do que muitos agentes sobre um só
paciente. Ora, um só pode batizar simultaneamente a vários. Logo e com maior razão, vários podem ao
mesmo tempo batizar a um.

3. Demais. — O batismo é o mais necessário dos sacramentos. Ora, em certos casos é necessários vários
batizarem simultaneamente a um; por exemplo no caso de estar uma criança em artigo de morte e
estarem presentes duas pessoas, uma muda e outra sem mãos e braços; pois, então seria necessário o
mutilado proferir as palavras e o mudo exercer o ato de batismo. Logo, parece que vários podem batizar
ao mesmo tempo.
Mas, em contrário, um agente exerce uma só ação. Se, pois, vários batizassem a um, resultariam vários
batismos. O que vai contra o dito do Apóstolo: Não há senão uma fé e senão um batismo.

SOLUÇÃO. — O sacramento do batismo haure a sua virtude, sobretudo na forma, a que o Apóstolo
denomina a palavra da vida. Por onde, devemos considerar, no caso de vários batizarem a um, de que
forma usaram. Assim, se disserem - Nós te batizamos em nome do Padre e do Filho e do Espírito Santo -
certos opinam que não conferirão o sacramento do batismo, por não terem observado a forma da
Igreja, que é Eu te batizo em nome do Padre e do Filho e do Espírito Santo. - Mas essa opinião fica
excluída pela forma do batismo usada pela Igreja Grega. Pois poderiam dizer: É batizado o servo de
Cristo N. em nome do Padre e do Filho e do Espírito Santo. Sob cuja forma os gregos recebem o batismo,
apesar de muito mais dissemelhante da que usamos que se disséssemos - Nós te batizamos.
Devemos, porém considerar que essa forma - Nós te batizamos - exprime a intenção de vários que
convêm em conferir o batismo a um. O que vai contra a natureza do ministério, pois ninguém batiza
senão como ministro de Cristo, fazendo-lhe assim as vezes; portanto, sendo Cristo um só, necessário é
também seja um só ministro representante de Cristo. Por isso diz Apóstolo slnaladamente: Um Senhor,
uma fé, um batismo. Logo uma intenção inconciliável com o batismo o torna inválido.
Se porém cada um dos batizantes dissesse: Eu te batizo em nome do Padre e do Filho e do Espírito Santo
- exprimiria cada qual a sua intenção, como se conferisse o batismo singularmente. O que poderia dar-se
no caso de dois adversários que contendessem por batizar. E como seria então manifesto quem
pronunciasse primeiro as palavras, conferiria o sacramento do batismo. O outro, por mais que tivesse o
direito de batizar, se ousasse pronunciar as palavras deveria ser punido por ter rebatizado. Se porém
ambos pronunciassem as palavras simultaneamente e imergissem ou aspergissem o neófito, deveriam
ser punidos pelo modo irregular de batizar e não pela reiteração do batismo; pois um e outro teria a
intenção de batizar um não-batizado e ambos, cada um por seu lado, batizariam. Nem confeririam dois
sacramentos diferentes; mas Cristo, que é quem batiza internamente, conferiria um sacramento por
meio de ambos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe quando se trata de agentes que agem
por virtude própria. Ora, os homens não batizam por virtude própria, mas por virtude de Cristo, que,
sendo um confere o seu sacramento por um ministro único.

RESPOSTA À SEGUNDA. — Em caso de necessidade, um poderia batizar a vários simultaneamente, sob
esta forma - Eu te batizo. Por exemplo, em caso de uma ruína iminente ou de morte em combate ou em
situações semelhantes, que se dão repentinamente e não permitem batizar cada um de per si. Nem por
isso, contudo se diversificaria a forma da Igreja, pois, o plural não é senão o singular geminado,
sobretudo quando Cristo disse, no plural - Batizai-os etc. - Nem há semelhança de batizante para
batizado. Porque Cristo, que é quem principalmente batiza, é um só; mas muitos se tornam um só em
Cristo.

RESPOSTA À TERCEIRA. — Como dissemos, a integridade do batismo consiste na forma das palavras e
no uso da matéria. Portanto, não batiza quem somente profere as palavras nem o que somente imerge.
Por onde, proferindo um, as palavras e fazendo outro a imersão, não poderá ser conveniente a forma
das palavras, Nem poderá dizer - Eu te batizo - quem não faz a imersão e por consequência não batiza.
Nem poderão dizer - Nós te batizamos - pois nem um nem outro batiza. Assim como duas pessoas que
escreverem um livro, escrevendo um uma parte e outro outra, não poderão dizer nós escrevemos este
livro, senão por sinédoque, tomando-se a parte pelo todo.

## Art. 7 — Se no batismo há necessidade de quem retire da fonte sagrada o batizado.
O sétimo discute-se assim. — Parece que no batismo não há necessidade de quem retire da fonte
sagrada o batizado.

1. — Pois, o nosso batismo foi instituído por Cristo e com ele se conforma. Ora, Cristo batizado não foi
tirado por ninguém da fonte, mas, como refere o Evangelho — depois que Jesus foi batizado saiu logo
para fora da água. Logo, parece que nem o batismo dos outros requere quem retire o batizado da fonte
sagrada.

2. Demais. — O batismo é uma regeneração espiritual, como se disse. Ora, a geração carnal não requer
senão um princípio ativo, o pai, e um passivo, a mãe. Porém, como no batismo a função de pai exerce
quem batiza e a da mãe a própria água do batismo, no dizer de Agostinho, parece não ser necessário
ninguém para retirar o batizado da fonte sagrada.

3. Demais. — Nos sacramentos da Igreja nada deve fazer-se de risível. Ora é risível os adultos batizados,
que podem suster de pé e sair da fonte sagrada, serem conduzidos por outrem. Logo, parece não haver
necessidade, sobretudo no batismo dos adultos, de quem tire o batizado da fonte sagrada.
Mas, em contrário, diz Dionísio, que os sacerdotes, tomando o batizado, entregam-no aos que lhe
devem dar a instrução e guiá-lo.

SOLUÇÃO. — A regeneração espiritual causada pelo batismo, assimila-se de certo modo à geração
carnal. Por isso diz a Escritura: Como meninos recém-nascidos, desejai o leite racional, sem dolo. Ora, na
geração carnal, o pequeno recém-nascido precisa de ama e de educador. Por onde, também na geração
espiritual do batismo é necessário quem desempenhe o papel de ama e de educador, informando e
instruindo esse como noviço da fé, sobre o pertinente à fé e à vida cristã. Ao que não podem vacar os
superiores da Igreja, entregue à direção comum do povo. Pois os pequenos e os noviços exigem
cuidados especiais, além dos comuns. Logo, é necessário quem retire o batizado da fonte sagrada, e lhe
dê instrução e proteção. Tal é o que diz Dionísio: Os nossos chefes divinos, isto é, os Apóstolos,
pensaram e decidiram que alguém devia receber os infantes, do mesmo modo por que os pais
confiariam o filho a um mestre sábio nas coisas divinas para que viva sob a sua conduta, sob a guarda de
um pai espiritual encarregado da salvação do mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo não foi batizado para se regenerar a si, mas aos
outros. Por isso, depois de batizado, não precisava de Mestre, como uma criança.

RESPOSTA À SEGUNDA. — A geração carnal só exige necessàriamente o pai e a mãe; mas para um parto
feliz e para a educação da criança é necessária a parteira, a ama e o mestre. E deles faz as vezes quem
retira o menino da fonte sagrada. Por isso não são necessàriamente exigidos pelo sacramento, mas um
só pode batizar com água, em caso de necessidade iminente.

RESPOSTA À TERCEIRA. — O batizado não é retirado pelo padrinho, da fonte sagrada, por ser ele fraco
de corpo, mas sim de espírito, como se disse.

## Art. 8 — Se quem retira o batizado da fonte sagrada está obrigado a dar- lhe instrução.
O oitavo discute-se assim. — Parece que quem retira o batizado da fonte sagrada não está obrigado a
dar-lhe instrução.

1. — Pois, não pode instruir senão o instruído. Ora, certos não instruídos, mas simples, são admitidos a
retirar o batizado da fonte sagrada. Logo, quem retira o batizado não está obrigado a dar-lhe instrução.

2. Demais. — O filho pode ser melhor instruído pelo pai do que por um estranho; pois, do pai recebe o
filho o ser, a nutrição e o ensino, como diz o Filósofo. Se, portanto, quem retira o batizado estivesse
obrigado a instruí-la, mais conveniente seria que o pai carnal retirasse o seu filho da fonte, que qualquer
outro. O que contudo é proibido por uma Decretal.

3. Demais. — Vários podem melhor instruir que um só. Se, portanto, quem retira um batizado está
obrigado a instruí-la, deveriam antes ser vários a retirá-la, que um só. Mas o contrário dispõe um
decreto de Leão Papa: Não mais de um - diz - quer varão ou mulher, venha a retirar o infante, do
batismo.
Mas, em contrário, diz Agostinho: Vós todos, homens e mulheres, que recebestes filhos no batismo, eu
vos exorto a vos considerar como devendo responder perante Deus por aqueles que vos vimos receber,
ao saírem da fonte sagrada.

SOLUÇÃO. — Cada um está obrigado a cumprir a obrigação que assumiu. Ora, como dissemos quem
recebeu o que saiu da fonte sagrada, assumiu a obrigação de ensiná-la. Logo, está obrigado a cuidar
dele, em caso de necessidade; assim, no tempo e lugar em que o batizado é criado entre infiéis. Mas,
quando criado entre católicos cristãos, pode razoavelmente eximir-se dessa obrigação presumindo-se
que os pais educarão diligentemente os filhos. Se, porém de qualquer modo perceber o contrário,
estaria obrigado, na medida do possível, a esforçar-se por cuidar da salvação dos seus filhos espirituais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Em caso de perigo, deveria ser uma pessoa instruída nas
coisas da religião, como diz Dionísio, que recebesse o batizando ao sair da fonte sagrada. Mas quando
não há esse perigo, por serem as crianças educadas entre católicos, qualquer pode ser admitido a esse
ofício. Pois o concernente à vida e à fé cristã é publicamente conhecido de todos. Contudo, o não-
batizado não pode receber o batizado, como o declara o Concílio de Mogúncia, embora o não-batizado
possa batizar. Porque a pessoa do batizante é necessária para o sacramento, mas não a do que recebe o
batizado, como se disse.

RESPOSTA À SEGUNDA. — Assim como a geração espiritual é diferente da carnal, assim também as
educações correspondentes são diferentes. Talo diz o Apóstolo: Se na verdade tivemos a nossos pais
carnais que nos corrigiam e os olhávamos com respeito, como não obedeceremos muito mais ao Pai dos
espíritos e viveremos? Portanto, um deve ser o pai espiritual e outro o carnal, salvo se a necessidade
impuzer o contrário.

RESPOSTA À TERCEIRA. — Haveria confusão de educações se não houvesse um instrutor principal.
Portanto, no batismo deve haver um que seja o padrinho principal. Outros porem podem ser admitidos
como coadjutores.
