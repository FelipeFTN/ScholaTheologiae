# Questão 6: Da ordem da assunção
Em seguida devemos tratar da ordem da referida assunção.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se o Filho de Deus assumiu a carne mediante a alma.
O primeiro discute-se assim. — Parece que o Filho de Deus não assumiu a carne mediante a alma.

1. — Pois, mais perfeito é o modo pelo qual o Filho de Deus está unido à natureza humana e às suas
partes, do que o pelo qual está em todas as criaturas. Ora, nas criaturas está imediatamente pela
essência, pela potência e pela presença. Logo, com maior razão, o Filho de Deus está imediatamente
unido à carne, e não mediante a alma.

2. Demais. — A alma e a carne estão unidas ao Verbo de Deus na unidade da hipóstase ou da pessoa.
Ora, o corpo pertence imediatamente à pessoa ou à hipóstase do homem, como a alma; antes até,
parece mais intimamente pertencente à hipóstase do homem o corpo, enquanto matéria, que a alma,
enquanto forma; pois, o princípio de individuação, compreendido na denominação de hipóstase é a
matéria. Logo, o Filho de Deus não assumiu a carne mediante a alma.

3. Demais. — Removido o meio, removido fica tudo o que por ele está unido; assim, removida a
superfície, desapareceria a cor do corpo, que nele existe mediante a superfície: Ora, separada pela
morte a alma, ainda permanece a união do Verbo com a carne, como a seguir se dirá. Logo, o Verbo não
está unido à carne mediante a alma.
Mas, em contrário, diz Agostinho: O poder divino, que é imenso, uniu-se uma alma racional e, por ela, o
corpo humano e o homem todo inteiro, para mudá-lo tornando-o melhor.

SOLUÇÃO. — O meio é assim chamado por implicar relação com o princípio e com o fim. Por onde,
assim como o princípio e o fim implicam uma certa ordem, assim também o meio. Ora, há uma dupla
ordem, a do tempo e a da natureza. Assim, na ordem do tempo, não se diz que há nenhum meio, no
mistério da Encarnação, porque o Verbo de Deus uniu a si, simultânea e totalmente, a natureza humana,
como a seguir se dirá. Quanto à ordem da natureza entre certos seres, podemos considerá-la a dupla
luz. Primeiro, conforme o grau de dignidade; assim dizemos que anjos são médios entre os homens e
Deus. Segundo, conforme a razão da causalidade; assim dizemos que existe uma causa média entre a
primeira causa e o último efeito. E esta segunda ordem de certo modo é consequente à primeira; assim,
como diz Dionísio, Deus age, pelas substâncias que lhe são mais chegadas, sobre as que dele estão mais
afastadas. — Se, pois, atendemos ao grau de dignidade neste último sentido, a alma é um termo médio
entre Deus e a carne. E então podemos dizer, que o Filho de Deus uniu a si a carne, mediante a alma.
Mas, também na ordem de causalidade, a alma é de certo modo a causa de a carne ter-se unido ao Filho
de Deus. Pois, não poderia ser assumida, senão pela ordem que tem para com a alma racional da qual
lhe resulta o ser carne humana. Pois, como dissemos acima, à natureza humana convinha, mais que a
todas as outras, ser assumida.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Podemos considerar uma dupla ordem entre a criatura e
Deus. — Uma, segunda a qual as criaturas são causadas por Deus, e dele dependem como do princípio
do qual têm o ser. E então, pela infinidade do seu poder, Deus atinge imediatamente qualquer ser, pelo
causar e conservar. Donde vem, que Deus está imediatamente em todos pela sua essência, presença e
potência. — Outra ordem é a em virtude da qual as coisas se reduzem a Deus como ao fim. E, então, há
um meio entre a criatura e Deus; pois, as criaturas inferiores se reduzem a Deus por meio das
superiores, como diz Dionísio. E a essa ordem pertence a assunção da natureza humana pelo Verbo de
Deus, que é o termo da assunção. E portanto, pela alma se une a carne.

RESPOSTA À SEGUNDA. — Se a hipóstase do Verbo de Deus fosse constituída simplesmente pela
natureza humana, resultaria o tocar o corpo de mais perto a essa hipóstase, por ser matéria, que é o
princípio da individuação; assim como a alma, que é a forma específica, toca de mais perto à natureza
humana. Ora, como a hipóstase do Verbo é anterior e mais elevada, relativamente à natureza humana,
tanto mais chegado lhe será o que, em a natureza humana, mais elevado for. Por onde, mais de perto
lhe toca ao Verbo de Deus a alma que o corpo.

RESPOSTA À TERCEIRA. — Nada impede, que uma coisa, sendo causa de outra, quanto à aptidão e à
conveniência, o efeito continue a existir, mesmo quando a causa for suprimida. Pois, embora a produção
de uma coisa dependa de outra, contudo, quando esta última for existente, já não depende daquela.
Assim, se a amizade entre duas pessoas for causada por uma terceira, ela permanece embora essa
terceira desapareça. E assim também, se uma mulher foi tomada em casamento por causa de sua
beleza, qualidade da mulher que facilita a união conjugal, contudo, desaparecida essa beleza, perdurará
a união conjugal. E semelhantemente, separada a alma, subsiste a união do Verbo de Deus com a carne.

## Art. 2 — Se o Filho de Deus assumiu a alma mediante o espírito.
O segundo discute-se assim. — Parece que o Filho de Deus não assumiu a alma mediante o espírito.

1. — Pois, uma mesma coisa não pode ser meio entre ela própria e outra. Ora, o espírito ou o
entendimento não difere, na essência, da alma em si mesma, como se estabeleceu na Primeira Parte.
Logo, o Filho de Deus não assumiu a alma, mediante o espírito ou entendimento.

2. Demais. — O que se fez mediante a assunção parece ser o mais apto para ela. Ora, o espírito ou
mente não é mais apto para ser assumido, que a alma; o que claramente resulta de não serem
assumíveis os espíritos angélicos, como se disse. Logo, parece que o Filho de Deus não assumiu a alma
mediante o espírito.

3. Demais. — Na assunção, ao primeiro princípio se une o elemento posterior mediante intermediário,
que tem prioridade sobre este. Ora, a alma designa a essência em si mesma, naturalmente com
prioridade sobre a sua potência, que é o entendimento. Logo, parece que o Filho de Deus não assumiu a
alma mediante o espírito ou entendimento.
Mas, em contrário, diz Agostinho: A invisível e incomutável verdade recebeu a alma, pelo espírito, e,
pela alma, o corpo.

SOLUÇÃO. — Como se estabeleceu, dizemos que o Verbo de Deus assumiu a carne mediante a alma,
quer quanto à ordem da dignidade, quer também quanto à conveniência da assunção. Ora, uma e outra
coisa encontraremos, se compararmos o intelecto, que se chama espírito, com as outras partes da alma.
Pois, a alma não é assumível, por conveniência, senão por ser capaz de Deus, tendo a sua existência à
imagem dele. O que é segundo o entendimento, que é chamado espírito, conforme àquilo do Apóstolo:
Renovai-vos no espírito do vosso entendimento. Semelhantemente, também o intelecto, entre as outras
partes da alma, é superior, mais digno e mais semelhante a Deus. Por onde, como diz Damasceno, uniu-
se à carne por meio do intelecto o Verbo de Deus. Ora, o intelecto é o que. a alma tem de mais puro;
mas também Deus é inteligência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o intelecto não difira da alma pela essência,
distingue-se porém das outras partes da alma, em virtude da potência. E por aí, compete-lhe o papel de
meio.

RESPOSTA À SEGUNDA. — Ao espírito angélico não lhe falece a conveniência para ser assumido, por
falta de dignidade, mas pela irreparabilidade da queda. O que não pode ser dito do espírito humano,
como se colige do que foi estabelecido na Primeira Parte.

RESPOSTA À TERCEIRA. — A alma, entre a qual e o Verbo de Deus é meio o intelecto, não é tomada pela
sua essência, que é comum a todas as potências; mas o é pelas potências inferiores, que são comuns a
todas as almas.

## Art. 3 — Se a alma de Cristo foi assumida pelo Verbo, antes da carne.
O terceiro discute-se assim. — Parece que a alma de Cristo foi assumida pelo Verbo, antes da carne.
1 — Pois, o Filho de Deus assumiu a carne mediante a alma, como se disse. Ora, chegamos ao meio
antes de chegarmos ao fim. Logo, o Filho de Deus primeiro assumiu a alma que o corpo.

2. Demais. — A alma de Cristo é mais digo na que os anjos, conforme a Escritura: Adorei ao Senhor,
todos os seus anjos. Ora, os anjos foram criados desde o princípio, como se estabeleceu na Primeira
Parte. Logo, também a alma de Cristo, que não foi primeiro criada que assumida; pois, como diz
Damasceno, nunca a alma nem o corpo de Cristo tiveram nenhuma hipóstase própria além da hipóstase
do Verbo. Logo, parece que a alma foi primeiro assumida que a carne, a qual foi concebida no ventre da
Virgem.
Demais. — O Evangelho diz: E nós o vimos cheio de graça e de verdade. E depois acrescenta: Todos nós
participamos da sua plenitude, isto é, todos os fiéis em qualquer tempo, como Crisóstomo expõe. Ora,
isso não seria, se Cristo não tivesse tido a plenitude da graça e da verdade, antes de todos os santos que
existiram desde o princípio do mundo; porque a causa não pode ser posterior ao causado. Tendo, pois, a
plenitude da graça e da verdade existido na alma de Cristo, pela união com o Verbo, segundo aquilo da
Escritura — Nós vimos a sua glória como de Filho unigênito do Pai, cheio de graça e de verdade —
resulta que desde o princípio do mundo a alma de Cristo foi assumida pelo Verbo de Deus.
Mas, em contrário, Damasceno diz: Antes da encarnação no ventre da Virgem, o intelecto não se uniu ao
Deus Verbo, para então ser chamado Cristo, como pensam muitos, erradamente.

SOLUÇÃO. — Origines ensinava que todas as almas foram criadas desde o princípio; e entre elas
também punha a alma de Cristo, como criada. — Mas isto é inadmissível, entendendo-se que foi então
criada mas não unida imediatamente ao Verbo; pois daí resultaria que essa alma teve, durante um certo
tempo, uma subsistência própria, sem o Verbo. E assim, quando foi assumida pelo Verbo, ou a união
não teria sido feita segundo a subsistência, ou teria desaparecido a subsistência preexistente da alma.
— Também semelhantemente, é inadmissível dizer que essa alma foi, a princípio, unida ao Verbo e,
depois, encarnou-se no ventre da Virgem. Porque então a sua alma não teria sido da mesma natureza
que a nossa, que é simultaneamente criada e infundida no corpo. Donde o dizer o Papa Leão: A carne de
Cristo não era de outra natureza que a nossa; nem lhe foi inspirada, a princípio, uma alma diferente da
dos outros homens.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como se disse. a alma de Cristo é considerada um meio,
na união da carne com o Verbo, na ordem da natureza. Mas isso não implica em que tivesse sido meio
na ordem do tempo.

RESPOSTA À SEGUNDA. — Como diz o Papa Leão, a alma de Cristo é excelente não pela diversidade
genérica, mas pela sublimidade da virtude. Pois, é do mesmo gênero que as nossas almas, mas
sobrepuja também os anjos, pela plenitude da graça e da verdade. Pois, o modo da Encarnação
corresponde à alma segundo a propriedade do seu gênero; donde vem que, sendo a forma do corpo, é
criada simultaneamente com a sua infusão no corpo e a sua união com ele. O que não convém aos
anjos, que são substâncias completamente separadas de corpos.

RESPOSTA À TERCEIRA. — Da plenitude de Cristo todos os homens participam, pela fé que nele têm.
Pois, diz o Apóstolo: A Justiça de Deus é infundida pela fé de Jesus Cristo em todos e sobre todos os que
nele crêem. Pois, assim como nós cremos nele, como encarnado, assim os antigos nele creram como
nascituro: Tendo um mesmo espírito de fé, cremos. Ora. a fé em Cristo tem a virtude de justificar por
decreto da graça de Deus, segundo o Apóstolo: Ao que não crê e crê naquele que justifica ao ímpio, a
sua fé lhe é imputada à justiça, segundo o decreto, da graça de Deus. Por onde, sendo esse decreto
eterno, nada impede certos se justificarem pela fé de Jesus Cristo, antes ainda de ter a sua alma cheia
de graça e de verdade.

## Art. 4 — Se a carne de Cristo foi primeiro assumida pelo Verbo que unida à alma.
O quarto discute-se assim. — Parece que a carne de Cristo foi primeiro assumida pelo Verbo que
unida à alma.

1. — Pois, diz Agostinho: Crê firmissimamente e de nenhum modo duvides, que a carne de Cristo não foi
concebida, sem a divindade, no ventre da Virgem, primeiro que fosse assumida pelo Verbo. Ora, parece
que a carne de Cristo foi primeiro concebida que unida à alma racional; porque a disposição material é
anterior na via da geração que a forma completiva. Logo, primeiro foi a carne de Cristo assumida que
unida à alma.

2. Demais. — Assim como a alma faz parte da natureza humana, assim também o corpo. Ora, a alma
humana não teve outro princípio do seu ser em Cristo, que nos outros homens, como resulta da
autoridade de Leão Papa supra aduzida. Logo, parece que também, o corpo de Cristo não teve outro
princípio de existir diferente do que tem em nós. Ora, em nós primeiro é concebido o corpo, que se lhe
una a alma racional. Logo, assim também o foi em Cristo. Então, a carne foi primeiro assumida pelo
Verbo, que unida à alma.

3. Demais. — Diz um autor que a causa primeira mais influi no causado e mais lhe está unida, que a
causa segunda. Ora, a alma de Cristo está para o Verbo como a causa segunda para a primeira. Portanto,
primeiro o Verbo uniu-se à carne, que a alma.
Mas, em contrário, diz Damasceno: A carne do Verbo de Deus é simultaneamente carne, carne animada,
racional e intelectual. Logo, a união do Verbo com a carne não lhe precedeu a união com a alma.

SOLUÇÃO. — A carne humana pode ser assumida pelo Verbo, conforme a relação que tem com a alma
racional como com a sua forma própria. Ora, essa relação não existe antes de se lhe unir a alma racional.
Pois, quando uma certa matéria se torna própria de uma determinada forma, simultaneamente recebe
essa forma; por onde não se termina a alteração no mesmo instante em que é introduzida a forma
substancial. Por isso a carne não devia ser assumida antes de ser carne humana; o que se deu quando se
lhe uniu a alma racional. Assim como, pois, a alma não foi primeiro assumida, que a carne, por ser
contra a natureza da alma o existir antes de unida ao corpo; assim também a carne não devia primeiro
ser assumida, que a alma, por não ser carne humana antes de ter uma alma racional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A carne humana existe por meio da alma. Logo, ano
antes da união com a alma, não é carne humana; mas, pode ser uma disposição para a carne humana.
Mas, na concepção de Cristo, o Espírito Santo que é um agente de virtude infinita, simultaneamente
dispôs a matéria e a conduziu ao seu termo perfeito.

RESPOSTA À SEGUNDA. — A forma especifica atualizando; mas a matéria é essencialmente potencial
em relação à espécie. Por onde, seria contra a essência da forma o preexistir à natureza da espécie, cuja
perfeição se consuma pela sua união com a matéria; mas não é contra a natureza da matéria o preexistir
à natureza da espécie. Por onde, a dissemelhança entre a nossa origem e a de Cristo, consistente em ser
a nossa carne concebida antes de ser animada, e em o não ser a carne de Cristo, se funda no que
precede o complemento da natureza; assim como também a diferença de sermos nós concebidos do
sêmen do homem, mas não Cristo. Mas, a diferença que houvesse quanto à origem da alma redundaria
em diversidade de natureza.

RESPOSTA À TERCEIRA. — Entende-se que o Verbo de Deus primeiro uniu-se à carne que a alma, pelo
modo comum das outras criaturas — pela essência, pela potência e pela presença; digo porém —
primeiro — não temporalmente, mas segundo a natureza. Pois, primeiro inteligimos a carne como um
certo ser. que tem do Verbo, do que como animada, o que lhe advém da alma. Mas, pela união pessoal
é mister que primeiro segundo o intelecto, a carne se una à alma que ao Verbo; porque a união com a
alma a torna capaz de união com o Verbo em pessoa: sobretudo porque a pessoa só existe na natureza
racional.

## Art. 5 — Se o Filho de Deus assumiu toda a natureza humana mediante as suas partes.
O quinto discute-se assim. — Parece que o Filho de Deus assumiu toda a natureza humana mediante
as suas partes.
1 — Pois, diz Agostinho. que a invisível e incomuntável Verdade assumiu, pelo espírito, a alma; pela
alma, o corpo e assim todo o homem. Ora, o espírito, a alma e o corpo são partes de todo o homem.
Logo, assumiu todo o homem mediante as suas partes.

2. Demais. — O Filho de Deus assumiu a carne mediante a alma, por ser mais semelhante a Deus a alma
do que o corpo. Ora. as partes da natureza humana, sendo mais simples, parece que são mais
semelhantes ao ser simplicissimo, que o todo. Logo, assumiu o todo mediante as partes.
Demais. — O todo resulta da união das partes. Ora, a união é entendida como o termo da assunção; ao
passo que as partes se preinteligem à assunção. Logo, assumiu o todo, pelas partes.
Mas, em contrário, diz Damasceno: Em nosso Senhor Jesus Cristo não consideramos partes de partes,
mas o que concorre proximamente à união, a saber, a divindade e a humanidade. Ora, a humanidade é
um determinado todo, composto de alma e de corpo como de partes. Logo, o Filho de Deus assumiu as
partes mediante o todo.

SOLUÇÃO. — Quando nos referimos a um meio, na assunção da Encarnação, não designamos uma
ordem temporal, porque foi simultânea a assunção do todo e das partes todas. Pois, como
demonstramos, a alma e o corpo simultaneamente uniram-se uma ao outro para constituir a natureza
humana no Verbo. E o que aí se designa é a ordem da natureza. Por onde, pelo que tem prioridade de
natureza, é assumido o que vem em segundo lugar. Ora, a prioridade de natureza pode ser considerada
a dupla luz relativamente ao agente e relativamente à matéria; pois, essas duas coisas preexistem à
realidade. Assim, relativamente ao agente é primeiro, em sentido absoluto, o que lhe constitui a
intenção primária; e, em sentido relativo, aquilo por onde lhe principia a ação. Quanto à matéria, é
primeiro àquilo que primeiramente existe na transmutação dela. Ora, a ordem a que sobretudo
devemos atender, na Encarnação, é a relativa ao agente; porque, como diz Agostinho, nessa matéria a
razão total da obra é o poder do agente. Ora, como é manifesto, o completo vem antes do incompleto,
na intenção do agente; e, por consequência, vem o todo antes das partes. Donde devemos concluir, que
o Verbo de Deus assumiu as partes da natureza humana mediante o todo, Pois, assim como assumiu o
corpo pela ordem que mantém para com a alma racional, assim, assumiu o corpo e a alma, pela ordem
que mantêm para com a natureza humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras citadas nada mais dão a entender senão que
o Verbo, assumindo as partes da natureza humana, assumiu toda a natureza humana. E assim, a
assunção das partes tem prioridade, na ordem da operação, logicamente, mas não temporalmente. Mas
a assunção da natureza tem prioridade na ordem da assunção; o que é ter prioridade absoluta, como se
disse.

RESPOSTA À SEGUNDA. — Deus é simples que também é perfeitíssimo. Por onde. o todo é mais
semelhante a Deus que ser mais perfeito.

RESPOSTA À TERCEIRA. — Na união pessoal é que se termina a assunção; mas não, na união da
natureza, que resulta da união das partes.

## Art. 6 — Se o Filho de Deus assumiu a natureza humana mediante a graça.
O sexto discute-se assim. — Parece que o Filho de Deus assumiu a natureza humana mediante a graça.
1 — Pois, pela graça é que nos unimos a Deus, Ora, em Cristo a natureza humana; estava por excelência
unida a Deus. Logo, essa união se fez mediante a graça.

2. Demais. — Assim como o corpo vive pela alma, que lhe dá a ele a perfeição, assim a alma, pela graça.
Ora, a natureza humana se torna apta para a assunção, por meio da alma. Logo, o Filho de Deus assumiu
a alma mediante a graça.

3. Demais. — Agostinho diz, que o Verbo Encarnado é como o nosso verbo, quando falamos. Ora, o
nosso verbo se une à palavra mediante o espírito. Logo, o Verbo de Deus se une à carne mediante o
Espírito Santo; e portanto, mediante a graça, que é atribuída ao Espírito Santo, segundo o Apóstolo. Há
repartição de graças, mas um mesmo é o Espírito.
Mas, em contrário, a graça é um acidente da alma, como na Segunda Parte se demonstrou. Ora, a união
do Verbo com a natureza humana se fez por subsistência e não por acidente, como do sobredito se
colhe. Logo, a natureza humana não foi assumida mediante a graça.

SOLUÇÃO. — Em Cristo há a graça de união e a graça habitual. Logo, a graça pode ser entendida como
meio, na assunção da natureza humana, quer tratemos da graça de união, quer da habitual. Pois, a graça
de união é o ser pessoal mesmo, dado gratuitamente à natureza humana, por Deus, na pessoa do
Verbo, o qual é o termo da assunção. E a graça habitual, pertencente à santidade pessoal do Homem-
Deus, é um efeito consequente à união, conforme o Evangelho: Vimos a sua glória, como de Filho
Unigênito do Pai, cheio de graça e de verdade, pelo que dá a entender que do facto mesmo de ser o
Homem Cristo o Unigênito do Pai — o que lhe advinha da união — tem a plenitude da graça e da
verdade. Se porém, entendermos a graça como a vontade de Deus, que faz ou dá alguma coisa
gratuitamente, nesse caso a união se fez pela graça, não como um meio, mas como pela causa eficiente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A nossa união com Deus é mediante uma operação, isto
é, enquanto o conhecemos e amamos. Por onde, essa união se dá pela graça habitual enquanto que a
operação perfeita procede do hábito. Mas a união da natureza humana com o Verbo de Deus é segundo
o ser pessoal, são dependente de nenhum hábito, mas imediatamente da natureza mesma.

RESPOSTA À SEGUNDA. — A alma é a perfeição substancial do corpo; ao passo que a graça é uma
perfeição acidental da alma. Por isso, a graça não pode ordenar a alma para a união pessoal, que não é
acidental, como a alma e o corpo.

RESPOSTA À TERCEIRA. — O nosso verbo se une à palavra, mediante o espírito; não, certo, como por
um meio formal, mas como por um meio movente; pois, do verbo interiormente concebido procede o
espírito, de que, se forma a palavra. E semelhantemente, do Verbo eterno procede o Espírito Santo, que
formou o corpo de Cristo, como a seguir se dirá. Mas daí não se segue que a graça do Espírito Santo seja
um meio formal, na referida união.