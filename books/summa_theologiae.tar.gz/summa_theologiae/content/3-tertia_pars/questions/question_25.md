# Questão 25: Da adoração de Cristo
Em seguida devemos tratar do que respeita a Cristo em relação a nós. E primeiro, da adoração de Cristo,
pela qual nós o adoramos. Segundo, de ser ele o mediador nosso, perante Deus.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se por uma mesma adoração deve ser adorada a divindade e a humanida de Cristo.
O primeiro discute-se assim. — Parece que por uma mesma adoração não deve ser adorada a
divindade e a humanidade de Cristo.

1. — Pois, a divindade de Cristo deve ser adorada pela adoração comum ao Pai e ao Filho; donde o dizer
o Evangelho: Todos honrem ao Filho assim como honram ao Pai. Ora, a humanidade de Cristo não é
comum com o Pai. Logo, não deve pela mesma adoração ser adorada a humanidade de Cristo e a sua
divindade.

2. Demais. — A honra é propriamente o prêmio da virtude, como diz o Filósofo. Ora, a virtude merece o
seu prêmio pelo seu ato. Mas, como, em Cristo, uma é a operação da sua natureza divina e outra, da
humana, como demonstramos, resulta que deve ser uma a honra tributada à sua humanidade, e outra à
sua divindade.

3. Demais. — A alma de Cristo, se não estivesse unida ao Verbo, devia ser venerada pela excelência da
sabedoria e da graça que tem. Ora, nada perdeu da sua dignidade por se ter unido ao Verbo. Logo, à
natureza humana em Cristo deve ser tributada uma adoração própria, além da que lhe é prestada à
divindade.
Mas, em contrário, diz o Quinto Sínodo: Quem afirmar que adora a Cristo nas suas naturezas, o que
constitui duas adorações; e que não adora, por uma só adoração, o Verbo de Deus encarnado,
simultaneamente com a sua carne, como foi estabelecido desde o início da Igreja de Deus, esse seja
anátema.

SOLUÇÃO. — Em quem é honrado duas coisas podemos considerar, a saber: A pessoa a quem a honra é
tributada e a causa da honra. Ora, propriamente, a honra é prestada a todo ser por si subsistente.
Assim, não dizemos que a mão de um homem é honrada, mas que esse homem o é. E se às vezes
dissermos, que é honrada a mão ou o pé de alguém, isso não significa sejam essas partes por si mesmas
honradas, mas que, nelas, honramos o todo. De cujo modo também um homem pode ser honrado por
alguma exterioridade sua, como na sua roupa, na sua imagem ou no seu embaixador. Mas, a causa da
honra é princípio em virtude do qual o honrado tem alguma excelência; pois, a honra é a reverência
prestada a alguém por causa da sua excelência, como se disse na Segunda Parte. Se, pois, num só
homem existirem várias causas de ser honrado, Por exemplo, a Superioridade, a ciência e a virtude, esse
homem receberá por certo uma só honra por parte de quem o honra, mas serão várias as honras, pelas
suas causas; pois, o mesmo homem é o honrado tanto pela ciência como pela virtude. Ora, havendo em
Cristo uma só pessoa, de natureza divina e humana, e também uma só hipóstase e um suposto, só uma
é a adoração e só uma a honra por parte dos que o adoram; mas, quanto à causa por que é honrado,
podemos considerar várias as adorações, de modo que será uma a honra tributada à sabedoria incriada
e outra, à salvação criada. - Mas, se tivesse Cristo várias pessoas ou hipóstases seriam também várias as
adorações, em sentido absoluto. E tal é o que o Sínodo condena. Pois, determina o seguinte: Quem
ousar dizer que devemos coadorar o homem assumido, com o Verbo de Deus, como se fossem duas
adorações diferentes, e que, ao contrário, não é a mesma adoração que honra o Emanuel, enquanto
Verbo feito carne, esse seja anátema.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na Trindade três são os honrados, mas uma só a causa
da honra. O contrário se dá no mistério da Encarnação. Por isso, é uma a honra tributada à Trindade e
outra a tributada a Cristo.

RESPOSTA À SEGUNDA. — Não é a operação a honrada, que é só a razão da honra. Por isso, o haver em
Cristo duas operações não prova serem duas as adorações, mas sim, duas causas de adoração.

RESPOSTA À TERCEIRA. — Se a alma de Cristo não estivesse unida ao Verbo de Deus, seria a parte mais
principal da humanidade dele. Por isso sobretudo devia ser honrada, por a ser nele o homem a parte
principal. Mas, por estar a alma de Cristo unida a uma pessoa mais digna, a essa pessoa sobretudo, a
qual a alma de Cristo está unida, é devida a honra. Mas isso não diminui a dignidade da alma de Cristo,
ao contrário, a aumenta, como também dissemos.

## Art. 2 — Se a humanidade de Cristo deve ser adorada por adoração de Iatria.
O segundo discute-se assim. — Parece que a humanidade de Cristo não deve ser adorada por
adoração de latria.

1. — Pois aquilo da Escritura: Adorai o escabelo de seus pés porque éle é santo – diz a Glosa: A carne
assumida pelo Verbo de Deus nós a adoramos sem nenhuma impiedade; pois, ninguém lhe come
espiritualmente a carne, antes de adorá-la; mas não me refiro à adoração de latria, devida só ao Criador.
Ora, a carne de Cristo é parte da sua humanidade. Logo, a humanidade de Cristo não deve ser adorada
com adoração de latria.

2. Demais. — O culto de latria a nenhuma criatura é devido; pois, os Gentios foram reprovados porque
adoraram e serviram à criatura, no dizer do Apóstolo. Ora, a humanidade de Cristo é uma criatura. Logo,
não deve ser adorada com adoração de latria

3. Demais. — A adoração de latria é devida a Deus como reconhecimento do seu domínio máximo,
segundo a Escritura: Adorarás ao Senhor teu Deus e só a ele servirás. Ora, Cristo enquanto homem é
menor que o Pai. Logo, a sua humanidade não deve ser adorada com adoração de latria.
Mas, em contrário, Damasceno diz: É adorada a carne de Cristo, depois de encarnado o Verbo de Deus,
não em si mesma, mas pelo Verbo de Deus a ela hipostaticamente unido. E aquilo da Escritura — Adorai
o escabelo de seus pés — diz a Glosa: Quem adora o corpo de Cristo não olha para a terra, mas antes
aquele de quem é o escabelo, em honra do qual adora o escabelo. Ora, o Verbo encarnado é adorado
por adoração de latria. Logo, também o seu corpo ou a sua humanidade.

SOLUÇÃO. — Como dissemos, a honra da adoração propriamente é devida à hipóstase subsistente;
contudo a razão da honra pode ser o que não é subsistente, por causa do que é honrado o seu sujeito. E
assim de dois modos podemos entender a adoração da humanidade de Cristo. Primeiro, que lhe
pertença, como ao ser adorado. E portanto, adorar a carne de Cristo não é senão adorar o Verbo de
Deus encarnado; assim como adorar a veste do rei não é senão adorar o rei vestido. E, desse modo, a
adoração da humanidade de Cristo é uma adoração de Iatria. - Em segundo lugar, podemos entender a
adoração da humanidade de Cristo, que lhe é tributada em razão de ser ela perfeita, por todos os dons
da graça. E então a adoração da humanidade de Cristo não é uma adoração de latria; mas de dulia; de
modo que a mesma pessoa una de Cristo seja adorada por adoração de latria, por causa da sua
divindade; e por adoração de dulia por causa da perfeição da sua humanidade. Nem há nisso
incongruência, porque a Deus Padre é devida a honra de latria por causa da divindade, e a honra de
dulia por causa do domínio com que governa a criatura. Por isso, àquilo da Escritura — Senhor Deus
meu, em ti esperei — diz a Glosa — Deus de todos, pelo poder, a quem é por isso devida a dulia; Deus
de todos pela criação, a quem é devida então a latria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Glosa citada não devemos entendê-la como
significando, que deva a carne de Cristo ser adorada separadamente da sua divindade; pois, isso seria
possível somente se não fosse uma mesma a hipóstase de Deus e do homem. Mas como diz Damasceno,
se separamos, com penetração de inteligência, o que é visto, do que é compreendido, não deve ser
adorado como criatura, isto é, com adoração de latria. E então, assim entendida, como separada do
Verbo de Deus, é lhe devida a adoração de dulia; não qualquer, por exemplo, a prestada às outras
criaturas; mas uma de mais excelência, chamada hiperdulia.

DONDE também se deduz a RESPOSTA À SEGUNDA E À TERCEIRA OBJEÇÕES. — Porque a adoração de
latria não é prestada à humanidade de Cristo em razão dela mesma, mas em razão da divindade, a que
está unidade, pela qual Cristo não é menor que o Pai.

## Art. 3 — Se a imagem de Cristo deve ser adorada com adoração de latria.
O terceiro discute-se assim. — Parece que à imagem de Cristo não deve ser adorada com adoração de
latria.

1. — Pois, diz a Escritura: Não farás para ti imagem de escultura, nem figura alguma. Ora, nenhuma
adoração deve ser prestada contra o preceito de Deus. Logo, a imagem de Cristo não deve ser adorada
com adoração de latria.

2. Demais. — Não devemos imitar as práticas dos gentios, como diz o Apóstolo. Ora, os gentios são
precipuamente acusados porque mudaram a glória do Deus incorruptível em semelhança de figura de
homem corruptível. Logo, a imagem de Cristo não deve ser adorada com adoração de latria.

3. Demais. — A Cristo é devida a adoração de latria em razão da divindade, e não, da humanidade. Ora,
à imagem da sua divindade, impressa na alma racional, não é devida a adoração de Iatria. Logo, muito
menos o é à imagem corpórea, que lhe representa a humanidade.

4. Demais. — No culto divino não se deve praticar senão o instituído por Deus. Por isso o Apóstolo, ao
transmitir a doutrina do sacrifício da Igreja, diz; Eu recebi do Senhor o que também vos ensinei a vós.
Ora, a Escritura nada nos diz sobre a adoração das imagens. Logo, a imagem de Cristo não deve ser
adorada com adoração de latria.
Mas, em contrário, Damasceno cita Basílio, que diz: A honra prestada à imagem é prestada ao ser a que
ela pertence, isto é, ao modelo. Ora, o modelo mesmo isto é, Cristo, deve ser adorado com adoração de
latria. Logo, também a sua imagem.

SOLUÇÃO. — Como diz o Filósofo, a nossa alma se aplica com duplo movimento, a uma imagem, à em si
mesma, como uma determinada coisa e enquanto imagem de alguém. E entre esses dois movimentos
há a diferença seguinte: o primeiro movimento, pelo qual nos aplicamos a uma imagem, enquanto uma
determinada coisa, difere daquele pelo qual nos aplicamos ao ser a que ela pertence; ao passo que o
segundo movimento, cujo objeto é a imagem como tal, é idêntico ao que tem por objeto o ser ao qual
ela pertence. Donde, pois, devemos concluir, que à imagem de Cristo, enquanto uma determinada
coisa, por exemplo, madeira esculpida ou pintada, nenhuma reverência é prestada, por que reverência
só é devida à natureza racional. E daí resulta que lhe prestamos reverência só enquanto imagem. Donde
se segue que a mesma reverência é prestada à imagem de Cristo e ao próprio Cristo. Sendo, portanto,
Cristo adorado com adoração de latria, consequentemente a sua imagem deve ser adorada também
com adoração de latria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O referido preceito não proíbe fazer qualquer escultura
ou imagem, mas, fazê-la para adorar, e por isso acrescenta: Não as adorarás nem lhes darás culto. Mas,
como se disse, o movimento para a imagem é o mesmo que o para a realidade; por isso, é proibida a
adoração da imagem do mesmo modo pelo qual o é a adoração do ser a que ela pertence. E por isso se
entende a proibição, do lugar aduzido, de adorar as imagens, que os gentios faziam para venerar os seus
deuses, isto é, os demônios. Donde o acrescentar a Escritura: Não terás deuses estrangeiros diante de
mim. Pois, do verdadeiro Deus, que é incorpóreo, não se pode fazer nenhuma imagem corpórea;
porque, como diz Damasceno, é suma insipiência e impiedade dar figura ao divino. Mas, como no Novo
Testamento Deus se fez homem, pode ser adorado na sua imagem corpórea.

RESPOSTA À SEGUNDA. — O Apóstolo proíbe tomarmos parte nas obras infrutuosas dos Gentios; mas
não o proíbe que lhes participemos das obras úteis, Ora, a adoração das imagens deve ser contada entre
as obras infrutuosas, por duas razões. Primeiro, porque certos gentios adoravam essas imagens como se
fossem as realidades, crendo habitar nelas a divindade, por causa das respostas que os demônios por
meio delas davam, e outros efeitos insólitos semelhantes. Segundo, por causa das realidades que elas
manifestavam; pois, faziam essas imagens, de certas criaturas, veneradas nelas pela veneração de latria
Ao passo que nós adoramos por adoração de latria a imagem por causa da realidade que ela representa,
como dissemos.

RESPOSTA À TERCEIRA. — À criatura racional é devida reverência, em si mesma. Por onde, se à criatura
racional, que é a imagem de Deus, fosse tributada a adoração de latria, poderia haver ocasião de erro;
isto é, poderia o afeto dos adoradores limitar-se ao homem, como um determinado ser, sem levar-se
até Deus, de que ele é a imagem. O que não pode dar-se com a imagem esculpida ou pintada na matéria
sensível.

RESPOSTA À QUARTA. — Os Apóstolos, por uma inspiração familiar do Espírito Santo, ensinaram certas
práticas a serem observadas pelas Igrejas, que não deixaram por escrito, mas na observância da Igreja,
através das gerações do fiéis, Por isso o Apóstolo mesmo diz: Estai firmes e conservai as tradições que
aprendestes, ou de palavra, isto é, proferida oralmente, ou de carta nossa, isto é, por um escrito
transmitido. E entre essas tradições está a da adoração das imagens de Cristo. Por isso São Lucas pintou
a imagem de Cristo, que, segundo se conta, está em Roma.

## Art. 4 — Se à cruz de Cristo devemos prestar a adoração de Iatria.
O quarto discute-se assim. — Parece que a cruz de Cristo não devemos prestar a adoração de latria.

1. — Pois, nenhum filho piedoso venera a contumélia feita contra o seu próprio pai, por exemplo, o
flagelo com que é flagelado, o madeiro em que foi suspenso; do contrário, aborrece tudo isso. Ora,
Cristo, no lenho da cruz, sofreu aprobiosíssima morte, segundo aquilo da Escritura: Condenemo-lo a
uma morte mais infame. Logo, em vez de venerá-la, devemos aborrecer a cruz.

2. Demais. — A humanidade de Cristo, é adorada pela adoração de latria, enquanto unida à pessoa do
Filho de Deus; o que não se pode dizer da cruz. Logo, à cruz de Cristo não deve ser prestada adoração de
latria.

3. Demais. — Assim como a cruz de Cristo foi o instrumento da sua paixão e morte, assim também o
foram muitas outras coisas, como os cravos, a coroa e a lança; as quais contudo não prestamos o culto
de latria. Logo, parece que não devemos tributar à cruz de Cristo a adoração de latria.
Mas, em contrário, prestamos o culto de latria aquele em quem pomos a esperança da nossa salvação.
Ora, pomos na cruz de Cristo a esperança da nossa salvação. Assim, a Igreja canta no hino da Paixão.
O cruz, ave, esperança única!
Neste tempo da paixão,
Aumenta dos pios a justiça,
E aos réus dá vênia.
Logo, devemos prestar à cruz de Cristo a adoração de latria.

SOLUÇÃO. — Como dissemos, honra ou reverência não é devida senão à natureza racional; e à criatura
insensível não devemos honra nem reverência senão por causa da natureza racional. E isto de dois
modos: ou enquanto representa uma natureza racional, ou por estar a esta de algum modo unida Do
primeiro modo, costumaram os homens venerar a imagem do rei; do segundo, as suas vestes. Mas, uma
e outra coisa, com a mesma veneração com que veneram o rei. — Se, pois, nos referimos à cruz mesma
onde foi Cristo crucificado, de um e outro modo deve ela ser venerada. Primeiro, porque nos representa
a figura de Cristo estendido nela; segundo por causa do contato dos seus membros e por ter sido
embebida do seu sangue. Por onde, de um e outro modo, é adorada pela mesma adoração por que o é
Cristo, isto é, pela adoração de latria. E também por isso dirigimos palavras e oração à Cruz como o
faríamos ao próprio crucificado. — Se porém se trata da efígie da cruz de Cristo, em qualquer outra
matéria por exemplo, pedra ou madeira, prata ou ouro, então veneramos a cruz somente como imagem
de Cristo, que veneramos com adoração de latria, segundo dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A intenção ou a opinião dos infiéis considera a cruz
como o opróbrio de Cristo, mas, pelo efeito que produziu, da nossa salvação, consideramo-la como a
virtude divina dele, com a qual triunfou dos inimigos, segundo o Apóstolo: Despojando os principados e
potestades, os trouxe confiadamente, triunfando em público deles em si mesmo. E por isso, noutro
lugar: A palavra da cruz é na verdade uma estultícia para os que se perdem, mas para os que se salvam,
que somos nós, é ela a virtude de Deus.

RESPOSTA À SEGUNDA. — A cruz de Cristo, embora não fosse unida ao Verbo de Deus, em pessoa, foi-
lhe contudo unida de certo modo, isto é, pela representação e pelo contato. E só por essa razão nós lhe
prestamos reverência.

RESPOSTA À TERCEIRA. — Pela razão do contato dos membros de Cristo, adoramos não só a cruz, mas
também tudo o que é de Cristo. Donde o dizer Damasceno: É' racional adorarmos o lenho precioso
como santificado pelo contato do seu santo corpo e sangue; e também os cravos, as vestes e a lança; e
os seus santos tabernáculos. Mas, tudo isso não representa a imagem de Cristo, como a cruz, chamada
sinal do Filho do Homem, que aparecerá no céu, como diz o Evangelho. E por isso às mulheres disse o
anjo Vós buscais a Jesus Nazareno, que foi crucificado; não disse — lanceado, mas, crucificado. Donde
vem que veneramos a imagem da cruz de Cristo, em qualquer matéria; mas não, a imagem dos cravos
ou de qualquer outra coisa semelhante.

## Art. 5 — Se à Mãe de Deus deve ser prestada a adoração de latria.
O quinto discute-se assim. — Parece que à Mãe de Deus deve ser prestada a adoração de latria.

1. — Pois, a mesma é a honra prestada à mãe do rei, que o é ao rei. Donde o dizer a Escritura: Pôs-se um
trono para a mãe do rei, a qual se assentou à sua mão direita. E Agostinho: No trono de Deus, no tálamo
do Senhor do céu e no tabernáculo de Cristo é também digna de estar a mãe de Deus. Ora, a Cristo é
devida a adoração de latria. Logo, também à sua mãe.

2. Demais. — Damasceno diz que a honra da mãe é referida ao Filho. Ora, ao Filho é devida a adoração
de latria. Logo, também à Mãe.

3. Demais. — A Mãe de Cristo lhe é mais chegada, que a cruz. Ora, à cruz é tributada adoração de latria.
Logo, à Mãe de Cristo deve ser tributada a mesma adoração.
Mas, em contrário, a Mãe de Deus é uma pura criatura. Logo, não lhe é devida a adoração de latria.

SOLUÇÃO. — Sendo a latria devida só a Deus, não o é à criatura; não o é, no sentido em que a
venerássemos em si mesma. Mas, embora as criaturas insensíveis não sejam em si mesmas dignas de
veneração, a criatura racional o é. Por isso, não devemos o culto de latria a nenhuma criatura racional
como tal. Sendo, porém, a bem-aventurada Virgem uma criatura racional, em si mesma, não lhe
devemos a adoração de latria, mas só a veneração de dulia. De maneira mais eminente, contudo, que às
outras criaturas, por ser Mãe de Deus. E por isso dizemos que lhe é devida, não qualquer dulia, mas a
hiperdulia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A mãe do rei não é devida honra igual à que o é ao rei;
mas, é lhe devida uma honra semelhante, em razão de certa excelência. E é o que querem dizer as
autoridades citadas.

RESPOSTA À SEGUNDA. — A honra de Maria é referida ao Filho, porque a mãe deve ser adorada por
causa do Filho. Mas não do modo pelo qual a honra da imagem é referida ao exemplar, pois, a imagem,
considerada me si mesma como uma determinada coisa, de nenhum modo deve ser venerada.

RESPOSTA À TERCEIRA. — A cruz não é digna de veneração considerada em si mesma, como dissemos.
Mas a Santa Virgem é em si mesma digna de veneração. Logo, a comparação não colhe.

## Art. 6 — Se as relíquias dos santos devem de algum modo ser adoradas.
O sexto discute-se assim – Parece que as relíquias dos santos de nenhum modo devem ser adoradas.

1. — Pois não devemos fazer nada que seja ocasião de erro. Ora, adorar as relíquias dos mortos parece
constituir um erro dos gentios, que prestavam honorificência aos mortos. Logo, não devemos honrar as
relíquias dos santos.

2. Demais. — E estulto adorar uma coisa insensível. Ora, as relíquias dos santos são insensíveis. Logo, é
estulto venerá-las.

3. Demais. — O corpo morto não é da mesma espécie que o vivo, e por consequência não é
numericamente idêntico a ele. Logo, parece que depois da morte de um santo, não lhe devemos adorar
o corpo.
Mas, em contrário, Genádio: Cremos sincerissimamente, que devem ser honrados os corpos dos santos
e sobretudo os dos santos mártires. E depois acrescenta: Quem não o admitir não é considerado Cristão,
mas Eumoniano e Vigilanciano.

SOLUÇÃO. — Como diz Agostinho, se as vestes paternas, um anel ou coisas semelhantes tanto mais
queridas são dos filhos, quanto maior o afeto que tinham pelos pais, de modo nenhum devemos
desprezar o corpo que nos é muito mais familiar e muito mais unido, do que qualquer roupa que
usemos; pois, o corpo pertence à própria natureza humana. Por onde é claro, que quem tem afeto por
outrem venera-lhe também o que dele resta, depois da morte; e não só o corpo ou partes do corpo, mas
também certos bens exteriores, como as vestes e outros semelhantes. Ora, é manifesto que devemos
venerar os santos de Deus, como membros de Cristo, filhos e amigos de Deus e nossos intercessores,
Por isso, devemos lhes venerar quais relíquias, com a honra devida, em memória deles; e sobretudo os
seus corpos, que foram os templos e os órgãos do Espírito Santo; que neles habitou e operou, e hão de
assemelhar-se ao. corpo de Cristo pela glória da ressurreição. Por isso, o próprio. Deus honra
convenientemente essas relíquias, fazendo. milagres na presença delas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A razão de Vigilância, cujas palavras são citadas por
Jerônimo no livro que contra ele escreveu, é a seguinte: Vemos introduzido, diz, a pretexto de religião, o
costume mais ou menos igual ao dos Gentios, de adorar, beijando-os, não sei que pósinhos encerrados
em um vaso envolto em pano precioso. Contra o que diz Jerônimo : Afirmo que não adoramos as
relíquias dos Mártires como não adoramos o sol nem a lua nem os anjos, isto é, com adoração de latria.
Mas, honramos as relíquias dos mártires, para adorarmos aquele a quem eles pertenceram; honramos
os servos, para que a honra, a eles tributada redunde para o Senhor. Assim, pois, honrando as relíquias
dos santos, não incidimos no erro dos Gentios, que prestavam culto de latria aos mortos.

RESPOSTA À SEGUNDA. — O corpo insensível não o adoramos, em si mesmo, mas por causa da alma,
que lhe esteve unida e que agora frui de Deus; e por causa de Deus, de que foram os ministros.

RESPOSTA À TERCEIRA. — O corpo de um santo morto não é numericamente idêntico ao de quando
vivia, por causa da diversidade da forma, que é a alma; mas, é lhe idêntico pela identidade da matéria,
que deve de novo unir-se à sua forma.