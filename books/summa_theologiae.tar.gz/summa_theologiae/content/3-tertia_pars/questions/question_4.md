# Questão 4: Da união relativamente ao assumido
Em seguida devemos tratar da união relativamente ao assumido.
E nesta parte, devemos primeiro tratar do que foi assumido pelo Verbo de Deus. Segundo, das coisas
coassumidas, que são as perfeições e os defeitos.
Ora, o Verbo de Deus assumiu a natureza humana e as suas partes. Por isso, sobre esse primeiro
assunto, ocorre uma tríplice consideração. A primeira, relativa à natureza humana em si mesma. A
segunda é relativa às suas partes. A terceira, à ordem da assunção.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a natureza humana era, mais que qualquer outra natureza, apta a ser assumida pelo Filho de Deus.
O primeiro discute-se assim. — Parece que a natureza humana não era, mais que qualquer outra
natureza, apta a ser assumida pelo Filho de Deus.
1 - Pois, diz Agostinho: Nas operações miraculosas, toda a razão da obra é o poder de quem a fez. Ora o
poder de Deus, que operou a Encarnação, obra de um sublime milagre, não é limitado a uma só
natureza; pois, o poder de Deus é infinito. Logo, a natureza humana não era, mais que qualquer outra
criatura, apta a ser assumida por Deus.

2. Demais. — A semelhança é a razão de conveniência, em se tratando da Encarnação de uma pessoa
divina, como se disse. Ora, como em a natureza racional há uma semelhança de imagem, assim, em a
natureza irracional, uma semelhança de vestígio. Logo, como a natureza humana, a criatura irracional
era apta para ser assumida.

3. Demais. — Em a natureza angélica há uma semelhança de Deus mais expressa que em a natureza
humana, como diz Gregório, citando aquilo da Escritura: Tu eras o selo da semelhança. E também os
anjos são, como os homens, susceptíveis de pecado, conforme a Escritura: Entre os seus anjos achou
crime.

4. Demais. — Sendo Deus dotado da suma perfeição, tanto mais semelhança tem uma coisa com ele
quanto mais perfeita é. Ora, a totalidade do universo é mais semelhante com ele que cada uma das suas
partes, entre as quais está a natureza humana. Logo, o universo no seu todo é mais apto para ser
assumido, que a natureza humana.
Mas, em contrário, a Escritura: Achando as minhas delícias em estar com os filhos dos homens. E assim,
parece haver uma certa conveniência de união entre o Filho de Deus e a natureza humana.

SOLUÇÃO. — Dizemos que pode ser assumido o que é como apto para o ser, por uma Pessoa divina. E
essa aptidão não pode ser entendida como uma potência passiva natural, que não se estende ao que
transcende a ordem natural, a qual é transcendida pela união pessoal da criatura com Deus. Donde
resulta que o considerado apto a ser assumido há de sê-lo por congruência com a união referida. Ora,
essa congruência tem um duplo fundamento em a natureza humana; a sua dignidade e a sua
necessidade. A dignidade, porque à natureza humana, enquanto racional e intelectual, é natural atingir
de certo modo o Verbo mesmo, pela sua operação, isto é, conhecendo-o e amando-o. A necessidade,
porque precisava de reparação, sujeita, como o estava, ao pecado original. Ora, estes dois fundamentos-
só em a natureza humana se encontram. Pois, à criatura irracional falta a congruência da dignidade, e à
angélica, a referida necessidade. Donde resulta que só a natureza humana é apta a ser assumida.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As criaturas recebem tal denominação, ou tal outra, pelo
que lhes convém pelas suas causas próprias, e não, pelas causas primeiras e universais. Assim, dizemos
que uma doença é incurável, não por não poder ser curada por Deus, mas por não o poder pelos
princípios próprios do sujeito. Assim, pois, dizemos que uma criatura não é apta para ser assumida, não
para diminuir nada ao poder divino, mas para mostrar a condição da criatura, que não tem essa aptidão.

RESPOSTA À SEGUNDA. — A semelhança de imagem, na natureza humana, depende da medida em que
é capaz de Deus, isto é, de atingi-lo pela sua operação própria, do conhecimento e do amor. Ao passo
que a semelhança de vestígio se funda só numa representação existente na criatura por impressão
divina, e não por poder a criatura irracional, que só tem essa semelhança, atingir a Deus pela sua só
operação. Ora, a quem falta o menos também não convêm o necessário para o mais; assim um corpo
que não é apto a ser aperfeiçoado pela alma sensitiva, muito menos o é o sê-lo pela alma intelectual.
Ora, muito maior e mais perfeita é a união com Deus, pelo ser pessoal, do que a que o é pela operação.
Portanto, à criatura irracional, incapaz da união com Deus pela operação, não convém se lhe unir
pessoalmente.

RESPOSTA À TERCEIRA. — Certos dizem que o anjo não é apto para ser assumido porque tem a sua
personalidade perfeita, desde o princípio da sua criação, pois, não está sujeito à geração nem à
corrupção. Por isso, não podia ser assumido na unidade da pessoa divina, sem que a sua personalidade
ficasse destruída; e isto nem lhe convém à incorruptibilidade da natureza, nem à bondade do
assumente, a quem não é próprio destruir nenhuma perfeição na criatura assumida. Mas, esta opinião
não parece excluir totalmente a congruidade da assunção da natureza angélica. Pois, Deus, pode,
criando uma nova natureza angélica, uni-la a si na unidade da pessoa, e portanto, sem destruir nada que
naquela preexistisse- Mas, como dissemos, falta-lhe a conveniência no tocante à necessidade; pois,
embora, a certos aspectos, a natureza angélica esteja sujeita ao- pecado, contudo, o seu pecado é
irremediável, como demonstramos na Primeira Parte.

RESPOSTA À QUARTA. — A perfeição do universo não é a perfeição de uma pessoa ou suposto, mas a
de um ser uno por posição ou pela ordem. Do qual as múltiplas partes não são aptas a ser assumidas,
como se disse. Donde se conclui que só a natureza humana é apta a ser assumida.

## Art. 2 — Se o Filho de Deus assumiu uma pessoa.
O segundo discute-se assim. — Parece que o Filho de Deus assumiu uma pessoa.

1. — Pois, como diz Damasceno, o Filho de Deus assumiu a natureza humana na sua indivisibilidade (in
átomo), isto é, na sua individualidade. Ora, indivíduo de .natureza racional é a pessoa como está claro
em Boécio. Logo, o Filho de Deus assumiu uma pessoa.

2. Demais. — Damasceno diz que o Filho de Deus assumiu o que infundiu em nossa natureza. Ora, nela
infundiu a personalidade, Logo, o Filho de Deus assumiu uma pessoa.

3. Demais. — Só é absorvido o que existe. Ora, Inocêncio III diz que a pessoa de Deus absorveu a pessoa
do homem. Logo, parece que a pessoa do homem foi primeiramente assumida.
Mas, em contrário, diz Agostinho, que Deus assumiu a natureza do homem e não a pessoa.

SOLUÇÃO. — Dizemos que é assumido o que é tomado para alguma coisa (ad aliquid sumitur). Por
onde, há de necessariamente o assumido ser concebido como anterior à assunção; assim como o que
localmente se move há de ser concebido como anterior ao movimento. Ora, a pessoa não é concebida,
em a natureza humana, como anterior à assunção; mas é, antes, o termo dela, como se disse..Se, pois,
fosse concebida como anterior, ou haveria necessariamente de corromper-se, e então seria assumida
em vão; ou haveria de permanecer, depois da união, e então seriam duas pessoas, uma assumida e
outra assumente, o que é errôneo, como se demonstrou. Donde se conclui, que de nenhum modo o
Filho de Deus assumiu a pessoa humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filho de Deus assumiu a natureza humana na sua
indivisibilidade (in átomo), isto é, num indivíduo que não é outra causa senão o suposto incriado, que é
a pessoa do Filho de Deus. Donde não se segue seja a pessoa a assumida.

RESPOSTA À SEGUNDA. — A natureza assumida não lhe falta uma personalidade própria, não por não
lhe faltar nada do que exige a perfeição da natureza humana, mas por lhe ser acrescentada a união com
a divina Pessoa, a qual é superior à natureza humana.

RESPOSTA À TERCEIRA. — A absorção, nesse caso, não importa na destruição, de nada de
anteriormente existente, mas, num obstáculo àquilo que poderia existir de outro modo. Se, pois, a
natureza humana não tivesse sido assumida pela pessoa divina, essa natureza teria uma personalidade
própria. E por isso dizemos que uma pessoa absorveu outra, embora impropriamente, por não ter a
pessoa divina impedido, pela sua união, que a natureza humana tivesse uma personalidade própria.

## Art. 3 — Se a Pessoa divina assumiu um homem.
O terceiro discute-se se assim. — Parece que a Pessoa divina assumiu um homem.
1 — Pois, diz a Escritura: Bem-aventurado o que elegeste e tomaste para o teu serviço, o que a Glosa
expõe, de Cristo. E Agostinho diz que o Filho de Deus assumiu o homem e sofreu, nele, o que é humano.

2. Demais. — A palavra homem designa a natureza humana. Ora, o Filho de Deus assumiu a natureza
humana. Logo, assumiu o homem.

3. Demais. — O Filho de Deus é homem. Ora, não é um homem, que não assumiu, porque então seria,
por igual razão, Pedro ou qualquer outro homem. Logo, é o homem que assumiu.
Mas, em contrário, a autoridade do Papa e Mártir Felix, citada no Sínodo Efesino: Cremos em Nosso
Senhor Jesus Cristo, nascido da Virgem Maria, porque é o Verbo e o Filho sempiterno de Deus, e não
homem assumido por Deus, de modo que fosse outro, diferente dele. Nem o Filho de Deus assumiu um
homem que fosse outro, diferente dele.

SOLUÇÃO. — Como se disse, o assumido não é o termo da assunção, mas é concebido como anterior à
assunção. Ora, segundo dissemos, o indivíduo no qual é assumida a natureza humana, não é outra coisa
senão a Pessoa divina, que é o termo da assunção. Pois, a palavra homem significa a natureza humana
enquanto lhe é natural existir num suposto. Pois, como diz Damasceno, como o nome Deus significa
aquele que tem a natureza divina, assim o nome homem, o que tem a natureza humana. Por onde, não
há propriedade de expressão quando se diz, que o Filho de Deus assumiu o homem, supondo, como o
exige a verdade das coisas, que em Cristo há um só suposto e uma só hipóstase. Mas, segundo os que
introduzem em Cristo duas hipóstases e dois supostos, conveniente e propriamente se poderia dizer,
que o Filho de Deus assumiu o homem. Por isso, a primeira opinião citada pelo Mestre das Sentenças
concede ter sido o homem o assumido. Mas, essa opinião é errônea, como se demonstrou.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essas locuções não se devem aplicar em sentido
extensivo, como próprias; mas devem ser entendidas piamente, sempre que são empregadas pelos
sagrados Doutores,.de modo que quando dizemos — o homem assumido — signifiquemos que a sua
natureza foi assumida, e que a assunção terminou-se em ser o Filho do Deus, homem.

RESPOSTA À SEGUNDA. — O nome homem significa a natureza humana em concreto, isto é, como
existente num suposto. E portanto, assim como não podemos dizer que o suposto foi assumido, assim
também não que o homem foi assumido.

RESPOSTA À TERCEIRA. — O Filho de Deus não é o homem que ele assumiu, mas aquele cuja natureza
assumiu.

## Art. 4 — Se o Filho de Deus devia ter assumido a natureza humana abstrata de todos os indivíduos.
O quarto discute-se assim. — Parece que o Filho de Deus devia ter assumido a natureza humana
abstrata de todos os indivíduos.

1. — Pois, a assunção da natureza humana foi feita para a salvação comum de todos os homens donde o
dizer o Apóstolo, de Cristo, que é o Salvador de todos os homens, principalmente dos fiéis. Ora, a
natureza, enquanto existente no indivíduo, já não é comum a todos. Logo, o Filho de Deus devia ter
assumido a natureza humana, enquanto abstrata de todos os indivíduos.

2. Demais. — Em tudo, o que é nobilíssimo deve ser o atribuído a Deus. Ora, em cada gênero, o que é
em si mesmo, é principal. Logo, o Filho de Deus devia ter assumido o homem em si mesmo; e esse é,
segundo os Platônicos, a natureza humana separada dos indivíduos. Logo, essa é que o Filho de Deus
devia ter assumido.

3. Demais. — A natureza humana não foi assumida pelo Filho de Deus, na sua significação concreta;
designada pela palavra homem, como se disse. Pois, assim é significada como existente no indivíduo,
segundo do sobredito se colige. Logo, o Filho de Deus assumiu a natureza humana, enquanto separada
dos indivíduos.
Mas, em contrário, diz Damasceno: Deus, o Verbo encarnado, não assumiu aquela natureza que é o
objeto da pura contemplação do espírito. Pois, essa não seria uma verdadeira Encarnação, mas
enganosa e fictícia. Ora, a natureza humana, enquanto separada dos indivíduos, é objeto da pura
contemplação, pois, não tem subsistência própria, como diz Damasceno no mesmo lugar. Logo, o Filho
de Deus não assumiu a natureza humana, enquanto separada dos indivíduos.

SOLUÇÃO. — A natureza do homem, ou de qualquer outro ser sensível, além da existência que tem nos
indivíduos, pode ser entendida a dupla luz: ou como tendo o ser quase por si mesma, independente. da
matéria, segundo o ensinavam os Platônicos; ou enquanto existente no intelecto, humano ou divino.
Ora, por si só a natureza humana não pode subsistir, como o Filósofo o prova; porque a natureza
específica das coisas sensíveis implica a matéria sensível, que lhe entra na definição, como as carnes e os
ossos na definição do homem. Por onde, não pode a natureza humana existir separada da matéria
sensível.
Se, porém, a natureza humana fosse subsistente desse modo, não fora conveniente que o Verbo a
assumisse. — Primeiro, porque o termo dessa assunção é a pessoa. Ora, é contra a natureza de uma
forma comum individuar-se numa pessoa. — Segundo, porque a uma natureza comum não se podem
atribuir senão as operações comuns e universais, pelas quais o homem não merece nem desmerece; e
contudo, a assunção de que se trata foi feita para que o Filho de Deus, pela natureza assumida,
merecesse por nós. — Terceiro, porque a natureza assim existente não é sensível, mas inteligível. Ora, o
Filho de Deus assumiu a natureza humana, para que por meio dela se manifestasse visivelmente aos
homens, segundo a Escritura: Depois disto foi ele visto na terra e conversou com os homens.
Semelhantemente, também não podia ser assumida a natureza humana pelo Filho de Deus, enquanto
ela é existente no intelecto divino. Porque assim, nada mais é senão a natureza divina. E, deste modo, a
natureza humana teria existido abeterno no Filho de Deus.
Semelhantemente, não é conveniente dizer que o Filho de Deus assumiu a natureza humana enquanto
existente no intelecto humano. Porque essa assunção não seria mais do que o ato intelectual de
conceber que ele assumiu a natureza humana, E, nesse caso, se não a assumisse, em a natureza das
coisas, esse conceito seria falso. E a Encarnação teria sido uma Encarnação ficta, como diz Damasceno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filho de Deus encarnado é o Salvador comum de
todos, não por uma comunidade de gênero ou de espécie, atribuída à natureza separada dos indivíduos,
mas por uma comunidade de causa, enquanto que o Filho de Deus encarnado é a causa universal da
salvação humana.

RESPOSTA À SEGUNDA. — O homem em si mesmo não existe em a natureza das coisas, de modo a ter
uma existência separada dos indivíduos, como o ensinavam os Platônicos. Embora certos digam que
Platão entendia que o homem separado só existe no intelecto divino. E assim, não era necessário fosse
assumido pelo Verbo, pois nele existia abeterno.

RESPOSTA À TERCEIRA. — Embora a natureza humana não fosse assumida em concreto, de modo a ser
preconcebida como o suposto da assunção, contudo o foi na sua individualidade, por tê-lo sido para
subsistir num indivíduo.

## Art. 5 — Se o Filho de Deus devia ter assumido a natureza humana em todos os indivíduos.
O quinto discute-se assim. — Parece que o Filho de Deus devia ter assumido a natureza humana em
todos os indivíduos.

1. — Pois, o primário e em si mesmo assumido foi a natureza humana. Ora, o conveniente a uma
natureza em si mesma o é também a tudo o existente nessa mesma natureza. Logo, era conveniente
que a natureza humana fosse assumida pelo Verbo de Deus em todos os seus supostos.

2. Demais. — A Encarnação divina procedeu da caridade divina, donde o dizer o Evangelho: Assim amou
Deus ao mundo, que lhe. deu o seu Filho unigênito. Ora, a caridade nos leva a nos darmos aos amigos o
quanto possível. Ora era possível ao Filho de Deus ter assumido várias naturezas humanas, como se
disse; e pela mesma razão todas. Logo, fora conveniente que o Filho de Deus assumisse a natureza
humana em todos os seus supostos.

3. Demais. — Um agente perito pratica os seus atos pela via mais breve possível. Ora, teria sido uma via
mais breve se todos os homens tivessem sido assumidos à filiação natural, do que, por um Filho natural,
muitos terem recebido a adoção de filhos, como diz o Apóstolo. Logo, a natureza humana devia ter sido
assumida pelo Filho de Deus em todos os seus supostos.
Mas, em contrário, diz Damasceno, que o Filho de Deus não assumiu a natureza humana considerada
especificamente; nem, pois, lhe assumiu todas as hipóstases.

SOLUÇÃO. — Não era conveniente que a natureza humana fosse assumida: pelo Verbo em todos os
seus supostos. — Primeiro, porque desapareceria assim a multidão dos supostos da natureza humana,
que lhe é conatural. Pois, não se devendo considerar, em a natureza assumida, outro suposto além da
Pessoa assumente, como se disse, se não existisse a natureza humana senão assumida, resultaria a
existência de um só suposto da natureza humana, a saber, a Pessoa assumente. — Segundo, porque tal
seria contra a dignidade do Filho de Deus encarnado, enquanto é o primogênito entre muitos irmãos,
segundo a natureza humana, assim como é o primogênito de toda a criatura, segundo a natureza divina.
E teriam então todos os homens a mesma dignidade. — Terceiro, porque era conveniente que, assim
como um suposto divino se encarnou, assim assumisse uma só natureza humana, para haver, de ambos
os lados, unidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ser assumida convém à natureza humana como tal; isto
é, porque não lhe convém em razão da pessoa, assim como convém à natureza divina assumir em razão
da pessoa. Pois, não lhe convém em si mesma, como lhe pertencendo aos princípios essenciais, ou como
uma propriedade natural sua; por cujo modo conviria a todos os seus supostos.

RESPOSTA À SEGUNDA. — O amor de Deus pelos homens se manifesta não só na mesma assunção da
natureza humana, mas sobretudo pelos seus sofrimentos, na natureza humana, pelos outros homens,
segundo aquilo do Apóstolo: Mas Deus faz brilhar a sua caridade em nós, porque, ainda quando eramos
pecadores, morreu Cristo por nós. O que não teria lugar se tivesse assumido a natureza humana em
todos.

RESPOSTA À TERCEIRA. — É por causa da brevidade da via que o agente perito toma, que não faz por
muitos meios o que pode suficientemente fazer por um só. Por isso, foi convenientíssimo que por um só
homem todos os outros fossem salvos.

## Art. 6 — Se era conveniente que o Filho de Deus assumisse a natureza humana da raça de Adão.
O sexto discute-se assim. — Parece que não era conveniente que o Filho de Deus assumisse a
natureza. humana da raça de Adão.

1. — Pois, diz o Apóstolo: Tal pontífice convinha que nós tivéssemos segregado dos pecadores. Ora, mais
segregado seria dos pecadores se não assumisse a natureza humana da raça do pecador Adão. Logo,
parece que não devia ter assumido a natureza humana da estirpe de Adão.

2. Demais. — Em todo gênero, o princípio é, mais nobre que o dele procedente. Se, pois, quis assumir a
natureza humana, devia tê-la assumido, antes, em Adão mesmo.

3. Demais. — Os gentios eram mais pecadores que os Judeus, como diz a Glosa àquilo do Apóstolo: Nós
somos Judeus por natureza e não pecadores dentre os gentios. Se, pois, quis assumir a natureza humana
dos pecadores, devia tê-la assumido, antes, a da raça dos gentios, que a de Abraão, que foi justo.
Mas, em contrário, o Evangelho reduz a geração do Senhor até a de Adão.

SOLUÇÃO. — Diz Agostinho: Deus podia assumir a natureza humana noutra raça que não a desse Adão,
que submeteu todo o gênero humano ao seu pecado. Mas, julgou melhor tirar da raça mesma que tinha
sido vencida, o homem pelo qual queria vencer o inimigo do gênero humano, E isto por três razões. —
Primeiro, porque é próprio da justiça que satisfaça aquele que pecou. E por isso, da natureza
corrompida por Adão devia ser tirado aquele que desse satisfação por toda a natureza. — Segundo,
porque também a maior dignidade do homem exigia que o vencedor do diabo saísse do gênero mesmo
que foi vencido dele. — Terceiro, porque assim também se manifestaria mais o poder de Deus,
assumindo da natureza corrupta e enferma o que devia elevar a um tão alto grau de poder e dignidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cristo devia ser segregado dos pecadores quanto à
culpa, que vinha delir; não quanto à natureza, que vinha salvar, e pela qual devia fazer-se em tudo
semelhante a seus irmãos, como o Apóstolo também o diz. E nisto ainda se lhe manifestou mais
admirável a inocência, que a natureza que assumiu fosse nele de tão grande pureza, apesar de tirada de
uma massa contaminada pelo pecado.

RESPOSTA À SEGUNDA. — Como se disse, aquele que veio tirar os pecados devia necessariamente ser
segregado dos pecadores, quanto à culpa a que Adão estava sujeito e a quem Deus o tirou. do seu
pecado, como diz a Escritura. Pois, era necessário que quem vinha purificar a todos não necessitasse de
purificação; assim como em qualquer gênero de movimento, o primeiro motor é imóvel relativamente a
esse movimento assim como o primeiro alterante é inalterável. Por onde, não era conveniente que
assumisse a natureza humana em Adão mesmo.

RESPOSTA À TERCEIRA. — Porque Cristo devia por excelência ser segregado dos pecadores, quanto à
culpa, dotado que era da suma inocência, foi conveniente que chegassemos a Cristo partindo do
primeiro pecador, mediante certos justos, em que prefulgissem determinados sinais da santidade
futura. E também por isso, no povo do qual Cristo devia nascer, Deus instituiu certos sinais de santidade,
que começaram em Abraão, o primeiro que recebeu a promessa de Cristo e a circuncisão, como sinal da
aliança, que devia se consumar como diz a Escritura.