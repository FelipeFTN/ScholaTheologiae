# Questão 70: Da circuncisão, que precedeu o batismo.
Em seguida devemos tratar dos atos preparatórios ao batismo. E primeiro, do ato preparatório
precedente ao batismo, isto é, da circuncisão. Segundo, dos atos preparatórios simultaneamente
concorrentes com o batismo, a saber, a catequese e o exorcismo.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se a circuncisão foi preparatória e figurativa do batismo.
O primeiro discute-se assim. — Parece que a circuncisão não foi preparatória e figurativa do batismo.

1. — Pois, toda figura tem alguma semelhança com o figurado. Ora, a circuncisão nenhuma semelhança
tem com o batismo. Logo parece que não era preparatória e figurativa do batismo.

2. Demais. — O Apóstolo, falando dos antigos Patriarcas, diz, que todos foram batizados na nuvem e no
mar. Mas não diz que foram batizados na circuncisão. Logo, a proteção da coluna de nuvem e a
passagem do Mar Vermelho foram, mais que a circuncisão, um preparativo para o batismo, que
figuravam.

3. Demais. — Como se disse, o batismo de João foi preparatório ao de Cristo se portanto também a
circuncisão foi preparatória e figurativa do batismo de Cristo, parece que o batismo de João era
supérfluo. O que não é admissível. Logo, a circuncisão não foi preparatória e figurativa do batismo.
Mas, em contrário, o Apóstolo: Vós estais circuncidados de circuncisão, não feito por despojo do corpo
de carne, mas sim na circuncisão de Cristo, estando sepultados juntamente com ele no batismo.

SOLUÇÃO. — O batismo é chamado sacramento da fé porque nele se faz de certo modo profissão de fé,
e nos agrega a comunidade dos fiéis. Ora, a nossa fé é idêntica à dos Antigos Patriarcas, segundo aquilo
do Apóstolo: Nós cremos com o mesmo espírito de fé. Mas, a circuncisão era de algum modo uma
protestação de fé; por isso, mediante ela, os antigos entravam a fazer parte do colégio dos fiéis. Por
onde, é manifesto que a circuncisão era preparatória ao batismo e dele prefigurativa, pois, aos antigos
Patriarcas todas as causas lhes aconteciam a eles em figura, na expressão do Apóstolo, assim como no
futuro punham o objeto da sua fé.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — — A circuncisão tinha semelhanças com o batismo
quanto ao efeito espiritual deste. Pois, assim como na circuncisão extirpava-se uma película carnal,
assim também o batismo nos livra dos nossos hábitos carnais.

RESPOSTA À SEGUNDA. — A proteção da coluna de nuvens e a passagem do Mar Vermelho foram de
certo modo figuras do nosso batismo, pelo qual renascemos da água, simbolizada pelo Mar Vermelho, e
do Espírito Santo, significado pela coluna de nuvem; mas não se fazia por aí nenhuma profissão de fé,
como se dava com a circuncisão: Por isso eram somente duas figuras e não sacramentos. Ao passo que a
circuncisão era também um sacramento preparatório ao batismo; mas figurava o rito exterior do
batismo menos expressivamente que os outros dois símbolos. Por isso o Apóstolo faz, antes, menção
deles que da circuncisão.

RESPOSTA À TERCEIRA. — O batismo de João foi preparatório ao batismo de cristo, quanto ao exercício
do ato. Mas a circuncisão, quanto a profissão da fé, necessária no batismo, como dissemos.

## Art. 2 — Se a circuncisão foi convenientemente instituída.
O segundo discute-se assim. — Parece que a circuncisão foi inconvenientemente instituída.

1. — Pois, como se disse, na circuncisão fazia-se uma profissão de fé. Ora, do pecado do primeiro
homem nunca ninguém pôde livrar-se senão pela fé na Paixão de Cristo segundo aquilo do Apóstolo: Ao
qual propôs Deus para ser vítima de propiciação pela fé no seu sangue. Logo, a circuncisão devia ter sido
instituída logo depois do pecado do primeiro homem, e não no tempo de Abraão.

2. Demais. — Na circuncisão tomava-se o compromisso de observar a lei antiga, como no batismo, o da
nova. Por isso diz o Apóstolo: Protesto a todo homem que se circuncida que está obrigado a guardar
toda a lei. Ora, a observância da lei não foi estabelecida no tempo de Abraão, mas, antes, no de Moisés.
Logo, foi inconvenientemente instituída a circuncisão no tempo de Abraão.

3. Demais. — A círcuncisão era figurativa e reparatória do batismo. Ora, o batismo é oferecido a todos,
conforme àquilo do Evangelho: Ide e ensinai a todos os povos, batizando-os. Logo, a circuncisão não
devia ser instituída para ser observada somente pelo povo dos Judeus, mas por todos os povos.

4. Demais. — A circuncisão carnal deve corresponder à espiritual, como a figura, ao figurado. Ora, a
circuncisão espiritual, feita por Cristo, convém indiferentemente a ambos os sexos; pois em Jesus Cristo
não há homem nem mulher, como diz o Apóstolo. Logo, não foi acertadamente instituída a circuncisão,
que convém só aos homens.
Mas, em contrário, como se lê na Escritura, a circuncisão foi instituída por Deus, cujas obras são
perfeitas.

SOLUÇÃO. — Como dissemos, a circuncisão era preparatória para o batismo, por ser ela uma profissão
de fé em Cristo, que também manifestamos no batismo. Ora, dentre os antigos Patriarcas, Abraão foi o
primeiro a receber a promessa do nascimento futuro de Cristo, como o diz a Escritura: Todas as gentes
da terra serão benditos naquele que há de proceder de ti. E também foi ele o primeiro que se reparou
da sociedade dos infiéis, obedecendo à ordem de Deus, que lhe disse: Sai da tua terra e da tua
parentela. Logo, a circuncisão foi convenientemente instituída em Abraão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Imediatamente depois do pecado dos nossos primeiros
pais, a ciência pessoal de Adão, que tinha sido plenamente instruído nas coisas divinas, comunicava à fé
e à razão natural um vigor bastante forte que tornava inútil então determinar os sinais da fé e os meios
da salvação. Mas cada um manifestava a sua crença mediante os sinais que lhe mais agradavam. No
tempo de Abraão porem diminuía a fé e muitos caíam na idolatria; E também a razão natural se
debilitava pelo aumento da concupiscência da carne, que chegou até aos pecados contra a natureza. Por
isso, então e não antes, foi instituída a circuncisão como uma profissão de fé e para diminuir a
concupiscência carnal.

RESPOSTA À SEGUNDA. — A observância da lei não devia ser imposta senão ao povo já organizado;
pois, a lei se ordena para o bem público, como se disse. Ora, o povo dos fiéis devia congregar-se
mediante um sinal sensível, necessário para se os homens adunarem em qualquer religião, como diz
Agostinho. Por isso era necessário instituir primeiro a circuncisão, que dar a lei. Quanto aos Patriarcas
que viveram antes da lei, instruíam as suas famílias sobre as coisas divinas, a modo de paternas
advertências. Por isso o Senhor disse de Abraão: Eu sei que ele há de ordenar a seus filhos e a toda a sua
família depois dele, que guardem os caminhos do Senhor.

RESPOSTA À TERCEIRA. — O batismo em si mesmo contém a perfeição da salvação, a que Deus chama
todos os homens, segundo àquilo do Apóstolo: Que quer que todos os homens se salvem. Por isso o
batismo é proposto a todos os povos. Ao contrário, a circuncisão não continha a perfeição da salvação;
mas a figurava como devendo ser realizada por Cristo, que havia de nascer do povo judeu. Por isso só a
esse povo foi dada a circuncisão.

RESPOSTA À QUARTA. — A circuncisão foi instituída como um sinal de fé para Abraão, crente que havia
de ser o pai de Cristo que lhe foi prometido; por isso era reservada só aos do sexo masculino. E também
o pecado original, para o qual foi especialmente como remédio, ordenada a circuncisão, transmite-se
pelo pai e não pela mãe, como dissemos na Segunda Parte. Mas O batismo contém a virtude de Cristo,
causa universal da salvação de todos, e remissão de todos os pecados.

## Art. 3 — Se o rito da circuncisão era como devia ser.
O terceiro discute-se assim. — Parece que o rito da circuncisão não era como devia ser.

1. — Pois, a circuncisão, como se disse, é uma profissão de fé. Ora, a fé emana da faculdade cognitiva,
cujas operações têm na cabeça a sua sede principal. Logo, o sinal da circuncisão devia ser feito antes na
cabeça que no membro da geração.

2. Demais. Para o uso dos sacramentos buscamos as matérias de emprego mais comum; assim, a água,
para lavar, e o pão, para nutrir. Ora, para cortar usamos mais comumente de uma faca de ferro do que
de pedra. Logo, a circuncisão não devia ser feita com faca de pedra.

3. Demais. — Assim como o batismo foi instituído como remédio do pecado original, assim também a
circuncisão, como o diz Beda. Ora, atualmente o batismo não é diferido até o oitavo dia a fim de as
crianças não correrem o risco da danação, por causa do pecado original, se morrerem sem batismo.
Logo, não se devia determinar o oitavo dia para a circuncisão, mas devia ser às vezes avançada, assim
como outras vezes era retardada.
Mas, em contrário, àquilo do Apóstolo - E recebeu o sinal da circuncisão - A Glosa determina o referido
rito da circuncisão.

SOLUÇÃO. — Como dissemos, a circuncisão é sinal da fé instituído por Deus, cuja sabedoria não tem
termo. Ora, determinar os sinais convenientes é obra da sabedoria. Por onde, deve-se concluir que o
rito da circuncisão era o que devia ser.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A circuncisão devia ser feita no membro da geração. -
Primeiro, por ser o sinal da fé, pela qual Abraão creu em Cristo, que havia de nascer da sua raça. -
Segundo, porque era remédio do pecado original, que se transmite pelo ato da geração. - Terceiro,
porque tinha por fim diminuir a concupiscência da carne, que sobretudo por esses membros se exerce,
por causa da intensidade do prazer venéreo.

RESPOSTA À SEGUNDA. — A faca de pedra não era de necessidade imprescindível na circuncisão. Por
isso nenhum preceito divino impõe o uso desse instrumento; nem comumente dele usavam outrora os
judeus para circuncidar, nem o usam agora. Mas, a Escritura refere que certas circuncisões famosas
foram feitas com faca de pedra. Assim, conta que Séfora tomou uma pedra agudíssima e circuncidou o
prepúcio de seu filho. E noutro lugar diz: Faze uns canivetes de pedra e circunda segunda vez aos Filhos
de Israel. O que figurava a circuncisão espiritual que Cristo viria fazer e da qual diz o Apóstolo: A pedra
porem era Cristo.

RESPOSTA À TERCEIRA. — O oitavo dia era o determinado para a circuncisão, quer num sentido místico,
pois, na oitava idade, que será a dos ressurrectos. Cristo acabará a circuncisão espiritual, como se fosse
no oitavo dia, quando tirará aos eleitos, não só a culpa, mas também toda penalidade. Quer também
por causa da fragilidade da criança antes do oitavo dia. Por isso, também em relação aos animais
determina a Escritura: Quando nascer um boi ou uma ovelha ou uma cabra, estarão sete dias mamando
debaixo de suas mães, mas ao oitavo dia e daí por diante se poderão oferecer ao Senhor. Outrossim, o
oitavo dia era de necessidade de preceito, de modo que os que o preteriam pecavam, mesmo se fosse
um sábado segundo àquilo da Escritura: Recebe um homem a circuncisão em dia de sábado, por não se
violar a lei de Moisés. Mas não era isso necessário para o sacramento ser válido, pois, os que preteririam
o oitavo dia podiam circuncidar-se depois.
Mas certos dizem quem em perigo iminente de morte poderia o oitavo dia ser avançado. Essa opinião
porém não pode fundar-se nem na autoridade da Escritura nem no costume dos judeus. Por isso
devemos pensar, e melhor, como o diz também Hugo Vitoríno, que o oitavo dia não podia ser avançado
sob nenhuma necessidade. Por isso, àquilo da Escritura. - Eu era unigénito diante de minha mãe, diz a
Glosa que o outro filho de Bersabé não é contado porque, morto antes do oitavo dia, ainda não tinha
recebido nome e, por consequência, não tinha sido circuncidado.

## Art. 4 — Se a circuncisão conferia a graça justificante.
O quarto discute-se assim. — Parece que a circuncisão não conferia a graça justificante.

1. — Pois, diz o Apóstolo: Se a justiça é pela lei, segue-se que morreu Cristo em vão, isto é, sem causa.
Ora, a circuncisão era uma obrigação da lei a ser cumprida, segundo àquilo do Apóstolo: Protesto a todo
o homem que se circuncida, que está obrigado a guardar toda a lei. Logo, se a justiça é pela circuncisão,
Cristo morreu em vão, isto é, sem causa. Ora, isto é inadmissível. Portanto, a circuncisão não conferia a
graça justificativa do pecado.

2. Demais. — Antes da instituição da circuncisão, só a fé bastava para justificar. Assim, diz Gregório: O
efeito que para nós produz a água do batismo, entre os antigos produzia para as crianças, por si só a fé.
Ora, a virtude da fé não sofreu nenhum detrimento pelo mandamento da circuncisão. Logo, a fé só por
si justificava as crianças, e não a circuncisão.

3. Demais. — A Escritura diz que o povo nascido no deserto durante quarenta anos estava por
circuncidar. Se, portanto a circuncisão tirava o pecado original, parece que todos os mortos no deserto,
tanto crianças como adultos, se condenaram. E o mesmo se deve objetar das crianças que morriam
antes do oitavo dia da circuncisão, que não devia ser avançado, como se disse.

4. Demais. — Nada, a não ser o pecado, impede a entrada no reino celeste. Ora, os circuncisos antes da
paixão de Cristo estavam impedidos de entrar no reino celeste. Logo, pela circuncisão os homens não
eram justificados do pecado.

5. Demais. — O pecado original não é perdoado sem o atual, porque é ímpio esperar de Deus meio
perdão, no dizer de Agostinho. Ora, em nenhum lugar se lê que pela circuncisão e remitisse o pecado
atual. Logo, também não era perdoado por ela o original.
Mas, em contrário, Agostinho: Desde que a circuncisão foi instituída no povo de Deus, como o sinal da
justiça pela fé, era capaz de purificar as crianças do pecado original e antigo, assim como também o
batismo começou a ter o poder de renovar o homem desde o tempo em que foi instituído.

SOLUÇÃO. — É opinião comum de todos que na circuncisão é perdoado o pecado original. Certos
porém, disseram que não conferia a graça, só remitia o pecado. E essa é a opinião do Mestre das
Sentenças e da Glosa. Mas é inadmissível, porque a culpa não se perdoa senão pela graça, conforme
àquilo do Apóstolo: Justificados gratuitamente por sua graça, etc. Por isso outros opinaram que pela
circuncisão era conferida a graça, quanto ao efeito da remissão da culpa, mas não quanto aos efeitos
positivos. A fim de não serem obrigadas a dizer que a graça conferida na circuncisão bastava para fazer
cumprir as disposições da lei, sendo assim supérfluo o advento de Cristo. Mas também esta posição não
pode manter-se. Primeiro, porque pela circuncisão era dada às crianças a faculdade de, a seu tempo,
chegarem a glória, efeito último positivo da graça, segundo, porque, na ordem da causa formal os
efeitos positivos têm naturalmente prioridade sobre os privativos, embora se dê o inverso na ordem da
causa material; pois, a forma não exclui a privação, senão informando o sujeito.
E por isso outros disseram, que na circuncisão era conferida a graça, mesmo quanto um certo efeito
positivo o de tornar digno da vida eterna; mas não quanto a todos os efeitos, porque não bastava a
reprimir o estímulo da concupiscência sem a fazer observar as disposições da lei. Opinião essa que
outrora foi à minha. — Mas quem refletir mais acuradamente verá que não é verdadeira. Porque com
uma graça mínima podemos resistir a qualquer concupiscência e evitar todo pecado mortal, Cometido
em transgressão dos mandamentos da lei; pois, uma caridade mínima tem mais amor a Deus que a
cobiça aos milhões de ouro e de prata.
Portanto, devemos concluir que na circuncisão era conferida a graça com todos os seus efeitos, mas de
modo diferente por que o faz o batismo. Pois, este confere a graça por virtude própria, que tem
enquanto instrumento da Paixão já consumada. Ao passo que a circuncisão a conferia enquanto sinal da
fé na Paixão futura de Cristo; de modo que quem recebia a circuncisão professava tal fé, se era adulto,
por si mesmo, e se criança, outro por ela. Por isso diz o Apóstolo: Abraão recebeu o sinal da circuncisão
como selo da justiça da fé. Porque a justiça vem da fé significada; e não da circuncisão significante. E
como o batismo obra como instrumento em virtude da paixão de Cristo, e não a circuncisão, por isso o
batismo imprime o caráter que nos incorpora com Cristo, conferindo mais copiosas graças que a
circuncisão. Pois, a realidade presente é mais eficaz que a simplesmente esperada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procederia se a justiça proviesse da
circuncisão de modo diferente que pela fé na paixão de Cristo.

RESPOSTA À SEGUNDA. — Assim como antes da instituição da circuncisão a fé no Cristo futuro
justificava tanto os adultos como as crianças, assim também depois de ter sido ela dada. Mas antes não
era necessário nenhum sinal manifestativo dessa fé, porque os homens fiéis, separadamente dos infiéis,
ainda não tinham começado a unar-se no culto do Deus único. É contudo provável que os pais fiéis
faziam determinadas preces a Deus pelos seus recém-nascidos, sobretudo quando em perigo de morte,
ou lhes davam alguma bênção, que era um como sinal da fé; assim como os adultos ofereciam por si
mesmos preces e sacrifícios.

RESPOSTA À TERCEIRA. — O povo no deserto, deixando de cumprir o mandamento da circuncisão,
estava escusado quer por não saber quando devia levantar o acampamento, quer porque, como Diz
Damasceno, não lhes era necessário trazer nenhum sinal distintivo, por habitarem separados dos outros
povos. E contudo como diz Agostinho, incorriam em desobediência os que por desprezo o preteriam. —
Parece porém que ninguém morreu incircunciso no deserto; pois, como diz a Escritura, não havia
enfermos nas tribos deles. E parece só terem morrido no deserto os circuncisos no Egito. Se porém
alguns incircuncisos morreram, com eles passou o mesmo que com os mortos antes da instituição da
circuncisão. O que também se deve entender das crianças mortas antes do oitavo dia, na vigência da lei.

RESPOSTA À QUARTA. — A circuncisão delia o pecado original nas suas conseqüências pessoais;
permanecia porém o impedimento de entrar no reino dos céus, inerente à natureza pecadora,
impedimento esse que foi removido pela paixão de Cristo. Por isso também o batismo, antes da paixão
de Cristo, não introduzia no reino. Mas a circuncisão o fazia se tivesse tido lugar depois da paixão de
Cristo.

RESPOSTA À QUINTA. — Os adultos quando circuncisos alcançavam a remissão não só do pecado
original, mas também dos pecados atuais. Não de modo porém que fossem liberados totalmente do
reato da pena, como se dá com o batismo, que confere graças mais copiosas.