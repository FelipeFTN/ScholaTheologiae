# Questão 61: Da necessidade dos Sacramentos.
Em seguida devemos tratar da necessidade dos sacramentos.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se os sacramentos eram necessários à salvação humana.
O primeiro discute-se assim. — Parece que os sacramentos não são necessários à salvação humana.

1. — Pois, diz o Apóstolo: O exercício corporal para pouco é proveitoso. O uso dos sacramentos é uma
espécie de exercício corporal, porque os sacramentos se perfazem pela significação das coisas sensíveis
e das palavras, como se disse. Logo, os sacramentos não são necessários à salvação humana.

2. Demais. — Ao Apóstolo foi dito: Basta-te a minha graça. Ora, não bastaria se os sacramentos fossem
necessários à salvação humana. Logo, os sacramentos não são necessários à salvação humana.

3. Demais. — Posta a causa suficiente nada mais é necessário para o efeito. Ora, a Paixão de Cristo é a
causa suficiente da nossa salvação. Assim, diz o Apóstolo: Se sendo nós inimigos, fomos reconciliados
com Deus pela morte de seu Filho, muito mais, estando já reconciliados, seremos salvos por sua vida.
Logo, os sacramentos não são necessários à salvação humana.
Mas, em contrário, Agostinho diz: Em nome de nenhuma religião, verdadeira ou falsa, podem os
homens adunar-se, se não se associarem num consórcio sob a égide de sinais ou sacramentos visíveis.
Ora, é-lhes necessário à salvação os homens se adunarem num nome de verdadeira religião. Logo, os
sacramentos são necessários à salvação humana.

SOLUÇÃO. — Os sacramentos são necessários à salvação humana por três razões. - Das quais a primeira
deve ser tirada da condição da natureza humana, a que é próprio partir do corpóreo e do sensível para
chegar ao espiritual e ao Inteligível. Ora, concerne à divina Providência prover a cada ser conforme ao
modo da sua condição. E por isso convenientemente a divina sabedoria confere ao homem os auxílios à
salvação sob certos sinais corpóreos e sensíveis, chamados sacramentos. - A segunda razão deve ser
tirada do estado do homem, que pelo pecado sujeitou o afeto às coisas corpóreas. Ora, onde padece
uma doença aí se deve aplicar ao homem um remédio medicinal. Por isso era conveniente Deus
mediante certos sinais corpóreos, aplicar ao homem uma medicina espiritual; pois, se lhe fossem dados
remédios puramente espirituais, a sua alma, presa ao material, não poderia servir-se deles. - A terceira
razão enfim deve ser haurida no exercício da ação humana, que versa principalmente sobre a matéria.
Afim, pois, de não ser duro ao homem o separar-se totalmente dos atos corpóreos, foram-lhe propostos
práticas sensíveis, nos sacramentos, com os quais salutarmente se exerce a evitar as práticas
supersticiosas, consistentes no culto dos demônios, ou outros maus atos que são as práticas
pecaminosas. - Assim, pois, pela instituição dos sacramentos o homem e ensinado por meio do sensível
de conformidade com a sua natureza; humilha-se, reconhecendo-se sujeito às coisas materiais, pois
acha nelas um auxílio; e também fica preservado de más ações pela prática salutar dos sacramentos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O exercício corporal, como tal, de pouco proveito é. Mas
o exercício pelo uso dos sacramentos não é puramente corporal senão, de certo modo, espiritual, isto é,
pela significação e pela causalidade.

RESPOSTA À SEGUNDA. — A graça de Deus é causa suficiente da salvação humana. Mas Deus dá a graça
aos homens segundo o modo que lhes é peculiar. Por isso os sacramentos são necessários aos homens
para conseguirem a graça.

RESPOSTA À TERCEIRA. — A Paixão de Cristo é causa suficiente da salvação humana. Mas nem por isso
daí se segue que os sacramentos não sejam necessários à salvação humana, pois, obram em virtude da
Paixão de Cristo. E a Paixão de Cristo de certo modo se aplica aos homens pelos sacramentos, segundo
aquilo do Apóstolo: Todos os que fomos batizados em Jesus Cristo tomos batizados na sua morte.

## Art. 2 — Se antes do pecado os sacramentos eram necessários ao homem.
O segundo discute-se assim. — Parece que antes do pecado os sacramentos eram necessários ao
homem.

1. — Pois, como se disse, os sacramentos são necessários para o homem alcançar a graça. Ora, mesmo
no estado de inocência o homem precisava da graça, como se estabeleceu na Primeira Parte. Logo,
também nesse estado eram lhe necessários os sacramentos.

2. Demais. — Os sacramentos são necessários ao homem em virtude da condição da natureza humana
como se disse. Ora, a natureza do homem é a mesma tanto antes como depois do pecado. Logo, parece
que também antes do pecado precisava dos sacramentos.

3. Demais. — O matrimônio é um sacramento, segundo aquilo do Apóstolo: este sacramento é grande,
mas eu digo em Cristo e na Igreja. Ora, o matrimônio foi instituído antes do pecado, como o refere a
Escritura. Logo, os sacramentos eram necessários ao homem antes do pecado.
Mas, em contrário; o remédio não é necessário senão ao doente, segundo aquilo do Evangelho: Os sãos
não têm necessidade de médico. Ora, os sacramentos são uns remédios espirituais aplicados contra os
males causados pelo pecado. Logo, não eram necessários antes do pecado.

SOLUÇÃO. — No estado de inocência, antes do pecado, os sacramentos não eram necessários. E a razão
disso podemos descobri-la na retidão desse estado, em que o inferior, longe de reger o superior, era
governado por este; assim como a razão estava sujeita a Deus, assim lhe estavam sujeitas a ela as
potências inferiores da alma; e à alma, o corpo. Ora, iria contra essa ordem se a alma se aperfeiçoasse,
quer quanto à ciência, quer quanto à graça, por algum meio material, como é o caso nos sacramentos.
Por onde, no estado de inocência o homem não precisava de sacramentos, considerados estes não só
como ordenados a serem remédio contra o pecado, mas ainda enquanto ordenados à perfeição da
alma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem, no estado de inocência, precisava da graça;
não porém que a conseguisse por quaisquer sinais sensíveis, mas espiritual e indivisivelmente.

RESPOSTA À SEGUNDA. — A natureza do homem é a mesma tanto antes como depois do pecado; mas o
estado da natureza não é o mesmo. Pois, após o pecado, a alma, ainda na sua parte superior, precisa
apoiar-se nos seres materiais, para conseguir a sua perfeição; o que não era necessário ao homem no
seu estado primeiro.

RESPOSTA À TERCEIRA. — O matrimônio foi instituído no estado de inocência, não como sacramento,
mas como função da natureza. Mas, por consequência, significava algo que havia de dar-se
relativamente a Cristo e à Igreja; como foi o caso de tudo o que precedeu a Cristo e o figurava.

## Art. 3 — Se depois do pecado, antes de Cristo, deviam existir sacramentos.
O terceiro discute-se assim. — Parece que depois do pecado, antes de Cristo, não deviam existir
sacramentos.

1. — Pois, como se disse, pelos sacramentos a Paixão de Cristo é aplicada aos homens; e assim a Paixão
de Cristo está para os sacramentos como a causa para o efeito. Ora, o efeito não precede a causa. Logo,
não devia haver sacramentos antes do advento de Cristo.

2. Demais. — Os sacramentos devem ser convenientes ao estado do gênero humano, como está claro
em Agostinho. Ora, o estado do gênero humano não mudou, depois do pecado, até a reparação feita
por Cristo. Logo, nem os sacramentos deviam ser mudados de modo que além dos sacramentos da lei
natural, outros fossem estatuídos, na lei de Moisés.

3. Demais. — Quanto mais uma coisa está próxima à perfeição, tanto mais se lhe deve assimilar. Ora, a
salvação humana, na sua perfeição, operou-a Cristo, de quem estavam mais próximos os sacramentos
da lei antiga do que os existentes antes da lei. Logo, deviam ser mais semelhantes aos sacramentos de
Cristo. Entretanto, o contrário resulta da predição que o sacerdócio de Cristo havia de ser segundo a
ordem de Melquisedeque e não segundo a ordem de Arão, como está no Apóstolo. Logo, antes de
Cristo, os sacramentos não foram dispostos convenientemente.
Mas, em contrário diz Agostinho, que os primeiros sacramentos, celebrados e observados na vigência da
lei, eram os prenúncios da vinda de Cristo. Ora, era necessário à salvação humana que fosse
preanunciado o advento de Cristo. Logo, era necessário que, antes de Cristo, certos sacramentos fossem
instituídos.

SOLUÇÃO. — Os sacramentos são necessários à salvação humana, enquanto uns sinais sensíveis de
realidades invisíveis pelas quais o homem se santifica. Ora, ninguém pode ser santificado, depois do
pecado, senão por Cristo, ao qual propôs Deus para ser vítima de propiciação pela fé no seu sangue, a
fim de manifestar a sua justiça, a fim de que ele seja achado justo e justificador daquele que tem a fé de
Jesus Cristo. Logo, era necessário que antes do advento de Cristo existissem certos sinais visíveis pelos
quais o homem proclamasse a sua fé no futuro advento do Salvador. E esses sinais se chamam
sacramentos. Por onde é claro que antes do advento de Cristo era necessário fossem instituídos certos
sacramentos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Paixão de Cristo é a causa final dos sacramentos
antigos, que alias, foram instituídos para a significar. Ora, a causa final não tem precedência no tempo,
mas só na intenção do agente. Logo, não havia inconveniente em certos sacramentos terem existido
antes da Paixão de Cristo.

RESPOSTA À SEGUNDA. — O estado do gênero humano, depois do pecado e antes de Cristo, pode ser
considerado a dupla luz. - Primeiro, segundo a natureza da fé. E então permaneceu sempre o mesmo,
porque os homens eram justificados pela fé no advento futuro de Cristo. - A outra luz pode ser
considerado segundo a intenção e a remissão do pecado e o expresso conhecimento de Cristo. Pois no
decurso dos tempos, de um lado o pecado começou a dominar cada vez mais o homem, porque
obnubilando-lhe a razão, não bastavam ao homem, para viver retamente, os preceitos da lei da
natureza, mas foi necessário se determinassem preceitos na lei escrita e, com estes, certos sacramentos
da fé. E também de outro lado era necessário que, no decorrer dos tempos, mais se desenvolvesse o
conhecimento da fé; pois como diz Gregório, no suceder-se dos tempos teve maior incremento o
conhecimento divino. E por isso também foi necessário que, na lei antiga, fossem determinados certos
sacramentos da fé, que tinham no futuro advento de Cristo. Os quais estão para 03 sacramentos
anteriores à lei, como o determinado para o indeterminado. Porque, antes da lei, não foi prefixado
determinadamente ao homem de que sacramentos usasse como o foi pela lei. O que era necessário,
tanto pelo entenebrecimento da lei natural como para ser mais determinada a significação da fé.

RESPOSTA À TERCEIRA. — O sacramento de Melquisedeque, anterior à lei, mais se assemelhava ao
sacramento da lei nova pela matéria; isto é, porque oferecia pão e vinho, como está na Escritura; assim
como também o sacrifício do Novo Testamento se perfaz pelo oferecimento do pão e do vinho. Ao
passo que os sacramentos da lei Mosaica mais se assemelham à realidade significada pelo sacramento,
isto é, a Paixão de Cristo, como é claro no caso do cordeiro pascoal e outros semelhantes. E isto assim a
fim de que se, na continuidade do tempo, permanecesse a mesma espécie de sacramentos, concluir-se-
ía pela continuação do mesmo sacramento.

## Art. 4 — Se, depois de Cristo, deviam existir certos sacramentos.
O quarto discute-se assim. — Parece que depois de Cristo não deviam existir nenhuns sacramentos.

1. — Pois, o advento da realidade faz cessar o figurado. Ora, como diz o Evangelho, a graça e a verdade
foi trazida por Jesus Cristo. Logo, sendo os sacramentos os sinais da verdade ou da figura, parece que
depois da Paixão de Cristo não deviam existir sacramentos.

2. Demais. — Os sacramentos supõem certos elementos, como do sobredito se colhe. Ora, o Apóstolo
diz: Quando éramos meninos, servíamos debaixo dos rudimentos do mundo; mas agora, quando veio o
cumprimento do tempo, já não somos meninos. Logo, parece que não devemos servir a Deus debaixo
dos elementos deste mundo, servindo-nos de sacramentos corpóreos.

3. Demais. — Em Deus não há mudança nem sombra alguma de variação, no dizer da Escritura. Ora,
implica de certo modo mudança da verdade Divina o conferir aos homens na santificação do tempo da
graça, uns sacramentos e, antes de Cristo, outros. Logo, parece que depois de Cristo não deviam ser
instituídos outros sacramentos.
Mas, em contrário, Agostinho diz, que os sacramentos da lei antiga foram suprimidos, porque
cumpridos; e foram instituídos outros, de maior virtude, de mais utilidade, de prática mais fácil e em
menor número.

SOLUÇÃO. — Assim como os antigos Patriarcas foram salvos pela fé na vinda de Cristo, assim também
nós o somos pela fé de Cristo que já nasceu e sofreu a sua Paixão. Mas, os sacramentos são uns sinais
reveladores da fé pelo qual o homem é justificado. Ora, o futuro, o passado e o presente hão de ser
significados por sinais diferentes. Pois, como diz Agostinho uma coisa é enunciada de um modo quando
deve ser feita e, de outro, quando já feita; assim como as expressões - haver de sofrer - e - tendo sofrido
- não soam do mesmo modo. Por isso era necessário existissem na lei nova, certos outros sacramentos,
que significassem o que precedeu a Cristo, além dos da lei antiga, que preanunciavam o futuro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Dionísio, o estado da lei nova é mediatário
entre o da lei antiga, cujo sentido figurado se cumpriu na vigência da lei nova, e o estado da glória, no
qual será manifestada una e perfeitamente toda a verdade. — E portanto, não haverá então nenhum
sacramento. Pois agora, enquanto vemos como por um espelho em enigmas, no dizer do Apóstolo, é-
nos forçoso chegar ao espiritual mediante certos sinais sensíveis; para isso servem os sacramentos.

RESPOSTA À SEGUNDA. — Aos sacramentos da lei antiga o Apóstolo lhes chama rudimentos fracos e
pobres, porque nem continham, nem causavam a graça. E por isso dos que recorriam eles o Apóstolo diz
que serviam a Deus debaixo dos rudimentos do mundo; pois, nada mais eram senão rudimentos deste
mundo. Ao contrário, os nossos sacramentos contêm e causam a graça. Logo, a comparação entre eles
não colhe.

RESPOSTA À TERCEIRA. — Um pai de família não mostra mudança de vontade pelo fato de dar ordens
diversas à sua família, conforme a variação dos tempos, não mandando no inverno o mesmo que manda
no verão. Do mesmo modo, não implica nenhuma mudança em Deus o ter instituído uns sacramentos,
depois do advento de Cristo, e outros no tempo da lei: Pois, aqueles eram apropriados a prefigurar a
graça, e estes o são a manifestar a graça presente.