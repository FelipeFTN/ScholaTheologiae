# Questão 83: Do rito deste sacramento
Em seguida devemos tratar do rito deste sacramento.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se na celebração diste sacramento Cristo é imolado.
O primeiro discute-se assim. — Parece que Cristo não é imolado na celebração deste sacramento.

1. — Pois, diz o Apóstolo: Cristo, com uma só oferenda, fez perfeitos para sempre aos que tem
santificado. Ora, essa oferenda foi a sua imolação. Logo, Cristo não é imolado na celebração deste
sacramento.

2. Demais. — A imolação de Cristo foi feita na cruz, na qual, como diz o Apóstolo, se entregou a si
mesmo por nós outros, como oferenda e hóstia a Deus em odor de suavidade. Ora, na celebração deste
mistério Cristo não é crucificado. Logo, não é imolado.

3. Demais. — Como diz Agostinho, na imolação de Cristo, sacerdote e hóstia se identificam. Ora, não se
identifica o sacerdote com a hóstia na celebração deste sacramento. Logo, a celebração deste
sacramento não é a imolação de Cristo.
Mas, em contrário, Agostinho: Cristo imolou-se uma vez em si mesmo e, contudo todos os dias é
imolado no sacramento.

SOLUÇÃO. — Por duas razões se diz que a celebração deste sacramento é a imolação de Cristo. -
Primeiro, porque, como diz Agostinho, costumamos dar às imagens o mesmo nome que têm os seres
representados por elas, assim, contemplando um quadro ou uma parede pintada, dizemos - aquele é
Cícero, aquel'outro é Salústio. Ora, a celebração deste sacramento, como dissemos, é uma imagem
representativa da paixão de Cristo, que é uma verdadeira imolação. Por isso Ambrósio diz: Em Cristo foi
oferecida uma só vez a hóstia, eficaz para produzir a salvação eterna. Por que, pois, a oferecemos nós
todos os dias? Para recordar a morte de Cristo. - Em segundo lugar, quanto ao efeito da paixão; pois, por
este sacramento tornamo-nos participantes dos frutos da paixão do Senhor. Por isso uma certa oração
dominical secreta diz: Quantas vezes se celebrar a comemoração, outras tantas se renovará a obra da
nossa redenção. Quanto, pois, à primeira razão, poderíamos dizer que Cristo foi imolado mesmo nas
figuras do Testamento Velho. Por isso diz o Apocalipse: Aqueles cujos nomes não esta escritos no livro
da vida do Cordeiro, que foi imolado desde o princípio do mundo. Mas, quanto à segunda, é próprio à
celebração deste sacramento que Cristo seja nele imolado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como Ambrósio diz no mesmo lugar, uma só é a hóstia,
que Cristo ofereceu e nós oferecemos, e não muitas, porque Cristo foi oferecido uma vez só; pois, este
sacrifício é a representação daquele; e assim como o que é oferecido em toda parte é um só corpo e não
muitos, assim também o sacrifício é um só.

RESPOSTA À SEGUNDA. — Assim como a celebração deste sacramento é a imagem representativa da
paixão de Cristo, assim o altar é representativo da sua cruz, na qual Cristo imolou o seu próprio corpo.

RESPOSTA À TERCEIRA. — Pela mesma razão também o sacerdote representa a imagem de Cristo, em
cujo nome e por cujo poder pronuncia as Palavras da consagração, como do sobredito se colhe. E assim,
de certo modo, sacerdote e hóstia se identificam.

## Art. 2 — Se foi convenientemente determinado o tempo da celebração deste mistério.
O segundo discute-se assim. Parece que foi inconvenientemente determinado o tempo da celebração
deste mistério.

1. — Pois, este sacramento é representativo da paixão do Senhor, como dissemos. Ora, a comemoração
da paixão do Senhor se faz na Igreja uma vez no ano. Assim, diz Agostinho: Pois, quantas vezes se
celebra a Páscoa não morre Cristo outras tantas? Contudo a recordação aniversária representa o que
outrora se passou e nos comove como se víssemos o Senhor pendente da cruz. Logo, este sacramento
não deve celebrar-se senão uma vez no ano.

2. Demais. — A paixão de Cristo a comemora a Igreja na sexta-feira antes da Páscoa, mas não na festa
do Natal. Sendo porém este sacramento comemorativo da paixão do Senhor, parece inconveniente
celebrarem-se no Natal três vezes este sacramento, e deixá-lo totalmente de fazer, na Parasceve.

3. Demais. — Na celebração deste sacramento a Igreja deve imitar a instituição de Cristo. Ora, Cristo
consagrou este sacramento de tarde. Logo, parece que deve ser celebrado nessa hora.

4. Demais. — Uma disposição canônica determina, segundo a resposta de Leão Papa (I), a Dióscoro
Alexandrino, bispo, que é lícito celebrar missa na primeira parte do dia. Ora, o dia começa à meia-noite,
como se disse. Logo, parece lícito celebrar também depois de meia-noite.

5. Demais. — Uma certa oração dominical secreta reza: Concede-nos, Senhor, nós te suplicamos, o
freqüentar estes mistérios. Ora, maior será a freqüência se o sacerdote celebrar, mesmo várias horas
por dia. Logo, parece que não deve o sacerdote ser proibido de celebrar várias vezes por dia.
Mas, em contrário, o costume observado pela Igreja segundo o estatuído pelos cânones.

SOLUÇÃO. — Como dissemos, na celebração deste mistério considera-se a representação da paixão do
Senhor e a participação do seu fruto. E tanto em relação àquela como a esta, era necessário determinar
o tempo conveniente à sua celebração. - Pois, como quotidianamente precisamos, por causa dos nossos
quotidianos defeitos, do fruto da paixão do Senhor, todos os dias na Igreja regularmente é oferecido
este sacramento. Por isso o Senhor nos ensinou a pedir: O pão nosso quotidiano nos dai hoje. O que
Agostinho assim expõe: Se o pão é quotidiano, porque esperais um ano para o receber, como os gregos
costumam fazê-lo no Oriente? Recebe todos os dias o que todos os dias te aproveita. Mas, tendo sido a
paixão do Senhor celebrada desde a terceira até a nona hora, por isso regularmente nessa parte do dia a
Igreja celebra solenemente este sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Este sacramento rememora a paixão de Cristo, enquanto
os seus efeitos derivam para os fiéis. Mas no tempo da paixão se remem ora a paixão de Cristo só
enquanto sofrida pelo nosso chefe. E isso só se fez uma vez; ao passo que quotidianamente os fiéis
colhem o fruto da paixão do Senhor. Por isso, ao passo que a primeira comemoração se faz só uma vez
no ano, esta se faz todos os dias, tanto por causa do fruto como para perpetuar a memória da paixão.

RESPOSTA À SEGUNDA. — Com o advento da realidade cessa o figurado. Ora, este sacramento é uma
figura e o exemplo da paixão do Senhor, como se disse. Por onde, no dia mesmo em que se rememora a
paixão do Senhor, enquanto realmente consumada, não se celebra a consagração deste sacramento.
Contudo, para que nem nesse dia a Igreja se veja privada do fruto da paixão conferido pela Eucaristia,
por isso o corpo de Cristo consagra-se no dia antecedente e conserva-se para ser tomado na sexta-feira
da paixão. Não porém o sangue, pelo perigo que correria de ser infundido no chão; e por ser o sangue a
imagem mais especial da paixão do Senhor, como dissemos. Nem é verdade o dito de certos, que pela
introdução de uma partícula do corpo de Cristo no vinho, converte-se este no seu sangue. Pois, isso não
pode dar-se senão pela consagração feita sob a devida forma das palavras. - Quanto ao dia da
Natividade, nele se celebram várias missas, por causa da tríplice natividade de Cristo das quais, uma é a
eterna, oculta para nós; por isso se canta uma missa de noite, em cujo intróito se reza: O Senhor me
disse - Tu és meu filho, eu te gerei hoje. Outra é a temporal, mas espiritual, pela qual Cristo nasce como
um luzeiro em nossos corações, na expressão da Escritura. E por isso se canta uma missa na aurora, em
cujo intróito se reza: A luz refulgirá hoje sobre nós. A terceira é a natividade temporal e corporal de
Cristo, enquanto visivelmente para nós, revestido de carne, nasceu do ventre virginal de Maria: E por
isso se canta a terceira missa em pleno dia, em cujo intróito se reza: Nasceu-nos um menino. Embora se
possa também dizer, ao inverso, que a natividade eterna, em si mesma, dá-se em pleno dia, e por isso
no Evangelho da terceira missa se faz menção da natividade eterna. Mas quanto à natividade corporal,
literalmente, Cristo nasceu de noite, em sinal de que vinha para as trevas de nossa miséria; e por isso na
missa noturna se reza o Evangelho do nascimento corporal de Cristo. Assim como também nos outros
dias em que devemos celebrar ou pedir vários benefícios de Deus, celebram-se três missas no mesmo
dia: uma, da festa; outra, pelo jejum; e uma terceira pelos mortos.

RESPOSTA À TERCEIRA. — Como dissemos, Cristo quis, por último, deixar este sacramento aos seus
discípulos, para que se lhes imprimisse mais profundamente no coração. Por isso, depois da ceia e ao
fim do dia, consagrou-o e deu-o aos discípulos. Celebramo-lo nós porém à hora da paixão do Senhor, a
saber: nos dias festivos, na terceira hora, quando Jesus foi crucificado pelas línguas dos judeus, na
expressão do Evangelho, e quando o Espírito Santo desceu sobre os discípulos. Ou nos dias de trabalho,
na sexta hora, quando foi crucificado às mãos dos soldados, como o narra o Evangelho. Ou nos dias de
jejum, na hora nona, quando, dando um grande grito, se lhe desatou o espírito, segundo o evangelista. -
Pode-se porém retardar a celebração, sobretudo quando se devem fazer ordenações e principalmente
no sábado santo, quer pela duração do ofício, quer por se deverem as ordenações fazer no domingo,
como o dispõe a legislação. - Mas também as missas podem ser celebradas na primeira parte do dia, por
alguma necessidade, por decisão canônica.

RESPOSTA À QUARTA. — Regularmente a missa deve celebrar-se de dia e não de noite, porque o
próprio Cristo, presente neste sacramento, disse: Importa que eu faça as obras de aquele que me
enviou, enquanto é dia; a noite vem, quando ninguém pode obrar. Eu que estou no mundo sou a luz do
mundo. Mas, de modo que se considere como princípio do dia, não a meia-noite: nem também o nascer
do sol, isto é, quando o seu disco aparece a iluminar a terra, mas quando surge a aurora. Pois então,
dizemos ter o sol de certo modo nascido, pelo manifestar-se a claridade dos seus raios. E nesse sentido,
o Evangelho diz que as mulheres chegaram ao sepulcro quando já o sol era nascido, embora tivessem
vindo, ao monumento, quando fazia ainda escuro na expressão do evangelista. E é assim que Agostinho
resolve essa contradição. Na noite do Natal do Senhor, porém, especialmente se celebra a missa,
porque o Senhor nasceu de noite como o diz o direito canônico. - E semelhantemente também no
sábado santo, ao começo da noite, por ter o Senhor ressurgido de noite, isto é, quando ainda fazia
escuro, antes do pleno nascimento do sol.

RESPOSTA À QUINTA. — Como o determina um decreto de Alexandre Papa (II), basta ao sacerdote
celebrar uma missa por dia, porque Cristo sofreu uma vez só e redimiu todo o mundo; e é muito feliz
quem pode celebrar uma missa dignamente. Certos sacerdotes porém celebram uma missa pelos
defuntos, e outra de dia, sendo necessário. Aqueles que porém ousarem celebrar várias missas num dia,
por dinheiro ou para lisonjear seculares, penso que não podem escapar à danação. E Inocêncio III
determina que exceto no dia da Natividade do Senhor - salvo se algum caso de necessidade persuadir o
contrário, - basta ao sacerdote celebrar uma só missa uma vez ao dia.

## Art. 3 — Se é necessário celebrar este sacramento em edifício e vasos sagrados.
O terceiro discute-se assim. — Parece não ser necessário celebrar este sacramento em edifício e vasos
sagrados.

1. — Pois, este sacramento é representativo da paixão do Senhor. Ora, Cristo não sofreu num edifício,
mas ora da porta da cidade, segundo aquilo do Apostolo: Jesus, para que santificasse ao povo pelo seu
sangue, padeceu fora da porta. Logo, parece que este sacramento não deve ser celebrado num edifício,
mas antes, ao ar livre.

2. Demais. — Na celebração deste sacramento a Igreja deve imitar o costume de Cristo e dos Apóstolos.
Ora, o edifício onde primeiro Cristo instituiu este sacramento não era consagrado; antes, era um
cenáculo comum preparado por um chefe de família, como o refere o Evangelho. E conforme a
Escritura, os Apóstolos todos os dias perseveravam unanimemente no templo e, partindo o pão pelas
casas, tomavam a comida com regozijo. Logo, também agora não se deve celebrar este sacramento só
em edifícios consagrados.

3. Demais. — Na Igreja, governada pelo Espírito Santo, nada deve fazer-se de inútil. Ora, inutilmente se
consagra uma igreja, um altar ou coisas semelhantes inanimadas, que não são susceptíveis de graça
nem de virtude espiritual. Logo, não se deviam fazer consagrações de igrejas.

4. Demais. — Só as obras divinas devem ser celebradas com certa solenidade, segundo aquilo da
Escritura: Nas obras das tuas mãos me regozijarei. Ora, a igreja e o altar são consagrados por obra
humana; bem como o cálice, os ministros e o mais. Mas não se celebra na Igreja a comemoração dessas
consagrações. Logo, também não deve ser comemorada com solenidade a consagração de uma igreja
ou de um altar.

5. Demais. — A realidade deve corresponder ao figurado. Ora, no Testamento Velho, figura do novo não
se faziam altares de pedras lavradas. Assim, diz a Escritura: Farme-eis um altar de terra. Se me edificares
porém algum altar de pedra não o edificarás de pedras lavradas. E noutro lugar se manda fazer o altar
de pau de setim revestido de cobre; e também de ouro. Logo, parece que não devia ser costume na
Igreja fazer o altar só de pedra.

6. Demais. — O cálice e a patena representam o sepulcro de Cristo, que foi cavado na pedra, como
lemos no Evangelho. Logo, o cálice deve ser feito de pedra e não só de prata, ouro ou ainda de estanho.

7. Demais. — Assim como o ouro é a matéria mais preciosa para os vasos, assim também os panos de
seda são mais preciosos que os outros. Logo, assim como o cálice se faz de ouro, assim também os
panos do altar devem ser feitos de seda e não só de linho.

8. Demais. — A dispensação e o rito dos sacramentos incumbem aos ministros da Igreja, assim como a
dispensação dos bens temporais depende da ordem dos chefes seculares. Donde o dizer o Apóstolo: Os
homens devem-nos considerar como uns ministros de Cristo e como uns dispensadores dos mistérios de
Deus. O que porém, na dispensação dos bens temporais for feito contra as determinações dos chefes,
será nulo. Se pois as prescrições referidas foram convenientemente estatuídas pelos Prelados da Igreja,
parece que em oposição a elas, o corpo de Cristo não pode ser consagrado. Donde resulta não serem
suficientes as palavras de Cristo para a celebração deste sacramento, o que é inadmissível. Logo, a Igreja
não regulou convenientemente a celebração deste sacramento.
Mas, em contrário, o estatuído pela Igreja é ordenado pelo próprio Cristo, segundo aquilo do Evangelho:
Onde se acham dois ou três congregados em meu nome, ai estou eu no meio deles.

SOLUÇÃO. — As coisas que acompanham a celebração deste sacramento têm dupla significação:
representar o que se passou na paixão do Senhor, e reverenciar este sacramento, em que Cristo está
realmente e não só figuradamente contido. Por isso, consagram-se as coisas que servem à celebração
dele; quer para reverenciar o sacramento, quer para reverenciar a santidade, efeito resultante da paixão
de Cristo, segundo aquilo do Apóstolo: Jesus, para que santificasse ao povo pelo seu sangue, etc.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Regularmente este sacramento deve ser celebrado
numa casa, que é a Igreja, segundo aquilo do Apóstolo: Para que saibas como deves portar-te na casa de
Deus, que é a Igreja de Deus vivo. Pois, fora da Igreja não é lugar do verdadeiro sacrifício, como diz
Agostinho. E como a Igreja não devia encerrar-se nos limites da nação judaica, mas difundir-se por todo
o mundo, por isso a paixão de Cristo não foi celebrada dentro da cidade dos judeus, mas debaixo do
céu, para assim todo o mundo fosse como o templo da paixão de Cristo. – E, contudo dispõe um cânone:
Aos sacerdotes em viagem permitimos celebrar a solenidade da missa, na falta de igreja, a céu aberto ou
em tendas, contanto que haja um altar consagrado e tudo o mais necessário a esse sagrado ministério.

RESPOSTA À SEGUNDA. — Como o edifício onde se celebra este sacramento significa a Igreja e igreja se
chama, é justamente consagrado. Como para representar, a santificação que à Igreja adveio da paixão
de Cristo, quer também para significar a santidade exigida nos que devem receber o sacramento. -
Quanto ao altar, ele significa o próprio Cristo, do qual diz o Apóstolo: Por ele ofereçamos a Deus
sacrifício de louvor. Por isso, a consagração do altar significa a santidade de Cristo, do qual diz o
Evangelho: O santo que há de nascer de ti será chamado Filho de Deus. E também dispõe um cânone:
Determinamos que os altares sejam consagrados não só pela unção do crisma, mas também pela
bênção sacerdotal. Por isso não é lícito regularmente receber este sacramento senão em edifícios
consagrados. Donde a disposição canônica: Nenhum sacerdote ouse celebrar missa senão em lugares
sagrados pelo bispo. E também, por não pertencerem à Igreja os pagãos nem os outros infiéis, por isso
na mesma disposição se lê: Não é lícito santificar uma igreja onde se sepultaram os cadáveres de infiéis
mortos; mas se for apta para nela se consagrar, seja reedificada, depois de retirados dela os corpos e
arrasadas as paredes ou arrancado o madeiramento do lugar. Se porém essa igreja foi antes consagrada,
é lícito nela celebrar missas, contanto que sejam fiéis os nela sepultados. Havendo necessidade porém,
pode este sacramento ser celebrado em casas não consagradas ou violadas, mas com o consentimento
do bispo. Por isso a referida ordenação determina: Estabelecemos que a solenidade da missa não pode
ser celebrada em toda parte, mas em lugares consagrados pelo bispo, ou onde ele permitir que se
celebre. Não contudo sem um altar portátil consagrado pelo bispo. Daí o dispor o mesmo cânone:
Permitimos celebrar, se as igrejas foram queimadas ou consumidas pelas chamas, em capelas com altar
consagrados. Mas como a santidade de Cristo é a fonte de toda a santidade da Igreja, por isso, em caso
de necessidade, basta um altar santificado, para celebrar-se este sacramento. Por isso nunca é
consagrada uma igreja sem altares. Contudo, sem igreja, às vezes é consagrado um altar com relíquias
dos santos, cuja vida está escondida com Cristo em Deus. Donde a disposição canônica: Determinamos
que os altares onde se verificar não haver nenhum corpo ou nenhumas relíquias dos mártires, sejam, se
possível, destuídos pelos bispos que governam a região.

RESPOSTA À TERCEIRA. — A igreja, os altares e outros objetos inanimados tais são consagrados, não por
serem suscetíveis de graça, mas porque, pela consagração, ficam dotados de uma certa virtude
espiritual, que os torna aptos ao culto divino, de modo que tiremos deles aumento à nossa devoção,
que nos faça progredir na vida da graça, salvo se a nossa irreverência o impedir. Por isso diz a Escritura:
Verdadeiramente naquele templo há uma virtude divina; porque aquele mesmo que tem a sua
habitação nos céus, esse mesmo é visitador e protetor daquele lugar. Por isso, antes da consagração são
levadas e exorcizadas, para que, desde então força do inimigo seja destruída. E pela mesma razão, as
igrejas que foram profanadas pelo derramamento de sangue ou por qualquer espécie de torpeza devem
ser reconciliadas: pois pelo pecado aí cometido manifesta·se de alguma forma a ação do inimigo. Por
isso lê-se na mesma distinção: Onde quer que encontreis igrejas dos arianos, sem a menor demora
consagrai· as como católicas por meio de preces e obras divinas. Por isso, certos afirmam com
probabilidade que, entrando numa igreja consagrada, alcançamos a remissão dos pecados venais, como
pela aspersão da água benta, baseados no lugar da Escritura: Abençoaste, Senhor, a tua terra; perdoaste
a maldade do teu povo. E é a razão por que, pela virtude que a consagração confere à igreja, não se
pode reiterar essa consagração. Por isso uma disposição canônica do concílio Niceno, determina: As
igrejas uma vez consagradas a Deus não se lhe deve reiterar a consagração, salvo se forem consumidas
pelo fogo, ou profanadas com derramamento de sangue ou por alguma torpeza. Porque assim como
uma criança, uma vez batizada por qualquer sacerdote, em nome do Padre, do Filho e do Espírito Santo,
não deve ser de novo batizada, assim também em lugar dedicado a Deus não deve ser consagrado de
novo, salvo pelas causas supra-referidas; se contudo conservaram a fé na santa Trindade os que a
consagraram. Do contrário, os que estão fora da Igreja, não podem consagrar. Mas, acrescenta a mesma
disposição: As Igrejas ou os altares, cuja consagração é duvidosa, sejam de novo consagrados. Mas, a
essa razão acresce ainda que as igrejas consagradas, adquirem uma certa virtude espiritual, como diz
uma disposição canônica: A madeira empregada na construção de uma igreja não deve ser usada em
outras obras, salvo em outra igreja; ou deve queimar-se ou dar-se aos frades de um mosteiro para que a
usem; mas não poderão servir ao uso à leigos. E ainda: Quando à pala do altar, o púlpito, os candelabros
e o véu estiverem consumidos pelo uso sejam queimados, sendo as cinzas colocadas no batistério, na
muralha ou atiradas em fossas do pavimento, a fim de não serem calcadas pelos pés dos fiéis.

RESPOSTA À QUARTA. — Como a consagração do altar representa a santidade de Cristo, e a de um
edifício, a santidade de toda a Igreja, por isso se deve celebrar com solenidade a consagração de uma
igreja. E é a razão por que se celebra durante oito dias a solenidade da consagração, para significar a
santa ressurreição de Cristo e dos membros da Igreja. Nem é a consagração da Igreja e do altar obra só
do homem, pois que imprime uma virtude espiritual. Donde a disposição canônica: As cerimônias da
consagração das igrejas devem ser celebradas solenemente todos os anos. E a razão de se celebrarem a
dedicação dos templos durante oito dias. acha-la-eis se lerdes no III livro dos Reis as solenidades da
consagração do templo. (Isto é, VIII, 66).

RESPOSTA À QUINTA. — Dispõe um cânone: Altares, não sendo de pedra, não sejam consagrados com
unção de óleo - O que concorda com a significação deste sacramento. Quer porque o altar significa a
Cristo, como diz o Apóstolo - e esta pedra era Cristo; quer também parque o corpo de Cristo foi
sepultado num monumento de pedra. Concorda ainda com o uso do sacramento, pois, a pedra, sobre
sólida, pode facilmente ser encontrada em toda parte. O que não era necessário na Lei Velha, porque se
fazia num só lugar um único altar. Quanto a se ordenar fosse o altar feito de terra ou de pedras lavradas,
foi por evitar a idolatria.

RESPOSTA À SEXTA. — A referida disposição diz: Outrora os sacerdotes usavam de cálices, não de ouro,
senão de madeira; mas o Papa Zeferino ordenou que se celebrassem as missas com patenas de vidro; e
depois Urbano mandou fosse tudo de prata. Mais tarde, porém, foi estatuído que o cálice do Senhor e a
patena, não sendo de ouro, fossem feitos totalmente de prata; ou pelo menos o cálice fosse de estanho.
Não se fizessem porém de bronze nem de cobre, por criarem o azinhavre, em contato com o vinho, e
por isso provocarem vômitos. Mas ninguém ouse cantar missa com cálice de madeira ou de vidro;
porque a madeira, sendo porosa, ficaria nela restos do sangue consagrado; e o vidro, por frágil, correria
perigo de quebrar-se. O mesmo se diga da pedra. Por isso, pela reverência devida a este sacramento,
ficou estatuído que o cálice fosse feito das matérias referidas.

RESPOSTA À SÉTIMA. — Onde podia fazer-se sem perigo, a Igreja determinou, relativamente a este
sacramento, o que mais expressamente em relação ao corpo, colocado no corporal, como, quanto ao
sangue, posto no cálice. Por onde, embora o cálice não se faça de pedra, o corporal, contudo se faz de
pano de linho, em que o corpo de Cristo foi envolvido. Por isso lemos, na Epístola do Papa Silvestre, a
disposição canônica: Deliberadamente estatuímos qua o sacrifício do altar ninguém ouse celebrá-lo com
pano de seda ou de cor, mas com pano de puro linho consagrado pelo bispo, assim como o corpo de
Cristo foi sepultado envolto num alvo lençol de linho. Deve também ser de linho o pano, por causa da
sua alvura, para significar a pureza da consciência; e por causa do muito trabalho exigido pela sua
preparação, para significar a paixão de Cristo.

RESPOSTA À OITAVA. — Dispensar os sacramentos pertence aos ministros da Igreja; mas a consagração
deles, ao próprio Deus. Por isso, os ministros da Igreja não têm nada que estatuir sobre a forma da
consagração; mas só sobre o uso do sacramento e o modo de o celebrar. Por onde, se o sacerdote
proferir as palavras da consagração sobre a matéria devida, com a intenção de consagrar, sem nada do o
que nos referimos, isto é, sem templo, altar, cálice e corporal consagrados e condições semelhantes
instituídas pela Igreja, consagra realmente o corpo de Cristo; mas gravemente peca, por não observar o
rito da Igreja.

## Art. 4 — Se foram convenientemente ordenadas as palavras proferidas neste sacramento.
O quarto discute-se assim. — Parece que foram inconvenientemente ordenadas as palavras proferidas
neste sacramento.

1. — Pois, este sacramento é consagrado pelas palavras de Cristo, como diz Ambrósio. Logo, nele não se
deve proferir nada mais senão as palavras de Cristo.

2. Demais. — As palavras e os atos de Cristo nós os conhecemos pelo Evangelho. Ora, na consagração
deste sacramento se alude a atos que não estão no Evangelho. Assim, aí não lemos que Cristo, na
consagração deste sacramento, elevasse os olhos para o céu. Semelhantemente, os Evangelhos referem
que Cristo disse - Tomai e comei, sem dizer - todos. Pois, na celebração deste sacramento se diz: Tendo
elevado os olhos ao céu; e de novo: Tomai e comei disto todos. Logo, essas palavras não deviam ser
proferidas na celebração deste sacramento.

3. Demais. — Os demais sacramentos se ordenam à salvação de todos os fiéis. Ora, na celebração
daqueles sacramentos não se faz oração comum pela salvação de todos os fiéis e dos defuntos. Logo,
também não se devia assim proceder neste sacramento.

4. Demais. O batismo é especialmente chamado o sacramento da fé. Logo, o concernente à instrução da
fé deve ser conferido antes no batismo, que neste sacramento; assim, a doutrina Apostólica e a
Evangélica.

5. Demais. — Todo sacramento supõe a devoção dos fiéis. Logo, não se deve, mais por este sacramento
que pelos outros, despertar-lhes a devoção mediante louvores divinos e advertências; por exemplo,
quando se diz - corações para o alto.

6. Demais. — O ministro deste sacramento é o sacerdote, como se disse. Logo, tudo quanto nele se reza
devia ser proferido pelo sacerdote e não, certas coisas pelos ministros e certas outras, pelo coro.

7. Demais. — Este sacramento é certamente obra do poder divino. Logo, é supérfluo o pedido do
sacerdote para que essa obra se cumpra: Cuja oblação tu, Deus, em todos etc.
8 Demais. — O sacrifício da Lei Nova é muito mais excelente que o dos antigos Patriarcas. Logo, o
sacerdote não devia pedir a aceitação desse sacrifício, como o de Abel, Abraão e Melquisedegue.

9. Demais. — O corpo de Cristo, assim como não começa a estar neste sacramento por mudança de
lugar, como dissemos, assim também nem, por esse modo, deixa de nele estar. Logo, não tem lugar a
petição do sacerdote: Ordena sejam estes dons levados ao teu altar pelas mãos do teu santo anjo.
Mas, em contrário, um Decreto diz: Tiago, irmão carnal do Senhor, e Basílio Cesarense Bispo, regularam
a celebração da missa. De cuja autoridade resulta que nada se profere na missa que não deva sê-lo.

SOLUÇÃO. — Este sacramento, compreendendo todo o mistério da nossa salvação, por isso é celebrado
com mais solenidade que todos os outros. E porque lemos na Escritura - Vê onde põe o teu pé quando
entras na casa de Deus; e: Prepara a tua alma antes da oração - por isso, antes da celebração deste
mistério, vem em primeiro lugar a preparação, para se bem fazer o que se segue. - Dessa preparação a
primeira parte é o louvar a Deus, que se faz no intróito, segundo àquilo da Escritura: Sacrifício de louvor
me honrará; e ali o caminho por onde lhe mostrarei a salvação de Deus. E esse louvor é tirado, no mais
das vezes, dos salmos, ou pelo menos é cantado com um salmo; porque, como Dionísio diz, os salmos,
como louvores, abrangem tudo o contido na Escritura. - A segunda parte contém a comemoração da
nossa miséria presente, quando o sacerdote implora misericórdia, dizendo Kyrie Eleison, três vezes pela
pessoa do Pai; três pela pessoa do Filho, quando diz Christe Eleíson; e três pela pessoa do Espírito Santo,
quando acrescenta Kyrie Eleíson. Três súplicas contra a nossa tríplice miséria - da ignorância, da culpa e
da pena; ou para significar que as três pessoas estão reciprocamente uma na outra. - A terceira parte
comemora a glória celeste, a que tendemos depois da miséria presente, quando se diz: Glória a Deus
nas alturas. O que se canta nas festas em que se comemora a glória celeste, e se omite nos ofícios
fúnebres, que só comemoram a miséria da vida presente. - A quarta parte contém a oração que o
sacerdote faz pelo povo, para que seja este digno de tão grandes mistérios. Em segundo lugar vem a
instrução do povo fiel, porque este sacramento é o mistério da fé, como dissemos. - E essa instrução
dispositivamente se faz pela doutrina dos Profetas e dos Apóstolos, lida na Igreja pelos leitores e
subdiáconos. E depois dessa lição o coro canta o gradual, que significa o progresso na vida espiritual; o
aleluia, símbolo da exultação espiritual; ou o trato, nos ofícios fúnebres, que significa os gemidos
espirituais. Porque de tudo isso o povo deve dar mostras. - Pela doutrina de Cristo contida no Evangelho
o povo é perfeitamente instruído; e é lida pelos diáconos, ministros do grau mais elevado. E por crermos
em Cristo, como na verdade divina segundo aquilo do Evangelho - Se eu vos digo a verdade, porque me
não credes? Lido o Evangelho, canta-se o símbolo da fé, pelo qual todo o povo mostra o seu
assentimento à fé, na doutrina de Cristo. Este símbolo se canta nas festas de que se faz nele alguma
menção, como nas de Cristo e da Santa Virgem. E nas dos Apóstolos, que fundaram essa fé, e em outras
semelhantes.
Assim, pois, preparado e instruído o povo, passa o sacerdote à celebração do mistério. E este é
oferecido como sacrifício, e consagrado e tomado como sacramento. E então, primeiro, se realiza a
oblação; segundo, a consagração da matéria oferecida; terceiro, a recepção dela. A oblação de compõe
de duas partes: o louvor do povo no canto do ofertório, símbolo da alegria dos oferentes; e a oração do
sacerdote, que pede seja aceita de Deus a oblação do povo. Por isso disse David: Eu te ofereci alegre
todas estas coisas na simplicidade do meu coração; e eu vi que o teu povo, que aqui está junto, te
ofereceu os seus presentes com grande alegria. E depois diz a oração: Senhor Deus, conserva
eternamente esta vontade. Em seguida vem a consagração, que, primeiro, no prefácio procura
despertar a devoção do povo; por isso adverte-o a ter os corações elevados para o Senhor. Donde,
acabado o prefácio, o povo louva devotamente a divindade de Cristo, dizendo com os anjos: Santo,
Santo, Santo. E a humanidade, com os meninos: Bendito o que vem. - Depois, o sacerdote comemora,
em secreto, primeiro, aqueles por quem oferece o sacrifício, isto é, pela: Igreja universal e pelos que
estão elevados em dignidade; e especialmente certos que oferecem ou por quem é oferecido. - Em
segundo lugar, comemora os santos, quando lhes implora o patrocínio pelo que acabou de recomendar,
ao dizer: Unidos numa mesma comunhão, honremos a memória. - Enfim, terceiro. conclui a petição,
quando diz: Assim, pois esta oblação, etc., para que se faça a oblação por aqueles por quem é oferecido
o sacramento.
Em seguida passa propriamente à consagração. Na qual - primeiro - pede o efeito dela, quando diz: Cuja
oblação tu, ó Deus. - Segundo, faz a consagração, pronunciando as palavras do Senhor quando disse: O
qual, na véspera, etc. - Terceiro, excusa-se da sua ousadia por obediência ao mandado de Cristo, quando
diz: É porque, lembrando-nos. Quarto pede seja aceito de Deus o sacrifício celebrado, quando diz: Sobre
os quais com propício, etc. - Quinto, pede o efeito deste sacrifício e sacramento - primeiro, para os que
o receberem, quando diz: Súplices te rogamos; segundo, para os mortos que já não no podem receber,
quando diz: Lembra-te também, Senhor, etc.; terceiro, especialmente para os sacerdotes mesmos que o
oferecem, quando diz: A nós também, pecadores. A seguir, vem a recepção do sacramento - E primeiro,
o povo é preparado para o receber - primeiramente, pela oração comum de todo o povo, que é a oração
dominical, na qual pedimos - o pão nosso de cada dia nos dai hoje; e também pela oração particular,
que o sacerdote especialmente oferece pelo povo, quando diz livrai-nos, Senhor, nós vo-lo pedimos. -
Segundo, o povo é preparado pela paz, dada quando reza - Cordeiro de Deus; pois, este é o sacramento
da unidade e da paz, como se disse, mas nas missas dos defuntos, nas quais o sacrifício é oferecido, não
pela paz presente, mas pelo descanso dos mortos, omite-se a paz.
Segue-se depois a recepção do sacramento, pelo sacerdote, primeiro, que o distribui depois aos outros;
porque, como diz Dionísio, quem dispensa o sacrifício aos outros deve, primeiro, participar dele. E por
último, a celebração completa da missa termina pela ação de graças - o povo exultando pela recepção
deste mistério, como o significam os cantos depois da comunhão; e o sacerdote, dando graças pela
oração, assim como Cristo, celebrada a ceia com os discípulos, disse o hino, como o referem os
Evangelhos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A consagração se opera pelas sós palavras de Cristo. Mas
é necessário fazer-lhes acréscimos para a preparação do povo, que recebe o sacramento, como
dissemos.

RESPOSTA À SEGUNDA. — Como diz o Evangelho, muitas coisas fez e disse o Senhor, pelos Evangelistas
não referidas. Entre elas está que o Senhor, na Ceia, elevou os olhos para o céu, o que a Igreja o recebeu
pela tradição dos Apóstolos. Pois é racional, que quem, na ressurreição de Lázaro e na oração que fez
pelos discípulos, levantou os olhos para o Pai, como o narra o evangelista, com maior razão o fizesse ao
instituir este sacramento, coisa mais importante. Quanto às expressões - manducate, e não comedite
(comei), não diferem de sentido, nem importa qual delas se diga; sobretudo que essas palavras não
fazem parte da forma, como dissemos. - E o vocábulo – todos, subentende-se entre as palavras do
Evangelho, embora não esteja nele expresso. Pois, Cristo disse: Se não comerdes a carne do Filho do
homem, não tereis vida em vós.

RESPOSTA À TERCEIRA. — A Eucaristia é o sacramento de toda a unidade eclesiástica. Por isto, mais
especialmente neste que nos outros sacramentos, deve-se fazer menção de tudo o concernente à
salvação de toda a Igreja.

RESPOSTA À QUARTA. — Há duas espécies de instrução na fé. - Uma é a dos catecumenos, que acabam
de receber a fé. E essa instrução é dada no batismo. - Outra é a recebida pelo povo fiel, que participa
deste mistério. E essa é dada neste sacramento. Contudo, dela não ficam privadas também os
catecúmenos e os infiéis. Por isso dispõe um cânone: O bispo não proíba a ninguém entrar na igreja e
ouvir a palavra de Deus, quer se trate de gentio, quer de herético ou judeu, até a missa dos
catecúmenos, na qual está contida a instrução da fé.

RESPOSTA À QUINTA. — Este sacramento requer maior devoção que os outros, porque nele está
contido todo Cristo. É também mais geral; porque exige a devoção de todo o povo, porque é o sacrifício
oferecido, e não só dos que o recebem, como se dá com os outros sacramentos. Por isso, no dizer de
Cipriano, o sacerdote, recitado o prefácio, prepara as almas dos seus irmãos, exclamando - Corações
para o alto, e respondendo o povo - Tenhamo-nos ao Senhor, é advertido a pôr. todos os seus
pensamentos em Deus.

RESPOSTA À SEXTA. — Neste sacramento menciona-se, como se disse, o concernente a toda a Igreja.
Por isso, o coro recita certas partes atinentes ao povo. - Dessas, umas o coro as continua até ao fim; e
esses são os sugeridos ao todo o povo. - Outros o sacerdote, que faz as vezes de Deus, começa e o povo
continua; em sinal de que tais coisas, como a fé na glória celeste, chegavam ao povo por divina
revelação. Por isso, o sacerdote começa a recitar o Símbolo da fé e o glória a Deus nas alturas. - Outros
são recitados pelos ministros, como a doutrina do Velho e do Novo Testamento; como sinal que ela foi
anunciada aos povos pelos ministros mandados por Deus. Outras partes porém só o sacerdote é quem
as recita; e são as que lhe concerne ao ofício próprio, que é oferecer dons e sacrifícios pelo povo. Mas,
ai, o concernente ao sacerdote e ao povo, o sacerdote o recita em voz alta, e tais são as orações
comuns. - Mas certas outras, como a oblação e a consagração, concernem só ao sacerdote. Por isso reza
em voz submissa o que a constitui. - Mas em ambas, desperta a atenção do povo, dizendo - O Senhor
seja convosco, esperando o assentimento dos assistentes, com o seu amém. Pela mesma razão diz em
voz alta - O Senhor seja convosco, antes do que diz secretamente, e acrescenta: - Por todos os séculos
dos séculos. - Ou, o que reza secretamente é o sinal de que, na paixão de Cristo, só às ocultas os
discípulos o confessavam.

RESPOSTA À SÉTIMA. — A eficácia das palavras sacramentais pode ficar impedida pela intenção do
sacerdote. - Nem há inconveniente em pedirmos a Deus o que sabemos com certeza ele o fará; assim
Cristo pediu a sua glorificação. - No caso vertente, o sacerdote não ora para que se faça a consagração,
mas para nos ser ela frutuosa; donde o dizer sinaladamente - para que ele se torne para nós o corpo e o
sangue. E isto significam as palavras que proferiu antes: Digna-te tornar esta oblação bendita, isto é,
como o explica Agostinho, pela qual sejamos abençoados, pela graça; aprovada, isto é, pela qual
sejamos recebidos no céu; ratificada, isto é, que por ela sejamos unidos ao coração de Cristo: racionável,
isto é, pela qual sejamos livres do senso animal; aceitável, isto é, a fim de que, descontentes de nós
mesmos por meio dela sejamos aceitáveis ao seu Filho único.

RESPOSTA À OITAVA. — Embora este sacramento seja, em si mesmo, superior a todos os antigos
sacrifícios, contudo os sacrifícios dos antigos foram muito aceitos de Deus, por causa da devoção deles.
Por isso o sacerdote pede que este sacrifício seja aceito de Deus, pela devoção dos oferentes, como o
foram aquel'outros.

RESPOSTA À NONA. — O sacerdote não pede nem que as espécies sacramentais sejam levadas ao céu;
nem que o seja o verdadeiro corpo de Cristo, que lá está sempre. Mas o pede para o corpo místico,
simbolizado neste sacramento; isto é, que as orações, tanto do povo como do sacerdote, os apresente a
Deus o anjo assistente aos divinos mistérios, segundo aquilo da Escritura: Subiu o fumo dos perfumes
das orações dos santos da mão do anjo. Quanto à expressão - sublime altar de Deus - significa ou a
própria Igreja triunfante, a que pedimos sejamos transferidos; ou Deus mesmo, do qual pedimos
participar. Pois, deste altar diz a Escritura: Não subirás por degraus ao meu altar, isto é, não introduzirás
graus na Trindade. - Ou, pelo anjo entende-se o próprio Cristo, o Anjo do grande conselho, que uniu o
seu corpo místico a Deus Padre e à Igreja triunfante. Donde também a denominação de missa; porque
pelo anjo o sacerdote emite (mittit) as suas preces a Deus, como o povo, mediante o sacerdote. Por isso,
no fim da missa o diácono diz, nos dias festivos - Ite, missa est (ide, foi oferecida) isto é, a hóstia a Deus
pelo anjo, de modo a ser de Deus aceita.

## Art. 5 — Se as cerimônias usadas na celebração deste mistério são convenientes.
O quinto discute-se assim. — Parece que as cerimônias usadas na celebração deste sacramento não
são convenientes.

1. — Pois, este sacramento pertence ao Testamento Novo, como o mostra a sua própria forma. Ora, na
vigência do Testamento Novo não se devem observar as cerimônias do Velho, nas quais o sacerdote e os
ministros lavavam-se com água quando iam oferecer o sacrifício. Assim, lemos na Escritura: Arão e os
seus filhos lavarão as suas mãos e os pés, quando houverem de entrar ao altar. Logo, não é conveniente
o sacerdote lavar as mãos na solenidade da missa.

2. Demais. — Como lemos no mesmo lugar, o Senhor mandou que o sacerdote queimasse um incenso
de suave fragrância sobre o altar que estava diante do propiciatório. O que também era uma das
cerimônias do Testamento Velho. Logo, não deve o sacerdote oferecer incenso, durante a missa.

3. Demais. — As cerimônias realizadas nos sacramentos da Igreja não devem reiterar-se. Logo, não deve
o sacerdote reiterar os sinais da cruz sobre este sacramento.

4. Demais. — O Apóstolo diz: Sem nenhuma contradição, o que é inferior recebe a bênção do que é
superior. Ora, Cristo, que está neste sacramento, depois da consagração é muito maior que o sacerdote.
Logo, inconvenientemente o sacerdote benze, depois da consagração, este sacramento, fazendo sobre
ele o sinal da cruz.

5. Demais. — Nos sacramentos da Igreja não deve haver nada que seja ridículo. Ora é ridículo fazer
gesticulações como quando o sacerdote estende os braços, põe as mãos, junta os dedos e se inclina.
Logo, tais coisas se não deviam fazer neste sacramento.

6. Demais. — Também é ridículo o sacerdote voltar-se tantas vezes para o povo, tantas vezes saudá-lo.
Logo, nada disso devia fazer-se na celebração deste sacramento.

7. Demais. —- O Apóstolo diz que Cristo não deve ser dividido. Ora, depois da consagração Cristo está
neste sacramento. Logo, o sacerdote não devia fracionar a hóstia.

8. Demais. — As cerimônias deste sacramento representam a paixão de Cristo. Ora, na paixão, o corpo
de Cristo foi dividido nos lugares das cinco chagas. Logo, o corpo de Cristo devia ser dividido antes em
cinco que em três partes.

9. Demais. — O corpo de Cristo é totalmente consagrado neste sacramento, em separado do sangue.
Logo, não se devia misturar com o sangue uma parte dele.
10. Demais. — Assim como o corpo de Cristo é dado neste sacramento como comida, assim o sangue de
Cristo, como bebida. Ora, à recepção do corpo de Cristo, ao celebrar a missa, não se lhe acrescenta
nenhuma outra comida corpórea. Logo, não devia o sacerdote, depois de ter bebido o sangue de Cristo,
tomar vinho não consagrado.
11. Demais. — O verdadeiro deve corresponder ao figurado. Ora, do cordeiro pascal, que foi a figura
deste sacramento, a lei ordenava que nada se conservasse para o dia seguinte. Logo, não se deviam
conservar hóstias consagradas, mas consumi-las logo.
12. Demais. — O sacerdote fala aos ouvintes, no plural; por exemplo, quando diz - O Senhor seja
convosco (Dominus vobiscum), e, Demos graças (Gratias agamus). Ora, não devemos falar no plural
quando nos dirigimos a um só, sobretudo inferior. Logo, não devia o sacerdote celebrar a missa, estando
presente só um ministro. Por onde, parece que certas práticas deste sacramento são inconvenientes.
Mas, em contrário, o costume da Igreja, que não pode errar, por inspirada pelo Espírito Santo.

SOLUÇÃO. — Como dissemos, para ser mais perfeita a significação, tudo o que se faz nos sacramentos é
significado duplamente por palavras e por atos. Ora, certos passos da paixão de Cristo, representados na
celebração deste sacramento, são significados por palavras. Ou ainda certas causas concernentes ao
corpo místico, que esse sacramento representa; e outras referentes ao uso do mesmo, que deve ser
com devoção e reverência. Por isso, na celebração deste mistério, certas práticas representam a paixão
de Cristo; ou ainda, a disposição do corpo místico; e certas outras concernem a devoção e a reverência
devidas a este sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ablução das mãos se faz, na celebração da missa, pela
reverência devida a este sacramento. E isto por duas razões. - Primeiro, por ser costume geral tocarmos
em coisas preciosas com as mãos lavadas. Por onde, faltaria à decência quem se achegasse a tão grande
sacramento com as mãos sujas, mesmo no sentido material. Segundo, pelo significado da ablução. -
Pois, como diz Dionísio, o lavarmos as extremidades significa a purificação, ainda dos mínimos pecados,
segundo aquilo do Evangelho: Aquele que está lavado não tem necessidade de lavar senão os pés. E
essa purificação é necessária em quem se achega a este sacramento. O que também é significado pela
confissão, que se faz antes do começo da missa. E o mesmo significava a ablução dos sacerdotes da Lei
Velha, conforme o ensina Dionísio no mesmo lugar. - Mas a Igreja não o observa como preceito
cerimonial da Lei Velha, senão como instituído por ela, e na prática em si mesma conveniente. Por isso,
não é observado do mesmo modo por que o era antigamente. Também se omite a ablução dos pés,
conservando-se só a das mãos, por poder fazer-se mais facilmente e por bastar a significar a perfeita
purificação. Pois, sendo as mãos o órgão dos órgãos, na expressão de Aristóteles, todas as obras se lhes
atribuem a elas. Donde o dizer o Salmo: Lavarei as minhas mãos entre os inocentes.

RESPOSTA À SEGUNDA. — Não usamos incensar, como se fosse um preceito cerimonial da lei, mas pelo
determinar a Igreja. Por isso não o fazemos do mesmo modo pelo qual o estatuía a Lei Velha. - E o
fazemos por duas razões. Primeiro, para reverenciar este sacramento: para, que o bom cheiro do
incenso, expulse algum mau odor do local, que pudesse provocar repugnância. Segundo, para
representar o efeito da graça da qual, como de bom odor, Cristo tinha a plenitude; segundo aquilo da
Escritura: Eis o cheiro de meu filho bem como o cheiro de um campo cheio. E o qual deriva de Cristo
para os fiéis, por meio dos ministros, segundo aquilo do Apóstolo: Por nosso meio difunde o cheiro do
conhecimento de si mesmo em todo o lugar. Por isso, depois de incensado todo o altar, que designa a
Cristo, incensam-se os demais, numa certa ordem.

RESPOSTA À TERCEIRA. — O sacerdote, na celebração da missa, faz o sinal da cruz para exprimir a
paixão de Cristo, que na cruz se consumou. Ora, a paixão de Cristo se consumou como que por graus. -
Assim, primeiro, teve lugar a entrega de Cristo, causada por Deus, por Judas e pelos judeus. E isso
significa a tríplice crucesignação, acompanhada das palavras: Estes dons, estes presentes, estes santos
sacrifícios e sem mancha. - Depois foi Cristo vendido, pelos sacerdotes, escribas e fariseus. Para o
significar, o sacerdote faz de novo por três vezes o sinal da cruz, dizendo: Bendita, aprovada, ratificada.
Ou para mostrar o preço da venda, que foram os trinta dinheiros. E acrescenta duplo sinal da cruz, às
palavras - A fim de que para nós o corpo e o sangue, etc., a fim de designar a pessoa de Judas, o
vendedor, e o de Cristo, o vendido. - Em terceiro lugar, na Ceia foi prenunciada a paixão de Cristo. Para
designá-lo o sacerdote faz, em terceiro lugar, o sinal da cruz por duas vezes - uma ao consagrar o corpo;
outra, ao consagrar o sangue, dizendo em ambas as vezes - Abençoou. - Em quarto lugar, consumou-se a
paixão mesma de Cristo. E, para representar as cinco chagas de Cristo o sacerdote faz pela quarta vez
um quintuplo sinal da cruz, dizendo: a hóstia pura, a hóstia santa, a hóstia imaculada, o pão santo da
vida eterna e o cálice de salvação perpétua. Em quinto lugar, representa a tensão do corpo, a efusão do
sangue e o fruto da paixão, um triplice sinal da cruz, acompanhado das palavras - recebermos o
sacrosanto do corpo e o sangue, enriquecidos de todas as bênçãos etc. - Em sexto lugar é representada
a tríplice oração que Cristo fez na cruz. - Uma pelos seus perseguidores, quando disse: Pai, perdoai-lhes.
A segunda - para libertar-se da morte, quando disse: Meu Deus, meu Deus, por que me abandonaste? A
terceira, para alcançar a glória, quando exclamou: Pai em tuas mãos entrego o meu espírito. E para
significá-lo, o sacerdote faz três vezes o sinal da cruz, dizendo: santificas, vivificas, abençoas etc. - Em
sétimo lugar, representam-se as três horas durante as quais ficou suspenso na cruz, isto é, desde a sexta
até a nona hora. E para significá-lo, faz de novo o sacerdote por três vezes o sinal da cruz, pronunciando
as palavras - por ele, com ele e nele. - Em oitavo lugar, representa-se a separação entre a alma e o
corpo, por duas crucesignações subseqüentes, fora do cálice. - Enfim, em nono lugar, é representada a
ressurreição operada no terceiro dia, por três cruzes, acompanhadas das palavras: A paz do Senhor
esteja sempre convosco. - Mas, podemos dizer, mais brevemente, que a consagração deste sacramento
e a aceitação deste sacrifício, bem como o seu fruto, procedem da virtude da cruz de Cristo. Por isso,
sempre que o sacerdote fizer menção de alguma dessas três coisas, faz o sinal da cruz.

RESPOSTA À QUARTA. — O sacerdote, depois da consagração, não faz o sinal da cruz para benzer e
consagrar, mas só para comemorar o sinal da cruz e o modo da paixão de Cristo, como do sobredito se
colhe.

RESPOSTA À QUINTA. — Nenhum dos gestos do sacerdote, na missa, constitui gesticulação ridícula, pois
têm o fim de representar alguma coisa. - Assim, o estender os braços depois da consagração significa o
Cristo com eles estendidos na cruz. - Também levanta as mãos ao orar, para significar que a sua oração
se dirige a Deus, pelo povo, segundo aquilo da Escritura - Levantemos ao Senhor os nossos corações
com as mãos para os céus. E noutro lugar: Quando Moisés tinha as mãos levantadas vencia Israel. -
Quando põe as mãos, inclina-se, orando súplice e humildemente, designa assim a humildade e a
obediência com que Cristo sofreu. Junta os dedos polegar e índice, com que tocou o corpo consagrado
de Cristo a fim de que não se disperse alguma partícula que a eles se tivesse apegado. O que constitui
reverência para com o sacramento.

RESPOSTA À SEXTA. — O sacerdote volta-se cinco vezes para o povo, para significar que o Senhor se
manifestou cinco vezes no dia da ressurreição, como dissemos quando tratamos da ressurreição de
Cristo. - Saúda sete vezes o povo – isto é, cinco vezes quando se volta para ele; e duas, em que não se
volta, isto é, quando ante, do prefácio diz - O Senhor seja convosco (Dominus vobiscum); e quando diz -
A Paz do Senhor seja sempre convosco, para designar a septiforme graça do Espírito Santo. Quanto ao
bispo, quando celebra nos dias festivos, diz, na primeira saudação - A paz seja convosco, o que depois da
ressurreição o Senhor o disse aos discípulos, cujas pessoas sobretudo as representa o bispo.

RESPOSTA À SÉTIMA. — A fração da hóstia significa três causas. Primeiro, a divisão mesma do corpo de
Cristo, que se operou na paixão. Segundo, a distinção do corpo místico em diversos estados. Terceiro, a
distribuição das graças procedentes da paixão de Cristo, como diz Dionísio. Por onde, tal fração não
induz divisão de Cristo.

RESPOSTA À OITAVA. — Como diz Sérgio Papa: Triforme é o corpo do Senhor. A parte oferecida, posta
no cálice, representa o corpo de Cristo já ressurrecto. Isto é, o próprio Cristo e a Santa Virgem, ou outros
santos já em corpo na glória. A parte que se come significa os que ainda vivem nesta terra; pois, os
peregrinos neste mundo se unem com Cristo pelo sacramento; e ficam alquebrados pelo sofrimento
como o pão comido é triturado pelos dentes. A parte remanescente no altar até o fim da missa significa
o corpo jacente no sepulcro; porque até o fim dos séculos os corpos dos santos estarão nos sepulcros;
mas as almas estão no purgatório ou no céu. Este rito porém não se observa atualmente, isto é, o de
conservar uma parte até ao fim da missa. Mas permanece a mesma significação das partes. O que certos
exprimiram em versos, dizendo: A hóstia se divide em partes; molhada, significa os que gozam da plena
beatitude; seca, os vivos; conservada, os sepultos. Certos porém dizem, que a parte posta no cálice
significa os viventes neste mundo; a conservada fora do cálice significa os plenamente bem
aventurados, isto é, em corpo e alma; a parte comida significa os outros.

RESPOSTA À NONA. — O cálice pode ter dupla significação. - Numa, é a paixão mesma, representada
neste sacramento. E então, a parte posta no cálice significa os ainda participantes dos sofrimentos de
Cristo. - Noutra significação pode simbolizar o gozo dos bem aventurados, também prefigurado neste
sacramento. Por onde, aqueles cujos corpos já gozam da plena beatitude são simbolizados pela parte
posta no cálice. - E devemos notar que a parte posta no cálice não deve ser dada ao povo como
complemento da comunhão, porque o pão molhado Cristo não o deu senão ao traidor Judas.

RESPOSTA À DÉCIMA. — O vinho, em razão da sua umidade, serve para lavar. Por isso, é tomado depois
da suscepção deste sacramento, para lavar a boca, para que nenhuma partícula nela fique; o que
constitui reverência para com este sacramento. Por isso, uma disposição canônica determina: O
sacerdote deve sempre lavar a boca com o vinho, depois de ter recebido completamente o sacramento
da Eucaristia; salvo se dever no mesmo dia celebrar outra missa; a fim de que o vinho tomado para lavar
a boca não impedisse celebrar outra vez. E pela mesma razão lava com vinho os dedos, com que tocou o
corpo de Cristo.

RESPOSTA À UNDÉCIMA. — A verdade deve, de certo modo, corresponder à figura; porque não deve a
parte da hóstia consagrada, da qual o sacerdote e os ministros ou também o povo comungam, ser
conservada para o dia seguinte. Por isso uma determinação do Papa Clemente estatuiu: Tantas hóstias
se ofereçam no altar, quantas bastem para o povo. As que sobrarem não se reservem para o dia
seguinte; mas sejam consumidas pela diligência dos clérigos, com temor e tremor. - Mas devendo este
sacramento ser recebido todos os dias, o que não se dava com o cordeiro pascal, por isso é necessário
conservar outras hóstias consagradas para os enfermos. Por onde, na mesma legislação se dispõe: O
presbítero tenha sempre preparada a Eucaristia de modo que quando alguém adoecer, dê-lhe logo a
comunhão, não vá morrer sem ela.

RESPOSTA À DUODÉCIMA. — Na celebração solene da missa, vários devem estar presentes. Donde o
dizer o Papa Sotero: Também isto foi estabelecido, que nenhum sacerdote ouse celebrar as solenidades
da missa sem dois ministros presentes, que lhe respondam, a ele como terceiro; porque, quando diz no
plural - O Senhor seja convosco (Dominus vobiscum); e a oração secreta - Orai por mim, é necessário
evidentemente que lhe alguém responda à saudação. Por isso, para maior solenidade, lemos no mesmo
lugar como estatuída, que o bispo celebre, com vários ministros, a solenidade da missa. Mas, nas missas
privadas, basta haver um ministro, representante de todo o povo católico, em nome do qual responde
no plural ao sacerdote.

## Art. 6 — Se se pode obviar suficientemente às deficiências ocorrentes. na celebração deste sacramento, observando-se às determinações da Igreja.
O sexto discute-se assim. — Parece que não se pode obviar suficientemente às deficiências ocorrentes
na celebração deste sacramento, observando-se as determinações da Igreja.

1. — Pois. pode acontecer que o sacerdote, antes ou depois da consagração, morra, fique alienado ou
impedido por qualquer outra doença de receber o sacramento e acabar a missa. Logo, não poderá
cumprir a determinação da Igreja, que ordena ao sacerdote participar do seu sacrifício, depois de haver
consagrado.

2. Demais. — Pode acontecer que o sacerdote, antes ou depois da consagração se lembre de ter comido
ou bebido ou de estar em estado de pecado mortal, ou excomungado, do que antes não se lembrava.
Logo e necessariamente, quem está nessa situação, peca mortalmente agindo contra o estatuído pela
Igreja, quer receba quer não receba o sacramento.

3. Demais. — Pode acontecer que, depois da consagração, caia no cálice uma mosca, uma aranha ou um
animal venenoso. Ou ainda que o sacerdote tenha conhecimento de ter sido posto veneno no cálice por
algum malévolo, para matá-lo. Em cujo caso recebendo o sacramento, pecará mortalmente suicidando-
se ou tentando a Deus. Semelhantemente se não o receber, peca agindo contra o estatuído pela Igreja.
E assim ficará perplexo e sujeito à necessidade de pecar. O que é inadmissível.

4. Demais. — Pode acontecer por negligência do ministro, que não foi posta água no cálice ou nem
vinho, e o sacerdote o descobre. Logo, também neste caso ficará perplexo: quer tomando o corpo sem o
sangue, caso em que fará um sacrifício imperfeito; quer não tomando nem o corpo nem o sangue.

5. Demais. — Pode acontecer que o sacerdote não se lembre de ter pronunciado as palavras da
consagração ou ainda outras que são ditas na celebração deste sacramento. Logo, neste caso pecará,
quer reiterando as palavras sobre a mesma matéria, as quais talvez já pronunciasse; quer usando do pão
e do vinho não consagrados, como se o tivessem sido.

6. Demais. — Pode acontecer, por causa do frio, que o sacerdote deixe cair à hóstia no cálice, quer
antes, quer depois da fração. Neste caso não poderá observar o rito da Igreja quanto à fração, ou a
disposição que só a terça parte dela deve ser posta no cálice.

7. Demais. — Pode acontecer, por negligência do sacerdote, que o sangue de Cristo se derrame; ou
ainda que vomite o sacramento tomado; ou também que as hóstias conservadas o sejam a ponto de
putrefazerem-se; ou mesmo, que sejam roídas pelos ratos; ou enfim, perdidas de qualquer maneira. Em
cujos casos não poderá prestar a este sacramento a reverência devida, segundo o estatuído pela Igreja.
Logo, parece que a tais deficiências ou perigos não pode o sacerdote obviar, observando-se as
determinações da Igreja.
Mas, em contrário, como Deus, também a Igreja nada manda de impossível.

SOLUÇÃO. — Aos perigos ou deficiências ocorrentes com este sacramento pode o sacerdote obviar de
dois modos. Primeiro, prevenindo, para não haver perigo. Depois, reparando, isto é, emendando o
acontecido ou dando remédio, ou pelo menos arrependendo-se do que fez negligentemente na
consagração do sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O sacerdote surpreendido pela morte ou por uma grave
enfermidade, antes da consagração do corpo e do sangue do Senhor, não deve ser substituído por
outro. - Mas se isso se der depois de começada a consagração, por exemplo, depois de consagrado o
corpo e antes da consagração do sangue, ou ainda depois da consagração de ambos, a celebração da
missa deve ser continuada por outro. Por onde, como está nas Decretais, lemos no Concílio Toledano:
Somos de parecer que, o sacerdote sendo surpreendido por uma enfermidade, estando a ponto de
consagrar, na missa, os santos mistérios, de modo a não poder terminar a consagração, possa então o
bispo ou outro presbítero continuar a consagração começada. Pois, começados, os santos mistérios
nenhum outro complemento podem ter, senão o da bênção completa do sacerdote que os iniciou do
que os acabar; porque não podem ser considerados perfeitos senão celebrados exatamente na ordem
prescrita. Porquanto, sendo nós, todos, um só, em Cristo, a diversidade de pessoas nenhuma
contrariedade causa, onde a unidade da fé é o sinal da eficácia da ação. Nem degenera em abuso,
inspirado na presunção, o estabelecido para obviar às misérias da nossa natureza. Assim, nenhum
ministro ou sacerdote, sem ser claramente surpreendido pela doença, ouse de nenhum modo deixar
imperfeita a celebração começada. E o temerário que ousar fazê-lo incorrerá na sentença de
excomunhão.

RESPOSTA À SEGUNDA. — Ocorrendo uma dificuldade, devemos sempre obviá-la por onde se oferece
um perigo menor. Ora, mais perigoso é, no caso vertente, o que vai contra a perfeição deste
sacramento; porque tal é um enorme sacrilégio. Menor perigo porém é o relativo à qualidade de quem
o recebe. Por onde, o sacerdote que, depois de começada a consagração se lembra de ter comido ou
bebido, deve contudo, terminar o sacrifício e receber o sacramento. Semelhantemente, se se lembrar
de ter cometido um pecado, deve arrepender-se com o propósito de o confessar e satisfazer; e então
não receberá como indigno o sacramento, mas, frutuosamente. - E o mesmo deveremos dizer de quem
se lembrar que está excomungado. Pois deve fazer o propósito de pedir humildemente a absolvição; e
assim, pelo invisível Pontífice Jesus Cristo, alcançará a absolvição no tocante ao ato de celebrar os
divinos mistérios. - se se lembrar porém, de alguma dessas coisas supra referidas, mais seguro julgaria
eu, sobretudo no caso da quebra do jejum e da excomunhão, que deixasse a missa começada, salvo se
temesse grave escândalo.

RESPOSTA À TERCEIRA. — Se, antes da consagração, cair uma mosca ou aranha no cálice, ou o
sacerdote verificar que nele foi posto veneno, deve pôr fora o vinho, lavar o cálice e de novo deitar nele
vinho para ser consagrado. - Se porém o incidente se der depois da consagração, deve tomar o animal
com cautela, lavá-lo diligentemente, queimá-lo e pôr no sacrário a água da ablução com as cinzas. - Se
porém verificar que foi posto veneno, de nenhum modo deve beber o cálice, nem o dar a outrem, a fim
de que não redunde em morte o cálice da vida. Mas deve diligentemente conservar o líquido num
pequeno vaso, para isso preparado, junto com as relíquias. E a fim de o sacramento não ficar imperfeito,
deve pôr outro vinho no cálice e de novo retomar o sacrifício, desde a consagração do sangue, para que
não fique imperfeito.

RESPOSTA À QUARTA. — O sacerdote, percebendo, antes da consagração do sangue e, depois da
consagração do corpo, que não há vinho ou água no cálice, deve pô-los logo e consagrar. - Percebendo
porém, depois da consagração, a falta da água, deve sem tempo continuar; porque a mistura da água
não é de necessidade para o sacramento, como dissemos. Deve porém ser punido quem foi a causa,
dessa negligência. Mas de nenhum modo deve ser misturada água com o vinho já consagrado, o que
causaria a corrupção parcial do sacramento, como dissemos. - Percebendo porém, depois das palavras
da consagração, que não foi posto vinho no cálice, se o perceber antes de receber o corpo, deve, posta
fora a água que já ele contivesse, nele introduzir vinho com água e recomeçar desde as palavras da
consagração do sangue. - Mas se o perceber, depois de ter tomado o corpo, deve colocar outra hóstia a
ser consagrada de novo juntamente com o sangue. E assim o digo porque, se o sacerdote pronunciasse
e só as palavras da consagração do sangue, não observaria a ordem devida na consagração; ora, como
dispõe o referido capítulo do concílio Toledano, não se podem considerar perfeitos os sacrifícios, se não
se observar a ordem presente. Pois, se o sacerdote recomeçasse da consagração do sangue e repetisse
todas as palavras subsequentes, não produziriam efeito se já não estivesse sobre o altar uma hóstia
consagrada. Porque há, na seqüência do canon, certas palavras e certos atos concernentes não só ao
sangue, mas também ao corpo. E deve o sacramento, no fim, de novo tomar a hóstia consagrada e o
sangue, sem embargo de já ter tomado a água que estava antes no cálice. Porque o preceito relativo à
perfeição do sacramento é de maior peso do que o em virtude do qual deve ser tomado em jejum, como
dissemos.

RESPOSTA À QUINTA. — Embora o sacerdote não se lembre se já pronunciou certas palavras que
deveria ter pronunciado, nem por isso se lhe perturba o espírito. Pois, quem muito disse não pode
lembrar-se de tudo o que disse, a menos que não apreenda o que disse, sob a razão de já dito; sendo
assim que as coisas se tornam objeto da memória. Por onde, quando pensamos atentamente no que
dizemos, mas pensamos que o dizemos, não muito depois nos lembramos de o haver dito. E é assim que
as coisas se tornam objetos da memória pelas tomarmos, enquanto passadas, como o ensina
Aristóteles. - Se pois, o sacerdote constar com probabilidade que omitem certas coisas, se estas não
forem de necessidade para o sacramento, não penso que por isso as deva repetir, alterando a ordem do
sacrifício, mas deve continuar o sacrifício. - Se porém se certificar que omitiu algo de essencial ao
sacramento, por exemplo, a forma da consagração, sendo esta de tanta necessidade, para o sacramento
como a matéria, então deve fazer o mesmo que dissemos quanto à falta da matéria; isto é, repetir a
forma da consagração e o mais, conforme a ordem para não alterar a seqüência do sacrifício.

RESPOSTA À SEXTA. — A fração da hóstia consagrada e o ato de colocar-se só uma parte dela no cálice,
respeita o corpo místico; assim como a mistura da água significa o povo. Por onde, a omissão destes
atos não induz imperfeição do sacramento, a ponto de ser necessário reiterar nada em a celebração
dele.

RESPOSTA À SÉTIMA. — Assim dispõe um decreto do Papa Pio (I): Se por negligência cair uma gota de
sangue na tábua aderente ao chão seja absorvida com a língua e a tábua arrancada. Se não houver
assoalho, a terra seja raspada e consumida no fogo e a cinza depositada dentro do altar. E o sacerdote
faça penitência por quarenta dias. - Se porém o cálice gotejar sobre o altar, o ministro absorva as gotas.
E faça penitência por três dias. - Se as gotas caírem sobre a primeira toalha do altar penetrar até a
segunda, faça penitência por quatro dias. Se penetrar até a terceira, faça nove dias de penitência. Se até
a quarta, vinte dias de penitência. E os panos que foram umedecidos, pelas gotas, o ministro os lave por
três vezes, recebendo a água o cálice, tome a água da ablução e a ponha perto do altar. Poderia também
ser bebida pelo ministro, se não temer rejeitá-la, pela repugnância. Certos, além disso, cortam e
queimam a parte do pano que foi molhada e depositam as cinzas no altar ou no sacrário. Mas na mesma
disposição legal se acrescenta: Quem por voracidade ou embriaguez expulsar, por vômito, a Eucaristia,
faça penitência por quarenta dias, sendo leigo; os clérigos ou monges, ou diáconos e presbíteros, por
setenta dias o bispo, por noventa. Se a expulsar em vômitos, por doença, taça sete dias de penitência. E
no mesmo assunto, dispõe o Concílio Aurelianense: Quem não guardar bem o sacramento, de modo que
um rato ou qualquer outro animal o coma na igreja, faça quarenta dias de penitência. - Quem o perder
na igreja ou lhe deixar cair uma parte, que não mais se ache faça trinta dias de penitência. - E da mesma
penitência é digno o sacerdote por cuja negligência as hóstias consagradas vierem a putrefazer-se.
Assim, nos referidos dias o penitente deve jejuar e abster-se da comunhão. Ponderadas porém as
condições do caso e da pessoa, a penitência em questão pode ser aumentada ou diminuída. Deve-se
porém notar, que em toda parte onde as espécies forem conservadas íntegras, devem ser
reverentemente conservadas ou também consumidas; pois, enquanto permanecerem as espécies, nelas
permanecerá o corpo de Cristo, como se disse. E o lugar onde forem encontradas devem, sendo
possível, queimar-se e depositarem-se as cinzas no sacrário, como dissemos a respeito da rasura da
tábua.
O Sacramento da Penitência
Em seguida devemos tratar do sacramento da penitência.
Sobre o que devemos tratar primeiro, da penitência em si mesma. Segundo, do seu efeito. Terceiro, das
suas partes. Quarto, dos Que recebem este sacramento. Quinto, do poder dos ministros. Sexto, da
solenidade deste sacramento. No primeiro ponto há duas questões a se considerarem. Primeiro, da
penitência enquanto sacramento. Segundo, da penitência enquanto virtude.