# Questão 2: Do apêndice ─ do purgatório.
Nesta questão discutem-se oito artigos:

## Art. 1 — Se há purgatório depois desta vida.
O primeiro discute-se assim. ─ Parece que não há purgatório depois desta vida.

1. - Pois, diz a Escritura: Bem-aventurados os mortos que morrem no Senhor. De hoje em diante, diz o
Espírito, que descansem dos seus trabalhos. Logo, os que morrem no Senhor não devem sofrer no
purgatório, depois desta vida. Nem os que no Senhor não morreram, porque esses não são susceptíveis
de purificação. Logo, depois desta vida não há nenhum purgatório.

2. Demais. ─ Assim está a caridade para o prêmio eterno como o pecado mortal para o suplício eterno.
Ora, os que morrem em pecado mortal entram logo a sofrer o suplício eterno. Logo, também os que
morrem na caridade recebem imediatamente o eterno prêmio. Portanto, não devem passar por
nenhum purgatório depois desta vida.

3. Demais. ─ Deus, misericórdia suma, é mais inclinado a premiar o bem que a punir o mal. Ora, assim
como os que vivem na caridade podem praticar certos atos maus, não merecedores do suplício eterno,
assim os que estão em pecado mortal podem praticar certas ações genericamente boas, não dignas do
prêmio eterno. Logo, assim como os condenados não recebem depois desta vida nenhum prêmio pelas
boas ações referidas, também as más ações, a que aludimos não devem ser punidas depois desta vida.
Donde a mesma conclusão que antes.
Mas, em contrário. ─ A Escritura diz: É um santo e saudável pensamento orar pelos mortos, para que
sejam livres dos seus pecados. Ora, não devemos orar pelos santos do paraíso, pois em nada precisam
das nossas orações. Nem pelos condenados do inferno, que não podem receber perdão dos pecados.
Logo, depois desta vida há certos ainda não perdoados de seus pecados e que podem sê-lo. E esses tem
a caridade, sem a qual não há remissão de pecados; porque a caridade cobre todos os delitos. Portanto,
tais almas não sofrerão a morte eterna, porque, como diz o Senhor, todo o que vive e crê em mim não
morrerá eternamente. Mas também não entrarão na glória senão depois de purificados, porque nada de
impuro nela entrará como diz a Escritura. Logo, há um purgatório desta vida.

2. Demais. ─ Gregório Nisseno diz: Quem vive na amizade de Jesus Cristo e não pode inteiramente
purificar-se do pecado nesta vida, depois da morte purgá-lo-á nas chamas do purgatório. Logo, depois
desta vida, há um purgatório.

SOLUÇÃO. ─ Do que já dissemos podemos com segurança concluir a existência de um purgatório, depois
desta vida. Pois, se atendermos a que o reato da pena não desaparece totalmente depois de perdoada a
culpa pela contrição; que nem sempre são delidos os pecados veniais com o perdão dos mortais; e que
além disso, a justiça exige que o pecado seja expiado pela pena devida, havemos necessariamente de
concluir que há de ser punido depois desta vida quem morre sem dar a satisfação devida, mesmo depois
da contrição dos pecados e da competente absolvição. Portanto, Os que negam o purgatório colidem
com a justiça divina e professam uma opinião errônea e alheia à fé: Por isso Gregório Nisseno, depois
das palavras supra-citadas acrescenta: Eis o que cremos e pregamos para salvar o dogma da verdade; e
assim o ensina a Igreja universal, quando reza para os defuntos ficarem livres dos seus pecados. O que
não é possível entender-se senão dos que sofrem no purgatório. Ora, quem se opõe à autoridade da
Igreja incorre em heresia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A autoridade citada se refere às obras que produzem o
mérito e não aos sofrimentos que purificam a alma.

RESPOSTA À SEGUNDA. ─ O mal não tem uma causalidade perfeita, mas resulta de deficiências
particulares; ao passo que o bem procede de uma causa perfeita, como diz Dionísio. Por isso qualquer
defeito impede a perfeição do bem; mas qualquer bem não impede a consumação de um mal, porque
nunca é o mal desacompanhado de algum bem. Por onde, o pecado venial impede a alma, que tem a
caridade, de alcançar o bem perfeito da vida eterna, antes de ser purificada. Enquanto que o pecado
mortal não pode impedir, esteja acompanhado do bem que estiver, a alma de sofrer imediatamente
depois de separada, o sumo mal.

RESPOSTA À TERCEIRA. ─ Quem cai num pecado mortal dá a morte a todas as boas obras antes
praticadas, e, mortas são todas as que praticar em estado de pecado mortal; porque, tendo ofendido a
Deus, merece perder todos os bens que de Deus recebeu. Portanto, quem morreu em pecado mortal
não receberá nenhum prêmio depois desta vida; ao passo que quem morreu na caridade, receberá
depois desta vida um prêmio, que nem sempre delirá todo mal existente na alma, mas só o que lhe for
contrário.

## Art. 2 — Se é o mesmo o lugar onde as almas são purificadas e os condenados punidos.
O segundo discute-se assim. ─ Parece não ser o mesmo o lugar onde as almas são purificadas e os
condenados punidos.

1. ─ Pois, a pena dos condenados é eterna, como diz o Evangelho: Estes irão para o fogo eterno. Ora, o
fogo do purgatório é temporal, como diz o Mestre. Logo, não podem ser simultaneamente punidos os
do inferno e os do purgatório pelo mesmo fogo. E assim, hão de por força ser distintos esses lugares.

2. Demais. ─ A pena do inferno dá a Escritura vários nomes: fogo, enxofre, ventos de tempestade etc.
Ora, a pena do purgatório só é designada com o nome de fogo. Logo, os condenados não são punidos no
inferno e no purgatório pelo mesmo fogo.

3. Demais. - Hugo Vitorino diz: É provável que os condenados são punidos nos lugares onde cometeram
a culpa. E também Gregório narra que Germano, bispo de Cápua, encontrou Pascácio num balneário,
onde se purificava. Logo, a pena purgatória não é no inferno, mas neste mundo.
Mas, em contrário, diz Gregório: Assim como o mesmo fogo que torna o ouro rutilante transforma em
fumos a palha, assim, o mesmo fogo queima o pecador e purifica o eleito. Logo, o mesmo fogo é o do
purgatório e o do inferno. Portanto, os condenados àquele e a este estão no mesmo lugar.

2. Demais. ─ Os Santos Patriarcas, antes do advento de Cristo, estavam num lugar mais nobre que
aquele onde se purificam as almas depois da morte; porque não sofriam lá nenhuma pena sensível. Ora,
esse lugar estava contíguo ao inferno, ou era o mesmo que o inferno; aliás Cristo, quando desceu ao
limbo, não teria dito a Escritura que desceu aos infernos. Logo, o purgatório ocupa o mesmo lugar que o
inferno, ou é contíguo a este.

SOLUÇÃO. ─ Do lugar do purgatório nada se encontra expressamente dito na Escritura, nem se podem
aduzir razões eficazes que o determinem. Contudo provavelmente, segundo o mais concorde com o
ensino dos santos Padres e a revelação feita a muitos, o purgatório ocupa um duplo lugar. Um,
consentâneo à lei comum: é o lugar inferior, contíguo ao inferno; e então o mesmo fogo crucia os
condenados ao inferno e purifica os justos ao purgatório; embora os condenados, enquanto inferiores
pelo mérito também devem ocupar um lugar inferior. ─ Outro lugar do purgatório é o que lhe é
destinado por dispensa. E assim sabemos, de certas almas, que cumpriram as suas penas em lugares
diversos, quer para instrução dos vivos, quer para socorro dos mortos, a fim de que os vivos,
conhecendo-lhes as penas, as mitigassem pelos sufrágios da Igreja.
Mas outros dizem que, segundo a lei comum, o lugar do purgatório é onde o homem peca. ─ O que não
parece provável, porque uma alma pode ser punida simultaneamente por pecados que cometeu em
lugares diversos.
Outros, ainda, ensinam que, segundo a lei comum, elas são punidas numa região superior à terra, por
estarem colocadas num estado médio, entre nós e Deus. ─ Mas isto não é exato. Porque não são
punidas pelo que as eleva acima de nós, mas pelo que têm de ínfimo, i. é, o pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O fogo do purgatório é eterno na sua substância, mas
temporal no seu efeito purificador.

RESPOSTA À SEGUNDA. ─ A pena do inferno tem por fim atormentar as almas; e por isso a designamos
com todos aqueles vocábulos nominativos de cousas que nesta vida nos atormentam. Mas o fim
principal das penas do purgatório é purificar dos restos do pecado. Por isso, a pena única que a ele se
atribui é a do fogo, que tem a propriedade de purificar e consumir.

RESPOSTA À TERCEIRA. ─ A objeção colhe-se se trata, não do lugar determinado pela lei comum ao
purgatório, mas do que a justiça divina destina a tal ou tal alma em particular.

## Art. 3 — Se a pena do purgatório excede todas as penas temporais desta vida.
O terceiro discute-se assim. ─ Parece que a pena do purgatório não excede todas as penas temporais
desta vida.

1. - Pois, quanto mais passivo é um ser, tanto mais profundamente pode sofrer, dado que sinta o
sofrimento. Ora, o corpo é mais passivo que a alma separada, quer por ser de natureza contrária à do
agente ígneo, quer por ter uma matéria capaz de receber a ação do agente ─ o que não se pode dizer da
alma. Logo, maior é a pena que o corpo sofre neste mundo, que a purificadora da alma na outra vida.

2. Demais. ─ A pena do purgatório é diretamente ordenada a purificar dos pecados veniais. Ora, aos
pecados veniais, sendo os levíssimos dos pecados, é devida uma pena levíssima, se o número dos golpes
há de regular-se pela qualidade do pecado. Logo, a pena do purgatório é levíssima.

3. Demais. ─ O reato, sendo um efeito da culpa, não se agrava senão com o agravamento da culpa. Ora,
aquele a quem a culpa já foi perdoada, não na pode ter agravada, Logo, aquele a quem foi perdoado um
pecado mortal, pelo qual não satisfez plenamente, o reato não lhe aumenta com a morte. Ora, nesta
vida, a sua culpabilidade não merecia a mais grave das penas. Logo, a pena que sofrerá depois desta
vida, não será mais grave que qualquer uma das dela.
Mas, em contrário, diz Agostinho: O fogo do purgatório será mais doloroso que qualquer pena que
possamos sentir, ver ou imaginar neste mundo.

2. Demais. ─ Quanto mais universal é uma pena tanto maior será. Ora, a alma humana, sendo simples,
será punida na sua totalidade. Mas o mesmo não se dá com o corpo. Logo, a pena sofrida pela alma
separada será mais intensa que toda pena de que o corpo seja susceptível.

SOLUÇÃO. ─ Duas espécies de pena haverá no purgatório: a do dano, que retarda a visão divina; e a do
sentido, que pune pelo fogo material. E tanto uma como outra, embora mínima, excede as penas
máximas desta vida. ─ Pois, quanto mais desejamos uma cansa tanto mais sofremos com a sua privação.
Ora, o desejo com que buscamos o sumo bem, depois desta vida, às almas santas é o intensíssimo de
todos, porque não sofrem nenhum obstáculo por parte de um corpo material e também por já ter
chegado o momento de fruir do sumo bem, se nada o impedir. Por isso, a dor resultante da privação
desse bem é máxima. ─ Além disso e semelhantemente, não consistindo a dor numa lesão, mas na
consciência apenas desta, tanto mais um ser sofre a ação de uma causa lesiva, quanto maior for a sua
sensibilidade. Por isso, as lesões que nos atingem as partes mais sensíveis são as que causam as dores
mais agudas. Ora, como toda a sensibilidade do corpo tem na alma a sua origem, necessariamente o
agente lesivo da alma há de por força fazê-la sofrer soberanamente. E supomos, em nossa
argumentação, que a alma pode ser cruciada pelo fogo material, como o diremos a seguir. Donde
concluímos que necessariamente as penas do purgatório ─ a do dano e a dos sentidos, excedem todas
as desta vida. Algumas porém buscam a razão disto no fato de ser a alma punida na sua totalidade, mas
não o corpo. ─ Mas não é exato, porque então as penas dos condenados seriam mais brandas depois,
que antes da ressurreição. O que é falso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora a alma seja menos passiva que o corpo, contudo
sente mais profundamente o sofrimento. Ora, onde se sente mais o sofrimento há maior dor, mesmo se
é ele menor.

RESPOSTA À SEGUNDA. ─ A acerbidade dessa pena não provém tanto da gravidade do pecado, quanto
das disposições do punido; porque o mesmo pecado é punido mais duramente na outra vida, que nesta.
Assim como quem é de melhor compleição sofre mais os mesmos sofrimentos que padecem outros; e
contudo o juiz, aplicando a todos os mesmos castigos pelas mesmas culpas, procede com justiça. Donde
se colhe a resposta à terceira objeção.

## Art. 4 — Se as penas do purgatório são voluntárias.
O quarto discute-se assim. ─ Parece que as penas do purgatório são voluntárias.

1. ─ Pois, os do purgatório tem o coração reto. Ora, a retidão do coração consiste em conformarmos a
nossa vontade com a de Deus, como diz Agostinho. Logo, querendo Deus puni-las, é voluntariamente
que lhe sofrem a pena.

2. Demais. ─ Todo homem sensato, querendo um fim, quer os meios para chegar a ele. Ora, os do
purgatório sabem que não podem chegar à glória, antes de sofrerem a pena. Logo, a querem.
Mas, em contrário. ─ Ninguém é liberado de uma pena que sofre voluntariamente. Ora, os do purgatório
pedem para se livrar dele, como se conclui de muitas narrativas de Gregório. Logo, não suportam essa
pena voluntariamente.

SOLUÇÃO. ─ De dois modos podemos dizer que um ato é voluntário.
De um modo, por vontade absoluta. E então nenhuma pena é voluntária, pois, por natureza a pena é
contrária à vontade.
De outro modo, por vontade condicionada; assim sofremos voluntariamente uma queimadura para
alcançarmos a saúde. E então, certas penas podem ser voluntárias. ─ Primeiro, porque por ela
adquirimos um bem. E assim, a própria vontade assume uma determinada pena, como no caso da
satisfação. Ou também quando aceitamos de bom grado uma pena e não quereríamos que ela não se
cumprisse; tal o caso do martírio. ─ De outro modo, porque, embora da pena nenhum bem nos resulte,
contudo sem ela não podemos alcançar o bem; assim, no caso da morte natural. E então a vontade não
assume a pena e quereria livrar-se dela; mas pela suportar, considera-se voluntária. E neste sentido,
voluntária é a pena do purgatório.
Certos porém dizem que de nenhum modo é voluntária a pena do purgatório, porque os que lá estão
ficam absorvidos por ela, a ponto de não saberem que são purificados e se julgarem condenados. ─ Mas
isto é falso, porque se não soubessem que hão de ser libertados, não pediriam, como frequentemente
fazem, os sufrágios.
Donde se concluem as respostas às objeções.

## Art. 5 — Se as almas do purgatório são punidas pelos demônios.
O quinto discute-se assim. ─ Parece que as almas do purgatório são punidas pelos demônios.

1. ─ Pois, como diz o Mestre mais abaixo, os pecadores terão como algozes os que tiveram como
tentadores. Ora, os demônios provocam à culpa, não só mortal, mas também venial quando não podem
obter a primeira. Logo, também no purgatório atormentarão as almas, pelos pecados veniais que elas
cometeram.

2. Demais. ─ Os justos são purificados de seus pecados tanto nesta vida como na outra. Ora, nesta
purificam-se pelas penas que lhes infligem os demônios, como se deu com Job. Logo, também depois
desta vida terão como castigo serem purificadas pelos demônios.
Mas, em contrário. ─ É injusto seja submetido ao inimigo quem dele triunfou. Ora, os do purgatório
triunfaram dos demônios, tendo morrido sem pecado mortal. Logo, não devem ficar sujeitos à punição
deles.

SOLUÇÃO. ─ Assim como depois do dia de juízo a justiça divina acenderá o fogo com que os condenados
serão perpetuamente punidos, assim também agora só pela justiça divina é que os eleitos serão
purificados, depois desta vida; não pelo ministério dos demônios, de que ficaram vencedores; nem pelo
dos anjos, que não atormentariam tão veementemente os seus concidadãos. É porém possível que os
conduzam ao lugar das penas. E que também os demônios, que se comprazem nas penas dos homens,
os acompanhem e lhes assistam a purificação ─ quer para se saciarem com os sofrimentos deles, quer
para colherem o que lhes ainda pertencia quando a alma dos eleitos se separou do corpo.
Nesta vida porém, que é o teatro da luta, os homens são punidos, tanto pelos maus anjos, como
inimigos ─ tal o caso de Job; como pelos bons, como no caso de Jacob, cujo nervo da coxa logo secou,
tocado pelo anjo. E também Dionísio diz expressamente, que os bons anjos algumas vezes punem os
homens.
Donde se deduzem as respostas às objeções.

## Art. 6 — Se a pena do purgatório expia a culpa do pecado venial.
O sexto discute-se assim. ─ Parece que a pena do purgatório não expia a culpa do pecado venial.

1. ─ Pois, àquilo de João ─ É o seu pecado para morte, etc., diz a Glosa: O pecado não delido nesta vida
em vão se lhe pede perdão na outra. Logo, nenhum pecado tem a sua culpa perdoada depois desta vida.

2. Demais. ─ Quem pode cair no pecado é que também pode ser livrado dele. Ora, a alma depois da
morte não pode pecar venialmente. Logo, nem ser absolvida do pecado do venial.

3. Demais. ─ Gregório diz, que cada alma se apresentará ao juízo, no estado em que se separou do
corpo; porque, como diz a Escritura, a árvore, em qualquer lugar onde cair, aí ficará. Portanto, quem sair
desta vida, em estado de pecado venial, no mesmo estado se encontrará quando comparecer ao juízo.
Logo, no purgatório ninguém expia a culpa venial.

4. Demais. ─ Como se disse, a culpa atual não se apaga senão pela contrição. Ora, depois desta vida não
haverá contrição, que é um ato meritório; porque então não haverá mérito nem demérito, pois,
segundo Damasceno, é para os homens a morte o que foi para os anjos a queda. Logo, depois desta vida
não será perdoada no purgatório a culpa do pecado venial.

5. Demais. ─ O pecado venial tem a sua raiz na concupiscência. Por isso, no seu primeiro estado, Adão
não podia pecar venialmente, como se disse. Ora, depois desta vida, não haverá na alma separada, que
sofre no purgatório, nenhuma sensualidade, já desaparecida a concupiscência; pois, esta é chamada a
lei da carne. Logo, não haverá no purgatório culpa venial. E portanto não poderá ser expiada pelo fogo
do purgatório.
Mas, em contrário, diz Gregório e Agostinho, que certas culpas leves são perdoadas na vida futura. Mas
não se pode entender que o sejam quanto à pena; porque então todas as culpas, por graves que fossem
quanto ao reato da pena, seriam expiadas pelo fogo do purgatório. Logo, a culpa dos pecados veniais é
expiada pelo fogo do purgatório.

2. Demais. ─ Pelas expressões do Apóstolo ─ madeira, feno e palha ─ entendem-se os pecados veniais,
como se disse. Ora, a madeira, o feno e a palha consomem-se no purgatório. Logo, também as culpas
veniais serão perdoadas depois desta vida

SOLUÇÃO. ─ Certos disseram que depois desta vida não é perdoada a culpa de nenhum pecado. E quem
morrer em culpa mortal será condenado, por não ser susceptível de nenhum perdão. Ora, não pode
ninguém morrer só com pecado venial, sem mortal, porque a graça final purifica da culpa venial. Pois, o
pecado venial resulta de amarmos demasiado os bens temporais, sem nem por isso nos separarmo-nos
de Cristo. E esse amor excessivo tem a sua raiz na concupiscência. Por onde, quem estiver de todo
isento da corrupção da concupiscência, como a S. S. Virgem, nenhum lugar pode dar ao pecado venial. E
portanto, como a morte se extingue e desaparece totalmente essa concupiscência, as potências da alma
ficam totalmente sob a ação da graça e isentas do pecado venial.
Mas esta opinião é frívola tanto em si como na sua causa. ─ Em si, porque contraria à doutrina dos
santos Padres e dos Evangelistas, que não pode entender-se da remissão da pena dos pecados veniais,
como diz o Mestre. Porque, do contrário, tanto os pecados leves como os graves seriam perdoados na
vida futura. Ora, diz Gregório que só as culpas leves podem ser perdoadas depois de esta vida. Nem
basta dizerem que se os santos Padres se referem especialmente às culpas leves, é para prevenir a
opinião que o pecado venial não seria passível na outra vida de nenhuma pena grave; pois, a remissão
da pena antes destrói a gravidade das penas do que a determina.
Na sua causa é frívola a referida opinião, porque o abatimento do corpo, nos últimos instantes da vida,
não expele a corrupção da concupiscência nem a diminuem na sua raiz senão só quanto ao seu ato;
como o demonstram os gravemente enfermos. Nem acalma as potências da alma, sujeitando-as à ação
da graça; porque a tranquilidade das potências e a sujeição delas à graça consiste em as potências
inferiores obedecerem às superiores que se deleitam na lei de Deus. O que não pode dar-se no estado
supra-referido, quando ficam impedidos os atos de todas essas potências. Salvo se se considerar como
tranquilidade a ausência da luta, conforme se dá com os adormecidos; mas nem por isso dizemos que o
sono diminui a concupiscência, nem que acalma as potências da alma ou as sujeita à ação da graça.
Além disso, dado que esse abatimento diminuísse a concupiscência na sua raiz e sujeitasse as potências
da alma à ação da graça, ainda isso não bastaria à purificação da culpa venial já cometida, embora
bastasse a evitar os pecados futuros. Porque a, culpa atual, mesmo venial, não fica perdoada sem a
cooperação atual da contrição, como se disse, por maior intensidade habitual que tenha essa contrição.
Assim, pode um morrer durante o sono, estando em graça, apesar de adormecido com pecado venial; e
esse tal não poderia fazer um ato de contrição pelo pecado venial, antes de morto.
Nem colhe afirmar, como afirmam, que se esse tal não se arrependeu, atual ou intencionalmente, em
geral ou em especial, caiu em pecado mortal, porque a complacência no pecado venial o transforma em
mortal. Pois, não é qualquer complacência no pecado venial que o transforma em mortal ─ aliás todo
pecado venial seria mortal, porque em todos, como voluntários que são, pomos complacência; mas uma
complacência tal que tem em vista o prazer, no qual consiste toda a perversidade humana, quando
fruimos do que só deveríamos usar. E assim, a complacência constitutiva do pecado mortal é a atual,
porque todo pecado mortal consiste num ato. Ora, pode acontecer que uma pessoa, depois de ter
cometido um pecado venial, não pense mais nele, se deve ser perdoado ou não: mas pense, talvez, que
um triângulo tem os três ângulos iguais a dois retos e nesse pensamento adormeça e morra. Por onde se
vê que a referida opinião é de todo irracional.
Por isso, devemos pensar com outros, que a culpa venial, de quem morre em graça, é perdoada depois
desta vida pelo fogo do purgatório; porque essa pena, de certo modo voluntária, por virtude da graça
terá a força de expiar totalmente a culpa, que puder coexistir com a graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A Glosa se refere ao pecado mortal. ─ Ou podemos
responder que, embora o pecado não seja apagado nesta vida, em si mesmo, sê-lo-á contudo no seu
mérito, por ter o pecador merecido nesta vida que a pena do purgatório lhe seja meritória.

RESPOSTA À SEGUNDA. ─ O pecado venial procede da corrupção da concupiscência, que não existirá na
alma separada padecente no purgatório; que portanto não poderá pecar venialmente. Mas a remissão
da culpa venial resulta da vontade informada pela graça, e esta a terá a alma separada, no purgatório.
Logo, não colhe o símil.

RESPOSTA À TERCEIRA. - Os pecados veniais não mudam o estado do homem, porque nem eliminam
nem diminuem a caridade, pela qual se mede a bondade que a graça confere à alma. Por onde,
perdoados ou sentidos os pecados veniais praticados, a alma permanece tal como era antes.

RESPOSTA À QUARTA. ─ Depois de esta vida não pode haver mérito em relação ao prêmio essencial.
Mas o pode em relação a um prêmio acidental, enquanto o homem de certo modo ainda continua
viandante. Por onde, no purgatório pode haver ato meritório quanto à remissão da culpa venial.

RESPOSTA À QUINTA. ─ Embora o pecado venial resulte da inclinação da concupiscência, contudo a
culpa procede da intenção. Por isso, mesmo desaparecida a concupiscência, ainda pode subsistir a
culpa.

## Art. 7 — Se o fogo do purgatório livra do reato da pena.
O sétimo discute-se assim. ─ Parece que o fogo do purgatório não livra do reato da pena.

1. ─ Pois, toda purificação supõe uma impureza. Ora, a pena não implica nenhuma impureza. Logo, o
fogo do purgatório não livra da pena.

2. Demais. ─ Um contrário não se purifica senão pelo seu contrário. Ora, pena não contria à pena. Logo,
pela pena do purgatório não se purifica nenhum reato penal.

3. Demais. ─ Aquilo do Apóstolo ─ O tal será salvo, se bem, etc. ─ diz a Glosa: O fogo salvífico é a
tentação da tribulação, da qual está escrito ─ o forno prova os vasos do oleiro, etc. Logo, expiamos todas
as penas pelas deste mundo, ao menos pela morte, que é a maior de todas, e não pelo fogo do
purgatório.
Mas, em contrário, a pena do purgatório é mais grave que qualquer pena deste mundo, como se disse.
Ora, pela pena satisfatória, que sofrermos neste mundo, ficamos livres do débito penal. Logo, com
muito maior razão, pelas penas do purgatório.

SOLUÇÃO. ─ Quem tem uma dívida só dela fica liberado pagando-a. E como o reato não é senão um
débito penal, quem sofre a pena devida fica absolvido do reato. Assim a pena do purgatório purifica do
reato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O reato, embora em si mesmo não implique nenhuma
impureza, contudo supre, na sua causa, alguma impureza.

RESPOSTA À SEGUNDA. ─ Embora uma pena não contrarie a outra, contudo contraria o reato penal;
pois, é por não termos expiado a pena devida que ficamos obrigados a ela.

RESPOSTA À TERCEIRA. ─ As mesmas palavras da Sagrada Escritura são susceptíveis de muitos sentidos.
Assim, esse fogo pode entender-se como sendo a tribulação presente e a pena subsequente. E por
ambas podem ser delidos os pecados veniais. Mas já dissemos que a morte natural não basta para isso.

## Art. 8 — Se das penas do purgatório um se livra mais cedo que outro.
O oitavo discute-se assim. ─ Parece que da pena do purgatório não pode um livrar-se mais cedo que
outro.

1. ─ Pois, quanto mais grave a culpa e o reato, tanto mais acerba será a pena imposta no purgatório.
Ora, a proporção entre uma pena mais acerba e uma culpa mais grave é a mesma entre uma pena mais
leve e uma culpa mais leve. Logo, ficará um livre ao mesmo tempo que outro.

2. Demais. ─ Méritos desiguais merecem retribuições desiguais na sua duração, tanto no céu como no
inferno. Ora, parece que o mesmo deve dar-se no purgatório.
Mas, em contrário, a comparação do Apóstolo, que significou as diferenças entre os pecados veniais,
pelas palavras ─ madeira, feno e palha. Ora, é um fato, que a madeira dura mais tempo no fogo que o
feno e a palha. Logo, um pecado venial é punido mais longamente no purgatório, que outro.

SOLUÇÃO. ─ Certos pecados veniais aderem mais fortemente à alma que outros, na medida em que o
afeto mais intensamente se inclina e mais fortemente se apega. E como os pecados que mais
fortemente aderem são purgados num tempo mais longo, por isso certos são torturados no purgatório
por mais tempo que outros, na medida em que o afeto mais imerso andou nos pecados veniais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A acerbidade da pena propriamente responde à
quantidade da culpa; ao passo que a diuturnidade corresponde à radicação da culpa no sujeito. Por
onde, pode acontecer fique no purgatório mais tempo quem sofre menos, e inversamente.

RESPOSTA À SEGUNDA. ─ O pecado mortal a que é devido o suplício do inferno, e a caridade a que é
devido o prêmio do paraíso depois desta vida, ficam radicados imutavelmente no sujeito. Por isso, tem
ambos a mesma duração, no inferno e no céu. Mas o mesmo não se dá com o pecado venial, punido no
purgatório, como do sobredito se colhe.
(cid:37)(cid:74)(cid:84)(cid:81)(cid:80)(cid:79)(cid:74)(cid:67)(cid:74)(cid:77)(cid:74)(cid:91)(cid:66)(cid:69)(cid:80)(cid:1)(cid:70)(cid:78)(cid:27)