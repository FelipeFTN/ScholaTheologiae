# Questão 1: Do apêndice ─ da pena do pecado original.
(Esta questão e a seguinte, acrescentadas ao suplemento, tem aqui o seu lugar).
Nesta questão discutem-se dois artigos:

## Art. 1 — Se ao pecado original, em si mesmo considerado, é devida uma pena sensível.
O primeiro discute-se assim. ─ Parece que ao pecado original, em si mesmo considerado, é devida
uma pena sensível.

1. ─ Pois, diz Agostinho: Tem firmissimamente e de nenhum modo duvides, que as crianças saídas deste
mundo, sem o sacramento do batismo, serão punidas do suplício eterno. Ora, suplício significa uma
pena sensível. Logo, as crianças, punidas só pelo pecado original, sofrerão uma pena sensível.

2. Demais. ─ À maior culpa é devida maior pena. Ora, o pecado original é mais grave pecado que o
venial, por implicar uma aversão maior, privando da graça; ao passo que o venial pode coexistir com ela.
Além disso, o pecado original é punido com pena eterna, ao passo que o venial com pena temporal.
Logo, se ao pecado venial é devida a pena do fogo, com muito maior razão, ao original.

3. Demais. ─ Os pecados são mais gravemente punidos depois desta vida, que durante ela, enquanto
ainda há lugar para a misericórdia. Ora, nesta vida, o pecado original é punido com uma pena sensível;
assim, as crianças, só manchadas do pecado original, sofrem, e não injustamente, muitas penas
sensíveis. Logo, também depois de esta vida lhe é devida uma pena sensível.

4. Demais. ─ Assim como o pecado atual implica a aversão e a conversão, assim no pecado original há
algo de correspondente à aversão, a saber, a privação da justiça original, e algo de correspondente à
conversão, i. é, a concupiscência. Ora, ao pecado atual, em virtude da conversão, é devida a pena do
fogo. Logo, também ao original, em razão da concupiscência.

5. Demais. ─ Os corpos das crianças serão, depois da ressurreição, passíveis ou impassíveis. ─ Se
impassíveis, como nenhum corpo humano pode ser impassível, senão pelo dom da impassibilidade ─
como se dá com os bem─aventurados; ou em razão da justiça original ─ como no estado de inocência;
daí resulta que os corpos das crianças ou terão o dote da impassibilidade e então serão gloriosos e não
haverá diferença entre as batizadas e as não-batizadas ─ o que é herético; ou terão a justiça original, e
isentos, portanto, do pecado original, por este não serão punidos ─ o que semelhantemente é herético.
─ Se porém forem passíveis, como todo ser passível sofre necessariamente a ação do agente presente,
daí resulta que, presentes corpos sensíveis ativos, sofrerão uma pena sensível.
Mas, em contrário. ─ Agostinho diz, que a pena das crianças, só manchadas do pecado original, é a
brandíssima de todas. O que não se daria se fossem atormentadas por uma pena sensível.

2. Demais. ─ A acerbidade da pena sensível corresponde ao prazer da culpa, conforme aquilo da
Escritura: Quanto se tem glorificado e tem vivido em deleites tanto lhe dai de tormento e de pranto.
Ora, o pecado original não implica nenhum prazer e nenhum ato; pois, todo prazer resulta de uma
atividade, como ensina Aristóteles. Logo, ao pecado original não é devida nenhuma pena sensível.

SOLUÇÃO. ─ A pena deve ser proporcionada à culpa, conforme a Escritura: Quando ela for rejeitada, tu a
julgarás contrapondo uma medida a outra medida. Ora, o detrimento causado pela culpa original, sendo
de natureza culposa, não resulta da subtração nem da corrupção de nenhum bem consequente aos
princípios mesmos da natureza humana, mas da subtração ou da corrupção de um bem acrescentado a
essa natureza. Nem essa é culpa de cada homem em particular, senão enquanto tem cada qual uma
natureza que ficou destituída de um bem que lhe era natural ter e possível conservar. Por isso, nenhuma
outra pena lhe é devida, senão a privação do fim a que se ordenava o bem de que ficou privado e que a
natureza humana por si mesma não pode alcançar. Ora, tal é a visão divina. Por onde, a privação dessa
visão é a própria e só pena do pecado original, depois da morte. Se, pois, fosse infligida ao pecado
original uma outra pena sensível, depois da morte, não seria este punido, pelo que encerra de culpa;
porque a pena sensível é uma pena pessoal, que se cumpre pela dor que impõe. Por onde, assim como a
culpa não resultou de um ato pessoal particular, não será também no sofrimento pessoal particular que
deverá consistir a expiação da pena; mas só na privação do bem para alcançar, o qual a natureza não é
por si mesma capaz. Quanto às outras perfeições e bondades resultantes dos seus princípios naturais, os
condenados nenhum detrimento sofrerão por causa do pecado original.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Na autoridade citada, a palavra suplício não designa uma
pena sensível, mas só a pena do dano, que é a privação da visão divina. Assim como também
frequentemente a Escritura costuma denominar fogo a qualquer pena.

RESPOSTA À SEGUNDA. ─ Dentre todos os pecados o original é o mínimo, porque tem o mínimo de
voluntário. Pois, não é voluntário pela vontade de uma pessoa em particular, mas só por vontade do
princípio da natureza. Ao passo que o pecado atual, mesmo venial, é voluntário pela vontade de quem o
cometeu. Por isso menor pena é devida ao original que ao venial. ─ Nem obsta que o original seja
incompatível com a graça; pois, a privação da graça não tem natureza de culpa, mas de pena, enquanto
procede do voluntário. Por onde, onde é menor o voluntário menor é a culpa. ─ Do mesmo modo, não
obsta seja devida uma pena temporal ao pecado venial atual. Porque isto é acidental: enquanto quem
morre só com o pecado venial tem a graça, em virtude da qual se purificou da pena. Mas se o pecado
venial alguém o tivesse sem a graça, sofreria uma pena perpétua.

RESPOSTA À TERCEIRA. ─ Não se dá o mesmo com a pena sensível anterior e a posterior à morte.
Porque antes da morte a pena sensível resulta da virtude da natureza agente; quer seja a pena sensível
interna, como uma febre ou cousa semelhante, ou ainda uma pena sensível externa, como uma
queimadura ou qualquer outra. Mas depois da morte nada age em virtude da natureza, mas só
conforme a ordem da justiça divina; quer a ação seja sobre a alma separada, sobre a qual sabemos que
o fogo não pode naturalmente agir; quer sobre um corpo ressurrecto, porque então toda atividade
natural cessará, cessado o movimento do primeiro móvel, causa de todo movimento e alteração
corpórea.

RESPOSTA À QUARTA. ─ A dor sensível responde ao prazer sensível da conversão do pecado atual. Ora,
a concupiscência habitual, produzida pelo pecado original, não é acompanhada de nenhum prazer. Por
isso a dor sensível não lhe corresponde, como pena.

RESPOSTA À QUINTA. ─ Os corpos das crianças não serão impassíveis por incapacidade de sofrerem,
mas por falta de um agente exteriormente atuante sobre eles. Porque depois da ressurreição nenhum
corpo terá ação sobre outro, sobretudo para alterá-lo ou destruí-lo por um efeito natural; não haverá
outra ação senão para punir o pecado por ordem da justiça divina. Por isso nenhuma pena sofrerão
aqueles corpos, que não merecem da justiça divina nenhuma pena sensível! Quanto ao corpo dos
santos, serão impassíveis, porque não terão a capacidade de sofrer nenhuma ação; por isso terão a
impassibilidade como um dom, que não terão as crianças.

## Art. 2 — Se a alma das crianças não batizadas sofrerá uma pena espiritual.
O segundo discute-se assim. ─ Parece que a alma das crianças não batizadas sofrerá uma pena
espiritual.

1. ─ Pois, como diz Crisóstomo, para os danados será mais grave a pena de serem privados da visão de
Deus que a de serem queimados pelo fogo do inferno. Ora, as crianças ficarão privadas da visão divina.
Logo, sofrerão com isso uma pena espiritual.

2. Demais. ─ Ficarmos privados do que queremos ter não pode ser sem algum sofrimento. Ora, as
crianças quererão gozar da visão de Deus, do contrário teriam uma vontade atualmente perversa, Logo,
não gozando dela, hão de sofrer.

3. Demais. ─ Se se disser que nada sofrerão por saberem que dela não foram privados por culpa própria,
objeta-se em contrário. ─ A imunidade da culpa, longe de diminuir, aumenta a dor da pena; pois, não é
por ser deserdado ou mutilado sem culpa, que alguém sofrerá menos. Logo, não será por serem
privadas sem culpa de um tão grande bem, que as crianças ficarão isentas de dor.

4. Demais. ─ Assim como as crianças batizadas estão para os méritos de Cristo, assim os não-batizados
para o demérito de Adão. Ora, as crianças batizadas alcançam, pelo mérito de Cristo, o prêmio da vida
eterna. Logo, também as não batizadas sofrem dor por serem privadas da vida eterna, pelo demérito de
Adão.

5. Demais. ─ Não é possível separarmo-nos do bem amado sem sofrermos dor. Ora, as crianças terão um
conhecimento natural de Deus e, pela mesma razão, o amarão naturalmente. Logo, ficando
perpetuamente separados dele, parece que não poderão sem dor sofrer essa separação.
Mas, em contrário. ─ Se as crianças não-batizadas sofrerem interiormente depois da morte, sê-lo-á por
culpa ou por pena. ─ Se da culpa, como dessa não poderão mais purificar-se, essa dor lhes será uma
causa de desesperação. Ora, essa dor nos condenados é o verme da consciência. Logo, as crianças
sofrerão a pena do verme de consciência. E assim, a pena delas não será a mais fraca de todas, como diz
o Mestre. ─ Se porém sofressem uma pena, como essa pena lhes teria sido justamente imposta por
Deus, a vontade delas se oporia à justiça divina. E então teria uma deformidade atual. O que é
inadmissível. Logo, não sentirão nenhuma dor.

2. Demais. ─ A razão reta não sofre que nos perturbemos pelo que não podemos evitar; e assim, como o
demonstra Séneca, o sábio não é susceptível de nenhuma turbação. Ora, nas crianças a razão reta não
sofreu nenhum desvio pelo pecado atual. Logo, nenhuma perturbação sofrerão por padecerem uma
pena que não puderam evitar.

SOLUÇÃO. ─ Nesta matéria há três opiniões.
Uns dizem que as referidas crianças não padecerão nenhuma dor, porque de forma lhes estará
obscurecida a razão, que não saberão o bem que perderam. ─ Mas não é provável, que a alma, livre do
liame do corpo, não conheça aquilo que a razão tem o poder de investigar e ainda muito mais.
Por isso outros dizem, que tem um conhecimento perfeito de tudo o que a razão natural pode
investigar, conhecem a Deus, sabem estarem privados da contemplação divina, e por isso de certo
modo sofrem. Esse sofrimento porém lhes ficará mitigado, por não terem voluntariamente incorrido na
culpa pela qual foram condenadas, ─ Mas esta opinião também não parece provável. Porque a dor não
pode ser pequena, causada pela perda de um tão grande bem e sem esperança de recuperá-lo. A pena
delas não poderá pois ser brandíssima. ─ Além disso, absolutamente pela mesma razão pela qual não
serão punidas pelo agente externo da dor sensível, não sentirão também a dor interna. Porque a dor da
pena corresponde ao prazer da culpa. Portanto, não sendo a culpa original acompanhada de nenhum
prazer, dela ficará excluída toda dor penal.
Por isso outros opinam que terão conhecimento perfeito de tudo o que pode ser alcançado pela razão
natural, saberão que estão privados da vida eterna, conhecerão a causa dessa privação, mas isso tudo
não lhes causará nenhuma espécie de sofrimento. Vejamos, porém, como isso é possível.
Devemos saber, que ninguém, de razão reta, se afligirá por ficar privado do que lhe excede a
capacidade, senão só se o for daquilo a que tem direito. Assim, nenhum homem sensato sofrerá por não
poder voar como a ave; nem por não ser rei ou imperador, se a isso não tem direito. Sofreria porém
ficando privado do que de certo modo lhe corresponde à capacidade. Ora, afirmo que todo homem
dotado de livre arbítrio é capaz de alcançar a vida eterna; pois pode preparar-se para a graça, que o fará
merecer. Portanto, perdendo-a, sofrerá a máxima das dores, por ter perdido um bem que poderia ter
alcançado. Ora, as crianças não foram nunca de porte a poderem chegar à vida eterna. Pois, esta,
excedente à toda capacidade natural, não lhes é devida em virtude do princípio da natureza; nem
podem praticar qualquer ato capaz de as fazer alcançar tão grande bem. Por onde, nenhum sofrimento
padecerão, por ficarem privadas da visão divina; ao contrário, terão grande gozo por participarem
largamente da bondade divina e das suas perfeições naturais.
Nem se pode dizer que fossem proporcionadas à consecução da vida eterna, se não por atos próprios,
ao menos mediante atos de outros, que as teriam podido batizar. Assim, muitas crianças nas mesmas
condições foram batizadas e ganharam a vida eterna. Pois tal explicação não colhe, porque só por uma
graça mui especial poderíamos ser premiados por atos que não praticamos. Por onde, a privação dessa
graça não causa às crianças mortas sem batismo maior pena que as que houvesse de sofrer um homem
sensato por não ter recebido as mesmas graças conferidas aos seus semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os condenados por uma culpa atual, tendo tido o uso do
livre arbítrio, tinham também a capacidade de alcançar a vida eterna; mas tal não se dá com as crianças,
como dissemos. Logo, não há símil em ambos os casos.

RESPOSTA À SEGUNDA. ─ Embora a vontade possa querer tanto o possível como o impossível, conforme
o ensina Aristóteles, contudo uma vontade ordenada e completa não pode querer senão aquilo do que
o sujeito é de certo modo ordenado. E quem não puder satisfazer à sua vontade nessas condições, com
isso sofrerá; mas não sofrerá não conseguindo o que não lhe era possível obter. E a isto se chamaria
antes veleidade que vontade; pois, tal objeto ninguém o quereria absolutamente falando, mas só se
fosse possível.

RESPOSTA À TERCEIRA. ─ Todos temos a possibilidade de conseguir um patrimônio e de conservar a
integridade do nosso corpo. Nada há pois de admirar se sofrermos, perdendo-os, por culpa quer nossa,
quer alheia. Por onde é claro que a objeção, fundada em tal símile, não colhe.

RESPOSTA À QUARTA. ─ O dom de Cristo excede ao pecado de Adão, como diz o Apóstolo. Por isso, não
é forçoso haja entre uma criança não-batizada, e o mal que sofre, a mesma correlação existente entre a
batizada e o bem que frui.

RESPOSTA À QUINTA. ─ Embora as crianças não-batizadas fiquem privadas da união com Deus pela
glória, contudo dele não ficam totalmente separadas. Ao contrário, com ele ficam unidas pela
participação dos bens naturais. E assim de Deus poderão gozar pelo conhecimento e amor naturais.