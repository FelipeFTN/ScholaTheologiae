# Questão 7: Dos efeitos da Fé.
Em seguida devemos tratar dos efeitos da fé.
E nesta questão, discutem-se dois artigos:

## Art. 1 — Se o temor é efeito da fé.
O primeiro discute-se assim. – Parece que o temor não é efeito da fé.

1. – Pois, o efeito não precede à causa. Ora, o temor precede à fé, no dizer da Escritura: Vós os que
temeis ao Senhor, crede-o. Logo, não é o temor efeito da fé.

2. Demais. – Os contrários não podem ter a mesma causa. Ora, temor e esperança são contrários, orno
se disse, pois, a fé gera a esperança, conforme uma Glosa. Logo, não é causa do temor.

3. Demais. – Um contrário não pode ser causa de outro. Ora, o objeto da fé é o bem da verdade
primeira; ao passo, que o do temor é o mal, conforme se disse. E como os atos se especificam pelos seus
objetos, segundo já foi estabelecido resulta que não é a fé a causa do temor.
Mas, em contrário, a Escritura: Os demônios creem e estremecem.

SOLUÇÃO. – O temor é um movimento da virtude apetitiva, como já dissemos. Ora, o princípio de todos
os movimentos apetitivos é o bem ou o mal apreendido. Por onde e necessariamente será alguma
apreensão o princípio do temor e de todos os movimentos apetitivos. Ora, a fé causa em nós uma
apreensão de certos males penais aplicados pelo juízo divino. E desse modo é a fé causa do temor, que
nos faz temer a punição de Deus; e tal temor é servil. É também a causa do temor filial, pelo qual
tememos a separação de Deus, ou pelo qual evitamos compararmo-nos com Ele, pelo reverenciar,
considerando-o como o bem imenso e altíssimo, do qual é péssimo o separar-se e mau querermos com
Ele nos igualar. Da primeira espécie de temor porém, isto é, do servil, é a causa a fé informe; e do temor
filial, que é o da segunda espécie, é a causa a fé informada que, pela caridade, leva o homem a unir-se e
a submeter-se a Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O temor de Deus não pode, universalmente, preceder a
fé, porque, se lhe ignorassemos de todo os prêmios ou as penas, que conhecemos pela fé, de nenhum
modo o temeríamos. Mas, suposta a fé em certos artigos, por exemplo, na excelência divina, daí resulta
o temor de reverência; donde se segue, ulteriormente, que o homem deve sujeitar a inteligência a Deus
para crer tudo o que Ele prometeu. Por isso, o texto citado acrescenta: E não vós faltará a sua
recompensa.

RESPOSTA À SEGUNDA. – Os contrários podem ter a mesma causa, em pontos de vista opostos, não
porém no mesmo ponto de vista. Assim, a fé gera a esperança, fazendo-nos levar em conta os prémios
com que Deus retribui os justos; e, por outro lado, gera o temor, fazendonos levar em conta as penas
que inflige aos pecadores.

RESPOSTA À TERCEIRA. – O objeto primário e formal da fé é o bem que é a verdade primeira; mas,
materialmente, também são propostos à fé certos males. Por exemplo, que é mau não se sujeitar a Deus
ou separar-se dele; e que os pecadores sofrerão males penais infligidos por Deus. E assim, pode a fé ser
causa do temor.

## Art. 2 — Se a purificação do coração é efeito da fé.
O segundo discute-se assim. – Parece que a purificação do coração não é efeito da fé.

1. – Pois, a pureza do coração reside precipuamente no afeto. Ora, a fé reside na inteligência. Logo, não
causa a purificação do coração.

2. Demais. – Não pode a causa da purificação do coração coexistir com a impureza. Ora, a fé pode
coexistir com a impureza do pecado, como o demonstram os que têm a fé informe. Logo, a fé não
purifica o coração.

3. Demais. – Se a fé purificasse de algum modo, o coração humano, purificar-nos-ia sobretudo a
inteligência. Ora, sendo um conhecimento enigmático, não pode, com a sua obscuridade, purificar o
intelecto. Logo, a fé de nenhum modo purifica o coração.
Mas, em contrário, diz a Escritura. Purificando com a fé os seus corações.

SOLUÇÃO. – A impureza de qualquer ser está em mesclar-se com o que lhe é inferior. Assim, não se diz
que a prata fica impura por misturar-se com o ouro, que a torna melhor, mas, quando se mistura com o
chumbo ou o estanho. Ora, é manifesto, que a criatura racional é mais digna que todas as criaturas
temporais e corpóreas. Por isso, torna-se impura quando se une, pelo amor, ao que é temporal. E dessa
impureza se purifica pelo movimento contrário, tendendo para Deus, que lhe é superior. Ora, desse
movimento o princípio primeiro é a fé, conforme a Escritura: é necessário que o que se chega a Deus;
creia logo, o primeiro princípio da purificação do coração é a fé que, quando aperfeiçoada pela caridade
informada, causa a purificação perfeita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O que pertence ao intelecto é princípio do que pertence
ao afeto, por mover a este o bem do intelecto.

RESPOSTA À SEGUNDA. – A fé, ainda a informe, exclui a impureza do erro, que lhe é oposta. E esta
consiste em o intelecto humano unir-se desordenadamente ao que lhe é inferior, querendo medir o
divino pelas essências das coisas sensíveis. Mas, quando informado pela caridade, não se compadece
com nenhuma impureza, porque, no dizer da Escritura, a caridade cobre todos os delitos.

RESPOSTA À TERCEIRA. – A obscuridade da fé não depende da impureza da culpa, mas antes, da
deficiência natural ao intelecto humano, no estado da vida presente.