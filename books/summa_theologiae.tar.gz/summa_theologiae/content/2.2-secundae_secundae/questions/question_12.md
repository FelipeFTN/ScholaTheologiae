# Questão 12: Da apostasia.
Em seguida devemos tratar da apostasia.
E nesta questão discutem-se dois artigos:

## Art. 1 — Se a apostasia pertence à infidelidade.
O primeiro discute-se assim. – Parece que a apostasia não pertence à infidelidade.

1. – Pois, o que é considerado como princípio de todo pecado não pode pertencer à infidelidade,
porque, além desta, existem muitos outros pecados. Ora, a apostasia é considerada o princípio de
muitos pecados, conforme a Escritura: O princípio da soberba do homem é apostatar de Deus, e em
seguida acrescenta: O princípio de todo pecado é a soberba. Logo, a apostasia não pertence à
infidelidade.

2. Demais. – A infidelidade reside no intelecto. Ora, a apostasia consiste, mais, em obras externas, em
palavras, ou mesmo na vontade interior. Pois, diz a Escritura: O homem apostata é um homem inútil;
caminha com boca perversa; faz sinais com os olhos, bate com o pé, fala com os dedos, com depravado
coração maquina o mal, e em todo o tempo semeia distúrbios. E ainda, quem se circuncidasse ou
adorasse o sepulcro de Maomé seria considerado apóstata. Logo, a apostasia não pertence diretamente
à infidelidade.

3. Demais. – A heresia pertence à infidelidade, da qual é uma determinada espécie. Ora, se a apostasia
pertencesse à infidelidade, seguir-se-ia que é dela uma determinada espécie e contudo não o é,
segundo o que já se disse. Logo, a apostasia não pertence à infidelidade.
Mas, em contrário, diz a Escritura: Muitos dos seus discípulos tornaram-se atrás, o que é apostatar: e
deles já antes o Senhor dissera: Há alguns de vós outros que não creem. Logo, a apostasia pertence à
infidelidade.

SOLUÇÃO. – A apostasia implica a renegação de Deus, o que pode dar-se de diversos modos, segundo os
modos diversos pelos quais o homem se une a Deus. Ora, o homem se une a Deus, primeiro, pela fé;
segundo, pela vontade devida e sujeita a lhe obedecer aos preceitos; terceiro, por certos estados
especiais e superrogatórios, como, o da religião, de clericatura ou ordens sacras. Ora, removido o
posterior, removido fica o anterior, mas não inversamente. Por onde, pode alguém aposta tal de Deus,
renegando a religião que professava ou a ordem que recebeu; e a esta se chama apostasia da ordem ou
da religião. Mas alguém também pode aposta tal de Deus, pela mente, que repugna aos mandamentos
divinos. Apesar, porém, dessas duas apostasias, o homem ainda pode continuar unido a Deus pela fé.
Mas, se a abandonar, então separa-se completamente de Deus. Por onde, a simples e absoluta
apostasia é aquela pela qual alguém abandona a fé, e a essa apostasia se chama perfídia. E neste
sentido, a apostasia absolutamente considerada pertence à infidelidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A objeção colhe; quanto à segunda forma da apostasia,
que implica o rompimento da vontade com os mandamentos de Deus e que existe em todo pecado
mortal.

RESPOSTA À SEGUNDA. – À fé implica não só a convicção íntima, mas ainda a declaração interna
manifestada por palavras e obras externas; pois a confissão é um ato de fé. E também, deste modo,
certas palavras externas ou obras podem implicar a infidelidade, enquanto sinais desta, no mesmo
sentido em que se diz que estar são é sinal da saúde. E embora o lugar citado possa ser entendido de
toda apostasia, convém entretanto, do modo mais verdadeiro, ao apóstata da fé. Pois, é a fé a
substância das causas que se devem esperar, e sem fé é impossível agradar a Deus. Por onde, perdida
ela, nada mais tem o homem de útil à salvação eterna. E por isso diz a Escritura: O homem apóstata é
um homem inútil. Ao contrário, é a fé a vida da alma, conforme aquilo do Apóstolo: O justo vive da fé!
Por onde, assim como, perdida a vida do corpo, todos os membros e partes do homem perdem a
disposição devida, assim também, perdida a vida da justiça, que vem da fé, surge a desordem em todos
os membros. E, primeiro, na boca, por onde sobretudo se manifesta o pensamento; depois, nos olhos;
em terceiro lugar, nos órgãos do movimento; em quarto, na vontade, que tende para o mal. Donde se
segue, que o apóstata semeia distúrbios, visando separar os outros dá fé, como ele próprio se separou.

RESPOSTA À TERCEIRA. – As espécies ele uma qualidade ou forma não se diversificam pelo termo de
origem ou de chegada do movimento. Mas antes ao inverso, as espécies do movimento dependem dos
termos. Ora, a apostasia respeita a infidelidade, como o termo final para que tende o movimento de
quem abandona a fé. Por onde, não implica uma espécie determinada de infidelidade, senão uma certa
circunstância agravante, conforme aquilo da Escritura. Melhor lhes era não ter conhecido a verdade do
que, depois de a ter conhecido, tornar atrás.

## Art. 2 — Se o príncipe, por apostasia da fé, perde o governo dos súditos, de modo a estes já não estarem obrigados a lhe obedecer.
O segundo discute-se assim. – Parece que o príncipe, por apostasia da fé, não perde o governo dos
súditos, que continuam obrigados a lhe obedecer.

1. – Pois, diz Ambrósio: Juliano imperador, embora apostata, governava soldados cristãos, e quando lhes
dizia - Preparai um exército para a defesa da república - eles lhe obedeciam. Logo, por apostasia do
príncipe, os súditos não ficam desligados do seu governo.

2. Demais. – O apóstata da fé é infiel. Ora, houve certos varões santos que serviram fielmente a
senhores infiéis, como José, o Faraó; Daniel, a Nabucodonosor e Mardoqueu, a Assuero. Logo, por
apostasia da fé, não se pode permitir deixe o príncipe de ser obedecido pelos súditos.

3. Demais. – Tanto a apostasia, como qualquer pecado, faz afastarmo-nos de Deus. Se, pois, por
apostasia da fé, os príncipes perdessem o direito de governar súditos fiéis, pela mesma razão o
perderiam por causa de outros pecados. Ora, isto é claramente falso. Logo, por apostasia da fé, não
devem deixar de lhes obedecer.
Mas, em contrário, Gregório: Nós, observando o que foi estatuído pelos nossos santos predecessores,
desligamos, pela nossa autoridade apostólica, do juramento, aqueles que são dependentes de
excomungados por fidelidade ou pela santidade do que juraram e proibimos de lodos os modos lhes
guardem fidelidade, até virem a dar satisfação. Ora, os apóstatas da fé são excomungados, bem como os
heréticos, segundo diz uma Decretal. Logo, não devem os súditos obedecer aos príncipes apóstatas da
fé.

SOLUÇÃO. – Como já dissemos a infidelidade em si mesma não exclui o governo. Pois este foi
introduzido pelo direito das gentes, que é um direito humano; ao passo que a distinção entre fiéis e
infiéis é fundada no direito divino, que não exclui o direito humano. Ora, quem peca por infidelidade
pode perder o direito de governar, em virtude de uma sentença, assim como pode também perdê-lo,
outras vezes, por outras culpas. A Igreja, porém, não pertence punir a infidelidade dos que nunca
receberam a fé, conforme à palavra do Apóstolo: Que me vai a mim em julgar daqueles que estão fora?
Mas a infidelidade dos que a receberam pode ser punida por uma sentença. Assim, os chefes são
convenientemente punidos, sendo proibidos de continuar a governar súditos fiéis. Pois, tal governo
poderia causar grande detrimento à fé, porque, como se disse, o homem apóstata com depravado
coração maquina o mal e semeia distúrbios, visando separar os homens da fé. Por onde, logo que, por
sentença, alguém é declarado excomungado, por apostasia da fé, por isso mesmo os seus súbditos são-
lhe desligados do governo e do juramento de fidelidade, que a ele os ligava.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – No tempo em questão a Igreja, ainda recente, não tinha o
poder de reprimir os príncipes terrenos. Por isso, tolerava que os fiéis obedecessem a Juliano o
Apóstata, no que não era contrário à fé, para evitar que esta corresse maiores perigos.

RESPOSTA À SEGUNDA. – É diferente a situação dos outros infiéis, que nunca receberam a fé, como se
disse.

RESPOSTA À TERCEIRA. – A apostasia da fé separa totalmente o homem de Deus, como se disse, o que
não se dá com certos outros pecados.