# Questão 6: Da causa da Fé.
Em seguida devemos tratar da causa da fé.
E nesta questão discutem-se dois artigos:

## Art. 1 — Se é a fé infundida no homem por Deus.
O primeiro discute-se assim. – Parece que não é a fé infundida no homem por Deus.

1. –Pois, como diz Agostinho pela ciência gera-se, nutre-se, defende-se e fortifica-se em nós a fé. Ora, o
que é gerado em nós pela ciência parece, antes, adquirido que infuso. Logo, não temos fé por infusão
divina.

2. Demais. –O que o homem alcança, ouvindo e vendo, considera-se como adquirido por ele. Ora, ele
adquire a fé vendo os milagres e ouvindo doutrina da mesma, conforme diz a Escritura: Conheceu o pai
ser aquela mesma hora em que Jesus lhe dissera : Teu filho vive. E creu ele, e toda a sua casa ainda: a fé
é pelo ouvido. Logo, tem a fé por aquisição.

3. Demais. –O que lhe está ao alcance da vontade o homem pode adquirir. Ora, a fé depende da
vontade de quem crê, como diz Agostinho. Logo, podemos adquiri-la.
Mas, em contrário, a Escritura pela graça é que sois salvo mediante a fé, e isto não vem de vós porque é
um dom de Deus.

SOLUÇÃO. –Duas condições exige a fé: ser-nos proposto o que devemos crer, para crermos
explicitamente; e o assentimento ao que nos é proposto.
Pela primeira condição ela vem necessariamente de Deus. Pois, as verdades da fé, excedendo a razão
humana, não são susceptíveis de contemplação pelo homem, se Deus não as revelar. Ora, a certos,
como aos Apóstolos e aos profetas, Deus as revelou imediatamente; a outros, as propõe mediante
pregadores da fé, como o diz a Escritura: Como pregarão eles se não forem enviados?
Em relação à segunda, isto é, ao assentimento do homem às verdades da fé, podemos considerar-lhe
dupla causa. Uma inducente à fé, exteriormente, como um milagre presenciado ou a persuasão de uma
pessoa, que leva a ter fé. Nem uma nem outra, porém, é causa suficiente, pois, dos que veem um
mesmo milagre e dos que ouvem a mesma pregação, uns creem e outros, não. Portanto, é preciso
admitir-se outra causa interior, que mova o homem, de dentro, a assentir nas verdades da fé. E essa os
Pelagianos consideravam como sendo só o livre arbítrio. E diziam, por isso, que o início da fé está em
nós, pois por nós mesmos nos preparamos a assentir às verdades dela. Porém a consumação da fé vem
de Deus, que nos propõe o que devemos crer. Mas esta doutrina é falsa. Porque, o homem, assentindo
nas verdades da fé, eleva-se acima da sua natureza, o que não pode se dar senão por um princípio
sobrenatural, que move de dentro e que é Deus. Logo, a fé, quanto ao assentimento, que é o principal,
no ato da mesma, vem de Deus, movendo interiormente, pela graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –A ciência que obra a modo de persuasão exterior, gera e
nutre a fé. Mas, a causa principal e própria da fé é a que move, interiormente, a assentir.

RESPOSTA À SEGUNDA. –A objeção feita também procede, quanto à causa, que propõe exteriormente
as verdades da fé, ou que persuade a crer por palavras ou obras.

RESPOSTA À TERCEIRA. –Crer depende, sem dúvida, da vontade do crente. Mas, é necessário seja a sua
vontade preparada pela graça de Deus, para poder elevar-se ao que lhe excede à natureza, como já
dissemos.

## Art. 2 — Se é a fé informe um dom de Deus.
O segundo discute-se assim. – Parece que a fé informe não é um dom de Deus.

1. –Pois, como diz a Escritura; as obras de Deus são perfeitas, Ora, a fé informe é imperfeita. Logo, não é
obra de Deus.

2. Demais. –Assim como se chama disforme a um ato que não tem a forma devida, assim também
informe se chama à fé sem a devida forma. Ora, o ato disforme do pecado não vem de Deus como já se
disse. Logo, também de Deus não vem a fé informe.

3. Demais. –Deus cura totalmente a quem cura, conforme a Escritura. Se recebe um homem a
circuncisão em dia de sábado, por não se violar a lei de Moisés, porque vos indignais vós de que eu em
dia de sábado curasse a todo um homem? Ora, pela fé o homem se cura da infidelidade. Logo, quem
quer que receba de Deus o dom da fé fica imediatamente purificado de todos os pecados. Mas, isto não
se opera senão pela fé informada. Portanto, só a fé informada é dom de Deus, com exclusão da fé
informe.
Mas, em contrário, uma certa Glosa diz: a fé sem a caridade é que é um dom de Deus. Ora, esta é
informe. Logo, a fé informe é um dom de Deus.

SOLUÇÃO. – A informidade é uma privação. Ora, devemos atender a que a privação respeita umas
vezes, à essência específica; outras, não, mas sobrevém ao ser já constituído na sua espécie própria.
Assim, a privação do equilíbrio devido dos humores concerne à essência mesma específica da doença;
ao contrário, a obscuridade não pertence à essência específica mesma do que é diáfano, mas lhe
sobrevém. Ora, quando se determina a causa de um ser, entendemos assinalá-la relativamente à
espécie própria do mesmo. Por onde, o que não pode ser considerado causa da privação também não o
pode, do ser a que a privação diz respeito especificamente. Assim, não pode ser considerada causa da
doença a que não o é do desiquilíbrio dos humores. Pode, contudo ser considerada causa da
diafaneidade o que não o é da obscuridade, que não concerne à essência específica daquela. Ora, a
informidade da fé não lhe respeita à essência específica, pois informe se chama à fé a que falta uma
certa forma exterior, como já dissemos. Por onde, a causa da fé informe é a causa da fé em si mesma
considerada. E essa é Deus, segundo já foi dito. Donde se conclui ser a fé informe um dom de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora a fé informe não tenha, absolutamente falando,
a perfeição da virtude, é perfeita, contudo, de uma certa perfeição, que basta à da fé, na sua essência.

RESPOSTA À SEGUNDA. – A disformidade de um ato moral diz-lhe respeito à essência específica, como
já dissemos. Pois, chama-se disforme o ato privado da sua forma intrínseca, que é a proporção devida
entre as circunstâncias dele. Logo, Deus não pode ser considerado causa do ato disforme. Ele, que não é
causa da disformidade, embora o seja do ato como tal. - Ou, devemos dizer que a disformidade implica,
não só a privação da forma devida, mas ainda, uma disposição contrária. Por onde, está a disformidade
para o ato como a falsidade, para o fim. Logo, como o ato disforme, também nenhuma fé falsa vem de
Deus. E assim como de Deus procede a fé informe, assim também os atos genericamente bons, embora
não informados pela caridade, como frequentemente se dá com os pecadores.

RESPOSTA À TERCEIRA. –Quem recebe de Deus a fé, sem a caridade, não fica, absolutamente falando,
resguardado de ser infiel, por não ficar removida a culpa da infidelidade precedente; mas o fica
relativamente, de modo que se liberte desse pecado. Pois frequentemente acontece que, por ação
divina, deixamos de praticar um ato pecaminoso sem contudo deixarmos a prática de outro ato dessa
natureza, por sugestão da nossa própria iniquidade. E também, deste modo, Deus concede a um a fé
sem lhe dar o dom da caridade; como, ainda dá a certos, sem a caridade, o dom da profecia e outros
semelhantes.