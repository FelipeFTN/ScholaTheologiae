# Questão 13: Da blasfêmia em geral.
Em seguida devemos tratar do pecado de blasfêmia, que se opõe à confissão da fé. E primeiro, da
blasfêmia em geral. Segundo, da blasfêmia chamada pecado contra o Espírito Santo.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se a blasfêmia se opõe à confissão da fé.
O primeiro discute-se assim. - Parece que a blasfêmia não se opõe à confissão da fé.

1. – Pois, blasfemar é assacar uma injúria ou um insulto contra o Criador. Ora, isso implica antes
malevolência contra Deus, que infidelidade. Logo, a blasfêmia não se opõe à confissão da fé.

2. Demais. – Aquilo da Escritura - a blasfêmia seja desterrada dentre vós - diz a Glosa: a que é dirigida
contra Deus ou os santos. Ora, a confissão da fé não se refere senão ao concernente a Deus, objeto da
fé. Logo a blasfêmia nem sempre se opõe à confissão da fé.

3. Demais. – Certos dizem que há três espécies de blasfêmias. Uma atribui a Deus o que lhe não
convém; outra dele remove o que lhe convém; a terceira atribui à criatura o que só é próprio de Deus.
Por onde, a blasfêmia não é relativa só a Deus, mas também às criaturas. Ora, a fé tem Deus como
objeto. Logo, a blasfêmia não se opõe à confissão da fé.
Mas, em contrário, diz o Apóstolo: Antes fui blasfemo e injuriador; e acrescenta: Fi-lo por ignorância na
incredulidade. Donde se colhe que a blasfêmia se inclui a incredulidade.

SOLUÇÃO. – A blasfêmia, por denominação, implica um certo detrimento à excelência da bondade,
sobretudo da divina. Ora, Deus, como diz Dionísio é a bondade mesma essencial. Por onde tudo o que
convém a Deus pertence-lhe à bondade; e tudo o que não lhe pertence muito longe está da essência da
bondade perfeita que é a sua essência. Portanto, negar o que convém a Deus ou atribuir-lhe o que lhe
não convém é em detrimento da sua bondade. E isto pode se dar de dois modos: ou só por afirmação da
inteligência, ou de mistura com uma detestação afetiva; assim como, ao contrário, a fé em Deus se
aperfeiçoa pelo amor do mesmo. Logo, esse detrimento à bondade divina é por obra só do intelecto, ou
também do afeto. Se residir só na inteligência é blasfêmia mental. Se porém se manifestar
exteriormente pela palavra, a blasfêmia será por palavras. E deste modo a blasfêmia se opõe à
confissão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Quem fala contra Deus, com intenção de injuriá-lo ofende
a bondade divina, não só quanto à verdade do intelecto, mas também pela pravidade da vontade, que
detesta e abate quanto lhe é possível, a honra divina. O que constitui a blasfêmia perfeita.

RESPOSTA À SEGUNDA. – Como Deus é louvado nos seus santos, enquanto são louvadas as obras que
neles realizou; assim a blasfêmia dirigida contra eles redunda para. Deus, por via de consequência.

RESPOSTA À TERCEIRA. – Por esse tríplice critério não se podem propriamente falando, distinguir as
diversas espécies de pecado de blasfêmia. Pois, atribuir a Deus o que lhe convém não difere, senão por
ser uma afirmação, de remover dele o que lhe convém, que é uma negação. Ora, essa diversidade não
distingue as espécies de hábito; pois, pela mesma ciência conhecemos a falsidade das afirmações e das
negações; e pela mesma ignorância erramos de um e de outro modo; porque a nega ão se prova pela
afirmação, como diz Aristóteles: Ora, atribuir às criaturas o que é próprio de Deus implica em lhe
atribuir o que lhe não convém; pois, o que é próprio de Deus é Deus mesmo. Logo, atribuir a uma
criatura o que é próprio só de Deus, é igualar Deus, em si mesmo, à criatura.

## Art. 2 — Se a blasfêmia é sempre pecado mortal.
O segundo discute-se assim. – Parece que a blasfêmia nem sempre é pecado mortal.
1 – Pois, aquilo do Apóstolo – Mas agora deixai também vós todas estas coisas, etc. - diz a Glosa: depois
das coisas maiores proíbe as menores; e nestas inclui as blasfêmias. Logo, a blasfêmia é considerada
entre os pecados menores, que são veniais.

2. Demais. – Todo pecado mortal se opõe a algum preceito do Decálogo. Ora, a blasfêmia não se opõe a
nenhum deles. Logo, não é pecado mortal.

3. Demais. – Não são pecados mortais os cometidos sem deliberação; por isso os movimentos
subitamente primários da nossa vontade não são pecados mortais, precederem o movimento da razão,
como do sobredito claramente resulta. Ora, a blasfêmia às vezes precede toda deliberação. Logo, nem
sempre é pecado mortal.
Mas, em contrário, a Escritura: O que blasfemar o nome do Senhor morra de morte. Ora, a pena de
morte não é imposta senão ao pecado mortal. Logo, pecado mortal é a blasfêmia.

SOLUÇÃO. – Como já dissemos pelo pecado mortal o homem separa-se do princípio primeiro da vida
espiritual, que é a caridade para com Deus. Por onde, tudo o que contraria a caridade ê genericamente
pecado mortal. Ora, a blasfêmia contraria genericamente a caridade para com Deus, por lhe causar
detrimento à bondade, como já dissemos, que é o objeto da caridade. Logo, a blasfêmia é
genericamente pecado mortal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Não se deve entender a Glosa citada, como considerando
pecados menores tudo o mais quanto acrescenta ao que antes disse; mas que, não tendo enumerado
antes senão os pecados maiores, acrescenta depois alguns menores, entre os quais enumera também
alguns dentre os maiores.

RESPOSTA À SEGUNDA. – Opondo-se a blasfêmia à confissão da fé, como já se disse a sua proibição
reduz-se à da infidelidade, compreendida no dito da Escritura: Eu sou o Senhor teu Deus, etc. Ou está
proibida por aquele outro lugar: Não tomarás em vão o nome de teu Deus. Ora, mais toma em vão o
nome de Deus quem dele afirma uma falsidade, que quem confirma qualquer falsidade invocando esse
nome.

RESPOSTA À TERCEIRA. – A blasfêmia pode, sem deliberação, surgir subrepticiamente, de dois modos. –
De um modo, quando não advertimos ser blasfêmia o que dizemos. E isso pode se dar quando,
subitamente, levados da paixão prorrompemos nas palavras imaginadas, em cuja significação não
refletimos. E então é a blasfêmia pecado venial e não é essencial e propriamente blasfêmia. – De outro
modo, quando advertimos na blasfêmia , considerando-lhe os significados das palavras. E então não
ficamos isentos de pecado mortal, como não o fica quem mata levado por um movimento súbito de ira,
alguém que lhe está sentado ao lado.

## Art. 3 — Se o pecado de blasfêmia é o maior dos pecados.
O terceiro discute-se assim. – Parece que o pecado de blasfêmia não é o maior dos pecados.

1. – Pois, chama-se mal o que é nocivo, segundo Agostinho. Ora, ê mais nocivo o pecado de homicídio,
que priva o homem da vida, que o da blasfêmia, que nenhum dano pode causar a Deus. Logo, o pecado
de homicídio é mais grave que o da blasfêmia.

2. Demais. – Quem perjura toma a Deus como testemunha da falsidade, e portanto afirma que Ele é
falso. Ora, nem todo blasfemo vai até a afirmar que Deus é falso. Logo, o perjúrio é mais grave pecado
que a blasfêmia.

3. Demais. – Àquilo da Escritura - Não queirais levantar ao alto vosso poder - diz a Glosa: O maior vício é
o de desculpar o pecado. Logo, não é a blasfêmia o máximo pecado.
Mas, em contrário, àquilo da Escritura – A um povo terrível, etc., diz a Glosa: Todo pecado, comparado
com a blasfêmia, é leve.

SOLUÇÃO. – Como já dissemos, a blasfêmia se opõe à confissão da fé. Por onde, implica a graveza da
infidelidade; ficando este pecado mais grave, se for acompanhado da aversão da vontade; e ainda mais,
se se prorromper em palavras; assim como, por seu lado, também o louvor da fé aumenta pelo amor e
pela confissão. Portanto, sendo a infidelidade o máximo pecado, genericamente, como já dissemos,
resulta, por consequência, que também a blasfêmia é o máximo pecado, pertencente que é ao mesmo
gênero, e agravando a infidelidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Comparados os objetos, é manifesto que a blasfêmia,
pecado que vai diretamente contra Deus, é mais grave que o pecado de homicídio, que atinge o
próximo. Comparados, porém os seus efeitos danosos, o homicídio é mais grave, por mais danoso ao
próximo, que a blasfêmia, a Deus. Ora, na gravidade da culpa se atende mais à intenção da vontade
perversa, que ao efeito do ato, como do sobredito resulta. Por onde, sendo intenção do blasfemo causar
dano à honra divina, peca, absolutamente falando, mais gravemente que o homicida. Contudo, entre os
pecados cometidos contra o próximo, o homicídio ocupa o primeiro lugar.

RESPOSTA À SEGUNDA. – Aquilo da Escritura a blasfêmia seja desterrada dentre vós - diz a Glosa: é pior
blasfemar que perjurar. Pois, o perjuro não diz nem sente, como o blasfemo, nada de falso sobre Deus;
mas toma a Deus por testemunha da falsidade; não por julgar que Deus é testemunha falsa, mas
esperando que Deus não testemunhe o contrário por algum sinal evidente.

RESPOSTA À TERCEIRA. – Desculpar o pecado é uma circunstância que agrava todo pecado, inclusive o
da blasfêmia. Por isso, é considerada o máximo pecado, por tornar os outros maiores.

## Art. 4 — Se os condenados blasfemam.
O quarto discute-se assim. – Parece que os condenados não blasfemam.

1. – Pois, certas pessoas más abstêm-se de blasfemar, por medo das penas futuras. Ora, os condenados
sofrem essas penas, e por isso mais as aborrecem. Logo e com maior razão são impedidos de blasfemar.

2. Demais. – A blasfêmia, sendo o gravíssimo dos pecados, é o mais demeritório. Ora, na vida futura já
não é possível merecer nem desmerecer. Logo, não haverá possibilidade da blasfêmia.

3. Demais. – A Escritura diz: Em qualquer lugar onde a árvore cair, ai ficará. Por onde é claro, que depois
desta vida o homem não terá outro mérito nem outro pecado, além do que nela teve. Ora, muitos serão
condenados, que nesta vida não foram blasfemos. Logo, também não blasfemarão na vida futura.
Mas, em contrário, a Escritura: Os homens se abrasaram com um calor devorante e blasfemaram o
nome de Deus, que tem poder sobre estas praças, Ao que diz a Glosa: Os que estão no inferno, embora
saibam que merecem o castiço, que sofrem, aborrecem contudo, o poder tão grande que Deus tem de
castigá-lo. Ora, isto já seria blasfêmia nesta vida; logo, também na futura.

SOLUÇÃO. – Como já dissemos, a blasfêmia consiste essencialmente em detestar a bondade divina. Ora,
os que estão no inferno conservam a vontade perversa, divorciada da justiça de Deus; por amarem os
pecados por que são punidos, quereriam cometê-los de novo, se o pudessem, e odeiam as penas que,
por esses pecados lhes são infligidas, Arrependem-se também contudo, de tais pecados cometidos, não
pelos odiarem, mas por serem punidos por causa deles. Por onde, há no íntimo do coração deles a
blasfêmia, consistente nesse detestar a divina bondade. E é de crer, que depois da ressurreição
blasfemarão vocalmente, assim como, vocalmente, os santos louvarão a Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os homens abstêm-se, nesta vida, da blasfêmia, pelo
temor das penas de que presumem livrar-se. Ora, os condenados, no inferno, não têm esperança de
virem a livrar-se. Por onde, como desesperados, são levados a tudo o que lhes sugere a vontade
perversa.

RESPOSTA À SEGUNDA. – Só nesta vida podemos merecer e desmerecer; por isso, durante ela, os
nossos bons atos são meritórios e os maus, demeritórios. Dos bem-aventurados, porém, os bens não
são meritórios, mas lhes pertencem ao prêmio da bem-aventurança. Do mesmo modo, os males dos
condenados não lhes são demeritórios, mas lhes pertencem à pena da condenação.

RESPOSTA À TERCEIRA. – Quem morre em estado de pecado mortal conserva, de certo modo, a
vontade de detestar a divina justiça. E por aí pode ser susceptível de blasfêmia.