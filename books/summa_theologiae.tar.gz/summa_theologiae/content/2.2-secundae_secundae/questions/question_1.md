# Questão 1: Do objeto da fé.
Portanto, dentre as virtudes teologais, devemos tratar, primeiro, da fé. Segundo, da esperança. Terceiro,
da caridade.
Ora, sobre a fé, há quatro considerações a fazer. Primeiro, sobre a fé em si mesma. Segundo, sobre os
dons da inteligência e da ciência, que lhe correspondem. Terceiro, dos vícios opostos. Quarto, dos
preceitos pertencentes a essa virtude.
Quanto à fé, devemos tratar, primeiro, do seu objeto. Segundo, do seu ato. Terceiro, do hábito mesmo
da fé.
Na primeira questão tratam-se dez artigos:

## Art. 1 — Se o objeto da fé é a verdade primeira.
O primeiro discute-se assim. – Parece que o objeto da fé não é a verdade primeira.

1. – Pois, objeto da fé é o proposto para crermos. Ora, é nos proposto a crer, não só o respeitante à
divindade, que é uma verdade primeira, mas também o pertencente à humanidade de Cristo, aos
sacramentos da Igreja e à condição das criaturas. Logo, nem só a verdade primeira é objeto da fé.

2. Demais. – A fé e a infidelidade, sendo contrárias, referem-se ao mesmo objeto. Ora, pode haver
infidelidade relativamente a todo o conteúdo da Sagrada Escritura; pois, considera-se infiel quem negar
qualquer parte dele. Logo, também é a fé relativa a todo o conteúdo da Sagrada Escritura. Ora, esta
contém muitas disposições relativas aos homens e aos demais seres criados. Logo, o objeto da fé não é
só a verdade primeira, mas também a verdade criada.

3. Demais. – A fé entra na mesma divisão que a caridade, como já se disse. Ora, pela caridade não só
amamos a Deus, suma bondade, mas também ao próximo. Logo, o objeto da fé não é só a verdade
primeira.
Mas, em contrário, diz Dionísio: a fé tem por objeto a verdade simples e sempre existente. Ora, esta é a
verdade primeira. Logo, é o objeto da fé a verdade primeira.

SOLUÇÃO. – O objeto de qualquer hábito cognoscitivo encerra dois elementos: o conhecido
materialmente, que é como o objeto material; e aquilo pelo que se conhece, que é a razão formal do
objeto. Assim, na ciência da geometria, as conclusões são materialmente conhecidas; mas a razão
formal desse conhecimento são os meios da demonstração, por onde se conhecem as conclusões. Assim
também, se considerarmos a razão formal do objeto da fé, esse não é senão a verdade primeira. Pois a
fé, de que tratamos, não adere a um objeto senão enquanto revelado por Deus. Por onde, apoia-se na
verdade divina, como meio. Se porém considerarmos materialmente os objetos aos quais a fé adere,
esses incluem, não só Deus, mas ainda muitos outros. Os quais, porém, não obtêm a adesão da fé,
senão na medida em que se ordenam de algum modo para Deus; isto é, enquanto certos efeitos da
divindade auxiliam o homem a tender para a fruição divina. Por onde, ainda por este lado, é o objeto da
fé, de certo modo, a verdade primeira, porque nada cai sob o domínio da fé senão enquanto ordenado
para Deus; assim como o objeto da medicina é a saúde, por nada considerar ela senão em ordem à
saúde.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O pertencente à humanidade de Cristo, aos sacramentos
da Igreja ou a quaisquer criaturas, constitui objeto da fé enquanto meios pelos quais nos ordenamos
para Deus, aos quais também assentimos por causa da verdade divina.
E o mesmo se deve RESPONDER À SEGUNDA OBJEÇÃO, quanto a tudo o que é transmitido pela Sagrada
Escritura.

RESPOSTA À TERCEIRA. – Também a caridade ama ao próximo por causa de Deus. Por onde, Deus
mesmo é o objeto próprio dela, como a seguir se dirá.

## Art. 2 — Se o objeto da fé é algo de complexo, a modo do objeto do juízo.
O segundo discute-se assim. – Parece que o objeto da fé nada tem de complexo, a modo do objeto do
juízo.

1. – Pois, é o objeto da fé a verdade primeira, como já se disse. Ora, a verdade primeira é algo de
incomplexo. Logo, o objeto da fé nada tem de complexo.

2. Demais. – A exposição da fé está contida no símbolo. Ora, o símbolo não se compõe de objetos de
juízo, mas de realidades. Assim, não diz, que Deus é omnipotente, mas: Creio em Deus omnipotente.
Logo, o objeto da fé não é o do juízo, mas, a realidade.

3. Demais. – À fé sucede a visão, conforme aquilo da Escritura: Nós agora vemos como por um espelho,
em enigmas; mas então face a face. Ora, o objeto da visão celeste, sendo a mesma essência divina, é
incomplexo. Logo, também o da fé, nesta vida.
Mas, em contrário. – A fé é termo médio entre a ciência e a opinião. Ora, meio e extremo pertencem ao
mesmo gênero. Por onde, versando a ciência e a opinião sobre os objetos dos juízos, resulta, por
semelhança, que também sobre eles versa a fé. Portanto, o objeto da fé, versando sobre tais objetos, é
complexo.

SOLUÇÃO. – O objeto conhecido está no sujeito, que o conhece, ao modo do sujeito. Ora, o modo
próprio do intelecto humano é conhecer a verdade compondo e dividindo, como já dissemos. Por onde,
objetos em si mesmos simples o intelecto os conhece segundo uma certa complexidade; assim como,
inversamente, o intelecto divino conhece, incomplexamente, objetos em si mesmos complexos.
Portanto, o objeto da fé pode ser considerado à dupla luz. - De um modo, quanto à realidade mesma
crida. E então, o objeto da fé é algo de incomplexo, a saber, a realidade mesma na qual temos fé. De
outro modo, quanto a quem crê. E, a esta luz, o objeto da fé é algo de complexo, a modo do objeto do
juízo. - Por isso, num e noutro caso, os antigos opinaram, com verdade, sendo ambas as opiniões
verdadeiras, de certo modo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A objeção procede quanto ao objeto da fé relativamente
à realidade mesma crida.

RESPOSTA À SEGUNDA. – O símbolo exprime o que é de fé, enquanto que nisso termina o ato do
crente, como aparece do modo mesmo da expressão. Ora, o ato do crente não termina num juízo, mas
numa realidade; pois, não formamos juízos senão para, desse modo, chegarmos ao conhecimento da
realidade, tanto na ciência como na fé.

RESPOSTA À TERCEIRA. – A visão, na pátria, será a da verdade primeira, como ela em si mesma é,
conforme a Escritura: Quando ele aparecer, seremos semelhantes a ele; porquanto nós outros o
veremos bem como ele é. Por onde, essa visão será, não a modo de juízo, mas, de simples inteligência.
Ao passo que, pela fé, não apreendemos a verdade primeira em si mesma. Portanto, não há semelhança
de razões.

## Art. 3 — Se é a fé susceptível de falsidade.
O terceiro discute-se assim. – Parece que a fé susceptível de falsidade.
1 – Pois, a fé entra na mesma divisão com a esperança e a caridade. Ora, a esperança é susceptível de
falsidade; assim, muitos que esperam alcançar a vida eterna, não há alcançarão. O mesmo se dá com a
caridade; pois, muitos são amados como bons sem contudo o serem. Logo, é a fé susceptível de
falsidade.

2. Demais. – Abraão acreditou em Cristo, que havia de nascer, conforme aquilo da Escritura: Vosso pai
Abraão desejou ansiosamente ver o meu dia. Ora, depois do tempo de Abraão, Deus poderia não ter-se
encarnado, pois, só por sua vontade assumiu a carne. Portanto, teria sido falso o que Abraão acreditou
de Cristo. Logo, é a fé susceptível de falsidade.

3. Demais. – Era fé dos antigos, que Cristo havia de nascer; e muitos conservaram essa fé até a pregação
do Evangelho. Ora, uma vez nascido, e antes de começar a pregar, era falso que Cristo havia de nascer.
Logo, é a fé susceptível de falsidade.

4. Demais. – Um dos artigos de fé consiste em crermos que o sacramento do altar contém o verdadeiro
corpo de Cristo. Ora, pode acontecer, quando não haja a conveniente consagração, que não exista
verdadeiramente esse corpo, mas só o pão. Logo, é a fé susceptível de falsidade.
Mas, em contrário. - Nenhuma virtude aperfeiçoadora do intelecto tem por objeto o falso, enquanto é
este um mal do intelecto, como está claro no Filósofo. Ora, é a fé uma virtude, que aperfeiçoa o
intelecto, conforme a seguir se demonstrará. Logo, não é susceptível de falsidade.

SOLUÇÃO. – Todo objeto de uma potência, de um hábito ou mesmo de um ato, só o é mediante a sua
razão formal. Assim, a cor não pode ser vista senão pela luz; e uma conclusão não pode ser conhecida
senão mediante a demonstração. Ora, como já se disse, é a razão formal do objeto da fé a verdade
primeira. Logo, ela nada pode alcançar senão enquanto dependente da verdade primeira, que não é
susceptível de nenhuma falsidade, assim como o ser não inclui o não ser nem o bem, o mal. Donde se
conclui que a fé não é susceptível de nenhuma falsidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Sendo a verdade o bem do intelecto e não, da potência
apetitiva, todas as virtudes, que aperfeiçoam o intelecto, excluem totalmente a falsidade; pois, é da
essência da virtude só referir-se ao bem. Ao contrário, as virtudes, que aperfeiçoam a parte apetitiva,
não excluem totalmente o falso; assim, podemos agir segundo a justiça ou a temperança, tendo falsa
opinião do objeto do nosso ato. Por onde, como a fé aperfeiçoa o intelecto, e a esperança e a caridade,
a parte apetitiva, não é o mesmo o caso entre elas. - E, contudo, nem a esperança é susceptível de
falsidade. Pois, ninguém espera conseguir a vida eterna por suas próprias forças, o que seria presunção,
mas, com o auxílio da graça, perseverando na qual, alcançará infalivelmente essa vida. -
Semelhantemente, à caridade pertence amar a Deus, onde quer que esteja Ele. Por isso, não importa,
para a caridade, que Deus esteja ou não em quem é amado por causa dele.

RESPOSTA À SEGUNDA. – A não encarnação de Deus, em si mesma considerada, era possível, mesmo
depois do tempo de Abraão. Mas, enquanto objeto da presciência divina, ela tem uma certa e infalível
necessidade, como se demonstrou na Primeira Parte E, deste modo, é objeto da fé. Portanto, como tal,
não é susceptível de falsidade.

RESPOSTA À TERCEIRA. – À fé do crente pertenceria crer, depois da natividade de Cristo, que ele havia
de nascer um dia. Mas a delimitação do tempo, em que se enganava, não procederia da fé, mas da
conjectura humana. Pois é possível, por conjectura humana, o fiel cair em alguma falsidade. Mas é
impossível, em virtude da fé, afirmar qualquer falsidade.

RESPOSTA À QUARTA. – A fé do crente não se refere a estas ou àquelas espécies de pão; mas a que o
verdadeiro corpo de Cristo está sob as espécies do pão sensível, quando convenientemente consagrado.
Por onde, sendo inconvenientemente consagrado, nem por isso conterá a fé qualquer falsidade.

## Art. 4 — Se é o objeto da fé algo de visível.
O quarto discute-se assim. – Parece que é o objeto da fé algo de visível.

1. – Pois, o Senhor disse a Tomé: Tu crestes, porque me viste: Logo, a visão e a fé tem o mesmo objeto.

2. Demais. – O Apóstolo diz: Nós agora vemos como por um espelho, em enigmas; e refere-se ao
conhecimento pela fé. Logo, vemos aquilo mesmo em que cremos.

3. Demais. – É a fé um certo lume espiritual. Ora, qualquer luz nos faz ver. Logo, tem a fé por objeto as
coisas visíveis.

4. Demais. – Todo sentido se chama visão, como diz Agostinho. Ora, a fé diz respeito ao que é ouvido,
conforme aquilo da Escritura. A fé é pelo ouvido. Logo, a fé refere-se às coisas visíveis.
Mas, em contrário, diz a Escritura: é a fé um argumento das causas que não aparecem.

SOLUÇÃO. – A fé implica o assentimento do intelecto aquilo em que cremos. Ora, a inteligência pode
assentir a alguma coisa, de dois modos. - De um modo, quando movido pelo objeto mesmo, ou
conhecido, em si, como é claro no caso dos primeiros princípios, objeto do intelecto; ou mediatamente,
como é claro no caso das conclusões, objeto da ciência. – De outro modo, o assentimento da
inteligência não se funda em ser ela suficientemente movida pelo seu objeto próprio, mas por uma certa
eleição, inclinada voluntariamente mais para um lado do que para outro. E então, se isso se der com
dúvida e temor não vá a outra parte ser verdadeira, haverá opinião. Se porém, houver certeza, sem
qualquer temor, existirá a fé. Ora, vistas são as coisas que, por si mesmas, movem o nosso intelecto, ou
os sentidos, ao conhecimento delas. Por onde, é manifesto que nem a fé nem a opinião podem ter por
objeto o visível, seja este sensível ou intelectual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Tomé viu uma causa e acreditou em outra: viu um
homem e, confessou crer em Deus, quando disse - meu Senhor e meu Deus.

RESPOSTA À SEGUNDA. – As verdades da fé podem ser consideradas à dupla luz. - Primeiro em especial.
E, não podem então ser simultaneamente vistas e cridas, como já se disse. - De outro modo, em geral,
isto é, sob uma noção geral de credibilidade. E nesse caso, são vistas pelo crente. Pois, não acreditaria
nelas, se não visse que devem ser acreditadas, quer pela evidência dos sinais, quer por meio
semelhante.

RESPOSTA À TERCEIRA. – O lume da fé faz-nos ver a credibilidade das verdades em que acreditamos.
Pois, assim como peles outros hábitos virtuosos vemos o que nos convém, de conformidade com eles,
assim também pelo hábito da fé, a nossa mente se inclina a assentir ao que convém à fé reta e não, a
outras coisas.

RESPOSTA À QUARTA. – O ouvido se refere às palavras significativas das verdades da fé; e não, às
verdades mesmas constitutivas do objeto da fé. E assim, não é necessário sejam elas vistas.

## Art. 5 — Se as verdades da fé podem ser objeto de ciência.
O quinto discute-se assim. – Parece que as verdades da fé podem ser objeto de ciência:

1. – Pois, o que não sabemos ignoramos, por opor-se a ignorância à ciência. Ora, as verdades da fé não
são ignoradas, pois ignorá-las é próprio da infidelidade, conforme aquilo da Escritura: Fiz por ignorância
na incredulidade. Logo, as verdades da fé podem ser objeto de ciência.

2. Demais. – A ciência se adquire por meio de razões. Ora, os autores sagrados apoiam em razões as
verdades da fé. Logo, tais verdades podem ser objeto de ciência.

3. Demais. – O que se prova demonstrativamente constitui ciência, pois a demonstração é um silogismo
que gera a ciência. Ora, certas verdades de fé, como a existência, a unidade de Deus e outras
semelhantes, as provam demonstrativamente os filósofos. Logo, tais verdades podem ser objeto de
ciência.

4. Demais. – A fé, sendo termo médio entre a opinião e a ciência, a opinião dista mais da ciência que a
fé. Ora, a opinião e a ciência podem, de certo modo, incidir sob o mesmo objeto, como diz Aristóteles.
Logo, o mesmo também se dá com a fé e a ciência.
Mas, em contrário, diz Gregório que as causas visíveis são objeto, não da fé, mas de conhecimento.
Logo, as verdades da fé não são objeto de conhecimento. Ora, o que sabemos é objeto de
conhecimento. Logo, o objeto de ciência não pode sê-lo da fé.

SOLUÇÃO. – Toda ciência é adquirida por meio de certos princípios evidentes e, por consequência,
intuitivos. Logo e necessariamente, tudo o que é sabido há de ser, de algum modo, intuitivo. Ora, não é
possível um mesmo sujeito ter intuição e crença, relativamente a um mesmo objeto como já se disse.
Por onde, impossível também é ter ciência e crença em relação a esse mesmo objeto. - Por dar-se
porém, que o visto ou sabido por um seja crido por outro. Assim, as verdades sobre a Trindade, em que
cremos, esperamos haver de vê-las, conforme a Escritura. Nós agora vemos a Deus como por um
espelho, em enigmas; mas então face a face. Ora, essa visão já os anjos a têm. Portanto, o que cremos
eles veem. E assim, semelhantemente, pode dar-se que o visto ou sabido por um homem, mesmo no
estado da vida presente, seja crido por outro, que tal não conhece demonstrativamente. Contudo o
comumente proposto a todos os homens para ser crido é, comumente, não sabido. Ora, essas verdades
são em absoluto, as da fé. Logo, fé e ciência não tem o mesmo objeto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os infiéis ignoram as verdades da fé, pelas não ver ou
conhecer em si mesmas, nem lhes apreender a credibilidade. Ora, deste modo é que os fiéis têm
conhecimento delas; não quase demonstrativamente, mas enquanto veem, pelo lume da fé, que devem
ser cridas, como já se disse.

RESPOSTA À SEGUNDA. – As razões aduzidas pelos Santos Padres para provar as verdades da fé não são
demonstrativas; mas, certas persuasões manifestativas da não impossibilidade do que a fé propõe. Ou
procedem dos princípios da fé, isto é, das autoridades da Sagrada Escritura, como diz Dionísio. Pois, com
tais princípios chegam os fiéis a uma certa prova, assim como a certas outras chegam outros, partindo
dos princípios evidentes. Por isso, a teologia também é uma ciência, como se disse no princípio desta
obra.

RESPOSTA À TERCEIRA. – O que se pode provar demonstrativamente inclui-se entre as verdades que se
devem crer, não, por terem todos nelas fé absoluta, mas, por ser tal preexigido pelas verdades da fé. E,
no mínimo, isso deve ser pressuposto pela fé ao menos por quem não pode de tal ter a demonstração.

RESPOSTA À QUARTA. – Como diz o Filósofo, no lugar aduzido, homens diversos podem ter ciência e
opinião de um objeto absolutamente o mesmo, como agora o afirmamos sobre a ciência e a fé. Mas um
determinado homem pode, certo, ter fé e ciência de um objeto relativamente o mesmo, por exemplo,
de um mesmo sujeito, mas, não sob igual aspecto. Pois, de um mesmo objeto pode alguém saber uma
coisa e opinar outra. E de modo semelhante, podemos saber, demonstrativamente, que Deus existe e
crer que é trino. Mas, de um mesmo objeto e sob o mesmo aspecto, não pode um mesmo homem,
simultaneamente, ter ciência e opinião, nem ciência e fé. Por diferentes razões, porém. Pois, a ciência
não pode, absolutamente falando, e em relação ao mesmo objeto, ser simultânea com a opinião.
Porque, a ciência consiste, essencialmente, em admitirmos a impossibilidade de ser de outro modo
aquilo que sabemos; ao contrário, é da essência da opinião admitirmos a possibilidade de ser de outro
modo aquilo que opinamos. Por seu lado, do que sabemos pela fé admitimos a impossibilidade de ser de
outro modo, por causa da certeza da fé; mas, um mesmo objeto não pode, simultaneamente, e sob o
mesmo aspecto, ser sabido e crido, porque o sabido é visto e o crido é não visto, como se disse.

## Art. 6 — Se as verdades da fé devem distinguir-se em certos artigos.
O sexto discute-se assim. – Parece que as verdades da fé não devem distinguir-se em certos artigos.

1. – Pois, todo o conteúdo da Sagrada Escritura deve ser admitido pela fé. Mas, esse conteúdo, pela sua
extensão, não pode ser reduzido a um número certo. Logo, é supérfluo distinguir artigos na fé.

2. Demais. – A distinção material, podendo ser levada ao infinito, não na deve levar em conta a arte.
Ora, a razão formal do objeto da credibilidade, sendo a verdade primeira, é uma e indivisível como já se
disse. Por onde, as verdades da fé não as pode distinguir a razão formal. Logo, deve-se deixar de lado a
distinção material, em artigos, das verdades da fé.

3. Demais. – Como certos dizem um artigo é uma verdade indivisível, a respeito de Deus, que nos
coarcta a crer. Ora, crer é um ato voluntário, pois, no dizer de Agostinho só crê quem quer. Logo, parece
inconveniente distinguir as verdades da fé em artigos.
Mas, em contrário, diz Isidoro: Um artigo é a percepção da verdade divina, que tende para a mesma.
Ora, por certas distinções é que podemos perceber a verdade divina; pois, o que em Deus tem unidade
multiplica-se em nosso intelecto. Logo, as verdades da fé devem distinguir-se em artigos.

SOLUÇÃO. – Parece que a denominação latina de articulus (artigo) deriva do grego; pois, apopoy, em
grego, correspondente ao latim ariiculus (artigo), significa uma certa coaptação de partes distintas. Por
isso, as partículas do corpo, coaptadas umas às outras, chamam-se articulações dos membros.
Semelhantemente, a gramática grega chama artigos a certas partes da oração coaptadas às demais
palavras para exprimir-lhes o gênero, o número ou o caso. E do mesmo modo, em retórica chamam-se
artigos a certas coaptações de partes. Assim, diz Túlio: chama-se artigo à distinção das palavras, umas
das outras, por intervalos, que cortam a oração, do modo requinte - pela acrimónia, pela voz, pelo
semblante, encheste de espanto os adversários.
Por isso se diz que as verdades da fé cristã se distinguem em artigos, por se dividirem em determinadas
partes com certa coaptação, umas às outras. Ora, são objeto da fé as realidades, divinas invisíveis como
já dissemos. Portanto, sempre que se trate do invisível, por uma razão especial, isso constitui um artigo
especial; quando porém, forem muitas as realidades desconhecidas, mas fundadas na mesma razão, não
haverá distinção de artigos. Assim, há uma dificuldade em entender que Deus sofreu; outra, em que,
depois de morto, ressurgiu; logo, o artigo da ressurreição deve ser distinto do da paixão. Mas, que
sofresse, morresse e fosse sepultado, tudo encerra a mesma dificuldade, de modo que, aceitando-se um
desses fatos, não é difícil aceitar os outros; portanto, todas essas verdades constituem um mesmo
artigo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Certas verdades da fé são por si mesma objeto da
credibilidade; outras, porém, em dependência de terceiras : assim como também as demais ciências
propõem determinadas verdades como buscadas por si mesmas e outras, como manifestativas de
terceiras. Ora, versa a fé, principalmente, sobre as realidades que esperamos ver na pátria, conforme a
Escritura. A fé é a substância das causas que se devem esperar. Portanto, pertence por si mesmo à fé
tudo o que nos ordena diretamente à vida eterna, como, a existência das três Pessoas de Deus
Omnipotente, o mistério da encarnação de Cristo e verdades semelhantes. E, por elas se distinguem os
artigos da fé. Outras verdades, porém, a Sagrada Escritura nos propõe à crença, não como
principalmente visadas, mas para a manifestação das supra-referidas. Assim, que Abraão teve dois
filhos, que um morto ressuscitou ao contato dos ossos de Eliseu, e fatos semelhantes, narrados pela
Sagrada Escritura, afim de manifestarem a majestade divina ou a encarnação de Cristo. E, em relação a
ela, não há necessidade de se fazer distinção de artigos.

RESPOSTA À SEGUNDA. – A razão formal do objeto da fé pode ser considerada em dupla acepção. -
Primeiro, em relação àquilo mesmo em que se acredita. E então, a razão formal de todas as verdades da
fé é a mesma, a saber, a verdade primeira. E por aí, não há distinção de artigos. - Noutra acepção, a
razão formal das verdades da fé pode ser considerada em relação a nós. E então, essa razão formal da
credibilidade está em ter esta por objeto a inevidência. E por aí há distinção entre os artigos da fé, como
se viu.

RESPOSTA À TERCEIRA. – A definição citada do artigo se funda mais na etimologia do nome, enquanto
de derivação latina, do que na sua verdadeira significação, enquanto derivada do grego. Por isso, não é
tal definição de grande peso. - Pode-se, contudo dizer que, sendo a crença voluntária, ninguém é
coarctado a crer por necessidade de coação; somos coarctados, contudo, pela necessidade do fim, pois,
como diz o Apóstolo, é necessário que o que se chega a Deus creia, e sem fé é impossível agradar a
Deus.

## Art. 7 — Se os artigos da fé aumentaram na sucessão dos tempos.
O sétimo discute-se assim. – Parece que os artigos da fé não aumentaram na sucessão dos tempos.

1. – Pois, como diz o Apóstolo, é a fé a substância das causas que se devem esperar. Ora, em todo
tempo esperamos sempre as mesmas coisas. Logo, em todo tempo devemos crer sempre nas mesmas.

2. Demais. – As ciências ordenadas pelo homem recebem acréscimo, na sucessão dos tempos, por causa
dá deficiência do conhecimento dos primeiros que as descobriram, como se vê claramente no Filósofo.
Ora, a doutrina da fé não foi descoberta pelo homem, mas dada por Deus; porque é um dom de Deus,
diz a Escritura. Ora, como a ciência de Deus não padece nenhuma deficiência, resulta que desde o
princípio o conhecimento das verdades da fé foi perfeito, e não aumentou, na sucessão dos tempos.

3. Demais. – A obra da graça não procede menos ordenadamente que a da natureza. Ora, esta toma o
seu início sempre do que é perfeito, como diz Boécio. Logo, também a obra da graça há de ter o seu
início no que é perfeito; e assim os que primeiro transmitiram a fé a conheceram perfeitissimamente.

4. Demais. – Assim como a fé em Cristo nos chegou por meio dos Apóstolos, assim também, no Antigo
Testamento, o conhecimento dela chegou aos patriarcas posteriores por meio dos primeiros, conforme
aquilo da Escritura. Pergunta a teu pai e ele te informará. Ora, os Apóstolos foram plenissimamente
instruídos sobre os mistérios; pois, receberam-nos, assim como com prioridade temporal, assim
também, mais abundantemente que os outros, conforme a Glosa sobre aquilo da Escritura. Nós mesmos
que temos as primícias do Espírito. Logo, conclui-se, que o conhecimento das verdades da fé não
aumentou na sucessão dos tempos.
Mas, em contrário, Gregório diz: Com o andar dos tempos cresceu a ciência dos Padres espirituais; e
quanto mais vizinhos se achavam do advento do Salvador, tanto mais plenamente receberam os
sacramentos da salvação.

SOLUÇÃO. – Na doutrina da fé, os artigos desempenham o mesmo papel que os princípios evidentes na
ciência adquirida pela razão natural. Ora, nesses princípios descobre-se uma certa ordem, pela qual uns
estão implicitamente contidos nos outros, assim como todos se reduzem ao seguinte, como primeiro - é
impossível afirmar e negar simultaneamente conforme está claro no Filósofo. Semelhantemente, todos
os artigos estão implicitamente contidos em certas verdades primeiras da fé, a saber: devemos crer na
existência de Deus e na sua Providência relativa à salvação dos homens, segundo aquilo da Escritura é
necessário que o que se chega a Deus creia que há Deus e que é remunerador dos que o buscam. Pois,
na existência divina se inclui tudo o que cremos existir eternamente em Deus, em que consiste a nossa
felicidade. Por seu lado, na fé da Providência se incluem todas as coisas, temporalmente dispensadas
por Deus para a salvação dos homens e que são a via para a felicidade. E deste modo, dos demais
artigos subsequentes, uns se incluem nos outros; assim, a fé na redenção humana compreende
implicitamente a encarnação de Cristo, a sua Paixão e fatos semelhantes.
Por onde, devemos concluir que, na sua substância, os artigos de fé não receberam acréscimo, na
sucessão dos tempos; porque, tudo quanto os patriarcas posteriores acreditaram estava contido na fé
dos precedentes, embora implicitamente. Mas, quanto à sua explicação, o número dos artigos
aumentou; porque certos foram conhecidos explicitamente pelos patriarcas posteriores, que os
anteriores assim não conheceram. Por isso, o Senhor diz a Moisés: Eu sou o Deus de Abraão, o Deus de
Isaac, o Deus de Jacó; mas eu não lhes declarei o meu nome Adonai. E Davis: Mais que os anciãos
entendi: E o Apóstolo: O mistério de Cristo em outras gerações não foi conhecido, assim como agora
tem sido revelado aos seus santos Apóstolos e profetas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Todos os homens sempre esperaram as mesmas coisas.
Como, porém só por Cristo tiveram essas esperanças, quanto mais afastados estavam de Cristo no
tempo, tanto mais longe se achavam da consecução dos bens esperados. Por isso, o Apóstolo diz: Na fé
morreram todas estes, sem terem recebido as promessas, mas, vendo-as de longe. Ora, quanto mais
uma coisa é vista de longe tanto menos distintamente o é. Por isso, os que estiveram mais vizinhos do
advento de Cristo conheceram mais distintamente os bens esperados.

RESPOSTA À SEGUNDA. – O progresso do conhecimento pode dar-se de dois modos. Primeiro, por parte
de quem ensina, quer seja só, quer vários, e que progridem no conhecimento, na sucessão dos tempos.
E esta é a razão do progresso das ciências descobertas pela razão humana. - De outro modo, por parte
do discente. Assim, o mestre, conhecedor de toda a ciência, não a transmite toda, desde o princípio, ao
discípulo, que não poderia compreendê-la, mas, a pouco e pouco, adaptando-lhe à capacidade. E deste
modo os homens progrediram no conhecimento da fé, na sucessão dos tempos. Donde o comparar o
Apóstolo estado, dos que viveram no regime do Velho Testamento, ao da puerícia.

RESPOSTA À TERCEIRA. – Duas são as causas preexigidas à geração natural: o agente e a matéria. Ora,
na ordem da causa agente, é naturalmente anterior o que é mais perfeito; assim, a natureza começa
pelo perfeito, pois o imperfeito não chega à perfeição senão por agentes perfeitos preexistentes. Na
ordem, porém da causa material, vem primeiro o imperfeito. E por aí, a natureza procede do imperfeito
para o perfeito. - Ora, no manifestar a fé, Deus é como o agente de ciência abeterno perfeita; e o
homem, como a matéria receptiva do influxo do agente divino. Por onde, cumpria que o conhecimento
humano da fé partisse do imperfeito para o perfeito. E embora certos homens, que foram os doutores
da fé, se comportassem a modo de causa agente, contudo a tais a manifestação do Espírito foi dada
para a utilidade comum, como diz a Escritura: Por isso, aos Patriarcas, que foram os instituidores da fé,
foi ministrado dela um conhecimento tão suficiente quanto era necessário que transmitissem ao povo,
nesse tempo, clara ou figuradamente.

RESPOSTA À QUARTA. – A consumação última da graça foi feita por Cristo; por isso, o seu tempo se
chama tempo da plenitude. Por isso, os que mais próximos estiveram de Cristo, quer antes, como João
Batista, quer depois, como os Apóstolos, conheceram mais plenamente os mistérios da fé. Assim vemos
se dar o mesmo com os diversos estados da vida humana: a perfeição é própria da juventude; e tanto
mais perfeito é o estado do homem, quanto mais está próximo da juventude, por anterioridade ou
posterioridade.

## Art. 8 — Se os artigos da fé estão convenientemente enumerados.
O oitavo discute-se assim. – Parece que os artigos da fé estão inconvenientemente enumerados.

1. – Pois, o que pode ser conhecido por meio da razão demonstrativa não pertence à fé, de modo a ser
para todos, objeto de fé, como já se disse. Ora, a unidade de Deus pode ser conhecida por
demonstração; pois, o Filósofo prova, e muitos outros filósofos aduziram razões que a demonstram.
Logo, a unidade de Deus não deve ser tida como um artigo de fé.

2. Demais. – Assim como, por força da fé, havemos de crer em Deus omnipotente, assim também, por
força da mesma, havemos de crer-lhe na omnisciência e na sua universal Providência; e muitos erraram
quanto a estes dois pontos. Logo, entre os artigos da fé, devia ter-se feito menção tanto da sabedoria e
da Providência divina, como da omnipotência.

3. Demais. – O conhecimento do Pai é o mesmo que o do Filho, conforme aquilo da Escritura. Quem me
vê a mim vê também o Pai. Logo, deveria haver só um artigo relativo ao Pai e ao Filho e, pela mesma
razão, ao Espírito Santo.

4. Demais. – A pessoa do Pai não é menor que a do Filho e do Espírito Santo Ora, vários artigos foram
enumerados relativos à pessoa do Espírito Santo e, semelhantemente, à do Filho. Logo, vários também
deviam ser os artigos relativos à pessoa do Pai.

5. Demais. – Assim como há algo de próprio à pessoa do Pai e à do Espírito Santo, assim também à do
Filho, quanto à divindade. Ora, os artigos da fé atribuem uma obra própria ao Pai, que é a da criação; e
semelhantemente, outra própria ao Espírito Santo, que é a de ter falado por meio dos profetas. Logo, os
artigos da fé deviam também atribuir uma obra própria ao Filho, quanto à divindade.

6. Demais. – O Sacramento da Eucaristia tem as suas dificuldades próprias comparada com muitos
artigos. Logo, devia ter-se feito um artigo especial sobre ela. Portanto, os artigos da fé não foram
suficientemente enumerados.
Mas, em contrário, está a autoridade da Igreja que fez a enumeração.

SOLUÇÃO. – Como já se disse, à fé essencialmente pertence aquilo de que gozaremos a visão na vida
eterna, e que a ela nos conduz. Ora, duas coisas se nos propõem a serem vistas nessa vida: a divindade,
que nos estava velada, e cuja visão nos torna felizes; e o mistério da humanidade de Cristo; pelo qual
temos acesso à gloria dos filhos de Deus, conforme o Apóstolo. Por isso, diz o Evangelho: A vida eterna
consiste em que eles conheçam por um só verdadeiro Deus a ti, e a Jesus Cristo, que tu enviaste. Por
onde, a primeira distinção das verdades da fé está em certas dizerem respeito à majestade divina;
outras, ao mistério da humanidade de Cristo, que é o sacramento da piedade, como diz a Escritura.
Ora, sobre a majestade divina três artigos se nos propõem a crer. - O primeiro é a unidade divina. E a
esta pertence o primeiro artigo. O segundo, a Trindade das pessoas. - Em terceiro lugar são nos
propostas as obras próprias da divindade. Das quais a primeira pertence à existência da natureza. E por
isso é nos proposto o artigo da criação. - A segunda pertence à existência da graça. E por isso num
mesmo artigo nos propõe tudo o que pertence à santificação humana. - A terceira enfim, à existência da
glória; e por isso é nos proposto outro artigo sobre a ressurreição da carne e a vida eterna. E assim, há
sete artigos pertencentes à divindade.
Semelhantemente, no tocante à divindade de Cristo se estabeleceram sete artigos. - Desses o primeiro
versa sobre a encarnação ou a concepção de Cristo. - O segundo, sobre a sua natividade, da Virgem. - O
terceiro, sobre a sua paixão, morte e sepultura. - O quarto sobre a descida aos infernos. - O quinto sobre
a ressurreição. - O sexto, sobre a ascensão. - O sétimo, sobre o seu advento para o juízo.
E assim, são ao todo quatorze.
Certos, porém distinguem doze artigos de fé: seis pertencentes à divindade e seis, à humanidade.
Resumem num só os três artigos sobre as três pessoas, porque o mesmo é o conhecimento delas três.
Quanto ao artigo sobre obra da glorificação, dividem-no em dois: a ressurreição da carne e a glória da
alma. Semelhantemente, reduzem a um os artigos sobre a concepção e a natividade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Conhecemos pela fé muitas verdades a respeito de Deus,
que os filósofos não puderam investigar, pela razão natural. Por exemplo, sobre a sua providência, sobre
a omnipotência, e que só a Ele devemos adorar. O que tudo está contido no artigo sobre a unidade
divina.

RESPOSTA À SEGUNDA. – O nome mesmo da divindade implica uma certa previsão, como se disse no
Primeiro livro. Ora, a potência, no ser inteligente, não obra senão pela vontade e pelo conhecimento.
Por onde, a omnipotência de Deus inclui, de certo modo, a ciência e a universal providência. Pois, não
poderia fazer tudo o que quer, nos seres deste mundo, se não os conhecesse e exercesse sobre eles a
sua providência.

RESPOSTA À TERCEIRA. – O conhecimento do Padre, do Filho e do Espírito Santo é o mesmo, quanto à
unidade essencial, pertencente ao primeiro artigo. Quanto porém à distinção das Pessoas, fundada nas
relações de origem, o conhecimento do Filho está, de certo modo, incluído na do Padre. Pois, não seria
Pai se não tivesse o Filho, sendo o nexo entre ambos o Espírito Santo. E sendo assim, bem andaram os
que estabeleceram um só artigo relativo às três Pessoas. Mas como relativamente a cada uma das
Pessoas, devemos atender a certos pontos sobre os quais é possível erro, podem estabelecer-se três
artigos relativos às três Pessoas. Assim, Ario acreditava no Pai omnipotente e eterno, mas não que o
Filho fosse coigual e consubstancial ao Pai; por isso, foi necessário acrescentar um artigo sobre a pessoa
do Filho, para determinar o ponto em questão. E pela mesma razão foi necessário introduzir o artigo
terceiro, contra Macedónio, sobre a pessoa do Espírito Santo. E semelhantemente, a concepção de
Cristo, a sua natividade e ainda a ressurreição e a vida eterna podem ser compreendidas sob uma
mesma noção, num mesmo artigo, enquanto tendo uma mesma ordenação. Mas, sob outra noção
podem se distinguir,· enquanto tendo, cada uma, dificuldades especiais.

RESPOSTA À QUARTA. – Ao Filho e ao Espírito Santo é próprio serem enviados para santificar a criatura.
Havendo, pois, mais verdades que devemos crer, sobre a pessoa do Filho e do Espírito Santo, são mais
os artigos, que sobre a Pessoa do Pai, que nunca é enviado, conforme se disse na Primeira Parte.

RESPOSTA À QUINTA. – A santificação da criatura, pela graça, e a consumação, pela glória, também se
operam pelo dom da caridade, próprio do Espírito Santo, e pelo da sapiência, próprio do Filho. Por onde,
ambas essas obras propriamente pertencem ao Filho e ao Espírito Santo, sendo disso, porém, diversas
as razões.

RESPOSTA À SEXTA. – Duas coisas podemos considerar, no sacramento da Eucaristia. Primeiro, que é
um sacramento; e portanto, com o mesmo fundamento que os outros efeitos da graça santificante.
Depois, que contém milagrosamente o corpo de Cristo, e então está compreendido na omnipotência,
como todos os outros milagres à omnipotência atribuídos.

## Art. 9 — Se os artigos da fé estão convenientemente dispostos no símbolo.
O nono discute-se assim. – Parece que os artigos da fé estão inconvenientemente dispostos no
símbolo.

1. – Pois, a Sagrada Escritura é a regra da fé, à qual não podemos acrescentar nem subtrair nada, como
ela própria o diz: Vós não ajustareis nem tirareis nada às palavras que eu vos digo. Logo, é ilícito erigir-se
qualquer outro símbolo em regra de fé, depois de ter sido outorgada a Sagrada Escritura.

2. Demais. – Como diz o Apóstolo, uma é a fé. Ora, o símbolo é a profissão da fé. Logo, foi conveniente
terem-se feito vários símbolos.

3. Demais. – A confissão da fé, contida no símbolo, diz respeito a todos os fiéis. Ora, nem a todos cabe
crer em Deus, mas só aos de fé informada. Logo, inconvenientemente foi outorgado o símbolo da fé sob
a forma destas palavras: Creio em um só Deus.

4. Demais. – A descida aos infernos é um dos artigos de fé, como já se disse. Ora, o símbolo dos Padres
não faz menção da descida aos infernos. Logo, parece que foi inconvenientemente acrescentado.

5. Demais. – Como diz Agostinho, expondo aquilo do Evangelho Credes em Deus, crede também em
mim - cremos em Pedro ou em Paulo; ora, crer só o dizemos em relação a Deus. Logo, sendo a Igreja
católica algo de puramente criado, resulta que é inconveniente dizer: Numa, santa, católica e apostólica
Igreja.

6. Demais. – O símbolo foi dado para regra de fé. Ora, esta deve ser proposta a todos e publicamente.
Logo, devia cantar-se, na missa, qualquer símbolo, como o dos Padres. Portanto, não parece
conveniente a disposição dos artigos da fé no símbolo.
Mas, em contrário, a igreja universal não pode errar, por ser governada pelo Espírito Santo, que é o
Espírito de verdade. Pois. assim o prometeu o Senhor aos discípulos, dizendo: Quando vier aquele
Espírito de verdade, ele vós ensinará todas as verdades. Ora, o símbolo foi dado por autoridade da Igreja
universal. Logo, nada contém de inconveniente.

SOLUÇÃO. – Como diz o Apóstolo, é necessário que o que se chega a Deus creia. Ora, ninguém pode crer
senão numa verdade que lhe seja proposta à crença. Por isso, foi necessário coligir as verdades da fé,
para mais facilmente poderem ser propostas a todos, afim de ninguém ficar privado da verdade, por
ignorância da fé. Ora, tal coleção dos artigos da fé recebeu o nome de símbolo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A Sagrada Escritura contém as verdades da fé
difusamente, sob modo diversos e, certas, obscuramente. De modo que, para extraí-las dela é
necessário longo estudo e exercício, que nem todos os que têm necessidade de conhecê-las podem
dispender; pois a maior parte, tomados por outras ocupações, não tem tempo de se dedicar a esse
estudo. Por isso, foi necessário se fizesse sumariamente uma coleção clara das sentenças da Sagrada
Escritura, para ser proposta à crença de todos. O que - porém não foi nenhum acréscimo à Sagrada
Escritura, mas antes um extrato da mesma.

RESPOSTA À SEGUNDA. – Todos os símbolos ensinam as mesmas verdades da fé. Mas, há necessidade
de instruir mais diligentemente o povo sobre elas, quando ocorrem erros, afim de não ser a fé dos
simples corrompida pelos heréticos. Tal a causa de ter sido necessário comporem-se vários símbolos, só
diferentes por explicar um, mais plenamente, o que outro contém implicitamente, conforme o exigia a
instância dos heréticos.

RESPOSTA À TERCEIRA. – É como que a pessoa de toda a Igreja, unida pela fé, que propõe a confissão
desta, no símbolo. Ora, a fé da Igreja é uma fé informada, que também se encontra em todos os
membros da Igreja, pelo número e pelo mérito. Por onde, o símbolo transmite a confissão da fé
enquanto conveniente à fé informada, de modo que se algum fiel não a tiver informada pode esforçar-
se por alcançar essa forma.

RESPOSTA À QUARTA. – Como os heréticos não caíram em nenhum erro a respeito da descida aos
infernos, não foi necessária nenhuma explicação sobre esse ponto. E por isso, não é repetido no símbolo
dos Padres, mas suposto, como predeterminado, no dos Apóstolos. Pois, o símbolo subsequente não
abole, antes, expõe o precedente, como já se disse.

RESPOSTA À QUINTA. – Quando se diz - na santa Igreja católica - devemos entendê-lo como significando
ser a nossa fé referida ao Espírito Santo, que santifica a Igreja, de modo que o sentido é: Creio no
Espírito Santo, que santifica a Igreja. Mas é melhor, segundo o uso comum, não se colocar aí a partícula
na, mas dizer simplesmente, a santa Igreja católica, como diz também o Papa Leão.

RESPOSTA À SEXTA. – Sendo o símbolo dos Padres explicativo do dos Apóstolos, e tendo sido composto
depois da fé já manifestada e quando a Igreja estava em paz, por isso é cantado publicamente na missa.
Ao passo que o símbolo dos Apóstolos, composto no tempo da perseguição, quando a fé ainda não
estava disseminada, é dito privadamente na Prima e no Completório, como que contra as trevas dos
erros passados e futuros.

## Art. 10 — Se pertence ao Sumo Pontífice ordenar o símbolo da fé.
O décimo discute-se assim. – Parece que não pertence ao Sumo Pontífice ordenar o símbolo da fé.

1. – Pois, uma nova ordenação do símbolo foi necessária, por causa da explicação dos artigos da fé,
como já se disse. Ora, no regime do Velho Testamento eram cada vez melhor explicados, conforme a
sucessão dos tempos, pois as verdades da fé tornam-se tanto mais manifestas quanto maior for a
proximidade de Cristo conforme já se disse. Ora, cessando essa causa, no regime da Lei Nova, não era
necessário dar uma explicação cada vez mais clara dos artigos da fé. Logo, parece não pertencer à
autoridade do Sumo Pontífice uma nova ordenação do símbolo.

2. Demais. – O que foi interdito, sob pena de anátema, pela Igreja Universal, não depende do poder de
nenhum homem. Ora, uma nova ordenação do símbolo foi interdita, sob pena de anátema, por
autoridade da Igreja Universal. Pois, dizem as atas do primeiro sínodo efesino: Uma vez lido até ao fim o
símbolo do sínodo de Nicéia, o santo sínodo declarou não ser licito a ninguém professar, subscrever ou
compor outra fé, que não a definida pelos Santos Padres reunidos em Nicéia sob a inspiração do Espírito
Santo. E acrescenta-se a pena de anátema; sendo o mesmo repetido nas atas do sínodo calcedonense.
Logo, parece não pertencer à autoridade do Sumo Pontífice ordenar de novo o símbolo.

3. Demais. – Atanásio não foi Sumo Pontífice, mas patriarca de Alexandria; e contudo, constituiu um
símbolo cantado na Igreja. Logo, parece não pertencer, antes, ao Sumo Pontífice que aos outros, a
constituição do símbolo.
Mas, em contrário, a organização do símbolo foi feita no sínodo geral. Ora, tal sínodo só pode se reunir
pela autoridade do Sumo Pontífice, como está nas Decretais. Logo, a organização do símbolo pertence à
autoridade do Sumo Pontífice.

SOLUÇÃO. – Como já se disse, uma nova ordenação do símbolo é necessária para obviar aos erros
ocorrentes. Portanto, tem autoridade para ordená-lo quem pode determinar o que é matéria de fé, para
que todos a esta adiram inconcussamente. Ora, tal é a autoridade do Sumo Pontífice, aquém são
deferidas as maiores e mais difíceis questões da Igreja, como determinam as Decretais. Por isso, o
Senhor disse a Pedro: a quem constituiu Sumo Pontífice: Eu roguei por ti para que a tua fé não falte; e
tu, enfim, depois de convertido conforta a teus irmãos. E a razão disto é que toda a Igreja deve ter a
mesma fé, conforme aquilo da Escritura. Todos digais uma mesma coisa, e que não haja entre vós
cismas. Ora, isto não poderia ser observado se uma questão sobre a fé não fosse resolvida por quem
governa toda a Igreja, de modo a ser a sua decisão aceita firmemente por toda ela. Por onde, só o Sumo
Pontífice tem autoridade para fazer nova ordenação do símbolo, bem assim tudo o mais respeitante à
Igreja universal, como reunir um sínodo geral e coisas semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Na doutrina de Cristo e dos Apóstolos as verdades da fé
estão suficientemente explicadas. Mas, os maus pervertem a doutrina apostólica e as outras verdades
da Escritura, para perdição deles próprios, no dizer da Escritura. Por isso, foi necessário, no decurso do
tempo, fazer uma explanação da fé, contra os erros ocorrentes.

RESPOSTA À SEGUNDA. – O que o símbolo proíbe e declara se aplica os particulares, que não podem
decidir sobre a fé. Mas tal declaração do sínodo geral não tirou o poder, ao sínodo seguinte, de decretar
um novo símbolo, contendo, não certo, fé nova, senão a mesma, porém, mais desenvolvida. Por isso,
todo sínodo sempre deixou ao seguinte a liberdade de acrescentar qualquer exposição às do
precedente, havendo necessidade de se opor a alguma heresia sobrevinda. O que, pertence ao Sumo
Pontífice, por cuja autoridade o sínodo se reúne e a sua sentença se confirma.

RESPOSTA À TERCEIRA. – Atanásio não compôs uma declaração da fé a modo de símbolo, mas antes, a
modo de doutrina, conforme se colhe da sua maneira mesma de exprimir-se. Mas como a sua doutrina
continha em resumo as verdades íntegras da fé, foi recebida, pela autoridade do Sumo Pontífice, de
modo a ser tida por uma como regra da fé.