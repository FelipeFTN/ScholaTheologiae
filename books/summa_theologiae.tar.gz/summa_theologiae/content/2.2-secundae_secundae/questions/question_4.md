# Questão 4: Da fé em si mesma.
Em seguida devemos tratar da virtude mesma da fé. E primeiro, da fé em si mesma. Segundo, dos que
têm fé. Terceiro, da causa da fé. Quarto, dos seus efeitos.
Na primeira questão discutem-se oito artigos:

## Art. 1 — Se é uma definição exata da fé a que dá o Apóstolo quando diz: É a fé a substância das coisas que se devem esperar um argumento das coisas que não aparecem.
O primeiro discute-se assim. – Parece inexata a definição da fé que dá o Apóstolo, quando diz: É a fé a
substância das coisas que se devem esperar, um argumento das causas que não aparecem.

1. – Pois, nenhuma qualidade é substância. Ora, a fé, sendo uma virtude teologal, como já se
demonstrou, é uma qualidade. Logo, não é substância.

2. Demais. – Virtudes diversas têm objetos diversos. Ora, o que esperamos é objeto da esperança. Logo,
não deve entrar na definição da fé, como seu objeto.

3. Demais. – A fé mais se aperfeiçoa pela caridade do que pela esperança, porque a caridade é a forma
da fé, como a seguir se dirá. Logo, devia-se introduzir, na definição da fé, a coisa que devemos amar, de
preferência à que devemos esperar.

4. Demais. – Uma mesma coisa não deve entrar em gêneros diversos. Ora, substância e argumento, são
gêneros diversos sem subalternação. Logo, inconveniente é dizer que é a fé substância e argumento.

5. Demais. – Um argumento manifesta a verdade daquilo a que se aplica. Ora, chama-se aparente ao
que é de verdade manifesta. Logo, há uma oposição implicada no dito – argumento das causas que não
aparecem. Portanto, a fé está inconvenientemente definida.
Mas, em contrário, basta à autoridade do Apóstolo.

SOLUÇÃO. – Muitos dizem que as palavras citadas do Apóstolo não constituem definição da fé. Quem as
considerar, porém retamente, verá que encerram tudo o que entra em tal definição, embora não
estejam ordenadas em forma de definição. Assim também os filósofos aplicam os princípios dos
silogismos, pondo de parte a forma silogística.
E para evidenciá-lo, devemos considerar que, sendo os hábitos conhecidos pelos atos e estes, pelos seus
objetos, a fé, sendo hábito, deve ser definida pelo seu ato próprio posto em relação com o seu objeto
próprio. Ora, é o ato da fé crer, que como já dissemos, é ato do intelecto determinado a um objeto, por
império da vontade. Assim, pois, o ato de fé se ordena, de um lado, ao objeto da vontade, que é o bem
e o fim, e, de outro, ao do intelecto, que é a verdade. E sendo a fé uma virtude teologal, como já
dissemos, o seu objeto se identifica com o seu fim. Por onde, é necessário que o objeto e o fim da fé se
correspondam proporcionalmente. Ora, como já foi dito, a verdade primeira enquanto inevidente e as
verdades a que, por causa dela, aderimos constituem o objeto da fé. E deste modo, é necessário que a
verdade primeira se comporte, em relação ao ato de fé, como fim, enquanto realiza a essência da
realidade não vista. Ora, isto é essencialmente o que esperamos, conforme aquilo do Apóstolo. O que
não vemos esperamos. Pois, ver a verdade é possui-la. Mas, ninguém espera o que já tem; pois que a
esperança se refere ao que ainda não possuímos como já dissemos.
Assim, pois, a relação entre o ato de fé e o fim o qual é o objeto da vontade, está expressa pelas
palavras: E a fé a substância das coisas que se devem esperar. Pois, de ordinário se chama substância à
primeira incoação de uma coisa qualquer, e sobretudo, quando no princípio primeiro está contido,
virtualmente, tudo quanto dele se segue. Por exemplo, se dissermos que os primeiros princípios
indemonstráveis são a substância da ciência, por serem os primeiros elementos, que temos da ciência,
esses princípios, que a contêm virtualmente toda. Ora, é deste modo que se diz - é a fé a substância das
coisas esperadas, Pois onde a primeira incoação das coisas esperadas, em nós, depende do
assentimento da fé, que contém virtualmente tudo o que esperamos. Pois, esperamos que havemos de
ser felizes por vermos, com visão plena, a verdade a que aderimos pela fé como é claro pelo que já
dissemos antes sobre a felicidade.
Por outro lado, a relação entre o ato de fé e o objeto do intelecto, enquanto objeto da fé, é designada
pela expressão: argumento das coisas que não aparecem. E toma-se o argumento, pelo seu efeito. Pois,
pelo argumento, a inteligência é levada a aderir a alguma verdade; por onde, à mesma adesão firme do
intelecto à verdade da fé que não aparece, chama-se, no caso, argumento. Por isso, outra versão diz -
convicção; pois, pela autoridade divina, o intelecto do crente é convencido a assentir ao que não vê.
Quem quiser, pois, reduzir as palavras referidas à forma de definição, poderá dizer: é a fé um hábito da
mente, pela qual começa a vida eterna em nós, e que faz a inteligência assentir ao que não aparece. -
Por onde, a fé distingue-se de tudo o mais que pertence ao intelecto. Assim, chamando-se - argumento -
distingue-se da opinião, da suspeita e da dúvida, pelas quais não é firme a primeira adesão ela
inteligência a nada. Quando se diz - Das coisas que não aparecem distingue-se a fé da ciência e do
intelecto, que tornam as coisas aparentes. - E enfim, quando se diz - substância das coisas que se devem
esperar - distingue-se a fé virtude, da fé comumente considerada, que não se ordena à beatitude
esperada.
Quanto a quaisquer outras definições dadas da fé, elas são explicações da que dá o Apóstolo. Assim,
Agostinho. É a fé uma virtude pela qual cremos o que não vemos, Damasceno é a fé um consentimento
que não indaga. E outros: É a fé uma determinada certeza da alma; sobre objetos ausentes, superior a
opinião e inferior a ciência. Ora, todas estas definições se identificam com o dito do Apóstolo:
Argumento das coisas que não aparecem. Enfim, a definição de Dionísio - é a fé um fundamento
permanente dos crentes, que os faz ter a verdade e, por eles, a manifesta - é a mesma que a referida:
substância das coisas que se devem esperar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – No texto em questão não se toma substância como
gênero generalíssimo, dividido, por oposição, dos outros gêneros. Mas enquanto que, em qualquer
gênero, se encontra uma certa semelhança de substância. Assim, ao primeiro, em qualquer gênero, que
contém virtualmente, em si, as mais subdivisões dele, se chama substância delas.

RESPOSTÃ À SEGUNDA. – Pertencendo a fé ao intelecto, enquanto imperado pela vontade, há de
necessariamente ordenar-se, como ao fim, aos objetos das virtudes por que se a vontade aperfeiçoa.
Entre elas está a esperança, como a seguir se dirá. Por onde, na definição da fé inclui-se o objeto da
esperança.

RESPOSTA À TERCEIRA. – O amor pode recair tanto sobre o visível como sobre o invisível, sobre o
presente como sobre o ausente. Por isso, o amável não se adapta à fé tão propriamente como o
esperado, porque a esperança recai sempre sobre um objeto ausente e invisível.

RESPOSTA À QUARTA. – A substância e o argumento, enquanto incluídos na definição da fé, não
implicam gêneros diversos dela, nem atos diversos. Mas relações diversas de um ato para objetos
diversos, como do sobredito resulta.

RESPOSTA À QUINTA. – O argumento fundado nos princípios próprios de uma verdade fá-la aparente.
Mas o fundado na autoridade divina não a torna tal. Ora, é um argumento dessa espécie que entra na
definição da fé.

## Art. 2 — Se a fé está na inteligência como no sujeito.
O segundo discute-se assim. – Parece que a fé não está no intelecto, como no seu sujeito.

1. – Pois, como diz Agostinho, a fé consiste na vontade dos crentes. Ora, a vontade é uma faculdade
diferente do intelecto. Logo, a fé não está no intelecto como no seu sujeito.

2. Demais. – O assentimento da fé, com que cremos alguma verdade, provém da vontade obediente a
Deus. Logo, todo o mérito da fé parece fundar-se na obediência. Ora, esta reside na vontade. Portanto,
também a fé, que, por conseguinte, não está na inteligência.

3. Demais. – O intelecto ou é especulativo ou prático. Mas, a fé não reside no intelecto especulativo;
pois, como não se pronuncia sobre nada a ser evitado ou de que devemos fugir como diz Aristóteles,
não é princípio de operação. Ora, é a fé que obra por caridade, no dizer do Apóstolo, Sernelhantemente,
não reside no intelecto prático, cujo objeto é a verdade contingente, factível ou agível; pois é o objeto
da fé a verdade eterna, como do sobredito se colhe. Logo, a fé não esta no intelecto como no seu
sujeito.
Mas, em contrário, a fé sucede a visão na pátria, conforme aquilo da Escritura. Nós agora vemos como
por um espelho, em enigma; mas, então, face a face. Ora, a visão pertence ao intelecto. Logo, também a
fé.

SOLUÇÃO. – Sendo a fé uma virtude, há de o seu ato necessariamente ser perfeito. Ora, a perfeição de
um ato procedente de dois princípios ativos exige sejam esses dois princípios perfeitos. Assim, não pode
cortar bem senão quem tem arte e uma serra bem disposta para cortar. Ora, a disposição para agir bem,
nas potências da alma capazes de tender para termos opostos, é o hábito, como dissemos. Logo, é
necessário que o ato procedente de duas potências tais seja perfeito, em virtude de um hábito
preexistente em ambas as potências. Ora, como já dissemos crer é ato do intelecto, enquanto movido
pela vontade a assentir. Mas esse ato procede da vontade e do intelecto, aos quais é natural
aperfeiçoar-se pelo hábito, conforme já dissemos. Logo, é necessário haver algum hábito, tanto no
intelecto como na vontade, se deve ser perfeito o ato de fé. Assim como também, para ser perfeito o
ato concupiscível, é necessário haver o hábito da prudência na razão, e o da temperança, no
concupiscível. Ora, crer é ato imediato do intelecto; pois, o objeto desse ato é a verdade que,
propriamente, reside no intelecto. Portanto, é necessário resida no intelecto, como no seu sujeito, a fé,
princípio próprio desse ato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Agostinho considera a fé na acepção de ato de fé, que diz
consistir na vontade dos crentes, enquanto que, pelo império da vontade, o intelecto assente às
verdades da fé.

RESPOSTA À SEGUNDA. – Não só é necessário seja a vontade pronta a obedecer, mas também há de
estar o intelecto bem disposto a seguir o império da vontade. Assim como é necessário esteja o
concupiscível bem disposto para obedecer ao império da razão. Portanto, não só é necessário o hábito
da virtude na vontade que impera, mas também no intelecto que assente.

RESPOSTA À TERCEIRA. – A fé reside no intelecto especulativo como no seu sujeito, conforme é
manifesto pelo objeto da mesma. Mas, sendo a verdade primeira objeto da fé, o fim de todos os nossos
desejos e de todas as nossas ações, segundo se vê claramente em Agostinho isso nos leva a agir por
amor. Assim também o intelecto especulativo, por extensão, torna-se prático, como diz Aristóteles.

## Art. 3 — Se a caridade é a forma da fé.
O terceiro discute-se assim – Parece que a caridade não é a forma da fé.

1. – Pois, um ser se especifica pela sua forma. Logo, de coisas que se dividem por oposição, como
espécies diversas de um mesmo gênero, uma não pode ser forma de outra. Ora, a fé se divide da
caridade, por oposição como espécies diversas da virtude. Logo, a caridade não pode ser forma da fé.

2. Demais. – A forma e o ser ao que ela pertence constituem um mesmo sujeito, porque formam um
mesmo ente; absolutamente falando. Ora, a fé reside no intelecto, ao passo que a caridade, na vontade,
Logo, a caridade não é a forma da fé.

3. Demais. – A forma é o princípio do ser. Ora, o princípio da crença, no concernente à vontade, parece
mais ser obediência que caridade, conforme aquilo do Apóstolo. Para que se obedeça à fé em todas as
gentes. Logo, a obediência é mais que a caridade, forma da fé.
Mas, em contrário, todo ser obra pela sua forma. Ora, a fé obra pelo amor. Logo, o amor da caridade é a
forma da fé.

SOLUÇÃO. – Como do sobredito se colhe, atos voluntários se especificam pelo fim, objeto da vontade.
Ora, o princípio da especificação de um ser se comporta, nos seres naturais, ao modo de forma.
Portanto, a forma de qualquer ato voluntário é, de certo modo, o fim a que ela se ordena. Seja porque
se especifica por este: seja também porque o modo da ação há de, por força, corresponder
proporcionalmente ao fim. Ora, é manifesto, pelo que já se disse, que o ato de fé se ordena ao objeto da
vontade, que é o bem, como ao fim. E o bem, fim da fé, a saber, o bem divino, é o objeto próprio da
caridade. Logo, a caridade é considerada forma da fé, enquanto que, por ela, o ato de fé, se aperfeiçoa e
informa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Chama-se a caridade forma da fé por lhe informar o ato.
Pois nada impede seja um mesmo ato informado por diversos hábitos; e portanto, reduzir-se a diversas
espécies, numa certa ordem, como dissemos, ao tratarmos em geral dos atos humanos.

RESPOSTA À SEGUNDA. – A objeção colhe quanto à forma intrínseca. Assim, pois, a caridade não é a
forma da fé, senão enquanto lhe informa o ato, como dissemos acima.

RESPOSTA À TERCEIRA. – A obediência mesma, como a esperança e qualquer outra virtude, que possa
preceder ao ato de fé é informada pela caridade, como a seguir ficará claro. Por onde, a caridade, em si
mesma, é posta como forma da fé.

## Art. 4 — Se a fé informe pode vir a ser informada e inversamente.
O quarto discute-se assim. – Parece que a fé informe não pode vir a ser informada e inversamente.

1. – Pois, como diz a Escritura quando vier o que é perfeito, abolido será o que é em parte. Ora, a fé
informe é imperfeita em relação à informada. Logo, sobrevindo a esta, fica excluída a informe, por não
terem um hábito numeradamente o mesmo.

2. Demais. – O morto não pode vir a ser vivo. Ora, a fé informe é morta, conforme aquilo da Escritura, A
fé sem obras é morta. Logo, a fé informe não pode vir a ser informada.

3. Demais. – A graça de Deus sobreveniente não tem menos efeito, no fiel, que no infiel. Ora,
sobrevindo ao infiel produz-lhe o hábito da fé. Logo, quando sobrevém ao fiel, que antes tinha o hábito
da fé informe, também causa nele outro hábito de fé.

4. Demais. – Como diz Boéci os acidentes não podem alterar-se. Ora, é a fé um acidente. Logo, não pode
a mesma fé ser, ora, informada e, ora, informe.
Mas, em contrário, àquilo da Escritura: A fé sem obras é morta - diz a Glosa - pelas quais revivesce. Logo,
a fé, antes morta e informe torna-se informada e viva.

SOLUÇÃO. – Várias opiniões houve sobre este assunto. – Uns disseram que o hábito da fé informada é
diferente do da informe; mas, sobrevindo a fé informada, desaparece a informe.
E, semelhantemente, ao homem que peca mortalmente, depois de ter a fé informada, sucede outro
hábito, o da fé informe, infundido por Deus. Mas não é admissível, que a graça, sobreveniente exclua
qualquer dom de Deus; nem, por outro lado, que qualquer dom de Deus seja infundido no homem pelo
pecado mortal. - Por isso outros disseram, que a fé informada e a informe tem, certo, hábitos diversos;
contudo, sobrevindo a fé informada, não fica eliminado o hábito da fé informe, mas continua
coexistindo no mesmo sujeito, com o da fé informada. Mas, também é inadmissível, que o hábito da fé
informe venha a ser vão, no que tem a fé informada. - E portanto, devemos dizer, de outro modo, que a
fé informada e a informe tem o mesmo hábito. E a razão é que os hábitos se diversificam pelo que
essencialmente lhes pertence. Ora, sendo a fé uma perfeição do intelecto, pertence-lhe a ela
essencialmente o que pertence ao intelecto. O que porém pertence à vontade não pertence
essencialmente à fé, de modo a poder diversificar o hábito desta. Ora, a distinção entre fé informada e
informe funda-se no pertencente à vontade, isto é na caridade, e não no pertencente ao intelecto. Logo,
a fé informada e a informe não pertencem a hábitos diversos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As palavras do Apóstolo devem aplicar-se ao caso de ser
a imperfeição da essência do ser imperfeito. Pois então e necessariamente, a sobreveniência do perfeito
exclui o imperfeito; assim, quando tivermos a visão clara ficará excluída a fé, que essencialmente se
refere às coisas que não aparecem. Quando porém não é a imperfeição, da essência do ser imperfeito,
então, o ser numericamente o mesmo, que era imperfeito, torna-se perfeito. Assim, a puerícia não é
essencialmente o homem, e por isso o ser numericamente o mesmo, que era criança, se torna homem.
Ora, a informidade não é da essência da fé, pois, existe acidentalmente, como dissemos. Por onde, é a
própria fé informe que se torna informada.

RESPOSTA À SEGUNDA. – O que constitui a vida do animal, isto é, a alma, forma essencial dele,
pertence-lhe por isso, à essência. Por onde, o morto não pode tornar-se vivo, porque diferem entre si
especificamente. Ao contrário, o que torna a fé informada ou viva não é da essência dela. Logo, não há
símile, no caso aduzido.

RESPOSTA À TERCEIRA. – A graça produz a fé, não somente quando esta começa, inicialmente, a existir
no homem, mas também enquanto durar. Pois, como dissemos, Deus sempre opera a justificação do
homem assim como o sol sempre opera a iluminação do ar. Por onde, a graça não obra menos,
sobrevindo ao fiel, que ao infiel. Pois, em um e outro produz a fé: naquele, confirmando-a e
aperfeiçoando-a; neste, causando-a inicialmente. - Ou pode-se dizer que por acidente, isto é, por causa
da disposição do sujeito, é que a graça não causa a fé no crente. Assim como, ao contrário, o pecado
mortal não priva da fé aquele que a perdeu por um pecado mortal precedente.

RESPOSTA À QUARTA. – A fé, em si mesma, não se muda, por tornar-se de informada, informe; mas se
muda o sujeito dela, que é a alma. Pois esta às vezes tem a fé sem a caridade e outras, com a caridade.

## Art. 5 — Se é a fé uma virtude.
O quinto discute-se assim. – Parece que não é a fé uma virtude.
1 – Pois, a virtude, tornando bom quem a possui, como diz o Filósofo, ordena para o bem. Ora, a fé
ordena para a verdade. Logo, não é virtude.

2. Demais. – Mais perfeita é a virtude infusa, que a adquirida. Ora, a fé, pela sua imperfeição, não é
considerada virtude intelectual adquirida, segundo claramente o diz o Filósofo. Logo, com maior razão,
não pode ser considerada virtude infusa.

3. Demais. – A fé informada e a informe são da mesma espécie, como já se disse. Ora, a informe não é
virtude, por não ter conexão com as demais virtudes. Logo, também não o é a fé informada.

4. Demais. – A graça gratuita e o fruto distinguem-se das virtudes. Ora, a fé está enumerada entre as
graças gratuita e também entre os frutos. Logo, não é a fé uma virtude.
Mas, em contrário, o homem se justifica pelas virtudes; pois, a justiça é a virtude total, como diz
Aristóteles. Ora, o homem se justifica pela fé, no dizer da Escritura: Justificados pois pela fé, tenhamos
paz, etc. Logo, é a fé uma virtude.

SOLUÇÃO. –Como do sobredito resulta, a virtude humana torna bom o ato humano. Por onde, todo
hábito, que for sempre princípio de atos bons, pode considerar-se como virtude humana. Ora, tal hábito
é a fé informada. Pois, sendo crer um ato do intelecto, que assente à verdade, por império da vontade,
duas condições se requerem para esse ser perfeito. Uma, que o intelecto tenda infalivelmente para o
seu bem, que é a verdade; outra, que infalivelmente se ordene ao fim último, por causa do qual a
vontade assente à verdade. Ora, ambos esses elementos se encontram na fé informada. Pois, é da
essência mesma da fé, que o intelecto seja sempre levado para a verdade, pois a fé não é susceptível de
falsidades como já estabelecemos. Ora, pela caridade, que informa a fé, a alma tem uma vontade que se
ordena infalivelmente para um fim bom. Logo, é virtude a fé informada.
A fé informe, porém não é virtude, porque, embora tenha o ato de fé informe a perfeição devida, por
parte, do intelecto, não a tem contudo por parte da vontade. Assim como se a temperança existisse no
concupiscíel, e não existisse no racional a prudência, não seria a temperança virtude como já dissemos.
Porque o ato de temperança exige um ato de razão e outro do concupiscível, assim como o ato de fé
exige o ato da vontade e o do intelecto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A verdade, em si mesma, é o bem do intelecto, pois é a
perfeição dele. Por onde, enquanto que pela fé, o intelecto é determinado para o verdadeiro, a fé se
ordena para um certo bem. Mas ulteriormente, enquanto informada pela caridade, também se ordena
para o bem, como objeto da vontade.

RESPOSTA À SEGUNDA. – A fé de que fala o Filósofo se apoia na razão humana que não conclui
necessariamente e é susceptível de falsidade. Por onde, essa fé não é virtude. Ao contrário, a fé de que
tratamos, funda-se na verdade divina infalível e portanto, não é susceptível de falsidade. Portanto, tal fé
pode ser virtude.

RESPOSTA À TERCEIRA. –A fé informada e a informe não diferem especificamente, como se
pertencessem a espécies diversas. Diferem porém como, na mesma espécie, o perfeito, do imperfeito.
Por onde, a fé informe, sendo imperfeita, não realiza perfeitamente a essência da virtude, pois, a virtude
é uma certa perfeição, como diz o Filósofo.

RESPOSTA À QUARTA. – Certos ensinam, que a fé, enumerada entre as graças gratuitas, é a fé informe.
– Mas não é esta opinião fundada, porque as graças gratuitas, no caso enumeradas, não são comuns a
todos os membros da Igreja. Donde o dizer o Apóstolo: Há repartição de graças; e ainda: a um é dado
isto, a outro, aquilo. Ora. a fé informe é comum a todos os membros da Igreja; porque o ser informe não
lhe pertence à substância, enquanto dom gratuito. Por onde, devemos dizer que fé, no caso vertente,
deve ser tomada por alguma excelência dela, por exemplo, pela constância, como diz a Glosa, ou pela
linguagem da fé. Por outro lado, é a fé considerada como fruto, enquanto o seu ato produz certo
deleite, em razão da certeza. Por isso, quando o Apóstolo numera os frutos, a Glosa explica que é a fé a
certeza do invisível.

## Art. 6 — Se é a fé uma só.
O sexto discute-se assim. – Parece que não é uma só a fé.

1. –Pois, assim como é a fé um dom de Deus, conforme diz o Apóstolo, assim também a sabedoria e a
ciência são enumeradas entre os dons de Deus, consoante à Escritura. Ora, a sabedoria e a ciência
diferem, por versar aquela sobre o eterno e esta, sobre o temporal, como está claro em Agostinho. Ora;
versando a fé sobre o eterno e também sobre certas coisas temporais, resulta que a fé não é uma só,
mas consta de partes.

2. Demais. –A confissão é um ato de fé, como já se disse. Ora, nem todos confessam uma mesma fé;
assim, o que nós confessamos como realizado, os antigos padres confessavam como futuro, conforme
está claro nas Escrituras: Eis que uma virgem conceberá. Logo, não é só uma a fé.

3. Demais. –É a fé comum a todos os fiéis de Cristo. Ora, um mesmo acidente não pode existir em
diversos sujeitos. Logo, nem todos podem ter a mesma fé.
Mas, em contrário, o Apóstolo: Um Senhor, uma fé.

SOLUÇÃO. – Considerada como hábito, a fé pode ser tomada em dupla acepção. Primeiro, em relação
ao objeto, havendo então uma só fé. Pois, é o objeto formal da fé a verdade primeira, aderindo à qual
cremos tudo o que a fé contém. Noutra acepção, relativamente ao sujeito; e então a fé se diversifica
com a diversidade dos sujeitos. Ora, é manifesto, que a fé, como qualquer outro hábito, se especifica
pela razão formal do objeto, mas se individua pelo sujeito. Portanto, considerada como hábito, pelo
qual cremos, é especificamente una e numericamente, diferente, nos diversos sujeitos. - Considerada
porém como aquilo em que cremos, embora diversas as suas verdades, acreditadas comumente por
todos, contudo todas se reduzem a uma só.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O que a fé propõe de temporal não lhes pertence ao
objeto, senão ordenadamente a algo de eterno, que é a verdade primeira, como já se disse. Logo, a
mesma fé se refere ao temporal e ao eterno, ao contrário do que se dá com a sabedoria e a ciência, que
consideram o temporal e o eterno conforme a essência própria de um e outro.

RESPOSTA À SEGUNDA. – A diferença assinalada entre o pretérito e o futuro não provém de qualquer
diversidade existente no objeto da fé, mas nas relações diversas dos crentes para com a mesma verdade
crida como também já se estabeleceu.

RESPOSTA À TERCEIRA. – A objeção colhe quanto à diversidade numérica da fé.

## Art. 7 — Se é a fé a primeira das virtudes.
O sétimo discute-se assim. – Parece que não é a fé a primeira das virtudes.
1 – Pois, aquilo do Evangelho - A vós outros, amigos meus, vos digo - diz a Glosa: a fortaleza é o
fundamento da fé. Ora, o fundamento é anterior aquilo que funda. Logo, não é a fé a primeira das
virtudes.

2. Demais. – Aquilo da Escritura - Não queiras imitar - diz a Glosa, que a esperança serve de introdução à
fé. – Ora, a esperança é uma virtude como a seguir se dirá. Logo, não é a fé a primeira das virtudes.

3. Demais. – Como já se disse, o intelecto do crente se inclina a assentir às verdades da fé, por
obediência a Deus. Ora, também a obediência é uma virtude. Logo, não é a fé a primeira das virtudes.

4. Demais. – Não a fé informe é o fundamento, mas a informada, como diz a Glosa a um lugar da
Escritura. Ora, é a fé informada pela caridade, como já se disse. Logo, pela caridade é que a fé vem a ser
o fundamento. Portanto, é a caridade mais que a fé, fundamento; pois, o fundamento é a primeira parte
do edifício. Por consequência, há de ter prioridade sobre a fé.

5. Demais. – Pela ordem dos atos se intelige a dos hábitos. Ora, no ato da fé, o ato da vontade,
aperfeiçoado pela caridade, precede ao do intelecto, que a fé aperfeiçoa, como causa, que precede o
efeito. Logo, a caridade precede à fé e, portanto, esta não é a primeira das virtudes.
Mas, em contrário, diz o Apóstolo que é a fé a substância das causas que se devem esperar. Ora, a
substância vem, por essência, em primeiro lugar. Logo, é a fé a primeira das virtudes.

SOLUÇÃO. –De dois modos pode uma coisa ser primeira que outra: por essência ou por acidente. Ora,
por essência, é a fé a primeira das virtudes. Pois, sendo o fim o princípio das ações como já dissemos,
hão de necessariamente as virtudes teologais, cujo objeto é o fim último, ter prioridade sobre as outras
virtudes. Ora, em si mesmo, é necessário resida o fim último no intelecto, antes de estar na vontade;
pois, a vontade não quer nada senão depois de apreendido pelo intelecto. Ora, está o último fim na
vontade pela esperança e pela caridade, e no intelecto, pela fé. Por onde é necessariamente, é a fé a
primeira de todas as virtudes, porque o conhecimento natural não pode alcançar a Deus, enquanto
objeto da beatitude, para o qual tendem a esperança e a caridade.
Acidentalmente, porém, qualquer virtude pode ter prioridade sobre a fé; mas, uma causa acidental tem
prioridade acidental. Ora, é próprio dessa causa remover o obstáculo, como está claro no Filósofo. E por
aí, certas virtudes podem ser consideradas acidentalmente como anteriores à fé, por removerem os
obstáculos à crença. Assim, a fortaleza remove o temor desordenado, que impede a fé; a humildade,
por seu lado, a soberba, que leva o intelecto à recusa de submeter-se à verdade da fé. E o mesmo pode
dizer-se de certas outras virtudes, embora não sejam verdadeiramente tais, senão pressuposta a fé,
como se vê claramente em Agostinho.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. – A esperança não pode levar, universalmente, a fé. Pois, não se pode ter
esperança na eterna beatitude, se não é esta crida como possível, pois o impossível não constitui objeto
da esperança, segundo do sobredito se colhe. Mas pela esperança pode alguém ser levado a perseverar
na fé ou a ela aderir firmemente; e neste sentido se diz que a esperança conduz à fé.

RESPOSTA À TERCEIRA. – A obediência é susceptível de dupla acepção. - Às vezes implica a inclinação da
vontade a cumprir os mandamentos divinos. E então, não é uma virtude especial, mas se acha
geralmente incluída em todas as virtudes, porque todos os atos virtuosos se compreendem nos
preceitos da lei divina, como já se disse. E neste sentido a obediência é necessária à fé. - Noutro sentido,
a obediência pode ser considerada como implicando uma certa inclinação o cumprir os mandamentos,
enquanto tem a natureza de débito. E então a obediência é uma virtude especial e faz parte da justiça;
pois, dá o devido ao superior, obedecendo-lhe. Segue-se então, neste sentido, à fé, que manifesta ao
homem que Deus é um superior a quem devemos obedecer.

RESPOSTA À QUARTA. – A essência do fundamento não somente exige tenha prioridade, mas também
que seja conexo às outras partes do edifício. Pois fundamento não seria se com ele não estivessem
coesas as outras partes. Ora, a conexão espiritual do edifício se realiza pela caridade, conforme a
Escritura: Sobre tudo isto, revesti-vos da caridade, que é o vínculo da perfeição. Logo, a fé não pode,
sem a caridade, ser fundamento; mas isso não implica seja a caridade anterior à fé.

RESPOSTA À QUINTA – O ato de vontade é pré-exigido à fé; não porém o ato da vontade informado pela
caridade. Pois tal ato pressupõe a fé; porque a vontade não pode tender para Deus com perfeito amor,
se o intelecto não tiver fé reta relativamente a ele.

## Art. 8 — Se é mais certa a fé que a ciência e as outras virtudes intelectuais.
Parece que não é mais certa a fé, que a ciência e as outras virtudes intelectuais.

1. –Pois, a dúvida se opõe à certeza; portanto, está mais certo quem pode duvidar menos, assim como é
mais branco o que tem menos mistura de preto. Ora, o intelecto, a ciência e também a sapiência não
tem dúvida a respeito dos seus objetos. O crente, porém, pode, às vezes, padecer um movimento de
dúvida e duvidar das verdades da fé. Logo, não é mais certa a fé que as virtudes intelectuais.

2. Demais. –A visão é mais certa que a audição. Ora, a fé é pelo ouvido, como diz o Apóstolo mas o
intelecto, a ciência e a sapiência implicam uma certa visão intelectual. Logo, mais certa é a ciência ou o
intelecto, que a fé.

3. Demais. –Quanto mais perfeição há no que pertence ao intelecto, tanto maior certeza existe. Ora, o
intelecto é mais perfeito que a fé, pois, por esta é que se chega aquele, conforme a Escritura. Se não
crerdes não entendereis, segundo outra letra. E também Agostinho diz, que pela ciência e fortifica a fé.
Logo, mais certa é a ciência ou o intelecto, que a fé.
Mas, em contrário, o Apóstolo diz: Quando ouvindo-nos, isto é, pela fé, recebestes de nós outros a
palavra de Deus, vós a recebestes, não como palavra de homens, mas (segundo é verdade) como
palavra de Deus, Ora, nada é mais certo que a palavra de Deus. Logo, a ciência não é mais certa que a fé,
nem nenhuma outra virtude intelectual.

SOLUÇÃO. –Como já dissemos, duas das virtudes intelectuais, a prudência e a arte, versam sobre o
contingente. Ora, a fé tem prioridade sobre elas, quanto à certeza, em razão da sua matéria, que são as
verdades eternas, não susceptíveis de mudança. Quanto às três outras virtudes intelectuais - a
sapiência, a ciência e o intelecto - elas versam sobre o necessário como já dissemos. Devemos, porém,
saber, que a sapiência, a ciência e o intelecto tem dupla acepção: enquanto consideradas pelo Filósofo
virtudes intelectuais; e enquanto dons do Espírito Santo. Ora, na primeira acepção, devemos admitir
que a certeza pode ser considerada à dupla luz. Primeiro, na sua causa; assim, dizemos ser mais certo o
que tem causa mais certa. E a esta luz é mais certa a fé, que as três virtudes referidas, porque se funda
na verdade divina, ao passo que estas, na razão humana. À outra luz podemos considerar a certeza
relativamente ao sujeito. E então dizemos que é mais certo o que o intelecto humano apreende mais
plenamente. Ora, deste modo, são as verdades da fé superiores ao intelecto humano, e não, as que são
do alcance das três sobretidas virtudes. Por onde, a esta luz, é a fé menos certa. Mas uma coisa é
julgada, absolutamente, quando se lhe considera a causa; e acidentalmente, quando se leva em conta a
disposição do sujeito.
Donde, absolutamente considerada, é mais certa a fé; ao passo que as outras virtudes são mais certas
acidentalmente, isto é, em relação a nós. Semelhantemente, consideradas as três virtudes referidas,
como dons da vida presente, estão para a fé como para o princípio que pressupõem. Por onde, ainda
por este lado é mais certa a fé que elas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A dúvida em questão não se funda na fé, mas em nós, por
não podermos alcançar plenamente as verdades da fé.

RESPOSTA À SEGUNDA. –Todas as condições iguais, a vista é mais certa que o ouvido; mas se aquele, de
quem ouvimos, tem uma vista, que excede muito a capacidade da nossa, então o ouvido é mais certo
que a vista, Assim, quem tiver pouca ciência se certificará mais, ouvindo um sábio, do que pelas
verdades vistas pela razão própria. E com maior razão, o homem mais se certificará ouvindo a Deus, que
não pode se enganar, apoiando-se no que vê com a sua razão própria, susceptível de engano.

RESPOSTA À TERCEIRA. –A perfeição do intelecto e da ciência excede o conhecimento da fé, por ter
maior clareza, não porém por ter mais certa a adesão. Pois, toda a certeza do intelecto ou da ciência,
enquanto dons, procede da certeza da fé, assim como a do conhecimento, das conclusões, da certeza
dos princípios. Enquanto porém virtudes intelectuais, a ciência, a sapiência e o intelecto se apoiam na
luz natural da razão, que não tem a certeza da palavra de Deus, em que se baseia a fé.