# Questão 3: Do ato exterior da Fé.
Em seguida devemos tratar do ato exterior da fé, que é a confissão.
E nesta questão discutem-se dois artigos:

## Art. 1 — Se a confissão é um ato de fé.
O primeiro discute-se assim. – Parece que não é a confissão um ato de fé.

1. – Pois, um mesmo ato não pode pertencer a virtudes diversas. Ora, a confissão depende da
penitência, de que é parte. Logo não é ato de fé.

2. Demais. – O temor e também a confusão retraem às vezes o homem de confessar a fé. Por isso, o
Apóstolo pede que orem por ele para que lhe seja dado com confiança fazer conhecer o mistério do
Evangelho. Ora, não afastar-se do bem, por confusão ou temor, procede da fortaleza, que modera a
audácia e o temor. Logo, parece que não é a confissão um ato de fé, mas antes, de fortaleza ou
constância.

3. Demais. – Assim como o fervor da fé nos leva a confessá-la exteriormente, assim também a praticar
outras obras externas; pois, diz o Apóstolo, a fé obra pela caridade. Ora, há outras obras externas, que
não são consideradas atos de fé. Logo, também não a confissão.
Mas, em contrário, sobre aquilo da Escritura - e a obra de fé pelo seu poder - diz a Glosa: Isto é, a
confissão, que é propriamente obra de fé.

SOLUÇÃO. – Os atos exteriores são propriamente atos da virtude a cujo fim especificamente se referem.
Assim, jejuar entra especificamente no fim da abstinência, consistente em reprimir a carne; portanto, é
ato de abstinência. Ora, a confissão das verdades da fé se ordena, especificamente, como ao fim, ao que
à fé pertence, conforme aquilo da Escritura: Nós cremos lendo um mesmo espírito de fé, e por isto é
que falei. Ora, a palavra exterior se ordena a significar o que concebemos na mente. Por onde, assim
como o conceito interior das coisas da fé é propriamente ato de fé, assim também o é a confissão
exterior.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A Escritura louva três espécies de confissão. Uma, as das
verdades da fé; e essa constitui propriamente o ato de fé, como referente ao fim da mesma, segundo se
disse. – Outra é a confissão de ação de graças ou de louvor. E esta constitui o ato de latria; pois se
ordena à honra de Deus, a quem se deve atribuir exteriormente, o que constitui o fim da latria. – A
terceira é a confissão dos pecados. E esta se ordena a deli-los, o que constitui o fim da penitência, à qual
portanto, pertence.

RESPOSTA À SEGUNDA. – O que remove o obstáculo não é causa essencial, mas acidentalmente
falando, como está claro no Filósofo. Por onde, a fortaleza, que remove o obstáculo à confissão da fé,
isto é, o temor ou a vergonha, não é causa própria e essencial da confissão, mas acidental.

RESPOSTA À TERCEIRA. – A fé interna, mediante o amor, causa todos os atos virtuosos exteriores,
mediante todas as outras virtudes, imperadas e não elícitas. Mas produz a confissão como ato próprio,
sem mediação de nenhuma outra virtude.

## Art. 2 — Se a confissão da fé é necessária à salvação.
O segundo discute-se assim. – Parece que a confissão da fé não é necessária à salvação.

1. – Pois, parece que basta para a salvação aquilo pelo que o homem atinge o fim da virtude. Ora, é o
fim próprio da fé a união da mente humana com a verdade divina, o que se pode dar mesmo sem a
confissão exterior. Logo, a confissão da fé não é necessária à salvação.

2. Demais. – Pela confissão exterior o homem manifesta a sua fé aos outros. Ora, isto só é necessário
aos que devem instruí-los na fé. Logo, os simples não são obrigados à confissão da fé.

3. Demais. – O que pode contribuir para escândalo e turbação dos outros não é necessário à salvação.
Pois, diz o Apóstolo: Portai-vos sem dar escândalo nem aos judeus, nem aos gentios, nem à Igreja de
Deus. Ora, a confissão da fé provoca às vezes perturbações nos infiéis. Logo, a confissão da fé não é
necessária à salvação.
Mas, em contrário, diz o Apóstolo: Com o coração se crê, para alcançar a justiça; mas com a boca se faz
a confissão para conseguir a salvação.

SOLUÇÃO. – As coisas necessárias à salvação são da alçada dos preceitos da lei divina. Ora, a confissão
da fé, sendo algo de afirmativo, não pode ser da alçada senão dum preceito afirmativo. Por onde, é das
coisas necessárias à salvação, na medida mesma em que pode ser da alçada de um preceito afirmativo
da lei divina. Ora, os preceitos afirmativos, como já dissemos, não obrigam para sempre embora
obriguem sempre. Pois obrigam conforme o lugar, o tempo e outras circunstâncias devidas, pelas quais
o ato humano deve ser limitado para ser virtuoso. Portanto, confessar a fé não é sempre e em toda
parte necessário à salvação, senão em lugar e tempo determinados. Assim quando, omitindo essa
confissão, tirariamos a honra devida a Deus e também a utilidade que poderia proporcionar ao próximo.
Por exemplo, se alguém, interrogado sobre a fé; calasse e isso fizesse crer, ou que não tem fé, ou que a
fé não fosse verdadeira; ou, calando, desviasse outros da fé. Por onde, em tais casos, é a confissão da fé
necessária para a salvação,

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O fim da fé, como das outras virtudes, deve referir-se ao
da caridade, que é o amor de Deus e do próximo. E portanto quando a honra de Deus ou a utilidade do
próximo o exige, não devemos nos contentar em pela nossa fé, estarmos unidos à verdade divina, mas
devemos confessá-la exteriormente.

RESPOSTA À SEGUNDA. – Em caso de necessidade, onde a fé periclita, todos estão obrigados a propalar
aos outros a sua fé, quer para a instrução ou confirmação dos outros fiéis, quer para reprimir os insultos
dos infiéis. Mas, em tempo ordinário, instruir os homens na fé não pertence a todos os fiéis.

RESPOSTA À TERCEIRA. – Se a perturbação dos infiéis nascer da confissão manifesta da fé, sem
nenhuma utilidade para a mesma ou para os fiéis, não é louvável, em tal caso, confessá-la
publicamente. Por isso, diz o Senhor: Não deis aos cães o que é santo, nem lanceis aos porcos as vossas
pérolas, para que não suceda que, tornando-se contra vós, vos despedacem. Mas, se se esperar alguma
utilidade, ou for necessário devemos confessar a fé publicamente, desprezando a perturbação dos
infiéis por isso, diz o Evangelho que, tendo os discípulos dito ao Senhor, que os Fariseus, depois de
ouvidas as suas palavras, ficaram escandalizados, ele respondeu: Deixei-os, isto é, perturbarem-se:
cegos são e condutores de cegos.