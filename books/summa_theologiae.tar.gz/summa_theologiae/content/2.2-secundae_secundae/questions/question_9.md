# Questão 9: Do dom da ciência.
Em seguida devemos tratar do dom da ciência.
E, nesta questão, discutem-se quatro artigos:

## Art. 1 — Se a ciência é um dom.
O primeiro discute-se assim. – Parece que a ciência não é um dom.

1. – Pois, os dons do Espírito Santo excedem às faculdades naturais. Ora, a ciência implica em resultado
da razão natural; pois, como diz o Filósofo, a demonstração é um silogismo que produz a ciência. Logo, a
ciência não é um dom do Espírito Santo.

2. Demais. – Os dons do Espírito Santo são comuns a todos os santos, como se disse. Ora, Agostinho diz:
muitos fiéis, não eminentes pela ciência, são no pela fé. Logo, a ciência não é um dom.

3. Demais. – O dom é mais perfeito que a virtude, como se disse antes. Logo, um dom basta à perfeição
de uma virtude. Ora, à virtude da fé cor responde o dom do intelecto como já se disse. Logo, não lhe
corresponde o dom da ciência. Nem se vê a que outra virtude corresponda. Logo, sendo os dons
perfeições das virtudes, segundo ficou dito, resulta que a ciência não é um dom.
Mas, em contrário, a Escritura, a considera como um dos sete dons.

SOLUÇÃO. – A graça é mais perfeita que a natureza. Por onde, não pode ser deficiente quando o
homem pode aperfeiçoar-se pela natureza. Ora, quando ele assente pela razão natural e segundo o
intelecto a alguma verdade, por essa verdade aperfeiçoa-se, de duplo modo. Primeiro, pela apreender;
segundo, porque tem por ela um juízo certo. Por isso duas condições se exigem para o intelecto humano
assentir perfeitamente à verdade da fé. Uma, compreender bem o objeto proposto, o que pertence ao
dom do intelecto, como já se disse. Outra, fazer, do objeto proposto, juízo certo e reto, discernindo o
que deve crer, do que não o deve. E para tal é necessário o dom da ciência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os diversos seres, segundo a diversidade das suas
condições, tem certezas diversas no conhecimento. Assim, o homem julga com certeza da verdade pelo
discurso da razão; e por isso a ciência humana é adquirida pela razão demonstrativa. Mas Deus julga
com certeza da verdade por simples intuição, sem nenhum discurso, como dissemos na Primeira Parte.
Por isso a ciência divina não é discursiva ou raciocinativa, mas absoluta e simples. E a ela é semelhante a
ciência considerada como dom do Espírito Santo, por ser uma semelhança participada do mesmo.

RESPOSTA À SEGUNDA. – Sobre o objeto da fé podemos ter duas espécies de ciência. Uma pela qual
sabemos o que devemos crer, discernindo-o do que não o devemos. E neste sentido a ciência é um dom
e a tem todos os santos. - Outra é a ciência sobre o objeto da fé, pela qual, sabemos não só o que
devemos crer, mas também como manifestar a fé, levar outros a crerem e refutar os adversários. E essa
ciência é considerada parte das graças gratuitas, dadas, não a todos, mas só a certos. Por isso, Agostinho
acrescenta às palavras citadas: Uma causa é saber somente o que o homem deve crer; outra, como, com
isso mesmo que crê, socorra aos que tem fé e a defenda contra os ímpios.

RESPOSTA À TERCEIRA. – Os dons são mais perfeitos que as virtudes morais e intelectuais. Mas não
mais que as virtudes teologais: antes, todos os dons se ordenam, como a fim, à perfeição das virtudes
teologais. Logo, não há incongruência em dons diversos se ordenarem a uma mesma virtude teologal.

## Art. 2 — Se o dom da ciência versa sobre as coisas divinas.
O segundo discute-se assim. – Parece que o dom da ciência versa sobre as coisas divinas.

1. – Pois, como diz Agostinho, é a fé gerada, nutrida e fortificada pela ciência. Ora, a fé diz respeito às
coisas divinas, porque o seu objeto é a verdade primeira como se estabeleceu. Logo, também o dom da
ciência versa sobre as coisas divinas.

2. Demais. – O dom da ciência é mais digno que a ciência adquirida. Ora, há uma ciência adquirida - a
metafísica - que versa sobre as coisas divinas. Logo, com maior razão, sobre elas versa o dom da ciência.

3. Demais. – Como diz a Escritura as causas invisíveis de Deus se veem, consideradas pelas obras que
foram feitas. Se pois há ciência das coisas criadas, também o haverá das divinas.
Mas, em contrário, Agostinho. A ciência das causas divinas se chama propriamente sabedoria; a das
causas humanas, por seu lado, tem a denominação própria de ciência.

SOLUÇÃO. – Formamos um juízo reto sobre uma coisa quando lhe consideramos a causa. Por onde, a
ordem dos juízos há por força de depender da ordem das causas. Ora, assim como a causa primeira o é
da segunda, assim por aquela julgamos desta. Ao contrário, da causa primeira não podemos julgar por
meio de nenhuma outra. Por isso o juízo feito por meio da causa primeira é o primeiro e perfeitíssimo.
Sempre porém que existe um ser perfeitíssimo, o nome comum de gênero se apropria ao que se afasta
por deficiência, desse ser, ao qual se aplica outra espécie de nome, como se vê na lógica. Assim, no
gênero das proposições convertíveis, à que significa a quididade se dá o nome especial de definição,
mas as proposições convertíveis, que dela se afastam por deficiência, conservam a denominação
comum e chamam-se propriedades,
Ora, implicando o nome de ciência uma determinada certeza do juízo, como se disse: quando obtida por
meio da causa altíssima, tal certeza tem o nome especial de sabedoria. Assim, sábio se chama, em cada
gênero de sabedoria, quem conhece a causa altíssima desse gênero, pela qual pode julgar de tudo o
mais, que dele depende. - Sábio, absolutamente falando, chama-se, porém, quem conhece a causa
altíssima absoluta, Deus. Por isso, o conhecimento das coisas divinas se chama sabedoria. Ao passo que
o das humanas se denomina ciência, denominação quase comum, que implica a certeza do juízo,
apropriada ao que é baseado nas causas segundas. Por onde, tomado nessa acepção, o nome de ciência
é considerado um dom distinto do da sabedoria. Por isso, tal dom só versa sobre as coisas humanas ou
sobre as criadas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora verse a fé sobre as coisas divinas e eternas,
contudo, em si mesma, é um bem temporal da alma do crente. Por isso, saber o que devemos crer é
próprio do dom da ciência. Ao passo que conhecer as verdades que cremos, em si mesmas, por uma
certa união com elas, pertence ao dom da sabedoria. Por onde, este dom corresponde antes à caridade,
que une a mente do homem a Deus.

RESPOSTA À SEGUNDA. –A objeção colhe quando o nome de ciência é tomado em acepção comum.
Pois, nesse sentido, não é considerada um dom especial, restringindo-se ao juízo baseado nas coisas
criadas.

RESPOSTA À TERCEIRA. –Como já dissemos todo hábito cognoscitivo diz respeito, formalmente, ao meio
pelo qual um objeto é conhecido; e materialmente, ao que é conhecido por tal meio. E tendo prioridade
o que é formal, as ciências que concluem, partindo de princípios matemáticos, em relação à matéria
natural, consideram-se, antes como matemáticas, a que mais se assemelham, embora, pela matéria,
mais se aproximem das ciências naturais. E por isso, Aristóteles diz que são sobretudo naturais. Por
onde, como o homem conhece a Deus por meio das coisas criadas, esse conhecimento constitui, antes,
ciência, a que formalmente diz respeito, que sabedoria, a que só materialmente pertence. E ao inverso,
quando pelas coisas divinas julgamos dos seres criados, isso constitui antes sabedoria, que ciência.

## Art. 3 — Se a ciência, considerada como dom, é uma ciência prática.
O terceiro discute-se assim. – Parece que a ciência, considerada como dom, é uma ciência prática.
1 – Pois, como diz Agostinho, a ação pela qual usamos das coisas externas depende da ciência. Ora, a
ciência, de que a ação depende, é prática. Logo, a ciência, como dom, é prática.

2. Demais. – Gregório diz. De nada serve a ciência, de que nenhuma utilidade tira a piedade; e mui inútil
é a piedade, que carece do discernimento da ciência. Dessa citação se conclui que a ciência dirige a
piedade. Ora, isto não pode caber à ciência especulativa. Logo, a ciência, como dom, não é especulativa,
mas prática.

3. Demais. – Só os justos tem o dom do Espírito Santo como já se estabeleceu. Ora, também os injustos
podem ter a ciência especulativa, conforme a Escritura. Aquele que sabe fazer o bem, e não o faz, peca.
Logo, a ciência, como dom, não é especulativa, mas prática.
Mas, em contrário, Gregório diz: A ciência prepara um banquete para o seu dia próprio, porque, no mais
íntimo do intelecto vence o jejum da ignorância. Ora, a ignorância não fica totalmente eliminada senão
pelas duas ciências - a especulativa e a prática. Logo, a ciência, considerada como dom, é especulativa e
prática.

SOLUÇÃO. – Conforme já se disse, o dom da ciência, como o do intelecto, se ordena à certeza da fé. Ora
esta, primária e principalmente, consiste na especulação, isto é, na união à verdade primeira. Mas sendo
esta também o fim último por causa do qual obramos, dai vem que a fé também se estende à operação,
conforme aquilo da Escritura: A fé obra por caridade. Por onde, o dom da ciência há de, primária e
principalmente, implicar na especulação, pela qual o homem sabe o que deve, pela fé, admitir;
secundariamente porém, se estende também à operação, porque, pela ciência das verdades da fé e do
que delas resulta, nos dirigimos nas nossas ações.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Agostinho se refere ao dom da ciência enquanto
extensivo às obras; pois, atribui-lhe a ação, mas, não só ela, nem primariamente. E deste modo também
dirige a piedade.
Donde SE DEDUZ CLARA A RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. – Conforme o que já dissemos a respeito do dom do intelecto, nem todos os
que compreendem têm esse dom, mas só quem compreende por hábito da graça. Assim também,
quanto ao dom da ciência, devemos entender, que só o possuem os que, por infusão da graça, fazem
juízo reto do que devem crer e agir, de modo a não se desviarem em nada da retidão da justiça. E esta é
a ciência dos santos, de que fala a Escritura. O justo o Senhor o guiou por caminhos direitos e lhe deu a
ciência dos santos.

## Art. 4 — Se ao dom da ciência corresponde a terceira bem-aventurança, que é: Bem-aventurados os que choram, porque eles serão consolados.
O quarto discute-se assim. – Parece que ao dom da ciência não corresponde a terceira bem-
aventurança, que é: Bem-aventurados os que choram, porque eles serão consolados.

1. – Pois, assim como é o mal a causa da tristeza e das lágrimas, assim, é o bem a causa da alegria. Ora,
pela ciência, manifestam-se mais principalmente os bens, que os males, que pelos bens se conhecem;
pois, o reto é juiz de si mesmo e também do incorreto, como diz Aristóteles. Logo, a referida bem-
aventurança não corresponde convenientemente ao dom da ciência.

2. Demais. – A consideração da verdade é um ato de ciência. Ora, nessa consideração não há tristeza,
mas antes, alegria, conforme a Escritura a sua conversação não em nada de desagradável, nem a sua
companhia nada de fastidioso, mas o que nela se acha é a satisfação e prazer. Logo, a referida bem-
aventurança não corresponde convenientemente ao dom da ciência.

3. Demais. – O dom da ciência consiste antes na especulação que na operação. Ora, enquanto
consistente na especulação, não lhe correspondem as lágrimas, porque o intelecto especulativo nada diz
sobre o que se deve imitar e fugir, como afirma Aristóteles, nem implica nada de alegre e de triste. Logo,
não se pode dizer, que a referida bem-aventurança corresponda ao dom da ciência.
Mas, em contrário, Agostinho: A ciência convém aos que choram, que souberam os males a que estão
adstritos e os pediram como bem.

SOLUÇÃO. – À ciência propriamente pertence o reto juízo sobre as criaturas. Ora, há criaturas pelas
quais o homem se desvia, ocasionalmente, de Deus, conforme aquilo da Escritura: As criaturas se
fizeram um objeto de abominação e um laço para os pés dos insensatos, isto é, dos que não as julgam
retamente, pensando existir nelas o bem perfeito; e por isso, nelas constituindo o seu fim, pecam e
perdem o verdadeiro bem. Ora, este dano o homem o conhece julgando retamente das criaturas, o que
faz pelo dom da ciência. Por isso, a bem-aventurança das lágrimas é considerada como correspondente
ao dom da ciência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os bens criados não provocam a alegria espiritual senão
enquanto referidos ao bem divino, donde propriamente resulta aquela alegria. Por onde e diretamente,
a paz espiritual e a alegria consequente correspondem ao dom da sabedoria. Por outro lado, ao dom da
ciência correspondem, primeiro, as lágrimas provocadas pelos erros passados; e por consequência, a
consolação, quando o homem, pelo juízo reto da ciência, ordena as criaturas ao bem divino. Por isso,
nessa bem-aventurança, consideram-se as lágrimas como mérito e a consolação consequente, como
prêmio, a qual, começada nesta vida, perfaz-se na futura.

RESPOSTA À SEGUNDA. –O homem se alegra com o pensamento mesmo da verdade. Ao passo que,
pode às vezes contristar-se por causa daquilo cuja verdade considera. E neste sentido, as lágrimas
atribuem-se à ciência.

RESPOSTA À TERCEIRA. – À ciência, enquanto consistente na especulação, não corresponde nenhuma
bem-aventurança. Porque a felicidade do homem não consiste na consideração das criaturas, mas na
contemplação de Deus. Mas, de algum modo, essa felicidade consiste no uso devido das criaturas e na
afeição ordenada para com elas. Mas digo isto, quanto à felicidade desta vida. Por onde, à ciência não é
atribuída nenhuma bem-aventurança pertinente à contemplação, mas, sim, ao intelecto e à sabedoria,
que versam sobre as coisas divinas.