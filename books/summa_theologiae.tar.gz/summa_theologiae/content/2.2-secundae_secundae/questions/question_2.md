# Questão 2: Do ato de Fé.
Em seguida devemos tratar do ato de fé.
E primeiro, do ato interior. Segundo, do ato exterior.
Na primeira questão discutem-se dez artigos:

## Art. 1 — Se crer é cogitar com assentimento.
O primeiro discute-se assim. – Parece que crer não é cogitar com assentimento.

1. – Pois, a cogitação implica investigação; porque cogitar é quase coagitar, ou agitar simultaneamente.
Ora, Damasceno diz ser a fé um assentimento não indagativo. Logo, cogitar não pertence ao ato de fé.

2. Demais. – A fé se funda na razão, como a seguir se dirá. Ora, cogitar é ato da potência cogitativa, que
pertence à parte sensitiva, como se disse na Primeira Parte. Logo, a cogitação não pertence à fé.

3. Demais. – Crer é ato do intelecto, porque o seu objeto é a verdade. Ore, parece que assentir, como
consentir, não é ato do intelecto, mas da vontade conforme já se disse. Logo, crer não é cogitar com
assentimento.
Mas, em contrário, Agostinho define assim crer.

SOLUÇÃO. - A palavra cogitar pode tomarse em triplíce acepção. – Primeiro, em comum, para significar
qualquer consideração atual do intelecto, Assim, Agostinho diz: Pela que denomino inteligência é que
inteligimos cogitando. –Noutra e mais própria acepção, chama-se cogitar à consideração do intelecto
acompanhada de uma certa investigação, antes de alcançada a perfeição do mesmo, pela certeza da
visão. E neste sentido Agostinho ensina não se diz que o Filho de Deus é cogitação, mas sim, o verbo de
Deus. Porque, quando a nossa cogitação, alcança o objeto da ciência e é por ele informada, o nosso
verbo é verdadeiro. Por onde, o Verbo de Deus deve ser compreendido como sem cogitação, sem nada
de formal, que possa ser informe. E assim sendo, chama-se propriamente cogitação ao movimento da
alma, que delibera, ainda não tornado perfeito pela plena visão da verdade. Ora, esse movimento pode
ser da alma, que delibera sobre intenções universais, o que pertence à parte intelectiva, ou sobre
intenções particulares, o que pertence à parte sensitiva. Por onde, cogitar, na segunda acepção, é
tomado pelo ato do intelecto deliberante; na terceira, pelo ato da virtude cogitativa.
Se pois tomarmos a palavra cogitar em comum, conforme à primeira acepção, a expressão - cogitar com
assentimento - não significa tudo quanto a crença essencialmente implica. Pois, nessa acepção, também
quem considera no que sabe ou intelige cogita com assentimento. – Tomado porém na segunda
acepção, cogitar implica na essência total o ato da crença. Pois, certos dos atos pertinentes ao intelecto
implicam um firme assentimento, sem a tal cogitação. Assim, quando consideramos o que sabemos ou
inteligimos, essa consideração já é informada. Outros atos do intelecto porém importam, por certo,
numa cogitação informe sem firme assentimento. Quer por não penderem para nenhuma parte, como
se dá com quem duvida; quer, por penderem mais para uma parte, mas dependerem de algum leve
sinal, como sucede com quem suspeita; quer, por aderirem a uma parte, mas com temor de que a outra
seja a verdadeira, como acontece com quem opina. Ora, o ato de crer implica e adesão firme a uma das
partes. Por aí, o crente convém com o que sabe e intelige. E, contudo, o seu conhecimento não é
perfeito, pela visão manifesta; por onde, convém com o de quem duvida, suspeita e opina. E, assim, é
próprio de quem crê cogitar com assentimento. E por isso, o ato de crer distingue-se de todos os atos do
intelecto, relativos à verdade e à falsidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A fé não implica a investigação da razão natural,
demonstrativa daquilo em que se crê. Implica porém uma certa investigação daquilo pelo que o homem
é levado a crer; por exemplo, por ter sido dito por Deus e confirmado por milagres.

RESPOSTA À SEGUNDA. – Cogitar, aqui, não se toma como ato da virtude cogitativa, mas enquanto
pertencente ao intelecto, como se disse.

RESPOSTA À TERCEIRA. – O intelecto do crente é determinado a um só objeto, não racional, mas
voluntariamente. Por onde, assentimento, aqui, se toma pelo ato do intelecto, enquanto é, pela
vontade, determinado a um objeto.

## Art. 2 — Se o ato da fé se distingue convenientemente em ato de crer a Deus, crer Deus e crer em Deus.
O segundo discute-se assim. – Parece que se distingue inconvenientemente o ato de fé em ato de crer
a Deus, crer Deus e crer em Deus.

1. – Pois, a cada hábito corresponde um ato. Ora, a fé, sendo virtude, é um hábito. Logo, é
inconveniente admitirem-se vários atos de fé.

2. Demais. – O comum a todos os atos de fé não deve ser considerado como um ato de fé particular.
Ora, crer a Deus está compreendido em geral em todo ato de fé, porque esta se funda na verdade
primeira. Logo, parece inconveniente distingui-la de outros atos também de fé.

3. Demais. – O que também convém aos infiéis não pode ser considerado de fé. Ora, crer na existência
de Deus também os infiéis o creem. Logo, não deve ser considerado ato de fé.

4. Demais. – Mover-se para o fim é próprio da vontade, cujo objeto é o bem e o fim. Ora, crer é ato, não
da vontade, mas do intelecto. Logo, não se deve estabelecer diferença nenhuma no ato de crer em
Deus, o que implica movimento para o fim.
Mas, em contrário, Agostinho faz a distinção referida.

SOLUÇÃO. – O ato de toda potência ou hábito é considerado relativamente à ordem entre a potência ou
o hábito e o seu objeto. Ora, o objeto da fé pode ser considerado à tríplice luz. Pois, crer, sendo ato
próprio do intelecto, enquanto movido pela vontade a assentir, como já dissemos objeto da fé pode ser
considerado, quer em relação ao intelecto mesmo, quer à vontade motora do intelecto. Ora, se o
considerarmos em relação ao intelecto, dois elementos podemos distinguir no ato de fé, como
dissemos. Um é o seu objeto material, e então se diz que é um ato de fé crer Deus; porque, como já
dissemos nada nos é proposto a crer senão enquanto diz respeito a Deus. Outro é a razão formal do
objeto, que é como o meio pelo qual assertimos nele, como crível; e então se considera ato de fé crer a
Deus; pois conforme já dissemos, o objeto formal da fé a verdade primeira a que o homem adere, afim
de por ela assentir no que crê. - Se porém considerarmos, ao terceiro modo, o objeto da fé, enquanto é
o intelecto movido pela vontade, então consideramos ato de fé crer em Deus, Pois, a verdade primeira
de refere à vontade, enquanto ela exerce a função de fim.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As três distinções feitas não designam atos diversos de fé,
mas um só e mesmo ato mantendo relações diversas com o objeto da fé.
Donde se deduz a RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. – Crer Deus não cabe aos infiéis, enquanto considerado ato de fé. Pois, não
creem Deus existente dependentemente das condições determinadas pela fé. Por onde, nem creem
verdadeiramente Deus, pois, no dizer do Filósofo, ausência do nosso conhecimento, em relação aos
seres simples, consiste só em totalmente não os atingirmos.

RESPOSTA À QUARTA. – Como já se disse, a vontade move o intelecto e as mais potências da alma para
o fim; e neste sentido é considerado ato de fé crer em Deus.

## Art. 3 — Se crer é necessário à salvação.
O terceiro discute-se assim. - Parece que crer não é necessário à salvação.
1 – Pois, à conservação e à perfeição de um ser basta o que lhe convém à natureza. Ora, as verdades da
fé excedem a razão natural dos, homem, por lhe não serem manifestas, como já se disse. Logo, crer não
é necessário à salvação.

2. Demais. – É arriscado darmos nosso assentimento quando não podemos julgar da verdade ou
falsidade do que nos propõem, conforme a Escritura: Porventura o ouvido não julga das palavras? Ora,
ele não pode julgar as verdades de fé pelas não poder resolver nos princípios primeiros pelos quais julga
de tudo. Logo, é arriscado dar fé a tais verdades. Portanto, crer não é necessário à salvação.

3. Demais. – A salvação o homem está em Deus, conforme a Escritura. A salvação dos justos vem do
Senhor. Ora, as causas invisíveis de Deus se veem consideradas pelas obras que foram feitas; ainda a sua
virtude sempiterna e a sua divindade, no dizer do Apóstolo. Ora, no que vemos, pelo intelecto, não
cremos. Logo, não é necessário, para nossa salvação, crermos em nada.
Mas, em contrário, a Escritura: sem fé é impossível agradar a Deus.

SOLUÇÃO. – Duas coisas existem, em todas as naturezas ordenadas, concorrentes à perfeição de uma
natureza inferior; uma, conforme ao seu movimento próprio; outra, ao da natureza superior. Assim, a
água, por movimento próprio, move-se para o centro; porém, pelo movimento da lua, move-se em
torno do centro, pelo fluxo e refluxo. Semelhantemente, os orbes planetários movem-se, por
movimento próprio, do ocidente para o oriente; mas, em virtude do movimento do primeiro orbe, do
oriente para o ocidente. Só a natureza racional criada se ordena imediatamente para Deus. Porque as
outras criaturas não atingem a nenhum termo universal, senão só particular, participantes da divina
bondade, quer pela existência somente, como os seres inanimados, quer ainda pelo viver, e pelo
conhecimento do particular, como as plantas e os animais. A natureza racional, porém, conhecendo a
noção universal de bem e de ser, ordena-se imediatamente ao princípio universal do ser. Logo, a
perfeição da criatura racional consiste, não somente no que lhe convém à natureza, mas também no
que lhe advém por uma certa participação sobrenatural da divina bondade, por isso, como dissemos
antes, a felicidade última do homem consiste numa certa visão sobrenatural de Deus, mas que ele não
pode alcançar senão por uma como instrução do mestre divino, conforme àquilo da Escritura. Todo
aquele que do Pai ouviu e aprendeu vem a mim. Ora, o homem torna-se participante dessa ciência, não
imediata, mas sucessivamente, ao modo da sua natureza. E todo o que a aprende há de por força crer,
para alcançar a ciência perfeita, como também o Filósofo o diz: é necessário que quem aprende creia.
Por onde, para o homem chegar à visão perfeita da felicidade, é necessário, antes, crer em Deus, como
o discípulo crê no mestre que ensina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como a natureza do homem depende de uma natureza
superior, não lhe basta à sua perfeição o conhecimento natural, mas é necessário outro, sobrenatural,
como já se disse.

RESPOSTA À SEGUNDA. – Assim como o homem, pelo natural lume do intelecto, assente aos princípios,
assim o virtuoso adquire pelo hábito da virtude, o juízo reto sobre o que lhe à virtude convém. E deste
modo também, pelo lume da fé, infundido divinamente, o homem assente às verdades da fé e não, ao
que lhe é contrário. Por onde, não incorrem em nenhum perigo de danação os que creem em Cristo
Jesus, iluminados por ele, por meio da fé.

RESPOSTA À TERCEIRA. – A fé percebe mais, das coisas invisíveis de Deus, e de modo mais alto, do que a
razão natural, que parte das criaturas para chegar a Deus. Por isso, diz a Escritura: Muitas causas em
grande número - te têm sido patenteadas, que excedem o entendimento do homens.

## Art. 4 — Se é necessário crer no que a razão natural pode provar.
O quarto discute-se assim. – Parece não ser necessário crer no que a razão natural pode provar.

1. – Pois, se nas obras da natureza nada há de supérfluo, com maioria de razão nas de Deus. Ora, o que
se pode fazer de um modo é inútil fazer-se também de outro. Logo, o que se pode conhecer pela razão
natural inutilmente se haveria de receber da fé.

2. Demais. – Precisamos crer naquilo que é objeto da fé. Ora, ciência e fé não recaem sobre o mesmo
objeto, como se estabeleceu. Logo, versando a ciência sobre tudo o que pode ser conhecido pela razão
natural, resulta não ser necessário crer no que se prova pela razão natural.

3. Demais. – Todos os objetos cognoscíveis têm a mesma razão. Se pois certos deles nos são propostos
para serem cridos, pela mesma razão seriamos forçados a crer em todos. Ora, isto é falso. Pois, não é
necessário crermos no que podemos conhecer pela razão natural.
Mas, em contrário, é necessário crer em Deus uno e incorpóreo, o que é provado pelos filósofos, por
meio da razão natural.

SOLUÇÃO. – É forçoso aceitemos, pela fé não só o que é superior à razão, mas também o que por esta
podemos conhecer. E isto por três razões. - Primeiro, para chegarmos mais prontamente ao
conhecimento da verdade divina. Pois, a ciência a que pertence provar a existência, de Deus, e o mais
que a Ele diz respeito, é nos proposta ao estudo em último lugar, pressupostas antes muitas outras
ciências. Por onde, só depois de muitos anos de vida poderíamos chegar ao conhecimento de Deus. –
Em segundo lugar, para ser mais geral o conhecimento de Deus. Pois, muitos não podem adiantar-se no
estudo das ciências, quer pelo embotamento do engenho, quer pelas ocupações e necessidades da vida
temporal; quer ainda por serem tardes no aprender. Ora, esses tais ficariam absolutamente privados do
conhecimento de Deus, se as verdades divinas não lhes fossem propostas pela fé. – Em terceiro lugar,
por causa da certeza. Pois, a razão humana é muito deficiente; aplicada às coisas divinas. E a prova está
em terem os filósofos, que as perscrutaram por uma investigação natural, errado em muitos pontos, e
opinado uns contrariamente aos outros. Logo, para os homens terem de Deus um conhecimento isento
de dúvidas e certo, foi necessário lhes fossem as verdades divinas transmitidas por meio da fé; como
ditada por Deus, que não pode mentir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A investigação da razão natural não basta ao gênero
humano para conhecer as coisas divinas, mesmo as que podem ser demonstradas pela razão. Logo, não
é supérfluo crermos nas verdades da fé.

RESPOSTA À SEGUNDA. – Um mesmo sujeito não pode ter ciência e fé de um mesmo objeto. Mas, o
sabido por um pode ser acreditado por outro, como já dissemos.

RESPOSTA À TERCEIRA. – Embora todos os objetos cognoscíveis convenham entre si, quanto à noção de
ciência, não convêm, contudo em se ordenarem igualmente à felicidade. Por isso nem todos são
igualmente propostos a serem cridos.

## Art. 5 — Se estamos obrigados a crer em alguma coisa explicitamente.
O quinto discute-se assim. – Parece não estarmos obrigados a crer em nada explicitamente.

1. – Pois, ninguém está obrigado ao que lhe está fora do poder. Ora, crer em alguma coisa
explicitamente não está no poder do homem, conforme diz a Escritura. Como creram aqueles que não
ouviram? Como ouviram sem pregador? Porém como pregarão eles se não forem enviados? Logo, não
estamos obrigados a crer em nada explicitamente.

2. Demais. – Nós nos ordenamos a Deus, tanto pela fé, como pela caridade. Ora, não estamos obrigados
a guardar os preceitos sobre a caridade, bastando-nos só a preparação do ânimo, como bem o
demonstra o preceito do Senhor assim formulado: Se alguém te ferir na tua face direita, oferece-lhe
também a outra. O mesmo se vê em preceitos semelhantes, como expõe Agostinho. Logo, também não
estamos obrigados a crer em nada explicitamente, bastando-nos só ter a alma preparada para crer as
coisas propostas por Deus.

3. Demais. – O bem da fé consiste numa certa obediência, conforme a Escritura: Para que se obedeça à
fé em todas as gentes. Ora, a virtude da obediência não exige que o homem observe certos e
determinados preceitos, bastando-lhe só ter o ânimo pronto a obedecer, conforme a Escritura: Pronto
estou, e em nada me tenho perturbado, para guardar os teus mandamentos. Logo, parece também
bastar, para a fé, tenhamos o ânimo pronto a crer tudo o que nos for proposto por Deus, sem crer em
nada explicitamente.
Mas, em contrário, diz a Escritura. É necessário que o que se chega a Deus creia que há Deus, e que é
remunerador dos que o buscam.

SOLUÇÃO. – Os preceitos da lei, que o homem está obrigado a cumprir, regulam os atos das virtudes,
que são a via para chegarmos à salvação. Ora, o ato de virtude, como já se disse, se funda na relação do
hábito com o objeto; e no objeto de qualquer virtude podemos distinguir os dois elementos seguintes. O
que propriamente e em si o constitui e necessariamente existe em todo ato virtuoso; e além disso o que
acidental ou consequentemente se relaciona com a essência própria do objeto.
Assim, ao objeto da fortaleza, propriamente e em si mesmo, pertence afrontar um perigo mortal e
arrostar o inimigo, correndo perigo por causa do bem comum. Mas o armar-se o homem ou ferir a
outrem numa guerra justa, ou cometer qualquer ato semelhante, reduz-se certo ao objeto da fortaleza,
mas por acidente. Logo, a determinação do ato virtuoso, quanto ao objeto próprio e essencial da
virtude, depende necessariamente de um preceito, assim como o ato mesmo da virtude. Mas, a
determinação, desse ato, quanto ao que diz respeito acidental ou secundariamente ao objeto próprio e
essencial da virtude, não depende necessariamente de um preceito, salvo em certos lugares e tempos.
Logo, devemos concluir, que o objeto essencial da fé é tornar o homem feliz, como já dissemos.
Acidental e secundariamente porém, relaciona-se com o objeto da fé tudo quanto contém a Sagrada
Escritura, transmitido por Deus, como: Abraão teve dois filhos, Davi foi filho de Isai, e coisas
semelhantes. Quanto, pois às primeiras coisas que devemos crer que são os artigos de fé, estamos
explicitamente obrigados a crê-las, assim como estamos obrigados a ter fé. Quanto ao mais, que
constitui objeto de crença, não estamos obrigados a crê-lo, explicita, mas só implicitamente, ou como
preparação do ânimo, dispondo-nos a crer tudo o que a divina Escritura contém. Mas estamos obrigados
a crê-lo explicitamente quando nos constar esteja incluído em matéria de fé.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Quando dizemos que alguma coisa está no poder do
homem, prescindindo do auxílio da graça, torná-lo-emos obrigado ao que não pode conseguir sem esse
auxílio, como, amar a Deus e ao próximo e, semelhantemente, crer nos artigos de fé. Ora, isto ele o
pode, com o auxílio da graça. E tal auxílio Deus o dá a uns, misericordiosamente, e nega a outros pela
sua justiça, como pena de algum pecado precedente ou, pelo menos, do pecado original, conforme
Agostinho.

RESPOSTA À SEGUNDA. – O homem está obrigado a amar, determinadamente, tudo quanto é amável e
constitui própria e essencialmente objeto da caridade - Deus e o próximo. Mas a objeção colhe quanto
aos preceitos de caridade que, quase consequentemente, se incluem no objeto da caridade.

RESPOSTA À TERCEIRA. – A virtude da obediência reside propriamente, na vontade. Por onde, para o
ato de obediência basta a prontidão da vontade sujeita a quem ordena, a qual é o objeto próprio e
essencial da obediência. Mas tal preceito ou tal outro se relaciona acidental ou consequentemente com
o objeto próprio e essencial da obediência.

## Art. 6 — Se todos estão obrigados igualmente a ter fé explícita.
O sexto discute-se assim. – Parece que nem todos estão obrigados a ter fé explícita.

1. – Pois, todos estão obrigados ao necessário à salvação como é claro relativamente aos preceitos da
caridade. Ora, o conhecimento explícito das verdades da fé é necessário para a salvação, como já se
disse. Logo, todos estão igualmente obrigados a crer explicitamente.

2. Demais. – Ninguém deve examinar o que não está obrigado a crer explicitamente. Ora, às vezes
também os simples são examinados sobre os mínimos artigos de fé. Logo, todos são obrigados a crer
todas as verdades explicitamente.

3. Demais. – Se os simples não estão obrigados a ter fé explícita, mas só implícita, é forçoso tenham fé
implícita na fé dos entendidos. Ora, isto é arriscado, pois pode dar-se que os entendidos errem. Logo,
também os simples devem ter a fé explícita. Portanto, todos estão obrigados por igual a crer
explicitamente.
Mas, em contrário, diz a Escritura: Os bois aravam e as jumentas pastavam junto a eles, porque os
simples, simbolizados pelas jumentas, devem no atinente às coisas da fé, aderir aos entendidos,
simbolizados pelos bois, como o expõe Gregório.

SOLUÇÃO. – A explicação das verdades da fé faz-se pela revelação divina, porque essas verdades
excedem à razão natural. Ora, a revelação divina se transmite numa certa ordem, pelos entendidos aos
ignorantes, assim como, aos homens, pelos anjos e aos anjos inferiores, pelos superiores, como está
claro em Dionísio. Logo, por igual razão, é necessário chegue a explicação da fé aos ignorantes pelos
entendidos. Portanto, assim como os anjos superiores, que iluminam os inferiores, tem conhecimento
mais pleno das coisas divinas, do que estes, conforme diz Dionísio, assim também os entendidos, a
quem pertence ensinar os outros, são obrigados a um conhecimento mais pleno das verdades da fé e a
crer nelas mais explicitamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Ter fé explícita nas verdades da fé não é igualmente
necessário a todos, para a salvação. Pois, são obrigados a ter explicitamente fé mais ampla, que os
outros, os entendidos, que têm a obrigação de instrui-los.

RESPOSTA À SEGUNDA. – Os simples não devem ser examinados sobre as subtilezas da fé, salvo quando
há suspeita de estarem corrompidos pelos heréticos que de ordinário lhes corrompem a fé no que
respeita às subtilezas desta. Se contudo, se reconhecer que não aderem pertinazmente à doutrina
perversa, e erram em tais questões por simplicidade, tais erros não se lhes podem imputar.

RESPOSTA À TERCEIRA. – Os ignorantes não têm fé implícita na fé dos esclarecidos, senão enquanto
estes aderem à doutrina divina. Donde o dizer o Apóstolo: Sede meus imitadores, como também eu o
sou de Cristo, Por onde, não é o conhecimento humano a regra da fé, mas a verdade divina. E se alguns
entendidos perderem a fé, não prejudicam a dos simples, que creem terem na aqueles reta, salvo se
aderirem pertinazmente e em particular aos erros deles, contra a fé da Igreja Universal, que não pode
errar, conforme o diz o Senhor. Mas eu roguei por ti para que a tua fé não falte.

## Art. 7 — Se crer explicitamente no mistério de Cristo é necessário à salvação, para todos.
O sétimo discute-se assim. – Parece que crer explicitamente no mistério de Cristo não é necessário à
salvação, para todos.
1 – Pois, o homem não está obrigado a crer no que os anjos ignoram, porque a fé é exposta
explicitamente pela revelação divina, que chegou aos homens mediante os anjos, como já se disse. Ora,
também os anjos ignoraram o mistério da encarnação, e por isso perguntava. Quem é este rei da glória?
E noutro lugar: Quem é este que vem de Edom? Conforme a exposição de Dionísio. Logo, os homens
não estavam obrigados a crer explicitamente no mistério da encarnação.

2. Demais. – É certo que João Batista era homem esclarecido e muitíssimo próximo de Cristo; dele disse
o Senhor: entre os nascidos de mulheres não se levantou outro maior que João Batista. Ora, parece que
João Batista não conheceu explicitamente o mistério de Cristo, pois lhe perguntou: Tu és o que hás de
vir ou é outro o que esperamos? Logo, os esclarecidos também não estavam obrigados a ter fé explícita
em Cristo.

3. Demais. – Muitos gentios alcançaram a salvação pelo ministério dos anjos, como diz Dionísio. Ora, os
gentios não tiveram em Cristo fé, nem explícita nem implícita, segundo parece, porque nenhuma
revelação lhes foi feita. Logo, parece que crer explicitamente o mistério de Cristo não era necessário a
todos, para a salvação.
Mas, em contrário, Agostinho diz: É sã a fé com a qual cremos que, nenhum homem, de maior ou menor
idade, podia libertar-se do contágio da morte e da contaminação do pecado, senão por Jesus Cristo,
mediador único entre Deus e os homens.

SOLUÇÃO. – Como já dissemos, própria e essencialmente pertence ao objeto da fé aquilo pelo que o
homem alcança a felicidade. Ora, a via para os homens chegarem à felicidade é o mistério da
encarnação e da paixão de Cristo, pois, diz a Escritura, o céu abaixo nenhum outro nome foi dado aos
homens pelo qual nós devamos ser salvos, Por onde, no mistério da encarnação de Cristo todos deviam
de algum modo crer em todos os tempos, embora diversamente, segundo a diversidade dos tempos e
das pessoas.
Pois, antes do estado do pecado, o homem tinha fé explícita na encarnação de Cristo, enquanto
ordenada à consumação da glória; mas não, enquanto ordenada à libertação do pecado, pela paixão e
pela ressurreição, porque o homem não tinha preciência do pecado futuro. Mas tinha preciência da
encarnação de Cristo, pelo dito da Escritura: Por isso deixará o homem o seu pai e a sua mãe e se unirá à
sua mulher; e o Apóstolo: Este sacramento é grande em Cristo e na Igreja. Ora, não é crível ignorasse o
primeiro homem tal sacramento.
Depois do pecado porém, o mistério de Cristo foi crido explicitamente, não só quanto à encarnação,
mas também quanto à paixão e à ressurreição, pelas quais o gênero humano foi libertado do pecado e
da morte. Pois, do contrário, não teria sido figurada a paixão de Cristo por certos sacrifícios, tanto antes
da lei como sob o regime dela. E o significado desses sacrifícios os instruídos conheciam explicitamente;
mas os simples, crendo, embora veladamente, terem tais sacrifícios sido ordenados por Deus para
significarem a Cristo, que devia vir, tinham, de certo modo, um conhecimento velado. E como já
dissemos, conheceram tanto mais distintamente o pertencente ao mistério de Cristo quanto mais
próximos se achavam dele.
Mas, uma vez a graça revelada, tanto os instruídos como os simples estão obrigados a ter fé explícita
nos mistérios de Cristo; sobretudo quanto ao que a Igreja soleniza em geral e propõe publicamente,
como são os artigos da encarnação, a que já nos referimos. E quanto às subtilezas sobre os artigos da
encarnação estamos obrigados a crê-los mais ou menos explicitamente, conforme ao que convém ao
estado e às obrigações de cada um de nós.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Aos anjos não escapou de todo o mistério do reino de
Deus, como diz Agostinho. Mas, com a revelação de Cristo, conheceram mais perfeitamente certas
razões desse mistério.

RESPOSTA À SEGUNDA. – João Batista não perguntou sobre o advento de Cristo encarnado, como se o
ignorasse, pois ele o confessou expressamente, dizendo: Eu o vi e dei testemunho de que Ele é o Filho
de Deus. Por isso, não interrogou: Tu és o que vieste? mas: Tu és o que hás de vir? Perguntando no
futuro e não, no pretérito. - Semelhantemente, não se deve crer ignorasse que Ele viria para a paixão,
pois, ele mesmo o disse: Ele aqui o cordeiro de Deus, eis aqui o que tira o pecado do mundo,
prenunciando-lhe a imolação futura. Demais disso, os outros profetas já o tinham predito, como está
claro, sobretudo em Isaias. - Logo, pode-se dizer, segundo Gregório que interrogou ignorando se havia
de descer em pessoa própria ao inferno. Pois sabia que a virtude da sua paixão havia de estender-se até
aos que estavam encerrados no limbo, conforme a Escritura: Tu também pelo sangue do teu testamento
fizeste sair os teus presos do lago em que não há água. Nem estava obrigado a crer nisso explicitamente
antes de ter cumprido o dever, a si mesmo imposto, de descer. - Ou pode-se dizer, conforme Ambrósio,
que não perguntou por dúvida ou ignorância, mas antes, por piedade. - Ou pode-se admitir, com
Crisóstomo, que não perguntou como se ignorasse, mas para, por meio de Cristo, satisfazer-lhe aos
discípulos; e por isso Cristo respondeu, para instrução deles, mostrando os sinais das obras.

RESPOSTA À TERCEIRA. – A muitos dos gentios foi feita revelação de Cristo, como claramente o
demonstra o que predisseram. Assim, num lugar a Escritura diz: Sei que o meu redentor vive. Também a
Sibila prenunciou certas coisas a respeito de Cristo, como diz Agostinho. E outrossim se lê na história dos
romanos, que, no tempo de Constantino Augusto e de Irene, sua mãe, se descobriu certo sepulcro onde
jazia um homem tendo uma lâmina de ouro no peito, na qual estava escrito: Cristo nascerá da Virgem e
eu creio nele. Ó Sol, nos tempos de Irene e de Constantino, de novo me verás. - Se porém houve que
foram salvos, a quem não foi feita a revelação, não o foram sem a fé no Mediador. Porque, embora não
tivessem tido fé explícita, tiveram-na porém implícita na Divina Providência, crendo que Deus é o
libertador dos homens, por modos que lhe aprazem, e que Ele mesmo revelou a certos, que
conheceram a verdade, conforme àquilo da Escritura: O qual nos instrui mais que aos animais da terra.

## Art. 8 — Se crer na Trindade explicitamente é de necessidade para a salvação.
O oitavo discute-se assim. – Parece que crer na Trindade explicitamente, não é de necessidade para a
salvação.

1. – Pois, diz o Apóstolo: é necessário que o que se chega a Deus creia que há Deus, e que é
remunerador dos que o buscam. Ora, isso podemos crer sem ter fé na Trindade, Logo, não é necessário
ter fé explícita na Trindade.

2. Demais. – O Senhor diz. Pai, eu manifestei o teu nome aos homens. O que expõe Agostinho: E o meu
nome aquele pelo qual és chamado, não Deus, mas, Pai meu. E em seguida acrescenta: Por ter feito este
mundo, Deus foi conhecido de todas as gentes, por não dever ser adorado com os falsos deuses, foi
conhecido na Judéia; enfim, enquanto Pai de Cristo, por quem tira o pecado do mundo, manifestou aos
homens esse seu nome, que antes lhes era oculto. Logo, antes do advento de Cristo, não se sabia, que a
divindade incluía a paternidade e a filiação. Portanto a Trindade não era explicitamente crida.

3. Demais. – Devemos crer explicitamente que Deus é o objeto da felicidade. Ora, o objeto da felicidade
é a suma bondade, que pode entender-se existente em Deus mesmo, sem a distinção de pessoas. Logo,
não é necessário crer explicitamente na Trindade.
Mas, em contrário, no Testamento Velho está muitas vezes expressa a Trindade das Pessoas. Assim, no
principio, para exprimi-la diz: Façamos o homem à nossa imagem e semelhança. Logo, desde o princípio,
era necessário, para a salvação, crer explicitamente na Trindade.

SOLUÇÃO. – Não se pode crer o mistério de Cristo, explicitamente, sem ter fé na Trindade. Pois, esse
mistério implica a encarnação do Filho de Deus, que renovou o mundo pela graça do Espírito Santo; e
além disso, que foi concebido pelo Espírito Santo. Por onde, do mesmo modo que o mistério de Cristo
foi antes ele Cristo, explicitamente crido 'pelos homens instruídos e, implícita e quase
obumbradamente, pelas pessoas simples, assim também o mistério da Trindade. Portanto, mesmo
depois do tempo em que a graça foi divulgada, todos estão obrigados a crer explicitamente no mistério
da Trindade. E todos os renascidos em Cristo o alcançam, invocando a Trindade, conforme aquilo da
Escritura: Ide e ensinai a todas as gentes, batizando-as em nome do Padre e do Filho e do Espírito Santo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Essas duas verdades citadas devem-nas crer
explicitamente, de Deus, todos e em todo tempo. Mas, não basta as creiam todos e em todo tempo.

RESPOSTA À SEGUNDA. – Antes do advento de Cristo, a fé na Trindade estava incluída na fé dos antigos,
instruídos. Mas Cristo a manifestou ao mundo pelos Apóstolos.

RESPOSTA À TERCEIRA. – A suma bondade de Deus, ao modo pelo qual agora, pelos seus efeitos, a
compreendemos, pode ser inteligida sem a Trindade das Pessoas. Mas, considerada em si mesma,
enquanto vista pelos bem-aventurados, não o pode, sem a Trindade das Pessoas. Demais disso, a missão
mesma das Pessoas divinas nos conduz à felicidade.

## Art. 9 — Se crer é meritório.
O nono discute-se assim. – Parece que crer não é meritório.

1. – Pois, o princípio do mérito é a caridade, como já se disse: Ora, a fé - como a natureza - é um
preâmbulo à: caridade. Logo, assim como um ato natural não é meritório, porque pelas nossas
faculdades naturais não merecemos, também não o é o ato de fé.

2. Demais. – Crer é meio termo entre opinar e saber ou considerar no que se sabe. Ora, a indagação
científica não é meritória, como também não o é a opinião. Logo, também não é meritório crer.

3. Demais. – Quem assente pela fé em algum princípio, ou tem causa suficiente que induz a crer, ou não
a tem. Se tem causa suficiente que o leva a crer, essa crença não lhe é meritória, por já não ser livre de
crer ou não. Se ao contrário, não tem causa suficiente, que o leve a crer, a. sua crença é uma leviandade,
conforme àquilo da Escritura: Aquele que crê de leve é leviano de coração; e, portanto, a crença não lhe
é meritória. Logo, de nenhum modo, é meritório crer.
Mas, em contrário, diz a Escritura: os santos, pela fé, alcançarão as promessas, – Ora, tal não se daria se,
crendo, não merecêssemos. Logo, o ato mesmo de crer é meritório.

SOLUÇÃO. – Como já dissemos, os nossos atos são meritórios, enquanto procedentes do livre arbítrio
movido pela graça de Deus. Por onde, todo ato humano, dependente do livre arbítrio e referido a Deus,
pode ser meritório. Pois, crer é ato do intelecto, que assente à verdade divina, por império da vontade,
movida pela graça de Deus; e assim, depende do livre arbítrio ordenado para Deus. Logo, o ato de fé
pode ser meritório.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A natureza está para a caridade, princípio do mérito,
como está a matéria para a forma; ao passo que a fé está para a caridade como disposição precedente à
última forma. Ora, é manifesto que o sujeito ou matéria, nem qualquer disposição precedente, pode
agir em virtude da forma, antes de recebê-la. Mas depois de havê-la recebido, tanto o sujeito como a
disposição precedente age em virtude dela, princípio principal do agir. Assim, o calor do fogo age em
virtude da forma substancial. Por onde, nem a natureza nem a fé, sem a caridade, podem produzir um
ato meritório; mas, a caridade sobreveniente torna meritório o ato de fé, bem como o da natureza e do
livre arbítrio natural.

RESPOSTA À SEGUNDA. – Dois elementos podemos considerar na ciência: o assentimento, que dá o
sujeito, que sabe, àquilo que sabe, e a consideração da coisa sabida. O assentimento à ciência não
depende do livre arbítrio, porque o ciente está obrigado a assentir, por força da demonstração. Logo, o
assentimento à ciência não é meritório. Porém, a consideração atual da coisa sabida depende do livre
arbítrio, pois, o homem pode considerar ou não. Portanto, a consideração da ciência pode ser meritória,
quando referida ao fim da caridade, isto é, à honra de Deus ou à utilidade do próximo, Ora, na fé, tanto
esta utilidade como a honra de Deus dependem do livre arbítrio. Logo, tanto em relação à esta como
àquela, o ato de fé pode ser meritório. A opinião, porém, não implica firme assentimento, por ser débil
e fraca, segundo o Filósofo. Por isso não procede da vontade perfeita; e portanto, quanto ao
assentimento, não participa quase da essência do mérito. Mas, por parte da consideração atual, pode
ser meritória.

RESPOSTA À TERCEIRA. – Quem crê tem razão suficiente que o leva a crer; pois é levado a tal pela
autoridade da doutrina divina, confirmada pelos milagres: e o que mais é pela moção interior e
convidativa de Deus. Portanto, não crê com leviandade. Contudo, não tem causa suficiente que o leve a
saber o que portanto, não elimina essencialmente o mérito.

## Art. 10 — Se a razão conducente às verdades da fé diminui o mérito desta.
O décimo discute-se assim. – Parece que a razão conducente às verdades da fé, diminui o mérito
desta.
1 – Pois, diz Gregório: a fé fundada na experiência da razão humana não é meritória. Se portanto a razão
humana, fundando suficientemente a experiência, exclui totalmente o mérito da fé, resulta que
qualquer razão humana, aduzida para levar às verdades da fé, diminui o mérito desta.

2. Demais. – Tudo o que diminui essencialmente a virtude diminui o mérito, porque a felicidade é o
prémio da virtude, como diz o Filósofo. Ora, parece que a razão humana diminui essencialmente a
virtude mesma da fé, porque consiste a essência desta em recair sobre o que não aparece como se disse
antes. Ora, quanto mais razões se aduzem para provar alguma verdade, tanto mais esta deixa de ser não
aparente. Logo, a razão humana, aduzida para fundar as verdades da fé, diminui o mérito desta.

3. Demais. – Os contrários têm causas contrárias. Ora, o que se aduz em contrário à fé aumenta-lhe o
mérito, quer se trate de uma perseguição, forçando a abandonar a fé, quer de alguma razão que tal
persuada. Logo, a razão, que coadjuva a fé, diminui-lhe o mérito.
Mas, em contrário, diz a Escritura: Aparelhados sempre para responder a lodo o que vos pedir razão
daquela esperança que há em vós. Ora, o Apóstolo não induziria a isso se tal diminuísse o mérito da fé.
Logo, a razão não diminui esse mérito.

SOLUÇÃO. – Como já dissemos o ato de fé pode ser meritório, enquanto dependente da vontade, não
só quanto ao uso, mas também quanto ao assentimento. Ora, a razão humana aduzida para provar as
verdades da fé, pode manter dupla relação com a vontade do crente. - Uma, enquanto precedente;
como quando alguém não tem vontade, ou não tem vontade pronta para crer, sem a tal ser induzido
por uma razão humana. E então, a razão humana aduzida diminui o mérito da fé. Porque, como já
dissemos, a paixão precedente à eleição, nas virtudes morais, diminui o mérito do ato virtuoso. Pois,
assim como o homem deve exercer os atos das virtudes morais guiando-se pelo juízo da razão e não,
pela paixão, assim também deve crer as verdades da fé, não por causa da razão humana, mas da
autoridade divina. – De outro modo, a razão humana pode comportar-se como consequente em relação
à vontade do crente. Pois, quando o homem tem a vontade pronta para crer, ama a verdade crida,
medita sobre ela e a abraça, se descobrir razões que o levem a tal. E neste sentido, não exclui a razão
humana o mérito da fé; antes, é sinal de maior mérito; assim como também a paixão consequente, nas
virtudes morais, revela uma vontade mais pronta, como já dissemos. E é isto o que significa o lugar da
Escritura referente ao que disseram os Samaritanos à mulher, figurativa da razão humana: Não é sobre
o teu dito que cremos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Gregório se refere ao caso de o homem não ter vontade
de crer, senão por causa da razão aduzida. Pois, quando tem vontade de crer as verdades da fé, só pela
autoridade divina, mesmo se tiver alguma razão demonstrativa de alguma dessas verdades, por
exemplo, que Deus existe isso não lhe elimina nem diminui o mérito da fé.

RESPOSTA À SEGUNDA. – As razões aduzidas para fundar a autoridade da fé não são demonstrações,
que possam ser reduzidas à visão inteligível do intelecto humano. Por onde, não deixam de ser relativas
ao não aparente. Mas removem os obstáculos à fé, mostrando não ser impossível o que ela propõe. Por
isso, tais razões não diminuem o mérito nem a essência da fé. Porém as razões demonstrativas aduzidas
para fundar essas verdades, e que são apenas preâmbulos para os artigos da fé, embora diminuam
essencialmente esta, por tornarem aparente o que ela propõe, não diminuem, contudo essencialmente
a caridade, que torna a vontade pronta a crê-las, embora não apareçam. Portanto, também não
diminuem essencialmente o mérito.

RESPOSTA À TERCEIRA. – O que repugna à fé, no que respeita, quer à reflexão humana, quer às
perseguições externas, aumenta o mérito da mesma na medida em que revela uma vontade mais
pronta e firme em crer. Por isso também os mártires tiveram maior mérito na fé, não a abandonando
por causa das perseguições. E também os sapientes tem, maior mérito em crer, não abandonando a fé
por causa das razões dos filósofos ou dos heréticos aduzidas contra ela. Mas o que convém à fé nem
sempre diminui a prontidão da vontade em crer; e, portanto, nem sempre diminui o mérito da fé.