# Questão 5: Dos que tem a Fé.
Em seguida devemos tratar dos que tem a fé.
E nesta questão, discutem-se quatro artigos:

## Art. 1 — Se nem o anjo, nem o homem, na sua condição primitiva, tinham fé.
O primeiro discute-se assim. –Parece que nem o anjo, nem o homem, na sua condição primitiva,
tinham fé.

1. –Pois, como diz Hugo de S. Victor, não tendo o homem olhos contemplativos, não pode ver a Deus
nem o que em Deus existe. Ora, o anjo, no estado da sua condição primitiva, antes da confirmação ou
da queda, não tinha vista contemplativa, pois, via as coisas no verbo, como diz Agostinho.
Semelhantemente, o primeiro homem, no estado de inocência, parece tinha os olhos abertos à
contemplação, conforme Hugo de S. Victor, nas suas Sentenças. O homem, diz, no seu primitivo estado,
conhecia o seu Criador, não por um conhecimento exterior alcançado só por ouvir dizer, mas antes, pelo
que ministra a inspiração interior; não, ao modo por que, nesta vida, os crentes buscam pela fé, a Deus
ausente, mas como, então, era visto, mais manifestamente, ela presença da contemplação. Logo, nem o
homem nem o anjo tinham fé, no estado da condição primitiva.

2. Demais. –O conhecimento da fé é enigmático e obscuro, conforme a Escritura: Nós agora vemos
como por um espelho, em enigmas. Ora, no estado da condição primitiva, nenhuma obscuridade havia
no homem nem no anjo, porque a obscuridade é pena do pecado. Logo, a fé, no estado dessa condição,
não podia existir nem no homem nem no anjo.

3. Demais. –O Apóstolo diz: a fé é pelo ouvido. Ora, como no estado primitivo da sua condição, nem o
anjo nem o homem podiam ouvir nada de outrem, não havia lugar para a fé. Logo, neste estado, não
tinha fé nem o homem nem o anjo.
Mas, em contrário, diz o Apóstolo: é necessário que o que se chega a Deus creia que há Deus, e que é
remunerador dos que o buscam. Ora, o anjo e o homem, na sua condição primitiva, achavam-se em
estado de se chegar a Deus. Logo, não tinham fé.

SOLUÇÃO. –Certos dizem, que os anjos, antes da confirmação e da queda, e os homens, antes do
pecado, não tinham fé por gozarem então da contemplação clara das coisas divinas. Mas é a fé
argumento das causas, que não aparecem, segundo o Apóstolo; e cremos, pela fé, o que não vemos, no
dizer de Agostinho. Por onde, exclui a fé, por essência, só aquela clareza que torna aparente ou visto o
objeto sobre que principalmente recai. Ora, é o objeto principal da fé a verdade primeira, cuja visão,
que sucede à fé, nos torna felizes. Portanto, não tendo o anjo, antes da confirmação, nem o homem,
antes do pecado, a beatitude pela qual vissem a Deus por essência, é manifesto que não tinham
conhecimento tão claro que excluísse a fé, na sua essência. Portanto, o não terem fé não podia ser
senão por lhes ser completamente desconhecido o objeto da mesma. Porém se o homem e o anjo
foram criados no estado de pura natureza, como certos dizem, talvez se pudesse admitir que não
tinham fé, nem este, antes da confirmação, nem aquele, antes do pecado. Pois, é o conhecimento da fé
superior ao natural que, não só o homem, mas também o anjo tem de Deus.
Ora, já estabelecemos, na Primeira Parte, que o homem e o anjo foram criados com o dom da graça.
Portanto, é necessário admitir-se que, pela graça recebida e ainda não consumada, tinham uma certa
incoação da felicidade esperada. Pois esta, começa na vontade pela esperança e pela caridade e no
intelecto, pela fé como já dissemos. Logo, devemos concluir, que tanto o anjo, antes da confirmação,
como o homem, antes do pecado, tinham fé.
É preciso entretanto notar-se, que o objeto da fé tem um elemento quase formal, que é a verdade
primeira, superior a todo conhecimento natural da criatura; e outro, material, como aquilo a que
assentimos, aderindo à verdade primeira. Quanto ao primeiro destes elementos, a fé existe comumente
em todos os que tem conhecimento de Deus, mas ainda não alcançaram a felicidade futura, unindo-se à
verdade primeira. Quanto porém às verdades propostas para serem materialmente cridas, certos
acreditam o que outros sabem claramente, mesmo no estado da vida presente como já dissemos. E
assim sendo, também podemos dizer que o anjo, antes da confirmação, e o homem, antes do pecado,
tiveram conhecimento claro de certos aspectos dos mistérios divinos, que agora só podemos conhecer,
crendo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora as palavras de Hugo de S. Victor sejam magistrais
e tenham a força da autoridade, podemos, contudo dizer, que a contemplação incompatível com a
necessidade da fé é a da pátria, onde será a verdade sobrenatural vista por essência. Ora, esta visão não
tinha o anjo, antes da confirmação, nem o homem, antes do pecado. A contemplação deles, porém, era
mais alta que a nossa; pois, aproximando-se, por ela, mais de Deus, podiam conhecer mais verdades,
manifestamente, sobre os divinos efeitos e os mistérios, do que podemos nós. Portanto, não existia
neles fé com que buscassem a Deus ausente, como nós buscamos; pois Deus lhes era presente pelo
lume da sabedoria, mais que a nós, embora nem a eles fosse de tal modo presente como o é aos bem
aventurados pelo lume da glória.

RESPOSTA À SEGUNDA. –No estado da condição primitiva do homem ou do anjo não havia a
obscuridade da culpa nem ao da pena. Havia porém no intelecto humano ou angélico, uma certa
obscuridade natural, pela qual toda criatura é treva comparada à imensidade da luz divina. Ora, tal
obscuridade basta para existir, em essência, a fé.

RESPOSTA À TERCEIRA. –No estado da condição primitiva, o homem não ouvia a ninguém que
exteriormente lhe falasse, senão a Deus inspirando interiormente. Assim também os profetas ouviam,
conforme aquilo da Escritura. Ouvirei o que o Senhor Deus me falar.

## Art. 2 — Se os demônios tem fé.
O segundo discute-se assim. – Parece que os demônios não tem fé.
1 – Pois, como diz Agostinho, a fé consiste na vontade dos crentes, Ora, boa é a vontade pela qual
queremos crer em Deus. Não havendo porém nos demônios nenhuma vontade deliberadamente boa,
como já se disse, resulta que neles não há fé.

2. Demais. –É a fé um dom da graça divina, segundo a Escritura. Pela graça é que sois salvos, mediante a
fé, porque é um dom de Deus. Ora, os demônios perderam os dons gratuitos, pelo pecado, como diz a
Glosa àquilo da Escritura: Eles põem os olhos nuns deuses estrangeiros e gostam do bagaço das uvas.
Logo, a fé não subsistiu nos demônios, depois do pecado.

3. Demais. –A infidelidade é considerada o mais grave dos pecados, como claramente o diz Agostinho
sobre aquilo da Escritura: Se eu não viera e não lhes tivera falado, não teriam eles pecado ; mas agora
não tem desculpa no seu pecado. Ora, certos homens cometem o pecado de infidelidade. Portanto, se
os demônios tivessem fé, certos homens cometeriam um pecado mais grave que o deles, o que é
inadmissível. Logo, os demônios não tem fé.
Mas, em contrário, a Escritura: Os demônios creem e estremecem.

SOLUÇÃO. –Como já dissemos, o intelecto de quem crê assente no objeto em que crê, não por que o
veja, em si mesmo, ou pela resolução aos primeiros princípios intuitivos, mas por império da vontade.
Ora, de dois modos pode a vontade mover o intelecto a assentir. Primeiro, pela ordenação dela para o
bem, e então crer é ato louvável. De outro modo, por ficar o intelecto convencido, de maneira a julgar
que deve crer naquilo que foi dito, embora não esteja convencido da evidência disso. Tal o caso do
profeta, que prenunciasse, em nome de Deus, um acontecimento futuro e mostrasse um sinal,
ressuscitando um morto. Então esse sinal convenceria o intelecto, de quem o visse, que manifestamente
conheceria a predição como vinda de Deus, que não mente, embora não fosse tal acontecimento do
futuro evidente em si mesmo. Portanto, não ficaria desse modo, eliminada a fé, na sua essência. Por
onde, devemos concluir, que dos fiéis é a fé louvável ao primeiro modo, pelo qual não existe nos
demônios, em que só do segundo modo existe. Pois veem muitos indícios manifestos por onde
percebem que a doutrina da Igreja vem de Deus, embora não vejam as verdades mesmas que a Igreja
ensina, por exemplo, que Deus é trino e uno e outras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A fé, nos demônios, é de certo modo, forçada pela
evidência dos sinais. Por onde, o que creem não lhes redunda em mérito para a vontade.

RESPOSTA À SEGUNDA. –A fé que é dom da graça inclina o homem a crer, por algum desejo do bem,
embora informe. Por onde, a fé, nos demônios, não é dom da graça, pois ao contrário, são forçados a
crer pela perspicácia do intelecto natural.

RESPOSTA À TERCEIRA. –O que desagrada aos demônios é serem compelidos a crer nos sinais da fé, tão
evidente são eles. Portanto, o que creem de nenhum modo lhes diminui a malícia.

## Art. 3 — Se o herético, que não crê num artigo de fé, pode ter fé informe nos outros.
O terceiro discute-se assim. –Parece que o herético, que não crê num artigo de fé, pode ter fé informe
nos outros.

1. –Pois, o intelecto natural do herético não é mais potente que o do católico. Ora, este, para crer em
qualquer artigo de fé, precisa ser ajudado pelo dom da mesma. Logo, também os heréticos não podem,
sem o dom da fé informe, crer em nenhum artigo de fé.

2. Demais. –Assim como a fé contém muitos artigos, assim também uma mesma ciência, por exemplo, a
geometria, abrange muitas conclusões. Ora, qualquer pode ter a ciência de certas conclusões
geométricas, ignorando as outras. Logo, também pode ter fé em uns artigos, e não em outros.

3. Demais. –Assim como o homem obedece a Deus, para crer em certos artigos, assim também, para
observar os mandamentos da lei. Ora, pode ser obediente em relação a uns mandamentos e não, a
outros. Logo, pode ter fé nuns artigos e não, em outros.
Mas, em contrário. –Assim como um pecado mortal contraria a caridade, assim descrer num artigo
contraria à fé. Ora, a caridade não subsiste no homem depois do pecado mortal. Logo, nem a fé, em
quem não crê num artigo.

SOLUÇÃO. –O herético, que descrê um artigo, não tem o hábito da fé informada, nem o da informe. E a
razão é que a espécie de qualquer hábito depende da razão formal do objeto, a qual, desaparecida, a
espécie do hábito não pode subsistir. Ora, é o objeto formal da fé a verdade primeira manifestada pelas
Sagradas Escrituras e pela doutrina da Igreja. Por onde, quem quer que não adira, como a uma regra
infalível e divina, à doutrina da Igreja, procedente da verdade primeira manifestada pela Sagrada
Escritura, não tem o hábito da fé. Aceita, porém as verdades da fé de modo diferente do que, por ela as
aceitaria. Assim como quem admitisse mentalmente alguma conclusão, sem lhe conhecer o meio por
que é demonstrada, manifestamente não tem dela a ciência, mas só a opinião. Ora, é claro que quem
adere à doutrina da Igreja, como à regra infalível, assente a, tudo o que a Igreja ensina. Do contrário, se,
do que ela ensina, aceitasse como lhe apraz, umas coisas e não, outras, já não aderiria a essa doutrina,
como à regra infalível, mas à vontade própria. E assim é manifesto que o herético descrendo
pertinazmente um artigo, não está disposto a seguir em tudo a doutrina da Igreja; se porém, não houver
pertinácia, já não é herético, mas apenas errado. Por onde, é claro que tal herético, em relação a um
artigo, não tem fé nos outros, mas uma certa opinião fundada na vontade própria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O herético não admite os artigos de fé, em relação aos
quais não erra, como os admite o fiel, isto é, aderindo absolutamente à verdade primeira, para possuir a
qual o homem precisa ser ajudado pelo hábito da fé, Mas, as admite por vontade e juízo próprios.

RESPOSTA À SEGUNDA. –As diversas conclusões de uma mesma ciência são provadas por meios
diversos, dos quais um pode ser conhecido sem o serem os outros. Por isso podemos conhecer certas
conclusões de uma ciência sem conhecer as outras. Mas a todos os seus artigos a fé adere por um só
meio, a saber, por causa da verdade primeira que nos é a proposta pela Escritura, conforme à doutrina
da Igreja, entendidas retamente. Logo, quem rejeita esse meio carece totalmente da fé.

RESPOSTA À TERCEIRA. –Preceitos diversos de lei podem referir-se a motivos diversos próprios e
próximos, e então, um pode ser observado sem os outros; ou, a um motivo primeiro, que é obedecer a
Deus perfeitamente. Ora, deste se afasta quem transgride um preceito, conforme a Escritura. Quem
faltar em um só ponto faz-se réu de ter violado todos.

## Art. 4 — Se pode um ter maior fé que outro.
O quarto discute-se assim. – Parece que não pode um ter maior fé que outro.
1 – Pois, um hábito depende quantitativamente do seu objeto. Ora, quem tem fé crê em todas as
verdades dela, porque, se não crê em alguma, perde totalmente a fé, como já se disse. Logo, parece que
não pode um ter maior fé que outro.

2. Demais. –O que está no lugar supremo não é susceptível de mais nem de menos. Ora, a fé, por
essência, está em supremo lugar, pois, para tê-la, deve o homem aderir à primeira verdade, acima de
tudo. Logo, não é a fé susceptível de mais e de menos.

3. Demais. – A fé desempenha, no conhecimento, quanto à ordem da graça, o mesmo papel que o
intelecto, faculdade dos princípios, no conhecimento natural, porque os artigos da fé são os princípios
primeiros do conhecimento, na ordem da graça, como do sobredito resulta. Ora, o intelecto, faculdade
dos princípios, a tem igualmente todos os homens. Logo, também a fé hão de tê-la igualmente todos os
fiéis.
Mas, em contrário. –Onde quer que haja pequeno e grande há de também haver maior e menor. Ora, na
fé há grande e pequeno; pois, diz o Senhor a Pedro: Homem de pouca fé, porque duvidastes? E à
mulher: Ó mulher, grande é a tua fé. Logo pode a fé ser maior em um que em outro.

SOLUÇÃO. –Como já dissemos, um hábito pode quantitativamente ser considerado à dupla luz: quanto
ao seu objeto e quanto à participação do sujeito. - Ora, o objeto da fé pode ser considerado sob dois
aspectos: quanto à sua razão formal e quanto ao materialmente proposto para ser crido. Quanto ao seu
objeto formal, ele é uno e simples, a saber, a verdade primeira, como já se disse. E assim, por este lado,
a fé não se diversifica nos seus crentes, mas é especificamente a mesma em todos, como já dissemos.
Ao contrário, o que é materialmente proposto para ser crido é múltiplo e susceptível, explicitamente, de
mais ou menos. E sendo assim, pode um homem crer, explicitamente, em mais verdades, que outro e,
portanto, ter maior fé, conforme a maior explicitação dela. - Considerada porém a fé na participação do
sujeito, o mesmo pode se dar, de dois modos, porque o ato de fé procede tanto do intelecto como da
vontade. como já dissemos. Portanto, pode-se dizer que um tem maior fé que outro quer por ter o
intelecto maior certeza e segurança, quer por ter a vontade mais pronta, devota ou confiante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Quem descrê pertinazmente alguma verdade de fé não
tem o hábito da mesma, que tem, ao contrário, quem, não crendo em todas explicitamente, está
contudo pronto a crê-las. E deste modo, quanto ao objeto, tem fé maior que outro quem crê
explicitamente em mais artigos, como dissemos.

RESPOSTA À SEGUNDA. – É da essência da fé antepor a verdade primeira a todas as outras. Contudo,
dos que a antepõem a tudo o mais, uns se lhe sujeitam mais certa e devotamente que outros. E por aí
tem fé maior que outros.

RESPOSTA À TERCEIRA. –O intelecto dos princípios resulta da natureza humana como tal, que existe
igualmente em todos. Ao passo que é a fé um dom da graça, que em todos não existe, igualmente. Logo,
o caso não é o mesmo. – E, contudo conforme a maior capacidade do intelecto, um conhece mais a
virtude dos princípios, que outro.