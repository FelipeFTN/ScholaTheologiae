# Questão 11: Da heresia.
Em seguida devemos tratar da heresia. E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a heresia é uma espécie de infidelidade.
O primeiro discute-se assim. – Parece que a heresia não é uma espécie de infidelidade.

1. – Pois, a infidelidade está no intelecto como já se disse. Ora, a heresia não reside no intelecto, mas
antes na potência apetitiva, porquanto, como comenta Jerônimo aquilo da Escritura - As obras da carne
estão patentes e está em Decret. - Heresia, em grego, vem de eleição, porque cada qual escolhe para si
a doutrina que julga melhor. Ora, a eleição é ato da potência apetitiva, como já se disse. Logo, a heresia
não é uma espécie de infidelidade.

2. Demais. – O vício principalmente se especifica pelo fim; donde o dizer o Filósofo: quem fornica para
roubar é mais ladrão que fornicador. Ora, o fim da heresia é a vantagem temporal, e sobretudo o
governo e a glória. Pois, como diz Agostinho herético é o que, por causa de alguma vantagem temporal,
e sobretudo da glória e do governo, emite ou regue opiniões falsas e novas. Logo, a heresia não é uma
espécie de infidelidade, mas antes, de soberba.

3. Demais. – A infidelidade, residindo no intelecto, não pode depender da carne. Ora, a heresia depende
das obras da carne, consoante ao dito do Apóstolo: As obras da carne estão patentes, como são a
fornicação, a impureza; e entre outras acrescenta depois: as contendas, as seitas, que são o mesmo que
heresias. Logo, não é a heresia uma espécie de infidelidade.
Mas, em contrário, a falsidade se opõe à verdade. Ora, herético é quem emite ou segue opiniões falsas e
novas. Logo, opõe-se à verdade, em que se funda a fé. Portanto, está compreendida na infidelidade.

SOLUÇÃO. – O nome de heresia, como se disse implica a eleição, que, conforme já dissemos, visa os
meios, pressuposto o fim. Ora, na crença, a vontade assente a uma verdade como a um bem próprio,
segundo do sobredito e colhe. Por onde, o que é principalmente verdadeiro tem a natureza de fim
último; e o que é secundário, a de meio. Ora, como quem crê assente na palavra de outrem é
considerado como principal e quase fim, em qualquer espécie de crença, aquele em cuja palavra
assentimos; e como quase secundário aquele que admitimos por querermos assentir na palavra de
outrem. Assim, pois, quem retamente possui a fé cristã, assente por vontade própria ao que
verdadeiramente pertence à doutrina de Cristo. Ora, da retidão da fé cristã podemos nos desviar de dois
modos. Primeiro, por não querermos assentir na doutrina de Cristo; o que implica a quase má vontade
relativamente ao próprio fim, e constitui a espécie de infidelidade dos pagãos e dos judeus. De outro
modo, podemos desviar da retidão da fé, quando, embora tendo a intenção de assentir na doutrina de
Cristo, erramos ao escolher aquilo pelo que aceitamos a Cristo elegendo, não o que Cristo
verdadeiramente ensinou, mas o que é sugerido pela mente própria. Por onde, a heresia é uma espécie
de infidelidade, própria dos que, embora confessando a fé em Cristo, viciam-lhe os dogmas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A eleição diz respeito à infidelidade, como a vontade à fé,
segundo já dissemos.

RESPOSTA À SEGUNDA. – Os vícios se especificam pelo fim próximo; mas no fim remoto haurem o
gênero e a causa. Assim, em quem fornica para roubar, a fornicação se especifica pelo seu fim próprio e
pelo objeto; mas, pelo fim último, mostra-se como a fornicação nasceu do furto e nele está contida,
como o efeito na causa ou a espécie no gênero conforme resulta claramente do que já dissemos sobre
os atos em geral. E o mesmo se dá no caso vertente: o fim próximo da heresia é aderir a uma falsa
opinião própria, o que a especifica; mas o fim remoto lhe manifesta a causa, isto é, que nasce da
soberba e da cobiça.

RESPOSTA À TERCEIRA. – Como heresia vem de eleger, assim seita vem de seguir, no dizer de Isidoro.
Por onde, heresia e seita se identificam. E ambas pertencem às obras da carne, não certo quanto ao ato
mesmo de infidelidade, relativamente ao objeto próximo, mas em razão da causa, que é ou o apetite do
fim indevido, quando nasce da soberba ou da cobiça; como dissemos ou então, alguma ilusão fantástica,
que é o princípio do erro, segundo também o Filósofo o diz. Ora, a fantasia, de certo modo, pertence à
carne, por ser o seu ato dependente de um órgão corpóreo.

## Art. 2 — Se a heresia versa propriamente sobre matéria de fé.
O segundo discute-se assim. – Parece que a heresia não versa propriamente sobre matéria de fé.

1. – Pois, como entre os Cristãos, também entre os judeus e os fariseus houve heresias e seitas,
conforme o diz Isidoro. Ora, as dissensões deles não versavam sobre matéria de fé. Logo, a heresia não
versa sobre matéria de fé como matéria própria.

2. Demais. – Matéria de fé são as realidades em que cremos. Ora, a heresia versa, não sobre realidades
somente, mas também sobre palavras e a interpretação da Sagrada Escritura. – Pois, como diz Jerônimo,
quem quer que entenda a Escritura diferentemente do sentido em que o exige o Espírito Santo, de
acordo com o qual foi escrita, embora não se aparte da Igreja, pode contudo chamar-se herético: e
noutro lugar: a heresia provém de palavras desordenadamente proferidas. Logo, a heresia não versa
propriamente sobre matéria de fé.

3. Demais. – Acontece às vezes dissentirem os santos doutores mesmo em matéria de fé. Assim,
Jerônimo e Agostinho, sobre a cessação do regime da lei. Contudo não há nisso nenhum vício de
heresia. Logo a heresia não versa propriamente sobre matéria de fé.
Mas, em contrário, diz Agostinho, contra os Maniqueus: Os que, na Igreja de Cristo, pendem para o que
é corrupto e mau, e, corrigidos, para virem a pensar sã e retamente, resistem contumazmente e não
querem emendar os seus dogmas pestilentos e mortíferos, mas persistem em defendêlos, são heréticos,
Ora, pestilentos e mortíferos dogmas são os que se opõem aos da fé, pela qual o justo vive, como diz a
Escritura. Logo, a matéria própria da heresia é o que pertence à fé.

SOLUÇÃO. – Tratamos agora da heresia enquanto implica corrupção da fé cristã. Ora, não implica essa
corrupção termos opinião falsa sobre o que não é de fé, como as proposições geométricas, ou ciências
semelhantes, que de nenhum modo podem a ela pertencer; mas só quando professarmos falsa opinião
em matéria de fé. Ora, uma doutrina pode ser de fé, de dois modos, como já dissemos: direta e
principalmente, como os artigos da mesma; ou indireta e secundariamente, como aqueles princípios
que, sendo negados, acarretam a alteração de algum desses artigos. Ora, de ambos esses modos pode
ha ver heresia, da mesma maneira que pode haver fé.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Assim como as heresias dos judeus e dos Fariseus
versavam sobre certas opiniões pertencentes ao judaísmo ou ao farisaísmo, assim também as heresias
dos cristãos versam sobre o que respeita à fé de Cristo.

RESPOSTA À SEGUNDA. – Diz-se que interpreta a Sagrada Escritura, de modo diferente do exigido pelo
Espírito Santo, quem lhe perverte o sentido de modo a contrariar o que foi revelado pelo mesmo. Por
isso, a Escritura diz, que os falsos profetas perseveraram em afirmar o que uma vez disseram, isto é, por
falsas interpretações da Escritura. Semelhantemente, pelas palavras que proferimos, confessamos a
nossa fé; pois, a confissão é um ato de fé, como já dissemos. Por onde, se nos manifestarmos
inconvenientemente sobre matéria de fé, daí pode resultar que ela se corrompa. Por isso, o Papa Leão,
em certa epístola diz: Porque os inimigos da fé de Cristo armam ciladas com todos os nossos atos,
palavras e silabas, não lhe devemos dar nenhuma ocasião, por leve que seja, para que, mentindo, digam
que estamos de acordo com os ensinamentos de Nestório.

RESPOSTA À TERCEIRA. – Como diz Agostinho e dispõem as decretais, não devem de nenhum modo ser
considerados heréticos os que, procurando a verdade com cautelosa solicitude, defendem, sem
nenhuma pertinaz animosidade, a opinião própria, embora falsa e pervertida, e estão prontos a se
emendarem quando encontrarem a verdade. Pois, não têm a intenção de contradizer a doutrina da
Igreja. Por isso, certos doutores dissentiram entre si sobre opiniões que nada importam à fé, sejam
entendidas como forem, ou mesmo sobre certas questões pertinentes à fé, mas ainda não definidas
pela Igreja. Mas, depois de definidas pela autoridade da Igreja universal, quem as impugnasse
pertinazmente seria considerado herético. E essa autoridade reside principalmente no Sumo Pontífice.
Pois, está determinado: Todas as vezes que se ventilarem questões de fé, julgo que todos os nossos
irmãos e colegas no episcopado devem ser deferidos a Pedro, isto é, à autoridade do seu nome. E contra
essa autoridade, nem Jerônimo, nem Agostinho, nem nenhum dos santos doutores defende a opinião
própria. Por isso, diz Jerônimo: Esta é a fé, beatíssimo Papa, que aprendemos na Igreja católica. Na qual,
se, menos doula ou pouco cautamente, introduzimos alguma causa, desejamos seja emendada por ti,
que tens a fé e a sede de Pedro. Se, porém, esta nossa confissão for comprovada pelo teu juízo, quem
quer que pretenda me culpar, mostrar-se-á indoulo, ou malévolo, ou ainda, não católico, mas herético.

## Art. 3 — Se se devem tolerar os heréticos.
O terceiro discute-se assim. – Parece que se devem tolerar os heréticos.

1. – Pois, diz o Apóstolo. É necessário que o servo do Senhor seja manso, corrija com modéstia aos que
resistem à verdade, na esperança de que poderá Deus algum dia dar-lhe o dom da penitência para Lhe
fazer conhecer a verdade, e que raiam dos laços do diabo. Ora, se os heréticos não forem tolerados, mas
condenados à morte, tirar-se-lhes-á a faculdade de fazerem penitência. Logo, esse proceder encontra o
preceito do Apóstolo.

2. Demais. – O necessário à Igreja deve ser tolerado. Ora, à Igreja são necessárias as heresias, no dizer
do Apóstolo: É necessário que haja heresias, para que também os que são provados fiquem manifestos
entre heréticos devem ser tolerados.

3. Demais. – O Senhor mandou que os seus servos deixassem crescer a cizânia até a messe, que é o fim
do mundo, como nesse mesmo lugar se diz. Ora, a cizânia significa os heréticos, conforme a
interpretação dos Santos Padres. Logo, devem-se tolerar os heréticos.
Mas, em contrário, o Apóstolo: Foge do homem hereje depois da primeira correção, sabendo que o que
é tal está pervertido.

SOLUÇÃO. – Os heréticos devem ser considerados à dupla luz: em si mesmos e em relação à Igreja.
Em si mesmos, estão em estado de pecado, pelo que merecem ser separados por excomunhão, não só
da Igreja, mas também, do mundo, pela morte. Pois, é muito mais grave perverter a fé, vida da alma, do
que falsificar o dinheiro, ajuda da vida temporal. Ora, se os príncipes seculares logo condenam
justamente à morte os falsificadores de moedas ou outros malfeitores, com maior razão os heréticos,
desde que são convencidos de heresia, podem logo ser, não só excomungados, mas também justamente
condenados à morte.
A Igreja porém usa de misericórdia, para obter a conversão dos errados. Por isso, não condena
imediatamente, senão só depois da primeira e segunda correção; como ensina o Apóstolo. Se porém
depois disso, permanecer o herético pertinaz, a Igreja, não mais lhe esperando a conversão, provê à
salvação dos outros, separando-o do seu grêmio por sentença de excomunhão. E ulteriormente,
abandona-o ao juízo secular para exterminá-lo do mundo pela morte. Pois, diz Jerônimo: Devem ser
cortadas as carnes pútridas e a ovelha sarnenta deve ser separada do redil, afim de que toda a cara, a
massa, o corpo e o rebanho não ardam, corrompamse, apodreçam e morram: Ario em Alexandria foi
uma centelha; mas, por não ter sido imediatamente reprimido, a sua chama devastou iodo o orbe.

DONDE À RESPOSTA À PRIMEIRA OBJEÇÃO. – Em virtude da referida modéstia é o herético corrigido a
primeira e a segunda vez. Mas, se não quiser retratar-se, já será considerado pervertido, como é claro
pelo lugar citado do Apóstolo.

RESPOSTA À SEGUNDA. – A utilidade proveniente das heresias está fora da intenção dos heréticos; pois
ela põe à prova a constância dos fiéis, conforme diz o Apóstolo; e serve para nos livrar da preguiça,
fazendo-nos considerar mais solicitamente as divinas Escrituras, como diz Agostinho. Mas, a intenção
dos heréticos é perverter a fé, mal máximo. Por onde, devemos levar em conta mais a intenção deles
em si mesma, para serem excluídos, do que o que lhes está fora dela, para serem tolerados.

RESPOSTA À TERCEIRA. – Como está numa decretal uma coisa é a excomunhão e outra, a erradicação.
Pois, alguém é excomungado, como diz o Apóstolo, afim de que a sua alma seja salva no dia do Senhor.
Além disso, serem os heréticos totalmente erradicados pela morte, não fere o mandamento do Senhor;
que se deve aplicar, no caso, de não poder extirpar-se a cizânia sem a extirpação do trigo, como já
dissemos, ao tratar dos infiéis em geral.

## Art. 4 — Se os convertidos da heresia devem, absolutamente, ser recebidos pela Igreja.
O quarto discute-se assim. – Parece que os convertidos da heresia devem, absolutamente, ser
recebidos pela Igreja.

1. – Pois, diz a Escritura, falando da pessoa do Senhor: Tu te tens prostituído a muitos amadores; ainda
assim, torna para mim, diz o Senhor: Ora o juízo da Igreja é o juízo de Deus, conforme outro lugar da
Escritura: Do mesmo modo ouvireis o pequeno que o grande, nem tereis acepção de pessoa alguma,
porque este é o juízo de Deus. Logo, os que fornicarem por infidelidade, que é a fornicação espiritual,
nem por isso devem deixar de ser recebidos pela Igreja.

2. Demais. – O Senhor manda a Pedro perdoar ao irmão que peca não só sete vezes, mas até setenta
vezes sete vezes. O que quer dizer, segundo a interpretação de Jerônimo (a este lugar), que devemos
perdoar tantas quantas vezes alguém pecar. Logo, tantas vezes quantas alguém pecar, caindo em
heresia, deve ser recebido pela Igreja.

3. Demais. – A heresia é uma espécie de infidelidade. Ora, os outros infiéis, querendo converter-se,
serão recebidos pela Igreja: Logo, também os heréticos devem sê-lo,
Mas, em contrário, diz uma Decretal: Os que, depois da abjuração do erro, vierem a reincidir na heresia
abjurada, devem ser entregues ao juízo secular. Logo, não devem ser recebidos pela Igreja.

SOLUÇÃO. – Segundo a instituição do Senhor, a Igreja estende a sua caridade a todos, não só aos
amigos, mas também, aos inimigos e perseguidores, conforme aquilo da Escritura: Amai a vossos
inimigos, fazei bem aos que vos tem ódio. Ora, a caridade exige queiramos e façamos bem ao próximo; e
este bem pode ser de duas espécies. – Um, espiritual, que é a salvação da alma, fim principal da
caridade; pois, pela caridade, devemos querer esse bem aos outros. Por onde, neste ponto, os heréticos,
convertendo-se, tantas vezes quantas tiverem caído, são recebidos pela Igreja afim de fazerem
penitência, que os porá de novo no caminho da salvação. – Mas, a caridade também visa,
secundariamente, outro bem, que é o temporal, como, a vida corpórea, a posse de bens materiais, a boa
fama, a dignidade eclesiástica ou secular. Pois, a caridade não nos obriga a querer esses bens aos
outros, senão para o fim da salvação deles. Por onde, se alguém, possuindo qualquer desses bens, vier a
impedir a salvação eterna de muitos, a caridade não exige que lhe queiramos, mas ao contrário, que
queiramos seja privado deles, porque a salvação eterna deve preferir aos bens temporais; ou porque o
bem de muitos deve preferir ao de um só. Se portanto os heréticos, sempre que voltassem fossem
recebidos, de modo a lhes ser conservada a vida e os demais bens temporais, daí podia resultar perigo
para a salvação dos outros. Quer pelos contaminarem, se viessem a recair; quer também porque, se
nenhuma pena sofressem tornariam a cair mais seguramente na heresia. Porquanto, como diz a
Escritura o não se proferir logo sentença contra os maus é causa de cometerem os filhos dos homens
crimes sem temor algum. Por isso a Igreja, primeiro, não só recebe, para fazerem penitência, os que
voltam da heresia, mas ainda lhes conserva a vida. E às vezes restitui-os por dispensa, às dignidades
eclesiásticas, que antes tinham, se os considerar como deveras convertidos. E lemos que isto foi
frequentemente feito, para conservar a paz. Mas, considera prova de inconstância na fé se, depois de
recebidos, vierem de novo a cair. Por isso, ulteriormente, os que voltam são recebidos, por certo, para
fazerem penitência; não porém para serem libertados da sentença de morte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os que voltam são sempre recebidos, no juízo de Deus,
por ser Deus o verdadeiro perscrutador dos corações e conhecer os que verdadeiramente voltam. Mas
isso a Igreja não pode imitar. Daí o presumir que não voltam verdadeiramente os que, depois de
recebidos, de novo vieram a cair. Por onde, sem lhes trancar a via da salvação, não os livra do perigo da
morte.

RESPOSTA À SEGUNDA. – O Senhor fala com Pedro sobre o pecado cometido contra este, que devia ser
sempre perdoado, de modo a se compadecer do irmão arrependido. Isso porém, não se aplica ao
pecado cometido contra o próximo ou contra Deus, que não está em nosso arbítrio perdoar, como diz
Jerônimo. Pois, neste caso, o modo de perdoar foi estatuído pela lei, conforme o exige a honra de Deus
e a utilidade do próximo.

RESPOSTA À TERCEIRA. – Os outros infiéis, que nunca receberam a fé, quando convertidos a ela, não
mostram nenhum sinal de inconstância, relativamente à mesma, como o fazem os heréticos relapsos.
Logo, o caso não é o mesmo.