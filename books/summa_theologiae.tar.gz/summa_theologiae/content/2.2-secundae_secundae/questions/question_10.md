# Questão 10: Da infidelidade em comum.
Em seguida devemos tratar dos vícios opostos. E primeiro, da infidelidade, oposta à fé. Segundo, da
blasfêmia, oposta à confissão. Terceiro, da ignorância e do embotamento, opostos à ciência e ao
intelecto.
Na primeira questão, devemos tratar da infidelidade em comum; na segunda, da heresia; na terceira, da
apostasia da fé.
Na primeira, discutem-se doze artigos:

## Art. 1 — Se a infidelidade é pecado.
O primeiro discute-se assim. – Parece que a infidelidade não é pecado.

1. – Pois, todo pecado é contra a natureza, como claramente o diz Damasceno. Ora, a infidelidade não é
contra a natureza, segundo Agostinho: é próprio à natureza de todos os homens ter tanto a fé como a
caridade; mas ter a fé, bem como a caridade, é próprio da graça dos fiéis. Logo, não ter fé, o que é ser
infiel, não é contra a natureza; e portanto não é pecado.

2. Demais. – Ninguém peca pelo que não pode evitar, por ser todo pecado voluntário. Ora, não está no
poder do homem evitar a infidelidade, pois, só tendo fé pode evitá-la, conforme ao dito do Apóstolo:
Como crerão aquele que não ouviram? E como ouvirão sem pregador? Logo, a infidelidade não é
pecado.

3. Demais. –Como já se disse, sete são os vícios capitais a que todos os pecados se reduzem. Ora, a
infidelidade não está contida em nenhum deles. Logo, não é pecado.
Mas, em contrário. – À virtude é contrário o vício. Ora, é a fé uma virtude, a que é contrária a
infidelidade, Logo, a infidelidade é pecado.

SOLUÇÃO. – A infidelidade pode ser considerada em duplo sentido: como pura negação, chamando-se
nesse caso infiel uma pessoa, só pelo fato de não ter fé; ou como contrária à fé, quando, por exemplo, a
alguém repugna ouvir-lhe a doutrina, ou ainda, a despreza, conforme aquilo da Escritura: Quem deu
crédito ao que nos ouviu? E é isto que constitui própria e essencialmente a infidelidade: que, neste
sentido, é pecado.
Considerada, porém enquanto negação pura, como no caso dos que nunca ouviram falar nas verdades
da fé, não implica essencialmente pecado, mas antes, pena, porque tal ignorância das coisas divinas é
resultante do pecado do primeiro pai. Assim, os infiéis, dessa maneira, condenam-se, certo, por causa
de outros pecados, que não podem, sem a fé, ser perdoados; não porém pelo pecado de infidelidade.
Por isso, o Senhor diz: Se eu não viera e não lhes tivera falado, não teriam eles pecado; o que Agostinho
explica como referente aquele pecado pelo qual não creram em Crido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Não é próprio à natureza humana ter fé, mas, sim, que a
mente do homem não repugne à moção interna e à pregação externa da verdade. Por onde, neste
último caso, a infidelidade é contra a natureza.

RESPOSTA À SEGUNDA. – A objeção colhe quando a infidelidade é tomada no sentido de simples
negação.

RESPOSTA À TERCEIRA. – A infidelidade, como pecado, nasce da soberba, que leva o homem a não
querer submeter o seu intelecto às regras da fé e à sã inteligência dos Padres. Por isso, Gregório diz,
que, da vanglória nascem as presunções da novidade. – Embora se possa dizer que, assim como as
virtudes teologais não se reduzem às cardeais, mas lhes são anteriores; assim também os vícios opostos
às virtudes teologais não se reduzem aos vícios capitais.

## Art. 2 — Se a infidelidade está no intelecto como no sujeito.
O segundo discute-se assim. – Parece que a infidelidade não está no intelecto como no sujeito.

1. – Pois, como diz Agostinho, todo pecado depende da vontade. Ora, a infidelidade é um pecado, como
já, se estabeleceu. Logo, a infidelidade está na vontade, como no sujeito, e não no intelecto.

2. Demais. – A infidelidade é, essencialmente, pecado, por desprezar a pregação da fé. Ora, o desprezo
depende da vontade. Logo, na vontade está a infidelidade.

3. Demais. – Àquilo da Escritura - Satanás se transforma em anjo de luz - diz a Glosa: Não é erro perigoso
e nocivo, crer que um anjo mau, fingindo-se de bom, seja bom, se fizer ou disser o que é próprio dos
anjos bons, E a razão esta na retidão da vontade de quem aceita o que faz esse anjo, pensando aceitar o
que faz um anjo bom. Logo, todo o pecado de infidelidade depende da vontade pervertida. Portanto,
não está no intelecto como no sujeito.
Mas, em contrário. – Os contrários tem o mesmo sujeito. Ora, a fé, a que é contrária a infidelidade, tem
no intelecto o seu sujeito. Logo, também é o intelecto o sujeito da infidelidade.

SOLUÇÃO. – Conforme já dissemos, considera-se o pecado como residindo na potência que é o princípio
do ato pecaminoso. Ora, este ato pode ter duplo princípio. Um, primeiro e universal, de que dependem
todos os atos pecaminosos; e tal princípio é a vontade, por ser todo pecado voluntário. Outro é o
princípio próprio e próximo do ato pecaminoso, donde procede ilicitamente esse ato: assim, sendo. 0
concupiscível o princípio da gula e da luxúria, dizemos que esta e aquela nele residem. Ora, dissentir,
que é o ato próprio da infidelidade, é, como o assentir, ato do intelecto, movido porém pela vontade.
Por onde, a infidelidade, como a fé, tem, certo, no intelecto o seu sujeito próximo, mas na vontade o
seu primeiro motor. E deste modo se diz que todo pecado procede da vontade.
Donde SE DEDUZ CLARA A RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. – O desprezo da vontade causa o dissentimento do intelecto, o que torna
completa a infidelidade em essência. Por onde, a causa da infidelidade está na vontade, mas a
infidelidade mesma está no intelecto.

RESPOSTA À TERCEIRA. – Quem crê ser um anjo mau, bom, não dissente do que é de fé; porque embora
o sentido corpóreo falhe, a mente não se afasta da doutrina verdadeira e reta, como, no mesmo lugar,
diz a Glosa. Mas quem aderisse a Satanás, quando começa a provocar a obras que lhe são próprias, isto
é, a obras más e falsas, não o faria pecado, como no mesmo passo se diz.

## Art. 3 — Se a infidelidade é o máximo dos pecados.
O terceiro discute-se assim. – Parece que a infidelidade não é o máximo dos pecados.

1. – Pois, diz Agostinho: Não ouso julgar precipitadamente se devemos preferir um católico de péssimos
costumes a um herético, em cuja vida, além de ser herético, nada encontremos de repreensível. Ora, o
herético é infiel. Logo, não é exato dizer, que a infidelidade é, absolutamente falando, o máximo dos
pecados.

2. Demais. – O que diminui ou excusa o pecado não pode ser o máximo dos pecados. Ora, a infidelidade
excusa ou diminui o pecado, conforme aquilo do Apóstolo: A mim, que havia sido antes blasfemo e
perseguidor é injuriador; mas alcancei a misericórdia de Deus, porque o fiz por ignorância na
incredulidade. Logo, a infidelidade não é o máximo dos pecados.

3. Demais. – Ao maior pecado é devida maior pena, conforme àquilo da Escritura: O número dos golpes
reqular-se-á pela qualidade do pecado. Ora, maior pena merecem os fiéis, que pecam, que os infiéis,
segundo o Apóstolo: Quanto maiores tormentos credes vós que merece o que pisar aos pés ao Filho de
Deus, e tiver em conta o sangue do testamento em que foi santificado? Logo, a infidelidade não é o
maior dos pecados.
Mas, em contrário, diz Agostinho, expondo aquilo da Escritura – Se eu não viera e não lhes tivera falado,
não teriam eles pecado – Quer dar a entender, sob um nome geral, um grande pecado. Pois, este
pecado, isto é, o de infidelidade, é o de que dependem todos. Logo, a infidelidade é o máximo dos
pecados.

SOLUÇÃO. – Todo pecado consiste, formalmente, na aversão de Deus, como já dissemos. Por onde, o
pecado é tanto mais grave quanto mais leva o homem a separar-se de Deus. Ora, pela infidelidade o
homem se afasta de Deus em sumo grau, porque, de um lado, não tem o verdadeiro conhecimento de
Deus; e por outro, o falso conhecimento que dele tem leva-o, não a aproximar-se, mas, ao contrário, a
afastar-se do mesmo. Nem é possível que, de algum modo, conheça a Deus quem d'Ele tem ideia falsa,
pois, o que pensa ser Deus, não o é. Por onde é manifesto, que o pecado de infidelidade é maior que
todos os concernentes à perversão dos costumes. Mas é diferente o que se dá com os pecados opostos
às outras virtudes teologais, como se dirá mais abaixo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Nada impede seja um pecado, de maior gravidade
genérica, menos grave em virtude de certas circunstâncias. Por isso, Agostinho não quis formar opinião
precipitada, do mau católico e do herético, que no mais, não peca. Porque o pecado do herético,
embora genericamente mais grave, pode contudo, ser aligeirado por alguma circunstância; e ao inverso,
o pecado do católico pode agravar-se por alguma circunstância.

RESPOSTA À SEGUNDA. – A infidelidade implica uma ignorância adjunta e a resistência ao que é de fé.
Ora, por este lado, inclui o que a torna essencialmente pecado gravíssimo. Quanto à ignorância, porém,
merece alguma excusa, e sobretudo quando não se peca por malícia, como foi o caso do Apóstolo.

RESPOSTA À TERCEIRA. – O infiel é punido mais gravemente pelo pecado de infidelidade, do que outro
pecador, por qualquer outro pecado, considerado este genericamente. Mas, cometendo outro pecado,
por exemplo o de adultério, o fiel peca, em igualdade de circunstâncias, mais gravemente que o infiel.
Isso, quer, por causa do conhecimento da verdade da fé; quer também, pelos sacramentos da mesma,
que recebeu, e a que ofende, pecando.

## Art. 4 — Se qualquer ação do infiel é pecado.
O quarto discute-se assim. – Parece que toda ação do infiel é pecado.

1. – Pois, aquilo do Apóstolo - Tudo o que não é segundo a fé é pecado - diz a Glosa: Toda a vida dos
infiéis é pecaminosa. Ora, à vida dos infiéis pertence tudo o que fazem. Logo, toda ação do infiel é
pecado.

2. Demais. – A fé dirige a intenção. Ora, nenhum bem pode provir senão da intenção reta. Logo, os
infiéis não podem praticar nenhuma boa ação.

3. Demais. – Corrupto o anterior, corrompido fica o posterior. Ora, o ato de fé precede os atos de todas
as virtudes. Logo, não podendo os infiéis fazer ato de fé, nenhuma boa obra podem fazer e pecam em
todas as que praticam.
Mas, em contrário, diz a Escritura, que Deus aceitou as esmolas que fez Cornélio, ainda infiel. Logo, nem
toda ação do infiel é pecado, mas alguma pode dar boa.

SOLUÇÃO. – Como já se disse, o pecado mortal priva da graça santificante, mas não corrompe
totalmente o bem da natureza. Por isso, sendo a infidelidade pecado mortal, os infiéis estão privados da
graça; mas, neles permanece algum bem da natureza. Por onde é manifesto, que não podem praticar as
boas obras dependentes da graça e as meritórias. Mas podem, de algum modo, praticar as boas obras
para que basta o bem da natureza. Por onde, não pecam necessariamente em tudo o que fazem. Mas
sempre que fazem alguma obra procedente da infidelidade, então pecam. Pois assim como o que tem a
fé pode pecar, venial ou mesmo mortalmente, praticando um ato que não se coaduna com o fim da fé;
assim também pode o infiel praticar um ato bom qualquer, que não se coaduna com o fim da
infidelidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O lugar citado é possível entendê-la como significando,
que a vida dos infiéis não pode ser sem pecado, desde que sem fé os pecados não podem ser
eliminados; ou que tudo o que fazem por infidelidade é pecado. Por isso, no mesmo lugar se acrescenta:
Porque todo o que vive ou age na infidelidade peca veementemente.

RESPOSTA À SEGUNDA. – A fé rege a intenção relativamente ao fim último sobrenatural. Mas, também
o lume da razão natural pode dirigir a intenção relativamente a qualquer bem que lhe seja conatural.

RESPOSTA À TERCEIRA. – A infidelidade não corrompe totalmente a razão natural dos infiéis, de modo a
privá-los de qualquer conhecimento da verdade, pela qual podem praticar certas obras genericamente
boas. Quanto a Cornélio, importa saber que não era infiel; do contrário, Deus, a quem ninguém pode
agradecer sem a fé, não lhe aceitaria o ato. Pois tinha fé implícita, ainda não manifestada pela verdade
do Evangelho. Por isso foi-lhe mandado Pedro, afim de instrui-lo mais plenamente na fé.

## Art. 5 — Se há várias espécies de infidelidade.
O quinto discute-se assim. – Parece que não há várias espécies de infidelidade.
1 – Pois, sendo a fé e a infidelidade contrárias, hão de ter o mesmo objeto. Ora, é o objeto formal da fé
a verdade primeira, donde ela tira a sua unidade, embora recaia sobre muitas coisas materialmente.
Logo, também o objeto da infidelidade é a verdade primeira.
Porém, aquilo em que o infiel não crê se inclui materialmente na infidelidade. Ora, a diferença específica
se funda não em princípios materiais, mas, formais. Logo, não há diversas espécies de infidelidade,
conforme aos diversos pontos em que os infiéis erram.

2. Demais. – De infinitos modos podemos nos desviar das verdades da fé. Se pois, conforme aos diversos
erros, são diversas as espécies de infidelidade, resulta que estas espécies são infinitas. E portanto, não
são susceptíveis de consideração.

3. Demais. – Uma mesma coisa não pode pertencer a espécies diversas. Ora, alguém pode ser infiel por
errar em matérias diversas. Logo, a diversidade dos erros não acarreta as diversas espécies de
infidelidade. Portanto, não há várias espécies de infidelidade.
Mas, em contrário, a cada virtude se opõem várias espécies de vícios; pois, o bem só se realiza de um
modo, e o mal, ao contrário, de muitos, como se vê claramente em Dionísio e no Filósofo. Ora, é a fé
uma virtude. Logo, a ela se lhe opõem muitas espécies de infidelidade.

SOLUÇÃO. – Toda virtude consiste na obediência a uma regra do conhecimento ou da ação humana,
como se disse. Ora, em cada matéria, há um só modo de obedecer à regra; ao contrário, de muitos
modos é possível desviar dela, e portanto, a uma virtude se opõem muitos vícios. Ora, a diversidade dos
vícios, que se opõem a cada virtude, pode ser considerada à dupla luz. – Primeiro, quanto às suas
relações diversas com a virtude. E então, há certas e determinadas espécies de vícios que se opõem a
uma mesma virtude; assim, à virtude moral se opõe um vício, que peca contra ela por excesso, e outro,
por defeito. – De outro modo, podemos considerar a diversidade dos vícios opostos a uma virtude,
relativamente à corrupção das diversas circunstâncias exigidas pela virtude. E então, a uma mesma
virtude, por exemplo, à temperança ou à fortaleza, opõem-se vícios infinitos, porque de infinitos modos
podem corromper-se as diversas circunstâncias da virtude, e portanto dar-se o afastamento, da retidão
da mesma. Por isso, os Pitagóricos ensinavam que o mal é infinito.
Por onde devemos dizer que, considerada a infidelidade relativamente ao fim, são diversas as espécies e
determinado o número delas. Pois, a resistência à fé, que constitui o pecado da infidelidade, pode se dar
de dois modos. Pois, ou se resiste à fé ainda não recebida, e essa é a infidelidade dos pagãos ou gentios.
Ou se resiste à fé cristã já recebida, quer em figura, e tal é a infidelidade dos judeus; quer, na
manifestação mesma da verdade, e tal é a dos heréticos. Por onde e em geral, podemos considerar
como três as referidas espécies de infidelidade. - Se porém distinguirmos as espécies de infidelidade
relativamente aos erros diversos em matéria de fé, então essas espécies não são determinadas, pois os
erros podem multiplicar-se ao infinito, como se vê claramente em Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A razão formal de um pecado pode ser considerada à
dupla luz. Ou dependentemente da intenção do pecador, e nesse caso aquilo que ele busca é o objeto
formal do pecado e lhe diversifica as espécies. Ou relativamente à noção do mal, e então o bem de que
ele se afasta é o objeto formal do pecado. Mas isto não lhe dá a espécie, mas antes, a priva dela. Por
onde devemos dizer, que o objeto da infidelidade é a verdade primeira, como aquilo de que ela se
afasta; mas o seu objeto formal, como aquilo para o que se converte; é a ciência falsa que ela segue, e
por este lado se lhe diversificam as espécies. Portanto, assim como a caridade é uma só, a que se une ao
sumo bem; mas diversos os vícios a ela opostos não só por buscarem bens temporais diversos,
afastando-se do sumo bem, mas, além disso, por causa das relações diversas desordenadas, para com
Deus; assim também é a fé uma virtude só, por unir-se à verdade primeira única, ao passo que as
espécies de infidelidade são muitas, por seguirem os infiéis opiniões falsas diversas.

RESPOSTA À SEGUNDA. – A objeção colhe quanto à distinção das espécies de infidelidade,
relativamente aos pontos diversos em que se erra.

RESPOSTA À TERCEIRA. – Assim como é a fé uma só, porque crê em muitas verdades ordenadas a uma
só, assim a infidelidade pode ser una, mesmo se errar em muitos pontos, enquanto todos estes se
ordenam a um só. Nada porém impede que alguém erre, caindo em diversas espécies de infidelidade,
assim como também pode um homem ser dominado por diversos vícios e sofrer diversas doenças do
corpo.

## Art. 6 — Se a infidelidade dos gentios ou dos pagãos é mais grave que as outras.
O sexto discute-se assim. – Parece que a infidelidade dos gentios ou dos pagãos é mais grave que as
outras.

1. – Pois, assim como a doença corporal é tanto mais grave quanto mais contraria à saúde de um
membro de maior importância, assim também o pecado é considerado tanto mais grave quanto mais
contraria ao que é de maior importância para a virtude. Ora, o que há de principal na fé é crer na
unidade divina, o que não fazem os infiéis. crendo em uma multidão de deuses. Logo, a infidelidade
deles é gravíssima.

2. Demais. – A heresia de um herético é tanto mais detestável quanto mais contradiz a mais numerosas
e importantes verdades da fé. Assim. a heresia de Ario, que privou da divindade, a pessoa do Filho de
Deus, é mais detestável que a de Nestório, que privou, dessa pessoa, a humanidade de Cristo, Ora, os
gentios afastam-se de verdades da fé mais numerosas e principais, que os judeus e os heréticos, porque
não aceitam nada, absolutamente, da fé. Logo, a infidelidades deles é a mais grave de todas.

3. Demais. – Todo bem diminui o mal. Ora, há algum bem nos judeus, que confessam ter vindo de Deus
o Antigo Testamento; e por outro lado, há bem nos heréticos, que veneram o Novo Testamento. Logo,
pecam menos que os gentios, que detestam ambos os Testamentos.
Mas, em contrário, diz a Escritura: Melhor lhes era não ter conhecido o caminho da justiça, do que,
depois de o ter conhecido, tornar para trás. Ora, os gentios não conheceram o caminho da justiça; os
heréticos e os judeus, por seu lado, de certo modo conhecendo-o, abandonaram-no. Logo, o pecado
deles é mais grave.

SOLUÇÃO. – Na infidelidade, como já dissemos, duas coisas podem considerar-se. Uma é a sua relação
com a fé. E por este lado, peca mais gravemente contra a fé quem se opõe à que já recebeu, do que
quem se opõe à que ainda não recebeu; assim como peca mais gravemente quem não cumpre o que
prometeu, do que quem não compre o que nunca prometeu.
E sendo assim, a infidelidade dos heréticos, que confessam a fé no Evangelho e se lhe opõem,
corrompendo-a, é pecado mais grave que o dos judeus, que nunca receberam essa fé. Mas, como
receberam a figura dela, na Lei Antiga, que corromperam, interpretando-a mal, por isso também a
infidelidade deles é mais grave pecado que a dos gentios, que, de nenhum modo, receberam a fé no
Evangelho. - Além disso, considera-se na infidelidade a corrupção do conteúdo da fé. E por este lado,
como os gentios erram em relação a maior número de verdades, que os judeus, e os judeus, que os
heréticos, mais grave é a infidelidade dos gentios que a dos judeus, e a destes que a dos heréticos; salvo
a de alguns heréticos, como os Maniquuns, que, em relação às verdades da fé, erram ainda mais que os
gentios. - Destas duas espécies de gravidades, porém, a primeira prepondera sobre a segunda, quanto
ao que é essencialmente culpa. Pois, a culpa essencial a infidelidade consiste, sobretudo, como já se
disse, em se opor à fé, mais do que em não lhe aceitar as verdades, porque isto, conforme já dissemos;
(a.1), constitui, mais essencialmente, a pena. Por onde, absolutamente falando, a infidelidade dos
heréticos é a péssima.
E daqui se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 7 — Se se deve disputar publicamente com os infiéis.
O sétimo discute-se assim. – Parece que não se deve disputar publicamente com os infiéis.

1. – Pois, diz o Apóstolo: Foge de contendas de palavras, que para nada aproveitam, senão para
perverter os que as ouvem. Ora, não é possível disputar publicamente com os infiéis sem contenção de
palavras. Logo, não se deve disputar publicamente com eles.

2. Demais. – A lei de Marciano Augusto, confirmada pelos cânone declara: Faz injúria ao juízo
religiosíssimo do Sínodo quem alguma vez se puser a revolver o que já foi retamente julgado e disposto,
e a disputar publicamente. Ora, tudo o que pertence à fé já foi determinado pelos sagrados concílios.
Logo, gravemente peca, fazendo injúria aos sínodos, quem se puser publicamente a discutir o que é de
fé.

3. Demais. – A disputa há de apoiar-se em argumentos. Ora, o argumento é um meio de convencer em
matéria duvidosa. Mas, as verdades da fé, sendo certíssimas, não dão lugar à dúvida. Logo, sobre elas
não se deve disputar publicamente.
Mas, em contrário, a Escritura diz: Saulo muito mais se esforçava, e confundia aos judeus: e falava com
os gentios e disputava com os gregos.

SOLUÇÃO. – Duas coisas se devem distinguir nas discussões sobre a fé: uma relativa a quem discute;
outra, aos ouvintes. – Relativamente aquele, é preciso que se lhe leve em conta a intenção. Se discutir,
duvidando da fé e não lhe tendo como certas as verdades, que procura examinar por meio de
argumentos, por certo peca, como dúbio na fé e infiel. Digno de louvor será, porém, se discutir sobre a
fé para refutar erros, ou mesmo como exercício.
Relativamente aos ouvintes, devemos distinguir se os assistentes à discussão são instruídos e firmes na
fé, ou se simples, e a tem vacilante. Pois certamente, nenhum perigo há em se discutir na presença de
sábios e firmes na fé. Quanto aos simples, porém, é mister distinguir. Porque, ou são provocados e
repelidos pelos infiéis, como os judeus, os heréticos ou os pagãos, que se esforçam por lhes corromper a
fé; ou de nenhum modo são provocados, nessas questões, como nas terras onde não existem infiéis. -
No primeiro caso, é necessário discutir sobre a fé publicamente, desde que se encontre quem seja
idôneo e capaz para tal e possa refutar os erros. Pois assim, os simples na fé se fortalecerão e os infiéis
ficarão privados do poder de enganar; e ao contrário, o fato mesmo de se calarem os que deviam se
opor aos corruptores da verdade da fé seria confirmação do erro. Por isso, Gregório diz: Assim como
falar incautamente incrementa o erro, assim o silêncio indiscreto abandona ao erro os que deviam ser
ensinados. - No segundo caso porém, é perigoso disputar sobre a fé na presença dos simples, cuja
crença é mais firme quando nada ouviram diverso daquilo que creem. Por isso não convém ouçam as
palavras dos infiéis, que disputam contra a fé.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O Apóstolo não proíbe totalmente a discussão, senão só a
desordenada, que se faz, antes, pela contenção das palavras do que pela firmeza das expressões.

RESPOSTA À SEGUNDA. – A lei citada proíbe à discussão pública sobre a fé, procedente de dúvidas
relativamente a esta; não porém a que visa conservá-la.

RESPOSTA À TERCEIRA. – Não se deve discutir sobre os artigos da fé, como duvidando deles; mas para
manifestar-lhes a verdade e refutar os erros. Por isso é necessário, para a confirmação da fé, disputar às
vezes com os infiéis; ora, defendendo a fé, conforme aquilo da Escritura: Sempre aparelhados para
responder a todo o que vos pedir razão daquela esperança que há em vós. Ora, para convencer os
errados, segundo ainda a Escritura: Para que passa exortar conforme à sã doutrina, e convencer aos que
contradizem.

## Art. 8 — Se os infiéis devem, de algum modo, ser compelidos a aceitar a fé.
O oitavo discute-se assim. – Parece que os infiéis de nenhum modo devem ser compelidos a aceitar a
fé.

1. – Pois, diz o Evangelho, que os servos do pai de famílias, em cujo campo foi semeada a cisânia,
perguntaram-lhe: Querer tu que nós vamos e a arranquemos? Ao que ele respondeu: Não, para que
talvez não suceda que, arrancando a cisânia, arranqueis juntamente com ela também o trigo. E comenta
Crisóstomo: Isto diz o Senhor para proibir que se perpetrem mortes. Nem se devem matar os heréticos,
pois se o fizerdes, fareis, necessária e simultaneamente, desaparecer muitos santos. Logo, pela mesma
razão, nenhum infiel deve ser obrigado a aceitar a fé.

2. Demais. – Uma Decretal diz: O santo Sinodo ordena, em seguida, que não se obrigue nenhum judeu a
crer por força. Logo, pela mesma razão, nem os demais infiéis devem ser obrigados a aceitar a fé.

3. Demais. – Agostinho diz: tudo o homem pode, não querendo; menos crer, que só por vontade o quer.
Ora, a vontade não pode ser obrigada. Logo, os infiéis não devem ser obrigados a aceitar a fé.

4. Demais. – A Escritura diz; da pessoa de Deus: Eu não quero a morte do pecador. Ora, nós devemos
conformar a nossa com a vontade divina, como já se estabeleceu. Logo, também não devemos querer
que os infiéis sejam condenados à morte.
Mas, em contrário, a Escritura: Sai por esses caminhos e cercos e força-os a entrar, para que fique cheia
a minha casa. Ora, na casa de Deus, isto é, na santa Igreja, os homens entram pela fé. Logo, certos
podem ser forçados a aceitá-la.

SOLUÇÃO. – Há certos infiéis, como os gentios e os judeus, que nunca receberam a fé; e esses de
nenhum modo devem ser compelidos a crer, pois crer depende da vontade. Podem porém ser obrigados
pelos fiéis, se estes tiverem poder para tal, a não lhes impedirem a fé, com blasfêmias, mas persuasões
ou mesmo com perseguições francas. E por isso, os fiéis de Cristo movem frequentemente guerra aos
infiéis; não pelos obrigar a crer, pois ainda que os tivessem vencidos e cativos deixar-lhes-iam a
liberdade de quererem crer ou não; mas pelos compelir a não impedir a fé em Cristo. - Outro é o caso
porém, dos infiéis, que outrora tiveram fé e ainda a confessam, como os heréticos e todos os apóstatas.
E esses devem ser forçados, mesmo com violência física, a cumprir o que prometeram e a conservar o
que uma vez receberam.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Pelo lugar citado, entenderam alguns ser proibido não,
certo, a excomunhão, mas a morte dos heréticos, como é claro pelo passo citado de Crisóstomo. E
Agostinho diz, de si: Minha primeira opinião era que não se deve forçar ninguém a fazer parte da
unidade de Cristo, senão persuadindo com palavras e lutando com discussões. Mas esta minha opinião
fica excluída, não pelas palavras dos que me contradizem, mas pelos fatos demonstrativos do contrário.
Pois o terror das leis só serviu para levar muito a dizerem: Graças ao Senhor, que nos rompeu os
vínculos. Quando, portanto, o Senhor diz: Deixai crescer uma e outra coisa até a ceifa - a sequência do
texto mostra claramente como deve ser entendido: Para que talvez não suceda que, arrancando a
cizânia, arranqueis juntamente com ela também o trigo. - Por onde suficientemente se mostra diz
Agostinho que quando isto não se deve temer, isto é, quando os crimes de um são tão conhecidos e
execrados por todos, que não acha nenhum defensor ou, pelo menos, defensor tal, que possa causar
cisma, então não pode dormir a severidade da disciplina.

RESPOSTA À SEGUNDA. – Os judeus, que de nenhum modo receberam a fé, não devem ser forçados a
aceitá-la. Os que, porém a receberam devem ser obrigados à força a conservar a fé, como se diz no
mesmo capítulo.

RESPOSTA À TERCEIRA. – Assim como prometer é próprio da vontade e cumprir o exige a necessidade,
assim também, próprio da vontade é receber a fé, e, de outro lado, é imposição da necessidade
conservar a fé já recebida. Por onde, os heréticos devem ser compelidos a conservar a fé. Pois, diz
Agostinho: Porque costumavam este: a clamar - somos livre: de crer ou não? Contra quem Cristo
empregou a força? - Saibam, pois, que Cristo forçou, primeiro, Paulo, e depois o ensinou.

RESPOSTA À QUARTA. – Como diz Agostinho na mesma Epistola, ninguém de nós quer que nenhum
herético pereça. Mas a casa de Davi não pode ter paz senão pela morte do seu filho Absalão, na guerra
que movia contra o Pai. Assim, a Igreja católica, se salva uns com a perdição de outros, cura a dor do
coração materno com a libertação de tantos povos.

## Art. 9 — Se se pode ter comunhão com os infiéis.
O nono discute-se assim. – Parece que se pode ter comunhão com os infiéis.

1. – Pois, diz o Apóstolo: Se algum dos infiéis vos convida e quereis ir, comei de tudo o que se vos põe
diante. E Crisóstomo diz: Permitimos, sem nenhuma proibição, que possais tomar parte nas refeições
dos pagãos, Ora, com quem comemos temos comunhão. Logo, é lícito ter comunhão com os infiéis.

2. Demais. – O Apóstolo diz: Porque, que me vai a mim em julgar daqueles que estão fora? Ora, os infiéis
estão fora. Por onde, como, por juízo da Igreja, os fiéis estão proibidos de ter comunhão com certos,
resulta que não estão proibidos de a ter com os infiéis.

3. Demais. – O Senhor não pode ter comunhão com o escravo senão comunicando-se com ele, ao menos
verbalmente; porque o senhor manda no escravo, ordenando. Ora, os Cristãos podem ter escravos
infiéis, judeus, ou ainda pagãos ou sarracenos. Logo, podem licitamente ter comunhão com eles.
Mas, em contrário, a Escritura: Não celebrarás concerto algum com elas, nem as tratarás com
compaixão, nem contrairás com elas matrimônios. E comentando o outro lugar. - A mulher, que padece
o fluxo mensal etc. – diz a Glosa: Devemos nos abster de tal modo da idolatria, que não tenhamos
contato com os idólatras, nem com os seus discípulos, nem tenhamos comunhão com eles.

SOLUÇÃO. – De dois modos pode ser interdito aos infiéis ter comunhão com uma pessoa: como pena
imposta aquele com quem se proíbe aos fiéis comunicar, ou como cautela para aqueles a quem se
proíbe a comunhão. E ambas essas causas podem se fundar nas palavras do Apóstolo. Assim, depois de
ter proferido a sentença de excomunhão, dá-lhe como fundamento: Não sabeis que um pouco de
fermento corrompe toda a massa? E em seguida, dá a razão da pena infligida, por juízo da Igreja,
quando diz: Por ventura não julgais vós daqueles que estão dentro?
Por isso, do primeiro modo, a Igreja não proíbe as fiéis a comunhão com os infiéis, pagãos ou judeus,
que nunca receberam a fé cristã. Porque não deve proferir, sobre eles, nenhum juízo espiritual, mas
temporal, em determinado caso, quando, vivendo entre Cristãos, cometam alguma culpa e sejam
punidos pelos fiéis temporalmente. Mas, deste modo, isto é, como pena, a Igreja proíbe aos fiéis ter
comunhão com os infiéis, que se desviaram da fé recebida, quer corrompendo-a, como os heréticos,
quer totalmente abandonando-a, como os apóstatas. Em ambos estes casos a Igreja profere contra eles
a sentença de excomunhão.
Mas do segundo modo, é mister distinguir entre as diversas condições das pessoas, dos negócios e dos
tempos. – Assim, certos estão de tal modo firmes na fé, que se pode esperar, da sua convivência com os
infiéis, que antes, os convertam do que percam a fé. Por onde, não se lhes deve proibir comuniquem-se
com os infiéis, pagãos ou judeus, que ainda não receberam a fé; e sobretudo urgindo a necessidade. -
Aos que porém forem simples e fracos na fé, cuja subversão possa provavelmente temer-se, se lhes
deve proibir comunicar com os infiéis; e sobretudo para que não venham a ter com eles grande
familiaridade ou com eles comuniquem, sem necessidade.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. – A Igreja não tem que proferir juízo contra os infiéis, de modo a lhes infligir
uma pena espiritual; pode porém proferir um juízo sobre certos dentre eles, para infligir uma pena
temporal. Daí vem que às vezes a Igreja, por certas culpas especiais, priva certos infiéis da comunhão
com os fiéis.

RESPOSTA À TERCEIRA. – É mais provável a conversão do escravo, submetido às ordens do senhor, fiel à
fé, que este tem, do que inversamente. Por isso não é proibido aos fiéis terem escravos infiéis. O senhor
porém que correr perigo iminente, convivendo com tal escravo, deve despedi-lo, conforme à ordem de
Deus: Se o teu pé te escandaliza, corta-o e lança fora de ti.

RESPOSTA AO ARGUMENTO CONTRÁRIO. – Essa ordem do Senhor se refere aos gentios, em cujas
terras os judeus entraram; pois estes inclinados à idolatria, era de temer não perdessem a fé pela
convivência continuada com aqueles. Por isso, no mesmo lugar se acrescenta: Porque ela seduzirá a teu
filho para que me não siga.

## Art. 10 — Se os infiéis podem ter governo ou domínio sobre os fiéis.
O décimo discute-se assim. – Parece que os infiéis podem ter governo ou domínio sobre os fiéis.

1. – Pois, diz o Apóstolo. Todos os servos que estão debaixo do jugo estimem a seus amos por dignos de
toda honra. E o lugar seguinte mostra que este se refere aos infiéis: E os que temem senhores fiéis não
os desprezem. E noutro passo diz a Escritura: Servos, sede obedientes aos vossos senhores com todo o
temor, não somente aos bons e moderados, mas também aos de dura condição. Ora, a doutrina
apostólica não ordenaria tal se os infiéis não pudessem governar os fiéis. Logo, aqueles podem governar
a estes.

2. Demais. – Todos os que pertencem à família de um príncipe devem obedecer-lhe. Ora, certos fiéis
eram da família de príncipes infiéis, donde o dizer a Escritura. Todos os santos vos saúdam, mas com
muita especialidade os que são da família de César, isto é, de Nero, que era infiel. Logo, os infiéis podem
governar os fiéis.

3. Demais. – Como diz o Filósofo, o escravo é o instrumento do Senhor, no atinente à vida humana,
assim como o ajudante do artífice é o instrumento deste no concernente à obra de arte. Ora, nessas
condições, pode o fiel estar sujeito ao infiel, pois os fiéis podem ser trabalhadores dos infiéis. Logo, os
infiéis podem governar os fiéis e mesmo ter domínio sobre estes.
Mas, em contrário, quem governa deve julgar os governados. Ora, os infiéis não podem julgar os fiéis,
conforme o Apóstolo: Atreve-se algum de vós, tendo negócio contra outro, ir a juízo perante os iníquos,
isto é, os infiéis, e não à presença dos santos? Logo, os infiéis não podem governar os fiéis.

SOLUÇÃO. - De dois modos podemos considerar este assunto. - Primeiro, quanto ao domínio ou o
governo, a ser instituído, dos infiéis sobre os fiéis. O que de nenhum modo deve ser permitido, porque
causaria escândalo e perigo para a fé. Pois facilmente os que estão sujeitos à jurisdição de outros podem
ser influenciados por eles de maneira a lhes seguir as ordens, a menos que sejam os súditos dotados de
grande virtude. E semelhantemente, os infiéis desprezarão a fé, se conhecerem os desfalecimentos dos
fiéis. Por isso o Apóstolo proibiu aos fiéis discutir em juízo perante um juiz infiel. Por isso de nenhum
modo a Igreja permite aos infiéis exercerem domínio sobre os fiéis, ou de qualquer modo os
governarem, em qualquer ministério. – De outra maneira, podemos considerar o domínio ou governo já
existente.
Nesse caso, devemos notar que o domínio e o governo foram introduzidos por direito humano, ao passo
que a distinção entre fiéis e infiéis é de direito divino. Ora, o direito divino, fundado na graça, não
elimina o direito humano, fundado em a natureza racional. Logo, a distinção entre fiéis e infiéis, em si
mesmo considerada, não elimina o domínio e o governo dos infiéis sobre os fiéis. Pode porém
justamente, por sentença ou ordem da Igreja, que tem de Deus a sua autoridade, ser eliminado esse
direito de domínio ou governo. Porque os infiéis, como castigo da sua infidelidade, merecem perder o
governo dos fiéis, transformados em filhos de Deus. Mas isto a Igreja faz umas vezes e, outras, não. –
Assim, quanto aos infiéis a ela sujeitos, mesmo temporalmente, e aos seus membros, estabeleceu o
direito seguinte. O escravo de judeus, uma vez tornado Cristão, seja libertado da escravidão, sem
nenhuma recompensa, se for escravo crioulo, isto é, nascido tal; e semelhantemente, se foi comprado
como escravo, quando ainda era infiel. Se porém foi comprado para ser vendido, deve ser exposto à
venda durante três meses. E nisto não comete a Igreja nenhuma injustiça, porque, sendo os judeus seus
escravos, pode dispor das coisas deles, assim como também os príncipes seculares fizeram muitas leis
sobre os seus súditos, no interesse da liberdade. – Para os infiéis porém, que não lhe estão sujeitos, nem
aos seus membros, temporalmente, a Igreja não aplicou essa legislação, embora pudesse, de direito,
instituí-la. E isto o fez para evitar escândalo. Assim também o Senhor mostrou que podia excusar-se do
tributo, porque os filhos são livres; contudo mandou pagálo, afim de não dar escândalo. Por isso
também Paulo, depois de ter mandado que os escravos estimem aos seus amos, acrescenta: Para que o
nome do Senhor e a sua doutrina não seja blasfemada.
E daqui se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. – O referido governo de César preexistia à distinção entre fiéis e infiéis. Por isso
não se dissolvia pela conversão de um infiel à fé. E era útil que alguns fiéis tivessem lugar na família do
imperador, para defender os demais fiéis. Assim, S. Sebastião confortava o ânimo dos Cristãos, que via
prestes a desfalecerem nos tormentos, e continuava, oculto pela clâmide militar, a fazer parte da família
de Diocleciano.

RESPOSTA À TERCEIRA. – Os escravos estão sujeitos ao senhor por toda a vida; e os súditos, aos chefes,
em todos os negócios. Mas os ajudantes dos artífices estão-lhes sujeitos quanto a certas obras especiais.
Por onde, é mais perigoso os infiéis terem o domínio ou o governo sobre os fiéis, que receberem deles o
ministério de algum serviço especial. Por isso, a Igreja permite possam os Cristãos cultivar as terras dos
judeus, pelos não levar isso necessariamente a conviver com eles. E Salomão também pediu ao rei de
Tiro mestres de obra para cortarem madeira, como se lê na Escritura. – E contudo, essa comunicação e
convivência deve ser totalmente proibida, se se temer que dela provenham perigos da subversão da fé
dos fiéis.

## Art. 11 — Se se devem tolerar os ritos dos infiéis.
O undécimo discute-se assim. – Parece, que não se devem tolerar os ritos dos infiéis.
1 – Pois, é manifesto que os infiéis, praticando os seus ritos, pecam. Ora, consente no pecado quem,
podendo impedi-lo, não o impede como diz a Glosa aquilo do Apóstolo: não somente os que estas
causas fazem, senão também os que consentem aos que as fazem. Logo, pecam os que lhes toleram os
ritos.

2. Demais. – Os ritos dos judeus se assimilam aos da idolatria. Pois, aquilo do Apóstolo Não vos metais
outra vez debaixo do jugo da escravidão - diz a Glosa: Não é mais leve esta lei da escravidão do que a da
idolatria. Ora, não se admitiria que qualquer pessoa praticasse o rito de idolatria; antes, os príncipes
cristãos faziam primeiro fechar os templos dos ídolos, e depois demoli-los, como o narra Agostinho.
Logo, e do mesmo modo, não devem ser tolerados os ritos dos judeus.

3. Demais. – O pecado de infidelidade é gravíssimo, como já se disse. Ora, os demais pecados, como o
adultério, o furto e outros, não são tolerados, mas punidos por lei. Logo, também não se devem tolerar
os ritos dos infiéis.
Mas, em contrário, diz Gregório, dos judeus: Todos tenham plena liberdade de observar e celebrar todas
as suas festividades, como o fizeram até aqui, e as observaram os antepassados, por muito tempo.

SOLUÇÃO. – O governo humano deriva do divino e deve imitá-lo. Ora, Deus, embora omnipotente e o
sumo bem, permite, contudo existam no universo certos males, que poderia impedir, afim de que, a
eliminação deles não acarretasse também a de maiores bens, ou resultassem males piores. Assim
também, os chefes do governo humano toleram com razão certos males, para não ficarem impedidos
certos bens, ou ainda, para não caírem em males piores, como diz Agostinho: Suprime as meretrizes, da
sociedade humana, e perturbarás tudo com a libidinosidade. Por onde, embora pequem em seus ritos
os infiéis, podem ser tolerados, ou por causa de algum bem deles proveniente, ou por algum mal
evitado.
Por outro lado, de observarem os judeus os seus ritos, que outrora prefiguravam a verdade da nossa fé,
resulta o bem de termos, dos inimigos, um testemunho dessa mesma fé, e de nos ser representado,
quase em figura, o que cremos. Por isso, são tolerados, com os seus ritos. Outros ritos porém, dos
infiéis, que nenhuma verdade ou utilidade tenham, não devem, do mesmo modo, ser tolerados, senão
talvez para evitar algum mal, isto é, o escândalo ou o dissídio, que da proibição poderia provir, ou o
impedimento à salvação dos que, assim tolerados, se converteriam à fé a pouco e pouco. E por isso
também a Igreja tolerou, às vezes, quando era grande a multidão dos infiéis, os ritos, dos heréticos e
dos pagãos.
Donde se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 12 — Se os filhos dos judeus e demais infiéis devem ser batizados contra a vontade dos pais.
O duodécimo discute-se assim. – Parece que os filhos dos judeus e demais infiéis devem ser batizados
contra a vontade dos pais.
1 – Pois, é mais forte o vínculo matrimonial do que o direito do pátrio poder sobre o filho. Porque este
direito pode ser dissolvido pelo homem, quando, de filho-família, vem a emancipar-se; ao contrário, os
homens não podem dissolver o vínculo matrimonial, conforme a Escritura: Não separe o homem o que
Deus ajuntou. Ora, por infidelidade, dissolve-se o vínculo matrimonial, conforme o Apóstolo. Porém se o
infiel se retira que se retire; porque neste caso já o nosso irmão ou a nossa irmã não estão mais sujeitos
à escravidão. E um Cânon dispõe que se um cônjuge infiel não quer, sem ofensa do seu Criador, coabitar
com o outro, então este não deve fazê-lo. Logo, com maior razão, por infidelidade, perde-se o direito do
pátrio poder sobre os filhos. Podem portanto, os filhos dos infiéis ser batizados contra a vontade deles.

2. Demais. – Devemos auxiliar os outros, quando há perigo de morte eterna, mais que quando esse
perigo é apenas de morte temporal. Ora, pecaríamos não socorrendo a quem víssemos correr perigo de
morte temporal. Como, pois os filhos dos judeus e demais infiéis corram perigo de morte eterna, se
forem abandonados aos pais, que os educarão na infidelidade, resulta que devem esses filhos ser-lhes
tirados, batizados e instruídos na fé.

3. Demais. – Os filhos dos escravos são escravos e estão sob o poder do senhor. Ora, os judeus são
escravos dos reis e dos príncipes. Logo, também os seus filhos. Portanto, os reis e os príncipes podem
fazer dos filhos dos judeus o que quiserem, e, por consequência nenhuma injustiça farão batizando-lhes
os filhos, contra a vontade deles.

4. Demais. – Todos, pertencemos mais a Deus, criador da nossa alma, que aos pais carnais, de quem
temos o corpo. Logo, não é injusto tirar os filhos dos judeus aos pais carnais e consagrá-los a Deus pelo
batismo.

5. Demais. – O batismo é mais eficaz à salvação do que a pregação, porque purifica imediatamente da
mácula do pecado, do reato da pena, e abre as portas do céu. Ora, o perigo proveniente da falta de
pregação é imputado ao que não pregou, como se lê na Escritura falando do que vê vir vindo a espada e
não toca a trombeta. Logo, com maior razão, se os filhos dos judeus se condenarem, por falta de
batismo, tal será imputado, como pecado aos que podiam batizá-los e não o fizeram.
Mas, em contrário, não se deve fazer injustiça a ninguém. Ora, fa-la-íamos aos judeus se lhes
batizássemos os filhos contra a vontade deles; porque então perderiam o direito do pátrio poder sobre
os filhos já fiéis. Logo, não lhos devemos batizar contra a vontade deles.

SOLUÇÃO. – O costume, na Igreja, goza da máxima autoridade e deve ser preferido a tudo o mais, pois a
própria doutrina dos doutores católicos tira da Igreja a sua autoridade. Por onde, devemos nos apoiar,
antes, na autoridade da Igreja do que na de Agostinho, de Jerônimo ou de qualquer outro doutor. Ora,
nunca foi uso da Igreja batizar os filhos dos judeus, contra a vontade deles. Pois, nos tempos passados,
muitos e santíssimos bispos, familiares de muitos príncipes católicos e poderosíssimos, como Silvestre,
de Constantino, e Ambrósio, de Teodósio, de nenhum modo deixariam de lhes pedir mandassem
proceder a esse batismo, se tal estivesse de acordo com a razão. Por onde, é perigoso introduzir essa
nova doutrina e batizar os filhos dos judeus, contra a vontade deles, e contra o costume da Igreja, até
agora observado.
E disto pode dar-se dupla razão. – Uma, por causa do perigo da fé. Se, pois, as crianças, ainda sem o uso
da razão, recebessem o batismo, depois, chegados à idade adulta, facilmente poderiam ser induzidos
pelos pais a abandonarem o que receberam ignorando; o que reverteria em detrimento da fé. – A outra
razão está em essa prática repugnar à justiça natural. Pois o filho é naturalmente, parte do pai. E, ao
princípio, dos pais não se distingue corporalmente, enquanto no ventre materno. Em seguida, vindo à
luz, antes de ter uso do livre arbítrio, depende dos cuidados paternos, como de um ventre espiritual.
Pois enquanto não tem uso da razão, a criança não difere do animal irracional. Por onde, assim como o
dono de um boi ou um cavalo pode usar dele como quiser, nos termos da lei civil, como de instrumento
próprio; assim também é de direito natural esteja o filho, antes do uso da razão, sob os cuidados do pai.
Portanto, seria contra a justiça natural, subtrair a criança, antes do uso da razão, a esses cuidados, ou
fazerlhes qualquer coisa, contra a vontade dos mesmos. Quando, porém começar a ter o uso do livre
arbítrio, já começará a ser senhor de si e pode prover-se a si mesmo, no pertencente ao direito divino
ou natural. E então, deve ser induzido à fé, não coagida, mas persuadida. E pode, mesmo contra a
vontade dos pais, receber a fé e ser batizada; não porém enquanto sem o uso da razão. Por isso, se disse
que os filhos dos antigos patriarcas foram salvos pela fé dos pais; querendo-se com isso significar, que
aos pais pertence velar pela salvação dos filhos, sobretudo antes de terem o uso da razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – No vínculo matrimonial ambos os cônjuges, tem o uso do
livre arbítrio, e pode um, contra a vontade do outro, assentir na fé. Ora, isto não se dá com a criança,
antes de ter o uso da razão. Porém, depois que tiver esse uso, então a comparação colhe, se quiser
converter-se.

RESPOSTA À SEGUNDA. – Ninguém deve ser subtraído à morte natural contra a ordem do direito civil.
Assim, ninguém deve livrar violentamente da morte o condenado pelo juiz à morte temporal. Por onde,
ninguém deve violar a ordem do direito natural, pela qual o filho está sob os cuidados paternos, para
libertá-la do perigo da morte eterna.

RESPOSTA À TERCEIRA. – Os judeus são escravos dos príncipes por escravidão civil, que não exclui a
ordem do direito natural ou divino.

RESPOSTA À QUARTA. – O homem se ordena a Deus pela razão, pela qual pode conhecê-la. Por isso, a
criança, antes do uso da razão, se ordena naturalmente a Deus pela razão dos pais, de cujos cuidados
por natureza depende; e conforme a disposição deles é que se deve tratar com ela das causas divinas.

RESPOSTA À QUINTA. – O perigo resultante da pregação omitida não é iminente senão aqueles que tem
obrigação de pregar. Por isso a Escritura disse antes: Eu te dei por atalaia à casa de Israel. Ora, velar
pelos filhos dos infiéis, quanto aos sacramentos da salvação, pertencelhes aos pais. Por onde, corre-lhes
o perigo iminente se, pela privação dos sacramentos, os filhos vierem a sofrer detrimento na salvação.