# Questão 8: Do dom do intelecto.
Em seguida devemos tratar do dom do intelecto e da ciência, que correspondem à virtude da fé.
E quanto ao dom do intelecto, discutem-se oito artigos:

## Art. 1 — Se o intelecto é um dom do Espírito Santo.
O primeiro discute-se assim. – Parece que não é o intelecto um dom do Espírito Santo.

1. – Pois, os dons gratuitos distinguem-se dos sobrenaturais, a que se acrescentam. Ora, o intelecto é
um dom natural da alma, pelo qual conhecemos os princípios evidentes, como o demonstra o Filósofo.
Logo, não deve ser considerado dom do Espírito Santo.

2. Demais. – As criaturas participam, ao seu modo e proporção, dos dons divinos, como está claro em
Dionísio. Ora, pelo seu modo, a natureza humana não conhece intuitivamente a verdade, o que é por
essência próprio do intelecto, mas discursivamente, o que é próprio da razão, conforme está claro em
Dionísio. Logo, o conhecimento divino concedido aos homens deve ser considerado dom, antes, da
razão que do intelecto.

3. Demais. – Na divisão das potências da alma, o intelecto se contrapõe à vontade, como claramente o
diz Aristóteles. Ora, nenhum dom do Espírito Santo se chama vontade. Logo, também nenhum deve
chamar-se intelecto.
Mas, em contrário, a Escritura. E descansará sobre ele o Espírito do Senhor; espírito de sabedoria e de
entendimento.

SOLUÇÃO. – O nome de intelecto implica um conhecimento íntimo; pois, inteligir significa quase ler
interiormente. E isto aparecerá claro a quem considerar na diferença entre intelecto e sentido, Pois, o
conhecimento sensível tem por objeto as qualidades exteriores sensíveis; ao contrário, o conhecimento
intelectual penetra até a essência das coisas, porquanto o seu objeto é a quididade das mesma como diz
Aristóteles. Ora, por muitos gêneros se distribui a constituição íntima das coisas, que o conhecimento
humano deve penetrar até o que tem de mais intrínseco. Assim, sob os acidentes se oculta a natureza
substancial dos seres; nas palavras se ocultam as suas significações; nas semelhanças e nas figuras, a
verdade figurada. Também o inteligível é, de certo modo, interno, em relação ao sensível, apreendido
externamente; e as causas compreendem os efeitos, e reciprocamente. Por onde, podemos considerar o
intelecto como concernente a tudo isso. Mas, começando o conhecimento do homem pelos sentidos,
como pelo que é quase exterior, é manifesto que, quanto mais forte for a luz do intelecto, tanto mais
profunda será a sua penetração. Ora, o lume do nosso intelecto, sendo de virtude finita, tem um grau
limitado de penetração. Por isso o homem necessita de um lume sobrenatural, para chegar a certos
conhecimentos que não pode alcançar pelo só lume natural. E esse lume sobrenatural dado ao homem
chama-se dom do intelecto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Pelo lume natural infuso em nós conhecemos somente
certos princípios gerais, naturalmente conhecidos. Mas, como o homem se ordena a uma felicidade
sobrenatural, segundo já se disse, é forçoso, alcance certas noções mais elevadas. E para isso é
necessário o dom do intelecto.

RESPOSTA À SEGUNDA. – O discurso da razão sempre começa pelo intelecto e no intelecto termina;
pois, raciocinamos partindo de certos objetos inteligidos. E o discurso da razão se completa quando
chegamos a inteligir o que, antes, nos era desconhecido. Portanto, o nosso raciocínio se baseia numa
intelecção precedente. Ora, o dom da graça não procede do lume natural, mas se lhe acrescenta, quase
para o aperfeiçoar. Por onde, a esse acréscimo não se chama razão, mas antes, intelecto, pois, o lume
acrescentado está para o que conhecemos sobrenaturalmente, como o lume natural ao que
primordialmente conhecemos.

RESPOSTA À TERCEIRA. – A vontade designa simplesmente um apetite movido, sem determinação de
nenhuma excelência. Ao passo que o intelecto designa uma certa excelência do conhecimento, de
penetrar até ao íntimo. Por onde, o dom sobrenatural recebe, antes, a denominação de intelecto, que a
de vontade.

## Art. 2 — Se temos o dom do intelecto simultaneamente com o da fé.
O segundo discute-se assim. – Parece que o dom do intelecto não pode ser possuído simultaneamente
com o da fé.

1. – Pois, como diz Agostinho: O que é entendido é delimitado pela compreensão de quem entende.
Ora, não cremos o que compreendemos, conforme àquilo do Apóstolo. Não que a tenha eu já
alcançado, ou que seja já perfeito. Logo, fé e intelecto não podem coexistir no mesmo sujeito.

2. Demais. – Tudo o que é inteligido é visto pelo intelecto. Ora, é a fé relativa às coisas que não
aparecem, como já se disse. Logo, a fé não pode coexistir num mesmo sujeito com o intelecto.

3. Demais. – O intelecto é susceptível de maior certeza que a ciência. Ora, ciência e fé não podem
coexistir num mesmo sujeito como já se disse. Logo, com maior razão, o intelecto e a fé.
Mas, em contrário, Gregório diz, que o intelecto, pelas coisas ouvidas, ilumina a mente. Ora, quem tem
fé pode ter a mente iluminada relativamente a essas coisas; donde o dizer a Escritura: o Senhor lhe
abriu o entendimento aos discípulos, para alcançarem o sentido das Escrituras. Logo, o intelecto pode
coexistir com a fé.

SOLUÇÃO. – A questão vertente exige dupla distinção: uma relativa à fé e a outra, ao intelecto. –
Quanto à fé, devemos distinguir o que lhe pertence essencial e diretamente e excede a razão natural -
como a Trindade e a unidade divinas e a encarnação do Filho de Deus - do que lhe pertence por lhe estar
ordenado, de certo modo, como tudo o que contém a divina Escritura. – No concernente ao intelecto,
devemos distinguir a dupla acepção em que podemos tomar a palavra inteligir. De um modo, em
sentido perfeito, isto é, quando chegamos a conhecer a essência da coisa inteligida e a verdade da
proposição inteligida, como em si mesma é. E deste modo não podemos inteligir, por força da fé, o que
diretamente a ela pertence. Mas o podemos quanto a certas coisas à fé ordenadas. De outro modo,
podemos inteligir uma coisa imperfeitamente, isto é, quando não conhecemos o que é ou de que modo
é a essência mesma dela, ou a verdade da proposição; contudo, conhecemos que as aparências externas
não contrariam a verdade. Isto é, quando inteligimos que, por causa das aparências externas, não
precisamos nos afastar das verdades da fé. E deste modo nada impede intelijamos, enquanto temos fé,
também o que essencialmente lhe pertence.
E daqui se DEDUZEM CLARAS AS RESPOSTAS ÀS OBJEÇÕES. – Pois, as primeiras três objeções colhem,
no sentido em que inteligimos perfeitamente. E a última procede, quanto ao intelecto das coisas
ordenadas à fé.

## Art. 3 — Se o intelecto, considerado dom do Espírito Santo, é prático ou somente especulativo.
O terceiro discute-se assim. – Parece que o intelecto, dom do Espírito Santo, não é prático, mas
somente especulativo.

1. – Pois, o intelecto, como diz Gregório: peneira certas coisas mais alias, Ora, o objeto do intelecto
prático não é alto, mas ao contrário, o que há de ínfimo, a saber, o singular, sobre o que versam os atos.
Logo, o intelecto, considerado como dom, não é intelecto prático.

2. Demais. – O intelecto, dom, é algo de mais digno que o intelecto, virtude intelectual. Ora, o intelecto,
virtude intelectual, só versa sobre o necessário, como está claro no Filósofo. Logo, com maior razão, o
intelecto, dom, versará somente sobre o necessário. Por outro lado, o intelecto prático não versa sobre
o necessário, mas sobre o susceptível de mudança e que pode ser objeto da ação humana. Logo, o
intelecto, dom, não é intelecto prático.

3. Demais. – O dom do intelecto ilumina a mente para o que excede a razão natural. Ora, as obras
humanas, sobre que versa o intelecto prático, não excedem a razão natural, que dirige as ações, como
do sobredito resulta. Logo, o intelecto, que é dom, não é intelecto prático.
Mas, em contrário, diz a Escritura: É bom entendimento o de todos os que obram como ele.

SOLUÇÃO. – Como já dissemos, o dom do intelecto diz respeito não só ao que primária e principalmente
é da alçada da fé, mas também a tudo que a ela se ordena. Ora, as boas obras se ordenam, de certo
modo, para a fé. Pois, a fé obra por caridade no dizer do Apóstolo. Logo, o dom do intelecto também se
estende a certas obras, não por versar principalmente sobre elas, mas porque, ao agir, nós vos
regulamos pelas razões eternas às quais adere a razão superior, que é aperfeiçoada pelo dom do
intelecto, considerando-as e consultando-as, segundo Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As obras humanas, em si mesmas consideradas, não tem
nenhuma alta excelência. Mas a tem, podendo então o intelecto versar sobre elas quando relativas à
regra da lei eterna e ao fim da beatitude divina.

RESPOSTA À SEGUNDA. – À dignidade mesma do dom do intelecto pertence inteligir o inteligível eterno
ou considerar as verdades necessárias, não só naquilo mesmo que são, mas também enquanto regras
determinadas dos atos humanos. Pois, quanto mais capaz é a virtude cognoscitiva, tanto mais nobre ela
é.

RESPOSTA À TERCEIRA. – A regra dos atos humanos é tanto a razão humana como a lei eterna conforme
já dissemos. Ora, a lei eterna excede a razão natural. Por onde, o conhecimento dos atos humanos,
enquanto regulados pela lei eterna, excede a razão natural e precisa da luz sobrenatural do dom do
Espírito Santo.

## Art. 4 — Se o dom do intelecto é infuso em todos os que tem a graça.
O quarto discute-se assim. – Parece que o dom do intelecto não é infuso em todos os que tem a graça.

1. – Pois, como diz Gregório, o dom do intelecto é dado contra o embotamento da mente. Ora, muitos
dos que tem a graça ainda padecem desse embotamento. Logo, nem todos os que tem a graça tem o
dom do intelecto.

2. Demais. – Entre as coisas que dizem respeito ao conhecimento, só é necessária para a salvação a fé,
porque como diz a Escritura, Cristo habita pela fé nos vossos corações. Ora, nem todos os que tem fé
tem o dom do intelecto; antes, os que creem devem orar para que entendam, como diz Agostinho.
Logo, o dom do intelecto não é necessário para a salvação, e portanto não o tem todos os que estão em
graça.

3. Demais. – O que é comum a todos os que tem a graça nunca lhes pode faltar. Ora, a graça do
intelecto, e de outros dons, perdemo-la às vezes utilmente; pois às vezes a alma, que compreende
coisas sublimes, se eleva pela soberba e, por isso, fica embotada gravemente para atingir causas ínfimas
e vis, no dizer de Gregório. Logo, o dom do intelecto não o tem todos os que tem a graça.
Mas, em contrário, a Escritura: Não souberam nem entenderam, andam em trevas. Ora, ninguém, que
tenha a graça, anda nas trevas, conforme àquilo do Evangelho: O que me segue não anda em trevas.
Logo, ninguém, que tenha a graça, carece do dom do intelecto.

SOLUÇÃO. – Todos os que tem a graça hão de necessariamente ter a retidão da vontade; pois que, pela
graça, prepara-se a vontade do homem para o bem, como diz Agostinho. Ora, a vontade não pode
ordenar-se retamente para o bem, sem que nela preexista algum conhecimento da verdade, pois o
objeto da vontade é o bem conhecido, como diz Aristóteles, Assim como, pois, pelo dom da caridade, o
Espírito Santo ordena a vontade do homem a mover-se diretamente para um certo bem sobrenatural,
assim, pelo dom do intelecto ilumina-lhe a mente para conhecer uma certa verdade sobrenatural a que
deve tender a vontade reta. Por onde, assim como o dom da caridade existe em todos os que tem a
graça santificante, assim também o dom do intelecto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Certos dos que tem a graça santificante podem sofrer
embotamento relativo ao que não é necessário à salvação. Mas, no concernente ao necessário, são
suficientemente instruídos pelo Espírito Santo, conforme àquilo da Escritura. A sua unção vos ensina em
todas as causas.

RESPOSTA À SEGUNDA. – Embora nem todos os que tem a fé entendam plenamente o que se lhes
propõe para crerem, entendem contudo que em tais verdades devem crer e em nada devem desviar-se
delas.

RESPOSTA À TERCEIRA. – O dom do intelecto nunca falta aos santos, relativamente ao necessário à
salvação. Mas falta às vezes em relação a outras coisas, de modo que não podem penetrar
perfeitamente tudo, pelo intelecto, para que se livrem da contaminação da soberba.

## Art. 5 — Se o dom do intelecto existe mesmo nos que não tem a graça santificante.
Parece que o dom do intelecto existe mesmo nos que não tem a graça santificante.
1 – Pois, diz Agostinho, explicando aquilo da Escritura - A minha alma desejou ansiosa as tuas
justificações - O intelecto voa rápido, seguindo-o tardo, ou mesmo não o seguindo, o afeto. Ora, todos
os que tem a graça santificante tem pronto o afeto, por via da caridade. Logo, pode existir o dom do
intelecto nos que não tem a graça santificante.

2. Demais. – A Escritura diz, que é necessário haver inteligência nas visões proféticas; donde se conclui
não ir a profecia sem o dom do intelecto. Ora, a profecia pode existir sem a graça santificante, como
está claro no evangelho, onde aos que dizem - profetizamos em teu nome - responde-se: eu nunca vos
conheci. Logo, o dom do intelecto pode existir sem a graça santificante.

3. Demais. – O dom do intelecto responde à virtude da fé, conforme aquilo da Escritura, de acordo com
outra lição: Se o não crerdes não entendereis. Ora, a fé pode existir sem a graça santificante. Logo,
também o dom do intelecto.
Mas, em contrário, diz o Senhor: Todo aquele que do Pai ouviu e aprendeu vem a mim. Ora, pelo
intelecto, apreendemos e penetramos o que ouvimos, como o diz claramente Gregório. Logo, todo o
que tem o dom do intelecto vem a Cristo, o que não é possível sem a graça santificante. Portanto, sem
esta, não existe tal dom.

SOLUÇÃO. – Como já dissemos os dons do Espírito Santo aperfeiçoam a alma, levando esta a deixar-se
facilmente mover pelo mesmo. Por onde, o lume intelectual da graça é considerado dom do intelecto,
enquanto o intelecto humano se torna bem disposto para ser movido pelo Espírito Santo. Ora, consiste
a influência dessa moção em fazer-nos apreender a verdade relativa ao fim. Por isso, enquanto o
Espírito Santo não mover a inteligência humana para ter apreciação exata do fim, não consegue ela o
dom do intelecto embora conheça por iluminação do mesmo Espírito outros preâmbulos a esse dom.
Ora, essa apreciação exata do último fim só a possui aquele que não erra, relativamente a ele, ao qual
esta unido, como ao que é ótimo. E isto só o consegue quem tem a graça santificante, assim como, na
ordem moral, o homem exerce uma apreciação reta do fim pelo hábito da virtude. Por onde, ninguém
tem o dom do intelecto sem a graça santificante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Agostinho chama intelecto a qualquer iluminação
intelectual, que contudo não realiza o dom na sua essência perfeita, se não nos levar a inteligência a
apreciar com retidão o fim.

RESPOSTA À SEGUNDA. – A inteligência necessária à profecia é uma iluminação da mente relativa ao
que é revelado aos profetas; não o é, porém, relativamente à apreciação reta do fim último, o que
pertence ao dom do intelecto.

RESPOSTA À TERCEIRA. – A fé implica somente um assentimento ao que lhe é proposto. Enquanto que o
intelecto implica uma certa percepção da verdade, que não pode ser relativa ao fim senão em quem
possui a graça santificante, como se disse. Logo, o caso não é o mesmo, no tocante ao intelecto e à fé.

## Art. 6 — Se o dom do intelecto se distingue dos outros dons.
O sexto discute-se assim. – Parece que o dom do intelecto não se distingue dos outros dons.
1 – Coisas com contrários iguais são iguais. Ora, a sabedoria se opõe à estultícia; ao embotamento, o
intelecto; à precipitação, o conselho; à ignorância, a ciência, como está claro em Gregório Ora, a
estultícia, o embotamento, a ignorância e a precipitação não diferem entre si. Logo, nem o intelecto se
distingue dos demais dons.

2. Demais. – O intelecto, enquanto virtude intelectual difere das outras virtudes intelectuais, por lhe ser
próprio versar sobre os princípios evidentes. Ora, o dom do intelecto não versa sobre nenhum princípio
evidente. Pois, para conhecer o que naturalmente e em si mesmo é cognoscível basta o hábito natural
dos primeiros princípios. E, para o sobrenatural, basta a fé, porque os artigos de fé versam sobre os
como que primeiros princípios do conhecimento sobrenatural conforme se disse. Logo, o dom do
intelecto não se distingue dos outros dons intelectuais.

3. Demais. – Todo conhecimento intelectual é especulativo ou prático. Ora, o dom do intelecto diz
respeito a um e outro, como se disse. Logo, não se distingue dos outros dons intelectuais, mas os
abrange a todos.
Mas, em contrário, todos os membros de uma enumeração devem, de certo modo, distinguir-se uns dos
outros, pois a distinção é o princípio do numero. Ora, o dom do intelecto é enumerado entre os outros
dons, segundo se vê na Escritura. Logo, o dom do intelecto é distinto dos outros.

SOLUÇÃO. – É manifesta a distinção entre o dom do intelecto e os outros três dons - a piedade, a
fortaleza e o temor. Porque aquele pertence à potência cognitiva, ao passo que estes três, à potência
apetitiva. Mas a diferença entre o dom do intelecto e os três seguintes - o da sabedoria, da ciência e do
conselho, - que também pertencem à potência cognoscitiva, não é do mesmo modo manifesta. Assim,
certos distinguem o dom do intelecto do da ciência e do conselho, por pertencerem os dois últimos ao
conhecimento prático, e o primeiro, ao especulativo. E por outro lado, distinguem-no do dom da
sabedoria, que também versa sobre o conhecimento especulativo, por versar sobre o juízo, ao passo
que o intelecto respeita à capacidade de inteligir os objetos que lhe são propostos, ou, de lhes penetrar
o íntimo. a esta luz fizemos antes a enumeração dos dons. – Mas quem considerar diligentemente verá
que o dom do intelecto versa, não só sobre a especulação, mas ainda sobre as ações, como dissemos. E
semelhantemente, também o dom da ciência versa sobre aquela e sobre estas, como a seguir se dirá.
Por onde, é preciso fundar de outro modo a distinção entre os dons. Pois todos os quatro dons referidos
se ordenam ao conhecimento sobrenatural, infundido em nós pela fé. Ora, como diz a Escritura, a fé é
pelo ouvido Por onde, certas verdades devem ser propostas a serem cridas pelo homem, não enquanto
objetos de intuição, mas, enquanto ouvidas e às quais ele adere pela fé. Ora, a fé, primária e
principalmente, versa sobre a verdade primeira; secundariamente, sobre certas verdades relativas às
criaturas; e enfim, também se estende à direção das ações humanas, enquanto praticadas pela
caridade, como do sobredito e colhe. Por onde, em relação aos artigos propostos a serem cridos pela fé,
duas condições são exigidas de nós. Primeiro, que sejam penetradas ou apreendidas pela inteligência; e
isto constitui o dom do intelecto. Segundo, que as julguemos retamente, considerando que lhes
devemos aderir, afastando-nos do que lhes é oposto. Ora, esse juízo, no concernente às coisas divinas,
pertence ao dom da sabedoria; no relativo às coisas criadas, ao dom da ciência; e enfim, quanto à
aplicação às ações particulares, ao dom do conselho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A referida diferença entre os quatro dons convém
manifestamente à distinção entre as oposições aos mesmos, segundo Gregório. - Pois, o embotamento
se opõe à acuidade. Por isso, se chama por semelhança, agudo ao intelecto, quando pode penetrar o
íntimo dos objetos que lhes são propostos; ao contrário, o embotamento faz com que a mente não lhes
possa penetrar esse íntimo. - Em seguida, estulto se chama ao intelecto, que julga erradamente sobre o
fim comum da vida. Por isso, opõe-se propriamente à sabedoria, que torna reto o juízo sobre a causa
universal. - A ignorância, por seu lado, implica deficiência da mente, mesmo em relação a quaisquer
particularidades. Por isso se opõe à ciência, que possibilite ao homem o juízo reto sobre as causas
particulares, isto é, sobre as criaturas. - A precipitação, enfim, manifestamente se opõe ao conselho,
que nos leva a não agirmos antes da deliberação racional.

RESPOSTA À SEGUNDA. – O dom do intelecto é relativo aos primeiros princípios do conhecimento
gratuito. De modo diferente, porém, que a fé. Pois, esta faz assentir neles; ao passo que ao dom do
intelecto pertence penetrar pela mente o que é dito.

RESPOSTA À TERCEIRA. – O dom do intelecto versa tanto sobre o conhecimento especulativo como
sobre o prático. Não, quanto ao juízo, mas quanto à apreensão, para que seja compreendido o que é
dito.

## Art. 7 — Se ao dom do intelecto corresponde a sexta bem-aventurança, a saber: Bem-aventurados os limpos de coração porque eles viram a Deus.
O sétimo discute-se assim. – Parece que ao dom do intelecto não corresponde a sexta bem-
aventurança, a saber: Bem-aventurados os limpos de coração porque eles verão a Deus.
1 – Pois, a limpeza do coração parece dizer respeito sobretudo ao afeto, Ora, o dom do intelecto não
pertence ao afeto, mas antes à potência intelectiva, Logo, a referida bem-aventurança não corresponde
ao dom do intelecto.

2. Demais. – A Escritura diz: Purificando com a fé os seus corações, Ora, pela purificação do coração
adquire-se a limpeza do mesmo. Logo, a referida bem-aventurança pertence mais à virtude da fé que ao
dom do intelecto.

3. Demais. – Os dons do Espírito Santo aperfeiçoam o homem na vida presente. Ora, na vida presente
não temos a visão de Deus, que nos torna bem-aventurados, como já se estabeleceu. Logo, a sexta bem-
aventurança, implicando a visão de Deus, não pertence ao dom do intelecto.
Mas, em contrário, diz Agostinho. A sexta operação do Espírito Santo, que é o intelecto, convém aos
limpos de coração, que, com os olhos purificados, poderão ver o que os olhos não veem.

SOLUÇÃO. – A sexta bem-aventurança, como as outras, contém duas coisas: uma, a modo de mérito,
que é a pureza do coração; outra, a modo de prêmio, que é a visão de Deus como já dissemos. E ambas
pertencem, de alguma maneira, ao dom do intelecto. Pois, há dupla espécie de pureza. – Uma,
preambular e dispositiva à visão de Deus, a saber, a depuração do afeto, das afeições desordenadas. E
essa pureza do coração opera-se pelas virtudes e pelos dons pertencentes à potência apetitiva. – Outra
espécie de pureza do coração é a quase completiva, relativamente à visão divina. E essa é a pureza da
mente, depurada dos fantasmas e dos erros, de modo que as verdades propostas por Deus não sejam
recebidas a modo dos fantasmas corporais, nem segundo as falsidades heréticas. E esta pureza provém
do dom do intelecto.
Semelhantemente, também há duas espécies de visão de Deus: uma perfeita, pela qual vemos a
essência divina; outra, imperfeita, pela qual, embora não vejamos quem seja Deus, vemos contudo o
que não é. E nesta vida, tanto mais perfeitamente o conheceremos, quanto mais compreendermos que
excede a tudo quanto podemos apreender pelo intelecto. Ora, ambas essas visões pertencem ao dom
do intelecto: a primeira, ao dom consumado do intelecto, tal como existirá na pátria; a segunda, ao dom
do intelecto incoado, tal como o temos na via.
Donde se DEDUZEM CLARAS AS RESPOSTAS ÀS OBJEÇÕES. – Pois, as duas primeiras se fundam na
primeira espécie de pureza; e a terceira, na perfeita visão de Deus. Ora, os dons, que nos aperfeiçoam,
nesta vida, incoativamente, terão a sua plenitude no futuro, como já antes dissemos.

## Art. 8 — Se, dentre os frutos, a fé corresponde ao dom do intelecto.
O oitavo discute-se assim. – Parece que, dentre os frutos, a fé não corresponde ao dom do intelecto.

1. – Pois, o intelecto é fruto da fé, conforme a Escritura: Não crereis se não compreenderdes, segundo
uma lição diferente da que temos: Se o não crerdes não permanecereis. Logo, não é a fé fruto do
intelecto.

2. Demais. – O que está antes não pode ser fruto do que vem depois. Ora, é a fé anterior ao intelecto,
porque é o fundamento de todo o edifício espiritual, como já se disse. Logo, não é a fé fruto do
intelecto.

3. Demais. – Mais são os dons pertencentes ao intelecto que ao apetite. Ora, entre os frutos, só um, a
fé, é considerado como pertencente ao intelecto; ao passo que todos os outros pertencem ao apetite.
Logo, a fé não corresponde mais ao intelecto, do que à sabedoria, à ciência ou ao conselho.
Mas, em contrário, o fim de um ser é o seu fruto. Ora, o dom do intelecto ordena-se principalmente à
certeza da fé, considerada como um fruto. Pois, diz a Glosa a fé, que é um fruto, é a certeza do invisível.
Logo, dentre os frutos, a fé corresponde ao dom do intelecto.

SOLUÇÃO. – Como já dissemos, quando tratamos dos frutos, chamam-se frutos do Espírito Santo certos
efeitos últimos e deleitáveis que nos proveem da virtude desse Espírito.
Ora, o que é último e deleitável é, essencialmente, fim, objeto próprio da vontade. Por onde e
necessariamente, o último e deleitável, na vontade, é de certo modo, fruto de tudo o mais que pertence
às outras potências. Sendo pois assim, podemos distinguir duas espécies de frutos do dom ou da
virtude, que aperfeiçoa uma potência: um próprio da potência, outro, quase último, próprio da vontade.
E a esta luz, devemos dizer, que ao dom do intelecto corresponde, como fruto próprio, a fé, isto é, a
certeza da fé; e, como último fruto, a alegria, que pertence à vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O intelecto é fruto da fé, que é uma virtude. Ora, não é
assim considerada a fé, quando tomada como fruto; mas sim, como uma determinada certeza da fé, a
que chegamos pelo dom do intelecto.

RESPOSTA À SEGUNDA. – A fé não pode, universalmente, preceder ao intelecto; pois o homem não
poderia assentir, crendo, a certos artigos que lhe são propostos, sem, de certo modo, compreendê-los.
Mas a perfeição do intelecto resulta da fé, que é uma virtude; de cuja perfeição procede uma
determinada certeza da fé.

RESPOSTA À TERCEIRA. –O conhecimento prático não pode conter em si o seu próprio fruto, porque
não vale para si mesmo, mas para outro. Ao contrário, o conhecimento especulativo encerra em si
mesmo o seu fruto, a saber, a certeza daquilo a que se refere. Por onde, ao dom do conselho, que só
pertence ao conhecimento prático, não corresponde nenhum fruto próprio. Aos dons, porém, da
sabedoria, do intelecto e da ciência, que também podem pertencer ao conhecimento especulativo, só
corresponde um fruto, que é o da certeza, expressa pelo nome da fé. Vários são os frutos, porém,
considerados como pertencentes à parte apetitiva; porque, como já dissemos, a essência do fim, que
implica o nome de fruto, pertence mais à virtude apetitiva que à intelectiva.