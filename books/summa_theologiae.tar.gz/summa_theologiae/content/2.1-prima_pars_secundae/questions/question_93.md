# Questão 93: Da lei eterna.
Em seguida devemos tratar das leis, em particular. E primeiro, da lei eterna. Segundo, da lei natural.
Terceiro, da lei humana. Quarto, da lei antiga. Quinto, da lei nova, que é a lei do Evangelho. E quanto à
sexta lei, que é a do estímulo, basta o que já foi dito quando tratamos do pecado original.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a lei eterna é a razão suma existente em Deus.
(Supra, q. 91, a. 1).
O primeiro discute-se assim. — Parece que não é a lei eterna a razão suma existente em Deus.

1. — Pois, a lei eterna é uma só. Ora, as razões das coisas na mente divina são várias; assim, Agostinho
diz, que Deus fez todas as coisas com razões próprias. Logo, parece que a lei eterna não é o mesmo que
a razão existente na mente divina.

2. Demais. — É da natureza da lei ser promulgada verbalmente, como já se disse (q. 90, a. 4). Ora, em
Deus o Verbo é considerado pessoalmente, como se estabeleceu na Primeira Parte (q. 34, a. 1); ao passo
que a razão o é essencialmente. Logo, a lei eterna não é o mesmo que a razão divina.

3. Demais. — Agostinho diz: A lei, que é chamada verdade, aparece como estando acima da nossa
mente. Ora, a lei existente como superior à nossa mente é a lei eterna. Logo, a verdade é a lei eterna.
Mas a verdade e a razão não têm a mesma essência. Logo, a lei eterna não é o mesmo que a razão
suma.
Mas, em contrário, Agostinho diz: A lei eterna é a razão suma, a que sempre devemos obedecer.

SOLUÇÃO. — Assim como em todo artífice preexiste à razão do que ele faz, com a sua arte, assim
também, em todo governante é necessário preexista à razão da ordem daquilo que devem fazer os que
lhe estão sujeitos ao governo. E como a razão das coisas, que devem ser feitas pela arte, chama-se arte
ou exemplar das coisas artificiadas, assim a razão de quem governa os atos dos súbditos assume a
natureza de lei, salvo tudo quanto já foi dito a respeito da essência da lei (q. 90). Ora, Deus, com sua
sabedoria, é o criador da universidade das coisas, para as quais está como o artífice, para as coisas arti-
ficiadas, conforme na Primeira Parte foi estabelecido (q. 14, a. 8). Pois, também é o governador de todos
os atos e moções de cada criatura, segundo também se estabeleceu na Primeira Parte (q. 103, a. 5). Por
onde, assim como a razão da sabedoria divina tem, como criadora de todas as coisas, natureza de arte,
exemplar ou idéia; assim a razão dessa mesma sabedoria, que move todas as coisas para o fim devido,
tem natureza de lei. E sendo assim, a lei eterna não é mais que a razão da sabedoria divina, enquanto
diretiva de todos os atos e moções.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho se refere, no passo aduzido, às razões ideais,
que respeitam às naturezas próprias de cada coisa. Por isso há nelas uma certa distinção e pluralidade,
conforme as diversas relações com as coisas, como se estabeleceu na Primeira Parte (q. 15, a. 2). Porém
a lei é considerada como diretiva dos atos em relação ao bem comum, como já se disse (q. 90, a. 2). Ora,
coisas entre si diversas consideram-se como unificadas, quando se ordenam para algo de comum.
Portanto, a lei eterna é uma, ela que é a razão da referida ordem.

RESPOSTA À SEGUNDA. — Duas considerações podem ser feitas a propósito de qualquer palavra: sobre
a palavra mesma, e o que ela exprime. Ora, a palavra vocal é proferida pela boca humana; e por ela se
exprimem as coisas significadas pelas palavras humanas. E a mesma é a essência do verbo mental
humano, que não é senão um conceito da mente, pela qual o homem exprime mentalmente aquilo que
pensa. Por onde, em Deus, o Verbo, que é o conceito do intelecto paterno, significa uma pessoa; mas
tudo o que está na ciência do Pai, seja o que é essencial, ou pessoal, ou ainda as obras de Deus,
exprime-se por esse Verbo, como está claro em Agostinho. E entre outras expressões, por esse Verbo
também se exprime a lei eterna. Mas daqui não se segue que a lei eterna seja considerada como algo de
pessoal, em Deus. Pois ela é apropriada ao Filho, por causa da conveniência que a razão tem com o
Verbo.

RESPOSTA À TERCEIRA. — A razão do intelecto divino tem com as coisas uma relação diferente da que
com elas tem a do intelecto humano. Pois, o intelecto humano é medido pelas coisas, de modo que um
conceito humano não é verdadeiro em si mesmo, senão pela sua conformidade com as coisas. Porque
segundo uma coisa é ou não, a nossa opinião é verdadeira ou falsa. Ao contrário, o intelecto divino é a
medida das coisas; porque cada uma delas é verdadeira na medida em que imita o intelecto divino,
como na Primeira Parte se disse (q. 16, a. 1). E portanto, o intelecto divino é verdadeiro em si mesmo.
Por onde, a sua razão é a verdade mesma.

## Art. 2 — Se a lei eterna é conhecida de todos.
(Supra, q. 19, a. 4, ad 3; In Iob, cap. XI, lect. I).
O segundo discute-se assim. — Parece que a lei eterna não é conhecida de todos.

1. — Pois, como diz o Apóstolo (1 Co 2, 11), as coisas de Deus ninguém as conhece senão o Espírito de
Deus. Ora, a lei eterna é uma razão existente na mente divina. Logo, é desconhecida de todos, menos de
Deus.

2. Demais. — Como diz Agostinho, pela lei eterna é justo que todas as coisas sejam ordenadíssimas. Ora,
nem todos sabem como todas as coisas são ordenadissímas. Logo, nem todos conhecem a lei eterna.

3. Demais. — Agostinho diz: A lei eterna é a de que os homens não podem julgar. Ora, no dizer de
Aristóteles, cada qual julga bem aquilo que conhece. Logo, a lei eterna de nós não é conhecida.
Mas, em contrário, diz Agostinho: O conhecimento da lei eterna está impresso em nós.

SOLUÇÃO. — De dois modos pode um objeto ser conhecido: em si mesmo; e no seu efeito, onde se
encontra alguma semelhança dele. Assim, quem não vê o sol na sua substância conhece-o pela
irradiação. Por onde, deve-se dizer que a lei eterna ninguém pode conhecê-la como em si mesma é,
senão só os bem-aventurados, que vêem a Deus em essência. Mas toda criatura racional a conhece por
alguma maior ou menor irradiação dela. Pois, todo conhecimento da verdade é uma certa irradiação e
participação da lei eterna, que é a verdade imutável, como diz Agostinho. Ora, a verdade todos de certo
modo a conhecem, pelo menos quanto aos princípios comuns da lei natural. Quanto aos outros, uns
participam mais e outros, menos do conhecimento da verdade; e assim também conhecem mais ou
menos a lei eterna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As coisas de Deus não podem, em si mesmas, ser
conhecidas de nós, mas se manifestam pelos seus efeitos, conforme àquilo da Escritura (Rm 1, 20): As
coisas invisíveis de Deus se vêem, consideradas pelas obras que foram feitas.

RESPOSTA À SEGUNDA. — Embora cada um conheça a lei eterna segundo a sua capacidade, do modo
por que acabamos de dizer, ninguém contudo pode compreendê-la, porque ela não pode manifestar-se
totalmente pelos seus efeitos. Por onde, não é necessário, que quem conhece a lei eterna, da maneira
predita, conheça toda a ordem das coisas, pela qual todas elas são ordenadíssimas.

RESPOSTA À TERCEIRA. — O julgar das coisas pode ser entendido em duplo sentido. — De um modo,
como a faculdade cognitiva julga do seu objeto próprio, conforme àquilo da Escritura (Jó 12,
11): Porventura o ouvido não julga das palavras e o paladar de quem come não julga do sabor? E
conforme a este modo de julgar, o Filósofo diz que cada qual julga bem aquilo que conhece, i. é,
julgando se o que lhe é proposto é verdade. — De outro modo, como o superior julga do inferior, por
um juízo prático, i. é, se deve ser de tal maneira e não de tal outra. E assim, ninguém pode julgar da lei
eterna.

## Art. 3 — Se toda lei deriva da lei eterna.
O terceiro discute-se assim. — Parece que nem toda lei deriva da lei eterna.

1. — Pois, há uma lei do estímulo, como já se disse (q. 91, a. 6). Ora, não deriva da lei divina, que é
eterna, porque a ela pertence à prudência da carne, da qual diz o Apóstolo (Rm 8, 7), que não é sujeito
da lei eterna.

2. Demais. — Nada de iníquo pode proceder da lei eterna, pois, como já se disse (a. 2 arg. 2), pela lei
eterna é justo que todas as coisas sejam ordenadíssimas. Ora, certas leis são iníquas, conforme aquilo da
Escritura (Is 10, 1): Ai dos que estabelecem leis iníquas. Logo, nem toda lei procede da lei eterna.

3. Demais. — Agostinho diz: A lei escrita para governar o povo permite, retamente, muitas coisas que
são castigadas pela Providência Divina. Ora, a razão da Providência Divina é a lei eterna, como já se disse
(q. 93, a. 1). Logo, nem mesmo toda lei reta procede da lei eterna.
Mas, em contrário, diz a Escritura (Pr 8, 15): Por mim reinam os reis, e por mim decretam os legisladores
o que é justo. Ora, a razão da divina sabedoria é a lei eterna, como já se disse (a. 1). Logo, todas as leis
procedem da eterna.

SOLUÇÃO. — Como já dissemos (q. 90, a. 1, a. 2), a lei implica uma certa razão diretiva dos atos para um
fim. Ora, em todos os motores ordenados, é necessário que a força do motor segundo derive da força
do primeiro; pois aquele não move senão enquanto movido por este. E vemos o mesmo se passar com
todos os governantes: a razão do governo deriva do primeiro governante para os segundos; assim como
a razão do que deve, na cidade, ser feito, deriva do rei, por meio de um preceito, para os
administradores subalternos. E também nas artes, a razão dos atos artísticos deriva do mestre de obras
para os artífices inferiores, que obram manualmente. Por onde, sendo a lei eterna a razão do governo
no supremo governador, é necessário que todas as razões do governo, existentes nos governantes
inferiores, derivem dela. Ora, todas essas razões dos governantes inferiores são leis outras que não a lei
eterna. Portanto, todas as leis, na medida em que participam da razão reta, nessa mesma derivam da lei
eterna. E por isso Agostinho diz: Nada há de justo e legítimo, nas leis temporais, que os homens não
tivessem para si ido buscar na lei eterna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O estímulo tem no homem natureza da lei, enquanto
pena resultante da divina justiça, e sendo assim é manifesto que deriva da lei eterna. Mas enquanto
inclina para o pecado, contraria a lei de Deus e não tem natureza de lei, como do sobredito resulta (q.
91, a. 6).

RESPOSTA À SEGUNDA. — A lei humana tem natureza de lei, na medida em que é conforme a razão
reta; e assim é manifesto, que deriva da lei eterna. Mas, na medida em que se afasta da razão, é
considerada lei iníqua; e então, não tem natureza de lei, mas antes, de violência. E contudo, a própria lei
iníqua, na medida em que guarda uma semelhança com a lei, pela ordem do poder de quem a fez, nessa
mesma medida também deriva da lei eterna; pois, não há potestade que não venha de Deus, no dizer do
Apóstolo (Rm 13, 1).

RESPOSTA À TERCEIRA. — Diz-se que a lei humana permite certas coisas, não pelas aprovar, mas pelas
não poder dirigir. Pois, muitas coisas, das dirigidas pela lei divina, não o podem ser pela lei humana,
porque o domínio da lei superior é mais vasto que o da inferior. Por onde, o mesmo não intrometer-se a
lei humana naquilo que não pode dirigir, provém da ordem da lei eterna. O contrário se daria se
aprovasse o que a lei eterna reprova. Por isso daqui não se conclui, que não derive a lei humana da
eterna, mas sim, que não pode ter perfeita conformidade com ela.

## Art. 4 — Se o necessário e o eterno estão sujeitos à lei eterna.
O quarto discute-se assim. — Parece que o necessário e o eterno estão sujeitos à lei eterna.

1. — Pois, tudo o que é racional está sujeito à razão. Ora, a vontade divina, sendo justa, é racional. Logo,
está sujeita à razão. Ora, a lei eterna é a razão divina. Portanto, a vontade de Deus está sujeita à lei
eterna. E como a vontade de Deus é algo de eterno, resulta que também o eterno e o necessário estão
sujeitos à lei eterna.

2. Demais. — Tudo o que está sujeito ao rei, está sujeito à lei do mesmo. Ora, o Filho, no dizer da
Escritura (1 Co 15, 28-29), quando lhe tiver entregado o reino, estará sujeito a Deus e ao Padre. Logo, o
Filho, que é eterno, está sujeito à lei eterna.

3. Demais. — A lei eterna é a razão da Divina Providência. Ora, muitas coisas necessárias estão sujeitas a
ela, como as substâncias incorpóreas e os corpos celestes permanentes. Logo, o necessário também
está sujeito à lei eterna.
Mas, em contrário. — O necessário, sendo impossível sofrer mudança, não precisa de coibição. Ora, a lei
é imposta ao homem para coibi-lo do mal, como do sobredito resulta (q. 92, a. 2). Logo, o necessário
não está sujeito à lei.

SOLUÇÃO. — Como já dissemos (a. 1), a lei eterna é a razão do governo divino. Por onde, tudo o que
está sujeito ao governo divino o está também à lei eterna; e o que não está sujeito a esse governo, nem
à lei eterna o está. E esta distinção pode se fundar nas coisas que nos circundam. Assim, ao governo
humano está sujeito o que pode ser feito pelos homens; o que porém pertence à natureza humana,
como ter alma, mãos ou pés, não depende do governo humano. Por onde, à lei eterna estão sujeitas
todas as coisas criadas por Deus, quer contingentes, quer necessárias; não está sujeito porém a essa lei
o que pertence à natureza ou à essência divina, que constitui realmente a lei eterna mesma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vontade de Deus podemos considerá-la de dois
modos. — De um modo, em si mesma. E então, sendo a vontade de Deus a essência mesma dele, não
está sujeita ao governo divino, nem à lei eterna, com a qual se identifica. — De outro modo podemos
considerá-la em relação àquilo que Deus quer das criaturas, as quais estão sujeitas à lei eterna, por
terem a sua razão na sabedoria divina. E por isso dizemos, que a vontade de Deus é racional. Pois, do
contrário, em si mesma, deveria ser considerada, antes como a própria razão.

RESPOSTA À SEGUNDA. — O Filho não foi feito por Deus, mas é dele naturalmente gerado. Por isso, não
está sujeito à Providência Divina, nem à lei eterna; antes, por uma certa apropriação, ele mesmo é a lei
eterna, como claramente o diz Agostinho. E dizemos que está sujeito ao Pai, em virtude da natureza
humana, pela qual também dizemos que o Pai é maior que ele.
À TERCEIRA OBJEÇÃO CONCEDEMOS. — Por proceder do necessário criado.

RESPOSTA À QUARTA. — Como diz o Filósofo, certas coisas necessárias têm, a causa da sua
necessidade; e assim, a mesma impossibilidade de existirem de outro modo provém-lhes de outro ser; e
isso mesmo é uma certa e eficacíssima coibição. Pois, tudo o que é coibido, em geral, dizemos que o é,
na medida em que não pode agir diferentemente da disposição que tem.

## Art. 5 — Se os contingentes naturais estão sujeitos à lei eterna.
O quinto discute-se assim. — Parece que os contingentes naturais não estão sujeitos à lei eterna.

1. — Pois, a promulgação é da essência da lei, como já se disse (q. 90, a. 4). Ora, a promulgação não
pode ser feita senão para criaturas racionais, a que alguma coisa pode ser anunciada. Logo, só as
criaturas racionais estão sujeitas à lei eterna, e portanto não o estão os contingentes naturais.

2. Demais. — O que obedece à razão dela participa, de certo modo, como diz Aristóteles. Ora, a lei
eterna é a razão suma, como já se disse (a. 1). Logo, como os contingentes naturais não participam de
nenhum modo da razão, mas ao contrário, são irracionais, parece que não estão sujeitos à lei eterna.

3. Demais. — A lei eterna é eficacíssima. Ora os contingentes naturais são susceptíveis de deficiências.
Logo, não estão sujeitos à lei eterna.
Mas, em contrário, diz a Escritura (Pr 8, 29): Quando circunscrevia ao mar o seu termo, e punha lei às
águas para que não passassem os seus limites.

SOLUÇÃO. — O que se diz da lei humana não é o mesmo que o dito da lei eterna, que é a lei de Deus.
Pois, a lei humana se estende somente às criaturas racionais sujeitas ao homem. E a razão é que a lei é
diretiva dos atos próprios aos súbditos de um governo; por isso, ninguém, propriamente falando, impõe
lei aos próprios atos. Ora, tudo o que o homem faz, usando dos seres irracionais, que lhe estão sujeitos,
ele o faz por um ato próprio, que move tais seres. Pois, essas criaturas irracionais não agem por si
mesmas, mas são levadas por outras, como já se disse (q. 1, a. 2). Por onde, o homem não pode impor
lei aos seres irracionais, embora lhe estejam sujeitos. Mas o pode para os seres racionais, que lhe estão
sujeitos, imprimindo-lhes no espírito, por um preceito ou um anúncio qualquer, uma certa regra, que é
o princípio do agir.
Ora, assim como o homem, por um enunciado, imprime um princípio interior aos atos de quem lhe está
sujeito, assim também Deus imprime a toda a natureza os princípios dos atos próprios dela. E assim
sendo, dizemos que Deus põe preceito para toda a natureza, conforme a Escritura (Sl 148, 6): Preceito
pôs e não se quebrantará. E por esta mesma razão, todos os movimentos e ações de toda a natureza
estão sujeitos à lei eterna. Por onde, é de outro modo que as criaturas irracionais estão sujeitas à lei
eterna: enquanto movidas pela Divina Providência e não, pela inteligência do preceito divino, como as
criaturas racionais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A impressão ativa de um princípio intrínseco está para as
coisas naturais, assim como a promulgação da lei está para os homens. Porque a promulgação da lei
imprime nos homens um princípio diretivo dos seus atos, como já se disse.

RESPOSTA À SEGUNDA. — As criaturas irracionais não participam da razão humana, nem lhe obedecem;
participam porém, a modo de obediência, da razão divina. Pois, o poder da razão divina tem maior
extensão que o da razão humana. E assim como os membros do corpo humano movem-se pelo império
da razão, mas dela não participam, porque não têm nenhuma apreensão ordenada para a razão, assim
também as criaturas irracionais são movidas por Deus, sem por isso virem a ser racionais.

RESPOSTA À TERCEIRA. — As deficiências ocorrentes nos seres naturais, embora estejam fora da ordem
das causas particulares, não escapam contudo, à das causas universais. E principalmente não escapam à
ordem da causa primeira, que é Deus, a cuja Providência nada pode fugir, como dissemos na Primeira
Parte (q. 22, a. 2). E sendo a lei eterna a razão da Divina Providência, como já dissemos (a. 1), as
deficiências dos seres naturais estão sujeitas à lei eterna.

## Art. 6 — Se todas as coisas humanas estão sujeitas à lei eterna.
O sexto discute-se assim. — Parece que nem todas as coisas humanas estão sujeitas à lei eterna.

1. — Pois, diz o Apóstolo (Gl 5, 18): Se vós sois guiados pelo espírito, não estais, debaixo da lei. Ora, os
homens justos, filhos de Deus por adoção, são levados pelo espírito de Deus, conforme àquilo da
Escritura (Rm 8, 14):Os que são levados pelo espírito de Deus, estes são filhos de Deus. Logo, nem todos
os homens estão sujeitos à lei eterna.

2. Demais. — O Apóstolo diz (Rm 8, 7): A sabedoria da carne é inimiga de Deus, pois não é sujeita à lei
de Deus. Ora, há muitos homens em quem domina a sabedoria da carne. Logo, à lei eterna, que é a lei
de Deus, não estão sujeitos todos os homens.

3. Demais. — Agostinho diz: Pela lei eterna é que os maus merecem a miséria e os bons, a vida feliz. Ora,
os homens já bem-aventurados ou condenados não estão mais em estado de merecer. Logo, não estão
sujeitos à lei eterna.
Mas, em contrário, Agostinho: De nenhum modo, qualquer ser pode fugir às leis do sumo Criador e
Ordenador, que estabelece a paz do universo.

SOLUÇÃO. — Duplo é o modo por que um ser está sujeito à lei eterna, como do sobredito resulta (a. 5).
De um modo, enquanto pelo conhecimento participa da lei eterna; de outro, pela ação e pela
passividade, participando dela como de princípio motivo interno. Ora, é deste segundo modo que à lei
eterna estão sujeitas as criaturas irracionais, como já dissemos (a. 5). Mas a natureza racional tendo,
além do que lhe é comum com todas as criaturas, algo de próprio, como racional que é, está sujeita à lei
eterna de um e de outro modo. Pois, de um lado, tem de certa maneira a noção da lei eterna, segundo
já dissemos (a. 2); e de outro, em toda criatura racional existe uma inclinação natural para o que está de
acordo com a lei eterna, pois, é-nos natural possuir as virtudes, como diz Aristóteles.
Ambos esses modos, porém, são nos maus, imperfeitos, e de certa maneira, corruptos. Pois, além de
terem a inclinação natural para a virtude depravada pelos hábitos viciosos, o próprio conhecimento
natural do bem lhes está entenebrecido pelas paixões e pelos hábitos pecaminosos. Ao contrário, nos
bons um e outro modo existe da maneira mais perfeita, porque ao conhecimento natural do bem se lhes
acrescenta o da fé e da sapiência; e à inclinação natural para o bem, o motivo interior da graça e da
virtude.
Por onde, os bons estão perfeitamente sujeitos à lei eterna, por agirem sempre de acordo com ela. Os
maus, por seu lado também lhe estão sujeitos, embora imperfeitamente, pelas suas ações, pela
conhecerem imperfeitamente, e deste mesmo modo se inclinarem ao bem. Mas o que lhes falta na ação
é-lhes suprido pela paixão, pois, na medida em que deixaram de fazer o que exigia a lei eterna, nessa
mesma hão de sofrer o que ela deles demanda. Donde o dizer Agostinho: Penso que os justos agem
sujeitos à lei eterna. E, noutra obra: Deus, por justa comiseração das almas que o abandonam, soube
ordenar com leis convenientíssimas as partes inferiores da sua criação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lugar citado do Apóstolo pode ser entendido em duplo
sentido. Num, aquele que está sujeito à lei está, contra a sua vontade, sujeito à obrigação que ela
impõe, como se suportasse um peso. Donde o dizer a Glosa: Está sujeito à lei quem se abstém das más
obras, pelo temor do suplício, que a lei comina, e não, pelo amor da justiça. E deste modo, os homens
espirituais não estão sujeitos à lei porque, pela caridade, que o Espírito Santo lhes infunde nos corações,
cumprem voluntariamente a exigência legal. — Noutro, o lugar citado pode ser entendido como
querendo significar, que as obras do homem levado pelo Espírito Santo são consideradas, mais, como do
Espírito Santo, que do homem mesmo. Por onde, o Espírito Santo, não estando sujeito à lei, como não o
está o Filho, segundo já foi dito (a. 4 ad 2), segue-se que as obras em questão, enquanto do Espírito
Santo, não estão sob o império da lei. O que está conforme ao dito do Apóstolo (2 Cor 3, 17): Onde há o
Espírito do Senhor aí há liberdade.

RESPOSTA À SEGUNDA. — A sabedoria da carne, não pode estar sujeita à lei de Deus, no concernente à
ação, pois inclina a ações contrárias à lei divina. Mas lhe está sujeita, no concernente à paixão, porque
merece sofrer uma pena segundo a lei da divina justiça. Contudo, em nenhum homem a sabedoria da
carne domina a ponto de corromper totalmente o bem da natureza. Por isso, permanece no homem a
inclinação para agir de conformidade com a lei eterna. Pois, como já ficou estabelecido (q. 85, a. 2), o
pecado não priva totalmente do bem da natureza.

RESPOSTA À TERCEIRA. — O que conserva um ser no seu fim, também o move para ele. Assim, o corpo
pesado a gravidade falo repousar no lugar inferior, e também o move para esse lugar. Por onde,
devemos dizer que, os que, pela lei eterna, merecem a beatitude ou a miséria, também são, pela mesma
lei, conservados naquela ou nesta. E assim sendo, os bem-aventurados e os condenados estão sujeitos à
lei eterna.