# Questão 36: Das causas da tristeza.
Em segundo devemos tratar das causas da tristeza.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se o bem perdido é, mais que o mal anexo, causa da dor.
O primeiro discute-se assim. — Parece que o bem perdido é, mais que o mal anexo, causa da dor.

1. — Pois, diz Agostinho, que sofremos dor com a perda dos bens temporais. Logo, pela mesma razão,
toda dor resulta da perda de algum bem.

2. Demais — Como já se disse, a dor que contraria o prazer tem o mesmo objeto que este. Ora, este tem
por objeto o bem, como já foi dito. Logo, a dor também se refere principalmente ao bem perdido.

3. Demais — Segundo Agostinho, o amor é causa da tristeza bem como dos outros afetos da alma. Ora,
o objeto do amor é o bem. Logo, a dor ou tristeza, recai antes sobre o bem perdido, que sobre o mal
anexo.
Mas, em contrário, diz Damasceno, que o mal esperado provoca o temor; o presente porém, a tristeza.

SOLUÇÃO. — Se as privações comportassem, relativamente à apreensão da alma, como se comportam
com a realidade, a questão presente podia ser considerada como carecente de toda importância. Pois, o
mal, como já estabelecemos na primeira parte, é a privação do bem. Ora, a privação, nos seres da
natureza, não sendo senão a privação do hábito oposto, o mesmo é contristar-se com o bem perdido
que com o mal presente. A tristeza porém é um movimento do apetite consecutivo à apreensão. Ora,
nesta, a privação corresponde a uma certa noção entitativa, chamando-se por isso ser de razão. Por
onde, o mal, sendo privação, comporta-se como contrário. E portanto, há diferença entre o movimento
apetitivo recair principalmente sobre o mal anexo ou sobre o bem perdido.
Ora, o movimento do apetite animal estando para as operações da alma, como o movimento natural
para os seres naturais, podemos descobrir a verdade refletindo sobre os movimentos naturais. Se pois,
levarmos em conta, nestes, a aproximação e o afastamento, aquela, em si mesma, respeita o
conveniente à natureza; e este, o que lhe é contrário. Assim, o grave, em si mesmo, afasta-se do lugar
superior e aproxima-se naturalmente do inferior. Se, porém levarmos em consideração a gravidade,
causa desses dois movimentos, esta, em si mesma, faz inclinar-se para o lugar inferior, antes de deslocar
do superior, do qual se afasta para tender para baixo. Por onde, a tristeza, comportando-se, nos
movimentos apetitivos, a modo de afastamento e de aproximação, e o prazer, a modo de prossecução
ou afastamento, assim como o prazer respeita primeiramente o bem alcançado, como objeto próprio,
assim a tristeza respeita o mal anexo; mas, a causa do prazer e da tristeza que é o amor, respeita, antes
do mal, o bem. E portanto, do modo pelo qual o objeto é a causa da paixão, o mal anexo é, mais
propriamente que o bem perdido, a causa da tristeza ou da dor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A perda mesma do bem é apreendida sob a noção de
mal, assim como o livrar-se do mal o é sob a de bem. E por isso Agostinho diz que a dor provém da
perda dos bens temporais.

RESPOSTA À SEGUNDA. — O prazer e a dor, que lhe é contrária, respeitam o mesmo objeto, mas com
noções contrárias. Pois, ao passo que o prazer provém do bem presente, a tristeza provém do ausente.
Ora, como um contrário implica a privação do outro, segundo está claro em Aristóteles, conclui-se que a
tristeza, relativa a um contrário, respeita de certo modo o mesmo objeto, mas sob noção diversa.

RESPOSTA À TERCEIRA. — Quando de uma causa provém muitos movimentos, não é necessário que
todos digam respeito principalmente àquilo que a causa principalmente respeita, mas só o primeiro. E
cada um dos outros respeita principalmente o que lhe é conveniente segundo a própria noção.

## Art. 2 — Se a concupiscência é causa da dor ou tristeza.
O segundo discute-se assim. — Parece que a concupiscência não é causa da dor ou tristeza.

1. — Pois, a tristeza em si mesma diz respeito ao mal, como já demonstramos. Ora, a concupiscência é
um movimento do apetite para o bem. O movimento porém, que tende para um contrário, não pode ser
causa do que respeita ao outro contrário. Logo, a concupiscência não é causa da dor.

2. Demais — A dor, segundo Damasceno, refere-se ao presente; a concupiscência porém, ao futuro.
Logo, esta não é causa da dor.

3. Demais — O deleitável em si mesmo não é causa da dor. Ora, a concupiscência é em si mesma
deleitável, como diz o Filósofo. Logo, não é causa da dor ou tristeza.
Mas, em contrário, diz Agostinho: A ignorância do que devemos fazer e a concupiscência do que é
nocivo são acompanhadas sempre do erro e da dor. Ora, a ignorância é causa do erro. Logo, a
concupiscência o é da dor.

SOLUÇÃO. — A tristeza é um movimento do apetite animal. Ora, o movimento apetitivo tem, como já
dissemos, semelhança com o natural. E disto podemos assinalar dupla causa; uma, a modo de fim;
outra, como aquela donde procede o princípio do movimento. Assim, a causa, quase final, da queda de
um corpo pesado, é o lugar inferior; porém o princípio do movimento é a inclinação natural, procedente
da gravidade. Ora, a causa, quase final, do movimento apetitivo é o seu objeto. E por isso dissemos
antes, que a causa da dor ou tristeza é o mal anexo. E por outro lado, a causa, que é como aquilo donde
procede o princípio de tal movimento, é a inclinação natural do apetite, que se inclina, primeiro, ao bem
e, consecutivamente a repudiar o mal contrário. Por onde, o princípio primeiro deste movimento
apetitivo é o amor, que é a inclinação primeira do apetite para a consecução do bem; e o segundo
princípio é o ódio, que é a inclinação primeira do apetite para evitar o mal.
Como porém a concupiscência ou cobiça é o primeiro efeito do amor, com a qual nos deleitamos,
conforme já dissemos, em máximo grau, por isso, Agostinho freqüentemente toma pelo amor a cobiça
ou concupiscência, como também já dissemos; e deste modo a considera como a causa universal da dor.
Mas, a concupiscência mesma, considerada na sua noção própria, é às vezes causa da dor. Pois tudo o
que impede um movimento de chegar ao seu termo lhe é contrário. Ora, o contrário ao movimento do
apetite é causa de tristeza. E por conseqüente, a concupiscência vem a ser causa de tristeza, na medida
em que nos contristamos com a tardança ou a total eliminação do bem desejado. Não pode porém ser a
causa universal da dor, porque nos entristecemos mais com a perda dos bens presentes, com os quais já
nos deleitamos, que com a dos futuros que desejamos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A inclinação do apetite para a consecução do bem é a
causa da inclinação do mesmo para evitar o mal, como já dissemos. E daqui resulta que os movimentos
do apetite, que respeitam o bem, são considerados causa dos que dizem respeito ao mal.

RESPOSTA À SEGUNDA. — O desejado, embora seja realmente futuro, já é contudo e de certo modo
presente, enquanto esperado. — Ou podemos dizer que, embora o bem desejado seja futuro, há
contudo atualmente um impedimento, que causa a dor.

RESPOSTA À TERCEIRA. — A concupiscência é deleitável, enquanto permanece a esperança de alcançar
o desejado; mas perdida esta, por um impedimento superveniente, a concupiscência causa a dor.

## Art. 3 — Se o desejo de unidade é causa da dor.
O terceiro discute-se assim. — Parece que o desejo da unidade não é causa da dor.

1. — Pois, como diz o Filósofo, a doutrina de acordo com a qual a repleção é causa do prazer e a divisão,
da tristeza, parece fundar-se nos prazeres e tristezas relativos à comida. Ora, nem todo prazer e nem
toda tristeza são dessa espécie. Logo, o desejo da unidade não é causa universal da dor, pois a repleção
respeita à unidade e a divisão é causa da multiplicidade.

2. Demais — Toda separação se opõe à unidade. Se portanto a dor fosse causada pelo desejo da
unidade, nenhuma separação seria deleitável. Ora, isto é falso evidentemente relativamente à
separação de todas as coisas supérfluas.

3. Demais — Pela mesma razão desejamos a junção com o bem e a remoção do mal. Ora, assim como
aquela diz respeito à unidade, sendo uma espécie de união, assim, esta é contrária à unidade. Logo, o
desejo da unidade não deve, mais que o da separação, ser considerado causa da dor.
Mas, em contrário, diz Agostinho: pela dor que os animais sentem, se vê claramente, quanto no
dirigirem e animarem os seus corpos, são almas que desejam a unidade. Pois que é a dor senão um
certo sentido a que repugna a divisão ou a corrupção?

SOLUÇÃO. — Do modo pelo qual a concupiscência ou o desejo do bem é causa da dor, desse mesmo
também deve ser considerado tal o desejo da unidade ou o amor. Pois, o bem de um ser consiste em
certa unidade, enquanto que cada ser tem unido consigo aquilo em que consiste a sua perfeição; e por
isso os Platônicos ensinaram que, como o bem, a unidade é um princípio. Por onde, cada ser deseja
naturalmente a unidade, assim como a bondade. E por isto, sendo o amor ou desejo do bem causa da
dor, também o será o amor ou desejo da unidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nem toda unidade aperfeiçoa a noção do bem, mas só
aquela da qual depende o ser perfeito de um ente. E por isto não é o desejo de qualquer unidade a
causa da dor ou tristeza, como certos opinaram, opinião que o Filósofo refuta dizendo que certas
repleções não são deleitáveis; assim os repletos de alimentos não se deleitam em os tomar. E tal
repleção ou união antes repugnaria que constituiria a perfeição do ser. Por onde, a dor não é causada
pelo desejo de qualquer unidade, mas daquela em que consiste a perfeição da natureza.

RESPOSTA À TERCEIRA. — A separação pode ser deleitável, quer na medida em que é removido o
contrário à perfeição do ser, ou, na medida em que a separação vai junta com alguma união, p. ex., a do
sensível com o sentido.

RESPOSTA À TERCEIRA. — Desejamos a separação das coisas nocivas e corruptoras, na medida em que
nos privam da unidade devida. Por isso, o desejo de tal separação não é a causa primeira da dor, mas
antes o é o desejo da unidade.

## Art. 4 — Se um poder maior deve ser considerado como causa da dor.
O quarto discute-se assim. — Parece que um poder maior não deve ser considerado causa da dor.

1. — Pois, o que está no poder do agente ainda não é presente, mas futuro. Ora, a dor se refere ao mal
presente. Logo, um poder maior não é causa da dor.

2. Demais — O mal causado é causa da dor. Ora, ele pode ser causado mesmo por um poder menor.
Logo, não deve o poder maior ser considerado causa da dor.

3. Demais — As causas dos movimentos apetitivos são as inclinações internas da alma. Ora, um poder
maior é algo de externo. Logo, não deve ser considerado causa da dor.
Mas, em contrário, diz Agostinho: a vontade que resiste a um poder maior causa a dor na alma, no
corpo causa a dor o sentido, que resiste a um corpo mais forte.

SOLUÇÃO. — Como já dissemos, o mal anexo é, ao modo de objeto, a causa da dor ou tristeza. Ora, a
causa da conjunção do mal deve ser considerada causa da dor ou tristeza. Porém, é de manifesto contra
a inclinação do apetite que o mal seja presencialmente inerente. Pois, o que vai contra a inclinação de
um ser nunca lhe advém senão pela ação de outro mais forte. E por isso Agostinho considera o poder
maior como causa da dor.
Deve-se porém saber que, se o poder mais forte influi a ponto de transformar a inclinação contrário em
própria, não haverá já nenhuma repugnância ou violência; assim, quando um agente mais forte,
corrompendo um corpo pesado, priva-lhe da inclinação de tender para baixo; e então, ser levado para
cima não lhe é violento, mas natural. Se pois um poder maior influir a ponto de virar a inclinação à
vontade ou ao apetite sensitivo, dele não resulta dor ou tristeza, que só resultará quando permanecer a
inclinação contrária do apetite. E por isso Agostinho diz que a vontade resistente a um poder mais forte
causa a dor; pois se não resistisse mas cedesse, consentindo, não resultaria a dor, mas o prazer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um poder maior causa a dor, não como agente
potencial, mas como atual, i. é, enquanto causa a junção com o mal corruptor.

RESPOSTA À SEGUNDA. — Nada impede um poder, que não é maior, absolutamente, sê-lo
relativamente, e nesta última acepção pode ser nocivo. Se porém não for maior de nenhum modo, de
nenhum modo poderá prejudicar, e portanto não poderá produzir nenhuma causa de dor.

RESPOSTA À TERCEIRA. — Os agentes exteriores podem ser causas dos movimentos apetitivos,
enquanto causam a presença do objeto. E deste modo o poder maior é considerado causa de dor.