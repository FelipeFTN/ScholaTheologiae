# Questão 60: Da distinção das virtudes morais entre si.
Em seguida devemos tratar da distinção das virtudes morais entre si. E sobre esta questão cinco artigos
se discutem:

## Art. 1 — Se há uma só virtude moral.
(III Sent., dist. XXXIII, q. 1, a. qª 1).
O primeiro discute-se assim. — Parece que há só uma virtude moral.

1. — Pois, assim como a direção dos atos morais pertence à razão, sujeito das virtudes intelectuais,
assim a inclinação pertence à virtude apetitiva, sujeito das virtudes morais. Ora, é uma só a prudência,
virtude intelectual diretora de todos os atos morais. Logo, também é uma só a virtude moral, que
imprime a inclinação em todos os atos morais.

2. Demais. — Os hábitos não se distinguem pelos objetos materiais, mas pelas razões formais dos
objetos. Ora, a razão formal do bem, a que se ordena a virtude moral, a saber, o modo da razão, é uma
só. Logo, é uma só a virtude moral.

3. Demais. — Os atos morais se especificam pelo fim, como já dissemos. Ora, o fim comum de todas as
virtudes morais é um só, a saber, a felicidade, enquanto os fins próprios e próximos são infinitos. Ora,
não sendo as virtudes morais infinitas, conclui-se que é uma só a virtude moral.
Mas, em contrário, um mesmo hábito não pode pertencer a diversas potências, como já se disse. Ora, o
sujeito das virtudes morais é a parte apetitiva da alma, que se divide em várias potências, como já se
disse na Primeira Parte. Logo, não pode haver uma só virtude moral.

SOLUÇÃO. — Como já dissemos, as virtudes morais são certos hábitos da parte apetitiva. Ora, estes
diferem especificamente conforme as diferenças especiais dos objetos, conforme estabelecemos. Ora,
espécie do objeto desejável, como a de qualquer coisa, depende da forma específica, procedente do
agente.
Devemos porém considerar, que a matéria do paciente tem dupla relação com o agente. Às vezes
recebe a forma do agente, essencialmente, tal como existe no agente; e isso se dá com todos os agentes
unívocos. E portanto, é necessário que, sendo o agente especificamente uno, a matéria receba também
forma especificamente una; assim, o fogo não gera, univocamente, senão o que é de espécie ígnea.
Outras vezes, porém, a matéria recebe a forma do agente, não essencialmente, tal como ela nele existe,
e é o caso dos geradores não unívocos; assim, o animal é gerado pelo sol. E então as formas recebidas
na matéria, provenientes do mesmo agente, não são da mesma espécie, mas se diversificam conforme a
matéria está diversamente proporcionada a receber o influxo do agente. Assim, vemos que a mesma
ação do sol gera, por putrefação, animais de diversas espécies, segundo a proporção diversa da matéria.
Mas, como é manifesto, na ordem moral a razão é que ordena e move, sendo a potência apetitiva a
ordenada e movida. Ora, o apetite não respeita, quase univocamente, a impressão da razão, por não ser
racional por essência, mas por participação, como se disse. Por onde, o desejável, conforme a moção
racional, tem tantas espécies diversas, quantas as relações diversas que mantém com a razão. Donde se
segue que, longe de constituírem uma só virtude, as virtudes morais são especificamente diversas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O objeto da razão é a verdade. Ora, todos os atos
morais, sendo de existência contingente, manifestam a mesma essência da verdade. Portanto, há neles
só uma virtude dirigente, que é a prudência. O objeto da potência apetitiva porém é o bem desejado,
cuja essência difere conforme a relação diversa mantém com a razão dirigente.

RESPOSTA À SEGUNDA. — As formalidades em questão são do mesmo gênero por causa da unidade do
agente; mas, se diversificam especificamente, por causa das relações diversas dos pacientes, como
acima dissemos.

RESPOSTA À TERCEIRA. — Os atos morais não se especificam pelo fim último, mas pelos fins próximos;
e estes, embora numericamente infinitos, não o são contudo especificamente.

## Art. 2 — Se as virtudes morais se distinguem entre si por serem umas relativas às obras e outras, às paixões.
(III Ethic., lect. VIII).
O segundo discute-se assim. — Parece que as virtudes morais não se distinguem entre si por serem,
umas, relativas às obras e outras, às paixões.

1. — Pois, como diz o Filósofo, a virtude moral versa sobre o prazer e a tristeza e obra o que é ótimo.
Ora, o prazer e a tristeza são paixões, como já se disse. Logo, a mesma virtude, que versa sobre as
paixões, versa também, como operativa, sobre as obras.

2. Demais. — As paixões, sendo princípios das obras externas, as virtudes que as retificam, hão-de,
conseqüente e necessariamente, retificar também as obras. Logo, as mesmas virtudes morais versam
sobre as paixões e sobre as obras.

3. Demais. — O apetite sensitivo é movido, bem ou mal, a todas as obras exteriores. Ora, estes
movimentos são paixões. Logo, as mesmas virtudes, que versam sobre as obras versam também sobre
as paixões.
Mas, em contrário, o Filósofo diz que a justiça versa sobre as obras; e por outro lado, a temperança, a
fortaleza e a mansidão, sobre certas paixões.

SOLUÇÃO. — A obra e a paixão podem se relacionar de dois modos com a virtude. Primeiro, como efeito
e então toda virtude moral produz certas obras boas, e uma certa deleitação ou tristeza, que são
paixões, como já dissemos. — Em segundo lugar, a obra pode relacionar-se com a virtude moral, como a
matéria sobre a qual versa. E então, das virtudes morais, umas versam sobre as obras e outras, sobre as
paixões.
E a razão disto está em o bem e o mal de certas obras nelas mesmas se fundarem, como quer que o
homem seja afetado por elas; i. é, o bem e o mal delas depende da relação de medida com outra coisa.
Assim sendo, é necessário haver uma virtude diretiva das obras, em si mesmas; tal é o caso da compra e
venda, e atos semelhantes, nos quais se leva em conta a relação de débito ou de não-débito para com
outrem. E por isso a justiça e as suas partes dizem respeito propriamente às obras, como sua matéria
adequada. — O bem e o mal de outras porém se fundam só na relação de medida com o sujeito delas. E
por isso neste caso é necessário levar em conta o modo bom ou mau por que este é afetado; e por
conseqüência necessária, as virtudes, relativas a essas obras versam principalmente sobre os afetos
internos chamados paixões da alma; e isso se dá com a temperança, a fortaleza e virtudes semelhantes.
Ora, pode acontecer que, nas obras relativas a outrem, seja posposto o bem da virtude pela paixão
desordenada da alma. E então, desaparecida a relação de medida da obra exterior, há de desvanecer-se
a justiça; e a desaparição corrompida da relação de medida das paixões interiores acarretará a
desaparição de alguma outra virtude. Assim, quem levado da ira, fere indebitamente outrem, lesa ao
mesmo tempo a justiça; ao passo que a ira imoderada elimina a mansidão. E o mesmo se dá nos casos
semelhantes.
E daqui se deduzem as RESPOSTAS ÀS OBJEÇÕES. — Pois, a primeira objeção se funda na obra
enquanto efeito da virtude. — As outras duas se fundam em que o ato e a paixão concorrem para o
mesmo fim; mas, em certos casos, a virtude versa principalmente sobre a obra — e, em outros, sobre a
paixão, pela razão já exposta.

## Art. 3 — Se uma só virtude é a que versa sobre as obras.
O terceiro discute-se assim. — Parece que só uma virtude moral é a que versa sobre as obras.

1. — Pois, a retidão de todos os atos externos pertence à justiça. Ora, esta é uma virtude. Logo, só há
uma virtude que diz respeito a elas.

2. Demais. — Há uma diferença máxima entre as obras ordenadas ao bem individual e as ordenadas ao
bem comum. Mas esta diferença não diversifica as virtudes morais; pois, como diz o Filósofo, a justiça
legal, que ordena os nossos atos para o bem comum, não difere da que os ordena para o nosso bem
individual, senão por uma diferença de razão. Logo, a diversidade das obras não causa a das virtudes
morais.

3. Demais. — Se a obras diversas se referissem virtudes morais diversas, seria necessário que tal fosse a
diversidade das virtudes morais qual a das obras. Ora, isto é claramente falso, pois à justiça pertence
estabelecer a retidão dos diversos gêneros são só das trocas, como das distribuições, conforme se vê em
Aristóteles. Logo, a obras diversas não correspondem virtudes diversas.
Mas, em contrário, a religião é uma virtude diferente da piedade; contudo, uma e outra versa sobre
determinados atos.

SOLUÇÃO. — Todas as virtudes morais, que versam sobre as obras, convêm numa noção geral de
justiça, que se funda no devido a outrem; distinguem-se porém por diversas razões especiais. E isto
porque a ordem racional dos atos externos se funda, como já dissemos, não na relação com o afeto
humano, mas na conveniência da causa consigo mesma, da qual deduzimos a idéia do devido, que funda
a noção de justiça, a qual exige paguemos o débito. E portanto, todas as virtudes, como ela, que versam
sobre as obras, participam de certo modo da justiça. Mas a noção de débito não é a mesma em todos os
casos. Assim, umas vezes devemos ao nosso igual; outras, ao superior; outras, a um inferior; umas
vezes, em virtude de um contrato, outras, de uma promessa ou por um benefício recebido. Ora, a estas
idéias diversas de débito correspondem virtudes diversas; assim, pela religião damos a Deus o que lhe é
devido; a piedade nos manda pagar o débito aos pais ou à pátria; o agradecimento, aos benfeitores e
assim por diante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A justiça propriamente dita é uma virtude especial
fundada em a noção perfeita de débito, susceptível de ser satisfeito por equivalência. Mas também se
chama justiça, em sentido mais amplo, a virtude que exige a satisfação de qualquer débito. E nesta
última acepção ela não é uma virtude especial.

RESPOSTA À SEGUNDA. — A justiça, que visa o bem comum, é uma virtude diferente da ordenada ao
bem privado de alguém; e por isso o direito comum se distingue do direito privado, e Túlio admite uma
virtude especial, a piedade, ordenada ao bem da pátria. Ora, a justiça, que ordena o homem para o bem
comum, tem um império geral, pois ordena todos os atos das virtudes ao devido fim, que é o bem
comum. Mas também a virtude se chama justiça, que é ordenada pela justiça, no primeiro sentido. Por
onde, a virtude só racionalmente difere da justiça legal, assim como só racionalmente difere a virtude,
que obra por si mesma, da que o faz por império de outra.

RESPOSTA À TERCEIRA. — Todas as obras pertencentes à justiça especial supõem a mesma noção de
débito. E portanto, constituem a mesma virtude da justiça, principalmente quanto às trocas. Mas talvez,
a justiça distributiva é de espécie diferente da comutativa, questão esta de que mais adiante se tratará.

## Art. 4 — Se a paixões diversas correspondem virtudes morais diversas.
O quarto discute-se assim. — Parece que a paixões diversas não correspondem virtudes morais
diversas.

1. — Os objetos de um mesmo hábito convêm no princípio e no fim, como se vê sobretudo nas ciências.
Ora, todas as paixões têm um mesmo princípio, que é o amor; e todas terminam num mesmo fim, que é
o prazer ou a pena, como já vimos. Logo, é só uma a virtude moral correspondente a todas as paixões.

2. Demais. — Se a paixões diversas se referissem virtudes morais diversas, estas seriam tantas quantas
aquelas. Ora, isto é falso evidentemente; pois, a mesma é a virtude moral que versa sobre paixões
opostas; assim, a fortaleza versa sobre o temor e a audácia; a temperança, sobre o prazer e a dor. Logo,
não é necessário que as paixões diversas correspondam virtudes morais diversas.

3. Demais. — O amor, a concupiscência e o prazer são paixões especificamente diferentes, como já se
estabeleceu. Ora, só a temperança é a virtude moral que lhes diz respeito a todas. Logo, a paixões
diversas não correspondem virtudes morais diversas.
Mas, em contrário, a fortaleza é relativa ao temor e à audácia; a temperança, à concupiscência; a
mansidão, à ira, como se disse.

SOLUÇÃO. — Não se pode dizer que uma só virtude moral corresponda a todas as paixões. Pois, estas
pertencem a potências diversas: umas, ao irascível, outras, ao concupiscível, como já dissemos.
Nem todas as diversidades das paixões bastam, necessariamente, a diversificar as virtudes morais. —
Primeiro, porque certas paixões se opõem por contrariedade; assim, a alegria e a tristeza, o temor e a
audácia, e outras. Ora, a essas paixões assim opostas corresponde, necessariamente, uma mesma
virtude. Pois, a virtude moral, consistindo numa certa mediania, é pela mesma razão que se estabelece
o meio termo entre paixões contrárias, assim como, em a natureza, os contrários, como o branco e o
preto, têm o mesmo meio termo. — Segundo, porque há diversas paixões repugnantes à razão, do
mesmo modo, i. é, impelindo ao que a contraria, ou retraindo do que ordena. E portanto, as diversas
paixões do concupiscível não pertencem a virtudes morais diversas. Pois os movimentos delas se
seguem uns aos outros segundo uma certa ordem, como ordenados ao mesmo fim, que é a busca do
bem ou a fuga do mal. Assim, do amor procede a concupiscência, e esta nos leva ao prazer. E o mesmo
se dá nos casos opostos, pois do ódio resulta a fuga ou a abominação, que conduz à dor. As paixões do
irascível, pelo contrário, não pertencem a uma mesma ordem, mas se ordenam a termos diversos.
Assim, a audácia e o temor ordenam-se a algum perigo grave; a esperança e o desespero, a um bem
árduo; a ira, enfim, a superar um contrário nocivo. E portanto, a estas paixões ordenam-se virtudes
diversas; assim, a temperança se ordena às paixões do concupiscível; a fortaleza, ao temor e à audácia; a
magnanimidade, à esperança e ao desespero; a mansidão, à ira.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todas as paixões convêm num princípio e num fim
comum; não porém num princípio ou fim próprio. Por onde, a objeção se baseia no que não basta à
unidade da virtude moral.

RESPOSTA À SEGUNDA. — Assim, como nos fenômenos naturais, por um mesmo princípio se afastam
de um princípio e se achegam a outro; e, na ordem racional, os contrários têm o mesmo fundamento,
assim também a paixões contrárias se refere uma mesma virtude moral, que, a modo da natureza,
concorda com a razão.

RESPOSTA À TERCEIRA. — As três paixões referidas se ordenam ao mesmo objeto, por uma certa
ordem, como já dissemos. E portanto, pertencem à mesma virtude moral.

## Art. 5 — Se as virtudes morais se distinguem pelos objetos das paixões.
O quinto discute-se assim. — Parece que as virtudes morais não se distinguem pelos objetos das
paixões.

1. — Pois, os objetos das paixões são como os das operações. Ora, as virtudes morais, que versam sobre
as operações não se distinguem pelos objetos destas; assim, à mesma virtude da justiça pertence
vender e comprar uma casa ou um cavalo. Logo, nem as virtudes morais, que versam sobre as paixões,
se diversificam pelos objetos destas.

2. Demais. — As paixões são atos ou movimentos do apetite sensitivo. Ora, a diversidade dos hábitos é
maior que a dos atos. Logo, objetos diversos, que não diversificam as espécies de paixões, também não
diversificarão as das virtudes morais; de modo que, só urna virtude moral versa sobre todos os objetos
deleitáveis, e assim com os demais objetos.

3. Demais. — O mais e o menos não diversificam as espécies. Ora, os diversos objetos deleitáveis não
diferem senão pelo mais e pelo menos. Logo, todos pertencem à mesma espécies de virtude. E pela
mesma razão, todos os que nos causam terror e assim por diante. Logo, as virtudes morais não se
distinguem pelos objetos das paixões.

4. Demais. — A virtude tanto obra o bem como impede o mal. Ora, são várias as virtudes que versam
sobre o desejo do bem; assim, a temperança, sobre o desejo dos deleites do tacto; a eutrapelia, sobre
os prazeres das diversões. Logo, hão-de ser também diversas as virtudes que versam sobre o temor dos
males.
Mas, em contrário, a castidade versa sobre os prazeres venéreos; a abstinência, por seu lado, sobre os
da mesa; e a eutrapelia, sobre os das diversões.

SOLUÇÃO. — A perfeição da virtude depende da razão, ao passo que a da paixão depende do próprio
apetite sensitivo. Por onde é necessário às virtudes se diversifiquem pela relação que mantêm com a
razão; e as paixões, pela que mantêm com o apetite. E portanto, o diverso ordenar-se dos objetos das
paixões ao apetite sensitivo causa as diversas espécies delas; e enquanto relacionadas com a razão,
causam as diversas espécies de virtudes. Ora, o movimento da razão não é o mesmo que o do apetite
sensitivo. Logo, nada impede uma diferença de objetos, que causa a diversidade das paixões, não cause
a diversidade das virtudes, como no caso de uma virtude versar sobre muitas paixões, segundo já
dissemos. E também uma diferença de objetos pode causar a das virtudes, sem causar a das paixões;
assim, quando diversas virtudes se ordenam a uma mesma paixão, p. ex., o prazer.
Ora, diversas paixões, pertencentes a potências diversas, sempre pertencem a virtudes diversas, como
já dissemos. Logo, a diversidade dos objetos relativa à das potências sempre diversifica as espécies de
virtudes; assim, se um bem é absoluto e outro, acompanhado de certa dificuldade. E como a razão rege,
numa certa ordem, as partes inferiores do homem, e mesmo se ,estende ao exterior, daí vem que o
objeto da paixão se relaciona diversamente com a razão, e portanto é de natureza a diversificar as
virtudes, conforme é apreendido pelos sentidos, pela imaginação, ou mesmo pela razão; ou conforme
pertence à alma, ao corpo ou às coisas exteriores. Logo, o bem do homem, que é o objeto do amor, da
concupiscência e do prazer pode ser considerado como pertencente ao sentido corpóreo ou à
apreensão interior da alma. E isto quer se ordene ao bem do homem em si mesmo, quanto ao corpo ou
quanto à alma; quer se ordene ao bem de um homem em relação aos outros. E toda diversidade tal
diversifica as virtudes, por causa da ordem diversa que mantém com a razão.
Assim pois qualquer bem considerado pertencerá à virtude da temperança, se for apreendido pelo
sentido do tacto, e se disser respeito á conservação individual ou específica da vida humana, como o
prazer da alimentação e os venéreos. Os prazeres porém dos outros sentidos, não sendo veementes, e
não opondo qualquer dificuldade à razão, não há nenhuma virtude que a eles se refira; pois a
virtude, como a arte, versa sobre o difícil, segundo já se disse.
Por outro lado, o bem apreendido, não pelo sentido mas pela virtude interior e pertencente ao homem
em si mesmo, e como o dinheiro e a honra; aquele se ordena, em si mesmo, ao bem do corpo, e esta
consiste numa apreensão da alma. E estes bens podem ser considerados ou absolutamente, enquanto
pertencentes ao concupiscível, ou enquanto acompanhados de certa dificuldade e pertencentes ao
irascível. Esta distinção porém não tem lugar em relação aos bens que deleitam o tacto, que são uns
bens ínfimos e cabem ao homem pelo que tem de comum com os brutos. Por onde, a liberalidade versa
sobre o bem do dinheiro, absolutamente considerado, enquanto objeto da concupiscência, do deleite
ou do amor. E quando esse bem é acompanhado de dificuldade, enquanto objeto da esperança,
constitui o objeto da magnificência. — Por outro lado, o bem sobre o qual versa a honra, considerado
absolutamente, enquanto objeto do amor, é uma virtude chamada filotimia, i. é, amor da honra.
Considerado porém como difícil, enquanto objeto da esperança, constitui a magnanimidade. E assim se
conclui que a liberalidade e a filotimia pertencem ao concupiscível; ao passo que a magnificência e a
magnanimidade, ao irascível.
Por fim, o bem do homem em relação aos outros não implica nenhuma dificuldade, mas é tomado na
sua acepção absoluta, como objeto das paixões do concupiscível. E este bem pode nos ser agradável
enquanto nos damos a outrem, ou naquilo que fazemos seriamente, i. é, nos atos ordenados ao fim
devido; ou naquilo que fazemos por divertimento, i. é, nos atos ordenados unicamente ao prazer, que
não se comportam para com a razão do mesmo modo que os primeiros. Pois, nas causas sérias,
comportamo-nos para com os outros de dois modos. Ou tornando-nos agradáveis por palavras e obras,
o que pertence à virtude por Aristóteles denominada amizade, e que também pode se
chamar afabilidade. Ou manifestando-nos por ditos e fatos, o que pertence à outra virtude
chamada verdade. Ora, a manifestação tem mais de racional que a deleitação, e as coisas sérias, que as
jocosas. E por isso é outra a virtude relativa aos deleites das diversões e a que o Filósofo
chama eutrapelia.
É pois claro que, segundo Aristóteles, são onze as virtudes morais relativas às paixões, a saber: a
fortaleza, a temperança, a liberalidade, a magnificência, a magnanimidade, a filotimia, a mansidão, a
amizade, a verdade, a eutrapelia e a justiça. E se distinguem pelas matérias, paixões e objetos diversos.
E se, por fim, lhes acrescentarmos a justiça, que versa sobre as obras, serão ao todo doze.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todos os objetos de uma mesma obra, especificamente,
mantêm a mesma relação com a razão; não porém todos os objetos da mesma paixão, especificamente;
porque as obras não podem, como os paixões, repugnar à razão.

RESPOSTA À SEGUNDA. — Uma é a razão que diversifica as paixões e outra a que diversifica as virtudes,
como já dissemos.

RESPOSTA À TERCEIRA. — O mais e o menos não diversificam a espécie, senão pela relação diversa com
a razão.

RESPOSTA À QUARTA. — O bem tem maior força de atração que o mal porque este não age senão em
virtude daquele, como diz Dionísio. E por isso, o mal não opõe nenhuma dificuldade à razão que exija
uma virtude, salvo se ele for grande: e esse é único em cada gênero de paixão. Assim, a mansidão é a
única virtude oposta à ira, e a fortaleza a única que versa sobre a audácia. Ao passo que a dificuldade
proveniente do bem, exige virtude, embora não seja grande o bem em cada gênero de paixão. E por isso
há várias virtudes morais que versam sobre as concupiscências, como já dissemos.