# Questão 103: Da duração dos preceitos cerimoniais.
Em seguida devemos tratar da duração dos preceitos cerimoniais.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a cerimônias da lei existiram antes dela.
(III, q. 60, a. 5, ad3; q. 61, a. 3 ad2; q. 70, a. 2, ad 1; IV Sent., dist. 1, q. 1, a. 2, qª 3, ad2; q. 2, a 6, qª 3; Ad
Hebr., cap. VII, lect I).
O primeiro discute-se assim. — Parece que as cerimônias da lei existiram antes dela.

1. — Pois, os sacrifícios e os holocaustos pertenciam às cerimônias da lei antiga, como já se disse (q.
101, a. 4). Ora, uns e outros existiram antes dela. Assim, diz a Escritura (Gn 4, 3-40, que Caim ofereceu
ao Senhor os seus dons dos frutos da terra; Abel também ofereceu das primícias do seu rebanho e das
suas gorduras. Noé também ofereceu holocaustos ao Senhor (Gn 18, 20). Abraão, do mesmo modo (Gn
22, 13). Logo, as cerimônias da lei antiga existiram antes dela.

2. Demais. — Entre as cerimônias concernentes às coisas sagradas estava construir e untar o altar. Ora,
isto se fazia antes da lei, como se lê na Escritura (Gn 13, 18): Abraão edificou um altar ao Senhor; e diz
de Jacó (Gn 28, 18): tirou a pedra e a erigiu em padrão, derramando óleo sobre ela. Logo, as cerimônias
legais existiram antes da lei.

3. Demais. — Entre os sacramentos legais era considerado como o primeiro a circuncisão. Ora, esta
existia antes da lei, como se lê na Escritura (Gn 17). Também o sacerdócio existia antes da lei; pois, diz a
Escritura (Gn 14, 18), que Melquisedeque era Sacerdote do Deus altíssimo. Logo, as cerimônias dos
sacramentos existiram antes da lei.

4. Demais. — A discriminação entre animais limpos e imundos pertencia às cerimônias das observâncias,
como se disse (q. 100, a. 2, a. 6 ad 1). Ora, essa discriminação já existia antes da lei, como se vê na
Escritura (Gn 7, 2-3): Toma de todos os animais limpos sete machos e sete fêmeas; e dos animais
imundos dois machos e duas fêmeas. Logo, as cerimônias legais existiram antes da lei.
Mas, em contrário, a Escritura (Dt 6, 1): Estes são os preceitos e as cerimônias que o Senhor nosso Deus
me mandou que vos ensinasse. Ora, os judeus não precisavam ser ensinados sobre elas, se tais
cerimônias já tivessem existido antes. Logo, as cerimônias da lei não existiram antes dela.

SOLUÇÃO. — Como já dissemos (q. 101, a. 2; q. 102, a. 2), as cerimônias da lei se ordenavam a dois fins:
o culto de Deus e a figuração de Cristo. Ora, quem adora a Deus há de necessariamente fazê-lo por
determinados meios, constitutivos do culto externo. E determinar o culto divino pertencia às
cerimônias; assim como pertence aos preceitos judiciais determinar as disposições que nos ordenam ao
próximo, como já dissemos (q. 99, a. 4). Por onde, assim como entre os homens havia geralmente certos
preceitos judiciais, sem contudo serem instituídos por autoridade da lei divina, mas ordenados pela
razão deles, assim também havia certas cerimônias, não certo, determinadas pela autoridade de alguma
lei, mas só pela vontade e devoção dos que adoravam a Deus. — Ora, ainda antes da lei, existiram certos
homens notáveis, dotados de espírito profético. Por onde é de crer que, por instinto divino e como por
uma lei privada, fossem levados a algum modo certo de adorar a Deus, conveniente ao culto interior e
também próprio a significar os mistérios de Cristo, que também eram figurados por outros atos deles,
conforme a Escritura (1 Cor 10, 11): Todas estas coisas lhes aconteciam a eles em figura. — Existiram,
logo, antes da lei, certas cerimônias; não porém as da lei, porque não eram instituídas por nenhuma
disposição legal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essas oblações e sacrifícios e holocaustos os antigos os
ofereciam por uma certa devoção da vontade própria, por lhes parecer conveniente. Para que, pelas
coisas recebidas de Deus e pelas que ofereciam em reverência divina, se afirmassem como adoradores
de Deus, princípio e fim de todas as coisas.

RESPOSTA À SEGUNDA. — E também instituíram certas coisas como sagradas; pois lhes parecia
conveniente, em reverência de Deus haverem certos lugares, distintos dos outros, destinados ao culto
divino.

RESPOSTA À TERCEIRA. — O sacramento da circuncisão foi estabelecido por preceito divino, antes da
lei. Por isso não se pode chamar sacramento da lei, como se fosse por ela instituído, mas só como
observado no seu regime. E foi isto o que disse o Senhor (Jo 7, 20): a circuncisão não vem do Senhor,
mas dos patriarcas. Também o sacerdócio existia antes da lei, entre os que adoravam a Deus, por
determinação humana, e que atribuíam essa dignidade aos primogênitos.

RESPOSTA À QUARTA. — A discriminação entre animais limpos e imundos, para o efeito de serem
comidos, não era anterior à lei, pois a Escritura diz (Gn 9, 3): Tudo o que se move e vive vos poderá
servir de sustento. Mas só para o efeito da oblação dos sacrifícios, porque os ofereciam de certos
determinados animais. Se porém havia certas discriminações de animais, para o fim da alimentação, isto
não era por se reputar ilícito o comê-los, pois nenhuma lei o proibia; mas por causa da abominação ou
do costume. Assim como ainda agora vemos serem certos alimentos abomináveis em certas terras,
comidos em outras.

## Art. 2 — Se as cerimônias da lei antiga tinham a virtude de justificar no tempo dessa lei.
(Supra, q. 100, a. 12; q. 102, a. 5, ad 4; III, q. 62, a. 6; IV Sent., dist. I, q. 1, a. 5, qª 1, 3; Ad Gatal., cap. II,
lect. IV; cap. III, lect. IV; Ad Hebr., cap. IX, lect, II).
O segundo discute-se assim. — Parece que as cerimônias da lei antiga tinham a virtude de justificar,
no tempo dessa lei.

1. — Pois, a expiação do pecado e a consagração do homem pertencem à justificação. Ora, a Escritura
diz (Ex 39, 21) que pela aspersão do sangue e unção com o óleo eram consagrados os sacerdotes e as
suas vestes. E noutro lugar diz (Lv 16, 16), que o sacerdote, pela aspersão do sangue do bezerro, expiava
o santuário das impuridades dos filhos de Israel e das suas prevaricações e dos seus pecados. Logo, as
cerimônias da lei antiga tinham a virtude de justificar.

2. Demais. — Aquilo pelo que o homem agrada a Deus pertence à justificação, conforme a Escritura (Sl
10, 8): O Senhor é justo e amou a justiça. Ora, pelas cerimônias certos agradavam a Deus, conforme
ainda a Escritura (Lv 10, 19): Como poderia eu agradar ao Senhor nas cerimônias, achando-me com o
coração tão penalizado? Logo, as cerimônias da lei antiga tinha o poder de justificar.

3. Demais. — O que é do culto divino mais pertence à alma que ao corpo, conforme a Escritura (Sl 18,
8): A lei do Senhor, que é imaculada, converte as almas. Ora, pelas cerimônias da lei antiga, purificavam-
se os leprosos. Logo, com maior razão, essas cerimônias podiam purificar a alma, justificando.
Mas, em contrário, diz o Apóstolo (Gl 2): Se tivesse sido dada uma lei que pudesse justificar, Cristo
morreu em vão, i. é, sem causa. Ora, isto é inadmissível. Logo, as cerimônias da lei antiga não
justificavam.

SOLUÇÃO. — Como já dissemos (q. 102, a. 5 ad 4), a lei antiga estabelecia uma dupla imundice: a
espiritual, i. é, a da culpa; e a corporal, que privava da idoneidade para o culto divino. Assim como era
considerado imundo o leproso, ou aquele que tocava algum cadáver: Por onde, a imundice não era
senão uma certa irregularidade.
Ora, as cerimônias da lei antiga tinham a virtude de purificar dela. Pois, eram uns remédios
determinados por ordenação da lei, para purificar da referida imundice, estatuída pela própria lei. Por
isso, o Apóstolo diz (Heb 9, 13): o sangue dos bodes e dos touros, e a cinza espalhada duma novilha,
santifica aos imundos para purificação da carne. E assim como a imundice de que se era purificado, por
essas cerimônias, era mais da carne que da mente, assim também as cerimônias mesmas da justiça da
carne o Apóstolo as considera como justiças da carne postas até ao tempo da correção.
Elas porém não tinham a virtude de expiar a imundice da mente, que é imundice da culpa. E isto porque
a expiação dos pecados só pode ser feita por Cristo, que tira os pecados do mundo, como diz o
Evangelho (Jo 1, 29). E como o mistério da encarnação e da paixão de Cristo ainda não estava
totalmente consumado, as cerimônias da lei antiga não podiam conter realmente em si uma virtude
profluente dessa encarnação e dessa paixão, como a contêm os sacramentos da lei nova. E por isso não
podiam purificar do pecado, como diz o Apóstolo (Heb 10, 4): é impossível que com sangue de touros e
de bodes se tirem os pecados. E a isto o Apóstolo chama elementos fracos e pobres; fracos, porque não
podem purificar dos pecados; fraqueza essa proveniente de serem pobres, i. é, de não conterem em si a
graça.
A mente dos fiéis contudo podia, na vigência da lei, unir-se a Cristo, que se encarnou e sofreu a paixão, e
assim justificar-se pela fé em Cristo. Da qual era uma afirmação a observância dessas cerimônias,
enquanto figura de Cristo. Por isso, no regime da lei antiga ofereciam-se certos sacrifícios pelos pecados;
não que por si mesmos eles purificassem do pecado, mas por serem uma afirmação de fé, que dele
purificava. E isso mesmo a lei o indica pelo modo de exprimir-se. Pois, determina que, na oblação das
hóstias pelo pecado, o sacerdote rogará por ele (pelo príncipe) e o seu pecado lhe será perdoado; como
se o pecado fosse perdoado, não por força dos sacrifícios, mas pela fé e devoção dos oferentes.
Deve-se contudo saber, que a expiação, pela cerimônia da lei antiga, das imundices corpóreas, era figura
da expiação dos pecados operada por Cristo.
Por onde é claro, que as cerimônias, no regime da lei antiga; não tinham a virtude de justificar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa santificação do sacerdote, dos seus filhos, das suas
vestes e de tudo o mais, pela aspersão do sangue, não passava de uma preparação ao culto divino e
remoção dos impedimentos, para a purificação da carne, como diz o Apóstolo (Heb 9, 13). E prefigurava
a outra purificação, pela qual Jesus, pelo seu sangue, santificou o povo. Ora, a expiação deve referir-se à
remoção dessas imundices corpóreas, e não à da culpa. Donde a referência à expiação do santuário, que
entretanto não podia ser sujeito de culpa.

RESPOSTA À SEGUNDA. — Os sacerdotes agradavam a Deus, nas cerimônias, pela obediência, devoção
e fé no que prefiguravam; não porém por elas, em si mesmas consideradas.

RESPOSTA À TERCEIRA. — As cerimônias instituídas para a purificação dos leprosos não se ordenavam a
tirar a imundice da enfermidade da lepra; o que se patenteia por se aplicarem só ao que já estava limpo.
Por isso, diz a Escritura (Lv 14, 3-4): o sacerdote, saindo fora do arraial, vendo que a lepra está curada,
mandará ao que se purifica, que ofereça, etc. Por onde é claro que era constituído juiz da lepra já curada
e não, da que devia selo. E as cerimônias de que se trata foram estabelecidas para tirar a imundice da
irregularidade. Diz-se contudo que às vezes se acontecesse o sacerdote errar no juízo, o leproso era
limpo miraculosamente por Deus, por virtude divina e não por virtude dos sacrifícios. Assim também,
milagrosamente, apodrecia a coxa de uma mulher adúltera, depois de ter bebido a água que o
sacerdote carregou de maldições, como está na Escritura (Nm 5, 19-27).

## Art. 3 — Se as cerimônias da lei antiga cessaram com o advento de Cristo.
(IV Sent., dist. I, q. 2, a. 5, qª 1, 2).
O terceiro discute-se assim. — Parece que as cerimônias da lei antiga não cessaram com o advento de
Cristo.

1. — Pois, diz a Escritura (Br 4, 1): Este é o livro dos mandamentos de Deus, e a lei que subsiste
eternamente. Ora, as cerimônias da lei a ela pertenciam. Logo, haviam de durar eternamente.

2. Demais. — A oblação do leproso purificado pertencia às cerimônias da lei. Ora, também o Evangelho
preceitua ao leproso purificado fazer essas oblações. Logo, com a vinda de Cristo não cessaram as
cerimônias da lei antiga.

3. Demais. — Permanecendo a causa, permanece o efeito. Ora, as cerimônias da lei antiga tinham certas
causas racionais, enquanto ordenadas ao culto divino, além de se ordenarem a figurar a Cristo. Logo, as
cerimônias da lei antiga não deviam cessar.

4. Demais. — A circuncisão foi instituída em sinal da fé de Abraão; a observação do sábado, para
rememorar o benefício da criação; e as demais solenidades da lei, para lembrarem os outros benefícios
de Deus, como já dissemos (q. 102, a. 4 ad 10; a. 5 ad 1). Ora, ainda nós devemos imitar a fé de Abraão;
e devemos sempre rememorar o benefício da criação e os outros benefícios de Deus. Logo, pelo menos
a circuncisão e as solenidades da lei não deviam cessar.
Mas, em contrário, diz a Escritura (Cl 2, 16-17): Ninguém vos julgue pelo comer nem pelo beber, nem
por causa dos dias de festa, ou das luas novas, ou dos sábados, que são sombras das coisas vindouras. E
(Heb 8, 13): chamando-lhe novo testamento deu por antiquado o primeiro; e o que se dá por antiquado
e envelhece perto está de perecer.

SOLUÇÃO. — Todos os preceitos cerimoniais da lei antiga ordenavam-se ao culto de Deus, como já
dissemos (q. 101, a. 1, a. 2). Ora, o culto externo deve proporcionar-se ao interno, por consistir na fé, na
esperança e na caridade. Por onde, à diversidade do culto externo devia corresponder a do interno. Ora,
podemos distinguir três estados no culto interno. — Um, no qual se tem fé e esperança nos bens
celestes e no que nos leva a esses bens; tudo porém considerado como coisas futuras. E tal foi o estado
da fé e da esperança, na lei antiga. — Outro é o estado do culto interno, no qual se tem fé e esperança
nos bens celestes, como em bens futuros; e nos meios que nos levam a esses bens, mas como meios
presentes ou pretéritos. E este é o estado da lei nova. — O terceiro estado é o em que ambas essas
coisas se crêem como presentes, e não se espera nada de futuro. E este é o dos bem-aventurados.
Ora, nesse estado da bem-aventurança, nada há de figurado no atinente ao culto divino senão só a ação
de graças e louvor. E por isso diz a Escritura (Ap 21, 22): E não vi templo nela; porque o Senhor Deus
todo poderoso e o cordeiro é o seu templo. Logo e pela mesma razão, as cerimônias do primeiro estado,
que figuravam o segundo e o terceiro, deveram cessar, com o advento do segundo. E deviam ser
estabelecidas outras cerimônias, convenientes ao estado do culto divino, para o tempo em que, sendo
futuros os bens celestes, os benefícios de Deus, que nos levam aqueles bens, são presentes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que a lei antiga deve existir eternamente,
absolutamente falando, quanto aos seus preceitos morais; e, quanto aos cerimoniais, no concernente à
verdade por eles figurada.

RESPOSTA À SEGUNDA. — O mistério da redenção do gênero humano ficou completo com a paixão de
Cristo. Por isso então o Senhor exclamou (Jo 19, 30): Tudo está cumprido, como se lê na Escritura. E
portanto, nesse momento teve de cessar todo o regime da lei antiga, cumprido por assim dizer na sua
verdade. E em sinal disso, como se lê na Escritura, na paixão de Cristo o véu do templo rasgou-se (Mt 27,
51). Por onde, antes da paixão de Cristo, enquanto pregava e fazia milagres, vigoravam ao mesmo
tempo a lei e o Evangelho, porque o seu mistério estava começado, mas ainda não cumprido. Pelo que,
N. S. Jesus Cristo mandou, antes da sua paixão, o leproso observar as cerimônias legais.

RESPOSTA À TERCEIRA. — As razões literais das cerimônias supra-referidas respeitam o culto divino,
baseado na fé do que deveria vir. Por onde, com o advento do que devia vir, cessou esse culto, e com
ele todas as razões que o justificavam.

RESPOSTA À QUARTA. — A fé de Abraão se fundava na sua crença na promessa divina, relativa à
descendência futura, e que seriam abençoados todos os povos. Por isso, enquanto isso era futuro, era
necessário afirmar a fé de Abraão pela circuncisão. Mas depois da promessa realizada, deve ela
manifestar-se por outro sinal, a saber, o batismo, que, assim, substitui a circuncisão, conforme aquilo do
Apóstolo (Cl 2, 11-12): Vós estais circuncidados de circuncisão não feita por mão de homem no despojo
do corpo da carne, mas sim na circuncisão de N. S. J. Cristo, estando sepultado juntamente com ele no
batismo. Por isso o sábado, que significava a criação inicial, foi mudado no domingo, em que se
comemora a nova criação, começada com a ressurreição de Cristo. E semelhantemente, às outras
solenidades da lei antiga sucederam-se novas, pois, os benefícios feitos ao povo judeu significam os que
Cristo nos concedeu. Assim, à festa da Fase sucedeu a da Paixão e da Ressurreição de Cristo; à de
Pentecostes, em que foi dada a lei antiga, a de Pentecostes, em que foi dada a do Espírito da vida; à da
Neomênia, a da beata Virgem, com a qual primeiro apareceu a luz do sol; i. é, de Cristo, pela abundância
da graça; à das Trombetas, a dos Apóstolos; à da Expiação, a dos Mártires e Confessores; à dos
Tabernáculos, a da Consagração da Igreja; à da Congregação e do Ajuntamento, a dos Anjos, ou ainda, a
de Todos os Santos.

## Art. 4 — Se depois da paixão de Cristo, podem-se observar as cerimônias legais, sem pecado mortal.
(Infra, q. 104, a. 3; q. 107, a. 2 ad 1; Iª-IIªª, q. 93, a. 7; IV Sent., dist. I, q. 2, a. 5; qª 3,4; Ad Rom., cap. XIV,
lect. I; Ad Galad., cap. II, lect. III; cap. 5, lect. I; Ad Coloss., cap. II, lect. IV).
O quarto discute-se assim. — Parece que depois da paixão de Cristo, podem-se observar as cerimônias
legais, sem pecado mortal.

1. — Pois, não se pode crer que os Apóstolos, depois de terem recebido o Espírito Santo, pecassem
mortalmente; pois, pela plenitude do Espírito, foram revestidos da virtude do alto, conforme a Escritura
(Lc 24, 49). Ora, os Apóstolos, depois do advento do Espírito Santo, observaram a lei. Assim, a Escritura
diz (At 16, 3), que Paulo circuncidou a Timóteo. E, noutro lugar (At 21, 26), que Paulo, por conselho de
Tiago, depois de tomar consigo aqueles varões, purificado com eles, no seguinte dia entrou no templo,
fazendo saber o cumprimento dos dias da purificação, até que se fizesse a oferenda por cada um
deles. Logo, as cerimônias legais podem ser observadas, depois da paixão de Cristo, sem pecado mortal.

2. Demais. — Pertencia às cerimônias da lei evitar a convivência com os gentios. Ora, isto foi observado
pelo primeiro pastor da Igreja, conforme aEscritura (Gl 2, 12): quando chegaram os que vieram a
Antioquia, Pedro subtraía-se e separava-se dos gentios. Logo, sem pecado, depois da paixão de Cristo,
podem observar-se as cerimônias da lei.

3. Demais. — Os preceitos dos Apóstolos não podiam induzir os homens ao pecado. Ora, por decisão
dos Apóstolos, foi estabelecido, que os gentios observassem algumas das disposições da lei, como se lê
na Escritura (At 15, 28-29): Pareceu bem ao Espírito Santo e a nós, não vos impor mais encargos do que
os necessários, que são estes: a saber, que vos abstenhais do que tiver sido sacrificado aos ídolos, e do
sangue e das carnes sufocadas e da fornicação. Logo, sem pecado, as cerimônias legais podem ser
observadas, depois da paixão de Cristo.
Mas, em contrário, diz o Apóstolo (Gl 5, 2): se vos fazeis circuncidar, Cristo não vos aproveitará
nada. Ora, só o pecado mortal faz perder o fruto da paixão de Cristo. Logo, observar a circuncisão e as
outras cerimônias da lei, depois dessa paixão, é pecado mortal.

SOLUÇÃO. — Todas as cerimônias da lei eram uma afirmação de fé, na qual consiste o culto interno de
Deus. Ora, a fé interior o homem pode manifestá-la por atos e por palavras; e, em ambos os casos,
quem afirmar alguma coisa falsamente comete pecado mortal. Pois, embora seja a fé que temos em
Cristo a mesma que tiveram os antigos Patriarcas, contudo, como eles o precederam e nós viemos
depois, a mesma fé é expressa por nós e por eles por palavras diferentes. Assim, a eles se lhes disse: Eis
que uma virgem conceberá no seu ventre e dará à luz um filho, sendo o verbo empregado no futuro; ao
contrário, nós o afirmamos com o verbo no passado: concebeu no seu ventre e deu à Luz.
Semelhantemente, as cerimônias da lei antiga significavam que Cristo havia de nascer e sofrer; ao passo
que os nossos sacramentos significam que nasceu e sofreu.
Por onde, assim como pecaria mortalmente quem, afirmando a sua fé, dissesse, como os antigos pia e
verdadeiramente faziam, que Cristo havia de nascer, assim também pecaria mortalmente quem agora
observasse as cerimônias da lei, que os antigos observavam pia e fielmente. E é isto o que diz Agostinho:
Jánão é prometido como havendo de nascer, de sofrer, de ressurgir, conforme o significavam os
sacramentos antigos; mas se anuncia que nasceu, sofreu, ressurgiu, conforme o significavam os
sacramentos recebidos pelos Cristãos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Neste ponto diferem as opiniões de Jerônimo e de
Agostinho. — Aquele distingue dois tempos. Um anterior à paixão de Cristo, em que as cerimônias legais
não eram peremptas, como se não tivessem, a seu modo, força obrigatória ou expiatória; nem
mortíferas, porque não pecava quem as observasse. Mas logo depois da paixão de Cristo começaram,
não só a ser letra morta, i. é, sem força e obrigatoriedade, mas também mortíferas, e assim pecava
mortalmente quem quer que as observasse. Por isso dizia que os Apóstolos nunca mais observaram
essas cerimônias, depois da paixão verdadeira, mas só por uma como pia simulação, para os judeus não
se escandalizarem e ficar-lhes impedida a conversão. Essa simulação deve ser entendida, não como
querendo dizer, que não praticassem os referidos atos, na verdade das coisas, mas que não os
praticavam como observantes das cerimônias da lei. Seria esse o caso daquele que cortasse o prepúcio
do membro viril, por motivo de saúde, e não para observar a circuncisão legal.
Mas era inconveniente que os Apóstolos ocultassem, por causa do escândalo, o que pertence à verdade
da vida e da doutrina, e usassem de simulação no atinente à salvação dos fiéis. Por isso e mais
apropriadamente, Agostinho distingue três tempos. Um, anterior à paixão de Cristo, em que as
cerimônias legais nem eram letra morta, nem mortíferas. Outro, posterior à divulgação do Evangelho,
em que são letra morta e mortíferas. Um terceiro tempo é médio, isto é, compreendido entre a paixão
de Cristo e a divulgação do Evangelho, em que eram, certo, letra morta, porque já não tinham nenhuma
força nem estava ninguém obrigado a observá-las. Contudo não eram mortíferas, porque os judeus, que
se converteram a Cristo, podiam observá-las licitamente; contanto que nelas não pusessem toda a
esperança, de modo a reputarem-nas necessárias à salvação, como se, sem elas, a fé em Cristo não
pudesse justificar. Os gentios porém, que se convertiam a Cristo, nenhuma razão tinham para observar
tais cerimônias. Por isso Paulo circuncidou Timóteo, que era nascido de mãe judia; ao contrário, não
quis circuncidar Tito, que nasceu gentio.
Por onde, o Espírito Santo não quis que se proibisse imediatamente aos judeus convertidos a
observância dessas cerimônias, como o eram aos gentios convertidos os ritos da gentilidade. Isto para
estabelecer uma diferença entre esses dois ritos. Pois, o da gentilidade era repudiado como
absolutamente ilícito e sempre proibido por Deus; ao passo que o rito da lei cessava, como tendo a sua
plenitude na paixão de Cristo e como instituído que fora por Deus para figurar Cristo.

RESPOSTA À SEGUNDA. — Segundo Jerônimo, Pedro subtraía-se simuladamente aos gentios, para
evitar o escândalo dos judeus, dos quais era o Apóstolo. Por isso, assim agindo, de nenhum modo
pecou. Ao passo que Paulo repreendeu-o também simuladamente, para evitar o escândalo dos gentios,
de quem era o Apóstolo.
Mas, Agostinho refuta essa opinião. Porque Paulo, na Escritura canônica, na qual não se pode crer que
haja nada de falso, diz que Pedro era repreensível. Logo, é verdade que Pedro pecou e Paulo o
repreendeu verdadeira e não, simuladamente. Ora, Pedro não pecou por ter observado, fora do tempo,
as cerimônias da lei; pois, isso lhe era lícito, como judeu convertido. Mas pecou por ter posto demasiada
diligência em observar tais cerimônias, para não escandalizar os judeus; de modo porém que daí
resultava escândalo para os gentios.

RESPOSTA À TERCEIRA. — Certos disseram, que a referida proibição dos Apóstolos não deve ser
entendida em sentido literal, mas espiritual. De modo que, pela proibição do sangue se entenda a do
homicídio; pela das carnes sufocadas, a da violência e da rapina; pela das vítimas imoladas, a da
idolatria; a fornicação, enfim, era proibida por ser má em si mesma. E deduzem esta opinião de certas
glosas, que expõem esses preceitos misticamente. — Mas como o homicídio e a rapina eram reputados
ilícitos,mesmo entre os gentios, não era preciso, nesse ponto, fazer um mandamento especial aos que,
da gentilidade se convertiam a Cristo.
Por isso outros dizem, que era proibido comer de tais causas, literalmente, não por causa da
observância das cerimônias legais, mas para reprimir a gula. Por onde, Jerônimo, comentando aquilo da
Escritura — Tudo o que por si mesmo haja morrido, etc. — diz: Condena os sacerdotes que, a propósito
dos tordos e de aves semelhantes, não guardam tais mandamentos, por avidez da gula. — Mas como há
certas comidas mais delicadas e provocadoras da gula, não havia razão para essas de que trata, serem,
mais que outras, proibidas.
E portanto, devemos dizer, de conformidade com a terceira opinião, que essas comidas foram
literalmente proibidas, não para se observarem as cerimônias da lei, mas para poder consolidar-se a
união dos gentios e dos judeus, habitando em comum. Pois, aos judeus, por costume antigo, era
abominável o sangue e as carnes sufocadas; e o comer do que fora imolado aos ídolos podia despertar-
lhes, em relação aos gentios, a suspeita de que retornavam à idolatria. Por isso fizeram-se as referidas
proibições, em tempo ainda recente, quando gentios e judeus deviam viver juntos. Mas, com o correr
dos anos, cessando a causa, cessou o efeito, uma vez manifestada a verdade da doutrina evangélica, em
que o Senhor ensina (Mt 15, 11), que não é o que entra pela boca o que faz imundo o homem; e que (1
Tm 4, 4) não é para desprezar nada do que se participa com ação de graças. Quanto à fornicação, foi
especialmente proibida, pela não considerarem os gentios como pecado.