# Questão 34: Da bondade e da malícia dos prazeres.
Em seguida devemos tratar da bondade e da malícia dos prazeres.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se todo prazer é mau.
(IV Sent., dist. XLIX, q. 3, a. 4, qa. 1; VII Ethic., lect. XI, XII; X, lect. I, III, IV, VIII).
O primeiro discute-se assim. ― Parece que todo prazer é mau.

1. ― Pois, o que corrompe a prudência e impede o uso da razão é, em si, mau, porque o bem do homem
é o que está de acordo com a razão, como diz Dionísio. Ora, o prazer corrompe a prudência e impede o
uso da razão, e tanto mais quanto maiores são os prazeres; por isso, nos prazeres venéreos, que são os
mais intensos, a nossa razão fica completamente abolida, como diz Aristóteles. E Jerônimo também diz,
que não haverá a presença do Espírito Santo no momento em que se realiza o ato conjugal, mesmo se
for um profeta o que exerça o ato da geração. Logo, todo prazer é mau.

2. Aquilo de que foge o virtuoso e que busca o de virtude deficiente parece que é em si mau e deve ser
evitado; pois, como diz Aristóteles, o homem virtuoso é quase a medida e a regra dos atos humanos; e o
Apóstolo diz (1 Cor 2, 15): o espiritual julga todas as coisas. Ora, as crianças e os animas, não
susceptíveis de virtude, buscam os prazeres, que são evitados pelo homem sóbrio. Logo, os prazeres
são, em si mesmos, maus e devem ser evitados.

3. Demais. ― A virtude e a arte versam sobre o difícil e o bom, como diz Aristóteles. Ora, nenhuma arte
é ordenada para o prazer. Logo, este não é um bem.
Mas, em contrário, diz a Escritura (Sl 36, 4): Deleita-te no Senhor. Ora, como a autoridade divina não
pode induzir a nenhum mal, conclui-se que nem todo prazer é mau.

SOLUÇÃO. ― Conforme diz Aristóteles, certos ensinaram que todos os prazeres são maus e isso porque
consideravam só os prazeres sensíveis e corpóreos, os mais manifestos. Pois no mais, os antigos
filósofos não distinguiam o inteligível do sensível nem o intelecto, dos sentidos, como diz ainda
Aristóteles. E assim, pensavam que devemos considerar maus todos os prazeres corpóreos, de modo
que os homens, inclinados aos prazeres imoderados chegam ao termo médio da virtude, abstendo-se
dos prazeres. ― Mas esta opinião não é admissível. Pois, como ninguém pode viver sem algum prazer
sensível e corpóreo, se os que têm todos os prazeres como maus forem surpreendidos no gozo de
alguns deles, os outros homens mais se inclinarão aos prazeres, pelo exemplo das obras, e abandonarão
a doutrina. Porque, no tocante às obras e às paixões humanas, onde vale sobretudo a experiência, os
exemplos movem mais que as palavras.
Logo, devemos dizer que certos prazeres são bons e certos, maus. Pois, o prazer é o repouso da
potência apetitiva nalgum bem amado e é conseqüente a alguma operação. E disto podemos dar duas
razões. ― Uma se funda no bem em que, descansando, nos deleitamos. Pois, o bem e o mal, na ordem
moral é o que convém à razão ou dela discorda, como já dissemos; assim como, na ordem da natureza,
chama-se natural o que convém à natureza, e inatural o que dela discorda. Ora, assim como na ordem
natural há um certo repouso natural, a saber, o que convém à natureza, p. ex., quando os graves
repousam na parte inferior; e há outro inatural, a saber, o que repugna à natureza, como quando os
graves repousam na parte superior; assim também na ordem moral, é bom o prazer que leva o apetite
superior ou o inferior a repousar no que convém à razão; e é mau o que o leva a repousar no que
discorda da razão e da lei de Deus. ― A outra razão se funda nas ações, das quais umas são más e
outras, boas. Ora, com as ações têm mais afinidade os prazeres que as acompanham, que os desejos
que as precedem no tempo. Por onde, sendo bons os desejos das boas ações e maus os das más, com
maioria de razão hão-de ser bons os prazeres que acompanham as boas obras e maus os que
acompanham as más.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como já dissemos, os prazeres fundados num ato
racionável não obstruem a razão nem destroem a prudência; mas os prazeres estranhos, como os
corpóreos, são os impedientes do uso da razão, segundo se disse. E isto ou por contrariedade do
apetite, que repousa no repugnante à razão e torna o prazer moralmente mau; ou por uma certa
obstrução da razão, como no concúbito conjugal onde, embora o prazer seja racional, impede contudo o
uso da razão por causa da alteração corpórea concomitante. Mas daí não resulta a malícia moral, assim
como o sono, impediente do uso da razão, não é moralmente mau, se a ele nos entregamos conforme a
razão o exige; pois, esta mesma exige que às vezes fique travado o seu uso. Dizemos contudo que a
obstrução da razão, proveniente do prazer do concúbito conjugal, embora não implique malícia moral,
porque não é pecado mortal nem venial, provém, entretanto, de uma certa malícia moral, a saber, do
pecado do nosso primeiro pai; pois, no estado de inocência não era assim, como é patente pelo já dito
na primeira parte.

RESPOSTA À SEGUNDA OBJEÇÃO. ― O homem sóbrio não evita todos os prazeres, mas só os
imoderados e não convenientes à razão. E o fato de as crianças e os animais buscarem os prazeres não
prova que estes sejam universalmente maus, porque aquelas e estes têm um apetite natural movido por
Deus para o que lhes é conveniente.

RESPOSTA À TERCEIRA OBJEÇÃO. ― A arte não visa todo e qualquer bem mas, o das coisas realizadas
exteriormente, como a seguir se dirá. E sobre as nossas operações e paixões versa mais a prudência e a
virtude, do que a arte. E contudo, há certas artes ― a culinária e a pigmentaria ― que produzem o
prazer, como diz Aristóteles.

## Art. 2 — Se todo prazer é bom.
(IV Sent., dist. XLIX, q. 3, a. 4; qa. 1; VII Ethic., lect. XI; X, lect. IV, VIII).
O segundo discute-se assim. ― Parece que todo prazer é bom.

1. ― Pois, como dissemos na primeira parte, o bem se divide em três espécies ― o honesto, o útil e o
deleitável. Ora, tudo o que é honesto é bom, bem como tudo o que é útil. Logo, todo prazer também é
bom.

2. Demais. ― É bom em si o que não é buscado em vista de outro fim, como diz Aristóteles. Ora, o
prazer não é buscado em vista de outro bem, pois é ridículo perguntar a alguém porque quer gozar.
Logo, o prazer é em si mesmo bom. Ora, o que se predica em si mesmo, de um ser, dele se predica
universalmente. Logo, todo prazer é bom.

3. Demais. ― O desejado por todos é em si mesmo bom, pois bem é o que todos os seres desejam,
como diz Aristóteles. Ora, todos desejam algum prazer, mesmo as crianças e os animais. Logo, o prazer é
em si mesmo bom e portanto todo prazer é bom.
Mas, em contrário, diz a Escritura (Pr 2, 14): Que se alegram depois de terem feito o mal, e triunfam de
prazer nas piores coisas.

SOLUÇÃO. ― Assim como certos estóicos disseram que todos os prazeres são maus, assim os epicuristas
ensinavam ser o prazer em si mesmo bom, e por conseqüência, que todos os prazeres são bons. E uns e
outros se enganaram por que não distinguiram entre o absoluta e o relativamente bom. Ora, é bom
absolutamente o bom em si mesmo. Pode porém suceder, e de duplo modo, que aquilo que não é em si
mesmo bom venha a sê-lo para alguém num determinado caso. De um modo, por lhe ser conveniente,
pela disposição em que atualmente se acha, embora esta não lhe seja natural; assim, a um leproso é, às
vezes, bom comer certos alimentos envenenados, não absolutamente convenientes à compleição
humana. De outro modo, quando o não conveniente é considerado como o sendo. E sendo o prazer o
repouso do apetite no bem, se este o for, absolutamente, o prazer será absoluto e absolutamente bom.
Se porém o bem não o for, absoluta, mas relativamente, também o prazer não é absoluto, mas relativo
a um determinado caso, nem é absolutamente bom, mas bom relativa ou aparentemente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― É relativamente à razão que consideramos um bem
como honesto e útil; e portanto, nada é honesto ou útil sem ser bom. O deleitável porém é relativo ao
apetite, que às vezes tende ao não conveniente à razão. Por onde, nem tudo o deleitável tem bondade
moral, dependente da razão.

RESPOSTA À SEGUNDA. ― O prazer não é procurado como meio para a obtenção de outro bem porque
é o repouso no fim. Ora, este pode ser bom e mau, embora não seja nunca fim senão enquanto bem de
um determinado indivíduo. E o mesmo se dá com o prazer.

RESPOSTA À TERCEIRA. ― Todos os seres buscam o prazer do mesmo modo por que buscam o bem,
pois o prazer é o repouso do apetite no bem. Mas como pode acontecer que nem todo o bem desejado
seja bem em si mesmo e verdadeiramente, assim também nem todo prazer é em si mesmo e
verdadeiramente bem.

## Art. 3 — Se há algum prazer melhor que todos os outros.
(I Sent., dist. XLIX, q. 3, a. 4, qa. 3; VII Ethic., lect. XI; X, lect. II)
O terceiro discute-se assim. ― Parece que não há nenhum prazer melhor que todos os outros.

1. ― Pois, nenhuma geração pode ser o que há de melhor, porque nenhuma pode ser o fim último. Ora,
o prazer resulta de uma geração, pois um ser se deleita quando disposto para um objeto natural
presente, como já se disse. Logo, nenhum prazer há melhor que todos os outros.

2. Demais. ― O melhor por excelência não pode tornar-se ainda melhor com o acréscimo seja do que
for. Ora, o prazer, com certo acréscimo, torna-se melhor; assim, é melhor o prazer com a virtude do que
sem ela. Logo, nenhum prazer há melhor que todos os outros.

3. Demais. ― O melhor, por excelência é universalmente bom, como bem em si mesmo que é; pois, o
existente por si mesmo tem prioridade e excelência sobre o existente por acidente. Ora nenhum prazer
é universalmente bom, como já se disse. Logo não há nenhum melhor que todos.
Mas, em contrário. ― A beatitude é o que há de melhor, como fim da vida humana. Ora, a beatitude é
acompanhada do prazer, como diz a Escritura (Sl 15, 11): encher-me-ás de alegria com teu rosto;
deleites na tua direita para sempre.

SOLUÇÃO. ― Platão não admitia, com os estóicos, que todos os prazeres sejam maus, nem que todos
sejam bons, com os epicuristas; mas que uns são bons e outros maus, sem contudo nenhum ser o bem
sumo ou melhor. Mas as suas razões, tanto quanto podemos compreendê-las, são deficientes em duplo
ponto de vista. ― Primeiro porque, vendo que os prazeres sensíveis e corpóreos consistem num certo
movimento e na geração, como é patente na absorção dos alimentos e de coisas semelhantes, cncluiu
que todos os prazeres são consecutivos à geração e ao movimento. Por onde, sendo a geração e o
movimento atos de seres imperfeitos, resulta que o prazer não tem a natureza de perfeição última. Ora,
isto se patenteia manifestamente falso no caso dos prazeres intelectuais. Pois, deleitamo-nos não só
com a geração da ciência ― p. ex., quando apreendemos ou nos admiramos, conforme já dissemos ―
mas também com a contemplação da ciência já adquirida. ― Segundo, porque considerava como ótimo
o bem absolutamente sumo, que é o bem mesmo, quase abstrato e não participado, assim como Deus
é, em si mesmo, o sumo bem. Ora, nós tratamos do que é ótimo na ordem das coisas humanas, que é,
em cada uma delas, o fim último. Ora, o fim, como já dissemos, tem dupla acepção: ou, uma coisa em si
mesma, ou o uso dela; assim, o fim do avarento é o dinheiro ou a posse deste. E então, podemos
considerar como fim último do homem ou Deus mesmo, sumo bem absoluto, ou o gozo de Deus, que
implica um certo prazer fundado no fim último. E deste modo, há um prazer do homem que pode ser
considerado ótimo por comparação com bens humanos.

DONDE A RSPOSTA À PRIMEIRA OBJEÇÃO. ― Nem todo prazer é conseqüente à geração; mas há certos
conseqüentes às operações perfeitas, como já se disse. Por onde, nada impede haja um prazer ótimo,
embora, nem todos sejam tais.

RESPOSTA À SEGUNDA. ― A objeção colhe aplicada ao melhor por excelência e absolutamente falando;
pela participação do qual existem todos os bens, e que não pode ser melhor por acréscimo seja do que
for. Mas em relação aos demais bens, é universalmente verdade que qualquer deles se torna melhor por
acréscimo de outro. Embora se possa dizer que o prazer é algo de estranho à atividade da virtude, que
antes a acompanha, como diz Aristóteles.

RESPOSTA À TERCEIRA. ― Nenhum prazer é o melhor, por excelência, como prazer, mas como o
repouso perfeito num bem ótimo. Por onde, não é necessário todo prazer seja ótimo, ou mesmo bom,
assim como por haver uma ciência que é ótima, nem todas as ciências o são.

## Art. 4 — Se o prazer é a medida ou a regra do bem e do mal.
(IV Sent., dist. XLIX, q. 3, a. 4, qa. 3, ad 1).
O quarto discute-se assim. ― Parece que o prazer não é a medida ou regra do bem e do mal moral.

1. ― Pois, como diz Aristóteles, todas as coisas se medem pela primeira no gênero. Ora, o prazer não
está em primeiro lugar no gênero da moralidade, mas o precedem o amor e o desejo. Logo, não é a
regra da bondade e da malícia moral.

2. Demais. ― A medida e a regra devem ser uniformes, e por isso o movimento uniforme por excelência
é a medida e a regra de todos os outros movimentos, como dia Aristóteles. Ora, o prazer é vário e
multiforme, pois uns são bons e outros maus. Logo, não é a medida e a regra da moralidade.

3. Demais. ― Julgamos mais certamente do efeito pela causa do que inversamente. Ora, a bondade ou a
malícia da ação é causa da bondade ou malícia do prazer, porque bons são os prazeres consecutivos às
boas ações; maus os consecutivos às más, como diz Aristóteles. Logo, os prazeres não são a regra e a
medida da bondade e da malícia moral.
Mas, em contrário, diz Agostinho, a propósito de um salmo ― ó Deus, que sondas os corações e as
entranhas: O fim dos cuidados e dos pensamentos é o prazer, a que todos nos esforçamos por chegar. E
o Filósofo diz, que o prazer é um fim arquitetônico, i. é., principal, relativamente ao qual julgamos que
tal ação é boa e tal outra má, absolutamente.

SOLUÇÃO. ― A bondade e a malícia moral consiste principalmente na vontade, como já dissemos. E
pelo fim conhecemos se esta é boa ou má. Ora, consideramos como fim aquilo no que a vontade
descansa; e o descanso da vontade ou de qualquer apetite no bem é o prazer. Por onde, pelo prazer da
vontade humana principalmente julgamos se um homem é bom ou mau: bom e virtuoso é o que se
compraz nas obras das virtudes; mau, o que se compraz nas obras más.
Os prazeres do apetite sensitivo porém não são a regra da bondade nem da malícia; assim, a comida é
deleitável em geral para o apetite sensitivo tanto do bom como do mau. Mas a vontade dos bons com
ela se deleita conforme a conveniência da razão, da qual não cura a vontade dos maus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O amor e o desejo têm prioridade sobre o prazer, na via
da geração. O prazer porém é anterior se considerarmos a idéia de fim, pois este exerce a função de
princípio, relativamente às ações; ora, por este princípio, como regra ou medida, sobretudo julgamos.

RESPOSTA À SEGUNDA. ― Todos os prazeres são uniformes no serem o repouso em algum bem; e
assim podem servir de regra ou medida. Assim, bom é aquele cuja vontade repousa no verdadeiro bem;
mau pelo contrário aquele cuja vontade descansa no mal.

RESPOSTA À TERCEIRA. ― O prazer aperfeiçoando, como fim, a operação, como já dissemos, não pode
ser perfeitamente boa uma operação sem ser acompanhada do prazer fundado no bem, pois a bondade
de uma ação depende do fim. E assim, de certo modo, a bondade do prazer é a causa da bondade da
operação.