# Questão 56: Do sujeito da virtude.
Em seguida devemos tratar do sujeito da virtude.
E sobre esta questão seis artigos se discutem:

## Art. 1 — Se a virtude existe na potência da alma como sujeito.
(III Sent., dist. XXXIII, q. 1, a. 4, qª 1; De Virtut., q. 1 a. 3).
O primeiro discute-se assim. — Parece que a virtude não existe na potência da alma como sujeito.

1. — Pois, diz Agostinho, que a virtude é que nos leva a viver retamente. Ora, nós não vivemos pela
potência da alma, mas pela sua essência. Logo, a virtude tem sua sede nesta e não naquela.

2. Demais. — O Filósofo diz: a virtude torna bom tanto quem a possui, como as suas obras. Ora, como a
obra é realizada pela potência, assim o virtuoso o é pela essência da alma. Logo, a virtude não reside
antes na potência que na essência da alma.

3. Demais. — A potência pertence à segunda espécie de qualidade. Ora, a virtude é uma qualidade,
como já se disse. E como não pode haver qualidade de qualidade, a virtude não pode existir na potência
da alma, como sujeito.
Mas, em contrário. — A virtude é o que, na potência, é último, como se disse. Ora, o que em alguma
coisa é último nessa existe. Logo, a virtude existe na potência da alma.

SOLUÇÃO. — Por três razões pode-se tornar manifesto que a virtude pertence à potência da alma. A
primeira se funda na essência mesma da virtude, que implica a perfeição da potência; ora, a perfeição
existe naquilo a que pertence. A segunda, naquilo mesmo que constitui um hábito operativo, como já
dissemos. Ora, toda operação procede da alma mediante alguma potência. A terceira, na disposição
para o que é ótimo; ora, este é o fim que é, ou uma operação do ser, ou algo consecutivo à operação
procedente da potência. Por onde, a virtude humana existe na potência da alma como sujeito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O termo — viver pode ser tomado em duplo sentido. Às
vezes significa o ser mesmo que vive, e assim, pertence à essência da alma, que é, para o vivente, o
princípio do existir. Outras vezes viver significa a operação do ser vivo, e assim vivemos retamente pela
virtude, enquanto que por ela obramos retamente.

RESPOSTA À SEGUNDA. — O bem ou é o fim ou é considerado como ordenado para o fim. Logo, como o
bem do operador consiste na operação, esse mesmo efeito da virtude, que é tornar bom o operador, é
relativo à operação, e por conseqüente à potência.

RESPOSTA À TERCEIRA. — Quando se diz que um acidente existe em outro como num sujeito isto não
significa que um, por si mesmo, pode sustentar outro, mas que um existe na substância mediante outro;
assim, a cor existe no corpo mediante a superfície, e por isso dizemos que esta é o sujeito da cor. E
desse mesmo modo, dizemos que a potência da alma é sujeito da virtude.

## Art. 2 — Se uma virtude pode existir em duas potências.
(Infra. Q. 60, ª 5: IV Sent., dist. XIV. Q. 1. a 3. qª 1: De Verit., q.14. ª 4. ad 7)
O segundo discute-se assim. — Parece que uma virtude pode existir em duas potências.

1. — Pois, os hábitos conhecem-se pelos atos. Ora, um mesmo ato procede diversamente de diversas
potências; assim, o ato de andar procede da razão como dirigente, da vontade como motora, e da
potência motiva como exeqüente. Logo, também o mesmo hábito da virtude pode existir em várias
potências.

2. Demais. — O Filósofo diz, que três elementos são exigidos pela virtude, que são: saber, querer e
operar imovelmente. Ora, saber é próprio do intelecto e querer, da vontade. Logo, a virtude pode existir
em várias potências.

3. Demais. — A prudência existe na razão, pois é a razão reta do que devemos praticar, como diz
Aristóteles. Logo, existe também na vontade, porque não pode ir junto com a vontade perversa, como
na mesma obra se diz. Logo, a mesma virtude pode existir em duas potências.
Mas, em contrário. — A virtude está na potência da alma como num sujeito. Ora, um mesmo acidente
não pode existir em vários sujeitos. Logo, a mesma virtude não pode existir em várias potências da alma.

SOLUÇÃO. — De dois modos pode uma realidade existir em duas outras. — De um modo, existindo em
ambas igualmente. Ora, assim é impossível uma virtude existir em duas potências, porque a diversidade
destas é considerada relativamente às condições gerais dos objetos; ao passo que a diversidade dos
hábitos é relativa às condições especiais dos mesmos; e assim, onde há diversidade de potências há
também a dos hábitos, mas não inversamente. — De outro modo, pode uma realidade existir em duas
ou várias outras, não igualmente, mas numa certa ordem. E assim, a mesma virtude pode pertencer a
várias potências, mas de maneira que pertença a uma, principalmente, e se estenda às outras a modo
de difusão ou disposição, sendo uma potência movida por outra, e sendo uma receptiva em relação à
outra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um mesmo ato não pode pertencer a diversas
potências, igualmente e na mesma ordem; mas, segundo razões e ordem diversas.

RESPOSTA À SEGUNDA. — A virtude moral preexige o saber porque obra segundo a razão reta. Mas,
essencialmente, a virtude moral se funda no apetite.

RESPOSTA À TERCEIRA. — A prudência, realmente, está na razão como no seu sujeito; mas, pressupõe a
retidão da vontade, como princípio, conforme a seguir se dirá.

## Art. 3 — Se o intelecto é o sujeito da virtude.
(III Sent. Dist. XXIII. q. 1, a. 4 qª 1., De Virtut., q. 1 a. 7; C.G. III, XXVI).
O terceiro discute-se assim. — Parece que o intelecto não é o sujeito da virtude.

1. — Pois, diz Agostinho, que toda virtude é amor. Ora, o sujeito do amor não é o intelecto, senão a
potência apetitiva. Logo, nenhuma virtude existe no intelecto.

2. Demais. — A virtude ordena-se para o bem, como do sobredito resulta. Ora, o bem é objeto, não do
intelecto, mas da potência apetitiva. Logo, o sujeito da virtude não é o intelecto, mas esta última
potência.

3. Demais. — A virtude torna bom quem a tem, como diz o Filósofo. Ora, o hábito, que aperfeiçoa o
intelecto, não torna bom quem o tem; pois, não é pela ciência nem pela arte que o homem é
considerado bom. Logo, o intelecto não é sujeito da virtude.
Mas, em contrário, a mente é, por excelência, considerada como intelecto. Ora, ela é o sujeito da
virtude, como é claro pela definição desta supra-referida. Logo, o intelecto é o sujeito da virtude.

SOLUÇÃO. — Como já dissemos, a virtude é um hábito pelo qual obramos retamente. Ora, de dois
modos um hábito pode ordenar-se ao ato reto. — De um modo, enquanto, por esse hábito, adquirimos
a faculdade de praticar o ato reto; assim, pelo hábito da gramática temos a faculdade de falar
retamente, embora a gramática não faça com que sempre falemos retamente, pois um gramático pode
cometer barbarismos ou solecismos. E o mesmo se pode dizer das outras ciências e artes. — De outro
modo, um hábito não só dá a faculdade de agir bem, mas ainda nos leva a usar retamente dessa
faculdade; assim, a justiça não só nos torna de vontade pronta a obrar justamente, mas também faz
com que obremos justamente. E como nada se chama bem, assim como ser absolutamente falando,
pelo que tem de potencial, senão enquanto atual, assim também tais hábitos levam o homem,
absolutamente, a obrar o bem e a ser bom; assim se dá com o que é justo temperante, ou tem virtudes
semelhantes. E, como a virtude torna bom quem a possui, e boa a sua obra, tais hábitos se chamam em
si mesmos, virtudes por tornarem boa a obra atualizada e bom, simplesmente, quem a pratica. Os
hábitos primeiros porém não se consideram em si mesmos, virtudes, por não tornarem boa à obra
senão de uma faculdade determinada; nem tornam simplesmente bons quem os possui. Assim, nenhum
homem é considerado absolutamente bom por ser sábio ou artífice, senão só relativamente, como bom
gramático ou bom ferreiro; e, por isto freqüentemente a ciência e a arte se opõem à virtude, e às vezes
se consideram virtudes, como já se disse.
Por onde, o sujeito do hábito considerado relativamente como virtude pode ser o intelecto, não só o
prático, mas também o especulativo, sem nenhuma ordenação relativa à vontade; e assim o
Filósofo considera a ciência, a sabedoria, a inteligência e mesmo a arte como virtudes intelectuais.
O sujeito do hábito porém, considerado absolutamente como virtude, não pode ser senão à vontade, ou
alguma potência movida por ela. E a razão é que a vontade move todas as demais faculdades, de certo
modo racionais, para os seus atos, como já dissemos. E portanto é por ter boa vontade que o homem
age bem. Logo, a virtude que nos leva a agir bem atualmente, e não só em possibilidade, é necessário
exista ou na vontade mesma, ou em alguma potência enquanto movida por esta.
Ora, o intelecto, como as demais potências, pode ser movido pela vontade, pois consideramos alguma
coisa atualmente porque queremos. E portanto, o intelecto, enquanto ordenado à vontade, pode ser
sujeito da virtude, em si mesma. E deste modo o intelecto especulativo ou razão é sujeito da fé, pois o
intelecto é movido a assentir ao que pertence à fé, pelo império da vontade, pois ninguém crê senão
porque quer. O intelecto prático, por seu lado, é sujeito da prudência. E como esta é a razão reta do que
devemos praticar, exige que o homem leve em conta os princípios dessa razão referentes ao que deve
praticar, que são os fins, aos quais ele bem se adapta pela retidão da vontade, assim como aos
princípios das coisas especulativas, pelo lume natural do intelecto agente. Por onde, assim como o
sujeito da ciência, que é a razão reta das coisas especulativas, é o intelecto especulativo, ordenado ao
intelecto agente, assim o sujeito da prudência é o intelecto prático, ordenado à vontade reta.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras de Agostinho devem entender-se da virtude
absolutamente considerada; não que toda virtude dessa natureza seja, absolutamente falando, amor,
mas porque depende dele de certo modo, enquanto depende da vontade, cujo primeiro afeto é o amor,
como já se disse.

RESPOSTA À SEGUNDA. — O bem de cada ser é o seu fim. E portanto, como a verdade é o fim do
intelecto, conhecê-la é o ato reto deste; por onde, o hábito, que aperfeiçoa o intelecto para conhecer a
verdade, tanto na ordem especulativa como na prática, chama-se virtude.

RESPOSTA À TERCEIRA. — A objeção colhe quanto à virtude absolutamente considerada.

## Art. 4 — Se o irascível e o concupiscível podem ser sujeitos da virtude.
(Infra, a. 5, ad 1; III Sent., dist. XXXIII, q. 2, a. 4, qª 2 ; De Verit. q. 24, a. 4, ad 9; De Virtut., q. 1, a. 10, ad
5).
O quarto discute-se assim. — Parece que o irascível e o concupiscível não podem ser sujeitos da
virtude.

1. — Pois, essas potências são comuns aos homens e aos brutos. Ora, por enquanto tratamos da virtude
própria ao homem, chamada por isso humana. Logo, o irascível e o concupiscível, partes do apetite
sensitivo, como já dissemos na Primeira Parte, não podem ser sujeitos da virtude.

2. Demais. — O apetite sensitivo é uma potência que se serve de órgão corpóreo. Ora, o bem da virtude
não pode ter sua sede no corpo do homem; pois diz o Apóstolo, (Rm 7,18): eu sei que na minha carne
não habita o bem. Logo, para apetite sensitivo não pode ser sujeito da virtude.

3. Demais. — Agostinho prova que a virtude não tem a sua sede no corpo, mas na alma, porque aquele
é governado por esta; e assim, é pela alma que usamos bem do corpo, do mesmo modo que eu sou a
causa de um auriga, que me obedece, dirigir bem os cavalos. Ora, assim como a alma rege o corpo,
assim também a razão o apetite sensitivo. Logo, é totalmente pela razão que o irascível e o
concupiscível são retamente governados. Ora, pela virtude é que vivemos retamente, como antes se
disse. Logo, não há virtude no irascível e no concupiscível, mas só na parte racional.

4. Demais. — O ato principal da virtude moral é a eleição, como já se disse. Ora, a eleição não pertence
ao irascível e ao concupiscível, mas à razão, como já se disse. Logo, a virtude moral pertence a esta e
não aqueles.
Mas, em contrário, atribuímos a fortaleza ao irascível e a temperança, ao concupiscível. E por isso o
Filósofo diz, que tais virtudes são próprias das partes irracionais.

SOLUÇÃO. — O irascível e o concupiscível são susceptíveis de dupla consideração. — Em si mesmos,
como partes do apetite sensitivo, e então não podem ser sujeitos da virtude. Ou como participantes da
razão, por lhes ser natural obedecer a ela. E assim podem ser sujeitos da virtude humana, pois enquanto
participantes da razão são princípio dos atos humanos.
E é necessário admitir a existência de virtudes nessas potências; pois é claro que elas aí existem. Porque
o ato procedente de uma potência movida por outra não pode ser perfeito sem ambas as potências
estarem bem dispostas ao ato; assim, o ato do artífice não pode ser congruente se ele não estiver bem
disposto a agir, assim como o seu instrumento. Por onde, para o irascível e o concupiscível, enquanto
movidos pela razão, operarem acertadamente, é necessário o hábito que os aperfeiçoa e leva a bem agir
existir, não só na razão, mas também neles. E como a boa disposição da potência motora e movida
depende da conformidade com a potência motora, a virtude do irascível e do concupiscível não é senão
uma conformidade habitual dessas potências com a razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O irascível e o concupiscível em si mesmos considerados,
como partes do apetite sensitivo, nos são comuns com os brutos. Mas enquanto racionais por
participação, por obedientes à razão, são potências próprias ao homem. E deste modo podem ser
sujeitos da virtude humana.

RESPOSTA À SEGUNDA. — Assim como o corpo do homem, não tendo por si mesmo o bem da virtude,
torna-se contudo instrumento de atos virtuosos, quando, pelo movimento da razão, aplicamos os
nossos membros a servir à justiça; assim também o irascível e o concupiscível não tem, certamente, por
si mesmos o bem da virtude, mas antes, a contaminação do fomes; quando, porém, se conformam com
a razão, gera-lhes o bem da virtude moral.

RESPOSTA À TERCEIRA. — De um modo é o corpo governado pela razão, e de outro por esta o irascível
e o concupiscível. — Pois, o corpo obedece ao nuto da alma, sem contradição, em tudo o que lhe é
natural ser movido por ela. Por onde, diz o Filósofo, que a alma rege o corpo com governo despótico, i.
é, como o senhor, o escravo. E portanto todo movimento do corpo é referido à alma, e por isso naquele
não há virtudes, mas só nesta. — O irascível e o concupiscível porém, não obedecem ao nuto da razão,
mas tem os seus movimentos próprios, às vezes, repugnantes à razão. Por isso no mesmo livro, o
Filósofo diz que a razão rege o irascível e o concupiscível com um governo político, como o pelo que se
governam seres livres, dotados em certos casos de vontade própria. E por isso é preciso haja no
concupiscível e no irascível certas virtudes pelas quais essas potências fiquem bem dispostas ao ato.

RESPOSTA À QUARTA. — Dois elementos há na eleição: a intenção do fim, pertencente à virtude moral;
e a aceitação prévia do conducente ao fim, pertencente à prudência, como já se disse. Ora, é pela boa
disposição do irascível e do concupiscível que a eleição nutre a intenção reta do fim, no atinente às
paixões da alma. E portanto as virtudes morais relativas às paixões tem sua sede no irascível e no
concupiscível; ao passo que a prudência é própria da razão.

## Art. 5 — Se nas potências sensitivas apreensivas internas pode haver virtude.
(Supra, q. 50, a . 3, ad 3; III Sent., dis. XXXIII, q. 2, a. 4, qª 2, ad 6; De Virtut., q. 1, a. 4, ad 6).
O quinto discute-se assim. — Parece que nas potências sensitivas internas pode haver virtude.

1. — Pois, o apetite sensitivo pode ser sujeito da virtude, enquanto obedece à razão. Ora, as potências
sensitivas apreensivas internas obedecem à razão; pois sob o império desta é que obra a imaginativa, a
cogitativa e a memorativa. Logo, nestas potências pode haver virtude.

2. Demais. — Assim como o apetite racional, que é à vontade, pode ter o seu ato impedido ou também
coadjuvado pelo apetite sensitivo, assim o intelecto ou razão pode ter o seu impedido ou, pelo
contrário, coadjuvado pelas preditas potências. E portanto, assim como pode haver virtude nas
potências sensitivas apetitivas, assim também o pode nas apreensivas.

3. Demais. — A prudência é uma virtude, da qual Túlio considera a memória como parte. Logo, também
a potência memorativa é susceptível de virtude. E pela mesma razão, as demais potências internas
apreensivas.
Mas, em contrário, todas as virtudes ou são intelectuais ou morais, como se disse. Ora, todas as virtudes
morais têm sua sede na parte apetitiva; e as intelectuais, por seu lado, no intelecto ou razão, como bem
se vê em Aristóteles. Logo, nenhuma virtude existe nas potências sensitivas apreensivas internas.

SOLUÇÃO. — Há certos hábitos existentes nas potências sensitivas apreensivas internas. O que se
evidencia, principalmente, pelo Filósofo dizer que por obra do costume, que é uma quase segunda
natureza, lembramo-nos das coisas umas depois das outras; pois, o hábito consuetudinal não é mais do
que um hábito adquirido pelo costume, que é uma quase natureza. Por isso, Túlio diz que a virtude é um
hábito, a modo de natureza, consentâneo com a razão. Ora, aquilo que a nossa memória ou as outras
virtudes sensitivas apreensivas adquirem por costume não é, em si mesmo, hábito, mas algo anexo aos
hábitos da parte intelectiva, como já dissemos antes.
Contudo, se alguns hábitos existem em tais potências, não se podem chamar virtudes. Pois, a virtude é
um hábito perfeito pelo qual não podemos obrar senão o bem. Por onde, necessariamente, a virtude há
de existir na potência que consuma a boa obra. Ora, o conhecimento da verdade não se consuma nas
potências sensitivas apreensivas, que são potências quase preparatórias do conhecimento intelectivo. E
portanto, não nessas potências, mas antes, no intelecto ou razão, é que existem as virtudes pelas quais
conhecemos a verdade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O apetite sensitivo se comporta para com a vontade,
que é apetite racional, como por ela movida. Portanto a obra da potência apetitiva se consuma no
apetite sensitivo, e por isso este é sujeito da virtude. — As virtudes sensitivas apreensivas, porém,
comportam-se antes como motoras, em relação ao intelecto, porque os fantasmas estão para a alma
intelectiva como as cores para a vista, conforme se disse. Logo, a atividade cognoscitiva termina no
intelecto, e por isso no intelecto ou razão é que têm sua sede as virtudes cognoscitivas.
E daqui consta com clareza à RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — A memória não é considerada parte da prudência, como a espécie o é do
gênero, quase como se fosse uma virtude, por si mesma; mas porque a bondade da memória é um
daqueles elementos exigidos para a prudência; de modo que ela se comporta como parte integrante.

## Art. 6 — Se a vontade é sujeito de alguma virtude.
(III Sent., dist. XXIII, q. 1, a. 4, qª 1; dist XXVII, q. 2, a. 3, ad 5.; De Verit., q. 24, a. 4, ad 9; De Virtut., q. 1,
a. 5; a. 12, ad 10; q. 2, a 2).
O sexto discute-se assim. — Parece que a vontade não é sujeito de nenhuma virtude.

1. — Pois, nenhum hábito é necessário no concernente a uma potência, em virtude da própria natureza
desta. Ora, a vontade, por sua própria natureza, fundando-se na razão, conforme o Filósofo, há de
tender ao bem racional, para o qual se ordenam todas as virtudes, porque cada ser naturalmente deseja
o próprio bem; ora, a virtude é um hábito, a modo da natureza, consentâneo com a razão, no dizer de
Túlio. Logo, a vontade não é sujeito da virtude.

2. Demais. — Toda virtude ou é intelectual ou é moral, como já se disse. Ora, a virtude intelectual tem
como sujeito o intelecto e a razão, mas não à vontade; a virtude moral, por outro lado, tem como
sujeito o irascível e o concupiscível, que são racionais por participação. Logo, nenhuma virtude tem a
vontade como sujeito.

3. Demais. — Todas os atos humanos, aos quais se ordenam as virtudes, são voluntários. Se pois há
alguma virtude na vontade, em relação a certos atos humanos, pela mesma razão haverá relativamente
a todos. E então, ou não haverá nenhuma virtude em nenhuma outra potência, ou duas virtudes hão-se
de ordenar a um mesmo ato; ora, isto é inadmissível. Logo, a vontade não pode ser sujeito da virtude.
Mas, em contrário, o motor exige maior perfeição que o movido. Ora, a vontade move o irascível e o
concupiscível. Logo, a virtude há de existir, com maior razão, na vontade, do que no irascível e no
concupiscível.

SOLUÇÃO. — Como o ato da potência se aperfeiçoa pelo hábito, ela precisa desse hábito que é uma
virtude, para bem agir com perfeição, quando para isso ela, pela sua própria natureza, não baste. Ora,
toda potência por natureza se ordena ao seu objeto. Por onde, sendo, como já se disse, o objeto da
vontade o bem da razão à vontade proporcionado, esta última não precisa, por este lado, da virtude que
aperfeiçoa. Mas dela precisa quando ao homem se lhe apresenta à vontade um bem que o excede, pela
desproporção, quer relativamente a toda a espécie humana, como o bem divino, que transcende os
limites da natureza humana, quer quanto ao indivíduo, como o bem do próximo. Por onde, tais virtudes,
como a caridade, a justiça e outras, que ordenam o afeto do homem para Deus ou para o próximo, tem
como sujeito a vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção tem cabido relativamente à virtude que
ordena ao bem próprio do sujeito que quer, como a temperança e a fortaleza, e outras semelhantes,
que versam sobre as paixões humanas, conforme do sobredito se colhe.

RESPOSTA À SEGUNDA. — Racional por participação não é só o irascível e o concupiscível, mas, em
absoluto, i. é, universalmente, o apetitivo, como já se disse. Ora, no apetitivo está compreendida a
vontade. E portanto, se há nesta alguma virtude, há de ser moral, se não for teológica, como a seguir se
demonstrará.

RESPOSTA À TERCEIRA. — Certas virtudes se ordenam ao bem da paixão moderada, o que é próprio a
cada homem em particular. E nessas não é necessário haver nenhuma virtude na vontade, pois, para tal,
basta à natureza da potência, como já se disse; senão só naquelas virtudes ordenadas a um bem
extrínseco.