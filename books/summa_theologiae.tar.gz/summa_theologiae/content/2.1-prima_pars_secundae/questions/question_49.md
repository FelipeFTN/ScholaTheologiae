# Questão 49: Da substância dos hábitos.
Sobre a primeira questão quatro artigos se discutem:

## Art. 1 — Se o hábito é uma qualidade.
(III. Sent., dist. XXIII, q. 1, a . 1; V Metaph., lect XX)
O primeiro discute-se assim. — Parece que o hábito não é uma qualidade.

1. — Pois, como diz Agostinho, a palavra hábito vem do verbo habere, que significa ter, e que se refere
não só à qualidade, mas também aos outros gêneros; assim, quando dizemos: ter quantidade, dinheiro
e coisas semelhantes. Logo, o hábito não é uma qualidade.

2. Demais — O hábito é considerado como um dos predicamentos, como diz Aristóteles. Ora, um
predicamento não pode estar contido em outro. Logo, o hábito não é uma qualidade.

3. Demais — Todo hábito é uma disposição, no dizer de Aristóteles. Ora, a disposição é a ordem do que
tem partes, como diz Aristóteles; o que pertence ao predicamento de lugar. Logo, o hábito não é uma
qualidade.
Mas, em contrário, o Filósofo diz, que o hábito é uma qualidade dificilmente mutável.

SOLUÇÃO. — O nome hábito é derivado do verbo latino habere, ter, e isto de duplo modo. Ou no
sentido em que dizemos tem o homem, ou qualquer outro ser, alguma coisa; ou porque um ser tem, em
si mesmo ou em relação a outro, um certo feitio.
Quanto ao primeiro sentido, devemos considerar que o verbo ter, significando uma coisa possuída, é
comum a diversos gêneros. Por isso, o Filósofo coloca o ter (habere) entre os postpredicamentos,
consecutivos aos diversos gêneros das coisas, como os contrários, a anterioridade, a posterioridade e
outros. — Mas entre as coisas que podem ser tidas há a distinção seguinte: certas não admitem nenhum
meio termo em relação a quem as tem; assim, não há nenhum meio termo entre o sujeito e a qualidade
ou a quantidade. Outras há, porém, entre as quais não há nenhuma mediação, mas só uma relação; tal
se dá, quando dizemos que alguém tem um companheiro ou um amigo. Por outro lado, coisas há dentre
as de que tratamos, que admitem um certo termo médio que não é, propriamente, ação nem paixão,
mas algo de comparável com elas; assim quando uma é o que orna ou cobre e outra, a ornada ou
coberta. Donde o dizer o Filósofo, que ter (hábito) exprime uma como ação entre o possuidor e a
coisa possuída, segundo se dá com aquilo que temos. E portanto, neste caso, constitui-se um gênero
especial chamado predicamento do hábito ou posse, a propósito do qual diz o Filósofo, que o hábito ou
posse é um termo médio entre um vestuário e quem o possui.
Se porém tomarmos a palavra ter (habere), no sentido de dizermos que uma coisa tem, em si mesma ou
relativamente a outra, um certo feitio, como este modo de ter-se a si mesmo se funda nalguma
qualidade, então o hábito é uma qualidade. E a este respeito diz o Filósofo: chama-se hábito uma
disposição em virtude da qual um ser é bem ou mal disposto, em si ou relativamente a outro; assim,
nesta acepção, a saúde é um hábito. Ora, como é neste sentido que agora tratamos do hábito, devemos
dizer que ele é uma qualidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procede quanto ao verbo ter tomado em
sentido geral, em que é comum a muitos gêneros, como já dissemos.

RESPOSTA À SEGUNDA. — A objeção procede quanto ao hábito entendido como meio termo entre o
possuidor e a coisa possuída, pois, nessa acepção, é um predicamento, como já se disse.

RESPOSTA À TERCEIRA. — Certamente que a disposição sempre implica uma ordem no ser que tem
partes. E isto pode dar-se de três maneiras, como no mesmo lugar o Filósofo logo acrescenta: local,
potencial ou especificamente. E nisto, no dizer de Simplício, compreende todas as disposições. As
corporais, quando diz —localmente, o que pertence ao predicamento de lugar, que é a ordem local das
partes. Quando diz potencialmente, aí inclui as disposições existentes em preparação e em capacidade e
ainda não perfeitas; tal é o caso da ciência e da virtude incoada. Quando por fim diz especificamente, aí
inclui as disposições perfeitas chamadas hábitos, como a ciência e a virtude completas.

## Art. 2 — Se o hábito é uma determinada espécie de qualidade.
(De Virtut., q. 1, a . 1).
O segundo discute-se assim. — Parece que o hábito não é uma determinada espécie de qualidade.

1. — Pois, como já se disse, o hábito, como qualidade, é uma disposição pela qual o sujeito fica bem ou
mal disposto. Ora, isto se dá em virtude de uma certa qualidade; assim pela figura, pelo calor, pelo frio e
por outros modos semelhantes é que um ser fica bem ou mal disposto. Logo, o hábito não é uma
determinada espécie de qualidade.

2. Demais — O Filósofo diz que a calidez e a frieza são disposições ou hábitos, como a doença e a saúde.
Ora, o calor e o frio pertencem à terceira espécie de qualidade. Logo, o hábito ou disposição não se
distingue das outras espécies de qualidade.

3. Demais — Ser dificilmente mutável não é uma diferença pertencente ao gênero da qualidade, mas
antes, ao movimento ou paixão. Ora, nenhum gênero se determina, relativamente à espécie, pela
diferença de outro gênero, mas é preciso que aquela se aplique, por si mesma, a este, como diz o
Filósofo. Logo, chamando-se ao hábito uma qualidade dificilmente mutável, resulta que não é uma
espécie determinada de qualidade.
Mas, em contrário, diz o Filósofo, que uma espécie de qualidade é o hábito e a disposição.

SOLUÇÃO. — Entre as quatro espécies de qualidade, o Filósofo considera como primeira a disposição e
o hábito. E Simplício explica as diferenças dessas espécies, dizendo que certas qualidades existentes
num sujeito por natureza e sempre, são naturais; outras porém, oriundas de uma causa extrínseca, e
que podem ser perdidas, chamam-se adventícias. E estas últimas, as adventícias, são hábitos e
disposições diferentes entre si por se poderem perder, umas, fácil e outras, dificilmente. Por outro lado,
das qualidades naturais umas se referem ao que é potencial, e tal é o caso da segunda espécie de
qualidade. Outras ao que é atual, e isto profunda ou superficialmente; no primeiro caso, temos a
terceira espécie de qualidade; no segundo, a quarta, como a figura, a forma, que é a figura do ser
animado. — Mas esta distinção das espécies de qualidade é inadmissível. Pois, há muitas figuras e
qualidades patíveis, não naturais, mas adventícias; e muitas disposições não adventícias, mas naturais,
como a saúde, a beleza e outras. E além disso, essa distinção não convém à ordem das espécies, pois
sempre o natural tem prioridade.
Por onde, devemos explicar de outro modo a distinção entre as disposições e os hábitos, e as outras
qualidades. Pois, propriamente, a qualidade implica um certo modo da substância. Ora, o modo é, no
dizer de Agostinho,prefixado pela medida, e portanto implica uma certa determinação de conformidade
com alguma medida. Por onde, assim como aquilo pelo que é determinada a potência da matéria, no
seu ser substancial, se chama qualidade, que é uma diferença da substância; assim, o que determina a
potência do sujeito, no seu ser acidental, chama-se qualidade acidental, que também é uma certa
diferença, como se vê claramente no Filósofo. Ora, o modo ou determinação do sujeito no seu ser
acidental, pode ser considerado ou em relação à natureza mesma do sujeito, ou relativamente à ação e
à paixão resultantes dos princípios da natureza, que são a matéria e a forma, ou em relação à
quantidade. — Se, pois, considerarmos o modo ou a determinação do sujeito, relativamente à
quantidade, vem ele a ser a quarta espécie de qualidade. E como a quantidade, por essência, não é
dotada de movimento e nem implica as noções de bem e de mal, não pertence à quarta espécie da
qualidade dispor alguma coisa bem ou mal nem fazer com que ela seja rápida ou lentamente mutável.
— Por outro lado, o modo ou a determinação do sujeito, quanto à ação e à paixão, constitui a segunda
ou a terceira espécie de qualidade. E por isso, numa e noutra se considera o fazer-se alguma coisa fácil
ou dificilmente, ou o mudar-se rápida ou diuturnamente; não se considera porém, no caso vertente,
nada que implica a noção de bem ou de mal, porque o movimento e a paixão, ao contrário do bem e do
mal, não implicam a noção de fim. — O modo, finalmente, e a determinação do sujeito em relação à
natureza da causa pertence à primeira espécie de qualidade, que é o hábito e a disposição. Pois, diz o
Filósofo, tratando dos hábitos da alma e do corpo, que eles são certas disposições, do que é perfeito,
para o que é ótimo; e denomino perfeito o que é disposto de conformidade com a natureza. E como a
forma em si mesma e a natureza da coisa é o fim e a causa pela qual alguma causa é feita, como diz
Aristóteles, por isso, na primeira espécie, incluímos o bem e o mal, e também o que é fácil e dificilmente
mutável, de conformidade com o que numa determinada natureza é o fim da geração e do movimento.
Por isso, o Filósofo define o hábito como uma disposição que nos torna bem ou mal dispostos; e diz mais
que pelos hábitos é que nos havemos bem ou mal, relativamente às paixões. Assim pois, o modo
conveniente à natureza de uma coisa é por essência bom; e é mau por essência o que lhe não convém. E
como a natureza é primariamente considerada, nas coisas, o hábito é tido como a primeira espécie de
qualidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A disposição implica uma certa ordem, como já
dissemos. E por isso não dizemos que alguém é disposto pela qualidade, senão em relação a alguma
coisa. E se acrescentarmosbem ou mal, o que implica a noção de hábito, é necessário levemos em conta
a ordem para a natureza, que é o fim. Por onde, não dizemos que alguém é bem ou mal disposto, pela
figura, ou pelo calor ou frio, senão relativamente à ordem para a natureza da coisa, de cuja ordem
depende a conveniência ou não conveniência. E por isso as próprias figuras e as qualidades passíveis,
consideradas como convenientes ou não convenientes à natureza da coisa, pertencem aos hábitos ou
disposições. Pois, enquanto convenientes à natureza da coisa, a figura e a cor se incluem na beleza; o
calor e o frio, na saúde. E deste modo a calidez e a frigidez o Filósofo as inclui na primeira espécie de
qualidade.
Donde se deduz clara a RESPOSTA À SEGUNDA OBJEÇÃO embora outros a resolvam diversamente,
como diz Simplício.

RESPOSTA À TERCEIRA. — A diferença — dificilmente mutável — não diversifica o hábito, das outras
espécies de qualidade, mas da disposição, que pode ser tomada em dupla acepção. Ou como um gênero
do hábito, pois Aristóteles a inclui na definição deste; ou como constituindo uma divisão oposta ao
hábito. E podemos entender que a disposição propriamente dita constitui uma divisão oposta ao hábito,
de duplo modo. Como o perfeito e o imperfeito, incluímos na mesma espécie; e então, por uma
denominação comum, chamaremos disposição ou que existe num sujeito imperfeitamente, de maneira
a poder ser perdido facilmente; e hábito ao que no sujeito existe perfeitamente, de maneira que não
possa ser facilmente perdido; e assim a disposição se transforma em hábito, como a criança em adulto.
De outro modo, podem ser distinguidos como espécies diversas de um gênero subalterno; e então
chamaremos disposições às qualidades da primeira espécie que podem, por natureza, perder-se
facilmente porque têm causas mutáveis, como a doença e a saúde. E reservamos o nome de hábitos às
qualidades, que por natureza não podem ser facilmente mutáveis, por terem causas imóveis, como as
ciências e as virtudes; e neste sentido a disposição não pode vir a ser um hábito. Esta doutrina parece
estar mais de acordo com a intenção de Aristóteles. Por isso, para provar tal distinção, apóia-se no uso
comum de falar, pelo qual as qualidades por natureza, facilmente mutáveis chamam-se hábitos quando,
por qualquer acidente, vêm a sê-lo dificilmente; e o inverso se dá com as qualidades dificilmente
mutáveis, por natureza, por natureza; assim, quem tiver a ciência tão imperfeitamente que possa
facilmente perdê-la, antes o consideramos como disposto para a ciência do que como possuidor dela.
Por onde é claro que o nome de hábito implica uma certa diuturnidade, o que se não dá com a
disposição. E nada impede que, neste sentido, o ser fácil edificilmente mutável sejam diferenças
específicas, por pertencerem à paixão e ao movimento e não, ao gênero da qualidade. Pois, essas
diferenças, embora sejam acidentais relativamente à qualidade, designam contudo, diferenças próprias,
e em si mesmas, das qualidade; assim como também, no gênero da substância, admitimos
freqüentemente diferenças acidentais, em lugar das substanciais, enquanto que, por elas, são
designados os princípios essenciais.
Art. 3 —Se o hábito implica ordenação para o ato.
O terceiro discute-se assim. — Parece que o hábito não implica ordenação para o ato.

1. — Pois, um ser age enquanto atual. Ora, o Filósofo diz: o hábito adquirido da ciência não exclui de nós
a potencialidade, embora diferente da que existia antes de sabermos. Logo, o hábito não implica relação
de princípio com o ato.

2. Demais — O que entra numa definição convém por si mesmo ao definido. Ora, está incluído na
definição de potência o ser princípio de ação, como se vê em Aristóteles. Logo, ser princípio do ato
convém, em si mesmo, à potência. Ora, o que é por si é princípio, em qualquer gênero. Se portanto, o
hábito é princípio do ato, segue-se que é posterior à potência e assim o hábito ou disposição não será a
primeira espécie de qualidade.

3. Demais — A saúde é, às vezes, um hábito, bem como a magreza e a beleza. Ora, estas últimas não se
chamam assim por se ordenarem ao ato. Logo, não é da natureza do hábito ser princípio do ato.
Mas, em contrário, diz Agostinho, que o hábito é o que leva um ser a agir, quando for preciso. E o
Comentador diz, que pelo hábito agimos quando queremos.

SOLUÇÃO. — Ordenar-se ao ato pode convir ao hábito tanto em razão dele próprio como em razão do
sujeito no qual existe.
No primeiro caso, convém a todo hábito ordenar-se, de certo modo, ao ato. Pois o hábito implica por
essência uma certa relação ordenada à natureza da coisa, enquanto lhe convém ou não. E a natureza da
coisa, por sua vez, que é o fim da geração, também se ordena a outro fim, que ou é uma operação ou
alguma obra a que chegamos pela operação. Por onde, o hábito não somente supõe uma ordenação à
natureza mesma da coisa, mas também e conseqüentemente à operação, enquanto fim da natureza, ou
conducente ao fim. E por isso, Aristóteles diz, definindo o hábito, que é uma disposição pela qual
ficamos bem ou mal dispostos, ou em nós mesmos, i. é, de conformidade com a nossa natureza,
ou relativamente a outra coisa, i. é, em ordem ao fim.
Há porém certos hábitos que, mesmo por parte do sujeito em que estão, implicam primária e
principalmente ordenação ao ato. Porque, como já dissemos, o hábito, primariamente e por si implica
relação com a natureza da coisa. Se portanto, a natureza da coisa, na qual existe o hábito, consiste
propriamente no mesmo ordenar-se ao ato, resulta que o hábito implica, principalmente essa mesma
ordenação. Ora, é manifesto, que é da natureza e da essência da potência ser princípio do ato. Donde,
todo hábito que pertence a alguma potência, como sujeito, implica principalmente ordenação ao ato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O hábito é um ato, como qualidade que é, e assim pode
ser princípio de operação. Mas, é potencial, relativamente à operação; e por isso é chamado ato
primeiro, sendo a operação chamada ato segundo, como se vê claramente.

RESPOSTA À SEGUNDA. — É da essência do hábito respeitar não à potência, mas à natureza. E como
esta precede a ação, a que respeita a potência, resulta que o hábito, como espécie de qualidade, tem
prioridade sobre a potência.

RESPOSTA À TERCEIRA. — A saúde é considerada um hábito ou disposição habitual em ordem à
natureza, como já dissemos. Como princípio do ato, porém e por conseqüência a natureza implica em se
lhe ordenar. E por isso o Filósofo diz, que consideramos são o homem, ou um membro
qualquer, quando pode obrar como são. E o mesmo se dá com os demais seres.

## Art. 4 — Se é necessário existir o hábito.
(III Sent., XXIII, q. 1, a . 1; De Verit., q. 20, a . 2; De Virtut., q. 1, a . 1).
O quarto discute-se assim. — Parece que não é necessário existir o hábito.

1. — Pois, pelos hábitos um ser fica bem ou mal disposto para alguma coisa, como já se disse. Ora, essa
boa ou má disposição os seres a têm da forma, pois por esta é que cada um deles tem a bondade e é
ente. Logo, não há nenhuma necessidade dos hábitos.

2. Demais — O hábito implica em ordenar-se para o ato. Ora, a potência implica em ser princípio
suficiente do ato, pois as potências, sem os hábitos, são princípios dos atos. Logo, não há necessidade
da existência daqueles.

3. Demais — O hábito se comporta do mesmo modo que a potência, em relação ao bem e ao mal; e
como a potência, também o hábito nem sempre age. Logo, a existência das potências torna supérflua a
do hábito.
Mas, em contrário, os hábitos são certas perfeições, como diz Aristóteles. Ora, a perfeição é sumamente
necessária, porque tem a natureza de fim. Logo, é necessária a existência dos hábitos.

SOLUÇÃO. — Como já dissemos, o hábito implica uma certa disposição ordenada à natureza da coisa e à
operação ou fim da mesma, e em virtude da qual um ser fica bem ou mal disposto para essa operação
ou esse fim. Porém para que um ser deva ser disposto para outro três condições são necessárias. —
Primeira, o que é disposto deve ser diferente daquilo a que é disposto e estar para este como a
potência, para o ato. Por onde, o ser que tiver a natureza não composta de potência e ato cuja operação
for substancial e em si mesmo subsistente não é susceptível de hábito ou disposição. — A segunda é
que o ser potencial possa ser determinado de vários modos e relativamente a vários atos. Por onde, o
que for potencial relativamente a um ato, e só a esse, não é susceptível de disposição nem de hábito,
porque um tal sujeito já tem, por natureza, a devida predisposição para um determinado ato. Assim, se
o corpo celeste for composto de matéria e de forma, como essa matéria não é potencial em relação a
mais de uma forma, segundo já dissemos na Primeira Parte, não será susceptível de disposição ou de
hábito relativamente à forma ou à operação, porque a natureza do corpo celeste não é potencial senão
a um movimento determinado. — A terceira é que vários elementos qualitativos concorram para dispor
o sujeito a um daqueles termos em relação ao qual é potencial e que podem ser proporcionados
diversamente entre si, de modo a ser ele bem ou mal disposto para a forma ou para a operação. Por
onde, as qualidades simples dos elementos, que, de um determinado modo lhes convêm às naturezas,
não as denominamos disposições ou hábitos. Denominamos porém assim a saúde, a beleza e atributos
semelhantes, que implicam uma certa proporção entre muitos elementos qualitativos, susceptíveis de
serem combinados de modos diversos. E por isto o Filósofo diz, que o hábito é uma disposição; e que a
disposição é a ordem do que tem parte, local, potencial ou especificamente, como já dissemos.
Por onde, como há muitos entes, para cujas naturezas e operações necessariamente concorrem muitos
elementos qualitativos, que podem ser combinados de diversos modos, é necessário existam os hábitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A natureza de um ser se aperfeiçoa pela forma; mas é
necessário que o sujeito se disponha, por alguma disposição ordenada a essa forma. Esta última por sua
vez se ordena ulteriormente à operação, que é o fim ou a via para ele. Se porém a forma for susceptível
de uma só operação determinada, não é necessária, para tal operação, além dessa forma, nenhuma
outra disposição. Se porém a forma for tal que possa operar de modos diversos, como é o caso da alma,
é necessário seja disposta para as suas operações por alguns hábitos.

RESPOSTA À SEGUNDA. — A potência às vezes é relativa a muitos atos, e, por isso, é necessário seja
determinada por outro ser. A potência porém que se não referir a muitos atos, não precisa de nenhum
hábito determinante, como já dissemos. E por isso as potências naturais não produzem as suas
operações mediante certos hábitos, porque já por si mesmas estão determinadas a um termo.

RESPOSTA À TERCEIRA. — Não é um mesmo hábito que se refere ao bem e ao mal, como a seguir se
dirá , ao contrário do que se dá com uma mesma potência. E portanto os hábitos são necessários para
determinarem as potências ao bem.