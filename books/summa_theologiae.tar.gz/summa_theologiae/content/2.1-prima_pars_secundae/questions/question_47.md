# Questão 47: Da causa eficiente da ira e dos seus remédios.
Em seguida devemos tratar da causa eficiente da ira e dos seus remédios. E sobre esta questão quatro
artigos se discutem:

## Art. 1 — Se sempre nos iramos por alguma coisa feita contra nós.
O primeiro discute-se assim. — Parece que nem sempre nos iramos por alguma coisa feita contra nós.

1. — Pois, pecando, nada podemos contra Deus, conforme a Escritura (Jó 35, 6): se as tuas iniqüidades
se multiplicarem, que farás tu contra ele? E contudo a Escritura também diz que Deus se ira contra os
homens, por causa dos pecados (Sl 105, 40): E se abrasou de furor o Senhor contra o seu povo. Logo,
nem sempre nos iramos por alguma coisa feita contra nós.

2. Demais — A ira é o desejo da vingança. Ora, podemos querer tirar vingança mesmo daquilo que é
feito contra outros. Logo, nem sempre o motivo da ira é o feito contra nós.

3. Demais — Como diz o Filósofo, iramo-nos principalmente contra os que desprezam aquilo com que
nos ocupamos de preferência; assim, os que se ocupam com a filosofia se iram contra os que a
desprezam; e o mesmo se dá com outras coisas. Ora, desprezar a filosofia não é fazer mal aos que com
ela se ocupam. Logo, nem sempre nos iramos contra aquilo que é feito contra nós.

4. Demais — Se calamos em face de quem nos injuria, mais lhe provocamos a ira, como diz Crisóstomo.
Mas, pelo fato de calarmos, nada fazemos contra ele. Logo, a ira nem sempre é provocada pelo que é
feito contra nós.
Mas, em contrário, diz o Filósofo: a ira provém sempre do feito contra nós; a inimizade porém, mesmo
que isso não se dê; assim, odiamos alguém só pelo reputarmos tal.

SOLUÇÃO. — Como já dissemos, a ira é o desejo de fazer mal a outrem, com fundamento na justiça
vindicativa. Ora, a vingança supõe sempre a injúria preexistente. Nem toda injúria porém provoca a
vindicta, senão só a que atinge o que deseja vingar-se; pois, assim como cada ser naturalmente deseja o
seu próprio bem, assim também naturalmente repele o próprio mal. Ora, a injúria que outrem nos faça
não nos atinge, se não fizer nada que seja contra nós. Donde se segue que o motivo da ira de alguém é
sempre alguma coisa contra ele feita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não se atribui a ira a Deus como paixão da alma, mas
como juízo da justiça, enquanto que quer tirar vingança do pecado. Pois, embora, pecando, não
possamos fazer mal a Deus efetivamente; contudo, por nossa parte, agimos de dois modos contra Ele.
Primeiro, porque o desprezamos nos seus mandamentos. Segundo, enquanto causamos algum mal a
outrem ou a nós mesmos, o que diz respeito a Deus, porque a pessoa a quem fizemos mal está sob a sua
providência e tutela.

RESPOSTA À SEGUNDA. — Iramo-nos contra aqueles que fazem mal aos outros; e desejamos tirar
vingança, enquanto aqueles a quem foi feito mal, de certo modo nos dizem respeito, quer por alguma
afinidade, quer pela amizade, ou ao menos por alguma comunhão de natureza.

RESPOSTA À TERCEIRA. — Aquilo por que sobretudo nos interessamos consideramos como bem nosso.
Por onde, quando isso é desprezado, consideramo-nos também como desprezados e lesados.

RESPOSTA À QUARTA. — Provocamos a ira de quem nos injuria, ficando calado, quando o fazemos por
desprezo, quase desdenhando a ira do mesmo. Ora, esse desdém já é, por si, um ato.

## Art. 2 — Se o contempto ou o desprezo é motivo de ira.
O segundo discute-se assim. — Parece que não só o contempto ou o desprezo é motivo da ira.

1. — Pois, como diz Damasceno, iramo-nos quando sofremos ou julgamos que sofremos alguma injúria.
Ora, podemos sofrer uma injúria mesmo sem contempto ou desprezo. Logo, nem só o desprezo é
motivo de ira.

2. Demais — Quem deseja a honra também sofre com o desprezo. Ora, os brutos não desejam a honra.
Logo, também não sofrem com o desprezo. E contudo, quando feridos, se lhes excita a ira, como diz o
Filósofo. Logo, nem só o desprezo é motivo da ira.

3. Demais — O Filósofo diz que há muitas outras causas da ira, p. ex.: o esquecimento, a exultação no
infortúnio, o anúncio dos males, o impedimento de realizar a vontade própria. Logo, nem só o desprezo
é que provoca a ira.
Mas, em contrário, diz o Filósofo, que a ira é o desejo da punição, acompanhado da pena, provocada por
um ostensivo desprezo, contrário à conveniência.

SOLUÇÃO. — Todas as causas da ira se reduzem ao desprezo. Ora, há três espécies de desprezo, como
diz o Filósofo, a saber: o desdém, o epereasmus, i, é, o impedimento de realizarmos a vontade própria e
acontumélia. E a estas três se reduzem todos os motivos da ira, podendo-se dar disso dúplice razão.
A primeira é que a ira deseja o mal de outrem, enquanto fundada na justiça vindicativa; e por isso, busca
a vingança na medida mesma em que esta é considerada justa. Ora, não podemos tirar vingança justa
senão daquilo que foi injustamente feito; e, portanto, o que provoca a ira é sempre algo considerado
como injusto. Donde o dizer o Filósofo que os homens não haveriam de irar-se se considerassem como
justo o que sofreram dos que os lesaram; pois, não há ira contra o que é justo. Ora, podemos causar mal
a outrem de três modos: por ignorância, paixão e eleição. Assim, cometemos a máxima injustiça
quando, por eleição, indústria, ou com determinada malícia, causamos mal a outrem, como diz
Aristóteles. Por onde, iramo-nos sobretudo contra aqueles que consideramos como nos tendo feito mal
de caso pensado. Não nos iramos porém, ou iramo-nos pouco, contra aqueles que nos fizeram alguma
injuria, em nosso sentir, por ignorância ou paixão. Pois, agir por ignorância ou paixão diminui a injúria e
provoca, de certo modo, a misericórdia e o perdão. Pois, consideramos como tendo pecado por
desprezo os que, por indústria, nos causam mal, e por isso nos irritamos sobretudo contra eles. Por
onde, diz o Filósofo, que não nos iramos, ou iramo-nos pouco, contra os que, por cólera, nos fizeram
algum mal, pois não os consideramos como tendo agido por desprezo.
A segunda razão é que o desprezo se opõe à excelência do homem; pois desprezamos aquilo a que não
damos nenhum valor. Ora, com todos os nossos bens pretendemos a uma certa excelência. Por onde, os
que nos ofendem consideramo-los como atacando a nossa excelência e como manifestando, portanto, o
desprezo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando sofremos uma injúria proveniente de qualquer
causa que não o desprezo, essa causa a diminui. Ao passo que só o desprezo ou contempto aumenta a
ira, e portanto, é por si mesmo causa de nos irarmos.

RESPOSTA À SEGUNDA. — Embora o bruto não deseje a honra como tal, deseja contudo naturalmente
uma certa excelência, e se ira contra o que se opõe a tal excelência.

RESPOSTA À TERCEIRA. — Todas as causas que a objeção refere se reduzem a um certo desprezo. —
Assim, o esquecimento é evidente sinal de desprezo; pois, ao que damos grande valor fixamos mais
profundamente na memória. — Semelhantemente, por um certo desprezo é que não tememos
penalizar a outrem, anunciando-lhe coisas tristes. — Por outro lado, quem, mesmo no infortúnio de
outrem, dá sinais de hilaridade, mostra que pouco se lhe importa com o bem ou o mal. — E por fim,
quem nos impede realizarmos o nosso propósito, e não por qualquer utilidade que disso lhe advenha,
não demonstra curar muito da nossa amizade. — Por onde, tudo isso significando desprezo, provoca a
ira.

## Art. 3 — Se a nossa excelência é a causa de nos irarmos mais facilmente.
O terceiro discute-se assim. — Parece que a nossa excelência não é a causa de nos irarmos mais
facilmente.

1. — Pois, como diz o Filósofo, certos, como os enfermos, os necessitados e os que não obtêm o que
desejam ficam mais irados, quando ofendidos. Ora, tudo isto parece supor uma certa deficiência. Logo,
esta, mais que a excelência, nos torna inclinados à ira.

2. Demais — No mesmo passo diz o Filósofo, que nós nos iramos, sobretudo, quando os outros nos
desprezam suspeitando não tenhamos uma determinada qualidade, ou apenas diminutamente; mas,
isso não nos importa, pois nos julgamos excelentes relativamente aquilo mesmo por que nos
desprezam. Ora, o desprezo em questão se funda numa deficiência. Logo, esta é, mais que a excelência,
causa de nos irarmos.

3. Demais — Tudo o concernente à excelência é o que sobretudo torna os homens alegres e
esperançosos. Ora, o Filósofo diz, que os homens não se iram quando se divertem, riem, vão a festas,
gozam da prosperidade, realizam seus planos, se deleitam com o que não é torpe e vivem esperançosos.
Logo, a excelência não é causa da ira.
Mas, em contrário, diz o Filósofo, que a excelência é causa de os homens ficarem indignados.

SOLUÇÃO. — De dois modos podemos considerar a causa da ira, no irado. — Primeiro, relativamente ao
motivo dela; e, então a excelência é causa de nos irarmos facilmente. Pois, o motivo da ira é o injusto
desprezo, como já dissemos. Ora, é claro que quanto mais excelentes formos, tanto mais injustamente
seremos desprezados, naquilo por que excelemos. Por onde, os que têm alguma excelência ficam
sobretudo irados quando os desprezamos; p. ex., quando desprezamos o rico no seu dinheiro, o orador
na sua eloqüência e assim por diante. — De outro modo, relativamente à disposição que o desprezo
causa em nós. Pois, como é manifesto, o que nos move à ira não é senão a ofensa, que nos punge. Ora,
é por algum defeito que sobretudo sofremos, pois facilmente nos ofendemos pelos defeitos que temos.
E esta é a causa de os fracos, ou os que têm outras deficiências, irarem-se mais facilmente; pois, mais
facilmente se ofendem.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Quem é desprezado naquilo mesmo por onde é manifestamente excelente,
como julga não padecer com isso nenhum detrimento, não sofre, e por isso não se ira. Mas, por outro
lado, por ser mais indignamente desprezado tem maior razão de se irar, a menos que não se julgue
objeto de zombaria e escárneo, não por desprezo, mas por ignorância ou coisa semelhante.

RESPOSTA À TERCEIRA. — Tudo o que a objeção enumera trava a ira na medida em que impede o
sofrimento. Mas por outro lado, provoca naturalmente a ira, fazendo com que sejamos desprezados
mais inconvenientemente.

## Art. 4 — Se uma deficiência é causa de mais facilmente nos irarmos contra outrem.
O quarto discute-se assim. — Parece que uma deficiência não é causa de mais facilmente nos irarmos
contra outrem.

1. — Pois, como diz o Filósofo, não nos iramos contra os que confessam o mal que fizeram, dele se
arrependem e se humilham; antes, somos brandos para com eles. Assim também os cães não mordem
os que estão sentados. Ora, isto supõe fraqueza e deficiência. Logo, a fraqueza é causa de não nos
irarmos contra outrem.

2. Demais — Não há deficiência maior que a morte. Ora, para com os mortos cessa a ira. Logo, a
deficiência de uma pessoa não é causa de nos irarmos contra ela.

3. Demais — Não julgamos que alguém valha pouco por ser nosso amigo. Ora, ofendemo-nos,
sobretudo, quando os amigos nos fazem mal ou não nos ajudam; e por isso diz a Escritura (Sl 54,
13): Porque se o meu inimigo houvera falado mal de mim, eu o houvera sofrido por certo. Logo, a
deficiência não é causa de nos irarmos contra ninguém.
Mas, em contrário, diz o Filósofo, o rico se ira contra o pobre, que o despreza, e o chefe, contra o
súbdito.

SOLUÇÃO. — Como já dissemos, o desprezo imerecido é o que sobretudo provoca a ira. Por onde, a
deficiência ou a fraqueza daquele contra quem estamos irados contribui para o aumento da ira,
enquanto aumenta o desprezo imerecido. E assim, quanto maior for alguém tanto mais será
imerecidamente desprezado; e quanto menor, tanto mais imerecidamente despreza. Por isso os nobres
se iram quando desprezados pelos rústicos; bem como os sábios, quando o são pelos ignorantes e os
senhores, pelos servos.
A fraqueza porém ou a deficiência, que diminui o desprezo imerecido não aumenta, mas diminui a ira. E
deste modo, os que se arrependem das injúrias feitas, confessam o mal praticado, se humilham e
pedem perdão mitigam a ira, conforme aquilo da Escritura (Pr 15, 1): A resposta branda quebra a ira.
Porque vemos que esses tais não desprezam, mas antes, estimam aqueles ante quem se humilham.
E daqui se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — É dupla a causa porque cessa a ira em relação aos mortos. Primeiro por não
poderem sofrer e sentir, o que sobretudo desejam os irados em relação aos de quem têm ira. Segundo,
por vermos que já sofreram o último dos males. Por isso a ira também cessa relativamente aos que já
sofreram graves penas, por exceder o mal deles a medida da justa retribuição.

RESPOSTA À TERCEIRA. — O desprezo dos amigos está em o número dos mais imerecidos. Por isso, por
semelhante causa, mais nos iramos contra eles, se nos desprezarem, quer nos fazendo mal, ou não nos
auxiliando, assim como contra os que nos são inferiores.