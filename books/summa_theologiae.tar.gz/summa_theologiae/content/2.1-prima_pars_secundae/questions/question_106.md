# Questão 106: Da lei do Evangelho, chamada nova, em si mesma
considerada.
Em seguida devemos tratar da lei do Evangelho, chamada lei nova. E primeiro, em si mesmo
considerada. Segundo, comparada com a lei antiga. Terceiro, do que a lei nova contém.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se a lei nova é uma lei escrita. [Art. Seq.; q. 107, a. 1, ad 2, 3; q. 108, a. 1. II Cor., cap. III, lect, II; Ad Hebr., cap. VIII, lect. II].
O primeiro discute-se assim. — Parece que a lei nova é uma lei escrita.

1. — Pois, a lei nova é o Evangelho mesmo. Ora, este é escrito (Jo 20, 31): Mas, foram escritas estas
coisas, afim de que vos creiais. Logo, a lei nova é uma lei escrita.

2. Demais. — A lei infusa é a da natureza, conforme a Escritura (Rm 2, 14-15): Naturalmente fazem as
coisas que são da lei os que mostram a obra da lei escrita nos seus corações. Se pois a lei do Evangelho
fosse infusa, não diferiria da lei natural.

3. Demais. — A lei do Evangelho é própria dos que vivem no regime do Novo Testamento. Ora, a lei
infusa é comum tanto a esses como aos que viveram no regime do Velho Testamento. Pois, diz a
Escritura (Sb 7, 27), que a divina Sabedoria, pelas nações, se transfunde nas almas santas, forma os
amigos de Deus e os profetas. Logo, a lei nova não é uma lei infusa.
Mas, em contrário, a lei nova é a lei do Novo Testamento. Ora, esta é infusa no coração. Pois, o
Apóstolo, citando a autoridade da Escritura (Jr 31, 31-33) — Eis aí virão os dias, diz o Senhor, e farei
nova aliança com a casa de Israel e com a casa de Judá — e expondo qual seja essa aliança, diz (Heb 8, 8-
10): Porque este é o testamento que ordenarei à casa de Israel, imprimindo as minhas leis na mente
deles, e as escreverei sobre o seu coração. Logo, a lei nova é infusa.

SOLUÇÃO. — Todo ser é considerado como sendo o que nele é principal, consoante o Filósofo. Ora, o
que há de principal na lei do Novo Testamento, e no que consiste toda a sua virtude, é a graça do
Espírito Santo, dada pela fé em Cristo. Por onde, a lei nova é principalmente a graça mesma do Espírito
Santo, dada aos fiéis de Cristo. E isto se torna manifesto pelas palavras do Apóstolo (Rm 3, 27): Onde
está o motivo de te gloriares? Todo ele foi excluído. Por que lei? Pela das obras? Não, mas pela lei da
fé — chamando, assim, lei à graça mesma da fé. E mais expressamente (Rm 8, 2): A lei do espírito de
vida em Jesus Cristo me livrou da lei do pecado e da morte. Por isso diz Agostinho, que, assim como a lei
das ações foi escrita em tábuas de pedra, assim, a lei da fé o foi nos corações dos fiéis. E noutro lugar do
mesmo livro: Que são as leis de Deus por Ele próprio escritas nos corações, senão a presença mesma do
Espírito Santo?
Contudo, a lei nova encerra certos preceitos como que secundários disponentes à graça do Espírito
Santo e ao uso dessa graça. E sobre eles era necessário que os fiéis de Cristo fossem instruídos por
palavras e escrituras, tanto em relação ao que devem crer como ao que devem agir.
Por onde, devemos dizer, que a lei nova é principalmente uma lei infusa; e, secundariamente, uma lei
escrita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O escrito nos Evangelhos não contém senão o que diz
respeito à graça do Espírito Santo, quer dispondo, quer ordenando para o uso dessa graça. Dispondo o
intelecto pela fé, pela qual se obtém a graça do Espírito Santo, o Evangelho encerra o concernente à
manifestação da divindade ou da humanidade de Cristo. Quanto ao afeto, ele contém a atinente ao
desprezo do mundo, que torna o homem capaz da graça do Espírito Santo; pois, o mundo, i. é, os
amantes do mundo, não pode receber o Espírito Santo, como diz a Escritura (Jo 14, 17). Quanto ao uso
da graça espiritual, ele consiste nos atos virtuosos, aos quais freqüentemente o escrito do Novo
Testamento exorta os homens.

RESPOSTA À SEGUNDA. — De dois modos pode haver algo de infuso no homem. — Primeiro, como
fazendo parte da natureza humana. E nesse sentido a lei natural é nela infusa. — De outro modo, como
lhe sendo acrescentado à natureza pelo dom da graça. E deste modo a lei nova é infusa no homem, e
indica não só o que ele deve fazer, mas também o ajuda a cumprir a lei.

RESPOSTA À TERCEIRA. — Ninguém nunca teve a graça do Espírito Santo, senão por fé explícita ou
implícita em Cristo. Ora, pela fé em Cristo o homem pertence ao Novo Testamento. Por onde, aqueles a
quem foi infundida a lei da graça pertenciam ao Novo Testamento.

## Art. 2 — Se a lei nova justifica.
O segundo discute-se assim. — Parece que a lei nova não justifica.

1. — Pois, ninguém se justifica sem obedecer à lei de Deus, conforme a Escritura (Heb 5, 9): Cristo veio a
fazer-se autor da salvação eterna para todos os que lhe obedecem. Ora, o Evangelho nem sempre
consegue que todos lhe obedeçam, consoante a Escritura (Rm 10, 16): Nem todos obedecem ao
Evangelho. Logo, a lei nova não justifica.

2. Demais. — O Apóstolo prova que a lei antiga não justificava, pois, na vigência dela, aumentou a
prevaricação. Assim, diz (Rm 4, 15): A lei obra ira; por quanto onde não há lei não há transgressão. Ora,
a lei nova é causa de muitas outras prevaricações; pois é digno de maior pena quem ainda peca, no
regime da lei nova, conforme a Escritura (Heb 10, 28-29): Se alguém quebranta a lei de Moisés, sendo-
lhe provado com duas ou três testemunhas, morre sem dele se ter comiseração alguma, pois, quanto
maiores tormentos credes vós que merece o que pisar aos pés ao Filho de Deus? etc. Logo, como a
antiga, também a lei nova não justifica.

3. Demais. — Justificar é efeito próprio de Deus, conforme aquilo da Escritura (Rm 8, 33): Deus é o que
justifica. Ora, tanto a lei antiga como a nova foram dadas por Deus. Logo, esta não justifica, mais que
aquela.
Mas, em contrário diz o Apóstolo (Rm 1, 16): Eu não me envergonho do Evangelho; porquanto a virtude
de Deus é para dar a salvação a todo o que crê. Logo há salvação só para os justificados. Logo, a lei do
Evangelho justifica.

SOLUÇÃO. — Como já dissemos (a. 1), duas coisas encerra a lei do Evangelho. — Uma principal, que é a
graça do Espírito Santo dada interiormente. E neste respeito, a lei nova justifica. Por isso, Agostinho diz:
Lá, i. é, no Antigo Testamento, a lei foi posta extrinsecamente, para que os injustos se aterrorizassem;
aqui, i. é, no Novo Testamento, foi dada intrinsecamente, para que se justificassem — Secundariamente,
pertencem à lei do Evangelho os ensinamentos da fé e os preceitos, que ordenam os afetos e os atos
humanos. E neste respeito, a lei nova não justifica. Por isso o Apóstolo diz (2 Cor 3, 6): A letra mata e o
espírito vivifica. E como expõe Agostinho, pela letra se entende qualquer escritura existente
independentemente dos homens, mesmo a dos preceitos morais, tais como estão contidos no
Evangelho. Por onde, mesmo a letra do Evangelho mataria se não existisse interiormente a graça, que
salva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe, quanto à lei nova; não quanto ao que
nela é principal, senão quanto ao secundário. Isto é, quanto aos ensinamentos e preceitos
extrinsecamente dados ao homem, por escrito ou verbalmente.

RESPOSTA À SEGUNDA. — A graça do Novo Testamento, embora ajude o homem a não pecar, todavia
não o confirma no bem, de modo a não poder mais pecar; pois isto é próprio do estado da glória. Por
onde, quem pecar, depois de ter recebido a graça do Novo Testamento, é digno de maior pena, como
ingrato a maiores benefícios e como não tendo usado do auxílio que lhe foi dado. Mas nem por isso se
diz que a lei nova produz a ira; pois em si mesma dá auxílio suficiente para o homem não pecar.

RESPOSTA À TERCEIRA. — O mesmo Deus deu a lei nova e a antiga, mas diferentemente. Pois, a antiga
deu-a escrita em tábuas de pedra; a nova, porém, em tábuas de carne do coração. Por onde, diz
Agostinho: O Apóstolo denomina essa lei literal, escrita fora do homem, transmissora da morte e da
condenação. Ao passo que à lei do Novo Testamento a considera transmissora do espírito e da justiça.
Porque, pelo dom do Espírito, praticamos a justiça e nos livramos de ser condenados por prevaricação.

## Art. 3 — Se a lei nova devia ter sido dada desde o princípio do mundo. [Supra, q. 96, a. 5, ad 2].
O Terceiro discute-se assim. — Parece que a lei nova devia ter sido dada desde o princípio do mundo.

1. — Pois, não há para com Deus acepção de pessoas, como diz a Escritura (Rm 2, 11). Ora, todos os
homens pecaram e necessitam da glória de Deus, segundo o Apóstolo (Rm 3, 23). Logo, a lei do
Evangelho devia ter sido dada desde o princípio do mundo, para que socorresse a todos.

2. Demais. — Tanto em lugares como em tempos diversos os homens são diversos. Ora, Deus, que quer
que todos os homens se salvem, mandou fosse o Evangelho pregado em todos os lugares, como está
claro na Escritura (1 Tm 2, 4). Logo, a lei do Evangelho devia ter existido em todos os tempos, e
portanto, dada desde o princípio do mundo.

3. Demais. — A salvação espiritual, sendo eterna, é mais necessária ao homem que a saúde corpórea,
que é temporal. Ora, Deus desde o princípio do mundo, providenciou sobre o necessário à saúde do
corpo submetendo ao homem todos os seres, por causa dele criados, como se lê na Escritura (Gn 1, 26-
29). Logo, também a lei nova necessária por excelência à salvação espiritual, devia ter sido dada aos
homens desde o princípio do mundo.
Mas, em contrário, diz o Apóstolo (1 Cor 15, 46): Não primeiro o que é espiritual, senão o que é animal.
Ora, a lei nova é por excelência espiritual. Logo, não devia ter sido dada desde o princípio do mundo.

SOLUÇÃO. — Pode-se dar tríplice razão de não ter sido a lei nova dada desde o princípio do mundo. — A
primeira é que, como já dissemos (a. 1), a lei nova consiste principalmente na graça do Espírito Santo,
que não devia ser dada abundantemente, antes de ter sido o gênero humano livrado do pecado, depois
de consumada a redenção de Cristo. Por isso, diz a Escritura (Jo 7, 39): Ainda o Espírito Santo não fora
dado, por não ter sido ainda glorificado Jesus. E esta razão o Apóstolo a assinala manifestamente,
quando acrescenta, depois de ter tratado da lei do Espírito Santo (Rm 8, 2 ss): Enviando Deus a seu filho
em semelhança de carne de pecado, ainda do pecado condenou ao pecado na carne, para que a
justificação da lei se cumprisse em nós.
A segunda razão pode ser tirada da perfeição da lei nova. Pois nada alcança imediatamente, desde a
origem, um estado perfeito; se não depois de uma certa ordem sucessiva no tempo. Assim, primeiro
somos crianças, e depois homem. E esta razão o Apóstolo a assinala, quando diz (Gl 3, 24-25): A lei nos
serviu de pedagogo, que nos conduziu a Cristo, para sermos justificados pela fé; mas, depois que veio a
fé, já não estamos debaixo do pedagogo.
A terceira se funda em ser a lei nova a lei da graça. Por onde, era primeiro necessário fosse o homem
abandonado a si mesmo, no regime da lei antiga, para que, caindo no pecado e conhecendo a sua
fraqueza, reconhecesse a necessidade da graça. E nesta razão toca o Apóstolo, quando diz (Rm 5,
20): Sobreveio a lei para que abundasse o pecado, mas onde abundou o pecado, superabundou a graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O gênero humano mereceu, por causa do seu primeiro
pai, ser privado do auxílio da graça. E assim, este não é dado a uns, por justiça, e o é a outros, por graça,
como diz Agostinho. Por onde, Deus não faz acepção de pessoas, por não ter desde o princípio do
mundo proposto a todos a lei da graça, que devia ser proposta na ordem devida.

RESPOSTA À SEGUNDA. — A diversidade dos lugares não faz variar a diversidade dos estados do gênero
humano, que varia conforme a sucessão dos tempos. Por isso, a lei nova é proposta para todos os
lugares, mas não, para todos os tempos. Embora em todos existissem certos homens pertencentes ao
Novo Testamento, como já dissemos (a. 1, ad 3).

RESPOSTA À TERCEIRA. — O que respeita à saúde do corpo serve ao homem, em virtude da natureza,
que não é destruída pelo pecado. Ao passo que o atinente à saúde espiritual se ordena para a graça, que
se perde pelo pecado. Portanto, os casos não são idênticos.

## Art. 4 — Se a lei nova há de durar até o fim do mundo.
O quarto discute-se assim. — Parece que a lei nova não há de durar até o fim do mundo.

1. — Pois, como diz o Apóstolo (1 Cor 13, 10), quando vier o que é perfeito, abolido será o que é em
parte. Ora, a lei nova é em parte, conforme diz o mesmo (1 cor 13, 9): Em parte conhecemos e em parte
profetizamos. Logo, a lei nova deve ser abolida, sucedendo-lhe um estado mais perfeito.

2. Demais. — O Senhor prometeu aos seus discípulos (Jo 16, 13), com o advento do Espírito Santo
Paráclito, o conhecimento de toda a verdade. Ora, a Igreja ainda não conhece toda a verdade, no regime
do Novo Testamento. Logo, devemos esperar outro estado, em que toda a verdade será manifestada
pelo Espírito Santo.

3. Demais. — Assim como o Pai difere o Filho e o Filho do Pai, assim o Espírito Santo, do Pai e do Filho.
Ora, houve um estado conveniente à pessoa do Pai, i. é, o do regime da lei antiga, em que os homens
punham o fito na geração. Semelhantemente, há outro estado conveniente à pessoa do Filho, i. é, o
estado da lei nova, em que dominam os clérigos, que buscam a sabedoria, apropriada ao Filho. Logo,
haverá um terceiro estado, o do Espírito Santo, em que dominarão os varões espirituais.

4. Demais. — O Senhor diz (Mt 24, 14): Será pregado este Evangelho do reino por todo o mundo, e
então chegará o fim. Ora, o Evangelho de Cristo, já há tanto tempo é pregado por todo o mundo, e
contudo ainda não chegou o fim. Logo, o Evangelho de Cristo não é o Evangelho do reino, mas há de
haver outro Evangelho, o do Espírito Santo, que será como que outra lei.
Mas, em contrário, diz o Senhor (Mt 24, 34): Digo-vos que não passará esta geração, sem que se
cumpram todas estas coisas; o que Crisóstomo entende da geração dos fiéis de Cristo. Logo, o estado
dos fiéis de Cristo permanecerá até a consumação dos séculos.

SOLUÇÃO. — O estado do mundo pode variar de dois modos. — Primeiro, pela diversidade das leis. E
assim, ao regime atual da lei nova não sucederá nenhum outro estado. Pois, o regime da lei nova
sucedeu ao da lei antiga, como sucede o mais perfeito ao menos perfeito. Ora, nenhum estado da vida
presente pode ser mais perfeito que o da lei nova. Porque nada pode ser mais próximo do fim último do
que aquilo que leva imediatamente para ele. Mas é isso o que faz a lei nova. Donde o dizer o Apóstolo
(Heb 10, 19-22): Portanto, irmãos, tendo confiança de entrar no santuário pelo sangue de Cristo,
acheguemo-nos ao caminho novo, que ele nos abriu. Por onde, não pode haver na vida presente
nenhum estado mais perfeito do que o da lei nova; porque há tanto maior perfeição quanto mais
proximidade houver do fim último. — De outro modo, o estado dos homens pode variar conforme eles
se comportam mais ou menos perfeitamente, em relação a uma mesma lei. E assim, o regime da lei
antiga mudou freqüentemente; pois, ora, as leis eram otimamente guardadas; ora, absolutamente
abandonadas. Assim como também o regime da lei nova se diversifica pelos diversos lugares, tempos e
pessoas, enquanto que a graça do Espírito Santo é mais ou menos perfeitamente aproveitada. Por onde,
não se deve esperar nenhum estado futuro em que a graça do Espírito Santo seja aproveitada mais
perfeitamente do que até agora o foi; e sobretudo, pelos Apóstolos, que receberam as primícias do
Espírito, i. é, com prioridade no tempo e mais abundantemente que os outros, como diz o Glosa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Segundo Dionísio, tríplice é o estado dos homens:
primeiro, o da lei antiga; segundo o da lei nova; terceiro, o que virá, não nesta vida, mas na futura, i. é,
na pátria celeste. Ora, assim como o primeiro estado foi figurado e imperfeito, em relação ao do
Evangelho; assim, o atual é figurado e imperfeito, em relação ao da pátria celeste, que, quando chegar,
abolirá aquele, conforme a Escritura (1 Cor 13, 12): Agora vemos como por um espelho, em enigmas;
mas então face a face.

RESPOSTA À SEGUNDA. — Como diz Agostinho, Montano e Priscila afirmavam, que a promessa do
Senhor, de dar o Espírito Santo, não se cumpriu nos Apóstolos, mas neles. E semelhantemente, os
Maniqueus, que se cumpriu em Maniqueu, que diziam ser o Espírito Paráclito. Por isso uns e outros não
admitiam os Atos dos Apóstolos, onde está manifesto, que a promessa se cumpriu nos Apóstolos. Assim
o Senhor repetidamente o prometeu (At 1, 5): vós sereis batizados no Espírito Santo, não muito depois
destes dias, que se completaram, como se lê no mesmo livro. Mas essas pretensões se excluem pelo que
diz o Evangelho (Jo 7, 39): Ainda o Espírito Santo não fora dado, por não ter sido ainda glorificado Jesus.
Por onde se dá a entender, que, logo depois de Jesus glorificado, na ressurreição e na ascensão, foi dado
o Espírito Santo. Ora, o Espírito Santo ensinou aos Apóstolos todas as verdades necessárias à salvação, a
saber, relativas ao que devemos saber e praticar. Mas não lhes ensinou sobre todos os acontecimentos
futuros, pois isso não lhes importava saber, conforme diz a Escritura (At 1, 7): Não é da vossa conta
saber os tempos nem momentos, que o Padre reservou ao seu poder.

RESPOSTA À TERCEIRA. — A lei antiga, era, não só do Pai, mas também do Filho, porque Cristo estava
nelas figurado. Por isso, diz o Senhor (Jo 5, 46): Se vós crêsseis a Moisés, certamente me creríeis
também a mim, porque ele escreveu de mim. Semelhantemente, também a lei nova não é somente de
Cristo, mas ainda do Espírito Santo, conforme aquilo (Rm 8, 2): A lei do Espírito de vida em Jesus Cristo,
etc. Por onde, não devemos esperar outra vida, além da do Espírito Santo.

RESPOSTA À QUARTA. — Cristo disse, logo no princípio da pregação evangélica (Mt 4, 17): Está próximo
o reino dos céus. Logo, é estultíssimo dizer que o Evangelho de Cristo não é o Evangelho do reino
celeste. Mas, a pregação do Evangelho de Cristo pode entender-se de dois modos. — Primeiro, quanto à
divulgação do conhecimento de Cristo. E então, o Evangelho foi pregado em todo o mundo, ainda no
tempo dos Apóstolos, como Crisóstomo diz. E sendo assim, o que se acrescenta — E então chegará o fim
— entende-se da destruição de Jerusalém, da qual, no caso, literalmente se falava. — De outro modo, a
predicação do Evangelho em toda a terra pode ser entendida como quando produzir o seu efeito pleno,
de maneira que a Igreja se estabeleça em todas as nações. E neste sentido, como diz Agostinho, o
Evangelho ainda não foi pregado em toda a terra; mas, quando o tiver sido, chegará o fim do mundo.