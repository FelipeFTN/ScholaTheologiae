# Questão 81: Da causa do pecado do homem, quanto a origem deste; ou,
do pecado original.
Em seguida devemos tratar da causa do pecado por parte do homem. Pois, como um homem é causa do
pecado de outrem, sugerindo-o, como o diabo, externamente, ele causa o pecado alheio, de maneira
especial, quanto à sua origem. Por onde, devemos tratar do pecado original. E, neste ponto, três
questões ocorrem à consideração. Primeira, da transmissão do pecado original. Segunda, da sua
essência. Terceira, do seu sujeito.
Na primeira questão discutem-se cinco artigos:

## Art. 1 — Se o primeiro pecado do primeiro pai se lhe transmitiu aos descendentes pela geração.
(II Sent., dist. XXX, q. 1, a. 2; dist. XXXI, q. 1. a. 1; IV Cont. Gent., cap. L, LI, LII; De Malo, q. 4, a. 1;
Compend. Theol., cap. CXCVI; Ad Rom., cap. V, lect. III).
O primeiro discute-se assim. — Parece que o primeiro pecado do primeiro pai não se lhe transmitiu
aos descendentes pela geração.

1. — Pois, diz a Escritura (Ez 18): o filho não carregará com a iniqüidade do pai. Ora, carregaria, se dele a
recebesse. Logo, ninguém herda, pela geração, o pecado de nenhum dos pais.

2. Demais. — O acidente não se transmite pela geração, sem a transmissão do sujeito, porque o
acidente não passa de um sujeito para outro. Ora, a alma racional, sujeito da culpa, não se transmite
pela geração, como já se demonstrou na primeira parte. Logo, também nenhuma outra culpa pode se
transmitir por ela.

3. Demais. — Tudo o que se transmite pela geração humana é causada pelo sêmen. Ora, o sêmen não
pode causar o pecado, por lhe faltar a parte racional da alma, causa única deste. Logo, não podemos
herdar nenhum pecado pela geração.

4. Demais. — O que é de natureza mais perfeita age mais intensamente. Ora, a carne perfeita não pode
macular a alma, que lhe está unida; do contrário esta, enquanto unida aquela, não poderia purificar-se
da culpa original. Logo, com maior razão, não pode o sêmen macular a alma.

5. Demais. — O Filósofo diz: ninguém critica os defeituosos de nascença, mas, os que o são por desídia e
negligência. Ora, chamam-se defeituosos de nascença os que tem um defeito de origem. Logo, pela
origem, nada é susceptível e críticas, nem é pecado.
Mas, em contrário, diz a Escritura (Rm 5): por um homem entrou o pecado neste mundo. O que não se
pode entender a modo de imitação, pois diz ainda a Escritura (Sb 2): por inveja do diabo entrou no
mundo a morte. Logo, só pela geração do primeiro homem entrou o pecado no mundo.

SOLUÇÃO. — A fé católica nos leva a admitir que o primeiro pecado do primeiro homem se lhe
transmitiu pela geração, aos descendentes. E por isso as crianças recém-nascidas são conduzidas ao
batismo, como para se lavarem da mácula da culpa. O contrário é heresia pelagiana, conforme
Agostinho o mostra em muitos dos seus livros.
Diversas são porém as vias seguidas para se investigar como o pecado do primeiro pai pode se lhe
transmitir aos descendentes. — Assim certos, considerando ser o sujeito do pecado a alma racional,
concluíram que, transmitindo-se ela pelo sêmen, de uma alma maculada há de derivar outra maculada.
— Outros, porém, repudiando esta opinião como errônea, esforçam-se por mostrar como a culpa da
alma do pai se transmite à prole, mesmo se a alma não se transmite, porque à prole passam os defeitos
corpóreos paternos. Assim, um leproso gera outro leproso, um gotoso, outro gotoso, por uma certa
corrupção do sêmen, embora essa corrupção não seja denominada lepra ou gota. Ora, como o corpo é
proporcionado à alma, e o defeito desta redunde naquele, e inversamente, assim também, dizem, o
defeito culposo da alma deriva para a prole, com a transmissão do sêmen, embora este não seja
atualmente sujeito da culpa.
Mas, todas estas explicações são insuficientes. Pois, concedamos que certos defeitos corpóreos se
transmitam pela geração, dos pais para a prole. E que também certos defeitos da alma sejam
conseqüência de uma indisposição do corpo, como quando de fátuos nascem fátuos. Apesar disto,
porém, o defeito de nascença exclui a essência da culpa — a ser voluntária. Por onde, ainda admitindo
que a alma racional se transmita, por isso mesmo que a mácula da alma do descendente não lhe
depende da vontade, não existe a essência da culpa, que provoca a pena. Pois, como diz o Filósofo:
ninguém acusará a um cego nato, mas antes, todos se compadecerão dele.
E, portanto, devemos proceder por outra via e dizer, que os homens nascidos de Adão podem
considerar-se como um só homem, por terem a mesma natureza herdada do primeiro pai. Assim
também, na ordem civil, todos os homens da mesma comunidade consideram-se como quase um só
corpo, e toda a comunidade, como quase um homem. E também diz Porfírio: pela participação da
espécie, muitos homens constituem um só homem. Por onde, os homens nascidos de Adão constituem
como que muitos membros de um só corpo. Ora, o ato de um membro corpóreo, p. ex., da mão, é
voluntário, não por vontade dela própria, mas por vontade da alma, motora primeira dos membros. Por
isso o homicídio que a mão cometer não se lhe imputará como pecado, se a considerarmos em si
mesma, separada do corpo; mas, se lhe imputa, enquanto parte do homem, movida pelo primeiro
princípio motor deste. Assim pois, a desordem existente num determinado homem, gerado de Adão,
não é voluntária, por vontade daquele, mas pela deste, que move, pela moção da geração, todos os que
dele receberam a origem, assim como a vontade da alma move a agirem todos os membros do corpo.
Por onde, o pecado assim originado do primeiro pai, para a sua descendência, chama-se original, do
mesmo modo que derivado da alma para os membros do corpo, se chama atual. E assim como este,
cometido por um membro, não é pecado desse membro, senão enquanto parte do homem, sendo por
isso chamado pecado humano; assim também o pecado original não é pecado de uma determinada
pessoa, senão na medida em que esta recebeu a natureza do primeiro pai, sendo por isso chamado
pecado da natureza, conforme aquilo da Escritura (Ef 2):éramos por natureza filhos da ira.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que o filho não carrega com o pecado do pai por
não ser por causa deste, castigado, salvo se lhe participa da culpa. Ora, tal se dá na questão vertente:
pela geração passa a culpa do pai para o filho, assim como, pela imitação, se transmite o pecado atual.

RESPOSTA À SEGUNDA. — Embora a alma racional não se transmute, por não poder o sêmen causá-la,
este predispõe contudo para ela. Por onde, pela virtude seminal, a natureza humana passa do pai para a
prole e, simultaneamente com a natureza, a sua deficiência. Por isso, quem nasce é consorte do
primeiro pai na culpa, por ter recebido dele a natureza, por via da geração.

RESPOSTA À TERCEIRA. — Embora a culpa não exista atualmente no sêmen, nele existe contudo
virtualmente a natureza humana, contaminada por aquela.

RESPOSTA À QUARTA. — O sêmen é o princípio da geração, o ato próprio da natureza, a cuja
propagação ele serve. Por isso a alma se macula, mais pelo sêmen, do que pela carne já perfeita e já
particularizada numa certa pessoa.

RESPOSTA À QUINTA. — O que é de nascença não é susceptível de acusação, se considerarmos, em si,
quem assim nasceu. Considerado porém como referido a algum princípio, pode sê-lo. Assim, quem
nasce sofre a ignomínia da raça, causada pela culpa de algum progenitor.

## Art. 2 — Se também os outros pecados, quer do primeiro pai, quer dos pais imediatos, se transmitem aos descendentes.
(II Sent., dist. XXXIII, q. 1, a. 1; IV Cont. Gent., cap. LII; De Malo, q. 4, a. 8; Compend. Theol., cap. CXCVII;
Ad Rom., capo V, lect. III).
O segundo discute-se assim. — Parece que também os outros pecados, quer do primeiro pai, quer dos
pais imediatos, se transmitem aos descendentes.

1. — Pois, a pena nunca é devida senão à culpa. Ora, certos são punidos, segundo o juízo divino, pelo
pecado dos pais imediatos, conforme está na Escritura (Ex 20): eu sou o Deus forte e zeloso que vinga a
iniqüidade dos pais nos filhos até a terceira e quarta geração. E também pelo juízo humano, no crime de
lesa majestade, os filhos são deserdados, por causa do pecado dos pais. Logo, também a culpa dos
próximos progenitores transmite-se aos descendentes.

2. Demais. — É mais fácil transmitir a outro o que um ser tem por si mesmo, do que o recebido de outro.
Assim, ao fogo é mais fácil aquecer, do que à água quente. Ora, o homem, pela geração, transmite à
prole o pecado recebido de Adão. Logo, com maior razão, o pecado por ele próprio cometido.

3. Demais. — Contraímos do primeiro pai o pecado original, por existirmos nele como no princípio da
natureza, pelo mesmo corrompida. Semelhantemente, também existimos nos nossos progenitores
próximos, como em certos princípios da natureza, que, embora corrupta, pode ainda corromper-se mais
pelo pecado, conforme aquilo da Escritura (Ap 22): aquele que está sujo, suje-se ainda. Logo, os filhos
contraem os pecados tanto dos progenitores próximos, como do primeiro pai, pela geração.
Mas, em contrário. — O bem é, mais que o mal, difusivo de si. Ora, os méritos dos progenitores
próximos não se transmitem aos descendentes. Logo, nem os pecados, com maior razão.

SOLUÇÃO. — Agostinho ventila esta questão e a deixa sem resposta. Mas quem nela atentar,
compreenderá ser impossível transmitir-se pela geração qualquer pecado, dos progenitores próximos,
ou mesmo do primeiro pai exceto o primeiro. E a razão está em o homem gerar outro homem
semelhante a si especifica e não, individualmente. Por isso, tudo o pertencente diretamente ao
indivíduo, como os atos pessoais e o que lhes diz respeito, não passa de pais a filhos. Assim, o gramático
não transmite ao filho a ciência gramatical, adquirida com estudo próprio. Ao contrário, aos filhos se
transmite o pertencente à natureza específica, salvo se houver falha nessa natureza; assim, não
falhando ela, o ser que tem olhos gera outro igualmente com eles. E se for a natureza forte, até certos
acidentes individuais, pertinentes à sua disposição, transmitem-se aos filhos, tais como a rapidez do
corpo, a bondade do engenho e semelhantes. De nenhum modo porém se transmite, como já se disse, o
que é puramente pessoal. Ora, assim como a nossa pessoa tem certos atributos próprios e certos outros
pelo dom da graça, assim também a natureza pode, por si, ter uns, — causados pelos princípios
próprios, — e outros, pelo dom da graça. E deste modo, a justiça original, como já dissemos na Primeira
Parte, era um determinado dom da graça conferido por Deus a toda a natureza humana, na pessoa do
primeiro pai; e este, pelo pecado original, a perdeu: por onde, assim como essa justiça original haveria
de transmitir-se aos pósteros, simultaneamente com a natureza, o mesmo teria de se dar com a
desordem oposta. Mas, os outros pecados atuais, quer do primeiro pai, quer dos outros, não
corrompem a natureza no que ela tem de próprio, senão só no particular à pessoa, i.é, no concernente à
inclinação para o ato. E por isso tais pecados não se transmitem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho, os filhos não são castigados nunca,
em lugar dos pais, por uma pena espiritual, salvo se participarem da culpa, pela origem ou pela
imitação, porque todas as almas procedem imediatamente de Deus, como diz a Escritura (Ez 18). Mas
em lugar dos pais, são às vezes punidos por uma pena corpórea, de acordo com o juízo divino ou
humano, por serem algo deles, quanto ao corpo.

RESPOSTA À SEGUNDA. — O que um ser tem de próprio e transmissível pode mais facilmente
transmitir. Ora, transmissíveis não são os pecados atuais dos nossos progenitores próximos, por serem
sumamente pessoais, como já se disse.

RESPOSTA À TERCEIRA. — O primeiro pecado corrompeu a natureza humana em si mesma; ao passo
que os outros a corrompem por uma corrupção pessoal.

## Art. 3 — Se o pecado do primeiro pai se transmitiu, pela geração, a todos os homens.
(III, q. 27, a. 2; q. 31, a. 8; II Sent., dist. XXX, q. 1, a. 2; dist. XXXI, q. 1, a. 2; III, dist. 3, q. 3, a 4, qª 1; IV,
dist. XLIII, a. 4, qª 1, ad 3; IV Cont. Gent., cap. sqq., LXXXIII; De Malo, q. 4, a. 6; Quodl., VI, q. 5, a. 1; In
Psalm., L; Ad Rom., cap. V, lect. III).
O terceiro discute-se assim. — Parece que o pecado do primeiro pai não se transmitiu pela geração, a
todos os homens.

1. — Pois, a morte é pena conseqüente ao pecado original. Ora, nem todos os gerados da raça de Adão
hão de morrer. Assim, não hão de morrer nunca os vivos por ocasião do advento do Senhor, conforme
diz a Escritura (1 Ts 4): Nós que vivemos não preveniremos aqueles que dormirão, pelo advento do
Senhor. Logo, esses não contraíram o pecado original.

2. Demais. — Ninguém dá o que não tem. Ora, quem é batizado não tem o pecado original. Logo, não o
transmite à prole.

3. Demais. — O dom de Cristo é maior que o pecado de Adão, como diz o Apóstolo. Ora, esse dom não
se transmite a todos os homens. Logo, nem o pecado de Adão.
Mas, em contrário, diz o Apóstolo (Rm 5): a morte passou a todos os homens por um homem, no qual
todos pecaram.

SOLUÇÃO. — Segundo a fé católica, devemos admitir firmemente que, com a só exceção de Cristo,
todos os homens, nascidos de Adão, contraíram deste o pecado original. Do contrário, nem todos
precisariam da redenção de Cristo; o que é errôneo. E a razão disto pode fundar-se no que já foi dito:
pelo pecado do primeiro pai se lhe transmitiu aos descendentes a culpa original, assim como pela von-
tade da alma, imprimindo o movimento aos membros, transmite-se a estes o pecado atual. Ora, é
manifesto que o pecado atual pode transmitir-se a todos os membros susceptíveis, por natureza, de
serem movidos pela vontade. Por onde também a culpa original se transmite a todos os originados de
Adão pelo movimento da geração.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É opinião mais provável e conveniente, que todos os
vivos por ocasião do advento do Senhor morrerão, mas depois de breve tempo ressurgirão, como mais
adiante se dirá com maior desenvolvimento. Se porém, for verdade, como outros dizem, que nunca hão
de morrer, conforme as várias opiniões expostas por Jerônimo, deve-se responder à objeção, dizendo
que, nesses tais, embora não morram, há contudo o reato da morte, se bem os livre Deus da pena, ele
senhor de perdoar também as penas dos pecados atuais.

RESPOSTA À SEGUNDA. — O batismo livra do reato do pecado original, e faz a alma recuperar a graça,
no respeitante à alma. Permanece porém atualmente o pecado original, quanto ao incentivo,
consistente na desordem das partes inferiores da alma e também do corpo, pelo qual e não pela alma, o
homem gera. E por isso os batizados transmitem o pecado original. Pois os pais não geram enquanto
renovados pelo batismo, mas enquanto conservam ainda resquícios do antigo pecado original.

RESPOSTA À TERCEIRA. — Assim como o pecado de Adão se transmitiu a todos os dele gerados
corporalmente, assim também a graça de Cristo se transmite a todos os gerados dele, espiritualmente,
pela fé e pelo batismo. E não só para perdoar a culpa do primeiro pai, mas também os pecados atuais, e
para nos introduzir na glória.

## Art. 4 — Se quem fosse milagrosamente formado de carne humana, contrairia o pecado original.
(II Sent., dist. XXXI, q. 1, a. 2, ad 3; dist. XXXIII, q. 1, a. 1, ad 5; III, dist. II, q. 1, a. 2, qª 2, ad 2; De Malo, q.
4, a. 7).
O quarto discute-se assim. — Parece que quem fosse milagrosamente formado de carne humana,
contrairia o pecado original.

1. — Pois, como diz uma Glosa, na carne de Adão se lhe corrompeu toda a posteridade; porque esta não
nasceu dele primeiro, no lugar da vida, mas depois, no do exílio. Ora, quem fosse formado do modo
supra dito, a esse a carne lhe seria gerada no lugar do exílio. Logo, contrairia o pecado original.

2. Demais. — A causa do pecado original foi à contaminação da alma pela carne. Ora, a nossa carne está
totalmente contaminada. Logo, a alma contrairia a contaminação do pecado original, qualquer que
fosse a parte da carne de que fôssemos formados.

3. Demais. — O pecado original procede do primeiro pai, por termos todos existido nele, pecador. Ora,
todos os que fossem formados de carne humana haveriam de ter existido em Adão. Logo, contrairiam o
pecado original.
Mas, em contrário, quem fosse formado milagrosamente de carne humana não teria existido em Adão,
quanto àorigem seminal, que só causa a transmissão do pecado original, como diz Agostinho.

SOLUÇÃO. — Como já se disse, o pecado original se transmitiu do primeiro pai aos seus descendentes
por serem estes promovidos à geração por aquele, assim como os membros são levados pela alma à
prática do pecado atual. Ora, o ato gerador não se dá senão pela virtude geratriz ativa. Por onde, só
contraem o pecado original os descendentes de Adão, por uma virtude geratriz ativa, dele originalmente
derivada. E isso é proceder dele por geração seminal, pois a virtude seminal não é senão a virtude
geratriz ativa. Ora, o formado da carne humana por virtude divina manifestamente não teria a sua
virtude ativa derivada de Adão. E portanto, não contrairia o pecado original; assim como o ato da mão
não se incluiria no pecado humano, se não fosse movida pela vontade do homem, mas por algum motor
extrínseco.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Adão não tomou o rumo do exílio senão depois do
pecado. Por onde, não por causa do lugar do exílio, mas, por causa do pecado, é que se a culpa original
transmitiu aos produzidos pela geração ativa de Adão.

RESPOSTA À SEGUNDA. — A carne não contamina a alma senão enquanto princípio gerador ativo, como
já se disse.

RESPOSTA À TERCEIRA. — Quem fosse formado de carne humana teria preexistido em Adão pela
substância corpórea, mas não pela virtude seminal, como já se disse. E logo, não contrairia o pecado
original.

## Art. 5 — Adão não tendo pecado, se os filhos de Adão e Eva contrairiam o pecado original, se só ela tivesse pecado.
(II Sent., dist. XXXI, q. 1, a. 2, ad 4; IV, dist. 1, q. 2, a 2, qª 2, ad 1; De Malo, q. 4, a. 7, ad 4, 5; Ad Rom.,
cap. V, lect. III; 1 Cor., cap. XV, lect. III).
O quinto discute-se assim. — Parece que os filhos de Adão e Eva contrairiam o pecado original, se só
ela tivesse pecado.

1. — Pois, contraímos dos pais o pecado original por termos preexistido neles, conforme aquilo do
Apóstolo: no qual todos pecaram. Ora, o homem preexiste tanto no pai como na mãe. Logo,
contrairíamos o pecado original pelo pecado tanto desta como daquele.

2. Demais. — Se só Eva tivesse pecado, os filhos nasceriam passíveis e mortais. Pois, a mãe é a que dá a
matéria da geração, como diz o Filósofo; ora, a morte e toda passibilidade decorrem necessariamente
da matéria. Mas, a passibilidade e a morte inevitável são penas do pecado original. Logo, se só Eva
tivesse pecado, os filhos contrairiam o pecado original.

3. Demais. — Damasceno diz, que o Espírito Santo preabitou na Virgem, de quem havia de nascer Cristo,
sem pecado original, purificando-a. Ora, essa purificação não teria sido necessária se a mácula do
pecado original não se contraísse pela mãe. E portanto, se só Eva tivesse pecado, os filhos contrairiam o
pecado original.
Mas, em contrário, diz o Apóstolo (Rm 5): por um homem entrou o pecado neste mundo. Ora, deveria,
mais acertadamente dizer que entrou por ambos, porque ambos pecaram; ou antes, pela mulher, que
pecou primeiro, se por ela se transmitisse à prole o pecado original. Logo, não é pela mãe, mas pelo pai,
que o pecado original se transmite à prole.

SOLUÇÃO. — A resposta a esta dúvida resulta do que já foi dito. Pois, como já estabelecemos, o pecado
original se transmitiu pelo primeiro pai, por dele depender a geração dos filhos. E por isso dissemos que
quem fosse só materialmente gerado da carne humana não contrairia o pecado original. Ora, é
manifesto, segundo a doutrina dos filósofos, que o pai é o princípio ativo da geração, ao passo que a
mãe ministra a matéria. Portanto não é pela mãe, mas pelo pai, que foi contraído o pecado original. Ora,
a esta luz, se não tivesse Adão pecado e Eva sim, os filhos não contrairiam o pecado original. E o inverso
se daria se Adão tivesse pecado e não Eva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O filho preexiste no pai como no princípio ativo; mas na
mãe, como no princípio material e passivo. Logo, não há semelhança de razões.

RESPOSTA À SEGUNDA. — Certos ensinam que se só Eva tivesse pecado, os filhos seriam imunes de
culpa, mas, sofreriam a morte inevitável e todas as demais passibilidades decorrentes necessariamente
da matéria ministrada pela mãe; não porém como significativas da pena, senão como deficiências
naturais. Esta opinião porém não é admissível. Pois, a imortalidade e a impassibilidade no estado
primitivo não dependiam da condição da matéria, como já dissemos na Primeira Parte, mas da justiça
original, pela qual o corpo estava sujeito à alma, enquanto esta o estivesse a Deus. Ora, a falta de justiça
original é o pecado original. Se portanto, Adão não tendo pecado, o pecado original não se transmitisse
aos descendentes, só pelo pecado de Eva, é manifesto que nos filhos não haveria falta da justiça
original. Logo não haveria neles qualquer passibilidade nem o inevitável da morte.

RESPOSTA À TERCEIRA. — A purificação proveniente da santa Virgem era necessária, não para evitar a
transmissão do pecado original, mas, para a Mãe de Deus resplandecer com máxima pureza. Pois, há
nenhum receptáculo digno de Deus, senão o puro, conforme aquilo da Escritura (Sl 92): à tua casa
convém santidade, Senhor.