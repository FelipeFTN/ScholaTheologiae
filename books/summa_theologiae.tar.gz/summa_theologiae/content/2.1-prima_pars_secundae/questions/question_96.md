# Questão 96: Do poder da lei humana.
Em seguida devemos tratar do poder da lei humana.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se a lei humana deve ser feita para o bem comum ou antes, para o particular.
(V Ethic., lect XVI).
O primeiro discute-se assim. — Parece que a lei humana não deve ser feita para o bem comum, mas
antes, para o particular.

1. — Pois, o Filósofo diz: Legal é a lei estabelecida para casos particulares; e também os decretos que
regulam, como o legal, casos particulares, pois são expedidos para se aplicarem a atos particulares.
Logo, a lei não é feita só para o bem comum, mas também para o particular.

2. Demais. — A lei é diretiva dos atos humanos, como já se disse (q. 90, a. 1, a. 2). Ora, os atos humanos
versam sobre o particular. Logo, a lei humana deve ser feita, não para o bem comum, mas antes, para o
particular.

3. Demais. — A lei é a regra e a medida dos atos humanos, como já se disse (q. 90, a. 1, a. 2). Ora, a
medida deve ser certíssima, como diz Aristóteles. Logo, nos atos humanos, não podendo haver nada a
tal ponto certo que não falhe em casos particulares, parece que as leis devem ser feitas, não para o bem
geral, mas para o particular.
Mas, em contrário, diz o jurisperito: O direito deve ser constituído para regular o que freqüentemente se
dá e não, para o que acontece fortuitamente.

SOLUÇÃO. — Tudo o que existe para um fim deve ser-lhe proporcionado. Ora, o fim da lei é o bem
comum; pois, como diz Isidoro, a lei deve ser estabelecida para a utilidade comum dos cidadãos, e não,
para a utilidade privada. Por onde, devem as leis humanas ser proporcionadas ao bem comum. Ora, este
consta de muitos elementos, que portanto, a lei há de necessariamente visar; no concernente às
pessoas, aos atos e aos tempos. Pois, a comunidade civil é composta de muitas pessoas, cujo bem é
buscado por meio de muitas ações. Nem a lei é instituída para durar pouco tempo, mas para perdurar
longamente, através da sucessão dos cidadãos, como diz Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo distingue três partes na justiça legal, que é o
direito positivo. Pois certas leis são, em si mesmas, estabelecidas para o bem geral; e são as leis gerais. E
a esta luz, diz: ao legal é indiferente vir a ser de um ou de outro modo mas já não o é, quando está
estabelecido: p. ex., que os prisioneiros sejam resgatados por um certo preço estatuído. — Outras são
gerais, sob certo respeito e particulares, sob outro. E essas se chamam privilégios, quase leis privadas,
porque respeitam pessoas singulares, embora o seu vigor se estenda a muitos outros casos. E por isso
acrescenta: além disso, todas as leis feitas para casos particulares. — Certas determinações também se
chamam legais, não por serem leis, mas por constituírem aplicação das leis comuns a certos fatos
particulares; e tais são os decretos, tidos como leis. E, por isto, acrescenta: os decretos.

RESPOSTA À SEGUNDA. — O que é diretivo deve sê-lo de muitas coisas. Por isso, o Filósofo diz, que
tudo o pertencente a um mesmo gênero é medido pelo que é primeiro nesse gênero. Pois, se fossem as
regras ou as medidas tantas quantas as coisas medidas ou reguladas, cessaria por certo a utilidade
daquelas, que consiste em podermos conhecer muitas coisas por meio de uma só. E assim, nenhuma
utilidade teria a lei, se não abrangesse senão um ato particular. Ora, para dirigir atos particulares são
estabelecidos os preceitos singulares dos prudentes. A lei, ao contrário, é um preceito comum, como já
se disse (q. 92, a. 2 arg. 2).

RESPOSTA À TERCEIRA. — Não devemos buscar em tudo a mesma certeza, diz Aristóteles. Por onde, nas
coisas contingentes, como as naturais e as humanas, basta uma certeza tal, que seja um princípio
verdadeiro, na maior parte dos casos, embora, em alguns possa a não vir a sê-lo.

## Art. 2 — Se à lei humana pertence coibir todos os vícios.
(Supra, q. 91, a. 4; q. 93, a. 3, ad 3; infra, a. 3, ad 1; q. 98, a. 1; IIª-IIªª, q. 69, a. 2, ad 1; q. 77, a. 1 ad 1; q.
78, a.1, ad 3; D Malo, q. 13, a. 4. ad 6;Quodl. II, q. 5, a. 2, ad 1, 2; In Iob, cap. XI, lect. I; In Psalm., XVIII).
O segundo discute-se assim. — Parece que à lei humana pertence coibir todos os vícios.

1. — Pois, diz Isidoro: As leis são feitas para, sendo temidas, coibirem a audácia. Ora, esta não será
suficientemente coibida, sem que todos os vícios sejam por aquela coibidos. Logo, a lei humana deve
coibi-los a todos.

2. Demais. — A intenção do legislador é tornar os cidadãos virtuosos. Ora, ninguém pode ser virtuoso se
se não coibir de todos os vícios. Logo, à lei humana pertence coibir de todos eles.

3. Demais. — A lei humana deriva da lei natural, como já se disse (q. 95, a. 2). Ora, todos os vícios
repugnam à lei natural. Logo, ela deve coibi-los a todos.
Mas, em contrário, diz Agostinho: Parece-me que esta lei, escrita para governar o povo, permite
retamente tais coisas e vindica a Providência Divina. Ora, a Providência Divina não vinga senão os vícios.
Logo, se não os coíbe, a lei humana permite, retamente, certos vícios.

SOLUÇÃO. — Como já dissemos (q. 90, a. 1, a. 2), a lei é posta como uma certa regra e medida dos atos
humanos. Ora, a medida deve ser homogênea com o medido, como diz Aristóteles: pois, coisas diversas
têm medidas diversas. Por onde e necessariamente, também as leis hão de ser impostas aos homens
segundo a condição deles; pois, como Isidoro diz, a lei deve ser possível, quanto à natureza e quanto aos
costumes pátrios. Ora, a faculdade de agir procede do hábito ou disposição interior; pois, o mesmo não
é possível tanto ao que não tem o hábito da virtude como ao virtuoso, assim como a mesma coisa não é
possível à criança e ao homem feito. E por isso não se estabelece a mesma lei para as crianças e para os
adultos, e muitas coisas permitidas aquelas são, por lei, punidas ou ainda vituperadas nestes.
Semelhantemente, muitas coisas se permitem ao homem de virtude imperfeita, que se não tolerariam
em homens virtuosos. Ora, a lei humana é feita para a multidão dos homens, composta na sua maior
parte de homens de virtude imperfeita. Por isso ela não proíbe todos os vícios, de que se os virtuosos
abstêm, mas só os mais graves, dos quais é possível à maior parte da multidão abster-se. E
principalmente os que causam dano a outrem, ou aqueles sem cuja proibição a sociedade humana não
pode subsistir; assim, a lei humana proíbe o homicídio, o furto e atos semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — À audácia é próprio atacar os outros. Por onde, entra
principalmente em o número dos pecados que causam injúria ao próximo e são proibidos pela lei
humana, como já se disse.

RESPOSTA À SEGUNDA. — A lei humana visa dirigir os homens para a virtude, não súbita, mas
gradativamente. Por isso não impõe imediatamente à multidão dos imperfeitos o que só é próprio dos
virtuosos, de modo que se abstenham de todos os vícios. Do contrário, os imperfeitos, não podendo
observar tais preceitos, cairiam em piores males, como diz a Escritura (Sl 30, 33): Aquele que com força
espreme a teta para tirar leite faz sair desta o sangue; e noutro lugar (Mt 9, 17): Se deitarem vinho novo,
i. é, preceitos da vida perfeita, em odres velhos, i. é, em homens imperfeitos, vai-se o vinho e se perdem
os odres, i. é, os preceitos são desprezados e os homens, do desprezo, caem em piores males.

RESPOSTA À TERCEIRA. — A lei natural é uma participação da lei eterna em nós; ao passo que a lei
humana é deficiente em relação à eterna. Pois, diz Agostinho: A lei estabelecida para reger a cidade
permite e deixa impunes muitos atos, que são vingados pela Providência Divina. Mas nem por deixar de
fazer tudo há de se lhe reprovar o que faz. Por onde, também a lei humana não pode proibir tudo o que
a lei da natureza proíbe.

## Art. 3 — Se a lei humana ordena os atos de todas as virtudes.
(Infra, q. 100, a. 2; V Ethic., lect II).
O terceiro discute-se assim. — Parece que não ordena a lei humana os atos de todas as virtudes.

1. — Pois, aos atos virtuosos se opõem viciosos. Ora, não proíbe a lei humana todos os vícios, como já se
disse (a. 2). Logo, também não ordena os atos de todas as virtudes.

2. Demais. — Os atos virtuosos procedem da virtude. Ora, a virtude é o fim da lei; a ponto que não pode
cair sob o preceito da lei o concernente à virtude. Logo, não ordena a lei humana os atos de todas as
virtudes.

3. Demais. — A lei humana se ordena para o bem comum, como já se disse (q. 90, a. 2). Ora, certos atos
virtuosos não se ordenam para o bem comum, mas para o particular. Logo, não ordena a lei os atos de
todas as virtudes.
Mas, em contrário, o Filósofo diz: A lei preceitua a prática de atos de fortaleza, de temperança e de
mansidão; e semelhantemente, no referente às outras virtudes e malícias, ordena uns atos e proíbe
outros.

SOLUÇÃO. — As virtudes se especificam pelos seus objetos, como do sobredito resulta (q. 54, a. 2; q. 60,
a. 1; q. 62, a. 2). Ora, todos os objetos das virtudes podem se referir ao bem particular de alguém, ou ao
bem comum da multidão. P. ex., podemos praticar atos de fortaleza para a conservação da cidade ou
dos direitos de um amigo; e assim por diante. Ora, como dissemos (q. 90, a. 2), a lei se ordena para o
bem comum. Logo, não há nenhuma virtude cujos atos a lei não os possa ordenar. Contudo não
preceitua sobre todos os atos de todas as virtudes, mas só dos ordenados para o bem comum. E isto
imediatamente, como quando alguma coisa se faz diretamente para o bem comum; ou, mediatamente,
como quando o legislador estabelece certas disposições pertinentes à boa disciplina, que informe os
cidadãos, para conservarem o bem comum da justiça e da paz.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não proíbe a lei humana todos os atos viciosos, com
obrigação de preceito, assim como desse modo, também não ordena todos os atos virtuosos. Proíbe,
porém, os atos de certos vícios particulares, assim como ordena os de certas e determinadas virtudes.

RESPOSTA À SEGUNDA. — De dois modos pode um ato ser considerado virtuoso. — De um modo,
porque o homem pratica atos virtuosos;assim, o ato da virtude da justiça consiste em agir retamente; o
da fortaleza, em agir corajosamente. E dessa maneira a lei ordena certos atos de virtude. — De outro
modo, quando alguém pratica atos virtuosos, como os que pratica o virtuoso. E tais atos sempre
procedem da virtude, nem caem sob o preceito da lei;mas é o fim a que o legislador pretende levar.

RESPOSTA À TERCEIRA. — Não há nenhuma virtude cujos atos se não ordenem ao bem comum,
mediata ou imediatamente, como já dissemos.

## Art. 4 — Se a lei humana obriga no foro da consciência.
O quarto discute-se assim. — Parece que a lei humana não obriga no foro da consciência.

1. — Pois, o poder inferior não pode impor lei ao juízo do poder superior. Ora, o poder humano, que faz
a lei humana, é inferior ao poder divino. Logo, a lei humana não pode impor lei ao juízo divino, que é o
juízo da consciência.

2. Demais. — O juízo da consciência depende sobretudo dos mandamentos divinos. Ora, às vezes os
mandamentos divinos são contraditos pelas leis humanas, conforme a Escritura (Mt 15, 6): Tendes feito
vão o mandamento de Deus pela vossa tradição. Logo, a lei humana não obriga ao homem no foro da
consciência.

3. Demais. — As leis humanas freqüentemente danificam e oprimem o homem, conforme àquilo da
Escritura (Is 10, 1 ss): Ai dos que estabelecem leis iníquas, e, escrevendo, escrevam injustiça, para
oprimirem os pobres em juízo, e fazerem violência à causa dos fracos do meu povo. Ora, é lícito a todos
evitar a violência e a opressão. Logo, as leis humanas não obrigam ao homem no foro da consciência.
Mas, em contrário, diz a Escritura (1 Pd 2, 19): Isto é uma graça, se alguém, pelo conhecimento do que
deve a Deus, sofre moléstias, padecendo injustamente.

SOLUÇÃO. — As leis estabelecidas pelos homens são justas ou injustas. — Se justas, têm, da lei eterna,
donde derivam, força para obrigar no foro da consciência, conforme àquilo da Escritura (Pr 8, 15): Por
mim reinam os reis e por mim decretam os legisladores o que é justo. Ora, as leis se consideram justas:
pelo fim, i. é, quando se ordenam para o bem comum;pelo autor, i. é, quando a lei feita não excede o
poder do seu autor; e pela forma, i. é, quando, por igualdade proporcional, impõe ônus aos governados,
em ordem ao bem comum. Ora, como cada homem e parte da multidão, cada um é da multidão por
aquilo mesmo que é e que tem; assim como qualquer parte, por aquilo mesmo que a constitui, pertence
ao todo; por isso, se a natureza faz sofrer à parte algum detrimento, é para salvar o todo. E assim sendo,
as leis, que impõem tais ônus proporcionais, são justas, obrigam no foro da consciência e são leis legais.
Por outro lado, as leis injustas podem sê-lo de dois modos. — Por contrariedade com o bem humano, de
modo oposto às razões que as tornam justas, antes enumeradas. Pelo fim, como quando um chefe
impõe leis onerosas aos súbditos, não pertinentes à utilidade pública, mas antes, à cobiça ou à glória
próprias deles; ou também pelo autor, quando impõe leis que ultrapassam o poder que lhe foi
cometido; ou ainda pela forma, p. ex., quando impõe desigualmente ônus à multidão, mesmo que se
ordenem para o bem comum. E estas são, antes, violências, que leis, pois, como diz Agostinho, não se
considera lei o que não for justo. Por onde, tais leis não obrigam no foro da consciência, salvo talvez
para evitar escândalo ou perturbações, por causa do que o homem deve ceder mesmo do seu direito,
segundo a Escritura: E se qualquer te obrigar a ir carregando mil passos, vai com ele ainda mais outros
dois mil; e ao que tirar-te a tua túnica, larga-lhe também a capa. — De outro modo, as leis podem ser
injustas por contrariedade com o bem divino. Tais as leis dos tiranos, obrigando à idolatria, ou ao que
quer que seja contra a lei divina. E tais leis de nenhum modo se devem observar, porque, como diz a
Escritura (At 5, 29), importa obedecer antes a Deus que aos homens.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz o Apóstolo (Rm 13, 1-2), não há potestade que
não venha de Deus; e portanto, aquele que resiste à potestade, no que lhe concerne à ordem,
resiste à ordenação de Deus. E assim, torna-se réu, quanto a sua consciência.

RESPOSTA À SEGUNDA. — A objeção colhe quanto às leis humanas que ordenam o contrário dos
mandamentos de Deus; ao que se não pode estender a ordem do poder. Por isso, em tais casos, não se
deve obedecer à lei humana.

RESPOSTA À TERCEIRA. — A objeção procede quanto à lei que impõe injusto gravame aos súbditos; ao
que também não pode estender-se a ordem do poder concedido por Deus. Por onde, também nesses
casos o homem não está obrigado a obedecer à lei e, sem escândalo ou maior detrimento, pode resistir-
lhe.

## Art. 5 — Se todos estão sujeitos à lei.
(Ad Rom., cap. XII, lect I).
O quinto discute-se assim. — Parece que nem todos estão sujeitos à lei.

1. — Pois, só estão sujeitos à lei aqueles para quem ela foi feita. Ora, o Apóstolo diz (1 Tm 1, 9): A lei não
foi posta para o justo. Logo, o justo não está sujeito à lei humana.

2. Demais. — Urbano II, Papa, diz, conforme está nas Decretais: Nenhuma razão exige que seja
governado por uma lei pública quem o é por uma lei particular. Ora, pela lei particular do Espírito Santo
são governados todos os homens espirituais, que são filhos de Deus, segundo àquilo da Escritura (Rm 8,
14): Todos os que são levados pelo Espírito de Deus estes tais são filhos de Deus. Logo, nem todos os
homens estão sujeitos à lei humana.

3. Demais. — O jurisperito diz: O príncipe está a salvo da lei. Ora, quem está a salvo da lei a ela não está
sujeito. Logo, nem todos estão sujeitos à lei.
Mas, em contrário, diz o Apóstolo (Rm 13, 1): Todo homem está sujeito às potestades superiores. Ora,
não está sujeito ao poder quem não o está à lei estabelecida por ele. Logo, todos os homens devem
estar sujeitos à lei.

SOLUÇÃO. — Como do sobredito resulta (q. 90, a. 1, a. 2; a. 3 ad 2), duas coisas a lei é por essência:
regra dos atos humanos e dotada de força coativa. Logo, de dois modos pode um estar sujeito à lei. —
Primeiro, como o regulado à regra. E deste modo, todos os que estão sujeitos ao poder o estão à lei, que
ele estabelece. De duas maneiras, porém, pode dar-se que alguém não esteja sujeito à lei. Ou por estar
absolutamente livre da sua sujeição; por isso os que fazem parte de um Estado ou reino não estão
sujeitos às leis nem ao domínio do chefe de outro Estado ou reino. Ou por ser governado por uma lei
superior; assim, quem está sujeito a um procónsul deve regular-se pelas suas ordens, não porém
naquilo que lhe ordena o imperador; no que não está sujeito à ordem de um poder inferior, desde que é
mandado por um superior. E assim, pode dar-se que quem, absolutamente falando, está sujeito à lei,
não o está, de algum modo, desde que é governado por uma lei superior. — De outra maneira, diz-se
que alguém está sujeito à lei como o coagido o está a quem coage. E deste modo, os homens justos e
virtuosos não lhe estão sujeitos, mas só os maus. Pois, o coagido e violento é contrário à vontade. Ora, a
vontade dos bons submete-se à lei, à qual não se submete a dos maus. Por onde, assim sendo, os bons
não estão sujeitos à lei, mas só os maus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procede quanto à sujeição a modo de coação.
Pois, assim, a lei não foi posta para os justos, que são a sua própria lei, porque mostram a obra da lei,
escrita nos seus corações, como diz o Apóstolo (Rm 2, 14-15). Por onde, para eles a lei não tem força
coativa, como para os maus.

RESPOSTA À SEGUNDA. — A lei do Espírito Santo é superior a toda lei posta pelo homem. Por isso, os
homens espirituais, enquanto levados pela lei do Espírito Santo, não estão sujeitos à lei, enquanto ela
repugne à direção desse Espírito. Mas é a direção mesma do Espírito Santo que leva os homens
espirituais a serem sujeitos à lei humana, conforme àquilo da Escritura (1 Pd 2, 13): Submetei-vos pois, a
toda humana criatura, por amor de Deus.

RESPOSTA À TERCEIRA. — Diz-se que o príncipe está a salvo da lei, quanto a força coativa dela. Pois
ninguém pode ser obrigado por si mesmo; e a lei não tem força coativa senão pelo poder do príncipe.
Por onde, diz-se que o príncipe está a salvo da lei, porque ninguém pode pronunciar contra ele um juízo
condenatório, se agir contra ela. Por isso, àquilo da Escritura — Contra ti só pequei, etc. — diz a Glosa:
Não há homem que possa julgar as ações do rei. Mas quanto à força diretiva da lei, o príncipe, por
vontade própria, a ela está sujeito, conforme esta disposição: Quem estabeleceu uma lei para outrem
também deve se lhe submeter. E a autoridade do Sábio o diz: Obedece à lei que fizeste. E no Código os
imperadores Teodósio e Valentiniano escrevem ao prefeito Volusiano: É palavra digna da majestade
reinante, que o príncipe se considere ligado pelas leis; pois, da autoridade da lei depende a nossa
autoridade. E por certo, é mais que o império sujeitar-se o principado às leis. E também o Senhor
repreende os que dizem e não fazem, e os que impõem cargas pesadas e nem com o seu dedo as
querem mover, como está no Evangelho (Mt 23, 3-4). Por onde, o príncipe não está a salvo do poder
diretivo do juízo de Deus; mas deve cumprir a lei, não coagido, mas voluntariamente. Está ainda o
príncipe acima da lei por poder mudá-la, se for conveniente, e dispensar dela conforme ao lugar e ao
tempo.

## Art. 6 — Se é lícito a quem está sujeito à lei agir fora dos termos dela.
(IIª-IIªe, q. 60, a. 5, ad 2, 3; q. 120, a. 1; q. 147, a. 4; III Sent., dist. XXXVII, a. 4; IV, dist. XV, q. 3, a. 2, q. 1,
2; V Ethic., lect. XVI).
O sexto discute-se assim. — Parece que não é lícito a quem está sujeito à lei agir fora dos termos dela.

1. — Pois, diz Agostinho: Embora os homens julguem as leis temporais, quando as estabelecem,
contudo uma vez instituídas e firmadas já não é lícito julgá-las, mas deve-se julgar de acordo com elas.
Ora, quem omitir palavras da lei, dizendo conservar a intenção do legislador, julga a lei. Logo, não é lícito
a quem está sujeito à lei omitir-lhe palavras, para conservar a intenção do legislador.

2. Demais. — Só pode interpretar as leis quem as pode fazer. Ora, a nenhum dos submetidos à lei é lícito
fazê-las. Logo, não podem interpretar a intenção do legislador, mas devem agir sempre conforme às
palavras da lei.

3. Demais. — Todo sapiente sabe explicar verbalmente as suas intenções. Ora, devem-se considerar
sapientes os que estabeleceram leis; pois, diz a Sabedoria: Por mim reinam os reis e por mim decretam
os legisladores o que é justo. Logo, não se deve julgar da intenção do legislador senão pelas palavras da
lei.
Mas, em contrário, diz Hilário: A inteligência das palavras deve fundar-se nas causas que as levaram a
ser proferidas; pois, não é a realidade que deve depender da palavra, mas esta, daquela. Logo, devemos
atender, antes à causa que moveu o legislador, do que às palavras mesmas da lei.

SOLUÇÃO. — Como já se disse (a. 4), toda lei se ordena ao bem comum dos homens, e nessa medida é
que obtém força e razão de lei; e na medida em que assim não se ordene, nessa mesma não tem força
para obrigar. Por isso, o jurisperito diz: Nenhuma razão de direito ou equitativa benignidade sofre, que
as medidas salutares introduzidas para a conservação da sociedade, nós as transformemos em
severidades, interpretando-as duramente, contra o que pede a comodidade humana. Acontece porém,
muitas vezes, que uma medida quase sempre útil a ser observada, para o bem comum, seja nociva, por
exceção, em algum caso particular. Por onde, como o legislador não pode prever todos os casos
particulares, propõe a lei para os casos mais freqüentes, dirigindo a sua intenção para a utilidade
comum. Portanto, se surgir um caso em que seja danosa ao bem comum a observância de uma lei, esta
não deve ser observada. Assim, se for estabelecido que todas as portas de uma cidade sitiada devam
ficar fechadas, isso é útil para o bem comum, na maior parte dos casos. Se porém acontecesse, que os
inimigos perseguissem certos cidadãos, pelos quais a cidade é conservada, seria danosíssimo para ela se
as portas se lhes não abrissem. Por onde, em tal caso, as portas se deveriam abrir, contra a letra da lei,
para se conservar a utilidade comum, que o legislador tinha em vista.
Devemos porém considerar, que se a observância da letra da lei não implicar um perigo súbito, a que é
preciso imediatamente obviar, não é lícito a quem quer que seja interpretar o que seja útil ou inútil à
cidade. Mas isso só pertence aos chefes, que, por causa de tais casos, têm a autoridade para dispensar
na lei. Se porém o perigo for súbito e não sofra demora, de modo a se poder recorrer ao superior, a
própria necessidade traz consigo a dispensa, porque a necessidade não está sujeita à lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quem, em caso de necessidade, age fora da letra da lei,
julga, não da lei, mas de um caso particular, onde vê que se não deve observar a letra da lei.

RESPOSTA À SEGUNDA. — Quem segue a intenção do legislador não interpreta, absolutamente,
falando, a lei. Mas assim o faz, em caso em que seja manifesto, pela evidência do dano, que o legislador
tinha outra intenção. Se porém houver dúvida, deve agir segundo as palavras da lei, ou consultar o
superior.

RESPOSTA À TERCEIRA. — De nenhum homem é tão grande a sabedoria a ponto de poder prever todos
os casos particulares; e portanto, ninguém poderá suficientemente exprimir, com palavras, o que
convém ao fim intencionado. E mesmo que o legislador pudesse prever todos os casos, não deveria
exprimi-los todos, para evitar confusão. Mas deve fazer a lei para o que comumente se dá.