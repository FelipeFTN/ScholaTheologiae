# Questão 43: Da causa do temor.
Em seguida devemos tratar da causa do temor. E sobre esta questão dois artigos se discutem:

## Art. 1 — Se o amor é causa do temor.
(In Psalm.XVIII).
O primeiro discute-se assim. — Parece que o amor não é causa do temor.

1. — Pois, o que provoca alguma coisa é causa da mesma. Ora, o temor provoca o amor de caridade,
como diz Agostinho. Logo, o temor é causa do amor e não inversamente.

2. Demais — Como diz o Filósofo, tememos sobretudo aqueles de quem esperamos algum mal iminente.
Ora, somos levados mais ao ódio do que ao amor daqueles de quem esperamos algum mal. Logo, o
temor é causado mais pelo ódio do que pelo amor.

3. Demais — Como já se disse, o que provém de nós mesmos não se manifesta como temível. Ora, o que
procede do amor provém, especificamente, do íntimo do coração. Logo, o temor não é causado pelo
amor.
Mas, em contrário, diz Agostinho: É certo que não há outra causa de temor senão a de perdermos o
objeto amado quando possuído, ou não possuí-lo quando esperado. Logo, todo temor é causado por
amarmos alguma coisa. Portanto, o amor é causa do temor.

SOLUÇÃO. — Os objetos das paixões da alma estão para ela como as formas para os seres naturais ou
artificiais; pois as paixões se especificam pelos seus objetos, como os seres naturais pelas suas formas.
Por onde, assim como a causa da forma o é daquilo que ela constitui; assim, tudo o que, de qualquer
modo, é causa do objeto, é causa da paixão. Ora, a causa de um objeto pode ser eficiente ou dispositiva
material. Assim, o objeto do prazer é o bem aparente conveniente e conjunto, cuja causa eficiente é o
que produz a conjunção, a conveniência, a bondade ou a aparência desse bem. Por outro lado, a causa
dispositiva material é o hábito, ou qualquer disposição pelo qual se nos torna conveniente ou aparente
o bem conjunto.
Assim pois no caso em questão, o objeto do temor é o mal considerado como tal, como futuro e
próximo e ao qual não podemos resistir facilmente. E portanto o que nos pode causar esse mal é causa
efetiva do objeto do temor, e por conseqüência do próprio temor. O que porém nos torna de tal modo
dispostos que temamos o mal de que acabamos de falar, é causa do temor e do seu objeto, como
disposição material. E deste modo o amor é causa do temor. Pois, é de amarmos um bem que se nos
torna mal o que dele nos priva; e por isso o tememos como um mal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como já dissemos, o temor em si mesmo e
primariamente diz respeito ao mal de que foge, e oposto a algum bem amado, e portanto, nasce do
amor. Secundariamente porém respeita aquilo por que provém o mal. E assim, acidentalmente, às vezes
provoca o amor, i. é, quando tememos sermos punidos por Deus, observamos-lhe os mandamentos;
donde, o início da esperança, que provoca o amor, como já dissemos.

RESPOSTA À SEGUNDA. — Começamos por ter ódio à pessoa de quem esperamos o mal; mas, começa a
ser amada desde que dela começamos a esperar o bem. Pois, desde o princípio era amado o bem, a que
contraria o mal temido.

RESPOSTA À TERCEIRA. — A objeção procede relativamente à causa eficiente de um mal temível, ao
passo que o amor é causa do mal a modo de disposição material, como já dissemos.

## Art. 2 — Se a deficiência é a causa do temor.
(In Psalm.XXVI).
O segundo discute-se assim. — Parece que a deficiência não é causa do temor.

1. — Pois, os que têm poder são os mais temidos. Ora, a deficiência é contrária ao poder. Logo, não é
causa do temor.

2. Demais — Os que vão ser decapitados sofrem a máxima deficiência. Ora, eles não temem, como diz
Aristóteles. Logo, a deficiência não é causa do temor.

3. Demais — Lutar supõe força e não deficiência: Ora, os competidores temem os que concorrem com
eles, como diz Aristóteles. Logo, a deficiência não é causa do temor.
Mas, em contrário. — Os contrários são causas uns dos outros. Ora, as riquezas, a força, a multidão dos
amigos e o poder excluem o temor, segundo Aristóteles. Logo, a falta desses elementos é a causa do
temor.

SOLUÇÃO. — Como já dissemos, podemos descobrir dupla causa do temor: uma, como disposição
material de quem teme; a outra, como causa eficiente, da parte de quem é temido.
Quanto ao primeiro ponto, a deficiência é em si mesma causa do temor; pois é por alguma deficiência
de forças que não podemos facilmente repelir o mal iminente. Contudo, para causar o temor é preciso
tenha a deficiência certa medida. Pois é menor a deficiência que causa o temor do mal futuro, que a
consecutiva ao mal presente, que provoca a tristeza. E ainda seria maior a deficiência, se ficasse
totalmente eliminado o sentimento do mal, ou o amor do bem, cujo contrário é temido.
Quanto ao segundo, a força e a robustez, em si mesma, é causa do temor. Pois, é por apreendermos,
como nocivo o que é forte, que não lhe podemos repelir os efeitos. Pode porém acontecer,
acidentalmente, que no caso vertente uma deficiência cause o temor; assim quando é causa de alguém
querer nos fazer mal, por uma injustiça, p. ex., ou porque foi lesado antes, ou teme sê-lo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção formulada relativamente à causa do temor
procede se se trata da causa eficiente.

RESPOSTA À SEGUNDA. — Os que vão ser decapitados são presas da paixão de um mal presente. Por
onde, esse defeito excede a medida do temor.

RESPOSTA À TERCEIRA. — Os competidores temem, não por causa do poder com que podem lutar, mas
por deficiência de poder; donde o não confiarem em que hão-de vencer.