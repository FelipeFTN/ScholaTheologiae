# Questão 54: Da distinção dos hábitos.
Em seguida devemos tratar da distinção dos hábitos. E sobre este ponto quatro artigos se discutem:

## Art. 1 — Se podem existir muitos hábitos numa mesma potência.
(III Sent., dist. XXXIII, q. 1, a . 1, qª 1; De Verit., q. 15, a . 2, ad 11; De Virtut., q. 1, a . 12, ad 4).
O primeiro discute-se assim. — Parece não podem existir muitos hábitos numa mesma potência.

1. — Pois, a multiplicação de uma atividade, que se distingue de outra pelo mesmo fundamento,
acarreta a multiplicação dessa outra. Ora, a potência e o hábito distinguem-se pelo mesmo fundamento,
a saber, pelos atos e pelos objetos. Logo, também assim se multiplicam. Logo, não podem existir muitos
hábitos numa mesma potência.

2. Demais — A potência é uma virtude simples. Ora, num sujeito simples não pode haver diversidade de
acidentes, porque o sujeito é causa do acidente e do que é simples só pode resultar um ser. Logo, numa
mesma potência não podem existir muitos hábitos.

3. Demais — Assim como o corpo é formado pela figura, assim o é a potência pelo hábito. Ora, um
mesmo corpo não pode ser formado simultaneamente por várias figuras. Logo, também uma potência
não pode ser simultaneamente formada por muitos hábitos. Logo, muitos hábitos não podem existir
simultaneamente na mesma potência.
Mas, em contrário, o intelecto é uma potência, na qual, contudo há hábitos de diversas ciências.

SOLUÇÃO. — Como já dissemos, os hábitos são disposições do que é potencial em relação a alguma
coisa, quer seja a natureza, quer uma operação ou fim da natureza. — Ora, os hábitos que são
disposições para a natureza, podem, manifestamente, existir vários num mesmo sujeito, porque as
partes deste podem ser consideradas diversamente, e conforme a disposição delas assim se denominam
os hábitos. Assim, se consideramos os humores como partes do corpo humano, da disposição deles em
a natureza humana depende o hábito ou disposição da saúde. Se porém considerarmos as partes
semelhantes, como os nervos, os ossos e as carnes, a mesma disposição em ordem à natureza constitui
a fortaleza ou a magreza. Se por fim levarmos em conta os membros, como as mãos, os pés e outros, a
disposição deles conveniente à natureza é a beleza. E assim há vários hábitos ou disposições num
mesmo sujeito.
Se porém considerarmos os hábitos que são disposições para a operação e que propriamente
pertencem às potências, também podem vários pertencer a uma mesma potência. E a razão é que o
sujeito do hábito é a potência passiva, como já dissemos; pois, a potência que só é ativa não é sujeito de
nenhum hábito, como consta claramente do sobredito. Ora, a potência passiva está para o ato
determinado de uma mesma espécie, como a matéria está para a forma; pois assim como a matéria é
determinada a uma mesma forma por um mesmo agente, assim a potência passiva é determinada, por
virtude de um objeto ativo, a um ato específico. Por onde, assim como vários objetos podem mover
uma potência passiva, assim uma potência passiva pode ser sujeito de diversos atos ou perfeições
especificamente considerados. Ora, os hábitos são qualidades ou formas inerentes à potência, pelos
quais esta se inclina a atos especificamente determinados. Por onde, a uma mesma potência podem
pertencer vários hábitos, assim como vários atos especificamente diferentes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como nos seres naturais a diversidade das espécies se
funda na forma, e a diversidade dos gêneros se funda na matéria, como já se disse, porque seres
genericamente diversos têm matéria diversa; assim também a diversidade genérica dos objetos produz
a distinção das potências, e por isso o Filósofo diz que seres genericamente diferentes têm também
partículas diferentes da alma. A diversidade específica dos objetos, por fim, causa a diversidade
específica dos atos e por conseqüência, dos hábitos. Ora, a diversidade genérica implica a diversidade
específica, mas não inversamente. Portanto, a potência diversas correspondem atos específicos diversos
e diversos hábitos. Não é necessário porém que hábitos diversos pertençam a potências diversas; antes,
vários podem pertencer a uma mesma potência. E assim como há gêneros de gêneros e espécies de
espécies, assim também podem existir diversas espécies de hábitos e potências.

RESPOSTA À SEGUNDA. — Embora essencialmente simples, a potência é de virtude múltipla, porque
pode se estender a muitos atos especificamente diferentes. Por onde, nada impede existam numa
mesma potência muitos hábitos especificamente diferentes.

RESPOSTA À TERCEIRA. — O corpo é formado pela figura como pela sua terminação própria. Ora, o
hábito não é uma terminação da potência, mas, uma disposição para o ato, como seu último termo.
Portanto, numa mesma potência não podem existir simultaneamente vários hábitos, senão talvez
enquanto um está compreendido no outro; assim como também um mesmo corpo não pode ter várias
figuras, senão enquanto que uma está na outra, como o triângulo no quadrângulo. Pois, o intelecto não
pode inteligir muitos objetos simultânea e atualmente; pode porém saber muitas simultânea e
habitualmente.

## Art. 2 — Se os hábitos distinguem-se pelos objetos.
(Infra, a . 3; q. 60, a . 1; q. 63, a . 4; III Sent., dist. XXXIII, q. 1. a . 1, qª 1).
O segundo discute-se assim. — Parece que os hábitos não se distinguem pelos objetos.

1. — Pois, os contrários são especificamente diferentes. Ora, o mesmo hábito da ciência diz respeito a
objetos contrários; assim, a medicina tem por objeto o são e o doente. Logo, os hábitos não se
distinguem por objetos especificamente diferentes.

2. Demais — Ciências diversas pertencem a hábitos diversos. Ora, um mesmo cognoscível pode
pertencer à ciência diversas; assim, o naturalista e o astrólogo demonstram que a terra é redonda, como
diz Aristóteles. Logo, os hábitos não se distinguem pelos objetos.

3. Demais — Os mesmos atos têm o mesmo objeto. Ora, um mesmo ato pode pertencer a diversos
hábitos virtuosos, desde que se refira a fins diversos; assim, dar dinheiro a alguém, por amor de Deus,
pertence à caridade; mas, se for para solver um débito, pertence à justiça. Logo, também um mesmo
objeto pode pertencer a diversos hábitos; e portanto, a diversidade dos hábitos não depende da
diversidade dos objetos.
Mas, em contrário. — Os atos diferem especificamente segundo a diversidade dos objetos, como já se
disse. Ora, os hábitos são certas disposições para os atos. Logo, também se distinguem pelos seus
objetos diversos.

SOLUÇÃO. — O hábito é tanto hábito como uma determinada forma. Por onde, a distinção dos hábitos
pode fundar-se na espécie, ou no modo comum pelo qual as formas se distinguem especificamente, ou
no modo próprio da distinção dos hábitos. Ora, as formas se distinguem umas das outras pelos diversos
princípios ativos, porque todo agente produz o que lhe é especificamente semelhante. O hábito, por seu
lado, implica em ordenar-se para algum termo. Ora, todas as coisas que se consideram ordenadas para
algum termo, distinguem-se pela distinção dos termos a que se ordenam. Ora, o hábito é uma
disposição ordenada para dois termos: a natureza e a operação dela resultante. — Assim, pois, a três
luzes os hábitos se distinguem especificamente: pelos princípios ativos de tais disposições, pela natureza
e pelos objetos especificamente diferentes, como a seguir se explicará.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na distinção das potências e também dos hábitos, não
devemos considerar o objeto materialmente, mas a sua noção específica ou mesmo genericamente
diferente. Pois, embora os contrários especificamente difiram pela diversidade das coisas, contudo pela
mesma razão os conhecemos a ambos, pois um é conhecido pelo outro. E portanto, enquanto convêm
na mesma razão de cognoscibilidade, pertencem ao mesmo hábito cognoscitivo.

RESPOSTA À SEGUNDA. — Que a terra é redonda, o físico o demonstra por um meio e o astrólogo por
outro. Este o faz por meios matemáticos, como, pelas figuras dos eclipses ou outro meio semelhante. O
físico, por seu lado, o demonstra por meios naturais, como o movimento dos graves para o centro ou
meios semelhantes. Ora, todo o valor da demonstração, que é o silogismo que nos leva ao
conhecimento, como se disse, depende do termo médio. Por onde, meios diversos são como diversos
princípios ativos, pelos quais os hábitos das ciências se diversificam.

RESPOSTA À TERCEIRA. — Como diz o Filósofo, o fim se comporta relativamente às ações, como o
princípio relativamente às demonstrações. Por onde, a diversidade dos fins diversifica as virtudes, bem
como a diversidade dos princípios ativos. Ora, são os fins, objetos dos atos internos, que pertencem
principalmente às virtudes, como do sobredito resulta.

## Art. 3 — Se os hábitos se distinguem pelo bem e pelo mal.
(III Sent., dist. XXXIII, q. 1, a . 1, q. 1).
O terceiro discute-se assim. — Parece que os hábitos não se distinguem pelo bem e pelo mal.

1. — Pois, o bem e o mal são contrários. Ora, um mesmo hábito pode referir-se a dois contrários, como
já se disse. Logo, os hábitos não se distinguem pelo bem e pelo mal.

2. Demais — O bem converte-se com o ente e assim, sendo comum a todos, não pode ser considerado
como diferença de nenhuma espécie, conforme se vê claramente no Filósofo. Semelhantemente, o mal,
sendo privação e não-ente, não pode ser diferente de nenhum ser. Logo, os hábitos não se podem
distinguir especificamente pelo bem e pelo mal.

3. Demais — Diversos hábitos maus podem dizer respeito ao mesmo objeto, como os que dizem
respeito à concupiscência, à intemperança e à insensibilidade; e o mesmo se dá com muitos hábitos
bons, como a virtude humana e a heróica ou divina, conforme se vê claramente pelo Filósofo. Logo, os
hábitos não se distinguem pelo bem e pelo mal.
Mas, em contrário, o hábito bom contraria o hábito mau; assim, a virtude, o vício. Ora, os contrários são
especificamente diversos. Logo, os hábitos diferem especificamente pelo bem e pelo mal.

SOLUÇÃO. — Como já dissemos, os hábitos se distinguem especificamente, não só pelos objetos e
princípios ativos, mas também por ordenarem-se à natureza; e isto pode dar-se de dois modos. — De
um modo, conforme a conveniência ou inconveniência em relação à natureza. E então distingue-se
especificamente o hábito bom e o mau. Pois, chama-se bom o que dispõe para o ato conveniente à
natureza do agente; e mau é o que dispõe para o ato não conveniente à natureza. Assim, os atos das
virtudes da natureza humana convêm em serem conformes à razão; ao passo que os dos vícios, sendo
contrários à razão, discordam da natureza humana. Por onde, é manifesto que os hábitos se distinguem
especificamente pela diferença do bem e do mal. — De outro modo, segundo a natureza, os hábitos
distinguem-se enquanto que uns dispõem para o ato conveniente à natureza inferior; outros, ao ato
conveniente à natureza superior. E assim a virtude humana, que dispõe para o ato conveniente à
natureza humana, distingue-se da virtude divina ou heróica, que dispõe para o ato conveniente a uma
certa natureza superior.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um mesmo hábito pode referir-se a dois contrários,
quando estes convêm numa mesma noção. Nunca porém se pode dar que hábitos contrários sejam de
uma mesma espécie; pois, a contrariedade dos hábitos se funda em noções contrárias. E assim os
hábitos se distinguem pelo bem e pelo mal, i. é, enquanto um é bom e outro mau; e não porque um diga
respeito ao bem e outro, ao mal.

RESPOSTA À SEGUNDA. — O bem comum a todos os entes não é uma diferença constitutiva da espécie
de nenhum hábito; mas, um certo e determinado bem, fundado na conveniência com uma determinada
natureza, a saber, a humana. Semelhantemente, o mal, como diferença constitutiva do hábito, não é
uma privação pura, mas algo de determinado, repugnante a uma determinada natureza.

RESPOSTA À TERCEIRA. — Vários hábitos bons referentes ao mesmo objeto específico, distinguem-se
pela conveniência com diversas naturezas, como já se disse. Ao passo que vários hábitos maus se
distinguem, relativamente a uma mesma ação, pelas diversas repugnâncias relativas ao que é conforme
à natureza; assim, a uma virtude são contrários os diversos vícios relativos à mesma matéria.
Tratado das virtudes em geral