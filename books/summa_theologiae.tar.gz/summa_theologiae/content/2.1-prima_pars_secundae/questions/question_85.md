# Questão 85: Dos efeitos do pecado e, primeiro, da corrupção do bem da
natureza.
Em seguida devemos tratar dos efeitos do pecado. E, primeiro da corrupção do bem da natureza.
Segundo, da mácula da alma. Terceiro, do reato da pena. Na primeira questão discutem-se seis artigos:

## Art. 1 — Se o pecado diminui o bem da natureza.
(I q. 48, a. 4; II Sent., dist. III, q. 3, ad 5; dist. XXX, q, 1, a. 1, ad 3; dist. XXXIV, a 5; III dist. XX, a. 1, qª 1, ad
1; III Cont Gent., cap. XII ; De Malo, q. 2, a. 11).
O primeiro discute-se assim. — Parece que o pecado não causa detrimento ao bem da natureza.

1. — Pois, o pecado do homem não excede em gravidade o do demônio. Ora, os dons naturais
permanecem íntegros nos demônios, depois do pecado, como diz Dionísio. Logo, o pecado também não
causa detrimento ao bem da natureza humana.

2. Demais. — A alteração do que é posterior não implica a do anterior; assim, a substância permanece a
mesma, embora se mudem os acidentes. Ora, a natureza preexiste à ação voluntária. Logo, embora o
pecado cause a desordem na ação, voluntária, nem por isso se altera a natureza, de modo a lhe ficar
diminuído o seu bem.

3. Demais. — O pecado é um ato; ao passo, que sofrer detrimento é uma paixão. Ora nenhum agente,
como tal, é paciente; é possível porém que atue sobre um paciente e sofra a ação de outro agente.
Logo, quem peca não causa detrimento, pelo pecado, ao bem da sua natureza.

4. Demais. — Nenhum acidente pode agir sobre o seu sujeito. Pois, sofrer uma ação é próprio do ser
potencial; ao passo que o sujeito do acidente já é ser atual, em relação a esse acidente. Ora, o pecado
reside no bem da natureza como o acidente, no sujeito. Logo, o pecado não diminui esse bem, pois,
diminuir é, de algum modo, agir.
Mas, em contrário, como diz o Evangelho (Lc 10, 30): Um homem baixava de Jerusalém a Jericó, i. é, à
prevaricação do pecado; é despojado dos bens gratuitos e vulnerado nos naturais, como expõe Beda.
Logo, o pecado causa detrimento ao bem da natureza.

SOLUÇÃO. — O bem da natureza humana pode ser considerado à tríplice luz. — Primeiro, como os
princípios mesmos constitutivos no que ela é; e como as propriedades deles derivadas; p. ex., as
potências da alma, e outras. — Segundo, tendo o homem, inclinação natural para a virtude, segundo já
estabelecemos (q. 60, 1; q. 63, 1), essa mesma inclinação é um certo bem natural. — Terceiro, pode-se
chamar bem natural ao dom da justiça original, conferido, no primeiro homem, a toda a natureza
humana.
Ora, o bem da natureza, primeiramente enumerado, não o destrói o pecado e nem o diminui. O
terceiro, porém, o pecado do primeiro pai totalmente o destruiu. Mas o médio, i. é, a inclinação natural
para a virtude, fica diminuído pelo pecado. Pois, os atos humanos produzem uma certa inclinação para
outros atos semelhantes, como já se demonstrou (q. 50, a. 1). Necessariamente porém, aquilo que se
inclina para um contrário fica com a inclinação diminuída para o outro. Por onde, sendo o pecado
contrário à virtude, o próprio pecar do homem diminui-lhe o bem da natureza, que é a inclinação para a
virtude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dionísio se refere ao bem primeiro da natureza, que é
existir, viver e inteligir, como é claro a quem lhe refletir nas palavras.

RESPOSTA À SEGUNDA. — Embora a natureza seja anterior à ação voluntária, tem contudo inclinação
para ela. Por onde, a natureza, em si mesma, não varia com a variação de tal ação; mas é a inclinação
mesma a que varia, enquanto ordenada para um termo.

RESPOSTA À TERCEIRA. — A ação voluntária procede de diversas potências, das quais uma é ativa e a
outra, passiva. Donde resulta que as ações voluntárias podem causar no homem, que as pratica, um
acréscimo ou um detrimento, conforme já dissemos (q. 51, a. 2), quando tratamos da geração dos
hábitos.

RESPOSTA À QUARTA. — O acidente age sobre o seu sujeito, não efetiva, mas formalmente, no sentido
em que se diz que a brancura torna branco. E assim, nada impede diminua o pecado o bem da natureza;
mas de modo a constituir a diminuição mesma desse bem, por ser um ato desordenado. Quanto porém
à desordem do agente, ela é causada pelo que os atos da alma tem de ativo e de passivo. Assim, o
sensível move o apetite sensitivo e este inclina a razão e a vontade, como já dissemos (q. 77, a. 1, 2).
Donde a desordem; não por atuar o acidente sobre o sujeito próprio, mas pelo objeto agir sobre a
potência, e uma potência sobre outra, desordenando-a.

## Art. 2 — Se a natureza humana pode ser privada totalmente do seu bem pelo pecado.
(I, q. 48, a. 4; II Sent., dist. VI, a. 4, ad 3; dist. XXXIV, a. 5; De Malo, q. 2, a. 12; III Cont. Gent., cap. XII).
O segundo discute-se assim. — Parece que a natureza humana pode ser privada totalmente do seu
bem pelo pecado.

1. — Pois, o bem da natureza humana é finito, por também o ser ela. Ora, o finito se exaure todo
diminuindo continuamente. E como o bem da natureza pode se diminuir continuamente pelo pecado,
conclui-se que pode de todo exaurir-se.

2. Demais. — Em seres da mesma natureza o todo e as partes tem a mesma essência, como se dá com o
ar, a água, a carne e com todos os corpos de partes semelhantes. Ora, o bem da natureza é totalmente
uniforme. Logo, como pode ser privada de uma de suas partes pelo pecado, pode também o ser, por ele
totalmente.

3. Demais. — O bem da natureza, diminuído pelo pecado, consiste em ser capaz da virtude. Ora, em
certos essa capacidade fica totalmente destruída pelo pecado, como se dá com os condenados, que não
podem readquirir a virtude, como o cego não pode recuperar a vista. Logo, o pecado pode privar
totalmente do bem da natureza.
Mas, em contrário, diz Agostinho, que o mal só pode existir no bem. Ora, o mal da culpa não pode existir
no bem da virtude ou da graça, por lhe ser contrários. Logo, há de existir no bem da natureza, e
portanto não priva totalmente dele.

SOLUÇÃO. — Como já dissemos (a. 1), o bem da natureza, diminuído pelo pecado, é a inclinação natural
para a virtude, a qual convém ao homem só por ser ele racional; pois por isso é que pode agir de
conformidade com a razão, e portanto virtuosamente. Ora, o pecado não pode privá-lo totalmente de
ser racional, pois então já não seria capaz de pecar. Logo, não é possível seja privado totalmente do
referido bem.
Certos porém, para explicar como esse bem pode sofrer continuamente detrimento pelo pecado,
recorreram a um exemplo por onde se mostra o finito diminuindo infinitamente sem nunca se
desvanecer de todo. Pois, como diz o Filósofo, se subtrairmos continuamente uma mesma quantidade,
de uma grandeza finita, esta há de desaparecer totalmente. Assim, se de uma quantidade finita
qualquer subtrairmos sempre a medida de um palmo. Se porém, a subtração se der na mesma
proporção e não segundo uma mesma quantidade, a grandeza poderá diminuir infinitamente. Assim, se
uma quantidade for dividida em duas partes, e se da metade subtrairmos a metade, poderemos
proceder ao infinito; de modo à sempre ser menor o tirado depois que o tirado antes. — Mas isto não se
dá no caso vertente. Pois, um pecado qualquer não diminui menos o bem da natureza, que o prece-
dente; antes, e talvez, mais, sendo mais grave.
E portanto, devemos dizer, de modo diverso, que a inclinação, no caso vertente, deve entender-se como
um termo médio entre dois extremos. Pois, tem sua raiz em a natureza racional; e tende para o bem da
virtude, como para o termo e o fim. De dois modos, pois, podemos lhe explicar a diminuição: em relação
à raiz e em relação ao termo. Do primeiro modo, ela não fica diminuída pelo pecado, por este não
diminuir a natureza, em si mesma, como já dissemos (a. 1). Mas diminui do segundo modo, encontrando
um obstáculo que a impeça de atingir o termo. Pois, se ficasse diminuída, do primeiro modo, poderia
então e forçosamente eliminar-se totalmente, uma vez desaparecida totalmente a natureza racional.
Mas, ficando diminuída, pelo obstáculo que se lhe opõe à consecução do termo, é claro que é
susceptível de diminuir infinitamente, por poderem os obstáculos emergir ao infinito, sendo o homem
capaz de acrescentar infinitamente pecado a pecado. Não poderá porém a inclinação desvanecer-se de
todo, por sempre lhe permanecer a raiz. Tal se dá com um corpo diáfano, que, por ser tal tem inclinação
a receber a luz; mas essa inclinação ou capacidade diminui com a sobreveniência das nuvens, embora
sempre lhes permaneça na raiz da natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe tratando-se de diminuição por
subtração. Mas no caso vertente, a diminuição se dá por um obstáculo aposto, que não elimina nem
diminui a raiz da inclinação, como se disse.

RESPOSTA À SEGUNDA. — A inclinação natural é, certo, totalmente uniforme. Mas diz respeito ao
princípio e ao termo; e, segundo essa diversidade, ora diminui, ora não.

RESPOSTA À TERCEIRA. — Mesmo nos condenados permanece a inclinação para a virtude; do contrário
não sofreriam o remorso da consciência. E se essa inclinação não se atualiza é por lhes faltar a graça,
conforme o exige a justiça. Assim também o cego conserva a aptidão para ver, na raiz mesma da
natureza, por ser um animal a que a visão é natural. Mas, esta não se atualiza, por lhe faltar a causa
adequada, que formaria o órgão necessário para ver.

## Art. 3 — Se a fraqueza, a ignorância, a malícia e a concupiscência são convenientemente consideradas lesões da natureza conseqüentes ao pecado.
(De Malo, q. 2 a. 11).
O terceiro discute-se assim. — Parece que a fraqueza, a ignorância, a malícia e a concupiscência são
inconvenientemente consideradas lesões da natureza conseqüentes ao pecado.

1. — Pois, o efeito não se identifica com a sua causa. Ora, essas lesões consideram-se causas dos
pecados, como do sobredito resulta (q. 76, a.1; q. 77, a. 3, 5; q. 78, a. 1). Logo, não devem considerar-se
efeitos do pecado.

2. Demais. — A malícia designa um pecado. Logo, não deve ser posta entre os efeitos dele.

3. Demais. — A concupiscência, sendo ato da potência concupiscível, é natural. Ora, o natural não pode
ser considerado lesão da natureza. Logo, a concupiscência não deve ser considerada tal.

4. Demais. — Como já se disse (q. 77, a. 3), o mesmo é pecar por fraqueza que por paixão. Ora, a con-
cupiscência é uma paixão. Logo, não se deve fazer distinção entre ela e a fraqueza.

5. Demais. — Agostinho estabelece duas penalidades para a alma pecadora: a ignorância e a dificuldade,
donde nasce o erro e os padecimentos. Ora, essa quádrupla enumeração não concorda com a de que
tratamos. Logo, uma delas há de ser insuficiente.
Mas, em contrário, está a autoridade de Beda.

SOLUÇÃO. — Pela justiça original, a razão continha perfeitamente as potências inferiores da alma,
sendo ela mesma aperfeiçoada por Deus, a quem estava sujeita. Ora, essa justiça original perdeu-se pelo
pecado do primeiro pai,como já dissemos (q. 81, a. 2). Por isso, todas as potências da alma ficaram, de
certo modo, destituídas da ordem própria, pela qual naturalmente se orientavam para a virtude. E a
essa destituição mesma se chama lesão da natureza.
Ora, são quatro as potências da alma capazes de serem sujeitos das virtudes, como já se disse (q. 61, a.
2), e são as seguintes. A razão, sujeito da prudência; a vontade, da justiça; o irascível, da fortaleza; a
concupiscência, da temperança. Por onde, a lesão da ignorância consiste em a razão ter ficado privada
de ordenar-se para a verdade. A da malícia, em a vontade ter ficado privada de ordenar-se, para o bem.
A da fraqueza em o ter o irascível ficado privado de ordenar-se para o árduo. E enfim, a da
concupiscência em o ter a concupiscência ficado privada de ordenar-se ao prazer moderado pela razão.
Por onde, são essas quatro as lesões infligidas a toda a natureza humana pelo pecado do primeiro pai.
— Mas, como a nossa inclinação para o bem da virtude, fica diminuída pelo pecado atual, conforme do
sobredito resulta, essas quatro lesões são conseqüências dos outros pecados. Pois a razão se embota
pelo pecado, sobretudo no agir; a vontade se endurece para o bem; aumenta a dificuldade de agir bem;
e a concupiscência mais se inflama.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede seja o efeito de um pecado causa de
outro. Assim, o desordenar-se da alma, por um pecado, inclina mais facilmente para outro.

RESPOSTA À SEGUNDA. — No caso vertente não se considera a malícia como pecado; mas como uma
inclinação da vontade para o mal, conforme aquilo da Escritura (Gn 8, 21): Os sentidos do homem são
inclinados para o mal desde a sua mocidade.

RESPOSTA À TERCEIRA. — Como já se disse (q. 82, a. 3 ad 1), a concupiscência é natural ao homem na
medida em que se lhe sujeita à razão. E se excede os limites desta, vai de encontro à natureza humana.

RESPOSTA À QUARTA. — Toda paixão pode ser considerada em geral como fraqueza, por debilitar as
forças da alma e se opor à razão. Ora, Beda toma a fraqueza em sentido estrito, enquanto oposta à
fortaleza, residente no irascível.

RESPOSTA À QUINTA. — A dificuldade a que se refere Agostinho inclui estas três lesões, das potências
apetitivas: a malícia, a fraqueza e a concupiscência. Pois, por causa delas não podemos praticar
facilmente o bem. O erro, porém, e a dor são lesões conseqüentes; pois, sofre dor quem é fraco para
alcançar o objeto da sua concupiscência.

## Art. 4 — Se a privação do modo, da espécie e da ordem são efeitos do pecado.
(De Virtut., q. 1, a. 8, ad 12).
O quarto discute-se assim. — Parece que a privação do modo, da espécie e da ordem não são efeitos
do pecado.

1. — Pois, como diz Agostinho, quando o modo, a espécie e a ordem são grandes, grande é o bem;
quando pequenos, pequeno; e nulo, quando são nulos. Ora, o pecado não anula o bem da natureza.
Logo, não priva do modo, da espécie e da ordem.

2. Demais. — Nada pode ser causa de si mesmo. Ora, o pecado é a privação do modo, da espécie e da
ordem, como diz Agostinho. Logo, a privação do modo, da espécie e da ordem não é efeito do pecado.

3. Demais. — Pecados diversos têm efeitos diversos. Ora, o modo, a espécie e a ordem, sendo diversos
entre si, parece que hão de sofrer privações diversas. Logo, a privação deles é o efeito de pecados
diversos; e portanto, não de um pecado qualquer.
Mas, em contrário, o pecado afeta a alma, como a doença ocorpo, segundo aquilo da Escritura (Sl 6,
3): Tem misericórdia de mim, Senhor, porque sou enfermo. Ora, a enfermidade priva do modo, da
espécie e da ordem do corpo. Logo, o pecado priva do modo, da espécie e da ordem da alma.

SOLUÇÃO. — Como já dissemos na Primeira Parte (q. 5, 5), o modo, a espécie e a ordem são consecu-
tivos a todo bem criado, como tal, e mesmo a todo ser. Pois, todo ser e todo bem é considerado tal pela
relação com alguma forma, em que se funda a espécie. Ora, a forma de um ser, substancial ou acidental,
depende de uma certa medida; e por isso o Filósofo diz que as formas das coisas são como os números.
Donde o ter a forma um certo modo, relativo à medida. E pela sua forma um ser se ordena a outro. E
assim, conforme os diversos graus dos bens são os graus diversos do modo, da espécie e da ordem.
Há pois um certo bem pertinente à substância mesma da natureza, que tem o seu modo, a sua espécie e
ordem; e esse não sofre privação nem detrimento pelo pecado. Há outro bem, o da inclinação natural,
que, por seu lado, tem o seu modo, a sua espécie e a sua ordem, e padece detrimento pelo pecado,
como já se disse (a. 1, 2), mas não fica completamente eliminado. Há ainda o bem davirtude e da graça,
que por sua vez tem o seu modo, a sua espécie e ordem, e esse fica totalmente destruído pelo pecado
mortal. Há por fim, o bem consistente no ato ordenado, em si mesmo, e também tem o seu modo, a sua
espécie e a sua ordem; e a privação deste constitui o pecado mesmo, essencialmente. Por onde se
evidencia como o pecado é privação do modo, da espécie e da ordem; e priva deles ou os diminui.
Donde se deduz clara a resposta às DUAS PRIMEIRAS OBJEÇÕES.

RESPOSTA À TERCEIRA. — O modo, a espécie e a ordem são consecutivos entre si, como do sobredito
resulta. Por isso sofrem privação e diminuição, simultaneamente.

## Art. 5 — Se a morte e as outras misérias do corpo são efeitos do pecado.
(IIª-IIªª, q. 164, a 1; II Sent., dist. XXX, q. 1, a 1; III, dist. XVI, q. 1, a. 1; IV, Protog.; dist. IV, q. 2, a. 1, qª 3;

IV, Cont. Gent., cap. LII; De Malo, q. 5, a. 4; Compend. Theol., cap. CXCIII; Ad Rom., cap. V, lect. III; Ad
Hebr., cap. IX, lect V).
O quinto discute-se assim. — Parece que a morte e as outras misérias do corpo não são efeitos do
pecado.

1. — Pois, causas iguais produzem efeitos iguais. Ora, as referidas misérias não são iguais para todos,
mas abundam nuns mais que em outros; embora, como já disse (q. 82, a. 4), para todos seja o mesmo o
pecado original, de que elas são o principal efeito. Logo, a morte e as misérias do corpo não são efeitos
do pecado.

2. Demais. — Removida a causa, removido fica o efeito. Ora, removido todo pecado, pelo batismo ou
pela penitência, não ficam removidas as misérias do corpo. Logo, não são efeitos do pecado.

3. Demais. — O pecado atual é mais essencialmente pecado que o original. Ora, o pecado atual não
altera a natureza do corpo, sendo causa de alguma de suas misérias. Logo, com maior razão, nem o
pecado original. Portanto, a morte e as outras misérias do corpo não são efeitos do pecado.
Mas, em contrário, diz o Apóstolo (Rm 5, 12): por um homem entrou o pecado neste mundo e, pelo
pecado, a morte.

SOLUÇÃO. — De dois modos pode uma causa produzir um efeito: essencial e acidentalmente.
Essencialmente, quando o produz em virtude da sua natureza ou forma; donde se conclui ter sido o
efeito em si mesmo o fim da causa. Por onde, estando a morte e as outras misérias do corpo fora da
intenção do pecador, é manifesto que o pecado não é, em si mesmo, causa dessas misérias.
Acidentalmente, quando remove um obstáculo; assim, como diz Aristóteles, quem arranca uma coluna
move acidentalmente a pedra que lhe estava sobreposta. E deste modo, o pecado do primeiro pai é
causa da morte e de todas as misérias do corpo em a natureza humana. Pois, esse pecado nos privou da
justiça original, que continha sujeitas à razão, sem nenhuma desordem, não só as potências inferiores
da alma, mas sujeitava também todo o corpo à alma, sem nenhuma deficiência, como estabelecemos na
Primeira parte (q. 97, a. 1). Por onde, perdida essa justiça original, pelo pecado do primeiro pai, assim
como a natureza humana ficou lesada na alma, pela desordem das potências, segundo já provamos (q.
82, a. 3); assim também se tornou corruptível pela desordem do próprio corpo.
Ora, a perda da justiça original, como a da graça, constitui uma pena. Por onde, também a morte, e
todos as misérias corpóreas conseqüentes, são penas do pecado original. E embora essas misérias não
estivessem na intenção do pecador, foram contudo pela justiça punitiva de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Causas iguais essenciais produzem, por si mesmas,
efeitos iguais. Pois, aumentada ou diminuída a causa essencial, aumenta ou diminui o efeito. Mas da
igualdade de causas, que removem apenas um obstáculo, não se lhes deduz a igualdade dos efeitos.
Assim, de derrubarmos, com igual impulso, duas colunas, não se segue sejam as pedras, que lhes estão
sobrepostas, igualmente movidas; mas, há de mover-se mais velozmente a que for mais pesada,
segundo a sua propriedade, e que fica abandonada a si mesma, uma vez removido o obstáculo. Do
mesmo modo, removida a justiça original, a natureza do corpo humano ficou abandonada a si própria. E
desde então, segundo a diversidade da compleição natural, os corpos de uns ficam sujeitos a maiores
misérias; os de outros, a menores, embora o pecado original afete igualmente a todos.

RESPOSTA À SEGUNDA. — A culpa original e a atual removem-se do mesmo sujeito de que se removem
as misérias corpóreas, conforme aquilo do Apóstolo (Rm 8, 11): dará vida aos vossos corpos mortais,
pelo Espírito, que habita em vós. Mas, uma e outra coisa se realizarão em tempo oportuno, segundo a
ordem da divina sabedoria. Pois, havemos de chegar à imortalidade e à impassibilidade da glória,
começada em Cristo, que no-la adquiriu, depois de lhe termos, durante a vida, participado dos
sofrimentos. Por isso, é necessário que, conformes com Cristo, a sua passibilidade perdure nos nossos
corpos, para merecermos a impassibilidade de glória.

RESPOSTA À TERCEIRA. — Dois elementos podemos considerar no pecado atual: a substância mesma
do ato e a culpa. Quanto àquela, o pecado atual pode causar misérias ao corpo; assim muitos adoecem
e morrem por comerem demais. Quanto à esta, priva da graça, que nos é dada para retificar os atos da
alma, e não para impedir as misérias do corpo, como o fazia a justiça original. Por onde, o pecado atual
não causa, como o original, essas misérias.

## Art. 6 — Se a morte e as demais misérias do corpo são naturais ao homem.
(IIª-IIªª, q. 164, a. 1, ad 1; II Sent., dist. XXX, q. 1, a. 1; III. Dist. XVI q. 1. a. 1; IV, dist. XXXVI, a. 1, ad 2; IV
Cont. Gent., cap. LII; De Malo, q. 5. a. 5; Ad Rom., cap. V, lect III; Ad Hebr., cap. IX, lect. V).
O sexto discute-se assim. — Parece que a morte e as demais misérias do corpo são naturais ao
homem.

1. — Pois, o corruptível difere genericamente do incorruptível, como diz Aristóteles. Ora, o homem é do
mesmo gênero que os brutos, que são naturalmente corruptíveis. Logo, também ele é naturalmente
corruptível.

2. Demais. — Tudo o que é composto de princípios contrários é corruptível, quase tendo em si mesmo a
causa da corrupção própria. Ora, tal é o corpo humano. Logo ele é naturalmente corruptível.

3. Demais. — O quente naturalmente consome o úmido. Ora, a vida humana se conserva pelo calor e
pela umidade. E como as operações vitais se exercem pelo ato do calor natural, como diz Aristóteles,
resulta que a morte e as demais misérias do corpo são naturais ao homem.
Mas, em contrário. — 1. Tudo o natural ao homem foi Deus quem o fez. Ora, Deus não fez a morte,
como diz a Escritura (Sb 1, 13). Logo, ela não é natural ao homem.

2. Demais. — O conforme à natureza não pode ser considerado pena nem mal, a todo ser é conveniente
o que lhe é natural. Ora, a morte e as demais misérias do corpo são a pena do pecado original, como já
se disse (a. 5). Logo, não são naturais ao homem.

3. Demais. — A matéria se proporciona à forma, e todas as coisas, ao seu fim. Ora, o fim do homem é a
beatitude perpétua, como já se disse (q. 2, 7; q. 5, a. 3-4). E também a forma do corpo humano é a alma
racional, que é incorruptível, como já se demonstrou na Primeira Parte (q. 75, 6). Logo, o corpo humano
é naturalmente incorruptível.

SOLUÇÃO. — De dois modos podemos considerar um ser corruptível: relativamente à natureza
universal, e à particular. — A natureza particular é a virtude ativa e conservativa própria do ser. E sendo
assim, toda corrupção e deficiência é contra a natureza, como diz Aristóteles; pois, a virtude referida
busca a existência e a conservação do ser a que pertence.
Por outro lado, a natureza universal é a virtude ativa existente num princípio universal da natureza, p.
ex., em algum dos corpos celestes ou em alguma substância superior, o que leva certos a darem a Deus
a denominação de natureza naturante. E essa virtude busca o bem e a conservação do universo,
exigindo esta última alternem-se a geração e a corrupção das coisas. E sendo assim, as corrupções e as
deficiências dos seres são naturais; não certo pela inclinação da forma, princípio da existência e da
perfeição; mas pela da matéria, atribuída proporcionalmente a uma determinada forma, conforme a
distribuição do agente universal. E embora toda forma tenda a perdurar no ser, o quanto possível
perpetuamente, contudo nenhuma forma de ser corruptível pode conseguir a perpetuidade de
existência. Exceto a alma racional, por não estar, como as outras formas, sujeita de modo nenhum à
matéria corpórea; antes, é dotada da sua atividade imaterial própria, como já demonstramos na
Primeira Parte (q. 75, a. 2). Por onde, quanto à sua forma, é natural ao homem, mais que aos outros
seres corruptíveis, a incorrupção. Mas como essa forma está ligada à matéria, composta de princípios
contrários, da inclinação da matéria resulta a corruptibilidade do todo. E a esta luz, o homem é natural-
mente corruptível, segundo a natureza da matéria, abandonada a si mesma, e não segundo a natureza
da forma.
Ora, as três primeiras objeções se fundam na matéria; e as outras três, na forma. Por onde, para solvê-
las, devemos considerar que a forma do homem, a alma racional, é, pela sua incorruptibilidade,
proporcionada ao seu fim, que é a felicidade perpétua. O corpo humano porém, corruptível,
considerado na sua natureza, é de certo modo proporcionado à sua forma, e de certo, outro, não. Pois,
podemos levar em conta, em qualquer matéria, uma dupla condição: escolhida pelo agente, e a não
escolhida, por se fundar na condição natural da matéria. Assim, o ferreiro, para fazer uma faca, escolhe
matéria dura e ductil, capaz de adelgaçar-se e tornar-se apta à incisão. E nessascondições o ferro é
matéria proporcionada à faca. Mas, pela sua natural disposição, o ferro é frágil e contrai a ferrugem; e
essa disposição não a escolhe o artífice, antes a repudiaria, se pudesse. Por onde, tal disposição da
matéria não é proporcionada à intenção do artífice nem ao fim da arte. Semelhantemente, o corpo
humano é pela sua compleição equilibrada, a matéria escolhida pela natureza para órgão
convenientíssimo ao tato e às outras potências sensitivas e motoras. Mas é corruptível, por causa da
condição da matéria. E essa corruptibilidade a natureza não a escolheu; antes, se pudesse, escolheria
matéria incorruptível. Deus porém, a quem está sujeita toda a natureza, supriu, na instituição do
homem, essa deficiência da natureza, dando ao corpo uma certa incorruptibilidade, pelo dom da justiça
original, como dissemos na Primeira Parte (q. 97, a. 1). E por isso se diz que Deus não fez a morte, e que
a morte é a pena do pecado.
Por onde é clara a RESPOSTA ÀS OBJEÇÕES.