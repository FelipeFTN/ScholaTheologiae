# Questão 67: Da duração das virtudes depois desta vida.
Em seguida devemos tratar da duração das virtudes depois desta vida.
E sobre esta questão seis artigos se discutem:

## Art. 1 — Se as virtudes morais permanecem depois desta vida.
(IIª. lIae, q. 136, a. 1, ad 1 ; III Sent., dist. XXXIII, q. 1, a. 4 ; De Virtut., q. 5, a. 4).
O primeiro discute-se assim.— Parece que as virtudes morais não permanecem depois desta vida.

1. — Pois no estado da glória futura os homens serão como anjos, como diz a Escritura (Mt 22, 30). Ora,
é ridículo atribuir aos anjos virtudes morais, como se disse. Logo, também os homens, depois desta vida,
não terão virtudes morais.

2. Demais. — As virtudes morais aperfeiçoam o homem na vida ativa. Ora, não há atividade na vida
futura, como diz Gregório: As obras da vida ativa desaparecem com o corpo. Logo, as virtudes morais
não permanecem depois desta vida.

3. Demais. — A temperança e a coragem, que são virtudes morais, são relativas às partes irracionais,
como diz o Filósofo. Ora, estas partes desaparecem com a desaparição do corpo, por serem atos de
órgãos corpóreos. Logo, parece que as virtudes morais não permanecem depois desta vida.
Mas, em contrário, diz a Escritura (Sb 1, 15): A justiça é perpétua e imortal.

SOLUÇÃO. — Como refere Agostinho, Túlio ensinou que, depois desta vida, não mais existem as quatro
virtudes cardeais, e que então os homens serão felizes só pelo conhecimento da natureza, que é melhor
e mais desejável que tudo, conforme diz Agostinho no mesmo lugar; mas por aquela natureza que criou
todas as naturezas. E Agostinho, por sua vez, determina que essas virtudes existem na vida futura, mas
de outro modo.
Para prová-lo devemos saber que, essas virtudes têm algo de formal e algo de quase material. O que
nelas há de material é uma inclinação da parte apetitiva para as paixões ou operações, segundo um
certo modo. Mas como este modo é determinado pela razão, o que há de formal em todas as virtudes é
a ordem mesma da razão.
Portanto, devemos concluir que as virtudes em questão, pelo que tem de material, não permanecem na
vida futura; pois, nela não existirá mais concupiscência nem prazeres do comer ou venéreos; nem temor
e coragem provocados pelo perigo da morte; nem distribuições ou comunicações de coisas que servem
ao uso da vida presente. Mas quanto ao que há nelas de formal, permanecerão perfeitíssimamente
depois desta vida, nos bem-aventurados, sendo então a razão de cada um retíssima quanto ao que lhe
diz respeito, nesse novo estado; e a potência apetitiva se moverá absolutamente obediente à ordem da
razão, em tudo o que a esse estado pertence. E por isso Agostinho no mesmo lugar diz que, então,
haverá prudência sem nenhum perigo de erro; fortaleza, sem o sofrimento de suportar os males;
temperança sem a repugnância da concupiscência; de modo que a prudência consistira em não preferir
nenhum bem a Deus nem com ele o igualar; a fortaleza, em se unir com ele fortemente; a temperança,
em não se deleitar com nenhum vício nocivo. Quanto à justiça é claro que o ato que dela permanecer
será submeter-se a Deus, pois já nesta vida é ato de justiça sujeitarmo-nos aos superiores.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No lugar aduzido o Filósofo se refere ao que há de
material nessas virtudes morais; i. é, à justiça, quanto à comunicação e à distribuição (dos bens); à
fortaleza, quanto ao que nos causa terror e perigo; à temperança, quanto às vis concupiscências.
E semelhantemente se deve responder à segunda. — Tudo o que respeita a vida ativa constitui a parte
material da virtude.

RESPOSTA À TERCEIRA. — Há duplo estado depois desta vida: um, anterior à ressurreição, estando as
almas separadas do corpo; outro, posterior a ela, quando de novo se unirem aos seus corpos. Neste
último estado existirão, como agora, as potências irracionais em órgãos corpóreo; e portanto, poderá
existir a fortaleza, no irascível e no concupiscível; a temperança, estando ambas essas potências
perfeitamente dispostas a obedecer à razão. Mas no estado anterior à ressurreição as partes irracionais
não existirão na alma, atualmente, mas só radicalmente na essência dela, como já dissemos na primeira
parte. Por onde, as virtudes de que tratamos só existirão em ato na sua raiz, i. é, na razão e na vontade,
onde estão os como que seminários delas, como já dissemos. A justiça porém, que reside na vontade,
permanecerá mesmo em ato. E por isso dela especialmente se diz que é perpétua e imortal, seja em
razão do sujeito, por ser a vontade incorruptível; seja também pela semelhança do ato, como já antes se
disse.

## Art. 2 — Se as virtudes intelectuais perduram depois desta vida.
(I, q. 89, a. 5, 6 ; III Sent., dist. XXXI, q. 2, a. 4 ; IV, dist. I, q. 1, a. 2; I Cor., cap. XIII, lect. III).
O segundo discute-se assim. — Parece que as virtudes intelectuais não perduram depois desta vida.

1. — Pois, como diz o Apóstolo (1 Cor 13, 8), a ciência será abolida, porque conhecemos em parte. Ora,
assim como o conhecimento da ciência é parcial, i. é, imperfeito, o mesmo se dá com o conhecimento
das outras virtudes intelectuais, enquanto durar esta vida. Logo, depois dela, todas desaparecerão.

2. Demais. — O Filósofo diz, que a ciência, sendo um hábito, é uma qualidade dificilmente removível,
pois não o perdemos facilmente, senão só por alguma forte transmutação ou doença. Ora, nada opera
maior mudança no corpo humano que a morte. Logo, a ciência e as demais virtudes intelectuais não
perduram depois desta vida.

3. Demais. — As virtudes intelectuais tornam a inteligência apta a operar retamente o seu ato próprio.
Ora, depois desta vida o intelecto já não age, porque a alma não pode inteligir nada sem o fantasma,
como se disse; ora, os fantasmas que só podem existir em órgãos corpóreos, não permanecem depois
desta vida. Logo, também não perduram, depois dela, as virtudes intelectuais.
Mas, em contrário, o conhecimento do universal e do necessário é mais estável que o do particular e
contingente. Ora, o homem continua a ter, depois desta vida, o conhecimento do particular e do
contingente, p. ex., daquilo que fez ou sofreu, conforme a Escritura (Lc 16, 25): lembra-te que
recebestes os teus bens em tua vida, e que Lázaro, semelhantemente, teve os seus males. Logo, com
maior razão, permanece o conhecimento do universal e do necessário, objeto da ciência e das outras
virtudes intelectuais.

SOLUÇÃO. — Como já dissemos na Primeira Parte, uns ensinaram que as espécies inteligíveis não
permanecem no intelecto possível, senão enquanto ele intelige em ato; e quando cessa a intelecção
atual, as espécies só se conservam na imaginativa e na memória, que, como potências sensitivas são
atos de órgãos corpóreos. Ora, tais potências se dissolvem com a dissolução do corpo. E portanto, sendo
assim, a ciência, nem qualquer outra virtude intelectual, perdurará, depois desta vida, uma vez corrupto
o corpo.
Mas esta opinião é contra a doutrina de Aristóteles, que diz que o intelecto possível se atualiza quando,
se torna cada uma das coisas singulares, como ciente, embora seja potencial em relação ao
conhecimento atual. Também é contra a razão, por serem as espécies inteligíveis recebidas pelo
intelecto possível ao seu modo, imovelmente; sendo por isso que ele se chama lugar das espécies, quase
conservador das espécies inteligíveis. Ao passo que os fantasmas, dependentemente dos quais o
homem intelige nesta vida, aplicando-lhes as espécies inteligíveis, como dissemos na Primeira Parte,
desaparecem com a dissolução do corpo.
Por onde, no concernente aos fantasmas, que lhes são como materiais, as virtudes intelectuais
destroem-se com a destruição do corpo; perduram porém no atinente às espécies inteligíveis, existentes
no intelecto possível. Ora, as espécies são como as formas das virtudes intelectuais. Por onde, depois
desta vida, elas permanecem, pelo que têm de formal; não porém pelo que têm de material, como já
dissemos a respeito das virtudes morais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras do Apóstolo se devem entender
relativamente ao que há de material na ciência e ao modo de inteligir; porque, nem os fantasmas
continuarão a existir depois da destruição do corpo, nem haverá então uso da ciência dependente dos
fantasmas.

RESPOSTA À SEGUNDA. — Pela doença se destrói o que há de material no hábito da ciência, isto é, no
referente aos fantasmas; não porém, no concernente às espécies inteligíveis, existentes no intelecto
possível.

RESPOSTA À TERCEIRA. — A alma separada, depois da morte, tem outro modo de inteligir, sem se
converter nos fantasmas, como dissemos na Primeira Parte. E, assim, a ciência permanece, não porém
quanto ao mesmo modo de operar, como já dissemos ao tratar das virtudes morais.

## Art. 3 — Se a fé perdura depois desta vida.
(IIª. lIae, q. 4, a. 4, ad 1 ; III Sent., dist.. XXXI. q. 2, a. 1, qª 1: De Virtut., q. 5. a. 4, ad 10).
O terceiro discute-se assim. — Parece que a fé perdura depois desta vida.

1. — Pois, a fé é mais nobre que a ciência. Ora, esta perdura depois da vida presente, como já se disse.
Logo, também a fé.

2. Demais. — A Escritura diz (1 Cor 3, 2): ninguém pode pôr outro fundamento senão o que foi posto,
que é Jesus Cristo, i. é, a fé de Jesus Cristo. Ora, tirados os fundamentos, não permanece o que sobre ele
se assentava. Logo, se a fé não perdurasse depois desta vida, nenhuma outra virtude poderia perdurar.

3. Demais. — O conhecimento da fé difere do da glória como o perfeito, do imperfeito. Ora, estes dois
últimos podem coexistir; assim, no anjo, pode coexistir o conhecimento vespertino com o matutino; e
nós podemos ter simultaneamente, em relação à mesma conclusão, a ciência, por meio de um silogismo
demonstrativo, e a opinião, por meio de um silogismo dialético. Logo, também a fé pode coexistir,
depois desta vida, com o conhecimento da glória.
Mas, em contrário, diz o Apóstolo (2 Cor 5, 6): enquanto estamos no corpo, vivemos ausentes do
Senhor;(porque andamos por fé e não por visão). Ora, os que estão na glória não vivem ausentes do
Senhor, mas lhe estão presentes. Logo, na glória, depois desta vida, a fé não perdura.

SOLUÇÃO. — Por si e na sua própria causa a oposição implica em um oposto exclua o outro, enquanto
que todos os opostos incluem a oposição entre a afirmação e a negação. Noutros casos, porém, a
oposição se funda em formas contrárias, como, entre as cores, o branco e o preto; em outros ainda, ela
se funda na perfeição e na imperfeição, sendo por isso que consideramos como contrários o mais e o
menos alterado, assim, quando do menos cálido procede o mais cálido, segundo já se disse. Ora, como o
perfeito e o imperfeito se opõem, é impossível à perfeição e a imperfeição recaírem simultaneamente
sobre o mesmo sujeito.
Devemos, porém, considerar que às vezes a imperfeição é da essência específica da coisa; assim, a falta
da razão é da essência específica do cavalo ou do boi. E como o que permanece na sua identidade
numérica não pode transferir-se de uma espécie para outra, com a desaparição dessa imperfeição
desaparece a espécie do ser; assim, o boi ou o cavalo deixariam de existir se fossem racionais. Outras
vezes porém a imperfeição não pertence à essência específica, mas tem qualquer fundamento acidental
no indivíduo; assim pode às vezes faltar à razão a alguém, cujo uso está impedido pelo sono, pela
embriaguez ou por uma causa análoga. E claro porém, que, removida essa imperfeição, a substância do
ser continua a existir do mesmo modo.
Ora, é manifesto que a imperfeição do conhecimento é da essência da fé; pois, na sua definição se diz
(Heb 11, 1): a fé é a substância das coisas que se devem esperar, um argumento das coisas que não
aparecem. E Agostinho diz: Em que consiste a fé? Em crer o que não vês. Ora, conhecer o que não se
manifesta nem é visto implica imperfeição do conhecimento, a qual portanto é da essência da fé. Por
onde é manifesto que a fé, permanecendo numericamente a mesma, não pode ser um conhecimento
perfeito.
Mas devemos além disso considerar se ela pode coexistir com o conhecimento perfeito, pois nada
impede coexista às vezes, um conhecimento imperfeito com o perfeito. Ora, devemos notar que um
conhecimento pode ser imperfeito de três modos: quanto ao objeto cognoscível, quanto ao meio e
quanto ao sujeito. — Quanto ao objeto cognoscível, o conhecimento angélico matutino difere do
vespertino, assim como o perfeito, do imperfeito; pois, o conhecimento matutino tem por objeto os
seres enquanto existentes no verbo; ao passo que o vespertino os tem por objeto enquanto existentes
na própria natureza; e esta, em relação à primeira, é uma existência imperfeita. — Quanto ao meio, o
conhecimento de uma conclusão, por um meio demonstrativo, difere do que temos por um meio
provável, assim como o perfeito difere do imperfeito. — Por fim, quanto ao sujeito, a opinião, a fé e a
ciência diferem entre si como o perfeito, do imperfeito. Pois, a opinião, na sua essência, admite uma
hipótese, mas, com receio de ser a outra a verdadeira e portanto não tem a adesão firme. Ao passo que
a ciência implica essencialmente a adesão firme, com a visão intelectiva, pois tem a certeza procedente
do intelecto dos princípios. A fé, por fim, ocupa uma posição média: excede a opinião, por implicar a
adesão firme, e é inferior à ciência, por não ter a visão. Ora, como é manifesto, o perfeito e o imperfeito
não podem coexistir num mesmo ponto de vista, mas as diferenças num e noutro fundadas podem
existir simultaneamente, num mesmo ponto de vista, em algum outro objeto. — Assim, pois, o
conhecimento perfeito e o imperfeito, quanto ao objeto, de nenhum modo podem se referir ao mesmo
objeto. Podem contudo convir no mesmo meio e no mesmo sujeito; pois, nada impede tenha alguém,
uma vez e simultaneamente, por um mesmo meio, um conhecimento de dois objetos, um perfeito e o
outro, imperfeito, como, p. ex., da saúde e da doença, do bem e do mal. — semelhantemente, é
impossível o conhecimento perfeito e o imperfeito, quanto ao meio, convirem num mesmo meio. Mas
nada impede que não convenham num mesmo objeto e num mesmo sujeito; pois, pode alguém
conhecer a mesma conclusão pelo meio provável e pelo demonstrativo. — E semelhantemente, é
impossível o conhecimento perfeito e o imperfeito, quanto ao sujeito, existirem simultaneamente num
mesmo sujeito. Ora, a fé, por essência, tem uma imperfeição proveniente do sujeito, pois o crente não
vê aquilo que crê. A beatitude, por seu lado, tem essencialmente uma perfeição fundada no sujeito e
consistente em o feliz ver o que o felicita, como já dissemos. Por onde é manifesta a impossibilidade de
a fé coexistir com a beatitude, no mesmo sujeito. DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A fé é
mais nobre que a ciência, quanto ao seu objeto, que é a Verdade primeira. Mas, a ciência tem um modo
mais perfeito de conhecer, não repugnante à perfeição da beatitude i. é, à visão, como lhe repugna o
modo da fé.

RESPOSTA À SEGUNDA. — A fé é um fundamento, pelo que tem de conhecimento; e portanto, quando
o conhecimento for perfeito, mais perfeito será o fundamento.

RESPOSTA À TERCEIRA. — A SOLUÇÃO. consta com evidência do dito antes

## Art. 4 — Se a esperança perdura, depois da morte, no estado da glória.
(IIª. lIae, q. 18, a. 2 ; II Sent., dist. XXVI, q. 2, a. 5, qª 2 ; dist. XXXI, q. 2, a. 1, qª 2; De Virtut., q.4. a. 4).
O quarto discute-se assim. — Parece que a esperança perdura depois da morte, no estado da glória.

1. — Pois, a esperança aperfeiçoa, de modo mais nobre, o apetite humano, do que as virtudes morais.
Ora, estas permanecem depois desta vida, como está claro em Agostinho. Logo, com maior razão a
esperança.

2. Demais. — O temor se opõe à esperança. Ora, ele perdura depois desta vida: nos bem-aventurados, o
temor filial, que permanece sempre; nos condenados, o das penas. Logo, pela mesma razão, pode
permanecer a esperança.

3. Demais. — Como a esperança, também o desejo tem por objeto o bem futuro. Ora, os bem-
aventurados tem tal desejo, tanto em relação à glória do corpo, que as almas deles desejam, conforme
diz Agostinho, como em relação à da alma, segundo aquilo da Escritura (Ecle 24, 29): Aqueles que me
comem terão ainda fome, e os que, me bebem terão ainda sede, e ainda (1 Pd 1, 12): ao qual os
mesmos anjos desejam ver. Logo, a esperança pode existir, nos bem-aventurados, depois desta vida.
Mas, em contrário, o Apóstolo diz (Rm 8, 24): o que qualquer vê, como o espera? Ora, os bem-
aventurados vêm o objeto da esperança, que é Deus. Logo, não esperam.

SOLUÇÃO. — Como já dissemos, o que por essência implica à imperfeição do sujeito não pode coexistir
num sujeito perfeito pela perfeição oposta. Isso se vê claramente no movimento que, implicando por
essência a imperfeição do sujeito, pois, é o ato do existente em potencia, como tal, cessa quando a
potência se atualiza; assim, o que já se tornou branco não pode ainda embranquecer. Ora, a esperança
implica um certo movimento para o que ainda não possuímos, como ficou claro pelo que acima
dissemos da paixão da esperança. Portanto, quando possuirmos o que esperamos, i. é, a fruição devida,
já não poderá existir a esperança.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A esperança é mais nobre do que as virtudes morais, por
ser Deus o seu objeto. Ora, o ato dessas virtudes não repugna, como o ato da esperança, à perfeição da
felicidade, senão talvez quanto à matéria, quanto à qual não perduram. Pois as virtudes morais não
aperfeiçoam o apetite só no atinente ao objeto ainda não possuído, mas também no atualmente já
possuído.

RESPOSTA À SEGUNDA. — Há um duplo temor: o servil e o filial, como a seguir se dirá. Aquele é o da
pena, e não poderá existir na glória, onde não existe nenhuma possibilidade de pena. Este comporta
dois atos: temer a Deus, e neste ponto permanece; e temer a separação dele, e neste não permanece,
pois separar-se de Deus implica o mal, e, no caso presente, não se pode temer nenhum mal, conforme
aquilo da Escritura (Pr 1, 33):Gozaremos da abundância, sem receio de mal algum. Ora, o temor se opõe
à esperança, por oposição do bem e do mal, como já dissemos. E portanto, o temor que perdura na
glória, não se opõe à esperança. Nos condenados porém pode haver o temor da pena mais do que, nos
bem-aventurados, a esperança da glória; porque neles haverá sucessão de penas, o que implica a idéia
de futuro, objeto do temor. Ao passo que na glória dos santos não há sucessão, pois é uma como
participação da eternidade, sem pretérito nem futuro, mas só presente. E contudo também nos
condenados não haverá temor, propriamente falando. Pois, como já dissemos, o temor nunca existe
sem alguma esperança de libertação, a qual nos danados, absolutamente não existirá; portanto,
também neles não haverá temor, senão comumente falando, no sentido em que se chama temor a
qualquer expectativa de mal futuro.

RESPOSTA À TERCEIRA. — Quanto à glória da alma, os bem-aventurados não podem ter desejo, no
concernente ao futuro, pela razão já exposta. Dizemos que eles têm fome e sede, para afastar a idéia de
tédio. E pela mesma razão dizemos que os anjos têm desejo. No concernente porém à glória do corpo,
pode por certo haver desejo nas almas dos santos, não porém, esperança, propriamente falando. Mas
não, enquanto a esperança é uma virtude teologal, pois então o seu objeto é Deus e não, qualquer bem
criado. Nem tomada em sentido comum, porque, nesse caso o seu objeto é o que é árduo, como já
dissemos. Ora, o bem, cuja causa certa já possuímos, não tem para nós nada de árduo; por isso,
propriamente falando, não dizemos que quem tem dinheiro espera poder possuir uma certa coisa, pois
pode possuí-la imediatamente, comprando-a. E semelhantemente, os que já têm a glória da alma não
podem, propriamente falando, esperar a glória do corpo, mas só desejá-la.

## Art. 5 — Se algo da fé ou da esperança perdura na glória.
(II Sent., dist. XXXI. q. 2, a. 1, qª3).
Parece que algo da fé ou da esperança perdura na glória.

1. — Pois, removido o próprio, fica o comum; assim, como se disse, removido o racional, permanece o
vivo; e removido este, permanece o ente. Ora, a fé tem algo de comum com a beatitude, o
conhecimento; e algo de próprio — o enigma, pois, a fé é um conhecimento enigmático. Logo, removido
o seu enigma, resta-lhe ainda o conhecimento.

2. Demais. — A fé é um lume espiritual da alma, conforme aquilo da Escritura (Ef 1, 18): Os olhos
iluminados do vosso coração para o conhecimento de Deus; ora aqui se trata do lume imperfeito, por
comparação com a luz da glória, de que fala o salmista (Sl 35, 19): No teu lume veremos o lume. Ora, o
lume imperfeito perdura, com a superveniência do perfeito; assim, a candeia não se extingue quando o
sol nasce. Logo, parece que também o lume da fé pode coexistir com o da glória.

3. Demais. — A substância de um hábito não desaparece com a eliminação da matéria; assim, podemos
conservar o hábito da liberalidade, mesmo depois que perdemos o dinheiro, se bem não a possamos
exercer em ato. Ora, o objeto da fé é a Verdade primária não vista. Logo, removido aquilo pelo que
vemos essa Verdade, ainda pode permanecer o hábito da fé.
Mas, em contrário, a fé é um hábito simples. Ora, o simples ou há de desaparecer totalmente ou
totalmente subsistir. Logo, como a fé não subsiste totalmente, mas desaparecerá, segundo se disse,
conclui-se que desaparecerá totalmente.

SOLUÇÃO. — Certos disseram que a esperança desaparece totalmente; mas, a fé desaparece em parte
— quanto ao enigma; e subsiste em parte — quanto à substância do conhecimento. Ora, se esta opinião
exprime que a fé subsiste una, não numérica, mas genericamente, é muito verdadeira. Pois, a fé convém
com a visão da pátria num mesmo gênero, que é o conhecimento; mas, a esperança não convém
genericamente com a felicidade, pois ela está para o gozo da beatitude como o movimento para o
repouso final.
Se ela porém, significa que o conhecimento da fé subsistirá no céu numericamente o mesmo, isto é
absolutamente impossível. Pois, removida a diferença de uma espécie, a substância genérica não
permanece numericamente a mesma. Assim, removida a diferença constitutiva da brancura, não
permanece a substância da cor numericamente a mesma, de modo que uma mesma cor,
numericamente, fosse, ora, a brancura e, ora, a negrura. Porquanto, o gênero não está para a diferença
como a matéria, para a forma, de modo que subsiste a substância genérica, numericamente a mesma,
depois de removida a diferença; assim como, removida a forma, a substância da matéria permanece
numericamente a mesma. Ora, o gênero e a diferença não são partes da espécie; mas assim como a
espécie significa um todo material, i. é, o composto da matéria e da forma, assim também a diferença
significa um todo; e o mesmo se dá com o gênero; mas, ao passo que este denomina o todo, enquanto
sendo como que a matéria, a diferença o denomina enquanto sendo como que a forma; e por fim a
espécie, enquanto uma e outra. Assim, no homem, a natureza sensitiva é como a matéria da intelectiva,
pois se chama animal ao que tem natureza sensitiva; racional ao que tem a intelectiva e homem, ao que
as tem a ambas. E, assim, o mesmo todo é expresso por esses três elementos, mas, não, do mesmo
modo. Donde consta com clareza, que, a diferença, não designando senão o gênero, depois de removida
a diferença à substância genérica não pode permanecer a mesma; assim, a animalidade não permanece
a mesma se for diferente a alma constitutiva do animal. Por onde, não é possível que o conhecimento,
numericamente o mesmo, que antes fora enigmático, venha a ser, depois, a visão plena. Donde se
conclui com clareza que nada do que há na fé, numérica ou especificamente o mesmo, subsiste na
pátria celeste, senão só o que for genericamente o mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Removido o racional, já um vivente não é
numericamente o mesmo, mas só genericamente, como do sobredito resulta.

RESPOSTA À SEGUNDA. — A imperfeição da luz da candeia não se opõe à perfeição da luz do sol,
porque uma e outra não recai sobre o mesmo sujeito. Ao passo que a imperfeição da fé e a perfeição da
glória entre si se opõem, e recaem sobre o mesmo sujeito; e, portanto não podem coexistir, assim como
não o pode a claridade do ar e a sua obscuridade.

RESPOSTA À TERCEIRA. — Quem perde o dinheiro não perde a possibilidade de tornar a ganhá-lo, e
portanto pode subsistir convenientemente o hábito da liberalidade. Mas no estado da glória, não só
desaparece atualmente o objeto da fé, que é o invisível, mas também na sua possibilidade, por causa da
perene beatitude. Seria pois inútil à subsistência de tal hábito.

## Art. 6 — Se a caridade subsiste, depois desta vida, na glória.
(II Sent., dist. XXXI, q. 2, a. 2; De Verit., q. 27, a. 5, ad 6; De Virtut., q. 4, a. 4, ad 7, 13, 14 ; I Cor., cap. XIII,
lect. III).
O sexto discute-se assim. — Parece que a caridade não subsiste depois desta vida, na glória.

1. — Pois, como diz a Escritura (1 Cor 13, 10), quando vier o que é perfeito, abolido será o que é em
parte, i. é, o imperfeito. Ora, a caridade é uma via imperfeita. Logo, será abolida quando chegarmos à
perfeição da glória.

2. Demais. — Os hábitos e os atos se distinguem pelos seus objetos. Ora, o objeto do amor é o bem
apreendido. Logo, como a apreensão desta vida difere da apreensão da vida futura, a mesma caridade
não poderá subsistir numa e noutra.

3. Demais. — O que num ponto de vista é imperfeito pode alcançar a igualdade da perfeição por um
aumento contínuo. Ora, a caridade da via não pode nunca chegar a igualar-se à da pátria, por mais que
aumente. Logo, a caridade da via não subsistirá na outra.
Mas, em contrário, o Apóstolo diz (1 Cor 13, 8): A caridade nunca jamais há de acabar.

SOLUÇÃO. — Como já dissemos, nada impede que aquilo que tem uma imperfeição, não pertencente à
essência, venha a ser perfeito, conservando-se numericamente tal como é; assim, o homem vem a ser
perfeito pelo crescimento, e a brancura, pela intensidade. Ora, a caridade é amor, a cuja essência não
pertence nenhuma imperfeição; pois, pode ter por objeto tanto o possuído como o que não o é, tanto o
que vemos como o que não vemos. Logo, a caridade não será abolida pela perfeição da glória, mas
permanecerá numericamente a mesma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A imperfeição pode atingir a caridade acidentalmente,
por não ser a imperfeição da essência do amor. Ora, removido o acidental, nem por isso deixa de existir
a substância. Logo, abolida a imperfeição da caridade, esta não será abolida.

RESPOSTA À SEGUNDA. — A caridade não tem por objeto o conhecimento em si mesmo, porque então
não seria a mesma nesta e na outra vida. Mas, tem como objeto, aquilo mesmo que é conhecido, e que
é sempre o mesmo, i. é, Deus.

RESPOSTA À TERCEIRA. — A caridade da via, aumentando não pode igualar a da pátria, pela diferença
causal existente. Pois, a visão é uma causa do amor, como já se disse. Ora, quanto mais perfeitamente
Deus é conhecido, tanto mais perfeitamente é amado.
Tratado dos dons do Espírito Santo