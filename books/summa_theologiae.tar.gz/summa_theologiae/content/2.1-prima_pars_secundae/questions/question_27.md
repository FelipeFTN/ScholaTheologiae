# Questão 27: Da causa do amor
Em seguida devemos tratar da causa do amor.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se o bem é a causa única do amor.
(Infra, q. 29, a . 1).
O primeiro discute-se assim. ― Parece que o bem não é a causa única do amor.

1. ― Pois, o bem não é a causa do amor senão porque é amado. Ora, acontece que também o mal é
amado, conforme a Escritura (Sl 10, 6): aquele porém que ama a iniqüidade aborrece a sua alma; do
contrário, todo amor seria bom. Logo, nem só o bem é causa do amor.

2. Demais. ― O Filósofo diz: amamos os que confessam os seus próprios vícios. Logo, o mal é causa do
amor.

3. Demais. ― Dionísio diz que não só o bem, mas ainda o belo é amável a todos.
Mas, em contrário, diz Agostinho: Certamente não é amado senão o bem. Logo, este é a causa do amor.

SOLUÇÃO. ― Como já dissemos, o amor reside na potência afetiva, que é passiva. Por onde, o seu
objeto se lhe refere como causa do seu movimento ou ato. Logo, há-de própria e necessariamente ser
causa do amor o que dele é o objeto. Ora, o objeto próprio do amor é o bem, pois, como já dissemos, o
amor implica uma certa conaturalidade ou complacência do amante em relação ao amado; pois, o bem
de cada qual é o que lhe é conatural e proporcionado. Donde se conclui, que o bem é a causa própria do
amor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O mal nunca é amado senão sob o aspecto de bem, i. é,
enquanto é bem relativo; mas é apreendido como bem, absoluto. Assim é mau o amor que não tende
para o que é absolutamente o verdadeiro bem. E deste modo o homem ama a iniqüidade enquanto que
ela alcança um certo bem, como o prazer, o dinheiro, ou coisa semelhante.

RESPOSTA À SEGUNDA. ― Os que confessam os próprios vícios não são amados por causa desses vícios,
mas por os confessarem, pois fazer tal é bom porque exclui o fingimento ou a simulação.

RESPOSTA À TERCEIRA. ― Idêntico ao bem, o belo só racionalmente dele difere. Pois, sendo o bem o
que todos os seres desejam, é da sua essência acalmar o apetite; ao passo que é da essência do belo
causar o repouso da apreensão que o vê ou o conhece. Por onde, vêm o belo principalmente os sentidos
mais susceptíveis de conhecimento, a saber, a vista e o ouvido, que servem à razão; assim, dizemos ―
belas vistas e belos sons. Em relação aos sensíveis porém dos outros sentidos, não usamos do nome de
beleza; assim não dizemos belos sabores nem belos odores. Por onde é claro, que o belo acrescenta ao
bem uma certa ordem à virtude cognoscitiva, de modo que bem se chama o que absolutamente agrada
ao apetite, e belo aquilo cuja apreensão agrada.

## Art. 2 — Se o conhecimento é causa do amor.
(IIª IIªe, q. 26, a . 2, ad 1; I Sent., dist. XV, q. 4, a . 1, a . 3).
O segundo discute-se assim. ― Parece que o conhecimento não é causa do amor.

1. ― Pois, por amor é que buscamos alguma coisa. Ora, buscamos coisas que não conhecemos, como as
ciências, pois que, sendo o possuí-las o mesmo que conhecê-las, conforme Agostinho, quando as
conhecemos as possuímos e já não as buscamos. Logo, o conhecimento não é causa do amor.

2. Demais. ― A razão que nos leva a amar o conhecimento faz com que mais o amemos, quando o
conhecemos. Ora, certos seres são mais amados que conhecidos; p. ex., Deus, que nesta vida pode ser
amado em si mesmo sem ser contudo em si mesmo conhecido. Logo, o conhecimento não é causa do
amor.

3. Demais. ― Se o conhecimento fosse causa do amor, este não existiria sem aquele. Ora, há amor em
todos os seres, como diz Dionísio, mas nem em todos conhecimento. Logo, este não é causa daquele.
Mas, em contrário, Agostinho afirma, que ninguém pode amar o desconhecido.

SOLUÇÃO. ― Como já dissemos, o bem é causa do amor, como objeto deste. Ora, o bem não é objeto
do apetite senão quando apreendido. Logo, o amor implica a apreensão do bem amado. Por onde, o
Filósofo diz que a vista corpórea é o princípio do amor sensitivo; e semelhantemente, a contemplação
da beleza ou da bondade é o do amor espiritual. Assim pois, o conhecimento é a causa do amor, e a
razão por que só o bem conhecido pode ser amado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Quem busca a ciência não a ignora absolutamente; mas
de certo modo já tem dela algum conhecimento, ou em geral, ou por algum de seus efeitos, ou por ouvir
que outros a enaltecem, como diz Agostinho. Por onde, possuí-la é conhecê-la, não imperfeita, mas
perfeitamente.

RESPOSTA À SEGUNDA. ― A perfeição do conhecimento não tem as mesmas exigências que a perfeição
do amor. Pois, residindo na razão, aquele compete distinguir racionalmente coisas realmente unidas, e
compor de certo modo coisas diversas, comparando umas com as outras. Por onde, a perfeição do
conhecimento exige que o homem conheça em particular tudo o que inclui uma realidade, como, as
partes, as virtudes, as propriedades. O amor porém reside na potência apetitiva, que visa a realidade
como em si mesma é, e portanto para a sua perfeição basta que seja amada uma realidade tal com for
apreendida. E o termos maior amor, que conhecimento, de uma determinada realidade, vem de que
podemos amar perfeitamente o que imperfeitamente conhecemos; e isso bem se manifesta em relação
às ciências, que podemos amar só pelo sumário conhecimento que delas temos, p. ex., sabendo que a
retórica é uma ciência pela qual podemos persuadir os homens, amamos nela essa qualidade. E o
mesmo se deve dizer em relação ao amor de Deus.

RESPOSTA À TERCEIRA. ― Mesmo o amor natural, existente em todos os seres é causado por um certo
conhecimento, não, certo, existente nos seres naturais mesmos, mas em quem os institui, como já se
disse.

## Art. 3 — Se a semelhança é causa do amor.
(III Sent., dist. XXVII, q. 1, a . 1, ad 3; De hebdom., lect. I; In Ioann., cap. XV, lect. IV; VIII Ethic., lect. I).
O terceiro discute-se assim. ― Parece que a semelhança não é a causa do amor.

1. ― Pois, os contrários não podem ter a mesma causa. Ora, a semelhança é causa do ódio, porquanto,
diz a Escritura (Pr 13, 10): Entre os soberbos sempre há contendas; e o Filósofo diz, que os oleiros rixam
uns com os outros. Logo, a semelhança não é causa do amor.

2. Demais. ― Agostinho diz: pode dar-se amemos em outrem o que não quereríamos ser; assim
podemos amar um histrião, sem que quiséssemos sê-lo. Ora, tal não se daria se a semelhança fosse
causa do amor, porque então amaríamos em outrem o que quereríamos ser. Logo, a semelhança não é
causa do amor.

3. Demais. ― Todos amamos as coisas de que temos necessidade e que não possuímos; assim, o doente
ama a saúde e o pobre, as riquezas. Ora, exatamente porque tais coisas nos faltam e delas carecemos,
delas somos dissemelhantes. Logo, não só a semelhança, mas também a dissemelhança é causa do
amor.

4. Demais. ― O Filósofo diz: amamos os que nos beneficiaram com dinheiro ou com a saúde; e
semelhantemente, todos tem dileção pelos que conservam a amizade para com os mortos. Ora, nem
todos os homens agem assim. Logo, a semelhança não é causa do amor.
Mas, em contrário, diz a Escritura (Ecle 13, 19): Todo animal ama ao seu semelhante.

SOLUÇÃO. ― A semelhança propriamente falando é causa do amor. Devemos ponderar porém, que a
semelhança entre várias coisas pode ser considerada sob dois pontos de vista. Ou dois seres têm a
mesma qualidade em ato, e por ex., dizem-se semelhantes se ambos são brancos; ou um tem
potencialmente e por uma certa inclinação o que o outro tem em ato, como se dissermos que o corpo
grave que está fora do seu lugar tem semelhança com outro, que está no seu; ou ainda, no sentido em
que a potência tem semelhança com o ato mesmo, pois este de certo modo está naquela.
Ora, o primeiro modo de semelhança causa o amor de amizade ou de benevolência. Pois, dois seres
semelhantes, quase tendo a mesma forma, são por estas unificados, de certo modo; assim dois homens
se unificam pela espécie humana e dois seres brancos, pela brancura; por onde, o afeto de um tende
para o outro como sendo unificado consigo e lhe quer o bem como a si mesmo. ― O segundo modo de
semelhança porém causa o amor de concupiscência ou amizade, útil ou deleitável; porque o que existe
em potência tem como tal o desejo do seu ato e se deleita na consecução dele, se for capaz de sentir e
de conhecer.
Mas como já dissemos, pelo amor de concupiscência amamo-nos propriamente a nós mesmos,
querendo o bem que desejamos. Pois amamo-nos mais a nós mesmo que aos outros, por temos
unidade substancial conosco mesmos, ao passo que com os outros temos apenas a semelhança de
forma. Por onde quem, sendo nosso semelhante pela participação da mesma forma, impede-nos a
consecução do bem que amamos, torna-se-nos odioso, não por ser semelhante, mas por nos tolher o
bem próprio. Por isso, porque tolhe um o lucro do outro, é que os oleiros rixam entre si. E entre os
soberbos sempre há contendas, porque um é obstáculo à excelência que o outro deseja.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. ― Por isso mesmo que amamos em outrem o que em nós não amaríamos, é
que há razão de semelhança proporcional. Pois, a mesma proporção existente entre uma pessoa e
aquilo que os outros nela amam, há entre ela o que em si mesma ama; assim há semelhança
proporcional quando um bom cantor ama um bom escritor, enquanto cada qual tem o que lhe convém
conforme à sua arte.

RESPOSTA À TERCEIRA. ― Quem ama o que lhe falta tem semelhança com o que ama, assim como o
potencial se assemelha ao atual, conforme já dissemos.

RESPOSTA À QUARTA. ― Pela mesma semelhança que há entre a potência e o ato, quem não é liberal
ama quem o é, por esperar deste último o que deseja. E o mesmo acontece com o que persevera na
amizade, em relação ao que não persevera. E de um e outro modo a amizade visa uma utilidade. ― Ou
se deve dizer que, embora nem todos os homens tenham as referidas virtudes, por hábito completo,
tem-nas contudo, por uma certa predisposição pela qual quem não tem virtude ama o virtuoso, como
lhe sendo conforme à razão.

## Art. 4 — Se as outras paixões podem ser causa do amor.
O quarto discute-se assim. ― Parece que outras paixões também podem ser causa do amor.

1. ― Pois, diz o Filósofo, que certos são amados por prazer. Ora, o prazer é uma paixão. Logo, outras
paixões também podem ser causa de amor.

2. Demais. ― O desejo é uma paixão. Ora, podemos amar a outrem por desejo de algo que deles
esperamos, como bem se vê em toda amizade fundada na utilidade. Logo, há outras paixões que podem
ser causa do amor.

3. Demais. ― Agostinho diz: Quem já não nutre esperanças de alcançar uma certa coisa, ou a ama
fracamente, ou absolutamente não a ama, embora reconheça quão bela seja. Logo, a esperança
também é causa do amor.
Mas, em contrário, todos os outros afetos da alma são causados pelo amor, como diz Agostinho.

SOLUÇÃO. ― Não há nenhuma paixão que não pressuponha o amor, porque todas as paixões da alma
implicam movimento ou repouso relativamente a algum objeto. Ora, todo movimento ou repouso
procede de alguma conaturalidade ou coaptação, consoantes à essência do amor. Por onde, é
impossível qualquer outra paixão da alma ser em universal causa de todo amor. Pode dar-se porém que
alguma paixão seja causa de um determinado amor, assim como um bem é causa de outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― É certo que o prazer é a causa do amor de quem por
prazer ama; mas esse prazer por sua vez é causado por outro amor precedente, pois ninguém se deleita
senão com o que é de certo modo amado.

RESPOSTA À SEGUNDA. ― O desejo de um objeto sempre lhe pressupõe o amor. Mas, esse desejo pode
ser causa de amarmos outro; assim, quem deseja o dinheiro ama por isso a pessoa de quem o recebeu.

RESPOSTA À TERCEIRA. ― A esperança causa ou aumenta o amor, por via do prazer, pois o provoca e
também em virtude do desejo, pois ela o fortifica, porquanto não desejamos intensamente o que não
esperamos. A própria esperança porém se reporta a algum bem amado.