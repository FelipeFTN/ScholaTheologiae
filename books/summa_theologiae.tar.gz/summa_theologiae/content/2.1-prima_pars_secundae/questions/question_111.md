# Questão 111: Da divisão da graça.
Em seguida devemos tratar da divisão da graça.
E nesta questão discutem-se cinco artigos:

## Art. 1 — Se a graça se divide convenientemente em graça santificante e gratuita.
[III Cont. Gent., cap. CLIV; Compende. Theol., cap. CCXIV ; Ad Rom., cap. I lect. III; Ad Ephes., cap. I, lect

II].
O primeiro discute-se assim. — Parece que a graça não se divide, convenientemente, em graça
santificante e gratuita.

1. — Pois, a graça é um dom de Deus, como já se disse (q. 110, a. 1). Porque, o homem não é agradável
a Deus, por lhe ter Deus feito algum dom; mas antes é ao contrário, por lhe ser o homem agradável é
que Deus lhe faz um dom gratuito. Logo, não há graça santificante.

2. Demais. — Tudo o que não é dado em virtude de méritos precedentes o é gratuitamente. Ora, pois
que a natureza é pressuposta ao mérito, o bem mesmo, que ela é, é dado ao homem sem mérito
precedente. Logo, também a natureza foi dada gratuitamente por Deus. Mas como ela se divide da
graça, por oposição, é inconveniente tomar-se como característica diferencial da graça o ser dada
gratuitamente; porque essa característica se encontra em outros gêneros que não o da graça. 3. Demais.
— Toda divisão se funda em características opostas. Ora, também a graça santificante, que nos justifica,
nos é concedida gratuitamente por Deus, conforme a Escritura (Rm 3, 24): Tendo sido justificados
gratuitamente por sua graça. Logo, a graça santificante não se deve dividir, por oposição, da graça
gratuita.
Mas, em contrário, o Apóstolo diz, que a graça tanto torna agradável, como é dada gratuitamente.
Assim, diz quanto à primeira característica (Ef 1, 6): Ele nos fez agradáveis a si em seu amado filho; e,
quanto à segunda (Rm 2, 6): E se isto for por graça, não foi já pelas obras; doutra sorte a graça já não
será graça.Portanto, pode-se distinguir a graça, que tem um só desses caracteres, da que tem os dois.

SOLUÇÃO. — Como diz o Apóstolo (Rm 13, 1), as potestades que há, essas foram por Deus
ordenadas. Ora, a ordem das coisas consiste em se ordenarem a Deus, umas pelas outras, como diz
Dionísio. E como a graça se ordena a dirigir o homem para Deus, isso se fará, ordenadamente, de modo
que uns se lhe ordenem por meio dos outros. Donde duas espécies de graça. Uma pela qual o homem se
une diretamente com Deus, chamadasantificante. Outra, pela qual, nesse ordenar-se para Deus, uns
colaboram com os outros; e esse dom é chamado graça gratuita, por sobrepujar a capacidade da
natureza humana e o mérito pessoal do homem. Não se chama porém graça santificante, por não ser
dada ao homem para se ele diretamente justificar, mas antes, para cooperar na justificação dos outros.
E a ela se refere o Apóstolo (1 Cor 12, 7): A cada um é dada a manifestação do Espírito para proveito, i.
é, dos outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que a graça torna agradável, não efetiva, mas
formalmente; i. é, porque, por ela, o homem se justifica e se torna digno de ser considerado agradável a
Deus, conforme a Escritura (Cl 1, 21): Fez-nos dignos de participar da sorte dos santos em luz.

RESPOSTA À SEGUNDA. — A graça, enquanto gratuita, exclui a idéia de débito, que pode ser entendido
em dupla acepção. Numa, provém do mérito, referente à pessoa a quem cabe praticar obras meritórias,
conforme a Escritura (Rm 4, 4): E ao que obra não se lhe conta o jornal por graça, mas por dívida. Outra
é o débito fundado na condição da natureza; assim quando dizemos ser devido ao homem ter razão e o
mais pertencente à natureza humana. Ora, em nenhuma dessas acepções, o débito se funda em
qualquer obrigação de Deus para com a criatura; mas antes, no dever desta, de submeter-se a Deus e
realizar a ordenação divina. Esta exige que tal natureza tenha tais condições ou propriedades, e que,
praticando tais atos, consiga tais resultados. Por onde, o débito, na primeira acepção, carece desses
dons naturais; mas deles não carece o débito na segunda acepção. Ao passo que, em ambas as
acepções, faltam-lhe os dons sobrenaturais. E por isso, a estes cabem, mais especialmente, o nome de
graça.

RESPOSTA À TERCEIRA. — A graça santificante acrescenta alguma coisa à noção de graça gratuita, o que
também pertence à essência da graça, que é tornar o homem agradável a Deus. Por onde, à graça
gratuita, que não o faz, se lhe dá o nome comum, como acontece em muitos outros casos. E assim,
opõem-se as duas partes da divisão — tornar e não tornar agradável.

## Art. 2 — Se a graça se divide convenientemente em operante e cooperante.
[II Sent., dist. XXVI, q. 1, a. 5; a. 6, ad 2; De Verit., q. 27, a. 5, ad 1, 2; II Cor., cap. VI, lect. I].
O segundo discute-se assim. — Parece que a graça não se divide convenientemente em operante e
cooperante.

1. — Pois, a graça é um acidente, como já se disse (q. 110, a. 2). Ora, um acidente não pode agir sobre o
seu sujeito. Logo, nenhuma graça pode se chamar operante.

2. Demais. — Se a graça obra alguma coisa em nós, há de sê-lo, por excelência, a justificação. Ora, esta
não é só a graça que a produz; pois, àquilo da Escritura (Jo 14, 12) — Esse fará também as obras que eu
faço —diz Agostinho: Quem te criou sem ti não te justificará sem ti: Logo, nenhuma graça pode chamar-
se operante, pura e simplesmente.

3. Demais. — Cooperar com alguém parece pertencer ao agente secundário, não ao principal. Mas a
graça opera em nós de modo mais decisivo que o livre arbítrio, conforme a Escritura (Rm 9, 16): Não
depende do que quer, nem do que corre, mas de Deus, que usa a misericórdia. Logo, a graça não pode
chamar de cooperante.

4. Demais. — As divisões devem fundar-se na oposição entre os seus membros. Ora, operar não se opõe
a cooperar, pois podem provir de um mesmo ser. Logo, inconvenientemente se divide a graça em
operante e cooperante.
Mas, em contrário, diz Agostinho: Deus, cooperando, perfaz em nós o que, operando, começou; porque
ele opera, no começo para que nós queiramos e, em seguida, completa o que fez, cooperando
conosco.Ora, as obras de Deus, com que nos move ao bem implicam a graça. Logo, esta se divide,
convenientemente, em operante e cooperante.

SOLUÇÃO. — Como já dissemos (q. 110, a. 2), a graça pode ser entendida em dupla acepção: como um
auxílio divino, que nos move a querer e agir retamente, e como um dom habitual, que Deus nos infunde.
Ora, em ambos os sentidos, ela se divide em operante e cooperante.
Pois, a operação de um efeito não se atribui ao móvel, mas ao motor. Por onde, a Deus é atribuída a
operação, que produz o efeito, pelo qual a nossa alma é movida e não, motora, pois que só Deus é
quem a move; e tal é a graça operante. Porém, não só a Deus, mas também à alma é atribuída a
operação causadora do efeito pelo qual a nossa alma é motora e movida; e tal é a graça cooperante. —
Ora, há em nós duplo ato. Primeiro, o interior da vontade; e em relação a este, a vontade se comporta
como movida e Deus, como motor; e sobretudo, quando a vontade, que, antes, queria o mal, começa a
querer o bem. Por onde, chama-se graça operante aquela com que Deus move a alma humana a querer
esse ato. Outro é o ato exterior, imperado pela vontade, como já dissemos (q. 17, a. 9); ora, neste ato,
há de a operação ser atribuída, conseqüentemente, à vontade. E como Deus também nos ajuda a
praticá-lo, confirmando interiormente a vontade, para o realizarmos e, exteriormente, dando-nos a
faculdade de agir, chama-se graça cooperante a que respeita esse ato. Por isso, depois das palavras
citadas, Agostinho acrescenta: Opera, afim de que nós queiramos: e quando queremos, coopera
conosco para que completemos a nossa obra. — Assim, pois, tomada a graça, como gratuita moção de
Deus, com a qual nos move ao bem meritório, ela se divide, convenientemente, em operante e
cooperante.
Se porém tomarmos a graça no sentido de dom habitual, então duplo é o seu efeito, como o é o de
qualquer outra forma; cujo primeiro efeito é o ser e, o segundo, a operação. Assim, a ação do calor é
tornar cálido e produzir a calefação exterior. Por isso, a graça habitual, quando sana ou justifica a alma,
ou a torna agradável a Deus, chama-se graça operante; quando é princípio da obra meritória,
procedente do livre arbítrio, chama-se cooperante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por ser uma certa qualidade acidental, a graça não age
sobre a alma efetiva, mas, formalmente; assim como se diz, que a brancura torna uma superfície branca.

RESPOSTA À SEGUNDA. — Deus não nos justifica sem nós, porque, pela moção do livre arbítrio, quando
somos justificados é que consentimos na justiça de Deus. Ora essa moção não é causa, mas efeito da
graça. Portanto, toda a operação depende desta.

RESPOSTA À TERCEIRA. — Diz-se que cooperamos com outrem, não só quando somos agente
secundário, que coopera com o principal, mas também quando ajudamos a consecução de um fim
proposto. Ora, pela graça operante, o homem é ajudado por Deus, para querer o bem. Por onde,
pressuposto já o fim, é conseqüente que a graça coopere conosco.

RESPOSTA À QUARTA. — A graça operante é a mesma que a cooperante; mas dela se distingue pela
diversidade dos seus efeitos, como do sobredito se colhe.

## Art. 3 — Se a graça se divide convenientemente em preveniente e subseqüente.
[II Sent., dist. XXVI, a. 5; a, art. 2; De Verit., q. 27, a. 5, ad 6; In Psalm. XXII; II Cor., cap. XI, lect. I].
O terceiro discute-se assim. — Parece que a graça se divide inconvenientemente, em preveniente e
subseqüente.

1. — Pois, a graça é efeito do amor divino. Ora, o amor divino nunca é subseqüente, mas sempre,
preveniente, conforme a Escritura (1 Jo 4, 10): Não em termos nós sido os que amamos a Deus, mas em
que ele foi o primeiro que nos amou a nós. Logo, a graça não deve se dividir em preveniente e
subseqüente.

2. Demais. — A graça santificante, sendo suficiente, é uma só num mesmo homem, segundo a Escritura
(2 Cor 12, 9): Basta-te a minha graça. Ora, o que é anterior não pode ser, simultaneamente, posterior.
Logo, a graça se divide, inconvenientemente, em preveniente e subseqüente.

3. Demais. — A graça é conhecida pelos seus efeitos. Ora, estes que precedem uns aos outros, são
infinitos. Por onde, se a graça devesse, de acordo com eles, ser dividida em preveniente e subseqüente,
resultariam infinitas as espécies dela. Ora, o infinito escapa a toda ciência. Logo, a graça não se divide,
convenientemente, em preveniente e subseqüente.
Mas, em contrário, a graça de Deus provém da sua misericórdia. Ora, na Escritura se encontram as duas
funções da misericórdia (Sl 58, 11): A misericórdia dele se antecipará; e (Sl 22, 6): A tua misericórdia irá
após de mim. Logo, a graça se divide, convenientemente, em preveniente e subseqüente.

SOLUÇÃO. — Assim como a graça se divide, quanto aos seus diversos efeitos, em operante e
cooperante, assim também, em preveniente e subseqüente, em qualquer acepção que seja tomada.
Ora, a graça produz em nós cinco efeitos. O primeiro é santificar a alma; o segundo, levá-la a querer o
bem, o terceiro, a realizar eficazmente o bem querido; o quarto, perseverar no bem; o quinto, chegar à
glória. Por onde, a graça, que produz em nós o primeiro efeito, chama-se preveniente, em relação ao
segundo; e enquanto produz o segundo, chama-se subseqüente, em relação ao primeiro. E assim como
um efeito qualquer da graça é posterior ao precedente e anterior ao seguinte, pode ela chamar-se
preveniente e subseqüente, relativamente a um mesmo efeito, a títulos diversos. E isto diz
Agostinho: Ele nos previne para curar-nos; acompanha-nos para, depois de curados, nos fortificarmos;
previne-nos para sermos chamados; acompanha-nos para alcançarmos a glória.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O amor de Deus significa algo de eterno, e portanto não
pode designar senão o que é preveniente. Ao contrário, a graça significa um efeito temporal, que pode
preceder a uma coisa e ser subseqüente a outra. Logo, pode chamar-se preveniente e subseqüente.

RESPOSTA À SEGUNDA. — A graça por ser preveniente e subseqüente, não essencialmente de espécies
diversas, mas só quanto aos seus efeitos, como já dissemos, a respeito da graça operante e cooperante.
Por onde, a graça subseqüente, por dizer respeito à glória, não difere numericamente da preveniente,
que atualmente nos justifica. Pois, assim como a caridade desta vida não é abolida, mas aperfeiçoada na
pátria, o mesmo deve dizer-se do lume da graça, porque nenhum dos seus dois aspectos implica
imperfeição essencial.

RESPOSTA À TERCEIRA. — Embora os efeitos da graça possam ser numericamente infinitos, como
infinitos são os atos humanos, contudo todos se reduzem a espécies determinadas. E além disso, todos
convêm em que um precede o outro.

## Art. 4 — Se o Apóstolo divide convenientemente a graça gratuita.
[III Cont. Gent., cap. CLIV; I Cor. XII, lect. II]
O quarto discute-se assim. — Parece que o Apóstolo divide inconvenientemente a graça gratuita.

1. — Pois, todo dom, que Deus nos dá gratuitamente, pode chamar-se graça gratuita. Ora, infinitos são
os dons, que Deus nos concede gratuitamente, referentes tanto aos bens da alma como aos do corpo; e
que contudo não nos tornam agradáveis a Ele. Logo, a graça gratuita não pode ser susceptível de
nenhuma divisão certa.

2. Demais. — A graça gratuita se divide, por oposição, da santificante. Ora, a fé pertence à graça
santificante, porque nos justifica, conforme a Escritura (Rm 5, 1): Justificados, pois, pela fé, etc. Logo, é
inconveniente considerar a fé como uma graça gratuita; sobretudo por não se considerarem tais as
outras virtudes, como a esperança e a caridade.

3. Demais. — Operar curas e falar várias línguas são milagres. Ora, a interpretação das línguas pertence
à sabedoria ou ciência, conforme a Escritura (Dn 1, 17): Deus deu a estes meninos a ciência e o
conhecimento de todos os livros e de toda a sabedoria. Logo, é inconveniente separar o dom de fazer
curas, e de falar várias línguas, do de praticar a virtude, como se fossem aqueles opostas a este. E
também o é separar, por oposição, o de interpretar as palavras, do de falar com sabedoria e ciência.

4. Demais. — Assim como a sabedoria e a ciência são dons do Espírito Santo, assim também a
inteligência e o conselho, a piedade, a fortaleza e o temor, como já se disse (q. 68, a. 4). Logo, estas
virtudes também devem se considerar como graças gratuitas.
Mas, em contrário, diz o Apóstolo (1 Cor 12, 8-10): A um pelo Espírito é dada a palavra de sabedoria; a
outro porém a palavra da ciência, segundo o mesmo Espírito; a outro a fé pelo mesmo Espírito; a outro a
graça de curar as doenças; a outro, a operação de milagres; a outro, a profecia; a outro, o discernimento
dos espíritos; a outro, a variedade de lugares; a outro, a interpretação das palavras.

SOLUÇÃO. — Como já dissemos (a. 1), a graça gratuita se ordena a nos levar a cooperarmos com
outrem, afim de conduzi-lo para Deus. Ora, isso não podemos fazer movendo-o interiormente, o que só
pertence a Deus, senão só ensinando ou persuadindo exteriormente. Por onde, a graça gratuita contém
em si o de que o homem precisa para instruir a outrem nas coisas divinas, superiores à razão. Ora, para
isso, três condições são necessárias: primeiro, um conhecimento completo das verdades divinas, para
podermos instruir os outros; segundo, confirmar ou provar o que dizemos, do contrário a nossa doutrina
não seria eficaz; terceiro, transmitir convenientemente aos nossos ouvintes os nossos pensamentos.
Ora, quanto à primeira condição, três qualidades são necessárias, como quando se trata do magistério
humano. — Assim, primeiro, é necessário que quem deve ensinar a outrem uma ciência, possua de
maneira certíssima os princípios dela. E para isso, serve a fé, que é a certeza das coisas invisíveis,
supostas como princípios da doutrina católica. — Segundo, é preciso, que quem ensina uma ciência, lhe
possua perfeitamente as conclusões principais. Donde o dom de falar com sabedoria, que é o
conhecimento das coisas divinas. — Em terceiro lugar, é necessário também tenha abundância de
exemplos e de conhecimento dos efeitos, pelos quais é mister às vezes, manifestar as causas. Donde, o
dom de falar com ciência, que é o conhecimento das coisas humanas; pois (Rm 1, 20), as coisas invisíveis
de Deus se vêm pelas obras que foram feitas.
Depois, para confirmar as verdades da razão, servimo-nos de argumentos; ao passo que as verdades
reveladas por Deus e superiores à razão confirmam-se por manifestações próprias do poder divino. E
isto de dois modos. — Primeiro, quando quem ensina a doutrina sagrada faz, sob a forma de milagres, o
que só Deus pode fazer. E esses milagres visam a saúde do corpo, donde a graça da cura; ou se ordenam
a só manifestação do poder divino, como quando o sol para ou escurece, ou o mar se divide; e para isso
é dada a graça de operar milagres. — Segundo, para poder manifestar os futuros contingentes, que só
Deus pode fazer; e para isto é dada a graça da profecia. E também os segredos dos corações,
pelo discernimento dos espíritos.
Enfim, a faculdade de falar pode significar o uso do idioma pelo qual quem ensina se faz entender, e daí
odom da variedade das línguas; ou o sentido das palavras proferidas, donde o dom da interpretação das
palavras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como já dissemos (a. 1), nem todos os benefícios que
Deus nos faz se consideram graças gratuitas; mas, só os excedentes à capacidade natural, como quando
um pescador abunda em palavras de sabedoria e de ciência, e em casos semelhantes. E esses casos se
compreendem na graça gratuita.

RESPOSTA À SEGUNDA. — Entre as graças gratuitas, enumera-se a fé, não como virtude justificante do
homem em si mesmo, mas enquanto implica uma certeza supereminente, que nos torna idôneos a
ministrar aos outros as suas verdades. Quanto à esperança e à caridade, pertencem à potência apetitiva,
na medida em que, por ela, o homem se ordena para Deus.

RESPOSTA À TERCEIRA. — A graça das curas distingue-se do poder geral de fazer milagres; pois tem
uma eficácia especial para conduzir à fé, à qual nos torna melhor dispostos pelo benefício da saúde do
corpo, adquirida pela virtude mesma da fé. — Semelhantemente, falar várias línguas e interpretar as
palavras têm certa eficácia especial para despertar à fé. E por isso se consideram como especiais graças
gratuitas.

RESPOSTA À QUARTA. — A sabedoria e a ciência não são enumeradas entre as graças gratuitas, quando
colocadas entre os dons do Espírito Santo. Isto é, enquanto o Espírito Santo torna a alma do homem tão
dócil, quanto necessário para seguir as inspirações da sabedoria ou da ciência. Pois, assim consideradas,
essas virtudes são dons do Espírito Santo. Mas, se enumeram entre as graças gratuitas, enquanto
implicam uma certa abundância de ciência e sabedoria, tornando o homem apto, não só a ter, por si
mesmo, um conhecimento reto das coisas divinas, mas também a instruir os outros e refutar os que as
contradizem. Por isso, entre as graças gratuitas, está assinaladamente colocada a palavra de sabedoria e
a de ciência. Pois, como diz Agostinho, uma coisa é saber somente o que o homem dever crer para
alcançar a vida eterna; outra, saber como, por esse meio, venha em auxílio das almas piedosas e os
defenda contra os ímpios.

## Art. 5 — Se a graça gratuita é mais digna que a santificante.
O quinto discute-se assim. — Parece que a graça gratuita é mais digna que a santificante.

1. — Pois, o bem da nação é superior ao do indivíduo, como diz o Filósofo. Ora, a graça santificante
ordena só para o bem do indivíduo, ao passo que a gratuita, para o de toda a comunidade da Igreja,
como já se disse. Logo, a graça gratuita é mais digna que a santificante.

2. Demais. — É maior virtude poder agir sobre outrem, que poder aperfeiçoar-se só a si mesmo; assim
como a claridade corpórea capaz de iluminar também os outros corpos é maior que aquela que luz sem
poder iluminá-los. Por isso, o Filósofo diz, que a justiça é a mais preclara das virtudes, pela qual o
homem age retamente, mesmo para com os outros. Ora, pela graça santificante o homem se aperfeiçoa
a si mesmo, ao passo que, pela gratuita, opera a perfeição dos outros. Logo, esta é mais perfeita que
aquela.

3. Demais. — O que é próprio dos melhores é mais digno que o comum a todos; assim, raciocinar,
próprio do homem, mais digno que sentir, comum a todos os animais. Ora, a graça santificante é
comum a todos os membros da Igreja; ao passo que a gratuita é dom próprio dos membros mais dignos
dela. Logo, a graça gratuita é mais digna que a santificante.
Mas, em contrário, o Apóstolo, depois de ter enumerado as graças gratuitas, acrescenta (1 Cor 12,
31): Mas eu ainda vou a mostrar-vos outro caminho mais excelente. Ora, como a seqüência do texto o
demonstra, ele se refere à caridade, que pertence à graça santificante. Logo, está é mais excelente que a
gratuita.

SOLUÇÃO. — Toda virtude é tanto mais excelente quanto mais elevado é o bem a que ela se ordena.
Pois, sempre o fim é mais excelente que os meios. Ora, a graça santificante ordena imediatamente o
homem à união com o fim último. Enquanto que a graça gratuita o ordena a certos meios preparatórios
do fim último. Assim, pela profecia, pelos milagres e por meios semelhantes, os homens são levados à
união com o fim último. Logo, a graça santificante é muito mais excelente que a gratuita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz o Filósofo, o bem de uma multidão, como, p.
ex., um exército, é duplo. Um está na multidão mesma, p. ex., a ordem do exército. Outro — o bem do
chefe, é dela distinto. E, este último é o superior, pois a ele se ordena o primeiro. Ora, a graça gratuita
se ordena ao bem comum da Igreja, que é a ordem eclesiástica. Ao passo que a graça santificante se
ordena a um bem comum separado, que é o próprio Deus. Logo, a graça santificante é mais nobre.

RESPOSTA À SEGUNDA. — Se a graça gratuita pudesse fazer o homem conseguir o que consegue pela
graça santificante, resultaria que ela é mais nobre que esta; assim como é mais excelente a claridade do
sol, que ilumina, do que a do corpo iluminado. Ora, pela graça gratuita não podemos causar em outrem
a união com Deus, que ele alcança pela graça santificante; mas podemos apenas provocar certas
disposições para essa união. Por onde não é necessário seja a graça gratuita mais excelente, do mesmo
modo que o calor, manifestativo da natureza específica do fogo, e pelo qual aquece as coisas, é mais
nobre que a forma substancial do mesmo.

RESPOSTA À TERCERIA. — Sentir se ordena a raciocinar, como ao fim; logo, raciocinar é mais nobre.
Ora, no caso vertente, dá-se o contrário, porque o próprio se ordena ao comum, como ao fim. Logo, não
há semelhança.