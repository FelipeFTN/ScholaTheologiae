# Questão 62: Das virtudes teologais.
Em seguida devemos tratar das virtudes teologais.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se há virtudes teologais.
O primeiro discute-se assim. — Parece que não há virtudes teologais.

1. — Pois, como já se disse, a virtude é uma disposição do que é perfeito para o que ótimo; e chama-se
perfeito ao que tem uma disposição natural. Ora, o divino é superior à natureza do homem. Logo, as
virtudes teologais não são virtudes humanas.

2. Demais. — As virtudes teologais assim se chamam por serem virtudes quase divinas. Ora, estas são
exemplares, como já se disse e não existem em nós. Logo, as virtudes teologais não são virtudes
humanas.

3. Demais. — Chamam-se virtudes teologais as pelas quais nos ordenamos a Deus, princípio primeiro e
fim último das coisas. Ora, o homem, pela natureza mesma da sua razão e da sua vontade, se ordena ao
princípio primeiro e ao fim último. Logo, não são necessários quaisquer hábitos das virtudes teologais,
pelos quais a razão e a vontade se ordenem para Deus.
Mas, em contrário, os preceitos da lei são relativos aos atos das virtudes. Ora, é a lei divina quem
preceitua sobre os atos da fé, da esperança e da caridade. Pois, diz a Escritura (Ecle 2, 8): Vós os que
temeis ao Senhor, crede-o; e: esperai nele; e: amai-o. Logo, a fé, a esperança e a caridade são virtudes
ordenadas para Deus. Logo, são teologais.

SOLUÇÃO. — A virtude aperfeiçoa o homem para os atos pelos quais se ordena para a felicidade, como
do sobredito resulta. Ora, a felicidade ou beatitude do homem é dupla, segundo já dissemos. Uma,
proporcionada à natureza, pode obtê-la pelos princípios desta. Outra lhe excede a natureza e só pode
alcançá-la pelo auxílio divino, por uma como participação da divindade, conforme o lugar da Escritura (2
Pd 1, 4) onde diz que, por Cristo, nos tornamos participantes da natureza divina. E como esta beatitude
excede as proporções da natureza humana, os princípios naturais, que dirigem o homem no agir
proporcionado ao seu ser, não bastam a ordená-lo à referida beatitude. Portanto, é necessário lhe
sejam acrescentados por Deus certos princípios pelos quais se ordene à beatitude sobrenatural, assim
como, pelos princípios naturais se ordena a um fim que lhe é conatural; mas, isso não vai sem o auxílio
divino. Ora, esses princípios se chamam virtudes teologais, quer por terem Deus como objeto, enquanto
nos ordenam retamente para ele; quer por nos serem infundidos só por Deus; quer por nos serem essas
virtudes conhecidas só pela divina revelação, na Sagrada Escritura.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Uma natureza pode ser atribuída a um ser de duplo
modo. Essencialmente, e nesse sentido as virtudes teologais excedem a natureza do homem. Ou
participativamente, como a madeira em ignição participa da natureza do fogo; e nesta acepção o
homem se torna, de certo modo, participante da natureza divina, como já dissemos. E assim as virtudes
teologais convêm ao homem segundo a natureza participada.

RESPOSTA À SEGUNDA. — As virtudes teologais não se chamam divinas, como significando que Deus
seja virtuoso por elas; mas, no sentido em que por meio delas, Deus nos torna virtuosos e nos ordena
para ele. Por onde não são exemplares, mas, exempladas.

RESPOSTA À TERCEIRA. — A razão e a vontade se ordenam naturalmente para Deus, como princípio que
é e fim da natureza; isto contudo proporcionadamente a esta. Mas, para Deus, como objeto da
beatitude sobrenatural, a razão e a vontade não se ordenam suficientemente, por natureza.

## Art. 2 — Se as virtudes teologais se distinguem das morais e intelectuais.
(III Sent., dist. XXIII, q. 1, a. 4, qª 3, ad 4; De Verit., q. 14, a. 3, ad 9 De Virtut., q. 1, a 12).
O segundo discute-se assim. — Parece que as virtudes teologais não se distinguem das morais e
intelectuais.

1. — Pois, dado que existam na alma humanas, as virtudes teologais hão de lhe aperfeiçoar a parte
intelectiva ou apetitiva. Ora, as virtudes que aperfeiçoam a parte intelectiva se chamam intelectuais; e
as que aperfeiçoam a parte apetitiva, morais. Logo, as virtudes teologais não se distinguem das
intelectuais e morais.

2. Demais. — Chamam-se virtudes teologais as que nos ordenam para Deus. Ora, dentre as virtudes
intelectuais há uma — que nos ordena para Deus, e é a sapiência que, considerando a causa altíssima,
versa sobre o divino. Logo, as virtudes teologais não se distinguem das intelectuais.

3. Demais. — Agostinho diz que as quatro virtudes cardeais manifestam a ordem do amor. Ora este é
caridade, considerada como uma virtude teologal. Logo, as virtudes morais não se distinguem das
teologais.
Mas, em contrário. — O superior à natureza humana distingue-se do que lhe é proporcionado. Ora, as
virtudes teologais são superiores à natureza do homem ao qual convêm naturalmente às virtudes
intelectuais e morais, como do sobredito se colhe. Logo, essas virtudes distinguem-se entre si.

SOLUÇÃO. — Como já dissemos, os hábitos se distinguem especificamente pela diferença formal dos
objetos. Ora, o objeto das virtudes teologais é Deus mesmo, fim último das coisas e enquanto excede o
conhecimento da nossa razão. Ao passo que o objeto das virtudes intelectuais e morais é algo que a
razão humana pode compreender. Por onde, as virtudes teologais se distinguem especificamente das
morais e intelectuais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As virtudes intelectuais e morais aperfeiçoam o intelecto
e o apetite do homem, como proporcionadas à natureza humana; as teológicas, porém, como
sobrenaturais.

RESPOSTA À SEGUNDA. — A sapiência que o Filósofo tem como virtude intelectual, considera as causas
divinas enquanto a razão humana pode investigá-las. Ora, as virtudes teologais versam sobre o que
excede a razão humana.

RESPOSTA À TERCEIRA. — Embora a caridade seja amor, contudo nem todo amor é caridade. Portanto,
quando se diz que toda virtude manifesta a ordem do amor, isso pode ser entendido ou do amor, na
acepção comum, ou do amor de caridade. No primeiro caso, qualquer virtude manifesta a ordem do
amor, porque qualquer das virtudes cardeais exige o afeto ordenado, e a raiz e o princípio de todo afeto
é o amor, como já dissemos. No segundo, não se deve por isso considerar qualquer outra virtude como
essencialmente caridade; mas como defendendo todas as outras, de certo modo, dela, como a seguir se
demonstrará.

## Art. 3 — Se se admitem convenientemente três virtudes teologais: a fé, a esperança e a caridade.
(IIª IIª, q. 17, a. 6; II Sent., Dist. XXIII, q. 1, a. 5; dist., XXVI, q. 2. a. 3, qª 1; De Virtut., q. 1, a 10, 12; I Cor.,
cap. XIII, lect II. IV).
O terceiro discute-se assim. — Parece inconveniente admitirem-se três virtudes teologais, a saber, a
fé, a esperança e a caridade.

1. — Pois, as virtudes teologias ordenam-se para a divina beatitude, assim como a inclinação da
natureza, para um fim conatural. Ora, entre as virtudes ordenadas a este fim, há só uma virtude natural,
que é o intelecto dos princípios. Logo há se também de admitir uma só virtude teologal.

2. Demais. — As virtudes teologais são mais perfeitas que as intelectuais e morais. Ora, a fé é menos
que uma virtude e não se compreende entre as virtudes intelectuais. Semelhantemente, a esperança
não se compreende entre as virtudes morais porque, sendo paixão, é menos que virtude.

3. Demais. — As virtudes teologais ordenam a alma do homem para Deus. Ora, a alma do homem não
pode se ordenar para Deus senão pela sua parte intelectiva, onde reside o intelecto e a vontade. Logo,
só devem existir duas virtudes teologais, uma que aperfeiçoa o intelecto e outra, à vontade.
Mas, em contrário, diz o Apóstolo (1 Cor 13, 13): Agora, pois, permanecem a fé, a esperança, a caridade,
estas três virtudes.

SOLUÇÃO. — Como já dissemos, as virtudes teologais ordenam o homem para a beatitude sobrenatural,
do mesmo modo que, pela inclinação natural, ele se ordena a um fim que lhe é conatural. Ora, isto se dá
por dupla via. Primeiro, pela razão ou intelecto, enquanto traz em si os primeiros princípios universais
conhecidos pela luz natural do intelecto, nos quais se apóia a razão, tanto na ordem especulativa como
na prática. Segundo, pela retidão da vontade naturalmente tendente para o bem da razão.
Ora, estas duas potências são incapazes de se ordenar à beatitude sobrenatural, conforme aquilo da
Escritura (1 Cor 2, 9): O olho não viu, nem o ouvido ouviu, nem jamais veio ao coração do homem o que
Deus tem preparado para aqueles que o amam. Logo, é necessário que a ambas essas potências algo se
lhes acrescente sobrenaturalmente para o homem se ordenar ao fim sobrenatural. — Assim,
primeiramente, ao intelecto se lhe acrescentam certos princípios sobrenaturais, apreendidos por
iluminação divina, e que são os princípios da crença, objeto da fé. — Em seguida, a vontade se ordena
para o fim sobrenatural, pelo movimento intencional, tendendo para ele, como o que é possível de
conseguir, o que pertence à esperança; e por uma como união espiritual, pela qual, de certo modo, se
transforma nesse fim, o que se realiza pela caridade. Pois, o apetite de cada ser move-se naturalmente e
tende para o seu fim conatural, e esse movimento procede de certa conformidade da coisa com o seu
fim.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O intelecto, para inteligir, precisa das espécies
inteligíveis; e por isso é preciso que se lhe acrescente um hábito natural. A natureza mesma da vontade
porém basta para que ela se ordene naturalmente para o fim, quer intencionalmente, quer quanto à
conformidade com ele. — Mas, em relação ao que lhe é superior à natureza, a potência, por si só, não
basta, para essa dupla ordenação, e por isso é necessário se lhe acrescente um hábito sobrenatural, que
diga respeito a ambas.

RESPOSTA À SEGUNDA. — A fé e a esperança implicam uma certa imperfeição, porque aquela recai
sobre o que não vemos, e esta, sobre o que não temos. Por onde, não constitui virtude, ter fé e
esperança no que está ao alcance das forças humanas. Mas, tê-las no que supera a faculdade da nossa
natureza excede toda virtude proporcionada ao homem, conforme aquilo da Escritura (1 Cor 1, 25): o
que parece em Deus uma estultícia é mais sábio que os homens.

RESPOSTA À TERCEIRA. — O apetite implica duas condições: o movimento para o fim e a conformidade
com ele pelo amor. E. assim é necessário admitir, no apetite humano, duas virtudes teologais, a saber, a
esperança e a caridade.

## Art. 4 — Se na ordem das virtudes teologais a fé é anterior à esperança e a esperança, à caridade.
(IIª-IIª, q. 4, a. 7; q. 17. a. 7, 8; III :Sent., disto XXIII, q.1. 2, a.5; dist. XXVI, q. 2, a. 3, qª 2 ; De Virtut., q. 4,
a. 3).
O quarto discute-se assim. — Parece que a ordem das virtudes teologias não deve ser a em que a fé é
anterior à esperança e a esperança, à caridade.

1. — Pois, a raiz é anterior ao que dela procede. Ora, a caridade é a raiz de todas as virtudes, conforme a
Escritura (Ef 3, 17): arraigados e fundados em caridade. Logo, a caridade é anterior às outras virtudes.

2. Demais. — Agostinho diz: Ninguém pode amar aquilo em cuja existência não crê. Mas, se crê e ama
também fará bem se esperar. Logo, parece que a fé precede a caridade e esta, a esperança.

3. Demais. — O amor é o princípio de todo afeto, como já se disse. Ora, a esperança, sendo uma paixão,
como já se disse, exprime um afeto. Logo, a caridade, que é amor, é anterior à esperança.
Mas, em contrário, é a ordem em que o Apóstolo enumera estas virtudes (1 Cor 13, 13): Agora pois
permanecem a fé, a esperança e a caridade.

SOLUÇÃO. — Há uma dupla ordem: a da geração e a da perfeição. Ora, naquela, em que a matéria é
anterior à forma, e o imperfeito, ao perfeito, num mesmo ser, a fé precede a esperança e esta, a
caridade, atualmente falando, porque quanto aos seus hábitos eles são infundidos simultaneamente. —
Pois, o movimento apetitivo não pode tender esperando ou amando, senão para o que é apreendido
pelo sentido ou pelo intelecto. Ora, pela fé, o intelecto apreende o que espera e ama. Logo,
necessariamente, na ordem da geração, a fé precede a esperança e a caridade. — Semelhantemente, se
o homem ama alguma coisa é porque a apreende como bem seu. Ora, aquilo de que o homem espera
poder receber um bem, ele o considera como seu bem. Logo, ama em quem espera, e portanto, na
ordem da geração e quanto ao ato, a esperança precede a caridade.
Mas na ordem da perfeição, a caridade precede a fé e a esperança, porque tanto esta como aquela se
formam e adquirem a perfeição de virtude, pela caridade. Por onde, a caridade é a mãe e a raiz de todas
as virtudes, enquanto forma de todos, como a seguir se dirá.
Donde consta clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Agostinho se refere à esperança pela qual confiamos, pelos méritos já
adquiridos, em que chegaremos à beatitude; e isto é próprio da esperança formada, consecutiva à
caridade. Mas também podemos esperar antes de termos a caridade; não, pelos méritos que já temos,
mas pelos que esperamos ter.

RESPOSTA À TERCEIRA. — Como já dissemos, quando tratamos das paixões, a esperança visa um objeto
principal, que é o bem esperado. E em relação a ele, o amor sempre precede a esperança; pois, nenhum
bem é esperado sem ser antes desejado e amado. — Em segundo lugar, a esperança também recai
sobre aquele por quem esperamos poder conseguir um bem. E neste caso a esperança, primeiramente,
precede o amor, embora depois, pelo próprio amor, a esperança aumente. Pois é porque julgamos
podermos conseguir um bem por meio de outrem, que começamos a amá-lo; e por isso mesmo que o
amamos nele mais fortemente esperamos.