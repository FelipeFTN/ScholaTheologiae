# Questão 80: Da causa do pecado por parte do diabo.
Em seguida devemos tratar da causa do pecado por parte do diabo. E sobre esta questão discutem-se
quatro artigos:

## Art. 1 — Se o diabo é causa direta de o homem pecar.
(Supra, q. 75, a. 3; De Malo, q. 3, a. 3).
O primeiro discute-se assim. — Parece que o diabo é causa direta de o homem pecar.

1. — Pois, o pecado consiste diretamente num afeto. Ora, Agostinho diz que o diabo inspira afetos
malignos aos de sua sociedade. E Beda: o diabo arrasta a alma para o afeto maligno. E Isidoro: o diabo
enche o coração dos homens de concupiscências ocultas. Logo, é causa direta do pecado.

2. Demais. — Jerônimo diz, que assim como Deus é o autor perfeito do bem, assim o é o demônio, do
mal. Ora, Deus é a causa direta dos nossos bens. Logo, o diabo é diretamente a causa dos nossos
pecados.

3. Demais. — O Filósofo diz, há um princípio extrínseco necessário do conselho humano. Ora, este tem
por objeto, não só o bem, mas ainda o mal. Logo, como Deus move para o conselho bom, e por aí é
diretamente a causa do bem; assim o diabo, para o conselho mau, sendo então causa direta do pecado.
Mas, em contrário, Agostinho prova que nenhuma outra causa leva o coração humano a fazer-se
escravo da sensualidade, senão a vontade própria. Ora, só o pecado torna o homem escravo da
sensualidade. Logo, a causa do pecado não pode ser o diabo, mas só a vontade própria.

SOLUÇÃO. — O pecado é um ato. Por isso a causa direta do pecado poderá sê-la também de sermos a
causa direta de um ato. E isto não se pode dar senão pelo princípio próprio desse ato que leva a agir.
Ora, o princípio próprio do ato pecaminoso é a vontade, pois todo pecado é voluntário. Logo, só pode
ser causa direta do pecado o que pode levar a vontade a agir.
Mas, como já se disse, a vontade é susceptível de dupla moção. Uma, provocada pelo objeto; assim,
dizemos que o objeto desejado e apreendido move o apetite. Outra, pelo interiormente inclinante a
vontade a querer, e isso só pode ser ou ela mesma ou Deus, como já demonstramos. Ora, Deus não
pode ser causa do pecado, como também já demonstramos. Resta, portanto, por este lado, só a
vontade do homem como causa direta do seu pecado.
No concernente ao objeto porém, podemos admitir mova ele a vontade de três modos. Primeiro, pela
proposição mesma do objeto; assim, dizemos que a comida excita o desejo do homem a comer.
Segundo, por meio do oferente ou proponente. Terceiro, persuadindo o proponente, que o objeto
realiza a idéia de bem; pois, esse, de certo modo, propõe à vontade o seu objeto próprio, que é o bem
racional, verdadeiro ou aparente. Por onde, do primeiro modo, as coisas sensíveis, manifestadas
exteriormente, movem a vontade do homem a pecar. Do segundo e do terceiro modos, o diabo, ou
mesmo qualquer pessoa pode incitar ao pecado, quer oferecendo algum objeto desejável ao sentido,
quer persuadindo a razão. Mas nenhum destes três modos pode constituir causa direta do pecado,
porque a vontade não se move necessariamente por nenhum objeto, salvo o fim último, como já se
disse. Logo, não é causa suficiente do pecado nem o objeto exteriormente oferecido, nem aquele que o
propõe, nem o que persuade. Donde se colhe que o diabo não é causa direta e suficiente do pecado,
mas só a modo de quem persuade ou propõe o objeto apetecido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todos os autores citados, e ainda outros que pensam
semelhantemente, referem-se ao diabo quando, sugerindo ou propondo certos objetos desejáveis,
desperta o afeto pelo pecado.

RESPOSTA À SEGUNDA. — A comparação aduzida se funda em que o diabo é de certo modo causa dos
nossos pecados, como Deus é, de certo outro, causa de nossos bens. Não se refere porém ao modo de
causar, porque Deus causa os bens, movendo interiormente a vontade, o que não pode fazer o diabo.

RESPOSTA À TERCEIRA. — Deus é o princípio universal de todo movimento humano interior. Mas, a
vontade humana se decide pelo mau conselho, ou diretamente e por si mesma, ou pelo diabo, quando
este persuade ou propõe um objeto desejável.

## Art. 2 — Se o diabo pode induzir ao pecado instigando interiormente.
(De Malo, q. 3. a. 4).
O segundo discute-se assim. — Parece que o diabo não pode induzir ao pecado, instigando
interiormente.

1. — Pois, os movimentos interiores da alma são atos vitais. Ora, todo ato vital procede de um princípio
intrínseco, mesmo o da alma vegetativa, o ínfimo desses atos. Logo, o diabo não pode, por moção
interna, instigar o homem ao mal.

2. Demais. — Todos os movimentos interiores nascem, na ordem da natureza, dos sentidos externos.
Ora, só Deus pode obrar fora dessa ordem, como já se estabeleceu na Primeira Parte. Logo, o diabo em
nada pode influir nos movimentos interiores do homem senão pelo que deles se manifesta nos sentidos
externos.

3. Demais. — Os atos internos da alma são inteligir e imaginar. Ora, o diabo não pode influir em nada
sobre esses dois atos. Pois, como já se demonstrou na Primeira Parte, ele não pode impressionar o
intelecto humano. Porque as formas imaginárias sendo mais espirituais, são de mais elevada dignidade
que as existentes na matéria sensível; e contudo o diabo não pode impressionar estas últimas, como
ficou provado na Primeira Parte. Logo, não pode, pelos atos interiores do homem, induzi-lo ao pecado.
Mas, em contrário, se assim fosse, nunca poderia tentar o homem, senão aparecendo-lhe visivelmente.
O que é claramente falso.

SOLUÇÃO. — A parte interior da alma é intelectiva e sensitiva. A primeira compreende a inteligência e a
vontade. Quanto a esta, já dissemos como se comporta o diabo em relação a ela. Por outro lado o
intelecto, por natureza, é movido pelo que o ilumina e o leva, assim, ao conhecimento da verdade.Ora,
em relação ao homem, não tem tal intenção o demônio, que quer, antes, entenebrecer-lhe a razão, para
que consinta no pecado. E esse entenebrecimento provém da fantasia e do apetite sensitivo. Por isso
toda a ação interior do diabo se dirige a mover a fantasia e o apetite sensitivo podendo assim induzir ao
pecado. Pois pode agir de modo a apresentar à imaginação certas formas imaginárias; e também tomar
o apetite sensitivo predisposto à paixão.
Pois, como já se disse, a natureza corpórea obedece naturalmente à espiritual, no concernente ao
movimento local. Por isso, o diabo pode causar tudo quanto pode provir do movimento local dos corpos
inferiores, se não for reprimido pelo poder divino. Ora, pelo movimento local podem certas formas ser
representadas à imaginação. Pois, como diz o Filósofo, quando dormimos, desce a maior parte do
sangue para o princípio sensitivo e, simultaneamente com ele, movimentos, — ou impressões
remanescentes da moção dos sensíveis, conservadas nas espécies sensíveis, — que movem o princípio
apreensivo. De modo que elas surgem como se então o princípio sensitivo fosse imutado pelas próprias
coisas exteriores. Daí o poder, esse movimento local dos espíritos ou dos humores ser provocado pelos
demônios quer durmamos, quer estejamos acordados, donde lhe resultam certas imaginações.
Semelhantemente, o apetite sensitivo fica predisposto a certas paixões por um determinado movimento
do coração e dos espíritos; e para isso também o diabo pode cooperar. E sendo provocadas certas
paixões do apetite sensitivo, percebemos mais acentuadamente o movimento ou intenção sensível,
reduzido, do modo sobredito, ao princípio apreensivo. Pois, como o Filósofo diz no mesmo livro, os
amantes são levados, por qualquer fraca imagem, à apreensão da coisa amada. E também sucede que,
provocada a paixão, julguemos dever buscar o objeto proposto à imaginação. Porque quem é presa da
paixão parece-lhe bem aquilo a que ela o inclina. E deste modo o diabo induz interiormente ao pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora as operações vitais sempre procedam de um
princípio intrínseco, um agente externo pode vir-lhes em ajuda. Assim como o calor externo contribui
para as operações da alma vegetal, tornando mais fácil a digestão de alimento.

RESPOSTA À SEGUNDA. — A referida aparição das formas imagináveis não é absolutamente, contra a
ordem da natureza; nem resulta só do império da nossa vontade, mas do movimento local, como já se
disse.
Donde é patente a RESPOSTA À TERCEIRA OBJEÇÃO. — Porque as formas em questão primordialmente,
as recebem os sentidos.

## Art. 3 — Se o diabo pode nos necessitar a pecar.
(De Malo, q. 3 a. 3, ad 9).
O terceiro discute-se assim. — Parece que o diabo pode nos necessitar a pecar.

1. — Pois, o poder maior pode impor necessidade ao menor. Ora, a Escritura diz, do diabo (Jó 41): Não
há poder sobre a terra que a se lhe possa comparar. Logo, pode necessitar o homem terreno a pecar.

2. Demais. — A nossa razão não pode mover-se senão pelos objetos externos propostos aos sentidos e
representados à imaginação. Pois, todo o nosso conhecimento tem a sua origem nos sentidos e não
podemos inteligir sem o fantasma, como diz Aristóteles. Ora, o diabo pode mover-nos a imaginação,
como já se disse, e também os sentidos externos. Pois, no dizer de Agostinho, o mal, suscitado pelo
diabo serpeia por todos os acessos sensíveis, corporifica-se em figuras, acomoda-se as cores, adere aos
sons, infunde-se nos sabores. Logo, pode inclinar-nos necessariamente a razão a pecar.

3. Demais. — Segundo Agostinho, nenhum pecado há no desejo da carne contra o espírito. Ora, o diabo
pode causar a concupiscência da carne, bem como as demais paixões, do modo por que já foi dito. Logo,
pode induzir, como necessidade, a pecar.
Mas, em contrário, diz a Escritura (1 Pd): O diabo, vosso adversário, anda ao derredor de vós, como um
leão que ruge, buscando a quem possa tragar. Ora, seria inútil essa advertência, se sucumbíssemos
necessariamente à tentação diabólica. Logo, o diabo não pode necessitar o homem ao pecado.

SOLUÇÃO. — O diabo, por virtude própria e se não for refreado por Deus, pode nos induzir
necessariamente a praticar atos genericamente pecaminosos; mas não pode nos impor a necessidade
de pecar. E isso se prova por não podermos resistir ao motivo de pecar senão pela razão. E do uso desta
podemos ficar totalmente privados pela moção imaginativa e do apetite sensitivo, como se dá com os
processos. Mas, então, desde que estamos privados da razão, não se nos imputa por pecado nenhum
ato que pratiquemos. Se porém, não ficarmos totalmente privados da razão, pela parte dela que
conservamos livre podemos resistir ao pecado, como já dissemos. Por onde é manifesto, que o diabo de
nenhum modo pode impor ao homem a necessidade de pecar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nem todo poder superior ao homem pode mover-lhe a
vontade mas, só o de Deus, como já demonstramos.

RESPOSTA À SEGUNDA. — O objeto apreendido pelo sentido ou pela imaginação não move
necessariamente a vontade, se conservamos o uso da razão, de que nem sempre nos priva a referida
apreensão.

RESPOSTA À TERCEIRA. — A concupiscência da carne, contrária ao espírito, não é pecado, quando a
razão lhe atualmente resiste; mas ao contrário, é ocasião de exercitarmos a virtude. Ora, não está no
poder do diabo privar a razão do seu poder de resistir. Logo, não pode impor a necessidade do pecado.

## Art. 4 — Se todos os pecados vêm da sugestão do diabo.
(I, q. 114, a. 3; De Malo, q. 3, a. 5).
O quarto discute-se assim. — Parece que todos os pecados dos homens provém da sugestão do diabo.

1. — Pois, como diz Dionísio, a multidão dos demônios é-lhes, para si e para os outros, a causa de todos
os males.

2. Demais. — Quem peca mortalmente faz-se escravo do diabo, conforme aquilo da Escritura (Jo
8): todo o que comete pecado é escravo do pecado. Mas, todo o que é vencido é também escravo
daquele que o venceu. Logo, quem cometer o pecado é vencido pelo diabo.

3. Demais. — Gregório diz, que o pecado do diabo é irreparável, por ter caído sem sugestão de ninguém.
Portanto, seria irremediável o pecado de quem pecasse por livre arbítrio, sem sugestão alheia, o que é
patentemente falso. Logo, todos os pecados humanos são sugeridos pelo diabo.
Mas, em contrário: Nem todos os nossos maus pensamentos são provocados pelo diabo, mas às vezes
surgem provocado pelo nosso arbítrio.

SOLUÇÃO. — Por certo, ocasional e indiretamente, o diabo é causa de todos os nossos pecados. Pois,
induziu o primeiro homem a pecar; e esse pecado viciou a tal ponto a natureza humana, que todos
somos inclinados a pecar. Do mesmo modo poderíamos considerar como causa da combustão da
madeira quem a tivesse secado, fazendo com que se ela facilmente queimasse. Diretamente porém, não
é causa de todos os pecados humanos, no sentido de nos persuadir a cada um deles. E isso o prova
Orígenes, por haverem de ter os homens, mesmo que o diabo não existisse, o apetite da comida, do ato
venéreo e semelhantes. E esse desejo poderia ser desordenado, se não se sujeitasse à razão; o que
depende do livre arbítrio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A multidão dos demônios é causa de todos os nossos
males, relativamente à origem primeira, como se disse.

RESPOSTA À SEGUNDA. — Torna-se escravo de outrem, não somente quem foi por esse dominado, mas
ainda quem voluntariamente se lhe submeteu. E deste modo torna-se escravo do diabo quem peca de
propósito deliberado.

RESPOSTA À TERCEIRA. — O pecado do diabo foi irremediável, por ter pecado sem sugestão de
ninguém; nem sentir qualquer inclinação a pecar causada por alguma sugestão precedente. Ora, tal se
não pode dizer do pecado de nenhum homem.