# Questão 58: Da distinção entre as virtudes morais e as intelectuais.
Em seguida devemos tratar das virtudes morais. E primeiro, da distinção entre elas e as virtudes
intelectuais. Segundo, da distinção delas entre si, conforme a matéria própria. Terceiro, da distinção
entre as principais ou cardeais e as outras.
Sobre a primeira questão cinco artigos se discutem:

## Art. 1 — Se toda virtude é moral.
(III Sent., dist. XXIII, q. 1, a. 4, qª 2; I Ethic., lect. XX; II. Lect I).
O primeiro discute-se assim. — Parece que toda virtude é moral.

1. — A virtude moral tira a sua denominação da palavra mos, moris, que significa costume. Ora,
podemos nos acostumar aos atos de todas as virtudes. Logo, toda virtude é moral.

2. Demais. — O Filósofo diz, que a virtude moral é um hábito eletivo consistente no meio termo
racional. Ora, toda virtude é hábito eletivo, porque podemos praticar, por eleição, os atos de qualquer
delas. E demais disso toda virtude consiste, de certo modo, num meio termo racional, como mais
adiante claramente demonstraremos. Logo, toda virtude é moral.

3. Demais. — Túlio diz na sua Retórica, que a virtude é um hábito, ao modo da natureza, consentâneo
com a razão. Ora, toda virtude humana, ordenando-se ao bem do homem, há de necessariamente ser
consentânea com a razão, pois tal bem consiste em estar de acordo com a razão, com diz Dionísio. Logo,
toda virtude é moral.
Mas, em contrário, o Filósofo diz: Tratando dos costumes, não dizemos que alguém é sábio ou
inteligente, mas, humilde ou sóbrio. Por onde, a sabedoria e o intelecto não são morais, embora sejam
virtudes, como já se disse. Logo, nem toda virtude é moral.

SOLUÇÃO. — Para resolver com evidência a questão vertente devemos considerar o que é o costume;
assim poderemos saber o que é a virtude moral. Ora, a palavra costume tem duas significações. Umas
vezes quer dizer modo ou rito, como no passo da Escritura (At 15, 1): Pois se vos não circuncidais
segundo o rito de Moisés, não podeis ser salvos. Outros, exprime uma certa inclinação natural, ou quase
natural, para fazer alguma coisa; e neste sentido atribuímos certos costumes aos brutos, como o faz a
Escritura (2 Mc 11, 11):lançando-se eles com grande ímpeto sobre seus inimigos, segundo o costume
dos leões, mataram-nos. E ainda o mesmo sentido aparece em outro passo, que diz (Sl 67, 7): (Deus) que
faz morar os de uns costumes sem casa. E ambos estes sentidos não se distinguem, entre os latinos,
verbalmente. Distinguem-se porém em grego; pois, ethos, que em latim significa costume (mos), às
vezes tem a primeira longa e escrita com a letra grega η; outras, a tem breve e escrita com ε.
Ora, a virtude moral tira a sua denominação da palavra latina, mos, moris, com o sentido de inclinação
natural ou quase natural a fazer alguma coisa. E desta se aproxima a outra significação, com o sentido
de costume (consuetudo); pois este, de certa maneira, converte-se em natureza e torna a inclinação
semelhante ao natural. Ora, é manifesto que a inclinação para o ato convém propriamente à virtude
apetitiva, à qual é próprio mover todas as potências para o ato como do sobredito se colhe. E portanto
nem toda virtude é considerada moral, mas só a pertencente à potência apetitiva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procede se referente aos modos (mos) com o
sentido de costume.

RESPOSTA À SEGUNDA. — Todos os atos virtuosos podem ser praticados por eleição; mas só a virtude
residente na parte apetitiva da alma é a que procede por eleição reta, pois, conforme já dissemos,
eleger é ato da virtude apetitiva. Por onde, hábito eletivo, que é o princípio da eleição, é só aquele que
aperfeiçoa a virtude apetitiva, embora os atos dos outros hábitos também possam entrar na esfera da
eleição.

RESPOSTA À TERCEIRA. — A natureza é o princípio do movimento, como diz Aristóteles. Ora, mover à
ação é próprio da parte apetitiva. E portanto, assimilar-se à natureza, por ser consentâneo com a razão,
é próprio das virtudes da potência apetitiva.

## Art. 2 — Se a virtude moral se distingue da intelectual.
(III Sent., dist. XXIII, q. 1, a. 4, qª 2; De Virtut., q. 1, a. 12; Ethic., lect. XX).
O segundo discute-se assim. — Parece que a virtude moral não se distingue da intelectual.

1. — Pois, como diz Agostinho, a virtude é a arte de viver retamente. Ora, a arte é uma virtude
intelectual. Logo, a virtude moral não difere da intelectual.

2. Demais. — Muitos incluem a ciência na definição das virtudes morais, e assim definem a perseverança
comoa ciência ou hábito daquilo em que devemos ou não nos deter; e a santidade, a ciência que nos
torna fiéis e observantes do que é justo para com Deus (Dos afetos, obra atribuída a Andrónico). Ora, a
ciência é uma virtude intelectual. Logo, a virtude moral se não deve distinguir da intelectual.

3. Demais. — Agostinho diz, que a virtude é a razão reta e perfeita. Ora, isto pertence à virtude
intelectual, como já se disse claramente. Logo, a virtude moral não é distinta da intelectual.

4. Demais. — Nada se distingue do que entra na sua definição. Ora, a virtude intelectual entra na
definição da virtude moral; pois, com diz o Filósofo, a virtude moral é um hábito eletivo, consistente
num meio termo racional, como o sapiente o determinaria. Ora, a razão reta que determina o meio
termo da virtude moral pertence à virtude intelectual, como se mostrou. Logo, a virtude moral não se
distingue da intelectual.
Mas, em contrário, está o seguinte, as virtudes se determinam pela diferença que torna umas,
intelectuais, outras, morais.

SOLUÇÃO. — O princípio primeiro de todas as obras humanas é a razão; e quaisquer outros princípios,
que existam, dessas obras, obedecem-lhe, de certo modo, mas de maneiras diversas. Assim, certos lhe
obedecem ao nuto, absolutamente, sem qualquer contradição, com p. ex., os membros do corpo, se
tiverem a sua consistência natural; pois, sob o império da razão, as mãos ou os pés são levados a agir. E
por isso o Filósofo diz que a alma rege o corpo com um governo despótico, i. é, como o senhor, o
escravo, que não tem direito de se lhe opor. Donde vem o terem certos ensinado que todos os
princípios ativos existentes no homem se comportam desse modo para com a razão. Ora, se isto fosse
verdade, bastaria fosse a razão perfeita para que nós agíssemos bem; e desde que a virtude é um hábito
que nos aperfeiçoa para bem agir, ela forçosamente só existiria na razão, e portanto toda virtude seria
intelectual. Esta foi à opinião de Sócrates, que consideravatodas as virtudes como formas da prudência,
conforme já se disse; e portanto, ensinava que o homem que tem ciência não pode pecar e todos os que
pecam por ignorância o fazem.
Mas esta opinião procede de uma suposição falsa. Pois, a parte apetitiva obedece à razão, não porém,
absolutamente, ao seu nuto, mas com o poder de se lhe opor. Por onde, diz o Filósofo, que a razão rege
a potência apetitiva com um governo político, como aquele com que governamos os filhos, que tem às
vezes direito de oposição. E por isso Agostinho diz, que às vezes a inteligência precede, sem o afeto lhe
obedecer, ou apenas tardamente, porque às vezes as paixões ou os hábitos da parte apetitiva podem,
num caso particular, travar o uso da razão. E neste caso é de algum modo verdadeiro o dito de Sócrates,
que ninguém peca com a ciência presente, contanto que esse dito se estenda ao uso da razão, numa
eleição particular.
Assim pois, para agirmos retamente é necessário, não só a razão estar bem disposta pelo hábito da
virtude intelectual, mas também a potência apetitiva o estar pelo hábito da virtude moral. Portanto,
assim como o apetite se distingue da razão, a virtude moral se distingue da intelectual. Logo, assim
como o apetite é princípio dos atos humanos enquanto participa, de certo modo, da razão, assim o
hábito moral realiza a noção de virtude humana na medida em que se conforma com a razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho comumente toma a arte no sentido de
qualquer razão reta. E assim na arte inclui também a prudência, que é a razão reta dos nossos atos,
assim como a arte é a razão reta das coisas factíveis. E desde então, o seu dito, que a virtude é a arte de
viver bem, convém essencialmente à prudência, e, participativamente, às outras virtudes, enquanto
dirigidas pela prudência.

RESPOSTA À SEGUNDA. — As definições aduzidas, sejam de quem forem, procedem da opinião
socrática; e devem ser entendidas do modo pelo qual tratamos da arte.
E semelhante é a RESPOSTA À TERCEIRA OBJEÇÃO.

RESPOSTA À QUARTA. — A razão reta, segundo a prudência inclui-se na definição da virtude moral, não
como parte essencial desta, mas como algo de participado por todas as virtudes morais, enquanto a
prudência as dirige a todas.

## Art. 3 — Se a virtude humana se divide suficientemente em moral e intelectual.
O terceiro discute-se assim. — Parece que a virtude humana não se divide suficientemente em moral
e intelectual.

1. — Pois, a prudência é considerada meio entre a virtude moral e a intelectual, por ser enumerada
entre as virtudes intelectuais; por outro lado, todos comumente a colocam entre as virtudes cardeais,
que são morais, como a seguir se verá. Logo, a virtude não se divide suficiente e imediatamente em
intelectual e moral.

2. Demais. — A continência, a perseverança e mesmo a potência não se incluem nas virtudes
intelectuais. E nem são morais, por não constituírem um meio termo de paixões que, antes, nelas
abundam. Logo, a virtude não se divide suficientemente em intelectuais e morais.

3. Demais. — A fé, a esperança e a caridade são virtudes. Mas não intelectuais, que são só as cinco
seguintes: a ciência, a sabedoria, o intelecto, a prudência e a arte, como já se disse. E também não são
virtudes morais, por não dizerem respeito às paixões, a que se referem principalmente as virtudes
morais. Logo, as virtudes não se dividem suficientemente em intelectuais e morais.
Mas, em contrário, diz o Filósofo: há duas espécies de virtudes; uma intelectual e outra moral.

SOLUÇÃO. — A virtude humana é um hábito que aperfeiçoa o homem para obrar retamente. Ora, os
atos humanos têm só dois princípios: o intelecto, ou razão, e o apetite; estes são os dois princípios
motores no homem, como já se disse. Por onde, toda virtude humana há de forçosamente ser perfectiva
de um desses dois princípios. Se o for do intelecto especulativo ou prático, a virtude será intelectual; e
moral, se da parte apetitiva. Donde se conclui, que toda virtude humana ou é intelectual ou moral.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A prudência é essencialmente uma virtude intelectual;
mas, pela sua matéria, convém com as virtudes morais, pois é a razão reta das nossas ações, como já
dissemos; e portanto, se enumera entre as virtudes morais.

RESPOSTA À SEGUNDA. — A continência e a perseverança não são perfeições da virtude apetitiva
sensitiva. E isto bem o demonstra o continente e o perseverante, em quem superabundam as paixões
desordenadas; e isso não se daria se o apetite sensitivo fosse aperfeiçoado por algum hábito, que o
pusesse de conformidade com a razão. Pois, a continência ou perseverança é a perfeição da parte
racional que se contrapõe às paixões, para esta não ser levada de vencida. É deficiente, porém da noção
de virtude, porque a virtude intelectiva, que faz a razão comportar-se retamente em relação à atividade
moral, pressupõe o apetite reto do fim, para poder haver-se com acerto em relação aos princípios, i. é,
os fins, nos quais se baseia para raciocinar; ora, isto falta ao continente e ao perseverante. Por outro
lado, também não pode ser perfeita a obra procedente das duas potências, se cada uma delas não for
aperfeiçoada pelo devido hábito; assim como não pode resultar uma ação perfeita do agente principal,
que se serve de um instrumento, por mais perfeito que ele seja, se o instrumento estiver mal disposto.
Por onde, se o apetite sensitivo, movido pela parte racional, não for perfeito, por mais que esta última o
seja, a ação conseqüente não poderá ser perfeita. E portanto, nem será virtude o princípio da ação; e
por isso, a continência dos prazeres e a perseverança nos sofrimentos não são virtudes, mas algo menos
que a virtude, como diz o Filósofo.

RESPOSTA À TERCEIRA. — A fé, a esperança e a caridade são superiores às virtudes humanas; pois, são
virtudes do homem enquanto participante da graça divina.

## Art. 4 — Se a virtude moral pode existir sem a intelectual.
(Infra, q. 65, a. 1; De Virtut., q. 5, a. 2; Quodl. XII, q. 15, a. 1; VI Ethic., lect. X, XI).
O quarto discute-se assim. — Parece que a virtude moral pode existir sem a intelectual.

1. — Pois, a virtude moral, como diz Túlio, é um hábito a modo de natureza, consentâneo com a razão.
Ora, não é necessário a razão da natureza existir em todos os seres, só porque a natureza é consentânea
com uma razão movente superior, como bem o deixam ver os seres naturais privados de razão. Logo,
pode haver em nós uma virtude moral, a modo de natureza, que nos incline a nos submeter à razão,
embora esta não seja perfeita pela virtude intelectual.

2. Demais. — Pela virtude intelectual conseguimos o uso perfeito da razão. Ora, dá-se às vezes que
certos, em que não impera o uso da razão, são virtuosos e amados de Deus. Logo, a virtude moral pode
existir sem a intelectual.

3. Demais. — A virtude moral nos inclina a agir retamente. Ora, muitos têm tal inclinação, mesmo sem o
juízo da razão. Logo, as virtudes morais podem existir sem as intelectuais.
Mas, em contrário, diz Gregório, que as outras virtudes não podem de nenhum modo ser tais, sem que
pratiquem prudentemente o que desejam. Ora, a prudência é uma virtude intelectual, como já se disse.
Logo, as virtudes morais não podem existir sem as intelectuais.

SOLUÇÃO. — Não há dúvida que as virtudes morais podem existir sem certas virtudes intelectuais, como
a sabedoria, a ciência e a arte; não o podem porém sem o intelecto e a prudência. — Assim, não podem
existir sem a prudência, por ser a virtude moral um hábito eletivo, i. é, que torna boa a eleição. Ora,
para esta ser boa se exigem duas condições. A primeira é haver a devida intenção do fim; e isto se dá
pela virtude moral, que inclina a potência apetitiva ao bem conveniente com a razão, que é o fim
devido. A segunda é que nos sirvamos retamente dos meios, o que se não pode dar senão pela razão,
que aconselha retamente, no julgar e no ordenar, o que pertence à prudência e às virtudes anexas,
como já dissemos. Por onde, a virtude moral não pode existir sem a prudência. — E por conseqüência,
sem o intelecto. Pois, por este é que conhecemos os princípios evidentes, tanto na ordem especulativa
como na operativa. Por onde, assim como a razão reta, na ordem especulativa, enquanto procede de
princípios naturalmente conhecidos, pressupõe o intelecto dos princípios, assim também a prudência,
que é a razão reta dos atos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A inclinação da natureza, nos seres privados de razão,
não inclui a eleição, e portanto essa inclinação não é necessariamente racional. Ao passo que a
inclinação da virtude moral é eletiva e, portanto, necessita, para ser perfeita, que a razão o seja, por
meio da virtude intelectual.

RESPOSTA À SEGUNDA. — Não é necessário, no homem virtuoso, o uso da razão imperar em universal,
mas só em relação ao que ele deve praticar virtuosamente. E assim o uso da razão impera em todas as
pessoas virtuosas. Por onde, mesmo aqueles que parecem simples, por destituídos da astúcia mundana,
podem ser prudentes, conforme aquilo da Escritura (Mt 10, 16): Sede prudentes como as serpentes, e
simples como as pombas.

RESPOSTA À TERCEIRA. — A inclinação natural para o bem da virtude é um certo começo desta, embora
não seja virtude perfeita. Pois, quanto mais perfeita essa inclinação, tanto mais perigosa pode ser, se
não se lhe acrescentar a razão reta, pela qual se faz a reta eleição dos meios convenientes ao fim
devido; assim como um cavalo cego, que corre, tanto mais dará encontrões e se ferirá, quanto mais
impetuosamente correr. E portanto, embora a virtude moral não seja a razão reta, como dizia Sócrates,
também não é somente segundo a razão reta, no sentido em que inclina para o que é conforme a essa
razão, como ensinavam os Platônicos; mas também é necessário seja acompanhada da razão reta,
segundo Aristóteles dizia.

## Art. 5 — Se a virtude intelectual pode existir sem a moral.
(Infra, q. 65, a. 1; De Virtut., q. 5, a. 2; Quodl. XII, q. 15, a. 1; VI Ethic., lect X).
O quinto discute-se assim. — Parece que a virtude intelectual pode existir sem a moral.

1. — Pois, a perfeição do que vem antes não depende da do que vem depois. Ora, a razão é anterior ao
apetite sensitivo e o move. Logo, a virtude intelectual, que é a perfeição da razão, não depende da
moral, que é a perfeição da parte apetitiva. Logo, pode existir sem ela.

2. Demais. — Os atos morais são matéria da prudência, assim como o que podemos produzir constitui a
matéria da arte. Ora, esta pode existir sem a matéria própria, como o ferreiro pode existir sem o ferro.
Logo, também a prudência o pode sem as virtudes morais, que contudo, entre todas as virtudes
intelectuais, é a mais unida com as morais.

3. Demais. — A prudência é uma virtude que nos faz aconselhar retamente, como já se disse. Ora,
muitos aconselham retamente, que entretanto são desprovidos das virtudes morais. Logo, a prudência
pode existir sem estas.
Mas, em contrário. — Querer fazer o mal opõe-se diretamente à virtude moral, mas não, a alguma
virtude capaz de existir sem ela. Ora, pecar voluntariamente opõe-se à prudência, como se disse. Logo, a
prudência não pode existir sem a virtude moral.

SOLUÇÃO. — Todas as virtudes intelectuais, menos a prudência, podem existir sem as virtudes morais. E
a razão é que a prudência é a razão reta dos nossos atos, e não só universalmente, mas também na
ordem particular a que pertencem os atos. Ora, a razão reta supõe princípios donde parta. Logo, em
relação ao particular, é necessário a razão proceder de princípios, não só universais, mas também
particulares. Ora, em relação aos princípios universais reguladores dos seus atos o homem se comporta
retamente pelo intelecto natural dos princípios, pelo qual sabe que não deve praticar nenhum mal; ou
ainda por alguma ciência prática. Isto porém, não basta para raciocinar sobre casos particulares. Pois
acontece às vezes, que o princípio universal, de que agora tratamos, conhecido pelo intelecto ou pela
ciência, oblitera-se num caso particular, por influência de alguma paixão. Assim, ao vencido pela
concupiscência parece-lhe bem o que deseja, embora vá contra o juízo universal da razão. E portanto,
assim como nos dispomos, para proceder retamente, em relação aos princípios universais, pelo
intelecto natural ou pelo hábito da ciência; assim também, para procedermos retamente, em relação
aos princípios particulares reguladores dos nossos atos, que são os fins, é necessário sejamos
aperfeiçoados por certos hábitos, que, de certo modo, nos tornam conatural o julgamento reto do fim. E
isto se dá pela virtude moral. Pois, o virtuoso julga retamente do fim da virtude, porque, tal como
somos, tal se nos afigura o fim, como já se disse. Logo, a razão reta dos nossos atos, que é a prudência
exige tenhamos a virtude moral.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A razão, enquanto apreensiva do fim, precede o apetite
deste. Mas o apetite do fim, por sua vez, precede a razão que raciocina para escolher os meios, o que
pertence à prudência, assim como, na ordem especulativa, o intelecto dos princípios é o princípio da
razão raciocinante.

RESPOSTA À TERCEIRA. — Os princípios das coisas artificiais não os julgamos nós bem ou mal, por uma
disposição do nosso apetite, como julgamos dos fins, que são os princípios na ordem moral; mas os
julgamos só pela consideração racional. E por isso, a arte não exige, como a prudência, a virtude, que
aperfeiçoa o apetite.

RESPOSTA À TERCEIRA. — A prudência não só aconselha mas também julga e ordena com acerto. O que
não poderia ser sem a remoção dos impedimentos das paixões, corruptoras do juízo e da ordenação da
prudência; e essa remoção se dá pela virtude moral.