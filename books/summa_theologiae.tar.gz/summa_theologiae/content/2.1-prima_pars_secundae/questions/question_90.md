# Questão 90: Da essência da lei.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se a lei é algo de racional.
O primeiro discute-se assim. — Parece que a lei nada tem de racional.

1. — Pois, diz o Apóstolo (Rm 7, 23): Sinto nos meus membros outra lei, etc. Ora, o racional não está nos
membros, porque a razão não se serve de órgãos corpóreos. Logo, a lei nada tem de racional.

2. Demais. — A razão só inclui a potência, o hábito e o ato. Ora, a lei não é nenhuma potência da razão.
E nem um hábito qualquer dela, porque os seus hábitos são as virtudes intelectuais, de que já se tratou
(a. 57). Nem um ato, pois, se o fosse, cessando ele, como se dá com os adormecidos, cessaria a lei. Logo,
a lei nada tem de racional.

3. Demais. — A lei move os que se lhe submetem, a agir retamente. Ora, mover à ação pertence
propriamente à vontade, como resulta claro do que já foi dito (q. 9, a. 1). Logo, a lei não depende da
razão, mas, antes, da vontade, conforme ao que também diz o Jurisperito: O que apraz ao príncipe tem
força de lei.
Mas, em contrário, à lei pertence ordenar e proibir. Ora, ordenar é ato da razão, como já se demonstrou
(q. 17, a. 1). Logo, a lei é algo de racional.

SOLUÇÃO. — A lei é uma regra e medida dos atos, pela qual somos levados à ação ou dela impedidos.
Pois, lei vem de ligar, porque obriga a agir. Ora, a regra e a medida dos atos humanos é a razão, pois é
deles o princípio primeiro, como do sobredito resulta (q. 1, a. 1 ad 3). Porque é próprio da razão ordenar
para o fim, princípio primeiro do agir, segundo o Filósofo. Ora, o que, em cada gênero, constitui o
princípio é a medida e a regra desse gênero. Tal a unidade, no gênero dos números, e o primeiro
movimento, no dos movimentos. Donde se conclui que a lei é algo de pertencente à razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Sendo a lei regra e medida, pode, de dois modos, ser
aplicada. De um, como o que mede e regula. Ora, como isto é próprio da razão, deste modo, a lei só na
razão existe. — De outro, como o que é regulado e medido. E, então existe em tudo o que em virtude
dela tem alguma inclinação. De sorte que qualquer inclinação proveniente de uma lei pode ser
considerada lei, não essencial, mas, participativamente. E deste modo, também a inclinação dos
membros para a concupiscência se chama lei dos membros.

RESPOSTA À SEGUNDA. — Podemos considerar, nos atos exteriores, a obra e o obrado, como, p. ex., a
edificação e o edifício. Assim também podemos distinguir, nas obras da razão, o ato mesmo dela, que é
inteligir e raciocinar; e algo de constituído por esse ato. E isto, no concernente à razão especulativa, é,
primeiramente, a definição; depois, o enunciado; e, em terceiro lugar, o silogismo ou argumentação.
Ora, mesmo a razão prática emprega no agir um certo silogismo, conforme já demonstramos (q. 13, a. 3;
q. 76, a. 1), de acordo com o que ensina o Filósofo. Por onde, deve haver, na razão prática, o que esteja
para as obras, como, na razão especulativa, está a proposição para as conclusões. Ora, tais proposições
universais da razão prática, ordenadas para o ato, têm natureza de lei. E elas são, umas vezes,
consideradas atualmente, e, outras possuídas habitualmente pela razão.

RESPOSTA À TERCEIRA. — A razão tira o seu poder motor da vontade, como já se disse (q. 17, a. 1). Pois,
é por querermos o fim que a razão ordena os meios. Mas para a vontade do que é ordenado vir a
constituir lei é preciso seja regulada pela razão. E deste modo compreende-se que a vontade do príncipe
tenha força de lei; do contrário seria antes iniqüidade que lei.

## Art. 2 — Se a lei se ordena sempre para o bem comum, como para o fim.
(Inira, q. 95, a. 4; q. 96, a. 1; III Sent., dist. XXXVII, a. 2, qª 2, ad 5 V Ethic., lect. II).
O segundo discute-se assim. — Parece que a lei não se ordena sempre para o bem comum, como para
o fim.

1. — Pois, é próprio da lei ordenar e proibir. Ora, a ordem visa um certo bem particular. Logo, o fim da
lei nem sempre é o bem comum.

2. Demais. — A lei dirige o homem para agir. Ora, os atos humanos versam sobre o particular. Logo,
também a lei se ordena a um bem particular.

3. Demais. — Isidoro diz: Se a lei participa da razão, será lei tudo o que desta participar. Ora, da razão
participa o que é ordenado não só para o bem comum, mas também para o privado. Logo, a lei não se
ordena só para o bem comum, mas também para o particular de cada um.
Mas, em contrário, Isidoro diz, que a lei é prescrita não para utilidade particular, mas para a utilidade
comum dos cidadãos.

SOLUÇÃO. — Como já dissemos (a. 1), sendo a lei regra e medida, ela depende do que é o princípio dos
atos humanos. Ora, como a razão é o princípio desses atos, também nela há algum primeiro princípio,
que o é de tudo o mais. Por onde e necessàriamente a este há de a lei pertencer, principal e
maximamente. Ora, o primeiro princípio, na ordem das operações, à qual pertence a razão prática, é o
fim último. E sendo o fim último da vida humana a felicidade ou beatitude, como já dissemos (q. 2, a. 7;
q. 3, a. 1), há de por força a lei dizer respeito, em máximo grau, à ordem da beatitude. — Demais, a
parte ordenando-se para o todo, como o imperfeito para o perfeito; e sendo cada homem parte da
comunidade perfeita, necessária e propriamente, há de a lei dizer respeito à ordem para a felicidade
comum. E, por isso, o Filósofo, depois de dar a definição do legal, faz menção da felicidade e da
comunhão política. Assim, diz: consideramos como justo legal o que faz e conserva a felicidade, com
tudo o que ela compreende, em dependência da comunidade civil. Ora, a comunidade perfeita é a
cidade, como diz Aristóteles.
Porém, em qualquer gênero, o que é principal é princípio de tudo o mais que a esse gênero pertence, e
que é considerado em dependência dele. Assim, o fogo, quente por excelência, é a causa do calor dos
corpos mistos, considerados quentes na medida em que participam do fogo. Por onde e
necessariamente a lei sendo por excelência relativa ao bem comum, nenhuma outra ordem, relativa a
uma obra particular, terá natureza de lei, senão enquanto se ordena ao bem comum. Logo, a este bem
se ordena toda lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Uma ordem supõe a aplicação da lei ao que é por ela
regulado. Ora, o ordenar-se para o bem comum, que é próprio da lei, é aplicável a fins particulares. E a
esta luz, também se podem dar ordens relativas a certos fins particulares.

RESPOSTA À SEGUNDA. — Certamente, as obras dizem respeito ao particular. Mas este pode ser
referido ao bem comum, não pela comunidade genérica ou específica, mas pela da causa final,
enquanto que o bem comum é considerado como fim comum.

RESPOSTA À TERCEIRA. — Assim como na ordem da razão especulativa nada tem firmeza senão pela
resolução aos primeiros princípios indemonstráveis, assim também nada a tem, na ordem da razão
prática, senão pela ordenação ao fim último, que é o bem comum. Ora, o que deste modo participa da
razão tem a natureza da lei.

## Art. 3 — Se a razão particular pode legislar.
(Infra, q. 97, a. 3, ad 2; IIª-IIªª, q. 50, a. 1, ad 3).
O terceiro discute-se assim. — Parece que qualquer razão particular pode legislar.

1. — Pois, diz o Apóstolo (Rm 2, 14): Quando os gentios, que não tem lei, fazem naturalmente as coisas
que são da lei, esses tais a si mesmos servem de lei. Ora, isto é dito em geral de todos. Logo, quem quer
que seja pode impor a si mesmo a sua lei.

2. Demais. — Como diz o Filósofo, a intenção do legislador é levar os homens à virtude. Ora, qualquer
um pode fazê-lo. Logo, a razão de qualquer homem pode legislar.

3. Demais. — Assim como o chefe da cidade é o seu governador, assim qualquer pai de família é o
governador da casa. Ora, o chefe da cidade pode legislar para ela. Logo, também qualquer pai de família
pode legislar para a sua casa.
Mas, em contrário, diz Isidoro, e está nas Decretais: A lei é a constituição do povo pela qual os patrícios,
simultaneamente com a plebe, estabeleceram alguma disposição. Logo, qualquer um não pode legislar.

SOLUÇÃO. — A lei, própria, primária e principalmente, diz respeito à ordem para o bem comum. Ora,
ordenar para o bem comum é próprio de todo o povo ou de quem governa em lugar dele. E portanto,
legislar pertence a todo o povo ou a uma pessoa pública, que o rege. Pois, sempre, ordenar para um fim
pertence a quem esse fim é próprio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como já dissemos (a. 1 ad 1), a lei está num sujeito, não
só como em quem regula, mas também, participativamente, como em quem é regulado. E deste modo
cada qual é para si mesmo a sua lei, enquanto participa da ordem de quem regula. Por isso o Apóstolo
acrescenta: Os que mostram a obra da lei escrita nos seus corações.

RESPOSTA À SEGUNDA. — Um particular não pode levar eficazmente à virtude. Pode apenas advertir;
mas, se a sua advertência não for aceita, não dispõe da força coativa, que a lei deve ter para levar
eficazmente à virtude, como diz o Filósofo. Ao passo que o povo, ou a pessoa pública, a quem compete
infligir as penas, tem essa força coativa, como a seguir se dirá (q. 92, a. 2 ad 3; IIa IIae q. 64, a.
3). E portanto, só ele pode legislar.

RESPOSTA À TERCEIRA. — Como o homem faz parte da casa, assim, esta, da cidade, que é uma
comunidade perfeita, segundo Aristóteles. Por onde, assim como o bem de um homem não é o fim
último, mas se ordena ao bem comum; assim, o bem de uma casa se ordena ao de toda a cidade, que é
uma comunidade perfeita. Portanto, quem governa uma família pode sem dúvida estabelecer certas
ordens ou estatutos, mas que propriamente não constituem leis.

## Art. 4 — Se a promulgação é da essência da lei.
(De Verit., q. 17, a. 3: Quodl. I, q. 9, a. 2).
O quarto discute-se assim. — Parece que a promulgação não é da essência da lei.

1. — Pois, a lei natural é a lei por excelência. Ora, ela não precisa de promulgação. Logo, o ser
promulgada não é da essência da lei.

2. Demais. — Pertence propriamente à lei obrigar a fazer ou não fazer alguma coisa. Ora, são obrigados
a cumprir a lei não só aqueles que lhe sabem da promulgação, mas também os outros. Logo, não é a
promulgação da essência da lei.

3. Demais. — A obrigação da lei também liga para o futuro, pois, as leis impõem necessidades aos
negócios futuros, como diz o direito. Ora, a promulgação é feita para os negócios presentes. Logo, não é
da essência da lei.
Mas, em contrário, dizem as Decretais: As leis são instituídas quando promulgadas.

SOLUÇÃO. — Como já dissemos (a. 1), a lei é imposta aos que lhe estão sujeitos, como regra e medida.
Ora, a regra e a medida impõe-se aplicando-se aos regulados e medidos. Por onde, para a lei ter força de
obrigar — o que lhe é próprio — é necessário seja aplicada aos homens, que por ela devem ser
regulados. Ora, essa aplicação se faz por chegar a lei ao conhecimento deles, pela promulgação. Logo, a
promulgação é necessária para a lei vir a ter força.
E assim, desses quatro elementos referidos podemos deduzir a definição da lei, que não é mais do que
uma ordenação da razão para o bem comum, promulgada pelo chefe da comunidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A promulgação da lei da natureza se dá por tê-la Deus
infundido na mente humana, de modo a ser naturalmente conhecida.

RESPOSTA À SEGUNDA. — Aqueles que não têm conhecimento da promulgação da lei são obrigados a
observá-la, enquanto sabem ou podem saber, por meio de outrem, da promulgação dela.

RESPOSTA À TERCEIRA. — A promulgação presente se aplica ao futuro pela persistência da escritura,
que, de certo modo, está sempre promulgando a lei. E por isso Isidoro diz: A lei é assim chamada do
verbo ler, está escrita.