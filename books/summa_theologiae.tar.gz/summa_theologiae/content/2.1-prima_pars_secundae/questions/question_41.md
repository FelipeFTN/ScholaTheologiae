# Questão 41: Do temor em si mesmo.
Em seguida devemos tratar, primeiro do temor; e segundo, da audácia.
Sobre o temor há quatro questões a tratar. Primeiro, do temor em si mesmo. Segundo, do seu objeto.
Terceiro, da sua causa, Quarto, do seu efeito.
Sobre a primeira questão discutem-se quatro artigos:

## Art. 1 — Se o temor é paixão da alma.
O primeiro discute-se assim. — Parece que o temor não é paixão da alma.

1. — Pois, como diz Damasceno, o temor é uma virtude que supõe a sístole, i. é, a contração, e é
desiderativa da essência. Ora, nenhuma virtude é paixão, conforme Aristóteles o prova. Logo, o temor
não é paixão.

2. Demais — Toda paixão é efeito de uma presença proveniente do agente. Ora, o temor não se refere a
nada de presente, mas sim, ao futuro, como diz Damasceno. Logo, o temor não é paixão.

3. Demais — Toda paixão da alma é um movimento do apetite sensitivo, consecutivo à apreensão do
sentido. Ora, o sentido não apreende o futuro, mas, sim, o presente. E o temor, referindo-se a um mal
futuro, não pode ser paixão da alma.
Mas, em contrário, Agostinho enumera o temor entre as outras paixões da alma.

SOLUÇÃO. — Entre os outros movimentos da alma, o temor é, depois da tristeza, o que principalmente
implica a noção de paixão. Pois, como já dissemos, ao conceito de paixão pertence: — primeiro, ser um
movimento da virtude passiva, para o qual o seu objeto está como um motor ativo, pois, a paixão é um
efeito do agente. E deste modo também consideramos paixões o sentir e o inteligir. — Segundo e mais
propriamente, chama-se paixão o movimento da virtude apetitiva. — E, ainda mais propriamente, o
movimento da virtude apetitiva servida por um órgão corpóreo, acompanhado de certa transmutação
corpórea. — E enfim, propríssimamente, chamam-se paixões os movimentos que acarretam alguma
nocividade.
Ora, é manifesto que o temor, sendo relativo ao mal, pertence à potência apetitiva que, em si mesma,
respeita o bem e o mal. Pertence ao apetite sensitivo, por ser acompanhado de certa transmutação, que
é a contração, como diz Damasceno. E implica além disso relação com o mal, enquanto este pode de
algum modo, levar-nos de vencida. Por onde, mui verdadeiramente lhe cabe a natureza de paixão; vem
contudo depois da tristeza, relativa ao mal presente, porque o temor é relativo ao mal futuro, que não
move como o presente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Virtude designa um certo princípio de ação; por isto, na
medida em que os movimentos interiores da potência apetitiva são princípios de atos exteriores,
chamam-se virtudes. O Filósofo porém nega seja a paixão uma virtude, pois, a virtude é um hábito.

RESPOSTA À SEGUNDA. — Assim como a paixão do corpo natural provém da presença corpórea do
agente, assim a da alma, da presença animal do agente, sem presença corporal ou real; e isso se dá
quando o mal, realmente futuro, se torna presente pela apreensão da alma.

RESPOSTA À TERCEIRA. — O sentido não apreende o futuro; mas, apreendendo o presente, o animal é
movido, por um instinto natural, a esperar um bem futuro ou a temer um futuro mal.

## Art. 2 — Se o temor é uma paixão especial.
O segundo discute-se assim. — Parece que o temor não é uma paixão especial.

1. — Pois, diz Agostinho: a quem o medo não desanima, nem a cobiça perturba, nem a agrura, i. é, a
tristezamacera, nem a agita a alvoroçada e vã alegria. Por onde se vê que, removido o temor, removidas
ficam todas as demais paixões. Logo, não é uma paixão especial, mas, geral.

2. Demais — O Filósofo diz, que a busca e a aversão desempenham, no apetite, o mesmo papel que, no
intelecto, a afirmação e a negação. Ora, a negação e a afirmação não são atividades especiais do
intelecto, mas podem se referir a muitas coisas. Logo, o mesmo se dá com a aversão, no apetite. Ora, o
temor não é senão um afastamento do mal. Logo, não é uma paixão especial.

3. Demais — Se o temor fosse uma paixão especial, teria a sua sede principalmente no irascível. Ora, ele
também existe no concupiscível. Pois, como diz o Filósofo, o temor é uma tristeza; e Damasceno afirma,
que o temor é uma virtude desiderativa. Ora, a tristeza e o desejo existem no concupiscível, como já
dissemos. Logo, não é uma paixão especial, desde que pertence a diversas potências.
Mas, em contrário, o temor entra na divisão geral das paixões, como se vê em Damasceno.

SOLUÇÃO. — As paixões da alma se especificam pelos seus objetos. E portanto, paixão especial é a que
tem um objeto especial. Ora, tanto o temor como a esperança estão nestas condições. Pois, assim como
o objeto desta é o bem futuro árduo e possível de ser alcançado, assim, o daquele é o mal futuro difícil a
que não podemos resistir. Logo, o temor é uma paixão especial da alma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todas as paixões da alma são derivadas de um mesmo
princípio, que é o amor, no qual têm conexão mútua. E é em virtude desta conexão, e não por ser o
temor uma paixão geral, que removido ele, removidas ficam todas as outras paixões.

RESPOSTA À SEGUNDA. — Nem toda aversão do apetite é temor, mas, a de um objeto especial, como já
dissemos. E portanto, embora a aversão seja algo de geral, contudo o temor é uma paixão especial.

RESPOSTA À TERCEIRA. — O temor de nenhum modo existe no concupiscível, pois não diz respeito ao
mal absolutamente considerado, mas ao que é acompanhado de uma certa dificuldade ou arduidade, de
modo que quase se lhe não possa resistir. Mas como as paixões do irascível derivam das do
concupiscível e nelas terminam, como já dissemos, ao temor se atribui o que é próprio ao concupiscível.
Assim, chamamos ao temor tristeza porque o seu objeto, quando presente, contrista; e por isso, o
Filósofo diz, no mesmo passo, que o temor procede da imaginação do mal futuro corruptor ou que
contrista. Semelhantemente, Damasceno atribui o desejo ao temor porque, assim como a esperança é
causada ou nasce do desejo do bem, assim, o temor é a fuga do mal, pois, tal fuga nasce do desejo do
bem, como do sobredito claramente resulta.

## Art. 3 — Se há algum temor natural.
O terceiro discute-se assim. — Parece que há um temor natural.

1. — Pois, diz Damasceno: a alma tem o temor natural de ser, contra a sua vontade, separada do corpo.

2. Demais — O temor nasce do amor, como já se disse. Ora, há um amor natural, segundo Dionísio.
Logo, há também um temor natural.

3. Demais — O temor se opõe à esperança, como já se disse. Ora, há uma esperança da natureza, como
se vê claramente na Escritura (Rm 4, 18), onde se diz que Abraão, contra a esperança da natureza
acreditou naesperança da graça. Logo, há também um temor da natureza.
Mas, em contrário. — O que é natural encontra-se comumente nos seres animados e nos inanimados.
Ora, nestes não há temor. Logo, o temor não é natural.

SOLUÇÃO. — Chama-se natural o movimento para o qual a natureza inclina; o que de dois modos pode
dar-se. — De um modo porque o todo se aperfeiçoa pela natureza, sem nenhuma operação da potência
apreensiva; assim, mover-se para cima é o movimento natural ao fogo como crescer o é aos animais e às
plantas. — De outro modo, natural é o movimento para o qual a natureza inclina, embora se complete
só pela apreensão; pois, como já dissemos, o movimento das potências cognitiva e apetitiva reduzem-se
à natureza como ao primeiro princípio. E deste modo também os atos mesmos da potência apreensiva,
como o inteligir, o sentir e o lembrar-se se chamam naturais, bem como o movimento do apetite animal.
E deste modo podemos dizer que o temor é natural, e distingue-se do não-natural, pela diversidade do
objeto. Pois, o temor, segundo o Filósofo, é relativo ao mal que corrompe e do qual a natureza foge, por
causa do seu desejo natural de existir; donde vem o dizermos que esse temor é natural. E além disso, o
temor é relativo ao mal que contrista, que não repugna à natureza, mas ao desejo do apetite; e tal
temor não é natural. Pois, como já dissemos, a distinção entre o amor de concupiscência e o prazer se
fundam no que é natural e no que não o é.
Porém, segundo a primeira acepção da palavra natural é mister saber-se que certas paixões da alma,
como o amor, o desejo e a esperança, se chamam às vezes naturais; outras porém não podem se
chamar assim. E isto porque o amor e o ódio, o desejo e a aversão implicam uma certa inclinação para
buscar o bem e fugir do mal, inclinação essa que também pertence ao apetite natural. Por onde, há um
certo amor natural; e podemos dizer que o desejo ou a esperança existe de certo modo também nos
seres naturais privados de conhecimento. As outras paixões da alma, porém, implicam certos
movimentos para os quais não basta, de nenhum modo, a inclinação natural. Ou porque essas paixões
implicam o sentido ou conhecimento; e, assim, como já dissemos, a apreensão sendo necessária para
haver prazer e dor, não podemos dizer que os seres privados de conhecimento se deleitam ou sofram
dor. Ou porque tais movimentos são contrários à essência da inclinação natural; assim é que a
desesperança foge do bem, por causa de alguma dificuldade; e o temor, seguindo nisso a inclinação
natural evita atacar o mal contrário, o natural. Por onde, tais paixões não se atribuem de nenhum modo
aos inanimados.
E daqui se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 4 — Se Damasceno assinala convenientemente seis espécies de termo: a indolência, o pejo, a vergonha, a admiração, o estupor e a agonia.
O quarto discute-se assim. — Parece que Damasceno assinala inconvenientemente seis espécies de
temor, a saber: a indolência, o pejo, a vergonha, a admiração, o estupor e a agonia.

1. — Pois, como diz o Filósofo, o temor é relativo ao mal que contrista. Logo, as espécies do temor
devem corresponder às da tristeza. Ora, há quatro espécies de tristezas. Logo, deve haver só quatro
espécies de temor, que lhes correspondam.

2. Demais — O que consiste num ato nosso depende do nosso poder. Ora, o temor é relativo ao mal que
sobrepuja o nosso poder, como já dissemos. Logo, a indolência, o pejo e a vergonha, que respeitam a
nossa operação, não devem ser considerados espécies do temor.

3. Demais — O temor é relativo ao futuro, como já se disse. Ora, a vergonha é relativa a um ato torpe
cometido, como diz Gregório Nisseno (Nemésio). Logo, a vergonha não é uma espécie de temor.

4. Demais — Só há temor do mal. Ora, a admiração e o estupor são relativos ao que é grande e insólito,
seja bem, seja mal. Logo, a admiração e o estupor não são espécie do temor.

5. Demais — Pela admiração os Filósofos são levados a inquirir a verdade, como diz Aristóteles. Ora, o
temor não leva a inquirir, mas antes a fugir. Logo, não é a admiração uma espécie de temor.
Mas, em contrário, basta a autoridade de Damasceno e de Gregório Nisseno (Nemésio).

SOLUÇÃO. — Como já dissemos, o temor é provocado pelo mal futuro, que nos sobrepuja o poder, de
modo que lhe não podemos resistir. Ora, como o bem, também o mal do homem pode ser considerado
quanto à sua operação ou quanto às coisas externas.
Quanto à sua operação o homem pode temer um duplo mal. — O primeiro é o trabalho, que causa
gravame à natureza; e, daí a indolência, consistente em evitar a atividade por temor do trabalho
sobreexcedente. — O segundo é a torpeza, que provoca a má opinião dos outros. E assim se
chama pejo à torpeza temida na comissão do ato, e vergonha quando se trata do ato torpe já cometido.
Por outro lado, o mal consistente nas coisas exteriores pode exceder, de três modos, a faculdade de
resistência do homem. — Primeiro, em razão da sua grandeza, como quando nos achamos em face de
um mal tão grande que não lhe podemos calcular as conseqüências. E nisto consiste a admiração. —
Segundo, em razão do seu caráter insólito, i. é, quando um mal insólito se nos oferece à consideração e,
por isso mesmo, nos parece grande. E nisso consiste o estupor, causado por uma imaginação insólita. —
Terceiro, em razão da improvisação, i. é, quando o mal não pôde ser previsto; assim tememos os
infortúnios futuros. E tal temor se chama agonia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As espécies de tristeza supra enumeradas não são
relativas à diversidade de objeto, mas, aos efeitos e a certas razões especiais. Por onde, não é
necessário que tais espécies correspondam às espécies do temor ora em questão, que são consideradas
relativamente à divisão própria do objeto do temor.

RESPOSTA À SEGUNDA. — A ação já realizada depende do poder de quem a praticou. Mas podemos
considerar algo de relativo à ação que, sobrepujando a faculdade de quem age, leva-o a desistir da ação.
E neste sentido a indolência, o pejo e a vergonha se consideram espécies do temor.

RESPOSTA À TERCEIRA. — Do ato pretérito podemos temer o convício ou o opróbrio futuro. E deste
modo a vergonha é uma espécie de temor.

RESPOSTA À QUARTA. — Nem toda admiração e nem todo estupor são espécies de temor; mas a
admiração provocada por um grande mal e o estupor causado por um mal insólito. — Ou podemos dizer
que, assim como a indolência evita o trabalho da ação exterior, assim a admiração e o estupor evitam a
dificuldade de encarar o que é grande e insólito, quer seja bom quer mau; por onde, deste modo, a
admiração e o estupor estão para o ato do intelecto, como a indolência, para o ato exterior.

RESPOSTA À QUINTA. — Quem admira evita julgar atualmente o que admira, temendo fazê-lo
deficientemente; mas inquire, no futuro. Ao passo que quem é tomado de estupor tanto teme julgar
atual como futuramente. Por isso, a admiração é o princípio da reflexão filosófica, da qual, ao contrário,
o estupor é um impedimento.