# Questão 23: Da diferença das paixões entre si.
Em seguida devemos tratar da diferença das paixões entre si.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se as paixões do apetite irascível são as mesmas do concupiscível.
(De Verit., q. 26, a . 4).
O primeiro discute-se assim. ― Parece que as paixões do apetite irascível são as mesmas do
concupiscível.

1. ― Pois, como diz o Filósofo, as paixões da alma são as de que resultam a alegria e a tristeza. Ora, esta
e aquela pertencem ao concupiscível. Logo, as paixões do irascível não são diferentes das do
concupiscível.

2. Demais. ― Comentando o passo da Escritura (Mt 12, 33) ― O reino dos céus é semelhante ao
fermento, etc. ― diz a Glosa de Jerônimo: Na razão tenhamos a prudência; no irascível, o ódio aos
vícios; no concupiscível, o desejo das virtudes. Ora, o ódio pertence ao concupiscível, assim como o
amor, que lhe é contrário, conforme diz Aristóteles. Logo, são as mesmas as paixões do concupiscível e
do irascível.

3. Demais. ― As paixões e os atos diferem especificamente, pelos seus objetos. Ora, as do irascível e do
concupiscível tem os mesmo objetos, a saber, o bem e o mal. Logo, as de um e de outro são idênticas.
Mas, em contrário. ― Atos de potências diversas, como ver e ouvir, são especificamente diversos. Ora, o
irascível e o concupiscível são as duas potências que dividem o apetite sensitivo, como já dissemos na
primeira parte. Logo, sendo as paixões movimentos do apetite sensitivo, conforme se disse antes as do
irascível serão especificamente diferentes das do concupiscível.

SOLUÇÃO. ― As paixões do irascível diferem especificamente das do concupiscível. Pois, tendo
potências diversas objetos diversos, como dissemos na primeira parte, as paixões de potências diversas
hão-de se referir necessariamente a objetos diferentes. Por onde, com maioria de razão, paixões de
potências diversas hão-de diferir entre si especificamente; porque, para diversificar as espécies de
potências é necessária maior diferença de objeto do que para diversificar as espécies de paixões ou
atos. Pois, assim como nos seres naturais, as diversidades genéricas resultam das diversidades da
potência da matéria, e a específica, das diversidades da forma na matéria existente, assim também os
atos da alma pertencentes a potências diversas são diversos, não só específica mas também
genericamente; os atos porém ou as paixões referentes a objetos diversos especiais compreendidos no
objeto comum de uma mesma potência diferem como espécies desse gênero.
Portanto, para sabermos quais as paixões do irascível e quais as do concupiscível, é necessário saber
qual é o objeto de uma e outra dessas potências. Ora, já dissemos na primeira parte, que o objeto da
potência concupiscível é o bem e o mal sensíveis, em si mesmos considerados, sendo aquele deleitável e
este, doloroso. Mas como por vezes a alma tem que padecer dificuldade ou luta para alcançar um bem
ou fugir de um mal de tal natureza, por estar um e outro acima do fácil alcance do animal, por isso o
bem e o mal que forem por natureza árduos e difíceis constituem o objeto do irascível. Logo, todas as
paixões que visam o bem ou o mal, absolutamente considerados, como a alegria, a tristeza, o amor, o
ódio e semelhantes, pertencem ao concupiscível; todas, porém, como a audácia, o temor, a esperança e
semelhantes, que visam o bem ou o mal enquanto árduos, enquanto difíceis, de algum modo, de serem
alcançados ou evitados, pertencem ao irascível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como dissemos na primeira parte, a potência irascível
foi dada aos animais para vencerem os obstáculos que impidam o concupiscível de tender para o seu
objeto, quer por tornarem o bem difícil de ser alcançado ou o mal difícil de ser superado. Por isso todas
as paixões do irascível vem a resolver-se nas do concupiscível; e desde logo também das paixões do
irascível resultam a alegria e a tristeza, que pertencem ao concupiscível.

RESPOSTA À SEGUNDA. ― Jerônimo atribui ao irascível o ódio dos vícios, não em si mesmo, pois então
pertenceria propriamente ao concupiscível; mas, por causa da luta que implica, e que pertence ao
irascível.

RESPOSTA À TERCEIRA. ― O bem enquanto deleitável move o concupiscível; mas desde que implica
dificuldade para ser alcançado encerra algo de repugnante ao concupiscível, donde a necessidade de se
admitir a existência de uma outra potência que tenda para ele. E o mesmo se dá com o mal. Ora, tal
potência é o irascível. Logo e conseqüentemente, as paixões do concupiscível e do irascível diferem
entre si especificamente.

## Art. 2 — Se a contrariedade entre as paixões do irascível é correlativa à existente entre o bem e o mal.
(III Sent., dist. XXVI, q. 1, a . 3; De Verit., q. 26, a . 4).
O segundo discute-se assim. ― Parece que a contrariedade entre as paixões do irascível é correlativa à
existente entre o bem e o mal.

1. ― Pois as paixões do irascível se ordenam às do concupiscível, como já dissemos. Ora, a
contrariedade existente entre estas últimas ― p. ex., entre o amor e o ódio, a alegria e a tristeza se
baseiam na que existe entre o bem e o mal. Logo, o mesmo se dá com as paixões do irascível.

2. Demais. ― As paixões diferem pelos seus objetos, como os movimentos, pelos seus termos. Ora, a
contrariedade entre aqueles supõe a existente entre estes, como se vê em Aristóteles. Logo, a
contrariedade entre as paixões também se baseia na que existe entre os seus objetos. Ora, o objeto do
apetite é o bem ou o mal. Logo, em nenhuma potência apetitiva pode haver contrariedade entre as
paixões senão fundada na que existe entre o bem e o mal.

3. Demais. ― Toda paixão da alma supõe uma aproximação e um afastamento, como diz Avicena. Ora,
aquela é causada pela idéia de bem; este, pela de mal; pois assim como o bem é o que todos os seres
desejam, conforme Aristóteles, o mal é o que todos evitam. Logo, a contrariedade entre as paixões da
alma só se pode fundar na que existe entre o bem e o mal.
Mas, em contrário. ― O temor e a audácia são contrários, como se vê em Aristóteles. Ora, entre si não
diferem só pelo bem e pelo mal, pois ambos dizem respeito a algum mal. Logo, nem toda contrariedade
entre as paixões do irascível é correlativa à que existe entre o bem e o mal.

SOLUÇÃO. ― A paixão é um movimento, como diz Aristóteles; logo, a contrariedade entre as paixões
deve deduzir-se da existente entre os movimentos ou mutações. Ora, nestas e naquelas há dupla
espécie de contrariedade, segundo Aristóteles. Uma, relativa à aproximação ou ao afastamento de um
mesmo termo e que é própria das mutações; assim, a contrariedade entre a geração, que é mudança
para o ser, e a corrupção, mudança que parte do ser. A outra é a contrariedade dos termos, própria dos
movimentos; assim o dealbar é um movimento do preto para o branco e se opõe ao enegrecer, que é
um movimento do branco para o preto.
Assim pois há nas paixões da alma dupla contrariedade: baseada uma na contrariedade dos objetos, a
saber, a que existe entre o bem e o mal; a outra, relativa à aproximação ou afastamento de um mesmo
termo. Ora, nas paixões do concupiscível há só a primeira espécie de contrariedade, relativa aos objetos;
ambas as espécies existem porém nas paixões do irascível. E a razão é que o objeto do concupiscível,
como já se disse, é o bem e o mal sensíveis absolutamente considerados. Ora, o bem como tal não pode
ser termo de afastamento mas só de aproximação; pois nenhum ser foge do bem com tal, antes, todos o
desejam. Semelhantemente, nenhum ser deseja o mal como tal, mas todos o evitam; e por isso o mal
não constitui um termo de aproximação, mas só de afastamento. Por onde, todas as paixões do
concupiscível, como o amor, o desejo e alegria, referindo-se ao bem, para este tendem: e todas as
paixões desse apetite referentes ao mal como o ódio, a aversão ou abominação e a tristeza, dele se
afastam. Logo, entre as paixões do concupiscível não pode haver contrariedade por aproximação e
afastamento do mesmo objeto.
O objeto do irascível porém é o bem ou o mal sensíveis, não absolutamente, mas enquanto difíceis ou
árduos, consoante já dissemos. Ora, o bem árduo ou difícil, enquanto bem, provoca de um lado, a
tendência para si, tendência própria à paixão da esperança; mas por outro lado, enquanto árduo e
difícil, provoca o afastamento, próprio da paixão do desespero. Semelhantemente, o mal árduo,
enquanto mal, por natureza deve ser evitado, e isto pertence à paixão do temor; provoca porém uma
tendência para si, enquanto árduo. ― pelo qual escapamos da sujeição ao mal ― e essa tendência para
ele constitui a audácia. Logo, entre as paixões do irascível há contrariedade fundada na que existe entre
o bem e o mal. ― p. ex., a contrariedade entre a esperança e o temor; e há a relativa à aproximação e
ao afastamento de um mesmo termo, como entre a audácia e o temor.
Donde se deduzem claras as RESPOSTA ÀS OBJEÇÕES.

## Art. 3 — Se toda paixão da alma tem contrária.
(Infra, q. 46, a . 1. ad 2; III Sent., dist. XXVI, q. 1, a . 3; De Verit., q. 26, a . 4).
O terceiro discute-se assim. ― Parece que toda paixão da alma tem contrária.

1. ― Pois, toda paixão respeita ao irascível ou ao concupiscível, como já se disse. Ora, as paixões de
ambos esse apetites tem contrariedade, a seu modo. Logo, toda paixão da alma tem contrária.

2. Demais. ― Toda paixão da alma ou tem o bem como objeto ou o mal, que constituem os objetos
universais da parte apetitiva. Ora, a paixão cujo objeto é o bem opõe-se à quem tem o mal como objeto.
Logo, toda paixão tem contrária.

3. Demais. ― Toda paixão da alma supõe aproximação ou afastamento, como já se disse. Ora, toda
aproximação é contrária ao afastamento e vice-versa. Logo, toda paixão da alma tem contrária.
Mas, em contrário. ― A ira é uma paixão da alma e a ela nenhuma paixão se lhe opõe, como se vê em
Aristóteles. Logo, nem toda paixão da alma tem contrária.

SOLUÇÃO. ― A paixão da ira tem isto de singular que não pode ter contrária, nem por aproximação e
afastamento, nem pela contrariedade do bem e do mal, pois é causada por um mal presente difícil. Ora,
a essa presença ou o apetite sucumbirá necessariamente, e então a ira não sai dos limites da tristeza,
paixão do concupiscível; ou será levada a atacar o mal lesivo, e isso propriamente a constitui. Por outro
lado, não lhe podemos supor um movimento de afastamento, porque o mal já é presente ou passado.
Por onde, o movimento da ira não é contrariado por nenhuma paixão, no ponto de vista da aproximação
ou do afastamento de um termo de referência. Semelhantemente, quanto à contrariedade entre o bem
e o mal. Pois ao mal presente opõe-se o bem já alcançado, que não pode implicar a idéia de árduo ou
difícil. Nem após a aquisição do bem permanece qualquer outro movimento, a não ser a quietação do
apetite no bem adquirido, o que é próprio da alegria, paixão do concupiscível. Logo, ao movimento da
ira nenhum outro movimento da alma pode ser contrário, senão só a cessação do movimento; e por isso
diz o Filósofo que ser pacífico se opõe a ser irado, o que não é oposição por contrariedade, mas por
negação ou privação.
Donde se deduzem AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 4 — Se uma mesma potência pode ter paixões especificamente diferentes e não contrárias entre si.
(III Sent., dist. XXVI, q. 1, a . 3; De Verit., q. 26, a . 4; II Ethic., lect. V).
O quarto discute-se assim. ― Parece que uma mesma potência não pode ter paixões especificamente
diferentes e não contrárias entre si.

1. ― Pois, as paixões da alma diferem pelos seus objetos. Ora, estes são o bem e o mal cujas diferenças
fundamentam a contrariedade das paixões. Logo, paixões da mesma potência, sem contrariedade
mútua, não podem entre si diferir especificamente.

2. Demais. ― A diferença específica é uma diferença formal. Ora, toda diferença formal implica alguma
contrariedade, como diz Aristóteles. Logo, paixões da mesma potência, não contrárias, não diferem
especificamente.

3. Demais. ― Toda paixão da alma consistindo numa aproximação ou afastamento do bem ou do mal,
resulta necessariamente que toda diferença entre as paixões se funda ou na diferença entre o bem e o
mal, ou na aproximação ou afastamento, ou na de maior ou menor aproximação ou afastamento. Ora,
as duas primeiras diferenças implicam a contrariedade entre as paixões como já se disse; ao passo que a
terceira não diversifica a espécie, porque então seriam infinitas as espécies de paixões. Logo, uma
mesma potência da alma não pode ter paixões especificamente diferentes e que não sejam contrárias.
Mas, em contrário. ― O amor e a alegria diferem especificamente e pertencem ao concupiscível.
Contudo não são contrários entre si, antes, aquele é causa desta. Logo, há paixões de uma mesma
potência que diferem entre si especificamente sem entretanto serem contrárias.

SOLUÇÃO. ― As paixões se distinguem pelas suas causas ativas, que são os seus objetos. Ora, a
diferença das causas ativas pode ser considerada de dois pontos de vista; especificamente e conforme a
natureza mesma delas, e assim o fogo difere da água; ou segundo a diversidade da faculdade que age.
Ora, a diversidade da causa ativa ou motora, quanto à faculdade de mover, pode ser considerada, nas
paixões da alma, por analogia com os agentes naturais. Assim, todo motor atrai de certo modo para si o
paciente, ou de si o repele. No primeiro caso produz no paciente três efeitos. Primeiro, infunde-lhe a
inclinação ou aptitude a tender para si; assim, quando um corpo leve e situado no alto dá a leveza ao
corpo que gera, pela qual este tem inclinação ou aptitude a elevar-se. Segundo, se o corpo gerado está
fora do seu lugar próprio, dá-lhe o mover-se para o lugar. Terceiro, dá-lhe o repouso no lugar alcançado,
pois pela mesma causa um corpo move-se para um lugar e nele repousa. E o mesmo se deve dizer
quando se trata da causa de uma repulsão.
Ora, nos movimento da parte apetitiva o bem tem uma quase virtude atrativa, e o mal, repulsiva. Por
onde, aquele causa primeiramente na potência apetitiva uma certa inclinação ou aptitude ou
conaturalidade para si mesmo, e isto pertence à paixão do amor, ao qual por contrariedade,
corresponde o ódio, por parte do mal. Em segundo lugar, o bem amado ainda não possuído; causa o
movimento para ser conseguido o que pertence à paixão do desejo ou da concupiscência, e por
contrariedade e quanto ao mal, a fuga ou a aversão. Terceiro, obtido o bem, o apetite produz um como
repouso no bem possuído, o que respeita à deleitação ou alegria a que se opõe, do lado do mal,
a dor ou a tristeza.
As paixões do apetite irascível porém já pressupõem, a aptitude ou inclinação a buscar o bem ou a evitar
o mal, próprias do concupiscível, que visa o bem e o mal absolutamente.
Assim, em relação ao bem ainda não possuído, temos a esperança e o desespero; em relação ao mal
presente, o temor e a audácia. Relativa porém ao bem não possuído, não há no irascível nenhuma
paixão, porque, não existe nesse caso a idéia de árduo, como já dissemos; mas a paixão da ira resulta do
mal presente.
Por onde é claro, que há três pares de paixões no concupiscível: amor e ódio, desejo e aversão, alegria e
tristeza. Semelhantemente, há três no irascível: esperança e desespero, temor e audácia, e a ira a qual
nenhum paixão se opõe.
Logo, são onze ao todo as paixões especificamente diferentes: seis do concupiscível e cinco do irascível.
E estas abrangem todas as paixões da alma.
Donde se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES.