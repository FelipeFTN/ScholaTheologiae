# Questão 12: Da intenção.
Em seguida devemos tratar da intenção.
E sobre esta Questão, cinco artigos se discutem:

## Art. 1 — Se a intenção é ato do intelecto ou da vontade.
(II Sent., dist. XXXVIII, a. 3; De Verit., q. 22, a . 13).
O primeiro discute-se assim. Parece que a intenção é ato do intelecto e não da vontade.

1. ― Pois, diz a Escritura (Mt 6, 22): Se o teu olho for simples, todo o teu corpo será luminoso,
significando olho, a intenção, como diz Agostinho. Ora, os olhos, sendo instrumentos da visão,
significam potência apreensiva. Logo, a intenção não é ato da potência apetitiva, mas da apreensiva.

2. Demais. ― No mesmo passo observa Agostinho, que a intenção é chamada luz pelo Senhor, quando o
Evangelho diz (Mt 6, 23): Se pois a luz que em ti há são trevas, etc. Ora, a luz diz respeito ao
conhecimento. Logo, também a intenção.

3. Demais. ― A intenção designa um certo ordenar-se ao fim. Ora, ordenar é próprio da razão. Logo, a
intenção pertence a esta e não à vontade.

4. Demais. ― O ato da vontade recai sobre o fim ou sobre os meios. Quando recai sobre o fim chama-se
vontade ou fruição; quando recai sobre os meios, eleição; ora, de uma e outra difere a intenção. Logo,
esta não é ato da vontade.
Mas, em contrário, diz Agostinho: a intenção da vontade une o corpo visto à vista; e semelhantemente,
a imagem existente na memória à fina ponta do espírito, que cogita interiormente. Logo, a intenção é
ato da vontade.

SOLUÇÃO. ― Intenção, como o próprio nome o indica, significa tender para alguma coisa. Ora, para
alguma coisa tende tanto a ação do motor como o movimento do móvel. Ora, pela ação do motor é que
o movimento do móvel tende. Logo, a intenção, primária e principalmente é própria do que move para
o fim; e por isso dizemos que o arquiteto, bem como todos os que ordenam, move os outros pelo seu
império, ao fim para o qual ele tende. Ora, como já se estabeleceu, a vontade move para o fim todas as
outras potências da alma. Por onde é manifesto, que a intenção é propriamente ato da vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Chama-se intenção aos olhos, metaforicamente; não
que ela seja própria do conhecimento, mas porque pressupõe este, pelo qual é proposto à vontade o
fim para onde ela a move. Assim, com os olhos prevemos para onde devemos corporalmente tender.

RESPOSTA À SEGUNDA. ― Chama-se à intenção luz porque é manifesta ao que entende. Por isso
também as obras se chamam trevas, porque o homem sabe o que entende, mas não o que resulta da
obra, como Agostinho expõe no mesmo passo.

RESPOSTA À TERCEIRA. ― Por certo que a vontade não ordena, mas tende contudo para alguma coisa,
segundo a ordem da razão. Por onde, esse nome de intenção designa um ato da vontade, pressuposta à
ordenação da razão, que ordena uma coisa para o fim.

RESPOSTA À QUARTA. ― A intenção é ato da vontade relativamente ao fim. Ora, de tríplice modo a
vontade visa o fim. Absolutamente, e então chama-se vontade o ato pelo qual queremos, de modo
absoluto, a saúde ou coisa semelhante, que exista. De outra maneira, o fim é considerado como o em
que a vontade descansa, e então a fruição respeita ao fim. Em terceiro lugar, o fim é considerado como
o termo de algo que para ele ordena, e é assim que a intenção diz respeito ao fim. Pois, não intendemos
a saúde só porque a queremos, mas porque queremos alcançá-la por alguma meio.

## Art. 2 — Se a intenção só se refere ao fim último.
O segundo discute-se assim. ― Parece que a intenção se refere só ao fim último.

1. ― Pois, como está no livro das Sentenças de Próspero: o clamor a Deus é a intenção do coração. Ora,
Deus é o fim do coração humano. Logo, a intenção só se refere ao fim.

2. Demais. ― A intenção, enquanto termo respeita ao fim, como já se disse. Ora, o termo é por natureza
último. Logo, a intenção sempre diz respeito ao fim último.

3. Demais. ― Como a intenção visa o fim, assim também a fruição. Ora, esta sempre se refere ao fim
último. Logo, também aquela.
Mas, em contrário. ― Só um ― a beatitude ― é o fim último das vontades humanas. Se pois a intenção
fosse relativa só ao fim último, não haveria intenções humanas diversas, o que é claramente falso.

SOLUÇÃO. ― Como já se disse, a intenção diz respeito ao fim, como termo que é do movimento da
vontade. Ora, relativamente a este, pode-se considerar o fim de duplo modo. Como o termo último, em
que se descansa, e que é o termo do movimento total; ou como termo médio, princípio de uma parte do
movimento e fim ou termo de outra. Assim, no movimento pelo qual se vai de A para C passando por B,
C é o termo último, B, também termo, mas não último; e a ambos pode se referir a intenção. Por onde,
embora sempre seja fim, nem por isso é necessário que sempre seja fim último.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Chama-se à intenção do coração clamor a Deus, não que
Deus seja sempre objeto, mas, sim, o conhecedor da intenção. — Ou porque, quando oramos, dirigimos
a Deus a nossa intenção que tem quase a força do clamor.

RESPOSTA À SEGUNDA. ― O termo tem a natureza de último, nem sempre, porém, em relação ao todo;
mas às vezes, em relação a uma das partes.

RESPOSTA À TERCEIRA. ― Fruição importa em repouso no fim, o que é próprio só do fim último. Ao
passo que a intenção importa em movimento para o fim; não porém, repouso. Portanto não realizam a
mesma noção.

## Art. 3 — Se se pode Intender várias coisas simultaneamente.
(De Verit., q. 13, a . 3).
O terceiro discute-se assim. ― Parece que não se podem intender várias coisas simultaneamente.

1. ― Pois, como diz Agostinho, o homem não pode intender simultaneamente Deus e as comodidades
materiais. Logo, por igual razão, não pode intender duas coisas quaisquer.

2. Demais. ― Intenção significa o movimento da vontade para um termo. Ora, um movimento não pode
ter, no mesmo ponto de vista, vários termos. Logo, a vontade não pode intender simultaneamente
muitas coisas.

3. Demais. ― A intenção pressupõe o ato da razão ou do intelecto. Ora, não inteligimos várias coisas
simultaneamente, segundo o Filósofo. Logo, também não as intendemos simultaneamente.
Mas, em contrário. ― A arte imita a natureza. Ora, esta, com um só instrumento, intende duas
utilidades; assim, a língua se ordena ao gosto e à locução, como diz Aristóteles. Logo do mesmo modo, a
arte ou a razão pode ordenar um meio simultaneamente a dois fins. Portanto, podem-se intender várias
coisas simultaneamente.

SOLUÇÃO. ― Duas coisas quaisquer podem ser consideradas em duplo aspecto: ordenadas ou não, uma
para a outra. Se ordenadas, é claro, pelo que já se disse, que o homem pode intender várias coisas
simultaneamente; pois a intenção recai não só sobre o fim último, conforme já se disse, mas também
sobre os meios. Assim, podemos intender simultaneamente o fim próximo e o fim último; p.ex., a
preparação de um remédio e a saúde. Se porém não forem ordenadas, ainda assim o homem pode
intender várias coisas simultaneamente; o que se evidencia quando prefere a outra uma coisa que julga
melhor. E entre as condições que tornam uma coisa melhor que outra, está a que a faz servir a mais fins;
e por isso, podemos preferi-la. Assim, pois, o homem intende várias coisas simultaneamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho quer dizer que o homem não pode intender
simultaneamente Deus e as comodidades temporais, como fins últimos; porque, conforme já se
demonstrou, um mesmo homem não pode ter vários fins últimos.

RESPOSTA À SEGUNDA. ― Um mesmo movimento pode ter, no mesmo ponto de vista, vários termos,
se um se ordenar ao outro; mas não o pode, se os termos não forem assim ordenados. Note-se, porém,
que pode ser considerado como uno, racionalmente, o que na realidade não é tal. Ora, a intenção é o
movimento da vontade para algo de preordenado na razão, como já se disse. Por onde, coisas várias, na
realidade, podem ser consideradas, enquanto dotadas de unidade racional, como um só termo da
intenção. E isso, porque duas coisas ou concorrem para integrar outra, p. ex., o calor e o frio
proporcionados, concorrem para a saúde; ou se incluem em outra que lhes é comum e é o termo da
intenção, e assim a aquisição do vinho e de roupas, p. ex., estando contida no lucro, como algo que lhes
é comum, nada impede intenda essas duas coisas quem intende o lucro.

RESPOSTA À TERCEIRA. ― Conforme já se disse na primeira parte (q. 85 a 4), podemos inteligir várias
coisas simultaneamente, contanto que tenham certa unidade.

## Art. 4 — Se é um só e mesmo movimento a intenção do fim e a vontade dos meios.
(Supra, q. 8, a . 3; II Sent., q. XXXVIII, a . 4; De Verit., q. 22, a . 14).
O quarto discute-se assim. ― Parece que não é um só e mesmo movimento a intenção do fim e a
vontade dos meios.

1. ― Pois, diz Agostinho, a vontade de ver uma janela tem como fim a visão dela; e outra é a vontade de
ver, pela janela, os transeuntes. Ora, querer ver os transeuntes, pela janela, inclui-se na intenção;
querer ver a janela, na vontade, que visa os meios. Logo, é um movimento da vontade a intenção do fim
e, outro, o querer os meios.

2. Demais. ― Os atos se distinguem pelos seus objetos. Ora, fins e meios são objetos diversos. Logo,
querer o fim e os meios são movimentos diversos da vontade.

3. Demais.— À vontade dos meios se chama eleição. Ora, esta não é idêntica à intenção. Logo, a
intenção do fim não é movimento idêntico ao da vontade dos meios.
Mas, em contrário, os meios estão para o fim como o que é médio para o termo. Ora, nos seres naturais,
é o mesmo movimento que, pelo termo médio, chega ao termo último. Logo, também no domínio da
vontade, o mesmo movimento é intenção do fim e vontade dos meios.

SOLUÇÃO. ― De duplo modo se pode considerar o movimento da vontade para o fim e para os meios.
― De um modo, enquanto a vontade se dirige para um e outro encarando-os absolutamente e em si. E
então, há dois movimentos absolutos da vontade. ― De outro modo, podemos considerar que é por
causa do fim que a vontade busca os meios. E assim, por um e mesmo movimento, com o mesmo
sujeito, a vontade tende para o fim e para os meios. Por ex., quando digo ― quero o remédio por causa
da saúde ― não designo mais que um mesmo movimento da vontade, e isso porque o fim é a razão de
querer os meios. Ora, é o mesmo ato que recai sobre o objeto e sobre a razão que permite apreendê-lo,
assim como um mesmo olhar vê a cor e a luz, conforme já se disse. E o mesmo se dá com o intelecto
que, por atos diversos, considera absolutamente o princípio e a conclusão; mas por um só ato assente à
conclusão por causa dos princípios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho se refere à vista da janela e dos transeuntes,
por ela, enquanto a vontade exerce esses dois atos absolutamente.

RESPOSTA À SEGUNDA. ― O fim, enquanto realidade, é objeto da vontade, diferente dos meios; mas é
um e mesmo objeto com eles, enquanto é a razão de serem queridos.

RESPOSTA À TERCEIRA. ― O movimento subjetivamente uno pode se diversificar pelo seu princípio e
pelo seu fim; assim, a ascensão e a descida, como diz Aristóteles. Por onde, há eleição quando o
movimento da vontade recai sobre os meios, enquanto ordenados ao fim. Chama-se intenção o
movimento da vontade que recai sobre o fim, enquanto conseguindo pelos meios. E a prova é que pode
haver a intenção do fim sem estarem ainda determinados os meios, sobre os quais recai a eleição.

## Art. 5 — Se os brutos Intendem o fim.
O quinto discute-se assim. ― Parece que os brutos intendem o fim.

1. ― Pois, a natureza dos seres carecentes de razão dista mais da natureza do que da natureza sensível
dos brutos. Ora, a natureza intende um fim, mesmo nos seres carecentes de razão, como o prova
Aristóteles. Logo, com maior razão, os brutos intendem o fim.

2. Demais. ― Como a intenção tem por objeto o fim, assim também a fruição, como se disse. Logo, e
igualmente, de intenção.

3. Demais. ― Não sendo o intender senão tender para algum fim, o que age para um fim o intende. Ora,
os brutos agem para um fim, pois o animal se move em busca de alimento e para coisas semelhantes.
Logo, intendem o fim.
Mas, em contrário. ― A intenção do fim importa em ordenar-se para ele, e ordenar é próprio da razão.
Ora, como os brutos não a tem, não intendem o fim.

SOLUÇÃO. ― como já se disse, intender é tender para alguma coisa, o que é próprio do motor e do
movido. ― Se pois, se diz que intende o fim o que é movido para ele, então a natureza o intende,
movida que é ao seu fim por Deus, assim como a seta pelo sagitante. E deste modo, também os brutos
intendem o fim enquanto movidos pelo instinto natural. ― De outro modo, intender o fim é próprio do
motor, enquanto ordena ao fim o movimento seu ou alheio, o que é obra só da razão. E nesta sentido,
que é o de intender própria e principalmente, os brutos não intendem o fim, como já se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procede sendo intender próprio do que é
movido para o fim.

RESPOSTA À SEGUNDA. ― A fruição não importa, como a intenção, em ordenar-se uma coisa para um
ser, mas o descanso absoluto no fim.

RESPOSTA À TERCEIRA. ― Os brutos são movidos para o fim, não considerando que podem alcançá-lo
pelo seu movimento, o que é próprio de quem intende; mas desejando-o, são movidos para ele por um
instinto natural, quase movidos por outro ser, segundo acontece com tudo o que é naturalmente
movido.