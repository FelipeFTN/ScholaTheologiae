# Questão 69: Das bem-aventuranças.
Em seguida devemos tratar das bem-aventuranças.
E sobre esta questão, quatro artigos se discutem:

## Art. 1 — Se as bem-aventuranças se distinguem das virtudes e dos dons.
(III Sent., dist. XXXIV, q. 1, a. 4: In Isaiam, cap. XI; In Matth., cap. V).
O primeiro discute-se assim. — Parece que as bem-aventuranças não se distinguem das virtudes e dos
dons.

1. — Pois, Agostinho atribui as bem-aventuranças enumeradas em Mat., V, aos dons do Espírito Santo;
ao passo que Ambrósio as atribui às quatro virtudes cardeais. Logo, as bem-aventuranças não se
distinguem das virtudes e dos dons.

2. Demais. — A vontade humana só tem duas regras: a razão e a lei eterna, como já se disse. Ora, as
virtudes aperfeiçoam o homem na ordem da razão; e os dons, na da lei eterna e do Espírito Santo, como
do sobredito resulta. Logo, além das virtudes e dos dons, não pode haver mais nada concernente à
retidão da vontade humana. Logo, as bem-aventuranças não se distinguem deles.

3. Demais. — Na enumeração das bem-aventuranças inclui-se a mansidão, a justiça e a misericórdia,
consideradas como sendo virtudes. Logo, as bem-aventuranças não se distinguem dos dons e das
virtudes.
Mas, em contrário, algumas das consideradas bem-aventuranças não são virtudes nem dons; tais a
pobreza, o pranto e a paz. Logo, as bem-aventuranças diferem das virtudes e dos dons.

SOLUÇÃO. — Como já dissemos, a bem-aventurança é o fim último da vida humana. Ora, considera-se
como já possuindo o fim quem tem a esperança de obtê-lo. Donde, diz o Filósofo que as crianças se
consideram felizes por causa da esperança; e o Apóstolo (Rm 8, 24): na esperança é que temos sido
feitos salvos. Ora, a esperança de conseguir o fim resulta de nos movermos convenientemente para ele
e dele nos aproximarmos, e isso se faz pelo agir. Ora, nós nos movemos para a bem-aventurança final e
dela nos aproximamos, pelos atos virtuosos, e principalmente pela influência dos dons, se nos referimos
à eterna beatitude, para a qual não basta a razão, mas é necessário o auxílio do Espírito Santo, para
obedecer e seguir ao qual nos tornam aptos os dons. Logo, as bem-aventuranças distinguem-se das
virtudes e dos dons, não como hábitos deles distintos, mas como os atos se distinguem dos hábitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho e Ambrósio atribuem as bem-aventuranças
aos dons e às virtudes, assim como os atos são atribuídos aos hábitos. Os dons porém são mais
eminentes que as virtudes cardeais, como já dissemos. E por isso Ambrósio, explicando as bem-
aventuranças propostas à multidão, as atribui às virtudes cardeais; ao passo que Agostinho, expondo as
propostas aos discípulos no monte, como a mais perfeitos, atribui-as aos dons do Espírito Santo.

RESPOSTA À SEGUNDA. — A objeção prova não haver, além das virtudes e dos dons, outros hábitos
retificadores da vida humana.

RESPOSTA À TERCEIRA. — A humildade é tomada pelo ato de mansidão. E o mesmo se deve dizer da
justiça e da misericórdia. E embora estas se considerem virtudes, atribuem-se contudo aos dons, pois
também estes aperfeiçoam os homens em relação aos mesmos objetos que as virtudes, como se disse.

## Art. 2 — Se os prêmios atribuídos as bem-aventuranças pertencem a esta vida.
(In Matth., cap.V).
O segundo procede-se assim. — Parece que os prêmios atribuídos as bem-aventuranças não
pertencem a esta vida.

1. — Pois, como já se disse, chama-se felizes os que têm a esperança dos prêmios. Ora, o objeto da
esperança é a felicidade futura. Logo, esses prêmios pertencem à vida futura.

2. Demais. — O Evangelho comina certas penas opostas as bem-aventuranças, quando diz (Lc 6, 25): Ai
de vós os que estais fartos, porque vireis a ter fome. Ai de vós os que agora rides, porque gemereis e
chorais. Ora, tais penas não as abrange a vida presente, pois freqüentemente os homens durante ela
não são punidos, conforme àquilo da Escritura (Jó 21, 13): Eles passam os seus dias em prazeres. Logo,
também os prêmios das bem-aventuranças não pertencem a esta vida.

3. Demais. — O reino dos céus, posto como prêmio da pobreza, é a beatitude celeste, conforme
Agostinho. Ora, a plena saciedade só existirá na vida futura, consoante àquilo da Escritura (Sl 16,
15): saciar-me-ei quando aparecer a tua glória. Ora, a visão de Deus e a manifestação da divina filiação
pertencem à vida futura, como consta da Escritura (1 Jo 3, 2): Agora somos filhos de Deus, e não
apareceu ainda o que havemos de ser. Sabemos que quando ele aparecer, seremos semelhantes a ele;
porquanto nos outros o veremos bem como ele é. Logo, os prêmios de que tratamos pertencem à vida
futura.
Mas, em contrário, Agostinho diz: Tais coisas podem por certo existir completamente nesta vida, como
cremos terem existido nos Apóstolos. Pois, aquela omnímoda transformação em forma Angélica,
prometida para depois desta vida, não pode ser explicada por nenhumas palavras.

SOLUÇÃO. — Sobre os prêmios em questão manifestam-se diversamente os expositores da Sagrada
Escritura. Uns, como Ambrósio dizem pertencerem todos à futura beatitude. Agostinho, porém,
considera-os pertencentes à vida presente. Crisóstomo, por seu lado, nas suas Homilias, diz
pertencerem uns à vida futura, e outros, à presente.
Para evidenciá-lo, devemos considerar que a esperança da futura beatitude pode existir em nós por
duas razões: primeiro, por uma certa preparação ou disposição à futura beatitude, e isso se dá pelo
mérito; ou, segundo, por uma incoação imperfeita da futura beatitude, nos varões santos, já nesta vida.
Pois, uma é a esperança na frutificação da árvore, quando rondeja viridente, e outra, quando começam
a aparecer os primeiros frutos.
Por onde, o nas bem-aventuranças concernente ao mérito, são umas preparações ou disposições à
beatitude, perfeita ou incoada. E o concernente nelas aos prêmios, pode consistir ou na beatitude
perfeita em si mesma, e então respeitar à vida futura, ou numa incoação da beatitude, como se dá com
os santos varões, e então dizem respeito à vida presente. Pois, quem começa por progredir nos atos das
virtudes e dos dons pode ter esperança de chegar à perfeição da via e da pátria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A esperança pode recair sobre a beatitude futura, como
sobre o último fim; pode também ter por objeto o auxílio da graça, como os meios, conforme aquilo da
Escritura (Sl 27, 7): Em Deus esperou o meu coração e eu fui ajudado.

RESPOSTA À SEGUNDA. — Embora às vezes os maus não sofram nesta vida penas temporais, as sofrem
contudo espirituais: Por isso, diz Agostinho: Conforme mandaste, Senhor, a alma desregrada é para si
mesma o seu castigo. E o Filósofo, falando dos maus: na alma deles domina a discórdia, que os arrasta,
ora para aqui e ora, para lá; e depois, conclui: Se a tal ponto é miserável o ser mau, havemos de fugir
intensamente a malícia. E semelhante e inversamente, embora os bons não recebam às vezes prêmios
materiais nesta vida, nunca lhes hão-de faltar contudo os espirituais, já nesta vida, conforme aquilo da
Escritura (Mt 19, 29 e Mc. 10, 30): recebereis, já neste século, o cêntuplo.

RESPOSTA À TERCEIRA. — Todos os prêmios, de que se trata, se consumarão por certo, na vida eterna;
mas de certo modo, enquanto lá não chegamos, começam já nesta vida. Pois, o reino dos céus, no dizer
de Agostinho, pode ser entendido como o início da sabedoria perfeita, por já começar a reinar neles o
espírito. Quanto à posse da terra, ela significa o bom afeto da alma repousando pelo desejo na
estabilidade da herança perpétua, que é o significado de terra. São consolados nesta vida, participando
do Espírito Santo, denominadoParáclito, i. é, Consolador. Ficam saturados, já no estado atual, do
alimento de que diz o Senhor (Jo 4, 34): A minha comida é fazer eu a vontade de meu Pai. Também
nesta vida os homens alcançam a misericórdia de Deus. Nela, purificada a visão pelo dom da
inteligência, Deus pode de certo modo ser visto. Mesmo nesta vida, também os que pacificam os seus
movimentos tornando-se mais semelhantes a Deus, são chamados seus filhos. Mas, sê-lo-ão mais
perfeitamente, na pátria.

## Art. 3 — Se as bem-aventuranças são enumeradas convenientemente.
(III Sent., dist. XXXIV, q. 1. a. 4; in Matth., cap.V).
O terceiro discute-se assim. — Parece que as bem-aventuranças são enumeradas
inconvenientemente.

1. — Pois, são atribuídas aos dons, como já se disse. Ora, destes, uns, como a sabedoria e o intelecto,
pertencem à vida contemplativa. Ora, não se enumera nenhuma bem-aventurança consistente no ato
da contemplação, mas todas as enumeradas consistem na vida ativa. Logo, são enumeradas
insuficientemente.

2. Demais. — À vida ativa pertencem não somente os dons executivos, mas também certos diretivos,
como a ciência e o conselho. Ora, nenhuma das bem-aventuranças enumeradas implica diretamente o
ato de ciência ou de conselho. Logo, são enumeradas insuficientemente.

3. Demais. — Na vida ativa, entre os dons executivos, a enumeração considera o temor como
pertencente à pobreza e a piedade, à bem-aventurança da misericórdia. E nada inclui que implique
diretamente a fortaleza. Logo, as bem-aventuranças são enumeradas insuficientemente.

4. Demais. — A Sagrada Escritura se refere a muitas outras bem-aventuranças; assim, um lugar diz (Jó 5,
17): Bem-aventurado o homem a quem Deus corrige, e ainda (Sl 1, 1): Bem-aventurado o varão que não
se deixou ir após o conselho dos ímpios e, por fim (Pr 3, 13): Bem-aventurado o homem que achou a
sabedoria. Logo, as bem-aventuranças são enumeradas insuficientemente.

5. Mas, em contrário. — Parece que a enumeração é supérflua. Pois, ao passo que são só sete os dons
do Espírito Santo, enumeram-se oito bem-aventuranças.

6. Demais. — São Lucas (Lc 6) enumera só quatro bem-aventuranças. Logo, São Mateus (Mt 5) enumera
sete ou oito superfluamente.

SOLUÇÃO. — As bem-aventuranças estão convenientíssimamente enumeradas.
Para cuja evidência devemos considerar uma tríplice opinião a respeito da bem-aventurança. Assim, uns
a fizeram constituir na vida voluptuosa; outros, na ativa; outros por fim, na contemplativa. Ora, estas
três espécies de bem-aventurança se relacionam diferentemente com a futura beatitude, cuja
esperança já faz sejamos considerados felizes nesta vida. Pois, a beatitude voluptuosa, sendo falsa e
contrária à razão, é obstáculo à futura beatitude. A consistente na vida ativa dispõe para a beatitude
futura. E a contemplativa, quando perfeita, constitui essencialmente a própria felicidade futura; se
imperfeita, é uma incoação desta.
E por isso o Senhor enunciou, primeiro, certas bem-aventuranças que são quase removentes do
impedimento da felicidade voluptuosa. Ora, esta consiste em duas coisas. — Primeiro, na afluência dos
bens exteriores, quer riquezas, quer honras. Delas o homem se retrai, pela virtude, usando-as
moderadamente; pelo dom, de modo mais excelente, desprezando-as totalmente. Por isso, Mateus
assim enuncia a primeira bem-aventurança (Mt 5, 3): Bem-aventurados os pobres de espírito, referente
ao desprezo das riquezas ou das honras, por meio da humildade. — segundo, em seguir as paixões
próprias, do irascível ou do concupiscível. No primeiro caso, a virtude impede ao homem exceder-se,
fazendo-o obedecer à regra da razão; e o dom, de modo mais excelente, tornando-o totalmente livre
delas, por vontade divina. E por isso, a segunda bem-aventurança anuncia (Mt 5, 4): Bem-aventurados
os mansos. No segundo caso, a virtude faz-nos usar moderadamente das paixões do concupiscível; e o
dom leva-nos a rejeitá-las totalmente se for necessário; e até mesmo sendo necessário, deixando-se
voluntariamente romper em lágrimas. E por isso a terceira bem-aventurança proclama: Bem-
aventurados os que choram.
Por seu lado, a vida ativa consiste precípuamente em darmos ao próximo o que lhe devemos ou o com
que espontaneamente o beneficiamos. No primeiro caso pela virtude da justiça damos-lhe o devido; e,
por seu lado, o dom nos leva também a fazê-lo com afeto mais abundante, praticando, levados por
ardente desejo, os atos de justiça, assim como quem tem fome e sede deseja ardentemente, a comida e
a bebida. E por isso a quarta bem-aventurança proclama: Bem-aventurados os que têm fome e sede de
justiça. Quanto aos dons espontâneos, a virtude da liberalidade nos aperfeiçoa para darmos a quem a
razão nos manda fazê-la, p. ex., aos amigos ou a outros que nos são chegados; mas o dom, pela
reverência para com Deus só considera a necessidade nos casos em que são preferíveis os benefícios
gratuitos. Donde o dizer Lucas (14, 12): Quando deres algum jantar ou alguma ceia, não chames nem
teus amigos, nem teus irmãos, etc.; mas convida os pobres, os aleijados etc.; o que é propriamente ter
misericórdia. E por isso a quinta bem-aventurança proclama: Bem-aventurados os misericordiosos.
Por fim a vida contemplativa ou constitui a própria beatitude final ou é dela uma incoação; e por isso, na
enumeração das bem-aventuranças, não é considerada como mérito, mas como prêmio. Mas são
considerados méritos os efeitos da vida ativa, que dispõem bem o homem para a contemplativa. Ora, no
atinente às virtudes e aos dons, que aperfeiçoam o homem em si mesmo, os efeitos da vida ativa
consistem na pureza do coração, i. é, em o coração do homem não andar inquinado de paixões. E por
isso a sexta beatitude proclama:Bem-aventurados os limpos de coração. No atinente porém às virtudes
e aos dons, que aperfeiçoam o homem nas suas relações com o próximo, o efeito da vida ativa é a paz,
conforme aquilo de Isaías (32, 17): E a paz será a obra da justiça. E por isso a sétima bem-aventurança
promete: Bem-aventurados os pacíficos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os atos dos dons pertencentes à vida ativa manifestam-
se nos próprios méritos; e os dos dons pertinentes à vida contemplativa, nos prêmios, pela razão já dita.
Ora, ver a Deus corresponde ao dom do intelecto; e conformar-se com Deus como por uma filiação
adotiva, ao dom da sabedoria.

RESPOSTA À SEGUNDA. — No concernente à vida ativa o conhecimento não é necessário, em si mesmo,
mas em vista da ação, como também, diz o Filósofo. E como a beatitude implica o que é último, entre as
bem-aventuranças não se contam os atos elícitos provenientes dos dons dirigentes à vida ativa; assim,
aconselhar é ato de conselho e julgar, de ciência. Mas se lhes atribuem os atos operativos, que eles
dirigem; assim, à ciência, o chorar, e ao conselho, o compadecer-se.

RESPOSTA À TERCEIRA. — Duas coisas podem se considerar na atribuição das bem-aventuranças aos
dons. — A primeira é a conformidade da matéria. E a esta luz, todas as cinco primeiras bem-
aventuranças podem atribuir-se à ciência e ao conselho como dirigentes; mas se incluem entre os dons
executivos. E assim, a fome e a sede da justiça, e mesmo a misericórdia, concernem à piedade, que
aperfeiçoam o homem nas suas relações para com os outros; a mansidão, porém, à fortaleza, conforme
Ambrósio, dizendo que é próprio da fortaleza vencer a ira e coibir a indignação, pois a fortaleza se
exerce sobre as paixões do irascível. Por seu lado, a pobreza e as lágrimas concernem ao dom do temor,
pelo qual o homem se afasta da concupiscência e dos prazeres do mundo. — A segunda coisa a
considerar são os motivos das bem-aventuranças. E, a esta luz são diversas as atribuições que lhes
devemos fazer. Assim, precipuamente, à mansidão move a reverência para com Deus, relativa à
piedade. Às lágrimas, move principalmente a ciência, que leva o homem a conhecer os seus defeitos e
os das coisas mundanas, conforme aquilo da Escritura (Ecle 1, 18): o que acrescenta a ciência também
acrescenta o trabalho. A ter fome das obras da justiça move principalmente a fortaleza de alma; e por
fim, a ter misericórdia, move precìpuamente o conselho de Deus, conforme aquilo da Escritura (Dn 4,
24): segue, ó rei, o conselho que te dou, e rime os teus pecados com esmolas, e as tuas iniqüidades com
obras de misericórdia para os pobres. E este modo de atribuição segue Agostinho.

RESPOSTA À QUARTA. — É necessário admitir que todas as bem-aventuranças constantes da Escritura
se reduzem às da enumeração vertente, quanto aos méritos ou quanto aos prêmios; pois,
necessariamente, todas hão-de pertencer, de algum modo, à vida ativa ou à contemplativa. Por onde o
lugar — Bem-aventurado o homem a quem Deus corrige — pertence a bem-aventurança das lágrimas; o
outro — Bem-aventurado o homem que achou a sabedoria — ao prêmio da sétima bem-aventurança. E
o mesmo se poderá dizer de outros que se possam aduzir.

RESPOSTA À QUINTA. — A oitava bem-aventurança é uma confirmação e manifestação de todas as
precedentes. Pois, quem está firmado na pobreza do espírito e na mansidão e nas demais bem-
aventuranças, não se afasta, por isso mesmo, desses bens por nenhuma perseguição. Por outro, a oitava
bem-aventurança concerne, de certo modo, às sete precedentes.

RESPOSTA À SEXTA. — Lucas narra que o sermão do Senhor foi feito às turbas. Por isso enumera as
bem-aventuranças conforme a capacidade delas, que só conheciam a felicidade voluptuosa, temporal e
terrena. Por onde, pelas quatro bem-aventuranças, o Senhor exclui as quatro coisas incluídas na
felicidade de que acabamos de falar. — E destas quatro, a primeira é a abundância dos bens exteriores
excluída pelo dito: Bem-aventurados os pobres, etc. — A segunda é o bem estar corpóreo, no que
respeita à comida, à bebida e coisas semelhantes. E isto fica excluído pela segunda bem-
aventurança. Bem-aventurados os que tem fome. — A terceira é o bem estar do homem quanto aos
prazeres do coração; o que fica excluído pela terceira bem-aventurança: Bem-aventurados os que
choram. — A quarta é o favorecimento externo dos homens, excluído pela quarta bem-
aventurança: Bem-aventurados sereis quando os homens vos aborrecerem. E como diz Ambrósio, a
pobreza pertence à temperança, que não busca as seduções; a fome, à justiça, porque quem tem fome
se compadece e, compadecendo-se, torna-se liberal; as lagrimas, à prudência, da qual é próprio chorar
as coisas perecíveis; sofrer o ódio dos homens, à fortaleza.

## Art. 4 — Se os prêmios das bem-aventuranças estão convenientemente enumerados.
(III Sent., dis. XXXIV, q. 1, a. 4).
O quarto discute-se assim. — Parece que os prêmios das bem-aventuranças estão
inconvenientemente enumerados.

1. — Pois, o reino dos céus, que é a vida eterna, contém todos os bens. Logo, não era preciso
estabelecer outros prêmios além deles.

2. Demais. — O reino dos céus é posto como prêmio pela primeira e pela oitava bem-aventuranças.
Logo, por igual razão, devia sê-lo por todas.

3. Demais. — As bem-aventuranças procedem por ordem ascendente, como diz Agostinho. Ora, os
prêmios procedem por ordem descendente; assim, a posse da terra é menos que o reino dos céus. Logo,
esses prêmios são enumerados inconvenientemente.
Mas, em contrário, é a autoridade do Senhor mesmo, que é quem propõe esses prêmios.

SOLUÇÃO. — Os prêmios em questão estão convenientíssimamente assinalados, considerada a
condição das bem-aventuranças relativamente às três supra-assinaladas.
Pois, as três primeiras bem-aventuranças se fundam no afastamento do em que consiste a felicidade
voluptuosa, que nós desejamos naturalmente mas, colocando-a não em Deus, onde deveríamos colocá-
la, senão nos bens temporais, e caducos. E por isso os prêmios das três primeiras bem-aventuranças são
relativos ao que muitos buscam na felicidade terrena. — Demais disso, os homens também buscam a
excelência e a abundância dos bens exteriores, i. é, das riquezas e das honras. Ora, tudo isso
compreende o reino dos céus, onde o homem consegue a excelência e a abundância dos bens, em Deus.
E por isso o reino dos céus o Senhor tornou a prometê-lo aos pobres de espírito. — Alem disso, os
homens duros e cruéis buscam a segurança própria destruindo os inimigos pelas lutas e guerras. Por
isso, o Senhor prometeu ainda aos pacíficos a segura e quieta posse da terra dos vivos, por onde se
exprime a solidez dos bens eternos. —Por fim, os homens buscam, na concupiscência e nos prazeres do
mundo, consolação aos trabalhos da vida presente. E por isso o Senhor prometeu ainda o consolo da
vida aos que choram.
Em seguida, as duas outras bem-aventuranças concernem às obras da felicidade ativa, que são as das
virtudes que nos põem em relação com o próximo, de cujas obras muitos se retraem pelo amor
desordenado dos próprios bens. E por isso o Senhor atribui a essas bem-aventuranças aqueles prêmios
(como bens) por causa dos quais os homens delas se afastam. — Também, muitos abandonam a prática
da justiça, não só não pagando o devido, mas até apoderando-se do alheio, para se enriquecerem de
bens temporais. Por isso, o Senhor prometeu a saciedade aos que têm fome de justiça. — Também
muitos abandonam a prática das obras de misericórdia, para não se imiscuírem com as misérias alheias.
Por isso, o Senhor prometeu misericórdia aos misericordiosos, que os livrará de toda miséria.
Por fim, as duas últimas bem-aventuranças concernem à felicidade ou beatitude contemplativa. E por
isso os prêmios se conferem conforme a conveniência das disposições incluídas no mérito. — Assim, a
pureza dos olhos dispõe à visão clara por onde, aos puros de coração é prometida a visão de Deus. —
Por outro lado, constituir a paz, em si mesmo ou entre os outros, manifesta que o homem é imitador do
Deus da união e da paz. E por isso, como prêmio, lhe é dada a glória da filiação divina, consistente na
perfeita união com Deus, pela sabedoria consumada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como Crisóstomo diz, todos os prêmios em questão
constituem um só na realidade — a felicidade eterna, que a inteligência humana não pode
compreender. E por isso era necessário, pelos diversos bens que conhecemos, se dissesse a quem se
faria a distribuição dos prêmios; observada a relação com os méritos.

RESPOSTA À SEGUNDA. — Assim como a oitava bem-aventurança é quase o fundamento de todas,
assim, devidos lhe são os prêmios de todas. Por onde, ocupa o primeiro lugar e se deve entender, por
conseqüência, que todos os prêmios lhe são atribuídos. Ou, segundo Ambrósio, o reino dos céus é
prometido aos pobres de espírito, quanto à glória da alma; e aos que sofreram perseguição no corpo,
quanto à glória deste.

RESPOSTA À TERCEIRA. — Também os prêmios diferem entre si por mais ou menos ricos. Assim, possuir
a terra do reino dos céus é mais do que simplesmente tê-la; pois temos muitas coisas que não
possuímos firme e pacificamente. Consolar-se no reino é mais do que tê-lo e possuí-lo, pois muitas
coisas nós as possuímos com dor. Ser saciado é mais que simplesmente consolar-se; pois a sociedade
implica a abundância da consolação. Mas a misericórdia ainda excede à sociedade, porque recebemos,
por ela, mais do que merecemos ou podemos desejar. E, mais ainda é ver a Deus, assim como maior é
quem, na corte, além de sentar-se à mesa do rei, vê-lhe a face. Por isso, na casa real, a maior dignidade
é a do filho do rei.