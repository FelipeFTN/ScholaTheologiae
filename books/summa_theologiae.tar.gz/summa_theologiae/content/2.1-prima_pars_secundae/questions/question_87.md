# Questão 87: Do reato da pena.
Em seguida devemos tratar do reato da pena. E, primeiro, do reato em si mesmo. Segundo, do pecado
mortal e do venial, que se distinguem entre si pelo reato. E, na primeira questão discutem-se oito
artigos:

## Art. 1 — Se o reato da pena é efeito do pecado.
(II Sent., dist. XXXII, q. 1, a. 1; IV, dist. XIV, q. 2, a. 1, qª 2; III Cont. Gent., cap. CXL: De Malo, q. 7, a. 10).
O primeiro discute-se assim. — Parece que o reato da pena não é efeito do pecado.

1. — Pois o acidente não pode ser efeito próprio da sua substância. Ora, o reato da pena é um acidente
do pecado, por estar fora da intenção do pecador. Logo, esse reato não é efeito do pecado.

2. Demais. — O mal não pode ser a causa do bem. Ora, a pena, sendo justa e infligida por Deus, é boa.
Logo, não é efeito do pecado, que é um mal.

3. Demais. — Agostinho diz: toda alma desordenada é a sua própria pena. Ora, uma pena não pode
causar o reato de outra, pois isso levaria ao infinito. Logo, o pecado não causa o reato da pena.
Mas, em contrário, diz a Escritura (Rm 2, 9): A tribulação e a angustia virá sobre toda a alma do homem
que obra mal. Ora, obrar mal é pecar. Logo, o pecado implica a pena, designada pelo nome de tribulação
e de angústia.

SOLUÇÃO. — Como na ordem natural, também na humana, uma coisa que se opõe a outra sofre
detrimento por parte desta. Assim, vemos, naquela ordem, que um contrário age mais veementemente
quando sobrevém o outro; e isso explica que a água aquecida se congela mais compactamente, como
diz Aristóteles. Assim também, vemos se dar o mesmo com os homens, por natural inclinação
reprimimos a quem se insurge contra nós.
Ora, como é manifesto, tudo o que está contido numa certa ordem se unifica, de algum modo, em
dependência do princípio da ordem. Por onde e conseqüentemente, o que se insurge contra uma ordem
determinada será reprimido por ela e por quem é o seu princípio. Ora, sendo o pecado um ato
desordenado, é manifesto que quem peca age contra uma determinada ordem. Por onde é conseqüente
seja reprimido por ela própria. E essa repressão constitui uma pena. Por isso, o homem pode ser punido
por uma tríplice pena, relativa à tríplice ordem a que está sujeita a vontade humana.Pois
primeiramente, a natureza humana está sujeita à ordem da própria razão; depois, à de quem nos
governa as ações externas, espiritual ou temporalmente, política ou domesticamente; em terceiro lugar,
à ordem universal do governo divino. Ora, qualquer destas ordens fica pervertida pelo pecado, porque o
pecador encontra a razão, a lei humana e a divina. Daí o incorrer em tríplice pena: a proveniente de si
mesmo, que é o remorso da consciência; a outra, proveniente do homem; e, a terceira, de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A pena é consecutiva ao pecado, enquanto este é um
mal em razão da sua desordem. Por onde, assim como o mal é acidental, no ato do pecador, estando-lhe
fora da intenção, assim também o reato da pena.

RESPOSTA À SEGUNDA. — Uma pena justa pode ser infligida tanto por Deus como pelo homem; por
isso, a pena não é um efeito do pecado, diretamente, mas só dispositivamente. Ora, o pecado torna o
homem réu da pena, que é um mal; pois, como diz Dionísio, mal é, não o ser punido, mas tornar-se
digno de pena. Por isso, o reato da pena é, diretamente considerado, efeito do pecado.

RESPOSTA À TERCEIRA. — Essa pena da alma desordenada é devida ao pecado por perverter ele a
ordem da razão. Mas também se torna réu de outra pena, por perverter a ordem da lei divina ou
humana.

## Art. 2 — Se um pecado pode ser pena de outro.
(I Sent., dist. XLVI, a. 2, ad 4; II, dist. XXXVI, a. 3; De Malo, q. 1, a. 4, ad 1 sqq. ; Ad Rom., cap. I, lect. VII).
O segundo discute-se assim. — Parece que um pecado não pode ser pena de outro.

1. — Pois, as penas são infligidas para reduzirem o homem ao bem da virtude, como está claro no
Filósofo. Ora, pelo pecado ele não é levado a esse bem, mas, ao oposto. Logo, um pecado não pode ser
pena de outro.

2. Demais. — As penas justas provêm de Deus, como claramente o diz Agostinho. Ora, o pecado não
provém de Deus e é injusto. Logo, um pecado não pode ser a pena de outro.

3. Demais. — É da essência da pena contrariar a vontade. Ora, o pecado procede da vontade, como do
sobredito resulta (q. 74, a. 1, 2). Logo, um pecado não pode ser a pena de outro.
Mas, em contrário, diz Gregório, que certos pecados são a pena do pecado.

SOLUÇÃO. — Podemos considerar o pecado à dupla luz: essencial e acidentalmente. — Ora,
essencialmente de nenhum modo um pecado pode ser pena de outro. Pois, considerado na sua
essência, o pecado procede da vontade, implicando por isso a culpa. Ora, é da essência da pena ser
contrária à vontade, como já vimos na Primeira Parte (q. 48, a. 5). Por onde é manifesto, que um
pecado, considerado na sua essência, não pode ser pena de outro.
Pode-o porém, e de três modos, considerados acidentalmente. — Primeiro, em relação à causa
removente do obstáculo. Pois, as paixões, a tentação do diabo e causas semelhantes inclinam ao
pecado; e essas causas são eliminadas pelo auxílio da graça divina, de que o pecado priva. Por onde,
como a privação mesma da graça é uma pena, segundo já provamos (q. 79, a. 3), resulta que,
acidentalmente, também o pecado consecutivo a essa privação é denominado pena. E nesse sentido o
Apóstolo diz (Rm 1, 24): Pelo que os entregou Deus aos desejos dos seus corações, que são as paixões
da alma; pois, abandonados do auxílio da graça divina, os homens são vencidos pelas paixões. E deste
modo dizemos, que sempre um pecado é pena do pecado precedente. — De outra maneira, em relação
à substância do ato, causa da opressão; seja um ato interior, como claramente o demonstram a ira e a
inveja; seja exterior, como com clareza o mostram os oprimidos de veemente fadiga e dano, ao
praticarem o ato pecaminoso, conforme aquilo da Escritura (Sb 5, 7): Nós nos cansamos no caminho da
iniqüidade. — De um terceiro modo, relativamente ao efeito, considerando-se então um pecado como
pena, em relação ao efeito conseqüente. — Mas, destes dois últimos modos um pecado é pena, não só
do pecado precedente, mas também de si mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O mesmo ser punido por Deus, quando permite caiamos
em certos pecados, encaminha-se para o bem da virtude. E às vezes mesmo para o bem dos pecadores,
fazendo-os se levantarem mais humildes e cautos, depois do pecado. Sempre porém para a emenda dos
outros que, vendo certos se precipitarem de pecado em pecado, concebem maior temor de pecar.
Quanto aos outros dois modos, é manifesto que a pena se ordena à emenda; pois, é natural que os
homens se afastem do pecado por sofrerem detrimento e pena pecando.

RESPOSTA À SEGUNDA. — A objeção colhe no atinente ao pecado, essencialmente considerado.
E o mesmo se deve RESPONDER À TERCEIRA OBJEÇÃO.

## Art. 3 — Se algum pecado implica o reato da pena eterna.
(III, q. 86, 8. 4; Sent., dist. XLII, q. 1, a. 5; IV, dist. XXI. q. 1, a 2, qª 3; dist. XLVI, q. 1, a. 3; III Cont. Gent.,
cap. CXLIII ; De Malo, q. 7. a. 10; Compend. Theol., cap. CLXXXIII ; In Matth., cap. XXV; Ad Rom., cap. II,
lect. II).
O terceiro discute-se assim. — Parece que nenhum pecado implica o reato da pena eterna.

1. — Pois, a pena justa é adequada à culpa, por ser a justiça uma igualdade; donde o dizer a Escritura (Is
27, 8): tu a julgarás contrapondo uma medida a outra medida. Ora, o pecado é transitório. Logo, não
implica o reato da pena eterna.

2. Demais. — As penas servem de remédios, como diz Aristóteles. Ora, nenhum remédio deve ser
infinito, pois todos se ordenam para um fim; e o que se ordena a um fim não é infinito, como diz o
Filósofo. Logo, nenhuma pena deve ser infinita.

3. Demais. — Ninguém faz nada senão com o fito de comprazer-se com o que faz. Ora, Deus não se
compraz com a perdição dos homens, como diz a Escritura (Sb 1, 13). Logo, não os punirá com pena
sempiterna.

4. Demais. — Nada do que é acidental é infinito. Ora, a pena é acidental, pois não é conforme à natureza
do punido. Logo, não pode durar infinitamente.
Mas, em contrário, diz a Escritura (Mt 25, 46): Estes irão para o suplício eterno. E ainda (Mc 3, 29): Mas o
que blasfemar contra o Espírito Santo nunca jamais terá perdão, mas será réu de eterno delito.

SOLUÇÃO. — Como já dissemos (a. 1), o pecado implica o reato da pena por perverter uma determinada
ordem. Ora, permanecendo a causa, permanece o efeito. Portanto, enquanto subsistir a perversão da
ordem, há de necessariamente subsistir o reato da pena. Ora, a perversão da ordem é, umas vezes,
reparável e, outras, irreparável. Assim, a prevaricação, que elimina o princípio, é irreparável; se porém o
princípio ficar salvo, poderá, por sua virtude, ser reparada a prevaricação. Do mesmo modo que,
corrupto o princípio da vista, não pode ser recuperada a visão senão pela só virtude divina; se porém,
salvo o princípio da vista, sobrevierem certos obstáculos à visão, esses podem ser eliminados pela
natureza ou pela arte. Ora, toda ordem tem um certo princípio, pelo qual alguém vem a ser participante
dela. Por onde, se pelo pecado se corromper o princípio da ordem pelo qual a vontade do homem está
sujeita a Deus, haverá desordem, em si mesma, irreparável, embora possa ser reparada pelo poder
divino. E como o princípio desta ordem é o fim último, a que o homem adere pela caridade, todos os
pecados que afastam de Deus, privando da caridade, em si mesmos implicam o reato da pena eterna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A pena é, pelo que tem de acerbo, proporcionada ao
pecado, tanto no juízo divino como no humano, conforme Agostinho. Mas não exige nenhum juízo seja
a pena, na sua duração, adequada à culpa. Assim não é por ter sido um adultério ou um homicídio
cometido num momento, que há de ser punido com pena momentânea. Mas poderá sê-lo, com cárcere
perpétuo ou com o exílio; ou, mesmo com a morte, em que se considera a duração da execução, mas
antes, a eliminação perpétua, da sociedade dos vivos, representando assim, a seu modo, a eternidade
da pena infligida por Deus. Ora, é justo, segundo Gregório, que quem pelo que tem de eterno, pecou
contra Deus seja punido na eternidade de Deus. E diz-se que alguém pecou pelo que tem de eterno, não
só quanto à continuação do ato, a perdurar durante toda a vida, mas também porque quem constituiu
como fim o pecado tem a vontade de pecar eternamente. E por isso, diz Gregório, os maus quereriam
viver sem fim para poderem sem fim permanecer na iniqüidade.

RESPOSTA À SEGUNDA. — Mesmo a pena infligida pelas leis humanas nem sempre é para a correção do
punido, mas sim, dos outros. Assim, o ladrão é enforcado, não para emendar-se, mas para os outros se
absterem de pecar, ao menos pelo temor da pena, conforme aquilo da Escritura (Pr 19, 25): Castigado o
pestilento, faz-se-á mais sábio o insensato. Assim também as penas eternas dos réprobos, infligidas por
Deus, são corretivas para os que, considerando nelas, se abstêm do pecado, conforme aquilo ainda da
Escritura (Sl 59, 6): Destes aos que te temem um sinal, para que fugissem da face do arco, e que se
livrassem os teus amados.

RESPOSTA À TERCEIRA. — Deus não se compraz com as penas em si mesmas; mas, em ordem à sua
justiça, que as exige.

RESPOSTA À QUARTA. — Embora acidentalmente, a pena se ordene à natureza, em si mesma contudo
se ordena à privação da ordem e à justiça de Deus. Por isso, enquanto perdurar a desordem, sempre há
de perdurar a pena.

## Art. 4 — Se ao pecado é devida uma pena quantitativamente infinita.
(II Sent., dist. XLII, a. 1, a. 5, ad 2; IV, dist. XLVI, q. 1, a. 3).
O quarto discute-se assim. — Parece que ao pecado é devida uma pena quantitativamente infinita.

1. — Pois, diz a Escritura (Jr 10, 24): Castiga-me, Senhor; porém seja isto segundo o teu juízo, e não no
teu furor, para que não suceda que tu me reduzas a um nada. E a ira ou o furor de Deus significa
metaforicamente a vindicta da justiça divina. Ora, ser reduzido ao nada é uma pena infinita, assim como
é próprio de um poder infinito fazer uma coisa do nada. Logo, pela vindicta divina, o pecado é punido
com pena infinita, quantitativamente.

2. Demais. — À quantidade da culpa corresponde à da pena, segundo a Escritura (Dt 25, 2): O número
dos golpes regular-se-á pela qualidade do pecado. Ora, o pecado cometido contra Deus é infinito. Pois,
tanto mais grave é ele quanto maior é a pessoa contra quem se peca; assim, é pecado mais grave
ofender o príncipe do que um homem particular. Ora, como a grandeza de Deus é infinita, é devida uma
pena infinita ao pecado contra ele cometido.

3. Demais. — O infinito pode sê-lo em duração e em quantidade. Ora, pela duração, a pena é infinita.
Logo, também pela quantidade.
Mas, em contrário, se assim fosse, as penas de todos os pecados mortais seriam iguais, pois não pode
um infinito ser maior que outro.

SOLUÇÃO. — A pena é proporcionada ao pecado. Ora, nestes dois elementos se devem considerar: Um,
a aversão do bem imutável, que é infinito; e portanto, por este lado, o pecado é infinito. O outro é a
conversão desordenada para o bem mutável. E por aí o pecado é finito, quer por ser finito esse próprio
bem mutável, quer por ser também finita a conversão para ele, pois os atos da criatura não podem ser
infinitos. Por onde, no concernente à aversão corresponde-lhe a pena do dano, também infinita, por ser
a perda de um bem infinito, Deus. No concernente à conversão desordenada, corresponde-lhes a pena
do sentido, finita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não se coaduna com a justiça divina reduzir totalmente
ao nada o pecador; pois isso repugna à perpetuidade da pena, exigida pela divina justiça, como já
dissemos (a. 3). Mas se dizemos que é reduzido ao nada quem fica privado dos bens espirituais,
conforme aquilo (1 Cor 13, 2): se nãotiver a caridade, não sou nada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe concernente à aversão; pois, por aí, o
homem peca contra Deus.

RESPOSTA À TERCEIRA. — A duração da pena corresponde à da culpa, não certo quanto ao ato, mas
quanto àmácula, que, enquanto perdura, permanecerá o reato da pena. Mas a acerbidade da pena
corresponde à gravidade da culpa. Ora, como em si mesma, a culpa irreparável há de perdurar
perpetuamente, é-lhe devida uma pena eterna. Mas no concernente à conversão desordenada, não tem
infinidade, e portanto não lhe é devido, por aí, uma pena quantitativamente infinita.

## Art. 5 — Se todo pecado implica o reato da pena eterna.
(III, q. 86, a. 4; II Sent., dist. XLII, q. 1, a. 5; IV, dist. XLVI. q. 1, a. 3; III Cont. Gent., cap. CXLIII; De Malo, q.

VII, a. 1, ad 24; a. 10, 11; Compend. Theol., cap. CLXXXII).
O quinto discute-se assim. — Parece que todo pecado implica o reato da pena eterna.

1. — Pois, como se disse (a. 4), a pena é proporcionada à culpa. Ora, a pena eterna difere infinitamente
da temporal. Mas nenhum pecado pode diferir de outro infinitamente, porque todo pecado é ato
humano, incapaz de ser infinito. Logo, sendo a certos pecados devida uma pena eterna, como se disse
(a. 4), a nenhum é devida uma pena somente temporal.

2. Demais. — O pecado original é o menor dos pecados; donde o dizer Agostinho: a pena mais branda é
a dos punidos só pelo pecado original. Ora, ao pecado original é devida uma pena perpétua. Pois, nunca
verão o reino de Deus as crianças mortas sem batismo, com o pecado original, conforme é claro pelo
que diz o Senhor (Jo 3, 3): Não pode ver o reino de Deus senão aquele que renascer de novo. Logo, com
maior razão, será eterna a pena de todos os outros pecados.

3. Demais. — A um pecado não é devida pena maior, por coexistir com outro; pois, cada um deles
recebe a sua pena estabelecida pela justiça divina. Ora, ao pecado venial é devida uma pena eterna, se
coexistir, num condenado, com o pecado mortal, pois no inferno não pode haver perdão. Logo, ao
pecado venial é devida, absolutamente, a pena eterna. Portanto, a nenhum pecado é devida a pena
temporal.
Mas, em contrário, diz Gregório que certas culpas mais leves são perdoadas depois desta vida. Logo,
nem todos os pecados são punidos com pena eterna.

SOLUÇÃO. — Como dissemos (a. 3), o pecado causa o reato da pena eterna, enquanto repugna
irreparavelmente à ordem da justiça divina, contrariando o fim último, o princípio mesmo da ordem.
Ora, é manifesto que alguns pecados implicam certo uma desordem, por encontrarem não o fim último,
mas os meios, quebuscam mais ou menos devidamente, salva contudo a ordem para o fim último. Assim
quando, embora afeiçoado em demasia a um determinado bem temporal, o homem nem por isso quer
ofender a Deus, fazendo seja o que for contra algum preceito seu. Por onde, a tais pecados não é devida
uma pena eterna, mas temporal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os pecados não diferem infinitamente, pela conversão
ao bem mutável, em que consiste a substância do ato; mas, pela aversão de Deus. Pois certos pecados
se cometem pela aversão ao fim último; outros, por buscarem desordenadamente os meios. Ora, o fim
último difere infinitamente dos meios.

RESPOSTA À SEGUNDA. — O pecado original não merece uma pena eterna em razão da sua gravidade;
mas em razão da condição do sujeito, i. é, do homem, privado da graça, que só torna possível o perdão
da pena.
E semelhantemente se deve RESPONDER À TERCEIRA OBJEÇÃO, relativa ao pecado venial. — Pois, a
eternidade da pena não corresponde à quantidade da culpa, mas à sua irremissibilidade, como já se
disse (a. 3).

## Art. 6 — Se o reato da pena permanece depois do pecado.
(III, q. 86, a. 4; II Sent., .dist. XLII, q. 1, a. 2; Compend. Theol., cap. CLXXXI).
O sexto discute-se assim. — Parece que o reato da pena não permanece depois do pecado.

1. — Pois, removida a causa, removido fica o efeito. Ora, o pecado é a causa do reato da pena. Logo,
removido o pecado, esse reato cessa.

2. Demais. — O pecado fica delido quando o homem volta para a virtude. Ora, ao virtuoso é devida, não
a pena, mas o prêmio. Logo, removido o pecado, não permanece o reato da pena.

3. Demais. — As penas são remédios, como diz Aristóteles. Ora, a quem já está curado de uma doença
não se lhe ministra remédio. Logo, delido o pecado, não permanece o débito da pena.
Mas em contrário, diz a Escritura (2 Sm 12, 13-14): E Davi disse a Natan: Pequei contra o Senhor. E Natan
respondeu a Davi: Também o Senhor transferiu o teu pecado; não morrerás. Todavia, como tu pelo que
fizeste deste lugar a que os inimigos do Senhor blasfemem, morrerá certamente o filho que te nasceu.
Logo, Deus pune ainda a quem já lhe perdoou o pecado. E portanto, o reato da pena permanece depois
de delido o pecado.

SOLUÇÃO. — Dois elementos, podemos considerar no pecado: o ato da culpa e a mácula subseqüente.
Ora, é claro, cessado o ato do pecado, subsiste o reato, em todos os pecados atuais. Pois, o ato
pecaminoso torna o homem réu da pena, por transgredir a ordem da justiça divina, à qual só volta por
uma certa compensação penal que restabelece a igualdade da justiça. E assim, quem cedeu, com
excesso, à vontade própria, agindo contra o mandamento de Deus, sofrerá, espontaneamente ou
coagido, conforme a ordem da divina justiça, algo de contrário àquilo que quis. O que também se dá nas
injúrias de um homem para com outro, onde a igualdade da justiça é reintegrada pela compensação da
pena. Por onde é claro, cessado o ato ao pecado ou da injúria assacada, ainda permanece o débito
penal.
Se porém nos referirmos à eliminação do pecado, quanto à mácula, então é manifesto que essa mácula
não pode ser delida da alma, senão pela união dela com Deus, o afastamento de quem lhe causava
detrimento na própria pureza; e isso constitui a mácula, como já dissemos (q. 86, a. 1). Ora, o homem se
une a Deus pela vontade. Por onde, a mácula do pecado nele não pode ser delida, sem a sua vontade se
submeter à ordem da divina justiça. E isto de modo a se sujeitar espontaneamente a uma pena, em
compensação da culpa incorrida; ou então, sofrendo pacientemente a imposta por Deus. Pois, de um e
outro modo a pena exige a satisfação.
Ora, a pena satisfatória de certa maneira, é menos essencialmente pena, que consiste em contrariar a
vontade. Pois, a pena satisfatória, embora, absolutamente considerada, seja contrária à vontade, não o
é enquanto atualmente aceita; e como tal é voluntária. Por onde, absolutamente, é voluntária;
relativamente porém, involuntária, como com clareza resulta do já dito sobre o voluntário e o
involuntário (q. 6, 6). Donde devemos concluir que, delida a mácula da culpa, pode certamente subsistir
o reato, não da pena, em absoluto, mas da pena satisfatória.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como, cessado o pecado, subsiste a mácula, como
dissemos (q. 86, a. 2), assim também pode subsistir o reato. Delida porém a mácula, não subsiste o
reato, segundo a mesma acepção, como dissemos.

RESPOSTA À SEGUNDA. — O virtuoso não incorre na pena, em sentido absoluto; pode contudo incorrer
na pena satisfatória; pois também faz parte da virtude o satisfazer por termos ofendido a Deus ou aos
homens.

RESPOSTA À TERCEIRA. — Delida a mácula, está sanada a lesão do pecado, quanto à vontade. Mas
ainda é necessária a pena, para sanar as outras potências da alma, desordenadas pelo pecado
precedente; assim serão sanadas pelo que lhes é contrário. E ela também é necessária para reintegrar a
igualdade da justiça e reparar o escândalo dos outros, de modo a se edificarem pela pena os que se
escandalizaram com a culpa, como o patenteia o exemplo aduzido, de Davi.

## Art. 7 — Se toda pena tem como causa uma culpa.
(IIª-IIªª, q. 108, a. 4; III, q. 14, a. 1, ad 3; II Sent., dist. XXX, q. 1, a 2; dist. XXXVI, a. 4; IV, dist. XV, q. 1, a. 4,
qª 2, ad 3; dist. XLVI, q. 1, a. 2, qª 3 ; III Cont. Gent., cap. CXLI; De Malo, q. 1, a. 4; q. 5, a. 4; In Ioan.,
cap. IX, lect. I).
O sétimo discute-se assim. — Parece que nem toda pena tem como causa uma culpa.

1. — Pois, diz o Evangelho, do cego de nascença (Jo 9, 3): Para que nascesse cego, nem este pecou, nem
os seus pais. E semelhantemente, vemos muitas crianças, mesmo batizadas, sofrerem graves penas,
como febres, opressões dos demônios e muitas outras, apesar de, depois de batizadas, nelas não haver
pecado. E antes de batizadas, não há nelas pecado, mais que nas outras crianças, que não sofrem tais
penas. Logo, nem toda pena tem como causa o pecado.

2. Demais. — Segundo parece, a razão de prosperarem os pecadores é a mesma de serem alguns
inocentes punidos. Pois, tanto um fato como o outro freqüentemente se dão na ordem humana. Assim,
a Escritura diz, dos maus (Sl 72, 5): Não participam dos trabalhos dos homens, nem com os homens
serão flagelados; e ainda (Jó 21, 7): Os ímpios vivem, são exaltados e crescem em riquezas; e por fim
(Hab 1, 13): porque razão olhas tu para os que cometem injustiças, e te conservas em silêncio,
entretanto que o ímpio, devora os que são mais justos que ele? Logo, nem toda pena é infligida por
causa de uma culpa.

3. Demais. — De Cristo diz S. Pedro (1 Pd 2, 22): O qual não cometeu pecado, nem foi achado engano na
sua boca. E contudo, no mesmo lugar, diz que padeceu por nós. Logo, nem sempre a pena Deus a
comina por causa de alguma culpa.
Mas, em contrário, diz a Escritura (Jó 4, 7 ss): que inocente pereceu jamais? ou quando foram os frutos
destruídos? Antes bem tenho visto que os que obram iniqüidade pereceram a um sopro de Deus. E
Agostinho: toda pena é justa e infligida por causa de algum pecado.

SOLUÇÃO. — Como dissemos (a. 6), a pena pode ser considerada à dupla luz: absolutamente, e como
satisfatória. — A satisfatória é de certo modo voluntária. E como os que diferem pelo reato da pena
podem se unificar, pela vontade, na união do amor, às vezes, quem não pecou pode assumir
voluntariamente a pena, em lugar de outrem. Assim vemos, na ordem das coisas humanas, uma pessoa
assumir para si a pena devida por outra. — Se porém, considerarmos a pena absoluta e essencialmente
então sempre é relativa à culpa própria. Mas umas vezes, à culpa atual, como quando alguém é punido,
por Deus ou pelos homens, por um pecado cometido; outras, é relativa à culpa original. E isto, principal
ou conseqüentemente. Principalmente, a pena do pecado original consiste no abandono da natureza
humana a si própria, privada do auxílio da justiça original. Donde resultam todas as penalidades
procedentes da corrupção da natureza humana.
Devemos porém saber que às vezes uma imposição é penal, sem contudo, implicar de modo absoluto a
essência da pena. Pois esta é uma espécie de mal, como dissemos na Primeira Parte (q. 48, a. 5); e o mal
é a privação do bem. Ora, sendo vários os bens do homem — os da alma, os do corpo e das coisas
exteriores — pode ele, às vezes sofrer detrimento num bem menor para aumentar o maior. Assim,
quando sofre detrimento no dinheiro, pela saúde do corpo; ou em qualquer desses dois bens, pela
saúde da alma e da glória de Deus. E em tal caso, esse detrimento não lhe é ao homem um mal,
absolutamente, senão só, relativamente. E portanto, não implica, em absoluto, a essência da pena, mas
a de remédio; pois, também os médicos propinam poções austeras aos doentes, para recuperarem a
saúde. E como essas não são essencialmente penas, não dependem da culpa, como de causa, senão em
parte. Pois, o mesmo ter necessidade de remédios penais a natureza humana lhe provém da sua
corrupção, pena do pecado original. Assim, no estado de inocência, não seria necessário estimular
ninguém para adiantar na virtude, por meio de comunicações penais. Por isso, o que neste caso haja de
penal se reduz à culpa original como à causa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Esses defeitos, dos que os tem de nascença ou mesmo
das crianças, são efeitos e penas do pecado original, como dissemos (q. 85, a. 5). E subsistem mesmo
depois do batismo, pela causa já referida. E se não são iguais para todos, isso provém da diversidade da
natureza abandonada a si própria, como já estabelecemos (q. 85, a. 5 ad 1). Mas esses defeitos os
ordena a Divina Providência à salvação do homem: ou dos que sofrem, ou dos advertidos pelas penas;
ou ainda à glória de Deus.

RESPOSTA À SEGUNDA. — Os bens temporais e corpóreos são por certo bens do homem; mas
pequenos. Ao contrário, os bens espirituais são os seus grandes bens. Donde vem a dar a Divina Justiça
aos virtuosos os bens espirituais; e dos bens temporais ou dos males, dar-lhes somente o suficiente para
a virtude. Pois, como diz Dionísio, é próprio da divina justiça não enfraquecer a fortaleza dos melhores
com dons materiais. Ao contrário, aos outros, o mesmo serem galardoados com bens temporais se lhes
converte em mal espiritual. Por isso, a Escritura conclui (Sl 72, 6): Portanto os possui a soberba.

RESPOSTA À TERCEIRA. — Cristo padeceu a pena satisfatória por pecados não seus, mas nossos.

## Art. 8 — Se alguém pode ser punido pelo pecado de outrem.
(IIª-IIªª, q. 108, a. 4, ad 1; II Sent., dist. XXXIII, q. 1, a. 2; IV, dist. XLVI, q. 2, a. 2, qª 2, a. 3; De Malo, q. 4,
a. 8, ad 6, 7, 9, 12, 15; q. 5, a. 4; QuodI. XII, q. 16, a. 1, ad 1: In Ioan., cap. IX, lect. I).
O oitavo discute-se assim. — Parece que alguém pode ser punido pelo pecado de outrem.

1. — Pois, como diz a Escritura (Ex 20, 5): Eu sou o Deus zeloso, que vinga a iniqüidade dos pais nos
filhos até a terceira e quarta geração daqueles que me aborrecem. E (Mt 23, 35): Para que venha sobre
vós todo o sangue dos justos que se tem derramado sobre a terra.

2. Demais. — A justiça humana deriva da divina. Ora, a justiça humana pune às vezes os filhos, pelos
pais, como é patente no crime de lesa-majestade. Logo, também segundo a divina justiça, um pode ser
punido pelo pecado de outro.

3. Demais. — Nem se diga que o filho é punido pelo pecado do pai e não, pelo próprio, por imitar a
malícia paterna. Pois, tal não se pode dizer, mais dos filhos, que dos estranhos, punidos por pena
semelhante à daqueles cujos pecados imitam. Logo, não parece sejam os filhos punidos pelos pecados
próprios, mas antes, pelos dos pais.
Mas, em contrário, diz a Escritura (Ez 18, 20): o filho não carregará com a iniqüidade do pai.

SOLUÇÃO. — Se nos referirmos à pena satisfatória, aceita voluntariamente, pode um sofrê-la por outro,
enquanto de certo modo unificados, como já se disse (a. 7). Se porém nos referirmos à pena infligida por
causa do pecado, enquanto essencialmente pena, então cada qual só é punido pelo seu pecado, pois o
ato pecaminoso, tem cunho pessoal. — Se enfim nos referirmos à pena, como remédio, nesse caso um
pode ser punido pelo pecado de outro. Pois, como dissemos, o detrimento sofrido nos bens corpóreos,
ou mesmo no próprio corpo, são uns remédios penais ordenados à salvação da alma. Por onde, nada
impede seja alguém punido, com tais penas, pelo pecado de outrem, quer por Deus, quer pelos homens.
Tal se dá quando os filhos são punidos pelos pais e os súbditos pelo senhor, enquanto são, de algum
modo, coisas a eles pertencentes. Mas isso de modo que, se o filho ou o súbdito for participante da
culpa, esse padecimento penal sê-lo-á essencialmente, tanto em relação ao punido como aquele pelo
qual é punido. Se porém não for participante da culpa, será penal, relativamente aquele por quem é
punido; mas quanto ao punido, exercerá só o papel de remédio, e só por acidente implicará a pena, em
si mesma, se o punido tiver consentido no pecado alheio; pois, se a sofrer pacientemente, a pena se lhe
ordenará ao bem da alma.
As penas espirituais, por seu lado, não são medicinais, por o bem da alma não se ordenar a outro bem
melhor. Por isso, nesses bens ninguém sofre detrimento sem culpa própria. Por onde, como diz
Agostinho, com tais penas ninguém pode ser punido em lugar do outro; pois, a alma do filho não é nada
de pertencente ao pai. E por isso o Senhor, dando a razão disto, diz (Ez 18, 4): Todas as almas são
minhas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ambos os textos citados parece se refiram às penas
temporais ou corpóreas, enquanto os filhos pertencem aos pais e os sucessores, aos predecessores. Ou,
se forem referidos às penas espirituais, sê-lo-ão por causa da imitação da culpa; por onde, no Êxodo, se
acrescenta — daqueles que me aborrecem. E o Evangelho: Acabai vós, pois, por encher a medida de
vossos pais. Assim, os pecados dos pais são considerados como punidos nos filhos, por serem estes,
educados nos pecados daqueles, mais inclinados a pecar, quer pelo costume, quer também pelo
exemplo paterno, como que lhes obedecendo à autoridade. E também são dignos de maior pena se,
vendo as dos pais, não se corrigem. E quando o texto acrescenta — até a terceira e quarta geração — é
por terem os homens à vida prolongada a ponto de verem a terceira e a quarta geração. E assim, tanto
podem os filhos presenciar, para os imitar, os pecados dos pais, como os pais, para as sofrerem, as
penas dos filhos.

RESPOSTA À SEGUNDA. — As penas infligidas pela justiça humana a um, pelo pecado de outro, são
corporais e temporais. E são de certo modo remédios ou medicinas contra as culpas futuras, de maneira
a levar os punidos ou os outros a se coibirem de culpas semelhantes.

RESPOSTA À TERCEIRA. — Consideram-se os pais mais que os estranhos, como punidos pelos pecados
alheios. E isso porque as penas dos pais redundam, de certo modo, nos que pecaram, como já se disse;
por ser o filho algo do pai; quer também porque os exemplos e as penas domésticas movem mais. Por
onde, quem foi educado nos pecados dos pais, os imitará mais veementemente; e ficará mais obstinado,
se não se amedrontar pelas penas por aqueles sofridas; por isso é digno de maior pena.