# Questão 89: Do pecado venial em si mesmo.
Em seguida devemos tratar do pecado venial em si mesmo. E nesta questão discutem-se seis artigos:

## Art. 1 — Se o pecado venial causa mácula na alma.
(III, q. 87, a. 2, ad3; IV Sent., dist. XVI, q. 2, a. 1, qª 2, ad3; a. 2, qª 1, ad 1).
O primeiro discute-se assim. — Parece que o pecado venial causa mácula na alma.

1. — Pois, diz Agostinho, que os pecados veniais, quando multiplicados, exterminam de tal modo a
nossa beleza, que nos privam dos amplexos do esposo celeste. Ora, a mácula não é mais do que um
detrimento da beleza. Logo, os pecados veniais causam mácula na alma.

2. Demais. — O pecado mortal causa mácula na alma pela desordem no ato e no afeto do pecador. Ora,
o pecado venial é uma desordem no ato e no afeto. Logo, causa mácula na alma.

3. Demais. — A mácula da alma é causada pelo apegar-se a um objeto temporal, com amor, como se
disse (q. 86, a. 1). Ora, pelo pecado venial a alma se apega com amor desordenado a um objeto
temporal. Logo, o pecado causa mácula na alma. Mas, em contrário, diz a Escritura (Ef 5, 27): Para a
apresentar a si mesmo Igreja gloriosa, sem mácula, nem ruga,. i. é, comenta a Glosa, sem qualquer
pecado criminal. Logo, parece ser próprio do pecado mortal o causar mácula na alma.

SOLUÇÃO. — Como do sobredito se colhe (q. 86, a. 1), a mácula implica detrimento na beleza, prove-
niente de algum contato. Isso bem o vemos nas coisas corpóreas, por semelhança com as quais se
transferiu para a alma o nome de mácula. Ora, dupla é a beleza do corpo — a proveniente da disposição
intrínseca dos membros e da cor, e a do esplendor externo que se lhe acrescenta. O mesmo se dá com a
alma: uma é a sua beleza habitual, quase intrínseca; outra, a atual, um quase fulgor externo. Ora, o
pecado venial macula certo a beleza atual, mas não a habitual, por não excluir nem diminuir o hábito da
caridade e das outras virtudes, como a seguir se dirá (IIa IIae q. 24, a. 10; q. 133, a. 1 ad 2), mas por lhes
só impedir o ato. E sendo a mácula algo de aderente ao ser maculado, conclui-se que ela implica
detrimento, antes da beleza habitual, que da atual. Por onde, em sentido próprio, o pecado venial não
causa mácula na alma. E só em certo sentido se pode dizer que a causa, por empanar o esplendor
resultante dos atos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho se refere ao caso de muitos pecados veniais
levarem, dispositivamente, ao mortal; pois do contrário, não poderiam impedir o amplexo do esposo
celeste.

RESPOSTA À SEGUNDA. — A desordem do ato pecaminoso mortal, corrompe o hábito da virtude; não
porém a do pecado venial.

RESPOSTA À TERCEIRA. — Pelo pecado mortal a alma busca com amor e como fim um bem temporal. E
por isto totalmente perde o influxo do esplendor da graça, que desce sobre os unidos pela caridade,
com Deus, como fim último. Ora pelo pecado venial o homem não se une a nenhuma criatura como ao
fim último. Portanto, a comparação não colhe.

## Art. 2 — Se os pecados veniais são designados convenientemente pela madeira, pelo feno e pela palha.
(IV Sent., dist. XXI. q. 1, a. 2, qª 1, 2; dist. XLVI, q. 2, a. 3, qª 3, ad 3; I Cor., cap. III, lect. II).
O segundo discute-se assim. — Parece que os pecados veniais se designam inconvenientemente pela
madeira, pelo feno e pela palha.

1. — Pois, edifícios de madeira, de feno e palha se dizem levantados sobre um fundamento espiritual.
Ora, os pecados veniais estão fora do edifício espiritual, assim como quaisquer falsas opiniões não
constituem ciência. Logo, os pecados veniais não são convenientemente designados pela madeira, pelo
feno e pela palha.

2. Demais. — Quem edifica com madeira, feno e palha, será salvo como por intervenção do fogo (1 Cor
3, 15). Ora, às vezes, quem comete pecados veniais não será salvo, mesmo pelo fogo. Tal o caso de
quem morre em estado de pecado mortal e venial. Logo, os pecados veniais são designados
inconvenientemente pela madeira, pelo feno e pela palha.

3. Demais. — Segundo o Apóstolo (1 Cor 3, 12), uns edificam edifícios de ouro, de prata e de pedras
preciosas, i. é, agem levados pelo amor de Deus, do próximo e pela boas obras; outros jazem edifícios de
madeira, de feno e de palha. Ora, pecados veniais os cometem mesmo os que amam a Deus e ao
próximo, e fazem boas obras. Pois, a Escritura o diz (1 Jo 1, 8): Se dissermos que estamos sem pecado,
nós mesmos nos enganamos. Logo, essa tríplice designação não convém aos pecados veniais.

4. Demais. — Os graus e as diferenças dos pecados veniais são muito mais de três. Logo, é inconveniente
reduzi-los às três classes supramencionadas.
Mas, em contrário, o Apóstolo diz (1 Cor 3, 15), que quem levanta sobre o fundamento edifício de
madeira, de feno e de palha será salvo como por intervenção do fogo, sofrendo então pena, embora
não eterna. Ora, o reato da pena temporal propriamente pertence ao pecado venial, como se disse (q.
87, a. 5). Logo, aquela tríplice distinção designa os pecados veniais.

SOLUÇÃO. — Alguns entenderam por fundamento a fé informe, sobre a qual certos edificam as boas
obras figuradas pelo ouro, pela prata e pelas pedras preciosas. Outros porém, os pecados, mesmo
mortais, figurados pela madeira, pelo feno e pela palha. — Mas, Agostinho refuta esta exposição,
dizendo: segundo o Apóstolo (Gl 5, 21), quem pratica as obras da carne não possuirá o reino de Deus, i.
é, não se salvará. Ora, o mesmo Apóstolo diz que quem levanta edifício de madeira, feno e palha, será
salvo como por intervenção do fogo. Logo, não se podem considerar a madeira, o feno e a palha como
designando os pecados mortais.
Outros então dizem que a madeira, o feno e a palha significam as boas obras, apoiadas certo nos
fundamentos do edifício espiritual, mas vão de mistura com elas pecados veniais. Assim, se cuidando
alguém dos seus interesses de família, se deixa levar do amor exagerado da esposa, dos filhos ou dos
bens, embora com subordinação a Deus, de modo a não ter nenhuma vontade de praticar nenhum ato
contra Ele. — Mas, esta interpretação também não é aceitável. Pois, como é manifesto, todas as boas
obras se referem à caridade para com Deus e o próximo, sendo por isso designadas pelo ouro, pela
prata e pelas pedras preciosas, e não pela madeira, pelo feno e pela palha.
Por onde, devemos pensar que os pecados veniais, que se imiscuem nas obras dos que buscam os bens
terrenos, são os designados pela madeira, pelo feno e pela palha. Pois, assim como estes elementos
agregam-se à casa, sem constituírem a substância do edifício, e podem queimar-se, permanecendo este;
assim também os pecados veniais podem multiplicar-se no homem, permanecendo o edifício espiritual.
E por causa deles o pecador sofre a pena do fogo, quer das tribulações temporais desta vida, quer,
depois desta, a do fogo do purgatório. E contudo consegue a salvação eterna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os pecados veniais se os consideramos como apoiados,
não quase diretamente, sobre um fundamento espiritual, mas, ao lado dele, conforme aquilo da
Escritura (Sl 136, 1). —Junto dos rios de Babilônia — i. é, ao lado. Porque, como dissemos, os pecados
veniais não destroem o edifício espiritual.

RESPOSTA À SEGUNDA. — Não se diz de qualquer que levante edifício de madeira, feno e palha, que
será salvo como por intervenção do fogo, mas só de quem edificar sobre o fundamento. E este não é a
fé informe, como certos pensaram, mas a fé informada pela caridade, conforme aquilo (Ef 3,
17): arraigados e fundados em caridade. Portanto, quem morreu em estado de pecado mortal e de
venial edificou certamente com a madeira, o feno e a palha, mas sem apoiar o edifício num fundamento
espiritual. E por conseguinte, não será salvo como por intervenção do fogo.

RESPOSTA À TERCEIRA. — Os que abandonaram o cuidado das coisas temporais, embora às vezes
pequem venialmente, cometem contudo pecados veniais leves, e frequentissimamente se purificam
pelo fervor da caridade. Por isso, esses tais não levantam sobre o fundamento um edifício de pecados
veniais, por pouco perdurarem neles. Ao contrário, os pecados veniais dos entregues às coisas terrenas
permanecem mais tempo, por não poderem tão freqüentemente recorrer ao perdão desses pecados,
pelo fervor da caridade.

RESPOSTA À QUARTA. — Como diz o Filósofo, todas as coisas se incluem nesta tríplice distinção: o
princípio, o meio e o fim. E deste modo todos os graus dos pecados veniais se reduzem a estas três
coisas: à madeira, que suporta longamente o fogo; à palha, que se consome muito ràpidamente; e ao
feno, que fica num meio termo. Pois, conforme os pecados veniais têm mais ou menos aderência e
gravidade, assim são expurgados pelo fogo mais rápida ou mais demoradamente.

## Art. 3 — Se o homem, no estado de inocência, podia pecar venialmente.
(II Sent., dest. XXI, q. 2, a. 3; De Malo, q. 2, a. 8, ad 1; q. 7, a. 7. a. 3. ad 13; a. 7).
O terceiro discute-se assim. — Parece que o homem, no estado de inocência podia pecar venialmente.

1. — Pois, àquilo da Escritura (1 Tm 2, 14) — Adão não foi seduzido — diz a Glosa: Inexperiente da divina
severidade podia ter-se enganado, de modo a crer que cometera um pecado venial. Ora, tal não teria
crido se não pudesse pecar venialmente, sem pecar mortalmente.

2. Demais. — Agostinho diz: Não se deve pensar que o tentador teria feito cair o homem, se já não lhe
existisse na alma um certo orgulho, que devia ser reprimido. Ora, esse orgulho precedente à queda,
efetivada pelo pecado mortal, não poderia ser senão pecado venial. E semelhantemente, no mesmo
lugar, Agostinho diz, um certo desejo de experimentar solicitou o homem, quando viu a mulher comer
do pomo vedado, sem morrer. Ora, Eva cedeu a um movimento de infidelidade, por ter posto em dúvida
a palavra de Deus, como o demonstra o seu dito (Gn 3, 3) — não suceda que morramos, que se lê na
Escritura. E tudo isso constitui pecados veniais. Logo, o homem podia pecar venialmente, antes de tê-lo
feito mortalmente.

3. Demais. — O pecado mortal se opunha, mais que o venial, à integridade do estado primitivo. Ora, não
obstante essa integridade, o homem podia pecar mortalmente. Logo, também venialmente.
Mas, em contrário, a todo pecado é devida uma pena. Ora, no estado de inocência, nenhuma pena
podia ser cabível, como diz Agostinho. Logo, não podia o homem cometer nenhum pecado que não o
lançasse fora desse estado de integridade. E como o pecado venial não lhe mudava o estado, não podia
pecar venialmente.

SOLUÇÃO. — Conforme a opinião comum, no estado de inocência o homem não podia pecar
venialmente. Mas, isto não se deve entender como se o pecado, para nós venial, lhe fosse mortal, se o
cometesse, dada a dignidade do seu estado. Pois, a dignidade de uma pessoa é circunstância agravante
do seu pecado. Mas não lhe muda a espécie, salvo se sobrevier a deformidade da desobediência
proveniente de um voto ou de coisa semelhante, o que, no caso vertente, não tem cabida. Por onde,
não por causa da dignidade primitiva é que o pecado, em si mesmo, venial, deixaria de transformar-se
em mortal. E portanto, devemos concluir, que Adão não podia pecar venialmente, por não poder come-
ter nenhum pecado, em si mesmo, venial, antes de, pecando mortalmente, ter perdido a integridade do
estado primitivo.
E a razão é que nós podemos pecar venialmente, ou por imperfeição do ato, como é o caso dos
movimentos súbitos, no gênero dos pecados mortais; ou pela desordem relativa aos meios, conservada
a ordenação devida para o fim. Ora, ambos os casos implicam uma certa falta de ordem, por não estar
firmemente contido no superior o inferior. Pois, se surgem em nós movimentos súbitos de sensualidade
é por esta não se submeter completamente à razão. Se, em a nossa própria razão surgem movimentos
súbitos, é pela execução do ato da mesma não se sujeitar à deliberação, que se inspira num bem mais
elevado, como se disse (q. 74, a. 10). Que, por fim, a alma humana se desordene, quanto aos meios,
conservando a ordenação devida para o fim, isso provém de não se ordenarem aqueles infalivelmente a
este, que ocupa o primeiro lugar, sendo quase o princípio, na ordem dos desejos, como dissemos (q. 10,
a. 1, a. 2 ad 3; q. 72, a. 5). Ora, no estado de inocência, conforme estabelecemos na Primeira Parte (q.
95, a. 1), era infalível a firmeza da ordem, de modo a sempre o inferior estar contido no superior,
enquanto a parte do homem mais elevada estivesse submetida a Deus, como também o diz Agostinho.
Logo e necessariamente, não haveria desordem no homem senão deixando de submeter-se a Deus o
que ele tem de mais elevado; e tal se dá pelo pecado mortal. Por onde é claro que, no estado de
inocência, o homem não poderia pecar venialmente, antes de havê-lo feito mortalmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No lugar aduzido venial não é tomado no sentido em
que agora o tomamos, senão no sentido do que é facilmente remissível.

RESPOSTA À SEGUNDA. — Esse orgulho precedente, na alma do homem, foi o seu primeiro pecado
mortal; e é considerado como precedente à queda no ato exterior do pecado. Pois, a esse orgulho se lhe
seguiu o desejo de experimentar, e, na mulher, a dúvida. Pois, esta encheu-se logo de um certo orgulho,
só por ter ouvido, da serpente, a menção do preceito, e como já não querendo se lhe submeter.

RESPOSTA À TERCEIRA. — O pecado mortal se opunha à integridade do estado primitivo, na medida em
que lhe era possível corrompê-lo; o que não podia fazer o pecado venial. E como qualquer desordem era
incompatível com a integridade desse estado, conseqüentemente, o primeiro homem não poderia pecar
venialmente antes de ter cometido pecado mortal.

## Art. 4 — Se um anjo bom ou mal pode pecar venialmente.
(De Malo, q. 7, a. 9).
O quarto discute-se assim. — Parece que um anjo bom ou mal pode pecar venialmente.

1. — Pois, o homem tem de comum com o anjo a parte superior da alma, chamada inteligência,
conforme aquilo de Gregório: O homem intelige, como os anjos. Ora, pela parte superior da alma o
homem pode pecar venialmente. Logo, também o anjo

2. Demais. — Quem pode o mais pode o menos. Ora, o anjo podia amar o bem criado, mais que a Deus;
e isso o fez, pecando mortalmente. Logo, também podia amar o bem criado, desordenadamente,
embora menos que a Deus, pecando venialmente.

3. Demais. — Os anjos maus podem cometer certos pecados, genericamente veniais provocando o riso
dos homens, e fazendo leviandades semelhantes. Ora, como se disse (a. 3), a circunstância pessoal não
torna mortal o pecado venial, a menos de uma proibição especial sobreveniente, o que não se dá no
caso vertente. Logo, o anjo pode pecar venialmente.
Mas, em contrário, maior era a perfeição do anjo que a do homem, no estado primitivo. Ora, neste
estado, o homem não podia pecar venialmente. Logo, com maior razão nem o anjo.

SOLUÇÃO. — Como já dissemos na Primeira parte (q. 58, a. 3; q. 79, a. 8), o intelecto do anjo não é
discursivo, de modo a proceder dos princípios para as conclusões, inteligindo aqueles e estas,
separadamente, como nós. Por onde, sempre que consideram as conclusões, necessariamente as
consideram como incluídas nos princípios. Ora, na ordem do nosso desejo, como já muitas vezes
dissemos (q. 8, a. 2; q. 10, a. 1; q. 72, a. 5), os fins são como que os princípios, e os meios, as conclusões.
Por onde, a mente angélica não escolhe os meios, senão enquanto compreendidos na ordem do fim. Por
isso e por natureza, não pode haver nos anjos desordem relativa aos meios, sem haver
simultaneamente a relativa ao fim, o que se dá pelo pecado mortal. Ora, os bons anjos não buscam os
meios senão em ordem ao fim devido, que é Deus; e por isso, todos os seus atos são atos de caridade, e
portanto, não pode haver neles pecado venial. Ao contrário, os anjos maus a nada se movem senão em
ordem ao fim do pecado da própria soberba. Por isso, em tudo o que fazem por vontade própria pecam
mortalmente. Mas o mesmo não se dá com o desejo do bem natural, que neles existe, como
demonstramos na Primeira Parte (q. 63, a. 4; q. 64, a. 2 ad 5).

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem tem certo de comum com os anjos a mente
ou intelecto; mas deles difere no modo de inteligir, como dissemos.

RESPOSTA À SEGUNDA. — O anjo não podia amar a criatura menos que a Deus, senão simultaneamente
referindo-a a Deus como ao último fim; ou a algum fim desordenado, pela razão já dada.

RESPOSTA À TERCEIRA. — Todos esses pecados considerados como veniais os demônios os provocam
para atrair os homens à sua familiaridade, e assim fazê-los cair em pecado mortal. Por isso, sempre que
provocam a tais pecados pecam mortalmente, por causa da intenção final.

## Art. 5 — Se os movimentos primeiros da sensualidade, nos infiéis, são pecados mortais.
(De Malo, q. 7, a. 3; ad 17, a. 8; Quodl. IV, q. 11, a. 2; Ad. Rom., cap. VIII, lect. 1).
O quinto discute-se assim. — Parece que os movimentos primeiros da sensualidade, nos infiéis, são
pecados mortais.

1. — Pois, como diz o Apóstolo (Rm 8, 1), nada de condenação tem os que estão em Jesus Cristo, os
quais não andam segundo a carne; referindo-se a concupiscência da sensualidade, como se colhe do que
antes disse (Rm 7). Por onde, estarem em Jesus Cristo é a causa de não ser condenável a concupiscência
dos que não andam segundo a carne, i. e, consentindo naquela. Ora, os infiéis não estão em Jesus Cristo.
Logo, a concupiscência neles é condenável e portanto os primeiros movimentos da sensualidade são-
lhes pecados mortais.

2. Demais. — Anselmo diz: Os que não estão em Cristo, sentindo o estímulo da carne, correm para a
condenação, mesmo que não andem segundo a carne. Ora, só o pecado mortal é merecedor de
condenação. Logo, como o homem sente a carne pelo movimento primeiro da concupiscência, resulta
que o primeiro movimento desta é, nos infiéis, pecado mortal.

3. Demais. — Anselmo diz: O homem foi feito de modo a não dever sentir a concupiscência. Ora, essa
condição devida lhe é restaurada pela graça batismal, que os infiéis não têm. Logo, sempre que um infiel
sente a concupiscência, mesmo sem consentir nela, peca mortalmente, agindo contra a condição em
que deveria estar.
Mas, em contrário, diz a Escritura (At 10, 34): Deus não faz acepção de pessoas. Logo, o que não imputa
a um por pecado também não imputa a outro. Ora, não imputa aos fiéis para, condená-los, os
movimentos primeiros da sensualidade; logo, nem aos infiéis.

SOLUÇÃO. — É irracional dizer que os movimentos primeiros da sensualidade, nos infiéis, sejam
pecados mortais, se neles não consentirem. O que de dois modos se patenteia. — Primeiro, porque em
si mesma a sensualidade não pode ser sujeito do pecado mortal como estabelecemos (q. 79, a. 4). Ora, a
natureza dela é a mesma, tanto nos infiéis, como nos fiéis. Por onde, o só movimento da sensualidade,
nos infiéis, não pode ser pecado mortal. — Em segundo lugar, o mesmo resulta do estado do próprio
pecador. Pois, nunca a dignidade da pessoa diminui o pecado; antes, o aumenta, como do sobredito se
colhe (q. 73, a. 10). Por onde, longe de ser o pecado menor, no fiel, que no infiel, é muito maior. Porque
os pecados dos infiéis merecem muito mais perdão, por causa da ignorância, conforme aquilo da Escri-
tura (1 Tm 1, 13): alcancei a misericórdia de Deus, porque o fiz por ignorância na incredulidade. E os
pecados se agravam pelos sacramentos da graça, segundo aquilo (Heb 10, 29): quanto maiores
tormentos credes vós que merece o que tiver em conta de profano o sangue do Testamento em que foi
santificado?

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Apóstolo se refere à condenação devida ao pecado
original, de que se livra pela graça de Jesus Cristo, embora permaneça o foco da concupiscência. Por
onde, o estarem os fiéis sujeitos a esta não lhes é sinal da condenação do pecado original, como o é nos
infiéis. E neste mesmo sentido devemos entender o lugar de Anselmo.
Donde se deduz clara a RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — Pela justiça original ao homem era natural a isenção da concupiscência. Por
onde, não é o pecado atual, mas o original, que se lhe opõe a essa isenção natural.

## Art. 6 — Se o pecado venial pode coexistir numa pessoa só com o original.
(II Sent., dist. XLII, q. 1, a. 5, ad 7; De Verit., q. 24, a. 1 , ad 2 ; De Malo, q. 5, a. 2, ad 8; q. 7, a. 10, ad 8).
Parece que o pecado venial pode coexistir numa pessoa, só com o original.

1. — Pois, a disposição precede o hábito. Ora, o pecado venial é disposição para o mortal, como se
demonstrou (q. 88, a. 3). Logo, existe, no infiel, a quem não foi perdoado o original, antes do mortal. E
portanto, podem os infiéis estar em estado de pecado venial e original, ao mesmo tempo, sem estar no
de mortal.

2. Demais. — O pecado venial tem menos conexão e conveniência com o mortal, do que um mortal,
com outro. Ora, o infiel, sujeito ao pecado original, pode cometer um pecado mortal, sem cometer
outro. Logo, também pode cometer o pecado venial sem cometer o mortal.

3. Demais. — Pode-se determinar o tempo em que a criança começa a ser capaz de praticar o pecado
atual. E chegado há esse tempo, é-lhe possível, ao menos durante algum breve espaço dele, estar sem
pecado mortal, pois isso também o é aos máximos celerados. Ora, durante esse espaço de tempo, por
breve que seja, pode pecar venialmente. Logo, é possível o pecado venial coexistir numa pessoa, com o
original, sem o mortal.
Mas, em contrario, por causa do pecado original, os homens são punidos no limbo das crianças, onde
não há pena do sentido, como a seguir se dirá (IIa IIae q. 69, a. 6). Enquanto que eles caem no inferno
por um só pecado mortal. Logo, não haverá lugar em que possa ser punido quem esteja manchado só do
pecado venial e do original.

SOLUÇÃO. — É impossível estar-se em estado de pecado venial e de original, simultaneamente, sem
estar no de mortal. E isso porque a falta de idade, que priva do uso da razão, excusa do pecado mortal
quem ainda não chegou à idade de discernimento. E portanto, com maior razão, o excusa do pecado
venial, se cometer algum que o seja genericamente. Quando porém começar a ter o uso da razão, não
ficará absolutamente excusado da culpa do pecado venial e do mortal. Ora, nessa idade, o que pri-
meiramente ocorre ao pensamento humano é deliberar sobre si mesmo. E então, se ordenar-se a si
mesmo ao fim devido, conseguirá, pela graça, a remissão do pecado original. Se porém não se ordenar
para esse fim, como está em idade capaz de discernimento, pecará mortalmente, não fazendo o que
estava em si fazer. E portanto, em tal pessoa não haverá o pecado venial sem o mortal, senão depois
que tudo lhe for perdoado pela graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pecado venial não é uma disposição precedente ao
mortal, necessária, mas contingentemente. É como o trabalho que, às vezes, dispõe para a febre, e não,
como o calor, que dispõe para a forma do fogo.

RESPOSTA À SEGUNDA. — Nada impede o pecado venial coexistir só com o original, por causa da
distância ou da conveniência entre eles; mas o que o impede é a falta do uso da razão, como se disse.

RESPOSTA À TERCEIRA. — A criança, que começa a ter o uso da razão, pode por algum tempo abster-se
de todos os pecados mortais, mas não pode livrar-se do pecado da omissão predita, sem que se
converta a Deus, o mais prontamente possível. Ora, o que primeiramente ocorre ao homem, que tem
discernimento, é o pensar sobre si mesmo, a quem, como o fim, ordena tudo o mais. Ora, o fim é o que
vem primeiro na intenção. E esse é pois o tempo em que está sujeito à obrigação, conforme o preceito
divino afirmativo, pelo qual o Senhor diz (Zc 1, 3): Convertei-vos a mim e eu me converterei a vós.
Tratado da lei
Devemos, conseqüentemente, tratar dos princípios exteriores dos atos. Ora, o princípio externo, que
inclina para o mal, é o diabo, de cuja tentação já tratamos na Primeira Parte. E o princípio externo, que
move para o bem, é Deus, que nos instrui pela lei e nos ajuda pela graça.
Por onde, devemos tratar, primeiro, da lei e, segundo, da graça.
Ora, quanto à lei, devemos considerá-la, primeiro, em geral. Segundo, nas suas partes.
E, sobre a lei, em geral, há tríplice consideração a fazer. A primeira é sobre a essência dela. A segunda,
sobre a diferença entre as leis. A terceira, sobre os efeitos da lei.