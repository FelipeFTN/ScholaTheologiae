# Questão 52: Do aumento dos hábitos.
Em seguida devemos tratar do aumento dos hábitos. E, sobre esta questão, três artigos se discutem:

## Art. 1 — Se os hábitos são susceptíveis de aumento.
(Infra, q. 66, a . 1; De Vertut., q. 1, a . 11; q. 5, a . 3; X Ethic., lect. III).
O primeiro discute-se assim. — Parece que os hábitos não podem aumentar.

1. — Pois, aumento supõe quantidade, como já se disse. Ora, os hábitos pertencem, não ao gênero da
quantidade, mas ao da qualidade. Logo, não podem receber aumento.

2. Demais — O hábito é uma perfeição, como já se disse. Ora esta, implicando um fim e um termo,
parece não ser susceptível de mais nem de menos. Logo, o hábito não pode aumentar.

3. Demais — O susceptível de mais e de menos há-de por força sofrer alteração; assim dizemos que se
altera o que, de menos, se torna mais quente. Ora, os hábitos não sofrem alteração, como já se provou.
Logo, os hábitos não podem aumentar.
Mas, em contrário, a fé é um hábito e, contudo, pode aumentar; por isso os discípulos dizem ao Senhor:
aumenta-nos a fé, como se lê no Evangelho (Lc 17, 5). Logo, os hábitos podem aumentar.

SOLUÇÃO. — O aumento, como tudo o relativo à quantidade, é transferido ao espiritual e ao intelectual,
das coisas corpóreas, por causa do conaturalidade do nosso intelecto com essas coisas, que estão ao
alcance da nossa imaginação.
Ora, dizemos que uma quantidade corpórea é grande, quando realiza a perfeição devida à quantidade;
por isso considera-se grande uma quantidade, no homem, que não se consideraria tal no elefante.
Donde vem o dizermos que uma forma é grande quando é perfeita. E como o bem implica a noção de
perfeito, em relação ao que não é materialmente grande, ser grande é o mesmo que ser melhor, como
diz Agostinho.
Ora, a perfeição da forma pode ser considerada à dupla luz: quanto à forma em si mesma, e enquanto o
sujeito dela participa. No primeiro caso podemos considerá-la pequena ou grande; p. ex., a saúde ou a
ciência grande ou pequena. No segundo, consideramo-la como susceptível de mais ou de menos; p. ex.,
mais ou menos branco ou são. Mas esta distinção não procede no sentido de ter a forma o ser
independente da matéria ou do sujeito; senão que a consideramos, de um modo, quanto à sua essência
especifica e, de outro, enquanto participada por um sujeito.
Quanto a esta doutrina, pois, são quatro as opiniões dos Filósofos, segundo refere Simplício, sobre a
intenção e a remissão dos hábitos e das formas. — Assim, Plotino e os demais Platônicos ensinavam que
as qualidades e os hábitos, em si mesmos, são susceptíveis de mais e de menos, por serem materiais e
terem por causa da infinidade da matéria, uma certa indeterminação. — Outros porém, ao contrário,
ensinavam que as qualidades e os hábitos, em si mesmos, não são susceptíveis de mais nem de menos,
mas que atribuímos às qualidades o mais e o menos, conforme a diversidade de participação; assim, não
dizemos que a justiça o é, mais ou menos, mas, sim, o justo. E a esta opinião Aristóteles alude. — A
terceira é a opinião dos Estóicos, média entre as duas supra-referidas. Diziam eles que certos hábitos,
como as artes, são em si susceptíveis de mais e de menos; outros, porém, não, como as virtudes. — A
quarta opinião é a dos que diziam que as qualidades e as formas imateriais não são susceptíveis de mais
e de menos; são-no porém as materiais.
Para estabelecermos pois a verdade das coisas, devemos considerar, que o princípio de especificação
dos seres deve necessariamente ser algo de fixo, estável e quase indivisível. E assim tudo o que ele
abrange por ele se especifica; e tudo o que dele se separa, mais ou menos, pertence a outra espécie,
mais ou menos imperfeita. Por isso, o Filósofo diz que as espécies das coisas são como os números, cuja
espécie varia pela adição ou diminuição. — Por onde, se uma forma ou qualquer outra coisa, em si
mesma por algo de seu, pertencer a uma determinada espécie, há-de necessariamente, considerada em
si mesma, realizar uma determinada essência, em relação à qual não pode ser nem excedente nem
deficiente. E tal é o calor, a brancura e qualidades semelhantes, não relativas a outras e, com maior
razão, a substância, que é ente por si mesma. — Coisas porém que se especificam por um termo para o
qual se ordenam, podem, em si mesmas, diversificar-se mais ou menos; e contudo pertencem à mesma
espécie por causa da unidade do termo a que se ordenam e que as especifica. Assim, o movimento, em
si mesmo, pode ser mais intenso ou remisso, permanecendo contudo na mesma espécie, por causa da
unidade do seu termo especificado. E o mesmo pode-se dar com a saúde; pois, o corpo se manifesta
como saudável quando tem disposições convenientes à natureza animal, que podem ser diversas e
portanto variar mais ou menos, sempre permanecendo contudo o princípio constitutivo da saúde. Por
isso, o Filósofo diz que a saúde, em si mesma, é susceptível de maior e menor grau; pois, não há a
mesma proporção em todos os seres, nem sempre, num mesmo ser; mas, mesmo diminuída,
permanece até um certo termo. Ora, essas diversas disposições ou proporções da saúde são relativas ao
excedente e ao excesso; por onde, se aplicássemos o nome de saúde só àquela que fosse dotada de
perfeito equilíbrio, então a saúde, em si mesma, não seria susceptível de maior ou menor grau. E fica
assim claro o modo por que uma qualidade ou forma pode ou não, em si mesma, aumentar ou diminuir.
Se porém levarmos em conta a qualidade ou a forma, quanto à participação do sujeito, veremos
também que umas qualidades e formas são susceptíveis de mais e de menos e outras, não. E a causa
desta diversidade Simplício descobre em que a substância, sendo um ser em si, não é por si mesma,
susceptível de mais e de menos. E portanto, toda forma participada substancialmente pelo sujeito não é
susceptível de intenção nem de remissão; e por isso no gênero da substância, nada é susceptível de mais
nem de menos. E como a quantidade é próxima da substância, da qual resulta a forma e a figura,
dizemos que também esta e aquela não são susceptíveis de mais nem de menos. Donde, segundo o
Filósofo, do que recebe a forma e a figura, nós dizemos, não que se alterou, mas, que vem a ser. Ao
passo que as outras qualidades, mais distantes da substâncias, e subordinadas à paixão e à ação, são
susceptíveis de mais e de menos, conforme a participação do sujeito.
Mas a razão desta diversidade pode ser ainda melhor explicada. Pois, como já dissemos, o princípio
especificador deve ser fixo e estável na sua indivisibilidade. Ora, de dois modos pode se dar que a forma
não seja participada mais nem menos. — Ou porque o participante contém a espécie em si mesma. Por
isso nenhuma forma substancial pode ser mais ou menos participada. Por onde, diz o Filósofo que,
como o número não é susceptível de mais nem de menos, também não o é a substância especificada, i.
é, no concernente à participação da forma específica; mas se for acompanhada da matéria, i. é, quanto
às disposições materiais, é susceptível de mais e de menos. — De outro modo, tal pode se dar se a
própria indivisibilidade for da essência da forma. Por onde, o que dela participar há-de fazê-lo na sua
essência indivisível. Donde vem que as espécies do número não as consideramos como susceptíveis de
mais nem de menos; pois, cada uma dessas espécies é constituída pela unidade indivisível. E o mesmo
se dá com as espécies da quantidade contínua, consideradas numericamente, como o que tem dois ou
três côvados; e com as relações, como o que é duplo ou triplo; e com as figuras, como o triângulo e o
quadrado. E esta razão Aristóteles a expõe quando, explicando porque as figuras não são susceptíveis de
mais nem de menos, diz: Aquilo que realiza a essência do triângulo e do círculo é triângulo ou círculo,
porque a indivisibilidade é inerente a essas essências; por onde, tudo o que delas participa há-de lhes
participar também a indivisibilidade.
Donde consta com clareza que, sendo os hábitos e as disposições assim chamados por se ordenarem a
algum termo, como diz Aristóteles, de dois modos podemos levar em conta a intenção e a remissão
deles. — Ou em si mesmos, como quando dizemos que a saúde é maior ou menor; ou que o é a ciência,
conforme tem maior ou menor extensão. — Ou de outro modo, quanto à participação do sujeito,
quando uma mesma saúde ou ciência é participada mais por um que por outro, conforme as diversas
aptidões provenientes da natureza ou do costume. Pois, o hábito e a disposição não especificam o
sujeito, nem além disso incluem, por essência, a indivisibilidade.
E quanto à relação do hábito com a virtude a seguir se dirá.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como a denominação de grandeza derivou das
quantidades corpóreas, para as perfeições inteligíveis das formas, assim também o nome de aumento,
cujo termo é o grande.

RESPOSTA À SEGUNDA. — Certamente o hábito é uma perfeição; não porém de tal natureza que seja o
termo do seu sujeito, como lhe dando o ser específico; e nem inclui na sua essência o termo, como as
espécies dos números.

RESPOSTA À TERCEIRA. — A alteração, primariamente, está nas qualidades da terceira espécie. Ela pode
porém existir nas qualidades da primeira espécie por posterioridade. Assim, produzida a alteração
relativa ao calor e ao frio, resulta a natureza animal alterada na saúde e na doença. E semelhantemente,
causada a alteração nas paixões do apetite sensitivo ou nas potências sensitivas apreensivas, segue-se à
alteração na ciência e nas virtudes, como já se disse.

## Art. 2 — Se o aumento dos hábitos se faz por adição.
(IIª-IIªe, q. 24, a . 5; De Virtut., q. 1, a . 11; q. 5, a . 3).
O segundo discute-se assim. — Parece que o aumento dos hábitos se dá por adição.

1. — Pois, o nome de aumento, como já se disse, foi transferido das quantidades corpóreas para as
formas. Ora, naquelas não há aumento sem adição, e por isso, conforme já se disse, o aumento é um
aditamento feito à grandeza preexistente. Logo, também nos hábitos o aumento só se dá pela adição.

2. Demais — O hábito não aumenta senão por meio de um agente. Ora, todo agente produz algum
efeito no sujeito paciente; assim, o agente que aquece produz o calor no corpo aquecido. Logo, não
pode haver aumento sem haver adição.

3. Demais — Assim como o que não é branco é potencial em relação ao branco; assim, o menos branco
também o é em relação ao mais branco. Mas, o que não é branco só vem a sê-lo pela superveniência da
brancura. Logo, o menos branco não se torna mais branco senão por alguma outra brancura
superveniente.
Mas, em contrário, diz o Filósofo: O corpo quente torna-se mais quente sem que um novo calor se lhe
acrescente à matéria; pois do contrário esse corpo não estaria quente quando o estava menos. Logo,
pela mesma razão, também nenhuma adição existe nas outras formas susceptíveis de aumento.

SOLUÇÃO. — A SOLUÇÃO. desta questão depende do que já dissemos antes. Pois, como já
estabelecemos, nas formas susceptíveis de intenção e de remissão, o aumento e a diminuição provêm,
de um modo, não da forma em si mesma considerada, mas das diversas participações do sujeito. Por
onde, tal aumento dos hábitos e das outras formas não se realiza pela adição de uma forma a outra,
mas porque o sujeito participa mais ou menos perfeitamente de uma e mesma forma. E assim como o
agente em ato é que torna um corpo atualmente quente, quase começando, então a participar da
forma, e não que esta comece, em si mesma, a existir, como já se provou; assim também, pela ação
intensa do agente um corpo se torna mais quente, como participando mais perfeitamente da forma, e
não como se algo a esta se acrescentasse.
Por onde, se pela adição se entendesse um aumento da forma, deste último modo, isto só poderia dar-
se por parte da forma mesma, ou por parte do sujeito. No primeiro caso, como já dissemos, tal adição,
ou subtração, variaria a espécie, como varia a espécie da cor, quando de pálida vem a ser branca. O
segundo caso não se poderia dar senão porque o sujeito recebeu uma forma que antes não tinha; assim,
se dissermos que o frio aumenta num homem que, primeiro, o sentia numa parte do corpo, e depois
veio a senti-lo em várias; ou então porque se acrescenta outro sujeito participante da mesma forma,
como se acrescentasse o quente ao que já o era, e o branco ao que já era branco. Ora, de ambos estes
modos dizemos que o corpo se tornou, não mais quente ou branco, mas maior.
Mas, como certos acidentes aumentam por si mesmos, conforme já dissemos, em certos deles o
aumento pode dar-se por adição. Assim, o movimento aumenta porque algo se lhe acrescenta, ou
quanto ao tempo em que se realiza, ou pela distância que percorre; e contudo, a espécie permanece a
mesma, por causa da unidade do termo. E também um mesmo movimento pode aumentar na sua
intensidade, em relação à participação do sujeito, podendo realizar-se mais ou menos expedita ou
prontamente. — Semelhantemente, a ciência pode, em si mesma, aumentar por adição: assim, quando
aprendemos várias conclusões da geometria, o nosso hábito dessa ciência aumenta especificamente.
Também a ciência de um sujeito, que dela participa, pode aumentar de intensidade; tal se dá quando
um homem considera certas conclusões mais expedita e claramente que outro.
Quanto aos hábitos corpóreos porém não pode dar-se grande aumento por adição, porque
consideramos completamente são ou belo o animal que o for em todas as suas partes. E é pela mutação
das qualidades simples, não susceptíveis de aumento, senão segundo a intenção, quanto ao sujeito
participante, que os hábitos podem chegar o uma compleição mais perfeita.
Mas abaixo trataremos desta questão relativamente às virtudes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A grandeza corpórea também é susceptível de duplo
aumento. Um, por adição de um sujeito a outro; tal é o caso do aumento dos seres vivos. Outro, só por
intensidade, sem nenhuma adição, como se dá com os corpos rarefeitos, segundo já se disse.

RESPOSTA À SEGUNDA. — A causa que aumenta o hábito produz sempre um efeito no sujeito, não
porém uma nova forma. Leva porém o sujeito a participar mais perfeitamente da forma preexistente, ou
a ter mais ampla extensão.

RESPOSTA À TERCEIRA. — O que ainda não é branco e que portanto ainda não tem essa forma, é, em
relação a ela, potencial; e por isso o agente causa, no sujeito, uma nova forma. O que porém é menos
quente ou branco não é potencial em relação à forma, pois a tem atualizada; mas o é em relação ao
modo perfeito de participação, o que consegue pela ação do agente.

## Art. 3 — Se qualquer ato aumenta o hábito.
O terceiro discute-se assim. — Parece que qualquer ato aumenta o hábito.

1. — Pois, multiplicada a causa, multiplicado fica o efeito. Ora, os atos são causas de certos hábitos,
como já se disse. Logo, o hábito aumenta com a multiplicação dos atos.

2. Demais — Os semelhantes são julgados pelo mesmo juízo. Ora, todos os atos procedentes do mesmo
hábito são semelhantes, como já se disse. Logo, se certos atos aumentam o hábito, qualquer ato
aumentará o mesmo.

3. Demais — O semelhante aumenta o semelhante. Ora, qualquer ato é semelhante ao hábito donde
procede. Logo, qualquer ato aumenta o hábito.
Mas, em contrário. — Os contrários não podem ter a mesma causa. Mas, como já se disse, certos atos
procedentes de um hábito o diminuem; assim p. ex. quando se fazem negligentemente. Logo, nem todo
ato aumenta o hábito.

SOLUÇÃO. — Atos semelhantes causam hábitos semelhantes, como já ficou dito. Pois, a semelhança e a
dissemelhança se fundam, não só na mesma ou em qualidade diversa, mas também no mesmo ou em
diverso modo da participação. Assim, não só o preto é dissemelhante do branco, mas também o menos
do mais branco, porque também daquele para este último se dá o mesmo movimento que o de um para
outro contrário, segundo já se estabeleceu.
Como porém da vontade humana depende o uso dos hábitos, segundo do sobredito resulta, assim como
quem tem um hábito pode não usar dele e mesmo praticar o ato que lhe é contrário; assim também
pode-se dar que use do hábito por um ato que não responda, proporcionalmente, à intensidade do
hábito. Por onde, se a intenção do ato se adequar proporcionalmente à do hábito, ou mesmo a
sobreexceder, qualquer ato ou aumentará o hábito ou contribuirá para o seu aumento; e poderemos
então falar do aumento dos hábitos por semelhança com o aumento do animal. Pois, não é um alimento
ingerido que aumenta, assim como não é uma gota que cava a pedra; mas, sim, o alimento multiplicado.
Assim também o hábito cresce por atos multiplicados. Se porém a intenção do ato for
proporcionalmente deficiente em relação à intensidade do hábito, esse ato não dispõe para o aumento,
mas antes, para a diminuição do hábito.
Donde consta com evidência a RESPOSTA ÀS OBJEÇÕES.