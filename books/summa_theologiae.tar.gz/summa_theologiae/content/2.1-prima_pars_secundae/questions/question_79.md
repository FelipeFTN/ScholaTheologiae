# Questão 79: Das causas exteriores do pecado, e primeiro por parte de Deus.
Em seguida devemos tratar das causas exteriores do pecado. E primeiro por parte de Deus. Segundo,
por parte do diabo. Terceiro, por parte do homem.
Sobre a primeira questão, discutem-se quatro artigos:

## Art. 1 — Se Deus é causa do pecado.
(I, q. 48, a. 6; q. 49, a. 2; IIª IIae, q, a, 2, ad 2; II Sent., dist. XXXIV, a. 3; dist. XXXVII, q. 2, a. 1; III Cont.
Gent., cap. CLXII; De Malo, q. 3, a. 1; Ad Rom., cap. 1, lect. VII).
O primeiro discute-se assim. — Parece ser Deus a causa do pecado.

1. — Pois, diz o Apóstolo (Rm 1): entregou-os Deus a um sentimento depravado, para que fizessem
coisas que não convêm. E a Glosa a esse lugar: Deus obra nos corações dos homens, inclinando-lhes a
vontade para o que quer, seja para o bem, seja para o mal. Ora, fazer o que não convém e inclinar a
vontade para o mal é pecado. Logo, Deus é causa de pecado do homem.

2. Demais. — A Escritura diz (Sb 14): as criaturas de Deus se transformaram em objeto de abominação, e
em motivo de tentação para as almas dos homens. Ora, costuma-se chamar à tentação provocação ao
pecado. E como as criaturas foram feitas por Deus, como se demonstrou na Primeira Parte, parece ser
Deus causa do pecado, provocando o homem a pecar.

3. Demais. — Toda causa da causa o é também do efeito. Ora, Deus é a causa do livre arbítrio, causa do
pecado. Logo, é também a causa deste último.

4. Demais. — Todo mal se opõe ao bem. Ora, não repugna à bondade divina seja Deus a causa do mal da
pena. Pois, deste mal diz a Escritura (Is 45), que Deus é quem cria o mal; e ainda pergunta (Am 3): Se
acontecerá algum mal na cidade, que Deus não fizesse. Logo, também à bondade divina não repugna
seja Deus causa da culpa.
Mas, em contrário. — A Escritura diz (Sb 11): não aborreces nada de quanto fizeste. Ora, Deus odeia o
pecado segundo a mesma Escritura. E Deus igualmente aborrece ao ímpio e à sua impiedade. Logo,
Deus não é causa do pecado.

SOLUÇÃO. — De dois modos o homem é causa do pecado, seu ou de outrem. Diretamente, inclinando a
pecar a sua vontade ou a de outrem. Indiretamente, não impedindo outros de pecarem. Por isso na
Escritura se diz ao Profeta (Ez 3): Se não disseres ao ímpio; Morrerás na tua iniqüidade, eu requererei da
tua mão o seu sangue.
Deus, porém não pode ser diretamente causa do pecado, nem seu nem de outrem. Pois todo pecado
implica afastamento da ordem existente em Deus como no fim. Ora, Deus inclina todas as coisas e fá-las
convergir para si, como para o último fim, no dizer de Dionísio. Portanto, é impossível seja, para si ou
para outrem, causa de afastamento da ordem, dele próprio dependente. Logo, não pode ser
diretamente causa do pecado.
Mas e do mesmo modo, nem indiretamente. Pois, pode não conceder a certos o auxílio para evitarem o
pecado, que não cometeriam se o concedesse. Mas tudo isso o faz segundo a ordem da sua sabedoria e
justiça, pois, ele próprio é justiça e sabedoria. Por onde, não se lhe pode imputar a causalidade do
pecado de outrem; assim como não atribuímos a um piloto a ser causa da submersão do navio, por não
o ter dirigido, salvo se lhe abandonou a direção, podendo e devendo dirigi-lo.
Portanto é claro, que Deus não é de nenhum modo causa do pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O próprio texto do Apóstolo solve a objeção. Porque, se
Deus abandona certos ao senso réprobo deles, é por já o terem eles, esse tal senso, para fazer o que
não devem. Ora, dizemos que Deus assim os abandona, pelos não impedir de seguirem o seu senso
réprobo, como dizemos que expomos os que não defendemos. E o sentido da expressão de Agostinho,
donde foi tirada a Glosa — Deus inclina as vontades dos homens para o bem e para o mal — é que ele
inclina a vontade diretamente para o bem;e para o mal, enquanto não o impede, como já se disse.
Contudo isto não se dá em razão do pecado precedente.

RESPOSTA À SEGUNDA. — Na frase — As criaturas de Deus transformaram-se em objeto de
abominação, e em motivo de tentação para as almas dos homens — a preposição em não é usada
causal, mas consecutivamente. Pois Deus não fez as criaturas para o mal dos homens, mas, pela
insipiência deles é que tal se deu. E por isso se acrescenta: e em laço para os pés dos insensatos, isto é,
dos que insipientemente usam das criaturas para um fim diferente daquele para que foram feitas.

RESPOSTA À TERCEIRA. — O efeito procedente da causa média, enquanto sujeita à influência da causa
primeira, também desta depende. Mas se proceder da causa média, enquanto esta escapa à ordem da
causa primeira, não depende da última. Assim, o ato de um ministro, contra a ordem do chefe, a este
não se lhe imputa, como à causa. E semelhantemente, o pecado que livremente cometemos contra o
preceito de Deus não se atribui a Deus como à causa.

RESPOSTA À QUARTA. — A pena se opõe ao bem do punido, privando-o assim de algum bem. Ao passo
que a culpa se opõe ao bem da ordem, que é Deus, e portanto vai contra diretamente à bondade
divina. E por isso culpa e pena não têm o mesmo fundamento.

## Art. 2 — Se Deus é causa do ato pecaminoso.
(II Sent., dist. XXXVII, q. 2, a. 2; De Malo. q. 3, a. 2).
O segundo discute-se assim. — Parece que Deus não é causa do ato pecaminoso.

1. — Pois, como diz Agostinho o ato pecaminoso não é uma realidade. Ora, Toda realidade é causada
por Deus. Logo, o ato pecaminoso não o causa Deus.

2. Demais. — Por ser causa do ato pecaminoso dizemos ser o homem causa do pecado; pois ninguém
pratica o mal intencionalmente, como diz Dionísio. Ora, Deus não é causa do pecado, segundo já se
disse. Logo, não é causa do ato pecaminoso.

3. Demais. — Certos atos são especificamente maus e pecaminosos, como do sobredito se colhe. Ora, a
causa de um efeito o é também do que a este convém especificamente. Logo, se Deus fosse causa do
ato pecaminoso, sê-lo-ia também do pecado. Ora, tal não é verdade, como já se demonstrou. Logo,
Deus não é causa do ato pecaminoso.
Mas, em contrário. — O ato do pecado é do livre arbítrio. Ora, a vontade de Deus é causa de todos os
movimentos, como diz Agostinho. Logo, a vontade de Deus é causa do ato pecaminoso.

SOLUÇÃO. — Como realidade e como ato, que é, o ato pecaminoso procede de Deus. — Pois, toda
realidade, seja de que modo for, há-de necessàriamente derivar do ser primeiro, como diz claramente
Dionísio. — Ora, toda ação só é causada por um ser atual, porque nada age senão como atual. Ora, todo
ser atual depende do ato primeiro, que é Deus, como de causa essencialmente atual. Donde se conclui o
ser Deus a causa de toda ação como tal.
Mas, pecado significa deficiência no ser e no ato; e esta procede de uma causa criada, que é o livre
arbítrio, desviado da ordem do agente primeiro, Deus. Por onde tal deficiência não se atribui a Deus
como a causa, mas ao livre arbítrio. Assim como o defeito de coxear reduz-se à tíbia curva, como à
causa, e não à virtude motora, que, contudo é causa do movimento no coxear. E a esta luz, Deus é causa
do ato do pecado, não porém do pecado, por não ser causa da deficiência do ato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No lugar aduzido Agostinho entende pela realidade a
realidade pura é simples, i. é, a substância. Ora, em tal sentido o ato pecaminoso não é uma realidade.

RESPOSTA À SEGUNDA. — Do homem, como causa, depende não só o seu ato, mas também, sua
própria deficiência, por se não sujeitar a quem devia sujeitar-se, embora não tenha principalmente essa
intenção. Logo, o homem é causa do pecado. Deus porém é causa do ato, mas de modo a não ser, de
maneira nenhuma, causa da deficiência concomitante ao ato. Logo, não é causa do pecado.

RESPOSTA À TERCEIRA. — Como dissemos, o ato e o hábito não se especificam pela privação mesma, na
qual consiste a essência do mal; mas por algum objeto conexo com essa privação. E assim, a deficiência
mesma, considerada não proveniente de Deus, pertence à espécie do ato conseqüentemente, e não
como diferença específica.

## Art. 3 — Se Deus é causa da obsecação e do endurecimento.
(I Sent., dist. XL, q. 4, a. 2; III Cont. Gent., cap. CLXII; De Verit., q. 24, a. 10; In Matth., cap., XIII; In Ioan.,
cap. XII, lect. VII; Ad Rom., cap. IX, lect. III; II Cor., cap. IV, lect. II).
O terceiro discute-se assim. — Parece não ser de Deus a causa da obsecação e do endurecimento.

1. — Pois, como diz Agostinho, Deus não é a causa de o homem ser pior. Ora, a obsecação e o
endurecimento o tornam tal. Logo, Deus não é causa daquela e deste.

2. Demais. — Fulgêncio diz, que Deus não se vinga daquilo de que é o autor. Ora, Deus se vinga do
coração endurecido, conforme a Escritura (Ecle 3): O coração duro será oprimido de males no fim da
vida. Logo, Deus não é a causa do endurecimento.

3. Demais. — Um mesmo efeito não pode ser atribuído a causas contrárias. Ora, tem-se como causa da
obsecação a malícia do homem, conforme aquilo da Escritura (Sb 2): porque à sua malícia os
cegou; e também o diabo, segundo outro lugar (2 Cor 4): o Deus deste século cegou os entendimentos
dos infiéis. Ora, todas essas são causas contrárias a Deus. Logo, Deus não é causa da obsecação nem do
endurecimento.
Mas, em contrário, diz a Escritura (Is 6): Obseca o coração deste povo e ensurdece-lhe os ouvidos; e
ainda (Rm 9): Logo ele tem misericórdia de quem quer, e ao que quer endurece.

SOLUÇÃO. — A obsecação e o endurecimento implicam dois elementos. — Um é o movimento da alma
humana, aderente ao mal e apartada da luz divina. E por aí Deus não é a causa da obsecação nem do
endurecimento, assim como não é a causa do pecado. — Outro é a subtração da graça, donde resulta
que a mente não é divinamente iluminada para apreciar com retidão, e o coração do homem não se
abranda para viver bem. E por aí Deus é causa da obsecação e do endurecimento. Devemos porém
considerar, que Deus é a causa universal da iluminação das almas, conforme aquilo da Escritura (Jo
1): Era a luz verdadeira, que ilumina a todo o homem que vem a este mundo. Assim como o sol é a
causa universal da iluminação dos corpos, mas diferentemente. Pois, ao passo que o sol atua iluminando
por necessidade de natureza, Deus age voluntariamente, segundo a ordem da sua sabedoria. Mas
embora o sol ilumine por natureza todos os corpos, encontrando obstáculo no corpo, deixá-lo-á
obscuro, como o vemos numa casa cujas janelas estejam fechadas. Contudo, dessa obscuridade o sol
não é de nenhum modo causa, pois não age a seu bel prazer, de modo a não projetar a luz no interior;
mas, só é causa dela quem fechou as janelas. Deus porém por juízo próprio, não envia o lume da graça
aqueles em quem encontra obstáculo. Por onde, causa da subtração dela é, não só quem lhe opõe
obstáculo, mas também Deus que, a seu juízo, não lhe a concede. E deste modo Deus é causa da
obsecação, do embotamento dos ouvidos e do endurecimento do coração. Pois, essas coisas se
distinguem pelos efeitos da graça que, com o dom da sabedoria aperfeiçoa o intelecto e abranda o afeto
com o fogo da caridade. Ora, como para o conhecimento do intelecto contribuem principalmente os
dois sentidos, da vista e do ouvido, dos quais aquele serve à invenção e este à instrução, por isso à vista
se opõe a obcecação; e à audição, o embotamento dos ouvidos; ao afeto, o endurecimento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Sendo a obsecação e o endurecimento, no concernente
à subtração da graça, penas determinadas não tornam pior o homem, que nelas incorre, bem como em
outras, por ter se tornado pior pela culpa.

RESPOSTA À SEGUNDA. — A objeção colhe quanto à obsecação, enquanto culpa.

RESPOSTA À TERCEIRA. — A malícia é causa merecedora da obsecação, como a culpa é causa da pena. E
deste modo também se diz que o diabo obseca por induzir à culpa.

## Art. 4 — Se a obsecação e o endurecimento sempre se ordenam à salvação do obsecado e endurecido.
(In Matth., cap. XIII: In Ioan., cap. XII, lect. VII).
O quarto discute-se assim. — Parece que a obsecação e o endurecimento sempre se ordenam à
salvação do obsecado e endurecido.

1. — Pois, diz Agostinho, que Deus, sendo o sumo bem, de nenhum modo permitiria o mal se não
pudesse dele tirar o bem. Portanto e com maioria de razão, ordena para o bem o mal de que é a causa.
Ora, Deus é causa da obsecação e do endurecimento, como já se disse. Logo, esta e aquela se ordenam
à salvação dos obsecados e endurecidos.

2. Demais. — A Escritura diz: Deus não se alegra na perdição dos ímpios. Ora, haveria de deleitar-se na
perdição deles, se não lhes fizesse reverter a obsecação em bem próprio deles. Do mesmo modo um
médico haveria de comprazer-se com o sofrimento do enfermo, se não lhe ordenasse à saúde o remédio
amargo que lhe propõe. Logo, Deus faz redundar a obsecação no bem dos obsecados.

3. Demais. — Deus não faz acepção de pessoas, como diz a Escritura (At 10). Ora, a obsecação de certos
ele lhes ordena para a salvação. Tal o caso de certos judeus obsecados em não crer em Cristo, para, nele
não crendo, matarem-no; mas depois, compungidos, converteram-se, como se lê na Escritura (At 2),
segundo está claro em Agostinho. Logo, a obsecação de todos Deus a converte na salvação deles.
Mas, em contrário. — Não se deve praticar o mal para dele resultar o bem, como diz a Escritura (Rm 3).
Ora, a obsecação é um mal. Logo, Deus não obseca o obsecado em benefício deste.

SOLUÇÃO. — A obsecação é preâmbulo para o pecado. Ora, este se ordena para dois termos: a
danação, pelo que é em si mesmo; e a salvação, pela misericórdia e providência de Deus, permitindo
certos caírem em pecado para, reconhecendo-o, humilharem-se e converterem-se, como diz Agostinho.
Por onde, a obsecação por natureza se ordena à danação do obsecado, sendo, por isso, considerada
também efeito da reprovação. Mas às vezes a divina misericórdia a ordena como remédio à salvação
dos obsecados. Esta misericórdia porém não é dada a todos eles, mas só aos predestinados, a
quem todas as coisas lhes contribuem para seu bem, no dizer da Escritura (Rm 8). Logo, a uns a ob-
secação os leva a salvamento; mas a outros, à danação, como diz Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todos os males que Deus faz ou permite se façam
ordenam-se para algum bem. Nem sempre porém, para o bem do sujeito do mal, senão que às vezes
para o de outrem, ou mesmo, de todo o universo. Assim ordenou a culpa dos tiranos ao bem dos
mártires, como ordena a pena dos condenados à glória da sua justiça.

RESPOSTA À SEGUNDA. — Deus não se compraz com a perdição dos homens em si mesma considerada;
mas, em razão da sua justiça, ou por causa do bem daí proveniente.

RESPOSTA À TERCEIRA. — Por misericórdia Deus ordena a obsecação de muitos à salvação deles; é
porém a sua justiça o que ordena a obsecação de outros para a danação. — Mas a misericórdia com que
Deus trata a uns, e não a todos, não implica haja nele acepções, como na Primeira Parte já se
demonstrou.

RESPOSTA À QUARTA. — Não devemos praticar o mal da culpa para dele resultar o bem; mas, em vista
do bem, devem-se aplicar os males da pena.
