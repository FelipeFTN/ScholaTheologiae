# Questão 59: Das relações entre as virtudes morais e a paixão.
Em seguida devemos tratar das diferenças das virtudes morais entre si.
E como as relacionadas com as paixões se distinguem conforme a diversidade destas, é necessário,
primeiro, tratar, em geral, das relações entre as virtudes e as paixões. Segundo, da distinção entre as
virtudes morais, relativamente às paixões.
Sobre a primeira questão cinco artigos se discutem:

## Art. 1 — Se a virtude moral é uma paixão.
(III Sent., dist. XXIII, q. 1, a. 3, qª 2; II Ethic., lect V).
O primeiro discute-se assim. — Parece que a virtude moral é uma paixão.

1. — Pois, o meio é do mesmo gênero que os extremos. Ora, a virtude moral é um meio entre as
paixões. Logo, é paixão.

2. Demais. — O vício e a virtude, sendo contrários, pertencem ao mesmo gênero. Ora, certas paixões,
como a inveja e a ira são consideradas vício. Logo, certas paixões são virtudes.

3. Demais. — A misericórdia é uma paixão, pois consiste na tristeza causada pelos males alheios, como
já se disse. Ora, Cícero, orador egrégio, não duvidou chamar-lhe virtude, como refere Agostinho. Logo, a
paixão pode ser uma virtude moral.
Mas em contrário, já se disse, que as paixões não são virtudes nem malícias.

SOLUÇÃO. — Por tríplice razão a virtude moral não pode ser paixão. — Primeiro, porque a paixão é um
movimento do apetite sensitivo, como já se disse. Ora, a virtude moral, sendo um hábito, não é
movimento, mas antes, princípio do movimento apetitivo. — Segundo, porque as paixões em si mesmas
não implicam bondade nem maldade. Pois, o bem ou o mal humanos dependem da razão; por onde, as
paixões, em si mesmas consideradas, implicam o bem e o mal, segundo convêm ou não com a razão.
Ora, nada disto pode dar-se com a virtude, que só diz respeito ao bem, como já dissemos. — Terceiro,
dado que, de algum modo, uma paixão diga respeito só ao bem ou só ao mal, contudo o movimento da
paixão, enquanto paixão, tem o seu princípio no apetite, e o termo, na razão, para conformidade com a
qual tende o apetite. Ao contrário, o movimento da virtude tem o seu princípio na razão, e o termo, no
apetite, enquanto movido pela razão. E por isso, na definição da virtude moral, se diz que é um hábito
eletivo, consistente num meio termo, determinado pela razão, como o sábio o determinaria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A virtude, por essência, não é um meio entre as paixões;
mas sim, pelo seu efeito, porque constitui um meio entre as paixões.

RESPOSTA À SEGUNDA. — Se tomarmos o vício como um hábito pelo qual obramos mal, é claro que
nenhuma paixão é vício. Se porém o considerarmos como pecado, que é um ato vicioso, nada impede a
paixão de ser um vício, e também contrariamente, de concorrer para o ato de virtude, segundo o qual a
paixão contraria a razão ou lhe segue o ato.

RESPOSTA À TERCEIRA. — Consideramos a misericórdia uma virtude, i. é, um ato de virtude na medida
em que esse movimento da alma obedece à razão; isto é, quando a misericórdia é feita de modo a
observarmos a justiça, quer quando fazemos esmola ao indigente ou perdoamos ao arrependido. Se
porém a tomarmos como um hábito, que aperfeiçoa o homem a se compadecer racionalmente, nada
impede então a considerarmos uma virtude; e o mesmo se pode dizer das paixões semelhantes.

## Art. 2 — Se as virtudes morais podem coexistir com as paixões.
(II Ethic., lect. III).
O segundo discute-se assim. — Parece que as virtudes morais não podem coexistir com as paixões.

1. — Pois, como diz o Filósofo, pacífico é o que não sofre perturbação; paciente, quem a sofre, mas não
se deixa vencer por ela. E o mesmo se pode dizer de todas as virtudes morais. Logo, não podem coexistir
com as paixões.

2. Demais. — A virtude é um hábito reto da alma, como a saúde o é do corpo, segundo já se disse. Por
onde, a virtude foi considerada saúde da alma, de certo modo, no dizer de Túlio. Ora, nesse mesmo
livro, Túlio considera as paixões como certas doenças da alma. Ora, a saúde não é compatível com
nenhuma doença. Logo, nem a virtude o é com as paixões da alma.

3. Demais. — A virtude moral supõe o uso perfeito da razão, mesmo nos casos particulares. Ora, isto fica
impedido pelas paixões, pois, diz o Filósofo, que os prazeres corrompem a ponderação da prudência; e
Salústio diz, que quando elas, isto é, as paixões, governam, a alma não descobre facilmente a verdade.
Logo, as virtudes morais não podem coexistir com as paixões.
Mas, em contrário, diz Agostinho: A vontade perversa terá os movimentos (das paixões) perversos; na
vontade reta, ao contrário, eles não só serão isentos de culpa, mas ainda louváveis. Ora, as virtudes
morais não excluem nada de louvável. Logo, não excluem as paixões e podem coexistir com elas.

SOLUÇÃO. — Sobre esta questão dissentem os estóicos e os peripatéticos, como o refere Agostinho.
Assim, aqueles ensinavam que as paixões não podem existir na alma do sábio ou virtuoso. Estes, pelo
contrário, sequazes de Aristóteles, como diz Agostinho, no mesmo lugar, doutrinavam que as paixões
podem coexistir com as virtudes morais, mas reduzidas ao justo meio.
Ora, esta diversidade de opiniões, como no passo aduzido diz Agostinho, se funda mais nas palavras do
que no modo de pensar deles. Assim, os estóicos, não distinguindo entre o apetite intelectual, chamado
vontade, e o sensitivo, dividido em irascível e concupiscível, também não distinguiam como os
peripatéticos as paixões da alma, que são movimentos do apetite sensitivo, dos outros afetos humanos,
que não são paixões, mas movimentos do apetite intelectivo, chamado vontade. Mas punham a
distinção só em serem paixões quaisquer afetos repugnantes à razão. E estas, se nascem
deliberadamente, não podem existir no sábio e virtuoso; se surgirem porém subitamente, este pode ser
susceptível delas. Pois, as imaginações da alma, chamadas fantasias, influem em nós sem de nós
dependerem, nem em si mesmas, nem quanto ao tempo em que surgem; e quando originadas de
circunstancias aterrorizantes, necessariamente hão de mover o ânimo do sábio, de modo a fazê-lo
experimentar as primeiras emoções do medo ou contrair-se pela tristeza, essas paixões tomando a
dianteira ao papel da razão; nem por isso contudo o sábio aprova tais coisas ou nelas consente, como o
refere Agostinho, citando a Aulo Gélio.
Por onde, consideradas como afeto desordenados as paixões não podem existir no virtuoso, de modo
que este nelas deliberadamente consista, segundo opinavam os estóicos. Se dermos, porém esse nome
a quaisquer movimentos do apetite sensitivo, então poderão nele existir, enquanto governadas pela
razão. E por isso diz Aristóteles: os que consideram as virtudes como estados de impassibilidade e de
quietude, não as compreendem bem por falta de distinção; pois deviam dizer também que são estados
de quietude relativamente às paixões, que atuam como não devem e inoportunamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo aduz o exemplo citado, bem como muitos
outros, nos seus livros de lógica; não que representem a sua opinião, mas sim, a de outros. Ora, no caso
presente, ele expõe a opinião dos estóicos, que consideravam as virtudes incompatíveis com as paixões
da alma. E essa opinião o Filósofo a rejeita, dizendo que as virtudes não são estados de impassibilidade.
Mas também podemos entender a sua opinião, que o pacífico não sofre perturbação, como referente à
paixão desordenada.

RESPOSTA À SEGUNDA. — As concepções citadas, bem como todas as que Cícero aduz, no caso
vertente, se referem às paixões como afetos desordenados.

RESPOSTA À TERCEIRA. — Se a paixão, tomando a dianteira ao juízo da razão, prevalecer na alma, de
modo a fazê-la consentir, trava o conselho e o uso da razão. Se porém lhe for subseqüente, quase
ordenada por ela, ajudará a execução do império racional.

## Art. 3 — Se a virtude é compatível com a tristeza.
O terceiro discute-se assim. — Parece que a virtude não é compatível com a tristeza.

1. — Pois, as virtudes são efeitos da sabedoria, conforme a Escritura (Sb 8, 7): (a divina sabedoria)
ensina a temperança e a justiça, a prudência e a fortaleza. Ora, como se acrescenta mais adiante (Sb 8,
16), a conversação da sabedoria não tem nada de desagradável. Logo, as virtudes são incompatíveis com
a tristeza.

2. Demais. — A tristeza é impedimento a agir, como se vê claramente no Filósofo. Ora o que impede a
boa operação repugna à virtude. Logo, a tristeza repugna à virtude.

3. Demais. — A tristeza é uma espécie de doença da alma, no dizer de Túlio. Ora, tal doença contraria a
virtude, que é um bom hábito da alma. Logo, a tristeza é contrária à virtude e não pode com ela
coexistir.
Mas em contrário, Cristo teve virtude perfeita. Ora, nele houve tristeza, como diz a Escritura (Mt 26,
38): A minha alma está numa tristeza mortal. Logo, a tristeza é compatível com a virtude.

SOLUÇÃO. — Como diz Agostinho, para os estóicos há na alma do sábio três eupatias, i. é, três paixões
boas, correspondentes às três perturbações, a saber: a vontade, correspondente à cobiça: à alegria, o
contentamento; a precaução ao medo. Mas, negaram a possibilidade de existir, na alma do sábio, o
correspondente á tristeza, e por duas razões. Primeiro, porque a tristeza supõe o mal já acontecido. Ora,
na opinião deles, nenhum mal pode suceder ao sábio. Pois pensavam que, assim como a virtude é o
único bem do homem, com exclusão dos bens corpóreos, assim o único mal do mesmo é o desonesto,
que não pode existir no virtuoso. — Mas esta opinião é irracional porque, sendo o homem composto de
corpo e alma, tudo lhe é bem que concorra a conservar a vida do corpo; embora não seja esse o bem
máximo, porque o homem pode usar mal dele. Logo, o mal, contrário a tal bem, pode existir no sábio e
produz uma tristeza moderada. — Além disso, embora o virtuoso possa viver sem pecado grave,
ninguém há que possa passar a vida sem pecados leves, conforme aquilo da Escritura (1 Jo 1, 8): Se
dissemos que estamos sem pecado, nós mesmos a nós mesmos nos enganamos. — Terceiro, porque o
virtuoso, embora atualmente sem pecado, nem sempre talvez esteve assim. E disto louvavelmente se
dói, conforme aquilo da Escritura (2 Cor 7, 10): Porque a tristeza, que é segundo Deus, produz para a
salvação uma penitência estável. — Quarto, porque pode ele também, louvavelmente, condoer-se do
pecado dos outros. Por onde, na medida em que a virtude moral é compatível com as várias paixões
moderadas pela razão, nessa mesma o é com a tristeza.
Em segundo lugar, os estóicos eram movidos pela razão, que a tristeza supõe o mal presente; enquanto
que o temor é relativo ao mal futuro, assim como o prazer o é ao bem presente e o desejo, enfim, ao
bem futuro. Pois, pode ser do domínio da virtude, que gozemos do bem já adquirido, ou desejemos o
que ainda não possuímos, ou enfim, que nos acautelemos do mal futuro. Mas, o curvar-se a nossa alma
pela tristeza ao mal presente, sendo, como é, absolutamente contrário à razão, não pode ser compatível
com o virtuoso. — Mas esta opinião também é irracional. Pois, como já dissemos, há um mal que pode
ser presente ao virtuoso, e repugnante à razão. E por isso o apetite sensitivo nisto acompanha a
repugnância da razão por entristecer-se também com esse mal, embora moderadamente, segundo o
juízo racional. Ora, pertence à virtude tornar o apetite sensitivo conforme a razão, como já dissemos.
Por onde, também à virtude pertence o fazê-lo entristecer-se moderadamente, quando deve
entristecer-se, conforme diz ainda o Filósofo. O que também é útil para fugir o mal. Pois, assim como é
buscado mais prontamente o bem, pelo prazer que nos proporciona, assim, é evitado mais fortemente o
mal, pela tristeza que nos causa.
E portanto devemos concluir, que a tristeza, pelo que convém com a virtude, não pode existir
simultaneamente com ela, pois a virtude se compraz no seu objeto próprio. Mas se entristece
moderadamente com tudo o que de algum modo lhe repugna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Do lugar citado se conclui que o sábio não se entristece
com a sabedoria; mas sim do que lhe serve a ela de impedimento. E por isso não há nenhum lugar para
a tristeza nos bem-aventurados, a cuja sabedoria nenhum impedimento pode existir.

RESPOSTA À SEGUNDA. — A tristeza impede a obra, cuja não-realização nos contrista; mas nos move a
executar mais prontamente o que nos livra dela.

RESPOSTA À TERCEIRA. — A tristeza imoderada é uma doença da alma; mas na condição da vida
presente, a tristeza moderada pertence ao bom hábito da alma.

## Art. 4 — Se toda virtude moral diz respeito às paixões.
O quarto discute-se assim. — Parece que toda virtude moral diz respeito às paixões.

1. — Pois, diz o Filósofo, que a virtude moral versa sobre os prazeres e as tristezas. Ora, o prazer e a
tristeza são paixões, como já se disse. Logo, toda virtude moral versa sobre as paixões.

2. Demais. — O racional por participação é o sujeito das virtudes morais, como já se estabeleceu. Ora, é
nessa parte da alma que existem as paixões, conforme já se disse. Logo, toda virtude moral diz respeito
às paixões.

3. Demais. — Em toda virtude moral se descobre alguma paixão. Logo, ou todas dizem respeito às
paixões, ou nenhuma. Ora, algumas, como a fortaleza e a temperança, versam sobre paixões, segundo
já se provou. Logo, todas as virtudes morais versam sobre as paixões.
Mas, em contrário, a justiça, que é uma virtude moral, não diz respeito às paixões, como se disse.

SOLUÇÃO. — A virtude moral aperfeiçoa a parte apetitiva da alma, ordenando-a ao bem da razão,
consistente no que é por ela moderado ou ordenado. Por onde, tudo o que pode ser ordenado ou
moderado pela razão pode ser virtude moral. Ora, a razão ordena não só as paixões do apetite sensitivo,
mas também as do intelectivo, que é a vontade e que não é sujeito das paixões, como já dissemos. E
portanto nem todas as virtudes morais dizem respeito às paixões, mas umas, às paixões e outras, às
operações.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nem toda virtude moral tem como matéria própria os
prazeres e as tristezas; mas, lhes são relativas como a algo de conseqüente ao ato próprio dela. Pois,
toda pessoa virtuosa se deleita com o ato de virtude e se entristece com o ato contrário. E por isso
Aristóteles, depois das palavras citadas na objeção, acrescenta que se as virtudes são relativas aos atos e
às paixões; e se a deleitação e a tristeza são conseqüentes a toda paixão e a todo ato, a virtude há de
dizer respeito aos prazeres e às tristezas, i. é, a algo de conseqüente.

RESPOSTA À SEGUNDA. — O racional por participação não só é o apetite sensitivo, sujeito das paixões,
mas também à vontade, onde elas não existem, como já se disse.

RESPOSTA À TERCEIRA. — Certas virtudes têm as paixões como matéria própria; certas outras, não. Por
onde, não há semelhança de casos, como a seguir se mostrará.

## Art. 5 — Se a virtude moral pode existir sem as paixões.
O quinto discute-se assim. — Parece que a virtude moral pode existir sem as paixões

1. — Pois, quanto mais a virtude moral é perfeita, tanto mais vence as paixões. Logo, no estado de
perfeição total não devem coexistir com nenhuma paixão.

2. Demais. — É perfeito o remoto do seu contrário e do que a este inclina. Ora, as paixões inclinam ao
pecado. Contrário à virtude; e por isso a Escritura (Rm 7, 5) as denomina paixões dos pecados. Logo, a
virtude perfeita não é compatível com nenhuma paixão. 3. Demais. — Assemelhamo-nos a Deus pela
virtude, como está claro em Agostinho. Ora, Deus obra sem paixão. Logo, a virtude perfeitíssima é
incompatível com qualquer paixão.
Mas, em contrário, não há justo que se não alegre com a obra justa, como já se disse. Ora, a alegria é
uma paixão. Logo, a justiça não pode existir sem a paixão; e com maior razão as outras virtudes.

SOLUÇÃO. — Se, com os estóicos, considerarmos as paixões como afetos desordenados, é manifesto
que a virtude perfeita é incompatível com elas.
Se porém dermos essa denominação a todos os movimentos do apetite sensitivo, é claro que as virtudes
morais que têm as paixões como matéria própria, não podem existir sem elas. Do contrário, a virtude
moral tornaria o apetite sensitivo absolutamente vão. Pois, não é função da virtude tornar a potência,
sujeita à razão, privada dos seus atos próprios, mas, praticando-os, executar o império da razão. Por
onde, assim como a virtude ordena os membros do corpo aos atos exteriores devidos, assim ordena o
apetite sensitivo aos seus movimentos próprios.
As virtudes morais porém, que não versam sobre as paixões, mas sobre as obras, podem existir sem
aquelas. E tal é a justiça, que leva a vontade a aplicar-se ao seu ato próprio, que não é uma paixão, mas
ao qual se segue, ao menos na vontade, a alegria que não é paixão. E se a alegria se multiplicar, pela
perfeição da justiça, redundará até o apetite sensitivo, porque as potências inferiores seguem o
movimento das superiores, como já dissemos. Assim, esta redundância, quanto mais perfeita for, tanto
mais causará a paixão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A virtude reprime as paixões desordenadas e provoca as
moderadas.

RESPOSTA À SEGUNDA. — As paixões desordenadas, e não as moderadas, é que induzem o pecado.

RESPOSTA À TERCEIRA. — O bem de um ser depende da condição da sua natureza, Ora, em Deus e nos
anjos não há, como no homem, apetite sensitivo. E por isso a boa obra de Deus e do anjo é
absolutamente livre de paixão, assim como do corpo; ao passo que a boa obra do homem vai junto com
a paixão bem como com o ministério do corpo.