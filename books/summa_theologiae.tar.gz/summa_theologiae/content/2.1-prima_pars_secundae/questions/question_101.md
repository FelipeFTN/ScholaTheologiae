# Questão 101: Dos preceitos cerimoniais em si mesmos.
Em seguida devemos tratar dos preceitos cerimoniais. Primeiro, em si mesmos. Segundo, da causa
deles. Terceiro, da duração dos mesmos.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se a razão dos preceitos cerimoniais está em serem concernentes ao culto de Deus.
(Supra, q. 99, a. 3; infra, q. 104, a. 1).
O primeiro discute-se assim. — Parece que a razão dos preceitos cerimoniais não está em concernirem
ao culto de Deus.

1. — A lei antiga impunha aos judeus certos preceitos sobre a abstinência dos alimentos, como se vê na
Escritura (Lv 11); e também proibia o uso de certas vestes (Lv 19, 19): Não usarás de vestido que seja
tecido de fios diferentes. E ainda (Nm 15, 38): que se façam umas guarnições nos remates das suas
capas. Ora, estes não são preceitos morais, porque não permaneceram na lei nova; e nem judiciais, por
não dizerem respeito a juízos dirimentes de questões entre as partes. Logo, são cerimoniais, mas, que
em nada concernem ao culto de Deus. Portanto, não é da essência dos preceitos cerimoniais serem
concernentes ao culto de Deus.

2. Demais. — Certos consideram cerimoniais os preceitos concernentes às solenidades, quase assim
chamados por causa dos círios que se nelas acendiam. Ora, além das solenidades, há muitas mais
cerimônias concernentes ao culto de Deus. Donde se conclui que os preceitos cerimoniais da lei não se
chamam assim por concernirem ao culto de Deus.

3. Demais. — Certos consideram os preceitos cerimoniais como quase normas, i. é, regra da salvação;
pois,chaireem grego significa salve, em latim. Ora, todos os preceitos da lei são regras de salvação, e não
só os atinentes ao culto de Deus. Logo, não se chamam cerimoniais só os preceitos concernentes ao
culto de Deus.

4. Demais. — Rabbi Moisés diz que se chamam preceitos cerimoniais aqueles cuja razão não é
manifesta. Ora, muitos dos preceitos concernentes ao culto de Deus tem razão manifesta, como, a
observância do sábado, a celebração da Fase e da Scenopegia, e muitas outras, cuja razão é sinalada na
lei. Logo, cerimoniais não são os preceitos concernentes ao culto de Deus.
Mas, em contrário, diz a Escritura (Ex 18, 19-20): Presta-te ao povo naquelas coisas que dizem respeito a
Deus, para lhes ensinares as cerimônias e o modo com que devem honrar a Deus.

SOLUÇÃO. — Como já dissemos (q. 99, a. 4), os preceitos cerimoniais determinam os preceitos morais
relativos a Deus, assim como os judiciais os determinam em relação ao próximo. Ora, o homem se
ordena para Deus por meio do culto devido. Por onde, cerimoniais propriamente se chamam os
preceitos concernentes ao culto de Deus. E a razão deste nome já a demos antes, quando distinguimos
esses preceitos, dos outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ao culto de Deus não dizem respeito só os sacrifícios e
coisas semelhantes, considerados como se ordenando a Deus imediatamente, mas também a
preparação conveniente dos ministros do culto a Deus devido. Assim, em tudo, os meios conducentes
ao fim pertencem à ciência do fim. Ora, esses preceitos sobre as vestes e os alimentos dos ministros de
Deus, estabelecidos pela lei, e outros semelhantes, respeitam-lhes de certo modo a preparação a fim de
serem idôneos para tal culto; assim como os que estão a serviço do rei seguem certas observâncias
especiais. Por isso, tais preceitos estão contidos nos cerimoniais.

RESPOSTA À SEGUNDA. — Essa derivação do nome em questão não parece muito apropriada;
sobretudo por não ser freqüente ler-se, na lei, que se acendessem círios nas solenidades; senão que, no
próprio candelabro, eram preparadas lâmpadas com azeite de oliveira como está claro na Escritura (Lv
24, 2). Contudo, pode-se dizer, que nas solenidades tudo o mais pertencente ao culto de Deus era
diligentemente observado; e sendo assim, na observância das solenidades incluem-se todos os preceitos
cerimoniais.

RESPOSTA À TERCEIRA. — Também não parece muito apropriada a derivação desse nome, pois, o nome
“cerimônia” não é grego, mas latino. Pode-se dizer, contudo, que, vindo de Deus a salvação do homem,
são aqueles preceitos sobretudo considerados como regras da salvação, que o ordenam para Deus. E
assim, preceitos cerimoniais se chamam os relativos ao culto de Deus.

RESPOSTA À QUARTA. — Essa explicação dos preceitos cerimoniais é de algum modo provável. Não que
se chamem cerimoniais por não terem explicação manifesta, mas por ser isso uma conseqüência. Pois,
de os preceitos concernentes ao culto de Deus serem figurativos, como a seguir se dirá (a. 2), procede o
não terem a razão manifesta.

## Art. 1 — Se a razão dos preceitos cerimoniais está em serem concernentes ao culto de Deus.
(Supra, q. 99, a. 3; infra, q. 104, a. 1).
O primeiro discute-se assim. — Parece que a razão dos preceitos cerimoniais não está em concernirem
ao culto de Deus.

1. — A lei antiga impunha aos judeus certos preceitos sobre a abstinência dos alimentos, como se vê na
Escritura (Lv 11); e também proibia o uso de certas vestes (Lv 19, 19): Não usarás de vestido que seja
tecido de fios diferentes. E ainda (Nm 15, 38): que se façam umas guarnições nos remates das suas
capas. Ora, estes não são preceitos morais, porque não permaneceram na lei nova; e nem judiciais, por
não dizerem respeito a juízos dirimentes de questões entre as partes. Logo, são cerimoniais, mas, que
em nada concernem ao culto de Deus. Portanto, não é da essência dos preceitos cerimoniais serem
concernentes ao culto de Deus.

2. Demais. — Certos consideram cerimoniais os preceitos concernentes às solenidades, quase assim
chamados por causa dos círios que se nelas acendiam. Ora, além das solenidades, há muitas mais
cerimônias concernentes ao culto de Deus. Donde se conclui que os preceitos cerimoniais da lei não se
chamam assim por concernirem ao culto de Deus.

3. Demais. — Certos consideram os preceitos cerimoniais como quase normas, i. é, regra da salvação;
pois,chaireem grego significa salve, em latim. Ora, todos os preceitos da lei são regras de salvação, e não
só os atinentes ao culto de Deus. Logo, não se chamam cerimoniais só os preceitos concernentes ao
culto de Deus.

4. Demais. — Rabbi Moisés diz que se chamam preceitos cerimoniais aqueles cuja razão não é
manifesta. Ora, muitos dos preceitos concernentes ao culto de Deus tem razão manifesta, como, a
observância do sábado, a celebração da Fase e da Scenopegia, e muitas outras, cuja razão é sinalada na
lei. Logo, cerimoniais não são os preceitos concernentes ao culto de Deus.
Mas, em contrário, diz a Escritura (Ex 18, 19-20): Presta-te ao povo naquelas coisas que dizem respeito a
Deus, para lhes ensinares as cerimônias e o modo com que devem honrar a Deus.

SOLUÇÃO. — Como já dissemos (q. 99, a. 4), os preceitos cerimoniais determinam os preceitos morais
relativos a Deus, assim como os judiciais os determinam em relação ao próximo. Ora, o homem se
ordena para Deus por meio do culto devido. Por onde, cerimoniais propriamente se chamam os
preceitos concernentes ao culto de Deus. E a razão deste nome já a demos antes, quando distinguimos
esses preceitos, dos outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ao culto de Deus não dizem respeito só os sacrifícios e
coisas semelhantes, considerados como se ordenando a Deus imediatamente, mas também a
preparação conveniente dos ministros do culto a Deus devido. Assim, em tudo, os meios conducentes
ao fim pertencem à ciência do fim. Ora, esses preceitos sobre as vestes e os alimentos dos ministros de
Deus, estabelecidos pela lei, e outros semelhantes, respeitam-lhes de certo modo a preparação a fim de
serem idôneos para tal culto; assim como os que estão a serviço do rei seguem certas observâncias
especiais. Por isso, tais preceitos estão contidos nos cerimoniais.

RESPOSTA À SEGUNDA. — Essa derivação do nome em questão não parece muito apropriada;
sobretudo por não ser freqüente ler-se, na lei, que se acendessem círios nas solenidades; senão que, no
próprio candelabro, eram preparadas lâmpadas com azeite de oliveira como está claro na Escritura (Lv
24, 2). Contudo, pode-se dizer, que nas solenidades tudo o mais pertencente ao culto de Deus era
diligentemente observado; e sendo assim, na observância das solenidades incluem-se todos os preceitos
cerimoniais.

RESPOSTA À TERCEIRA. — Também não parece muito apropriada a derivação desse nome, pois, o nome
“cerimônia” não é grego, mas latino. Pode-se dizer, contudo, que, vindo de Deus a salvação do homem,
são aqueles preceitos sobretudo considerados como regras da salvação, que o ordenam para Deus. E
assim, preceitos cerimoniais se chamam os relativos ao culto de Deus.

RESPOSTA À QUARTA. — Essa explicação dos preceitos cerimoniais é de algum modo provável. Não que
se chamem cerimoniais por não terem explicação manifesta, mas por ser isso uma conseqüência. Pois,
de os preceitos concernentes ao culto de Deus serem figurativos, como a seguir se dirá (a. 2), procede o
não terem a razão manifesta.

## Art. 2 — Se os preceitos cerimoniais são figurativos.
(Infra, q. 103, a. 1, 3; q. 104, a. 2).
O segundo discute-se assim. — Parece que os preceitos morais não são figurativos.

1. — Pois, é da obrigação de quem quer que ensine exprimir-se de modo a ser facilmente entendido,
como diz Agostinho. E isto é sobretudo necessário na legislação, porque os preceitos da lei são
propostos ao povo. Por isso ela deve ser clara, como diz Isidoro. Se portanto, os preceitos foram dados
como figurativos de alguma coisa, parece que foram transmitidos inconvenientemente a Moisés, sem
manifestarem o que figuravam.

2. Demais. — Todos os atos do culto divino devem revestir-se da máxima dignidade. Ora, fazer uma
coisa para representar outra parece ser próprio do teatro ou da poesia. Pois, antigamente, nos teatros,
faziam-se umas coisas para representarem feitos de outrem. Logo, conclui-se que tal não se deve fazer
no culto de Deus, como já se disse. Logo, os preceitos cerimoniais não devem ser figurados.

3. Demais. — Agostinho diz, que Deus é cultuado sobretudo pela fé, pela esperança e pela caridade:
Ora, os preceitos relativos à fé, à esperança e a caridade não são figurativos. Logo, figurativos não
devem ser os preceitos cerimoniais.

4. — Demais. — O Senhor diz (Jo 4, 24): Deus é espírito, e em espírito e verdade é que o devem adorar
os que o adoram. Ora, a figura não é a verdade mesma; antes, uma se divide da outra por oposição.
Logo, os preceitos cerimoniais, pertencentes ao culto de Deus, não devem ser figurativos.
Mas, em contrário, diz o Apóstolo (Cl 2, 16-17): Ninguém vos julgue pelo comer nem pelo beber, nem
por causa dos dias de festa, ou das luas novas, ou dos sábados, que são sombras das coisas vindouras.

SOLUÇÃO. — Como já dissemos (a. 1; q. 99, a. 3), chamam-se preceitos cerimoniais os ordenados ao
culto. Ora, duplo é o culto de Deus — o interno e o externo. Pois, sendo o homem composto de corpo e
alma, esta e aquele devem aplicar-se ao culto de Deus, de modo que a alma o cultue com culto interno,
e o corpo, com o externo. Por isso, diz a Escritura (Sl 83, 3): O meu coração e a minha alma se
regozijaram no Deus vivo. E assim como o corpo se ordena a Deus, pela alma, assim, o culto externo, ao
interno. Ora, o culto interno consiste em a alma unir-se com Deus pelo intelecto e pelo afeto. Por onde,
segundo os modos diversos por que o intelecto e o afeto, de quem cultua a Deus, se une retamente com
ele, assim os modos diversos por que os atos externos do homem se aplicam ao culto de Deus.
Ora, no estado da felicidade futura, o intelecto humano contemplará a verdade divina em si mesma. Por
onde, o culto externo não consistirá em nenhuma figura, mas só em louvor a Deus, o que procede do
conhecimento interior e do afeto, conforme aquilo da Escritura (Is 51, 3): Nela se achará o gosto e a
alegria, ação de graças e voz de louvor.
Ao contrário, no estado da vida presente, não podemos contemplar a divina verdade em si mesma, mas
é necessário que o seu raio nos ilumine, sob certas figuras sensíveis, como diz Dionísio; mas,
diversamente, conforme os estados diversos do conhecimento humano. — Ora, na lei antiga, nem a
verdade divina era em si mesma clara, nem estava ainda preparada a via para chegar a ela, como diz o
Apóstolo (Heb 9, 8). Por isso era necessário que o culto externo da lei antiga fosse figurativo, não só da
verdade futura, que deverá manifestar-se na pátria celeste, mas também de Cristo, via conducente a
essa verdade celeste. — No estado da lei nova, ao contrário, essa via já foi revelada. Por isso não precisa
de ser prefigurada como futura, mas deve ser comemorada a modo de passada ou presente; devendo-
se prefigurar só a verdade futura da glória ainda não revelada. E isto diz o Apóstolo (Heb 11, 1): a lei tem
a sombra dos bens futuros, não a mesma imagem das coisas. Pois, a sombra é menos que a imagem: ao
passo que esta pertence à lei nova, aquela pertence à antiga.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As verdades divinas não devem ser reveladas aos
homens, senão de acordo com a capacidade deles; do contrário dar-se-lhes-ia ocasião de caírem, por
desprezarem o que não podiam entender. Por isso foi mais útil terem sido os mistérios divinos
transmitidos ao povo rude sob o véu de figuras; de modo que os conhecessem implicitamente ao
menos, servindo a essas figuras, em honra de Deus.

RESPOSTA À SEGUNDA. — Assim como as criações poéticas não são compreendidas pela razão humana,
por causa da deficiência de verdade que encerram, assim também a razão humana não pode
compreender perfeitamente as coisas divinas, por encerrarem verdades que a excedem. Por isso, em
um e outro caso, é necessária a representação por meio de figuras sensíveis.

RESPOSTA À TERCEIRA. — Agostinho se refere, no lugar aduzido, ao culto interno, ao qual contudo é
preciso ordenar o externo, como dissemos.
E semelhantemente se deve RESPONDER À QUARTA OBJEÇÃO. — Porque, por Cristo, os homens foram
introduzidos, mais plenamente, no culto espiritual de Deus.

## Art. 3 — Se deviam ter sido muito os preceitos cerimoniais.
(IV Sent., dist. I, q. 1, a. 5, qª 2, ad 2; Ad Rom., cap. V. lect. VI).
O terceiro discute-se assim. — Parece que não deviam ter sido muitos os preceitos cerimoniais.

1. — Pois, os meios devem ser proporcionados ao fim. Ora, os preceitos cerimoniais, como já se disse (a.
1, a. 2), ordenavam-se ao culto de Deus e a figurar Cristo. Ora, há um só Deus, de quem tiveram o ser
todas as coisas; e só um Senhor Jesus Cristo, por quem todos existem, como diz a Escritura (1 Cor 8, 6).
Logo, os preceitos cerimoniais não deviam ter-se multiplicado.

2. Demais. — A multidão dos preceitos cerimoniais era ocasião de transgressões, segundo a Escritura (At
15, 10): Porque tentais a Deus, pondo um jugo sobre as cervizes dos discípulos, que nem nossos pais
nem nós pudemos suportar? Ora, a transgressão dos preceitos divinos encontra a salvação humana. E
toda lei, devendo buscar o bem estar dos homens, como diz Isidoro, resulta que se não deviam ser dado
muitos preceitos cerimoniais.

3. Demais. — Os preceitos cerimoniais diziam respeito ao culto externo e material de Deus, como já se
disse (a. 2). Ora, a lei devia diminuir esse culto material por se ordenar para Cristo, que ensinou aos
homens adorarem a Deus em espírito e em verdade, como está na Escritura (Jo 4, 23). Logo, não se
deviam ter dado muitos preceitos cerimoniais.
Mas, em contrário, diz a Escritura (Os 8, 12): Eu lhe tinha prescrito um grande número de leis minhas; e
(Jó 11, 6): Para te descobrir os segredos da sua sabedoria, é que a sua lei é de muitas maneiras.

SOLUÇÃO. — Como já dissemos (q. 96, a. 1), toda lei é dada a algum povo. Ora, este abrange duas
espécies de homens: uns, inclinados ao mal, devem ser coibidos pelos preceitos da lei, como já se disse
(q. 95, a. 1); outros, com inclinação para o bem, por natureza, costume, ou, melhor, por graça, e esses
devem ser instruídos e melhorados pelo preceito da lei.
Por onde, quanto a essas duas espécies de homens, importava fossem os preceitos cerimoniais da lei
antiga multiplicados. Pois, no povo judeu, havendo certos inclinados à idolatria, era necessário fossem
desviados desse culto para o de Deus pelos preceitos cerimoniais. E como os homens de muitas
maneiras serviam à idolatria, era necessário, ao contrário, fazerem-se muitas instituições para reprimir
casos particulares. E além disso, que a esses tais fossem impostos tantos preceitos, de modo a serem
quase onerados pela contribuição que deviam dar para o culto de Deus, e assim não lhes sobrasse
tempo para servir à idolatria. — Quanto aos inclinados ao bem, também era necessária a multiplicação
dos preceitos cerimoniais. E isso para que a mente deles, diversa e mais assiduamente, assim se
referisse a Deus; ou também porque o mistério de Cristo, figurado por esses preceitos cerimoniais,
trouxe ao mundo muitas utilidades, e muitas considerações se deviam fazer relativas a ele, que era
necessário fossem figuradas pelos mesmos diversos preceitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando os meios são suficientes para conduzir ao fim,
então basta um meio para um fim; assim, um remédio eficaz basta às vezes, a restaurar a saúde, não
sendo então necessário multiplicarem-se os remédios. Mas por causa da sua debilidade e imperfeição,
torna-se necessário multiplicar os meios; por isso dão-se muitos remédios a um enfermo, quando um só
não basta para curar. Ora, as cerimônias da lei antiga eram imprestáveis e imperfeitas para representar
o mistério de Cristo, que é sobreexcelente, e para submeter a mente dos homens a Deus. Por isso, o
Apóstolo diz (Heb 7, 18-19): O mandamento primeiro é na verdade abrogado pela fraqueza e
inutilidade; porque a lei nenhuma coisa levou à perfeição. Por onde, era necessário que as cerimônias
em questão fossem multiplicadas.

RESPOSTA À SEGUNDA. — Do legislador sábio é próprio permitir transgressões menores para evitar as
maiores. Por onde, nem por evitar a transgressão da idolatria e da soberba, que haveria de prorromper
nos corações dos judeus, se cumprissem todos os preceitos da lei, deixou Deus de impor muitos
preceitos cerimoniais, que lhes ofereciam facilmente a ocasião de transgredir.

RESPOSTA À TERCEIRA. — A lei antiga em muitos casos diminuiu o culto material. Para o que estatuiu
não se oferecessem sacrifícios em qualquer lugar, nem por quem quer que fosse. E muitos deles
estabeleceu para a diminuição do culto externo, como o mesmo Rabbi Moisés Egípcio diz. Era
necessário, porém não atenuar a ponto o culto material a Deus, que os homens resvalassem no culto
dos demônios.

## Art. 4 — Se as cerimônias da lei antiga se dividiam convenientemente em sacrifícios, coisas sagradas, sacramentos e observâncias.
(Ad Coloss., cap. II, lect. IV).
O quarto discute-se assim. — Parece que as cerimônias da lei antiga se dividiam inconvenientemente
em sacrifícios, coisas sagradas, sacramentos e observâncias.

1. — Pois, as cerimônias da lei antiga figuravam a Cristo. Ora, isto só se fazia pelos sacrifícios, figurativos
do sacrifício pelo qual Cristo se entregou a si mesmo por nós outros como oferenda e hóstia a Deus,
como diz a Escritura (Ef 5, 2). Logo, só os sacrifícios pertenciam ao cerimonial.

2. Demais. — A lei antiga ordenava-se para a nova. Ora, nesta o sacrifício é o sacramento do altar. Logo,
na antiga, não se deviam opor os sacramentos aos sacrifícios.

3. Demais. — Sagrado se chama ao dedicado a Deus; e nesse sentido diziam-se santificados o
tabernáculo e os seus vasos. Ora, todas as coisas usadas na cerimônia se ordenavam ao culto de Deus,
como se disse (a. 1). Logo, todos eram sagradas, e portanto não se devia considerar como sagrada só
uma parte delas.

4. Demais. — Observância vem de observar. Ora, todos os preceitos da lei deviam ser observados,
conforme a Escritura (Dt 8, 11): Toma sentido e tem cuidado que jamais te não esqueças do Senhor teu
Deus, e que não desprezes os seus preceitos e leis e cerimônias. Logo, as observâncias não deviam ser
consideradas como parte das cerimônias.

5. Demais. — As solenidades eram consideradas cerimônias, sendo, como eram, sombra das coisas
vindouras, como diz a Escritura (Cl 2, 16-17). Semelhantemente, as oblações, sacrifícios e dons, segundo
claramente o diz o Apóstolo (Heb 9, 9). Entretanto, nada disso tudo está contido na enumeração supra.
Logo, é inconveniente a referida divisão das cerimônias.
Mas, em contrário, a lei antiga designa cada uma dessas preditas cerimônias. — Pois, os sacrifícios são
chamados cerimônias (Nm 15, 24): oferecerá um bezerro, com a sua oferenda e libações, como o pede o
cerimonial. — Do sacramento da ordem se diz (Lv 7, 35): Esta é a unção d’Arão e de seus filhos nas
cerimônias. — Das coisas sagradas também se diz (Ex 38, 21): Estas são as partes, que compunham o
tabernáculo do testemunho, nas cerimônias dos Levitas. — Por fim, das observâncias (1 Rs 9, 6): Se vos
desviardes de mim, não me seguindo, nem guardando as cerimônias, que eu vos prescrevi.

SOLUÇÃO. — Como já dissemos (a. 1, a. 2), os preceitos cerimoniais ordenavam-se ao culto de Deus, no
qual podemos considerar o culto em si mesmo, os que cultuavam e os seus instrumentos. — Ora, em si
mesmo, o culto consiste nos sacrifícios oferecidos para reverenciar a Deus. — Os instrumentos do culto
constituíam as coisas sagradas, como o tabernáculo, os vasos e objetos semelhantes. — Quanto aos que
cultuavam, duas considerações podemos fazer: a sua instituição para o culto divino, feita por uma
consagração do povo, ou dos ministros, a isto pertence aos sacramentos; e, depois, o modo de vida
peculiar deles, pelo qual se distinguiam dos que não cultuavam a Deus, e a isto pertencem as
observâncias, p. ex., quanto aos alimentos e às vestes e coisas semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Era necessário que os sacrifícios fossem oferecidos em
lugares e por homens determinados, o que tudo pertencia ao culto de Deus. Por onde, assim como os
sacrifícios significavam Cristo imolado, assim também os sacramentos e as coisas sagradas a eles
pertencentes figuravam os sacramentos e as coisas sagradas da lei nova; e as observâncias dos mesmos
figuravam o gênero de vida do povo dessa lei. O que tudo diz respeito a Cristo.

RESPOSTA À SEGUNDA. — O sacrifício da lei nova, i. é, a Eucaristia, contém Cristo mesmo, autor da
santificação, pois, santificou ao povo pelo seu sangue, como diz a Escritura (Heb 13, 12). Por onde, este
sacrifício também é um sacramento. Mas, os sacrifícios da lei antiga não continham Cristo, senão que o
figuravam, e por isso não se chamavam sacramentos. Mas, para designá-lo havia certos sacramentos
especiais da lei antiga, que eram as figuras da futura consagração. — Embora também a certas
consagrações se acrescentassem determinados sacrifícios.

RESPOSTA À TERCEIRA. — Também os sacrifícios e os sacramentos eram coisas sagradas. Mas havia
certas coisas sagradas, por serem dedicadas ao culto de Deus, que, nem por isso, eram sacrifícios nem
sacramentos. E por isso, se lhes aplicava a denominação comum de coisas sagradas.

RESPOSTA À QUARTA. — As coisas pertencentes ao gênero de vida do povo, que cultuava a Deus,
aplicava-se a denominação comum de observâncias, por serem menos que as outras coisas. Pois, não se
consideravam objetos sagrados porque não respeitavam imediatamente ao culto de Deus, como o
tabernáculo e os seus vasos. Mas, por uma conseqüência, eram preceitos cerimoniais, enquanto
condicentes com uma certa conveniência do povo, que cultuava a Deus.

RESPOSTA À QUINTA. — Assim como os sacrifícios eram oferecidos num determinado lugar, assim
também o eram em determinados tempos. Por onde, também as solenidades eram contadas entre as
coisas sagradas. — Ao passo que as oblações e os dons eram enumerados entre os sacrifícios, por serem
oferecidos a Deus. Por isso, diz o Apóstolo (Heb 5, 1): Todo o pontífice assunto dentre os homens é
constituído a favor dos homens naquelas coisas que tocam a Deus, para que ofereça dons e sacrifícios
pelos pecados.