# Questão 4: Do necessário à beatitude.
Em seguida deve-se tratar do necessário à beatitude. E sobre esta Questão oito artigos se discutem:

## Art. 1 — Se a deleitação é necessária à beatitude.
(Supra, q. 3, a . 4; II Sent., dist. XXXVIII, a . 2; dist. XLIX, q. 1, a. 1, q ª 2; q. 3, a . 4, q ª 4; Compend. Theol.,
cap. CVII, CLXV; X Ethic., lect. VI).
O primeiro discute-se assim. — Parece que a deleitação não é necessária para a beatitude.

1. — Pois, como diz Agostinho, a visão é toda a mercê da fé. Ora, o prêmio ou mercê da virtude é a
beatitude, como se vê no Filósofo. Logo, nada mais é necessário à beatitude, além da visão.

2. Demais. — A beatitude é o bem por si suficientíssimo, como diz o Filósofo. Ora, o que necessita de
qualquer outra coisa não é por si suficiente. Consistindo, pois, a essência da beatitude na visão de Deus,
como já se demonstrou, resulta que a deleitação não é necessária à beatitude.

3. Demais. — A operação da felicidade ou da beatitude há-de ser não impedida, como diz Aristóteles.
Ora, a deleitação impede a ação do intelecto, pois, corrompe a apreciação da prudência, conforme
Aristóteles. Logo, ela não é necessária para a beatitude.
Mas, em contrário, diz Agostinho, que a beatitude é o alegrar-se com a verdade.

SOLUÇÃO. — De quatro modos se pode dizer que uma coisa é necessária a outra. Primeiro, como
preâmbulo ou preparação; assim, a disciplina é necessária à ciência. Segundo, como aperfeiçoamento;
assim, a alma é necessária à vida do corpo. Terceiro, como coadjuvante extrínseco; assim, amigos são
necessários para fazer alguma coisa. Quarto, como algo de concomitante; assim, se dissermos que o
calor é necessário ao fogo. E deste modo é que a deleitação é necessária à beatitude, pois é causada
pelo repouso do apetite no bem alcançado. Por onde, não sendo a beatitude senão a obtenção do sumo
bem, não pode ela existir sem a concomitante deleitação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vontade de quem merece repousa só pelo fato de lhe
ser feita mercê; o que é deleitar-se. Por onde, em a noção mesma de mercê feita já se inclui a
deleitação.

RESPOSTA À SEGUNDA. — A deleitação resulta da visão mesma de Deus. Por onde, a quem vê a Deus
não lhe pode faltar a deleitação.

RESPOSTA À TERCEIRA. — A deleitação concomitante à operação do intelecto não a impede, antes, a
conforta, como diz Aristóteles; pois, no que fazemos com prazer, agimos mais atenta e
perseverantemente. Ao passo que a deleitação estranha impede a operação. Umas vezes, por
distraimento da intenção, pois, como já se disse, a nossa intenção se dirige sobretudo aquilo com que
nos deleitamos; e quando intencionamos veementemente uma coisa, necessário é que a nossa intenção
se retraia de outras. Por vezes, também, por contrariedade; assim, a deleitação do sentido, contrária à
razão, impede a ponderação da prudência mais do que a do intelecto especulativo.

## Art. 2 — Se a deleitação, na beatitude, tem prioridade sobre a visão.
(II Sent., dist. XXXVIII, a . 2, ad 6; III Cont. Gent., cap. XXVI; X Ethic., lect VI).
O segundo discute-se assim. — Parece que a deleitação tem, na beatitude, prioridade sobre a visão.

1. — Pois, como diz Aristóteles, a deleitação é a perfeição do ato. Ora, a perfeição é mais excelente que
o perfectível. Logo, a deleitação tem prioridade sobre a operação do intelecto, que é a visão.

2. Demais. — Tem prioridade aquilo que faz uma coisa ser apetecível. Ora, as operações são apetecidas
pelas suas deleitações; por isso, a natureza apôs a deleitação às atividades necessárias à conservação do
indivíduo e da espécie, para que tais operações não fossem abandonadas pelos animais. Logo, a
deleitação tem prioridade, na beatitude, sobre a visão, operação do intelecto.

3. Demais. — A visão corresponde à fé; ao passo que a deleitação, ou fruição, à caridade. Ora, esta é
maior que a fé, como diz o Apóstolo (1 Cor 13). Logo, a deleitação ou fruição tem prioridade sobre a
visão.
Mas, em contrário. — A causa tem prioridade sobre o efeito. Ora, a visão é causa da deleitação. Logo,
tem prioridade esta sobre aquela.

SOLUÇÃO. — O Filósofo suscitaesta Questão e a deixa irresoluta. Mas, quem a considerar
diligentemente há de por força concluir que a visão, operação do intelecto, tem prioridade sobre a
deleitação. Pois, esta consiste na quietação da vontade; ora, a vontade só repousa em um objeto por
causa da bondade do mesmo. Portanto, se repousa em alguma operação, esse repouso procede da
bondade da operação. Nem a vontade busca o bem por causa do repouso, porque então ao ato mesmo
dela seria o fim, o que vai contra o já estabelecido. Antes, busca repousar na operação, porque esta é o
seu bem.
Por onde é manifesto, que a operação mesma, em que repousa a vontade tem prioridade sobre o
repouso da vontade no bem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz o Filósofo no mesmo passo, a deleitação
completa a operação como a beleza, a juventude, pois, esta resulta daquela. Por onde, a deleitação é
uma perfeição concomitante à visão e não uma como perfeição que torna perfeita a visão, na sua
espécie.

RESPOSTA À SEGUNDA. — A apreensão sensitiva não alcança a essência comum do bem, mas um bem
particular deleitável. Por isso o apetite sensitivo dos animais é levado ao ato por causa da deleitação. O
intelecto porém apreende a essência universal do bem, da consecução da qual resulta a deleitação, e
por isso visa, antes, o bem que a deleitação. Donde resulta que o intelecto divino, instituidor da
natureza, faz depender a deleitação da atividade. Ora, não se deve julgar nada absolutamente,
conforme a ordem do apetite sensitivo, mas, antes, segundo a do intelectivo.

RESPOSTA À TERCEIRA. — A caridade não busca o bem amado por causa da deleitação; mas é-lhe
conseqüente o deleitar-se no bem alcançado, que ama. E assim, não lhe corresponde, como fim, a
deleitação mas, antes, a visão, que primariamente lhe torna presente o fim.

## Art. 3 — Se a beatitude supõe a compreensão.
(I, q. 12, a . 7. ad I; I Sent., dist. I, q. a . 1; IV, dist. XLIV, q. 4, a . 5, q ª 1).
O terceiro discute-se assim. — Parece que a beatitude não supõe a compreensão.

1. — Pois, diz Agostinho: Alcançar a Deus com a mente é grande beatitude, porém é impossível
compreender. Logo, sem compreensão há beatitude.

2. Demais. — A beatitude é a perfeição do homem, quanto à parte intelectiva, que não abrange outras
potências, senão o intelecto e a vontade, como já se disse na primeira parte. Ora, o intelecto
suficientemente se aperfeiçoa pela visão de Deus e a vontade, pela deleitação nele. Logo, não é
necessária, como terceiro elemento, a compreensão.

3. Demais. — A beatitude consiste na operação. Ora, as operações se determinam pelos objetos e os
objetos gerais são dois; a verdade e o bem. A verdade porém corresponde à visão e o bem, a deleitação.
Logo, não é necessária a compreensão, como terceiro elemento.
Mas, em contrário, dia o Apóstolo (1 Cor 9, 24): Correi de tal maneira que o alcanceis. Ora, a carreira
espiritual termina em a beatitude; por onde, diz o mesmo (2 Tm 4, 7): Eu pelejei uma boa peleja; acabei
a minha carreira; guardei a fé. Pelo mais me está reservada a coroa da justiça. Logo, a beatitude exige a
compreensão.

SOLUÇÃO. — Consistindo a beatitude na consecução do último fim, o que ela supõe devemos considerá-
lo quanto à ordem mesma do homem em relação ao fim. Ora, o homem se ordena a um fim inteligível,
em parte, pelo intelecto e, em parte, pela vontade. Pelo intelecto, enquanto nele preexiste um
conhecimento imperfeito do fim. Pela vontade; antes de tudo pelo amor, que é o seu movimento
primeiro para algum objeto; em segundo lugar, pela relação real entre o amante e o amado, e que pode
ser tríplice. Assim, umas vezes o amado, estando presente ao amante, já não é buscado. Outras, não o
estando, mas sendo impossível alcança-lo, não é buscado. Outras, enfim, é possível obtê-lo, mas sendo
de tal modo superior à faculdade de quem deve alcança-lo, não pode ser obtido imediatamente; donde
resulta uma relação entre quem espera e o que é esperado, a única que leva à busca do fim. E a cada
uma desta tríplice relação corresponde algo na beatitude. Assim, o conhecimento perfeito corresponde
à relação imperfeita; enquanto que a presença do fim, sem si, corresponde à relação de esperança; e
afinal a deleitação no fim já presente resulta do amor, como já se disse. Por onde, é necessária, para a
beatitude, esta tríplice concorrência: a visão, conhecimento perfeito do fim inteligível; a compreensão,
que supõe a presença do fim; a deleitação ou fruição, que supõe o repouso do amante no amado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Compreensão tem duplo sentido. Num significa a
inclusão do compreendido no compreensor, e assim tudo o que é compreendido pelo finito é finito; e
então, Deus não pode ser compreendido por nenhum intelecto criado. Noutro sentido, compreensão
não significa mais do que a posse de uma coisa já tida presencialmente; assim, diz-se que quem busca a
outrem o compreende quando o possui. E neste sentido a compreensão é necessária à beatitude.

RESPOSTA À SEGUNDA. — Assim como à vontade pertence à esperança e o amor, porque quem ama
alguma coisa não adquirida tende para ela; assim também lhe pertence à compreensão e a deleitação,
porque quem tem alguma coisa nela repousa.

RESPOSTA À TERCEIRA. — A compreensão não é operação diferente da visão, mas relação com o fim já
adquirido. Por onde, mesmo a visão, em si, ou a coisa vista, enquanto existente presencialmente, é o
objeto da compreensão.

## Art. 4 — Se a retidão da vontade é necessária para a beatitude.
(Infra, q. 5, a . 7; IV Cont. Gent., cap. XCII; Compend. Theol., cap. CLXVI).
O quarto discute-se assim. — Parece que a beatitude não implica a retidão da vontade.

1. — Pois, como já se disse, a beatitude consiste na atividade do intelecto. Ora, para a perfeita operação
deste não é necessária a retidão da vontade, que torna os homens puros. Pois, diz Agostinho: Não
aprovo o que disse na oração — Deus, que quiseste que só os puros conhecessem a verdade — porque
se pode responder que muitos, embora não puros, conhecem muitas verdades. Logo, a beatitude não
implica a retidão da vontade.

2. Demais. — O anterior não depende do posterior. Ora, a operação do intelecto é anterior à da
vontade. Logo, a beatitude, operação perfeita do intelecto, não depende da retidão da vontade.

3. Demais. — O que se ordena a um fim já não é necessário, alcançando o fim; assim a nau, depois que
se chegou ao porto. Ora, a retidão da vontade, causada pela virtude, se ordena como para o fim, à
beatitude. Logo, alcançada esta, já não é necessária aquela.
Mas, em contrário, diz a Escritura (Mt 5, 8): Bem-aventurados os limpos de coração, porque eles verão a
Deus; e (Heb 12, 14): Segui a paz com todos, e a santidade, sem a qual ninguém verá o Deus.

SOLUÇÃO. — A retidão da vontade é necessária para a beatitude, tanto antecedente como
concomitante. — Antecedentemente, por que tal retidão supõe a ordem devida em relação ao último
fim. Ora, o fim está para o que se lhe ordena como a forma, para a matéria. Por onde, como esta não
pode conseguir aquela, se para ela não estiver disposta de certo modo; assim nada consegue o fim sem
estar para ele ordenado de certo modo. E portanto ninguém pode chegar à beatitude sem a retidão da
vontade. — E concomitantemente, porque, como já se disse, a beatitude última consiste na visão da
essência divina, que é a essência mesma da bondade. Assim, à vontade de quem vê a essência de Deus
tudo ama, por força, subordinadamente a Deus; como também à vontade de quem não lhe vê a
essência tudo ama, necessariamente, sob a noção comum, de bem. Ora, é isto mesmo o que constitui a
vontade reta. Por onde, é manifesto que a beatitude não pode existir sem tal vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho se refere ao conhecimento da verdade, que
não é a essência mesma da bondade.

RESPOSTA À SEGUNDA. — Todo ato da vontade é precedido por algum ato do intelecto. Há porém atos
da vontade anteriores a atos do intelecto, pois, a vontade tende para o ato final do intelecto, que é a
beatitude. E portanto, a reta inclinação da vontade é preexigida para a beatitude, assim como o
movimento reto da seta à percussão do alvo.

RESPOSTA À TERCEIRA. — Nem tudo o que é ordenado a um fim cessa, alcançado o fim; mas somente
aquilo que se inclui em a noção de imperfeição e de movimento. Donde, os meios conducentes ao
movimento não são necessários, uma vez que se chegou ao fim. Mas a ordem devida, em relação ao fim,
é necessária.

## Art. 5 — Se o corpo é necessário à beatitude.
(IV Cont. Gent., cap. LXXIX, XCI; De Pot., q. 5, a . 10; Compemd. Theol., cap. CLI).
O quinto discute-se assim. — Parece que o corpo é necessário à beatitude.

1. — Pois, a perfeição da virtude e da graça pressupõe a da natureza. Ora, a beatitude é a perfeição da
virtude e da graça. A alma porém, sem o corpo, não tem a perfeição da natureza, porque é
naturalmente parte da natureza humana, e toda parte é imperfeita, separada do seu todo. Logo, a alma
sem o corpo não pode ser feliz.

2. Demais. — Como já se disse, a beatitude é uma atividade perfeita. Ora, esta resulta do ser perfeito,
porque nada age, senão enquanto é atual. Não tendo a alma porém o ser perfeito, quando separada do
corpo, pois nenhuma parte separada do todo o tem, resulta que, dele separada, não pode ser feliz.

3. Demais. — A beatitude é a perfeição do homem. Ora, a alma sem corpo não é homem. Logo, a
beatitude não pode existir, na alma, sem o corpo.

4. Demais. — Segundo o Filósofo, o ato da felicidade, no qual consiste a beatitude, não pode ser
impedido. Ora, a atividade da alma separada fica impedida, pois, como diz Agostinho, é-lhe inerente um
certo desejo natural de governar o corpo que, de certo modo, lhe retarda o encaminhar-se, com total
contensão, ao supremo céu, i. é, à visão da essência divina. Logo, a alma sem o corpo não pode ser feliz.

5. Demais. — A beatitude é o bem suficiente e aquieta o desejo. Ora, tal não convém à alma separada,
que ainda deseja a união com o corpo, como diz Agostinho. Logo, a alma separada do corpo não é feliz.

6. Demais. — O homem, na beatitude, se equipara aos anjos. Ora, tal não se dá com a alma sem o corpo,
como diz Agostinho. Logo, não é feliz.
Mas, em contrário, diz a Escritura (Ap 14, 13): Bem-aventurados os mortos que morrem no Senhor.

SOLUÇÃO. — Dupla é a beatitude: a imperfeita, que conseguimos nesta vida; e a perfeita, que consiste
na visão de Deus. — Ora, é manifesto que a beatitude desta vida necessariamente implica o corpo. Pois
essa beatitude é operação do intelecto especulativo ou prático. E tal operação, nesta vida, não podendo
existir sem o fantasma, que só existe no órgão corpóreo, como na primeira parte já se viu, resulta que a
beatitude desta vida depende, de certo modo, do corpo.
Mas quanto à beatitude perfeita, uns ensinam que a alma, sem o corpo, não pode obtê-la. E dizem: as
almas dos santos, separadas dos corpos, não chegarão a tal beatitude, até o dia do juízo quando os
corpos ressurgirem. — Tal doutrina, porém, a rejeita como falsa, tanto a autoridade como a razão. — A
autoridade porque está na Escritura (2 Cor 5, 6): Enquanto estamos no corpo, vivemos ausentes do
Senhor; e acrescenta-se, mostrando a razão desse peregrinar: Porque andamos por fé e não por visão.
Donde resulta que, enquanto andamos por fé e não por visão, sem a visão da divina essência ainda não
estamos presentes a Deus. Ora, as almas dos Santos, separadas dos corpos, são-lhe presentes, e por isso
acrescenta-se: Mas temos confiança, e ansiosos queremos mais ausentar-nos do corpo, e estar
presentes ao Senhor. Por onde é manifesto, que essas almas, separadas dos corpos, andam por visão,
contemplando a essência de Deus, na qual consiste a verdadeira beatitude. — E isto mesmo também se
demonstra pela razão. Pois o intelecto, para a sua operação, só precisa do corpo por causa dos
fantasmas, nos quais descobre a verdade inteligível, como na primeira parte se disse. Ora, como
também já se demonstrou nessa mesma parte, a divina essência não pode ser vista pelos fantasmas.
Donde, consistindo a perfeita beatitude não depende do corpo humano, e portanto sem este a alma
pode ser feliz.
Cumpre porém saber que de duplo modo uma coisa respeita à perfeição de outra. Como lhe
constituindo a essência; assim, a alma é necessária à perfeição do homem. E como lhe contribuindo para
o bem estar, assim a beleza do corpo ou a presteza do engenho contribuem para a perfeição do homem.
Ora, embora o corpo não seja necessário à perfeição da beatitude humana, quanto ao primeiro modo, o
é contudo quanto ao segundo. Pois, dependendo a operação da natureza do ser, quanto mais perfeita
for a alma em sua natureza tanto mais perfeita será a sua operação, na qual consiste a felicidade, E por
isso Agostinho, indagando se aos espíritos dos defuntos, sem corpos pode ser concedida a suma
beatitude, responde: não podem ver a incomutável substância, como a vêm os anjos, seja por uma
causa mais oculta, seja porque há neles um certo desejo natural de governar o corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A beatitude é a perfeição da alma, quanto ao intelecto,
pelo qual ela transcende os órgãos do corpo; não porém que seja a forma natural deste. Por onde, essa
perfeição natural permanece, pela qual à alma é devida a beatitude; embora não permaneça a perfeição
da natureza pela qual é a forma do corpo.

RESPOSTA À SEGUNDA. — A alma se comporta, em relação à existência, diferentemente das outras
espécies de partes. Pois a existência do todo não é a de cada uma das suas partes. Por onde, destruído o
todo, ou a parte deixa totalmente de existir, como as partes do animal, quando este é destruído. Ou, se
permanecem, têm existência atual diversa, como a parte da linha que tem existência diversa da linha
total. Ora, à alma uma lhe resta a existência de composto, depois da destruição do corpo. E isto porque
a existência da matéria é a mesma que a da forma, o que vem a ser a existência mesma do composto.
Ora, a alma subsiste no seu ser, como na primeira parte se demonstrou. Donde se conclui que, depois
da separação do corpo, tem o ser perfeito, e portanto é susceptível de operação perfeita, embora não
tenha a natureza perfeita da espécie.

RESPOSTA À TERCEIRA. — O homem, tendo a beatitude pelo intelecto, pode, permanecendo este,
possuir aquela. Assim como os dentes de um Etíope que permitem seja considerado branco, podem ser
alvos, mesmo depois de arrancados.

RESPOSTA À QUARTA. — De duplo modo pode uma coisa ser impedida por outra. Por contrariedade,
como quando o frio impede a ação do calor; e tal impedimento da operação repugna à felicidade. E por
defeito, como quando a coisa impedida não tem tudo o que implica a sua omnímoda perfeição; e tal
impedimento da operação não repugna à felicidade, senão a omnímoda perfeição dela. Assim dizemos
que a separação da alma do corpo a retarda a tender, com toda a contensão, a visão da divina essência.
Pois, ela deseja gozar de Deus de modo que essa fruição redunde no corpo, como é possível. E portanto,
enquanto frui de Deus, sem o corpo, o seu apetite repousa, no que possui, de modo tal que quereria
que o seu corpo disso obtivesse participação.

RESPOSTA À QUINTA. — O desejo da alma separada se satisfaz totalmente, quanto ao desejável, pois,
tem o que basta ao apetite. Mas não se satisfaz totalmente quanto ao apetente, que não possui o bem
na totalidade do modo por que quereria possuí-lo. E portanto, reassumido o corpo, a beatitude
aumenta, não intensiva, mas extensivamente.

RESPOSTA À SEXTA. — O que se diz no passo aduzido, que os espíritos dos defuntos não vêm a Deus
como os anjos, não se deve entender quanto à desigualdade quantitativa, porque, já agora, certas almas
de Santos foram elevadas às ordens superiores dos anjos, e vêm a Deus mais claramente que os anjos
inferiores. Mas deve ser entendido quanto à desigualdade proporcional, porque os anjos, mesmo os
íntimos, têm toda a perfeição da beatitude que deverão ter; não, porém, as almas separadas dos Santos.

## Art. 6 — Se a perfeição do corpo é necessária à perfeita beatitude do homem.
(III, q. 15, a . 10; IV Sent., dist. XLIX, q. 4, a . 5, q ª2).
O sexto discute-se assim. — Parece que a perfeição do corpo não é necessária à perfeita beatitude do
homem.

1. — Pois, a perfeição do corpo é um bem temporal. Ora, como já se demonstrou, a beatitude não
consiste nos bens corpóreos. Logo, à beatitude do homem não é necessária nenhuma perfeita
disposição do corpo.

2. Demais. — A beatitude do homem consiste na visão da divina essência, como já se demonstrou. Ora,
para esta operação em nada contribui o corpo, conforme se disse. Logo, nenhuma disposição do corpo é
necessária à beatitude.

3. Demais. — Quanto mais abstrato do corpo for o intelecto, tanto mais perfeitamente intelige. Ora, a
beatitude consiste na operação perfeitíssima do intelecto. Logo, necessariamente há de a alma, de
todos os modos, ser abstrata do corpo. Portanto, de nenhum modo é necessária qualquer disposição
deste para a beatitude.
Mas, em contrário. — O prêmio da virtude é a beatitude, donde o dito da Escritura (Jo 13, 17): Bem-
aventurados sereis, se as praticardes. Mas por seu lado, é prometida aos Santos, como prêmio, não só a
visão de Deus e a deleitação, mas também a boa disposição do corpo, segundo Isaías (Is 66, 14): Vós o
vereis, e folgará o vosso coração, e os vossos ossos como erva brotarão. Logo, a boa disposição do corpo
é necessária à beatitude.

SOLUÇÃO. — Se nos referimos à beatitude do homem tal qual pode ser obtida nesta vida, é claro que
ela implica a boa disposição do corpo. Pois, essa beatitude consiste, segundo o Filósofo, na operação da
virtude perfeita. Ora, é manifesto, que pela invalidade do corpo o homem pode ser impedido de toda
atividade virtuosa.
Se nos referimos porém à beatitude perfeita, então alguns afirmam que lhe não é necessária nenhuma
disposição do corpo, antes é necessário que a alma esteja completamente separada dele. E por isso
Agostinhocita as palavras de Porfírio: para a alma ser feliz deve estar separada de qualquer corpo. —
Mas tal doutrina é inadmissível, porque sendo natural à alma estar unida a um corpo, não é possível que
a perfeição dela exclua a sua natural perfeição.
Por onde, devemos admitir que à beatitude perfeita implica a todos os respeitos, a perfeita disposição
do corpo, tanto antecedente como conseqüentemente. — Antecedentemente, porque, como diz
Agostinho, sendo o corpo tal que o seu governo seja difícil e oneroso, como a carne que corrompe e
onera a alma, a alma desvia-se da visão do sumo céu. Donde conclui que, quando o corpo atual já não
for animal, mas espiritual, então equiparar-se-á aos anjos e ser-lhe-á glória o que lhe foi empecilho. — E
conseqüentemente, porque a beatitude da alma redundará no corpo, de modo que este entre em posse
da sua perfeição. E por isso diz Agostinho: Deus fez a alma de tão poderosa natureza, de modo a
redundar a sua pleníssima beatitude, em a natureza inferior, o vigor da incorrupção.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A beatitude não consiste no bem corpóreo, como seu
objeto; mas, tal bem pode contribuir para o decoro ou perfeição da beatitude.

RESPOSTA À SEGUNDA. — Embora o corpo não contribua, em nada, para a operação do intelecto pela
qual vemos a essência de Deus, pode contudo impedir essa visão. Por isso, é necessária a perfeição do
corpo para não ficar impedida a elevação da mente.

RESPOSTA À TERCEIRA. — A perfeita operação do intelecto implica por certo a separação deste corpo
corruptível, que onera a alma; não porém a do corpo espiritual, que estará totalmente sujeito ao
espírito. E disto tratará a terceira parte desta obra.

## Art. 7 — Se para a beatitude são também necessários bens externos.
(2.2, q. 186, a 3, ad 4).
O sétimo discute-se assim. — Parece que para a beatitude são também necessários os bens externos.

1. — Pois o prometido aos Santos como prêmio se conclui na beatitude. Ora, a eles lhe estão
prometidos os bens externos, como a comida e a bebida, as riquezas e o reinado, conforme a Escritura
(Lc 22,30): Para que comais e bebais à minha mesa no meu reino: Mas entesourai para vós tesouros no
céu; e (Mt 6, 20): Vinde benditos de meu Pai, possui o reino. Logo, para a beatitude, são necessários os
bens externos.

2. Demais. — Segundo Boécio, a beatitude é o estado perfeito pela reunião de todos os bens. Ora, os
bens externos são bens do homem, embora mínimos, como diz Agostinho. Logo, também eles são
necessários para a beatitude.

3. Demais. — O Senhor diz (Mt 5, 12): O vosso galardão é copioso nos céus. Ora, estar nos céus significa
estar em um lugar. Logo, ao menos um lugar externo é necessário para a beatitude.
Mas, em contrário, diz a Escritura (Sl 72, 25): Pois que tenho eu no céu? E, fora de ti, que desejei eu
sobre a terra? Que é como se dissesse: Não quero senão o seguinte — (72, 28) para mim é bom unir-me
a Deus. Logo, além de Deus nada mais é necessário à beatitude.

SOLUÇÃO. — Para a beatitude imperfeita, tal como pode ser alcançada nesta vida, são necessários os
bens externos; não que lhe constituam a essência, mas como lhe servindo de instrumento, a ela que
consiste na operação da virtude, como diz Aristóteles. Pois, precisa o homem nesta vida de bens
necessários ao corpo, para a atividade — tanto da virtude contemplativa como da ativa; sendo-lhe
ainda, para esta, necessários muitos outros bens pelos quais exerça as obras da virtude ativa.
Para a beatitude perfeita porém, que consiste na visão de Deus, de nenhum modo são necessários tais
bens. E a razão é que todos os bens externos são necessários ou para o sustento do corpo animado, ou
para certas operações adequadas à vida humana e as quais exercemos pelo corpo animado. Mas, a
perfeita beatitude consistente na visão de Deus, há de tê-la a alma sem o corpo, ou unida ao corpo, não
já animal, mas espiritual. E portanto, de nenhum modo tais bens externos, ordenados à vida animal, são
necessários à beatitude. E sendo, nesta vida, a felicidade contemplativa mais semelhante a Deus, mais
que a ativa se assemelha à perfeita beatitude, como resulta do que já foi dito, e portanto, necessita
menos dos referidos bens do corpo, como diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todas as promessas materiais contidas na Sagrada
Escritura devem entender-se metaforicamente, pois nelas se costumam designar as coisas espirituais
por meio das corpóreas, para das coisas conhecidas, nos elevarmos a desejar as desconhecidas, como
diz Gregório numa homilia. Assim, pela comida e pela bebida se entende a deleitação da beatitude;
pelas riquezas, a suficiência pela qual ao homem basta Deus; pelo reinado, a exaltação do homem até a
união com Deus.

RESPOSTA À SEGUNDA. — Os referidos bens, que servem à vida animal, não cabem à vida espiritual, na
qual consiste a beatitude perfeita. E contudo, haverá nesta a reunião de todos os bens; pois, tudo o que
estes tem de bom, há de totalmente conter-se na suma fonte deles.

RESPOSTA À TERCEIRA. — Segundo Agostinho, do galardão dos Santos não se diz que estejam nos céus
corpóreos; mas, por céus entende-se a altura dos bens espirituais. – Contudo, haverá para os bem-
aventurados um lugar corpóreo, que é o céu empíreo; não que este seja necessário à beatitude, senão
por uma como congruência e decoro.

## Art. 8 — Se os amigos são necessários à beatitude.
O oitavo discute-se assim. — Parece que os amigos são necessários à beatitude.

1. — Pois, a beatitude futura é freqüentemente designada nas Escrituras com o nome de glória. Ora,
esta consiste em ser o bem de um homem levado ao conhecimento de muitos. Logo, à beatitude é
necessária a sociedade dos amigos.

2. Demais. — Boécio — (Sêneca) diz, que sem a sociedade não é agradável à posse de nenhum bem.
Ora, à beatitude implica a deleitação. Logo, também é necessária a sociedade dos amigos.

3. Demais. — A caridade se aperfeiçoa na beatitude. Ora aquela se estende ao amor de Deus e do
próximo. Logo, para esta é necessária a sociedade dos amigos.
Mas, em contrário, diz a Escritura (Sb 7, 11): E todos os bens me vieram juntamente com ela, i. é, com
divina sabedoria, que consiste na contemplação de Deus. E portanto, nada mais é necessário à
beatitude.

SOLUÇÃO. — Se nos referimos à felicidade da vida presente, o feliz precisa de amigos, como diz
Aristóteles; não certo por utilidade, pois basta–se a sim mesmo; nem pela deleitação, pois tem-na em si
mesmo perfeita, praticando a virtude; mas para beneficiá-los, para deleitar-se vendo-os bem fazer e
para ser, no bem fazer, coadjuvante por eles. Portanto, para bem obrar, o homem precisa de auxílio dos
amigos, tanto nas obras da vida ativa, como nas da contemplativa.
Mas, se nos referimos à beatitude perfeita da pátria, não implica necessariamente a sociedade dos
amigos, porque o homem tem a plenitude total da sua beatitude em Deus. Mas, tal sociedade contribui
para a existência completa da beatitude; donde o dizer Agostinho: para a criatura espiritual ser feliz
basta seja intrinsecamente coadjuvante pela eternidade, verdade e caridade do Criador; se porém deve
dizer-se que é coadjuvante extrinsecamente, talvez isso só se dê pela visão mútua e pelo gáudio da
sociedade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A glória essencial à beatitude é a que o homem tem, não
junto de outro homem, mas junto de Deus.

RESPOSTA À SEGUNDA. — A expressão citada deve entender-se como referente ao bem possuído, que
não tem plena suficiência. O que não se aplica no caso vertente, porque o homem tem em Deus a
suficiência de todos os bens.

RESPOSTA À TERCEIRA. — A perfeição da caridade é essencial à beatitude, quanto ao amor de Deus,
não do próximo. Por onde, se fosse uma única a alma que gozasse de Deus, ela seria feliz sem ter
próximo a quem amasse. Mas, suposto este, resulta o amor para com ele, do perfeito amor de Deus. Por
isso a amizade é como que concomitante à perfeita beatitude.