# Questão 68: Dos dons.
Em seguida devemos tratar dos dons. E sobre esta questão oito artigos se discutem.

## Art. 1 — Se os dons se distinguem das virtudes.
(III Sent., dist. XXXIV, q. 1, a. 1; In Isaiam, cap. XI; Ad Galat., cap. V lect. VI).
O primeiro discute-se assim. — Parece que os dons não se distinguem das virtudes.

1. — Pois, Gregório, expondo aquilo de Jó (Jó 1, 2) — E nasceram-lhe sete filhos e três filhas —
diz: Nascem-se sete filhos quando pela concepção do bom pensamento surgem em nós as sete virtudes
do Espírito Santo. E cita aquilo da Escritura (Is 11, 2): E descansará sobre ele o espírito de entendimento,
etc., onde se enumeram os sete dons do Espírito Santo. Logo, estes sete dons são virtudes.

2. Demais. — Agostinho, expondo aquilo da Escritura (Mt 12, 45) — Então vai, e ajunta a si outros sete
espíritos etc. — diz: Sete vícios são contrários às sete virtudes do Espírito Santo, i. é, aos sete dons. Ora,
esses sete vícios são contrários às virtudes consideradas em sentido geral. Logo, os dons não se
distinguem das virtudes consideradas nesse sentido.

3. Demais. — Sujeitos a que convém a mesma definição são idênticos. Ora, a definição da virtude
convém aos dons; pois, o dom é uma boa qualidade da mente, pela qual vivemos retamente, etc.
Semelhantemente, a definição do dom convém às virtudes infusas; pois, o dom é uma doação
irretribuível, segundo o Filósofo. Logo, as virtudes não se distinguem dos dons.

4. Demais. — Alguns dos chamados dons são virtudes. Pois, como já se disse, a sabedoria, o intelecto e a
ciência são virtudes intelectuais; o conselho pertence à prudência; a piedade é uma espécie de justiça; e
por fim, a coragem é uma virtude moral. Logo, as virtudes não se distinguem dos dons.
Mas, em contrário, Gregório distingue os sete dons, designados, diz, pelos sete filhos de Jó, das três
virtudes teologais, representadas pelas três filhas do mesmo. E noutro lugar, distingue os mesmos sete
dons, das quatro virtudes cardeais., representadas, diz, pelos quatro ângulos da casa.

SOLUÇÃO. — Se considerarmos o dom e a virtude, quanto às suas noções, nenhuma oposição há entre
esta e aquele. Pois, a virtude, por essência, é assim chamada por conferir ao homem a perfeição de agir
retamente, como já dissemos; ao passo que o dom essencialmente é relativo à causa de onde procede.
Ora, nada impede, que o precedente, como dom, de uma certa causa, confira a quem o recebe a
perfeição de agir retamente; sobretudo que, como já dissemos, certas virtudes são infundidas em nós
por Deus. Por onde, a esta luz, o dom não pode ser distinto da virtude.
E por isso certos ensinaram não devem os dons ser distintos das virtudes. — Mas nem por isso deixa de
lhes ser menor a dificuldade, quando se trata de dar a razão de se considerarem certas virtudes, e não
todas, como dons; e de certos dons não se contarem evidentemente entre as virtudes, como, p. ex., o
temor.
E daí o dizerem outros que os dons se devem distinguir das virtudes, mas sem darem suficiente causa de
distinção, de tal modo comum às virtudes que de nenhum modo conviesse aos dons, e vice-versa. E
então outros, considerando que, dentre os sete dons, quatro — a sabedoria, a ciência, o intelecto e o
conselho —pertencem à razão; e três — a coragem, a piedade e o temor — à potência apetitiva,
disseram que dons fortificam o livre arbítrio, enquanto faculdade racional, e as virtudes, enquanto
faculdade voluntária. E isso por descobrirem só duas virtudes — a fé e a prudência — na razão ou
intelecto, pertencendo às outras à potência apetitiva ou afetiva. Ora, seria necessário, se esta distinção
fosse pertinente, todas as virtudes pertencerem à potência apetitiva, e todos os dons, à razão.
Outros ainda, tiveram em vista o lugar de Gregório seguinte: o dom do Espírito Santo que forma, na
mente que lhe é obediente, a prudência, a temperança, a justiça e a fortaleza, também a mune, pelos
sete dons, contra todas as tentações. E consideraram então as virtudes como ordenadas a obrar bem e
os dons, a resistir às tentações. — Mas esta distinção também não é suficiente. Pois, também as
virtudes resistem às tentações, que induzem aos pecados e que as contrariam pois cada um resiste ao
que lhe é contrário, como bem vemos suceder com a caridade, da qual se diz (Ct 8, 7): as muitas águas
não puderam extinguir a caridade. Outros, por fim, refletindo que a Escritura nos transmite esses dons
como existiram em Cristo, disseram que as virtudes se ordenam, absolutamente, ao bem agir; ao passo
que os dons nos tornam semelhantes a Cristo, principalmente quanto aos seus sofrimentos, pois os
dons de que tratamos resplenderam principalmente na sua paixão. Mas também isto não é suficiente.
Pois, o próprio Senhor nos induz precipuamente a nos assemelhar com ele pela humildade e pela
mansidão, conforme está na Escritura (Mt 11, 29): aprendei de mim, que sou manso e humilde de
coração; e também pela caridade, conforme àquilo (Jo 13, 34): Que vos amei uns aos outros, assim
como eu vos amei. Ora, estas virtudes resplandeceram, precipuamente, na paixão de Cristo.
E portanto, para distinguir os dons, das virtudes, devemos seguir o modo de falar da Escritura, que no-
los transmite, não sob o nome de dons, mas antes, sob o de espíritos. Assim, diz Isaias (11, 2): E
descansará sobre ele o espírito de sabedoria e de entendimento etc. Essas palavras dão manifestamente
a entender que tal enumeração dos sete dons os supõe existentes em nós por inspiração divina; e a
inspiração implica uma moção externa. Ora, devemos considerar que há no homem um duplo princípio
motor: um, interior — a razão; outro exterior — Deus, como já dissemos; e o Filósofo também diz o
mesmo. Ora, como é manifesto, todo o movido deve necessariamente ser proporcionado ao motor; e a
perfeição do móvel, como tal, consiste em ter uma disposição que o faça bem receber o movimento do
motor. Quanto mais elevado porém for o motor, tanto mais necessariamente, e por uma disposição
mais perfeita, o móvel se lhe há de proporcionar; assim, vemos ser necessário o discípulo dispor-se
tanto mais perfeitamente, a receber a doutrina do mestre, quanto mais perfeita ela for. Ora, é
manifesto que as virtudes humanas aperfeiçoam o homem, ao qual é natural ser movido pela razão, em
todos os seus atos, interior ou exteriormente. Logo, é necessário existam no homem perfeições mais
altas que o disponham a ser movido por Deus. E tais perfeições se chamam dons, não só por serem
infundidos por Deus, mas também por disporem o homem a se deixar facilmente mover pela inspiração
divina, como diz Isaías (50, 5): O Senhor me abriu o ouvido, e eu o não contradigo; não me retirei para
traz. E o Filósofo também diz: quando movidos por inspiração divina não devemos buscar conselho na
razão humana, mas seguir essa inspiração, porque somos movidos por um principio superior à razão
humana. E assim o entendem os que dizem aperfeiçoarem os dons o homem para atos superiores aos
da virtude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os dons em questão também se denominam virtudes,
conforme a noção comum de virtude. Tem contudo algo de supereminente a essa noção, por serem
certas virtudes divinas que aperfeiçoam o homem, enquanto movido por Deus. E por isso o Filósofo
introduz, além da virtude comum, uma virtude heróica ou divina, que faz certos serem
chamados homens divinos.

RESPOSTA À SEGUNDA. — Os vícios sendo contrários aos bens da razão também contrariam as virtudes;
como contrários, porém, à divina inspiração, contrariam os dons. Ora, contrariar a Deus é também
contrariar a razão, cujo lume deriva de Deus.

RESPOSTA À TERCEIRA. — A definição em apreço se dá da virtude quanto ao seu modo comum de ser.
Por onde, se quisermos restringir a definição às virtudes, enquanto distintas dos dons, diremos que a
expressão —pela qual vivemos retamente — deve ser entendida da retidão da vida conforme a regra da
razão. Semelhantemente, o dom, enquanto distinto da virtude infusa, pode ser considerado como o
dado por Deus para lhe recebermos a moção, que leva o homem a seguir retamente as suas inspirações.

RESPOSTA À QUARTA. — A sabedoria se chama virtude intelectual, enquanto procede do juízo da razão.
Chama-se porém, dom, enquanto obra por instinto divino. E o mesmo se deve dizer nos demais casos.

## Art. 2 — Se os dons são necessários à salvação do homem.
O segundo discute-se assim. — Parece não serem os dons necessários à salvação do homem.

1. — Pois, os dons se ordenam a uma certa perfeição, que ultrapassa a perfeição comum da virtude.
Ora, não é necessário à sua salvação o homem conseguir tal perfeição, que ultrapasse o estado comum
da virtude, pois tal perfeição não é objeto de preceito, mas de conselho. Logo, os dons não são
necessários à salvação do homem.

2. Demais. — Para a sua salvação basta ao homem proceder bem em relação ao divino e ao humano.
Ora, pelas virtudes teologais o homem procede bem em relação ao divino; e pelas morais, em relação ao
humano. Logo, os dons não lhe são necessários para a salvação.

3. Demais. — Gregório diz, que o Espírito Santo dá a sabedoria, contrária à estultícia; o intelecto,
contrário ao embotamento; o conselho, contrário à precipitação; a coragem, contrária ao temor; a
ciência, contrária à ignorância; a piedade, contrária à dureza; e, contrário à soberba, o temor. Ora, as
virtudes constituem remédio suficiente para se extirparem todos esses vícios. Logo, os dons não são
necessários à salvação do homem.
Mas, em contrário. — O mais elevado dos dons é a sabedoria; e o ínfimo, o temor. Ora, ambos são
necessários à salvação, pois da sabedoria diz a Escritura (Sb 7, 28): Porque Deus a ninguém ama senão
ao que habita com a sabedoria; e do temor (Ecle 1, 28): Porque aquele que está sem temor não poderá
ser justificado. Logo, também os dons médios são necessários à salvação.

SOLUÇÃO. — Como já se disse, os dons são umas perfeições do homem, que o dispõem a seguir
facilmente o instinto divino. Por onde, quando não basta o instinto da razão, mas é necessário o do
Espírito Santo, é, por conseqüência, também necessário o dom.
Ora, Deus aperfeiçoa a razão do homem de dois modos: naturalmente, i. é, pelo lume da razão natural;
e por uma perfeição sobrenatural, que são as virtudes teologais, como já dissemos. E embora esta
segunda perfeição seja maior que a primeira, contudo a primeira o homem a tem de modo mais perfeito
que a segunda. Pois, aquela ele a tem de posse plena; esta, imperfeitamente, pois amamos e
conhecemos a Deus imperfeitamente. Ora, é manifesto que o ser de natureza, forma ou virtude
perfeita, pode, por si mesmo, obrar por meio delas, sem excluir contudo a ação de Deus, que obra
interiormente em toda natureza e em toda vontade. Mas o ser de natureza, forma ou virtude imperfeita
não pode obrar por si, se não for movido por outro. Assim, o sol, perfeitamente lúcido, pode iluminar
por si mesmo; porém a lua, que tem imperfeitamente a natureza da luz, não ilumina senão iluminada.
Também o médico conhecedor perfeito da arte médica, pode obrar por si; mas, o seu discípulo, ainda
não plenamente instruído não o pode, se não for instruído por aquele.
Por onde, quanto ao que cai sob a alçada da razão humana, em ordem ao fim conatural ao homem, este
pode obrar pelo juízo da razão. — Haverá, porém uma bondade superabundante se, mesmo nesse caso,
Deus o ajudar por um instinto especial. Por onde, segundo os filósofos, nem todos os que tinham
virtudes morais adquiridas as tinham heróicas ou divinas. Porém, em relação ao fim último sobrenatural,
ao qual a razão nos move enquanto informada, de certo modo e imperfeitamente pelas virtudes
teologais, essa moção por si mesma não basta, se não lhe advier do alto o instinto e a moção do Espírito
Santo, conforme àquilo da Escritura (Rm 8, 14.17): Porque todos os que são levados pelo Espírito de
Deus, estes tais são filhos e herdeiros de Deus; e ainda (Sl 142, 10): O teu espírito que é bom me
conduzirá à terra de retidão. Pois, a herança daquela terra dos bem-aventurados ninguém a pode
alcançar se não for movido e conduzido pelo Espírito Santo. E portanto, para conseguir esse fim, é
necessário ao homem ter o dom do Espírito Santo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os dons excedem a perfeição comum das virtudes, não
quanto ao gênero das obras, do modo pelo qual os conselhos precedem os preceitos; mas quanto ao
modo de obrar, enquanto o homem é movido por um princípio mais alto.

RESPOSTA À SEGUNDA. — As virtudes teologais e morais não aperfeiçoam o homem em ordem ao
último fim, de modo que ele não precise de ser movido por um certo instinto superior do Espírito Santo,
pela razão já dita.

RESPOSTA À TERCEIRA. — A razão humana não pode conhecer tudo, nem tudo lhe é possível, quer a
consideremos como dotada de perfeição natural, quer como aperfeiçoada pelas virtudes teologais. E
por isso não pode livrar-se sempre da estultícia, e do mais que lembra a objeção. Mas aquele, a cuja
ciência e poder tudo está sujeito, nos livra, pela sua moção, de toda estultícia, ignorância,
embotamento, dureza e demais deficiências. Por onde, os dons do Espírito Santo, que nos levam a lhe
seguir docilmente o instinto, se consideram dados contra essas deficiências.

## Art. 3 — Se os dons do Espírito Santo são hábitos.
O terceiro discute-se assim — Parece que os dons do Espírito Santo não são hábitos.

1. — Pois, o hábito, sendo uma qualidade dificilmente mutável, como se disse, é qualidade permanente
no homem. Ora, é próprio de Cristo, que os dons do Espírito Santo nele descansem, como diz a Escritura
(Is 11, 2). E noutro lugar (Jo 1, 33): Aquele sobre que tu vires descer o Espírito, e repousar sobre ele,
esse é o que batiza. E Gregório, expondo este texto diz: O Espírito Santo vem ter com todos os fiéis, mas
permanece singularmente só com o Mediador. Logo, os dons do Espírito Santo não são hábitos.

2. Demais. — Os dons do Espírito Santo aperfeiçoam o homem, levando-o pelo Espírito de Deus, como já
se disse. Ora, levado por esse Espírito, o homem desempenha o papel de instrumento em relação a ele.
Ora, não é próprio do instrumento ser aperfeiçoado por um hábito, senão do agente principal. Logo, os
dons do Espírito Santo não são hábitos.

3. Demais. — Assim como os dons do Espírito Santo provêm da inspiração divina, assim também o dom
da profecia. Ora, este não é hábito, pois o espírito de profecia não está sempre presente ao profeta,
como diz Gregório. Logo os dons do Espírito Santo também não são hábitos.
Mas, em contrário, o Senhor diz aos discípulos, falando do Espírito Santo (Jo 14, 17): Ele ficará conosco e
estará em vós. Ora, o Espírito Santo não está no homem sem os seus dons. Logo, estes ficam nos
homens e, portanto, não são só atos ou paixões, mas também hábitos permanentes.

SOLUÇÃO. — Como já se disse, os dons são certas perfeições do homem, que o tornam bem disposto a
seguir o instinto do Espírito Santo. Ora, é manifesto, pelo sobredito, que as virtudes morais aperfeiçoam
a potência apetitiva, fazendo-a participar, de certo modo, da razão, pois lhe é natural ser movida pelo
império desta última. Por onde, os dons do Espírito Santo estão para o homem, relativamente ao
Espírito, como as virtudes morais para a potência apetitiva, relativamente à razão. Ora, as virtudes
morais são hábitos que dispõem as potências apetitivas a obedecerem prontamente à razão. Por onde,
também os dons do Espírito Santo são hábitos que tornam apto o homem a obedecer prontamente a
esse Espírito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Gregório, no mesmo passo aduzido, solve a dificuldade
dizendo:O Espírito Santo permanece sempre em todos os eleitos, quanto aos dons sem os quais não
podem chegar à vida eterna; mas, quanto aos outros, nem sempre permanece. Ora, os sete dons são
necessários à salvação, como já dissemos. Logo, quanto a eles, o Espírito Santo sempre permanece nos
santos.

RESPOSTA À SEGUNDA. — A objeção procede quanto ao instrumento, que não age, mas é somente
passivo. Ora, o homem não é tal instrumento, pois, dotado de livre arbítrio, também assim age quando
levado pelo Espírito Santo. Logo, precisa de um hábito.

RESPOSTA À TERCEIRA. — A profecia é um dos dons que servem à manifestação do Espírito, e não é de
necessidade para a salvação. Por onde, não há símile.

## Art. 4 — Se são convenientemente enumerados os sete dons do Espírito Santo.
(IIª – IIªe, q. 8, a, 6; III Sent., dist. XXXIV, q. 1, a. 2; In Isaiam, cap. XI).
O quarto discute-se assim. — Parece que os sete dons do Espírito Santo são inconvenientemente
enumerados.

1. — Pois, nessa enumeração se incluem quatro elementos pertencentes às virtudes intelectuais: a
sabedoria, o intelecto, a ciência e o conselho, pertencentes à prudência; e nela não se inclui nada
relativo à arte, a quinta virtude intelectual. Semelhantemente, essa enumeração inclui a piedade,
pertinente à justiça; o dom da fortaleza, pertencente à fortaleza, e nada inclui pertinente à temperança.
Logo, os dons estão insuficientemente enumerados.

2. Demais. — A piedade faz parte da justiça. Ora, a enumeração inclui a fortaleza e não qualquer parte
da mesma. Logo, também não devia incluir a piedade, mas, a justiça.

3. Demais. — As virtudes teologais se ordenam principalmente para Deus. Ora, como os dons
aperfeiçoam o homem para se mover para Deus, à enumeração devia incluir também certos dons
pertinentes às virtudes teologais.

4. Demais. — Assim como tememos a Deus, também o amamos, nele esperamos, com ele nos
comprazemos. Ora, o amor, a esperança e o prazer são paixões que entram na mesma divisão do temor.
Logo, se este é considerado como um dom, também dons haveriam de ser as três paixões.

5. Demais. — Ao intelecto se acrescenta a sabedoria, que o rege; à fortaleza, o conselho; à piedade, a
ciência. Logo, também ao temor devia ser acrescentado algum dom diretivo; e, portanto, são
inconvenientemente enumerados os sete dons do Espírito Santo.
Mas, em contrário, é a autoridade da Escritura (Is 11, 2-3).

SOLUÇÃO. — Como já dissemos, os dons são uns hábitos que tornam o homem apto a seguir
prontamente o instinto do Espírito Santo, assim como as virtudes morais aperfeiçoam as potências
apetitivas para obedecerem à razão. Ora, assim como é natural a estas serem movidas pelo império da
razão, assim é natural a todas as potências humanas serem movidas pelo instinto de Deus, como por um
poder superior. Logo, todas as potências, que podem ser princípios de atos humanos, i. é, a razão e a
potência apetitiva, são susceptíveis tanto de virtudes como de dons. Ora, a razão ou é especulativa ou
prática, e ambas consideram a apreensão da verdade, conducente a um conhecimento ulterior, e o juízo
sobre a verdade. — Ora, para apreender a verdade, a razão especulativa é aperfeiçoada pelo intelecto, e
a prática, pelo conselho. — E para julgar retamente, a especulativa é aperfeiçoada pela sabedoria, e a
prática, pela ciência.
Por seu lado, a potência apetitiva, em nossas relações com outrem, é aperfeiçoada pela piedade; no
referente a nós mesmos, pela fortaleza, no concernente ao temor dos perigos; e pelo temor, no relativo
ao desejo desordenado dos prazeres, conforme aquilo da Escritura (Pr 15, 27): todo o homem evita o
mal por meio do temor do Senhor; e (Sl 118, 120): Transpassa com o seu temor as minhas carnes,
porque tenho temido os teus juízos.
Por onde é claro que os dons em apreço têm a mesma extensão que as virtudes, tanto intelectuais como
morais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os dons do Espírito Santo aperfeiçoam o homem no
concernente ao bem viver, o que não faz a arte, que se ocupa com as produções externas, pois ela é a
razão reta das coisas factíveis, e não das ações, como se disse. Pode-se contudo dizer que, quanto à
infusão dos dons, a arte pertence ao Espírito Santo, principal motor; e não, aos homens, que lhe servem
como de instrumentos, enquanto por ele movidos. A temperança, por seu lado, responde, de certo
modo, ao temor. Pois, assim como é próprio à virtude da temperança, por essência, fazer-nos preferir o
bem da razão aos maus prazeres, assim é próprio ao dom do temor fazer-nos preferir o temor de Deus a
esses maus prazeres.

RESPOSTA À SEGUNDA. — A palavra — justiça — deriva da retidão da razão; e portanto convém-lhe
mais a denominação de virtude que de dom. Ao passo que a piedade implica a reverência para com os
pais e a pátria. E como Deus é Pai de todos os seres, também ao seu culto se chama piedade, como diz
Agostinho. E, portanto, chama-se convenientemente piedade ao dom pelo qual, reverenciando a Deus,
fazemos o bem para com todos.

RESPOSTA À TERCEIRA. — A nossa alma não é movida pelo Espírito Santo se não se lhe estiver unida, de
cedo modo; assim como o instrumento não é movido pelo artífice, senão por contato ou por qualquer
outra união. Ora, a primeira forma de união se dá pela fé, pela esperança e pela caridade. Por onde,
estas virtudes se pressupõem aos dons, sendo-lhes, como as raízes. E portanto, todos os dons
pertencem a essas três virtudes, como derivações delas.

RESPOSTA À QUARTA. — O amor, a esperança e o prazer têm o bem como objeto. Ora, o sumo bem é
Deus. Por onde, os nomes dessas três paixões se transferem às virtudes teologais, pelas quais o homem
se une a Deus. Ao passo que o objeto do temor é o mal, que em Deus de nenhum modo existe. Logo, ele
não implica união com Deus, mas antes, afastamento de certas causas, pela reverência para com Deus, E
portanto, não denomina nenhuma virtude teologal, mas um dom que nos retrai do mal, de modo mais
eminente que a virtude moral.

RESPOSTA À QUINTA. — A sabedoria dirige tanto o intelecto como o afeto do homem. E por isso se
põem dois dons diretivos, correspondentes à sabedoria: para a inteligência, o dom do intelecto; para o
afeto, o do temor. Pois, a razão de temer a Deus se funda precìpuamente na consideração da excelência
divina, que a sabedoria considera.

## Art. 5 — Se os dons são conexos.
(III Sent., dist. XXXVI, a. 3).
O quinto discute-se assim. — Parece que os dons não são conexos.

1. — Pois, diz o Apóstolo (1 Cor 12, 8): Porque a um pelo Espírito é dada a palavra de sabedoria; a outra
porém a palavra de ciência, segundo o mesmo Espírito. Ora, a sabedoria e a ciência se incluem entre os
dons do Espírito Santo. Logo, esses dons são atribuídos a diversos e não tem conexão mútua, num
mesmo sujeito.

2. Demais. — Agostinho diz, que muitos fiéis, embora possuam a fé, não possuem a ciência. Ora, a fé é
acompanhada por algum dom, ao menos pelo temor. Logo, os dons não estão necessariamente conexos
num mesmo sujeito.

3. Demais. — Gregório diz: a sabedoria será menor se estiver privada do intelecto, e este será muito
inútil, se não subsistir pela sabedoria; vil é o conselho a que falta a robustez da fortaleza; e esta será
completamente destruída, se não se apoiar no conselho; a ciência será nula se não tiver a utilidade da
piedade; e esta será de todo inútil, se carecer do discernimento da ciência; e também o próprio temor,
sem as virtudes supra enumeradas, deixará de servir a realização de qualquer boa ação. Por onde,
podemos ter um dom sem ter os outros, Logo, os dons do Espírito Santo não são conexos.
Mas, em contrário, o que antes já havia dito Gregório: Nesse convívio de filhos, devemos perscrutar
como se nutrem mutuamente. Ora, por filhos de Jó, de que agora fala, entendem-se os dons do Espírito
Santo. Logo, estes são conexos por se alimentarem uns dos outros.

SOLUÇÃO. — A verdade sobre esta questão pode facilmente presumir-se do já dito. Pois, como já
dissemos, assim como as potências apetitivas se dispõem, pelas virtudes morais, dependentemente do
regime da razão, assim, todas as virtudes da alma se dispõem pelos dons, dependentemente da moção
do Espírito Santo. Ora, este habita em nós pela caridade, conforme aquilo da Escritura (Rm 5, 5): a
caridade de Deus está derramada em nossos corações pelo Espírito Santo, que nos foi dado, assim como
a nossa razão se aperfeiçoa pela prudência. Por onde, assim como as virtudes morais se ligam umas às
outras por meio da prudência, assim os dons do Espírito Santo, pela caridade, de modo tal que, quem
tiver tem todos os dons do Espírito, e ninguém os pode ter sem a caridade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Num sentido, a sabedoria e a ciência podem ser
consideradas graças dadas gratuitamente; i. é, de modo tal que tenhamos tanta abundância do
conhecimento das coisas divinas e humanas, que possamos instruir os fiéis e refutar os adversários. E é
nesse sentido que o Apóstolo, no passo aduzido, considera a sabedoria e a ciência; sendo, por isso que,
assinaladamente, se refere à palavra da sabedoria e da ciência. — Noutro sentido, essas palavras podem
ser tomadas como exprimindo dons do Espírito Santo. E então, não significam senão certas perfeições
da mente humana que a dispõem bem para seguir o instinto do Espírito Santo, no conhecimento das
causas divinas e humanas. Por onde é claro que tais dons existem em todos os que têm caridade.

RESPOSTA À SEGUNDA. — No lugar citado, Agostinho se refere à ciência, expondo o passo aduzido do
Apóstolo. E por isso, ele a toma no primeiro sentido exposto, i. é, como graça dada gratuitamente. E isso
é claro pelo que acrescenta: Uma coisa é saber só o que o homem deve crer para alcançar a vida feliz,
que não é senão a eterna; outra, como há de proporcioná-lo às piedosas e defendê-lo contra os ímpios,
e isto é ao que o Apóstolo chama propriamente ciência.

RESPOSTA À TERCEIRA. — Assim como, de um modo, a conexão das virtudes cardeais se prova por se
aperfeiçoarem, de certo modo, umas às outras, como já dissemos, assim também Gregório pretende
provar a conexão dos dons por não poder um ser perfeito sem o outro. E por isso dissera antes: Cada
uma das virtudes desaparecerá de todo, se não se auxiliarem todas entre si: Donde não se conclui que
um dom possa existir sem os outros, mas que o intelecto não seria dom, se existisse sem a sabedoria,
assim como sem a justiça, a temperança não seria virtude.

## Art. 6 — Se os dons do Espírito Santo permanecem na pátria.
(III Sent., dist. XXXIV. a. 3).
O sexto discute-se assim. — Parece que os dons do Espírito Santo não permanecem na pátria.

1. — Pois como diz Gregório, o Espírito Santo inspira a mente com os sete dons, contra todas as
tentações. Ora, na pátria não haverá tentações, conforme aquilo da Escritura (Is 11, 9): Eles não farão
dano algum, nem matarão em todo o meu santo monte. Logo, na pátria não haverá dons do Espírito
Santo.

2. Demais. — Os dons do Espírito Santo são hábitos, como já se disse. Ora, os hábitos seriam vãos sem a
existência dos atos; pois, diz Gregório: o intelecto faz-nos penetrar o que ouvimos, o conselho impede a
precipitação, a fortaleza faz-nos não temer a adversidade, e a piedade enche até as vísceras do coração
com obras de misericórdia. Ora, tudo isto não convém ao estado da pátria. Logo, no estado da glória
não existirão tais dons.

3. Demais. — Certos dons, como a sabedoria e o intelecto, aperfeiçoam o homem, na vida
contemplativa; outros, como a piedade e a fortaleza, na vida ativa. Ora, esta última se nos acaba com
esta vida, como diz Gregório. Logo, no estado da glória, não existirão todos os dons do Espírito Santo.
Mas, em contrário, diz Ambrósio: A cidade de Deus ou a Jerusalém celeste não será banhada pelo
percurso de nenhum rio terrestre; mas, o Espírito Santo, procedente da fonte da vida, de que nós nos
saciamos com um breve hausto, afluirá mais abundante aos espíritos celestes, com uma correnteza
plena e intumescida pelas sete virtudes espirituais.

SOLUÇÃO. — Podemos considerar os dons à dupla luz. — Quanto à essência, e então existirão
perfeitíssimamente na pátria, como está claro no lugar aduzido de Ambrósio. E a razão é que os dons do
Espírito Santo aperfeiçoam a mente humana para lhe seguir a moção, o que se dará principalmente na
pátria, quando Deus for tudo em todos, como diz a Escritura (1 Cor 15, 28), e quando o homem estiver
totalmente sujeito a Deus. — De outro modo, quanto à matéria sobre a qual operam; e então, na vida
atual, operam sobre uma matéria sobre a qual não operarão, no estado da glória. E portanto não
permanecerão na pátria, como já dissemos a propósito das virtudes cardeais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No lugar aduzido, Gregório se refere aos dons próprios
do estado presente, que nos protegem contra o ataque dos males. Mas, no estado da glória, cessados os
males, seremos aperfeiçoados no bem pelos dons do Espírito Santo.

RESPOSTA À SEGUNDA. — Gregório atribui, a cada um dos dons algo que passa com o estado presente,
e algo que permanece na vida futura. Pois, diz, que a sabedoria fortifica a mente na esperança e na
certeza das coisas eternas, e desses dois, a esperança passa, mas a certeza permanece. Do intelecto diz
que, penetrando as coisas ouvidas, e fortificando o coração ilumina-lhe as trevas; ora, o que é ouvido
passa porque, no dizer da Escritura (Jr 31, 34), não ensinará varão ao seu irmão; mas, a iluminação da
mente permanecerá. Do conselho diz, que impede a precipitação, o que é necessário à vida presente; e,
demais, que faz a alma abundar na razão, o que é necessário também na vida futura. Da fortaleza,
que não teme as adversidades, o que é necessário na vida presente; e, demais, que alimenta a
confiança, que permanece na vida futura. Da ciência só diz que elimina o jejum da ignorância, o que
pertence ao estado presente; mas, o que acrescenta —no ventre da mente — pode-se entender,
figuradamente, da plenitude do conhecimento, pertencente também ao estado futuro. Da piedade,
que enche as vísceras do coração com as obras de misericórdia, o que, literalmente entendido, pertence
só ao estado da vida presente; mas o mesmo afeto íntimo dos próximos, designado pela expressão —
vísceras, pertence também ao estado futuro, em que a piedade não exibirá as obras de misericórdia,
mas o afeto congratulatório. Do temor, que reprime a mente para que não se ensoberbeça com as
coisas presentes, o que pertence ao estado atual; e que conforta com o alimento da esperança, para as
coisas futuras, o que pertence, quanto à esperança, ao estado presente; mas pode também pertencer
ao estado futuro, quanto ao conforto relativo ao que aqui esperamos e lá obteremos.

RESPOSTA À TERCEIRA. — A objeção colhe quanto à matéria dos dons. Pois as obras da vida ativa não
constituirão a matéria deles. Mas os atos de todas versarão sobre a vida contemplativa, que é a vida
feliz.

## Art. 7 — Se a dignidade dos dons se funda na enumeração de Isaias, cap. XI.
(In Isaiam. Cap. XI).
O sétimo discute-se assim. — Parece que a dignidade dos dons não se funda na enumeração de Isaias.

1. — Pois, o mais importante dos dons é o que Deus exige, principalmente, do homem. Ora, o que dele
Deus exige sobretudo é o temor, conforme a Escritura (Dt 10, 12): Agora, pois, ó Israel, que é o que o
Senhor teu Deus pede de ti, senão que temas o Senhor teu Deus; e ainda (Ml 1, 6): se eu sou vosso
Senhor onde está o temor que se me deve? Logo, o temor, enumerado (Isaías) em último lugar não é o
ínfimo, mas o máximo dos dois.

2. Demais. — A piedade é considerada como bem universal, conforme diz o Apóstolo (1 Tm 4, 8): a
piedade para tudo é útil. Ora, o bem universal tem preferência sobre os bens particulares. Logo, a
piedade, enumerada em penúltimo lugar, é o mais importante dos dons.

3. Demais. — A ciência aperfeiçoa o juízo do homem, ao passo que o conselho é próprio à perquirição.
Ora, o juízo é superior a esta. Logo, a ciência é dom mais importante que o conselho, embora venha
depois dele na enumeração.

4. Demais. — A fortaleza reside na potência apetitiva, e a ciência, na razão. Ora, esta é mais eminente
que a potência apetitiva. Logo, também a ciência é dom mais eminente que a fortaleza, enumerada
contudo em primeiro lugar. Portanto, a dignidade dos dons não depende da ordem da sua enumeração.
Mas, em contrário, diz Agostinho: Parece-me que a septiforme operação do Espírito Santo, de que fala
Isaías, concorda com os graus e as sentenças, mencionados por Mateus, V; Mas, difere na ordem,
porque, em Isaías, a enumeração começa pelos dons mais elevados, e em Mateus, pelos inferiores.

SOLUÇÃO. — A dignidade dos dons pode ser considerada de dois modos: absolutamente, i. é, quanto
aos próprios atos, enquanto procedentes dos seus princípios, ou relativamente i. é, quanto à matéria.
Ora, considerando absolutamente a dignidade dos dons, com eles sucede o mesmo que com as virtudes,
pois os dons aperfeiçoam o homem para todos os atos das potências da alma, para os quais também as
virtudes os aperfeiçoam, como já dissemos. Por onde, assim como as virtudes intelectuais têm
preeminência sobre as morais, e dentre as próprias virtudes intelectuais, as contemplativas, como a
sabedoria, o intelecto e a ciência, são superiores às ativas, como a prudência e a arte, de modo que a
sabedoria tem preeminência sobre o intelecto e este, sobre a ciência, bem como a prudência e a sínese
sobre a eubulia; assim também, os dons da sabedoria e do intelecto, da ciência e do conselho têm
preeminência sobre a piedade, a fortaleza e o temor, tendo a piedade preeminência sobre a fortaleza, e
esta sobre o temor, como a justiça tem preeminência sobre a fortaleza e esta, sobre a temperança.
Mas, quanto à matéria, a fortaleza e o conselho têm preeminência sobre a ciência e a piedade, porque a
fortaleza e o conselho supõem o que é árduo, ao passo que a ciência e a piedade se exercem nos casos
comuns.
Assim pois, a dignidade dos dons corresponde à ordem da enumeração, parte, absolutamente,
enquanto a sabedoria e o intelecto têm preeminência sobre todos; e parte, quanto à ordem da matéria,
enquanto o conselho e a fortaleza têm preferência sobre a ciência e a piedade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O temor é exigido, principalmente, como um quase
primórdio à perfeição dos dons, porque o temor do Senhor é princípio da sabedoria; e não por ser mais
digno que os outros dons; mas, na ordem da geração, antes de praticarmos o bem, por influência dos
demais dons, fugimos do mal, por influência do temor, como diz a Escritura (Pr 16, 6).

RESPOSTA À SEGUNDA. — A piedade não a comparam as palavras do Apóstolo a todos os dons de Deus,
mas só ao exercício corporal, sobre o qual já havia dito, que para pouco é proveitoso.

RESPOSTA À TERCEIRA. — Embora a ciência, por causa do juízo, tenha preferência sobre o conselho,
contudo este a tem, quanto à matéria. Pois, o conselho só se exerce quando se trata de coisas árduas,
como se disse; ao passo que o juízo da ciência, em todos os casos.

RESPOSTA À QUARTA. — Os dons diretivos, pertinentes à razão, são mais dignos que os dons
executivos, se forem considerados em relação aos atos, enquanto procedentes das potências; pois, a
razão tem preeminência sobre a potência apetitiva, como o que regula a tem sobre o regulado. Mas,
quanto à matéria, o conselho se anexa à fortaleza como o diretivo ao executivo e, semelhantemente, a
ciência à piedade; pois, o conselho e a fortaleza se exercem nos casos árduos, a ciência e a piedade, nos
comuns. E portanto, o conselho, simultaneamente com a fortaleza, é enumerado, em razão da matéria,
antes da ciência e da piedade.

## Art. 8 — Se as virtudes têm preeminência sobre os dons.
(III Sent., dist. XXXIV, q. 1, a. 1, ad 5; De Virtut., q. 2, a. 2, ad 17).
O oitavo discute-se assim. — Parece que as virtudes têm preeminência sobre os dons.

1. — Pois, diz Agostinho, falando da caridade: Nenhum dom de Deus é mais excelente que este. É o
único que separa os filhos do reino eterno, dos da eterna perdição. Há ainda outros dons do Espírito
Santo, mas de nada servem sem a caridade. Ora, a caridade é uma virtude. Logo, a virtude tem
preeminência sobre os dons do Espírito Santo.

2. Demais. — O que tem naturalmente prioridade tem também preeminência, Ora, as virtudes têm
prioridade sobre os dons do Espírito Santo. Pois, Gregório diz: Os dons formam, antes de tudo, na mente
que lhes é dócil, a prudência, a temperança, a fortaleza, e a justiça. E assim equilibra, em pouco, a
mesma mente com as sete virtudes, i. é, dons, opondo, à estultícia, a sabedoria; ao embotamento, o
intelecto, à precipitação, o conselho; ao temor, a fortaleza; à ignorância, a ciência; à dureza, a piedade; à
soberba, o temor. Logo, as virtudes têm preeminência sobre os dons.

3. Demais. — Ninguém pode usar mal da virtude, como diz Agostinho. Ora, é possível usar mal dos dons;
pois, como diz Gregório, imolamos a hóstia da nossa prece para a sabedoria não ensoberbecer; para o
intelecto, sutilmente discorrendo, não aberrar; para o conselho, multiplicando-se, não confundir; para
não se precipitar à fortaleza, gerando a confiança; para a ciência não inchar, conhecendo sem amar;
para a piedade não transviar, afastando do caminho reto; para o temor, amedrontando mais do que é
justo, não imergir no abismo do desespero. Logo, as virtudes são mais dignas que os dons do Espírito
Santo.
Mas, em contrário, os dons são conferidos para fortalecer as virtudes contra os defeitos, como é claro
pela citação aduzida. E assim, parece que aperfeiçoam o que as virtudes não podem aperfeiçoar. Logo,
têm preeminência sobre elas.

SOLUÇÃO. — Como do sobredito resulta, distinguem-se três gêneros de virtudes: umas teologais;
outras, intelectuais; outras, morais. As teologais unem a Deus a mente humana; as intelectuais
aperfeiçoam a razão; enfim, as morais tornam apta as potências apetitivas a obedecer à razão. Ora,
pelos dons do Espírito Santo todas as potências da alma se dispõem a submeter-se à moção divina.
Por onde, os dons estão para as virtudes teologais, que unem o homem ao Espírito Santo, que o move,
como as virtudes morais estão para as intelectuais, perfectivo da razão, motora das virtudes morais.
Assim, pois, como as virtudes intelectuais têm preeminência sobre as morais e as regulam, assim as
teologais a têm sobre os dons do Espírito Santo, e os regulam. Donde o dizer Gregório: os sete filhos, i.
é, os sete dons, não chegam à perfeição da dezena, senão fizerem tudo com fé, esperança e caridade.
Comparados, porém, com as demais virtudes intelectuais ou morais, os dons têm preeminência sobre as
virtudes. Pois, aperfeiçoam as potências da alma, relativamente ao Espírito Santo, que move; ao passo
que as virtudes aperfeiçoam ou a razão mesma, ou as demais potencias, relativamente à razão. Ora, é
manifesto que quanto maior o motor, tanto mais perfeitamente disposto deve ser o móvel. Logo, os
dons são mais perfeitos que as virtudes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A caridade é uma virtude teologal, e concedemos tenha
preeminência sobre os dons.

RESPOSTA À SEGUNDA. — De dois modos pode-se entender a prioridade. — Primeiro, na ordem da
perfeição e da dignidade; assim, o amor de Deus tem prioridade sobre o do próximo. E deste modo, os
dons têm prioridade sobre as virtudes intelectuais e morais; posterioridade, porém, relativamente às
virtudes teologais.— De outro modo, na ordem da geração ou disposição; assim, o amor do próximo
precede, quanto ao ato, o amor de Deus. E assim, as virtudes morais e intelectuais precedem os dons;
pois, estando bem disposto no que respeita à sua razão própria, o homem fica bem disposto no
concernente a suas relações com Deus.

RESPOSTA À TERCEIRA. — A sabedoria, o intelecto, e dons semelhantes, provêm do Espírito Santo,
enquanto informados pela caridade, que não obra temerariamente, como diz a Escritura (1 Cor 13, 4). E,
portanto, da sabedoria, do intelecto e de dons semelhantes ninguém pode usar mal, enquanto dons do
Espírito Santo. Mas para não se afastarem da perfeição da caridade, um é fortificado pelo outro. E é isto
que Gregório quer dizer.