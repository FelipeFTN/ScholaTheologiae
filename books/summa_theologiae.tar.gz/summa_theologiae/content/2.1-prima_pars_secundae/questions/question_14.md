# Questão 14: Do conselho.
Em seguida devemos tratar do conselho. E sobre esta Questão, seis artigos se discutem:

## Art. 1 — Se o conselho é inquirição.
O primeiro discute-se assim. ― Parece que o conselho não é inquirição.

1. ― Pois, como diz Damasceno, o conselho é apetitivo. Ora, não pertence ao apetite o inquirir. Logo, o
conselho não e inquirição.

2. Demais. ― O inquirir é próprio do intelecto discursivo, e por isso não convém a Deus, cujo
conhecimento não é discursivo, como se estabeleceu na primeira parte. Ora, o conselho é atribuído a
Deus, pois, como diz o Apóstolo (Ef 1, 11), obra todas as coisas segundo o conselho da sua vontade.
Logo, o conselho não é inquirição.

3. Demais. ― A inquirição é relativa ao duvidoso. Ora, o conselho se dá em relação a bens certos,
conforme aquilo do Apóstolo (1 Cor 7, 25): Quanto porém às virgens não tenho mandamento do
Senhor; mas dou conselho. Logo, o conselho não é inquirição.
Mas, em contrário, diz Gregório Nisseno (Nemésio): Todo conselho é uma inquirição; mas, nem toda
inquirição é conselho.

SOLUÇÃO. ― Como já se disse, a eleição resulta de um juízo da razão relativo ao que se deve fazer. Ora,
relativamente ao que se deve fazer há muita incerteza porque os atos versam sobre os singulares
contingentes, pela sua variabilidade incertos. Ora, nas coisas duvidosas e incertas, a razão não profere o
juízo sem uma inquirição precedente. Logo, é necessária a inquirição da razão antes do juízo relativo ao
que se deve escolher. E a essa inquirição se chama conselho; e por isso o Filósofo diz, que a eleição é um
desejo do que foi anteriormente deliberado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando os atos de duas potências se ordenam uns aos
outros, há em cada um deles algo que depende da outra potência; e portanto, uns e outros podem ser
designados pelo nomes de uma e outra potência. Ora, é manifesto que o ato da razão dirigente para os
meios; e o ato da vontade subordinado à razão e tendente para eles ordenam-se um para outro. Por
onde, de um lado, na eleição, ato da vontade, manifesta-se algo de racional, que é a ordem; e de outro
lado, no conselho, ato da razão, manifesta-se de algum modo a vontade. Este elemento voluntário se
apresenta como matéria, porque o conselho é relativo ao que o homem quer fazer; e também como
movido, pois desde que o homem quer o fim, move-se ao conselho relativo aos meios. E por isso o
Filósofo diz, que a eleição é um intelecto apetitivo, para mostrar que esses dois elementos nela
concorrem. E Damasceno diz que o conselho é um apetite inquisitivo, para mostrar que pertence de
certo modo tanto à vontade, relativamente à qual e pela qual se faz a inquirição, como à razão que
inquire.

RESPOSTA À SEGUNDA. ― O que se diz de Deus deve ser entendido sem nenhuma das nossas
deficiências. Assim, a nossa ciência é das conclusões, obtida discorrendo das causas para os efeitos; ao
passo que a ciência de Deus significa certeza relativamente a todos os efeitos, na causa primeira, sem
nenhum discurso. E semelhantemente, o conselho é atribuído a Deus, quanto à certeza da sentença ou
do juízo, que em nós procede da inquirição do conselho; mas tal inquirição não existe em Deus e
portanto, sob este aspecto, o conselho não lhe é atribuído. E por isso Damasceno diz, que em Deus não
há conselho, próprio do ignorante.

RESPOSTA À TERCEIRA. ― Nada impede serem alguns bens certíssimos, no juízo dos sapientes e dos
homens espirituais, e todavia não o serem no de muitos ou dos homens carnais. E por isso formam-se
conselhos a respeito deles.

## Art. 2 — Se o objeto do conselho são somente os meios ou também os fins.
(III Sent., dist. XXXV, q. 2, a . 4, q ª 1; III Ethic., lect VIII).
O segundo discute-se assim. Parece que o conselho tem por objeto não só os meios, mas também o
fim.

1. ― Pois, tudo o que encerra dúvida pode ser objeto de inquirição. Ora, em relação às obras humanas,
pode haver dúvida quanto ao fim e não só quanto aos meios. Ora, sendo a inquirição no tocante às
ações, um conselho, resulta que este pode ter por objeto o fim.

2. Demais. ― A matéria do conselho são as ações humanas. Ora, destas, umas são fins, como diz
Aristóteles. Logo, o conselho pode ter por objeto o fim.
Mas, em contrário, diz Gregório Nisseno (Nemésio), o conselho tem por objeto, não o fim, mas os meios.

SOLUÇÃO. ― O fim, nas ações, exerce a função de princípio, porque a razão de ser dos meios se deduz
do fim. Ora, sobre um princípio não se discute, antes, deve ser suposto em toda inquirição. Por onde,
sendo o conselho uma inquirição, tem por objeto, não o fim, mas só os meios. Pode porém acontecer
que o fim de uma ação se ordene a outro fim; assim como o princípio de uma demonstração pode ser
conclusão de outra. E como o que é considerado fim de uma inquirição pode ser considerado meio em
relação a outra, o fim, nesse sentido, pode ser objeto do conselho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O que é aceito como fim já é determinado. Por isso,
enquanto duvidoso, não é tido como fim; e portanto se for objeto do conselho, este não tem por objeto
o fim, mas o meio.

RESPOSTA À SEGUNDA. ― As ações são objeto do conselho, na medida em que se ordenam a algum
fim. Donde, a ação humana que for fim não poderá como tal ser objeto do conselho.

## Art. 3 — Se o conselho tem por objeto só nossos atos.
(III Ethic., lect. VII).
O terceiro discute-se assim. ― Parece que o conselho não tem por objeto só os nossos atos.

1. ― Pois, o conselho importa numa como conferência. Ora, entre muitos conferentes pode-se tratar
também do que é imutável e não feito por nós, como p. ex., as naturezas das coisas. Logo, o conselho
não tem por objeto só os nossos atos.

2. Demais. ― Há homens que às vezes, consultam sobre o estatuído por lei e são chamados por isso
jurisconsultos. E contudo, os que assim consultam não podem fazer as leis. Logo, o conselho não tem
por objeto só os nossos atos.

3. Demais. ― Certos também fazem consultas sobre acontecimentos futuros, que todavia não estão em
nosso poder. Logo, o conselho não tem por objeto só os nossos atos.

4. Demais. ― Se o conselho tivesse por objeto só os nossos atos ninguém deliberaria sobre os dos
outros. Ora, isto é claramente falso. Logo, o conselho não tem por objeto só os nossos atos.
Mas, em contrário, diz Gregório Nisseno (Nemésio): Deliberamos sobre o que depende de nós e por nós
pode ser feito.

SOLUÇÃO. ― Conselho propriamente, significa conferência entre várias pessoas. Pois, como o próprio
nome indica, conselho vem, por assim dizer, de consilium, porque vários se assentam juntos para assim
conferenciarem. Ora, há de se considerar, que para se conhecer algo de certo nas particularidades
contingentes, é preciso que se levem em conta várias condições ou circunstâncias, que, não facilmente
examinadas por um só, podem ser apreendidas com maior segurança por vários, pois o que um não
percebe ocorrerá o outro. Ao passo que, relativamente ao necessário e universal, a reflexão é mais
absoluta e mais simples, porque para tal reflexão mais facilmente um só pode se bastar a si mesmo. E
por isso a inquirição do conselho tem propriamente por objeto os singulares contingentes. Porém o
conhecimento da verdade, em tais casos, não tem importância tão grande que seja desejado por si
mesmo, como se dá com o conhecimento do universal e necessário; mas é desejado, antes, enquanto
útil para a ação, pois, as ações versam sobre os singulares contingentes. Portanto, deve-se dizer que o
conselho propriamente tem por objeto os nossos atos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O conselho supõe uma conferência, não qualquer, mas
relativa ao que se deve fazer, pela razão já exposta.

RESPOSTA À SEGUNDA. ― O estabelecido por lei; embora não resulte da ação do que busca conselho,
contudo o dirige para ela; pois, o ordenado por lei é uma razão de agirmos.

RESPOSTA À TERCEIRA. ― O conselho tem por objeto não só os nossos atos mas também o que se
ordena às operações. Diz-se então que uma consulta é feita sobre acontecimentos futuros, enquanto o
homem, por tais acontecimentos conhecidos, é levado a fazer ou evitar alguma coisa.

RESPOSTA À QUARTA. ― Deliberamos sobre os feitos dos outros, na medida em que se unificam
conosco; quer pela união afetiva, como quando alguém é solícito sobre as coisas do amigo, como se
fossem suas; quer a modo de instrumento, pois o agente principal e o instrumental formam como uma
só causa, agindo um por meio do outro e sendo neste sentido que o senhor delibera sobre o que deve
fazer o seu servo.

## Art. 4 — Se o conselho respeita tudo o que fazemos.
(III Sent., dist. XXXV, q. 2, a . 4, q ª 1; III Ethic., lect. VII).
O quarto discute-se assim. ― Parece que o conselho respeita tudo o que fazemos.

1. ― Pois, a eleição é um desejo do que foi anteriormente deliberado, como já se disse. Ora, a eleição se
refere a tudo o que fazemos. Logo, também o conselho.

2. Demais. ― O conselho supõe inquirição da razão. Ora, sempre que não agimos levados do ímpeto da
paixão, procedemos por inquirição racional. Logo, o conselho respeita tudo o que fazemos.

3. Demais. ― Como diz o Filósofo, quando um ato pode ser realizado por vários meios, o conselho
examina como se ele fará mais facilmente e melhor; se porém não há senão um meio, como, por ele se
fará. Ora, tudo o que fazemos por um meio ou por muitos o fazemos. Logo, o conselho respeita tudo o
que fazemos.
Mas, em contrário, diz Gregório Nisseno (Nemésio) que o conselho não diz respeito às obras da
educação e da arte.

SOLUÇÃO. ― O conselho, como já se disse, é uma certa inquirição. Ora, de ordinário deliberamos sobre
o que é duvidoso, e por isso a razão inquisitiva, chamada argumento, é a que leva da dúvida à fé. Ora, de
dois modos pode dar-se que uma ação na ordem prática, não seja duvidosa. Ou porque, por vias
determinadas, procedemos a determinados fins, como acontece com as artes que têm modos certos de
operar; assim, um escritor não delibera sobre o modo de traçar as letras, pois isso está determinado
pela arte. Ou então, porque tem pouca importância o agir de tal maneira ou de tal outra, como se dá
com as coisas mínimas, que pouco ajudam ou impedem a consecução do fim; e o que é pouco a razão o
considera quase como nada. Há portanto duas ordens de atos sobre os quais não deliberamos, embora
ordenados ao fim, segundo o Filósofo: os de mínima importância e os já determinados no modo por que
se devem fazer, como acontece com as operações das artes, excetas as que são conjeturais, no dizer de
Gregório Nisseno (Nemésio), como p. ex., a medicinal, a dos negócios e outras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A eleição pressupõe o conselho, em razão do juízo ou da
sentença. Por onde, quando esta ou aquele são manifestados, sem inquirição, não é necessário que o
conselho a faça.

RESPOSTA À SEGUNDA. ― No que é manifesto a razão não inquire, mas julga imediatamente. E
portanto, não é necessário que haja inquirição do conselho em tudo o que é feito racionalmente.

RESPOSTA À TERCEIRA. ― Quando um ato pode ser feito por um meio, mas por diversos modos,
podemos duvidar, como quando é feito por vários meios, e portanto é necessário o conselho. Mas este
não o é quando é determinado, não só o ato, mas também o modo.

## Art. 5 — Se o conselho procede por modo resolutório.
(III Ethic., lect. VIII).
O quinto discute-se assim. ― Parece que o conselho não procede por modo resolutório.

1. ― Pois, o conselho tem por objeto os nossos atos. Ora, estes não procedem pelo modo resolutório,
mas antes, pelo compositivo, i. é, indo do simples para o composto. Logo, nem sempre o conselho
procede por modo resolutório.

2. Demais. ― O conselho é uma inquirição racional. Ora, a razão parte do anterior para o posterior,
segundo a ordem mais conveniente. Como pois o pretérito é anterior ao presente e este ao futuro,
deve-se proceder, no conselho, do presente e do pretérito para o futuro; o que não entra na ordem
resolutória. Logo, no conselho não se conserva esta ordem.

3. Demais. ― O conselho só versa sobre o que nos é possível, como diz Aristóteles. Ora, a possibilidade
de um ato depende de podermos nós fazê-lo ou não, de modo a chegar a um termo. Logo, na inquirição
do conselho do conselho é necessário partir do presente.
Mas, em contrário, como diz o Filósofo, quem delibera inquire e resolve.

SOLUÇÃO. ― Em toda inquirição é necessário partir de algum princípio. E se este for primeiro tanto na
ordem do conhecimento como na do ser, o processo não é resolutório, mas antes compositivo. Pois,
proceder das causas para os efeitos é processo compositivo porque aquelas são mais simples que estes.
Se porém o que é primeiro na ordem do conhecimento for posterior na do ser, o processo é resolutório;
assim, quando julgamos de efeitos manifestos, resolvendo-os a causas simples. Ora, o princípio, na
inquirição do conselho, é o fim, que, primeiro na intenção, é posterior quanto à realização. E sob este
aspecto, necessariamente a inquirição do conselho há de ser resolutória, isto é, parte do
intencionalmente futuro até chegar ao que imediatamente deve ser efeito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O conselho tem por objeto os atos; mas a razão deles se
deduz do fim. E portanto, a ordem do raciocínio relativo aos atos é contrária à ordem do agir.

RESPOSTA À SEGUNDA. ― A razão parte do que é primeiro na ordem racional; nem sempre porém do
que é primeiro temporalmente.

RESPOSTA À TERCEIRA. ― Não procuraríamos saber se o que devemos fazer em vista de um fim é
possível se isso não tivesse conveniência com o fim. E portanto, antes de considerar se um ato é
possível, é necessário inquirir se é apto a conduzir ao fim.

## Art. 6 — Se a inquirição do conselho procede ao infinito.
(III Ethic., lect. VIII)
O sexto discute-se assim. ― Parece que a inquirição do conselho procede ao infinito.

1. ― Pois, o conselho é uma inquirição relativa a casos particulares, da ordem prática. Ora, os singulares
são infinitos. Logo, também o é a inquirição do conselho.

2. Demais. ― Cabe à inquirição do conselho considerar, não só o que se deve fazer, mas também como
se hão de remover os obstáculos. Ora, qualquer ação humana pode ser impedida infinitas vezes e o
impedimento pode ser removido por alguma razão humana. Logo, vamos ao infinito buscando a
remoção dos obstáculos.

3. Demais. ― A inquirição da ciência demonstrativa não procede ao infinito, porque há de chegar a
algum princípio evidente, de certeza absoluta. Ora, tal certeza não se pode encontrar nos singulares
contingentes, variáveis e incertos. Logo, a inquirição do conselho procede ao infinito.
Mas, em contrário. ― Ninguém busca o que é impossível alcançar, como diz Aristóteles. Ora, é
impossível percorrer o infinito. Se pois, a inquirição do conselho fosse ao infinito, ninguém começaria à
deliberar, o que é patentemente falso.

SOLUÇÃO. ― A inquirição do conselho procede atualmente ao finito, sob duplo aspecto: quanto ao
princípio e quanto ao termo. Pois essa inquirição parte, na verdade, de duplo princípio. Um próprio, em
virtude do gênero mesmo das ações, que é o fim, sobre o qual não se delibera, mas antes o conselho o
supõe, como princípio, segundo já se disse. Outro é tirado de um diverso gênero, por assim dizer, do
mesmo modo que, nas ciências demonstrativas, em que uma ciência supõe, sem os discutir, dados de
outra. Ora, esses princípios supostos na inquirição do conselho são todos os recebidos pelos sentidos, p.
ex., que isto é pão ou ferro; e todos os conhecidos em universal por qualquer ciência especulativa ou
prática, como p. ex., que fornicar é proibido por Deus e que o homem não pode viver se não se nutrir
convenientemente. Ora, sobre tudo isto não discute quem delibera. Por outro lado o termo da
inquirição consiste naquilo que nos é imediatamente possível fazer. Pois, assim como o fim exerce a
função de princípio, assim os meios, a de conclusão. Por onde, o que ocorre a ser feito em primeiro
lugar exerce a função de conclusão última, com a qual a inquirição termina. ― Nada porém impede que,
potencialmente, o conselho procede ao infinito, enquanto podem ocorrer coisas infinitas a serem
inquiridas por ele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os casos singulares são infinitos, não atual, mas só
potencialmente.

RESPOSTA À SEGUNDA. ― Embora uma ação humana possa vir a ser impedida, nem sempre, porém,
esse impedimento lhe está presente. E portanto, nem sempre se deve deliberar sobre a eliminação do
impedimento.

RESPOSTA À TERCEIRA. ― Nos singulares contingentes pode ser considerada uma ação como certa, ser
bem não absolutamente, contudo relativamente a ela. Assim, não e necessário que Sócrates esteja
sentado, mas o é, quando o está, e disso podemos ter a certeza.