# Questão 78: Da causa do pecado, por parte da vontade, chamada malícia.
Em seguida devemos tratar da causa do pecado, por parte da vontade, chamada malícia.
E sobre esta questão, discutem-se quatro artigos:

## Art. 1 — Se se pode pecar de propósito ou por malícia intencional.
(II Sent., dist. XLIII, a. 1; De Malo, q. 2, a. 8, ad 4; 1. 3, a. 12; a. 14, ad 7, 8).
O primeiro discute-se assim. — Parece que ninguém peca de propósito ou por malícia intencional.

1. — Pois, a ignorância se opõe ao propósito ou à malícia intencional. Ora, todo mal é ignorante,
segundo o Filósofo; e a Escritura (Pr 14): Os que obram mal erram. Logo, ninguém peca por malícia
intencional.

2. Demais. — Dionísio diz que ninguém obra mal intencionalmente. Ora, pecar por malícia é praticar o
mal intencionalmente; pois, o contrário à nossa intenção é acidental e não pode classificar um ato. Logo,
ninguém peca por malícia.

3. Demais. — A malícia em si mesma é pecado. Se pois fosse causa de pecado, seguir-se-ia que um
pecado é causa de outro, ao infinito, o que é inadmissível. Logo, ninguém peca por malícia.
Mas em contrário: Os que como de propósito se apartaram de Deus, e não quiseram compreender
todos os seus caminhos. Ora, apartar-se de Deus é pecar. Logo, certos pecam de propósito ou por
malícia intencional.

SOLUÇÃO. — O homem, como qualquer outro ser, deseja naturalmente o bem. E só pela corrupção ou
desordem em algum de seus princípios pode o seu apetite inclinar-se para o mal; e assim também pode
haver pecado nos atos dos seres naturais. Ora, os princípios dos atos humanos são o intelecto e o
apetite, tanto o racional, chamado vontade, como o sensitivo. Por onde, pode haver pecado nesses atos,
por deficiência do intelecto, como quando pecamos por ignorância; ou por deficiência do apetite
sensitivo, como quando pecamos por paixão; ou ainda por deficiência da vontade, sendo esta
desordenada.
E a vontade é desordenada quando mais ama o que é menos bom. Ora, é proceder conseqüentemente
preferirmos sofrer detrimento no bem menos amado; assim, quando preferimos sofrer a amputação de
um membro, mesmo cientemente, para conservarmos a vida, que amamos mais. E deste modo se uma
vontade desordenada ama algum bem temporal — p. ex., as riquezas ou o prazer — mais do que a
ordem da razão ou da lei divina ou a caridade de Deus ou um bem semelhante, segue-se que prefere
sofrer detrimento em algum desses bens espirituais, para alcançar um bem temporal. Pois, o mal não é
outra coisa que a privação de algum bem. E assim, pelo que acabamos de dizer, podemos cientemente
querer um mal espiritual, que é, o mal absoluto, e nos priva do bem espiritual, para alcançarmos um
bem temporal. E portanto, pecamos intencionalmente ou de propósito, cientemente escolhendo o mal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ignorância às vezes exclui a ciência, pela qual
simplesmente sabemos que praticamos o mal, sendo por isso ela a causa do pecado. Outras vezes,
porém, exclui a ciência pela qual conhecemos atualmente tal ato como mau; assim, quando pecamos
por paixão. Outras vezes, ainda, exclui a ciência pela qual sabemos não devermos praticar um
determinado mal para conseguirmos um bem, embora saibamos absolutamente ser isso um mal. E
assim dizemos que ignora quem peca intencionalmente.

RESPOSTA À SEGUNDA. — O mal não pode ser buscado intencionalmente por ninguém; pode sê-lo
contudo para evitar outro mal ou conseguir outro bem, como dissemos. E em tal caso, preferiríamos
alcançar um bem, buscado intencionalmente, em si mesmo, sem sofrermos detrimento em outro.
Assim, o lascivo quereria fruir o prazer, sem ofender a Deus; mas, propostos esses dois bens, prefere,
pecando, incorrer na ofensa de Deus, a privar-se do prazer.

RESPOSTA À TERCEIRA. — A malícia, pela qual dizemos que alguém peca pode ser tomada como a
malícia habitual, pela qual o hábito mau é, segundo o Filósofo, denominado malícia, assim como o bom
é chamado virtude. E a esta luz, dizemos que peca por malícia quem peca pela inclinação do hábito. —
Mas também pode ser considerada como a malícia atual. Quer seja denominada malícia a eleição do
mal; dizendo-se, nesse caso, que peca por malícia quem peca por tal eleição. Quer seja chamada malícia
alguma culpa precedente, da qual resulta outra subseqüente; assim quando alguém se rebela contra o
bem de um irmão, por inveja. E então não há identidade entre causa e efeito, mas um ato interior é
causa de um ato exterior, e um pecado, causa de outro. Não assim, contudo, ao infinito, pois havemos
de chegar a um primeiro pecado, não causado por outro anterior, como do sobredito se colhe.

## Art. 2 — Se todo o que peca por hábito peca por malícia intencional.
(II Sent., dist. XLIII, a. 2).
O segundo discute-se assim. — Parece que nem todos os que pecam por hábito pecam por malícia
intencional.

1. — Pois, o pecado por malícia é considerado gravíssimo. Ora, às vezes cometem um pecado leve, por
hábito, como quando dizemos alguma palavra ociosa. Logo, nem todo pecado por hábito é de malícia
intencional.

2. — Demais. — Os atos praticados por hábito são semelhantes aos que geram os hábitos, como diz
Aristóteles. Ora, os atos precedentes ao hábito vicioso não procedem de malícia intencional. Logo,
também os pecados provenientes do hábito não procedem dessa malícia.

3. Demais. — Nós nos regozijamos com o que praticamos com malícia intencional, conforme diz a
Escritura (Pr 2): Os que se alegram depois de terem feito o mal, e triunfam de prazer nas piores coisas. E
isto por nos ser agradável conseguir o que intencionamos e nos é, de certo modo, habitualmente
conatural. Ora, os que pecam por hábito se doem do pecado cometido; pois, os maus, i. é, os de hábito
vicioso, enchem-se de arrependimento, como diz Aristóteles. Logo, os pecados habituais não são de
malícia intencional.
Mas em contrário. — Chama-se pecado de malícia intencional o proveniente da eleição do mal. Ora,
cada qual elege segundo o hábito próprio o inclina, como diz Aristóteles, a respeito do hábito virtuoso.
Logo, o pecado habitual procede de malícia intencional.

SOLUÇÃO. — Não é a mesma coisa pecar, tendo um hábito, e pecar por hábito. Pois, como o hábito
depende da vontade do sujeito, este não é arrastado a agir levado por ele. Sendo por isso o hábito
definido como aquilo de que usamos quando queremos. E, portanto, como é possível praticarmos um
ato virtuoso, embora tenhamos um hábito vicioso, que não trava totalmente a razão, mas lhe deixa um
certo discernimento íntegro, permitindo ao pecador praticar alguma obra boa; assim também é
possível, embora com um hábito vicioso, obrarmos às vezes, não levados por ele, mas pela paixão em
revolta, ou mesmo pela ignorância. Mas, levados pelo hábito vicioso, sempre e necessariamente
pecamos por malícia intencional. Pois, quem tem um hábito ama, em si mesmo, o que lhe convém, de
acordo com esse hábito, que se lhe torna de certo modo conatural, por se o costume e o hábito
converterem em a natureza. Ora, o que nos convém, por um hábito vicioso, exclui o bem espiritual.
Donde resulta o elegermos o mal espiritual, para alcançarmos o bem conveniente, de acordo com o
hábito. E isto é pecar com malícia intencional. Por onde é manifesto, que quem peca por hábito peca
com malícia intencional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os pecados veniais não excluem o bem espiritual, que é
a graça de Deus ou a caridade; por isso consideram-se maus, não absoluta, mas relativamente. E por
isso também os hábitos deles não podem ser considerados maus absoluta, mas só, relativamente.

RESPOSTA À SEGUNDA. — Os atos procedentes dos hábitos são semelhantes especificamente aos atos
de que se os hábitos geram. Deles diferem, porém, como o perfeito, do imperfeito. E tal é a diferença
entre o pecado cometido com malícia intencional e o praticado por paixão.

RESPOSTA À TERCEIRA. — Quem peca por hábito sempre se compraz no seu ato, desde que obedece a
um hábito. Mas como pode obedecer não a ele, mas, meditando noutro ato, à razão, ainda não de todo
obnubilada, é possível não se deixando levar pelo hábito, doer-se do ato cometido orientado por este.
No mais das vezes, porém, os que assim procedem se arrependem do pecado, não por este, em si
mesmo, lhes desagradar, mas por algum mal que, por causa do pecado, sofrem.

## Art. 3 — Se quem peca por malícia intencional peca por hábito.
(II Sent., dist. XLIII, a. 2; In Matth., cap. XII).
O terceiro discute-se assim. — Parece que quem peca por malícia intencional peca por hábito.

1. — Pois, diz o Filósofo, que nem todos podem praticar atos injustos, ao modo do injusto, i. é, por
eleição; mas, só o que tem o hábito para tal. Ora, pecar por malícia intencional é fazê-lo, com eleição do
mal, conforme já se disse. Logo, só quem tem o hábito pode pecar por malícia intencional.

2. Demais. — Orígenes diz que ninguém se anula ou falha subitamente, mas só paulatinamente e aos
poucos há-de resvalar. Ora, o máximo deslize é pecar por malícia intencional. Logo, não é
repentinamente e desde o princípio, mas por um diuturno costume, capaz de gerar o hábito, que
chegamos a pecar por essa malícia.

3. Demais. — Sempre que pecamos por malícia intencional, necessariamente a vontade por si mesma se
inclinará ao mal que elegeu. Ora, pela natureza mesma da potência, o homem não se inclina para o mal,
mas ao contrário, para o bem. Logo, se escolhe o mal fá-lo necessariamente por alguma coisa
sobreveniente, a saber, a paixão ou o hábito. Ora, quem peca por paixão não peca por malícia
intencional, mas por fraqueza, como já se disse. Logo, quem peca por malícia intencional há-de, sempre
e necessariamente, pecar por hábito.
Mas, em contrário. — O hábito bom está para a eleição do bem, como o mau, para a do mal. Ora,
podemos sem termos o hábito da virtude, escolher o que é virtuosamente bom. Logo, também
podemos eleger o mal, sem termos um hábito vicioso; e isso é pecar por malícia intencional.

SOLUÇÃO. — A vontade se comporta, de um modo, em relação ao bem e, de outro, ao mal. Pois, pela
natureza da sua potência, inclina-se para o bem racional como para o objeto próprio; e por isso todo
pecado é considerado contrário à razão. Portanto e necessariamente, só por alguma causa estranha a
eleição da vontade se inclina para o mal. E, isso às vezes se dá por deficiência da razão, como quando
pecamos por ignorância; outras, por impulso do apetite sensitivo, como quando pecamos por paixão. E
em nenhum destes casos pecamos por malícia intencional, mas só quando a vontade se move
propriamente para o mal. O que de dois modos pode se dar. — Primeiro, por alguma disposição
corrupta, inclinante para o mal, de modo a, em vista dessa disposição, algum mal nos ser conveniente e
semelhante, para o qual, em razão da semelhança, a vontade tende como se fosse bem. Pois, cada ser
tende, em si mesmo, ao que lhe é conveniente. E essa disposição corrupta é ou um hábito adquirido
pelo costume, que se converteu em natureza; ou algum hábito corpóreo doentio, como quando temos
certas inclinações naturais para certos pecados, por causa da corrupção da nossa natureza.
De outro modo, a vontade pode tender, por si mesma, para o mal, pela remoção de um obstáculo
proibitivo. Assim, se nos abstivermos de pecar, não propriamente por nos desagradar o pecado, mas
pela esperança da vida eterna, ou pelo temor da Geena, uma vez perdida a esperança, pelo desespero,
ou o temor, pela presunção, resultará o pecarmos por malícia intencional e quase sem freios.
Por onde claro fica, que o pecado, cometido por malícia intencional, sempre pressupõe no homem
alguma desordem, que contudo nem sempre é habitual. Portanto, quem peca por malícia intencional
nem por isso peca por hábito, necessariamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Proceder como o injusto é, não somente praticar atos
injustos por malícia intencional, mas ainda com prazer, e sem grave oposição da razão. Ora, isso o faz só
quem assim age habitualmente.

RESPOSTA À SEGUNDA. — Não é repentinamente que resvalamos, pecando por malícia intencional;
mas isso pressupõe uma causa que nem sempre é um hábito, como já se disse.

RESPOSTA À TERCEIRA. — O que inclina a vontade para o mal nem sempre é um hábito ou paixão, mas
podem ser certas outras coisas, como já se disse.

RESPOSTA À QUARTA. — A eleição do bem e a do mal não têm o mesmo fundamento. Pois, ao passo
que o mal nunca existe sem o bem natural, o bem pode existir sem o mal da culpa perfeita.

## Art. 4 — Se quem peca por malícia intencional peca mais gravemente que quem peca por paixão.
(II Sent., dist. XLIII, a. 4; De Malo, q. 3, a. 13; VII Ethic., lect. VIII).
O quarto discute-se assim. — Parece que quem peca por malícia intencional não peca mais
gravemente que quem peca por paixão.

1. — Pois, a ignorância excusa do pecado, total ou parcialmente. Ora, a ignorância de quem peca por
malícia intencional é maior que a de quem peca por paixão. Pois, quem peca por malícia intencional
assim procede por ignorância do princípio, que é a maior de todas, como diz o Filósofo. Pois aprecia mal
o fim, princípio das obras. Logo, é mais excusável de pecado quem peca por malícia intencional que
quem peca por paixão.

2. Demais. — Quanto maior for o impulso com que pecamos tanto menor será o pecado, como o
demonstra quem a ele se entrega por maior ímpeto de paixão. Ora, quem peca por malícia intencional é
levado pelo hábito, cujo impulso é mais forte que o da paixão. Logo, quem peca por hábito peca menos
que quem peca por paixão.

3. Demais. — Pecar por malícia intencional é pecar elegendo o mal. Ora, quem peca por paixão também
elege o mal. Logo, não peca menos que quem peca por malícia intencional.
Mas, em contrário, o pecado cometido de propósito por isso mesmo, merece pena mais grave,
conforme aquilo da Escritura (Jó 34): Feriu-os como ímpios à vista de todos, os que como de propósito
se afastaram dele. Ora, a pena só aumenta pela gravidade da culpa. Logo, o pecado se agrava quando
proposital e por malícia intencional.

SOLUÇÃO. — O pecado por malícia intencional é mais grave que o passional, por tríplice razão. —
Primeiro porque, residindo o pecado principalmente na vontade, quanto mais o ato deste lhe for
próprio a ela, tanto mais grave é ele, em igualdade de circunstâncias. Ora, quando pecamos por malícia
intencional, o ato pecaminoso é mais próprio à vontade, que por si mesma o busca, que quando
pecamos por paixão, pois neste caso a vontade é levada a pecar por um princípio extrínseco. Por onde, o
pecado, pelo fato mesmo de ser procedente da malícia, agrava-se, e tanto mais quanto mais veemente
for a malícia. E pelo que procede da paixão, tanto mais diminui, quanto mais veemente ela for.
Segundo porque a paixão inclinante a pecar se desvanece rapidamente, e então logo tornamos ao bom
propósito, arrependendo-nos do pecado. Ao contrário, o hábito inclinante ao pecado por malícia é uma
qualidade permanente; e portanto, quem peca por malícia peca mais diuturnamente. E por isso o
Filósofo compara o intemperante, que peca por malícia, ao enfermo que sofre continuamente; e o
incontinente, que peca por paixão, ao que sofre intermitentemente.
Terceiro porque quem peca por malícia intencional está mal disposto quanto ao fim mesmo, que é o
princípio na ordem da ação. E assim, a sua deficiência é mais perigosa que a de quem peca por paixão,
cujo propósito tende para um bom fim, embora tal propósito fique momentaneamente travado pela
paixão. Ora, sempre a deficiência do princípio é péssima. Por onde é manifesto, que o pecado por
malícia é mais grave que o passional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ignorância da eleição, onde a objeção se funda, nem
excusa do pecado nem o diminui, como já se disse. Portanto, nem a tal ignorância maior torna menor o
pecado.

RESPOSTA À SEGUNDA. — O impulso proveniente da paixão vem de uma como deficiência exterior,
relativa à vontade; ao passo que, pelo hábito, a vontade se inclina quase por um princípio interior.
Portanto, não há semelhança de razões.

RESPOSTA À TERCEIRA. — Uma coisa é pecarmos elegendo e outra, por eleição. Porque, nessa tal
pessoa, não é a eleição o princípio primeiro do pecado, mas é levado pela paixão a eleger o que não
elegeria se desta estivesse isento. Mas, quem peca por malícia intencional elege o mal em si mesmo, do
modo já dito. E portanto a sua eleição é o princípio do pecado, sendo por isso considerado como
pecando por eleição.