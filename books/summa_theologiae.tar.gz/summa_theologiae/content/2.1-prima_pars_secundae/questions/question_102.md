# Questão 102: Das causas dos preceitos cerimoniais.
Em seguida devemos tratar das causas dos preceitos cerimoniais.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se os preceitos cerimoniais tem causa.
O primeiro discute-se assim. — Parece que os preceitos cerimoniais não tem causa.

1. — Pois, aquilo da Escritura (Ef 2, 15) — Abolindo com os seus decretos a lei dos preceitos — diz a
Glosa: Isto é, abolindo a lei antiga, quanto às observâncias carnais, com decretos, i. é, com os preceitos
evangélicos, fundados na razão. Ora, se as observâncias da lei antiga eram fundadas na razão, seriam
abolidas em vão pelos decretos racionais da lei nova. Logo, as observâncias cerimoniais da lei não se
fundavam em nenhuma razão.

2. Demais. — A lei antiga sucedeu à lei da natureza. Ora, nesta havia um preceito, que não tinha
nenhuma razão de ser, senão provar a obediência do homem, como diz Agostinho, sobre a proibição da
árvore da vida. Logo, também a lei antiga devia estabelecer certos preceitos, que provassem a
obediência do homem, e que, em si mesmos, nenhuma razão de ser tivessem.

3. Demais. — Chamam-se morais as obras do homem procedentes da razão. Se pois os preceitos
cerimoniais se fundassem nalguma razão, não haviam de diferir do morais. Logo, parece que aqueles
não tem nenhuma causa; pois, a razão de um preceito é deduzida de alguma causa.
Mas, em contrário, diz a Escritura (Sl 18, 9): o preceito do Senhor é claro, que esclarece os olhos. Ora, os
preceitos cerimoniais são de Deus. Logo, são claros; o que não seriam se não tivessem uma causa
racional.

SOLUÇÃO. — Sendo próprio do sapiente ordenar, segundo o Filósofo, o procedente da sabedoria divina
há de ser ordenado, como diz o Apóstolo (Rm 13, 1). Ora, para haver ordem duas condições se
requerem. — A primeira, que ela tenha um fim devido, que é o princípio de toda a ordem dos nossos
atos; pois, do que acontece por acaso, fora de uma intenção final, bem como do que se não faz
seriamente, mas, por diversão, dizemos que é desordenado. — Em segundo lugar, é necessário seja o
meio proporcionado ao fim; donde se segue que a razão dos meios se deduz do fim, assim como a razão
da disposição da serra se tira do seu fim, que é cortar, como diz Aristóteles.
Ora, é manifesto, que os preceitos cerimoniais, bem como todos os outros preceitos da lei foram
instituídos pela sabedoria divina; donde o dizer a Escritura (Dt 4, 6): esta é a vossa sabedoria e
inteligência em face do povo. Por onde, é necessário concluir, que os preceitos cerimoniais eram
ordenados a algum fim, donde se lhes possam assinalar as causas racionais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As observâncias da lei antiga podem considerar-se sem
razão por não terem razão, em si mesmas e por natureza, as coisas que se faziam; p. ex., que as vestes
não fossem feitas de lã e de linho. Mas podiam ter razão relativamente à outra coisa, quer por a
figurarem, quer por a excluírem. — Ao passo que os decretos da lei nova, principalmente consistentes
na fé e no amor de Deus, pela própria natureza do ato são racionais.

RESPOSTA À SEGUNDA. — A proibição da árvore da ciência do bem e do mal não se fundava em ser
essa árvore naturalmente má; mas essa proibição, em si mesma, tinha a sua razão de ser em se ordenar
a outra coisa, que figurava. E assim também os preceitos cerimoniais da lei antiga tinham a sua razão de
ser no se ordenarem a outra coisa.

RESPOSTA À TERCEIRA. — Os preceitos morais, como estes — não matarás, não furtarás — tem por
natureza causas racionais. Ao passo que os cerimoniais tiram as suas causas racionais de se ordenarem
para outro fim, como se disse.

## Art. 2 — Se os preceitos cerimoniais tinham causa literal ou, se só figurada.
(Ad Rom., cap. IV, lect. II).
O segundo discute-se assim. — Parece que os preceitos cerimoniais não tinham causa literal, mas só
figurada.

1. — Pois, dentre os preceitos cerimoniais, os principais eram a circuncisão e a imolação do cordeiro
pascal. Ora, uma e outra tinham só causa figurada, porque só como sinais foram estabelecidos,
conforme a Escritura (Gn 17, 11): Circuncidareis a carne do vosso prepúcio, para que seja o sinal do
concerto que há entre mim e vós. E da celebração da Páscoa diz (Ex 13, 9): Será como um sinal na tua
mão, e como um memorial diante de teus olhos. Logo, com maior razão, os outros preceitos cerimoniais
só tinham causa figurada.

2. Demais. — O efeito se proporciona à sua causa. Ora, todos os preceitos cerimoniais eram figurados,
como se disse (q. 101, a. 2). Logo, não tinham causa senão figurada.

3. Demais. — O que é indiferente a ser cumprido de um ou de outro modo não pode ter causa literal.
Ora, certos preceitos cerimoniais eram indiferentes a serem cumpridos de um modo ou de outro, como,
p. ex., os que se referiam ao número dos animais a serem oferecidos, e em outras semelhantes
circunstâncias particulares. Logo, os preceitos da lei antiga não tinham razão literal.
Mas, em contrário. — Assim como os preceitos cerimoniais figuravam a Cristo, assim também as
histórias do Velho Testamento; pois, diz a Escritura (1 Cor 10, 11): todas estas coisas lhes aconteciam a
eles em figura. Ora, nas histórias do Velho Testamento, além do sentido místico ou figurado, há também
um sentido literal. Logo, também os preceitos cerimoniais além das causas figuradas, tinham causas
literais.

SOLUÇÃO. — Como já se disse (a. 1), a razão dos meios há de ser deduzida da do fim. Ora, duplo era o
fim dos preceitos cerimoniais, pois ordenavam-se ao culto de Deus, naquele tempo, e a figurar a Cristo;
assim como também as palavras dos profetas diziam respeito ao tempo presente, mas também
representavam figuradamente o futuro, como diz Jerônimo.
Por onde, as razões dos preceitos cerimoniais da lei antiga são susceptíveis de dupla consideração.
Primeiro, em razão do culto divino, que naquele tempo devia ser observado. E essas razões eram
literais, quer dissessem respeito a evitar o culto da idolatria, quer a rememorar certos benefícios de
Deus, quer a insinuar a excelência divina, quer ainda à por à mostra a disposição da mente então exigida
dos que cultuavam a Deus. — Em segundo lugar, as razões desses preceitos podem ser fundadas em se
ordenarem a figurar a Cristo. E assim tinham razões figuradas e místicas, quer deduzidas de Cristo
mesmo e da Igreja, o que pertence à alegoria; quer por serem relativas aos costumes do povo cristão, o
que pertence à moralidade; quer ao estado da glória futura, enquanto somos nela introduzidas por
Cristo, o que pertence à analogia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como o sentido da locução metafórica, na
Escritura, é literal, porque as palavras foram expressas para terem tal significação; assim também as
significações das cerimônias da lei — comemorativas dos benefícios de Deus, por causa dos quais foram
instituídas, — ou de instituições semelhantes, que diziam respeito a esse estado, não transcendem a
ordem das causas literais. Por onde, por uma causa literal é que se determinou a celebração da Páscoa,
porque era o sinal da libertação do cativeiro do Egito; e a circuncisão, que era sinal do pacto feito entre
Deus e Abraão.

RESPOSTA À SEGUNDA. — A objeção procederia se os preceitos cerimoniais tivessem sido dados só
para figurar o futuro, e não para nesse tempo cultuar a Deus.

RESPOSTA À TERCEIRA. — Assim como, conforme já dissemos (q. 96, a. 1) as leis humanas se fundam na
razão universal, e não em condições particulares dependentes do arbítrio dos que as instituem, assim
também, muitas determinações particulares das cerimônias da lei antiga, não tinham nenhuma causa
literal, senão só figurada; mas, em comum, também tinham causa literal.

## Art. 3 — Se se pode assinalar uma razão conveniente das cerimônias relativas aos sacrifícios.
(In Psalm. XXXIX; In Isaiam., cap. I; In Ioann., cap. I, lect. XIV).
O terceiro discute-se assim. — Parece que não se pode assinalar razão conveniente das cerimônias
relativas aos sacrifícios.

1. — Pois, no sacrifício se oferecia o necessário ao sustento da vida humana, como certos animais e
certos pães. Ora, Deus não precisa de tal sustento, conforme a Escritura (Sl 49, 13): Porventura comerei
carnes de touros? Ou beberei sangue de cabrito? Logo, inconveniente era oferecer tais sacrifícios a
Deus.

2. Demais. — No sacrifício divino não se ofereciam senão animais quadrúpedes dos três gêneros
seguintes: bois, ovelhas e cabras. E quanto às aves, em geral, a rôla e a pomba; e em especial, para a
cura dos leprosos, fazia-se o sacrifício de pardais. Ora, muitos animais há mais nobres que esses. E como
devemos oferecer a Deus tudo o que é ótimo, resulta que se lhe deviam oferecer sacrifícios não só dos
animais supra-referidos.

3. Demais. — Assim como o homem recebeu de Deus o domínio sobre as aves e os animais, assim
também sobre os peixes. Logo, inconveniente era excluir a estes do sacrifício divino.

4. Demais. — Ordenava-se oferecem-se indiferentemente rôlas e pombas. Por onde, assim como
mandavam oferecer os filhotes dos pombos, assim também deviam mandar se oferecessem os das
rôlas.

5. Demais. — Deus é o autor da vida, não só dos homens, mas também dos animais, como é claro pelo
que diz a Escritura (Gn 1, 20). Ora, a morte se opõe à vida. Logo, não deviam oferecer a Deus animais
mortos, mas ao contrário vivos, e tanto mais quanto também o Apóstolo adverte (Rm 12,
1): ofereçamos os nossos corpos como uma hóstia viva, santa, agradável a Deus.

6. Demais. — Se a Deus não se deviam oferecer em sacrifícios senão animais mortos, parece que não se
devia fazer nenhuma diferença entre os modos por que o era. Logo, inconveniente era determinar o
modo da imolação, sobretudo no que respeita às aves, como se vê na Escritura (Lv 1, 15 ss).

7. Demais. — Toda imperfeição do animal é via para a corrupção e a morte. Se pois se ofereciam a Deus
animais mortos, era inconveniente proibir a oferta de qualquer animal imperfeito, p. ex., manco, cego
ou com algum outro defeito.

8. Demais. — Os que oferecem vítimas a Deus devem participar delas, conforme aquilo do Apóstolo (1
Cor 10, 18): os que comem as vítimas por ventura não tem parte com o olhar? Logo, era inconveniente
subtrair aos oferentes certas partes das vítimas, como o sangue e a gordura, o peitinho e a espádua
direita.

9. Demais. — Assim como os holocaustos eram oferecidos em honra de Deus, assim também o eram as
hóstias pacíficas e as pelo pecado. Ora, nenhum animal do sexo feminino era oferecido a Deus como
vítima; faziam-se entretanto holocaustos tanto de quadrúpedes, como de aves. Logo, era inconveniente
oferecer animais do sexo feminino, como hóstias pacíficas e pelo pecado, sem entretanto, se
oferecerem aves para esse mesmo fim.
10. Demais. — Todas as hóstias pacíficas se consideravam como de um só gênero. Logo, não se devia
fazer diferença entre as hóstias, cuja carne não se podia, e outros, de que se podia comer no dia
seguinte, como se lê na Escritura (Lv 7, 15 ss).
11. Demais. — Todos os pecados tem isto de comum o afastarem de Deus. Logo, devia se oferecer um
só gênero de sacrifícios, por todos os pecados, para reconciliar com Deus.
12. Demais. — Todos os animais oferecidos em sacrifícios, o eram de um mesmo modo, i. é, mortos.
Logo, não parece conveniente se fizessem oblações de diversos modos de todos os produtos da terra;
pois, ora, eram oferecidas espigas, ora, flor de farinha, ora, pão cozido, umas vezes, no forno, outras, em
frigideira, outras, em grelhas.
13. Demais. — Devemos reconhecer como provindo de Deus tudo o que temos para o nosso uso. Logo,
era inconveniente, além dos animais, oferecer a Deus só pão, vinho, azeite, incenso e sal.
14. Demais. — Os sacrifícios de corpos exprimem o sacrifício interno do coração, pelo qual o homem
oferece o seu espírito a Deus. Ora, nesse sacrifício interior há mais da doçura, representada pelo mel, do
que do picante, representado pelo sal, conforme o dito da Escritura (Sr 24, 27): o meu espírito é mais
doce que o mel. Logo, inconvenientemente se proibia trazer, para o sacrifício, mel e fermento, que
também dá sabor ao pão; e se mandava oferecer sal, que é picante, e incenso, que é amargo de sabor.
— Logo, as coisas pertencentes às cerimônias dos sacrifícios não tinham causa racional.
Mas, em contrário, diz a Escritura (Lv 1, 13): o sacerdote queimará tudo sobre o altar em holocausto e
suave cheiro para o Senhor. Ora, como se diz noutro lugar (Sb 7, 28), Deus a ninguém ama senão ao que
habita com a sabedoria. Donde se pode concluir que tudo o que é recebido por Deus o é com sabedoria.
Logo, aquelas cerimônias dos sacrifícios se fundavam em sabedoria, tendo, como tinham, causas
racionais.

SOLUÇÃO. — Como já se disse (a. 2), as cerimônias da lei antiga tinham dupla causa: uma literal, pela
qual se ordenavam ao culto de Deus; outra, figurada ou mística, enquanto ordenadas a figurar Cristo.
E num e noutro caso, podemos convenientemente assinalar a causa das cerimônias relativas aos
,
sacrifícios.
Assim, enquanto se ordenavam ao culto de Deus, de dois modos podemos compreender a causa dos
sacrifícios. — De um modo, enquanto representavam a ordenação da mente para Deus, para quem se
elevava o que oferecia o sacrifício. Ora, a ordenação reta da mente para Deus consiste em o homem
considerar como procedente dele, como do primeiro princípio, todas as coisas que tem; e para ele as
ordenar, como para o último fim. E isto era expresso pelas oblações e sacrifícios, pelos quais o homem
oferecia das suas coisas em honra de Deus, como em reconhecimento de as ter recebido d'Êle,
conforme o que disse Davi (1 Cr 29, 14):Tudo é teu; e o que recebemos da tua mão, nós isso mesmo te
oferecemos. Por onde, na oblação dos sacrifícios o homem proclamava que Deus é o princípio primeiro
da criação das coisas, e o fim último a que tudo se deve referir. — E como a ordenação reta da mente
para Deus consiste em a mente humana não reconhecer nenhum outro princípio, autor das coisas,
senão só Deus, nem constituir o seu fim em nenhuma outra coisa, por isso a lei proibia oferecer
sacrifício a quem quer que fosse, exceto Deus, conforme àquilo (Ex 22, 20): aquele que sacrificar aos
deuses, à exceção só do Senhor, morrerá. Por onde e de outro modo, podemos dar a razão da causa das
cerimônias relativas ao sacrifício, dizendo, que por elas os homens deixavam de fazer sacrifícios aos
ídolos. Por isso, também os preceitos sobre os sacrifícios não foram dados ao povo judeu, senão depois
que caiu na idolatria, adorando um bezerro de metal fundido. Sendo assim, esses sacrifícios foram
instituídos, para que o povo, pronto a sacrificar, os oferecesse antes a Deus que aos ídolos. Donde o
dizer Jeremias (Jr 7, 22) — Eu não falei com vossos pais, nem lhes mandei, no dia em que os tirei da
terra do Egito, coisa alguma acerca dos holocaustos e das vítimas.
Dentre todos os dons, porém, que Deus fez ao gênero humano, já caído no pecado, o principal foi o de
seu Filho. Donde o dizer a Escritura (Jo 3, 16): assim amou Deus ao mundo, que lhe deu o seu Filho
unigênito, para que todo o que crê nele não pereça, mas tenha a vida eterna. Por isso, o maior dos
sacrifícios foi o de Cristo, que se entregou a si mesmo, em odor de suavidade, no dizer da Escritura (Ef 5,
2). E, todos os outros sacrifícios da lei antiga eram oferecidos para figurarem esse sacrifício singular e
precípuo, como o perfeito é figurado pelo imperfeito. Donde o dito do Apóstolo (Heb 10, 11), que o
sacerdote da lei antiga oferecia muitas vezes as mesmas hóstias, que nunca podem tirar os pecados;
mas, Cristo, ofereceu uma só hóstia pelos pecados, sempiternamente. E como do figurado se deduz a
razão de ser da figura, as razões dos sacrifícios figurativos da lei antiga devem-se deduzir do verdadeiro
sacrifício de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus não queria que tais sacrifícios lhe fossem
oferecidos, por causa das coisas mesmas oferecidas, como se delas precisasse; donde o dizer a Escritura
(Is 1, 11): não quero mais holocaustos de carneiro, nem gordura d'animais médios, nem sangue de
bezerros, nem de cordeiros, nem de bodes. Mas, queria que lh'os oferecessem como já se disse, quer
para excluir a idolatria, quer para fazer sentir a ordem devida da mente humana para Deus; quer
também para figurar o mistério da redenção humana operado por Cristo.

RESPOSTA À SEGUNDA. — Havia uma razão conveniente para que fossem oferecidos a Deus em
sacrifício todos esses animais referidos e não, outros. — A primeira era para excluir a idolatria. Porque
todos os outros animais os idólatras os ofereciam aos seus deuses, ou deles usavam para malefícios. Ao
passo que era abominável imolar os animais referidos, entre os egípcios, com quem conviviam os
judeus; e por isso aqueles não os ofereciam aos seus deuses, em sacrifício. Por isso, diz a Escritura (Ex 8,
26): Viremos a fazer sacrifícios ao Senhor nosso Deus, o que os Egípcios têm por uma abominação. Pois,
prestavam culto às ovelhas; veneravam os bodes, porque na figura deles os demônios apareciam; e
enfim, usavam dos bois para a agricultura, que tinham como parte das coisas sagradas. — A segunda
razão era por serem os sacrifícios desses animais convenientes para a referida ordenação da mente para
Deus. E isto de dois modos. Primeiro, porque com esses animais é que sobretudo se sustenta a vida
humana; e sendo eles os mais puros, dão a mais pura nutrição. Ao passo que, dos outros animais, uns
são silvestres e não apropriados comumente ao uso dos homens; ou, se domésticos, proporcionam
nutrição imunda, como o porco e a galinha. Ora, só o que é puro devemos oferecer a Deus. Quanto às
aves referidas, eram as especialmente sacrificadas, por existirem copiosamente na terra da promissão.
Segundo, porque a imolação desses animais designava a pureza da mente. Pois, diz a Glosa: oferecemos
o bezerro, quando vencemos a soberba da carne; o cordeiro, quando corrigimos os movimentos
irracionais; o bode, quando superamos a lascívia; a pomba, quando somos simples; a rola, quando
guardamos a castidade; os pães ázimos, quando nos nutrimos do ázimo da sinceridade.Pois, é
manifesto, que a pomba exprime a caridade e a simplicidade do coração. — Em terceiro lugar, era
conveniente serem oferecidos tais animais, como figurando a Cristo. Pois, diz a mesma Glosa: Cristo era
oferecido no bezerro, por causa da virtude da cruz; no cordeiro, por causa da inocência; no carneiro, por
causa do principado; no bode, por causa da semelhança com a carne do pecado; na rôla e na pomba,
mostrava-se a união das duas naturezas; ou a rola significava a castidade, e a pomba, a caridade. Com
flor de farinha, figurava-se a aspersão dos crentes pela água do batismo.

RESPOSTA À TERCEIRA. — Os peixes, que vivem na água, são mais alheios ao homem que os outros
animais, que vivem no ar, como ele próprio. E além disso, tirados dela logo morrem; por isso não
podiam, como os outros animais, ser oferecidos no templo.

RESPOSTA À QUARTA. — As rolas já crescidas são melhores que os filhotes; com as pombas, porém, dá-
se o contrário. Por isso, como diz Rabbi Moisés, mandavam se oferecer rolas e filhotes de pombas;
porque devemos oferecer a Deus tudo o que é ótimo.

RESPOSTA À QUINTA. — Os animais oferecidos em sacrifício eram mortos, para assim, serem
consumidos pelos homens; pois Deus lhos deu como alimento. E também eram queimados no fogo,
porque, cozidos nele, se tornam apropriados à alimentação humana. — Semelhantemente, a imolação
dos animais significava a destruição dos pecados; e que os homens eram dignos de morte, pelos seus
pecados, isso significando esses animais sacrificados em lugar deles, para a expiação de tais pecados. —
E também a imolação desses animais significava a imolação de Cristo.

RESPOSTA À SEXTA. — A lei determinava um modo especial de imolar os animais, para excluir outros
modos pelos quais os idólatras os imolavam aos ídolos. Ou também, como diz Rabbi Moisés, a lei
escolhia o gênero de morte que menos fizesse sofrer os animais imolados, pelo que também se excluía a
falta de misericórdia dos oferentes, e a deterioração dos animais mortos.

RESPOSTA À SÉTIMA. — Os animais defeituosos são de ordinário desprezados, mesmo pelos homens;
por isso era proibido oferecê-los em sacrifício a Deus. Pela mesma razão era proibido oferecer na casa
de Deus o ganho da prostituta ou o preço do cão. E por isso também não ofereciam animais antes do
sétimo dia de terem nascido; por serem quase abortivos e não ainda plenamente constituídos, pela sua
tenra idade.

RESPOSTA À OITAVA. — Havia três gêneros de sacrifícios. — Um era aquele em que se consumiam
totalmente as vítimas; e por isso se chamava holocausto, que significa queimado totalmente. E esse
sacrifício era oferecido a Deus especialmente para Lhe reverenciar a majestade e o amor da sua
bondade; e convém ao estado de perfeição, no implemento dos conselhos. Por isso tudo se queimava
para significar que, assim como o animal todo, resolvido em vapor, sobe aos ares, assim também o
homem todo, com tudo o que lhe pertence, está sujeito ao domínio de Deus, a quem deve oferecer-se.
Outro era o sacrifício pelos pecados, oferecido a Deus, pela necessidade de os remir; e convém ao
estado dos penitentes para a satisfação dos pecados. Continha duas partes, das quais, uma se queimava
e cedia-se a outra para ser consumida pelos sacerdotes, para significar que a expiação dos pecados sefaz
por Deus, pelo ministério dos sacerdotes. Salvo, quando o sacrifício era oferecido pelo pecado de todo o
povo, ou especialmente, pelo do sacerdote; pois então as vítimas eram totalmente queimadas. Porque
não devia destinar-se a alimento dos sacerdotes o que era oferecido pelo pecado deles, para que neles
não ficasse nada de pecaminoso. E porque, em tal caso, não haveria satisfação pelo pecado; pois, se as
vítimas devessem ser comidas por aqueles por cujos pecados eram oferecidas, seria o mesmo que não o
terem sido.
O terceiro sacrifício era o chamado hóstia pacífica, oferecido a Deus, ou em ação de graças, ou pela
saúde e prosperidade dos oferentes, como dívida do benefício a receber ou já recebido. E convém ao
estado dos que progridem, no cumprir os mandamentos. E estes sacrifícios continham três partes, das
quais, uma era queimada em honra de Deus; a outra cedia-se para ser comida pelos sacerdotes; a
terceira, enfim, para ser comida pelos oferentes. Isto tudo para significar que a salvação do homem vem
de Deus, sob a direção dos seus ministros, e com a cooperação dos próprios homens que são salvos.
Além disso, era geralmente observado, que o sangue e a gordura não deviam ser comidos pelos
sacerdotes nem pelos oferentes. Sendo o sangue derramado na base do altar, em honra de Deus; e a
gordura, consumida no fogo. — E uma razão disso era excluir a idolatria; pois, os idólatras bebiam o
sangue das vítimas e comiam as gorduras, conforme a Escritura (Dt 32, 38): De cujas vítimas comiam as
banhas e bebiam o vinho das libações. — A segunda razão era a direção da vida humana. Pois, proibia-se
o uso do sangue para causar horror da efusão do sangue humano; donde o dizer a Escritura (Gn 9, 4-
5): Não comereis carne com sangue; porque eu requererei o sangue das vossas almas. E comer as
gorduras, para evitar a lascívia; donde a Escritura (Ez 34, 3): matáveis o que era mais gordo. — A terceira
razão se fundava na reverência divina. Pois, o sangue é o que há de mais necessário à vida, vindo de aí o
dizer-se, que a alma está no sangue; ao passo que a gordura indica a abundância da nutrição. Por onde,
para se mostrar que de Deus nos vem a vida e a abundância de todos os bens, em honra d'Êle se
derramava o sangue e queimava a gordura. — A quarta razão era que a efusão do sangue significava a
do sangue de Cristo; e a gordura, a abundância da sua caridade, pela qual se ofereceu a Deus por nós.
Das hóstias pacíficas cediam-se para serem comidos pelos sacerdotes, o peitinho e a espádua direita,
para excluir uma certa espécie de adivinhação, chamada espatulamância. Pois faziam-se adivinhações
com as espáduas dos animais imolados e, semelhantemente, com os ossos do peito; razão pela qual
dessas partes eram privados os oferentes. — Mas isso também significava que ao sacerdote era
necessária a sabedoria do coração, para instruir o povo, significada pelo peito, que cobre o coração; e
também a fortaleza, para suportar os defeitos, significada pela espádua direita.

RESPOSTA À NONA. — Como o holocausto era o perfeitíssimo dos sacrifícios, só o macho era desse
modo oferecido, porque a fêmea é um animal imperfeito. Por outro lado, a oblação das rolas e das
pombas era por causa da pobreza dos oferentes, que não podiam oferecer animais maiores. E como as
hóstias pacíficas eram oferecidas gratuitamente, e ninguém as oferecia obrigado, senão
espontaneamente, as aves referidas não eram oferecidas como hóstias dessa espécie, mas como
holocaustos e vítimas pelo pecado, que às vezes era necessário oferecer. E demais, essas aves, por causa
da altura do seu vôo, convinham à perfeição dos holocaustos; e também a serem vítimas pelo pecado,
por terem, como canto, o gemido.

RESPOSTA À DÉCIMA. — O holocausto era o principal dentre todos os sacrifícios; porque a vítima toda
era queimada em honra de Deus e nada dela se comia. — O segundo lugar, na santidade, tinha-o a
vítima pelo pecado, comida só no átrio, pelos sacerdotes, no dia mesmo do sacrifício. — O terceiro, era
o da vítima pacífica, em ação de graças, comida no mesmo dia, mas em todos os lugares de Jerusalém.
— O quarto, o da hóstia pacífica, em virtude de voto, cujas carnes podiam ser comidas no dia seguinte.
— E a razão desta ordem é que o homem tem obrigações, para com Deus, sobretudo, por causa da sua
majestade; em segundo lugar, por causa da ofensa cometida; em terceiro, pelos benefícios já recebidos;
em quarto, pelos benefícios esperados.

RESPOSTA À UNDÉCIMA. — Os pecados se agravam pelo estado do pecador, como dissemos (q. 73, a.
10). Por isso, mandavam-se oferecer as outras vítimas pelo pecado do sacerdote e do príncipe, ou de
alguma pessoa privada. Pois, deve-se atender, como diz Rabbi Moisés, a que, quanto mais grave era o
pecado, tanto mais vil era a espécie do animal por ele oferecida. Por isso, a cabra, o mais vil de todos,
era oferecida pela idolatria, o gravíssimo dos pecados; ao passo que, pela ignorância do sacerdote, era
oferecido um bezerro; e pela negligência do príncipe, um bode.

RESPOSTA À DUODÉCIMA. — A lei, nos sacrifícios, quis prover à pobreza dos oferentes. De modo que,
quem não pudesse ter um quadrúpede, oferecesse pelo menos uma ave; o que não a pudesse ter,
oferecesse ao menos um pão; e quem ainda esse não o pudesse ter, oferecesse ao menos farinha ou
espigas. — E a causa figurada disso era que o pão significava Cristo, pão vivo, como diz a Escritura (Jo 6,
41-51). E Cristo, na fé dos patriarcas, existia como espiga, no estado da lei da natureza; como flor de
farinha, na doutrina da lei e dos profetas; como pão formado, depois que assumiu a humanidade; como
pão cozido, i. é, formado pelo Espírito Santo, no forno do útero virginal;que também foi cozido em
frigideira, por causa dos trabalhos que sofreu no mundo; e enfim, na cruz, como que queimado em
grelhas.

RESPOSTA À DÉCIMA TERCEIRA. — Os produtos da terra, de que o homem lança mão, ou lhe servem de
comida, e desses se oferecia o pão; ou de bebida, dos quais se oferecia o vinho; ou de condimento, e
dentre esses se oferecia o azeite e o sal; ou de remédios, e dentre esses se oferecia incenso, que é
aromático e fortificante. — Ora, o pão figurava a carne de Cristo; o vinho, o seu sangue, que nos remiu;
o azeite, a graça de Cristo; o sal a ciência; o incenso, a oração.

RESPOSTA À DÉCIMA QUARTA. — O mel não era oferecido em sacrifício a Deus, quer por costumarem
oferecê-lo em sacrifício aos ídolos; quer, também para excluir toda doçura carnal e todo prazer dos que
pretendiam sacrificar a Deus. O fermento não era oferecido, para excluir a corrupção; e talvez também
era costume oferecê-lo nos sacrifícios aos ídolos. O sal o era, por impedir a corrupção pútrida, pois os
sacrifícios a Deus deviam ser puros; etambém porque o sal significava a discreção da sabedoria, ou
ainda, a mortificação da carne. O incenso era oferecido a Deus, para significar a devoção do coração,
necessária aos oferentes; e também o odor da boa fama, pois o incenso é resinoso e odorífero. E como o
sacrifício da inveja não procedia da devoção, mas antes, da suspeição, nele não se oferecia incenso.

## Art. 4 — Se se pode dar razão suficiente das cerimônias da lei antiga relativas às coisas sagradas.
(Ad Coloss., cap. II, lect. IV; Ad Hebr., cap. IX,lect. I).
O quarto discute-se assim. — Parece que das cerimônias da lei antiga, relativas às coisas sagradas, não
se pode dar razão suficiente.

1. — Pois, diz Paulo (At 17, 24): Deus, que fez o mundo, e tudo o que nele há, sendo ele o Senhor do céu
e da terra, não habita em templos feitos pelos homens. Logo, a lei antiga institui inconvenientemente,
para o culto de Deus, o tabernáculo ou templo.

2. Demais. — A estrutura da lei antiga não foi mudada senão por Cristo. — Ora, o tabernáculo designava
a estrutura dessa lei. Logo, não devia ser mudado pela edificação de nenhum templo.

3. Demais. — A lei divina deve sobretudo induzir os homens ao culto divino. Ora, para o desenvolver-se
do culto divino é necessário fazerem-se muitos altares e templos, como claramente se vê na lei nova.
Logo, mesmo no regime da lei antiga, não devia haver só um templo ou tabernáculo, mas muitos.

4. Demais. — O tabernáculo ou templo ordenava-se ao culto de Deus. Ora, em Deus devemos venerar
sobretudo a unidade e a simplicidade. Logo, não era conveniente que o tabernáculo ou templo se
distinguisse por certos véus.

5. Demais. — A virtude do primeiro motor, que é Deus, se manifesta primeiro na parte do Oriente, onde
começa o primeiro movimento. Ora, o tabernáculo foi instituído para a adoração de Deus. Logo, devia
estar voltado mais para o Oriente que para o Ocidente.

6. Demais. — O Senhor mandou (Ex 20, 4) não se fizesse imagem de escultura, nem figura alguma. Logo,
inconvenientemente se esculpiram, no tabernáculo ou templo, imagens de querubins.
Semelhantemente, aí se viam, sem causa racional, a arca, o propiciatório, o candelabro, a mesa e o altar
duplo.

7. Demais. — O Senhor mandou (Ex 20, 24): Far-me-eis um altar de terra. — E ainda (Ex 20, 26): Não
subirás por degraus ao meu altar. Logo, inconvenientemente se mandou, depois, fazer um altar de ma-
deira, ouro ou cobre, e de tanta altura, que só por degraus se podia subir a ele. Pois, diz a Escritura (Ex
27, 1-2): Farás também um altar de pau setim, o qual terá cinco côvados ao cumprimento e outros
tantos de largura, e terá três côvados de alto, e o cobrirás de cobre. E (Ex 30, 1-3): Farás um altar de
madeira de setim para queimar os perfumes. E o cobrirás de puríssimo ouro.

8. Demais. — Nas obras de Deus nada deve ser supérfluo, porque nem nas da natureza isso se dá. Ora, a
um tabernáculo ou casa basta uma coberta. Logo, era inconveniente se lhe sobre-porem muitas
cobertas, a saber: cortinas, cobertas de pele de cabra, peles de carneiro tintas de vermelho e peles
tintas de roxo.

9. Demais. — A consagração exterior significava a interior, cujo sujeito é a alma. Logo,
inconvenientemente era consagrado o tabernáculo e os seus vasos, que eram corpos inanimados.
10. Demais. — A Escritura diz (Sl 33, 2): Bendirei o Senhor em todo o tempo; seu louvor será semprena
minha boca. Ora, as solenidades são instituídas para louvar a Deus. Logo, não era conveniente se
estatuírem certos dias para realizar as solenidades. — De tudo isso resulta, que as cerimônias das coisas
sagradas não tinham causas convenientes.
Mas, em contrário, diz o Apóstolo (Heb 8, 4): os que oferecem os dons segundo a lei servem de modelo
e sombra das coisas celestiais; como foi respondido a Moisés quando estava para acabar o tabernáculo:
Olha, disse, faze todas as coisas conforme o modelo que te foi mostrado no monte. Ora, é muito
racional o que representa a imagem das coisas celestes. Logo, as cerimônias das coisas sagradas tinham
causa racional.

SOLUÇÃO. — Todo o culto externo de Deus se ordena principalmente a os homens o reverenciarem.
Ora, é próprio do afeto humano reverenciar menos o que é comum e sem distinção particular; e prestar
mais reverência e admiração ao que tem alguma excelência e se distingue do comum. E daí vem ter o
costume humano estabelecido, que os reis e os príncipes, que devem ser reverenciados pelos súbditos,
sejam ornados de vestes mais preciosas e também possuam habitações mais amplas e mais belas. E por
isso, era necessário fossem ordenados ao culto de Deus, certos tempos especiais, um tabernáculo
especial, vasos especiais e ministros especiais, para assim provocarem o espírito dos homens à maior
reverência d'Ele. — Semelhantemente, como já dissemos (a. 2; q. 100, a. 12; q. 101, a. 2), a estrutura da
lei antiga tinha por fim figurar o mistério de Cristo. Ora, é forçoso seja algo de determinado aquilo que
deve figurar alguma coisa; de modo que representa uma semelhança dela. Por onde, também era
necessário se observassem certas disposições especiais concernentes ao culto de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O culto de Deus implica duas condições: o Deus adorado
e os homens que o adoram. Ora, Deus, que é adorado, não se encerra em nenhum lugar material e por
isso, não era preciso se lhe construísse um tabernáculo especial ou um templo. Ao contrário, os homens
que o adoram, são seres corpóreos; e, por causa deles, era necessário se construísse um tabernáculo
especial ou um templo, para o culto de Deus. E isto por duas razões. — A primeira, que os homens,
reunidos nesse lugar, com o pensamento de serem destinados a adorar a Deus, o fizessem com maior
reverência. — A segunda, que a disposição desse templo ou do tabernáculo significasse algo de
condescende com a excelência da divindade ou humanidade de Cristo. E é o que diz Salomão (1 Rs 8,
27): se o céu e céu dos céus te não podem compreender, quanto menos esta casa que eu edifiquei? E,
em seguida acrescenta (1 Rs 8, 29-30): os teus olhos estejam abertos de noite e de dia sobre esta casa
da qual disseste: O meu nome estará nela; para ouvires a oração do teu servo e do teu povo de Israel.
Por onde é claro, que a casa do santuário não foi instituída para compreender a Deus, como se nela
habitasse localmente;mas para que aí habitasse o nome de Deus. Isto é, para que o conhecimento de
Deus se manifestasse pelo que se aí fazia e dizia; e para, pela reverência ao lugar, as orações se
tornarem mais dignas de serem ouvidas, pela devoção dos que oravam.

RESPOSTA À SEGUNDA. — A estrutura da lei antiga, quanto ao seu cumprimento, não foi mudada antes
de Cristo; mas só por Cristo isso se fez. Foi mudada, porém, quanto à condição do povo que ela regia.
Pois, primeiro, esteve no deserto, sem morada certa; depois, teve várias guerras com as nações vizinhas;
ultimamente, no tempo de Davi e de Salomão, viveu tempos tranqüilos. E então foi, pela primeira vez,
edificado o templo no lugar designado por Abraão, por indicação divina, para se aí fazerem as
imolações. Pois, como diz a Escritura (Gn 22, 2), o Senhor mandou a Abraão oferecesse o seu filho em
holocausto sobre um dos montes que eu te mostrar; e depois disse (Gn 22, 14), que pôs por nome
aquele lugar: O Senhor vê, quase, por previsão de Deus, fosse aquele lugar escolhido para o culto divino.
Pelo que diz a Escritura (Dt 12, 5-6): Vireis ao lugar que o Senhor vosso Deus escolher e oferecereis os
vossos holocaustos e vítimas. Ora, esse lugar, para a edificação do templo, não devia ser designado
antes do tempo predito, por duas razões dadas pelo Rabbi Moisés. A primeira, para que os gentios se
não apropriassem desse lugar. A segunda, para que não o destruíssem. A terceira enfim, para que
qualquer das tribos não pretendesse tê-lo como seu lote, donde nascessem demandas e litígios. Por
isso, não se devia edificar o templo enquanto não houvesse um rei, capaz de impedir esses litígios. E,
antes dessa edificação, ordenava-se ao culto de Deus um tabernáculo portátil por diversos lugares,
quase ainda não existente um lugar determinado para o culto divino. E esta é a razão literal da
diversidade do tabernáculo e do templo. — A razão figurada pode ser que essas duas coisas significavam
um duplo estado. O tabernáculo, que era mutável, significa o regime da vida presente também mutável.
O templo, por seu lado, fixo e permanente, o regime da vida futura, absolutamente invariável. E por
isto, na edificação do templo, diz a Escritura, que não se ouvia o som de martelo nem machado, para
significar que toda atividade perturbadora era estranha ao estado futuro. Ou, o tabernáculo significava o
regime da lei antiga; e o templo, construído por Salomão, o da lei nova. Por onde, na construção do
tabernáculo, só os judeus trabalharam; ao passo que, na do templo, cooperavam também os tírios e
sidónios, que eram gentios.

RESPOSTA À TERCEIRA. — A razão da unidade do templo ou do tabernáculo pode ser literal e figurada.
— A literal era a exclusão da idolatria; porque os gentios atribuíam templos diversos aos diversos
deuses. Por onde, para que se radicasse no espírito dos homens a fé na unidade divina, quis Deus se lhe
oferecesse sacrifício só num lugar. Ademais disso, para assim mostrar que o culto material não lhe é em
si mesmo aceito. Pelo que, impedia se oferecessem sacrifícios a cada passo e em toda parte. Ao
contrário, o culto da lei nova, em cujo sacrifício está contida a graça espiritual, é, em si mesmo, aceito
de Deus. Por isso, a lei nova admite a multiplicação dos altares e dos templos. Quanto ao pertencente
ao culto espiritual de Deus, que consistia na doutrina da lei e dos profetas, havia ainda, na lei antiga,
diversos lugares determinados, chamados sinagogas, em que o povo se reunia para louvar a Deus.
Assim, chamam-se também agora igrejas os lugares em que para louvá-Lo, se congrega o povo cristão.
Por onde, a nossa Igreja tomou o lugar do templo e da sinagoga; porque, sendo o seu sacrifício
espiritual, não distinguimos agora o lugar do sacrifício do lugar da doutrina. — A razão figurada pode
ser, que o templo e o tabernáculo significam a unidade da Igreja, militante, ou triunfante.

RESPOSTA À QUARTA. — Assim como a unidade do templo ou do tabernáculo representam a de Deus
ou da Igreja, assim também, a distinção entre um e outro representa a distinção entre as coisas sujeitas
a Deus, e que nos elevam a venerá-Lo. Pois, distinguiam-se no tabernáculo duas partes: a ocidental
chamada o Santo dos Santos; e a oriental, chamada Santo. E, enfim, ante ele, havia o átrio.
Ora, esta distinção se fundava em dupla razão. — Uma, pela qual o tabernáculo se ordenava ao culto de
Deus. E assim, as diversas partes do mundo estavam figuradas nas duas partes do tabernáculo. Pois, a
chamada Santo dos Santos simbolizava o mundo superior, que é o das substâncias espirituais; e a
chamada Santo, o mundo corpóreo. Por onde, o Santo se separava do Santo dos Santos por um véu, pin-
tado de quatro cores, símbolos dos quatro elementos. Essas eram: o bisso, símbolo da terra, porque o
bisso, i. é, o linho nasce da terra; a púrpura, símbolo da água, porque a cor purpúrea era feita de certas
conchas que se encontram no mar; o jacinto, que significava o ar, que tem cor de ouro; e a escarlata
duas vezes tinta, que designava o fogo. E isto era assim porque a matéria dos quatro elementos é um
impedimento que nos vela as substâncias incorpóreas. Por onde, no tabernáculo interior, i. é, no Santo
dos Santos, só o sumo sacerdote entrava, e uma só vez no ano, para significar que a perfeição final do
homem é a entrada no mundo espiritual. No tabernáculo exterior, i. é, no Santo, o sacerdote entrava
todos os dias, não porém o povo, que tinha acesso só ao átrio. Porque as coisas corpóreas o povo pode
percebê-las, mas as razões internas delas só os sapientes, refletindo, podem atingi-las. Quanto à razão
figurada, o tabernáculo exterior, chamado Santo simboliza o regime da lei antiga, como diz o Apóstolo
(Heb 9, 6 ss). Porque nele sempre entravam os sacerdotes para cumprirem o ofício de sacrificar.
Enquanto o tabernáculo interior, chamado Santo dos Santos significa a glória celeste, ou também o
regime espiritual da lei nova, que é um quase começo da glória futura, estado, em que Cristo nos
introduziu. E era figurado pela entrada só do sumo sacerdote, uma vez no ano, no Santo dos Santos. —
O véu, por seu lado, significava a ocultação dos sacrifícios antigos; e era ornado de quatro cores signifi-
cativas. O bisso, símbolo da pureza da carne; a púrpura, dos sofrimentos que os santos padeceram por
Deus; a escarlata duas vezes tinta, da dupla caridade para com Deus e o próximo; o jacinto, da
meditação celeste. — Mas o povo e os sacerdotes tinham relações diferentes com a lei antiga. Pois,
aquele assistia aos sacrifícios corporais que se ofereciam no átrio; ao passo que os sacerdotes
meditavam na essência deles, com fé mais explícita nos mistérios de Cristo. Por isso entravam no
tabernáculo exterior, que também estava separado do átrio por um véu, porque certas coisas, sobre o
mistério de Cristo eram veladas ao povo e conhecidas dos sacerdotes. Mas não lhes eram plenamente
reveladas, como depois, no Novo Testamento, conforme a Escritura (Ef 3, 5).

RESPOSTA À QUINTA. — Os judeus adoravam com a cara voltada para o ocidente; o que foi introduzido
na lei para excluir a idolatria, pois, todos os gentios, em reverência ao sol, adoravam voltados para o
oriente. Donde o dizer a Escritura (Ez 8, 16), que certos tinham as costas voltadas para o templo do
Senhor e as caras viradas para o oriente, e adoravam o sol nascendo. E era para excluir isso, que o
tabernáculo tinha o Santo dos Santos voltado para o ocidente, para o adorarem voltados para esse
ponto. — Quanto à razão figurada, pode ser que a estrutura do antigo tabernáculo se ordenava a
significar a morte de Cristo, figurada pelo ocaso, conforme a Escritura (Sl 67, 5): Aquele que sobe sobre
o ocidente, o Senhor é o seu nome.

RESPOSTA À SEXTA. — Pode-se dar uma razão literal e, outra, figurada do que se continha no
tabernáculo. — A literal é relativa ao culto divino. Ora, como já dissemos (ad 4), o tabernáculo interior,
chamado Santo dos Santos, significa o mundo superior das substâncias espirituais. Por isso, três coisas
continha esse tabernáculo: a arca do testamento, na qual havia uma urna de ouro, que continha o
maná, e a vara de Aarão, que tinha florescido, e as tábuas do testamento, nas quais estavam escritos os
dez preceitos do decálogo. — E essa arca estava situada entre dois querubins, olhando um para outro.
— Sobre a arca havia uma tábua, chamada propiciatório, apoiada nas azas dos querubins, como se fosse
levada por eles, e levando a imaginar que essa tábua fosse o assento de Deus. E se chamava
propiciatório, querendo significar que Deus, daí, se tornava propício ao povo, pelas preces do sumo
sacerdote. E era conduzido pelos querubins, como sendo os que seguem a Deus. Quanto à arca do
testamento, era um como escabelo de quem estava sentado no propiciatório.
Ora, essas três coisas simbolizam três outras existentes no referido mundo superior. — Deus, que está
acima de todas as coisas e é incompreensível a todas as criaturas. E por isso, não punham nenhuma
figura que lhe representasse a invisibilidade, mas sim, a do seu assento, porque concebemos criatura
enquanto sujeita a Deus, como o assento a quem se assenta. — Há também, nesse mundo superior,
substâncias espirituais chamadas anjos. E estes eram simbolizados pelos dois querubins, olhando um
para o outro, para designar a concórdia dos anjos entre si, conforme àquilo da Escritura (Jó 25,
2): aquele que mantém a concórdia nas alturas. Também não havia um só querubim, para que se de-
signasse a multidão dos espíritos celestes, e se impedisse o culto deles aqueles a quem foi ordenado
adorassem um só Deus. — Demais, nesse mundo inteligível, estão de certo modo, encerradas as razões
eternas do que neste mundo fazemos, assim como as razões dos efeitos estão encerradas nas suas
causas, e, no artífice, as das coisas artificiadas. O que é simbolizado pela arca, que continha três coisas
representativas das três coisas humanas de maior valor, a saber: a sabedoria, simbolizada nas tábuas do
testamento; o poder governamental, na vara de Aarão; e a vida, representada pelo maná, que foi o
sustento dela. Ou ainda, essas três coisas significam os três atributos de Deus: as tábuas, a sabedoria; a
vara, o poder; o maná, a bondade, quer pela sua doçura, quer porque Deus o deu ao seu povo, por
misericórdia, sendo, por isso, conservado, em memória dessa misericórdia.
Essas três coisas também estão figuradas na visão de Isaías. Viu ele ao Senhor sentado num sólio excelso
e elevado, assistido de Serafins, e o templo cheio da glória de Deus. Por isso, clamavam os Serafins:
Cheia está toda a terra da sua glória (Is 6, 1-3). E assim, as imagens dos Serafins não foram aí postas para
receberem culto, o que era proibido pelo primeiro preceito da lei, mas como sinal de ministério,
conforme dissemos.
Por seu lado, o tabernáculo exterior, significativo do século presente, também continha três coisas: o
altar do timiama, posto diretamente contra a arca; a mesa da proposição, na qual se punham os doze
pães, colocada na parte norte; e o candelabro, na parte sul.
E essas três coisas são consideradas como correspondentes às três encerradas na arca, representando,
mas mais manifestamente, o mesmo que elas. Pois é necessário seja, das razões eternas das coisas,
dada mais clara manifestação da existência que têm na mente divina e dos anjos, para poderem os
sábios conhecê-las, sábios simbolizados nos sacerdotes que entram no tabernáculo. — Por isso, o
candelabro designa como em sinal sensível, a sabedoria, expressa nas tábuas por palavras inteligíveis. —
O altar do timiama, o ofício dos sacerdotes, a quem pertence trazer o povo para Deus; o que também é
significado pela vara. Pois, nesse altar se queimava o timiama do bom odor, que significa a santidade do
povo, agradável a Deus; porque, como diz a Escritura (Ap 8, 3), o fumo dos aromas exprime as
justificações dos santos. A dignidade sacerdotal é significada, na arca, pela vara, e no tabernáculo
exterior, pelo altar do timiama. Porque o sacerdote é o mediador entre Deus e o povo, que governa por
poder divino, simbolizado pela vara; e oferecia a Deus, quase no altar do timiama, o fruto do seu
governo, i. é, a santidade do povo. — A mesa, bem como o maná, significam o sustento temporal da
vida; mas o que estava naquela era um alimento mais comum e grosseiro, ao passo que o maná era mais
suave e delicado. O candelabro estava convenientemente colocado na parte austral, e a mesa, na aqui-
lonar; porque aquela é a parte direita do mundo, ao passo que esta é a esquerda, como diz Aristóteles.
A sabedoria pertencia à parte direita, assim como os outros bens espirituais; enquanto que a nutrição
temporal, à esquerda, conforme a Escritura (Pr 3, 16): Na sua esquerda, as riquezas e a glória. Enfim, o
poder sacerdotal é um meio termo entre as coisas temporais e a sabedoria espiritual, pois por ela é
dispensada a sabedoria espiritual e as coisas temporais.
Mas também se pode dar dessas coisas outra razão, mais literal. — Na arca estavam contidas as tábuas
da lei, para impedir o esquecimento dela; donde o dizer a Escritura (Ex 24, 12): dar-te-ei duas tábuas de
pedra e a lei e os mandamentos, que eu escrevi para ensinares os filhos de Israel. — A vara de Aarão
estava aí colocada para reprimir a dissensão entre o povo e o sacerdócio do mesmo, conforme a
Escritura (Nm 17, 10):Torna a levar a vara de Aarão para o tabernáculo do testemunho, para se guardar
ali em memória dos rebeldes filhos de Israel. — O maná era conservado na arca, para comemorar o
benefício que Deus fez aos filhos de Israel no deserto, e por isso, diz a Escritura (Ex 16, 32): Enche um
gomor dele e guarde-se para todas as gerações futuras, para que saibam qual foi o manjar com que eu
vos sustentei no deserto. — O candelabro foi instituído para a honorificência do tabernáculo; pois
importa à magnificência da casa o ser bem iluminada. Tinha sete ramos, como diz Josefo, para significar
os sete planetas, que iluminam todo o mundo. E foi colocado na parte austral, porque dela é que se
movem os planetas, em relação a nós. — O altar, do timiama foi instituído para que sempre houvesse
no tabernáculo o fumo do bom odor, quer para veneração do tabernáculo, quer também para remédio
contra o mau cheiro, que necessariamente resultava do sangue derramado e da imolação dos animais.
Pois, o fétido é desprezado como vil; ao passo que todos apreciam muito o que tem bom odor. — A
mesa foi posta para significar que os sacerdotes, servidores do templo, deviam nele se alimentar. Por
isso, só eles podiam comer dos doze pães superpostos na mesa, em memória das doze tribos, conforme
se lê na Escritura (Mt 12, 4). E não estava colocada diretamente no meio, diante do propiciatório, para
excluir o rito da idolatria. Porque os gentios, nos sacrifícios à lua, colocavam a mesa em frente do ídolo
da lua; donde o dizer a Escritura (Jr 7, 18): as mulheres misturam a manteiga para fazerem tortas à
rainha do céu. — O átrio, fora do tabernáculo, continha o altar dos holocaustos, onde se ofereciam a
Deus, em sacrifício, das coisas pertencentes ao povo. E por isso, este podia ficar no átrio, e oferecia os
seus bens a Deus, por mãos dos sacerdotes. Mas só os sacerdotes, a quem competia oferecer o povo a
Deus, é que podiam ter acesso ao altar interior, no qual era oferecida a devoção e a santidade do povo.
E esse altar estava colocado no átrio, fora do tabernáculo, para impedir o culto da idolatria; pois os
gentios levantavam altares, dentro dos templos, para imolar aos ídolos. Quanto à razão figurada de
todas essas coisas, pode ser descoberta na relação do tabernáculo com Cristo, a quem figura. Por onde,
devemos considerar que, para designar a imperfeição das figuras legais, instituíram-se, no templo,
diversas figuras significativas de Cristo. — Assim, é significado pelo propiciatório, porque ele é a
propiciação pelos nossos pecados, como diz a Escritura (1 Jo 2, 2). E era conveniente fosse o propi-
ciatório levado pelos Querubins, porque de Cristo foi escrito (Heb 1, 6): E todos os anjos de Deus o
adorem. — Também a arca significa a Cristo, porque, assim como era construída de pau setim, assim, o
corpo de Cristo é composto de membros puríssimos. Era dourada, porque Cristo é cheio de sabedoria e
caridade, simbolizadas pelo ouro. Dentro da arca havia uma urna de ouro, isto é, a alma santa, que
encerra o maná, i. é, toda a plenitude da divindade. E ainda nela estava a vara, i. é, o poder sacerdotal,
porque Cristo foi constituído pontífice eterno. Também nelas estavam as tábuas do testamento, para
significar que Cristo mesmo é legislador. — Demais, Cristo é simbolizado pelo candelabro, porque, ele
próprio o disse (Jo 8, 12): Eu sou a luz do mundo. As sete lâmpadas significam os sete dons do Espírito
Santo. — É também simbolizado pela mesa, porque Ele é o alimento espiritual, conforme a Escritura (Jo
6, 41-51): Eu sou o pão vivo; os doze pães significam os doze apóstolos ou a doutrina deles. Ou então, o
candelabro e a mesa podem significar a doutrina e a fé da Igreja, que ilumina e refaz ao mesmo tempo.
Também Cristo é simbolizado no duplo altar, o das holocaustos e o do timiama. Porque, por Ele,
devemos oferecer a Deus todas as obras virtuosas, tanto aquelas pelas quais mortificamos a carne,
como que oferecidas no altar dos holocaustos; como as que, com maior perfeição da mente, pelos
desejos espirituais dos perfeitos, oferecemos a Deus em Cristo, como que no altar do timiama,
conforme a Escritura (Heb 13, 15): Ofereçamos, pois, por ele a Deus sem cessar sacrifício de louvor.

RESPOSTA À SÉTIMA. — O Senhor mandou se construísse um altar onde se deviam oferecer os
sacrifícios e os dons, em honra de Deus e para sustento dos ministros, que serviam no tabernáculo. E
sobre a construção desse altar, o Senhor deu duplo preceito.
Um, no princípio da lei, quando mandou que fizessem um altar de terra, ou ao menos, de pedras não
lavradas; e demais, que não fizessem um altar elevado onde devessem subir por degraus. E isto para
detestarem o culto da idolatria. Pois os gentios construíam aos ídolos altares ornados e altos, onde
acreditavam haver algo da santidade e da divindade. Razão pela qual também o Senhor mandou (Ex 20,
24 ss): Não plantarás bosque nem árvore alguma ao pé do altar do Senhor teu Deus; porque os idólatras
costumavam sacrificar debaixo das árvores, por causa da amenidade do lugar e da sombra. — E destes
preceitos também há uma razão figurada. Pois, em Cristo, que é o nosso altar, devemos admitir a verda-
deira natureza da carne, quanto à sua humanidade — e isso significa o construir um altar de terra; e
também, quanto à divindade, devemos admitir nele a igualdade com o Pai — e isso significa o não subir
por degraus ao altar. E nem devemos, ao lado de Cristo, admitir a doutrina dos gentios, que provoca a
lascívia.
Feito porém o tabernáculo em honra de Deus, não eram para temer tais ocasiões de idolatria. Por isso, o
Senhor mandou se fizesse, para os holocaustos, um altar de bronze, que estivesse patente a todo o
povo; e de ouro, o altar do timiama, que só os sacerdotes viam. Assim, não era tanta a preciosidade do
bronze, que provocasse o povo a alguma idolatria.
Mas, a Escritura dá como razão do preceito (Ex 20, 26) — não subirás por degraus ao meu altar — o que
logo acrescenta: para que se não descubra a tua torpeza. Por onde, devemos considerar que também
isso foi instituído para excluir a idolatria; pois, nos sacrifícios a Priapo, os gentios descobriam as partes
pudendas. Mas depois, foi ordenado aos sacerdotes usassem calções que lhes cobrissem essas partes. E,
assim, sem perigo, podia ser determinada uma altura tal do altar que, para oferecer os sacrifícios, a ele
subissem por uns degraus de madeira, não permanentes, mas trazidos na hora do sacrifício.

RESPOSTA À OITAVA. — O corpo do tabernáculo constava de umas tábuas eretas no sentido do
comprimento, cobertas por dentro de umas cortinas de quatro cores variadas, o saber, de bisso
retorcido, de cor de jacinto, de púrpura e de escarlata tinta duas vezes. Mas, essas cortinas cobriam só
os lados do tabernáculo. No teto do mesmo havia uma coberta de peles tintas de roxo; e, sobre esta,
outra de peles de carneiro tintas de vermelho; e por cima uma terceira, de umas peles de cabra, que
cobriam, não só o teto do tabernáculo, mas desciam até a terra e cobriam, exteriormente, as tábuas do
mesmo.
Ora, desta coberta, a razão literal, em comum, era servir de ornato e proteção do tabernáculo, de modo
que este fosse reverenciado. Em especial, porém, segundo alguns, as cortinas designam o céu sidéreo,
cheio de diversas e variegadas estrelas. As peles de cabra, as águas que estão sobre o firmamento; as
tintas de vermelho, o céu empíreo, em que estão os anjos; as tintas de roxo, o céu da santa Trindade.
A razão figurada dessas coisas é a seguinte. As tábuas, de que o tabernáculo era construído, significavam
os fiéis de Cristo, de que é a Igreja construída. O tabernáculo era coberto por dentro de tábuas de
quatro cores, porque os fiéis são ornados interiormente de quatro virtudes. Pois, como diz a Glosa, o
bisso retorcido significa a carne resplendente pela castidade; o jacinto, a mente desejosa das coisas
celestes; a púrpura, a carne sujeita ao sofrimento; a escarlata tinta duas vezes, a mente refulgente entre
os sofrimentos por amor de Deus e o amor do próximo. As cobertas do teto designam os prelados e os
doutores, que devem brilhar pela vida repassada das coisas celestes, o que é simbolizado pelas peles de
cor de jacinto; pela prontidão para o martírio, simbolizado pelas de escarlata tintas duas vezes; pela
austeridade de vida e a paciência nas adversidades, simbolizado pelas de cabra, que estavam expostas
aos ventos e às chuvas, como diz a Glosa.

RESPOSTA À NONA. — A santificação do tabernáculo e dos seus vasos tem uma causa literal, que era
fazer com que fossem tidos na maior reverência, como destinados que eram ao culto divino por essa
consagração. — A razão figurada é que essa santificação significa a espiritual, do tabernáculo vivo, i. é,
dos fiéis, que constituem a Igreja de Cristo.

RESPOSTA À DÉCIMA. — Na lei antiga havia sete solenidades temporais e uma contínua, como se pode
coligir da Escritura (Nm 28; 29). — Havia uma festividade quase contínua, porque todos os dias, de
manhã e de tarde, era imolado o cordeiro. E essa contínua festividade de um sacrifício perene
representa a perpetuidade da beatitude divina.
Das festas temporais, a primeira era a que se renovava em cada semana. E essa era a solenidade do
Sábado, celebrada em memória da criação das coisas, como já se disse. — Outra a que se repetia cada
mês, era a da Neomenia, celebrada para comemorar a obra do governo divino. Pois, as coisas do nosso
mundo inferior variam principalmente conforme o movimento da lua. Por isso, celebrava-se essa festa
na lua nova; e não no plenilúnio, para evitar o culto dos idólatras, que, nesse tempo, prestavam à lua. —
E como esses dois referidos benefícios são comuns a todo o gênero humano, essas festas se repetiam
mais freqüentemente.
As outras cinco festas celebravam-se uma vez por ano, e nelas se rememoravam os benefícios
especialmente feitos ao povo judeu. — Assim, celebrava-se a festa da Fase, no primeiro mês, para
comemorar o benefício da libertação do Egito. — A de Pentecostes, depois de cinqüenta dias, para
rememorar o benefício da lei que lhes foi dada.
As outras três festas eram celebradas no sétimo mês, que, como o sétimo dia, era quase inteiramente
solene, para os judeus. — Assim, no primeiro dia do sétimo mês, havia a festa das Trombetas, em
memória da liberação de Isaac, quando Abraão encontrou o carneiro preso pelos chifres, o qual
representavam pelas cornetas em que buzinavam. — E era a festa das Trombetas um quase convite para
se prepararem para a festa seguinte, celebrada no décimo dia. Era essa a da Expiação, em memória do
benefício de ter-se Deus tornado propício ao povo, a pedido de Moisés, depois do pecado da adoração
do bezerro. — A seguir, celebravam a da Scenopegia, i. é, dos Tabernáculos, durante sete dias, para
comemorar o benefício da divina proteção, guiando-os pelo deserto, onde habitaram em tabernáculos.
Por isso, nesse dia, deviam tomar o fruto da árvore mais formosa, i. é, do limoeiro; e uma árvore de
densas folhas, i. é, a murta, cujas folhas são odoríferas; e folhas de palmeira; e salgueiros da torrente,
que conservam por muito tempo o verdor. Tudo isso se encontra na terra da promissão, e era para
significar que Deus os conduziu através da terra árida do deserto, para uma terra deliciosa. — No oitavo
dia celebrava-se outra festa, a da Congregação e do Ajuntamento, em que se recebia do povo o
necessário para as despesas com o culto divino. E significava a união do povo e a paz concedida na terra
da promissão.
As razões figuradas dessas festas são as seguintes. O sacrifício perene do cordeiro figura a perpetuidade
de Cristo, que é o Cordeiro de Deus, conforme a Escritura (Heb 13, 8): Jesus Cristo era ontem e é hoje; o
mesmo será também por todos os séculos. — O Sábado designa a réquie espiritual, que Cristo nos deu,
como se lê na Escritura (Heb 4). — A Neomênia, começo da lua nova, significa a iluminação da primitiva
Igreja por Cristo, quando pregava e fazia milagres. — A festa de Pentecostes simboliza a descida do
Espírito Santo sobre os Apóstolos. — A das Trombetas, a pregação dos Apóstolos. — A da Expiação, a
purificação dos pecados do povo cristão. — A dos Tabernáculos, a peregrinação dos cristãos neste
mundo, onde passam progredindo nas virtudes. — A da Congregação e do Ajuntamento, a congregação
dos fiéis no reino celeste; e por isso essa festa era considerada santíssima. E essas três festas eram
contínuas, umas em relação às outras; porque é necessário progridam na virtude os que expiaram os
vícios, até chegarem à visão de Deus, como diz a Escritura (Sl 83, 8).

## Art. 5 — Se se podem dar causas convenientes aos sacramentos da lei antiga.
(III, q. 70, a. 1, 3; Ad Bom., cap. IV, lect. II; I Cor., cap. V, lect. II).
O quinto discute-se assim. — Parece que não se podem dar causas convenientes aos sacramentos da
lei antiga.

1. — Pois, o que se fazia para o culto divino não devia ser semelhante ao que observavam os idólatras.
Donde o dizer a Escritura (Dt 12, 31): Não farás assim com o Senhor teu Deus; porque eles fizeram pelos
seus deuses todas as abominações, que o Senhor aborrece. Ora, os adoradores dos ídolos, ao adorá-los,
cortavam-se com canivetes até a efusão do sangue, como refere a Escritura (1 Rs 18, 28), que se
retalhavam, segundo o seu costume, com canivetes e lancetas, até se cobrirem de sangue. Pelo que o
Senhor mandou (Dt 14, 1):Não fareis incisões, nem vos fareis abrir calva para chorardes algum morto;
porque és um povo santo para com o Senhor teu Deus, e ele te escolheu, dentre todas as nações que há
na terra para serdes particularmente o seu povo. Logo, a circuncisão era inconvenientemente instituída
pela lei.

2. Demais. — O que se faz para o culto divino deve ter dignidade e gravidade, conforme a Escritura (Sl
34, 18): No meio do povo numeroso te louvarei. Ora, implicauma certa leviandade o comer-se
apressadamente. Logo, é um preceito inconveniente o de comer apressadamente o cordeiro pascal. E
também se fizeram certas instituições sobre o modo de comer esse cordeiro, que parecem totalmente
irracionais.

3. Demais. — Os sacramentos da lei antiga são figuras dos da nova. Ora, o cordeiro pascal significa o
sacramento da Eucaristia, conforme a Escritura (1 Cor 5, 7): Cristo, que é a nossa Páscoa, foi imolado.
Logo, também a lei devia ter alguns sacramentos que prefigurassem outros da lei nova, como, a
confirmação, a extrema-unção, o matrimônio e os outros sacramentos.

4. Demais. — Só se pode fazer purificação do que constitui imundície. Ora, para Deus, nada é imundo,
porque todo corpo é criatura sua; e toda a criatura de Deus é boa, e não é para desprezar nada do que
se participa com ação de graças, como diz a Escritura (1 Tm 4, 4). Logo, era inconveniente que se
purificassem, por causa do contato com um homem morto, ou com qualquer infecção corporal
semelhante.

5. Demais. — A Escritura diz (Sr 34, 4): Que coisa será alimpada por um imundo? Ora, a cinza da vaca
vermelha queimada era imunda, porque tornava imundo. Pois, como diz a Escritura (Nm 19, 7 ss), o
sacerdote que a imolava ficava imundo até a tarde. Do mesmo modo, o que a queimava e quem lhe
ajuntava as cinzas. Logo, era um preceito inconveniente que, com essa cinza aspergida, os imundos se
purificassem.

6. Demais. — O pecado não é nada de material, que possa ser levado de um lugar para outro; nem pode
o homem purificar-se dele por meio do que é imundo. Logo, era inconveniente, para a expiação dos
pecados do povo, que o sacerdote confessasse sobre um bode os pecados dos filhos de Israel, para que
os levasse para o deserto. E por outro bode, que os sacerdotes imolavam, para as purificações, e era
queimado juntamente com um novilho, fora do arraial se tornassem imundos, de modo que
precisassem lavar as vestes e o corpo com água.

7. Demais. — O que já está limpo não precisa ser de novo purificado. Logo, era inconveniente que ao
homem ou a casa, purificados da lepra, se impusesse outra purificação.

8. Demais. — A imundícia espiritual não podia ser limpa pela água material ou pela raspagem dos pelos.
Logo, era irracional o Senhor ter ordenado se fizesse uma bacia de bronze com sua base, para lavatório
das mãos e dos pés dos sacerdotes, que houvessem de entrar no tabernáculo. Bem como também o era,
que se mandasse aos levitas lavarem-se com a água da expiação, e rasparem todos os pelos do corpo.

9. Demais. — O mais não pode santificar-se pelo menos. Logo, era inconveniente que, na lei, se fizesse a
consagração dos sacerdotes maiores e menores, e dos levitas por unção, sacrifícios e oblações
corpóreas.
10. Demais. — Como diz a Escritura (1 Sm 16, 7) o homem vê o que está patente, mas o Senhor olha
para o coração. Ora, o que é exteriormente patente, no homem, é a disposição corpórea e também as
vestes. Logo, era inconveniente se destinassem aos sacerdotes, maiores e menores, certas vestes
especiais, que refere a Escritura (Ex 28). E parece sem razão que alguém fosse impedido de ser
sacerdote, por causa de defeitos corpóreos, conforme se diz (Lv 21, 17): O homem de qualquer das
famílias da tua linhagem que tiver deformidade não oferecerá pães ao seu Deus; nem se for cego, se
coxo, etc. Por onde se conclui, que os sacramentos da lei antiga eram irracionais.
Mas, em contrario, diz a Escritura (Lv 20, 8): Eu sou o Senhor que vos santifico. Ora, Deus não faz nada
sem razão, conforme o salmo (Sl 103, 24): Todas as coisas fizeste com sabedoria. Logo, nos sacramentos
da lei antiga, que se ordenavam à santificação dos homens, nada havia sem causa racional.

SOLUÇÃO. — Como já dissemos (q. 101, a. 4), sacramentos propriamente se chamavam às coisas
atribuídas aos sacerdotes de Deus para alguma consagração, por meio de quem, elas, de certo modo, se
destinavam ao culto divino. Ora, o culto de Deus, de maneira geral, pertencia a todo o povo; mas, de
modo especial, aos sacerdotes e levitas, que eram os seus ministros. Por isso, nos sacramentos da lei
antiga, certas disposições pertenciam comumente a todo o povo; e certas outras, especialmente, aos
ministros. E em relação a ambos, três coisas eram necessárias. — A primeira, que cada um fosse posto
em estado de adorar a Deus, o que em geral todos faziam pela circuncisão, sem a qual ninguém era
admitido a nenhuma das cerimônias legais; e quanto aos sacerdotes, pela consagração. — Em segundo
lugar, era exigido o uso daquilo que pertencia ao culto divino. Por isso o povo fazia o banquete pascal,
ao qual não era admitido nenhum incircunciso, como se vê na Escritura (Ex 12, 43 ss). E os sacerdotes
faziam a oblação das vítimas, comiam o pão da proposição, e o mais para o que eram destinados. — Por
fim, exigia-se a remoção do que impedia o culto divino, i. é, das imundícias. E assim, para o povo,
instituíram-se certas purificações de determinadas imundícias exteriores, e também expiações dos
pecados. Para os sacerdotes e levitas instituiu-se a oblação das mãos, dos pés e a raspagem dos pêlos.
— E tudo isto tinha causas racionais literais, porque se ordenava ao culto de Deus, naquele tempo; e
figuradas, porque se ordena a figurar Cristo, como ficará claro por um exame minucioso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A razão literal da circuncisão, e a principal, era ser um
protesto de fé na unidade de Deus. E como Abraão foi o primeiro, que se separou dos infiéis, saindo da
sua casa e da sua parentela, foi o primeiro a receber a circuncisão. E nessa causa toca o Apóstolo (Rm 4,
9 ss): Recebeu o sinal da circuncisão como selo da justiça da fé que está no prepúcio; porque, como
nesse mesmo lugar se lê, pela fé de Abraão foi-lhe imputada a justiça, porque creu em esperança contra
a esperança, i. é, contra a esperança da natureza, na esperança da graça, para que se tornasse pai de
muitas gentes; pois era velho e velha também e estéril a sua esposa. E para que esse protesto e imitação
da fé de Abraão se firmasse nos corações dos judeus, recebiam na carne um sinal que não pudessem
esquecer. Donde a Escritura (Gn 17, 13):Este meu pacto será na vossa carne para concerto eterno. E, por
isso fazia-se no oitavo dia, porque, antes, a criança é muito tenra e podia causar-lhe mal grave, por ser
considerada como algo de ainda não consolidado. Razão por que nem os animais eram oferecidos antes
do oitavo dia. E não se deixava a circuncisão para mais tarde, afim de que, por causa da dor, não se lhe
quisesse fugir ao sinal; e também afim de que os pais, cujo amor para com os filhos vai aumentando
com a convivência continuada e com o crescimento deles, não quisessem subtraí-los a ela. — A segunda
razão podia ser o enfraquecimento da concupiscência no membro circunciso. — A terceira o escárnio
dos sacrifícios a Venus e a Priapo, nos quais era honrada essa parte do corpo. — Mas o Senhor não
proibiu senão a incisão, que se fazia no culto dos ídolos, ao que não se assemelhava a circuncisão de que
se trata.
A razão figurada da circuncisão é simbolizar que Cristo poria termo à corrupção; o que faria completa e
perfeitamente na oitava idade, que é a dos ressurretos. E como toda corrupção da culpa e da pena tem
em nós origem carnal, proveniente do pecado do primeiro pai, a circuncisão fazia-se no membro da
geração. Donde o dizer o Apóstolo (Cl 2, 11): Estais circuncidados em Cristo de circuncisão não feita por
mão de homem no despojo do corpo da carne, mais sim na circuncisão de Cristo.

RESPOSTA À SEGUNDA. — A razão literal do banquete pascal era a comemoração do benefício, de Deus
ter tirado os judeus do Egito; por isso, com a celebração desse banquete, confessavam constituir o povo
que Deus para si tirara do Egito. Mas, quando foram libertados, foi-lhes dado como preceito untarem a
padieira nas casas, significando isso um como protesto que não aceitavam os ritos dos egípcios, que
adoravam um carneiro. Por isso ficaram livres, pela aspersão do sangue do cordeiro, ou por untarem os
limiares das casas, do perigo de extermínio, iminente para os egípcios. Ora, a saída dos judeus do Egito
se realizou com as duas circunstâncias seguintes. Com pressa no andar, porque os egípcios os apertavam
a saírem velozmente, como se lê na Escritura (Ex 12, 33); e era iminente o perigo a quem não se
apressasse em sair com o povo, pois ficando, seria morto pelos egípcios. Essa pressa era significada, de
dois modos. Pelo que comiam; pois tinham como preceito comerem pães ázimos, em sinal de que os
egípcios lhes tinham dado tanta pressa a partir que não puderam meter-lhes o fermento. E também por
comerem o cordeiro assado ao fogo, porque assim era preparado mais rapidamente; e por não o despe-
daçarem, porque na pressa, não havia tempo de quebrar os ossos. De outro modo, quanto à maneira de
comer. Assim, diz a Escritura: cingireis os vossos rins, e tereis sapatos nos pés e bordões nas mãos, e
comereis à pressa, o que manifestamente designa homens que faziam caminho rápido. E o mesmo fim
visava o outro preceito: Há de comer-se em cada casa, nem das suas carnes tirareis nada para fora;
porque, pela pressa, não havia tempo de fazer brindes uns aos outros. Quanto às amarguras, que
sofreram no Egito, eram simbolizadas pelas alfaces agrestes. As razões figuradas são claras. A imolação
do cordeiro pascal significa a de Cristo, conforme a Escritura (1 Cor 5, 7): Cristo, que é a nossa Páscoa,
foi imolado. O sangue do cordeiro, que livrava do extermínio, untado nas padieiras das casas, significa a
fé na paixão de Cristo, no coração e na boca dos fiéis. Por ela nos libertamos do pecado e da morte,
conforme a Escritura (1 Pd 1, 18): Fostes redimidos pelo precioso sangue do cordeiro imaculado.
Comiam-lhe a carne para significar que comemos a carne do corpo de Cristo no sacramento.Eram
assadas ao fogo para significar a paixão ou a caridade de Cristo. Comiam-nas com pães ázimos para
significar a pureza do banquete dos fiéis, que comem o corpo de Cristo, segundo a Escritura (1 Cor 5,
8): Solenizemos o nosso convite, com os ázimos da sinceridade e da verdade. Acrescentavam asalfaces
agrestes; em sinal da penitência dos pecadores, necessária aos que recebem o corpo de Cristo. Os rins
devem ser cingidos com o cinto da castidade. Os sapatos dos pés são a imagem dos patriarcas mortos. O
báculo, que deviam ter nas mãos, significa a custódia pastoral. Também se mandava comessem numa
casa o cordeiro pascal, i. é, na Igreja dos Católicos e não, nos conventículos dos heréticos.

RESPOSTA À TERCEIRA. — Certos sacramentos da lei nova correspondem, figuradamente, a outros da
lei antiga. Assim, à circuncisão corresponde o batismo, que é o sacramento da fé. Por isso, diz a Escritura
(Cl 2, 11-12): Vós estais circuncidados na circuncisão de N. S. Jesus Cristo, estando sepultados
juntamente com ele no batismo. Ao banquete do cordeiro pascal corresponde, na lei nova, o
sacramento da Eucaristia. A todas as purificações da lei antiga, o sacramento da penitência. A
consagração do pontífice e dos sacerdotes, ao sacramento da ordem. Ao sacramento da confirmação,
que implica a plenitude da graça, nenhum sacramento da lei antiga podia corresponder, pois, ainda não
chegara o tempo da plenitude, porque, a lei ninguém levou àperfeição. O mesmo se dá com o da
extrema unção, que é uma preparação imediata para a entrada na glória, cujo adito ainda não fora
franqueado na lei antiga, porque o resgate ainda não tinha sido pago. O matrimônio estava, certo,
compreendido na lei antiga, enquanto pertencente à lei da natureza; mas não, enquanto sacramento
significativo da união de Cristo e da Igreja, ainda não realizada. Por isso, na lei antiga, dava-se libelo de
repúdio, que encontra a essência desse sacramento.

RESPOSTA À QUARTA. — Como já se disse, as purificações da lei antiga ordenavam-se a remover os
impedimentos do culto divino. Este era duplo: o espiritual, que consistia na elevação da mente para
Deus; e o corpóreo, consistente nos sacrifícios, nas oblações e coisas semelhantes. — Ora, do culto
espiritual, os homens ficavam privados pelo pecado, que, como se pensava, os poluía; assim, pela
idolatria e pelo homicídio, pelos adultérios e incestos. E dessas manchas se purificavam por certos
sacrifícios, ou oferecidos, em geral, por todo o povo, ou mesmo pelos pecados de cada um. Não que
esses sacrifícios carnais tivessem por si mesmos a virtude de expiar o pecado. Mas porque significam a
futura expiação dos pecados por Cristo, de que os antigos eram participantes, protestando a fé no
Redentor, em figuras de sacrifícios.
Do culto externo os homens ficavam privados por certas imundícias corpóreas. Estas eram, primeiro,
consideradas em relação a eles próprios, e, conseqüentemente, em relação às vestes, às casas e aos
vasos. Essas imundices provinham, em parte, dos homens mesmos; em parte, do contato com coisas
imundas. Quanto às primeiras, era considerado imundo o que já tinha alguma corrupção ou a alguma
estava exposto. Por isso, sendo a morte uma corrupção, o cadáver de um homem era considerado
imundo. Do mesmo modo, como a lepra provém da corrupção dos humores, que também irrompem
para fora e contaminam os outros, os leprosos eram considerados imundos. Semelhantemente, as
mulheres que sofriam de fluxo de sangue, por doença, ou também por natureza, ou no tempo do
mênstruo, ou, ainda, no da concepção. E pela mesma razão os homens eram considerados imundos, que
sofriam de fluxo seminal, quer por doença, quer por polução noturna, ou ainda, pelo coito. Pois, toda a
umidade saída do homem, desses modos sobreditos, implicavam infecção imunda. Também eles
contraíam uma certa imundícia pelo contacto com determinadas coisas imundas.
Ora, d' essas imundices podem-se assinalar razão literal e figurada. — A literal era a reverência ao que
pertencia ao culto divino; quer porque os homens não costumavam tocar nas coisas preciosas, quando
imundos, quer porque o raro acesso às coisas sagradas as tornava mais veneradas. Pois, como ninguém
podia, senão raramente, acautelar-se contra todas essas imundices, acontecia que só raramente podiam
tocar nas coisas pertencentes ao culto divino; e assim, quando se lhes achegavam, faziam-no com maior
reverência e humildade da mente. — Certas dessas imundices também tinham, como razão literal, fazer
com que os homens não temessem chegar-se ao culto divino, fugindo à sociedade dos leprosos e
semelhantes enfermos, cuja doença era abominável e contagiosa. — De certas outras a razão era fazer
evitar o culto da idolatria; porque os gentios, no rito dos seus sacrifícios, empregavam às vezes o sangue
e o sêmen humanos. — Mas, todas essas imundices corpóreas se purificavam, ou só pela aspersão da
água, ou, quando eram maiores, por algum sacrifício para expiar o pecado, donde provinham as tais
enfermidades.
A razão figurada é que, dessas imundícias as externas figuram diversos pecados. Assim, a de um
cadáver, significa a do pecado, que é a morte da alma. A da lepra, a da doutrina herética, quer porque
esta é contagiosa como aquela; quer porque não há nenhuma falsa doutrina que não vá mesclada com
alguma verdade; assim como também, na superfície do corpo do leproso, aparece uma certa distinção
entre as manchas e a carne sã. A imundice da mulher que sofre fluxo de sangue significa a da idolatria,
por causa do cruor da imolação. A do homem com fluxo seminal, a do vanilóquio, porque sêmen é a
palavra de Deus. A do coito e a da mulher que deu à luz, a do pecado original. A da mulher menstruada,
a da mente embotada pelos prazeres. E em geral, a imundice do contacto com coisa imunda designa a
do consentimento no pecado de outrem, conforme a Escritura (2 Cor 6, 17): Saí do meio deles, e
separai-vos dos tais e não toqueis o que é imundo.
E essa imundícia do contado atingia também as coisas inanimadas; pois, tudo o que, de qualquer modo,
o imundo tocava, ficava imundo. No que a lei atenuou a superstição dos gentios, que consideravam
contraída a imundice, não só pelo contado com o imundo, mas também pelo colóquio ou pela vista,
como refere Rabbi Moisés, sobre a mulher menstruada. E isto misticamente significava o que diz a
Escritura (Sb 14, 9): Deus igualmente aborrece ao ímpio e à sua impiedade.
Havia também uma certa imundice das coisas inanimadas em si mesmas, como era a da lepra, na casa e
nas vestes. Pois, assim como a doença da lepra procede, no homem, do humor corrupto, que putrefaz e
corrompe a carne, assim também, por uma certa corrupção e excesso de umidade ou de secura, opera-
se uma certa corrupção nas pedras da casa, ou ainda nas vestes. Por isso a lei chama lepra a essa
corrupção, que fazia considerar imunda uma casa ou a roupa. Quer, porque toda corrupção implica
imundice, como se disse; quer também porque, para evitar tais corrupções, os gentios prestavam culto
aos deuses Penates. Por isso a lei mandava destruir a casa em que tal corrupção perseverasse, e que as
vestes fossem queimadas, para evitar a ocasião da idolatria. Havia também uma imundice própria dos
vasos, da qual diz a Escritura (Nm 19, 15): O vaso que não tiver tapadura nem atadura sobre si, será
imundo. E a causa dessa imundice era que, em tais vasos, podia facilmente cair algo de imundo que os
contaminasse. Também tinha esse preceito por fim evitar a idolatria. Pois, os idólatras acreditavam, que
se ratos, lagartos ou outros animais semelhantes, que imolavam aos deuses, caíssem nos vasos ou nas
águas, estes lhes seriam gratos. E também certas mulheres do povo deixavam os vasos descobertos em
obséquio às divindades a que chamavam Ianas.
A razão figurada dessas imundices é a seguinte. A lepra na casa significa a imundice da reunião dos
heréticos; a no vestido de linho, a perversidade dos costumes, pela amargura da mente; a na roupa de
lã, a perversidade dos aduladores; a na urdidura, os vícios da alma; a na trama, os pecados carnais, pois,
assim como a urdidura está na trama, assim, a alma, no corpo. O vaso sem tapadura nem atadura, o
homem sem qualquer velame de taciturnidade, ou o que não é constrangido por nenhuma correção da
disciplina.

RESPOSTA À QUINTA. — Como já se disse (a. 4), a lei considerava dupla imundice. Uma, proveniente de
corrupção da mente ou do corpo, e esta era a maior. A outra, do só contato com o imundo, e era a
menor e expiável com rito mais fácil. Pois, a primeira era expiada por meio dos sacrifícios pelo pecado;
porque toda corrupção procede deste e o significa. Ao passo que a segunda o era só pela aspersão de
uma certa água de expiação, de que fala a Escritura (Nm 19).
Pois, nesse lugar, o Senhor manda que tomassem uma vaca vermelha, em memória do pecado, que
cometeram quando adoraram o bezerro. E diz uma vaca, e não um bezerro, porque, assim costumava
chamar à sinagoga, conforme àquilo (Os 4, 16): Israel se desencaminhou como uma vaca que não pode
sofrer o jugo. E isto talvez porque adoravam as vacas, seguido o costume do Egito, conforme o lugar da
Escritura (Os 10, 5):Adoravam as vacas de Bethaven. — E para fazer detestar o pecado da idolatria, era
imolada fora do arraial. E onde quer que se fizesse o sacrifício expiatório da multidão dos pecados, toda
ela era queimada fora do arraial. — E como se quisesse significar, por esse sacrifício, que o povo ficava
limpo da totalidade dos pecados, o sacerdote molhava o dedo no sangue dela e fazia com ele sete
aspersões, voltado para a porta do tabernáculo. E essa aspersão mesma do sangue era para fazer
detestar a idolatria, na qual o sangue da imolação não era espalhado, mas reunido, e em redor dele, os
homens comiam em honra dos ídolos. — A vaca era, ademais disso, queimada no fogo, quer porque
Deus, no fogo, apareceu a Moisés, e no mesmo foi dada a lei; quer para significar que se devia extirpar
totalmente a idolatria e tudo o que a ela pertencia; assim como da vaca eram consumidos na chama
tanto a pele e as carnes como o sangue e o excremento. — E acrescentava-se, na combustão, pau de
cedro, hissopo, escarlata duas vezes tinta, para significar que, como o pau de cedro não apodrece
facilmente, e a escarlata duas vezes tinta não perde a cor, e o hissopo conserva o cheiro, ainda depois
de estar dessecado; assim também esse sacrifício era pela conservação do povo, e da sua honestidade e
devoção. Por isso, diz a Escritura, das cinzas da vaca: Para que as guarde a multidão dos filhos de Israel.
Ou, segundo Josefo, nesse sacrifício simbolizavam-se os quatro elementos. Punha-se o cedro no fogo
para significar a terra, por causa da sua fixidez no solo; o hissopo, pelo seu cheiro, significava o ar; a
escarlata duas vezes tinta, a água, pela mesma razão por que também a significava a púrpura, por causa
da tinta, que se faz com água. De modo que tudo isto significava, que se oferecia ao Criador o sacrifício
dos quatro elementos. E como esse sacrifício era oferecido para fazer detestar o pecado da idolatria,
eram considerados imundos tanto o que queimou, como o que recolheu as cinzas e o que fazia a
aspersão da água misturada com a cinza. Isto porque tudo o atinente, de certo modo, à idolatria devia
ser rejeitado como imundo. E dessa imundice se purificavam pela só ablução das vestes. Nem era
necessário fizessem aspersão da água, porque então o processo iria ao infinito. Pois, o que aspergia a
água tornava-se imundo e então, aspergindo-se a si mesmo, continuaria imundo; mas quem o
aspergisse também ficaria imundo; e semelhantemente, quem a este aspergisse, e assim ao infinito.
A razão figurada desse sacrifício é que a vaca vermelha significa a Cristo, por causa da natureza humana
enferma, de que se revestiu, designada pelo sexo feminino da vaca. A cor desta designa o sangue da
paixão. A vaca vermelha estava na força da idade, porque toda obra de Cristo é perfeita. Não tinha
nenhum defeito e não tinha ainda levado o jugo, porque Cristo é inocente, nem levou o jugo do pecado.
Devia ser levada a Moisés, porque lhe imputavam a transgressão da lei mosaica quanto à violação do
sábado. Devia ser entregue ao sacerdote Eleazar, porque Cristo, condenado à morte, foi entregue nas
mãos dos sacerdotes. Era imolada fora do arraial porque Cristo padeceu fora da porta. O sacerdote
tingia o dedo no sangue dela, porque o mistério da paixão de Cristo deve ser meditado e imitado com
sabedoria, significada pelos dedos. O sacerdote fazia aspersão voltado para o tabernáculo, para
significar a sinagoga, quer para a condenação dos judeus incrédulos, quer para a purificação dos crentes.
E isto sete vezes, por causa dos sete dons do Espírito Santo, ou dos sete dias, que simbolizam todos os
tempos. Também tudo o que aludia à encarnação de Cristo devia ser queimado no fogo, i. é,
espiritualmente entendido. Assim, a pele e a carne significam as obras externas de Cristo; o sangue, a
virtude sutil e interior, vivificante das obras externas; o excremento, a lassidão, a sede e tudo o mais
próprio à fraqueza. Acrescentavam-se ainda três coisas, a saber: o cedro, para significar a sublimidade
da esperança, ou da contemplação; o hissopo, símbolo da humildade ou da fé; a escarlata duas vezes
tinta, da dupla caridade. Pois, por essas virtudes devemos nos unir com a paixão de Cristo. A cinza da
combustão era recolhida por um homem limpo, porque os resultados da paixão aproveitaram aos
gentios, que não foram culpados da morte de Cristo. Era posta na água da expiação, porque pela paixão
de Cristo o batismo produz o efeito de purificar dos pecados. O sacerdote, que imolava e queimava a
vaca, e aquele que a queimava, e o que lhe recolhia as cinzas, ficavam imundos, bem como o que fazia
aspersão da água. Isso, quer porque os judeus ficaram imundos por terem morto a Cristo, que expiou os
nossos pecados; e até a tarde, i. é, até o fim do mundo, quando o que restar de Israel se converterá. Ou
porque os que tratam as coisas santas, procurando a purificação dos outros, eles próprios também
contraem certas imundices, como diz Gregório; e isto até a tarde, i. é, até o fim da vida presente.

RESPOSTA À SEXTA. — Como já se disse, a imundice proveniente da corrupção da mente ou do corpo
era expiada pelos sacrifícios pelo pecado. E ofereciam-se sacrifícios especiais pelos pecados de cada um.
Ora, certos eram negligentes em expiar tais pecados e imundices; ou deixavam de o fazer por
ignorância. Por isso, foi instituído que, uma vez por ano, no dia dez do sétimo mês, se fizesse um
sacrifício expiatório por todo o povo. E porque, no dizer do Apóstolo (Heb 7, 28), a lei constitui
sacerdotes a homens que têm enfermidade, era necessário que o sacerdote oferecesse primeiro por si
mesmo o bezerro, pelo pecado, em lembrança do que Aarão cometeu ao fundir o bezerro de ouro. E um
carneiro em holocausto, para significar que a escolha do sacerdote, significado pelo carneiro, chefe do
rebanho, devia ordenar-se à honra de Deus. — Em seguida o sacerdote oferecia, pelo povo, dois bodes.
Um era imolado para expiar o pecado do povo. Porque o bode é um animal fétido e, da sua pele, fazem-
se vestes que picam o corpo; o que significa o mau cheiro, a imundice e o aguilhão dos pecados. O
sangue do bode imolado era conduzido, junto com o do bezerro, ao Santo dos Santos, e com ele se
aspergia todo o santuário, para significar que o tabernáculo era purificado das imundices dos filhos de
Israel. O corpo do bode e o do bezerro, imolados pelo pecado, deviam ser queimados, para significar a
consumpção dos pecados. Não porém no altar, onde só se queimavam totalmente os holocaustos. Por
isso, era ordenado que fossem queimados fora do arraial, em detestação dos pecados; e isto se fazia
sempre que era imolada a vítima do sacrifício por algum pecado grave, ou pela multidão deles. — O
outro bode era mandado para o deserto, não, certo, para ser oferecido aos demônios, que aí os gentios
adoravam, porque nada era lícito lhes imolar; mas, para significar o efeito da imolação da vítima desse
sacrifício. Por isso, o sacerdote impunha-lhe a mão sobre a cabeça, confessando os pecados dos filhos
de Israel; e então o bode era mandado para o deserto, para ser comida das feras, como sofrendo a pena
pelos pecados do povo. E consideravam-no como carregando esses pecados, quer porque o ser ele
mandado para o deserto significasse a remissão de tais pecados; quer porque se lhe ligava à cabeça
algum bilhete, onde estes estavam escritos.
A razão figurada desses sacrifícios é significar a Cristo. O bezerro significa-lhe a virtude; o carneiro, que é
chefe dos fiéis; o bode, a sua semelhança da carne do pecado. E o próprio Cristo foi imolado pelo
pecado dos sacerdotes e do povo, porque, pela sua paixão, tanto os grandes como os pequenos são
limpos do pecado. O sangue do bezerro e do bode era introduzido no Santo pelo pontífice, porque o
sangue da paixão de Cristo nos abriu a porta do reino dos céus. Os corpos desses animais eram
queimados fora do arraial, porque Cristo padeceu fora da porta; como diz o Apóstolo (Heb 13, 12).
Quanto ao bode emissário, podia significar a divindade mesma de Cristo, que foi para a solidão, no
sofrimento da sua humanidade, não, certo, por mutação de lugar, mas por coibição da virtude. Ou
significava a má concupiscência, que devemos expulsar de nós, e os movimentos virtuosos, que
devemos imolar ao Senhor. — A imundice dos que queimavam essas vítimas no sacrifício tinha a mesma
razão já assinalada no sacrifício da vaca vermelha (ad 5).

RESPOSTA À SÉTIMA. — Pelo rito da lei, o leproso não era limpo da mácula da lepra, mas, era
encontrado já limpo. Isso significa o lugar da Escritura, que diz (Lv 14, 3 ss): mandará ao que se purifica,
vendo que a lepraestá curada. Logo, já estava purificado da lepra; mas era considerado como se
purificando ao ser restituído, pela decisão do sacerdote, ao convívio social e ao culto divino. Acontecia
porém às vezes que, por milagre divino, fosse purificado da lepra, segundo o rito da lei material, quando
o sacerdote se enganava no julgar. — Essa purificação do leproso fazia-se de dois modos. Pois, primeiro,
era julgado como estando limpo; depois, como tal, era restituído ao convívio social e ao culto divino, i. é,
depois de sete dias. — Na primeira purificação o leproso, que devia purificar-se, oferecia por si duas
avezinhas vivas, pau de cedro, escarlata e hissopo, de modo que com um fio escarlate fosse ligada a
avezinha junto com o hissopo e o pau de cedro. E de maneira que este servisse de cabo ao aspersório;
ao passo que o hissopo e a avezinha eram as partes do aspersório que eram molhadas no sangue da
outra avezinha imolada em águas vivas. E essas quatro coisas eram oferecidas contra os quatro defeitos
da lepra. Pois, contra a putrefação era oferecido o cedro, árvore incorruptível; contra a fetidez, o
hissopo, que é uma erva odorífera; contra a insensibilidade, a avezinha viva; contra a fealdade da cor, a
escarlata, que tem cor viva. Deixava-se a avezinha viva voar para o campo, porque o leproso era
restituído à liberdade antiga. — No oitavo dia, era o purificado admitido ao culto divino e restituído ao
convívio social. Porém, depois de ter rapado todo os pêlos do corpo, lavado os vestidos, porque a lepra
corroe aqueles e contamina estes e os torna fétidos. Depois oferecia um sacrifício pelo seu pecado,
porque a lepra era, quase sempre, apanhada, por causa dele. Com o sangue do sacrifício o sacerdote
molhava a extremidade da orelha do que devia purificar-se, e os polegares da mão e pé direitos; pois é
nesses lugares que primeiro se distingue e sente a lepra. Acrescentavam ainda a esse rito três líquidos: o
sangue contra a corrupção do mesmo; o azeite, para designar a cura da doença; a água viva, para limpar
a espurcícia.A razão figurada é, que as duas avezinhas significam a divindade e a humanidade de Cristo.
Uma delas, símbolo da humanidade, era imolada num vaso de barro sobre águas vivas, porque a paixão
de Cristo consagrou as águas do batismo, a outra, símbolo da impassibilidade divina, ficava viva, porque
a divindade não pode morrer. Por isso voava, por não poder a divindade ser atingida pelo sofrimento, A
avezinha viva era posta na água, para ser aspergida, simultaneamente com o pau de cedro, a escarlata,
o carmesim e o hissopo, i. é, com a fé, a esperança e a caridade, como dissemos, porque somos bati-
zados na fé em Deus e no homem. O homem lava, na água do batismo e das lágrimas, as suas vestes, i.
é, as suas obras, e todos os pêlos, i. é, os pensamentos. A extremidade da orelha direita daquele que se
purificava era molhada no sangue e no azeite, para precaver o ouvido contra as palavras corruptoras. Os
polegares da mão direita e do pé eram molhados, para as suas ações serem santas. O mais, que diz
respeito a esta purificação, ou a das outras imundices, nada tem de especial que não esteja
compreendido nos outros sacrifícios pelos pecados ou pelos delitos.

RESPOSTA À OITAVA E À NONA. — Assim como o povo judeu foi instituído para o culto de Deus, pela
circuncisão, assim o ministro, por alguma especial purificação ou consagração. Por isso foi-lhe ordenado
que se separasse dos outros povos, como destinado especialmente ao ministério do culto divino, o que
com esses se não dava. E tudo o que era feito com respeito à consagração ou instituição deles, visava
mostrar que tinham uma prerrogativa de pureza, virtude e dignidade. Por isso, três coisas se faziam na
instituição dos ministros. Primeiro, eram purificados; segundo, ordenados e consagrados; terceiro,
aplicados ao uso do ministério.
Comumente todos se purificavam pela ablução com água e por certos sacrifícios; em especial, porém, os
levitas raspavam todos os pêlos do corpo, como se lê na Escritura (Lv 8).
A consagração dos pontífices e dos sacerdotes fazia-se na ordem seguinte. Primeiro, depois de terem
feito a ablução, revestiam-se de certas vestes especiais próprias a designar-lhes a dignidade.
Especialmente porém o pontífice era ungido na cabeça com o óleo da unção, para significar que dele
promanava para outrem o poder de consagrar, assim como o óleo, da cabeça, escorre para os membros
inferiores, conforme se lê na Escritura (Sl 132, 2): Como o perfume derramado na cabeça, que desceu
sobre toda a barba de Aarão. Os levitas não tinham outra consagração senão o serem oferecidos ao
Senhor pelos filhos de Israel, por meio das mãos do pontífice, que orava por eles. Os sacerdotes
menores eram consagrados só nas mãos, que deviam aplicar-se aos sacrifícios; e com o sangue do
animal imolado era molhada a extremidade da orelha direita deles, e os polegares do pé e da mão
direita. Isso para que fossem obedientes a Deus, no oferecer os sacrifícios, o que era significado pelo
umedecimento da orelha direita; e para que fossem solícitos e prontos na execução deles, o que era
significado pelo umedecimento do pé e da mão direita. Aspergiam-lhes também as vestes com o sangue
do animal imolado, em memória do sangue do cordeiro por quem foram libertos do Egito. Ofereciam-se
também na consagração deles os seguintes sacrifícios. Um bezerro, pelo pecado, em memória da
remissão do pecado de Aarão, quando fundiu o bezerro de bronze. Um carneiro em holocausto, em
memória da oblação de Abraão, cuja obediência o pontífice devia imitar. O carneiro da consagração, que
era uma como hóstia pacífica, em memória da libertação do Egito pelo sangue do cordeiro. E um
canistrel de pães, em memória do maná dado ao povo.
Também concernia à aplicação do ministério o se lhes impor sobre as mãos a gordura do carneiro, a
torta de um pão, e a espádua direita, para mostrar que recebiam o poder de fazertais oferendas ao
Senhor. Os levitas enfim se aplicavam ao ministério por serem introduzidos no tabernáculo da aliança,
como que para ministrarem nos vasos do santuário.
A razão figurada disso tudo é a seguinte. Os que vão ser consagrados ao ministério espiritual de Cristo
devem, primeiro, purificar-se pela água do batismo e das lágrimas, em fé da paixão de Cristo; é um
sacrifício expiatório e purgativo. E devem raspar todos os pêlos do corpo, i. é. todos os pensamentos
maus. Também devem ornar-se de virtudes e se consagrar com o óleo do Espírito Santo e com a
aspersão do sangue de Cristo. E assim, devem estar preparados para desempenhar os ministérios
espirituais.

RESPOSTA À DÉCIMA. — Como já dissemos, a intenção da lei era despertar a reverência do culto divino.
Isto de dois modos: excluindo do culto o que podia ser desprezível; e aplicando-lhe tudo o que fosse
considerado como honorificente. E se isto se observava em relação ao tabernáculo, aos seus vasos e aos
animais que iam ser imolados, com maioria de razão devia ser observado em relação aos ministros. —
Por onde, para remover deles o que quer que fosse de desprezível, foi ordenado que não tivessem
deformidade ou defeito corpóreo, porque homens que o têm costumam ser tomados pelos outros em
má conta. Pelo que também foi instituído que não fossem escolhidos para o ministério de Deus, a esmo
e de qualquer família; mas os de uma certa prosápia, e conforme à sucessão da família, para assim se
conseguirem ministros mais ilustres e nobres.
E para que fossem tidos em reverência, acrescentavam -lhes vestes de ornato especial, e uma especial
consagração. E esta é em geral a causa desses ornatos. — Em especial porém importa saber-se que o
pontífice tinha oito ornamentos. — Primeiro, vestes de linho. Segundo, uma túnica de jacinto, em cujas
extremidades, aos pés e ao redor, punham-se umas campainhas e umas como romãs de jacinto, de
púrpura e de escarlata tinta duas vezes. — Terceiro, o efod, que cobria os ombros e a parte anterior até
a cintura, e que era de ouro, de jacinto, de púrpura, de escarlata tinta duas vezes, e de linho fino
retorcido. E nos ombros tinha duas pedras cornalinas, onde estavam gravados os nomes dos filhos de
Israel. — Quarto, o racional, feito da mesma matéria; que era quadrado, colocado no peito e ligado ao
efad. E nesse racional havia doze pedras preciosas separadas em quatro fileiras, nas quais também
estavam escritos os nomes dos filhos de Israel. Isso como para significar que o pontífice carregava com o
peso de todo o povo, por lhe ter os nomes nos ombros; e que, por trazê-las no peito, i. é, guardando-os
quase no coração, devia perenemente pensar na salvação dele. No racional também o Senhor mandou
escrever: Doutrina e Verdade, porque nele estavam escritas certas determinações relativas à verdade da
justiça e da doutrina. Os judeus porém fabulavam, que no racional havia uma pedra capaz de revestir-se
de cores diversas conforme aos diversos sucessos por que deviam passar os filhos de Israel, e lhe
chamavam — Doutrina e Verdade. — Quinto, o cíngulo, i. é, uma cinta feita das quatro cores já referidas
— Sexto, a tiara, i. é, uma mitra de bisso — Sétimo, a lâmina de ouro, pendente da cabeça, na qual
estava escrito o nome do Senhor. — Oitavo, calções de linho, para lhes cobrirem as partes, quando
subissem ao santuário ou ao altar. Destes oito ornatos menores os sacerdotes tinham quatro, a saber, a
túnica, os calções, o cíngulo e a tiara.
Desses ornamentos a razão literal era, segundo alguns, significar a disposição do orbe terrestre, como se
o pontífice se considerasse ministro do Criador do mundo. Donde o dizer a Escritura (Sb 18, 24): Na
vestidura de Aarão estava descrito o orbe da terra. Assim, os calções de linho figuravam a terra, donde
ele nasce. A circunvolução do cíngulo, o oceano, que circunda a terra. A túnica de jacinto, com a sua cor,
significava o ar; as suas campainhas, o trovão; as romãs, os relâmpagos. O efod significava, na sua
variedade, o céu sidéreo; as duas cornalinas, os dois hemisférios, ou o sol e a lua. As doze pedras
preciosas no peito, os doze signos do zodíaco; estavam postas no racional, porque, nos fenômenos
celestes estão as razões essenciais dos terrestres, conforme a Escritura (Jó 18, 33): Acaso entendes a
ordem do céu e darás disso a razão estando na terra? A mitra ou tiara significava o céu empíreo. A
lâmina de ouro, Deus, que tudo governa.
A razão figurada é manifesta. Pois, as deformidades ou defeitos corpóreos, de que os sacerdotes deviam
estar imunes, significam os diversos vícios e pecados que não deviam ter. Não deviam ser cegos, i. é,
ignorantes. Nem coxos, i. é, instáveis e sujeitos a inclinações diversas. Nem de nariz pequeno, grande ou
torcido; i. é, não deviam por falta de discreção, cair em exageros por excesso ou defeito; ou ainda, não
praticar atos maus; pois, o nariz designa o discernimento, capaz de distinguir os odores. Não deviam ter
quebrado o pé ou a mão, i. é, perder a virtude de agir ou proceder virtuosamente. Seria também
rejeitado o corcovado, anterior ou posteriormente; o que significa o amor supérfluo das coisas terrenas.
O remeloso, i. é, entenebrecido de engenho pelo afeto carnal, pois a remelosidade provém do fluxo dos
humores. O de belide no olho, i. é, o que no pensamento nutrisse a presunção de ser puro na
justificação. Também quem tivesse sarna pertinaz, i. é, a petulância da carne. Quem tivesse impigem,
pois esta sem dor se dissemina pelo corpo e ofende a beleza dos membros; e isso designa a avareza, E
também quem tivesse quebradura ou fosse obeso; i. é, trouxesse a carga da torpeza no coração,
embora não a realizasse por obras.
Os ornamentos designam as virtudes dos ministros de Deus. Pois, as quatro seguintes lhe são
necessárias a todos. A castidade, significada pelos calções; a pureza da vida, pela túnica de linho; o
moderado discernimento, pelo cíngulo; a retitude de intenção, pela tiara protetora da cabeça. — Mas,
além destas, os pontífices devem ter quatro outras. Primeiro, lembrarem-se de Deus, pela
contemplação, isto simbolizado na lâmina de ouro com o nome de Deus na fronte. Segundo, deviam
suportar as fraquezas do povo, o que era simbolizado pelo efod. Terceiro, trazer o povo no coração e no
íntimo, pela solicitude da caridade; e isso significa o racional. Quarto, viver um gênero de vida celeste,
pelas obras de perfeição, o que é significado pela túnica de jacinto. Essa túnica tinha, na extremidade,
campainhas de ouro, símbolo da doutrina das coisas divinas que deve ir de par com o gênero de vida
celeste do pontífice. Acrescentavam-se ainda umas romãs, símbolo da unidade da fé e da concórdia nos
bons costumes, porque a sua doutrina deve ser conexa, de modo a não romper a unidade da fé e da paz.

## Art. 6 — Se as observâncias cerimoniais tinham causa racional.
(IIª-IIªª, q. 86., a. 3, ad 1, 2, 3; Ad Rom., cap. XIV, lect. I, III; I Tim., cap. IV, lect. I; Ad Tit., cap. I, lect. IV).
O sexto discute-se assim. — Parece que as observâncias cerimoniais não tinham nenhuma causa
racional.

1. — Pois, como diz o Apóstolo (1 Tm 4, 4) toda criatura de Deus é boa e não é para desprezar nada do
que se participa com ação de graças. Logo, proibia-se inconvenientemente o uso de certos alimentos,
por imundos (Lv 11).

2. Demais. — Como os animais eram dados em alimento ao homem, assim também as ervas; donde o
dizer a Escritura (Gn 9, 3): eu vos entreguei toda carne, como as viçosas hortaliças. Ora, a lei não
distinguia ervas imundas, apesar de algumas delas serem venenosas e muito nocivas. Logo, também não
devia proibir certos animais, por imundos.

3. Demais. — Se a matéria de que alguma coisa provém é imunda, pela mesma razão há de sê-lo o dela
gerado. Ora, a carne é gerada do sangue. E como nem todas as carnes eram proibidas, como imundas,
pela mesma razão não devia sê-lo, como tal, o sangue, nem a gordura dele gerada.

4. Demais. — O Senhor diz (Mt 10, 28), que não são para temer os que matam o corpo, porque depois
dessa morte, nada mais podem fazer. Ora, tal não seria verdade se se convertesse em mal do homem o
que se lhe viesse a fazer ao cadáver. Logo, com maior razão, não importava o modo por que se viessem
a cozer as carnes do animal já morto. E portanto, parece irracional o que diz a Escritura (Ex 23, 19): Não
cozerás o cabrito no leite da sua mãe.

5. Demais. — Era de preceito oferecer ao Senhor, por mais perfeitas, as primícias dos homens e dos
animais. Logo, era inconveniente o seguinte preceito (Lv 19, 23): Quando entrares na terra e plantares
nela árvores frutíferas, cortar-lhes-ei os seus prepúcios, i. é, os primeiros germens, e serão imundos
para vós e não comereis deles.

6. Demais. — As vestes são exteriores ao corpo do homem. Logo, não se deviam proibir aos judeus
certas vestes especiais, p. ex., como as referidas nos lugares da Escritura (Lv 19, 19): Não usarás de
vestido que seja tecido de fios diferentes; (Dt 22, 5) a mulher não se vestirá de homem, nem o homem
se vestirá de mulher; e ainda (Dt 22, 11): Não te vestirás de coisa que seja tecida de lã e de linho.

7. Demais. — A memória dos mandamentos de Deus não respeita ao corpo, mas ao coração. Logo, era
inconveniente o ordenar a Escritura (Dt 6, 8 ss), que os preceitos de Deus ligavam como um sinal na sua
mão; e que se deviam escrever no limiar das portas; e que fizessem umas guarnições nos remates das
capas, pondo nelas fitas de cor de jacinto, para que se recordem dos mandamentos do Senhor.

8. Demais. — O Apóstolo diz (1 Cor 9, 9), que Deus não tem cuidado dos bois; e, por conseqüência, nem
dos outros animais irracionais. Logo, eram inconvenientes os preceitos (Dt 22, 6): Se, indo por um
caminho, achares o ninho duma ave, não apanharás a mãe com os filhinhos; e (Dt 25, 4): Não atarás a
boca ao boi que trilha na eira; e (Lv 19, 19): Não lançarás a tua besta a ter cópula com animais doutra
espécie.

9. Demais. — Não se fazia nenhuma separação entre plantas mundas e imundas. Logo, com maior razão,
não se devia fazer qualquer distinção relativamente à cultura delas. Portanto eram inconvenientes os
preceitos (Lv 19, 19): Não semearás o teu campo com diversa semente; e (Dt 22, 9 ss): Não semearás a
tua vinha de outra semente; e: Não lavrarás com boi e asno juntamente.
10. Demais. — Os seres inanimados, sobretudo, estão sujeitos ao poder do homem. Logo, era
inconveniente o preceito da lei, que privava o homem do uso da prata e do ouro, de que se fabricavam
os ídolos, e do mais que se encontrava no templo destes. E também era ridículo o outro preceito, que se
lê (Dt 7, 25): tendo satisfeito à tua necessidade, cavarás ao redor e cobrirás com a terra que tiraste.
11. Demais. — Sobretudo dos sacerdotes se exige a piedade. Ora, esta manda assistirmos aos funerais
dos amigos; e por isso Tobias foi louvado (Tb 1, 20 ss). Também algumas vezes, por piedade, pode
alguém receber uma meretriz como esposa, pela livrar assim do pecado e da infâmia. Logo, tais coisas se
proibiam inconvenientemente aos sacerdotes (Lv 21).
Mas, em contrário, diz a Escritura (Dt 18, 14): tu, porém, foste instruído de outra sorte pelo Senhor teu
Deus. Donde se pode coligir, que as observâncias de que se trata foram instituídas por Deus por uma
certa prerrogativa especial do povo judeu. Logo, não eram irracionais ou sem causa.

SOLUÇÃO. — O povo judeu, como já dissemos (a. 5), foi especialmente destinado ao culto divino; e dele,
em especial, os sacerdotes. E assim como as coisas aplicadas a esse culto deviam ter algo de particular,
exigido pela honorificência do mesmo; assim, o gênero de vida do povo judeu e, sobretudo, dos
sacerdotes, devia especialmente ter uma certa congruência, espiritual ou corporal com tal culto. Ora, o
culto da lei figura o mistério de Cristo. Por isso, todas as suas observâncias figuram o concernente a
Cristo, conforme a Escritura (1 Cor 10, 11): Todas estas coisas lhes aconteciam a eles em figura. Por isso,
duas razões se podem assinalar a essas observâncias: a congruência com o culto divino, e o figurarem o
que respeita à vida dos Cristãos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como já dissemos (a. 5 ad 4, 5), a lei estabelecia dupla
corrupção ou imundice. Uma, da culpa, que mancha a alma; a outra, a de qualquer corrupção que de
certo modo contamina o corpo. — Quanto, pois, à primeira imundice, não havia nenhum gênero de
comida por natureza imundo ou susceptível de contaminar o homem; donde o dizer a Escritura (Mt 15,
11): Não é o que entra pela boca o que faz imundo o homem; mas o que sai da boca, isso é o que faz
imundo o homem; o que é aplicado aos pecados. Contudo certas comidas podiam acidentalmente
manchar a alma, por serem tomadas contra a obediência, o voto, ou por nímia concupiscência; ou
enquanto constituíam fomento à luxúria, razão pela qual certos se abstinham do vinho e da carne.
Quanto à imundice corpórea, a proveniente de alguma corrupção, certas carnes dos animais a tinham.
Ou porque estes se nutrem de coisas imundas, como o porco. Ou vivem imundamente, como alguns,
que habitam debaixo da terra, p. ex., as toupeiras, os ratos e semelhantes, que contraem também por
isso mau cheiro. Ou porque a carne deles, por causa da demasiada umidade ou secura, geram humores
corruptos no corpo humano. Por isso, eram proibidas aos judeus as carnes dos animais que têm sola, i.
é, unha inteira, não fendida por causa da sua terreneidade. Semelhantemente, era-lhes proibida a carne
dos animais que têm muitas fendas nos pés, como a do leão e outros semelhantes porque são muito
coléricos e ardentes. Pela mesma razão, certas aves de rapina, demasiado secas; e certas aves aquáticas,
pelo excesso de umidade. Também certos peixes sem barbatanas e escamas, como as enguias e outros,
por causa do excesso de umidade. Era-lhes permitido comer os animais ruminantes, de unha fendida,
porque tem humores bem digeridos e de compleição média; e porque nem são demasiado úmidos,
como as unhas o significam; nem demasiado terrenos, por não terem a unha inteira, mas fendida. Dos
peixes eram-lhes permitido os mais secos, como o davam a entender as escamas e as barbatanas, que
tornam temperada a compleição úmida deles. Das aves, as melhor constituídas, como a galinha, a perdiz
e outras. — A outra razão era fazer detestar a idolatria. Pois, os gentios e principalmente os egípcios,
entre os quais os judeus viviam, imolavam aos ídolos esses animais proibidos ou os empregavam para
feitiçarias. Ao passo que não comiam aqueles que era permitido aos judeus comerem; mas os adoravam
como deuses. Ou por alguma outra causa se abstinham deles, como já dissemos (a. 3, ad 2). — A
terceira razão era para impedir a diligência demasiada em relação à comida. Por onde, concediam-lhes
os animais susceptíveis de serem conseguidos fácil e prontamente.
Contudo geralmente era-lhes proibido comerem o sangue e a gordura de qualquer animal. — O sangue,
quer para evitarem a crueldade e detestarem derramar sangue humano, como já dissemos (a. 3, ad 8).
Quer também para fazer evitar o rito da idolatria; porque era costume dos idólatras reunirem-se ao
redor do sangue recolhido, para comerem em honra dos ídolos, a quem o consideravam muitíssimo
agradável. Por isso o Senhor mandou, que o sangue fosse derramado e coberto com terra. E também
lhes era proibido comer animais sufocados ou estrangulados, porque o sangue deles não se separa da
carne; ou porque tais gêneros de morte fazem os animais sofrer muito, e o Senhor queria afastá-los da
crueldade, mesmo para com os brutos, para que, habituando-se a tratá-los, mesmo a estes, com
comiseração, mais se afastassem da crueldade para com os homens. — Também era-lhes proibida a
gordura, quer porque os idólatras a comiam em honra dos seus deuses;quer também porque era
queimada em honra de Deus; quer enfim porque o sangue e a gordura não fazem boa nutrição, causa
essa dada pelo Rabbi Moisés. A causa de ser proibido comer os nervos está na Escritura (Gn 32, 32): os
filhos de Israel não comem nervo, porque o anjo tocou o nervo da coxa de Jacó, e ficou entorpecido.
A razão figurada dessas observâncias é que todos esses animais eram proibidos por serem figuras de
certos pecados. Donde o dizer Agostinho: A quem indagar se o porco e o cordeiro são limpos por
natureza, por ser boa toda criatura de Deus, respondemos que, em certo sentido, o cordeiro é limpo e o
porco é imundo. Mas, perguntar isto seria o mesmo que perguntar, considerando a natureza da
expressão, e as letras e sílabas, de que constam, se as palavras — estulto e sábio — são puras. Pois, uma
é pura e a outra, imunda. Assim, o animal ruminante e de casco fendido era puro porsignificação.
Porque a fenda das unhas significa a distinção entre os dois Testamentos; ou a do Padre e do Filho; ou a
das duas naturezas de Cristo; ou a separação entre o bem e o mal. A ruminação significa a meditação
das Escrituras e a sã inteligência das mesmas. Ora, quem não é capaz de compreender alguma destas
coisas é imundo.
Semelhantemente, os peixes, que têm escamas e barbatanas eram puros, por significação. Pois, as
barbatanas significam a vida sublime ou a contemplação; e as escamas, a vida áspera. Sendo ambas elas
necessárias à pureza espiritual.
Das aves eram proibidos certos gêneros especiais. Na águia, de vôo alto, proíbe-se a soberba. No grifo,
nocivo aos cavalos e aos homens, a crueldade dos poderosos. O halieto, que se nutre de pequenas aves,
significa os molestos aos pobres. O milhano, muito dado a preparar insídias, os fraudulentos. O abutre,
que acompanha os exércitos, no fito de comer os cadáveres dos mortos — os que provocam mortes e
sedições entre os homens, para daí tirarem lucro. Os animais do gênero dos corvos significam os
difamados pelos prazeres; ou os desprovidos de bons afetos, pois o corvo, uma vez mandado fora da
arca, não voltou. O avestruz, apesar de ave, incapaz de voar e sempre apegado à terra, os que militando
por Deus vivem, contudo, implicados em negócios seculares. O bufo, de visão noturna aguda, mas que
não vê de dia, os astutos nas coisas temporais, mas botos nas espirituais. A gaivota, que voa no ar e
nada na água, os que veneram a circuncisão a par do batismo; ou, ainda, os que querem alçar o vôo da
contemplação, mas vivem nas águas dos prazeres. O açor, empregado para caçar, os que servem aos
poderosos para depredarem os pobres. O mocho, que busca alimento de noite e se esconde de dia, os
luxuriosos que buscam ocultar o que fazem, agindo de noite. O mergulo, capaz de ficar muito tempo
debaixo da água, os gulosos que se atacam nas águas dos prazeres. O íbis, ave da África, de bico
comprido, e que se nutre de serpentes e é talvez o mesmo que a cegonha, os invejosos que se nutrem,
como de serpentes, dos males dos outros. O cisne, de cor branca e de pescoço comprido, com o qual
tira o alimento do fundo da terra ou da água, pode significar os homens que, sob candor da justiça
externa buscam lucros terrenos. O onocrótalo, ave dos países orientais, de bico comprido, com umas
bolsinhas na garganta onde repõe, primeiro, o alimento que, depois de uma hora, manda ao ventre,
significa os avarentos que, com cuidados imoderados, acumulam o necessário à vida. O porfirião,
diferente das outras aves, tem um pé espalmado para nadar e outro fendido para andar, pois nada na
água como os adens e anda na terra como as perdizes; e só bebe, ao comer, molhando na água a
comida. Significa os que nada querem fazer por vontade de outrem, senão só o que for banhado na
água da vontade própria. A cegonha, vulgarmente chamada falcão, significa aqueles cujos pés são
ligeiros para derramar sangue. O carádrio, ave gárrula, os loquazes. A poupa, que nidifica no estrume e
nutre-se de excrementos fétidos, e simulando no canto um gemido, significa a tristeza do século
geradora de morte, nos homens imundos. O morcego, que voa achegado à terra, aqueles a quem,
ornados da ciência profana, só sabem as coisas terrenas.
Além disso, das aves e dos quadrúpedes só lhes eram permitidos os de pernas posteriores mais longas,
para poderem saltar. Eram porém proibidos os que vivem mais apegados à terra, por serem
considerados imundos os que abusam da doutrina dos quatro Evangelistas, afim de não serem por ela
elevados para o alto.
No sangue enfim, na gordura e no nervo entendiam-se proibidas a crueldade, a volúpia e a contumácia
no pecado.

RESPOSTA À SEGUNDA. — Já antes do dilúvio os homens nutriam-se de plantas e mais ervas da terra.
Mas parece que o uso da carne foi introduzido depois, conforme a Escritura (Gn 9, 3): eu vos dei toda
carne como viçosas hortaliças. E isto porque alimentar-se dos frutos da terra é mais próprio da
simplicidade da vida; ao passo que comer carne revela antes o prazer e o apego ao viver. Pois
naturalmente a terra germina em ervas, ou, com pequeno esforço, obtém-se em grande cópia esses,
produtos; ao contrário, só com grande diligência podem-se nutrir ou apanhar os animais. Por onde,
querendo o Senhor reduzir o seu povo a uma vida mais simples, proibiu-lhes muitos gêneros de animais,
e não dos produtos da terra. Ou também porque aqueles eram imolados aos ídolos e não, estes.
À TERCEIRA OBJEÇÃO É CLARA A RESPOSTA, pelo já dito.

RESPOSTA À QUARTA. — Embora o bode imolado não sinta como, lhe sejam as carnes cozidas, contudo,
ao espírito de quem o coze parece implicar uma certa crueldade, empregar, para lhes consumir o leite
materno, que lhe foi dado como nutrição. Ou pode-se dizer, que os gentios, na solenidade dos ídolos,
coziam totalmente as carnes do bode, para imolá-las ou comê-las. E por isso, a Escritura, depois de ter
tratado das solenidades que se deviam, pela lei, celebrar, acrescenta (Ex 23): Não cozerás o cabrito no
leite de sua mãe.
A razão simbólica dessa proibição é figurar que Cristo, comparado com o bode, por causa da semelhança
da carne do pecado, não devia ser cozido, i. é, morto, pelos judeus, no leite materno i. é, no tempo da
infância. Ou significa que o bode, i. é, o pecador, não deve ser cozido no leite materno, i. é, corrompido
pelas lisonjas.

RESPOSTA À QUINTA. — Os gentios ofereciam aos seus deuses as primícias dos frutos, que julgavam
afortunadas; ou então os queimavam para fazer certas magias. Por isso, foi preceituado aos judeus
considerassem imundos os frutos dos três primeiros anos. Pois, em três anos, quase todas as árvores da
terra deles, cultivadas de semente, pela enxertia ou pela plantação, produziam fruto. E raramente acon-
tecia que os caroços dos frutos da árvore, ou as sementes latentes fossem semeados, por produzirem
frutos mais retardados. Ora, a lei diz respeito ao que mais freqüentemente se faz. Por onde, os pomos
do quarto ano, como sendo as primícias dos frutos puros, eram oferecidos a Deus; os do quinto, porém
e seguintes, comidos.
A razão figurada desses preceitos é simbolizar que, depois dos três estados da lei — o primeiro, de
Abraão até Davi; o segundo, até a transmigração de Babilônia; o terceiro, até Cristo — Cristo, que, é o
fruto dela, devia ser oferecido a Deus. Ou que as primícias das nossas obras nos devem ser suspeitas,
por causa da sua imperfeição.

RESPOSTA À SEXTA. — Como diz a Escritura (Sr 19, 27), o vestido do corpo dá a conhecer qual o homem
é. Por onde, o Senhor quis que o seu povo se distinguisse dos outros, não só pelo sinal carnal da
circuncisão, mas também: por uma diferença no vestir. E por isso, foi-lhe proibido vestir-se de roupa
tecida de lã e de linho; e que as mulheres usassem trajes masculinos e inversamente, por duas razões.
— A primeira fazer evitar a idolatria. Pois, os gentios, no culto dos seus deuses, usavam de várias vestes
de diversas contexturas. E também, no culto de Marte, as mulheres usavam das armas dos homens; no
de Vênus, ao inverso, os homens usavam trajes femininos. A outra razão era fazer evitar a luxúria. Pois,
pela exclusão de várias misturas nos tecidos das vestes, excluía-se toda união em coitos desordenados.
Porque é um incentivo à concupiscência e dá ocasião à libidinagem o vestir a mulher trajes masculinos.
A razão figurada de proibir nas vestes, tecidas de lã e de linho, é evitar a união da inocência e da
simplicidade, representadas pela lã, como a sutileza e a malícia, figuradas pelo linho. Também proibia a
mulher usurpar para si a doutrina ou os ofícios dos homens; ou ao homem o pendor para a efeminação.

RESPOSTA À SÉTIMA. — Diz Jerônimo: O Senhor mandou que se fizesse umas guarnições de jacinto nas
quatro pontas das capas, para distinguir o povo de Israel dos outros povos. Pois, assim, mostravam ser
judeus e, à vista desse sinal, despertavam a memória da sua lei. E o que diz a Escritura — E as atarás
com um sinal na tua mão, e estarão sempre diante dos teus olhos — os Fariseus interpretavam mal,
escrevendo em pergaminho o decálogo de Moisés, e prendendo-o na fronte, como coroa, para que se
movesse diante dos olhos. Entretanto a intenção do Senhor, mandando assim fazer, era que fossem
ligadas na mão, i. é, nas obras, e estivessem diante dos olhos, i. é, na meditação. As fitas cor de jacinto,
entremeadas nas capas significam a intenção celeste, inspiradora de todas as nossas obras. E também
pode-se dizer que, como o povo judeu era carnal e de cerviz dura, era necessário excitá-los à
observância da lei por esses sinais sensíveis.

RESPOSTA À OITAVA. — Há no homem duplo afeto: o racional e o passional. — Ao primeiro não
importa como se tratem os brutos, porque Deus lhe sujeitou todas as coisas ao poder, conforme a
Escritura (Sl 8, 8): Todas as coisas sujeitastes debaixo de seus pés. E neste sentido o Apóstolo diz que
Deus não cuida dos bois, por não exigir lhe dê o homem contas de como trata os bois ou os outros
animais. — Mas, pelo afeto da paixão o homem é movido em relação aos brutos. Pois, como a paixão da
misericórdia nasce dos sofrimentos alheios, e sofrer também podem os brutos, no homem pode nascer
o afeto da misericórdia mesmo para com os sofrimentos deles. Ora, quem com os animais exerce o
afeto da misericórdia está mais próximo a tê-lo para com os homens. Donde o dizer a Escritura (Pr 11,
10): O justo atende pela vida dos seus animais; mas as entranhas dos ímpios são cruéis. E por isso o
Senhor, para provocar a misericórdia no povo judaico, inclinado à crueldade, quis exercê-lo na miseri-
córdia, mesmo para com os brutos, proibindo-lhe tratá-los com qualquer crueldade. Por onde, era
proibido aos judeus cozer o bode no leite da mãe, prender a boca do boi que trilhava, matar a mãe com
os filhos.Embora também se possa dizer, que isso lhes era proibido para levá-los a detestar a idolatria.
Pois, os egípcios reputavam por nefário os bois comerem dos grãos que trilhavam. E alguns feiticeiros
também empregavam a ovelha, enquanto amamentava os filhos, e estes, apanhados simultaneamente
com ela, para conseguir a fecundidade e a boa fortuna em a nutrição dos filhos. E também porque nos
augúrios tinha-se como boa fortuna encontrar a mãe criando os filhos.
Do cruzamento entre animais de espécies diversas pode-se assinalar tríplice razão literal. — Uma, fazer
detestar a idolatria dos egípcios, que provocavam esses cruzamentos diversos, para cultuar aos planetas
que, conforme as suas diversas conjunções, produzem efeitos vários e sobre diversas espécies de coisas.
— Outra razão era excluir o coito contra a natureza. — A terceira, tolher universalmente, toda ocasião
de concupiscência. Pois, animais de espécies diversas não se cruzam facilmente, se não forem
provocados pelo homem; e a vista do coito provoca no homem movimentos de concupiscência. Por isso,
ainda mesmo nas tradições dos judeus, preceitua-se, como refere Rabbi Moisés, que os homens
desviem os olhos de animais em cópula.
A razão figurada é que o boi que trilha; i. é, o pregador, que distribui as sementes da doutrina, não deve
ser privado da subsistência necessária à vida, como diz o Apóstolo (1 Cor 9, 4 ss). — Também não
devemos tomar a mãe juntamente com os filhos; porque em certos casos devemos seguir o sentido
espiritual, como filho; e abandonar como nas cerimônias da lei a observância literal, como mãe. —
Também era proibido fazer os jumentos, i. é, os homens do povo cristão, ter cópula, i. é, ter sociedade,
com animais de outra espécie, i. é, com os gentios ou judeus.

RESPOSTA À NONA. — Todos os cruzamentos a que se alude, eram proibidos na agricultura,
literalmente, para fazer detestar a idolatria. Porque os egípcios, em veneração das estrelas, faziam
diversas misturas de sementes, animais e roupas, representativas das diversas conjunções delas. — Ou,
todas essas várias mesclas eram proibidas para fazer detestar o coito contra a natureza.
Mas também têm uma razão figurada. Pois, o preceito — Não semearás a tua vinha doutra semente —
deve ser entendido, espiritualmente, da Igreja, que, sendo a vinha espiritual, não deve ser semeada com
doutrina estranha. — E semelhantemente, o campo, i. é, a Igreja, não o semearás com diversa semente,
i. e, com a doutrina católica e a herética. — Não lavrarás com boi e asno juntamente, porque o fátuo, na
predicação, não se deve unir com o sábio, porque um é empecilho ao outro.

RESPOSTA À DÉCIMA. — Com razão a Escritura (Dt 7) proibia a prata e o ouro, não por não estarem
sujeitos ao poder dos homens, mas porque tanto os ídolos, como tudo aquilo de que eram fundidos,
estavam sujeitos àmaldição, como soberanamente abomináveis a Deus. E isso está claro no seguinte
passo do referido capítulo (Dt 7, 26): Nem em tua casa meterás coisa alguma que seja de ídolo, por não
vires a ser anátema, como ele o é também. Ou ainda para que, recebendo cobiçosamente o ouro e a
prata, não viessem com facilidade a cair na idolatria, à qual eram os judeus inclinados. — O segundo
preceito, de cobrir as dejeções com terra, era justo e honesto, quer por limpeza corporal;quer para
conservar a salubridade do ar; quer pela reverência devida ao tabernáculo da aliança, colocá-lo no
arraial, onde se dizia habitar o Senhor. E isto está claramente dito no lugar em que, depois de se
estabelecer esse preceito, dele se dá a razão: O Senhor teu Deus anda no meio do campo para te livrar
de todo o perigo etc.; e para que o teu campo seja santo, i. é, limpo, e não apareça nele coisa de
fealdade.
A razão figurada desse preceito, segundo Gregório, é significar que os pecados oriundos do instinto da
nossa mente, como excrementos fétidos, devem ser cobertos pela penitência, para sermos aceitos a
Deus, conforme aquilo da Escritura (Sl 31, 1): Bem-aventurados aqueles cujas iniqüidades são
perdoados, e cujos pecados são cobertos. Ou, conforme a Glosa: Para que, conhecida a miséria da
condição humana, a surdisse da mente enaltecida e soberba fosse coberta e purgada pela humildade, na
fossa da profunda meditação. RESPOSTA À UNDÉCIMA. — Os feiticeiros e os sacerdotes dos ídolos
empregavam, nos seus ritos, os ossos ou as carnes dos mortos. E por isso, para extirpar o culto da
idolatria, o Senhor mandou os sacerdotes menores, que ministravam no santuário em tempos
determinados, não se contaminarem nas mortes, senão só dos parentes muito próximos, como o pai e a
mãe, e outras pessoas assim chegadas. Porém, o pontífice devia estar sempre preparado para o
ministério do santuário; e por isso lhe era totalmente proibido achegar-se aos mortos, embora lhe
tivessem sido próximos. — Também lhes era proibido tomar mulher meretriz ou repudiada; mas que a
tomassem virgem. Quer pela reverência para com eles, cuja dignidade pareceria, de certo modo,
diminuída com uma tal união; quer também por causa dos filhos, por quem seria uma ignomínia a
torpeza da mãe. O que era sobretudo para evitar, quando a dignidade do sacerdócio era conferida
conforme àsucessão na família. — Também lhes era preceituado não raspassem a cabeça nem a barba,
nem fizessem incisão no corpo; para remover o rito da idolatria. Pois, os sacerdotes aos gentios
raspavam a cabeça e a barba; por isso, diz a Escritura (Br 6, 30): Estão assentados os sacerdotes tendo as
túnicas rasgadas e as cabeças e a barba rapada. E também, no culto dos ídolos, eles se retalhavam com
canivetes e lancetas, como se diz em outro lugar (1 Rs 18, 28). Por onde, mandou-se o contrário aos
sacerdotes da lei antiga.
A razão espiritual desses preceitos é deverem os sacerdotes ser absolutamente imunes de obras mortas,
que são as do pecado. E também não devem raspar a cabeça, i. é, perder a sabedoria; nem a barba, i. é,
perder a perfeição da sabedoria; nem ainda cindir as vestes ou fazer incisão no corpo, isto é, não
incorrer no vício do cisma.