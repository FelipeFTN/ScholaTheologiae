# Questão 25: Do bem e do mal nas paixões da alma.
Em seguida devemos tratar do bem e do mal nas paixões da alma. E sobre esta questão quatro artigos
se discutem:

## Art. 1 — Se as paixões da alma são moralmente boas ou más.
(II Sent., dist. XXXVI, a . 2; De Malo, q. 10, a . 1, ad 1; q. 12, a . 2, ad 1; a . 3).
O primeiro discute-se assim. ― Parece que nenhuma das paixões da alma é moralmente boa ou má.

1. ― Pois, o bem e o mal moral são próprios do homem, conforme diz Ambrósio: os costumes se
referem propriamente ao homem. Ora, as paixões não lhe são próprias, mas lhe são comuns a ele e aos
animais. Logo, nenhuma paixão humana é moralmente boa ou má.

2. Demais. ― O bem ou o mal do homem é o que é conforme à razão ou a ela contrário, como diz
Dionísio. Ora, as paixões da alma residem, não na razão, mas no apetite sensitivo, como já vimos. Logo,
não dizem respeito ao bem ou mal do homem, i. é, à bondade moral.

3. Demais. ― O Filósofo diz que pelas paixões, não somos louvados nem vituperados. Ora, o somos
relativamente ao bem e ao mal moral. Logo, as paixões não são boas ou más moralmente.
Mas, em contrário, diz Agostinho, referindo-se às paixões da alma: São más, se o amor é mau, boas, se
bom.

SOLUÇÃO. ― As paixões da alma podem considerar-se em dois pontos de vista: em si e enquanto caem
sob o império da razão e da vontade. Em si consideradas e como uns movimentos do apetite irracional,
não são susceptíveis de bem nem de mal moral, que dependem da razão, como já dissemos. São porém
susceptíveis de bem ou de mal moral, enquanto caem sob o império da razão e da vontade. Pois, o
apetite sensitivo depende mais estreitamente da razão e da vontade que os membros exteriores, cujos
movimentos entretanto e cujos atos são bons ou maus moralmente na medida em que forem
voluntários. Com maior razão, as paixões quando forem voluntárias, podem considerar-se boas ou más
moralmente. Ora, consideram-se voluntárias ou por serem governadas ou por não serem sofreadas pela
vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Em si mesmas consideradas, as paixões são comuns aos
homens e aos animais; mas, enquanto governadas pela razão, são próprias do homem.

RESPOSTA À SEGUNDA. ― Também as virtudes inferiores apetitivas chamam-se racionais na medida em
queparticipam, de algum modo, da razão, como diz Aristóteles.

RESPOSTA À TERCEIRA. ― Quando o Filósofo diz que não somos louvados nem vituperados por causa
das paixões absolutamente consideradas não quer significar não sejam elas dignas de louvor ou
vitupério, enquanto governadas pela razão. E por isso acrescenta: Pois não louvamos nem vituperamos
quem teme ou se encoleriza, mas sim, quem é possuído dessas paixões, de certo modo, i. é, conforme
ou contrariamente à razão.

## Art. 2 — Se todas as paixões da alma são moralmente más.
(Infra, q. 59, a . 2; De Malo, q. 12 a . 1).
O segundo discute-se assim. ― Parece que todas as paixões da alma são moralmente más.

1. ― Pois, diz Agostinho: certos denominam as paixões doenças ou perturbações da alma. Ora, toda
doença ou perturbação da alma é um mal moral. Logo, todas as paixões são moralmente más.

2. Demais. ― Damasceno diz: a operação é um movimento conforme à natureza, e a paixão, contrário.
Ora, o que encontra a natureza, nos movimentos da alma, se equipara ao pecado e ao mal moral; e por
isso o mesmo autor diz, noutro passo, que o diabo caiu de um estado natural para outro, contrário à
natureza. Logo, as paixões são moralmente más.

3. Demais. ― Tudo o que induz ao pecado tem natureza de mal. Ora, tais são as paixões por isso,
denominadas, na Escritura (Rm 7, 5), paixões dos pecadores. Logo, são moralmente más.
Mas, em contrário, diz Agostinho: do amor reto são retos todos os afetos. Pois, os que o nutrem
desejam perseverar, condoem-se dos pecados, alegram-se com as boas obras.

SOLUÇÃO. ― Sobre esta questão tinham opiniões diversas os estóicos e os peripatéticos, aqueles,
considerando más todas as paixões, estes, tendo as moderadas por boas. Esta diferença de doutrinas
porém, embora pareça grande, verbalmente é nula ou insignificante, realmente, para quem lhes
considerar as intenções. Ora, os estóicos, não discernindo entre o sentido e a inteligência, e portanto
entre o apetite intelectivo e o sensitivo, não discerniam também entre as paixões da alma, cuja sede é o
apetite sensitivo, e os simples movimentos da vontade, que residem no intelectivo. Por onde,
denominavam vontade qualquer movimento racional da parte apetitiva e paixão, qualquer movimento
que extravasa dos limites da razão. Por isso, Túlio, seguindo-lhes a opinião, chama doenças a todas as
paixões, donde se conclui que os doentes não tem saúde e os que não tem saúde são insipientes,
chamando-se assim insanos aos insipientes. Os peripatéticos, por seu lado, denominavam paixões todos
os movimentos do apetite sensitivo, considerando boas as moderadas pela razão e más as carecentes
dessa moderação. Por onde se vê que Túlio, no mesmo livro rejeita como inconveniente a opinião dos
peripatéticos, admitindo a moderação nas paixões e diz: devemos evitar todo mal, ainda moderado;
pois, assim como não está são quem está moderadamente doente, assim não é sã a moderação, de que
se trata, das doenças ou paixões da alma. Ora, as paixões não se consideram doenças ou perturbações
da alma senão quando carecem da moderação da razão.
Donde se deduz a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. ― Todas as paixões da alma aumentam ou diminuem o movimento natural do
coração, acelerando ou retardando-lhe a sístole ou a diástole; e isto manifesta a essência de paixão.
Logo, não é necessário que toda paixão sempre se desvie da ordem natural da razão.

RESPOSTA À TERCEIRA. ― As paixões da alma, quando contrárias à ordem da razão, inclinam para o
pecado; ordenadas porém pela razão, auxiliam a virtude.

## Art. 3 — Se qualquer paixão sempre diminui a bondade do ato moral.
(De Verit., q. 26, a . 7; De Malo, q. 3, a . 11; q. 12, a . 1).
O terceiro discute-se assim. ― Parece que toda paixão sempre diminui a bondade do ato moral.

1. ― Pois, tudo o que empece o juízo da razão, do qual depende a bondade do ato moral, há
necessariamente de diminuir esta bondade. Ora, toda paixão impede tal juízo, conforme diz
Salústio: Todos os homens que deliberam sobre coisas duvidosas convém sejam isentos do ódio, da ira,
da amizade e da misericórdia. Logo, toda paixão diminui a bondade do ato moral.

2. Demais. ― O ato humano, quanto mais semelhante a Deus, tanto melhor; por isso, diz o Apóstolo (Ef
5, 1):Sede pois imitadores de Deus, como filhos muito amados. Ora, Deus e os santos anjos punem sem
ira e auxiliam sem compartir da miséria, como diz Agostinho. Logo, é melhor praticar tais obras sem
paixão da alma, que com ela.

3. Demais. ― Do mesmo modo que o mal moral, o bem supõe dependência da razão. Ora, aquele é
diminuído pela paixão, pois, peca-se menos por paixão do que por indústria. Logo, menor é o bem feito
com paixão que o praticado sem ela.
Mas, em contrário, diz Agostinho, que a paixão da misericórdia serve à razão quando se comporta de
modo que a justiça seja conservada, quer socorrendo o indigente, quer perdoando ao penitente. Ora,
nada que sirva à razão diminui o bem moral. Logo, esse é o caso da paixão.

SOLUÇÃO. ― Os estóicos, tendo por más todas as paixões da alma, admitiam conseqüentemente, que
diminuem a bondade do ato moral, pois todo bem que vá de mescla com algum mal ou se destrói
totalmente ou se torna menos bom. E isto é verdade se tomarmos por paixões da alma só os
movimentos desordenados do apetite sensitivo, como perturbações ou doenças que são. Se porém
denominarmos paixões todos os movimentos do apetite sensitivo, então a perfeição do bem humano
requer sejam elas moderadas pela razão. Ora, sendo a razão quase a raiz do bem humano, este será
tanto mais perfeito quanto maior for o número de coisas convenientes ao homem a que ele se aplicar.
Por onde, não se duvide que também é da perfeição do bem moral que os atos dos membros exteriores
sejam dirigidos pela regra da razão. Logo, podendo o apetite sensitivo obedecer à razão, como já
dissemos, é da perfeição do ato moral ou humano que também as paixões da alma sejam reguladas pela
razão.
Assim pois como é melhor queira o homem o bem e o pratique por um ato exterior, assim também é da
perfeição do bem moral que a ele seja o homem levado, não pela vontade, mas também pelo apetite
sensitivo. E neste sentido diz a Escritura (Sl 83, 3): O meu coração e a minha carne se regozijaram no
Deus vivo, tomando-se coração pelo apetite intelectivo e carne, pelo sensitivo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― As paixões humanas podem manter dupla relação com o
juízo da razão. Uma, antecedente e nesse caso como obnubilam o juízo da razão, do qual depende a
bondade moral do ato, diminuem-lhe a bondade; pois é mais louvável praticar-se uma obra da caridade
por um juízo da razão, do que só pela paixão da misericórdia. ― Outra conseqüente, e isto de duplo
modo. Primeiro, a modo de redundância, pois quando a parte superior da alma se move intensamente
para algum objeto, também a parte inferior segue-lhe o movimento, e assim a paixão existente
conseqüentemente no apetite sensitivo é sinal da intensidade da vontade, índice portanto de maior
bondade moral. Segundo, a modo de eleição, como quando o homem, por juízo da razão, elege o ser
afetado por alguma paixão, para agir mais prontamente, com a cooperação do apetite sensitivo. E assim
a paixão da alma aumenta a bondade do ato.

RESPOSTA À SEGUNDA. ― Em Deus e nos anjos não há apetite sensitivo nem membros corpóreos; e
portanto, o bem neles não implica ordenação das paixões ou dos atos corpóreos, como em nós.

RESPOSTA À TERCEIRA. ― A paixão tendente ao mal que precede o juízo da razão diminui o pecado;
mas se lhe for conseqüente, por algum dos modos sobreditos, aumenta-o ou é sinal de seu aumento.

## Art. 4 — Se alguma paixão da alma é na sua espécie moralmente boa ou má.
(IIª. IIªº, q. 158, a . 1; IV Sent.,dist. XV, q. 2, a . 1, qª 1, ad 4; dist. L, q. 2, a . 4, qª 3, ad3; De Malo, q. 10, a
. 1).
O quarto discute-se assim. ― Parece que nenhuma paixão da alma é a na sua espécie moralmente boa
ou má.

1. ― Pois, o bem e o mal moral dependem da razão. Ora, as paixões, pertencendo ao apetite sensitivo,
tem relações acidentais com a razão. Ora, como nada do que é acidental pertence a qualquer espécie de
ser, resulta que nenhuma paixão é especificamente boa ou má.

2. Demais. ― Os atos e as paixões se especificam pelos seus objetos. Se pois uma paixão fosse
especificamente boa ou má, necessariamente seriam, na sua espécie, boas às paixões que tem um bom
objeto, como o amor, o desejo e a alegria; e más, especificamente, as que, como o ódio, o temor e a
tristeza têm um mau objeto. Ora, isto é falso, evidentemente. Logo, nenhuma paixão da alma é
especificamente boa ou má.

3. Demais. ― Não há espécie de paixão que não se encontre nos animais. Ora, de bem moral só o
homem é susceptível. Logo, nenhuma paixão da alma é especificamente boa ou má.
Mas, em contrário, diz Agostinho: a misericórdia está entre as virtudes. E o Filósofo, por sua vez, a
vergonha é uma paixão louvável. Logo, há paixões especificamente boas ou más.

SOLUÇÃO. ― O que já dissemos em relação aos atos também devemos dizer das paixões, a saber, que
de dois modos podemos encarar a espécie do ato ou da paixão. Ou quanto ao gênero da natureza, e
então o bem ou o mal moral não lhe pertencem à espécie; ou quanto ao gênero da moralidade, na
medida em que participam do voluntário e do juízo da razão. E deste último modo o bem e o mal moral
podem pertencer à espécie de paixão, entendendo-se por este objeto algo de conveniente à razão ou
dela dissonante, como se dá com a vergonha, temor da torpeza e, com a inveja, tristeza causada pelo
bem de outrem. Pertencem então à espécie do ato exterior.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Essa objeção colheria, relativamente às paixões,
enquanto pertencentes à espécie da natureza, isto é, considerando-se o apetite sensitivo em si mesmo.
Enquanto porém ele obedece à razão, já o bem e o mal da razão não reside acidental, mas
essencialmente, nas paixões desse apetite.

RESPOSTA À SEGUNDA. ― As paixões que tendem para o bem serão boas se esse bem for verdadeiro; e
o mesmo se dá com as que se afastam de verdadeiro mal. Ao contrário porém as paixões que se afastam
do bem ou tendem para o mal são más.

RESPOSTA À TERCEIRA. ― O apetite dos brutos não obedece à razão. E contudo, na medida em que é
dirigido por uma certa estimativa natural, sujeita a uma razão superior, que é a divina, há neles uma
quase semelhança do bem moral, quanto às paixões da alma.