# Questão 92: Dos efeitos da lei.
Em seguida devemos tratar dos efeitos da lei. E nesta questão dois artigos se discutem:

## Art. 1 — Se o efeito da lei é tornar os homens bons.
(II Cont. Gent., cap. CXVI: X Ethic., Irect., Iect. XIV).
O primeiro discute-se assim. — Parece que o efeito da lei não é tornar os homens bons.

1. — Pois, os homens são bons pela virtude, que torna bom quem a tem, como diz Aristóteles. Ora, a
virtude do homem vem-lhe de Deus, que a produz em nós, sem nós, como se disse a propósito da
definição da virtude (q. 55, a. 4). Logo, não compete à lei tornar os homens bons.

2. Demais. — A lei não é útil ao homem se ele não lhe obedecer. Ora, já é por bondade que o homem
obedece à lei. Logo, antes da lei, é-lhe necessária a bondade. Logo, não é ela que torna os homens bons.

3. Demais. — A lei se ordena para o bem comum, como já se disse (q. 90, a. 2). Ora, certos, que pro-
cedem retamente no atinente ao bem comum, não o fazem em relação ao próprio. Logo, não pertence à
lei tornar os homens bons.

4. Demais. — Certas leis são tirânicas, como diz o Filósofo. Ora, o tirano não busca o bem dos súbditos,
mas a utilidade própria. Logo, não pertence à lei tornar os homens bons.
Mas, em contrário, diz o Filósofo: A vontade de todo legislador é tornar os cidadãos bons.

SOLUÇÃO. — Como já dissemos (q. 90, a. 1 ad 2; a. 3, a. 4), a lei não é senão o ditame da razão do chefe,
que governa os súbditos. Ora, a virtude de todo súbdito está em submeter-se bem àquele por quem é
governado; assim como a virtude do irascível e do concupiscível consiste em serem bem obedientes à
razão. E assim, a virtude de qualquer súbdito está em sujeitar-se bem ao que governa, como diz o
Filósofo. Pois, toda lei é estabelecida para ser obedecida pelos súbditos. Por onde é manifesto, que é
próprio da lei levar os súbditos a serem virtuosos. Ora, como é a virtude que torna bom quem a tem,
segue-se que é efeito próprio da lei tornar bons, absoluta ou relativamente, aqueles para os quais foi
dada. Assim, se a intenção do legislador visar o verdadeiro bem, que é o bem comum; regulado pela
justiça divina, resulta que, pela lei, os homens se tornarão absolutamente bons. Se for, porém, a
intenção do legislador o bem não absoluto, mas o útil, o deleitável ou o que repugna à justiça divina,
então a lei tornará os homens bons, não absoluta, mas relativamente, em ordem a um determinado
regime. Por onde, existe bem, ainda nos que são, em si mesmos, maus; assim, chama-se bom ladrão o
que age bem em vista dos seus fins.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dupla é a virtude, como do sobredito se colhe (q. 63, a.
2): a adquirida e a infusa. Ora, para uma e outra contribui o agir costumeiro, mas diversamente; pois,
causa a virtude adquirida, dispõe para a infusa, e conserva e promove a já adquirida. E como a lei é dada
para dirigir os atos humanos, na medida em que eles levam para a virtude, nessa mesma a lei torna bons
os homens. Donde o dizer o Filósofo: Os legisladores tornam os cidadãos bons, imprimindo-lhes bons
hábitos.

RESPOSTA À SEGUNDA. — Nem sempre obedecemos à lei pela bondade de uma virtude perfeita; mas
umas vezes, pelo temor da pena, outras, pelo só ditame da razão, que é um princípio de virtude, como
já estabelecemos (q. 63, a. 1).

RESPOSTA À TERCEIRA. — A bondade da parte é considerada relativamente à do todo; por isso, diz
Agostinho, é má toda parte que não se coaduna com o todo. Sendo pois cada homem parte da cidade, é
impossível seja bom sem ser bem proporcionado ao bem comum; nem o todo pode ter boa consistência
senão pelas partes, que lhe sejam proporcionadas. Por onde, é impossível manter-se o bem comum da
cidade sem os cidadãos serem virtuosos, ao menos aqueles a quem cabe governar. Pois basta, para o
bem da comunidade, que os cidadãos sejam virtuosos na medida em que obedecem às ordens do chefe.
E por isso o Filósofo diz: A virtude do chefe e a do bom cidadão é a mesma; mas não é a mesma que a do
bom cidadão a virtude de um cidadão qualquer.

RESPOSTA À QUARTA. — A lei tirânica, não estando de acordo com a razão, não é, absolutamente
falando, lei; antes, é uma perversão dela. E contudo, na medida em que participa da essência da lei,
tende a tornar bons os cidadãos. Ora, da essência da lei não participa, senão na medida em que é um
ditame de quem governa os seus súbditos e tende a que eles sejam obedientes à lei. O que é torná-los
bons, não absolutamente, mas em relação ao regime.

## Art. 2 — Se os atos da lei estão convenientemente assinalados na expressão: são atos da lei ordenar, proibir, permitir e punir.
O segundo discute-se assim. — Parece que os atos da lei não estão convenientemente assinalados na
expressão: são atos da lei ordenar, proibir, permitir e punir.

1. — Pois, toda lei é um preceito geral, como diz o jurisconsulto. Ora, ordenar é a mesma coisa que
preceituar. Logo, os três outros membros da enumeração tornam-se supérfluos.

2. Demais. — O efeito da lei é levar os súbditos para o bem, como já se disse (a. 1). Ora, o conselho visa
um bem melhor que o do preceito. Logo, à lei pertence, antes aconselhar que mandar.

3. Demais. — Assim como o homem é incitado ao bem pelas penas, também o é pelos prêmios. Logo, se
punir é considerado efeito da lei, também o premiar deve sê-lo.

4. Demais. — A intenção do legislador é tornar bons os homens, como já se disse (a. 1). Ora, quem só
por medo das penas obedece à lei não é bom. Pois embora pelo temor servil, que é o temor das penas,
alguém possa fazer o bem, não o faz contudo bem, como diz Agostinho. Logo, parece não ser próprio da
lei punir.
Mas, em contrário, diz Isidoro: Toda lei ou permite alguma coisa, p. ex., que o homem forte busque o
prêmio; ou proíbe, p. ex., que a ninguém é lícito desposar uma virgem consagrada; ou pune, p. ex., com
pena capital quem cometeu uma morte.

SOLUÇÃO. — Como um enunciado é um ditame da razão expresso pela enunciação, assim a lei o é,
expresso a modo de preceito. Ora, é próprio à razão passar de uma proposição para outra. Por onde,
assim como nas ciências demonstrativas a razão leva a assentirmos na conclusão, em virtude de certos
princípios, assim também leva a assentirmos no preceito de lei, por alguns princípios.
Ora, as ordens da lei regulam atos humanos, que ela dirige, como já dissemos (q. 90, a. 1, a. 2; q. 91, a.
4), e que são de diferentes espécies. Pois, segundo já ficou dito (q. 18, a. 8), certos atos são
genericamente bons, e são os das virtudes. E em relação a estes se diz que é ato da lei preceituar ou
ordenar, porque a lei preceitua todos os atos das virtudes, como diz Aristóteles. — Outros atos são
genericamente maus, como os atos viciosos. E estes a lei os proíbe. — Outros ainda são genericamente
indiferentes; e estes ela os permite. Também podem considerar-se indiferentes todos os atos que são
pouco bons ou pouco maus. — Enfim, o meio pelo qual a lei se faz obedecer é o temor da pena. E por
aqui se considera como efeito dela punir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como cessar o mal é de certo modo bem; assim, a
proibição tem de certo modo natureza de preceito. E a esta luz, tomando em sentido lato a palavra
preceito, a lei é universalmente chamada preceito.

RESPOSTA À SEGUNDA. — Aconselhar não é ato próprio da lei, e pode pertencer mesmo a um
particular, que não pode legislar. Por isso, o próprio Apóstolo, ao dar um conselho, disse: Eu é que digo,
não o Senhor. Por isso, não é considerado como efeito da lei.

RESPOSTA À TERCEIRA. — Também o premiar pode pertencer a qualquer pessoa, ao passo que punir
não cabe senão ao ministro da lei, por cuja autoridade a pena é aplicada. Por isso, premiar não é
considerado como ato da lei, mas só punir.

RESPOSTA À QUARTA. — Começando alguém a acostumar-se a evitar o mal e a fazer o bem, pelo temor
da pena, é levado às vezes a praticá-lo por vontade própria e com prazer. E assim, a lei, mesmo punindo,
leva os homens a se tornarem bons.