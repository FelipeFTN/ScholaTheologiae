# Questão 15: Do consentimento.
Em seguida devemos tratar do consentimento.
E nesta Questão quatro artigos se discutem:

## Art. 1 — Se consentir é próprio só da parte apreensiva da alma.
(Infra, q. 74, a . 7, ad 1).
O primeiro discute-se assim. ― Parece que consentir é próprio só da parte apreensiva da alma.

1. ― Pois, Agostinho, atribui o consentimento à razão superior. Ora, a razão designa a virtude
apreensiva. Logo, desta é próprio o consentimento.

2. Demais. ― Consentir é sentir simultaneamente. Ora, sentir é próprio da potência apreensiva. Logo,
também consentir.

3. Demais. ― Assim como assentir significa a aplicação do intelecto a alguma realidade, assim também o
consentir. Ora, assentir é próprio do intelecto, virtude apreensiva. Logo, também a esta pertence o
consentir.
Mas, em contrário, diz Damasceno: quem julga e não ama não sentencia, i. é, não dá o consentimento.
Ora, amar é próprio da virtude apetitiva. Logo, também o consentimento.

SOLUÇÃO. ― Consentir supõe a aplicação de um sentimento a uma realidade. Ora, é próprio ao sentido
conhecer as coisas presentes, pois ao passo que a virtude imaginativa é apreensiva das semelhanças
corpóreas, mesmo se estas pertencem a objetos, o intelecto é apreensivo das razões universais, que
pode apreender indiferentemente, estejam os objetos determinados presentes ou ausentes. E como o
ato da virtude apetitiva é uma como inclinação à realidade em si, a aplicação mesma da virtude apetitiva
à realidade, enquanto aderente a esta, recebe, por uma certa semelhança, o nome de sentido, porque
experimenta, por assim dizer, a realidade a que adere, enquanto que nela se compraz. Por isso diz a
Escritura (Sb 1, 1): Senti bem ao Senhor, na bondade. E neste sentido consentir e ato da virtude
apetitiva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Aristóteles, a vontade está na razão. Por isso,
quando Agostinho atribui o consentimento à razão, considera incluída nela a vontade.

RESPOSTA À SEGUNDA. ― Sentir, em acepção própria, pertence à potência apreensiva; mas, em virtude
da semelhança tirada da experiência, é próprio da apetitiva, como já se disse.

RESPOSTA À TERCEIRA. ― Assentir é como que sentir relativamente a uma coisa, e assim importa numa
certa distância relativa aquilo a que se assente. Consentir porém é sentir simultaneamente, e assim
supõe uma certa união com aquilo no que se consente. E por isso, se diz, mais propriamente, que a
vontade, da qual é próprio o tender à realidade em si, consente; ao passo que do intelecto, cuja
operação não é um movimento para a realidade, mas antes, ao inverso, como já se disse na primeira
parte, se diz, com mais propriedade, que assente, embora se costume tomar uma palavra pela outra. E
também se pode dizer que o intelecto assente, enquanto movido pela vontade.

## Art. 2 — Se o consentimento convém aos brutos.
(Infra, q. 1, a . 2).
O segundo discute-se assim. ― Parece que o consentimento convém aos brutos.

1. ― Pois, o consentimento implica a terminação do apetite em relação a um objeto. Ora, os apetites
dos brutos são assim determinados. Logo, há neles consentimento.

2. Demais. ― Removido o anterior, removido fica o posterior. Ora, o consentimento precede a ação.
Logo, se os brutos tivessem consentimento não agiriam, o que é evidentemente falso.

3. Demais. ― Diz-se às vezes, que os homens consentem em agir, levados por paixões como a
concupiscência ou a ira. Ora, os brutos agem impelidos pela paixão. Logo, há neles consentimento.
Mas, em contrário, diz Damasceno: depois do julgamento, o homem dispõe e ama o que foi julgado pelo
conselho, e isso se chama sentença, i. é, consentimento. Ora, nos brutos não há conselho. Logo,
também não há consentimento.

SOLUÇÃO. ― Consentimento, em sentido próprio não existe nos brutos, pois importa na aplicação do
movimento apetitivo a um algum ato. Ora, dessa aplicação é capaz o que tem em seu poder o referido
movimento; assim, um bastão pode tocar uma pedra, mas fazê-lo tocar a pedra é da alçada de quem
pode movê-lo. Ora, o bruto não tem poder sobre o movimento apetitivo que procede do instinto
natural. Por onde, embora por certo tenha apetite, a nada aplica o movimento apetitivo, e por isso não
se diz, propriamente, que consente, o que é próprio só da natureza racional, que governa esse
movimento e pode aplicá-lo a objetos diversos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nos brutos há determinação do apetite a um objeto,
mas só passivamente. Ora, o consentimento importa numa determinação do apetite, não só passiva,
mas sobretudo ativa.

RESPOSTA À SEGUNDA. ― Removido o anterior, removido fica o posterior que daquela propriamente
resulta. Quando porém o anterior resulta de vários antecedentes, não desaparece com a remoção de
um deles. Assim, se o endurecimento pode resultar do calor e do frio ― como se dá com os tijolos
endurecidos ao fogo, e com a água congelada, endurecida pelo frio ― removido o calor, nem por isso
removido fica o endurecimento. Ora, a execução de uma obra não resulta só do consentimento, mas
também do impulso apetitivo próprio aos animais.

RESPOSTA À TERCEIRA. ― Os homens que agem levados pela paixão podem não segui-la, o que não se
dá com os brutos, e portanto o caso não é o mesmo.

## Art. 3 — Se o consentimento tem por objeto o fim.
O terceiro discute-se assim. — Parece que o consentimento tem por objeto o fim.

1. ― O que convém a um efeito convém com maior razão, à sua causa. Ora, consentimos nos meios por
causa do fim. Logo, neste consentiremos, com maioria de razão.

2. Demais. ― O intemperante tem como fim a sua ação, do mesmo modo que o virtuoso, a sua. Ora,
aquele consente no ato próprio. Logo, o consentimento pode ter por objeto o fim.

3. Demais. ― O desejo dos meios é a eleição, como já se disse. Se pois o consentimento recaísse só
sobre os meios, não diferiria ele em nada da eleição, o que é patentemente falso, conforme se vê em
Damasceno quando diz, que depois da disposição, que denominara sentença, se dá a eleição. Logo, o
consentimento não tem por objeto só os meios.
Mas, em contrário, diz Damasceno, no mesmo passo, que há sentença, ou consentimento, quando o
homem dispõe e ama o que foi julgado pelo conselho. Ora, este só recai sobre os meios. Logo, também
o consentimento.

SOLUÇÃO. ― Consentimento significa aplicação do movimento apetitivo, por quem o tem no seu poder,
a algo de preexistente. Ora, na ordem das ações humanas, é preciso, primeiro, apreender o fim; depois,
desejar o fim; em seguida, deliberar sobre os meios e, afinal, desejá-los. Ora, o apetite tende
naturalmente para o último fim, e por isso a aplicação do movimento apetitivo ao fim apreendido não
implica consentimento, mas um simples querer. Porém, o que supõe o fim último cai, como tal, sob o
conselho; e então pode aí haver consentimento, na medida em que o movimento apetitivo se aplica ao
que foi julgado pelo conselho. Ao contrário, o movimento apetitivo do fim não se apóia no conselho,
antes, este é que naquele se apóia porque pressupõe o desejo do fim; ao passo que o apetite dos meios
pressupõe a determinação do conselho. E portanto, a aplicação do movimento apetitivo à determinação
do conselho é, propriamente, o consentimento. Por onde, como o conselho não tem por objeto senão
os meios, o consentimento propriamente dito não recai senão sobre estes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como conhecemos as conclusões pelos princípios,
dos quais não há ciência mas inteligência, que é superior à ciência; assim também consentimos nos
meios por causa do fim, que todavia não é objeto do consentimento, mas da vontade que lhe é superior.

RESPOSTA À SEGUNDA. ― O intemperante tem como fim, antes, o deleite resultante do ato do que o
ato mesmo e, por isso, é que consente neste.

RESPOSTA À TERCEIRA. ― A eleição acrescenta ao consentimento uma certa relação referente ao que é
preferido; e por isso, depois do consentimento, resta ainda a eleição. Pode dar-se porém que pelo
conselho descubramos vários meios conducentes ao fim e consintamos em todos porque todos nos
convêm; então, de muitos, que nos agradam, escolhemos um de preferência. Se porém encontrarmos
só um que nos agrade, há entre o consentimento e a eleição, diferença não real, mas somente racional;
e então o consentimento consiste em nos comprazermos com esse meio, para agir, e a eleição em o
preferirmos aos que não nos agradam.

## Art. 4 — Se o consentimento para agir pertence sempre à razão superior.
(Infra, q.79, a . 7. II Sent., dist. XXIV, q. 3, a . I. De Verit., q. 15, a . 3).
O quarto discute-se assim. ― Parece que o consentimento para agir nem sempre pertence à razão
superior.

1. ― Pois, como diz o Filósofo, a deleitação resulta do ato e se lhe acrescenta como à mocidade a sua
flor. Ora, consentir na deleitação pertence à razão inferior, como diz Agostinho. Logo, consentir no ato
não pertence só à razão superior.

2. Demais. ― Chama-se voluntária a ação na qual consentimos. Ora, muitas potências podem produzir
ações voluntárias. Logo, não é só a razão superior que consente no ato.

3. Demais. ― A razão superior tende para as coisas eternas, para contemplá-las e nelas se inspirar, como
diz Agostinho. Ora, muitas vezes o homem consente em agir, não por causa de razões eternas, mas por
temporais, ou ainda, movido por certas paixões. Logo, consentir num ato não pertence só à razão
superior.
Mas, em contrário, diz Agostinho: Não é possível que o espírito se resolva eficazmente a cometer um
pecado, se a intenção, que tem pleno poder de fazer com que se movam os membros ou se retraiam da
ação, não ceder às solicitações de um ato mau ou não se deixar escravizar por ele.

SOLUÇÃO. ― A sentença final sempre pertence ao superior, ao qual é próprio julgar os outros; e
enquanto resta a julgar o que lhe é proposto, ainda não é pronunciada a sentença final. Ora, é manifesto
que a razão superior é a que tem que julgar de tudo; pois julgamos das realidades sensíveis pela razão; e
o que se refere às razões humanas, nós o julgamos segundo as razões divinas, que pertencem à razão
superior. Por onde, enquanto for incerto se, segundo as razões divinas, devemos ou não resistir,
nenhum julgamento da razão tem natureza de sentença final. Ora, a sentença final, quanto ao que se
deve fazer, é o consentimento no ato. Logo, este pertence à razão superior, enquanto que, na razão,
está incluída a vontade, como já se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O consentimento na deleitação, resulta do ato, pertence
à razão superior, bem como lhe pertence o consentimento no ato; ao passo que o consentimento na
deleitação resultante de um pensamento pertence à razão inferior, com também a esta lhe pertence o
pensar. Contudo, se considerarmos como um ato o pensar ou não pensar, o juízo pertence à razão
superior; e o mesmo se dá com a deleitação conseqüente. Se porém considerarmos tal ação como
ordenada a outra, então ela pertence à razão inferior. Pois, a ação que se ordena a outra pertence a
uma arte ou potência inferior à que tem por objeto o fim ao qual a referida ação é subordinada. Por
isso, a arte que tem por objeto o fim se chama arquitectônica ou principal.

RESPOSTA À SEGUNDA. ― Por se chamarem voluntárias as ações nas quais consentimos, não é
necessário que o consentimento se aplique a cada potência, mas à vontade, da qual procede o
voluntário, e que está na razão, como já se disse.

RESPOSTA À TERCEIRA. ― Diz-se que a razão superior consente, não só porque sempre move a agir,
segundo as razões eternas, mas também, porque, segundo as mesmas razões, deixa de mover.