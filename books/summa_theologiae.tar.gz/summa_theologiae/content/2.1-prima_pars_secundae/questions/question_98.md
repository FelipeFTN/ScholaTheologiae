# Questão 98: Da lei antiga.
Em seguida devemos tratar da lei antiga. E, primeiro, da lei em si mesma. Segundo, dos seus preceitos.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a lei antiga era boa.
(Art. seq., ad 1, 2; Ad Rom., cap. VII, lect. II, III; Ad Galat., cap. III, lect. VII, VIII; I Tim., cap. I, lect. II).
O primeiro discute-se assim. — Parece que a lei antiga não era boa.

1. — Pois, diz a Escritura (Ez 20, 25): Eu lhes dei uns preceitos não bons, e umas ordenanças nas quais
eles não acharam a vida. Ora, uma lei não é considerada boa senão pela bondade dos preceitos que
contém. Logo, a lei antiga não era boa.

2. Demais. — Pela sua bondade é que a lei é útil para o bem público, como diz Isidoro. Ora, a lei antiga
não era salutar, mas antes, mortífera e nociva. Pois, diz o Apóstolo (Rm 7, 8): Sem a lei o pecado estava
morto. E eu nalgum tempo vivia sem lei; mas quando veio o mandamento reviveu o pecado; e eu sou
morto. E ainda (Rm 5, 20): Sobreveio a lei para que abundasse o pecado. Logo, a lei antiga não era boa.

3. Demais. — Pela sua bondade é que a lei é de observância possível, quanto à natureza e quanto ao
costume humano. Ora, tal não era a lei antiga, conforme diz Pedro (At 15, 10): Porque tentais pôr um
jugo sobre ascervizes dos discípulos, que nem nossos pais nem nós pudemos suportar. Logo, parece que
a lei antiga não era boa.
Mas, em contrário, diz o Apóstolo (Rm 7, 12): Assim que, a lei é na verdade santa, e o mandamento é
santo, e justo, e bom.

SOLUÇÃO. — Sem nenhuma dúvida, a lei antiga era boa. Pois, assim como se manifesta verdadeira uma
doutrina, por estar de acordo com a razão; assim, mostra ser boa uma lei, por estar de acordo com a
razão reta. Ora, a lei antiga estava de acordo com a razão, pois reprimia a concupiscência, que lhe é
contrária a ela, como o prova aquele mandamento (Ex 20, 17): Não cobiçaras os bens do teu próximo. E
também proibia todos os pecados contrários à razão. Por onde é manifesto, que era boa. E esta é a
razão do Apóstolo, quando diz (Rm 7, 22): Eu me deleito na lei de Deus, segundo o homem interior; e
ainda (Rm 7, 16): consinto com a lei, tendo-a por boa.
Devemos porém notar que a bondade tem diversos graus, como diz Dionísio. Assim há uma bondade
perfeita e outra, imperfeita. A perfeita relativamente aos meios consiste em ser um meio tal, que por si
mesmo é conducente ao fim. A imperfeita consiste em praticarmos algum ato para a consecução do fim,
mas não bastante a atingi-lo. Assim, o remédio perfeitamente bom nos cura; o imperfeito ajuda, mas
não pode curar.
Ora, como sabemos um é o fim da lei humana, e outro, o da divina. O fim da lei humana é a
tranqüilidade temporal da cidade. E esse fim a lei o consegue coibindo os atos exteriores, excluindo os
males capazes, de perturbar a paz civil. Ao passo que a lei divina visa levar o homem ao fim da felicidade
eterna, fim que todo pecado impede; e não só por atos externos, como também por internos. Portanto,
o bastante à perfeição da lei humana, que é proibir os pecados e cominar a pena, não o é à perfeição da
lei divina, que há de tornar o homem totalmente capaz de participar da felicidade eterna. Ora, isto não
pode ser senão por graça do Espírito Santo, pela qual se difunde a caridade nos nossos corações, que
cumpre a lei; pois, a graça de Deus é a vida eterna, como diz o Apóstolo (Rm 5, 5). Mas, esta graça a lei
antiga não a podia conferir, pois isso estava reservado a Cristo. Porque, como diz João, a lei foi dada por
Moisés, a graça e a verdade foi trazida por Jesus Cristo. Donde vem, que a lei antiga era, por certo boa,
mas imperfeita, conforme àquilo (Heb 7, 19): a lei nenhuma coisa levou à perfeição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No lugar citado o Senhor fala dos preceitos cerimoniais,
chamados não bons por não conferirem a graça, que purifica os homens do pecado, embora por eles os
homens se mostrassem pecadores. Por isso assinaladamente diz: e umas ordenanças nas quais eles não
achavam a vida, i. é, pelas quais não podem obter a vida da graça. E depois acrescenta: E permiti que
eles se manchassem nos seus dons, i. é, mostrei-os manchados, quando para expiação dos seus pecados
ofereciam lodo o que rompe o claustro materno.

RESPOSTA À SEGUNDA. — Diz-se que a lei matava, não certo efetiva, mas, ocasionalmente, por causa
da sua imperfeição, por não conferir a graça, pela qual os homens pudessem cumprir o que ela mandava
e evitar o que proibia. E assim, essa ocasião não era dada, mas tomada pelos homens. E por isso o
Apóstolo diz, no esmo lugar (Rm 5, 11): o pecado, tomando ocasião do mandamento, me enganou, e me
matou pelo mesmo mandamento. E por esta razão diz: sobreveio a lei para que abundasse o pecado;
onde se deve considerar a expressão — para que — não consecutiva, mas causalmente, i. é, porque os
homens, tomando ocasião da lei, pecaram mais intensamente. Quer por ser o pecado mais grave, depois
da proibição da lei; quer ainda porque a concupiscência aumentasse, pois, maior é a nossa
concupiscência quando se trata do proibido.

RESPOSTA À TERCEIRA. — O jugo da lei não podia ser suportado sem a graça coadjuvante, que a lei não
dava. Pois, diz o Apóstolo (Rm 9, 16): querer e correr nos preceitos de Deus não depende do que quer,
nem do que corre, mas de usar Deus da sua misericórdia. Donde o dizer a Escritura (Sl 118, 32): Corri
pelo caminho dos teus mandamentos, quando dilataste o meu coração, i. é, pelo dom, da graça e da
caridade.

## Art. 2 — Se a lei antiga procedia de Deus.
(Ad Hebr., cap. VII, lect. III).
O segundo discute-se assim. — Parece que a lei antiga não procedia de Deus.

1. — Pois, diz a Escritura (Dt 32, 4): As obras de Deus são perfeitas. Ora, a lei antiga era imperfeita, como
se disse (a. 1). Logo, não procedia de Deus.

2. Demais. — A Escritura diz (Ecle 3, 14): Eu aprendi que todas as obras que Deus fez perseveram para
sempre. Ora, a lei antiga não perseverou para sempre; pois, diz o Apóstolo (Heb 7, 18): O mandamento
primeiro é na verdade abrogado pela fraqueza e inutilidade. Logo, a lei antiga não procedia de Deus.

3. Demais. — Do legislador sábio é próprio extirpar não só os males, como as suas ocasiões. Ora, a lei
antiga era ocasião de pecado, como já se disse (a. 1 ad 2). Logo, não convinha a Deus, a quem nenhum é
semelhante entre os legisladores, no dizer da Escritura (Jó 36, 22), impor tal lei.

4. Demais. — A Escritura diz (1 Tm 2, 4): Deus quer que todos os homens se salvem. Ora, a lei antiga não
bastava para a salvação dos homens, como já se disse (a. 1). Logo, a Deus não convinha dar tal lei, e
portanto a lei antiga não procedia de Deus.
Mas, em contrário, diz o Senhor, falando dos Judeus, a quem foi dada a lei antiga (Mt 15, 6): vós tendes
feito vão o mandamento de Deus pela vossa tradição. E pouco antes tinha dito (Mt 15, 4): Honra a teu
pai e a tua mãe, o que, manifestamente, está contido na lei antiga (Ex 20, 12; Dt 5, 16). Logo, esta
procedia de Deus.

SOLUÇÃO. — A lei antiga foi dada pelo Deus de bondade, Pai de Nosso Senhor Jesus Cristo. Pois, a lei
antiga ordenava os homens para Cristo, de dois modos. — De um modo, dando testemunho de Cristo.
Por isso, o Evangelho diz (Lc 24, 44): é necessário cumprir-se tudo o que de mim estava escrito na lei,
nos Salmos e nos Profetas; e ainda (Jo 5, 46): Porque se vós crêsseis a Moisés, certamente me creríeis
também a mim, porque ele escreveu de mim. — De outro modo, por uma como disposição, enquanto
que, retraindo os homens do culto da idolatria, encerrava-os no culto do Deus único, que, por meio de
Cristo, devia salvar o gênero humano. Por onde, diz o Apóstolo (Gl 3, 23): Antes que a fé viesse,
estávamos debaixo da guarda da lei, encerrados para aquela fé que havia de ser revelada. Ora, é
manifesto, que quem dispõe para o fim também conduz para ele; quero dizer que conduz por si mesmo,
ou por meio de seus subordinados. Ora, o diabo não iria fazer uma lei, conducente dos homens a Cristo,
por quem ele havia de ser lançado fora, conforme àquilo da Escritura (Mt 12, 26): se Satanás lança fora a
Satanás, está ele dividido contra si mesmo. Logo, a lei antiga foi dada por Deus mesmo, donde veio a
salvação aos homens, pela graça de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede o temporalmente perfeito não o ser,
absolutamente. Assim, diz-se que uma criança é perfeita, não absolutamente, mas conforme a sua
condição no tempo; e portanto, os preceitos impostos às crianças são perfeitos, não absolutamente,
mas segundo a condição delas. E tais foram os preceitos da lei. Por isso o Apóstolo diz (Gl 3, 24): a lei
nos serviu de pedagogo que nos conduziu a Cristo.

RESPOSTA À SEGUNDA. — Perseveram eternamente as obras de Deus, que ele fez para assim
perseverarem; e essas são as obras perfeitas. Ora, a lei antiga foi rejeitada no tempo da perfeição da
graça, não por má, mas como insuficiente e inútil para esse tempo; porque, como acrescenta o mesmo
lugar, a lei nenhuma coisa levou à perfeição. Por onde, diz o Apóstolo (Gl 3, 24): Depois que veio a fé, já
não estamos debaixo de pedagogo.

RESPOSTA À TERCEIRA. — Como já dissemos (q. 79, a. 4), Deus às vezes permite certos caírem em
pecado para desse modo se humilharem. Assim também, quis dar uma lei tal que, por suas próprias
forças, os homens não pudessem cumprir, para, presumindo de si mesmos e reconhecendo-se
pecadores, recorrerem, humilhados, ao auxílio da graça.

RESPOSTA À QUARTA. — Embora a lei antiga não bastasse para salvar os homens, contudo,
simultaneamente com ela, Deus deu outro auxílio aos homens, com o qual poderiam salvar-se. E esse foi
a fé no Mediador, pela qual se justificaram os padres antigos, como também nós nos justificamos. E
assim, Deus não abandonava os homens, deixando-os sem os auxílios da salvação.

## Art. 3 — Se a lei antiga foi dada pelos anjos, ou imediatamente por Deus.
(In Isaiam, cap. VI; Ad Galat., cap. III, lect. VII; Ad. Coloss., cap. II, lect. IV; Ad Hebr., cap. II, lect. I).
Parece que a lei antiga não foi dada pelos anjos, mas imediatamente por Deus.

1. — Pois, anjo significando núncio, esse nome implica um ministério e não domínio, conforme àquilo da
Escritura (Sl 102, 20-21): Bendizei ao Senhor, todos os anjos dele. Ora, a mesma Escritura diz, que a lei
antiga foi dada pelo Senhor (Ex 33, 11): Falou o Senhor todas estas palavras; e acrescenta: Eu sou o
Senhor teu Deus. E o mesmo modo de falar é freqüentemente repetido no Êxodo e nos livros seguintes
da lei. Logo, a lei foi imediatamente dada por Deus.

2. Demais. — A Escritura diz (Jo 1, 17): A lei foi dada por Moisés. Ora, este a recebeu de Deus,
imediatamente, conforme ainda a Escritura (Ex 33, 11): O Senhor falava a Moisés cara a cara, bem como
um homem costuma falar ao seu amigo. Logo, a lei antiga foi imediatamente dada por Deus.

3. Demais. — Só o chefe pode legislar, como se disse (q. 90, a. 3). Ora, só Deus é o chefe, no atinente à
salvação das almas; os anjos são apenas espíritos administradores, como diz a Escritura (Heb 1, 14).
Logo, a lei antiga não devia ser dada pelos anjos, pois se ordenava à salvação das almas.
Mas, em contrário, diz o Apóstolo (Gl 3, 19): a lei foi dada pelos anjos na mão dum Mediador; e ainda (At
7, 53): recebestes a lei por ministério dos anjos.

SOLUÇÃO. — A lei foi dada por Deus, por meio dos anjos. E além da razão geral assinalada por Dionísio,
que as coisas divinas devem ser transmitidas aos homens por meio dos anjos, há uma razão especial
pela qual era necessário fosse a lei antiga dada por meio deles. Pois, como já dissemos (a. 1, a. 2), a lei
antiga era imperfeita, mas dispunha para a salvação perfeita do gênero humano, que haveria de vir de
Cristo. Ora, vemos que em todas as faculdades e artes ordenadas, o superior pratica por si mesma o ato
principal e perfeito, e, pelos seus ministros, os disponentes à perfeição última. Assim, o construtor de
um navio o compõe por si mesmo; mas prepara o material diante artífices, trabalhando sob suas ordens.
Por isso foi conveniente a lei perfeita do Novo Testamento ter sido dada imediatamente por Deus
mesmo; e que a lei antiga fosse dada aos homens pelos ministros de Deus, i. é, pelos anjos. E deste
modo o Apóstolo mostra a eminência da lei nova sobre a antiga; porque, em o Novo Testamento, Deus
nos falou pelo Filho; ao passo que, no antigo, falou pelos anjos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Gregório, o anjo que se descreve como tendo
aparecido a Moisés, é tido, ora, como anjo, ora, como o Senhor. Anjo porque, falando, exteriormente,
servia; Senhor, por outro lado, porque, presidindo interiormente, dava eficácia à linguagem. E por isso,
também o anjo representava a pessoa de Deus.

RESPOSTA À SEGUNDA. — Como explica Agostinho, o Êxodo diz: O Senhor falava a Moisés cara a cara; e
pouco depois, acrescenta: Mostra-me a tua glória. Logo, sentia o que via e desejava o que não via. Logo,
não via a essência mesma de Deus, e portanto não era instruído imediatamente por ela. Por onde, o dito
da Escritura — falava com ele cara a cara — é de acordo com a opinião do povo, que pensava que
Moisés falava cara a cara com Deus, por aparecer-lhe Deus e falar-lhe por meio de uma sua criatura,
como o anjo e a nuvem. Ou, por essa visão da face se entende uma certa contemplação eminente e
familiar, inferior à essência da visão divina.

RESPOSTA À TERCEIRA. — Só o chefe pode, por sua autoridade, instituir a lei; mas às vezes promulga
instituída por outros. Assim, Deus institui a lei por sua autoridade, mas a promulgou pelos anjos.

## Art. 4 — Se a lei antiga devia ter sido dada só ao povo judeu.
O quarto discute-se assim. — Parece que a lei antiga não devia ter sido dada só ao povo judeu.

1. — Pois, a lei antiga dispunha da salvação, que viria de Cristo, como se disse (a. 2, a. 3). Ora, essa
salvação não havia de vir só para os judeus, mas para todas as gentes, conforme a Escritura (Is 49,
6): Pouco é que tu sejas meu servo para suscitar as tribos de Jacó e converter as fezes de Israel; eu te
estabeleci para Luz das gentes, a fim de seres tu a salvação que eu envio até a última extremidade da
terra. Logo, a lei antiga devia ter sido dada a todas as gentes e não só ao povo judeu.

2. Demais. — Como diz a Escritura (At 10, 34-35), Deus não faz acepção de pessoas; mas em toda a
nação aquele que o teme e obra o que é justo, esse lhe é aceito. Logo, não devia ter aberto o caminho
da salvação a um povo de preferência a outro.

3. Demais. — A lei foi dada pelos anjos, como se disse (a. 3). Ora, o ministério dos anjos Deus sempre o
deu, não só aos judeus, mas a todas as gentes, conforme a Escritura (Sr 17, 14): Ele estabeleceu a cada
nação seu príncipe que a governasse. E todas as gentes também são favorecidas por bens temporais, de
que Deus cura menos que dos espirituais. Logo, também devia ter dado a lei a todos os povos.
Mas, em contrário, diz a Escritura (Rm 3, 1-2): Que tem, pois, demais o Judeu? Muita vantagem logra em
todas as maneiras; principalmente porque lhes foram por certo confiados os oráculos de Deus. E noutro
lugar (Sl 147, 9): Não fez assim a toda outra nação, e não lhes manifestou os seus juízos.

SOLUÇÃO. — Poder-se-ia dar uma razão de a lei ter sido outorgada antes ao povo judeu, do que aos
outros povos, e é a seguinte. Enquanto os outros caíam na idolatria, só o povo judeu conservava o culto
do Deus único; por isso eram aqueles indignos de receberem a lei, para não se darem as coisas santas
aos cães.
Mas esta razão não pode ser considerada conveniente. Porque o povo judeu, mesmo depois de a lei lhe
ter sido dada, caiu na idolatria, o que era mais grave, conforme está claro na Escritura (Ex 32; Am 5, 25-
26): Porventura, ó casa de Israel; oferecestes-me vós algumas hóstias e sacrifícios no deserto onde
estivestes quarenta anos? e levastes o tabernáculo ao vosso Moloch, e a imagem dos vossos ídolos, o
astro do vosso Deus, coisas que fizestes por vossas mãos. E, noutro lugar, diz expressamente (Dt 9, 6):
Sabe, pois, que não é pela tua justiça que o Senhor teu Deus te fará possuir esta terra tão excelente,
pois que tu és um povo de cerviz duríssima.
Mas a razão está exposta no mesmo lugar: Porque o Senhor queria cumprir o que tinha prometido com
juramento a teus pais Abraão, Isaac e Jacó. E qual fosse essa promessa o Apóstolo a indica (Gl 3, 16): as
promessas foram ditas a Abraão e a sua semente. Não diz: E às sementes, como de muitos, senão como
de um: E à tua semente, que é Cristo. Portanto, Deus deu ao povo judeu a lei e os outros benefícios
especiais, por causa da promessa que lhes fora feita aos pais, para que deles nascesse Cristo. Pois
convinha que o povo, donde Cristo haveria de nascer, fosse distinguido com uma santificação especial,
conforme aquilo da Escritura (Lv 19, 2): Sede santos, porque eu sou santo. Nem foi pelo mérito de
Abraão, que a promessa lhe foi feita, de Cristo haver de nascer da sua semente, mas por escolha e
vocação gratuita de Deus. Donde o dizer a Escritura (Is 41, 2): Quem suscitou do Oriente o justo e o
chamou para que o seguisse?
Por onde é claro que só por eleição gratuita os Patriarcas receberam a promessa e o povo, deles
oriundo, recebeu a lei, segundo àquilo da Escritura (Dt 4, 36-37): tu ouviste as suas palavras do meio do
jogo, porque amou a teus pais e escolheu depois deles a sua posteridade.
Se porém ainda se objetar a escolha de tal povo, e não outro, para Cristo nascer dele, é boa a resposta
de Agostinho, onde diz: Porque chama a um e não a outro, não o queiras decidir se não queres errar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a salvação futura estivesse preparada para
todos por Cristo, contudo era necessário nascesse ele de um povo, que por isso teve acima de todos,
prerrogativa, conforme a Escritura (Rm 9, 4): os judeus, dos quais é a adoção de filhos, e a aliança, e a
legislação, cujos pais são os mesmos de quem descende de Cristo segundo a carne.

RESPOSTA À SEGUNDA. — A acepção de pessoas tem lugar em relação ao que é dado por dívida; no que
porém é conferido por vontade gratuita, não tem lugar. Assim, não faz acepção de pessoas quem por
liberalidade dá do seu a um e não a outro; mas se fosse dispensador dos bens comuns e não os
distribuísse equitativamente, segundo os méritos das pessoas, então haveria acepção delas. Ora, os seus
benefícios salutares Deus os confere ao gênero humano gratuitamente. Por onde, não faz acepção de
pessoas, se os confere a uns de preferência a outros. Por isso, Agostinho diz: Todos os que Deus ensina,
misericordiosamente os ensina; e os que não ensina, pelo seu juízo o faz; o que procede da danação do
gênero humano, por causa do pecado do primeiro pai.

RESPOSTA À TERCEIRA. — Os benefícios da graça são subtraídos ao homem por causa da culpa; mas os
benefícios naturais não o são. Entre os quais estão os ministérios dos anjos; pois a ordem mesma das
naturezas exige, que as ínfimas sejam governadas pelas médias. E também os auxílios materiais, que
Deus confere, não só aos homens, mas também aos brutos, conforme àquilo da Escritura (Sl 35, 7): Tu,
Senhor, salvarás os homens e as bestas.

## Art. 5 — Se todos os homens estavam obrigados a observar a lei antiga.
(In Math., cap. XXIII; Ad Rom., cap. II, lect. III; cap. VI, lect. III).
O quinto discute-se assim. — Parece que todos os homens estavam obrigados a observar a lei antiga.

1. — Pois, quem está sujeito ao rei há de necessariamente estar-lhe sujeito à lei. Ora, a lei antiga foi
dada por Deus, que é o rei de toda a terra, como diz a Escritura (Sl 46, 8). Logo, todos os habitantes da
terra estavam obrigados à observância da lei.

2. Demais. — Os judeus não podiam se salvar sem observarem a lei antiga. Pois, diz a Escritura (Dt 27,
26):Maldito o que não permanece firme nas ordenações desta lei, e que as não cumpre efetivamente.
Se portanto, os outros homens podiam salvar-se sem a observância da lei antiga, pior que a deles seria a
condição dos judeus.

3. Demais. — Os gentios eram admitidos ao rito judaico e à observância da lei, conforme a Escritura (Ex
12, 48): Se algum peregrino quiser passar para a vossa terra e celebrar a Páscoa do Senhor, circuncidem-
se primeiro todos os seus varões, e então a celebrará como é devido e será como natural da mesma
terra. Ora, inutilmente foram os estrangeiros admitidos, por ordem divina, à observância da lei, se sem
esta pudessem salvar-se. Logo, ninguém podia salvar-se sem observar a lei.
Mas, em contrário, diz Dionísio, que muitos gentios foram pelos anjos convertidos a Deus. Ora, é certo
que os gentios não observavam a lei. Logo, sem esta observância certos puderam salvar-se.

SOLUÇÃO. — A lei antiga manifestava os preceitos da lei da natureza, acrescentando-lhes certos
preceitos próprios. Por onde, todos estavam obrigados a observar todos os preceitos da lei antiga, que
também o eram da lei natural; não por serem daquela, mas por pertencerem a esta. Mas ninguém, a
não ser o povo judaico, estava obrigado a observar os preceitos que a lei antiga acrescentou. E a razão
disso é que, como já dissemos (a. 4), a lei antiga foi dada ao povo judaico, para obterem uma certa
prerrogativa de santidade, pela reverência a Cristo, que desse povo devia nascer. Ora, tudo o que é
estatuído para a santificação especial de alguém, só a este obriga. Assim os clérigos, ligados pelo divino
ministério, têm certas obrigações, que não têm os leigos. Semelhantemente, os religiosos estão em
virtude da sua profissão, obrigados a certas obras de perfeição, a que não estão os sacerdotes seculares.
Assim, do mesmo modo, o povo judeu tinha certas obrigações especiais, que não tinham os outros
povos. Por isso diz a Escritura (Dt 18, 13): Tu serás perfeito e sem mancha com o Senhor teu Deus. Pelo
que também usavam de uma certa confissão, como se lê na Escritura (Dt 26, 3): Confesso hoje diante do
Senhor teu Deus, etc.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todos os sujeitos ao rei estão obrigados a observar a lei,
que ele propõe a todos em geral. Mas, se instituir certas disposições a serem observadas pelos seus
servidores particulares, os demais não estão obrigados a observá-las.

RESPOSTA À SEGUNDA. — Quanto mais o homem se une a Deus tanto mais melhora a sua condição.
Por onde, quanto mais adstrito era ao culto divino o povo judaico, tanto mais sobrepujava os outros
povos em dignidade. Por isso, diz a Escritura (Dt 4, 8): onde há outro povo tão célebre, que tenha
cerimônias e ordenações cheias de justiça e toda uma lei? — E semelhantemente, também a este
respeito são de melhor condição os clérigos, que os leigos e os religiosos, que os padres seculares.

RESPOSTA À TERCEIRA. — Os gentios mais perfeita e seguramente conseguiam a salvação na
observância da lei, do que seguindo só a lei natural; por isso eram admitidos a observá-la. Assim como
também, entre nós, os leigos entram para o estado clerical e os padres seculares, para as ordens
religiosas, embora sem isso possam salvar-se.

## Art. 6 — Se a lei antiga foi dada, no tempo conveniente, a Moisés.
(III, q. 70, a. 2, ad 2; IV Sent., dist. I, q. 1, a. 2, qª 4; Ad Galat., cap. III, lect.VII).
O sexto discute-se assim. — Parece que a lei antiga não foi dada, no tempo conveniente, a Moisés.

1. — Pois, a lei antiga dispunha para a salvação, que haveria de vir de Cristo, como se disse (a. 2, a. 3).
Ora, logo depois do pecado, o homem precisava do remédio dessa salvação. Logo, a lei antiga devia ter
sido dada imediatamente depois do pecado.

2. Demais. — A lei antiga foi dada para a santificação daqueles de quem Cristo devia nascer. Ora, a
Abraão começou a ser feita a promessa da semente, que é Cristo, como está na Escritura (Gl 3, 16).
Logo, a lei devia ter sido dada imediatamente, no tempo de Abraão.

3. Demais. — Assim como Cristo não veio a nascer dos outros descendentes de Noé, mas, de Abraão, a
quem a promessa foi feita, assim também não nasceu dos outros filhos de Abraão, senão de David, a
quem, conforme a Escritura, a promessa foi renovada (2 Sm 23, 1): Disse o varão a favor do qual se
decretou sobre o Cristo do Deus de Jacó. Logo, a lei antiga devia ter sido dada depois de David, como o
foi depois de Abraão.
Mas, em contrário, diz o Apóstolo (Gl 3, 19): A lei foi posta por causa das transgressões, até que viesse a
semente, a quem havia feito a promessa, ordenada por anjos na mão de um mediador, i. é, dada orde-
nadamente, como diz a Glosa. Logo, foi conveniente que a lei antiga fosse outorgada naquela época.

SOLUÇÃO. — Foi muito conveniente que a lei antiga tivesse sido dada no tempo de Moisés. E podemos
assinalar disto dupla razão, fundada em ser toda lei imposta a dois gêneros de homens. — Ora, é
imposta a homens duros e soberbos, para coibi-los e dominá-los. — Ora, é imposta também aos bons
que, por ela instruídos, são ajudados a cumprir aquilo que visam.
Por onde, foi conveniente ter sido dada, no tempo em questão, a lei antiga, para conter a soberba dos
homens. Pois, de duas coisas o homem se ensoberbecia: da ciência e do poder. — Da ciência, como se a
razão natural lhe pudesse bastar para a salvação. E então, para lhe vencer a soberba, nesse ponto foi
entregue ao regime da sua razão, sem o adminículo da lei escrita. E assim, pôde aprender
experimentalmente, que sofria deficiência de razão, pois caíram os homens, no tempo de Abraão, até na
idolatria e em vícios torpíssimos. Por onde, depois desse tempo, foi necessário dar-lhe a lei escrita, para
remédio da sua ignorância; pois, pela lei conhecemos o pecado, como diz o Apóstolo (Rm 3, 20). — Mas,
depois de ter sido o homem instruído pela lei, a sua soberba foi vencida pela fraqueza, por não poder
cumprir a lei conhecida. Por isso, o Apóstolo conclui (Rm 8, 3-4), o que era impossível à lei, em razão de
que se achava debilitada pela carne, enviou Deus a seu filho, para que a justificação da lei se cumprisse
em nós.
Por outro lado, para os bons a lei foi dada como auxílio. E isso então era sobretudo necessário, quando a
lei natural começava a obscurecer-se pela freqüência dos pecados. Assim, era necessário fosse tal
auxílio dado numa certa ordem, para, pelo imperfeito, serem levados ao perfeito. Por onde, entre a lei
da natureza e a da graça foi necessário ser dada a lei antiga.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Logo depois do pecado do primeiro homem, não era
oportuno outorgar a lei antiga. Quer porque o homem, confiado na sua razão, ainda não se reconhecia
necessitado dela; quer por não estar o ditame da lei da natureza ainda obscurecido pelo costume de
pecar.

RESPOSTA À SEGUNDA. — A lei não deve ser dada senão ao povo, pois é um preceito comum, como já
dissemos (q. 90, a. 2, a. 3). Por isso, no tempo de Abraão, foram impostos certos preceitos familiares, e
quase domésticos, de Deus aos homens. Mas depois, multiplicada a sua posteridade, de modo a
constituir um povo; e libertada da escravidão, a lei podia ser-lhe convenientemente outorgada. Pois, os
escravos não fazem parte do povo, ou da cidade, a quem a lei deve ser aplicada, como diz o Filósofo.

RESPOSTA À TERCEIRA. — Como a lei devia ser dada a um povo, receberam-no, não só aqueles de que
Cristo nasceu, mas, todo o povo foi marcado com o sinal da circuncisão, sinal da promessa feita a
Abraão, e em que ele acreditou, como diz o Apóstolo. Logo, mesmo antes de David, foi necessário da a
lei a um tal povo já constituído.