# Questão 50: Do sujeito dos hábitos.
Em seguida devemos tratar do sujeito dos hábitos. E sobre esta questão seis artigos se discutem:

## Art. 1 — Se o corpo é susceptível de algum hábito.
(III. Sent., dist. XXIII, q. 1, a . 1).
O primeiro discute-se assim. — Parece que o corpo não é susceptível de nenhum hábito.

1. — Pois, como diz o Comentador, o hábito é que nos leva a agir quando quisermos. Ora, as ações
corpóreas, sendo naturais, não estão sujeitas à vontade. Logo, o corpo não é susceptível de nenhum
hábito.

2. Demais — Todas as disposições corpóreas são facilmente mutáveis. Ora, o hábito é uma qualidade
que se muda dificilmente. Logo, nenhuma disposição corpórea pode ser hábito.

3. Demais — Todas as disposições corpóreas estão sujeitas à alteração. Ora, esta pertence à terceira
espécie de qualidade, que, na divisão, se opõe ao hábito. Logo, o corpo não é susceptível de nenhum
hábito.
Mas, em contrário, diz o Filósofo que se chama hábito à saúde do corpo ou a uma doença incurável.

SOLUÇÃO. — Como já dissemos, o hábito é uma certa disposição de um sujeito potencial em relação a
uma forma ou a uma operação.
Por onde, enquanto implica disposição para a operação, nenhum hábito existe, principalmente, no
corpo como sujeito. Pois, toda operação do corpo ou provêm de uma qualidade natural do mesmo, ou
da alma que o move. Portanto, o corpo não fica disposto, por nenhum hábito, às operações procedentes
da natureza, pois, as virtudes naturais são determinadas a um só termo; pois, como já dissemos, a
disposição habitual é necessária quando o sujeito é potencial em relação a muitos termos. As operações
porém que procedem da alma, por meio do corpo, pertencem, por certo, principalmente, à alma
mesma, mas, secundariamente, ao corpo. Ora, os hábitos proporcionam-se às operações, sendo por isso
que atos semelhantes causam hábitos semelhantes, como diz Aristóteles. E portanto as disposições para
tais operações existem, principalmente, na alma. Podem porém existir no corpo, secundariamente,
enquanto este fica disposto e habilitado a servir prontamente às operações da alma.
Se porém considerarmos a disposição do sujeito em relação à forma, então pode existir uma disposição
habitual no corpo, que está para a alma como o sujeito para a forma. E deste modo, a saúde, a beleza e
atribuições semelhantes chamam-se disposições habituais, embora não realizem perfeitamente a noção
de hábito, porque as suas causas por natureza são facilmente mutáveis.
Alexandre, entretanto, como o refere Simplício, era de doutrina que um hábito ou disposição da
primeira espécie de nenhum modo pode existir no corpo, e dizia que a primeira espécie de qualidade
pertence somente à alma. E o que Aristóteles diz, sobre a saúde e a doença é a título de exemplo e não
que pertençam essas disposições à primeira espécie de qualidade, de modo que o sentido do seu
pensamento é — assim como a doença e a saúde podem mudar-se fácil ou dificilmente, assim também
as qualidades da primeira espécie a que se dá o nome de hábito e disposição. Ora, isto vai claramente
contra a intenção de Aristóteles, quer porque usa do mesmo modo de falar, dando como exemplos à
saúde, a doença, a virtude e a ciência; quer porque coloca expressamente, entre os hábitos, a beleza e a
saúde.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção é procedente quanto ao hábito como
disposição a agir; e quanto aos atos do corpo procedentes da natureza, mas não, dos que procedem da
alma, cujo princípio é à vontade.

RESPOSTA À SEGUNDA. — As disposições corpóreas não são em si mesmas dificilmente mutáveis, por
causa da mutabilidade das causas corpóreas. Podem sê-lo porém por comparação com um determinado
sujeito, isto é, por não poderem ser removidas desse sujeito, durante a sua existência; ou por
comparação com outras disposições. Ao passo que as qualidades da alma são em si mesmas dificilmente
mutáveis por causa da imobilidade do sujeito. E por isso Aristóteles não diz que a saúde, quando
dificilmente mutável, seja em si mesma um hábito, mas que é como um hábito, segundo está no texto
grego. As qualidades da alma porém consideram-se, em si mesmas, hábitos.

RESPOSTA À TERCEIRA. — As disposições corpóreas pertencentes à primeira espécie de qualidade,
como certos disseram, diferem das qualidades da terceira espécie em que estas estão como em vir-a-ser
e em movimento, sendo por isso chamadas paixões ou qualidades passíveis; quando, porém chegarem à
perfeição, i. é, quase à espécie, então já pertencem à primeira espécie de qualidade. — Mas, contra isto
se insurge Simplício, porque, deste modo, a calefação pertenceria à terceira espécie de qualidade, ao
passo que o calor, à primeira; ora, Aristóteles coloca o calor na terceira.
Donde o dizer Porfírio, como Simplício o refere no lugar citado, que a paixão ou a qualidade passível, e a
disposição e o hábito diferem, nos corpos, pela intensidade e pela remissão. Assim, quando um corpo
recebe a calidez mas só porque é aquecido, sem poder aquecer, nele existe então a paixão, se for
transitória, ou a qualidade passível se for permanente. Quando porém adquire também o poder de
aquecer outros corpos, possui uma disposição. Se além disso essa disposição se firmar de tal modo que
venha a ser dificilmente mutável, ela se transformará em hábito. De maneira que a disposição é uma
certa intensidade ou perfeição da paixão ou da qualidade passível; ao passo que o hábito o é, da
disposição. — Mas isto não é admitido por Simplício, porque essa intensidade a remissão não implicam
diversidade por parte da forma em si mesma, mas pela diversa participação do sujeito; por onde, desse
modo, não se poderiam diversificar as espécies de qualidade.
E portanto devemos dizer, de outro modo, que, como já o demonstramos, a comensuração das
qualidades passíveis em si mesmas, relativamente à conveniência com a natureza, implica a noção de
disposição. Por onde, alterando-se o calor e o frio, a unidade e a secura, que são qualidades passíveis,
resulta conseqüentemente, a alteração relativamente à doença e à saúde. Mas, primariamente e por si,
não há alteração relativamente a tais hábitos e disposições.

## Art. 2 — Se os hábitos existem na alma, mais pela essência do que pela potência.
(II Sent., dist. XXVI, a . 3, ad 4, 5).
O segundo discute-se assim. — Parece que os hábitos existem na alma mais pela essência que pela
potência.

1. — Pois, disposições e hábitos respeitam a ordem da natureza, como já se disse. Ora, a natureza é
relativa mais à essência da alma do que às potências da mesma, porque esta é, por essência, a natureza
de um tal corpo e a sua forma. Logo, os hábitos estão na alma essencial mais do que potencialmente.

2. Demais — Não pode haver acidente de acidente. Ora, de um lado o hábito é um acidente e, de outro,
as potências da alma também pertencem ao gênero dos acidentes, como já se disse na Primeira Parte.
Logo, o hábito não está na alma, em razão da sua potência.

3. Demais — O sujeito é anterior ao que nele existe. Ora, o hábito, pertencente à primeira espécie de
qualidade é anterior à potência, que pertence à segunda. Logo, o hábito não tem na potência da alma o
seu sujeito.
Mas, em contrário, o Filósofo introduz hábitos diversos nas diversas partes da alma.

SOLUÇÃO. — Como já dissemos, o hábito implica uma certa disposição ordenada para a natureza ou
para a operação.
Se o considerarmos como ordenado para a natureza, ele não pode existir na alma; isto se nos referimos
à natureza humana, porque a alma é em si forma completiva dessa natureza. Por onde, a esta luz, um
hábito ou uma disposição existirá antes no corpo, ordenado para a alma, que na alma, ordenado para o
corpo. — Se nos referimos porém a alguma natureza superior, da qual o homem possa tornar-se
participante, conforme aquilo da Escritura (2 Pd 1, 4) — para que sejamos feitos participantes da
natureza divina — então nada impede haja na alma essencialmente algum hábito, a saber, a graça,
como a seguir se dirá.
Se porém considerarmos o hábito relativamente à operação, então ele existe por excelência na alma,
porque esta não é determinada a uma só operação, mas, é susceptível de muitas, o que é exigido para o
hábito, como já dissemos. E como, pelas suas potências, é que a alma é princípio das operações, os
hábitos nela existem pelas potências da mesma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A essência da alma pertence à natureza humana, não
como sujeito que deve receber alguma outra disposição, mas como forma e natureza à qual qualquer
disposição é relativa.

RESPOSTA À SEGUNDA. — Um acidente não pode, em si mesmo, ser sujeito de outro. Mas como
mesmo entre os acidente há uma certa ordem, pode um sujeito, enquanto por sua vez é acidente, ser
também sujeito de outro acidente. E então dizemos que um acidente é o sujeito de outro; assim, a
superfície é sujeito da cor e, do mesmo modo, a potência pode ser sujeito do hábito.

RESPOSTA À TERCEIRA. — O hábito tem prioridade sobre a potência enquanto importa disposição para
a natureza; a potência porém sempre implica relação com a operação, que é posterior, porque a
natureza é o princípio da operação. Ao passo que o hábito, cujo sujeito é a potência, não implica em
ordenar-se para a natureza, mas para a operação, e por isso é posterior à potência. — Ou podemos dizer
que o hábito é anterior à potência como o completo o é ao incompleto e o ato, à potência; pois, o ato
tem naturalmente, prioridade, embora a potência lhe seja anterior na ordem da geração e do tempo,
como diz Aristóteles.

## Art. 3 — Se as potências da parte sensitiva são susceptíveis de algum hábito.
(III Sent., dist. XIV, a . 1 qª 2; dist. XXIII, q. 1, a . 1; De Virtut., q. 1, a . 1).
O terceiro discute-se assim. — Parece que as potências da parte sensitiva não são susceptíveis de
nenhum hábito.

1. — Pois, como a potência nutritiva, também a sensitiva pertence ao irracional. Ora, não se admite
nenhum hábito nas potências da parte nutritiva. Logo, também não devemos admitir nenhum nas da
parte sensitiva.

2. Demais — As partes sensitivas são-nos comuns com os brutos. Ora, estes não são susceptíveis de
nenhum hábito por não terem vontade, que entra na definição do hábito, como já se disse. Logo, as
potências sensitivas não são susceptíveis de nenhum hábito.

3. Demais — Os hábitos da alma são as ciências e as virtudes; e assim como a ciência diz respeito à
potência apreensiva, assim a virtude, à apetitiva. Ora, as potências sensitivas não são susceptíveis de
nenhuma ciência, porque esta tem por objeto o universal, que aquelas não podem apreender. Logo,
também as partes sensitivas não podem ter os hábitos das virtudes.
Mas, em contrário, diz o Filósofo, que as partes irracionais têm certas virtudes, a saber, a temperança e
a fortaleza.

SOLUÇÃO. — As potências sensitivas podem considerar-se de duplo modo, enquanto operam pelo
instinto da natureza, ou pelo império da razão. — No primeiro caso ordenam-se, bem como a natureza,
a um só termo. E portanto, assim como as potências naturais não são susceptíveis de hábitos, assim
também não o são, no caso vertente, as potências sensitivas. — No segundo modo, podem se ordenar a
termos diversos. E assim, podem ser susceptíveis de certos hábitos, pelos quais ficam bem ou mal
dispostos para alguma atividade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não é natural às potências da parte nutritiva obedecer
ao império da razão e, portanto, não são susceptíveis de quaisquer hábitos. Mas as potências sensitivas
o são, e por isso são capazes de ter certos hábitos, pois na medida em que obedecem à razão,
consideram-se de certa maneira, racionais, como diz Aristóteles.

RESPOSTA À SEGUNDA. — As potências sensitivas, nos brutos, não operam pelo império da razão, pois,
abandonados a si mesmos, os brutos agem por instinto da natureza. Por onde, os brutos não têm
hábitos ordenados às operações, embora haja neles certas disposições ordenadas à natureza, como a
saúde e a beleza. Como porém eles são dispostos, pela razão do homem, e em virtude de um certo
costume, a operar de tal ou de tal outro modo, podemos admitir que haja neles de certa maneira
hábitos. Por isso, diz Agostinho: vemos certos animais, dos mais brutos, absterem-se dos máximos
prazeres, por medo das dores; e esses mesmos os consideramos como domesticados e mansos, uma vez
assim habituados. Falta-lhes porém o que no hábito implica o uso da vontade, pois não têm o poder de
usar dela ou não, o que pertence à razão. Por onde, propriamente falando, não podem ser susceptíveis
de hábito.

RESPOSTA À TERCEIRA. — É natural ao apetite sensitivo ser movido pelo racional, como diz Aristóteles;
ao passo que às potências racionais apreensivas é natural serem influenciadas pelas virtudes sensitivas.
Por onde, é mais curial existam os hábitos nas potências sensitivas apetitivas, do que nas sensitivas
apreensivas, pois naquelas eles não existem senão enquanto agem ao império da razão. Nas próprias
potências internas sensitivas apreensivas porém podem existir certos hábitos, que facilitam ao homem
lembrar-se, cogitar ou imaginar; por isso o Filósofo diz, que o costume contribui muito para termos boa
memória; pois as potências sensitivas são levadas a agir pelo império da razão. As potências apreensivas
externas porém como a visão, a audição e outras, não são susceptíveis de quaisquer hábitos, mas são
ordenadas aos seus atos determinados pela disposição da sua natureza; e tal é também o caso dos
membros do corpo, não susceptíveis de hábitos, que pertencem, antes, às potências que lhes impõem
os movimentos.

## Art. 4 — Se o intelecto é susceptível de hábitos.
(III Sent., dist. XIV, a . 1, qª 2; dist. XXIII, q. 1, a . 1; De Verit., q. 10, a . 2; De Virtut., q. 1, a . 1).
O quarto discute-se assim. — Parece que o intelecto não é susceptível de hábito.

1. — Pois, os hábitos são conformados às operações, como já se disse (a. 1). Ora, as operações do
homem são comuns à alma e ao corpo, conforme diz Aristóteles. Logo, também o hábito. Ora, o
intelecto não é ato do corpo, como ensina Aristóteles. Logo, o intelecto não é sujeito de nenhum hábito.

2. Demais — Tudo o existente em outro ser, neste existe ao modo do mesmo. Ora, o que é forma sem
matéria é somente ato; ao passo que o composto de forma e de matéria encerra simultaneamente a
potência e o ato. Logo, no ser puramente formal nada pode existir que esteja simultaneamente em
potência e em ato, mas somente no ser composto de matéria e forma. Ora, o intelecto é forma sem
matéria. Logo, o hábito, que encerra simultaneamente a potência e o ato, sendo um quase termo médio
entre este e aquela, não pode existir no intelecto, mas só no conjunto, composto de alma e corpo.

3. Demais — O hábito é uma disposição pela qual nos dispomos bem ou mal para alguma coisa, como
diz Aristóteles. Ora, é por uma disposição do corpo, que nos dispomos bem ou mal para o ato da
inteligência; por onde, Aristóteles diz ainda, que os de carne delicada são, como vemos, de boa aptidão
mental. Logo, os hábitos cognoscitivos não existem no intelecto, que é separado, mas em alguma
potência que seja ato de uma parte do corpo.
Mas, em contrário, o Filósofo coloca a ciência, a sapiência, e o intelecto, que é o hábito dos princípios,
na parte intelectiva mesma da alma.

SOLUÇÃO. — São várias as opiniões a respeito dos hábitos cognoscitivos. Assim uns, ensinando que o
intelecto possível é o mesmo para todos os homens, são forçados a admitir que os hábitos cognoscitivos
existem, não no intelecto mesmo, mas nas virtudes interiores sensitivas. Pois, os homens,
diversificando-se pelos hábitos, como é manifesto, não podemos admitir que os hábitos cognoscitivos
existam diretamente no que, sendo numericamente uno, é comum a todos os homens. Por onde, se o
intelecto possível é numericamente um, para todos os homens, os hábitos das ciências, que os
diversificam, não poderão existir nele como sujeito, mas sim, nas potências interiores sensitivas,
diversas nos diversos homens.
Mas, esta opinião, primeiro é contra a intenção de Aristóteles. Pois, é manifesto que as potências
sensitivas não são racionais por essência, mas só, por participação, como diz Aristóteles. Ora, o Filósofo
inclui as virtudes intelectuais — a sapiência, a ciência e o intelecto — na parte racional por essência. Por
onde, não existem nas potências sensitivas, mas no próprio intelecto. Pois, diz expressamente que o
intelecto possível, quando se torna em cada coisa singular, i. é, quando é reduzido ao ato (apreensivo)
das coisas singulares pelas espécies inteligíveis, então se atualiza, do modo pelo qual dizemos que quem
é ciente está em ato; e isto se dá quando podemos operar por nós mesmos, i. é, refletindo. E é, sem
dúvida, certo que, também neste caso, é potencial, de certa maneira; não, porém, como antes de
aprender ou descobrir.
Por onde, é no intelecto possível que está o hábito da ciência, pelo qual ele pode refletir, embora não
esteja refletindo. — Em segundo lugar, a opinião de que se trata vai também contra a verdade das
coisas. Pois, assim como a potência também o hábito é próprio do ser ao qual é própria a operação. Ora,
inteligir e refletir é ato próprio do intelecto. Logo, também o hábito, pelo qual refletimos, está
propriamente no intelecto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Certos disseram, como o refere Simplício, que, como
toda operação do homem pertence, de certo modo, ao composto, segundo o diz o Filósofo, nenhum
hábito pertence só à alma, senão ao conjunto. Donde se seque que, sendo o intelecto separado,
nenhum hábito nele existe, como o pretende a razão anterior. — Mas esta objeção não colhe; pois, o
hábito não é uma disposição do objeto para a potência, mas antes, desta para aquele. Por onde e
necessariamente, o hábito há-de existir na potência mesma, que é princípio do ato, não porém no que
está para a potência como seu objeto. Ora, só em razão dos fantasmas, como já se estabeleceu, é que
dizemos que inteligir é comum à alma e ao corpo; e é claro que o fantasma se reporta ao intelecto
possível como seu objeto, segundo já se demonstrou. Donde se conclui, que o hábito intelectivo se
radica principalmente no próprio intelecto e não nos fantasmas, comuns à alma e ao corpo. Logo,
devemos concluir, que o intelecto possível é o sujeito do hábito. Ora, isso é próprio ao que é potencial
em relação a muitos termos, o que convém, por excelência, ao intelecto possível. Portanto, este é o
sujeito dos hábitos intelectuais.

RESPOSTA À SEGUNDA. — Assim como ser potencial em relação ao ser sensível é natural à matéria
corpórea, assim o é ao intelecto possível sê-lo em relação ao ser inteligível. Por onde, nada impede
exista no intelecto possível o hábito, meio termo entre a pura potência e o ato perfeito.

RESPOSTA À TERCEIRA. — De prepararem interiormente as potências apreensivas o objeto próprio ao
intelecto possível, resulta que, pela boa disposição de tais potências, para a qual coopera a boa
disposição do corpo, o homem se torna apto a inteligir. E assim, o hábito intelectivo pode,
secundariamente, existir nessas potências; principalmente porém existe no intelecto possível.

## Art. 5 — Se a vontade é susceptível de algum hábito.
(II Sent., dist. XXVII, a . 1, ad 2; III, dist. XXIII, q. 1, a . 1; De Verit., q. 20, a . 2; De Virtut., q. 1, a . 1).
O quinto discute-se assim. — Parece que a vontade não é susceptível de nenhum hábito.

1. — Pois, os hábitos existentes no intelecto são espécies inteligíveis, pelas quais ele intelige em ato.
Ora, a vontade não opera por meio de nenhumas espécies. Logo, a vontade não é sujeito de nenhum
hábito.

2. Demais — O intelecto agente não o julgamos susceptível de nenhum hábito, ao contrário do que se
dá com o intelecto possível, que é uma potência ativa. Ora, a vontade é, por excelência, uma potência
ativa, porque move todas as potências a concorrerem aos seus atos, como já se disse. Logo, nela não há
nenhum hábito.

3. Demais — Nas potências naturais não há nenhum hábito, pois por natureza elas são determinadas a
um certo termo. Ora, a vontade, por sua natureza, se ordena a tender para o bem ordenado pela razão.
Logo, a vontade não é susceptível de nenhum hábito.
Mas, em contrário, a justiça é um hábito. Ora, ela existe na vontade, pois é o hábito pelo qual queremos
e obramos o que é justo, como já se disse. Logo, a vontade pode ser sujeito de algum hábito.

SOLUÇÃO. — Toda potência que pode ordenar-se diversamente à ação necessita de um hábito pelo qual
se dispõe bem para o seu ato. Ora, a vontade, sendo uma potência racional, pode ordenar-se
diversamente à ação. Logo, é necessário admitirmos nela algum hábito pelo qual se disponha bem para
o seu ato. Demais, da sua própria noção resulta que o hábito se ordena principalmente à vontade, pois é
o de que usamos quando quisermos, segundo já ficou dito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como no intelecto há uma espécie que é
semelhança do objeto; assim é necessário haver na vontade e em qualquer potência apetitiva algo pelo
qual ela se inclina ao seu objeto, pois o ato da virtude apetitiva não passa de uma inclinação, como já
dissemos. Ora, aquilo a que uma potência se inclina suficientemente, pela sua própria natureza não
exige nenhuma qualidade inclinante. Mas como é necessário, para o fim da vida humana, que a potência
apetitiva se incline a um objeto determinado, para o qual não se inclina pela própria natureza, que é
relativa a muitos e diversos objetos, é necessário haja na vontade e nas outras potências apetitivas
certas qualidades inclinantes, chamadas hábitos.

RESPOSTA À SEGUNDA. — O intelecto agente é só agente e, de nenhum modo paciente. A vontade
porém e qualquer potência apetitiva é motora e movida, como já se disse. Logo, não há semelhança, em
ambos os casos; pois, ser susceptivo de hábito convém ao que está de certo modo em potência.

RESPOSTA À TERCEIRA. — A vontade, pela sua natureza mesma, inclina-se para o bem da razão. Mas,
como este bem se diversifica de múltiplas maneiras, necessário é a vontade inclinar-se por algum
hábito, a um determinado bem da razão, para que daí resulte mais pronta a operação.

## Art. 6 — Se nos anjos há hábitos.
(III Sent., dist. XIV, a . 1, qª 2, ad 1).
O sexto discute-se assim. — Parece que nos anjos não há hábitos.

1. — Pois, diz Máximo, comentador de Dionísio: Não devemos julgar que as virtudes intelectuais, i. é,
espirituais,existam nos intelectos divinos, i. é, nos anjos, como em nós, a modo de acidentes, de
maneira que um destes exista em outro como num sujeito; pois, nos anjos não há qualquer acidente.
Ora, todo hábito é acidente. Logo, nos anjos não há hábitos.

2. Demais — Como diz Dionísio, as disposições santas das essências celestes participam, por excelência,
da bondade de Deus. Ora, o que é por si é sempre anterior e mais principal do que o existente por meio
de outro ser. Logo, as essências dos anjos, em si mesmas, se aperfeiçoam pela conformidade com Deus
e não, portanto, por meio de quaisquer hábitos. E esta parece ser a razão de Máximo, que logo a seguir
se lê: Se tal não se desse, a essência dos anjos não subsistiria em si mesma, nem poderia, o quanto
possível, ser, em si mesma, deificada.

3. Demais — O hábito é uma disposição, como já se disse. Ora, a disposição, como no mesmo lugar se
acrescenta, é a ordem do que tem partes. Ora, os anjos sendo substâncias simples, resulta que neles
não há disposições e hábitos.
Mas, em contrário, diz Dionísio, os anjos da primeira hierarquia chamam-se Ardentes, Tronos e Efusão
da sapiência, manifestação deiforme dos hábitos dos mesmos.

SOLUÇÃO. — Certos disseram que nos anjos não há hábitos, mas que tudo que deles dizemos
essencialmente o dizemos. Por isso Máximo, depois das palavras supra-citadas, acrescentou: Os hábitos
e as virtudes neles existentes são essenciais por causa da imaterialidade dos mesmos. E Simplício
também diz: A sapiência da alma é um hábito; a do intelecto, substância; pois, tudo o que é divino tem
em si mesmo a sua suficiência e a sua existência.
Esta opinião é em parte verdadeira e em parte, falsa. Pois é manifesto, pelo que já dissemos, que o
sujeito do hábito não é senão o ser em potência. Ora, considerando os preditos comentadores que os
anjos são imateriais e que neles não há a potência da matéria, deles excluíram o hábito e qualquer
acidente. Entretanto, embora não haja nos anjos a potência da matéria, há todavia alguma potência,
porque ser ato puro é só próprio de Deus; e portanto, na mesma medida em que neles há potências,
pode haver também hábitos. Mas como a potência da matéria e a da substância intelectual não têm a
mesma essência, conseqüentemente também os hábitos, num e noutro caso, não podem tê-la idêntica.
Donde o dizer Simplício, que os hábitos da substância intelectual não são semelhantes aos de que
tratamos aqui; mas são, antes, semelhantes às espécies simples e materiais que ela contêm em si
mesma.
Em relação a tais hábitos porém uma é a posição do intelecto angélico e outra, do humano. Este, que é
infinito na ordem das inteligências, é potencial relativamente a todos os inteligíveis, como o é a matéria
prima em relação a todas as formas sensíveis; e por isso, para inteligir todas as coisas precisa de um
certo hábito. O intelecto angélico porém não se comporta como pura potência no gênero dos
inteligíveis, mas como um certo ato. Não certo como ato puro, o que é próprio só de Deus, mas, vai de
mistura com alguma potência, da qual tanto menos tem quanto mais superior é. Por onde, como
dissemos na Primeira Parte, enquanto potencial, necessita ser aperfeiçoado habitualmente por certas
espécies inteligíveis, para o fim da sua operação própria. Enquanto atual porém pode, pela sua essência,
inteligir certos objetos, ao menos a si próprio, e os demais ao modo da sua substância, com se diz no
livro De causis; e isso tanto mais perfeitamente quanto mais perfeito for. Como nenhum anjo porém
alcança a perfeição de Deus, do qual dista infinitamente, necessita, para atingir a Deus pelo intelecto e
pela vontade, de certos hábitos, como potencial que é em relação ao ato puro. E por isso Dionísio diz
que os hábitos dos anjos pelos quais se conformam com Deus, são deiformes. — Os hábitos porém, que
são disposições para o ser natural, não existem nos anjos, que são imateriais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras de Máximo devem ser entendidas dos
hábitos e dos acidentes materiais.

RESPOSTA À SEGUNDA. — No que convém essencialmente aos anjos, ele não precisam de hábito. Mas,
como não são seres de tal modo por si mesmos existentes, que não participem da sabedoria e da
bondade divina, por isso, na medida em que precisam participar de algo exterior, nessa mesma
devemos admitir que neles há hábitos.

RESPOSTA À TERCEIRA. — Nos anjos não há partes essenciais, mas apenas potenciais, enquanto o
intelecto se lhes aperfeiçoa por meio de várias espécies, e a vontade se refere a vários objetos.