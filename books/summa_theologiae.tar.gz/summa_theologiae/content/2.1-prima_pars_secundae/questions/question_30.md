# Questão 30: Da concupiscência.
Em seguida devemos tratar da concupiscência. E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se a concupiscência reside só no apetite sensitivo.
O primeiro discute-se assim. ― Parece que a concupiscência não reside só no apetite sensitivo.

1. ― Pois, há uma certa concupiscência da sabedoria, como diz a Escritura (Sb 6, 21): a concupiscência
ou o desejo da sabedoria conduz ao reino eterno. Ora, o apetite sensitivo não pode se elevar até a
sabedoria. Logo a concupiscência não reside só no apetite sensitivo.

2. Demais. ― O apetite sensitivo não tem desejo dos mandamentos de Deus; antes, o Apóstolo diz (Rm
7, 18): em mim quero dizer, na minha carne, não habita o bem. Ora, o desejo dos mandamentos de
Deus está compreendido na concupiscência, conforme aquilo da Escritura (Sl 118, 20): A minha alma
desejou ansiosa em todo tempo as tuas justificações. Logo, a concupiscência não reside só no apetite
sensitivo.

3. Demais. ― Cada potência deseja o seu bem. Logo, a concupiscência existe em cada uma das potências
da alma e não só no apetite sensitivo.
Mas, em contrário, diz Damasceno: a parte irracional, que obedece e segue à persuasão da razão, se
divide em concupiscência e ira. Ora, esta é parte passiva e apetitiva da alma racional. Logo, a
concupiscência reside no apetite sensitivo.

SOLUÇÃO. ― Como diz o Filósofo, a concupiscência é um apetite deleitável. Ora, há duas espécies de
deleites, como a seguir se dirá: um próprio ao bem inteligível, que pertence à razão; outro, próprio ao
bem sensível. Ora, a primeira espécie pertence só à alma, ao passo que a segunda, à alma e ao corpo,
porque, sendo os sentidos virtudes existentes em órgãos corpóreos, o bem sensível é bem do conjunto.
Ora, o apetite de tal deleite é a concupiscência que, como o próprio nome o indica, pertence
simultaneamente à alma e ao corpo. Por onde, a concupiscência, propriamente falando, reside no
apetite sensitivo e na virtude concupiscível, que, da concupiscência, recebe a sua denominação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O apetite da sabedoria ou dos outros bens espirituais é
chamado às vezes concupiscência, quer por causa de uma certa semelhança; quer por causa da
intensidade do apetite da parte superior que redunda no inferior de modo tal que este, arrastado pelo
superior, vem a tender, ao seu modo, para o bem espiritual, e assim também o corpo serve ao espírito,
conforme a Escritura (Sl 83, 3): O meu coração e a minha carne se regozijaram no Deus vivo.

RESPOSTA À SEGUNDA. ― O desejo, propriamente falando, pode pertencer, não só ao apetite inferior,
mas também e sobretudo ao superior. Pois, ele não implica, como a concupiscência, uma associação
com o seu objeto, senão um simples movimento para a coisa desejada.

RESPOSTA À TERCEIRA. ― Cada potência da alma deseja o seu bem próprio, por apetite natural, o qual
não depende da apreensão. Mas, o desejo que tem do bem o apetite animal, que depende da
apreensão, pertence só à virtude apetitiva. E enfim, desejar algo sob espécie de bem deleitável sensível
― o que é propriamente ter concupiscência ― pertence à virtude concupiscível.

## Art. 2 — Se a concupiscência é uma paixão especial da potência concupiscível.
(Supra, q. 23, a . 4; III Sent., dist. XXVI, q. 1, a . 3).
O segundo discute-se assim. ― Parece que a concupiscência não é uma paixão especial da potência
concupiscível.

1. ― Pois, as paixões se distinguem pelos seus objetos. Ora, o objeto do concupiscível é o deleitável
sensível, que também é o objeto da concupiscência, segundo o Filósofo. Logo, a concupiscência não é
uma paixão especial do concupiscível.

2. Demais. ― Agostinho diz, que a cobiça é o amor das coisas transitórias, e assim não se distingue do
amor. Ora, todas as paixões especiais se distinguem umas das outras. Logo, a concupiscência não é uma
paixão especial do concupiscível.

3. Demais. ― Cada paixão do concupiscível tem a sua contrária, com já dissemos. Ora, à concupiscência
não se opõe nenhuma paixão especial; pois, diz Damasceno, que o bem esperado constitui a
concupiscência; o presente, a alegria. Semelhantemente, o mal esperado constitui o temor e o presente,
a tristeza. Daqui resulta que, assim como a tristeza é contrária à alegria, assim o temor o é a
concupiscência. Ora, este não reside no concupiscível mas, no irascível. Logo, a concupiscência não é
nenhuma paixão especial do concupiscível.
Mas, em contrário, a concupiscência é causada pelo amor e tende para a deleitação, paixões do
concupiscível. E assim, distingue-se, como paixão especial, das outras paixões do concupiscível.

SOLUÇÃO. ― Como já dissemos, o bem deleitável sensível é em geral o objeto do concupiscível; por
onde, as várias paixões do concupiscível se distinguem pelas diferenças desse bem. Ora, as diversidades
do objeto podem ser consideradas relativamente à natureza mesma dele ou às diversidades da virtude
ativa. Ora, as diversidades do objeto ativo, fundadas em a natureza mesma deste, causam a diferença
material das paixões; ao passo que as diversidades da virtude ativa produzem a diferença formal delas,
que as diversifica especificamente.
Mas é preciso também levar em conta a noção de fim ou bem, como virtude motriz, quer enquanto
realmente presente, quer enquanto ausente. Pois, quando presente, leva-nos a repousar nele; e quando
ausente, nos move para ele. Por onde, quando o deleitável sensível adapta, de certo modo, a si e
conforme o apetite, causa o amor; quando, ausente, atrai para si, causa a concupiscência; quando por
fim, estando presente, produz a quietação do apetite, causa o deleite. Assim, pois, a concupiscência é
uma paixão especificamente diferente do amor e da deleitação; mas, o desejar um objeto deleitável ou
tal outro produz as diversidades numéricas da concupiscência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O bem deleitável não é objeto da concupiscência,
absolutamente falando, senão enquanto ausente; assim como o sensível é, enquanto passado, objeto da
memória. Ora, estas condições particulares diversificam as espécies de paixões ou também as das
potências da parte sensitiva, que respeita objetos particulares.

RESPOSTA À SEGUNDA. ― A denominação de Agostinho se funda na causa e não na essência, pois a
cobiça não é, em si mesma, amor, mas efeito deste. ― Ou, de outro modo, podemos responder que
Agostinho se refere à cobiça, em sentido lato, como designando qualquer movimento do apetite capaz
de respeitar a um bem futuro. E assim, compreende em si o amor e a esperança.

RESPOSTA À TERCEIRA. ― A paixão diretamente oposta à concupiscência não tem denominação e está
para o mal como a concupiscência para o bem. Mas, sendo relativa ao mal ausente, como o temor é às
vezes tomada por este, assim como a cobiça o é, por vezes, pela esperança. Pois, como o bem e o mal
pequenos quase não são levados em conta, consideram-se quaisquer movimentos do apetite para o
bem ou para o mal futuros como esperança e temor, que respeitam o bem e o mal árduos.

## Art. 3 — Se certas concupiscências são naturais e outras, não-naturais.
(Infra, q. 41, a. 3; q. 77, a . 5).
O terceiro discute-se assim. ― Parece que não são certas concupiscências naturais e outras, não-
naturais.

1. ― Pois, a concupiscência pertence ao apetite animal, como já se disse. Ora, o apetite natural se divide
por oposição com o animal. Logo, nenhuma concupiscência é natural.

2. Demais. ― A diversidade material não produz a diversidade específica, mas só a numérica, e não é
compreendida no domínio da arte. Ora, se há concupiscências naturais e não-naturais, elas não diferem
senão pelos seus objetos, o que produz a diferença material e numérica somente. Logo, as
concupiscências não dividem em naturais e não-naturais.

3. Demais. ― A razão se divide por oposição com a natureza, como se vê em Aristóteles. Se pois há no
homem alguma concupiscência não-natural, ela há-de necessariamente ser racional. Ora, tal não pode
ser porque, sendo a concupiscência uma paixão, pertence ao apetite sensitivo e não à vontade, que é
um apetite racional. Logo, não há concupiscências não-naturais.
Mas, em contrário, o Filósofo considera certas concupiscências como naturais e outras, como não-
naturais.

SOLUÇÃO. ― Como já dissemos, a concupiscência é um apetite do bem deleitável. Ora, de dois modos
um bem pode ser tal. ― Ou porque é conveniente à natureza do animal, como a comida, a bebida e
coisas semelhantes e tal concupiscência do deleitável se chama natural. ― Ou porque é conveniente ao
animal em virtude de uma apreensão; assim, quando é apreendido algo como bom e conveniente, e por
conseqüência, com isso há deleite. E esta concupiscência do deleitável se chama não-natural,
denominando-se de ordinário cobiça.
Ora, as concupiscências da primeira espécie ― as naturais, são comuns ao homem e aos animais,
porque a uns e a outros há algo que lhes é naturalmente conveniente e deleitável. E, por isso, o Filósofo
as denominacomuns e necessárias. ― As da segunda espécie porém são próprias aos homens, que tem
a propriedade de buscar algo como bom e conveniente, além daquilo que a natureza exige. E por isso
diz ainda o Filósofo que as concupiscências da primeira espécie são irracionais; as da segunda porém
são acompanhadas da razão. E como coisas diversas se fundamentam diversamente, as desta última
espécie Aristóteles também as denominapróprias e adventícias, i. é, superiores às naturais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Aquilo mesmo que é desejado pelo apetite natural pode
sê-lo, quando apreendido, pelo apetite animal. E neste sentido a comida, a bebida e coisas semelhantes,
naturalmente apetecidas, podem ser objetos da concupiscência natural.

RESPOSTA À SEGUNDA. ― A diversidade entre as concupiscências naturais e as não-naturais não é
somente material mas às vezes também formal, enquanto procede da diversidade dos objetos ativos.
Ora, o objeto do apetite é o bem apreendido. Por onde, a objetos ativos diversos correspondem
apreensões diversas, conforme alguma coisa é apreendida como conveniente, por apreensão absoluta,
que causa as concupiscências naturais, denominadas pelo Filósofo irracionais; ou conforme é
apreendida, com deliberação, o que causa as concupiscências não naturais, que por isso são designadas
por Aristóteles como acompanhadas da razão.

RESPOSTA À TERCEIRA. ― O homem tem não somente a razão universal, pertencente à parte
intelectiva mas também a particular, pertencente à sensitiva, como dissemos no livro primeiro. E desde
então, a concupiscência que é acompanhada da razão também pode pertencer ao apetite sensitivo. E
além disso, o apetite sensitivo, por sua vez, pode ser movido pela razão universal, mediante a
imaginação particular.

## Art. 4 — Se a concupiscência e infinita.
O quarto discute-se assim. ― Parece que a concupiscência não é infinita.

1. ― Pois, o objeto da concupiscência é o bem, que exerce a função de fim. Ora, quem introduz o
infinito exclui o fim, como diz Aristóteles. Logo, a concupiscência não pode ser infinita.

2. Demais. ― A concupiscência, procedendo do amor, busca o bem conveniente. Ora, o infinito, sendo
desproporcionado, não pode ser conveniente. Logo, a concupiscência não pode ser infinita.

3. Demais. ― Não podendo percorrer o infinito, não podemos portanto, chegar-lhe ao último termo.
Ora, a concupiscência, atingindo o objeto último, transforma-se em deleitação. Logo, se a
concupiscência fosse infinita nunca se transformaria na deleitação.
Mas, em contrário, diz o Filósofo, que por ser a concupiscência infinita é que os homens desejam coisas
infinitas.

SOLUÇÃO. ― Como já dissemos, há duas espécies de concupiscência: a natural e a não-natural. ―
Aquela não pode ser infinita em ato, pois é relativa àquilo que a natureza exige. Ora, como esta tende
sempre a um fim finito e certo, o homem nunca deseja infinita comida ou bebida. Mas como em a
natureza pode haver o infinito potencial por sucessão, também a concupiscência que lhe é relativa pode
ser infinita do mesmo modo, de maneira que, obtido um alimento, deseje outro ou qualquer outra coisa
exigida pela natureza, pois esses bens corpóreos, quando obtidos não permanecem perpetuamente,
mas desaparecem. E por isso o Senhor disse à Samaritana (Jô 4, 13): Todo aquele que bebe desta água
tornará a ter sede. ― A concupiscência não-natural porém é absolutamente infinita, pois é conseqüente
à razão, como já dissemos. Ora, esta pode proceder ao infinito. Por isso, quem deseja as riquezas pode
desejá-las sem termo, de modo a torna-se, tanto quanto puder, rico, absolutamente.
Pode porém dar-se ainda outra razão, segundo o Filósofo, e é que há uma concupiscência finita e outra,
infinita. A do fim é sempre infinita, pois o fim é desejado por si mesmo, como, p. ex., a saúde que,
quanto melhor, tanto mais desejada é, ao infinito, assim como se o branco, em si mesmo, desagrega, o
que mais branco é mais desagrega. ― Mas, a concupiscência dos meios não é infinita, sendo eles
desejados apenas na medida conveniente ao fim. Por onde os que põem o fim nas riquezas tem a
concupiscência delas ao infinito; ao passo que aqueles que as desejam para as necessidades da vida
desejam-nas finitas e bastantes a essas necessidades, como diz o Filósofo no mesmo passo. E o mesmo
se deve dizer sobre as concupiscências de quaisquer outras coisas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Tudo o que é objeto de concupiscência é desejado como
um certo fim, quer por ser realmente finito, enquanto desejado uma vez, em ato; quer por ser finito, por
cair no domínio da apreensão. E não pode ser apreendido sob a noção de infinito, porque, como diz
Aristóteles, o infinito é aquilo além do qual podemos sempre tomar alguma coisa de novo, quanto à
quantidade.

RESPOSTA À SEGUNDA. ― A razão tem, de certo modo, virtude infinita, porque pode considerar objetos
infinitos em número, como bem se vê na adição dos números e das linhas. Por onde, o infinito é de
certo modo proporcionado à razão. Pois, o universal, que a razão apreende, é de certa maneira, infinito,
porque contém potencialmente infinitos singulares.

RESPOSTA À TERCEIRA. ― Para que nos deleitemos não é preciso consigamos tudo o que desejamos,
mas, que nos deleitemos com aquilo que desejamos e conseguimos.