# Questão 37: Dos efeitos da dor e da tristeza.
Em seguida devemos tratar dos efeitos da dor e da tristeza.
E sobre deste ponto quatro artigos se discutem:

## Art. 1 — Se a dor elimina a faculdade de aprender.
O primeiro discute-se assim. — Parece que a dor não elimina a faculdade de aprender.

1. — Pois, diz a Escritura (Is 26, 9): Quando exercitares na terra os teus juízos, aprenderão justiça os
habitadores do orbe; e mais adiante (Is 26, 16): saudável lhes foi na tribulação do seu murmúrio a tua
doutrina. Ora, dos juízos de Deus e da tribulação resulta a dor ou tristeza nos corações dos homens.
Logo, a dor ou tristeza não elimina, mas antes desenvolve a faculdade de aprender.

2. Demais — Diz a Escritura (Is 28, 9): A quem ensinará a ciência? E a quem fará entender o que se
ouviu? Aos que já se lhes tirou o leite, aos que já foram desmamados, i. é, dos prazeres. Ora, a dor e a
tristeza é que sobretudo exclui os prazeres; pois, impede qualquer prazer, como está em Aristóteles; e a
Escritura diz (Ecl 9, 29), que o mal presente faz esquecer os maiores prazeres. Logo, a dor não elimina,
mas antes desenvolve a faculdade de aprender.

3. Demais — A tristeza interior é mais forte que a dor externa, como já dissemos. Ora, o homem pode
aprender, embora possuído de tristeza. Logo, com maior razão, quando possuído pela dor corpórea.
Mas, em contrário, diz Agostinho: Embora, nesses dias estivesse duramente afligido por uma dor de
dentes, não me era possível voltar o ânimo, senão talvez para o que já havia aprendido; pois, achava-me
completamente impedido de aprender o que estava completamente na tendência do meu espírito.

SOLUÇÃO. — Como todas as potências da alma se lhe radicam na essência una, é necessário que,
quando a intenção da alma é levada veementemente à operação de uma potência, retraia-se da
operação de outra, pois uma mesma alma não pode ter senão uma intenção. E por isso o que atrair para
si a intenção total da alma, ou grande parte dela, não se compadecerá com mais nada que reclame
grande atenção. Ora, é manifesto que a dor sensível atrai soberanamente para si essa intenção; pois, as
coisas tendem, na sua intenção total, a repelir o que lhes é contrário, como bem se vê já nos seres
naturais. E semelhantemente, também é manifesto que para aprender de novo uma noção é necessário
estudo e esforço, com grande intenção, conforme está claro na Escritura (Pr 2, 4-5): Se buscares como o
dinheiro, e cavares pelo achar como os que desenterram tesouros, então acharás a ciência. E portanto,
se a dor for intensa, o homem não poderá aprender nada; e poderá ser tão intensa que nem mesmo,
enquanto domina, possa pensar no que antes já sabia. Há nisto porém diferenças, relativas às diferenças
do amor com que aprendemos ou refletimos; a este quanto maior for tanto mais impedirá a intenção da
alma de ser completamente dominada pela dor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A tristeza moderada, exclusiva da evagação da alma,
pode ser útil para adquirirmos a ciência; e principalmente daquilo pelo que esperamos nos libertar da
tristeza. E deste modo, na tribulação do seu murmúrio, os homens recebem mais facilmente a doutrina
de Deus.

RESPOSTA À SEGUNDA. — Tanto o prazer como a dor, na medida em que arrastam a intenção da alma,
impedem a consideração racional; e por isso Aristóteles diz ser impossível compreendermos seja o que
for durante o prazer venéreo. A dor entretanto, mais que o prazer, absorve essa intenção, como vemos,
nos seres naturais, em que a ação de um corpo natural é mais intensa em relação ao que lhe é contrário;
assim, a água quente, sofrida mais intensamente por um corpo frio, congela-se mais fortemente. Se
portanto a dor ou a tristeza for moderada, pode acidentalmente ser útil para aprendermos, na medida
em que exclui a superabundância do prazer; mas em si mesma é um impedimento; e se for intensa
privará totalmente da faculdade de aprender.

RESPOSTA À TERCEIRA. — A dor externa provém da lesão do corpo, e por isso é, mais que a interna,
acompanhada da transmutação corpórea; a interna porém é maior, relativamente ao que há de formal
na dor, que depende da alma. E por isso, a dor corpórea impede, mais que a interna, a contemplação,
que exige o repouso completo. E contudo, se a dor interna também for demasiado intensa, arrastará a
intenção de tal modo que o homem não pode aprender nada de novo. Assim Gregório, levado da
tristeza, abandonou a exposição do livro de Ezequiel.

## Art. 2 — Se o gravame do ânimo é efeito da tristeza.
O segundo discute-se assim. — Parece que o gravame do ânimo não é efeito da tristeza.

1. — Pois, diz o Apóstolo (2 Cor 7, 11): Considerai, pois, quanto esta mesma tristeza, que sentistes
segundo Deus, produziu em vós não só de vigilante cuidado, mas também de apologia, de indignação,
etc.. Ora, o cuidado e a indignação implicam um certo soerguimento do ânimo oposto ao gravame.
Logo, este não é efeito da tristeza.

2. Demais — A tristeza se opõe ao prazer. Ora, este tem como efeito a dilatação, a que se opõe, não o
gravame, mas a constrição. Logo, o gravame não deve ser considerado efeito da tristeza.

3. Demais — É próprio da tristeza consumir, como se vê por aquilo do Apóstolo (1 Cor 2, 7): para que
não aconteça que seja consumido de demasiada tristeza quem se acha em tais circunstâncias. Ora, o
agravado não é consumido; antes, sofre pressão de um corpo pesado; ao passo que o consumido inclui-
se no que consome. Logo, o gravame não deve ser considerado efeito da tristeza.
Mas, em contrário, Gregório Nisseno (Nemésio) e Damasceno dizem que a tristeza agrava.

SOLUÇÃO. — Os efeitos das paixões da alma são designados às vezes metaforicamente, por semelhança
com os corpos sensíveis, porque os movimentos do apetite animal são semelhantes às inclinações do
apetite natural. Assim, atribuímos o fervor ao amor, a dilatação ao prazer, e o gravame à tristeza. Pois,
dizemos que uma pessoa se torna agravada quando o seu movimento próprio é tolhido por algum peso.
Ora, como é claro pelo já dito, a tristeza procede de um mal presente, o qual pelo mesmo repugnar ao
movimento da vontade, agrava o ânimo, tolhendo-o de gozar do que quer.
Se porém a violência do mal contristante não for de molde a eliminar a esperança de nos livrarmos dele,
embora produza o gravame do ânimo, impedindo-lhe a posse atual do que quer, contudo permanece o
movimento para repelir esse mal. Se porém a violência do mal for tão intensa de modo a tolher toda
esperança de nos livrarmos dele, então também o movimento interior do ânimo angustiado ficará
absolutamente impedido, sem poder voltar-se para nenhum lado; e às vezes também o movimento
exterior do corpo fica assim impedido, que o homem se torna estúpido, concentrado dentro de si
mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tal soerguimento do ânimo provém da tristeza segundo
Deus, pela esperança, que traz consigo, da remissão do pecado.

RESPOSTA À SEGUNDA. — No respeitante ao movimento apetitivo, ao mesmo que se refere a
constrição refere-se também o gravame. Pois é por se tornar agravado, de modo a não poder dirigir-se
livremente para as cousas exteriores, que ele se retrai dentro em si, quase constringido em si mesmo.

RESPOSTA À TERCEIRA. — Diz-se que a tristeza nos consome quando a violência do mal contristante
afeta o ânimo de modo a excluir toda esperança de libertação. E assim, por igual o agrava e consome.
Pode porém dar-se, que coisas que vão bem juntas, metaforicamente consideradas, venham a se
repugnar, consideradas no seu sentido próprio.

## Art. 3 — Se a tristeza impede toda operação.
O terceiro discute-se assim. — Parece que a tristeza não impede toda operação.

1. — Pois, a solicitude é causada pela tristeza, como resulta da autoridade do Apóstolo anteriormente
aduzida. Ora, a solicitude ajuda a agir bem, e por isso o Apóstolo diz (2 Tm 2, 15): Cuida muito em te
apresentares a Deus digno de aprovação. Logo, a tristeza não impede a operação mas antes a ajuda.

2. Demais — A tristeza produz em muitos a concupiscência, como diz Aristóteles. Ora, a concupiscência
torna mais intensa a operação. Logo, também a tristeza.

3. Demais — Assim como certas operações são próprias dos alegres, assim outras, como chorar, o são
dos tristes. Ora, uma atividade aumenta com o que lhe é conveniente. Logo, certas operações não ficam
tolhidas mas antes, intensificam-se pela tristeza.
Mas, em contrário, diz o Filósofo, que o prazer aperfeiçoa a operação, e ao contrário a tristeza a tolhe.

SOLUÇÃO. — Como já dissemos, a tristeza nem sempre agrava o ânimo ou o consome, a ponto de
excluir todo movimento interior e exterior, mas antes, é causa de certos movimentos. Donde o poder a
operação relacionar-se duplamente com a tristeza. — De um modo como o objeto desta, e então a
tristeza pode tolher qualquer operação; assim, o que fazemos com tristeza nunca o fazemos tão bem
como o que fazemos com prazer ou sem tristeza. E a razão é que, sendo a vontade a causa da operação
humana, quanto mais o objeto desta nos entristecer, a ação será necessariamente tanto mais fraca. —
De outro modo, a operação se relaciona com a tristeza como sendo esta o princípio e a causa. E então,
necessariamente, tal operação há-de aumentar com a tristeza; assim, quanto mais nos entristecemos
com alguma coisa, tanto mais nos esforçamos para a repelir, enquanto temos a esperança de o
conseguir; do contrário, nenhum movimento ou operação seria causado pela tristeza.
Donde se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES.