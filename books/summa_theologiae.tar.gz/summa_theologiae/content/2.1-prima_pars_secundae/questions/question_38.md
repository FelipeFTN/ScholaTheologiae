# Questão 38: Dos remédios da dor ou tristeza.
Em seguida devemos tratar dos remédios da dor ou tristeza.
E sobre este assunto cinco artigos se discutem:

## Art. 1 — Se o prazer mitiga a dor ou tristeza.
(Supra, q. 35, a . 4, ad 2; infra, a . 5; III, q. 46, a . 8, ad 2; II Cor., cap. VII, lect. II).
O primeiro discute-se assim. — Parece que o prazer não mitiga a dor ou tristeza.

1. — Pois, o prazer não mitiga a tristeza senão por lhe ser contrário, porque os remédios são contrários
aos males, como diz Aristóteles. Ora, não qualquer prazer é contrário a qualquer dor, como já dissemos.
Logo, o prazer não mitiga a tristeza.

2. Demais — O que causa a tristeza não a mitiga. Ora, certos prazeres causam a tristeza; pois, como diz
Aristóteles, o mau se entristece porque se deleitou. Logo, nem todo prazer mitiga a tristeza.

3. Demais — Agostinho diz que saiu da pátria onde convivera com um amigo, que veio a falecer, porque
assim, os seus olhos não haviam de o procurar onde não costumavam vê-lo. Donde podemos concluir
que aquilo que os nossos amigos mortos ou ausentes tinham de comum conosco se nos torna penoso,
quando sofremos com a morte ou ausência deles. Ora, eles tinham de comum conosco sobretudo os
prazeres. Logo, estes se nos tornam penosos quando nos entristecemos. Logo, o prazer não mitiga a
tristeza.
Mas, em contrário, diz o Filósofo, que o prazer expulsa a tristeza, tanto a contrário como qualquer outra,
sendo forte.

SOLUÇÃO. — Como do sobredito resulta, o prazer é o repouso do apetite no bem conveniente; e a
tristeza é o repugnante ao apetite. Por onde, o prazer está para a tristeza, nos movimentos apetitivos,
como, relativamente ao corpo, o descanso para a fadiga, proveniente de alguma transmutação não
natural; pois também a tristeza implica uma certa fadiga ou sofrimento da virtude apetitiva. Assim pois
como o repouso do corpo é remédio contra a fadiga proveniente de qualquer causa não natural, assim o
prazer é remédio para mitigar a tristeza, qualquer que ela seja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora nem todo prazer seja contrário à tristeza
especificamente, lh’o é contudo genericamente, como já dissemos. E portanto, relativamente à
disposição do sujeito, a tristeza pode ser mitigada pelo prazer.

RESPOSTA À SEGUNDA. — Os deleites dos maus não provocam a tristeza presente, mas a futura,
quando se arrependerem dos males que lhes causaram prazer. E essa tristeza é aliviada pelos prazeres
contrários.

RESPOSTA À TERCEIRA. — De duas causas a inclinarem a movimentos contrários, uma se opõe a outra,
até finalmente vencer a mais forte e de ação mais diuturna. Ora, quando nos entristecemos por causa
daquilo com que costumávamos nos deleitar juntamente com o amigo, agora morto ou ausente, duas
causas existem conducentes a termos opostos. Pois o pensamento da morte ou da ausência do amigo
inclina para a dor, ao passo que o bem presente, para o prazer; e por isso um diminui o outro. Contudo,
como o sentido apreensor do que é presente move mais fortemente que a memória do passado, e o
amor próprio dura mais que o de outrem, daí vem que ao cabo o prazer expulsa a tristeza. E por isso,
depois de algumas palavras, Agostinho, no mesmo lugar, acrescenta, que a sua dor cedia aos primeiros
gêneros de prazeres.

## Art. 2 — Se o pranto mitiga a tristeza.
O segundo discute-se assim. — Parece que o pranto não mitiga a tristeza.

1. — Pois, nenhum efeito diminui a sua causa. Ora, o pranto ou gemido é efeito da tristeza. Logo, não a
diminui.

2. Demais — Assim como o pranto ou gemido é efeito da tristeza, assim, efeito da alegria é o riso. Ora,
este não diminui aquela. Logo, nem o pranto mitiga a tristeza.

3. Demais — Com o pranto se nos representa o mal que entristece. Ora, a imaginação do objeto da
tristeza aumenta a esta última, assim como a imaginação do objeto da alegria a intensifica. Logo, o
pranto não mitiga a tristeza.
Mas, em contrário, diz Agostinho, que quando se condoia com a morte do amigo, só os gemidos e as
lágrimas lhe proporcionavam algum alívio.

SOLUÇÃO. — As lágrimas e os gemidos naturalmente mitigam a tristeza e por duas razões. — A primeira
é que todo mal reprimido aflige mais por aumentar a contenção da alma. Mas quando ele se expande,
para o exterior, essa contenção como que se esvai e então diminui a dor interna. E por isso, quando,
tomados da tristeza, a manifestamos exteriormente pelo pranto ou gemido, ou ainda, pela palavra, nós
a mitigamos. — A segunda é que sempre a atividade consoante à disposição em que estamos nos é
deleitável. Ora, o pranto e os gemidos são atividades consoantes a quem está triste ou sofre, e por isso
se tornam deleitáveis. Ora, como todo prazer mitiga de certo modo a tristeza ou a dor, como já
dissemos, resulta que o pranto e o gemido mitigam a tristeza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A relação mesma entre a causa e o efeito é contrária à
existente entre o que contrista e quem é contristado. Pois, todo efeito é conveniente à sua causa, e lhe
é por conseqüência deleitável. Ora, o que contrista contraria o contristado. Portanto, o efeito da tristeza
tem com o contristado uma relação contrária à que, com o mesmo, tem o que contrista. E por isso, em
razão dessa contrariedade, a tristeza fica mitigada pelo seu próprio efeito.

RESPOSTA À SEGUNDA. — A relação entre o efeito e a causa é semelhante à existente entre a causa do
prazer e quem o goza, por haver conveniência de parte a parte. Ora, os semelhantes se intensificam
mutuamente. Por isso, o riso e os outros efeitos da alegria a aumentam, e só não o farão se forem em
excesso.

RESPOSTA À TERCEIRA. — É natural que, em si mesma, a imaginação de um objeto contristante
aumente a tristeza. Mas o mesmo imaginar que fazemos o que nos convém, em um determinado
estado, nos causa um certo prazer. E pela mesma razão, se formos tomados do riso, numa circunstância
em que deveríamos chorar, havemos de sofrer por fazer o que não é conveniente, como diz Túlio.

## Art. 3 — Se o amigo que se compadece conosco mitiga a tristeza.
(In Iob, cap. II, lect. II; cap. XVI, lect. I; Rom., cap. XII, lect. III; IX Ethic., lect. XIII).
O terceiro discute-se assim. — Parece que o amigo que se compadece conosco não mitiga a tristeza.

1. — Pois, os contrários são efeitos dos contrários. Ora, como diz Agostinho, quando muitos entre si se
comprazem, é mais intenso o prazer de cada um, porque mutuamente se excitam e inflamam. Logo,
pela mesma razão, é maior a tristeza quando muitos estão simultaneamente tristes.

2. Demais — A amizade quer ser paga com amizade, como diz Agostinho. Ora, o amigo compadecido
condói-se com a dor do amigo. Logo, essa dor do amigo compadecido é, para o amigo que já antes sofria
do mal próprio, causa de outra dor. Por onde, duplicando-se a dor, há-de a tristeza crescer.

3. Demais — Todo mal do amigo, bem como o próprio, é causa de tristeza, pois o amigo é outro eu. Ora,
a dor é um mal. Logo, a do amigo compadecido aumenta a tristeza do amigo de que ele se condói.
Mas, em contrário, diz o Filósofo, que, nas tristezas, o amigo nos consola que sofre conosco.

SOLUÇÃO. — Naturalmente, o amigo que se compadece de nós, nas tristezas, é consolatório; e disso dá
o Filósofo dupla razão. A primeira é que, sendo próprio da tristeza agravar, ela como implica um certo
peso, do qual procuramos nos aliviar quando estamos agravados. Por isso, quando vemos outros tristes
por causa da nossa tristeza, como imaginamos carregam conosco a nossa carga, como se esforçando por
nos aliviarem dela; e assim se torna mais leve o peso da tristeza, como se dá quando transportamos
pesos materiais. — A segunda razão e melhor é que, quando os amigos se contristam conosco, sentimos
sermos amados deles, o que é deleitável, como já dissemos. Como toda deleitação mitiga a tristeza,
conforme também já foi dito, resulta que o amigo compadecido nos mitiga a tristeza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A amizade se manifesta tanto por nos alegrarmos com
os alegres como por nos compadecermos dos que sofrem. E por isso ambas essas coisas, em razão da
causa, se tornam deleitáveis.

RESPOSTA À SEGUNDA. — O condoer-se do amigo, em si mesmo, haveria de contristar; mas antes,
deleita, quando lhe considerarmos a causa, que é o amor.
Donde se deduz clara a RESPOSTA À TERCEIRA OBJEÇÃO.

## Art. 4 — Se a contemplação da verdade mitiga a dor.
O quarto discute-se assim. — Parece que a contemplação da verdade não mitiga a dor.

1. — Pois, como diz a Escritura (Ecl 1, 18), o que acrescenta a ciência, também acrescenta o trabalho.
Ora, a ciência supõe a contemplação da verdade. Logo, a contemplação da verdade não mitiga a dor.

2. Demais — A contemplação da verdade é própria ao intelecto especulativo. Ora, o intelecto
especulativo não move, como diz Aristóteles. Ora, sendo a alegria e a dor movimentos da alma, resulta
que a contemplação da verdade em nada influi a mitigação da dor.

3. Demais — O remédio do sofrimento deve ser aplicado onde o sofrimento existe. Ora, a contemplação
da verdade é própria do intelecto. Logo, não mitiga a dor corpórea, residente no sentido.
Mas, em contrário, diz Agostinho: Parecia-me, se aquele fulgor da verdade se manifestasse às nossas
mentes, ou que eu não haveria de sentir aquela dor, ou a toleraria como se nada fosse.

SOLUÇÃO. — Como já dissemos, é na contemplação da verdade que sobretudo consiste o prazer. Ora,
todo prazer mitiga a dor, como também já demonstramos. Logo, a contemplação da verdade mitiga a
tristeza ou dor, e tanto mais perfeitamente quanto mais perfeitamente formos amantes da sabedoria. E
por isso os homens, na tribulação, alegram-se com a contemplação das coisas divinas e da felicidade
futura, conforme aquilo da Escritura (Tg 1, 2): Meus irmãos, tende por um motivo da maior alegria para
vós as diversas tribulações que vos sucedem. E o que é mais, tal alegria se encontra mesmo entre os
cruciatos do corpo; assim, Tibúrcio mártir, andando com os pés nus sobre brasas ardentes, dizia: Parece-
me andar sobre rosas, em nome de Jesus Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O que acrescenta a ciência também acrescenta o
trabalho, ou pela dificuldade e deficiência no descobrir a verdade, ou porque pela ciência conhecemos
muitas coisas contrárias à nossa vontade. E assim, em relação às coisas conhecidas, a ciência causa
trabalho; e relativamente porém à contemplação da verdade, prazer.

RESPOSTA À SEGUNDA. — O intelecto especulativo não move a alma relativamente ao objeto da
especulação; move-a porém relativamente à especulação mesma, bem do homem e naturalmente
deleitável.

RESPOSTA À TERCEIRA. — Nas potências da alma dá-se a redundância da superior para a inferior. E
sendo assim, o prazer da contemplação, pertencente à parte superior, redunda na mitigação mesmo da
dor sensível.

## Art. 5 — Se o sono e o banho mitigam a tristeza.
O quinto discute-se assim. — Parece que o sono e o banho não mitigam a tristeza.

1. — Pois, a tristeza está na alma. Ora, o sono e o banho são relativos ao corpo. Logo, em nada
concorrem para mitigar a tristeza.

2. Demais — O mesmo efeito não pode ser causado por causas contrárias. Ora, o sono e o banho, sendo
corpóreos, repugnam à contemplação da verdade, causa da mitigação da tristeza, como já dissemos.
Logo, não mitigam a tristeza.

3. Demais — A tristeza e a dor, pertencendo ao corpo, consistem numa certa transmutação do coração.
Ora, o sono e o banho são remédios relativos antes aos sentidos exteriores e aos membros, que à
disposição interior do coração. Logo, não mitigam a tristeza.
Mas, em contrário, diz Agostinho: Ouvi que o nome de banho provém de expelir a ansiedade da alma; e
em seguida: Dormi e acordei, e senti que a minha dor se mitigara não pouco. E cita o dito do hino de
Ambrósio, que o repouso torna de novo aptos ao trabalho os membros cansados, torna ágeis as mentes
fadigadas e dissipa os sofrimentos angustiosos.

SOLUÇÃO. — Como já dissemos, a tristeza especificamente repugna ao movimento vital do corpo. E
portanto, o que restitui a natureza corpórea ao estado devido da noção vital repugna à tristeza e a
mitiga. E portanto, na medida em que tais remédios fazem a natureza recobrar o estado devido, são
causa de prazer, porque esse refazer-se da natureza é o constitutivo do prazer, como já dissemos. Por
onde, como todo prazer mitiga a tristeza, o banho e o sono são remédios corpóreos mitigantes da
tristeza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A constituição devida do corpo, enquanto sentida, causa
a deleitação, e por conseguinte mitiga a tristeza.

RESPOSTA À SEGUNDA. — Um prazer impede outro, como já dissemos; contudo, todos mitigam a
tristeza. E por isso não há inconveniente em a tristeza mitigar por causas que mutuamente se impedem.

RESPOSTA À TERCEIRA. — Toda boa disposição do corpo redunda de certo modo no coração, princípio e
fim dos movimentos corpóreos, como diz Aristóteles.