# Questão 108: Do conteúdo da lei nova.
Em seguida devemos tratar do conteúdo da lei nova.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a lei nova devia ordenar ou proibir certos atos externos.
(Quodl. IV, q. 8, a. 2; Ad Rom., cap. III, lect. IV)
O primeiro discute-se assim. — Parece que a lei nova não devia ordenar nem proibir certos atos
externos.

1. — Pois, a lei nova é o Evangelho do reino celeste, conforme a Escritura (Mt 24, 14): Serás pregado
este Evangelho do reino por todo o mundo. Ora, o reino de Deus não consiste em atos externos, senão
só em internos, conforme a Escritura (Lc 17, 21): Está o reino de Deus dentro de vós; e (Rm 14, 17): O
reino de Deus não é comida nem bebida, mas justiça e paz e gozo no Espírito Santo. Logo, a lei nova não
devia ordenar nem proibir qualquer ato externo.

2. Demais. — A lei nova é a lei do Espírito, como diz a Escritura (Rm 8, 2), onde há o Espírito do Senhor,
aí há liberdade, como diz o Apóstolo (2 Cor 3, 17). Logo, não há liberdade, quando o homem é obrigado
a fazer ou a evitar certos atos externos. Logo, a lei nova não contem nenhum preceito ou proibição
sobre atos externos.

3. Demais. — Todos os atos externos dependem das mãos, como os internos, da alma. Ora, a diferença
entre a lei nova e a antiga é que esta coibia as mãos, e aquela coíbe a alma. Logo, a lei nova não devia
estabelecer proibições e preceitos sobre os atos externos, mas somente sobre os internos.
Mas, em contrário, pela lei nova os homens se tornam filhos da luz; e por isso diz a Escritura (Jo 12,
36):Crede na luz, para que sejais filhos da luz. Ora, os filhos da luz devem fazer as obras da luz e não as
das trevas, conforme o Apóstolo (Ef 5, 8): Noutro tempo éreis trevas, mas agora sois luz no Senhor;
andai como filhos da luz. Logo, a lei nova devia proibir certas obras externas e ordenar outras.

SOLUÇÃO. — Como já dissemos (q. 106, a. 1, 2), o que há de principal na lei nova é a graça do Espírito
Santo, que se manifesta na fé que obra por caridade. E esta graça os homens a conseguem pela
mediação do Filho de Deus humanado, cuja humanidade foi primeiro, cheia de graça, que, depois, se
nos comunicou. Por isso, diz a Escritura (Jo 1, 14): O verbo se fez carne; e em seguida: Cheio de graça e
de verdade; e em seguida: E todos nós participamos da sua plenitude, e graça por graça. E por isso
acrescenta: a graça e a verdade foi trazida por Jesus Cristo. Por onde, convém que, por certos meios
sensíveis externos, a graça que promana do Verbo encarnado chegue até nós; e que a graça interior,
que torna a carne sujeita ao espírito, produza certas obras sensíveis externas.
Assim pois os atos externos podem de dois modos pertencer à graça — Primeiro, por levarem de certo
modo a ela. E tal é a ação dos sacramentos instituídos pela lei nova, como, o batismo, a Eucaristia e
outros. — De outro modo, há atos externos produzidos por inspiração da graça. Mas aqui devemos fazer
uma distinção. Certos atos externos têm conveniência ou contrariedade necessária com a graça interior,
consistente na fé que obra por caridade. E esses atos são ordenados ou proibidos pela lei nova; assim
ela ordena a confissão da fé e proíbe a negação. Por isso a Escritura diz (Mt 10, 32-33): Todo aquele que
me confessar diante dos homens, também eu o confessarei diante de meu Pai; e o que me negar diante
dos homens, também eu o negarei diante de meu Pai. Há outros atos porém que não têm contrariedade
ou conveniência necessária com a fé que obra por caridade. E esses a lei nova não os ordenou nem os
proibiu na sua instituição primitiva, mas foi deixado pelo legislador, i. é, por Cristo, ao arbítrio de cada
um determinar como deve proceder em relação a eles. Assim, cada qual é livre, relativamente a esses
atos, de determinar o que lhe convém fazer ou evitar; e o mesmo deve ordenar aos seus súditos o
chefe, determinando o que, em tal caso, deve ser feito ou evitado. Por isso, neste ponto, a lei do
Evangelho é chamada lei da liberdade; porque a lei antiga fazia muitas determinações e pouco deixava
para ser determinado pela liberdade humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O reino de Deus consiste principalmente nos atos
internos; por conseqüência, também pertence ao reino de Deus tudo aquilo sem o que esses atos não
podem ser praticados. Assim se o reino de Deus consiste na justiça interior e na paz e alegria espiritual,
necessariamente todos os atos exteriores, que repugnam à justiça, à paz ou à alegria espiritual
repugnam também ao reino de Deus, e portanto devem ser proibidas pelo Evangelho desse reino. O
reino de Deus, ao contrário, não consiste no que é indiferente à vida interior, como, p. ex., comer tais
comidas ou tais outras. Por isso o Apóstolo disse antes:reino de Deus não é comida nem bebida.

RESPOSTA À SEGUNDA. — Segundo o Filósofo, é livre quem é causa de seus atos. Logo, pratica um ato
livremente quem de si mesmo o faz. Ora, o que o homem pratica por um hábito conveniente à sua
natureza, por si mesmo o pratica; porque o hábito inclina ao que é conforme à natureza. Se pois o
hábito fosse repugnante á natureza, o homem não agiria por si mesmo, mas levado por uma corrupção
sobreveniente. Ora, a graça do Espírito Santo é como um hábito interior infuso em nós, que nos inclina a
agir retamente. Logo faz-nos praticar livremente o que convém à graça e evitar o que lhe repugna. —
Assim pois, a lei nova se chama lei da liberdade, em dois sentidos. Primeiro, por não nos obrigar a fazer
nem a evitar nada, senão o em si mesmo necessário, ou contrário à salvação; e isso entra na ordenação
ou na proibição da lei. Em segundo sentido, porque essas ordenações ou proibições ela nos faz cumpri-
las livremente, enquanto as cumprimos por inspiração interna da graça. E por estas duas razões a lei
nova é chamada lei da perfeita liberdade.

RESPOSTA À TERCEIRA. — A lei nova, proibindo os movimentos desordenados da alma, também havia
necessariamente de coibir os atos desordenados das mãos, efeitos dos atos internos.

## Art. 2 — Se a lei nova ordenou suficientemente os atos externos.
O segundo discute-se assim. — Parece que a lei nova ordenou insuficientemente os atos externos.

1. — Pois, parece que à lei nova pertence principalmente a fé que obra por caridade, conforme a
Escritura (Gl 5, 6): Em Jesus Cristo nem a circuncisão vale alguma coisa, nem o prepúcio; mas, a fé que
obra por caridade.Ora, a lei nova explicitou certas verdades de fé, que não estavam explícitas na lei
antiga, como p. ex., a fé na Trindade. Logo, também devia ter acrescentado certas obras morais
externas, não determinadas pela antiga lei.

2. Demais. — A lei antiga instituiu não somente sacramentos, mas também certas coisas sagradas, como
já se disse (q. 101, a. 4; a. 102, a. 4). Ora, na lei nova embora tenha instituído certos sacramentos, não se
vê que tivesse Deus determinado coisas sagradas, como as que respeitam à santificação de um templo,
ou de vasos, ou mesmo relativas à celebração de alguma solenidade. Logo, a lei nova ordenou
insuficientemente as obras externas.

3. Demais. — A antiga lei continha certas observâncias relativas aos ministros de Deus, e também certas
outras relativas ao povo, como já se disse (q. 101, a. 4; q. 102, a. 6), ao tratar dos cerimoniais da lei
antiga. Ora, vemos que a lei nova estabeleceu certas observâncias para os ministros de Deus (Mt 10,
9): Não possuías ouro nem prata, nem tragais dinheiro nas vossas cintas, e o mais que nesse lugar se
segue e ainda em outro (Lc 9; 10). Logo, a lei nova também devia ter instituído outras observâncias,
relativas ao povo fiel.

4. Demais. — Na lei antiga havia, além dos preceitos morais e cerimoniais, certos, judiciais. Ora, a lei
nova não deu nenhum preceito judicial. Logo, ordenou insuficientemente as obras externas.
Mas, em contrário, diz o Senhor (Mt 7, 24): Todo aquele que ouve estas minhas palavras, e as observa,
será comparado ao homem sábio, que edificou a sua casa sobre rocha. Ora, o edificador sábio não omite
nada de necessário ao edifício. Logo, nas palavras de Cristo, está suficientemente estabelecido tudo o
que pertencer à salvação humana.

SOLUÇÃO. — Como já dissemos (a. 1), a lei nova devia ordenar ou proibir só os atos externos, que nos
levam à graça, ou que respeitam necessariamente ao reto uso da mesma. Ora, a graça não podemos
segui-la por nós mesmos, mas só por Cristo. Por onde, os sacramentos, pelos quais conseguimos a graça,
o Senhor, Ele próprio, os instituiu. São eles: o batismo, a eucaristia, a ordem dos ministros da lei nova,
quando instituiu os Apóstolos e os setenta e dois discípulos; a penitência; o matrimonio indissolúvel;
enfim, a confirmação, prometida pela missão do Espírito Santo. Lê-se também no Evangelho, que, por
sua instituição, os Apóstolos curavam os enfermos, ungindo-os com óleo. São esses os sacramentos da
lei nova.
Quanto ao bom uso da graça, ele é obra da caridade. E as obras da caridade, enquanto necessárias à
virtude, pertencem aos preceitos morais, que também a lei antiga estabeleceu. Por onde, neste ponto, a
lei nova não devia acrescentar nada à antiga, quanto a tais obras externas. E quanto à determinação
delas, quando ordenadas ao culto de Deus, ela pertence aos preceitos cerimoniais da lei; quando
ordenadas ao próximo, aos judiciais, como dissemos (q. 99, a. 4). Ora, essas determinações não são em
si mesmas necessárias à graça interior, no que consiste a lei nova. Por onde, não se incluem nos
preceitos desta, mas são deixadas ao arbítrio humano. Delas, umas respeitam os súditos, e são relativas
a cada um em particular; outras, aos superiores temporais ou espirituais, e são relativas à utilidade
comum.
Assim pois a lei nova não devia determinar, ordenado ou proibido, quaisquer obras externas, além dos
sacramentos e preceitos morais, que de si mesmos constituem a essência da virtude. Tais são os
preceitos de não matar, não furtar e outros semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As verdades da fé são superiores à razão humana, e por
isso não podemos alcançá-las sem ser pela graça. Por onde, com graça mais abundante podem-se
explicitar mais verdades da fé. Ao passo que, na prática de atos virtuosos, nós nos dirigimos pela razão
natural, que é uma determinada regra das ações humanas, com já dissemos (q. 19, a. 3; q. 63, a. 2_. E
por isso neste ponto não havia necessidade de se estabelecerem preceitos, além dos da lei moral, que
são ditames da razão.

RESPOSTA À SEGUNDA. — Os sacramentos da lei nova conferem a graça, que não é dada senão por
Cristo; e por isso era necessário dele recebessem a instituição. Ao contrário, as coisas sagradas, como
um templo ou um altar consagrado, ou coisas semelhantes, não conferem nenhuma graça, como
também não a confere a celebração mesma das solenidades. Por onde, como essas coisas, em si
mesmas, não, pertencem à necessidade interna da graça, o Senhor deixou ao arbítrio dos fiéis a
instituição delas.

RESPOSTA À TERCEIRA. — Os preceitos referidos o Senhor deu aos Apóstolos, não como observâncias
cerimoniais, mas como instituições morais. E podem se entender em duplo sentido. — Ou, conforme
Agostinho, como concessões e não, como preceitos. Assim o Senhor concedeu-lhes pudessem exercer o
ofício da pregação sem alforje nem bordão nem coisas semelhantes, por terem como que o poder de
receber o necessário à vida daqueles a quem pregavam; e por isso acrescentou: porque é digno o
trabalhador do seu alimento. Mas também, não peca, antes, faz mais do que deve, quem leva consigo o
de que vive, desempenhando o dever da pregação, sem receber paga daqueles a quem prega o
Evangelho, como fez Paulo. — De outro, pode-se entender, conforme a exposição de outros Santos, que
foram dados aos Apóstolos certos preceitos temporais, no tempo em que foram mandados a pregar o
Evangelho na Judéia, antes da paixão de Cristo. Pois, como que ainda pequenos e vivendo sob a
proteção de Cristo, precisavam os discípulos de receber certas instituições especiais feitas pelo Mestre,
como os súditos as recebem dos seus superiores. E principalmente, porque deviam exercitar-se aos
poucos, para se deixarem do cuidado com as coisas temporais. E assim se tornavam idôneas para pregar
o Evangelho por todo o mundo: Nem é para admirar se, ainda na vigência do regime da lei antiga, e sem
terem os Apóstolos recebido a perfeita liberdade do Espírito, instituiu certos modos determinados de
viver, os quais, nas vésperas da paixão, aboliu, por estarem os discípulos já neles suficientemente
exercitados. Donde o dizer o Evangelho (Lc 22, 35-36): Quando eu vos mandei caminhar sem bolsa e
sem alforje e sem sapatos, faltou-vos porventura alguma coisa? E eles responderam: Nada. Prosseguiu
logo Jesus: Pois agora quem tem bolsa tome-a, e também alforje. Porque já estava iminente o tempo da
perfeita liberdade, em que seriam entregues totalmente ao próprio arbítrio, quanto às coisas que, em si
mesmas, não são necessariamente exigidas pela virtude.

RESPOSTA À QUARTA. — Os preceitos judiciais, em si mesmos considerados, também não concernem
necessariamente à virtude, de um modo determinado; senão só quanto à idéia geral de justiça. Por isso,
a aplicação deles o Senhor a deixou aos diretores dirigir os outros, espiritual ou temporalmente. Ao
passo que fez certas explicações dos preceitos judiciais da lei antiga, por causa da má inteligência dos
Fariseus, como a seguir se dirá (a. 3, ad 2).

## Art. 3 — Se a lei nova ordenou suficientemente os atos internos do homem.
O terceiro discute-se assim. — Parece que a lei ordenou insuficientemente os atos internos do
homem.

1. — Pois, são dez os mandamentos que ordenam o homem para Deus e para o próximo. Ora, o Senhor
deu complemento só a três deles, a saber: sobre a proibição do homicídio, sobre a do adultério, e sobre
a do juramento falso. Logo, ordenou o homem insuficientemente, omitido o complemento aos outros
preceitos.

2. Demais. — O Senhor nada ordenou, no Evangelho, sobre os preceitos judiciais, salvo sobre o repúdio
da esposa, sobre a pena de talião e sobre a perseguição aos inimigos. Ora, há muitos outros preceitos
judiciais na lei antiga, como já se disse (q. 104, a. 4; q. 105). Logo, neste ponto, ordenou
insuficientemente a vida do homem.

3. Demais. — A lei antiga, além dos preceitos morais e judiciais, continha certos outros, cerimoniais,
sobre os quais o Senhor nada ordenou. Logo, ordenou insuficientemente.

4. Demais. — É da boa disposição interna da mente não fazer o homem nenhuma boa obra visando
qualquer fim temporal. Ora, há muitos outros bens temporais que não o aplauso humano; pois, há
muitas outras obras boas além do jejum, da esmola e da oração. Logo, o Senhor ensinou
inconvenientemente quando, só em relação a essas três obras, mandou evitar a glória do aplauso
humano, e nada ensinou sobre os demais bens terrenos.

5. Demais. — É naturalmente ínsito no homem procurar as coisas necessárias à vida, e isso lhe é comum
com os irracionais. Por onde, diz a Escritura (Pr 6, 6-8): Vai ter, ó preguiçoso, com a formiga, e considera
os seus caminhos; a qual, não tendo condutor, nem mestre, faz o seu provimento no estio, e ajunta no
tempo da ceifa de que se sustentar. Ora, todo preceito estabelecido contra a inclinação da natureza é
iníquo, por ser contra a lei natural. Logo, o Senhor proibiu inconvenientemente ao homem a busca do
alimento e do vestuário.

6. Demais. — Não se deve proibir nenhum ato virtuoso. Ora, o juízo é um ato de justiça, conforme a
Escritura (Sl 18, 15): Até que a justiça venha a fazer juízo. Logo, o Senhor proibiu inconvenientemente o
juízo. E portanto, a lei nova ordenou insuficientemente os atos internos.
Mas, em contrário, Agostinho diz: Devemos considerar que, quando o Senhor disse: — Quem ouve estas
minhas palavras — significa com isso suficientemente que o seu sermão contem plenamente todos os
preceitos que regulam a vida cristã.

SOLUÇÃO. — Como resulta do lugar aduzido de Agostinho, o sermão que o Senhor fez na montanha
contém toda a regulamentação da vida cristã, e ordena perfeitamente os atos humanos internos. Pois,
depois de declarar o fim da beatitude e de exaltar a dignidade dos Apóstolos, que deviam divulgar a
doutrina evangélica, ordena os atos humanos internos. Primeiro, os do homem para consigo mesmo;
depois, os relativos ao próximo.
Os atos relativos a nós mesmos, ele os ordena de dois modos, conforme aos nossos dois movimentos
internos, que levam aos atos — a vontade de agir e a intenção final. — Por isso, primeiro ordena a
vontade do homem, pelos diversos preceitos da lei, de modo que se ele abstenha, não só das obras
externas más, em si mesmas, mas também das internas e das ocasiões más. — Depois, ordena a
intenção humana, dizendo que, em nossos atos não devemos buscar nem a glória humana, nem as
riquezas mundanas, o que é entesourar na terra.
Em seguida, ordena o movimento interior do homem relativamente ao próximo. Assim, não devemos
julgá-lo temerária, injusta ou presunçosamente. Nem devemos ser de tal modo negligentes que lhe
entreguemos as coisas sagradas, se forem indignos.
E, por último, ensina o modo de cumprir a doutrina evangélica. Que é implorar o auxílio divino; esforçar-
se por entrar pela porta estreita da virtude perfeita; tomar cautela para não se deixar transviar pelos
sedutores. E faz ver que a observação dos mandamentos é necessária à virtude; não bastante só a
confissão da fé, ou obrar milagres, ou só ouvir a doutrina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Senhor completou só os preceitos da lei dos quais os
Escribas e os Fariseus não tinham inteligência reta. E isto se dava, principalmente, sobre três preceitos
do decálogo. — Assim, quanto à proibição do adultério e do homicídio, pensavam que só era proibido o
ato exterior e não, o desejo interior. E isso pensavam mais no concernente ao adultério e ao homicídio,
do que ao furto e ao falso testemunho. Porque o movimento da ira, tendente ao homicídio, e o da
concupiscência, tendente ao adultério, são considerados como de certo modo inerentes à natureza; isso
não se dá com o desejo de furtar ou de proferir falso testemunho. — Deste tinham falsa inteligência,
pensando que o perjúrio é, por certo, pecado; mas que o juramento deve em si mesmo ser desejado e
repetido, porque, segundo lhes parecia, implica reverência a Deus. Por isso, o Senhor mostrou, que não
devemos desejar, como bom, o juramento, mas é melhor falar sem jurar, salvo se houver necessidade.

RESPOSTA À SEGUNDA. — Sobre os preceitos judiciais os Escribas e os Fariseus erravam de dois modos.
— Primeiro, pensando que eram justos em si mesmos certos preceitos estabelecidos por Moisés, como
permissões. Assim, o repúdio da esposa e receber usuras dos estranhos. Por isso, o Senhor proibiu o
repúdio da mulher (Mt 5, 32) e receber usuras (Lc 6, 35): emprestai sem daí esperardes nada.
De outro modo erravam, pensando que certas práticas que a lei ordenava por justiça, deviam ser feitas
por espírito de vingança, cobiça das coisas temporais ou ódio dos inimigos. E isto em relação a três
preceitos. — Assim, julgavam lícito o desejo da vingança, por causa do preceito sobre a pena de talião;
ora, esse preceito foi dado para se observar à justiça e não para se tirar vingança. E por isso o Senhor,
para evitar a má inteligência dele, ensina que a alma do homem deve estar preparada a sofrer ainda
maiores injúrias, se necessário for. — Pensavam ser lícito a moção da cobiça, por causa dos preceitos
judiciais que ordenavam fosse feita a restituição da coisa furtada, mesmo com algum acréscimo, como
já dissemos (q. 105, a. 2 ad 9). E isso a lei ordenou para fazer observar a justiça e não para dar lugar a
cobiça. Por isso o Senhor ensina que não exijamos nada pela cobiça, mas antes, estejamos prontos a dar
ainda mais se for necessário. — Enfim, tinham como lícito a moção do ódio, por causa do preceito legal
que mandava matar os inimigos; o que a lei instituiu para que se cumprisse a justiça, como já dissemos
(q. 105, a. 3 ad 4), e não para se saciarem os ódios. E, por isso o Senhor ensina a amarmos os inimigos e
estarmos prontos se for necessário, a lhes fazer benefícios. — Assim, no dizer de Agostinho, esses
preceitos visam à preparação da alma.

RESPOSTA À TERCEIRA. — Os preceitos morais deviam absolutamente permanecer na lei nova, pois em
si mesmos se incluem na essência da virtude. Enquanto que os preceitos judiciais não deviam
necessariamente continuar, do modo pelo qual a lei os determinou, mas foram deixados ao arbítrio
humano, que os determinassem de um ou de outro modo. Portanto, o Senhor nos ordenou
convenientemente em relação a esses dois gêneros de preceitos. — Quanto à observação dos preceitos
cerimoniais, ela desapareceu totalmente, com a aplicação da lei nova. Por isso, em relação a esses
preceitos, o Senhor nada ordenou, no seu ensinamento comum. Ensinou porém noutro ponto, que todo
culto material, determinado na lei antiga, devia ser mudado, na vigência da lei nova. Assim, diz (Jo 4, 21-
23): É chegada a hora em que vós não adorareis o Pai, nem neste monte nem em Jerusalém; mas os
verdadeiros adoradores hão de adorar o Pai em espírito e verdade.

RESPOSTA À QUARTA. — Todas as coisas do mundo se reduzem a três: as honras, as riquezas, e os
prazeres, conforme a Escritura (1 Jo 2, 16): Tudo o que há no mundo é concupiscência da carne, que
pertence aos prazeres da carne, e concupiscência dos olhos, que respeita às riquezas, e soberba da
vida, que diz respeito à ambição de glória e honra. Ora, os prazeres supérfluos da carne, a lei não os
prometeu, mas ao contrário, proibiu. Prometeu porém, em troca, uma honra excelsa e a abundância das
riquezas: Se tu ouvires a voz do Senhor teu Deus, Ele te exaltará sobre todas as nações que há na
terra. Isso, quanto à honra. E pouco adiante acrescenta: O Senhor te fará abundante de todos os
bens; quanto às riquezas. Mas essas promessas os judeus as entendiam tão estultamente, que
pensavam se devia servir a Deus por causa delas, como se fossem o fim. — Por onde, para o evitar, o
Senhor mostrou, primeiro, que não devemos praticar obras virtuosas por causa da glória humana. E
ensina serem três as obras a que todas as mais se reduzem. Pois, tudo o que fazemos para refrear as
nossas concupiscências se reduz ao jejum; tudo o que fazemos por amor ao próximo se reduz à esmola;
enfim tudo o que fazemos para o culto de Deus se reduz à oração. E essas três obras ele as considera
especiais, como que sendo as importantes, e pelas quais os homens costumam principalmente buscar a
glória. — Em segundo lugar, ensinou que não devemos por nas riquezas o nosso fim, quando
disse:Não queirais entesourar para vós tesouros na terra.

RESPOSTA À QUINTA. — O Senhor não proibiu os cuidados necessários, mas só os desordenados. Ora,
há quatro cuidados desordenados, que devemos evitar, relativamente aos bens temporais. — Primeiro,
não constituirmos neles o nosso fim; nem servirmos a Deus, por causa das necessidades de comer e
vestir. Por isso diz: Não queirais entesourar para vós, etc. — Segundo, não devemos buscar as coisas
temporais, desesperando do auxílio divino. Por isso o Senhor diz: O vosso Pai sabe que tendes
necessidade de todas elas. — Terceiro, os nossos cuidados não hão de ser presunçosos, de modo a
confiarmos em nós mesmos, pensando que com o nosso próprio esforço, sem o auxílio divino,
poderemos obter o necessário à vida. O que o Senhor nega, dizendo que o homem não pode
acrescentar nada à sua estatura. — Quarto, o homem se inquieta com o tempo das suas necessidades,
preocupando-se, no presente, com o que só respeita ao futuro. E por isso, o Senhor diz: Não andeis
inquietos pelo dia de amanhã.

RESPOSTA À SEXTA. — O senhor não proíbe o juízo da justiça, sem o qual as coisas santas não podem
ser negadas aos indignos; mas, o juízo desordenado, como dissemos.

## Art. 4 — Se a lei nova propôs convenientemente conselhos certos e determinados.
O quarto discute-se assim. — Parece que a lei nova ordenou inconvenientemente conselhos certos e
determinados.

1. — Pois, os conselhos se tomam sobre os meios convenientes à consecução do fim, como já dissemos,
quando tratamos do conselho (q. 14, a. 2). Ora, nem todos servem para todos. Logo, não se devem
propor a todos conselhos certos e determinados.

2. Demais. — Conselhos se tomam sobre o melhor bem. Ora, não há graus determinados do melhor
bem. Logo, não se devem dar conselhos certos e determinados.

3. Demais. — Os conselhos dizem respeito à perfeição da vida. Ora, também a essa perfeição respeita a
obediência. Logo, o Evangelho deixou de dar, inconvenientemente, conselho sobre ela.

4. Demais. — Muito do concernente à perfeição da vida esta incluído nos preceitos. Assim isto (Mt 5,
44):Amai a vossos inimigos, e também os preceitos que o senhor deu aos Apóstolos. Logo, a lei nova deu
conselhos inconvenientemente, quer pelos não ter dado todos, quer pelos não ter distinguido dos
preceitos.
Mas, em contrário. — Os conselhos do amigo sábio são de grande utilidade, conforme a Escritura (Pr 27,
9):Com perfume e variedade de cheiros se deleita o coração, e com os bons conselhos do amigo se
banha a alma em doçura. Ora, Cristo é sábio e amigo por excelência. Logo, os seus conselhos são os de
máxima utilidade e conveniência.

SOLUÇÃO. — A diferença entre o preceito e o conselho está em, o primeiro implicar necessidade ao
passo que o segundo depende da vontade daquele a quem é dado. E por isso, convenientemente, a lei
nova, que é a lei da liberdade, acrescentou aos preceitos os conselhos; o que não o fez a lei antiga, lei da
escravidão. Logo e forçosamente, os preceitos da lei nova devem ser entendidos como relativos ao
necessário à consecução do fim, que é a eterna beatitude, na qual ela nos introduz diretamente. Ao
passo que os conselhos hão de versar sobre aquilo pelo que o homem pode, melhor e mais
expeditamente, conseguir o referido fim.
Ora, o homem está colocado entre os bens deste mundo e os espirituais, nos quais consiste a beatitude
eterna. E de modo que, quanto mais se apega a aqueles, tanto mais se afasta destes, e inversamente.
Por onde, quem se apega totalmente as coisas deste mundo, constituindo nelas o seu fim e
considerando-as como a razão e a regra dos seus atos, aparta-se totalmente dos bens espirituais. Ora,
essa desordem é que os preceitos fazemdesaparecer. Desprezar porém totalmente as coisas do mundo,
não é necessário para o homem alcançar o fim referido. Pois ele pode chegar à beatitude eterna usando
das coisas deste mundo, sem por nelas o seu fim. A este porém chegará mais facilmente, desprezando
totalmente as coisas. Por isso o Evangelho dá conselhos sobre esse ponto.
Ora, os bens deste mundo, que servem ao uso da vida humana, são das três categorias seguintes. As
riquezas dos bens externos, buscadas pela concupiscência dos olhos; os prazeres da carne, pela
concupiscência da carne; e as honras, pela soberba da vida, como se vê na Escritura (1 Jo 2, 16). Ora, é
próprio dos conselhos evangélicos fazer desapegar-nos dessas três espécies de bens, totalmente, na
medida do possível. E nesse tríplice desapego se funda toda a religião, que busca o estado de perfeição.
Assim, as riquezas são desprezadas pela pobreza; os prazeres da carne, pela castidade perpétua; a
soberba da vida, pela submissão da obediência. Mas pelos conselhos propostos, em absoluto, é que
observamos, em si mesmas, essas três disposições de vida. Ao passo que por um conselho particular,
aplicado a um caso dado, observamos cada uma das disposições referidas. Assim, quem dá esmola a um
pobre, sem estar obrigado a isso, segue o conselho, em particular. Também segue o conselho, em
particular, quem em tempo determinado se abstém dos prazeres da carne, para se vacar a oração.
Semelhantemente, quem não cede à sua vontade, num caso particular, em que podia fazê-lo
licitamente, segue em tal caso o conselho. Assim quando, sem estar obrigado, beneficia aos seus
inimigos; ou quando perdoa a ofensa de quem podia justamente vingar-se. Assim todos os conselhos
particulares se reduzem aos três conselhos gerais e perfeitos supra-referidos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os conselhos referidos, em si mesmos, são aplicáveis a
todos. Mas pode se dar não o sejam a alguém, sem disposição para eles, por não ter o afeto para os
mesmos inclinado. Por isso o Senhor, quando propõe os conselhos evangélicos, sempre faz menção da
inclinação do homem a observá-los. Assim ao dar conselho da pobreza perpétua, diz antes (Mt 19,
21): Se queres ser perfeito; acrescentando depois: vai e vende o que tens. Semelhantemente, ao dar o
conselho da castidade perpétua, diz (Mt 19, 12): Há uns castrados, que a si mesmos se castraram por
amor do reino dos céus; mas logo acrescenta: O que é capaz de compreender isto compreenda-o. Do
mesmo modo o Apóstolo, tendo dado o conselho da virgindade, diz (1 Cor 7, 35): Digo-vos isto para
proveito vosso; não para vos ilaquear.

RESPOSTA À SEGUNDA. — Os bens melhores, particulares, são indeterminados, em cada caso dado.
Mas os que o são em geral, simples e absolutamente falando, são determinados. Ora, a esses se
reduzem todos os bens particulares referidos, como já se disse.

RESPOSTA À TERCEIRA. — Entende-se que o Senhor também deu o conselho de obediência quando
disse: E siga-me. E nós o seguimos, não só imitando-lhe as obras, mas também obedecendo-lhe aos
mandamentos, conforme aquilo (Jo 10, 27): As minhas ovelhas ouvem a minha voz; e eu conheço-as e
elas me seguem.

RESPOSTA À QUARTA. — O que o Senhor disse sobre o verdadeiro amor aos inimigos e disposições
semelhantes, se se referirem à preparação da alma, é necessário para a salvação. E então o homem
deve estar preparado a fazer bem aos inimigos e a agir sempre nesse sentido, quando a necessidade o
exigir. Por isso estabeleceram-se preceitos para o regular. Mas é apenas por um conselho particular,
como já dissemos, que estaremos preparados a fazê-lo, pronta e atualmente, aos inimigos, quando não
ocorrer especial necessidade. E quanto aos preceitos que se lêem noutro lugar do Evangelho, eles
constituíam disciplinas próprias do tempo, ou são certas concessões, como dissemos (q. 2, ad 3). Por
isso não são dados como conselhos.
Tratado da Graça