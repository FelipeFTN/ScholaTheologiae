# Questão 100: Dos preceitos morais da lei antiga.
Em seguida devemos tratar de cada um dos gêneros dos preceitos da lei antiga. E primeiro, dos
preceitos morais. Segundo, dos cerimoniais. Terceiro, dos judiciais.
Na primeira questão discutem-se doze artigos:

## Art. 1 — Se todos os preceitos morais pertencem à lei da natureza.
(Infra, q. 104, a. 1).
O primeiro discute-se assim. — Parece que nem todos os preceitos morais pertencem à lei da
natureza.

1. — Pois, diz a Escritura (Sr 17, 9): acrescentou-lhes a disciplina, e deu-lhes em herança a lei da vida.
Ora, a disciplina se divide, por oposição, da lei da natureza; porque a lei natural não se aprende, mas se
tem por instinto natural. Logo, nem todos os preceitos morais pertencem à lei da natureza.

2. Demais. — A lei divina é mais perfeita que a humana. Ora, esta faz, aos preceitos da lei da natureza,
certos acréscimos relativos aos bons costumes. E isso é claro por ser a lei da natureza a mesma para
todos, ao passo que essas instituições morais variam com os diversos povos. Logo, com muito maior
razão, a lei divina devia acrescentar à lei da natureza certos preceitos relativos aos bons costumes.

3. Demais. — Assim como a razão natural produz bons costumes, assim também a fé; donde o dizer a
Escritura (Gl 5, 6): a fé obra por caridade. Ora, a fé não está contida na lei da natureza, porque as suas
verdades são superiores à razão natural. Logo, nem todos os preceitos morais da lei divina pertencem à
lei da natureza.
Mas, em contrário, diz o Apóstolo (Rm 2, 14): os gentios, que não têm lei, fazem naturalmente as coisas
que são da lei. O que se deve entender como referente ao que respeita aos bons costumes. Logo, todos
os preceitos morais da lei pertencem à lei da natureza.

SOLUÇÃO. — Os preceitos morais são distintos dos cerimoniais e dos judiciais. Pois, os morais respeitam
ao que, em si mesmo, pertence aos bons costumes. Ora, como os costumes humanos se consideram em
relação à razão, que é o princípio próprio dos atos humanos, chamam-se bons os costumes congruentes
com a razão, e maus, os que dela se afastam. Ora, assim como todo juízo da razão especulativa procede
do conhecimento natural dos primeiros princípios, assim também todo juízo da razão prática procede de
certos princípios naturalmente conhecidos, conforme já dissemos (q. 94, a. 2, a. 4). Donde podemos
proceder diversamente para julgar coisas diversas. Pois, há certos atos humanos de tal modo explícitos,
que, com pouca reflexão, podem logo ser aprovados ou reprovados, tendo-se em vista esses princípios
comuns e primeiros. Outros há porém, para cuja apreciação é preciso refletir aturadamente nas diversas
circunstâncias, que podem ser consideradas diligentemente só pelo homem prudente, e não por
qualquer pessoa. Assim como, considerar as conclusões particulares das ciências não pertence a todos,
mas só aos filósofos. Outros há enfim que, para julgá-las, o homem precisa ser ajudado pela instrução
divina, como é o caso do que pertence à fé.
Por onde é claro que, dizendo respeito os preceitos morais aos bons costumes e estes sendo os que
estão de acordo com a razão; e todo juízo da razão humana derivando, de certo modo, da razão natural,
necessariamente todos os preceitos morais hão de pertencer à lei da natureza, mas diversamente. —
Assim, há certos de que a razão natural de qualquer homem pode logo julgar, que devem ser
obedecidos. Tais são: honrarás a teu pai e a tua mãe; e não matarás, não furtarás. E estes pertencem
absolutamente à lei da natureza. — Há porém outros que são tidos, pelos homens prudentes, e em
virtude de uma consideração mais subtil da razão, como devendo ser observados. E estes pertencem à
lei natural, mas precisam de uma certa doutrina pela qual os prudentes ensinem os que não o são. Tal
aquilo da Escritura: Levanta-te diante dos que têm a cabeça cheia de cãs e honra a pessoa do velho; e
outros semelhantes. — Há outros enfim, para julgar dos quais a razão humana precisa da instrução
divina, que nos ensina sobre as coisas divinas. Tais aqueles:não farás para ti imagem de escultura, nem
figura alguma; não tomarás o nome do Senhor teu Deus em vão.
Donde se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 2 — Se os preceitos morais da lei abrangem todos os atos virtuosos.
(IIª-IIae, q. CXL., a. 2).
O segundo discute-se assim. — Parece que os preceitos morais da lei não abrangem todos os atos
virtuosos.

1. — Pois, à observância dos preceitos da lei antiga se chama justificação, conforme aquilo da Escritura
(Sl 118, 8): observarei as tuas justificações. Ora, a justificação é a execução da justiça. Logo, os preceitos
morais não abrangem senão os atos de justiça.

2. Demais. — O que cai sob a alçada de um preceito tem natureza de obrigação. Ora, a noção de
obrigação não inclui as demais virtudes, senão só a justiça, cujo ato próprio é dar a cada um o que lhe é
devido. Logo, os preceitos da lei moral não abrangem os atos das outras virtudes, mas só os da justiça.

3. Demais. — Toda lei é estabelecida para o bem comum, como diz Isidoro. Ora, dentre as virtudes, só a
justiça visa o bem comum, conforme diz o Filósofo. Logo, os preceitos morais abrangem só os atos de
justiça.
Mas, em contrário, diz Ambrósio: o pecado é a transgressão da lei divina e a desobediência aos
mandamentos celestes. Ora, os pecados contrariam todos os atos virtuosos. Logo, a lei divina deve
ordenar sobre os atos de todas as virtudes.

SOLUÇÃO. — Ordenando-se os preceitos da lei para o bem comum, como já se disse (q. 90, a. 2), eles
hão de forçosamente diversificar-se conforme as diversas maneiras de ser da comunidade. Por isso, o
Filósofo ensina, que umas serão as lei estabelecidas para a cidade governada por um rei, e outras as
estabelecidas para a que é governada pelo povo ou pelos mais poderosos, dos habitantes dela. Ora, um
é o feitio da comunidade, para que se ordena a lei humana, e outro, para que se ordena a lei divina. —
Pois, a lei humana se ordena à comunidade civil, a constituída pelos homens entre si; e estes se
ordenam uns para os outros pelos seus atos exteriores, com que se entre comunicam. E essa
comunicação pertence essencialmente à justiça, que é propriamente diretiva da comunidade humana.
Por onde, a lei humana só propõe preceitos referentes aos atos de justiça; e se ordenar outros atos de
virtude, não será senão enquanto se revestem da essência da justiça, como está claro no Filósofo.
A comunidade porém, a que se ordena a lei divina, é a dos homens enquanto tendem para Deus, na vida
presente ou na futura. Por isso, essa lei propõe preceitos sobre todos os atos pelos quais os homens
bem se ordenam à comunicação com Deus. Ora, o homem se une a Deus pela razão, ou espírito, que
reproduz a imagem d’Êle. Por onde, a lei divina propõe preceitos sobre todos os atos pelos quais bem
ordenada fica a razão do homem. Ora, isto se dá pelos atos de todas as virtudes. Assim, as virtudes
intelectuais ordenam com acerto os atos da razão em si mesmos; as morais, por seu lado, impõem
ordem aos atos da razão relativamente às paixões internas e as obras externas. Por onde é manifesto,
que a lei divina propõe convenientemente preceitos sobre os atos de todas as virtudes. De modo porém
que certos atos, sem os quais a ordem da virtude, que é a da razão, não pode ser observada, são
impostos pela obrigação de preceitos; e outros, relativos à existência completa da virtude perfeita,
pertencem à advertência do conselho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O cumprir os mandamentos da lei, mesmo os que
pertencem aos atos das outras virtudes, implica a idéia de justificação. Enquanto é justo o homem
obedecer a Deus; ou ainda enquanto é justo que todo o humano esteja sujeito à razão.

DONDE A RESPOSTA À SEGUNDA. — A justiça propriamente dita implica a dívida de um homem para
com outro; ao passo que todas as outras virtudes implicam o débito das faculdades inferiores para com
as superiores. E, conforme a natureza desse débito, o Filósofo distingue uma certa justiça metafórica.

RESPOSTA À TERCEIRA. — A resposta se deduz clara do que dissemos sobre as diversas comunidades.

## Art. 3 — Se todos os preceitos morais da lei antiga reduzem-se aos dez preceitos do decálogo.
(Infra. A. 2; IIª-IIae, q. 122, a. 6, ad. 2; III Sent., dist. XXXVII, a. 3; De Malo, q. 14, a. 2, ad 14; Quodl. VII, q.
7, a. 1, ad 8).
O terceiro discute-se assim. — Parece que nem todos os preceitos morais da lei antiga se reduzem aos
dez preceitos do decálogo.

1. — Pois, os primeiros e principais preceitos da lei são: Amarás o Senhor teu Deus e amarás o teu
próximo, como está na Escritura (Mt 22, 37-39). Ora, estes dois preceitos não fazem parte dos do
decálogo. Logo, nem todos os preceitos morais estão contidos nos do decálogo.

2. Demais. — Os preceitos morais não se reduzem aos cerimoniais, mas antes, inversamente. Ora, entre
os preceitos do decálogo, um é cerimonial, a saber: Lembra-te de santificar o dia de sábado. Logo, os
preceitos morais não se reduzem a todos os do decálogo.

3. Demais. — Os preceitos morais regulam todos os atos da virtude. Ora, os do decálogo abrangem só os
atos de justiça, como claramente verá quem examinar cada um deles. Logo, os preceitos do decálogo
não contêm todos os preceitos morais.
Mas, em contrário, aquilo da Escritura. — Bem aventurados sois quando vos injuriarem — diz a Glosa,
que Moisés, depois de ter proposto os dez preceitos, explicou-os por partes. Logo, todos os preceitos da
lei fazem parte dos preceitos do decálogo.

SOLUÇÃO. — Os preceitos do decálogo diferem dos outros preceitos da lei, por, como está dito, terem
sido propostos por Deus mesmo ao povo; ao passo que os outros Ele os propôs por meio de Moisés. Por
onde, pertencem aos preceitos do decálogo aqueles cujo conhecimento o homem tem, por si mesmo,
de Deus. Ora, estes são os que, com pouca reflexão, podem ser logo conhecidos, como o auxílio dos
primeiros princípios comuns; e os que também se tornam logo conhecidos pela fé divinamente infusa.
Logo, entre os preceitos do decálogo não se contam dois gêneros de preceitos. Os primeiros e comuns,
como — a ninguém se deve fazer mal, e outros semelhantes — que não precisam de nenhuma
transmissão, mas, quase evidentes, estão escritos na razão natural. Nem os que a perquirição diligente
dos prudentes considera como pertencentes à razão; pois, esses Deus os transmitiu ao povo, mediante
o ensinamento dos prudentes. Ora, ambos estes gêneros de preceitos estão contidos nos do decálogo,
mas diversamente. Os primeiros e comuns neles estão contidos como os princípios, nas conclusões
próximas; e os conhecidos por meio dos prudentes, inversamente, como as conclusões, nos princípios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os dois preceitos referidos são preceitos primeiros e
comuns da lei da natureza, quase evidentes à razão humana, pela natureza ou pela fé. Por onde, todos
os preceitos do decálogo se referem a esses dois, como conclusões, aos princípios comuns.

RESPOSTA À SEGUNDA. — O preceito sobre a observância do sábado é, de certo modo, moral; pois
preceitua que o homem, em algum tempo, se entregue às coisas de Deus, conforme aquilo da Escritura
(Sl 45, 11):Cessai e vede que eu sou o Deus. E assim se contam entre os preceitos do decálogo. Não
porém quanto à determinação do tempo; porque, por aí, é cerimonial.

RESPOSTA À TERCEIRA. — A noção de dívida é, nas outras virtudes, mais lata que na justiça. E assim, os
preceitos referentes aos atos das outras virtudes não são conhecidos do povo como os preceitos sobre
os atos de justiça. E por isso os atos de justiça caem especialmente sob a alçada dos preceitos do
decálogo, que são os primeiros elementos da lei.

## Art. 4 — Se os preceitos do decálogo se distinguem convenientemente.
O quarto discute-se assim. — Parece que os preceitos do decálogo se distinguem
inconvenientemente.

1. — Pois, a latria é uma virtude distinta da fé. Ora, os preceitos são dados para regular os atos de
virtude. E o que se diz no princípio do decálogo — Não terás deuses estrangeiros diante de mim —
pertence à fé; o que se acrescenta — não farás para ti imagem de escultura, etc. — à latria. Logo, há
duas sortes de preceitos, e não uma só, como diz Agostinho.

2. Demais. — Os preceitos afirmativos da lei, como — Honrarás a teu pai e a tua mãe — distinguem-se
dos negativos, como — Não matarás. Ora, o preceito — Eu sou o Senhor teu Deus — é afirmativo; e o
que se lhe acrescenta — Não terás deuses estrangeiros diante de ti — é negativo. Logo, há duas
espécies de preceitos, e não uma só, como quer Agostinho.

3. Demais. — O Apóstolo diz (Rm 7, 7): eu não conheceria a concupiscência, se a lei não dissera — não
cobiçaras. E, por aí se vê que o preceito — não cobiçarás — é um só. Logo, não devia dividir-se em dois.
Mas, em contrário, é a autoridade de Agostinho, ensinando que três são os preceitos relativos a Deus, e
sete, ao próximo.

SOLUÇÃO. — Os preceitos do decálogo diversos os distinguem diversamente. Assim, Hesíquio,
comentando o lugar — dez mulheres cozam pães num só forno — diz que o preceito sobre a observação
do sábado não é um dos dez, porque não deve ser observado literalmente, em todo tempo. Distingue
contudo quatro preceitos relativos a Deus. O primeiro é — Eu sou o Senhor teu Deus — o segundo —
Não terás deuses estrangeiros diante de mim; e Jerônimo também distingue estes dois, comentando
Oseas (Os 10, 10), por causa das suas duas iniqüidades; o terceiro preceito diz que é: não farás para ti
imagem de escultura; o quarto, enfim: não tomarás o nome do Senhor teu Deus em vão. Os relativos ao
próximo diz serem seis. O primeiro: Honrarás a teu pai e a tua mãe; o segundo: Não matarás; o
terceiro: Não fornicarás; o quarto: não furtarás; o quinto:não dirás falso testemunho; o sexto: não
cobiçarás.
Mas, é inadmissível, que o preceito sobre a observação do sábado seja posto entre os do decálogo, se
de nenhum modo faz parte deles. Em segundo lugar, o dito — Ninguém pode servir a dois Senhores —
parece ter a mesma razão e cair sob a alçada desses mesmos preceitos — Eu sou o Senhor teu Deus,
e, Não terás deuses estrangeiros. E por isso Orígenes, distinguindo também quatro preceitos relativos a
Deus, considera esses dois supra-referidos como um só; considera como segundo: não farás para ti
imagem de escultura;como terceiro: não tomarás o nome do Senhor teu Deus em vão; e como
quarto: lembra-te de santificar o dia de sábado. Quanto aos outros seis, ele os considera como Hesíquio.
Mas, como fazer imagem de escultura, ou semelhança, não é proibido senão para que não seja adorada
como Deus, pois, no tabernáculo, Deus mandou fazer a imagem de um serafim, como se lê na Escritura
(Ex 25, 18), por isso, Agostinho, mais convenientemente, considera um só preceito — Não terás deuses
estrangeiros — e — Não farás imagem de escultura. Semelhantemente, desejar relação com mulher
alheia é manifestação da concupiscência da carne. Ao passo que a cobiça das outras coisas, que se
desejam possuir, pertence à concupiscência dos olhos. Por onde, o mesmo Agostinho considera como
dois preceitos: não cobiçar a casa alheia e a mulher alheia. E assim, considera três preceitos como
relativos a Deus, e sete, ao próximo. E esta opinião é melhor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A latria não é mais que uma protestação de fé. Por isso,
não se deviam estabelecer uns preceitos sobre a latria e outros, sobre a fé. Mas, antes, deviam se
estabelecer alguns referentes à latria, que, à fé. Porque, o preceito sobre a fé é um pressuposto aos do
decálogo, bem como o preceito do amor. Pois, assim como os primeiros preceitos comuns da lei da
natureza são evidentes para quem tem a razão natural, e não precisam de promulgação; assim também
o de crer em Deus é, em si e primariamente, conhecido a quem tem fé; porquanto, diz a Escritura, é
necessário que o que se chega a Deus creia que há Deus. Por isso não precisa de nenhuma promulgação,
senão da infusão da fé.

RESPOSTA À SEGUNDA. — Os preceitos afirmativos se distinguem dos negativos, quando um não está
compreendido no outro. Assim, honrar os pais não inclui que não se mate ninguém, nem inversamente.
Mas, quando o afirmativo está compreendido no negativo, ou inversamente, não se constituem
preceitos diversos. Assim, — não furtarás — não constitui preceito diverso de — conservar a coisa
alheia, ou, restituí-la. E por isto, crer em Deus e não crer em deuses alheios não são preceitos diversos.

RESPOSTA À TERCEIRA. — Toda a concupiscência convém numa mesma razão; e por isso o Apóstolo se
refere, singularmente, ao mandamento relativo à concupiscência. Como, porém, há razões diversas
especiais de cobiçar, Agostinho distingue diversos preceitos relativos à repressão daconcupiscência.
Pois, as espécies dela diferem segundo a diversidade das ações ou dos concupiscíveis, como diz o
Filósofo.

## Art. 5 — Se os preceitos do decálogo estão convenientemente enumerados.
(III Sent., dist. XXXVII, a. 2, qª 2; III Cont., Gent., cap. CXX, CXXVIII; De Virtut., q. 2, a. 7, ad 10; Ad Rom.,
cap. XIII, lect. II).
O quinto discute-se assim. — Parece que os preceitos do decálogo estão inconvenientemente
enumerados.

1. — Pois, o pecado, como diz Ambrósio é a transgressão da Lei divina e a desobediência aos
mandamentos do céu. Ora, os pecados se distinguem por pecar o homem contra Deus, contra o
próximo, ou contra si mesmo. Entre os preceitos do decálogo porém, não há nenhum que ordene o
homem para si mesmo, mas só há os que o ordenam para Deus e o próximo. Logo, é insuficiente a
enumeração dos preceitos do decálogo.

2. Demais. — Assim como ao culto de Deus pertencia à observância do sábado, assim também lhe
pertencia à observância das outras solenidades e a imolação dos sacrifícios. Ora, entre os preceitos do
decálogo, há um pertencente à observância do sábado. Logo, também devia haver outros pertencentes
às outras solenidades e ao rito dos sacrifícios.

3. Demais. — Contra Deus pode-se pecar, tanto perjurando, como blasfemando ou, de qualquer modo,
mentindo contra a divina doutrina. Ora, foi estabelecido um preceito proibindo o perjúrio, quando se
disse: não tomarás o nome do Senhor teu Deus em vão. Logo, os pecados de blasfêmia e de falsa
doutrina deviam ter sido proibidos por algum outro preceito.

4. Demais. — O homem tem amor natural tanto para com os pais como para com os filhos. Demais
disso, o mandamento da caridade se estende a todos os próximos. Ora, os preceitos do decálogo se
ordenam para a caridade, conforme àquilo da Escritura (1 Tm 1, 5): o fim do preceito é a caridade. Logo,
assim como foi feito um preceito relativo aos pais, assim também deveriam ter sido feitos outros
relativos aos filhos e aos demais próximos.

5. Demais. — Em qualquer gênero de pecados podemos pecar pelo desejo ou por obras. Ora em certos
gêneros de pecados, como o do furto e do adultério, proíbe-se o pecado por obra, quando se diz — Não
fornicarás, não furtarás, separadamente do pecado de desejo, quando se diz — Não cobiçarás os bens
do teu próximo, e não cobiçarás a mulher do teu próximo. Logo, o mesmo se deveria ter feito em
relação aos pecados do homicídio e de falso testemunho.

6. Demais. — O pecado tanto pode provir da desordem do concupiscível como da do irascível. Ora,
certos preceitos proíbem a concupiscência desordenada, como o que diz — não cobiçarás. Logo, o
decálogo também devia conter certos outros proibitivos da desordem do irascível. Logo, parece que os
dez preceitos do decálogo não estão convenientemente enumerados.
Mas, em contrário, diz a Escritura (Dt 4, 13): Ele vos mostrou o seu pacto, que ordenou que
observásseis, e as dez palavras que escreveu em duas tábuas de pedra.

SOLUÇÃO. — Como já se disse (a. 2), assim como os preceitos da lei humana ordenam o homem para
uma certa comunidade humana, assim os da lei divina, para uma certa comunidade ou república dos
homens sob a direção de Deus. Ora, para que alguém possa fazer parte de uma comunidade, duas
condições se exigem. A primeira é comportar-se devidamente para com o chefe da comunidade; a
segunda, comportar-se devidamente para com os outros companheiros e co-participes dessa
comunidade. Logo, era necessário que, na lei divina, se estabelecessem, primeiro, certos preceitos que
ordenassem o homem para Deus; e, segundo, outros que o ordenassem para os próximos com quem
convive simultaneamente, sob a direção de Deus.
Ora, para com o chefe da comunidade o homem tem três obrigações: primeiro, a fidelidade; segundo, a
reverência; terceiro, o famulado. — A fidelidade para com o senhor consiste em não deferir a outro a
honra do principado. E é isto que visa o primeiro preceito, quando diz: não terás deuses estrangeiros. —
Em segundo lugar, a reverência para com o senhor exige que não se lhe faça nada de injurioso. E isto
visa o segundo preceito, quando diz: não tomarás o nome do Senhor teu Deus em vão. — Por fim, o
famulado é devido ao senhor em recompensa dos benefícios que dele recebem os súbditos. E isto visa o
terceiro preceito, sobre a santificação do sábado, em memória da criação das coisas.
Quanto aos próximos, para com eles procedemos devidamente, em especial e em geral. — Em especial,
pagando o débito aos a quem devemos. E isto visa o preceito de honrar os pais. — Em geral, em relação
a todos, não causando dano a ninguém, nem por obras, nem por palavras, nem por intenção. — Pois,
por obra causamos dano ao próximo, ora atingindo-lhe a existência pessoal; o que é proibido pelo
mandamento que diz — não matarás. Ora, atingindo uma pessoa que lhe é conjunta, para a propagação
da prole, o que proíbe o preceito quando diz: não fornicarás. Outras vezes, causamos-lhe dano no bem
que ele possui, que se ordena para uma e outra coisa; e isto visa quando diz: não furtarás. — Causar
dano por palavras é proibido quando se diz: não dirás falso testemunho contra o teu próximo. — Por
fim, o dano por intenção e proibido quando se diz: não cobiçarás
Ora, de acordo com esta diferença, podem-se distinguir três preceitos, que ordenam para Deus. Dos
quais o primeiro respeita a obra, e por isso diz: não farás imagem de escultura. O segundo, à palavra,
quando diz: não tomarás o nome do Senhor teu Deu; em vão. O terceiro, à intenção; porque na
santificação do sábado, enquanto preceito moral, se preceitua o descanso do coração em Deus. — Ou,
segundo Agostinho, pelo primeiro preceito reverenciamos a unidade do primeiro princípio; pelo
segundo, a verdade divina; pelo terceiro, a sua bondade, pela qual nos santificamos, e na qual
descansamos, como no fim.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Podemos dar dupla resposta. — A primeira é que os
preceitos do decálogo se referem ao mandamento do amor. Pois, era necessário dar ao homem um
preceito sobre o amor de Deus e do próximo, porque, neste ponto, a lei natural ficou obscurecida pelo
pecado. Mas, não era necessário preceituar sobre o amor de si mesmo, por que neste ponto, vigorava a
lei natural. Ou porque o amor de si mesmo se inclui no de Deus e do próximo; pois, o homem
verdadeiramente se ama a si mesmo, ordenando-se para Deus. Por isso, os preceitos do decálogo só se
referem ao próximo e a Deus.
De outro modo, podemos dizer, que os preceitos do decálogo são os que o povo imediatamente
recebeu de Deus. Por isso, diz a Escritura (Dt 10, 4): Escreveu em tábuas o que antes tinha escrito, as dez
palavras que o Senhor vos tinha falado. Por onde, era necessário fossem esses preceitos tais que
pudessem logo entrar na mente do povo, pois, um preceito tem natureza de obrigação devida. Ora, que
o homem, necessariamente tem deveres para com Deus e o próximo, é facilmente compreensível para
qualquer e, principalmente, para um fiel. Mas não é facilmente compreensível que, pelo que a si mesmo
lhe pertence, e não a outrem, um homem tenha necessariamente algum dever para com outro. Pois,
parece, ao primeiro aspecto, que cada um é livre quanto ao que lhe pertence. Por isso, os preceitos, que
proíbem as desordens do homem para consigo mesmo, chegaram ao povo mediante a instrução dos
prudentes. Donde o não pertencerem ao decálogo.

RESPOSTA À SEGUNDA. — Todas as solenidades da lei antiga foram instituídas em comemoração de
algum benefício divino, ou já realizado no passado, ou prefigurado, para o futuro. E semelhantemente,
todos os sacrifícios eram oferecidos por isso. Ora, entre todos os benefícios de Deus a serem
comemorados, o primeiro e o principal é o da criação, comemorado na santificação do sábado. Por
onde, a Escritura, como razão deste preceito, diz (Ex 20, 11): Porque o Senhor fez em seis dias o céu e a
terra etc. Quanto a todos os benefícios futuros, que deviam ser prefigurados, o principal e final era o
repouso da mente em Deus, no presente, pela graça, ou, no futuro, pela glória, o que também estava
figurado na observância do sábado. Por isso, diz a Escritura (Is 58, 13): Se apartares do sábado o teu pé,
o fazer a tua vontade no meu santo dia, e chamares ao sábado delicado e santo para glória do Senhor.
Pois, estes benefícios estão, primeira e principalmente, na mente dos homens, sobretudo, fiéis. Quanto
às outras solenidades, eram celebradas por causa de alguns benefícios temporais passageiros; como a
celebração da Páscoa, por causa do benefício da passada libertação, do Egito, e por causa da paixão
futura de Cristo, realizada no tempo, e que nos conduz ao repouso do sábado espiritual. Por onde,
preteridas todas as outras solenidades e sacrifícios, só do sábado se faz menção nos preceitos do
decálogo.

RESPOSTA À TERCEIRA. — Como diz o Apóstolo (Heb 6, 16), os homens juram pelo que há maior que
eles, e o juramento é a maior segurança para terminar todas as suas contendas. Por onde, sendo o jura-
mento comum a todos, a desordem em relação a ele é especialmente proibida por um preceito do
decálogo. O pecado porém de falsa doutrina não é senão de poucos; por isso, não era necessário fazer
menção disso entre os preceitos do decálogo. Embora, segundo um modo de entender, o preceito —
não tomarás o nome do Senhor teu Deus em vão — proíba a falsidade da doutrina; pois, uma Glosa
expõe: não dirás que Cristo é uma criatura.

RESPOSTA À QUARTA. — A razão natural logo dita ao homem que a ninguém faça injúria; e por isso, os
preceitos que proíbem o dano estendem-se a todos. A razão natural, porém, não dita imediatamente
que se deva fazer alguma coisa em benefício de outrem, senão para com quem se tenha algum dever.
Ora, os deveres do filho para com o pai são tão manifestos a ponto de não poderem ser negados por
nenhuma tergiversação. Porque o pai é o principio da geração e do ser e, além disso, da educação e da
instrução. Por isso, não está entre os preceitos do decálogo, que devamos prestar algum benefício ou
obséquio a alguém, salvo aos pais. Os pais porém não são considerados como devedores aos filhos, por
quaisquer benefícios que deles houvessem recebido, mas, ao contrário. Pois, o filho é algo do pai,
e os pais amam os filhos como algo deles,segundo diz o Filósofo. Por onde, pelas mesmas razões, não se
estabeleceram nenhuns preceitos, no decálogo, relativos ao amor dos filhos, como também nenhuns,
que ordenassem o homem para si mesmo.

RESPOSTA À QUINTA. — O prazer do adultério e a utilidade das riquezas são desejáveis por si mesmos,
enquanto têm a natureza de bem deleitável ou útil. E por isso os preceitos haviam necessariamente de
proibir, não só a obra, mas também, a concupiscência. Ao contrário, o homicídio e a falsidade são em si
mesmos horríveis; pois, o próximo e a verdade são naturalmente amados e não são desejados senão por
causa de outra coisa. Por onde, não era necessário, quanto aos pecados de homicídio e de falso
testemunho, proibir o pecado de intenção, mas, só o de obra.

RESPOSTA À SEXTA. — Como já se disse (q. 25, a. 1), todas as paixões do irascível derivam das do
concupiscível. Por isso, nos preceitos do decálogo, que são quase os primeiros elementos da lei, não se
deviam mencionar as paixões do irascível, mas, só as do concupiscível.

## Art. 6 — Se os dez preceitos do decálogo estão convenientemente ordenados.
(IIª-IIae, q. 122, a. 2, sqq; III Sent., dist. XXXVII, a. 2, qª 3).
O sexto discute-se assim. — Parece que os dez preceitos do decálogo estão inconvenientemente
ordenados.

1. — Pois, a dileção do próximo é a que conduz para a de Deus, porque o próximo nos é mais conhecido
que Deus, conforme a Escritura (1 Jo 4, 20): aquele que não ama a seu irmão, a quem vê, como pode
amar a Deus, a quem não vê? Ora, os três primeiros preceitos pertencem ao amor de Deus; e os sete
outros, ao do próximo, Logo, os preceitos do decálogo estão inconvenientemente ordenados.

2. Demais. — Os preceitos afirmativos ordenam atos de virtude; os negativos, proíbem os do vício. Ora,
segundo Boécio, hão-se, primeiro, de extirpar os vícios, que semear as virtudes. Logo, entre os preceitos
pertencentes ao próximo, era mister estabelecerem-se os negativos antes dos afirmativos.

3. Demais. — Os preceitos da lei são feitos para dirigir os atos dos homens. Ora, o ato do coração é
anterior ao da palavra e ao da obra externa. Logo, os preceitos, que proíbem a concupiscência e que
respeitam o coração, estão inconvenientemente postos em último lugar.
Mas, em contrário, o Apóstolo diz (Rm 13, 1): as coisas que vêem de Deus são ordenadas. Ora, os
preceitos do decálogo foram imediatamente dados por Deus, como já se disse (a. 3). Logo, estão
convenientemente ordenados.

SOLUÇÃO. — Como já se estabeleceu (a. 3; a. 5 ad 1), os preceitos do decálogo versam sobre o que de
pronto a razão do homem compreende. Ora, é manifesto que a razão apreende tanto mais facilmente
um objeto, quanto mais o contrário deste lhe é grave e repugnante a ela. E claro porém que a ordem da
razão, começando pelo fim, vai sobretudo contra ela o proceder o homem desordenadamente, em
relação ao fim. Ora, o fim da vida humana e da sociedade é Deus. Por onde, era primeiramente
necessário, pelos preceitos do decálogo, ordenar o homem para Deus, por ser gravíssimo o que a isto
contraria. Assim também, num exército, ordenado para o chefe como para o fim, primeiro hão de os
soldados estar sujeitos ao chefe, sendo o contrário gravíssimo; em segundo lugar, hão-se de coordenar
entre si.
Ora, entre os meios pelos quais o homem se ordena para Deus, ocorre em primeiro lugar submeter-se
fielmente, sem lhe ter nenhuma participação com os inimigos. Em segundo lugar, há de prestar-lhe
reverência. Em terceiro, há de lhe servir pelo famulado. Assim também, num exército, maior falta
dosoldado é agir infielmente, tendo inteligência com o inimigo, do que fazer qualquer irreverência ao
chefe; e isto é ainda mais grave do que deixar de prestar qualquer serviço ao chefe.
Quanto aos preceitos, que ordenam para o próximo, é manifesto que mais repugna à razão e é mais
grave pecado o homem não conservar a ordem devida para com as pessoas a quem mais deve. Por isso,
entre os preceitos que ordenam para o próximo, vem em primeiro lugar o que respeita aos pais. E, entre
os outros preceitos, também a ordem se funda na da gravidade dos pecados. Assim, é mais grave e mais
repugnante à razão pecar por obra, que por palavra; e por palavra, do que por intenção. E, entre os
pecados por obra, é mais grave o homicídio, que priva da vida, do que o adultério, que torna incerta a
prole nascitura. E o adultério é mais grave que o furto, relativo aos bens exteriores.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora, por via dos sentidos, o próximo seja mais
conhecido que Deus, contudo, o amor de Deus é a razão do amor do próximo, como a seguir ficará claro
(IIa IIae, q. 25, a. 1; IIa IIae, q. 26, a. 2). Por isso é que se estabeleceram, em primeiro lugar, os preceitos
que ordenam para Deus.

RESPOSTA À SEGUNDA. — Assim como Deus é a causa universal e o princípio da existência de todas as
coisas, assim o pai é o princípio da existência do filho. Por isso era conveniente, depois dos preceitos
relativos a Deus, estabelecer o concernente aos pais. Mas a objeção colhe, quando os preceitos
afirmativos e os negativos respeitam ao mesmo gênero de obras. Embora também, neste ponto, não
tenha omnímoda eficácia. Pois, na execução de uma obra, hão-se primeiro extirpar os vícios que semear
as virtudes, conforme àquilo da Escritura (Sl 33, 15): Desvia-te do mal e faze o bem; (Is 1, 16-
17), cessai d' obrar perversamente, aprendei a fazer o bem. Contudo, quanto ao conhecimento, a
virtude precede o pecado, pois, pelo reto é que se conhece o obliquo, como diz Aristóteles. Ora, pela lei
se conhece o pecado, no dizer da Escritura (Rm 3, 20). E sendo assim, o preceito afirmativo devia ser
posto em primeiro lugar. A razão da ordem porém não é esta, mas a exposta acima. Porque, nos
preceitos referentes a Deus, concernentes à primeira tábua, está posto em último lugar o preceito
afirmativo, porque a sua transgressão implica menor reato.

RESPOSTA À TERCEIRA. — Embora o pecado intencional tenha precedência quanto à execução, contudo
a razão lhe apreende a proibição posteriormente.

## Art. 7 — Se os preceitos do decálogo foram dados convenientemente.
(IIª-IIae, q. 122, a. 2 sqq.; III Sent., dist. XXXVII, a. 2, qª 1).
O sétimo discute-se assim. — Parece que os preceitos do decálogo foram dados inconvenientemente.

1. — Pois, os preceitos afirmativos ordenam para os atos virtuosos; ao passo que os negativos os
separam dos atos viciosos. Ora, em qualquer matéria, virtudes e vícios entre si se opõem. Logo, em
qualquer matéria, sobre que verse um preceito do decálogo, devia se estabelecer um preceito
afirmativo e um negativo. Logo, inconvenientemente se estabeleceram certos afirmativos e certos,
negativos.

2. Demais. — Isidoro diz: toda lei se funda na razão. Ora, todos os preceitos do decálogo concernem à lei
divina. Logo, de todos se devia dar a razão, e não só do primeiro e do terceiro.

3. Demais. — Pela observação dos preceitos merecemos prêmios, de Deus. Ora, as promessas divinas
concernem os prêmios dos preceitos. Logo, devia se fazer uma promessa relativa a cada preceito e não
só, ao primeiro e ao quarto.

4. Demais. — A lei antiga é chamada a lei do temor porque pela cominação de penas induzia à
observação dos preceitos. Ora, todos os preceitos do decálogo pertencem à lei antiga. Logo, em todos
se devia fazer a cominação da pena e não só no primeiro e no segundo.

5. Demais. — Todos os preceitos de Deus devem-se conservar na memória, conforme a Escritura (Pr 3,
3):Grava-os sobre as tábuas do teu coração. Logo é inconveniente fazer menção da memória só no
terceiro preceito. Por onde, os preceitos do decálogo foram dados inconvenientemente.
Mas, em contrário, diz a Escritura (Sb 11, 21): Deus fez todas as coisas com conta e peso e medida. Logo,
com maior razão, observou modo conveniente no dar os preceitos da sua lei.

SOLUÇÃO. — Nos preceitos da lei divina está contida a máxima sabedoria; por isso, diz a Escritura (Dt 4,
6):Esta é a vossa sabedoria e inteligência aos povos. Ora, do sapiente é próprio dispor todas as coisas em
devido modo e ordem. Por onde é manifesto, que os preceitos da lei foram ministrados de modo
conveniente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A afirmação implica sempre a negação do contrário; mas
nem sempre, da negação de um contrário, resulta a afirmação do outro. Assim, resulta sempre de que,
se alguma coisa é branca, não é negra; mas não se pode dizer que, se não é negra, é portanto branca;
por ter a negação maior extensão que a afirmação. Daí vem que o preceito negativo — não se deve
fazer injúria a outrem — estende-se a maior número de pessoas, conforme o primeiro ditame da razão,
do que o preceito pelo qual se deve prestar a outrem um obséquio ou um benefício. Pois,
primeiramente, o ditame da razão implica, que devemos fazer benefícios ou serviços aqueles de quem
recebemos benefícios, se ainda não os recompensamos. Mas duas pessoas há cujos benefícios ninguém
pode suficientemente pagar: Deus e o próprio pai, como diz Aristóteles. Por isso, estabeleceram-se só
dois preceitos afirmativos: um, que manda honrar ospais; outro, sobre a celebração do sábado, em
comemoração dos benefícios divinos.

RESPOSTA À SEGUNDA. — Os preceitos puramente morais têm razão manifesta; por isso, não era
necessário acrescentar-lhes nenhuma outra. Mas a certos preceitos se acrescenta um cerimonial
determinativo do preceito moral comum. Assim, ao primeiro: Não farás imagem de escultura; e no
terceiro é determinado o dia do sábado. Por isso, num e noutro caso, era preciso assinalar a razão.

RESPOSTA À TERCEIRA. — Os homens, de ordinário, dirigem os seus atos para alguma utilidade. Por
isso, era necessário estabelecer a promessa de um prêmio, naqueles preceitos dos quais não se via
proceder nenhuma utilidade, mas antes, serem impedimentos dela. Ora, como os pais cada vez mais se
vão separando de nós, deles não esperamos nenhuma utilidade. Por onde, ao preceito que manda
honrá-los se acrescentou uma promessa. Semelhantemente, quanto ao que proíbe a idolatria, que os
homens consideravam como obstáculo a uma utilidade aparente, que criam poder conseguir, por pactos
feitos com os demônios.

RESPOSTA À QUARTA. — As penas sobretudo são necessárias contra os inclinados ao mal, como diz
Aristóteles. Por onde, a lei acrescenta a cominação de penas só naqueles preceitos, que supõem
inclinação para o mal. Ora, os homens eram inclinados à idolatria, por causa do costume geral das
nações. Semelhantemente, são também inclinados ao perjúrio, por causa da freqüência do juramento.
Por isso, aos dois primeiros preceitos se acrescentou uma cominação.

RESPOSTA À QUINTA. — O preceito sobre o sábado foi estabelecido como comemorativo do benefício
passado. Por isso, nele especialmente se faz menção da memória. — Ou, porque o preceito sobre o
sábado tem uma determinação adjunta, que não é da lei da natureza; e portanto, esse preceito
precisava de uma advertência especial.

## Art. 8 — Se os preceitos do decálogo admitem dispensa.
(Supra, q. 94, a. 5, ad 2.; IIª-IIae., q. 104, a. 5, ad 2; Sent., dist. XLVII, a.4; III, dist. XXXVII, a. 4; De Malo, q.
3, a. 1, ad 17; q, 15, a. 1, ad 8).
O oitavo discute-se assim. — Parece que os preceitos do decálogo admitem dispensa.

1. — Pois, os preceitos do decálogo são de direito natural. Ora, o justo natural admite, em certos casos,
exceções e é mutável, assim como a natureza humana, no dizer do Filósofo. Ora, a deficiência da lei, em
certos casos particulares, é a razão da dispensa, como já se disse (q. 96, a. 6; q. 97, a. 4). Logo, os
preceitos do decálogo admitem dispensa.

2. Demais. — O homem está para a lei humana como Deus para a lei divina. Ora, o homem pode ser
dispensado do preceito legal, que ele mesmo estabeleceu. Logo, tendo sido os preceitos do decálogo
instituídos por Deus, resulta que Deus pode dispensar neles. Ora, os prelados desempenham, na terra, o
papel de Deus, conforme àquilo do Apóstolo (2 Cor 2, 10): pois eu também, se dei alguma coisa, foi por
amor de vós em pessoa de Cristo. Logo, também os prelados podem dispensar nos preceitos do
decálogo.

3. Demais. — Entre os preceitos do decálogo está incluída a proibição do homicídio. Ora, os homens
podem dispensar neste preceito; assim quando, segundo os preceitos da lei humana, certos, como os
malfeitores ou os inimigos da pátria, são mortos licitamente. Logo, os preceitos do decálogo admitem
dispensa.

4. Demais. — A observância do sábado está contida entre os preceitos do decálogo. Ora, houve dispensa
neste preceito, conforme a Escritura (1 Mc 2, 4): Tomaram naquele dia esta resolução dizendo: Todo
homem, quem quer que ele seja, que nos atacar em dia de sábado, não façamos dificuldade de pelejar
contra ele. Logo, os preceitos do decálogo admitem dispensa.
Mas, em contrário, na Escritura (Is 24, 5), certos são censurados porque mudaram o direito, romperam a
aliança sempiterna; e isto se deve entender sobretudo dos preceitos do decálogo. Logo, estes não
podem sofrer mudança por dispensa.

SOLUÇÃO. — Como já se disse (q. 96, a. 6; q. 97, a. 4), deve-se dispensar nos preceitos, quando ocorrer
algum caso particular, em que, observadas as palavras da lei, contrariar-se-ia a intenção do legislador.
Ora, a intenção de qualquer legislador se ordena, primeiro e principalmente, para o bem comum; e
segundo, para a ordem da justiça e da virtude, pela qual se conserva o bem comum e a ele se chega.
Portanto, se estabelecerem preceitos conducentes à conservação mesma do bem comum, ou, à ordem
mesma da justiça e da virtude, tais preceitos exprimem a intenção do legislador, e portanto não
admitem dispensa. Por exemplo, se uma comunidade estabelecesse como preceito, que ninguém deve
destruir a república, nem entregar a cidade aos inimigos; ou que ninguém deve fazer nada de injusto ou
de mal, tais preceitos não admitiriam dispensa. Mas se estabelecesse outros, ordenados para estes, que
lhes determinassem certos modos especiais, estes poderiam admitir dispensa, quando a omissão deles,
em certos casos particulares, não prejudicasse aos primeiros, expressivos da intenção do legislador.
Assim se, para a conservação da república, uma cidade estabelecesse que certos, de cada aldeia,
velassem pela guarda da outra cidade sitiada, poderiam alguns ser disso dispensados, em vista de uma
utilidade maior.
Ora, os preceitos do decálogo exprimem a intenção mesma de Deus legislador. Pois, os da primeira
tábua, que ordenam para ele, contêm a ordem mesma para o bem comum e final, que é Deus. E os da
segunda, a ordem da justiça a ser observada entre os homens, de modo que, p. ex., a ninguém se lhe
faça o que se lhe não deve fazer, e a cada um lhe seja pago o devido; pois, a esta luz é que devem ser
entendidos os preceitos do decálogo. Logo, esses preceitos são absolutamente indispensáveis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo não se refere ao justo natural, que contém a
ordem mesma da justiça; pois, a observância da justiça não admite nenhuma exceção. Mas ele se refere
a determinados modos de observá-la, que sofrem exceção, em certos casos.

RESPOSTA À SEGUNDA. — Como diz o Apóstolo (2 Tm 2, 13), Deus permanece fiel, não pode negar-se a
si mesmo. Ora, negar-se-ia a si mesmo, se, sendo a própria justiça, ele próprio lhe eliminasse a ordem.
Portanto, Deus não pode dispensar o homem de tender ordenadamente para si, ou de sujeitar-se à
ordem da sua justiça, mesmo, em matéria conducente a se ordenarem os homens uns para os outros.

RESPOSTA À TERCEIRA. — O decálogo proíbe matar a outrem, na medida em que esse ato tem natureza
de indébito; pois, então, esse preceito exprime a essência mesma da justiça. Ora, a lei humana não pode
conceder seja lícito matar alguém indebitamente. Não é porém indevido matar os malfeitores ou os
inimigos da república. Por isso, tal não contraria ao preceito do decálogo; nem tal morte constitui o
homicídio proibido pelo preceito, como diz Agostinho. E semelhantemente, privar do seu a quem
devidamente deve ser privado não é o furto nem a rapina proibidos pelo preceito do decálogo. Por isso,
quando os filhos de Israel, por preceito de Deus, espoliaram os egípcios, não cometeram furto; pois
deviam fazê-lo por sentença divina. — Semelhantemente, quando Abraão consentiu em matar o filho,
não consentiu num homicídio, porque devia matá-lo, por mandado de Deus, senhor da vida e da morte.
Pois, Ele é quem infligiu a pena de morte a todos os homens, justos e injustos, por causa do pecado do
primeiro pai. E o homem que for executor de tal sentença, por autoridade divina, não será homicida,
como não o é Deus. — Do mesmo modo ainda, Oséas, tendo tido relação com uma esposa fornicária ou
uma mulher adúltera, não cometeu adultério nem fornicou; porque buscou a que era sua por ordem de
Deus, autor da instituição do matrimônio. — Assim pois, os referidos preceitos do decálogo, quanto à
razão de justiça que contêm, são imutáveis. Mas, são mutáveis no tocante a alguma determinação,
quando se aplicam a casos particulares, p. ex., quanto a saber-se se há ou não homicídio, furto ou
adultério. E isso, ora, pela só autoridade divina, no caso do que só por Deus foi instituído, como o
matrimônio e instituições semelhantes; ora, também por autoridade humana, em matéria cometida à
jurisdição dos homens; pois, estes governam em nome de Deus, neste ponto, e não em relação a tudo.

RESPOSTA À QUARTA. — A resolução de que se trata foi, antes, interpretação, que dispensa no
preceito. Pois, não se considera como violador do sábado quem obra por necessidade da salvação
humana, como o Senhor o mostra (Mt 12, 3 ss).

## Art. 9 — Se o modo da virtude está na alçada do preceito da lei.
(Supra, q. 96, a. 3, ad 2; IIª-IIae, q. 44, a. 4, ad 1; II Sent., dist. XXVIII, a. 3; IV, dist. XV, q. 3. a. 4. qª 1. ad 3).
O nono discute-se assim. — Parece que o modo da virtude está na alçada do preceito da lei.

1. — Pois, o modo da virtude está em praticarmos justamente atos justos; fortemente, atos fortes, e
assim com as demais virtudes. Ora, a Escritura ordena (Dt 26, 20): administrarás a justiça com retidão.
Logo, o modo da virtude está na alçada do preceito.

2. Demais. — O que está na intenção do legislador é o que sobretudo está na alçada do preceito. Ora,
essa intenção visa principalmente tornar os homens virtuosos, como diz Aristóteles. E sendo próprio do
homem virtuoso agir virtuosamente, o modo da virtude há de estar na alçada do preceito.

3. Demais. — O modo da virtude está propriamente em agirmos voluntária e deleitavelmente. Ora, isto
está na alçada do preceito da lei divina. Pois, diz a Escritura (Sl 99, 2): servi ao Senhor em alegria; e (2
Cor 9, 7):não com tristeza, nem como por força, porque Deus ama ao que dá com alegria; ao que a Glosa
diz: tudo o que fizeres falo com alegria, e falo-as bem; se porém o fizeres com tristeza, o jeito vem de ti,
mas não o fizeste tu. Logo, o modo da virtude está na alçada do preceito da lei.
Mas, em contrário. — Ninguém pode obrar como o virtuoso, sem ter o hábito da virtude, como está
claro no Filósofo. Ora, quem quer que, transgrida o preceito da lei merece pena. Donde se seguiria que
todo aquele que não tivesse o hábito da virtude mereceria pena por tudo o que fizesse. Ora, isto é
contra a intenção da lei, que visa induzir o homem à virtude, acostumando-o às boas obras. Logo, o
modo da virtude não está na alçada do preceito.

SOLUÇÃO. — Como já dissemos (q. 90, a. 3 ad 2), o preceito de lei tem força coativa. Por onde, aquilo a
que a lei obriga entra diretamente no seu preceito. Ora, a coação da lei se realiza pelo medo da pena,
como diz Aristóteles. Pois, está propriamente na alçada do preceito da lei, aquilo pelo que ela inflige
uma pena. No instituir porém a pena, a lei divina procede diferentemente da humana. Pois, a pena da
lei não é infligida senão relativamente àquilo de que o legislador tem que julgar; porque a lei pune em
virtude de um juízo. Ora, os homens autores da lei não devem julgar senão dos atos externos,
porque vêem o que está patente, como diz a Escritura (1 Sm 16, 7). E só Deus, autor da lei divina, é que
pode julgar dos movimentos interiores das vontades, segundo àquilo da Escritura (Sl 7, 10): Deus, que
sonda os corações e as entranhas.
Ora, a esta luz, devemos dizer, que o modo da virtude, sob certo aspecto, é levado em consideração
pela lei humana e pela divina; sob outro, pela lei divina e, não, pela humana; e, enfim, sob um terceiro,
nem pela lei humana, nem pela divina. Pois, esse modo consiste em três coisas, segundo o Filósofo. A
primeira em obrarmos cientemente; o que é julgado, tanto pela lei divina, como pela humana. Pois, é
acidental o que fazemos por ignorância. E assim, por ignorância, os atos humanos são julgados dignos de
pena ou de vênia, tanto pela lei humana, como pela divina. — A segunda consiste em obrarmos
voluntariamente, ou por eleição, e eleição de um objeto particular, o que implica um duplo movimento
interior — o da vontade e o da intenção, de que já tratamos (q. 8; q. 12), e das quais a lei humana não
pode julgar, mas só, a divina. Pois, a lei humana não pode punir quem quer matar, mas não matou. Ao
passo que a lei divina o pune, conforme a Escritura (Mt 5, 22): todo o que se ira contra seu irmão será
réu no juízo. — A terceira consiste em agirmos e conservarmo-nos firme e imovelmente. E esta firmeza
pertence propriamente ao hábito, i. é, está em obrarmos por um hábito enraigado. Ora, neste ponto, o
modo da virtude não está na alçada do preceito nem da lei divina, nem da humana. Pois, nem pelos
homens, nem por Deus é punido,como transgressor do preceito, quem retribui aos pais a honra devida,
embora sem o hábito da piedade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O modo de praticar um ato de justiça, pertencente ao
preceito, é praticá-lo segundo a ordem do direito, e não pelo hábito da justiça.

RESPOSTA À SEGUNDA. — Duas coisas visa a intenção do legislador. Uma é a para a qual, pelo preceito
da lei, quer levar, e essa é a virtude. Outra é a sobre a qual quer fazer o preceito, e esta é a que leva ou
dispõe para a virtude, a saber, o ato de virtude. Pois, o fim do preceito não se confunde com o seu
objeto; assim como, no demais, o fim não se identifica com os meios.

RESPOSTA À TERCEIRA. — Praticar sem tristeza obras de virtude entra no preceito da lei divina, porque
quem quer que obre com tristeza não obra voluntariamente. Mas, obrar deleitavelmente, ou com ledice
e alegria, está, de certo modo, no preceito, i. é, enquanto que a deleitação resulta do amor de Deus e do
próximo, incluídos no preceito, por ser o amor a causa da deleitação. Mas, de outro modo, não está,
enquanto que a deleitação resulta do hábito; porque a deleitação na obra é sinal de um hábito
existente, como diz Aristóteles. Pois, um ato pode ser deleitável pelo fim ou pela conveniência com o
hábito.

## Art. 10 — Se o modo da caridade está na alçada do preceito da lei divina.
(III Sent., dist. :XXXVI, a. 6; De Verit., q. 23, a. 7, ad 8; q. 24, a. 12. ad 16; De Malo, q. 2, a. 5, ad 7).
O décimo discute-se assim. — Parece que o modo da caridade está na alçada do preceito da lei divina.

1. — Pois, diz a Escritura (Mt 19, 17): se tu queres entrar na vida, guarda os mandamentos; por onde se
vê que a observância dos mandamentos basta para fazer entrar na vida. Ora, para isso não bastam as
boas obras, se não forem feitas pela caridade, conforme a Escritura (1 Cor 13, 3): E se eu distribuir todos
os meus bens em o sustento dos pobres, e se entregar o meu corpo para ser queimado, se todavia não
tiver caridade, nada disto me aproveita. Logo, o modo da caridade está na alçada do preceito.

2. Demais. — Ao modo da caridade propriamente pertence fazer tudo por Deus. Ora, isto está na alçada
do preceito, conforme diz o Apóstolo (1 Cor 10, 31): fazei tudo para a glória de Deus. Logo, o modo da
caridade está na alçada do preceito.

3. Demais. — Se o modo da caridade não estivesse na alçada do preceito, poderíamos cumprir os
preceitos da lei, sem a caridade. Ora, o que podemos fazer sem a caridade, podemos fazer sem a graça,
que sempre a acompanha. Logo, podemos cumprir os preceitos da lei, sem a graça, o que é o erro
pelagiano, como está claro em Agostinho. Logo, o modo da caridade está na alçada do preceito.
Mas, em contrário, todo aquele que não observa o preceito, peca mortalmente. Se, pois, o modo da
caridade é da alçada do preceito — quem fizer qualquer obra, sem caridade, pecará mortalmente. Ora,
quem não tem caridade obra sem ela, e portanto, peca mortalmente em tudo o que fizer, embora seja o
ato bom. O que é inadmissível.

SOLUÇÃO. — No tocante a este assunto emitiram-se duas opiniões. — Uns consideram, absolutamente,
o modo da caridade como da alçada do preceito. Mas não é impossível observe o preceito quem não
tem caridade, pois pode dispor-se do modo a Deus lha infundir. E nem peca sempre mortalmente quem,
sem a caridade, pratica o bem; porque obrar pela caridade é um preceito afirmativo, que não obriga
sempre, senão só no tempo em que a tiver. — Outros porém disseram que, absolutamente, o modo da
caridade não está na alçada do preceito.
Ora, ambas, a certo respeito, exprimem a verdade; pois, o ato de caridade pode ser considerado à dupla
luz. — Primeiro, enquanto é, em si mesmo, um ato. E deste modo cai sob a alçada da lei, o que é
especialmente determinado sobre a caridade, a saber: Amarás ao Senhor teu Deus, e, amarás ao teu
próximo. E neste ponto a primeira opinião exprime a verdade. Pois, não é impossível observar o preceito
sobre o ato de caridade, porque podemos nos dispor a tê-la; e, quando a tivermos, podemos usar dela.
— Em segundo lugar, pode ser considerado o ato de caridade enquanto modo dos atos das outras
virtudes; i. é, enquanto os atos das outras virtudes se ordenam para ela, que é o fim do preceito, como
diz a Escritura (1 Tm 1, 5). Pois, como já dissemos (q. 12, a. 4), a intenção do fim é um certo modo
formal do ato ordenado para o fim. E sendo assim, é verdadeira a segunda opinião, pela qual o modo da
caridade não é da alçada do preceito. Isto é, o preceito — honra ao pai — não inclui o honrá-lo pela
caridade, mas somente, honrá-lo. Por onde, quem honra ao próprio pai, embora sem caridade, não se
torna transgressor desse preceito, embora o seja do que preceitua o ato de caridade, por cuja
transgressão merece uma pena.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Senhor não disse — se tu queres entrar na vida,
guarda um mandamento — mas — guarda todos os mandamentos. Entre os quais também está o do
amor de Deus e do próximo.

RESPOSTA À SEGUNDA. — No preceito da caridade está incluído o amar a Deus de todo o coração; e
isso implica em referir tudo a Deus. Portanto, o homem não pode cumprir o preceito da caridade, se não
referir tudo a Deus. Por onde, quem honra aos pais está obrigado a honrá-los pela caridade, não por
força do preceito — Honra a teus pais — mas, por força do outro — Amarás ao Senhor teu Deus de todo
o teu coração. E como estes são dois preceitos afirmativos que não obrigam para sempre, podem
obrigar em tempos diversos. E assim, pode alguém cumprir o preceito de honrar os pais sem transgredir
o outro, sobre a omissão do modo da caridade.

RESPOSTA À TERCEIRA. — O homem não pode observar todos os preceitos da lei, sem cumprir o da
caridade; porque isso não o fará sem a graça. Portanto, é impossível o que disse Pelágio, que o homem
pode cumprir a lei sem a graça.

## Art. 11 — Se se distinguem convenientemente outros preceitos morais da lei, além do decálogo.
(Supra. a. 3).
O undécimo discute-se assim. — Parece que inconvenientemente se distinguem outros preceitos
morais da lei, além do decálogo.

1. — Pois, como diz o Senhor (Mt 22, 40), destes dois mandamentos depende toda a lei e os profetas.
Ora, estes dois preceitos se explicam pelos dez do decálogo. Logo, não é necessário se estabeleçam
outros preceitos morais

2. Demais. — Os preceitos morais distinguem-se dos judiciais e dos cerimoniais, como já se disse (q. 99,
a. 3, a. 4). Ora, as determinações dos preceitos morais comuns pertencem aos judiciais e aos
cerimoniais; pois, esses preceitos morais comuns estão contidos no decálogo, ou mesmo, a ele se
pressupõem, como se disse (a. 3). Logo, é inconveniente estabelecerem-se outros preceitos morais,
além do decálogo.

3. Demais. — Os preceitos morais respeitam os atos de todas as virtudes, como já se disse (a. 2). Por
onde, assim como a lei estabelece preceitos morais, além do decálogo, relativos à latria, à liberalidade, à
misericórdia, à castidade; assim também deveria ter estabelecido relativos às demais virtudes, p. ex., à
da fortaleza, da sobriedade, e outras; e entretanto não o fez. Logo, não se distinguem
convenientemente, na lei, outros preceitos morais, além do decálogo.
Mas, em contrário, diz a Escritura (Sl 18, 8): A lei do Senhor, que é imaculada, converte as almas. Ora,
também pelos outros preceitos morais, acrescentados ao decálogo, o homem se conserva sem a mácula
do pecado, e a sua alma se converte para Deus. Logo, pertencia à lei estabelecer também outros
preceitos morais.

SOLUÇÃO. — Como do sobredito resulta (q. 99, a. 3, a. 4), os preceitos judiciais e os cerimoniais têm
força de lei em virtude da só instituição; pois antes de terem sido instituídos não importava que se
agisse de um ou de outro modo. Ao passo que os preceitos morais têm eficácia pelo próprio ditame da
razão natural, mesmo que nunca sejam determinados por lei. Ora, estes preceitos têm três graus. —
Assim, uns são certíssimos e de tal modo manifestos, que não precisam de publicação, como os
atinentes ao amor de Deus e do próximo, e semelhantes, conforme já dissemos (a. 3), que são quase os
fins dos preceitos. Por onde, quanto a eles, não pode errar o juízo da razão de ninguém. — Outros
porém são mais determinados, cuja razão qualquer, mesmo um simples homem vulgar, pode facilmente
compreender. E contudo, como algumas vezes, em relação a estes, o juízo humano pode estar
pervertido, precisam de publicação. E tais são os preceitos do decálogo. — Outros enfim há, cuja razão
não é manifesta a todos, mas só aos sapientes; e esses são os preceitos morais, acrescentados ao
decálogo, dados por Deus ao povo, por meio de Moisés e Aarão.
Mas, como o manifesto é o princípio pelo qual conhecemos o que não o é, os preceitos morais,
acrescentados ao decálogo, reduzem-se aos deste, a modo de adição com eles. — Pois, o primeiro
preceito do decálogo proíbe o culto dos outros deuses, a que se acrescentaram outros preceitos
proibitivos detudo o que se funda no culto dos ídolos, como está na Escritura (Dt 18, 10-11): Nem se
ache entre vós quem pretenda purificar seu filho ou filha, fazendo-os passar pelo jogo; nem quem seja
feiticeiro, ou encantador, nem quem consulte aos pilões ou adivinhos, ou indague dos mortos a
verdade. — O segundo preceito proíbe o perjúrio, ao qual se acrescenta a proibição da blasfêmia (Lv 24,
15 ss) e a da falsa doutrina (Dt 13). — Ao terceiro se acrescentam todos os preceitos cerimoniais. — Ao
quarto, sobre a honra devida aos pais, acrescenta-se o de honrar aos velhos, conforme o lugar (Lv 19,
32): Levanta-te diante dos que têm a cabeça cheia de cãs e honra a pessoa do velho. E, em geral, todos
os preceitos, que mandam reverenciar os maiores, ou beneficiar os iguais ou os menores. — Ao quinto
preceito, sobre a proibição do homicídio, acrescenta-se a do ódio ou de qualquer violência contra o
próximo, conforme o lugar (Lv 19, 16): Não conspirarás contra o sangue do teu próximo; e também a
proibição do ódio fraterno, conforme aquilo (Lv 19, 17): Não aborrecerás o teu irmão no teu coração. —
Ao sexto preceito, sobre a proibição do adultério, acrescenta-se o que proíbe o meretrício (Dt 23,
17): Não haverá entre as filhas de Israel mulher prostituta, nem fornicador nos filhos de Israel; e
também a proibição do vício contra a natureza (Lv 18, 22-23): Não usarás do macho como fosse fêmea;
não te ajuntarás com animal algum. — Ao sétimo, sobre a proibição do furto, acrescenta-se o que
proíbe a usura (Dt 23, 19):Não emprestarás com usura a teu irmão; e a proibição da fraude (Dt 25,
13): Não terás no teu saco diversos pesos; e, universalmente, tudo o que pertence à proibição da calúnia
e da rapina. — Ao oitavo, que proíbe o falso testemunho, acrescenta-se a proibição do falso juízo (Ex 23,
2): Nem em juízo te deixarás arrastar do sentimento do maior número, para te desviares da verdade. E a
proibição da mentira, como no mesmo cap. se acrescenta: Fugirás à mentira; e a da detração, conforme
outro lugar (Lv 19, 16): Não serás delator de crimes, nem mexeriqueiro entre o povo. — Enfim, aos
outros dois preceitos nada se acrescentou, porque proíbem universalmente todas as más
concupiscências.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ao amor de Deus e do próximo se ordenam certos
preceitos do decálogo, conforme a razão manifesta de débito; outros, porém, conforme uma razão mais
oculta.

RESPOSTA À SEGUNDA. — Os preceitos cerimoniais e os judiciais são determinativos dos preceitos do
decálogo, por força da instituição; e não por força do instinto natural, como os preceitos morais a eles
acrescentados.

RESPOSTA À TERCEIRA. — Os preceitos da lei se ordenam ao bem comum, como já se disse (q. 90, a. 2).
E como as virtudes, que ordenam para outrem, visam diretamente o bem comum; e semelhantemente a
virtude da castidade, enquanto o ato de geração serve ao bem comum da espécie, por isso se
estabeleceram diretamente preceitos sobre essas virtudes, tanto os do decálogo, como os que se lhes
acrescentaram. Quanto ao ato de fortaleza, deu-se um preceito a ser proposto pelos chefes, que
exortam à guerra, empreendida pelo bem comum, como está claro quando se ordena ao sacerdote (Dt
20, 3): não temais, não receeis. Semelhantemente, do ato da gula cometeu-se a proibição à advertência
paterna, porque contraria o bem doméstico; por onde, diz a Escritura, da pessoa dos pais (Dt 21,
20): despreza ouvir as nossas admoestações, passa a vida em comezainas e dissoluções e banquetes.

## Art. 12 — Se os preceitos morais da lei antiga justificavam.
(Supra, q. 98, a. 1; III Sent., dist. XL, a.3; Ad Rom., cap. II, lect. III; cap. III lect. II; Ad Galat., cap. II, lect;
cap. III, lect. IV).
O duodécimo discute-se assim. — Parece que os preceitos morais da lei antiga justificavam.

1. — Pois, diz o Apóstolo (Rm 2, 13): Porque não são justos diante de Deus os que ouvem a lei; mas os
que fazem o que manda a lei serão justificados. Ora, obedientes à lei são os que lhe cumprem os
preceitos. Logo, esses preceitos, cumpridos, justificavam.

2. Demais. — A Escritura diz (Lv 18, 5): Guardai as minhas leis e mandados, os quais fazendo o homem,
viverá neles.Ora, a vida espiritual o homem a vive pela justiça. Logo, os preceitos da lei, sendo
cumpridos, justificavam.

3. Demais. — A lei divina é mais eficaz que a humana. Ora, esta justifica, pois há uma certa justiça em
lhe cumprir os preceitos. Logo, os preceitos da lei justificavam.
Mas, em contrário, diz o Apóstolo (2 Cor 3, 6): A letra mala. O que, segundo Agostinho, também se
entende dos preceitos morais. Logo, estes não justificavam.

SOLUÇÃO. — Própria e primariamente chama-se a quem tem saúde, são; e em significação derivada, ao
que exprime ou conserva a saúde. Assim também, em sentido próprio e primário, chama-se justificação
à prática mesma da justiça; e em sentido derivado e quase impróprio, pode-se chamar
justificação à figuração da justiça ou à disposição para ela. E desses dois modos é manifesto, que os
preceitos da lei justificavam, por disporem os homens para a graça de Cristo justificante, a qual também
figuravam. Pois, como diz Agostinho, também a vida do povo judaico era profética e figurativa de Cristo.
Se porém nos referimos à justificação propriamente dita, então devemos considerar que a justiça pode
ser tomada como habitual, ou como atual. E a esta luz, a justificação tem duplo sentido: Num, é porque
o homem se torna justo, adquirindo o hábito da justiça; noutro, significa a execução dos atos de justiça,
e neste sentido a justificação nada mais é do que a execução da justiça. — Como as outras virtudes
porém, a justiça pode ser considerada como adquirida e infusa, conforme do sobredito resulta (q. 63, a.
4). A adquirida é causada pelas obras. Ao passo que a infusa, por Deus mesmo, por meio da sua graça. E
esta é a verdadeira justiça, de que agora tratamos, pela qual somos considerados justos, em Deus,
conforme a Escritura (Rm 4, 2): Se Abraão foi justificado pelas obras, tem de que se gloriar, mas não,
diante de Deus. Por onde, esta justiça não podia ser causada pelos preceitos morais, relativos aos atos
humanos. E por aí os preceitos morais não podiam justificar, causando a justiça. Se porém
considerarmos a justiça como a execução da mesma, então todos os preceitos da lei justificavam, por
conterem o que é em si mesmo justo, mas de modos diversos. Assim, os preceitos cerimoniais
continham, certo, a justiça em si mesma e em geral, enquanto se manifestava no culto de Deus. Mas,
em especial, não a continham, em si mesma, senão pela só determinação da lei divina. Por isso, destes
preceitos se diz, que não justificavam senão pela devoção e obediência dos que lhes praticavam os
ditames. Por outro lado, os preceitos morais e os judiciais continham o que era em si mesmo justo, em
geral, ou também em especial. Mas os preceitos morais continham o que era em si mesmo justo, con-
forme a justiça geral, que é toda a virtude, como diz Aristóteles; ao passo que os preceitos judiciais
pertenciam à justiça especial, relativa aos contratos que na vida, os homens pactuam entre si.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Apóstolo, no lugar citado, toma a justificação no
sentido de execução da justiça.

RESPOSTA À SEGUNDA. — Do que cumpre os preceitos da lei se diz que vive neles, por não incorrer na
pena de morte, que a lei infligia aos transgressores. E neste sentido é que determina o Apóstolo.

RESPOSTA À TERCEIRA. — Os preceitos da lei humana justificam pela justiça adquirida, da qual agora
não tratamos, senão só da que justifica perante Deus.