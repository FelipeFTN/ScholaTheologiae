# Questão 113: Da justificação do ímpio, que é efeito da graça operante.
Em seguida devemos tratar dos efeitos da graça. E primeiro, da justificação do ímpio, efeito da graça
operante. Segundo, do mérito, efeito da graça cooperante.
Na primeira questão discutem-se dez artigos:

## Art. 1 — Se a justificação do ímpio é a remissão dos pecados.
(Infra, a. 6 ad I; IV Sent., dist. XVII, q. 1, a. 1, qª 1; De Verit., q. 28, a. 1).
O primeiro discute-se assim. – Parece que a justificação do ímpio não é a remissão dos pecados.

1. – Pois, o pecado se opõe não só à justiça, como a todas as virtudes, segundo do sobredito resulta.
Ora, a justificação implica um certo movimento para a justiça. Logo, nem toda remissão do pecado é
justificação, pois todo movimento se realiza entre dois termos contrários.

2. Demais. – Um objeto tira o seu nome do que tem em si de mais importante, como diz Aristóteles. Ora,
a remissão dos pecados se opera, principalmente, pela fé, conforme aquilo da Escritura: a caridade
cobre todos os delitos. Logo, a remissão dos pecados devia ser denominada, antes, pela fé ou pela
caridade, do que pela justiça.

3. Demais. – A remissão dos pecados parece significar o mesmo que vocação; ora, é chamado quem está
distante, e o pecado é que nos torna distante de Deus. Ora, a vocação precede à justificação, conforme
a Escritura: Aos que chamou a estes também justificou. Logo, a justificação não é a remissão dos
pecados.
Mas, em contrário, aquilo da Escritura: Aos que chamou a estes também justificou – diz a Glosa: pela
remissão dos pecados. Logo, esta é a justificação.

SOLUÇÃO. – A justificação,em acepção passiva, implica um movimento para a justiça, assim como a
calefação, para o calor. E como a justiça implica, por essência, a retidão da ordem, pode ser tomada em
duplo sentido. – Primeiro, enquanto implica a ordem reta no ato mesmo do homem. E então, a justiça é
considerada como virtude. Quer seja uma virtude particular, que ordena a retidão dos atos de um
homem relativamente aos de outro; quer seja a justiça legal, que ordena essa retidão, relativamente ao
bem comum do povo, como está claro em Aristóteles. – Noutro sentido, a justiça implica uma certa
retidão da ordem na disposição mesma interna do homem, fazendo com que a sua faculdade suprema
se submeta a Deus, e a essa faculdade, i. é, à razão se sujeitem as faculdades inferiores da alma. E a essa
disposição o Filósofo dá o nome de justiça metaforicamente dita. Ora, esta justiça pode realizar-se no
homem de duplo modo. – Primeiro, como simples geração, que se opera pela passagem da privação
para a forma. E neste sentido, a justificação poderia convir mesmo a quem não estivesse em pecado e,
nesse estado, recebesse de Deus a justiça. Assim, diz-se que Adão recebeu a justiça original. – De outro
modo, essa justiça pode realizar-se no homem, conforme ao movimento da razão, que vai de um termo
para o seu contrário. E deste modo, a justificação implica uma certa mudança do estado de injustiça
para o da referida justiça. E é neste sentido que se trata agora da justificação do ímpio, conforme aquilo
do Apóstolo: Ao que não obra e crê naquele que justifica ao ímpio, a sua fé lhe é imputada à justiça,
segundo o decreto da graça de Deus. E como um movimento tira a sua denominação, mais do seu termo
de origem, do que do de chegada, esse passar do estado de injustiça para o da justiça, pela remissão do
pecado, recebe a sua denominação do termo de chegada, e se chama justificação do ímpio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Todo pecado, por isso mesmo que implica uma certa
desordem da mente não sujeita a Deus, pode chamar-se injustiça, contrária à justiça em questão,
conforme aquilo da Escritura: Todo o que comete um pecado comete igualmente uma iniqüidade,
porque o pecado é uma iniqüidade. E assim, à remoção de qualquer pecado chama-se justificação.

RESPOSTA À SEGUNDA. – A fé e a caridade implicam uma ordem especial da mente humana para Deus,
pelo intelecto e pelo afeto. Ao passo que a justiça implica, em geral, a retidão total da ordem. Por isso,
essa mudança tira a sua denominação, antes, da justiça, que da caridade ou da fé.

RESPOSTA À TERCEIRA. – A vocação depende do auxílio de Deus, que move interiormente e excita a
alma a abandonar o pecado. Essa moção de Deus, porém, não é a remissão mesma do pecado, mas a
sua causa.

## Art. 2 — Se, para a remissão da culpa, que é a justificação do ímpio, é necessária a graça infusa.
(II Sent., dist, q. 1, a. 3, qª 1; De Verit., q. 28, a. 2; Ad Ephes., cap. V, lect. V).
O segundo discute-se assim. – Parece que, para a remissão da culpa, que é a justificação do ímpio, não
é necessária a graça infusa.

1. – Pois, podemos ser removidos de um contrário, sem por isso sermos levados para o outro, se esses
contrários forem mediatos. Ora, o estado da culpa e o da graça são contrários mediatos; pois, no meio,
está o estado de inocência, em que o homem não tem a graça nem a culpa. Logo, pode a alguém ser-lhe
remitida a culpa sem que alcance a graça.

2. Demais. – A remissão da culpa consiste em Deus não mais no-la imputar, conforme a Escritura: Bem
aventurado o homem a quem o Senhor não imputou o pecado. Ora, a infusão da graça produz algum
efeito em nós, como já se estabeleceu. Logo, a infusão da graça não é necessária à remissão da culpa.

3. Demais. – Ninguém pode estar sujeito simultaneamente a dons contrários. Ora, certos pecados, como
a prodigalidade e a avareza, são contrários. Logo, quem é escravo do pecado da prodigalidade não o é,
ao mesmo tempo, da avareza, embora possa acontecer estivesse antes a ela sujeito. Portanto, pecando
pelo vício da prodigalidade, livra-se do pecado da avareza e, por conseqüência, algum pecado se remite,
sem a graça.
Mas, em contrário, diz a Escritura: Tendo sido justificados gratuitamente por sua graça.

SOLUÇÃO. – O homem, pecando, ofende a Deus, como do sobredito resulta. Ora, a nenhum ofensor se
lhe remite a ofensa senão depois de pacificado o seu ofendido. Assim também, se o pecado nos é
perdoado, por Deus ter reatado conosco a sua paz, consistente no amor com que nos ama. Ora, o amor
de Deus, no tocante ao ato divino, é eterno e imutável; deixa porém às vezes de imprimir em nós o seu
efeito, segundo dele nos afastamos ou o recuperamos. E esse efeito do divino amor em nós, excluído
pelo pecado, é a graça,que nos torna dignos da vida eterna e que perdemos pelo pecado mortal.
Portanto, não se pode conceder a remissão da culpa sem haver a infusão da graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – É mais difícil, ofendido, remitirmos a ofensa, do que
simplesmente não odiar a quem não nos ofendeu. Pois, podemos nem amar nem odiar a outrem. Mas a
quem nos ofendeu, só por uma especial benevolência podemos perdoar-lhe a ofensa. Ora, a
benevolência de Deus para com o homem é recuperada pelo dom da graça. Por onde, embora, antes de
ter pecado, pudesse viver sem graça e sem culpa, contudo, depois do pecado, não pode estar isento de
culpa, sem a graça.

RESPOSTA À SEGUNDA. – O amor de Deus consiste, não só num ato da divina vontade, mas implica
ainda um certo efeito da graça, como já dissemos. Assim também, é por um efeito produzido no
pecador, que Deus não lhe imputa o seu pecado; e isso Deus o faz por amor.

RESPOSTA À TERCEIRA. – Como diz Agostinho, se, para sair do estado de pecado, bastasse cessar de
cometê-lo, a Escritura não teria feito senão nesta advertência: Filho, pecaste; não recomeces. Mas,
como não basta, ela acrescenta:E ora para que te sejam perdoados os pecados passados. Ora,
transitório pelo seu ato, o pecado permanece pelo reato, como já dissemos. Por onde, em que passa dos
pecados de um vício para os do vício contrário, já não existe atualmente o pecado passado, mas, só o
seu reato. E portanto, nessa pessoa existe o reato de um e outro pecado. Logo, não é o afastamento de
Deus, fundamento do reato dos pecados, que os torna entre si contrários.

## Art. 3 — Se, para a justificação do ímpio, é necessária a moção do livre arbítrio.
(II Sent., dist. XXVII, a. 2, ad 7; IV, dist. XVII, q. 1, a. 3, qª 2; De Verit., q. 28, a. 3,4; In Ioan., cap. IV, lect II;
Ad Ephes., cap. V, lect V).
O terceiro discute-se assim. – Parece que, para a justificação do ímpio, não é necessária nenhuma
moção do livre arbítrio.

1. – Pois, vemos que o sacramento do batismo justifica as crianças, e, as vezes, mesmo os adultos, sem
qualquer moção do livre arbítrio. Pois, diz Agostinho, estando um seu amigo sofrendo de febres: jazia, já
havia tempo, sem sentidos e com suores letais; e, desesperado, foi, sem o saber, batizado e regenerou-
se;ora, isto se faz pela graça santificante. Porém, Deus não fez depender o seu poder, dos sacramentos.
Logo, pode também, sem eles, e sem qualquer moção do livre arbítrio, justificar o homem.

2. Demais. – Dormindo, o homem não tem o uso da razão, sem o qual não pode haver moção do livre
arbítrio. Ora, Salomão, dormindo, obteve de Deus o dom da sabedoria, como diz a Escritura. Logo, pela
mesma razão, o dom da graça justificante é, às vezes, dado por Deus ao homem, sem haver neste a
moção do livre arbítrio.

3. Demais. – A mesma causa, que produz a graça, a conserva. Pois, diz Agostinho: o homem deve
converter-se para Deus de modo a ser justificado sempre por ele. Ora, sem a moção do livre arbítrio, o
homem conserva a graça. Logo, pode, sem essa moção, ter sido inicialmente infundida.
Mas, em contrário, diz a Escritura: Todo aquele que do Pai ouviu e aprendeu vem a mim. Ora, não é
possível aprender sem a moção do livre arbítrio; pois quem aprende aceita a doutrina de quem ensina.
Logo, ninguém vai a Deus só pela graça santificante, sem a moção do livre arbítrio.

SOLUÇÃO. – A justificação do ímpio Deus a opera movendo-o para a justiça. Pois, Ele é quem justifica o
ímpio,no dizer da Escritura. Ora, os seres todos Deus os move segundo a natureza de cada um. Assim,
vemos que, dos seres naturais, move os pesados diferentemente dos leves, segundo as naturezas
diversas deles. Assim também move o homem para a justiça, de conformidade com a condição da
natureza humana. Ora, por natureza, o homem é dotado do livre arbítrio. Logo, Deus não o move para a
justiça, sem a moção do livre arbítrio, de que o homem tem o uso. Mas lhe infunde o dom da graça
justificante, movendo, simultaneamente, o livre arbítrio, nos seres capazes dessa moção, para
receberem o dom da graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As crianças, não sendo capazes da moção do livre
arbítrio, Deus as move para a justiça, pela só informação da alma delas. Mas isso não se opera sem o
sacramento. Pois, como o pecado original, de que são justificadas, não as contaminou por vontade
própria delas, mas pela sua origem carnal, por isso a graça de Cristo se lhe infunde por regeneração
espiritual. E o mesmo se dá com os furiosos e os loucos, que nunca tiveram o uso do livre arbítrio. Pode,
porém uma pessoa ter tido o uso do livre arbítrio, e depois perdê-lo, por doença ou durante o sono. E
essa não recebe a graça santificante por meio do batismo exteriormente ministrado, ou por outro
qualquer sacramento, sem ter feito, antes, o propósito de recebê-lo; e o que não pé possível sem o uso
do livre arbítrio. Foi assim, deste modo, que foi regenerado aquele a quem se refere Agostinho; pois,
tendo, antes, consentido no batismo, recebeu-o depois.

RESPOSTA À SEGUNDA. – Também Salomão, dormindo, não mereceu nem recebeu a sabedoria;
somente foi-lhe revelado que, conforme ao seu desejo anterior, Deus lhe infundira. E por isso, diz a
Escritura, da pessoa dele; Desejei e foi-me dado o sentido. – Ou se pode dizer que o sono de Salomão
não foi natural, mas, profético, consoante à Escritura: Se entre vós se achar algum profeta do Senhor, eu
lhe aparecerei em visão ou lhe falarei em sonhos; em cujo caso é possível usar do livre arbítrio. – E
contudo, deve saber-se que o dom da sabedoria e o da graça justificante não tem o mesmo
fundamento. Pois, aquele ordena principalmente o homem para o bem, objeto da vontade; por isso é
movido para tal bem por uma moção da vontade, dependente do livre arbítrio. Ao passo que a
sabedoria aperfeiçoa o intelecto, que procede à vontade; por onde, sem o movimento completo do livre
arbítrio o intelecto pode ser iluminado pelo dom as sabedoria. Assim também vemos que, durante o
sono, recebe o homem certas revelações, como diz a Escritura: Quando cai sopor sobre os homens, e
estão dormindo no seu leito, então abre os ouvidos dos homens e, admoestando-os, lhes adverte o que
devem fazer.

DONDE A RESPOSTA Á TERCEIRA. – Pela infusão da graça santificante dá-se uma como transformação
da alma humana; e portanto, é necessário uma moção própria dela, que a mova de conformidade com a
sua natureza. Ao passo que a conservação da graça não precisa de nenhuma transformação, e portanto
de nenhuma moção da alma, mas só, da continuidade do influxo divino.

## Art. 4 — Se, para a justificação do ímpio, é necessária a moção da fé.
(IV Sent., dist. XVII, q. 1, a. 3, qª 3; De Verit., q. 28, a. 4; Ad Ephes., cap. II, lect. III).
O quarto discute-se assim. – Parece que para a justificação do ímpio não é necessária a moção da fé.

1. – Pois, se o homem é justificado pela fé, pode sê-lo também por outras virtudes, como o temor, do
qual diz a Escritura: O temor do Senhor lança fora o pecado; porque aquele que está sem temor não
poderá ser justificado. E também pela caridade: Perdoados lhe são seus muitos pecados, porque amou
muito. E ainda, pela humildade: Deus resiste aos soberbos e dá a sua graça aos humildes. E enfim, pela
misericórdia: Os pecados purificam-se pela misericórdia e pela fé. Logo, para a justificação do ímpio não
é mais necessária a moção da fé do que a das virtudes referidas.

2. Demais. – O ato de fé não é necessário para a justificação, senão enquanto, por ela, o homem
conhece a Deus. Ora, pode conhecer a Deus também por outros modos, como, pelo conhecimento
natural e pelo dom da sabedoria. Logo, não é necessário o ato de fé, para a justificação do ímpio.

3. Demais. – São diversos os artigos da fé. Se pois, o ato de fé fosse necessário à justificação do ímpio,
seria necessário o homem ter presente ao espírito todos os artigos da fé, no momento de ser justificado.
Ora, isto é impossível, pois tal conhecimento demanda longo tempo. Logo, parece que o ato de fé não é
necessário à justificação do ímpio.
Mas, em contrário, diz a Escritura: Justificados, pois, pela fé, tenhamos paz com Deus.

SOLUÇÃO. – Como já dissemos, a moção do livre arbítrio é necessária para a justificação do ímpio, pois a
alma do homem é movida por Deus. Ora, Deus move a alma humana convertendo-a para si, como diz a
Escritura, segundo outra versão: Ó Deus, tu voltado para nós, nos darás vida. Por onde, para a
justificação do ímpio, é necessária a moção da alma, que a faz converter-se para Deus. Ora, a conversão
para Deus dá-se, primeiramente, pela fé, conforme à Escritura: É necessário que o que se chega a Deus
creia que há Deus.Logo, a moção da fé é necessária à justificação do ímpio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A moção da fé não é perfeita senão informada pela
caridade; por isso, na justificação do ímpio essa moção é simultânea com a da caridade. Ora, o livre
arbítrio é movido para Deus afim de se lhe sujeitar; e, por isso, também concorre para tal fim o ato do
temor filial e o da humildade. Pois, pode se dar que um mesmo ato do livre arbítrio respeita a diversas
virtudes, enquanto uma ordena e outra seja ordenada, na medida em que o ato é susceptível de se
ordenar para fins diversos. Ora, o ato de misericórdia vai contra o pecado, a modo de satisfação, e assim
é consecutivo à justificação; ou a modo de preparação, enquanto que os misericordiosos alcançarão
misericórdia; e então pode preceder à justificação. Ou enfim, pode concorrer para esta, de par com as
virtudes referidas, enquanto a misericórdia está incluída no amor do próximo.

RESPOSTA À SEGUNDA. – Pelo conhecimento natural o homem não se converte para Deus, como objeto
da beatitude e causa da justificação. Por isso, tal conhecimento não basta para a justificação, Quanto ao
dom da sabedoria, ele pressupõe o conhecimento da fé, como do sobredito resulta.

RESPOSTA À TERCEIRA. – Como diz o Apóstolo, ao que crê naquele que justifica ao ímpio, a sua fé lhe é
imputada à justiça, segundo o decreto da graça de Deus. Por onde é claro, que, para a justificação do
ímpio é necessário o ato de fé, afim de ele crer que Deus justificou o homem pelo mistério de Cristo.

## Art. 5 — Se, para a justificação do ímpio, é necessária a moção do livre arbítrio contra o pecado.
(III, q. 86, a. 2; IV Sent., dist. XVII, q. 1, a. 3, qª 4; III Cont., Gent., cap. CLVIII; De Verit., q. 28, a. 5).
O quinto discute-se assim. – Parece que, para a justificação do ímpio, não é necessária a moção do
livre arbítrio contra o pecado.

1. – Pois, só a caridade basta para delir o pecado, segundo a Escritura: A caridade cobre todos os
delitos. Ora, o objeto da caridade não é o pecado. Logo, não é necessária, contra este, a moção do livre
arbítrio, para justificação do ímpio.

2. Quem marcha para a frente não deve olhar para traz, conforme aquilo do Apóstolo: Esquecendo-me,
por certo, do que fica para traz, e avançando-me ao que resta para o diante, prossigo, segundo o fim
proposto, ao prêmio da soberana vocação. Ora, a quem busca a justiça atrás lhe ficam os pecados
passados. Logo, deve esquecê-los, nem deve para eles se voltar, por moção do livre arbítrio.

3. Demais. – Na justificação do ímpio não se remite um pecado sem remitir o outro, pois é ímpio esperar
de Deus meio perdão. Se, pois, para justiçar-se, o ímpio tivesse de mover o seu livre arbítrio contra o
pecado, será necessário ter presente no espírito todos os seus pecados. Ora, isso é absurdo, quer
porque demandaria muito tempo uma tal atividade do pensamento; quer, porque o pecador não
poderia obter vênia dos pecados de que se esqueceu. Logo, o movimento do livre arbítrio, contra o
pecado, não é necessário, para a justificação do ímpio.
Mas, em contrário, diz a Escritura: Eu disse: Confessarei ao Senhor contra mim a minha injustiça; e tu me
perdoaste a impiedade do meu pecado.

SOLUÇÃO. – Como já dissemos, a justificação do ímpio é uma moção pela qual a alma humana é levada
por Deus, do estado do pecado, para o da justiça. Por onde, há de necessariamente o espírito, pela
moção do livre arbítrio, comportar-se, em relação a ambos os extremos, como se comporta um corpo,
movido localmente por um motor, em relação aos dois termos do movimento. Ora, é manifesto que, no
movimento local, o corpo movido se afasta do termo de origem e se aproxima do termo final. Por onde
necessariamente, alma humana, justificada, afasta-se pela moção do livre arbítrio, do pecado e
aproxima-se da justiça. Ora, em se tratando da moção do livre arbítrio, o afastamento e a aproximação
identificam-se com o detestar e o desejar. Pois, diz Agostinho, expondo aquilo da Escritura – o
mercenário, porém foge: - Os nossos afetos são moções da alma; a alegria é uma dilatação da alma; o
temor, a sua fuga; aproxima-se a vossa alma, quando desejais; foge, quando temeis. Logo, na
justificação do ímpio, há de haver dupla moção do livre arbítrio. Uma, pelo desejo, tende para a justiça
de Deus; e outra, pela qual detesta o pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – É próprio de uma mesma virtude buscar um dos opostos
e fugir de outro. Por onde, à caridade pertence, tanto amar a Deus, como detestar o pecado, pelo qual a
alma se separa de Deus.

RESPOSTA À SEGUNDA. – Ao passado o homem não deve voltar-se com amor. Mas, é melhor esquecê-
lo para não se lhe apegar. Deve porém tê-lo presente, afim de detestá-lo; e assim dele se afastar.

RESPOSTA À TERCEIRA. – No tempo precedente à justificação, é preciso o homem detestar cada um dos
pecados, que cometeu, e dos quais tenha lembrança. E dessa consideração precedente, resulta, na
alma, uma certa moção que detesta universalmente todos os pecados cometidos. Entre os quais
também se incluem os caídos no esquecimento. As disposições do pecador são então tais, que teria
contrição, mesmo dos pecados de que não se lembra, se eles lhe ocorressem à memória. E esse
movimento concorre para a justificação.

## Art. 6 — Se a remissão dos pecados deve ser enumerada entre as condições exigidas para a justificação do ímpio.
(IV. Sent., dist. XVII, q. 1, a. 3, qª 5).
O sexto discute-se assim. – Parece que a remissão dos pecados não deve ser enumerada entre as
condições exigidas para a justificação do ímpio.

1. – Pois, a substância de um ser não se inclui entre os elementos necessários à sua existência; assim o
homem não deve ser enumerado com a sua alma e o seu corpo. Ora, a justificação mesma do ímpio é a
remissão dos seus pecados, como já se disse. Logo, tal remissão não deve enumerada entre as
condições exigidas à justificação do ímpio.

2. Demais. – A infusão da graça se identifica com a remissão da culpa, assim como a iluminação, com a
exclusão das trevas. Ora, um objeto não deve ser enumerado consigo mesmo. Logo, a remissão da culpa
não deve ser enumerada com a infusão da graça.

3. Demais. – A remissão dos pecados resulta da moção do livre arbítrio para Deus e contra o pecado,
como o efeito, da causa; pois, os pecados são perdoados pela fé e pela contrição. Ora, um efeito não
deve ser enumerado junto com a sua causa; porque as partes constitutivas de uma determinada
enumeração são simultâneas por natureza. Logo, a remissão da culpa não deve fazer parte da mesma
enumeração em que entram as condições exigidas para a justificação do ímpio.
Mas, em contrário, na enumeração dos elementos constitutivos de um ser não se deve omitir o fim, que
é o mais importante em qualquer ser. Ora, a remissão dos pecados é o fim, na justificação do ímpio,
conforme à Escritura: Todo este fruto se reduz a que seja tirado o seu pecado. Logo, a remissão dos
pecados deve ser enumerada entre as condições exigidas para a justificação do ímpio.

SOLUÇÃO. – Quatro condições são exigidas para a justificação do ímpio: a infusão da graça, a moção do
livre arbítrio para Deus, por meio da fé; a moção do livre arbítrio contra o pecado, e a remissão da culpa.
E a razão disto está como já dissemos, em ser a justificação uma moção pela qual a alma é movida por
Deus, passando do estado da culpa para o da justiça. Ora, qualquer moção, pela qual um ser move
outro, requer as três condições seguintes. Primeiro, a moção do motor; segunda, o movimento do
móvel; terceira, a consumação do movimento, i. é, a consecução do fim. Ora, a moção divina é a graça
divina. A moção do livre arbítrio é dupla, compreendendo o afastamento do termo de origem e a
aproximação do termo de chegada. A consumação, ou a consecução do termo deste movimento, se
realiza pela remissão da culpa; e, então se consuma a justificação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Diz-se que a justificação do ímpio é a remissão mesma
dos pecados, porque todo movimento se especifica pelo seu termo. Contudo, a consecução desse termo
exige muitas outras condições, como do sobredito resulta.

RESPOSTA À SEGUNDA. – A infusão da graça e a remissão da culpa podem ser consideradas à dupla luz
– Primeiro, quanto à substância mesma do ato; e então, identificam-se; pois, pelo mesmo ato porque
Deus concede a graça perdoa a culpa. – Segundo, quanto aos seus objetos. E então, a culpa delida difere
da graça infusa; assim como, nos seres naturais, a geração e a corrupção diferem, embora o gerar-se de
um ser seja o corromper-se de outro.

RESPOSTA À TERCEIRA. – Não se trata agora da divisão de um gênero em suas espécies, caso em que as
partes da divisão hão de existir simultaneamente. Mas da diferença entre os elementos exigidos para
um ente ser completo; e nesse caso, podem uns ser anteriores ao outro, porque os elementos e as
partes de um composto podem ser anteriores uns aos outros.

## Art. 7 — Se a justificação do ímpio é instantânea ou sucessiva.
(IV Sent., dist. XVII, q. 1, a. 5, qª 2, 3; De Verit., q. 28, a. 2, ad 10: a.9).
O sétimo discute-se assim. – Parece que a justificação do ímpio não é instantânea, mas sucessiva.

1. – Pois, como já se disse, para a justificação do ímpio é necessária a moção do livre arbítrio. Ora, o ato
deste é escolher; o que preexige a deliberação do conselho, como já se estabeleceu. Ora, a deliberação,
implicando um certo discurso, que supõe a sucessão, parece que a justificação do ímpio é sucessiva.

2. Demais. – O movimento de livre arbítrio suplica uma reflexão atual. Ora, é impossível inteligir muitos
objetos simultânea e atualmente, como na Primeira Parte se estabeleceu. E como na justificação do
ímpio exigimos a moção do livre arbítrio para objetos diversos, isto é, para Deus e contra o pecado,
parece que tal justificação não pode ser instantânea.

3. Demais. – Uma forma susceptível de mais e de menos é recebida sucessivamente pelo sujeito, como
bem o demonstra o caso da brancura e da negrura. Ora, a graça é susceptível de mais e de menos, como
já se estabeleceu. Logo, não é recebida instantaneamente pelo sujeito. E como, para a justificação do
ímpio, é necessária a infusão da graça, parece que ela não pode ser instantânea.

4. Demais. – A moção do livre arbítrio, que concorre para a justificação do ímpio, é meritória; e
portanto, há de necessariamente proceder da graça, sem a qual não há nenhum mérito, como a seguir
se dirá. Ora, um ser recebe, primeiro, a sua forma, para depois, por meio dela, agir. Logo, primeiro, é
infundida a graça, para, depois, o livre arbítrio mover-se para Deus e detestar o pecado. Logo, a
justificação é total e simultânea

5. Demais. – Se a graça é infundida na alma, há de necessariamente, haver um momento em que ela aí
começou a existir. Semelhantemente, se a culpa é perdoada, há de, por força, haver um último instante
em que o homem ainda está no estado da culpa. Ora, não pode ser o mesmo instante para os dois
casos, porque, então, dois contrários coexistiriam. Logo, é necessário sejam os dois instantes sucessivos,
devendo então haver, entre eles, conforme diz o Filósofo, um tempo médio. Logo, a justificação não é
totalmente simultânea, mas sucessiva.
Mas, em contrário, a justificação do ímpio se faz pela graça do Espírito Santo, justificante. Ora, o Espírito
Santo advém subitamente ao espírito do homem, conforme a Escritura: E de repente veio do céu um
estrondo, como de vento, que assoprava com ímpeto. Ao que diz a Glosa: a graça do Espírito Santo não
conhece a lentidão dos grandes esforços. Logo, a justificação do ímpio não é sucessiva, mas instantânea.

SOLUÇÃO. – A justificação do ímpio consiste total e originalmente na infusão da graça, pela qual é
movido o livre arbítrio e perdoada a culpa. Ora, essa infusão se dá instantaneamente e sem sucessão. E
a razão é a seguinte. Uma forma não se imprime subitamente num sujeito, que para ela não está
disposto, precisando, por isso, o agente de tempo para dispor o sujeito. Por onde vemos que, logo que a
matéria está disposta, por uma alteração precedente, ela se une à forma substancial. Pela mesma razão,
como um corpo diáfano tem, por si mesmo, disposição para receber a luz, é subitamente iluminado por
um corpo atualmente lúcido. Ora, segundo já dissemos, Deus, para infundir a graça na alma, não exige
outra disposição senão a que Ele mesmo produz. Mas essa disposição, suficiente à recepção da graça.
Ele a opera, ora subitamente; ora, paulatina e sucessivamente, como já dissemos. Pois, o que impede
um agente natural de dispor a matéria é alguma desproporção entre a resistência da matéria e a virtude
do agente. E por isso, vemos que quanto mais forte for a virtude do agente, tanto mais prontamente
disporá a matéria. Ora, o poder divino é infinito. Pode, pois, dispor subitamente, para a forma qualquer
matéria criada; e com maior razão o livre arbítrio do homem, cuja moção pode, por natureza, ser
instantânea. Por onde, a justificação do ímpio Deus a opera instantaneamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A moção do livre arbítrio, que concorre para a justificação
do ímpio, é um consentimento em detestar o pecado e converter-se para Deus; e esse consentimento é
dado instantaneamente. Pode, porém, às vezes, preceder alguma deliberação, que não é da substância
da justificação, mas via para a mesma; assim como o movimento local é uma via para a iluminação, e a
alteração, para a geração.

RESPOSTA À SEGUNDA. – Como já dissemos na Primeira Parte, nada impede serem atual e
simultaneamente pensados dois objetos, que, de certo modo, se unificam. Assim, simultaneamente
inteligimos o sujeito e o predicado, enquanto unidos para formar uma só afirmação. Do mesmo modo, o
livre arbítrio pode mover-se simultaneamente para dois objetos, sendo um ordenado para o outro. Ora,
a moção do livre arbítrio contra o pecado se ordena para o que o leva para Deus; pois o homem detesta
o pecado por ser contrário a Deus, com quem quer unir-se. Por onde, o livre arbítrio, na justificação do
ímpio, simultaneamente detesta o pecado e se converte para Deus; assim como um corpo, afastando-se
de um lugar, aproxima-se, simultaneamente, de outro.

RESPOSTA À TERCEIRA. – A razão de uma forma não ser recebida, instantaneamente por uma certa
matéria, não é ser essa forma susceptível demais e de menos. Pois então, também a luz não seria
recebida instantaneamente pelo ar, que pode ser mais ou menos iluminado. Mas se deve buscar a razão
na disposição da matéria ou do sujeito, como já dissemos.

RESPOSTA À QUARTA. – No mesmo instante em que recebe a sua forma, o ser começa a agir, de
conformidade com ela; assim como o fogo, desde que foi gerado, move-se para cima e, se o seu
movimento fosse instantâneo, atingiria o seu lugar imediatamente. Ora, o movimento do livre arbítrio,
que é o querer, não é sucessivo, mas instantâneo. Logo, não é necessário seja a justificação do ímpio
sucessiva.

RESPOSTA À QUINTA. – A sucessão de dois contrários, no mesmo sujeito, deve ser considerada
diferentemente, segundo se trata de seres sujeitos ou não ao tempo. – Assim, pois, nos sujeitos ao
tempo, não há lugar para um último instante, em que a forma anterior ainda permanece no sujeito; há
porém, para um último tempo e para um primeiro instante em que a forma subseqüente já está
presente na matéria ou no sujeito. A razão disso é que, no tempo, não é possível haver um instante
imediatamente precedente a outro. Pois, o tempo não se compõe de instantes consecutivos, como de
pontos consecutivos não se compõe a linha, segundo o prova Aristóteles. Contudo, o tempo é limitado
pelo instante. Por onde, durante todo o tempo precedente, em que um ser se move para uma
determinada forma, permanece ligado à forma oposta. Só no último instante desse tempo, que é o
primeiro do tempo seguinte, une-se à forma, que constitui o termo do movimento. – Mas, é diferente o
caso dos seres fora do tempo. Pois, se há alguma sucessão de sentimento ou de pensamentos, p. ex.,
nos anjos, ela se mede por um tempo, não contínuo, mas, discreto, porque as realidades mesmas, que
são medidas, não são contínuas, conforme estabelecemos na Primeira Parte. Por onde, em tais casos, há
lugar para um último instante, em que subsistia o estado anterior e um primeiro em que já existe o
estado subseqüente. Nem é necessário haver um tempo médio, por não haver, no caso, continuidade
do tempo, que o exigiria. – Ora, a alma humana, justificada, está por essência fora do tempo, embora
lhe esteja acidentalmente sujeita, por inteligir em dependência do contínuo e do tempo, por meio dos
fantasmas, nos quais considera as espécies inteligíveis, como dissemos na Primeira Parte. Por onde,
devemos considerar-lhe as mudanças de acordo com a condição dos movimentos temporais. E então,
diremos que não há um último instante, em que a alma ainda se conserve em estado de pecado, mas
um último tempo. Ao contrário, há um primeiro instante, em que já está em estado de graça, enquanto
que estava, em todo o tempo precedente, em estado de culpa.

## Art. 8 — Se a infusão da graça é, na ordem da natureza, a primeira das condições exigidas para a justificação do ímpio.
(IV Sent., dist. XVII, q. 1. A. 4; De Verit., q. 28, a. 7,8).
O oitavo discute-se assim. – Parece que a infusão da graça não é, na ordem da natureza, a primeira
das condições exigidas para a justificação do ímpio.

1. – Pois, o afastamento do mal precede à pratica do bem, conforme a Escritura: Desvia-te do mal e faze
o bem. Ora, a remissão da culpa implica o afastamento do mal; ao passo que a infusão da graça, a
persecução no bem. Logo, a remissão da culpa é naturalmente anterior à infusão da graça.

2. Demais. – A disposição precede naturalmente à forma a que se destina. Ora, a moção do livre arbítrio
é uma disposição para receber a graça. Logo, precede naturalmente a infusão dela.

3. Demais. – O pecado impede a alma de tender livremente para Deus. Ora, antes de se realizar um
movimento, é preciso remover-lhe os obstáculos. Logo, a remissão da culpa e a moção do livre arbítrio
contra o pecado são naturalmente anteriores à moção do livre arbítrio para Deus e à infusão da graça.
Mas, em contrário. – A causa é naturalmente anterior ao seu efeito. Ora, a infusão da graça é a causa de
tudo o mais necessário à justificação do ímpio, como já se disse antes. Logo é naturalmente anterior.

SOLUÇÃO. – As quatro condições referidas, para a justificação do ímpio são simultâneas no tempo, pois
essa justificação não é sucessiva, como já dissemos; mas, na ordem da natureza, uma é anterior às
outras. Assim, nessa ordem, a primeira dentre elas é a infusão da graça; a segunda, a moção do livre
arbítrio para Deus; a terceira, a moção do livre arbítrio contra o pecado; a quarta enfim, a remissão da
culpa.
E a razão é que, em qualquer movimento vem naturalmente em primeiro lugar, a moção do motor;
depois, a disposição da matéria, ou o movimento do móvel; e por último, o fim ou o termo do
movimento, em que termina a moção do motor. Ora, a moção de Deus, enquanto motor, é a infusão da
graça, como já dissemos; o movimento ou a disposição do móvel é a dupla moção do livre arbítrio;
ultimamente, o termo ou o fim do movimento é a remissão da culpa, como do sobredito resulta. Por
onde, em ordem natural, a infusão da graça vem em primeiro lugar, na justificação do ímpio. Em
segundo, a moção do livre arbítrio para Deus. Em terceiro, a moção do livre arbítrio contra o pecado,;
pois quem é justificado detesta o pecado, por ser contrário a Deus. Por isso, a moção do livre arbítrio
para Deus procede naturalmente ao do livre arbítrio contra o pecado, pois aquele é a causa e a razão
deste. Em quarto e último lugar, está a remissão da culpa, para a qual, como para o fim, se ordena essa
transformação, segundo ficou dito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O afastamento e a aproximação do termo podem-se
considerar à dupla luz. – Primeiro, relativamente ao móvel. E assim, naturalmente, o afastamento
precede ao aproximar-se do termo. Pois, no móvel, o contrário excluído é anterior ao que o móvel
busca, pelo seu movimento. – Quanto ao agente, porém dá-se o inverso. Pois, o agente, pela forma nele
preexistente, age afim de remover o contrário. Assim como o sol, pela sua luz, age para remover as
trevas; por isso, deve ele, antes de expulsar as trevas, iluminar. O ar iluminado, por seu lado; e segundo
a ordem natural deve, antes de receber a luz, purificar-se das trevas, embora esses dois fenômenos
sejam temporalmente simultâneos. – E como a infusão da graça e a remissão da culpa dependem de
Deus, que justifica, aquela é, na ordem da natureza, anterior a esta. Se porém considerarmos o homem
justificado, dá-se o inverso: primeiro, na ordem da natureza, está a libertação da culpa e depois, a
consecução da graça justificante. – Ou, pode-se dizer que os termos da justificação – a culpa como
origem, e a justiça, como fim. Enquanto que a graça é a causa da remissão da culpa e da obtenção da
justiça.

RESPOSTA À SEGUNDA. – A disposição do sujeito precede, na ordem natural, à recepção da forma; é
consecutiva, porém, à ação do agente, pela qual também o sujeito mesmo é disposto. Por onde, a
moção do livre arbítrio precede naturalmente à consecução da graça; é consecutivo porém à infusão
dela.

RESPOSTA Á TERCEIRA. – Como diz o Filósofo, nos movimentos da alma, o que sobe ao principio da
especulação, ou tende ao fim de uma ação, é absolutamente o primeiro. Mas, nos movimentos
exteriores, a remoção do obstáculo precede à consecução do fim. E sendo a moção do livre arbítrio uma
moção da alma, esta, primeira e naturalmente, há de mover-se para Deus, como para o fim, e depois
remover o obstáculo do pecado.

## Art. 9 — Se a justificação do ímpio é a máxima obra de Deus.
(III, q. 43, a. 4, ad 2; IV Sent., dist. XVII, q. 1, a. 5, qª 1, ad 1, 2; dist. XLVI, q. 2, a. 1, qª 3, ad 2; In Ioan.,
cap. XIV. Lect. III).
O nono discute-se assim. – Parece que a justificação do ímpio não é a máxima obra de Deus.

1. – Pois, pela justificação, o ímpio consegue a graça nesta vida. Ora, pela glorificação, seguimos a glória
da pátria, que é maior. Logo, a glorificação dos anjos ou dos homens é obra maior que a justificação do
ímpio.

2. Demais. – A justificação do ímpio ordena-se ao seu bem particular. Ora, o bem do universo é melhor
que o de um só homem, como está claro em Aristóteles. Logo, maior obra é a criação do céu e da terra
que a justificação do ímpio.

3. Demais. – Fazer algo do nada e sem a cooperação de nenhum agente, é maior obra que fazer uma
coisa, de outra, como a cooperação de um paciente. Ora, a obra da criação faz algo do nada, e, portanto,
sem a cooperação de nenhum agente. Ao passo que, na justificação do ímpio, Deus faz uma coisa, de
outra, i. é, do ímpio, um justo. E há ai uma cooperação por parte do homem, porque há a moção do livre
arbítrio, como já se disse. Logo, a justificação do ímpio não é a máxima obra de Deus.
Mas, em contrário, diz a Escritura: as suas misericórdias são sobre todas as suas obras. E a Coleta diz:
Deus, que manifestas a tua onipotência sobretudo perdoando e fazendo misericórdia. E Agostinho
expondo o lugar da Escritura – Fará outras coisas ainda maiores: - é maior obra fazer do ímpio um justo,
que criar o céu e a terra.

SOLUÇÃO. – De dois modos podemos dizer que uma obra é grande. – Quanto ao modo de agir e então a
maior obra é a da criação, em que o ser foi feito do nada. – Ou quanto à grandeza da obra. E neste
sentido maior obra é a justificação do ímpio, que termina pelo bem eterno da participação divina, do
que a criação do céu e da terra, que termina no bem da natureza mutável. Por isso, Agostinho, depois
de ter dito, que maior obra é fazer do ímpio um justo, que criar o céu e a terra, acrescenta: O céu e a
terra passarão; porém a salvação e a justificação dos predestinados permanecerão.
Mas é preciso não esquecer que há duas espécies de grandeza. – Uma é a de quantidade absoluta. E
então, o dom da glória é maior que o da graça, justificava do ímpio. Por isso a glorificação dos justos é
maior obra que a justificação do ímpio. – Outra espécie de grandeza é a de quantidade proporcional;
assim, dizemos que um monte é pequeno e um grão de milho é grande. E então, o dom da graça
justificava do ímpio é maior que o da glória, que beatifica o justo. Porque o dom da graça excede mais à
dignidade do ímpio, que era digno da pena, que o dom da glória à dignidade do justo, que pelo fato
mesmo de ter sido justificado é digno da glória. Por isso, Agostinho diz no mesmo lugar: Julgue quem
puder, se é maior obra criar os anjos justos, que justifica os ímpios. Por certo, se ambos os casos exigem
poder igual, o último exige maior misericórdia.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. – O bem do universo é melhor que o do indivíduo, um e outro considerados no
mesmo gênero. Mas o bem da graça é, para o indivíduo, melhor que o da natureza, para todo o
universo.

RESPOSTA À TERCEIRA. – A objeção colhe quanto ao modo de agir, pelo qual a criação é a maior obra de
Deus.

## Art. 10 — Se a justificação do ímpio é obra milagrosa.
(I, q. 105, a. 7, ad 1; II Sent., dist. XVIII, q. 1, a. 3 ad 2; IV, dist. XVII, q. 1, a. 5).
O décimo discute-se assim. – Parece que a justificação do ímpio é obra milagrosa.

1. – Pois, as obras milagrosas são maiores que as não milagrosas. Ora, a justificação do ímpio é maior
obra que as outras, que são milagrosas, como claramente o diz Agostinho no lugar referido. Logo, a
justificação do ímpio é uma obra milagrosa.

2. Demais. – O movimento da vontade está na alma, como a inclinação natural, nos seres da natureza. E
só operando milagrosamente é que Deus age sobre os seres naturais, contra a inclinação da natureza.
Assim, quando dá a vista a um cego ou ressuscita um morto. Ora, a vontade do ímpio tende para o mal.
Por onde, como Deus, ao justificar o homem, move-o para o bem, parece que a justificação do ímpio é
milagrosa.

3. Demais. – Como a sabedoria, também a justiça é um dom de Deus. Ora, por milagre é que alguém
subitamente e sem estudo, recebe de Deus a sabedoria. Logo, milagrosamente é o ímpio justificado por
Deus.
Mas, em contrário. – As obras milagrosas são superiores ao poder natural. Ora, justificação do ímpio não
o é, pois, diz Agostinho: O homem, por natureza, pode ter tanto a fé como a caridade; mas os fiéis, pela
graça, é que tem a fé, como a caridade. Logo, a justificação do ímpio não é milagrosa.

SOLUÇÃO. – Costuma-se distinguir três elementos nas obras milagrosas. – Um, dependente do poder do
agente, é que só o poder divino pode fazer milagres. Por isso, estes nos surpreendem de todo, como
tendo uma causa oculta, conforme já dissemos na Primeira Parte. E assim, tanto a justificação do ímpio,
como a criação do mundo e, universalmente, todas as obras que só a Deus cabe fazer, podem chamar-se
milagrosas.
Em segundo lugar, em certas obras milagrosas, se dá que a forma impressa é superior ao poder natural
da matéria de que se trata. Assim, na ressurreição de um morto, a vida excede o poder natural do corpo
ressurreto. E a este respeito, a justificação do ímpio não é milagrosa, por ser naturalmente a alma capaz
da graça. Pois, no dizer de Agostinho, por isso mesmo que é feita à imagem de Deus, a graça a torna
capaz de ver a Deus.
Em terceiro lugar, há, nas obras milagrosas, algo de contrário à ordem habitual e ordinária, segundo a
qual a causa produz o efeito. Assim, quando um doente adquire subitamente a saúde perfeita, contra o
curso habitual da cura, operada pela natureza ou pela arte. E então, a justificação do ímpio é, ora,
milagrosa e, ora, não. Pois, o curso comum e habitual da justificação é que Deus, movendo
interiormente a alma, o homem se lhe converta, primeiro, por uma conversão imperfeita, que, depois,
vem a ser perfeita. Pois, a caridade começada merece ser aumentada para que, assim, mereça chegar à
perfeição, como diz Agostinho. Outras vezes, porém, Deus move a alma tão veementemente, que ela de
pronto chega a uma certa perfeição da justiça. Tal se deu com a conversão de Paulo, em que ele, por
milagre, ficou até mesmo exteriormente prostrado; e por isso a sua conversão é comemorada pela
Igreja como milagrosa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora certas obras milagrosas sejam, quanto ao bem
que encerram, menores que a justificação do ímpio, contrariam, contudo, a ordem habitual de tais
efeitos. E portanto, constituem, mais que os outros, milagres.

RESPOSTA À SEGUNDA. – Não há milagre sempre que um ser natural se move, contra a sua inclinação;
do contrário, seria milagre o aquecer-se a água ou uma pedra ser atirada para cima. Milagre há quando
um efeito se realiza, contra a ordem regular da causa própria, que, por natureza, o produz. Ora,
nenhuma outra causa há da justificação do ímpio, senão Deus, assim como só o fogo é a causa do
aquecimento da água. Portanto, a esta luz, a justificação do ímpio não é milagrosa.

RESPOSTA À TERCEIRA. – É natural ao homem adquirir a sabedoria e a ciência, de Deus, por meio do seu
engenho e estudo próprios. Por isso, há milagre quando, por outro modo, o homem se torna sapiente
ou sábio. Ao passo que não lhe é natural adquirir, por operação própria, a graça justificante, senão por
ação de Deus. Logo, os casos não são semelhantes.