# Questão 74: Do sujeito dos pecados.
Em seguida devemos tratar do sujeito dos vícios ou dos pecados. E sobre esta questão discutem-se dez
artigos:

## Art. 1 — Se a vontade pode ser sujeito do pecado.
O primeiro discute-se assim. ― Parece que a vontade não pode ser sujeito do pecado.

1. ― Pois, como diz Dionísio, o mal é contrário à vontade e à intenção. Ora, o pecado constitui um mal.
Logo, não pode existir na vontade.

2. Demais. ― A vontade busca o bem ou a aparência dele. Ora, querendo o bem, não peca; e o querer o
bem aparente, que não é verdadeiramente bem, pertence a uma deficiência, antes, da virtude
apreensiva, que da vontade. Logo, nesta o pecado de nenhum modo existe.

3. Demais. ― Não se pode identificar o sujeito e a causa eficiente do pecado; porque a causa eficiente e
a material não têm a mesma incidência, como diz Aristóteles. Ora, a vontade é causa eficiente do
pecado; pois, no dizer de Agostinho, a primeira causa do pecado é a vontade. Logo, esta não é sujeito do
mesmo.
Mas, em contrário, diz Agostinho, que, pela vontade, pecamos e vivemos retamente.

SOLUÇÃO. ― Como já dissemos (q. 21, a. 1; q. 71, a. 1, 6), o pecado é um ato. Ora, há atos transitivos
para a matéria exterior, como queimar e cortar. E a matéria e o sujeito desses é aquilo sobre o que lhes
recai a ação; assim, o Filósofo diz, que o movimento é o ato do móvel, procedente do motor. Outros
atos porém não são transeuntes para a matéria exterior, mas permanecem no agente, como desejar e
conhecer; e esses são todos atos morais, quer sejam de virtudes, quer de pecados. Por onde e
necessariamente, o sujeito próprio do ato pecaminoso é a potência, que é princípio do mesmo. Ora,
como é próprio dos atos morais o serem voluntários, segundo já estabelecemos (q. 1, a. 1; q. 18, a. 6, 9),
resulta que a vontade, princípio dos atos voluntários, bons ou maus, que são os pecados, é princípio
destes. Donde se conclui, que o pecado está na vontade como no sujeito.DONDE A RESPOSTA À

PRIMEIRA OBJEÇÃO. ― Diz-se que o mal é contrário à vontade, porque esta não tende para ele, como
tal. Mas como há males que são bens aparentes, a vontade deseja às vezes algum mal; e deste modo há
nela mal.

RESPOSTA À SEGUNDA. ― Se a deficiência da faculdade apreensiva de nenhum modo dependesse da
vontade, seguir-se-ia a não existência do pecado, nem nesta nem naquela, como é o caso dos que
laboram em ignorância invencível. Donde se conclui que também a deficiência da faculdade apreensiva,
dependente da vontade, contribui para o pecado.

RESPOSTA À TERCEIRA. ― A objeção colhe no atinente às causas eficientes, cujas ações, transitivas para
a matéria exterior, não se movem a si mesmas, mas a outros móveis. Ora, o contrário se dá com a
vontade. Logo, a objeção não procede.

## Art. 2 — Se só a vontade é sujeito do pecado.
(IIa IIae, q. 10, a. 2; II Sent., dist. XLI, q. 2, a. 2; De Malo q. 7, a. 6)
O segundo discute-se assim. ― Parece que só a vontade é sujeito do pecado.

1. ― Pois, como diz Agostinho, só pela vontade é que pecamos. Ora, o pecado está, como no sujeito, na
potência pela qual pecamos. Logo, só a vontade é sujeito do pecado.

2. Demais. ― O pecado é um mal contrário à razão. Ora o bem e o mal da razão constituem o objeto só
da vontade. Logo, só esta é o sujeito do pecado.

3. Demais. ― Todo pecado é um ato voluntário; pois, como diz Agostinho, o pecado é voluntário a ponto
tal que, se não o for, não será pecado. Ora, os atos das outras potências não são voluntários senão na
medida em que são movidas pela vontade. Mas isto não basta para serem sujeitos do pecado; porque,
do contrário, sujeitos do pecado também seriam os membros corpóreos, que são movidos pela vontade;
o que é manifestamente falso. Logo, só a vontade é sujeito do pecado.
Mas, em contrário. ― O pecado é contrário à virtude. Ora, os contrários não podem coexistir no mesmo
sujeito. Mas, as outras potências da alma, além da vontade, também são sujeitos das virtudes, conforme
já se estabeleceu (q. 66, a. 3, 4). Logo, nem só a vontade é sujeito do pecado.

SOLUÇÃO. ― Como do sobredito claramente se colhe (a. 1), tudo o que é princípio do ato voluntário é
sujeito do pecado. Ora, consideram-se atos voluntários não só os elícitos da vontade, mas também os
imperados por ela, como já dissemos (q. 6, a. 4), quando tratamos do voluntário. Por onde, não só a
vontade pode ser sujeito do pecado, mas também todas as potências que, por ela, podem ser levadas
para os seus atos, ou, por ela mesma, afastadas deles. E também essas potências são sujeitos dos
hábitos morais bons ou maus, pois atos e hábitos têm o mesmo sujeito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Não pecamos senão pela vontade, considerada esta
como primeiro motor; mas pecamos também pelas outras potências, como por ela movidas.

RESPOSTA À SEGUNDA. ― O bem e o mal residem na vontade como sendo por si mesmos objetos dela.
Mas as outras potências são suscetíveis de algum bem e algum mal determinado; em virtude disso,
pode nelas existir virtude, vício e pecado, na medida em que participem da vontade e da razão.

RESPOSTA À TERCEIRA. ― Os membros do corpo não são princípios dos atos mas somente órgãos; por
isso são o como escravo da alma motora, que é mandado e não manda. Ao passo que as potências
apetitivas interiores se relacionam com a razão, como livres, por mandarem, de certo modo, e serem
mandadas, como claramente resulta do que diz Aristóteles. E além disso, os atos dos membros
corpóreos são ações transeuntes para a matéria exterior; como bem claramente o mostra o ferimento
mortal, no pecado de homicídio. Por isso o símile não colhe.

## Art. 3 — Se na sensualidade pode haver pecado.
(II Sent., dist. XXIV, q. 3, a. 2; De Verit., q. 25, a. 5; De Malo q. 7, a. 6; Quodl. IV q. 11, a. 1)
O terceiro discute-se assim. ― Parece que na sensualidade não pode haver pecado.

1. ― Pois, o pecado é próprio do homem, louvado ou vituperado, conforme os seus atos. Ora, a
sensualidade nos é comum com os brutos. Logo, não pode nela haver pecado.

2. Demais. ― Ninguém peca pelo que não pode evitar, como diz Agostinho. Ora, o homem não pode
evitar o desordenado do ato da sensualidade; pois esta se funda numa radical corrupção, enquanto
vivemos esta vida mortal; e por isso, ela é representada pela serpente, no dizer de Agostinho. Logo, a
desordem do movimento sensual não é pecado.

3. Demais. ― O que não fazemos não se nos pode imputar como pecado. Ora, considera-se como feito
por nós mesmos o que fazemos com deliberação racional, conforme diz o Filósofo. Logo, o movimento
da sensualidade, onde não há deliberação racional, não se nos pode imputar como pecado.
Mas, em contrário, diz a Escritura (Rm 7, 19): Porque eu não faço o bem que quero; mas faço o mal, que
não quero, o que Agostinho refere ao mal da concupiscência, que sabemos ser um movimento da
sensualidade. Logo, esta é suscetível de pecado.

SOLUÇÃO. ― Como já dissemos (a. 2), pode haver pecado em qualquer potência, cujo ato pode ser
voluntário e desordenado; e nisso consiste a essência do pecado. Ora, é manifesto, que o ato da
sensualidade pode ser voluntário, na medida em que a ela, i. é, ao apetite sensitivo, lhe é natural ser
movido pela vontade. Donde se conclui que na sensualidade pode haver pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Certas virtudes da parte sensitiva, embora nos sejam
comuns com os brutos, têm contudo em nós, alguma excelência, por coexistirem com a razão. Assim,
superiores a eles, temos, na parte sensitiva, a cogitativa e a reminiscência, como dissemos na Primeira
Parte (q. 78, a. 4). E deste modo também o nosso apetite sensitivo, superior ao dos brutos, tem certa
excelência, a saber, o lhe ser natural obedecer à razão. E a esta luz, pode ser princípio do ato voluntário
e, por conseqüência, sujeito do pecado.

RESPOSTA À SEGUNDA. ― A radical corrupção da sensualidade deve ser entendida quanto ao aguilhão
do pecado, que nunca se embota totalmente nesta vida; pois, passado quanto ao reato, o pecado
original permanece atual. Mas essa corrupção, do atrativo pelo pecado, não impede possamos, com
vontade racional, reprimir todos movimentos desordenados da sensualidade, quando pressentidos; por
exemplo, desviando o pensamento para outros objetos. Mas, enquanto o fazemos, pode surgir em nós
algum movimento desordenado, no tocante ao primeiro objeto. Assim, quando, querendo evitar o
movimento da concupiscência, transferimos o pensamento, dos prazeres carnais, para a especulação
científica, pode surgir, às vezes em nós algum movimento de vã glória não premeditado. Por onde, não
podemos evitar todos esses movimentos, por causa da referida corrupção. Mas já basta, só por si, para a
essência do pecado voluntário, que possamos evitar cada um desses movimentos.

RESPOSTA À TERCEIRA. ― O que fazemos sem deliberação racional não o fazemos perfeitamente;
porque nisso não atua nada do que em nós é principal. Por onde, o nosso ato não é um ato humano
perfeito. E por conseqüência, não pode haver, no caso, um ato perfeito mais só imperfeito, de virtude
ou pecado. Por isso o movimento da sensualidade, que surpreende a razão, é pecado venial, algo de
imperfeito no gênero pecado.

## Art. 4 — Se na sensualidade pode haver pecado mortal.
(II Sent., dist. XXIV; q. 3, a. 2, ad 3; De Verit., q. 25, a. 5; De Malo, q. 7, a. 6; Quodl. IV, q. 11, a. 1)
O quarto discute-se assim. ― Parece que na sensualidade pode haver pecado mortal.

1. ― Pois, o ato é conhecido pelo seu objeto. Ora, podemos pecar mortalmente em relação aos objetos
da sensualidade; assim, relativamente aos prazeres da carne. Logo, um ato da sensualidade pode ser
pecado mortal, que portanto, pode existir na sensualidade.

2. Demais. ― O pecado mortal é contrário à virtude. Ora, esta pode existir na sensualidade; pois, a
temperança e a fortaleza são virtudes das partes irracionais, como diz o Filósofo. Logo, na sensualidade
pode haver pecado mortal, pois é natural dos contrários coexistirem no mesmo sujeito.

3. Demais. ― O pecado venial é uma disposição para o mortal. Ora, a disposição e o hábito coexistem no
mesmo sujeito. Mas, existindo o pecado venial na sensualidade, como já se disse, nela também pode
existir o mortal.
Mas, em contrário, diz Agostinho, e está na Glosa da Escritura, o movimento desordenado da
concupiscência,i. é, o pecado da sensualidade, pode existir também nos que estão em graça, nos quais,
entretanto, não existe pecado mortal. Logo, o movimento desordenado da sensualidade não é pecado
mortal.

SOLUÇÃO. ― Assim como a desordem corruptora do princípio da vida corpórea causa a morte do corpo,
assim a que corrompe o princípio da vida espiritual, que é o fim último, causa a morte espiritual do
pecado mortal, como já dissemos (q. 72, a. 5). Ora, ordenar alguma coisa para o fim não pertence à
sensualidade, mas só à razão. Por outro lado, o afastar-se do fim também só pertence a quem pode
ordenar para ele. Logo, o pecado mortal não pode existir na sensualidade, mas, só na razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O ato da sensualidade pode concorrer para o pecado
mortal; mas o ato deste não é mortal pelo que há nele de sensualidade, senão pelo que tem de racional,
pois, à razão compete ordenar para o fim. Por onde, o pecado mortal não se atribui à sensualidade mas
à razão.

RESPOSTA À SEGUNDA. ― O ato virtuoso não o é completamente só pelo que há nele de sensualidade;
mas antes, pelo que contém de razão e de virtude, à qual é próprio o escolher; pois, o ato da virtude
moral não vai sem a eleição. Por onde e sempre, esse ato, moralmente virtuoso, que aperfeiçoa a
potência apetitiva, é acompanhado do ato da prudência, que aperfeiçoa a potência racional. E o mesmo
se dá também com o pecado mortal, como já dissemos.

RESPOSTA À TERCEIRA. ― A disposição mantém tríplice relação com o sujeito disposto. Às vezes, ambos
se identificam e coexistem no mesmo sujeito; assim, dizemos que a ciência incoada é a disposição para a
ciência perfeita. Outras vezes, coexistem no mesmo sujeito, mas não se identificam; assim, o calor é a
disposição para a forma ígnea. Outras vezes enfim nem se identificam, nem coexistem no mesmo
sujeito, como se dá com coisas que se ordenam umas para as outras, de modo a ser um meio para se
chegar à outra; assim, a bondade da imaginação é uma disposição para a ciência, existente no intelecto.
Ora, deste modo, o pecado venial, existente na sensualidade, pode ser uma disposição para o pecado
mortal, residente na razão.

## Art. 5 — Se o pecado pode existir na razão.
(II Sent., dist. XXIV, q. 3 a. 3).
O quinto discute-se assim. ― Parece que o pecado não pode existir na razão.

1. ― Pois, o pecado de uma potência é um defeito da mesma. Ora, o defeito na razão não é pecado, mas
antes, excusa dele; assim, a ignorância nos desculpa do pecado. Logo, na razão não pode haver pecado.

2. Demais. ― O sujeito primeiro do pecado é a vontade, como já se disse (a. 1). Ora, a razão, sendo a
que dirige a vontade, tem precedência sobre ela. Logo, não pode haver pecado na razão.

3. Demais. ― Não pode haver pecado senão relativamente ao que existe em nós. Ora, a perfeição e a
deficiência da razão não são coisas que estejam em nós; assim, certos têm a razão deficiente ou solerte.
Logo, não há pecado na razão.
Mas, em contrário, diz Agostinho, que o pecado reside na razão inferior e na superior.

SOLUÇÃO. ― O pecado de uma potência consiste no ato da mesma, como do sobredito resulta (a. 1, 2,
3). Ora, a razão é suscetível de duplo ato. Um lhe pertence por si mesma e é relativo ao seu objeto
próprio, que é conhecer a verdade. O outro lhe pertence enquanto diretiva das outras potências. ― Ora,
de um e de outro modo pode haver pecado na razão. Do primeiro, quando ela erra no conhecimento da
verdade; em cujo caso o pecado lhe é imputado, se nutria ignorância ou erro no tocante ao que podia
ou devia saber. Do segundo, quando impera, ou também não reprime, após a deliberação, os atos
desordenados das potências inferiores.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção procede, relativamente ao defeito da razão,
pertinente ao seu ato próprio, que lhe respeita o objeto próprio. E então, quando há defeito do
conhecimento daquilo que não podemos saber, esse defeito não é pecado, mas antes, o excusa; e tal é o
caso dos atos cometidos pelos loucos. Se porém o defeito da razão disser respeito ao que podemos e
devemos saber, então não ficamos totalmente isentos de pecado, mas esse defeito mesmo nos é
imputado como pecado. O defeito porém, que só está em dirigir as outras potências, sempre nos é
imputado como pecado, porque pelo próprio ato podíamos obviar a ele.

RESPOSTA À SEGUNDA. ― Como já dissemos (q. 17, a. 1), quando tratamos dos atos da vontade e da
razão, a vontade, de certo modo, move a razão e a precede; mas também esta, de certo modo, precede
àquela. Por onde, o movimento da vontade pode ser chamado racional, e o ato racional, voluntário. E a
esta luz, a razão é suscetível de pecado, quer por ser o seu defeito voluntário, quer por ser ela princípio
do ato da vontade.

RESPOSTA À TERCEIRA. ― Resulta clara do que ficou dito.

## Art. 6 — Se o pecado da deleitação morosa reside na razão.
(II Sent., dist. XXIV, q. 3, a. 1)
O sexto discute-se assim. ― Parece que o pecado da deleitação morosa não reside na razão.

1. ― Pois, a deleitação implica movimento da potência apetitiva, como já se disse (q. 31, a. 1). Ora, a
potência apetitiva distingue-se da razão, que é uma potência apreensiva. Logo, a deleitação morosa não
reside na razão.

2. Demais. ― Pelos objetos podemos conhecer a que potência um ato pertence, por que potência ele se
ordena ao seu objeto. Ora, a deleitação morosa versa às vezes sobre os bens sensíveis e não, sobre os
racionais. Logo, o pecado da deleitação morosa não reside na razão.

3. Demais. ― Chama-se moroso ao que tem diuturnidade temporal. Ora, esta não é a razão de
pertencer um ato a uma determinada potência. Logo, a deleitação morosa não pertence à razão.
Mas, em contrário, diz Agostinho, consentir no pensamento sensual limitando-nos só à deleitação do
pensamento, seria como se só a mulher tivesse comido o fruto proibido. Ora, por mulher entende-se a
razão inferior, como ele próprio o expõe, no lugar citado. Logo, o pecado da deleitação morosa está na
razão.

SOLUÇÃO. ― Como já dissemos (a. 5), o pecado pode por certo existir às vezes na razão, como diretiva
dos atos humanos. Ora, é manifesto que ela o é, não só dos atos exteriores, mas também, das paixões
interiores. E portanto, quando ela falha, na direção destas, diz-se que há pecado nela, do mesmo modo
que quando falha na direção dos atos exteriores. Ora, de duas maneiras ela pode falhar na direção das
paixões interiores. Ou excitando paixões ilícitas, como quando deliberadamente provocamos em nós o
movimento da ira ou da concupiscência; ou não reprimindo o movimento ilícito da paixão, como
quando, depois de termos deliberado que é desordenado o ato nascente da paixão, contudo, nele nos
demoramos sem o rechaçarmos. E deste modo se diz que o pecado da deleitação morosa reside na
razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Por certo que a deleitação tem na potência apetitiva,
seu princípio próprio; ao passo que, na razão está como no princípio motor. Isto de acordo com o que já
dissemos (a. 1), a saber, que, as ações não transitivas para a matéria exterior estão, como no sujeito,
nos seus princípios.

RESPOSTA À SEGUNDA. ― O ato próprio elícito da razão recai sobre o objeto próprio dela; mas a sua
direção recai sobre todos os objetos das potências inferiores, que podem ser dirigidas pela razão. E a
esta luz, também a deleitação relativa aos objetos sensíveis pertence à razão.

RESPOSTA À TERCEIRA. ― Chama-se morosa à deleitação, não pela demora temporal, mas porque a
razão deliberante se demora nela, sem contudo a repelir, retendo e revolvendo deliberadamente no
pensamento aquilo que devia ser rechaçado assim que nos atingisse a alma, como diz Agostinho.

## Art. 7 — Se o pecado do consentimento no ato reside na razão superior.
(Supra, q. 15, a. 4; II Sent., dist. XXIV, q. 3, a. 1; De Verit., q. 15, a. 3)
O sétimo discute-se assim. ― Parece que o pecado do consentimento no ato não reside na razão
superior.

1. ― Pois, consentir é ato da virtude apetitiva, como já se estabeleceu (q. 15, a. 1). Ora, a razão é uma
faculdade apreensiva. Logo, o pecado de consentimento no ato não reside na razão superior.

2. Demais. ― A razão superior se dirige a observar e a consultar as razões eternas, como diz Agostinho.
Ora, às vezes consentimos nos atos, sem consultarmos as razões eternas; pois, nem sempre pensamos
nas coisas divinas, quando consentimos num ato. Logo, o pecado de consentimento no ato nem sempre
está na razão superior.

3. Demais. ― Assim como, pelas razões externas, podemos regular os atos exteriores, assim também
podemos por elas regular os prazeres interiores ou outras paixões. Ora, o consentimento no prazer, sem
a intenção de o consumarmos pela obra, pertence à razão inferior, como diz Agostinho. Logo, também o
consentimento no ato do pecado deve ser atribuído, às vezes, à razão inferior.

4. Demais. ― Assim como a razão superior excede a inferior, assim a razão excede a potência
imaginativa. Ora, às vezes, procedemos ao ato pela apreensão da potência imaginativa, sem qualquer
deliberação da razão; tal é o caso quando, sem premeditação, movemos a mão ou o pé. Logo, também
às vezes a razão inferior pode consentir no ato do pecado, sem a razão superior.
Mas, em contrário, diz Agostinho: Se, no consentimento de usar mal das coisas percebidas pelos
sentidos corpóreos, de tal modo nos determinamos a um pecado, que, se pudermos, o levaremos a
termo no corpo, devemos então entender que a mulher deu ao marido o pomo proibido; por onde se
representa a razão superior. Logo, a esta pertence consentir no pecado.

SOLUÇÃO. ― O consentimento implica um certo juízo relativo àquilo em que consentimos. Pois, assim
como a razão especulativa julga e sentencia sobre o inteligível, assim, a razão prática julga e sentencia
sobre o que devemos fazer. Devemos porém considerar que, em todo juízo, a sentença última pertence
ao supremo tribunal; assim vemos que, na ordem especulativa, a decisão última sobre uma proposição é
dada pela sua resolução aos primeiros princípios. E enquanto existir um principio mais alto, ainda é
possível examinarmos, à sua luz, o objeto em discussão; e portanto, fica suspenso o juízo até ser dada a
sentença final. Ora, é manifesto, que os atos humanos podem ser regulados pela regra da razão
humana, deduzida das coisas criadas, que podemos conhecer naturalmente; e, ulteriormente, pela regra
da lei divina, como já dissemos (q. 19, a. 4). E como a lei divina é superior, por conseqüência a última
sentença, que finalmente termina o juízo, pertença à razão superior, conhecedora das razões eternas.
Mas quando são várias as coisas a serem julgadas, o juízo final recai sobre o ocorrido em último lugar.
Ora, nos atos humanos, o existente em último lugar é o ato mesmo, cujo preâmbulo é a deleitação, a ele
conducente. Por onde, à razão superior propriamente pertence o consentimento no ato; e à inferior,
cujo juízo é inferior, pertence o juízo preambular, que versa sobre a deleitação. Embora destas a razão
superior também possa julgar; pois, tudo o dependente do juízo da razão inferior, depende também do
da superior, mas não inversamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Consentir é ato da virtude apetitiva; não absolutamente,
mas conseqüente ao ato da razão deliberativa e judicativa, como já dissemos (q. 15, a. 3); pois, o
consentimento termina quando a vontade busca o que foi julgado pela razão. Por onde, o
consentimento pode ser atribuído tanto à vontade quanto à razão.

RESPOSTA À SEGUNDA. ― Por isso mesmo que a razão superior não dirige os atos humanos, segundo a
lei divina impediente do ato pecaminoso, nós a consideramos como consenciente, quer considere a lei
eterna, quer não. Pois, se considera na lei de Deus, a despreza pelo seu ato; e se não na considera,
menospreza-a a modo de omissão. E portanto, de todos os modos, o consentimento no ato do pecado
procede da razão superior. Pois, como diz Agostinho, o pecado por obra não pode ser consentido
eficazmente pela vontade, sem que aquela sua intenção, onde reside o sumo poder de mover os
membros ao ato ou dela os coibir, cedendo ou servindo à má ação.

RESPOSTA À TERCEIRA. ―Assim como a razão superior pode, considerando na lei eterna, dirigir ou
coibir o ato exterior, assim também pode fazer o mesmo relativamente à deleitação interior. Entretanto,
antes de se declarar o juízo da razão superior, a razão inferior, deliberando apoiada em juízos temporais,
às vezes cede ao prazer da sensualidade, assim que esta lh’o propõe; e então, o consentimento na
deleitação pertence à razão inferior. Se, porém, mesmo depois de consideradas as razões eternas, o
homem persevera no mesmo consentimento, então este já é da alçada da razão superior.RESPOSTA À

QUARTA. ― A apreensão da potência imaginativa é súbita e não deliberada; e portanto, podemos
praticar um ato, antes de a razão superior ou a inferior ter tempo de deliberar. Porém o juízo da razão
inferior é acompanhado de deliberação, dentro de certo tempo, durante o qual também a razão
superior pode deliberar. Por onde, se esta, pela sua deliberação, não coibir o ato pecaminoso, este ser-
lhe-á justamente imputado.

## Art. 8 — Se o consentimento na deleitação é pecado mortal.
(Infra q. 88, a. 5, ad 2; II Sent., dist. XXIV, q. 3 a. 4; De Verit., q. 15 a. 4; Quodl. XII, q. 22, a. 1)
O oitavo discute-se assim. ― Parece que o consentimento na deleitação não é pecado mortal.

1. ― Pois, consentir na deleitação é da alçada da razão inferior, a qual não compete fitar olhos nas
razões eternas ou na lei divina e nem, por conseqüência, delas afastar-se. Ora, todo pecado mortal
implica afastamento dessa lei, como o evidencia a definição dada por Agostinho, do pecado mortal,
supra referida (q. 71, a. 6). Logo, o consentimento na deleitação não é pecado mortal.

2. Demais. ― Só é mal consentir naquilo que é mau. Ora, aquilo que faz com que uma essência seja o
que é, também é essa essência mesma, em mais alto grau, ou, pelo menos, não o é em menor grau.
Logo, aquilo em que consentimos não pode ser menor mal que o consentimento. Ora, a deleitação sem
as obras não é pecado mortal, mas só venial. Portanto, também não é pecado mortal o consentimento
na deleitação.

3. Demais. ― A deleitação difere em bondade e malícia, segundo a diferença das obras, como diz o
Filósofo. Ora, uma obra é o pensamento interior; outra, o ato exterior, p. ex., a fornicação. Logo, a
deleitação, conseqüente ao ato interior do pensamento, difere, em bondade e malícia, do prazer da
fornicação, só na medida em que o pensamento interior difere do ato exterior; e, por conseqüência,
também do mesmo modo difere o consentimento, num e outro caso. Ora, o pensamento interior não é
pecado mortal; logo, nem o consentimento nela. E portanto, nem o consentimento na deleitação.

4. Demais. ― O ato exterior da fornicação ou do adultério não é pecado mortal por causa do prazer, que
também existe no ato conjugal, mas por causa da desordem desse ato. Ora, quem consente na
deleitação nem por isso consente na desordem do ato. Logo, não peca mortalmente.

5. Demais. ― O pecado de homicídio é mais grave que o de simples fornicação. Ora, consentir na
deleitação, resultante do pensamento do homicídio, não constitui pecado mortal. Logo, também não o
constitui, com maioria de razão, consentir na que resulta do pensamento da fornicação.

6. Demais. ― A oração dominical é recitada cotidianamente, para a remissão dos pecados veniais, como
diz Agostinho. Ora, Agostinho também diz que o consentimento na deleitação deve ser eliminado pela
oração dominical. Eis as suas palavras: o consentimento é muito menor pecado do que a resolução de o
pôr em obra; e portanto, também devemos pedir perdão por tais pensamentos, devemos bater no peito
e dizer: Perdoai-nos as nossas dívidas. Logo, o consentimento na deleitação é pecado mortal.
Mas, em contrário, Agostinho acrescenta, depois de poucas palavras: Todo homem se danará, se não
forem perdoados, pela graça do Mediador, os pecados considerados como só de pensamentos, mas
onde há a vontade de se o ânimo deleitar neles. Ora, ninguém se condena senão por pecado mortal.
Logo, pecado mortal é o consentimento na deleitação.

SOLUÇÃO. ― São diversas as opiniões sobre este assunto. Assim, para uns o consentimento na
deleitação não é pecado mortal, mas só venial. Para outros, pelo contrário, é pecado mortal, opinião
mais comum e verossímil. Pois, devemos considerar que todo prazer resulta de um ato como diz
Aristóteles; e além disso que tem algum objeto. Por onde, todo prazer é suscetível de dupla reação, a
saber, com o ato donde resulta e com o objeto que nos deleitamos. Ora, como qualquer outra coisa,
também um ato pode ser objeto do prazer, por poder considerar-se como o bem e o fim no qual,
consumado o prazer, descansamos. Também, outras vezes, o próprio ato, donde resulta o prazer, é o
objeto deste, pelo refletir-se da potência apetitiva, da qual é próprio o deleitar-se, no ato mesmo, como
num certo bem. Tal é o caso de pensarmos, e nos deleitarmos com aquilo em que estamos pensando,
por nos agradar o nosso pensamento. Outras vezes ainda, o prazer resultante de um ato, p. ex., de um
pensamento qualquer, tem como objeto outro ato, como coisa pensada. E então, esse deleite procede
da inclinação do apetite, não para o pensamento, mas para a obra em que pensamos.
Assim pois, quem pensa na fornicação, de dois modos pode deleitar-se: ou no próprio pensamento, ou
na fornicação em que pensa. A deleitação no pensamento, resulta na inclinação do afeto para ele. Ora,
em si mesmo, o pensamento não é pecado mortal; antes, é por vezes só venial, como quando pensamos
inutilmente; e outras vezes não implica nenhum pecado, como quando pensamos utilmente, para, num
determinado caso, pregar ou disputar sobre ele. Logo e por conseqüência, a afeição e o deleite que,
deste modo, versam sobre o pensamento da fornicação, não entram no gênero do pecado mortal; mas,
umas vezes, constituem pecado venial e, outras, não constituem pecado nenhum. Por onde, também
não é pecado mortal o consentimento nessa deleitação. E a esta luz, há verdade na primeira opinião.
Por outro lado, quando pensando na fornicação, nós nos deleitamos com o ato mesmo desse
pensamento, é por estar o nosso afeto inclinado para esse ato. E assim, o consentirmos em tal
deleitação não é senão consentirmos em que o nosso afeto se incline para a fornicação, pois, ninguém
se deleita senão com o que lhe é conforme no apetite. Ora, consentirmos deliberadamente em o nosso
afeto se conformar com coisas que são, em si mesmas, pecados mortais, constitui pecado mortal. E
portanto, esse consentimento na deleitação com o pecado mortal é pecado mortal, como o ensina a
segunda opinião.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O consentimento na deleitação pode depender, não só
da razão inferior, como também da superior, conforme dissemos (a. 7). E contudo, também a razão
inferior pode afastar-se das razões eternas; pois embora não as contemple, como as tomando por
norma, o que é próprio da razão superior, leva-as em conta, entretanto, como regulada por ela. Assim
que, afastando-se delas, pode pecar mortalmente. Pois os atos das potências inferiores, bem como os
dos membros exteriores, podem também ser pecados mortais, por faltar a ordenação da razão superior,
regulando-os de conformidade com as razões eternas.

RESPOSTA À SEGUNDA. ― O consentimento num pecado genericamente venial é pecado venial. E deste
modo, pode-se concluir que o consentimento na deleitação, resultante do vão pensamento de fornicar,
é pecado venial. Mas a deleitação que versa sobre o ato mesmo da fornicação é, pelo seu gênero,
pecado mortal; e só por acidente, i. é, por imperfeição do ato, é que, antes do consentimento, é pecado
venial apenas. Mas, essa imperfeição desaparece com o consentimento deliberado sobreveniente, de
modo que vem a ser, por natureza, pecado mortal.

RESPOSTA À TERCEIRA. ― A objeção colhe no atinente ao deleite cujo objeto é o pensamento.

RESPOSTA À QUARTA. ― A deleitação cujo objeto é o ato exterior não pode existir sem a complacência
neste ato, em si mesmo, embora não nos resolvamos a praticá-lo, por causa da proibição de algum
superior. O que torna o ato desordenado e, por conseqüência, desordenado também o prazer.

RESPOSTA À QUINTA. ― Também o consentimento na deleitação procedente da complacência no ato
do homicídio, é pecado mortal; não porém o consentimento na deleitação procedente da complacência
do pensamento do homicídio.

RESPOSTA À SEXTA. ― Devemos recitar a oração dominical, não só contra os pecados veniais, mas
também contra os mortais.

## Art. 9 — Se na razão superior, enquanto diretiva das potências inferiores, i. é, enquanto consente no ato do pecado, pode haver pecado venial.
(II Sent., dist. XXIV q. 3, a. 5; de Verit., q. 15 a. 5; De Malo, q. 7, a. 5)
O nono discute-se assim. ― Parece que na razão superior, enquanto diretiva das potências inferiores,
i. é, enquanto consente no ato do pecado, não pode haver pecado venial.

1. ― Pois, como diz Agostinho, a razão superior adere às razões eternas. Ora, pecar mortalmente é
afastar-se dessas razões. Logo, parece que não pode haver, na razão superior, senão pecado mortal.

2. Demais. ― A razão superior exerce, na vida espiritual, a função de princípio, como a exerce o coração,
na vida corpórea. Ora, as doenças do coração são mortais. Logo, também os pecados da razão superior.

3. Demais. ― O pecado venial torna-se mortal, se for resultante do desprezo. Ora, parece que implica
desprezo o pecarmos por deliberação, embora venialmente. E como o consentimento da razão superior
é sempre acompanhado de deliberação sobre a lei divina, daí resulta o não poder por causa do desprezo
dessa mesma lei deixar de implicar pecado mortal. Mas, em contrário. ―O consentimento no ato do
pecado pertence à razão superior, como já se disse (a. 7). Ora, o consentimento no ato do pecado venial
é pecado venial. Logo, pode haver pecado venial na razão superior.

SOLUÇÃO. ― Como diz Agostinho, a razão superior adere às razões eternas, contemplando-as ou
consultando-as; contemplando-as, quando lhes perscruta a verdade; consultando-as quando de acordo
com elas procede aos seus juízos e disposições: i. é, quando mediante as razões eternas e
deliberadamente consente em algum ato ou dele se afasta. Ora, pode acontecer que a desordem do
ato, em que consente, não encontre as razões eternas, por não implicar desvio do fim último, como as
contraria o ato do pecado mortal; mas, não colide com elas, como o ato do pecado venial. Por onde,
quando a razão superior consente no ato do pecado venial não se volta contra as razões eternas; e
portanto peca, não mortal, mas só venialmente. Donde se deduz a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. ― Há dupla doença do coração. Uma, que lhe atinge a substância mesma e lhe
imuta a compleição natural; e essa é sempre mortal. Outra, proveniente de alguma desordem do seu
movimento ou de alguma víscera que lhe é anexa, e essa nem sempre é mortal. Do mesmo modo, há
sempre pecado mortal na razão superior quando ela deixa de ordenar-se para o objeto próprio, que são
as razões eternas. Mas, quando a desordem só é relativa a este, não é mortal o pecado, mas venial.

RESPOSTA À TERCEIRA. ― O consentimento deliberado no pecado nem sempre implica desprezo da lei
divina; mas só quando o pecado contraria a essa lei.

## Art. 10 — Se na razão superior, como tal, i. é, enquanto contempla as razões eternas, pode haver pecado venial.
(II Sent., dist. XXIV, q. 6, a. 5; De Verit., q. 15, a. 5; De Malo, q. 7, a. 5)
O décimo discute-se assim. ― Parece que na razão superior, como tal, i. é, enquanto contemplativa
das razões eternas, não pode haver pecado venial.

1. ― Pois, o ato da potência não vem a ser deficiente senão porque se comporta desordenadamente em
relação ao seu objeto. Ora, o objeto da razão superior são as razões eternas, das quais não é possível
afastar-se sem pecado mortal. Logo, na razão superior, como tal, não pode haver pecado venial.

2. Demais. ― Sendo a razão uma potência deliberativa, o seu ato é sempre acompanhado de
deliberação. Ora, todo ato deliberadamente desordenado, relativo às coisas de Deus, é pecado mortal.
Logo, na razão superior como tal não há nunca pecado venial.

3. Demais. ― Às vezes se dá que o pecado subreptício é venial. É mortal, ao contrário, o que implica
deliberação, porque a razão deliberante se apóia num bem maior, agindo contra o qual peca mais
gravemente. Assim, se a razão, consentindo deliberadamente num ato deleitável desordenado e
contrário à lei de Deus, pecará mais gravemente do que se considerar que esse ato só é contrário a uma
virtude moral. Ora, a razão superior não pode se apoiar em nada mais elevado do que o seu objeto.
Logo, se a moção subreptícia não for pecado mortal, nem o fará tal a deliberação superveniente, o que é
evidentemente falso. Logo, na razão superior, como tal, não pode haver pecado venial.
Mas, em contrário. ―A moção subreptícia de infidelidade é pecado venial. Ora, é próprio à razão
superior como tal. Logo, nela, como tal, pode haver pecado venial.

SOLUÇÃO. ― A razão superior é levada, de um modo, para o seu objeto, e, de outro, para os objetos das
potências inferiores, dirigidas por ela. ― Ora, não é levada para os objetos dessas potências, senão na
medida em que consulta, sobre eles, as razões eternas. Portanto não é levado para eles senão por
deliberação. Ora, o consentimento deliberado no pecado genericamente mortal, constitui pecado
mortal. Logo, a razão superior sempre peca mortalmente, se forem pecados mortais os atos das
potências inferiores em que consente.
Por outro lado, ela é capaz de dois atos, relativamente ao seu objeto próprio, a saber: a simples
intuição; e a deliberação, pela qual, mesmo relativamente ao seu objeto próprio, consulta as razões
eternas. Ora, por simples intuição, ela é suscetível a uma moção desordenada relativa às coisas divinas;
assim, quando nos sobrevém uma súbita moção de infidelidade. E embora esta seja genericamente,
pecado mortal, contudo a sua súbita adveniência só o é venial. Porque se não há pecado mortal senão
contra a lei de Deus, pode contudo uma verdade de fé aparecer subitamente à razão sob um aspecto
diferente, antes de, no caso, ser ou poder ser consultada a razão eterna, i. é, a lei de Deus. Assim, se
tivermos o súbito pensamento de ser impossível na ordem natural a ressurreição dos mortos, e
subitamente rejeitá-la antes de ter tempo de deliberar que nos foi transmitida, para nela crermos, pela
lei divina. Se porém, depois dessa deliberação, permanecer a moção de infidelidade, haverá pecado
mortal. E portanto, em relação ao seu objeto próprio, a razão superior pode, nos movimentos súbitos,
pecar venialmente, ou mesmo mortalmente, por consentimento deliberado, embora o pecado seja, no
seu gênero, mortal. No atinente, porém, às potências inferiores, sempre peca mortalmente, quanto ao
pecado genericamente mortal; mas não quanto aos genericamente veniais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O pecado contra as razões eternas, embora mortal só
genericamente, pode contudo ser venial, por causa da imperfeição da moção súbita, como já se disse.

RESPOSTA À SEGUNDA. ― Na ordem dos atos, a razão a que pertence a deliberação pertence também a
simples intuição daquilo de que a deliberação procede; assim como também, na ordem especulativa, à
razão pertence formar tanto os silogismos como as proposições. E portanto, a razão também pode ser
suscetível de movimentos súbitos.

RESPOSTA À TERCEIRA. ― Um mesmo objeto pode ser suscetível de considerações diversas, dos quais
seja um superior ao outro. Assim, Deus pode ser considerado, ou enquanto cognoscível pela razão
humana, ou enquanto ensinado pela revelação divina, que é consideração mais alta. E portanto, embora
o objeto da razão superior seja algo de altíssimo, por natureza, pode contudo ser reduzido a uma
consideração mais alta. E por esta razão, aquilo que, no movimento súbito, não era pecado mortal, vem
a sê-lo, pela deliberação redutora a uma consideração mais alta, como ficou exposto.