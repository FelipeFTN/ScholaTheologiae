# Questão 114: Do mérito, que é efeito da graça cooperante.
Em seguida devemos tratar do mérito, que é efeito da graça cooperante.
E nesta questão discutem-se dez artigos:

## Art. 1 — Se o homem pode merecer perante Deus.
(Supra, q. 21, a. 4; III, Sent., dist. XVIII, a. 2).
O primeiro discute-se assim. – Parece que o homem não pode merecer nada de Deus.

1. – Pois, ninguém merece recompensa por pagar o que deve. Ora, nem com todo o bem que fizermos
podemos pagar suficientemente o que devemos a Deus, a quem cada vez mais devemos, como o
próprio Filósofo o diz. Por isso, está na Escritura: Depois de terdes feito o que vos foi mandado, dizei:
Somos uns servos inúteis; fizemos o que devíamos fazer. Logo, o homem não pode merecer nada de
Deus.

2. Demais. – O que fazemos em nosso benefício não nos dá nenhum mérito junto de Deus, a quem isso
nada aproveita. Ora, uma ação reta aproveita ao seu próprio autor ou a outro homem, mas não a Deus,
conforme a Escritura: Se obrares com justiça, que lhe darás? Ou que receberá ele de tua mão? Logo, o
homem não pode merecer nada de Deus.

3. Demais. – Quem merece algo de outrem o tem como seu devedor, pois a recompensa merecida é
devida. Ora, Deus não pode ser devedor de ninguém, conforme a Escritura: Quem lhe deu alguma coisa
primeiro, para esta lhe haver de ser recompensada? Logo, ninguém pode merecer nada de Deus.
Mas, em contrário, diz a Escritura: Recompensa há para a tua obra. Ora, recompensa é o dado em
virtude de um mérito. Logo, parece que o homem pode merecer perante Deus.

SOLUÇÃO. – O mérito e a recompensa têm o mesmo objeto. Pois, recompensa se chama ao dado em
retribuição de uma obra ou de um trabalho, como lhe sendo o preço. Por onde, assim como pagar o
justo preço pelo que se recebeu de outrem é ato de justiça, assim ato de justiça também é dar a
recompensa devida a uma obra ou trabalho. Ora, a justiça implica uma certa igualdade, segundo o
Filósofo. Portanto, a justiça absoluta só existe entre os perfeitamente iguais; e onde não há igualdade
absoluta não há também justiça absoluta, senão só uma certa espécie dela. Assim, há o chamado direito
paterno ou o dominical, como diz o Filósofo no mesmo livro. E por isto, entre os quais há justiça
absoluta há também, em absoluto, fundamento ao mérito e à recompensa, Porém onde só há justiça
relativa e não, absoluta, também não há mérito, absoluta, senão só relativamente, enquanto isso
implica a noção de justiça. Assim, pois, o filho pode merecer perante o pai, e o escravo, junto ao senhor.
Ora, é manifesto que, entre Deus e o homem há a máxima desigualdade, pois há entre esses dois seres
uma distância infinita, e todo bem do homem vem de Deus. Por isso, entre o homem e Deus não há
justiça fundada numa igualdade absoluta, mas apenas proporcional, enquanto cada um age ao seu
modo. Ora, o modo e a medida das capacidades humanas é Deus quem os estabelece, Por onde, o
homem não pode ter mérito diante de Deus, senão pressuposta uma ordem divina, de maneira que,
pela sua ação, ele receba de Deus, como recompensa, por assim dizer, os bens em vista dos quais ele lhe
deu o poder de agir. Assim também os seres naturais, pelos seus movimentos próprios e pelas suas
operações, alcançam o fim a que Deus os ordenou. Mas de maneira diferente; pois a criatura racional,
dotada de livre arbítrio, tem o poder de agir, por si mesma o que lhe dá ao ato caráter meritório. Mas
isso não se passa com as outras criaturas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O homem, fazendo por vontade própria o que deve,
merece; do contrário, o ato de justiça, pelo qual paga o devido, não seria meritório.

RESPOSTA À SEGUNDA. – Deus, nas nossas boas obras, não visa nenhuma utilidade, mas a glória, i.e, a
manifestação da sua bondade; e isso é o que ele também visa nas suas obras. Pois, de o adorarmos
nenhum bem lhe acresce a ele, senão a nós mesmos. E assim, merecemos perante Deus; não que ele
tire algum proveito das nossas obras, mas por obrarmos para a sua glória.

RESPOSTA À TERCEIRA. – De os nossos atos não serem meritórios, senão pressupondo-se uma ordem
divina, não resulta que Deus se torne, absolutamente, nosso devedor, senão a si mesmo, a quem se
deve o fazer cumprir-se a sua ordem.

## Art. 2 — Se, sem a graça, podemos merecer a vida eterna.
(Supra, q. 109, a. 5, et locis ibi citatis).
O segundo discute-se assim. – Parece que, sem a graça, podemos merecer a vida eterna.

1. – Pois, o homem, merece de Deus aquilo para que ele o ordenou, como se disse. Ora, o homem, por
natureza, ordena-se à felicidade, como fim; por isso, mesmo naturalmente, deseja ser feliz. Logo, pelas
suas faculdades naturais, sem a graça, pode merecer a felicidade da vida eterna.

2. Demais. – Uma obra é tanto mais meritória quanto menos devida. Ora, menos devido é o bem feito
por quem recebeu menores benefícios. Por onde, como quem tem só os bens naturais recebeu menores
benefícios de Deus, do que quem, além desses, recebeu os dons gratuitos, parece que as suas obras são
mais meritórias, perante Deus. E portanto, se quem tem a graça pode merecer, de certo modo, a vida
eterna, com maior razão o pode quem não a tem.

3. Demais. – A misericórdia e a liberalidade de Deus excedem infinitamente a misericórdia e a
liberalidade humana. Ora, um homem pode merecer perante outro, mesmo se nunca lhe esteve nas
boas graças. Logo, parece que, com maior razão, o homem pode, sem a graça, merecer de Deus a vida
eterna.
Mas, em contrário, diz a Escritura: A graça de Deus é a vida eterna.

SOLUÇÃO. – Podemos distingui dois estados do homem, sem a graça, como já dissemos: o de natureza
íntegra, qual o de Adão, antes do pecado; e o de natureza corrupta, como o nosso, antes da reparação
operada pela graça. – Se pois, considerarmos o homem no seu primeiro estado, não pode ele, só pelas
suas faculdades naturais, sem a graça, merecer a vida eterna, pela só razão que o seu mérito depende
da preordenação divina. E Deus não ordena o ato de nenhum ser para o que lhe é desproporcionado à
capacidade, que é o princípio do ato. Pois, por instituição da Divina Providência, nenhum ser pode agir
ultrapassando a sua capacidade. Ora, a vida eterna é um bem excedente à capacidade da natureza
criada, porque também lhe excede o conhecimento e o desejo, conforme a Escritura: O olho não viu
nem o ouvido ouviu, nem jamais veio ao coração do homem. Donde, nenhuma criatura é princípio
suficiente do ato meritório da vida eterna, sem se lhe acrescentar o bem sobrenatural, chamado graça.
– Se porém considerarmos o homem no estado de pecado, à razão supra-referida se ajunta outra,
fundada no obstáculo do pecado. Pois, sendo este uma ofensa de Deus, que faz perder a vida eterna,
como do sobredito resulta, ninguém, estando em pecado, pode merecer a vida eterna, sem primeiro,
abandonando-o, reconciliar-se com Deus,; o que se faz pela graça. Pois, ao pecador não se lhe deve a
vida, mas a morte, segundo a Escritura: O estipêndio do pecado é a morte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Deus ordenou a natureza humana para conseguir o fim
da vida eterna, não por virtude própria, mas com o auxílio da graça. E assim, pode o seu ato ser
meritório da vida eterna.

RESPOSTA À SEGUNDA. – O homem, sem a graça, não pode praticar obras iguais às que praticaria
auxiliado por ela; porque, quanto mais perfeito é o princípio da ação, tanto mais perfeita é esta. A
objeção colheria, suposta, em ambos os casos, a igualdade da ação.

RESPOSTA À TERCEIRA. – Considerada a objeção à luz da primeira razão exposta (no corpo do artigo),
não é possível nenhuma assimilação entre Deus e o homem. Pois, este tem de Deus todo o poder de
praticar o bem e não, de algum outro homem. Portanto, não pode ter algum mérito perante Deus,
senão por algum dom divino; o que o Apóstolo assinaladamente refere, quando diz: Quem lhe deu
alguma coisa primeiro, para esta lhe haver de ser recompensada? Ao passo que, perante outro homem,
ele pode merecer, antes de ter recebido, do mesmo, seja o que for, por meio do que recebeu de Deus. –
Porém, quanto a segunda razão, fundada no obstáculo do pecado, há semelhança entre Deus e o
homem; pois não podemos merecer nada, da parte de quem ofendemos senão nos reconciliarmos com
ele, dando-lhe satisfações.

## Art. 3 — Se o homem, constituído em graça, pode condignamente merecer a vida eterna.
(II Sent., dist. XXVII, a. 3; III, dist. XVIII, a. 2.; Ad Rom., cap. IV, lect. I; cap. VI, lect. IV; cap. VIII, lect. IV).
Parece que o homem, constituído em graça, não pode condignamente merecer a vida eterna.

1. – Pois, diz o Apóstolo: As penalidades da vida presente não tem proporção alguma com a glória
vindoura que se manifestará em nós. Ora, dentre as obras meritórias, são predominantes os sofrimentos
dos santos. Logo, nenhuma obra humana é condignamente meritória da vida eterna.

2. Demais. – Aquilo da Escritura – A graça de Deus é a vida eterna – diz a Glosa: Podia dizer com
exatidão – o estipêndio da justiça é a vida eterna; mas preferiu dizer: a graça de Deus é a vida eterna,
para compreendermos que Deus nos conduz à vida eterna pela sua misericórdia e não pelos nossos
méritos. Ora, o que alguém merece condignamente não por misericórdia o merece, mas por mérito.
Logo, parece que o homem não pode, com o auxílio da graça, merecer condignamente a vida eterna.

3. Demais. – Condigno é o mérito, que é igual à recompensa. Ora, nenhum ato da vida presente pode
igualar à vida eterna, que excede o nosso conhecimento e o nosso desejo. Excede também à caridade ou
o amor desta vida, assim como excede à natureza. Logo, o homem não pode, com a graça, merecer
condignamente a vida eterna.
Mas, em contrário. – O dado em virtude de um justo juízo é recompensa condigna. Ora, a vida eterna
Deus no-la dá em virtude de um juízo justo, conforme a Escritura: Pelo mais me está reservada a coroa
da justiça, que o Senhor, justo juiz, me dará naquele dia. Logo, o homem merece condignamente a vida
eterna.

SOLUÇÃO. – Podemos considerar de dois modos a obra meritória do homem: enquanto precedente do
livre arbítrio, ou da graça do Espírito Santo. – Considerada a substância da obra, enquanto procedente
do livre arbítrio, não pode haver nela condignidade, por causa da sua máxima desigualdade; mas lá a
congruidade, por causa de uma certa igualdade proporcional. Pois, é congruente que, ao homem,
agindo conforme a sua capacidade, Deus o recompense de conformidade com a excelência dela. – Se
considerarmos, porém, a obra meritória enquanto procedente da graça do Espírito Santo, então é
condignamente meritória da vida eterna. Porque, então, o valor do mérito se funda no poder do Espírito
Santo, que nos move para a vida eterna, segundo a Escritura: Virá a ser nele uma fonte de água que
solte para a vida eterna. Além disso, o preço dessa ogra depende da dignidade da graça, pela qual o
homem, tornado consorte da natureza divina, é adotado como filho de Deus, ao qual é devida a herança
em virtude do direito mesmo de adoção, consoante à Escritura: Se somo filhos, também herdeiros.

DONDE A RESPOSTA Á PRIMEIRA OBJEÇÃO. – O Apóstolo se refere aos sofrimentos dos santos,
considerados na sua substância.

RESPOSTA À SEGUNDA. – As palavras citadas da Glosa devem entender-se relativamente à primeira
causa de alcançarmos a vida eterna, que é a misericórdia de Deus. Ao passo que o nosso mérito é uma
causa subseqüente.

RESPOSTA À TERCEIRA. – A graça do Espírito Santo, que temos durante a vida, embora não seja
atualmente igual à glória, o é, contudo, virtualmente; assim, a semente, em que toda a árvore,
virtualmente está. Do mesmo modo, pela graça, habita no homem o Espírito Santo, causa suficiente da
vida eterna. Por isso, a Escritura diz, que é penhor da nossa herança.

## Art. 4 — Se a graça é o princípio do mérito, mais pela caridade, do que pelas outras virtudes.
(III Sent., dist. XXX, a. 5; IV, dist. XLIX, q. 1, a. 4, qª 4; q. 5, a. 1; De Verit., q. 14, a. 5, ad 5; De Pot., q. 6, a.
9; Ad Rom., cap. VIII, lect. V; I Tim., cap, lect II; Ad Herb., cap. VI, lect III).
O quarto discute-se assim. – Parece que a graça não é princípio do mérito, mais pela caridade, do que
pelas outras virtudes.

1. – Pois, a recompensa é devida à obra, conforme a Escritura: Chama os trabalhadores e paga-lhes o
jornal.Ora, toda virtude, sendo um hábito operativo, é princípio de alguma obra, como já dissemos.
Logo, todas as virtudes são igualmente princípio de mérito.

2. Demais. – O Apóstolo diz; Cada um receberá a sua recompensa particular segundo o seu
trabalho. Ora, a caridade, antes diminui que aumenta o trabalho; pois, como diz Agostinho, tudo o que é
duro e cruel o amor o torna fácil e quase o reduz a nada. Logo, a caridade não é, mais que as outras
virtudes, o princípio do mérito.

3. Demais. – É o princípio primeiro do mérito a virtude, cujo atos são, por excelência, meritórios. Ora,
mais meritórios são os atos de fé, de paciência ou de fortaleza, como bem o demonstraram os mártires
que, pela fé, lutaram paciente e fortemente até a morte. Logo, as outras virtudes são, mais que a
caridade, o princípio do mérito.
Mas, em contrário, diz o Senhor: Aquele que me ama será amado de meu Pai, e eu o amarei também, e
me manifestarei a ele. Ora, a vida eterna consiste no conhecimento claro de Deus, conforme a
Escritura: A vida eterna consiste em que eles conheçam por um só verdadeiro Deus e vivo a ti. Logo, o
mérito da vida eterna depende principalmente da caridade.

SOLUÇÃO. – Como podemos deduzir do que já foi dito, um ato humano é meritório por duas razões.
Primeiro e principalmente, por ordenação divina, pela qual um ato se torna meritório do bem para o
qual o homem é divinamente ordenado. Em segundo lugar, pelo livre arbítrio, que torna o homem
capaz, diferentemente das outras criaturas, de agir por si mesmo, isto é, voluntariamente. E, em ambos
os casos, o mérito depende principalmente da caridade. – Pois, devemos primeiro, considerar, que a
vida eterna consiste no gozo de Deus.Ora, a moção da alma humana para gozar do bem divino é o ato
próprio da caridade, pela qual todos os atos das outras virtudes, enquanto governadas pela caridade, se
ordenam para tal fim. Por onde, o mérito da vida eterna pertence, primeiramente, à caridade e,
secundariamente, às outras virtudes, enquanto a caridade lhes governa os atos. – Do mesmo modo,
como é manifesto, o que fazemos por amor o fazemos de maneira soberanamente voluntária. Por onde,
enquanto o mérito, por essência, exige o ato voluntário, deve ser atribuído principalmente à caridade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A caridade, tendo o fim último como objeto, move as
outras virtudes a agirem. Pois, sempre, o hábito concernente ao fim governa os concernentes aos meios,
como do sobredito se colhe.

RESPOSTA À SEGUNDA. – Uma obra pode ser laboriosa e difícil, de dois modos. – Pela sua grandeza; e
então a grandeza do trabalho acarreta o aumento do mérito. Por onde, a caridade não diminui o
trabalho, antes, faz-nos empreender as maiores obras; pois, como diz Gregório, em certa homília, desde
que ela existe, obra grandes coisas. – De outro modo, uma obra pode ser laboriosa e difícil por
deficiência do seu autor; pois, o que fazemos sem vontade pronta é laborioso e difícil. E esse labor
diminui o mérito, mas a caridade o elimina.

RESPOSTA À TERCEIRA. – O ato de fé não é meritório, senão quando a fé obra com caridade, como diz a
Escritura. – Semelhantemente, os atos de paciência e de fortaleza não são meritórios, se não os
fizermos com caridade, conforme aquilo da Escritura: Se entregar o meu corpo para ser queimado, se
todavia não tiver caridade, nada disto me aproveita.

## Art. 5 — Se o homem pode merecer por si a primeira graça.
(II Sent., dist. XXVII, a. 4; a. 5, ad 3; III, dist. XVIII, a. 4, qª 1; dist. XIX, a. 1, qª 1; III Cont. Gent., cap. CXLIX;
De Verit., q. 29, a. 6; In Ioan., cap. X, lect. IV; Ad Ephes., cap. II, lect III).
O quinto discute-se assim. – Parece que o homem pode merecer por si a primeira graça.

1. – Pois, diz Agostinho, que a fé merece a justificação. Ora, o homem é justificado pela primeira graça.
Logo, pode merecê-la por si.

2. Demais. – Deus não dá a graça senão aos dignos. Mas ninguém é digno de um dom senão por tê-lo
merecido condignamente. Logo, pode-se merecer condignamente a primeira graça.

3. Demais. – Entre os homens, pode se merecer um dom já recebido. Assim, quem recebeu um cavalo
do senhor, pode merecê-lo, usando bem dele no serviço desse mesmo senhor. Ora, Deus é mais liberal
que o homem. Logo, com maior razão, este pode merecer de Deus, por obras subseqüentes, a primeira
graça, já recebida.
Mas, em contrário, repugna à essência da graça ser recompensa de obras, conforme a Escritura: Ao que
obra não se lhe conta o jornal por graça, mas por dívida. Ora, o homem merece o que lhe é imputado
como débito, e como sendo uma recompensa da sua obra. Logo, não pode merecer a primeira graça.

SOLUÇÃO. – O dom da graça pode ser considerado à dupla luz; - Primeiro, quanto ao seu caráter de dom
gratuito. E então, é manifesto que todo mérito repugna à graça, pois, como diz o Apóstolo, se isto foi
por graça, não foi já pelas obras. – Segundo, quanto à natureza mesma do que é dado. E assim, também
o dom da graça escapa ao mérito, se trata de alguém que ainda não a possui; quer por exceder ela à
capacidade da nossa natureza, quer também porque, antes de recebê-la, o homem, no estado de
pecado, está impedido de merecê-la, pelo próprio pecado. Mas depois de havê-la recebido, já não pode
merecer a graça possuída. Porque a recompensa é o termo da obra, ao passo que a graça é o princípio
de qualquer boa obra nossa, como já dissemos. Outro dom gratuito, porém, que venhamos a merecer,
em virtude da graça precedente, já não será a primeira graça. – Por onde, é manifesto que ninguém
pode merecer para si a primeira graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como ele próprio o confessa, Agostinho enganou-se,
durante certo tempo, acreditando que o início da fé está em nós, ao passo que Deus no-la dá
consumada. Esse erro ele o retrata no lugar que acabamos de citar. Ora, o lugar citado pela objeção, que
a fé merece a justificação, parece referir-se a essa opinião retratada. Se, porém, supusermos, como o
exige a verdade da fé, que Deus nos dá o início da mesma, então o ato de fé já resulta da primeira graça,
e portanto não pode merecê-la. Logo, o homem é justificado pela fé, não porque, crendo, mereça a
justificação, mas porque, sendo justificado, crê; pois, a moção da fé é necessária à justificação do ímpio,
como já dissemos.

RESPOSTA À SEGUNDA. – Deus não dá a graça senão aos dignos; não porém que, antes, dela já fossem
dignos, mas pelos tornar tais, pela graça, Ele que só pode fazer puro ao que foi concebido de imunda
semente.

RESPOSTA À TERCEIRA. – Toda boa obra do homem procede da primeira graça, como do princípio. Não
procede, porém, de nenhum dom humano. E portanto, não há semelhança entre o dom da graça e o
dom humano.

## Art. 6 — Se um homem pode merecer para outro a primeira graça.
( Art. Seq., ad 2; II Sent., dist. XXVII, a. 6; III, dist. XIX, a. 5, qª, 3 ad 5; IV, dist. XLV, q, 2, a. 1, qª 1; De
Verit., q. 29. A. 7; I Tim., cap, IV, lect II).
O sexto discute-se assim. – Parece que um homem pode merecer para outro a primeira graça.

1. – Pois, ao que diz a Escritura – Vendo Jesus à fé deles etc. – diz a Glosa: Que poder tem perante Deus
a fé pessoal, pois que junto d’Ele tanto valeu a alheia, que o levou a curar esse homem, interna e
externamente1Ora, a cura interior do homem é operada pela primeira graça. Logo, um homem pode
merecê-la para outro.

2. Demais. – As orações dos justos não são vãs, mas eficazes, conforme a Escritura: A oração do justo,
sendo assídua, vale muito. Mas no mesmo lugar se diz: orai uns pelos outros, para serdes salvos. Ora,
como a salvação do homem não pode vir senão da graça, resulta que um homem pode merecer para
outro a primeira graça.

3. Demais. – A Escritura diz: Granjeais amigos com as riquezas da iniqüidade, para que, quando vós
vierdes a faltar, vos recebam eles nos tabernáculos eternos. Ora, ninguém é recebido nos tabernáculos
eternos senão pela graça, pela qual, só, merecemos a vida eterna, como já se disse. Logo, um homem
pode merecer para outro a primeira graça.
Mas, em contrário, a Escritura: Ainda que Moisés e Samuel se pusessem diante de mim, não está a
minha alma com este povo. Entretanto, eles foram os que mais mereceram perante Deus. Logo, parece
que nenhum homem pode merecer para outro a primeira graça.

SOLUÇÃO. – Como do sobredito resulta, as nossas obras podem ser meritórias, por duas razões.
Primeiro, em virtude da moção divina, e então, merecemos condignamente. Depois, por procederem do
livre arbítrio, pelo qual agimos voluntariamente. E por este lado, o mérito é côngruo; pois é congruente,
que o homem, usando bem das suas capacidades, Deus obre mais excelentemente, de conformidade
com a sobreexcelência do seu poder.
Por onde é claro que, por mérito condigno, ninguém, salvo Cristo, pode merecer para outrem a primeira
graça. Porque todos nós somos movidos por Deus, pelo dom da graça, para chegarmos à vida eterna; e
portanto, o mérito condigno não pode ir além dessa moção. A alma de Cristo, porém, recebeu, pela
graça, essa moção divina, não só para alcançar a glória da vida eterna, mas também para levar os outros
para ela, como cabeça da Igreja e autor da salvação humana, conforme a Escritura: Levou muitos filhos à
glória, ele o autor da salvação etc.
Por mérito côngruo, porém, podemos merecer para outrem a primeira graça. Pois, o homem,
constituído em graça, cumprindo a vontade de Deus, é congruente que Deus, por uma amizade
proporcional, cumpra a vontade de um relativa à salvação de outro. Embora, às vezes, possa advir
impedimento por parte daquele a quem esse justo desejava a justificação. Ora, é a um caso dessa
espécie que se refere o lugar de Jeremias, ultimamente citado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A fé de um vale para a salvação de outro, por mérito
côngruo e não condigno.

RESPOSTA À SEGUNDA. – A oração impetra confiando na misericórdia; ao passo que o mérito condigno,
na justiça. Por isso, o homem, orando, impetra muitos bens da divina misericórdia que, contudo, por
justiça, não merece, conforme aquilo da Escritura: Nós, prostrando-nos em terra diante da tua face não
fazemos estas deprecações fundados em alguns merecimentos da nossa justiça, mas, sim, na multidão
das tuas misericórdias.

RESPOSTA À TERCEIRA. – Diz-se que os pobres, recebendo a esmola, recebem os que lha dão nos
tabernáculos eternos, ou por lhes pedir o perdão, orando; ou por merecerem, côngruamente, em favor
deles, por outras boas ações; ou também, materialmente falando, porque, pelas próprias obras de
misericórdia, que praticamos para com os pobres, mereçamos ser recebidos nos tabernáculos eternos.

## Art. 7 — Se podemos, por nós mesmos, merecer levantarmo-nos da queda.
(II Sent., dist. XXVII, a. 4, ad 3; a. 6; Ad Hebr., cap. VI. Lect III).
Parece que podemos, por nós mesmos, merecer levantarmo-nos da queda.

1. – Pois, parece que o homem pode merecer o que justamente pede a Deus. Ora, nada de mais justo,
como diz Agostinho, podemos pedir a Deus, do que o levantarmo-nos da queda, conforme aquilo da
Escritura:Quando faltar a minha fortaleza, não me desampares, Senhor. Logo, o homem pode merecer
levantar-se da queda.

2. Demais. – As nossas obras aproveitam muito mais a nós mesmos que aos outros. Ora, podemos de
certo modo, merecer que outrem se levante da queda, assim como merecer-lhe a primeira graça. Logo,
com maior razão, podemos merecer para nós mesmos o levantarmo-nos da queda.

3. Demais. – Quem esteve em graça mereceu para si, pelas boas obras praticadas, a vida eterna, como
do sobredito resulta. Ora, ninguém pode alcançar a vida eterna senão auxiliada pela graça. Logo, parece
que mereceu levantar-se, pela graça.
Mas, em contrário, a Escritura: Se o justo se apartar da sua justiça, e vier a cometer a iniqüidade, de
nenhuma das obras de justiça que tiver feito se fará memória. Logo, para levantar-se, de nada lhe
valerão as graças precedentes. Por tanto, não podemos de antemão merecer levantarmo-nos do pecado
em que tivermos caído.

SOLUÇÃO. – Ninguém pode, por si mesmo, merecer levantar-se do pecado em que vier a cair, nem por
mérito condigno, nem por mérito côngruo. – Não o pode por mérito condigno, por este depender por
essência, da moção da graça divina, a qual fica impedida pelo pecado sobreveniente. Por onde, todos os
benefícios com que Deus gratificar um homem, para lhe operarem a reabilitação, escapam-lhe ao
mérito, pois a moção da graça, anteriormente recebida, não se estende até esse ponto. – Por outro
lado, o pecado daquele, em favor de quem outrem merece, impede o mérito côngruo, pelo qual este lhe
merece a primeira graça, de produzir o seu efeito. Logo, com maior razão, a eficácia desse mérito fica
impedida pelo obstáculo existente em que merece e naquele em favor de quem merece; porque então
ambos esses obstáculos concorrem na mesma pessoa. Portanto, ninguém pode, de nenhum modo,
merecer por si mesmo, levantar-se, depois de ter caído.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Tanto o desejo que temos de nos levantar da queda,
como a oração em que o pedimos, consideram-se justos, por tenderem para a justiça. Não porém, que
se apóiem na justiça, a modo de mérito, mas só, de misericórdia.

RESPOSTA À SEGUNDA. – Podemos merecer para outrem congruamente a primeira graça, por não
haver obstáculo, ao menos por parte nossa, que merecemos. Mas o obstáculo sobrevém, quando,
depois do mérito da graça, nos afastamos da justiça.

RESPOSTA À TERCEIRA. – Certos disseram que ninguém pode merecer absolutamente, a vida eterna,
senão pelo ato da graça final; mas, só com a condição de perseverar. – Esta opinião porem é irracional,
pois às vezes o ato da última graça não é mais meritório, mas, menos, que os atos precedentes, por
causa do acabrunhamento causado pela doença. – Por onde, devemos dizer que, absolutamente
falando, qualquer ato de caridade merece a vida eterna. Mas o pecado sobreveniente impede o mérito
precedente de produzir o seu efeito; assim como as causas naturais deixam de produzir os seus efeitos
por causa de um obstáculo sobreveniente.

## Art. 8 — Se o homem pode merecer o aumento da graça ou da caridade.
(II Sent., dist. XXVII, a. 5; In Ioan., cap. X, lect. IV).
O oitavo discute-se assim. – Parece que o homem não pode merecer o aumento da graça ou da
caridade.

1. – Pois, a quem já recebeu o premio merecido nenhuma outra recompensa é devida, como aqueles de
quem diz a Escritura: Receberam a sua recompensa. Se pois pudéssemos merecer o aumento de
caridade ou de graça, resultaria que, uma vez aumentada a graça, não poderíamos esperar mais
nenhum premio, o que é inadmissível.

2. Demais. – Nenhum ser pode agir além dos limites de ação da sua espécie. Ora, o princípio do mérito é
a graça ou a caridade, como do sobredito resulta. Logo, ninguém pode merecer graça ou caridade maior
que a que tem.

3. Demais. – O que o homem pode merecer o merece por algum ato procedente da graça ou da
caridade; assim como pode merecer a vida eterna por qualquer ato praticado nessas condições. Se pois,
o aumento da graça ou da caridade pode ser merecido, resulta que merecemos esse aumento por
qualquer ato informado pela caridade. Ora, o que merecemos, infalivelmente recebemos de Deus, se
não sobrevier o obstáculo do pecado, conforme a Escritura: Sei a quem tenho crido, e estou certo de
que ele é poderoso para guardar o meu depósito para aquele dia. Donde se seguiria que, por qualquer
ato meritório, a graça ou a caridade ficaria aumentada. Ora, isto é inadmissível porque às vezes esses
atos meritórios não são praticados com muito fervor, de modo a bastarem para causar o aumento da
caridade. Logo, o aumento da caridade não pode ser merecido.
Mas, em contrário, diz Agostinho: a caridade merece ser aumentada, para que, aumentada, mereça
chegar à perfeição. Logo, o aumento da caridade ou da graça pode ser merecido.

SOLUÇÃO. – Como já dissemos, pode ser merecido condignamente aquilo a que se estende a moção da
graça. Ora, a moção de um motor não se estende só ao último termo do movimento, mas também a
todo o desenvolvimento progressivo dele. Ora, o termo do movimento da graça é a vida eterna. E o
avanço progressivo desse movimento depende do aumento da caridade ou da graça, conforme aquilo
da Escritura: A vereda dos justos, como luz que resplandece, vai adiante e cresce até o dia perfeito, que
é o dia da glória. Logo, o aumento da graça pode ser merecido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O premio é o termo do mérito. Ora, o movimento tem
duplo termo: o último e o médio; que constitui ao mesmo tempo um princípio e um termo. A
recompensa, consistente no aumento, é um termo desta espécie. Pelo contrário, a recompensa
consistente no favor dos homens é como o último termo para os que o consideram como fim. Por isso,
esses tais não receberão nenhuma outra recompensa.

RESPOSTA À SEGUNDA. – O aumento da graça não sobreleva o poder da graça preexistente, embora lhe
sobrepuje a grandeza. Assim como uma árvore, de tamanho muito superior à da sua semente, não lhe
excede, contudo, a virtude.

RESPOSTA À TERCEIRA. – Por qualquer ato meritório o homem merece o aumento da graça, bem como
a consumação dela, que é a vida eterna. Mas, como esta não é concedida imediatamente, mas em
tempo oportuno, assim também a graça não aumenta imediatamente, mas no seu tempo, isto é,
quando o sujeito estiver suficientemente disposto a lhe receber o aumento.

## Art. 9 — Se podemos merecer a perseverança.
O nono discute-se assim. – Parece que podemos merecer a perseverança.

1. – Pois, o que obtemos pedindo podemos merecer quando estamos em estado de graça. Ora, pedindo-
a obtemos de Deus a perseverança, do contrário pediríamos em vão a Deus, nas petições da oração
dominical, como o nota Agostinho. Logo, tendo a graça, podemos merecer a perseverança.

2. Demais. – É melhor não poder pecar, que simplesmente, de fato, não pecar. Ora, podemos merecer
não poder pecar; pois, merecemos a vida eterna que implica, por essência, a impecabilidade. Logo, com
maior razão, podemos merecer não pecar, de fato, i. é, perseverar.

3. Demais. – O aumento da graça é mais que a perseverança na graça já obtida. Ora, podemos merecer
o aumento da graça, como já se disse. Logo, com maior razão, podemos merecer a perseverança na
graça obtida.
Mas, em contrário, tudo o que merecemos recebemos de Deus, se não houver o obstáculo do pecado.
Ora, muitos praticam obras meritórias, sem contudo alcançarem a perseverança. Nem se pode dizer que
tal se dá por causa do obstáculo do pecado, pois, o fato mesmo de pecar opõe-se à perseverança; de
modo que, quem merecer a perseverança a esse Deus não lhe permite cair em pecado. Logo, não
podemos merecer a perseverança.

SOLUÇÃO. – Tendo o homem naturalmente o livre arbítrio, capaz de pender para o bem e para o mal,
de dois modos pode ele obter de Deus a perseverança no bem. Ou porque, com o auxílio da graça
consumada, o livre arbítrio seja determinado no bem, o que se dará na glória; ou, por influência da
moção divina, que inclina o homem ao bem, até o fim. Pois, como resulta claro do sobredito, podemos
merecer o que se apresenta como um termo à moção do nosso livre arbítrio, movido diretamente por
Deus; não porém o que está para essa moção, como princípio. Por onde é claro, a perseverança da
glória, o termo do referido movimento, pode ser merecida. Mas a perseverança, nesta vida, não pode
ser merecida, por depender somente da moção divina, princípio de todo mérito. Mas aqueles a quem
Deus concede o benefício dessa perseverança a recebem gratuitamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Mesmo o que não merecemos, impetramos nas nossas
orações; pois Deus ouve os pecadores que pedem, dos pecados, o perdão que não merecem, como
claramente o diz Agostinho, comentando aquilo da Escritura: - Sabemos que Deus não ouve a
pecadores. Pois, do contrário, o publicano teria dito em vão: Meu Deus, sê propício a mim
pecador, como se lê na Escritura: E semelhantemente, pedindo, obteremos de Deus o dom da
perseverança, para nós mesmos ou para outrem, embora não o possamos merecer.

RESPOSTA À SEGUNDA. – A perseverança da glória está para a moção do livre arbítrio, como um termo;
não porém, a perseverança desta vida, pela razão exposta.
O mesmo devemos RESPONDER À TERCEIRA OBJEÇÃO, quanto ao aumento da graça, como resulta claro
do que foi dito.

## Art. 10 — Se podemos merecer os bens temporais.
(IIª.IIªe, q. 122, a. 5, ad 4; III. Q. 89, a. 6, ad 3; De Pot., q.6, a. 9.)
O décimo discute-se assim. – Parece que podemos merecer os bens temporais

1. – Pois, podemos merecer o que nos é prometido como premio da justiça. Ora, a lei antiga promete os
bens temporais como recompensa da justiça, conforme está na Escritura. Logo, parece que podemos
merecer os bens temporais.

2. Demais. – Parece que podemos merecer o que Deus nos dá em paga de algum serviço feito. Ora, Deus
às vezes recompensa com certos bens temporais os que lhe prestaram algum serviço. Assim, diz a
Escritura: E porque as parteiras temeram a Deus ele lhes estabeleceu as suas casas. Ao que a Glosa
comenta: a recompensa da beneficência delas podia consistir na vida eterna; mas, por causa do pecado
da mentira, recebem uma recompensa terrestre. E noutro lugar, a Escritura diz: O rei de Babilônia me
rendeu com o seu exército um grande serviço no cerco de Tiro e não se lhe deu nenhuma recompensa; e
depois, acrescenta:haverá uma recompensa para o seu exército; eu lhe entregarei a terra do Egito
porque ele trabalhou para mim. Logo, podemos merecer os bens temporais.

3. Demais. – O bem está para o mérito como o mal para o demérito. Ora, por causa do demérito do
pecado, Deus puniu certos homens com penas temporais, como o demonstra claramente o caso dos
sodomitas. Logo, também podemos merecer os bens temporais.
Mas, em contrário, nem todos recebem igualmente os bens que podem merecer. Mas, ao contrário, os
bens temporais e os males os bons e os maus os recebem conforme à mesma medida, segundo a
Escritura:Acontecem igualmente todas as coisas ao justo e ao ímpio, ao bom e ao mau, ao puro e ao
impuro, ao que sacrifica vítimas e ao que despreza os sacrifícios. Logo, não podemos merecer os bens
temporais.

SOLUÇÃO. – O que podemos merecer é um premio ou uma recompensa, cujo caráter essencial é ser um
bem. Ora, duplo é o bem do homem: o absoluto e o relativo. – O seu bem absoluto é o fim último,
conforme à Escritura: Para mim me é bom unir-me a Deus; e por conseqüência, tudo o que se ordena a
conduzir para esse fim. E tudo isso podemos, absolutamente, merecer. – O bem relativo e não absoluto
do homem é o que lhe é atualmente bem, ou sob um certo aspecto. E esse não podemos merecer
absoluta, mas, relativamente.
Assim sendo, devemos pois dizer, que os bens temporais, considerados enquanto úteis à pratica da
virtude, que nos conduz à vida eterna, podem ser direta e absolutamente objeto de mérito, ao mesmo
título que aumento da graça e tudo o que, depois da primeira graça, nos ajuda a chegar à felicidade. Pois
Deus dá aos justos os bens temporais, e também aos maus, o quanto lhes basta para alcançarem a vida
eterna. E nessa medida esses bens o são absolutamente. Por isso, diz a Escritura: Os que temem ao
Senhor não serão privados de bem algum; e, noutro lugar: Não vi o justo desamparado.
Considerados, porém, esses bens temporais em si mesmos, são bens do homem, não absolutos, mas
relativos. E então não constituem absolutamente matéria de mérito, senão só relativamente, isto é,
enquanto os homens são movidos por Deus à prática de certos atos temporais, com os quais, gozando
do favor divino, conseguem o que se propuserem. De modo que, assim como a vida eterna é,
absolutamente, o premio das obras justas, por causa da moção divina, conforme já dissemos, assim
também os bens temporais, considerados em si mesmos, implicam por essência o caráter de
recompensa, levando-se em conta a moção divina, que move as vontades humanas a buscá-los, embora,
por vezes, ao fazê-lo, os homens não sejam movidos por uma intenção reta.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como diz Agostinho, essas promessas temporais foram
figuras dos bens espirituais futuros, que se realizaram em nós. Pois esse povo carnal se apegava às
promessas da vida presente; mas não só a língua, como também a vida deles foi profética.

RESPOSTA À SEGUNDA. – Essas retribuições referidas se consideram feitas por Deus por causa da
moção divina; não porem em consideração da malícia da vontade, sobretudo no concernente ao rei de
Babilônia. Este não combateu contra Tiro por querer servir a Deus, mas antes, para usurpar para si o
domínio sobre essa cidade. – Semelhantemente, também as parteiras, embora tivessem boa vontade
relativamente à salvação das crianças, contudo essa vontade não foi reta, pois falaram mentirosamente.

RESPOSTA À TERCEIRA. – Os males temporais são afligidos aos ímpios como pena, enquanto que não os
ajudam a alcançar a vida eterna. Aos justos, pelo contrário, que são coadjuvados por esses males, não
são penas, mas antes, remédios, como já dissemos.

RESPOSTA À QUARTA. – Tudo acontece igualmente, tanto para os bons como para os maus, quanto à
substância mesma dos bens ou dos males temporais. Mas não, quanto ao fim; pois, ao passo que os
bons são conduzidos por eles à felicidade, os maus não o são.
E o que dissemos até aqui, sobre a moral geral, é o bastante.