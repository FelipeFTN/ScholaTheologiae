# Questão 64: Do meio termo das virtudes.
Em seguida devemos tratar das propriedades das virtudes. E, primeiro, do meio termo das virtudes.
Segundo da conexão das virtudes. Terceiro, da qualidade delas. Quarto, da duração das mesmas.
Sobre a primeira questão discutem-se quatro artigos:

## Art. 1 — Se a virtude moral consiste num meio termo.
(IIª-IIªe, q. 17, a. 5, ad 2 ; III Sent., dist. XXXIII, q. 1, a. 3, qª 1 De
Virtut., q. 1, a. 13; q. 4. a_ 1, ad 7 ; II Ethic., lect. VI, VII).
O primeiro discute-se assim. — Parece que a virtude moral não consiste num meio termo.

1. — Pois, a noção de termo último repugna a de termo médio. Ora, da essência da virtude é ser termo
último, conforme a opinião de Aristóteles, que a virtude é, na potência, o último. Logo, a virtude moral
não consiste num meio termo.

2. Demais. — O máximo não é médio. Ora, certas virtudes morais tendem ao máximo; assim, a
magnanimidade versa sobre as honras máximas, e a magnificência, sobre as máximas despesas, como se
disse. Logo, nem toda virtude moral consiste num meio termo.

3. Demais. — Se é da essência da virtude moral consistir num meio termo, necessariamente ela deve
destruir-se e não aperfeiçoar-se; quando tende para um extremo. Ora, certas virtudes morais se
aperfeiçoam tendendo para o extremo; tal o caso da virgindade, que tende para o extremo, abstendo-se
de todo prazer venéreo e constituindo assim a castidade perfeitíssima; e em dar tudo aos pobres
consiste a misericórdia perfeitíssima ou liberalidade. Logo, não é da essência da virtude moral consistir
num meio termo.
Mas, em contrário, diz o Filósofo, que a virtude é um hábito eletivo consiste num meio termo.

SOLUÇÃO. — Como do sobredito resulta, a virtude por essência ordena o homem para o bem. E a
virtude moral, propriamente, aperfeiçoa parte da alma em relação a uma determinada matéria. Ora, a
medida e a regra do movimento apetitivo em relação aos objetos de apetição é a razão. Por outro lado,
o bem de tudo o sujeito à medida e à regra consiste em conformar-se com a sua regra; assim, o bem das
coisas artificiadas está em seguir a regra da arte. E por conseqüência, nesses casos, o mal consiste na
discordância da regra ou medida própria; o que se pode dar por sobreexcedência ou deficiência em
relação à medida, como se vê manifestamente em tudo o medido ou regulado. E portanto, é claro que o
bem da virtude moral consiste numa adequação com a medida da razão. Ora, é claro que, entre um
excesso e um defeito, o meio termo é a igualdade ou conformidade. Por onde é manifesto que a virtude
moral consiste num meio termo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A virtude moral tira a sua bondade da regra racional; e
tem como matéria as paixões ou operações. Ora, se compararmos a virtude moral com a razão, a sua
conformidade com esta a coloca num como extremo, ocupando o outro extremo a não conformidade
com a razão, por excesso ou por defeito. Se porém considerarmos a matéria da virtude moral, ela
constitui um meio termo, porque reduz a paixão à regra racional. E por isso, o Filósofo diz, que a virtude
é, por substância, um termo médio, enquanto impõe a sua regra à matéria própria; por outro
lado, enquanto sendo o que é ótimo e bom, i. é, enquanto conforme com a razão, ocupa um extremo.

RESPOSTA À SEGUNDA. — O médio e o extremo dos atos e das paixões dependem de diversas
circunstâncias. Por onde, nada impede constitua uma virtude um extremo, quanto a uma circunstância,
e um meio, quanto a outras circunstâncias, pela sua conformidade com a razão. Tal é caso da
magnificência e da magnanimidade. Pois, se levarmos em conta a quantidade absoluta do objeto para
que tende o magnífico e o magnânimo, essas virtudes constituem um extremo e um máximo. Mas, se o
considerarmos em relação a outras circunstâncias, constituirão um meio; pois tendem para um máximo
que é a conformidade com a regra da razão e consiste em agir onde, quando e por causa do que
importa; constituirão um excesso se tenderem para um máximo consistente em agir quando, onde ou
por causa do que importa; e, enfim, um defeito se não tenderem para um máximo consistente em agir
onde e quando é necessário. E é isto que diz o Filósofo: o magnânimo, pela sua magnanimidade, está
constituído num extremo; mas por agir como deve, está num meio termo.

RESPOSTA À TERCEIRA. — O que dizemos da magnanimidade dizemos também da virgindade e da
pobreza. Pois, a virgindade se abstém de todos os prazeres venéreos, e a pobreza, de todas as riquezas,
por causa do que e segundo o que isso é necessário, a saber, segundo a ordem de Deus e por causa da
vida eterna. E se isso se der por obediência ao que não deve ser, i. é, por alguma superstição ilícita ou
ainda por vanglória, teremos agido inutilmente. Se, por outro lado, o fizermos quando não é necessário
ou por obediência indevida, haverá vício por defeito, como o manifestam os transgressores do voto de
virgindade ou de pobreza.

## Art. 2 — Se o meio termo da virtude moral é o meio termo da razão ou o da coisa.
(IIª-IIªe, q. 58. a. 10; III Sent., dist. XXXIII, q. 1, a. 3. qª 2; De Virtut., q. 1, a.13).
O segundo discute-se assim. — Parece que o meio termo da virtude moral não é o meio termo da
razão, mas o da coisa.

1. — Pois, o bem da virtude moral consiste em ser um meio termo. Ora, o bem, como se disse, existe
nas coisas mesmas. Logo, o meio termo da virtude moral é o da realidade mesma.

2. Demais. — A razão é uma faculdade apreensiva. Ora, a virtude moral não consiste no meio termo das
apreensões, mas antes, no das obras e das paixões. Logo, o meio termo da virtude moral não é o
racional mas, o real.

3. Demais. — O meio termo de urna proporção aritmética ou geométrica é o da realidade. Ora, tal é o
meio termo da justiça, corno se disse. Logo, o meio termo da virtude moral não é o racional, mas o real.
Mas, em contrário, diz o Filósofo, que a virtude moral consiste num meio termo relativo a nós, conforme
a razão o determina.

SOLUÇÃO. — O meio termo racional pode ser entendido em duplo sentido. — Num primeiro sentido,
consiste no ato mesmo da razão, este sendo como reduzido a um termo médio. E assim, como a virtude
moral não aperfeiçoa o ato da razão, mas o da virtude apetitiva, o meio termo da virtude moral não é o
da razão. —Noutro sentido, pode chamar-se meio termo da razão aquilo que ela estabelece numa
determinada matéria. E assim, todo meio termo da virtude moral é meio termo da razão, porque, como
já dissemos, a virtude moral consiste num meio termo por conformidade com a razão reta.
Umas vezes porém sucede que o meio termo da razão é também o real; e então necessariamente o
meio termo da virtude moral é o mesmo da realidade; e tal é o caso da justiça. Outras vezes contudo o
meio termo da razão não é o da realidade, mas é relativo a nós, e tal é o caso de todas as outras virtudes
morais. E isso porque a justiça versa sobre os atos relativos a coisas exteriores, e cuja retidão deve ser
estabelecida absolutamente e em si mesma considerada, como já dissemos. E portanto, o meio termo
racional da justiça coincide com o da causa, a saber enquanto ela dá a cada um o que lhe é devido, nem
mais nem menos. Ao passo que as demais virtudes morais versam sobre as paixões internas, cuja
retidão não pode ser estabelecida do mesmo modo, porque as paixões humanas se manifestam de
modos diversos. Por onde é necessário que a retidão da razão, no concernente às paixões, seja
estabelecida por uma relação conosco, que somos afetados pelas paixões.
E daqui se deduzem as RESPOSTAS ÀS OBJEÇÕES— Pois, as duas primeiras se fundam no meio termo da
razão existente no ato mesmo desta. — E a terceira se funda no meio termo da justiça.

## Art. 3 — Se as virtudes intelectuais consistem num meio termo.
(III Sent., dist. XXXIII, q. 1. a. 3, qª 3; De Virtut., q. 1, a. 1; q. 4, a. 1, ad 7).
O terceiro discute-se assim. — Parece que as virtudes intelectuais não consistem num meio termo.

1. — Pois, as virtudes morais consistem num meio termo por se submeterem à regra da razão. Ora,
como as virtudes intelectuais existem na razão mesma, não podem estar sujeitas a uma regra superior.
Logo, as virtudes intelectuais não consistem num meio termo.

2. Demais. — O meio termo da virtude moral é determinado pela virtude intelectual, conforme o dito de
Aristóteles: a virtude consiste num meio termo determinado pela razão, como o determinaria o sábio.
Se pois, a virtude intelectual consistir ainda num outro meio termo, esse lhe há de ser determinado por
alguma outra virtude, e assim proceder-se-ia ao infinito.

3. Demais. — Termo médio existe, propriamente, entre contrários, como se vê claramente no Filósofo.
Ora, no intelecto não pode haver nenhuma contrariedade, porque os próprios contrários — como preto
e branco, são e doente — enquanto nele existentes, deixam de ser tais. Logo, nas virtudes intelectuais
não há meio termo.
Mas, em contrário, a arte é uma virtude intelectual, como já se disse e contudo, é um meio termo, como
também já se estabeleceu. Logo, a virtude intelectual consiste num meio termo.

SOLUÇÃO. — O bem de um ser consiste num meio termo, enquanto se submete à regra ou à medida,
que pode ultrapassar ou não alcançar, como já dissemos. Ora, tanto a virtude intelectual como a moral
ordenam-se para o bem, segundo ficou estabelecido. Por onde, estando o bem da virtude intelectual
sujeito à medida, está sujeito também ao meio termo da razão. Ora, o bem da virtude intelectual é o
verdadeiro: o verdadeiro absoluto, da virtude especulativa, como se disse; e o da virtude prática, o
verdadeiro conforme ao apetite reto.
A verdade do nosso intelecto, absolutamente considerada, é como medida pela realidade. Pois a
realidade é a medida do nosso intelecto, segundo se disse; pois, a verdade de uma opinião ou de uma
oração depende de uma realidade que é ou não é. Assim, pois, o bem da virtude intelectual especulativa
consiste num certo meio termo conforme a realidade mesma, enquanto diz ser o que é, e não ser o que
não é; e nisso consiste a essência da verdade. O excesso se manifesta na afirmação falsa, que diz ser o
que não é; e o defeito, em a negação falsa, que diz não ser o que é.
Por outro lado, a verdade da virtude intelectual prática, comparada com a realidade, está para ela como
o que é medido; e assim, tanto nas virtudes intelectuais práticas, como nas especulativas, o meio termo
é considerado na sua conformidade com a realidade. Mas em relação ao apetite, ele exerce o papel de
regra e medida. Por onde, o meio termo da virtude moral, i. é, a retidão da razão, é também o da
prudência; mas desta, enquanto regula e mede e daquela, como medida e regulada. Semelhantemente,
o excesso e o defeito é tomado em acepções diversas, num e noutro caso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Também a virtude moral tem a sua medida, como
dissemos; e é pela conformidade com esta que é considerado o meio termo daquela.

RESPOSTA À SEGUNDA. — Não há necessidade de proceder ao infinito, em relação às virtudes, porque a
medida e a regra da virtude intelectual não é algum outro gênero de virtude, mas a realidade mesma.

RESPOSTA À TERCEIRA. — As coisas contrárias, em si mesmas, não têm contrariedade na alma, porque
um é a razão de conhecermos o outro; e contudo, no intelecto, há a contrariedade da afirmação e da
negação, que são contrarias entre si, como se diz no fim do Perihermeneias. Pois, embora o ser e o não-
ser não sejam contrários, mas opostos por contrariedade, se os considerarmos como existentes na
realidade, porque um é ente e outro, puro não-ente; contudo, referidos ao ato da alma, um e outro
exprimem algum ser. Por onde, o ser e o não-ser são contraditórios; mas a opinião que considera o bem
como bem é contrária a que o considera como não-bem. E entre esses contrários o meio termo é a
virtude intelectual.

## Art. 4 — Se a virtude teológica consiste num meio termo.
(IIª-IIªe,q. 17, a.5, ad 2; III Sent., dist. XXXIII,q. 1, a. 3.q 4ª; De Virtut., 1, a. 13; q. 2, a. 2, ad 10, 13 ;q. 4. a.
1, ad 7: Rom., cap.XII, lect 1).
O quarto discute-se assim. — Parece que a virtude teológica consiste num meio termo.

1. — Pois, o bem das outras virtudes consiste num meio termo. Ora, a virtude teológica as excede em
bondade. Logo, com maioria de razão, consiste num meio termo.

2. Demais. — O meio termo da virtude moral está em ser o apetite regulado pela razão, enquanto que o
da virtude intelectual, em ser o nosso intelecto medido pelo objeto. Ora, a virtude teológica tanto
aperfeiçoa o intelecto como o apetite, como já se disse. Logo, também consiste num meio termo.

3. Demais. — A esperança, que é uma virtude teologal, é o meio termo entre o desespero e a
presunção; semelhantemente, a fé se manifesta como meio termo entre heresias contrárias, como diz
Boécio. Assim, confessando que em Cristo há uma só pessoa e duas naturezas, estamos num termo
médio, entre a heresia de Nestório, que ensina existirem nele duas pessoas e duas naturezas, e a de
Eutíquio, que só admite uma pessoa e uma natureza. Logo, a virtude teológica consiste num meio
termo.
Mas, em contrário. — Em todos os casos em que a virtude consiste num meio termo, podemos pecar
por excesso ou por defeito. Ora, em relação a Deus, objeto da virtude teológica, não podemos pecar por
excesso; pois, diz a Escritura (Ecle 43, 33): Bendizendo vós ao Senhor, exaltai-o quando podeis; porque
ele é maior que todo louvor. Logo, a virtude teológica não consiste num meio termo.

SOLUÇÃO. — Como já dissemos, o meio termo da virtude é considerado por conformidade com a sua
regra ou medida, que podemos ultrapassar ou não alcançar. Ora, a virtude teológica é susceptível de
dupla medida — Uma fundada em a noção mesma de virtude. E assim a medida e a regra da virtude
teológica é o próprio Deus. Porque a nossa fé é regulada pela verdade divina; a caridade, pela sua
bondade; e a esperança, enfim, pela grandeza do seu poder e do seu amor. Ora, esta medida excede
toda a faculdade humana. Por onde, o homem não poderá nunca amar a Deus, nele crer e nele esperar,
tanto quanto deve. E portanto, com maior razão, não poderá haver aí nenhum excesso. Logo, o bem da
virtude teologal não pode consistir num meio termo, mas será tanto melhor quanto mais se aproximar
do sumo bem. — A outra regra ou medida da virtude teologal se funda em nós; porque, embora não
possamos nos dar a Deus tanto quanto devemos, devemos contudo, crendo, esperando e amando-o,
nos aproximar dele conforme a capacidade da nossa condição. Por onde, acidentalmente, podemos,
quanto ao que nos diz respeito, distinguir na virtude teológica um meio e extremos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O bem das virtudes intelectuais e morais consiste num
meio termo conforme a uma regra ou medida que podemos ultrapassar. O que não se dá com as
virtudes teologais, em si mesmas consideradas, como já dissemos.

RESPOSTA À SEGUNDA. — As virtudes morais e intelectuais aperfeiçoam o nosso intelecto e o nosso
apetite, em relação a uma medida e a uma regra criada; ao passo que as virtudes teológicas o fazem em
relação à medida e à regra incriada. Logo, não há semelhança.

RESPOSTA À TERCEIRA. — A esperança é um meio termo entre a presunção e o desespero, no que se
refere a nós. Assim, dizemos que presume quem espera de Deus um bem que lhe excede a condição; e
desespera por não esperar o que, por sua condição, poderia esperar. Mas não poderá haver
superabundância de esperança, relativamente a Deus, cuja bondade é infinita. — Semelhantemente, a
fé é um meio termo entre heresias contrárias, não por comparação com o seu objeto, que é Deus, em
quem não podemos crer com excesso; mas enquanto a opinião humana mesma é um meio termo entre
opiniões contrárias, como do sobredito resulta.