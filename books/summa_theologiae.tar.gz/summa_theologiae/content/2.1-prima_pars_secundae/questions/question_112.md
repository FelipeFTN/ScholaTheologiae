# Questão 112: Da causa da graça
Em seguida devemos tratar da causa da graça.
E Nesta questão discutem-se cinco artigos:

## Art. 1 — Se só Deus é a causa da graça.
(III, q. 62, a. 1; q. 64, a. 1; I Sent., dist. XIV, part, q. 3; dist. XL, q.4, 2, ad 3; II, dist. V, q. 1, a.3, qª 1;
DeVerit., q. 27, a. 3; Ad Rom., cap. V, lect. I).
O primeiro discute-se assim. – Parece que não é só Deus a causa da graça.

1. – Pois, diz a Escritura: a graça e a verdade foi trazida por Jesus Cristo. Ora, o nome de Jesus Cristo
designa não só a natureza divina unida à humana, mas também essa natureza humana criada e
assumida por Deus. Logo, alguma criatura pode ser causa da graça.

2. Demais. – Os sacramentos da lei nova e os da antiga diferem em aqueles causarem a graça, e estes
somente a significarem. Ora, os sacramentos da lei nova são elementos visíveis. Logo, nem só Deus é a
causa da graça.

3. Demais. – Segundo Dionísio, os anjos purificam, iluminam e aperfeiçoam, tanto os anjos inferiores,
como os homens. Ora, a criatura racional é purificada, iluminada e aperfeiçoada pela graça. Logo, não é
só Deus a causa da graça.
Mas, em contrário, diz a Escritura: O Senhor dará a graça e a glória.

SOLUÇÃO. – Nenhum ser pode agir fora dos limites da sua espécie, pois a causa há de ser sempre
superior ao efeito. Ora, o dom da graça excede as faculdades de toda natureza criada, pois a graça não é
senão uma participação da natureza divina, que sobrepuja qualquer outra natureza. Por onde, é
impossível qualquer criatura causar a graça. E portanto e necessariamente, só Deus pode deificar,
comunicando o consórcio da sua natureza, por uma participação de semelhança, assim como só o fogo
pode dar a um corpo o estado de combustão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A humanidade de Cristo é um como instrumento da sua
divindade, na expressão de Damasceno. Ora, um instrumento não realiza a ação do agente principal, por
virtude própria, mas em virtude daquele. Por onde, a humanidade de Cristo não causa a graça por
virtude própria, mas em virtude da divindade adjunta, que torna salutares as obras dessa humanidade.

RESPOSTA À SEGUNDA. – Assim como na pessoa mesma de Cristo a humanidade causa a nossa salvação
pela graça, mas sob a ação principal da virtude divina; assim também os sacramentos da lei nova,
derivados de Cristo, causam a graça instrumental; mas é a virtude do Espírito Santo, operando neles,
que a causa principalmente, conforme a Escritura: Quem não renascer da água e do Espírito Santo não
pode entrar no reino de Deus.

RESPOSTA À TERCEIRA. – O anjo purifica, ilumina e aperfeiçoa outro anjo ou o homem, instruindo-o, de
certo modo; não porém justificando, pela graça. Por isso, Dionísio diz, que essa purificação, iluminação e
perfeição não passam de uma recepção da ciência divina.

## Art. 2 — Se, da parte do homem, é necessária alguma preparação ou disposição para a graça.
(Qu. Seq., a. 3; IV Sent., dist. XVII, a. 2, qª 1, 2; In Ion., cap. IV, lect. II; Ad Hebr., cap. XII, lect. III).
O segundo discute-se assim. – Parece que, da parte do homem, não é necessária nenhuma preparação
ou disposição para a graça.

1. – Pois, como diz o Apóstolo, ao que obra, não se lhe conta o jornal por graça, mas por dívida. Ora, a
preparação do homem pelo livre arbítrio só é possível por alguma operação. Logo, não há lugar para a
graça.

2. Demais. – Quem se ataca no pecado não se prepara a receber a graça. Ora, a certos, que nele se
atacam, foi dada a graça. Tal é o caso de Paulo, que a alcançou, respirando ainda ameaças e morte
contra os discípulos do Senhor. Logo, da parte do homem, não é necessária nenhuma preparação para a
graça.

3. Demais. – Um agente de poder infinito não precisa de matéria predisposta, pois nem dela, em si
mesma, precisa, como o demonstra a criação, a que é comparado a infusão da graça, chamada nova
criatura. Ora, só Deus, cujo poder é infinito, causa a graça, como se disse. Logo, da parte do homem, não
é necessária nenhuma preparação para alcançar a graça.
Mas, em contrário, diz a Escritura: Prepara-te a saíres ao encontro do teu Deus; e: Preparai os vossos
corações para o Senhor.

SOLUÇÃO. – Como já dissemos, a graça tem duas acepções; ora, significa o dom habitual de Deus; ora, o
auxílio de Deus, que move a alma para o bem. – Na primeira acepção, exige de nós uma preparação,
porque nenhuma forma pode existir senão na matéria já predisposta. – Na segunda, não exige, da parte
do homem, nenhuma preparação, quase preveniente ao auxílio divino; antes, qualquer preparação, que
possa existir no homem, provém do auxílio de Deus, que move a alma para o bem. E sendo assim, o
próprio bom movimento do livre arbítrio, pelo qual nos preparamos a receber o dom da graça, é um ato
procedente da moção divina. E neste sentido, diz-se que o homem se prepara, conforme a Escritura: Da
parte do homem está o preparar a sua alma; essa preparação provem principalmente de Deus, que
move o livre arbítrio. E em tal acepção, se diz que a vontade humana é preparada por Deus, e que Deus
lhe dirige os passos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Certa preparação do homem para ter a graça vai
simultaneamente com a infusão mesma dela. E tal operação é, certo, meritória; não, da graça, já
possuída, mas da glória, que ainda não o é. Há porem outra preparação, imperfeita, para a graça, que ás
vezes precede o dom da graça santificante, e contudo provém da moção divina. Essa preparação,
porém, não basta para o mérito, enquanto o homem não foi justificado pela graça; porque nenhum
mérito pode provir a não ser dela, como a seguir se dirá.

RESPOSTA À SEGUNDA. – O homem não pode preparar-se para a graça ele chegue à preparação
perfeita, súbita ou paulatinamente. Donde o dizer a Escritura: A Deus é fácil o enriquecer de repente ao
pobre. Ora, acontece algumas vezes, que Deus move o homem a algum bem, mas não perfeito; e essa
preparação precede á graça. Outras vezes, porém, rápida e perfeitamente, move-o para o bem e ele
recebe a graça de súbito, conforme a Escritura: Todo aquele que do Pai ouviu e aprendeu vem a mim.
Ora, isto deu-se com Paulo que, de súbito, quando mais se atascava no pecado, teve o coração
perfeitamente movido por Deus, que o fez ouvir, aprender e vir; por isso, conseguiu, de súbito, a graça.

RESPOSTA À TERCEIRA. – Um agente de poder infinito não exige qualquer matéria preexistente ou
predisposta, quase um pressuposto, por ação de outra causa. Contudo é necessário, conforme à
condição da coisa a ser criada, causar nela tanto a matéria como a disposição devida para a forma.
Semelhantemente, para Deus infundir a graça na alma, nenhuma preparação há exigida, que Ele não
realize.

## Art. 3 — Se é necessariamente dada a graça a quem para ela se prepara, ou faz tudo quanto pode.
(IV Sent., dist. XVII, q. 1, a. 2, qª 3).
O terceiro discute-se assim. – Parece que necessariamente é dada a graça a quem para ela se prepara
ou faz tudo quanto pode.

1. – Pois, aquilo da Escritura – Justificados pela fé, tenhamos paz – diz a Glosa: Deus recebe quem junto
dele se refugia; do contrário, seria iníquo. Ora, é impossível haver iniqüidade em Deus. Logo, é
impossível não receba quem busca refúgio junto d’Êle e, portanto, alcança a graça necessariamente.

2. Demais. – Anselmo diz, que a causa pela qual Deus não concede a graça ao diabo é não ter ele
querido recebê-la, nem para ela estar preparado. Ora, removido a causa fica o efeito necessariamente
removido. Logo, a quem quiser receber a graça é ela necessariamente concedida.

3. Demais. – O bem é de si mesmo comunicativo, como claramente se vê em Dionísio. Ora, o bem da
graça é superior ao da natureza. Por onde, como a forma natural se une necessariamente à matéria para
ela disposta, com maior razão a graça há de ser necessariamente dada a quem para ela está preparado.
Mas, em contrário, o homem esta para Deus como o barro, para o oleiro, conforme a Escritura: Como o
barro está na mão do oleiro, assim vós estais na minha mão. Ora, o barro não recebe necessariamente a
forma que lhe dá o oleiro, por preparado que esteja. Logo, nem o homem, por mais que se prepare,
recebe necessariamente a graça, de Deus.

SOLUÇÃO. – Como já dissemos, a preparação do homem, para a graça procede de Deus, como o motor;
e do livre arbítrio, como do movido. Ora, a preparação pode ser considerada à dupla luz. – Primeiro,
enquanto procedente do livre arbítrio. E então, nada tem em si que exija a graça necessariamente; pois,
o dom da graça excede toda preparação de que o homem é capaz. – Segundo, enquanto procedente da
moção divina. E então, atinge necessariamente aquilo a que Deus a ordenou, não coagida, mas
infalivelmente, porque o plano de Deus não pode falhar, conforme Agostinho que diz: todos os que
Deus salva, pelos seus benefícios, são certissimamente salvos. E assim, por designo de Deus, que move
um homem, cujo coração foi movido, alcança a graça infalivelmente, segundo a Escritura: Todo aquele
que do Pai ouviu e aprendeu vem a mim.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A Glosa citada se refere ao que se refugia junto de Deus
por um ato meritório do livre arbítrio, já informado pela graça. E então, se Deus não o recebesse, iria
contra a justiça que Êle próprio estabeleceu. – Ou, se a Glosa se refere ao movimento do livre arbítrio
anterior à graça, entende que esse mesmo refugiar-se do homem em Deus provém da moção divina, e
por isso é justo não seja vão.

RESPOSTA À SEGUNDA. – A falta da primeira graça é por culpa nossa; mas, a causa primeira de ser
conferida é Deus, conforme a Escritura: A tua perdição, ó Israel, toda vem de ti; só em mim está o teu
auxílio.

RESPOSTA À TERCEIRA. – Mesmo na ordem das coisas naturais, a disposição da matéria não acarreta
necessariamente a consecução da forma, salvo, pela virtude do agente causador da disposição.

## Art. 4 — Se a graça é maior em um que em outro.
O quarto discute-se assim. – Parece que a graça não é maior em um que em outro.

1. – Pois a graça é causada em nós pelo amor divino, como já se disse. Ora, a Escritura diz: Ele fez ao
pequeno e ao grande e tem igualmente cuidado de todos. Logo, todos recebem a graça igualmente, de
Deus.

2. Demais. – O grau supremo não é susceptível de mais nem de menos. Ora, a graça está no grau
supremo, pois conduz ao fim último. Logo, não é susceptível de mais nem de menos; e portanto não é
maior em um que em outro.

3. Demais. – A graça é a vida da alma, como já se disse. Ora, a vida não é susceptível de mais e de
menos. Logo, nem a graça.
Mas, em contrário, diz a Escritura: a cada um de nós foi dada a graça, segundo a medida do dom de
Cristo. Ora, o que é dado com medida não o é igualmente a todos. Logo, em todos tem graça igual.

SOLUÇÃO. – Como já dissemos, o hábito é susceptível de dupla grandeza. Uma, relativa ao fim ou
objeto, pelo qual se considera uma virtude mais nobre que outra, enquanto ordenada a um bem maior.
Outra, relativa ao sujeito, enquanto que participa mais ou menos desse hábito inerente. – Ora, quanto à
primeira grandeza a graça santificante não é susceptível de aumento ou diminuição, pois por natureza a
graça une o homem a Deus, sumo bem. – Mas, quanto ao sujeito, é susceptível de mais ou de menos,
enquanto um é iluminado por ela mais perfeitamente que outro. Esta diversidade se explica, de certo
modo, pelo grau de preparação do sujeito, para a graça; pois quem se prepara melhor recebe a graça
mais abundante. Mas esta não pode ser considerada como a razão primeira de tal diversidade; pois a
preparação para a graça não depende do homem, senão enquanto o seu livre arbítrio é preparado por
Deus. Por onde, a causa primeira dessa diversidade deve ser procurada em Deus mesmo, que dispensa
diversamente os dons da sua graça para, dos diversos graus dela, resultar a beleza e a perfeição da
Igreja. Assim como estabeleceu os diversos graus dos seres para o universo ser perfeito. Por isso, o
Apóstolo, depois de ter dito – A cada um foi dada a graça, segundo a medida do dom de Cristo – e de ter
enumerado as diversas graças, acrescenta: Para consumação dos santos, para edificar o corpo de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O cuidado divino pode ser tomado em duplo sentido. –
Primeiro, como o ato mesmo divino, simples e uniforme. E assim, aplica-se igualmente a todos, porque
por um ato simples dispensa os dons maiores e os menores. – De outro modo, pode ser considerado
relativamente ao que as criaturas dele recebem, e daí as desigualdades. Pois, Deus, cuidando das
criaturas, dá a umas maiores dons que a outras.

RESPOSTA À SEGUNDA. – A objeção procede quanto ao primeiro modo da grandeza da graça. Pois ela
não pode ser maior por nos ordenar para um bem maior, mas porque nos ordena mais ou menos, a
participar, mais ou menos, do mesmo bem. Porquanto o sujeito pode participar, mais intensa ou
remissamente, da graça mesma, ou da glória final.

RESPOSTA À TERCEIRA. – A vida natural, constituindo a substancia mesma do homem, não é suscetível
de mais nem de menos. Ao passo que, da vida da graça o homem participa acidentalmente, e portanto
pode tê-la mais ou menos.

## Art. 5 — Se o homem pode saber que tem a graça.
( I Sent., dist. XVII, a. 4; III, dist. XXXIII, q. 1.a. 2, ad 1; IV, dist. IX, q. 1, a. 3, qª 2; dist. XXI, q. 2, a. 2, ad 2;
De Verit., q. 10, a. 10; II Cor., cap. XII, lect. I; cap. XIII, lect. II).
O quinto discute-se assim. – O homem pode saber que tem a graça.

1. – Pois, a graça está, por sua essência, na alma. Ora, a alma tem conhecimento certíssimo do que nela
está, essencialmente, como se vê claro em Agostinho. Logo, a graça pode ser certissimamente
conhecida por quem a possui.

2. Demais. – Como a ciência, também a graça é dom de Deus. Ora, quem recebeu de Deus a ciência,
sabe que a tem conforme a Escritura: O Senhor me deu a verdadeira ciência destas coisas. Logo, por
igual razão, quem recebeu de Deus a graça sabe que a tem.

3. Demais. – O lume é mais cognoscível que as trevas; porque, segundo o Apóstolo, tudo o que se
manifesta é luz. Ora, o pecado, que é a treva espiritual, o pecador pode saber com certeza que o tem.
Logo, com maior razão, a graça, que é a luz espiritual.

4. Demais. – O Apóstolo diz: Ora, nós não recebemos o espírito deste mundo, mas sim o Espírito que
vem de Deus, para sabermos as coisas que por Deus nos foram dadas. Ora, a graça é o primeiro dom de
Deus. Logo, quem recebe a graça, pelo Espírito Santo, sabe quem, pelo mesmo, ela lhe foi dada.

5. Demais. – Foi dito a Abraão, por parte do Senhor: Agora conheci que temes a Deus, i. é, te
fizconhecer. Ora, esse lugar se refere ao temor casto, que não vai sem a graça. Logo, o homem pode
saber que a tem.
Mas, em contrário, diz a Escritura: Não sabe o homem se é digno de amor ou de ódio. Ora,a graça
santificante torna o homem digno do amor de Deus. Logo, ninguém pode saber se tem a graça
santificante.

SOLUÇÃO. – De três modos podemos conhecer um objeto. Primeiro, pela revelação. E assim, alguém
pode saber se está em graça; pois Deus o revela, às vezes a certos, por um privilégio especial, para já
nesta vida, começarem a gozar a alegria da segurança, e prossigam, mas confiante e fortemente, nas
suas obras magníficas, e suportem os males da vida presente. Assim, foi dito a Paulo: Basta-te a minha
graça.
De outro modo, o homem pode conhecer um objeto, por si mesmo e com certeza. E então, ninguém
pode saber que tem a graça. Pois, só podemos ter certeza do que podemos julgar pelo seu princípio
próprio. Assim, temos certeza das conclusões demonstrativas, pelos princípios indemonstráveis
universais; pois ninguém pode saber que tem a ciência de uma conclusão, se ignorar o princípio. Ora, o
princípio da graça e o seu objeto é Deus mesmo que, por causa da sua excelência, é-nos desconhecido,
conforme aquilo da Escritura: Com efeito, Deus é grande, que sobre excede à nossa ciência. Portanto,
não podemos conhecer com certeza a sua presença nem a sua ausência em nós, segundo a Escritura: Se
ele vier a mim, eu o não verei; se for eu o não perceberei. Logo, o homem não pode julgar com certeza
se tem a graça, consoante à Escritura: Pois, nem ainda eu me julgo a mim mesmo; pois, o Senhor é
quem me julga.
De terceiro modo, conhecemos um objeto conjecturalmente, por certos sinais. E desta maneira
podemos saber que temos a graça, percebendo que pomos em Deus o nosso prazer e desprezamos as
coisas mundanas e não tendo consciência de nenhum pecado mortal. E neste sentido, pode-se entender
o lugar da Escritura: Eu darei ao vencedor o maná escondido, o qual não conhece senão quem no
recebe. Porque, quem o recebe o sabe, por experiência da sua doçura, a qual não a sente quem não o
recebe. Mas tal conhecimento é imperfeito. Por isso o Apóstolo diz: De nada me argúi a consciência;
mas nem por isso me dou por justificado. Pois, como diz outro lugar da Escritura: Quem é que conhece
os seus delitos? Purifica-me dos que me são ocultos, e perdoa ao teu servo os alheios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O que está essencialmente na alma é conhecido por
conhecimento experimental, enquanto o homem descobre, pelos seus atos, os princípios internos que
os produzem. Assim, percebemos a vontade, querendo, e a vida, pelos atos vitais.

RESPOSTA À SEGUNDA. – Essencialmente, a ciência dá ao homem a certeza sobre o seu objeto; do
mesmo modo, a fé torna-o certo do seu. E isto, porque a certeza pertence à perfeição do intelecto, onde
existem os dons referidos. Portanto, quem tem a ciência ou a fé está certo de as ter. Não se dá o
mesmo, porém, com a graça, com a caridade e dons semelhantes, que aperfeiçoam a potência apetitiva.

RESPOSTA À TERCEIRA. – O pecado tem, como princípio o objeto, um bem mutável, que nos é
conhecido. Ao passo que o objeto ou o fim da graça é-nos desconhecido, por causa da imensidade da
sua luz, segundo a Escritura: Habita numa luz inacessível.

RESPOSTA À QUARTA. – O Apóstolo, nesse lugar, se refere aos dons da glória que nos são dados em
esperança. Ora, nós os conhecemos certissimamente pela fé, embora não saibamos com certeza que
temos a graça pela qual podemos merecê-los. – Ou pode-se dizer que se refere a um conhecimento
privilegiado, dado pela revelação. Por isso, acrescenta: Porém Deus nos revelou a nós pelo seu Espírito.

RESPOSTA À QUINTA. – Essa palavra dita a Abraão pode se referir ao conhecimento experimental,
derivado da verificação da obra realizada. Pois, pela obra que fez, Abraão podia conhecer
experimentalmente que tinha o temor de Deus. – Ou também pode referir-se à revelação.