# Questão 19: Da bondade do ato interior da vontade.
Em seguida devemos tratar da bondade do ato interior da vontade.
E sobre esta questão, dez artigos se discutem:

## Art. 1 — Se a bondade da vontade depende do seu objeto.
O primeiro discute-se assim. ― Parece que a bondade da vontade não depende do seu objeto.

1. ― Pois, a vontade só pode querer o bem, porquanto, o mal lhe é contrário, como diz Dionísio. Se
portanto a bondade da vontade dependesse do seu objeto, resultaria que toda vontade seria boa e má,
nenhuma.

2. Demais. ― O bem principal é do fim; e por isso a bondade deste, como tal, não depende de nada.
Ora, segundo o Filósofo, a ação boa é um fim, embora a produção nunca o seja porque sempre se
ordena, à coisa produzida, como ao fim. Logo, a bondade da vontade não depende de nenhum objeto.

3. Demais. ― Qual é um ser tal é o que produz. Ora, o objeto da vontade é bom pela sua bondade
natural. Logo, não pode ele conferir-lhe a ela uma bondade moral; e portanto esta, quando concernente
à vontade, não depende do objeto.
Mas, em contrário, diz o Filósofo, que a justiça é que leva certos a quererem ações justas; e pela mesma
razão, pela virtude é que querem o bem. Ora, boa é a vontade que opera virtuosamente. Logo a
bondade da vontade provém de querer o bem.

SOLUÇÃO. ― O bem e o mal, em si, diferenciam os atos da vontade, à qual se referem, assim como o
verdadeiro e o falso se referem à razão cujos atos distingue a diferença existente entre a verdade e a
falsidade, que nos leva a considerar uma opinião como verdadeira ou falsa. Por onde, a vontade boa e a
má são atos especificamente diferentes. Ora, a diferença específica dos atos depende dos objetos, como
já se disse. Logo, o bem e o mal dos atos da vontade dependem propriamente dos objetos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Longe de sempre querer o verdadeiro bem, a vontade
quer às vezes um bem aparente, bem, certo, de algum modo, mas que não convém, absolutamente ao
apetite. E por isso o ato da vontade, nem sempre bom, é às vezes, mau.

RESPOSTA À SEGUNDA. ― Embora um ato possa de certo modo ser o fim último do homem, nem por
isso é ato da vontade, como já se disse antes.

RESPOSTA À TERCEIRA. ― O bem é apresentado à vontade pela razão como objeto; e na medida em
que entra na ordem da razão, pertence à ordem moral e causa, no ato da vontade, a bondade moral.
Pois a razão é o princípio dos atos humanos e morais, como antes se disse.

## Art. 2 — Se a bondade da vontade depende só do objeto.
O segundo discute-se assim. ― Parece que a bondade da vontade não depende só do objeto.

1. ― Pois, o fim tem mais afinidade com a vontade do que com outra potência. Ora, os atos das outras
potências recebem a sua bondade, não só do objeto, mas também do fim, como do sobredito resulta.
Logo, também a vontade recebe a sua, não do objeto, mas do fim.

2. Demais. ― A bondade de um ato provém não só do objeto mas também das circunstâncias, como já
se disse. Ora, a diferença de bondade e malícia no ato da vontade varia com a diversidade das
circunstâncias; assim, se queremos alguma coisa quando, onde, quanto e como devemos ou não
devemos querer. Logo, a bondade da vontade depende não só do objeto, mas também das
circunstâncias.

3. Demais. ― A ignorância das circunstâncias excusa a malícia da vontade, como já se disse. Ora, isto
não se daria se a bondade e a malícia da vontade não dependessem das circunstâncias. Logo, destas
dependem e não só do objeto.
Mas, em contrário. ― As circunstâncias, como tais, não especificam um ato, como já se disse. Ora, o
bem e o mal são diferenças específicas do ato de vontade, segundo foi dito. Logo, a bondade e a malícia
da vontade não dependem das circunstâncias, mas só do objeto.

SOLUÇÃO. ― Em qualquer gênero, quanto mais uma coisa tiver prioridade sobre outras tanto mais
simples será e tanto menos elementos de composição terá; assim os primeiros corpos são simples.
Assim, como facilmente se verifica, o que num gênero tem prioridade é de certa maneira simples e uno.
Ora, o princípio da bondade e malícia dos atos humanos procede de um ato da vontade. E portanto, a
bondade e a malícia desta se fundam nalguma unidade, ao passo que a bondade e a malícia dos outros
atos podem advir-lhes de origens diversas.
Ora, o que num gênero é princípio não é acidental, mas essencial; pois, tudo o que é acidental se reduz
ao seu princípio, que é o essencial. Logo, a bondade da vontade depende unicamente do que torna o
ato essencialmente bom, isto é, do objeto, e não das circunstâncias, acidentes do ato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O fim é o objeto da vontade mas não das demais
faculdades. Por onde, a bondade do ato da vontade proveniente do objeto não difere da que provém do
fim, a não ser acidentalmente, se um fim depender de outro e uma vontade, de outra; ao passo que, nos
atos das outras faculdades, há diferença entre essas duas bondades.

RESPOSTA À SEGUNDA. ― Suposto que a vontade quer o bem, nenhuma circunstância pode torná-la
má. E quando se diz que podemos querer um bem quando não devemos, pode-se entendê-lo em dois
sentidos. Ou a circunstância se refere ao objeto querido, e então a vontade não quer o bem, o que se dá
se decidirmos praticar um ato quando não devemos; ou se refere ao ato de querer, e então é impossível
queiramos um bem quando não devemos, porque devemos querer sempre o bem e só por acidente é
que, querendo um determinado bem, ficamos impedidos de querer o bem devido; mas então o mal não
provêm de querermos esse determinado bem, mas de não querermos o outro. E o mesmo se deve dizer
das outras circunstâncias.

RESPOSTA À TERCEIRA. ― A ignorância das circunstâncias excusa a malícia da vontade, quando se
referem ao objeto querido, fazendo com que ignoremos as circunstâncias do ato que queremos.

## Art. 3 — Se a bondade da vontade depende da razão.
O terceiro discute-se assim. ― Parece que a bondade da vontade não depende da razão.

1. ― Pois, o anterior não depende do posterior. Ora, o bem pertence, antes, à vontade que à razão,
como do sobredito resulta. Logo, o bem da vontade não depende da razão.

2. Demais. ― Como diz o Filósofo, a bondade do intelecto prático é a verdade conforme ao apetite reto.
Ora, este é a vontade boa. Logo, a bondade da razão prática depende, mais, daquela da vontade, do que
inversamente.

3. Demais. ― O motor não depende do que é movido, mas inversamente. Ora, a vontade move a razão e
as demais faculdades, como se disse. Logo, a bondade da vontade não depende da razão.
Mas, em contrário, diz Hilário: É imoderada toda pertinácia do querer, quando a vontade não está
sujeita a razão. Ora, a bondade da vontade consiste em não ser imoderada. Logo, depende da razão.

SOLUÇÃO. ― Como já se disse, a bondade da vontade depende propriamente, do objeto, e este lhe é
proposto pela razão; pois, o bem conhecido pelo intelecto é o objeto proporcionado à vontade, ao passo
que não lhe é proporcionado a ela, mas ao apetite sensitivo, o bem sensível ou imaginário. Pois,
enquanto que a vontade pode tender ao bem universal apreendido pela razão, o apetite sensitivo não
tende senão para um bem particular, apreendido pela potência sensitiva. Logo, a bondade da vontade
depende da razão, do mesmo modo por que depende do objeto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O bem sob o aspecto de bem, i. é, de desejável, é objeto
antes da vontade que da razão. Porém o é da razão, sob o aspecto de verdadeiro, antes de o ser da
vontade sob o de desejável; porque o apetite da vontade não pode tender para o bem se este não for
apreendido primeiro pela razão.

RESPOSTA À SEGUNDA. ― No passo aduzido, o Filósofo se refere ao intelecto prático enquanto delibera
e raciocina sobre os meios, e é então aperfeiçoado pela prudência. Ora, no concernente aos meios, a
retitude da razão consiste na conformidade como o apetite do fim devido. Este, contudo pressupõe a
apreensão reta do fim, pela razão.

RESPOSTA À TERCEIRA. ― A vontade move de certa maneira a razão, que por sua vez e de algum modo
move a vontade para o seu objeto, como já se disse.

## Art. 4 — Se a bondade da vontade humana depende da lei eterna.
O quarto discute-se assim. ― Parece que a bondade da vontade humana não depende da lei eterna.

1. ― Pois, o que é medido só pode sê-lo por uma regra e uma medida. Ora, a regra da vontade humana,
da qual depende a sua bondade, é a razão reta. Logo, essa bondade não depende da lei eterna.

2. Demais. ― A medida deve ser homogênea com o medido, como diz Aristóteles. Ora, a lei eterna não é
homogênea com a vontade humana. Logo, não lhe pode servir de medida, a ponto de dela depender a
sua bondade.

3. Demais. ― Da medida devemos estar certíssimos. Ora, a lei eterna nos é desconhecida. Logo, não
pode ser a medida da nossa vontade, a ponto de a sua bondade dela depender.
Mas, em contrário, diz Agostinho: o pecado consiste em fazer, dizer ou desejar o que é contrário à lei
eterna. Ora, a malícia da vontade é a raiz do pecado. E como a malícia se opõe à bondade, a bondade da
vontade depende da lei eterna.

SOLUÇÃO. ― Em todas as causas ordenadas o efeito depende mais da causa primeira que da segunda,
porque esta não age senão em virtude daquela. Ora, é em virtude da lei eterna, que é a razão divina,
que a razão humana é a regra da vontade humana, pela qual se lhe mede a bondade. E por isso, diz a
Escritura (Sl 4, 6 e 7): Muitos dizem: quem nos patenteará os bens? Gravado está, Senhor, sobre nós o
lume do teu rosto, quase dizendo: a luz da razão, existente em nós, pode nos mostrar o bem e regular a
vontade, na medida em que é a luz do teu rosto, i. é, dele derivada. Por onde, é manifesto que a
vontade humana depende muito mais da lei eterna que da razão humana; de modo que, quando esta
falha, é necessário recorrer aquela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O medido não pode ter várias medidas próximas; pode
contudo tê-las várias, ordenando-se uma à outra.

RESPOSTA À SEGUNDA. ― A medida próxima deve ser homogênea com o medido, não porém a remota.

RESPOSTA À TERCEIRA. ― Embora a lei eterna nos seja desconhecida, enquanto existente na mente
divina, contudo se nos torna conhecida de algum modo, ou pela razão natural, dela derivada e imagem
própria sua, ou por alguma revelação superveniente.

## Art. 5 — Se a vontade discordante da razão errônea é má.
(II Sent., dist. XXXIX., q. 3, a . 3; De Verit., q. 17, a . 4; Quodl. III, q. 12 a . 2; VIII, q. 6, a . 3; IX, q. 7, a . 2;
Rom., cap XIV, lect. II; Galat., cap. V, lect. I).
O quinto discute-se assim. ― Parece que a vontade discordante da razão errônea não é má.

1. ― Pois, a razão, enquanto derivada da lei eterna, é a regra da vontade humana, como se disse. Ora,
dessa lei não deriva a razão errônea, que portanto não pode ser regra da vontade humana. Logo, não é
má a vontade discordante da razão errônea.

2. Demais. ― Segundo Agostinho, a ordem de uma autoridade inferior não obriga quando contrária à da
autoridade superior; assim, se um procônsul mandar o que o imperador proíbe. Ora, a razão errônea às
vezes, propõe coisas contrárias à ordem do superior, que é Deus, cuja autoridade é suma. Logo, o
ditame da razão errônea não obriga, e portanto não é má à vontade que discorda dessa razão.

3. Demais. ― Toda vontade é má que é culpada de alguma espécie de malícia. Ora, a vontade
discordante da razão errônea não pode ser culpada de nenhuma espécie de malícia; p. ex., se a razão
erra dizendo que se deve fornicar, à vontade que não quer fazê-lo não pode ser culpada de nenhuma
espécie de malícia. Logo, a vontade discordante da razão errônea não é má.
Mas, em contrário. ― Como já ficou dito na primeira parte, a consciência não é senão a aplicação da
ciência a um ato particular, e reside na razão. Logo, a vontade discordante da razão errônea é contrária
à consciência. Ora, toda vontade tal é má, pois diz a Escritura (Rm 14, 23): E tudo o que não é segundo a
fé é pecado, i. é, tudo o que é contrário à consciência. Logo, a vontade discordante da razão errônea é
má.

SOLUÇÃO. ― Sendo a consciência de certo modo um ditame da razão, pois é uma aplicação da ciência
aos atos, como já se disse na primeira parte, indagar se a vontade discordante da razão errônea é má é
o mesmo que indagar se a consciência errônea obriga. E a este propósito certos distinguiram três
gêneros de atos: os genericamente bons, os indiferentes e os genericamente maus. E ensinam que não
há erro se a razão ou a consciência decidir a prática de um ato genericamente bom ou genericamente
mau, pois a mesma razão que ordena o bem proíbe o mal. Porém será errônea a razão ou a consciência
se determinar, que devamos praticar, em virtude de um preceito, uma ação má em si mesma ou proibir
a prática de um ato em si mesmo bom. E semelhantemente, será errônea a razão ou a consciência se
dispuser que um ato em si mesmo indiferente, como levantar uma palha do chão, é proibido ou
ordenado. Doutrinam pois que a razão ou a consciência errônea em relação aos atos indiferentes, quer
ordenando-os ou proibindo-os, obriga, de modo que a vontade discordante de tal razão errônea é má e
comete pecado. Porém a razão ou a consciência errônea ordenando o mal em si, ou proibindo o que em
si é bom e necessário à salvação, não obriga; e em tais casos a vontade discordante da razão ou da
consciência errônea não obriga.
Mas esta doutrina é irracional. Pois, quanto aos atos indiferentes, a vontade discordante da razão ou da
consciência errônea é má, de certo modo, pelo seu objeto, do qual depende a bondade ou malícia da
vontade; não o é porém pelo objeto considerado em a sua natureza, senão só porque é apreendido
acidentalmente pela razão como bom ou mau, como um bem a ser feito ou um mal a ser evitado. E
como o objeto da vontade lhe é proposto pela razão, segundo já se disse, desde que um objeto lhe é
proposto por ela como sendo mau, à vontade que o aceita, aceita o mal. Ora, tal se dá, não só com os
atos indiferentes, mas também com os bons ou maus. Pois, não só um ato indiferente pode ser tomado
acidentalmente como bom ou mau, mas ainda o bem pode assumir o aspecto do mal, ou o mal, o do
bem, em virtude da apreensão da razão. P. ex., abster-se de fornicar é um bem, mas só é abraçado pela
vontade na medida em que a razão lho propõe; se pois for proposto pela razão errônea como mal, à
vontade o quer sob o aspecto de mal. Por onde, a vontade será má porque quer o mal, não em si, mas
acidental, em virtude da apreensão da razão. Semelhantemente, crer em Cristo é em si bom e
necessário à salvação; mas esse bem a vontade não o quer senão enquanto proposto pela razão. Por
onde, ser for pela razão proposto como um mal; é como tal que à vontade o quer; não seja, em si, mal,
senão só acidentalmente, pela apreensão da razão. E por isso o Filósofo diz: propriamente falando, é
incontinente quem não obedece à razão reta; acidentalmente, quem não obedece à razão falsa.
Por onde, devemos concluir que toda vontade discordante da razão, reta ou errônea, é sempre má.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O juízo da razão errônea, embora não derive de Deus,
contudo desde que essa razão o propõe como verdadeiro, ele há de conseqüentemente derivar de Deus
de quem procede toda verdade.

RESPOSTA À SEGUNDA. ― O dito de Agostinho se refere ao caso de sabermos que a autoridade inferior
manda algo de contrário à ordem do superior. Mas quem, tomando a ordem do procônsul pela do
imperador, a desprezasse, desprezaria a deste último. E semelhantemente, quem soubesse que a razão
humana dita algo de contrário à ordem de Deus não estaria obrigado a segui-la; mas então, a razão não
seria totalmente errônea. Se porém, a razão errônea propuser algo como sendo preceito de Deus, então
desprezar-lhe o ditame será desprezar a ordem de Deus.

RESPOSTA À TERCEIRA. ― A razão, quando apreende o mal, sempre o apreende sob alguma noção de
bem, p. ex., porque contraria a uma ordem divina, ou porque é escândalo ou por coisa semelhante. E
então, a malícia da vontade se reduz a uma dessas espécies de malícia.

## Art. 6 — Se a vontade concorde com a razão errônea é boa.
(De Verit., q. 17, a . 3, ad 4; Quodl.III, q. 12, a . 2; VIII, 1. 6, a . 3, 5; IX, q. 7, a . 2).
O sexto discute-se assim. ― Parece que a vontade concorde com a razão errônea é boa.

1. ― Pois, assim como a vontade discordante da razão busca o que esta considera mau, assim a
concorde busca o que a razão considera bom. Ora, a vontade que discorda da razão, ainda má, é má.
Logo, a concorde com a razão, ainda errônea, é boa.

2. Demais. ― A vontade concorde com o preceito de Deus e com a lei eterna é sempre boa. Ora, esta e
aquela são-nos propostos pela apreensão da razão, ainda errônea. Logo, a vontade que com esta
concorda é boa.

3. Demais. ― A vontade discordante da razão errônea é má. Por onde, se a que concorda também o
fosse, toda vontade de quem segue a razão errônea seria má, e o deixaria perplexo, levando-o ao
pecado necessariamente, o que é inadmissível. Logo, a vontade concorde com a razão errônea é boa.
Mas, em contrário. ― A vontade dos que mataram os Apóstolos era má, e todavia, concordava com a
razão errônea deles, conforme a Escritura (Jô 16, 2): Está a chegar o tempo em que todo o que vos
matar julgará que nisso faz serviço a Deus. Logo, a vontade concorde com a razão errônea pode ser má.

SOLUÇÃO. ― Assim como a questão anterior se identifica com a de saber se a consciência errônea
obriga, assim esta é o mesmo que indagar se tal consciência excusa. Ora, esta questão depende do que
já dissemos, a saber que a ignorância, ora causa o involuntário e ora, não. E como o bem e o mal moral
dependem do ato voluntário, conforme do sobredito resulta, é claro que a ignorância, causa do
involuntário, elimina a razão de bem e de mal moral; não porém a que não o causa. Pois, como já se
disse, a ignorância de certo modo querida, direta ou indiretamente, não causa o involuntário. Refiro-me
à ignorância diretamente voluntária, objeto de um ato da vontade, e à indiretamente voluntária, que se
origina da negligência, em virtude da qual alguém não quer saber aquilo que deve, segundo já foi dito.
Se, pois, a razão ou a consciência errar voluntariamente, de modo direto, ou por negligência, não
sabendo o que deveria saber, esse erro não impedirá que a vontade concorde com a razão ou a
consciência assim errônea seja má. Se porém for um erro que cause o involuntário, proveniente da
ignorância de alguma circunstância não filha da negligência, tal erro impede a vontade, com ele
concorde, de ser má. P. ex., se a razão errônea disser que um homem deve ter relações com a esposa de
outro, a vontade que concordar com essa razão errônea será má, porque o erro provém da ignorância
da lei de Deus, que ele deveria conhecer. Se porém a sua razão errar, fazendo-o acreditar que vai ter
relações com a sua legítima esposa, que lhe pede o débito conjugal, tal erro isenta a vontade do mal,
porque provém da ignorância de uma circunstância que excusa, causando o involuntário.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como diz Dionísio, o bem procede da causa integra e o
mal, de qualquer defeito. Por onde, para ser considerado mau o objeto da vontade, basta que o seja por
natureza ou por ser apreendido como tal. Para ser bom, porém, há-de sê-lo de ambos os modos.

RESPOSTA À SEGUNDA. ― A lei eterna não pode errar, mas a razão humana o pode. Por onde, a
vontade concorde com esta nem sempre é reta, e nem sempre é concorde com a lei eterna.

RESPOSTA À TERCEIRA. ― Como num silogismo, também em moral, dado um inconveniente,
necessariamente se seguem outros. Assim, suposto que alguém busque a vanglória, por ação a que
esteja obrigado ou por omissão, sempre pecará. E nem há razão para a perplexidade, porque pode
abandonar a intenção má. E semelhantemente, suposto um erro da razão ou da consciência, procedente
de ignorância que não excuse, necessariamente há-de seguir-se o mal da vontade, sem haver lugar para
a perplexidade, porque podemos abandonar o erro, sendo a ignorância vencível e voluntária.

## Art. 7 — Se a bondade da vontade depende do fim intencional.
(II Sent., dist. XXXVIII, a . 4, 5).
O sétimo discute-se assim. ― Parece que a bondade da vontade não depende do fim intencional.

1. ― Pois, como já se disse, a bondade da vontade depende só do objeto. Ora, em relação aos meios,
um é o objeto da vontade e outro, o fim visado. Logo, em relação a eles, a bondade da vontade não
depende do fim intencional.

2. Demais. ― É próprio da vontade boa querer observar o mandamento de Deus. Ora, isso pode referir-
se a um mau fim, p. ex., a vanglória ou a cobiça, quando se quer obedecer a Deus para conseguir bens
temporais. Logo, a bondade da vontade não depende do fim intencional.

3. Demais. ― O bem e o mal, diversificando a vontade, diversificam também o fim. Ora, a malícia da
vontade não depende da malícia do fim intencional; assim quem quer furtar para dar esmola tem
vontade má, embora vise um fim bom. Logo, a bondade da vontade não depende de ser bom o fim
intencional.
Mas, em contrário, diz Agostinho que a intenção é remunerada por Deus. Ora, Deus só remunera o bem.
Logo, a bondade da vontade depende do fim intencional.

SOLUÇÃO. ― A intenção mantém dupla relação com a vontade, conforme é precedente ou
concomitante. ― Precede causalmente a intenção da vontade quando queremos uma coisa em virtude
de um fim intencional. E, em tal caso, a relação da coisa com o fim é considerada como a razão mesma
da sua bondade; assim, quem quer jejuar por amor de Deus, faz bem, porque o faz por esse amor. Por
onde, como a bondade da vontade resulta da bondade do objeto querido, conforme já se disse, ela há,
necessariamente, de depender do fim intencional. ― É conseqüente, de outro lado, a intenção da
vontade, quando sobrevém a uma vontade já preexistente; como quando queremos fazer uma coisa e
depois a referimos a Deus. E então a bondade da primeira vontade não depende da intenção seguinte, a
não ser que um novo ato de vontade venha ligar esta aquela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Quando a intenção é a causa de querermos os meios, a
relação destes com o fim torna-se a razão mesma da bondade do objeto, como já se disse.

RESPOSTA À SEGUNDA. ― A vontade não pode ser boa se a má intenção é a causa de querermos.
Assim, quem quer dar esmola por vanglória, quer o que é em si bom, mas por uma razão má; por onde,
como o querer é mau, má lhe há-de ser à vontade. Se porém a intenção for conseqüente, a vontade
podia ser boa e a intenção subseqüente lhe deprava, não o ato anterior, mas o posterior.

RESPOSTA À TERCEIRA. ― Como já dissemos, o mal provém de qualquer defeito e o bem, de causa total
e íntegra. Por onde, sempre será má a vontade, tanto querendo o mal em si, sob razão de bem, como o
bem, sob a de mal. Mas para ser boa, é preciso que queira o bem, sob razão de bem, i. é, o bem pelo
bem.

## Art. 8 — Se o grau de bondade da vontade depende do grau de bondade da intenção.
O oitavo discute-se assim. ― Parece que o grau de bondade da vontade depende do grau de bondade
da intenção.

1. ― Pois, a propósito do passo de Mateus (12, 35) ― O homem bom do bom tesouro tira boas
coisas ― diz a Glosa: Cada um faz tanto bem quanto tenciona fazer. Ora, a intenção dá a bondade não
só ao ato externo como também à vontade, segundo já se disse. Logo, o grau da vontade boa é relativo
ao da intenção.

2. Demais. ― Se a causa aumenta, o efeito também aumenta. Ora, a bondade da intenção é a causa de a
vontade ser boa. Logo, quanto mais tivermos a intenção do bem tanto mais será a vontade boa.

3. Demais. ― Em relação ao mal, a intenção é a medida do pecado; assim, quem atirar uma pedra com a
intenção do homicídio, do homicídio será réu. Logo, pela mesma razão, relativamente ao bem, a
bondade será boa na medida em que tencionamos fazer o bem.
Mas, em contrário. ― A intenção pode ser boa e a vontade, má. Logo, pela mesma razão, aquela pode
ser melhor que esta.

SOLUÇÃO. ― De dois modos podemos considerar o grau dos atos e do fim intencional. Relativamente
ao objeto, segundo queremos ou fazemos um bem maior; ou à intensidade do ato, segundo o agente
quer ou age mais intensamente. Se pois tratamos do grau do querer ou da intenção, quanto ao objeto, é
claro que o grau do ato não acompanha o da intenção; e isso pode dar-se de dois modos, relativamente
ao ato externo. Primeiro, por não ser o objeto, que se ordena ao fim intencionado, proporcionando a
este; assim, não poderia realizar a sua intenção quem, com dez libras, quisesse comprar o que vale cem.
Segundo, por causa dos impedimentos, que podem se opor à realização do ato externo, e que nós não
pudermos remover; assim, se quisermos ir a Roma e por impedidos, não o pudermos. Relativamente aos
atos interiores da vontade porém, isto não pode dar-se senão de um modo, porque, ao contrário dos
atos externos, estes dependem de nós. Mas a vontade pode querer um objeto não proporcionado, ao
fim que intenciona e então absolutamente considerada, ela não é boa no mesmo grau que a intenção.
Como porém esta, em si pertence de certo modo ao ato da vontade, do qual é a razão de ser, o grau da
sua bondade redunda para este, pois que a vontade quer, como fim, um bem grande, embora o meio
pelo qual visa consegui-lo, dele não seja digno.
Se porém considerarmos o grau da intenção e do ato, quanto à intensidade de ambos, a da primeira
redunda para o ato interior e exterior da vontade. Pois, a intenção se comporta como formalmente, em
relação a ambos, segundo do sobredito resulta claro; embora materialmente falando, a intenção possa
ter uma intensidade que não tem, no mesmo grau, o ato interior ou exterior; p. ex., quando não
queremos tomar o remédio com a mesma intensidade com que queremos a saúde. Contudo, esse
mesmo querer intensamente a saúde redunda formalmente na intensa vontade de tomar o remédio. È
preciso porém considerar que a intensidade do ato interior ou exterior pode referir-se à intenção como
objeto desta; p. ex., quando temos a intenção de querer ou fazer alguma coisa, intensamente. Mas, daí
não se segue que queiramos ou operamos intensamente, porque o grau do bem visado não é
correlativo à bondade do ato interior ou exterior, como já se disse. Por onde, não merecemos tanto
quanto temos a intenção de merecer, porque o grau do mérito consiste na intensidade do ato, como a
seguir se dirá.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A Glosa aduzida se refere ao juízo de Deus, que leva em
conta principalmente o fim intencional. E por isso, outra Glosa diz, no mesmo passo, que o tesouro do
coração é a intenção, pela qual Deus julga as obras. Pois, a bondade da intenção, como já dissemos,
redunda de certo modo na bondade da vontade, que faz o mesmo ato exterior meritório, perante Deus.

RESPOSTA À SEGUNDA. ― A bondade da intenção não é a causa total de ser a vontade boa. Por onde, a
objeção não colhe.

RESPOSTA À TERCEIRA. ― Para a malícia da vontade basta a da intenção; por isso, quanto esta é má,
tanto o é aquela. Mas como dissemos, o mesmo não se dá com a bondade.

## Art. 9 — Se a bondade da vontade humana depende da sua conformidade com a divina.
(I Sent., dist. XLVIII, a . 1; De Verit., q. 23, a . 7).
O nono discute-se assim. ― Parece que a bondade da vontade humana não depende da sua
conformidade com a divina.

1. ― Pois, é impossível a vontade humana conformar-se com a divina, segundo claramente diz a
Escritura (Is 55, 9): Porque assim como os céus se levantam sobre a terra, assim se acham levantados os
meus caminhos sobre os vossos caminhos, e os meus pensamentos sobre os vossos pensamentos. Se
portanto para a bondade da vontade fosse necessária a sua conformidade com a vontade divina,
resultaria que é impossível a vontade humana ser boa, o que é inadmissível.

2. Demais. ― Assim como a nossa vontade deriva da divina, assim da ciência divina a nossa ciência. Ora,
a nossa ciência não é necessariamente conforme com a divina, pois muitas coisas Deus sabe que nós
ignoramos. Logo, nem é necessário que a nossa vontade seja conforme com a divina.

3. Demais. ― A vontade é princípio de ação. Ora, a ação nossa não pode conformar-se com a divina.
Logo, não é necessário que a nossa vontade seja conforme com a divina.
Mas, em contrário, diz a Escritura (Mt 26, 39): Não se faça nisto a minha vontade, mas sim a tua; cujo
sentido, segundo Agostinho expõe, é que Cristo quer que o homem seja reto e dirija-se para Deus. Ora,
a retidão da vontade é a sua bondade. Logo, a bondade desta depende da sua conformidade com a
vontade divina.

SOLUÇÃO. ― Como já se disse, a bondade da vontade depende do fim intencional. Ora, o fim último da
vontade humana é o sumo bem ― Deus, segundo já dissemos. Logo e necessariamente a bondade da
vontade humana há-se de ordenar para Deus, sumo bem. Ora, este bem, em si e primeiramente,
comparado com a vontade divina, constitui-lhe o objeto próprio. E como o primeiro, em qualquer
gênero, é a medida e a razão de tudo o que a esse gênero pertence; e sendo reto e bom aquilo que
atinge a sua medida, segue-se que, para ser boa, a vontade humana há-se de conformar com a divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A vontade humana há-se de conformar com a divina,
não, se lhe equiparando, mas imitando-a. E semelhantemente, a ciência humana conforma-se com a
divina, conhecendo a verdade; e a ação humana com a divina, convindo com a natureza do homem que
age por imitação e não por equiparação.
Donde se deduzem claras as RESPOSTAS À SEGUNDA E À TERCEIRA OBJEÇÃO.

## Art. 10 — Se a vontade humana, querendo um objeto, deve conformar-se sempre com a divina.
(I Sent., dist. XLVIII, a . 2, 3, 4; De Verit., q. 23, a . 8).
O décimo discute-se assim. ― Parece que a vontade humana, querendo um objeto, não deve sempre
conformar-se com a divina.

1. ― Pois, não podemos querer o que ignoramos, porque o bem apreendido é o objeto da vontade. Ora,
na mor parte das vezes, ignoramos o que Deus quer. Logo, a vontade humana não pode conformar-se
com a divina, querendo um objeto.

2. Demais. ― Deus quer danar quem ele de ante-mão sabe que morrerá em pecado mortal. Se pois,
o homem querendo um objeto, tivesse que conformar a sua vontade com a divina, teria de querer a
própria danação, o que é inadmissível.

3. Demais. ― Ninguém é obrigado a querer nada contrário à piedade. Ora, às vezes, tal se daria se o
homem quisesse o que Deus quer; assim iria contra a piedade um filho que quisesse a morte do pai,
querida por Deus. Logo, o homem, querendo um objeto, não está obrigado a conformar a sua com a
vontade de Deus.

1. Mas, em contrário, sobre aquilo do salmo (Sl 32, 1) ― aos retos convém que o louvem ― diz a
Glosa: Tem o coração reto quem quer o que Deus quer. Ora, todos estão obrigados a ter o coração reto.
Logo, a querer o que Deus quer.

2. Demais. ― A forma da vontade, como de qualquer ato, provém do objeto. Se pois o homem deve
conformar a sua vontade com a divina, isso há-de ser em relação ao objeto querido.

3. Demais. ― A discordância das vontades consiste em os homens quererem coisas diversas. Ora, quem
tiver vontade oposta à divina a tem má. Logo, tem má vontade quem, querendo um objeto, não a
conforma com a divina.

SOLUÇÃO. ― Como do sobredito resulta a vontade move-se para o objeto que lhe for proposto pela
razão. Ora, acontece que esta aprecia um objeto diversamente, de modo que uma coisa boa, a uma luz
não o é a outra. Por onde, a vontade de quem quer o que lhe parece bom, é boa; e também será boa a
de quem não quer esse mesmo objeto por lhe parecer mau. Assim, o juiz tem vontade boa querendo a
morte de um ladrão, que lhe parece justa; mas a vontade de outrem, p. ex., da esposa ou do filho, será
também boa, não querendo a morte do mesmo, por ser má, por natureza.
Seguindo, pois, a vontade a apreensão da razão ou do intelecto, quanto mais geral for a noção do bem
apreendido, tanto mais geral será o bem para o qual a vontade é movida, como se vê pelo exemplo
aduzido. Pois o juiz, curando do bem comum, que é a justiça, quer a morte do ladrão, que lhe parece
boa em relação ao estado comum; a esposa, porém, considerando o bem privado da família, quer que o
seu marido, embora ladrão, não seja morto.
Ora, o bem de todo o universo é o que é apreendido por Deus, criador e governador do mesmo; e por
isso, quer tudo de um ponto de vista universal, que é a sua bondade, bem de todo o universo. Ao passo
que a apreensão da criatura, recai, por natureza, sobre algum bem particular, proporcionando à sua
natureza. Ora, pode acontecer que uma coisa boa, num ponto de vista particular, não o seja, no ponto
de vista universal, ou inversamente, como já se disse. E por isso pode se dar que uma vontade seja boa,
quando quer, particularmente considerada, uma coisa que contudo, universalmente considerada, Deus
não quer; e inversamente. Donde vem que vontades diversas de homens diversos, querendo coisas
opostas, podem ser boas, querendo-as por diversas razões particulares.
Não é porém reta a vontade do homem que quer um bem particular, quando não o referir ao bem
comum, como fim; pois também o apetite natural de qualquer das partes deve se ordenar ao bem
comum do todo. Ora, do fim provém a como que razão formal de querer o que a ele se lhe ordena. Por
onde, quem quiser um bem particular com vontade reta há-de querê-lo materialmente; ao passo que
há-de querer o bem comum divino, formalmente. Logo, a vontade humana querendo um objeto, tem de
se conformar com a divina, formalmente, pois, tem de querer o bem divino e comum; não porém
materialmente, pela razão já dita. Porém, num e noutro sentido, a vontade humana se conforma, de
certo modo, com a divina, porque, conformando-se com ela pela razão comum do objeto querido,
conforma-se pelo fim último; e não se conformando, em relação ao objeto querido materialmente,
conforma-se na ordem da causa eficiente, porque a inclinação mesma conseqüente à natureza ou à
apreensão particular de determinado objeto, todos os seres a receberem de Deus, causa eficiente. E por
isso costuma-se dizer que, neste ponto, a vontade humana conforma-se com a divina, porque quer
aquilo que Deus quer que ela queira.
Mas há outro modo de conformidade, no ponto de vista da causa formal, quando o homem quer uma
coisa pela caridade, como Deus quer. E esta conformidade também se reduz à formal, que se funda na
ordem ao último fim, objeto próprio da caridade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Segundo a razão comum de querer, podemos conhecer
o objeto querido por Deus, pois sabemos que ele só quer o bem. Logo, quem quer uma coisa, sob
qualquer razão de bem, tem a sua vontade conforme com a divina, quanto a essa razão. Mas em casos
particulares, não sabemos o que Deus quer, e então não estamos obrigados a conformar a nossa
vontade com a divina. No estado da glória porém todos veremos em particular a relação de tudo o que
quisermos com a vontade de Deus, a esse respeito; e portanto teremos a vontade conforme com a de
Deus, não só formal, mas também materialmente e em tudo.

RESPOSTA À SEGUNDA. ― Deus não quer a danação como tal, nem a morte, em si mesma, de
ninguém, pois, quer que todos os homens se salvem (1 Tm 2, 4); mas o quer em nome da justiça. E por
isso basta neste ponto que o homem queira que seja garantida a justiça de Deus e a ordem da natureza.
Donde se deduz clara a RESPOSTA À TERCEIRA.

RESPOSTA À PRIMEIRA OBJEÇÃO EM CONTRÁRIO. ― Quem conforma a sua vontade com a divina,
quanto à razão mesma de querer, quer mais o que Deus quer do que quem a conforma quanto à coisa
querida; porque a vontade move-se principalmente mais para o fim que para os meios.

RESPOSTA À SEGUNDA. ― A espécie e a forma de um ato funda-se mais na razão formal do objeto do
que naquilo que nele existe materialmente.

RESPOSTA À TERCEIRA. ― Não há oposição de vontades quando pessoas diversas querem coisas
diversas, não pela mesma razão. Mas haveria se pela mesma razão o que é querido de um não o fosse
de outro. Ora, tal não está em questão.