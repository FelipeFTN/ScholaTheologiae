# Questão 88: Do pecado venial e do mortal.
Em seguida, por se distinguirem entre si, quanto ao reato, o pecado venial e o mortal, devemos tratar
deles. E, primeiro, devemos tratar do pecado venial, por comparação com o mortal. Segundo, do venial,
em si mesmo.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se o pecado venial se opõe convenientemente ao mortal.
(Supra, q. 72, a. 5; II Sent., dist. XLII, q. 1, a. 3; III Cont. Gent., cap. CXXXIX; De Malo, q. 7, a. 1).
O primeiro discute-se assim. — Parece que o pecado venial não se opõe convenientemente ao mortal.

1. — Pois, como diz Agostinho, pecado é o dito, feito ou desejado contra a lei eterna. Ora, o ser contra a
lei eterna constitui o pecado mortal. Logo, todo pecado é mortal e a este não se opõe o venial.

2. Demais. — O Apóstolo diz (1 Cor 10, 31): Logo ou vós comais ou bebais, ou façais qualquer outra
coisa, fazei tudo para a glória de Deus. Ora, contra este preceito age quem peca, pois não se comete
pecado pela glória de Deus. E sendo pecado mortal agir contra o preceito, resulta que quem peca
mortalmente o faz.

3. Demais. — Quem se apega com amor a algum bem, apegasse-lhe para dele fruir ou usar, segundo
está claro em Agostinho. Ora, nenhum pecador se apega a um bem mutável para dele usar; pois, não o
refere ao bem capaz de nos fazer felizes; e isso é propriamente usar, segundo Agostinho, no lugar
aduzido. Logo, quem peca frui o bem mutável. Ora, a perversidade humana consiste em fruir as coisas
que se devem usar, conforme Agostinho. E sendo a perversidade considerada pecado mortal, por
conseqüência quem peca, mortalmente peca.

4. Demais. — Quem se apega a um termo, se afasta, por isso mesmo, de outro. Ora, quem peca se
apega a um bem mutável. Logo, se afasta do bem imutável, e portanto peca mortalmente. Por onde, o
pecado venial não se opõe convenientemente ao mortal.
Mas, em contrário, diz Agostinho: crime é o que merece condenação; pecado venial é, ao contrário, o
que não a merece. Ora, crime é denominação do pecado mortal. Logo, o pecado venial se opõe
convenientemente ao mortal.

SOLUÇÃO. — Certas idéias não se opõem em sentido próprio, mas apenas metaforicamente
consideradas. Assim, ser ridente não se opõe a ser árido; mas há oposição entre essas idéias quando rir
se diz metaforicamente de um prado, pelo seu aspecto florido e viridente. Do mesmo modo, mortal,
tomado em sentido próprio, enquanto relativo à morte do corpo, não se opõe à venial, nem pertence ao
mesmo gênero. Mas, tomado em sentido metafórico, aplicado aos pecados, mortal opõe-se a venial.
Pois, sendo o pecado uma enfermidade da alma, como estabelecemos (q. 71, a. 1 ad 3; q. 72, a. 5; q. 74,
a. 9 ad 2), a sua denominação de mortal é por semelhança com a doença, assim chamada por implicar
uma perda irreparável, pela privação de algum princípio, como já dissemos (q. 72, a. 5). Ora, o princípio
da vida espiritual, concernente à virtude, é a ordem para o fim último, como se disse (q. 72, a. 5; q. 87,
a. 3). E esta, destruída, não pode se separada por nenhum princípio intrínseco, mas só pelo poder
divino, conforme estabelecemos (q. 87, a. 3). Pois as desordens relativas aos meios reparam-se pelo fim;
assim como o erro relativo às conclusões, pela verdade dos princípios. Por onde, a privação da ordem,
relativa ao último fim, não pode ser reparada por nada de superior a ele, assim como não o pode o erro
relativo aos princípios. Por isso, os pecados em questão chamam-se mortais por serem como
irreparáveis. Ao contrário, os pecados, desordenados relativamente aos meios, conservada à ordem
para o último fim, são reparáveis. E esses se chamam veniais. Pois o pecado é susceptível de vênia
quando desaparece o reato da pena, que cessa com o cessar do pecado, segundo dissemos (q. 87, a. 6).
Portanto, mortal se opõe a venial como o reparável ao irreparável. E isto, digo, por um princípio interno;
não por comparação com o poder divino, que pode curar qualquer doença, tanto corporal como
espiritual. E por isso o pecado venial se opõe, convenientemente ao mortal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A divisão do pecado em venial e mortal não é a divisão
de um gênero em espécies, que de certo modo participam igualmente da essência genérica; mas de um
análogo em partes de que ele se predica por anterioridade e posterioridade. E portanto, a noção
perfeita do pecado, dada por Agostinho, convém ao pecado mortal. O pecado venial, porém é
considerado pecado em acepção imperfeita e em ordem ao pecado mortal; assim como o acidente é
considerado ser em acepção imperfeita, e relativamente à substância. Pois, o pecado venial não é
contrário à lei; porque, quem peca venialmente não faz o proibido por lei, nem omite o a que a lei
obriga preceptivamente; mas age fora da lei, por não observar o modo racional intencionado pela lei.

RESPOSTA À SEGUNDA. — O preceito citado do Apóstolo, sendo afirmativo, não obriga para sempre.
Portanto, não age contra este preceito quem não refere atualmente à glória de Deus tudo quando faz.
Pois basta referir-se a si mesmo e tudo o que tem, habitualmente, a Deus, para nem sempre pecar
mortalmente, não referindo atualmente algum ato à glória de Deus. Ora, o pecado venial não exclui a
ordem habitual dos atos humanos para a glória de Deus, senão só a atual; por não excluir a caridade,
que ordena habitualmente para Deus. Donde se conclui o pecar venialmente quem peca mortalmente.

RESPOSTA À TERCEIRA. — Quem peca venialmente apega-se ao bem temporal, não como o fruindo,
porque não o constitui último fim; mas, como dele usando e o referindo a Deus, não atual, mas
habitualmente.

RESPOSTA À QUARTA. — O bem mutável não é considerado como termo contraposto ao imutável,
senão quando é tomado como fim. Pois, o meio não tem a essência de termo.

## Art. 2 — Se o pecado venial difere, em gênero, do mortal, de modo que tanto o mortal como o venial o sejam genericamente.
(II Sent., dist. XLII, q. 1, a. 4; De Malo, q. 7, a. 1; q. 10, a. 2).
O segundo discute-se assim. — Parece que o pecado venial não difere, em gênero do mortal, de modo
que tanto o mortal como o venial o sejam genericamente.

1. — Pois, o bem e o mal, genericamente considerados, dos atos humanos, dependem da matéria ou do
objeto, como se disse (q. 18, a. 2). Ora, em relação a qualquer objeto ou matéria é possível pecar mortal
e venialmente. Pois, o homem pode amar qualquer bem mutável, menos que Deus, e isso é pecar
venialmente; ou mais que Deus, o que é pecar mortalmente. Logo, o pecado venial não difere do mortal
genericamente.

2. Demais. — Como já se disse (a. 1; q. 72, a. 5; q. 87, a. 3), é considerado mortal o pecado irreparável e
venial, o reparável. Ora, ser irreparável é próprio do pecado por malícia, considerado por certos, irre-
missível; ao contrário, ser reparável é próprio do pecado por fraqueza ou ignorância, considerado
remissível. Logo, o pecado mortal difere do venial como o cometido por malícia, do cometido por
fraqueza e ignorância. Ora, por aí os pecados não diferem entre si genérica, mas só causalmente, como
se disse (q. 77, a. 8 ad 1). Logo, o pecado venial não difere do mortal genericamente.

3. Demais. — Como já se estabeleceu (q. 74, a. 3 ad 3; q. 10), as moções súbitas, tanto da sensualidade
como da razão, são pecados veniais. Ora, moções súbitas se encontram em qualquer gênero de pecado.
Logo, não há pecados genericamente veniais.
Mas, em contrário, Agostinho enumera certos gêneros de pecados veniais, e certos outros, de mortais.

SOLUÇÃO. — Venial é chamado o pecado merecedor de vênia. Por onde, um pecado pode ser
considerado venial, de um modo, por ter alcançado vênia. E neste sentido, diz Ambrósio, que todo
pecado, pela penitência, torna-se venial;isto é, chama-se venial por causa de um evento. — Doutro
modo, chama-se venial o que nada traz em si que impeça conseguir a vênia, quer total, quer
parcialmente. — Parcialmente, quando encerra algum elemento diminutivo da culpa, como quando o
pecado é cometido por fraqueza ou ignorância. E se chama então venial na sua causa. — Totalmente,
por não destruir a ordem para o último fim; por isso não merece a pena eterna, mas a temporal. Ora, é
do pecado venial neste sentido que agora tratamos.
Nos dois primeiros sentidos o pecado venial não pertence a nenhum gênero determinado. Pode sê-lo,
porém, no terceiro sentido, sendo então considerado o pecado venial ou mortal genericamente,
conforme é o gênero ou a espécie do ato determinado pelo objeto. Assim, quando a vontade é levada a
algum ato em si repugnante à caridade, pela qual o homem se ordena para o último fim, há pecado
mortal pelo seu objeto. E é mortal genericamente, quer seja contra o amor de Deus, como a blasfêmia,
o perjúrio e outros; quer seja contra o amor do próximo, como o homicídio, o adultério e semelhantes.
Tais pecados são pois mortais genericamente. Outras vezes porém a vontade do pecador é levada ao
que, embora implicando uma certa desordem, não contraria o amor de Deus nem o do próximo; tal a
palavra ociosa, o riso supérfluo e outros pecados genericamente veniais.
Mas, como os atos morais são bons e maus, não só pelo objeto, mas também por uma disposição do
agente, como estabelecemos (q. 18, a. 4, a. 6), pode um pecado genericamente venial, em razão do seu
objeto, vir a ser mortal por parte do agente, quer por este tê-lo erigido em fim último, quer por tê-lo
ordenado a um pecado genericamente mortal. Talo caso de quem aplicasse uma palavra vã à comissão
do adultério. Semelhantemente, também por parte do agente um pecado genericamente mortal pode
vir a ser venial, por ser o ato imperfeito, i. é, não racionalmente deliberado, o que é o princípio próprio
do mau ato, como dissemos, ao tratar dos movimentos súbitos de infidelidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quem escolhe o repugnante à divina caridade
manifesta, por isso mesmo que o prefere a essa caridade, e por conseguinte, que ama tal objeto mais
que Deus. Portanto, certos pecados genéricos em si mesmos repugnantes à caridade, supõem o amor de
um objeto, de preferência a Deus.E assim são genericamente mortais.

RESPOSTA À SEGUNDA. — A objeção procede quanto ao pecado venial na sua causa.

RESPOSTA À TERCEIRA. — A objeção procede no concernente ao pecado venial pela imperfeição do ato.

## Art. 3 — Se o pecado venial é uma disposição para o mortal.
(IIª-IIªª, q. 24, a. 10; q. 186, a. 9, ad 1; I Sent., dist. XVII, q. 2, a. 5; II, dist. XXIV, q. 3, a. 6; De Malo, q. 7, a.
I, ad 7; a. 3).
O terceiro discute-se assim. — Parece que o pecado venial não é uma disposição para o mortal.

1. — Pois, um contrário não dispõe para o outro. Ora, pecado venial e mortal se opõem, como se disse
(a. 1). Logo, aquele não é disposição para este.

2. Demais. — Um ato dispõe para o que lhe é especificamente semelhante; e por isso Aristóteles diz: de
atos semelhantes procedem disposições e hábitos semelhantes. Ora, o pecado mortal e o venial diferem
genérica ou especificamente, como se disse (a. 2). Logo o venial não dispõe para o mortal.

3. Demais. — Se o pecado é chamado venial por dispor para o mortal, pecado venial será
necessariamente tudo o disponente para o mortal. Ora, todas as boas obras dispõem para o pecado
mortal; pois, diz Agostinho: a soberba arma ciladas às boas obras, para que pereçam. Logo, também as
boas obras são pecados veniais, e isso é inadmissível.
Mas, em contrário, diz a Escritura (Sr 19, 1): aquele que despreza as coisas pequenas pouco a pouco
cairá.Ora, quem peca venialmente despreza as coisas pequenas. Logo, a pouco e pouco se dispõe a cair
totalmente no pecado mortal.

SOLUÇÃO. — O disponente é de certo modo causa. Portanto, como há duas espécies de causas, há
duplo modode disposições. Há uma causa motora direta para o efeito; tal é o caso do corpo cálido, que
aquece. Outra é a causa motora indireta, removendo o obstáculo; assim, dizemos que a remoção de
uma coluna implica na remoção da pedra a ela sobreposta. E neste sentido o ato do pecado dispõe
duplamente. — De um modo, diretamente, para um ato especificamente semelhante. E então,
primariamente e por si mesmo, o pecado venial pode dispor, por uma certa conseqüência, ao pecado
mortal por parte do agente. Pois, aumentada a disposição ou o hábito, pelos atos dos pecados veniais, o
atrativo do pecado pode crescer tanto, de modo a o pecador erigir o pecado venial em fim próprio. Pois,
o fim de quem tem um hábito, como tal, é agir de acordo com esse hábito. Por onde, pecando muitas
vezes venialmente, dispõe-se para o pecado mortal.
De outro modo, um ato humano dispõe, removendo o obstáculo. E por aí o pecado genericamente
venial pode dispor para o genericamente mortal. Pois, quem comete o pecado genericamente venial
perturba uma certa ordem. Porque, acostumando a sua vontade, nas pequenas coisas, a se não
submeter à ordem devida, dispõe-na a também não se submeter à ordem do fim último, escolhendo o
pecado genericamente mortal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pecado venial não se opõe ao mortal, como duas
espécies de um mesmo gênero, segundo dissemos (a. 1 ad 1); mas como o acidente se opõe à subs-
tância. Por onde, assim como o acidente pode ser uma disposição para a forma substancial, assim
também o pecado venial, para o mortal.

RESPOSTA À SEGUNDA. — O pecado venial não é especificamente semelhante ao mortal;
genericamente porém o é, por implicar um e outro a falta da ordem devida, embora de maneiras
diferentes, como dissemos (a. 1, a. 2).

RESPOSTA À TERCEIRA. — Uma boa obra não é em si mesma disposição para o pecado mortal; pode
porém acidentalmente ser matéria ou ocasião dele. Ao contrário, em si mesmo o pecado venial dispõe
para o mortal, como dissemos.

## Art. 4 — Se o pecado venial pode vir a ser mortal.
(a. 2, 6: II Sent., dist. XXIV, q. 3, a. 6; dist. XLII, q. 1, a. 4; De Malo, q. 7, a. 3).
O quarto discute-se assim. — Parece que o pecado venial pode vir a ser mortal.

1. — Pois, diz Agostinho, expondo aquilo da Escritura (Jo 3, 36), o que não crê no Filho não verá a
vida: os pecados pequenos, i. é, veniais, se forem consentidos, matam. Ora, o pecado mortal assim se
chama precisamente por matar a alma, espiritualmente. Logo, o pecado venial pode vir a ser mortal.

2. Demais. — O movimento da sensualidade, anterior ao consentimento da razão, é pecado venial; mas,
dado o consentimento, é mortal, como se disse (q. 74, a. 8 ad 2). Logo, o pecado venial pode vir a ser
mortal.

3. Demais. — O pecado venial e o mortal diferem como a doença curável, da incurável, segundo se disse
(a. 1). Ora, a doença curável pode vir a ser incurável. Logo, o pecado venial pode vir a ser mortal.

4. Demais. — A disposição pode vir a ser um hábito. Ora, o pecado venial é uma disposição para o
mortal, como se disse (a. 3). Logo, o pecado venial pode vir a ser mortal.
Mas, em contrário. — Coisas entre si infinitamente diferentes não se transformam umas nas outras. Ora,
o pecado mortal difere infinitamente do venial, como do sobredito resulta. Logo, o venial não pode vir a
ser mortal.

SOLUÇÃO. — De três modos é possível entender-se que o pecado venial pode vir a ser mortal. — De um
modo, quando um mesmo ato, numericamente, primeiro, pecado venial venha depois, a ser mortal; e
tal é impossível. Porque o pecado, como todo ato moral, consiste principalmente num ato da vontade.
Por onde, não é considerado moral um ato quando a vontade mudou, embora uma ação seja por
natureza continuada. Ora, se a vontade não mudar, não pode o venial vir a ser mortal. — De outro
modo pode-se entender que o genericamente venial venha a ser mortal. E isto é certo possível, quando
o pecado venial é erigido em fim, ou, quando referido a um pecado mortal como ao fim, conforme se
disse (a. 2). — De terceiro modo pode-se entender que muitos pecados veniais venham a constituir um
mortal. E tal é falso se isto significar, que de muitos pecados veniais se constitua integralmente um mor-
tal. Pois, nem todos os pecados veniais do mundo podem implicar tão grande reato como o de um
pecado mortal. O que resulta claro da duração; pois, o pecado mortal implica o reato da pena eterna; e
o venial o da pena temporal, como se disse (q. 87, a. 3, a. 5). E isto também se conclui com clareza
refletindo sobre a pena do dano; pois, o pecado mortal merece a privação da visão divina, a que
nenhuma outra pena pode comparar-se, como diz Crisóstomo. E o mesmo se conclui ainda,
considerando a pena do sentido, quanto ao verme da consciência; embora talvez, quanto à pena do
fogo, as penas não sejam desproporcionadas. Se porém se entender, que muitos pecados veniais
constituam dispositivamente um mortal, então é verdade, como já demonstramos (a. 3), quanto aos
dois modos da disposição por que o pecado venial dispõe para o mortal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho fala no sentido em que muitos pecados
veniais causam dispositivamente o mortal.

RESPOSTA À SEGUNDA. — O movimento mesmo da sensualidade, precedente ao consentimento da
razão, nunca vem a ser pecado mortal; mas sim o ato, em si da razão consenciente.

RESPOSTA À TERCEIRA. — A doença corporal não é um ato, mas uma disposição permanente; e
portanto, pode mudar-se, permanecendo a mesma. Ao passo que o pecado venial é um ato transitivo,
impossível de repetir-se. Por onde, não há no caso símile.

RESPOSTA À QUARTA. — A disposição tornada habitual é como o que, numa mesma espécie, é
imperfeito; assim, a ciência imperfeita tornar-se hábito, quando aperfeiçoada. Ao passo que o pecado
venial é uma disposição de outro gênero, como o acidente relativamente à substância, na qual ele nunca
pode transformar-se.

## Art. 5 — Se a circunstância pode tornar mortal o pecado venial.
(IV Sent., dist. XVI, q. 3, a. 2, qª 4; De Malo, q. 2, a. 8; q. 7, a. 4).
O quinto procede-se assim. — Parece que a circunstância pode tornar mortal o pecado venial.

1. — Pois, diz Agostinho, que a iracúndia prolongada e a embriaguez freqüente passam para o número
dos pecados mortais. Ora, a ira e a embriaguez não são genericamente pecados mortais, mas veniais; do
contrário, sempre seriam mortais. Logo, a circunstância pode tornar mortal o pecado venial.

2. Demais. — O Mestre das Sentenças diz, que se a deleitação for morosa, o pecado é mortal; Se porém
não o for, é venial. Ora, a morosidade é uma circunstância. Logo, a circunstância pode tornar mortal o
pecado venial.

3. Demais. — Mais difere o mal, do bem, que o pecado venial do mortal, males genericamente. Ora, a
circunstância pode tornar mal um ato bom, como quando se dá esmola por vanglória. Logo, com maior
razão, podem tornar mortal o pecado venial.
Mas, em contrário, sendo a circunstância um acidente, a ela não quantitativamente pode exceder a
quantidade genérica do ato; pois, sempre o sujeito tem preeminência sobre o acidente. Se portanto o
ato for genericamente pecado venial, a circunstância não poderá torná-lo mortal; pois, o pecado mortal
excede de certo modo infinitamente a quantidade do venial, como do sobredito resulta (q. 72, a. 5 ad 1;
q. 87, a. 5 ad 1).

SOLUÇÃO. — Como dissemos (q. 7, a. 1; q. 18, a. 5 ad 4, a. 10, a. 11), quando tratamos delas, as
circunstâncias são, como tais, acidentes do ato moral. Mas podem também ser consideradas diferença
específica desse ato; e então deixam de ser circunstâncias e constituem uma espécie do ato moral. E isto
se dá quando a circunstância acrescenta ao pecado uma deformidade de outro gênero. Assim, o ato de
quem coabita com mulher que não a sua, assume a deformidade oposta à castidade; mas se essa for
além disso esposa de outrem, acrescenta-lhe a deformidade oposta à justiça, com a qual colide quem
usurpa as coisas alheias. Por isso, tal circunstância constitui nova espécie de pecado, chamada adultério.
Mas é impossível uma circunstância transformar o pecado venial, em mortal, salvo se causar uma
deformidade de outro gênero. Pois, como se disse, a deformidade do pecado venial está em causar
desordem relativa aos meios; ao passo que a do mortal é relativa ao fim último. Por onde e
manifestamente, a circunstância, como tal, não pode tornar mortal o pecado venial; senão só quando
lhe muda a espécie e se transforma, de certo modo, em diferença específica do ato moral.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A diuturnidade não é circunstância que mude a espécie
do ato; do mesmo modo, nem a repetição ou freqüência, salvo acidentalmente, por algum elemento
sobreveniente. Pois um ato não vem a ser de nova espécie por multiplicar-se ou protelar-se; salvo se
sobrevier ao ato protelado ou multiplicado algum elemento capaz de lhe variar a espécie, como a
desobediência ou o desprezo ou outro semelhante. — Devemos, pois concluir: sendo a ira um movi-
mento da alma, conducente a fazer mal ao próximo, se esse mal, intencionado pelo ato da ira for
genericamente pecado mortal — como o homicídio ou furto — tal ira é genericamente pecado mortal.
Mas o ser pecado venial lhe advém da imperfeição do ato, enquanto movimento súbito da sensualidade.
Se porém for diuturna, volta à natureza do seu gênero, pelo consentimento da razão. Mas, se o mal
intencionado pelo movimento da ira for genericamente venial, como quando uma pessoa, irada contra
outra, vai-lhe dizer alguma palavra leve e jocosa que lhe ofenda um tanto a ela, então não será pecado
mortal, embora seja prolongada. E só por acidente poderá sê-lo, se, p. ex., daí nascer um grave
escândalo ou coisa semelhante. — Quanto à embriaguez devemos admitir que pode, por essência, ser
pecado mortal. Pois, tornar-se o homem incapaz, sem necessidade, só pelo prazer do vinho, de usar da
sua razão, que o ordena para Deus e o faz evitar muitos pecados possíveis, isso contraria expressamente
à virtude. Por outro lado, o ser pecado venial advém-lhe de algum ignorância ou fraqueza. Tal é o caso
de quem ignora as virtudes do vinho, ou a debilidade própria, não pensando venha a embriagar-se. Pois
então se lhe imputa por pecado, não a embriaguez, mas só o excesso na bebida. Se porém se embriaga
freqüentemente não pode excusar-se, com essa ignorância, de que a sua vontade prefere, antes,
entregar-se se à embriaguez, que abster-se do vinho supérfluo. E portanto o pecado volta à sua
natureza.

RESPOSTA À SEGUNDA. — A deleitação morosa não é considerada pecado mortal senão quando tem
como objeto o que o constitui, genericamente, tal. E em relação a esse objeto, a deleitação não morosa
é pecado venial, isto é, pela imperfeição do ato, como dissemos, a respeito da ira. Pois, é a aprovação da
razão deliberante que torna a ira diuturna e a deleitação, morosa.

RESPOSTA À TERCEIRA. — Só quando constitui uma espécie de pecado a circunstância transforma o ato
bom em mau, como estabelecemos (q. 18, a. 5 ad 4).

## Art. 6 — Se um pecado mortal pode tornar-se venial.
(Supra, a. 2; De Malo, q. 7, a. 1, ad 18; a. 3 ad 9).
O sexto discute-se assim. — Parece que um pecado mortal pode tornar-se venial.

1. — Pois, o pecado venial dista igualmente do mortal, e reciprocamente. Ora, o pecado venial pode vir
a ser mortal, como se disse (a. 5). Logo, também o mortal pode vir a ser venial.

2. Demais. — O pecado venial e o mortal diferem assim: quem peca mortalmente ama a criatura mais
que a Deus; e quem peca venialmente a ama menos que Deus. Ora, é possível, cometendo-se um
pecado genericamente mortal, amar a criatura menos que Deus. Assim, quem fornicasse, ignorando ser
a fornicação simples pecado mortal e contrário ao amor divino; mas, de modo a estar pronto a
abandonar a fornicação por amor de Deus, se soubesse que, fornicando, vai contra esse amor. E em tal
caso pecaria venialmente, transformando-se então, o pecado mortal em venial.

3. Demais. — Como se disse (q. 5 arg. 3), o bem difere mais do mal, que o pecado venial, do mortal. Ora,
um ato em si mesmo mal pode tornar-se bom; assim, o homicídio pode tornar-se um ato de justiça
como quando um juiz mata um ladrão. Logo, com maior razão, um pecado mortal pode vir a ser venial.
Mas, em contrário, o eterno nunca pode vir a ser temporal. Ora, o pecado mortal merece pena eterna;
ao contrário, o venial, pena temporal. Logo, um pecado mortal nunca pode vir a ser venial.

SOLUÇÃO. — Venial e mortal diferem no gênero do pecado, como o perfeito, do imperfeito, segundo
dissemos (a. 1 ad 1). Ora, o imperfeito, recebendo um acréscimo, poderá vir a ser perfeito. Por onde, o
pecado venial, por se lhe acrescentar a deformidade, pertencente ao gênero do pecado mortal, torna-se
mortal. Tal o caso de quem, dizendo uma palavra ociosa, fosse levado a fornicar. O perfeito porém não
pode com nenhum acréscimo tornar-se imperfeito. Logo, um pecado mortal não pode tornar-se venial
por se lhe acrescer qualquer deformidade, pertencente ao gênero do pecado venial. Assim, o pecado de
quem fornica não se lhe diminui, por dizer uma palavra ociosa, mas, ao contrário, se agrava com essa
deformidade adjunta. — Pode, porém um pecado, genericamente mortal, ser venial por causa da
imperfeição do ato. Pois a imperfeição o faz não constituir perfeita e essencialmente um ato moral, se
não for deliberado, mas súbito, como do sobredito resulta (a. 2). O que se dá pela privação da razão
deliberada. E como um ato se especifica pela razão deliberada, tal privação modifica a espécie.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O venial difere do mortal como o imperfeito, do
perfeito; p. ex., como a criança, do homem. Pois, da criança faz-se o homem, mas não reciprocamente.
Logo, a objeção não colhe.

RESPOSTA À SEGUNDA. — Se a ignorância for tal, como a do furioso ou do louco, que escuse
absolutamente do pecado, quem cometer fornicação com essa ignorância não peca nem venial nem
mortalmente. Se porém a ignorância não for invencível, então já em si mesma é pecado, e traz consigo a
falta do amor divino, por ter o pecador descuidado de informar-se do que pudesse conservá-lo nesse
amor.

RESPOSTA À TERCEIRA. — Como diz Agostinho, o mal em si mesmo, não pode, por nenhum fim, vir a ser
bem. Assim, o homicídio, consistente em matar um inocente, de nenhum modo pode vir a ser um bem.
Mas o juiz que mata um ladrão, ou o soldado que mata um inimigo da república, não se consideram
homicidas, como diz Agostinho.