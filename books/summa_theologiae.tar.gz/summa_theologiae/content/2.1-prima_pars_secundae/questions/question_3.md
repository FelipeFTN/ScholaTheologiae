# Questão 3: Que é a beatitude.
Em seguida devemos tratar da beatitude e o que ela exige.
Sobre o primeiro ponto oito artigos se discutem:

## Art. 1 — Se a beatitude é algo de incriado.
(I. q. 26, a . 3; IV Sent., dist. XLIX, q. 1, a . 2, q ª 1).
O primeiro discute-se assim. — Parece que a beatitude é algo de incriado.

1. — Pois, como diz Boécio, é necessário confessar que Deus é a beatitude mesma.

2. Demais. — A beatitude é o mesmo bem. Ora, ser o sumo bem é próprio de Deus. Logo, como não há
vários bens sumo, resulta que a beatitude é o mesmo que Deus.

3. Demais. — A beatitude é o fim último, para o qual naturalmente tende a vontade humana. Ora, esta
não deve tender para nenhum outro fim, a não ser Deus, só do qual deve gozar, como diz Agostinho.
Logo, a beatitude é o mesmo que Deus.
Mas, em contrário. — Nada do que é feito é incriado. Ora, a beatitude do homem é algo de feito, pois,
segundo Agostinho, devemos gozar das coisas que nos fazem felizes. Logo, a beatitude não é algo de
incriado.

SOLUÇÃO. — Como já se disse o fim tem dupla acepção. Numa é a coisa mesma que desejamos
alcançar; assim, do avarento o fim é o dinheiro. Noutra, é a obtenção ou a posse ou o uso ou a função
da coisa desejada; assim, se se disser que a posse do dinheiro é o fim do avarento e gozar da coisa
voluptuosa é o fim do desregrado.
Ora, na primeira acepção, o fim último do homem é o bem incriado, i. é, Deus, que só, pela sua bondade
infinita, pode satisfazer perfeitamente à vontade do homem.
Na segunda, porém, esse último fim é algo de criado nele mesmo existente, e que não é senão a
obtenção ou o gozo do fim último.
Ora, o fim último chama-se beatitude. — Assim pois, considerada quanto à causa ou ao objeto, a
beatitude do homem é algo de incriado. — Considerada, porém, quanto à sua essência mesma, é algo
de criado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus é por essência a beatitude; pois é feliz, não pela
obtenção ou participação de qualquer outra coisa, mas pela sua essência. Ao passo que os homens são
felizes, como no mesmo passo diz Boécio, por participação, assim como são assim chamados deuses,
por participação. Ora, a participação mesma da beatitude, pela qual dizemos que o homem é feliz, é
algo de criado.

RESPOSTA À SEGUNDA. — Diz-se que a beatitude é o sumo bem do homem, porque é a obtenção ou
gozo do sumo bem.

RESPOSTA À TERCEIRA. — A beatitude é chamada o último fim no sentido em que a obtenção do fim se
chama fim.

## Art. 2 — Se a beatitude é operação.
(IV. Sent. dist. XLIX. q. 1, a 2, q a. 2; I Cont. Gent., cap. C; I Ethic., lect. X; IX Metaph., lect. VIII).
O segundo discute-se assim. — Parece que a beatitude não é operação.

1. — Pois, como diz a Escritura (Rm 6, 22), tendes o vosso fruto em santificação, e por fim a vida eterna.
Ora, a vida, sendo a existência mesma dos seres vivos, não é operação. Logo, esta não é a beatitude, o
último fim do homem.

2. Demais. — Boécio diz que a beatitude é o estado perfeito pela reunião de todos os bens. Ora, estado
não quer dizer operação. Logo, a beatitude não é operação.

3. Demais. — A beatitude, sendo a última perfeição do homem, designa algo de existente em quem é
feliz. Ora, operação não significa algo de existente no operante, mas antes, algo dele procedente. Logo,
ela não é operação.

4. Demais. — A beatitude é imanente em quem é feliz. Ora, a operação não é imanente, mas
transeunte. Logo, não e operação.

5. Demais. — Um homem é susceptível de uma só beatitude. Ora, as operações são muitas. Logo, a
beatitude não é operação.

6. Demais. — A beatitude está em quem é feliz, sem interrupção. Ora, a operação humana
freqüentemente se interrompe, p. ex., pelo sono ou por qualquer outra inibição, ou pelo repouso. Logo,
a beatitude não é operação.
Mas, em contrário, diz o Filósofo, que a felicidade é uma operação de virtude perfeita.

SOLUÇÃO. — Na medida em que a beatitude do homem é algo de criado, nele existente, necessário
admitir-se que é uma operação, pois é a sua última perfeição. Ora, o que é perfeito o é na medida em
que está em ato, porque a potência sem ato é imperfeita. Logo, é necessário que a beatitude consista
no último ato do homem. Ora, é manifesto, que a operação é o último ato do operante, sendo por isso
denominado pelo Filósofo ato segundo; pois o que tem forma pode ser operante em potência, como o
que sabe pode pensar em potência. Donde vem que todas as outras coisas também se consideram como
sendo para a sua operação, como diz Aristóteles. Logo, necessário é seja a beatitude uma operação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Vida tem dupla acepção. — Numa, significa a existência
mesma do vivente, e então a beatitude não é vida. Pois, como já ficou demonstrado, a existência de um
homem, seja ele quem for, não é a sua beatitude, porque só de Deus a beatitude é o se. — Noutra
acepção, chama-se vida à operação mesma do vivente, pela qual o princípio da vida se atualiza; assim,
falamos de vida ativa ou contemplativa ou voluptuosa. E neste sentido a vida eterna se chama último
fim, o que é claro pelo dito da Escritura (Jo 17, 3): A vida eterna porém consiste em que eles conheçam
por um só verdadeiro Deus a ti.

RESPOSTA À SEGUNDA. — Boécio, quando definiu a beatitude, considerou a noção comum mesma dela.
Pois, a noção comum da beatitude está em ser ela o bem comum perfeito, e isto exprimiu dizendo que é
o estado perfeito pela união de todos os bens, o que não significa senão que o feliz está no estado do
bem perfeito. Aristóteles, porém, exprimiu a essência mesma da beatitude, mostrando o que faz o
homem estar nesse estado, que é por uma certa operação. Por isso também mostra que a beatitude é o
bem perfeito.

RESPOSTA À TERCEIRA. — Como diz Aristóteles, dupla é a ação. Uma, procedente do operante para a
matéria exterior, como queimar e secar. E tal operação não pode ser beatitude, pois não é ação e
perfeição do agente, mas antes, do paciente, como no mesmo passo se diz. Outra é a ação imanente no
próprio agente, como sentir, inteligir e querer. E essa é a perfeição e ato do agente e pode ser a
beatitude.

RESPOSTA À QUARTA. — Beatitude, significando uma certa perfeição última, na medida em que os
diversos seres capazes de beatitude podem alcançar os diversos graus de perfeição, nessa mesma
medida necessário é dizer-se que a beatitude tem diversas acepções. — Assim, em Deus está a
beatitude essencial, porque o seu ser mesmo é a sua operação, pela qual frui, não de outrem, mas de si
mesmo. — Nos santos anjos, porém, a última perfeição relativa a alguma operação pela qual se unem
ao bem incriado, e essa operação é-lhes única e sempiterna. — Nos homens, enfim, no estado da vida
presente, a última perfeição depende da operação pela qual cada um se une a Deus. E esta não pode ser
sempiterna nem contínua, e por conseqüência nem única porque se multiplica pela intercisão. E por
isso, no estado da vida presente, a perfeita beatitude não pode ser conseguida pelo homem. Por onde, o
Filósofo, colocando a beatitude do homem nesta vida, diz que é imperfeita, concluindo, depois de
muitas reflexões: Nós os consideramos felizes como homens. Mas a beatitude perfeita nos é prometida
por Deus quando formos como os anjos no céu, na expressão da Escritura. (Mt 22, 30) — Quanto,
porém, à referida beatitude perfeita, cessa a objeção porque nesse estado de felicidade a mente do
homem está unida a Deus por operação una, contínua e sempiterna. Enquanto que, na vida presente, na
medida em que nos desviarmos da unidade e da continuidade de tal operação, nessa mesma nos
desviaremos da perfeição da beatitude. Há, contudo, alguma participação da beatitude, e tanto maior
quanto mais contínua e una puder ser a operação. Por onde, na vida ativa, ocupada por muitos
negócios, há menos da essência da beatitude, do que na contemplativa, que se ocupa com um só
objeto, que é a contemplação da verdade. E se por vezes o homem não pratica atualmente essa
operação, contudo, porque pode, sempre que quiser, praticá-la e porque a cessação mesma — p.ex., do
sono, ou de qualquer outra inibição natural — ele a ordena para ela, tal operação é considerada como
sendo contínua.
E daqui se deduzem claras as RESPOSTAS A QUINTA E À SEXTA OBJEÇÕES.

## Art. 3 — Se a beatitude consiste também na atividade dos sentidos.
(III Cont. Gent., cap. XXXIII. Compend. Theol., part. II, cap. IX; I Ethic., lect. X).
O terceiro discute-se assim. — Parece que a beatitude consiste na atividade dos sentidos.

1. — Pois, não há nenhuma atividade do homem superior à sensitiva, a não ser a intelectiva. Ora, em
nós, esta depende daquela, porque não podemos inteligir sem o fantasma, como diz Aristóteles. Logo, a
beatitude consiste também na atividade sensitiva.

2. Demais. — Boécio diz, que a beatitude é o estado perfeito pela reunião de todos os bens. Mas certos
bens são sensíveis e nós os atingimos por operação do sentido. Logo, esta é necessária para a beatitude.

3. Demais. — A beatitude é o bem perfeito, como o prova Aristóteles; o que não seria se o homem por
ela não se aperfeiçoasse relativamente a todas as suas partes. Ora, certas destas partes se aperfeiçoam
pelas operações sensitivas. Logo, são elas necessárias para a beatitude.
Mas, em contrário. — A atividade sensitiva nos é comum com os animais. Ora, comum não é a
beatitude. Logo, esta não consiste na operação sensitiva.

SOLUÇÃO. — Uma coisa pode respeitar à beatitude de três modos: essencial, antecedente e
conseqüentemente.
Essencialmente, por certo, não pode a atividade sensitiva lhe respeitar; pois, a beatitude do homem
consiste essencialmente na sua união com o bem incriado, que é o último fim, como já se demonstrou; e
a ele o homem não pode unir-se pela atividade dos sentidos. E semelhantemente, porque também,
como já se demonstrou, a beatitude do homem não pode consistir nos bens corpóreos, únicos que
alcançamos pela operação do sentido.
Porém a atividade dos sentidos pode concernir à beatitude, antecedente e conseqüentemente. —
Antecedentemente, quanto à beatitude imperfeita, tal como pode ser obtida na vida presente, pois, a
operação do intelecto preexige a do sentido. — Conseqüentemente, quanto à perfeita beatitude, que é
esperada no céu; pois, após a ressurreição, da beatitude mesma da alma, como diz Agostinho, haverá
uma certa refluência para o corpo e os sentidos corpóreos, de modo que se aperfeiçoem nas suas
operações; e isto resultará mais claro quando se tratar, a seguir, da ressurreição dos corpos. E então, o
ato pelo qual a alma humana se une a Deus, não dependerá do sentido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção aduzida prova que a operação do sentido
exigida, antecedentemente, para a beatitude imperfeita, tal como ela pode ser adquirida nesta vida.

RESPOSTA À SEGUNDA. — A beatitude perfeita, tal como os anjos a têm absorve todos os bens pela
união com a fonte universal de todo o bem; e ele não precisa, para isso, de cada um dos bens
particulares. Mas para a beatitude imperfeita atual, é necessária a reunião dos bens suficientes à mais
perfeita atividade desta vida.

RESPOSTA À TERCEIRA. — Na beatitude perfeita o homem totalmente se aperfeiçoa; mas quanto à
parte inferior, por uma redundância da superior. Porém na beatitude imperfeita da vida presente,
inversamente, da perfeição da parte inferior procede-se à da superior.

## Art. 4 — Se a beatitude consiste no ato da vontade.
(I, q. 26, a . 2, ad 2; IV Sent., dist. XLIX, q. 1, a . 1, q ª 2; III Cont. Gent. cap. XXVI; Quodl. VIII, q. 9, a . 1;
Compend. Theol., cap. CVII),
O quarto discute-se assim. — Parece que a beatitude consiste no ato da vontade.

1. — Pois, como pensa Agostinho14, a beatitude do homem consiste na paz, por onde diz a Escritura (Sl
147, 14): O que estabeleceu a paz nos teus limites. Ora, a paz diz respeito à vontade. Logo, a beatitude
do homem consiste na vontade.

2. Demais. — A beatitude é o sumo bem. Ora, o bem é objeto da vontade. Logo, a beatitude consiste na
operação da vontade.

3. Demais. — Ao primeiro movente corresponde o último fim; assim, o último fim de todo um exército é
a vitória, que é o último fim do chefe, que move a todos. Ora, o primeiro movente à operação é a
vontade, que move toda as outras virtudes, como a seguir se dirá. Logo, a beatitude pertence à vontade.

4. Demais. — Se a beatitude é uma operação, necessariamente há de ser a mais nobre operação do
homem. Ora, mais nobre é o amor de Deus, que é ato da vontade, do que o conhecimento, operação do
intelecto, como se vê claramente na Escritura (1 Cor 13). Logo, a beatitude consiste num ato da vontade.
14 XIX De Civ. Dei.

5. Demais. — Agostinho diz que feliz é quem tem tudo o que quer e nada quer mal; e logo depois
acrescenta:Aproxima-se de feliz quem quer bem tudo o que quer; pois, os bens fazem o feliz, dos quais
ele já tem algo, que é a boa vontade mesma. Logo, a beatitude consiste no ato da vontade.
Mas, em contrário, diz o Senhor, na Escritura (Jo 17, 3): A vida eterna porém consiste em que eles
conheçam por um só verdadeiro Deus a ti. Ora, a vida eterna é o fim último, como já se disse. Logo, a
beatitude do homem consiste no conhecimento de Deus, ato do intelecto.

SOLUÇÃO. — Como já se disse, duas coisas supõe a beatitude; a essência dela e a deleitação que
acompanha e que lhe é como um acidente.
Digo, pois, que é impossível a beatitude essencial consistir em ato da vontade, por ser manifesto, pelo já
estabelecido, que ela é a consecução do último fim e este não consiste em tal ato. Pois, a vontade busca
o fim ausente, quando o deseja, e se compraz repousando no fim presente. Ora, como é manifesto, o
desejo em si do fim não é a consecução dele, mas tendência para ele. Ao passo que o deleite advém à
vontade quando o fim lhe é presente; e não inversamente, pois, não se torna presente uma coisa
porque a vontade nela se deleita. Logo, é necessário seja outra, que não o ato da vontade, a causa que
torna presente o fim. — E isto se vê manifestamente em relação aos fins sensíveis. Assim, se conseguir
dinheiro fosse ato da vontade, o cubiçoso, logo, desde o princípio, quando quer tê-lo, consegui-lo-ia.
Ora, a princípio, este lhe está ausente e o consegue apreendendo-o com a mão ou por outro qualquer
meio, e então é que se deleita com o dinheiro adquirido. — E o mesmo, se dá com o fim inteligível. Pois,
primeiro, queremos consegui-lo, e o conseguimos quando ele se nos torna presente por um ato do
intelecto: e então a vontade, deleitada, repousa no fim já adquirido. Por onde, a essência da beatitude
consiste num ato da vontade.
Porém à vontade pertence o deleite conseqüente à beatitude, segundo a expressão de Agostinho,
quando diz ser a beatitude o alegrar-se com a verdade, porque a alegria em si é a consumação da
felicidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A paz diz respeito ao fim último do homem; não que seja
essencial a beatitude mesma, mas por lhe ser relativa, antecedente e conseqüentemente.
Antecedentemente, enquanto está já removido tudo o que perturba e impede o último fim. E
conseqüentemente, quando o homem, alcançado esse fim, fica em paz, com o desejo satisfeito.

RESPOSTA À SEGUNDA. — O objeto primeiro da vontade não é o seu ato, assim como o objeto primeiro
da visão não é a visão, mas o visível. Por onde, do fato mesmo de a beatitude pertencer à vontade, com
seu objeto primeiro, resulta que lhe não pertence como ato da mesma.

RESPOSTA À TERCEIRA. — O intelecto apreende o fim antes da vontade; contudo, o movimento para o
fim começa na vontade. Por onde, a esta cabe o que resulta em último lugar, da consecução do fim, a
saber, a deleitação ou fruição.

RESPOSTA À QUARTA. — A dilecção, movendo, tem preeminência sobre o conhecimento; mas este é-
lhe anterior, no atingir o objeto, pois só se ama o conhecido, como diz Agostinho. Portanto, atingimos,
primeiro, por ato do intelecto, o fim inteligível; assim como atingimos primeiro, pelo ato do sentido, o
fim sensível.

RESPOSTA À QUINTA. — Quem tem tudo o que quer é feliz, por isso; mas não o é por um ato da
vontade; senão por outra coisa. Porém não querer nada de mal é necessário à beatitude, como
disposição devida para ela. Ora, a boa vontade se considera do número dos bens que fazem feliz,
porque é uma certa inclinação para eles; assim como o movimento se reduz ao gênero do seu termo,
como a alteração à qualidade.

## Art. 5 — Se a beatitude consiste na atividade do intelecto prático.
(IV Sent., dist. XLIX, q. 1 a . 1, q ª 3; III Ethic., lect. X spp.).
O quinto discute-se assim. — Parece que a beatitude consiste na atividade do intelecto prático.

1. — Pois, o fim último da criatura consiste em assimilar-se com Deus. Ora, mais se assimila com ele pelo
intelecto prático, causa das coisas inteligidas, do que pelo especulativo, cuja ciência é derivada das
coisas. Logo, a beatitude do homem consiste, antes, na operação o intelecto prático do que na do
especulativo.

2. Demais. — a beatitude é o bem perfeito do homem. Ora, o intelecto prático ordena-se sobretudo ao
bem e o especulativo, ao verdadeiro. Por isso, somos considerados bons pela perfeição do intelecto
prático e não pela do especulativo, pela qual nos consideram sábios ou inteligentes. Logo, a beatitude
do homem consiste, antes, no ato do intelecto prático do que no do especulativo.

3. Demais. — A beatitude é um certo bem próprio ao homem. Ora, o intelecto especulativo se ocupa
sobretudo com o que lhe é exterior, ao passo que o prático com o homem mesmo, como as suas
operações e paixões. Logo, a beatitude do homem consiste, mais, na operação do intelecto prático que
na do especulativo.
Mas, em contrário, diz Agostinho, que contemplação nos está prometida como fim de todas as opções e
perfeição eterna das alegrias.

SOLUÇÃO. — A beatitude consiste, mais, na operação do intelecto especulativo, que na do prático.
O que resulta de tríplice consideração.
A primeira é que, se a beatitude do homem é atividade, necessário é seja a mais elevada delas. Ora, esta
é relativamente ao objeto mais elevado, o da mais elevada potência, que é o intelecto, cujo objeto por
excelência é o bem divino, objeto, não do intelecto prático, mas do especulativo. Por onde, na atividade
contemplativa das coisas divinas consiste sobretudo a beatitude. E como, no dizer de Aristóteles, cada
ser é considerado como sendo o que nele é ótimo; tal operação há-se ser sobretudo a própria do
homem, e a em máximo grau deleitável.
A segunda resulta de ser a contemplação principalmente buscada por si mesma. Ora, o ato do intelecto
prático não é buscado, por si mesmo em vista da ação, pois, as ações, em si, se ordenam a algum fim.
Por onde e manifesto, que o último fim não pode consistir na vida ativa, pertencente ao intelecto
prático.
A terceira resulta de que, na vida contemplativa, o homem comunica com seres superiores, i. é, com
Deus e os anjos, com os quais se assimila, pela beatitude. Ora, pelo que pertence à vida ativa, os animais
têm de certo modo comunidade com o homem, embora imperfeitamente.
Por onde, a beatitude última e perfeita, esperada na vida futura, consiste totalmente na contemplação.
Enquanto a imperfeita, tal como pode ser adquirida nesta vida, consiste primeiro e principalmente na
contemplação, e secundariamente na operação do intelecto prático, que ordena as ações e paixões
humanas, como diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A referida assimilação do intelecto prático com Deus é
por proporcionalidade, pois está para o seu objeto conhecido, como Deus, para o seu. Ao passo que a
assimilação do intelecto especulativo com Deus é por união ou informação, que é assimilação muito
maior. E todavia, pode-se dizer que, em relação à sua essência, que é principalmente conhecida, Deus
não tem conhecimento prático, mas somente especulativo.

RESPOSTA À SEGUNDA. — O intelecto prático se ordena ao bem exterior, ao passo que o especulativo,
para o bem em si mesmo, que é a contemplação da verdade. E se esse for perfeito, o homem também o
fica totalmente sendo e torna-se bom; ora, esse bem o intelecto prático não o tem, antes ordena para
ele.

RESPOSTA À TERCEIRA. — A objeção procederia se o homem em si fosse o seu último fim.
Pois nesse caso a consideração e a ordenação dos seus atos e paixões seria a sua beatitude. Mas, como
o fim último do homem é um bem que lhe é extrínseco, i.é, Deus, que atingimos por operação do
intelecto especulativo, por isso a sua beatitude consiste, mais em tal atividade do que na do intelecto
prático.

## Art. 6 — Se a beatitude do homem consiste na consideração das ciências especulativas.
(III Cont. Gent., cap. XLVIII; Compend. Theol., cap. CIV).
O sexto discute-se assim. — Parece que a beatitude do homem consiste na consideração das ciências
especulativas.

1. — Pois, como diz o Filósofo, a felicidade é a operação segundo a virtude perfeita. E ao distinguir as
virtudes, admite só três especulativas — a ciência, a sapiência e o intelecto — concernentes todas à
consideração das ciências especulativas. Logo, a beatitude última do homem consiste na consideração
dessas ciências.

2. Demais. — A beatitude última do homem é a desejada, naturalmente e por si mesma, por todos os
homens. Ora, tal é a consideração das ciências especulativas; pois, como diz Aristóteles, todos os
homens desejam naturalmente saber; e acrescenta, logo depois, que as ciências especulativas são
buscadas por si mesmas. Logo, a beatitude consiste na consideração de tais ciências.

3. Demais. — A beatitude é a perfeição última do homem. Ora, tudo o que chega à perfeição há de sê-lo
na medida em que é reduzido da potência ao ato. Ora, o intelecto humano se reduz ao ato pela
consideração das ciências especulativas. Logo, nessa consideração há-de consistir a beatitude última do
homem.
Mas, em contrário, diz Jeremias (9, 23): Não se glorie o sábio no seu saber, referindo-se à sabedoria das
ciências especulativas. Logo, não consiste na consideração delas a beatitude última do homem.

SOLUÇÃO. — Como já se disse, dupla é a beatitude do homem: uma, perfeita e outra, imperfeita. Há-de
considerar-se como perfeita a que realiza a verdadeira essência da beatitude; e como imperfeita, a que
não a realiza, mas só participa de uma semelhança particular da beatitude. Assim como a prudência
perfeita é a do homem que conhece a razão do que deve agir; ao passo que a imperfeita é a de alguns
brutos, que têm uns instintos particulares para certas operações semelhantes às da prudência.
Por onde, a beatitude perfeita não pode consistir essencialmente na consideração das ciências
especulativas. E isto é evidente para quem refletir que a consideração da ciência especulativa não
ultrapassa o alcance dos seus princípios, pois, nos princípios da ciência está virtualmente contida toda a
ciência. Ora, os princípios primeiros das ciências especulativas são derivados dos sentidos, como
claramente se vê no Filósofo. Por onde, toda a consideração das ciências especulativas não pode
ultrapassar o ponto a que pode levar o conhecimento dos sensíveis. Ora, a beatitude última do homem,
que é a sua perfeição última, não pode consistir no conhecimento dos sensíveis. Pois nada se aperfeiçoa
pelo que é inferior, senão na medida em que este participa de algum modo do superior. Ora, é
manifesto que a forma da pedra, ou de qualquer outro objeto sensível, é inferior ao homem. Por isso,
não se aperfeiçoa o intelecto por essa forma, como tal, mas enquanto ela participa da semelhança de
algo superior ao intelecto humano, que é o lume inteligível ou algo de tal. Ora, tudo o que existe em
virtude de outra coisa se reduz ao existente por si. Por onde, é necessário que a perfeição última do
homem se realize pelo conhecimento de algo superior ao intelecto humano. Já se demonstrou, porém,
que, pelos sensíveis, não se pode chegar ao conhecimento das substâncias separadas, superiores ao
intelecto humano. Donde se conclui que a beatitude última do homem não pode consistir na
consideração das ciências especulativas. – Mas assim como as formas sensíveis participam de certa
semelhança com as substâncias superiores, assim, a consideração das ciências especulativas e uma
participação da beatitude verdadeira e perfeita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No passo aduzido, o Filósofo trata da felicidade
imperfeita, tal como pode ser obtida nesta vida, segundo já se disse.

RESPOSTA À SEGUNDA. — É desejada naturalmente não só a beatitude perfeita, mas também qualquer
semelhança ou participação dela.

RESPOSTA À TERCEIRA. — Pela consideração das ciências especulativas o nosso intelecto se reduz ao
ato, de certo modo; não porém ao ato último e completo.

## Art. 7 — Se a beatitude do homem consiste no conhecimento das substâncias separadas, i. é, dos anjos.
(I, q. 64, 1, ad 1; III Cont. Gent., cap. XLIV; In Boet, de Trin., q. 6, a . 4, ad 3).
O sétimo discute-se assim. — Parece que a beatitude do homem consiste no conhecimento das
substâncias separadas, i. é, dos anjos.

1. — Pois, como diz Gregório: De nada serve participar dos regozijos dos homens se não chegarmos a
participar dos angélicos, com o que designa a beatitude final. Ora, podemos participar dos regozijos
angélicos pela contemplação deles. Logo, nessa contemplação consiste a felicidade última do homem.

2. Demais. — A perfeição última de um ser consiste em unir-se ao seu princípio; assim, diz-se que o
círculo é figura perfeita, porque tem o mesmo princípio e o mesmo fim. Ora, o princípio do
conhecimento humano está nos anjos, pelos quais os homens são iluminados, como diz Dionísio. Logo, a
perfeição do intelecto humano consiste na contemplação dos anjos. 3. Demais. — Uma natureza é
perfeita quando está unida a uma natureza superior; assim, a perfeição última do corpo consiste em
estar unido à natureza espiritual. Ora, superiores ao intelecto humano, na ordem da natureza, são os
anjos. Logo, a perfeição última desse intelecto esta em se unir com os anjos mesmos, pela
contemplação.
Mas, em contrário, diz Jeremias (Jr 9, 24): Porém nisto se glorie aquele que se gloria, em conhecer-me e
em saber. Logo, a glória última do homem, ou a beatitude não consiste senão no conhecimento de
Deus.

SOLUÇÃO. — Como já se disse, a beatitude perfeita do homem não consiste em ser a perfeição do
intelecto, participativamente, mas em ser tal essencialmente. Ora, como é manifesto, o que constitui a
perfeição de uma potência contém em essência o objeto próprio dessa potência. E sendo o objeto,
próprio do intelecto a verdade, a contemplação do que tem a verdade participada não torna perfeito o
intelecto, por perfeição última. Ora, sendo a disposição das coisas, quanto à existência, a mesma que a
disposição quanto à verdade, segundo Aristóteles, todos os seres, por participação são também
verdadeiros do mesmo modo. Ora, os anjos têm a existência participada, porque só em Deus a
existência é a essência, como já se demonstrou na primeira parte. Donde resulta, que só Deus é a
verdade por essência e que a contemplação dele torna perfeitamente feliz. — Nada, porém, impede
admitir-se uma certa beatitude imperfeita pela contemplação dos anjos, e mesmo mais alta do que na
consideração das ciências especulativas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Participaremos dos regozijos angélicos não só
contemplando-os, mas, simultaneamente com eles, Deus.

RESPOSTA À SEGUNDA. — Para os que consideram as almas humanas criadas pelos anjos, é mui
conseqüente consista a beatitude do homem na contemplação deles, sendo essa como que a união com
o seu princípio. Mas isto é errôneo, como na primeira parte já se disse. Por onde, a perfeição última do
intelecto humano procede da união com Deus, princípio tanto da criação da alma como da sua
iluminação. Ao passo que o anjo ilumina como ministro, conforme já se estabeleceu na primeira parte.
Por onde, pelo seu ministério, ajuda o homem a chegar à beatitude, não sendo porém o objeto da
beatitude humana.

RESPOSTA À TERCEIRA. — De dois modos pode ser a natureza superior atingida pela inferior. Primeiro,
quanto ao grau da potência participante, e então a perfeição última do homem estará em chegar a
contemplar como os anjos contemplam. Segundo, como o objeto é atingido pela potência, e então a
perfeição última de uma potência está em atingir aquilo em que plenamente se encontra a essência do
seu objeto.

## Art. 8 — Se a beatitude do homem consiste na visão da essência divina em si mesma.
(I. q. 12, a . 1; De Verit., q. 8, a . 1; Quodl. X, q. 8; Compend. Theol., part. I. cap. CIV, CVI; part. II, cap. IX;
In Matth., cap. V; In Ion., cap. I lect. XI).
O oitavo discute-se assim. — Parece que a beatitude do homem não consiste na visão da divina
essência em si mesma.

1. — Pois, no dizer de Dionísio, pelo supremo intelecto o homem se une a Deus como ao
completamente desconhecido. Ora, o que é visto em essência não é completamente desconhecido.
Logo, a perfeição última do intelecto ou beatitude não consiste em ver Deus em essência.

2. Demais. — A perfeição da natureza mais alta é mais elevada. Ora, a perfeição própria do divino
intelecto é contemplar a sua própria essência.
Logo, tal não alcança a perfeição do intelecto humano, que lhe é inferior.
Mas, em contrário, diz a Escritura (1 Jo 3, 2): Quando ele aparecer, seremos semelhantes a ele e o
veremos bem como ele é.

SOLUÇÃO. — A beatitude última e perfeita não pode estar senão na visão da divina essência, para a
evidência do que duas coisas se devem considerar. A primeira é que o homem não é perfeitamente feliz,
enquanto lhe resta algo a desejar e a buscar. A segunda é que a perfeição de uma potência é relativa à
natureza do seu objeto. Ora, o objeto do intelecto é a quididade, i. é, a essência da coisa, como diz
Aristóteles. Por onde, a perfeição do intelecto está na razão direta do seu conhecimento da essência de
uma coisa. De um intelecto, pois, que conhece a essência de um efeito sem poder conhecer, por ele, o
eu a causa essencialmente é, não se diz que atinge a causa em si mesma, embora possa, pelo efeito,
saber se ela existe. Por onde, permanece naturalmente no homem o desejo de também saber o que é a
causa, depois de conhecido o efeito e de sabido que tem causa. E tal desejo é o de admiração e provoca
a indagação, como diz Aristóteles. Por ex., quem contempla um eclipse do sol, considera-lhe a causa e,
não sabendo qual seja, admira-se e, admirando-se, perquire; esta perquirição não repousa até que
chegue a conhecer a essência da causa. — Se, pois, o intelecto humano, conhecendo a essência de um
efeito criado, somente souber que Deus existe, a sua perfeição ainda não atingiu a causa primeira em si
mesmo, restando-lhe ainda o desejo natural de perquirir a causa, e por isso não é perfeitamente feliz.
Portanto, para a felicidade perfeita é necessário o intelecto atingir a essência mesma da causa primeira.
E assim, terá a sua perfeição pela união com Deus como o objeto em que só consiste a beatitude do
homem, conforme já se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dionísio se refere ao conhecimento dos que estão na
via, em busca da beatitude.

RESPOSTA À SEGUNDA. — Como já se disse, em dupla acepção se pode considerar o fim. Como a coisa
mesma que é desejada, e então como já se disse, o fim da natureza superior é idêntico ao da inferior, e
mesmo ao de todas as coisas. E como a aquisição dessa coisa mesma, e então o fim da natureza superior
é diverso do fim da inferior, conforme a relação diversa com uma determinada coisa. Assim, pois, mais
elevada é a beatitude de Deus, que compreende pelo intelecto a sua essência, que a do homem ou a do
anjo, que vê mas não compreende.