# Questão 24: Da ordem das paixões entre si.
Em seguida devemos tratar da ordem das paixões entre si.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se as paixões do irascível tem prioridade sobre as do concupiscível.
(III Sent., dist. XXVI, q. 1, a . 3; q.2 a . 3, qª 2; De Verit;. Q. 25, a . 2).
O primeiro discute-se assim. ― Parece que as paixões do irascível tem prioridade sobre as do
concupiscível.

1. ― Pois, a ordem das paixões depende da dos objetos. Ora, o objeto do irascível é o bem árduo que,
parece, é o supremo entre os outros bens. Logo, as paixões do irascível tem prioridade sobre as do
concupiscível.

2. Demais. ― O motor é anterior ao movido, Ora, o irascível está para o concupiscível como o motor
para o movido, pois foi dado aos animais para vencerem os obstáculos que se opõem a que o
concupiscível goze do seu objeto, conforme já dissemos; ou, na linguagem de Aristóteles, o que remove
o obstáculo exerce a função de motor. Logo, as paixões do irascível tem anterioridade sobre as do
concupiscível.

3. Demais. ― A alegria e a tristeza são paixões do concupiscível. Ora, resultam das do irascível, pois, diz
o Filósofo, que a punição acalma o ímpeto da ira, produzindo a deleitação em lugar da tristeza. Logo, as
paixões do irascível tem prioridade sobre as do concupiscível.
Mas, em contrário. ― As paixões do concupiscível visam o bem absoluto; as do irascível porém, o bem
restrito, i. é, árduo. Ora, como o bem absoluto tem prioridade sobre o restrito, as paixões do
concupiscível tem prioridade sobre as do irascível.

SOLUÇÃO. ― As paixões do concupiscível abrangem um domínio mais vasto que as do irascível, pois há
nelas algo relativo ao movimento, como o desejo, e algo relativo ao repouso, como a alegria e a tristeza;
ao passo que as do irascível nada tem de relativo ao repouso mas só ao movimento. E a razão é que,
aquilo em que repousamos nada contém de difícil ou árduo, que é o objeto do irascível.
Ora, o repouso, sendo o termo do movimento, é anterior na intenção, mas posterior na execução. Se
pois compararmos as paixões do irascível com as do concupiscível, que supõem o repouso no bem,
manifestamente aquelas precedem a estas, na ordem da execução; assim, a esperança precede à alegria
e por isso a causa, conforme aquilo na Escritura (Rm 12, 12): na esperança alegres. A paixão
concupiscível porém, que implica o repouso no mal, a saber, a tristeza, é média entre as duas paixões do
concupiscível pois, sendo causada pelo ocorrer do mal que era temido, resulta do temor; mas precede
ao movimento da ira, causa de nos arrojarmos à vingança. E como vingar-se do mal é apreendido como
bom, o irado se alegra, após havê-lo conseguido. Por onde é manifesto, que toda paixão do irascível
termina numa paixão do concupiscível que implica repouso, a saber, a alegria ou a tristeza.
Se porém compararmos as paixões do irascível com as do concupiscível, que importam o movimento,
estas são manifestamente primeiras, porque aquelas lhe acrescentam algo, assim como o objeto do
irascível acrescenta algo ao do concupiscível, a saber, o árduo ou a dificuldade. Assim, a esperança
acrescenta ao desejo um certo esforço e uma certa elevação do ânimo para conseguir o bem árduo.
Semelhantemente, o temor acrescenta à aversão ou abominação uma certa depressão do ânimo por
causa da dificuldade do mal.
Por onde, as paixões do irascível são médias entre as do concupiscível, que importam movimento para o
bem ou para o mal, e as que importam repouso no bem ou no mal. Logo, é claro que as do irascível tem
princípio e termo nas do concupiscível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção procederia se da essência do objeto do
concupiscível fosse algo de oposto ao árduo, como é da essência do objeto do irascível ser árduo. Ora, o
concupiscível, tendo o bem absoluto, como objeto, este é naturalmente anterior ao do irascível, como o
comum é anterior ao próprio.

RESPOSTA À SEGUNDA. ― O que remove o obstáculo não é motor por si mesmo, mas por acidente.
Ora, no caso, trata-se da ordem em si mesma entre as paixões. E além disso, o irascível remove o
obstáculo ao repouso do concupiscível no seu objeto. Donde não resulta senão que as paixões do
irascível precedem as do concupiscível, que se referem ao repouso.
E é nisto que se funda a TERCEIRA OBJEÇÃO.

## Art. 2 — Se o amor é a primeira das paixões do concupiscível.
(I, q. 20, a . 1; infra, q. 27, a . 4; III Sent., dist. XXVII, q. 1, a . 3; IV Cont. Gent., cap. XIX; De Verit., q. 26, a .
4; De Virtut., q. 3, a . 3; De Div. Nom., cap. IV, lect. IX).
O segundo discute-se assim. ― Parece que o amor não é a primeira das paixões do concupiscível.

1. ― Pois, a denominação da virtude concupiscível deriva da concupiscência, paixão idêntica ao desejo.
Ora, a denominação é dada pelo que é mais importante, como diz Aristóteles. Logo, a concupiscência
tem precedência sobre o amor.

2. Demais. ― O amor importa uma certa união, pois é uma força unitiva e consistente, como diz
Dionísio. Ora, a concupiscência ou desejo é um movimento para a união com a coisa cobiçada ou
desejada. Logo, tem prioridade sobre o amor.

3. Demais. ― A causa é anterior ao efeito. Ora, a deleitação é às vezes causa do amor, pois certos amam
por deleitação, como diz Aristóteles. Logo, é anterior ao amor, que portanto não é a primeira entre as
paixões do concupiscível.
Mas, em contrário, diz Agostinho que todas as paixões são causadas do amor, pois o amor, desejando
ardentemente possuir o seu objeto, é desejo; quando porém já o possui e o goza é alegria. Logo, o amor
é a primeira das paixões do concupiscível.

SOLUÇÃO. ― Os objetos do concupiscível são o bem e o mal. Ora, sendo este a privação daquele, o bem
há-de necessariamente ter prioridade. Logo, todas as paixões que o tem por objeto são naturalmente
anteriores as que tem o mal como objeto tendo cada uma a sua paixão oposta, pois, buscando-se o bem
é forçoso eliminar-se o mal oposto.
Ora, o bem tem natureza de fim que é, certo, primeiro na intenção e posterior, na execução. Por onde a
ordem das paixões do concupiscível pode ser considerada relativamente à intenção ou à execução.
Quanto a esta, é primeiro aquilo que primeiramente existe no ser que tende para o fim. Ora, é
manifesto que tudo o que tende para um fim há-de ter, primeiro, aptidão para o alcançar e proporção
com ele, pois, nada tende para um fim não proporcionado. Segundo, há-de ser movido para o fim.
Terceiro, repousa no fim alcançado. Ora, essa aptidão mesma da proporção do apetite com o bem é o
amor, que não é mais do que a complacência no bem. Depois, o movimento para o bem é o desejo ou
concupiscência. E por fim o repouso no bem é a alegria ou deleitação. Por onde, segundo esta ordem, o
amor precede o desejo e este, a deleitação. O contrário, porém se dá na ordem da intenção, porque a
deleitação intencionada causa o desejo e o amor, pois ela é o gozo do bem que, como o bem mesmo, é
de certo modo fim, conforme já dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― As coisas são denominadas conforme nós as
conhecemos, pois,as palavras são signos das coisas inteligidas, segundo o Filósofo. Ora, comumente
conhecemos a causa pelo efeito. Ora, o efeito do amor, quando o objeto amado já é possuído, é a
deleitação; quando porém ainda não o é, é o desejo ou concupiscência. Pois, como diz Agostinho, o
amor é mais sentido quando o produz a carência. Logo, entre todas as paixões do concupiscível, a
concupiscência é a mais sensível, e por isso dela recebe a potência a sua denominação.

RESPOSTA À SEGUNDA. ― Há dupla união entre a coisa amada e o amante. ― Uma real, por conjunção
com a coisa mesma que é amada. E tal união respeita à alegria ou à deleitação, resultante do desejo. ―
Outra é a união afetiva, por aptidão ou proporção; assim, quando um ser tem aptidão relativamente a
outro e inclinação para ele deste já participa. É assim que o amor implica a união, a qual precede ao
movimento do desejo.

RESPOSTA À TERCEIRA. ― A deleitação causa o amor, enquanto tem prioridade na intenção.

## Art. 3 — Se a esperança é a primeira entre as paixões do irascível.
O terceiro discute-se assim. ― Parece que a esperança não é a primeira entre as paixões do irascível.

1. ― Pois, a potência irascível recebe da ira a sua denominação. Ora, como esta é dada pelo que é mais
importante, resulta ser a ira mais importante que a esperança e ter prioridade sobre ela.

2. Demais. ― O árduo é o objeto do irascível. Ora, é mais árduo superar o mal contrário iminente e
futuro ―próprio da coragem; ou o mal já presente ― próprio à ira, que esforçar-se por adquirir,
absolutamente falando, qualquer bem; e semelhantemente, parece mais árduo vencer o mal presente
que o futuro. Logo, a ira é paixão mais importante que a coragem e esta, que a esperança, e portanto a
última não tem prioridade.

3. Demais. ― No movimento para o fim, antes de chegarmos ao termo afastamo-nos do ponto inicial.
Ora, o temor e o desespero importam afastamento de um ponto, ao passo que a coragem e a esperança
implicam a aproximação. Logo, as duas primeiras precedem as duas últimas paixões.
Mas, em contrário. ― O que mais se aproxima da que é primeiro mais prioridade tem. Ora, a esperança
está mais próxima do amor, que é a primeira das paixões. Logo, tem prioridade entre todas as paixões
do irascível.

SOLUÇÃO. ― Como já dissemos, todas as paixões do irascível importam movimento para alguma coisa.
Ora, este movimento, no irascível, pode proceder de dupla causa: ou só da aptidão ou proporção
relativamente ao fim, o que é próprio do amor e do ódio; ou da presença do bem mesmo e do mal, o
que pertence à tristeza ou à alegria. Mas ao passo que a presença do bem não causa nenhuma paixão
no irascível, como já dissemos, a do mal causa a paixão da ira.
Ora, como na via da geração ou da consecução, a proporção ou a aptitude relativamente ao fim precede
a consecução dele, a ira é entre todas as paixões do irascível a última na via da geração. Entre as outras
paixões do irascível porém, que importam o movimento conseqüente ao amor ou ódio do bem e do mal,
as que tem como objeto o bem, como a esperança e o desespero, hão naturalmente de ter prioridade
sobre as que, como a coragem e o temor, tem por objeto o mal; porém de modo tal, que a esperança
tem prioridade sobre o desespero, pois, é um movimento para o bem, em si mesmo, que, por natureza,
é atrativo; o desespero, por seu lado, é um afastamento do bem, o que é próprio deste não como tal,
mas em certo ponto de vista, e portanto acidentalmente. Pela mesma razão, o temos, implicando
afastamento do mal, precede à audácia. Mas, que a esperança e o desespero tenham naturalmente
prioridade sobre o temor e a coragem, resulta manifestamente de serem a razão destas duas últimas
paixões, assim como o desejo do bem é a razão de se evitar o mal; pois a coragem resulta da esperança
da vitória e o temor, do desespero de vencer. A ira, por outro lado, resulta da coragem, pois ninguém
que deseja vingar-se se encoleriza em ousar vingar-se, conforme diz Avicena.
Por onde fica claro que a esperança é a primeira entre as paixões do irascível. E, se quisermos conhecer
a ordem das paixões, segundo a geração, primeiramente surgem o amor e o ódio; depois, o desejo e a
fuga; terceiro, a esperança e o desespero; quarto, o temor e a coragem; quinto, a ira; sexto e último, a
alegria e a tristeza, que acompanham todas as paixões, como se diz. E de como o amor é anterior ao
ódio; o desejo, à fuga; a esperança, ao desespero; o temor, à coragem; a alegria, à tristeza, do sobredito
se colige.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Sendo a ira causada pelas outras paixões como o efeito,
pelas causas precedentes, dela, como do mais manifesto, a potência recebe a sua denominação.

RESPOSTA À SEGUNDA. ― Não é o árduo, mas antes, o bem, a razão do aproximar-se ou do desejar. Por
onde, a esperança, que visa o bem mais diretamente, tem prioridade, embora a coragem ou mesmo a
ira tenham às vezes, que afrontar o que é mais árduo.

RESPOSTA À TERCEIRA. ― O apetite, primariamente e por si, move-se para o bem, como seu objeto
próprio e essa é a causa de afastar-se do mal. Pois, o movimento da parte apetitiva é proporcional, não
ao movimento natural, mas à intenção da natureza, que visa o fim antes de visar a remoção do
obstáculo contrário, não sendo este querido senão para a obtenção do fim.

## Art. 4 — Se as principais paixões são as quatro seguintes: a alegria e a tristeza, a esperança e o temor.
(Infra, q. 84, a . 4, ad 2; IIª. IIªº, q. 141, ª 7, ad 3; III Sent., dist. XXVI, q. 1, a . 4; De Verit., q. 26, a . 5).
O quarto discute-se assim. ― Parece que as quatro principais paixões não são as quatro seguintes: a
alegria e a tristeza, a esperança e o temor.

1. ― Pois, Agostinho em vez da esperança, coloca a cobiça.

2. Demais. ― Há dupla ordem nas paixões da alma: a da intenção e a da execução ou geração. Ora, as
paixões se consideram principais ou quanto à ordem da intenção, e nesse caso só a alegria e a tristeza,
que são finais, são as principais; ou quanto à ordem da consecução ou geração, e então será o amor a
principal. Logo, de nenhum modo se podem considerar como principais as quatro paixões seguintes: a
alegria e a tristeza, a esperança e o temor.

3. Demais. ― Como a coragem é causada pela esperança, assim o temor, pelo desespero. Logo, devem-
se considerar a esperança e o desespero como paixões principais, na qualidade de causas; ou a
esperança e a coragem por terem afinidades com as duas primeiras.
Mas, em contrário, diz Boécio, enumerando as quatro principais paixões: repele as alegrias, repele o
temor, foge da esperança e nem a dor esteja presente.

SOLUÇÃO. ― Estas quatro paixões são comumente consideradas como principais; as duas primeiras ― a
alegria e a tristeza ― por serem absolutamente completivas e finais, relativamente a toda as outras, e a
elas conseqüentes, como diz Aristóteles; o temor e a esperança, de outro lado, por serem completivas,
não absolutamente, mas no gênero do movimento apetitivo de alguma coisa. Pois, relativamente ao
bem, o movimento começa pelo amor, continua pelo desejo e termina pela esperança; e em relação ao
mal, começa pelo ódio, continua pela aversão e termina pelo temor.
Por onde, o número dessas quatro paixões funda-se de ordinário na diferença entre o presente e o
futuro, pois o movimento se refere ao futuro e o repouso, ao presente. Ora, o bem presente é objeto da
alegria, o mal presente, da tristeza; o bem futuro, da esperança e o mal futuro, do temor. E as demais
paixões referentes ao bem ou ao mal presente ou futuro reduzem-se a estas como complemento delas.
Por isso alguns também consideram principais as paixões em questão, por serem gerais. O que é
verdade, se a esperança e o temor designarem o movimento do apetite tendente comumente para algo
de desejável ou que deve ser evitado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Agostinho coloca o desejo ou cobiça em lugar da
esperança, por visarem o mesmo objeto, i. é, ao bem futuro.

RESPOSTA À SEGUNDA. ― As paixões em questão chamam-se principais, na ordem da intenção e como
complementares. E embora o temor e a esperança não sejam as últimas, absolutamente, são-no
contudo no gênero das que tendem para algo quase futuro. Nem pode haver dificuldade, a não ser
sobre a ira; mas esta não pode ser considerada principal, porque é um certo efeito da audácia, que não
pode ser paixão principal, como a seguir se dirá.

RESPOSTA À TERCEIRA. ― O desespero implica afastamento mas quase por acidente, do bem; e a
audácia importa no aproximar-se, também acidental, do mal. Logo, estas paixões não podem ser
principais; pois, o acidental não o pode ser. E assim também a ira, conseqüente à coragem, não pode ser
considerada principal.