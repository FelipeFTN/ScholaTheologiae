# Questão 86: Da mácula do pecado.
Em seguida devemos tratar da mácula do pecado. E, nesta questão, discutem-se dois artigos:

## Art. 1 — Se o pecado causa mácula na alma.
(Infra, q. 89, a. I; IV Sent., dist. XVIII, q. 1, a. 2, qª 1).
O primeiro discute-se assim. — Parece que o pecado não causa mácula nenhuma na alma.

1. — Pois, a natureza superior não pode ser contaminada pelo contato da inferior; por isso, o raio solar
não se contamina pelo contato com os corpos fétidos, como diz Agostinho. Ora, a alma humana é de
natureza muito superior às coisas mutáveis, que busca, pecando. Logo, pelo pecado, não contrai, delas,
mácula.

2. Demais. — O pecado está principalmente na vontade, como já se disse (q. 74, a. 1, 2). Ora, a vontade
está na razão, como diz Aristóteles; e a razão ou intelecto não se macula por pensar em qualquer
objeto, mas ao contrário, se aperfeiçoa. Logo, também a vontade não se macula pelo pecado.

3. Demais. — Se o pecado causa mácula, esta ou é algo de positivo ou é privação pura. Se for algo de
positivo, não pode ser senão uma disposição ou hábito, pois nada mais pode ser causado pelo ato. Ora,
não é disposição nem hábito; pois pode se dar que, removida a disposição ou o hábito, ainda permaneça
a mácula, como o patenteia o caso de quem pecou mortalmente por prodigalidade e depois, pecando
mortalmente, adquiriu o hábito do vício oposto. Logo, a mácula não introduz nada de positivo na alma.
E nem por outro lado, é privação pura; porque todo pecado resulta do afastamento e da privação da
graça; donde se seguiria que todos os pecados haviam de constituir uma só mácula. Logo, a mácula não
é efeito do pecado.
Mas, em contrário, diz a Escritura (Sr 47, 22): Puseste mácula na tua glória. E (Ef 5, 27): Para a apresentar
a si mesmo a Igreja gloriosa, sem mácula nem ruqa. E ambos os lugares se referem à mácula do pecado.
Logo, esta é o efeito do pecado.

SOLUÇÃO. — A mácula se atribui, propriamente, ao corpo límpido que perde o lustre pelo contato com
outro corpo, como se dá com a roupa, o ouro, a prata e corpos semelhantes. E é por semelhança que
havemos de atribuir a mácula aos seres espirituais. Ora, a alma humana tem um duplo lustre: o
proveniente da refulgência da luz natural da razão, pela qual se dirige nos seus atos; e o da refulgência
da luz divina, i. é, da sabedoria e da graça, que também aperfeiçoa o homem para agir acertada e
convenientemente. Ora, há um como tato da alma quando ela adere a um objeto, pelo amor. Por onde,
quando peca, adere a um objeto, contra a luz da razão e da lei divina, como do sobredito resulta (q. 71,
a. 6). Donde o chamar-se metaforicamente mácula da alma ao detrimento que lhe sofre o lustre,
proveniente desse contacto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A alma não se contamina com as coisas inferiores, por
virtude delas mesmas, como se nela influíssem. Mas antes e inversamente, a alma é a que se contamina
pela sua ação, aderindo a essas coisas, desordenadamente, contra a luz da razão e da lei divina.

RESPOSTA À SEGUNDA. — A ação do intelecto se aperfeiçoa, por estarem nele, ao seu modo, objetos
inteligíveis. Por isso, longe de se contaminar com eles, o intelecto por eles se aperfeiçoa. O ato da
vontade porém consiste no movimento para os objetos, de modo que o amor une a alma à coisa amada.
E por isso, a alma se macula, quando adere desordenadamente, conforme aquilo da Escritura (Os 9,
10): e se tornaram abomináveis como as coisas que amaram.

RESPOSTA À TERCEIRA. — A mácula não é nada de positivamente existente na alma, nem exprime só
uma privação; mas, significa a privação do lustre da alma relativamente à sua causa, que é o pecado. Por
isso pecados diversos produzem máculas diversas. E o mesmo se dá com a sombra, que é privação pela
interposição de algum corpo; e conforme a diversidade dos corpos interpostos, assim as sombras se
diversificam.

## Art. 2 — Se a mácula permanece na alma depois do ato do pecado.
(Infra, q. 87, a. a. 6).
O segundo discute-se assim. — Parece que a mácula não permanece na alma depois do ato do
pecado.

1. — Pois, nada permanece na alma depois do ato, salvo o hábito ou a disposição. Ora, a mácula não é
hábito nem disposição, como já se demonstrou (a. 1, arg. 3). Logo, não permanece na alma depois do
ato do pecado.

2. Demais. — A mácula está para o pecado como a sombra, para o corpo, conforme já se disse (a. 1, ad
3). Ora, desaparecido o corpo, não permanece a sombra. Logo, passado o ato do pecado, não
permanece a mácula.

2. Demais. — Todo efeito depende da sua causa. Ora, a causa da mácula é o ato do pecado. Logo,
removido este, não permanece a mácula na alma.
Mas, em contrário, diz a Escritura (Js 22, 17): Acaso parece-vos pouco ter pecado em Belfegor, e que a
mácula deste crime ainda até hoje não esteja apagada em vós?

SOLUÇÃO. — A mácula do pecado subsiste na alma, mesmo depois de cessado o ato. E a razão é que a
mácula, como já dissemos (a. 1), implica a falta de lustre, pela privação da luz da razão ou da lei divina.
Portanto, enquanto o homem ficar fora dessa luz, nele subsiste a mácula do pecado; mas, quando voltar
à luz da razão divina, o que se dá pela graça, então cessará a mácula. Embora porém cesse o ato do
pecado, pelo qual o homem se afastou da luz da razão ou da lei divina, nem por isso volta
imediatamente ao estado anterior; mas, para tal, é necessário um movimento da vontade contrário ao
primeiro movimento. Assim como quem se distanciar de outrem, por um movimento, deste não fica
próximo, imediatamente com o cessar do movimento, mas é preciso que se aproxime, voltando, por um
movimento contrário.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Depois do ato do pecado, nada permanece de positivo
na alma, senão a disposição ou o hábito. Permanece contudo algo de privativo, a saber, a privação da
união com a luz divina.

RESPOSTA À SEGUNDA. — Desaparecido o obstáculo corpóreo, o corpo diáfano permanece na mesma
proximidade e relação anterior com o corpo que ilumina, e portanto imediatamente desaparece a
sombra. Ao passo que, removido o ato do pecado, não permanece a alma na mesma relação com Deus.
Portanto, a comparação não colhe.

RESPOSTA À TERCEIRA. — O ato do pecado distancia de Deus; e desse distanciamento resulta a falta de
lustre, assim como o movimento é provocado pela distância local. Por onde, assim como, cessando, o
movimento local, não fica eliminada a distância local; assim também a mácula não desaparece por haver
cessado o ato pecaminoso.