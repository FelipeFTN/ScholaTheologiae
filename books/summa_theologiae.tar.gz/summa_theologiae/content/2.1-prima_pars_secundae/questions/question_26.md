# Questão 26: Do amor.
Em seguida devemos tratar das paixões da alma em especial. E primeiro, das do concupiscível. Segundo,
das do irascível.
O primeiro estudo será tripartido. Assim, primeiro, trataremos do amor e do ódio. Segundo, da
concupiscência e da aversão. Terceiro, do prazer e da tristeza.
Sobre o amor há três pontos a se considerarem. Primeiro, do amor em si mesmo. Segundo, da causa do
amor. Terceiro, dos seus efeitos.
Sobre a primeira questão quatro artigos se discutem:

## Art. 1 — Se o amor pertence ao concupiscível.
(III Sent., dist. XXVI, q. 2, a . 1; dist. XXVII, q. 1, a . 2).
O primeiro discute-se assim. ― Parece que o amor não pertence ao concupiscível.

1. ― Pois, diz a Escritura (Sb 8, 2): A esta, i. é, à sabedoria, eu amei e requestei desde a minha mocidade.
Ora, o concupiscível, sendo parte do apetite sensitivo, não pode tender para a sabedoria, que não é
compreendida pelo sentido. Logo, o amor não pertence ao concupiscível.

2. Demais. ― Parece que o amor se identifica com as outras paixões, segundo Agostinho, que diz: O
amor, que deseja ardentemente possuir o objeto amado, é cobiça; o que já o possui e o goza é alegria; o
que foge do que se lhe opõe é temor; o que sente o mal sucedido é tristeza. Ora, nem todas as paixões
pertencem ao concupiscível; assim o temor, que entra na enumeração supra, pertence ao irascível.
Logo, não se pode dizer, absolutamente, que o amor pertence ao concupiscível.

3. Demais. ― Dionísio admite um certo amor natural. Ora, este mais parece pertencer às virtudes
naturais, próprias da alma vegetativa. Logo, o amor não pertence absolutamente, ao concupiscível.
Mas, em contrário, diz o Filósofo, que o amor pertence ao concupiscível.

SOLUÇÃO. ― O amor é algo próprio ao apetite, pois ambos tem por objeto o bem; por onde, qual a
diferença do apetite, tal a do amor. Ora, há uma espécie de apetite não conseqüente à apreensão do
apetente, mas à de outrem; e este se chama apetite natural. Pois os seres naturais desejam o que lhes
convém à natureza, não por apreensão própria, mas pela do instituído da natureza, como se disse no
livro primeiro. Outra espécie de apetite há porém conseqüente à apreensão do apetente, mas
necessária e não livremente, e tal é o apetite sensitivo, dos brutos, que contudo nos homens participa
algo da liberdade, enquanto obedece à razão. Enfim, há outro apetite que acompanha a apreensão do
apetente, conforme um juízo livre, e é o racional ou intelectivo chamado vontade.
Ora, em qualquer destes apetites, chama-se amor ao princípio do movimento tendente para o fim
amado. No apetite natural, o princípio desse movimento é a conaturalidade do apetente relativamente
ao objeto para que tende, e pode ser chamado amor natural, assim como a conaturalidade do corpo
pesado em relação ao lugar médio se dá em virtude da gravidade e pode ser denominado amor natural.
E semelhantemente, a coaptação do apetite sensitivo ou da vontade para algum bem, i. é, a
complacência no bem, chama-se amor sensitivo, ou intelectivo ou racional. Por onde, o amor sensitivo
pertence ao apetite sensitivo, como o amor intelectivo ao apetite intelectivo. E pertence ao
concupiscível, porque é assim denominado relativamente ao bem absoluto e não ao bem árduo, objeto
do irascível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O passo aduzido da Escritura se refere ao amor
intelectivo ou racional.

RESPOSTA À SEGUNDA. ― Causal e não essencialmente é que se chama ao amor temor, alegria, cobiça
e tristeza.

RESPOSTA À TERCEIRA. ― O amor natural tem sua sede não só nas potências da alma vegetativa, mas
em todas as potências da alma, bem como em todas as partes do corpo, e em universal em todas as
coisas; pois, como diz Dionísio, para todos o bem e o belo são agradáveis; e isso porque todas as coisas
tem conaturalidade com o que lhes é conveniente, conforme a natureza de cada uma.

## Art. 2 — Se o amor é paixão.
O segundo discute-se assim. ― Parece que o amor não é paixão.

1. ― Pois, nenhuma virtude é paixão. Ora, todo amor é virtude, de algum modo, como diz Dionísio.
Logo, o amor não é paixão.

2. Demais. ― O amor é uma união ou nexo, segundo Agostinho. Ora, união e nexo são antes relação que
paixão. Logo, o amor não é paixão.

3. Demais. ― Damasceno diz que a paixão é um certo movimento. Ora, o amor não implica o
movimento do apetite, que é o desejo, mas o princípio desse movimento. Logo, não é paixão.
Mas, em contrário, diz o Filósofo, que o amor é uma paixão.

SOLUÇÃO. ― A paixão é um efeito do agente no paciente. Ora, o agente natural produz no paciente
duplo efeito: dá-lhe a forma e o movimento conseqüente a esta; assim, a geração dá ao corpo a
gravidade e o movimento que a ela se segue; e a conaturalidade mesma, princípio do movimento para o
seu lugar conatural, por meio da gravidade, também pode de certo modo chamar-se amor natural. De
maneira que o apetível dá ao apetite, primeiro, uma certa coaptação para ele, que é uma como
complacência no apetível, donde resulta o movimento para este. Pois, o movimento apetitivo age
circularmente pelo processo seguinte: o apetível move o apetite, introduzindo-lhe, por assim dizer, na
intenção; e o apetite tende para o apetível, que deve ser realmente conseguido, de modo a o fim do
movimento coincidir com o princípio do mesmo. Por onde, a primeira imutação do apetite pelo apetível
se chama amor, que não é senão a complacência no apetível, da qual resulta o movimento para este,
que é o desejo; e por último vem o repouso, que se chama alegria. Assim pois o amor, consistindo numa
quase imutação do apetite pelo apetível, é manifesto que é paixão: propriamente, enquanto tem a sua
sede no concupiscível; comumente e em geral, enquanto está na vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Virtude, significando o princípio do movimento ou da
ação, Dionísio dá essa denominação ao amor enquanto princípio do movimento apetitivo.

RESPOSTA À SEGUNDA. ― A união é própria do amor enquanto que, pela complacência do apetite, o
amante se refere ao que ama, como a si mesmo ou a algo de si. Por onde, é claro que o amor não é a
relação mesma da união, antes, esta é conseqüência daquela. Por isso diz Dionísio, que o amor é uma
virtude unitiva; e o Filósofo que a união é um efeito do amor.

RESPOSTA À TERCEIRA. ― O amor embora não designe o movimento do apetite tendente para o
apetível, designa contudo o movimento do apetite em virtude do qual este sofre imutação do apetível,
de modo a lhe agradar a ele.

## Art. 3 — Se o amor é o mesmo que a dileção.
(I Sent., dist. X, Expos. Litt., III, dist. XXVII, q. 2, a . 1; De Div. Nom., cap. IV, lect IX).
O terceiro discute-se assim. ― Parece que o amor é o mesmo que a dileção.

1. ― Pois, diz Dionísio, que o amor está para a dileção como quatro para duas vezes dois e o retilíneo,
para o que tem linhas retas. Ora, estas expressões são idênticas. Logo, idênticos também hão-de ser o
amor e a dileção.

2. Demais. ― Os movimentos apetitivos diferem pelos seus objetos. Ora, o objeto da dileção e do amor
é o mesmo. Logo, aquela e este se identificam.

3. Demais. ― Se dileção e o amor diferem em algo, há-de ser sobretudo porque a dileção deve ser
tomada no bom sentido e o amor, no mau, segundo disseram alguns, conforme refere Agostinho. Ora,
de tal modo não diferem, pois, como diz Agostinho no mesmo passo, ambos esses vocábulos a Sagrada
Escritura os emprega tanto no bom como no mau sentido. Logo, o amor e a dileção não diferem, como
conclui no passo citado Agostinho, dizendo que não é uma coisa o amor e outra, a dileção.
Mas, em contrário, diz Dionísio, que certos Santos consideram mais divino o nome de amor que o de
dileção.

SOLUÇÃO. ― Há quatro nomes que se empregam para significarem de certo modo o mesmo: amor,
dileção, caridade e amizade, que contudo diferem no seguinte. A amizade, segundo o Filósofo, é um
quase hábito; o amor, porém, e a dileção empregam-se parasignificar ato ou paixão; ao passo
que caridade é usada em ambos esses sentidos. ― Estes três vocábulos todavia exprimem um mesmo
ato, mas diversamente. Assim, o mais geral deles é o amor, pois toda dileção ou caridade a ele se reduz,
mas não inversamente; assim, adileção acrescenta-lhe a eleição precedente, como o próprio nome o
indica. Por onde, a dileção não pertence ao concupiscível, mas exclusivamente à vontade, e só é própria
da natureza racional. A caridade por sua vez acrescenta ao amor uma certa perfeição, enquanto que,
como o nome por si o está indicando, temos em grande preço o que amamos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Dionísio se refere ao amor e à dileção enquanto
existentes no apetite intelectivo, e nesse caso identificam-se.

RESPOSTA À SEGUNDA. ― O objeto do amor é mais geral que o da dileção, porque tem maior extensão,
como se disse.

RESPOSTA À TERCEIRA. ― O amor não difere da dileção como difere o bem do mal, mas no sentido
supra-referido. Contudo, na potência intelectiva, um e outro se identificam, e nesse sentido é que
escreve Agostinho, no passo citado, acrescentando por isso logo depois: a vontade reta é o amor bom e,
a perversa, o mau. Como porém o amor, paixão do concupiscível, inclina muitos para o mal, isto deu
lugar a que certos introduzissem a diferença supra-mencionada.

RESPOSTA À QUARTA. ― Alguns disseram que, mesmo na própria vontade, o nome de amor é mais
divino que o de dileção, por implicar uma certa paixão, principalmente quando pertencente ao apetite
sensitivo; ao passo que a dileção pressupõe o juízo da razão. O homem porém pode tender a Deus pelo
amor, antes, passivamente, quase atraído pelo próprio Deus, do que levado pela razão própria; e isso
inclui a idéia de dileção, como dissemos. Por onde, mais divino que esta é o amor.

## Art. 4 — Se o amor se divide convenientemente em amor de amizade e de concupiscência.
(I, q. 60, a . 3; IIªº. q. 23, a . 1; II Sent., III, part. II, q. 3: III, dist. XXIX, a . 3; IV, dist. XLIX, q. 1, a . 2, qª 1, ad
3; De Virtut., q., q. 4, a . 3; De Div. Nom., cap. IV, Lect. IX, X).
O quarto discute-se assim. ― Parece que não é conveniente a divisão do amor em amor de amizade e
de concupiscência.

1. ― Pois, ao passo que o amor é uma paixão, a amizade é um hábito, como diz o Filósofo. Ora, o hábito
não pode ser parte em que se divide a paixão. Logo, não é conveniente dividir-se o amor em amor de
concupiscência e de amizade.

2. Demais. ― Não podem ser partes de uma divisão coisas que pertencem a uma mesma classificação, o
que não se dá, p. ex., com as noções de homem e de animal. Ora, a concupiscência entra na mesma
classificação que o amor, pois é como ele uma paixão. Logo, não pode este ser parte da concupiscência.

3. Demais. ― Segundo o Filósofo, há três espécies de amizade: a útil, a deleitável e a honesta. Ora, a útil
e a deleitável se incluem na concupiscência: Logo, esta não deve se dividir por oposição com a amizade.
Mas, em contrário. ― Dizemos que ama uma coisa quem a deseja; assim diz-se que ama o vinho quem
por doce, o deseja, como se vê no Filósofo. Ora, como diz o mesmo, não temos amizade pelo vinho ou
coisas semelhantes. Logo, uma coisa é o amor de concupiscência e outra, o de amizade.

SOLUÇÃO. ― Como diz o Filósofo, amar é querer bem a alguém. Assim pois o movimento do amor
tende para um duplo termo: o bem que queremos a alguém, seja esse a nossa própria pessoa ou a de
outrem; e a pessoa a quem o queremos. Ora, ao bem que queremos para outrem diz respeito o amor de
concupiscência; a pessoa a quem o queremos, o amor de amizade.
Esta divisão porém é por anterioridade e posterioridade. Pois, a quem amamos por amor de amizade
amamos absolutamente e em si mesmo; o que porém amamos por amor de concupiscência o amamos
para outrem e não absolutamente e em si mesmo. Ora, como o ente por si e em absoluto é o que existe
por si; e o ente relativo é o que existe em outro; assim o bem conversível no ser é o que absolutamente
tem a bondade; ao passo que o bem de outrem é um bem relativo. Por conseqüência, o amor pelo qual
amamos alguma coisa como boa em si mesma é o amor absoluto; enquanto que aquele pelo qual
amamos algum bem, para outrem, é o amor relativo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O amor não se divide em amizade e concupiscência, mas
em amor de amizade e de concupiscência. Assim, chamamos propriamente amigo àquele a quem
queremos algum bem; e dizemos que desejamos o que queremos para nós.
Donde se deduz clara A RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. ― Pela amizade útil e deleitável, queremos, por certo, algum bem ao amigo, e
nisso entra a noção de amizade. Mas pelo referirmos, ulteriormente, esse bem à nossa deleitação ou
utilidade, a amizade útil e a deleitável, enquanto implicam o amor de concupiscência, perdem o caráter
da verdadeira amizade.