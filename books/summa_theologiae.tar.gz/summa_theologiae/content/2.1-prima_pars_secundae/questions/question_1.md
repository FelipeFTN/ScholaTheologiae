# Questão 1: Do fim último em comum.
Deve-se tratar aqui primeiro, do fim último da vida humana. Em seguida, dos meios pelos quais o
homem pode alcançar esse fim ou dele desviar-se; pois, é do fim que se deduz a natureza daquilo que se
a ele ordena.
Ora, como se admite que o fim último da vida humana é a beatitude, necessário é, em primeiro lugar,
tratar do fim último, em comum, e depois, da beatitude.
Sobre o primeiro ponto oito artigos se discutem:

## Art. 1 — Se convém ao homem agir para um fim.
(infra, a . 2; q. 6, a . 1; III cont. Gent., cap. II).
O primeiro artigo discute-se assim. — Parece que não convém ao homem agir para um fim.

1. — Pois, o que tem naturalmente prioridade é a causa. Ora, o fim, como a próprio palavra o indica, é
por natureza o último. Logo, o fim não exerce a função de causa. Ora, o homem age para a causa da
ação, pois, a preposição para designa função causal. Logo, não convém ao homem agir para um fim.

2. Demais. — O fim que é último não existe para outro. Ora, certas ações constituem um fim último,
como se vê no Filósofo. Logo, nem tudo o homem faz para um fim.

3. Demais. — O homem age para um fim quando delibera. Ora, praticamos muitos atos sem deliberação
e sem mesmo, muitas vezes, neles pensar; assim, enquanto pensamos em outras cousas, movemos o pé
ou a mão, ou esfregamos a barba. Logo, nem tudo o homem faz para um fim.
Mas, em contrário. — Tudo o que pertence a um gênero deriva do princípio desse gênero. Ora, como se
vê claramente no Filósofo, o fim é o principio das operações do homem. Logo, a este convém fazer tudo
para um fim.

SOLUÇÃO. — Das ações feitas pelo homem só se chamam propriamente humanas as que lhe são
próprias, enquanto homem. Ora, este difere das criaturas irracionais, por ser senhor dos seus atos. Por
onde, chamam-se propriamente ações humanas só aquelas de que o homem é senhor. Ora, senhor das
suas ações o homem o é pela razão e pela vontade, sendo por isso o livre arbítrio chamado à faculdade
da vontade e da razão. Portanto, chamam-se ações propriamente humanas as procedentes da vontade
deliberada; e se há outras que convêm ao homem, essas podem, por certo, chamar-se ações do homem,
mas não propriamente humanas, pois não procedem dele como tal. Ora, é manifesto que todas as ações
procedentes de uma potência são por esta causadas, quanto à essência do objeto mesmo delas. E como
o objeto da vontade é o fim e o bem, necessário é tendam todas as ações humanas para um fim.

DONDE A RESPOSTA A PRIMEIRA OBJEÇÃO. — Último na execução, o fim é contudo o primeiro na
intenção do agente, e por isso tem a natureza de causa.

RESPOSTA À SEGUNDA. — Qualquer ação humana que seja fim último há de necessariamente ser
voluntária; do contrário não seria humana, como já se disse. Ora, em duplo sentido uma ação é
chamada voluntária. Por ser imperada pela vontade, como andar ou falar; ou por ser dela decorrente,
como o querer, em si mesmo. Ora, é impossível que o ato mesmo decorrente da vontade seja fim
último. Pois, o objeto da vontade é fim como o da visão é cor. Por onde, assim como é impossível que o
primeiro visível seja a visão mesma, porque toda visão se refere a algum objeto visível; assim também é
impossível que o primeiro desejável, que é fim, seja o querer em si mesmo. Donde resulta que se
alguma ação humana for fim último, há de ser imperada pela vontade. E então, em tal caso, há de haver
alguma ação do homem — ao menos, o próprio querer, que seja para um fim. Logo, faça o homem, seja
o que for, é verdade dizer-se que age para um fim, mesmo operando um ato que seja o último fim.

RESPOSTA À TERCEIRA. — Tais ações não são propriamente humanas, por não procederem da
deliberação da razão, princípio próprio dos atos humanos. E por isso têm certamente um fim imaginado,
não, porém, estabelecido pela razão.

## Art. 2 — Se agir para um fim é próprio da natureza racional.
(Infra. q. 12, a . 5; II Cont. Gent., cap. XXIII, cap. I, II, XVI; De Pot., q. 1 a .5; q. 3, a . 15; V Metaph., lect.

XVI).
O segundo discute-se assim. — Parece que agir para um fim é próprio da natureza racional.

1. — Pois o homem, a quem é próprio agir para um fim, não age nunca para um fim desconhecido. Ora,
há muitos seres que não conhecem o fim, ou porque carecem absolutamente de conhecimento, como
as criaturas insensíveis, ou porque, como os brutos, não apreendem a noção de fim. Donde se conclui
que é próprio da natureza racional agir para um fim.

2. — Demais. Agir para um fim é ordenar para este a ação própria, o que é obra da razão, e portanto não
convém aos seres que dela carecem.

3. — Demais. O bem e o fim são o objeto da vontade. Ora, a vontade está na razão, como diz Aristóteles.
Logo, agir para um fim é próprio só da natureza racional.
Mas, em contrário, o Filosofo prova que não só o intelecto, mas também a natureza, age para um fim.

SOLUÇÃO. — Todos os agentes agem necessariamente para um fim. Ora, eliminada a primeira, de várias
causas ordenadas umas para as outras, necessário é sejam também essas outras eliminadas. Ora, a
primeira de todas as causas é a final; pois, a matéria não busca a forma senão quando movida pelo
agente, nada passando por si da potência para o ato. O agente porém só move visando um fim, pois se
não fosse determinado a certo efeito não produziria antes um de preferência a outro. Ora, para produzir
um determinado efeito, necessário é seja determinado a algo certo como natureza de fim. E esta
determinação, operada em a natureza racional pelo apetite racional chamado vontade, o é, nos outros
seres, pela inclinação natural denominada apetite natural.
Deve-se contudo considerar, que um ser tende para um fim pela sua ação ou pelo seu movimento, de
duplo modo: movendo-se por si mesmo para o fim, como o homem; ou movido por outro, ao modo da
seta tendendo para um fim determinado, movida pelo sagitante, que dirige para ele a sua ação. Por
onde, os seres dotados de razão a si mesmos se movem para o fim, por terem o domínio dos seus atos
pelo livre arbítrio, faculdade da vontade e da razão. Ao passo que os privados dela tendem ao fim por
inclinação natural, como que movidos por outro e não por si mesmos, por não conhecerem a noção de
fim. E portanto, não podem ordenar nada para um fim, mas somente são para este ordenados por
outro, pois toda a natureza está para Deus como o instrumento para o agente principal, conforme já se
estabeleceu.
Por onde, é próprio da natureza racional tender para o fim, como conduzindo-se ou dirigindo-se para
ele. Ao passo que a natureza irracional, como levada ou conduzida por outro; quer seja o fim
apreendido, como pelos brutos dotados de conhecimento, quer não apreendido, como se dá com os
seres totalmente dele privados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem conhece o fim quando age para ele, por si
mesmo; mas quando levado ou conduzido por outro. p.ex., quando age por império de outrem, ou
quando movido por impulso de outrem, não é necessário conheça o fim. E isso se dá com as criaturas
irracionais.

RESPOSTA À SEGUNDA. — Ordenar para o fim é próprio de quem por si mesmo se dirige para ele. Ao
passo que ser ordenado para o fim é próprio de ser, que para o mesmo é levado por outro; o que pode
convir à natureza irracional, mas proveniente de um ser dotado de razão.

RESPOSTA À TERCEIRA. — O objeto da vontade é o fim e o bem universais. Por onde, por não serem
capazes de apreender o universal, os seres privados de razão e de intelecto não podem ter vontade,
senão apenas o apetite natural ou sensitivo determinado a um bem particular. Ora, é claro que as
causas particulares são movidas pela causa universal; assim, o governador da república, que visa o bem
comum, move pelo seu império todas as funções particulares dela. Por onde e necessariamente, todos
os seres privados de razão hão-de ser movidos, para fins particulares, por alguma vontade racional, que
alcance o bem universal e que é a vontade divina.

## Art. 3 — Se os atos humanos não são especificados pelo fim.
(Infra, q. 18, a . 6: q. 72, ª 3: II Sent. Dist. XL. A . 1; De Virtut., q. 1, ª 2, ad 3; q. 2, a . 3).
O terceiro discute-se assim. — Parece que os atos humanos não são especificados pelo fim.

1. — Pois, o fim é causa extrínseca. Ora, todo especificado o é por algum princípio intrínseco. Logo, os
atos humanos não se especificam pelo fim.

2. Demais. — O que dá a espécie tem prioridade. Ora, o fim só existe posteriormente. Logo os atos
humanos não se especificam pelo fim.

3. Demais. — O que é uno não pode caber senão em uma espécie. Ora, dá-se que um ato
numericamente uno, é ordenado para fins diversos. Logo, o fim não especifica os atos humanos.
Mas, em contrário, diz Agostinho: Sendo o fim culpável ou louvável, louváveis ou culpáveis serão as
nossas obras.

SOLUÇÃO. — Tudo o que é especificado o é pelo ato e não pela potência. Assim, os compostos de
matéria e forma são especificados pelas formas próprias. E assim também se deve pensar a respeito dos
movimentos próprios. Pois, distinguindo-se de certo modo o movimento pela ação e pela paixão, uma e
outra se especificam pelo ato: esta, pelo ato, princípio do agir; aquela pelo que é o termo do
movimento. Assim, a calefação — ato não é mais do que uma certa moção procedente do calor; e a
calefação — paixão, do que o movimento para o calor. E a definição dá a razão da espécie.
Ora, de um e outro modo, os atos humanos, considerados, quer como ações, quer como paixões,
especificam-se pelo fim. Pois, esses atos podem ser considerados de ambos os modos, porque o homem
se move a si mesmo e é por si mesmo movido. Porém como já se disse, chamam-se humanos os atos
procedentes da vontade deliberada. Ora, o objeto da vontade é o bem e o fim. Por onde é manifesto,
que o princípio dos atos humanos, como tais, é o fim; e semelhantemente, também é o termo deles.
Pois, um ato humano termina naquilo que a vontade visa, como fim; assim como nos agentes naturais a
forma do gerado é conforme a do gerador. E porque, como diz Ambrósio, os costumes propriamente
são humanos, os atos morais especificam-se propriamente pelo fim, pois, atos morais e atos humanos
são o mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O fim não é, de nenhum modo, algo de extrínseco ao
ato, porque está para este como princípio ou termo. Ora, é da essência mesma do ato proceder de um
princípio, quanto à ação e tender para um termo, quanto à paixão.

RESPOSTA À SEGUNDA. — O fim sendo, intencionalmente, primeiro, como já se disse, pertence à
vontade; e assim especifica o ato humano ou moral.

RESPOSTA À TERCEIRA. — O ato numericamente o mesmo, como procedente, uma vez, do agente, só se
ordena a um fim próximo que o especifica; pode porém ordenar-se a vários fins remotos, dos quais um é
fim do outro. É contudo possível seja um ato uno, quanto à natureza específica, ordenado a diversos fins
da vontade. Assim o ato uno, quanto à natureza específica, de matar um homem, pode ordenar-se ao
fim de conservar a justiça e o de satisfazer à ira. Donde, segundo a espécie moral, serão diversos os
atos; pois, um será virtuoso e outro vicioso. Pois, o movimento não se especifica pelo termo acidental
mas só pelo termo em si. Ora, fins morais são acidentais ao que é natural; e inversamente, a essência do
fim natural é acidental ao moral. Por onde, nada impede que atos idênticos pela natureza específica
sejam diversos pela espécie moral, e inversamente.

## Art. 4 — Se há um fim último da vida humana, ou se, nos fins, se deve proceder ao infinito.
(II Metaph., lect. IV; I Ethic., lect II).
O quarto discute-se assim. — Parece que não há nenhum fim último da vida humana, mas que em
relação aos fins, se deve proceder ao infinito.

1. — Pois, o bem é, por essência, difusivo de si, como se vê claramente em Dionísio. Se portanto, o que
procede de um bem é, por sua vez, bem, necessário é seja um difusivo do outro, e então a procedência
vai ao infinito. Ora, o bem exerce o papel de fim. Logo, procede-se, quanto aos fins, ao infinito.

2. Demais. — O racional pode multiplicar-se ao infinito. Assim, as quantidades matemáticas aumentam
ao infinito; as espécies de números são infinitas porque, dado qualquer número, a razão pode pensar
um maior. Ora, o desejo do fim resulta da apreensão da razão.

3. Demais. — O bem e o fim é o objeto da vontade. Ora, esta pode refletir infinitas vezes sobre si
mesma; pois, posso querer alguma coisa, e querer que a queira, e assim ao infinito. Logo, em relação
aos fins da vontade humana, procede-se ao infinito, sem nenhum fim último.
Mas, em contrário, diz o Filósofo, os que a levam ao infinito aniquilam a natureza do bem. Ora, este
desempenha o papel de fim. Logo, vai contra a essência do fim proceder-se ao infinito, e é portanto
necessário admitir-se um último fim.

SOLUÇÃO. — Propriamente falando é impossível, em relação aos fins, proceder-se ao infinito, por
qualquer lado que seja. — Pois, em coisas que constituem por si mesmas uma ordem mútua,
necessariamente, removida a primeira, removidas serão as que dela dependem. Por onde, como o prova
o Filósofo, não é possível, nas causas motoras, proceder ao infinito, pois então deixaria de existir o
primeiro motor; e subtraído este, os outros, que só movem enquanto movidos por ele, não podem
mover. — Ora, há dupla ordem de fins: a da intenção e a da execução, e em ambas é necessário haver
algo de primordial. Pois, o primordial, na ordem da intenção, é como o princípio motor do apetite,
eliminado o qual, o apetite por nada seria movido. E quanto à execução, é primordial o princípio que faz
a operação começar, subtraído o qual, nada começaria a operar nada. Ora, o princípio da intenção é o
último fim; e o da execução é o primeiro dos meios conducentes ao fim. Por onde, por nenhum lado é
possível proceder ao infinito; pois, sem último fim nada seria desejado, nenhuma ação terminaria e nem
mesmo descansaria a intenção do agente. E se não houvesse nenhum meio primeiro, conducente ao
fim, ninguém começaria a fazer nada e nem terminaria o conselho, que procederia ao infinito.
Porém, nada impede que coisas sem nenhuma ordem mútua, por si mesmas, mas só por acidente
conjugadas, sejam infinitas; pois, causas acidentais são indeterminadas. E é deste modo que os fins, e os
meios a eles conducentes, podem ter infinidade acidental.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É da essência do bem ser difusivo de si, mas não,
proceder de outro. Por onde, tendo ele a natureza de fim, e sendo o primeiro bem o último fim, a
objeção não prova que não o seja, mas que, suposto o primeiro fim, se pode proceder ao infinito,
inferiormente, em relação aos meios. E tal se daria, levando-se em conta só a virtude infinita do
primeiro bem. Mas a difusão deste sendo segundo o intelecto, pela qual proflui nos causados, segundo
uma certa forma, há uma certa forma, há um certo modo inerente ao efluxo dos bens, do primeiro bem,
de cuja virtude difusiva eles participam. Por onde, a difusão deles não procede ao infinito, mas, como
diz a Escritura (Sb 9), Deus dispôs todas as coisas em número, peso e medida.

RESPOSTA À SEGUNDA. — No que é por si, a razão parte de princípios naturalmente conhecidos e
avança para um certo termo. Por onde, como o prova o Filósofo, nas demonstrações não há processo ao
infinito, porque nelas se atende a uma ordem de coisas mutuamente conexas por si mesmas e não, por
acidente. Onde porém a conexão é acidental nada impede a razão proceder ao infinito. Ora, é acidental,
à quantidade ou ao número preexistente, como tal, que se lhe acrescente uma quantidade ou unidade.
Por onde, em tal caso, nada impede proceder-se ao infinito.

RESPOSTA À TERCEIRA. — Essa multiplicação dos atos da vontade reflexa sobre si mesma é acidental
em relação à ordem dos fins. E o evidencia o fato de refletir a vontade sobre si mesma,
indiferentemente, uma ou várias vezes, em relação ao mesmo ato.

## Art. 5 — Se é possível à vontade de um mesmo homem buscar simultaneamente vários fins últimos.
O quinto discute-se assim. — Parece impossível à vontade de um mesmo homem buscar
simultaneamente vários fins últimos.

1. — Pois, diz Agostinho, que certos fizeram consistir o último fim do homem em quatro coisas: no
prazer, no repouso, nos bens da natureza e na virtude, que constituem manifestamente pluralidade.
Logo, o mesmo homem pode fazer consistir em muitas coisas o fim último da sua vontade.

2. Demais. — Onde não há mútuas oposições não há mútuas exclusões. Ora, há na realidade muitas
coisas que mutuamente não se opõe. Logo, admitido um fim último da vontade, nem por isso ficam
excluídos outros.

3. Demais. — Nem por ter posto em alguma coisa o seu último fim, a vontade perde sua livre potência.
Mas antes de havê-lo posto, p. ex., no prazer, podia tê-lo posto em outra coisa, p. ex., nas riquezas.
Logo, também, depois de alguém ter feito do prazer o último fim da sua vontade, pode
simultaneamente fazê-lo consistir nas riquezas. E, portanto, é possível à vontade de um mesmo homem
buscar diversos fins últimos.
Mas, em contrário. — O que constitui, como fim último, o repouso de alguém, domina-lhe o afeto,
porque daquele lhe decorrem as regras de toda a vida. Por isso, na Escritura (Fp 3, 19) se diz que dos
gulosos Deus é o ventre, por constituírem o fim último nos prazeres do ventre. Mas, segundo Mateus
(Mt 6, 24), ninguém pode servir a dois senhores, i. é, não ordenados um para o outro. Logo, é impossível
ter um mesmo homem vários fins últimos não mutuamente ordenados.

SOLUÇÃO. — É impossível à vontade de um mesmo homem tender simultaneamente para diversos fins
últimos. — E pode-se dar disso tríplice razão.
A primeira é que, buscando cada ser a sua perfeição, busca-a como fim último, como bem perfeito e
completivo de si próprio. Por isso, diz Agostinho: Por fim do bem não entendemos um fim que o esgote,
até que não mais exista, mas que o leve até a plenitude da perfeição. Forçoso é, pois, que o fim último
satisfaça totalmente o desejo do homem, de modo que, além dele, nada mais se possa desejar. Ora, tal
não se daria se fosse necessário algo de estranho à perfeição desse fim. Por onde, não é possível o
desejo tender para dois fins, como se fossem ambos o bem perfeito dele.
A segunda razão é que, assim como, no processo da razão, o princípio é o que é naturalmente
conhecido, assim, no do apetite racional ou vontade, necessariamente há de ser princípio o que é
naturalmente desejado. Ora, este tem de ser um só, porque a natureza não tende senão para um termo.
Mas, o princípio, no processo do apetite racional é o último fim. Por onde, necessariamente, na
denominação de último se contém uma só tendência da vontade.
A terceira razão é: sendo as ações voluntárias especificadas pelo fim, como já se estabeleceu, necessário
é derivar-se do fim último, que é comum, a noção do gênero, assim como os seres naturais tem o
gênero fundado na razão formal comum. Ora, sendo tudo o que a vontade deseja, como tal, de um
mesmo gênero, forçosamente há de ser uno o último fim. E tanto mais quanto, em qualquer gênero, há
um primeiro princípio, e o fim último exerce tal função, como já se disse.
Ora, o fim último do homem, em geral, está para todo o gênero humano, assim como o fim último de
um determinado homem está para esse homem. Por onde, assim como todos os homens têm um fim
último, naturalmente, assim também necessário é seja, à vontade de um determinado homem,
estatuído um fim último.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Toda essa pluralidade é tomada pela essência do bem
perfeito uno, dela constituído, segundo os que em tais coisas põem o último fim.

RESPOSTA À SEGUNDA. — Embora se possam admitir muitas coisas sem oposição mútua, contudo se
opõe ao bem perfeito haver algo, fora dele, constitutivo da perfeição de um ser.

RESPOSTA À TERCEIRA. — Não está no poder da vontade fazer os opostos existirem simultaneamente, o
que se daria se ela tendesse para vários fins últimos disparatados, como do sobredito se colhe.

## Art. 6 — Se tudo o que o homem quer é por causa do fim último.
(IV Sent., dist. XLIV, q. 1, a . 3, q ª 4; I Cont. Gent., cap. CI).
O sexto discute-se assim. — Parece que nem tudo o homem quer por causa do fim último.

1. — Pois, as coisas ordenadas ao último fim são consideradas sérias, sendo como que úteis. Ora, destas
distinguem-se as jocosas. Logo, o que o homem faz jocosamente não o ordena ao último fim.

2. Demais. — Diz o Filósofo, que as ciências especulativas são cultivadas por si mesmas. Todavia, não se
pode dizer que qualquer delas seja o último fim. Logo, nem tudo o que o homem deseja é por causa do
último fim.

3. Demais — Quem ordena algo para algum fim, neste pensa, mas, nem sempre o homem pensa no
último fim, em tudo o que deseja ou faz. Logo, nem tudo ele deseja ou faz por causa de tal fim.
Mas, em contrário, diz Agostinho: O fim do nosso bem é a causa de serem amadas as outras causas;
porém esse fim o é por si mesmo.

SOLUÇÃO. — Tudo quando o homem deseja há de forçosamente desejar por causa do último fim. E isso
ressalta de dupla razão. — A primeira é que tudo quanto o homem deseja está compreendido em a
noção de bem. E se não é desejado como bem perfeito, que é o último fim, há de necessariamente sê-lo
como tendendo para esse bem; pois sempre o que é incoativo se ordena para a própria consumação,
como é patente tanto nas obras da natureza como nas da arte. E assim, toda perfeição incoativa se
ordena à perfeição consumada, que é o último fim. — A segunda é que o último fim está para a moção
do apetite como o primeiro motor para as outras moções. Ora, é manifesto que as causas segundas
motoras não movem senão enquanto movidas pelo primeiro motor. Por onde, os apetíveis secundários
não movem o desejo senão em ordem ao apetível primário, que é o último fim.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As ações deleitáveis não se ordenam a nenhum fim
extrínseco, mas somente ao bem daquele mesmo que se diverte, enquanto causam deleite ou descanso.
Ao passo que o bem consumado do homem é o seu último fim.
E semelhantemente se deve RESPONDER À SEGUNDA OBJEÇÃO, quanto à ciência especulativa,
desejada como um certo bem do especulador e compreendida no bem completo e perfeito, que é o
último fim.

RESPOSTA À TERCEIRA. — Não é necessário pensarmos sempre no último fim, todas as vezes que
desejamos ou obramos alguma coisa. Pois, a virtude da primeira intenção, referida a tal fim, perdura no
desejo de qualquer coisa, embora não se pense atualmente no último fim. Do mesmo modo que não é
necessário quem anda por um caminho pensar no fim a cada passada.

## Art. 7 — Se há um só fim último para todos os homens.
(Supra, a. 5; Ethic., lect. IX).
O sétimo discute-se assim.— Parece que não há um só fim último para todos os homens.

1. — Pois, parece que o último e soberano fim do homem é o bem incomutável. Ora, certos dele se
desviam, pecando. Logo, não há só um fim último para todos os homens.

2. Demais. — A vida total do homem se regula pelo último fim. Se, pois, este fosse só um para todos os
homens resultaria que eles não teriam intentos diversos no viver, o que patentemente é falso.

3. Demais. — O fim é o termo da ação e as ações se referem ao singular. Ora, os homens embora
convenham pela natureza específica, diferem contudo pelo que respeita ao indivíduo. Logo, não há um
só fim para todos os homens.
Mas, em contrário, diz Agostinho: todos os homens convêm no desejar o último fim, que é a felicidade.

SOLUÇÃO. — Sob duplo aspecto se pode considerar o último fim: quanto à sua essência e quanto ao seu
conteúdo. — Ora, quanto à essência todos convêm no desejar o fim último; pois todos desejam alcançar
a própria perfeição, que é a essência do fim último, como já se disse. — Mas quanto ao conteúdo, nem
todos os homens nele convêm. Pois, uns desejam as riquezas, como o bem perfeito: outros porém, o
prazer: outros, por fim, outras coisas. Assim como o doce é agradável a todo gosto, mas para este a mais
agradável é a doçura do vinho, para aqueles, a do mel ou qualquer outra. Mas necessariamente, a mais
deleitável há de ser a doçura em que mais se deleita quem tem o gosto perfeito. E semelhantemente é
necessário seja completíssimo o bem, que deseja como último fim quem tem o afeto bem disposto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os que pecam se transviam do em que verdadeiramente
consiste a essência do último fim; não porém, da intenção mesma para este, a qual falsamente os leva
para outras coisas.

RESPOSTA À SEGUNDA. — Os homens têm diversos intentos na vida, por causa das coisas diversas em
que buscam a essência do sumo bem.

RESPOSTA À TERCEIRA. — Embora as ações se refiram ao singular, contudo é-lhes o princípio primeiro
de agir a natureza, que tende para um termo, como já se disse.

## Art. 8 — Se todos os outros seres têm o mesmo fim último do homem.
(1, q. 103, a . 2; II Sent., dist. XXXVIII, a . 1, 2; Cont. Gent., cap. XVII, XXV; Verit., q. 5, a . 6, ad 4).
O oitavo discute-se assim. — Parece que todos os outros seres têm o mesmo fim último que o
homem.

1. — Pois, o fim corresponde ao princípio Ora, Deus, princípio dos homens, é também o de todos os
demais seres. Logo, todos estes têm o mesmo fim do homem.

2. Demais. — Como diz Dionísio, Deus converte tudo para si, como fim último. Ora, ele é o fim último do
homem porque só dele é que se há de fruir. Logo, todos os outros seres têm o mesmo fim último do
homem.

3. Demais. — O fim último do homem é objeto da vontade. Ora, o objeto desta é o bem universal, fim
de todos os seres. Logo, necessário é tenham todos eles o mesmo fim último que o homem.
Mas, em contrário, o fim último dos homens é a beatitude, que todos desejam, como diz Agostinho. Ora,
não está nos animais desprovidos de razão o serem felizes, como diz ainda Agostinho. Logo, todos os
outros seres não têm o mesmo fim último que o homem.

SOLUÇÃO. — No dizer do Filósofo, emprega-se o vocábulo fim em dupla acepção: como o porque se
quer e como o pelo que se quer; i. é, como a causa mesma, cuja natureza é boa, e como o uso ou a
aquisição dessa coisa. Assim, se dissermos que o fim do movimento do corpo grave é o lugar inferior,
como coisa, ou o estar nesse lugar, como uso; e o fim do avarento é o dinheiro, como coisa, ou a posse
dele, como uso. — Se, pois, considerarmos o último fim do homem, relativamente à coisa mesma que é
o fim, então todos os outros seres têm o mesmo fim que o homem, pois Deus é o fim último tanto dele
como deles. — Se porém considerarmos o último fim do homem quanto à consecução, então, as
criaturas irracionais não têm o mesmo fim que o homem. Pois, este e as demais criaturas racionais
obtêm o último fim conhecendo e amando a Deus; o que não se dá com as outras criaturas que
alcançam o fim último, enquanto participam de alguma semelhança de Deus, na medida em que
existem, vivem, ou ainda, conhecem.
Donde se deduzem claras as RESPOSTAS ÀS OBJEÇÕES. — Pois, beatitude significa obtenção do último
fim.