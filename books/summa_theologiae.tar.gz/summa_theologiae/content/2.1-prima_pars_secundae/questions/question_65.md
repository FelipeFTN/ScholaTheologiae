# Questão 65: Da conexão das virtudes.
Em seguida devemos tratar da conexão das virtudes. E sobre esta questão, cinco artigos se discutem:

## Art. 1 — Se as virtudes morais são necessariamente conexas.
(III Sent., dist. XXXVI, a, 1 ; IV, dist. XXXIII, q. 3, a, 2, ad 6 :De Virtut., q. 5. a. 2; Quodl., XII, q, 15, a, 1 ; VI
Ethic., lect, XI).
O primeiro discute-se assim. — Parece que as virtudes morais não são necessariamente conexas.

1. — Pois, as virtudes morais são às vezes causadas pelo exercício dos atos, como já se provou. Ora, o
homem pode exercitar os atos de uma virtude sem exercitar os de outra. Logo, pode possuir uma
virtude moral sem outra.

2. Demais. — A magnificência e a magnanimidade são virtudes morais. Ora, podemos possuir as outras
virtudes morais sem possuirmos essas duas; pois, diz o Filósofo, que o pobre não pode ser magnífico,
embora possa possuir outras virtudes; e que quem é digno de pouco e com isso se dignifica é sóbrio,
mas não magnânimo. Logo, as virtudes morais não são conexas.

3. Demais. — Assim como as virtudes morais aperfeiçoam a parte apetitiva da alma, assim as
intelectuais, a intelectiva. Ora, aquelas não são conexas, pois podemos ter uma ciência sem ter outra.
Logo, estas também o não são.

4. Demais. — Se as virtudes morais são conexas só o poderão sê-lo pela prudência; ora, isto não basta
para a conexão das virtudes morais. Pois, vemos que um pode ser prudente em relação a atos que
pertencem a uma virtude, sem o ser em relação a atos de outra, assim como pode ter a arte relativa a
certas produções, sem ter a relativa a outras. Ora, a prudência é a razão reta que nos guia no que
devemos fazer. Logo: não é necessário sejam conexas às virtudes morais.
Mas, em contrário, diz Ambrósio: As virtudes são de tal modo conexas e concatenadas entre si, que
quem possui uma possui muitas. E Agostinho também diz: as virtudes existentes na alma humana de
nenhum modo estão separadas entre si. E Gregório: sem as outras, uma virtude ou é absolutamente
nula, ou imperfeita. E Túlio: Se confessas que não tens uma virtude, necessariamente não terás
nenhuma.

SOLUÇÃO. — A virtude moral pode ser considerada perfeita ou imperfeita. Esta — como a temperança
ou a fortaleza — não é mais do que uma inclinação nossa, oriunda da natureza ou do costume, para
fazer alguma obra genericamente boa. E nesta acepção as virtudes morais não são conexas; pois, vemos
que certos, por compleição natural ou por qualquer costume, são prontos para as ações liberais, sem o
serem para o exercício da castidade. Por outro lado, a virtude moral perfeita é um hábito que inclina a
fazer bem obras boas. E neste sentido devemos dizer que, como quase todos pensam, as virtudes
morais são conexas. E disto há dupla razão, enquanto que certos distinguem diversamente as virtudes
cardeais. — Assim, como já dissemos, uns as distinguem segundo certas condições gerais das virtudes e
de modo que a discrição pertence à prudência; a retidão, à justiça; a moderação, à temperança; a
firmeza de ânimo, à fortaleza, seja qual for à matéria relativamente à qual sejam consideradas. Ora, a
esta luz, aparece manifestamente a razão da conexão; pois, a firmeza não merece o louvor devido à
virtude se não for acompanhada da moderação, da retidão ou da discrição; e o mesmo se dá com as
outras virtudes. E é esta razão de conexão que assinala Gregório, dizendo:as virtudes, como tais,
estando separadas, não podem ser perfeitas, porque nem a prudência é verdadeira que não for justa,
temperante e forte. E o mesmo diz das outras virtudes, o que concorda com a razão semelhante que dá
Agostinho.
Outros porém distinguem as virtudes em questão pelas suas matérias; e neste sentido, Aristóteles dá-
lhes a razão da conexão. Pois, como já dissemos, nenhuma virtude moral pode existir sem a prudência.
Porque é próprio da virtude moral, que é um hábito eletivo, fazer uma eleição reta; e para isso não
basta só a inclinação para o fim devido, efetivada diretamente pelo hábito da virtude moral, mas é
também preciso escolhermos diretamente os meios; e isto se realiza pela prudência, que aconselha,
julga e preceitua sobre eles. E semelhantemente, a prudência não a podemos ter sem que tenhamos as
virtudes morais; pois, ela é a razão reta do que devemos fazer, e procede dos fins das ações, como de
princípios, em relação aos quais nos avimos retamente por meio das virtudes morais. Por onde, assim
como a ciência especulativa não pode ser alcançada sem o intelecto dos princípios, assim também a
prudência não o pode sem as virtudes morais. Donde manifestamente resulta que elas são conexas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Das virtudes morais, umas aperfeiçoam o homem, no
seu estado geral, i. é, relativamente ao que é comumente praticado no decurso de toda a vida humana.
E por isso é necessário que ele se exercite simultaneamente nas matérias de todas as virtudes morais; e
se, obrando bem, exercitá-las todas, adquirirá os hábitos de todas. Se porém, obrando bem, exercitar-se
em relação a uma só matéria, p. ex., a ira — e não, a outra, — p. ex., a concupiscência — adquirirá,
certo, o hábito de refrear aquela, o que, entretanto, não realizará a noção de virtude, pela falta de
prudência no que respeita à concupiscência; assim como as inclinações naturais também não realizarão
a noção perfeita de virtude, faltando a prudência.
Há outras virtudes morais, porém, que aperfeiçoam o homem, elevando-o a um estado eminente, como
a magnificência e a magnanimidade. E como o exercício nas matérias destas virtudes não é da alçada de
qualquer, comumente, pode alguém ter as outras virtudes morais, sem ter atualmente os hábitos dessas
virtudes, se nos referimos às virtudes adquiridas. Se porém adquirir as outras virtudes tê-las-á a estas
em potência próxima. Assim, quem pelo exercício, alcançou a liberalidade em relação a doações e
gastos pequenos, adquirirá, com pequeno exercício, o hábito da magnificência, se lhe sobrevier
abundância de dinheiro; do mesmo modo que o geômetra, com pouco estudo, adquire a ciência de uma
conclusão na qual nunca pensou. Pois, consideramos como tendo uma coisa quem a tem com presteza,
conforme aquilo do Filósofo: O que falta por pouco podemos considerar como quase não faltando.
Donde consta com clareza a RESPOSTA À SEGUNDA OBJEÇÃO. RESPOSTA À TERCEIRA. — As virtudes
intelectuais versam sobre matérias diversas não ordenadas umas para as outras, como é claro nas
diversas ciências e arte. E por isso, não existe nelas a conexão existente nas virtudes morais que versam
sobre as paixões e as obras manifestamente entre si ordenadas. Pois, todas as paixões, procedentes de
certas, que são as primeiras, — a saber, o amor e o ódio — terminam em certas outras, que são o prazer
e a dor. E semelhantemente, todas as obras, que constituem a matéria das virtudes morais, ordenam-se
umas para as outras e mesmo para as paixões. E é por isso que toda a matéria das virtudes morais cai no
domínio da prudência. — Contudo, tudo o que é inteligível se ordena para os primeiros princípios. E
desde então, todas as virtudes intelectuais dependem do intelecto dos princípios, como a prudência, das
virtudes morais, conforme já foi dito. Mas os princípios universais, que o intelecto apreende, não
dependem das conclusões, sobre as quais versam as outras virtudes intelectuais, assim como as virtudes
morais dependem da prudência, porque o apetite move, de certo modo, a razão, e esta, aquele, como já
dissemos.

RESPOSTA À QUARTA. — Os 0bjetos para que as virtudes morais inclinam, comportam-se, em relação à
prudência, como princípios; porém, os produtos da arte não se referem a esta como princípios mas só
como matéria. Pois, é manifesto que, embora a razão possa ser reta relativamente a uma parte da
matéria e não, relativamente à outra, não pode porém ser considerada reta, de nenhum modo, se
houver falta de algum princípio; assim como não poderia possuir a ciência geométrica quem errasse em
relação ao princípio —Qualquer todo é maior que uma das partes — porque, então, haveria de afastar-
se muito da verdade, nas deduções seguintes. — E, além disso, os atos são ordenados uns para os
outros, mas não, os produtos da arte, como dissemos. E portanto, a falta de prudência em relação a
uma parte dos nossos atos, implicaria a mesma falta em relação aos outros, o que não pode dar-se em
relação aos produtos da arte.

## Art. 2 — Se as virtudes morais podem existir sem a caridade.
(Iª·lIae., q. 23, a. 7 ; III Sent., dist. XVII, q. 2, a. 4, qª 3, ad 2; dist. XXXVI, q. 2; de Virtut., q. 5, a. 2).
O segundo discute-se assim. — Parece que as virtudes morais podem existir sem a caridade.

1. — Pois, foi dito que todas as virtudes, exceto a caridade, podem ser comuns aos bons e aos maus.
Ora, a caridade só pode existir nos bons, como no mesmo livro se diz. Logo, as outras virtudes podem
ser possuídas sem a caridade.

2. Demais. — As virtudes morais podem ser adquiridas pelos atos humanos, como se disse. Ora, a
caridade só pode ser possuída por infusão, conforme aquilo da Escritura (Rm 5, 5): a caridade de Deus
está derramada em nossos corações pelo Espírito Santo, que nos foi dado. Logo, as outras virtudes
podem ser possuídas sem caridade.

3. Demais. — As virtudes morais, enquanto dependentes da prudência, são conexas entre si. Ora, a
caridade não depende da prudência, e antes a excede, conforme a Escritura (Ef 3, 19): a caridade de
Cristo excede a ciência. Logo, as virtudes morais não são conexas com a caridade, e podem existir sem
ela.
Mas, em contrário, diz a Escritura (I Jo 3, 14): Aquele que não ama permanece na morte. Ora, as virtudes
aperfeiçoam a vida espiritual, pois por elas é que vivemos retamente, como diz Agostinho. Logo, não
podem existir sem o amor da caridade.

SOLUÇÃO. — Como já dissemos, as virtudes morais, enquanto operativas do bem, ordenadamente ao
fim que não excede a faculdade natural do homem, podem ser adquiridas por obras humanas. E assim
adquiridas, podem existir sem a caridade, como existiram em muitos gentios. — Mas, enquanto
operativas do bem, ordenadamente ao fim último sobrenatural, então realizam a essência da virtude
perfeita e verdadeiramente, e não podem ser adquiridas pelos atos humanos, mas são infundidas por
Deus. Ora, tais virtudes morais não podem existir sem a caridade. Pois, como já dissemos, as virtudes
morais não podem existir sem a prudência, e esta não pode existir sem aquelas, que nos levam a
proceder bem em relação a certos fins, dos quais procede a razão da prudência. Ora, pela sua razão
reta, a prudência exige, que o homem proceda bem em relação ao último fim — a que o leva a caridade
— muito mais que em relação aos outros fins, a que o levam as virtudes morais; assim como, na ordem
especulativa, a razão reta implica, principalmente, o primeiro princípio indemonstrável que os
contraditórios não podem ser simultaneamente verdadeiros.Do sobredito consta portanto, com clareza,
que só as virtudes infusas são perfeitas e se chamam virtudes, absolutamente falando. Ao passo que as
adquiridas — que são as outras — o são parcial e não absolutamente, porque ordenam bem o homem
para um fim último, não absoluta, mas genericamente. E por isso, àquilo da Escritura (Rm 14, 23) —
Tudo o que não é segundo a fé é pecado — diz a Glosa de Agostinho: Onde falta o conhecimento da
verdade, a virtude é falsa, mesmo acompanhada de ótimos costumes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No lugar aduzido as virtudes se consideram na sua
noção imperfeita. Do contrário, tomada a virtude moral em a noção perfeita, torna bom quem o possui
e por conseqüência, não pode existir nos maus.

RESPOSTA À SEGUNDA. — A objeção colhe relativamente às virtudes morais adquiridas.

RESPOSTA À TERCEIRA. — Embora a caridade exceda a ciência e a prudência, contudo esta depende
daquela, como já dissemos, e, por conseqüência, também dela dependem todas as virtudes morais
infusas.

## Art. 3 — Se podemos ter a caridade, sem as outras virtudes morais.
(III Sent., dist. XXXVI, a. 2; De Virtut., q. 5, a. 2).
O terceiro discute-se assim. — Parece que podemos ter a caridade sem as outras virtudes.

1. — Pois, aquilo para que basta só um se ordenam indevidamente vários. Ora, só a caridade basta para
realizarmos todas as obras virtuosas, como consta claro da Escritura (I Cor 13, 4): a caridade é paciente,
é benigna etc. Logo, possuída a caridade, as demais virtudes são supérfluas.

2. Demais. — Quem possui o hábito da virtude a pratica facilmente e nisso se compraz; por isso o prazer
que temos em obrar é sinal do hábito, como se disse. Ora, muitos que não estão em pecado mortal, têm
caridade e contudo sentem dificuldade em agir virtuosamente, e nisso não se comprazem senão no que
respeita à caridade. Logo, muitos têm a caridade, que não têm as outras virtudes.

3. Demais. — A caridade existe em todos os santos. Ora, há santos que não tiveram certas virtudes; pois,
diz Beda que os santos se humilham mais pelas virtudes que não têm do que se gloriam pelas que
possuem. Logo, não é necessário tenha todas as virtudes morais quem tem a caridade.
Mas, em contrário, pela caridade cumpre-se a lei na sua totalidade, conforme o dito da Escritura (Rm 13,
8):aquele que ama ao próximo tem cumprido com a lei. Ora, a lei, na sua totalidade, não pode ser
cumprida senão com todas as virtudes morais, porque ela preceitua sobre todos os atos virtuosos, como
se disse. Logo, quem tem a caridade tem todas as virtudes morais. E Agostinho também diz, numa de
suas epístolas, que a caridade inclui em si todas as virtudes cardeais.

SOLUÇÃO. — Todas as virtudes morais são infundidas simultaneamente com a caridade, porque Deus
não age menos perfeitamente nas obras da graça que nas da natureza. Assim, vemos que em nenhum
ser da natureza se encontra um princípio de qualquer obra sem existir o necessário à realização dessa
obra; p. ex., os animais têm órgãos pelos quais a alma obra perfeitamente o que está no seu poder. Ora,
é manifesto que a caridade, ordenando o homem ao seu último fim, é o princípio de todas as boas obras
que podem ordenar-se para tal fim. Por onde é necessário que, com a caridade, sejam infundidas no
homem todas as virtudes morais, pelas quais ele produz os vários gêneros de boas obras. E assim, é
claro que as virtudes morais infusas são conexas não só pelo que respeita a prudência, mas também, a
caridade; e que quem perde a caridade, pelo pecado mortal, perde também todas as virtudes morais
infusas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Para o ato de uma potência inferior ser perfeito é
necessário existir a perfeição, não só na potência superior, mas também na inferior. Pois, se o agente
principal atuasse do modo devido, sem que o instrumento estivesse bem disposto, não poderia realizar
uma obra perfeita. Por onde, para o homem empregar bem os meios, é necessário não só ter a virtude
pela qual proceda retamente em relação ao fim, mas também as que o façam empregar com acerto os
meios. Porque a virtude relativa ao fim se comporta como principal e motiva, em relação às que
dependem do fim. E portanto, com a caridade, é necessário termos também as outras virtudes morais.

RESPOSTA À SEGUNDA. — Às vezes sucede, que quem possui um hábito sofre dificuldade no agir, e por
conseqüência não se deleita nem se compraz com o ato, por algum impedimento extrínseco
sobreveniente. Assim, quem tem o hábito da ciência pode sofrer dificuldade em inteligir, por causa da
sonolência ou de alguma enfermidade. E semelhantemente, os hábitos das virtudes morais infusas
padecem às vezes dificuldade no agir, por causa de certas disposições contrárias, resíduos de atos
precedentes. E essas dificuldades não se apresentam nas virtudes morais adquiridas, porque o exercício
dos atos, pelos quais elas se adquirem, elimina também as disposições contrárias.

RESPOSTA À TERCEIRA. — Alguns santos se consideram como não possuindo certas virtudes, por
padecerem dificuldades em as praticar, pela razão já dita, embora tenham os hábitos de todas as
virtudes.

## Art. 4 — Se a fé e a esperança podem, às vezes, existir sem a caridade.
(IIª. lIae, q. 23, a. 7, ad 1 ; III Sent., dist .. XXIII, q. 3, a. 1, qª 2; dist. XXVI, q. 2. a. 3, qª 2; I Cor., cap. XIII
lect. 1).
O quarto discute-se assim. — Parece que a fé e a esperança nunca existem sem a caridade.

1. — Pois sendo virtudes teologais, são mais dignas do que as virtudes morais, mesmo as infusas. Ora,
estas não podem existir sem a caridade. Logo, nem a fé e a esperança.

2. Demais. — Só crê quem quer, diz S. Agostinho. Ora, a caridade existe na vontade, da qual é, a
perfeição, como já dissemos. Logo, a fé não pode existir sem a caridade.

3. Demais. — Como diz Agostinho, a esperança não pode existir sem o amor. Ora é a este, como
caridade, que ele se refere. Logo, a esperança não pede existir sem a caridade.
Mas, em contrário, a propósito de Mateus 1, 2 a Glosa diz que a fé gera a esperança e esta, a caridade.
Ora, o gerador é anterior ao gerado e pode existir sem este. Logo, a fé pode existir sem a esperança e
esta, sem a caridade.

SOLUÇÃO. — A fé e a esperança, assim como as virtudes morais, podem ser consideradas à dupla luz:
como de certo modo incoativas, e como virtudes perfeitas na sua essência. Pois, ordenando-se a virtude
à prática das boas obras, é perfeita a conducente a obras perfeitamente boas. E para isto não só boas
devem elas ser, mas também, bem feitas; do contrário não haverá bem perfeito se, por bem, se entende
o que é feito, embora não o seja bem; e portanto, também o hábito, princípio do que obramos, não
realizará perfeitamente a noção de virtude. Assim, quem pratica a justiça por certo que faz bem; mas a
sua obra não será o de uma virtude perfeita, se não o praticar bem, i. é, segundo a eleição reta, que se
inspira na prudência. Logo, sem esta a justiça não pode ser virtude perfeita.
Assim, pois, a fé e a esperança podem, por certo, existir de algum modo sem a caridade, mas, sem esta,
não podem realizar a noção perfeita da virtude. Pois, como a fé tem por objeto crer em Deus, e como
crer é assentir na opinião de outrem, por vontade própria, o ato da fé não será perfeito, se a vontade
não quiser do modo devido. Ora, só influenciada pela caridade, que aperfeiçoa a vontade, pode esta
querer do modo devido; porquanto, todo movimento reto dela procede do amor, no dizer de Agostinho.
Por onde, a fé pode, certamente, existir sem a caridade, mas não como virtude perfeita; assim como a
temperança ou a fortaleza não podem existir sem a prudência. E o mesmo se deve dizer da esperança,
cujo ato consiste em ter em expectativa a futura beatitude dada por Deus. Esse ato será perfeito se se
fundar nos méritos que já temos, o que não pode ser sem a caridade. Mas, se essa expectativa se fundar
nos méritos que ainda não temos, mas que nos propomos adquirir no futuro, o ato será imperfeito, e
pode existir sem a caridade. E portanto, a fé e a esperança podem existir sem a caridade, mas, sem esta,
propriamente falando, as virtudes não existem; porque, a virtude, por essência, exige não somente que
obremos de acordo com ela, mas ainda, que obremos retamente, como se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As virtudes morais dependem da prudência; ora, a
prudência infusa, sem a caridade, não pode realizar a essência da prudência, por lhe faltar a relação
devida com o primeiro princípio, que é o último fim. Ao passo que a fé e a esperança, por essência, não
dependem da prudência nem da caridade; e, portanto, podem existir sem esta, embora então não
sejam virtudes, como já se disse.

RESPOSTA À SEGUNDA. — A objeção colhe quanto à fé, que realiza perfeitamente a essência da virtude.

RESPOSTA À TERCEIRA. — Agostinho se refere, no lugar aduzido, à esperança pela qual temos em
expectativa a futura beatitude, fundada nos méritos que já possuímos; o que não pode ser sem a
caridade.

## Art. 5 — Se a caridade pode existir sem a fé e a esperança.
O quinto procede-se assim. — Parece que a caridade pode existir sem a fé e sem a esperança.

1. — Pois, a caridade é o amor de Deus. Ora, Deus pode ser amado por nós naturalmente, mesmo sem
pressupor a fé ou a esperança da futura beatitude. Logo, a caridade pode existir sem a fé e sem a
esperança.

2. Demais. — A caridade é a raiz de todas as virtudes, conforme aquilo da Escritura (Ef 3, 17): arraigados
e fundados em caridade. Ora, a raiz às vezes não produz ramos. Logo, a caridade pode, às vezes, existir
sem a fé, a esperança e as outras virtudes.

3. Demais. — Cristo teve caridade perfeita, e contudo não teve fé nem esperança, porque foi
compreensor perfeito, como a seguir se dirá. Logo, a caridade pode existir sem a fé e sem a esperança.
Mas, em contrário, diz a Escritura (Heb 11, 6): sem a fé é impossível agradar a Deus, o que pertence, por
excelência, à caridade, conforme aquilo (Pr 8, 17): Eu amo aos que me amam. E a esperança também
leva à caridade, como já dissemos. Logo, não podemos ter a fé sem a esperança e a caridade.

SOLUÇÃO. — A caridade significa não só amor de Deus, mas também uma certa amizade para com ele, a
qual acrescenta ao amor a retribuição acompanhada de comunicação mútua, como se disse. E que isto
pertence à caridade consta com clareza daquilo da Escritura (1 Jo 4, 16): aquele que permanece na
caridade permanece em Deus, e Deus nele; e ainda (1 Cor 1, 9): Fiel é Deus, pelo qual fostes chamado à
companhia de seu filho Jesus Cristo. E esta sociedade do homem com Deus que é, de algum modo, uma
conversação familiar com ele, começa na vida presente pela graça e se completará na futura, pela glória.
E ambas essas coisas nós as obtemos pela fé e pela esperança. Por onde, assim como não poderemos
ter amizade com alguém se descrermos ou desesperarmos de poder ter com o mesmo alguma
sociedade ou familiar conversação, assim não poderemos ter amizade com Deus, que é a caridade, se
não tivermos a fé, que nos faz crer nessa sociedade e conversação com Deus, e se não esperarmos
pertencer a essa sociedade. E portanto, sem a fé e a esperança a caridade não pode existir de nenhum
modo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A caridade não é qualquer amor de Deus, mas o pelo
qual o amamos como objeto da beatitude, ao qual nos ordenamos pela fé e pela esperança.

RESPOSTA À SEGUNDA. — A caridade é a raiz da fé e da esperança, porque lhes dá a perfeição da
virtude; mas, a fé e a esperança, por sua própria natureza, são pressupostas à caridade, como já
dissemos; e, portanto, a caridade não pode existir sem elas.

RESPOSTA À TERCEIRA. — Cristo não teve fé nem esperança no que há numa e outra de imperfeito; mas
em lugar de fé teve a visão plena, e em lugar da esperança, a plena compreensão. E portanto, teve
caridade perfeita.