# Questão 83: Do sujeito do pecado original.
Em seguida devemos tratar do sujeito do pecado original. E nesta questão discutem-se quatro artigos:

## Art. 1 — Se o pecado original está mais na carne que na alma.
(II Sent., dist. XVIII, q. 2, a. 1, ad. 3; dist. XXX, q. q, a. 2, ad 4; dist. XXXI, q. 1, a. 1, ad 2, 4; dist. XXXIII, q. 1,
a. 3, ad 4; De Malo, q. 4, a. 3).
O primeiro discute-se assim. — Parece que o pecado original está mais na carne que na alma.

1. — Pois, a repugnância da carne com a alma procede da corrupção do pecado original. Ora, a raiz
dessa repugnância está na carne, conforme aquilo do Apóstolo (Rm 7): sinto nos meus membros outra
lei que repugna à lei do meu espírito. Logo, o pecado original está principalmente na carne.

2. Demais. — Tudo está mais na causa que no efeito; assim o calor esta mais no fogo que aquece, do
que na água aquecida. Ora, a alma sofre a contaminação do pecado original, por meio do sêmen carnal.
Logo, o pecado original está mais na carne que na alma.

3. Demais. — Contraímos o pecado original do primeiro pai, porque preexistimos nele pelo gérmen
seminal. Ora, nele não preexistimos pela alma, mas só pela carne. Logo, o pecado original não está na
alma, mas na carne.

4. Demais. — A alma racional criada por Deus é infundida no corpo. Se portanto, a alma fosse
contaminada pelo pecado original, sê-lo-ia desde a sua criação ou infusão. E assim, Deus, causa da
criação e da infusão, seria também a causa do pecado.

5. Demais. — Ninguém que tenha sabedoria iria despejar um licor precioso num vaso, do qual sabe que
o contaminará. Se portanto a alma, pela sua união com o corpo, pudesse contaminar-se com a mácula
da culpa original, Deus, que é a sabedoria mesma, nunca haveria de infundi-la em tal corpo. Ora, se a
infunde, é que ela não fica maculada pela carne. Portanto, o pecado original não está na alma, mas na
carne.
Mas, em contrário, o sujeito de uma virtude e de um vício ou pecado, é o mesmo que o da virtude ou
vício contrários. Ora, a carne não pode ser sujeito da virtude, pois, como diz o Apóstolo (Rm 7), eu sei
que em mim, quero dizer, na minha carne, não habita o bem. Logo, a carne não pode ser o sujeito do
pecado original, mas só a alma.

SOLUÇÃO. — Uma coisa pode estar em outra de dois modos: como na causa, principal ou instrumental,
ou como no sujeito. Por onde, o pecado original de todos os homens preexistiu por certo, em Adão,
como na causa primeira principal, conforme aquilo do Apóstolo (Rm 5): no qual todos pecaram. Por
outro lado, o pecado original preexistia no sêmen do corpo, como na causa instrumental, porque é pela
virtude ativa do sêmen que ele se transmite à prole simultaneamente com a natureza humana. Mas, o
pecado original de nenhum modo pode ter a carne como sujeito, mas só a alma.
E a razão é que, como já dissemos, pela vontade do primeiro pai, o pecado original se lhe transmitiu aos
descendentes, por via de geração, assim como da vontade de um homem o pecado atual se lhe deriva
para as outras partes. E nesta derivação notamos o seguinte. Tudo o redundante da moção da vontade,
de pecar, para qualquer parte do homem, de algum modo participante do pecado, seja, como sujeito,
seja, como instrumento, tudo isso implica essencialmente a culpa. Assim, a vontade da gula faz o
concupiscível desejar o alimento, e leva as mãos e a boca a tomarem-no, que, enquanto movidas pela
vontade ao pecado, são instrumentos deste. Porém o ulterior redundante na potência nutritiva, e nos
membros interiores, de natureza a não serem movidos pela vontade, não implica a culpa
essencialmente.
Assim pois, podendo a alma ser sujeito da culpa, e a carne, em si mesma, não, toda a corrupção do
primeiro pecado, que atinge a alma, implica a culpa; o que porém não a atinge implica, não culpa, mas a
pena. Portanto, a alma, e não a carne, é o sujeito do pecado original.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho, o Apóstolo se refere no lugar citado
ao homem já redimido, libertado da culpa, mas sujeito à pena, e por isso diz que o pecado habita na
carne. Mas daqui se não segue seja a carne sujeito da culpa, mas só da pena.

RESPOSTA À SEGUNDA. — O pecado original tem no sêmen a sua causa instrumental. Ora, não é
necessário que o existente na causa instrumental nesta exista mais principalmente que no efeito, senão
só na causa principal. Edeste modo o pecado original existiu mais principalmente em Adão, em quem
existiu como pecado atual.

RESPOSTA À TERCEIRA. — A alma de um homem qualquer não preexistiu, seminalmente em Adão
pecador, como no seu princípio efetivo, mas como no princípio dispositivo. Porque o sêmen corpóreo,
transmitido por Adão, não tem a virtude de produzir a alma racional, mas, só a de dispô-la.

RESPOSTA À QUARTA. — A mácula do pecado original de nenhum modo foi causada por Deus, mas só
pelo pecado do primeiro pai, mediante a geração carnal. Logo, a criação, implicando relação da alma só
com Deus, não se pode dizer que por ela fosse maculada. A infusão porém implica relação com Deus,
que infunde, e com a carne, na qual é a alma infundida. Logo, considerada a relação com Deus, que
infunde, não se pode dizer que pela infusão a alma seja maculada, mas só levando-se em conta a
relação com o corpo em que é infundida.

RESPOSTA À QUINTA. — O bem comum tem preferência sobre o particular. Por isso, Deus, de
conformidade com a sua sabedoria, não derroga para evitar o contágio particular de uma alma, a ordem
universal das coisas, que exige seja ela infundida em tal corpo. Sobretudo por ser da natureza da alma
não começar a existir senão unida ao corpo, como se demonstrou na Primeira Parte. Pois, é-lhe melhor
a ela assim existir, segundo a natureza, do que não existir de nenhum modo; sobretudo por poder, pela
graça, livrar-se da condenação.

## Art. 2 — Se o pecado original está mais na essência da alma que nas potências.
(II Sent., dist. XXXI, q. 2, a. 1; De Verit., q. 25, a. 6; q. 27, a. 6, ad 2; De Malo, q. 4, a. 4).
O segundo discute-se assim. — Parece que o pecado original não está mais na essência da alma que
nas potências.

1. — Pois é natural à alma ser sujeito do pecado, por poder ser movida pela vontade. Ora, não a
essência da alma é a movida pela vontade, mas sim as suas potências. Logo, o pecado original não
atingiu a essência da alma, mas só as suas potências.

2. Demais. — O pecado original se opõe à justiça original. Ora, esta havia de estar em alguma potência
da alma, sujeito da virtude. Logo, também o pecado original está mais nas potências que na essência da
alma.

3. Demais. — Assim como da carne o pecado original derivou para a alma, assim da essência desta
derivou-lhe para as potências. Ora, o pecado original está mais na alma que na carne. Logo, também
mais nas potências, que na essência da alma.

4. Demais. — Tem-se como concupiscência o pecado original, conforme já se disse. Ora, a
concupiscência tem sua sede nas potências da alma. Logo, também o pecado original.
Mas, em contrário, o pecado original é considerado um pecado natural, como já se disse. Ora, a alma é
por essência, e não pelas suas potências, como já se estabeleceu na Primeira Parte, a forma e a natureza
do corpo. Logo, ela é principalmente e por essência o sujeito do pecado original.

SOLUÇÃO. — A alma é principalmente sujeito de um pecado, pelo que a torna primariamente causa
motora desse pecado. Assim, se a causa motiva do pecado for o deleite sensível, residente na potência
sensitiva, como seu objeto próprio, segue-se que essa potência é o sujeito próprio desse pecado. Ora, é
manifesto, o pecado original foi causado pela geração. Portanto, por onde a alma entra primeiramente
em contato com a geração do homem, por aí ela é o sujeito primeiro do pecado original. Ora, a geração
entra em contato com a alma, como seu termo, enquanto forma do corpo, o que por essência própria
lhe convém, segundo já demonstramos na Primeira Parte. Logo, a alma é por essência o sujeito primeiro
do pecado original.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como o movimento da vontade do homem atinge-
lhe propriamente, as potências, e não a essência da alma, assim o movimento da vontade do primeiro
gerador atinge primeiramente, por via da geração, a essência da alma, como já se disse.

RESPOSTA À SEGUNDA. — Também a justiça original se inclina, primordialmente na essência da
alma;pois, era um dom de Deus à natureza humana, próprio mais de tal essência, que das suas
potências. Pois, estas pertencem mais à pessoa, enquanto princípio de atos pessoais. Por onde, os
sujeitos próprios dos pecados atuais é que são pecados pessoais.

RESPOSTA À TERCEIRA. — O corpo está para a alma como a matéria para a forma; esta, embora
posterior na ordem da geração, é anterior na da perfeição e da natureza. Ora, a essência da alma está
para as potências, como o sujeito para os acidentes próprios, posteriores ao sujeito, tanto na ordem da
geração, como na da perfeição. Portanto a comparação não colhe.

RESPOSTA À QUARTA. — A concupiscência desempenha, no pecado original, o papel de matéria e
conseqüência, segundo já se disse.

## Art. 3 — Se o pecado original contaminou mais a vontade que as outras faculdades.
(II Sent., dist. XXX, q. 1, a. 3; De Verit., q. 25, a 6; De Malo, q. 4, a. 5).
O terceiro discute-se assim. — Parece que o pecado original não contaminou mais a vontade que as
outras faculdades.

1. — Pois, todo pecado pertence principalmente à potência por cujo ato foi causado. Ora, o pecado
original foi causado pelo ato da potência geratriz. Logo, dentre as demais potências da alma, parece
pertencer antes à potência geratriz.

2. Demais. — O pecado original transmite-se pelo sêmen carnal. Ora, as outras potências da alma são
mais próximas da carne, que a vontade; como se vê claramente em todas as potências sensitivas, que se
servem de órgão corpóreo. Logo, nelas, mais que na vontade, está o pecado original.

3. Demais. — O intelecto tem prioridade sobre a vontade, pois esta não pode querer senão o bem
conhecido. Se portanto o pecado original contaminou todas as potências da alma, parece que
contaminou primeiro o intelecto, como sendo a mais importante.
Mas, em contrário, a justiça original diz respeito, primariamente, à vontade, pois, consiste na retidão da
vontade, como diz Anselmo. Logo, o pecado original, que se lhe opõe, respeita, antes de tudo, a
vontade.

SOLUÇÃO. — Dois aspectos devemos levar em conta no contágio do pecado original. Primeiro, a sua
inerência ao sujeito; e por aí diz respeito, primariamente, à essência da alma, como já se disse. Em
seguida devemos considerar-lhe a inclinação para o ato; e, por aí respeita às potências da alma. Ora, ele
há de respeitar, primária e necessariamente a que tem a inclinação primeira para o pecado. E como esta
é a vontade, segundo já se demonstrou, o pecado original há de lhe dizer respeito em primeiro lugar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pecado original não é causado no homem pela
potência geratriz da prole; mas pelo ato da potência geratriz do pai. Por onde, não é necessário seja a
sua potência geratriz o sujeito primeiro do pecado original.

RESPOSTA À SEGUNDA. — O pecado original tem dupla derivação: uma, da carne para a alma; outra, da
essência da alma para as potências. A primeira é conforme à ordem da geração; a segunda, à da
perfeição. E portanto, embora as potências sensitivas sejam mais próximas à carne; como porém a
vontade está mais chegada à essência da alma, como potência superior que é, será a primeira a receber
a contaminação do pecado original.

RESPOSTA À TERCEIRA. — O intelecto de certa maneira precede à vontade, por propor-lhe o seu objeto.
De outro modo porém a vontade precede o intelecto, na ordem da moção para o ato, moção essa que
implica o pecado.

## Art. 4 — Se as referidas potências — a geratriz, a potência concupiscível e o sentido do tacto, foram mais contaminadas que as outras.
(II Sent., dist., XXXI, q. 2, a. 2: De Verit., q. 25; a. 6; De Malo, q. 4, a. 2, ad 12; a. 5, ad 1).
O quarto discute-se assim. — Parece que as referidas potências não foram mais contaminadas que as
outras.

1. — Pois, parece que o contágio do pecado original há de ter atingido sobretudo aquela parte da alma
susceptível de ser o sujeito primário do pecado. Ora, esta é a parte racional, e sobretudo à vontade.
Logo, esta foi sobretudo à contaminada pelo pecado original.

2. Demais. — Nenhuma potência da alma é contaminada pela culpa, senão enquanto pode obedecer à
razão. Ora, a potência geratriz não o pode, como o diz Aristóteles. Logo, não foi sobretudo essa a
potência contaminada pelo pecado original.

3. Demais. — Dentre os sentidos é o da visão o mais espiritual e achegado à razão, por distinguir mais
diferenças entre as coisas, como diz Aristóteles. Ora, o contágio da culpa atingiu principalmente a razão.
Logo, o sentido da visão foi mais contaminado que o tato.
Mas, em contrário, Agostinho diz, que o contágio da culpa original manifestou-se sobretudo no
movimento dos membros genitais, desobedientes à razão. Ora, esses membros servem à potência
geratriz, no comércio sexual, onde o prazer depende do tato, que excita sobretudo a concupiscência.
Logo, o contágio do pecado original atingiu sobretudo estas três potências: a geratriz, a concupiscível e
o sentido do tacto.

SOLUÇÃO. — Costuma-se chamar contaminação sobretudo aquela corrupção que naturalmente se
transmite a outrem; por isso as doenças contagiosas, como a lepra, a sarna e semelhantes, chamam-se
contaminações. Ora, a corrupção do pecado original se transmite pelo ato da geração, como já se disse.
Por onde, consideram-se sobretudo como contaminadas as potências concorrentes nesse ato. Ora, tal
ato serve à potência geratriz, como ordenado para a geração; e implica o prazer do tacto, objeto por
excelência da potência concupiscível. E portanto, como se consideram corruptas pelo pecado original
todas as partes da alma, corruptas principalmente e contaminadas se consideram as três referidas
potências.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O pecado original, enquanto inclina para os pecados
atuais, atingiu principalmente a vontade, como já se disse. Mas enquanto se transmite à prole, atingiu
as faculdades preditas, proximamente, e a vontade, remotamente.

RESPOSTA À SEGUNDA. — A contaminação da culpa atual só atinge as potências movidas pela vontade
do pecador. Ora, a contaminação da culpa original derivou não, da vontade daquele que a contraiu,
mas, da geração natural, à qual serve a potência geratriz. Logo, há nela a contaminação do pecado
original.

RESPOSTA À TERCEIRA. — A visão não concerne ao ato gerador senão como disposição remota,
enquanto que, por ela, se manifesta a forma concupiscíve1. Ao passo que o prazer se completa pelo
tacto. Por isso o contágio em questão se atribui mais ao tacto que à vista.