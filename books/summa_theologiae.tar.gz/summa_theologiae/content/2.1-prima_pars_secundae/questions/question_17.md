# Questão 17: Dos atos ordenados pela vontade.
Em seguida devemos tratar dos atos ordenados pela vontade.
E sobre esta Questão nove artigos se discutem:

## Art. 1 — Se ordenar é ato da razão ou da vontade.
(II ª, II ª, q. 83, a . 1; IV Sent., dist. XV, q. 4, a . 1, q ª 1, ad 3; De Verit., q.22, a 12, a . 12 ad 4. Quodl. IX, q.
5, a . 2).
O primeiro discute-se assim. ― Parece que ordenar não é ato da razão mas, da vontade.

1. ― Pois, ordenar é mover, conforme o nota Avicena, ao afirmar serem quatro as espécies de
motores: o que aperfeiçoa, o que dispõe, o que ordena e o que aconselha. Ora, à vontade pertence
mover todas as outras potências da alma, como já se disse. Logo, ordenar é ato da vontade.

2. Demais. ― Assim como ser mandado é próprio de quem está sujeito, assim ordenar o é de quem é
soberanamente livre. Ora, a liberdade está radicalmente sobretudo na vontade. Logo a esta pertence
ordenar.

3. Demais. ― À ordem segue-se imediatamente o ato. Ora, ao ato da razão não se segue,
imediatamente, o agir; assim, quem julga que uma coisa deve ser feita não a realiza imediatamente.
Logo, ordenar não é ato da razão, mas da vontade.
Mas, em contrário, diz Gregório Nisseno (Nemésio) e também o Filósofo, que o apetite obedece à razão.
Logo, é próprio desta ordenar.

SOLUÇÃO. ― Ordenar é ato da razão, pressuposto contudo o ato da vontade. E isto se prova
considerando que, como os atos da vontade e da razão podem reagir uns sobre os outros, enquanto que
esta raciocina sobre o querer, e aquela quer o raciocinar, pode se dar que o ato da vontade seja
precedido pelo da razão e inversamente. E prolongando-se a influência do ato anterior no conseqüente,
acontece às vezes que um ato da vontade não subsiste senão na medida em que nele persiste,
virtualmente, algo do ato da razão, conforme já dissemos ao tratar do uso e da eleição. E inversamente,
acontece que não subsiste um ato da razão senão enquanto nele permanece, virtualmente, algo do ato
da vontade. Ora, ordenar é, certa e essencialmente, ato da razão; pois quem manda dá uma ordem a
alguém para fazer alguma coisa, intimando ou enunciando. Por onde, ordenar, a modo de intimação, é
próprio da razão. Ora, a razão pode intimar ou enunciar de duplo modo. Absolutamente, e nesse caso a
intimação é expressa por um verbo no modo indicativo, como quando alguém diz a outrem: deves fazer
isto. Outras vezes porém a razão intima uma ordem a alguém, movendo-o à execução dela e tal
intimação se exprime pelo verbo no modo imperativo, como quando se lhe diz faze isto. Ora, o que nas
potências da alma, move primariamente ao exercício do ato é a vontade, como já se disse E como o
segundo motor não move senão em virtude do primeiro, resulta que a moção mesma causada pela
razão, imperando, provém-lhe do impulso da vontade. Donde se conclui que ordenar é ato da razão,
pressuposto, porém o ato da vontade, por virtude do qual a razão move pela ordem, ao exercício do ato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ordenar não é mover de qualquer modo; mas com uma
certa intimação, que indica a outrem o que deve fazer, e isto é ato da razão.

RESPOSTA À SEGUNDA. ― A liberdade está radicalmente na vontade, como sujeito; mas tem como
causa a razão; pois se a vontade pode se exercer livremente sobre objetos diversos, é porque a razão
pode ter várias concepções do bem. E por isso os filósofos definem o livre arbítrio como o juízo livre da
razão, por ser esta a causa da liberdade.

RESPOSTA À TERCEIRA. ― A objeção proposta conclui que a ordem não é ato da razão, absolutamente,
mas acompanhada de certa moção, como já disse.

## Art. 2 — se ordenar convém aos brutos.
O segundo discute-se assim. ― Parece que ordenar convém aos brutos.

1. ― Pois, segundo Avicena, a força que ordena o movimento reside no apetite; e a que executa o
movimento, nos músculos e nos nervos. Ora, ambas existem nos brutos. Logo, podem ordenar.

2. Demais. ― É próprio do escravo ser mandado. Ora, o corpo está para a alma como o servo para o
senhor, no dizer do Filósofo. Logo, o corpo recebe as ordens da alma, mesmo nos brutos, composto de
corpo e alma.

3. Demais. ― Ordenando a si mesmo é que o homem se lança na ação. Ora, os animais também nela se
lançam, como diz Damasceno. Logo, são capazes de ordenar.
Mas, em contrário. ― A ordem é um ato da razão, como já se disse. Ora, os brutos não tem razão. Logo,
não podem ordenar.

SOLUÇÃO. ― Ordenar não é mais do que mandar alguém fazer alguma coisa, com certa moção
intimativa. Ora, tal ato é próprio da razão. Logo, é impossível que os brutos, desprovidos de razão,
possam de qualquer modo ordenar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que a potência apetitiva ordena um movimento
na medida em que move a razão ordenadora. Ora, só os homens são capazes de tal. Pois, nos brutos, a
potência apetitiva não é propriamente imperativa senão no sentido geral de mover.

RESPOSTA À SEGUNDA. ― O corpo dos brutos pode certamente obedecer, mas a alma não pode
governar porque não pode ordenar. Não há por isso, no caso, relação entre quem ordena e quem é
ordenado, mas só, entre o motor e o movido.

RESPOSTA À TERCEIRA. ― Os brutos impulsionam-se à ação de modo diferente dos homens. Estes o
fazem por um imperativo da razão, equivalendo, neles, o impulso a uma ordem. Os brutos porém, pelo
instinto natural; pois o apetite deles, uma vez apreendido o objeto conveniente ou não, imediatamente
se move para ele ou dele se afasta. Logo são ordenados à ação por outrem, nela não se lançando por si
mesmos. E portanto, há neles o impulso, mas não, a ordem.

## Art. 3 — Se o uso precede a ordem.
O terceiro discute-se assim. ― Parece que o uso precede a ordem.

1. ― Pois, a ordem é ato da razão, que pressupõe o da vontade, como já se disse. Ora, o uso é ato da
vontade, como também já se disse. Logo, precede a ordem.

2. Demais. ― A ordem é um dos meios, em vista do fim. Ora, o uso tem por objeto exatamente esses
meios. Logo, é anterior à ordem.

3. Demais. ― O ato de toda potência movida pela vontade se chama uso, pois a vontade usa de todas as
potências, como já se disse. Ora, a ordem é um ato da razão, enquanto movida pela vontade, como
também já se disse. Logo, a ordem é uma espécie de uso. E sendo o comum anterior ao próprio, o uso é
anterior à ordem.
Mas, em contrário, diz Damasceno, que o impulso para a ação precede o uso. Ora esse impulso nasce da
ordem. Logo, esta precede o uso.

SOLUÇÃO. ― O uso do meio, enquanto este é referido ao fim pela razão, precede a eleição, como já se
disse. Logo, há forçosamente de preceder à ordem. Porém o uso do meio enquanto submetido à
potência executora, depende da ordem, porque o ato de quem usa é conexo com o da coisa usada;
assim, ninguém usa de um bastão antes que este, de algum modo, atue. A ordem porém não é
simultânea com o ato do ser ordenado; mas naturalmente, é anterior à obediência a si devida, sendo
mesmo às vezes essa prioridade temporal. Por onde, é manifesto que a ordem é anterior ao uso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nem todo ato da vontade precede o ato racional da
ordem; mas há um que precede e é a eleição; outro que se segue e é o uso. Pois, após a determinação
do conselho, juízo da razão, é que a vontade elege; depois da eleição, a razão ordena a quem deve
empregar os meios escolhidos; enfim, executando a ordem da razão, a vontade põe-se a usar e essa
vontade é, ora a de outrem, quando mandamos a outrem; ora, é a própria, quando ordenamos a nós
mesmos.

RESPOSTA À SEGUNDA. ― Como os atos são anteriores às potências, assim os objetos, aos atos. Ora, o
objeto do uso são os meios. Logo, como a ordem mesma é um meio, pode-se concluir mais
acertadamente que ela é antes anterior do que posterior ao uso.

RESPOSTA À TERCEIRA. ― Assim como o ato da vontade que usa da razão, para ordenar, precede a
ordem, assim também se pode dizer que esse mesmo uso da vontade precede qualquer ordem da
razão, porque os atos dessas potências se refletem mutuamente uns sobre os outros.

## Art. 4 — Se o ato ordenado e a ordem são um mesmo ato.
(III, q. 19, a . 2; De Unione Verbi, a . 5).
O quarto discute-se assim. ― Parece que o ato ordenado e a ordem não são um mesmo ato.

1. ― Pois, de potências diversas são diversos os atos. Ora, o ato ordenado procede de uma potência e a
ordem, de outra; pois, uma é a potência que ordena e outra, a ordenada. Logo, ato ordenado e ordem
não são um mesmo ato.

2. Demais. ― Coisas separáveis uma da outra são diversas, pois nada se separa de si mesmo. Ora, às
vezes o ato ordenado se separa da ordem; e é quando esta precede sem ser seguida daquele. Logo,
ordem e ato ordenado diferem.

3. Demais. ― Onde há prioridade de uma coisa sobre outra há diversidade. Ora, a ordem naturalmente
precede o ato ordenado. Logo, este difere daquela.
Mas, em contrário, diz o Filósofo, que quando uma coisa é para outra, só uma existe. Ora, o ato
ordenado não é senão para a ordem. Logo, ambos constituem um só ato.

SOLUÇÃO. ― Nada impede que coisas múltiplas, a uma luz, sejam uma só, a outra. Antes, tudo o que é
múltiplo se unifica, num certo ponto de vista, como diz Dionísio. Há-se entretanto de levar em conta a
diferença seguinte: certas coisas que são múltiplas, absolutamente, relativamente, constituem uma só;
com outras porém, o contrário se dá. Ora, a unidade é predicada do mesmo modo que o ser; e este,
absolutamente, é substância e, relativamente, acidente ou ser de razão. Por onde, tudo o que é um,
substancialmente, é um, absolutamente, e múltiplo, relativamente. Assim, o todo, no gênero da
substância, composto das suas partes integrais ou essenciais, é um, absolutamente, porque é ente e
substância, absolutamente; ao passo que as partes são entes e substâncias, no todo. Porém seres, que
tem diversidade substancial e unidade acidental, são diversos, absolutamente, e um mesmo ser
acidental; assim, muitos homens formam um povo e muitas pedras, um acervo, que é unidade de
composição ou de ordem. Do mesmo modo muitos indivíduos com unidade genérica ou específica são
múltiplos, absolutamente, e um, relativamente; pois, ser um, genérica ou especificamente, é ser
racionalmente uno.
Ora, assim como no gênero dos seres naturais, o todo é composto de matéria e forma ― por ex., o
homem, de corpo e alma, o qual é um, naturalmente, embora tenha multidão de partes ― assim
também nos atos humanos, o ato de uma potência inferior se comporta materialmente em relação ao
da potência superior, enquanto que aquela age por virtude da superior, que a move; e do mesmo modo
o ato do primeiro motor se comporta como forma em relação ao ato do instrumento. Por onde é claro
que a ordem e o ato ordenado constituem um só e mesmo ato, do mesmo modo que o todo é uno,
embora múltiplo pelas suas partes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Se as potências diversas não fossem subordinadas entre
si, os atos deles seriam diversos, absolutamente. Mas, quando uma potência move a outra, os seu atos
constituem, de certo modo, um só, pois um só ato é o do motor e do móvel, como diz o Filósofo.

RESPOSTA À SEGUNDA. ― De poder a ordem ser separada do ato ordenado, resulta que são múltiplos,
quanto às partes; assim as partes do homem podem ser separadas umas das outras, embora constituam
uma unidade total.

RESPOSTA À TERCEIRA. ― Nada impede que nos seres múltiplos, pelas partes, mas unificados, pelo
todo, um tenha prioridade sobre outro; assim, a alma tem de certo modo prioridade sobre o corpo e o
coração, sobre os outros membros.

## Art. 5 — Se o ato da vontade é ordenado.
(I Ethic., lect. XX).
O quinto discute-se assim. ― Parece que o ato da vontade não é ordenado.

1. ― Pois, como diz Agostinho, a alma ordena a si mesma o querer, mas não a faz querer. Ora, querer é
ato da vontade. Logo, este não é ordenado.

2. Demais. ― Ordenar convém a quem compreende a ordem. Ora, à vontade não compete compreendê-
la, pois a vontade difere do intelecto, que compreende. Logo, o ato da vontade não é ordenado.

3. Demais. ― Se um ato da vontade é ordenado, pela mesma razão todos hão de sê-lo. Ora, se todos o
forem, há-se de proceder ao infinito necessariamente; porque o ato da vontade precede o da razão que
ordena, como já se disse; e se esse ato da vontade for, por sua vez, ordenado, a ordem, que lhe
corresponde, há de preceder outro ato da razão e assim ao infinito. Ora, é impossível esse processo ao
infinito. Logo, o ato da vontade não é imperado.
Mas, em contrário. ― Tudo o que está em nosso poder está sujeito à nossa ordem. Ora, os atos da
vontade por excelência caem sob nosso poder, pois todos os nossos atos se consideram como estando
em nosso poder, enquanto voluntários. Logo, os atos da vontade são ordenados por nós.

SOLUÇÃO. ― Como já se disse, a ordem não é senão o ato da razão que manda, com certa moção, que
alguma coisa seja feita. Ora, é manifesto que a razão pode ordenar o ato da vontade. Pois, assim como
pode julgar que é bom querer uma coisa, assim pode ordenar, mandando-nos querer. Por onde é claro
que o ato da vontade pode ser ordenado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como Agostinho diz no mesmo passo, a alma já quer
quando a si mesma se ordena, perfeitamente, que queira. E só por ordenar imperfeitamente é que às
vezes ordena e não quer. Ora, a ordem imperfeita vem de que a razão é movida, por motivos diversos, a
ordenar ou não, e por isso flutua entre esses dois termos e não ordena perfeitamente.

RESPOSTA À SEGUNDA. ― Assim como cada um dos membros corpóreos age não só para si, mas para
todo o corpo ― p.ex., os olhos vêm para todo ele, — o mesmo se dá com as potências da alma. Pois, o
intelecto intelige, não só para si, mas para todas as potências; e para todas, e não só para si, a vontade
quer. Portanto, o homem ordena-se a si mesmo o ato da vontade, por ser susceptível de compreender e
querer.

RESPOSTA À TERCEIRA. ― Sendo a ordem um ato da razão, ordenado é o ato que a ela está sujeito. Ora,
o ato primeiro da vontade não procede de ordem da razão, mas do instinto da natureza, ou de uma
coisa superior, como se disse antes. E portanto não é necessário proceder ao infinito.

## Art. 6 — Se um ato da razão pode ser ordenado.
(De Vertut., q. 1, a . 7).
O sexto discute-se assim. ― Parece que um ato da razão não pode ser ordenado.

1. ― Pois, é inadmissível que alguém ordene a si mesmo. Ora, é a razão que ordena, como já se disse.
Logo, o seu ato não pode ser ordenado.

2. Demais. ― O essencial é diverso do participado. Ora, a potência, cujo ato é ordenado pela razão, é
razão participativamente, com diz o Filósofo. Logo, não pode ser ordenado o ato da potência que é, por
essência, razão.

3. Demais. ― É ordenado o ato que está em nosso poder. Ora, conhecer e julgar a verdade, ato da
razão, não está sempre em nosso poder. Logo, o ato da razão não pode ser ordenado.
Mas, em contrário. ― O que fazemos livremente, podemos ordenar. Ora, o ato da razão se exerce
livremente, pois, como diz Damasceno, o homem procura, percruta, julga e dispõe livremente. Logo, o
ato da razão pode ser ordenado.

SOLUÇÃO. ― A razão podendo refletir sobre si mesma, ordena não só os atos das outras potências mas,
o seu próprio; e portanto, este pode ser ordenado. Devemos porém atender a que o ato da razão pode
ser considerado sob duplo aspecto: relativamente ao seu exercício, e então pode sempre ser ordenado,
como quando se indica a alguém que preste atenção e use da razão; e relativamente ao objeto, e então
ele se desdobra em dois. Ou, se trata da apreensão de uma verdade qualquer, e isso não está em nosso
poder, pois depende de luz natural ou sobrenatural, de que dispomos; e portanto, neste caso, o ato da
razão não está em nosso poder e não pode ser ordenado. Ou se trata de dar a razão o seu assentimento
ao que apreende aquilo a que o nosso intelecto assente naturalmente, como os primeiros princípios, dar
o assentimento ou o dissentimento não depende de nós, mas, da ordem da natureza, e portanto,
propriamente falando, isso não pode ser ordenado por nós. Há porém certas verdades apreendidas que
não convencem o intelecto de tal modo, que não possa assentir ou dissentir ou, pelo menos, suspender
o assentimento ou o dissentimento, por uma causa qualquer; e em tais casos, assentir ou dissentir está
em nosso poder e cai sob nossa ordem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A razão ordena a si mesma como a vontade a si mesma
se move, conforme já se disse; e isso se dá porque essas duas faculdades podem refletir sobre o próprio
ato e passar de um para outro.

RESPOSTA À SEGUNDA. ― Por causa da diversidade dos objetos, submetidos ao ato da razão, nada
impede que esta participe de si mesma, assim como o conhecimento das conclusões participa do
conhecimento dos princípios.

RESPOSTA À TERCEIRA. ― Resulta clara do que foi dito.

## Art. 7 — Se um ato do apetite sensitivo pode ser ordenado.
(I. q. 81. a . 3; infra, q. 56, a . 4 ad 3; q.58, a . 2; De Verit., q.25, a. . 4 De Virtut., q. 1, a . 4).
O sétimo discute-se assim. ― Parece que um ato do apetite sensitivo não pode ser ordenado.

1. ― Pois, diz o Apóstolo (Rm 7, 19): Porque eu não faço o bem, que quero; e a Glossa explica, que o
homem não quer ceder à concupiscência e contudo cede. Ora, ceder à concupiscência é ato do apetite
sensitivo. Logo, tal ato não está sujeito ao nosso império.

2. Demais. ― A transmutação formal da matéria corpórea só de Deus depende, como já se estabeleceu
na primeira parte. Ora, o ato do apetite sensitivo causa o calor e o frio, que são transmutações
corpóreas. Logo, o ato do apetite sensitivo não está sujeito ao império humano.

3. Demais. ― O motor próprio do apetite sensitivo é o apreendido pelo sentido ou pela imaginação. Ora,
não está sempre em nosso poder apreender desse modo um objeto. Logo, o ato do apetite sensitivo não
está sujeito à nossa ordem.
Mas, em contrário, diz Gregório Nisseno (Nemésio): o concupiscível e o irascível, que pertencem ao
apetite sensitivo, obedecem à razão. Logo, o ato desse apetite cai sob as ordens da razão.

SOLUÇÃO. ― Um ato cai sob nossas ordens na medida em que cai sob nosso poder, como já se disse.
Por onde, para se compreender como o ato do apetite sensitivo cai sob o império da razão necessário é
considerar como está em nosso poder. Ora, é de saber, que o apetite sensitivo difere do intelectivo,
chamado vontade, por ser virtude de um órgão corpóreo, o que não se dá com a vontade. Ora, todo ato
de uma potência, que se serve de órgão corpóreo, depende não só da potência da alma
correspondente, mas também da disposição do órgão corpóreo; assim, a visão depende da potência
visual e da qualidade dos olhos, que a facilita ou impede. Por onde, o ato do apetite sensitivo não só
depende da potência apetitiva, mas também, da disposição do corpo. Porém a atividade de uma
potência da alma resulta de uma apreensão ou imaginação. Ora, a apreensão imaginativa, sendo
particular, é regulada pela racional, que é universal, assim como uma virtude ativa particular é regulada
pela virtude ativa universal. E portanto, por este lado, o ato do apetite sensitivo está sujeito à razão; ao
passo que não o está a qualidade e a disposição do corpo; e isto impede que o movimento do apetite
sensitivo esteja totalmente sujeito ao império da razão. E pode mesmo acontecer que esse movimento
se precipite, subitamente, provocado pela apreensão da imaginação ou do sentido, e então escapa ao
império da razão embora esta pudesse preveni-lo se o previsse. E por isso o Filósofo diz que a razão
governa o irascível e o concupiscível, não com poder despótico, como o senhor governa o escravo, mas
com poder político ou real, como se dá com homens livres, que não estão sujeitos ao governo de modo
absoluto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Uma disposição do corpo, que impede o apetite
sensitivo de submeter-se totalmente ao império da razão é que leva o homem a ceder à concupiscência,
contra a sua vontade. E por isso o Apóstolo acrescenta, no mesmo lugar: Mas sinto nos meus membros
outra lei que repugna à lei do meu espírito. Também o mesmo acontece por causa do movimento súbito
da concupiscência, como já se disse.

RESPOSTA À SEGUNDA. ― A disposição do corpo mantém dupla relação com o ato do apetite sensitivo.
Ou ela é precedente, como quando alguém está disposto de certo modo, corporalmente, para tal ou tal
paixão; ou é conseqüente, como quando alguém se exalta, estando encolerizado. Ora, a disposição
precedente escapa ao império da razão porque procede da natureza ou de alguma precedente moção,
que não pode ser acalmada imediatamente. A disposição conseqüente porém esta sujeita a esse
império porque depende do movimento local do coração, que se move diversamente segundo os
diversos atos do apetite sensitivo.

RESPOSTA À TERCEIRA. ― Para a apreensão do sentido sendo necessário o sensível externo, não está
em nosso poder apreender nada, pelos sentidos, sem que o sensível esteja presente e essa presença
dele, o homem pode usar do sentido como quiser, a menos que haja impedimento por parte do órgão. A
apreensão imaginativa, porém, está a subordinada à razão, na medida em que a força ou fraqueza da
imaginação o permite. Assim, se um homem não pode imaginar a concepção racional, isso provém ou de
não serem imagináveis os seres concebidos, como os incorpóreos; ou da fraqueza da virtude
imaginativa, proveniente de alguma indisposição orgânica.

## Art. 8 — Se os atos da alma vegetativa estão sujeitos ao império da razão.
(II ª, II ª, q. 148, a . 1, ad 3 III, q. 15, a . 2, ad 1; q. XIX, a . 2; II Sent., dist. XX, q. 1, a . 2, ad 3; De Verit., q.
13, a . 4: Quodl., IV, q. 11, a 1).
O oitavo discute-se assim. ― Parece que os atos da alma vegetativa estão sujeitos ao império da
razão.

1. ― Pois, as forças sensitivas são mais nobres que as da alma vegetativa. Ora, aquelas estão sujeitas ao
império da razão. Logo, estas também forçosamente, hão de estar.

2. Demais. ― O homem é chamado um pequeno mundo, porque a alma é para o corpo o que Deus é
para o mundo. Ora, Deus está no mundo de modo tal que todas as coisas lhe obedecem ao império.
Logo, tudo o que existe no homem, incluindo-se as forças da alma vegetativa, obedece ao império da
razão.

3. Demais. ― Só os atos sujeitos ao império da razão são susceptíveis de louvor e de vitupério. Ora, os
atos das potências nutritiva e geratriz são susceptíveis de louvor e de vitupério, de virtude e de vício,
como o prova a gula, a luxúria e as virtudes opostas. Logo, os atos dessas potências estão sujeitos ao
império da razão.
Mas, em contrário, diz Gregório Nisseno (Nemésio): o que diz respeito à potência nutritiva e à geratriz
escapa à persuasão da razão.

SOLUÇÃO. ― Dos atos, uns procedem do apetite natural, outros, do animal ou intelectual; pois, todo
agente tende de certo modo para o fim. Ora, o apetite natural não é conseqüente a nenhuma
apreensão, como acontece com o apetite animal e com o intelectual. A razão, por outro lado, impera ao
modo de potência apreensora. Por onde, os atos procedentes do apetite intelectivo ou do animal
podem ser governados pela razão; mas não os procedentes do apetite natural. E por isso Gregório
Nisseno (Nemésio) diz, que se chama natural ao que pertence à potência geratriz e à nutritiva. Por onde,
o ato da alma vegetativa não está sujeito ao império da razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tanto mais imaterial é um ato e tanto mais nobre é e
mais sujeito ao império da razão. Por onde, as virtudes da alma vegetativa, não obedecendo à razão, são
íntimas.

RESPOSTA À SEGUNDA. ― No caso, a semelhança é parcial, e não total, pois, assim como Deus move o
mundo, assim a alma, o corpo; mas a alma não criou o corpo, do nada, com Deus criou o mundo, o que
explica que este lhe está totalmente sujeito ao império.

RESPOSTA À TERCEIRA. ― A virtude e o vício, o louvor e o vitupério não se atribuem aos atos mesmos
da potência nutritiva e da geratriz, a saber, a digestão e a formação do corpo humano; mas aos atos da
parte sensitiva ordenados aos das duas sobreditas potências, por exemplo, aos atos de concupiscência
relativos à gula e à sensualidade venérea, bem como ao exercício deles, conveniente ou inconveniente.

## Art. 9 — Se os membros do corpo obedecem à razão.
(I, q. 81, a . 3 ad 2; infra, q. 56 a . 4, ad 3; q. 58, a . 2; II Sent., dist. XX, q. 1, a . 2, ad 3; De Pot., q. 3, a . 15,
ad 4).
O nono discute-se assim. ― Parece que os membros do corpo não obedecem à razão.

1. ― Pois como se sabe, distam mais da razão que as virtudes da alma vegetativa. Ora, estas não
obedecem à razão, como já se disse. Logo, muito menos os membros do corpo.

2. Demais. ― O coração é o princípio do movimento animal. Ora, os movimentos do coração não estão
sujeitos ao império da razão; pois, como diz Gregório Nisseno (Nemésio), seu pulsar não é regulado pela
razão. Logo, o movimento dos membros corpóreos não está sujeito ao império da razão.

3. Demais. ― Como diz Agostinho, o movimento dos órgãos da geração, ora, é importuno e involuntário;
ora, não obedece à vontade, quando querido e o corpo fica frígido quando a concupiscência ferve na
alma. Logo, o movimento dos membros não obedece à razão.
Mas, em contrário, diz Agostinho: A alma ordena que a mão se mova e esta o faz com tanta felicidade,
que apenas se distingue a ordem, da execução.

SOLUÇÃO. ― Os membros do corpo são por assim dizer os órgãos das potências da alma; e portanto, do
modo por que estas obedecem à razão, desse mesmo também obedecem aqueles. Ora, como as
virtudes sensitivas estão sujeitas ao império da razão, mas não as naturais, assim também, todos os
movimentos dos membros resultantes das potências sensitivas estão sujeitos ao sobredito império; não
o estão porém, os resultantes das virtudes naturais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os membros não se movem a si mesmos mas são
movidos pelas potências da alma, das quais certas mais se aproximam da razão que as virtudes da alma
vegetativa.

RESPOSTA À SEGUNDA. ― No que respeita ao intelecto e à vontade, primeiro encontramos o que é
natural, donde o mais deriva; assim, do conhecimento natural dos primeiros princípios deriva o
conhecimento das conclusões; do fim naturalmente desejado pela vontade resulta a eleição dos meios.
Assim também, nos movimentos corpóreos, o princípio é natural. Pois, o princípio do movimento
corpóreo procede do movimento do coração; e por isso este é natural e não voluntário, resultando,
como acidente próprio, da vida, que procede da união do corpo com a alma. Semelhantemente, o
movimento dos corpos graves e leves resulta da forma substancial dos mesmos, e por isso se diz que são
movidos pelo gerador, conforme o Filósofo. E daqui vem que esse movimento se chama vital. Por onde,
diz Gregório Nisseno (Nemésio), que assim como a potência geratriz e a nutritiva não obedecem à razão,
assim também não obedece o movimento pulsativo, que é vital, assim designado essa expressão o
movimento do coração, que se manifesta pelas veias pulsáteis.

RESPOSTA À TERCEIRA. ― Como diz Agostinho, é por pena do pecado que o movimento dos membros
genitais não obedece a razão; de modo que a alma sofra a pena da sua desobediência a Deus,
precisamente no membro pelo qual o pecado original se transmite aos descendentes. Mas como pelo
pecado dos nossos primeiros pais, conforme a seguir se dirá, a natureza foi abandonada a si mesma,
privada do dom sobrenatural, que fora divinamente conferido ao homem, vejamos qual a razão natural
por que, em particular, o movimento desses membros não obedece à razão. Aristóteles, no livro De
causis motus animalium descobre a causa em os movimentos do coração e dos membros pudendos
serem involuntários; pois, estes se movem em conseqüência de alguma apreensão, em virtude da qual o
intelecto e a fantasia representam algo de que resultam paixões da alma, provocadoras de tal
movimento. E não se movem conforme a injunção da razão ou do intelecto porque para o movimento
de tais membros é necessária alguma alteração natural ― a calidez ou a frieza ― que não está sujeita ao
império da razão. ― E isso se dá especialmente com esses dois membros porque cada um deles é como
que um animal separado, enquanto princípio de vida; ora, o princípio é, virtualmente, o todo. Assim, o
coração é o princípio dos sentidos; e do membro genial procede a virtude seminal que constitui,
virtualmente, todo o animal. E por isso tem naturalmente movimentos próprios, por ser necessário que
os princípios sejam naturais, como já se disse.