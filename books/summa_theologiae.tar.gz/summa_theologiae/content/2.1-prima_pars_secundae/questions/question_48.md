# Questão 48: Dos efeitos da ira.
Em seguida devemos tratar dos efeitos da ira. E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se a ira causa o prazer.
O primeiro discute-se assim. — Parece que a ira não causa o prazer.

1. — Pois, a tristeza exclui o prazer. Ora, a ira vai sempre acompanhada da tristeza, porque, como diz
Aristóteles, quem age levado pela ira o faz com pena. Logo, a ira não causa o prazer.

2. Demais — Como diz o Filósofo, a punição acalma o ímpeto da ira, substituindo a alegria pela tristeza;
donde podemos deduzir que o prazer do irado lhe advém da punição. Ora, esta exclui a ira. Logo, a
presença do prazer elimina a ira, e portanto não é um efeito acompanhado de prazer.

3. Demais — Nenhum efeito impede a sua causa, porque lhe é conforme com ela. Ora, os prazeres
impedem a ira, como diz Aristóteles. Logo, o prazer não é efeito da ira.
Mas, em contrário, o Filósofo cita o provérbio seguinte: a ira, muito mais doce que o mel, que corre com
limpidez, se entumesce no peito dos homens.

SOLUÇÃO. — Como diz o Filósofo, os prazeres mais sensíveis e mais corpóreos são remédios contra o
sofrimento; por onde, quando recorremos ao prazer como remédio contra um grande sofrimento ou
ansiedade, tanto mais o sentimos; assim, na sede a água se nos torna mais agradável. Ora, é manifesto,
pelo sobreditoque o movimento da ira surge em nós provocado por alguma injúria a nós feita e que nos
penaliza, sendo então a vindicta o remédio contra essa pena. Por isso, da vingança presente resulta o
prazer e tanto maior quanto maior for a ofensa. — Por onde, se a vindicta se realizar, o prazer, que
exclui totalmente o sofrimento, torna-se completo e assim acalma o movimento da ira. Mas antes de ser
a vingança uma realidade atual, já ela se torna presente ao irado de dois modos: pela esperança, porque
ninguém se ira que não espere a vindicta, como já dissemos; ou pelo pensamento continuado, pois é-
nos deleitável demorar no pensamento daquilo que desejamos; isso explica nos sejam agradáveis
mesmo às imaginações do sonho. Por isso o irado se deleita revolvendo continuamente no ânimo o
pensamento da vingança. Contudo, não é um prazer perfeito que elimina o sofrimento, e por
conseguinte a ira.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O irado não sofre e alegra com um mesmo objeto; mas
sofre com a injúria e goza com a vingança planejada e esperada. Por onde, o sofrimento está para a ira
como um princípio; o prazer porém, como efeito ou termo.

RESPOSTA À SEGUNDA. — A objeção procede quanto ao prazer causado pela realização da vingança,
que exclui totalmente a ira.

RESPOSTA À TERCEIRA. — O prazer precedente exclui o sofrimento e por conseguinte, a ira. Porém o
prazer da vindicta é consecutivo à ira.

## Art. 2 — Se o ardor é, por excelência, efeito da ira.
O segundo discute-se assim. — Parece que o ardor não é, por excelência, efeito da ira.

1. — Pois, como já se disse, o ardor é relativo ao amor. Ora este, como também já se disse, é o princípio
e a causa de todas as paixões. Ora, sendo a causa mais poderosa que o efeito, resulta que a ira não
causa, por excelência, o ardor.

2. Demais — O que em si mesmo excita o ardor aumenta cada vez mais no decorrer do tempo; assim, o
amor diuturno mais se fortifica. Ora, a ira diminui com o passar do tempo, pois, como diz o Filósofo, o
tempo acalma a ira. Logo, esta não causa, propriamente o ardor.

3. Demais — O ardor aumenta o ardor. Ora, uma ira maior, superveniente, faz diminuir a menor, como
diz o Filósofo. Logo, a ira não causa o ardor.
Mas, em contrário, diz Damasceno, que a ira é ardor do sangue no coração, proveniente da evaporação
do fel.

SOLUÇÃO. — Como já dissemos, a transmutação corpórea provocada pelas paixões da alma é
proporcionada ao movimento do apetite. Ora, é manifesto que qualquer apetite, ainda natural, tende
mais fortemente ao que lhe é contrário, se este estiver presente; e por isso vemos a água aquecida
congelar-se mais fortemente, quase por ação mais veemente do frio sobre o quente. Ora, o movimento
apetitivo da ira é causado por alguma injúria que nos é feita, como pelo que é presentemente contrário.
Por isso, o apetite tende principalmente, a repelir a injúria, pelo desejo da vindicta; donde uma grande
veemência e impetuosidade no movimento da ira. E como este não se dá por retração, a que o frio é
proporcionado, mas antes, pela prossecução, a que é proporcionado o calor, conseqüentemente o
movimento da ira causa um certo ardor do sangue e dos espíritos no coração, que é o instrumento das
paixões da alma. Donde vem que, por causa da intensa perturbação do coração, que acompanha a ira,
sobretudo nos irados se manifestam certos indícios, nos membros exteriores. Pois, como diz
Gregório, estimulado pela ira, o coração, incendiado, palpita, o corpo treme, a língua trava-se as faces
afogueiam-se, excitam-se os olhos e já os conhecidos de nenhum modo se reconhecem; a boca do irado
quer gritar mas ignora o sentido o que haja de dizer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O amor em si mesmo, como diz Agostinho, nós não o
sentimos senão quando o perdemos. Por onde, quanto mais sofremos, pela injúria que nos é feita,
detrimento nalguma excelência amada, tanto mais sentimos o amor, e portanto mais ardorosamente o
coração se nos altera, afim de remover o impedimento que nos separa do objeto amado; de modo que a
ira aumenta e faz sentirmos mais o ardor amoroso. Contudo, o ardor resultante do calor pertence-lhe,
por uma razão, e, por outra, à ira. Pois, o ardor amoroso é acompanhado de certa doçura e suavidade,
por ter por objeto o bem amado; e daí vem o assemelhar-se ao calor do ar e do sangue; e isso explica
que os sanguíneos são mais amorosos, e o dizer-se que o fígado provoca o amor, no qual se opera uma
certa geração do sangue. O ardor da ira porém é acompanhado de amargura consumptiva, porque
tende à punição do contrário; por isso é assimilado ao calor do fogo e da cólera; donde o dizer
Damasceno, que a ira procede da evaporação do fel e é chamada félea.

RESPOSTA À SEGUNDA. — Aquilo cuja causa se enfraquece com o tempo necessariamente há-de ir-se
debilitando. Ora, é manifesto, que a memória se enfraquece com o tempo, pois os fatos antigos
facilmente lhe escapam. E sendo a ira causada pela memória da injúria feita, a sua causa há-de, por
força, diminuir com o tempo, paulatinamente, até desaparecer. E isso explica que a injúria parece maior
logo depois de sentida, diminuindo-se-lhe a importância que lhe damos quando mais ela se esbate no
sentimento atual. O mesmo se dá com o amor, se a sua causa permanecer só na memória. Donde o
dizer do Filósofo, que a ausência diuturna do amigo parece fazer esquecer a amizade. Ao contrário, com
a presença dele, sempre a causa da amizade se intensifica no tempo e, portanto, a amizade cresce. E o
mesmo se daria com a ira se a sua causa se multiplicasse continuamente. Contudo, o fato mesmo de ela
consumir-se rapidamente atesta-lhe o veemente ardor. Pois assim como um grande fogo logo se
extingue, uma vez consumida a sua matéria, assim também a ira, pela sua veemência, logo se
desvanece.

RESPOSTA À TERCEIRA. — Toda virtude, dividida em muitas partes, logo diminui. Por isso, quando nos
iramos contra uma pessoa e, logo a seguir, contra outra, por isso mesmo a primeira ira diminui,
sobretudo se a segunda for maior. Pois, a injúria que provocou a ira contra a primeira, será considerada
pequena ou nula comparada com a segunda, julgada maior.

## Art. 3 — Se a ira priva da razão.
(De Malo, q. XII, a . 1).
O terceiro discute-se assim. — Parece que a ira não priva da razão.

1. — Pois, o que vai acompanhado da razão parece que não nos pode privar dela. Ora, a ira é
acompanhada da razão, como diz Aristóteles. Logo, não nos priva da mesma.

2. Demais — Quanto mais privados formos da razão, tanto menos podemos nos exteriorizar. Ora, o
Filósofo diz, que o iracundo não o é oculta, mas manifestamente. Logo, parece que a ira não priva do
uso da razão, como a concupiscência, que é insidiosa, conforme diz ainda ele, no mesmo lugar.

3. Demais — O juízo da razão torna-se mais claro pela adjunção do elemento contrário, pois os
contrários, juxtapostos, aumentam a clareza. Ora, isto mesmo faz crescer a ira, pois, como diz o
Filósofo, os homens tornam-se mais irados quando os contrários preexistem; isso se dá, p. ex., com os
honrados que perdem a honra. Logo, a mesma causa que aumenta a ira também fortifica o juízo da
razão. Portanto, aquela não impede este.
Mas, em contrário, diz Gregório, que a ira priva da luz a inteligência, agitando a mente na confusão.

SOLUÇÃO. — A mente ou razão, embora não dependa, pra o seu ato próprio, de um órgão corpóreo,
contudo, como depende, para o mesmo, de certas potências sensitivas, cujos atos ficam impedidos pela
perturbação do corpo, necessariamente as perturbações corpóreas hão-de impedir também o juízo da
razão, como mui claramente o manifesta a embriaguez e o sono. Pois, como já dissemos, a ira produz
perturbação corpórea sobretudo no coração e de modo tal que esta deriva até para os membros
exteriores. Por onde, dentre as demais paixões, ela é a que mais manifestamente nos priva do uso da
razão, conforme aquilo da Escritura (Sl 30, 10): Conturbados com a ira estão os meus olhos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O movimento apetitivo, elemento formal da ira, tem na
razão o seu princípio. Mas, pelo seu elemento material, que é a comoção do calor, que impede
velozmente, a paixão da ira trava o juízo perfeito da razão, quase não obedecendo perfeitamente a esta.
E assim impede o seu uso.

RESPOSTA À SEGUNDA. — Diz-se que o iracundo o é manifestamente, não que lhe seja manifesto o que
deva fazer, mas por obrar desse modo, não buscando ocultar-se de maneira nenhuma. E isso se dá em
parte pela privação da razão, que não pode discernir o que deve ocultar e o que deve manifestar, e nem
mesmo pensar nos meios de ocultar; e em parte, pelo dilatar-se do coração, causado pela
magnanimidade, que a ira produz. Por onde, o Filósofo diz, que o magnânimo ama e odeia
manifestamente, e manifestamente fala e age. Porém dizemos da concupiscência que é latente e
insidiosa, por, no mais das vezes, o prazer desejado ser acompanhado de certa torpeza e malícia, que
queremos esconder. Apraz-nos, entretanto, agir manifestamente, quando devemos manifestar a
virilidade e a excelência, como é o caso da vingança.

RESPOSTA À TERCEIRA. — Como já dissemos, o movimento da ira tem na razão a sua origem. Por onde,
a aposição de um contrário a outro, no mesmo ponto de vista, fortifica o juízo da razão e aumenta a ira.
Assim, parece-nos maior o detrimento que sofremos na honra ou nas riquezas, que possuíamos, quer
pela vizinhança do contrário, quer por ser inopinado. Por isso causa sofrimento maior, assim como
também grandes bens, surgindo inopinados, causam maior prazer. E, conforme a intensidade do
sofrimento precedente, cresce também a ira, conseqüentemente.

## Art. 4 — Se a ira causa a taciturnidade.
O quarto discute-se assim. — Parece que a ira não causa a taciturnidade.

1. — Pois, a taciturnidade se opõe à loquacidade. Ora, a ira, no seu crescer provoca-nos a fala, como se
vê claramente pelos graus da mesma, que o Senhor assinala, dizendo (Mt 5, 22): O que se ira contra seu
irmão; e o que disser a seu irmão: Raca; e o que lhe disser: és um tolo. Logo, a ira não causa a
taciturnidade.

2. Demais — É por faltar à vigilância da razão que o homem prorrompe em palavras desordenadas;
donde o dito da Escritura (Pr 25, 28): Assim como é uma cidade toda aberta e que não está cercada de
muros, assim é o homem que quando fala não pode conter o seu espírito. Ora, a ira impede, por
excelência, o juízo da razão, como já dissemos (a. 3). Logo, leva-nos, sobretudo a prorromper em
palavras desordenadas. Portanto, não causa a taciturnidade.

3. Demais — Diz a Escritura (Mt 12, 34): A boca fala do que está cheio o coração. Ora, pela ira o coração
fica soberanamente perturbado, como já dissemos. Logo, causa principalmente à loquacidade e, não
portanto, a taciturnidade.
Mas, em contrário, diz Gregório, que a ira reprimida pelo silêncio, estua mais veemente no coração.

SOLUÇÃO. — A ira, como já dissemos, é, de um lado, acompanhada da razão, e de outro, priva-nos dela.
E, em ambos os casos, pode causar a taciturnidade. No primeiro, quando o juízo da razão, embora não
coíba o afeto do desejo desordenado da vingança, tem contudo vigor para coibir a língua de expressões
desordenadas. Donde o dizer Gregório: Às vezes a ira impõe silêncio, quase por um juízo, ao espírito
perturbado. — No segundo caso, porque, como já dissemos, a perturbação da ira é levada até às partes
exteriores do corpo e sobretudo, àquelas onde se manifesta mais expresso o influxo do coração, como
os olhos, a face e a língua; e por isso, como já se disse, a língua trava-se, as faces afogueiam-se,
incendem-se os olhos; podendo ser tal a perturbação da ira que prive absolutamente a língua do uso da
palavra. Daí resulta a taciturnidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A intensidade da ira chega às vezes até impedir a razão
de dominar a língua; outras vezes, vai mesmo além, até impedir o movimento da língua e dos outros
órgãos externos do corpo.
Donde se deduz clara a RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — A perturbação do coração pode às vezes ser tão intensa a ponto de impedir,
pelo seu movimento desordenado, o movimento dos órgãos exteriores; o que causa a taciturnidade, a
imobilidade dos membros exteriores e até mesmo a morte. Se porém não for tamanha a perturbação, a
boca desata a falar, pela superabundância do coração perturbado.
Tratado dos hábitos
Depois dos atos e das paixões, devemos tratar dos princípios dos atos humanos. Primeiro, dos princípios
intrínsecos. Segundo, dos princípios extrínsecos. Ora, o princípio intrínseco é a potência e o hábito. Mas
como na Primeira Parte já tratamos das potências (q. 77, sqq.), resta agora tratar dos hábitos.
Primeiro, em geral. Segundo, das virtudes, dos vícios e dos outros hábitos semelhantes, que são os
princípios dos atos humanos.
A respeito dos hábitos em geral, quatro pontos devemos considerar. Primeiro, da substância dos
hábitos. Segundo, do sujeito deles. Terceiro, da causa da geração, do aumento e da corrupção dos
mesmos. Quarto, da distinção entre eles.