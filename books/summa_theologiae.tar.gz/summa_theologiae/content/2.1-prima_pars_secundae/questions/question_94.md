# Questão 94: Da lei natural.
Em seguida, devemos tratar da lei natural. E nesta questão discutem-se seis artigos:

## Art. 1 — Se a lei natural é um hábito.
No que concerne ao primeiro artigo, assim se procede. Parece que a lei natural é um hábito.

1. – Pois, como diz o Filósofo, “é tríplice o que há na alma: a potência, o hábito e a afecção”. Ora, a lei
natural não é uma das potências da alma e nem uma das afecções, o que é patente se forem estas
enumeradas uma a uma. Portanto, a lei natural é um hábito.

2. Demais – Além disso, Basílio diz que a consciência ou sindérese é “a lei do nosso intelecto”, o que não
se pode inteligir senão da lei natural. Ora, a sindérese é certo hábito. Portanto, a lei natural é um hábito.

3. Demais – Além disso, a lei natural permanece sempre no homem, como adiante se tornará patente.
Ora, nem sempre a razão do homem, à qual pertence, pensa na lei natural. Logo, a lei natural não é um
ato, mas um hábito.
Em sentido contrário, há o que diz Agostinho: “um hábito é algo de que se utiliza quando é necessário”.
Ora, não é assim a lei natural, pois é inerente aos recém-nascidos e aos condenados, que por ela não
podem agir. Portanto, a lei natural não é um hábito.

SOLUÇÃO. — Deve dizer-se que algo pode ser dito hábito de dois modos. De um modo, própria e
essencialmente e, assim, a lei natural não é hábito. Foi dito acima que a lei natural é algo constituído
pela razão, assim como a proposição é uma obra da razão. Ora, não é idêntico o que alguém faz e o por
que alguém age: assim, alguém, pelo hábito da gramática, produz uma oração correta. Dado pois ser o
hábito aquilo “por que” alguém age, não pode ocorrer que alguma lei seja hábito própria e
essencialmente. De outro modo, pode dizer-se hábito aquilo que se possui por meio de um hábito,
como se diz fé aquilo que se possui pela fé. E, desse modo, porque os preceitos da lei natural são por
vezes considerados em ato pela razão; por vezes, porém, são-lhe inerentes de modo somente habitual,
pode dizer-se do segundo modo ser a lei natural um hábito. Da mesma forma, os princípios
indemonstráveis dos atos especulativos não são o próprio hábito dos princípios, mas são os princípios
aos quais se refere o hábito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No que concerne ao primeiro argumento, deve dizer-se
que, na passagem, o Filósofo intenciona investigar o gênero da virtude: e como é manifesto ser a virtude
certo princípio do ato, relaciona apenas os princípios dos atos humanos: as potências, os hábitos, as
afecções. Todavia, além destes, há na alma outros três a considerar: certos atos, como o querer é
naquele que quer e aquilo que se conhece no conhecedor e também as propriedades naturais da alma
são-lhe inerentes, como, por exemplo, a imortalidade e outras semelhantes.

RESPOSTA À SEGUNDA. — No que concerne ao segundo argumento, deve dizer-se que a sindérese diz-
se lei do nosso intelecto, enquanto é o hábito que contém os princípios da lei natural, que são os
primeiros princípios das obras humanas.

RESPOSTA À TERCEIRA. — No que concerne ao terceiro argumento, deve dizer-se que a razão alegada
conclui que a lei natural é algo de que se é dotado habitualmente. E isto, nós o concedemos.No que
concerne à objeção em sentido contrário, deve dizer-se que alguém pode, por vezes, não usar o que lhe
é habitualmente inerente por força de algum impedimento, como um homem não pode usar o hábito
da ciência em razão do sono. E também, a criança não pode usar o hábito de inteligência dos princípios
e mesmo da lei natural, que lhe é habitualmente inerente, por causa da deficiência própria à idade.
Art. 2— Se a lei natural contém muitos preceitos ou um só.
No que concerne ao segundo artigo, assim se procede. Parece que a lei natural não contém muitos
preceitos, mas somente um.

1. – Com efeito, a lei está contida no gênero do preceito. Se houvesse, portanto, múltiplos preceitos da
lei natural, seguir-se-ia haver também múltiplas leis naturais.

2. Demais – Além disso, a lei natural é consequente à natureza do homem. Ora, a natureza humana é
uma em seu todo, embora seja múltipla em suas partes. Assim, pois, ou é um apenas o preceito da lei da
natureza, por causa da unidade do todo, ou são muitos, por causa da multiplicidade das partes da
natureza humana. E assim será necessário que também as inclinações próprias ao concupiscível
pertençam à lei natural.

3. Demais – Além disso, a lei é algo pertinente à razão. Ora, a razão é, no homem, somente uma. Logo,
só há um preceito da lei natural.
Há, em sentido contrário, que no homem os preceitos da lei natural estão para as obras a realizar-se
como estão os primeiros princípios da demonstração. Ora, os primeiros princípios indemonstráveis são
múltiplos. Portanto, são também múltiplos os preceitos da lei da natureza.

SOLUÇÃO. — Deve dizer-se que os preceitos da lei da natureza estão para a razão prática do mesmo
modo que os princípios primeiros da demonstração estão para a razão especulativa: uns e outros são
princípios conhecidos por si mesmos. Ora, algo diz-se por si mesmo conhecido duplamente: de um
modo, em si; de outro modo, quanto a nós. Em si, qualquer proposição diz-se por si conhecida se o seu
predicado é da razão do sujeito. Ocorre porém que, para aquele que ignora a definição do sujeito, tal
proposição não será conhecida por si mesma. Assim, esta proposição: “o homem é racional”, é por si
mesma conhecida segundo sua natureza, pois quem diz homem, diz racional. Todavia, para quem ignora
o que é o homem, esta proposição não é por si conhecida. Disto segue-se, como o diz Boécio, há
dignidades ou proposições conhecidas por si mesmas comumente a todos e são tais aquelas
proposições cujos termos são conhecidos por todos, como “qualquer todo é maior que sua parte” e “os
que são iguais a um terceiro, são iguais entre si”.
Há, porém, certas proposições conhecidas por si mesmas apenas para os sábios, os quais inteligem o
significado de seus termos: assim àquele que intelige que um anjo não é corpo, é conhecido por si
mesmo não ser circunscrito a um lugar, o que não é manifesto aos rudes, que não o captam. Ora, entre
aquelas proposições ao alcance da apreensão de todos há, porém, certa ordem. Pois o que primeiro cai
sob a apreensão é o ente, cuja intelecção está inclusa em tudo que alguém apreende. Eis por que o
primeiro princípio indemonstrável é que não se pode simultaneamente afirmar e negar, que está
fundado sobre a razão do ente e do não ente. Sobre este princípio todos os demais estão
fundamentados, como se diz na Metafísica. Ora, assim como o ente é aquilo que, primeiro, pura e
simplesmente, cai sob a apreensão, assim também o bem é aquilo que primeiro cai sob a razão prática,
a qual está ordenada para a obra, pois todo agente age em vista do fim e este é dotado da razão de
bem. Dessa forma, o primeiro princípio da razão prática está fundamentado sobre a razão de bem e é o
seguinte: “o bem é aquilo que todos apetecem”. Portanto, este é o primeiro preceito da lei: “o bem
deve ser praticado e procurado, o mal deve ser evitado”. Sobre isso estão fundamentados todos os
demais preceitos da lei da natureza, de tal modo que tudo o que deve ser praticado ou evitado, que a
razão prática naturalmente apreende ser bem humano, pertence aos preceitos da lei da natureza. Ora,
porque o bem tem razão de fim e o mal razão de seu contrário, daí segue-se que tudo aquilo para que
tem o homem uma inclinação natural, a razão naturalmente apreende como bom e, por conseguinte,
como obra a ser praticada, e o seu contrário como mal a ser evitado. Assim, segundo a ordem das
inclinações naturais, segue-se a ordem dos preceitos da lei da natureza. Pois é primeiro inerente ao
homem a inclinação para o bem segundo a natureza que tem em comum com todas as substâncias, qual
seja, toda a substância apetece a conservação de seu ser segundo a sua natureza.E segundo essa
inclinação pertence à lei natural tudo aquilo porque é conservada a vida do homem e que impede o que
lhe é contrário. Em segundo lugar é inerente ao homem a inclinação para algo mais especial, segundo a
natureza que tem em comum com os outros animais.
E segundo isso, diz-se ser da lei natural “aquilo que a natureza ensinou a todos os animais”, como a
união do macho e da fêmea, a educação dos filhos e similares. Em terceiro lugar é inerente ao homem a
inclinação para o bem segundo a natureza da razão que lhe é própria, como ter o homem uma
inclinação natural para conhecer a verdade sobre Deus e viver em sociedade. E segundo isto pertence à
lei natural aquilo que diz respeito a esta inclinação como que o homem evite a ignorância, não ofenda a
outros com os quais deve conviver, e tudo o mais que a isso diz respeito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No que concerne ao primeiro argumento, deve dizer-se
que todos esses preceitos da lei da natureza, na medida em que são referentes a um só primeiro
preceito, têm a razão de uma única lei natural.

RESPOSTA À SEGUNDA. — No que concerne ao segundo argumento, deve dizer-se que todas as
inclinações de quaisquer partes da natureza humana, como as do concupiscível e do irascível, segundo
são reguladas pela razão, pertencem à lei natural, e são reduzidas a um primeiro preceito, como se
disse. E, segundo isso, são múltiplos, em si mesmos, os preceitos da lei da natureza, os quais,
entretanto, têm em comum uma só raiz.

RESPOSTA À TERCEIRA. — No que concerne ao terceiro argumento, deve dizer-se que a razão, embora
seja em si una, é, todavia, a ordenadora de tudo o que diz respeito ao homem. E, segundo isto, está
contido sob a lei da razão tudo o que pode ser regulado pela razão.
Art 3 — Se todos os atos das virtudes são de lei da natureza.
No que concerne ao terceiro artigo assim se procede. Parece que nem todos os atos das virtudes são
da lei da natureza.

1. – Isto porque, é de razão da lei ordenar para o bem comum. Ora, certos atos das virtudes ordenam-se
para o bem particular de alguém, como é patente, sobretudo, nos atos da temperança. Portanto, nem
todos os atos das virtudes são subordinados à lei natural.

2. Demais – Além disso, todos os pecados opõem-se a alguns atos virtuosos. Se, pois, todos os atos das
virtudes são da lei da natureza, parece, por conseguinte, serem todos os pecados contra a natureza.
Ora, isto diz-se em especial de alguns pecados.

3. Demais – Além disso, todos estão de acordo quanto àquilo que é segundo a natureza. Mas nem todos
estão de acordo quanto aos atos das virtudes. Com efeito, algo é virtuoso para um, é vicioso para
outros. Portanto, nem todos os atos as virtudes pertencem à lei da natureza.
Há em contrário o que diz Damasceno: “as virtudes são naturais”. Portanto, também os atos virtuosos
são subordinados à lei da natureza.

SOLUÇÃO. — Deve dizer-se que podemos falar duplamente dos atos virtuosos. De um modo, enquanto
são virtuosos; de outro modo, enquanto são tais atos considerados em suas espécies próprias. Se
falamos dos atos das virtudes enquanto são virtuosos, dessa forma todos os atos virtuosos pertencem à
lei da natureza. Foi dito, com efeito, que pertence à lei da natureza tudo aquilo para que o homem se
inclina segundo sua natureza. Ora, cada qual se inclina para a operação que lhe é conveniente segundo a
sua forma, como o fogo para aquecer. Donde, por ser a alma racional a forma própria do homem, a
inclinação natural é inerente a qualquer homem em vista de agir segundo a razão e isto é precisamente
o agir segundo a virtude. Donde, segundo isto, todos os atos das virtudes são da lei natural, pois a
própria razão dita a cada um precisamente isto: agir virtuosamente. Mas se falamos dos atos virtuosos
segundo eles próprios, na medida em que são considerados em suas próprias espécies, então nem todos
os atos virtuosos são da lei da natureza. Com efeito, muito se faz, segundo a virtude, para o que a
natureza não inclina, em primeiro lugar, mas que os homens vieram a descobrir mediante a pesquisa da
razão como sendo útil para o bem viver.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No que concerne ao primeiro argumento, deve dizer-se
que a temperança concerne às concupiscências naturais do alimento, da bebida e do sexo, as quais se
ordenam ao bem comum da natureza, assim como outras matérias legais ordenam para o bem comum
moral.

RESPOSTA À SEGUNDA. — No que concerne ao segundo argumento, deve dizer-se que se pode dizer
natureza do homem de um lado a que é própria ao homem, e, quanto a isto, todos os pecados, por
serem contra a razão, são também contra a natureza, como é patente na argumentação de Damasceno
no “Sobre a fé ortodoxa”. De outro lado, a que é comum aos homens e aos outros animais e, quanto a
isto, alguns pecados especiais dizem-se ser contra a natureza, como, por oposição à união do macho e
da fêmea, que é natural a todos os animais, há o coito dos machos que se diz especialmente vício contra
a natureza.

RESPOSTA À TERCEIRA. — No que concerne ao terceiro argumento, deve dizer-se que a razão alegada
procede da consideração dos atos em si mesmos. Assim sendo, por causa das diversas condições dos
homens, ocorre que alguns atos sejam virtuosos para alguns enquanto são-lhes proporcionados e
convenientes, os quais, entretanto, são viciosos para outros, por não lhes serem proporcionados.

## Art. 4 — Se a lei da natureza é uma em todos.
No que concerne ao quarto artigo assim se procede. Parece que a lei da natureza não é uma em todos.

1. – Com efeito, diz-se nos Decretos que “o direito natural é o que está contido na lei e no Evangelho”.
Ora, isto não é comum para todos, pois, como se diz na carta aos Romanos, “nem todos obedecem ao
Evangelho”. Portanto, a lei natural não é a mesma para todos.

2. Demais – Além disso, “aquelas ações que são segundo a lei dizem-se justas”, como está escrito na
Ética. Mas no mesmo livro diz-se que nada é de tal modo justo em todos, sem que seja diversificado em
alguns. Portanto, também a lei natural não é a mesma em todos.

3. Demais – Além disso, à lei da natureza pertence aquilo para o que está inclinado o homem segundo
sua natureza. Mas homens diversos inclinam-se naturalmente para bens diversos: alguns para a
concupiscência das volúpias, outros, para os desejos das honrarias, outros, para outros bens. Portanto, a
lei natural não é uma em todos.
Em sentido contrário, há o que diz Isidoro: “o direito natural é comum a todas as nações”.

SOLUÇÃO. — Deve dizer-se que, pertence à lei da natureza aquilo para que o homem naturalmente se
inclina e nisto está incluído o que é próprio ao homem, inclinar-se para agir segundo a razão. Ora,
pertence à razão proceder do comum ao próprio, como é patente na Física. Todavia, a este respeito, um
é o comportamento da razão especulativa e outro o da razão prática.Assim, porque a razão especulativa
trabalha sobretudo na esfera do necessário, ao qual é impossível ser de outro modo, descobre-se sem
nenhuma falha a verdade nas conclusões próprias, como nos princípios comuns. Mas a razão prática
trabalha com o contingente, no qual estão as operações humanas e, assim, embora no que é comum
haja alguma necessidade, quanto mais se desce ao próprio, tanto mais se encontra falha.Dessa forma,
portanto, no especulativo é a mesma a verdade para todos, tanto nos princípios quanto nas conclusões,
embora, nas conclusões, a verdade não seja conhecida por todos, mas apenas nos princípios que se
dizem concepções comuns.No que é operativo, porém, não é a mesma a verdade ou a retidão prática
em todos quanto ao que é próprio, mas somente quanto ao que é comum, e mesmo para aqueles, para
os quais é a mesma a retidão no que é próprio, não é ela igualmente conhecida por todos. Desse modo
é patente que, quanto aos princípios comuns da razão especulativa ou prática, a verdade ou retidão é
para todos a mesma e igualmente conhecida.
Quanto, porém, às conclusões próprias da razão especulativa, é a mesma a verdade para todos, mas não
é por todos igualmente conhecida: para muitos, com efeito, é verdadeiro que o triângulo tem três
ângulos iguais a dois retos, embora isto não seja por todos conhecido. Mas quanto às conclusões
próprias da razão prática, nem é a mesma para todos a verdade ou retidão, nem para aqueles para os
quais é a mesma, é igualmente conhecida. Com efeito, para todos é reto e verdadeiro agir segundo a
razão. Deste princípio segue-se uma conclusão própria: é obrigatório restituir os depósitos. E isto é
verdadeiro na maioria dos casos; mas pode ocorrer em algum caso que seja danoso e, por conseguinte,
contra a razão, que se restituam os depósitos, por exemplo, se alguém os reivindica para combater a
pátria. Esta deficiência se manifesta tanto mais, quanto mais se desce ao particular, por exemplo, se se
estipula que os depósitos devem ser restituídos com tal caução ou de tal modo: quanto mais numerosas
forem as condições particulares apostas, tanto mais serão os modos segundo os quais se poderá falhar,
de maneira que não seja reto dever-se ou não restituir.Assim, deve dizer-se que a lei da natureza,
quanto aos primeiros princípios comuns, é a mesma em todos, tanto segundo a retidão, quanto segundo
o conhecimento. Mas quanto ao que é próprio e como que as conclusões dos princípios comuns é a
mesma para todas as mais das vezes, tanto segundo a retidão, quanto segundo o conhecimento; mas
em poucos casos pode ela falhar, seja quanto à retidão, por causa de alguns impedimentos (como
também as naturezas sujeitas à geração e à corrupção falham em uns poucos casos por causa de
impedimentos), seja quanto ao conhecimento. Isto ocorre porque alguns têm a razão depravada pela
paixão, por um mal costume ou por uma disposição má da natureza como, por exemplo, entre os
antigos germanos o latrocínio não era reputado iníquo, embora seja expressamente contra a lei da
natureza, como o relata Júlio César.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No que concerne ao primeiro argumento, deve dizer-se
que tal palavra não deve ser entendida como se todos os preceitos que estão contidos na lei ou no
Evangelho, sejam da lei da natureza, já que muito do que aí é transmitido está acima da natureza, mas
no sentido de a lei da natureza ser aí transmitida de forma plena. Assim, ao dizer Graciano que “o direito
natural é o que está contido na Lei e no Evangelho”, de imediato acrescentou: “por força do qual, cada
um recebe a ordem de fazer a outrem o que quer que lhe façam”.

RESPOSTA À SEGUNDA. — No que concerne ao segundo argumento, deve dizer-se que a palavra do
Filósofo deve entender-se do que é naturalmente justo, não enquanto princípios comuns, mas como
certas conclusões destes derivadas, as quais são dotadas de retidão, as mais da vezes, e umas poucas
vezes falham.

RESPOSTA À TERCEIRA. — No que concerne ao terceiro argumento, deve dizer-se que, assim como a
razão no homem domina as demais potências, assim também é necessário que todas as inclinações
naturais, pertencentes às demais potências, sejam ordenadas segundo a razão. Donde ser comumente
reto para todos que todas as inclinações dos homens sejam dirigidas segundo a razão.

## Art. 5 — Se a lei da natureza pode ser mudada.
No que concerne ao quinto artigo assim se procede. Parece que a lei da natureza pode ser mudada.

1. – Pois, sobre a passagem do Eclesiástico: “Acrescentou-lhes a disciplina e a lei da vida”, diz a glosa:
“Quis fosse a lei escrita para a correção da lei natural”. Mas o que é corrigido é mudado. Portanto, a lei
natural pode ser mudada.

2. Demais – Além disso, a morte de um inocente, o adultério e o furto são contra a lei natural. Ora, isto
encontra-se mudado por Deus, seja quando Este ordenou a Abraão que matasse o filho inocente,
conforme Gênesis, seja quando ordenou aos judeus que levassem consigo os vasos tomados de
empréstimo aos egípcios, segundo Êxodo, seja quando ordenou a Oséias que recebesse por esposa uma
prostituta. Portanto, a lei natural pode ser mudada.

3. Demais – Além disso, diz Isidoro no Livro das Etimologias que “a posse comum de todos os bens e
igual liberdade é de direito natural”. Mas vemos que tais leis foram mudadas pelas leis humanas.
Portanto, parece que a lei natural é mutável.
Em sentido contrário, há o que se diz nos Decretos: “o direito natural vigora desde a origem da criatura
racional. Não varia no tempo, mas permanece imutável”.

SOLUÇÃO. — Deve dizer-se que se pode entender a mudança da lei natural duplamente. De um modo,
por meio de algo que se lhe acrescenta. Dessa forma, nada proíbe ser a lei natural mudada, pois muito
foi acrescentado à lei natural, tanto pela lei divina, quanto por leis humanas para utilidade da vida
humana. De outro modo se entende a mudança da lei natural a modo de subtração, de forma que algo
deixe de ser de lei natural, que primordialmente vigorara segundo a lei natural.E, assim, quanto aos
primeiros princípios da lei da natureza é esta de todo imutável. Quanto, porém, aos preceitos segundos,
que dissemos ser como que conclusões próprias próximas dos primeiros princípios, nisto a lei natural
não muda sem que as mais das vezes seja sempre reto o que a lei natural contém. Pode, porém, mudar
em algo particular e em poucos casos, em razão de algumas causas especiais que impedem a
observância de tais preceitos, como se disse acima.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No que concerne ao primeiro argumento, deve dizer-se
que se diz que a lei escrita foi dada para a correção da lei da natureza, ou porque pela lei escrita
completou-se o que faltava à lei da natureza, ou porque a lei da natureza, quanto a alguns preceitos,
corrompera-se nos corações de alguns, de modo tal a julgarem ser boas ações naturalmente más e tal
corrupção necessitava de correção.

RESPOSTA À SEGUNDA. — No que concerne ao segundo argumento, deve dizer-se que, por morte
natural comum, morrem todos, tanto os nocivos quanto os inocentes. Tal morte natural foi introduzida
pelo poder divino em razão do pecado original, conforme se diz em Reis: “Deus faz morrer (e viver)”.
Dessa forma, por mandado divino, pode infligir-se a morte a qualquer homem, nocivo ou inocente sem
nenhuma injustiça. Da mesma forma, o adultério é o coito com a mulher de outrem, a qual é-lhe
destinada segundo lei divinamente transmitida. Donde, se alguém tem acesso a qualquer mulher por
mandado divino, não há adultério nem fornicação. E o mesmo vale para o furto, que é a tomada de
coisa alheia. O que alguém recebe por mandado de Deus, que é o Senhor de tudo, não o recebe sem a
vontade do Senhor, no qual consiste o furto. Mas não é só nas coisas humanas que, se algo é ordenado
por Deus, isto é devido, mas também nas coisas naturais o que é obra de Deus é a seu modo natural,
como se disse na Primeira Parte.

RESPOSTA À TERCEIRA. — No que concerne ao terceiro argumento, deve dizer-se que algo diz-se de
direito natural duplamente. De um modo, porque a natureza a isto inclina, como não se dever fazer
injúria a outrem. De outro modo, porque a natureza não induziu o contrário, como podemos dizer que
estar o homem nu é de direito natural, porque a natureza não o dotou de veste, mas inventou-a a arte.
Desse modo “a posse comum de todos os bens e a igual liberdade de todos diz-se ser de direito
natural”. Com efeito, a distinção das posses e a servidão não foram introduzidas pela natureza, mas pela
razão dos homens, para utilidade da vida humana. E, assim, nisto a lei da natureza não foi mudada a não
ser por uma adição.

## Art. 6 — Se a lei da natureza pode ser abolida do coração do homem.
No que concerne ao sexto artigo, assim se procede. Parece que a lei da natureza pode ser abolida do
coração do homem.

1. – Pois, sobre Romanos: “para os gentios, que não têm a lei...”, diz a glosa: “no homem interior,
renovado pela graça, inscreve-se a lei da justiça, que a culpa apagara”. Ora, a lei da justiça é lei da
natureza. Portanto, a lei da natureza pode apagar-se.

2. Demais – Além disso, a lei da graça é mais eficaz que a lei da natureza. Ora, a lei da graça é apagada
pela culpa. Portanto, muito mais pode apagar-se a lei da natureza.

3. Demais – Além disso, aquilo que a lei estatui é estabelecido como justo. Ora, muito foi estatuído pelos
homens contra a lei da natureza. Portanto, a lei da natureza pode abolir-se do coração do homem.
Em sentido contrário, há o que diz Agostinho: “A tua lei está escrita no coração do homem e nenhuma
iniquidade pode apagá-la”. Ora, a lei inscrita no coração dos homens é a lei natural. Portanto, a lei
natural não pode ser apagada.

SOLUÇÃO. — Deve dizer-se que, como acima se disse, pertencem primeiro à lei natural certos preceitos
generalíssimos, os quais são conhecidos por todos; além disso, há outros preceitos secundários mais
particulares, que são como que conclusões próximas dos princípios. Assim, quanto a tais princípios
comuns, a lei natural de nenhum modo pode ser abolida do coração humano de forma universal. É
abolida, porém, em algo de operável, na medida em que a razão é impedida de aplicar o princípio geral
ao operável particular por óbice da concupiscência ou de alguma outra paixão, como se disse acima.
Quanto aos preceitos segundos, entretanto, pode ser a lei natural abolida dos corações dos homens, ou
por força das más persuasões, do mesmo modo que, no especulativo, ocorrem erros a respeito das
conclusões necessárias, ou ainda por causa dos maus costumes e hábitos corruptos. Dessa forma, por
exemplo, entre alguns não eram os latrocínios reputados pecados e também os vícios contra a natureza,
como o diz o Apóstolo em Romanos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No que concerne ao primeiro argumento, deve dizer-se
que a culpa abole a lei da natureza no particular, não no universal, a não ser talvez quanto aos preceitos
segundos da lei da natureza.

RESPOSTA À SEGUNDA. — No que concerne ao segundo argumento, deve dizer-se que, embora a graça
seja mais eficaz do que a natureza, a natureza é mais essencial ao homem e, por isso, dotada de maior
permanência.

RESPOSTA À TERCEIRA. — No que concerne ao terceiro argumento, deve dizer-se que aquela razão
procede quanto a preceitos segundos da lei da natureza, contra os quais alguns legisladores produziram
alguns estatutos iníquos.