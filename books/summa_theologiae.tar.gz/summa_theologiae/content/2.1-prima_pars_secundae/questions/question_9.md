# Questão 9: Do motivo da vontade.
Em seguida devemos tratar do motivo da vontade.
E sobre esta Questão seis artigos se discutem:

## Art. 1 — Se a vontade é movida pelo intelecto.
(I q. 82, a . 4; III Cont Gent., cap. XXVI; De Verit., q. 22, a . 12; De Malo, q. 6).
O primeiro discute-se assim. ― parece que a vontade não é movida pelo intelecto.

1. ― Pois, diz Agostinho, comentando aquilo do salmo (Sl 118, 20) ― A minha alma desejou ansiosa em
todo o tempo as tuas justificações! ― O intelecto como que voa na frente, seguindo-se porém um efeito
tardo ou nulo; conhecemos o bem mas não nos agrada o agir. Ora, tal não se daria se a vontade fosse
movida pelo intelecto, porque o movimento do móvel procede da moção do motor. Logo, o intelecto
não move a vontade.

2. Demais. ― O intelecto exerce para com a vontade a função de apresentar o apetível, assim como a
imaginação o apresenta ao apetite sensitivo. Ora, a esta, assim agindo, não move o apetite sensitivo;
antes às vezes tratamos o imaginado como o que se nos mostra numa pintura, que não nos move,
segundo diz Aristóteles. Logo, também o intelecto não move a vontade.

3. Demais. ― Motor e movido não são idênticos, no mesmo ponto de vista. Ora, a vontade move o
intelecto, pois, inteligimos quando queremos. Logo, o intelecto não move a vontade.
Mas, em contrário, diz o Filósofo: o apetível inteligido é motor não movido; ao passo que a vontade é
motor movido.

SOLUÇÃO. ― Um ser precisa ser movido por outro, na medida em que é potencial em relação a vários
atos; pois, é necessário que o potencial seja atualizado pelo que já é atual, chamando-se a isto mover.
Ora, de duplo modo uma virtude da alma pode ser potencial em relação a diversos atos: quanto a agir
ou não e quanto a fazer tal coisa ou tal outra. Assim, a vista às vezes vê atualmente e às vezes, não; às
vezes vê o branco e às vezes, o preto. Logo, precisa de um motor, quanto a esses dois modos, isto é,
para o exercício ou uso do ato e para a determinação deste. O exercício depende do sujeito que umas
vezes age e outras não; e a determinação, do objeto, que é especificador dos atos.
Ora, a moção do sujeito, em si, provém de algum agente. E como todo agente age para um fim, segundo
já se demonstrou, o princípio de tal moção provém do fim. Donde vem que a arte que visa um fim move,
pelo seu império, a que visa o meio; assim, a arte de pilotar impera à que constrói a nau, como diz
Aristóteles. Ora, o bem em comum, que tem natureza de fim, é o objeto da vontade. E portanto, por
este lado, a vontade move, para os seus atos, as outras potências da alma; porque usamos destas
quando queremos. Pois, os fins e as perfeições de todas as outras potências estão compreendidos,
como bens particulares, no objeto da vontade. E sempre, a arte ou potência que visa o fim universal
move a agir a arte ou potência que visa o fim particular, compreendido no universal. Deste modo, o
chefe do exército, que visa o bem comum, i. é, a ordem de todo o exército, move, pelo seu império,
qualquer dos tribunos, que visa a ordem de um batalhão.
O objeto porém move determinando o ato, a modo de princípio formal, pelo qual, nos seres naturais, a
ação é especificada, como a calefação, pelo calor. Ora, o princípio formal primeiro é o ente e o
verdadeiro universal, objeto do intelecto. E, portanto, por este modo de moção, o intelecto move a
vontade, apresentando-lhe o seu objeto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Da autoridade citada não se deduz que o intelecto não
move, mas, que não move necessariamente.

RESPOSTA À SEGUNDA. ― Assim como a imaginação da forma, sem a apreciação do que é conveniente
ou nocivo, não move o apetite sensitivo; assim também a apreensão do verdadeiro, sem a natureza de
bem e de apetível, não move o apetite intelectivo, que é a vontade. Por onde, não é o intelecto
especulativo que move, mas, sim, o prático, como diz Aristóteles.

RESPOSTA À TERCEIRA. ― A vontade move o intelecto, quanto ao exercício do ato, pois, o próprio
verdadeiro, perfeição do intelecto, está contido, como um bem particular, no bem universal. Mas,
quanto à determinação do ato, proveniente do objeto, o intelecto move a vontade, pois, o bem mesmo
é apreendido por uma idéia especial compreendida na idéia universal de verdadeiro. Por onde é claro
que o motor e o movido não se identificam, no mesmo ponto de vista.

## Art. 2 — Se a vontade pode ser movida pelo apetite sensitivo.
(Infra, q. 10, a . 3; q. 77, a . 1; De Verit., q. 22, a . 9, ad 6).
O segundo discute-se assim. ― Parece que a vontade não pode ser movida pelo apetite sensitivo.

1. ― Pois, o motor e o agente são preeminentes ao paciente, como diz Agostinho. Ora, o apetite
sensitivo é inferior à vontade, apetite intelectivo, assim como o sensitivo o é ao intelecto. Logo, o
apetite sensitivo não move o intelectivo.

2. Demais. ― Nenhuma virtude particular pode produzir efeito universal. Ora, o apetite sensitivo,
resultante da apreensão particular do sentido, é uma virtude particular. Logo, não pode causar o
movimento da vontade, que é universal, como resultante da apreensão universal do intelecto.

3. Demais. ― Como está provado em Aristóteles, o motor não é movido pelo que ele põe em
movimento, de maneira que a moção seja recíproca. Ora, a vontade move o apetite sensitivo, enquanto
que este obedece à razão. Logo, o apetite sensitivo não move a vontade.
Mas, em contrário, diz a Escritura (Tg 1, 14): Mas cada um é tentado pela sua própria concupiscência,
que o abstrai e alicia. Ora, ninguém seria arrastado pela concupiscência que tem a sua sede no apetite
sensitivo sem a vontade ser movida por esse apetite. Logo, o apetite sensitivo move a vontade.

SOLUÇÃO. ― Como já se disse, o apreendido sob a idéia de bom e de conveniente move, como objeto, a
vontade. Ora, uma coisa pode parecer boa e conveniente em dois pontos de vista, conforme se atenda
ao que ou a quem é proposta; pois, conveniência supõe relação e portanto depende de um e outro
extremo. E daí, vem que o gosto, diversamente disposto, não aceita, do mesmo modo, algo como
conveniente e não conveniente. Donde o dito do Filósofo: cada um julga do fim, segundo suas
disposições naturais.
Ora, é manifesto que, pela paixão do apetite sensitivo, o homem é imutado para alguma disposição. Por
onde, quando levado por uma paixão, parece-lhe conveniente o que lhe não pareceria se dela estivesse
isento; assim, o que parece bom ao irado não o parece ao calmo. Deste modo, pois, quanto ao objeto, o
apetite sensitivo move a vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede seja mais débil, em certo ponto de vista, o
que em si, é preeminente. Assim, a vontade em si, é preeminente ao apetite sensitivo, mas este tem
sobreeminência quando a paixão domina e submete.

RESPOSTA À SEGUNDA. ― Os atos e as eleições do homem dizem respeito ao particular. Donde, por
isso mesmo que é uma virtude particular, o apetite sensitivo tem grande poder para dispor o homem de
tal maneira que este aprecie o particular, de tal modo ou de tal outro.

RESPOSTA À TERCEIRA. ― Como diz o Filósofo, a razão, na qual está a vontade, move, pelo seu império,
o irascível e o concupiscível; não, certo, por principado despótico, como é o servo movido pelo senhor,
mas por principado real ou político, como os homens livres são regidos pelo governador, os quais
contudo podem resistir. Por onde, o irascível e o concupiscível podem resistir à vontade e assim nada
impede seja esta às vezes movida por eles.

## Art. 3 — Se a vontade se move a si mesma.
(De Malo, q. 6).
O terceiro discute-se assim. ― Parece que a vontade não se move a si mesma.

1. ― Pois, todo motor, como tal, existe em ato; ao passo que o movido é potencial, porque o
movimento é o ato do que existe em potência, como tal. Ora, nada podendo ser atual e potencial, no
mesmo ponto de vista, nada se move a si mesmo. Logo, também a vontade não pode mover-se a si
mesma.

2. Demais. ― O móvel é movido pelo motor presente. Ora, a vontade estando sempre presente a si
mesma, sempre a si mesma havia de mover-se, o que é claramente falso.

3. Demais. ― A vontade é movida pelo intelecto, como já se disse. Se pois a si mesma se move, resulta
que é movida simultânea e imediatamente por dois motores, o que é inadmissível. Logo, não se move a
si mesma.
Mas, em contrário, a vontade é senhora dos seus atos e dela depende o querer e o não querer; o que
não se daria se não pudesse mover-se a si mesma a querer. Logo, move-se a si mesma.

SOLUÇÃO. ― Como já se disse antes, em razão do fim, objeto da vontade, a ela pertence mover as
outras potências. Ora, segundo já foi dito, o fim está para os apetíveis como o princípio, para os
inteligíveis. Ora, é manifesto que o intelecto, conhecendo o princípio, reduz-se da potência ao ato,
quanto ao conhecimento das conclusões, e deste modo a si mesmo se move. E semelhantemente, a
vontade, querendo o fim, move-se a si mesma a querer os meios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não sendo no mesmo ponto de vista que a vontade
move e é movida, não é também desse modo que é atual e potencial; mas, querendo o fim, atualmente,
reduz-se da potência ao ato, em relação aos meios, para os querer em ato.

RESPOSTA À SEGUNDA. ― A potência da vontade está sempre e atualmente presente a si mesma; mas
o ato pelo qual a vontade quer às vezes o fim nem sempre nela existe, sendo por ele que a si mesma se
move. Donde não se segue que sempre se mova a si mesma.

RESPOSTA À TERCEIRA. ― A vontade não é movida pelo intelecto do mesmo modo pelo qual a si
mesma se move; pois, ao passo que por aquele é movida quanto à apresentação do objeto, por si
mesma o é quanto ao exercício do ato conforme a idéia do fim.

## Art. 4 — Se a vontade é movida por algum objeto exterior.
(1, q. 105, a . 4; q. 106, a . 2; q 111, a . 2; Infra, q. 80, a . 1; q. 109, ª 2, ad 1; III Cont. Gent., cap. LXXXIX;
De Verit., q. 22, a . 9; De Malo, q. 6; Quod., I, q. 4, a . 2).
O quarto discute-se assim. ― Parece que a vontade não é movida por nenhum objeto exterior.

1. ― Pois, o movimento da vontade é voluntário e é da essência deste ― como também da essência do
que é natural ― proceder de um princípio intrínseco. Logo, esse movimento não provém de nenhum
objeto exterior.

2. Demais. ― A vontade não pode sofrer violência, como já se demonstrou. Ora, violento é o que tem
princípio exterior. Logo, a vontade não pode ser movida por nenhum objeto exterior.

3. Demais. ― O que é suficientemente movido por um motor não há mister ser movido por outro. Ora, a
vontade move-se suficientemente a si mesma. Logo, não é movida por nenhum objeto exterior.
Mas, em contrário. ― A vontade é movida pelo objeto, como já se disse. Ora, o objeto da vontade pode
ser uma coisa exterior proposta ao sentido. Logo, ela pode ser movida por um objeto exterior.

SOLUÇÃO. ― É manifesto que quanto ao seu objeto, a vontade pode ser movida por algo de exterior.
Mas, é forçoso ainda afirmar que ela é movida por algum princípio exterior, quanto ao exercício do ato.
Pois, tudo o que, ora, age atualmente e, ora, é potencial, forçosamente há de ser movido por algum
motor. Ora, é manifesto que a vontade começa a querer o que antes não queria. Logo, é necessário que,
por alguma coisa, seja movida a querer. Por certo que, como já se disse, ela se move a si mesma,
quando, querendo o fim, quer os meios. Ora, isto não se pode dar, senão pelo conselho; assim, quem
quer sarar principia a cogitar de que modo pode consegui-lo, e dessa cogitação, conclui que pode sarar
por meio do médico, e isso quer. Mas, como nem sempre quis, atualmente, a saúde, necessário é
começasse a querer sarar, movida por algum motor. Se porém ela se movesse a si mesma a querer, seria
forçoso que tal fizesse, mediante o conselho, em virtude de outra vontade pressuposta. E como tal
processo não pode ir ao infinito, necessário é admitir-se que, no seu primeiro movimento, a vontade se
move pelo impulso de algum motor externo, como conclui Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É da essência da vontade ter princípio intrínseco; mas
não é necessário que este seja um princípio primeiro não movido por outro. E por isso, embora o
princípio próximo do movimento voluntário seja intrínseco, contudo o princípio primeiro é extrínseco,
assim com o é o princípio primeiro do movimento natural, que move a natureza.

RESPOSTA À SEGUNDA. ― Para a essência do violento não basta seja o princípio extrínseco, mas é
necessário acrescentar: sem que o paciente em nada contribua para tal. Ora, isso se não dá quando a
vontade é movida por algo de exterior, pois, embora movida, ela é que quer. Ao passo que esse
movimento seria violento se fosse contrário ao movimento da vontade, o que, no caso, não pode ser
porque então ela quereria e não quereria ao mesmo tempo.

RESPOSTA À TERCEIRA. ― A vontade, em certo ponto de vista e na sua ordem, i. é, como agente
próximo, move-se suficientemente; mas não pode mover-se a si mesma em relação a tudo, como se
demonstrou. E por isso necessita ser movida por um primeiro motor.

## Art. 5 — Se a vontade humana é movida pelo corpo celeste.
(I, q. 115, a . 4; Iiac, q. 95, a . 5; II Sent. Dist. XV, 1. q. 1, a . 3; III, Cont. Gent., cap. LXXXVII; De Verit., q. 5,
a . 10; De Malo, q. 6; Compend. Theol, cap. CXXVII, CXXVIII; In Math., cap. II; I Perih., lect. XIV; III De
Anima, lect. IV; III Ethic., lect. XIII).
O quinto discute-se assim. ― Parece que a vontade humana é movida pelo corpo celeste.

1. ― Pois, todos os movimentos vários e multiformes se reduzem, como a causa, ao movimento
uniforme, que é o do céu, conforme o prova Aristóteles. Ora, os atos humanos são vários e multiformes,
pois, primeiro, não existindo, começaram depois a existir. Logo, reduzem-se, ao movimento do céu,
naturalmente uniforme, como causa.

2. Demais. ― Segundo Agostinho, os corpos inferiores são movidos pelos superiores. Ora, os
movimentos do corpo humano, causados pela vontade, não podem se reduzir, ao movimento do céu
como causa sem que também a vontade seja movida pelo céu. Logo, este move a vontade humana.

3. Demais. ― Pela observação dos corpos celestes, os astrólogos prenunciam certas verdades relativas
aos atos humanos futuros, procedentes da vontade. Ora, tal se não daria se os tais corpos não
pudessem mover a vontade do homem. Logo, a vontade humana é movida pelo corpo celeste.
Mas, em contrário, diz Damasceno: os corpos celestes não são as causas dos nossos atos. Ora, sê-lo-iam
se a vontade, princípio dos atos humanos, fosse movida por eles. Logo, aquela não é movida por estes.

SOLUÇÃO. ― É manifesto que, do modo pelo qual é movida pelo objeto exterior a vontade, pode ser
movida pelos corpos celestes; pois, assim como os corpos exteriores, propostos ao sentido, movem a
vontade, assim também os órgãos das potências sensitivas caem sob a ação dos movimentos dos corpos
celestes.
Mas certos ensinaram ainda que, assim como a vontade é movida por algum agente exterior, quanto ao
exercício do ato, assim também os corpos celestes podem influir diretamente sobre ela. Isto, porém, é
impossível. Pois, como diz Aristóteles, a vontade está na razão, que é uma potência da alma não ligada a
órgão corpóreo. Donde se conclui que é uma potência absolutamente imaterial e incorpórea. Ora, é
manifesto que nenhum corpo pode agir sobre um ser incorpóreo, antes, ao inverso, porque os seres
incorpóreos e imateriais têm virtude mais formal e universal que quaisquer seres corpóreos. Logo, é
impossível o corpo celeste influir diretamente sobre o intelecto e a vontade. E por isso Aristóteles,
expondo a opinião dos que dizem com Homero ― a vontade dos homens é tal qual a causa o pai dos
deuses e dos homens. ― i. é, Júpiter, pelo qual se entende todo o céu, atribui essa mesma opinião aos
que diziam não diferir o intelecto, do sentido. Ora, todas as virtudes sensitivas, sendo atos de órgãos
corpóreos, podem ser movidas acidentalmente pelos corpos celestes, uma vez que sejam movidos os
corpos de que eles são os atos.
Como já se disse porém, que o apetite intelectivo é, de certo modo, movido pelo sensitivo, o movimento
dos corpos celestes atinge, indiretamente, a vontade, na medida em que as paixões do apetite sensitivo
podem movê-la.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os movimentos multiformes da vontade humana
reduzem-se a alguma causa uniforme, superior, contudo, ao intelecto e à vontade. Ora, isso se não pode
dizer de qualquer corpo, mas só, de uma substância superior imaterial. Logo, não é necessário que o
movimento da vontade seja reduzido ao movimento do céu, como causa.

RESPOSTA À SEGUNDA. ― Os movimentos corpóreos humanos se reduzem ao movimento dos corpos
celestes, como causa, na medida em que a disposição mesma dos órgãos, própria para o movimento,
provém, de certo modo, da impressão de tais corpos. E enquanto o apetite sensitivo também é movido
por essa impressão. E além disso, enquanto os corpos exteriores são movidos conforme ao movimento
dos corpos celestes, principiando a vontade, em virtude desse ocurso, a querer ou não alguma coisa,
como quando, chegando o frio, começamos a querer fazer fogo. Mas tal moção da vontade procede do
objeto apresentado exteriormente e não, do impulso interior.

RESPOSTA À TERCEIRA. ― Como já se disse, o apetite sensitivo sendo ato do órgão corpóreo, nada
impede que, por impressão dos corpos celestes, uns sejam inclinados, como por compleição natural, à
ira, à concupiscência ou a qualquer paixão semelhante. Pois a maior parte dos homens seguem as
paixões, às quais só os sapientes resistem. Donde vem que, na mor parte dos casos, verifica-se o que é
prenunciado dos atos humanos, pela consideração dos corpos celestes. Porém, como diz Ptolomeu, o
sapiente domina os astros, porque, resistindo às paixões, impede, por vontade livre e de nenhum modo
sujeita ao movimento celeste, tais efeitos desses corpos. Ou, como diz Agostinho, devemos confessar
que por um certo instinto ocultíssimo por que as mentes humanas são levadas, sem o saberem, é que às
vezes os astrólogos dizem a verdade. E isso é obra dos espíritos sedutores, quando feito para enganar os
homens.

## Art. 6 — Se a vontade é movida só por Deus, como princípio exterior.
(I, q. 105, a . 4; q. 106, a . 2; q. 111, a . 2; II Sent., dist. XV, q. 1, a . 3; III Cont. Gent., cap. LXXXVIII, XCI,

XCII; De Verit., q. 22, a . 8, 9; De Malo, q. 3, ª 3; q. 6; Compend. Theol, cap. CXXIX).
O sexto discute-se assim. ― Parece que a vontade não é movida só por Deus, como princípio exterior.

1. ― Pois, o inferior é por natureza movido pelo superior; assim, os corpos inferiores, pelos corpos
celestes. Ora, à vontade humana é superior além de Deus, o anjo. Logo, ela pode ser movida também
por este, como princípio exterior.

2. Demais. ― O ato da vontade resulta do ato do intelecto. Ora, o intelecto humano é atualizado, não só
por Deus, mas também pelo anjo, por meio de iluminação, como diz Dionísio. Logo, pela mesma razão
também a vontade.

3. Demais. ― Deus é a causa só dos bens, conforme a Escritura (Gn 1, 31): E viu Deus todas as coisas que
tinha feito, e eram muito boas. Se, pois a vontade do homem fosse movida só por Deus, nunca seria
movida para o mal; ora, pela vontade é que pecamos e vivemos retamente, como diz Agostinho.
Mas, em contrário, diz a Escritura (Fp 2, 13): Deus é o que obra em vós o querer e o perfazer.

SOLUÇÃO. ― O movimento da vontade, assim como o natural, procede do interior. Pois, embora um
motor possa mover uma coisa natural, de cuja natureza ele não é a causa, contudo só pode causar o
movimento natural o que é, de certo modo, a causa da natureza. Assim, a pedra é movida para cima
pelo homem, que não lhe causa a natureza; mas esse movimento não lhe é natural a ela e só lhe pode
ser causado pelo que lhe causou a natureza. E é por isso que o gerador move os corpos graves e leves
localmente, como diz o Filósofo. Por onde, o homem, dotado de vontade, pode ser movido pelo que não
lhe é a causa; mas é impossível que o seu movimento voluntário proceda de algum princípio extrínseco,
que não seja a causa da vontade.
Ora, só Deus pode ser a causa da vontade; o que de duplo modo se demonstra. Primeiramente, porque
a vontade é uma potência da alma racional, que só Deus causa, por criação, como se disse na primeira
parte. E depois, porque a vontade, ordenando-se ao bem universal, só Deus, que o é, pode ser a causa
dela. Enquanto que qualquer outro bem é por participação e particular; ora, causa particular não pode
dar inclinação universal. Logo, nem a matéria prima, potencial em relação a todas as formas, pode ser
causada por qualquer agente particular.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O anjo não é superior ao homem a ponto de lhe ser
causa da vontade, a modo dos corpos celestes, causa das formas naturais de que resultam os
movimentos naturais dos corpos da natureza.

RESPOSTA À SEGUNDA. ― O intelecto do homem é movido pelo anjo, quanto ao objeto que lhe é
proposto ao conhecimento por virtude de iluminação Angélica. E assim também a vontade pode ser
movida pela criatura exterior, como já se disse.

RESPOSTA À TERCEIRA. ― Deus, como universal motor, move a vontade do homem para o bem, objeto
universal dela. E o homem, que não pode querer nada, sem essa moção universal, pode contudo pela
razão determinar-se a querer tal coisa ou tal outra, que é bem verdadeiro ou aparentemente. ― Às
vezes, porém, e em especial, Deus move certos a quererem um determinado bem; assim aqueles que
move pela graça, como a seguir se dirá.