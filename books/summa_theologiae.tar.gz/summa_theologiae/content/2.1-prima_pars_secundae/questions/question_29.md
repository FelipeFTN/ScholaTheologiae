# Questão 29: Do ódio.
Em seguida devemos tratar do ódio. E sobre esta questão seis artigos se discutem:

## Art. 1 — Se o objeto e a causa do ódio é o mal.
(Infra, q. 46, a . 2).
O primeiro discute-se assim. ― Parece que o objeto e a causa do ódio não é o mal.

1. ― Pois, todo ente é como tal bom. Se pois o objeto do ódio é o mal, nenhuma coisa pode ser odiada,
senão só algum defeito qualquer que tenha. Ora, isto é falso.

2. Demais. ― Odiar o mal é louvável; assim, a Escritura diz em louvor de certos (II Mc 3, 1), que as leis
eram exatamente guardadas, por causa da piedade do pontífice Onias e do ódio que ele tinha no
coração contra todo mal. Ora, se só o mal é odiado, resulta que todo ódio é louvável, o que é
claramente falso.

3. Demais. ― Uma mesma coisa não pode ser simultaneamente boa e má. Ora, o amável para uns é
odioso para outros. Logo, há ódio, não só do mal, mas ainda do bem.
Mas, em contrário. ― O ódio é contrário ao amor. Ora, o objeto do amor é o bem, como antes dissemos.
Logo, o objeto do ódio é o mal.

SOLUÇÃO. ― Sendo o apetite natural derivado de uma apreensão, embora não conexa, a mesma
natureza tem a inclinação do apetite natural e a do apetite animal, conseqüente à apreensão conexa,
conforme já se disse. Ora, é manifesto, que assim como o amor natural consiste na consonância ou
aptidão natural do apetite para o conveniente, assim, o ódio natural consiste na dissonância natural do
apetite relativamente ao repugnante e corruptivo. Do mesmo modo o amor do apetite animal ou o do
intelectivo é a consonância desse apetite com o apreendido como conveniente; e o ódio é uma certa
dissonância do apetite em relação ao apreendido como repugnante e nocivo. Ora, como tudo
conveniente tem, como tal, natureza de bem, assim tudo o repugnante o tem como tal natureza de mal.
― E portanto, como o bem é o objeto do amor, o mal o é do ódio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O ser como tal não é por essência repugnante, mas
conveniente, porque tudo se lhe reduz a ele. Mas um ente determinado pode ser contrário a outro; e
neste ponto de vista, o ser odioso para outro é, para este, mal, não em si, mas relativamente a ele.

RESPOSTA À SEGUNDA. ― Assim como podemos apreender como bem aquilo que não o é
verdadeiramente, o mesmo se pode dar com o mal. Por onde, às vezes se dá que não é bem nem o ódio
do mal nem o amor do bem.

RESPOSTA À TERCEIRA. ― O amável ao apetite natural de um, por lhe convir à natureza, pode ser
odioso para outros, por repugnar em relação a esse mesmo apetite; assim o calor que convém ao fogo,
repugna à água. O mesmo se dá com o apetite animal, pois o que um apreende sob a noção de bem,
outro apreende sob a de mal.

## Art. 2 — Se o amor é causa do ódio.
(IV Cont. Gent., cap. XIX).
O segundo discute-se assim. ― Parece que o amor não é causa do ódio.

1. ― Pois, noções que por oposição se dividem são naturalmente simultâneas, como se diz. Ora, o amor
e o ódio, sendo contrários, dividem-se por oposição. Logo, são naturalmente simultâneos, e portanto o
primeiro não é causa do segundo.

2. Demais. ― Um contrário não é causa do outro. Ora, amor e ódio são contrários. Logo, aquele não é
causa deste.

3. Demais. ― O posterior não é causa do anterior. Ora, o ódio é anterior ao amor, segundo parece, pois
implicando ele o afastamento do mal, o amor importa na aproximação do bem. Logo, aquele não é
causa deste.
Mas, em contrário, diz Agostinho, que todos os afetos são causados pelo amor. Logo, também o ódio,
que é um afeto da alma.

SOLUÇÃO. ― Como já dissemos, o amor consiste numa certa conveniência entre o amante e o amado, e
o ódio, numa certa repugnância ou dissonância entre um e outro. Ora, o que convém a um ser deve se
considerar antes do que o que lhe repugna, pois o que repugna é corruptivo ou impeditivo do
conveniente. Por onde e necessariamente, o amor há-de ser anterior ao ódio; e só se odeia o que
contraria o bem conveniente que se ama. Ora, neste sentido todo ódio é causado pelo amor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Das noções que se dividem por oposição umas,
naturalmente são simultâneas, real e racionalmente; assim, duas espécies animais ou duas espécies de
cores. De outras porém, simultâneas racionalmente, uma é realmente anterior à outra, de que é a
causa, como é patente com as espécies dos números, das figuras e dos movimentos. Outras por fim não
são simultâneas, nem real nem racionalmente, como a substância e o acidente, pois aquela é realmente
causa deste, e o ente, na sua noção racional é atribuído primeiro à substância e depois ao acidente,
porque a este não se atribui senão enquanto pertence à substância. ― Ora, o amor e o ódio são por
certo naturalmente simultâneos, no ponto de vista racional, não porém no real. Por onde, nada impede
seja o amor causa do ódio.

RESPOSTA À SEGUNDA. ― O amor e o ódio são contrários quando referidos ao mesmo objeto. Mas, não
o são quando se referem a objetos contrários, sendo nesse caso um a conseqüência do outro; pois pela
mesma razão pelo qual amamos uma coisa odiamos a sua contrária. E assim, o amor de uma leva-nos a
odiar a outra.

RESPOSTA À TERCEIRA. ― Na ordem da execução, primeiro nos afastamos de um termo e, depois,
achegamo-nos ao outro; mas, o inverso se dá na ordem da intenção pois afastamo-nos de uma para nos
achegarmos ao outro. Ora, o movimento apetitivo pertence mais à intenção do que à execução. Logo, o
amor é anterior ao ódio, sendo um e outro movimentos apetitivos.

## Art. 3 — Se o ódio é mais forte que o amor.
O terceiro discute-se assim. ― Parece que o ódio é mais forte que o amor.

1. ― Pois, diz Agostinho: Não há ninguém que não fuja da dor mais do que deseja o prazer. Ora, fugir da
dor é próprio do ódio, ao passo que o desejo do prazer é próprio do amor. Logo, aquele é mais forte que
este.

2. Demais. ― O mais débil é vencido pelo mais forte. Ora, quando o amor se converte no ódio é por este
vencido. Logo, o ódio é mais forte que o amor.

3. Demais. ― As afeições da alma se manifestam pelos seus efeitos. Ora, o homem se aplica mais em
repelir o odioso do que em buscar o amado, pois até mesmo os animais se abstêm do prazer por temor
do açoite, como diz Agostinho. Logo, o ódio é mais forte que o amor.
Mas, em contrário. ― O bem é mais forte que o mal, pois o mal não age senão em virtude do bem,
como diz Dionísio. Ora, o ódio e o amor diferem pela diferença existente entre o bem e o mal. Logo, o
amor é mais forte que o ódio.

SOLUÇÃO. ― É impossível seja o efeito mais forte que a causa. Ora, todo ódio precede, como de causa,
de algum amor, como já dissemos. Logo, é impossível seja o ódio absolutamente mais forte que o amor.
Mas é necessário além disto, que o amor, absolutamente falando, seja mais forte que o ódio. Pois, um
ser se move mais fortemente para os fins que para os meios. Ora, como o afastamento do mal se ordena
à consecução do bem, como fim, conclui-se que, absolutamente falando, é mais forte o movimento da
alma para o bem do que para o mal.
Ás vezes porém o ódio parece mais forte que o amor, por duas razões. ― Primeira, por ser mais sensível
que ele. Pois, a percepção do sentido implica uma certa imutação e esta nós a sentimos mais vivamente
no momento mesmo em que se opera do que quando já é consumada; e assim se explica que o calor da
febre hética, embora maior, não é sentido tão intensamente como o calor da terçã, porque já se
transformou num quase hábito da natureza. E também o amor é mais sentido na ausência do amado,
porque, como diz Agostinho, ele não é tão sentido como quando o manifesta a falta do amado. Por
onde, também se explica seja a repugnância pelo objeto odiado percebida mais sensivelmente do que a
conveniência do amado. ― Segunda, porque não há correlação entre o ódio e o amor correspondente.
Pois, conforme a diversidade dos bens assim é a dos amores, na sua maior ou menor intensidade, e a
esses amores se proporcionam os ódios opostos. E por isso, o ódio correspondente ao maior amor move
mais que o menor amor.

DONDE SE DEDUZ CLARA A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Assim, o amor do prazer é menor que o
da conservação própria ao qual corresponde a fuga da dor, e por isso fugimos mais à dor do que
amamos o prazer.

RESPOSTA À SEGUNDA. ― O ódio nunca venceria o amor senão por causa de um amor maior que tem o
seu ódio correspondente. Assim como nos amamos a nós mesmos mais que o amigo, por isso odiamos
até o próprio amigo que nos contraria.

RESPOSTA À TERCEIRA. ― Por ser o ódio mais sensível que o amor é que se age mais intensamente para
repelir o que é odioso.

## Art. 4 — Se podemos nos odiar a nós mesmos.
(IIª.IIªe, q. 25, a . 7; II Sent., dist XLII, q. 2, a . 2, qª, ad 2; III, q. XXVII, Expos. Litt; In Psalm., X; Ephes., cap.
V, lect. IX).
O quarto discute-se assim. ― Parece que podemos nos odiar a nós mesmos.

1. ― Pois, diz a Escritura (Sl 10, 6): aquele que ama a iniqüidade aborrece a sua alma. Ora, muitos amam
a iniqüidade. Logo, odeiam-se a si mesmos.

2. Demais. ― Odiamos a quem queremos e fazemos mal. Ora, certos, às vezes, querem e fazem mal a si
mesmos, como p. ex., os suicidas. Logo, odeiam-se a si mesmos.

3. Demais. ― Boécio diz, que a avareza torna os homens odiosos, donde se pode concluir que todos
odeiam o avarento. Ora, muitos são avarentos. Logo, odeiam-se a si mesmos.
Mas, em contrário, diz o Apóstolo (Ef 5, 29): Ninguém aborreceu jamais a própria carne.

SOLUÇÃO. ― É impossível, absolutamente falando, odiarmo-nos a nós próprios. Pois naturalmente,
todos desejam o bem, nem podemos desejar nada senão sob a forma de bem, porque o mal é contrário
à vontade, como diz Dionísio. Ora, amar alguém é querer-lhe bem, como já dissemos. Por onde e
necessariamente, havemos de nos amar a nós mesmos, sendo impossível, absolutamente falando, que a
nós mesmos nos odiemos.
Acidentalmente porém, podemos nos odiar a nós mesmos e isto de dois modos. ― De um, quanto ao
bem que a nós mesmos queremos. Pois pode suceder que o que desejamos como bem relativo seja
absolutamente mal; e neste caso, queremos acidentalmente mal a nós próprios, i. é, odiamo-nos. ― De
outro modo, quanto à nós mesmos, a quem queremos o bem. Pois, um ser é sobretudo o que nele há de
principal; e por isso dizemos que a cidade faz o que faz o rei, como se este constituísse toda ela. Ora, é
manifesto ser o homem tal, sobretudo pela alma. Os que, porém, se consideram como sendo o que são
sobretudo pela sua natureza corpórea e sensitiva, amam-se pelo que se julgam; mas, querendo o que
contraria à razão, odeiam-se no que verdadeiramente são. ― E de ambos os modos, aquele que ama a
iniqüidade, aborrece, não só a sua alma, mas também a si mesmo.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. ― Ninguém quer e faz mal a si mesmo senão na medida em que apreende esse
mal sob a razão de bem. Assim, os suicidas apreendem sob a razão de bem a morte mesma, como termo
de alguma miséria ou dor.

RESPOSTA À TERCEIRA. ― O avarento odeia um acidente seu, mas nem por isso se odeia a si mesmo,
assim como o doente odeia a sua doença por isso mesmo que se ama. ― Ou devemos responder, que a
avareza torna o avarento odioso aos outros, mas não a si mesmo; antes, ela é causada pelo amor
desordenado de si mesmo, que leva o avarento a querer a si, mais do que é mister, os bens temporais.

## Art. 5 — Se podemos odiar a verdade.
O quinto discute-se assim. ― Parece que não podemos odiar a verdade.

1. ― Pois, o bem, o ser e a verdade entre si se convertem. Ora, ninguém pode odiar a bondade, e
portanto a verdade.

2. Demais. ― Todos os homens desejam naturalmente saber, como diz Aristóteles. Ora, ciência só a há
do verdadeiro. Logo, a verdade é naturalmente desejada e amada. Mas o que num ser existe
naturalmente existe sempre. Logo, ninguém pode odiar a verdade.

3. Demais. ― O Filósofo diz, que os homens amamos os que não são fingidos. Ora, isto não é senão por
causa do amor à verdade. Logo, o homem ama naturalmente a verdade, e portanto não a odeia.
Mas, em contrário, diz o Apóstolo (Gl 4, 16): Tornei-me eu logo vosso inimigo, porque vos disse a
verdade.

SOLUÇÃO. ― O bem, a verdade e o ser são idênticos na realidade, mas diferem racionalmente. Assim, o
bem é por essência desejável, mas não o ser e a verdade, pois, bem é o que todos os seres desejam. Por
onde, o bem como tal não pode ser odiado nem geral nem particularmente. O ser e a verdade porém
não podem, por certo, ser odiados em geral, porque a dissonância causa o ódio e a conveniência, o
amor; ora, o ser e a verdade são comuns a todas as coisas. Mas, em particular, nada impede seja odiado
um certo ser e uma certa verdade, enquanto se apresentam como contrários ou repugnantes; a
contrariedade porém e a repugnância não se opõem à noção de ser e à de verdade, como se opõe à de
bondade.
Ora, um bem particular qualquer pode, de três modos, repugnar ou contrariar o bem amado. ―
Primeiro, porque a verdade, estando causal e originalmente nas coisas mesmas, às vezes odiamos uma
verdade porque não queremos aceitá-la como tal. ― Segundo, quando temos conhecimento de uma
verdade que nos impede a busca do bem amado; tal o caso dos que quereriam não conhecer as
verdades da fé para pecarem livremente, e desses diz a Escritura (Jó 21, 14): nós não queremos
conhecer os teus caminhos. ― Terceiro, odiamos uma verdade particular, como repugnante, enquanto
existente no intelecto de outrem; assim, quem quer que lhe fique oculto o pecado odeia qualquer
conheça a verdade sobre esse pecado. E neste sentido, diz Agostinho, que os homens amam a verdade
que os ilumina e odeiam a que os acusa.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. ― Conhecer a verdade é em si mesmo amável, e por isso diz Agostinho, que
acabamos de citar, que os homens amam a verdade que os ilumina. Mas por acidente o conhecimento
da verdade pode ser odioso, quando impede a obtenção do que se deseja.

RESPOSTA À TERCEIRA. ― Amamos os homens não fingindo porque gostamos de conhecer a verdade
como ela é, e tais homens assim a manifestam.

## Art. 6 — Se podemos odiar alguma coisa em universal.
(Infra, q. 46, a . 7, ad 3).
O sexto discute-se assim. ― Parece que não podemos odiar nada em universal.

1. ― Pois, o ódio é uma paixão do apetite sensitivo, movido pela apreensão sensível. Ora, os sentidos
não podem apreender o universal. Logo, não podemos odiar nada em universal.

2. Demais. ― O ódio é causado por alguma dissonância, a qual repugna à comunidade. Ora, a
comunidade entra em a noção do universal. Logo, não pode haver ódio de nada em universal.

3. Demais. ― O objeto do ódio é o mal. Ora, o mal está nas coisas e não na mente, como diz Aristóteles.
Ora, como o universal só existe na mente que o abstrai do particular, resulta que não pode haver ódio
de nada em universal.
Mas, em contrário, diz o Filósofo, que a ira sempre se refere ao singular e o ódio, ao genérico; assim,
todos odiamos o ladrão e o caluniador.

SOLUÇÃO. ― De dois modos podemos considerar o universal: como o substrato mesmo da noção de
universalidade, ou como referente à natureza à qual essa noção é atribuída; pois, uma coisa é
considerada a noção universal de homem e outra, considerar essa noção enquanto realiza num homem.
Ora, na primeira acepção, nenhuma potência da parte sensitiva, quer a apreensiva, quer a apetitiva
pode atingir o universal, porque este procede da abstração da matéria individual, matéria em que se
radica toda virtude sensitiva. Esta virtude porém quer seja apreensiva, quer apetitiva, pode atingir um
objeto universalmente. Assim, dizemos que o objeto da vista é a cor, genericamente; não que ela
conheça a cor universal, mas porque a cognoscibilidade da cor pela vista não convém só a uma
determinada cor, mas à cor em absoluto.
Por onde, também o ódio da parte sensitiva pode visar algo em universal; pois, ao animal pode se opor
uma coisa pela sua natureza comum e não somente pela particular; assim o lobo se opõe à ovelha e por
isso esta o odeia universalmente. A ira porém é sempre causada por algo de particular, a saber, pelo ato
de alguém que nos lesa e esse ato é um particular. E por isso o Filósofo diz: a ira sempre é relativa ao
singular; o ódio porém pode se referir ao seu objeto, genericamente.
Mas o ódio existente na parte intelectiva, consecutivo à apreensão universal do intelecto, pode ter
ambas as modalidades aqui examinadas, em relação ao universal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O sentido não apreende o universal como tal; porém
apreende que, por acidente, tem a universalidade.

RESPOSTA À SEGUNDA. ― O que é comum a todos, não pode ser a razão do ódio. Mas nada impede
que o que é comum a muitos seja contrário a alguns, e portanto odioso.

RESPOSTA À TERCEIRA. ― A objeção colhe quanto ao universal como substrato da noção de
universalidade, que então não é atingido pela apreensão ou pelo apetite sensitivo.