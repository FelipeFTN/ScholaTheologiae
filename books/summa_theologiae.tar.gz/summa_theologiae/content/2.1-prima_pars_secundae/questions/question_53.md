# Questão 53: Da diminuição e da corrupção dos hábitos.
Em seguida devemos tratar da diminuição e da corrupção dos hábitos.
E sobre esta questão três artigos se discutem:

## Art. 1 — Se o hábito pode perder-se.
(I, q. 89, a . 5).
O primeiro discute-se assim. — Parece que o hábito não pode perder-se.

1. — Pois, o hábito é uma como segunda natureza, sendo por isso que as ações habituais são deleitáveis.
Ora, a natureza não se perde, enquanto permanece o ser a que ela pertence. Logo, também o hábito se
não pode perder enquanto permanecer o sujeito.

2. Demais — Toda desaparição da forma se dá ou pela alteração do sujeito, ou pela presença da forma
contrária; assim, a doença desaparece com a corrupção da natureza animal ou com a superveniência da
saúde. Ora, a ciência, que é um hábito, não pode desaparecer com a alteração do sujeito, porque o
intelecto, que é o sujeito, é uma substância e não se corrompe, como já se disse. E semelhantemente
também não pode desaparecer por nenhum contrário, pois as espécies inteligíveis não são contrárias
entre si, como já se disse. Logo, o hábito da ciência não pode desaparecer de nenhum modo.

3. Demais — Toda alteração implica algum movimento. Ora, o hábito da ciência, existente na alma, não
pode desaparecer por um movimento próprio da alma mesma, por que esta em si mesma não é movida.
E só acidentalmente o é pelo movimento do corpo. Ora, nenhuma alteração corpórea pode desvanecer
as espécies inteligíveis existentes no intelecto, pois que é o lugar das espécies, sem corpo; donde se
conclui que nem pelos sentidos e nem pela morte os hábitos podem perder-se. Logo, o hábito da ciência
não se pode perder. E por conseguinte, nem o da virtude, também existente na alma racional; e, como
diz o Filósofo, as virtudes são mais permanentes que as disciplinas.
Mas, em contrário, diz o Filósofo que o esquecimento e o engano são perdas da ciência. Ora, quem peca
perde o hábito da virtude. E por atos contrários é que as virtudes se geram e corrompem, com já se
disse.

SOLUÇÃO. — Dizemos que uma forma é eliminada absolutamente, pela sua contrária, e acidentalmente,
pela corrupção do seu sujeito. Se, portanto, existir algum hábito cujo sujeito seja corruptível, e cuja
causa tenha um contrário, esse poderá perder-se, dos dois modos, segundo bem o manifestam os
hábitos corpóreos como a saúde e a doença. Os hábitos porém, cujo sujeito é incorruptível, não podem
perder-se acidentalmente. Há contudo certos hábitos que, embora existentes principalmente num
sujeito incorruptível, existem, secundariamente, num corruptível. Assim, o hábito da ciência existe,
principalmente, no intelecto possível e, secundariamente, nas potências apreensivas sensitivas, como já
dissemos. Por onde, por parte do intelecto possível o hábito da ciência não pode perder-se
acidentalmente, senão só por parte das potências sensitivas inferiores.
Por isso devemos examinar se esses hábitos podem, em si mesmos, perder-se. Porque, se houver um
hábito que tenha algum contrário, ou por si mesmo ou em virtude da sua causa, esse poderá, em si
mesmo, perder-se; não o poderá porém, se não tiver contrário. — Ora, é manifesto que a espécie
inteligível existente no intelecto possível não tem nenhum contrário, como também o é que nada pode
ser contrário ao intelecto agente, causa dessa espécie. Por onde, se existir algum hábito, no intelecto
possível, causado imediatamente pelo intelecto agente, esse há-de ser incorruptível absoluta e
acidentalmente. E tais são os hábitos dos primeiros princípios, tanto especulativos como práticos, que se
não podem perder por nenhum esquecimento ou engano; por isso diz o Filósofo, que a prudência não se
perde pelo esquecimento. — Há, por outro lado, no intelecto possível, um hábito causado pela razão,
que é o das conclusões e se chama ciência. E essa causa pode ter dupla contrariedade. Uma,
proveniente das proposições mesmas, das quais a razão procede; assim, à proposição — o bem é o
bem — é contrária esta outra — o bem não é o bem — segundo o Filósofo. Outra, proveniente do
processo mesmo da razão; é assim que um silogismo sofístico se opõe a um dialético ou demonstrativo.
Por onde é claro que, pela razão falsa, pode perder-se o hábito da verdadeira opinião ou até da ciência.
Por isso, diz o Filósofo, que o engano é a corrupção da ciência, como já dissemos.
Há porém certas virtudes intelectuais residentes na razão mesma, conforme já se disse e com as quais
se dá o mesmo que com a ciência ou a opinião. Por outro lado, outras, as virtudes morais, residentes na
parte apetitiva da alma, em que se fundam também os vícios opostos. Assim, pois, como os hábitos da
parte apetitiva são causados pela razão naturalmente motora dessa parte; assim também, pelo juízo da
razão, movendo, de qualquer modo, para o termo oposto, que por ignorância, quer pela paixão ou ainda
pela eleição, perder-se o hábito da virtude ou do vício.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como já se disse, o hábito se assemelha à natureza mas,
com certa deficiência. Por onde, como a natureza de um ser não pode, de nenhum modo, dele separar-
se, o hábito, por seu lado, só dificilmente o pode.

RESPOSTA À SEGUNDA. — Embora nada seja contrário às espécies inteligíveis, pode contudo haver
contrário às proposições e ao processo da razão, como já se disse.

RESPOSTA À TERCEIRA. — A ciência, quanto aos fundamentos mesmos do hábito, não pode ser alterada
pelo movimento corpóreo; senão só quanto ao impedimento do ato, na medida em que o intelecto
precisa, para o seu ato, das potências sensitivas, que podem sofrer impedimento proveniente da
transmutação corpórea. Porém, pelo movimento inteligível da razão, o hábito da ciência pode
corromper-se, mesmo quanto aos próprios fundamentos do hábito. E semelhantemente, pode
corromper-se também o hábito da virtude. Contudo, a expressão — as virtudes são mais permanentes
que as ciências — deve ser entendida, não relativamente ao sujeito ou à causa, mas ao ato; pois, o uso
das virtudes é contínuo, durante toda a vida, o que não se dá com o das ciências.

## Art. 2 — Se o hábito pode diminuir.
O segundo discute-se assim. — Parece que o hábito não pode diminuir.

1. — Pois, o hábito é uma qualidade e forma simples. Ora, o que é simples é possuído ou perdido na sua
totalidade. Logo, o hábito, embora possa perder-se, não pode diminuir.

2. Demais — Tudo o que convém ao acidente convém-lhe em si mesmo ou em razão do seu sujeito. Ora,
o hábito, em si mesmo, não aumenta nem diminui, pois do contrário se seguiria que uma espécie pode
ser predicada, mais ou menos, dos seus indivíduos.
Se portanto o hábito não pode diminuir, quanto à participação do sujeito, segue-se que lhe advém
alguma propriedade, que não lhe é comum com o sujeito. Ora, a forma, à qual convém alguma
propriedade que lhe não é comum com o seu sujeito, é separável, como já se disse. Donde resulta que o
hábito é uma forma separável, o que é impossível.

3. Demais — A essência e a natureza do hábito, bem como a de qualquer acidente, consiste em
concretizar-se num sujeito; por isso, qualquer acidente se define pelo seu sujeito. Se, pois, o hábito, em
si mesmo, não aumenta nem diminui, também não poderá diminuir quando concretizado num sujeito e,
portanto, não poderá diminuir de nenhum modo.
Mas, em contrário, é da essência dos termos contrários recaírem sobre o mesmo objeto. Ora, o
aumento e a diminuição são contrários. E portanto, se o hábito pode aumentar também pode diminuir.

SOLUÇÃO. — Os hábitos podem diminuir de dois modos, assim como, segundo já vimos, podem
aumentar. E como eles aumentam pela mesma causa que os gera, assim diminuem pela mesma que os
destrói; pois, a diminuição de um hábito é via para a sua destruição, e inversamente, a sua geração é um
fundamento do seu aumentar-se.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O hábito, em si mesmo considerado, sendo uma forma
simples, não lhe pode caber a diminuição. Mas o pode quanto ao modo diverso de participar, que
provém da indeterminação da potência do ser mesmo que participa, e a qual pode participar
diversamente de uma mesma forma, ou pode estender-se a um maior ou menor número delas.

RESPOSTA À SEGUNDA. — A objeção colheria se a essência mesma do hábito não pudesse de nenhum
modo diminuir. Ora, nós não dizemos isso, mas sim, que qualquer diminuição da essência do hábito tem
o seu princípio, não nele, mas no ser que participa.

RESPOSTA À TERCEIRA. — Seja qual for o sentido atribuído ao acidente, ele depende, por essência, do
sujeito, porém de diferentes maneiras. Pois, tomado abstratamente, o acidente implica relação com o
sujeito, a qual começa naquele e termina neste; assim, chama-se brancura àquilo pelo que uma coisa é
branca. Por onde, na definição do acidente abstrato não se inclui o sujeito, como quase a primeira parte
da definição, que é o gênero, mas como que a segunda, que é a diferença; assim, dizemos que a simitas
é a curvidade do nariz. Mas, nos seres concretos, a relação começa no sujeito e termina no acidente;
assim, chama-se branco àquilo que tem brancura. Por onde, na definição deste acidente incluímos o
sujeito como gênero, que é a primeira parte da definição; assim, dizemos que simus é um nariz curvo.
Por onde, o que convém aos acidentes por parte do sujeito, e não essencialmente, não se lhes atribui
abstrata, mas concretamente. E tal é o que se dá com o aumento e a diminuição, em alguns deles; por
isso dizemos que há mais ou menos, não brancura, mas, branco. E o mesmo se dá com os hábitos e
outras qualidades, salvo que certos aumentam e diminuem por adição, como do sobredito resulta.

## Art. 3 — Se o hábito destrói-se ou diminui só pelo cessar da atividade.
(IIª-IIªe, q. 24, a . 10; I Sent., dist. XVII, q. 2, a . 5).
O terceiro discute-se assim. — Parece que o hábito não se destrói ou diminui só pelo cessar da
atividade.

1. — Pois, os hábitos são mais permanentes que as qualidades passivas, como do sobredito resulta. Ora,
as qualidades passivas não se destroem nem diminuem pela cessação do ato; assim, a brancura não
diminui, embora não imute a vista, nem o calor, mesmo que não aqueça. Logo, também os hábitos não
diminuem nem se destroem pela cessação do ato.

2. Demais — A corrupção e a diminuição são mutações. Ora, nada se muda sem uma causa motora.
Logo, como a cessação do ato não implica nenhuma causa motora, conclui-se que essa cessação não
pode causar a diminuição ou destruição do hábito.

3. Demais — Os hábitos da ciência e da virtude residem na alma intelectiva, que está fora do tempo.
Ora, o que está fora do tempo não se destrói nem diminui pela diuturnidade temporal. Logo, nem os
referidos hábitos se destroem ou diminuem embora permaneçam muito tempo sem se exercitarem.
Mas, em contrário, diz o Filósofo que a disparição da ciência não são só é o engano, mas também, o
esquecimento; e ainda: a falta de exercício dissolve muitas amizades. E pela mesma razão os outros
hábitos das virtudes diminuem ou desaparecem pela cessação do ato.

SOLUÇÃO. — Como já se disse, um motor pode sê-lo de duplo modo. Por si mesmo, quando move em
razão da própria forma; assim, o fogo aquece. Ou por acidente, como o que remove um obstáculo, e
deste modo a cessação do ato causa a destruição ou a diminuição dos hábitos, enquanto remove o ato
que impedia as causas destrutivas ou diminuidoras do hábito. Pois, como já dissemos, os hábitos, em si
mesmos, desvanecem-se ou diminuem por obra do agente contrário. Por onde, os hábitos, cujos
contrários aumentam no decurso do tempo e deviam ser eliminados pelo ato procedente do hábito, tais
hábitos diminuem ou mesmo desaparecem totalmente pela diuturna cessação do ato, como bem o
demonstram a ciência e a virtude.
Pois é manifesto que o hábito da virtude moral torna o homem pronto no escolher o meio, nas ações e
nas paixões. Ora, quem não emprega o hábito da virtude para moderar as paixões ou as atividades
próprias, dá lugar necessariamente ao nascimento de muitas paixões e atos contrários ao modo da
virtude, pela inclinação do apetite sensitivo e de outros móveis externos. Por isso, a virtude desaparece
ou diminui pela cessação do ato.
E o mesmo se dá por parte dos hábitos intelectuais, que tornam o homem pronto a julgar retamente das
coisas imaginadas. Se pois cessarmos o uso desses hábitos, surgem as imaginações estranhas, que às
vezes levam ao termo oposto, e a ponto tal que, se não forem de certo modo cortadas ou comprimidas,
tornam-nos menos aptos para julgar retamente, dispondo-nos mesmo, por vezes e totalmente, ao
contrário. Assim que, pela cessação do ato, diminui ou mesmo destrói-se o hábito intelectual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Cessando de aquecer, também o calor desapareceria se
isso provocasse o aumento do frio, que elimina o calor.

RESPOSTA À SEGUNDA. — A cessação do ato leva à destruição ou diminuição, porque remove o
obstáculo, como já se disse.

RESPOSTA À TERCEIRA. — A parte intelectiva da alma, em si mesma, está fora do tempo; mas a
sensitiva a ele está sujeita. Por onde, no decurso do tempo, transmuta-se quanto às paixões da parte
apetitiva; e mesmo quanto às virtudes apreensivas; por onde, diz o Filósofo, que o tempo é causa do
esquecimento.