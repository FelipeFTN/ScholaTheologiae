# Questão 105: Da razão de ser dos preceitos judiciais.
Em seguida devemos tratar da razão de ser dos preceitos judiciais.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a lei antiga constituiu convenientemente os chefes.
O primeiro discute-se assim. — Parece que a lei antiga constituiu inconvenientemente os chefes.

1. — Pois, como diz o Filósofo, a ordenação do povo depende precipuamente do chefe máximo.
Ora, a lei não determina como esse chefe supremo devia ser constituído; só determina sobre os chefes
inferiores. Assim, diz, primeiro (Ex 18, 21): Escolhe dentre os do povo uns tantos homens tementes a
Deus, etc.; e (Nm 11, 16): Ajunta-me setenta homens dos anciãos de Israel; e (Dt 1, 13): Daí dentre vós
homens sábios e capazes, etc. Logo, a lei antiga constituiu insuficientemente os chefes do povo.

2. Demais. — É próprio do que é ótimo fazer coisas ótimas, como diz Platão. Ora, a ótima constituição
de um estado ou de um povo qualquer é ser governado por um rei. Pois esse regime representa por
excelência o governo divino, pelo qual o Deus único governa o mundo desde o princípio. Logo, a lei
devia ter constituído um rei para o povo e não deixar a escolha ao arbítrio deles, como o permitiu; (Dt
17, 14-15): Quando disseres eu constituirei um rei para me governar, elegerás aquele, etc.

3. Demais. — Dia a Escritura (Mt 12, 25): todo reino dividido contra si mesmo será desolado, o que ficou
experimentalmente patenteado no povo judeu, cuja causa da destruição foi a divisão do reino. Ora, a lei
deve principalmente buscar o que respeita ao bem comum do povo. Logo, a lei antiga devia ter proibido
a divisão do reino em dois governos. E nem devia isso ter sido feito por autoridade divina, como,
segundo se lê na Escritura (1 Rs 11, 29), o foi por autoridade de Ahias Silonita.

4. Demais. — Assim como os sacerdotes são constituídos para a utilidade do povo, no concernente a
Deus, conforme o diz a Escritura (Heb 5, 1), assim os príncipes são constituídos tais para essa mesma
utilidade, na ordem das coisas humanas. Ora, aos sacerdotes e aos levitas da lei destinavam-se certos
proventos de que deviam viver, como os dízimos, as primícias e muitas outras semelhantes. Logo e pela
mesma razão, aos príncipes do povo devia se ordenar o que lhes servisse de sustento; e tanto mais
quando lhes era proibido aceitar donativos, como diz a Escritura (Ex 23, 8): Não aceitarás donativos,
porque eles fazem cegar ainda aos prudentes e pervertem as palavras dos justos.

5. Demais. — Assim como o regime real é o melhor de todos, assim o regime do tirano é a pior
corrupção do governo. Ora, o Senhor, ao constituir o rei, instituiu um direito tirânico, conforme a
Escritura (1 Sm 8, 11):Este será o direito do rei que vos há de governar; ele tomará os vossos filhos etc.
Logo, a lei dispôs inconvenientemente sobre a constituição dos príncipes.
Mas, em contrário, o povo de Israel se gabava da formosura do seu governo (Nm 24, 5): Que formosos
são os teus pavilhões, ó Jacó, e que belas as tuas tendas, ó Israel! Ora, a formosura o governo do povo
depende de príncipes bem constituídos. Logo, pela lei o povo foi bem constituído em relação aos seus
reis.

SOLUÇÃO. — A respeito da boa constituição dos chefes de uma cidade ou nação, duas coisas devemos
considerar. Uma, que todos tenham parte no governo; assim se conserva a paz do povo e todos amam e
guardam um tal governo, como diz Aristóteles. A outra é relativa à espécie do regime ou à constituição
dos governos. E tendo estes diversas espécies, como diz o Filósofo, as principais são as seguintes. A
monarquia, onde o chefe único governa segundo o exige a virtude; a aristocracia, i. é, o governo dos
melhores, na qual alguns poucos governam segundo também o exige a virtude. Ora, o governo melhor
constituído, de qualquer cidade ou reino, é aquele onde há um só chefe, que governa segundo a
exigência da virtude e é o superior de todos. E, dependentes dele, há outros que governam, também
conforme a mesma exigência. Contudo esse governo pertence a todos, quer por poderem os chefes ser
escolhidos dentre todos, quer também por serem eleitos por todos. Por onde, essa forma de governo é
a melhor, quando combinada: monarquia, por ser só um o chefe; aristocracia, por muitos governarem
conforme o exige a virtude; democracia i. é, governo do povo, por, deste, poderem ser eleitos os chefes
e ao mesmo pertencer à eleição deles.
E isto foi o que instituiu a lei divina. Pois Moisés e os seus sucessores governavam o povo, sendo, como
singularmente, os chefes de todos; e isso é uma espécie de monarquia. Mas eram escolhidos setenta e
dois anciões, conforme a virtude. Pois, diz a Escritura (Dt 1, 15) Eu tirei das vossas tribos homens sábios
e nobres e os constitui príncipes; sinal de um regime aristocrático.
Mas era também democrático por serem esses escolhidos dentre todo o povo: Escolhe dentre os do
povo uns tantos sábios, etc. E também era o povo quem os escolhia: Daí entre vós homens sábios, etc.
Por onde é claro que a melhor constituição dos chefes foi a estabelecida pela lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O povo judeu era governado por Deus, com especial
cuidado. Por isso diz a Escritura (Dt 7, 6): O Senhor teu Deus te escolheu para seres o seu povo próprio.
Por isso, o Senhor reservou para si a escolha do chefe supremo. E foi isto que Moisés pediu (Nm 27,
16): O Senhor Deus dos espíritos de todos os homens escolha algum homem que vigie sobre essa
multidão. Assim, por ordem de Deus, foi Josué constituído no principado, depois de Moisés. E a respeito
de cada um dos juízes, sucessores de Josué, se lê que Deus suscitou ao povo um salvador; e que o
espírito do Senhor esteve neles, como está claro na Escritura. Por isso o Senhor também não cometeu
ao povo a eleição do rei, mas a reservou para si, como se lê na Escritura (Dt 17, 15): Constituirás rei
aquele a quem o Senhor teu Deus tiver escolhido.

RESPOSTA À SEGUNDA. — O governo real é o melhor regime para o povo, se não se corromper. Mas,
por causa do grande poder de que o rei é dotado, o seu governo facilmente degenera em tirania, se não
for perfeita a virtude de quem foi investido nesse poder. Pois, como diz Aristóteles, só o virtuoso pode
suportar a boa fortuna. Ora, são poucos os de virtude perfeita; e principalmente os judeus eram cruéis e
inclinados à avareza, vícios que sobretudo fazem os homens cair na tirania. Por isso o Senhor, desde o
princípio, não lhes deu nenhum rei com amplos poderes; mas juízes e governadores, que lhes servissem
de guardas. Mas depois, o pedido do povo, concedeu-lhe, quase indignado, um rei, como é claro pelo
que disse a Samuel (1 Sm 8, 7):Não é a ti que eles rejeitaram, mas a mim, para eu não reinar sobre eles.
Contudo, desde o princípio, para a escolha do rei, instituiu, primeiro, o modo de elegê-lo. Para isso
estabeleceu as duas condições seguintes. Que, ao elegê-lo, procurassem conhecer o juízo de Deus. E não
constituíssem reis de outra nação, por terem esses pouca afeição à nação de que foram feitos chefes, e
por conseqüência não cuidam dela. Em segundo lugar, ordenou como os reis já constituídos deviam ter
o seu gênero de vida: não multiplicarem os seus carros e cavalos, nem as mulheres, nem acumular
riquezas imensas. Pois é por tais cobiças, que resvalam na tirania e se divorciam da justiça. Também
determinou o modo de se haverem para com Deus: lerem sempre e meditarem a sua lei, e tê-lo sempre
em temor e obediência. Ordenou ainda como havia de proceder em relação aos súditos: não os
desprezar soberbamente, nem oprimi-los nem se desviarem da justiça.

RESPOSTA À TERCEIRA. — A divisão do reino e a multidão dos reis foram dadas, antes, como pena aos
judeus, por causa das suas muitas dissensões, que suscitaram principalmente contra o reinado justo de
David, do que para a perfeição deles. Donde o dizer a Escritura (Os 13, 11): Eu te darei um rei no seu
furor: e ainda (Os 8, 4): Eles reinaram por si mesmos e não por mim; eles foram príncipes e eu não os
conheci.

RESPOSTA À QUARTA. — Os sacerdotes eram destinados ao culto, conforme à sucessão na família. E
isto para serem tidos em maior reverência, por não poder qualquer do povo vir a ser sacerdote. Por isso,
a honra que lhes era devida redundava em reverência ao culto divino. Por onde, era necessário se lhes
destinassem certos bens especiais de que vivessem, os quais eram tirados dos dízimos, das primícias,
como também das oblações e dos sacrifícios. Os príncipes, porém, eram tirados dentre todo o povo; e
por isso tinham certos bens próprios de que podiam viver. E tanto mais quanto o Senhor proibira que
mesmo o rei superabundasse em riquezas ou em magnificência de aparato. Quer porque, assim, não
lhes era fácil serem arrastados pela soberba e caírem na tirania; ou também porque, não sendo os
príncipes muito ricos e sendo laborioso o principado e cheio de cuidados, este não era muito desejado
pela gente do povo, e assim desapareciam os motivos de sedição.

RESPOSTA À QUINTA. — O direito referido não era devido ao rei por instituição divina; mas antes,
prenunciava a usurpação dos reis, que para si constituíram um direito iníquo, degenerando em tiranos e
depredadores do povo. Isso é claro pelo que a Escritura acrescenta: E vós sereis seus servos, o que
constitui, propriamente, a tirania; pois, os tiranos governam os seus súditos como se estes fossem
escravos. E o dito de Samuel tinha por fim aterrá-los para não pedirem um rei. Mas, continua ainda a
Escritura, o povo não quis dar ouvidos às razões de Samuel. Pode porém acontecer que um bom rei, sem
tirania, tome os filhos do povo, constituindo-se seus tribunos e centuriões, e se apodere de muitos bens
dos seus súditos, a fim de procurar o bem comum.

## Art. 2 — Se os preceitos judiciais relativos ao convívio social foram convenientemente estabelecidos.
O segundo discute-se assim. — Parece que os preceitos judiciais relativos ao convívio social foram
inconvenientemente estabelecidos.

1. — Pois, os homens não podem conviver pacificamente, se um se apoderar do pertencente a outro.
Ora, isto parece estar permitido na lei, quando diz (Dt 23, 24): Se entrares na vinha de teu próximo,
come quantas uvas quiseres. Logo, a lei antiga não cuida convenientemente da paz social.

2. Demais. — Muitos estados e reinos foram destruídos sobretudo por se ter permitido às mulheres o
direito de propriedade, como diz o Filósofo. Ora, isto foi estabelecido pela lei antiga (Nm 27, 8): Quando
algum homem morrer sem filhos, a herança passará à sua filha. Logo, a lei não cuidou
convenientemente do bem do povo.

3. Demais. — A sociedade humana se conserva principalmente por os homens, comprando e vendendo,
comunicarem-se entre si os bens de que precisam, como diz Aristóteles. Ora, a lei antiga tirou o poder
de vender, pois, ordenava que a propriedade vendida revertesse ao vendedor no qüinquagésimo ano do
jubileu, como está claro na Escritura (Lv 25, 28). Logo, neste ponto, a lei preceituou inconvenientemente
ao povo judeu.

4. Demais. — As necessidades humanas exigem, antes de tudo, que os homens estejam prontos a fazer
concessões mútuas. Ora, essa disposição se elimina se os credores não restituem o que recebem. Por
isso, diz a Escritura (Sr 29, 10): Muitos deixaram de emprestar, não por desumanidade, mas porque
temeram ser defraudados sem o merecerem. Ora, a lei permitia isso. Primeiro, porque mandou (Dt 15,
2): Aquele a quem seu amigo ou seu próximo ou seu irmão dever alguma coisa não a poderá repetir,
porque é o ano da remissão do Senhor. E noutro lugar (Ex 22, 15) diz, que, presente o dono, se o animal
emprestado tiver morrido, não estará obrigado a restituí-lo. Segundo, porque se anula a garantia
fundada no penhor; pois, diz a lei (Dt 24, 10): Quando requereres de teu próximo alguma coisa que ele
te deve, não entrarás em sua casa para dela levares algum penhor; e ainda (Dt 24, 12-13): Não
pernoitará em tua casa o penhor, mas, imediatamente lho tornarás a dar. Logo, a lei dispôs
insuficientemente sobre o mútuo.

5. Demais. — Como a defraudação do depósito leva a um perigo máximo, é mister empregar nisso a
máxima cautela. Por isso, diz a Escritura (2 Mc 3, 15): Os sacerdotes invocavam aquele que está do céu
dominando tudo, que fez uma lei sobre os depósitos, rogando-lhe que os guardasse salvos para aqueles
que os tinham depositado. Ora, nos preceitos da lei antiga estabelece-se uma pequena cautela relativa
aos depósitos. Se o depósito for perdido, ficará garantido pelo juramento do depositário. Logo, neste
ponto, a lei não dispôs convenientemente.

6. Demais. — Assim como um mercenário aluga o seu trabalho, assim outros alugam a casa ou bens
semelhantes. Ora, não era necessário que o locatário pagasse imediatamente o preço da coisa alugada.
Logo, também era muito duro o seguinte preceito da lei (Lv 19, 13): Não deterás em teu poder até o dia
seguinte a paga do jornaleiro.

7. Demais. — Como freqüentemente se tem necessidade do juiz, deve ser fácil o acesso ao mesmo.
Logo, a lei estatuiu inconvenientemente, que fossem a um lugar determinado a fim de obter julgamento
nas suas questões.

8. Demais. — É possível não só dois, mas ainda três ou mais concordarem em mentir. Logo,
inconvenientemente estabelece a lei (Dt 19, 15): tudo passará por constante sobre o depoimento de
duas ou três testemunhas.

9. Demais. — A pena deve ser infligida conforme a gravidade da culpa. Por isso diz a lei (Dt 25, 2): O
número dos golpes regular-se-á pela qualidade do pecado. Ora, a certas culpas iguais a lei estatuiu
penas desiguais: Assim, quando diz (Ex 22, 1): o ladrão restituirá cinco bois por um boi e quatro ovelhas
por uma ovelha. Também alguns pecados não muito graves punia com pena grave; assim, quem era
colhido enfeixando lenha no sábado era apedrejado (Nm 15, 32 ss). Também o filho insolente, porque
cometeu um pequeno delito, i. é, porque passava a vida em comezainas e banquetes, mandava-o
lapidar (Dt 21, 18 ss). Logo, as penas da lei foram inconvenientemente estatuídas.
10. Demais. — Diz Agostinho: as leis estabelecem oito gêneros de penas, segundo escreve Túlio e são os
seguintes: a multa, os ferros, os açoites, o talião, a infâmia, o exílio, a morte, a servidão. Dessas, a lei
antiga estatuiu algumas. Assim, a multa, quando o ladrão era condenado a pagar o quíntuplo ou o
quádruplo. Os ferros, quando mandava encerrar num cárcere o delinqüente. Os açoites, quando
determina (Dt 25, 2): Se virem que o delinqüente merece açoites, deitá-lo-ão em terra e fá-lo-ão açoitar
na sua presença. A infâmia era aplicada contra aquele que, não querendo desposar a mulher do seu
irmão defunto, esta lhe tirava o sapato e lhe cuspia na face. (Dt 25, 9) Também aplicava a pena de
morte, quando diz (Lv 20, 9): O que amaldiçoar o seu pai ou a sua mãe morra de morte. E enfim, a de
talião (Ex 21, 24): Olho por olho, dente por dente. Logo, inconvenientemente, a lei deixava de infligir as
outras duas penas — a da escravidão e a do exílio.
11. Demais. — A pena só é devida à culpa. Ora, os brutos não são passíveis de culpa. Logo,
inconvenientemente a lei lhe infligia pena, quando diz (Ex 21, 29): O boi, que matar um homem ou uma
mulher, será apedrejado; e (Lv 20, 16): A mulher que se ajuntar com qualquer bruto será morta
juntamente com ele. Donde se conclui que a lei antiga ordenou inconvenientemente sobre o convívio
social dos judeus.
12. Demais. — O Senhor mandou, que o homicídio fosse punido com a morte do homicida. Ora, a morte
de um bruto tem muito menos importância que a de um homem. Logo, a pena do homicídio não pode
ser suficientemente compensada pela de um bruto. Logo, é inconveniente a seguinte disposição da lei
(Dt 21, 1-4): Quando for achado o cadáver de um homem que foi morto, sem que se saiba quem foi o
matador, sairão os anciões da cidade mais vizinha e tomarão da manada uma novilha, que não tenha
ainda carregado como o jugo nem fendido a terra como o relho do arado; e levá-lo-ão a um vale áspero
e pedregoso, que nunca tivesse sido lavrado nem semeado, e ali cortarão o pescoço à novilha.
Mas, em contrário, a Escritura lembra o seguinte, como benefício (Sl 147, 20): Não fez assim a toda
outra nação e não lhes manifestou o seu juízo.

SOLUÇÃO. — Como diz Agostinho, citando Túlio, um povo é a associação de muitos indivíduos, baseada
no consenso jurídico e na utilidade comum. Por onde, a noção de povo implica uma comunhão de
homens ordenada por justos preceitos legais. Ora, há duas espécies de comunhão entre os homens.
Uma fundada na autoridade do príncipe; outra, na vontade própria dos indivíduos. E como cada um
pode dispor do que lhe pertence, é necessário que, pela vontade do príncipe, a justiça se exerça entre os
seus súditos e penas sejam infligidas aos malfeitores. Por outro lado, aos indivíduos lhes pertence o que
possuem; e portanto, por autoridade própria, podem dispor disso, uns em relação aos outros, por
compra, venda, doação e modos semelhantes.
Ora, sobre uma e outra espécie de comunhão a lei ordenou suficientemente. Assim, estabeleceu juízes
(Dt 16, 18): Estabelecerás juízes e magistrados em todas as tuas portas, para que julguem o povo com
retidão de justiça. Instituiu também a ordem justa do julgamento (Dt 1, 16-17): Julgai o que for justo, ou
ele seja cidadão ou estrangeiro: nenhuma distinção haverá de pessoas. Evitou ainda a ocasião de juízos
injustos, proibindo aos juízes aceitarem dádivas (Ex 23, 8; Dt 16, 19). Determinou, além disso, o número
duplo ou triplo das testemunhas. E enfim, estabeleceu penas certas pelos diversos delitos, como depois
se dirá (ad 10).
Quando à propriedade, é ótimo, como diz o Filósofo, que ela seja exercida separadamente; e o uso dela,
em parte, comum, e, em parte, dividido, por vontade dos proprietários.
Ora, estes três modos de possuir foram estabelecidos pela lei antiga. — Pois, primeiro, a propriedade foi
dividida entre particulares (Nm 33, 53-54): Eu vos dei a terra para a possuirdes, a qual repartireis entre
vós por sorte. Ora, como diz o Filósofo, muitas cidades foram destruídas pelos modos irregulares de
propriedade. Por isso a lei estabeleceu tríplice remédio para regular a propriedade. — O primeiro, que
fosse dividida igualmente pelo número de homens; por isso se diz: Aos que forem em maior número
dareis maior porção, e aos que forem menos, porção mais pequena. — O segundo, que a propriedade
não pudesse ser alienada perpetuamente, mas que, depois de certo tempo, revertesse aos seus
proprietários para que não se confundissem os lotes possuídos. — O terceiro, para evitar a confusão, de
os parentes próximos sucederem aos mortos. No primeiro grau, o filho; no segundo, a filha; no terceiro,
os irmãos; no quarto, os tios paternos; no quinto, quaisquer outros parentes próximos. E para conservar
ulteriormente a distinção dos lotes, a lei estatuiu que as mulheres herdeiras se casassem com homens
das suas tribos.
Quanto ao segundo modo de propriedade a lei instituiu que sob certos aspectos o uso das coisas fosse
comum. — Primeiro, quanto ao cuidado delas, preceitua (Dt 22, 1-4): Vendo extraviados o boi ou a
ovelha de teu irmão, não passarás de largo, mas conduzi-los-ás a teu irmão; e assim em casos
semelhantes. — Segundo, quanto ao fruto. Pois, era permitido em comum a todos entrar lìcitamente na
vinha do amigo e comer dela, contanto que não levasse frutos para fora. E mandava, especialmente,
que se deixassem para os pobres as gamelas esquecidas, os frutos e os cachos de uva remanescentes (Lv
19, 9; Dt 24, 19). E também eram repartidos, os frutos nascidos no sétimo ano.
Quanto ao terceiro modo, a lei estatuía a repartição feita pelos proprietários. — Uma, puramente
gratuita (Dt 14, 28-29): Todos os três anos separarás outro dízimo; e virão os levitas e o peregrino e o
órfão e a viúva e comerão e se fartarão. — Outra, em recompensa da utilidade, como, por compra e
venda, locação e condução, mútuo e, ainda, por depósito. E a respeito de tudo isso encontram-se
ordenações certas na lei.
Por onde claro fica, que a lei antiga ordenou suficientemente sobre as relações sociais do povo judeu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz o Apóstolo (Rm 13, 8), aquele que ama ao
próximo tem cumprido com a lei; porque todos os preceitos da lei, sobretudo os ordenados ao próximo,
o foram para o fim de os homens se amarem uns aos outros. Ora, do amor procede ao repartirem entre
si os seus bens, conforme a Escritura (1 Jo 3, 17): O que vir a seu irmão ter necessidade e lhe fechar as
suas entranhas, como está nele à caridade de Deus? Por isso a lei visava acostumar os homens a
repartirem facilmente entre si os seus bens; e também o Apóstolo manda aos ricos dêem facilmente e
repartam (1 Tm 6, 18). Ora, não reparte facilmente quem não suporta que o próximo tire, sem causar
grande detrimento, um pouco dos seus bens. Por isso, a lei ordenou que fosse lícito ao que entrasse na
vinha do próximo comer quantas uvas quisesse, sem levar consigo para fora, para que isso não fosse
ocasião de causar graves danos, que iria perturbar a paz. Pois, entre disciplinados, ela não se perturba
por tirar alguém um pouco dos bens de outrem, o que, ao contrário, confirma a amizade e acostuma os
homens a repartir facilmente.

RESPOSTA À SEGUNDA. — A lei determinou que só na falta de filhos varões as mulheres sucedessem
nos bens paternos. Pois então era necessário que a sucessão fosse concedida às mulheres, para
consolação do pai, a quem seria penoso ver a sua herança passar completamente a estranhos. Mas a lei
acrescenta neste ponto a cautela necessária ordenando que as mulheres, sucedendo na herança
paterna, casassem com homens da sua tribo, para se não confundirem os lotes das tribos.

RESPOSTA À TERCEIRA. — Como diz o Filósofo, a regulamentação da propriedade contribui muito para a
conservação da cidade ou da nação. Por isso, como ele ainda diz, certas nações gentias estatuíram, que
ninguém pudesse vender as suas propriedades, senão por manifesta necessidade. Pois, se as vendessem
a cada passo, poderia acontecer viesse à propriedade a cair totalmente em mãos de poucos; e então,
haveria necessariamente a cidade ou a região de ficar vazia de habitantes. Por isso a lei antiga, a fim de
evitar esse perigo, ordenou de modo a satisfazer às necessidades dos homens, permitindo a venda das
propriedades durante um certo tempo. Mas simultaneamente evitou o perigo, ordenando que depois
desse tempo, a propriedade vendida revertesse ao vendedor. E assim o fez para os lotes se não
confundirem, e permanecesse sempre a mesma distinção determinada das tribos. — Mas como os
edifícios urbanos não constituíam lotes distintos, a lei permitia que como os bens móveis, pudessem ser
vendidos definitivamente. Pois, não era fixo o número das casas da cidade, como era certa a medida dos
lotes, que não podia ser aumentada. Ao passo que o podia o número das casas urbanas. As casas, porém
que não eram urbanas e que não tinham muros em torno do terreno, não podiam ser vendidas em
caráter perpétuo; porque tais casas não eram construídas senão para a cultura e a guarda da
propriedade. Por isso e justamente, a lei estabeleceu a mesma disposição para elas que para os lotes.

RESPOSTA À QUARTA. — Como já se disse, a intenção da lei, nos seus preceitos, era levar a se
acostumarem os homens a satisfazer mutuamente às necessidades uns dos outros. Por isso sobretudo
fomenta a amizade. E essa facilidade de se proverem uns aos outros ela quis estabelecer, não só no
atinente às prestações gratuitas e absolutas, mas ainda ao concedido por mútuo. Porque este contrato é
o mais freqüente e o mais necessário ao maior número.
Por isso, institui muitas disposições para facilitar essa transação. Primeiramente, determinou que
fossem os judeus fáceis em fazer empréstimo, nem de tal se retraíssem por aproximar-se o ano da
remissão. — Segundo, não gravassem, aquele a quem concedessem mútuo, com usuras, ou recebendo
como penhor coisas absolutamente necessárias à vida, e se as recebessem, que as restituíssem
imediatamente. Pois assim se lê na Escritura (Dt 23, 19): Não emprestarás com usura a teu irmão; e (Dt
24, 6): Não receberás em lugar do penhor nem a mó de cima nem a de baixo, porque te deu por penhor
a sua própria vida; e ainda (Ex 22, 26):Se receberes do teu próximo em penhor a sua capa, restitua antes
do sol posto — Terceiro, não exigissem o pagamento importunamente. Assim, estatui (Ex 22, 25): Se
emprestares algum dinheiro ao necessitado do meu povo que habita contigo, não o apertarás como um
exator. E por isso também ordenava (Dt 24, 10-11):Quando requereres de teu próximo alguma coisa que
ele te deve, não entrarás em sua casa para dela levares algum penhor; mas estarás de fora e ele te trará
o que tiver. Isso, ou porque a casa, sendo o nosso mais seguro abrigo, é molesta ao dono que lha
invadam ou para não permitir ao credor tomasse o penhor que quisesse, mas antes, de modo que o
devedor desse como penhor aquilo de que menos precisasse. — Em quarto lugar, instituiu que, no
sétimo ano, os débitos fossem completamente perdoados. Pois era provável que os que podiam
restituir, comodamente, o fizessem antes do sétimo ano e não defraudasse, voluntariamente, o
prestamista. Se porém fossem os devedores absolutamente insolventes, os credores lhes deviam de
perdoar o débito em virtude do mesmo amor por que deviam dar de novo, por causa de indigência.
Quanto aos animais emprestados, a lei estatuiu o seguinte. Se morressem ou se estropiassem, na
ausência daquela a quem foram emprestados, e por negligência do mesmo, era ele obrigado à
restituição. Se porém morressem ou se estropiassem, apesar da sua presença e do cuidado diligente,
não estava obrigado a restitui. E sobretudo, se tivessem sido alugados. Porque, então, como podiam
morrer e estropiar-se em poder do mutuante, este, conseguida a conservação do animal, como já tinha
tirado lucro do mútuo, não teria mutuado de graça. Isto principalmente devia observar-se quando os
animais eram tomados por aluguel. Porque então, o uso deles, sendo pago por um certo preço, nada
mais se devia pagar, com a restituição dos mesmos, salvo por algum dano resultante da negligência do
prestamista. Se porem os animais não tivessem sido tomados de aluguel, poderia haver uma certa
eqüidade, de modo a pelo menos se pagar tanto quanto pudesse dar de aluguel o uso do animal morto
ou estropiada.

RESPOSTA À QUINTA. — O mútuo e o depósito diferem em ser o primeiro feito em benefício do
mutuado, enquanto o segundo, em benefício do depositante. Por isso, em certos casos, havia maior
obrigação de restituir o mútuo do que o depósito. Pois este podia perder-se de dois modos. Por uma
causa inevitável ou natural; p. ex., se o animal depositado morreu ou estropiou-se. Ou por uma causa
extrínseca, p. ex., se foi tomado por inimigos ou devorado por uma fera. E neste caso, havia obrigação
de restituir ao dono o que restava do animal morto. Nos demais casos supra-referidos, não havia
nenhuma obrigação de restituir; mas somente a de prestar juramento, para evitar a suspeita de fraude.
De outro modo, o depósito podia ser perdido por uma causa evitável, p. ex., o furto. E então, por causa
da sua negligência, o depositário tinha obrigação de restituir. Mas, como já dissemos (a. 4), quem
recebia um animal em mútuo, estava obrigado a restituí-lo, mesmo que, na sua ausência, o animal
tivesse morrido ou ficado estropiado. Assim, respondia por uma negligência menor que a por que
respondia o depositário, que era só a do furto.

RESPOSTA À SEXTA. — Os mercenários, que alugavam o seu trabalho, eram pobres e tiravam dele o
sustento quotidiano. Por isso a lei sabiamente ordenou que logo se lhes pagassem o salário, para lhes
não faltar o sustento. Mas os que alugavam outras coisas eram em geral ricos, e assim não precisavam
do preço da locação para o sustento quotidiano. Por onde, não é em ambos os casos a mesma a
situação.

RESPOSTA À SÉTIMA. — Os juízes são constituídos para resolverem os casos duvidosos de justiça entre
os homens. Ora, pode haver dupla dúvida. — Uma, entre pessoas simples. E para resolvê-la a lei
ordenava (Dt 16, 18): Estabelecerás juízes e magistrados em todas as tribos, para que julguem o povo
em retidão de justiça. — Mas também, pode haver dúvidas mesmo entre peritos. E, para o evitar, a lei
determinou que todos buscassem o lugar principal escolhido por Deus, em que haveria de estar o sumo
sacerdote, para resolver as dúvidas relativas às cerimônias do culto divino; e estabeleceu um juiz sumo
do povo, que resolvesse sobre o atinente aos julgamentos entre as partes. Assim também hoje, por
apelação ou consulta, as causas dos juízes inferiores são deferidas aos superiores. Por isso diz a lei (Dt
17, 8-9): Se acontecer que penda diante de ti algum negócio difícil e escabroso, e vires que dentro das
tuas portas são vários os pareceres dos juízes, levanta-te e sobe ao lugar que o Senhor teu Deus tiver
escolhido; e encaminhar-te-ás aos sacerdotes da linhagem da Levi e ao juiz que nesse tempo for. Mas,
como esses julgamentos de causas duvidosas não sucediam freqüentemente, o povo não ficava com isso
onerado.

RESPOSTA À OITAVA. — Os negócios humanos não são susceptíveis de prova demonstrativa e infalível;
mas basta uma probabilidade conjectural, como a de que usam os oradores. Por onde, embora seja
possível duas ou três testemunhas combinarem para mentir, não é contudo fácil nem provável que o
façam. Por isso recebesse o testemunho como verdadeiro, e sobretudo se neles não vacilarem e não
forem, por outras causas, suspeitas. E assim, porque as testemunhas não se desviavam facilmente da
verdade, a lei instituiu que fossem diligentíssimamente examinadas, e punidas gravemente as falsas.
Havia ainda alguma razão de determinar-lhes o número, que é significar a infalível verdade das Pessoas
divinas. Estas são às vezes consideradas como duas, porque o Espírito Santo é o nexo entre elas; ora,
como três, segundo Agostinho, comentando aquilo da Escritura (Jo 8, 17): E na vossa mesma lei está
escrito que o testemunho de duas pessoas é verdadeiro.

RESPOSTA À NONA. — Não só pela gravidade da culpa, mas também por outras inflige-se uma pena
grave. Primeiro, pela gravidade do pecado; pois, todas as condições sendo iguais, ao maior pecado é
devido pena mais grave. Segundo, por causa do costume no pecar; porque de pecados habituais os
homens não se afastam facilmente senão por meio de penas graves. Terceiro, por causa da intensa
concupiscência ou deleitação no pecado; coisas de que se os homens não apartam facilmente, senão
por causa de penas graves. Quarto, pela facilidade em cometer o pecado e perdurar nele; pois tais
pecados, quando manifestados, devem ser sobretudo punidos para aterrorizar os outros pecadores.
Quanto à gravidade do pecado, devemos atender a um quádruplo grau, ainda relativamente a um
mesmo fato. — O primeiro era quando alguém cometia o pecado involuntariamente. Então, se fosse
absolutamente involuntário, havia escusa completa da pena. Por isso, diz a lei, que se uma donzela for
violentada no campo, não é ré de morte, porque gritou e não houve alguém que a livrasse. Se porém o
pecado fosse de algum modo voluntário, mas cometido por fraqueza, p. ex., quando se peca por paixão,
esse pecado ficaria diminuído. E então a pena, conforme a um verdadeiro julgamento, devia diminuir.
Salvo, se merecesse ser agravada, por causa do bem comum, a fim de afastar os outros de cometerem
tal pecado, como já se disse. — O segundo grau era quando alguém pecava por ignorância. E então de
certo modo era reputado réu, por causa da negligência em informar-se; contudo, não era punido pelos
juízes, mas expiava o pecado com sacrifícios. Por isso dia a Escritura (Lv 4, 2): Se alguém pecar por
ignorância oferecerá uma cabra sem defeito. Mas, isto deve entender-se da ignorância de fato e não, da
ignorância do preceito divino, que todos eram obrigados a conhecer. — O terceiro grau era quando
alguém pecava por soberba, i. é, por eleição ou por malícia certas. E então era punido conforme a
gravidade do delito. — O quarto grau, quando pecava por protérvia e pertinácia. E nesse caso devia
absolutamente ser morto como rebelde e infrator da ordem legal.
Ora, conforme estas disposições devemos concluir que, na pena do furto, a lei considerava o que podia
freqüentemente acontecer. Por onde, no furto de coisas fáceis de se guardarem dos ladrões, estes não
deviam restituir senão o duplo. Ora, ovelhas não se podem facilmente guardar de serem furtadas, pois,
pastando nos campos, acontecia freqüentemente que o eram. Por isso a lei impôs pena maior,
estabelecendo se restituíssem quatro por uma. Mas já os bois se guardam mais dificilmente, por
viverem largados nos campos e não pastarem em rebanhos, como as ovelhas. Por isso, impôs em tal
caso pena ainda maior, mandando restituir cinco bois por um. E isto digo, não fosse o caso em que o
animal furtado fosse encontrado vivo em poder do ladrão; pois então, como nos demais furtos, restituía
só o duplo; por poder-se presumir que, conservando-o vivo, pensava em restituí-lo. Ou pode-se dizer,
segundo a Glosa, que o boi e a vaca têm cinco utilidades: serem imolados, arar, dar a carne, dar leite e
ainda fornecer couro para muitos ursos. Por isso, por um boi furtado, o ladrão devia restituir cinco.
Também a ovelha tem quatro utilidades: ser imolado, dar carne, leite, e fornecer a lã.
Quanto ao filho contumaz, era morto, não por ter comido e bebido; mas por causa da contumácia e da
rebelião, sempre punidas de morte, como se disse. — O que colhia lenha ao sábado era lapidado, como
violador da lei, que mandava observar o sábado em comemoração da criação do mundo, como já
dissemos (q. 100, a. 5); por isso era morto como infiel.

RESPOSTA À DÉCIMA. — A lei antiga infligia a pena de morte nos crimes mais graves, i. é, nos pecados
contra Deus, no homicídio, no furto de homens, na irreverência para com os pais, no adultério e no
incesto. Mas, no furto de outras coisas, estabeleceu a pena da multa. Nos ferimentos e mutilações, a
pena de talião, e semelhantemente, no pecado de falso testemunho. Nas outras culpas menores, a de
flagelação ou de infâmia.
A pena de escravidão infligiu-a em dois casos. Primeiro, quando, no sétimo ano da remissão, o escravo
não queria usar do benefício da lei e sair livre; por isso era-lhe infligida a pena de ficar perpetuamente
escravo. Segundo, ao ladrão, quando não tinha como o que restituir.
A pena do exílio a lei não a cominou, absolutamente falando, porque, enquanto os demais povos jaziam
na corrupção da idolatria, só o povo judeu adorava a Deus. Por isso, se alguém fosse excluído
completamente desse povo, correria perigo de cair na idolatria. Por onde, a Escritura refere que Davi
disse a Saul (1 Sm 26, 19): Malditos são os que me arrojaram hoje, para que eu não habite na herança
do Senhor, dizendo: Vai, serve a deuses estrangeiros. Havia porém um exílio particular, e era o seguinte.
Quem ferisse, sem o cuidar, o próximo, não podendo provar-se que nutria qualquer ódio contra ele,
devia refugiar-se numa das cidades destinadas para tal e aí permanecer até a morte do sumo sacerdote.
E então era-lhe lícito voltar para a casa; porque as iras particulares costumam aplacar-se com
calamidade geral do povo; e assim, já os parentes próximos do morto não estavam mais propensos a
matar o homicida.

RESPOSTA À UNDÉCIMA. — Mandavam-se matar os animais, não por qualquer culpa deles, mas como
pena dos donos, que não os impediram de cometerem as referidas transgressões da lei. Por isso, o dono
era sobretudo punido se o boi já era muito avezado a marrar; pois nesse caso podia obviar o perigo mais
facilmente, que se o boi se pusesse subitamente a dar marradas. Ou os animais eram mortos para fazer
detestar o pecado, e pelo seu aspecto, não incutirem horror nos homens.

RESPOSTA À DUO DÉCIMA. — A razão literal da disposição citada estava, como diz Rabbi Moisés, em ser
freqüentemente o homicida de alguma cidade próxima. E matava-se a novilha para descobrir o
homicídio oculto; o que se fazia por três meios. Um era que os anciãos convocados juravam nada ter
omitido para guardar os caminhos. Outros, que o dono da novilha era danificado com a morte da
mesma; de modo que se, antes, o homicídio fosse descoberto, o animal não seria morto. O terceiro, que
o lugar em que a novilha fosse morta permanecia inculto. Por isso, a fim de evitar um e outro dano, os
homens da cidade facilmente indicariam o homicida, se o soubessem; e raramente aconteceria que não
se viesse a saber quaisquer palavras ou indícios relativos a ele. — Ou isso se fazia para incutir o terror do
homicídio e fazer detestá-lo. Assim, a morte da novilha, animal útil e robusto, principalmente antes de
trabalhar sob o jugo, significava que quem quer que cometesse um homicídio, embora útil e forte, devia
ser morto e com morte cruel, significada pela degolação. E que, como vil e objeto, devia ser excluído do
convívio humano. Isso era significado pelo abandono da novilha morta num lugar áspero e inculto, para
apodrecer.
Misticamente porém, a novilha do rebanho significa a carne de Cristo, que não sofreu o jugo, não
cometeu pecado nem fendeu a terra com o arado, i. é, não se manchou com mácula nenhuma de
sedição. O ser morta num vale áspero, significa a desprezada morte de Cristo, que purgou todos os
pecados; e mostra que o diabo é o autor do homicídio.

## Art. 3 — Se os preceitos judiciais relativos aos estrangeiros foram convenientemente estabelecidos.
O terceiro discute-se assim. — Parece que os preceitos judiciais relativos aos estranhos não foram
convenientemente estabelecidos.

1. — Pois, diz Pedro (At 10, 34-35): Tenho na verdade alcançado que Deus não faz acepção de pessoas;
mas que em toda nação aquele que teme a Deus e obra o que é justo, esse lhe é aceito. Ora, os que são
aceitos de Deus, não devem ser excluídos da sua igreja. Logo, a lei mandava inconvenientemente; que o
Amonita e o Moabita não entrarão jamais na congregação do Senhor, ainda depois da décima geração. E
ao contrário, no mesmo capítulo, ordena, a respeito de certas nações (Dt 23, 7): Não abominarás o
Idumeu, porque é teu irmão, nem o Egiptano, porque tu foste estrangeiro na sua terra.

2. Demais. — Pelo que não depende de nós não podemos merecer nenhuma pena. Ora ser eunuco ou
nascer de mulher pública não depende de ninguém. Logo, a lei ordena inconvenientemente (Dt 23, 1-
2): O eunuco e o que nasceu de mulher pública não entrarão na congregação do Senhor.

3. Demais. — A lei antiga ordenou misericordiosamente, que o estrangeiro não fosse afligido, quando
diz (Ex 22, 21): Não molestarás nem afligirás o estrangeiro, porque também vós mesmos fostes
estrangeiros na terra do Egito; e ainda (Ex 23, 9): Não será molesto ao estrangeiro, porque vós sabeis
que almas são as dos estrangeiros, pois que também vós o fostes na terra do Egito. Ora, aflige a outrem
quem o aprime com usuras. Logo, a lei permitiu inconvenientemente emprestar usurariamente dinheiro
aos outros.

4. Demais. — Muito mais nossos próximos são os homens que as árvores. Ora, devemos, aos que nos
são mais próximos, ter mais afeto e mostrar os efeitos do amor, conforme a Escritura (Sr 13, 19): Todo
animal ama ao seu semelhante; assim também todo homem ama ao seu próximo. Logo, o Senhor
mandou, inconvenientemente, que matassem todos os prisioneiros das cidades inimigas e que
entretanto não cortassem as árvores frutíferas.

5. Demais. — O bem comum deve, por natureza, ser preferido por todos ao bem particular. Ora, na
guerra feita contra os inimigos visa-se o bem comum. Logo, a lei mandava, inconvenientemente que, na
iminência de um combate, voltasse para a casa o que, p. ex., acabou de edificar um prédio novo, ou o
que plantou uma vinha, ou o que desposou uma mulher.

6. Demais. — Ninguém deve tirar vantagem de uma culpa. Ora, é culpado o homem medroso e de
coração pávido; pois falta-lhe a virtude da fortaleza. Logo, eram inconvenientemente escusados dos
trabalhos do combate os medrosos e os pávidos de coração.
Mas, em contrário, diz a Divina Sabedoria (Pr 8, 8): Justos são todos os meus discursos: neles não há
coisa má nem depravada.

SOLUÇÃO. — Podem os homens ter com os estrangeiros dupla relação: uma, pacífica; outra hostil. E a
lei estabeleceu preceitos convenientes para regularem ambos esses casos.
Assim, aos judeus se oferecia tríplice ocasião de conviver pacificamente com os estrangeiros. —
Primeiro, quando, peregrinos, os estrangeiros passavam pelas terras deles. — Segundo, quando vinham
para elas afim de aí habitarem ádvenas. E em ambos os casos a lei estabeleceu preceitos de
misericórdia. Assim diz (Ex 22, 21): Não molestarás o estrangeiro; e (Ex 22, 9): Não serás molesto ao
estrangeiro. — Terceiro, quando alguns estrangeiros queriam ser admitidos totalmente ao convívio e
rito deles, no que se atendia a uma certa ordem. Assim, não eram logo recebidos como cidadãos; do
mesmo modo certos povos gentios tinham estabelecido, que não fossem considerados cidadãos senão
os que tivessem tido avós ou bisavós com essa qualidade, conforme o refere o Filósofo. E isto porque se
os estrangeiros, logo ao chegarem, fossem admitidos ao gozo dos direitos dos nacionais, poderiam dar
lugar a muitos perigos. Assim, não tendo ainda um amor comprovado pelo bem público, poderiam
atentar contra o povo. Por isso a lei estabeleceu, que podiam ser recebidos a fazer parte do povo, na
terceira geração, os que provinham de certas nações, de alguma afinidade com os judeus. Tais eram os
egípcios, entre os quais nasceram e foram criados, e os idumeus, filhos de Esaú, irmão de Jacó. Outras
porém, como os amonitas e os moabitas, que se portaram hostilmente para com eles, nunca os
admitiam no seu seio. Enfim os amalecitas, que foram os seus piores inimigos, e com os quais não
tinham nenhuma cognação, eles os consideravam como inimigos perpétuos. Por isso, diz a Escritura (Ex
17, 16): A guerra do Senhor será contra Amalec de geração em geração.
Também, quanto às relações hostis como os estrangeiros, a lei estabeleceu preceitos adequados. —
Assim, primeiro, instituiu que se fizesse a guerra justamente, mandando que, quando fossem atacar
uma cidade, primeiro oferecessem a paz. — Segundo, que continuassem fortemente a guerra
empreendida, confiando em Deus; e para ser isso melhor observado, instituiu que, na iminência do
combate, o sacerdote os animasse, prometendo o auxílio de Deus. — Terceiro, ordenou que se
removessem os impedimentos ao combate, mandando voltassem para a casa certos que podiam causar
tais impedimentos. — Quarto, instituiu que usassem moderadamente da vitória, poupando mulheres e
crianças, e também não cortando as árvores frutíferas da região.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A lei não excluía do culto de Deus os homens de
nenhuma nação, e nem do que dizia respeito à salvação da alma. Assim, diz (Ex 12, 48): Se algum
peregrino quiser passar para a vossa terra e celebrar a Páscoa do Senhor, circuncidem-se primeiro todos
os seus varões, e então o celebrará como é devido e será como natural da mesma terra. Mas, na ordem
das coisas temporais, no concernente à comunidade do povo, nela não se admitia nenhum estrangeiro
imediatamente, pela razão supra dita. Mas alguns, como os egípcios e os idumeus, só depois da terceira
geração; outros eram excluídos perpetuamente, em detestação da culpa passada, como os moabitas, os
amonitas e os amalecitas. Pois, assim como um homem é punido pelo pecado que cometeu, afim de os
outros, com esse exemplo, temerem e se absterem de pecar; assim também, por algum pecado, uma
nação ou cidade pode ser punida, para as outras se absterem de pecado semelhante. Podia porém
alguém, excepcionalmente, ser admitido no grêmio do povo, por algum ato de virtude. Assim, como se
lê na Escritura (Jd 14, 6), Aquior, o general dos filhos de Amon, foi incorporado no povo de Israel, e toda
a descendência da sua linhagem. E semelhantemente, Rute moabita, que era mulher virtuosa. Embora
se possa dizer, que a referida proibição se aplicava aos homens e não, às mulheres, que não podem ser,
absolutamente falando, cidadãs.

RESPOSTA À SEGUNDA. — Como diz o Filósofo, um cidadão pode ser considerado à dupla luz: absoluta
e relativamente. Do primeiro modo, é cidadão quem pode praticar atos próprios de cidadão; p. ex.,
tomar parte no conselho ou nos juízos do povo. Do segundo, pode ser considerado cidadão todo
habitante da cidade, mesmo os escravos, as crianças e os velhos, sem a capacidade que lhes dê poder
sobre o pertencente à comunidade. Por isso, também os espúrios eram excluídos, por causa da sua
origem vil, da igreja e do grêmio do povo, até a décima geração. Semelhantemente, os eunucos, por não
poderem ter a honra de serem pais; e, sobretudo, no povo judeu, em que o culto de Deus era
conservado segundo a geração carnal. Pois, mesmo entre os gentios, os que geravam muitos filhos eram
distinguidos com alguma honra insigne, como diz o Filósofo. Contudo, no atinente à graça de Deus, os
eunucos, bem como os estrangeiros, não eram separados dos demais, como se disse. Assim, diz a
Escritura (Is 56, 3): E não diga o filho do estrangeiro, o qual se une ao Senhor, proferindo: O senhor com
uma divisão me separará do seu povo. E não diga o eunuco: Eis-me aqui um lenho seco.

RESPOSTA À TERCEIRA. — Receber usuras dos outros, não estava na intenção da lei, que apenas o
permitia, por causa da inclinação dos judeus para a avareza. E para se comportar mais pacificamente
para com os estrangeiros dos quais auferiam lucros.

RESPOSTA À QUARTA. — A lei fazia uma certa diferença relativa às cidades inimigas. Umas eram
remotas e não do número das que lhes eram prometidas. E nessas, uma vez vencidas, matavam os
varões que lutaram contra o povo de Deus; poupando porém mulheres e crianças. Mas, das cidades
vizinhas, que lhes estavam prometidas, mandavam-se matar todos, por causa das iniqüidades dos
antepassados, para punir as quais o Senhor mandava o povo de Israel, como, por assim dizer, executor
da divina justiça. Assim, diz a lei (Dt 9, 5):Porque elas obraram impiamente, por isso foram destruídas à
tua entrada. Quanto às árvores frutíferas mandava-se fossem poupadas, para utilidade do próprio povo,
a cujo bem estar devia servia a cidade com o seu território.

RESPOSTA À QUINTA. — O construtor de uma casa nova, ou o plantador da vinha, ou o que desposou
uma mulher eram excluídos do combate, por duas razões. Primeiro, por os homens costumarem amar
mais o que acabam ou estão a ponto de possuir, e por isso temendo muito perdê-lo. Por onde, era
provável que, por causa de tal amor, também temessem muito a morte, e assim fossem menos fortes na
luta.
Segundo, porque, como diz o Filósofo, é considerado um infortúnio perdermos um bem que estávamos
a ponto de possuir. Ora, os parentes, que ficavam, haviam de se contristar demasiado com a morte dos
que foram para a guerra, sem poderem tomar conta dos bens que estavam a ponto de possuir. E
também o povo, considerando nisso, havia de ficar horrorizado. Por isso, tais homens ficavam livres do
perigo da morte, afastados da luta.

RESPOSTA À SEXTA. — os medrosos eram mandados para a casa não em benefício próprio, mas para ao
povo não advirem danos, da presença deles. Pois o temor e a fuga dos mesmos provocariam também os
outros a temer e a fugir.

## Art. 4 — Se a lei antiga estabeleceu convenientemente preceitos relativos à sociedade doméstica.
(IV. Sent., dist. XXXIII, q. 1, a. 3, qª 3, ad 3 ; q. 2, a 2, qª 1, 2, 4. III Cont. Gent., cap. CXXIII, CXXV).
O quarto discute-se assim. — Parece que a lei antiga estabeleceu inconvenientemente preceitos
relativos à sociedade doméstica.

1. — Pois, tudo quanto o escravo é pertence ao dono, como diz o Filósofo. Ora, o que pertence a alguém
deve pertencer-lhe perpetuamente. Logo, a lei ordenava inconvenientemente, que, no sétimo ano, os
escravos ficassem livres.

2. Demais. — Assim como um asno ou um boi é propriedade do dono, assim também o escravo. Ora, a
lei ordenava, que os animais extraviados fossem restituídos ao dono. Logo, ordenava
inconvenientemente ao dizer (Dt 23, 15): Não entregarás a seu senhor o escravo que se tiver acolhido a
ti.

3. Demais. — A lei divina deve ser mais misericordiosa que a humana. Ora, as leis humanas punem
gravemente os que castigam demasiado asperamente os escravos ou as escravas. Ora, o mais áspero
dos castigos é o que produz a morte. Logo, a lei estatuía inconvenientemente ao dizer (Ex 21, 20-21): O
que ferir o seu escravo ou a sua escrava com uma vara, se sobrevier um ou dois dias, não ficará ele
sujeito à pena, porque é dinheiro seu.

4. Demais. — O domínio do senhor sobre os escravo é diferente do domínio do pai sobre o filho como
diz Aristóteles. Ora, é por causa do domínio servil, que o dono podia vender o escravo ou a escrava.
Logo, a lei permitia inconvenientemente que o pai pudesse vender, para criada ou escrava, a sua filha.

5. Demais. — O pai tem poder sobre o filho. Ora, punir em excesso pertence a quem tem poder sobre o
pecador. Logo, a lei mandava inconvenientemente, que o pai levasse o seu filho aos anciãos da cidade,
para ser punido.

6. Demais. — O Senhor proibiu que se contraíssem casamentos com estrangeiros, e se dissolvessem os
assim contraídos. Logo, a lei permitia inconvenientemente que se pudesse casar com as cativas
estrangeiras.

7. Demais. — O Senhor ordenou que, ao se casarem, evitassem certos graus de consangüinidade e
afinidade. Logo, a lei mandava inconvenientemente que o irmão do que morresse sem filhos lhe
desposasse a mulher.

8. Demais. — Entre marido e mulher, havendo a máxima familiaridade, deve também haver a fidelidade
mais firme. Ora, tal não poderá ser se o matrimonio for dissolúvel. Logo, o Senhor permitiu
inconvenientemente, que o marido pudesse demitir a mulher, depois de escrito o libelo de repúdio; e
que, ulteriormente, não pudesse retomá-la.

9. Demais. — Assim como a mulher pode romper a fidelidade para com o marido, assim também o pode
o dono em relação ao escravo e o filho, ao pai. Ora, para investigar a injúria do escravo contra o senhor
ou do filho contra o pai, a lei não instituiu nenhum sacrifício. Logo, parece supérfluo ter instituído o
sacrifício da zelotipia, para investigar o adultério da mulher. Assim, pois, a lei estabeleceu
inconvenientemente os preceitos judiciais relativos à sociedade doméstica.
Mas, em contrário, diz a Escritura (Sl 18, 10): Os juízos do Senhor são verdadeiros, cheios de justiça em si
mesmos.

SOLUÇÃO. — A sociedade doméstica se funda, como diz o Filósofo, na conveniência quotidiana,
ordenada às necessidades da vida. Ora, a vida humana se conserva de dois modos. — Individualmente,
enquanto cada homem constitui um indivíduo. E para conservar essa vida, ajuda-se o homem dos bens
exteriores, donde tira a alimentação, a roupa e o mais, necessário para viver. E para tomar conta disso
tudo precisa de escravos. — De outro modo, especificamente, pela geração, para o que precisa de
mulher, que lhe gere filhos. Por isso, na comunhão doméstica, há três relações: a do dono para como o
escravo; do marido para com a mulher; do pai para com os filhos. — Ora, a esses três casos, a lei antiga
estabeleceu preceitos adequados.
Assim, mandava que os escravos fossem tratados benevolamente. Para não sofrerem trabalhos
imoderados, o Senhor ordenou que (Dt 5, 14), no dia do sábado, descansasse o teu escravo e a tua
escrava bem como tu. E, além disso, no infligir às penas, impôs que os mutiladores dos escravos os
deixassem ir livres. E o mesmo estabeleceu relativamente à escrava com quem alguém tivesse casado.
Também e especialmente determinou, que os escravos que faziam parte do povo, saíssem livres, no
sétimo ano, com tudo o que trouxeram, mesmo com a roupa. Mandava ainda a lei que se lhes desse
viático.
Quanto ao casamento, a lei estatuía que os homens se casassem com mulheres da sua tribo; isso para se
não confundirem os lotes das tribos. E que um irmão se casasse com a mulher do seu irmão defunto e
sem filhos. Isto para que quem não pode ter sucessores do seu sangue, tivesse-os ao menos por adoção,
e assim não se lhe delisse totalmente a memória. Proibia também o casamento entre certas pessoas.
Assim com mulheres estrangeiras, por causa do perigo da sedução; e com próximas parentas, pela
reverência natural a elas devida. Estipulou também como os maridos deviam tratar a mulher com quem
casaram. Assim, nem de leve deviam infamá-la; por isso mandava punir o que atribuía um falso crime à
sua mulher. E também, por ódio dele contra a mulher, que o filho não sofresse nenhum detrimento. E
ainda, que, por ódio, o marido não castigasse a mulher, mas antes, escrevendo um libelo, a repudiasse.
E, enfim, para que, desde o princípio, os cônjuges se ligassem com grande amor, mandava que a quem
tivesse casado de pouco não se lhe impusesse nenhum encargo público, a fim de poder livremente gozar
da convivência com sua mulher.
Quanto aos filhos, instituiu que os pais lhes dessem educação, instruindo-os na fé. Por isso diz (Ex 12, 26
ss):Quando os vossos filhos vos disserem: Que rito é este? Responder-lhes-eis: É a vítima da passagem
do Senhor. E que lhes ensinassem os bons costumes. Por isso, os pais deviam dizer-lhes (Dt 21,
20): Despreza ouvir as nossas admoestações, passa a vida em comezainas e dissoluções e banquetes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Senhor não quis que os filhos de Israel, por Ele libertos
da escravidão, e transferidos para o serviço divino, ficassem perpetuamente escravos. Por isso diz a
Escritura (Lv 25, 39): Se, constrangido da pobreza, se vender a ti teu irmão, não o oprimirás com a
servidão de escravo; mas o tratarás como jornaleiro e colono; porque eles são meus servos e eu os tirei
da terra do Egito, não se vendam em qualidade de escravos. Por onde, como eram escravos, não
absoluta, mas relativamente falando, terminado o prazo, eram mandados livres.

RESPOSTA À SEGUNDA. — A ordenação referida entende-se do escravo procurado pelo dono para
matá-lo, ou para algum ministério pecaminoso.

RESPOSTA À TERCEIRA. — A lei distinguia se os ferimentos feitos nos escravos eram certos ou incertos.
Se certos, impunha uma pena. Assim, no caso de mutilação, impunha a pena da perda do escravo, que
devia ser posto em liberdade; no de morte, a pena do homicídio, quando o escravo morria nas mãos do
dono, que o castigava. Se porém a lesão fosse certa, mas, só aparente, i. é, se o escravo castigado não
morria imediatamente, mas, só depois de alguns dias, a lei não infligia nenhuma pena, por ser ele
propriedade do dono. Pois, em tal caso era incerto se morrera do ferimento. Se porém o ferido fosse um
homem livre, que não morrera imediatamente, mas andasse encostado ao seu bordão, não era réu de
homicídio quem o feriu, mesmo que o ferido viesse a morrer subseqüentemente. Mas estava obrigado a
pagar as despesas que a vítima fez com os médicos. Ora, isto não se dava com o escravo, propriedade
do dono; porque tudo quanto o escravo tinha, e até mesmo a sua pessoa, era propriedade daquele. Por
isso, a lei dava como causa de não sofrer o dono a pena pecuniária, ser o escravo dinheiro seu.

RESPOSTA À QUARTA. — Como já se disse (ad 1), nenhum judeu podia possuir outro como escravo,
absolutamente, mas só, de certo modo, como mercenário, por algum tempo. E, assim, a lei permitia
que, por pobreza premente, o pai vendesse o filho ou a filha. Isto o dizem claramente as palavras
mesmas da lei: Se alguém vender sua filha para ser serva, esta não sairá como costumam sair às
escravas. E do mesmo modo, alguém podia vender, não só o filho, mas também a si mesmo, mais como
mercenário, que como escravo, conforme aquilo (Lv 25, 39-40): Se, constrangido da pobreza, se vender
a ti teu irmão, não o oprimirás com a servidão de escravo, mas o tratarás como jornaleiro e colono.

RESPOSTA À QUINTA. — Como diz o Filósofo, o governo paterno só tem o poder de admoestar; mas não
tem poder coativo, pelo qual podem ser coibidos os rebeldes e os contumazes. Por isso, neste caso, a lei
mandava que o filho contumaz fosse punido pelos governadores da cidade.

RESPOSTA À SEXTA. — O senhor proibia que as mulheres estrangeiras fossem tomadas em matrimônio,
por causa do perigo de sedução, afim de não caírem na idolatria. E especialmente o proibia se essas
mulheres pertencessem às nações vizinhas, a cujos ritos os judeus podiam mais facilmente se apegar.
Aquela porém, que quisesse deixar o culto dos ídolos e converter-se ao culto da lei, podia ser tomada
em matrimônio. Tal foi o caso de Rute, que casou com Booz, a qual disse à sua sogra (Rt 1, 16): O teu
povo será o meu povo e o teu Deus, o meu Deus. Por isso a cativa não podia ser aceita como esposa,
senão depois de raspada a cabeleira, cortadas as unhas e deixadas às vestes com que foi prisioneira, ter
chorado o pai e a mãe; o que significava a perpétua rejeição da idolatria.

RESPOSTA À SÉTIMA. — Como diz Crisóstomo, a morte era mal inconsolável para os judeus, que faziam
tudo para a vida presente. Por isso foi-lhes estatuído que ao defunto se lhe nascesse um filho, do irmão;
o que era uma como mitigação da morte. Determinava-se porém que ninguém, a não ser o irmão ou um
parente próximo, desposasse a mulher do defunto, porque, do contrário, o que nascesse de tal união
não era considerado filho do que morrera. Além disso, um estranho não tinha tanto interesse em
perpetuar a família do defunto, como o tinha o irmão, ao qual também, pelo parentesco, era justo que
assim procedesse. Por onde é claro que o irmão, ao desposar a mulher de seu irmão, fazia às vezes da
pessoa do defunto.

RESPOSTA À OITAVA. — A lei permitia o repúdio da esposa; não que isso fosse absolutamente justo,
mas por causa da dureza dos judeus, como diz o Senhor (Mt 19, 8). Mas isto devemos versar mais
desenvolvidamente, quando tratarmos do matrimonio (IIa IIae, q. 67).

RESPOSTA À NONA. — A esposa quebra a fé do matrimonio pelo adultério; e isso facilmente, levada do
prazer, e às escondidas, porque o olho do adúltero observa a escuridão como diz a Escritura (Jó 24, 15).
Mas, não há a mesma relação entre o pai e o filho que entre o escravo e o senhor. Porque a infidelidade
entre eles não procede do desejo do prazer, mas antes, da malícia; nem pode ficar oculto, como a
infidelidade da mulher adúltera.