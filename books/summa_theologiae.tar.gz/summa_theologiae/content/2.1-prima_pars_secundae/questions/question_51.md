# Questão 51: Da causa dos hábitos quanto à geração deles.
Em seguida devemos tratar da causa dos hábitos. E, primeiro, quanto à geração deles. Segundo, quanto
ao aumento. Terceiro, quanto à diminuição e à corrupção.
Sobre a primeira questão quatro artigos se discutem:

## Art. 1 — Se há hábitos procedentes da natureza.
(Infra, q. 63, a. 1)
O primeiro discute-se assim. — Parece que nenhum hábito é procedente da natureza.

1. — Pois, o uso do que procede da natureza não depende da nossa vontade. Ora, o hábito é aquilo de
que usamos quando quisermos, como diz o Comentador. Logo, o hábito não procede da natureza.

2. Demais — O que a natureza pode fazer por um meio não o faz por dois. Ora, as potências da alma
procedem da natureza. Se, pois, os hábitos das potências também dela procedessem, o hábito e a
potência seriam idênticos.

3. Demais — A natureza não falha no necessário. Ora, os hábitos são necessários para operarmos bem,
como já se disse. Se pois houvesse hábitos procedentes da natureza, esta não falharia e portanto
causaria necessariamente todos os hábitos. Ora, isto é claramente falso. Logo, o hábito não procede da
natureza.
Mas, em contrário, Aristóteles coloca, entre os hábitos, o intelecto dos princípios, que procede da
natureza, sendo por isso que os primeiros princípios se consideram naturalmente conhecidos.

SOLUÇÃO. — Uma coisa pode ser natural de dois modos. Pela natureza da espécie; assim, é natural ao
homem o riso e ao fogo o ser levado para cima. Ou pela natureza do indivíduo; assim é natural a
Sócrates ou a Platão ser doentio ou sadio, segundo a própria compleição. Além disso, relativamente a
uma e outra natureza, uma coisa pode chamar-se natural de dois modos. Ou por proceder totalmente
da natureza; ou por dela proceder em parte e, em parte, de um princípio exterior. Assim, quando
alguém sara por si, toda a saúde procede da natureza; e quando sara com o auxílio de um remédio, a
saúde provém, parte da natureza e, parte, de um princípio exterior.
Se considerarmos, pois, o hábito como disposição do sujeito em relação à forma ou à natureza, ele é
natural de qualquer dos dois modos supra-referidos. Assim, há uma disposição natural, própria à
espécie humana, que abrange todos os homens; e essa é natural pela natureza da espécie. Mas como
essa disposição implica uma certa amplitude, os seus diversos graus podem convir aos diversos homens
segundo a natureza do indivíduo; e tal disposição pode provir totalmente da natureza ou, em parte
apenas, provindo então, por outra parte, de um princípio exterior, como já dissemos referindo-nos aos
que saram por meio da arte médica.
O hábito porém, que é disposição para a operação cujo sujeito é alguma potência da alma, como já
dissemos, pode, certo, ser natural, tanto pela natureza da espécie, como pela do indivíduo. Pela
natureza da espécie, enquanto depende da alma que, sendo forma do corpo, é um princípio específico.
Pela natureza do indivíduo, enquanto depende do corpo, que é um princípio material. De nenhum
desses dois modos porém pode o homem ter hábitos naturais, de maneira que procedam totalmente da
natureza. Podem eles existir porém nos anjos, enquanto têm espécies inteligíveis naturalmente infusas,
o que não convém à natureza humana, como já dissemos na Primeira Parte
Logo, há nos homens certos hábitos naturais, procedentes, parte, da natureza e, parte, de um princípio
exterior.
Isso dá-se porém de um modo, com as potências apreensivas e, de outro, com as apetitivas.
Em relação às primeiras um hábito pode ser natural, incoativamente, quanto à natureza da espécie e
quanto à do indivíduo. — Quanto aquela, por parte da alma em si mesma; assim, dizemos que o
intelecto dos princípios é um hábito natural. Pois, pela natureza mesma da alma intelectual é próprio ao
homem conhecer o todo como maior que uma das partes, desde que conheça o que é todo e o que é
parte; e assim, em casos semelhantes. Mas, conhecer o todo e a parte ele não o pode senão pelas
espécies inteligíveis hauridas nos fantasmas. E, por isso, o Filósofo mostra que o conhecimento dos
princípios provém em nós dos sentidos. — Quanto à natureza do indivíduo, um hábito cognoscitivo é
natural incoativamente, enquanto um homem, por disposição orgânica, é mais apto para bem inteligir,
que outro, na medida em que precisamos das potências sensitivas para a operação do intelecto.
Nas potências apetitivas porém, não há nenhum hábito natural, incoativamente, por parte da alma, se
levamos em conta a substância mesma do hábito, mas só se nos referimos a certos princípios deste;
assim, os princípios do direito comum são chamados sementeiras das virtudes. E isto porque a
inclinação para os objetos próprios, que é considerada uma incoação do hábito, não lhe pertence a este,
mas antes, à natureza mesma da potência. — Quanto ao corpo, porém, levando em conta a natureza do
indivíduo, há certos hábitos apetitivos por incoações naturais. Pois, certos são dispostos, pela própria
compleição do corpo, à castidade, à mansidão ou a disposições semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe quanto à natureza dividida por oposição
à razão e à vontade, embora esta e aquela, em si mesmas, pertençam à natureza do homem.

RESPOSTA À SEGUNDA. — O que não pode pertencer a uma potência, em si mesma, pode contudo, se
lhe acrescentar naturalmente. Assim, não pode pertencer à potência intelectiva mesma dos anjos o ser
cognoscitiva de tudo, porque então haveria necessariamente de ser o ato de tudo, o que só a Deus
convém. Pois é necessário seja aquilo pelo que um objeto é conhecido uma semelhança natural dele.
Donde se seguiria que se a potência do anjo conhecesse tudo por si mesma, seria semelhança e ato de
tudo. Por onde é necessário que às suas potências intelectivas se acrescentem certas espécies
inteligíveis, semelhanças das coisas inteligidas; pois, por participação da divina sabedoria, e não pela
essência própria, os intelectos deles podem ser, em ato, aquilo que inteligem. E assim é claro que nem
tudo o que pertence ao hábito natural pode pertencer à potência.

RESPOSTA À TERCEIRA. — A natureza não se comporta do mesmo modo no causar todas as
diversidades dos hábitos; pois, certos podem ser causados por ela e certos, não, como já dissemos.
Donde não se segue que todos os hábitos sejam naturais, pelo serem alguns.

## Art. 2 — Se certos hábitos podem ser causados por algum ato.
(De Malo, q. 11. a . 2 ad 4, 6; De Virtut., q. 1. a . 9).
O segundo discute-se assim. — Parece que um hábito não pode ser causado por nenhum ato.

1. — Pois, o hábito é uma qualidade, como já se disse. Ora, toda qualidade é causada num sujeito,
enquanto este é susceptível de receber alguma coisa. Ora, como o agente, por isso mesmo que o é, não
é receptivo, mas antes, produtor, conclui-se que nenhum hábito pode nele ser gerado pelos seus
próprios atos.

2. Demais — Aquilo em que alguma qualidade é causada move-se para essa qualidade, como se vê
claramente no que é aquecido ou resfriado. Ora, o que produz um ato causador da qualidade, move,
como claramente o deixa ver aquilo que aquece ou resfria. Se portanto o hábito fosse causado num ser
por um ato próprio deste, resultaria que o mesmo ser seria motor e movido, ou, agente e paciente, o
que é impossível, como já se disse.

3. Demais — Um efeito não pode ser mais nobre que a sua causa. Ora, o hábito é mais nobre que o ato
que o precede, o que se evidencia por torná-los mais nobres. Logo, o hábito não pode ser causado por
um ato precedente.
Mas, em contrário, o Filósofo ensina que os hábitos das virtudes e dos vícios são causados pelos atos.

SOLUÇÃO. — O agente inclui às vezes só o princípio ativo do seu ato; assim, no fogo há apenas o
princípio ativo do aquecimento. E, nenhum hábito de tal agente pode ser causado pelo ato próprio do
mesmo. Donde vem que os seres naturais não podem acostumar-se ou desacostumar-se em relação a
nada, como já se disse.
Certos agentes, porém, incluem um princípio ativo e passivo dos seus atos, como se vê claramente nos
atos humanos. Pois os atos da potência apetitiva dela procedem enquanto movida pela potência
apreensiva representativa do objeto; e ulteriormente, a potência intelectiva, quando raciocina sobre as
conclusões, implica, como princípio ativo, uma proposição evidente. Por onde, por meio de tais atos,
certos hábitos podem ser causados nos agentes, não certamente quanto ao primeiro princípio ativo,
mas quanto ao princípio do ato que põe o móvel em movimento. Pois, tudo o que recebe de fora a
paixão e o movimento, recebe a sua disposição do ato do agente. E por isso os atos multiplicados geram
uma certa qualidade na potência passiva e movida, denominada hábito; assim, os hábitos das virtudes
morais são causados nas potências apetitivas, enquanto movidas pela razão; e os hábitos das ciências
são causados no intelecto enquanto movido pelas proposições primeiras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O agente como tal nada recebe; mas quando age
movido por outro, recebe algo do motor, e assim é causado o hábito.

RESPOSTA À SEGUNDA. — Nada, em si mesmo, pode ser simultaneamente motor e movido; mas nada
impede possa um ser mover-se por si mesmo, em pontos de vista diversos, como já se provou.

RESPOSTA À TERCEIRA. — O ato que precede o hábito, enquanto proveniente de um princípio ativo, se
origina de um princípio mais nobre que o ato gerado. Assim a razão, em si mesma, é princípio mais
nobre que o hábito da virtude moral da potência apetitiva, gerado por atos costumeiros; e o intelecto
dos princípios é princípio mais nobre que a ciência das conclusões.

## Art. 3 — Se o hábito pode ser gerado por um só ato.
(I Sent., dist. XVII, q. 2, a . 3, ad 4; De Virtut., q. 1, a . 9 ad 11).
O terceiro discute-se assim. — Parece que o hábito pode ser gerado por um só ato.

1. — Pois, a demonstração é um ato da razão. Ora, por uma só demonstração é causada a ciência, que é
o hábito de uma conclusão. Logo, o hábito pode ser causado por um só ato.

2. Demais — Como o ato pode aumentar por multiplicação, assim também o pode pela intensidade. Ora,
o hábito é gerado por atos multiplicados. Logo também, se um ato for muito intenso, poderá ser causa
geratriz do hábito.

3. Demais — A saúde e a doença são hábitos. Ora, por um ato o homem pode sarar ou ficar enfermo.
Logo, um ato pode causar o hábito.
Mas, em contrário, diz o Filósofo, que, assim como uma andorinha não faz primavera, nem um só dia;
assim também não é um só dia, ou pouco tempo, que poderá fazer um homem bem-aventurado ou
feliz. Ora, a beatitude é uma operação conforme ao hábito da virtude perfeita, como já se disse. Logo, o
hábito da virtude e, pela mesma razão, outro qualquer hábito, não pode ser causado por um só ato.

SOLUÇÃO. — Como já dissemos, o hábito é gerado pelo ato, enquanto a potência passiva é movida por
um princípio ativo. Para uma qualidade qualquer porém ser causada no ser passivo, é necessário que o
princípio ativo o domine totalmente. Por isso vemos que o fogo, não podendo dominar totalmente o seu
combustível, não pode inflamá-lo imediatamente, mas vai, aos poucos, eliminando as disposições
contrárias, de modo a dominá-lo totalmente, imprimindo-lhe a sua semelhança.
Ora, como é manifesto, o princípio ativo, que é a razão, não pode, por um só ato dominar totalmente a
potência apetitiva, porque esta se conduz, de modos diversos e tem muitos objetos; pode porém por
um único ato julgar se um objeto é desejável segundo determinadas razões e circunstâncias. E por isso a
potência apetitiva não é vencida totalmente, de modo a, na maioria dos casos, a modo da natureza, ser
levada para o mesmo objeto; e isso pertence ao hábito da virtude. Por onde, este hábito não pode ser
causado por um só ato, mas por muitos.
Em relação porém às potências apreensivas, devemos levar em conta uma dupla passividade: a do
intelecto possível, e a do que Aristóteles denomina passivo, que é uma razão particular, i. é, a potência
cogitativa juntamente com a memorativa e a imaginativa. — Mas em relação ao ser passivo primeiro,
pode existir um ativo que, por um único ato o domine totalmente, como lhe sendo subordinado; assim
uma proposição evidente leva o intelecto a assentir firmemente na conclusão. O que não faz a
proposição provável; e por isso é necessário que por muitos atos da razão seja causado o hábito
opinativo, mesmo por parte do intelecto passível. Ao passo que o hábito da ciência pode ser causado
por um só ato da razão, quanto ao intelecto passível. — Mas, quanto às potências inferiores
apreensivas, é necessário sejam os mesmos atos reiterados muitas vezes, para produzirem uma forte
impressão na memória. E por isso o Filósofo diz, que a meditação fortalece a memória.
Os hábitos corpóreos porém é possível sejam causados por um só ato, se o princípio ativo tiver forte
virtude; assim às vezes um remédio forte produz a saúde prontamente.
E daqui consta com evidência a RESPOSTA ÀS OBJEÇÕES.

## Art. 4 — Se o homem tem hábitos infundidos por Deus.
(Infra, q. 63, a. 3).
O quarto discute-se assim. — Parece que nenhum hábito do homem é infundido por Deus.

1. — Pois, Deus procede igualmente para com todos. Se portanto infundir certos hábitos em alguns
homens, há-de infundi-los em todos; o que é evidentemente falso.

2. Demais — Deus opera em todos os seres pelo modo que lhes convém à natureza; pois, pertence à
Divina Providência salvar a natureza, como diz Dionísio. Ora, o hábito do homem é naturalmente
causado pelos atos, como já dissemos. Logo, Deus não causa, nos homens, nenhuns hábitos sem atos.

3. Demais — Pelo hábito infundido por Deus, o homem poderia produzir muitos atos. Ora, tais atos
causariam um hábito semelhante, como já se disse. Donde resultaria existirem dois hábitos da mesma
espécie no mesmo indivíduo; um adquirido e outro, infuso. Ora, isto é impossível, pois duas formas da
mesma espécie não podem coexistir no mesmo sujeito. Logo, nenhum hábito é infundido no homem
por Deus.
Mas, em contrário, diz a Escritura (Ecle 15, 5): O Senhor o encherá do espírito de sabedoria e de
inteligência. Ora, a sabedoria e a inteligência são hábitos. Logo, certos hábitos são infundidos no homem
por Deus.

SOLUÇÃO. — Por dupla razão certos hábitos são infundidos no homem por Deus. — A primeira é que há
certos pelos quais ele se dispõe bem para um fim excedente à capacidade da sua natureza, que é a sua
última e perfeita beatitude, com já dissemos. E como os hábitos devem ser proporcionados aquilo a que
dispõem o homem, os que o dispõem para um tal fim hão-de também necessariamente exceder-lhe a
capacidade da natureza. Por onde, poderão nele existir só por infusão divina; e tal é o caso de todas as
virtudes gratuitas. — A outra razão é que Deus pode produzir os efeitos das causas segundas, sem elas,
como já dissemos na Primeira Parte. Ora, assim como às vezes para ostentar o seu poder, produz a
saúde que podia ser causada pela natureza, sem a cooperação de nenhuma causa natural; assim
também, às vezes, para o mesmo fim, infunde no homem hábitos que podem ser causados por uma
virtude natural. Assim deu aos Apóstolos a ciência das Escrituras e de todas as línguas, que os homens
podem adquirir pelo estudo ou pelo costume, embora não de modo tão perfeito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus, pela sua natureza, procede igualmente para com
todos; mas, quanto à ordem da sua sabedoria, dá por alguma certa razão, a uns o que não dá a outros.

RESPOSTA À SEGUNDA. — O que Deus opera em todos os seres, por meio deles, não impede faça certas
coisas que a natureza não pode fazer; mas daqui se segue que não obra nada contra o que convém à
natureza.

RESPOSTA À TERCEIRA. — Os atos produzidos por um hábito infuso não causam nenhum outro hábito;
mas confirmam o preexistente. — Assim os remédios, ministrados ao homem são, não causam, por
natureza, a saúde, mas, fortificam a que ele já tinha.