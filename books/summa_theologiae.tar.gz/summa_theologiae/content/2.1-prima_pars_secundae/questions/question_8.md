# Questão 8: Dos atos em que há vontade.
Em seguida devemos tratar dos atos mesmos da vontade, em especial. E primeiro, dos atos precedentes
da vontade, em si, como elícitos dela. Segundo, dos atos imperados pela vontade.
Mas, como a vontade se move para o fim e para os meios, há-se de tratar, primeiro, dos atos pelos quais
a vontade se move para o fim; e em seguida, dos atos pelos quais se move para os meios.
Ora, os atos da vontade para o fim são três: querer, fruir e intender. Por onde, trataremos, primeiro, da
vontade. Segundo, da fruição. Terceiro, da intenção.
Sobre o primeiro ponto, três questões se consideram. A primeira, em que atos há vontade. A segunda é
pelo que ela é movida. A terceira, como é movida.
Sobre a primeira Questão três artigos se discutem:

## Art. 1 — Se a vontade quer só o bem.
(I, q. 19, a . 9; IV Sent., dist. XLIX, q. 1, a . 3, q ª 1; De Verit., q. 22, a . 6).
O primeiro discute-se assim. ― Parece que a vontade não quer só o bem.

1. ― Pois, uma mesma é a potência dos contrários; assim, a vista vê o branco e o negro. Ora, o bom e o
mal são contrários. Logo, a vontade quer não só o bem, mas ainda o mal.

2. Demais. ― As potências racionais buscam os contrários, segundo o Filósofo. Ora, a vontade é
potência racional, pois, reside na razão, como diz Aristóteles. Logo, a vontade busca os contrários e,
portanto, quer, não só o bem, mas ainda o mal.

3. Demais. ― O bem e o ser se convertem entre si. Ora, a vontade quer, não só o ser, mas também o
não-ser; assim, queremos, umas vezes, não andar e não falar; e também queremos, outras, certos
futuros, que não são realidades atuais. Logo, a vontade não quer só o bem.
Mas, em contrário, diz Dionísio: o mal é contrário à vontade, e: todos os seres apetecem o bem.

SOLUÇÃO. ― A vontade é um apetite racional. Ora, todo apetite só pode desejar o bem; pois, o apetite
não é mais do que uma inclinação do apetente para alguma coisa; e nada se inclina senão para o que lhe
é semelhante e conveniente. Por onde, tudo o que existe sendo, enquanto ente e substância, um certo
bem, necessário é que toda inclinação seja para um bem. E daí procede o dito do Filósofo: bem é o que
todos os seres desejam.
Deve-se porém considerar que, como toda inclinação resulta de alguma forma, o apetite natural resulta
de forma existente em a natureza; ao passo que o apetite sensitivo ou também o intelectivo ou racional,
chamado vontade, resulta de forma apreendida. Assim como, pois, o para que tende o apetite natural é
o bem existente na realidade, assim, o para que tende o apetite animal, ou voluntário, é o bem
apreendido. Portanto, para a vontade tender para alguma coisa, não é necessário que exista o bem, na
realidade, mas que algo seja apreendido sob a idéia de bem. E por isso diz o Filósofo: o fim é o bem ou o
que parece tal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a potência dos contrários seja a mesma,
contudo ela não se comporta com ambos, do mesmo modo. Assim, a vontade tende para o bem e para
o mal; mas para aquele, apetecendo-o; para este, fugindo. E por isso o apetite atual do bem se chama
vontade, designando esta um ato de vontade; e é neste sentido que estamos agora tratando da
vontade. Ao passo que à fuga do mal se chama antes negação da vontade (noluntas). Por onde, assim
como a vontade quer o bem, assim a sua negação foge do mal.

RESPOSTA À SEGUNDA. ― A potência racional não busca quaisquer contrários, mas só os que se
contêm no seu objeto conveniente; pois nenhuma potência busca senão o objeto que lhe convém. Ora,
o objeto da vontade é o bem, e por isso ela busca só os contrários compreendidos no bem; assim, o ser
movido e o repousar, o falar e o calar e outros semelhantes, para os quais a vontade é levada pela idéia
de bem.

RESPOSTA À TERCEIRA. ― O que não é ser real, é considerado ser de razão; por isso, as negações e as
privações consideram-se seres de razão. E desse mesmo modo os futuros, enquanto apreendidos, são
entes e, como tais, apreendidos sob a idéia de bem, a vontade tende para eles. Donde o dito do
Filósofo: não ter mal se compreende na idéia de bem.

## Art. 2 — Se a vontade quer também os meios ou só o fim.
(I Sent., dist. XLV, a. 2, ad 1; II dist. XXIV, q. 1a a. a . 3, ad 3; De Verit., q. 22, a . 13, ad 9).
O segundo discute-se assim. ― Parece que a vontade não quer os meios, mas só fim.

1. — Pois, diz o Filósofo: a vontade quer o fim; a eleição, porém, os meios.

2. Demais. ― A coisas genericamente diversas ordenam-se potências diversas da alma, como diz
Aristóteles. Ora, o fim e os meios pertencem a gêneros diversos do bem; pois, o fim que é o bem
honesto ou deleitável pertence ao gênero da qualidade, da ação ou da paixão; ao passo que o bem
chamado útil, que existe para o fim, é relativo a alguma coisa, como diz Aristóteles. Logo, se vontade só
quer o fim, não pode querer os meios.

3. Demais. ― Os hábitos, sendo perfeições das potências, a elas se proporcionam. Ora, dos hábitos
chamados artes operativas, uns visam o fim, outros, o meio. Assim, à arte de pilotar cabe o uso do
navio, que é o fim deste; à fazer navios porém, a construção da nau, que é meio, para um fim. Logo,
querendo o fim, a vontade não quer os meios.
Mas, em contrário, nas coisas naturais, pela mesma potência são percorridos os meios e é alcançado o
termo. Ora, o que diz respeito ao fim, são meios, pelos quais se chega aquele, como termo. Logo, se a
vontade quer o fim há de também querer os meios.

SOLUÇÃO. ― Vontade significa, ora, a potência mesma pela qual queremos; ora, o ato mesmo de
vontade.
Se, pois, tratamos da vontade enquanto potência, ela se estende tanto ao fim como aos meios. Ora,
cada potência se estende a tudo o em que pode existir, de qualquer modo, por natureza o seu objeto;
assim, a vista se estende a tudo o que participa de algum modo da cor. Ora, a idéia de bem, objeto da
potência da vontade, encontra-se não só no fim mas também nos meios.
Se porém tratamos da vontade, enquanto ato, então propriamente falando ela só quer o fim. Pois todo
ato, que tira da potência a sua denominação, designa um ato simples dessa potência, assim, inteligir
designa um ato simples do intelecto. Ora, o ato simples de uma potência recai sobre o objeto em si da
potência. Ora, o que é, em si mesmo, bem e querido é o fim. Logo, a vontade propriamente quer o fim
em si; ao passo que os meios não são bens e nem são queridos, em si mesmos, mas em ordem ao fim. E
por isso a vontade não os quer senão na medida em que quer o fim; portanto este é o que neles ela
quer. Assim, inteligir, propriamente, se refere ao que é conhecido, em si, i. é, os princípios; enquanto
que do conhecido por meio dos princípios não se diz que há inteligência, senão na medida em que nisso
os princípios mesmos são considerados. Assim, pois, o fim está para os apetíveis, como o princípio, para
os inteligíveis, segundo Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo se refere à vontade, enquanto ela designa
propriamente um ato simples seu; não porém como designando uma potência.

RESPOSTA À SEGUNDA. ― Coisas genericamente diversas e igualmente independentes, entre si,
ordenam-se a potências diversas; assim, ao som e à cor, gêneros diversos de sensíveis, ordena-se à
audição e a visão. Ora, o honesto e o útil não são igualmente independentes, entre si; mas estão um
para o outro, como o que existe para si e o que existe para outro. E por isso ambos sempre se referem à
mesma potência, assim como, pela potência visiva sente-se à cor e a luz, pela qual aquela é vista.

RESPOSTA À TERCEIRA. ― Nem tudo o que diversifica o hábito diversifica a potência. Pois os hábitos são
certas determinações das potências para alguns atos especiais. Contudo, qualquer arte operativa
considera tanto o fim como o meio. P. ex., a arte de pilotar considera, de um lado, como fim, o para o
que opera; e de outro, como meio, aquilo que manda. Pelo contrário, a arte de fazer navio considera
como meio aquilo que opera e, como fim, aquilo ao que ordena o operado. E assim por diante: em cada
arte operativa há um fim que lhe é próprio e algo que é o meio e que lhe pertence, propriamente.

## Art. 3 — Se pelo mesmo ato a vontade quer o fim e o meio.
(Infra. q. 12, a . 4; De Verit., q. 22, a . 14).
O terceiro discute-se assim. ― Parece que pelo mesmo ato a vontade quer o fim e o meio.

1. ― Pois, segundo o Filósofo, quando uma coisa existe para outra, só uma delas existe. Ora, a vontade
não quer o meio senão para o fim. Logo, move-se para um e outro pelo mesmo ato.

2. Demais. ― O fim é a razão de se querer o meio, assim como a luz é a da visão das cores. Ora, pelo
mesmo ato vê-se a luz e a cor. Logo, pelo mesmo movimento a vontade quer o fim e o meio.

3. Demais. ― É o mesmo, numericamente, o movimento natural que, pelos termos médios, tende ao
que é último. Ora, os meios estão para o fim como o médio para o último. Logo, pelo mesmo ato a
vontade quer o fim e os meios.
Mas, em contrário. ― Os atos se diversificam pelos objetos. Ora, o fim e o meio, chamado útil, são
espécies diversas de bens. Logo, não é pelo mesmo ato que a vontade os quer, a um e outro.

SOLUÇÃO. ― Sendo o fim querido por si mesmo, e sendo o meio como tal querido para o fim, é claro
que a vontade pode querer aquele sem querer este. Mas pode querer os meios sem querer o fim. Assim
pois, a vontade quer o fim em si mesmo, de duplo modo: absolutamente e em si e em razão de querer
os meios. Ora, é claro, pelo mesmo movimento uno é que a vontade, de um lado quer o fim, sendo este
a razão de querer os meios, e, de outro, quer os meios. Diverso porém é o ato pelo qual quer o fim em
si, absolutamente, o que às vezes tem precedência temporal; assim, quando alguém quer
primeiramente a saúde e, depois, deliberando como possa curar-se, quer que se chame o médico para
curar. E o mesmo se dá com o intelecto. Pois, primeiro, inteligimos os princípios em si; depois, os
inteligimos nas conclusões, enquanto damos assentimento a estas por meio daqueles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção feita colhe quando a vontade quer o fim,
como razão de querer os meios.

RESPOSTA À SEGUNDA. ― Embora, sempre que vemos a cor vemos também a luz, pelo mesmo ato,
contudo, podemos ver esta sem vermos aquela. ― E semelhantemente, quem quer os meios quer
sempre e pelo mesmo ato o fim; não porém, inversamente.

RESPOSTA À TERCEIRA. ― Na execução da obra, os meios exercem a função de termos médios e o fim,
de termo último. Donde, assim como o movimento natural para às vezes no meio e não alcança o
termo, assim também às vezes realizamos o meio sem contudo conseguirmos o fim. Mas no querer se
dá o inverso; pois, pelo fim, a vontade é levada a querer os meios, assim como o intelecto chega às
conclusões pelos princípios, considerados meios. Donde, assim como o intelecto às vezes intelige o meio
sem por ele chegar à conclusão, assim também a vontade quer às vezes, o fim sem entretanto chegar a
querer o meio.
E quanto ao que é objetado em contrário, a SOLUÇÃO. é clara pelo que já ficou dito antes. Pois, o útil e
honesto não constituem espécies independentes um do outro, por igual; mas estão entre si como o que
existe para si mesmo e o que existe para outra coisa.
Donde, o ato da vontade pode querer um sem querer o outro, mas não inversamente.