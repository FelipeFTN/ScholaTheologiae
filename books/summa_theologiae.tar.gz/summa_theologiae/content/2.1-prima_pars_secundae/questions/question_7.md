# Questão 7: Das circunstâncias dos atos humanos.
Em seguida devemos tratar das circunstâncias dos atos humanos.
E sobre esta Questão quatro artigos se discutem:

## Art. 1 — Se a circunstância é acidente do ato humano.
(Infra. q. 18, a . 3; IV Sent., dist. XVI, q. a . 1, q ª 1).
O primeiro discute-se assim. ― Parece que a circunstância não é um acidente do ato humano.

1. ― Pois, como diz Túlio, é pela circunstância que a oração dá autoridade e firmeza à argumentação.
Ora, a oração dá firmeza à argumentação, sobretudo pelo que é substancial, como a definição, o gênero,
a espécie e coisas semelhantes, com as quais, ensina ainda Túlio, o orador deve argumentar. Logo, a
circunstância não é acidente do ato humano.

2. Demais. ― É próprio do acidente existir no ser. Ora, tal não se dá como o que circunsta, que é antes
exterior. Logo, as circunstâncias não são acidentes dos atos humanos.

3. Demais. ― Não há acidente de acidente. Ora, os atos humanos já são acidentes. Logo, as
circunstâncias não são acidentes dos atos.
Mas, em contrário. ― As condições particulares de uma coisa singular chamam-se acidentes, que a
individuam. Ora, o Filósofo diz que as circunstâncias são particulares, i. é, condições particulares dos
atos singulares. Logo, elas são acidentes individuais dos atos humanos.

SOLUÇÃO. ― Sendo os nomes, segundo o Filósofo, sinais das coisas inteligidas, necessariamente, o
processo de denominar há-de ser correlativo ao do conhecimento intelectivo. Ora, o nosso
conhecimento intelectual procede do mais para o menos conhecido; e por isso aplicamos os nomes das
coisas mais conhecidas a significarem as menos conhecidas. Donde vem que, como diz Aristóteles, das
coisas situadas num lugar derivou o nome de distância para todos os contrários; e semelhantemente,
usamos dos nomes relativos ao movimento local para significar outros movimentos, porque os corpos,
circunscritos pelo lugar são os que mais conhecemos. Donde resulta ter-se derivado o nome de
circunstância, das coisas situadas num lugar, para os atos humanos.
Ora, diz-se que circunstância, localmente, o que embora extrínseco a uma coisa, com ela tem contato ou
dela se aproxima, localmente. Por onde, todas as condições exteriores à substância do ato e que,
contudo, respeitam de algum modo o ato humano, chamam-se circunstâncias. Ora, o que é exterior à
substância de uma coisa, mas que à coisa mesma pertence, chama-se acidente. Donde o se
denominarem as circunstâncias acidentes dos atos humanos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A oração dá, certo, firmeza à argumentação, primeiro,
pela substância do ato; e secundariamente, pelas circunstâncias dele. Assim, primeiro, torna-se acusável
quem perpetrou um homicídio; secundariamente, porque o perpetrou com dolo, com fito de lucro, em
tempo ou lugar sagrado, ou de modos semelhantes. E por isso diz Túlio, significativamente, que pela
circunstância e como secundariamente, a oração acrescenta a firmeza à argumentação.

RESPOSTA À SEGUNDA. ― De duplo modo se atribui o acidente a um ser. Porque neste existe como
quando se diz que branco é acidente de Sócrates. Ou porque existem ambos, simultaneamente, no
mesmo sujeito; assim, considera-se o branco como acidental ao músico, por convirem ambos e de certa
maneira se tocarem, num mesmo sujeito. E deste modo é que as circunstancias se chamam acidentes
dos atos.

RESPOSTA À TERCEIRA. ― Como já se disse, considera-se um acidente como pertencente a outro, pela
conveniência de ambos, num mesmo sujeito, o que de dois modos pode dar-se. Ou por se fundarem
eles nesse sujeito, sem nenhuma ordem ― assim branco e músico, em Socrátes ― ou, numa certa
ordem, como quando o sujeito recebe um acidente mediante outro — assim, o corpo recebe a cor,
mediante a superfície. Ora, de ambos esses modos, as circunstâncias se referem aos atos. Pois, umas,
ordenadas para o ato, dizem respeito ao agente, sem mediação de nenhum outro ato, p. ex., o lugar e a
condição da pessoa. Outras porem mediante o ato mesmo; assim, o modo de agir.

## Art. 2 — Se as circunstâncias dos atos humanos devem ser consideradas pelo teólogo.
O segundo discute-se assim. ― Parece que as circunstâncias dos atos humanos não devem ser
consideradas pelo teólogo.

1. ― Pois, os atos humanos não são considerados pelo teólogo senão enquanto qualificados, i. é,
enquanto bons ou maus. Ora, as circunstâncias não podem qualificá-los, porque nenhuma coisa é
qualificada, formalmente falando, pelo que lhe é exterior, senão pelo que nela existe. Logo, as
circunstâncias dos atos não devem ser consideradas pelo teólogo.

2. Demais. ― As circunstâncias são acidentes dos atos. Ora, um mesmo ato tem infinitos acidentes, e
por isso, como diz Aristóteles, nenhuma arte ou ciência, senão só a sofística, se ocupa com o ente
acidental. Logo, o teólogo não tem que considerar as circunstâncias dos atos humanos.

3. Demais. ― Considerar as circunstâncias pertence ao retórico. Ora, a retórica não é parte da teologia.
Logo, a consideração das circunstâncias não pertence ao teólogo.
Mas, em contrário. — A ignorância das circunstâncias causa o involuntário, como diz Damasceno e
Gregório Nisseno (Nemésio). Ora, o involuntário escusa da culpa, cuja consideração incumbe ao teólogo.
Logo, também a este incumbe a consideração das circunstâncias.

SOLUÇÃO. ― As circunstâncias pertencem à consideração do teólogo por tríplice razão. — A primeira é
que o teólogo considera os atos humanos enquanto por eles o homem se ordena à beatitude. Ora, tudo
o que se ordena ao fim deve a este ser proporcionado. Ora, o ato é proporcionado ao fim por uma certa
comensuração mediante as devidas circunstâncias. Por onde, a consideração das circunstâncias
pertence ao teólogo. ― A segunda é que o teólogo considera os atos humanos enquanto há neles bem e
mal, melhor e pior; e isto se diversifica pelas circunstâncias, como a seguir se verá. ― A terceira é que o
teólogo considera os atos humanos, quanto à qualidade que têm de meritórios ou demeritório e para o
que é necessário, sejam voluntários. Ora, o ato humano é julgado voluntário ou involuntário, conforme
o conhecimento ou ignorância das circunstâncias, como já se disse. E, portanto, a consideração das
circunstâncias pertence ao teólogo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O bem ordenado a um fim e que se chama útil importa
numa relação; por onde, diz o Filósofo que, no que é relativo, o bem é o útil. Ora, chama-se relativo não
só o existente em outro ser, mas também o que é extrínseco, como bem se vê no que é direito e
esquerdo, igual ou desigual e atribuições semelhantes. Por onde, a bondade, existindo nos atos
enquanto úteis ao fim, nada impede sejam considerados bons ou maus enquanto proporcionados a algo
extrínseco.

RESPOSTA À SEGUNDA. ― Os acidentes que se comportam absolutamente como tais fogem a qualquer
arte, pela sua incerteza e infinidade. Mas tais acidentes não desempenham a função de circunstâncias
porque, como já disse, estas, embora exteriores ao ato, dizem-lhe contudo respeito de certo modo,
como ordenadas que são para ele. Porém, os acidentes, em si, caem sob o domínio da arte.

RESPOSTA À TERCEIRA. ― A consideração das circunstâncias pertence tanto ao moralista e ao político
como ao retórico. ― Ao moralista, enquanto que por elas se atinge ou não o meio termo da virtude, nos
atos humanos e nas paixões. ― Ao político e ao retórico, porém, enquanto que pelas circunstâncias os
atos se tornam escusáveis ou acusáveis. De modo diverso, contudo; pois, ao passo que o retórico
persuade, o político discerne. ― ao teólogo, enfim, a quem servem todas as outras artes, pertence
considerá-las, de todos os modos referidos. Pois, com o moralista considera os atos virtuosos e viciosos;
e com o retórico e o político os considera enquanto merecem pena ou prêmio.

## Art. 3 — Se as circunstâncias estão convenientemente enumeradas no terceiro livro das Éticas de Aristóteles.
(IV Sent., dist. XVI, q. 3, a . 1, q ª 2, 3, De Malo, q. 2, a . 6; III Ethic., let. III).
O terceiro discute-se assim. — Parece que as circunstâncias estão inconvenientemente enumeradas
no terceiro livro das Éticas de Aristóteles.

1. — Pois, chama-se circunstância de um ato, o que a ele se refere, exteriormente. Ora, tais são o tempo
e o lugar. Logo, há só duas as circunstâncias, a saber, quando e onde.

2. Demais. — Das circunstâncias se deduz o que é bem ou mal feito. Ora, isto diz respeito ao modo do
ato. Logo, todas as circunstâncias se incluem numa, que é o modo de agir.

3. Demais. ― As circunstâncias não pertencem à substância do ato mas sim às causas mesmas do ato.
Logo, nenhuma circunstância deve ser deduzida da causa do ato. E portanto, nem quem age, nem a
causa por que se age, nem o a respeito de que se age são circunstâncias: pois, quem age se considera
como causa eficiente:a causa por que se age, como final; e o a respeito do que se age, como material.
Mas, em contrário é a autoridade do Filósofo no terceiro livro das Éticas, em Questão.

SOLUÇÃO. — Túlio, na sua Retórica, ensina sete circunstâncias, contidas no seguinte versículo:
Quem, o que, onde, com que auxílios, porque, de que modo, quando.
Pois devemos consideras quem fez os atos, com que auxílios ou instrumentos os fez, o que fez, onde fez,
porque fez, de que modo fez, e quando fez. Aristóteles, porém, acrescenta a circunstância a respeito de
que, que Túlio compreende em o que.
E a razão desta enumeração pode se fundamentar da maneira seguinte. Chama-se circunstância o como
que existente de modo exterior à substância do ato, mas de certo modo o admitindo. O que de tríplice
modo pode dar-se: atingindo o ato, em si; atingindo-lhe a causa; atingindo-lhe o efeito. O ato, em si é
atingido a modo de medida, como o tempo e o lugar; ou a modo de qualidade, como o modo de agir.
Atinge o efeito, como quando se considera o que alguém fez. A causa, se é final, a ela se refere o por
causa do que se age; se é material ou objeto a esta se refere o a respeito do que se age; se é a causa do
agente principal, a ela se refere quem fez; se é a causa do agente instrumental, a ela se refere o com
que auxílios fez.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O tempo e o lugar circunstam ao ato, a modo de
medida; outras circunstâncias há porém, que atingem de qualquer outro modo, existindo exteriormente
à substância dele.

RESPOSTA À SEGUNDA. ― O modo de ser bom ou mal não é considerado circunstância, mas,
conseqüente de todas as circunstâncias. É considerado porém como circunstância especial o modo
pertencente à qualidade do ato; p. ex., se alguém anda veloz ou retardamente; se alguém fere forte ou
brandamente e assim por diante.

RESPOSTA À TERCEIRA. ― A condição da causa da qual depende a substância do ato não é considerada
circunstância, mas condição adjunta. Assim como não se considera circunstância o ser alheio o objeto
furtado. ― o que pertence à substância do furto ― mas, o ser grande ou pequeno. E o mesmo se dá
com as outras circunstâncias atinentes às outras causas. Pois, o fim, que especifica o ato, não e
circunstância, mas sim, o fim adjunto. Assim, não é circunstância se o forte age corajosamente por causa
do bem que é a fortaleza; mas, se age corajosamente para a libertação do Estado, do povo cristão ou de
modo semelhante. E o mesmo se dá como o que respeita ao que se faz; assim, se alguém, derramando
água, lava outrem, isso não é circunstância da ablução; mas, sim, se, lavando resfria ou aquece, sana ou
faz mal.

## Art. 4 — Se são circunstâncias principais a causa por que se age e o em que se realiza a operação.
(IV Sent., dist. XVI. Q. 3, a . 2, q. 2; III Ethic., lect III).
O quarto discute-se assim. ― Parece que não são circunstâncias principais a causa porque se age e
o em que se realiza a operação, como diz o Filósofo.

1. ― Pois, o em que se realiza a operação parece ser o lugar e o tempo, que não são circunstâncias
principais por serem o que há de mais extrínseco ao ato. Logo, o em que se realiza a operação não é a
principalíssima das circunstâncias.

2. Demais. ― O fim é extrínseco ao ser. Logo, não é a principalíssima das circunstâncias.

3. Demais. ― O que é principalíssimo, num ser, é-lhe a causa e a forma. Ora, a causa do ato, sem si, é a
pessoa agente; e a forma do ato é o seu modo. Logo, estas duas circunstâncias são as principalíssimas.
Mas, em contrário, diz Gregório Nisseno (Nemésio), que as circunstâncias principalíssimas são o fim e o
objeto da ação.

SOLUÇÃO. ― Propriamente humanos, como já se disse, são os atos voluntários. Ora, o motivo e o
objeto da vontade é o fim. E portanto, a principalíssima de todas as circunstâncias é a que constitui o
fim do ato, que é a razão por que se age; e secundária é a que atinge a substância do ato, i. e, aquilo que
se fez. Ao passo que as outras circunstâncias são mais ou menos principais enquanto mais ou menos se
aproximam das primeiras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pelo em que se realiza a operação o Filósofo não
entende o tempo e o lugar, mas aquilo que se adjunge ao ato mesmo. Por onde, Gregório Nisseno,
como que expondo o dito do Filósofo, em lugar da expressão deste ― em que se realiza a operação ―
diz ― aquilo que é feito.

RESPOSTA À SEGUNDA. ― O fim, embora não seja da substância do ato, é contudo a causa
principalíssima dele, enquanto leva o agente a agir. E é por isso que o ato moral se especifica,
sobretudo, pelo fim.

RESPOSTA À TERCEIRA. ― A pessoa agente é causa do ato, enquanto movida pelo fim, e então ordena-
se ao ato principalmente. Ao passo que as outras condições da pessoa não se ordenam assim,
principalmente, ao ato. E o modo também não é a forma substancial do ato, que lhe é relativa ao objeto
e ao termo ou fim; mas é uma como qualidade acidental dele.