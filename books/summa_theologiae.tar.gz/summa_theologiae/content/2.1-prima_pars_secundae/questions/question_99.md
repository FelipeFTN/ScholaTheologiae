# Questão 99: Dos preceitos da lei antiga.
Em seguida devemos tratar dos preceitos da lei antiga. E primeiro, da distinção deles. Segundo, de cada
um dos gêneros distintos.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a lei antiga continha só um preceito.
O primeiro discute-se assim. — Parece que a lei antiga não continha senão um preceito.

1. — Pois, a lei não é senão um preceito, como já se disse (q. 90, a. 2, a. 3). Ora, a lei antiga é uma só.
Logo, não contém senão um preceito.

2. Demais. — O Apóstolo diz (Rm 13, 9): se há algum outro mandamento, todos eles vêm a resumir-se
nesta palavra: Amarás a teu próximo como a ti mesmo. Ora, este é um só mandamento. Logo, a lei
contém só um mandamento.

3. Demais. — A Escritura diz (Mt 7, 12): tudo o que vós quereis que vos façam os homens, fazei-o
também vós a eles; porque esta é a lei e os projetas. Ora, toda a lei antiga está contida na lei e nos
profetas. Logo, ela na tem senão um preceito.
Mas, em contrário, o Apóstolo diz (Ef 2, 15): Abolindo com os seus decretos a lei dos preceitos;
referindo-se à lei antiga, como é claro pela Glosa a esse lugar. Logo, a lei antiga continha em si muitos
mandamentos.

SOLUÇÃO. — O preceito da lei, sendo obrigatório, tem por objeto aquilo que deve ser feito. Ora, por
força de um fim é que alguma coisa deve ser feita. Por onde é manifesto, que da essência de um
preceito é ordenar-se para um fim, isto é, o preceituado deve ser necessário ou conveniente a um fim.
Ora, a este podem muitas coisas ser necessárias ou convenientes. E assim sendo, podemos, para coisas
diversas, dar preceito diversos, enquanto ordenados para um mesmo fim. Por onde, devemos concluir
que todos os preceitos da lei antiga constituem um só preceito por ser ordenarem a um mesmo fim. São
porém muitos conforme a diversidade das coisas que se ordenam para esse fim.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que a lei antiga é una por ordenar-se a um fim
único; e contudo, contêm diversos preceitos, relativos à distinção das coisas ordenadas para esse fim.
Assim como a arte da construção é uma pela unidade de fim, por visar à edificação da casa; e contudo,
contém preceitos diversos, conforme a diversidade dos atos para esse fim ordenados.

RESPOSTA À SEGUNDA. — Como diz o Apóstolo (1 Tm 1, 5), o fim do preceito é a caridade. Pois, toda a
lei visa constituir a amizade dos homens entre si, ou deles para com Deus. Por isso, toda lei está
completa neste só mandamento — Amarás a teu próximo como a ti mesmo — que é como o fim de
todos os mandamentos. Pois, no amor do próximo também se inclui o de Deus, quando ele é amado por
amor de Deus. Por isso, o Apóstolo pôs este único preceito, pelos dois, referentes ao amor de Deus e do
próximo, dos quais diz o Senhor (Mt 22, 40): destes dois mandamentos depende toda a lei e os profetas.

RESPOSTA À TERCEIRA. — Como diz Aristóteles, a amizade para com outrem vem da nossa para
conosco mesmo, porque procedemos para com outrem como procedem para conosco. Por onde, o dito
— tudo o que vós quereis que vos façam os homens, fazei-o também vós a eles — deve ser entendido
como regra de amor do próximo, implicitamente contida naquele outro lugar: amarás a teu próximo
como a ti mesmo. E assim, é uma explicação deste mandamento.

## Art. 2 — Se a lei antiga continha preceitos morais.
(Infra, a. 4; In Matth., cap. XXIII).
O segundo discute-se assim. — Parece que a lei antiga não continha preceitos morais.

1. — Pois, a lei antiga distingue-se da lei natural, como já se estabeleceu (q. 91, a. 4, a. 5; q. 98, a. 5).
Ora, os preceitos morais pertencem à lei da natureza. Logo, não pertencem à lei antiga.

2. Demais. — A lei divina devia vir em socorro do homem quando lhe falhasse a razão; como se dá
claramente com as coisas da fé, supra-racionais. Ora, para se observarem o preceito moral basta-nos a
razão. Logo, eles não pertencem à lei antiga, que é uma lei divina.

3. Demais. — A lei antiga é considerada como a letra que mata, conforme a Escritura (2 Cor 3, 6). Ora, os
preceitos morais não matam, mas vivificam, segundo a Escritura (Sl 118, 93): Nunca jamais me
esquecerei das tuas justificações, porque nelas me vivificaste. Logo, os preceitos morais não pertencem
à lei antiga.
Mas, em contrário, diz a Escritura (Sr 17, 9): acrescentou-lhes a disciplina, e deu-lhes em herança a lei da
vida. Ora, a disciplina diz respeito aos costumes, conforme diz a Glosa ao lugar, a disciplina consiste na
aquisição de bons costumes, vencendo dificuldades. Logo, a lei dada por Deus continha preceitos
morais.

SOLUÇÃO. — A lei antiga continha certos preceitos morais, como está claro na Escritura (Ex 20, 13-
15): Não matarás, não furtarás. E isto, racionalmente. Pois, assim como a intenção principal da lei
humana é procurar a amizade dos homens entre si, assim a da lei divina é constituir principalmente a
amizade entre o homem e Deus. Ora, como a semelhança é a razão do amor, conforme aquilo da
Escritura — Todo animal ama ao seu semelhante — é impossível haver amizade entre o homem e Deus,
que é ótimo, sem o homem se tornar bom. Por onde, diz a Escritura (Lv 19, 2; 11, 45): Sede Santos,
porque eu sou santo. Ora, a bondade do homem é a virtude, que torna bom quem a tem. Logo, era
necessário fossem dados os preceitos da lei antiga, mesmo relativos aos atos das virtudes. E estes são os
preceitos morais da lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A lei antiga distingue-se da lei natural, não como
absolutamente diferente dela, mas por lhe fazer certos acréscimos. Pois, assim como a graça pressupõe
a natureza, assim é necessário pressuponha a lei divina à natural.

RESPOSTA À SEGUNDA. — Era conveniente que a lei divina providenciasse, não só quanto ao que a
razão humana não pode alcançar, mas também em relação ao que ela pode errar. Ora, em relação aos
preceitos morais, no atinente aos preceitos generalíssimos da lei natural, a razão humana não podia
errar completamente; mas o costume de pecar a obscurecia quanto às ações particulares.
Relativamente porém aos outros preceitos morais, que são quase conclusões deduzidas dos princípios
gerais da lei da natureza, a razão de muitos aberrava, de modo a julgar lícitas certas coisas em si
mesmas más. Por isso, era necessário, contra uma e outra deficiência, ser o homem socorrido pela
autoridade da lei divina. Assim também, entre as verdades que devemos crer, são-nos propostas, não só
aquelas que a razão não pode alcançar, como a Trindade de Deus; mas também, as que o pode a razão
reta, como a unidade divina. E isso para obviar o erro da razão humana, em que muitos caíam.

RESPOSTA À TERCEIRA. — Como o prova Agostinho, também se diz, ocasionalmente, que a letra da lei,
em relação aos preceitos morais, mata, quando ordena o bem, sem conceder o auxílio da graça para
realizá-lo.

## Art. 3 — Se a lei antiga continha preceitos cerimoniais, além dos morais.
(Infra, a. 4, 5; q. 101, a. 1; q. 103, a. 3. q. 104, a. 1; IIª-IIae, q. 122, a. 1, ad 2; IV Sent., dist. I, q. 1, exposit.
Litt.; Quodl. II, q. 4, a. 3; In Matth., cap. XXIII).
Parece que a lei antiga não continha preceitos cerimoniais, além dos morais.

1. — Pois, toda lei é-nos imposta para ser a regra diretiva dos nossos atos humanos. Ora, os atos
humanos chamam-se morais, como já se disse (q. 1, a. 3). Logo, parece que a lei antiga dada aos homens
não devia conter senão preceitos morais.

2. Demais. — Os preceitos chamados cerimoniais pertencem ao culto divino. Ora, o culto divino é um
ato de virtude, i. é, de religião que, como Túlio diz, à divina natureza rende um culto e cerimônia. Ora,
visando os preceitos morais aos atos das virtudes, como já se disse (a. 2), parece que os preceitos
cerimoniais não se devem distinguir dos morais.

3. Demais. — Preceitos cerimoniais são os de significação figurativa. Ora, como diz Agostinho, entre os
homens as palavras são principalmente significativas. Logo, nenhuma necessidade havia de a lei conter
preceitos cerimoniais sobre certos atos figurativos.
Mas, em contrário, diz a Escritura (Dt 4, 13-14): As dez palavras que escreveu em duas tábuas de pedra,
mandou-me naquele tempo que vos ensinasse as cerimônias e as ordenações que vós devíeis guardar.
Ora, os dez preceitos da lei são morais. Logo, além dos preceitos morais, há outros que são cerimoniais.

SOLUÇÃO. — Como já se disse (a. 2), a lei divina foi principalmente instituída a fim de ordenar os
homens para Deus; ao passo que a lei humana, a fim de ordená-los principalmente uns para os outros.
Por isso, as leis humanas não cuidaram em instituir nada sobre o culto divino, senão em ordem ao bem
comum humano. E também por isso instituíram muitas disposições, relativas às coisas divinas, por lhes
parecerem convenientes a informar os costumes humanos, como o demonstra o rito dos gentios. A lei
divina, inversamente, ordenou os homens uns para os outros, enquanto isso convinha com a ordenação
para Deus, que ela principalmente visava. Ora, o homem se ordena para Deus, não só pelos atos
interiores do espírito, — crer, esperar e amar — mas também por certas obras exteriores, pelas quais
confessa a sua dependência, de Deus. E essas obras se consideram como pertencentes ao culto de Deus.
E esse culto se chama cerimônia, quase munia, i. é, dons de Ceres, chamada a deusa dos frutos, como
certos dizem; porque, dos frutos se fizeram as primeiras oblações a Deus. Ou, como refere Valério
Máximo, o nome de cerimônia foi introduzido para significar o culto divino, entre os latinos, por causa
de um lugar fortificado perto de Roma chamado Caere. Porque, quando Roma foi tomada pelos
Gauleses, para ali foram transferidos os sacrifícios dos Romanos, reverentissimamente feitos. Por onde,
os preceitos da lei, pertencentes ao culto de Deus, chama-se especialmente cerimoniais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os atos humanos entendem também com o culto divino.
Por isso, a lei antiga, dada aos homens, contém preceitos referentes a eles.

RESPOSTA À SEGUNDA. — Como já se disse (q. 91, a. 3), os preceitos da lei da natureza são comuns e
precisam de determinação. Ora, determinam-se pela lei humana e pela divina. E assim como as
determinações mesmas, feitas pela lei humana, não se consideram como de lei natural, mas de direito
positivo; assim também, essas determinações dos preceitos da lei da natureza, feitas pela lei divina,
distinguem-se dos preceitos morais, pertencentes à lei da natureza. Ora, cultuar a Deus, sendo ato de
virtude, pertence ao preceito moral; mas, a determinação desse preceito, i. é, que deva ser cultuado
com tais vítimas e tais dons, pertence aos preceitos cerimoniais. Por onde, os preceitos cerimoniais
distinguem-se dos preceitos morais.

RESPOSTA À TERCEIRA. — Como diz Dionísio, as coisas divinas não podem se manifestar aos homens
senão sob certas semelhanças sensíveis. E estas semelhanças movem mais o ânimo, quando não são
expressas só pela palavra, mas também falam aos sentidos. Por isso, a Divina Escritura manifesta as
coisas divinas, não só por semelhanças expressas verbalmente, como o mostram as locuções
metafóricas; mas também por semelhanças das coisas propostas à vista, o que pertence aos preceitos
cerimoniais.

## Art. 4 — Se, além dos preceitos morais e cerimoniais, há preceitos judiciais, na lei antiga.
(Art. Seq.: q. 103, a. 1; q. 104, a. 1; IIª-IIae, q. 87, a. 1; q. 122, a. 1, as 2; Quodl. II, q. 4, a. 3; In Math., cap.

XXIII).
O quarto discute-se assim. — Parece que, além dos preceitos morais e cerimoniais, não há nenhum
preceito judicial, na lei antiga.

1. — Pois, diz Agostinho, que, na lei antiga, há preceitos para dirigir e para significar a vida. Ora, os
preceitos para dirigir a vida são os morais; os para significá-la são os cerimoniais. Logo, além desses dois
gêneros de preceitos, não se podem descobrir, na lei antiga, preceitos judiciais.

2. Demais. — Aquilo da Escritura — Dos teus juízos não me tenho apartado — diz a Glosa: Isto é,
daqueles de que fizeste a regra de viver. Ora, a regra de viver pertence aos preceitos morais. Logo, os
preceitos judiciais não se devem distinguir dos morais.

3. Demais. — O juízo é um ato de justiça, segundo a Escritura (Sl 93, 15): Até que a justiça venha a fazer
juízo. Ora, o ato de justiça, como o das demais virtudes morais, pertence aos preceitos morais. Logo,
estes incluem em si os judiciais e, portanto, não devem se distinguir deles.
Mas, em contrário, diz a Escritura (Dt 6, 1): Estes são os preceitos e as cerimônias e as ordenações. Ora,
por preceitos se entendem, antonomasticamente, os morais. Logo, além dos preceitos morais e dos
cerimoniais, há também os judiciais.

SOLUÇÃO. — Como já se disse (a. 2, a. 3), à lei divina pertence ordenar os homens uns para os outros e
para Deus. Ora, ambas essas coisas pertencem, em comum, ao ditame da lei da natureza, à qual se
referem os preceitos morais; mas devem ser determinadas pela lei divina ou humana, por serem os
princípios evidentes comuns tanto à especulação como à ação. Por onde, assim como a determinação
do preceito comum sobre o culto divino se faz pelos preceitos cerimônias, assim a determinação do
preceito comum relativo à observação da justiça entre os homens é determinada pelos preceitos
judiciais.
E a esta luz, é necessário admitirem-se três espécies de preceitos da lei antiga: os morais, relativos ao
ditame da lei natural; os cerimoniais, que são as determinações do culto divino; e os judiciais, que são as
determinações da justiça a ser observada entre os homens. Por onde, depois de ter dito o Apóstolo, que
a lei é santa, acrescenta: o mandamento é santo, e justo, e bom. Justo, quanto aos preceitos judiciais;
santo, quanto aos cerimoniais, pois santo se chama ao que é consagrado a Deus; e bom, i. é, honesto,
quanto aos preceitos morais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tanto os preceitos morais como os judiciais visam à
direção da vida humana. Por onde, uns e outros estão contidos numa das partes expostas por
Agostinho, a saber, nos preceitos para dirigir a vida.

RESPOSTA À SEGUNDA. — Juízo significa execução da justiça, que se faz pela aplicação da razão a certos
casos particulares determinados. Por onde, os preceitos judiciais comunicam, por um lado, com os
morais, enquanto derivados da razão; e por outro, com os cerimoniais, enquanto certas determinações
dos preceitos comuns. Por isso, às vezes, os preceitos judiciais e os morais estão compreendidos, pela
Escritura, nos juízos: Ouve, ó Israel, as cerimônias e ordenações. Outras vezes, os judiciais e os
cerimoniais: Executareis as minhas ordenações e observareis os meus preceitos, onde, preceitos são os
morais; e ordenações, os judiciais e cerimoniais. RESPOSTA À TERCEIRA. — O ato de justiça pertence,
em geral, aos preceitos morais; mas a sua determinação em especial, aos preceitos judiciais.

## Art. 5 — Se a lei antiga contém outros preceitos, além dos morais, dos judiciais e dos cerimoniais.
(Art. Praeced.; Ad Galad., cap. V., lect III; Ad Hebr., cap. VII, lect. II).
O quinto discute-se assim. — Parece que a lei antiga contém outros preceitos, além dos morais, dos
judiciais e dos cerimoniais.

1. — Pois, os judiciais tem por objeto os atos de justiça, de homem para homem; ao passo que os
cerimoniais, o ato de religião, pelo qual se cultua a Deus. Ora, além destes, há muitas outras virtudes,
como a temperança, a fortaleza, a liberalidade e ainda outras, conforme já se disse (q. 60, a. 5). Logo,
além dos preceitos referidos, a lei antiga havia de conter muitos outros.

2. Demais. — A Escritura diz (Dt 11, 1): Ama ao Senhor teu Deus, e guarda em todo o tempo os seus
preceitos e cerimônias, os seus juízos e mandamentos. Ora, preceitos são os morais, como se disse (a.
4). Logo, além dos preceitos morais, judiciais e cerimoniais, a lei ainda contém outros chamados
mandamentos.

3. Demais. — A Escritura diz (Dt 6, 17): Guarda os preceitos dos Senhor teu Deus, e as ordenações e as
cerimônias, que te prescreveu. Logo, além de todos os preceitos, ainda a lei contém as ordenações.

4. Demais. — Diz a Escritura (Sl 118, 93): Nunca jamais me esquecerei das tuas justificações; e a Glosa: i.
é, da lei. Logo, os preceitos da lei antiga são, não só morais, cerimoniais e judiciais, mas também,
justificações.
Mas, em contrário, a Escritura (Dt 6, 1): Estes são os preceitos e as cerimônias e as ordenações, que o
Senhor Deus vos mandou. E estas palavras se dizem no princípio da lei. Logo, todos os preceitos dela
estão compreendidos nestes.

SOLUÇÃO. — A lei abrange umas disposições, que são os preceitos; e outras, ordenadas ao
cumprimento deles. Ora, os preceitos se referem aos atos, que devemos praticar. E, ao cumprimento
deles o homem é levado por dois móveis: a autoridade de quem os fez; e a utilidade da sua observância,
que está na consecução de algum bem útil, deleitável ou honesto, ou na fuga do mal contrário. — Pois,
era necessário que a lei antiga estabelecesse certas disposições indicativas da autoridade de Deus
ordenador, como as seguintes (Dt 6, 4): Ouve, ó Israel, o Senhor teu Deus é o Deus único; (Gn 1, 1) No
princípio criou Deus o céu e a terra. E estas se chamam ordenações. — Também era preciso que
estabelecesse certos prêmios para os que a observassem, e penas, para os que a transgredissem, como
claramente o fez (Dt 28): Se tu ouvires a voz do Senhor teu Deus, ele te exaltará sobre todas as noções,
etc. E estas se chamam justificações, por distribuir Deus, justamente, as punições ou os prêmios.
Por outro lado, os atos que devemos praticar não caem sob a alçada do preceito, senão enquanto tem
natureza de obrigação devida. Ora, há uma dupla obrigação: uma, fundada na regra da razão; outra, na
regra da lei determinante; assim também o Filósofo distingue duas espécies de justiça: a moral e a legal.
Ora, a obrigação moral é dupla. Pois, a razão dita à prática de certos atos ou como necessários, sem o
que não pode subsistir a ordem da virtude, ou como úteis, para que melhor se conserve essa ordem. —
E a esta luz, a lei (antiga) preceitua ou proíbe precisamente certos atos morais, como: não matarás, não
furtarás. E estes se chamam propriamente preceitos. — Outros atos, porém são preceituados ou
proibidos, não como obrigações precisas, mas para um fim melhor. E estes podem se chamar
mandamentos, por implicarem uma certa resolução e persuasão, como (Ex 22, 26): Se receberes do teu
próximo em penhor a sua capa, restitui-lha antes do sol posto; e outros semelhantes. Por onde, diz
Jerônimo: nos preceitos está a justiça; nos mandamentos, porém, a caridade. — Quanto à obrigação
fundada na determinação da lei, ela pertence, na ordem das coisas humanas, aos preceitos judiciais; e
na ordem das coisas divinas, aos cerimoniais.
Embora também os preceitos atinentes à pena ou aos prêmios possam chamar-se ordenações,
enquanto protestações da divina justiça. Mas todos os preceitos da lei podem se chamar justificações,
enquanto execuções da justiça legal. — De outro modo, podem também os mandamentos se distinguir
dos preceitos, em que preceitos se chamem os ordenados diretamente por Deus; e mandamentos,
como o próprio nome parece significar, o que mandou por meio de outros.
Disso tudo resulta, que todos os preceitos da lei estão contidos nos morais, cerimoniais e judiciais; ao
passo que as outras disposições não tem natureza de preceitos; mas se ordenam à observância deles,
como se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Só a justiça, entre as outras virtudes, implica a noção de
obrigação devida. Por onde, os preceitos morais são determináveis pela lei, na medida em que
pertencem à justiça, de que faz parte a religião, como diz Túlio. Portanto, o justo legal não pode ser algo
diferente dos preceitos cerimoniais e judiciais.

ÀS OUTRAS OBJEÇÕES AS RESPOSTAS SÃO CLARAS pelo que acaba de ser dito.