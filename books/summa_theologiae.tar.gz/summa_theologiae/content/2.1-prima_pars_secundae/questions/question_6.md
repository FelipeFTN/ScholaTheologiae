# Questão 6: Do voluntário e do involuntário.
Como é necessário, pois, chegar-se à beatitude por meio de certos atos, é preciso, conseqüentemente,
tratar dos atos humanos, para conhecermos os que a ela conduzem ou dela desviam. Mas, como as
operações e os atos dizem respeito ao singular, toda ciência operativa se completa, considerada em
particular. Por onde, a ciência moral, que versa sobre os atos humanos há de ser tratada, primeiro, em
universal e, segundo, em particular.
Quanto à consideração universal dos atos humanos, há-se, primeiro de tratar deles, em si mesmos;
segundo, dos seus princípios. Ora, desses atos, uns são próprios ao homem; outros são-lhe comuns com
os animais. E como a beatitude é bem próprio do homem, conduzem a ela mais proximamente os atos
propriamente humanos, que os que lhe são comuns com os animais. Portanto, há-se de tratar, primeiro,
dos atos próprios ao homem. Segundo, dos que lhe são comuns com os animais, chamados paixões.
Sobre o primeiro ponto duas considerações se apresentam: primeira, da condição dos atos humanos;
segunda, da distinção deles. Mas como se chamam atos humanos propriamente ditos, aos voluntários,
por ser a vontade o apetite racional próprio do homem, é preciso considerar os atos enquanto
voluntários. E portanto, há de se tratar, primeiro, do voluntário e do involuntário em comum; segundo,
dos atos voluntários elícitos da vontade mesma, dela procedente imediatamente; terceiro, dos atos
voluntários imperados pela vontade, procedentes da vontade mediante outras potências.
E como os atos voluntários têm certas circunstâncias pelas quais são julgados há-se de tratar, primeiro,
do voluntário e do involuntário; e conseqüentemente, das circunstâncias dos atos em si, onde se
manifesta o voluntário e o involuntário.
Sobre o primeiro ponto oito artigos se discutem:

## Art. 1 — Se há voluntário nos atos humanos.
(De Verit., q. 23, a . 1).
O primeiro discute-se assim. ― Parece que não há voluntário nos atos humanos.

1. ― Pois, como se vê em Gregório Nisseno, Damasceno e Aristóteles, é voluntário o que tem em si
mesmo o seu princípio. Ora, o princípio dos atos humanos não está no homem mesmo, mas lhe é
exterior; pois, o apetite do homem é movido a agir pelo apetível, que lhe é exterior e é um como motor
não-movido, conforme diz Aristóteles. Logo, nos atos humanos não há voluntário.

2. Demais. ― Como o prova o Filósofo, não há nos animais nenhum movimento incipiente que não seja
precedido de algum movimento exterior. Ora, todos os atos do homem principiam, pois nenhum é
eterno. Logo, o princípio de todos os atos humanos é exterior, e portanto não há neles voluntário.

3. Demais. ― Quem age voluntariamente pode agir por si. Ora, tal não convém ao homem, pois, diz a
Escritura (Jô 15, 5): Vós sem mim não podeis fazer nada. Logo, não há voluntário nos atos humanos.
Mas, em contrário, como diz Damasceno, voluntário é o ato que é operação racional. Ora, tais são os
atos humanos. Logo, neles há voluntário.

SOLUÇÃO. ― Necessariamente há voluntário nos atos humanos. Isto se evidencia considerando que o
princípio de certos atos ou movimento está no agente ou no que é movido; e de outros movimentos ou
atos o princípio é exterior. Assim, quando a pedra é movida para cima, o princípio dessa moção lhe é
exterior; mas, quando movida para baixo, o princípio de tal moção está na pedra mesma. Ora, dos seres
movidos por um princípio intrínseco, uns se movem a si mesmos e outros, não. E como todo agente ou
ser movido age ou é movido para um fim, são perfeitamente movidos por um princípio intrínseco os
seres em que há um princípio intrínseco, não só de serem movidos, mas de serem movidos para um fim.
Ora, para que alguma coisa se faça para um fim, é necessário algum conhecimento deste. Por onde,
tudo o que age ou é movido por um princípio intrínseco, com algum conhecimento do fim, tem em si
mesmo o princípio de seu ato, não só para agir, mas agir para o fim. Enquanto que o que não tem
nenhum conhecimento do fim, embora encerre em si o princípio da ação ou do movimento, não
contém, contudo o princípio de agir ou ser movido para um fim, em si mesmo, mas em outro ser que lho
imprime, para a sua moção em vista do fim. E por isso não se diz que tais seres se movem a si mesmo,
mas que são movidos por outros. Ao passo que os que têm conhecimento do fim se consideram como
movendo a si mesmos, por terem em si o princípio, não só de agir, mas ainda de agir para um fim. E
portanto, como uma e outra coisa, i. é, o agir e o agir para um fim, procede de um princípio intrínseco,
os movimentos de tais seres e os seus atos são chamados voluntários; pois, a denominação de
voluntário importa em que o movimento e o ato procede da inclinação própria. Donde vem o chamar-se
voluntário, conforme a definição de Aristóteles, de Gregório Nisseno e de Damasceno, o que tem um
princípio interno, mas com a adição da ciência. Por onde, como o homem conhece por excelência o fim
da sua obra e se move a si mesmo, os seus atos implicam o voluntário, em máximo grau.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nem todo princípio é princípio primeiro. Embora, pois,
seja da essência do voluntário ter princípio intrínseco, não lhe vai contudo contra a essência que esse
princípio seja causado ou movido por um princípio externo, pois essa essência não exige que tal
princípio seja um princípio primeiro. Deve-se porém saber que pode um princípio de movimento ser
primeiro, genericamente e não o ser em si mesmo; assim, no gênero dos seres alteráveis, o alterador
primeiro é o corpo celeste, que todavia não é em si mesmo o primeiro motor, mas é movido localmente,
pelo motor superior. Assim, pois, o princípio intrínseco do ato voluntário, que é a virtude cognoscitiva e
apetitiva, é o primeiro princípio genérico do movimento apetitivo, embora seja movido por um princípio
externo, quanto a outras espécies de movimento.

RESPOSTA À SEGUNDA. ― Certamente o primeiro movimento do animal é precedido de algum
movimento externo, sob duplo aspecto. Primeiro, enquanto por este movimento externo um sensível é
apresentado ao sentido do animal, cujo sensível, apreendido, move o apetite. Assim o leão, vendo um
veado aproximar-se, pelo seu movimento, começa a ser movido para ele. Segundo, enquanto, pelo
movimento externo, o corpo do animal começa, de algum modo, a imutar-se, por imutação natural, p.
ex., pelo frio ou pelo calor. Ora, imutado um corpo, pelo movimento de outro corpo externo, também se
imuta, acidentalmente, o apetite sensitivo, que é virtude do corpo orgânico; assim quando, por uma
alteração do corpo, juntamente se move o apetite à concupiscência. Mas isto não vai contra a essência
do voluntário, como já se disse; pois, tais moções por um princípio externo são de outro gênero.

RESPOSTA À TERCEIRA. ― Deus move o homem a agir, não só propondo-lhe ao sentido o apetível, ou
imutando-lhe o corpo, mas também movendo a vontade mesma; porque todo movimento, tanto da
vontade como da natureza, dele procede, como primeiro motor. E assim como não é contra a essência
da natureza que o seu movimento provenha de Deus, como primeiro motor, por ser a natureza um
instrumento de Deus, que se move; assim, não é contra a essência do ato voluntário proceder de Deus,
por ser a vontade movida por ele. É, porém, comum à essência do movimento, tanto natural, como
voluntário, proceder de um princípio intrínseco.

## Art. 2 — Se há voluntário nos brutos.
(II Sent., dist. XXV, a . 1, ad 6; De Verit., q. 23, a . 1; III Ethic., lect. IV).
O segundo discute-se assim. ― Parece que não há voluntário nos brutos.

1. ― Pois, voluntário vem de vontade e esta, fundando-se na razão, não pode existir nos brutos. Logo,
neles não há voluntário.

2. Demais. ― Por serem os atos humanos voluntários, diz-se que o homem é senhor deles. Ora, os
brutos, que não agem, mas antes são levados ― como diz Damasceno ― não têm o domínio sobre seus
atos. Logo, não há neles voluntário.

3. Demais. ― Damasceno diz que os atos voluntários tem como seqüência o louvor e o vitupério. Ora, tal
não se dá com os atos dos brutos. Logo, não há neles voluntário.
Mas, em contrário, diz o Filósofo, que às crianças e aos brutos é comum o voluntário. E o mesmo diz
Gregório Nisseno e Damasceno[f]V. supra.

SOLUÇÃO. ― Como já se disse, a essência do voluntário implica em o princípio do ato ser interno, como
algum conhecimento do fim. Ora, duplo é este conhecimento: o perfeito e o imperfeito. Pelo perfeito
não só é apreendida a coisa constitutiva do fim, mas também a idéia de fim e a proporção entre este e o
que se lhe ordena. E tal conhecimento do fim só é próprio à criatura racional. O conhecimento
imperfeito do fim é o consistente na só apreensão dele, sem se conhecer a idéia de fim e a proporção
entre o ato e este. E tal conhecimento existe nos brutos, pelo sentido e pela estimativa natural. ― Por
onde, do perfeito conhecimento do fim depende o voluntário, na sua essência perfeita, pelo qual
alguém pode, apreendido o fim e deliberando sobre ele e sobre o que para ele conduz, ser ou não
movido para tal. ― Porém, ao conhecimento imperfeito do fim segue-se o voluntário, no sentido
imperfeito, enquanto que alguém, apreendendo o fim, não delibera mas é, subitamente, movido para
ele. Por onde, o voluntário, na acepção perfeita, só é próprio à natureza racional; mas, na imperfeita,
também existe nos brutos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vontade, designando o apetite racional, não pode
existir nos seres carecedores de razão. Ao passo que a denominação de voluntário procede da vontade e
pode se aplicar aos seres nos quais há participação da vontade, por alguma conveniência com ela. E
deste modo o voluntário se atribui aos brutos, enquanto que, por algum conhecimento, são movidos
para o fim.

RESPOSTA À SEGUNDA. ― O homem é senhor dos seus atos porque delibera sobre eles. Pois, é porque
a razão deliberante se refere a termos opostos, que a vontade pode tender para um deles. Mas nesta
acepção não há voluntário nos brutos, como já se disse.

RESPOSTA À TERCEIRA. ― O louvor e o vitupério são consecutivos ao ato voluntário, quanto à idéia
perfeita de voluntário, que não existe nos brutos.

## Art. 3 — Se o voluntário pode existir sem algum ato.
(Infra, q. 71, a . 5, ad 2; II Sent., dist. XXXV, a . 3; De Maio, q. 2, a . 1, ad 2).
O terceiro discute-se assim. ― Parece que o voluntário não pode existir sem algum ato.

1. ― Pois, chama-se voluntário o que procede da vontade. Ora, nada pode proceder da vontade a não
ser por algum ato, ao menos, da própria vontade. Logo, o voluntário não pode existir sem algum ato.

2. Demais. ― Assim como se diz que alguém quer, por um ato da vontade, assim se diz que não quer,
cessando tal ato. Ora, não querer causa o involuntário, que se opõe ao voluntário. Logo, este não pode
existir, cessando o ato da vontade.

3. Demais. ― Da essência do voluntário é o conhecimento, como já se disse. Ora, o conhecimento
implica a existência de algum ato. Logo, o voluntário não pode existir sem qualquer ato.
Mas, em contrário. ― Chama-se voluntário aquilo de que somos senhores. Ora, nós o somos de agir ou
não, de querer ou não querer. Logo, como agir e querer é voluntário, do mesmo modo o é não agir e
não querer.

SOLUÇÃO. ― Chama-se voluntário o que procede da vontade. Ora, diz-se que uma coisa procede de
outra, de duplo modo. Diretamente, quando uma coisa procede de outra, que é agente; assim, a
calefação, do calor. Indiretamente, quando procede de outra porque esta não age; assim, dizemos que a
submersão de um navio procede do piloto, porque este deixou de dirigi-lo. Ora, deve-se saber, que nem
sempre o resultante da inação tem como causa a inação do agente; mas só é assim, quando este podia e
devia agir. Se, pois, o piloto não pudesse dirigir o navio ou o governo deste lhe não fosse cometido, não
se lhe havia de imputar a submersão causada pela sua ausência.
Como pois a vontade, querendo e agindo, pode e às vezes deve impedir o não querer e o não agir, um e
outro lhe é imputado, como proveniente dela. E assim, o voluntário pode existir sem nenhum ato; às
vezes, sem ato externo, mas com ato interno, como quando quer não agir; outras vezes, porém,
também sem ato interno, como quando não quer agir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Chama-se voluntário não só o que procede da vontade
agente, diretamente, mas também o que procede dela não agente, indiretamente.

RESPOSTA À SEGUNDA. ― Não querer tem dupla acepção. ― Ora, é tomado com força de expressão
una, como infinitivo do verbo não querer. Quando, pois, digo ― não quero ler ― o sentido é ― quero
não ler; e assim ― não querer ler ― significa ― querer não ler. E então não querer causa o voluntário.
― Noutra acepção, é tomado com força de oração, e então não é afirmado o ato da vontade, e portanto
não querer não causa o involuntário.

RESPOSTA À TERCEIRA. ― O ato do conhecimento é necessário, para o voluntário, do mesmo modo por
que o é o da vontade; a saber, de maneira que esteja no poder de alguém pensar, querer e agir. E então,
assim como não querer e não agir, a seu tempo, é voluntário, assim também não pensar.

## Art. 4 — Se se pode violentar a vontade.
(I, q. 82, a . 1; II Sent., dist. XXV, a . 2; IV. Dist. XXXIX, a . 1; De Verit., q. 22, a . 5, 8).
O quarto discute-se assim. ― Parece que a vontade pode ser violentada.

1. ― Pois, um ser pode ser violentado por outro, que lhe é superior. Ora, há um ser ― Deus ― mais
poderoso que a vontade humana. Logo, esta pode ser coagida por ele.

2. Demais. ― Tudo o que é passivo é coagido pelo ativo correspondente, quando imutado por este. Ora,
a vontade, motor movido, como diz Aristóteles, é virtude passiva. Sendo ela, pois, às vezes movida pelo
ativo, correspondente, resulta, que às vezes é coagida.

3. Demais. ― Movimento violento é o que vai contra a natureza. Ora, o movimento da vontade é às
vezes contra a natureza, como é claro no movimento dela para pecar, contrário à natureza, conforme
Damasceno. Logo, o movimento da vontade pode ser coagido.
Mas, em contrário, como diz Agostinho, o que se faz por vontade não se faz por necessidade. Logo, o
que se faz por vontade não pode ser coagido, e portanto a vontade não pode ser coagida a agir.

SOLUÇÃO. ― Duplo é o ato da vontade: um é ato seu imediato, como elícito e é o querer; outro é o ato
por ela imperado e exercido mediante outra potência, como andar e falar, imperados pela vontade,
exercidos porém pela potência motiva. Nestes, a vontade pode sofrer violência pela qual os membros
externos podem ser impedidos de executarem o império da vontade. Mas, o ato próprio da vontade, em
si mesmo, não pode ser violentado. E a razão, é que tal ato não é mais do que uma inclinação
procedente do princípio cognoscitivo interior, assim como o apetite natural é uma inclinação
procedente do princípio interno, sem conhecimento. Ora, o que é coagido ou violento procede de um
princípio exterior. Por onde, vai contra a essência mesma do ato da vontade ser coagido ou violento.
Assim, como é contra a essência da inclinação natural ou do movimento da pedra o ser levada para
cima, embora tal se possa dar por violência; não podendo porém esse movimento violento proceder da
natural inclinação dela. Assim também o homem pode ser arrastado por violência mas que tal lhe
proceda da vontade repugna à essência da violência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus, mais poderoso que a vontade humana, pode
movê-la, conforme aquilo da Escritura (Pr 21, 1): O coração do rei se acha na mão do Senhor; ele o
inclinará para qualquer parte que quiser. Ora, se tal fosse por violência, já não seria com ato da vontade,
nem seria movida a vontade, mas algo contra ela.

RESPOSTA À SEGUNDA. ― Nem sempre, que um ser passivo é imutado pelo ativo correspondente o
movimento é violento; mas só quando tal se dá contra a inclinação interior do passivo. Do contrário
todas as alterações e gerações dos corpos simples seriam não naturais e violentas. São porém naturais,
pela aptidão interior da matéria ou do sujeito, para tal disposição. E semelhantemente, quando a
vontade é movida pelo apetível, conforme a sua inclinação própria, o movimento não é violento, mas,
voluntário.

RESPOSTA À TERCEIRA. ― Aquilo para o que tende a vontade, pecando, é mau e contra a natureza
racional, na verdade das coisas; contudo, é apreendido como bom e conveniente à natureza; por ser
conveniente ao homem quanto a alguma paixão do sentido, ou a algum hábito corrupto.

## Art. 5 — Se a violência causa o involuntário.
(Infra. q. 73. a . 6; III Ethic., lect. I).
O quinto discute-se assim. ― Parece que a violência não causa o involuntário.

1. ― Pois, voluntário e involuntário procedem da vontade. Ora, esta, como já se disse, não pode ser
violentada. Logo, a violência não pode causar o involuntário.

2. Demais. ― O involuntário é acompanhado de tristeza, como diz Damasceno e o Filósofo. Ora,
podemos às vezes sofrer violência sem nos contristarmos. Logo, ela não causa o involuntário.

3. Demais. ― O que procede da vontade não pode ser involuntário. Ora, há certa violência procedente
da vontade; assim quando alguém sobe, carregando um corpo pesado; e quando inflecte os membros
contra a flexibilidade natural deles. Logo, a violência não causa o involuntário.
Mas, em contrário, diz Damasceno e o Filósofo, que há involuntário por violência.

SOLUÇÃO. ― A violência se opõe diretamente ao voluntário, como também ao natural. Pois a um e
outro é comum proceder de princípio intrínseco, pela razão seguinte. Assim como no ser carente de
conhecimento, a violência causa o que vai contra a natureza; assim, nos seres que conhecem, a violência
produz o que vai contra a vontade. Ora, assim como o que vai contra a natureza se chama inatural,
assim, o que vai contra a vontade, involuntário. Por onde, a violência causa o involuntário.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O involuntário se opõe ao voluntário; pois, como já se
disse, voluntário se chama não só o ato procedente, imediatamente, da vontade mesma, mas também o
imperado por ela. Quanto ao primeiro, a vontade não pode ser violentada, como já se disse; por onde, a
violência não pode tornar tal ato involuntário. Mas, quanto ao ato imperado, a vontade pode padecer
violência e então, relativamente a tal ato, a violência causa o involuntário.

RESPOSTA À SEGUNDA. ― Assim como se chama natural ao que é conforme a inclinação da natureza,
assim, voluntário ao que é conforme à da vontade. Ora, natural se toma em dupla acepção. Numa,
significa o procedente da natureza como princípio ativo; assim; aquecer é natural ao fogo. Noutra, como
princípio passivo, e isso porque há, em a natureza, inclinação a receber a ação de princípio extrínseco;
assim, diz-se que é natural o movimento do céu, por causa da aptidão natural do corpo celeste a tal
movimento. Embora seja motor voluntário. E semelhantemente, voluntário pode ser tomado em dupla
acepção. Numa, relativo à ação, como quando alguém quer fazer alguma coisa; noutra, relativo à
paixão, como quando alguém quer sofrer alguma coisa, de outrem. Por onde, sendo a ação causada por
algo exterior, e permanecendo, no qual sofre, a vontade de sofrer, não há, no caso, violento em si;
porque, embora o que sofre não contribua para a ação, contribui contudo, querendo sofrer e, por isso,
não pode ser considerado involuntário.

RESPOSTA À TERCEIRA. ― Como diz o Filósofo, o movimento do animal pelo qual às vezes se move
contra a inclinação natural do corpo, embora não seja natural a este, é contudo de certo modo natural
ao animal, porque lho é o ser movido conforme o apetite. E portanto, não há violento, absoluta, mas
relativamente falando. E o mesmo devemos dizer quando inflectimos os membros contra a disposição
natural. Pois isto é violento relativamente, a saber, quanto ao membro particular; não porém
absolutamente, quanto ao homem agente, em si mesmo.

## Art. 6 — Se o medo causa o involuntário absoluto.
(VI Sent., dist. XXIX, q. 1, a . 1; Quodi. V. q. 5, a 3; II Cor., cap. IX, Lect. 1; III Ethic., lect. I, II).
O sexto discute-se assim. ― Parece que o medo causa o involuntário absoluto.

1. ― Pois, assim como a violência é relativa ao que contraria presencialmente à vontade, assim o medo
é relativo ao mal futuro, que a ela lhe repugna. Ora, a violência causa o involuntário absoluto. Logo,
também o medo.

2. Demais. ― O que tem em si tal natureza, assim se conserva com o acréscimo seja do que for; p.ex., o
quente em si permanece tal, unido seja ao que for. Ora, o que se faz por medo é em si involuntário.
Logo, permanece tal, mesmo sobrevindo o medo.

3. Demais. ― O que tem natureza condicional a tem relativamente; mas o que a tem sem nenhuma
condição absolutamente a tem. Assim o necessário condicional o é relativamente; porém o necessário
absolutamente, o é em si mesmo. Ora, o que se faz por medo é involuntário absolutamente; logo, não é
voluntário absolutamente; logo, não é voluntário senão condicional, i. é, para evitar-se o mal temido.
Logo, o que se faz por medo é involuntário absolutamente.
Mas, em contrário, diz Gregório Nisseno (Nemésio) e também o Filósofo, que as ações feitas por medo
são mais voluntárias que involuntárias.

SOLUÇÃO. ― Como diz o Filósofo e Gregório Nisseno (Nemésio), as ações feitas por medo incluem um
misto de voluntário e involuntário. Pois, consideradas em si, não há nelas voluntário; mas há o
voluntário ocasional, i. é, o que evita o mal temido.
Mas, se bem se atentar, tais ações — voluntárias, absolutamente, e involuntárias, relativamente ― são
mais voluntárias que involuntárias. Pois, considera-se absoluto o atual; e o existente só na apreensão
não existe absoluta, mas relativamente. Ora, os inspirados no medo são atuais na medida em que são
praticados. E como os atos dizem respeito ao singular, e este, como tal se realiza num determinado
lugar e tempo, um ato praticado é atual por se realizar em tal lugar e tal tempo e sob as outras
condições individuais. Assim, pois, o praticado por medo é voluntário, por se realizar em determinado
lugar e tempo e como sendo, em determinado caso, impedimento a um maior mal, temido; p. ex., a
projeção de mercadorias ao mar torna-se voluntária em tempo de tempestade, pelo temor do perigo.
Por onde é manifesto, que é voluntário absolutamente e verifica portanto a essência do voluntário, por
ser o seu princípio interior. Mas o considerar-se, fora do caso figurado, o ato praticado por medo como
repugnante à vontade, isto não o é senão em virtude de tal consideração. E portanto, é involuntário,
relativamente, i. é, enquanto considerado como fora do caso vertente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ações feitas por medo e por violência diferem, não só
quanto ao presente e ao futuro, mas ainda no seguinte. O praticado por violência é absolutamente
contra o movimento da vontade, que nisso não consente; ao passo que o praticado por medo se torna
voluntário porque tal movimento o visa não em si mesmo, mas por outra causa, i. é, para afastar o mal
temido. Pois basta à essência do voluntário, que o seja por causa de outro fim, porque é voluntário não
só o que é querido por si mesmo, como fim, mas também o querido por causa de outra coisa, como
sendo o fim. Por onde, como é claro, no feito por violência a vontade interior não age; mas age, no feito
por medo. E, portanto, como diz Gregório Nisseno (Nemésio), a definição de violento para excluir o feito
por medo, não só se diz que violento é o que procede de princípio extrínseco, mas se acrescenta, sem
que o paciente em nada contribua para tal; pois, no feito por medo em algo concorre a vontade de
quem teme.

RESPOSTA À SEGUNDA. ― O que tem designação absoluta, como o cálido e o branco, permanece como
é, acrescentando-se seja o que for; mas o que a tem relativa varia segundo respeita coisas diversas;
assim, o grande comparado com uma coisa é pequeno comparado com outra. Ora, o voluntário é assim
chamado não só em si mesmo, como absolutamente, mas também por causa de outra coisa; como
relativamente. E, portanto, nada impede seja voluntário no atinente a um ato, o que não o seria no
atinente a outro.

RESPOSTA À TERCEIRA. ― O praticado por medo é voluntário sem condição, i. é, enquanto atualmente
feito; mas é involuntário condicionalmente, i. é, se tal medo não estivesse iminente. Por onde, da
objeção proposta antes se pode concluir o oposto.

## Art. 7 — Se a concupiscência causa o involuntário.
(III Ethic., lect. II, IV).
O sétimo discute-se assim. ― Parece que a concupiscência causa o involuntário.

1. ― Pois, como o medo, também a concupiscência é uma paixão. Ora, aquele causa, de certo modo, o
involuntário. Logo também a concupiscência o causa.

2. Demais. ― Assim como por temor o tímido age contra o que propusera, assim também o
incontinente, por concupiscência. Ora, o temor causa, de certo modo, o involuntário. Logo, também a
concupiscência.

3. Demais. ― O voluntário supõe o conhecimento. Ora, este a concupiscência o corrompe, pois, como
diz o Filósofo, a deleitação, ou concupiscência da deleitação, corrompe a estimativa da prudência. Logo,
a concupiscência causa o involuntário.
Mas, em contrário, diz Damasceno: O involuntário é feito com tristeza e é digno de misericórdia ou
indulgência. Ora, nada disto cabe ao feito por concupiscência. Logo, esta não causa o involuntário.

SOLUÇÃO. ― A concupiscência não causa o involuntário, mas, antes o voluntário. Pois este é assim
chamado por inclinar-se a vontade para ele. Ora, pela concupiscência a vontade é inclinada a querer o
desejado. Logo, a concupiscência causa, antes, o voluntário que o involuntário.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O temor é relativo ao mal; a concupiscência porém ao
bem. Ora, ao passo que aquele é contrário, esta é consona à vontade. Por onde, o temor, mais que a
concupiscência, causa o involuntário.

RESPOSTA À SEGUNDA. ― Em quem age por medo, repugna a vontade ao que faz, em si considerado.
Mas no que age por concupiscência, como o incontinente, não permanece a vontade anterior, pela qual
repudiava o que deseja, senão que se muda a querer o que antes repudiava. E portanto, no feito por
medo, há de certo modo involuntário; mas este de nenhum modo existe no feito por concupiscência.
Pois o incontinente, por concupiscência, age contra o que antes propusera. Não, porém, contra o que
atualmente quer. Ao passo que o tímido age contra o que ainda atualmente quer, em si mesmo.

RESPOSTA À TERCEIRA. ― Se a concupiscência travasse totalmente o conhecimento, como se dá com os
que ela torna amantes, resultaria a eliminação do voluntário. Mas nem por isso haveria aí propriamente
involuntário; pois nos privados do uso da razão não há voluntário nem involuntário. Às vezes, porém, no
feito por concupiscência não fica totalmente travado o conhecimento, porque não se elimina o poder de
conhecer, mas só a consideração atual relativa ao que se vai fazer. Ora, isto mesmo é voluntário, porque
voluntário se chama o que está no poder da vontade, como não agir, não querer, e semelhantemente,
não considerar, pois, a vontade pode resistir à paixão, como a seguir se dirá.

## Art. 8 — Se a ignorância causa o involuntário.
(Infra, q. 76, a . 3; II Sent., dist. XXXIX, q. 1, a . 1, ad. 4; dist. XLIII, a . 1, ad 3; De Malo, q. 3, a .8; III Ethic.,
lect. I, III).
O oitavo discute-se assim. ― Parece que a ignorância não causa o involuntário.

1. ― Pois, como diz Damasceno, o involuntário merece vênia. Ora, às vezes o feito por ignorância não a
merece, conforme aquilo da Escritura (1 Cor 14, 38): Se alguém, porém, o quer ignorar, será ignorado.
Logo, a ignorância não causa o involuntário.

2. Demais. ― Todo pecado supõe ignorância, conforme a Escritura (Pr 14, 22): Os que obram mal erram.
Se pois a ignorância causasse o involuntário, resultaria que todo pecado seria involuntário, o que colide
com o dito de Agostinho: todo pecado é voluntário.

3. Demais. ― O involuntário é acompanhado de tristeza, como diz Damasceno. Ora, certos atos são
feitos por ignorância e sem tristeza, como quando alguém mata o inimigo, que quer matar, pensando
matar um cervo. Logo, a ignorância não causa o involuntário.
Mas, em contrário, diz Damasceno e o Filósofo, que há involuntário por ignorância.

SOLUÇÃO. ― A ignorância pode causar o involuntário, privando do conhecimento que ele implica, como
já se disse. Mas, não é qualquer ignorância que priva desse conhecimento, pois, há-se de saber que a
ignorância mantém tríplice relação com o ato da vontade: concomitante, conseqüente e antecedente.
A concomitante diz respeito ao que se faz e igualmente se havia de fazer, ainda que se soubesse. E
então, a ignorância não induz a querer o que se faz; mas, por acidente, o feito é simultaneamente
ignorado. Assim, no exemplo supra-aduzido, quando alguém mata, ignorando, o inimigo que quer
matar, julgando matar um cervo. E tal ignorância não causa o involuntário, como diz o Filósofo, porque
não causa nada de repugnante à vontade; mas, causa o não voluntário, (noluntário), porque não pode
ser atualmente querido o ignorado.
A ignorância conseqüente à vontade é a voluntária, o que de dois modos se dá, conforme os dois modos
de voluntário sobre-estabelecidos. ― Um é quando o ato da vontade se apóia na ignorância; assim,
quem quer ignorar para ter escusa do pecado ou para não se abster dele, conforme a Escritura (Jó 21,
14): Nós não queremos conhecer os teus caminhos. E esta ignorância se chama afetada. ― Outro é
quando alguém pode e deve saber, pois ao não agir e ao não querer chama-se voluntário, como já se
disse. Assim, deste modo há ignorância quando alguém não considera atualmente o que pode e deve
considerar; e essa é a ignorância da má eleição e procede da paixão ou do hábito. Ou quando alguém
não cura de adquirir o conhecimento que deve ter. E conforme a este modo, a ignorância dos princípios
universais do direito, que devam ser conhecimentos de todos, considera-se voluntária, quase
procedente da negligência. ― Sendo pois a ignorância voluntária, destes dois modos, não pode causar o
involuntário absolutamente, mas causa o voluntário relativo, por preceder o movimento da vontade,
levada a fazer o que não faria se houvesse ciência.
A ignorância antecedente à vontade não é voluntária, e contudo é causa de se querer o que de outro
modo não se quereria. Assim, quando alguém, ignorando, por não ser obrigado a saber, alguma
circunstância do ato que pratica, não o faria se a soubesse; p. ex., uma pessoa depois de ter empregado
estudo, não sabe que um transeunte passa pela rua, atira uma seta e o mata. E tal ignorância causa o
involuntário, absolutamente.
Donde se deduzem AS RESPOSTAS ÀS OBJEÇÕES. — Pois, a primeira se funda na ignorância do que se
está obrigado a saber. ― A segunda, na ignorância de eleição que, de certo modo, é voluntária, como se
disse. ― A terceira, enfim, na ignorância concomitante à vontade.