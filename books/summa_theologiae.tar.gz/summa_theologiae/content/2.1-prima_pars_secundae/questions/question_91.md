# Questão 91: Da diversidade das leis.
Em seguida devemos tratar da diversidade das leis.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se há uma lei eterna.
(Infra, q. 93, a. 1).
O primeiro discute-se assim. — Parece que não há nenhuma lei eterna.

1. — Pois, toda lei é imposta a alguém. Ora, como só Deus existe abeterno, nenhuma lei pode abeterno
ter sido imposta a ninguém. Logo, nenhuma lei é eterna.

2. Demais. — A promulgação é da essência da lei. Ora, esta não poderia sê-la abeterno porque ninguém
há para tê-la promulgado abeterno. Logo, nenhuma lei pode ser eterna.

3. Demais. — A lei importa em ordenação para um fim. Ora, nada do que se ordena para um fim é
eterno, porque só o último fim o é. Logo, nenhuma lei é eterna.
Mas, em contrário, Agostinho diz: A Lei, que é chamada a razão suma, não pode deixar de ser
considerada imutável e eterna por todo ser inteligente.

SOLUÇÃO. — Como já dissemos (q. 90, a. 1 ad 2; a. 3, a. 4), a lei não é mais do que um ditame da razão
prática, do chefe que governa uma comunidade perfeita. Ora, supondo que o mundo seja governado
pela Divina Providência, como estabelecemos na Primeira Parte (q. 22, a. 1, a. 2), é manifesto que toda a
comunidade do universo é governada pela razão divina. Por onde, a razão mesma do governo das
coisas, em Deus, que é o regedor do universo, tem a natureza de lei. E como a razão divina nada
concebe temporalmente, mas tem o conceito eterno, conforme a Escritura (Pr 8, 23), é forçoso dar a
essa lei a denominação de eterna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As coisas que em si mesmas não existem, existem em
Deus, enquanto por ele pré conhecidas e pré ordenadas, conforme aquilo da Escritura (Rm 4, 17): Que
chama as coisas que não são como as que são. Assim, pois, o conceito eterno da lei divina tem a
natureza de lei eterna, enquanto ordenada por Deus para o governo das coisas por ele preconhecidas.

RESPOSTA À SEGUNDA. — A promulgação se faz verbalmente e por escrito. E de ambos os modos,
recebe a lei eterna promulgação, da parte de Deus, que a promulga. Pois, é eterno o Verbo divino e
eterna é a escritura do livro da vida. Mas essa promulgação não pode ser eterna por parte da criatura
que a ouve ou a observa.

RESPOSTA À TERCEIRA. — A lei implica, ativamente, ordem para um fim, enquanto por ela certas coisas
se ordenam para este. Mas não passivamente, no sentido em que a própria lei se ordena para um fim;
salvo, por acidente, no governador, cujo fim está fora dele, para o qual também necessariamente há de
a sua lei se ordenar. Ora, o fim do governo divino é Deus mesmo, nem a sua lei dele difere. Portanto, a
lei eterna não se ordena para outro fim.

## Art. 2 — Se há em nós uma lei natural.
(IV Sent., dist. XXXIII: q. 1, a. 1).
O segundo discute-se assim. — Parece que não há em nós nenhuma lei natural.

1. — Pois, o homem é suficientemente governado pela lei eterna. Assim, Agostinho diz, que pela lei
eterna torna-se justo o serem todas as coisas ordenadíssimas. Ora, a natureza não abunda no supérfluo,
assim como não falha no necessário. Logo, não há no homem nenhuma lei natural.

2. Demais. — Pela lei o homem ordena os seus atos para o fim, como já se estabeleceu (q. 90, a. 2). Ora,
a ordenação dos atos humanos para o fim não se faz por natureza, como se dá com as criaturas
irracionais que buscam o fim pelo só apetite natural. Pois, o homem busca o fim pela razão e pela
vontade. Logo, não há nenhuma lei natural no homem.

3. Demais. — Quanto mais somos livres, tanto menos estamos sujeitos à lei. Ora, o homem é mais livre
que todos os animais, por causa do livre arbítrio que, ao contrário deles, possui. Por onde, não estando
eles sujeitos à lei natural, nem o está o homem.
Mas, em contrário, àquilo da Escritura (Rm 2, 14) – Porque quando os gentios, que não tem lei, fazem
naturalmente as coisas que são da lei – diz a Glosa: Embora sem a lei escrita, tem contudo a Lei natural,
pela qual todos tem entendimento e consciência do bem e do mal.

SOLUÇÃO. — Como já dissemos (q. 90, a. 1), sendo a lei regra e medida, pode de dois modos estar num
sujeito: como no que regula e mede, e como no regulado e medido; pois, na medida em que um ser
participa da regra ou da medida, nessa mesma é regulado ou medido. Ora, todas as coisas sujeitas à
Divina Providência são reguladas e medidas pela lei eterna, como do sobredito resulta (a. 1). Por onde é
manifesto, que todas participam, de certo modo, da lei eterna, enquanto que por estarem impregnadas
dela se inclinam para os próprios atos e fins. Ora, entre todas as criaturas, a racional está sujeita à Divina
Providência de modo mais excelente, por participar ela própria da providência, provendo a si mesma e
às demais. Portanto, participa da razão eterna, donde tira a sua inclinação natural para o ato e o fim
devidos. E a essa participação da lei eterna pela criatura racional se dá o nome de lei natural. Por isso,
depois do Salmista ter dito (Sl 4, 6) – Sacrificai sacrifício de justiça – continua, para como que responder
aos que perguntam quais sejam as obras da justiça: Muitos dizem – quem nos patenteará os bens? A
cuja pergunta dá a resposta: Gravado está, Senhor, sobre nós o lume do teu rosto, querendo assim dizer
que o lume da razão natural, pelo qual discernimos o bem e o mal, e que pertence à lei natural, não é
senão a impressão em nós do lume divino. Por onde é claro, que a lei natural não é mais do que a
participação da lei eterna pela criatura racional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procederia se a lei natural fosse algo diverso
da lei eterna;ora, ela não é mais do que uma participação desta, como dissemos.

RESPOSTA À SEGUNDA. — Toda operação da nossa razão e da nossa vontade deriva do que é segundo a
natureza, como dissemos (q. 10, a. 1). Pois, todo raciocínio deriva de princípios evidentes; e todo desejo
dos meios deriva do desejo natural do fim último. Por onde e necessariamente, a direção primeira dos
nossos atos para o fim há de depender da lei natural.

RESPOSTA À TERCEIRA. — Mesmo os animais irracionais participam, a seu modo, da razão eterna, como
a criatura racional. Mas como esta dela participa intelectual e racionalmente, por isso essa participação
da lei eterna pela criatura racional chama-se propriamente lei;pois, a lei é algo de racional, como já
dissemos (q. 90, a. 1). Ora, a lei eterna não é participada racionalmente pela criatura irracional;
portanto, só por semelhança pode-se chamar lei a essa participação.

## Art. 3 — Se há uma lei humana.
(Infra, q. 95, a. 1).
O terceiro discute-se assim. — Parece que não há nenhuma lei humana.

1. — Pois, a lei natural é uma participação da lei eterna, como já se disse (a. 2). Ora, pela lei eterna,
todas as coisas são ordenadíssimas, como diz Agostinho. Logo, a lei natural basta para ordenar todas as
coisas humanas, e portanto, não há necessidade de nenhuma lei humana.

2. Demais. — A lei é essencialmente medida, como se disse (q. 90, a. 1). Ora, a razão humana não é a
medida das coisas, mas antes inversamente, como diz Aristóteles. Logo, nenhuma lei pode proceder da
razão humana.

3. Demais. — A medida deve ser certíssima, como está em Aristóteles. Ora, o ditame da razão humana,
no concernente à direção das coisas, é incerto, conforme àquilo da Escritura (Sb 9, 14): Os pensamentos
dos mortais são tímidos, e incertas as nossas providências. Logo, nenhuma lei pode proceder da razão
humana.
Mas, em contrário, Agostinho ensina que há duas leis: uma eterna, e outra temporal, a que chama
humana.

SOLUÇÃO. — Como já dissemos (q. 90, a. 1 ad 2), a lei é um ditame da razão prática. Ora, dá-se que o
modo de proceder da razão prática é semelhante ao da especulativa, pois ambas procedem de certos
princípios para certas conclusões, como antes ficou estabelecido. Por onde devemos concluir que, assim
como a razão especulativa, de princípios indemonstráveis e evidentes tira as conclusões das diversas
ciências, cujo conhecimento não existe em nós naturalmente, mas são descobertos por indústria da
razão; assim também, dos preceitos da lei natural, como de princípios gerais e indemonstráveis,
necessariamente a razão humana há de proceder a certas disposições mais particulares. E estas
disposições particulares, descobertas pela razão humana, observadas as outras condições pertencentes
à essência da lei, chamam-se leis humanas como já dissemos (q. 90, a. 2, a. 3, a. 4). E por isso, Túlio, na
sua Retórica, diz que a origem do direito está na natureza; daí, em razão da utilidade, nasceram certas
disposições costumeiras; depois, o medo e a religião sancionaram essas disposições oriundas da
natureza e aprovadas pelo costume.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A razão humana não pode participar plenamente do
ditame da razão divina; mas o pode ao seu modo e imperfeitamente. Por onde, pela razão especulativa,
por uma participação natural da sabedoria divina, temos o conhecimento de certos princípios comuns,
mas não o conhecimento próprio de qualquer verdade, como a contém a sabedoria divina. Assim
também, pela razão prática, o homem naturalmente participa da lei eterna relativamente a certos
princípios comuns, mas não quanto a direções particulares de determinados atos, que contudo estão
contidos na lei eterna. Por onde, é necessário, ulteriormente, que a razão humana proceda a certas
disposições particulares das leis.

RESPOSTA À SEGUNDA. — A razão humana, em si mesma, não é a regra das coisas; mas os princípios,
que lhe são naturalmente inerentes, são certas regras gerais, e medidas de tudo o que o homem deve
fazer; do que a razão natural é a regra e a medida, embora não seja a medida do que é natural.

RESPOSTA À TERCEIRA. — A razão prática versa sobre os atos, que são particulares e contingentes; não
porém, sobre o que é necessário, como a razão especulativa. Por onde, as leis humanas não podem ter
aquela infalibilidade que têm as conclusões demonstrativas das ciências. Nem é necessário seja toda
medida absolutamente infalível e certa, mas deve sê-lo enquanto isso lhe é genericamente possível.

## Art. 4 — Se é necessário haver uma lei divina.
(I, q. 1. a. 1; IIª-IIªª, q. 22, a. I, ad 1; III, q. 60, a. 5, ad 3; III Sent., dist. XXXVII, a. 1; In Psalm. XVIII; Ad
Galat., cap. III, lect. VII).
O quarto discute-se assim. — Parece que não é necessário haver nenhuma lei divina.

1. — Pois, como já se disse (a. 2), a lei natural é uma participação da lei eterna em nós. Ora, a lei eterna
é a lei divina, como já se disse (a. 1). Logo, não é necessário haver uma lei divina, além da natural e das
leis humanas dela derivadas.

2. Demais. — A Escritura diz (Sr 15, 14): Deus deixou o homem na mão do seu conselho. Ora, o conselho
é ato de razão, como já se estabeleceu (q. 14, a. 1). Logo, o homem foi deixado ao governo da sua razão.
Ora, o ditame da razão humana é a lei humana, como já se disse (a. 3). Logo, não é necessário seja o
homem governado por nenhuma lei divina.

3. Demais. — A natureza humana é mais capaz do que a das criaturas irracionais. Ora, as criaturas
irracionais não estão sujeitas a nenhuma lei divina, além da inclinação natural, que lhes é inerente.
Logo, com maior razão, não deve a criatura racional estar sujeita a qualquer lei divina, além da natural.
Mas, em contrário, David pede a Deus que lhe imponha uma lei, dizendo (Sl 118, 33): Impõe-me por lei,
Senhor, o caminho das tuas justificações.

SOLUÇÃO. — Além da lei natural e da humana, é necessário, para a direção da vida humana, haver uma
lei divina. E isto por quatro razões. — Primeiro, porque pela lei o homem dirige os seus atos em ordem
ao fim último. Ora, se ele se ordenasse só para um fim que lhe não excedesse a capacidade das
faculdades naturais, não teria necessidade de nenhuma regra racional, superior à lei natural e à humana
desta derivada. Mas como o homem se ordena ao fim da beatitude eterna, excedente à capacidade
natural das suas faculdades, como já estabelecemos (q. 5, a. 5), é necessário que, além da lei natural e
da humana, seja também dirigido ao seu fim por uma lei imposta por Deus. — Segundo, da incerteza do
juízo humano, sobretudo no atinente às coisas contingentes e particulares, originam-se juízos diversos
sobre atos humanos diversos;donde, por sua vez, procedem leis diversas e contrárias. Portanto, para
poder o homem, sem nenhuma dúvida, saber o que deve fazer e o que deve evitar, é necessário dirija os
seus atos próprios pela lei estabelecida por Deus, que sabe não poder errar. — Terceiro, porque o
homem só pode legislar sobre o que pode julgar. Ora, não pode julgar dos atos internos, que são
ocultos, mas só dos externos, que aparecem. E contudo, a perfeição da virtude exige que ele proceda
retamente em relação a uns e a outros. Portanto, a lei humana, não podendo coibir e ordenar
suficientemente os atos internos, é necessário que, para tal, sobrevenha a lei divina. — Quarto, porque,
como diz Agostinho, a lei humana não pode punir ou proibir todas as malfeitorias. Pois, se quisesse
eliminar todos os males, haveria conseqüentemente de impedir muitos bens, impedindo assim a
utilidade do bem comum, necessário ao comércio humano. Por onde, afim de nenhum mal ficar sem ser
proibido e permanecer impune, é necessário sobrevir a lei divina, que proíbe todos os pecados. —
E essas quatro causas estão resumidas no salmo, que diz o seguinte (Sl 118, 8): A lei do Senhor que é
imaculada, i. é, que não permite a torpeza de nenhum pecado; converte as almas, porque regula, não só
os atos externos, mas também os internos; o testemunho do Senhor é fiel, por causa da certeza da
verdade e da retitude; e dá sabedoria aos pequeninos, ordenando o homem a um fim sobrenatural e
divino.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pela lei natural, o homem participa da lei eterna,
proporcionalmente à capacidade da sua natureza. Mas importa que, de modo mais alto, seja levado ao
fim último e sobrenatural. E por isso se lhe acrescenta a lei dada por Deus, pela qual a lei eterna é
participada de modo mais elevado.

RESPOSTA À SEGUNDA. — O conselho é uma perquisição e, portanto, há de proceder de certos
princípios. Não basta porém que proceda de princípios naturalmente ínsitos, que são os da lei natural,
pelas razões já expostas. Mas é necessário que outros se lhes acrescentem e tais são os preceitos da lei
divina.

RESPOSTA À TERCEIRA. — As criaturas irracionais não se ordenam a um fim mais elevado do que o
proporcionado à capacidade natural delas. Logo, a comparação não colhe.

## Art. 5 — Se há só uma lei divina.
(Infra, q. 107, a. I; Ad Galat., cap. I, lect. II).
O quinto discute-se assim. — Parece que a lei divina é uma só.

1. — Pois, no mesmo reino, só uma é a lei do rei. Ora, todo o gênero humano está para Deus como para
um rei, conforme àquilo da Escritura (Sl 46, 8): Deus é o rei de toda a terra. Logo, há uma só lei divina.

2. Demais. — Toda lei se ordena ao fim que o legislador visa relativamente aqueles para os quais legisla.
Ora, em relação aos homens, Deus visa uma mesma coisa, segundo a Escritura (1 Tm 2, 4): Quer que
todos os homens se salvem, e que cheguem a ter o conhecimento da verdade. Logo, só uma é a lei
divina.

3. Demais. — A lei divina parece estar mais próxima da lei eterna, que é una, do que a lei natural, por ser
mais elevada a revelação dá graça do que o conhecimento da natureza. Ora, a lei natural é a mesma
para todos os homens. Logo, Com maior razão, a lei divina.
Mas, em contrário, diz o Apóstolo (Heb 7, 12): Mudado que seja o sacerdócio, é necessário que se faça
também mudança da lei. Ora, como no mesmo lugar se diz, duplo é o sacerdócio: o levítico e o de Cristo.
Logo, também dupla há de ser a lei divina; a antiga e a nova.

SOLUÇÃO. — Como já dissemos na Primeira Parte (q. 30, a. 3), a distinção é a causa do número. Ora, de
dois modos podem as coisas se distinguir. — De um, quando absoluta e especificamente diversas, como
o cavalo e o boi. — De outro, como o perfeito se distingue do imperfeito, dentro da mesma espécie;
assim, a criança, do homem. Ora, é deste modo que a lei divina se distingue em lei antiga e nova. Por
onde, o Apóstolo (Gl 3, 24-25) compara o estado da lei antiga ao da criança dirigida por um mestre; e o
da lei nova, ao do homem perfeito, que já não precisa de mestre.
Ora, a perfeição e imperfeição da lei se fundam nas suas três funções, já antes expostas. — Assim,
primeiramente, pertence à lei ordenar para o bem comum, como para o fim, segundo já dissemos (q.
90, a. 2). E esse bem pode ser duplo. Um é o bem sensível e terreno, ao qual ordenava diretamente a lei
antiga. Por isso, logo no princípio dela, o povo é convidado ao reino terrestre dos cananeus. O outro é o
bem inteligível e celeste, ao qual ordena a lei nova. Por isso, Cristo, logo no princípio da sua pregação,
convida para o reino dos céus, dizendo (Mt 4, 17): Fazei penitência, porque está próximo o reino dos
céus. Donde o dizer Agostinho, que as promessas das coisas temporárias estão contidas no Antigo
Testamento, que, por isso, se chama antigo; ao passo que a promessa da vida eterna pertence ao Novo
Testamento. Em segundo lugar, à lei pertence dirigir os atos humanos conforme à ordem da justiça. No
que também a lei nova extravaga da antiga, ordenando os atos internos da alma, conforme àquilo da
Escritura (Mt 5, 20): Se a vossa justiça não for maior e mais perfeita do que a dos Escribas e dos Fariseus,
não entrareis no reino dos céus. E, por isso se diz, que a lei antiga coíbe as mãos, a nova, a alma. — Em
terceiro lugar, à lei pertence levar os homens à observância dos mandamentos. E isto, que a lei antiga
fazia, pelo temor das penas, a nova o faz pelo amor, infundido em nossos corações pela graça de Cristo,
conferida na lei nova, e figurada apenas, na antiga. Donde o dizer Agostinho: O temor e o amor, eis a
breve diferença entre a Lei e o Evangelho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na casa o pai de família propõe uma ordem aos filhos e
outra, aos adultos. Assim também o mesmo rei, Deus, dá, no seu reino, uma lei aos homens, que ainda
vivem na imperfeição, e outra, mais perfeita, aos que pela lei anterior chegaram à capacidade maior das
coisas divinas.

RESPOSTA À SEGUNDA. — A salvação dos homens não podia vir senão de Cristo, conforme à Escritura
(At 4, 12): Nenhum outro nome foi dado aos homens pelo qual nós devamos ser salvos. Por onde, a lei,
que perfeitamente conduz todos à salvação, não podia ser dada senão depois do advento de Cristo. Mas
antes dela, era necessário fosse dada ao povo, do qual Cristo havia de nascer, uma lei preparatória para
recebê-lo, em que já se achassem contidos certos rudimentos da justiça salvífica.

RESPOSTA À TERCEIRA. — A lei natural dirige o homem por certos preceitos gerais, em que convêm
tanto os perfeitos como os imperfeitos. Por isso é a mesma para todos. Ao passo que a lei divina o dirige
mesmo em certas particularidades, em que os perfeitos não se comportam do mesmo modo que os
imperfeitos. Por isso, a lei tinha que ser dupla, como ficou dito.

## Art. 6 — Se há uma lei constituída pelo estímulo da sensualidade.
(Infra. q. 93. a. 3; Ad Rom., cap. VII. lect. IV).
O sexto discute-se assim. — Parece que não há uma lei constituída pelo estímulo da sensualidade.

1. — Pois, como diz Isidoro, a lei consiste na razão. Ora, o estímulo da sensualidade, longe de consistir
na razão, desvia dela. Logo, não tem a natureza de lei.

2. Demais. — Toda lei é obrigatória, de modo que são considerados transgressores os que não a
observam. Ora, não é transgressor quem não se submete ao estímulo da sensualidade, mas, ao
contrário, quem lhe obedece. Logo, ele não tem natureza de lei.

3. Demais. —A lei se ordena para o bem comum, como já se disse (q. 90, a. 2). Ora, o estimulo da
sensualidade não inclina para esse bem, mas antes, para o particular. Logo, não tem natureza de lei.
Mas, em contrário, diz a Escritura (Rm 7, 23): Sinto nos meus membros outra lei, que repugna à lei do
meu espírito.

SOLUÇÃO. — Como já dissemos (a. 2; q. 90, a. 1 ad 1), a lei está essencialmente no sujeito que regula e
mede; e, participativamente, no que é medido e regulado. De modo que toda inclinação ou ordenação,
existente em quem está sujeito à lei, chama-se lei participativamente, como do sobredito resulta (a. 2;
q. 90, a. 1 ad 1). Ora, de duas maneiras pode existir uma inclinação nos súbditos da lei, provinda do
legislador. Ou porque este neles causa diretamente uma inclinação e inclina, às vezes, diversos para atos
diversos; podendo-se, deste modo, dizer que uma é a lei dos soldados e outra, a dos mercadores. Ou,
indiretamente, quando o legislador, destituindo um seu súbdito de uma dignidade, falo, por
conseqüência, passar para outra ordem, ficando como que sujeito a outra lei. Assim, o soldado,
destituído da milícia, ficará sujeito à lei dos lavradores ou dos mercadores.
Assim, pois, sob Deus legislador, criaturas diversas têm inclinações naturais diversas, de modo que
aquilo que para uma é, de certo modo, lei, para outra é contrário à lei. Por exemplo, ser bravo é de
certo modo a lei do cão; mas é contra a lei da ovelha ou de outro animal de índole mansa. Ora, a lei do
homem, que lhe coube por ordenação divina, de acordo com a sua condição, é obrar de conformidade
com a razão. E tanta força tinha essa lei, no estado primitivo, que nada de preterracional ou de irra-
cional podia surpreender o homem. Mas quando ele se afastou de Deus, incorreu na pena de ser
arrastado pelo ímpeto da sensualidade. O que se dá com cada um em particular, quanto mais se afastar
da razão; que, assim, de certo modo se assemelha aos brutos, levados pelo ímpeto da sensualidade,
conforme àquilo da Escritura (Sl 48, 21):O homem, quando estava na honra, não o entendeu: foi
comparado aos brutos irracionais, e se fez semelhante a eles. Por onde, a inclinação mesma de sensuali-
dade, chamada estímulo, tem nos brutos, absolutamente, natureza de lei; do modo, porém, porque, em
relação a eles se pode falar em lei no sentido de inclinação direta. Ao contrário, relativamente ao
homem, essa inclinação não tem natureza de lei, sendo antes, um desvio da lei da razão. Mas, por ter
sido o homem, pela justiça divina, destituído da justiça original, e perdido o vigor da razão, o ímpeto
mesmo da sensualidade, que o arrasta, tem natureza de lei, mas penal e, por lei divina, inseparável do
homem, destituído da dignidade que lhe era própria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procede quanto ao estímulo da sensualidade,
em si mesmo considerado, e como inclinação para o mal. Pois, em tal sentido, não tem natureza de lei,
como já se disse, ao passo que a terá enquanto resultante da justiça da lei divina. Tal como se
disséssemos ser lei que a um nobre, por sua culpa, se permitisse ser submetido a obras servis.

RESPOSTA À SEGUNDA. — A objeção colhe quanto à lei como regra e medida; pois, assim, os que dela
desviam vêem a ser transgressores. Mas, nesse sentido, o estímulo da sensualidade não é uma lei mas,
sim, por uma certa participação, como já se disse.

RESPOSTA À TERCEIRA. — A objeção colhe relativamente ao estímulo da sensualidade, quanto à sua
inclinação própria; não porém, quanto à sua origem. E contudo, considerada a inclinação da
sensualidade, tal como existe nos brutos, ela se ordena para o bem comum, i. é, para a conservação da
natureza da espécie ou do indivíduo. O que também se dá com o homem, desde que a sensualidade
esteja sujeita à razão. — Mas se chama estímulo da sensualidade na medida em que foge à ordem da
razão.