# Questão 16: Do uso.
Em seguida devemos tratar do uso.
E sobre esta Questão quatro artigos se discutem:

## Art. 1 — Se usar é ato da vontade.
(I Sent., dist. I, q. 1, a . 2).
O primeiro discute-se assim. ― Parece que usar não é ato da vontade.

1. ― Pois, como diz Agostinho, usar consiste em referir uma coisa à obtenção de outra. Ora, isto
pertence à razão, à qual é próprio referir e ordenar. Logo, usar é ato da razão e não da vontade.

2. Demais. ― Damasceno diz: o homem, primeiro, move-se à operação e depois, usa. Ora, agir pertence
à potência executiva; o ato da vontade porém não se segue ao da potência executiva, antes, a execução
é que vem em último lugar. Logo, o uso não é ato da vontade.

3. Demais. ― Agostinho diz: Todas as coisas foram feitas para uso do homem, porque julgando, a razão,
que lhe foi dada, usa de todas. Ora, julgar das coisas criadas por Deus, pertence à razão especulativa,
que é totalmente distinta da vontade, princípio dos atos humanos. Logo, usar não é ato da vontade.
Mas, em contrário, diz Agostinho: Usar é servir-se de uma coisa ao alvitre da vontade.

SOLUÇÃO. ― O uso de uma coisa importa na aplicação dessa coisa a alguma operação; e por isso se
chama usar de uma coisa a operação à qual a aplicamos; assim cavalgar é usar do cavalo e bater é usar
de um bastão. Ora, à operação aplicamos não só os princípios internos de ação, a saber, as potências
mesmas da alma ou os membros do corpo ― p. ex., o intelecto, para inteligir e os olhos, para verem ―
mas também as coisas exteriores, p. ex., o bastão para bater. Ora, é manifesto que não aplicamos a
qualquer operação as coisas exteriores, senão por meio dos princípios intrínsecos, que são potências da
alma, ou hábitos das potências, ou órgãos, que são membros do corpo. Como já se demonstrou porém,
a vontade é a que move aos seus atos as potências da alma; e isso é aplicá-las à operação. Por onde, é
manifesto que usar, primária e principalmente, é próprio da vontade como primeiro motor; da
inteligência porém como dirigente; das outras potências, enfim, como executoras, que estão para a
vontade, que as aplica à ação, como os instrumentos, para o agente principal. Propriamente porém, a
operação não se atribui ao instrumento mas, ao agente principal; assim, a edificação se atribui ao
operário e não, aos instrumentos. Por onde é manifesto que usar propriamente é ato da vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Sem dúvida a razão refere uma coisa à outra; mas a
vontade tende para essa coisa referida pela razão. E neste sentido, diz-se que usar é referir uma coisa à
outra.

RESPOSTA À SEGUNDA. ― Damasceno fala do uso enquanto pertence às potências executivas.

RESPOSTA À TERCEIRA. ― A própria razão especulativa é aplicada pela vontade à operação do inteligir
ou de julgar. E portanto, diz-se que o intelecto especulativo usa enquanto que, como as outras
potências executivas, é movido pela vontade.

## Art. 2 — Se usar convém aos brutos.
O segundo discute-se assim. ― Parece que usar convém aos brutos.

1. ― Pois, fruir é mais nobre que usar, porque, como diz Agostinho, o que usamos referimos ao que
vamosgoza. Ora, fruir convém aos brutos, como já se disse. Logo, com maior razão o usar.

2. Demais. ― Usar é aplicar os membros para agir. Ora, os animais fazem tal, pois usam dos pés para
andar e dos chifres para chifrar. Logo, aos brutos convém o usar.
Mas, em contrário, diz Agostinho: Só o animal dotado da razão é que pode usar das coisas.

SOLUÇÃO. ― Como já se disse, usar é aplicar um princípio de ação para agir, assim como consentir é
aplicar o movimento apetitivo para desejar alguma coisa, conforme ficou estabelecido. Ora, só o ser que
tem livre arbítrio sobre outro é que pode aplicar este último a um terceiro; ora, esse arbítrio só o tem o
ser que sabe referir uma coisa à outra, o que pertence à razão. Por onde, só o animal racional pode
consentir e usar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Fruir implica o movimento absoluto do apetite para o
apetível; ao passo que usar implica esse movimento para uma coisa que se refere à outra. Se pois
compararmos o usar e o fruir, quanto aos seus objetos, este é mais nobre que aquele, pois, o
absolutamente desejável é melhor que aquilo que só relativamente o é. Se os compararmos porém,
quanto à virtude apreensiva precedente, maior nobreza requer o uso, porque ordenar uma coisa a outra
é próprio da razão; absolutamente falando, porém, também o sentido pode apreender uma realidade.

RESPOSTA À SEGUNDA. ― Os animais usam de seus membros por instinto natural e não por
conhecerem a relação deles com as suas operações. Por onde, não se diz propriamente, que aplicam os
membros à ação nem que deles usam.

## Art. 3 — Se o uso pode ter por objeto também o fim último.
O terceiro discute-se assim. ― Parece que o uso pode ter por objeto também o fim último.

1. ― Pois, diz Agostinho, Todo o que frui, usa. Ora, também se frui do fim último. Logo, dele também se
usa.

2. Demais. ― Usar é tomar uma coisa conforme a quer a vontade, como se diz no mesmo passo. Ora, a
vontade não quer nada mais fortemente que o fim último. Logo, o uso pode tê-lo como seu objeto.

3. Demais. ― Hilário diz, que a eternidade está no Pai, a espécie na Imagem, i. é, no Filho, o uso no Dom,
i. é, no Espírito Santo. Ora, este sendo Deus, é o fim último. Logo, o uso pode ter como objeto o fim
último.
Mas, em contrário, como diz Agostinho, ninguém tem o direito de usar de Deus, mas só de fruí-lo. Ora,
só Deus é o fim último. Logo, deste não se pode usar.

SOLUÇÃO. ― Usar, como já se disse, importa na aplicação de uma coisa a outra. Ora, a coisa aplicada
para a consecução de outra tem natureza de meio. Por onde, o uso sempre recai sobre os meios; e por
isso as coisas acomodadas ao fim se chamam úteis, denominando-se às vezes uso a própria utilidade.
Devemos porém considerar, que fim último é empregado em duplo sentido: absoluta e relativamente.
Pois, o fim designa, conforme já se disse, ora, uma realidade mesma, ora a obtenção ou o uso dela.
Assim, o fim do avarento é o dinheiro ou a posse dele. Por onde é manifesto que, absolutamente
falando, o fim último é a realidade mesma, pois a posse do dinheiro não é boa senão por causa do bem
que é o dinheiro. Mas, relativamente ao sujeito, a obtenção do dinheiro é o fim último, pois não o busca
o avarento senão para possuí-lo. Logo, absoluta e propriamente falando, frui do dinheiro quem o erige
em fim último; e o goza quem o refere à posse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho se refere ao uso, comumente, enquanto
implica uma ordenação do fim à fruição mesma, que ele comporta e que é procurada.

RESPOSTA À SEGUNDA. ― A vontade quer o fim para descansar nele; por onde, esse descanso mesmo,
no fim, chamado fruição, é denominado por isso uso do fim. Os meios porém a vontade os quer, não
somente para os usar em vista do fim, mas relativamente a outra realidade na qual repousa.

RESPOSTA À TERCEIRA. ― Nas palavras de Hilário, uso significa repouso no fim último, no sentido em
que se diz comumente falando, que alguém usa do fim para obtê-lo, conforme já se disse. Donde o dizer
Agostinho, que dá o nome de uso ao amor, à deleitação, à felicidade ou beatitude.

## Art. 4 — Se o uso precede a eleição.
O quarto discute-se assim. ― Parece que o uso precede a eleição.

1. ― Pois, à eleição segue-se somente a execução. Ora, o uso pertencendo à vontade, precede à
execução. Logo, precede também à eleição.

2. Demais. ― O absoluto é anterior ao relativo; portanto, o mesmo relativo é anterior ao mais relativo.
Ora, a eleição implica duas relações: uma a do meio escolhido com o fim; outra com o meio preferido. O
uso porém implica uma relação só com o fim. Logo é anterior à eleição.

3. Demais. ― A vontade usa das outras potências, movendo-as. Ora, movendo-se também a si mesma,
como já se disse, ela usa também de si, aplicando-se à ação. Ora, isto o faz quando consente. Logo, o
uso está no consentimento mesmo; e, como este precede à eleição, conforme já se disse, também o uso
a precede.
Mas, em contrário, diz Damasceno: a vontade, após a eleição, lança-se na ação e dela usa.

SOLUÇÃO. ― A vontade tem dupla relação com o objeto. Uma pela qual este nela está, de algum modo,
em virtude de certa proporção ou ordem que há de uma para o outro. Por isso se diz que as coisas
naturalmente proporcionadas a um fim naturalmente o desejam. Porém tal posse do fim é imperfeita; e
como todo o imperfeito tende para a perfeição, tanto o apetite natural como o voluntário tendem à
posse real do fim, o que é possuí-lo perfeitamente. E esta é a segunda relação da vontade com o objeto.
Ora, o objeto querido não é só o fim, mas também os meios; e o último termo da primeira relação da
vontade com estes é a eleição, na qual se completa a proporção da vontade, para que completamente
queira os meios. Por onde é manifesto que o uso se segue à eleição, tomando-se uso no sentido em que
a vontade emprega a potência executiva, movendo-ª Como porém a vontade move de certo modo
também a razão e dela usa, pode-se entender por uso dos meios a consideração da razão pela qual ela
os refere ao fim. E neste sentido, o uso precede a eleição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A moção pela qual a vontade leva a execução precede à
execução mesma; é consecutiva porém à eleição. E assim, pertencendo o uso a essa moção da vontade,
é meio termo entre a eleição e a execução.

RESPOSTA À SEGUNDA. ― O relativo por essência é posterior ao absoluto. Não é porém necessário que
seja posterior o sujeito ao qual se atribuem as relações. Ao contrário, quanto mais prioridade tiver a
causa, tanto mais relações terá com maior número de efeitos.

RESPOSTA À TERCEIRA. ― A eleição precede o uso se ambos se referirem à mesma realidade. Mas nada
impede que o uso de uma coisa precede à eleição de outra. E como os atos da vontade refletem-se
sobre si próprios, em qualquer deles pode-se achar o consentimento, a eleição e o uso. Por exemplo,
quando se diz que a vontade consente na sua eleição, consente no seu consentimento e usa de si para
consentir e escolher. E sempre, desses atos, terão prioridade os que forem ordenados a algo de
anterior.