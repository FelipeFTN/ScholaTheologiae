# Questão 63: Da causa das virtudes.
Em seguida devemos tratar da causa das virtudes.
E sobre esta questão, quatro artigos se discutem:

## Art. 1 — Se a virtude existe em nós por natureza.
(Supra. q. 55, a. 1 ; I Sent., disto XVII, q. 1. a 3 ; II disto XXXIX. q. 2. a. 1 ; IIIª, dist. XXXIII, q. 1, a. 2. q. 1 ;
De Verit., q. II, a. I ; De Virtut., q. 1, a. 8; II Ethic., lect. 1).
O primeiro discute-se assim. — Parece que a virtude existe em nós por natureza.

1. — Pois, diz Damasceno: As virtudes são naturais e existem igualmente em todos. E Antonio: Se a
vontade mudar a natureza haverá perversidade. Conserve-se a condição e haverá virtude. E sobre aquilo
da Escritura (Mt 4, 23): Jesus rodeava ensinando, etc. — diz a Glosa: Ensina as virtudes naturais, a saber:
a justiça, a castidade, a humildade, que o homem possui naturalmente.

2. Demais. — O bem da virtude é existir de acordo com a razão, como do sobredito resulta. Ora, o que é
segundo a razão é bem natural, pois a razão é a natureza do homem. Logo, a virtude neste existe por
natureza.

3. Demais. — Chama-se natural ao existente em nós desde o nosso nascimento. Ora, isto se dá com
certas virtudes, pois, diz a Escritura (Jó 31, 18): Porque desde a minha infância cresceu comigo a
comiseração, e do ventre de minha mãe saiu comigo. Logo, a virtude existe em nós por natureza.
Mas, em contrário. — O existente em nós por natureza é comum a todos, e não o perdemos pelo
pecado, porque os bens naturais permanecem, mesmo nos demônios, como diz Dionísio. Ora, a virtude
não existe em todos os homens e se perde pelo pecado. Logo, neles não existe por natureza.

SOLUÇÃO. — Sobre as formas corpóreas uns disseram que elas têm procedência totalmente intrínseca,
quase admitindo uma existência oculta delas. Outros, que essa procedência é totalmente extrínseca,
como se proviessem de alguma causa separada. Outros, enfim, que a procedência em parte, é
intrínseca, enquanto preexistem potencialmente na matéria; e, em parte, extrínseca, quando
atualizadas pelo agente.
Assim também alguns ensinaram que as ciências e as virtudes têm procedência totalmente extrínseca,
de modo que todas naturalmente preexistem na alma, e que a disciplina e o exercício eliminam os
obstáculos que a elas se opõem; assim como a ação da lima clarifica o ferro, obstáculos esses que se
apresentam à alma provenientes do pesadume do corpo. E esta foi à opinião dos Platônicos. — Outros,
por seu lado, disseram que têm procedência totalmente extrínseca, i. é, por influência da inteligência
agente, como quer Avicena. — Outros, por fim, ensinaram que, quanto à aptidão, a ciência e a virtude
existem em nós por natureza; não porém quanto à perfeição, como diz o Filósofo. E esta opinião é mais
verdadeira.
E para prová-lo manifestamente, devemos considerar que o vocábulo natural pode ser aplicado ao
homem em duplo sentido: por natureza específica e por natureza individual, Ora, todos os seres se
especificam pela sua forma e se individualizam pela matéria. E como a forma do homem é a alma
racional, e a matéria, o corpo, o que lhe convém à alma racional lhe é especificamente natural; e o que
lhe é natural pela determinada compleição do corpo, há de lho ser pela natureza individual. Mas o
natural ao homem, corporal e especificamente há de referir-se de certo modo à alma, enquanto um
determinado corpo é proporcionado a uma determinada alma.
Ora, de um e de outro modo, a virtude é natural ao homem, por uma certa incoação. Por natureza
específica, enquanto na sua razão existem naturalmente certos princípios, naturalmente conhecidos,
tanto do que ele pode saber como do que pode praticar, e que são como sementeiras das virtudes
intelectuais e morais; e enquanto existe na vontade um apetite natural do bem racional. Por outro lado,
quanto à natureza individual, enquanto uns têm melhor ou pior disposição corpórea para certas
virtudes; e isto porque certas potências sensitivas são atos de certas partes do corpo, e a disposição
delas ajuda ou impede os atos das mesmas, e por conseqüência as potências racionais, a que essas
potências sensitivas servem. Por isso tem um aptidão natural para a ciência, outro, para a fortaleza, e
um terceiro para a temperança. E é deste modo que tanto as virtudes intelectuais como as morais por
uma certa aptidão incoativa existem em nós por natureza. Não porém de maneira consumada, porque a
natureza é determinada a um só termo e a consumação dessas virtudes não se dá por um só, mas por
diversos modos de agir, conforme as diversas matérias sobre que versam as virtudes e conforme as
diversas circunstâncias.
Por onde é claro que as virtudes existem naturalmente em nós, quanto à aptidão e a incoação delas; não
porém quanto à perfeição, exceto as virtudes teológicas de procedência totalmente extrínseca.
E daqui constam com clareza as RESPOSTAS ÀS OBJEÇÕES. — Pois, as duas primeiras colhem, enquanto
existem em nós, por termos natureza, sementeiras de virtudes. — A terceira procede enquanto que, por
disposição natural do corpo, que vem desde o nascimento, um tem natural compassivo, outro, para
viver temperadamente e outro, para outra virtude.

## Art. 2 — Se as virtudes podem ser causadas em nós pelas obras habituais.
(Supra, q. 51, a. 2; II Sent., disto XLIV, q. 1, a. 1, ad 6; III, dist. XXXIII. q. 1, a. 2, qª 2 ; De Virtut., q. 1, a. 9;

II Ethic., lect. 1).
O segundo discute-se assim. — Parece que as virtudes não podem ser causadas em nós pelas obras
habituais.

1. — Pois sobre aquilo da Escritura (Rm 14, 23) — Tudo o que não é segundo a fé é pecado — diz a
Glosa:Toda a vida dos infiéis é pecado, e nada é bom senão o sumo bem. Onde falta o conhecimento da
verdade, a virtude é falsa, mesmo com ótimos costumes. Ora, a fé não pode ser adquirida pelas obras,
mas é causada em nós por Deus, segundo aquilo da Escritura (Ef 2, 8): Pela graça é que sois salvos,
mediante a fé. Logo, não podemos adquirir nenhuma virtude pelas obras habituais.

2. Demais. — O pecado, sendo contrário à virtude, não é compatível com ela. Ora, o homem não pode
evitar o pecado senão pela graça de Deus, conforme o dito da Escritura (Sb 8, 21): Eu sabia que de outra
maneira não podia ter continência, se Deus me a não desse. Logo, também nenhuma virtude pode ser
causada em nós pelas obras habituais, mas só por dom de Deus.

3. Demais. — Não há a perfeição da virtude em atos que são desta desprovidos. Ora, o efeito não pode
ser superior à causa. Logo, a virtude não pode ser causada pelos atos que a precedem.
Mas, em contrário, Dionísio diz que o bem é mais virtuoso que o mal. Ora, os maus atos causam hábitos
viciosos. Logo, com maior razão, os atos bons podem causar hábitos virtuosos.

SOLUÇÃO. — Da geração dos hábitos pelos atos, em geral, já tratamos. Agora porém de modo especial
devemos tratar da virtude, que, como já dissemos, aperfeiçoa o homem para o bem. Ora, como o bem
consiste, por essência, em modo, espécie e ordem, conforme diz Agostinho; ou em número, peso e
medida, como diz a Escritura (Sb 11, 21), é necessário consideremos o bem do homem relativamente a
uma regra. E esta, é dupla, como já dissemos: a razão humana e a lei divina. E como esta é a regra
superior, tem maior extensão; de modo que tudo o regulado pela razão humana o é também pela lei
divina, mas não inversamente.
Logo, a virtude do homem, ordenada para o bem que recebe o seu modo pela regra da razão humana,
pode ser causada pelos atos humanos, enquanto tais atos procedem da razão, de cujo poder e regra
depende o referido bem. — Mas a virtude que ordena o homem para o bem determinado pela lei
divina, e não pela razão humana, não pode ser causada pelos atos humanos, cujo princípio é a razão;
mas é causado em nós só por obra divina. E por força desta noção de virtude é que Agostinho introduzia
na definição de virtude: que Deus obra em nós sem nós.
E em relação à virtude, neste sentido, A PRIMEIRA OBJEÇÃO colhe.

RESPOSTA À SEGUNDA. — A virtude divinamente infusa, sobretudo considerada em sua perfeição, não
se compadece com nenhum pecado mortal; mas a adquirida humanamente pode ser compatível com
um ato pecaminoso, mesmo mortalmente. Porque o uso do nosso hábito está sujeito à nossa vontade,
como já dissemos. Ora, um ato pecaminoso não destrói o hábito da virtude adquirida, pois, um hábito
não é diretamente contrariado por um ato, mas por outro hábito. E portanto, embora o homem, sem a
graça, não possa evitar o pecado mortal, de modo que nunca peque mortalmente, não fica impedido
entretanto de poder adquirir o hábito da virtude, pelo qual se abstenha, na maioria dos casos, das más
obras, e sobretudo das mais contrárias à razão. Há porém, certos pecados mortais que, sem a graça, o
homem de nenhum modo pode evitar, e são os que diretamente se opõem às virtudes teologais, que
existem em nós por dom da graça. E disto se dirá mais manifestamente a seguir.

RESPOSTA À TERCEIRA. — Como já dissemos, preexistem em nós, por natureza, certas sementes ou
princípios das virtudes adquiridas. E esses princípios são mais nobres que as virtudes adquiridas por
meio deles, assim como o intelecto dos princípios especulativos é mais nobre que a ciência das
conclusões; e a retidão natural da razão, do que a retificação do apetite, que se faz pela participação da
razão e pertence à virtude moral. Assim pois, os atos humanos, enquanto procedentes de princípios
mais altos, podem causar as virtudes humanas adquiridas.

## Art. 3 — Se além das virtudes teologais, há em nós outras infundidas por Deus.
(Supra, q. 51, a. 4; III Sent., dist. XXXIII, q.1, a. 2, qª 3; De Virtut., q. 1, a. 10) .
O terceiro discute-se assim. — Parece que além das virtudes teologais não há em nós outras virtudes
infundidas por Deus.

1. — Pois, o que podem fazer as causas segundas não o faz Deus imediatamente, senão às vezes
miraculosamente, porque como diz Dionísio, a lei da divindade é governar as coisas últimas pelas
médias. Ora, as virtudes intelectuais e morais podem ser causadas em nós pelos nossos atos, como já se
disse. Logo, não é conveniente sejam em nós causadas por infusão.

2. Demais. — Nas obras de Deus, muito mais que nas da natureza, nada há de supérfluo. Ora, para nos
ordenar ao bem sobrenatural bastam às virtudes teologais. Logo, não há, além dessas, virtudes
sobrenaturais, causadas em nós por Deus.

3. Demais. — A natureza, e com maior razão Deus, não fazem por dois meios o que podem fazer só por
um. Ora, Deus infundiu em nossa alma germens das virtudes, como diz a Glosa (Heb 1, 15-16). Logo, não
é necessário cause em nós por infusão outras virtudes.
Mas, em contrário, diz a Escritura (Sb 8, 7): Ensina a temperança e a justiça, a prudência e a fortaleza.

SOLUÇÃO. — É necessário sejam os efeitos proporcionados às suas causas e aos seus princípios. Ora,
todas as virtudes, tanto as intelectuais como as morais, adquiridas pelos nossos atos, procedem de
certos princípios naturais preexistentes em nós, como já dissemos. Em lugar desses princípios naturais
Deus nos dá as virtudes teologais, pelas quais nos ordenamos a um fim sobrenatural, conforme já se
disse. Por onde, é necessário que também a essas virtudes teologais correspondam proporcionalmente
outros hábitos causados em nós por Deus, que estão para as virtudes teologais como as morais e
intelectuais para os princípios naturais das virtudes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Seguramente certas virtudes morais e intelectuais
podem ser causadas em nós pelos nossos atos; mas, não são proporcionadas às virtudes teologais. E
portanto é necessário haver em nós outras que lhes sejam proporcionadas e causadas imediatamente
por Deus.

RESPOSTA À SEGUNDA. — As virtudes teologais nos ordenam suficientemente a um fim sobrenatural,
por uma certa inclinação, e de maneira imediata no que respeita a Deus mesmo. Mas, é necessário que
a alma, por outras virtudes infusas, se aperfeiçoe no tocante a outras coisas, mas ordenando-se para
Deus.

RESPOSTA À TERCEIRA. — A virtude dos princípios naturalmente infusos não ultrapassa a capacidade da
natureza. E portanto, para ordenar-se a um fim sobrenatural, o homem precisa ser aperfeiçoado por
outros princípios acrescentados.

## Art. 4 — Se virtudes infusas diferem especificamente das adquiridas.
(III Sent., dist. XXXIII, q. 1, a. 2,qª. 4 ; De Virtut., q. 1, a. 10, ad 7. 8, 9; q. 5. a. 4).
O quarto discute-se assim. — Parece que as virtudes infusas não diferem especificamente das
adquiridas.

1. — Pois, pelo que já se disse, parece que a virtude adquirida não difere da infusa senão pela relação
com o último fim. Ora, os hábitos e os atos humanos se especificam, não pelo fim último, mas pelo fim
próximo. Logo, as virtudes morais ou intelectuais infusas não diferem especificamente das adquiridas.

2. Demais. — Os hábitos se conhecem pelos atos. Ora, a temperança infusa e a adquirida dependem do
mesmo ato que é moderar a concupiscência do tato. Logo, não diferem especificamente.

3. Demais. — A diferença entre a virtude adquirida e a infusa se funda no que é imediatamente feito por
Deus e pela criatura. Ora, o homem que Deus formou é especificamente o mesmo que é gerado pela
natureza, assim como os olhos que deu ao cego de nascença são os mesmos que os produzidos por uma
força formativa. Logo, a virtude adquirida é especificamente idêntica à infusa.
Mas em contrário. — A mudança de qualquer diferença, que entra na definição, diversifica a espécie.
Ora, na definição da virtude infusa diz-se: que Deus obra em nós, sem nós, como já se estabeleceu.
Logo, a virtude adquirida, de que não se pode dizer tal, não é especificamente a mesma que a infusa.

SOLUÇÃO. — Os hábitos se distinguem especificamente de dois modos. — De um, como já dissemos,
pelas noções especiais e formais dos objetos. Ora, o objeto de qualquer virtude é bem relativo à matéria
própria dela; assim, o objeto da temperança é o bem dos prazeres relativos à concupiscência do tacto; e,
de um lado, a noção formal desse objeto provém da razão, que estabelece o modo para essa
concupiscência; e, de outro, a sua noção material é a proveniente dessa mesma concupiscência. Ora, é
manifesto que o modo imposto a essa concupiscência pela regra da razão humana e pela regra divina
corresponde a noções diversas. Assim, ao passo que para o uso dos alimentos, a razão lhe impõe um
modo em virtude do qual não podem ser nocivos à saúde do corpo nem impedir o ato da razão, a regra
da lei divina exige que o homem castigue o seu corpo e o reduza à servidão (1 Cor 9, 27), pela
abstinência da comida, da bebida e de causas semelhantes. Por onde é claro que a temperança infusa
difere especificamente da adquirida. E o mesmo se dá com as outras virtudes.
De outro modo, os hábitos se distinguem especificamente aquilo para o que se ordenam. Assim, a saúde
do homem não é especificamente a mesma que a do cavalo, por causa das naturezas diversas a que
uma e outra se ordena. E, do mesmo modo, diz o Filósofo, que as virtudes dos cidadãos são diversas
conforme se relacionam devidamente com as diversas formas de governo. E, desta maneira, as virtudes
morais infusas, pelas quais os homens se ordenam convenientemente para virem a ser cidadãos dos
santos e domésticos de Deus (Ef 2, 19), diferem especificamente das virtudes adquiridas pelas quais o
homem se ordena convenientemente para as coisas humanas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A virtude infusa difere da adquirida, quanto ao ordenar-
se não só para o último fim, mas também para os objetos próprios, como dissemos.

RESPOSTA À SEGUNDA. — A temperança adquirida e a infusa impõem modos diferentes à
concupiscência dos prazeres do tacto, como dissemos. Logo, não recaem sobre o mesmo ato.

RESPOSTA À TERCEIRA. — O olho do cego de nascença Deus o fez para o mesmo ato para o qual formou
a natureza os demais olhos; e portanto é da mesma espécie que estes. E o mesmo se daria se Deus
quisesse causar no homem milagrosamente virtudes que ele adquire pelos seus atos. Mas não é assim
que o entende a objeção.