# Questão 104: Dos preceitos judiciais.
Em seguida devemos tratar dos preceitos judiciais. E primeiro, devemos considerá-los em comum.
Segundo, as suas razões.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se a razão dos preceitos judiciais está em se ordenarem ao próximo.
(Supra, q. 99, a. 4).
O primeiro discute-se assim. — Parece que a razão dos preceitos judiciais não está em se ordenarem
ao próximo.

1. — Pois, os preceitos judiciais eram assim chamados por causa do juízo. Ora, há muitos outros
preceitos por que se o homem ordena para o próximo, e não pertencem à ordenação dos juízos. Logo,
não se chamam preceitos judiciais aqueles pelos quais o homem se ordena para o próximo.

2. Demais. — Os preceitos judiciais distinguem-se dos morais, como já se disse (q. 99, a. 4). Ora, há
muitos preceitos morais por que o homem se ordena para o próximo, como o demonstram os da
segunda tábua. Logo, os preceitos judiciais não se chamam assim por se ordenarem ao próximo.

3. Demais. — Os preceitos cerimoniais estão para Deus, como os judiciais, para o próximo, conforme se
disse (q. 99 a. 4; q. 101, a. 1). Ora, entre os preceitos cerimoniais, certos respeitam à pessoa mesma,
como as observâncias sobre os alimentos e as vestes, de que já se tratou (q. 102, a. 6 ad 1, 6). Logo, os
preceitos judiciais não se chamam assim por ordenarem o homem para o próximo.
Mas, em contrário, diz a Escritura, referindo-se às outras boas obras do varão justo (Ez 18, 8): se fizer um
verdadeiro juízo entre homem e homem. Ora, os preceitos judiciais são assim chamados por causa do
juízo. Logo, assim se chamam os que dizem respeito à ordenação dos homens uns para os outros.

SOLUÇÃO. — Como do sobredito resulta (q. 95, a. 2; q. 99, a. 4), certos preceitos de qualquer lei têm
força obrigatória, em virtude de um ditame da razão, pela razão natural ditar seja tal ato praticado ou
evitado. E esses preceitos se chamam morais, por na razão se fundarem os costumes humanos. — Há
outros preceitos sem força obrigatória em virtude do ditame mesmo da razão. Porque, em si mesmos
considerados, não implicam em absoluto a noção de obrigação ou não-obrigação; mas têm força de
obrigar em virtude de alguma instituição divina ou humana. E tais são certas determinações dos
preceitos morais.
Se portanto forem determinados preceitos morais, por instituição divina, relativos à ordenação do
homem para Deus, esses preceitos se chamarão cerimoniais. Se relativos à ordenação dos homens uns
para os outros, chamar-se-ão judiciais. Logo, dois fundamentos têm a razão dos preceitos judiciais:
concernirem à ordenação dos homens uns para os outros; e terem força obrigatória fundada, não só na
razão, mas na instituição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os juízos se exercem por ofício de chefes com o poder
de julgar. Ora, ao príncipe pertence não só ordenar sobre os litígios, mas também sobre os contratos
voluntários dos homens entre si, e de tudo o atinente à comunidade do povo e ao regime. Por onde, os
preceitos judiciais não são somente os concernentes às lides judiciais, mas todos os que respeitam à
ordenação mútua dos homens, sujeita à ordenação do príncipe como juiz supremo.

RESPOSTA À SEGUNDA. — A objeção colhe quanto aos preceitos, que ordenam para o próximo, com
força obrigatória pelo só ditame da razão.

RESPOSTA À TERCEIRA. — Mesmo em relação ao que se ordena para Deus, há certos preceitos morais,
que a razão dita, informada pela fé. Assim, que devemos amar e adorar a Deus. Outros preceitos, porém
são cerimoniais e não têm força obrigatória senão por instituição divina. Ora, a Deus pertencem não só
os sacrifícios, que lhe são oferecidos, mas tudo o concernente à idoneidade dos oferentes e dos que o
cultuam; pois, o homem se ordena para Deus como para o fim. Portanto, o culto de Deus de par com os
preceitos cerimoniais exige uma certa idoneidade para o culto divino. — Ao contrário, o homem não se
ordena para o próximo, como para o fim, de modo que devesse por essência dispor-se ordenadamente
para o próximo; pois seria relação de escravos para senhor, fundada em pertencerem, por aquilo
mesmo que são, ao senhor, segundo o Filósofo. E portanto, não há preceitos judiciais que ordenem o
homem para si mesmo; mas todos os preceitos dessa natureza são morais. Pois, a razão, princípio da
moralidade, desempenha no homem, em relação ao que lhe diz respeito, o mesmo papel que, na
cidade, o príncipe ou o juiz. Deve-se porém saber, que a ordenação do homem para o próximo está mais
sujeita à razão do que a do homem para Deus. Por isso, são em maior número os preceitos morais
ordenadores do homem para o próximo, do que aqueles que o ordenam para Deus. E assim havia de
conter a lei mais preceitos cerimoniais que judiciais.

## Art. 2 — Se os preceitos judiciais são figurativos.
(Art. Seq.; IIª-IIªª, q. 87, a.1).
O segundo discute-se assim. — Parece que os preceitos judiciais não são figurativos.

1. — Pois, parece próprio dos preceitos cerimoniais serem figurativos de alguma instituição. Se
portanto, os preceitos judiciais também fossem figurativos, não difeririam dos cerimoniais.

2. Demais. — Assim como aos judeus, assim também aos gentios foram dados certos preceitos judiciais.
Ora, os preceitos judiciais dos outros povos nada figuravam, mas só ordenavam o que devia ser feito.
Logo, parece que também os preceitos judiciais da lei antiga nada figuravam.

3. Demais. — Era necessário dar a entender por figuras o pertencente ao culto divino, porque as coisas
de Deus são superiores à nossa razão. Ora, o que respeita ao próximo não a excede. Logo, os preceitos
judiciais, que nos ordenam para o próximo, nada deviam figurar.
Mas, em contrário, é que na Escritura, os preceitos judiciais são expostos alegórica e moralmente.

SOLUÇÃO. — De dois modos pode um preceito ser figurativo — Primariamente e em si mesmo, quando
foi principalmente instituído para ter alguma significação. E deste modo, os preceitos cerimoniais são
figurativos; pois, foram instituídos para figurar o pertencente ao culto de Deus e ao mistério de Cristo.
— Outros preceitos porém são figurativos, não primariamente e em si mesmos, mas por conseqüência.
E deste modo, os preceitos judiciais da lei antiga são figurados. Certo, não foram instituídos para figurar
nada; mas para ordenar o estado do povo judeu segundo a justiça e a eqüidade. Por conseqüência,
porém, eram figurativos, porque todo o estado desse povo, regulado por esses preceitos, era figurativo,
conforme a Escritura (1 Cor 10, 11): Todas estas coisas lhes aconteciam a eles em figura.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os preceitos cerimoniais são figurativos de modo
diferente dos judiciais, como já se disse.

RESPOSTA À SEGUNDA. — O povo judeu foi escolhido de Deus para dele nascer Cristo. Por isso, todo o
estado desse povo havia de ser profético e figurativo, como diz Agostinho. E por isso também, os
preceitos judiciais, que lhe foram dados, são mais figurativos do que os dados aos outros povos. Assim
também, as guerras e os feitos desse povo se entendem misticamente;não porém as guerras ou os
feitos dos assírios ou dos romanos, embora, humanamente falando, sejam muito mais famosos.

RESPOSTA À TERCEIRA. — A ordenação para o próximo, no povo judeu, em si mesma considerada era
accessível à razão. Mas enquanto referida ao culto de Deus, a superava, sendo por aí, figurativa.

## Art. 3 — Se os preceitos judiciais da lei antiga implicam obrigação perpétua.
(Infra, q. 108. a. 2; IIª-IIªª, q. 87, a. 1: IV Sent., dist. XV, q. 1 a. 5, qª 2, ad 5 Quodl. II, q. 4., a. 3; IV, q. 8, a.
2; Ad Hebr., cap. VII. Lect. II).
O terceiro discute-se assim. — Parece que os preceitos judiciais da lei antiga implicam obrigação
perpétua.

1. — Pois, os preceitos judiciais pertencem à virtude da justiça;porque juízo se chama à execução da
justiça. Ora, a justiça é perpétua e imortal, como diz a Escritura (Sb 1, 15). Logo, a obrigação dos
preceitos judiciais é perpétua.

2. Demais. — As instituições divinas são mais estáveis que as humanas. Ora, os preceitos judiciais das
leis humanas obrigam perpetuamente. Logo, com maior razão, os da lei divina.

3. Demais. — O Apóstolo diz (Heb 7, 18): O mandamento primeiro é na verdade abrogado pela sua
fraqueza e inutilidade. O que é verdadeiro dos mandamentos cerimoniais, que não podiam purificar a
consciência do que sacrificava, por meio somente de manjares e bebidas e de diversas abluções e
justiças da carne, como diz o mesmo Apóstolo (Heb 9, 9-10). Mas os preceitos judiciais eram úteis e
eficazes para aquilo ao que se ordenavam, i. é, para constituir a justiça e a eqüidade entre os homens.
Logo, os preceitos judiciais da lei antiga não são rejeitados, mas vigem até agora.
Mas, em contrário, diz o Apóstolo (Heb 7, 12): mudado que seja o sacerdócio, é necessário que se faça
também mudança da lei. Ora, o sacerdócio foi transferido de Aarão para Cristo. Logo, também toda a lei
foi mudada. Logo, os preceitos judiciais não obrigam ainda agora.

SOLUÇÃO. — Os preceitos judiciais não implicaram obrigação perpétua, e por isso foram anulados com
o advento de Cristo. Porém, de modo diferente por que o foram os cerimoniais. Pois, estes o foram de
modo a não só ficarem sendo letra morta, mas ainda mortíferos para os que os observarem, depois de
Cristo, sobretudo depois da divulgação do Evangelho. Ao passo que os preceitos judiciais são, por cedo,
letra morta, por não terem força de obrigar, mas não são mortíferos. Assim, príncipe, que mandasse
observá-los no seu reino não pecaria, salvo se fossem observados ou se mandasse que o fossem, como
tendo força obrigatória, em virtude da instituição da lei antiga. Pois, essa intenção de observá-los seria
mortífera. E a razão dessa diferença pode ser encontrada no que já ficou dito (a. 2). Pois, como
dissemos, os preceitos cerimoniais são figurativos, primariamente e em si mesmos, como tendo sido
principalmente instituídos para figurar os mistérios futuros de Cristo. Portanto, a observância mesmo
deles prejudica à verdade da fé, pela qual confessamos esses mistérios já se terem cumprido. Ao passo
que os preceitos judiciais não foram instituídos para figurar, mas para dispor o estado do povo judeu,
que se ordenava para Cristo. Por onde, mudado o estado desse povo, com o advento de Cristo, os
preceitos judiciais perderam a força obrigatória; pois a lei era um pedagogo conducente a Cristo, como
diz o Apóstolo (Gl 3, 24). Como porém esses preceitos judiciais não se ordenavam a figurar, mas a levar
à prática de certos atos, a observância deles, absolutamente, não prejudica a verdade da fé. A intenção
porém, de observá-los como lei obrigatória prejudica à referida verdade, por daí se concluir que o
estado do povo judeu ainda dura, e que Cristo ainda não veio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A justiça, certo, há de ser observada perpetuamente;
mas a determinação do que é justo, por instituição humana ou divina, há de necessariamente variar
segundo os diversos estados dos homens.

RESPOSTA À SEGUNDA. — Os preceitos judiciais instituídos pelos homens obrigam perpetuamente,
enquanto permanecer o regime. Mas se a cidade ou o povo passar para outro regime, por força as leis
hão-se de mudar. Pois, as mesmas leis não convêm à democracia, que é o governo do povo, e à
oligarquia, que é o dos ricos, como está claro no Filósofo. E portanto, mudado o primitivo estado do
povo judeu, haviam necessariamente de mudar-se os preceitos judiciais.

RESPOSTA À TERCEIRA. — Os preceitos judiciais dispunham o povo para a justiça e a eqüidade, na
medida em que isso era possível ao estado dos judeus. Mas depois de Cristo, esse estado teve de
mudar-se, de modo que no regime da lei cristã não haveria distinção entre gentios e judeus, como havia
antes. E por isso, era forçoso se mudassem também os preceitos judiciais.

## Art. 4 — Se os preceitos judiciais podem ter divisão certa.
O quarto discute-se assim. — Parece que os preceitos judiciais não podem ter nenhuma divisão certa.

1. — Pois, os preceitos judiciais ordenavam os homens uns para os outros. Ora, sendo infinitas as coisas
de que os homens necessitam e precisavam de ordenar, entre si, elas não podem depender de nenhuma
distinção certa. Logo, os preceitos judiciais não podem ter divisão certa.

2. Demais. — Os preceitos judiciais são determinações dos morais. Ora, estes não têm nenhuma divisão
senão enquanto se reduzem aos do decálogo. Logo, os preceitos judiciais não são susceptíveis de
nenhuma distinção certa.

3. Demais. — Dos preceitos cerimoniais, por serem susceptíveis de divisão certa, a lei indica uma certa
divisão, chamando a uns sacrifícios, e a outros, observâncias. Mas nenhuma distinção a lei indica entre
os preceitos judiciais. Logo, parece, não são susceptíveis de divisão certa.
Mas, em contrário. — Onde há ordem há de necessariamente haver distinção. Ora, a noção de ordem é
própria, sobretudo, dos preceitos judiciais, pelos quais se ordenava o povo judeu. Logo, devem ter, por
excelência, uma divisão certa.

SOLUÇÃO. — A lei é uma como arte para instituir e ordenar a vida humana. Ora, cada arte tem uma
certa divisão nas suas regras. Portanto, toda lei deve conter uma certa divisão nos seus preceitos; do
contrário, a confusão viria aniquilar-lhe a utilidade. Por onde devemos concluir, que os preceitos
judiciais da lei antiga, que ordenavam os homens uns para os outros, comportam uma distinção fundada
na da ordenação humana. Ora, em qualquer povo, podemos descobrir quádrupla ordem. Uma, a dos
chefes em relação aos súbditos; outra, a dos súbditos entre si; a terceira, a dos indivíduos desse povo
para com os estranhos; a quarta, a dos membros da sociedade doméstica, como a do pai para o filho, da
esposa para o esposo, do senhor para o escravo. E conforme a estas quatro ordens, podem se dividir os
preceitos judiciais da lei antiga. — Assim, ela estabeleceu certos preceitos sobre a constituição e o dever
dos chefes, e sobre o respeito a eles devido. E esta é uma parte dos preceitos judiciais. — Outras, sobre
as relações aos cidadãos entre si; como sobre a compra e venda, os julgamentos e as penas. E esta é a
segunda parte dos preceitos judiciais. — Outros, relativos aos estrangeiros; p. ex., sobre as guerras
contra os inimigos e o modo de receber os estranhos e os ádvenas. E esta é a terceira parte dos
preceitos judiciais. — Enfim, a lei estabeleceu certos preceitos sobre a sociedade doméstica, como os
relativos aos escravos, às mulheres e aos filhos. E esta é a quarta parte dos preceitos judiciais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os preceitos relativos à ordenação dos homens entre si
são, sem dúvida, em número infinito. Contudo, podem reduzir-se a um certo número deles, conforme à
diferença das ordenações humanas, como já se disse.

RESPOSTA À SEGUNDA. — Os preceitos do decálogo são os primeiros no gênero dos preceitos morais,
como já dissemos (q. 100, a. 3). Por onde, os outros preceitos morais se dividem relativamente a eles.
Os preceitos judiciais porém e os cerimoniais têm a sua força obrigatória fundada, não na razão natural,
mas na só instituição. Portanto, a divisão deles tem outra razão de ser.

RESPOSTA À TERCEIRA. — A lei indica a divisão dos preceitos judiciais pela matéria mesma que regulam.