# Questão 2: Em que consiste a beatitude do homem.
Em seguida devemos tratar da beatitude. Primeiro, no que consiste. Segundo, o que é. Terceiro, como
podemos alcançá-la.
Sobre o primeiro ponto, oito artigos se discutem:

## Art. 1 — Se a beatitude do homem consiste nas riquezas.
(III Cont. Gent., cap. XXX; I Ethic., lect. V).
O primeiro discute-se assim. — Parece que a beatitude do homem consiste nas riquezas.

1. — Pois, sendo a beatitude o fim último do homem, há de consistir no que soberanamente lhe atrai o
desejo. — Ora, tais são as riquezas, como diz a Escritura (Ecle 10, 19): Todas as coisas obedecem ao
dinheiro. Logo, nelas consiste a beatitude do homem.

2. Demais. — Segundo Boécio, a beatitude é o estado perfeito, pela reunião de todos os bens. Ora, com
o dinheiro pode-se obter tudo, pois a moeda foi inventada, no dizer do Filósofo, para ser como a fiança
com a qual o homem consiga tudo quanto quiser. Logo, a beatitude consiste nas riquezas.

3. Demais. — O desejo do sumo bem nunca sendo vão, há de ser infinito. Ora, isto soberanamente se dá
como o dinheiro, pois, como diz a Escritura (Ecle 5, 9), o avarento jamais se fartará de dinheiro. Logo,
nas riquezas consiste a beatitude.
Mas, em contrário. — O bem do homem consiste, antes em conservar do que em dissipar a beatitude.
Ora, como diz Boécio, as riquezas mais brilham gastas do que acumuladas: pois, a avareza sempre faz os
odiosos e a liberalidade, os gloriosos. Logo, nas riquezas não consiste a beatitude.

SOLUÇÃO. — É impossível a beatitude do homem consistir nas riquezas. Ora, há duas espécies delas,
como diz o Filósofo: as naturais e as artificiais. Aquelas são as que o homem busca para satisfazer suas
necessidades naturais, como a comida e a bebida, os vestuários, os transportes, a habitação e outras
semelhantes. Estas são as que não provêm da natureza, em si mesmas, como o dinheiro, mas que a arte
humana inventou para facilitar as trocas e são como a medida das coisas venais.
Ora, claro é que a beatitude do homem não pode consistir nas riquezas naturais. Pois, buscando-as ele
para outro fim, a saber, o sustento da sua vida, não lhe podem constituir o fim último, antes, para ele se
ordenam como fim delas. Por onde, na ordem da natureza, todas essas coisas são inferiores ao homem
e para ele feitas, conforme a Escritura (Sl 8, 7): Todas as coisas sujeitaste debaixo de seus pés.
Quanto às riquezas artificiais, elas não são buscadas senão por causa das naturais; pois, não o seriam se
com elas não se comprassem as coisas necessárias ao uso da vida. Logo, com maior razão, não podem
desempenhar o papel de fim último.
Por onde, é impossível consistir nas riquezas a beatitude, último fim do homem.

DONDE A RESPOSTA A PRIMEIRA OBJEÇÃO. — Todas as coisas corpóreas obedecem ao dinheiro, para o
sem número de estultos que só conhecem os bens materiais, susceptíveis de serem adquiridos com o
dinheiro. Ora, o juízo sobre os bens humanos não o devemos procurar entre os estultos, mas entre os
sábios; assim como o juízo sobre o sabor devemos aprendê-lo como os que têm o gosto são.

RESPOSTA À SEGUNDA. — Com dinheiro podem-se adquirir todos os bens venais, não porém os
espirituais, não susceptíveis de venda. Por isso, diz a Escritura (Pr 17, 16): De que serve ao insensato o
ter grandes riquezas, se ele não pode comprar com elas a sabedoria?

RESPOSTA À TERCEIRA. — O desejo das riquezas naturais não é infinito, porque bastam à natureza
numa certa medida. Mas o é o das artificiais porque serve à concupiscência desordenada, que se não
altera, como se vê claramente no Filósofo. Porém, o desejo infinito das riquezas e o desejo do sumo
bem diferem. Pois, quanto mais perfeitamente possuído o sumo bem, tanto mais é amado e tanto mais
se desprezam as outras coisas, porque, quanto mais possuído, mais conhecido; donde o dito da Escritura
(Ecl 24, 29): Aqueles que me comem terão ainda fome. E o contrário acontece com o desejo das riquezas
e de quaisquer bens temporais, que quando já possuídos, são desprezados, sendo outros os desejados,
como se exprime a Escritura (Jo 4, 13), quando o Senhor diz: Todo aquele que bebe desta água — como
o que se designam os bens temporais —tornará a ter sede. E isso por ser a insuficiência deles mais
conhecida quando possuídos. Por onde, isso mesmo põe-lhes a nu a imperfeição e o não poder consistir
neles o sumo bem.

## Art. 2 — Se a beatitude do homem consiste na honra.
(III Cont. Gent., cap. XXVIII; I Ethic., lect V).
O segundo discute-se assim. — Parece que a beatitude do homem consiste na honra.

1. — Pois, como diz o Filósofo, a beatitude ou felicidade é o prêmio da virtude. Ora, tal prêmio o é por
excelência a honra no dizer do mesmo Filósofo. Logo, nela consiste, por excelência a beatitude.

2. Demais. — O que principalmente convém a Deus e aos mais excelentes é a beatitude, bem perfeito.
Ora, tal é a honra, como diz o Filósofo e também a Escritura (1 Tm 1, 17): A Deus só seja honra e glória.
Logo, a beatitude consiste na honra.

3. Demais. — O maximamente desejado pelos homens é a beatitude. Ora, nada é mais desejável por
eles do que a honra; pois, suportam dano em tudo o mais, contanto que não padeçam nenhum
detrimento na honra própria. Logo, a beatitude consiste na honra.
Mas, em contrário. — A beatitude está em quem é feliz. Ora, a honra não está em quem é honrado, mas
antes, em quem honra, que presta reverência ao honrado, como diz o Filósofo. Logo, a beatitude não
consiste na honra.

SOLUÇÃO. — É impossível a beatitude consistir na honra. Pois, tributamos honra a alguém por alguma
excelência sua; e assim é o sinal e o testemunho dessa excelência em quem é honrado. Ora, a excelência
do homem se funda sobretudo na beatitude, que é dele o bem perfeito; e nas suas partes, i. é, naqueles
bens pelos quais algo se participa da beatitude. Por onde, a honra pode por certo resultar da beatitude,
mas esta não pode consistir principalmente naquela.

DONDE A RESPOSTA A PRIMEIRA OBJEÇÃO. — Como diz o Filósofo no mesmo passo, a honra não é o
prêmio da virtude, pelo qual mourejam os virtuosos; mas estes recebem daqueles como de quem nada
maior tivesse que dar, como prêmio. Mas o verdadeiro prêmio da virtude é a beatitude mesma, pela
qual mourejam os virtuosos. Se, pois, obrassem por causa da honra, já não haveria virtude, mas
ambição.

RESPOSTA À SEGUNDA. — A honra é devida a Deus e aos mais excelentes, como sinal ou testemunho da
excelência preexistente; mas não que, em si os torne excelentes.

RESPOSTA À TERCEIRA. — Do desejo natural da beatitude, resultante da honra, como se disse, provém
que os homens soberanamente a desejam. Por onde, procuram sobretudo ser honrados pelos virtuosos,
com cujo juízo se acreditam excelentes ou felizes.

## Art. 3 — Se a felicidade do homem consiste na glória.
(III Cont. Gent., cap. XXIX).
O terceiro discute-se assim. — Parece que a beatitude do homem consiste na glória.

1. — Pois, a beatitude consiste no que é atribuído aos santos em recompensa das tribulações sofridas no
mundo. Ora, tal é a glória, segundo diz a Escritura (Rm 8, 18): As penalidades da presente vida não têm
proporção alguma com a glória vindoura que se manifestará em nós. Logo, a beatitude consiste na
glória.

2. Demais. — Como se vê em Dionísio, o bem é difundido de si. Ora, pela glória principalmente é que o
bem do homem chega ao conhecimento dos outros, pois, como diz Ambrósio (Agostinho) ela não é
senão um conhecimento glorioso acompanhado de louvor. Logo, a beatitude do homem consiste na
glória.

3. Demais. — A beatitude é o mais estável dos bens. Ora, tal é a fama ou glória, pela qual os homens de
certo modo conseguem a eternidade. Donde o dizer Boécio: Mostrai-vos perpetuadores da vossa
imortalidade quando buscais a fama nos tempos futuros. Logo, a beatitude consiste na fama ou glória.
Mas, em contrário. — A beatitude é o verdadeiro bem do homem. Ora, a fama ou glória pode ser falsa;
pois, como diz Boécio, muitos conseguiram as falsas opiniões do vulgo, muitas vezes, um grande nome.
E que de mais torpe se pode pensar? Pois, os que são apregoados falsamente hão de eles próprios se
envergonhar dos seus louvores. Logo, a beatitude do homem não consiste na fama ou glória.

SOLUÇÃO. — É impossível a beatitude do homem consistir na fama ou glória humana. Pois, a glória não
é senão um conhecimento glorioso acompanhado de louvor, como diz (Agostinho) Ambrósio. Ora, a
causa conhecida se refere, de um modo, ao conhecimento humano, e de outro, ao divino; pois aquele é
causado pela coisa conhecida, e este é a causa desta. Por onde, a perfeição do bem humano, chamada
beatitude, não pode ser causada pelo conhecimento humano; mas antes, este procede da beatitude de
alguém e é, de certo modo, causado pela própria beatitude humana, incoada ou perfeita. E logo, na
fama ou na glória não pode consistir a beatitude do homem; mas o bem deste depende, como da causa,
do conhecimento de Deus. Portanto, da glória existente em Deus depende, como da causa, a beatitude
do homem, conforme aquilo da Escritura (Sl 90, 16): livrá-lo-ei e glorificá-lo-ei; saciá-lo-ei com
diuturnidade de dias e mostrar-lhe-ei o meu salvador.
Mas também devemos considerar, que o conhecimento humano muitas vezes falha, e sobretudo nos
singulares contingentes, como os atos humanos. Por onde, freqüentemente a glória humana é falaz.
Mas como Deus não pode enganar-se, a sua glória é sempre verdadeira, e por isso diz a Escritura (2 Cor
10, 18): O que é estimável é aquele a quem Deus recomenda.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Apóstolo não se refere, no passo aduzido, à glória
procedente dos homens, mas da que procede de Deus, em face dos seus anjos. Por isso diz o
Evangelho: O Filho do homem o confessará (na glória do seu Pai) ante os anjos de Deus.

RESPOSTA À SEGUNDA. — O bem de um homem, que está no conhecimento de muitos, pela fama ou
pela glória, se esse conhecimento for verdadeiro necessariamente há de derivar do bem nesse homem
existente, e então pressupõe a beatitude perfeita ou incoada. Se porém for falso, não concorda como o
objeto e então não existe o bem no que é celebrado pela fama. Por onde é claro que a fama de nenhum
modo pode tornar o homem feliz.

RESPOSTA À TERCEIRA. — A fama não tem estabilidade; antes, o falso rumor facilmente se perde; e se
por vezes perseverar estável, sê-lo-á por acidente. Ora, a beatitude tem por si e sempre a estabilidade.

## Art. 4 — Se a beatitude do homem consiste no poder.
(III Cont.Gent., cap. XXXI; Compend. Theol., part. II. cap. IX; De Regina. Princip., lib. I cap. VIII; In Matth.,
cap. V).
O quarto discute-se assim. — Parece que a beatitude consiste no poder.

1. — Pois, todos os seres desejam assimilar-se a Deus, último fim e princípio primeiro. Ora, os homens
que tem o poder, consideram-se, pela semelhança deste, semelhantes a Deus em máximo grau; por
isso, são chamados deuses na Escritura (Ex 22, 28): Não falarás mal dos deuses. Logo, a beatitude
consiste no poder.

2. Demais. — A beatitude é o bem perfeito. Ora, perfeitíssimo é que o homem também possa governar
os outros, o que convém aos constituídos no poder. Logo, a beatitude consiste no poder.

3. Demais. — A beatitude sendo soberanamente desejável opõe-se ao que se deve sobretudo evitar.
Ora, os homens evitam sobretudo a servidão, à qual se contrapõe o poder. Logo, a beatitude consiste no
poder.
Mas, em contrário. — A beatitude é o bem perfeito. Ora, o poder é soberanamente imperfeito. Pois,
como diz Boécio, o poder humano não pode excluir as apreensões dos cuidados nem evitar o aguilhão
dos temores. E ainda: Julgas poderoso o que é rodeado de satélites e que mais teme aqueles que
aterroriza? Logo, a beatitude não consiste no poder.

SOLUÇÃO. — É impossível a beatitude consistir no poder, por duas razões. — Primeiro, porque o poder
exerce a função de princípio, como se vê claro em Aristóteles; a beatitude, porém, de fim último. —
Segundo, porque o poder tanto se refere ao bem como ao mal, ao passo que a beatitude é o bem
perfeito e próprio do homem. Por onde, uma beatitude poderia consistir, mais, no bom uso do poder,
que supõe a virtude, do que no próprio poder.
Por fim, quatro razões gerais podem ser aduzidas para mostrar que em nenhum dos sobreditos bem
exteriores pode consistir a beatitude.
E a primeira é que, sendo a beatitude o sumo bem do homem, não se compadece com nenhum mal;
ora, todos os bens preenumerados podem-se encontrar tanto nos bons como nos maus.
A segunda razão é que, sendo da essência da beatitude bastar-se a si mesma, como se vê em
Aristóteles, necessário é que, uma vez alcançada não falte nenhum bem necessário ao homem. Ora,
obtido cada um dos bens, referidos até aqui, podem ainda faltar muitos outros necessários ao homem,
como a sabedoria, a saúde do corpo e outros.
A terceira é a seguinte. Sendo a beatitude o bem perfeito, dela não pode provir nenhum mal para
ninguém. Ora, isso não se dá com os referidos bens; pois como diz a Escritura (Ecle 5, 12), as riquezas às
vezes se conservam para mal de seu dono; e o mesmo se dá com as outras três espécies de bens.
A quarta razão é a seguinte. O homem ordenando-se à beatitude naturalmente, ordena-se por
princípios interiores; ora, os quatro bens aludidos provêm, antes, de causas exteriores e, muitas vezes,
da fortuna, donde vem o serem chamados bens da fortuna.
Por onde é claro que de nenhum modo a beatitude neles consiste.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O poder divino é idêntico à sua bondade, e por isso não
pode usar senão bem desta. Ora, tal não se dá com os homens. Por onde, não basta, para a beatitude,
que o homem se assemelhe com Deus pelo poder, se também não se lhe assemelhar pela bondade.

RESPOSTA Á SEGUNDA. — Assim como é ótimo alguém usar bem do poder, no governo do povo, assim
é péssimo usar mal; de modo que o poder tanto pode ser usado para o bem como para o mal.

RESPOSTA À TERCEIRA. — A servidão é um impedimento para o bom uso do poder, e por isso os
homens naturalmente, a fogem; mas daí não se deduz seja o poder o sumo bem do homem.

## Art. 5 — Se a beatitude do homem consiste nos bens do corpo.
(IV Sent., dist. XLIX, q. 1, a . 1, q ª 1; III Cont. Gent., cap. XXXII; Compend. Theol., part. II, cap. IX; I Ethic.,
lect. X).
O quinto discute-se assim. — Parece que a beatitude do homem consiste nos bens do corpo.

1. — Pois, diz a Escritura (Ecl 30, 16): Não há riquezas maiores do que as da saúde do corpo. Ora, a
beatitude consiste no que é ótimo. Logo, consiste na saúde do corpo.

2. Demais. — Dionísio diz que existir é melhor que viver, e viver, melhor que todos os mais bens. Ora, a
existência ou a vida do homem implica necessariamente a saúde do corpo. Sendo, pois a beatitude o
sumo bem do homem, resulta que ela implica sobretudo a saúde do corpo.

3. Demais. — Quanto mais comum for uma causa, tanto mais dependerá de um princípio mais alto,
porque quanto mais elevada for a causa tanto maior extensão terá a sua agência. Ora, assim como a
causalidade eficiente se considera relativamente à sua agência, assim a causalidade final relativamente
ao apetite. Logo, assim como a causa eficiente primeira é a que influi em tudo, assim o fim último é o
desejado de todos. Ora, a existência é o que soberanamente é desejado de todos. Logo, no que diz
respeito à existência do homem, como o é a saúde do corpo, consiste por excelência a beatitude.
Mas, em contrário, pela beatitude o homem é excelente sobre todos os animais. Ora, pelos bens do
corpo é ele superado por muitos; assim, pelo elefante, na diuturnidade da vida; pelo leão, na força; pelo
veado, na velocidade. Logo, a beatitude do homem não consiste nos bens do corpo.

SOLUÇÃO. — É impossível a beatitude do homem consistir nos bens do corpo, por duas razões. — A
primeira: é impossível que a conservação na existência de uma coisa ordenada para outra como para o
fim seja o seu último fim. Assim, o piloto não busca, como último fim, a conservação da nau que lhe foi
confiada, porque a nau é ordenada para outro fim, que é navegar. Assim, pois, como a nau é confiada ao
piloto para que a dirija, assim o homem é entregue à vontade e à sua razão, segundo aquilo da Escritura
(Ecl 15, 14): Deus criou o homem desde o princípio, e o deixou na mão do seu conselho. Ora, é
manifesto que o homem, não sendo o sumo bem, se ordena para algum fim outro. Por onde, é
impossível seja o fim último da razão e da vontade humana a conservação da existência humana. — A
segunda é a seguinte. Dado que o fim da razão e da vontade humana fosse a conservação da humana
existência, nem por isso se poderia dizer que o fim do homem fosse algum bem do corpo. Pois, o ser do
homem consiste em alma e corpo; e embora a existência do corpo dependa da alma, a existência desta,
contudo, não depende daquele, como já vimos antes. E este em si, existe para a alma, como a matéria
para a forma e os instrumentos para o motor, afim de por eles exercer a sua atividade. Por onde, todos
os bens do corpo se ordena aos da alma, como fim. E portanto é impossível consistir a felicidade, que é
fim último, nos bens do corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como o corpo se ordena para a alma, que é o seu fim,
assim os bens exteriores, para o corpo. Por onde, é racional seja o bem deste preferível aos bens
exteriores, que é o significado da expressão riquezas; do mesmo modo, o bem da alma é preferível a
todos os bens do corpo.

RESPOSTA À SEGUNDA. — Existir, em si mesmo considerado, encerrando toda a perfeição da existência,
tem preeminência sobre a vida e tudo o que dela se segue. E é esse o sentido em que fala Dionísio. Mas,
considerado o existir mesmo, enquanto participado por tal ou tal ser, que não encerram a perfeição
total da existência, mas a têm imperfeita, como acontece com qualquer criatura, então é manifesto que
o existir ao qual se acrescenta uma perfeição é mais eminente. Por onde, no mesmo passo, Dionísio diz,
que os seres vivos são melhores que os simplesmente existentes e os inteligentes, que os vivos.

RESPOSTA À TERCEIRA. — Como o fim corresponde ao princípio, a razão aduzida prova que o fim
último, que encerra toda a perfeição da existência, é o princípio primeiro do existir. E a semelhança com
ele os entes a buscam, cada um na medida da própria perfeição; assim, uns, só pelo existir; outros, pelo
viver; outros enfim, em menor número, pelo viver, pelo inteligir e pelo ser feliz.

## Art. 6 — Se a beatitude do homem consiste no prazer.
(IV Sent., dist. XLIV. q. 1 a . 3, q ª 4, ad 3, 4; III Cont. Gent., cap. XXVII, XXXIII; I Ethic., lect. V).
O sexto discute-se assim. — Parece que a beatitude do homem consiste no prazer.

1. — Pois a beatitude, sendo o fim último, não é desejada por outra coisa, senão as outras por ela. Ora,
tal se dá sobretudo, com o prazer; porquanto, como diz Aristóteles, é ridículo perguntar a alguém
porque quer deleitar-se. Logo, a beatitude consiste principalmente no prazer e nos deleites.

2. Demais. — A causa primeira produz impressão mais veemente que a segunda, como se diz no
livro Das Causas. Ora, a influência do fim é relativa ao desejo do mesmo. Por onde, tem a natureza de
fim último o que move principalmente o desejo; e tal é o prazer. E a prova é que o deleite absorve a
vontade e a razão do homem a ponto de fazer desprezar os outros bens. Donde se conclui que o fim
último do homem, que é a beatitude, consiste sobretudo no prazer.

3. Demais. — Como o desejo busca o bem, o que todos desejam há de ser ótimo. Ora, todos, sábios,
insipientes e mesmo os irracionais, buscam o deleite. Logo, este é ótimo, e portanto no prazer consiste a
beatitude, sumo bem.
Mas, em contrário, diz Boécio: Que são tristes as conseqüências dos prazeres, sabem-no todos os que
querem lembrar-se das suas sensualidades; pois, se estas pudessem fazer os felizes, nenhuma razão
haveria para que também os brutos não fossem considerados tais.

SOLUÇÃO. — Por serem as mais conhecidas de todas, as deleitações corpóreas receberam o nome de
prazer, como diz Aristóteles, embora haja outros prazeres mais fortes, nos quais todavia não consiste
principalmente a beatitude. Pois, uma coisa é o pertencente à essência de um ser, e outra o seu
acidente próprio; assim, uma coisa é ser o homem animal racional e outra, um animal que ri. Ora,
devemos considerar que toda deleitação é um acidente próprio que acompanha a beatitude, ou alguma
parte dela. Pois, deleita-se quem tem algum bem a si conveniente, na realidade, em esperança ou, pelo
menos, na memória. Ora, o bem conveniente perfeito é a beatitude mesma do homem; o imperfeito é
uma participação próxima, remota ou, pelo menos, aparente da beatitude. Por onde, é manifesto que
nem ainda a deleitação resultante do bem perfeito é a essência mesma da beatitude, mas algo que dela
procede, como acidentalmente.
Ora, do prazer corpóreo não pode, mesmo do modo já referido, resultar o bem perfeito; pois, resulta do
bem apreendido pelo sentido, virtude da alma que se serve do corpo. Ora, o bem pertencente ao corpo
e apreendido pelo sentido não pode ser o bem perfeito do homem. Pois, a alma racional, excedendo a
capacidade da matéria corpórea, a parte da alma independente do órgão corpóreo tem uma certa
infinidade em relação a esse mesmo corpo e às partes da alma a ele ligadas. Pois, o imaterial é de certo
modo infinito em relação ao material, porque a forma contrai-se, por assim dizer, e limita-se pela
matéria; por onde, a forma separada da matéria é de certo modo infinita. Por isso o sentido, potência
corporal, conhece o singular, determinado pela matéria; o intelecto porém, potência independente da
matéria, conhece o universal abstrato desta e contém em si infinitos singulares. Por onde, como é claro,
o bem conveniente ao corpo que causa, por apreensão do sentido, o prazer corpóreo não é o bem
perfeito do homem, antes, é mínimo em comparação com o bem da alma. Por isso diz a Escritura (Sb 7,
9), que todo o ouro em comparação com a sabedoria é um pouco de areia. Assim, pois, nem o prazer
corpóreo é a beatitude em si, nem é por si um acidente dela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A mesma razão por que se deseja o bem deseja-se o
prazer, que não é mais do que a quietação do apetite no bem; assim como pela mesma virtude da
natureza um peso é levado para baixo e aí repousa. Por onde, assim como o bem é desejado por si
mesmo, assim também o prazer o é, por si, e não por outra coisa, por significar causa final. Significando,
porém, causa formal, ou antes, motivo, então é apetível por outra coisa, i. é, por causa do bem, objeto
do prazer que lhe e por conseguinte o princípio e lhe dá a forma. Pois o prazer é apetecido porque é o
repouso no bem desejado.

RESPOSTA À SEGUNDA. — O apetite veemente do deleite sensível resulta de serem mais perceptíveis às
operações dos sentidos, princípio do nosso conhecimento. Donde vem o serem desejados de muitos os
deleites sensíveis.

RESPOSTA À TERCEIRA. — Todos desejam os prazeres do mesmo modo por que desejam o bem; e
contudo desejam o prazer em razão do bem, e não inversamente, como já se disse. Donde não se segue
que o prazer seja o bem máximo e em si mesmo; mas que cada prazer resulta de um bem e que algum
prazer resulta do bem máximo e em si.

## Art. 7 — Se a beatitude do homem consiste em algum bem da alma.
O sétimo discute-se assim. — Parece que a beatitude consiste em algum bem da alma.

1. — Pois, a beatitude é um dos bens do homem. Ora, estes se dividem em três classes: os bens
externos, os bens do corpo e os bens da alma. Ora, a beatitude não consiste nos bens externos, nem do
corpo, como já se demonstrou. Logo, consiste nos da alma.

2. Demais. — Mais amamos alguém do que o bem que lhe desejamos; assim, mais amamos o amigo a
quem desejamos o dinheiro, do que o dinheiro. Ora, todos desejam para si algum bem e, portanto
amam-se a si mesmo mais que todos os outros bens. Mas a beatitude é sumamente amada pois por ela
tudo o mais é amado e desejado. Logo, ela consiste em algum bem do próprio homem; e como não
consiste nos bens do corpo, há de por força consistir nos da alma.

3. Demais. — A perfeição é algo do ser aperfeiçoado. Ora, a beatitude é uma perfeição do homem. Logo,
é algo destes. Mas não pertence ao corpo, como já se demonstrou. Logo, pertence à alma, e assim
consiste nos bens desta.
Mas, em contrário, como diz Agostinho, aquilo que constitui a vida feliz deve ser amado por si. Ora, o
homem não deve ser amado por si mesmo; antes, tudo o que nele existe deve ser amado por Deus.
Logo, a beatitude não consiste em nenhum bem da alma.

SOLUÇÃO. — Como já se disse, o fim é considerado sob duplo aspecto: como a causa mesmo que
desejamos alcançar, e como o uso, a obtenção ou posse dela.
Se, pois consideramos o último fim do homem quanto à coisa mesmo desejada como último fim, é
impossível que este seja a alma ou algo dela.
Pois esta, em si considerada, é existente em potência; assim, de ciente, em potência, passa a ciente em
ato; de virtuosa em potência, para virtuosa em ato. Ora, sendo o ato como o complemento da potência,
é impossível o que é, em si, potencial, ter a natureza de último fim. Por onde, é impossível seja a alma
em si o último fim de si mesma. — Também não o pode ser nada dela, potencial, atual ou habitual. Pois
o bem, que é o último fim, é o bem perfeito que satisfaz o apetite. Ora, o apetite humano, que é a
vontade, deseja o bem universal. Mas qualquer bem inerente à alma mesma é bem participado, é por
conseqüência particularizado. Por onde, é impossível seja algum deles o último fim do homem.
Se considerarmos, porém, o último fim do homem quanto à obtenção mesma dele, à sua posse e a
qualquer uso da coisa mesma desejada como fim, então ao último fim pertence algo do homem, por
parte da alma, pois por esta é que o homem consegue a beatitude.
Aquilo, porém, que é desejado como fim, é o em que consiste a beatitude e faz feliz; e à consecução
disto chama-se beatitude.
Por onde, devemos concluir que a beatitude é algo da alma; mas o em que ela consiste é algo de
exterior à alma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na medida em que na divisão referida se compreendem
todos os bens apetíveis pelo homem, considera-se bem da alma, não só a potência, o hábito ou ato, mas
também o objeto, que é extrínseco. E deste modo nada impede considerar como um bem da alma o em
que consiste a beatitude.

RESPOSTA À SEGUNDA. — No caso vertente, a beatitude é amada, sobretudo como bem desejado; ao
passo que o amigo é amado como o a quem se deseja o bem; e assim também o homem se ama a si
mesmo. Por onde, um e outro amor não tem o mesmo fundamento. Se porém, pelo amor da amizade o
homem ama algo acima de si mesmo, isso se há de examinar quando se tratar de caridade.

RESPOSTA À TERCEIRA. — A beatitude, em si, sendo perfeição da alma, é um certo bem a esta inerente.
Mas o em que a beatitude consiste, i. é, em fazer feliz, é algo de exterior à alma, como já se disse.

## Art. 8 — Se a beatitude do homem consiste em algum bem criado.
(I. q. 12, a . 1; IV Cont. Gent., cap. LIV; Compend. Theol., part. I cap. CVIII; part. II. cap. IX; De Regim.
Princip., lib. I cap. VIII; In Psalm., XXXII)
O oitavo discute-se assim. — Parece que a beatitude do homem consiste em algum bem criado.

1. — Pois, como diz Dionísio, a divina sabedoria une os extremos das naturezas primárias aos princípios
das secundárias; donde, pode-se concluir, o que é sumo em a natureza inferior deve atingir o que, na
superior, é infinito. Ora, o sumo bem do homem é a beatitude. Sendo, pois o anjo, na ordem da
natureza, superior ao homem, como já vimos, resulta que a beatitude deste consiste em atingi-lo, de
certo modo.

2. Demais. — O fim último de uma coisa está na sua perfeição; por isso a parte é para o fim, que é o
todo. Ora, a universidade total das criaturas, chamada mundo maior, está para o homem, chamado
mundo menor, como o perfeito para o imperfeito. Logo, a beatitude do homem consiste na
universidade total das criaturas.

3. Demais. — O homem torna-se feliz quando satisfaz o seu desejo natural. Ora, este não se estende a
um bem maior que o que ele pode apreender. Não sendo ele pois capaz de um bem que exceda os
limites de toda criatura, resulta que pode se tornar feliz por meio de algum bem criado, no qual então
consiste a sua beatitude.
Mas, em contrário, diz Agostinho: como a alma é a vida do corpo, assim, a vida feliz do homem é Deus,
de quem diz a Escritura: Bem aventurado o povo que tem ao Senhor por seu Deus.

SOLUÇÃO. — É impossível a beatitude do homem consistir em algum bem criado. Pois esta é o bem
perfeito que repousa totalmente o apetite; do contrário, se algo ainda restasse a apetecer não seria ele
o fim último. Ora, o objeto da vontade, que é o apetite humano, é o bem universal, como o do intelecto
é a verdade universal. Donde resulta claro, que nada pode satisfazer a vontade do homem senão o bem
universal. Ora, disto não é capaz nenhum bem criado, mas só Deus, porque toda criatura tem a bondade
participada. Por onde, só Deus pode satisfazer a vontade do homem, conforme a Escritura (Sl 102, 5): O
que enche de bens o teu desejo. Logo, só em Deus consiste a beatitude dele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O que é superior no homem atingir, por certo, o que é
infinito na criatura Angélica, por certa semelhança; mas nem por isso aí repousa como no fim último,
mas prossegue até a fonte universal mesma do bem, objeto universal da beatitude de todos os felizes,
pois é o bem infinito e perfeito.

RESPOSTA À SEGUNDA. — Se um todo não é o último fim, mas se ordena a outro fim ulterior, então o
último fim da parte não é o todo mesmo, mas algum outro. Ora, a universalidade das criaturas, para a
qual o homem está como a parte para o todo, não é o último fim, mas se ordena para Deus, que o é. Por
onde, o bem do universo não é o último fim do homem, mas Deus mesmo.

RESPOSTA À TERCEIRA. — O bem criado não é inferior ao que é o bem, intrínseco e inerente à
capacidade do homem; porém o é ao bem infinito objeto dessa capacidade. Ora, o bem participado pelo
anjo e por todo o universo é um bem infinito e limitado.