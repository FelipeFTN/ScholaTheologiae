# Questão 39: Ou da bondade e da malícia da dor ou tristeza
Em seguida devemos tratar da bondade e da malícia da dor ou tristeza.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se toda tristeza é má.
(III Sent., dist. XV, q. 2, a. 2, qa 1, ad 3; IV, dist. XLIX, q. 3, a. 4, qa. 2).
O primeiro discute-se assim. — Parece que toda tristeza é má.

1. — Pois, diz Gregório Nissemo (Nemésio): Toda tristeza é por sua própria natureza má. Ora, o
naturalmente mau o é sempre e em toda parte. Logo, toda tristeza é má.

2. Demais — Aquilo de que todos, mesmos os virtuosos, fogem é mau. Ora, todos, mesmo os virtuosos,
fogem da tristeza, pois, como diz Aristóteles, embora o prudente não vise o deleitar-se, visa contudo
não contristar-se. Logo, a tristeza é um mal.

3. Demais — Assim como o mal corpóreo é objeto e causa da dor corpórea, o mal espiritual é objeto e
causa da tristeza espiritual. Ora, toda dor corpórea é mal do corpo. Logo, toda tristeza espiritual o é da
alma.
Mas, em contrário. — Entristecer-se com o mal é contrário a comprazer-se no mesmo. Ora, comprazer-
se no mal é mau, e por isso a Escritura, para a detestação de certos, deles diz (Pr 2, 14), que se alegram
depois de terem feito o mal. Logo, a tristeza por causa do mal não é má.

SOLUÇÃO. — De dois modos podemos dizer que uma coisa é boa ou má. — De um, absolutamente e em
si mesma. — E assim, toda tristeza é um mal; pois o mesmo inquietar-se do apetite do homem com o
mal presente implica a idéia do mal, porque impede o repouso desse apetite no bem. — De outro modo
diz-se que uma coisa é boa ou má por suposição de outra; assim dizemos que a vergonha é um bem por
suposição de algum ato torpe cometido, como diz Aristóteles. Por onde, suposto algo de contristador ou
de doloroso, é próprio da bondade fazer-nos contristar ou condoer do mal presente. E só poderíamos
não nos contristar ou não nos condoer ou porque não sentíssemos o mal ou porque não nô-lo
julgássemos repugnante, e em um e outro caso há mal manifesto. E portanto, a bondade faz com que,
suposta a presença do mal, se lhe siga a tristeza ou dor. E é o que diz Agostinho: E ainda é bom que o
bem perdido cause dor; pois, se não permanecesse algum bem em a natureza, não constituiria pena
nenhuma dor do bem perdido.
Mas, como as questões morais se referem ao singular, sobre o qual versam as operações, o bom por
suposição deve ser julgado bom, assim como é considerado voluntário o que o é por suposição,
conforme diz Aristóteles e já nós o demonstramos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Gregório Nisseno (Nemésio) fala da tristeza
relativamente ao mal contristante; não porém relativamente ao que o sente e o repele. Ora, neste
último caso também todos fogem a tristeza na medida em que fogem o mal; mas não fogem o
sentimento e a repulsão dele. E o mesmo devemos dizer da dor corpórea; pois, o sentimento e a repulsa
do mal corpóreo atestam uma natureza boa.
Donde se deduzem claras as RESPOSTAS À SEGUNDA E À TERCEIRA OBJEÇÕES.

## Art. 2 — Se a tristeza implica a noção de bem honesto.
(Infra, q. 59, a. 3; III, q. 15, a. 6 ad 2, 3; q. 46, a. 6, ad 2).
O segundo discute-se assim. — Parece que a tristeza não implica a noção de bem honesto.

1. ― Pois, o que conduz ao inferno é contrário ao honesto. Ora, diz Agostinho: Parece que Jacó temia
ser perturbado com tanta tristeza de modo a ir, não ao repouso dos bem-aventurados, mas ao inferno
dos pecadores. Logo, a tristeza não implica a noção de bem honesto.

2. Demais ― O bem honesto implica a noção de louvável e meritório. Ora, a tristeza diminui o louvor e o
mérito, pois, diz o Apóstolo (2 Cor 9, 7): Cada um como propôs no seu coração, não com tristeza nem
como por força. Logo, a tristeza não é um bem honesto.

3. Demais ― Como diz Agostinho, sofremos tristeza pelo que acontece contra a nossa vontade. Ora, não
querer aquilo que atualmente nos acontece é ter a vontade contrária à ordem divina, a cuja providência
está sujeito tudo o que acontece. Logo, sendo próprio da vontade reta o conformar-se com a vontade
divina, como já se disse, a tristeza é contrária à retidão da vontade. E assim não implica a noção de
honesto.
Mas, em contrário. ― Tudo o que merece o prêmio da vida eterna implica a noção de honesto. Ora, tal é
a tristeza, como está claro no Evangelho (Mt 5, 5): Bem-aventurados os que choram, porque eles serão
consolados.

SOLUÇÃO. ― Pelo modo por que a tristeza é um bem, ela pode ser um bem honesto. Pois, como já
dissemos, a tristeza é um bem relativamente ao conhecimento e à repulsa do mal. E tanto esta como
aquele, na dor corpórea, atestam a bondade da natureza, donde provém que o sentido sente e a
natureza evita o que lesa, e é causa da dor. Na tristeza interior porém, o conhecimento do mal é pelo
juízo reto da razão; e a repulsa, pela vontade bem disposta e que o detesta. Ora, todo bem honesto
procede destes dois elementos; da retidão da razão e da vontade. Por onde, é manifesto que a tristeza
pode implicar a noção de bem honesto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Todas as paixões da alma devem ser reguladas pela
regra da razão, que é a raiz do bem honesto, e que é ultrapassada pela tristeza imoderada, da qual fala
Agostinho. E, portanto, afasta-se da noção de honesto.

RESPOSTA À SEGUNDA. ― Assim como a tristeza causada pelo mal procede da vontade e da razão reta,
que o detesta; assim a tristeza causada pelo bem procede da razão e da vontade perversa, que o
detesta. Portanto, tal tristeza impede o louvor ou o mérito do bem honesto, como quando damos
esmola com tristeza.

RESPOSTA À TERCEIRA. ― Certas coisas como o pecado, acontecem atualmente não por vontade de
Deus, mas permitidas por ele. Por onde a vontade a que repugna o pecado atual, em si ou em outrem,
não discorda da vontade de Deus. Os males da pena, porém, existem atualmente, por vontade d´Ele.
Não é entretanto exigido, para a retidão da vontade que o homem os queira em si mesmos, mas só que
não contrarie a ordem da divina justiça, como já dissemos.

## Art. 3 — Se a tristeza pode ser um bem útil.
(III, q. 46, a. 6, ad 2).
O terceiro discute-se assim. ― Parece que a tristeza não pode ser um bem útil.

1. ― Pois, diz a Escritura (Ecle 30, 25): Porque a tristeza tem morto a muitos e não há utilidade nela.

2. Demais. ― A eleição recai sobre o que é útil a um fim qualquer. Ora, a tristeza não é susceptível de
eleição; pois devemos fazer a eleição, antes sem tristeza que com ela, como diz Aristóteles. Logo, a
tristeza não é um bem útil.

3. Demais. ― Cada ser é para a sua operação, como diz Aristóteles. Ora, como ele próprio também o diz,
a tristeza impede a operação. Logo, a tristeza não é um bem útil.
Mas, em contrário. ― O sábio só busca o útil. Mas, diz a Escritura (Ecle 7, 5): O coração dos sábios está
onde se acha a tristeza, e o coração dos insensatos onde se acha a alegria. Logo, a tristeza é útil.

SOLUÇÃO. ― O mal presente provoca duplo movimento apetitivo. Um, pelo qual o apetite é contrariado
por esse mal; e por este lado a tristeza não tem utilidade, porque o presente não pode deixar de o ser. O
segundo movimento provocado no apetite o leva a fugir e repelir o mal que contrista; e por este lado a
tristeza tem utilidade, se se refere a algo de que devemos fugir. Ora, de dois modos devemos fugir de
alguma coisa. ― Primeiro, quando esta, como o pecado, considerada em si mesma, tem contrariedade
com o bem; por onde, a tristeza causada pelo pecado é útil para evitá-lo, como diz o Apóstolo (2 Cor 7,
9): Agora folgo, não de vos haver entristecido, mas de que a vossa tristeza vos trouxe à penitência. ― De
outro modo, devemos fugir do que é, não em si mesmo, mau, mas ocasião do mal, e a que aderimos
excessivamente pelo amor, ou que nos precipitará em algum mal, como acontece com os bens
temporais. E neste sentido a tristeza causada pelos bens temporais pode ser útil, como diz a Escritura
(Ecle 7, 3): Melhor é ir à casa que está de luto do que à casa onde se dá banquete, porque naquela é um
advertido do fim de todos os homens. ― E portanto, a tristeza relativa a todos os males de que devemos
fugir é útil, pois se torna dupla a causa de os evitar. Porque, já o mal, em si, deve ser evitado; ademais
disso todos fogem a tristeza em si mesma, assim como todos desejamos o bem e o prazer que ele nos
causa. Por onde, assim como o prazer proporcionado pelo bem faz com que o busquemos mais
avidamente, assim a tristeza causada pelo mal leva-nos a fugi-lo mais veementemente. DONDE A

RESPOSTA À PRIMEIRA OBJEÇÃO. ― O passo aduzido da Escritura se refere à tristeza imoderada, que
absorve o ânimo; pois o imobiliza e impede evitar o mal, como já se disse.

RESPOSTA À SEGUNDA. ― Assim como o elegível vem a sê-lo menos, por causa da tristeza; assim o que
devemos evitar, ainda mais o devemos, pela mesma razão. E por este lado a tristeza é útil.

RESPOSTA À TERCEIRA. ― A tristeza causada por uma operação tolhe; mas a procedente da cessação da
mesma leva a operar mais intensamente.

## Art. 4 — Se a tristeza é o sumo mal.
O quarto discute-se assim. ― Parece que a tristeza é o sumo mal.

1. ― Pois, ao ótimo opõe-se o péssimo, como diz Aristóteles. Ora, há um certo prazer ótimo, e é o que
respeita a felicidade. Logo, há alguma tristeza que é o sumo mal.

2. Demais. ― A beatitude é o sumo bem do homem, porque é o seu último fim. Ora, ela consiste em
termos tudo o que queremos e em não querermos mais nada, como já dissemos. Logo, o sumo bem do
homem é a satisfação completa da sua vontade. Ora, a tristeza é causada pelo que acontece contra a
nossa vontade, como está claro em Agostinho. Logo, a tristeza é o sumo mal do homem.

3. Demais. ― Agostinho argumenta assim: Somos compostos de duas partes ― a alma e o corpo, sendo
este a inferior. Ora, o sumo bem é o que, na melhor parte é ótimo; e o sumo mal o que, na pior, é
péssimo. Ora, o que tem de ótimo a alma é a sabedoria; e o que tem de péssimo o corpo é a dor. Logo o
sumo bem do homem é saber e o sumo mal, sofrer a dor.
Mas, em contrário. ― A culpa é maior que a pena, como estabelecemos na primeira parte. Ora, a
tristeza ou dor respeita a pena do pecado, assim como gozar das coisas mutáveis é o mal da culpa. Pois,
diz Agostinho:Que se chama dor da alma senão o estar privado das coisas mutáveis, que gozava ou que
esperava gozar? E nisto consiste totalmente o chamado mal, i. é, o pecado e a pena do pecado. Logo, a
tristeza ou dor não é o sumo mal do homem.

SOLUÇÃO. ― É impossível seja qualquer tristeza ou dor o sumo mal do homem. Pois, toda tristeza ou
dor é causada por um verdadeiro mal ou por um mal aparente que é, na realidade, bem. Ora, a dor ou
tristeza provocada pelo verdadeiro mal não pode ser o sumo mal, pois há algo de pior que ela, a saber,
não considerar mal o que verdadeiramente o é, ou não lhe oferecer resistência. Por outro lado, a
tristeza ou dor causada pelo mal aparente, que é um verdadeiro bem, não pode ser o sumo mal, porque,
pior seria alheiar-mo-nos de todo do verdadeiro bem. Por onde, é impossível a tristeza ou dor ser o
sumo mal do homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Há dois bens comuns ao prazer e à tristeza, a saber: o
verdadeiro juízo sobre o bem e o mal, e a ordem devida da vontade que aprova aquele e rejeita este.
Por onde é claro que há, na dor ou tristeza, algum bem, cuja privação a tornaria pior; mas nem todo
prazer encerra um mal cuja remoção o tornasse melhor. E por isso há algum prazer capaz de ser o sumo
bem do homem, do modo pelo qual já dissemos; ao passo que a tristeza não lhe pode ser o sumo mal.

RESPOSTA À SEGUNDA. ― O mesmo repugnar da vontade ao mal é um bem. E por isso, a tristeza ou
dor não pode ser o sumo mal, por haver nela mescla de bem.

RESPOSTA À TERCEIRA. ― O nocivo ao melhor encerra maior mal do que o nocivo ao pior. Pois, chama-
se mal ao nocivo, como diz Agostinho. Por onde, o mal da alma é pior que o do corpo. E portanto, não
colhe o raciocínio introduzido por Agostinho, de acordo, não com o seu sentir, mas com o de outrem.