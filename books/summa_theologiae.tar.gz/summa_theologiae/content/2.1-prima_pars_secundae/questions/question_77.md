# Questão 77: Da causa do pecado por parte do apetite sensitivo: se a
paixão da alma é causa do pecado.
Em seguida devemos tratar da causa do pecado por parte do apetite sensitivo, se a paixão da alma é
causa do pecado.
E nesta questão, discutem-se oito artigos:

## Art. 1 — Se a vontade é movida pela paixão do apetite sensitivo.
(Supra, q. 9, a. 2 ; q. 10, a. 3 ; De Verit., q. 22, a. 9, ad 6).
O primeiro discute-se assim. ― Parece que a vontade não é movida pela paixão do apetite sensitivo.

1. ― Pois, nenhuma potência passiva é movida senão pelo seu objeto. Ora, a vontade é uma potência,
passiva e ativa ao mesmo tempo, enquanto motora e movida, como diz o Filósofo, em universal, a
respeito da potência apetitiva. E como o objeto da vontade não é a paixão do apetite sensitivo, mas
antes, o bem da razão, resulta que a paixão desse apetite não move a vontade.

2. ― Demais. ― O motor superior não é movido pelo inferior; assim como a alma não é movida pelo
corpo. Ora, a vontade, apetite racional, está para o apetite sensitivo, como o motor superior para o
inferior. Pois, segundo o Filósofo, o apetite racional move o sensitivo, assim como, nos corpos celestes,
uma esfera move outra. Logo, a vontade não pode ser movida pela paixão do apetite sensitivo.

3. ― Demais. ― Nada de imaterial, pode ser movido pelo material. Ora, a vontade é uma potência
imaterial, pois, sendo racional, não se serve de nenhum órgão material, como diz Aristóteles. Ao passo
que o apetite sensitivo é uma potência material, dependente, como é, de um órgão corpóreo. Logo, a
paixão do apetite sensitivo não pode mover o apetite intelectivo.
Mas, em contrário, diz a Escritura (Dn 13, 56): a concupiscência te perverteu o coração.

SOLUÇÃO. ― A paixão do apetite sensitivo não pode arrastar ou mover diretamente a vontade senão só
indiretamente. E isto de dois modos, dos quais o primeiro é por abstração. Pois, estando todas as
potências da alma radicadas na essência da mesma, necessariamente, quando uma exerce com
veemência o seu ato, as outras sofram remissão no seu, ou mesmo, sejam totalmente impedidas dele. E
isto, porque toda potência, capaz de muitos atos, torna-se remissa; donde e ao contrário, quando tende
com veemência para um só objeto torna-se-lhe menos possível produzir outros. Ou porque, operações
da alma exigem uma certa intensidade, e esta, aplicada veementemente a um objeto, não pode atender
a outro com a mesma veemência. E deste modo, por uma como distração, quando o movimento do
apetite sensitivo se fortifica, por uma determinada paixão, necessário é sofra remissão ou fique
totalmente impedido o movimento próprio à vontade, apetite racional.
De outro modo, por parte do objeto da vontade, que é o bem apreendido pela razão. Pois, o juízo e a
apreensão da razão ficam impedidos pela veemente e desordenada apreensão da imaginação e pelo
juízo da faculdade estimativa, como se vê claramente nos dementes. Ora, é manifesto, a apreensão da
imaginação e o juízo da estimativa dependem da paixão do apetite sensitivo, assim como a apreciação
do gosto depende da disposição da língua. Por isso notamos que os lesados por uma paixão não desviam
facilmente a imaginação do objeto do seu afeto. Portanto e conseqüentemente, o juízo da razão quase
sempre é consecutivo à paixão do apetite sensitivo; e, por conseguinte, também o movimento da
vontade, ao qual é natural obtemperar sempre ao juízo da razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A paixão do apetite sensitivo causa imutação no juízo
relativo ao objeto da vontade, como já se disse, embora a paixão mesma do apetite sensitivo não seja
diretamente objeto da vontade.

RESPOSTA À SEGUNDA. ― O superior não é movido pelo inferior, diretamente; mas, indiretamente,
pode, de certo modo, ser movido, como já se disse.
E o mesmo devemos responder à TERCEIRA OBJEÇÃO.

## Art. 2 — Se a razão pode ser travada pela paixão contrária à sua ciência.
(De Malo, q. 2. a. 9 ; VII Ethic., lect. III)
O segundo discute-se assim. ― Parece que não pode a razão ser travada pela paixão contrária à sua
ciência.

1. ― Pois, o mais forte não pode ser vencido pelo mais fraco. Ora, a ciência, pela sua certeza, é o que há
em nós de mais forte. Logo, não pode ser travada pela paixão, débil e transitória.

2. ― Demais. ― A vontade só pode ter por objeto o bem real ou aparente. Ora, a paixão, quando arrasta
a vontade para o bem verdadeiro, não inclina a razão contra a ciência. E quando a arrasta para o bem
aparente, sem existência, fá-lo para o bem aparente à razão, o que também lhe pertence à ciência.
Logo, a paixão nunca inclina a razão contra a ciência.

3. Demais. ― E a quem disser que arrasta a razão, conhecedora em universal do objeto, de maneira a
levá-la a julgar o contrário, num caso particular, responde-se-lhe o seguinte. ― Quando a proposição
universal se opõe à particular, tal se dá por contradição; assim, todo homem se opõe a nem todo
homem. Ora, duas opiniões, que versam sobre objetos contraditórios, são contrárias, como diz
Aristóteles. Quem portanto, conhecendo alguma coisa em universal, julgasse a oposta, em particular,
por força defenderia simultaneamente opiniões contrárias, o que é impossível.

4. Demais. ― Quem conhece em universal conhece também o particular, pois sabe estar esse contido
naquele. Assim, quem sabe que toda mula é estéril sabe ser estéril tal animal determinado, pois sabe
que é mula, como está claro em Aristóteles. Ora, quem sabe algo em universal, p. ex., que não devemos
praticar a fornicação, sabe, p. ex., que tal ato particular, contido no universal, é um ato de fornicação.
Logo, também o conhece em particular.

5. Demais. ― O expresso pela palavra é sinal da inteligência da alma, segundo o Filósofo. Ora, levados
pela paixão confessamos freqüentemente ser um mal o que escolhemos, mesmo em particular. Logo,
temos essa ciência relativa ao particular. Donde portanto se conclui, que as paixões não podem arrastar
a razão contrariamente à ciência em universal; pois, não pode dar-se que tenha a ciência,
universalmente, e pense o oposto em particular.
Mas, em contrário, diz o Apóstolo (Rm 7, 23): Sinto nos meus membros outra lei que repugna à lei do
meu espírito e que me faz cativo da lei do pecado. Ora, a lei dos membros está na concupiscência, da
qual já tratamos acima. E sendo a concupiscência uma paixão, resulta que esta arraste a razão, mesmo
contrariamente ao que ela sabe.

SOLUÇÃO. ― Era opinião de Sócrates, como diz Aristóteles, que a ciência nunca poderia ser vencida pela
paixão. Por isso, ensinava, todas as virtudes são ciências e todos os pecados, ignorâncias. E nisso, de
certo modo, pensava retamente; pois a vontade, querendo o bem, ou o que lhe parece tal, nunca se
move para o mal, salvo se o não bom aparecer, de certo modo, como tal, à razão. E por isso a vontade
nunca tenderá para o mal, senão por ignorância ou erro da razão. Donde o dizer a Escritura (Pr 14, 22):
Os que obram mal erram. ― Mas por outro lado, a experiência patenteia que muitos procedem contra a
ciência que têm, e a autoridade divina o confirma, conforme àquele lugar: aquele servo que soube a
vontade de seu senhor, e não a fez, dar-se-lhe-ão muitos açoites; e ainda: Aquele, pois, que sabe fazer o
bem, e não no faz, peca. Por onde se vê que a opinião de Sócrates não é verdadeira de modo absoluto;
mas é preciso distinguir, como ensina Aristóteles.
Pois, como para agir acertadamente, o homem é dirigido por dupla ciência, uma de natureza universal e
outra, particular, a deficiência de qualquer delas basta para lhe ficar impedida a retidão da vontade e do
ato, como já se disse (q. 76, a. 1). Por onde, é possível possuirmos a ciência, em universal, de que, p. ex.,
não devemos praticar a fornicação, sem contudo sabermos, em particular, que não devemos praticar
um determinado ato, que é fornicação; e isto basta para a vontade não obtemperar à ciência de
natureza universal, da razão. ― E além disso, devemos considerar que nada impede saibamos alguma
coisa habitualmente, sem contudo nela refletirmos atualmente. Por onde, pode suceder tenhamos uma
ciência reta, singularmente, e não só universalmente, sem contudo nela refletirmos atualmente. E então
não parece difícil agirmos à margem do que não consideramos em ato.
Por outro lado, às vezes é só por falta de intenção que não consideramos, em particular, o que
habitualmente sabemos. Assim quando, sabendo geometria, não temos a intenção de lhe considerar as
conclusões, o que entretanto poderíamos imediatamente fazer, se o quiséssemos. Outras vezes, ainda,
não consideramos o que possuímos habitualmente, por causa de algum impedimento sobreveniente; p.
ex., por causa de alguma ocupação exterior ou doença corpórea. E deste modo, quem é dominado pela
paixão não considera em particular o que sabe universalmente, por lhe impedir a ela tal consideração.
Ora, pode impedi-la de três modos. ― Primeiro, por distração, como já ficou exposto (a. 1). Segundo,
por contrariedade; pois muitas vezes a paixão inclina para o contrário daquilo que sabemos por ciência
universal. Terceiro, por imutação corpórea, pela qual a razão fica de certo modo travada, de maneira a
não poder exercer livremente o seu ato. Assim, o sono ou a embriaguez, pela alteração corpórea que
causam travam o uso da razão. E vemos claramente que isto se dá às vezes com as paixões, quando a
muita intensidade delas nos priva de todo o uso da razão. Assim, o amor ou a ira excessivos levam
muitos à insânia. E deste modo, a paixão arrasta a razão a julgar, em particular, contra o que sabe por
ciência universal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A ciência em universal, que é certíssima, não exerce o
papel principal na agência; mas antes, a ciência em particular, pois o atos versam sobre o particular. Por
onde, não é de admirar-se, na ordem prática, a paixão encontra a ciência universal, faltando a
consideração particular.

RESPOSTA À SEGUNDA. ― Já é por alguma paixão que o bem, que não é tal, se apresenta em particular
à razão, como bem. E, contudo, esse juízo particular é contrário à ciência de natureza universal, da
razão.

RESPOSTA À TERCEIRA. ― Não é possível termos simultânea e atualmente uma ciência ou opinião
verdadeira a respeito do universal afirmativo, e uma opinião falsa sobre o particular negativo, ou
inversamente. Mas pode bem se dar que tenhamos, uma ciência verdadeira habitual, sobre o universal
afirmativo, e uma opinião falsa atual sobre o particular negativo. Pois, um ato não contraria diretamente
a um hábito, mas sim a outro ato.

RESPOSTA À QUARTA. ― Aquele que tem a ciência em universal, fica impedido pela paixão de subsumir
nela a menor (do silogismo) de modo a chegar à conclusão; mas subsume noutra universal, sugerida
pela inclinação da paixão, e conclui em dependência dessa universal. E por isso o Filósofo diz, que o
silogismo do incontinente tem quatro proposições. Duas são universais e delas, uma pertence à razão,
como, p. ex., que não devemos praticar nenhuma fornicação; outra, à paixão, como, p. ex., que
devemos seguir o prazer. Assim, a paixão contende com a razão para que esta não subsuma na primeira
proposição; e por isso, enquanto perdura, a razão subsume na segunda e conclui em dependência dela.

RESPOSTA À QUINTA. ― Assim como o ébrio pode às vezes, proferir palavras expressivas de
pensamentos profundos de que, contudo a sua mente não pode julgar, por lho impedir a embriaguez,
assim, quem é levado pela paixão, embora diga verbalmente que tal ato não deve ser praticado,
contudo sente interiormente, na alma, que o deve, como diz Aristóteles.

## Art. 3 — Se o pecado causado pela paixão, deve ser tido como causado pela fraqueza.
(Infra, q. 85, a. 3, ad 4 ; De Malo, e. 3, a. 9 ; In Psalm. VI)
O terceiro discute-se assim. ― Parece que o pecado causado pela paixão não deve ser tido como
causado pela fraqueza.

1. ― Pois, a paixão é um movimento veementemente do apetite sensitivo, como já se disse (a. 1). Ora, a
veemência do movimento prova antes em favor da fortaleza que da fraqueza. Logo, o pecado causado
pela paixão não deve ser tido como causado pela fraqueza.

2. Demais. ― A fraqueza do homem funda-se sobretudo no que ele tem de mais frágil. Ora, tal é a carne,
donde a expressão da Escritura (Sl 77, 39): E lembrou-se que são carne. Logo, devemos considerar
pecado de fraqueza o causado, antes por uma deficiência do corpo, do que por uma paixão da alma.

3. Demais. ― O homem não é considerado fraco pelo que lhe depende da vontade. Ora, fazer ou não
fazer aquilo a que a paixão inclina, depende-lhe da vontade, conforme a Escritura (Gn 4, 7): a tua
concupiscência estar-te-á sujeita e tu dominarás sobre ela. Logo, o pecado causado pela paixão não o é
pela fraqueza.
Mas, em contrário, Túlio, chama às paixões da alma doenças. Ora, as doenças são também designadas
pelo nome de fraquezas. Logo, o pecado causado pela paixão deve ser tido como causado pela fraqueza.

SOLUÇÃO. ― A causa própria do pecado é a alma, na qual principalmente ele existe. Ora, a fraqueza
pode lhe ser atribuída por semelhança com a fraqueza do corpo. E, este o consideramos fraco quando
debilitado ou impedido de exercer a sua atividade própria, por causa de alguma desordem nas suas
partes; de modo tal que os nossos humores e membros não estejam sujeitos ao poder dirigente e motor
do corpo. Por onde, chama-se fraco ao membro que não pode exercer a atividade do membro são; tal se
dá com os olhos, quando não podem ver claramente, como diz o Filósofo. Donde o dizer-se que há na
alma fraqueza quando fica impedida de exercer a sua atividade própria, pela desordenação nas partes
da mesma.
Pois, assim como se dizem desordenadas as partes do corpo, quando não obedecem à ordem da
natureza, assim também desordenadas consideram-se as partes da alma quando fogem à ordem da
razão, que as rege. Portanto, quando, fora da ordem da razão, a potencia concupiscível ou a irascível é
afetada por alguma paixão, causa, do modo supra dito, de algum impedimento à ação devida, diz-se que
há pecado por fraqueza. Por isso, o Filósofo, compara o incontinente ao epiléptico, cujos membros se
lhe movem contrariamente ao que ele dispõe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Assim como, quanto mais forte for o motor do corpo
contrário à ordem da natureza, tanto maior será a fraqueza, assim, quanto mais forte o movimento da
paixão, contrário à ordem racional, tanto maior será a fraqueza da alma.

RESPOSTA À SEGUNDA. ― O pecado principalmente consiste num ato da vontade, não impedido pela
fraqueza do corpo. Pois, quem é fraco de corpo pode ter a vontade pronta para agir. Mas, pode esse ato
ficar travado pela paixão, como já se disse (a. 1). Por onde, quando dizemos ser um pecado causado pela
fraqueza, referimo-nos mais à fraqueza da alma que à do corpo. Mas também se chama à fraqueza da
alma fraqueza da carne, porque, pela condição desta, surgem em nós as paixões da alma, por ser o
apetite sensitivo uma potencia que se serve de órgãos corpóreos.

RESPOSTA À TERCEIRA. ― Por certo está no poder da vontade assentir ou não naquilo para o que a
paixão inclina; e nesse sentido se diz que o nosso apetite depende de nós. Contudo esse aprendimento
do dissentimento da vontade pode ficar impedido pela paixão, do modo já exposto.

## Art. 4 — Se o amor próprio é o princípio de todo o pecado.
(Infra, q. 84, a. 2, ad 3 ; IIª-IIªª, q. 25, a. 7, ad 1 ; q. 153, a. 5, ad 3 ; II Sent., dist. XLII, q. 2, a. 1; De Malo,
q. 8, a. 1, ad 19)
O quarto discute-se assim. ― Parece que o amor próprio não é o princípio de todo pecado.

1. ― Pois, o em si mesmo bom e devido não pode ser causa própria do pecado. Ora, o amor próprio é,
em si mesmo, bom e devido; por isso nos foi preceituado amarmos ao próximo como a nós mesmos (Lv
19, 18). Logo, o amor de si mesmo não pode ser causa própria do pecado.

2. Demais. ― O Apóstolo diz (Rm 7, 8): E o pecado, tomando ocasião pelo mandamento, obrou em mim
toda a concupiscência; ao que diz a Glosa: é boa a lei que, coarctando a concupiscência, elimina todo
mal; o assim o diz porque a concupiscência é causa de todos os pecados. Ora, a concupiscência é uma
paixão diferente do amor, como já antes se estabeleceu (q. 23, a. 4). Logo, o amor próprio não é causa
total do pecado.

3. Demais. Agostinho, sobre aquilo da Escritura (Sl 79) ― Ela foi queimada a fogo e escavada ―diz, que
todo pecado provém do amor que perniciosamente inflama, ou do temor que perniciosamente
humilhe. Logo, só o amor próprio é causa do pecado.

4. Demais ― Assim como às vezes pecamos pelo desordenado amor de nós mesmos, assim também,
outras, pelo amor desordenado do próximo. Logo, o amor próprio não é causa de todos os pecados.
Mas, em contrário, diz Agostinho, que o amor de si, até o desprezo de Deus, constitui a cidade de
Babilônia. Ora, por qualquer pecado ficamos pertencendo à cidade de Babilônia. Logo, o amor próprio é
a causa de todo pecado.

SOLUÇÃO. ― Como já se disse (q. 75, a. 1), a causa própria e essencial do pecado deve buscar-se na
conversão para um bem mutável; donde procede que todo ato pecaminoso resulta do desejo
desordenado de algum bem temporal. E é por nos amarmos desordenadamente a nós mesmos que
também desordenadamente desejamos os bens temporais; pois, amar alguém é querer-lhe bem. Por
onde e manifestamente, o amor desordenado de si é a causa de todo pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O amor próprio ordenado é devido e natural, no sentido
de querermos para nós o bem que nos cabe. Ao passo que o amor próprio desordenado, causa desprezo
de Deus, é considerado, segundo Agostinho, causa do pecado.

RESPOSTA À SEGUNDA. ― A concupiscência pela qual desejamos o bem se reduz ao amor próprio como
à causa, segundo já se disse.

RESPOSTA À TERCEIRA. ― O amor se refere não só ao bem que para nós desejamos, como a nós
mesmos, a quem o deseja.
Por onde, o amor, considerado como referente ao que desejamos, ― p. ex., o amor do vinho ou do
dinheiro ― tem como causa o temor relativo à fuga do mal. Pois, todo pecado provém ou do desejo
desordenado de algum bem, ou de fuga desordenada de algum mal. Ora, esta e aquele se reduzem ao
amor próprio, pois é por se amar a si próprio que o homem deseja os bens ou foge dos males.

RESPOSTA À QUARTA ― O amigo é um quase outro eu. E assim, considera-se que, quando pecamos por
amor de um amigo, por amor de nós mesmos o fazemos.

## Art. 5 — Se se consideram convenientemente como causas dos pecados a concupiscência da carne, a concupiscência dos olhos e a soberba da vida.
(II Sent., dist. XLII, q. 2, a. 1).
O quinto discute-se assim. ― Parece que se consideram inconvenientemente como causas dos
pecados aconcupiscência da carne, a concupiscência dos olhos e a soberba da vida.

1. ― Pois, segundo o Apóstolo (1 Tm 6, 10), a raiz de todos os males é a avareza. Ora, a soberba da vida
não está contida na avareza. Logo, não deve ser posta entre as causas dos pecados.

2. Demais. ― A concupiscência da carne se excita principalmente pela visão dos olhos, segundo aquilo
da Escritura (Dn 13, 56): a formosura te seduziu. Logo, a concupiscência dos olhos não se divide, por
contrariedade, da concupiscência da carne.

3. Demais. A concupiscência é um apetite deleitável, como já se disse (q. 30, a. 1). Ora, a deleitação
pode afetar não só a vista, mas também os outros sentidos. Logo, também se deveria admitir uma
deleitação do ouvidos e dos demais sentidos.

4. Demais. ― Assim como somos induzidos do pecado pela concupiscência desordenada do bem, assim,
pela aversão desordenada ao mal, conforme já se disse (a. 4, ad 3). Ora, na enumeração supra nada há
de condizente com essa aversão ao mal. Logo, enumeram-se insuficientemente as causas dos pecados.
Mas, em contrário, diz a Escritura (1 Jo 2, 16): Porque tudo o que há no mundo é concupiscência da
carne, e concupiscência dos olhos, e soberba da vida. Ora, por causa do pecado vem o nos referirmos às
coisas do mundo; e por isso, no mesmo livro (5, 19) está que todo o mundo está posto no maligno. Logo,
as causas dos pecados são as três supra-enumeradas.

SOLUÇÃO. ― Como já dissemos (a. 4), o amor desordenado de si é a causa de todo pecado. Ora, nesse
amor está incluído o apetite desordenado do bem, pois cada qual deseja o bem a quem ama. Por onde
manifestamente, tal apetite é a causa de todo pecado. Mas o bem é de duplo modo o objeto do apetite
sensível, onde residem as paixões da alma, causas do pecado. É-o absolutamente, enquanto objeto do
concupiscível; ou, de outro modo, quando, difícil de atingir, é o objeto do irascível, conforme dissemos
(q. 23, a. 1).
Ora, dupla é a concupiscência, segundo já se estabeleceu (q. 30, a. 3). Uma natural, incidente sobre o
necessário ao sustento do corpo, quer quanto à conservação do indivíduo, como a comida, a bebida e
coisas semelhantes; quer quanto à conservação da espécie, como o é o caso da função reprodutora. E
ao apetite desordenado de tais coisas se chama concupiscência da carne. ― A outra é a concupiscência
animal incidente sobre coisas que, pelo sentido da carne, não produzem sustento nem deleitação, mas
são deleitáveis pela apreensão imaginativa, ou de modo semelhante. Assim, o dinheiro, o ornato das
vestes e coisas semelhantes. Esta concupiscência animal se chama concupiscência dos olhos. E por ela se
entende a concupiscência da visão mesma, que se opera pelos olhos, e se traduz pela curiosidade,
segundo a exposição de Agostinho. Ou, a concupiscência das coisas propostas exteriormente aos olhos,
e que se traduz pela cobiça, segundo a exposição de outros. ― Por outro lado, o desejo do
bem difícil diz respeito à soberba da vida; pois, a soberba é o apetite desordenado da excelência, como
a seguir se dirá (q. 84, a. 2; IIa IIae, q. 162, a. 1).
Por onde, é claro, a essas três concupiscências podem reduzir-se todas as paixões, causas do pecado.
Pois, às duas primeiras se reduzem todas as paixões do concupiscível; e à terceira, todas as do irascível,
não susceptível de dupla divisão, porque todas as paixões do irascível correspondem à concupiscência
animal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Enquanto a cobiça implica universalmente o apetite de
qualquer bem, a soberba da vida também está nela compreendida. E como a cobiça, sendo então um
vício especial e denominando-se avareza, é a raiz de todos os vícios, a seguir se dirá (q. 82, a. I).

RESPOSTA À SEGUNDA. ― Pela concupiscência dos olhos não se entende aqui a concupiscência de
todas as coisas que por eles podem ser vistas, senão só a daquelas onde não buscamos o deleite carnal,
depende do tato, mas só a dos olhos, i. é, de qualquer virtude apreensiva.

RESPOSTA À TERCEIRA. ― O sentido da vista é o mais excelente de todos e o que maior extensão
abrange, como diz Aristóteles. E por isso o seu nome se aplica a todos os outros sentidos e também a
todas as apreensões interiores, no dizer de Agostinho.

RESPOSTA À QUARTA. ― A fuga do mal é causada pelo desejo do bem, como dissemos (q. 24, a. 2). E
por isso se referem às paixões que inclinam para o bem, como causas das inclinantes
desordenadamente à fuga do mal.

## Art. 6 — Se o pecado fica atenuado pela paixão.
(Supra, q. 24, a. 3 ; q. 73, ad 6 ; De Verit., q. 26, a. 7, ad I ; De Malo, q. 3, a 2 ; V Ethic., lect. XIII).
O sexto discute-se assim. ― Parece que o pecado não fica atenuado pela paixão.

1. ― Pois, o aumento da causa aumenta o efeito; assim, o cálido dissolve, o mais cálido mais dissolve.
Ora, a paixão é causa do pecado, como já se estabeleceu (a. 5). Logo, quanto mais intensa a paixão,
tanto maior o pecado. Portanto, ela não o diminui, mas, o aumenta.

2. Demais. ― A paixão boa está para o mérito, assim como está a má para o pecado. Ora, aquela
aumenta o mérito; pois, tanto mais merecemos quanto maior for a misericórdia com que socorremos os
pobres. Logo, também a má paixão antes agrava que atenua o pecado.

3. Demais. ― Quanto mais intensa for a vontade de cometermos o pecado, tanto mais grave será este
considerado. Ora, a paixão, impulsora da vontade, fá-la cometer mais veementemente o ato
pecaminoso. Logo, a paixão agrava o pecado.
Mas, em contrário. ― A paixão mesma da concupiscência é a chamada tentação da carne. Ora, quanto
maior for a paixão que nos subjuga, tanto menos pecaremos, como claramente o diz Agostinho. Logo, a
paixão diminui o pecado.

SOLUÇÃO. ― O pecado consiste essencialmente num ato do livre arbítrio, a faculdade da vontade e da
razão. Ora, a paixão é um movimento do apetite sensitivo, e pode ser antecedente e conseqüente ao
livre arbítrio. Antecedente, quando a paixão do apetite sensitivo arrasta ou inclina a razão ou a vontade,
como já dissemos (a. 1, 2; q. 9, a. 2; q. 10, a. 3). Conseqüente, quando o movimento das faculdades
superiores, pela sua veemência, redundam nas inferiores. Pois, a vontade não pode mover-se
intensamente para nada, sem provocar alguma paixão no apetite sensitivo.
Se portanto considerarmos a paixão precedente ao ato do pecado, por força ela o diminuirá. Pois, um
ato é pecaminoso na medida em que é voluntário e dependente de nós. Ora, diz-se que alguma coisa
depende de nós, pela razão e pela vontade. Por onde, quanto mais a razão e a vontade agem
livremente, e não pelo impulso da paixão, tanto mais a obra é voluntária e nossa. E deste modo a
paixão, diminuindo o voluntário, diminui o pecado. ― Por seu lado, a paixão conseqüente não o diminui,
mas ao contrário, o aumenta; ou antes, é sinal da gravidade do mesmo, por demonstrar a intensidade
da vontade em querer o ato pecaminoso. E assim e verdadeiramente quanto maior for a libidinosidade
ou a concupiscência com que pecarmos, tanto mais gravemente pecaremos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A paixão é causa do pecado no atinente à conversão.
Pois, a gravidade do mesmo depende sobretudo da aversão, que, por sua vez, resulta acidentalmente da
conversão, i. é, contra a intenção do pecador. Ora, não são as causas acidentais correlatamente
aumentadas que aumentam os efeitos, mas só as essenciais.

RESPOSTA À SEGUNDA. ― A paixão boa, conseqüente ao juízo da razão, aumenta o mérito. Se porém o
proceder, de modo a sermos levados a obrar bem, mais pela paixão que por um juízo racional, então a
paixão diminui a bondade do ato e o louvor que lhe é devido.

RESPOSTA À TERCEIRA. ― Embora o movimento da vontade seja mais intenso quando provocado pela
paixão, não é contudo tão próprio da vontade como quando, dirigido só pela razão, conduz ao pecado.

## Art. 7 — Se a paixão excusa totalmente do pecado.
(Infra a 8, ad 3 ; De Malo, q. 3, a. 10 ; V Ethic., lect. XIII).
O sétimo discute-se assim. ― Parece que a paixão excusa totalmente o pecado.

1. ― Pois, tudo o que causa o involuntário excusa totalmente do pecado. Ora, a concupiscência da
carne, que é uma paixão, causa o involuntário, conforme aquilo da Escritura (Gl 5, 17): a carne deseja
contra o espírito, para que não façais todas as coisas que quereis. Logo, a paixão excusa totalmente do
pecado.

2. Demais. ― A paixão causa uma ignorância particular, como já se disse (a. 2). Ora, a ignorância
particular excusa totalmente do pecado, como já se estabeleceu (q. 19, a. 6). Logo, a paixão também
excusa totalmente dele.

3. Demais. ― A enfermidade da alma é mais grave que a do corpo. Ora, esta excusa totalmente do
pecado, como bem o mostram os loucos. Logo, com maior razão, a paixão, que é uma enfermidade do
corpo.
Mas, em contrário, o Apóstolo (Rm 7, 5), as denomina paixões dos pecados, só pelos causar; o que não
faria se excusassem totalmente deles. Logo, as paixões não excusam totalmente do pecado.

SOLUÇÃO. ― Um ato genericamente mau só é isento totalmente de pecado se foi totalmente
involuntário. Por onde, a paixão, que tornar totalmente involuntário o ato a ela consecutivo, excusa
totalmente do pecado; do contrário, não.
Sobre isto duas coisas se devem ponderar. ― A primeira, que um ato é voluntário em si mesmo, quando
a vontade para ele é levada diretamente; ou na sua causa, quando a vontade visa a esta e não, o efeito,
como o demonstra quem voluntariamente se embriaga, ao qual se imputa como voluntário o que
pratica no estado de embriaguez. ― Em segundo lugar devemos ponderar, que um ato pode ser
considerado voluntário direta ou indiretamente. Diretamente, quando a vontade é para ele levada;
indiretamente, quando, podendo impedi-lo, não o fez.
Mas aqui devemos distinguir. Assim, a paixão é às vezes tão forte de modo a privar totalmente do uso
da razão, como bem o mostram os enlouquecidos por amor ou ira. E então, se essa paixão era a
princípio voluntária, o ato é imputado como pecado; pois, é voluntário na sua causa, como já o dissemos
a respeito da embriaguez. Se porém a causa não for voluntária, mas natural, como quando, p. ex.,
alguém, por doença ou causa semelhante, se deixa dominar de uma paixão tal, que priva totalmente do
uso da razão, o ato se torna absolutamente involuntário e, por conseqüência, excusa totalmente do
pecado. Outras vezes porém a paixão não é tão forte que de todo impeça o uso da razão. E nesse caso
esta pode excluir a paixão, distraindo-se com outros pensamentos; ou impedir que ela consiga o seu
efeito, porque os membros não se ativam senão com o consentimento da razão, como já se disse (q 17,
a. 9). Por onde, tal paixão não excusa totalmente do pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O dito ― para que não façais todas as coisas que
quereis ― não deve ser referido ao que praticamos exteriormente, mas ao movimento interior da
concupiscência. Pois, preferíamos não desejar nunca o mal, como é também interpretado aquilo do
Apóstolo (Rm 7, 19): faço o mal que não quero. Ou também pode ser referido à vontade precedente à
paixão; como bem mostram os incontinentes, quando, arrastados pela concupiscência, agem contra o
seu propósito.

RESPOSTA À SEGUNDA. ― A ignorância particular excusa totalmente quando é a ignorância da
circunstância, que não podemos conhecer, apesar de empregarmos a diligência devida. Mas a paixão
causa a ignorância do direito, em um caso particular, por impedir a aplicação da ciência comum a um
ato particular; e essa paixão pode a razão repeli-la, como já se disse.

RESPOSTA À TERCEIRA. ― A enfermidade do corpo é voluntário. Símile haveria se fosse voluntária,
como já dissemos a respeito da embriaguez, enfermidade corpórea.

## Art. 8 — Se o pecado provocado pela paixão pode ser mortal.
(De Malo., q. 3, a. 10)
O oitavo discute-se assim. ― Parece que o pecado provocado pela paixão não pode ser mortal.

1. Pois, o pecado venial separa-se do mortal, por contrariedade. Ora, o pecado por fraqueza é venial,
por trazer em si a causa da vênia. Ora, sendo o pecado provocado pela paixão proveniente da fraqueza,
resulta o não poder ser mortal.

2. Demais. ― A causa é mais forte que o efeito. Ora, a paixão não pode ser pecado mortal, por não
poder este residir na sensualidade, como já se demonstrou (q. 74, a. 4). Logo, o pecado provocado pela
paixão não pode ser mortal.

3. Demais ― A paixão desvia a razão, como do sobredito se colhe (a. 1, 2). Ora, a razão pode voltar-se
para Deus ou dele afastar-se, e nisso consiste a essência do pecado mortal. Logo, o pecado provocado
pela paixão pode ser mortal.
Mas, em contrário, diz o Apóstolo (Rm 7, 5): as paixões dos pecados obravam em nossos membros para
darem fruto à morte. Ora, frutificar para a morte é próprio do pecado mortal. Logo, o pecado provocado
pela paixão pode ser mortal.

SOLUÇÃO. ― O pecado mortal consiste, como dissemos (q. 72, a. 5), no afastamento de Deus, fim
último; e esse afastamento provém da razão deliberativa, à qual também é próprio ordenar para o fim.
Por onde, só nos movimentos súbitos pode suceder que a inclinação da alma para um fim contrário ao
fim último, não seja pecado mortal, por não ter podido intervir a razão deliberativa. Ora, não é
subitamente que passamos da paixão ao ato pecaminoso, ou ao consentimento deliberado. Logo, a
razão deliberativa pode intervir; pois, pode excluir ou, pelo menos, impedir a paixão, como já se disse (a.
7). Portanto, se não intervier, o pecado é mortal; daí o vermos muitos homicídios e adultérios serem
cometidos por paixão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― De três modos pode um pecado considerar-se venial. ―
Primeiro quando tem uma causa de vênia, que o diminui. Assim, chama-se venial o pecado por fraqueza
ou ignorância. ― Segundo, por um evento; assim, todo pecado pela penitência torna-se venial, i. é,
consegue-se a vênia. ― Terceiro, genericamente, como a palavra ociosa. E, só nesta acepção, venial se
opõe ao mortal. Ora, a objeção se funda no primeiro sentido.

RESPOSTA À SEGUNDA OBJEÇÃO. ― A paixão é causa do pecado, quanto à conservação. Mas o torna
mortal a aversão consecutiva acidentalmente à conversão, como já se disse (a. 6, ad 1). Logo, a objeção
não colhe.

RESPOSTA À TERCEIRA. ― Nem sempre o ato da razão fica totalmente impedido pela paixão; e por isso
resta-lhe sempre o livre arbítrio, para poder apartar-se de Deus ou voltar-se para ele. Se porém ficasse
totalmente travado o uso da razão, já não haveria pecado, nem mortal nem venial.