# Questão 20: Da bondade e da malícia dos atos humanos exteriores.
Em seguida devemos tratar da bondade e da malícia dos atos humanos exteriores.
E sobre esta questão seis artigos se discutem:

## Art. 1 — Se o bem e o mal está, primeiro, no ato exterior, que no ato da vontade.
(De Malo, q. 2, a . 3).
O primeiro discute-se assim. ― Parece que o bem e o mal estão primeiro no ato exterior que no ato
da vontade.

1. ― Pois, a vontade tira a sua bondade do objeto, como já se disse. Ora, o ato exterior é o objeto do ato
interior da vontade; assim, falamos em querer o furto ou, dar esmola. Logo, o bem e o mal estão
primeiro no ato exterior que no ato da vontade.

2. Demais. ― O bem se atribui primeiramente ao fim, porque a bondade dos meios deriva da do fim.
Ora, o ato da vontade não pode ser fim, como já se disse, ao passo que o pode o ato de qualquer outra
potência. Logo, o bem está primeiro no ato de outra potência que no da vontade.

3. Demais. ― O ato da vontade se comporta formalmente em relação ao ato exterior, como já dissemos.
Ora, como a forma advém à matéria, o que é formal é posterior. Logo, o bem e o mal estão primeiro no
ato exterior que no ato da vontade.
Mas, em contrário, diz Agostinho, que pela vontade pecamos e por ela vivemos retamente. Logo, o bem
e o mal moral existem primeiro na vontade.

SOLUÇÃO. ― Certos atos exteriores podem ser considerados bons ou maus, em duplo sentido.
Genericamente e levadas em conta as circunstâncias em si mesmas; assim, diremos que dar esmola,
conforme às circunstâncias devidas, é um bem. Ou de outro modo, em ordem ao fim, e assim, dar
esmola por vanglória reputamos por mal. Ora, sendo o fim o objeto próprio da vontade, é claro que a
razão de bondade ou malícia, do ato exterior, em ordem a ele, está primeiro, no ato da vontade, donde
deriva para o ato exterior. A bondade porém ou a malícia do ato exterior, em si mesmo, por causa da
matéria devida e das devidas circunstâncias, não lhe deriva da vontade, mas antes da razão. Por onde,
se considerarmos a bondade do ato exterior, relativamente à razão que o ordena e o apreende, ela é
anterior à bondade do ato da vontade. Considerada porém na execução do ato, supõe a bondade da
vontade, que lhe é o princípio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O ato exterior é objeto da vontade, enquanto à razão
lho propõe como um bem que apreende e ordena; e então a sua bondade é anterior à do ato da
vontade. Mas considerado na sua realização, é efeito da vontade e posterior a esta.

RESPOSTA À SEGUNDA. ― O fim é primeiro na intenção; mas último na execução.

RESPOSTA À TERCEIRA. ― A forma, enquanto recebida na matéria, é-lhe posterior, na via da geração,
embora seja por natureza anterior; mas enquanto existente na causa agente, é a todas as luzes
anteriores. Ora, sendo a vontade relativamente ao ato exterior causa eficiente, a bondade do seu ato é
a forma do ato exterior, como existente na causa agente.

## Art. 2 — Se toda bondade e malícia do ato exterior depende da vontade.
(II Sent., dis. XL, a . 2).
O segundo discute-se assim. ― Parece que toda a bondade e malícia do ato exterior depende da
vontade.

1. ― Pois, diz a Escritura (Mt 7, 18): Não pode a árvore boa dar maus frutos, nem a árvore má dar bons
frutos. Ora, por árvore se entende a vontade, e por fruto a sua obra, segundo a Glosa. Logo, não é
possível a vontade interior ser boa e o ato exterior, mau, ou inversamente.

2. Demais. ― Agostinho diz que só a vontade pode pecar. Logo, não havendo pecado nesta, também
não haverá no ato exterior; portanto, toda bondade ou malícia deste daquela depende.

3. Demais. ― O bem e o mal, de que agora tratamos, são diferenças do ato moral. Ora, estas por si
dividem o gênero, segundo o Filósofo. E como o ato é moral desde que é voluntário, resulta que o bem e
o mal de um ato procede da vontade.
Mas, em contrário, como diz Agostinho, coisas há que se não podem tornar boas por nenhum bem e
nenhuma boa vontade.

SOLUÇÃO. ― Como já se disse, podemos considerar duas espécies de bondade e malícia do ato exterior;
a relativa à matéria devida e às circunstâncias, e a relativa à ordem ao fim. Esta última, que se ordena ao
fim, depende totalmente da vontade; ao passo que a primeira depende da razão, e desta depende a
bondade da vontade na medida em que quer.
Ora, é mister lembrar-nos que, como já ficou dito, para uma coisa ser má basta um simples defeito;
porém para ser boa, absolutamente, não basta uma bondade qualquer, senão a bondade íntegra. Se
pois a vontade for boa pelo seu objeto próprio e pelo fim, conseqüentemente o ato exterior há-de ser
bom. Mas não basta, para este último ser bom, a bondade da vontade oriunda do fim intencional; se
porém a vontade for má, quer pelo fim intencional, quer pelo ato querido, conseqüentemente o ato
exterior há-de ser mau.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A vontade boa, significada pela árvore boa, deve ser
entendida com tirando a sua bondade, do ato querido e do fim intencional.

RESPOSTA À SEGUNDA. ― Peca voluntariamente não só quem quer um mau fim, como também quem
quer um mau ato.

RESPOSTA À TERCEIRA. ― Chama-se voluntário não só o ato interior da vontade, com também os atos
exteriores, por procederem da vontade e da razão. Por onde, em relação aquele e a estes pode haver a
diferença de bem e de mal.

## Art. 3 — Se o ato interior da vontade e os atos exteriores tem a mesma bondade ou malícia.
O terceiro discute-se assim. ― Parece que o ato interior da vontade e os atos exteriores não tem a
mesma bondade ou malícia.

1. ― Pois, o princípio do ato interior é a potência da alma interior, apreensiva ou apetitiva; ao passo que
o do ato exterior é a potência executora do movimento. Ora, onde há princípios diversos de ação há
atos diversos. O ato porém é o sujeito da bondade ou da malícia. Ora, como o mesmo acidente não
pode estar em sujeitos diversos, não pode ter a mesma bondade o ato interior e o exterior.

2. Demais. ― A virtude torna bom o homem e a sua obra, como diz Aristóteles. Ora, uma é a virtude
intelectual da potência que manda e outra, a virtude moral da potência que obedece, como se vê
claramente no Filósofo. Logo, uma é a bondade do ato interior, relativa à potência que manda, e outra,
a do exterior, relativa à potência que obedece.

3. Demais. ― Causa e efeito não podem se identificar, pois nada é causa de si mesmo, Ora, a bondade
do ato interior é causa da do exterior, ou inversamente, com já se disse. Logo, ambos não podem ter a
mesma bondade.
Mas, em contrário, já demonstramos que o ato da vontade se comporta como princípio formal em
relação ao ato exterior. Ora, do formal e do material resulta uma mesma realidade. Logo, o ato interior
e o exterior tem a mesma bondade.

SOLUÇÃO. ― Como já se disse, o ato interior da vontade e o ato exterior, considerados na ordem da
moralidade, constituem um só e mesmo ato. Umas vezes acontece porém que o ato subjetivamente
uno, tem várias razões de bondade e de malícia; e outras vezes uma só. Por onde, devemos concluir
que, umas vezes, o ato interior e o exterior tem a mesma bondade e malícia, e outras, não. Mas, como
também já dissemos, as duas referidas bondades ou malícias, a do ato interior e a do exterior, são
subordinadas entre si. Ora, em coisas assim subordinadas, pode acontecer que uma seja boa só por ser
subordinada a outra; tal uma poção amarga, boa só por ser curativa, não havendo por isso duas
bondades ― a da saúde e a da poção, mas uma só. Outras vezes porém, aquilo que subordina a outra
coisa encerra em si alguma razão de bondade, além da sua subordinação; assim, um remédio saboroso,
além de curar, é agradável.
Por onde, devemos dizer que, quando o ato exterior é bom ou mau só em virtude de ordenar-se a um
fim, esse ato que visa um fim, mediante o ato da vontade, tem absolutamente, a mesma bondade e
malícia deste último que, por si mesmo visa um fim. Quando porém o ato exterior tem, uma bondade ou
malícia, própria, i. é, em virtude da matéria e das circunstâncias, então, a sua bondade difere daquela da
vontade, que promana do fim; mas de modo tal que a bondade do fim redunda, da vontade, no ato
exterior, e a da matéria e das circunstâncias redunda no ato da vontade, com já se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção aduzida prova que o ato interior e o exterior,
diversos pelo gênero da natureza, constituem um só ato moral, como dissemos.

RESPOSTA À SEGUNDA. ― Como diz Aristóteles, as virtudes morais se ordenam aos seus próprios atos,
como a fins; a prudência porém, que reside na razão, se ordena aos meios. E por isso são necessárias
várias virtudes. Mas a razão reta relativa ao fim mesmo das virtudes não tem bondade diferente
daquela da virtude, desde que a bondade da razão é participada por cada virtude.

RESPOSTA À TERCEIRA. ― Quando uma coisa deriva para outra, como de causa agente unívoca, então
há nas duas algo de diferente; assim, quando um corpo cálido aquece, o seu calor é numericamente
diferente do calor do corpo aquecido, embora sejam ambos os calores da mesma espécie. Quando
porém uma coisa deriva para outra, por analogia ou proporção, então há numericamente uma só coisa;
assim, da saúde do corpo do animal deriva a do remédio e a da urina, nem a desta e a daquela diferem
da saúde do animal, causada pelo remédio e demonstrada pela urina. E deste modo, da bondade da
vontade deriva a do ato exterior, e inversamente, em virtude da mútua relação entre ambos.

## Art. 4 — Se o ato exterior aumenta a bondade ou a malícia do ato interior.
(II Sent., dist. XL, a . 3; De Malo, q. 2, a . 2, ad 8).
O quarto discute-se assim. ― Parece que o ato exterior não aumenta a bondade ou a malícia do ato
interior.

1. ― Pois, diz Crisóstomo: É a vontade a recompensada pelo bem e condenada pelo mal. Ora, as obras
são os testemunhos da vontade. Logo, Deus não as quer em si mesmas, para saber como julgar, mas por
causa dos outros, afim de que todos entendam que ele é justo. Ora, como devemos apreciar o bem e o
mal, antes pelo juízo de Deus, que pelo dos homens, o ato exterior não aumenta a bondade nem a
malícia do ato interior.

2. Demais. ― A bondade do ato interior e do exterior é a mesma, com já se disse. Ora, o aumento se dá
pela adição de uma coisa a outra. Logo, o ato exterior não aumenta a bondade nem a malícia do ato
interior.

3. Demais. ― Toda a bondade da criatura nada acrescenta à bondade divina, porque deriva desta
totalmente. Ora, a bondade do ato exterior deriva toda, às vezes, da do ato interior; e às vezes,
inversamente, como se disse. Logo, um não aumenta a bondade ou a malícia do outro.
Mas, em contrário. ― Todo agente visa conseguir o bem e evitar o mal. Se pois o ato exterior não
aumenta a bondade nem a malícia, quem tem a vontade boa ou má pratica o bem e se afasta do mal,
em vão, o que é inadmissível.

SOLUÇÃO. ― Se nos referimos à bondade que ao ato exterior lhe advém da vontade do fim, ele nada
acrescenta a essa bondade, salvo se a vontade em si mesma puder tornar-se melhor, no bem, e pior, no
mal. Ora, isto pode se dar de três modos. ― Primeiro, numericamente, se queremos fazer alguma coisa
com fim bom ou mau, mas não fazemos; quando, depois queremos e fazemos, duplica-se o ato da
vontade, e então há no caso dois bens ou dois males. Segundo. ― extensivamente; assim quando uma
pessoa quer fazer um bem ou um mal, mas por algum impedimento desiste, ao passo que outra
continua o movimento da vontade até realizar a obra, é claro que a vontade desta última tem maior
duração no bem ou no mal, tornando-se por isso pior ou melhor. ― Terceiro, intensivamente, pois há
certos atos exteriores deleitáveis ou penosos, que são de natureza a intensificar ou afrouxar a vontade.
Ora, é inegável que tanto melhor ou pior é a vontade quanto mais intensamente tende para o bem ou
para o mau.
Se porém nós nos referimos à bondade do ato exterior que lhe advém da matéria e das circunstâncias
devidas, então ele está para a vontade como termo e fim. E deste modo, aumenta a bondade ou a
malícia da vontade, porque toda inclinação ou movimento se completa conseguindo o fim ou atingindo
o termo. Por onde, não há vontade perfeita senão a que age oportunamente. Se porém não houver
possibilidade de a vontade perfeita operar quando pode, o defeito da consumação do ato exterior é
absolutamente involuntário. Ora, o involuntário não merecendo pena nem premio, na realização de um
bem ou de um mal, nada tira do premio ou da pena, quando o homem, por absoluta involuntariedade,
deixou de fazer o bem ou o mal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Crisóstomo se refere à vontade do homem perfeita, que
cessa de agir somente pela impossibilidade de o fazer.

RESPOSTA À SEGUNDA. ― A objeção colhe quanto à bondade que o ato exterior tira da vontade do fim.
Ora, diferente desta bondade é a que o ato exterior haure na matéria e nas circunstâncias, que não é
diferente porém daquela que à vontade lhe deriva do ato querido mesmo, com a qual se compara como
razão e causa dela, conforme já se disse.
Donde se deduz clara a RESPOSTA À TERCEIRA OBJEÇÃO.

## Art. 5 — Se as conseqüências de um ato aumentam-lhe a bondade ou a malícia.
(Infra, q. 73, a . 8; De Malo, q. 1, a . 3, ad15; q. 3, a . 10, ad 5).
O quinto discute-se assim. ― Parece que as conseqüências de um ato aumentam-lhe a bondade ou a
malícia.

1. ― Pois, o efeito preexiste na causa virtualmente. Ora, as conseqüências resultando dos atos como os
efeitos, das causas, preexistem neles virtualmente. Mas uma coisa é considerada boa ou ma pela
virtude, porque, como diz Aristóteles, a virtude torna bom quem a possui. Logo, as conseqüências
aumentam a bondade ou a malícia do ato.

2. Demais. ― O bem feito pelos ouvintes são efeitos conseqüentes à predicação do doutor. Ora, tal bem
redunda em mérito do pregador, como se vê claramente na Escritura (Fl 4, 1): Meus muito amados e
desejados irmãos, gosto meu e coroa minha. Logo, as conseqüências de um ato aumentam-lhe a
bondade ou a malícia.

3. Demais. ― A pena aumenta proporcionalmente à culpa; por isso, dia a Escritura (Dt 25, 2): O número
dos golpes regular-se-á pela qualidade do pecado. Ora, a conseqüência do ato aumenta a pena, como na
mesma se lê (Ex 21, 19): Se o boi é já de tempos avezado a marrar, e o dono, tendo sido disso advertido,
não o encurralou, e o boi matar um homem ou uma mulher, será apedrejado, e a seu dono matá-lo-ão.
Ora, este não seria morto, se o boi ainda mesmo em liberdade, não tivesse matado um homem. Logo, a
conseqüência superveniente aumenta a bondade ou a malícia de um ato.

4. Demais. ― Não incorre em irregularidade quem expõe outrem à morte, ferindo ou dando uma
sentença, sem que contudo a morte daí resulte. Mas incorreria, se ela se seguisse. Logo, a conseqüência
aumenta a bondade ou malícia do ato.
Mas, em contrário. ― A conseqüência superveniente não torna mau o ato que era bom, nem bom o que
era mau. Assim, se dermos esmola a um pobre, e este dela abusar para pecar, isso em nada diminui o
nosso mérito; semelhantemente, o fato de sofrermos pacientemente a injúria que nos é irrogada, em
nada excusa quem a fez. Logo, as conseqüências não aumentam a bondade nem a malícia dos atos.

SOLUÇÃO. ― As conseqüências de um ato ou são previstas ou não. ― No primeiro caso é claro que lhe
aumentam a bondade ou a malícia. Assim, quem prevê que de ato seu muitos males podem resultar e
nem por isso deixa de o praticar dá provas de uma vontade mais desordenada. ― Se ao contrário, as
conseqüências não forem previstas, então devemos distinguir. Se, ordinária e necessariamente resultam
de um tal ato, aumentam-lhe a bondade ou a malícia. Pois, manifestamente, é melhor, no seu gênero, o
ato do qual podem resultar muitos bens, e pior, se dele resultarem muitos males. Se porém as
conseqüências resultam do ato acidental e extraordinariamente, não lhe aumentarão a bondade e a
malícia; pois não podemos julgar nenhuma realidade pelo que lhe é acidental, senão só pelo que lhe é
necessário.

DONDE A RESPOSTA Á PRIMEIRA OBJEÇÃO. ― A virtude da causa se julga pelos seus efeitos essenciais
e não pelos acidentais.

RESPOSTA À SEGUNDA. ― O bem que os ouvintes fazem resultam da predicação do doutor, como
efeitos necessários. Por isso redundam em prêmio daquele, sobretudo quando o bem foi previsto.

RESPOSTA À TERCEIRA. ― As conseqüências pelas quais se devia infligir uma pena ao culpado resultam
necessariamente da referida causa e além disso são punidas como previstas. Por isso são-lhe imputadas
e merecem a pena.

RESPOSTA À QUARTA. ― A objeção procederia se a irregularidade resultasse da culpa. Ora, ela resulta,
não desta, mas, do fato, por algum defeito sacramental.

## Art. 6 — Se um mesmo ato pode ser bom e mau.
(II Sent., dist. XL, a . 4).
O sexto discute-se assim. ― Parece que um mesmo ato pode ser bom e mau.

1. ― Pois, é uno o movimento contínuo, como diz Aristóteles. Ora, o mesmo movimento contínuo pode
ser bom e mau; p. ex., se alguém vai à igreja continuamente, antes por vanglória, que para servir a Deus.
Logo, o mesmo ato pode ser bom e mau.

2. Demais. ― Segundo o Filósofo, ação e paixão constituem um mesmo ato. Ora aquela pode ser boa,
como a de Cristo, e esta, má, como a dos Judeus. Logo, um mesmo ato pode se bom e mau.

3. Demais. ― Sendo o servo quase instrumento do senhor, o ato daquele é ato deste, como o ato do
instrumento o é do artífice. Ora, pode dar-se que a ação do servo seja boa, por proceder da vontade boa
do senhor, e má, por proceder da sua vontade má. Logo, o mesmo ato pode ser bom e mau.
Mas, em contrário. ― Os contrários não podem coexistir no mesmo sujeito. Ora, o bem e o mal são
contrários, Logo, um mesmo ato não pode ser bom e mau.

SOLUÇÃO. ― Nada impede seja uma realidade una, pertencendo a um gênero, e múltipla, pertencendo
a outro; assim, a superfície contínua é una, considerada no gênero da quantidade, sendo contudo
múltipla, considerada no gênero da cor, se, em parte, for branca e, em parte, negra. E deste modo, nada
impede seja um ato uno, referido ao gênero da natureza, e não o seja, referido ao gênero da
moralidade; e inversamente, como já se disse. Assim, o andar contínuo, ato uno no gênero da natureza,
pode vir a ser múltiplo, no da moralidade, mudada que seja à vontade de quem anda, a qual é o
princípio dos atos morais. ― Por onde, considerado no gênero da moralidade, é impossível o mesmo ato
ser moralmente bom e mau; pode sê-lo entretanto, se tiver a unidade da natureza e não, a da
moralidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O movimento contínuo procedente de intenções
diversas, embora naturalmente uno, não o é moralmente.

RESPOSTA À SEGUNDA. ― Ação e paixão pertencem ao gênero da moralidade, na medida em que são
voluntárias. Por onde, segundo a diversidade das vontades que os inspiram, constituem moralmente
dois atos e, portanto, um pode ser bom e o outro, mau.

RESPOSTA À TERCEIRA. ― O ato do servo, enquanto procedente da sua vontade, não é ato do senhor,
mas só quando procede da ordem deste, e assim, a má vontade do servo não torna mau o ato do
senhor.