# Questão 97: Da mudança das leis.
Em seguida devemos tratar da mudança das leis. E nesta questão discutem-se quatro artigos;

## Art. 1 — Se a lei humana deve de algum modo ser mudada.
(Infra, q. 104, a. 3, ad 2; Ad. Galat., cap. I, lect. II. V Ethic., lect. XII).
O primeiro discute-se assim. — Parece que a lei humana de nenhum modo deve ser mudada.

1. — Pois, a lei humana deriva da lei natural, como já se disse (q. 95, a. 2). Ora, a lei natural perdura
imutável. Logo, também a lei humana deve permanece imutável.

2. Demais. — Como diz o Filósofo, a medida deve, por excelência, ser permanente. Ora, a lei humana é a
medida dos atos humanos, como já se disse (q. 90, a. 1, a. 2). Logo, deve permanecer imutável.

3. Demais. — Da essência da lei é ser justa e reta, como já se disse (q. 95, a. 2). Ora, o que é uma vez
reto o é sempre. Logo, o que foi uma vez lei deve sê-lo sempre.
Mas, em contrário, Agostinho diz: A lei temporal, embora justa, pode, no decurso do tempo, ser
justamente mudada.

SOLUÇÃO. — Como já se disse (q. 91, a. 3), a lei humana é um ditame da razão por que se dirigem os
atos humanos. E assim, por dupla causa pode a lei humana ser justamente mudada: uma fundada na
razão; outra, proveniente dos homens, cujos atos são regulados por lei.
Uma é fundada na razão, porque à razão humana é natural ascender gradualmente do imperfeito para o
perfeito. Por isso vemos, nas ciências especulativas, que os primeiros filósofos transmitiram aos seus
sucessores umas doutrinas imperfeitas, que estes por sua vez transmitiram aos seus sucessores mais
aperfeiçoadas. Ora, o mesmo se dá na ordem das ações. Assim, os primeiros que intencionaram
descobrir mais útil disposição para a comunidade humana, não podendo prever tudo, por si mesmos,
fizeram certas instituições imperfeitas e falhas em muitos casos, que os pósteros modificaram,
estabelecendo por sua vez certas outras, que, em alguns casos, podem não realizar a utilidade comum.
Por outro lado, por parte do homem, cujos atos são regulados por lei, esta pode retamente mudar-se,
por causa da mudança das condições dos homens, aos quais convêm coisas diversas segundo as suas
diversas condições. Assim Agostinho dá o exemplo seguinte. Se um povo for de boa moderação, grave e
guarda diligentíssimo da utilidade comum, a lei é justamente feita para que a tal povo seja lícito
estabelecer os seus magistrados, que administrem a república. Mas se, depravado esse povo
paulatinamente, venha a tornar venal o seu sufrágio e entregar o governo a homens flagiciosos e
celerados, é justo cassar-lhe o poder de distribuir as honras, e transferi-lo ao arbítrio de uns poucos
bons.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A lei natural é uma participação da lei eterna, como já se
disse (q. 91, a. 2), e por isso permanece imutável; e essa imutabilidade ela a tem da perfeição da razão
divina, que institui a natureza. Ao contrário, a razão humana é mutável e imperfeita. E portanto, a sua
lei é mutável. Além disso, a lei natural contém certos preceitos universais, que sempre permanecem; ao
passo que a lei estabelecida pelo homem contém preceitos particulares, provocados pelos casos
emergentes.

RESPOSTA À SEGUNDA. — A medida deve ser permanente quanto possível. Mas na ordem das coisas
mutáveis nada pode haver que permaneça imutável. Por onde, a lei humana não pode ser
absolutamente imutável.

RESPOSTA À TERCEIRA. — Na ordem das coisas materiais a retidão é considerada absolutamente; e por
isso permanece na sua essência. Ao passo que a retidão da lei é considerada em relação à utilidade
comum, a qual não é sempre proporcionada uma mesma realidade, como já se disse. Por isso essa
retidão é susceptível de mudança.

## Art. 2 — Se a lei humana há de sempre ser mudada quando aparecerem melhores instituições.
(II Polit., lect. XII).
O segundo discute-se assim. — Parece que a lei humana há de sempre ser mudada quando
aparecerem melhores instituições.

1. — Pois, as leis humanas são fundadas na razão humana, assim como também as demais artes. Ora,
nestas, muda-se o que estava estabelecido, se aparecer algo de melhor. Logo, o mesmo se deve fazer
com as leis humanas.

2. Demais. — Pelo passado podemos prever o futuro. Ora, se as leis humanas não mudassem com a
superveniência de melhores instituições, daí resultariam muitos inconvenientes, porque segundo
parece, as leis antigas eram muito rudes. Logo, as leis hão-se de mudar, sempre que for possível fazer
melhores instituições.

3. Demais. — As leis humanas são feitas para governar atos particulares dos homens. Ora, na ordem dos
atos particulares, não podemos alcançar conhecimento perfeito senão pela experiência, que exige
tempo, como diz Aristóteles. Logo, parece que, no decurso do tempo, pode ser que ocorra algo de
melhor a ser estatuído.
Mas, em contrário, dizem as Decretais: É ridículo e desonra bastante abominável sofrer a destruição das
tradições que recebemos, desde a antiguidade, dos nossos antepassados.

SOLUÇÃO. — Como já dissemos (a. 1), a lei humana pode ser retamente mudada, na medida em que
essa mudança responda a uma utilidade pública. Mas a mudança, em si mesma, da lei, acarreta um
certo detrimento para o bem da comunidade. Porque para a observância da lei contribui muito o
costume; a ponto de o que se faz contra o costume geral, embora em si mesmo leve, ser, na verdade,
grave. Por onde, mudada, a lei perde da sua força obrigatória, na medida em que se destrói o costume.
Portanto, nunca deve ser mudada a lei humana, a menos que, por outro lado, haja compensação, para o
bem comum, correlativa à parte de rogada da lei. E isto se dá: ou porque, da nova disposição legal,
provém alguma utilidade máxima e evidentíssima; ou porque havia máxima necessidade de mudança;
ou porque a lei costumeira continha manifesta iniqüidade ou a sua observância era nociva para muitos.
Por isso, o jurisperito diz: No constituir uma nova ordem de coisas deve ser evidente a utilidade para nos
afastarmos da lei tida diuturnamente como justa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O que pertence à arte tem uma eficácia fundada só na
razão; e portanto, sempre que ocorrer qualquer melhora, deve-se mudar o que antes estava
estabelecido. Ora, as leis tiram do costume a sua máxima virtude, como diz o Filósofo. De aí o não
deverem ser facilmente mudadas.

RESPOSTA À SEGUNDA. — A objeção conclui, que as leis se devem mudar; não porém para darem lugar
a qualquer melhoria; mas por causa de alguma grande utilidade ou necessidade, como já se disse.
E semelhantemente se deve RESPONDER À TERCEIRA OBJEÇÃO.

## Art. 3 — Se o costume pode obter força de lei e abrogar a lei.
(IIª-IIªª, q. 79, a 2; ad 2; IV Sent., dist. XXXIII, q. 1, a. 1, ad 1; Quodl. II, q. 4, a. 3; IX, q. 4, a. 2).
O terceiro discute-se assim. — Parece que o costume não pode obter força de lei nem abrogar a lei.

1. — Pois, a lei humana deriva da lei da natureza e da lei divina, como do sobredito resulta (q. 93, a. 3; q.
95, a. 2). Ora, o costume dos homens não pode mudar a lei da natureza, nem a lei divina. Logo, também
não pode mudar a humana.

2. Demais. — Muitos males não podem fazer um bem. Ora, quem primeiro começou a agir contra a lei
fez mal. Logo, a multiplicação de atos semelhantes nada poderá fazer de bom. Ora, a lei, sendo regra
dos atos humanos, é um bem. Portanto, o costume não pode abrogar a lei, de modo que obtenha força
de lei.

3. Demais — Legislar é próprio de pessoas públicas, a quem pertence governar a comunidade; por isso
pessoas particulares não podem fazer leis. Ora, o costume se avigora por atos de particulares. Logo, o
costume não pode obter força tal que abrogue a lei.
Mas, em contrário, Agostinho diz: o costume do povo de Deus e as instituições dos maiores devem ser
considerados como lei. E assim como os prevaricadores contra as leis divinas, assim também os
contentores dos costumes eclesiásticos devem ser reprimidos.

SOLUÇÃO. — Toda lei procede da razão e da vontade do legislador: a divina e a natural, da vontade
racional de Deus; a humana, da vontade do homem, regulada pela razão. Ora, a razão e a vontade se
manifestam, não só pela palavra, quanto aos atos que o homem vai praticar, mas também pelos
próprios atos. Pois, cada um pratica o que considera bom. Ora, é claro, pela palavra humana a lei não só
pode ser mudada, mas também exposta, manifestando o movimento interior e o conceito da razão
humana. Por onde, também atos, sobretudo multiplicados, e geradores do costume podem mudar e
expor a lei, e mesmo produzir uma disposição com força de lei. Pois por atos exteriores e multiplicados
revela-se eficacìssimamente o movimento interior da vontade e o conceito da razão. Porque se
considera proveniente do juízo deliberado da razão o que se faz mui repetidamente. E sendo assim, o
costume tanto pode ter força de lei, como abrogá-la e interpretá-la.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A lei natural e a divina procedem da vontade divina,
como já se disse. Por isso não pode ser mudada pelo costume procedente da vontade humana, mas só
por autoridade divina. Por onde, nenhum costume pode ter força de lei contra a lei divina ou a natural.
Pois, diz Isidoro: Ceda o uso à autoridade; o mau uso estirpe a lei e a razão.

RESPOSTA À SEGUNDA. — Como já dissemos (q. 96, a. 6), as leis humanas são deficientes em certos
casos. Por isso é possível às vezes, em caso de deficiência da lei, agir fora dos seus termos, sem ser mau
o ato assim praticado. Ora, a multiplicação de tais casos, por alguma mudança existente nos homens,
manifesta, pelo costume, que a lei já não é útil, assim como isso mesmo se manifestaria se uma lei
contrária fosse verbalmente promulgada. Se, porém ainda permanecer a mesma razão, pelo qual a
primeira lei era útil, não é o costume que suplanta a lei, mas a lei, o costume. Salvo talvez se a lei for
considerada como inútil só por não ser exeqüível, de acordo com o costume pátrio, o que era uma das
condições dela. Pois, é difícil remover o costume do povo.

RESPOSTA À TERCEIRA. — O povo, em que se realiza o costume, pode ter dupla condição. — Se for livre
e capaz de legislar, vale mais o consenso de toda a multidão, para o fim de se observar alguma
disposição manifestada pelo costume, do que a autoridade do chefe, que não tem o poder de legislar
senão enquanto representa a personalidade do povo. Por onde, embora pessoas singulares não possam
legislar, contudo a totalidade do povo o pode. — Outro caso é o do povo que não tem poder livre de
legislar para si ou de remover a lei estabelecida por um poder superior. Em tal caso, contudo, o próprio
costume, que prevalece na multidão, obtém força de lei, por ser tolerado por aqueles a quem pertence
impor a lei ao povo. Pois, por isso mesmo são considerados como tendo aprovado o que o costume
introduziu.

## Art. 4 — Se os chefes do povo podem dispensar nas leis humanas.
(Supra, q. 96. a. 6; infra, q. 100. a. 8; IIª-IIªª, q. 88, a. 10; q. 89. a. 9; q. 717, a. 4; III Sent., dist. XXXVII, a.
4; IV. dist. XV, q. 3, a. 2, qª 1; dist. XXVII, q. 3, a. 3, ad 4; III Cont. Gent., cap. CXXV).
O quarto discute-se assim. — Parece que os chefes do povo não podem dispensar nas leis humanas.

1. — Pois, a lei é estabelecida para a utilidade geral, como diz Isidoro. Ora, o bem comum não pode ser
preterido em benefício da utilidade particular de ninguém. Porque, no dizer do Filósofo, o bem da nação
é mais divino que o de um só homem. Logo, parece que não se deve dispensar ninguém de modo a
poder contrariar o bem comum.

2. Demais. — Aos constituídos como chefes a Escritura preceitua (Dt 1, 17): Do mesmo modo ouvireis o
pequeno que o grande, nem tereis acepção de pessoa alguma, porque este é o juízo de Deus. Ora,
conceder a um o que se nega a todos, comumente, é fazer acepção de pessoas. Logo, sendo isto contra
o preceito da lei divina, os chefes do povo não podem conceder tais dispensas.

3. Demais. — A lei humana, quando reta, há de estar de acordo com a lei natural e a divina; do contrário
não estaria de acordo com a religião, nem conviria com a disciplina, o que entretanto a lei exige, como
diz Isidoro. Ora, na lei natural e divina ninguém pode dispensar. Logo nem na lei humana.
Mas, em contrário, diz o Apóstolo (1 Cor 9, 17): A dispensação me veio só a ser encarregada.

SOLUÇÃO. — A dispensa, propriamente, implica a comensuração entre o comum e o particular. Por
onde, também o chefe de família se chama dispensador, por distribuir a cada membro dela, com peso e
medida, as obras e o necessário à vida. Assim também, em qualquer povo, diz-se que dispensa quem
ordena como cada preceito geral há de ser cumprido pelos particulares.
Ora, pode acontecer que um preceito correspondente, na maior parte dos casos, à utilidade da
multidão, não convenha a uma determinada pessoa ou a um determinado caso. E isso, quer por ser
impedimento do melhor, quer por provocar algum mal, como do sobredito se colhe (q. 96, a. 6). Ora,
seria perigoso cometer tal dispensa ao juízo de qualquer, salvo se houver perigo evidente e súbito,
como antes se disse (q. 96, a. 6). Por onde, quem tem o múnus de governar a multidão tem o poder de
dispensar na lei humana, que se lhe apóia na autoridade. De modo que, nas pessoas ou nos casos em
que a lei é deficiente, dê licença para não se observar o preceito dela.
Se porém, der tal licença, sem a mencionada razão, e só por sua vontade, não será fiel na dispensação,
ou será imprudente. Infiel, se não visar intencionalmente o bem comum; imprudente, se ignorar a razão
de dispensar. Pelo que diz o Senhor (Lc 12, 42): Quem crês que é o dispenseiro fiel e prudente que faz o
senhor sobre a sua família?

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não deve ser em prejuízo do bem comum que alguém
seja dispensado de observar a lei geral; mas com a intenção de isso aproveitar a tal bem.

RESPOSTA À SEGUNDA. — Não há acepção de pessoas se não se estabelecem situações iguais para
pessoas desiguais. Por onde, quando a condição de uma pessoa exige que racionalmente se observe
para com ela alguma disposição especial,não há acepção de pessoas, se lhe fizer uma graça especial.

RESPOSTA À TERCEIRA. — A lei natural, por conter preceitos gerais, que nunca falham, não é
susceptível de dispensa. Mas às vezes o homem pode dispensar nos outros preceitos, que são umas
quase conclusões dos preceitos comuns. Por exemplo, que não se restitua o mútuo ao traidor da pátria,
ou coisa semelhante. Quanto à lei divina, cada homem está para ela, como uma pessoa privada, para a
lei pública, a que está sujeito. Por onde, assim como ninguém pode dispensar na lei pública humana,
senão aquele de quem ela tira a sua autoridade, ou quem dele receber permissão para tal, assim,
ninguém, a não ser Deus, ou quem Ele especialmente determinar, pode dispensar nos preceitos do
direito divino, procedentes de Deus.