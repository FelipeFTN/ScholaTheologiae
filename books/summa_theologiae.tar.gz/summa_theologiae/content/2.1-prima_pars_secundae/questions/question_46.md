# Questão 46: Da ira, em si mesma.
Em seguida, devemos tratar da ira. — E, primeiro, da ira em si mesma. Segundo, da causa produtiva da
ira e do seu remédio. Terceiro, do seu efeito.
Sobre a primeira questão oito artigos se discutem:

## Art. 1 — Se a ira é uma paixão especial.
(Supra, q. 23, a . 4; III Sent., dist. XXVI, q. 1, a . 3).
O primeiro discute-se assim. — Parece que a ira não é uma paixão especial.

1. — Pois, da ira tem a sua denominação a potência irascível. Ora, a esta pertence, não só uma, mas
muitas paixões. Logo, a ira não é uma paixão especial.

2. Demais — Cada paixão especial tem a sua contrária, como verá claramente quem as examinar uma
por uma. Ora, não há nenhuma paixão contrária à ira, como já se disse. Logo, não é uma paixão especial.

3. Demais — Uma paixão especial não inclui outra. Ora, a ira inclui muitas paixões, pois vai de mescla
com a tristeza, com a esperança e com o prazer, como se vê claramente no Filósofo. Logo, não é uma
paixão especial.
Mas, em contrário, Damasceno considera a ira como uma paixão especial; e semelhantemente Túlio.

SOLUÇÃO. — De dois modos pode uma expressão ser geral. Ou como predicação, e assim a palavra
animal se aplica geralmente a todos os animais; ou como causa, e assim o sol é a causa geral de tudo o
que se produz nos seres da terra, segundo Dionísio. Ora, assim como o gênero contém, potencialmente,
muitas diferenças, quanto à semelhança da matéria, assim a causa agente, muitos efeitos quanto à
virtude ativa. Um efeito porém pode ser produzido pelo concurso de diversas causas. E como toda causa
permanece, de certa maneira, no seu efeito, podemos também dizer, de um terceiro modo, que o
efeito, produzido pela reunião de muitas causas, tem uma certa generalidade, enquanto as encerra, de
certo modo, atualmente.
Por onde, do primeiro modo, a ira não é uma paixão geral, mas entra na mesma divisão que as outras,
como já dissemos. — E nem do segundo. Pois, não é a causa das outras paixões; ao passo que, deste
modo, podemos considerar o amor como uma paixão geral, segundo vemos claramente em Agostinho;
pois, ele é a raiz primeira de todas as paixões, como já dissemos. Num terceiro modo porém, a ira pode
ser considerada paixão geral, enquanto causada pelo concurso de muitas paixões. Pois, o movimento da
ira não se manifesta senão porque sofremos alguma tristeza e porque nos está presente o desejo e a
esperança de nos vingarmos, porquanto, no dizer do Filósofo, o irado nutre a esperança de se
vingar; pois, deseja a vindicta como lhe sendo possível. Por onde, se for muito avantajada a pessoa que
nos causou um mal, não dará lugar à ira, mas só à tristeza, como diz Avicena.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A potência irascível recebe da ira a sua denominação;
não que todos os movimentos dessa potência se lhe reduzam a ela, mas porque todos nela acabam; ora,
entre todos os referidos movimentos este é o mais manifesto.

RESPOSTA À SEGUNDA. — Por isso mesmo que a ira é causada por paixões contrárias, a saber, pela
esperança, que visa o bem, e pela tristeza, que visa o mal, ela inclui em si a contrariedade; por isso não
tem contrário.Como também as cores médias não têm contrariedade senão a que resulta das cores
simples que as causam.

RESPOSTA À TERCEIRA. — A ira inclui muitas paixões; não, certo, como o gênero inclui as espécies, mas
antes, como a causa contem o efeito.

## Art. 2 — Se o objeto da ira é o mal.
(Infra, a . 6; De malo, q. 12, a . 2, 4).
O segundo discute-se assim. — Parece que o objeto da ira é o mal.

1. — Pois, como diz Gregório Nisseno, a ira é quase a escudeira da concupiscência , porque impugna o
que impede a esta. Ora, todo impedimento implica a noção de mal. Logo, a ira diz respeito ao mal, como
seu objeto.

2. Demais — A ira e o ódio convêm no mesmo efeito, pois uma e o outro nos causam dano. Ora, o ódio
tem o mal como objeto, segundo já se disse. Logo, também a ira.

3. Demais — A ira é causada pela tristeza, e por isso o Filósofo diz que a ira age acompanhada da
tristeza. Ora, o objeto desta é o mal. Logo, também o daquela.
Mas, em contrário, diz Agostinho, que a ira provoca a vindicta. Ora, o desejo da vindicta é o desejo do
bem, pois se refere à justiça. Logo, o objeto da ira é o bem.

DEMAIS. — A ira vai sempre junta com a esperança, e por isso causa o prazer, como diz o Filósofo. Ora,
o objeto da esperança e do prazer é o bem. Logo, também o da ira.

SOLUÇÃO. — O movimento da virtude apetitiva é consecutivo ao ato da apreensiva. Ora, esta pode
apreender um objeto de dois modos; de modo incomplexo, como quando inteligimos o que é o homem;
e de modo complexo, como quando inteligimos que a cor branca existe num homem. Por onde, de
ambos esses modos a virtude apetitiva pode tender para o bem e para o mal. A modo de simples e
incomplexo, quando o apetite segue simplesmente o bem ou adere a ele, ou quando foge do mal. E tais
movimentos constituem o desejo e a esperança, o prazer e a tristeza, e outros semelhantes. A modo de
complexo, como quando o apetite deseja algum bem ou mal para alguém, quer tendendo para um
determinado objeto, quer fugindo do mesmo. E isto é manifesto no amor e no ódio, pois amamos a
quem desejamos o bem, e odiamos a quem queremos o mal. E o mesmo se dá com a ira: quem está
irado procura vingar-se. Por onde, o movimento da ira tende para dois termos: para a vindicta em si,
que deseja e espera, como um bem, provindo daí o deleite; e para aquele de quem quer tirar vingança,
como alguém que lhe é contrário e nocivo, o que implica a noção do mal.
Ora a esta luz, há uma dupla diferença a considerar entre a ira e o amor e o ódio. A primeira é que a ira
sempre diz respeito a dois objetos; ao passo que o amor e o ódio às vezes visam só um objeto, como
quando dizemos que alguém ama ou detesta o vinho ou coisa semelhante. A segunda é que os dois
objetos a que diz respeito o amor são bons, pois o amante quer o bem a alguém como sendo
conveniente a este último. E os dois objetos a que diz respeito o ódio são um e outro de natureza má;
pois, quem odeia quer o mal a alguém como lhe sendo inconveniente a este. A ira, ao contrário,
considera como bom um objeto, a saber, a vindicta que deseja; e outro, como mal, a saber, o homem
nocivo, de quem se quer vingar. Por onde, é uma paixão composta, de certo modo, de paixões
contrárias.
E daqui se deduz claras AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 3 — Se a ira tem sua sede no concupiscível.
(III Sent., dist. XXVI, q. 1, a . 2).
O terceiro discute-se assim. — Parece que a ira tem a sua sede no concupiscível.

1. — Pois, como diz Túlio, a ira é uma espécie de desejo. Ora, o desejo, pertence ao concupiscível. Logo,
também a ira.

2. Demais — Agostinho diz que a ira se transforma no ódio. E Túlio, no livro supra-citado, que o ódio é a
ira inveterada. Ora, o ódio, como o amor, tem a sua sede no concupiscível. Logo, também a ira.

3. Demais — Damasceno e Gregório Nisseno dizem que a ira compõe-se da tristeza e do desejo. Ora,
tanto este como aquele têm sua sede no concupiscível. Logo, também a ira.
Mas, em contrário. — A potência concupiscível é diferente da irascível. Se pois a ira pertencesse ao
concupiscível, a potência irascível não tiraria dela a sua denominação.

SOLUÇÃO. — Como já dissemos, as paixões do irascível diferem das do concupiscível, por serem os
objetos destas o bem e o mal absolutos; ao passo que os objetos daquelas são o bem e o mal
acompanhados de certa dificuldade ou arduidade. Ora, como já dissemos, a ira visa dois termos: a
vindicta que deseja, e a pessoa de quem quer tirá-la. E em ambos esses casos ela requer uma certa
arduidade, pois o seu movimento não se manifesta senão com uma certa grandeza relativamente a
esses dois termos; pois, como diz o Filósofo, às coisas nulas ou muito pequenas não lhes damos nenhum
valor. Por onde é manifesto, que a ira não tem sua sede no concupiscível, mas, no irascível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Túlio denomina desejo o apetite de qualquer bem
futuro, sem levar em conta as condições de árduo ou não árduo. E, a esta luz, inclui a ira no desejo,
como desejo que é da vingança. E assim o desejo é comum ao irascível e ao concupiscível.

RESPOSTA À SEGUNDA. — Diz-se que a ira se transforma no ódio, não porque a mesma paixão,
numericamente, que era antes ira, venha a ser, em seguida, quando inveterada, o ódio; mas, isso se dá
em virtude da causalidade. Pois a ira, quando diuturna, causa o ódio.

RESPOSTA À TERCEIRA. — Diz-se que a ira se compõe da tristeza e do desejo, não como partes, mas
como causas. Pois, como já dissemos, as paixões do concupiscível são as causas das do irascível.

## Art. 4 — Se a ira é acompanhada da razão.
(IIª IIªº, q. 156, a . 4;VII Ethic., lect. VI).
O quarto discute-se assim. — Parece que a ira não é acompanhada da razão.

1. — Pois a ira, sendo uma paixão, tem sua sede no apetite sensitivo. Ora, este segue, não a apreensão
da razão, mas a da parte sensitiva. Logo, a ira não é acompanhada da razão.

2. Demais — Os brutos não tem razão, e contudo são susceptíveis de ira. Logo, esta não é acompanhada
daquela.

3. Demais — A embriaguez, que priva da razão, dá incremento à ira. Logo, esta não é acompanhada da
razão.
Mas, em contrário, diz o Filósofo, que a ira, de certo modo, é consecutiva à razão.

SOLUÇÃO. — Como já dissemos, a ira é o desejo da vingança. Ora, este importa uma relação entra a
pena que deve ser infligida e o mal que sofremos; donde o dizer o Filósofo, que quando pensamos que é
necessário atacar alguém de tal modo, logo ficamos irados. Ora, comparar e pensar é próprio da razão.
Logo, a ira vai de certo modo acompanhada da razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O movimento da potência apetitiva pode ir
acompanhado da razão, de dois modos. Ou quando a razão ordena, o que faz com que a vontade, dela
acompanhada, se chame apetite racional; ou quando a razão enuncia, e assim a ira é acompanhada da
mesma. Pois, diz o Filósofo, que a ira vai acompanhada da razão, não como ordenante, mas como
manifestativa da injúria. Porque o apetite sensitivo obedece à razão, não imediatamente, mas, mediante
a vontade.

RESPOSTA À SEGUNDA. — Os brutos têm um instinto natural que lhes foi infundido pela razão divina,
em virtude do qual são dotados de movimentos interiores e exteriores semelhantes aos da razão, como
já dissemos.

RESPOSTA À TERCEIRA. — Segundo já foi dito, a ira ouve de certo modo a razão, que nos anuncia que
fomos injuriados; mas não a ouve perfeitamente, porque não lhe observa a regra, no tirar a vingança.
Por onde, para haver ira é necessário um ato de razão e mais o impedimento da mesma. E por isso o
Filósofo diz, que os demasiado ébrios não ficam irados, por não serem susceptíveis de nenhum juízo da
razão; mas, quando pouco ébrios, podem ficar irados, como quem tem o juízo da razão, mas travado.

## Art. 5 — Se a ira é mais natural que a concupiscência.
(IIª-IIªº, q. 156, a . 4; De Verit., q. 25, a . 6, ad 4; VII Ethic., lect. VI).
O quinto discute-se assim. — Parece que a ira não é mais natural que a concupiscência.

1. — Pois, diz-se que é próprio do homem ser um animal manso por natureza. Ora, a mansidão opõe-se
à ira, como diz o Filósofo. Logo, esta não é mais natural que a concupiscência; antes, parece de todo
contrária à natureza do homem.

2. Demais — A razão se opõe à natureza, pois, não dizemos que quem age conforme a razão também o
faz de conformidade com a natureza. Ora, a ira é acompanhada da razão, ao passo que a concupiscência
não o é, como diz Aristóteles. Logo, esta é mais natural que aquela.

3. Demais — A ira é o desejo da vingança; ora, a concupiscência é sobretudo o apetite dos prazeres do
tato, a saber, os da mesa e os venéreos. Ora, estes são mais naturais ao homem que a vingança. Logo, a
concupiscência é mais natural que a ira.
Mas, em contrário, diz o Filósofo, que a ira é mais natural que a concupiscência.

SOLUÇÃO. — Chama-se natural ao que é causado pela natureza, como se vê claramente em Aristóteles.
Por onde, só pela sua causa é que podemos saber se uma paixão é mais ou menos natural. Ora, a causa
de uma paixão, como já dissemos, pode ser considerada de dois modos: em relação ao objeto e em
relação ao sujeito. — Se pois considerarmos a causa da ira e da concupiscência em relação ao objeto,
esta, sobretudo quanto referente aos prazeres da mesa e aos venéreos, é mais natural que aquela,
porquanto esses prazeres são mais naturais que a vingança. — Se porém considerarmos a causa da ira
relativamente ao sujeito, então ela é de certo modo mais natural, assim como, de certo modo, também
a concupiscência o é.
Pois, a natureza de um homem pode ser considerada, genérica, especificamente, ou segundo a
compleição própria do indivíduo. — Assim, se considerarmos a natureza genérica, que é a do homem
enquanto animal, então a concupiscência é mais natural que a ira; pois, é pela natureza comum em si
mesma, que o homem tem certa inclinação para desejar o que lhe conserva a vida, específica ou
individualmente. — Se porém considerarmos a sua natureza específica, i. é, enquanto racional, então a
ira é-lhe mais natural que a concupiscência, por ser, mais que esta, acompanhada da razão. Por isso, diz
o Filósofo, que é mais humano punir — o que diz respeito à ira — que ser manso, porque todos os seres
se insurgem naturalmente contra o que lhes é contrário e nocivo. — Se porém considerarmos a
natureza de um indivíduo na sua compleição própria, então a ira é mais natural que a concupiscência,
porque mais facilmente que a esta ou qualquer outra paixão, segue uma tendência natural, resultante
da compleição. Ora, é predisposto à ira quem tem compleição colérica; e a cólera move-se mais
rapidamente que os outros humores, comparável por isso ao fogo. Por onde, quem por compleição
natural tem predisposição para a ira, encoleriza-se mais prontamente do que cede à concupiscência o
que é para esta predisposto. Por isso, como diz o Filósofo, a ira, mais que a concupiscência, transmite-se
dos pais aos filhos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Podemos considerar no homem a compleição natural,
corpórea, que é equilibrada, e a razão em si mesma. Relativamente pois a essa compleição, não há no
homem, natural e especificamente, sobreexcelência da ira nem de qualquer outra paixão, por causa do
equilíbrio da compleição. Ao passo que os brutos, quanto mais se afastam dessa qualidade de
compleição para a disposição de uma compleição extrema, tanto mais ficam naturalmente dispostos ao
excesso de alguma paixão; assim, o leão, à audácia; o cão, à ira, a lebre, ao temor e assim por diante.
Quanto à razão, por outro lado, é natural ao homem tanto o irar-se como o ser manso, pois ela de certo
modo provoca a ira, indicando-lhe a causa e, de certo modo, a acalma, enquanto o irado não obedecer
totalmente ao império da razão, como já dissemos.

RESPOSTA À SEGUNDA. — A razão em si mesma também pertence à natureza do homem. Logo, por isso
mesmo que a ira é acompanhada da razão, é que, de certo modo, é natural ao homem.

RESPOSTA À TERCEIRA. — A objeção procede, quanto à ira e à concupiscência, relativamente ao objeto.

## Art. 6 — Se a ira é mais grave que o ódio.
(IIª-IIªº, q. 158, a . 4; De Malo, q. 12, a . 4).
O sexto discute-se assim. — Parece que a ira é mais grave que o ódio.

1. — Pois, como diz a Escritura (Pr 27, 4), a ira não tem misericórdia, nem o furor que rompe. Ora, o ódio
às vezes tem misericórdia. Logo, a ira é mais grave que o ódio.

2. Demais — Sofrer um mal e padecer dor por causa disso é mais que sofrer apenas. Ora, a quem odeia
lhe basta que a pessoa odiada sofra um mal; ao passo que o irado quer, além disso, que ela o saiba e
padeça com isso, como diz o Filósofo. Logo, a ira é mais grave que o ódio.

3. Demais — Quanto mais elementos concorrem para a estabilidade de uma coisa tanto mais estável ela
é; assim, o hábito mais permanente é o causado por muitos atos. Ora, a ira é causada pelo concurso de
várias paixões, como já se disse, o que se não dá com o ódio. Logo, é mais grave e mais estável que este.
Mas, em contrário, Agostinho compara o ódio a uma trave, e a ira a uma palha.

SOLUÇÃO. — A espécie e a natureza de uma paixão se deduzem do seu objeto. Ora, a ira e o ódio, de
um mesmo sujeito, têm o mesmo objeto; pois, como quem odeia deseja o mal ao odiado, assim o irado
aquele contra quem dirige a sua ira. Mas, não pela mesma razão, pois o primeiro deseja o mal do
inimigo, enquanto mal; ao passo que o segundo o deseja para aquele contra o qual está encolerizado,
não enquanto mal, mas enquanto tem um certo caráter de bem, i. é, enquanto o considera como justo,
por ser uma vingança. Por onde, como também antes já dissemos, o ódio consiste na aplicação do mal
ao mal; ao passo que a ira, na do bem ao mal. Ora, é manifesto que desejar o mal a alguém, sob a idéia
de justiça, encerra menos da essência do mal, do que lhe querer, pura e simplesmente, o mal. Pois, no
primeiro caso pode-se estar de acordo com a virtude da justiça, se for por obediência a uma prescrição
da razão. Ao passo que a ira só é má porque, no vingar-se, não obedece ao preceito da razão. Por onde,
é manifesto que o ódio é muito pior e mais grave que a ira.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dois elementos podemos levar em conta, na ira e no
ódio, a saber: aquilo mesmo que desejamos e a intensidade do desejo. — Quanto ao primeiro, a ira tem
mais misericórdia que o ódio. Pois, como o ódio deseja o mal de outrem, em si mesmo, não há medida
de mal que o sacie; porque, no dizer do Filósofo, as coisas desejadas em si mesmas são-no sem medida;
assim o avarento deseja as riquezas. Donde o dito da Escritura (Ecle 12, 16): O inimigo, se achar ocasião,
não se fartará de sangue. Ao passo que a ira não deseja o mal senão sob as aparências de justa
vingança; por onde, o irado se compadece quando o mal que lhe foi feito excede, na sua apreciação, a
medida da justiça. E, por isso, o Filósofo diz que o irado se compadece à vista dos muitos males sofridos
pelo seu adversário, ao passo que quem odeia de nenhum modo se compadece. — De outro lado,
quanto à intensidade do desejo, a ira exclui a misericórdia, mais que o ódio porque o seu movimento é
mais impetuoso, por causa da inflamação da cólera. Por isso, a Escritura logo acrescenta (Pr 27,
4): quem poderá suportar o ímpeto de um espírito concitado?

RESPOSTA À SEGUNDA. — Como já dissemos, o irado deseja o mal de alguém enquanto este se reveste
das aparências de uma vingança justa. Ora, a vingança se realiza pela aplicação de uma pena; e da
natureza desta é ser contrária à vontade, ser aflitiva e aplicada em expiação de alguma culpa. Por isso, o
irado deseja que aquele a quem castigou o sinta e o sofra e conheça que esse castigo lhe é aplicado por
causa da injúria assacada a outrem. Quem odeia porém nada disso lhe importa, porque deseja o mal de
outrem como tal. Ora, não é verdade que aquilo que nos causa pena seja pior. Pois, a injustiça e a
imprudência, sendo males não causam pena àqueles em quem existem, por serem voluntários, como diz
o Filósofo.

RESPOSTA À TERCEIRA. — O causado por muitas causas é mais estável quando as causas estão
compreendidas numa mesma noção; mas, uma causa pode prevalecer sobre muitas outras. Ora, o ódio
provém de causa mais permanente que a ira. Pois esta provém de uma comoção do ânimo, por causa de
um mal que nos foi feito; ao passo que o ódio, de uma disposição pela qual reputamos como nos sendo
contrário e nocivo o que odiamos. Por onde, como a paixão passa mais depressa que a disposição ou o
hábito, assim a ira se desvanece mais rápido que o ódio, embora também o ódio seja paixão
proveniente de uma determinada disposição. Por isso o Filósofo diz, que o ódio é mais incurável que a
ira.

## Art. 7 — Se a ira só tem por objeto os susceptíveis de justiça.
O sétimo discute-se assim. — Parece que a ira não tem por objeto só os susceptíveis de justiça.

1. — Pois, o homem não pode exercer a justiça para com os seres irracionais. Ora, às vezes o homem se
encoleriza contra seres irracionais; assim, quando um escritor, irado, arroja a pena ou o cavaleiro açoita
o cavalo. Logo, a ira não tem por objeto somente os seres susceptíveis de receber a justiça.

2. Demais — Não há justiça do homem para consigo mesmo nem para com tais coisas que a ele próprio
lhe dizem justiça, como diz o Filósofo. Ora, às vezes o homem se encoleriza contra si mesmo; assim o
penitente, por causa do pecado, donde o dizer a Escritura (Sl 4, 5): Irai-vos e não queirais pecar. Logo, a
ira não tem como objeto somente os seres susceptíveis de receberem a justiça.

3. Demais — Podemos praticar a justiça e a injustiça para com toda uma classe de pessoas ou toda uma
comunidade; p. ex., quando uma cidade lesa a alguém. Ora, a ira não recai sobre nenhuma classe de
pessoas, mas só sobre um indivíduo singular, como diz o Filósofo. Logo, a ira não tem como objeto
próprio aqueles somente que são susceptíveis de justiça ou injustiça.
Mas o contrário se pode conclui do que diz o Filósofo.

SOLUÇÃO. — Como já dissemos, a ira busca o mal na medida em que este exerce a função de justiça
vindicativa. Por onde a ira é relativa aos mesmos a que o é a justiça e a injustiça. Pois, é próprio da
justiça exercer a vingança; e lesar a outrem é o constitutivo da injustiça. Assim, tanto pela causa, que é a
lesão praticada por outrem, como também por parte da vindicta a tirar dele, o que visa o irado, é
manifesto que a ira tem o mesmo objeto que a justiça e a injustiça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como já se disse, a ira, embora seja acompanhada da
razão pode porém existir também nos brutos, carecentes de razão, enquanto movidos por um instinto
natural mediante a imaginação à prática de atos semelhantes aos atos racionais. Assim pois, tendo o
homem razão e imaginação, de dois modos pode nele nascer o movimento da ira. — Primeiro, quando
só a imaginação denuncia a lesão. E assim algum movimento de ira nasce mesmo contra seres
irracionais e inanimados, à semelhança do movimento originado nos animais contra tudo o que lhes seja
nocivo. — De outro modo, quando a razão é a que denuncia a lesão. E assim, como diz o Filósofo, de
nenhum modo pode se exercer a ira contra seres insensíveis nem contra os mortos; quer por não
sentirem, qualidade que sobretudo supõe os irados naqueles contra quem se encolerizam; quer
também por não ser possível exercer contra eles a vindicta, pois não podem cometer nenhuma injúria.

RESPOSTA À SEGUNDA. — Como diz o Filósofo, o homem pode exercer para consigo mesmo uma certa
justiça e injustiça metafórica: é enquanto a razão rege o irascível e o concupiscível. E neste sentido
também se diz que o homem tira vindicta de si mesmo; e por conseqüência se encoleriza contra si
mesmo. Mas própria e essencialmente falando, ninguém pode irar-se contra si mesmo.

RESPOSTA À TERCEIRA. — A diferença única assinalada pelo Filósofo entre o ódio e a ira está em o ódio
poder referir-se a uma classe de pessoas e assim odiamos todo gênero de ladrões; ao passo que a ira
não pode recair senão sobre um indivíduo singularmente considerado. E a razão disso está em o ódio ser
causado porque a qualidade de um ser é apreendida como dissonante da nossa disposição; e isto pode
dar-se tanto em universal como em particular. Enquanto que a ira é causada por alguém que, com um
ato seu, nos lesou; ora todos os atos dizem respeito ao singular. Por isso a ira versa sempre sobre algo
de singular. — E quando foi toda a cidade que nos lesou, toda ela é considerada como um indivíduo
singular.

## Art. 8 — Se Damasceno assinala convenientemente três espécies de ira, a saber: o fel, a mania e o furor.
O oitavo discute-se assim. — Parece que Damasceno assinala inconvenientemente três espécies de
ira: o fel, a mania e o furor.

1. — Pois, as espécies de nenhum gênero se diversificam por um acidente, Ora, o fel, a mania e o furor
se diversificam acidentalmente, pois, chama-se fel o princípio do movimento da ira; a ira permanente
chama-se mania; e por fim, o furor é a ira que se vinga num certo tempo. Logo, não são espécies
diferentes de ira.

2. Demais — Túlio diz, que o arrebatamento se chama em grego, θυμός é uma ira que ora nasce e ora
desaparece. Ora, θυμός, segundo Damasceno, é o mesmo que o furor. Logo, este não precisa de tempo
para a vindicta mas se extingue com o tempo.

3. Demais — Gregório estabelece três graus na ira: a ira sem palavras, a ira acompanhada de palavras e
a ira com palavras expressas, de conformidade com aquelas três partes do dito do Senhor no Evangelho
(Mt 5, 22):o que se ira contra seu irmão, em que se refere à ira sem palavras; e depois acrescenta: e o
que disser a seu irmão: Raca, onde toca na ira acompanhada da palavra, mas não ainda com sentido
pleno; e depois acrescenta: e o que lhe disser a seu irmão: És um tolo, onde a palavra se completa pelo
discurso perfeito. Logo, Damasceno dividiu insuficientemente a ira, não compreendendo nela nada do
que se refere à palavra.
Mas, em contrário, é a autoridade de Damasceno e de Gregório Nisseno (Nemésio).

SOLUÇÃO. — As três espécies de ira, na divisão de Damasceno e também de Gregório Nisseno
(Nemésio) se fundam naquilo que intensifica a ira. E isto pode dar-se de três modos. Primeiro, pela
facilidade do movimento mesmo; e essa ira ele a denomina fel, porque se acende facilmente. Segundo,
pela tristeza que causa a ira, que perdura muito tempo na memória; e esta pertence à mania, palavra
derivada de permanecer. Terceiro, por aquilo que o irado deseja, a saber, a vindicta; e esta pertence
ao furor, que não se aplaca enquanto não pune. Por onde o Filósofo chama a certos irados agudos, por
se irarem prontamente; a certos outros, amargos, por conservarem a ira por muito tempo; e certos,
enfim, difíceis, porque não descansam enquanto não punem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tudo aquilo que dá à ira algum complemento não se lhe
refere acidentalmente. Donde, nada impede que nisso nos fundemos para especificá-la.

RESPOSTA À SEGUNDA. — O arrebatamento, que Túlio introduz, parece antes pertencer à primeira
espécie de ira, que se consuma com a prontidão desta, do que ao furor. Nada porém impede que
o θυμός grego, que se chama em latim furor, importe numa e noutra coisa: a prontidão no irar-se e a
firmeza de propósito em punir.

RESPOSTA À TERCEIRA. — Os graus dessa ira se distinguem pelo efeito da mesma; não porém pela
diversa perfeição do movimento mesmo da ira.