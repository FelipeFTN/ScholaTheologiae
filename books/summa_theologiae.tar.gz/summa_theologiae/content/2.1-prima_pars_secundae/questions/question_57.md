# Questão 57: Da distinção entre as virtudes intelectuais.
Em seguida devemos tratar da distinção entre as virtudes. E primeiro, quanto às virtudes intelectuais.
Segundo, quanto às morais. Terceiro, quanto às teológicas.
Sobre a primeira questão seis artigos se discutem:

## Art. 1 — Se os hábitos intelectuais especulativos são virtudes.
(III Sent., dist. XXIII, q. 1, a. 4, qª 1; De Virtut., q. 1 a. 7).
O primeiro discute-se assim. — Parece que os hábitos intelectuais especulativos não são virtudes.

1. — Pois, a virtude é um hábito operativo, como já se disse. Ora, os hábitos especulativos não são
operativos, pois o especulativo difere do prático ou operativo. Logo, os hábitos intelectuais
especulativos não são virtudes.

2. Demais. — A virtude visa tornar o homem feliz ou beato, pois, a felicidade é o prêmio da virtude,
como diz Aristóteles. Ora, os hábitos intelectuais não consideram os atos humanos ou os outros bens
humanos pelos quais o homem alcança a felicidade, mas antes, as coisas naturais e divinas. Logo tais
hábitos se não podem denominar virtudes.

3. Demais. — A ciência é um hábito especulativo. Ora, a ciência e a virtude distinguem-se entre si como
gêneros diversos não subalternados, segundo se vê no Filósofo. Logo, os hábitos especulativos não são
virtudes.
Mas, em contrário. — Só os hábitos especulativos consideram o necessário e que não pode existir de
outro modo. Ora, o Filósofo inclui, certas virtudes intelectuais na parte da alma que considera o
necessário e que não pode ter outro modo de existir. Logo, os hábitos intelectuais especulativos são
virtudes.

SOLUÇÃO. — Toda virtude, sendo ordenada para o bem, como já dissemos, de duplo modo um hábito
pode ser considerado virtude, conforme também já ficou dito. Ou porque dá a faculdade de obrar
retamente; ou porque, com a faculdade, torna também bom o uso da mesma. Ora, este último caso,
segundo já ficou dito, só pertence aos hábitos referentes à parte apetitiva, porque a faculdade apetitiva
da alma é que nos faculta usar de todas as potências e hábitos.
Como pois os hábitos intelectuais especulativos não aperfeiçoam a parte apetitiva, nem de certo modo,
lhe digam respeito, senão só à intelectiva, podem-se chamar virtudes, enquanto tornam capaz a
faculdade da sua ação reta, que é a consideração da verdade, atividade reta do intelecto. Mas não se
chamam virtudes, conforme o segundo modo, quase fazendo com que usemos bem da potência ou do
hábito. Pois, não é por termos o hábito da ciência especulativa que nos inclinaremos a usar dele; esse
hábito só nos confere a faculdade de especular a verdade em relação àquilo de que temos ciência. Mas
só a moção da vontade é que nos leva a usar da ciência habitual. Por onde, a virtude que aperfeiçoa a
vontade, como a caridade ou a justiça, também nos leva a empregar retamente os hábitos especulativos
de que tratamos. E assim sendo, pode haver mérito também nos atos desses hábitos, se forem feitos
com caridade; e neste sentido Gregório diz que a vida contemplativa tem maior mérito que a ativa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Há uma dupla atividade: a exterior e a interior. Ora, o
que é prático ou operativo, e se opõe ao especulativo, se funda na atividade exterior, ao que não se
ordena o hábito especulativo. Mas este se ordena à atividade interna do intelecto, consistente em
especular a verdade; e por este lado é um hábito operativo.

RESPOSTA À SEGUNDA. — De dois modos se diz que a virtude visa sobre certos respeitos. — De um
modo, como sendo estes, objetos. E então, as referidas virtudes especulativas não respeitam o por que
o homem se torna feliz; a menos que a expressão por que exprima a causa eficiente, ou o objeto da
felicidade completa, que é Deus, objeto supremo da especulação. — De outro modo, como sendo atos,
e então as virtudes intelectuais visam o por que o homem se torna feliz; quer por poderem os atos
dessas virtudes ser meritórias, como já se disse; quer por serem uma incoação da perfeita beatitude,
consistente na contemplação da verdade, conforme ficou dito acima.

RESPOSTA À TERCEIRA. — A ciência se opõe à virtude tomada na segunda acepção e pertencente à
potência apetitiva.

## Art. 2 — Se se distinguem convenientemente três virtudes intelectuais especulativas, a saber: a sapiência, a ciência e o intelecto.
(De Virtut., q. 1, a. 12).
O segundo discute-se assim. — Parece que não se distinguem convenientemente três virtudes
intelectuais especulativas, a saber: a sapiência, a ciência e o intelecto.

1. — Pois, a espécie não deve entrar numa mesma divisão, como o gênero. Ora, a sapiência é uma
espécie de ciência, como já se disse. Logo, aquela não deve, com esta, entrar em o número das virtudes
intelectuais.

2. Demais. — Na distinção das potências, dos hábitos e dos atos, quanto aos seus objetos, considera-se
principalmente a razão formal destes, como do sobredito se colhe. Logo, diversos hábitos não se
diversificam pelo objeto material, mas pela razão formal deste. Ora, o princípio da demonstração é a
razão de se conhecerem as conclusões. Logo, o intelecto dos princípios não deve ser considerado como
um hábito ou virtude diferentes da ciência das conclusões.

3. Demais. — Chama-se virtude intelectual à existente na parte racional, por essência. Ora, a razão,
mesmo a especulativa, raciocina silogizando, tanto demonstrativa como dialeticamente. Logo, assim
como a ciência causada pelo silogismo demonstrativo é considerada virtude intelectual especulativa,
assim também o é a opinião.
Mas, em contrário, o Filósofo considera só três virtudes intelectuais especulativas: a sapiência, a ciência
e o intelecto.

SOLUÇÃO. — Como já dissemos, é pela virtude intelectual especulativa que o intelecto especulativo se
aperfeiçoa para considerar a verdade, pois nisto consiste a retidão da sua atividade. Ora, a verdade
pode ser conhecida sob duplo aspecto: por si mesma, ou por um intermediário. — Enquanto conhecida
por si mesma, desempenha o papel de princípio e é percebida imediatamente pelo intelecto. E por isso
o hábito, que aperfeiçoa a inteligência para tal conhecimento da verdade, chama-se intelecto, que é o
hábito dos princípios.
Por outro lado, a verdade enquanto conhecida por um intermediário, não é apreendida imediatamente
pelo intelecto, mas pela perquirição da razão e desempenha o papel de termo. E isto pode ser de dois
modos: como o que, num determinado gênero, é último, e como o que é último relativamente ao
conhecimento humano total. — E como aquilo que é conhecido por nós posteriormente é por natureza
primário e mais conhecido, como já se disse, o que é último relativamente ao conhecimento humano
total é o que por natureza é primário e cognoscível por excelência. Ora, sobre isso versa a sapiência, que
considera as causas altíssimas, segundo já se disse. Por onde, ela julga e ordena convenientemente
todas as coisas; pois, o juízo perfeito e universal não é possível senão pela resolução às causas
primeiras. — A ciência, por fim, aperfeiçoa o intelecto para o que é último num determinado gênero de
cognoscíveis. Por onde, tantos são os diversos hábitos das ciências quanto os diversos gêneros de
cognoscíveis; ao passo que a sapiência é uma só.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A sapiência é uma espécie de ciência, enquanto tem o
que é comum a todas as ciências, i. é, enquanto pelos princípios demonstra as conclusões. Mas como
tem sobre as outras ciências algo que lhe é próprio, por julgar de tudo, e não só quanto às conclusões,
mas também quanto aos primeiros princípios, por isso tem a natureza de virtude mais perfeita que a
ciência.

RESPOSTA À SEGUNDA. — Quando o objeto, por natureza se refere por um só ato, a uma potência ou a
um hábito, não se distinguem então os hábitos ou as potências pela razão do objeto e pelo objeto
material; assim, à mesma potência visiva pertence ver a cor e a luz, que é a razão de vermos a cor, e é
vista simultaneamente com esta. Ora, os princípios da demonstração podem ser considerados
separadamente, sem considerarmos as conclusões. Também podem considerar-se simultaneamente
com estas, enquanto são conducentes a elas. Ora, considerar os princípios, deste segundo modo, é
próprio da ciência, que considera também as conclusões. Considerar porém os princípios, em si
mesmos, é próprio do intelecto. Por onde, quem refletir retamente verá que essas três virtudes não se
distinguem, por igual, entre si, mas numa certa ordem. Pois, assim como num todo potencial, uma parte
é mais perfeita que outra, como, p. ex., a alma racional o é mais que a sensível e esta, que a vegetativa;
assim também a ciência depende do intelecto como do principal; e ambos, da sapiência, como do
principalissímo, e compreende em si o intelecto e a ciência, pois julga das conclusões das ciências e dos
princípios das mesmas.

RESPOSTA À TERCEIRA. — Como já dissemos, o hábito da virtude se refere determinadamente ao bem e
de nenhum modo ao mal. Ora, o bem do intelecto é a verdade, e o mal, a falsidade. Por onde, só se
chamam virtudes intelectuais os hábitos pelos quais sempre dizemos a verdade e nunca, a falsidade. Ao
passo que a opinião e a suspeita podem recair sobre a verdade e a falsidade, e portanto não são
virtudes intelectuais, como já se disse.

## Art. 3 — Se a arte é uma virtude intelectual.
(De Virtut., q. 1, a. 7; VI Ethic., lect III).
O terceiro discute-se assim. — Parece que a arte não é uma virtude intelectual.

1. — Pois, diz Agostinho, que ninguém pode usar mal da virtude. Ora, podemos usar mal da arte; tal é o
caso do artífice que obra mal de acordo com a ciência da sua arte. Logo, a arte não é uma virtude.

2. Demais. — Não há virtude de virtude. Ora, há uma virtude da arte, como já se disse. Logo, a arte não
é uma virtude.

3. Demais. — As artes liberais são mais excelentes que as mecânicas. Ora, assim como estas são práticas,
aquelas são especulativas. Logo, se a arte fosse uma virtude intelectual, devia ser enumerada entre as
virtudes especulativas.
Mas, em contrário, o Filósofo embora considere a arte como virtude, não a enumera contudo entre as
virtudes especulativas, cujo sujeito é, diz, a parte científica da alma.

SOLUÇÃO. — A arte não é mais que a razão reta de acordo com a qual fazemos certas obras. E a
bondade destas não consiste em o apetite humano se comportar de um determinado modo, mas em ser
boa, em si mesma, a obra feita. Pois, o que importa para o louvor do artista, como tal, não é a vontade
com que faz a obra, senão a qualidade da obra feita. Por onde, propriamente falando, é um hábito
operativo.
E contudo convém em algo com os hábitos especulativos. Pois, também a estes importa o modo de ser
do objeto considerado, mas não como se comporta o apetite humano em relação a ele. Assim, desde
que o geômetra demonstre a verdade, pouco importa como se comporte quanto à parte apetitiva, se
está alegre ou irado; e o mesmo se dá com o artífice, segundo já se disse. Por onde, a arte supõe a
noção de virtude do mesmo modo que os hábitos especulativos; pois, nem estes e nem aquela fazem a
obra boa quanto ao uso — o que é próprio da virtude que aperfeiçoa o apetite mas só quanto à
faculdade de agir retamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A má obra artística de quem possui uma arte não
provém desta, mas é antes contra ela; do mesmo modo que quem mente, sabendo qual é a verdade,
não fala de acordo, mas contra a sua ciência. Por onde, assim como a ciência sempre diz respeito ao
bem, conforme já dissemos, assim também a arte, que por isso é considerada virtude. Afasta-se
entretanto da noção perfeita de virtude, porque não produz o bom uso, em si, para o que é necessária
outra condição; embora o bom uso não possa existir sem a arte.

RESPOSTA À SEGUNDA. — Como a boa vontade, aperfeiçoada pela virtude moral é necessária para o
homem usar bem da sua arte, o Filósofo diz que há virtude moral na arte, na medida em que uma certa
virtude moral é necessária para o bom uso da mesma. Pois é manifesto que o artífice, pela justiça, que
torna a vontade reta, se inclina a fazer uma obra fiel.

RESPOSTA À TERCEIRA. — Mesmo no que é especulativo entra algo de prático, de certo modo; p. ex., a
construção de um silogismo ou de uma oração congruente, ou a ação de numerar ou medir. E portanto,
todos os hábitos especulativos ordenados a essas operações da razão chamam-se, por semelhança,
artes liberais, para se diferençarem das artes ordenadas às obras exercidas pelo corpo, que são, de
algum modo, servis, pois estar o corpo servilmente sujeito à alma, e ser o homem, pela alma, livre. Ao
passo que as ciências não ordenadas a nenhuma dessas obras se chamam absolutamente, ciências e não
artes. Nem é necessário, por serem as artes liberais mais nobres, que mais se lhes adapte a noção de
arte.

## Art. 4 — Se a prudência é virtude diferente da arte.
(IIª-IIª, q. 47, a.4, ad 2; a. 5; De Virtut., q. 1, a. 12; VI Ethic., lect IV).
O quarto discute-se assim. — Parece que a prudência não é virtude diferente da arte.

1. — Pois, a arte é a razão reta de acordo com a qual fazemos certas obras. Ora, obras genericamente
diversas não fazem com que uma arte deixe de o ser, pois há artes diversas que se ocupam com obras
muito diversas. Ora, como também a prudência é uma certa razão reta das obras, parece que também
ela deve ser considerada como arte.

2. Demais. — A prudência convém mais com a arte que os hábitos especulativos, pois tanto estes como
aquela dizem respeito ao que se realiza contingentemente, como já se diss. Ora, certos hábitos
especulativos se chamam artes. Logo e com maior razão, a prudência deve ser considerada uma arte.

3. Demais. — É próprio da prudência aconselhar retamente, como já se disse. Ora, também em certas
artes, como a militar, a governativa e a medicinal, é preciso haver conselho. Logo, a prudência não se
distingue da arte.
Mas, em contrário, o Filósofo distingue a prudência da arte.

SOLUÇÃO. — As virtudes se distinguem pelas noções diversas que elas realizam. Pois, como já se disse,
hábitos há que se fundamentam como virtudes só pelo darem a faculdade de obrar retamente, outros,
porque não só dão essa faculdade, mas também o uso. Ora, a arte dá apenas a faculdade de obrar
retamente, porque não diz respeito ao apetite. Ao passo que a prudência, não só dá a referida
faculdade, como também o uso; pois, diz respeito ao apetite por lhe pressupor a retidão.
E a razão desta diferença é que a arte é a razão reta que nos dirige naquilo que produzimos; ao passo
que a prudência é a razão reta que nos dirige quando agimos. Ora, produzir e agir diferem; pois, como
se disse, produzir implica um ato transitivo para a matéria exterior, como, edificar, cortar e outros;
enquanto que agir implica um ato imanente no agente, como ver, querer e outros. Assim que, a
prudência está para os atos humanos, consistentes no uso das potências e dos hábitos, como a arte está
para o que produzimos exteriormente. Ora, a perfeição e a retitude do ato depende dos princípios que
servem de base ao silogismo da razão; do mesmo modo que, como já dissemos, a ciência depende do
intelecto, que é o hábito dos princípios e o pressupõe. Ora, nos atos humanos, os fins desempenham o
mesmo papel que os princípios nas ciências especulativas, como já se disse. Por onde, a prudência, que
é a razão reta, que nos guia nas nossas ações, exige estejamos bem dispostos em relação aos fins, o que
se dá pelo apetite reto; e, portanto, ela também supõe a virtude moral, que torna reto o apetite. Ora, a
bondade das obras da arte não é a do apetite humano, mas a dessas obras mesmas; e por isso a arte
não pressupõe o apetite reto. E daí vem que o artífice que peca voluntariamente é mais digno de louvor
que outro que o faz involuntariamente; ao contrário quem peca voluntariamente vai contra a prudência
mais que quem o faz involuntariamente; porque a prudência exige, por essência, a retidão da vontade, o
que não se dá com a arte. Por onde consta com clareza que a prudência é uma virtude distinta da arte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os diversos gêneros das coisas artificiais são todos
exteriores ao homem, e por isso não diversificam a noção de virtude. Mas a prudência, sendo a razão
reta dos próprios atos humanos, a diversifica, como dissemos.

RESPOSTA À SEGUNDA. — A prudência convém mais com a arte que os hábitos especulativos, quanto
ao sujeito e à matéria; pois ambas pertencem à parte opinativa da alma e dizem respeito ao que sucede
contingentemente. Mas, pela noção de virtude, a arte convém mais com os hábitos especulativos, que
com a prudência, como se disse.

RESPOSTA À TERCEIRA. — A prudência aconselha com acerto sobre o pertencente à totalidade e ao
último fim da vida humana. Enquanto certas artes aconselham apenas sobre o pertencente aos seus fins
próprios. Por isso, os bons conselheiros em matéria bélica ou náutica, se consideram chefes prudentes
ou pilotos e não simplesmente prudentes, como aqueles, e só esses, que aconselham sobre o
pertencente à totalidade da vida.

## Art. 5 — Se a prudência é uma virtude necessária ao bem viver.
(IIª IIª, q. 51, a. 3, ad 3; De Virtut., q. 1, a. 6).
O quinto discute-se assim. — Parece que a prudência não é uma virtude necessária ao bem viver.

1. — Pois, assim como a arte está para o que nós podemos produzir, de que ela é a razão reta, assim
está a prudência para os nossos atos, relativamente aos quais consideramos a vida do homem, pois, a
prudência é a razão reta desses atos, como já se disse. Ora, em relação às coisas que podemos produzir,
a arte só é necessária para que venham a ser feitas, e não depois de o terem sido. Logo, também a
prudência não é necessária ao homem para o bem viver, uma vez que ele é virtuoso, senão talvez
somente para que venha a sê-lo.

2. Demais. — Pela prudência aconselhamos retamente, como já se disse. Ora, o homem pode agir não
só pelo bom conselho próprio, mas também pelo alheio. Logo, não é necessário, para bem viver, o
homem ter prudência, bastando seguir o conselho dos prudentes.

3. Demais. — É pela virtude intelectual que somos levados a dizer sempre a verdade e nunca a falsidade.
Ora, isto parece que não se dá com a prudência, pois não é humano que, no aconselhar sobre o que
devemos fazer, nunca erremos, pois os atos humanos são contingentes e podem realizar-se de modos
diversos, e por isso diz a Escritura (Sb 9, 14): Porque os pensamentos dos mortais são tímidos e incertas
as nossas providências. Logo, parece que a prudência não deve ser considerada virtude intelectual.
Mas, em contrário, a Escritura a enumera entre as demais virtudes necessárias à vida humana, quando
diz da divina sabedoria (Sb 8, 7): ensina a temperança e a prudência e a justiça e a fortaleza, que é o
mais útil que há na vida para os homens.

SOLUÇÃO. — A prudência é virtude soberanamente necessária à vida humana. Pois, viver bem consiste
em obrar bem. Ora, para obrarmos bem é necessário levarmos em conta não só o que façamos, mais
ainda como o façamos: i. é, devemos obrar segundo uma eleição reta e não só pelo ímpeto ou pela
paixão. Ora, como a eleição visa os meios, a sua retitude exige dois elementos: o fim devido e o que
convenientemente se lhe ordena. Ora, ao fim devido o homem se dispõe convenientemente pela
virtude, que aperfeiçoa a parte apetitiva da alma, cujo objeto é o bem e o fim. E para que o homem se
ordene retamente ao fim devido é preciso seja diretamente disposto pelo hábito racional, pois
aconselhar e eleger, que dizem respeito aos meios, são atos da razão. E portanto é necessário haver
nesta alguma virtude intelectual, que aperfeiçoa a razão, pela qual ela procede acertadamente em
relação aos meios. E tal virtude é a prudência, que portanto é uma virtude necessária à bem viver.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O bem da arte é considerado, não no artífice mesmo,
mas antes, no artificiado, desde que a arte é a razão reta das coisas factíveis. Ora, a facção transitiva
para a matéria exterior, não constitui a perfeição do faciente, mas a do feito, assim como o movimento
é ato móvel: pois, a arte versa sobre as coisas factíveis, mas o bem da prudência é relativo ao próprio
agente, cuja perfeição é o seu próprio ato; pois, a prudência é a razão reta do nosso agir, como já se
disse. Por onde, a arte não exige obre o artífice retamente, mas faça obra boa. Antes se exigiria que o
próprio artificiado obrasse bem; isto é, que, p. ex., a faca cortasse bem ou a serra serrasse bem, se fosse
próprio a tais instrumentos o agir e não, antes, o serem dirigidos, pois não tem o domínio dos seus atos.
Logo, a arte não é necessária ao artífice para viver bem, mas só para produzir o bom artificiado e
conservá-lo. Ao passo que a prudência é necessária ao homem para viver bem e não só para ser bom.

RESPOSTA À SEGUNDA. — Quando o homem obra, não de acordo com a razão própria, mas movido
pelo conselho de outrem, a sua obra ainda não é absolutamente perfeita, isto é, quanto à razão
dirigente e quanto ao apetite motor. Por onde, se obra bem não o faz de modo absolutamente bom,
que é viver bem.

RESPOSTA À TERCEIRA. — A verdade do intelecto prático é tomada em sentido diferente da do
especulativo, como já se disse. Pois, a verdade do intelecto especulativo supõe a sua conformidade com
a coisa. E como ele não pode conformar-se infalivelmente com as coisas contingentes mas só com as
necessárias, a virtude intelectual é constituída, não por qualquer hábito especulativo relativo a coisas
contingentes, mas só pelos que respeitam o necessário. A verdade do intelecto prático, por outro lado, é
relativa à conformidade com o apetite reto; e esta não tem lugar no que respeita às coisas necessárias,
não feitas pela vontade humana, mas só no que diz respeito às contingentes, que podem ser feitas por
nós, quer por atos internos, que por produção externa. E portanto, a virtude do intelecto prático é
relativa só as coisas contingentes, e constitui a arte, quando se trata dos factíveis e a prudência, quando
diz respeito aos nossos atos.

## Art. 6 — Se convenientemente adjungem-se à prudência a eubulia, a sínese e a gnome.
(IIª IIª, q. 48, 51; III Sent., dist. XXXIII, q. 3, a. 1, qª 3, 4; De Virtut., q 1, a. 12, ad 26; q. 5, a. 1).
O sexto discute-se assim. — Parece que inconvenientemente se adjungem a prudência a eubulia, a
sínese e a gnome.

1. — Pois, a eubulia é um hábito pelo qual aconselhamos bem, como já se disse. Ora, aconselhar
retamente é próprio da prudência, como no mesmo livro se diz. Logo, a eubulia não é uma virtude
adjunta à prudência, mas antes, é a prudência mesma.

2. Demais. — Pertence ao superior julgar dos inferiores. Logo, virtude suprema é aquela a que pertence
o ato do julgamento. Ora, a sínese é a que julga bem. Logo, não é virtude adjunta à prudência, mas
antes, é a principal.

3. Demais. — Como são diversas as coisas que devemos julgar, diversas também são as sobre as que
devemos aconselhar. Ora, há uma só virtude — a eubulia, relativa a tudo sobre o que devemos
aconselhar. Logo, para julgarmos bem do que devemos agir não é necessário introduzir, alem da sínese,
outra virtude, a saber, a gnome.

4. Demais. — Túlio atribui à prudência três outras partes, a saber: a memória do pretérito, a inteligência
do presente e a providência do futuro. E Macróbio também lhe induz certas outras partes, a saber: a
cautela, a docilidade e outras. Logo, parece que não só as virtudes supranumeradas se adjungem a
prudência.
Mas, em contrário, é a autoridade do Filósofo, que ensina serem estas três virtudes adjuntas à
prudência.

SOLUÇÃO. — De todas as potências ordenadas a principal é a que se ordena para o ato principal. Ora, há
três atos da razão relativos aos atos humanos: o primeiro é aconselhar; o segundo, julgar; o terceiro,
mandar. Ora, os dois primeiros correspondem aos atos do intelecto especulativo, que são inquirir e
julgar, pois, o conselho é uma certa inquirição. Mas o terceiro ato é próprio do intelecto prático,
enquanto operativo; pois, a razão não pode mandar o que não pode ser feito pelo homem. Ora, é
manifesto que o ato principal, em relação ao que o homem faz, e ao qual os outros se ordenam, é
mandar. E portanto, à prudência, virtude a que é próprio o mandar acertadamente, adjungem-se, como
a principal, e na qualidade de secundárias, a eubulia, que aconselha retamente, a sínese e a gnome,
partes da potência judicativa, de cuja distinção mais abaixo se tratará.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A prudência aconselha retamente, não por um ato
imediato seu, mas por aperfeiçoar esse ato, mediante a eubulia, virtude que lhe é sujeita.

RESPOSTA À SEGUNDA. — O juízo sobre os atos ordena-se a um fim ulterior; pois pode se dar que
julguemos retamente sobre o que devemos fazer sem contudo retamente o executarmos. Por onde, o
último complemento está em a razão ordenar acertadamente sobre o que temos que fazer.

RESPOSTA À TERCEIRA. — O juízo sobre cada coisa se faz pelos seus princípios próprios. Ora, a
inquisição ainda não se realiza por tais princípios, porque se já os tivéssemos, não havia mais
necessidade dela, pois o seu objeto estaria descoberto. E portanto, ao passo que só uma virtude se
ordena a aconselhar com acerto, duas se ordenam a julgar bem, por não haver distinção nos princípios
comuns, mas só nos próprios. Por isso é que, na ordem especulativa, só uma é a dialética, que perquire
sobre tudo; ao passo que as ciências demonstrativas, que são judicativas, são diversas, por terem
objetos diversos. A sínese porém e a gnome diferem pelas regras diversas por que julgam. Pois, a sínese
julga dos atos, segundo a lei comum; ao passo que a gnome o faz, segundo a razão natural, nos casos
em que a lei comum é deficiente, como se esclarecerá melhor a seguir

RESPOSTA À QUARTA. — A memória, a inteligência, a providência e, semelhantemente, a cautela, a
docilidade e virtudes tais não são diversas da prudência; mas, de certo modo se lhe comparam como
partes integrantes, enquanto todas são necessárias à perfeição dela. E há também certas partes
subjetivas ou espécies da prudência, como a econômica, a arte de reinar e outras tais. Mas, as três
virtudes em questão são umas quase partes potenciais da prudência, por se lhe ordenarem como o
secundário ao principal. E sobre isto mais adiante se dirá.