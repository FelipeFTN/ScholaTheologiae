# Questão 42: Do objeto do temor
Em seguida devemos tratar do objeto do temor. E sobre esta questão seis artigos se discutem:

## Art. 1 — Se o bem é objeto do temor.
(IIª IIªe, q. 19, a . 1, 2).
O primeiro discute-se assim. — Parece que o bem é objeto do temor.

1. — Pois, como diz Agostinho, não tememos senão perder o objeto amado quando possuído, ou não
possuí-lo quando esperado. Ora, o que amamos é bom. Logo, o temor tem o bem como objeto próprio.

2. Demais — O Filósofo diz, que é terrível o poder, e o governar a outrem. Ora, o poder é um bem. Logo,
o bem é o objeto do temor.

3. Demais — Em Deus não pode haver nenhum mal. Ora, é-nos ordenado temê-lo, conforme a Escritura
(Sl 33, 10): Temei ao Senhor todos vós, os seus santos. Logo, também há temor do bem.
Mas, em contrário, diz Damasceno, que o temor é relativo ao mal futuro.

SOLUÇÃO. — O temor é um movimento da potência apetitiva, da qual é próprio buscar e evitar um
dado objeto, como diz Aristóteles. Ora, o que ela busca é o bem, e o que evita é o mal. Por onde,
qualquer movimento dessa potência que importe em buscar um objeto, há de sempre tê-lo por bom; e
qualquer que implique a fuga, há de tê-lo por mau. Por onde, como o temor implica a fuga, há de
primariamente e em si mesmo ter o mal como seu objeto próprio.
Mas, também pode visar o bem, na medida em que este tiver relação com o mal. — E isto pode dar-se
de dois modos. De um, enquanto o mal priva do bem; pois é por ser privativo deste que é mal. Por onde,
quando fugimos do mal como tal, necessariamente o fazemos porque ele nos priva do bem amado, que
buscamos. E por isso, disse Agostinho antes, que a causa única de temermos é não querermos perder o
bem amado. — De outro modo, o bem está para o mal, como a causa deste, a saber, enquanto que um
determinado bem tem a virtude de produzir qualquer mal no bem amado. Por onde, como a esperança
visa, segundo já dissemos, dois termos, a saber, o bem para o qual tende, e aquilo pelo que espera
haver de alcançar o bem desejado, assim também o temor visa, dois termos, a saber, o mal de que foge
e o bem que, pela sua virtude, pode infligir o mal.
E é deste modo que Deus é temido pelo homem, enquanto pode infligir uma pena, espiritual ou
corpórea. E também do mesmo modo é temido o poder de um homem, sobretudo quando lesado, ou
injusto, porque então é levado imediatamente a causar um mal. Assim, tememos ainda quem tem poder
sobre nós, i. é, tememos depender de outrem, de maneira que isso lhe dê o poder de nos fazer mal; tal
é o caso de quem, sendo cônscio de um crime, teme que outrem revele.
E daqui se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 2 — Se há temor do mal natural.
O segundo discute-se assim. — Parece que não há temor de mal natural.

1. — Pois, diz o Filósofo, que o temor nos desperta o conselho. — Ora, não deliberamos sobre o que
acontece naturalmente, como diz o mesmo autor. Logo, não há temor do mal natural.

2. Demais — Os males naturais como a morte e outros, estão sempre iminentes ao homem. Se pois
houvesse temor de tais males, viveríamos sempre a temer.

3. Demais — A natureza não move para o que lhe é contrário. Ora, o mal da natureza dela mesma
provém. Logo, não é natural fugirmos desse mal. E, portanto, não há temor natural de um mal natural,
ou da natureza.
Mas, em contrário, diz o Filósofo, que não há nada mais temível que a morte, que é um mal natural.

SOLUÇÃO. — Como diz o Filósofo, o temor provém da fantasia de um mal futuro que causa corrupção
ou tristeza. Ora, como causa tristeza o mal contrário à vontade, assim causa corrupção o que o é à
natureza; e tal é o mal natural. Logo, pode haver temor dele.
Devemos porém considerar que o mal da natureza tem às vezes uma causa natural, e então assim se
chama, não só porque priva de um bem da natureza, mas, também porque é efeito desta; tal é a morte
natural e outros males. Às vezes, porém, o mal da natureza provém de uma causa não natural; tal é a
morte causada violentamente por um perseguidor. E em um e outro caso o mal da natureza é ora
temido e ora, não. Pois, o temor provindo da fantasia de um mal futuro, no dizer do Filósofo, o que
exclui essa fantasia também exclui o temor. Mas de dois modos pode o mal parecer futuro. — Primeiro,
por ser remoto e distante. Assim, à distância nos leva a considerá-lo como não havendo de suceder, e
por isso não tememos ou o tememos pouco. Pois, segundo o Filósofo, as coisas que estão muito
afastadas não são temidas; assim, embora todos saibamos que havemos de morrer, com isso não nos
importamos por não ser próximo. — De outro modo consideramos como não havendo de acontecer um
mal futuro, por casa da necessidade, que nos leva a tê-lo por presente. E por isso, o Filósofo diz,
que aqueles que vão ser decapitados não temem, vendo a premência da morte iminente; mas para
temermos é preciso haver alguma esperança de salvação.
Portanto, se não tememos o mal natural é que não o consideramos como havendo de acontecer.
Quando porém ele causa a morte, e é apreendido como próximo, embora nos deixe alguma esperança
de salvação, é temido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O mal natural não provém às vezes da natureza, como já
dissemos. Quando porém dela procede, embora não possa ser evitado de todo, pode contudo ser
diferido. E nesta esperança podemos deliberar sobre o modo de o evitar.

RESPOSTA À SEGUNDA. — O mal natural, embora esteja sempre iminente, nem sempre contudo o está
proximamente. E por isso nem sempre é temido.

RESPOSTA À TERCEIRA. — A morte e os outros males naturais provêm da natureza universal; mas o
quanto lhe é possível à natureza particular procura evitá-los. Por onde, pela inclinação da natureza
particular, sentimos dor e tristeza causadas por esses males, quando presentes; e temor, se estiverem
na iminência de acontecer.

## Art. 3 — Se pode haver temor do mal da culpa.
(IIª IIªº, q. 144, ª 2).
O terceiro discute-se assim. — Parece que pode haver temor do mal da culpa.

1. — Pois, diz Agostinho, que por um casto temor o homem teme a separação de Deus. Ora, dele só nos
separa a culpa, conforme aquilo da Escritura (Is 59, 2): as vossas iniqüidades são as que fizeram uma
separação entre vós e o vosso Deus. Logo, pode haver temor do mal da culpa.

2. Demais — Como diz Túlio, tememos, quando futuro, aquilo com que nos contristamos, quando
presente. Ora, podemos nos condoer ou contristar com o mal da culpa. Logo, podemos também temê-
lo.

3. Demais — A esperança opõe-se ao temor. Ora, aquela pode dizer respeito ao bem da virtude, como
se vê no Filósofo. E o Apóstolo diz (Gl 5, 10): Eu confio de vós no Senhor, que não tereis outros
sentimentos. Logo, também pode haver temor do mal da culpa.

4. Demais — A vergonha é uma espécie de temor, como já se disse. Ora, ela é provocada por um ato
torpe, que é mal da culpa. Logo, também o temor.
Mas, em contrário, diz o Filósofo, que nem todos os males nós os tememos; assim, o sermos injustos ou
tardos.

SOLUÇÃO. — Como já dissemos, assim como o objeto da esperança é o bem futuro árduo, que podemos
alcançar, assim o temor é relativo ao mal futuro árduo, que não podemos facilmente evitar. Donde se
conclui, que não nos pode aterrorizar o que é absolutamente da alçada do nosso poder e da nossa
vontade, senão só aquilo que tem uma causa extrínseca. Ora, o mal da culpa tem como causa própria a
vontade humana. Logo, nada implica que nos possa propriamente aterrorizar.
Como porém a vontade humana pode inclinar-se ao pecado por alguma causa exterior, pode haver
temor do mal da culpa e provocado, então, por uma causa exterior, quando aquilo que nos faz inclinar o
faz com grande força; p. ex., quando tememos permanecer na sociedade dos maus, sem sermos
induzidos a pecar. Mas propriamente falando, em tal disposição o homem teme, antes, a sedução, que a
culpa, em sentido próprio, i. é, enquanto voluntária, pois deste modo nada teria que temer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A separação de Deus é uma pena resultante do pecado;
ora, toda pena provém, de certo modo, de uma causa exterior.

RESPOSTA À SEGUNDA. — A tristeza e o temor convêm em que ambos dizem respeito ao mal. Em duas
coisas, porém, diferem. Primeiro, porque enquanto a tristeza é provocada pelo mal presente, o temor o
é pelo futuro. E segundo, porque a tristeza, pertencendo ao concupiscível e sendo relativa ao mal
absolutamente considerado, pode dizer respeito a qualquer mal, grande ou pequeno; ao passo que o
temor, pertencendo ao irascível, diz respeito ao mal que vai de mistura com o árduo e difícil, que
desaparece quando a vontade pode fazer valer o seu império. Por isso nem sempre tememos, como
futuro, aquilo com que nos contristamos, quando presente.

RESPOSTA À TERCEIRA. — A esperança é relativa ao bem que podemos alcançar. Ora, podemos alcançá-
lo ou por nós mesmos ou por meio de outrem. E portanto a esperança pode dizer respeito a um ato de
virtude, que cai na nossa alçada. O temor, porém, é relativo ao mal que não está em nosso poder. Por
onde, o mal temido sempre provém de uma causa extrínseca; ao passo que o bem esperado pode provir
de causa tanto intrínseca como extrínseca.

RESPOSTA À QUARTA. — Como já dissemos, a vergonha não é um temor causado pelo ato mesmo do
pecado, mas pela torpeza ou ignomínia dele resultante; ora, isso é uma causa extrínseca.

## Art. 4 — Se o temor pode ser temido.
O quarto discute-se assim. — Parece que o temor não pode ser temido.

1. — Pois, conservamos, pelo temor tudo o que tememos perder; assim, quem teme perder a saúde a
conserva, temendo. Se pois o temor for temido, nós nos livraremos de temer temendo-o. Ora, isto é
inadmissível.

2. Demais — Temer é fugir. Ora, ninguém foge de si mesmo. Logo, o temor a si mesmo não teme.

3. Demais — O temor é relativo ao futuro. Ora, quem teme já tem temor. Logo, não pode temê-lo.
Mas, em contrário, podemos amar o amor e condoer-nos da dor. Logo, pela mesma razão, também
podemos temer o temor.

SOLUÇÃO. — Como já dissemos, é capaz de nos aterrar só o que provém de uma causa extrínseca; e não
o que provém da nossa vontade. Ora, o temor provém, em parte, de uma causa extrínseca e, em parte,
é da alçada da vontade. Provém de causa extrínseca por ser uma paixão conseqüente à fantasia do mal
iminente. E neste sentido podemos temê-lo, i. é, temer que esteja iminente a necessidade de temer,
pela iminência de algum mal extremo. É porém da alçada da vontade, por obedecer o apetite inferior à
razão, o que nos faculta repelir o temor. E, neste sentido, o temor não pode ser temido, como diz
Agostinho. Mas como alguém poderia se servir das razões que ele aduz, para mostrar que o temor de
nenhum modo pode ser temido, é necessário respondê-las.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nem todos os temores são um só temor; mas a
diversidade das coisas temidas acarreta a dos temores. Por onde, nada impede nos preservemos de um
temor por meio de outro; e assim, por meio deste conservemo-nos sem temer.

RESPOSTA À SEGUNDA. — Sendo um temor pelo qual tememos o mal iminente e outro o pelo que
tememos o temor mesmo desse mal, não se segue que o mesmo fuja de si próprio, ou que o mesmo
seja a fuga de si próprio.

RESPOSTA À TERCEIRA. — Por causa da diversidade dos temores, já referida, podemos por um temor
presente temer um futuro temor.

## Art. 5 — Se os males insólitos e os repentinos sejam mais de se temerem.
O quinto discute-se assim. — Parece que os males insólitos e repentinos não são mais de se temerem.

1. — Pois, assim como a esperança é relativa ao bem, assim o temor o é ao mal. Ora, a experiência
concorre para o aumento da esperança, no bem. Logo, também no mal concorre para o aumento do
temor.

2. Demais — O Filósofo diz, que os mais temidos não são os da ira arrebatada, mas os brandos e os
astutos. Ora, como se sabe, os primeiros são mais levados por movimentos súbitos. Logo, as coisas
súbitas são menos temíveis.

3. Demais — O que é súbito mais dificilmente é objeto de reflexão. Ora, quanto mais refletimos em
certas coisas tanto mais as tememos; e, por isso, diz o Filósofo, que alguns parecem fortes por causa da
ignorância; mas, quando sabem que as coisas não são como lhes parecem, fogem. Logo, o repentino é
menos temido.
Mas, em contrário, diz Agostinho: O temor, ao passo que vela pela sua segurança, tem horror ao insólito
e repentino, oposto às coisas que ama.

SOLUÇÃO. — Como já dissemos, o objeto do temor, é o mal iminente, que não pode ser facilmente
repelido. E, isto pode dar-se por duas causas: pela grandeza do mal ou pela debilidade de quem teme.
Ora, o insólito e repentino influi em ambos os casos. Primeiro, influi para o mal iminente parecer maior.
Pois, quanto mais refletimos nas coisas corpóreas, tanto boas como más, tanto menores elas nos
parecem. Por onde, assim como a diuturnidade mitiga a dor do mal presente, como se lê em Túlio,
assim, a reflexão prévia diminui o temor do mal futuro. Em segundo lugar, o insólito e repentino
concorre para a fraqueza de quem teme, pelo privar dos meios a que pode recorrer para repelir o mal
futuro, que de nada podem servir quando o mal ocorre de improviso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É bom o objeto da esperança, que podemos alcançar.
Por onde, o que aumenta o nosso poder aumenta naturalmente a esperança; e pela mesma razão
diminui o temor, porque este é relativo ao mal a que não podemos facilmente resistir. Ora, a
experiência tornando o homem mais forte para agir, assim como aumenta a esperança, diminui o temor.

RESPOSTA À SEGUNDA. — Os que de ira arrebatada não a ocultam; e por isso os males que podem
causar não são de tal modo repentinos, que não possam ser previstos. Ao passo, que os brandos e
astutos dissimulam a ira; por isso os males com que ameaçam, não podendo ser previstos, atacam de
improviso. Donde a dizer o Filósofo que esses são os mais temidos.

RESPOSTA À TERCEIRA. — Em si mesmos considerados, os bens ou os males corpóreos parecem
maiores, no princípio. E a razão é que um contrário parece maior quando comparado com o outro.
Assim, quem passa repentinamente da pobreza para as riquezas, mais as estima por comparação com a
pobreza passada; e inversamente, os ricos caídos repentinamente na pobreza maior horror têm desta.
Por isto, mais tememos o mal repentino, por nos parecerem maiores. Pode porém acontecer,
acidentalmente, que não se manifeste a grandeza do mal; assim p. ex., quando os inimigos se ocultam
insidiosamente. E então é verdade que o mal, atentamente considerado, se torna mais terrível.

## Art. 6 — Se é mais para temer aquilo que não tem remédio.
O sexto discute-se assim. — Parece que não é mais para temer aquilo que não tem remédio.

1. — Pois, para haver temor é preciso reste alguma esperança de salvação, como se disse. Ora, quando o
mal não tem remédio não há nenhuma esperança de salvação. Logo, os males dessa natureza não são
temidos de modo nenhum.

2. Demais — Não podemos dar nenhum remédio ao mal da morte; pois por força da só natureza não
podemos voltar da morte à vida. Entretanto a morte não é o que mais tememos, como diz o Filósofo.
Logo, não é o que não tem remédio o que mais tememos.

3. Demais — O Filósofo diz: o diuturno não é melhor do que o que dura só um dia; nem o perpétuo é
melhor que o não-perpétuo. Logo, pela mesma razão, nem pior. Ora, o que não tem remédio não difere
dos outros males senão pela diuturnidade ou perpetuidade. Logo, não são, por isso, piores ou mais
temíveis.
Mas, em contrário, diz o Filósofo: o temível se torna mais terrível quando, cometida à falta, não
podemos corrigi-la; ou quando não há remédio, ou, pelo menos, remédio fácil.

SOLUÇÃO. — O objeto do temor é o mal. Por onde, tudo o que aumenta este aumenta também aquele.
Ora, o mal pode aumentar não só especificamente, mas também quanto às circunstâncias, como do
sobredito resulta. Ora, dentre estas, a diuturnidade, ou ainda, a perpetuidade são as que mais
concorrem para o aumento dele. Pois, o que está no tempo é de certo modo medido pela duração
temporal. Logo, se sofrer alguma coisa num determinado tempo é um mal, sofrê-la em tempo duplo é
considerado duplo mal. E por esta razão, sofrer esse mesmo mal, num tempo infinito, i. é, sofrê-lo
perpetuamente, implica de certo modo um aumento infinito. Ora, os males que, uma vez sucedidos, não
podem ter remédio, ou que não o tem fácil, são considerados como perpétuos ou diuturnos. Por onde,
tornam-se especialmente temidos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Há para o mal um duplo remédio. — Um que impede o
mal futuro de vir a realizar-se. E, eliminado o remédio, elimina-se a esperança e por conseqüência o
temor. Por isso não tratamos aqui desse remédio. — O outro remédio, é o removente do mal atual. E é
deste que agora tratamos.

RESPOSTA À SEGUNDA. — Embora a morte seja um mal irremediável, contudo não a tememos se não
está iminente, como já dissemos.

RESPOSTA À TERCEIRA. — No passo aduzido o Filósofo trata do bem em si, que é específico. Ora, em tal
sentido, o bem não se torna maior pela diuturnidade ou perpetuidade, mas pela sua natureza mesma.