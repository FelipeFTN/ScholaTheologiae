# Questão 40: Da esperança e do desespero.
Em seguida devemos tratar das paixões do irascível. E, primeiro, da esperança e do desespero. Segundo,
do temor e da audácia. Terceiro, da ira.
Sobre a primeira questão oito artigos se discutem:

## Art. 1 — Se a esperança é o mesmo que o desejo ou cobiça.
(Supra, q. 24, a . 1; III Sent., dist. XXVI, q. 1, a . 3; q. 2, a . 3, qª 2; De Virtut., q. 4, a . 1; Compend. Theol.,
part. II, cap. VII).
O primeiro discute-se assim. — Parece que a esperança é o mesmo que o desejo ou cobiça.

1. — Pois, a esperança é considerada como uma das quatro principais paixões. Ora, quando Agostinho
as enumera coloca a cobiça no lugar da esperança. Logo, a esperança é o mesmo que a cobiça ou
desejo.

2. Demais — As paixões diferençam-se pelos seus objetos. Ora, a esperança e a cobiça ou desejo tem o
mesmo objeto, que é o bem futuro. Logo, a esperança é o mesmo que a cobiça ou o desejo.

3. Demais — Nem vale dizer que a esperança acrescenta ao desejo a possibilidade de alcançar o bem
futuro. — Pois, o que se relaciona acidentalmente com o objeto não varia a espécie da paixão. Ora, o
possível se relaciona acidentalmente com o bem futuro, que é o objeto da cobiça ou desejo e da
esperança. Logo, esta não é uma paixão especificamente diferente do desejo ou cobiça.
Mas, em contrário. — Às diversas potências correspondem diversas paixões especificamente diferentes.
Ora, a esperança reside no irascível, ao passo que o desejo e a cobiça, no concupiscível. Logo, a
esperança difere especificamente do desejo ou cobiça.

SOLUÇÃO. — As paixões se especificam pelos seus objetos. Ora, há quatro condições que devemos
considerar relativamente ao objeto da esperança. — A primeira é que ele deve ser bom, pois,
propriamente falando, não há esperança senão do bem. E, por aqui ela difere do temor, relativo ao mal.
— A segunda é que deve ser futuro, pois a esperança não tem por objeto o bem presente já adquirido.
E, por aqui, difere da alegria, relativa ao bem presente. — A terceira, que deve ser algo de árduo, que se
alcança com dificuldade; pois, não se diz que alguém espera um objeto insignificante, que com a maior
facilidade poderá possuir. E por aqui difere a esperança, do desejo ou cobiça, que, referente a um bem
absolutamente futuro, pertence ao concupiscível, ao passo que ela pertence ao irascível. — A quarta é
que seja possível alcançar o objeto árduo, pois ninguém espera o que de nenhum modo pode alcançar.
E por aqui a esperança difere do desespero.
Por onde é claro que a esperança difere do desejo, assim como as paixões do irascível, das do
concupiscível. E por isso pressupõe o desejo, assim como todas as paixões do irascível pressupõem as do
concupiscível, conforme já dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho coloca a cobiça em lugar da esperança,
porque uma e outra visa o bem futuro; e porque o bem que não é árduo é quase reputado por nada. De
modo que o desejo é considerado como tendendo sobretudo para o bem árduo, para o qual também
tende a esperança.

RESPOSTA À SEGUNDA. — O objeto da esperança não é o bem futuro, absolutamente, mas, o que se
alcança com arduidade e dificuldade, como já dissemos.

RESPOSTA À TERCEIRA. — O objeto da esperança não somente acrescenta a possibilidade ao objeto do
desejo, mas também a arduidade; e esta faz com que a esperança pertença a outra potência, a saber, ao
irascível, que respeita o árduo, como já dissemos na primeira parte. Ora, o possível e o impossível de
nenhum modo são acidentais relativamente ao objeto da virtude apetitiva. Pois, o apetite é um princípio
de moção. Ora, nenhum ser se move senão para o termo possível; assim, ninguém se move senão para o
que julga poder alcançar. E por isto a esperança difere do desespero, tanto quanto difere o possível do
impossível.

## Art. 2 — Se a esperança pertence à potência cognitiva.
(III Sent., dist. XXVI, q. 1, a . 1; q. 2, a . 2).
O segundo discute-se assim. — Parece que a esperança pertence à potência cognitiva.

1. — Pois, a esperança é uma expectativa, conforme aquilo do Apóstolo (Rm 8, 25): E se o que não
vemos esperarmos, por paciência o esperamos. Ora, a expectativa pertence à potência cognitiva, da
qual é próprio o esperar. Logo, a esperança pertence também a essa potência.

2. Demais — Segundo parece, a esperança é o mesmo que a confiança; donde vem o dizermos que
quem espera confia, quase querendo identificar as duas expressões — confiar e esperar. Ora, a
confiança, como a fé, pertence à potência cognitiva. Logo, também a esperança.

3. Demais — A certeza é propriedade da potência cognitiva. Ora, é atribuída à esperança. Logo, esta
pertence a tal potência.
Mas, em contrário. — A esperança é relativa ao bem, como dissemos. Ora, o bem como tal é objeto, não
da potência cognitiva, mas da apetitiva. Logo, a esperança não pertence àquela potência, mas a esta.

SOLUÇÃO. ― A esperança, implicando uma certa tendência do apetite para um determinado bem,
pertence manifestamente à potência apetitiva. Pois, o movimento para um objeto é, propriamente, da
alçada do apetite; ao passo que a atividade da potência cognitiva completa-se, não pelo mover-se do
sujeito conhecente para o objeto, mas antes, porque este está naquele. Como porém a potência
cognitiva move a apetitiva, representando-lhe o seu objeto, dos diversos aspectos do objeto apreendido
resultam os diversos movimentos da potência apetitiva. Ora, um é o movimento resultante, para o
apetite, da apreensão do bem, e outro, da apreensão do mal; e semelhantemente, diferentes são os
movimentos resultantes da apreensão do presente e do futuro, do absoluto e do árduo, do possível e do
impossível. E sendo assim, a esperança é um movimento da virtude apetitiva consecutivo à apreensão
de um bem futuro árduo, mas possível de ser alcançado; isto é, é a tendência do apetite para tal objeto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Respeitando a esperança um bem possível, o
movimento dela se manifesta no homem de duplo modo, porque de dois modos um objeto pode-lhe ser
possível, a saber, relativamente à virtude própria ou à de outro. Donde vem que, de quem tem
esperança de alcançar, pela virtude própria, alguma coisa dizemos que espera e não, que tem
expectativa. Ao passo que ter expectativa é, propriamente, esperar alguma coisa por auxílio de virtude
alheia, significando ter expectativa quase estar naexpectação de outrem, enquanto que a potência
apreensiva precedente, não só respeita o bem que intenta alcançar, mas também o que por cuja virtude
o espera, conforme aquilo da Escritura (Ecle 51, 10): Estava olhando para o socorro dos homens. Por
onde, chama-se às vezes ao movimento da esperança expectação, por causa da inspeção da potência
cognitiva precedente.

RESPOSTA À SEGUNDA. — O que desejamos e pensamos poder alcançar cremos que já o alcançamos; e,
dessa fé da potência cognitiva precedente provém o denominarmos confiança ao movimento
consecutivo do apetite. Pois este movimento tira a sua denominação do conhecimento precedente,
como o efeito, da causa mais conhecida, porquanto, a potência apreensiva conhece melhor o seu do
que o ato da apetitiva.

RESPOSTA À TERCEIRA. — Atribuímos a certeza não somente ao movimento do apetite sensitivo, mas
também ao do apetite natural, como quando dizemos que a pedra tende certamente para baixo. E isto
pela infalibilidade que lhe advém da certeza do conhecimento precedente ao movimento do apetite
sensitivo, ou mesmo, do natural.

## Art. 3 — Se os brutos têm esperança.
(III Sent., dist. XXVI, q. 1, a . 1).
O terceiro discute-se assim. — Parece que os brutos não têm esperança.

1. — Pois, a esperança é relativa a um bem futuro, como diz Damasceno. Ora, conhecer o futuro não
pertence aos brutos, dotados só de conhecimento sensível, que não alcança o futuro. Logo, neles não há
esperança.

2. Demais — O objeto da esperança é o bem que podemos adquirir. Ora, o possível e o impossível são
diferenças da verdade e da falsidade, que só existem na inteligência, como diz o Filósofo. Logo, a
esperança não existe nos brutos, desprovidos de inteligência.

3. Demais — Agostinho diz, que os animais se movem pelo que vêem. Ora, a esperança não se refere ao
que é visto, como diz a Escritura (Rm 8, 24): porque o que qualquer vê, como o espera? Logo, não há
esperança nos brutos.
Mas, em contrário. — A esperança é uma paixão do irascível. Ora, este existe nos brutos. Logo, também
aquela.

SOLUÇÃO. — As paixões interiores dos animais podem ser depreendidas dos seus movimentos
exteriores: e destes se deduz que há neles esperança. Assim, nem o cão se move para uma lebre, nem o
gavião, para uma ave, que vêem muito distantes, como não esperando poder alcançá-las; se porém
estiverem próximas, movem-se, como na esperança de as apanhar. Pois, como já dissemos, tanto o
apetite sensitivo dos brutos, como o natural dos seres insensíveis, seguem a apreensão de algum
intelecto, como se dá também com o apetite da natureza intelectiva chamado vontade. Mas a diferença
está em que esta é movida pela apreensão do intelecto conjunto, ao passo que o movimento do apetite
natural segue a apreensão do intelecto separado, que instituiu a natureza. E o mesmo se dá com o
apetite sensitivo dos brutos, que também agem por um certo instinto natural. Por onde, nas obras dos
brutos e dos demais seres naturais, manifesta-se um processo semelhante ao das operações da arte. E
deste modo os brutos podem ter esperança e desespero.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora os brutos não conheçam o futuro, movem-se
contudo por um instinto natural para algo de futuro, como se o previssem; e esse instinto lhes foi
infundido pelo intelecto divino, que prevê o futuro.

RESPOSTA À SEGUNDA. — O objeto da esperança é o possível não enquanto aspecto do verdadeiro,
pois, em tal sentido, resulta da relação entre o predicado e o sujeito; mas, enquanto relativo a uma
potência; e é assim que Aristóteles divide o possível nessas duas partes referidas.

RESPOSTA À TERCEIRA. — Embora a vista não apreenda o futuro, contudo o que o animal vê de
presente move-lhe o apetite a buscar ou evitar algo no futuro.

## Art. 4 — Se o desespero é o contrário da esperança.
(Supra, q. 23, a . 2; infra, q. 45, a . 1, ad 2; III Sent., dist. XXVI, q. 1, a . 3, ad 3).
O quarto discute-se assim. — Parece que o desespero não é o contrário da esperança.

1. — Pois, à unidade é contrária a unidade, como diz Aristóteles. Ora, o temor é contrário à esperança.
Logo, não lho é o desespero.

2. Demais — Os contrários são relativos a um mesmo termo. Ora, tal não se dá com a esperança e o
desespero; pois aquela diz respeito ao bem e este é provocado por um mal impediente à aquisição do
bem. Logo, a esperança não é contrária ao desespero.

3. Demais — Um movimento é contrário a outro; e o repouso , por outro lado, opõe-se ao movimento,
de que é privação. Ora, o desespero parece implicar, antes, a imobilidade que o movimento. Logo, não é
contrário à esperança, que implica o movimento de tendência para o bem esperado.
Mas, em contrário, o desespero recebe a sua denominação por oposição à esperança.

SOLUÇÃO. — Como já dissemos, mudanças comportam dupla contrariedade. Uma, pelo acesso a termos
contrários, e tal contrariedade só existe nas paixões do concupiscível; assim, o amor é contrário ao ódio.
De outro modo, pelo acesso e pelo afastamento, em relação ao mesmo termo; e tal é a contrariedade
entre as paixões do irascível, como já dissemos. Ora, o objeto da esperança, que é o bem árduo, exerce
por certo uma atração, enquanto considerado como possível de ser alcançado; e por isso a esperança,
que implica a aproximação, tende para ele. Mas considerado como impossível de ser obtido, provoca
uma repulsa, pois, como diz Aristóteles, os homens recuam quando chegam a algo de impossível. E a
esse objeto respeita o desespero; e, por isso, implica o movimento de afastamento e é contrário á
esperança, como o afastamento o é ao acesso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O temor contraria a esperança, por causa da
contrariedade dos objetos, a saber, o bem e o mal; pois esta contrariedade existe nas paixões do
irascível, enquanto derivadas das do concupiscível. Ao passo que o desespero é contrário à esperança só
pela contrariedade de acesso e de afastamento.

RESPOSTA À SEGUNDA. — O desespero não respeita o mal em si mesmo; mas às vezes e por acidente,
lho respeita quando causa a impossibilidade de alcançar um bem. Pode porém haver desespero por
sobreexcesso de bem.

RESPOSTA À TERCEIRA. — O desespero não implica a só privação da esperança, mas também o
afastamento da coisa desejada por causa da impossibilidade conhecida de a alcançar. Por onde, o
desespero como a esperança, pressupõe o desejo; e quanto ao que não pode ser objeto do nosso
desejo, não temos esperança nem desespero. E por isto tanto este como aquela visam o bem, que entra
nos limites do desejo.

## Art. 5 — Se a experiência é causa da esperança.
(Infra, q. 42, a . 5, ad 1; q. 45, a . 3).
O quinto discute-se assim. — Parece que a experiência não é causa da esperança.

1. — Pois a experiência é própria à potência cognitiva; por isso diz o Filósofo, que a potência intelectual
precisa da experiência e do tempo. Ora, a esperança não pertence à potência cognitiva, mas à apetitiva,
como já dissemos. Logo, não é causa da esperança.

2. Demais — Como diz o Filósofo, os velhos têm a esperança difícil, por causa da experiência; donde
resulta que esta é a causa da falta daquela. Ora, os contrários não podem ter a mesma causa. Logo, a
experiência não é causa da esperança.

3. Demais — Como diz o Filósofo, explicar tudo a propósito de tudo e nada omitir é às vezes sinal de
estultice. Ora, segundo parece, é a grandeza da esperança que nos leva a experimentar tudo, pois, a
estultice provém da inexperiência. Logo, mais que a experiência, esta é causa da esperança.
Mas, em contrário, diz o Filósofo, que alguns se vêm cheios de esperança por terem vencido muitas
vezes e muitos, o que respeita à experiência. Logo, esta é causa da esperança.

SOLUÇÃO. — Como já dissemos, o objeto da esperança é o bem futuro, árduo, e possível de ser
alcançado. Logo, pode ser causa da esperança o que torna um objeto possível ao homem ou o leva a
julgá-lo tal. — Do primeiro modo é causa da esperança tudo o que aumenta o poder do homem, como
as riquezas e a fortaleza; e entre outras, também a experiência, pois, por esta o homem adquire a
faculdade de agir facilmente, donde resulta a esperança. E, por isso, diz Vegécio: Ninguém teme fazer o
que tem consciência de haver bem aprendido. — De outro modo é causa da esperança tudo o que nos
leva a considerar um certo objeto como possível; e isso pode se dar tanto com uma doutrina como uma
persuasão qualquer. E assim também causa da esperança é a experiência, enquanto nos leva a
considerar como possível, o que, antes dela, reputávamos por impossível. Mas, por este modo, a
experiência pode ser também causa da falta de esperança. Pois, como a experiência nos leva a julgar
possível o que antes tínhamos por impossível, assim e inversamente, leva-nos a julgar impossível o que
antes reputávamos por possível. — Por onde, a experiência, sendo causa da esperança, de dois modos;
e da falta de esperança, de um, podemos dizer que ela é, sobretudo causa da esperança.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nos nossos atos, a experiência não só produz a ciência,
mas também um certo hábito, por causa do costume, que torna mais fácil o agir. Mas, também a
potência intelectual mesma contribui para podermos operar facilmente, pois demonstra ser alguma
coisa possível. E assim causa a esperança.

RESPOSTA À SEGUNDA. — Os velhos têm falta de esperança por causa da experiência, na medida em
que esta manifesta a impossibilidade. E por isso, no mesmo passo aduzido se acrescenta que lhes
acontecem muitas coisas detrimentosas.

RESPOSTA À TERCEIRA. — Quase por acidente é que a estultice e a inexperiência podem ser causa da
esperança: removendo a ciência que leva a considerar, verdadeiramente, que uma coisa não é possível.
Por onde, a inexperiência é causa da esperança pela mesma razão pela qual a experiência é causa da
falta de esperança.

## Art. 6 — Se a juventude e a embriaguez são causas da esperança.
(Infra, q. 45, a . 3).
O sexto discute-se assim. — Parece que a juventude e a embriaguez não são causas da esperança.

1. — Pois, a esperança implica uma certa certeza e segurança e por isso S. Paulo a compara a uma
âncora. Ora, os jovens e os ébrios faltam de firmeza, pois, são de ânimo facilmente mudável. Logo, a
juventude e a embriaguez não são causas da esperança.

2. Demais — O que aumenta o poder é por excelência causa da esperança, como já se disse. Ora, a
juventude e a embriaguez implicam falta de firmeza. Logo, não são causas da esperança.

3. Demais — A experiência é causa da esperança, como já se disse. Ora, aos jovens falta a experiência.
Logo, a juventude não é causa da esperança.
Mas, em contrário, diz o Filósofo, que estavam ébrios de esperança no sucesso; e que, os jovens têm
esperanças no sucesso.

SOLUÇÃO. — A juventude é causa da esperança por três razões, como diz o Filósofo, e que são relativas
às três condições do bem — futuro, árduo e possível — objeto da esperança, como já dissemos. —
Assim, os jovens têm muito do futuro e pouco do passado. Ora, como a memória é relativa ao passado e
a esperança, ao futuro, têm pouca memória e vivem muito pela esperança. — Em segundo lugar, os
jovens pela sua natureza ardorosa, têm muitos espíritos e, por isso, o coração se lhes alarga, o que os
leva a buscar o árduo. Donde vem o serem animados e cheios de esperança. — E por fim, os que nunca
sofreram oposição ou obstáculos aos seus esforços, facilmente reputam uma coisa por possível. E por
isso os jovens, pela inexperiência dos obstáculos e das deficiências próprias, facilmente julgam lhes seja
uma determinada coisa possível; e isto os torna cheios de esperança.
Ora, duas destas condições também existem nos ébrios, a saber, o ardor e a multiplicação dos espíritos,
por causa do vinho, e a inconsideração dos perigos e das deficiências próprias. E pela mesma razão
também todos os estultos e os que agem sem deliberação tentam tudo e vivem cheios de esperança.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora os jovens e os ébrios não tenham a firmeza,
realmente, têm-na contudo, segundo a estimativa deles; pois julgam haverem certamente de conseguir
o que esperam.
E semelhantemente, devemos responder à segunda objeção, que os jovens e os ébrios têm, por certo,
falta de firmeza, na realidade das coisas; mas, como não conhecem as suas deficiências, julgam terem
firmeza.

RESPOSTA À SEGUNDA. — Não só a experiência, mas também a inexperiência é, de certo modo, causa
da esperança, como já dissemos.

## Art. 7 — Se a esperança é causa do amor.
(Supra, q. 17, a . 4, ad 3; infra, q. 62, a . 4, ad 3; IIª-IIªº, q. 17, a . 8; De Virtut., q. 4, a . 3).
O sétimo discute-se assim. — Parece que a esperança não é causa do amor.

1. — Pois, segundo Agostinho, o amor é o primeiro dos afetos da alma. Ora, a esperança é um desses
afetos. Logo, o amor a precede e, portanto, ela não o causa.

2. Demais — O desejo precede a esperança. Ora, ele é causado pelo amor, como já se disse. Logo,
também a esperança o é e, portanto, não o precede.

3. Demais — A esperança causa o prazer, segundo já se disse. Mas, só pode haver prazer no bem
amado. Logo, o amor precede a esperança.
Mas, em contrário, sobre aquilo da Escritura (Mt 1, 2) — Abraão gerou a Isaac, e Isaac gerou a Jacó —
diz a Glosa: Isto é, a fé gerou a esperança; a esperança, a caridade. Ora, caridade é amor. Logo, este é
causado pela esperança.

SOLUÇÃO. — A esperança implica relação. Assim, como objeto, respeita o bem esperado. Mas, como
este é árduo e possível e, às vezes, não por nossa causa, mas pela de outros, é que alguma coisa se nos
torna árdua e possível, a esperança também respeita aquilo que causa essa possibilidade.
Por onde, enquanto a esperança visa o bem esperado, é causada pelo amor, pois, ela não existe senão
relativamente ao bem desejado e amado. Enquanto porém a esperança respeita o que nos torna alguma
coisa possível, o amor é causado por ela e não inversamente. Pois é por esperarmos alcançar por meio
de alguém, certos bens, que somos levados para ele como para o nosso bem, e assim começamos a
amá-lo. Mas de quem amamos não esperamos nada senão por acidente, enquanto cremos recebermos
também em paga o amor. Por onde, o sermos amados é causa de esperarmos em quem nos ama; mas
esse amor é causado pela esperança que nessa pessoa depositamos.
Donde se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 8 — Se a esperança coadjuva, ou antes, impede a nossa atividade.
O oitavo discute-se assim. — Parece que a esperança não coadjuva, mas antes impede a nossa
atividade.

1. — Pois, a esperança produz a segurança. Ora, esta gera a negligência, que nos impede a atividade.
Logo, também a esperança a impede.

2. Demais — A tristeza nos impede a atividade, como já se disse. Ora, a esperança às vezes causa a
tristeza, conforme a Escritura (Pr 13, 12): A esperança que se retarda aflige a alma. Logo, ela impede a
nossa atividade.

3. Demais — O desespero contraria a esperança, como já foi dito. Ora, aquele, sobretudo na guerra,
coadjuva a atividade; pois, diz a Escritura (2 Rs 2, 26), que é coisa perigosa a desesperação. Logo, a
esperança produz um efeito contrário, impedindo-nos a atividade.
Mas, em contrário, diz a Escritura (1 Cor 9, 10): o que lavra deve lavrar com esperança de perceber os
frutos. E o mesmo se dá em todos os demais casos.

SOLUÇÃO. — A esperança, em si mesma, pode coadjuvar a nossa atividade, tornando-a mais intensa. —
Primeiro, em razão do seu objeto, o bem árduo possível. Pois, a consideração do árduo excita a atenção;
e por outro lado, a consideração do possível não retarda o esforço. Donde se conclui que o homem age
intensamente levado da esperança. — Segundo, em razão do seu efeito. Pois, a esperança, como já
dissemos, causa o prazer, que nos coadjuva a atividade, conforme também já dissemos; e por isso
mesmo a coadjuva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A esperança respeita o bem que devemos alcançar; ao
passo que a segurança, o mal que devemos evitar. Por onde, esta mais se opõe ao temor do que se
relaciona com a esperança. — E contudo a segurança não causa a negligência, senão enquanto diminui o
exame do que é árduo, o que também faz diminuir a esperança. Pois, o que o homem alcança sem
temer nenhum impedimento quase não é reputado por árduo.

RESPOSTA À SEGUNDA. — A esperança por si causa o prazer; mas, por acidente, causa a tristeza, como
já dissemos.

RESPOSTA À TERCEIRA. — O desespero, na guerra, torna-se perigoso, por causa de uma certa esperança
conjunta. Pois, os desesperados da fuga enfraquecem-se fugindo, mas esperam vingar a morte própria.
E por isso pugnam mais valentemente, fundados nessa esperança; donde vem o tornarem-se perigosos
aos inimigos.