# Questão 82: Do pecado original quanto à sua essência.
Em seguida devemos tratar da essência do pecado original. E nesta questão discutem-se quatro artigos:

## Art. 1 — Se o pecado original é um hábito.
(II Sent., dist. XXX, q. 1, a. 3, ad 2; De Malo, q. 4, a. 2 ad 4).
O primeiro discute-se assim. — Parece que o pecado original não é um hábito.

1. — Pois, o pecado original é a carência da justiça original, como diz Anselmo; e, portanto, é uma
privação. Ora, esta se opõe ao hábito. Logo, o pecado original não é um hábito.

2. Demais. — O pecado atual, implica, essencialmente mais que o original, a culpa, por ser por essência
mais voluntário. Ora, o hábito do pecado atual não implica essencialmente a culpa; pois, do contrário,
quem estivesse dormindo pecaria culposamente. Logo, nenhum hábito original implica a essência da
culpa.

3. Demais. — O ato mau sempre precede o mau hábito, porque nenhum hábito mal é infuso, mas
adquirido. Ora, o pecado original não é precedido por nenhum ato. Logo, não é hábito.
Mas, em contrário, diz Agostinho: por causa do pecado original as crianças são capazes de
concupiscência, embora não a exerçam em ato. Ora, a capacidade supõe um hábito. Logo, o pecado
original é hábito.

SOLUÇÃO. — Como já dissemos, há duas espécies de hábito. — Uma inclina a potência a agir; neste
sentido a ciência e a virtude se chamam hábitos, mas, não é hábito o pecado original. — Outra é a
disposição de uma natureza, composta de muitos elementos, e que a leva a comportar-se bem ou mal,
em determinado caso; e sobretudo quando essa disposição tiver quase se transformado em a natureza,
como se dá com a doença e a saúde. E deste modo o pecado original é um hábito. Pois é uma disposição
desordenadaproveniente da desaparição daquela harmonia em que consistia a essência da justiça
original. Assim também a doença corpórea é uma disposição desordenada do corpo, que perturba o
equilíbrio em que consiste a essência da saúde. Por isso se chama ao pecado original langor da natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A doença corpórea tem algo da privação, enquanto
perturba o equilíbrio da saúde; e algo de positivo, que é a disposição desordenada dos humores. Assim
também o pecado original implica a privação da justiça original, seguida da disposição desordenada das
partes da alma. Por onde, não é privação pura, mas um certo hábito corrupto.

RESPOSTA À SEGUNDA. — O pecado atual é uma certa desordem do ato. O original, porém, sendo
pecado da natureza, é uma disposição desordenada desta em si mesma; e implica a essência da culpa,
enquanto derivada do primeiro pai, como já dissemos. Ora, essa disposição desordenada da natureza
implica a essência do hábito, o que não se dá com a desordenada disposição do ato. E, por isso, o
pecado original pode ser um hábito, não, porém, o atual.

RESPOSTA À TERCEIRA. — A objeção se funda no hábito que inclina a potência para o ato; ora tal hábito
não é o pecado original. Pois, não é diretamente que deste resultem certas inclinações para atos
desordenados. Mas, indiretamente, pela remoção do obstáculo, i. é, da justiça original, que os impede.
Assim também da doença corpórea resulta indiretamente uma inclinação para movimentos corpóreos
desordenados. Nem devemos dizer que o pecado original seja um hábito infuso, ou adquirido pelo ato
(salvo, se for do primeiro pai e não, de uma pessoa qualquer), senão que é inato por uma origem
viciosa.

## Art. 2 — Se num mesmo homem há muitos pecados originais.
(II Sent., dist. XXXIII, q. 1, a. 3; Expos. Litt; De Malo, q. 4, a. 8 ad 1; In Psalm. XXXI, L; Ad Rom., cap. IV,
lect. I; cap. V, lect.III).
O segundo discute-se assim. — Parece que num mesmo homem há muitos pecados originais.

1. — Pois, como diz a Escritura (Sl 50, 6) eu fui concebido em iniqüidade, e em pecados me concebeu
minha mãe. Ora, o pecado em que o homem foi concebido é o original. Logo, num mesmo homem há
muitos pecados originais.

2. Demais. — Um mesmo hábito não inclina para atos contrários, pois, inclina ao modo da natureza, que
só visa um termo. Ora, o pecado original, ainda num mesmo homem, inclina para pecados diversos e
contrários. Logo, o pecado original não constitui um só hábito, mas, vários.

3. Demais. — O pecado original contaminou todas as partes da alma. Ora, essas diversas partes são
sujeitos diversos do pecado, como do sobredito resulta (q. 74). Ora, como um mesmo pecado não pode
existir em sujeitos diversos, resulta que o pecado original não é um só, mas, muitos.
Mas, em contrário, diz a Escritura (Jo 1, 29): Eis aqui o cordeiro de Deus, eis aqui o que tira o pecado do
mundo; usando o singular, porque o pecado do mundo, que é o original, é um só, como expõe a Glosa a
esse lugar.

SOLUÇÃO. — Em cada homem há um só pecado original, do que podemos dar dupla razão. — Uma se
funda na causa do pecado original. Pois, como já dissemos, só o primeiro pecado do primeiro pai se lhe
transmitiu aos descendentes. Por onde, em cada homem, o pecado original é um só, numericamente; e
em todos os homens é um só, proporcionalmente, a saber, em relação ao primeiro princípio.
A outra razão pode fundar-se na essência mesma do pecado original. Pois, em toda disposição
desordenada, a unidade específica é considerada relativamente à causa, e a unidade numérica,
relativamente ao sujeito. E isso bem o mostra a doença corpórea, pois, há doenças especificamente
diversas, procedentes de causas diversas, como, da superabundância do calor ou do frio, ou de alguma
lesão do pulmão ou do fígado; mas, num mesmo homem não pode haver senão uma mesma doença
específica, numericamente. Ora, a causa da disposição corrupta chamada pecado original é só uma, a
saber, a privação da justiça original, pela qual deixou a alma de estar sujeita a Deus. E portanto, pecado
original é especificamente um só, e num mesmo homem não de existir, mais de um em número. Em
homens diversos porém, embora um só, específica e proporcionalmente, tem diversidade numérica.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A expressão plural — em pecados — é usada ao modo
da divina Escritura, que freqüentemente emprega o número plural pelo singular, como: são mortos os
que buscavam a alma do menino. No caso vertente esse uso se explica quer por preexistirem
virtualmente, no pecado original, todos os pecados atuais, como num certo princípio, e sendo portanto
virtualmente múltiplo; quer pelo pecado do primeiro pai, transmitido pela geração, incluir muitas
deformidades, como a soberba, a desobediência, a gula e semelhantemente. Ou por serem muitas as
partes da alma contaminadas pelo pecado original.

RESPOSTA À SEGUNDA. — Um mesmo hábito não pode inclinar, por si e diretamente, i. é, pela forma
própria, a atos contrários; mas nada impede o faça indiretamente e acidentalmente, i. é, removendo o
obstáculo, como quando, desaparecido o equilíbrio de um corpo misto, os seus elementos tendem para
lugares contrários. E semelhantemente, desaparecido o equilíbrio da justiça original, as diversas
potências da alma se dispersam para termos diversos.

RESPOSTA À TERCEIRA. — O pecado original contaminou as diversas partes da alma, enquanto partes
de um mesmo todo; assim também a justiça original mantinha na unidade todas essas partes. E
portanto, há um só pecado original, assim como só pode haver uma febre, num mesmo homem, embora
sejam diversas as partes do corpo contaminadas.

## Art. 3 — Se o pecado original é a concupiscência.
(Sent., dist. XXX, q. 1, a. 3; Expos. Litt.: dist. XXXII, q. 2, a. 1, ad 3; dist. XXXII, q. 1, a. 1, ad 1, 3, 4; De
Malo, q. 3, a. 7; q. 4, a. 2).
O terceiro discute-se assim. — Parece que o pecado original não é a concupiscência.

1. — Pois, todo pecado é contrário à natureza, como diz Damasceno. Ora, a concupiscência, sendo o ato
próprio da potência concupiscível, potência natural, é conforme a natureza. Logo, não é o pecado
original.

2. Demais. — O pecado original causou em nós as paixões dos pecados, como se vê no Apóstolo (Rm 7).
Ora, há muitas outras paixões, além da concupiscência, como já se estabeleceu. Logo, o pecado original
não é a concupiscência, antes que qualquer outra paixão.

3. Demais. — Pelo pecado original desordenaram-se todas as partes da alma, como já se disse. Ora, a
inteligência é a suprema dessas partes, como está claro no Filósofo. Logo, o pecado original é mais a
ignorância que a concupiscência.
Mas, em contrário, diz Agostinho: a concupiscência é o reato do pecado original.

SOLUÇÃO. — Cada ser se especifica pela sua forma. Ora, como já se disse, o pecado original se
especifica pela sua causa. Logo e necessariamente, a causa do pecado original é a que lhe dá a
formalidade. E como coisas opostas têm causas opostas, deve-se fundamentar a causa do pecado
original pela da justiça original, que se lhe opõe. Ora, toda a ordem da justiça original estava na sujeição
da vontade humana a Deus. Essa sujeição se dava, primária e principalmente, pela vontade, à qual
compete mover todas as outras partes para o fim, como já dissemos. Por onde, o afastamento da
vontade, de Deus, causou a desordem em todas as outras potências da alma. Portanto, a privação da
justiça original, pela qual a vontade estava sujeita a Deus, é o que há de formal no pecado original;
enquanto que todas as outras desordens das potências da alma constituem como o elemento material
desse pecado. Ora, a desordem dessas outras potências consiste, principalmente em buscarem
desordenadamente os bens mutáveis; e essa desordem pode receber a denominação comum de
concupiscência. E portanto, o pecado original é, materialmente, concupiscência; formalmente, porém,
consiste na falta da justiça original.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Sendo no homem a potência concupiscível naturalmente
regulada pela razão, a concupiscência é-lhe natural a ele na medida em que se conforma com a ordem
da razão. E a que ultrapassa os limites da razão é contra a natureza do homem. Ora, tal é a
concupiscência do pecado original.

RESPOSTA À SEGUNDA. — Como já dissemos, as paixões do irascível se reduzem às do concupiscível
como às principais; entre as quais a concupiscência move mais veementemente e é mais sentida, como
já antes estabelecemos. E por isso, é-lhe atribuído o pecado original, como sendo a principal e de certo
modo, inclusiva de todas as outras.

RESPOSTA À TERCEIRA. — Assim como nos bons o intelecto e a razão têm a supremacia; assim nos
maus e inversamente, desempenha o papel principal a parte inferior da alma, que obnubila a razão e a
arrasta, como já se disse. E por isso o pecado original é considerado antes como concupiscência que
como ignorância; embora também a ignorância esteja contida entre as deficiências materiais do pecado
original.

## Art. 4 — Se o pecado original se mani¬festa igualmente em todos.
(II Sent., dist. XXXII, q. 1, a. 3).
O quarto discute-se assim. — Parece que o pecado original não se manifesta igualmente em todos.

1. — Pois, o pecado original é a concupiscência desordenada, como já se disse. Ora, nem todos são
igualmente inclinados à concupiscência. Logo, o pecado original não se manifesta igualmente em todos.

2. Demais. — O pecado original é uma disposição desordenada da alma; assim como a doença o é do
corpo. Ora, a doença é susceptível de mais e de menos. Logo, também o pecado original.

3. Demais. — Agostinho diz que a sensualidade transmite o pecado original à prole. Ora um desenvolve
maior sensualidade que outro, no ato da geração. Logo, o pecado original pode existir em um mais que
em outro.
Mas, em contrário, o pecado original é o pecado da natureza, como já se disse. Ora, a natureza de todos
é igual. Logo, também o pecado original.

SOLUÇÃO. — Dois elementos há no pecado original: a falta da justiça original e a relação dessa falta com
o pecado do primeiro pai, do qual é derivada por uma origem viciosa. — Ora, quanto ao primeiro
elemento, o pecado original não é susceptível de mais nem de menos. Porque nos privou totalmente do
dom da justiça original; ora, as privações que privam totalmente, como a morte e as trevas, não são
susceptíveis de mais nem de menos, como já se disse. — Semelhantemente, nem quanto ao segundo.
Pois, todas se relacionam igualmente com o primeiro princípio da origem viciosa, donde derivou
essencialmente para o pecado original a culpa; ora, relações não são susceptíveis de mais nem de
menos. — Por onde é manifesto, que o pecado original não se manifesta em um mais que em outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Roto o vínculo da justiça original, que mantinha na
ordem, todas as potências da alma, cada uma delas obedece à sua tendência própria, e tanto mais
veemente, quanto mais forte. Ora, sucede que certas potências da alma são mais fortes em um que em
outro, por causa das diversas compleições do corpo. Portanto, o ser um mais inclinado que outro à
concupiscência não provém do pecado original. Porque em todos foi igualmente roto o vínculo da
justiça original, e igualmente em todos as partes inferiores da alma foram abandonadas a si próprias.
Mas isso provém da diversa disposição das potências, como dissemos.

RESPOSTA À SEGUNDA. — A doença do corpo não tem em todos causa igual, mesmo se for
especificamente a mesma. Assim, na febre proveniente da bílis putrefata a putrefação pode ser maior
ou menor e mais próxima ou mais remota do princípio vital. Ao passo que a causa do pecado original é
igual em todos. Logo, a comparação não colhe.

RESPOSTA À TERCEIRA. — A sensualidade transmitente do pecado original à prole não é a sensualidade
atual. Pois, dado que o poder divino concedesse a alguém o não sentir nenhuma sensualidade
desordenada no ato da geração, ainda assim transmitiria à prole o pecado original. Mas devemos
considerar essa sensualidade como a habitual, que torna o apetite sensitivo insubmisso à razão, roto o
vínculo da justiça original. Ora, tal sensualidade é a mesma em todos.