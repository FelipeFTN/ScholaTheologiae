# Questão 28: Dos efeitos do amor.
Em seguida devemos tratar dos efeitos do amor. E sobre esta questão seis artigos se discutem:

## Art. 1 — Se a união é efeito do amor.
(I, q. 20, a . 1, ad 3; supra, q. 25, a . 2, ad 2; III Sent., dist. XXVII, q. 1, a . 1; De Div. Nom., cap. IV, lect. XII).
O primeiro discute-se assim. ― Parece que a união não é efeito do amor.

1. ― Pois, a ausência repugna à união. Ora, o amor é compatível com a ausência, conforme o amor é
compatível com a ausência, conforme se vê no Apóstolo (Gl 4, 18): Sede pois zelosos do bem sempre,
referindo-se a si mesmo, como explica a Glosa, e não só quando eu estou presente convosco. Logo, não
é a união um efeito do amor.

2. Demais. ― Toda união ou é essencial, como quando a forma se une à matéria, o acidente ao sujeito, à
parte ao todo ou a outra parte para constituir o todo; ou é em virtude de uma semelhança genérica,
específica ou acidental. Ora, o amor não causa a união essencial, do contrário nunca haveria amor por
coisas divididas na essência. Mas também não causa a união baseada na semelhança, antes, é por esta
causado, como já se disse. Logo, a união não é efeito do amor.

3. Demais. ― O sentido em ato torna-se o sensível em ato e o intelecto em ato torna-se o objeto
inteligido em ato. Ora, o amante em ato não se torna o objeto amado em ato. Logo, a união é mais
efeito do conhecimento que do amor.
Mas, em contrário, diz Dionísio, que qualquer amor é uma virtude unitiva.

SOLUÇÃO. ― É dupla forma a união do amante com o amado. Uma real, quando este está
presencialmente naquele; outra porém pelo afeto. E esta deve ser considerada relativamente à
apreensão precedente, pois o movimento apetitivo é conseqüente à apreensão. Ora, sendo o amor de
duas espécies ― o de concupiscência e o de amizade, um e outro procede de uma certa apreensão de
unidade entre o amado e o amante. Pois quem ama alguma coisa, quase desejando-a, apreende-a como
necessário ao seu bem estar. Semelhantemente, quem ama alguém por amor de amizade quer-lhe o
bem que quer a si mesmo, e por isso o apreende como outro eu, enquanto lhe quer o bem, do referido
modo. E daí vem o dizer-se que o amigo é um outro eu; e Agostinho: Bem disse aquele que considerou o
amigo como metade da sua alma.
Por onde, a primeira união o amor a causa efetivamente, porque leva a desejar e buscar a presença do
amado, como algo que lhe convém e lhe pertence. A segunda união ele a causa formalmente, pois que o
amor em si mesmo consiste nessa união ou nexo. Por isso Agostinho diz, que o amor é um quase laço
que une ou tende a unir dois seres ― o amante e o amado, ― referindo-se une à união do afeto, sem a
qual não há amor; e tende a unir, à união real.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção colhe quanto à união real que, certo, implica a
deleitação como causa; enquanto que o desejo importa na ausência real do amado, o objeto do amor
pode lhe estar tanto ausente como presente.

RESPOSTA À SEGUNDA. ― A união mantém tríplice relação com o amor. ― Uma o causa e esta é
substancial, no amor pelo qual nos amamos a nós mesmos; é porém união de semelhança, no amor pelo
qual amamos os outros seres, como já se disse. ― Há outra união porém, na qual consiste
essencialmente o amor e esta se funda na coaptação do afeto, e se assimila à união substancial,
enquanto o amante tem relação com o amado como se fosse consigo mesmo, pelo amor de amizade, e
como se fosse algo de si, pelo amor de concupiscência. Há por fim outra união, efeito do amor, e esta é
a real, que o amante busca no ser amado e que se funda na conveniência do amor. Por isso segundo o
Filósofo, Aristófanes disse que os amantes desejam constituir um único ser. Mas, como isto causaria a
corrupção de ambos ou de um dos dois, buscam a união conveniente e própria, que os leva à
convivência, à mútua conversação e a modos semelhantes de união.

RESPOSTA À TERCEIRA. ― O conhecimento se completa pela união do conhecido com o conhecente,
por semelhança. O amor porém faz com que a coisa amada mesma se una de certo modo com o
amante, conforme já dissemos. Por onde, o amor é mais unitivo que o conhecimento.

## Art. 2 — Se o amor causa a mútua inerência, i. é, se faz com que o amante esteja no amado e reciprocamente.
(III Sent., dist. XXVII, q. 1, a . 1 ad 4).
O segundo discute-se assim. ― Parece que o amor não causa a mútua inerência, i. é, não faz com que
o amante esteja no amado e reciprocamente.

1. ― Pois, o que está em outro ser é contido por este. Ora, o continente não se identifica com o
conteúdo. Logo, o amor não pode causar a mútua inerência, de modo que o amado esteja no amante e
reciprocamente.

2. Demais. ― Não podemos penetrar no íntimo de um ser íntegro senão dividindo-o. Ora, dividir coisas
realmente unidas não pertence ao apetite, no qual tem sua sede o amor, mas à razão. Logo, a mútua
inerência não é efeito do amor.

3. Demais. ― Se pelo amor o amante está no amado e inversamente, conclui-se que o amado se une ao
amante, do mesmo modo por que este se une com aquele. Ora, a união mesma é o amor, como já se
disse. Donde se conclui, que sempre o amante há-de ser amado por quem o ama, o que é claramente
falso. Logo, a mútua inerência não é efeito do amor.
Mas, em contrário, diz a Escritura (1 Jo 4, 16): aquele que permanecer na caridade permanece em Deus,
e Deus nele. Ora, a caridade é o amor de Deus. Logo, pela mesma razão, qualquer amor faz com que o
amado esteja no amante.

SOLUÇÃO. ― O efeito em questão da mútua inerência, pode ser entendido relativamente à virtude
apreensiva e à apetitiva.
Assim quanto à primeira, dizemos que o amado está no amante na medida em que este é assimilado
pela apreensão daquele, conforme a Escritura (Fl 1, 7): porque vos tenha no coração. ― Dizemos porém
que o amante está no amado pela apreensão, enquanto não se contenta com uma apreensão superficial
do amado, mas antes procura escrutar intimamente tudo o que ao amado pertence, penetra-lhe o
íntimo. Nesse sentido, do Espírito Santo, que é o Amor de Deus, diz a Escritura (1 Cor 2, 10): que penetra
ainda o que há de mais oculto na profundidade de Deus.
Relativamente à virtude apetitiva porém, dizemos que o amado está no amante por provocar-lhe uma
certa complacência do afeto, de modo que se deleite com o amado, ou com os seus bens, ou com a sua
presença; ou ainda, quando o amado está ausente, busque-o por amor de concupiscência, ou os bens
que, por amor de amizade, lhe quereria; e não por nenhuma causa extrínseca, como quando desejamos
alguma coisa por causa de outra, ou desejamos o bem a outrem por uma outra coisa qualquer, senão só
por complacência do amado que lhe está intimamente radicada. Por isso o amor se chama íntimo, e se
fala nas vísceras da caridade. ― Inversamente porém, o amante está no amado, de um modo, pelo
amor de concupiscência, de outro, pelo de amizade. Ora, o amor de concupiscência não repousa numa
obtenção ou fruição qualquer, extrínseca ou superficial do bem amado, mas procura possuí-lo
perfeitamente, quase penetrando-lhe no íntimo. Ao passo que no amor de amizade, o amante está no
amado, porque reputa como seus os bens e os males do amigo, e como sua a vontade do amigo, de
modo que se considere como afetado dos mesmos bens e dos mesmos males que afetam o amigo. E por
isso é próprio dos amigos quererem as mesmas coisas, alegrarem-se e entristecerem-se com elas,
segundo o Filósofo, que ainda diz em outro passo que, do modo supra-mencionado, considerando seu o
que é do amigo, o amante se considere como estado no amado, quase identificado com ele, e enquanto,
reciprocamente, quer e age por causa do amigo como por causa de si mesmo, quase considerando-o
como identificado consigo, desse modo o amado está no amante.
Pode-se ainda entender a mútua inerência de um terceiro modo, relativamente ao amor de amizade,
por via do amor mútuo, enquanto os amigos mutuamente se amam e mutuamente se querem bem e se
beneficiam.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O amado está contido no amante, enquanto se lhe
imprime no afeto por uma certa complacência deste. Inversamente porém o amante está contido no
amado, enquanto busca de certo modo o que a este lhe é íntimo. Por onde, nada impede um mesmo ser
seja, em diversos pontos de vista, continente e contido; assim. O gênero se contém na espécie e
reciprocamente.

RESPOSTA À SEGUNDA. ― A apreensão da razão precede ao afeto do amor. Por onde, assim como a
razão inquire, assim o afeto do amor penetra o ser amado, como do sobredito claramente resulta.

RESPOSTA À TERCEIRA. ― A objeção colhe relativamente ao modo de mútua inerência, que não se
encontra em qualquer amor.

## Art. 3 — Se o êxtase é um efeito do amor.
(IIª-IIªº, q. 175, a . 2; III Sent., dist. XXVII, q. 1, a . 1 ad 4; II Cor., cap. XII, lect. I; De Div.Nom., cap. IV, lect
X).
O terceiro discute-se assim. ― Parece que o êxtase não é efeito do amor.

1. ― Pois, o êxtase implica uma certa alienação. Ora, esta nem sempre a produz o amor, pois os
amantes são por vezes senhores de si. Logo, o amor não produz o êxtase.

2. Demais. ― O amante deseja que o amado lhe esteja unido. Por onde, antes o atrai para si do que
tende para ele, saindo fora de si.

3. Demais. ― O amor une o amado ao amante, como dissemos. Se pois o amante tende, saindo fora de
si, para o amado afim de buscá-lo, resulta que sempre mais o ama que a si mesmo, o que é claramente
falso. Logo, o êxtase não é efeito do amor.
Mas, em contrário, diz Dionísio, que o divino amor produz o êxtase, e que o próprio Deus por amor
sofreu o êxtase. Ora, sendo todo amor uma como semelhança participada do amor divino, conforme na
mesma obra se lê, resulta que todo amor causa o êxtase.

SOLUÇÃO. ― Dizemos que alguém sofre o êxtase quando fica fora de si mesmo; e isso pode dar-se em
relação à potência apreensiva como à apetitiva. ― Em relação à primeira dizemos que alguém fica fora
de si mesmo quando se alheia ao pensamento próprio, quer por elevado para um ser superior, com
quando o é à compreensão de certas verdades que sobrepujam a capacidade da razão e dos sentidos;
quer por ser rebaixado a um nível inferior, quando cai em fúria ou amência, dizendo-se então que sofre
êxtase. ― Relativamente à parte apetitiva porém, dizemos que alguém sofre um êxtase quando o seu
apetite busca algum objeto, saindo de certo modo fora de si mesmo.
Ora, o êxtase da primeira espécie o amor o produz dispositivamente, fazendo meditar no ser amado,
como dissemos; e a meditação intensa num objeto abstrai o espírito, de outros. ― O êxtase da segunda
espécie o amor produz direta e absolutamente, quando é amor de amizade; não assim, mas de certo
modo, quando é amor de concupiscência. Pois, nesta última espécie de amor, o amante é de algum
modo levado para fora de si mesmo, porque, não contente com o gozo do bem possuído, busca fruir
algo de extrínseco; mas, querendo ter para si esse bem extrínseco, não sai absolutamente de si, mas
essa afeição pelo fim se encerra no próprio eu. Pelo amor de amizade porém, o afeto se alheia,
absolutamente ao sujeito, porque quer bem ao amigo e pratica o bem, por causa mesma do amigo,
quase dele tomando cuidado e providência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção colhe quanto à primeira espécie de êxtase.

RESPOSTA À SEGUNDA. ― A Objeção colhe em relação ao amor de concupiscência, que não produz
absolutamente o êxtase, como dissemos.

RESPOSTA À TERCEIRA. ― Quem ama sai fora de si mesmo na medida em que quer bem ao amigo e por
ele age. Ora, não quer as coisas do amigo mais que as suas. Donde não se segue que ama a outrem mais
que a si mesmo.

## Art. 4 — Se o zelo é efeito do amor.
(In Ioann., cap. II, lect. II; Cor., cap. XIV; lect. I; II, cap. XI, lect 1).
O quarto discute-se assim. ― Parece que o zelo não é efeito do amor.

1. ― Pois, o zelo é princípio da contenção, e por isso diz a Escritura (1 Cor 3, 3): Por quanto, havendo
entre vós zelos e contendas, etc. Ora, a contenção repugna ao amor. Logo, o zelo não é efeito do amor.

2. Demais. ― O objeto do amor é o bem, de si mesmo comunicativo. Ora, o zelo repugna à
comunicação, pois por zelo não admitimos participe outrem do ser amado; assim, dizemos que os
homens tem zelos pelas esposas, porque não querem tê-las em comum com outros. Logo, o zelo não é
efeito do amor.

3. Demais. ― O zelo não vai sem o ódio nem sem o amor, pois, diz a Escritura (Sl 72, 3): Tive zelo sobre
os ímpios. Logo, não deve ser considerado efeito mais do amor que do ódio.
Mas, em contrário, diz Dionísio, que Deus é chamado zelote, pelo muito amor que tem pelos seres
existentes.

SOLUÇÃO. ― O zelo, qualquer que seja o sentido que lhe dê, provém da intensidade do amor. Ora, é
manifesto que quanto mais intensamente uma potência tende para um objeto, tanto mais fortemente
repele tudo o contrário e repugnante. Ora, sendo o amor um certo movimento para o amado com diz
Agostinho, o amor intenso procura excluir tudo o a que repugna.
Porém isto se dá, de um modo, no amor de concupiscência, e de outro no de amizade. ― Pois, quem
intensamente deseja uma coisa é levado, contra tudo o que repugna à consecução ou ao gozo tranqüilo
do ser amado. Dizemos então, que os maridos têm zelos pelas esposas, afim de a participação de outros
não contrariar a posse exclusiva que delas querem ter. Semelhantemente, os que buscam a excelência
se opõem aos que são considerados excelentes e lhes impedem a excelência que querem ter. E este é o
zelo da inveja, da qual diz a Escritura (Sl 36, 1): Não queiras imitar aos malignos, nem invejes aos que
obram iniqüidade. ― O amor de amizade porém quer o bem do amigo, e por isso quando é intenso leva
a nos insurgir contra tudo o que repugna ao bem do amigo. E neste sentido dizemos que zela pelo amigo
quem se esforça por repelir o que se diz ou faz contra o bem do mesmo. E também deste modo dizemos
que zela por Deus quem se esforça por repelir como pode tudo o que é contra a honra ou a vontade de
Deus, segundo aquilo da Escritura (3 Rs 19, 14): Eu me consumo de zelo pelo Senhor Deus dos exércitos;
e sobre aquilo do Evangelho (Jo 2, 17): O zelo da tua casa me comeu, diz a Glosa que é devorado do zelo
quem se apressa em corrigir qualquer mal que vê e, se não o pode, tolera-o gemendo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― No passo aduzido o Apóstolo se refere ao zelo da inveja
que é, certo, causa da contenção, não contra o objeto amado, mas, em favor dele, contra tudo o que lhe
é impedimento.

RESPOSTA À SEGUNDA. ― O bem é amado enquanto é comunicável ao amante; por isso tudo o que
impede a perfeição dessa comunicação torna-se odioso, e assim o zelo é causado pelo amor do bem.
Acontece porém que, por bondade deficiente, certos bens limitados não podem ser integralmente
possuídos por muitos, nascendo então do amor desses bens o zelo da inveja. Não nasce porém
propriamente, dos bens que podem, na sua integralidade, ser possuídos por muitos; assim ninguém
inveja outrem por causa do conhecimento da verdade, capaz de ser conhecida por muitos
integralmente; mas talvez por causa da excelência desse conhecimento.

RESPOSTA À TERCEIRA. ― É do amor mesmo que procede o ódio pelo que repugna ao amado. Por
onde, o zelo, propriamente falando, é considerado efeito, mais do amor que do ódio.

## Art. 5 — Se o amor é paixão lesiva.
(III Sent., dist. XXVII, q. 1, a . 1, ad 4).
O quinto discute-se assim. ― Parece que o amor é uma paixão lesiva.

1. ― Pois, o desfalecimento ou langor manifesta uma certa lesão de quem desfalece. Ora, o amor causa
desfalecimento ou langor, conforme a Escritura (Ct 2, 5): Acudi-me com confortativos de flores, trazei-
me pomos que me alentem, porque desfaleço de amor. Logo, o amor é uma paixão lesiva.

2. Demais. ― Derreter-se é quase dissolver-se. Ora, o amor causa derretimento, conforme a Escritura
(Ct 5, 6): A minha alma se derreteu assim que ele (o meu amado) falou. Logo, o amor, causando
derretimento, é corruptivo e lesivo.

3. Demais. ― O fervor designa certo excesso de calidez, que é corruptivo. Ora, o fervor é causado pelo
amor, pois Dionísio conta, entre as outras propriedades pertencentes ao amor dos Serafins, a calidez, a
penetração e o grande fervor; e a Escritura diz (Ct 8, 6), que as suas alâmpadas (do amor) são umas
alâmpadas de fogo e chama. Logo, o amor é uma paixão lesiva e corruptiva.
Mas, em contrário diz Dionísio, que todos os seres se amam intensamente, i. é, procurando conservar-
se. Logo, o amor não é uma paixão lesiva, mas antes, conservadora e perfectiva.

SOLUÇÃO. ― Como dissemos, amor significa uma certa coaptação da virtude apetitiva para algum bem.
Ora, o que tem coaptação para algo que lhe é conveniente não fica lesado por isso, antes, se for
possível, mais se aperfeiçoa e melhora. Ao contrário, o que tem coaptação para algo de inconveniente
fica por isso lesado e pior. Ora, o amor do bem conveniente aperfeiçoa e melhora o amante; ao passo
que o amor inconveniente ao amante lesa-o e torna-o pior. Por onde, o homem se aperfeiçoa e
melhora, soberanamente, pelo amor de Deus, e sofre lesão e piora pelo amor do pecado, conforme a
Escritura (Os 9, 10): e se tornaram abomináveis com as coisas que amaram.
Mas isto que acaba de ser dito se refere ao que há de formal no amor e dependente do apetite. Pelo
que tem de material, que é uma certa alteração corpórea, essa paixão pode ser lesiva pelo excesso da
alteração, como acontece com os sentidos e com todos os atos de uma potência da alma, que se exerce
mediante alguma alteração de órgão corpóreo.

RESPOSTA ÀS OBJEÇÕES EM CONTRÁRIO. ― Ao amor podem-se atribuir quatro efeitos próximos:
derretimento, fruição, langor e fervor. O primeiro é o derretimento, oposto à congelação. Ora, as coisas
congeladas se contraem de modo a não poderem ser facilmente penetradas. O amor porém, dá ao
apetite a coaptação para receber o bem amado, na medida em que este está no amante, como já
dissemos. Por onde, o congelamento ou dureza do coração é disposição repugnante ao amor. O
derretimento pelo contrário implica um certo amolecimento do coração, que o torna apto a receber o
amado. ― Quando pois está presente e possuído este, causa o prazer ou fruição. ― Quando ausente,
causa duas paixões: uma, a tristeza pela ausência, manifestada pelo langor, sendo, por isso, que Túlio dá
principalmente à tristeza o nome de ansiedade; outra, o desejo intenso de possuir o amado,
manifestado pelo fervor. ― E estes são os efeitos do amor formalmente considerado, conforme a
relação entre a virtude apetitiva e o objeto. ― Mas a paixão do amor produz, relativamente à alteração
do órgão, certos efeitos proporcionados aos que acabamos de ver.

## Art. 6 — Se o amante faz tudo por amor.
(III Sent., dist. XXVII, q. 1, a . 1).
O sexto discute-se assim. ― Parece que o amante não faz tudo por amor.

1. ― Pois, o amor é uma paixão, como dissemos. Mas, nem tudo o que faz o homem o faz por paixão;
mas certas coisas, por eleição e certas, por ignorância, como diz Aristóteles. Logo, nem tudo o homem
faz por amor.

2. Demais. ― O apetite é princípio de movimento e da ação em todos os animais, como diz Aristóteles.
Se pois tudo fazemos por amor, serão supérfluas as outras paixões da parte apetitiva.

3. Demais. ― Nada é causado simultaneamente por causas contrárias. Ora, certos atos são praticados
por ódio. Logo, nem tudo é feito por amor.
Mas, em contrário, diz Dionísio, que tudo o feito por amor o é.

SOLUÇÃO. ― Todo agente age em vista de um fim, como já dissemos. Ora, o fim é o bem de cada um
desejado e amado. Por onde, é manifesto que todo e qualquer agente pratica todas suas ações por
amor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção colhe relativamente ao amor, paixão do
apetite sensitivo; e nós nos referimos agora ao amor na sua acepção comum, enquanto compreende em
si o amor intelectual, o racional, o animal e o natural. E é nesse sentido que Dionísio fala do amor.

RESPOSTA À SEGUNDA. ― O amor causa, como já dissemos o desejo, a tristeza, o prazer e, por
conseqüência, todas as outras paixões. Por onde, todo ato procedente de qualquer paixão procede
também do amor, como da causa primeira; logo, não são supérfluas as demais paixões, como causas
próximas.

RESPOSTA À TERCEIRA. ― Também o ódio é causado pelo amor, como a seguir se dirá.