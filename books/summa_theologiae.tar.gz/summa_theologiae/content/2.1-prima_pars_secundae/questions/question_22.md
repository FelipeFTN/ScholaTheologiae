# Questão 22: Do sujeito das paixões da alma.
Em seguida devemos tratar das paixões da alma. Primeiro, em geral. Segundo, em especial. Em geral,
quatro questões devemos estudar, relativamente a elas. Primeiro, do sujeito delas. Segundo, da
diferença entre elas. Terceiro, da comparação mútua entre as mesmas. Quarto, da sua malícia e
bondade.
Sobre a primeira questão três artigos se discutem:

## Art. 1 — Se a alma tem paixões.
(III Sent., dist. XV. Q. 2, a . 1, qª 2; De Verit., q. 26, a . 1, 2).
O primeiro discute-se assim. ― Parece que a alma não tem paixões.

1. ― Pois, sofrer é próprio da matéria. Ora, a alma não é composta de matéria e forma, como
estabelecemos na primeira parte. Logo, a alma não tem paixões.

2. Demais. ― A paixão é um movimento, como diz Aristóteles. Ora, a alma não é movida, como ainda
Aristóteles o prova. Logo, nela não há paixões.

3. Demais. ― A paixão é causa de corrupção, pois, como diz Aristóteles, toda paixão aumenta em
detrimento da substância. Ora, a alma é incorruptível. Logo, não tem paixões.
Mas, em contrário, diz o Apóstolo (Rm 7, 5): Porque, enquanto estávamos na carne, as paixões dos
pecados, que havia pela lei, obravam em nossos membros. Ora, os pecados existem propriamente, na
alma. Logo, também as paixões chamadas dos pecados.

SOLUÇÃO. ― A palavra sofrer tem tríplice acepção. Uma, comum, pela qual todo receber é sofrer,
mesmo que o ser nenhum detrimento sofra; assim dizemos que o ar sofre quando é iluminado. Ora, isto
é mais propriamente aperfeiçoar-se que sofrer. ― Num sentido próprio, empregamos a palavra sofrer
para significar uma coisa recebida com exclusão de outra, o que de dois modos pode dar-se. Ora, é
excluído o que não convém ao ser; assim, quando o corpo de um animal sara, dizemos que sofre porque
recebe a saúde, por exclusão da doença. ― De outro modo, inversamente; assim, dizemos que estar
doente é sofrer, porque recebemos a doença, por exclusão da saúde; e este é o modo mais próprio à
paixão. Pois sofrer implica em alguma coisa ser atraída para o agente, porquanto, o ser que fica privado
do que lhe é conveniente é considerado, sobretudo, como atraído para outro ser. E semelhantemente,
Aristóteles diz que quando do menos nobre se gera o mais nobre há geração, absolutamente, e
corrupção, relativamente; e ao inverso, quando do mais nobre é gerado o menos nobre.
Ora, deste três modos a alma tem paixões. Assim, quanto à recepção, dizemos que sentir e
compreender é de certo modo sofrer. Por outro lado, a paixão acompanhada de exclusão só existe
seguida de alteração corpórea. Por onde, a paixão propriamente dita não pode convir à alma senão
acidentalmente, a saber, na medida em que o composto comporta o sofrimento. Ora, há aqui
diversidade de situações; assim, quando tal alteração se faz para pior mais propriamente se realiza a
noção de paixão, do que quando se faz para melhor, e por isso a tristeza é paixão mais propriamente
que a alegria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Sofrer acompanhado de exclusão e de alteração é
próprio da matéria, e por isso só afeta os seres compostos de matéria e forma. Mas, quando implica
somente recepção, não afeta só e necessariamente a matéria, mas pode também afetar qualquer ser
existente em potência. Ora, a alma, embora não seja composta de matéria e forma, encerra contudo
uma certa potencialidade, em virtude da qual lhe convém o receber e o sofrer, e nesse sentido dizemos
que inteligir é sofrer, conforme Aristóteles.

RESPOSTA À SEGUNDA. ― Sofrer e ser movido, embora não convenha à alma, em si mesma convém-lhe
contudo acidentalmente, como diz Aristóteles.

RESPOSTA À TERCEIRA. ― A objeção colhe relativamente à paixão que implica alteração para pior; e tal
paixão senão acidentalmente pode convir à alma; mas, em si mesma convém ao composto, que é
corruptível.

## Art. 2 — Se a paixão reside mais na parte apreensiva que na apetitiva.
(III Sent., dist. XV, q. 2, a . 1 qª 2;De Verit., q. 26, a . 3; De Dir. Nom., cap. II, lect. IV; II Ethic., lect. V).
O segundo discute-se assim. ― Parece que a paixão reside mais na parte apreensiva que na apetitiva.

1. ― Pois, o que é primeiro, em qualquer gênero ocupa nesse gênero o primeiro lugar e é a causa do
mais, como diz Aristóteles. Ora, a paixão existe na parte apreensiva antes de existir na apetitiva, pois
esta não a sente sem que ela afete precedentemente aquela. Logo, a paixão reside mais na parte
apreensiva que na apetitiva.

2. Demais. ― O que tem maior atividade tem menor passividade, pois a ação se opõe à paixão. Ora, a
parte apetitiva é mais ativa que a apreensiva. Logo, nesta sobretudo reside a paixão.

3. Demais. ― Assim como o apetite sensitivo, também a potência apreensiva sensitiva é virtude de
órgão corpóreo. Ora, a paixão da alma implica propriamente falando uma alteração corpórea. Logo, não
está mais na parte apetitiva que na apreensiva sensitiva.
Mas, em contrário, diz Agostinho: os movimentos da alma a que os Gregos chamam πχδη, e o latinos,
como Cícero, perturbações, outros os denominam afecções ou afetos, e outros ainda, como em grego e
mais expressivamente, paixões. Donde se conclui claramente que as paixões da alma são o mesmo que
afecções; e como estas pertencem manifestamente à parte apetitiva e não à apreensiva, conclui-se que
aquelas residem mais na primeira que na última.

SOLUÇÃO. ― Como já dissemos, o nome de paixão implica que o paciente é atraído pela ação do
agente. Ora, a alma é atraída para o objeto externo, mais pela virtude apetitiva que pela apreensiva.
Pois por meio daquela põe-se em relação com as coisas mesmas tais como são, e por isso diz o Filósofo
que o bem e o mal, objetos da potência apetitiva, estão nas coisas mesmas. A virtude apreensiva porém
não é atraída para as coisas em si mesmas, mas as conhece pela espécie delas, que tem em si ou recebe
conforme o modo que lhe é próprio; por isso, no mesmo lugar diz Aristóteles, que a verdade e a
falsidade, que pertencem à inteligência, não estão nas coisas, mas na mente. Por onde claramente se vê
que a paixão em si mesma reside mais na parte apetitiva que na apreensiva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A intensidade se comporta de modo contrário conforme
é relativa à perfeição ou à deficiência. Em relação à primeira a intensidade supõe aproximação de um
primeiro princípio, e é tanto maior quanto mais próxima se acha dele. Assim, a intensidade da luz num
corpo lúcido varia com a aproximação do que é lúcido em máximo grau, e tanto mais lúcido é um corpo
quanto mais próximo está deste último. Mas no atinente à deficiência, a intensidade varia, não com o
aproximar-se do que é maximamente intenso, mas com o afastar-se da perfeição, pois nisto consiste a
essência da privação e da deficiência. Por onde, quanto mais se afasta do termo último, tanto menos
intensidade tem; e assim se explica que um defeito, pequeno sempre no princípio, aumente quanto
mais progride. Ora, a paixão implica uma deficiência, pois é própria do ser potencial. Logo, os seres que
se aproximam da perfeição primeira. ― Deus, pouco tem de potencialidade e de paixão; e o contrário se
dá conseqüentemente com os que dele mais se afastam. E assim também, na potência da alma, que tem
prioridade, a saber, a apreensiva, há menos do que constitui a essência da paixão.

RESPOSTA À SEGUNDA. ― A virtude apetitiva é considerada mais ativa porque é sobretudo o princípio
do ato exterior; e é tal em virtude do princípio que a torna, sobretudo passiva, i. é, por se ordenar ao
objeto em si mesmo; pois, pela ação exterior é que chegamos a alcançá-los.

RESPOSTA À TERCEIRA. ― Como já dissemos na primeira parte, um órgão da alma pode alterar-se de
duplo modo. Primeiro, por transmutação espiritual, enquanto recebe a espécie da coisa. E isto se dá
essencialmente como o ato da virtude apreensiva sensitiva; assim os olhos são imutados pelo objeto
visível, não que fique colorido mas por receber a espécie da cor. Há porém outra transmutação do órgão
― a natural ― pela qual se altera a sua disposição natural; isso se dá, p. ex., com o corpo aquecido ou
resfriado ou afetado de modo semelhante. E tal transmutação é acidental em relação ao ato da virtude
apreensiva sensitiva; assim quando os olhos se cansam por causa da visão forçada ou se embotam pela
veemência do objeto visível. Ora, esta espécie de transmutação se ordena em si ao ato do apetite
sensitivo; por isso na definição dos movimentos da parte apetitiva inclui-se, materialmente, uma
transmutação natural do órgão, e assim dizemos que a ira faz ferver o sangue no coração. Por onde é
claro que a paixão em essência reside mais no ato da virtude sensitiva apetitiva, do que no da virtude
sensitiva apreensiva, embora uma e outra seja ato de órgão corpóreo.

## Art. 3 — Se a paixão reside mais no apetite sensitivo que no intelectivo.
(I, q. 20, a . 1, ad 1; III Sent., dist. XV, q. 2, a . 1, qª 2; IV dist. XLIX, q. 3, a . 1, qª 2, ad 1; De Verit., q. 26, a .
3; II Ethic., lect. V).
O terceiro discute-se assim. ― Parece que a paixão não reside mais no apetite sensitivo que no
intelectivo.

1. ― Pois, diz Dionísio, que Hieroteu, ensinado por uma diviníssima inspiração, não só aprendeu as
coisas divinas, como teve a paixão delas. Ora, a paixão do divino não pode pertencer ao apetite
sensitivo, cujo objeto é o bem sensível. Logo, a paixão reside no apetite intelectivo tanto como no
sensitivo.

2. Demais. ― Quanto mais poderosa for uma atividade, tanto mais forte será a paixão correspondente.
Ora, o objeto do apetite intelectivo, que é o bem universal, é mais poderosamente ativo que o do
apetite sensitivo, que é o bem particular. Logo, a paixão reside essencialmente mais no apetite
intelectivo que no sensitivo.

3. Demais. ― A alegria e o amor são considerados paixões. Ora, afetam também o apetite intelectivo e
não só o sensitivo; do contrário, a Escritura não os atribuiria a Deus e aos anjos. Logo, as paixões não
residem mais no apetite sensitivo que no intelectivo.
Mas, em contrário, diz Damasceno, descrevendo as paixões animais: A paixão é um movimento da
virtude apetitiva sensível provocado pela imaginação do bem ou do mal. Por outra: a paixão é um
movimento da alma irracional provocado pela idéia do bem e do mal.

SOLUÇÃO. ― Como já dissemos, existe propriamente paixão onde há transmutação do corpo; e esta se
encontra nos atos do apetite sensível, não só espiritual ― como na apreensão sensitiva ― mas também
natural. O ato do apetite intelectivo, ao contrário, não requer nenhuma transmutação corpórea, porque
esse apetite não é virtude de nenhum órgão. Por onde é claro, que a paixão, em essência, reside mais
propriamente no ato do apetite sensitivo do que no do intelectivo; e isso também se vê claramente nas
definições aduzidas de Damasceno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― No passo citado, paixão do divino significa afeto pelas
coisas divinas e união com elas pelo amor, o que na verdade se realiza sem transmutação corpórea.

RESPOSTA À SEGUNDA. ― A magnitude da paixão depende não só da virtude do agente mas também
da passibilidade do paciente; pois seres facilmente passíveis são-no em relação mesmo ao que é pouco
ativo. Embora portanto, o objeto do apetite intelectivo seja mais ativo que o do sensitivo, contudo este
é mais passivo.

RESPOSTA À TERCEIRA. ― O amor, a alegria e sentimentos semelhantes, quando se atribuem a Deus,
aos anjos ou aos homens, como pertencentes ao apetite intelectivo, significam um ato simples da
vontade com semelhança de efeito, sem paixão. Por isso, diz Agostinho: Os santos anjos punem sem ira
e socorrem sem se perturbarem pela compaixão da miséria. E contudo as denominações de tais paixões
lhes são aplicadas pelo uso ordinário da linguagem humana, para exprimirem uma certa conformidade
de ação e não a fraqueza da paixão.