# Questão 76: Das causas do pecado em especial.
Em seguida devemos tratar das causas do pecado em especial. Primeiro, das causas interiores, em
especial.Segundo, das exteriores. Terceiro, dos pecados que são causas de outros.
Ora, a primeira consideração, segundo o que já foi dito, será tripartida. Assim, primeiro, trataremos da
ignorância, causa do pecado, no concernente à razão. Segundo, da fraqueza ou paixão, causa do pecado
no concernente ao apetite sensitivo. Terceiro, da malícia, causa do pecado, no concernente à vontade.
Sobre a primeira questão discutem-se quatro artigos:

## Art. 1 — Se a ignorância pode ser causa do pecado.
(Infra, a. 3 ; De Malo, q. 3, a. III Ethic., lect. III).
O primeiro discute-se assim. ― Parece que a ignorância não pode ser causa do pecado.

1. ― Pois, o não-ser não tem causa nenhuma. Ora, a ignorância, sendo uma privação da ciência, é não-
ser. Logo, não pode ser causa do pecado.

2. Demais. ― As causas do pecado se deduzem da conversão, como do sobredito resulta (q. 75, a. 1).
Ora, parece que a ignorância respeita à aversão. Logo, não dever ser considerada causa do pecado.

3. Demais. ― Todo pecado depende da vontade, como já disse (q. 74, a. 1). Ora, esta não visa senão o
que já é conhecido, pois, o seu objeto é o bem apreendido. Logo, a ignorância não pode ser causa do
pecado.
Mas, em contrário, diz Agostinho, que certos pecam por ignorância.

SOLUÇÃO. ― Segundo o Filósofo, a causa motora é dupla: uma o é por si mesma; outra, por acidente.
Por si mesma o é a que move por virtude própria; assim, o gerador é causa motora dos graves e dos
leves. Por acidente, quando remove o impedimento, ou quando é a remoção mesma deste. Ora, de tal
modo, a ignorância pode ser causa do ato pecaminoso; pois, ela é a privação da ciência, que aperfeiçoa
a razão, a qual, por dirigir os atos humanos, proíbe os atos pecaminosos.
Devemos porém considerar, que a razão é diretiva dos atos humanos, por uma dupla ciência: pela
ciência universal e pela particular. Pois, quando reflete no que devemos fazer, se serve de um silogismo,
cuja conclusão é o juízo, ou a eleição ou a obra. Ora, como as ações recaem sobre o singular, singular
também há de ser a conclusão do silogismo prático. Mas, a proposição singular não se conclui da
universal senão mediante outra proposição singular. Assim, ao homem é proibido o ato do parricídio,
por saber que não se deve matar o próprio pai, e que certo indivíduo é o pai. Logo, uma e outra
ignorância podem causar o ato do parricídio, a saber: a do princípio universal, que é uma regra da razão,
e a da circunstância singular. Por onde, é claro, não é qualquer ignorância do pecador a causa do
pecado, mas só a que priva da ciência proibitiva do ato pecaminoso. Portanto, se a vontade de alguém
estivesse de tal modo disposta que lhe não proibisse o ato do parricídio, ainda conhecendo o próprio
pai, o desconhecer a este não lhe é àquele causa de pecado. E portanto tal indivíduo peca, não
por ignorância, mas ignorando, segundo o Filósofo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O não-ser não pode, por si mesmo, ser causa de nada;
pode contudo ser causa acidental, removendo o impedimento.

RESPOSTA À SEGUNDA. ― Assim como a ciência, exclusiva da ignorância, causa o pecado, pelo que há
nele de conversão, assim a ignorância, no atinente a essa conversão, é causa do pecado, removendo o
obstáculo.

RESPOSTA À TERCEIRA. ― A vontade não pode ser levada ao totalmente desconhecido; mas pode
querer o que é, em parte, conhecido e, em parte, ignoto. E deste modo, a ignorância é causa de pecado;
assim, quando alguém sabe que mata um homem, mas ignora seja este o próprio pai; ou quando sabe
que um ato é deleitável, mas não sabe que constitui pecado.

## Art. 2 — Se a ignorância é pecado.
(Supra, q. 74, a. 1, ad 2 ; a. 5 ; IIª-IIªª, q. 53, a. 2 ; II Sent., dist. XXII, q. 2, a. 1 ; dist. XLII, q. 2, qª 3, ad 3; IV
dist. IX, a. 3, qª 2, ad 1 ; De Malo, q. 3, a. 7 ; Quodl. I, q. 9, a. 3 ; III Ethic., lect. XI).
O segundo discute-se assim. – Parece que a ignorância não é pecado.

1. ― Pois, pecado é o dito, feito ou desejado contra a lei de Deus, como já se estabeleceu (q. 71, a. 6).
Ora, a ignorância não implica nenhum ato interior nem exterior. Logo, não é pecado.

2. ― O pecado se opõe mais diretamente à graça que à ciência. Ora, a privação da graça não é pecado,
mas antes, pena conseqüente ao pecado. Logo, a ignorância, privação da ciência, não é pecado.

3. ― Demais. ― Se a ignorância é pecado, só por ser voluntária o é. Ora, se a ignorância só é pecado
quando voluntária, resulta que o pecado consiste antes nesse ato mesmo da vontade do que na
ignorância. Logo, esta não é pecado, mas antes, uma conseqüência dele.

4. ― Demais. ― Todo pecado é delido pela penitência; nenhum há, salvo o original, que, transeunte
quanto ao reato, permaneça atual. Ora, a ignorância não desaparece pela penitência; mas ainda
permanece atual, embora removido pela penitência todo o reato. Logo, a ignorância não é pecado, a
não ser talvez o original.

5. ― Demais. ― Se a ignorância, em si mesma, fosse pecado, este permaneceria atual enquanto aquela
perdurasse. Ora, ela perdura sempre no ignorante. Logo, este estaria sempre pecando, o que é de toda
evidência falso; pois, do contrário, a ignorância seria pecado gravíssimo. Portanto, não é pecado.
Mas, em contrário. ― Nada merece pena, a não ser o pecado. Ora, a ignorância a merece, segundo
aquilo da Escritura (I Cor 14, 38): mas se alguém o quer ignorar, será ignorado. Logo, a ignorância é
pecado.

SOLUÇÃO. ― A ignorância difere da nesciência em que esta significa a simples negação da ciência; por
isso, de quem não possui a ciência de alguma coisa podemos dizer que a não sabe. E deste modo,
Dionísio atribui aos anjos a nesciência. A ignorância, porém, implica a privação da ciência, quando nos
falta a ciência, do que entretanto naturalmente deveríamos saber. Ora, há certas coisas que somos
obrigados a saber e sem a ciência das quais não podemos proceder com retidão. Por onde, todos
comumente são obrigados a saber as coisas da fé e os preceitos universais do direito; e cada um em
particular o que lhe respeita ao estado ou ao dever. Há porém certas outras, que embora possamos
naturalmente sabê-las, não estamos entretanto obrigados a tal; assim os teoremas de geometria e os
contingentes particulares, salvo em determinados casos.
Ora, como é claro, todo aquele que omite o ter ou fazer o a que está obrigado peca por pecado de
omissão. Donde, o ser pecado de negligência a ignorância do que estamos obrigados a fazer. Mas a
ninguém, se lhe imputa como negligência o que não souber ou não puder saber. E por isso a esta
ignorância se chama invencível, por não poder ser superada pelo esforço. Por onde, não sendo
voluntária, por não estar em nosso poder o arredá-la, não é pecado. Portanto, é claro que nenhuma
ignorância invencível é pecado; a ignorância vencível, pelo contrário, o é, se for do que estamos
obrigados a saber; não o é, porém, se for do que não estamos obrigados a saber.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como já disse (q. 71, a. 6, ad 1), as expressões ― o dito,
feito ou desejado ―compreendem também as negações opostas, em virtude do que a omissão implica
essencialmente o pecado. E assim, a negligência, que torna pecado a ignorância, está contida na referida
definição do pecado, quando omitimos o que devíamos dizer, fazer ou desejar para adquirir a ciência
devida.

RESPOSTA À SEGUNDA. ― A privação da graça embora não seja pecado, em si mesma, contudo pode vir
a sê-lo em razão da negligência em nos prepararmos para ela como também se dá com a ignorância. Há
entretanto aqui uma dessemelhança, porque, pelos nossos atos, podemos adquirir a ciência; ao passo
que, não por eles, mas só por dom de Deus podemos adquirir a graça.

RESPOSTA À TERCEIRA. ― Assim como o pecado de transgressão não consiste no só ato de vontade,
mas também no ato querido, imperado pela vontade; assim também, no pecado de omissão, não só o
ato da vontade é pecado mas também a omissão mesma enquanto de certo modo voluntária. E deste
modo, a negligência mesma da ciência ou a inconsideração é pecado.

RESPOSTA À QUARTA. ― Delido o reato, pela penitência, permanece a ignorância, enquanto privação
da ciência, não permanece porém a negligência, que leva a considerar a ignorância como pecado.

RESPOSTA À QUINTA. ― Como nos demais pecados por omissão, o nosso ato pecaminoso só o é ao
tempo em que o preceito afirmativo obriga, assim, também no pecado de ignorância. Por isso o
ignorante não está sempre em ato de pecar, mas só ao tempo de adquirir a ciência que está obrigado a
ter.

## Art. 3 — Se a ignorância escusa totalmente do pecado.
(Supra, q. 19, a. 6 ; IIª:IIªª, q. 59 a.4, ad 1 ; III, q. 47, a. 5, ad 3 ; Sent., dist. XXII, q. 2, a. 2; dist. XLI, q. 2, a.
1, ad 3; IV dist. IX, a. 3, 1ª 2; De Malo, q. 3, a. 8; Quodl. VIII, q. 6, a. 5 ; Ad Rom., cap. I, lect. VII ; Ad Tim.,
cap. 1, lect. III ; De Div. Nom., cap. IV, lect.XXII ; V Ethic., lect. XIII).
O terceiro discute-se assim. ― Parece que a ignorância escusa totalmente do pecado.

1. ― Pois, como diz Agostinho, todo pecado é voluntário. Ora, a ignorância causa o involuntário,
conforme já se estabeleceu (q. 6, a. 8). Logo, a excusa totalmente do pecado.

2. ― Demais. ― O que fazemos sem intenção acidentalmente o fazemos. Ora, não podemos ter
intenção do desconhecido. Logo, o que fazemos por ignorância é, na ordem dos nossos atos, acidental.
Mas, o acidental não especifica. Logo, nada do feito por ignorância deve ser considerado, na ordem dos
atos humanos, pecado ou virtude.

3. ― Demais. ― O homem é sujeito da virtude e do pecado, enquanto participa da razão. Ora, a
ignorância exclui a ciência, que aperfeiçoa a razão. Logo, excusa totalmente o pecado.
Mas, em contrário, diz Agostinho que certos atos praticados por ignorância são justamente reprovados.
Ora, justamente só se reprovam os pecados. Logo, certos atos praticados por ignorância são tais, e
portanto a ignorância não escusa totalmente do pecado.

SOLUÇÃO. ― A ignorância, em si mesma, pode tornar involuntário o ato que causa. Pois, como já se
estabeleceu (a. 1), dissemos que ela causa o ato que proíbe à ciência oposta. Assim que tal ato fosse
acompanhado de ciência, seria contrário à vontade, sendo por isso que se lhe aplica a denominação de
involuntário. Se porém a ciência, excluída pela ignorância, não proíbe o ato, por causa da inclinação da
vontade para ele, a ignorância dessa ciência não causa em nós o involuntário, mas nos faz não querê-lo,
como diz Aristóteles. E tal ignorância, não sendo causa do ato pecaminoso, como já dissemos (a. 1), e
não causando o involuntário, não excusa do pecado. E o mesmo se dá com qualquer ignorância não
causadora do ato pecaminoso, mas conseqüente ou concomitante a ele. A ignorância, porém, causa do
ato por o ser do involuntário, pode em si mesma excusar do pecado, porque o voluntário é da essência
deste.
Mas, de dois modos pode ela, às vezes, não excusar totalmente do pecado. ― Primeiro, por parte da
coisa mesma ignorada. Pois, a ignorância excusa do pecado na medida em que ignoramos ser um ato
pecaminoso. Pode porém, acontecer ignoremos alguma circunstância do pecado, que, se fosse
conhecida, nos afastaria dele, quer essa circunstância seja da essência do pecado, quer não. E contudo,
ainda essa ciência conserva algum elemento pelo qual poderíamos saber que é pecado o ato em
questão. Assim, quem ferir a outrem, que saiba ser um homem, faz o bastante para haver
essencialmente pecado, embora não saiba seja o ferido o próprio pai, circunstância constituinte de nova
espécie de pecado. Ou talvez não sabia que o atacado, defendendo-se, lhe revidasse o golpe, o que, se o
soubesse, não o atacaria; mas isso não se inclui na noção do pecado. Por onde, embora esse tal peque
por ignorância, não fica contudo totalmente excusado do pecado, por ainda lhe restar o conhecimento
deste último. ― De outro modo, pode a ignorância, em si mesma, não excusar do pecado, quando
voluntária. E isto diretamente, se, de propósito, queremos nos manter na ignorância para pecarmos
mais livremente; ou indiretamente, como quando, em virtude do trabalho de outras ocupações, somos
negligentes em aprender o que nos levaria a evitar o pecado. Pois tal negligência torna a própria
ignorância voluntária e pecaminosa, contanto que recaia sobre o que deveríamos e podíamos saber. E
portanto, essa ignorância não excusa totalmente do pecado. Se ela porém for que seja absolutamente
involuntária, ou por invencível, ou por incidir sobre o que não estávamos obrigados a saber, então
escusa completamente do pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Nem toda ignorância causa o involuntário, como já
dissemos (q. 6, a. 8). Logo, nem toda excusa totalmente do pecado.

RESPOSTA À SEGUNDA. ― Na medida em que o ignorante tem algo de voluntário, nessa mesma
intenciona o pecado. E deste modo o pecado não será acidental.

RESPOSTA À TERCEIRA. ― Se a ignorância for tal que exclua totalmente o uso da razão, também excusa
totalmente do pecado, como é o caso dos loucos e dementes. Mas nem sempre é tal a ignorância, causa
do pecado. E portanto, nem sempre excusa totalmente dele.

## Art. 4 — Se a ignorância diminui o pecado.
(Supra, q. 73, a. 6 ; IIª-IªIª, q. 59, a. 4, ad 1 ; II Sent., dist. XXII, q. 2, a. 2; De Malo, q. 3, a. 8 ; De Div.
Nom., cap. IV, lect. XXII ; V Ethic., lect. XIII).
O quarto discute-se assim. ― Parece que a ignorância não diminui o pecado.

1. ― Pois, o comum a todo pecado não o diminui. Ora, a ignorância é comum a todo pecado, porquanto,
como diz o Filósofo, todo mau é ignorante. Logo, a ignorância não diminui o pecado.

2. Demais. ― Um pecado acrescentado a outro torna-o maior. Ora, a ignorância em si mesma já é
pecado, como já se disse (a. 2). Logo, não diminui o pecado.

3. Demais. ― O que agrava o pecado não pode também diminuí-lo. Ora, a ignorância o agrava; pois,
sobre aquilo do Apóstolo (Rm 2, 4)― Ignoras que a benignidade de Deus te convida à penitência ―diz
Ambrósio:Pecas gravíssimamente se ignoras. Logo a ignorância não diminui o pecado.

4. Demais. ― Se alguma ignorância diminui o pecado, essa há-de ser principalmente a que priva
totalmente do uso da razão. Ora, essa não o diminui, mas ao contrário, o aumenta; pois, como diz o
Filósofo, o ébrio merece duplos castigos. Logo, a ignorância não diminui o pecado.
Mas, em contrário. ―Toda causa de remissão do pecado o atenua. Ora, tal é a ignorância, conforme
aquilo da Escritura (1 Tm 1, 13): alcancei a misericórdia, porque o fiz por ignorância. Logo, a ignorância
diminui ou atenua o pecado.

SOLUÇÃO. ― Sendo todo pecado voluntário, a ignorância pode diminuir o pecado, na medida em que
diminuir o voluntário; se porém não diminuir a este, de nenhum modo diminuirá aquele. Ora, como é
manifesto, a ignorância, que excusa totalmente do pecado, por privar totalmente do voluntário, não
diminui o pecado, mas de modo absoluto o aumenta. A ignorância porém, que não causa o pecado, mas
existe concomitantemente com ele, nem o diminui nem o aumenta. Logo, só pode diminuir o pecado a
ignorância que o causa; e contudo, ela não o excusa totalmente.
Pois, às vezes se dá que essa ignorância é voluntária, diretamente e em si mesma; como quando de
propósito ignoramos para pecarmos mais livremente. E tal ignorância aumenta o voluntário e o pecado;
pois, da intensidade da vontade no pecar provém o querermos sofrer o dano da ignorância com o fito na
liberdade de pecar. Outras vezes, porém, a ignorância, causa do pecado, não é diretamente voluntária,
mas indireta ou acidentalmente. Assim, como quando não queremos o labor do estudo, donde resulta o
sermos ignorante; ou como quando queremos beber vinho imoderadamente, donde o ficarmos ébrios e
privados do juízo. E tal ignorância diminui o voluntário, e por conseqüência o pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A ignorância, que torna todo homem mau ignorante,
não é causa do pecado, mas algo de conseqüente a ela, i. é, à paixão ou ao hábito que inclina ao pecado.

RESPOSTA À SEGUNDA. ― Um pecado adicionado a outro produz vários pecados, mas nem sempre
torna o pecado maior pois talvez ambos não constituam um só pecado, senão vários. E pode acontecer,
se o diminuir o segundo, que ambos juntos não tenham tão grande gravidade, como a teria um só.
Assim, o homicídio é pecado mais grave cometido por um homem sóbrio do que por um homem ébrio,
embora haja neste último caso dois pecados; porque a embriaguez diminui o pecado conseqüente, na
sua essência, mais do que lhe constitui a gravidade.

RESPOSTA À TERCEIRA. ― O lugar de Ambrósio pode ser entendido da ignorância simplesmente
afetada. Ou pode ser compreendido no gênero do pecado de ingratidão, cujo grau sumo está em o
homem não reconhecer mesmo os benefícios. Ou pode ser referido à ignorância de infidelidade, que
subverte o fundamento do edifício espiritual.

RESPOSTA À QUARTA. ― O ébrio merece por certo duplo castigo, por causa de dois pecados que
comete, a saber: a embriaguez e outro pecado que se lhe segue. Contudo, a embriaguez, em razão da
ignorância adjunta, diminui o pecado conseqüente, e talvez mais do que a gravidade dela própria, como
dissemos. ― Ou se pode dizer que o lugar aduzido se funda na ordenação de um certo Pítaco, legislador,
que estatuía: se os ébrios ferirem alguém, devem ser punidos mais amplamente, levando-se em conta,
não a vênia de que sobretudo são credores, mas a utilidade; porque os ébrios ofendem mais
freqüentemente que os sóbrios, como está claro no Filósofo.