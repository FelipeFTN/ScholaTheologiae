# Questão 13: Da eleição.
Em seguida devemos tratar dos atos da vontade concernentes aos meios. São três: eleger, consentir e
usar. Ora, como à eleição precede o conselho, devemos tratar, primeiro, da eleição; segundo, do
conselho; terceiro, do consentimento; quarto do uso.
Sobre a eleição, seis artigos se discutem:

## Art. 1 — Se a eleição é ato da vontade ou da razão.
(I, q. 83, ª 3; II Sent., dist. XXIV, q. 1, a . 2; De Verit., q. 22, a . 15; III Ethic., lect. VI, IX; VI, lect. II).
O primeiro discute-se assim. ― Parece que a eleição não é ato da vontade, mas da razão.

1. ― Pois, a eleição importa numa certa comparação, pela qual se refere uma coisa a outra. Ora,
comparar é próprio da razão. Logo, também a esta pertence a eleição.

2. Demais. ― A mesma faculdade é a que raciocina e conclui. Ora, raciocinar, na ordem dos atos é
próprio da razão. E como a eleição é uma como conclusão, na ordem dos atos, como diz Aristóteles,
parece que ela é um ato da razão.

3. Demais. ― A ignorância não é própria da vontade, mas, da virtude cognitiva. Ora, há uma
certa ignorância da eleição, como diz Aristóteles. Logo, a eleição não pertence à vontade mas, à razão.
Mas, em contrário, diz o Filósofo, que a eleição é o desejo das coisas que estão em nosso poder.
Ora, o desejo é ato da vontade. Logo, também a eleição.

SOLUÇÃO. ― A palavra eleição inclui algo pertencente à razão ou intelecto e algo pertencente à
vontade. Pois, como diz o Filósofo, a eleição é o intelecto apetitivo, ou o apetite intelectivo. Ora, sempre
que dois elementos concorrem para constituir uma só realidade, um deles é como formal relativamente
ao outro. Por onde, Gregório Nisseno (Nemésio), diz que a eleição nem é o apetite, em si mesma, nem
só conselho, mas algo de composto desses dois elementos. Pois, assim como dizemos que o animal é
composto de corpo e alma, e que nem o corpo existe por si só, nem a alma só, mas ambos; assim
também a eleição.
Devemos porém considerar, em relação aos atos da alma, que o ato essencialmente procedente de uma
potência ou hábito, recebe a forma e a espécie da potência ou hábito superior, segundo a lei que
subordina o inferior ao superior. Assim, se alguém pratica um ato de fortaleza, por amor de Deus, esse
ato materialmente é, certo, de fortaleza; formalmente porém de caridade. Ora, como é manifesto, a
razão precede de certo modo a vontade e lhe ordena o ato; a saber enquanto a vontade tende para o
seu objeto conforme à ordem da razão, pois que a virtude apreensiva apresenta à apetitiva o seu
objeto. Por onde, o ato pelo qual a vontade tende para algo que é proposto como bom, desde que é
ordenado a um fim pela razão, é, certo, um ato de vontade, materialmente; formalmente, porém é ato
de razão. Ora, a substância de tais atos é a matéria, relativamente à ordem imposta pela potência
superior. E portanto, a eleição não é, substancialmente, ato da razão, mas da vontade; pois ela se
completa por um certo movimento da alma para o bem escolhido. Logo, é de manifesto, ato de potência
apetitiva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A eleição importa numa certa comparação precedente;
mas não é essencialmente a comparação mesma.

RESPOSTA À SEGUNDA. ― A conclusão do silogismo, mesmo relativo aos atos, pertence à razão e se
chama sentença ou juízo, a que a eleição se subordina. E por isso, a conclusão, em si, pertence à eleição
como a algo dela resultante.

RESPOSTA À TERCEIRA. ― Diz-se que há ignorância da eleição, não porque a eleição mesma seja
ciência, mas por se ignorar o que se deve escolher.

## Art. 2 — Se a eleição convém aos brutos.
(II Sent., dist. XXV, a . 1, ad 6, 7; V Metaphys, lect. XVI; III Ethic., lect V).
O segundo discute-se assim. ― Parece que a eleição convém aos brutos.

1. ― Pois, como diz Aristóteles, a eleição é o desejo de certas coisas em vista de um fim. Ora, os brutos
desejam certas coisas em vista de um fim, pois agem para algum fim e são movidos pelo apetite. Logo,
nos brutos há eleição.

2. Demais. ― O nome mesmo de eleição parece significar que uma coisa é tomada de preferência a
outras. Ora, os brutos tomam uma coisa de preferência a outras, como quando a ovelha come uma erva
e rejeita outra. Logo há eleição nos brutos.

3. Demais. ― Como diz Aristóteles, é pela prudência que escolhemos os meios. Ora, a prudência convém
aos brutos, dizendo-se, por isso, que têm prudência, sem formação, todos aqueles que como as abelhas
não podem ouvir os sons. E isto também é manifesto aos sentidos. Pois, manifestam-se admiráveis
sagacidades nas operações de animais, como as abelhas, as aranhas e os cães. Assim, quando o cão,
perseguindo um veado, chega a uma encruzilhada, explora, pelo faro, se o veado passou pelo primeiro
caminho ou pelo segundo; assegurado de que não passou por eles, atira-se sem hesitar e sem explorar,
pelo terceiro caminho. Ele como que emprega um silogismo disjuntivo, pelo qual poderia concluir que o
veado passou por esse caminho desde que não passou pelos dois outros únicos. Logo, parece que a
eleição convém aos brutos.
Mas, em contrário, diz Gregório Nisseno (Nemésio) as crianças e os irracionais agem certo,
voluntariamente, não, porém, escolhendo. Logo, nos brutos não há eleição.

SOLUÇÃO. ― Sendo a eleição a preferência de uma coisa a outra, necessário é seja relativa a várias
coisas elegíveis. E, portanto, em seres determinados unilateralmente, não pode haver eleição. Há,
porém, diferença entre o apetite sensitivo e a vontade. Pois, como do sobredito resulta, o apetite
sensitivo é determinado a um bem particular, conforme a ordem da natureza; ao passo que a vontade é,
certo, segundo essa mesma ordem, determinada a algo de comum, que é o bem, mas se comporta
indeterminadamente em relação aos bens particulares. Por onde, propriamente, à vontade pertence
escolher, não porém ao apetite sensitivo, único existente nos brutos; e, por isso, não lhes convém a
eleição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nem todo desejo de um meio em vista de um fim se
chama eleição, mas o que é acompanhado de um certo discernimento de um meio, do outro; ora tal não
pode ter lugar senão quando o desejo pode recair sobre vários objetos.

RESPOSTA À SEGUNDA. ― O animal prefere uma coisa a outra porque o seu apetite está naturalmente
determinado a ela. Por isso, quando pelo sentido ou pela imaginação lhe é apresentado algo a que
naturalmente se lhe inclina o apetite, imediatamente e sem eleição é movido para ela; assim como
também, sem eleição, o fogo se move para cima e não para baixo.

RESPOSTA À TERCEIRA. ― Como diz Aristóteles, o movimento é o ato do móvel procedente do motor. E
por isso, a virtude deste aparece no movimento daquele. Por onde, em todos os seres movidos pela
razão, manifesta-se a ordem da razão motora, embora os seres por ela movidos não a possuam. Assim,
a seta tende diretamente ao alvo pelo movimento do arqueiro, como se ela mesma tivesse a razão
dirigente. E o mesmo se vê nos movimentos dos relógios e de todos os engenhos humanos feitos pela
arte. Ora, as coisas artificiais estão para a arte humana como todas as naturais, para a arte divina. E por
isso, a arte se manifesta tanto nos seres movidos pela natureza como nos movidos pela razão, como diz
o Filósofo. Donde resulta que, nas suas operações os brutos manifestam certas sagacidades, por serem
dotados de uma inclinação natural para determinados modos de proceder ordenadíssimos e como
dispostos por uma arte suma. Donde vem que certos animais são denominados prudentes ou sagazes,
não porém que neles exista alguma razão ou eleição. E isso resulta de que todos os seres dotados da
mesma natureza operam semelhantemente.

## Art. 3 — Se a eleição só existe em relação aos meios.
(I Sent., dist., XLI, a . 1, II, dist. XXV, a . 3, ad 2; De Verit., q. 24, a . 1, ad 20; III Ethic., lect. V).
O terceiro discute-se assim. ― Parece que a eleição não existe só em relação aos meios.

1. ― Pois, como diz o Filósofo, a virtude torna a eleição reta; entretanto, tudo o que naturalmente se faz
em visa dela não lhe pertence, mas a outra potência. Ora, o fim é a causa dela qual fazemos alguma
coisa. Logo, a eleição recai sobre o fim.

2. Demais. ― Eleição importa em preferência de uma coisa a outra. Ora, assim como relativamente aos
meios, um poder ser preferido a outro, assim também relativamente aos diversos fins. Logo, a eleição
pode recair tanto sobre o fim como sobre os meios.
Mas, em contrário, diz o Filósofo, que a vontade visa o fim e a eleição, os meios.

SOLUÇÃO. ― Como já se disse, a eleição resulta da sentença ou juízo, que é quase a conclusão de um
silogismo operativo. Por onde, inclui-se na eleição aquilo que faz o papel de conclusão no silogismo
prático. Ora, nas ações o fim se comporta como princípio e não como conclusão, segundo diz o Filósofo.
Logo, o fim como tal não é objeto da eleição.
Mas, como na ordem especulativa, nada impede que o princípio de uma demonstração ou ciência seja a
conclusão de outra demonstração ou de outra ciência, se bem o princípio primeiro indemonstrável não
possa ser conclusão de nenhuma demonstração ou ciência, também o fim de uma operação pode se
ordenar a outra como meio, e então se compreende na eleição. Assim, na ação do médico a saúde é o
fim, e por isso não entra na eleição dele, que a supõe como princípio. Mas, a saúde do corpo se ordena
ao bem da alma, e, por isso pode ser objeto da eleição, do que cuida da saúde da alma, o ser são ou
enfermo; pois, o Apóstolo diz: Porque quando estou enfermo, então estou forte. O fim último porém de
nenhum modo pode ser objeto da eleição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os fins próprios das virtudes ordenam-se à beatitude
como ao seu último fim. E deste modo podem ser objeto de eleição.

RESPOSTA À SEGUNDA. ― Como já se estabeleceu antes, o último fim é único. Por onde, quando
ocorrem vários fins, pode haver eleição dentre eles, enquanto se ordenam a um fim ulterior.

## Art. 4 — Se a eleição só existe em relação aos atos humanos.
O quarto discute-se assim. ― Parece que a eleição não existe só em relação aos atos humanos.

1. ― Pois, a eleição tem por objeto os meios. Ora, estes não somente são atos, mas também órgãos,
como diz o Filósofo. Logo, as eleições não recaem só sobre os atos humanos.

2. Demais. ― A ação se distingue da contemplação. Ora, mesmo nesta tem lugar a eleição, p. ex.,
quando se prefere uma opinião a outra. Logo, a eleição existe não só em relação aos atos humanos.

3. Demais. ― Há homens eleitos para certos ofícios seculares ou eclesiásticos, por outros que nenhuma
ação tem sobre eles. Logo, a eleição não existe só em relação aos atos humanos.
Mas, em contrário, diz o Filósofo: ninguém escolhe senão o que julga poder fazer por si mesmo.

SOLUÇÃO. ― Como o objeto da intenção é o fim, são os meios o da eleição. Ora, o fim é uma ação ou
uma realidade qualquer. E quando esta for o fim, necessário é que intervenha alguma ação humana;
quer porque o homem faz essa realidade, que é o fim, como quando o médico produz a saúde, que é o
seu fim e, por isso, se diz que produzir a saúde é o fim do médico; quer porque o homem, de algum
modo, goza ou frui da realidade, que é o fim, sendo assim o dinheiro ou a sua posse o fim do avarento. E
o mesmo se deve dizer do meio. Pois necessário é que este seja uma ação ou alguma realidade em que
intervém alguma ação, pela qual o homem produz o meio ou dele usa. E deste modo, a eleição sempre
diz respeito aos atos humanos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os órgãos se ordenam ao fim na medida em que o
homem usa deles em vista do fim.

RESPOSTA À SEGUNDA. ― Na própria contemplação há algum ato do intelecto, que assente a uma ou
outra opinião. Ao passo que a ação exterior é a que se opõe à contemplação.

RESPOSTA À TERCEIRA. ― Quem elege o bispo ou um chefe do estado escolhe nomeá-lo para tal
dignidade. Do contrário, se nenhum ato seu houvesse para constituir o bispo ou o chefe, não lhe
competiria a eleição. E semelhantemente, devemos dizer que sempre uma coisa preferida a outra
implica alguma operação de quem a escolhe.

## Art. 5 — Se há eleição só do possível.
(III Ethic., lect. V).
O quinto discute-se assim. ― Parece que a eleição não é só do possível.

1. ― Pois, a eleição é ato da vontade, como já se disse. Ora, há vontade do impossível como diz
Aristóteles. Logo, também eleição.

2. Demais. ― A eleição recai sobre o feito por nós, como se disse. Nada pois importa, quanto à eleição,
que seja escolhido o impossível absoluto ou o impossível para quem escolhe. Ora, como
freqüentemente não podemos realizar o que escolhemos, isso nos é impossível. Logo, há eleição de
impossíveis.

3. Demais. ― O homem não tenta fazer nada senão escolhendo. Ora, S. Bento diz que se um prelado
mandar algo de impossível, é preciso tentar fazê-lo. Logo, pode haver eleição de impossíveis.
Mas, em contrário, diz o Filósofo: não há eleição de impossíveis.

SOLUÇÃO. ― Como já se disse, as nossas eleições referem-se sempre às nossas ações. Ora, o que
fazemos nos é possível. Logo, necessário é dizer-se que a eleição não recai senão sobre os possíveis.
Semelhantemente, a razão de se escolher um meio é ele nos conduzir ao fim. Ora pelo impossível
ninguém pode conseguir um fim. E a prova está em que quando, deliberando, os homens chegam ao
que lhes é impossível, recuam, quase não querendo passar além.
E isto também resulta claramente do modo de proceder da razão precedente à escolha. Pois, o meio
que a eleição visa está para o fim como a conclusão para o princípio. Ora, é manifesto que uma
conclusão impossível não resulta de um princípio possível. Por onde, não pode ser possível o fim sem
que o meio também o seja. E ao impossível ninguém é movido. Logo, ninguém tenderia para o fim se
não visse que o meio é possível. E portanto, o impossível não constitui objeto de eleição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vontade é média entre o intelecto e a operação
exterior; pois o intelecto propõe à vontade o seu objeto e esta é a que causa a ação exterior. Assim,
portanto, o princípio do movimento da vontade é considerada em relação ao intelecto que apreende
algo como bem universal; ao passo que o termo ou perfeição do ato da vontade é considerado
relativamente à ordem da operação pela qual tendemos à consecução da coisa; pois o movimento da
vontade procede da alma para as coisas. E portanto, a perfeição do ato da vontade está em que há para
alguém algum bem a ser realizado. Ora, isto é possível, e portanto só é completa a vontade do possível,
que é o bem para quem o quer. Incompleta é porém a vontade do impossível chamada por alguns
veleidades, porque o quereríamos se fosse possível. Ora, a eleição designa um ato da vontade já
determinado aquilo que alguém deve fazer; logo, de qualquer modo, só recai sobre os possíveis.

RESPOSTA À SEGUNDA. ― Sendo o objeto da vontade o bem apreendido, devemos julgar desse objeto
na medida em que se compreende na apreensão. E portanto, assim como às vezes há vontade de algo
apreendido como bem, e que contudo não o é verdadeiramente, assim também às vezes há eleição do
que é apreendido como possível para o que escolhe, e que contudo não lhe é possível.

RESPOSTA À TERCEIRA. ― Tal diz S. Bento porque o súbdito não deve determinar a seu juízo o que é
possível, mas sempre seguir juízo do superior.

## Art. 6 — Se o homem elege necessariamente.
(I, q. 83, a . 1; II Sent., dist XXV, a . 2; De Verit., q.22, a . 6; q.24. a. 1; De Malo, q. 6; I Perih., lect. XIV).
O sexto discute-se assim. ― Parece que o homem escolhe necessariamente.

1. ― Pois, o fim está para o elegível, como os princípios para as suas conseqüências, segundo é patente
em Aristóteles. Ora, dos princípios deduzem-se necessariamente as conclusões. Logo, pelo fim somos
necessariamente levados a agir.

2. Demais. ― Como já se disse, a eleição segue-se ao juízo da razão relativo ao que se deve fazer. Ora, a
razão julga necessariamente de certas coisas, por serem necessárias as premissas. Logo, pelo fim somos
necessariamente movidos a agir.

3. Demais. ― Entre dois bens absolutamente iguais o homem não é movido a um de preferência ao
outro; assim, o faminto à vista de alimentos igualmente apetitíveis, em diversas partes e em distâncias
iguais, não se move a um de preferência a outro, como diz Platão, expondo a razão do repouso da terra
no meio, segundo o refere Aristóteles. E com maioria de razão, não é escolhido o que é considerado
menos de preferência ao que é considerado igual. Logo, proposto dois ou mais bens, entre os quais um
aparece como maior, é impossível escolher qualquer dos outros. Logo, é escolhido necessariamente o
que aparece como melhor. Ora, toda eleição recai sobre o que de certo modo consideramos melhor.
Portanto, toda eleição é necessária.
Mas, em contrário, a eleição é um ato da potência racional que se exerce sobre os contrários, segundo o
Filósofo.

SOLUÇÃO. ― O homem não escolhe necessariamente, e isto porque o que pode não existir não existe
necessariamente. E que é possível escolher ou não escolher pode-se provar pela dupla faculdade do
homem: querer ou não, agir ou não; pode também querer tal coisa ou tal outra, fazer isto ou aquilo. E o
fundamento disso se deduz da própria virtude da razão. Pois, a vontade pode tender para tudo o que a
razão apreende como bem. Ora, a razão pode apreender como bem não só o querer ou agir, mas
também, o não querer e não agir. E além disso, em relação a todos os bens particulares, pode
considerar o porque de um bem e o defeito de outro, que o torna mal; e deste modo, pode apreender
cada um desses bens com elegível ou desprezível. Só o bem perfeito, que é a beatitude, a razão não
pode apreendê-lo sob o aspecto de mal ou como tendo qualquer defeito. E por isso, o homem quer a
beatitude necessariamente e não pode querer não ser feliz ou ser miserável. Ora, como a eleição não
tem por objeto o fim mas, os meios, segundo já se disse, não visa o bem perfeito, que é a beatitude, mas
os bens particulares. E portanto, o homem escolhe, não necessária, mas livremente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nem sempre a conclusão procede necessariamente dos
princípios; mas só quando eles não podem ser verdadeiros, se ela não o é. E semelhantemente, não é
necessário que sempre do fim, resulte para o homem a necessidade de escolher os meios; porque nem
todo meio é tal que, sem ele, o fim não possa ser conseguido; ou, se for tal, nem sempre é considerado
sob esse aspecto.

RESPOSTA À SEGUNDA. ― A sentença ou juízo da razão sobre o que se deve fazer se refere a realidades
contingentes, que podem ser feitas por nós; e nessas, as conclusões não resultam necessariamente de
princípios necessários, com absoluta necessidade, mas deles resultam só condicionalmente, como
quando se diz: se corre, move-se.

RESPOSTA À TERCEIRA. ― Nada impede que duas coisas sejam proposta como equivalentes, sob um
mesmo aspecto, e contudo, em relação a uma, se considere alguma condição que a torna melhor e a
vontade se incline mais para ela que para a outra.