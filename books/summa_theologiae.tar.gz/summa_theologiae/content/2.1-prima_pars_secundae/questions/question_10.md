# Questão 10: Do modo pelo qual a vontade é movida.
Em seguida devemos tratar do modo pelo qual a vontade é movida.
E, sobre esta Questão, quatro artigos se discutem:

## Art. 1 — Se a vontade é movida para alguma coisa, naturalmente.
(I, q. 60 a . 1, 2; III Sent., dist. XXVII, q. 1, a 2; De Verit;. Q. 22, a . 5; De Malo, q. 6; q. 16, a . 4, ad 5).
O primeiro discute-se assim. ― Parece que a vontade não é movida naturalmente para nada.

1. ― Pois, agente natural é uma divisão que se opõe a agente voluntário, como se vê em Aristóteles.
Logo, a vontade para nada é movida naturalmente.

2. Demais. ― O natural a um ser é-lhe sempre inerente; assim, ao fogo, a calidez. Ora, nenhum
movimento é sempre inerente à vontade. Logo, nenhum movimento lhe é natural.

3. Demais. ― Ao passo que a natureza é determinada a um só termo, a vontade se exerce entre termos
opostos. Logo, nada quer naturalmente.
Mas, em contrário, o movimento da vontade segue-se ao ato do intelecto. Ora, este intelige certas
coisas naturalmente. Logo, também a vontade quer naturalmente certas coisas.

SOLUÇÃO. ― Como diz Boécio e Aristóteles, muitas acepções tem a palavra natureza. ― Ora significa o
princípio intrínseco das coisas moveis e então é matéria ou forma material, como se vê em Aristóteles.
Outras vezes significa qualquer substância ou qualquer ente e então diz-se natural a um ser o que lhe
convém substancialmente e lhe é, assim, inerente, por si. E o que não existe, por si, em qualquer ser, se
reduz como ao seu princípio ao desse modo existente. E portanto é forçoso que tomada a natureza
nesta acepção, o princípio, relativamente ao que convém ao ser, sempre seja natural. O que se dá
manifestamente com o intelecto, pois os princípios do conhecimento intelectual são naturalmente
conhecidos.
E também de modo semelhante, é forçoso que o princípio dos movimentos voluntários seja algo de
naturalmente querido. Ora, isto é o bem em comum, para o qual a vontade naturalmente tende, como
qualquer potência tende para o seu objeto; e também o fim último, que está para os apetíveis como os
primeiros princípios das demonstrações, para os inteligíveis; e em geral, tudo o que convém ao ser que
quer, segundo a sua natureza. Pois, com a vontade apetecemos não só o que pertence a tal potência,
mas ainda o que pertence a cada uma das outras potências e ao homem total. Por onde, o homem quer
naturalmente, não só o objeto da vontade, mas também tudo o que convém às outras faculdades.
Assim, o conhecimento da verdade, conveniente ao intelecto; o existir, o viver e coisas semelhantes,
que respeitam à consistência natural; o que tudo se compreende no objeto da vontade, como
determinados bens particulares.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vontade é uma divisão que se opõe à natureza, do
mesmo modo que uma causa se divide de outra, por oposição; pois, certas coisas se fazem natural e
outras, voluntariamente. Há porém outra maneira de causar própria à vontade, senhora dos seus atos,
além do modo próprio à natureza, que é determinada a um termo. Como porém a vontade se funda em
alguma natureza, forçoso é seja de certa maneira participado pela vontade o modo próprio à natureza;
assim, o que é próprio à causa anterior é participado pela posterior. Ora, a existência, que é natural, em
cada ser, é anterior ao querer, que é voluntário; e, por isso a vontade quer certas coisas, naturalmente.

RESPOSTA À SEGUNDA. ― Às coisas naturais é-lhes inerente o que é natural, como resultante só da
forma; assim, a calidez, ao fogo. O que porém é natural como conseqüente à matéria não é sempre
inerente em ato, mas às vezes só em potência. Pois, ao passo que a forma é ato, a matéria é potência.
Ora, o movimento é o ato do que existe em potência, como diz Aristóteles. Portanto, o que nas coisas
naturais pertence ao movimento, não lhes é sempre inerente; assim, o fogo nem sempre se move para
cima, mas às vezes sai fora do seu lugar. E semelhantemente, não é necessário que a vontade, que passa
da potência ao ato, quando quer alguma coisa, queira sempre em ato, mas só quando está em alguma
disposição determinada. Ao passo que a vontade de Deus, ato puro, está sempre em ato de querer.

RESPOSTA À TERCEIRA. ― Sempre corresponde à natureza o que lhe é uno e proporcionado. Assim, à
natureza genérica o que é genericamente uno; à específica, o especificamente uno; à individuada, o
individualmente uno. Ora, sendo a vontade como o intelecto, uma virtude imaterial, corresponde-lhe
naturalmente um objeto comum, o bem, assim como um objeto comum corresponde ao intelecto, que é
a verdade, o ser ou a qüididade. Ora, o bem em comum abrange muitos bens particulares, a nenhum
dos quais a vontade é determinada.

## Art. 2 — Se a vontade é necessariamente movida pelo seu objeto.
(I, q. 82, a . 1, 2; II Sent., dist. XXV, a . 2; De Verit., q. 22, a . 6; De Malo, q. 6; Perih., lect. XIV).
O segundo discute-se assim. ― Parece que a vontade é necessariamente movida pelo seu objeto.

1. ― Pois, o objeto da vontade está para ela como o motivo para o móvel, conforme se vê em
Aristóteles. Ora, o motivo, sendo suficiente, move necessariamente o móvel. Logo, a vontade pode ser
movida necessariamente pelo seu objeto.

2. Demais. ― Como a vontade é uma virtude imaterial, assim também o intelecto; e ambas essas
potências se ordenam a objeto universal, como já se disse. Ora, o intelecto é movido necessariamente
pelo seu objeto. Logo, também a vontade pelo seu.

3. Demais. ― Tudo o que queremos ou é fim ou algo a este ordenado. Ora, o fim, segundo se sabe, é
necessariamente querido, pois é como o princípio, nas ciências especulativas, ao qual assentimos
necessariamente. Mas o fim sendo a razão de querermos os meios, resulta que também estes os
queremos necessariamente. Logo, a vontade é movida necessariamente pelo seu objeto.
Mas, em contrário, as potências racionais, segundo o Filósofo, se movem entre os contrários. Ora, a
vontade é potência racional, pois está na razão, como diz Aristóteles. Logo, move-se entre os contrários
e portanto não é movida necessariamente para nenhum deles.

SOLUÇÃO. ― De duplo modo é a vontade movida: quanto ao exercício do ato e quanto à especificação
dele, procedente do objeto. ― Ora, do primeiro modo a vontade não é movida necessariamente por
nenhum objeto; pois podemos não cogitar de um objeto e por conseqüência não querê-lo atualmente.
Mas quanto ao segundo modo de moção, a vontade é ora necessariamente movida pelo objeto e, ora,
não. Pois no movimento de qualquer potência, pelo seu objeto, deve-se considerar a razão por que este
move aquela. Assim, o visível move a vista sob o aspecto de cor atualmente visível; por onde, proposta à
vista, a cor necessariamente a move, a menos que a desviemos; e isto pertence ao exercício do ato. Se
porém fosse proposta à vista algo de colorido, não atualmente, de todos os modos, mas, de certo modo,
sim, e, de certo, não, a vista não veria tal objeto necessariamente; pois, podendo visá-lo por onde não
atualmente colorido, não o veria. Ora, assim como o atualmente colorido é o objeto da vista, assim o
bem o é da vontade. Por onde, proposto à vontade um objeto, que seja bom universalmente e sob
todos os pontos de vista, a vontade, se quer alguma coisa, há de tender para ele necessariamente, pois
não poderia querer o contrário. Se porém se propuser um objeto que não seja bom, sob os pontos de
vista, a vontade não tende para ele necessariamente.
E como a falta de qualquer bem tem a natureza de não-bom, só o bem perfeito e indiciente é tal que a
vontade não pode deixar de querê-lo; e isso é a beatitude. Ao passo que quaisquer outros bens
particulares, enquanto deficientes, podem ser considerados como não-bens e, como tais, ser repelidos
ou aceitos pela vontade, cujo objeto pode uma mesma coisa, e luzes diversas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Motivo suficiente de uma potência só o é o objeto que
tem, totalmente, a natureza de motivo; se porém de algum modo for deficiente, não moverá de modo
necessário, como já se disse.

RESPOSTA À SEGUNDA. ― O intelecto é movido necessariamente pelo objeto que é sempre e
necessariamente verdadeiro; não porém pelo que sendo contingente ― como já se disse que é o bem ―
pode ser verdadeiro e falso.

RESPOSTA À TERCEIRA. ― O fim último move a vontade necessariamente, porque é o bem perfeito. E
de modo semelhante, tudo o que é ordenado a esse fim, sem o que este não pode ser alcançado, como
existir, viver e meios tais. Tudo porém sem o que o fim pode ser alcançado não é querido
necessariamente por quem quer o fim; assim também, as conclusões, sem as quais os princípios podem
ser verdadeiros, não as admite necessariamente quem admite os princípios.

## Art. 3 — Se a vontade é movida necessariamente pela paixão do apetite inferior.
(Infra. q. 77, a . 7; De Verit., q. 5, a . 10; q. 22, a . 9, ad 3, 6).
O terceiro discute-se assim. ― Parece que a vontade é movida necessariamente pela paixão do
apetite inferior.

1. ― Pois, diz a Escritura (Rm 7, 19): Porque eu não faço o bem, que quero; mas faço o mal, que não
quero; e isso é dito a propósito da concupiscência, que é uma paixão. Logo, a vontade é
necessariamente movida pela paixão.

2. Demais. ― Como diz Aristóteles, cada qual julga do fim conforme suas disposições pessoais. Ora, não
está no poder da vontade submeter imediatamente a paixão. Logo, também nesse poder não está não
querer aquilo para o que a paixão se inclina.

3. Demais. ― A causa universal não atinge o efeito particular senão mediante a causa particular; e por
isso a razão universal não move senão mediante a estimativa particular, como diz Aristóteles. Ora, a
razão universal está para a estimativa particular, como a vontade para o apetite sensitivo. Logo, só
mediante este é que a vontade é movida a querer um objeto particular. E portanto, o apetite sensitivo
estando disposto de certo modo por alguma paixão, a vontade não poderá ser movida em sentido
oposto.
Mas, em contrário, diz a Escritura (Gn 4, 7): A tua concupiscência estar-te-á sujeita, e tu dominarás sobre
ela. Logo, a vontade do homem não é necessariamente movida pelo apetite inferior.

SOLUÇÃO. ― Como já se disse, a paixão do apetite sensitivo move a vontade, por ser esta movida pelo
objeto; i. é, enquanto que um homem, de certo modo disposto pela paixão, julga conveniente e bom o
que, sem a paixão, não julgaria tal. E esta imutação do homem pela paixão de duas maneiras pode dar-
se.
Primeiramente, ficando ele pela paixão de tal modo ligado, que perde o uso da razão; isso sucede com
os loucos e amantes por causa da veemente ira ou concupiscência, ou qualquer outra perturbação
corpórea; pois, tais paixões não sobrevêm sem transmutação corpórea. E elas os fazem agir como os
brutos, que seguem necessariamente o ímpeto da paixão, pois neles não há algum movimento da razão
e, por conseguinte, da vontade.
Outras vezes porém a razão não é pela paixão totalmente absorvida, mas o seu juízo fica em parte livre,
e assim, permanece algo do movimento da vontade. Por onde, na medida em que a razão fica livre e
não sujeita à paixão, nessa mesma medida o movimento da vontade, que permanece, não tende
necessariamente para aquilo a que a paixão inclina.
Assim pois ou não há no homem o movimento da vontade, e só a paixão domina; ou, se esse
movimento existe, a vontade não segue a paixão necessária.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vontade não pode fazer com que não surja o
movimento da concupiscência, dizendo, por isso o Apóstolo (Rm 7, 19): Faço o mal que não quero, isto
é, tenho dele desejo; pode, contudo, não querer ter desejo ou neste não consentir. E portanto, não
segue necessariamente o movimento de concupiscência.

RESPOSTA À SEGUNDA. ― Tendo o homem duas naturezas ― a intelectual e a sensitiva ― ora, a alma
está totalmente num estado uniforme; ou porque a parte sensitiva está toda sujeita à razão, como
acontece com os virtuosos, ou, inversamente, porque a razão é totalmente absorvida pela paixão, como
se dá com os amantes. Mas às vezes, embora obnubilada pela paixão, a razão conserva-se parcialmente
livre, e então podemos repelir totalmente a paixão ou ao menos, comportamo-nos de modo a não
segui-la. E em tal disposição, algo lhe aparece como racional e algo como passional, pois o homem
diversamente se dispõe em relação às diversas partes da alma.

RESPOSTA À TERCEIRA. ― A vontade é movida, não só pelo bem universal apreendido pela razão, mas
também pelo que é apreendido pelo sentido. E portanto, pode ser movida a algum bem particular, sem
a paixão do apetite sensitivo. Pois, queremos e obramos muitas coisas, sem paixão, só pela eleição do
apetite; o que sobretudo se manifesta naqueles em que a razão luta contra a paixão.

## Art. 4 — Se a vontade é necessariamente movida por Deus.
(I, q. 83, a . 1, ad 3; De Verit., q. 24, a . 1, ad 3; De Malo, q. ad 3).
O quarto discute-se assim. ― Parece que a vontade é movida por Deus necessariamente.

1. ― Pois, todo agente a que se não pode resistir move necessariamente. Ora, não se pode resistir a
Deus, cujo poder é infinito, pois por isso diz a Escritura (Rm 9, 19): Quem é o que resiste à sua
vontade? Logo, Deus move a vontade necessariamente.

2. Demais. ― Como já se disse, a vontade é movida necessariamente quanto ao que naturalmente quer.
Ora, diz Agostinho, é natural a cada ser que Deus nele opere. Logo, a vontade quer necessariamente
tudo aquilo a que é movida por Deus.

3. Demais. ― É possível aquilo que, posto, não causa nenhuma impossibilidade. Ora, de admitir-se que a
vontade não quer aquilo a que Deus a move, resulta uma impossibilidade, a saber que a operação de
Deus seria ineficaz.
Mas, em contrário, diz a Escritura (Ecle 15, 14): Deus criou o homem desde o princípio e o deixou na
mão do seu conselho. Logo, não lhe move a vontade necessariamente.

SOLUÇÃO. ― Como diz Dionísio, à providência divina é próprio, não corromper, mas conservar a
natureza das coisas. Por onde, move todas as coisas conforme à condição delas; e, assim, por moção
divina as causas necessárias produzem os seus efeitos necessariamente, e as causas contingentes, os
seus contingentemente. Ora, a vontade é um princípio ativo não determinado a um só termo, mas
comportando-se indiferentemente em relação a muitos. Por onde, Deus a move sem determiná-la
necessariamente a um termo, permanecendo-lhe, antes, o movimento contingente e não necessário,
salvo naquilo ao que é naturalmente movida.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No poder da divina vontade está não somente operar
por meio da coisa que move, mas ainda, fazer tal de modo congruente a essa coisa. E por isso, mais
repugnaria à divina moção ser a vontade movida necessariamente, o que não lhe convém à natureza, do
que livremente, como lhe convém.

RESPOSTA À SEGUNDA. ― É natural a um ser tudo o que Deus nele opera para que seja o que é; assim,
a cada ser convém o que Deus quer lhe convenha. Ora, ele não quer que tudo o operado nas coisas seja
natural ― p. ex., que os mortos ressurjam ― mas sim, que cada ser natural esteja submetido ao poder
divino.

RESPOSTA À TERCEIRA. ― Se Deus move a vontade para alguma coisa, é impossível mas não
absolutamente, que a vontade para esta não seja movida. Donde não se segue que a vontade seja
necessariamente movida por Deus.