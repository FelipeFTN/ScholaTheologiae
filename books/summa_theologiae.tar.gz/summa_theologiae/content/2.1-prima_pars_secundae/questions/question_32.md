# Questão 32: Da causa do prazer.
Em seguida devemos tratar das causas do prazer.
E sobre esta questão oito artigos se discutem:

## Art. 1 — Se a atividade é a causa própria e primeira do prazer.
(IV Sent., dist. XLIX, q. 3, a . 2).
O primeiro discute-se assim. ― Parece que a atividade não é a causa própria e primeira do prazer.

1. ― Pois, como diz o Filósofo: deleitar-se consiste em o sentido sofrer, porquanto o prazer supõe o
conhecimento, como ficou dito. Ora, antes de conhecermos as atividades mesmas, conhecemos-lhe os
objetos. Logo, a atividade não é a causa própria do prazer.

2. Demais. ― O prazer consiste principalmente no fim alcançado o qual é principalmente desejado. Ora,
nem sempre a atividade é um fim, mas às vezes este é o objeto da ação. Logo, a atividade não é a causa
própria e por si mesma do prazer.

3. Demais. ― O ócio e o descanso supõem a cessação da atividade. Ora, ambos são agradáveis, como diz
Aristóteles. Logo, a atividade não é a causa própria do prazer.
Mas, em contrário, diz o Filósofo, que o prazer é uma operação conatural, não impedida.

SOLUÇÃO. ― Como já dissemos, duas condições são exigidas para o prazer: a consecução do bem
conveniente e o conhecimento dessa consecução. Ora, aquela e este consistem numa determinada
atividade; pois, o conhecimento atual é uma atividade e semelhantemente por uma certa atividade é
que alcançamos o bem conveniente. E também a atividade própria é um certo bem conveniente. Por
onde é necessário todo prazer dependa de alguma atividade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Os objetos mesmos da atividades não são deleitáveis
senão enquanto que conosco se conjugam, quer pelo só conhecimento, como quando nos deleitamos
na consideração ou visão de certos objetos, quer simultaneamente como o conhecimento, de qualquer
outro modo, como quando nos deleitamos sabendo que possuímos algum bem, p. ex., as riquezas, a
honra ou coisas semelhantes, que por certo não seriam deleitáveis se não fossem conhecidas como
possuídas. Pois, como diz o Filósofo, há grande prazer em considerar uma coisa própria nossa, isso
procede do amor natural que temos por nós mesmos. Ora, possuir tais coisas não é senão usar ou poder
usar delas, o que supõe alguma atividade. Por onde, é manifesto que todo prazer se reduz à atividade
como à sua causa.

RESPOSTA À SEGUNDA. ― Mesmo quando os fins visados são, não as atividades, mas os resultados
delas, estes são deleitáveis enquanto possuídos ou feitos, o que diz respeito a algum uso ou atividade.

RESPOSTA À TERCEIRA. ― As atividades são deleitáveis enquanto proporcionadas e conaturais ao
agente. Ora, como a virtude humana é finita, a atividade lhe é proporcional conforme uma certa
medida. Por onde, excedendo essa medida, já não será proporcional nem deleitável, mas antes,
laboriosa e molesta. E neste sentido, o ócio, o jogo e tudo o que respeita ao repouso é deleitável porque
expunge a tristeza, procedente do que é penoso.

## Art. 2 — Se o movimento é causa do prazer.
(IV Sent., dist. XLIX, q. 3, a . 2, ad 3).
O segundo discute-se assim. ― Parece que o movimento não é causa do prazer.

1. ― Porque, como já dissemos, o bem presentemente obtido é a causa do prazer; e por isso o Filósofo
diz, que o prazer não e comparável à geração, mas à operação de um ser já existente. Ora, o que é
movido para um termo ainda não o alcançou, mas de certo modo está em via de geração, relativamente
a ele, enquanto que todo movimento implica a geração e a corrupção, como diz Aristóteles. Logo, o
movimento não é causa do prazer.

2. Demais. ― O movimento introduz no agir a fadiga e a lassidão. Ora, atividades laboriosas fatigantes
não são deleitáveis mas antes, aflitivas. Logo, o movimento não é causa do prazer.

3. Demais. ― O movimento implica uma certa inovação que se opõe ao hábito. Ora, as coisas habituais
são-nos deleitáveis, como diz o Filósofo. Logo, o movimento não é causa do prazer.
Mas, em contrário, diz Agostinho: Porque isto, Senhor, meu Deus, quando és eternamente para ti
mesmo a tua alegria, e quando várias de tuas criaturas gozam junto de ti sempiternamente? Porque
este vosso mundo se compraz, contínua e alternadamente na deficiência e na abundância, na guerra e
na paz? Donde se conclui que os homens gozam e se deleitam com certas mudanças. E então, o
movimento, parece, é causa do prazer.

SOLUÇÃO. ― Três condições se requerem para o prazer: duas primeiras, cuja união é deleitável; e a
terceira, o conhecimento dessa união. E de acordo com essas três condições o movimento se torna
deleitável, como diz o Filósofo. Pois, quanto a nós, que nos deleitamos, a transmutação se nos torna
deleitável porque a nossa natureza é sujeita a mudanças; por onde, o que agora nos é conveniente já
não no-lo é mais tarde; assim, aquecer-se ao fogo, conveniente ao o homem no inverno, não o é no
verão. ― Também quanto ao bem que deleita, e que se nos une a nós, a transmutação é deleitável.
Porque a atividade continuada de um agente aumenta-lhe o efeito; assim, quanto mais alguém se
aproxima do fogo, mais se aquece e desseca. Ora, a disposição natural implica uma certa medida. Logo,
quando a presença continuada do objeto deleitável sobreexcede a medida dessa disposição natural, se
torna desejável o seu afastamento. ― E por fim, em relação ao conhecimento, também deleitável nos é
a mudança. Pois, de um lado, o homem deseja conhecer, total e perfeitamente, tudo o que conhece;
mas como, de outro, não pode apreender total e simultaneamente certos objetos, deleitar-se com a
transmutação, de modo que, a uma parte sucede outra e, assim, seja sentido o todo. Donde o dito de
Agostinho: Não queres por certo que as sílabas se detenham, mas que se evolem e dêem lugar a outras,
de modo que ouças toda a palavra. O mesmo se dá com todas as coisas que formam um todo, mas que
não existem simultaneamente: o todo, se pudesse ser apreendido simultaneamente, deleitaria mais que
cada uma das partes.
Se portanto um objeto deleitável, intransmutável por natureza, não puder ser excessivo, pela sua
continuada presença, em relação à disposição natural do homem; e se demais disso, puder ser
apreendido total e simultaneamente, a sua mudança não será agradável. E quanto mais os prazeres se
aproximarem deste tipo, tanto mais poderão ter uma presença continuada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Embora o que é movido ainda não tenha chegado
perfeitamente ao termo, já começa contudo de ter algo desse termo. E neste sentido, o movimento, em
si mesmo, já participa algo do prazer, embora não encerre o prazer perfeito, pois os prazeres mais
perfeitos são os que tem por objeto objetos imóveis. ― E também o movimento torna-se deleitável
enquanto que por ele se torna conveniente o que antes não o era, ou deixa de o ser, como já se disse.

RESPOSTA À SEGUNDA. ― O movimento causa fadiga e lassidão, quando ultrapassa a nossa disposição
natural. Ora, não é nesse sentido que o movimento é deleitável, mas enquanto remove o que encontre
essa disposição natural.

RESPOSTA À TERCEIRA. ― O habitual é deleitável quando se torna natural, pois o hábito é uma quase
segunda natureza. Ora, o movimento é deleitável, não por certo enquanto se afasta do habitual, mas
antes, enquanto impede a corrupção da disposição natural, que poderia provir de uma atividade
continuada. De modo que pela mesma causa de conaturalidade se tornam deleitáveis o hábito e o
movimento.

## Art. 3 — Se a memória e a esperança são causas do prazer.
(III Sent., dist. XXVI, q. 1, a . 1, ad. 3; XI Metaph., lect. VIII).
O terceiro discute-se assim. ― Parece que a memória e a esperança não são causas do prazer.

1. ― Pois, o prazer se refere ao bem presente, como diz Damasceno. Ora, a memória e a esperança se
referem ao bem ausente; aquela ao passado, esta, ao futuro. Logo, a memória e a esperança não são
causas do prazer.

2. Demais. ― Os contrários não podem ter a mesma causa. Ora, a esperança é causa da aflição,
conforme a Escritura (Pr 13, 12): A esperança que se retarda aflige a alma. Logo, a esperança não é
causa do prazer.

3. Demais. ― Tanto a esperança como a concupiscência e o amor convêm com o prazer, relativamente
ao bem. Logo, não se deve dizer que, mais que a concupiscência e o amor, a esperança é causa do
prazer.
Mas, em contrário, diz a Escritura (Rm 12, 12): Na esperança alegres; e (Sl 76, 4): Lembrei-me de Deus e
me deleitei.

SOLUÇÃO. ― O prazer é causado pela presença do bem conveniente, quando sentido ou percebido de
qualquer maneira. Ora, uma coisa pode nos estar presente de dois modos: pelo conhecimento, estando
o objeto conhecido por uma semelhança no sujeito que conhece; ou realmente, como quando uma
coisa se une a outra real e atualmente, ou em potência, por um modo qualquer de união. E sendo a
união real mais íntima que a do conhecimento, que implica uma semelhança, bem como a união real
atual mais que a potencial, máximo é o prazer dos sentidos, que requer a presença da coisa sensível. Em
segundo lugar vem o prazer da esperança, no qual se dá a união deleitável, não só pela apreensão, mas
também pela faculdade ou possibilidade de alcançar o bem que deleita. Em terceiro lugar, por fim, está
o prazer da memória, que implica só a união de apreensão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A esperança e a memória se referem, certo, a objetos
absolutamente ausentes, mas que, a certa luz, são presentes, quer só pela apreensão, quer pela
apreensão e pela faculdade, pelo menos presumida.

RESPOSTA À SEGUNDA. ― Nada impede os contrários tenham a mesma causa considerada em pontos
de vista diversos. Por onde, a esperança, enquanto inclui a apreciação presente de um bem futuro,
causa o prazer; enquanto porém privada da presença do mesmo, causa a aflição.

RESPOSTA À TERCEIRA. ― O amor e a concupiscência causam o prazer. Pois todo amado é deleitável ao
amante, por ser o amor uma certa união ou conaturalidade entre o amante e o amado.
Semelhantemente, todo objeto desejado é deleitável para quem o deseja, pois a concupiscência é
principalmente o apetite do prazer. A esperança porém implicando uma determinada certeza da
presença real do bem que deleita, ao contrário do amor e da concupiscência, é mais que esta e aquela
causa do prazer, e semelhantemente, mais que a memória, atinente ao passado.

## Art. 4 — Se a tristeza é causa do prazer.
O quarto discute-se assim. ― Parece que a tristeza não é causa do prazer.

1. ― Pois, um contrário não é causa de outro. Ora, a tristeza contraria o prazer. Logo, não é causa deste.

2. Demais. ― Os efeitos dos contrários são contrários. Ora, a lembrança das coisas deleitáveis é causa de
prazer. Logo, a das coisas tristes é causa da dor e não, do prazer.

3. Demais. ― A tristeza está para o prazer como o ódio para o amor. Ora, o ódio não é causa do amor,
antes pelo contrário, como foi dito. Logo, a tristeza não é causa do prazer,
Mas, em contrário, diz a Escritura (Sl 41, 4): As minhas lágrimas foram o meu pão de dia e de noite. Ora,
por pão entende-se o alimento do prazer. Logo, as lágrimas oriundas da tristeza podem ser deleitáveis.

SOLUÇÃO. ― A tristeza pode ser considerada de duplo ponto de vista: como atual e como existente na
memória, e de ambos esses modos pode ser causa do prazer. Assim, a tristeza atual é causa do prazer,
por despertar a memória da coisa amada, cuja ausência contrista, mas cuja apreensão só por si já
deleita. Mas a lembrança da tristeza se torna deleitável por causa da subseqüente libertação, pois não
padecer um mal implica a noção de bem. Por onde, aumenta-se-nos a matéria da alegria quando
conhecemos estarmos livres de certas tristezas e dores, e como diz Agostinho: muitas vezes, estando
alegres, lembramo-nos das coisas tristes; e sãos e sem dor, de coisas dolorosas, e isso faz com que nos
tornemos mais alegres e como reconhecidos. E o mesmo Agostinho afirma que quanto maior foi o
perigo na luta, tanto maior é a alegria do triunfo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Acidentalmente um contrário pode ser causa de outro;
assim o frio às vezes aquece, como diz Aristóteles. Semelhantemente, a tristeza é causa acidental do
prazer, enquanto que, por ela, se dá a apreensão de algum objeto deleitável.

RESPOSTA À SEGUNDA. ― A lembrança das coisas tristes, enquanto tristes e contrárias às deleitáveis,
não causam prazer, senão enquanto que o homem se sente liberto delas. E semelhantemente, a
lembrança de coisas agradáveis perdidas pode causar a tristeza.

RESPOSTA À TERCEIRA. ― O ódio pode por acidente ser causa do amor; assim, quando amamos os que
odeiam conosco um mesmo objeto.

## Art. 5 — Se as ações dos outros são-nos causa de prazer.
O quinto discute-se assim. ― Parece que as ações dos outros não nos são causa de prazer.

1. ― Pois, a causa do prazer é um bem próprio que conosco se aduna. Ora, isto não se dá com as ações
dos outros. Logo, estas não nos são causa de prazer.

2. Demais. ― Uma ação é um bem próprio do agente. Se pois as ações dos outros são-nos causa de
prazer, pela mesma razão hão-de sê-lo todos os demais bens deles, o que é claramente, falso.

3. Demais. ― A ação é deleitável enquanto precedente de um hábito que nos é inato; por isso diz
Aristóteles que devemos considerar o prazer de agir como sinal da formação de um hábito. Ora, as
ações dos outros não procedem de hábitos nossos, mas às vezes de hábitos dos que agem. Logo, tais
ações são deleitáveis, não para nós, mas para aqueles mesmos que agem.
Mas, em contrário, diz a Escritura (II Jo 4): Muito me alegrei por ter achado que alguns de teus filhos
andam em verdade.

SOLUÇÃO. ― Como já dissemos, duas condições se requerem para o prazer: a consecução do bem
próprio e o conhecimento dessa consecução. Por onde, de três modos a ação de outrem pode ser causa
de prazer. ― Primeiro, quando por meio de tal ação conseguimos algum bem. E neste sentido, as ações
daqueles que nos fazem bem nos são deleitáveis, pois é agradável receber um bem de outrem. ―
Segundo, quando por ação de outrem, chegamos a algum conhecimento ou a alguma apreciação do
bem próprio. E por isso, nos deleitamos quando louvados ou honrados pelos outros, pois então
entramos na apreciação de que em nós existe um certo bem. E como esta apreciação é mais fortemente
produzida pelo testemunho dos bons e dos virtuosos, nós nos deleitamos sobretudo com os louvores
deles. E essa é a razão por que, sendo o adulador um lisongeador fingido, as lisonjas são agradáveis a
muitos. E ainda, recaindo o amor sobre um determinado bem; e tendo a admiração por objeto algo de
grande, ser amado e admirado pelos outros é agradável, porque entramos então a estimar a nossa
própria vontade ou grandeza, com o que nos deleitamos. ― Terceiro, porque as ações mesmas dos
outros, quando boas, são apreciadas como bem próprio nosso, em virtude do amor, que nos leva a
estimar o amigo como a nós mesmos; e por causa do ódio, que nos leva a considerar o bem de outrem
como nos sendo contrário, a ação má de um inimigo nos é deleitável. Por onde, diz a Escritura (1 Cor 13,
6):a caridade não folga com a injustiça, mas folga com a verdade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A operação de outrem pode adunar-se comigo pelo
efeito, como no primeiro modo supra-referido; pela apreensão, como no segundo ou, pela afeição,
como no terceiro.

RESPOSTA À SEGUNDA. ― A objeção procede, relativamente ao terceiro dos modos referidos, não
porém aos dois primeiros.

RESPOSTA À TERCEIRA. ― As ações dos outros, embora não procedem de hábitos em mim existentes,
causam-me contudo algo de deleitável, ou me levam à apreciação ou à apreensão de um hábito próprio,
ou procedem de algum hábito de quem se unifica comigo pelo amor.

## Art. 6 — Se fazer bem a outrem é causa de prazer.
O sexto discute-se assim. ― Parece que fazer bem a outrem não é causa de prazer.

1. ― Pois, o prazer é causado pela consecução do bem próprio, como já foi dito. Ora, fazer bem não
concerne à consecução, mas antes, ao dispêndio do bem próprio. Logo, é antes causa de tristeza que de
prazer.

2. Demais. ― O Filósofo diz, que o egoísmo é mais conatural ao homem que a prodigalidade. Ora, a esta
pertence fazer bem aos outros, e àquele é próprio deixar de o fazer. Ora, como é deleitável a ação que a
cada um de nós é conatural, conforme Aristóteles, resulta que fazer bem aos outros não é causa de
prazer.

3. Demais. ― Efeitos contrários procedem de causas contrárias. Ora, certos atos, que consistem em
fazer mal aos outros, são-nos naturalmente deleitáveis, como vencer, repreender ou increpar os outros;
e também, para os irados, punir, conforme diz o Filósofo. Logo, fazer bem é antes causa de tristeza que
de prazer.
Mas, em contrário, diz o Filósofo que, é agradabilíssimo ser liberal para com os amigos ou estranhos e
auxiliá-los.

SOLUÇÃO. ― Fazer o bem a outrem pode ser causa de prazer, por tríplice razão. ― Primeira, por
comparação com o efeito, que é o bem praticado para com outrem. E neste sentido, reputando como
nosso próprio o bem de outrem, pela união do amor, deleitamo-nos com o bem que lhe fazemos,
sobretudo aos amigos, como com o bem que nos é próprio. ― Segunda, por comparação com o fim;
assim quando fazendo bem a outrem, esperamos conseguir um bem para nós mesmos, da parte de
Deus ou dos homens; ora, a esperança é causa de prazer. ― Terceira, por comparação com um princípio
tríplice. Um é a faculdade de fazer bem, pela qual se nos desperta uma certa imaginação de algum bem
abundantemente existente em nós, que podemos comunicar aos outros. E por isso, nós nos deleitamos
com os filhos e as próprias obras, como com aquilo ao que comunicamos o nosso bem próprio. Outro
princípio é o hábito, que nos inclina a fazer bem, e que nos torna conatural esse ato; e é por isso que os
liberais dão aos outros liberalmente. O terceiro é um princípio motor; assim, quando somos movidos,
por quem amamos, a lhe fazer bem; pois tudo o que fazemos ou sofremos por causa de um amigo nos é
deleitável, porque o amor é a principal causa do prazer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Dispender o que é nosso, enquanto manifesta o bem
próprio, é deleitável. Mas, enquanto dispêndio, sobretudo imoderado, pode ser causa de tristeza.

RESPOSTA À SEGUNDA. ― A prodigalidade implica um dispêndio imoderado, que repugna à natureza;
por isso se diz que ela é contra a natureza.

RESPOSTA À TERCEIRA. ― Vencer, repreender e punir não são atos deleitáveis enquanto implicam o
mal de outrem, mas enquanto dizem respeito ao bem próprio, que amamos mais do que odiamos o mal
de outrem. ― Assim, vencer é naturalmente agradável porque nos leva à estima da nossa própria
excelência. E por isso, de todos os jogos os mais deleitáveis são aqueles em que há luta e que podem
proporcionar vitória; e em geral, todas as lutas promissoras da esperança da vitória. ― Repreender e
increpar pode ser, de dois modos, causa de prazer. Primeiro, porque desperta em nós a imaginação da
sabedoria e da excelência própria, pois increpar e corrigir é próprio dos prudentes e mais velhos.
Segundo, porque, increpando e repreendendo, fazemos bem a outrem, e isso é deleitável, como já
dissemos. ― Quanto ao homem irado, é-lhe agradável o punir, porque lhe parece, assim, remover um
aparente rebaixamento, proveniente de uma ofensa precedente. Porque ao ofendido lhe parece sofrer
assim um rebaixamento, e por isso deseja libertar-se deste, retribuindo a ofensa. ― Por onde é claro,
que fazer bem a outrem pode, em si mesmo, ser deleitável; ao passo que fazer mal aos outros não é
deleitável senão enquanto o consideramos como incluindo o bem próprio.

## Art. 7 — Se a semelhança é causa do prazer.
O sétimo discute-se assim. ― Parece que a semelhança não é causa do prazer.

1. ― Pois, governar e presidir implica dissemelhança. Ora, ambos são deleitáveis, naturalmente, como
diz Aristóteles. Logo, mais que a semelhança, a dissemelhança é causa do prazer.

2. Demais. ― Nada é mais dissemelhante do prazer que a tristeza. Ora, os que sofrem de alguma tristeza
são os que mais procuram os prazeres, como diz Aristóteles. Logo, a dissemelhança é, mais que a
semelhança, causa do prazer.

3. Demais. ― Os que superabundam em certos prazeres não se deleitam, mas antes, se enfastiam com
eles, como o mostram os que se abarrotam de alimentos. Logo, a semelhança não é causa do prazer.
Mas, em contrário, a semelhança é causa do amor, como antes se disse. Ora, o amor é causa do prazer.
Logo, a semelhança é causa do prazer.

SOLUÇÃO. ― A semelhança é uma certa unidade; por isso, o semelhante, enquanto uno, é deleitável e
amável, como já dissemos. Por onde, o semelhante que não corrompe, mas aumenta o nosso bem
próprio, é deleitável, absolutamente; assim, o homem para o homem, o jovem para o jovem. O que
porém corrompe o nosso bem próprio se nos torna acidentalmente aborrecido e causa a tristeza, não
por certo como semelhante e uno, mas por corromper o que tem maior unidade.
Ora, de dois modos o semelhante pode corromper o nosso bem próprio. De um modo, corrompendo a
medida desse bem, por excesso; pois o bem, sobretudo o corpóreo, como a saúde, consiste numa certa
comensuração; e por isso, os que superabundam em alimento ou em qualquer prazer corpóreo, se
enfastiam. De outro modo, por contrariedade direta com o bem próprio; assim, os oleiros se detestam,
não como oleiros, mas por fazerem uns os outros perder a excelência ou lucro próprios, que desejam
como bem próprio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Entre governador e governado, havendo uma certa
comunidade, há também uma determinada semelhança que porém implica uma determinada
excelência, porque governar e presidir respeitam à excelência do bem próprio; assim, aos prudentes e
aos melhores compete governar e presidir; e isso desperta no homem, a representação da bondade
própria. ― Ou porque, governando ou presidindo, fazemos bem aos nossos semelhantes, e isso é
deleitável.

RESPOSTA À SEGUNDA. ― Aquilo com que se deleita o homem triste, embora não seja semelhante à
tristeza contudo é-lhe semelhante a ele, pois a tristeza contraria o bem próprio de quem está triste; e
por isso os tristes desejam o prazer, que contribui para o bem próprio deles, enquanto remédio do
contrário. E esta é a causa porque os prazeres corpóreos, a que são contrárias certas tristezas, são mais
desejados do que os intelectuais, que não tem a contrariedade da tristeza, como a seguir se dirá. E
assim se explica também porque todos os animais desejam naturalmente o prazer, pois o animal tem a
sua atividade sempre ligada aos sentidos e ao movimento. E também porque os moços são os que mais
buscam o prazer, por causa das muitas mudanças, que, por crescerem, sofrem. E por fim, também os
melancólicos desejam veementemente os prazeres, para expulsar a tristeza; pois, o corpo deles é como
que corroído pelo mau humor, conforme Aristóteles.

RESPOSTA À TERCEIRA. ― Os bens corpóreos implicam uma certa medida. Por onde, o superexcesso de
prazeres semelhantes corrompe o bem próprio. E assim, esse superexcesso torna-se fastidioso e causa
de tristeza, enquanto contraria o bem próprio do homem.

## Art. 8 — Se a admiração é causa de prazer.
O oitavo discute-se assim. ― Parece que a admiração não é causa de prazer.

1. ― Pois, admirar é próprio da natureza ignorante, como diz Damasceno. Ora, a ignorância não é
deleitável, mas antes, a ciência. Logo, a admiração não é causa do prazer.

2. Demais. ― A admiração é o princípio da ciência, quase via para inquirir a verdade, como diz
Aristóteles. Ora, contemplar o que já se conhece é mais deleitável do que perquirir o desconhecido,
como diz o Filósofo; pois, isto acarreta dificuldades e obstáculos e aquilo, não, pois o prazer é causado
por uma atividade sem obstáculos, como diz Aristóteles. Logo, a admiração não é causa do prazer,
antes, serve-lhe de obstáculo.

3. Demais. ― Todos nos deleitamos com aquilo com que estamos acostumados; e por isso as ações
habituais, por estarmos acostumados com o que já adquirimos, são deleitáveis. Ora, não admiramos
aquilo com o que estamos acostumados, como diz Agostinho. Logo, a admiração é contrária à causa do
prazer.
Mas, em contrário, diz o Filósofo, que a admiração é causa de prazer.

SOLUÇÃO. ― Alcançar o que desejamos é deleitável, como já dissemos. Por onde, quanto maior for o
desejo do objeto amado, tanto maior será o prazer causado pela sua aquisição. Além disso, o aumento
mesmo do desejo implica aumento do prazer, por implicar também a esperança de possuir o objeto
amado, conforme já dissemos, quando explicamos que, pela esperança, o desejo próprio é deleitável.
Ora, a admiração é o desejo de sabermos alguma coisa; o que se dá quando, vendo o efeito, ignoramos
a causa, ou quando a causa de um determinado efeito nos excede o conhecimento ou a faculdade. Por
onde, a admiração é causa do prazer, enquanto é acompanhada da esperança de conseguir o que deseja
saber. E por isso, tudo o admirável é deleitável, como o que é raro e todas as representações das coisas,
mesmo as que em si não são deleitáveis. Pois, a alma se compraz em comparar uma coisa com outra, o
que é ato próprio e conatural da razão, como diz o Filósofo. E também libertar-se de grandes perigos é
mais deleitável porque é admirável, como diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A admiração não é deleitável, quando acompanhada de
ignorância, mas quando tem o desejo de conhecer a causa, e quando, quem admira conhece algo de
novo i. é, se conhece como sendo diferente do que pensava ser.

RESPOSTA À SEGUNDA. ― O prazer implica duas condições: o repouso no bem e a percepção desse
repouso. Quanto à primeira, sendo mais perfeito contemplar a verdade conhecida, que perquirir a
desconhecida, a contemplação do que sabemos é em si mais deleitável que a perquirição do ignorado.
Contudo, por acidente e quanto à segunda condição, pode suceder que às vezes inquirir seja mais
agradável, quando a inquirição procede de uma maior desejo; ora, o desejo maior é excitado pela
percepção da ignorância. E por isso, nós nos deleitamos mais com o que pela primeira vez descobrimos
ou conhecemos.

RESPOSTA À TERCEIRA. ― Aquilo de que temos costume nos é deleitável, no agir, como nos sendo
quase conatural. Contudo as coisas raras podem ser agradáveis, que em razão do conhecimento, por
desejarmos o conhecimento delas como nos sendo admirável; quer em razão da ação, pois, pelo desejo
mais se inclina a mente a agir intensamente em relação ao que é novo, como diz Aristóteles. Ora, ação
mais perfeita causa prazer mais perfeito.