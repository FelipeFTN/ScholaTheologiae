# Questão 66: Da igualdade das virtudes.
Em seguida devemos tratar da igualdade das virtudes.
E sobre esta questão discutem-se seis artigos:

## Art. 1 — Se uma virtude pode ser maior ou menor.
(III Sent., disto XXXVI. a. 4 ; De Mato, q. 2. a. 9, ad 8 ; De Virtut., q. 5, a. 3).
O primeiro discute-se assim. — Parece que uma virtude não pode ser maior ou menor.

1. — Pois, como diz a Escritura (Ap 21, 16), os lados da cidade de Jerusalém são iguais, significando
aqui —lados — virtudes, como diz a Glosa a esse lugar. Logo, todas as virtudes são iguais e portanto
uma não pode ser maior que outra.

2. Demais. — Tudo aquilo que é, por essência, máximo, não pode ser maior nem menor. Ora, tal é a
virtude, que é, no dizer do Filósofo o que, na potência, é último; e Agostinho também diz, que as
virtudes são o máximo bem, de que ninguém pode usar mal. Logo, uma virtude não pode ser maior nem
menor.

3. Demais. — A quantidade do efeito se mede pela virtude do agente. Ora, as virtudes perfeitas, que são
as infusas, procedem de Deus, cuja virtude é uniforme e infinita. Logo, uma virtude não pode ser maior
que outra.
Mas, em contrário. — Onde pode haver aumento e superabundância pode haver desigualdade. Ora, nas
virtudes há superabundância e aumento, conforme aquilo da Escritura (Mt 5, 20): se a vossa justiça não
for maior e mais perfeita que a dos escribas e as dos Fariseus, não entrareis no reino dos céus; e ainda
(Pr 15, 5): Na abundante justiça há uma grandíssima força.

SOLUÇÃO. — A questão de saber se uma virtude pode ser maior que outra pode ser entendida de dois
modos. — Primeiro, no concernente a virtudes especificamente diferentes, e então é manifesto que
uma é maior que outra. Pois, sempre a causa é mais poderosa que o efeito; e, nos efeitos, há tanto
maior poder quanto maior é a proximidade da causa. Ora, é claro pelo que já foi dito, que a causa e a
raiz do bem humano é a razão. E portanto, a prudência, que aperfeiçoa a razão, tem preferência, quanto
à bondade, sobre as outras virtudes morais que aperfeiçoam a potência apetitiva enquanto participando
da razão. E dentre estas por sua vez será melhor a que mais participar da razão. Por isso a justiça, que
tem sua sede na vontade, tem preferência sobre as outras virtudes morais; e a fortaleza, cuja sede é o
irascível, tem preferência sobre a temperança, cuja sede é o concupiscível, que participa menos da
razão, como se vê em Aristóteles.
De outro modo, a questão pode ser entendida no concernente às virtudes da mesma espécie. E então,
como já dissemos, quando tratamos da intensidade dos hábitos, uma virtude pode ser considerada
como maior ou menor, quer em si mesma, quer em relação ao sujeito participante. — Se pois a
considerarmos em si mesma, a grandeza ou pequenez da virtude depende da sua extensão. Assim,
aquele que tem uma virtude, p. ex., a temperança, a tem em toda a sua extensão, o que não se dá com
a ciência e com a arte, pois o gramático não sabe tudo o que respeita à gramática. E neste sentido
andaram bem os estóicos, como refere Simplício dizendo que a virtude, bem como a ciência e a arte não
é susceptível de mais nem de menos, porque a virtude, por essência, consiste num máximo. — Se porém
considerarmos a virtude relativamente ao sujeito participante, então pode ser maior ou menor, quer
referente à mesma pessoa, em tempos diversos, quer referente a pessoas diversas. Porque, para
alcançar o meio termo da virtude, dependente da razão reta, um tem melhor disposição que outro, quer
por estar mais acostumado, quer por melhor disposição natural, quer por ter uma razão que julga com
mais perspicácia, ou ainda quer por um maior dom da graça, que é dada a cada um segundo a medida
do dom de Cristo, como diz a Escritura (Ef 4, 7). E neste ponto é falha a doutrina dos estóicos quando
ensinam que não pode ser considerado virtuoso senão quem tiver suma disposição para a virtude.
Porque, a virtude, na sua essência, não exige alcancemos o meio termo da razão reta, de modo
absoluto, como pensavam os estóicos; mas basta atinjamos as proximidades desse meio, como se disse.
Pois, um atinge mais aproximada e prontamente que outro um mesmo sinal indivisível, como nô-lo
mostram os sagitários que, atiram a um certo alvo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A igualdade de que se trata não deve ser considerada
como quantidade absoluta, mas proporcionalmente; porque todas as virtudes humanas aumentam,
deste último modo, como a seguir se dirá.

RESPOSTA À SEGUNDA. — Esse máximo último que é próprio da virtude pode se apresentar como
sendo mais ou menos bom, conforme os modos supra-referidos; pois, não consistem num último termo
indivisível, como já dissemos.

RESPOSTA À TERCEIRA. — Deus não obra por necessidade natural, mas conforme a ordem da sua
sabedoria, pela qual dá as virtudes aos homens, segundo medidas diversas, conforme aquilo da Escritura
(Ef 4, 7): a cada um de nós foi dada a graça, segundo a medida do dom de Cristo.

## Art. 2 — Se todas as virtudes de um mesmo homem são igualmente intensas.
(II Sent., dist. XLII, q. 2. a. 5. ad 6; III, dist. XXXVI. a. 4; De Malo, q.2, a. 9, ad 8; De Virtut., q. 5, a. 3).
O segundo discute-se assim. — Parece que todas as virtudes de um mesmo homem não são
igualmente intensas.

1. — Pois, como diz o Apóstolo (1 Cor 7, 7), porém cada um tem de Deus seu próprio dom: uns na
verdade duma sorte, e outro da outra. Ora, se todos tivessem de certo modo, por dom de Deus todas as
virtudes infusas, não teriam uns dons diferentes de outros. Logo, nem todas as virtudes são iguais num
mesmo homem.

2. Demais. — Se todas as virtudes de um mesmo homem fossem igualmente intensas, quem excedesse
a outrem por uma determinada virtude o excederia também por todas as outras. Ora, isto é
evidentemente falso. Pois, muitos santos são principalmente louvados em relação a virtudes diversas:
assim, Abraão, pela fé; Moisés, pela mansidão; Jó, pela paciência. E por isso na Igreja se canta de um
confessor (Ecle 44, 20): Não se achou outro semelhante a ele, no guardar a lei do Excelso; pois, cada um
tem a prerrogativa de uma determinada virtude. Logo, nem todas as virtudes de um mesmo homem são
igualmente intensas.

3. Demais. — Tanto mais intenso é um hábito e tanto mais deleitável e prontamente nos faz obrar. Ora,
a experiência ensina que um pratica uns atos virtuosos mais deleitável e prontamente que outros. Logo,
nem todas as virtudes de um mesmo homem são igualmente intensas.
Mas, em contrário, Agostinho diz que os iguais em fortaleza são-no também em prudência e
temperança, e assim por diante. Ora, isto não se daria se todas as virtudes de um mesmo homem não
fossem iguais. Logo, elas o são.

SOLUÇÃO. — A quantidade das virtudes pode ser considerada à dupla luz, como já dissemos. Ou quanto
à essência específica delas, e então não há dúvida que uma virtude é num mesmo homem maior que
outra; assim, a caridade, maior que a fé e a esperança. Ou quanto à participação do sujeito i. é,
enquanto num determinado sujeito tem maior ou menor intensidade; e neste sentido todas as virtudes
de um mesmo homem são iguais, por uma igualdade proporcional, enquanto nele crescem igualmente,
assim como os dedos da mão, quantitativamente desiguais, são iguais proporcionalmente por
proporcionalmente crescerem.
Ora, devemos compreender esta noção de igualdade como a de conexão, pois a igualdade é uma certa
conexão quantitativa das virtudes. Ora, como já dissemos, à conexão das virtudes podemos assinalar
duplo fundamento.
O primeiro concorda com a interpretação daqueles que, pelas quatro virtudes cardeais entendem
quatro condições gerais das virtudes, cada uma das quais se manifesta simultaneamente com as outras,
em qualquer matéria. E então, as virtudes, em relação a uma dada matéria, não podem ser consideradas
iguais se não tiverem todas essas condições iguais. E esta é a razão da igualdade delas dada por
Agostinho, quando escreve: Se disseres que, dentre vários homens de fortaleza igual, um sobressai pela
prudência resulta que a fortaleza deste será menos prudente; e, do mesmo modo, nem todos serão de
fortaleza igual, quando a fortaleza de um for mais prudente; e o mesmo verás em relação às demais
virtudes, se as percorreres todas, a essa luz.
Um segundo fundamento é dos que entenderam que as virtudes cardeais têm matérias determinadas. E
a esta luz a conexão das virtudes morais se funda na prudência e, quanto às virtudes infusas, na
caridade e não na inclinação, que é dependente do sujeito, como já dissemos. Assim, pois, podemos
descobrir o fundamento da igualdade das virtudes na prudência, quanto ao que todas as virtudes morais
têm de formal. Por onde, quem tiver uma razão igualmente perfeita há de, proporcionalmente a essa
razão reta, estabelecer o meio termo em qualquer matéria das virtudes. Porém, quanto ao que as
virtudes morais têm de material, i. é, quanto à inclinação mesma para o ato virtuoso, pode um homem
praticar mais prontamente um do que outro ato virtuoso, quer por natureza, quer por costume, ou
ainda pelo dom da graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lugar do Apóstolo pode ser entendido dos dons da
graça gratuita, que não são comuns a todos, nem são todos iguais num mesmo homem. — Ou se pode
dizer que se refere à medida da graça santificante, segundo a qual um abunda em todas as virtudes mais
que outro, por causa da maior abundância da prudência, ou também da caridade, que obra a conexão
entre todas as virtudes infusas.

RESPOSTA À SEGUNDA. — Um santo é louvado principalmente por uma virtude, e outro, por outra, por
praticar pronta e excelentemente um do que outro ato virtuoso.
E daqui consta também com clareza a resposta À TERCEIRA OBJEÇÃO.

## Art. 3 — Se as virtudes morais têm preeminência sobre as intelectuais.
(IIª. lIae, q. 23, a. 6. ad 1 ; IV Sent., dist. XXXIII, q. 3, a. 3).
O terceiro discute-se assim. — Parece que as virtudes morais têm preeminência sobre as intelectuais.

1. — Pois, o que é mais necessário e mais permanente é melhor. Ora, as virtudes morais são mais
permanentes mesmo que as ciências, que são virtudes intelectuais; logo, também são mais necessárias
à vida humana. Logo, têm preeminência sobre as virtudes intelectuais.

2. Demais. — A virtude, por essência, torna bom quem a possui. Ora, as virtudes morais é que tornam o
homem bom, não porém as intelectuais, a não ser talvez a prudência, unicamente. Logo, as virtudes
morais são melhores que as intelectuais.

3. Demais. — O fim é mais nobre que os meios. Mas, como se disse, a virtude moral torna reta a
intenção do fim, ao passo que a prudência torna reta a eleição dos meios. Logo, a virtude moral é mais
nobre que a prudência, virtude intelectual que versa sobre a moralidade.
Mas, em contrário. — A virtude moral reside em a nossa parte racional por participação, ao passo que a
intelectual, por essência, como se disse. Ora, o racional por essência é mais nobre que o racional por
participação. Logo, as virtudes intelectuais são mais nobres que as morais.

SOLUÇÃO. — Em dois sentidos podemos compreender uma coisa como maior que outra: absoluta e
relativamente. Ora, nada impede que o melhor absolutamente não o seja, relativamente; assim, embora
filosofar seja melhor que enriquecer, não o é contudo para quem sofre necessidades. A consideração
absoluta se funda na essência específica. Ora, como a virtude se especifica pelo seu objeto, segundo já
dissemos, mais nobre, absolutamente falando, é a que tem um objeto mais nobre. Ora, é manifesto que
o objeto da razão é mais nobre que o do apetite; pois, ao passo que aquela apreende o universal, este
tende para as coisas enquanto particulares. Por onde, absolutamente falando, as virtudes intelectuais,
que aperfeiçoam a razão, são mais nobres que as morais, que aperfeiçoam o apetite. Se porem
considerarmos a virtude relativamente ao ato, a moral, que aperfeiçoa o apetite, o qual atualiza as
outras potências, como já dissemos, é mais nobre. E como se chama virtude àquilo que, sendo perfeição
da potência, é princípio de um ato, essa denominação convém, por essência, mais às virtudes morais
que às intelectuais, embora estas constituam, absolutamente falando, hábitos mais nobres.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As virtudes morais são mais duradouras que as
intelectuais por se exercerem relativamente à vida comum. Mas é manifesto que os objetos das
ciências, que são necessárias e têm sempre o mesmo modo de existir, são mais permanentes que os das
virtudes morais, que são atos particulares. E o serem as virtudes morais mais necessárias à vida humana,
não prova que sejam, absolutamente, as mais nobres, senão só relativamente. Portanto, as virtudes
intelectuais especulativas, por isso mesmo que não se ordenam a outro fim, como o útil, são mais
dignas. E isto porque elas causam de certo modo, em nós, uma felicidade incoativa e a felicidade
consiste no conhecimento da verdade, como já dissemos.

RESPOSTA À SEGUNDA. — As virtudes morais, e não as intelectuais, tornam o homem bom,
absolutamente falando, porque o apetite move para o seu ato as outras potências, como já dissemos.
Por onde, isto não prova senão que as virtudes morais são, relativamente, melhores.

RESPOSTA À TERCEIRA. — A prudência não só dirige as virtudes morais na eleição dos meios, mas
também na pre-instituição do fim. Ora, o fim de cada virtude moral é atingir o meio termo, na sua
matéria própria, e este é determinado pela razão reta dirigida pela prudência, como se disse.

## Art. 4 — Se a justiça é a principal entre as virtudes morais.
(Supra, a. 1 ; IIª. lIae, q. 58, a. 12; q. 123, a. 12; q. 141, a. 8; IV Sent., dist. XXXIII, q. 3, a. 3 ; De Virtut., q.
5, a. 3).
O quarto discute-se assim. — Parece que a justiça não é a principal entre as virtudes morais.

1. — Pois, dar a alguém do seu é mais do que lhe restituir o devido. Ora, aquilo é próprio da liberalidade,
isto, da justiça. Logo, parece que a liberalidade é maior virtude que a justiça.

2. Demais. — O que há num ser de mais perfeito é o que nele há também de maior. Ora, como diz a
Escritura (Tg 1, 4), a paciência é perfeita nas suas obras. Logo, é maior que a justiça.

3. Demais. — A magnanimidade obra o que é grande, em todas as virtudes, como se disse. Logo, ela
engrandece a própria justiça e portanto é maior que esta.
Mas, em contrário, diz o Filósofo, que a justiça é a preclaríssima das virtudes.

SOLUÇÃO. — Uma virtude pode ser considerada, na sua espécie, maior ou menor, absoluta ou
relativamente falando. É absolutamente maior aquela em que esplende um maior bem racional, como já
dissemos. E a esta luz, a justiça tem preexcelência sobre todas as virtudes morais, como sendo mais
próxima da razão; o que claramente se manifesta tanto pelo seu sujeito como pelo seu objeto. Pois, o
sujeito da justiça é a vontade, que é o apetite racional, segundo já foi claramente estabelecido. O objeto
ou matéria da justiça são os atos pelos quais o homem tem relação, não só consigo mesmo, mas
também com outrem. Por onde, a justiça é a preclaríssima das virtudes, como se disse.
E quanto às outras virtudes morais, que versam sobre as paixões, tanto mais esplenderá em cada uma o
bem da razão, quanto mais importantes forem os objetos relativamente aos quais o movimento
apetitivo se sujeitar à razão. Ora, o maior bem do homem, de que dependem todos os outros, é a vida. E
portanto, a fortaleza, que sujeita à razão o movimento apetitivo, no relativo à morte e à vida, ocupa o
primeiro lugar entre as virtudes morais que versam sobre as paixões; contudo, ela se subordina à justiça.
E por isso o Filósofo diz, que, necessariamente, as máximas virtudes são as mais honradas pelos outros,
pois a virtude é uma potência benefactiva. É por isto que se honram principalmente, os fortes e os
justos, porque, a fortalezaé útil na guerra, e a justiça, na guerra e na paz. Depois da fortaleza vem à
temperança, que sujeita o apetite à razão no atinente ao que se ordena imediatamente à vida, quer isso
se considere individualmente, quer especificamente, como no caso dos alimentos e das relações
sexuais. E assim, essas três virtudes, simultaneamente com a prudência, consideram-se principais,
mesmo em dignidade.
Relativamente porém, dizemos que uma virtude é maior, por acrescentar à virtude principal um
adminículo ou ornato. Assim também a substância é, absolutamente falando, mais digna que o acidente;
o que não impede seja, relativamente falando, um acidente mais digno, por aperfeiçoar a substância por
algum ser acidental.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O ato de liberalidade há-se de fundar sobre o da justiça,
pois, o dom não seria liberal se não o fizéssemos com o que é nosso, como se disse. Por onde, sem a
justiça, que discerne o nosso, do alheio, não pode haver liberalidade; mas aquela pode existir sem esta.
Portanto, absolutamente falando, a justiça é maior que a liberalidade, por ser mais geral e lhe servir de
fundamento. Mas, relativamente, a liberalidade é maior, por ser um como ornato da justiça, e seu
suplemento.

RESPOSTA À SEGUNDA. — Diz-se que a paciência é perfeita nas suas obras, no que respeita ao
sofrimento dos males, em relação aos quais ela não só exclui a injusta vingança, que a justiça também
exclui; nem só o ódio, como o faz a caridade; nem só a ira, como o faz a mansidão; mas também a
tristeza desordenada, raiz de todos os males que acabamos de enumerar. E por isso, é mais perfeita e
maior, porque, na matéria em questão, extirpa a raiz. Mas não é, absolutamente falando, mais perfeita
que as outras virtudes, porque a fortaleza não somente suporta os sofrimentos sem se perturbar, o que
também faz a paciência, mas também os afronta, quando necessário. Por onde, quem é forte é
paciente, mas não, vice-versa. Pois, a paciência é parte da fortaleza.

RESPOSTA À TERCEIRA. — Não pode haver magnanimidade sem a preexistência das outras virtudes,
como se disse. Por isso ela é como o ornato das outras. E portanto, é maior que todas as outras, relativa
e não absolutamente.

## Art. 5 — Se a sabedoria é a maior das virtudes intelectuais.
(Supra, q. 57. a. 2. ad 2 ; VI Ethic., lect. VI).
O quinto discute-se assim. — Parece que a sabedoria não é a maior das virtudes intelectuais.

1. — Pois, quem dirige é maior que o dirigido. Ora, parece que a prudência impera sobre a sabedoria
como diz o Filósofo: esta, i. é, a política, relativa à prudência, segundo ficou dito, esta preordena quais
as artes que devem existir no Estado, e quais e até que ponto cada um as deve estudar. Ora, como a
sabedoria também faz parte da ciência, resulta que a prudência é maior que ela.

2. Demais. — É da essência da virtude ordenar o homem à felicidade, pois, ela é a disposição do que é
perfeito para o que é ótimo, como se disse. Ora, a prudência é a razão reta dos atos, pelos quais
alcançamos a felicidade; ora, a sabedoria não considera esses atos. Logo, a prudência é maior que ela.

3. Demais. — Tanto mais perfeito, tanto maior é o conhecimento. Ora, podemos ter um conhecimento
mais perfeito das coisas humanas, com as quais se ocupa a ciência, do que das divinas, objeto da
sabedoria, como diz Agostinho; porque as coisas divinas são incompreensíveis, conforme aquilo da
Escritura (Jó 36, 26): Com efeito, Deus é grande, que sobreexcede a nossa ciência. Logo a ciência é maior
virtude que a sabedoria.

4. Demais. — O conhecimento dos princípios é mais digno que o das conclusões. Ora, a sabedoria, como
as outras ciências, conclui partindo de princípios indemonstráveis, objeto do intelecto. Logo, o intelecto
é maior virtude que a sabedoria.
Mas, em contrário, o Filósofo diz, que a sabedoria é como a cabeça das virtudes intelectuais.

SOLUÇÃO. — Como já dissemos, a grandeza específica de uma virtude depende do seu objeto. Ora; o
objeto da sabedoria tem precedência sobre os objetos de todas as virtudes intelectuais, pois, é Deus,
causa altíssima, como já dissemos. E como pela causa julgamos do efeito, e pela causa superior, das
inferiores, à sabedoria cabe julgar de todas as outras virtudes intelectuais e ordená-las a todas, e é
quase arquitetônica em relação a todas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Versando a prudência sobre as coisas humanas e a
sabedoria, sobre a causa altíssima, é impossível seja a prudência maior virtude que a sabedoria, a menos
que, como se disse, o homem fosse o que há de maior no mundo. Por onde, devemos concluir,
conforme também já está dito que a prudência não governa a sabedoria, mas ao inverso, pois, como diz
a Escritura (1 Cor 2, 15), o espiritual julga todas as coisas, e ele não é julgado de ninguém. Assim, a
prudência não deve se ocupar com as coisas altíssimas, que a sabedoria considera, mas dirige aquilo que
se ordena à sabedoria, i. é, se ocupa com o modo pelo qual os homens devem chegar à sabedoria. E por
aí a prudência ou política é ministra da sabedoria, pois conduz a ela, preparando-lhe a via, como o
ostiário ao rei.

RESPOSTA À SEGUNDA. — A prudência considera os meios pelos quais chegamos à felicidade, ao passo
que a sabedoria considera o objeto mesmo da felicidade que é o inteligível altíssimo. Ora, se a sabedoria
fosse perfeita no considerar o seu objeto, nesse ato consistiria a felicidade perfeita. Mas, como o ato da
sabedoria nesta vida é imperfeito, em relação ao seu principal objeto que é Deus, esse ato é uma como
incoação ou participação da felicidade futura. E portanto, está mais próxima da felicidade que a
prudência.

RESPOSTA À TERCEIRA. — Como diz o Filósofo, um conhecimento é superior a outro, ou porque tem um
objeto mais nobre, ou pela sua certeza. Se porém os objetos fossem iguais em bondade e nobreza, a
virtude mais certa será a maior. Mas a menos certa porém, com objetos mais altos e mais importantes,
é superior a mais certa, mas que tem por objeto coisas inferiores. Por isso o Filósofo diz que é grande
coisa poder conhecer algo sobre as coisas celestes, mesmo por uma razão débil e local. E, noutro lugar,
Aristóteles diz, que é preferível conhecer um pouco dos seres mais nobres, que conhecer muito de seres
inferiores. Por onde, a sabedoria, cujo objeto é o conhecimento de Deus, o homem, no estado da vida
presente, não pode alcançá-la perfeitamente, de modo a ter-lhe a posse, o que só é próprio de Deus,
como se disse. Porém, mesmo esse pequeno conhecimento, que, pela sabedoria, podemos ter de Deus,
é preferível a qualquer outro.

RESPOSTA À QUARTA. — A verdade e o conhecimento dos princípios indemonstráveis depende da
natureza dos termos. Assim, quem souber o que é o todo e o que é a parte, imediatamente
compreenderá que o todo é maior que a parte. Ora, conhecer em que consiste o ente e o não-ente, o
todo e a parte, e tudo o mais que resulta do ser e de que se constituem como termos; os princípios
indemonstráveis, isso pertence à sabedoria. Pois, o ser comum é efeito próprio da causa altíssima, i. é,
Deus. E portanto, a sabedoria não só se serve dos princípios indemonstráveis, que é o objeto do
intelecto, para por eles chegar a conclusões, como o fazem também as outras ciências, mas também os
julga e disputa contra os que os negam. Donde se conclui que a sabedoria é maior virtude que o
intelecto.

## Art. 6 — Se a caridade é a maior das virtudes teologais.
(IIª. lIae , q. 23, a. 6).
O sexto discute-se assim. — Parece que a caridade não é a maior das virtudes teologais.

1. — Pois, como a fé reside no intelecto, e a esperança e a caridade na potência apetitiva, como já se
disse, resulta que a fé está para a esperança e a caridade, como a virtude intelectual para a moral. Ora,
aquela é maior que esta, como do sobredito resulta. Logo, a fé é maior que a esperança e a caridade.

2. Demais. — O resultado de uma adição é maior que o adicionado. Ora, parece que a esperança é como
que adicionada à caridade, pois pressupõe o amor, como diz Agostinho, porque torna mais intensa a
tendência para a coisa amada. Logo, é maior que a caridade.

3. Demais. — A causa tem prioridade sobre o efeito. Ora, a fé e a esperança são causas da caridade,
conforme a glosa de Mateus 1, que diz que a fé gera a esperança e a esperança, a caridade. Logo, a fé e
a esperança são maiores que a caridade.
Mas, em contrário, diz a Escritura (1 Cor 13, 13): Agora, pois, permanecem a fé, a esperança e a
caridade, estas três virtudes; porém a maior delas é a caridade.

SOLUÇÃO. — Como já dissemos, a grandeza específica da virtude depende do objeto. Ora, como são
três as virtudes teologais referentes a Deus, como objeto próprio, uma não pode ser considerada maior
que outra por ter um objeto maior, mas por estar mais próxima dele. E deste modo, a caridade é a
maior de todas. Pois, as outras implicam, por essência, uma certa distância do objeto, porquanto a fé
versa sobre o que não vemos, e a esperança sobre o que não temos. Ao passo que o amor de caridade
recai sobre o que já possuímos, pois o amado está, de certa maneira, no amante; e, pelo afeto, este é
levado a unir-se àquele; e por isso, diz a Escritura (1 Jo 4, 16): aquele que permanece na caridade
permanece em Deus, e Deus nele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A fé não está para a esperança e a caridade como a
prudência para as virtudes morais. E isto por duas razões. — A primeira é que as virtudes teologais tem
um objeto superior à alma humana, ao passo que a prudência e as virtudes morais versam sobre o que é
inferior ao homem. Ora, o amor do que é superior ao homem é mais nobre que o conhecimento. Pois, o
conhecimento se completa pela presença do objeto no sujeito conhecente, enquanto que o amor, pela
tendência do amante para o amado. Ora, o superior ao homem é mais nobre em si mesmo do que pelo
modo que nele existe, pois aquilo que em outrem existe, existe ao modo deste. O contrário sucede com
o inferior ao homem. — A segunda é que a prudência modera os movimentos apetitivos, dependentes
das virtudes morais. Ora, a fé não modera o movimento apetitivo tendente para Deus, que pertence às
virtudes teologais, mas somente mostra o objeto. Ora, o movimento apetitivo para o objeto excede o
conhecimento humano, conforme aquilo da Escritura (Ef 3, 19): a caridade de Cristo, que excede todo
entendimento.

RESPOSTA À SEGUNDA. — A esperança pressupõe o amor d'aquilo que esperamos alcançar, que é o
amor de concupiscência, pelo qual mais nos amamos a nós mesmos, quando desejamos o bem, que
qualquer outra coisa. Ao passo que a caridade implica o amor de amizade, ao qual nos leva a esperança,
como já dissemos.

RESPOSTA À TERCEIRA. — A causa perficiente tem prioridade sobre o seu efeito, mas não a causa
dispositiva. Do contrário, o calor do fogo seria mais forte que a alma, à qual ele dispõe a matéria, o que
é evidentemente falso. Assim, pois, a fé gera a esperança, e esta, a caridade, enquanto uma dispõe para
a outra.