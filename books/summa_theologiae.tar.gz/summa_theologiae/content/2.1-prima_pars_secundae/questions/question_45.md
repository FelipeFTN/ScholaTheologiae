# Questão 45: Da coragem.
Em seguida devemos tratar a coragem. E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se a coragem é contrária ao temor.
(Supra, q. 23, a. 2).
O primeiro discute-se assim. — Parece que a coragem não é contrária ao temor.

1. — Pois, como diz Agostinho, a coragem é um vício. Ora, o vício é contrário à virtude. Logo, não sendo
o temor virtude, mas paixão, a coragem não lhe é contrária.

2. Demais — A unidade é contrária à unidade. Ora, a esperança é contrária ao temor. Logo, não o é o
temor.

3. Demais — Uma paixão exclui a sua oposta. Ora, a segurança é a excluída pelo temor; pois, como diz
Agostinho, o temor vela pela sua segurança. Logo, a segurança é contrariada pelo temor e não pela
coragem.
Mas, em contrário, diz o Filósofo, que a coragem é contrária ao temo.

SOLUÇÃO. — Está em a natureza dos contrários distarem entre si no máximo grau, como diz Aristóteles.
Ora, o que dista em máximo grau do temor é a coragem. Pois, aquele receia o dano futuro, por causa da
vitória deste sobre a pessoa que teme; ao passo que a coragem afronta o perigo iminente, por causa da
sua vitória sobre o próprio perigo. Por onde e manifestamente, a coragem é contrária ao temor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ira, a coragem e os nomes de todas as paixões podem
ser tomados em dupla acepção. Numa, enquanto implicam, absolutamente, o movimento do apetite
sensitivo para algum objeto bom ou mau; e nesse sentido designam paixões. Noutra, enquanto
simultaneamente com esse movimento, implicam desvio da ordem da razão; e nesse sentido designam
vícios. Ora, é nesta última acepção que Agostinho toma a coragem; ao passo que nós a tomamos na
primeira.

RESPOSTA À SEGUNDA. — Não pode haver pluralidade de contrários à unidade, tomada num mesmo
sentido; mas nada impede tal se dê quando ela é tomada em sentidos diversos. E assim, como já
dissemos, as paixões do irascível têm dupla contrariedade: uma, pela oposição do bem e do mal, e assim
o temor é contrário à esperança; outra, pela de aproximação e afastamento, e assim a coragem é
contrária ao temor, ao passo que a esperança o é ao desespero.

RESPOSTA À TERCEIRA. — A segurança nada significa de contrário ao temor, mas só a exclusão deste;
pois, dizemos que está seguro quem não teme. Por onde, a segurança se opõe ao temor, como privação;
a coragem, porém, como contrário. Ora, como este inclui em si a privação, assim a coragem inclui a
segurança.

## Art. 2 — Se a coragem resulta da esperança.
(Supra, q.25, a . 3; De Verit., q. 26, a . 5, ad 2; III Ethic., lect. XV).
O segundo discute-se assim. — Parece que a coragem não resulta da esperança.

1. — Pois, a coragem é relativa ao mal aterrorizante, como diz Aristóteles. Ora, a esperança diz respeito
ao bem, como já dissemos. Logo, têm objetos diversos e não pertencem à mesma ordem. Portanto, a
coragem não resulta da esperança.

2. Demais — Como a coragem é contrária ao temor, assim o desespero o é à esperança. Ora, o temor
não resulta do desespero, pois antes, este exclui aquele, como diz o Filósofo. Logo, a coragem não
resulta da esperança.

3. Demais — A coragem visa um certo bem, a saber, a vitória. Ora, tender para um bem árduo é próprio
da esperança. Logo, a coragem é o mesmo que a esperança e, portanto, dela não resulta.
Mas, em contrário, diz o Filósofo: os que têm esperança firme são corajosos. Logo, parece que a
coragem resulta da esperança.

SOLUÇÃO. — Como já dissemos muitas vezes, todas as paixões da alma, de que tratamos, pertencem à
potência apetitiva. Ora, todos os movimentos dessa potência se reduzem à busca e à fuga. Ora, uma e
outra visam um determinado objeto essencial ou acidentalmente; essencialmente falando, buscamos o
bem e fugimos do mal. Acidentalmente porém, podemos buscar o mal por causa de algum bem, que vai
de mistura com ele, e fugir do bem, por causa de algum mal que lhe está adjunto. Mas, como o acidental
depende do essencial, a busca do mal depende da do bem, assim como a fuga do bem depende da do
mal. Ora, os quatro casos considerados dizem respeito às quatro paixões; a busca do bem é própria da
esperança; a fuga do mal é própria do temor; a busca do mal aterrorizante pertence à coragem, e a fuga
do bem, ao desespero. Donde se conclui que a coragem resulta da esperança, pois, é porque esperamos
superar um mal aterrorizante iminente que o afrontamos audazmente. Ao passo que do temor resulta o
desespero, pois desesperamos quando tememos a dificuldade que rodeia o bem esperado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colheria se o bem e o mal fossem objetos sem
dependência entre si. Mas como o mal se ordena, de certo modo, ao bem, pois lhe é posterior como a
privação o é ao hábito, há-de, por força, a coragem, que afronta o mal, ser posterior à esperança, que
busca o bem.

RESPOSTA À SEGUNDA. — Embora o bem em si mesmo tenha prioridade sobre o mal, contudo a fuga
diz respeito, primeiro, ao mal, que ao bem; assim como a prossecução é própria primeiro ao bem, que
ao mal. Por onde, como a esperança tem prioridade sobre a coragem, assim o temor a tem sobre a
desesperação. E como do temor nem sempre resulta o desespero, mas, só quando for intenso; assim, da
esperança nem sempre resulta coragem, senão só quando ela for veemente.

RESPOSTA À TERCEIRA. — A coragem embora relativa ao mal a que está conjunto o bem da vitória,
segundo o pensa o corajoso, visa contudo o mal; ao passo que a esperança visa o bem conjunto. E
semelhantemente, o desespero visa o bem diretamente, de que foge; ao passo que o temor respeita o
mal adjunto. Por onde, propriamente falando, a coragem não é parte, mas efeito da esperança; assim
como o desespero não é parte, mas efeito do temor. E por isto também, a coragem não pode ser uma
paixão principal.

## Art. 3 — Se a deficiência pode ser causa da coragem.
O terceiro discute-se assim. — Parece que a deficiência pode ser causa da coragem.

1. — Pois, diz o Filósofo, que os amantes do vinho são fortes e audazes. Ora, do vinho provém o efeito
da embriaguez. Logo, a coragem é causada por um defeito.

2. Demais — O Filósofo diz, que os inexperientes dos perigos são corajosos. Ora, a inexperiência é um
defeito. Logo, a coragem é causada por um defeito.

3. Demais — Os que sofreram injustiças costumam ser mais corajosos, como também os animais,
quando açoitados, como diz Aristóteles. Ora, sofrer injustiça é uma deficiência. Logo, a coragem é
causada por esta.
Mas, em contrário, diz o Filósofo, que a causa da coragem está em se trazer na fantasia, a esperança da
salvação próxima e de estarem longe ou não existirem coisas que aterrorizam. Ora, o que implica uma
deficiência ou diz respeito à remoção do que salva, ou à proximidade do que aterroriza. Logo, nada que
implique deficiência pode ser causa da coragem.

SOLUÇÃO. — Como já dissemos antes, a coragem resulta da esperança e é contrária ao temor. Por
onde, tudo o que, por natureza, causa a esperança ou exclui o temor é causa da coragem. Como porém
o temor, a esperança e também a coragem, sendo paixões, supõem um movimento do apetite, e uma
certa transmutação corpórea, à dupla luz podemos considerar a causa da coragem: quanto à
provocação da esperança ou quanto à exclusão do temor. Aquela é relativa ao movimento apetitivo;
esta, à transmutação corpórea.
Quanto ao movimento apetitivo, resultante da apreensão, a esperança, causadora da coragem, é
provocada pelo que nos leva a pensar ser-nos possível alcançar a vitória. Ou pelo nosso próprio poder,
como pela força do corpo, pela experiência dos perigos, pela abundância do dinheiro e por coisas
semelhantes. Ou pelo poder de outros, como o grande número de amigos ou quaisquer outros
auxiliares; e principalmente se confiarmos no auxílio divino. Por onde, os de mais confiança em Deus são
os mais corajosos, como diz o Filósofo. Ao passo que, segundo este mesmo modo, o temor é excluído
pelo afastamento de coisas aterrorizantes, próximas; p. ex., por não termos inimigos, por não termos
feito mal a ninguém, por não vermos nenhum perigo iminente; pois os perigos parecem iminentes
sobretudo aos que fizeram mal aos outros.
De outro lado, quanto à transmutação corpórea, a coragem é causada pela provocação da esperança e
pela exclusão do temor, por parte dos elementos que produzem o calor no coração. E por isso diz o
Filósofo, que os de coração pequeno são mais corajosos; e os animais de coração grande são
tímidos; porque o calor natural não pode aquecer um coração grande tão bem como aquece um
pequeno, assim como o fogo não pode aquecer uma casa grande tão bem como uma pequena. E noutro
livro, diz que os de pulmão sanguíneo são mais corajosos, por causa do calor do coração daí resultante.
E no mesmo lugar diz que os amantes do vinho são mais corajosos, por causa da calidez do mesmo. Por
isso dissemos, que a embriaguez contribui para a firmeza da esperança; pois, o calor do coração repele o
temor e causa a esperança, pelo distender-se, pelo amplificar-se do coração.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A embriaguez causa a coragem, não como defeito, mas
por dilatar o coração, e também por dar uma certa amplitude à estimativa.

RESPOSTA À SEGUNDA. — Os inexperientes dos perigos são mais corajosos, não por deficiência, mas
por acidente; isto é, enquanto que, pela inexperiência, não conhecem a própria debilidade nem a
presença dos perigos; e assim, da eliminação da causa do temor resulta a coragem.

RESPOSTA À TERCEIRA. — Como diz o Filósofo, os que sofreram injustiça tornam-se corajosos por
pensarem que Deus lhes vem em auxílio aos que se acham nessas condições. Por onde é claro que
nenhuma deficiência pode causar a coragem senão por acidente; i. é, enquanto tem alguma excelência
adjunta, verdadeira ou julgada tal, seja por nós mesmos, ou por outrem.

## Art. 4 — Se os corajosos são mais audazes antes dos perigos do que depois de estarem neles.
(III Ethic., lect. XV).
O quarto discute-se assim. — Parece que os corajosos não o são mais antes dos perigos do que depois
de neles estarem.

1. — Pois, o tremor é causado pelo temor, que é contrário à coragem, como do sobredito resulta. Ora,
os corajosos, a princípio tremem, às vezes, como diz o Filósofo. Logo, não são mais corajosos antes dos
perigos que depois de neles estarem.

2. Demais — A paixão se intensifica com o crescimento do seu objeto; assim, se o bom é amável, mais
sê-lo-á o melhor. Ora, o árduo é o objeto de coragem. Logo, o crescimento daquele importa o desta. E
como o perigo presente se torna mais árduo e difícil, há-de acarretar também o aumento da coragem.

3. Demais — Sofrimentos causados provocam a ira. Ora, esta causa a coragem; pois, como diz o
Filósofo, a ira é corajosa. Logo, parece que se tornam mais corajosos os que já estão nos perigos e
feridos.
Mas, em contrário, diz Aristóteles, que os corajosos, antes dos perigos, correm-lhes veloz e
ardentemente ao encontro; mas, quando neles se acham, recuam.

SOLUÇÃO. — A coragem, sendo um movimento do apetite sensitivo, resulta da apreensão da potência
sensitiva. E, esta não compara nem indaga circunstâncias particulares, mas julga subitamente. Ora,
acontece às vezes que, por uma súbita apreensão, não pode ser conhecido tudo o que suscita
dificuldade, num caso dado. Donde, os movimentos da coragem, que afrontam o perigo. Pelo que,
quando entramos a experimentá-lo, sentimos maiores dificuldades do que a princípio pensávamos, e
por isso recuamos.
Ao passo que a razão examina tudo o que, num caso dado, pode suscitar dificuldades. E isto explica que
os fortes, que afrontam os perigos, depois de havê-los examinados, parecem remissos, a princípio,
porque os afrontam não apaixonadamente, senão com a devida deliberação. Mas, quando já se acham
metidos nos perigos, nenhuma surpresa experimentam; antes, eles lhes parecem menores do que a
princípio pensaram. — Ou então é que os fortes afrontam os perigos movidos pelo bem da virtude,
perseverando neles a vontade do bem, quaisquer que sejam aqueles. Ao passo que os corajosos, só pela
impressão alimentam a esperança e excluem o temor, como já dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Também aos corajosos pode sobrevir o tremor, pelo
concentrar-se do calor, de fora para dentro, como se dá com os que temem, Ao passo, que aos
corajosos o calor se lhes concentra no coração, aos que temem se lhes concentra nas partes inferiores.

RESPOSTA À SEGUNDA. — O objeto do amor é o bem puro e simples; por isso, se este aumenta,
aumenta pura e simplesmente aquele. Ao passo que o objeto da coragem é composto de bem e de mal;
e o seu movimento contra o mal pressupõe o da esperança para o bem. Por onde, o tal movimento não
cresce mas, antes, diminui, quando a dificuldade do perigo cresce a ponto de exceder a esperança. Se
esse movimento, porém, se mantiver quanto maior for o perigo, tanto maior será julgada a coragem.

RESPOSTA À TERCEIRA. — Um ferimento não causa a ira se não supusermos a existência da esperança,
como a seguir se dirá. Se pois, o perigo for tamanho, que excede a esperança da vitória, dele não
resultará a ira. Mas é verdade que, da seqüência desta, resulta o aumento da coragem.