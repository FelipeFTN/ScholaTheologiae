# Questão 35: Da dor e da tristeza em si mesmas.
Em seguida devemos tratar da dor e da tristeza.
E sobre esta questão temos que tratar, primeiro, da tristeza ou dor em si mesma. Segundo, das suas
causas. Terceiro, dos seus efeitos. Quarto, dos seus remédios. Quinto, da sua bondade ou malícia.
Sobre a primeira questão oito artigos se discutem:

## Art. 1 — Se a dor é paixão da alma.
(II, q. 84, a . 9, ad 2).
O primeiro discute-se assim. Parece que a dor não é paixão da alma.

1. — Pois, nenhuma paixão da alma existe no corpo. Ora, a dor pode nele existir, conforme aquilo de
Agostinho: a chamada dor do corpo é a corrupção repentina da saúde daquilo que a alma, usando mal,
sujeitou à corrupção. Logo a dor não é paixão da alma.

2. Demais — Toda paixão da alma reside na potência apetitiva. Ora, a dor reside não nessa potência,
mas, na apreensiva, conforme Agostinho: a dor do corpo é causada pelo sentido que reside a um corpo
mais poderoso. — Logo, a dor não é paixão da alma.

3. Demais — Toda paixão da alma diz respeito ao apetite animal. Ora, não a esse apetite, mas antes, ao
natural é que diz respeito a dor, conforme Agostinho: Se não restasse nenhum bem em a natureza, a
dor não seria a pena do bem perdido. Logo, a dor não é paixão da alma.
Mas, em contrário, Agostinho coloca a dor entre as paixões da alma, baseado naquilo de Virgílio: Por
isso temem, desejam, alegram-se e sofrem.

SOLUÇÃO. — Assim como o prazer requer duas condições — a união com o bem e a percepção dessa
união, assim também duas são as exigidas pela dor — a mescla com algum mal que o é porque priva de
algum bem, e a percepção dessa mescla. Ora, se aquilo que se mescla não tiver, em relação ao com que
se mescla, a natureza de bem ou de mal, não pode causar prazer nem dor. Por onde é claro que o objeto
do prazer e da dor é o apreendido sob a noção de bem ou de mal. Ora, o bem e o mal como tais
constituem o objeto do apetite. Logo, é claro que o prazer e a dor dizem respeito ao apetite.
Ora, todo movimento apetitivo ou inclinação consecutiva à apreensão diz respeito ao apetite intelectivo
ou sensitivo. Pois, a inclinação do apetite natural não segue a apreensão do apetente, mas, de outrem,
como já dissemos na primeira parte. E como o prazer e a dor pressupõem, no mesmo jeito, um sentido
ou uma certa apreensão, é manifesto que tanto esta como aquele existem no apetite intelectivo ou
sensitivo.
Ora, todo movimento do apetite sensitivo se chama paixão, como já dissemos; e principalmente o que
implica algum defeito. Por onde a dor, como existente no apetite sensitivo, se chama muito
propriamente paixão da alma; assim como as moléstias corpóreas chamam-se propriamente paixões do
corpo. E por isso Agostinho chama especialmente à dor sofrimento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que a dor é corpórea porque a causa de dor está
no corpo; assim, quando sofremos algo que lhe é nocivo. Mas o movimento da dor sempre reside na
alma, pois o corpo não pode padecer dor se não a sofre a alma, como diz Agostinho.

RESPOSTA À SEGUNDA. — Diz-se que a dor respeita ao sentido, não por ser ato da virtude sensitiva,
mas porque é necessária à dor corpórea, bem como ao prazer.

RESPOSTA À TERCEIRA. — A dor, pela perda de um bem, demonstra a bondade da natureza; não que a
dor seja ato do apetite natural, mas porque do sentir a natureza o aparta-se de algum objeto desejado
como bem, procede a paixão da dor no apetite sensitivo.

## Art. 2 — Se a tristeza é dor.
(III, q 15 a . 6; III Sent., dist. XV, 1. 2 a . 3, qª 1, 2; De Verit., q. 26, a . 3, ad 9; a . 4 ad 4).
O segundo discute-se assim. — Parece que a tristeza não é dor.

1. — Pois, como diz Agostinho, a dor se refere ao corpo. Ora, a tristeza diz respeito sobretudo, à alma.
Logo, a tristeza não é dor.

2. Demais — A dor só se refere ao mal presente. Ora, a tristeza pode referir-se ao pretérito e ao futuro;
assim, a penitência é uma tristeza relativa ao pretérito e a ansiedade, ao futuro. Logo, a tristeza difere
absolutamente da dor.

3. Demais — A dor não é causada senão pelo sentido do tato. Ora, a tristeza pode ser causada por todos
os sentidos. Logo, a tristeza não é dor e é objeto de um conceito mais lato.
Mas, em contrário, diz o Apóstolo (Rm 9, 2): Tenho grande tristeza e contínua dor no meu coração,
usando das palavras tristeza e dor no mesmo sentido.

SOLUÇÃO. — O prazer e a dor podem ser causados por dupla apreensão: pela do sentido externo ou
pela interna, da inteligência ou da imaginação. Ora, a apreensão interna tem maior extensão que a
externa, pois tudo o que entra no domínio desta entra também no daquela, mas não inversamente. Por
onde, só o prazer causado pela apreensão interna é denominado alegria, como já dissemos. E
semelhantemente, é chamada tristeza só aquela dor que é causada pela apreensão interna. E assim
como só o prazer causado pela apreensão externa merece o nome de tal e não o de alegria, assim
também a dor causada pela apreensão externa tem tal denominação e não a de tristeza. Logo, a tristeza
é uma espécie de dor, como a alegria uma espécie de prazer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No passo aduzido, Agostinho se refere ao uso do
vocábulo; pois a palavra dor é usada sobretudo para exprimir as dores corpóreas, que são mais
conhecidas, do que para exprimir as dores espirituais.

RESPOSTA À SEGUNDA. — Ao passo que o sentido externo só percebe o presente, a faculdade cognitiva
interna pode perceber o presente, o pretérito e o futuro. E por isso a tristeza pode se referir ao
presente, ao pretérito e ao futuro; ao passo que a dor corpórea, consecutiva à apreensão do sentido
externo só pode referir-se ao presente.

RESPOSTA À TERCEIRA. — Os sensíveis do tato são dolorosos, não só enquanto desproporcionados à
potência apreensiva mas também na medida em que contrariam a natureza. Os sensíveis dos outros
sentidos porém, embora possam ser desproporcionados à potência apreensiva, contudo não contrariam
a natureza senão em ordem aos sensíveis do tato. Por isso, só o homem, animal de conhecimento
perfeito, se deleita com os sensíveis em si mesmos dos outros sentidos, enquanto que os brutos só se
deleitam com eles na medida em que se referem aos sensíveis do tato, como diz o Filósofo. E por isso,
em relação aos sensíveis dos outros sentidos, não dizemos que há dor enquanto esta contraria o prazer
natural, mas antes, tristeza, que contraria o prazer animal. Se, pois, numa acepção mais usual,
tomarmos a dor como significando dor corpórea, ela se divide, por oposição com a tristeza e
relativamente à distinção entre apreensão interna e externa, embora quanto aos objetos o prazer tenha
maior extensão que a dor corpórea. Se porém tomarmos a palavra dor numa acepção comum, então ela
vem a ser um gênero de tristeza, como já dissemos.

## Art. 3 — Se a dor contraria o prazer.
(Supra, q.31, a . 8 ad 2; III, q. 84, a . 9, ad 2; IV Sent., dist. XLIX, q. 3, a . 3, qª 1).
O terceiro discute-se assim. — Parece que a dor não contraria o prazer.

1. — Pois um contrário não pode ser causa de outro. Ora, a tristeza pode ser causa do prazer, conforme
a Escritura (Mt 5, 5): Bem-aventurados os que choram porque serão consolados. Logo, não são
contrários.

2. Demais — Um contrário não pode denominar a outro. Mas, em certos casos, a dor em si mesma ou
tristeza é deleitável; assim, Agostinho diz que a dor nos espetáculos deleita; e que o pranto é amargo e
contudo, às vezes, deleita. Logo, a dor não é contrária ao prazer.

3. Demais — Um contrário não pode ser matéria de outro, porque os contrários não podem existir
simultaneamente. Ora, a dor pode ser matéria de prazer, pois diz Agostinho: Que o penitente sempre se
condói e se alegra com a sua dor. E o Filósofo diz que, inversamente, o mau se doe daquilo com que se
deleitou. Logo, o prazer e a dor não são contrários.
Mas, em contrário, diz Agostinho: a alegria consiste em a vontade consentir naquilo que desejamos; a
tristeza, em dissentir do que não queremos. Ora, consentir e dissentir são contrários. Logo, contrários
hão de ser o prazer e a tristeza.

SOLUÇÃO. — Como diz o Filósofo, a contrariedade é uma diferença formal. Ora, a forma ou espécie da
paixão e do movimento é oriunda do objeto ou termo. Ora, sendo contrários os objetos do prazer e da
tristeza ou dor, a saber, o bem e o mal presentes, conclui-se que a dor e o prazer são contrários.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede seja, acidentalmente, um contrário causa
de outro. Assim, a tristeza pode ser causa do prazer. De um modo, quando a tristeza, pela ausência de
um bem ou pela presença do mal contrário, busca mais veementemente o objeto do prazer; assim, o
sedento busca mais veementemente a bebida como remédio contra a tristeza que sofre. De outro
modo, quando pelo grande desejo de um prazer, não recusamos sofrer tristezas para chegarmos ao
prazer almejado. E de um e outro modo, a tristeza presente conduz à consolação da vida futura. Pois,
chorando pelos pecados ou pela dilação da glória, o homem merece a consolação eterna.
Semelhantemente, também a merece quem, para consegui-la, não foge a sofrer, por ela, trabalhos e
angústias.

RESPOSTA À SEGUNDA. — A dor mesma pode ser, por acidente, deleitável; assim quando, como nos
espetáculos, vai junta com a admiração; ou quando faz recordar o objeto amado e sentir o amor
daquele por cuja ausência se sofre. Por onde, sendo o amor deleitável, também a dor e tudo o que dele
resulta e o faz sentir são deleitáveis. E por isso também as dores, nos espetáculos, podem ser
deleitáveis, por nos levarem a sentir amor por aqueles que aí são representados.

RESPOSTA À TERCEIRA. — A vontade e a razão refletem sobre os seus atos, enquanto considerados sob
as noções de bem e de mal. E deste modo, a tristeza pode ser matéria do prazer ou inversamente; não
por si, mas por acidente, sendo uma e outra considerados à luz das noções de bem e de mal.

## Art. 4 — Se a tristeza é universalmente contrária ao prazer.
O quarto discute-se assim. — Parece que a tristeza é universalmente contrária ao prazer.

1. — Pois, assim como a brancura e a negrura são espécies contrárias de cor, assim espécies contrárias
de paixões da alma são o prazer e a tristeza. Ora, a brancura e a negrura se opõem universalmente.
Logo, também o prazer e a tristeza.

2. Demais — Remédio supõe contrariedade. Ora, o prazer é um remédio universal contra a tristeza,
como se vê claramente no Filósofo. Logo, o prazer é universalmente contrário a qualquer tristeza.

3. Demais — Os contrários são impedimentos uns dos outros. Ora, a tristeza impede universalmente o
prazer, como se vê claro no Filósofo. Logo, a tristeza é contrária universalmente ao prazer.
Mas, em contrário. — Os contrários não podem ter a mesma causa. Ora, pela mesma disposição,
(habitus) alegramo-nos com uma coisa e nos contristamos com a oposta; e daí vem que a caridade
leva a nos alegrarmos com os que se alegram e a chorarmos com os que choram, como diz o Apóstolo
(Rm 12, 15). Logo, nem toda tristeza é contrária ao prazer.

SOLUÇÃO. — Como diz Aristóteles, a contrariedade é uma diferença formal, e a forma é geral ou
especial. Donde resultam certas contrariedades de forma genérica, como a da virtude e do vício, e
outras de forma específica como a de justiça e injustiça.
Devemos porém notar que certas coisas se especificam por formas absolutas, como as substâncias e as
qualidades; e outras, por comparação com algo de extrínseco e, assim as paixões e os movimentos se
especificam pelos termos ou pelos objetos. Por isso, nos casos em que as espécies são consideradas
relativamente a formas absolutas, as espécies contidas em gêneros contrários não são contrários
especificamente; mas isso não importa tenham qualquer afinidade ou conveniência entre si. Assim, a
intemperança e a justiça, pertencentes a gêneros contrários, a saber à virtude e ao vício, não são
contrárias entre si quanto à noção específica própria, mas nem por isso tem qualquer afinidade ou
conveniência mútua. Mas nos casos em que as espécies se fundam na relação com algo de extrínseco,
sucede que as dos gêneros contrários não só não são contrários entre si, mas ainda tem uma certa
conveniência e afinidade mútua. E isso porque comportar-se do mesmo modo em relação aos contrários
implica em contrariedade; assim, aproximar-se do branco e aproximar-se do preto supõe a noção de
contrariedade; ao passo que comportar-se de modo contrário em relação aos contrários importa a
noção de semelhança, como afastar-se do branco e aproximar-se do preto. E isto se manifesta
sobretudo na contradição, que é princípio de oposição; e esta consiste em afirmar e negar a mesma
coisa, como, branco e não-branco; porém a afirmação de um dos opostos e a negação de outro
importam conveniência e semelhança, como quando digo preto e não-branco.
Ora, a tristeza e o prazer sendo paixões, especificam-se pelos seus objetos. E certo, tem entre si
contrariedade genérica, pois este implica a prossecução e aquela, a fuga, que se comportam, em relação
ao apetite, como a afirmação e a negação relativamente à razão, conforme diz Aristóteles. E portanto, a
tristeza e o prazer, referentes ao mesmo objeto, opõem-se especificamente entre si. Porém a tristeza e
o prazer relativos a objetos diversos, se estes não forem opostos, mas desproporcionados, não mantêm
entre si oposição específica, mas são também desproporcionados; assim o entristecer-se pela morte de
um amigo e o deleitar-se com a contemplação. Se porém esses objetos diversos forem contrários, então
o prazer e a tristeza não só não mantêm contrariedade específica mas antes, tem conveniência e
afinidade; assim, o alegrar-se com o bem e o entristecer-se com o mal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A brancura e a negrura não se especificam pela relação
com algo de extrínseco, como o prazer e a tristeza. Portanto não realizam a mesma noção.

RESPOSTA À SEGUNDA. — O gênero se funda da matéria, como está claro em Aristóteles. Nos acidentes
porém, o sujeito ocupa o lugar da matéria. Ora, como já dissemos, o prazer e a tristeza são
genericamente contrários. E portanto, em qualquer tristeza a disposição do sujeito é contrária à
disposição de qualquer prazer, em que o apetite se comporta como aceitante do que tem, ao passo que
em toda tristeza procura fugir. E assim, em relação ao sujeito, o prazer é remédio universal contra a
tristeza; e a tristeza é empecilho universal a qualquer prazer; e sobretudo quando o prazer é
especificamente contrário à tristeza.
Donde se deduz clara A RESPOSTA À TERCEIRA OBJEÇÃO. — Ou se pode responder de outro modo que,
embora nem toda tristeza seja especificamente contrária a qualquer prazer, contudo quanto ao efeito o
é; pois este conforta a natureza animal e aquela, de certo modo, a molesta.

## Art. 5 — Se alguma tristeza é contrária ao prazer da contemplação.
(III, q. 46, a . 7, ad 4; III Sent., dist. XV, q. 2, a . 3, qª 2, ad 3; dist. XXVI, q. 1 a . 5, ad 5; IV, dist. XLIX, q. 3, a
. 3, qª 2; De Verit., q. 26, a . 3, ad 6; a . 9, ad 8; Ompend. Theol., e. CLXV).
O quinto discute-se assim. — Parece que alguma tristeza é contrária ao prazer da contemplação.

1. — Pois, diz o Apóstolo (2 Cor 7, 10): A tristeza que é segundo Deus produz para a salvação uma
penitência estável. Ora, pensar em Deus compete à razão superior, à qual é próprio o entregar-se à
contemplação, segundo Agostinho. Logo, a tristeza se opõe ao prazer da contemplação.

2. Demais — Os contrários são efeitos dos contrários. Se pois a contemplação de um contrário é causa
de alegria, a de outro sê-lo-á de tristeza. E, assim, a tristeza será contrária ao prazer da contemplação.

3. Demais — Assim como o objeto do prazer é o bem, o da tristeza é o mal. Ora, a contemplação pode
implicar a noção de mal, pois, como diz o Filósofo, é inconveniente meditar em certas coisas. Logo, a
tristeza pode ser contrária ao prazer da contemplação.

4. Demais — Qualquer operação que não sofra impedimento é causa do prazer, como diz Aristóteles.
Ora, a operação contemplativa pode ser impedida de muitos modos, de maneira a dissipar-se
totalmente ou realizar-se com dificuldade. Logo, na contemplação pode haver tristeza contrária ao
prazer.

5. Demais — A aflição da carne é causa de tristeza. Ora, diz a Escritura (Ecl 12, 12): a meditação
freqüente é aflição da carne. Logo, a contemplação implica a tristeza contrária ao prazer.
Mas, em contrário, diz a Escritura (Sb 8, 16): a sua conversação, i. e, da sabedoria, não tem nada de
desagradável nem a sua companhia nada de fastidioso; mas o que nela se acha é satisfação e prazer.
Ora, a conversação e a companhia da sabedoria se dá por meio da contemplação. Logo, nenhuma
tristeza é contrária ao prazer da contemplação.

SOLUÇÃO. — O prazer da contemplação pode ser entendido de dois modos. — De modo que a
contemplação seja a causa e não o objeto do prazer; e então este não procede da contemplação, mas da
coisa contemplada. Ora, pode acontecer que contemplemos um objeto nocivo e contristador, ou
conveniente e aprazível. Logo, se entendermos neste sentido o prazer da contemplação, nada impede a
tristeza lhe seja contrária. — De outro modo, podemos entender o prazer da contemplação no sentido
em que esta é o objeto e a causa daquela; assim, quando nos deleitamos com a contemplação mesma. E
assim, como diz Gregório Nisseno (Nemésio),ao prazer da contemplação não se opõe nenhuma tristeza;
e o mesmo diz o Filósofo. Mas isto, se considerarmos esse prazer em si mesmo. E a razão é que a
tristeza, em si mesma, contraria o prazer que tem um objeto contrário ao dela; assim, a tristeza causada
pelo frio é contrária ao prazer causado pelo calor. Ora, nada há de contrário ao objeto da contemplação.
Pois as noções dos contrários, enquanto apreendidas, não são contrárias; antes, um contrário é a razão
de conhecermos o outro. Por onde, ao prazer da contemplação em si mesmo não pode ser contrária
nenhuma tristeza. Ainda mais não têm mescla de nenhuma tristeza, como se dá com os prazeres
corpóreos, que servem como de remédios contra certos sofrimentos; assim, picados pela sede,
deleitamo-nos com a bebida, e cessada de todo aquela, cessa também o prazer de beber. Ora, o prazer
da contemplação não é causada pela exclusão de nenhum sofrimento, mas por ser ela em si mesma
deleitável; pois não é uma geração, mas uma operação perfeita, como já dissemos.
Acidentalmente porém, a tristeza pode mesclar-se com o prazer da apreensão, e isto de dois modos: por
parte do órgão e por impedimento da apreensão. — Por parte do órgão, a tristeza ou dor mescla-se com
a apreensão, diretamente, nas potências apreensivas da parte sensitiva, que se servem de órgão
corpóreo. Isto provém do sensível, contrário à compleição normal do órgão, e assim o gosto é contrário
ao amargo e o olfato, ao fétido; ou da continuidade do sensível próprio que pela sua assiduidade produz
o embotamento da potência natural, como já dissemos, e assim torna fastidiosa a apreensão sensível,
que antes era deleitável. Ora, esses dois fatos não se realizam diretamente em relação à contemplação
da mente, porque esta não é função de nenhum órgão corpóreo. Por isto, o passo citado da Escritura diz
que a contemplação mental nada tem de desagradável nem de fastidioso. — Como porém a mente
humana se serve, para contemplar, das potências apreensivas sensitivas, cujos atos são susceptíveis de
lassidão, daí vem que, indiretamente, alguma aflição ou dor pode mesclar-se com a contemplação.
Mas de nenhum desses modos a tristeza, mesclada acidentalmente com a contemplação, pode
contrariar o prazer desta proveniente. Pois a tristeza causada pelo impedimento da contemplação não
vai contra o prazer desta, antes, tem com ela afinidade e conveniência, como do sobredito resulta (a. 4).
A tristeza porém ou a aflição proveniente do cansaço corpóreo não cabe nesse mesmo gênero, e
portanto é completamente desproporcionada dele. E assim é manifesto que nenhuma tristeza é
contrária ao prazer fundado na contemplação mesma, e que, salvo acidentalmente, nenhuma tristeza se
pode com ele mesclar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A tristeza segundo Deus não procede da contemplação
mesma da mente, mas de algo que ela contempla — o pecado, e que considera como contrário à divina
deleitação.

RESPOSTA À SEGUNDA. — Coisas contrárias na realidade da natureza não tem contrariedade, enquanto
existentes em a nossa mente. Assim, as noções dos contrários não são contrários, mas antes, um é a
razão de conhecermos o outro, e por isso a ciência dos contrários é uma só.

RESPOSTA À TERCEIRA. — A contemplação em si mesma não pode implicar nunca a noção de mal, pois
ela não é senão a consideração da verdade, bem do intelecto. Acidentalmente porém o pode, quando a
contemplação do que é vil impede a do melhor; ou quando o apetite deseja desordenadamente a coisa
contemplada.

RESPOSTA À QUARTA. — A tristeza proveniente do impedimento à contemplação não contraria o
prazer da mesma, antes, tem afinidade com ela, como já dissemos.

RESPOSTA À QUINTA. — A aflição da carne pode mesclar-se, acidental e indiretamente, com a
contemplação da mente, como já dissemos.

## Art. 6 — Se o evitamento da tristeza é mais veemente que o desejo do prazer.
(IIª-IIªº, q. 138, a . 1; III Sent., dist. XXVII, q. 1, a . 3, ad 3; IV, dist. XLIX, q. 3, a . 3, qª 3).
O sexto discute-se assim. — Parece que o evitamento da tristeza é mais veemente que o desejo do
prazer.

1. — Pois, diz Agostinho: Não há ninguém que não prefira evitar a dor a desejar o prazer. Ora, aquilo em
que todos comumente consentem parece ser natural. Logo, é natural e conveniente preferir evitar a
tristeza a desejar o prazer.

2. Demais — A ação do contrário contribui para a rapidez e a intensidade do movimento; assim, a água
quente congela-se mais rápida e fortemente, como diz o Filósofo. Ora, por lhe ser contrária é que o
triste procura evitar a tristeza; ao passo que o desejo do prazer não vem de nenhuma contrariedade
entre este e quem está triste, mas antes, procede da conveniência com aquele que se deleita. Logo,
evitar a tristeza supera em intensidade o desejo do prazer.

3. Demais — Quanto mais forte for a paixão que superarmos, pelo esforço da razão, tanto mais dignos
de louvor e virtuosos seremos; porque, como diz Aristóteles, a virtude versa sobre o difícil e bom. Ora, o
forte, que resiste ao movimento conducente a evitar a dor, é mais virtuoso que o sóbrio que resiste ao
movimento conducente a desejar o prazer; pois, como diz o Filósofo, os fortes e os justos são sobretudo
os honrados. Logo, mais veemente é o movimento pelo qual evitamos a tristeza, do que aquele que nos
leva a desejar o prazer.
Mas, em contrário. — O bem é mais forte que o mal, como se lê claramente em Dionísio. Ora, o prazer é
desejável por causa do bem, seu objeto; ao passo que por causa do mal é que procuramos evitar a
tristeza. Logo, o desejo do prazer é mais forte que o evitamento da tristeza.

SOLUÇÃO. — Em si mesmo considerado, o desejo do prazer é mais forte que o evitamento da tristeza.
— E a razão é que a causa do prazer é o bem conveniente; ao passo que a da dor ou tristeza é algum mal
repugnante. Ora, pode acontecer que um bem seja conveniente sem nenhuma dissonância; mas não
pode haver nenhum mal repugnante totalmente, sem nenhuma conveniência. Por onde, o prazer pode
ser íntegro e perfeito, enquanto que a tristeza é sempre parcial; e por isso o desejo do prazer é mais
intenso que o evitamento da tristeza. — A segunda razão é que o bem, objeto do prazer é desejado por
si mesmo, ao passo que o mal, objeto da tristeza, deve ser evitado como privação que é, do bem. Ora, o
existente por si tem prioridade sobre o existente por outro. — E a prova disto se manifesta nos
movimentos naturais. Pois todo movimento natural é mais intenso no fim, quando se aproxima do
termo conveniente à sua natureza, do que no princípio, quando se afasta do termo não conveniente à
sua natureza. Assim, a natureza tende mais intensamente ao conveniente, do que foge do repugnante.
Portanto também a inclinação da virtude apetitiva, em si mesma considerada, tende ao prazer com
maior veemência do que aquela com que evita a tristeza.
Mas por acidente pode acontecer que fujamos da tristeza mais veementemente do que desejamos o
prazer. E isto por três razões. — A primeira se funda na apreensão. Pois, como diz Agostinho, o amor é
mais sentido quando se põe de manifesto a sua falta. Ora, da falta do bem amado procede a tristeza,
proveniente ou da perda desse bem ou da sua privação, causada por um mal contrário. O prazer, ao
contrário, não sofre privação do bem amado, mas repousa no bem já alcançado. Ora, sendo o amor a
causa do prazer e da tristeza, tanto mais evitamos a esta, quanto mais ela nos faz sentir o amor, que lhe
é contrário. A segunda se funda na causa da tristeza ou produtora da dor, repugnante a um bem mais
amado do que aquele com qual nos deleitamos. Assim mais amamos a integridade natural do nosso
corpo do que o prazer da comida. E por isso, por medo da dor proveniente dos flagelos ou de outros
castigos, contrários à sã integridade do corpo, nos privamos do prazer da comida ou de coisas
semelhantes. — A terceira razão se funda no efeito, i. é, enquanto a tristeza impede não só um, mas
todos os prazeres.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dito de Agostinho, que a dor é evitada mais
veementemente que o prazer desejado, é verdadeiro acidental e não, essencialmente. O que se torna
claro pelo que acrescenta: às vezes vemos animais crudelíssimos absterem-se dos maiores prazeres, por
medo de dores, contrárias à vida, amada por excelência.

RESPOSTA À SEGUNDA. — Uma coisa se dá com o movimento procedente do interior e outra, com o
procedente do exterior. Aquele tende ao conveniente com maior veemência do que se afasta do que lhe
é contrário, como já o dissemos a respeito do movimento natural. Mas o segundo se intensifica pela
própria contrariedade; porque cada ser se esforça, a seu modo, por resistir ao que lhe é contrário, bem
como para se conservar a si mesmo. Por isso o movimento violento intensifica-se no princípio e remite-
se no fim. Ora, o movimento da parte apetitiva tem procedência interna, pois procede da alma para as
coisas. E portanto, em si mesmo considerado, o prazer é desejado com maior veemência do que a
tristeza é evitada. Porém o movimento da parte sensitiva procede do exterior, quase das coisas para a
alma; e por isso é mais sentido o que é mais contrário. E assim, mesmo por acidente, na medida em que
os sentidos são necessários para o prazer e a tristeza, esta é evitada com maior veemência do que
aquele é desejado.

RESPOSTA À TERCEIRA. — O homem forte não é louvado pela sua razão não ser vencida pela dor ou por
qualquer tristeza, senão por não ser vencida pela tristeza conexa com o perigo de morte. Ora, esta a
evitamos com maior veemência do que desejamos o prazer da comida ou o sexual, sobre os quais versa
a sobriedade; do mesmo modo, a vida é mais amada do que a comida ou o coito. Mas, o sóbrio é mais
louvado por não buscar os prazeres do tato do que por não evitar as tristezas contrárias, como está
claro em Aristóteles.

## Art. 7 — Se a dor externa é maior que a dor interna do coração.
(Infra, q. 37, a . 1, ad 3).
O sétimo discute-se assim. — Parece que a dor externa é maior que a dor interna do coração.

1. — Pois, a dor corpórea externa procede de uma causa repugnante à boa conservação do corpo, sede
da vida; ao passo que a dor interna é causada por alguma imaginação do mal. Ora, sendo a vida mais
amada que o bem é imaginado, resulta, conforme o que já foi dito, que a dor externa é maior que a
interna.

2. Demais — Mais move uma coisa real que sua semelhança. Ora, a dor externa provém da união real
com algum contrário; ao passo que a interna, da semelhança apreendida do contrário. Logo é aquela
maior que esta.

3. Demais — A causa é conhecida pelo seu efeito. Ora, a dor externa produz efeitos mais fortes; assim o
homem morre mais facilmente por causa de dores externas que por causa da interna. Logo, a dor
externa é maior e mais para evitada, que a interna.
Mas, em contrário, diz a Escritura (Ecl 25, 17): A tristeza do coração é uma praga universal, e a maldade
da mulher é uma consumada malícia. Logo, como a malícia da mulher supera todas as outras, conforme
desse texto se deduz, assim a tristeza do coração excede todas as dores externas.

SOLUÇÃO. — A dor externa e a interna tem um ponto comum e dois, pelos quais diferem. Têm de
comum o serem ambas movimentos da virtude apetitiva, como já dissemos. Mas diferem pelos dois
elementos implicados na tristeza e no prazer, a saber, a causa, que é o bem ou o mal anexo, e a
apreensão. Ora, a causa da dor externa é o mal anexo, repugnante ao corpo; ao passo que a da dor
interna é o mal anexo repugnante ao apetite. Demais disso, a dor externa resulta da apreensão do
sentido, e especialmente do tato; enquanto que a interna resulta da apreensão interna, i. é, da
imaginação, ou também da razão.
Se portanto compararmos a causa da dor interna com a da externa, uma pertence, em si mesma, ao
apetite que abrange ambas as dores, mas a outra lhe pertence imediatamente. Assim, a dor interna
provém de alguma coisa repugnar ao apetite diretamente; e a externa, de lhe repugnar a este por já ter
repugnado antes ao corpo. E como sempre o existente por si tem prioridade sobre o existente por
outro, por este lado a dor interna tem preeminência sobre a externa. — E o mesmo resulta se
considerarmos a apreensão. Pois a apreensão racional e imaginativa é mais elevada que a do sentido do
tato. Por onde, absolutamente falando e em si mesma, a dor interna é mais forte que a externa. E a
prova é que aceitamos voluntariamente, as dores externas, para evitarmos a interna. E enquanto a dor
externa não repugna ao apetite interior, torna-se de certo modo deleitável e agradável à alegria interior.
Às vezes porém a dor externa é acompanhada da interna, e então a dor aumenta. Pois a interna é, não
só maior que a externa, mas também mais universal. Assim, tudo o repugnante ao corpo pode repugnar
ao apetite interno; e tudo o apreendido pelo sentido pode ser apreendido pela imaginação e pela razão;
mas não inversamente. E por isso a autoridade aduzida diz expressamente: a tristeza do coração é uma
praga universal; porque as dores dos flagelos exteriores estão compreendidas na tristeza interna do
coração.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A dor interna pode também ser causada pelo que
contraria a vida. E assim não devemos pensar que a relação existente entre a dor externa e a interna se
funde nos males diversos causados pela dor; antes, ela se funda na relação diversa dessa causa da dor
com o apetite.

RESPOSTA À SEGUNDA. — A tristeza interior não procede da semelhança da coisa apreendida, como de
causa. Pois o homem não se contrista, internamente, com a semelhança da coisa apreendida, mas com a
coisa mesma, de que apreende o símile. E essa coisa é tanto mais perfeitamente apreendida, pela sua
similitude, quanto mais imaterial e abstrata for esta. E portanto, a dor interna, em si mesma
considerada, é maior, como causada por um maior mal existente, pois o mal é mais conhecido pela
apreensão interna.

RESPOSTA À TERCEIRA. — As imutações corpóreas são causadas sobretudo pela dor externa, quer por
ser a causa dela um princípio de corrupção anexo ao corpo, que implica a apreensão do tato; quer
também por ser o sentido externo mais corpóreo que o interno, assim como o apetite sensitivo o é mais
que o intelectivo. E por isso, como já antes dissemos, é sobretudo pelo movimento do apetite sensitivo
que o corpo sofre imutação; e semelhantemente, mais pela dor externa do que pela interna.

## Art. 8 — Se Damasceno assinala convenientemente quatro espécies de tristeza, a saber: a acedia, a ansiedade, a misericórdia e a inveja.
(Infra, q. 41, ad 1; III Sent., dist. XXVI, q. 1, a . 3; De Verit., q. 26, a . 4, ad 6).
O oitavo discute-se assim. — Parece que Damasceno assinala inconvenientemente quatro espécies de
tristeza: a acédia, a opressão ou ansiedade, segundo Gregório Nisseno (Nemésio), a misericórdia e
a inveja.

1. Demais. — A tristeza se opõe à deleitação. Ora, desta não existem espécies. Logo, também não as
devemos atribuir àquela.

2. Demais — A penitência é uma espécie de tristeza, bem como a némese e o zelo, como diz o Filósofo.
Ora, estas não estão compreendidas nas espécies supra-nomeadas. Logo, a divisão supra-referida é
insuficiente.

3. Demais — Toda divisão deve ser feita por oposições. Ora, entre os termos supra-referidos não há
oposição mútua; pois, segundo Gregório Nisseno (Nemésio), a acédia é a tristeza que embarga a voz; a
ansiedade a que a torna pesada; a inveja é a tristeza causada pelos bens alheios, a misericórdia, por fim,
é a provocada pelos males alheios. Às vezes, na verdade, contristamo-nos com os bens ou males alheios
e ao mesmo tempo a voz interior se torna pesada, e a perdemos, a exterior. Logo, a divisão sobre-
referida não é conveniente.
Mas, em contrário, estão as autoridades de ambos — Gregório Nisseno (Nemésio) e Damasceno.

SOLUÇÃO. — A espécie, pela sua noção mesma, há-se de adicionar ao gênero. Ora, de dois modos pode
haver adição ao gênero. De um modo, do que em si mesmo lhe pertence e está virtualmente nele
contido; assim,racional se acrescenta a animal. E esta adição introduz verdadeiras espécies num
determinado gênero, como se vê no Filósofo. Pode porém adicionar-se a um gênero o que lhe é quase
estranho à noção; assim, branco, ou qualquer atributo semelhante, a animal. E esta adição não introduz
verdadeiras espécies no gênero, no sentido em que comumente falamos dos gêneros e das espécies. Às
vezes, porém dizemos que uma atribuição é espécie de um gênero, por ter algo de estranho a que se
aplica a noção de gênero; assim, do carvão e da chama dizemos serem espécies do fogo, por causa da
aplicação da natureza do fogo a certa matéria estranha. E pelo mesmo modo de falar, a astrologia e a
perspectiva se consideram espécie da matemática, na medida em que os princípios matemáticos se
aplicam à matéria natural.
E segundo este modo de exprimir é que se assinalam aqui as espécies de tristeza, aplicando-se-lhe a
noção a um elemento estranho, que pode ser tomado relativamente à causa do objeto ou ao efeito. —
Ora, o objeto próprio da tristeza é o mal próprio. Por onde, o objeto estranho à mesma pode ser
considerado ou quanto a um só desses elementos, que será então o mal, mas não próprio; assim,
a misericórdia é a tristeza causada pelo bem alheio, considerado contudo como próprio. Ou quanto a
ambos, porque não se refere então nem ao que é próprio nem ao que é mal, mas, ao bem alheio,
considerado, contudo como mal próprio; e tal é ainveja. — E quanto ao efeito próprio da tristeza,
consiste numa certa aversão do apetite. Por onde, o que é estranho, em relação ao efeito da tristeza,
pode ser considerado só relativamente a um dos elementos, ficando eliminada a aversão; e tal é
a ansiedade, que agrava o ânimo de modo a não deixar nenhum refúgio, e por isso recebe também a
denominação de angústia. Se porém esse gravame chegar ao ponto de imobilizar os membros exteriores
e impedi-los de agir, isso constituirá a acédia, e então o que é estranho será relativo a ambos os
elementos, por não ser nem aversão nem pertencer ao apetite. E por isso, e mais essencialmente, se diz
que a acedia trava a voz, porque esta é, de todos os movimentos exteriores, o que exprime sobretudo o
conceito interior e o afeto, não só nos homens mas também nos brutos, como diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A deleitação é causada pelo bem, considerado num
determinado sentido. E portanto, não se lhe atribuem tantas espécies como as da tristeza, causada pelo
mal, e que pode existir de muitos modos, como diz Dionísio.

RESPOSTA À SEGUNDA. — A penitência relativa ao mal próprio, em si mesmo objeto da tristeza. E por
isso não pertence às espécies em questão. — Por outro lado, o zelo e a némese estão contidas na inveja,
como a seguir se dirá.

RESPOSTA À TERCEIRA. — A divisão de que tratamos não é fundada nas oposições das espécies, mas na
diversidade dos elementos estranhos, a que se prende a noção de tristeza, como dissemos.