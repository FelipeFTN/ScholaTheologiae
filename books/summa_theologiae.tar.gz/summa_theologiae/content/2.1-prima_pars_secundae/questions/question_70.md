# Questão 70: Dos frutos do Espírito Santo.
Em seguida devemos tratar dos frutos.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se os frutos do Espírito Santo, enumerados pelo Apóstolo em Galat. V, são atos.
(Ad Galat., cap. V, lect VI).
O primeiro discute-se assim. — Parece que os frutos do Espírito Santo, enumerados pelo Apóstolo,
não são atos.

1. — Pois, o que produz fruto não deve ser considerado como tal, porque então iríamos ao infinito. Ora,
há um fruto proveniente dos nossos atos, conforme aquilo da Escritura (Sb 3, 15): o fruto dos bons
trabalhos é glorioso; e ainda (Jo 4, 36): o que sega recebe galardão e ajunta fruto para a vida eterna.
Logo, os nossos atos não podem, em si mesmos ser considerados frutos.

2. Demais. — Como diz Agostinho, gozamos como os objetos conhecidos, como os quais a própria
vontade se compraz e neles descansa. Ora, a nossa vontade não deve descansar nos nossos atos em si
mesmos considerados. Logo, estes não devem ser considerados frutos.

3. Demais. — Entre os frutos do Espírito Santo são enumeradas pelo Apóstolo certas virtudes, a saber, a
caridade, a mansidão, a fé e a castidade. Ora, as virtudes não são atos, mas hábitos, como já dissemos.
Logo, os frutos não são atos.
Mas, em contrário, diz a Escritura (Mt 12, 33): pelo fruto é que a árvore se conhece, i. é, o homem, pelas
suas obras, como o expõem os Santos Doutores. Logo, os atos humanos em si mesmos chama-se frutos.

SOLUÇÃO. — O nome fruto foi transferido das coisas corpóreas para as espirituais. Ora, corporalmente
falando, fruto é o produzido pela planta chegada ao seu pleno desenvolvimento, e traz em si uma certa
suavidade. E fruto, neste sentido, mantém dupla relação: com a árvore produtora e com a pessoa que
dela o colhe. Por onde, neste duplo sentido também esse nome pode ser espiritualmente considerado;
primeiro, denominando fruto do homem o que ele produz como se fosse uma árvore; e depois, assim
chamando o que o homem colhe.
Mas, nem tudo o que ele colhe pode ser considerado fruto, senão só o que é último e inclui em si a
deleitação. Pois, pode o homem possuir um campo ou uma árvore, que não se consideram frutos, senão
só o que ele entende colher deles, como resultado último. E neste sentido chama-se fruto do homem ao
seu último fim, do qual ele deve fruir.
Se porém considerarmos fruto do homem o que ele produz, então frutos se consideram os seus atos,
em si mesmos. Pois, a obra é um ato segundo de quem obra, e traz consigo o prazer, se mantiver
conveniência com o seu autor. Se pois o ato proceder da faculdade racional do homem, será chamado
fruto da razão. Se porém proceder do homem por uma virtude mais alta, a do Espírito Santo, então,
chamar-se-á ao ato do homem fruto do Espírito Santo, procedente de uma quase semente divina,
conforme àquilo da Escritura (1 Jo 3, 9):Todo o que é nascido de Deus não comete o pecado, porque a
semente de Deus permanece nele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como o fruto é, de certo modo, o que vem em último
lugar e é o fim, nada impede haver fruto de outro fruto, assim como um fim pode se ordenar a outro.
Assim pois as nossas obras, enquanto certos efeitos do Espírito Santo, que obra em nós, podem ser
consideradas frutos; mas enquanto ordenadas ao fim da vida eterna, são antes flores. Por isso, diz a
Escritura (Ecle 24, 23): as minhas flores são frutos de honra e de honestidade.

RESPOSTA À SEGUNDA. — De dois modos podemos entender que a vontade se deleita com um objeto,
em si mesmo considerado. A expressão — em si mesmo ou exprime a causa final, e então ninguém se
deleita a não ser com o último fim; ou a causa formal, e então podemos nos deleitar em tudo o que é
formalmente deleitável. Assim, um enfermo se compraz com a saúde em si mesma considerada, como
fim; com um remédio suave, não como fim, mas como com o que tem sabor deleitável; e com um
remédio desagradável só por causa de outro fim e, de nenhum modo em si mesmo. — Por onde,
devemos concluir que o homem deve se deleitar em Deus, em si mesmo, como último fim; e com os
atos virtuosos, não como fins, mas por causa da honestidade que contém, agradável aos virtuosos. Por
isso Ambrósio diz, que os atos virtuosos se chamam frutos, porque com santa e pura deleitação
confortam os que os praticam.

RESPOSTA À TERCEIRA. — Os nomes das virtudes são às vezes tomados, pelos atos das mesmas; assim,
como diz Agostinho, a fé consiste em crer o que não vês; e a caridade é o movimento da alma para amar
a Deus e ao próximo. E deste modo são aplicados os nomes das virtudes, na enumeração dos frutos.

## Art. 2 — Se os frutos diferem das bemaventuranças.
(Ad Galat., cap. V, lect. VI; In Isaiam, cap. XI).
O segundo discute-se assim. — Parece que os frutos não diferem das bem-aventuranças.

1. — As bem-aventuranças se atribuem aos dons, como já se disse. Ora, os dons aperfeiçoam o homem,
movido pelo Espírito Santo. Logo, as próprias bem-aventuranças são frutos do Espírito Santo.

2. Demais. — O fruto da vida eterna está para a bem-aventurança futura, que é a da posse, assim como
o da vida presente para as bem-aventuranças da vida atual, que são esperadas. Ora, o fruto da vida
eterna é a mesma bem-aventurança futura. Logo, os da vida presente são as bem-aventuranças
mesmas.

3. Demais. — É da essência do fruto ser algo de último e deleitável. Ora, isto é também da essência da
bem-aventurança, como já se disse. Logo, fruto e bem-aventurança têm a mesma essência, e portanto
não devem ser distintos entre si.
Mas, em contrário. — Onde há espécies diversas há sujeitos diversos. Ora, os frutos e as
bemaventuranças dividem-se em partes diversas, como a enumeração daqueles e destes claramente o
mostra. Logo, os frutos diferem das bemaventuranças.

SOLUÇÃO. — A noção de bem-aventurança tem compreensão maior que a de fruto. Pois, para a deste
basta que venha por último e seja deleitável; ao passo que aquela exige, ulteriormente, a perfeição e a
excelência. Por onde, todas as bem-aventuranças podem ser consideradas frutos, mas não
inversamente. Assim, são frutos todas as obras virtuosas com que nos deleitamos; ao passo que são
bem-aventuranças só as obras perfeitas que também, em razão mesma da sua perfeição, se atribuem
mais aos dons que às virtudes, como já se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção prova que as bem-aventuranças são frutos,
não porém que todos os frutos sejam bem-aventuranças.

RESPOSTA À SEGUNDA. — O fruto da vida eterna é último e perfeito, absolutamente, e portanto em
nada se distingue da futura bem-aventurança. Os frutos da vida presente, porém, não são últimos e
perfeitos, absolutamente; e portanto, nem todos os frutos são bem-aventuranças.

RESPOSTA À TERCEIRA. — A bem-aventurança tem, por essência, algo mais que a essência do fruto,
como se disse.

## Art. 3 — Se o Apóstolo enumera convenientemente os doze frutos.
(III Sent., dist. XXXIV, q. 1, a. 5; Ad Galat., cap. V. Lect VI).
O terceiro discute-se assim. — Parece que o Apóstolo enumera inconvenientemente, os doze frutos.

1. — Pois, noutro lugar, diz que só há um fruto da vida presente (Rm 6, 22): tendes o vosso fruto em
santificação. E noutra parte se diz (Is 27, 9): todo este fruto se reduz a que seja tirado o seu pecado.
Logo, não se devem enumerar doze frutos.

2. Demais. — O fruto nasce da semente espiritual, como já se disse. Ora, o Senhor enumera um tríplice
fruto da terra boa nascido da semente espiritual: centésimo, sexagésimo e trigésimo. Logo, não se
devem enumerar doze frutos.

3. Demais. — O fruto, por essência, vem por último e é deleitável. Ora, isto não se verifica em todos os
frutos enumerados pelo Apóstolo; assim a paciência e a longanimidade supõem o que causa pena; e por
outro lado, a fé não vem por último, mas antes é, por essência, o fundamento primeiro. Logo, a
enumeração dos frutos, em questão peca por excesso.
Mas, em contrário. — Parece que a enumeração é insuficiente e deficiente. Pois, como já se disse, todas
as bemaventuranças podem se chamar frutos. Ora, a enumeração não as abrange a todas, pois nada
compreende pertinente ao ato da sabedoria e de muitas outras virtudes. Logo, essa enumeração dos
frutos é insuficiente.

SOLUÇÃO. — A enumeração dos doze frutos feita pelo Apóstolo é correta e podem eles ser expressos
pelos doze frutos de que fala a Escritura (Ap 22, 2): duma e de outra parte do rio, estava a árvore da
vida, que dá doze frutos. Como porém se chama fruto ao procedente de algum princípio, como de
princípio ou de raiz, a distinção dos frutos em questão deve-se fundar nos diversos modos por que
procedem em nós os frutos do Espírito Santo. Ora, essa processão implica, primeiro, que o coração
humano se ordene, em si mesmo; segundo, que se ordene para o que lhe está ao lado; terceiro, para o
que lhe é inferior.
Ora, o coração do homem fica, em si mesmo, bem disposto quando se comporta como deve tanto em
relação ao mal como ao bem. Ora, a primeira disposição da mente humana para o bem se opera pelo
amor, a primeira e a raiz de todos os afetos, como já dissemos. E por isso, o primeiro enumerado dos
frutos do Espírito Santo é a caridade, pela qual ele se dá em própria semelhança, sendo Amor; donde o
dizer o Apóstolo (Rm 5, 5): a caridade de Deus está derramada em nossos corações pelo Espírito Santo,
que nos foi dado. —Ora, do amor de caridade resulta necessariamente a alegria, pois todo amante se
alegra estando unido ao amado. Ora, a caridade tem sempre presente a Deus, a quem ama, segundo
aquilo da Escritura (1 Jo 4, 16):Aquele que permanece na caridade permanece em Deus e Deus, nele.
Logo, a conseqüência da caridade é a alegria. — Mas, a perfeição da alegria é a paz, de dois modos.
Primeiro, quanto à tranqüila libertação das perturbações exteriores; pois não pode gozar perfeitamente
do bem amado quem sofre perturbação exterior, no gozo do mesmo. E por isso o coração
perfeitamente pacificado num gozo, por nada pode ser molestado, pois considera tudo o mais como
quase não existente; por onde, diz a Escritura (Sl 118, 165): Gozam minha paz os que amam a tua lei, e
não há para ele tropeço, i. é, por não serem perturbados pelas causas exteriores, a ponto de não
gozarem de Deus. Segundo, quanto à satisfação do desejo volúvel, pois não gozamos suficientemente
quando não nos satisfaz o objeto do nosso gozo. Ora, ambos esses casos implicam a paz, de modo que
não sejamos perturbados pelas causas externas e descansemos os nossos desejos num só objeto. Por
onde, em terceiro lugar é enumerada a paz, depois da caridade e da alegria. — Por outro lado, o coração
se comporta como deve em relação ao mal, de dois modos. Não se perturbando com os males
eminentes, por meio da paciência. — Segundo, não se perturbando com a dilação dos bens, por meio
dalonganimidade; pois o estar privado do bem implica o mal, como se disse.
Em seguida, quanto ao que está ao nosso lado, i. é, quanto ao próximo, nosso coração se dispõe bem,
pelabondade, no atinente à vontade de bem fazer. — Segundo, pela benignidade, no que respeita à
execução da beneficência; pois, chamam-se benignos aqueles que a bondade ígnea do amor faz arder
no beneficiar ao próximo. — Terceiro, quanto a tolerar com equanimidade os males que o atingem, por
meio da mansidão, que coíbe a ira. — Quarto, não só não fazendo mal ao próximo, pela ira, mas nem
pela fraude ou pelo dolo. E isto o conseguimos pela fé, tomada em sentido de fidelidade; mas
considerada como crença em Deus, ela nos ordena ao que nos é superior, fazendo-nos sujeitar o
intelecto a Deus, e por conseqüência tudo o que possui.
Enfim, em relação ao que nos é inferior bem nos dispomos: primeiro, quanto aos atos externos,
pelamodéstia, observando o comedimento em tudo o que dizemos e fazemos. — Quanto à
concupiscência interna, pela continência e pela castidade, distinguindo-se uma da outra, porque esta
nos priva do ilícito e aquela, do lícito; quer, porque o continente sofre a concupiscência sem ser por ela
vencida, ao passo que o casto nem a sofre nem é por ela vencido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A santificação se opera por todas as virtudes que
também purificam os pecados. Por isso os lugares aduzidos nomeiam o fruto na sua unidade genérica;
Mas ele se divide em muitas espécies, e isso faz considerarmos muitos frutos.

RESPOSTA À SEGUNDA. — Os frutos centésimo, sexagésimo e trigésimo não se diversificam pelas
diversas espécies de atos virtuosos, mas pelos diversos graus de perfeição, mesmo de uma virtude.
Assim se diz que a continência conjugal está expressa no fruto trigésimo; a da viuvez, no sexagésimo; e a
virginal, no centésimo. E ainda de outros modos, os Santos Doutores distinguem três frutos evangélicos
relativos aos três graus das virtudes; sendo esses três graus relativos à perfeição de todas as coisas, que
se funda no princípio, no meio e no fim. REPOSTA À TERCEIRA.— O mesmo não se perturbar nas
tristezas implica o prazer. E a fé, mesmo considerada como fundamento, é algo de último e deleitável,
por incluir a certeza. Por isso a Glosa expõe: A fé, i. é, a certeza do invisível.

RESPOSTA À QUARTA. — Como diz Agostinho, o Apóstolo, no lugar aduzido não quis, ensinar quais são
as obras da carne ou os frutos do Espírito Santo, senão mostrar em que gênero aquelas devem ser
evitadas e estes, buscados. Por onde mais ou menos frutos podiam ter sido enumerados. E contudo,
todos os atos dos dons e das virtudes podem, com certa conveniência, ser reduzidos aos enumerados,
enquanto todas as virtudes e dons hão de, necessariamente, ordenar o coração de algum dos modos
preditos. Assim, os atos da sabedoria e de qualquer dos dons, que ordenam para o bem se reduzem à
caridade, à alegria e à paz. Mas o Apóstolo preferiu esta enumeração à outra, por implicar o que ela
abrange a fruição dos bens ou a quietação dos males, o que está incluído na essência do fruto.

## Art. 4 — Se os frutos do Espírito Santo contrariam as obras da carne, que o Apóstolo enumera.
(Ad. Galat., cap. V. Lect VI).
O quarto discute-se assim. — Parece que os frutos do Espírito Santo não contrariam as obras da carne,
que o Apóstolo enumera.

1. — Pois, os contrários pertencem ao mesmo gênero. Ora, as obras da carne não se chamam frutos.
Logo, os frutos do Espírito Santo não as contrariam.

2. Demais. — A unidade é contrária à unidade. Ora, o Apóstolo enumera mais obras da carne que frutos
do Espírito Santo. Logo, os frutos do Espírito e as obras da carne não se contrariam.

3. Demais. — Entre os frutos do Espírito Santo enumera-se em primeiro lugar a caridade, a alegria e a
paz, a que não correspondem as obras da carne enumeradas em primeiro lugar, a saber, a fornicação, a
imundícia e a impudicícia. Logo, os frutos do Espírito Santo não contrariam as obras da carne.
Mas, em contrário, o Apóstolo diz no mesmo lugar (Gl 5, 17): a carne deseja contra o espírito e o espírito
contra a carne.

SOLUÇÃO. — As obras da carne e os frutos do Espírito Santo podem ser considerados em dois sentidos.
— Primeiro, de um modo geral, e então os frutos do Espírito Santo são contrários às obras da carne.
Pois, o Espírito Santo move o coração humano ao que é racional, ou antes, supra-racional; ao passo que
o apetite da carne que é sensitivo, arrasta para os bens sensíveis, inferiores ao homem. Por onde, assim
como os movimentos para cima e para baixo são contrários, na ordem da natureza, assim, nas obras
humanas, as obras da carne são contrárias aos frutos do Espírito.
De outro modo, podemos considerar os frutos enumerados e as obras da carne, em particular. E assim,
não é necessário que cada um daqueles se contraponha a cada uma destas; pois, como já se disse, o
Apóstolo não pretende enumerar todas as obras espirituais nem todas as carnais. — Contudo, fazendo
uma certa adaptação, Agostinho contrapõe a cada obra, cada fruto. Assim, à fornicação, que é o amor
pela satisfação da sensualidade fora do legítimo conúbio, opõe-se a caridade pela qual a alma se une
com Deus, na qual também consiste a verdadeira castidade. As imundícias que são perturbações
oriundas da fornicação, opõe-se a alegria da tranqüilidade. A servidão dos ídolos, que faz guerra contra
o Evangelho de Deus, opõe-se à paz. Aos venefícios, inimizades e contenções, animosidades, emulações
e dissenções opõem-se: a longanimidade, para suportar os males dos homens entre os quais vivemos; a
benignidade, para curá-los; a bondade, para perdoá-los. Às heresias se opõe a fé; à inveja, a mansidão; à
embriaguez e à intemperança no comer, a continência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O procedente da árvore, contra a natureza da mesma,
não se lhe considera fruto, mas corrupção. Ora, como as obras virtuosas são conaturais, e as viciosas,
contrárias à razão, as primeiras se chamam frutos, e não as segundas.

RESPOSTA À TERCEIRA. — O bem só existe de um modo, e o mal de muitos, como diz Dionísio. Por isso,
a uma mesma virtude se opõem muitos vícios; não sendo pois, de admirar se se enumeram mais obras
da carne do que frutos do Espírito Santo.

RESPOSTA À QUARTA. — Resulta clara do que foi dito.
Tratado dos vícios e pecados