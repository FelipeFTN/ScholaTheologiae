# Questão 11: Da fruição.
Em seguida devemos tratar da fruição.
E, nesta Questão quatro artigos se discutem:

## Art. 1 — Se fruir é próprio só da potência apetitiva.
(I Sent., dist. I, q. 1, a . 1).
O primeiro discute-se assim. ― Parece que fruir não é próprio só da potência apetitiva.

1. ― Pois, fruir não é senão colher o fruto. Ora, o fruto da vida humana, que é a beatitude, colhe-o o
intelecto, em cujo ato consiste a felicidade, como já se demonstrou. Logo, fruir não é próprio da
potência apetitiva, mas do intelecto.

2. Demais. ― Toda potência tem um fim próprio, que é a sua perfeição; pois, o fim da visão é conhecer o
visível, o da audição, perceber os sons e assim por diante. Ora, o fim de uma coisa é o seu fruto. Logo,
fruir é próprio de todas as potências e não só da apetitiva.

3. Demais. ― A fruição importa num certo deleite. Ora, o deleite sensível pertence ao sentido, que se
compras no seu objeto; e pela mesma razão o deleite intelectual pertence ao intelecto. Logo, a fruição
pertence à potência apreensiva e não à apetitiva.
Mas, em contrário, diz Agostinho: Fruir é aderir por amor, a alguma coisa, em si mesma. Ora, o amor
respeita à potência apetitiva. Logo, também fruir é ato dessa potência.

SOLUÇÃO. ― Fruição e fruto respeitam, segundo parece, a uma mesma realidade, e um deriva do outro.
Qual seja o derivado, não vem ao caso, senão que, como parece provável, o mais manifesto também foi
primeiro denominado. Ora, sendo-nos as coisas mais sensíveis as mais manifestas, o nome de fruição
parece derivado dos frutos materiais. Ora, o fruto material é o que por último esperamos da árvore e o
que colhemos com certa suavidade. Por onde, a fruição parece pertencer ao amor ou deleite que
sentimos ante o termo da nossa expectativa, que é o fim. Ora, o fim e o bem é o objeto da potência
apetitiva. Logo, é manifesto ser a fruição ato dessa potência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede que a uma só e mesma realidade se
refiram diversas potências, sob diversos pontos de vista. Assim, a visão de Deus como tal é ato do
intelecto; mas como bem e fim é objeto da vontade e podemos desse modo gozá-lo. De maneira que o
intelecto, como potência agente, alcança esse fim; ao passo que a vontade o alcança como potência que
move para o fim e deste goza, quando já obtido.

RESPOSTA À SEGUNDA. ― Como já se disse, a perfeição e o fim de cada uma das outras potências estão
contidos no objeto da potência apetitiva, como o próprio está contido no comum. Por onde, a perfeição
e o fim de qualquer potência, como bem particular, pertence à potência apetitiva; e por isso esta move
as outras aos fins próprios e, conseguindo o seu fim, ajuda também as outras a conseguirem os seus.

RESPOSTA À TERCEIRA. ― Dois elementos há na deleitação: a percepção do conveniente, própria da
potência apreensiva; e a complacência no que se apresenta como conveniente, própria da potência
apetitiva e em que a deleitação encontra a sua plenitude.

## Art. 2 — se fruir é próprio só do homem.
(I Sent., dist. I, q. 4, a 1).
O segundo discute-se assim. ― Parece que fruir é próprio só do homem.

1. ― Pois, diz Agostinho, os homens somos os que fruímos e utilizamos. Logo, os brutos não podem
fruir.

2. Demais. ― Fruímos do fim último. Ora, este não podem conseguir os brutos. Logo, não podem fruir.

3. Demais. ― Assim como o apetite sensitivo está sujeito ao intelectivo, assim o apetite natural, ao
sensitivo. Ora, se fruir pertence ao apetite sensitivo, parece que, pela mesma razão, pode pertencer ao
natural, o que é evidentemente falso, pois, este não pode fruir. Logo, também não o pode o sensitivo, e
portanto não é próprio dos brutos fruir.
Mas, em contrário, diz Agostinho: não é absurdo pensar que também os brutos fruem do alimento e de
qualquer outro prazer corpóreo.

SOLUÇÃO. ― Como resulta do que já foi estabelecido, fruir não é ato da potência que chega ao fim,
executando-o; mas da que impera a execução, pois, conforme já se disse, tal é próprio da potência
apetitiva. Ora, nos seres privados de conhecimento, há, certo, a potência que alcança o fim, como
executora; assim, o grave tende para baixo e o leve, para cima. Mas a potência que visa o fim, como
imperativa, não reside neles, mas nalguma natureza superior. E esta move toda a natureza pelo seu
império, assim como, nos seres que têm conhecimento, o apetite move as outras potências para os atos
delas. Logo, é manifesto que os seres privados de conhecimento, embora cheguem ao fim, não podem
contudo fruir dele, como o podem só os que têm conhecimento. O conhecimento do fim é porém duplo:
o perfeito e o imperfeito. Pelo perfeito, conhecemos não só o fim e o bem, mas a idéia universal do bem
e do fim; e tal conhecimento é próprio só da natureza racional. Pelo imperfeito, conhecemos
particularmente o fim e o bem e tal conhecimento também existe nos brutos, cujas virtudes apetitivas
não imperam livremente, mas são movidas ao que apreendem por um instinto natural. Por onde, à
natureza racional convém a fruição na acepção perfeita; aos brutos, na imperfeita e, às demais criaturas,
de nenhum modo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho se refere à fruição perfeita.

RESPOSTA À SEGUNDA. ― Não é necessário que a fruição se refira ao último fim, absolutamente; mas
ao que cada um considera como tal.

RESPOSTA À TERCEIRA. ― O apetite sensitivo resulta de algum conhecimento; não, porém, o apetite
natural, sobretudo enquanto existente nos seres carecentes de razão.

RESPOSTA À QUARTA. ― No passo aduzido, — Agostinho se refere à fruição imperfeita, como resulta
do modo mesmo por que se expressa; pois, diz, não é absurdo pensar que também os brutos fruem,
como não o seria dizer que usam.

## Art. 3 — Se há fruição só do último fim.
(I Sent., dist. I, q. 2, a . 1; Ad Philem., lect II).
O terceiro discute-se assim. ― Parece que não é só do último fim que há fruição.

1. ― Pois, diz o Apóstolo (Fm 1, 20): Sim, irmão. Eu me gozarei de ti no Senhor. Ora, é manifesto que
Paulo não colocou o seu último fim no homem. Logo, não é só do último fim que se frui.

2. Demais. ― Fruto é o que se frui. Ora, diz o Apóstolo (Gl 5, 22): O fruto do espírito é a caridade, o gozo,
a paz e coisas semelhantes, que não têm natureza de último fim. Logo, não é só deste que há fruição.

3. Demais. ― Os atos da vontade refletem-se sobre si mesmos, pois queremos o querer e amamos o
amar. Ora, fruir é ato da vontade, pois, como diz Agostinho, com a vontade fruímos. Logo, fruímos da
nossa fruição. E não sendo esta o fim último do homem, senão o bem incriado, que é Deus, não é
portanto a fruição só do último fim.
Mas, em contrário, diz Agostinho: Não fruímos quando queremos algo, por causa de outra coisa. Ora, só
o fim último não é desejado por causa de nada. Logo, só dele há fruição.

SOLUÇÃO. ― Como já se disse, a idéia de fruto compreende dois elementos: ser último e aquietar o
apetite, com certa doçura e deleitação. Ora, o que é último pode sê-lo absoluta ou relativamente:
absolutamente se não se refere a outra coisa; relativamente, se se refere a certas coisas. Ora, chama-se
propriamente fruto, do qual fruímos em sentido próprio, aquilo que é absolutamente último, com que
nos deleitamos a título de fim derradeiro. ― Mas de nenhum modo pode chamar-se fruto ao que não é
deleitável em si mesmo, mas desejado somente em dependência de outra coisa; assim uma poção
amarga, desejada por causa da saúde. ― Ao que porém traz consigo uma certa deleitação, à qual se
referem realidades precedentes, podemos de algum modo chamar fruto; mas disso não fruímos,
segundo a idéia própria e completa de fruto. Por onde, diz Agostinho: fruímos das coisas conhecidas nas
quais descansa a vontade, com delícias. Ora, absolutamente, ela não descansa senão no fim último, pois
enquanto está na expectativa de alguma coisa, o movimento da vontade fica suspenso, embora já tenha
chegado a um termo. Assim, no movimento local, embora o meio do caminho seja princípio e fim, não é
contudo considerado como fim atual senão quando nele repousamos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como pondera Agostinho, se o Apóstolo tivesse dito
― Eu me gozarei de ti ― e não acrescentasse ― no Senhor ― teria posto aí o fim da deleitação; mas
fazendo o acréscimo referido, significou que pôs o fim no Senhor e dele fruiu; como se dissesse que
fruiu do irmão, não a título de termo, mas de meio.

RESPOSTA À SEGUNDA. ― O fruto se refere, de um modo, à arvore que o produz e, de outro, ao
homem que o goza. Àquela, como o efeito se refere à causa; a este, como último esperado deleitável.
Ora, às coisas enumeradas pelo Apóstolo, no passo aduzido, chamam-se frutos porque são certos
efeitos do Espírito Santo em nós, sendo por isso denominados frutos do Espírito Santo; não porém que
delas fruamos a título de fim último. ― Ou, de outro modo, chamam-se frutos, segundo Ambrósio,
porque são buscados por si mesmos, não certo por não se referirem à beatitude, mas por terem em si
mesmos a razão de nos agradarem.

RESPOSTA À TERCEIRA. ― Como já se disse antes, fim significa, de um modo, a coisa mesma e, de outro,
a aquisição dela. Não há aí porém dois fins, mas um só, considerado em si mesmo e aplicado a outro.
Ora, Deus é o último fim como a realidade que é buscada por último; e é fruição, como posse do fim
último. Assim, pois, como Deus não é fim diferente da fruição dele, assim pela mesma idéia de fruição
fruímos de Deus e da fruição divina. E o mesmo se dá com a beatitude criada, que consiste na fruição.

## Art. 4 — Se a fruição é só do bem possuído.
O quarto discute-se assim. ― Parece que a fruição não é só do bem possuído.

1. ― Pois, diz Agostinho: Fruir é usar, com gáudio, não já da esperança, mas da coisa mesma. Ora, da
coisa ainda não possuída não há gáudio, mas esperança. Logo, fruição é só do fim possuído.

2. Demais. ― Como já se disse, a fruição, propriamente, só é do último fim; pois só este aquieta o
apetite. Ora, o apetite só se satisfaz com o fim já possuído. Logo, a fruição, propriamente falando, só é
do fim último.

3. Demais. ― Fruir é colher o fruto. Ora, este só é colhido quando já está possuído o fim. Logo, só há
fruição do bem possuído.
Mas, em contrário. ― Fruir é aderir, por amor, a uma coisa, por ela mesma, como diz Agostinho. Ora,
isto pode se dar mesmo com uma coisa não possuída. Logo, podemos fruir mesmo do fim ainda não
possuído.

SOLUÇÃO. ― Fruir importa relação da vontade com o fim último, enquanto que ela considera alguma
coisa como tal fim. Ora, o fim último pode ser possuído de duplo modo: perfeita e imperfeitamente.
Perfeitamente, quando possuído, não só intencional mas também realmente; imperfeitamente quando
possuído só na intenção. Logo, a fruição perfeita é a do fim já realmente possuído; ao passo que a
imperfeita é a do fim não real mas só intencionalmente possuído.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho se refere à fruição perfeita.

RESPOSTA À SEGUNDA. ― De duplo modo fica impedido o repouso da vontade: quanto ao objeto, que
não sendo o fim último, ordena-se a outro fim; ou quanto ao que deseja o fim, mas ainda não o
alcançou. Ora, ao passo que o objeto especifica o ato, do agente depende o modo de agir, que,
conforme a sua condição é perfeito ou imperfeito. Por onde, do fim que não é último, a fruição é
imprópria, como deficiente relativamente à idéia de fruição. Do fim último, porém, embora não ainda
possuído, a fruição é própria, mas imperfeita, por causa do modo imperfeito de conseguir esse fim.

RESPOSTA À TERCEIRA. ― Diz-se que alguém alcança ou possui o fim, não só real mas também
intencionalmente, como se viu.