# Questão 21: Das conseqüências dos atos humanos em razão da bondade
ou da malícia deles.
Em seguida devemos tratar das conseqüências dos atos humanos em razão da bondade ou da malícia
deles.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se o ato humano, por ser bom ou mau, implica a noção de retitude ou de pecado.
O primeiro discute-se assim. ― Parece que o ato humano, por ser bom ou mau, não implica a noção
de retitude ou de pecado.

1. ― Pois, os monstros são pecados da natureza, como diz Aristóteles. Ora, eles não são atos, mas seres
gerados contra a ordem da natureza. Ora, as produções da arte e da razão imitam as coisas da natureza,
conforme no mesmo passo se diz. Logo, um ato, por ser desordenado e mau, não implica a noção de
pecado.

2. Demais. ― Como diz Aristóteles, de pecado é susceptível tanto a natureza como a arte, quando não
chegam ao fim visado. Ora, a bondade e a malícia de um ato humano consistem sobretudo no fim
intencional e na sua prossecução. Logo, a malícia de um ato não implica a noção de pecado.

3. Demais. ― Se a malícia do ato implicasse a noção de pecado, onde quer que houvesse mal haveria
pecado. Ora, isto é falso, pois a pena, embora implique a noção de mal, não implica a de pecado. Logo,
não é por ser mau que um ato implica tal noção.
Mas, em contrário. ― A bondade de um ato humano, como já se demonstrou, depende principalmente
da lei eterna; e por conseqüência, a sua malícia consiste em discordar dessa lei. Ora, isto induz a noção
de pecado, como diz Agostinho: pecado é um dito, ato ou desejo contrário à lei eterna. Logo, o ato
humano, por ser mau, implica a noção de pecado.

SOLUÇÃO. ― O mal é mais que o pecado e o bem, que a retitude, pois, embora qualquer privação do
bem constitua sempre pecado, este em sentido próprio consiste num ato praticado em vista de um fim
e que não conserva, para com ele a ordem devida. Ora, a ordem devida para com um fim é medida por
uma determinada regra, que é, para os seres que agem conforme à natureza, a virtude mesma desta
que inclina para o fim. Por onde, é reto o ato que procede da virtude natural, de conformidade com a
inclinação natural para o fim; porque o meio não se afasta dos extremos, i. é, o ato, da ordenação do
princípio ativo ao fim. O ato que se afasta porém de tal retitude, induz a idéia de pecado.
Mas os seres que agem por vontade tem como regra próxima a razão humana, e como suprema, a lei
eterna. Por onde, sempre que um ato o homem o pratica em vista de um fim, conforme à ordem da
razão e da lei eterna, é reto; quando porém se afasta dessa retidão considera-se pecado. Ora, é claro
pelo que já dissemos, que todo ato voluntário é mau, que se afasta da ordem da razão e da lei eterna;
ao passo que todo ato bom concorda com ambas essas ordens. Donde se colhe que o ato humano, por
ser bom ou mau, implica a idéia de retitude ou de pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Diz-se que os monstros são pecados por serem o
resultado de um pecado inerente ao ato da natureza.

RESPOSTA À SEGUNDA. ― Há duplo fim: o último e o próximo. Ora, no pecado da natureza, o ato é
falho em relação ao fim último, que é a perfeição do ser produzido; não o é porém em relação a
qualquer fim próximo, pois por ele a natureza chega a produzir certos efeitos. Semelhantemente, no
pecado da vontade há sempre deficiência em relação ao fim último visado, pois nenhum ato mau da
vontade pode ordenar-se à beatitude, fim último; mas não há deficiência em relação a algum fim
próximo, que a vontade visa e consegue. E por isso, como a intenção posta nesse fim se ordena ao fim
último, mesmo ela pode induzir a idéia de retitude e de pecado.

RESPOSTA À TERCEIRA. ― Tudo se ordena ao fim por meio de um ato; por isso a natureza do pecado,
que consiste no desviar-se da ordem final, consiste propriamente em um ato; ao passo que a pena diz
respeito a pessoa que peca, como na primeira parte se disse.

## Art. 2 — Se o ato humano, por ser bom ou mau, é digno de louvor ou de culpa.
O segundo discute-se assim. ― Parece que o ato humano, por ser bom ou mau, não é digno de louvor
ou de culpa.

1. ― Pois, há pecado mesmo nos fenômenos da natureza, como diz Aristóteles. Ora, não se lhes atribui
nem o louvor nem a culpa, como se vê ainda em Aristóteles. Logo, por ser mau ou pecado, um ato
humano não é culposo; e por conseqüência nem é digno de louvor por ser bom.

2. Demais. ― O pecado existe nos atos morais assim como nos da arte; pois, como diz Aristóteles, peca
o gramático que não escreve bem e o médico que não dá o remédio conveniente. Entretanto, não é
inculpado o artista por ter feito mal alguma coisa, porque tem a faculdade de fazer tanto uma obra boa
como outra, má. Logo, também o ato moral, por ser mau, não é digno de culpa.

3. Demais. ― Dionísio diz, que o mal implica debilidade e impotência. Ora, uma e outra elimina ou
diminui a culpa. Logo, não é por ser mau que um ato humano é digno de culpa.
Mas, em contrário, diz o Filósofo, que dignas de louvor são as obras das virtudes; dignas de vitupério ou
de culpa as obras contrárias. Ora, os atos bons são atos de virtude, pois esta torna bom quem a possui e
os atos que pratica bons; logo, os atos opostos são maus. Por onde, o ato humano, por ser bom ou mau,
é digno de louvor ou de culpa.

SOLUÇÃO. ― Assim como o mal é mais que o pecado, assim este é mais que a culpa. Pois, chama-se
culposo ou louvável o ato imputável a um agente; porquanto louvar ou inculpar não é mais do que
imputar a alguém a malícia ou a bondade do seu ato. Ora, só é imputado ao agente o ato sobre o qual
tem domínio, podendo praticá-lo ou não; e isto se dá com todos os atos voluntários, porque, pela
vontade, o homem exerce domínio sobre os seus atos, como do sobredito resulta. Donde se conclui que
o bem ou o mal dá razão para louvor ou culpa, só nos atos voluntários, nos quais se identificam o mal, o
pecado e a culpa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Sendo a natureza determinada, os atos naturais não
estão no poder do agente natural. Por onde, embora nesses atos possa haver pecado, não há contudo,
culpa.

RESPOSTA À SEGUNDA. ― Um é o papel da razão relativamente às coisas da arte e outro, relativamente
aos atos morais. No respeito à arte, a razão se ordena a um fim particular de que cogita; na moral
porém ordena-se ao fim comum de toda a vida humana; e o fim particular se ordena ao comum. Ora, o
pecado, desviando-se da ordem final, como já dissemos, de dois modos pode existir na produção da
arte. Primeiro, por haver desvio em relação ao fim particular visado intencionalmente pelo artista, e
este pecado é próprio da arte; assim, quando um artista, querendo fazer uma obra boa, fá-la má, ou
inversamente. Segundo, porque se desvia do fim comum da vida humana; então dizemos que peca
quem intencionalmente faz obra má, que induza outrem em engano; e este pecado não é próprio do
artista, como tal, mas como homem. Por onde, pelo primeiro pecado, o artista é inculpado como tal; no
segundo, é inculpado o homem, com tal. No domínio moral porém, onde a ordem da razão é relativa ao
fim comum da vida humana, o pecado e o mal implicam sempre um desvio dessa ordem, relativamente
ao fim comum da vida humana; por isso de tal pecado tem culpa o homem, como homem e como ser
moral. Donde o dizer o Filósofo, o que voluntariamente peca, na arte, é preferível ao que peca contra a
prudência e contra as virtudes morais, de que ela é diretriz.

RESPOSTA À TERCEIRA. ― A debilidade dos males voluntários cai sob o poder do homem; e portanto
não elimina nem diminui a culpa.

## Art. 3 — Se o ato humano, pela sua bondade ou malícia, é meritório ou demeritório.
O terceiro discute-se assim. ― Parece que o ato humano, pela sua bondade ou malícia, não é
meritório nem demeritório.

1. ― Pois, mérito e demérito se definem relativamente à retribuição, que só tem razão de ser no
referente a outrem. Ora, nem todos os atos humanos implicam tal referência, pois certos não dizem
respeito senão ao próprio indivíduo. Logo, nem todo ato humano bom ou mau é meritório ou
demeritório.

2. Demais. ― Ninguém merece pena ou prêmio por dispor do seu como quiser; assim, quem o destrói
não é punido, como sê-lo-ia se destruísse o alheio. Ora, o homem é senhor dos seus atos. Logo, deles
dispondo, bem ou mal, não merece pena nem prêmio.

3. Demais. ― Não é por fazer bem a si próprio que alguém merece que outrem também lho faça; e o
mesmo se diga do mal. Ora, o ato bom em si mesmo é um certo bem e perfeição do agente; e ao
contrário, mal lhe é o ato desordenado. Logo, por fazer o mal e o bem, o homem não merece nem
desmerece.
Mas, em contrário, diz a Escritura (Is 3, 10-11): Dizei ao justo que ele será bem sucedido, pois, comerá o
fruto dos seus conselhos. Ai do ímpio que corre ao mal; porque lhe será dada a retribuição das suas
mãos.

SOLUÇÃO. ― O mérito e o demérito se definem relativamente à retribuição feita conforme a justiça; e
esta se faz a quem age em benefício ou detrimento de outrem. Ora, devemos considerar que quem vive
em sociedade é de certo modo parte e membro de toda ela. Por onde, o bem ou o mal que fizer a outra
pessoa redundará em bem ou mal de toda a sociedade, assim como quem lesa a mão lesa por
conseqüência todo o homem. Portanto, quem age em benefício ou detrimento de uma pessoa singular
torna-se de duplo modo digno de mérito ou demérito, por lhe ser devida retribuição, primeiro, pela
pessoa singular beneficiada ou ofendida; segundo, por parte de toda a sociedade. Se porém ordenar o
seu ato diretamente para o bem ou mal de toda a sociedade, esta deve-lhe retribuição, primária e
principalmente; secundariamente, devem-na todas as suas partes. Por outro lado, se age para bem ou
mal de si mesmo, também retribuição lhe é devida por vir isso a repercutir no bem comum da sociedade
de que é membro; não se lhe deve muito embora retribuição pelo bem ou mal da pessoa singular, que é
no caso o próprio agente, senão por parte deste mesmo, na medida em que por analogia o homem é
susceptível de fazer justiça a si próprio.
Por onde é claro que o ato bom ou mau implica o louvor ou a culpa na medida em que cai no poder da
vontade; implica a retitude e o pecado, relativamente à ordem final; o mérito e o demérito enfim
relativamente à retribuição devida a outrem por justiça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Os atos do homem bom ou mau, embora às vezes não se
ordenem ao bem ou mal de nenhuma outra pessoa singular, ordenam-se contudo ao bem ou mal de
outrem, que é a comunidade.

RESPOSTA À SEGUNDA. ― Também o homem que tem o domínio sobre os seus atos merece ou
desmerece, dispondo bem ou mal deles, na medida em que depende de outrem, i. é, da comunidade, de
que faz parte; e o mesmo se dará se usar bem ou mal de outros bens seus, dos quais a comunidade deve
servir-se.

RESPOSTA À TERCEIRA. ― O próprio bem ou mal que alguém faz a si mesmo, pelo seu ato, redunda na
comunidade, como dissemos.

## Art. 4 — Se o ato do homem, bom ou mau, é meritório ou demeritório perante Deus.
(Infra, q. 114, a . 1).
O quarto discute-se assim. ― Parece que o ato do homem, bom ou mau, não é meritório nem
demeritório perante Deus.

1. ― Pois, como já se disse, o mérito e o demérito implicam relação com a recompensa de um benefício
ou de um dano feito a outrem. Ora, o bom ou mau ato do homem não pode ser proveitoso nem nocivo
a Deus, conforme aquilo da Escritura (Jô 25, 6-7): Se pecares, em que danarás tu a Deus? De mais disso,
se obrares com justiça, que lhe darás? Logo, o ato do homem, bom ou mau, não é meritório nem
demeritório perante Deus.

2. Demais. ― O instrumento em nada merece nem desmerece nas mãos de quem o usa, porque toda a
sua ação é devida a este último. Ora, o homem, quando age, é instrumento da divina virtude, que
principalmente o move, conforme a Escritura comparando, manifestamente, o homem agente com um
instrumento (Is 10, 15): Acaso gloriar-se-á o machado contra o que corta com ele? Ou levantar-se-á a
serra contra aquele por quem é posta em movimento? Logo, bem ou mal agindo, o homem não merece
nem desmerece perante Deus.

3. Demais. ― O ato humano é meritório ou demeritório por ter relação com outrem. Ora, nem todos os
atos humanos se ordenam a Deus. Logo, nem todos, bons ou maus, são meritórios ou demeritórios
perante Deus.
Mas, em contrário, diz a Escritura (Ecle. 12, 14): E de tudo quanto se comete fará Deus dar conta no seu
juízo, seja boa ou má essa coisa. Ora, juízo implica retribuição relativa ao mérito ou demérito de alguém.
Logo, todo ato do homem, bom ou mau, é meritório ou demeritório perante Deus.

SOLUÇÃO. ― Como já dissemos o ato do homem é meritório ou demeritório enquanto se ordena a
outrem, em si mesmo ou como parte de uma comunidade. Ora, de ambos os modos os nossos atos são
meritórios ou demeritórios perante Deus. Primeiro, quanto a Deus em si mesmo, fim último do homem;
pois, devemos referir todos os nossos atos a esse fim, como antes já demonstramos. Logo, quem faz um
ato mau, não referível a Deus, não lhe conserva a honra, que é devida ao último fim. Por outro lado, em
relação a toda a comunidade do universo, pois governador de toda comunidade deve precípuamente
tratar do bem comum, e por isso compete-lhe retribuir ao que nessa comunidade é bem ou mal feito.
Ora, Deus governa e dirige todo o universo, como estabelecemos na primeira parte, e especialmente as
criaturas racionais. Por onde é manifesto, que os atos humanos são perante ele meritórios ou
demeritórios; do contrário, resultaria que não cura de tais atos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Deus, em si mesmo, não ganha nem perde nada por via
de um ato humano; o homem porém na medida das suas forças, subtrai ou concede alguma coisa a
Deus, conservando ou não a ordem que ele instituiu.

RESPOSTA À SEGUNDA. ― Ser o homem movido como instrumento de Deus não exclui que se mova a si
mesmo pelo livre arbítrio, como do sobredito resulta. Logo, pelo seu ato merece ou desmerece perante
Deus.

RESPOSTA À TERCEIRA. ― O homem não se ordena, em si mesmo, totalmente e com tudo o que lhe
pertence, à comunidade política; e por isso não há-de qualquer ato seu ser meritório e ou demeritório,
em relação a essa comunidade. Mas o todo que é o homem, com tudo o que pode e tem, deve ordenar-
se para Deus; donde, todo o ato humano, bom ou mau, é por essência meritório ou demeritório perante
ele.
Tratado das paixões da alma