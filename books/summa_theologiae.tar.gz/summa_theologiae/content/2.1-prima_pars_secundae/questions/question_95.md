# Questão 95: Da Lei humana
Em seguida devemos tratar da lei humana.
E primeiro, da lei humana em si mesma. Segundo, do seu poder. Terceiro, da sua mutabilidade.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se é útil terem os homens estabelecido leis.
(Supra, q. 91, a. 3; X Ethic., lect XIV).
O primeiro discute-se assim. — Parece que não é útil terem os homens estabelecido leis.

1. — Pois, a intenção de qualquer lei é tornar os homens bons, como já se disse (q. 92, a. 1). Ora, eles
são levados melhor ao bem, voluntariamente, por advertências, do que coagidos por leis. Logo, não é
necessário estabelecê-las.

2. Demais. — O Filósofo diz: Os homens buscam o juiz, como sendo a justiça animada. Ora, a justiça
animada é melhor que a inanimada, contida nas leis. Logo, melhor seria cometer a execução da justiça
ao arbítrio dos juízes, do que legislar a esse respeito.

3. Demais. — Toda lei é diretiva dos atos humanos, como do sobredito resulta (q. 90, a. 1, a. 2). Ora,
como os atos humanos versam sobre situações particulares, que são infinitas, o que respeita à direção
dos atos humanos não pode ser levado em conta suficientemente, senão por alguém que tenha a
ciência dos particulares. Logo, é melhor serem os atos humanos dirigidos pelo arbítrio dos prudentes, do
que fazer leis para eles. Portanto, não é necessário estabelecer leis humanas.
Mas, em contrário, Isidoro diz: As leis foram feitas para que, por medo delas, seja coibida a audácia
humana, a inocência defendida contra os maus e dos próprios maus refreada a faculdade de fazer mal,
pelo temor do suplício. Ora, tudo isto é em máximo grau necessário ao gênero humano. Logo,
necessário é que se tenham estabelecido leis humanas.

SOLUÇÃO. — Como do sobredito resulta (q. 63, a. 1; q. 94, a. 3), o homem tem aptidão natural para a
virtude; mas a perfeição mesma da virtude é forçoso adquiri-la por meio da disciplina. Assim, vemos que
é por alguma indústria, que satisfaz às suas necessidades, p. ex., as do comer e do vestir-se. Dessa
indústria já a natureza lhe forneceu o início, a saber, a razão e as mãos; não porém o complemento,
como o fez para os outros animais, a que deu a cobertura dos pêlos e alimentação suficiente. Ora, para
a disciplina em questão, o homem não se basta facilmente a si próprio. Pois, a perfeição da virtude
consiste principalmente em retraí-lo dos prazeres proibidos, a que sobretudo é inclinado, e, por
excelência, os jovens, para os quais a disciplina é mais eficaz. Logo, é necessário que essa disciplina, pela
qual consegue a virtude, o homem a tenha recebido de outrem. Assim, para os jovens naturalmente
inclinados aos atos de virtude, por dom divino, basta a disciplina paterna, que procede por advertências.
Certos, porém, são protervos, inclinados aos vícios e se não deixam facilmente mover por palavras. Por
isso é necessário sejam coibidos do mal pela força e pelo medo, para que ao menos assim, desistindo de
fazer mal, e deixando a tranqüilidade aos outros, também eles próprios pelo costume sejam levados a
fazer voluntariamente o que antes faziam por medo, e deste modo se tornem virtuosos. Ora, essa
disciplina, que coíbe pelo temor da pena, é a disciplina das leis. Por onde é necessário, para a paz dos
homens e para a virtude, que se estabeleçam leis. Pois, como diz o Filósofo, o homem se, aperfeiçoado
pela virtude, é o melhor dos animais, afastado da lei e da justiça, é o pior de todos. Porque tem as armas
da razão, para satisfazer as suas paixões e crueldades, que os outros animais não têm.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os homens bem dispostos são melhor induzidos à
virtude por advertências, que voluntariamente aceitam, do que pela coação. Certos, porém, mal
dispostos, não se deixam levar à virtude, senão coagidos.

RESPOSTA À SEGUNDA. — Como diz o Filósofo, é melhor que tudo seja regulado por lei, do que
entregue ao arbítrio de juízes. E isto por três razões. — Primeiro, por ser mais fácil encontrar uns poucos
homens prudentes, suficientes para fazer leis retas, do que muitos que seriam necessários, para julgar
bem de cada caso particular. — Segundo, porque os legisladores, com muita precedência consideram
sobre o que é preciso legislar; ao contrário, os juízos sobre fatos particulares procedem de casos
nascidos subitamente. Ora, mais facilmente pode o homem ver o que é reto, depois de ter refletido
muito, do que apoiado só num único fato. — Terceiro, porque os legisladores julgam em geral e para o
futuro; ao passo que os homens, que presidem ao juízo, julgam do presente, apaixonados pelo amor ou
pelo ódio, ou por qualquer cobiça; o que lhes deprava o juízo. — Portanto, como, a justiça animada do
juiz não se encontra em muitos e é flexível, é necessário, sempre que for possível, seja determinado por
lei como se deva julgar, deixando pouquíssima margem ao arbítrio humano.

RESPOSTA À TERCEIRA. — É necessário cometer a juízes certos casos particulares, que a lei não pode
abranger, conforme o Filósofo o diz, no mesmo lugar; p. ex., saber se um fato se deu ou não, ou coisas
semelhantes.

## Art. 2 — Se toda lei feita pelos homens é derivada da lei natural.
(III Cont. Gent., cap. CXXIII; III Sent., dist. XXXVII, a. 3; IV, dist. XV, q. 3, a. 1, qª 4; a. 2, qª 1; V Ehtic.,
lect. XII).
O segundo discute-se assim. — Parece que nem toda lei feita pelos homens é derivada da lei natural.

1. — Pois, diz o Filósofo: Ao justo legal é inicialmente indiferente vir a ser de um ou de outro modo. Ora,
tal indiferença não existe no que depende da lei natural. Logo, nem tudo o que é estabelecido pelas leis
humanas deriva da lei natural.

2. Demais. — O direito positivo divide-se, por oposição, do direito natural, como se vê claramente em
Isidoro, e no Filósofo. Ora, o que deriva dos princípios comuns da lei natural, como conclusão, pertence
à lei natural, como já se disse (Q. 94, a. 4). Logo, o que é de lei humana não deriva da lei natural.

3. Demais. — A lei da natureza é a mesma para todos; pois, no dizer do Filósofo, o justo natural tem em
toda parte o mesmo vigor. Ora, se as leis humanas derivassem da lei natural, também haveriam de ser
as mesmas para todos, o que é evidentemente falso.

4. Demais. — Ao que deriva da lei natural pode-se assinalar uma razão. Ora, nem de tudo o que foi
estatuído pelas leis dos antepassados pode-se dar razão, como diz o jurisperito. Logo, nem todas as leis
humanas derivam da lei natural.
Mas em contrário, diz Túlio: O temor das leis e a religião sancionaram o que, derivado da natureza, foi
sancionado pelo costume.

SOLUÇÃO. — Como diz Agostinho, não é considerado lei o que não for justo. Por onde, uma disposição é
justa na medida em que tem a virtude da lei. Ora, na ordem das coisas humanas, chama-se justo ao que
é reto segundo a regra da razão. E como da razão a primeira regra é a lei da natureza, conforme do
sobredito resulta (q. 91, a. 2 ad 2), toda lei estabelecida pelo homem tem natureza de lei na medida em
que deriva da lei da natureza. Se, pois, discordar em alguma coisa, da lei natural, já não será lei, mas
corrupção dela.
Deve-se, porém, saber que, de dois modos pode ser a derivação da lei natural; como conclusões
derivadas dos princípios, ou como determinações de certos princípios gerais. Ora, o primeiro modo é
semelhante ao porque, nas ciências, derivam-se, dos princípios, conclusões demonstrativas. O segundo
é semelhante ao que se dá com as artes, em que formas gerais se determinam em algo de especial.
Assim, o artífice há de necessariamente determinar a forma geral, de modo a constituir a figura de uma
casa. Por onde, certas disposições derivam dos princípios gerais da lei da natureza, a modo de
conclusões; assim, o dever de não matar pode derivar, como conclusão, do princípio que a ninguém se
deve fazer mal. Outras disposições derivam por determinação; assim, a lei da natureza estatui que quem
peca seja punido; mas a pena com que deve sê-lo é uma determinação da lei da natureza.
Ora, ambos estes modos se encontram nas leis estabelecidas pelo homem. Porém, as disposições
pertencentes ao primeiro modo estão contidas na lei humana, não só como estabelecidas por ela, mas
também por elas receberem, da lei natural, algo do seu vigor. Ao passo que as disposições pertencentes
ao segundo modo haurem o seu vigor só na lei humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo se refere nesse lugar às disposições de lei, por
uma certa determinação ou especificação dos preceitos da lei da natureza.

RESPOSTA À SEGUNDA. — A objeção colhe quanto ao que deriva da lei da natureza como conclusão.

RESPOSTA À TERCEIRA. — Os princípios gerais da lei da natureza não podem ser aplicados a todos do
mesmo modo, por causa da múltipla variedade das coisas humanas. E daí provém a diversidade das leis
positivas dos diversos povos.

RESPOSTA À QUARTA. — A expressão do jurisperito deve ser entendida das disposições estabelecidas
pelos antepassados e que versam sobre determinações particulares da lei natural. E a essas
determinações se referem, como a uns princípios, o juízo dos peritos e dos prudentes, que logo vêm,
assim, o que seja mais congruente determinar num caso particular. E por isso o Filósofo diz: em tais
casos, é preciso atender ao juízo dos peritos, dos anciães ou dos prudentes, embora manifestado por
enunciados e opiniões indemonstráveis, não menos que se fossem demonstrações.

## Art. 3 — Se Isidoro expõe convenientemente a qualidade da lei positiva.
O terceiro discute-se assim. — Parece que Isidoro expõe inconvenientemente as qualidades da lei
positiva, dizendo: A lei há de ser honesta, justa, possível, natural, conforme aos costumes pátrios,
conveniente ao lugar e ao tempo, necessária, útil e também clara, de modo a não iludir pela
obscuridade; escrita, não para a utilidade privada, mas para a utilidade comum dos cidadãos.

1. — Pois, antes, atribuía à qualidade de lei três condições, dizendo: Lei será tudo o que estiver de
acordo com a razão; que, ao menos, concorde com a religião, convenha à disciplina,
aproveite à salvação. Portanto, é superfluamente que, depois, multiplica as condições da lei.

2. Demais. — A justiça faz parte da honestidade, como diz Túlio. Logo, depois de ter dito — honesta,
superfluamente acrescenta — justa.

3. Demais. — A lei escrita, segundo Isidoro, divide-se do costume, por oposição. Logo, não devia dizer,
na definição da lei — conforme ao costume pátrio.

4. Demais. — Necessário tem dupla acepção. Numa é o que, sendo-o absolutamente, não pode sofrer
mudança; e esta necessidade, não dependendo do juízo humano, não pertence à lei humana. Mas,
noutra acepção, necessário pode ser o que tende para um fim, e tal necessidade é o mesmo que
utilidade. Logo, é supérfluo dizer — necessária e útil.
Mas, em contrário, é a autoridade do próprio Isidoro.

SOLUÇÃO. — A forma de um ser, que tende para um fim, há de necessariamente ser determinada por
proporção com esse fim. Assim, a forma de uma serra há de ser tal que sirva para cortar, como está
claro em Aristóteles. Assim também, tudo o que é reto e medido há de necessariamente ter a forma
proporcionada à sua regra e medida. Ora, uma e outra coisa se encontra na lei humana; pois, ordena-se
a um fim; e é uma regra ou medida, regulada ou medida por uma medida superior. E esta é dupla a
saber, a lei divina e a lei da natureza, como do sobredito resulta (a. 2; q. 93, a. 3). Ora, o fim da lei
humana é a utilidade dos homens, como também o diz o jurisperito. Por isso Isidoro discriminou, em
primeiro lugar, três condições da lei: ser concorde com a religião, enquanto proporcionada à lei divina;
conveniente a disciplina, enquanto proporcionada à lei da natureza; aproveitar à salvação enquanto;
proporcionada à utilidade humana.
E a estas três se reduzem todas as outras condições, referidas em seguida. Assim, a denominação de
honesta se refere a ser concorde com a religião; o que acrescenta — justa, possível, natural, conforme
aos costumes pátrios, conveniente ao lugar e ao tempo, tudo se reduz a ser conveniente à disciplina.
Pois, a disciplina humana se refere, primeiro, à ordem da razão, que está incluída na palavra — justa.
Segundo, à faculdade do agente. Pois, a disciplina deve convir a cada um, segundo a sua possibilidade,
observada a possibilidade da natureza. Assim, não se pode impor às crianças o mesmo que se impõe aos
homens perfeitos. E deve ela ser conforme aos costumes humanos, pois, o homem não pode, só, viver
em sociedade, sem conformar os seus costumes com os dos outros. Terceiro quanto às circunstâncias
devidas, Isidoro diz — conveniente ao lugar e ao tempo. E o que acrescenta — necessária, útil, etc. — se
refere ao que importa à salvação. De modo que a necessidade se refere à remoção dos males; a
utilidade, à consecução dos bens; a clareza acautela contra danos que poderiam provir da própria lei. E,
ordenando-se a lei para o bem comum, como já dissemos (q. 90, a. 2), esta mesma condição está
exposta na última parte da enumeração.
Donde se deduzem claras AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 4 — Se Isidoro estabelece convenientemente a divisão das leis humanas ou do direito humano.
(V Ethic., lect. XII).
O quarto discute-se assim. — Parece que Isidoro estabelece inconvenientemente a divisão das leis
humanas, ou do direito humano.

1. — Pois, neste direito compreende o direito das gentes, assim chamado, como ele próprio o diz,
porque por eles se regem todos os povos. Ora, como diz ainda o mesmo, o direito natural é comum a
todas as nações. Logo, o direito das gentes não está contido no direito positivo humano, mas antes, no
direito natural.

2. Demais. — Causas que têm a mesma virtude não diferem formal, mas só, materialmente. Ora, as leis,
os plebiscitos, os senatus-consultos e outras disposições legais, que o autor enumera, têm todos a
mesma virtude. Logo, parece que só hão de diferir materialmente. Ora, não se deve, na arte, levar em
conta essa distinção que pode se dividir ao infinito. Logo, é inconveniente estabelecer tal divisão das leis
humanas.

3. Demais. — Como há, na cidade, príncipes, sacerdotes e soldados, há também muitos outros ofícios
humanos. Logo, parece que, assim como se introduz de certo modo um direito militar e um direito
público exercido pelos sacerdotes e pelos magistrados, assim também devem se introduzir outros
direitos e outros ofícios próprios da cidade.

4. Demais. — Deve-se preterir o acidental. Ora, uma lei pode, acidentalmente, ser feita por um ou outro
indivíduo. Logo, é inconveniente estabelecer uma divisão das leis humanas fundada em os nomes dos
legisladores, de modo que, p. ex., uma se chame Cornélia, outra, Falcídia, etc.
Mas, em contrário, basta a autoridade de Isidoro.

SOLUÇÃO. — Uma divisão pode ser feita, essencialmente, pelo que constitui a essência do ente a ser
dividido. Assim, a essência do animal compreende a alma, que pode ser racional ou irracional. Por onde,
própria e essencialmente, o animal é dividido em racional e irracional, e não em branco e preto,
totalmente estranhos à sua essência. Ora, há muitos elementos constitutivos da essência da lei humana,
segundo os quais qualquer pode ser, própria e essencialmente, dividida.
Assim, primeiramente, é da sua essência ser derivada da lei natural, como do sobredito resulta (a. 2). E,
a esta luz, o direito positivo se divide em direito das gentes e direito civil, conforme aos dois modos
porque se dá a derivação da lei natural, como já antes se disse (a. 2). Pois, ao direito das gentes
pertence o que deriva da lei natural como as conclusões derivam dos princípios; tais as justas compras,
vendas e outras transações sem as quais os homens não podem ter convivência, que é de direito
natural, porque o homem é um animal naturalmente social, como o prova Aristóteles. O que, porém,
deriva da lei da natureza, por determinação particular, pertence ao direito civil, pelo qual cada Estado
determina O que lhe é acomodado.
Em segundo lugar, da essência da lei humana é ordenar-se ao bem comum da cidade. E, a esta luz, a lei
humana pode se dividir conforme à diversidade dos que especialmente trabalham para o bem comum.
Assim, os sacerdotes, orando a Deus pelo povo; os príncipes, governando o povo; e os soldados,
pugnando pela salvação dele. Por onde, a estes homens se aplicam certos direitos especiais.
Em terceiro lugar, é da essência da lei humana ser instituída pelo governador da comunidade civil, como
já dissemos. E assim sendo, as leis humanas se distinguem conforme aos diversos regimes da cidade. —
Dos quais um, segundo o Filósofo, se chama reino, i. é, quando a cidade é governada por um só chefe.
Ao qual correspondem as constituições. Outro regime é o chamado aristocracia, que é o principado dos
melhores ou optimatas. E a estes correspondem as respostas dos prudentes e também os senatus-
consultos. — Outro é a oligarquia, i. é, o principado de poucos, ricos e poderosos ao qual corresponde o
direito pretoriano, também chamado honorário. — Outro, ainda, é o regime do povo chamado
democracia, ao qual correspondem os plebiscitos. — Outro por fim é o tirânico, absolutamente
corrupto, e por isso nenhuma lei lhe corresponde. — Mas há também um regime composto de todos
esses, que é o melhor. E a esse corresponde a lei, estabelecida simultaneamente pelos patrícios e pelos
plebeus, como diz Isidoro.
Enfim, em quarto lugar, é da essência da lei humana ser diretiva dos atos humanos. E a esta luz,
conforme aos assuntos diversos para os quais as leis foram estabelecidas, assim se distinguem as leis, às
vezes denominadas pelos nomes dos seus autores. Tais são as distinções de lei Júlia, sobre os adultérios;
lei Cornélia, sobre os sicários, e assim por diante, não por causa dos seus autores, mas por causa dos
seus objetos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O direito das gentes, sendo racional, é, de certo modo,
natural ao homem, enquanto derivado da lei natural, a, modo de conclusão não muito remota dos
princípios; por isso os homens facilmente se põem de acordo relativamente a ele.
Distingue-se, contudo, do direito natural, sobretudo do que é comum a todos os animais.
Pelo que foi dito se deduzem claras as RESPOSTAS ÀS OUTRAS OBJEÇÕES.