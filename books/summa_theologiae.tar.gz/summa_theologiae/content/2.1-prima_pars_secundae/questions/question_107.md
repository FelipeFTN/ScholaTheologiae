# Questão 107: Da comparação entre a lei nova e a antiga.
Em seguida devemos comparar a lei nova com a antiga.
E, sobre este ponto, discutem-se quatro artigos:

## Art. 1 — Se a lei nova difere da antiga. [Supra, q. 91, a. 5; Ad Galat., cap. I, lect. II].
O primeiro discute-se assim. Parece que a lei nova não difere da antiga.

1. — Pois, uma e outra foram dadas para os que têm fé em Deus, conforme a Escritura (Heb 11, 6): sem
fé é impossível agradar a Deus. Ora, fé tanto a tiveram os antigos como os modernos, conforme a Glosa.
Logo, a lei é a mesma.

2. Demais. — Agostinho diz, que a pequena diferença entre a lei e o Evangelho é o temor e o amor. Ora,
este e aquela não bastam para diversificar a nova lei da antiga, porque também esta estabelecia
preceitos de caridade, como os seguintes (Lv 19, 18): Amarás a teu próximo; (Dt 6, 5) Amarás ao Senhor
teu Deus. Nem podem as duas leis se diversificar pela diferença assinalada por Agostinho: O Antigo
Testamento prometia bens temporais, o Novo os promete espirituais e eternos. Porque também o Novo
promete certos bens temporais, conforme se lê no Evangelho (Mr 10, 30): Receberá já de presente
neste mesmo século o cento por um, das casas e dos irmãos, etc. E no Antigo Testamento esperava-se
em promessas espirituais e eternas conforme o Apóstolo (Heb 11, 16): Agora aspiram outra pátria
melhor, i. é, a celestial, referindo-se aos antigos patriarcas. Logo, a lei nova não difere da antiga.

3. Demais. — O Apóstolo parece distinguir uma lei da outra (Rm 3, 27), quando chama à lei antiga lei das
obras, e à nova, lei da fé. Ora, segundo o mesmo, a lei antiga também era lei da fé (Heb 11, 39): Todos
estão provados pelo testemunho da fé, referindo-se aos patriarcas do Velho Testamento.
Semelhantemente, a lei nova, por sua vez, é a lei das obras, como diz o Evangelho (Mt 5, 44): Fazei bem
aos que vos têm ódio; e (Lc 22, 19): Fazei isto em memória de mim. Logo, a lei nova não difere da antiga.
Mas, em contrário, diz o Apóstolo (Heb 7, 12): Mudado que seja o sacerdócio, é necessário que se faça
também a mudança da lei. Ora, o sacerdócio do Novo Testamento difere do sacerdócio do Antigo, como
o mesmo Apóstolo o prova. Logo, a lei nova também difere da antiga.

SOLUÇÃO. — Como já dissemos (q. 90, a. 2; q. 91, a. 4), toda lei ordena a vida humana para um fim. Ora,
todas as coisas ordenadas para um fim podem diversificar-se de duplo modo, conforme a idéia do fim.
De um modo, por se ordenarem a diversos fins; e esta é uma diferença específica, sobretudo se o fim for
próximo. De outro modo, pela proximidade ou afastamento do fim. Assim, é claro que os movimentos
diferem especificamente segundo se ordenam para termos diversos. Mas, quando uma parte do
movimento está mais próximo do termo que outra, elas entre si diferem, como o perfeito, do
imperfeito.
Por onde, podemos distinguir duas leis diversas. — Primeiro, como que absolutamente, enquanto
ordenadas a fim diversos. Assim, a lei da cidade, que se ordenasse a servir ao governo do povo, seria
especificamente diferente da que se ordenasse a servir aos melhores da cidade. — De outro modo, uma
lei pode se distinguir de outra por estar uma ordenada ao fim, mais proximamente e, a outra, mais
remotamente. Assim, na cidade, uma é a lei imposta aos homens perfeitos, capazes de praticar logo o
que respeita ao bem comum; outra é a que manda ministrar ensino às crianças, que devem ser
instruídas para praticarem mais tarde ações de homem.
Por onde, devemos dizer que, do primeiro modo, a lei nova não difere da antiga, pois o fim de ambas é
trazer o homem sujeito a Deus. Ora, o Deus do Novo e do Velho Testamento é o mesmo, conforme o
Apóstolo (R 3, 30): Não há senão um Deus, que justifica pela fé os circuncidados e que também pela fé
justifica os incircuncidados. Do outro modo, a lei nova difere da antiga. Porque esta era como um
pedagogo de crianças, no dizer do Apóstolo (Gl 3, 24). Ao passo que a lei nova é a perfeição, lei da
caridade, da qual diz o Apóstolo (Cl 3, 14), que é o vínculo da perfeição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A unidade da fé em ambos os Testamentos prova a
unidade do fim. Pois, como já dissemos (q. 62, a. 2), o objeto das virtudes teologais, entre as quais está a
fé, é o fim último. Contudo, uma era a função da fé na antiga lei, e outra, a na lei nova. Pois, o que os
antigos criam como futuro, nós cremos como realizado.

RESPOSTA À SEGUNDA. — Todas as diferenças assinaladas entre a lei nova e a velha fundam-se nas
idéias de perfeito e de imperfeito. Pois os preceitos de toda lei são dados para regular os atos virtuosos.
Ora, para praticar tais atos, os imperfeitos, ainda sem o hábito da virtude, agem de um modo, e de
outro os que já são perfeitos por esse hábito. Assim, os que ainda não tem o hábito da virtude são
levados a praticar atos virtuosos por uma causa extrínseca, p. ex., por causa da cominação de penas ou
pela promessa de certas remunerações extrínsecas, como a honra, as riquezas, ou coisas semelhantes.
Por isso a lei antiga, dada para imperfeitos, i. é, que ainda não tinham conseguido a graça espiritual, era
chamada lei do temor, porque levava à observância dos preceitos pela cominação de determinadas
penas, e dela se diz que fazia certas promessas temporais. Os que tem virtudes, porém, são levados a
praticá-la por amor da mesma, e não por qualquer pena ou remuneração extrínseca. Por onde, a lei
nova que é a principal, por consistir na graça espiritual mesma, infundida nos corações, chama-se lei do
amor. E a Escritura diz que ela promete bens espirituais e eternos, que são os objetos da virtude,
principalmente da caridade, que por isso tende para esses bens, não como algo de extrínseco, senão de
próprio. E também por isso se diz que a lei eterna coibia as mãos e não, a alma. Porque, quem se
abstém do pecado, por temor da pena, não afasta a sua vontade do pecado, absolutamente falando,
como o faz a vontade do que se abstém por amor da justiça. E por isso se diz que a lei nova que é a lei
do amor, coíbe a alma. — Houve porém no regime do Velho Testamento, quem, tendo a caridade e a
graça do Espírito Santo, esperava principalmente as promessas espirituais e eternas, e portanto
pertencia ao regime da lei nova. E semelhantemente, há no regime do Novo Testamento certos homens
carnais, que ainda não alcançaram a perfeição da lei nova. E esses, embora desse regime, tornam
necessário sejam levados às obras virtuosas pelo temor das penas e por meio de certas promessas
temporais. A lei antiga, porém, não obstante esses preceitos de caridade, não os dava por ela o Espírito
Santo, por quem está derramada a caridade em nossos corações, como diz a Escritura (Rm 5, 5).

RESPOSTA À TERCEIRA. — Como já dissemos (q. 106, a. 1, 2), a lei nova é chamada lei da fé por
consistir, principalmente, na graça mesma, dada internamente aos crentes; daí o denominar-se graça da
fé.Secundariamente, ela contém certos atos morais e sacramentais, que não lhe constituem a parte
principal, como constituíam a parte principal da lei antiga. Mas os que, no regime do Velho Testamento,
foram, pela fé, aceitos a Deus, pertenceram por isso ao Novo Testamento. Pois, não se justificaram
senão pela fé em Cristo, autor do Novo Testamento. Por onde, de Moisés diz o Apóstolo (Heb 11,
26): Tinha por maiores riquezas o opróbrio de Cristo que os tesouros dos egípcios.

## Art. 2 — Se a lei nova cumpriu a antiga.
[IV Sent., dist. I, q. 2, a. 5, qª 2, ad 1, 3; Ad Rom., cap. III, lect. IV, cap. IX, lect. V; Ad Ephes, cap. II, lect.
V].
O Segundo discute-se assim. — Parece que a lei nova não cumpriu a antiga.

1. — Pois, o cumprimento contraria a abolição. Ora, a lei nova vem abolir ou excluir a observância da
antiga, conforme diz o Apóstolo (Gl 5, 2): Se vos fazeis circuncidar, Cristo vos não aproveitará
nada. Logo, a lei nova não veio cumprir a antiga.

2. Demais. — Um contrário não cumpre o outro. Ora, o Senhor propôs, na lei nova, certos preceitos
contrários aos da lei antiga. Assim, diz (Mt 5, 27-32): Ouvistes que foi dito aos antigos: Qualquer que se
desquitar de sua mulher dê-lhe carta de repúdio. Mas eu vos digo que todo o que repudiar a sua
mulher, a faz ser adúltera. E a seguir, o mesmo se dá com a proibição do juramento, e ainda com a pena
de talião e com o ódio aos inimigos. Semelhantemente, parece que o Senhor excluiu os preceitos da lei
antiga relativos ao discernimento dos alimentos, quando diz (Mt 15, 11): Não é o que entra pela boca o
que faz imundo o homem. Logo, a lei nova não cumpriu a antiga.

3. Demais. — Quem age contra a lei não a cumpre. Ora, em certos casos, Cristo agiu contra ela. Assim,
tocou o leproso, como diz o Evangelho (Mt 8, 3), o que era contra a lei. Também foi visto violar muitas
vezes o sábado, pelo que dele diziam os judeus (Jo 9, 16): Este homem, que não guarda o sábado, não é
de Deus.Logo, Cristo não cumpriu a lei. Logo, a lei nova, dada por Cristo, não veio cumprir a antiga.

4. Demais. — A lei antiga continha preceitos morais cerimoniais e judiciais, como já se disse (q. 99, a. 4).
Ora, num lugar do Evangelho, onde se vê que o Senhor, a certos respeitos, cumpriu a lei, nenhuma
menção se faz dos preceitos judiciais e cerimoniais. Logo, parece que a lei nova não veio totalmente
cumprir a antiga.
Mas, em contrário, diz o Senhor (Mt 5, 17): Não vim destruir a lei, mas a dar-lhe cumprimento. E depois
acrescenta (Mt 5, 18): não passará da lei um só i, ou um til, sem que tudo seja cumprido.

SOLUÇÃO. — Como já dissemos (a. 1), a lei nova está para a antiga como o perfeito para o imperfeito.
Ora, o perfeito completa o que falta ao imperfeito. E assim, a lei nova completa a antiga, suprindo-a no
que lhe faltava.
Ora, duas coisas podem considerar-se na lei antiga: o fim e os preceitos nela contidos. — O fim da lei é
tornar os homens justos e virtuosos, como já se disse (q. 92, a. 1). Por onde, o fim da lei antiga era a
justificação dos homens; o que porém não podendo fazer, o figurava por meio de certos atos
cerimoniais e o prometia por palavras. E neste ponto a lei nova cumpre a antiga, justificando pela
virtude da paixão de Cristo. E isto diz o Apóstolo (Rm 8, 3-4): O que era impossível à lei, enviando Deus a
seu Filho em semelhança de carne de pecado, por causa do pecado, condenou ao pecado na carne, para
que a justificação da lei se cumprisse em nós. E neste ponto a lei nova realiza o que a antiga prometeu,
conforme aquilo do Apóstolo (2 Cor 1, 20):Todas as promessas de Deus são em seu Filho, i, é, em
Cristo. E além disso, nesta matéria, cumpre também o que a lei antiga figurava. Por isso, a Escritura diz
(Cl 2, 17), que as cerimônias eram à sombra das coisas vindouras; mas o corpo é um Cristo, i. é, a
verdade pertence a Cristo. Por isso, a lei nova se chama lei da verdade, e a antiga, lei da sombra ou da
figura.
Quanto aos preceitos da lei antiga, Cristo os cumpriu com as suas obras e a sua doutrina. — Com as
obras, porque quis circuncidar-se e observar as outras disposições legais, que devia no seu tempo
observar, segundo aquilo da Escritura (Gl 4, 4): Feito sujeito à lei. — E com a sua doutrina cumpriu os
preceitos da lei de três modos. — Primeiro, explicando-lhe o sentido, como se vê no caso do homicídio e
do adultério, na proibição dos quais os Escribas e os Fariseus não viam senão o ato exterior proibido. Por
onde, o Senhor cumpriu a lei, mostrando que a sua proibição abrange também os atos internos dos
pecados. — Segundo, o Senhor cumpriu os preceitos da lei ordenando como se haviam de observar mais
perfeitamente as disposições da lei antiga. Assim, a lei antiga estatuía que se não perjurasse, o que se
observa mais perfeitamente se a gente se abstém de todo de jurar, salvo em caso de necessidade. — Em
terceiro lugar, o Senhor cumpriu os preceitos da lei, acrescentando certos conselhos de perfeição, como
se vê no Evangelho onde, a quem afirmava observar os preceitos da lei antiga diz (Mt 19, 21): Falta-te
uma coisa: Se queres ser perfeito, vai, vende o que tens, etc.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A lei nova não veio abolir a observância da antiga, senão
na parte das cerimônias, como já dissemos (q. 13, 1. 3, 4), pois elas eram figurativas do futuro. Por onde,
pelo fato mesmo de estarem cumpridos os preceitos cerimoniais, já realizado o que eles figuravam, já
não deviam ser observados. Pois se o fossem, significariam algo de futuro, ainda não realizado. Assim
também a promessa do dom futuro já não tem lugar, uma vez a promessa cumprida pela realização do
dom. E deste modo, uma vez cumpridas, desapareceram as cerimônias da lei.

RESPOSTA À SEGUNDA. — Como diz Agostinho, os preceitos referidos, do Senhor, não são contrários
aos da lei antiga. — Pois, o preceito do Senhor de não repudiar a esposa, não é contrário ao que a lei
preceituava. E nem a lei disse — Quem quiser repudia a esposa — do que o contrário seria não repudiar.
Mas certamente, não queria fosse à esposa repudiada pelo marido, quem interpôs um prazo para que o
de ânimo pressuroso em separar-se, peado pela redação do libelo, se abstivesse da separação. Por isso
o Senhor, a fim de o confirmar, para que a esposa não fosse repudiada facilmente, excetuou só o caso
da fornicação. — E o mesmo também se deve dizer quanto à proibição do juramento, conforme já
advertimos — E o mesmo é patente na proibição do talião. A lei taxou o modo da vindicta, para que não
a tomassem imoderadamente; da qual o Senhor mais perfeitamente demoveu aquele a quem advertiu
se abstivesse dela completamente. — Quanto ao ódio dos inimigos, o Senhor removeu a falsa
inteligência dos Fariseus, advertindo-nos que devemos odiar, não as pessoas, mas a culpa. — Enfim,
quanto ao discernir dos alimentos, que era cerimonial, o Senhor não mandou que deixasse de ser
observado, mas mostrou que nenhuma comida é em si mesma imunda, mas, só figuradamente, como já
se disse (q. 102, a. 6 ad 1).

RESPOSTA À TERCEIRA. — A lei antiga proibia tocar no leproso, por que, fazendo-o, incorria-se numa
certa imundice de irregularidade, assim como por tocar num morto, segundo já dissemos (q. 102, a. 5 ad
4). Ora, o Senhor, que era o curador do leproso, não podia incorrer em imundice. — Pelas coisas porém
que fez no sábado, não aboliu em verdade a lei do sábado, como ele próprio o mostra no Evangelho.
Quer porque fizesse milagre por virtude divina, que sempre age sobre as coisas; quer porque praticasse
obras para a salvação humana, pois os Fariseus também providenciavam pela conservação dos animais,
no dia de sábado; quer também porque, em razão da necessidade, desculpou os discípulos que colhiam
espigas no sábado. Mas realmente, aboliu a lei do sábado como supersticiosamente a entendiam os
Fariseus, pensando que a gente se devia abster mesmo das obras da salvação, nesse dia, o que ia contra
a intenção da lei.

RESPOSTA À QUARTA. — No lugar aduzido do Evangelho não se lembram os preceitos cerimoniais da
lei, porque a observância deles desapareceu totalmente, por terem sido realizados, segundo já dissemos
(a. 1). — Dos preceitos judiciais só foi lembrado o do talião, de modo a ser entendido de todos os mais o
que fosse dito deste. E o Senhor ensinou que, nesse preceito, a intenção da lei não era que se aplicasse
a pena de talião pelo prazer da vingança, que ele exclui, advertindo que cada um deve estar preparado a
sofrer injúrias ainda maiores; mas só por amor da justiça. E deste modo ainda permanece na lei nova a
referida pena.

## Art. 3 — Se a lei nova está contida na antiga.
O terceiro discute-se assim. — Parece que a lei nova não está contida na antiga.

1. — Pois, a lei nova consiste principalmente na fé, sendo por isso chamada lei da fé, como diz o
Apóstolo (Rm 3, 27). Ora, a lei nova estabeleceu muitos preceitos da fé, que não estão contidos na lei
antiga. Logo, a lei nova não está contida na antiga.

2. Demais. — Sobre aquilo do Evangelho (Mt 5, 19) — Aquele que quebrar um destes mínimos
mandamentos — diz uma Glosa, que os mandamentos da lei são menores; e os do Evangelho, maiores.
Ora, o mais não pode estar contido no menos. Logo, a lei nova não está contida na antiga.

3. Demais. — A coisa contida em outra é possuída simultaneamente com esta. Ora, se a lei nova
estivesse contida na antiga, resultaria que quem estivesse sob o regime desta estaria também sob o
daquela. Logo, foi supérfluo dar uma lei nova a quem já tinha a antiga. Portanto, a lei nova não está
contida na antiga.
Mas, em contrário, diz a Escritura (Ez 1, 16): E a roda estava na roda, i. é, o Novo Testamento no Velho,
como expõe Gregório.

SOLUÇÃO. — De dois modos pode uma coisa estar contida em outra: atualmente, como a que está
colocada num lugar; ou, virtualmente, como o efeito na causa ou o completo no incompleto. Assim, o
gênero contém potencialmente a espécie, e toda a árvore está contida na semente. E deste modo a lei
nova está contida na antiga: pois, como já se disse, aquela está para esta, como o perfeito, para o
imperfeito. Por isso, Crisóstomo, expondo aquilo do Evangelho (Mr 4, 28) — A terra por si mesma
produz, primeiramente a erva, depois a espiga e, por último, o grão graúdo na espiga — diz assim:
Primeiro, frutifica a erva, na lei da natureza; depois, as espigas na lei de Moisés; enfim, o grão graúdo,
no Evangelho. Assim, pois, a lei nova está na antiga, como o grão na espiga.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tudo o que o Novo Testamento ensina explícita e
abertamente para ser crido, também já se encontrava no Velho Testamento, mas implícita e
figuradamente. E assim, mesmo quanto ao que devemos crer, a lei nova está contida na antiga.

RESPOSTA À SEGUNDA. — Diz-se que os preceitos da lei nova são maiores que os da antiga, quanto à
sua manifestação explícita. Mas, pela substância mesma, os preceitos do Novo Testamento estão todos
contidos no do Velho. Donde o dizer Agostinho: Quase tudo o que o Senhor ensinou ou preceituou,
quando acrescentava — Eu, porém, vos digo — já se encontra naqueles livros antigos. Mas, como não se
compreendia no homicídio senão a morte dada ao corpo humano, o Senhor explicou, que todo ato
injusto, para prejudicar o próximo, está incluído no gênero do homicídio. E por tais explicações, os
preceitos da lei nova consideram-se maiores que os da lei antiga. Mas, nada impede esteja o maior
virtualmente contido no menor, como a árvore, na semente.

RESPOSTA À TERCEIRA. — É preciso explicar o dito implicitamente. Por onde, depois de dada a lei
antiga, era necessária dar também a lei nova.

## Art. 4 — Se a lei nova é mais onerosa do que a antiga.
[III Sent., dist. XL, a. 4, qª 3 ; Quodl. IV, q. 8, a. 2 ; In Matth, ; cap. IX].
O quarto discute-se assim. — Parece que a lei nova é mais onerosa que a antiga.

1. — Pois, sobre aquilo da Escritura — Aquele que quebrar um destes mínimos mandamentos — diz
Crisóstomo: Os mandamentos de Moisés, como — não matarás, não fornicarás — são mais fáceis de
praticarem. Enquanto que os de Cristo, como — Não te encolerizarás, não cobiçaras — são mais
difíceis. Logo, a lei nova é mais onerosa que a antiga.

2. Demais. — É mais fácil usar da prosperidade terrena, do que sofrer tribulações. Ora, no Antigo
Testamento, a prosperidade temporal era consecutiva à observância da lei, como se vê na Escritura (Dt
28, 1-14). Ao passo que muitas adversidades perseguem os observantes da lei nova, consoante o
Apóstolo (2 Cor 6, 4-10):Portemo-nos em nossas mesmas pessoas como ministros de Deus, na muita
paciência, nas tribulações, nas necessidades, nas angústias, etc. Logo, a lei nova é mais onerosa que a
antiga.

3. Demais. — Um preceito acrescentado a outro é mais difícil de ser observado. Ora, a lei nova foi
acrescentada à antiga. Assim, esta proibiu o perjúrio; ao passo que aquela, até mesmo o juramento. A
lei antiga proibia a separação da mulher sem o libelo de repúdio; a nova proibiu absolutamente a
separação, como o diz a Escritura (Mt 5, 31 ss), conforme a exposição de Agostinho. Logo, a lei nova é
mais onerosa que a antiga.
Mas, em contrário, diz a Escritura (Mt 11, 28): Vinde a mim, todos os que andam em trabalho e vos
achais carregados. E segundo a explicação de Hilário: Chama a si os que padecem as dificuldades da lei e
estão carregados com os pecados do século. E depois, o Senhor acrescenta, falando do jugo do
Evangelho: O meu jugo é suave, e o meu peso leve. Logo, a lei nova é mais leve que a antiga.

SOLUÇÃO. — Em relação às obras virtuosas, para regular as quais foram dados os preceitos da lei, surge
dupla dificuldade. — Uma, relativa às obras externas, que em si mesmas trazem uma certa dificuldade e
onerosidade. E neste ponto a lei antiga será muito mais onerosa que a nova. Pois, com as suas múltiplas
cerimônias, obrigava a mais atos externos que a lei nova. Esta, além dos preceitos da lei natural, poucas
coisas acrescentou, com a doutrina de Cristo e dos Apóstolos. Embora muitos acréscimos se fizessem
depois, por instituição dos santos padres. Mas ainda neste ponto, Agostinho diz, que não se deve perder
de vista a moderação, para não se tornar onerosa a vida dos fiéis. Assim, referindo-se a certos,
diz: Carregam com obras servis a própria religião nossa, que, com manifestíssimas e pouquíssimas
cerimônias de sacrifícios, a misericórdia de Deus quis que fosse livre. De modo que é mais tolerável a
condição dos judeus, sujeitos, a sacramentos legais e não a presunções humanas.
A outra dificuldade versa sobre os atos virtuosos internos, como quando praticados pronta e
agradavelmente. Ora, atacar essa dificuldade é a função da virtude. Pois, a prática desses atos, muito
difícil para quem não possui a virtude, torna-se fácil para o virtuoso. E neste ponto os preceitos da lei
nova são mais onerosos que os da antiga. Pois, aquela proíbe os movimentos internos da alma, que a lei
antiga não proibia expressamente em todos os casos, embora o fizesse em certos, em que porém não se
acrescentava nenhuma pena à proibição. Ora, o que a lei nova dispõe é dificílimo para quem é sem
virtude. Pois, como diz o Filósofo, é fácil fazer o que faz o justo; mas agir como ele age, deleitável e
prontamente, é difícil para quem não tem justiça. E assim também diz a Escritura (1 Jo 5, 3): os seus
mandamentos não são custosos; o que Agostinho explica:o que não é difícil para quem ama o é para
quem não ama.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A autoridade aduzida se refere expressamente à
dificuldade da lei nova, quanto à expressa proibição dos movimentos internos.

RESPOSTA À SEGUNDA. — As contrariedades que sofrem os observantes da lei nova não são impostas
pela lei mesma; contudo, como o amor, em que a lei consiste, são facilmente toleradas. Pois, como diz
Agostinho o amor torna fácil e quase destrói o que é cruel e duro.

RESPOSTA À TERCEIRA. — Esses acréscimos aos preceitos da lei antiga têm por fim facilitar-lhe a
observância, como diz Agostinho. Logo, daí não se conclui que a lei nova seja mais onerosa, mas ao
contrário, mais fácil.