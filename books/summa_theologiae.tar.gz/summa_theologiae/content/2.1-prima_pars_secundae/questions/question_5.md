# Questão 5: Da consecução da beatitude.
Em seguida devemos, tratar da consecução mesma da beatitude. E sobre esta Questão oito artigos se
discutem:

## Art. 1 — Se o homem pode alcançar a beatitude.
O primeiro discute-se assim. — Parece que o homem não pode alcançar a beatitude.

1. — Pois, assim como a natureza racional é superior à sensível, assim a intelectual o é à racional, como
se vê claramente em muitos lugares de Dionísio. Ora, os brutos, dotados só da natureza sensível, não
podem alcançar o fim da natureza racional. Logo, nem o homem de natureza racional, pode alcançar o
fim da natureza intelectual, que é a beatitude.

2. Demais. — A verdadeira beatitude consiste na visão de Deus, que é a verdade pura. Ora, é conatural
ao homem descobrir a verdade na ordem natural; por isso é que intelige, nos fantasmas, as
espécies inteligíveis, como diz Aristóteles. Logo, não pode alcançar a beatitude.

3. Demais. — A beatitude consiste na obtenção do sumo bem. Mas ninguém pode chegar ao que é sumo
sem passar pelos meios. Ora, como entre Deus e a natureza humana é média a natureza Angélica, que o
homem não pode ultrapassar, resulta que não pode alcançar a beatitude.
Mas, em contrário, diz a Escritura (Sl 93, 12): Bem-aventurado o homem a quem tu instruíres, Senhor.

SOLUÇÃO. — Beatitude significa obtenção do bem perfeito. Logo, quem quer que seja capaz de tal bem
pode alcançá-la. Ora, como o seu intelecto pode apreender o bem universal e perfeito, e a sua vontade
apetecê-lo, conclui-se que o homem é capaz do bem perfeito. E portanto, pode alcançar a beatitude. —
E o mesmo também se conclui de ser ele capaz da visão da divina essência, como já se estabeleceu na
primeira parte. Ora, dissemos que, nessa visão, consiste a sua perfeita beatitude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De modo diferente excede a natureza racional à
sensitiva e a intelectual, à racional. Pois, racional excede a sensitiva quanto ao objeto do conhecimento;
porque o sentido de nenhum modo pode, ao contrário da razão, conhecer o universal. Porém a natureza
intelectual excede a racional quanto ao modo de conhecer a verdade inteligível; pois aquela apreende
imediatamente a verdade, que a natureza racional alcança pela perquirição da razão, como resulta claro
do já dito na primeira parte. Por onde, como a razão pode, movendo-se, alcançar aquilo que o intelecto
apreende, concluí-se que a natureza racional pode alcançar a beatitude, que é a perfeição da natureza
intelectual, embora de modo diferente do angélico. Pois os anjos a conseguiram imediatamente desde o
princípio da sua condição; ao passo que os homens e ela chegam após certo tempo, enquanto que a
natureza sensitiva de nenhum modo pode alcançar tal fim.

RESPOSTA À SEGUNDA. — Ao homem, no estado de vida presente, é conatural o modo de conhecer a
verdade inteligível por meio dos fantasmas; mas, passada esta vida, tem outro modo conatural, como já
se disse na primeira parte.

RESPOSTA À TERCEIRA. — O homem não pode exceder os anjos pelo grau de natureza e de modo que
lhes seja naturalmente superior. Pode-o contudo pela atividade do intelecto, inteligindo que existe algo
de superior aos anjos, que o beatifica, e que quando o alcançar perfeitamente, será perfeitamente feliz.

## Art. 2 — Se um homem pode ser mais feliz que outro.
(IV Sent., dist. XLIX, q. 1, a . 4, q ª 2, In Matth., cap. XX; In Ioann, cap. XIV, lect. I; Cor., III, lect II).
O segundo discute-se assim. — Parece que um homem não pode ser mais feliz que outro.

1. — Pois, como diz o Filósofo, a beatitude é o prêmio da virtude. Ora, a todos é dada igual recompensa
pelas obras da virtude, conforme a Escritura (Mt 20, 10), quando diz que todos os que trabalharam na
vinha não receberam mais que um dinheiro cada um; porque, na expressão de Gregório, tiveram em
quinhão uma igual retribuição da vida eterna. Logo, um não será mais feliz que outro.

2. Demais. — A beatitude é o sumo bem. Mas nada pode ser maior do que o que é sumo. Logo, não
pode haver uma beatitude maior que a alcançada pelo homem.

3. Demais. — A beatitude, sendo o bem perfeito e suficiente, aquieta o desejo do homem. Ora, esse
desejo não se aquieta se faltar algum bem, que possa ser proporcionado; se porém não faltar nada do
que possa sê-lo, não pode haver nenhum outro bem maior. Logo, ou o homem não é feliz, ou, se o é,
não pode haver outra beatitude maior.
Mas, em contrário, diz a Escritura (Jo 14, 2): Na casa de meu Pai há muitas moradas, pelas quais, como
ensina Agostinho, se entendem as diversas dignidades dos méritos, na vida eterna. Ora, a dignidade da
vida eterna, dada ao mérito, é a beatitude mesma. Logo, há diversos graus de beatitude e esta não é
igual para todos.

SOLUÇÃO. — Duas coisas se incluem na essência da beatitude: o fim último, em si, que é o sumo bem; e
a obtenção ou gozo desse bem. – Ora, quanto ao bem em si, que é o objeto da beatitude e a causa, não
pode uma beatitude ser maior que outra, porque só há um sumo bem, que é Deus, por cuja fruição os
homens são felizes. — Mas quanto à obtenção ou gozo de tal bem, pode uma ser maior que outra;
porque mais feliz será quem mais fruir desse bem. Ora, pode dar-se que um goze mais perfeitamente de
Deus, que outro, por ser mais bem disposto ou ordenado a tal gozo. E a esta luz, pode um ser mais feliz
que outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A unidade do dinheiro significa a unidade da beatitude,
quanto ao objeto; enquanto a diversidade das moradas significa a diversidade da beatitude, quanto ao
grau diverso da fruição.

RESPOSTA À SEGUNDA. — A beatitude é chamada o sumo bem por ser a posse perfeita ou a fruição do
sumo bem.

RESPOSTA À TERCEIRA. — Nenhum bem-aventurado tem qualquer bem a desejar, porque possui o bem
infinito, em si, que é o bem de todo bem, como diz Agostinho. Mas se diz que um é mais feliz que outro,
quanto à diversa participação do mesmo bem. — A adição porém dos outros bens não aumenta a
beatitude; por onde, diz Agostinho: Quem te conheceu a ti e ao outros bens, não é mais feliz, por estes,
mas só por ti é feliz.

## Art. 3 — Se a beatitude pode ser obtida nesta vida.
(IV Sent., dist. XLIII, a . 1, q ª 1; dist. XLIX, q. 1, a . 1, q ª 4; Cont. Gent., cap. XLVIII; I Ethic., lect. X, XVI).
O terceiro discute-se assim. — Parece que a beatitude pode ser obtida nesta vida.

1. — Pois, diz a Escritura (Sl 118,1): Bem-aventurados os que se conservam sem mácula no caminho, os
que andam na lei do Senhor. Ora, isto se dá nesta vida. Logo, nela se pode ser feliz.

2. Demais. — A participação imperfeita do sumo bem não elimina a essência da beatitude; do contrário,
um não seria mais feliz que outro. Ora, nesta vida, os homens podem participar do sumo bem,
conhecendo e amando a Deus, embora imperfeitamente. Logo, nesta vida o homem pode ser feliz.

3. Demais. — O que é dito por muitos não pode ser totalmente falso; pois se considera natural o que
existe em muitos, porque a natureza não falha totalmente. Ora, muitos põem a beatitude nesta vida,
como se vê claramente na Escritura (Sl 143, 15): Bem-aventurado chamarão ao povo que tem estas
coisas, i. é, os bens da vida presente. Logo, pode-se nesta vida ser feliz.
Mas, em contrário, diz a Escritura (Jó 14, 1): O homem nascido da mulher, que vive breve tempo, é
cercado de muitas misérias. Ora, a beatitude exclui a miséria. Logo o homem não pode ser feliz nesta
vida.

SOLUÇÃO. — Podemos alcançar nesta vida uma certa participação de beatitude; beatitude perfeita
porém e verdadeira não pode ser obtida. E isto podemos prová-lo de dois modos.
Primeiro, pela essência comum da beatitude. Pois, sendo ela o bem perfeito e suficiente, exclui todo mal
e satisfaz todo desejo. — Ora, nesta vida não podemos excluir todo mal. Pois, a vida presente está
sujeita a muitos males, que não podem ser evitados: à ignorância da inteligência; à afeição desordenada
do apetite; e a muitos incômodos do corpo, que Agostinho diligentemente enumera. —
Semelhantemente, também o desejo do bem não pode ser saciado nesta vida. Pois naturalmente o
homem deseja a permanência do bem que possui. Ora, não só os bens da vida presente são transitórios,
mas ainda passa a própria vida, que naturalmente desejamos e queríamos permanecesse
perpetuamente, porque naturalmente ao homem lhe repugna a morte. Por onde, é impossível nesta
vida obter-se a verdadeira beatitude.
Segundo, se se considerar o em que especialmente consiste a beatitude — a visão da essência divina, a
que o homem não pode chegar nesta vida, como já se demonstrou na primeira parte.
Donde manifestamente resulta que ninguém nesta vida pode alcançar a verdadeira e perfeita beatitude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Certos se consideram felizes nesta vida, ou pela
esperança da beatitude a alcançar, na vida futura, conforme aquilo da Escritura (Rm 8, 24) — Na
esperança é que fomos salvos; ou por uma tal ou qual participação da beatitude, relativa a uma certa
fruição do sumo bem.

RESPOSTA À SEGUNDA. — A participação da beatitude pode ser imperfeita de duplo modo. Quanto ao
objeto mesmo da beatitude, que não é visto na sua essência; e tal imperfeição elimina a essência da
verdadeira beatitude. E segundo, quanto ao próprio participante que, certo, atinge o objeto da
beatitude, em si mesmo, que é Deus, mas imperfeitamente, por comparação com o modo pelo qual
Deus a si mesmo se goza. E tal imperfeição não elimina a verdadeira essência da beatitude porque,
sendo esta uma operação, como já se disse, a sua verdadeira essência se considera quanto ao objeto
que especifica o ato, e não quanto ao sujeito.

RESPOSTA À TERCEIRA. — Os homens julgam haver nesta vida alguma beatitude, por uma certa
semelhança com a verdadeira. E assim, não erram totalmente no seu juízo.

## Art. 4 — Se a beatitude pode ser perdida.
(I. p. 64, a . 2; q. 94, a . 1; I Sent., dist., VIII, q. 3, a . 2; IV, dist. XLIX, q. 1, a . 1 q ª 4; III Cont. Gent., cap.

LXII; Compend. Theol., Art. I, cap. CLXVI; pArt. II, cap. IX; In Ioann, cap. X, lect V).
O quarto discute-se assim. — Parece que a beatitude pode ser perdida.

1. — Pois, a beatitude é uma perfeição, e toda perfeição está no perfectível, ao modo deste. Ora, sendo
o homem mutável por natureza, resulta que a beatitude é participada por ele mutávelmente, e portanto
pode perdê-la.

2. Demais. — A beatitude consiste na ação do intelecto, ao qual está sujeita a vontade. Ora, esta exerce
entre termos opostos. Donde resulta que pode omitir a operação pela qual o homem se torna feliz, e
então este deixa de o ser.

3. Demais. — Ao princípio corresponde o fim. Ora, a beatitude do homem tem princípio, porque ele não
foi sempre feliz. Logo, há de ter fim.
Mas, em contrário, diz a Escritura (Mt 25, 46), falando dos justos, que irão estes para a vida eterna, que
é como já se disse, a beatitude dos Santos. Ora, o eterno não pode faltar. Logo, a beatitude não pode
ser perdida.

SOLUÇÃO. — Se nos referimos à beatitude imperfeita, tal como pode ser obtida nesta vida, então pode
ser perdida. — E isto é patente na felicidade contemplativa, que se perde ou pelo esquecimento,
quando, p. ex., a ciência desaparece na doença; ou ainda por certas ocupações que nos desviam da
contemplação. — É também patente na felicidade ativa. Pois, a vontade do homem pode transmutar-se,
degenerando para o vício, da virtude, em cujo ato consiste principalmente a felicidade. Se porém a
virtude permanecer íntegra, as transmutações exteriores podem perturbar a beatitude, impedindo
muitas operações virtuosas; não podem contudo eliminá-la totalmente, porque ainda permanece a
atividade virtuosa, enquanto o homem arrosta dignamente tais adversidades. — E como a beatitude
desta vida pode ser perdida, o que vai contra a essência dela, por isso o Filósofodiz que alguns, nesta
vida, são felizes, não absolutamente, mas como homens, cuja natureza está sujeito à mudança.
Se porém nos referimos à beatitude perfeita, esperada depois desta vida, devemos saber que Orígenes,
seguindo o erro de alguns platônicos, ensinou que depois de adquirida a beatitude última o homem
pode se tornar miserável.
Mas tal opinião resulta manifestamente falsa, de dupla razão.
A primeira é tirada da essência mesma comum da beatitude. Pois, sendo ela o bem perfeito e suficiente,
necessário é satisfaça o desejo do homem e exclua todo mal. Ora, o homem deseja naturalmente
conservar o bem que possui e ter a certeza de conservá-lo; do contrário necessariamente havia de
afligir-se com o temor de perdê-lo ou com a dor pela certeza da perda. Logo, é necessário, para a
verdadeira beatitude, que o homem tenha opinião certa de que nunca há de perder o bem possuído. E
de tal opinião, sendo verdadeira, resulta que nunca há de perder a beatitude, sendo falsa, já em si é um
mal ter tal opinião; pois a falsidade é o mal do intelecto como o verdadeiro lhe é o bem, segundo diz
Aristóteles. Logo, já não será verdadeiramente feliz, se algum mal nele existe.
Em segundo lugar, o mesmo resulta da consideração da essência da beatitude, em especial. Pois, como
já se demonstrou, a perfeita beatitude do homem consiste na visão da essência divina. Ora, é impossível
que, contemplando a essência divina, não queiramos contempla-la. Porque todo bem possuído, de que
queiramos ser privados, ou é insuficiente, e em lugar dele buscamos outro mais suficiente; ou é
acompanhado de algum incômodo, que causa aborrecimento. — Ora, a visão da divina essência enche a
alma de todos os bens, porque une à fonte de toda vontade. Por onde, diz a Escritura (Sl 16, 15): Saciar-
me-ei quando aparecer a tua glória; e (Sb 7, 11): E todos os bens me vieram juntamente com ela, i. é,
com a contemplação da sabedoria. — E semelhantemente, nenhum incômodo a acompanha; pois da
contemplação da sabedoria diz a Escritura (Sb 8, 16): a sua conservação não tem nada de desagradável,
nem a sua companhia nada de fastidioso. — É pois claro que, por vontade própria, o bem-aventurado
não pode abandonar a beatitude. — E do mesmo modo, também não pode perdê-la, porque Deus dela
o prive. Pois a privação da beatitude, sendo uma pena tal privação, não pode provir de Deus, juiz justo,
senão por causa de alguma culpa, na qual não pode cair quem lhe vê a essência, porque essa visão é
necessariamente acompanhada da retidão da vontade, como já se demonstrou. E semelhantemente,
nenhum outro agente pode privar dela. Pois a mente unida com Deus fica elevada acima de tudo o mais;
e assim, dessa união, nenhum outro agente pode excluí-la. Por onde, é inadmissível que, por quaisquer
vicissitudes dos tempos, passe o homem da beatitude para a miséria, e inversamente; porque, tais
vicissitudes temporais só podem recair sobre o que está sujeito ao tempo e ao movimento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A beatitude é a perfeição consumada, que exclui do
bem-aventurado toda deficiência. E portanto, sem mutabilidade, advém ao que a possui, por feito da
virtude divina, que eleva o homem à participação da eternidade transcendente a toda mutação.

RESPOSTA À SEGUNDA. — A vontade se exerce entre termos opostos, quanto às coisas ordenadas para
o fim; mas ele se ordena por necessidade natural ao fim último, como resulta claro de não poder o
homem deixar de querer ser feliz.

RESPOSTA À TERCEIRA. — A beatitude tem princípio, quanto a condição do participante dela; mas não
tem fim, por causa da condição do bem cuja participação torna feliz. Por onde uma é a razão porque a
beatitude tem início e outra, a por que carece de fim.

## Art. 5 — Se o homem pelas suas faculdades naturais pode alcançar a beatitude.
(I. q. 12, a . 4;q. 62, a . 1; infra, q. 62, a . 1; III Sent., dist., XXVII. Q. 2, a . 2; IV, dist. LXIX. q. 2, a . 6; III
Cont.Gent., cap. LII, CXLVII).
Parece que o homem pelas suas faculdades naturais pode alcançar a beatitude.

1. — Pois, a natureza não falha no necessário. Ora, nada é tão necessário ao homem como o que o leve
ao fim último. Logo, isto não falta à natureza humana, e, portanto, o homem pode, pelas suas
faculdades naturais, alcançar a beatitude.

2. Demais. — O homem, sendo mais nobre que as criaturas irracionais, há de ser mais auto-suficiente.
Ora, essas criaturas podem, pelas suas faculdades naturais, conseguir os seus fins. Logo, com maior
razão, o homem pode, pelas suas, conseguir a beatitude.

3. Demais. — A beatitude é uma operação perfeita, segundo o Filósofo. Ora, o que começa uma coisa
também a aperfeiçoa. Por onde, estando a operação imperfeita, que é como o princípio, nas operações
humanas, sujeita ao poder natural do homem, pelo qual é senhor dos seus atos, resulta que pela sua
potência natural ele pode atingir a operação perfeita, que é a beatitude.
Mas, em contrário. — O homem é naturalmente princípio dos seus atos pelo intelecto e pela vontade.
Ora, a beatitude última, preparada para os Santos excede o intelecto e a vontade do homem. Pois, diz a
Escritura (1 Cor 2, 9): O olho não viu, nem o ouvido ouviu, nem jamais veio ao coração do homem o que
Deus tem preparado para aqueles que o amam. Logo, o homem, pelas suas faculdades naturais não
pode alcançar a beatitude.

SOLUÇÃO. — A beatitude imperfeita, tal como pode ser alcançada nesta vida, o homem pode adquiri-la
pelas suas faculdades naturais, do modo por que também adquire a virtude, em cuja operação tal
beatitude consiste, como a seguir se dirá. — Mas a beatitude perfeita do homem, como já se disse,
consiste na visão da essência divina. Ora, ver a Deus em essência, está acima da natureza, não só do
homem, como também de toda criatura, conforme já se demonstrou na primeira parte. Pois, o
conhecimento natural de uma criatura é conforme ao modo da sua substância, segundo, da inteligência,
se diz no livro Das causas, que conhece o que lhe é superior e inferior, ao modo da sua substância. Ora,
todo conhecimento conforme ao modo da substância criada não alcança a visão da divina essência, que
excede infinitamente toda substância criada. Por onde, nem o homem, nem nenhuma criatura pode
conseguir a beatitude última, pelas suas faculdades naturais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A natureza não falta com o necessário ao homem, pois
embora não lhe desse, como aos outros animais, armas e tegumento, deu-lhe a razão e as mãos, com as
quais pode adquirir as coisas necessárias. Assim também não lhe falta com esse necessário, embora não
lhe desse, o que era impossível, nenhum princípio, pelo qual pudesse alcançar a beatitude, pois deu-lhe
o livre arbítrio, pelo qual pudesse voltar-se para Deus, que o havia de tornar feliz. Pois, como diz
Aristóteles, o que podemos por meio dos amigos também, de certo modo, por nós o podemos.

RESPOSTA À SEGUNDA. — A natureza que pode alcançar o bem perfeito, embora para tal precise de
auxílio exterior, é de mais nobre condição que a que não pode alcançar tal bem, senão só o imperfeito,
embora para tal não precise do referido auxílio. Assim como, segundo o Filósofo, é melhor disposto para
a saúde quem a pode conseguir perfeita, embora com auxílio da medicina, do que quem só pode
consegui-la imperfeita, sem tal auxílio. E, portanto, a criatura racional, capaz de alcançar o perfeito bem
da beatitude, precisando, para tal, do auxílio divino, é mais perfeita que a irracional, incapaz de tal bem,
conseguindo apenas um bem imperfeito por virtude da sua natureza.

RESPOSTA À TERCEIRA. — Sendo da mesma espécie, o imperfeito e o perfeito podem ser causados pela
mesma potência. Mas tal não se dá necessariamente, sendo de espécies diferentes, pois nem tudo o
que pode causar uma disposição da matéria pode conferir-lhe a última perfeição. Ora, a operação
imperfeita, dependente do poder natural do homem, não é da mesma espécie que a perfeita, que é a
sua beatitude última; pois, os atos se especificam pelo objeto. Por onde, a objeção não colhe.

## Art. 6 — Se o homem pode tornar-se feliz por obra de uma criatura superior, o anjo.
O sexto discute-se assim. — Parece que o homem pode tornar-se feliz por ato de uma criatura
superior, como o anjo.

1. — Havendo nas coisas dupla ordem — uma, a das partes do universo entre si; a outra, a de todo o
universo em relação ao bem que lhe é exterior — a primeira se ordena à segunda, como ao seu fim,
conforme diz Aristóteles. Assim como a ordem das partes do exército, entre si, é para a de todo o
exército, relativamente ao chefe. Ora, a ordem das partes do universo, entre si, funda-se em que as
criaturas superiores agem sobre as inferiores, como na primeira parte se disse. Ora, a beatitude consiste
na ordem do homem ao bem que está fora do universo e que é Deus. Logo, por ação sobre o homem de
uma criatura superior, como o anjo, o homem pode tornar-se feliz.

2. Demais. — O que é potencialmente tal pode atualizar-se pelo que é tal atualmente; assim o cálido
potencial vem a atualizar-se pelo que atualmente já o é. Ora, o homem tem a felicidade em potência.
Logo, pode tornar-se feliz em ato, por meio do anjo, que o é atualmente.

3. Demais. — A beatitude consiste, como já se disse, na operação do intelecto. Ora, o anjo pode iluminar
o intelecto do homem, conforme se estabeleceu na primeira parte. Logo, pode tornar o homem feliz.
Mas, em contrário, diz a Escritura (Sl 83, 12): O senhor dará a graça e a glória.

SOLUÇÃO. — Estando todas as criaturas da natureza sujeitas a leis, por terem virtude e ação limitada, o
que excede a natureza criada não pode ser feito por virtude de nenhuma criatura. E portanto, o que há
de fazer-se, de superior à natureza, há de sê-lo imediatamente por Deus, como a ressurreição de um
morto, o dar vista a um cego e coisas semelhantes. Ora, como já se demonstrou, a beatitude é bem
excedente à natureza criada. Por onde, é impossível seja conferida pela ação de qualquer criatura; e
portanto, o homem torna-se feliz pela só ação de Deus, se nos referimos à beatitude perfeita. — Se
porém nos referimos à imperfeita, então ela tem a mesma essência da virtude, em cujo ato consiste.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quase sempre se dá nas potências ativas ordenadas, que
levar ao fim último pertence à suprema potência; e as potências inferiores coadjuvam, dispondo, à
consecução desse último fim. Assim, à arte de pilotar, que rege a de construir navios, pertence o uso do
navio, e para ela é que o navio é feito. Por onde, na ordem do universo, o homem é seguramente
ajudado pelos anjos, na consecução do último fim, supostos certos elementos precedentes, pelos quais
se dispõe a tal consecução. Mas o fim último em si é alcançado pelo primeiro agente mesmo, que é
Deus.

RESPOSTA À SEGUNDA. — Quando a forma de um ser existe, atual, perfeita e naturalmente, pode ser-
lhe princípio de ação; assim o cálido aquece pelo calor. Mas se a forma do ser é imperfeita e não
natural, não pode ser princípio de comunicar-se com outra coisa; assim, a intenção da cor, na pupila,
não pode causar o branco; e todas as coisas iluminadas ou aquecidas não podem aquecer ou iluminar
outras, porque então a iluminação e o aquecimento iriam ao infinito. Ora, o lume da glória, pelo qual se
vê a Deus, nele existe, certo, perfeita e naturalmente; em qualquer criatura, porém, imperfeita,
similitudinária e participativamente. Por onde, nenhuma criatura feliz pode comunicar a outra a sua
felicidade.

RESPOSTA À TERCEIRA. — O anjo beato ilumina o intelecto do homem ou mesmo do anjo inferior,
quanto a certas razões das obras divinas, não porém quanto à visão da divina essência, como na
primeira parte se disse. Pois, para vê-la, todos são iluminados imediatamente por Deus.

## Art. 7 — Se são necessárias obras para que o homem alcance de Deus a beatitude.
(I. q. 62, a . 4; Compend. Theol., cap. CLXXII).
O sétimo discute-se assim. — Parece que não são necessárias obras para que o homem alcance, de
Deus, a beatitude.

1. — Pois, Deus, agente de virtude infinita, não preexige, para agir, matéria ou disposição desta, mas
pode produzir o todo, imediatamente. Ora, as obras do homem, não lhe sendo necessárias para a
beatitude, como causa eficiente, segundo se disse, só podem ser exigidas como disposições. Logo, Deus,
que não preexige, no agir, disposições, confere a beatitude sem obras precedentes.

2. Demais. — Como Deus é autor imediato da beatitude, assim também institui a natureza
imediatamente. Ora, na primeira instituição da natureza, produziu sem nenhuma disposição precedente
ou ação da criatura; mas, imediatamente, fez cada ser perfeito na sua espécie. Logo confere a beatitude
ao homem sem quaisquer obras precedentes.

3. Demais. — A Escritura diz (Rm 4, 6) que é feliz o homem a quem Deus atribui a justiça sem obras.
Logo, não são necessárias quaisquer obras, para que o homem alcance a beatitude.
Mas, em contrário, diz a Escritura (Jo 13, 17): Se sabeis estas coisas, bem-aventurados sereis, se as
praticardes. Logo, pela ação se chega à beatitude.

SOLUÇÃO. — Como já se disse, necessariamente a beatitude supõe a retidão da vontade, que não é
senão a ordem devida, desta, relativamente ao último fim, e tão indispensável à consecução dele como
a devida disposição da matéria à da forma. Mas por aí não se prova que qualquer obra do homem deve
preceder-lhe a beatitude. Pois Deus poderia fazer a vontade tender retamente e, simultaneamente,
alcançá-lo, como às vezes dispõe a matéria, e simultaneamente lhe confere a forma. Porém a ordem da
divina sabedoria exige que tal não se faça. Pois, como diz Aristóteles, dos seres que naturalmente
possuem o bem perfeito, uns o possuem sem movimento, outros, por um só movimento e outros, por
muitos. Ora, possuir o bem perfeito, imutavelmente, é próprio daquele que naturalmente o possui e
possuir naturalmente a beatitude é próprio só de Deus. Por onde, só de Deus é próprio não ser movido
para a beatitude por nenhuma obra precedente. E como a beatitude excede toda a natureza criada,
nenhuma simples criatura a alcança, convenientemente, sem o movimento do ato pelo qual tende para
ela. O anjo, porém, superior ao homem na ordem, da natureza, a alcança por ordem da divina
sabedoria, pelo só movimento da obra meritória, como se expôs na primeira parte. Ao passo que os
homens a conseguem pelos movimentos múltiplos dos atos chamados méritos. Por onde, também
segundo o Filósofo, a beatitude é o prêmio das ações virtuosas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A obra do homem é preexigida para a consecução da
beatitude, não por causa da insuficiência da divina virtude beatificante, mas para que seja conservada a
ordem nas coisas.

RESPOSTA À SEGUNDA. — Deus produziu as primeiras criaturas imediatamente perfeitas, sem nenhuma
disposição ou operação precedente da criatura; porque assim instituiu os primeiros indivíduos das
espécies para que, por eles a natureza se propagasse aos pósteros. E semelhantemente, logo desde o
princípio da sua concepção, sem nenhuma oba meritória precedente, a alma de Cristo foi bem-
aventurada porque dele, que é Deus e homem, a beatitude devia derivar-se para os outros, conforme
aquilo da Escritura (Heb 2, 10): que levou muitos filhos à glória. Mas isto é-lhe singular. Pois, às crianças
batizadas advém o mérito de Cristo, para alcançarem a beatitude, embora lhe faltem méritos próprios,
porque pelo batismo se tornavam membros de Cristo.

RESPOSTA À TERCEIRA. — O Apóstolo se refere à beatitude da esperança, que se alcança pela graça
justificante e que, certo, não é dada por causa de obras precedentes. Pois, ela não tem natureza de
termo do movimento, como a beatitude, mas antes, é princípio do movimento pelo qual se tende à
beatitude.

## Art. 8 — Se todos desejam a beatitude.
(IV Sent., dist. XLIX, q. 1, a . 3, q ª 1).
O oitavo discute-se assim. — Parece nem todos desejam a beatitude.

1. — Pois, sendo o bem apreendido o objeto do apetite, como diz Aristóteles, ninguém pode desejar o
que ignora. Ora, muitos ignoram o que seja a beatitude; e o evidência, como diz Agostinho, o terem uns
posto a beatitude no prazer do corpo, outros, na virtude da alma, outros, em outras coisas. Logo, nem
todos desejam a beatitude.

2. Demais. — Como já se disse, a essência da beatitude é a visão da essência divina. Ora, alguns dizem
ser impossível ao homem ver a Deus em essência; e portanto, tal não desejam. Logo, nem todos os
homens desejam a beatitude.

3. Demais. — Agostinho diz, que feliz é quem tem tudo o que quer e nada quer mal. Ora, nem todos
querem tal, pois, uns querem mal certas coisas, e contudo consentem em querê-las. Logo, nem todos
querem a beatitude.
Mas, em contrário, Agostinho: Se um comediante dissesse — Todos quereis ser felizes e não quereis ser
miserável — diria algo que ninguém deixaria de confessar, na sua vontade.

SOLUÇÃO. — A beatitude pode ser considerada a dupla luz. — Quanto à sua essência comum, e então
necessariamente todo homem a quer. Pois, a essência comum da beatitude está em ser ela o bem
perfeito, como já se disse. Ora, sendo o bem o objeto da vontade, o bem perfeito de alguém é o que lhe
satisfaz totalmente à vontade. Por onde, desejar a beatitude não é senão desejar que a vontade seja
saciada, o que todos querem. — De outro modo, podemos considerar a beatitude quanto à sua noção
especial, i. é, quanto ao em que ela consiste. E então, nem todos a conhecem porque não sabem a que
coisa convenha à essência comum dela. E por conseguinte, nesta acepção nem todos a querem.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — A vontade segue a apreensão do intelecto ou da razão; mas assim como
acontece que uma coisa, idêntica na realidade, é todavia diversa quanto à consideração da razão; assim
também se dá que uma coisa é idêntica, na realidade, e todavia, sob um aspecto, é desejada e, sob
outro, não. A beatitude, portanto, pode ser considerada quanto à noção de bem final e perfeito, e nisso
consiste a essência comum dela; e, então, a vontade tende para ela, necessariamente, como já se disse.
E pode também ser considerada sob outros pontos de vista especiais quanto à operação mesma, ou
quanto à potência operativa, ou quanto ao objeto; e então a vontade não tende para ela
necessariamente.

RESPOSTA À TERCEIRA. — A definição de beatitude dada por certos — Feliz é quem tem tudo o que
quer, ou, a quem tudo lhe sucede como deseja — entendida de um modo, é boa e suficiente; de outro
modo, porém, é imperfeita. — Assim, se a entendermos, absolutamente, de todas as coisas que o
homem quer com desejo natural, então é verdade que quem tem tudo o que quer é feliz. Pois nada
sacia o apetite natural do homem, senão o bem perfeito, que é a beatitude. — Entendida, porém do que
o homem quer pela apreensão da razão, então o possuir o homem certas coisas, que quer, é antes
miséria que beatitude, enquanto tais coisas, possuídas impedem-no de possuir o que quer
naturalmente; assim como a razão recebe como verdadeiras, às vezes, coisas que impedem o
conhecimento da verdade. — E conforme este ponto de vista, Agostinho acrescenta, para a perfeição da
beatitude, que nada quer mal. Embora a primeira expressão — feliz é quem tem tudo o que quer —
bem entendida, já podia bastar.
Tratado dos atos humanos