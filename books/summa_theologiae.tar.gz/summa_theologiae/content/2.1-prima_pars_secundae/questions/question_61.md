# Questão 61: Da distinção entre as virtudes cardeais.
Em seguida devemos tratar das virtudes cardeais. E sobre esta questão cinco artigos se discutem:

## Art. 1 — Se as virtudes morais devem chamar-se cardeais ou principais.
(Infra, q. 66, a. 4; III Sent., dist. XXXIII, q. 2, a. 1, qa 2; De Virtut., q. 1, a. 12, ad 24; q. 5, a. 1)
O primeiro discute-se assim. — Parece que as virtudes morais não devem chamar-se cardeais ou
principais.

1. — Pois, coisas que se dividem por oposição existem simultaneamente por natureza, como diz
Aristóteles; e, portanto, uma não é a principal em relação às outras. Ora, todas as virtudes se dividem,
genericamente, por oposição. Logo, nenhumas devem ser as principais entre elas.

2. Demais. — O fim é mais principal que os meios. Ora, as virtudes teologais versam sobre o fim e as
morais sobre os meios. Logo, não estas se devem chamar principais ou cardeais mas, aquelas.

3. Demais. — O que é por essência é mais principal do que o que é por participação. Ora, as virtudes
intelectuais pertencem por essência à parte racional; e as morais, só por participação, como já se disse.
Logo, as principais não são as virtudes morais, mas as intelectuais.
Mas, em contrário, Ambrósio expondo o lugar — bem-aventurados os pobres de espírito —
diz: Sabemos que são quatro as virtudes cardeais, a saber: a temperança, a justiça, a prudência, a
fortaleza. Ora, estas são virtudes morais. Logo, as virtudes morais são cardeais.

SOLUÇÃO. — Quando falamos simplesmente das virtudes, entendemos falar da virtude humana. Ora
esta, como já dissemos, implica a noção perfeita de virtude, que exige a retidão do apetite; pois, ela não
somente dá a faculdade de bem agir, mas também causa o bom uso da obra. Chama-se porém virtude,
na acepção imperfeita da palavra, a que não exige a retidão do apetite, porque só dá a faculdade de
bem agir, sem causar o bom uso da obra. Ora, é certo que o perfeito tem primazia sobre o imperfeito. E
portanto, as virtudes que implicam a retidão do apetite, consideram-se principais. Ora, tais são as
virtudes morais; e entre as intelectuais, só a prudência, que contudo de certo modo é moral pela sua
matéria, como do sobredito resulta. E portanto, entre as virtudes morais, colocam-se as chamadas
principais ou cardeais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando o gênero unívoco se divide nas suas espécies, as
partes da divisão incluem igualmente a essência genérica; embora pela natureza das causas seja uma
espécie a principal e mais perfeita que outra; assim, o homem em relação aos brutos. Mas, quando a
divisão é de um análogo, logo, que se predica de muitos por prioridade e posterioridade, nada impede
uma parte da divisão seja a principal, mesmo quanto à noção comum; assim, a substância,
relativamente ao acidente, é ser de maneira principal. E tal é a divisão das virtudes em diversos gêneros;
porque o bem da razão não se encontra em todos os casos segundo a mesma ordena.

RESPOSTA À SEGUNDA. — As virtudes teologais são superiores ao homem, como já dissemos. E por isso
não se chamam propriamente humanas, mas sobre-humanas ou divinas.

RESPOSTA À TERCEIRA. — As virtudes intelectuais diferentes da prudência, embora sejam principais, em
relação às virtudes morais, quanto ao sujeito, não o são contudo quanto à noção de virtude, que
respeita o bem, objeto do apetite.

## Art. 2 — Se são quatro as virtudes cardeais.
(Infra, q. 66, a. 4; III Sent., dist, XXXIII, q. 2, a. 1, qª 3; De Virtut., q. 1, a. 12, ad 25; q. 5, a. 1; II Ethic.,
lect. VIII).
O segundo discute-se assim. — Parece que não são quatro as virtudes cardeais.

1. — Pois, a prudência é diretiva das outras virtudes morais, como do sobredito resulta. Ora, o que
dirige tem primazia sobre os dirigidos. Logo, só a prudência é a virtude principal.

2. Demais. — As virtudes principais são de certo modo morais. Ora, as operações morais nós as
ordenamos pela razão prática e pelo apetite reto, como já se disse. Logo, só há duas virtudes cardeais.

3. Demais. — Entre as todas virtudes uma é mais principal que outra. Mas para ser uma virtude principal
não é preciso o seja ela em relação a todas, senão só em relação a certas. Logo, são muito mais as
virtudes principais.
Mas, em contrário, diz Gregório: Nas quatro virtudes se manifesta toda a estrutura das boas obras.

SOLUÇÃO. — O número, num caso concreto, pode ser considerado em relação aos princípios formais ou
aos sujeitos. E de ambos os modos há quatro virtudes cardeais.
Pois, o princípio formal da virtude, de que agora tratamos, é o bem da razão, que pode ser considerado
sob duplo aspecto. Ou enquanto consistente na própria consideração da razão, e então a prudência é a
virtude principal; ou, enquanto à ordem da razão é relativa a algum objeto. E isto será ou relativamente
às obras, e então há lugar para a justiça, ou às paixões, e então é necessário haver duas virtudes. Pois é
necessário estabelecer a ordem da razão relativamente às paixões, levando-se em conta a repugnância
por elas opostas à razão; o que se pode dar de dois modos. Primeiro, quando a paixão impele a algo de
contrário à razão; e nesse caso é necessário uma virtude que a reprima, e tal é a temperança. Depois,
quando a paixão afasta do que a razão dita, como o temor dos perigos ou dos trabalhos; e então é
necessária uma virtude pela qual o homem se firme, para não recuar, naquilo que é racional, e isso
designa a fortaleza.
E semelhantemente, quanto aos sujeitos, achamos o mesmo número. Pois, as virtudes de que ora
tratamos têm quádruplo sujeito: o racional por essência, que a prudência aperfeiçoa; e o racional por
participação que comporta tríplice divisão: à vontade, sujeito da justiça, o concupiscível, sujeito
da temperança; e o irascível, sujeito da fortaleza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A prudência é, absolutamente, a mais principal dentre as
virtudes. Mas há outras consideradas principais, cada uma em seu gênero.

RESPOSTA À SEGUNDA. — O racional por participação comporta tríplice divisão, como já se disse.

RESPOSTA À TERCEIRA. — Todas as demais virtudes, das quais uma é mais principal que a outra,
reduzem-se às quatro preditas, quanto ao sujeito e quanto às razões formais.

## Art. 3 — Se as demais virtudes devem mais que as referidas, chamar-se principais.
(III Sent., dist. XXXIII, q. 2, a. 1, qª4; De Virtut., q. 1, a. 12, ad 26; q. 5, a. 1; II Ethic., lect. VIII).
O terceiro discute-se assim. — Parece que as demais virtudes devem, mais que as referidas, chamar-se
principais.

1. — Pois, o que é máximo, em cada gênero, é o mais principal. Ora, a magnanimidade consiste em
praticar grandes atos, em todas as virtudes, como se disse. Logo, deve ser considerada, por excelência,
como a virtude principal.

2. Demais. — É por excelência virtude principal aquela pela qual todas as outras se formam. Ora, tal é a
humildade; pois, diz Gregório, que quem pratica as outras virtudes sem a humildade, é comparável a
quem leva palhas ao vento. Logo, a humildade é, por excelência, a principal.

3. Demais. — É por excelência principal o que é perfeitíssimo. Ora, isto pertence à paciência, segundo
aquilo da Escritura (Tg 1, 4): A paciência deve ser perfeita nas suas obras. Logo, deve ser considerada
como principal.
Mas, em contrário, diz Túlio, que todas as virtudes se reduzem as quatro de que tratamos.

SOLUÇÃO. — Como já dissemos, essas quatro virtudes cardeais se fundam nas quatro razões formais da
virtude, de que tratamos. E estas se manifestam de maneira principal em certos atos ou paixões. Assim
como o bem consistente na consideração da razão se manifesta principalmente na ordem mesma da
razão e não, no conselho, nem no juízo, como já dissemos; assim, o bem da razão, enquanto se
manifesta nos atos conforme as noções de reto e devido, se manifesta principalmente nas trocas e nas
distribuições relativas a outrem, no mesmo pé de igualdade. Por seu lado, o bem consistente em refrear
as paixões se manifesta principalmente nas paixões mais difíceis de serem reprimidas, i. é, nas relativas
aos prazeres do tacto. Por fim, o bem consistente na firmeza com que mantemos a exigência da razão
contra o ímpeto das paixões, manifesta-se principalmente nos perigos da morte, os dificílimos de todos
para serem arrostados.
Assim, pois, podemos considerar as quatro virtudes supra mencionadas à dupla luz. — Primeiro, quanto
às razões formais comuns. E então chamam-se principais como quase gerais, em relação a todas as
virtudes. De modo que toda virtude que faz o bem, levando em conta a consideração da razão, chama-
se prudência; toda a que, nos seus atos, observa o bem no atinente ao devido e ao reto, chama-se
justiça; toda a que coíbe as paixões e as reprime chama-se temperança; toda a que dá a firmeza de
ânimo contra quaisquer paixões se chama fortaleza. Assim, muitos sagrados doutores, como filósofos,
se referem a essas virtudes; e as outras nelas se contêm. Por onde caem todas as objeções.
Em segundo lugar, elas podem-se considerar enquanto denominadas pelo que é principal em cada
matéria. E então são virtudes especiais e divididas das outras por oposição. Mas se chamam principais,
em relação às outras, pela principalidade da matéria. Assim, chama-se prudência a que é preceptiva;
justiça, a que versa sobre atos devidos entre iguais; temperança, a que reprime o desejo dos deleites do
tacto; fortaleza, a que nos fortifica contra os perigos da morte.
E por este lado, caem também as objeções, porque as demais virtudes podem ter certas outras razões
de serem principais; mas estas o são em razão da matéria, como já dissemos.

## Art. 4 — Se as quatro referidas virtudes são diversas e distintas entre si.
(III Sent., dist. XXXIII, q. 1, a. 1, qª 3; De Virtut., q. 1, a. 12, ad 23; q. 5, a. 1, ad 1; II Ethic., lect. VIII).
O quarto discute-se assim. — Parece que as quatro referidas virtudes não são diversas e distintas
entre si.

1. — Pois, diz Gregório: Não é verdadeiramente prudência a que não é justa, temperada e forte, nem
perfeita a temperança que não é forte, justa e prudente; nem fortaleza integra a que não é prudente,
temperada e justa; nem verdadeira justiça a que não é prudente, forte e temperada. Ora, isto não se
daria, se as referidas quatro virtudes fossem distintas umas das outras; pois, diversas espécies do
mesmo gênero não se denominam entre si. Logo, as referidas virtudes não são entre si distintas.

2. Demais. — O que se atribui a uma coisa não se atribui a outra dela distinta. Ora, atribuísse à fortaleza
o que é próprio da temperança; pois, diz Ambrósio: A fortaleza verdadeira consiste em nos vencermos a
nós mesmos, sem nos deixarmos abrandar ou dobrar por nenhuma sedução. E também diz, que a
temperançaconserva o modo e a ordem em tudo o que deliberamos agir ou dizer. Logo, as virtudes em
questão não são distintas entre si.

3. Demais. — O Filósofo diz, que a virtude exige: primeiro, a ciência; depois, a eleição de uma obra, em
si mesma considerada; e terceiro, uma disposição firme e imutável. Ora, a primeira destas condições
pertence à prudência, que é a razão reta dos nossos atos, a segunda, i. é, eleger, à temperança, que nos
faz agir não apaixonada, mas refletidamente, refreadas as paixões; a terceira, i. é, para um fim devido,
implica, de um lado, a retidão, que pertence à justiça e, de outro, a firmeza e a imobilidade, que
pertence à fortaleza. Logo, cada uma destas virtudes é geral em relação às outras. E portanto, não se
distinguem entre si.
Mas, em contrário, diz Agostinho, que a virtude se considera quadripartida, por um certo e vário afeto
do próprio amor; e trata em seguida das quatro virtudes preditas. Logo, estas se distinguem entre si.

SOLUÇÃO. — Como já dissemos, as quatro virtudes cardeais se consideram de dois modos diversos
pelos vários autores. — Uns as consideram como significativas de certas condições gerais da alma
humana, que se encontram em todas as virtudes. E então a prudência não é senão a retidão do
discernimento relativamente a certos atos ou matérias; a justiça, por seu lado, é a retidão da alma, pela
qual obramos o que devemos, em qualquer matéria; a temperança, em terceiro lugar, é a disposição da
alma que impõe uma determinada medida a certas paixões ou obras, para não ultrapassarem os devidos
limites; a fortaleza, por fim, é à disposição da alma que nos fortifica no que é segundo a razão, contra
quaisquer ímpetos das paixões ou dificuldades do obrar. Estas quatro virtudes porém, distintas entre si,
não implicam diversidade de hábitos virtuosos, quanto à justiça, à temperança e à fortaleza. Pois, a
qualquer virtude moral, por isso mesmo que é Um hábito, convém uma certa firmeza, para não ser
movida pelo que lhe é contrário; e isto dissemos que pertence à fortaleza. E ainda, a qualquer delas, por
isso mesmo que é virtude, se ordena ao bem, que implica as noções de reto ou devido; o que, segundo
dissemos, pertence à justiça. E por fim qualquer delas, por ser virtude moral e participante da razão, há
de conservar em tudo um certo modo racional, para não ultrapassar os devidos limites; e isto, conforme
ficou dito, pertence à temperança. Por onde, só o ter discernimento, o que atribuímos a prudência, se
distingue das outras três virtudes. Pois, enquanto isto pertence à razão, por essência, as outras três
implicam uma certa participação da razão, aplicando-a as paixões ou obras. E portanto, segundo o que
acabamos de dizer, a prudência seria uma virtude distinta das outras três, que, por seu lado, não seriam
distintas entre si. Pois é manifesto que uma mesma virtude é hábito, virtude e moral.
Outros porém melhor consideram as quatro virtudes, enquanto determinadas a matérias especiais,
sendo cada qual determinada a uma matéria, na qual é principalmente acentuada aquela condição
geral, donde a virtude tirou a sua denominação, conforme já dissemos. E segundo esta opinião, é
manifesto que as virtudes em questão são hábitos diversos, distintos entre si pela diversidade dos
objetos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Gregório se refere às virtudes cardeais na primeira
acepção. — Ou se pode dizer que elas se denominam umas pelas outras, por uma certa redundância.
Pois, o próprio à prudência redunda nas outras virtudes, enquanto dirigidas por elas; e cada uma delas
redunda nas outras pela razão que quem pode o mais pode também o menos difícil. E portanto, quem
pode o dificílimo, i. é, refrear os desejos dos prazeres do tato, para que não excedam a medida, torna-se
por isso mesmo mais hábil para o que é muito mais fácil como refrear a audácia relativa aos perigos da
morte, para não ultrapassar os seus limites, dizendo-se então que a fortaleza é temperada. Por sua vez,
considera-se forte a temperança, pelo redundar nela a fortaleza. Pois, quem pela fortaleza tem o ânimo
firme contra os perigos da morte — o que é dificílimo — é mais capaz de conservar essa firmeza contra
os ímpetos dos prazeres. Porque, como diz Túlio, não é concebível que quem não é vencido pelo medo,
o seja pela cobiça; nem que seja às vezes vencido pelo prazer aquele que se não rendeu à pena.
E daqui consta também com clareza à RESPOSTA À SEGUNDA OBJEÇÃO. — Pois, a temperança conserva
a medida em tudo, e a fortaleza guarda o ânimo inquebrantável contra o engodo dos prazeres, seja
porque essas virtudes designam certas condições gerais das virtudes, seja pela redundância já referida.

RESPOSTA À TERCEIRA. — As quatro condições gerais das virtudes, que o Filósofo introduz, não são
próprias às quatro virtudes. Mas podem-lhes ser apropriadas pela maneira já dita.

## Art. 5 — Se as quatro virtudes cardeais se dividem convenientemente em virtudes exemplares, virtudes da alma purificada, purgatórias e políticas.
(III Sent., dist. XXXIII, q. 1, a. 4. ad 2; dist. XXXIV, q. 1, a. 1 arg. 6. De Verit., q. 26, a. 8, ad 2).
O quinto discute-se assim. — Parece que as quatro virtudes cardeais não se dividem
convenientemente em virtudes exemplares, virtudes da alma purificada, purgatórias e políticas.

1. — Pois, como diz Macróbio, as virtudes exemplares são as que existem na contemplação divina. Ora,
o Filósofo diz, que é ridículo atribuir a Deus a justiça, a fortaleza, a temperança e a prudência. Logo, não
podem as virtudes em questão ser exemplares.

2. Demais. — Chamam-se virtudes da alma purificada as não acompanhadas de paixões; pois, como diz
Macróbio, no mesmo lugar, é próprio à temperança da alma purificada não, reprimir as terrenas
concupiscência, mas, totalmente esquecê-las; e à fortaleza, ignorar as paixões e não, vencê-las. Ora
como já ficou dito, as virtudes cardeais não podem existir sem paixões. Logo, não podem pertencer à
alma purificada.

3. Demais. — Macróbio diz que as virtudes purgatórias são as dos que por um certo desprezo das coisas
humanas, se apegam só às coisas divinas. Ora, isto parece mal expresso, pois, conforme diz
Túlio, aqueles que dizem desprezar coisas geralmente estimadas, como o governo e a magistratura,
penso que a esses, não se lhes deve atribuir louvor, mas, censura. Logo, não há virtudes purgatórias.

4. Demais. — Macróbio denomina virtudes políticas àquelas que levam os bons cidadãos a se devotarem
à república e a defenderem as cidades. Ora, só a justiça legal é que se ordena ao bem comum, como diz
o Filósofo. Logo, as demais virtudes não se devem chamar políticas.
Mas, em contrário, Macróbio diz no mesmo lugar: Plotino que, com Platão, é o príncipe dos professores
da filosofia, diz que há quatro gêneros de virtudes, incluindo cada um quatro virtudes, das quais as do
primeiro gênero se chamam políticas; as do segundo, purgatório; as do terceiro, as da alma já
purificada; e as do quarto, exemplares.

SOLUÇÃO. — Como diz Agostinho, para que na alma possam nascer às virtudes, é preciso que ela siga a
Deus, que nos fará bem viver. Logo, o exemplar da virtude humana há de preexistir em Deus; como nele
preexistem as razões de todas as coisas. Por onde, tais virtudes podem ser consideradas como
exemplarmente existentes em Deus, e chamam-se então exemplares. De modo que a mente divina
mesma se chamará prudência; a temperança em Deus será o voltar-se a sua intenção para Ele próprio,
como em nós é assim chamada porque faz o concupiscível subordinar-se à razão; em Deus, a fortaleza é
a sua imutabilidade; e a sua justiça, por fim, é a observância da lei eterna nas suas obras, como disse
Plotino.
Mas, como o homem é por natureza um animal político, as virtudes cardeais se chamam políticas
enquanto existentes no homem conforme a condição da sua natureza. Isto é, enquanto que o homem,
pela prática dessas virtudes, procede retamente na prática dos seus atos. E é neste sentido que até aqui
temos tratado delas.
Mas, não só ainda no dizer do Filósofo, o homem deve voltar-se para as causas divinas o mais que lhe
for possível, mas também no da Escritura Sagrada, que freqüentemente no-lo recomenda, como quando
diz (Mt 5, 48): Sede perfeito, como também vosso Pai celestial é perfeito. Por onde, é necessário
admitamos certas virtudes médias, entre as políticas, que são virtudes humanas, e as exemplares, que o
são divinas. E essas se distinguem pela diversidade dos seus movimentos e dos seus termos. — Assim,
umas são transitivas e tendentes à semelhança divina, se chamam purgatórias. De modo, porém, que a
prudência despreze toda mundanidade, toda entregue à contemplação das coisas divinas e norteando
todas as cogitações da alma só para Deus. A temperança, por seu lado, há de desprezar, na medida do
que se compadece com a natureza, as exigências do corpo. A fortaleza, por sua vez, há de levar a alma à
não se aterrar com a separação do corpo e com o evolar-se para o alto. A justiça, por fim, faz com que a
alma siga, totalmente, a via conducente ao fim proposto. — Por fim, há virtudes cujo alvo é a
semelhança com Deus e são as da alma já purificada. E então, a prudência é a que só tem em mira as
causas divinas; a temperança, a que despreza os desejos terrenos; a fortaleza, a que passa ao largo das
paixões; a justiça, imitando a mente divina, associa-se com ela numa perpétua aliança. E essas virtudes
nós a atribuímos aos bem-aventurados ou a certos que, já nesta vida, são perfeitíssimos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo trata das virtudes cardeais enquanto
referentes às causas humanas. Assim, a justiça, enquanto referente à compra e à venda; a fortaleza, ao
temor; a temperança, aos desejos. Ora, em tal sentido é ridículo atribuí-las a Deus.

RESPOSTA À SEGUNDA. — As virtudes humanas, i. é, as virtudes dos homens, enquanto se agitam neste
mundo, versam sobre as paixões. Mas, as dos que já alcançaram a plena bem-aventurança, são sem
mescla de paixões. E por isso Plotino diz, que as paixões as virtudes políticas as abrandam, i. é, reduzem-
nas ao meio termo; as segundas, i. é, as purgatórias, as eliminam; as terceiras, próprias da alma já
purificada, as esquecem; para as quartas, i. é, as exemplares, é sacrilégio nomear as paixões. Embora
também se possa dizer que Macróbio, no passo aduzido, se refere às paixões enquanto exprimem certos
movimentos ordenados.

RESPOSTA À TERCEIRA. — Abandonar as coisas humanas, quando a necessidade exige o contrário, é um
mal; nos demais casos, é virtude. E por isso Túlio, antes do lugar citado, tinha dito: Talvez devamos
excusar de não se ocuparem com a coisa pública aqueles que, com excelente engenho, se entregaram à
ciência; e aos que, impedidos pela diminuição das forças, ou por outra causa mais grave, se afastaram
das coisas públicas, deixando a outros o poder e a glória de bem administrá-las. O que concorda com
isto de Agostinho: O amor da verdade busca um repouso santo; a caridade se devota às obras de justiça
que aceita. Mas, se ninguém nos impuser tal carga, entregamo-nos à compreensão e à contemplação da
verdade; se no-la impuserem, porém, aceitemo-la por dever de caridade.

RESPOSTA À QUARTA. — Só a justiça legal versa diretamente sobre o bem comum; mas pelo seu
império leva todas as outras virtudes a se referirem a esse bem, como diz o Filósofo. Pois, devemos
considerar que pertence às virtudes políticas, no sentido em que aqui são tomadas, não só obrar bem
em favor da comunidade, mas ainda em favor das partes desta, como, p. ex.; a sociedade doméstica ou
uma pessoa singular.