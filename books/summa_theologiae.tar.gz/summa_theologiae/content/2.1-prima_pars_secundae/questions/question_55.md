# Questão 55: Das virtudes quanto à sua essência.
Em seguida e conseqüentemente devemos tratar dos hábitos em especial. E como estes, conforme já se
disse, distinguem-se pelo bem e pelo mal, devemos tratar, primeiro dos hábitos bons, que são as
virtudes, e do que lhes é anexo, a saber, os dons, as beatitudes e os frutos. Segundo, dos hábitos maus,
a saber, dos vícios e dos pecados.
Quanto às virtudes, cinco questões devem ser tratadas. Primeira, da essência da virtude. Segunda, do
seu sujeito. Terceira, da divisão das virtudes. Quarta, da causa da virtude. Quinta, de certas
propriedades da virtude.
Na primeira questão, quatro artigos se discutem:

## Art. 1 — Se a virtude humana é um hábito.
(II Sent., dist. XXVII a. 1; III, dist. XXIII, q. q, a. 3, qª 1, 3; De Virtut., q. 1, a. 1; II Ethic., lect V).
O primeiro discute-se assim. — Parece que a virtude humana não é um hábito.

1. — Pois, a virtude é o que, na potência, é último, como disse o Filósofo. Ora, o que é último reduz-se
ao gênero a que pertence; assim, o ponto, ao gênero da linha. Logo, a virtude reduz-se ao gênero da
potência e não ao do hábito.

2. — Demais. — Agostinho diz, que a virtude é o bom uso do livre arbítrio. Ora, este uso é um ato. Logo,
a virtude não é um hábito, mas um ato.

3. — Demais. — Merecemos, não pelos hábitos, mas pelos atos; do contrário mereceríamos
continuamente, mesmo dormindo. Ora, merecemos pelas virtudes. Logo, elas não são hábitos, mas
atos.

4. — Demais. — Agostinho diz, que a virtude é a ordem do amor; e que a ordenação chamada virtude
leva-nos a fruir o que deve ser fruído, e usar o que deve ser usado. Ora, a ordem ou ordenação
denomina um ato ou uma relação. Logo, a virtude não é um hábito, mas um ato ou relação.

5. — Demais. — Como há virtudes humanas também as há naturais. Ora, estas não são hábitos, mas
potências. Logo, também não o são as virtudes humanas.
Mas em contrário, o Filósofo ensina que a ciência e a virtude são hábitos.

SOLUÇÃO. — A virtude designa uma certa perfeição da potência. Ora, a perfeição de um ser é
principalmente considerada em relação ao seu fim. Ora, o fim da potência é o ato. Por onde,
consideramos perfeita a potência na medida em que é determinada para o seu ato. Ora, há certas
potências que, em si mesmas, se determinam para os seus atos; tais as potências naturais ativas; e por
isso, estas se chamam em si mesmas virtudes. Porém as potências racionais, próprias do homem, não
são determinadas a uma só operação, mas, são indeterminadas e relativas a muitas. Ora, elas
determinam-se aos atos pelos hábitos, como do sobredito resulta; logo, as virtudes humanas são
hábitos.

RESPOSTA À PRIMEIRA OBJEÇÃO. — Às vezes chama-se virtude aquilo a que ela é relativa, como o seu
objeto ou seu ato; assim como chamamos umas vezes fé àquilo em que acreditamos; outras, à crença
mesma, e outras, ainda, o hábito pelo qual cremos. Por onde, quando dizemos que a virtude é o que, na
potência é último, tomamo-la pelo seu objeto. Pois, aquilo de que a potência é ultimamente capaz é o
ao que dizemos que é relativa a virtude de um ser; assim, a virtude de quem pode carregar cem libras e
não mais é considerada relativamente a essas cem e não a sessenta. E a objeção seria procedente
apenas se a virtude fosse, essencialmente, o que na potência é último.

RESPOSTA À SEGUNDA. — É pelo mesmo fundamento que dizemos ser uma virtude o bom uso do livre
arbítrio; pois, para ele, como para o seu ato próprio, se ordena à virtude. Pois, um ato de virtude não é
mais que o bom uso do livre arbítrio.

RESPOSTA À TERCEIRA. — De duplo modo podemos dizer que merecemos alguma coisa: ou pelo mérito
em si mesmo, como quando dizemos que corremos pela corrida e, deste modo, merecemos pelos atos;
ou quase pelo princípio do merecer, como quando dizemos que corremos pela potência motiva e, neste
sentido, dizemos que merecemos pelas virtudes e pelos hábitos.

RESPOSTA À QUARTA. — A virtude chama-se uma ordem ou ordenação do amor, como aquilo ao que
ela é relativa; pois, pela virtude o amor é ordenado em nós.

RESPOSTA À QUINTA. — As potências naturais são, em si mesmas, determinadas a uma operação; não,
porém as racionais. Por onde não há símile, como já se disse.

## Art. 2 — Se é da essência da virtude humana ser um hábito operativo.
(III Sent., dist. XXIII. Q. 1, a. qª 1).
O segundo discute-se assim. — Parece que não é da essência da virtude humana ser um hábito
operativo.

1. — Pois, diz Túlio, o que se dá com a saúde e a beleza do corpo se dá também com a virtude da alma.
Ora, a saúde e a beleza não são hábitos operativos. Logo, também não o é a virtude.

2. Demais — Há, nos seres naturais, virtude, não só para agir, mas também para existir; pois, vemos
claramente no Filósofo, que certos seres têm a virtude de existir sempre; outros a de existir, não
sempre, mas durante um determinado tempo. Ora, a virtude natural se comporta, nos seres naturais,
como a virtude humana, nos racionais. Logo, também a virtude humana é relativa, não só ao agir, mas
também ao existir.

3. Demais. — O Filósofo diz, que a virtude é uma disposição do perfeito para o ótimo. Ora, o ótimo, para
o qual o homem se dispõe pela virtude, é o próprio Deus, como Agostinho o prova; para o qual ela se
dispõe pela assimilação. Logo, parece que a virtude deve ser denominada uma certa qualidade da alma
ordenada para Deus, enquanto que nos torna semelhantes a ele, e não, ordenada para a operação.
Logo, não é um hábito operativo.
Mas, em contrário, o Filósofo diz, que a virtude de um ser é o que lhe torna boa a operação.

SOLUÇÃO. — A virtude, conforme a significação mesma da palavra, implica uma certa perfeição da
potência, com já se disse. Ora, como há dupla potência — uma relativa ao ser e outra, ao agir — a
perfeição de uma e outra se chama virtude. A potência para o ser, porém, se funda na matéria, que é
um ser potencial; ao passo que a potência para agir se funda na forma, que é o princípio da ação,
porque um ser age na medida em que é atual. Ora, na constituição do homem, o corpo se comporta
como matéria e a alma, como forma. Ora, o homem tem corpo como os brutos, como também tem as
potências comuns ao corpo e à alma. Só as faculdades próprias à alma, i. é, as racionais, é que
pertencem exclusivamente ao homem. Por onde, a virtude humana, de que agora tratamos, não pode
pertencer ao corpo, mas somente ao que é próprio da alma. Logo, ela não implica em ordenar-se para o
ser, mas antes, para a ação. E, portanto, é da essência da virtude humana ser um hábito operativo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO.— O modo da ação é conseqüente à disposição do agente,
pois um ser, assim como é, assim age. Por onde, sendo a virtude o princípio de certas operações, é
necessário preexista no agente, relativamente à virtude, alguma disposição que lhe seja conforme. Ora,
a virtude é que torna a operação ordenada. Por onde, a virtude, em si mesma, é uma disposição
ordenada da alma, pela qual as potências desta se ordenam, de certo modo, uma para as outras e para
o que lhes é exterior. E portanto, a virtude, enquanto disposição conveniente da alma, assimila-se à
saúde e à beleza, que são disposições próprias do corpo. Mas isto não impede que a virtude seja
também um princípio de operação.

RESPOSTA À SEGUNDA. — A virtude relativa ao existir não é própria do homem; mas só a relativa à
atividade da razão, que lhe é própria a ele.

RESPOSTA À TERCEIRA. — A substância de Deus, sendo a sua ação, a suma assimilação do homem com
Deus é fundada em alguma operação. Por onde, como já se disse, a felicidade ou beatitude, pela qual o
homem sobretudo se conforma com Deus, fim da vida humana, consiste na ação.

## Art. 3 — Se é da essência da virtude ser um hábito bom.
(III Sent., dist. XXIII, q. 1, a. 3, qª 1; dist. XXVI, q. 2, a. 1; II Ethic., lect. VI).
O terceiro discute-se assim. — Parece que não é da essência da virtude ser um hábito bom.

1. — Pois, o pecado sempre tem por objeto o mal. Ora, também há uma virtude do pecado, conforme
aquilo do Apóstolo (I Cor 15, 56): a virtude do pecado é a lei. Logo, a virtude nem sempre é um hábito
bom.

2. Demais. — A virtude responde à potência. Ora, esta é relativa, não só ao bem, mas ainda ao mal,
segundo aquilo da Escritura (Is 5, 22): Ai de vós os que sois poderosos para beber vinho, e varões fortes
para beberdes a largos sorvos a ebriedade. Logo, a virtude também é relativa ao bem e ao mal.

3. Demais. — Segundo o Apóstolo (II Cor 12, 9), a virtude se aperfeiçoa na enfermidade. Ora, a
enfermidade é um mal. Logo, a virtude é relativa, não só ao bem, mas ainda, ao mal.
Mas, em contrário, diz Agostinho: Ninguém duvidará que a virtude torne ótima a alma. E o Filósofo diz,
que a virtude torna bom quem a tem bem como as obras que pratica.

SOLUÇÃO. — Como já se disse, a virtude implica a perfeição da potência; e por isso a virtude de um ser
se determina pelo que é ultimamente capaz como ficou estabelecido. Ora, o de que uma virtude é
ultimamente capaz há de necessariamente ser o bem, pois todo mal implica um certo defeito; donde o
dizer Dionísio, que todo mal é uma enfermidade. E por isso é necessário que a virtude de um ser seja
ordenada para o bem. Logo, a virtude humana, que é um hábito imperativo, é um hábito bom e
operativo do bem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como a perfeição, também o bem é empregado
metaforicamente em relação ao mal; assim, falamos de um perfeito e de um bom gatuno ou ladrão,
como se vê claramente no Filósofo. Ora, de acordo com este modo de falar, também a virtude é
empregada metaforicamente em relação ao mal. E assim dizemos que a virtude do pecado é a lei,
enquanto que, por ela, o pecado aumenta ocasionalmente e chega quase ao seu máximo.

RESPOSTA À SEGUNDA. — O mal da embriaguez e do excesso no beber está na falta de ordenação
racional. Ora, pode-se dar que, com a ausência da razão, uma potência inferior venha a ser perfeita
relativamente ao que pertence ao seu gênero, mesmo com repugnância ou ausência da razão. Mas, a
perfeição de uma tal potência, implicando falta de razão, não pode chamar-se virtude humana.

RESPOSTA À TERCEIRA. — A razão se mostra tanto mais perfeita, quanto mais puder vencer ou tolerar
as enfermidades do corpo e das partes inferiores. Por isso dizemos que, a virtude humana, atribuída à
razão, se aperfeiçoa na enfermidade, não, certo, da razão, mas na do corpo e das partes inferiores.

## Art. 4 — Se é exata a definição de virtude comumente dada: a virtude é uma boa qualidade da mente, pela qual vivemos retamente, de que ninguém pode usar mal, e que Deus obra em nós, sem nós.
(II Sent., dist. XXVII, a. 2; De Virtut., q. 1, a. 2).
O quarto discute-se assim. — Parece que não é conveniente a definição de virtude comumente dada:
a virtude é uma boa qualidade da mente, pela qual vivemos retamente, de que ninguém pode usar
mal, e que Deus obra em nós, sem nós.

1. — Pois, a virtude é a bondade do homem, porque torna bom quem a possui. Ora não se pode dizer
que a bondade seja boa, como não se pode dizer que a brancura é branca. Logo, é inexato afirmar que a
virtude é uma boa qualidade.

2. Demais. — Nenhuma diferença é mais comum que o seu gênero, pois ela é que o divide. Ora, o bem é
mais comum que a qualidade, pois que se converte no ente. Logo, o bem não deve entrar na definição
da virtude, como diferença da qualidade.

3. Demais. — Como diz Agostinho tudo o que não nos for comum com os brutos pertence ao espírito.
Ora, também há certas virtudes das partes irracionais, como diz o Filósofo. Logo, nem toda virtude é
uma boa qualidade da mente.

4. Demais. — Parece que a retidão pertence à justiça; por isso os mesmos que se chamam retos se
chamam também justos. Ora, a justiça é uma espécie de virtude. Logo, é inconveniente incluir a idéia de
reto na definição da virtude e dizer: pela qual vivemos retamente.

5. Demais. — Quem se ensoberbece com alguma coisa usa mal dela. Ora muitos se ensoberbecem com
a virtude; pois, diz Agostinho, que a soberba lhes arma ciladas mesmo com as boas obras, para que
pereçam. Logo, é falso que ninguém use mal da virtude.

6. Demais. — O homem se justifica pela virtude. Ora, Agostinho diz, comentando aquilo de João (Jo 14,
12) —e fará outras ainda maiores —: Quem te criou sem ti não te justificará sem ti. Logo, é inexato dizer
que a virtude Deus a obra em nós sem nós.
Mas, em contrário, é a autoridade de Agostinho, de cujas palavras foi tirada a referida definição; e
principalmente do II de lib. Arb. (C.XIX).

SOLUÇÃO. — Esta definição exprime perfeitamente toda a essência da virtude. Pois a essência perfeita
de um ser deduz-se da reunião de todas as suas coisas. Ora, a definição de que se trata compreende
todas as causas da virtude. — Assim, a causa formal da virtude, como de tudo, é deduzida do seu gênero
e da diferença, quando se diz que ela é uma qualidade boa; pois, o gênero da virtude é a qualidade e a
diferença, o bem. Contudo, a definição seria mais conveniente se, em lugar da qualidade, se pusesse o
hábito, que é o gênero próximo. — Em seguida, a virtude não tem matéria pela qual (ex-qua) exista,
nem quaisquer acidentes; mas tem matéria sobre que diz respeito (circa quam) e sobre a qual (in qua)
recai, que lhe constitui o sujeito. A matéria sobre que diz respeito é o objeto da virtude, mas ela não
pode entrar na referida definição da virtude, porque pelo seu objeto a virtude é especificamente
determinada, e agora tratamos de uma definição em geral da virtude. E por isso põe-se o sujeito em
lugar da causa material, quando se diz que a virtude é uma boa qualidade da mente. — Em terceiro
lugar, o fim da virtude, que é um hábito operativo, é a obra mesma. Devemos porém notar que certos
hábitos operativos — os viciosos — sempre dizem respeito ao mal; outros, ora ao bem, ora ao mal,
como a opinião, que tem por objeto tanto o verdadeiro como o falso. Mas, a virtude é um hábito
sempre referente ao bem. E portanto, para discernir-se a virtude dos hábitos que são sempre relativos
ao mal, a definição diz — pelo qual vivemos retamente; e para discernir-se dos que dizem respeito, ora,
ao mal e, ora, ao bem, diz — de que ninguém pode usar mal. — E por fim, a causa eficiente da virtude
infusa, de que trata a definição, é Deus. Por isso a definição diz — que Deus obra em nós, sem nós; e se
esta parte da definição fosse eliminada, o restante seria comum a todas as virtudes, tanto as adquiridas
como as infusas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O que primeiramente cai sob a apreensão do intelecto é
o ser. Por isso, a tudo o que apreendemos atribuímos o ser; e por conseguinte, a unidade e a bondade,
que no ser se convertem. Por onde, dizemos que a essência é ser, uma e boa; e que a unidade é ser,
uma e boa; e o mesmo dizemos da bondade. Mas, isto não se dá com as formas especiais, como a
brancura e a saúde; pois nem tudo o que apreendemos sob a noção de branco, apreendemos também
sob a de são. Devemos contudo considerar que, assim como os acidentes e as formas não subsistentes
se chamam entes, não porque tenham por si mesmos o ser, mas porque por eles alguma coisa existe,
assim também se consideram bons ou unos, não, certo, por alguma outra bondade ou unidade, mas
porque, por eles, algum ser é bom ou uno. Assim, pois, a virtude é considerada boa porque, por ela,
algum ser é bom.

RESPOSTA À SEGUNDA. — O bem incluído na definição da virtude não é o bem comum conversível no
ente e que é mais que uma qualidade; mas o bem da razão, no sentido em que Dionísio diz, que o bem
da alma é ser racional.

RESPOSTA À TERCEIRA. — A virtude não pode existir na parte irracional da alma, senão enquanto esta
participa da razão, como já se disse. Por onde, a razão ou mente é o sujeito próprio da virtude humana.

RESPOSTA À QUARTA. — A retidão é própria da justiça, que tem por objeto as coisas exteriores que
servem ao uso do homem e constituem a matéria própria dela, como a seguir se dirá. Ao passo que a
retidão, que implica em ordenar-se ao fim devido e à lei divina, da vontade humana, como já dissemos,
é comum a todas as virtudes.

RESPOSTA À QUINTA. — Podemos usar mal da virtude como objeto; assim, quando pensamos mal dela
ou a odiamos ou com ela nos ensoberbecemos; não porém como princípio do uso, de modo que seja
mau o ato da virtude.

RESPOSTA À SEXTA. — A virtude infusa é causada em nós sem a nossa cooperação, mas não sem o
nosso consentimento. E neste sentido é que devemos entender a parte da definição, que diz — que
Deus obra em nós sem nós. E quanto aos nossos atos, Deus os causa em nós, mas não sem nós; pois ele
age em toda vontade e natureza.