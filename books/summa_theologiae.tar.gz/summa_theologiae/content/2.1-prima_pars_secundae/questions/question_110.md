# Questão 110: Da graça de Deus quanto à sua essência.
Em seguida devemos tratar da graça de Deus, quanto à sua essência.
E nesta questão, discutem-se quatro artigos:

## Art. 1 — Se a graça produz algum efeito na alma.
[II Sent., dist. XXVI, a. 1; III Cont. Gent., cap. CL; De Verit., q. XXVII, a. 1].
O primeiro discute-se assim. — Parece que a graça não produz nenhum efeito na alma.

1. — Pois, no mesmo sentido em que se diz que temos a graça de Deus, também se diz que temos a de
uma pessoa qualquer; donde o dizer a Escritura (Gn 39, 21): O Senhor deu a José a graça na presença do
carcereiro - mor. Ora, quando sediz que alguém recebeu graça de outrem, isso nenhum efeito produz
em quem a recebeu; mas, significa, que há uma certa aceitação em quem a dispensou. Logo, quando se
diz, que o homem recebeu graça de Deus, isso nenhum efeito lhe produz na alma, significando apenas a
aceitação divina.

2. Demais. — Como a alma vivifica o corpo, assim Deus, a alma; por isso, diz a Escritura (Dt 30, 20): Deus
é a tua vida. Ora, a alma vivifica o corpo imediatamente. Logo, nenhum meio termo há entre Deus e a
alma, e portanto, a graça não produz na alma nenhum efeito.

3. Demais. — Ao lugar da Escritura (Rm 1, 7) — Graça vos seja dada e paz — diz a Glosa: Graça, i. é,
remissão dos pecados. Ora, a remissão dos pecados nenhum efeito produz na alma, só fazendo com que
Deus não impute o pecado, conforme a Escritura (Sl 31, 2): Bem aventurado o homem a quem o Senhor
não imputou pecado. Logo, também a graça nada produz na alma.
Mas, em contrário. — A luz nenhum efeito produz no objeto iluminado. Ora, a graça é uma luz da alma,
e por isso diz Agostinho: A luz da verdade abandona o que prevaricou contra a lei, o qual, abandonado,
se torna cego. Logo, a graça produz algum efeito na alma.

SOLUÇÃO. — Conforme ao modo comum de falar, a graça pode ser tomada em tríplice acepção.
Primeiro, como amor de outrem; assim, costuma-se dizer que um soldado tem a graça do rei, para
significar que o rei o tem na sua graça. Segundo, na acepção de um dom gratuitamente dado, e assim
costumamos dizer: Faço-te esta graça. Terceiro, como recompensa de um benefício gratuitamente feito;
e assim quando se diz que damos graças pelos benefícios. Ora, destas três acepções, a segunda depende
da primeira; pois, do amor com que temos alguém em nossa graça, procede o que gratuitamente lhe
fazemos. E da segunda procede a terceira, porque dos benefícios gratuitamente feitos procede a ação
de graças.
Ora, quanto às duas últimas acepções, é manifesto, que a graça produz em quem a recebeu, primeiro, o
dom mesmo, gratuitamente feito; e segundo, reconhecimento desse dom. Mas na primeira acepção, é
preciso fazer-se uma diferença entre a graça de Deus e a humana. Pois, como o bem da criatura procede
da vontade divina, do amor de Deus, pelo qual quer o bem da criatura, há de decorrer algum bem para
esta. Ao passo que a vontade do homem se move pelo bem preexistente nas coisas; e por isso o seu
amor não produz totalmente o bem do seu objeto, mas, ao contrário, o pressupõe, parcial ou
totalmente. Por onde é claro, que todo bem da criatura resulta de algum amor de Deus, sendo esse bem
entretanto produzido e não, coexistente com o amor eterno. Ora, nessa diferença de bens se funda a do
amor de Deus pela criatura. Assim, um é o amor comum, com que ama todas as coisas, que existem, no
dizer da Escritura (Sb 11, 25), e, pelo qual, dá o ser natural às coisas criadas. Outro é o amor especial,
pelo qual eleva a criatura racional a participar do bem divino, condição essa que lhe excede a natureza.
E por esse amor dizemos que ela ama a Deus, absolutamente falando, porque por ele Deus quer,
absolutamente, o bem eterno da criatura, que é Ele próprio.
Assim, pois, quando se diz que o homem tem a graça de Deus, significa isso um dom sobrenatural,
procedente de Deus para o homem. — Mas às vezes também se chama graça de Deus ao próprio e
eterno amor divino; e nessa acepção é que se considera a graça da predestinação, pela qual Deus
escolheu certos, ou os predestinou, gratuitamente e não, por méritos deles. Tal é o que diz a Escritura
(Ef 1, 5): Predestinou-nos para sermos seus filhos adotivos em louvor e glória da sua graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando se diz, que alguém tem a graça de outrem, ou a
de Deus, entende-se que há, no primeiro, algo de agradável ao segundo, ou a Deus, mas
diferentemente. Pois, o que em alguém é agradável a outrem é pressuposto ao amor deste. Ao
contrário, o que há no homem de agradável a Deus, já é causado pelo amor divino.

RESPOSTA À SEGUNDA. — Deus é a vida da alma, a modo de causa eficiente; ao passo que a alma é a
vida do corpo, a modo de causa formal. Ora, entre a matéria e a forma não há nenhum meio termo, pois
esta, por si mesma, informa a matéria ou o sujeito. Ao passo que o agente informa o sujeito, não pela
sua substância, mas pela forma, que causa na matéria.

RESPOSTA À TERCEIRA. — Agostinho diz: Quando disse que a graça consiste na remissão dos pecados e
a paz, na reconciliação com Deus, isso não significa que a paz e a reconciliação não pertençam à graça
geral, mas que, especialmente, a graça significa a remissão dos pecados. Logo, nem só a remissão dos
pecados pertence à graça, mas também, muitos outros dons de Deus. Por onde, a remissão dos pecados
não se opera sem algum efeito divinamente causado em nós, como a seguir se demonstrará (q. 113, a.
2).

## Art. 2 — Se a graça é uma qualidade da alma.
[II Sent., dist. XXVI, a. 2; a. e, ad 1; III Cont. Gent., cap. CL; De Verit., q. 27, a. 2, ad 7].
O Segundo discute-se assim. — Parece que a graça não é uma qualidade da alma.

1. — Pois, nenhuma qualidade age sobre o seu sujeito, pois, a ação dela, não podendo existir sem a
deste, haveria necessariamente o sujeito de agir sobre si mesmo. Ora, a graça age sobre o homem,
justificando-o. Logo, não é uma qualidade.

2. Demais. — A substancia é mais nobre que a qualidade. Ora, a graça é mais nobre que a natureza da
alma; pois, com a graça, podemos muitas coisas, para o que não basta a natureza, segundo já se disse
(q. 109, a. 1, a. 2, a. 3). Logo, a graça não é uma qualidade.

3. Demais. — Nenhuma qualidade permanece depois de desaparecida do sujeito. Ora, a graça
permanece. Pois, não se corrompe porque então voltaria ao nada; e demais é criada, sendo por isso,
chamada nova criatura. Logo, a graça não é uma qualidade.
Mas, em contrário, aquilo da Escritura (Sl 103, 15): — Para que faça brilhar o seu rosto com o azeite —
diz a Glosa: a graça é o brilho da alma, que concilia o santo amor. Logo, o brilho da alma, como a beleza
do corpo, é uma qualidade. Logo, também a graça o é.

SOLUÇÃO. — Como já foi estabelecido (a. 1), quando se diz que alguém tem a graça de Deus, quer-se
significar que experimenta um efeito gratuito da vontade de Deus. Pois, como já dissemos (q. 109, a. 1),
o homem é ajudado gratuitamente pela vontade de Deus, de dois modos. Primeiro, quando Deus move
a alma a conhecer, querer ou fazer alguma coisa. E deste modo, esse efeito gratuito, no homem, não é
uma qualidade, mas um movimento da alma; pois, como diz Aristóteles, o movimento é a ação do motor
no móvel. — De outro modo, o homem é ajudado pela vontade gratuita de Deus, quando Deus infunde
na alma um dom habitual. E isto por não ser conveniente seja Deus menos providente para com aqueles
que, por amor, quer que possuam um bem sobrenatural, do que para com as criaturas destinadas, pelo
seu amor, a possuírem um bem natural. Ora, Ele provê às criaturas naturais, não só movendo-se aos
seus atos naturais, mas ainda conferindo-lhes certas formas e virtudes, que lhes são princípio dos atos, e
as inclinam para os seus movimentos naturais. E assim, os movimentos, com que Deus as move, tornam-
se conaturais e fáceis, segundo a palavra da Escritura (Sb 8, 1): E dispôs todas as coisas com
suavidade. Logo, com maior razão, Deus infunde, nos seres que move à consecução de um bem
sobrenatural eterno, certas formas ou qualidades sobrenaturais, pelas quais os move, suave e
prontamente, à consecução do bem eterno. Por onde, o dom da graça é uma certa qualidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que a graça, como qualidade, age na alma, não a
modo de causa eficiente, mas de causa formal, assim como a justiça torna justo, e a brancura, branco.

RESPOSTA À SEGUNDA. — A substância de um ser ou lhe constitui a natureza mesma, ou faz parte dela.
E é neste segundo sentido que se chama substância à matéria ou à forma. E sendo a graça superior à
natureza humana, não pode ser substância ou forma substancial, mas é a forma acidental da alma. Ora,
o que existe em Deus substancialmente realiza-se, acidentalmente, na alma participante da divina
bondade, como bem o demonstra a ciência. Por onde, por isso mesmo que a alma participa
imperfeitamente da divina bondade, essa participação, que é a graça, a alma a tem de modo mais
imperfeito do que o modo porque tem a sua subsistência mesma. É porém mais nobre que a natureza
da alma, por ser expressão ou participação da divina bondade; mas, não o é, quanto ao modo de ser.

RESPOSTA À TERCEIRA. — Como diz Boécio, a essência do acidente consiste em existir em outro ser. Por
onde, todo acidente chama-se ente, não por ser ente em si mesmo, mas por fazer com que alguma coisa
exista; e, por isso, se chama antes ente de um ente, que propriamente, ente como diz Aristóteles. E
como só o ente é que pode vir a ser ou corromper-se nenhum acidente, propriamente falando, vem a
ser nem se corrompe. Mas diz-se que vem a ser ou se corrompe, na medida em que, no que lhe diz
respeito, o seu sujeito começa ou acaba atualmente de existir. Ora, sendo assim, também se diz que a
graça é criada, por serem os homens, por ela criados, i. é, constituídos do nada, um ser novo, i. é, não
pelos seus méritos, conforme a Escritura (Ef 2, 10): somos criados em Jesus Cristo para boas obras.

## Art. 3 — Se a graça é o mesmo que a virtude.
[II Sent., dist. XXVI, a. 4; De Verit., q. 27, a. 2].
O terceiro discute-se assim. — Parece que a graça é o mesmo que a virtude.

1. — Pois, como diz Agostinho, a graça operante é a fé, que obra por amor. Ora, a fé que obra pelo
amor, é uma virtude. Logo, a graça também o é.

2. Demais. — Ao que convém a definição convém também o definido. Ora, as definições dadas, da
virtude, pelos santos ou pelos filósofos, convêm à graça; pois também ela torna bom o sujeito e a sua
obra; também ela é uma boa qualidade da mente, pela qual vivemos retamente, etc. Logo, a graça é
uma virtude.

3. Demais. — A graça é uma qualidade. Ora, é manifesto que não pertence à quarta espécie da
qualidade, que é a forma e a figura fixa de um objeto; pois, não pertence ao corpo. Nem à terceira,
porque não é paixão ou qualidade possível, que pertence à parte sensitiva da alma, como o prova
Aristóteles; pois a graça principalmente está na alma. Nem, por fim, à segunda espécie, que é a potência
ou impotência da natureza; pois, é superior à natureza e não pode buscar o bem e o mal, como a
potência natural. Logo, há de pertencer à primeira espécie, que é o hábito ou disposição. Ora, os hábitos
da alma são as virtudes, pois, a própria ciência é, de certo modo, uma virtude. Logo, a graça é o mesmo
que a virtude.
Mas, em contrário. — Se a graça é uma virtude, há de ser, por excelência, uma das três virtudes
teologais. Ora, não é a fé, nem a esperança que podem existir sem a graça santificante. Nem a caridade,
porque a graça prepara a caridade, como diz Agostinho. Logo, a graça não é uma virtude.

SOLUÇÃO. — Certos ensinaram que a graça é a essência idêntica à virtude, desta diferindo só
racionalmente. Pois tira essa denominação de tornar o homem agradável a Deus, ou por ser dada
gratuitamente; ao passo que a virtude confere a perfeição para agir bem. E esta parece ter sido a
opinião do Mestre das Sentenças.
Mas, é inadmissível a quem refletir atentamente na essência da virtude. Pois, como diz o Filósofo, a
virtude é uma disposição do que é perfeito; chamo perfeito ao que é disposto segundo a natureza. Por
onde se vê que a virtude de um ser é assim chamada em relação a alguma natureza preexistente; isto é,
quando está disposto do modo conveniente à sua natureza. Ora, é manifesto que as virtudes adquiridas
pelos atos humanos, de que já tratamos (q. 55 ss), são disposições pelas quais o homem se ordena
convenientemente à natureza que o torna homem. Ao passo que as virtudes infusas o dispõem de modo
mais alto e para um fim mais elevado. Por onde, hão de também dispô-lo em ordem a uma natureza
mais alta, i. é, à natureza divina participada, chamada lume da graça, conforme a escritura (2 Pd 1,
4): Comunicou-nos as mui grandes e preciosas graças que tinha prometido, para que por elas sejais
feitos participantes da natureza divina. E por termos recebido tal natureza é que nos consideramos
regenerados, como filhos de Deus.
Assim, pois, como o lume natural da razão é algo de superior às virtudes adquiridas, assim denominadas
por se lhe ordenarem para ele; assim, o lume da graça, que é uma participação da natureza divina, é
algo de superior às virtudes infusas, dele derivadas e ao qual se ordenam. Por isso, o Apóstolo diz (Ef 5,
8): Noutro tempo eram trevas, mas agora sois luz no Senhor: andai como filhos da luz. Por onde, assim
como as virtudes adquiridas aperfeiçoam o homem para proceder segundo a luz natural da razão, assim
as virtudes infusas, para proceder de acordo com a luz da graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A fé, que obra o amor, Agostinho a denomina graça;
porque o ato da fé, que assim obra, é o primeiro ato pelo qual se manifesta a graça santificante.

RESPOSTA À SEGUNDA. — O bem, que entra na definição da virtude, é assim chamado relativamente à
conveniência com alguma natureza preexistente, essencial ou participada. Ora, não assim o bem é
atribuído à graça, mas como á raiz da bondade do homem, segundo já se disse.

RESPOSTA À TERCEIRA. — A graça se reduz à primeira espécie de qualidade. Nem é o mesmo que a
virtude, mas é um certo hábito, pressuposto às virtudes infusas, como princípio e raiz delas.

## Art. 4 — Se a graça está na essência da alma como no sujeito, ou em alguma das duas potências.
[Sent., dist. XXVI, a. 3; IV, dist, IV, q. 1, a. 3, qª 3, ad 1; De Verit., q. 27, a. 6].
O quarto discute-se assim. — Parece que a graça não está na essência da alma, como no sujeito, mas
numa das suas potências.

1. — Pois, diz Agostinho, a graça está para a vontade, ou para o livre arbítrio, como o cavaleiro para o
cavalo. Ora, à vontade ou livre arbítrio é uma potência, como já dissemos na Primeira Parte (q. 83, a. 2).
Logo, a graça está na potência da alma como no seu sujeito.

2. Demais. — Da graça derivam os méritos do homem, como diz Agostinho. Ora, o mérito depende do
ato procedente de alguma potência. Logo, a graça é a perfeição de alguma das potências da alma.

3. Demais. — Se a essência da alma fosse o sujeito próprio da graça, a alma haveria necessariamente de,
na sua essência, ser capaz da graça. Ora, isto é falso, porque daí resultaria que toda alma é capaz da
graça. Logo, a essência da alma não é o sujeito próprio da graça.

4. Demais. — A essência da alma é-lhe anterior às potências. Ora, o anterior é concebível
independentemente do posterior. Donde resulta que podemos conceber a graça, na alma, sem
recebermos nenhuma parte ou potência da alma, e nem à vontade, nem o intelecto, nem qualquer
faculdade. Ora, isto é inadmissível.
Mas, em contrário, regenerados pela graça, tornamo-nos filhos de Deus. Ora, a geração termina, antes
na essência, que nas potências. Logo, a graça está na essência da alma, antes de lhe estar nas potências.

SOLUÇÃO. — Esta questão depende da precedente. Pois, se a graça é o mesmo que a virtude, há de
necessariamente estar nas potências da alma como no sujeito; porque elas são o sujeito próprio da
virtude, como já dissemos (q. 56, a. 1). Se, ao contrário, difere da virtude, não se pode dizer que as
potências da alma sejam o sujeito dela; porque toda perfeição das potências da alma tem natureza de
virtude, como já dissemos (q. 55, a. 1; q. 56, a. 1). Donde se conclui, que a graça, assim como tem
prioridade sobre a virtude, tem também um sujeito às potências da alma, a saber, a essência desta. Ora,
pela potência intelectiva e pela virtude da fé, o homem participa do conhecimento divino; e, pela
potência da vontade e pela virtude da caridade, participa do amor divino. Assim também, pela natureza
da alma participa, por uma certa semelhança, da natureza divina, regenerando-se, de algum modo, e
como criada de novo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como da essência da alma decorrem as suas
potências, que são os princípios das obras; assim também, da graça decorrem virtudes para as potências
da alma, que a movem aos seus atos. E sendo assim, a graça está para a vontade como o motor, para o
móvel, ou, o que é o mesmo, como o cavaleiro, para o cavalo; não, porém, como o acidente, para a
substância.
E daqui se deduz também clara a RESPOSTA À SEGUNDA OBJEÇÃO. — Pois, a graça é, mediante as
virtudes, o princípio das obras meritórias; assim como a essência da alma é, mediante as potências, o
princípio das operações vitais.

RESPOSTA À TERCEIRA. — Alma é o sujeito da graça, enquanto pertencente à espécie da natureza
intelectual ou nacional. Ora, a alma não se especifica por meio de alguma potência; pois as potências
são propriedades naturais da alma, resultantes da espécie. E portanto, a alma, por essência, difere
especificamente das almas dos brutos e das plantas. E por isso, de ser a essência da alma humana
sujeito da graça não se segue possa qualquer alma ser tal sujeito; pois, isso convém à essência da alma,
enquanto pertencente a uma determinada espécie.

RESPOSTA À QUARTA. — Sendo as potências da alma propriedades naturais, resultantes da espécie, a
alma não pode existir sem elas. Mas, dado que o pudesse, ainda a alma seria chamada, conforme a sua
espécie, intelectual ou racional. Não por ter essas potências, atualmente, mas por causa da sua essência
específica, de que naturalmente decorrem tais potências.