# Questão 75: Das causas dos pecados em geral.
Em seguida devemos tratar das causas dos pecados. E, primeiro, em geral. Segundo, em especial.
Sobre a primeira questão discutem-se quatro artigos:

## Art. 1 — Se o pecado tem causa.
(I, q. 49, a. 1; II Sent., dist. XXXIV , a. 3)
O primeiro discute-se assim. ― Parece que o pecado não tem causa.

1. ― Pois, o pecado é essencialmente um mal, como já se disse (q. 71, a. 6). Ora, o mal não tem causa,
como diz Dionísio. Logo, o pecado igualmente não tem.

2. Demais. ― Causa é aquilo de que resulta necessariamente algum efeito. Ora, o que resulta
necessariamente não é pecado, porque todo pecado é voluntário. Logo, o pecado não tem causa.

3. Demais. ― Se o pecado tem causa, esta há-de ser ou o bem ou o mal. Ora, aquele, não, porque o bem
não produz senão o bem; pois, não pode a árvore boa dar maus frutos, como diz a Escritura (Mt 7,
18).Semelhantemente, também o mal não pode ser causa do pecado, pois o mal da pena resulta do
pecado e o da culpa identifica-se com ele. Logo, o pecado não tem causa.
Mas, em contrário. ― Tudo o que é feito tem causa; pois, como diz a Escritura (Jó 5, 6): Nada se faz na
terra sem causa. Ora, o pecado é feito, pois, é o dito, o feito ou o desejado contra a lei de Deus. Logo, o
pecado tem causa.

SOLUÇÃO. ― O pecado é um ato desordenado. Ora, enquanto ato, pode ter em si mesmo causa, como
qualquer outro ato. E enquanto desordenado, tem causa do modo por que a pode ter a negação ou a
privação. Ora, a qualquer negação podemos atribuir dupla causalidade. Pois, primeiro, a falta de causa,
i. é, a negação da própria causa é causa da negação em si mesma, pois, da remoção da causa resulta a
remoção do efeito; assim, a causa da obscuridade é a ausência do sol. De outro modo, a causa da
afirmação, da qual resulta a negação, é a causa acidental da negação conseqüente; assim, o fogo,
causando calor, como tendência principal, causa conseqüentemente a privação da frigidez. E destas
duas causas, a primeira é suficiente a produzir a simples negação. Mas, como a desordem do pecado e
de qualquer mal não é simples negação, mas privação daquilo que o ser devia naturalmente ter,
necessariamente tal desordem terá uma causa agente acidental. Pois, o que é natural e deve subsistir
nunca poderá deixar de existir senão em virtude de alguma causa impediente. E, deste modo, costuma-
se dizer que o mal, consistente numa privação, tem causa deficiente ou age por acidente. Ora, toda
causa agente acidental se reduz à outra, essencial. E como o pecado, e no concernente a sua desordem,
tem causa agente acidental; e no concernente ao ato, causa agente essencial, resulta que a sua
desordem é conseqüência da causa mesma do ato. Portanto, a vontade, carecente da direção da regra
racional e da regra da lei divina, e aspirando a algum bem mutável, causa um ato pecaminoso em si
mesmo, causando, porém, a desordem do mesmo, por acidente, e extra-intencional. Pois, a falta de
ordem no ato provém da falta de direção da vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O pecado não significa só a privação mesma do bem,
que é a desordem, mas também o ato sujeito a tal privação, que é essencialmente um mal. E como esse
ato assim considerado tenha causa, já o dissemos.

RESPOSTA À SEGUNDA. ― Para que a definição aduzida de causa deve verificar-se universalmente, é
preciso que seja entendida como aplicada à causa eficiente e não impedida. Pois pode um efeito ter a
sua causa eficiente, e contudo não resultar necessariamente dela, por via de algum impedimento
sobreveniente. Do contrário, seguir-se-ia que tudo se produz necessariamente, como o diz claramente
Aristóteles. Assim pois, embora o pecado tenha causa, daí não se segue seja ele necessário, pois o efeito
dela pode ficar impedido.

RESPOSTA À TERCEIRA. ― Como já se disse, a vontade, sem a aplicação da regra da razão ou da lei
divina, é causa do pecado. Ora, não aplicar a regra da razão ou da lei divina não é, em si e
essencialmente, mal, nem pena, nem culpa, antes de se praticar o ato. Por onde, a esta luz, o mal não é
a causa do primeiro pecado, mas, um certo bem, com ausência de certo outro.

## Art. 2 — Se o pecado tem causa interior.
O segundo discute-se assim. ― Parece que o pecado não tem causa interior.

1. ― Pois, o que é interior a um ser sempre lhe está presente. Portanto, se o pecado tivesse causa
interior, o homem pecaria sempre, porque, posta a causa, resulta o efeito.

2. Demais. ― Nada pode ser causa de si mesmo. Ora, os movimentos interiores do homem é que
constituem o pecado. Logo, não são causa deste.

3. Demais. ― O que é interior ao homem ou é natural ou é voluntário. Ora, o natural não pode ser causa
do pecado, por ser este contrário à natureza, como diz Damasceno. E o voluntário, se for desordenado,
já é pecado. Logo, nada de intrínseco pode ser causa do primeiro pecado.
Mas, em contrário, Agostinho diz que o voluntário é causa do pecado.

SOLUÇÃO. ― Como já dissemos (a. 1), devemos deduzir do ato mesmo a causa em si do pecado. Ora,
podemos distinguir a causa interior mediata e imediata do ato humano. A sua causa imediata é a razão e
a vontade, pela qual o homem é dotado de livre arbítrio. A causa remota é a apreensão da parte
sensitiva e também o apetite sensitivo. Pois, assim como pelo juízo da razão e de acordo com ela, a
vontade se move para o seu objeto, assim também pela apreensão do sentido, o apetite sensitivo se
inclina para o ser, inclinação que às vezes arrasta a vontade e a razão, como a seguir se estabelecerá
claramente (q. 77, a. 1). Por onde, podemos assinalar uma dupla causa interior do pecado: a próxima,
relativa à razão e à vontade; e a remota, concernente à imaginação ou ao apetite sensitivo.
Mas, como já se disse (a. 1), a causa do pecado é algum bom motivo aparente, mas, a que falta o motivo
devido, i. é, a regra da razão ou da lei divina. Por onde, o motivo mesmo, que é o bem aparente,
depende da apreensão do sentido e do apetite; e, por outro lado, a ausência mesma da regra devida
depende da razão, naturalmente levada à consideração dessa regra. A perfeição porém do ato
voluntário pecaminoso, depende da vontade, pois o ato mesmo da vontade, com as premissas supostas,
já é pecaminoso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O que é intrínseco, como potência natural, sempre está
presente; ao passo que nem sempre o está o intrínseco como ato interior do apetite ou da virtude
apreensiva. Ora, a potência mesma da vontade é causa potencial do pecado, a qual porém se atualiza
pelos movimentos precedentes, da parte sensitiva, primeiro, e, conseqüentemente, da razão. Pois, por
isso mesmo que um objeto é proposto como desejável ao sentido, a razão, às vezes, cessa de considerar
a regrar devida; e então, a vontade pratica o ato pecaminoso. E portanto, como os movimentos
precedentes nem sempre são atuais, também o pecado nem sempre há-de sê-lo.

RESPOSTA À SEGUNDA. ― Nem todos os movimentos interiores são da substância do pecado,
consistente principalmente num ato da vontade; mas, uns precedem o pecado, e outros lhe são
conseqüentes.

RESPOSTA À TERCEIRA. ― A causa do pecado, como potência produtora do ato, é natural. E o
movimento da parte sensitiva, donde resulta o pecado, às vezes também o é, como quando pecamos
desejando a comida. Mas vem a ser pecado inatural, por lhe faltar a regra natural a que o homem, pela
sua natureza, deve atender.

## Art. 3 — Se o pecado tem causa exterior.
(Infra, q. 80, a. 1, 3; De Malo, q. 3, a. 3, 4).
O terceiro discute-se assim. ― Parece que o pecado não tem causa exterior.

1. ― Pois, o pecado é voluntário. ― Ora, voluntário é o que depende de nós, e portanto não tem causa
exterior.

2. Demais. ― Como a natureza, também a vontade é um princípio interior. Ora, na ordem da natureza, o
pecado não procede senão de uma causa interior; assim, os partos monstruosos provêm da corrupção
de algum princípio interno. Logo, também na ordem moral, o pecado não provém senão de causa
interior. Logo, não tem causa exterior.

3. Demais. ― Multiplicada a causa, multiplicam-se os efeitos. Ora, quanto mais e maiores as causas
exteriores, que nos induzem a pecar, tanto menos se nos imputa como pecado aquilo que
desordenadamente praticamos. Logo, nada de exterior é causa do pecado.
Mas, em contrário, diz a Escritura (Nm 31, 16): Não são elas as que seduziram os filhos de Israel; e as
que vos fizeram violar a lei do Senhor pelo pecado de Fogor. Logo, pode o pecado ter uma causa
exterior.

SOLUÇÃO. ― Como já dissemos (a. 2), são causas interiores do pecado: a vontade, donde tira o ato
pecaminoso a sua plenitude; a razão, desviada da regra devida; e a inclinação do apetite sensitivo. Por
onde, de tríplice maneira, poderia ser extrínseca a causa do pecado: pela moção imediata da vontade,
em si mesma, ou da razão, ou do apetite sensitivo. ― Ora, como já dissemos (q. 9, a. 6), só Deus pode
mover interiormente a vontade; e Deus não pode ser causa do pecado, segundo mais adiante se
demonstrará (q. 79, a. 1). ― Donde se conclui, que não pode ser exterior a causa do pecado, a não ser
movendo a razão, como quando o homem ou o demônio nos persuade ao pecado; ou movendo o
apetite sensitivo, como o é o caso de certos sensíveis externos, motores do apetite sensitivo. ― Mas
nem a persuasão exterior relativa ao que devemos fazer nos move necessariamente a razão. Nem, por
outro lado, os objetos exteriores propostos movem necessariamente o apetite sensitivo, a não ser que
este esteja disposto de certo modo; e contudo, também esse apetite não move necessariamente a razão
nem a vontade. ― Portanto, pode ser exterior a causa incitante ao pecado; não contudo induzindo a ele
suficientemente, porque a causa completa e suficiente do pecado é só a vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Por isso mesmo que os objetos exteriores conducentes
ao pecado não agem suficiente e necessariamente, é que se conclui a nossa capacidade de pecar ou
não.

RESPOSTA À SEGUNDA. ― O admitir-se uma causa interior do pecado, não exclui a exterior; pois, a
causa exterior não é causa do pecado, senão mediante a interior, como já se disse.

RESPOSTA À TERCEIRA. ― Multiplicadas as causas exteriores conducentes ao pecado, multiplicam-se os
atos pecaminosos; pois muitas destas causas inclinam muitas vezes a tais atos. Mas isso diminui a
culpabilidade, consistente em haver em nós algo de voluntário.

## Art. 4 — Se o pecado é causa do pecado.
(II Sent., dist. XXXVI, a. 1; dist. XLII, q. 2, a 1, 3; De Malo, q. 8, a 1; Ad Roman., cap 1, lect. VII)
O quarto discute-se assim. ― Parece que o pecado não é causa do pecado.

1. ― Pois, há quatro gêneros de causas, das quais nenhuma pode levar a ser o pecado causa do pecado.
Assim, o fim implica essencialmente o bem, e este não pode existir no pecado, mau por essência. Pela
mesma razão, pecado também não pode ser a causa eficiente, pois o mal não é causa agente, mas, é
fraco e impotente, como diz Dionísio. Por fim, a causa material e a formal exercem as suas influencias só
nos corpos naturais; logo, o pecado não pode ter causa material nem formal.

2. Demais. ― É próprio da causa perfeita agir semelhantemente a si mesma, como diz Aristóteles. Ora, o
pecado é por essência imperfeito. Logo, não pode ser causa do pecado.

3. Demais. ― Se um pecado for causa de outro, este será, pela mesma razão, causa de outro, e assim ao
infinito, o que é inadmissível. Logo, o pecado não é causa do pecado.
Mas, em contrário, Gregório diz: O pecado que não é delido logo pela penitência é pecado e causa do
pecado.

SOLUÇÃO. ― O pecado, como ato, tendo causa, um será causa de outro, do mesmo modo por que pode
um ato humano ser causa de outro. Logo, um pecado pode ser causa de outro relativamente aos quatro
gêneros de causas. ― Primeiro, ao modo da causa eficiente ou motora, por si ou por acidente. Por
acidente, no sentido de considerarmos motor acidental o removente de um impedimento. Pois quando,
por um ato pecaminoso, perdemos a graça, a caridade, a verecúndia ou seja o que for, que afasta do
pecado, caímos por isso em outro pecado; e assim o primeiro é causa acidental do segundo. É causa por
si como quando um ato pecaminoso nos dispõe a praticar mais facilmente outro ato semelhante; pois,
os atos são os causadores das disposições e dos hábitos, que inclinam a outros atos semelhantes. ―
Quanto ao gênero da causa material, um pecado é causa de outro, ao qual prepara a matéria; assim, a
avareza prepara a matéria ao litígio; e este quase sempre, é provocado pelas riquezas acumuladas. ―
No concernente ao gênero da causa final, um pecado é causa de outro, enquanto, por causa do fim de
um pecado, cometemos outro; assim, quem praticasse a simonia tendo por fim a ambição, ou a
fornicação por causa do furto. ― E como, na ordem moral, o fim dá a forma, como já se disse (q. 1, a. 2 ;
q. 18, a. 6 ; q. 72, a. 3), daqui se segue que um pecado é causa formal de outro. Pois, no ato da
fornicação praticado em vista do furto, aquela é o elemento material, e este o formal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O pecado, sendo desordenado, é essencialmente um
mal, mas como determinado ato, encerra algum bem, ao menos como fim aparente. E assim, enquanto
ato, pode ser causa final e efetiva de outro pecado, embora não, enquanto desordenado. Quanto à
matéria, o pecado a tem não como a de que procede (ex qua), mas, como aquela sobre a qual recai
(circa quam). E a forma ele a tem, como fim. Portanto, segundo os quatro gêneros de causas, o pecado
pode ser considerado causa do pecado, como ficou dito.

RESPOSTA À SEGUNDA. ― Pela sua desordem, o pecado é imperfeito, por imperfeição moral; mas como
ato, pode ter a perfeição de natureza. E a esta luz, pode ser causa do pecado.

RESPOSTA À TERCEIRA. ― Nem toda causa do pecado é pecado. Por onde, não é necessário proceder-se
ao infinito, mas, podemos chegar a um pecado, cuja causa não é outro pecado.