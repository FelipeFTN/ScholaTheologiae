# Questão 109: Da necessidade da graça.
Em seguida devemos tratar do princípio exterior dos atos humanos, i. é Deus, enquanto, com a sua
graça, nos ajuda a proceder retamente. E primeiro, devemos tratar da graça de Deus. Segundo, da sua
causa. Terceiro, dos seus efeitos.
O primeiro tratado será tripartido. Assim, primeiro, trataremos da necessidade da graça. Segundo, da
graça, quanto à sua essência mesma. Terceiro, da sua divisão.
Na primeira questão discutem-se dez artigos:

## Art. 1 — Se sem a graça o homem pode conhecer a verdade.
(II Sent., dist. XXVIII, a. 5; Cor., cap. XII, lect. I)
O primeiro discute-se assim. — Parece, que sem a graça o homem não pode conhecer a verdade.

1. — Pois, sobre aquilo da Escritura. — Ninguém pode dizer Senhor Jesus, senão pelo Espírito Santo —
diz a Glosa de Ambrósio: Quem quer que diga a verdade, pelo Espírito Santo a diz. Ora, o Espírito Santo
habita em nós pela graça. Logo, sem esta não podemos conhecer a verdade.

2. Demais. — Agostinho diz: As mais certas doutrinas são as por assim dizer, iluminadas pelo sol, de
modo a serem vistas. Deus, porém é que ilumina, sendo a razão, para o espírito, o que é a vista para os
olhos; mas os olhos do espírito são os sentidos da alma. Ora, os sentidos do corpo, por mais puros que
sejam, não podem ver nada sem a luz do sol. Logo, também a mente humana, por perfeita que seja, não
pode, raciocinando, conhecer a verdade, sem a iluminação divina, que é auxílio da graça.

3. Demais. — Não pode a mente humana conhecer a verdade, senão pensando, como claro está em
Agostinho. Ora, o Apóstolo diz (2 Cor 3, 5): Não que sejamos capazes de nós mesmos de ter algum
pensamento como de nós mesmos. Logo, o homem não pode conhecer a verdade, por si mesmo, sem
auxílio da graça.
Mas, em contrário, diz Agostinho: Não aprovo o que disse numa oração — Deus, que só aos puros
permitiste conhecer a verdade. Pois, poderia alguém objetar, que muitos, embora impuros, conhecem
muitas verdades.Ora, pela graça, o homem se torna puro, conforme a Escritura (Sl 50, 12): Cria em
mim, ó Deus, um coração puro, e renova nas minhas entranhas um espírito reto. Logo, sem a graça, o
homem pode, por si mesmo, conhecer a verdade.

SOLUÇÃO. — Pelo uso ou por um ato da luz intelectual, é que conhecemos a verdade; pois, segundo o
Apóstolo (Ef 5, 13), tudo o que se manifesta é luz. Ora, qualquer uso implica movimento, tomando o
movimento em acepção lata, no qual se consideram movimentos o inteligir e o querer, segundo o
Filósofo claramente o diz. Vemos porém, que o movimento dos seres corpóreos implica, não só a forma,
que é o princípio dele ou da ação, mas também a moção do primeiro móvel. Ora, o primeiro móvel, na
ordem material, é o corpo celeste. Assim, por perfeito que seja o calor do fogo, não poderia aquecer
senão pela moção do corpo celeste. Ora, é manifesto, que todos os movimentos corpóreos se reduzem
ao do corpo celeste, como ao primeiro motor corpóreo. Pois, assim também todos os movimentos,
tanto os corpóreos como os espirituais, reduzem-se ao primeiro móvel absoluto, que é Deus. E portanto,
por perfeita que se suponha uma natureza corpórea ou espiritual, ela não pode se atualizar se não for
movida por Deus. E esse movimento depende da ordem da sua providência e não, da necessidade
natural, como o do corpo celeste. Nem só, porém todo movimento procede de Deus, como primeiro
motor; mas também dele, como do ato primeiro, procede toda perfeição formal. Por onde, o ato
intelectual, bem como o de todo ser criado, depende de Deus, de dois modos: por haurir nele a
perfeição ou a forma pela qual age; e por ser movido por ele à ação.
Mas, toda forma inerente às coisas criadas por Deus tem a sua eficiência relativa a um ato determinado,
que lhe é próprio, e além do qual não pode ir senão reforçado por outra forma superveniente. Assim, a
água não pode aquecer senão aquecida pelo fogo. Ora, a forma do intelecto humano é o lume
inteligível, suficiente, em si mesmo, para conhecer certos inteligíveis, a saber, aqueles cujo
conhecimento podemos obter por meio dos sensíveis. O que porém é superior à sua capacidade o
intelecto humano não pode conhecer senão fortalecido pelo lume da graça; p. ex., pelo lume da fé ou da
profecia, chamado lume da graça, por ser acrescentado à natureza. Por onde, devemos dizer que para
conhecer qualquer verdade o homem precisa do auxílio de Deus que o move ao seu ato. Não precisa
porém, para conhecer a verdade, em todos os casos, de nova iluminação acrescentada à iluminação
natural, mas só nos casos que lhe excedem o conhecimento natural. E contudo, algumas vezes
milagrosamente, pela sua graça, instrui a certos, relativamente ao que podem conhecer pela razão
natural; assim como, algumas vezes, faz milagrosamente certas coisas que a natureza pode fazer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Toda verdade, seja dita por quem for, provém do
Espírito Santo, como lume, que naturalmente a infunde e move a compreender e falar a verdade. Não
porém como habitando na pessoa pela graça santificante ou como conferindo algum dom habitual
acrescentando ao da natureza. Pois isto só se dá no conhecimento e na expressão de certas verdades e,
sobretudo, nas que respeitam à fé, ao que se refere o texto citado do Apóstolo.

RESPOSTA À SEGUNDA. — O sol material ilumina exteriormente, ao passo que o sol inteligível, que é
Deus, interiormente. Por onde, o lume natural infuso na alma é, em si mesmo, iluminação de Deus, que
permite ao conhecimento natural atingir o seu objeto. E para isto não é necessária outra iluminação,
senão só para os objetos excedentes ao conhecimento natural.

RESPOSTA À TERCEIRA. — Sempre precisamos, para qualquer pensamento, do auxílio divino que move
o intelecto à ação; pois inteligir alguma coisa, atualmente, é pensar, como claramente o diz Agostinho.

## Art. 2 — Se o homem pode querer e fazer o bem sem a graça.
(II Sent., dist. XXVIII, a. 1; dist. XXXIX, expos. Litt.; IV, dist.XVII, q. 1, a. 2, qª 2, ad; 3; De Verit., q. 24, a. 12;

II Cor., cap. III, lect. I).
O segundo discute-se assim. — Parece que o homem pode querer e fazer o bem sem a graça.

1. — Pois, está no poder do homem aquilo de que ele é senhor. Ora, o homem é senhor de seus atos, e
sobretudo da sua vontade, como já se disse (q. 1, a. 1; q. 13, a. 6). Logo, pode querer e fazer o bem por
si mesmo, sem o auxílio da graça.

2. Demais. — Um ser tem mais poder sobre o que lhe é natural do que sobre o que lhe contraria a
natureza. Ora, o pecado é contra a natureza, como diz Damasceno, ao contrário, o ato virtuoso é
segundo a natureza da alma, como já se disse (q. 71, a. 1). Ora, desde que o homem pode por si mesmo
pecar, conclui-se com maioria de razão, que pode por si mesmo querer o fazer o bem.

3. Demais. — O bem da inteligência é a verdade, como diz o Filósofo. Ora, a inteligência pode por si
mesma conhecê-la, assim como todo ser pode por si mesmo realizar o seu ato natural. Logo, com maior
razão, o homem pode por si mesmo fazer e querer o bem.
Mas, em contrário, diz o Apóstolo (Rm 9, 16): Não depende do que quer, i.é, do querer, nem do que
corre, i. é, do correr, mas, de usar Deus da sua misericórdia. E Agostinho: sem a graça, os homens não
podem, absolutamente, fazer o bem por pensamento, nem por vontade, amor, ou ação.

SOLUÇÃO. — A natureza do homem pode ser considerada à dupla luz. Na sua integridade, como existia
em nosso primeiro pai, antes do pecado ou como após esse pecado existe agora em nós. Ora, tanto num
como noutro estado, a natureza humana precisa do auxílio divino, como primeiro motor, para fazer ou
querer qualquer bem, conforme já dissemos (a. 1). Porém no estado de natureza íntegra, podia o
homem, quanto o exigem os atos virtuosos e só ajudado das suas faculdades naturais, querer e obrar o
bem proporcionado à sua natureza, tal como é o da virtude adquirida; não porém o da virtude infusa,
que lhe excede a natureza. No estado da natureza corrupta, porém, o homem falha, mesmo no que
poderia por natureza alcançar, de modo que não lhe é possível fazer, só pelas suas faculdades naturais,
todo o bem de que a sua natureza é capaz. Contudo, pelo pecado não ficou a natureza humana
totalmente corrupta, de modo a ficar privada de todo bem natural. Por isso, pode o homem, mesmo no
estado da natureza corrupta e por virtude da sua natureza, fazer algum bem particular, como, edificar
casas, plantas vinhas e coisas semelhantes. Mas não pode fazer todo bem que lhe é conatural, sem
falhar em caso algum. Assim como um homem doente pode, por si mesmo, fazer algum movimento,
mas, sem ser curado pelo médico, não pode mover-se perfeitamente, como um homem são.
Por onde, o homem necessita, no estado da natureza íntegra, do auxílio da graça, acrescentado às suas
faculdades naturais, mas só, para fazer e querer o bem sobrenatural. No estado da natureza corrupta,
porém, precisa desse auxílio, primeiro, para fortificar-se, e depois para praticar o bem da virtude
sobrenatural, que é meritório. Além disso, em um e outro estado, o homem precisa do auxílio divino
para mover-se à prática do bem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem é senhor dos seus atos de querer ou não
querer, por causa da deliberação racional, que pode inclinar-se para um ou outro lado. Mas só e
necessariamente por uma deliberação precedente é que poderá deliberar ou não, se disso for capaz.
Ora, como esse processo não pode ir ao infinito, é forçoso, finalmente, o livre arbítrio humano ser
movido por algum princípio externo, superior a mente humana, e que é Deus, como o prova o filósofo.
Por onde, o espírito do homem, mesmo ainda não corrompido, não tem de tal modo o domínio dos seus
atos, que dispense a moção divina. E, com maior razão, o livre arbítrio do homem enfermo pelo pecado,
que encontra, na corrupção da sua natureza um obstáculo a pratica do bem.

RESPOSTA À SEGUNDA. — Pecar não é mais do que claudicar na pratica do bem adequado à natureza
de um ser. Ora, todo ser criado, assim como não existe senão em virtude de outro e, em si considerado,
nada é: assim também precisa, por esse outro, de ser conservado no bem adequado à sua natureza. Por
onde, se não for sustentado por Deus, pode, abandonado a si mesmo, falhar na pratica do bem, assim
como pode, nessas condições, reduzir-se ao nada.

RESPOSTA À TERCEIRA. — Também a verdade o homem não a pode conhecer sem o auxílio divino,
como já dissemos (a. 1). E contudo, a natureza humana ficou mais corrupta, pelo pecado, no seu desejo
do bem, que no conhecimento da verdade.

## Art. 3 — Se o homem pode amar a Deus sobre todas as coisas, só pelas suas faculdades naturais, sem o auxílio da graça.
(I, q. 60, a. 5; IIª-IIªe, q.26, a. 3; II Sent., dist. XXXIX, a. 3; De Virtut., q. 2, a. 2, as 16; q. 4, a. 1, ad 9;
Quodl. I, q. 4, a. 3).
O terceiro discute-se assim. — Parece que o homem não pode amar a Deus sobre todas as coisas, só
pelas suas faculdades naturais, sem o auxílio da graça.

1. — Pois, amar a Deus sobre todas as coisas é no que consiste própria e principalmente o ato de
caridade. Ora, a caridade o homem não pode tê-la por si mesmo; porque, como diz o Apóstolo (Rm 5,
5), a caridade de Deus está derramada em nossos corações pelo Espírito Santo, que nos foi dado. Logo,
só pelas suas faculdades naturais, o homem não pode amar a Deus sobre todas as coisas.

2. Demais. — Nenhuma natureza pode pretender o que lhe é superior. Ora, amar a Deus mais que a si
mesmo é pretender o que é superior à natureza criada; logo, não pode amar a Deus mais que a si
mesma, sem o auxílio da graça.

3. Demais. — A Deus, que é o sumo bem é devido o sumo amor, e este consiste em amá-lo sobre todas
as coisas. Ora, não podemos amar a Deus com o sumo amor, que lhe devemos, sem a graça; do
contrário, esta seria dada inutilmente. Logo, o homem não pode, sem a graça, e só com as suas
faculdades naturais, amar a Deus sobre todas as coisas.
Mas, em contrário. — Como certos ensinam, o primeiro homem foi constituído só com as suas
faculdades naturais, em cujo estado manifestamente amou de algum modo a Deus. Ora, não O amou
tanto quanto a si, ou menos que a si, porque então pecaria. Logo, amou-O mais que a si. Por onde, só
pelas suas faculdades naturais o homem pode amar a Deus mais que a si e sobre todas as coisas.

SOLUÇÂO. — Como já dissemos na Primeira Parte (q. 60, a. 5), onde também expusemos as diversas
opiniões sobre o amor natural dos anjos, o homem, no estado da natureza íntegra, podia obrar, em
virtude da sua natureza, o bem que lhe é conatural, sem o acréscimo do dom da graça, embora, não
sem o auxilio da moção divina. Ora, amar a Deus sobre todas as coisas é conatural ao homem e mesmo
a qualquer criatura, não só racional, mas também irracional e mesmo inanimada, conforme o modo do
amor que convém a cada uma delas. E a razão está em ser natural a todos os seres desejarem e amarem
o que lhes corresponda a natureza; pois, todo ser ageconforme a sua capacidade natural, segundo
Aristóteles. Ora, é manifesto que o bem da parte é para o bem do todo. Por onde, por desejo ou amor
natural, cada ser ama o seu bem próprio, por causa do bem comum de todo o universo, que é Deus. Por
isso, Dionísio diz, que Deus atrai todas as coisas ao seu amor. Por onde, o homem, no estado da
natureza íntegra, referia não só o amor de si mesmo ao amor de Deus, como fim, mas também o de
tudo o mais. E assim, amava a Deus mais que a si mesmo e sobre todas as coisas. Mas no estado da
natureza corrupta, já não procede do mesmo modo por causa do apetite da vontade racional, que, por
causa da corrupção da natureza procura o seu bem particular; salvo sendo restaurada pela graça de
Deus. E portanto, devemos dizer, que o homem, no estado de natureza íntegra, não precisa do dom da
graça, acrescentada aos seus dotes naturais, para amar a Deus naturalmente sobre todas as coisas;
embora, precisasse do auxílio de Deus, para mover-se para esse fim. Mas no estado da natureza
corrupta, precisa, mesmo para isso, do auxílio da graça, que restaura a natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A caridade ama a Deus sobre todas as coisas de modo
mais eminente que a natureza. Pois, esta ama a Deus sobre todas as coisas enquanto princípio e fim do
bem natural. A caridade porém, enquanto objeto da felicidade, e enquanto o homem tem uma certa
sociedade espiritual com Deus. E também a caridade acrescenta ao amor natural de Deus uma certa
presteza e prazer, assim como qualquer hábito virtuoso o acrescenta ao ato bom, feito só pela razão
natural do homem, sem o hábito da virtude.

RESPOSTA À SEGUNDA. — Quando se diz que nenhuma natureza pode nada do que lhe é superior, não
se deve por aí entender que não possa buscar um objeto que lhe seja superior. Pois, é manifesto que o
nosso intelecto, por conhecimento natural, pode conhecer certas coisas que lhe são superiores, como o
demonstra o conhecimento natural de Deus. Mas devemos entendê-lo no sentido de a natureza não
poder praticar um ato que lhe exceda a capacidade das forças. Ora, tal não é o ato de amar a Deus sobre
todas as coisas, natural a toda natureza criada, como já se disse.

RESPOSTA À TERCEIRA. — Chama-se sumo o amor, não só quanto ao grau da dileção, mas também
quanto à razão e ao modo de amar. E sendo assim, o sumo grau do amor é o pelo qual a caridade ama a
Deus como beatificante, conforme já dissemos.

## Art. 4 — Se o homem, sem a graça, só pelas suas faculdades naturais, pode cumprir os preceitos da lei.
(II Sent., dist. XXVIII, a. 3; De Verit., q. 24, a. 14, ad 1, 2, 7; Ad Rom., cap. II, lect III).
O quarto discute-se assim. — Parece que o homem, sem a graça, só pelas suas faculdades naturais,
pode cumprir os preceitos da lei.

1. — Pois, diz o Apóstolo (Rm 2, 14): os gentios, que não têm lei, fazem naturalmente as coisas que são
da lei. Ora, o que o homem faz naturalmente pode fazê-lo por si por si mesmo, sem a graça. Logo, sem
esta pode cumprir os preceitos da lei.

2. Demais. — Jerônimo diz, que devem ser amaldiçoados os que dizem ser impossível o por Deus
preceituado aos homens. Ora, é impossível, para o homem, o que ele não pode cumprir por si mesmo.
Logo, por si mesmo, pode cumprir todos os preceitos da lei.

3. Demais. — De todos os preceitos da lei o maior é aquele (Mt 27, 37): Amarás ao Senhor teu Deus de
todo o teu coração. Ora, este mandamento o homem pode cumpri-lo pelas suas faculdades naturais,
amando a Deus sobre todas as coisas, como já dissemos (a. 3). Logo, pode cumprir todos os
mandamentos da lei, sem a graça.
Mas, em contrário, Agostinho diz que é próprio da heresia dos Pelagianos crer que, sem a graça, o
homem possa cumprir todos os mandamentos divinos.

SOLUÇÃO. — De dois modos podemos cumprir os mandamentos da lei. — Primeiro, quanto à substância
das obras, quando praticamos atos de justiça, de fortaleza e das demais virtudes. E deste modo, o
homem podia, no estado da natureza íntegra, cumprir todos os mandamentos da lei; do contrário, não
poderia, nesse estado, deixar de pecar, pois o pecar não é senão transgredir os mandamentos divinos.
Mas, no estado da natureza corrupta, não pode cumprir todos os mandamentos divinos, sem o auxílio
da graça. — De outro modo, os mandamentos da lei podem ser cumpridos, não só quanto à substância
das obras, mas também quanto ao modo de agir, i. é, praticando-as com caridade. E assim, nem no
estado da natureza íntegra, nem no da corrupta, o homem pode cumprir, sem a graça, os mandamentos
da lei. Por isso, Agostinho depois de ter dito, que sem a graça os homens não podem, absolutamente,
fazer nenhum bem, acrescenta: a graça é necessária, não só para lhes dar a conhecer o que devem
praticar, mas também para fazerem o de que foram informados, com amor. Além disso, precisam, em
um outro estado, do auxílio da moção divina, para cumprirem os mandamentos, como dissemos (a. 2, a.
3).

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No dizer de Agostinho, não devemos nos admirar de
dizer o Apóstolo, que os gentios fazem naturalmente as coisas da lei; pois, o Espírito da graça obra em
nós a instauração da imagem de Deus, segundo a qual fomos naturalmente criados.

RESPOSTA À SEGUNDA. — O que podemos, com o auxílio divino, não nos é absolutamente impossível,
conforme àquilo do Filósofo: o que podemos por meio dos amigos podemos de certo modo por nós
mesmos.Por isso, no mesmo lugar, Jerônimo confessa que o nosso arbítrio é livre, no sentido de sempre
precisamos do auxílio de Deus.

RESPOSTA À TERCEIRA. — O preceito do amor de Deus o homem não pode cumpri-lo só pelas suas
faculdades naturais, conforme às exigências da caridade, como do sobredito resulta (a. 3).

## Art. 5 — Se o homem pode merecer a vida eterna, sem a graça.
(Infra, q. 114, a. 2; II Sent., dust. XXVIII, a. 1; dist. XXIX, a. 1 ; III Cont. Gent., cap. CXLVII ; De Verit., q. 24,
a. 1, ad 2 ; a. 14 ; Quold.I, q. 4, a. 2).
O quinto discute-se assim. — Parece que o homem pode merecer a vida eterna, sem a graça.

1. — Pois, diz o Senhor (Mt 19, 17): Se tu queres entrar na vida, guarda os mandamentos. Por onde se vê
que depende da vontade humana entrar na vida eterna. Ora, o que da nossa vontade depende por nós
mesmos o podemos fazer. Logo, o homem pode, por si mesmo, merecer a vida eterna.

2. Demais. — A vida eterna é um galardão ou prêmio, que Deus dá aos homens, conforme a Escritura
(Mt 5, 12): o vosso galardão está nos céus. Ora, Deus dá o galardão ou o prêmio ao homem, segundo as
suas obras, no dizer da Escritura (Sl 61, 12): Tu retribuirás a cada um segundo as suas obras. Logo, sendo
o homem senhor dos seus atos, foi deixado ao seu poder entrar na vida eterna.

3. Demais. — A vida eterna é o fim último da vida humana. Ora, todos os seres da natureza podem,
pelas suas faculdades naturais, conseguir o seu fim. Logo, com maior razão, o homem, de natureza mais
elevada, pode chegar à vida eterna pelas suas faculdades naturais, sem o auxílio da graça.
Mas, em contrário, diz o Apóstolo (Rm 6, 23): A graça de Deus é a vida eterna. O que foi dito, explica a
Glosa a esse lugar, para entendermos, que Deus nos conduz, pela sua misericórdia, à vida eterna.

SOLUÇÃO. — Os atos conducentes ao fim devem ser a este proporcionados. Ora, nenhum ato excede à
proporção do princípio ativo. Por isso, vemos que nenhum ser natural pode produzir, pela sua operação
própria, um efeito que lhe exceda a virtude ativa, senão só o que lhe for proporcionado à virtude. Ora, a
vida eterna é um fim desproporcionado à natureza humana, como do sobredito resulta (q. 5, a. 5). Por
onde, o homem, pelas suas faculdades naturais, não pode praticar obras meritórias proporcionadas à
vida eterna; para isso é necessária uma virtude mais alta, que é a virtude da graça. Portanto, sem esta,
ele não pode alcançar a vida eterna. Pode, porém, praticar certas obras conducentes a determinados
bens que lhe sejam conaturais, como, trabalhar no campo, beber, comer, ter amigos e outros
semelhantes, como diz Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem, pela sua vontade, pode fazer obras
meritórias para a vida eterna. Mas, como diz Agostinho, no mesmo livro, para isso é necessário que a
vontade lhe seja preparada pela graça de Deus.

RESPOSTA À SEGUNDA. — Ao lugar do Apóstolo — a graça de Deus é a vida eterna — diz a Glosa:
É certo que a vida eterna é dada em retribuição das boas obras; mas estas mesmas já procedem da
graça de Deus. Pois, como também já dissemos (a. 4), para cumprir os mandamentos de Deus, como
devemos e meritoriamente, é necessária a graça.

RESPOSTA À TERCEIRA. — A objeção colhe quanto ao fim conatural do homem. Pois, a natureza
humana, por isso mesmo que é mais nobre, pode atingir um fim mais elevado, ao menos com o auxílio
da graça, e o qual de nenhum modo podem alcançar os seres de natureza inferior. Assim, tem melhor
disposição para a saúde quem pode alcançá-la, com o auxílio de certos remédios, do que quem de
nenhum modo o pode, como diz o Filósofo.

## Art. 6 — Se o homem pode preparar-se a si mesmo para a graça, sem o auxílio externo da mesma.
(I, q. 62, a. 2; II Sent., dist. V, q. 2, a 1; dist. XXVIII, a. 4; IV, dist. XVII, q. 1, a. 2, qª 2, ad 2; III Cont., Gent.
Cap. CXLIX; De Verit., q. 24, a. 15; Quodl. I q. 4, a. 2; In Ioan., cap. I, lect. VI; Ad Hebr., cap. XII, lect III).
O sexto discute-se assim. — Parece que o homem pode preparar-se a si mesmo para a graça, sem o
auxílio da mesma.

1. — Pois, ao homem não foi imposto nada de impossível como já se disse (a. 4, ad 1). Ora, a Escritura
diz (Zc 1, 3): Convertei-vos a mim e eu me converterei a vós. Ora, preparar-se para a graça não é senão
converter-se para Deus. Logo, o homem pode por si mesmo, sem a graça, preparar-se para ela.

2. Demais. — O homem prepara-se para a graça fazendo o que está em si; pois, se o fizer, Deus não a
negará, conforme diz a Escritura (Mt 7, 11): Deus dá espírito bom aos que lhe pedirem. Ora, dizemos
que está em nós o que de nós depende. Logo, ao nosso poder foi dado prepararmo-nos para a graça.

3. Demais. — Se o homem precisa da graça afim de preparar-se para ela, pela mesma razão precisará de
outra para obter a primeira, e assim ao infinito, o que é inadmissível. Logo, devemos parar na primeira,
de modo que o homem, sem a graça, pode preparar-se para a mesma.

4. Demais. — A Escritura diz (Pr 16, 1): Da parte do homem está o preparar a sua alma. Ora, pertence ao
homem o que ele por si mesmo pode fazer. Logo, por si mesmo, pode preparar-se para a graça.
Mas, em contrário, diz a Escritura (Jo 6, 44): Ninguém pode vir a mim, se o Pai, que me enviou, o não
trouxer. Se, pois, o homem pudesse preparar-se por si mesmo, não seria necessário ser levado por
outrem. Logo, não pode preparar-se para a graça, sem o auxílio dela.

SOLUÇÃO. — Há dupla preparação da vontade humana para o bem. — Uma, pela qual se ela prepara,
afim de obrar o bem e gozar de Deus. E essa preparação da vontade não pode ser sem o dom habitual
da graça, como princípio da obra meritória, segundo já dissemos (a. 5). A outra visa conseguir o dom
mesmo da graça habitual. Ora, para o homem preparar-se, afim de receber esse dom, não é necessário
pressupor na alma nenhum outro dom habitual, porque assim iríamos ao infinito. Mas é preciso
pressupor um auxílio gratuito de Deus, que mova a alma interiormente ou inspire o bem proposto.
Assim, desses dois modos precisamos do auxílio divino, como já dissemos (a. 2, a. 3).
Ora, que precisamos do auxílio da moção divina afim de nos prepararmos para a graça, é manifesto.
Pois, todo agente, visando um fim, necessariamente toda causa dirigirá os seus efeitos para o seu fim.
Ora, a ordem dos fins é relativa à ordem dos agentes ou dos motores. Por onde, o homem há de
necessariamente converter-se para o fim último, movido pelo primeiro motor; ao fim próximo, porém,
pela moção de algum motor inferior. Assim, o ânimo do soldado converte-se a buscar a vitória por
moção do chefe do exército; mas por instigação do tribuno é que se converte a seguir a bandeira de um
exército. Ora, sendo Deus o primeiro motor absoluto, é em virtude da sua moção que todas as coisas se
convertem para ele, por força da tendência geral delas para o bem, pela qual cada uma busca, ao seu
modo, assimilar-se com Deus. Por isso Dionísio diz, que Deus converte todas as coisas para si mesmo. Os
homens justos, porém, Ele os converte a si, como o fim especial a que tendem e ao qual desejam se unir
como ao bem próprio, conforme a Escritura (Sl 72, 28): Para mim me é bom unir-me a Deus. Portanto, o
homem não pode converter-se para Deus, senão pelo levar Deus a agir assim. Ora, preparar-se para a
graça é como converter-se para Deus, assim como quem tem desviados os olhos da luz do sol prepara-se
a receber essa luz, convertendo-os para ele. Por onde é claro que o homem não pode preparar-se para
receber o lume da graça, senão com o auxílio gratuito da moção interna de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A conversão do homem para Deus se faz pelo seu livre
arbítrio; por isso foi-lhe dado o preceito de converter-se para Deus. Mas o livre arbítrio não pode
converter-se para Deus, senão porque Ele o faz proceder desse modo, conforme àquilo da Escritura (Jr
31, 18): Converte-me e converter-me-ei, porque tu és o Senhor meu Deus; e ainda (Lm 5, 21): Converte-
nos, Senhor, a ti e nós nos converteremos.

RESPOSTA À SEGUNDA. — O homem nada pode fazer senão movido por Deus, conforme a Escritura (Jo
15, 5):Sem mim não podeis fazer nada. Portanto, quando se diz que faz o que está no seu poder, isso
significa que pode assim agir, quando movido por Deus.

RESPOSTA À TERCEIRA. — A objeção colhe quanto à graça habitual, que exige uma preparação, porque
toda forma exige uma disposição para recebê-la. Mas a moção que o homem recebe de Deus não pré-
exige nenhuma outra, por ser Deus o primeiro motor. Por onde, não há necessidade de se proceder ao
infinito.

RESPOSTA À QUARTA. — É próprio do homem preparar a sua alma, por fazê-lo com livre arbítrio.
Contudo, não o faz sem o auxílio de Deus, que o move e o atrai para si, como dissemos.

## Art. 7 — Se o homem pode ressurgir do pecado sem o auxílio da graça.
(Infra, q. 113, a. 2; II Sent., dist. XXVIII, a. 2 ; III Cont. Gent., cap. CLVII ; IV, cap. LXXII ; De Verit., q. 24, a.
12 ad 34 ; q. 28, a. 2 ; Ad Ephes., cap. V, lect. V)
O sétimo discute-se assim. — Parece que o homem pode ressurgir do pecado sem o auxílio da graça.

1. — Pois, o que é pré-exigido para a graça existe sem ela. Ora, ressurgir do pecado é pré-exigido para a
iluminação da graça, conforme a Escritura (Ef 5, 14): Levanta-te dentre os mortos e Cristo te
alumiará. Logo, o homem pode ressurgir do pecado, sem a graça.

2. Demais. — O pecado se opõe à virtude, como a doença, à saúde, segundo já se disse (q. 71, a. 1 ad 3).
Ora, o homem, por virtude da natureza, pode sair da doença para a saúde, sem auxílio de remédio
externo, por conservar internamente o princípio vital, do qual procede a operação natural. Logo, por
semelhante razão, também o homem pode restaurar-se a si mesmo, saindo do estado de pecado para o
da justiça, sem auxílio da graça exterior.

3. Demais. — Qualquer ser natural pode voltar ao ato adequado à sua natureza; assim a água aquecida
volta, por si mesma, à sua frieza natural; e a pedra, atirada para cima, volta por si mesma ao seu
movimento natural. Ora, o pecado é um ato contra a natureza, como claramente o diz Damasceno.
Logo, o homem pode, por si mesmo, voltar, do pecado, para o estado de justiça.
Mas, em contrário, diz o Apóstolo (Gl 2, 21): se foi dada uma lei, que possa justificar, segue-se que
morreu Cristo em vão, i. é, sem causa. Por igual razão, se o homem tem uma natureza pela qual possa
justificar-se, Cristo morreu em vão, i. é, sem causa. Ora, isto não se pode admitir. Logo, o homem não
pode justificar-se por si mesmo, i. é, sair do estado da culpa para o da justiça.

SOLUÇÃO. — O homem de nenhum modo pode ressurgir do pecado, por si mesmo, sem o auxílio da
graça. Pois, depois de praticado o ato pecaminoso, permanece o reato, como já se disse (q. 87, a. 6). Por
onde, ressurgir do pecado não é o mesmo que ter cessado o ato pecaminoso, mas sim, recuperar o
perdido pelo pecado. Ora, pelo pecado, o homem sofre tríplice detrimento; como resulta do sobredito
(q. 85, a. 1; q. 86, a. 1; q. 87, a. 1): a mácula, a corrupção do bem natural e o reato da pena. — A mácula,
por ficar privado do esplendor da graça, por causa da deformidade do pecado. — A corrupção do bem
natural, por desordenar-se a natureza humana pela não sujeição da vontade a Deus; pois, desaparecida
esta ordem, há de por conseqüência ficar desordenada a natureza toda do homem pecador. — Enfim,
pelo reato da pena o homem, pecando mortalmente, merece a condenação eterna. Ora, é manifesto
que esse tríplice detrimento não pode ser reparado senão por Deus. — Assim, o esplendor da graça,
provindo da iluminação da luz divina, a alma não pode recuperá-lo se Deus não a iluminar de novo; e
para isso é necessário o dom habitual do lume da graça. — Semelhantemente, a ordem da natureza não
pode ser restaurada, de modo à vontade do homem ficar sujeita a Deus, se Ele não a atrair para si, como
já dissemos (a. 6). — E também, enfim, o reato da pena eterna não pode ser remido senão por Deus,
contra quem foi cometida a ofensa, e que é o juiz do homem. E, portanto, o homem precisa do auxílio
da graça para ressurgir do pecado, quanto ao dom habitual e quanto à moção interna divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Atribui-se ao homem o que lhe depende do livre
arbítrio, necessário para ressurgir do pecado. Por onde e o lugar — Levanta-te e Cristo te iluminará —
não significa, que todo levantar-se do pecado preceda à iluminação da graça; mas que, quando o
homem, movido no seu livre arbítrio por Deus, se esforça por levantar-se do pecado, recebe o lume da
graça justificante.

DONDE A RESPOSTA À SEGUNDA. — A razão natural não é princípio suficiente da saúde espiritual, que a
graça santificante confere ao homem; mas tal princípio é a graça, de que o pecado o priva. Por isso, não
pode ele restaurar-se a si mesmo, mas precisa lhe seja de novo infundida a graça, como se de novo a
alma fosse infundida num corpo, pela ressurreição deste.

RESPOSTA À TERCEIRA. — A natureza íntegra pode restaurar-se por si mesma, no que lhe é conveniente
e proporcionado. Mas no que lhe excede a capacidade não pode, senão por auxílio externo. Ora, a
natureza humana decaiu, pelo ato do pecado, pois não permaneceu íntegra, mas se corrompeu, como já
se disse. Logo, não pode restaurar-se por si mesma, nem em relação ao seu bem conatural, nem, como
maior razão à justiça sobrenatural.

## Art. 8 — Se o homem pode, sem a graça, não pecar.
(Supra, q. 63, a. 2, ad 2; q. 74, a. 3, ad 2; II Sent., dist. XX, q. 2, a. 3, ad 5; dist. XXIV, q. 1, a. 4; dist. XXVIII,
a. 2; III Cont. Gent., cap. CLX; De Verit., q. 22, a. 5, ad 7; q. 24, a. 1, ad 10, 12; a. 12, 13; De Malo, q. 3, a.
1, ad 9; I Cor., cap. XII, lect. I; Ad Hebr., cap. X, lect. III).
O oitavo discute-se assim. — Parece que o homem pode, sem a graça, não pecar.

1. — Pois, ninguém peca, fazendo o inevitável, como diz Agostinho. Se portanto, o homem, em estado
de pecado mortal, não pode evitá-lo resulta que, pecando, não peca. O que é inadmissível.

2. Demais. — O homem é punido afim de não pecar. Se pois, o estado de pecado mortal não pode deixar
de pecar, resulta que é punido em vão. O que é inadmissível.

3. Demais. — A Escritura diz (Sr 15, 18): Diante do homem estão à vida e a morte, o bem e o mal; o que
lhe agradar, isso lhe será dado. Ora, quem peca não deixa de ser homem. Logo, pode escolher entre o
bem e o mal, e portanto, sem a graça evitar o pecado.
Mas, em contrário, diz Agostinho: Não duvido que por ninguém deve ser ouvido e deve ser por todos
anatematizado quem nega que devemos orar, para não cairmos em tentação; pois, quem o faz nega seja
necessário ao homem, para não pecar, o auxílio da graça de Deus, bastando só a vontade humana, com
a aceitação da lei.

SOLUÇÃO. — Podemos encarar o homem à dupla luz: no estado da natureza íntegra e no da natureza
corrupta. — No primeiro, podia, mesmo sem a graça habitual, não pecar, nem mortal nem venialmente.
Pois, pecar não é senão afastar-se do que é natural, o que o homem, no estado de natureza íntegra,
podia evitar. Não o podia, porém, sem o auxílio de Deus que conserva no bem; pois, subtraído esse
auxílio, a própria natureza voltaria ao nada.
No estado, porém, da natureza corrupta, o homem precisa da graça habitual, que restaura a natureza,
para abster-se completamente do pecado. E essa restauração se faz, primeiro, pelo espírito, no estado
da vida presente, em que o apetite carnal ainda não está completamente purificado. Por isso, o
Apóstolo, personificando o homem redimido diz (Rm 7, 25): Eu mesmo sirvo à lei de Deus segundo o
espírito; e sirvo à lei do pecado, segundo a carne. E nesses estado, o homem pode abster-se de todo
pecado mortal, que se funda no espírito, como já estabelecemos (q. 74, a. 5). Não pode, porém, livrar-se
de todo pecado venial, por causa da corrupção do apetite inferior da sensualidade. Pois, a razão pode
certamente reprimir-lhe cada um dos movimentos, em particular; sendo, por isso, que estes constituem
essencialmente pecados e atos voluntários. Mas não reprimi-los a todos, porque, enquanto se esforça
por resistir a um, pode surgir outro. E também porque a razão nem sempre pode estar vigilante para
evitar tais movimentos, como já dissemos (q. 74, a. 3 ad 2).
Semelhantemente, antes de a razão humana, onde se radica o pecado mortal, ter sido reparada pela
graça santificante, podia o homem evitar todo pecado mortal, num determinado tempo; pois, não havia,
por força, de pecar, atual e continuamente. Não podia, porém, durante muito tempo permanecer sem
pecado mortal. Por isso, Gregório diz: o pecado que não é logo detido pela penitência, arrasta, com o
seu peso, para outro. E a razão disto é que, assim como o apetite inferior deve estar sujeito à razão,
assim também a razão deve estar sujeita a Deus e colocar nele o fim da sua vontade. Ora, é
necessariamente, pelo fim, que se hão de reger todos os movimentos humanos; assim como, pelo juízo
da razão, todos os movimentos do apetite inferior. Por onde, não estando o apetite inferior totalmente
sujeito à razão, hão de surgir movimentos desordenados nesse apetite sensitivo; e assim também, não
estando a razão humana totalmente sujeita a Deus, conseqüentemente, muitas desordens hão de lhe
viciar os atos. Ora, o homem não tem o coração firmado em Deus, a ponto de não querer separar-se
dele, por conseguir qualquer bem ou evitar qualquer mal, desprezando-lhe os preceitos. Por isso, peca
mortalmente, e sobretudo porque, nos seus atos súbitos, obra de acordo com um fim preconcebido e
um hábito preexistente, no dizer do Filósofo. Embora, com premeditação da razão, possa agir
contrariamente à ordem do fim preconcebido e à inclinação do hábito. Mas como não pode viver em
estado de contínua premeditação, não lhe é possível permanecer muito tempo sem agir de acordo com
a vontade desordenadamente afastada de Deus, senão for, logo, reconduzido, pela graça, à ordem
devida.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem pode evitar cada um dos atos do pecado,
singularmente; não, porém, todos, senão com o auxílio da graça, conforme já dissemos. E contudo,
como é por falta sua, que não se prepara a receber a graça, não pode escusar-se do pecado, pois, sem a
graça, é incapaz de evitá-lo.

RESPOSTA À SEGUNDA. — A punição é útil para, com a dor que provoca, fazer nascer na vontade a
regeneração. Contanto, que o punido seja filho da promessa, de modo que, simultâneo com o estrepito
da mesma, que repercute exteriormente, e flagela, Deus mova a vontade, interiormente, com inspiração
oculta, como diz Agostinho. Logo, a correção é necessária, pois a vontade humana a exige, para poder
abster-se do pecado; porém, não é suficiente, sem o auxílio de Deus. Por isso, a Escritura diz (Ecle 7,
14): Considera as obras de Deus, porque ninguém pode corrigir, a quem ele desprezou.

RESPOSTA À TERCEIRA. — Como diz Agostinho, o lugar citado da Escritura se entende do homem, no
estado da natureza íntegra, quando ainda não era escravo do pecado e podia portanto pecar e não
pecar. No estado atual, porém, é-lhe dado tudo quanto quer; mas só com o auxílio da graça pode querer
o bem.

## Art. 9 — Se quem já conseguiu a graça pode, por si mesmo, praticar o bem e evitar o pecado, sem outro auxílio da mesma.
(II Sent., dist. XXIX, expos. Litt.; De Verit., q. 24, a. 13, 14; q. 27, a. 5, ad 3; In Psalm. XXXI).
O nono discute-se assim. — Parece, que quem já conseguiu a graça pode, por si mesmo, praticar o
bem e evitar o pecado, sem outro auxílio da mesma.

1. — Pois, é vão ou imperfeito aquilo que não realiza o fim para o qual foi feito. Ora, a graça nos é dada
para podermos fazer o bem e evitar o pecado. Se, portanto com o auxílio dela, o homem não pode
evitá-lo, resulta que é vã ou imperfeita.

2. Demais. — Pela graça o Espírito Santo mesmo habita em nós, conforme a Escritura (1 Cor 3, 16): Não
sabeis vós, que sois templo de Deus, e que o Espírito de Deus mora em vós? Ora, o Espírito Santo, sendo
onipotente, tem poder para nos levar a agir retamente e guardar-nos do pecado. Logo, quem conseguiu
a graça pode agir retamente e livrar-se do pecado, sem outro auxílio da mesma.

3. Demais. — Se o homem, que já conseguiu a graça, ainda precisa de outro auxílio dela, para viver
retamente e abster-se do pecado, pela mesma razão, quando tiver alcançado esse outro auxílio,
precisará ainda de um terceiro. Donde, o processo irá ao infinito, o que é inadmissível. Logo, quem está
em graça não precisa de outro auxílio da mesma, para agir bem e abster-se do pecado.
Mas, em contrário. Agostinho diz: assim como os olhos da carne, por perfeitos que sejam, não podem
ver, senão ajudados pelo brilho da luz, assim também, o homem, embora perfeitissimamente
justificado, não pode viver retamente, se não for ajudado pela luz eterna da divina justiça. Ora, a
justificação é operada pela graça, conforme a Escritura (Rm 3, 24): Tendo sido justificados gratuitamente
por sua graça. Logo, quem já tiver a graça, precisa ainda de outro auxílio da mesma para viver
retamente.

SOLUÇÃO. — Como já dissemos (a. 5), o homem, para viver retamente precisa duplamente do auxílio de
Deus. Primeiro, do dom habitual, que restaura a natureza humana corrupta e, uma vez restaurada,
eleve-a a fazer obras meritórias para a vida eterna, que lhe excedem a capacidade. Segundo, o homem
precisa do auxílio da graça, afim de que Deus a mova para agir. — Ora, do primeiro modo, o homem, no
estado da graça, não precisa de nenhum outro auxílio da mesma, que seria um como segundo hábito
infuso. Precisa porém do auxílio da graça, pelo qual Deus o move a agir retamente. — E isto, por duas
razões. A primeira, de ordem geral, é que, como já dissemos, nenhum ser criado pode praticar qualquer
ato, senão em virtude de moção divina. — A segunda, de ordem especial, se funda na condição do
estado da natureza humana, que, embora restaurada pela graça, quanto ao espírito, permanece
contudo corrupta e contaminada na carne, pela qual serve à lei do pecado, como diz o Apóstolo (rm 7,
25). Embora permaneça ainda uma certa obscuridade da ignorância na inteligência, pela qual, como diz
o mesmo Apóstolo (Rm 8, 26), não sabemos o que havemos de pedir, como convém. Pois, por causa das
várias eventualidades da vida, e por não nos conhecermos perfeitamente a nós mesmos, não podemos
plenamente saber o que nos convém, conforme aquilo da Escritura (Sb 9, 14): Os pensamentos dos
mortais são tímidos, e incertas as nossas providências. Por onde, temos necessidade de ser dirigidos e
protegidos por Deus, que tudo conhece e tudo pode. E por isso, mesmo aos que pela graça renasceram
filhos de Deus, convém dizer: E não nos deixes cair em tentação e Faça-se a tua vontade, assim no céu
como na terra, e o mais que contém a oração dominical, relativa ao assunto vertente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dom da graça habitual não nos é dado para que
deixemos, por ele, de precisar de outro auxílio divino. Pois, toda criatura necessita de ser conservada,
por Deus, no bem que d’Ele recebeu. Por onde, de precisar o homem de auxílio divino, ainda depois de
ter recebido a graça, não se pode concluir que ela tenha sido dada em vão ou seja imperfeita. Pois,
mesmo no estado da glória, quando já a graça for absolutamente perfeita, o homem precisava do divino
auxílio. Na vida presente, porém, enquanto não está completamente restaurado, a graça é, de certo
modo, imperfeita, como já dissemos.

RESPOSTA À SEGUNDA. — A ação do Espírito Santo, que nos move e protege, não fica circunscrita pelo
efeito do dom habitual, que causa em nós. Mas, além desse efeito, move-nos e protege-nos,
simultaneamente com o Pai e o Filho.

RESPOSTA À TERCEIRA. — A objeção conclui que o homem não precisa de outra graça habitual.

## Art. 10 — Se o homem, constituído na graça, precisa do auxílio da mesma para perseverar.
(IIª-IIªe, q. 137 a. 4: II Sent., dist. XXIX, exposit litt.; III Cont. Gent., cap. CLV; De Verit., q. 24, a. 13).
O décimo discute-se assim. — Parece que o homem constituído na graça não precisa do auxílio da
mesma, para perseverar.

1. — Pois, a perseverança, como a continência, é algo menos que a virtude, como claramente o diz o
Filósofo. Ora, o homem, uma vez justificado pela graça, não precisa do auxílio da mesma, para praticar a
virtude. Logo, com maior razão, não precisa desse auxílio para perseverar.

2. Demais. — Todas as virtudes são infundadas simultaneamente. Ora, a perseverança é considerada
uma virtude. Logo, a perseverança coexiste com a graça das outras virtudes infusas.

3. Demais. — Como diz o Apóstolo, o homem ganhou mais com o dom de Cristo, do que perdeu com o
pecado de Adão. Ora, Adão recebera o dom de poder perseverar. Logo, com maior razão, pela graça de
Cristo, obtemos o poder de perseverar. Portanto, não precisamos, para isso, de nenhuma graça.
Mas, em contrário, Agostinho diz: Porque pedimos a Deus a perseverança, se ele não a dá? Pois, é uma
petição irrisória, desde que sabemos que ele não nos satisfaz o pedido, e que está em nosso poder esse
dom mesmo, não recebido de Deus. Ora, a perseverança é pedida, mesmo pelos santificados pela graça;
pois, isso está compreendido na oração — Santificado seja o vosso nome — como,no mesmo lugar
Agostinho o confirma, citando as palavras de Cipriano. Logo, o homem, mesmo constituído em graça,
precisa que Deus lhe dê a perseverança.

SOLUÇÃO. — A perseverança pode ser entendida em tríplice acepção. — Às vezes, significa um hábito
do espírito, que fortifica o homem contra o ímpeto da tristeza, para que se não afaste da vida virtuosa. E
assim, a perseverança está para a tristeza como a continência, para a concupiscência e o prazer,
segundo o Filósofo. — Outras vezes, pode chamar-se perseverança a um hábito pelo qual o homem tem
o propósito de perseverar no bem até o fim. — Ora, de ambos esses modos, a perseverança é infundida
simultaneamente com a graça, assim como a continência e as demais virtudes.
Noutra acepção, chama-se perseverança à continuação no bem até o fim da vida. E para consegui-la, o
homem, constituído na graça não precisa, por certo, de nenhuma outra graça habitual, mas, ao auxílio
divino, que o dirige e protege contra o ímpeto das tentações, conforme resulta da questão precedente.
Portanto, quem está justificado pela graça, há necessariamente de pedir a Deus o referido dom da
perseverança, para livrar-se do mal, até o fim da vida. Pois, a muitos é dada a graça, aos quais não é
dado nela perseverar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção colhe, quanto à primeira acepção da
perseverança. Assim como a segunda também colhe, no concernente à segunda acepção.
Donde se deduz a RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — Como diz Agostinho, o homem, no seu primeiro estado, recebeu o dom pelo
qual poderia perseverar; não o recebeu, contudo, para que perseverasse. No estado presente, porém,
pela graça de Cristo, muitos recebem o dom da graça, pelo qual podem perseverar, e além disso é-lhes
concedido perseverarem. Portanto, o dom de Cristo é maior que o delito de Adão. E contudo, o homem
podia, pelo dom da graça, perseverar mais facilmente, no estado de inocência, em que nenhuma
rebelião havia da carne contra o espírito, do que no estado presente, em que a restauração operada
pela graça de Cristo, embora já começada, no espírito, ainda não se consumou na carne. O que se dará
na prática, onde o homem, não só poderá perseverar, mas onde também não poderá pecar.