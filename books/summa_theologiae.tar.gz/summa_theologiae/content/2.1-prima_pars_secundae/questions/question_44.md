# Questão 44: Dos efeitos do temor.
Em seguida devemos tratar dos efeitos do temor. E sobre este ponto quatro artigos se discutem:

## Art. 1 — Se o temor causa contração.
O primeiro discute-se assim. — Parece que o temor não causa a contração.

1. — Pois, produzida a contração, o calor e os espíritos concentram-se no interior. Ora, o aumento do
calor e dos espíritos, no interior, provoca o coração a agir audazmente, como o vemos nos irados; e o
contrário se dá com o temor. Logo, este não produz a contração.

2. Demais — Da multiplicação dos espíritos e do calor, internamente, resulta rompermos em palavras,
como vemos acontecer com os que padecem alguma dor. Ora, os que temem não dizem palavra, mas
antes se tornam taciturnos. Logo, o temor não produz contração.

3. Demais — A vergonha é uma espécie de temor, como já se disse. Ora, os envergonhados enrubescem,
como diz Túlio e o Filósofo. Ora, o rubor das faces atesta, não a contração, mas, o contrário dela. Logo, a
contração não é efeito do temor.
Mas, em contrário, diz Damasceno, que o temor é um fenômeno produzido pela sístole, i. é, pela
contração.

SOLUÇÃO. — Como já dissemos, nas paixões da alma, o elemento formal é o movimento mesmo da
potência apetitiva; assim como o material é a transmutação corpórea, sendo, um desses elementos
proporcionado ao outro. Por onde, da semelhança e da natureza do movimento apetitivo resulta aquela
transmutação. Ora, quanto ao movimento animal do apetite, o temor implica uma certa contração. E a
razão é que ele provém da fantasia de um mal iminente que só dificilmente pode ser repelido, como já
dissemos. Ora, é a pouca força que faz com que uma coisa possa só dificilmente ser repelida, conforme
já se disse. E como a força tanto menos pode quanto menor é, da imaginação mesma, que causa o
temor, resulta para o apetite uma certa contração. Assim, vemos nos moribundos a natureza retrair-se
para o interior, por causa da pouca força; e vemos também que, nas cidades, quando os cidadãos
temem, retraem-se do exterior, concentrando-se, o mais que podem, no interior. E da semelhança com
esta contração, pertencente ao apetite animal, resulta que, quando há temor, o calor e os espíritos
corpóreos contraem-se no interior.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz o Filósofo, embora os espíritos dos que temem
retraiam-se do exterior para o interior, contudo o movimento deles não é o mesmo nessas pessoas que
nos irados. Pois, nestes, por causa do calor e da subtileza dos espíritos, provenientes do desejo da
vindicta, o movimento dos espíritos se realiza, interiormente, da parte inferior para a superior; e isso
explica que esses espíritos bem como o calor, se concentrem no coração. Donde resulta que os irados se
tornam prontos e audazes no ataque. Nos que temem, porém, por causa da frigidez crescente,
proveniente do imaginar na falta de forças, os espíritos se movem da parte superior para a inferior. E
por isso o calor e os espíritos não se multiplicam no coração, mas antes, dele se afastam; e essa a razão
por que os tímidos não atacam prontamente, mas antes, fogem.

RESPOSTA À SEGUNDA. — É natural a qualquer ser que sofre, homem ou animal, recorrer ao auxílio de
que dispõe, para repelir o mal presente, causa da dor. E por isso vemos os animais que sofrem alguma
dor defenderem-se com os dentes ou com os chifres. Ora, o máximo auxílio contra tudo, de que
dispõem os animais, são o calor e os espíritos. Por onde, na dor, a natureza conserva aquele e estes
interiormente, de modo a poder empregá-los na repulsa do mal. E, por isso, o Filósofo diz, que,
multiplicados os espíritos e o calor, internamente, por força eles se hão-de manifestar pela voz. Isso
explica que os que sofrem mal podem conter-se que não gritem. Nos que temem, porém, o movimento
do calor interno e dos espíritos, partindo do coração para os membros inferiores, como já dissemos, faz
com que o temor empeça a formação da voz, resultante da emissão dos espíritos para a parte superior,
por meio da boca. Por isso o temor nos torna calados; e a mesma causa explica também que o temor
nos faz tremer, como diz o Filósofo.

RESPOSTA À TERCEIRA. — Os perigos da morte não só contrariam o apetite animal mas também a
natureza. Por isto o temor que a morte provoca produz a contração, não só por parte do apetite, mas
também por parte da natureza corpórea. Pois o animal, pela imaginação da morte, fica de tal modo
disposto, que contrai o calor para a parte interna, como acontece quando a morte é naturalmente
iminente. Donde vem o empalidecerem os que temem a morte, como diz Aristóteles. Ao contrário, o
mal que a vergonha teme não se opõe à natureza, mas só ao apetite animal. Donde resulta uma certa
contração relativa a esse apetite; não porém relativa à natureza corpórea, pois antes, a alma, quase
contraída em si mesma, provoca o movimento dos espíritos e do calor, o que os leva a se difundirem
externamente. Eis porque os envergonhados enrubescem.

## Art. 2 — Se o temor nos torna conciliativos.
(IIª-IIªº, q. 129, a . 7; In Psalm. XII).
O segundo discute-se assim. — Parece que o temor não nos torna conciliativos.

1. — Pois, o que nos torna conciliativos não pode ao mesmo tempo impedir o conselho. Ora, o temor o
impede, porque toda paixão perturba a paz, necessária para o bom uso da razão. Logo, o temor não nos
torna conciliativos.

2. Demais — O conselho é um ato da razão pelo qual pensamos e deliberamos sobre o futuro. Mas, há
certo temor que impede o pensamento e nos faz perder a cabeça, como diz Túlio. Logo, o temor não nos
torna conciliativos, mas antes impede o conselho.

3. Demais — Assim como usamos do conselho para evitar o mal, dele usamos também para conseguir o
bem. Logo, o temor não nos torna, mais que a esperança, conciliativos.
Mas, em contrário, diz o Filósofo, que o temor nos torna conciliativos.

SOLUÇÃO. — Podemos ser conciliativos de dois modos. — Pela vontade ou solicitude em aconselhar. E
assim o temor nos torna conciliativos, porque, como diz o Filósofo, nós deliberamos sobre as grandes
coisas, em que quase descremos de nós mesmos. Ora, o que incute o temor não é mau, absolutamente
mas se reveste de uma certa grandeza, por ser apreendido, quer como algo que só dificilmente pode ser
repelido, quer como vindo a realizar-se proximamente, conforme já dissemos. Por onde, sobretudo nos
temores é que recorremos ao conselho. — De outro modo, dizemos que é conciliativo quem tem a
faculdade de aconselhar bem. E neste sentido nem o temor nem qualquer outra paixão nos torna
conciliativos. Porque, quando possuídos de uma paixão, vemos as coisas mais ou menos diferentes do
que elas na verdade são; assim, o amante acha melhores que na realidade as coisas que ama; e quem
teme acha mais terríveis que na realidade as coisas que lhe causam temor. Por onde, por falta da
retidão de juízo, qualquer paixão, em si mesma, impede a faculdade de aconselhar bem.
Donde se deduz clara A RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Quanto mais forte é uma paixão tanto maior travamento sofre quem é
tomado dela. Por onde, sendo o temor forte, embora queiramos deliberar, ficamos com o pensamento
perturbado de tal maneira, que não podemos tomar conselho. Sendo ele porém pequeno, que deixe
lugar ao conselho e nem conturbe demasiado a razão, pode até mesmo auxiliar a faculdade de bem
aconselhar, em razão da solicitude que provoca.

RESPOSTA À TERCEIRA. — Também a esperança nos torna conciliativos; pois, como diz o
Filósofo, ninguém delibera sobre o que desespera, como nem sobre o impossível, segundo o mesmo.
Ora, o temor nos torna mais conciliativos que a esperança; porque esta é relativa a um bem que
podemos alcançar, e aquele, a um mal que apenas podemos repelir. Por onde, maior dificuldade implica
este que aquela; e por isso deliberamos, como já dissemos, quando a situação é difícil, e mal confiamos
em nós.

## Art. 3 — Se o tremor é efeito do temor.
(Supra, a . 1, ad 2; In Psalm. XVII).
O terceiro discute-se assim. — Parece que o tremor não é efeito do temor.

1. — Pois, ele é resultante da frigidez, sendo por isso que vemos os homens frígidos tremerem. Ora,
parece que o temor não causa o frio, mas antes, o calor que desseca; e a prova está em os que temem
terem sede, principalmente quando o temor é máximo, como bem o demonstram os conduzidos à
morte. Logo, o temor não causa temor.

2. Demais — A emissão do supérfluo é provocada pelo calor; por isso, no mais das vezes, os remédios
laxativos são cálidos. Ora, essas emissões são ocasionadas, freqüentemente, pelo temor. Logo, parece
que este causa o calor, e portanto não causa tremor.

3. Demais — No temor o calor de fora concentra-se na parte interna. Se, pois, por causa dessa
concentração, o homem treme exteriormente, conclui-se por semelhança que, em todos os membros
exteriores, o tremor deverá ser causado pelo temor. Ora, tal não se dá. Logo, o tremor do corpo não é
efeito do temor.
Mas, em contrário, diz Túlio, que o tremor, a palidez e o ranger dos dentes resultam do terror.

SOLUÇÃO. — Como já dissemos, o temor provoca uma certa contração de fora para dentro, e isso
explica que os membros externos permaneçam frios. Daí o tremor, causado pela debilidade da força
reguladora dos membros; e para tal debilidade contribui sobretudo a falta de calor, instrumento pelo
qual a alma move, como diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Uma vez o calor concentrado, das partes externas para o
interior, ele multiplica-se interiormente, e sobretudo nas partes inferiores, i. é, que respeitam à
nutrição. E daí, consumida a umidade, nasce a sede e mesmo, às vezes, a soltura do ventre, e emissão
da urina e ainda do sêmen. Ou então, essa emissão do supérfluo se dá por causa da contração do ventre
e dos testículos, como diz o Filósofo.
Donde se deduz clara A RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — No temor o calor abandona o coração, tendendo dos membros superiores
para os inferiores; e por isso, aos temerosos se lhe treme sobretudo o coração e os membros que têm
qualquer ligação com o peito, onde está o coração. Isso explica que se lhes trema sobretudo a voz, pela
vizinhança da artéria vocal com o coração. E também lhes treme o lábio inferior e toda a mandíbula
inferior, pela ligação que têm com o coração; donde resulta o ranger dos dentes. Pela mesma razão,
tremem os braços e as mãos. Ou então, o fenômeno se explica por serem esses membros os mais
móveis; e por isso, aos que temem lhes tremem os joelhos, conforme aquilo da Escritura (Is 35,
3): Confortai as mãos frouxas, e corroborai os joelhos débeis.

## Art. 4 — Se o temor trava a operação.
O quarto discute-se assim. — Parece que o temor trava a operação.

1. — Pois, a operação fica impedida sobretudo pela perturbação da razão, que é quem a dirige. Ora, o
temor perturba a razão, como já dissemos. Logo, trava a operação.

2. Demais — Os que procedem com temor facilmente falham na operação; assim, quem se mete a andar
por cima de uma trave suspensa no alto cai, facilmente, por causa do temor; não cairia porém se
andasse sobre ela posta em baixo, pois então não teria temor. Logo, o temor trava a operação.

3. Demais — A preguiça ou indolência é uma espécie de temor. Ora, ela trava a operação. Logo, também
o temor.
Mas, em contrário, diz o Apóstolo (Fl 2, 2): obrai a vossa salvação com receio e com tremor; o que não
diria se o temor travasse a livre operação. Logo, o temor não a trava.

SOLUÇÃO. — A operação exterior do homem é causada certo pela alma como primeiro móvel; mas
pelos membros corpóreos, como instrumentos. Ora, uma operação pode ficar impedida tanto por
defeito do instrumento como do motor principal. Assim, por parte dos instrumentos corpóreos, o
temor, em si mesmo e por natureza, trava a operação exterior, pela falta de calor que causa nos
membros exteriores. Quanto à alma, por outro lado, se ele for moderado e não perturbar demasiado a
razão, contribuirá para a boa operação, causando uma certa solicitude e fazendo-nos deliberar e operar
mais atentamente. Se porém crescer de modo a perturbar a razão, impedirá a operação, mesmo da
alma. Ora, não é a esse temor que se refere o Apóstolo.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Os que caem de uma trave suspensa no alto é porque sofreram perturbações
da imaginação, causada pelo temor do acidente imaginado.

RESPOSTA À TERCEIRA. — Toda pessoa temerosa foge do que teme; por onde, sendo a preguiça o
temor da operação em si mesma, enquanto laboriosa, ela trava a operação, desviando desta a vontade.
Mas o temor referente a outras coisas coadjuva a operação na medida mesma em que inclina a vontade
a fazer aquilo pelo que fugimos do que tememos.