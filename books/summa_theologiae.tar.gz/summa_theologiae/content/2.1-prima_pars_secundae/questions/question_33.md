# Questão 33: Dos efeitos do prazer.
Em seguida devemos tratar dos efeitos do prazer. E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se a dilatação é efeito do prazer.
O primeiro discute-se assim. ― Parece que a dilatação não é efeito do prazer.

1. ― Pois, a dilatação concerne antes, ao amor, segundo o dito do Apóstolo (II Cord 6, 11): o nosso
coração se tem dilatado. E por isso, diz a Escritura, falando do preceito da caridade (Sl 118, 96): o teu
mandamento é largo sem medida. Ora, o prazer é uma paixão diferente do amor. Logo, a dilatação não
é um efeito do prazer.

2. Demais. ― O que se dilata se torna mais capaz de receber. Ora, receber concerne ao desejo,
referente a um objeto ainda não possuído. Logo, a dilatação concerne mais ao desejo que ao prazer.

3. Demais. ― A contração se opõe à dilatação, mas é própria do prazer, pois contraímos aquilo que
queremos reter. Ora, o mesmo se dá com o afeto do apetite em relação ao que deleita. Logo, a dilatação
não concerne ao prazer.
Mas, em contrário, para exprimir a alegria, diz a Escritura (Is 60, 5): Então tu verás e estarás em
afluência, e o teu coração se espantará e se dilatará fora de si mesmo. E demais disso, deleitação, ou
prazer, vem de dilatação, e por isso também se chama ledice (Laetitia), como já se disse.

SOLUÇÃO. ― A latitude é uma dimensão da grandeza corpórea, e por isso se atribui aos afetos da alma
só metaforicamente. Ora, a dilatação é assim chamada por ser um quase movimento para a latitude; e é
própria da deleitação por causa de duas condições que esta requer. ― Uma diz respeito à virtude
apreensiva, que apreende a união com um bem conveniente. E por esta apreensão, o homem percebe
ter alcançado uma certa perfeição, que é a grandeza espiritual. E então se diz que a sua alma se
engrandece ou dilata, pelo prazer. ― Outra condição é a atinente à virtude apetitiva, que assente no
objeto deleitável, nele descansa e como se lhe entrega, para apreendê-la no seu interior. E assim, o
afeto do homem se dilata pela deleitação, quase entregando-se para conter dentro de si o objeto que
deleita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Nada impede uma mesma expressão metafórica se
atribua a objetos diversos, segundo semelhanças diversas. Assim, a dilatação é própria do amor, em
virtude de uma certa extensão, i. é, enquanto o afeto do amante se estende a outros e o leva a cuidar
não só do que é seu, mas também do que aos outros pertence. À deleitação, por outro lado, é própria a
dilatação, enquanto que um ser se alarga para se tornar como mais capaz.

RESPOSTA À SEGUNDA. ― O desejo acarreta certamente uma dilatação, por causa da imaginação da
coisa desejada; mas muito mais, pela presença do objeto que já deleita. Pois, o ânimo se entrega mais
ao objeto que já deleita do que ao que é desejado e ainda não possuído, porque o prazer é o fim do
desejo.

RESPOSTA À TERCEIRA. ― Quem se deleita contrai, por certo, aquilo que deleita, inerindo-se-lhe
fortemente; mas ao mesmo tempo, dilata o coração para fruir perfeitamente do objeto deleitável.

## Art. 2 — Se o prazer nos provoca o desejá-lo mais.
(IV Sent., dist. XLIX, q. 3, a. 2, ad 3; In Ioann., cap. IV, lect. II).
O segundo discute-se assim. ― Parece que o prazer não nos provoca a desejá-lo mais.

1. ― Pois, todo movimento cessa uma vez chegado ao repouso. Ora, o prazer é um quase repouso do
movimento do desejo, como já se disse. Logo, o movimento do desejo cessa quando chega ao prazer.
Portanto, este na provoca o desejo.

2. Demais. ― Dois contrários não são causa um do outro. Ora, o objeto do prazer de certo modo se
opõe ao do desejo; pois este tem por objeto o bem ainda não adquirido, aquele, o bem já possuído.
Logo, o prazer não nos provoca a desejá-lo mais.

3. Demais. ― O fastio repugna ao desejo. Ora, o prazer muitas vezes causa fastio. Logo, não nos provoca
a desejá-lo mais.
Mas, em contrário, diz o Senhor (Jo 4, 13): Todo aquele que bebe desta água torna a ter sede. Água
significa, neste passo, segundo Agostinho, o prazer corpóreo.

SOLUÇÃO. ― O prazer pode ser considerado sob duplo aspecto: como atual e como existente apenas na
memória. Também a sede ou desejo pode ser considerada à dupla luz: em sentido próprio, enquanto
implica o desejo de um objeto ainda não possuído, e em sentido comum, enquanto importa a exclusão
do fastio.
Como atual, o prazer não nos provoca a sede ou o desejo do mesmo, propriamente falando, mas só por
acidente, dado que a sede ou desejo seja o apetite de um objeto ainda não possuído. Pois, o prazer é
um afeto do apetite relativo a um objeto presente. Ora, este pode não ser possuído perfeitamente, quer
por parte desse próprio objeto, quer por parte de quem o possui. ― O primeiro caso se dá quando o
objeto não é possuído total e simultânea mas, nós o recebemos sucessivamente, e então, deleitando-
nos com o que já possuímos, desejamos possuir o que resta; assim, ouvindo com prazer a primeira parte
de um verso, desejamos ouvir a outra parte, como diz Agostinho. E deste modo, quase todos os prazeres
corpóreos provocam-nos a sede de gozá-los mais e mais, até que sejam consumados; e isso porque
esses prazeres são conseqüentes a um certo movimento, como bem o mostram os da mesa. ― O
segundo caso se dá quando não possuímos imediata e perfeitamente, mas adquirimos paulatinamente
um objeto que, de si, existe de modo perfeito. Assim, neste mundo, deleitamo-nos quando percebemos
imperfeitamente algo sobre o conhecimento divino; e esse mesmo debate provoca a sede ou o desejo
do conhecimento perfeito; e podemos assim compreender o passo da Escritura (Ecl 24, 29): os que me
bebem terão ainda sede.
Se porém por sede ou desejo entendermos só a intensidade do afeto que exclui o fastio, então os
prazeres espirituais são os que, por excelência nos provocam a sede ou o desejo de gozá-los mais e
mais. Pois os prazeres corpóreos tornam-se fastidiosos ― como bem o demonstram os da mesa ―
quando, por aumento e continuidade, produzem a superexcrescência do hábito natural. Por onde, uma
vez chegados ao gozo perfeito dos prazeres corpóreos, enfastiamo-nos deles, e às vezes desejamos
outros. Os prazeres espirituais, pelo contrário, não produzem a superexcrescência do hábito natural,
antes, aperfeiçoam a natureza. E por isso, quando consumados, se tornam mais deleitáveis, salvo
quando por acidente a atividade contemplativa é acompanhada de certas operações das virtudes
corpóreas que cansam pela sua continuidade. E deste modo, podemos também compreender o passo
da Escritura (Ecle 24, 29): os que me bebem terão ainda sede; pois também dos anjos, que conhecem a
Deus perfeitamente e nele se deleitam, diz a Escritura (1 Pd 1, 12): ao qual os mesmos anjos desejam
ver.
Se porém considerarmos o prazer enquanto existente na memória e não atualmente, então por
natureza ele provoca a que cada vez dele tenhamos mais sede e desejo; o que bem se vê quando
voltamos àquela disposição em que o passado nos era deleitável. Se porém sofremos uma mudança em
virtude dessa disposição, já então a lembrança do prazer não nos causa prazer, mas fastio; assim, a
lembrança da comida para quem está farto.

DONDE A RESPOSTA Á PRIMEIRA OBJEÇÃO. ― Quando o prazer é perfeito causa um repouso completo
e cessa o movimento do desejo tendente ao objeto ainda não possuído. Quando porém é possuído
imperfeitamente, o movimento não cessa totalmente.

RESPOSTA À SEGUNDA. ― O que é possuído imperfeitamente sob certo aspecto é possuído e, sob
outro, não. E por isso podem simultaneamente se lhe referir o desejo e o prazer.

RESPOSTA À TERCEIRA. ― Os prazeres causam, sob certo ponto de vista, o fastio e, sob outro, o desejo,
como já dissemos.

## Art. 3 — Se o prazer impede o uso da razão.
(Supra, q. 4, a. 1, ad 3; infra q. 34, a. 1, ad 1; IIa IIae, q. 15 a. 3; q. 53, a. 6; IV Sent., dist. XLIX, q. 3, a. 5, q.
1 ad 4).
O terceiro discute-se assim. ― Parece que o prazer não impede o uso da razão.

1. ― Pois, o repouso concorre, por excelência, para o devido uso da razão, e por isso diz o Filósofo
que,estando em repouso e descansada, a alma torna-se ciente e prudente; e a Escritura (Sb 8,
16): Entrando em minha casa, acharei o meu descanso com ela. Ora, o prazer é um repouso. Logo não
impede, antes ativa o uso da razão.

2. Demais. ― As atividades que não pertencem ao mesmo sujeito, embora contrárias, não se impedem.
Ora, o prazer pertence à parte apetitiva e o uso da razão, à apreensiva. Logo, aquele não impede o uso
desta.

3. Demais. ― O que sofre impedimento proveniente de algum agente é, de certo modo, alterado por
este. Ora, o uso da virtude apreensiva, sendo a causa do prazer, move-o antes, do que sofre mudança
por parte dele. Logo, o prazer não impede o uso da razão.
Mas, em contrário, diz o Filósofo que o prazer corrompe a ponderação da prudência.

SOLUÇÃO. ― Como diz Aristóteles, os prazeres próprios aumentam a atividade, ao passo que os
estranhos a impedem. Ora, certos prazeres resultam do uso mesmo da razão; assim, quando nos
deleitamos com o contemplar ou o raciocinar. E este prazer não impede o uso da razão, mas o ativa,
porque fazemos mais atentamente o que nos causa prazer e a atenção ajuda a atividade.
Os prazeres corpóreos, porém, impedem o uso da razão, de tríplice modo. ― Primeiro, por causa da
distração. Pois, como já dissemos, atendemos muito ao com que nos deleitamos. Ora, a atenção
aplicada intensamente a um objeto se enfraquece em relação aos demais, ou totalmente deles se
desvia. E então, se o prazer corpóreo for grande, impedirá totalmente o uso da razão, atraindo para si
toda a atenção do espírito, ou a impedirá em grande parte. ― Segundo, por causa da contrariedade.
Pois, certos prazeres, levados ao excesso, são contra a ordem da razão. E por isso, o Filósofo diz, que os
prazeres corpóreos corrompem a ponderação da prudência;não porém a da razão especulativa, a que
não contrariam; por ex., não contrariam a verdade que o triângulo tem os três ângulos iguais a dois
retos. Ao passo que, pelo primeiro modo, impedem uma e outra. ― Terceiro, por uma certa obstrução.
Pois, ao prazer corpóreo é conseqüente uma certa transmutação corpórea, tanto maior que nas outras
paixões, porque o apetite se apega mais fortemente a um objeto presente que a um ausente. Ora, estas
perturbações corpóreas impedem o uso da razão, como vemos nos ébrios, que têm o uso dela obstruído
ou impedido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O prazer corpóreo causa, por certo, o repouso do
apetite no objeto deleitável, repouso que às vezes contraria a razão; mas sempre causa uma alteração
no corpo. E de um e outro modo impede o uso da razão.

RESPOSTA À SEGUNDA. ― As virtudes apetitiva e apreensiva, são, por certo, partes diversas, mas de
uma mesma alma. Por onde, se a intenção da alma se aplica veementemente a um ato de uma dessas
virtudes, fica impedida de exercer o ato contrário da outra.

RESPOSTA À TERCEIRA. ― O uso da razão implica no uso devido da imaginação e das demais virtudes
sensitivas, que se servem de órgão corpóreo. Por onde, a alteração do corpo impede o uso da razão,
desde que fica impedido o ato da virtude imaginativa e o das outras virtudes sensitivas.

## Art. 4 — Se o prazer aperfeiçoa a operação.
(IV Sent., dist. XLIX, q. 3, a. 3, qa. 3, ad 3; X Ethic., lect. VI, VII).
O quarto discute-se assim. ― Parece que o prazer não aperfeiçoa a operação.

1. ― Pois, toda operação humana depende do uso da razão. Ora, o prazer impede o uso da razão, como
já se disse. Logo, não aperfeiçoa, mas debilita a operação humana.

2. Demais. ― Nada se aperfeiçoa a si mesmo ou à sua causa. Ora, o prazer é uma operação, como diz
Aristóteles; e isso há-se de entender essencial ou causalmente. Logo, o prazer não aperfeiçoa a
operação.

3. Demais. ― Se o prazer aperfeiçoa a operação há de ser como fim, como forma, ou como agente. Ora,
como fim, não, porque não buscamos as operações por causa do prazer, mas antes ao contrário, como
já se disse. Nem tão pouco como causa eficiente, porque antes, a operação é a causa eficiente do
prazer. Nem por fim como forma, pois o prazer não aperfeiçoa a operação, com se fosse um hábito,
conforme o Filósofo. Logo, o prazer não aperfeiçoa a operação.
Mas, em contrário, diz o mesmo passo do autor que se acaba de citar, que o prazer aperfeiçoa a
operação.

SOLUÇÃO. ― O prazer aperfeiçoa a operação de dois modos. ― Como fim; não no sentido em que
chamamos fim àquilo por causa do que alguma coisa existe; mas no sentido em que todo bem
sobreveniente, como complemento, pode ser chamado fim. É neste sentido, diz o Filósofo, que o prazer
aperfeiçoa a operação, como um fim sobreveniente, a saber, enquanto ao bem, que é uma operação,
sobrevém outro bem, prazer, que implica o repouso do apetite no bem pressuposto. ― Segundo, como
causa agente, não diretamente, pois diz o Filósofo, que o prazer aperfeiçoa a operação, não como o
médico, senão como a saúde aperfeiçoa quem está são; mas indiretamente, a saber, enquanto o agente,
deleitando-se com a sua ação, atende-lhe mais veementemente e opera com maior diligência. É neste
sentido, diz Aristóteles, que o prazer aumenta as operações próprias e impede as estranhas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Nem todo prazer impede o ato da razão, mas, só o
prazer corpóreo que não é conseqüente a esse ato e sim ao do concupiscível, que cresce com o prazer.
O prazer, porém, conseqüente ao ato da razão fortifica o uso da mesma.

RESPOSTA À SEGUNDA. ― Como diz Aristóteles, duas coisas podem ser causa uma da outra, sendo
uma, causa eficiente e a outra, final. E deste modo, a operação causa o prazer como causa eficiente; e o
prazer aperfeiçoa a operação como causa final, conforme já se disse.

RESPOSTA À TERCEIRA. ― Resulta clara do que acabamos de dizer.