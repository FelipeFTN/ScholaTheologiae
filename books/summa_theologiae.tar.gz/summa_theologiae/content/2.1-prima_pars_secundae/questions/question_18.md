# Questão 18: Da bondade e da malícia dos atos humanos em geral.
Em seguida devemos tratar da bondade e da malícia dos atos humanos. Primeiro, de como é uma ação
humana boa ou má. Segundo, do que resulta da bondade ou da malícia dos atos humanos, p. ex., o
mérito ou o demérito, o pecado e a culpa.
Sobre o primeiro ponto ocorre tríplice consideração. A primeira é sobre a bondade e a malícia dos atos
humanos em geral. A segunda, da bondade e da malícia dos atos interiores. A terceira, da bondade e da
malícia dos atos externos.
Sobre a primeira questão onze artigos se discutem:

## Art. 1 — Se todas as ações humanas são boas ou se as há más.
(De Malo, q. 2, a . 4).
O primeiro discute-se assim. ― Parece que todas as ações do homem são boas e nenhuma é má.

1. ― Pois, como diz Dionísio, o mal só age em virtude do bem. Ora, este não produz aquele. Logo,
nenhuma ação é má.

2. Demais. ― Nada age senão enquanto atual. Ora, nada é mau por ser atual, mas por ser a potência
privação do ato; pois, um ser é bom na medida em que a potência é aperfeiçoada pelo ato, como diz
Aristóteles. Ora, nada age enquanto mau, mas só enquanto bom. Logo, todas as ações são boas e
nenhuma é má.

3. Demais. ― Só acidentalmente o mal pode ser causa, como se vê claramente em Dionísio. Ora, de toda
ação há de resultar algum efeito, necessariamente. Logo, nenhuma é má, mas todas são boas.
Mas, em contrário, diz o Senhor (Jo 3, 20): Porquanto todo aquele que obra mal aborrece a luz. Há
portanto ações humanas más.

SOLUÇÃO. ― Fala-se do bem e do mal das coisas, porque há proporção entre estas e as suas ações. Ora,
cada coisa é boa na mesma medida em que é, pois o bem e o ser se convertem, como já se disse na
primeira parte. Só Deus porém tem toda a plenitude do ser, por causa da sua unidade e simplicidade; ao
passo que as criaturas possuem a plenitude do ser que lhes convém, de modo múltiplo. Assim umas
possuem o ser de modo relativo, e contudo falta-lhes algo à plenitude devida. A plenitude do ser
humano, p. ex., implica a composição de alma e corpo, com todas as potências e instrumentos do
conhecimento e do movimento; por onde, a quem faltar um desses elementos, faltar-lhe-á algo da
plenitude do seu ser. Pois quanto tiver de ser tanto terá de bondade; e na medida em que lhe faltar algo
da plenitude do seu ser, nessa mesma lhe faltará a bondade e será considerado mau; assim, para um
cego é bem o viver e mal, estar privado da vista. Se porém não tivesse nenhum ser ou nenhuma
bondade, não poderia considerar-se mau nem bom. Como porém da essência do bem é a plenitude do
ser, o ente a que faltar a plenitude que lhe é devida, não será considerado bom, absoluta, mas
relativamente, enquanto ser; poderá contudo ser considerado ser, absolutamente, e não ser,
relativamente, conforme se disse na primeira parte.
Assim pois devemos concluir que toda ação, na medida em que é, nessa mesma é boa; e lhe faltará a
bondade, sendo, por isso considerada má, na mesma medida em que lhe faltar algo da plenitude do ser
devido; p. ex., se lhe faltar a quantidade determinada exigida pela razão, ou o lugar devido, ou coisa
semelhante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O mal age em virtude do bem deficiente. Se pois o bem
faltasse totalmente, não haveria ser nem ação; e se o bem não fosse deficiente, não haveria mal. Por
onde, a ação causada, em virtude de um bem deficiente, há de ser também deficientemente boa: é boa,
relativamente e má, absolutamente.

RESPOSTA À SEGUNDA. ― Nada impede um ser tenha, num ponto de vista, a atualidade, que o faz agir
e, noutro, a privação do ato, que lhe causa a ação deficiente. Assim um cego, tendo as pernas sãs, pode
andar; mas, privado da vista, com a qual se dirige, a marcha fica-lhe defeituosa e há de ser trôpego no
andar.

RESPOSTA À TERCEIRA. ― Uma ação má pode, por si, produzir um efeito, na medida em que tiver algo
de bondade e de ser. Assim, o adultério é causa de geração humana enquanto implica a união dos sexos
e não, enquanto contraria a ordem racional.

## Art. 2 — Se a ação humana haure no objeto a sua bondade ou malícia.
(Infra, q. 19, a . 1; II Sent., dist. 36, a . 5).
O segundo discute-se assim. ― Parece que a ação humana não haure no objeto a bondade ou a
malícia.

1. ― Pois, o objeto de uma ação é uma realidade. Ora, não nas coisas, mas no uso que delas fazem os
pecadores, está o mal, como diz Agostinho. Logo, a ação humana não haure no objeto a sua bondade ou
malícia.

2. Demais. ― O objeto é como a matéria da ação. Ora, a bondade de uma coisa não provém da matéria,
mas antes, da forma, que a atualiza. Logo, não é no objeto que os atos haurem a bondade ou a malícia.

3. Demais. ― O objeto da potência ativa está para a ação, como o efeito para a causa. Ora, a bondade
da causa não depende do efeito, mas antes, ao contrário. Logo, não se tira do objeto a bondade nem a
malícia do ato humano.
Mas, em contrário, diz a Escritura (Os 9, 10): e se tornaram abomináveis como as coisas que amaram.
Ora, o homem, pela malícia dos seus atos, é que se torna abominável perante Deus. Logo, essa malícia
depende dos maus objetos que o homem ama. E o mesmo se deve dizer da bondade.

SOLUÇÃO. ― Conforme já se disse, o bem e o mal das ações, como das demais coisas, depende da
plenitude ou da deficiência do ser. Ora, o que em primeiro lugar concorre para tal plenitude é aquilo
que especifica. E assim como a forma é a que especifica um ser natural, assim o objeto é o que
especifica o ato, como o termo, o movimento. Por onde, assim como a bondade primeira de um ser
natural depende da sua forma, que o especifica, assim a primeira bondade do ato moral depende do
objeto conveniente; e por isso alguns costumam falar do que é bom, no seu gênero, como, p. ex., usar o
que se possui. E assim como, nos seres naturais, o primeiro mal consiste em o ser gerado não conseguir
a sua forma específica, p. ex., se a geração, em vez de produzir um homem, produz outro ser, assim
também o primeiro mal nos atos morais, é o procedente do objeto, como tomar o bem de outrem. E
este se chama o mal no seu gênero, tomando gênero no sentido de espécie, como quando
dizemos gênero humano para significar toda a espécie humana.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora as coisas exteriores sejam em si mesmas boas,
nem sempre contudo mantêm a proporção devida com tal ação ou tal outra; e por isso, consideradas
como objetos de tais ações, cessam de ser boas.

RESPOSTA À SEGUNDA. ― O objeto não é a matéria da qual procede a ação, mas a matéria sobre a qual
ela recai; e exerce de certo modo a função de forma, enquanto especifica.

RESPOSTA À TERCEIRA. ― Nem sempre o objeto de uma ação humana é o de uma potência ativa. Pois,
a potência apetitiva é de certo modo passiva, enquanto movida pelo objeto desejado, e contudo é
princípio de atos humanos. Além disso, os objetos das potências ativas não são eleitos senão quando já
transformados; assim, o alimento transformado é o efeito da potência nutritiva; ao passo que o ainda
não transformado é como a matéria sobre a qual age essa potência. Demais disso, sendo o objeto de
certo modo efeito da potência ativa, resulta que é o termo da ação dela. E por conseqüência dá-lhe a
forma e a espécie, pois o movimento se especifica pelo termo. E embora a bondade de uma ação não
seja causada pela bondade do seu efeito, contudo chamamos boa a ação capaz de produzir bom efeito;
de modo que na proporção entre a ação e o efeito consiste a razão mesma da sua bondade.

## Art. 3 — Se as circunstâncias tornam uma ação boa ou má.
(II Sent., dist. XXVI, a . 5; De Malo, q. 2, a . 4, ad 5).
O terceiro discute-se assim. ― Parece que as circunstâncias não tornam uma ação boa

1. ― Pois, as circunstâncias circunstam ao ato, existindo como fora dele, segundo já se disse. Ora, o bem
e o mal existem nas coisas mesmas, como diz Aristóteles. Logo, as ações não são nem boas nem más em
virtude das circunstâncias.

2. Demais. ― É sobretudo da bondade e malícia dos atos que trata a ciência dos costumes. Ora, as
circunstâncias, sendo acidentes dos atos, escapam à consideração da ciência, pois nenhuma trata do
que é acidental, como diz Aristóteles. Logo, a bondade e a malícia dos atos não resulta das
circunstâncias.

3. Demais. ― O que convém a uma coisa substancialmente não se lhe a atribui acidentalmente. Ora, do
primeiro modo é que o bem e o mal convêm às ações pois elas podem ser genericamente boas ou más,
como já se disse. Logo, não lhes convêm serem boas ou más em virtude das circunstâncias.
Mas, em contrário, diz o Filósofo, que o homem virtuoso age como e quando deve, e conforme às
demais circunstâncias. Logo, ao contrário, o vicioso, dado a cada espécie de vício, age como e quando
não deve e em disconformidade com as demais circunstâncias. Logo, as ações humanas são boas ou más
conforme às circunstâncias.

SOLUÇÃO. ― Os seres naturais não recebem da forma substancial, que as especifica, toda a plenitude
da perfeição que lhes é devida, mas muito lhes acrescentam os acidentes supervenientes; assim ao
homem, a figura, a cor e os demais acidentes, dos quais, a falta de algum, para a proporção normal,
redunda em mal. Pois, o mesmo se dá com as ações, cuja plenitude de bondade não consiste toda na
espécie, mas no que lhes advém como acidente. Ora, tais são as circunstâncias devidas. Logo, se uma
delas falta, a ação há de ser má.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― As circunstâncias são exteriores à ação, por não serem
da essência desta, embora nela existam, como acidentes; do mesmo modo que os acidentes das
substâncias naturais são exteriores às essências delas.

RESPOSTA À SEGUNDA. ― Nem todos os acidentes tem relações contingentes com a substância, mas
alguns as têm necessárias, e como tais são objetos da consideração científica. E é deste modo que a
ciência dos costumes considera as circunstâncias dos atos.

RESPOSTA À TERCEIRA. ― O bem e o ser se convertem. Ora, assim como este é substancial e acidental,
assim também, tanto dos seres naturais como das ações morais, o bem é essencial e substancial.

## Art. 4 — Se a bondade e a malícia dos atos humanos provêm do fim.
(II Sent., dist. XXXVI, a . 5).
O quarto discute-se assim. ― Parece que a bondade e a malícia dos atos humanos não provêm do fim.

1. ― Pois, como diz Dionísio, nenhum ato visa o mal como fim do agir. Logo, se pelo fim é que os atos
são bons ou maus, nenhum será mau, o que é evidentemente falso.

2. Demais. ― A bondade de um ato lhe é algo de intrínseco. Ora, o fim é causa extrínseca. Logo, não é
em virtude do fim que uma ação se torna boa ou má.

3. Demais. ― Um ato bom pode se ordenar a um fim mau, como quando alguém dá esmola por
vanglória; e inversamente, um ato mau pode se ordenar a um fim bom, como quando alguém furta para
dar aos pobres. Logo, não é o fim que confere a bondade ou a malícia aos atos.
Mas, em contrário, diz Boécio: quem visa um fim bom é bom, e quem visa um mau, é mau.

SOLUÇÃO. ― As coisas se dispõem para a bondade como para o ser. Ora, há certas que têm o ser
independente, e em relação a essas basta lhes consideremos o ser, absolutamente. Há outras porém
que são dependentes, e devemos então considerar-lhes a causa de que dependem. Ora, assim como o
ser de uma coisa depende do agente e da forma, assim a bondade depende do fim. Por isso, a bondade
das Pessoas divinas, independente de tudo, não a julgamos relativamente a nenhum fim. As ações
humanas porém e quaisquer outras, cuja bondade é dependente, tiram a bondade do fim de que
dependem, abstraindo-se da bondade absoluta que lhes é intrínseca.
Assim pois a bondade de uma ação humana pode ser considerada em quatro pontos de vista. Uma é
genérica, que convém à ação como tal; pois, é boa na medida em que é ação, como já se disse. Outra é
específica, e lhe resulta do objeto conveniente. A terceira, dependente das circunstâncias, é como que
acidental. E a quarta, depende do fim, é constituída pela relação com a causa mesma da bondade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O bem que visamos, quando agimos nem sempre o é
verdadeiramente, mas às vezes é bem apenas aparente. E por isso, do fim resulta uma ação má.

RESPOSTA À SEGUNDA. ― Embora o fim seja causa extrínseca, contudo a proporção devida e a relação
com ele são inerentes à ação.

RESPOSTA À TERCEIRA. ― Nada impede que uma ação deixa de ter todas as quatro bondades referidas.
E então pode se dar que a ação boa na sua espécie e relativamente às circunstâncias se ordene a um fim
mau, e inversamente. De modo que é absolutamente boa só a ação na qual concorrem todas as
bondades; pois, ao passo que qualquer defeito, por pequeno que seja, causa o mal, o bem procede só
de uma causa íntegra, como diz Dionísio.

## Art. 5 — Se os atos morais bons e maus diferem especificamente.
(I, q. 48, a . 1, ad 2; II Sent., dist. XL, a . 1; III Cont. Gent., cap. IX; De Malo, q. 2, a . 4; De Virtut., q. 1, a . 2,
ad 3).
O quinto discute-se assim. ― Parece que os atos morais bons e maus não diferem especificamente.

1. ― Pois, a bondade e a malícia dos atos é como a das coisas, segundo já se disse. Ora, nestas o bem e
o mal não diversificam a espécie; assim, da mesma espécie é tanto o homem bom como o mau. Logo,
também a bondade e a malícia dos atos não os diversificam especificamente.

2. Demais. ― O mal, sendo privação, é de certo modo, não-ser. Ora, este não pode diferençar, como diz
o Filósofo. E, como a diferença constitui a espécie, resulta que um ato mau não pertence a nenhuma
espécie. Logo, o bem e o mal não diversificam especificamente, os atos humanos.

3. Demais. ― Atos especificamente diversos produzem efeitos diversos. Ora, um efeito pertencente a
uma determinada espécie pode resultar tanto de um ato bom como de um mau; assim, o homem é
gerado tanto do adultério como do concúbito matrimonial. Logo, os atos bons não diferem
especificamente dos maus.

4. Demais. ― Os atos são às vezes bons e maus pela circunstância, como já se disse. Ora, esta, sendo
acidente, não os especifica. Logo, não é pela bondade nem pela malícia que os atos diferem
especificamente.
Mas, em contrário. ― Segundo o Filósofo, hábitos semelhantes produzem atos semelhantes. Ora, os
hábitos bons diferem especificamente dos maus, como a liberalidade, da prodigalidade. Logo, também
os atos bons diferem do mesmo modo dos maus.

SOLUÇÃO. ― Todo ato se especifica pelo seu objeto, com já se disse. Por onde, é necessário que
qualquer diferença no objeto corresponda a uma diversidade específica nos atos. Devemos porém notar
que uma diferença no objeto, causa da diferença específica dos atos, relativamente a um princípio ativo,
não é causa relativamente a outro, pois, o acidental não especifica senão só o essencial. Ora, uma
diferença no objeto pode ser essencial, relativamente a um princípio ativo, e acidental relativamente a
outro; assim, o conhecimento da cor e o do som diferem relativamente ao sentido, mas não,
relativamente ao intelecto.
Ora, a bondade e a malícia dos atos humanos são relativos à razão. Pois, como diz Dionísio, o bem do
homem consiste em ser conforme à razão, e o mal, contrário. E na verdade, o bem de uma coisa é o que
lhe convém, formalmente, e o mal, o que lhe contraria a ordem formal. Por onde é claro que a diferença
entre o bem e o mal, considerada relativamente ao objeto, implica relação essencial com a razão, o que
lhe torna o objeto conveniente ou não conveniente; e assim, chamam-se humanos ou morais os atos
procedentes da razão. Logo, é claro que o bem e o mal diversificam especificamente os atos morais,
pois, as diferenças essenciais diversificam as espécies.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Mesmo nos seres naturais o bem e o mal, i. é, o que é
conforme ou contrário à natureza, diversifica-lhes as espécies; assim, o corpo vivo e o morto não
pertencem à mesma espécie. E, semelhantemente, o bem sendo o conforme à razão, e o mal, o que lhe
é contrário, diversificam a espécie moral.

RESPOSTA À SEGUNDA. ― A privação que o mal supõe não é absoluta mas, resultante de uma certa
potência. Assim, é especificamente mau um ato, não por não ter nenhum objeto mas por tê-lo não
conveniente à razão, como apoderar-se dos bens alheios. Por onde, na medida em que o objeto for algo
de positivo, pode constituir a espécie de um ato mau.

RESPOSTA À TERCEIRA. ― O ato conjugal e o adultério, enquanto referidos à razão, diferem
especificamente e produzem efeitos também especificamente diferentes; pois, aquele merece louvor e
prêmio e este, vitupério e pena. Não diferem porém de espécie enquanto relativos à faculdade de gerar;
e portanto produzem o mesmo efeito, especificamente.

RESPOSTA À QUARTA. ― A circunstância, considerada como diferença essencial do objeto enquanto
esta é relativa à razão, pode especificar um ato moral. E isto se dá necessariamente, sempre que a
circunstância muda em malícia a bondade de uma ato; pois, ela não torna mau o ato, senão porque
contraria à razão.

## Art. 6 — Se o fim diversifica especificamente os atos em bons e maus.
(II Sent., dist. XL, a . 1).
O sexto discute-se assim. ― Parece que o fim não diversifica especificamente os atos em bons e maus.

1. ― Pois, os atos se especificam pelo objeto. Ora, o fim não é objeto, de nenhum modo. Logo, o bem e
o mal dele procedente não diversificam os atos especificamente.

2. Demais. ― O acidental não especifica, como já se disse. Ora, é acidental a um ato ser ordenado para
um fim; assim, quando se dá esmola por vanglória. Logo, o fim não diversifica especificamente os atos
em bons e maus.

3. Demais. ― Atos especificamente diversos podem se ordenar a um mesmo fim; assim ao fim da
vanglória podem se ordenar os atos de diversas virtudes e de diversos vícios. Logo, o fim não diversifica
especificamente os atos em bons e maus.
Mas, em contrário, demonstrou-se acima que os atos humanos especificam-se pelo fim. Logo, o fim
diversifica especificamente os atos em bons e maus.

SOLUÇÃO. ― Certos atos se chamam humanos, enquanto voluntários, com já se disse. Ora, o ato
voluntário inclui dois outros: o interior, da vontade, e o exterior, tendo um e outro o seu objeto. Ora, o
fim propriamente é o objeto do ato interior da vontade; ao passo que o ato exterior tem por objeto
aquilo mesmo sobre o que recai. Por onde, assim como o ato exterior se especifica pelo objeto sobre o
qual recai, assim o ato interior da vontade, pelo fim, como seu objeto próprio. Ora, o que procede da
vontade tem por assim dizer valor de forma para o que procede do ato exterior, pois a vontade se serve,
para agir, dos membros, a modo de instrumentos; e nem os atos exteriores tem valor moral senão
enquanto voluntários. Logo, a espécie dos atos humanos é formalmente considerada em relação ao fim;
e materialmente, em relação ao objeto do ato exterior. Por onde, diz o Filósofo: aquele que furta para
cometer adultério é, propriamente falando, mais adúltero que ladrão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O fim equivale a um objeto, como se disse.

RESPOSTA À SEGUNDA. ― É acidental ao ato exterior ordenar-se a um certo fim, mas não o é ao ato
interior da vontade, pois este último está para o primeiro como a forma para a matéria.

RESPOSTA À TERCEIRA. ― Quando muitos atos especificamente diferentes se ordenam a um mesmo
fim, há certo, especificamente, diversidade em relação aos atos exteriores, mas unidade em relação ao
ato interior.

## Art. 7 — Se a espécie de bondade proveniente do fim está compreendida na proveniente do objeto, como a espécie, no gênero.
O sétimo discute-se assim. ― Parece que a espécie de bondade proveniente do fim está
compreendida na proveniente do objeto, como a espécie, no gênero; p. ex., quando alguém quer
furtar para dar esmola.

1. ― Pois, o ato se especifica pelo objeto, como já se disse. Ora, é impossível uma coisa estar
compreendida em uma determinada espécie, que, por sua vez, não esteja na que lhe é própria; pois,
uma mesma coisa não pode estar em diversas espécies não subordinadas entre si. Logo, a espécie
procedente do fim está compreendida na que procede do objeto.

2. Demais. ― A última diferença é sempre a que constitui a espécie especialíssima. Ora, a diferença
procedente do fim é posterior à procedente do objeto, porque fim é sinônimo de último. Logo, a espécie
procedente do fim está compreendida na procedente do objeto, como espécie especialíssima.

3. Demais. ― Quanto mais uma diferença é formal tanto mais especial é, pois a diferença está para o
gênero, como a forma, para a matéria. Ora, a espécie procedente do fim é mais formal que a
procedente do objeto, como já se disse. Logo, aquela está compreendida nesta como a espécie
especialíssima no gênero subalterno.
Mas, em contrário. ― Cada gênero tem as suas diferenças determinadas. Ora, um ato de uma mesma
espécie procedente do objeto pode se ordenar a infinitos fins; p. ex., o furto pode se ordenar a infinitos
bens ou males. Logo, a espécie proveniente do fim não está compreendida, como gênero, na que
procede do objeto.

SOLUÇÃO. ― O objeto do ato exterior pode ter dupla relação com o fim da vontade. Pode-se lhe
ordenar, essencialmente, como, p. ex., o lutar bem se ordena à vitória; ou, acidentalmente, assim furtar
para dar esmola. Ora, como diz o Filósofo, necessariamente as diferenças dividem o gênero e lhe
constituem as espécies, essencialmente. Se for acidental, a divisão não será procedente: p. ex., se
dividíssemos os animais em racionais e irracionais, e estes em alados e não alados a divisão seria
inaceitável, porque alados e não alados não determinam, essencialmente, irracionais. É necessário
dividir assim: animais que têm e que não têm pés; destes, uns tem dois pés, outros, quatro,
outros, muitos, divisões estas que determinam essencialmente a primeira diferença.
Portanto, quando o objeto não se ordena essencialmente ao fim, a diferença específica dele
proveniente não determina essencialmente a resultante do fim, e reciprocamente. Por onde, uma
dessas espécies, não se incluindo na outra, o ato moral pertence a duas como espécies disparatadas; e
por isso dizemos que quem furta para fornicar pratica duas malícias num só ato. Se porém o objeto se
ordena essencialmente ao fim, uma das diferenças é, essencialmente, determinante da outra, e
portanto uma está compreendida na outra.
Resta porém examinar qual é a compreendida; e para o sabermos claramente devemos considerar,
primeiro, que quanto mais particular é a forma donde deriva uma diferença, tanto mais específica é
esta. Segundo, quanto mais universal é um agente, tanto mais universal é a forma que dele procede.
Terceiro, quanto mais posterior é um fim, tanto maior é a sua correspondência a um agente mais
universal; assim, ao passo que a vitória, fim último do exército, é o fim visado pelo general chefe, o
comando de tal batalhão ou tal outro é o fim visado por chefes inferiores. Do sobredito se segue, que a
diferença específica procedente do fim é mais geral; e a procedente do objeto essencialmente ordenado
a um determinado fim, é específica em relação à primeira. Ora, a vontade, cujo objeto próprio é o fim, é
motor universal em relação a todas as potências da alma, cujos objetos próprios são os dos atos
particulares.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Substancialmente considerada, uma coisa não pode
estar compreendida em duas espécies não ordenadas uma para a outra, mas considerada
acidentalmente o pode, assim, uma fruta pertence, pela cor, a uma certa espécie, p. ex., a dos corpos
brancos, e pelo odor, à dos perfumados. E semelhantemente, os atos que substancialmente pertencem
a uma espécie natural, podem, pelas condições morais supervenientes, incluir-se em duas espécies,
como já se disse.

RESPOSTA À SEGUNDA. ― Último na execução, o fim é o primeiro na intenção da razão, pela qual se
determinam as espécies dos atos morais.

RESPOSTA À TERCEIRA. ― A diferença está para o gênero como a forma para a matéria, enquanto ela
atualiza o gênero; mas o gênero por sua vez é considerado como sendo mais formal que a espécie por
ser mais absoluto e menos contracto. Por onde, as partes da definição se reduzem ao gênero de causa
formal, como diz Aristóteles, e então o gênero é causa formal da espécie e tanto mais formal quanto
mais comum.

## Art. 8 — Se há atos especificamente indiferentes.
(II Sent., dist. XL, a . 5: De Malo, 1. 2, a . 5).
O oitavo discute-se assim. ― Parece que não há atos especificamente indiferentes.

1. ― Pois, o mal é a privação do bem, segundo Agostinho. Ora, privação e posse opõem-se
imediatamente, conforme o Filósofo. Logo, nenhum ato é especificamente indiferente, quase médio
entre o bem e o mal.

2. Demais. ― Os atos humanos se especificam pelo fim ou pelo objeto, com já se disse. Ora, um e outro
é bom ou mau. Logo, todo ato humano é especificamente bom ou mau e nenhum é indiferente.

3. Demais. ― Como já se disse, é considerado bom o ato que tem a devida perfeição de bondade; mau,
aquele ao qual ela falece. Ora, necessariamente todo ato ou tem a plenitude total da sua bondade ou
algo dela lhe falta. Logo, e necessariamente, todo ato é especificamente bom ou mau e nenhum,
indiferente.
Mas, em contrário, diz Agostinho: há certos fatos intermediários que podem ser produzidos com bom ou
mau ânimo, dos quais seria temerário julgar. Logo, há atos especificamente indiferentes.

SOLUÇÃO. ― Como já se disse, todo ato se especifica pelo seu objeto; e o ato humano chamado moral
se especifica pelo seu objeto, referido ao princípio dos atos humanos, que é a razão. Por onde, se o
objeto do ato inclui algo de conveniente à ordem da razão, esse ato será especificamente bom, p. ex.,
dar esmola a um pobre. Se porém incluir algo de repugnante à ordem da razão, será especificamente
mau, p. ex., furtar, i. é, apoderar-se do alheio. Ora, pode acontecer que o objeto do ato nada inclua de
pertencente à sobredita ordem, p. ex., ajuntar uma palha do chão, ir ao campo e outros. E tais atos são
especificamente indiferentes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Há duas espécies de privação: Uma é a do ser, a qual
nada deixa e tudo elimina; assim, a cegueira elimina totalmente a vista; as trevas, a luz; a morte, a vida;
e entre esta privação e o modo de ser que lhe é oposto não há intermediário possível. A outra consiste
em ser privado de certo modo; assim a doença é privação da saúde, não por eliminá-la totalmente, mas
por predispor para a sua perda total, que se dá pela morte; e esta privação, deixando alguma coisa, não
está sempre em oposição imediata como o seu contrário. Ora, deste modo é que o mal é privação do
bem, como diz Simplício ; pois, deixando algo dele, não o exclui totalmente. Por onde, pode haver um
meio termo entre o bem e o mal.

RESPOSTA À SEGUNDA. ― Todo objeto ou fim tem alguma bondade ou malícia, pelo menos natural
mas, nem sempre implica a bondade ou malícia moral, considerada em relação à razão, como já se
disse. Ora, é desta última que agora se trata.

RESPOSTA À TERCEIRA. ― Nem tudo o que convém a um ato lhe pertence à espécie. Por onde, embora
em a noção da sua espécie não esteja compreendido tudo o que pertence à plenitude da bondade do
ato, nem por isso este há de ser especificamente mau ou bom; assim, o homem não é especificamente
nem virtuoso nem vicioso.

## Art. 9 — Se um ato individualmente considerado pode ser indiferente.
(I Sent., dist. I, q. 3, ad 3; II, dist. XL, a . 5; IV, dist. XXVI, q. 1, a . 4; De Malo, q. 2, a . 5).
O nono discute-se assim. ― Parece que um ato individualmente considerado pode ser indiferente.

1. ― Pois, nenhuma espécie há que em si não contenha ou possa conter algum indivíduo. Ora, como já
se disse, atos há especificamente indiferentes, Logo, um ato individual pode ser indiferente.

2. Demais. ― Os atos individuais causam hábitos que lhes são conformes, como diz Aristóteles. Ora,
hábitos há indiferentes, pois, diz o Filósofo, que certos, como os plácidos e os pródigos, embora não
sejam maus, também não se consideram bons, por se desviarem da virtude, sendo portanto indiferentes
quanto ao hábito. Logo, atos individuais há indiferentes.

3. Demais. ― O bem moral se refere à virtude e o mal moral, ao vício. Ora, acontece às vezes que o
homem não ordena a nenhum fim virtuoso ou vicioso um ato especificamente indiferente. Logo, atos
individuais há indiferentes.
Mas, em contrário, diz Gregório numa homilia: É ociosa toda palavra a que falta a retidão necessária, ou
um motivo de justa necessidade ou de piedosa utilidade. Ora, a palavra ociosa é má, pois, os homens
darão conta dela no dia do juízo, como diz o Evangelho (Mt 12, 36). Pelo contrário, será boa a palavra
que tem o motivo da justa necessidade ou da pia utilidade. Logo, toda palavra é boa ou má e, pela
mesma razão, bom ou mau há de ser qualquer ato. Logo, nenhum ato individual é indiferente.

SOLUÇÃO. ― Pode dar-se, ás vezes que um ato especificamente indiferente seja, individualmente
considerado, bom ou mau. E isto porque o ato moral, como já se disse, tira a sua bondade, não só do
objeto que o especifica, mas também, das circunstâncias, que são como que acidentes; assim uma coisa
pode convir a um indivíduo humano, no ponto de vista dos seus acidentes individuais, e não convir ao
homem especificamente considerado. Ora, é necessário que um ato individual se revista de alguma
circunstância que o torne bom ou mau, ao menos quanto à intenção do fim. E sendo próprio da razão
ordenar, o ato procedente da razão deliberativa, que não se ordenar ao fim devido, por isso mesmo lhe
repugna a ele e é mau; o que se ordenar porém ao fim devido, entretanto na ordem da razão, é bom.
Ora, como necessariamente todo ato se ordena ou não ao fim devido, todos os atos humanos,
procedentes da razão deliberativa, individualmente considerados, ou são bons ou maus.
Os que, porém não procederem dessa razão, mas de uma certa imaginação, como coçar a barba, mover
as mãos ou os pés, esses não são, propriamente falando, morais ou humanos, pois, este caráter lhes
deriva da razão. Tais, atos serão portanto indiferentes, quase escapando ao gênero dos atos morais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― De muitos modos pode um ato ser especificamente
indiferente. De um modo, se a indiferença lhe for especificamente devida, e neste caso a objeção colhe.
Mas deste modo nenhum ato é especificamente indiferente, pois não há nenhum objeto de ato humano
que se não possa ordenar ao mal ou ao bem, pelo fim ou pela circunstância. De outro modo, porque não
é especificamente, bom nem mau, e portanto só por outra coisa poderá vir a sê-lo. Assim o homem não
é especificamente, nem branco nem negro; mas também a espécie não se opõe a tal, pois a brancura e a
negrura podem lhe sobrevir de outra causa que não os princípios da espécie.

RESPOSTA À SEGUNDA. ― O Filósofo considera mau, propriamente falando, o que é nocivo aos outros
homens. E nesse sentido diz que o pródigo não é mau porque a ninguém é nocivo, senão a si próprio. E
o mesmo se dá com todos os que não são nocivos ao próximo. Ora, nós aqui denominamos mal, em
geral, tudo o repugnante à razão; e neste sentido todo ato individual é bom ou mau, como se disse.

RESPOSTA À TERCEIRA. ― Todo fim que esteja na intenção da razão deliberativa pertence ao bem de
alguma virtude ou ao mal de algum vício. Pois, o ato mesmo de quem, ordenadamente procura o
sustento ou o descanso do próprio corpo ordena-se ao bem da virtude, porque a esse bem se ordena o
corpo assim tratado.

## Art. 10 — Se uma circunstância pode especificar um ato como bom ou mau.
(Supra, a . 5, ad 4; infra, q. 73, a . 7; IV Sent., dist. XVI, q. 3, a . 2, qª 3; De Malo, q. 2, a . 6, 7).
O décimo discute-se assim. ― Parece que uma circunstância não pode especificar um ato como bom
ou mau.

1. ― Pois, um ato se especifica pelo seu objeto. Ora, as circunstâncias diferem do objeto. Logo, não
especificam o ato.

2. Demais. ― As circunstâncias são como acidentes do ato moral, conforme se disse. Ora, o acidente não
especifica. Logo, a circunstância não constitui nenhuma espécie de bem ou de mal.

3. Demais. ― Uma mesma coisa não pode pertencer a várias espécies. Ora, um mesmo ato pode ter
muitas circunstâncias. Logo, a circunstância não especifica um ato como bom ou mau.
Mas, em contrário. ― O lugar é uma circunstância. Ora, ele pode especificar o ato moral como sendo
mau; assim furtar em lugar sagrado é sacrilégio. Logo, a circunstância especifica um ato como bom ou
mau.

SOLUÇÃO. ― Assim como as espécies dos seres naturais são constituídas pelas formas naturais, assim,
as dos atos morais, pelas suas formas, enquanto concebidas pela razão, segundo do sobredito resulta.
Como porém a natureza é unilateralmente determinada, não podendo o seu processo ir ao infinito, é
necessário chegar-se a uma forma última, donde derive a diferença específica, além da qual não pode
haver outra diferença específica. E daí vem que o acidente de um ser natural não pode constituir tal
diferença. Ao contrário, o processo da razão não está unilateralmente determinado, mas pode
prosseguir além de qualquer termo dado. Por onde, o que é considerado circunstância superveniente ao
objeto, que determina a espécie de um ato, pode por sua vez ser considerado pela razão ordenadora
como condição principal do objeto determinante da espécie do ato. Assim, o apoderar-se do alheio,
especificado pela noção de alheio como furto, exerce a função de circunstância, se ademais se
considerarem as questões de lugar ou de tempo. Mas como a razão ainda pode, no concernente ao
lugar, ao tempo e outras questões desse gênero, estabelecer relações, pode dar-se que a condição de
lugar, relativamente ao objeto, seja considerada contrária à ordem da razão, p. ex., porque ela ordena
que se não deve injuriar em lugar sagrado. De modo que o apoderar-se do alheio em tal lugar
acrescenta uma contrariedade especial à ordem da razão. E portanto, o lugar, considerado antes como
circunstância, o é agora como condição principal do objeto contrário à razão. E desta maneira sempre
que alguma circunstância respeite uma ordem especial da razão, favorável ou contrária,
necessariamente essa circunstância especifica o ato moral como bom ou mau.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A circunstância, na medida em que especifica um ato, é
considerada condição do objeto, segundo já se disse, e uma como diferença específica do mesmo.

RESPOSTA À SEGUNDA. ― A circunstância como tal, tendo natureza de acidente, não especifica; mas,
sim, quando transformada em condição principal do objeto.

RESPOSTA À TERCEIRA. ― Nem toda circunstância especifica um ato moral como bom ou mau, pois,
não é qualquer que implica uma relação de conveniência ou disconveniência com a razão. Por onde,
embora sejam muitas as circunstâncias de um ato, nem por isso ele há de pertencer a muitas espécies.
Todavia não há inconveniente em um ato moral pertencer a várias espécies morais, mesmo
disparatadas, como já se disse.

## Art. 11 — Se toda circunstância referente à bondade ou à malícia especifica um ato.
(Infra, q. 73, a . 7; IV Sent., dist. XVI, q. 3, a . 2, qª3; De Malo, q. 2, a . 7).
O undécimo discute-se assim. ― Parece que toda circunstância referente à bondade ou malícia
especifica um ato.

1. ― Pois o bem e o mal são diferenças específicas dos atos morais. Por onde, o que causa uma
diferença na bondade ou malícia do ato moral também a causa na diferença específica. Ora, tudo o que
aumenta a bondade ou malícia de um ato, fá-lo diferir, sob este aspecto, e portanto especificamente.
Logo, toda circunstância que aumenta a bondade ou malícia de um ato especifica-o.

2. Demais. ― A circunstância adveniente ou implica em si alguma razão de bondade ou malícia, ou não
implica. Se não, nada pode acrescentar à bondade ou malícia do ato; pois, o que não é bom não pode
tornar melhor, nem pode tornar pior o que não é mau. Se, pelo contrário, incluir em si qualquer razão
de bondade ou malícia, especifica por isso mesmo o ato. Logo, toda circunstância, que aumenta a
bondade ou a malícia, constitui nova espécie de bem ou de mal.

3. Demais. ― Segundo Dionísio, o mal é causado por um defeito qualquer. Ora, qualquer circunstância
agravante da malícia implica um defeito especial. Logo, causa nova espécie de pecado. E pela mesma
razão, qualquer que aumente a bondade parece acrescentar-lhe nova espécie de bondade, assim como
qualquer unidade acrescentada ao número produz nova espécie numérica, pois, o bem consiste
em número, peso emedida.
Mas, em contrário. ― O mais e o menos não diversificam a espécie, mas um e outro é circunstância que
aumenta a bondade ou a malícia. Logo, nem toda circunstância, que aumente a bondade ou a malícia,
especifica o ato moral como bom ou mau.

SOLUÇÃO. ― Como já dissemos, a circunstância especifica um ato moral como bom ou mau, quando
concernente a uma ordem especial da razão. Mas acontece, às vezes que uma circunstância não está
nesse caso, quer quanto ao bem, quer quanto ao mal, senão sendo pressuposta outra circunstância que
especifique como bom ou mau o ato moral. Assim, apoderar-se de alguma coisa em grande ou pequena
quantidade só concerne à ordem da razão, relativamente ao bem ou ao mal, se for pressuposta outra
condição da qual o ato tira a sua malícia ou a sua bondade; por exemplo, se esse bem for alheio ― o que
repugna à razão. Por onde, apoderar-se do alheio em grande ou pequena quantidade não diversifica a
espécie do pecado; mas pode agravá-lo ou diminuí-lo. E o mesmo se dá com os outros males ou bens.
Logo, nem toda circunstância, que aumente a bondade ou a malícia, diversifica a espécie do ato moral.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A diferença de aumento e diminuição, nas coisas
susceptíveis, desta e daquela, não diversifica a espécie, assim como a diferença de maior ou menor
brancura não faz diferir a espécie da cor. E, semelhantemente, o que diversifica, aumentando e
diminuindo o bem ou o mal, não causa diferença específica no ato moral.

RESPOSTA À SEGUNDA. ― A circunstância que agrava o pecado ou aumenta a bondade de um ato não
tem às vezes bondade ou malícia em si mesma, mas relativamente a uma outra condição do ato, como
se disse. E portanto, não confere espécie nova, mas aumenta a bondade ou a malícia proveniente dessa
outra condição.

RESPOSTA À TERCEIRA. ― Uma circunstância pode implicar um defeito particular, não em si mesma,
mas relativamente à outra coisa. E semelhantemente, pode acrescentar uma nova perfeição só por
comparação com outra coisa. De modo que, embora aumente a bondade ou a malícia, contudo nem
sempre faz variar a espécie de bem ou de mal.