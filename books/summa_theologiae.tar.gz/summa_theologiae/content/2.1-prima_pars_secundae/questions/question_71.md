# Questão 71: Dos vícios e dos pecados em si mesmos.
Em seguida devemos tratar dos vícios e dos pecados. E, sobre esta questão há seis pontos a
considerar.Primeiro, dos vícios e dos pecados em si mesmos. Segundo, da distinção deles. Terceiro, da
comparação deles entre si. Quarto, do sujeito do pecado. Quinto, da sua causa. Sexto, do seu efeito.
Sobre o primeiro ponto discutem-se seis artigos:

## Art. 1 — Se o vício é contrário à virtude.
O primeiro discute-se assim. ― Parece que o vício não é contrário à virtude.

1. ― Pois, a unidade é contrária à unidade, como Aristóteles o prova. Ora, à virtude é contrário o pecado
e a malícia. Logo, não o vício, pois este nome também se dá à indébita disposição dos membros
corpóreos ou à de quaisquer outras coisas.

2. Demais. ― Virtude designa uma certa perfeição da potência. Ora, o vício não designa nada de
pertinente à potência. Logo, não é contrário à virtude.

3. Demais. ― Como diz Túlio, a virtude é uma como saúde da alma. Ora, à saúde se opõe, mais que o
vício, a doença ou moléstia. Logo, o vício não é contrário à virtude.
Mas, em contrário, diz Agostinho, que o vício é uma qualidade que torna má a alma; ao passo que a
virtude éuma qualidade que torna bom quem a tem, como do sobredito resulta. Logo, o vício é contrário
à virtude.

SOLUÇÃO. ― Duas coisas podemos considerar na virtude: a sua essência mesma e aquilo a que ela se
ordena. À essência é susceptível o ser considerada diretamente e nas suas conseqüências. ―
Diretamente considerada, implica uma certa disposição do sujeito que se comporta segundo a sua
natureza. Donde o dito do Filósofo: a virtude é uma disposição do perfeito para o ótimo; e chamo
perfeito ao que é disposto segundo a natureza. ― Considerada nas suas conseqüências, a virtude é uma
certa bondade, pois, a bondade de uma coisa consiste em comportar-se de modo conveniente à sua
natureza.
E quanto àquilo a que ela se ordena, a virtude é um ato bom, como do sobredito claramente se colhe.
Por onde, segundo estas considerações, à virtude se contrapõe tríplice oposição. ― Uma é a do pecado,
oposto àquilo a que a virtude ordena, pois, propriamente, ele implica um ato desordenado, assim como
o ato da virtude é ordenado e devido. ― Em seguida, a malícia se opõe à virtude, que por essência,
implica uma certa bondade. ― Ao passo que o vício se opõe à essência direta da virtude; pois, o vício de
qualquer coisa consiste em ela não ter a disposição que lhe convém à natureza. Donde o dizer
Agostinho: Chama vício ao que vires faltar à perfeição da natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― As três oposições referidas não contrariam a virtude, à
mesma luz. Mas, o pecado lhe é contrário, enquanto ela obra o bem; a malícia, enquanto é uma certa
bondade; e o vício, propriamente, enquanto virtude.

RESPOSTA À SEGUNDA. ― A virtude implica não somente a perfeição da potência, que é o princípio da
ação, mas também, a devida disposição do sujeito. E isto porque cada ser obra enquanto atual. Por
onde, o que deve obrar o bem há-de por força ter em si mesmo boa disposição. E a esta luz o vício se
opõe à virtude.

RESPOSTA À TERCEIRA. ― Como diz Túlio, as doenças e as enfermidades são partes da natureza
viciosa. Assim,chama-se doença à corrupção de todo o corpo, como a febre ou coisa semelhante; ao
passo que enfermidade é a doença acompanhada de fraqueza; e o vício supõe o dissídio entre as partes
do corpo. A doença corpórea porém às vezes existe sem a enfermidade, como quando estamos
interiormente mal dispostos, sem que se nos fique impedida a atividade habitual; ao passo que, na
alma, conforme diz o mesmo autor, esses dois fenômenos não podem ser separados senão
mentalmente. Pois necessariamente, sempre que estamos de interior mal disposto e nutrindo um afeto
desordenado, tornamo-nos fracos para obrar como devemos, porquepelo fruto é que a árvore se
conhece, i. é, pelas obras, o homem, como diz o Evangelho (Mt 12, 33). Ao passo que o vício da
alma, conforme diz Túlio no mesmo lugar, é um hábito ou afeto da mesma, inconstante, durante toda a
vida e dissentindo de si mesma. O que se dá ainda sem doença ou enfermidade, como quando, por ex.,
pecamos por fraqueza ou paixão. Por onde, vício diz mais que enfermidade ou doença, assim como
também virtude diz mais que saúde, pois esta se inclui naquela. Logo, mais convenientemente se opõe o
vício à virtude que a enfermidade à doença.

## Art. 2 — Se o vício é contrário à natureza.
(Ad Roman., cap. I, VIII ; Ad Galat., cap. V, lect. VI).
O segundo discute-se assim ― Parece que o vício não é contrário à natureza.

1. ― Pois, o vício é contrário à virtude, como já se disse. Ora, as virtudes não nos procedem da natureza,
mas nos são causadas por infusão ou pelo costume, segundo já ficou dito. Logo, os vícios não são
contrários à natureza.

2. Demais. ― O que vai contra a natureza não é susceptível de costume; assim, a pedra nunca se
acostuma a ser dirigida para cima, como diz Aristóteles. Ora, certos se acostumam com os vícios. Logo,
estes não são contrários à natureza.

3. Demais. ― Nada de contrário à natureza se encontra freqüentemente nos que a têm. Ora,
freqüentemente se encontram homens viciosos; pois, no dizer do Evangelho (Mt 7, 13), larga é a porta
que guia para a perdição, e muitos são os que entram por ela. Logo, o vício não é contra a natureza.

4. Demais. ― O pecado está para o vício como o ato para o hábito, conforme do sobredito se colhe. Ora,
o pecado é definido: o dito, feito ou desejado contra a lei de Deus, segundo se vê claramente em
Agostinho. Ora, a lei de Deus é superior à natureza. Logo, devemos considerar o vício contrário, antes à
lei do que à natureza.
Mas, em contrário, diz Agostinho. Todo vício por si mesmo é contrário à natureza.

SOLUÇÃO. ― Como já se disse, o vício é contrário à virtude. Ora, a virtude de um ser consiste em ter a
boa disposição conveniente à sua natureza, como já ficou dito. Por onde e necessariamente, há vício
sempre que um ser qualquer tem disposição contrária ao que lhe convém à natureza. E isso é causa de
ser susceptível de vitupério; pois, no dizer de Agostinho, tem-se o nome de vitupério como derivado do
vício.
É mister, porém, considerar que a forma, que especifica o ser, lhe constitui por excelência a natureza.
Ora, o homem é constituído na sua espécie pela alma racional. Portanto, o contrário à ordem racional
colide propriamente com a natureza do homem como tal; e o que é conforme à razão o é também à sua
natureza, em si mesma considerada. Ora, como diz Dionísio, o bem do homem é estar de acordo com a
razão, e o mal, é estar contra ela. Por onde, a virtude humana, que torna o homem bom e boa a sua
obra, é-lhe conforme à natureza na medida em que lhe convém à razão; e o vício vai-lhe contra a
natureza na medida em que encontra a ordem racional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Embora as virtudes, na perfeição do seu ser, não sejam
causadas pela natureza, inclinam contudo ao que a esta é conforme, i. é, ao que é conforme à ordem
racional. Pois, diz Túlio, que a virtude é um hábito conforme à natureza, consentâneo com a razão. E
deste modo dizemos, que a virtude é conforme à natureza; entendendo-se, ao contrário, que o vício vai
contra ela.

RESPOSTA À SEGUNDA. ― No lugar citado, o Filósofo se refere ao contrário à natureza, no sentido de
esta expressão se opor ao que procede da natureza; e não, como oposta ao que lhe é conforme, ao
modo pelo qual dizemos, serem as virtudes conformes à natureza, por inclinarem ao que a esta convém.

RESPOSTA À TERCEIRA. ― Tem o homem dupla natureza: a racional e a sensitiva. E como pela operação
dos sentidos ele exerce o ato racional, mais são os sequazes das inclinações da natureza sensitiva, que
da ordem da razão. Pois são em maior número os que admitem o princípio de uma coisa, do que
aqueles que lhe chegam ao fim consumado. Donde, os vícios e pecados dos homens provêm de
seguirem a inclinação da natureza sensitiva, contra a ordem racional.

RESPOSTA À QUARTA. ― Tudo o contrário à natureza do artificiado vai também contra a da arte, por
meio da qual ele é produzido. Ora, a lei eterna está para a ordem da razão humana, como a arte para o
artificiado. Por onde, pela mesma razão, o vício e o pecado são contrários, tanto à ordem da razão
humana como à da lei eterna. E por isso Agostinho diz, que de Deus procede todas as naturezas o serem
o que são; e são viciosas na medida em que se afastam da arte daquele pelo qual foram feitas.

## Art. 3 — Se o vício, i. é, o hábito mau, é pior que o pecado, i. é, o ato mau.
O terceiro discute-se assim. ― Parece que o vício, i. é, o hábito mau, é pior que o pecado, i. é, o ato
mau.

1. ― Pois, assim como tanto melhor é o bem, quanto mais diuturno, assim, quanto mais diuturno, tanto
pior é o mal. Ora, o hábito vicioso é mais diuturno que os atos viciosos, rapidamente transitórios. Logo,
o hábito é pior que o ato vicioso.

2. Demais. ― Muitos males são mais para se fugirem, que um só mal. Ora, o hábito mau é causa virtual
de muitos atos maus. Logo, o hábito vicioso é pior que o ato vicioso.

3. Demais. ― A causa tem preeminência sobre o efeito. Ora, o hábito aperfeiçoa o ato, tanto na sua
bondade como na sua malícia. Logo, tanto em relação a esta como àquela, o hábito tem preeminência
sobre o ato.
Mas, em contrário. ― Somos justamente punidos por um ato vicioso; não porém por um hábito vicioso
não atualizado. Logo, o ato vicioso é pior que o hábito vicioso.

SOLUÇÃO. ― O hábito ocupa posição média entre a potência e o ato. Ora, é manifesto que, tanto em
relação ao bem como ao mal, o ato tem preeminência sobre a potência, conforme diz Aristóteles; pois, é
melhor agir bem que poder fazê-lo; e semelhantemente, merece maior vitupério agir mal, que poder
fazê-lo. Donde também se segue que, tanto em relação à bondade como à malícia, o hábito ocupa um
grau médio entre a potência e o ato; e assim, de um lado, o hábito, bom ou mau, tem preeminência,
pela sua bondade ou malícia, sobre a potência, e, de outro, é dependente do ato. E isto bem claramente
resulta de não se chamar bom ou mau o hábito senão por inclinar a um ato bom ou mau. Por onde, por
causa da bondade ou da malícia do ato, dizemos que um hábito é bom ou mau. E assim o ato, tanto na
sua bondade como na sua malícia, tem preeminência sobre o hábito, pois o que dá a um ser a sua
vitalidade a tem com maior razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Nada impede que uma coisa tenha, absolutamente,
preeminência sobre outra a qual é, de certo modo, inferior. Pois, absolutamente falando, julgamos
superior o que tem preeminência sobre outra coisa, levando em conta o que, numa e noutra, é
essencial; e relativamente falando, a que tem preeminência quanto ao que é, em ambas, acidental. Ora,
como já demonstramos, da noção mesma de ato e de hábito resulta que aquele, tanto na sua bondade
como na sua malícia, tem preeminência sobre este. E o ser o hábito mais diuturno que o ato resulta,
acidentalmente, de que um e outro existe numa natureza tal que não pode agir sempre, e cuja ação se
opera por um movimento transitivo. Logo, absolutamente falando, o ato, tanto na bondade como na
malícia, tem preeminência; mas, o hábito a tem, relativamente.

RESPOSTA À SEGUNDA. ― Um hábito não é constituído, de modo absoluto, de muitos atos, senão só de
modo relativo, i. é, virtualmente. E por isso não se pode concluir daqui, que ele tenha, absolutamente,
quanto à bondade ou à malícia, preeminência sobre o ato.

RESPOSTA À TERCEIRA. ― O hábito é causa do ato, no gênero da causa eficiente; mas, este é causa
daquele no gênero da causa final, apoiados na qual distinguimos as noções de bem e de mal. Logo,
quanto à bondade e à malícia, o ato tem preeminência sobre o hábito.

## Art. 4 — Se o ato vicioso ou pecado pode coexistir com a virtude.
(Supra, q. 63, a. 2, ad 2 ; infra, q. 73, a. 1, ad 2 ; IIª-IIªª, q. 24, a. 12; De Virtur., q. q, 1, ad 5).
O quarto discute-se assim. ― Parece que o ato vicioso ou pecado não pode coexistir com a virtude.

1. ― Pois, os contrários não podem coexistir no mesmo sujeito. Ora, o pecado é de certo modo
contrário à virtude, como já se disse. Logo, não pode coexistir com ela.

2. Demais. ― O pecado é pior que o vício, i. é, o ato mau é pior que o hábito mau. Ora, o vício não pode
coexistir com a virtude, no mesmo sujeito. Logo, nem o pecado.

3. Demais. ― Assim como o pecado se manifesta acidentalmente na atividade voluntária, assim
também, nos fenômenos naturais, conforme diz Aristóteles. Ora, nestes nunca ele se manifesta
acidentalmente senão por alguma corrupção da virtude natural; assim, os monstros procedem da
corrupção de algum princípio seminal, como diz o Filósofo. Logo, também na atividade voluntária, o
pecado não se manifesta acidentalmente senão corrupção de alguma virtude da alma; e portanto,
pecado e virtude não podem coexistir no mesmo sujeito.
Mas, em contrário, diz o Filósofo, que pelos contrários é a virtude gerada corrompida. Ora, um só ato
virtuoso não causa a virtude, como já estabelecemos. Logo, também não a elimina um só ato
pecaminoso. Portanto, uma e outro podem coexistir no mesmo sujeito.

SOLUÇÃO. ― O pecado está para a virtude como o ato mau para o hábito bom. Ora, o hábito da alma
não se comporta do mesmo modo que a forma do ser natural. Pois, a forma natural necessariamente
produz a sua operação própria. Por isso com uma forma natural não pode coexistir o ato da forma
contrária; assim, o ato de resfriar não pode coexistir com o calor, nem, com a leveza, o ato do descenso,
salvo por violência de um motor externo. O hábito da alma ao contrário, não opera necessariamente,
antes, usamos dele quanto queremos. Por onde, podemos simultaneamente ter um hábito e dele não
usarmos, ou praticarmos o ato contrário; e, assim, podemos possuir a virtude e inclinarmos para o ato
do pecado.
Ora, este ato, comparado com a virtude, enquanto hábito, não pode corrompê-la, se for um único. Pois,
assim como não gera o hábito um único ato, assim também por este não se corrompe, como já
dissemos. Comparado porém o ato do pecado com a causa das virtudes, um só ato pode corromper
várias virtudes. Pois, todo pecado mortal é contrário à caridade, raiz de todas as virtudes infusas, como
tais. E portanto, um único ato de pecado mortal, excluindo a caridade, exclui conseqüentemente todas
as virtudes infusas, enquanto virtudes. E digo isto por causa da fé e da esperança, cujos hábitos ficam
informes, depois do pecado mortal, e assim não são virtudes. Mas o pecado venial, não contrário à
caridade, não a excluindo, também não exclui, por conseqüência, as outras virtudes. As virtudes
adquiridas porém, não as exclui um único ato de qualquer pecado.
Assim, portanto, o pecado mortal não pode coexistir com as virtudes infusas, mas o pode com as
adquiridas. Ao passo que o pecado venial pode coexistir tanto com estas como com aquelas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O pecado não é contrário à virtude em si mesma
considerada, senão quanto ao seu ato. E, portanto, o pecado, que não pode coexistir com o ato da
virtude, o pode com o hábito da mesma.

RESPOSTA À SEGUNDA. ― O vício é diretamente contrário à virtude, assim como o pecado o é ao ato
virtuoso. E portanto, o vício exclui a virtude, como o pecado, o ato da mesma.

RESPOSTA À TERCEIRA. ― As virtudes naturais agem necessariamente; e portanto, existindo íntegra a
virtude, o pecado nunca poderá coexistir com o ato. As virtudes da alma porém, não produzem os seus
atos necessariamente. E portanto o símile não colhe.

## Art. 5 — Se qualquer pecado implica um ato.
(II Sent., dist. XXXV, a. 3 ; De Malo, q. 2. a. 1).
O quinto discute-se assim. ― Parece que todo pecado implica um ato.

1. ― Pois, o mérito está para a virtude, como o pecado para o vício. Ora, o mérito não pode existir sem
algum ato. Logo, também não o pode o pecado.

2. Demais. ― Agostinho diz: todo pecado é voluntário; pois, se fosse involuntário não seria pecado. Ora,
nada pode ser voluntário a não ser por um ato de vontade. Logo, todo pecado implica algum ato.

3. Demais. ― Se o pecado não implicasse nenhum ato, seguir-se-ia que quem cessasse o ato próprio
pecaria. Ora, quem nunca praticou tal ato cessa continuamente de o praticar. Donde se segue que peca
continuamente, o que é falso. Logo, não há nenhum pecado sem ato.
Mas, em contrário, diz a Escritura (Tg 4, 17): Aquele que sabe fazer o bem e não o faz, peca. Ora, não
fazer não implica nenhum ato. Logo, o pecado pode existir sem qualquer ato.

SOLUÇÃO. ― Esta questão surge principalmente a propósito do pecado de omissão, sobre o qual variam
as opiniões. ― Assim, para alguns, todo pecado de omissão implica um ato interior ou exterior. Interior,
como quando queremos não ir à igreja, estando obrigado a fazê-lo. Exterior como quando, na hora em
que devíamos ir à igreja, ou mesmo antes, nos ocupamos de modo a ficarmos impedido de o fazer. E
este caso vem de certo modo a cair no primeiro, pois se quisermos uma coisa que não pode coexistir
com outra, conseqüentemente queremos ficar privado de uma delas; salvo se não refletirmos em que
aquilo que queremos fazer nos tolhe a obrigação, podendo então por negligência ser considerado
culpado. ― Para outros porém, o pecado de omissão não supõe nenhum ato; pois, já não fazer o que
devemos é pecado.
Ora, ambas essas opiniões encerram parte de verdade. ― Assim, se compreendermos no pecado de
omissão aquilo o que em si mesmo pertence à essência do pecado, às vezes esse pecado é
acompanhado do ato interior, como quando queremos não ir à igreja; outras vezes não implica nenhum
ato interior ou exterior, como quando, na hora em que devemos ir à igreja, de nenhum modo pensamos
em a ela ir ou não. ― Se porém compreendermos no pecado de omissão também as causas ou ocasiões
dela, então necessariamente esse pecado implica algum ato. Pois, tal pecado não existe senão quando
omitimos o que podemos fazer ou não. Ora, só por uma causa ou ocasião conjunta ou precedente é que
nos inclinamos a não fazer o que podemos ou não fazer. E se essa causa não estiver em nosso poder,
não implica pecado a omissão, como quando por doença deixamos de ir à igreja. Se pelo contrário, a
causa ou ocasião de omitir está ao alcance da vontade, a omissão implica pecado. E portanto, sempre
necessariamente essa causa, enquanto voluntária, implica algum ato, pelo menos interior, da vontade.
E esse ato recai às vezes sobre a omissão mesma; assim, quando queremos não ir à igreja para evitar um
trabalho. E então, tal ato, em si mesmo, faz parte da omissão, porque, por si, a vontade de qualquer
pecado, faz parte deste, por ser o voluntário da essência do pecado. Outras vezes porém, o ato da
vontade é levado, diretamente, a outra coisa, que nos impede o ato devido. E isso se dá, quer quando
aquilo a que a vontade é levada é conjunto com a omissão, como no caso de querermos nos divertir no
tempo em que devíamos ir à igreja; quer quando é precedente, como no caso de querermos nos divertir
até muito tarde, não podendo, por isso, ir em horas matinais à igreja. E então, esse ato interior leva à
omissão acidentalmente, porque esta daí resulta, mas contra a intenção; e o contrário à intenção
considera-se acidental, segundo diz Aristóteles. Por onde, é manifesto que neste caso o pecado de
omissão implica um ato conjunto ou precedente, que contudo se prende acidentalmente ao pecado de
omissão. Ora, devemos julgar as coisas pelo que têm de essencial e não, de acidental. Por onde e com
mais verdade, podemos dizer que há pecados que podem existir sem qualquer ato; do contrário
também a essência dos outros pecados atuais implicaria os atos e as ocasiões circunstanciais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O bem implica mais elementos que o mal,
porque aquele provém de uma causa totalmente íntegra, ao passo que este, de qualquer defeito
particular, como diz Dionísio. E portanto, o pecado pode provir ou de fazermos o que não devemos, ou
de não fazermos o que devemos; enquanto que só pode haver mérito quando fazermos
voluntariamente o que devemos. E logo, não pode haver mérito sem ato, mas sem ato pode haver
pecado.

RESPOSTA À SEGUNDA. ― Chama-se voluntário ao que não só é objeto de um ato da vontade, mas que
também está em nosso poder ser ou não feito, como diz Aristóteles. Por onde, também o mesmo não
querer pode se chamar voluntário, enquanto está em nosso poder querer ou não.

RESPOSTA À TERCEIRA. ― O pecado de omissão contraria a um preceito afirmativo, que obriga sempre
mas não para sempre. Portanto, pecamos quando cessamos o ato só durante o tempo em que o
preceito afirmativo obriga.

## Art. 6 — Se o pecado é convenientemente definido assim: o dito, feito ou desejado contra a lei eterna.
(II Sent., dist. XXXV, a. 2; De Malo, q. 2, a. 1).
O sexto discute-se assim. ― Parece que o pecado é inconvenientemente definido: o dito, feito ou
desejado contra a lei eterna.

1. ― Pois, o dito, feito ou desejado implica algum ato. Ora, nem todo pecado implica um ato, como já se
disse. Logo, esta definição não inclui todo pecado.

2. Demais. ― Agostinho diz: O pecado é a vontade de reter ou conseguir o que a justiça proíbe. Ora,
tomando-se a conseqüência em sentido lado, no sentido de qualquer apetite, ela compreende a
vontade. Logo, bastaria dizer: é pecado o desejado contra a lei eterna, sem ser preciso acrescentar: dito
ou feito.

3. Demais. ― O pecado parece que consiste propriamente no desvio do fim; pois, o bem e o mal se
consideram principalmente em relação ao fim, como do sobredito resulta. Por isso, Agostinho define o
pecado relativamente ao fim, dizendo: pecar não é senão buscar as causas temporais, desprezando as
eternas; e ainda: toda a perversidade humana consiste em usarmos do que devemos fruir e fruirmos do
que devemos usar. Ora, na definição precitada não se faz nenhuma menção do desvio do fim devido.
Logo, o pecado é insuficientemente definido.

4. Demais. ― Chama-se proibido ao contrário à lei. Ora, nem todos os pecados são maus por serem
proibidos; antes, certos são proibidos por serem maus. Logo, numa definição comum, não se devia dizer
que o pecado vai contra a lei de Deus.

5. Demais. ― Pecado significa um ato humano mau, como do sobredito resulta. Ora, o mal do homem é
ir contra a razão, como diz Dionísio. Logo, devia dizer antes, que o pecado é contra a razão do que
contra a lei eterna.
Em contrário, basta a autoridade Agostinho.

SOLUÇÃO. ― Como é claro pelo já dito, o pecado não é senão um ato humano mau. Ora, o que torna
humano um ato é o ser voluntário, como pelo sobredito se patenteia. Voluntário, ou por ser como
elícito da vontade, sendo tal o caso do querer ou do escolher; ou por ser por ela imperado, como os atos
exteriores de falar ou obrar. Por outro lado, o que torna mau é o ser falto da comensuração devida. E
como toda comensuração supõe a comparação com uma regra, faltando esta, essa coisa será
incomensurada. Ora, a regra da vontade humana é dupla. Uma próxima e homogênea, que é a própria
razão humana; a outra é a regra primeira, a saber, a lei eterna, que é a quase razão de Deus. E por isso
Agostinho, na definição do pecado, introduziu dois elementos. Um pertence à substância do ato
humano, como o que é quase material no pecado, quando diz: o dito, o feito ou desejado; outro,
pertencente à essência do mal, como sendo o que no pecado é quase formal, quando diz: contra a lei
eterna.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Afirmação e negação reduzem-se ao mesmo gênero;
assim como, nas Pessoas Divinas, gerado e não gerado se reduzem à relação, no dizer de
Agostinho. Portanto, devemos considerar como significando o mesmo ― dito e não dito, feito e não
feito.

RESPOSTA À SEGUNDA. ― A causa primeira do pecado está na vontade, que rege todos os atos
voluntários, únicos susceptíveis dele. E por isso, Agostinho às vezes define o pecado só pela vontade.
Mas como também os atos exteriores pertencem à substância do pecado, sendo em si mesmos, maus,
segundo dissemos, é necessário também introduzir na definição dele algo de pertencente a tais atos.

RESPOSTA À TERCEIRA. ― A lei eterna, primária e principalmente, ordena o homem para o fim, e por
conseqüência o leva a usar bem dos meios. E por isso, quando a definição diz ― contra a lei eterna ―
toca no desvio do fim e em tudo o mais que seja desordenado.

RESPOSTA À QUARTA. ― Quando se diz que nem todo pecado é um mal por ser proibido, entende-se a
proibição do direito positivo. Se porém nos referimos ao direito natural, contido primariamente na lei
eterna, e secundariamente no judicatório natural da razão humana, então todo pecado é mal, por ser
proibido. Pois, por isso mesmo que é desordenado repugna ao direito natural.

RESPOSTA À QUINTA. ― O pecado é considerado pelos teólogos principalmente como ofensa a Deus;
porém, pelo filósofo moral, enquanto contrário à razão. Por onde, Agostinho definia o pecado
convenientemente, antes, pelo que tem de contrário à lei eterna, do que por ser contra a razão. Tanto
mais que, pela lei eterna, nós nos regulamos em muitos casos excedentes à razão humana, como se dá
com as coisas da fé.