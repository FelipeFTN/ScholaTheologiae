# Questão 31: Do prazer em si mesmo.
Em seguida devemos tratar do prazer e da tristeza.
Sobre o prazer quatro questões devemos considerar. Primeira, do prazer em si mesmo. Segunda, das
causas do prazer. Terceira, dos seus efeitos. Quarta, da sua bondade e malícia.
Sobre a primeira questão oito artigos se discutem:

## Art. 1 — Se o prazer é uma paixão.
(Infra, q. 35, a . 1; IV Sent., dist. XLIX, q. 3, a . 1, qª 1)
O primeiro discute-se assim. ― Parece que prazer não é uma paixão.

1. ― Pois, Damasceno distingue a operação, da paixão, dizendo que a operação é um movimento
segundo a natureza; a paixão porém é um movimento contra a natureza. Ora, o prazer é uma operação,
como diz o Filósofo. Logo, o prazer não é uma paixão.

2. Demais. ― Sofrer é ser movido, como diz Aristóteles. Ora, o prazer consiste, não em ser movido, mas
em tê-lo sido pois é causado pelo bem já adquirido. Logo, não é uma paixão.

3. Demais. ― O prazer consiste numa certa perfeição de quem o goza, pois aperfeiçoa a operação, como
diz Aristóteles. Ora, aperfeiçoar-se não é sofrer nem ser alterado, segundo o mesmo filósofo. Logo, o
prazer não é uma paixão.
Mas, em contrário, Agostinho coloca o prazer ou gáudio ou alegria entre as paixões da alma.

SOLUÇÃO. ― O movimento do apetite sensitivo chama-se propriamente paixão, como já se disse. Ora,
qualquer afeto procedente da apreensão sensitiva é movimento do apetite sensitivo, que há-de convir
necessariamente ao prazer. Pois, como diz o Filósofo o prazer é um certo movimento da alma e uma
disposição simultaneamente completa para um objeto natural presente.
E para entendimento desta doutrina devemos considerar que, como certos seres naturais, assim
também certos animais conseguem alcançar as suas perfeições naturais. E embora o ser movido para a
perfeição não seja um ato simultaneamente completo, contudo o ato de conseguir a perfeição natural o
é. Pois entre os animais e os outros seres naturais há a diferença que estes não sentem, quando
constituídos no que lhes convém à natureza, ao passo que aqueles o sentem, e este sentimento causa
um movimento da alma no apetite sensitivo, movimento que é o prazer. É pois, genericamente que se
diz que o prazer é um movimento da alma. E quando se diz disposição para um objeto natural presente,
i. é, existente realmente em a natureza, assinala-se a causa do prazer, que é a presença do bem
conatural. Quando dizemos simultaneamente completo mostramos que a disposição não deve ser
considerada enquanto se opera, mas depois de operada, quase no termo do movimento; pois o prazer
não é um vir-a-ser, como queria Platão, mas antes, como diz Aristóteles, um estado. Quando por fim se
diz sensível, excluem-se as perfeições das coisas insensíveis, não susceptíveis de prazer. ― Por onde,
conclui-se claramente que, sendo um movimento do apetite animal, conseqüente à apreensão do
sentido, o prazer é uma paixão da alma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A operação conatural não impedida é uma perfeição
segunda, como diz Aristóteles. Por onde, o prazer lhes advém às coisas constituídas na operação própria
conatural e não impedida, e constitui um estado perfeito, como dissemos. Assim, pois, quando se diz
que o prazer é uma operação, essa predicação não é essencial, mas causal.

RESPOSTA À SEGUNDA. ― Podemos considerar no animal, duplo movimento: o relativo à intenção que
visa o fim, e este concerne o apetite; e o relativo à execução, e este respeita a operação exterior.
Embora pois no ser que já conseguiu o bem com o qual se deleita, cesse o movimento de execução, pelo
qual tendeu ao fim, não cessa contudo o movimento da parte apetitiva, a qual como antes desejava o
que não possuía, agora se deleita como o bem que possui. Por onde, não obstante seja o prazer um
certo repouso do apetite em presença do bem deleitoso, que lhe satisfaz, contudo ainda continua a
imutação do apetite pelo seu objeto, em razão do qual o prazer é um movimento.

RESPOSTA À TERCEIRA. ― Embora o nome de paixão convenha sobretudo e propriamente às paixões
corruptivas e tendentes ao mal, como se dá com os sofrimentos corpóreos, e com a tristeza e o temor,
na alma, contudo certas paixões se ordenam ao bem, como já se disse. E neste sentido o prazer se
chama paixão.

## Art. 2 — Se o prazer se realiza no tempo.
(IV Sent., dist. XLIX, q. 3, a . 1, qª 3; De Verit., q. 8, a . 14, ad 2).
O segundo discute-se assim. ― Parece que o prazer se realiza no tempo.

1. ― Pois, o prazer é um movimento, como diz o Filósofo. Ora, todo movimento se realiza no tempo.
Logo, também o prazer.

2. Demais. ― Chama-se diuturno ou moroso o que se realiza no tempo. Ora, certos prazeres se
consideram morosos. Logo, o prazer se realiza no tempo.

3. Demais. ― As paixões da alma são do mesmo gênero. Ora, há certas que existem no tempo. Logo,
também o prazer.
Mas, em contrário, diz o Filósofo, que o prazer não se produz em nenhum determinado tempo.

SOLUÇÃO. ― De duplo modo pode uma coisa estar no tempo: em si e por outra coisa e quase por
acidente. Pois, sendo o tempo o número das posições sucessivas, diz-se que estão, em si, no tempo, as
coisas sujeitas por essência à sucessão ou ao que quer que à sucessão respeite, como o movimento, o
repouso, o falar e coisas semelhantes. Noutro sentido, diz-se que estão, não em si mesmas, no tempo,
as coisas cuja essência não implica nenhuma sucessão, mas que estão sujeitas a algo de sucessivo.
Assim, ser homem, por essência, não implica sucessão, pois não é movimento, mas termo do
movimento ou da mutação, ou da geração. Mas, enquanto sujeito a causas transmutáveis, ser homem
implica o tempo.
Por onde, o prazer, em si mesmo, independe do tempo, porque supõe o bem já alcançado, que é quase
o termo do movimento. ― Mas se esse bem alcançado estiver sujeito à transmutação, o prazer se
realizará, acidentalmente no tempo. Se porém for absolutamente intransmutável, o prazer não
decorrerá no tempo, nem essencial nem acidentalmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como diz Aristóteles, o movimento tem dupla acepção.
Numa, é o ato do que é imperfeito, isto é, existente em potência, como tal, e esse movimento é
sucessivo e temporal. Noutra, é o ato do que é perfeito, i. é, existente em ato, como inteligir, sentir,
querer e atos semelhantes, entre os quais também deleitar-se; e tal movimento não é sucessivo, nem
em si temporal.

RESPOSTA À SEGUNDA. ― Chama-se moroso ou diuturno o prazer acidentalmente temporal.

RESPOSTA À TERCEIRA. ― As outras paixões não tem por objeto, como o prazer, o bem já alcançado.
Por onde, tem, mais que ele, a natureza do movimento imperfeito. E por conseguinte, ao prazer
convém, mais que a elas, não estar no tempo.

## Art. 3 — Se a alegria é absolutamente o mesmo que o prazer.
(Infra, q. 35, a . 2; III Sent., dist. XXVI, q. 1, a . 3; dist. XXVII, q. 1, a . 2 ad 3; IV, dist. XLIX, q. 3, a . 1, qª 4; I
Cont. Gent., cap. XC; De Verit., q. 25, a . 4, ad 5).
O terceiro discute-se assim. ― Parece que a alegria é absolutamente o mesmo que o prazer.

1. ― Pois, as paixões da alma diferem pelos seus objetos. Ora, a alegria e o prazer tem o mesmo objeto,
a saber, o bem adquirido. Logo, a alegria é absolutamente o mesmo que o prazer.

2. Demais. ― Um mesmo movimento não pode terminar em dois termos. Ora, é o mesmo movimento
― a concupiscência ― que termina na alegria e no prazer. Logo, o prazer e a alegria são absolutamente
idênticos.

3. Demais. ― Se a alegria é diferente do prazer, pela mesma razão também hão-de sê-lo a ledice, a
exultação, a jucundidade e assim serão todas essas paixões diferentes. Ora, isto é falso. Logo, a alegria
não difere do prazer.
Mas, em contrário é que não atribuímos alegria aos animais, mas sim, prazer. Logo, não é o mesmo a
alegria que o prazer.

SOLUÇÃO. ― A alegria, como diz Avicena no seu livro De Anima, é uma espécie de prazer. Ora, devemos
considerar que, assim como certas concupiscências são naturais e certas não-naturais e conseqüentes à
razão, com já dissemos, assim também uns prazeres são naturais e outros, não-naturais e
acompanhados da razão; ou, como dizem Damasceno e Gregório Nisseno
(Nemésio), certos são corpóreos e certos, animais, o que vem a dar no mesmo. Pois, nós nos deleitamos
com o que, sendo naturalmente desejado, é adquirido; e com o que desejamos segundo a razão. Ora, o
nome de alegria não se aplica senão ao prazer conseqüente à razão. Por onde, não atribuímos a alegria
aos brutos, senão só o prazer. Por outro lado, tudo o que desejamos, segundo a natureza, também
podemos desejar com a deleitação da razão, mas não inversamente. Portanto, tudo o que causa prazer
pode também causar alegria, em se tratando de seres racionais, embora nem tudo possa causar a
alegria; assim, às vezes o que nos causa um prazer corpóreo não nos causa alegria, segundo a razão.
Donde se conclui que o prazer abraça domínio mais vasto que a alegria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Sendo o objeto do apetite animal o bem apreendido, as
diversidades da apreensão se prendem, de certo modo, às do objeto. E assim, os prazeres animais,
chamados também alegrias, distinguem-se dos corpóreos, chamados exclusivamente prazeres, como
também já se disse, a respeito das concupiscência.

RESPOSTA À SEGUNDA. ― Também entre as concupiscências há uma diferença semelhante a de que
trata a objeção; assim, o prazer corresponde à concupiscência e a alegria, ao desejo, que parece
pertencer sobretudo à concupiscência animal. E assim como as diferenças do movimentos, assim
também as do repouso.

RESPOSTA À TERCEIRA. ― As outras denominações pertinentes ao prazer são-lhe impostas em virtude
dos seus efeitos. Assim, a de ledice (laetitia) é imposta pelo alargamento do coração, como se
disséssemos que é uma dilatação (latitia); a de exultação provém dos sinais exteriores do prazer interior,
que se manifesta exteriormente enquanto a alegria interior prorrompe para o exterior; a
de jucundidade por fim provém de certos sinais ou efeitos especiais da alegria. E contudo, todas essas
denominações pertencem à alegria, pois não as aplicamos senão às naturezas racionais.

## Art. 4 — Se o prazer reside no apetite intelectivo.
(Infra, q. 35, a . 1; I Sent., dist. XLV, a . 1; IV, dist. XLIX, q. 3, a . 1, qª 1, 2).
O quarto discute-se assim. ― Parece que o prazer não reside no apetite intelectivo.

1. ― Pois, diz o Filósofo, que o prazer é um certo movimento sensível. Ora, movimento sensível não
existe na potência intelectiva. Logo, o prazer não reside também nesta potência.

2. Demais. ― O prazer é uma paixão. Ora, toda paixão é própria do apetite sensitivo. Logo, só há prazer
neste apetite.

3. Demais. ― O prazer nos é comum com os brutos. Logo, só reside na parte que também nos é comum
com eles.
Mas, em contrário, diz a Escritura (Sl 36, 4): Deleita-te no Senhor. Ora, o apetite sensitivo não pode
aplicar-se a Deus, senão só o intelectivo. Logo, pode haver prazer no apetite intelectivo.

SOLUÇÃO. ― Como já dissemos, há um certo prazer conseqüente à apreensão da razão. Ora, por esta
apreensão é movido não só o apetite sensitivo, aplicando-se a um objeto particular, mas também o
apetite intelectivo, chamado vontade. E então, no apetite intelectivo ou vontade há o prazer chamado
alegria, não porém, o prazer corpóreo.
Ora, os prazeres de um e outro apetites diferem em que os do apetite sensível são acompanhados de
certa transmutação corpórea; ao passo que os do apetite intelectivo não são mais que um movimento
simples da vontade. E neste sentido Agostinho diz, que a cobiça e a alegria não são mais do que a
vontade que consente nos objetos queridos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Na referida definição do Filósofo, sensível significa em
geral, qualquer apreensão. Pois, diz ele que o prazer é relativo a todos os sentidos, e semelhantemente
ao intelecto e à especulação. Ou podemos dizer que no passo aduzido o Filósofo define o prazer do
apetite sensitivo.

RESPOSTA À SEGUNDA. ― O prazer tem a natureza de paixão, propriamente falando, por ser
acompanhado de uma certa transmutação corpórea. E, neste sentido, não existe no apetite intelectivo,
mas existe, como simples movimento, assim também existe em Deus e nos anjos. Por onde, diz o
Filósofo que Deus se regozija por ato simples e uno. E Dionísio diz, que os anjos não são susceptíveis do
nosso prazer sensível, mas, se regozijam com Deus na alegria da incorrupção.

RESPOSTA À TERCEIRA. ― Nós temos não só a alegria, que nos é comum com os brutos, mas também, a
que nos é comum com os anjos. Por onde, no mesmo passo Dionísio diz, que os homens santos se
tornam muitas vezes participantes dos prazeres angélicos. E, assim há em nós não só o prazer do apetite
sensitivo, que nos é comum com os brutos, mas também o do apetite intelectivo, pelo qual
comunicamos com os anjos.

## Art. 5 — Se os prazeres corpóreos e sensíveis são maiores que os espirituais e intelectuais.
(IV Sent., dist. XLIX, q. 3, a . 5, qª 1; In Psalm., XVIII; I Ethic., lect. XIII; XII Metaph., lect. VIII).
O quinto discute-se assim. ― Parece que os prazeres corpóreos e sensíveis são maiores que os
espirituais e intelectuais.

1. ― Pois, todos procuramos algum prazer, segundo o Filósofo. Ora, o número dos que buscam os
prazeres sensíveis é maior do que o dos que procuram os prazeres espirituais da inteligência. Logo, os
prazeres corpóreos são mais intensos.

2. Demais. ― A grandeza da causa é conhecida pelo efeito. Ora, os prazeres corpóreos produzem efeitos
mais fortes; pois, como diz o Filósofo: transmutam o corpo e produzem a insânia em alguns. Logo, os
prazeres corpóreos são maiores.

3. Demais. ― É preciso temperar e refrear os prazeres corpóreos, por causa da veemência deles. Ora,
não é preciso refrear os prazeres espirituais. Logo, os primeiros são mais fortes.
Mas, em contrário, diz a Escritura (Sl 118, 103): Que doces são as tuas palavras ao meu paladar: mais
que o mel à minha boca! E o Filósofo diz: o prazer máximo é o que acompanha a atividade da sabedoria.

SOLUÇÃO. ― Como já dissemos, o prazer provém da união com o objeto conveniente, sentido ou
conhecido. Devemos notar porém que as operações da alma, principalmente as sensitivas e as
intelectivas, intransitivas à matéria exterior, são atos ou perfeições do agente, como inteligir, sentir,
querer e atos semelhantes; ao passo que os atos que recaem sobre a matéria exterior são, antes, atos e
perfeições da matéria transmutada, pois, o movimento é um ato que o móvel recebe do motor. Por
onde, as referidas ações da alma sensitiva e intelectiva são, de um lado, um certo bem do agente, e são
também conhecidas pelo sentido e pelo intelecto; donde vem que delas, e não somente dos seus
objetos, resulta o prazer.
Se porém compararmos os prazeres intelectuais com os sensíveis, enquanto que nos deleitamos com
esses atos mesmos, que são o conhecimento sensível e o intelectual, não há dúvida que os prazeres
intelectuais são muito maiores que os sensíveis. Pois nós nos deleitamos muito mais inteligindo que
sentindo um objeto, porque o intelecto, refletindo sobre o seu ato muito mais que o sentido sobre o
seu, conhece mais perfeitamente e mais do que o sentido. E por isso o conhecimento intelectual é
preferível, pois não há ninguém que não queira, antes, ser privado da visão corpórea do que da
intelectual, equiparando-se aos brutos e aos estultos, como diz Agostinho.
Mas em compararmos os prazeres intelectuais espirituais como os sensíveis corpóreos, então
absolutamente falando aqueles são maiores. E isto bem o demonstram os três elementos que requer o
prazer: um bem conexo, o ser ao que ele se une e a união mesma. ― Ora, o bem espiritual em si mesmo
é maior que o corpóreo e mais amado. E a prova está em que os homens se abstêm dos prazeres
corpóreos, mesmo dos maiores, para não perderem a honra, bem espiritual. ― Semelhantemente, a
parte intelectiva é em si mesma muito mais nobre e mais cognoscitiva que a parte sensitiva. ― E por
fim, a união do intelecto com o seu objeto é mais íntima, mais perfeita e mais consistente que a união
do sentido com o seu. ― Mais íntima, porque o sentido apreende os acidentes exteriores das coisas, ao
passo que o intelecto penetra-lhes até a essência, pois, o seu objeto é a qüididade. ― Mais perfeita,
porque à união do sensível com o sentido se acrescenta o movimento, que é um ato imperfeito; e por
isso, os prazeres sensíveis não são de totalidade simultânea, mas há neles algo de transeunte e algo cuja
consumação se espera, como bem o demonstram os prazeres da mesa e os venéreos. Os prazeres
espirituais porém não implicando o movimento, tem uma totalidade simultânea. ― Mais consistente,
porque os objetos dos prazeres corpóreos são corruptíveis e presto desaparecem, ao passo que os bens
espirituais são incorruptíveis.
Todavia, em relação a nós, os prazeres corpóreos são mais veementes, por três razões. ― Primeiro,
porque conhecemos as coisas sensíveis melhor que as espirituais. ― Segunda, porque os prazeres
sensíveis, sendo paixões do apetite sensitivo, implicam alguma transmutação corpórea, o que não se dá
com os prazeres espirituais, senão por alguma redundância do apetite superior no inferior. ― Terceira,
porque os prazeres corpóreos são desejados como remédios contra deficiências ou moléstias corpóreas,
que causam certas tristezas; e por isso tais prazeres, supervenientes a essas tristezas, são mais sentidos
e, por conseqüência mais aceitos que os espirituais, sem tristezas contrárias, como a seguir se dirá.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― É maior o número dos que buscam os prazeres
corpóreos porque são mais conhecidos, e é maior o número dos que o conhecem. E também porque os
homens precisamos desses prazeres como remédios contra toda sorte de dores e tristezas; e como a
maior parte dos homens não pode alcançar os prazeres espirituais, próprios dos virtuosos, é
conseqüente descambem para os corpóreos.

RESPOSTA À SEGUNDA. ― A transmutação corpórea é causada sobretudo pelos prazeres corpóreos,
enquanto são paixões do apetite sensitivo.

RESPOSTA À TERCEIRA. ― Os prazeres corpóreos pertencem à parte corpórea, regulada pela razão, e
por isso precisam ser temperados e regulados por esta; ao passo que os espirituais pertencem ao ânimo,
que é a regra mesma, e por isso são em si mesmos sóbrios e moderados.

## Art. 6 — Se os prazeres do tato são maiores que os dos outros sentidos.
(IIª.IIªº q. 141, a . 4; IV Sent., dist. XLIX, q. 3, a . 5, qª 2; De Malo, q. 14, a . 4, ad 1).
O sexto discute-se assim. ― Parece que os prazeres do tato não são maiores que os dos outros
sentidos.

1. ― Pois, é máximo o prazer sem o qual cessa toda alegria. Ora, tal é o prazer da vista, conforme o dito
da Escritura (Tb 5, 12): Que alegria poderei eu ter, eu que sempre estou em trevas e que não vejo a luz
do céu?Logo, o prazer da vista é o maior de todos os prazeres sensíveis.

2. Demais. ― Cada um acha prazer no que ama, diz Aristóteles. Ora, de todos os sentidos mais amamos
o da vista. Logo, o prazer da vista é máximo.

3. Demais. ― O princípio da amizade deleitável é por excelência a vista. Ora, a causa dessa amizade é o
prazer. Logo, o prazer da vista é máximo.
Mas, em contrário, diz o Filósofo, que os maiores prazeres são os do tato.

SOLUÇÃO. ― Como já dissemos, aquilo que é amado se torna deleitável. Ora, os sentidos, como diz
Aristóteles, são amados por dois motivos: por causa do conhecimento e da utilidade. Logo, de um e
outro modo pode existir o prazer sensível. Mas, como apreender o conhecimento mesmo, enquanto um
certo bem, é próprio do homem, próprios do homem são os prazeres dos sentidos da primeira espécie,
a saber, os dependentes do conhecimento: ao passo que os prazeres dos sentidos, enquanto amados
por utilidade, são comuns a todos os animais.
Se pois nos referimos ao prazer do sentido, em razão do conhecimento, é manifesto que o prazer da
vista é maior que o de qualquer outro sentido. ― Se porém a ele nos referimos, em razão da utilidade, o
maior prazer será o do tato; pois, a utilidade dos sensíveis está em se ordenarem à conservação da
natureza animal. Ora, para esta utilidade mais concorrem os sensíveis do tato, que conhece o
constitutivo do animal, a saber, o quente e o frio, o úmido e o seco e qualidades semelhantes. Por onde,
nesta acepção, os prazeres do tato são maiores, quase mais próximos do fim. E também por isto os
animais não susceptíveis do prazer dos sentidos, senão em razão da utilidade, não gozam dos prazeres
dos demais sentidos senão em ordem dos sensíveis do tato; assim, os cães não gozam com o cheiro das
lebres mas, com o comê-las; nem o leão goza com a voz do boi; mas, com o devorá-lo, como diz
Aristóteles.
Sendo pois o prazer do tato o máximo, em razão da utilidade, e o prazer da vista, em razão do
conhecimento, quem quiser compará-los verá que, absolutamente, o prazer do tato é maior que o da
vista, por se encerrar nos limites do prazer sensível. Pois como é manifesto, o natural, num ser, é o que
há de mais forte. Ora, a estes prazeres do tato é que se ordenam as concupiscências naturais, como as
da comida, as venéreas e semelhantes. ― Se porém considerarmos o prazer da vista enquanto ela serve
ao intelecto, então são mais fortes, pela mesma razão pela qual os prazeres intelectuais o são mais que
os sensíveis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A alegria, como já dissemos, significa um prazer animal e
pertence sobretudo à vista; ao passo que o prazer natural pertence sobretudo ao tato.

RESPOSTA À SEGUNDA. ― Amamos tanto a vista por causa do conhecimento, porque ela nos mostra as
muitas diferenças das coisas, como diz Aristóteles.

RESPOSTA À TERCEIRA. ― Não é do mesmo modo que o prazer e a vista são causas do amor carnal. Pois
o prazer e sobretudo o do tato, é causa final da amizade deleitável; ao passo que a vista é a causa da
qual procede o princípio do movimento, enquanto que, pela vista do objeto amável, se imprime e
espécie da coisa que atrai o amor e a concupiscência do prazer, que ela produz.

## Art. 7 — Se há algum prazer inatural.
O sétimo discute-se assim. ― Parece que nenhum prazer é inatural.

1. ― Pois, o prazer é, para os afetos da alma, o que o repouso é para os corpos. Ora, o apetite do corpo
natural não repousa senão no seu lugar conatural. Logo, nem pode haver repouso do apetite animal,
que é o prazer, senão em algo que lhe seja conatural. Logo, não há prazer inatural.

2. Demais. ― O contrário à natureza é violento. Ora, tudo o violento gera a tristeza, como diz
Aristóteles. Logo, nada do que encontra a natureza pode ser deleitável.

3. Demais. ― A causa do prazer, como é claro pela definição do Filósofo supra aduzida, está em nos
sentirmos numa disposição conforme à natureza. Ora, é natural a cada ser a disposição que lhe é
conforme à natureza, porque o movimento natural é o tendente para um termo natural. Logo, todo
prazer é natural.
Mas, em contrário, diz o Filósofo, que certos prazeres são dolorosos e contra a natureza.

SOLUÇÃO. ― Chama-se natural ao que é conforme à natureza, como diz Aristóteles. Ora, a natureza no
homem pode ser considerada à dupla luz. ― Primeiro, enquanto o intelecto e a razão constituem, por
excelência, a natureza humana, e esta é que o coloca numa determinada espécie. E a esta luz, podem-se
chamar prazeres naturais aos homens aqueles que lhes convêm de conformidade com a razão; assim, é
natural ao homem deleitar-se com a contemplação da verdade e com os atos virtuosos. ― Num
segundo ponto de vista, a natureza no homem é aquilo que confina com a razão, i. é, que lhe é comum
com os animais, e sobretudo que não obedece à razão. E a esta luz o que diz respeito à conservação do
corpo, individualmente, como, a comida, a bebida, o sono e coisas semelhantes; ou, especificamente,
como a atividade sexual, tudo isso é considerado como naturalmente deleitável ao homem.
Ora, conforme esses dois pontos de vista, podem certos prazeres serem inaturais, absolutamente, mas
conaturais, relativamente. Pois, pode suceder que, num determinado indivíduo, venha a corresponder-
se algum dos princípios naturais da espécie, e então, o que seria contrário à natureza da espécie, pode
acidentalmente ser natural a esse indivíduo; assim, é natural que a água quente aqueça. Por onde, pode
dar-se que aquilo que é contra a natureza do homem, relativamente à razão ou à conservação do corpo,
se torne conatural a um determinado homem por causa de alguma corrupção existente em a natureza
do mesmo. E esta corrupção pode provir do corpo ou da alma. Quanto ao corpo, de alguma doença ―
assim, os febricitantes acham amargo o doce e reciprocamente; ou da má compleição ― assim, há quem
se deleite comendo terra, carvão ou coisas semelhantes. Quanto à alma, quando alguém, por costume,
se deleita em comer carne humana; no coito bestial ou com indivíduos do mesmo sexo; ou em coisas
semelhantes, que não são conforme à natureza humana.
E daqui se deduzem AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 8 — Se um prazer pode ser contrário a outro.
O oitavo discute-se assim. ― Parece que um prazer não pode ser contrário a outro.

1. ― Pois, as paixões da alma se especificam e se opõem pelos seus objetos. Ora, o objeto do prazer é o
bem. E como não há bem contrário a outro bem, antes, o bem é contrário ao mal e o mal, ao bem, como
diz Aristóteles, conclui-se que nenhum prazer é contrário a outro.

2. Demais. ― Uma coisa só tem uma contrariedade, como o prova Aristóteles. Ora, ao prazer é contrária
a tristeza. Logo, um prazer não é contrário a outro.

3. Demais. ― Só pela contrariedade de objetos com que nos deleitamos pode um prazer contrariar a
outro. Ora, tal diferença é material, ao passo que a contrariedade em questão é uma diferença formal,
como diz Aristóteles. Logo, não há contrariedade entre um prazer e outro.
Mas, em contrário. ― Coisas do mesmo gênero e que se excluem, são contrárias, segundo o Filósofo.
Ora, certos prazeres excluem outros, como diz o mesmo autor. Logo, há prazeres contrários.

SOLUÇÃO. ― Como já dissemos, o prazer dos afetos da alma é comparável ao repouso dos corpos
naturais. Ora, dois corpos naturais repousam, de modo contrário, quando um repousa na parte superior
e outro, na inferior, como diz Aristóteles. Por onde, nos afetos da alma, dois prazeres podem ser
contrários.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A expressão citada do Filósofo, deve entender-se no
sentido que o bem e o mal se referem às virtudes e aos vícios; assim, dois vícios podem ser contrários,
mas não, duas virtudes. Nos demais casos porém nada impede dois bens se contrariem; assim, o
quente, bem do fogo, é contrário ao frio, bem da água. E deste modo, um prazer pode ser contrário a
outro. Mas nos bens da virtude isso não se pode dar, porque o bem da virtude é considerado por
conveniência com a regra una da razão.

REPOSTA À SEGUNDA. ― O prazer é para afetos da alma, o que o repouso natural é para os corpos, pois
respeita algo de conveniente e quase conatural. Assim, a tristeza é como um repouso violento, pois o
que contrista repugna ao apetite animal, como o lugar do repouso violento repugna ao apetite natural.
Ao repouso natural porém se opõem tanto o repouso violento do mesmo corpo como o de outro,
conforme Aristóteles. Por onde, a um prazer se opõem tanto outro prazer, como a tristeza.

RESPOSTA À TERCEIRA. ― Os objetos com que nos deleitamos, sendo objetos dos prazeres, produzem
não só a diferença material mas também a formal, se forem diversas as razões da complacência. Pois a
natureza diversa do objeto diversifica a espécie do ato ou da paixão, como do sobredito resulta.