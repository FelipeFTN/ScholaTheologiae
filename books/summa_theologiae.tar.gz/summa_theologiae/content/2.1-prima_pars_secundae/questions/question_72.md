# Questão 72: Da distinção entre os pecados
Em seguida devemos tratar da distinção entre os pecados ou vícios. E sobre esta questão discutem-se
nove artigos:

## Art. 1 — Se os pecados diferem especificamente pelos seus objetos.
(Infra a. 3, 8; De Malo, q. 2, a. 6; q. 14, a. 3)
O primeiro discute-se assim. ― Parece que os pecados não diferem especificamente pelos seus
objetos.

1. ― Pois, os atos humanos consideram-se precipuamente bons ou maus, em relação ao fim, conforme
já se demonstrou (q. 18, a. 6). Ora, como o pecado não é mais do que o ato humano mau, conforme já
se disse (q. 71, a. 1), resulta o deverem os pecados se distinguir, especificamente, antes pelos fins que
pelos objetos.

2. Demais. ― O mal, sendo privação, distingue-se especificamente pelas diversas espécies dos
contrários. Ora, o pecado é um certo mal, no gênero dos atos humanos. Logo, os pecados distinguem-se
especificamente antes pelos contrários do que pelos objetos.

3. Demais. ― Se os pecados diferissem especificamente pelos seus objetos, seria impossível o mesmo
pecado, especificamente, recair sobre diversos objetos. Ora, tal se dá com certos deles. Assim, a
soberba tem como objeto tanto o espiritual como o corporal, segundo Gregório; e a avareza também
incide sobre vários gêneros de objetos. Logo, especificamente, os pecados não se distinguem pelos seus
objetos.
Mas, em contrário, pecado é o dito, feito ou desejado contra a lei de Deus. Ora, o dito, feito ou desejado
distingue-se, especificamente, pelos objetos diversos, pois, pelos objetos é que se distinguem os atos,
como já se disse (q. 18, a. 5). Logo, também os pecados se distinguem especificamente pelos seus
objetos.

SOLUÇÃO. ― Como já dissemos (q. 71, a. 6), dois elementos concorrem na essência do pecado: o ato
voluntário e a sua desordem, pelo afastamento da lei de Deus. Ora, destes dois elementos, um é relativo
ao pecador, que intenciona praticar tal ato voluntário, em tal determinada matéria; o outro, i. é, a
desordem do ato, refere-se, acidentalmente, à intenção do pecador, pois, como diz Dionísio, ninguém
pratica o mal intencionalmente. Ora, é manifesto que cada ser se especifica pelo essencial, e não pelo
acidental, porque este é estranho à essência da espécie. Por onde, os pecados se distinguem,
especificamente, mais pelos atos voluntários do que pela desordem existente no pecado. Ora, os atos
voluntários distinguem-se, especificamente, pelos seus objetos, como já demonstramos antes (q. 18, a.
5). Donde se segue que os pecados, própria e especificamente, se distinguem pelos seus objetos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O fim, principalmente, tem a essência de bem, e por isso
se refere como objeto ao ato da vontade, que é primordial em todo pecado. Por onde, vem a dar no
mesmo que os pecados se diferenciem pelos seus objetos ou pelos seus fins.

RESPOSTA À SEGUNDA. ― O pecado não é pura privação, mas, sim, um ato privado da ordem devida. E
por isso os pecados especificamente se distinguem, antes, pelos objetos dos atos do que pelos
contrários. Contudo viria a dar no mesmo se se distinguissem pelas virtudes opostas, pois as virtudes se
distinguem, especificamente pelos seus objetos, como já estabelecemos antes (q. 60, a. 5).

RESPOSTA À TERCEIRA. ― Nada impede, em diversas coisas, específica ou genericamente diferentes,
haver uma razão formal do objeto por onde o pecado se especifica. E deste modo a soberba busca a
excelência relativamente a coisas diversas; ao passo que a avareza busca a abundância do que é
destinado ao uso humano.

## Art. 2 — Se convenientemente se distinguem os pecados espirituais, dos carnais.
(IIa-IIae, q. 118 a. 6; 1 Cor cap. VI, lect. III; II VII, lect. I; Ad Galat., cap. V, lect. V)
O segundo discute-se assim. ― Parece que inconvenientemente se distinguem os pecados espirituais,
dos carnais.

1. ― Pois, diz o Apóstolo (Gl 5, 19): Mas as obras da carne estão patentes, como são a fornicação, a
impureza, a desonestidade, a luxúria, a idolatria, os empeçonhamentos etc. por onde se vê que todos os
gêneros de pecado são obras da carne. Ora, assim se chamam os pecados carnais. Logo, não se devem
distinguir tais pecados, dos espirituais.

2. Demais. ― Quem peca procede segundo a carne, conforme aquilo da Escritura (Rm 8, 13): Porque se
viverdes segundo a carne, morrereis; mas se vós pelo espírito fazendo morrer as obras da carne,
vivereis.Ora, viver ou proceder segundo a carne é a essência mesma do pecado carnal. Logo, todos os
pecados são carnais, não havendo lugar para os espirituais.

3. Demais. ― A parte superior da alma, que é a mente ou razão, chama-se espírito, conforme aquilo da
Escritura (Ef 4, 23): Renovai-vos pois no espírito de vosso
entendimento ―onde espírito significa razão, como diz a Glosa a esse lugar. Ora, todo pecado carnal
supõe o consentimento da razão, pois pertence à razão superior consentir no ato pecaminoso, como a
seguir se dirá (q. 74, a. 7). Logo, pecados carnais e espirituais são o mesmo; e portanto, não se devem
distinguir uns dos outros.

4. Demais. ― Se alguns pecados são especialmente carnais, isto se deve entender principalmente
daqueles pelos quais pecamos contra o nosso corpo. Ora, como diz o Apóstolo (1 Cor 6, 18), todo o
outro pecado qualquer que o homem cometer é fora do corpo; mas o que comete fornicação peca
contra o seu próprio corpo. Logo, só a fornicação seria pecado carnal; e contudo, o Apóstolo (Ef 5, 3)
também enumera a avareza entre os pecados carnais.
Mas, em contrário, diz Gregório: dos sete vícios capitais, cinco são espirituais e dois, carnais.

SOLUÇÃO. ― Como já dissemos (a. 1), os pecados se especificam pelos seus objetos. Ora, todo pecado
consiste no desejo de algum bem variável, desejado desordenadamente; e por conseqüência, quando já
o possuímos, nos deleitamos desordenadamente. Ora, como resulta claro do que já dissemos, há uma
dupla deleitação. Uma, é a da alma que se consuma na só apreensão da coisa possuída segundo os
nossos desejos, e pode também chamar-se deleitação espiritual; tal é o caso de nos deleitarmos com o
louvor humano ou coisa semelhante. A outra é a deleitação corpórea ou natural, que se consuma pelo
contato corpóreo e que também pode chamar-se carnal. Por onde, os pecados que se consumam na
deleitação espiritual se chamam espirituais; ao contrário, os que se consumam na deleitação carnal se
chamam carnais, como a gula, consumada nos prazeres da mesa e a luxúria, nos venéreos. Por isso diz o
Apóstolo (2 Cor 7, 1): purifiquemo-nos de toda a imundície da carne e do espírito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como diz a Glosa ao lugar citado, esses vícios se
chamam obras da carne, não por se consumarem no prazer da carne; mas esta palavra é aí tomada no
sentido de homem, do qual dizemos que, vivendo segundo as suas tendências, vive segundo a carne; e o
mesmo diz Agostinho. E a razão disto é que toda deficiência da razão humana tem o seu início, de certo
modo, no sentido carnal.
E daqui também se deduz clara a resposta à segunda objeção.

RESPOSTA À TERCEIRA. ― Mesmo nos pecados carnais há algum ato espiritual, que é o da razão; mas o
fim desses pecados, donde tiram a denominação, é o deleite da carne.

RESPOSTA À QUARTA. ― Como diz a Glosa no lugar citado, especialmente no pecado da fornicação a
alma se sujeita ao corpo; pois, no momento mesmo dele, não podemos pensar em nenhuma outra
coisa. Ao passo que o prazer da gula, embora carnal, não absorve a razão do mesmo modo. Ou podemos
dizer, que por esse pecado fazemos também certa injúria ao corpo, desordenadamente maculado. E por
isso se diz que só por tal pecado o homem peca especialmente contra o seu corpo. ― A avareza, por seu
lado, enumerada entre os pecados carnais, é tomada pelo adultério, que é a posse injusta da mulher
alheia. Ou podemos dizer que por as coisas com que se deleita o avarento serem algo de corporal, é ela
enumerada entre os pecados carnais. Mas o prazer mesmo dela não está na carne, mas no espírito; e
por isso, segundo Gregório, é pecado espiritual.

## Art. 3 — Se os pecados se distinguem especificamente pelas suas causas.
O terceiro discute-se assim. ― Parece que os pecados se distinguem especificamente pelas suas
causas.

1. ― Pois, as coisas se especificam pelo mesmo princípio donde tiram o ser. Ora, este os pecados o
recebem das suas causas. Logo, também por elas se especificam; e portanto, diferem especificamente
pela diversidade das causas.

2. Demais. ― Entre todas as causas, a material é a menos atinente à espécie. Ora, o objeto é como a
causa material do pecado. Se portanto os pecados se especificam pelos seus objetos, resulta, que se
especificam muito mais pelas outras causas.

3. Demais. ― Agostinho, comentando aquilo do salmo ― Ela foi queimada a fogo e escavada ―diz,
que todo pecado provém do temor mau que humilha ou do amor que inflama para o mal. Pois, como diz
a Escritura (1 Jo 2, 16), tudo o que há no mundo ou é concupiscência da carne, ou é concupiscência dos
olhos, ou, soberba da vida. E quando se diz que alguma coisa existe no mundo por causa do
pecado, entendem-se, pela palavra mundo, os amantes dele, como interpreta Agostinho. Por seu lado,
Gregório também distingue todos os pecados segundo os sete vícios capitais. Ora, todas estas divisões
visam as causas dos pecados. Logo, conclui-se que eles diferem especificamente segundo a diversidade
das causas.
Mas, em contrário, se assim fosse, todos os pecados seriam da mesma espécie, como procedentes da
mesma causa, conforme diz a Escritura (Ecle 10, 15): o princípio de todo pecado é a soberba; e (1 Tm): e
raiz de todos os males é a avareza. Ora, como é manifesto, há diversas espécies de pecados. Logo, não
se distinguem especificamente pelas diversidades das causas.

SOLUÇÃO. ― Sendo quatro os gêneros de causas, elas se atribuem diversamente a coisas diversas.
Assim, a causa formal e a material visam propriamente a substância da coisa; e portanto, pela forma e
pela matéria, as substâncias se distinguem específica e genericamente. Por outro lado, o agente e o fim
visam diretamente o movimento e a operação; e portanto, os movimentos e as operações se distinguem
especificamente por essas causas. Mas, de maneira diversa. ― Pois, os princípios ativos naturais são
determinados sempre aos mesmos atos. Por onde, as diversas espécies dos atos naturais se fundam,
não só nos objetos, que são os fins ou termos, mas também nos princípios ativos; assim, aquecer e
esfriar distinguem-se especificamente pelo calor e pelo frio. ― Os princípios ativos, dos atos voluntários,
porém e tais são os dos pecados, não se realizam necessariamente em relação a um só termo. E
portanto, de um mesmo princípio ativo ou motivo podem provir diversas espécies de pecados. Assim, o
mau temor que humilha pode nos levar ao roubo, ao assassinato ou ao abandono da grei que nos foi
cometida; e tudo isto também pode provir do amor. Por onde, é manifesto que os pecados não diferem
especificamente pelas diversas causas ativas ou motivas, mas só pela diversidade da causa final. Ora, o
fim é o objeto da vontade; pois, como já demonstramos (q. 1, a. 3; q. 18, a. 6), os atos humanos se
especificam pelo seu fim.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O princípio ativo dos atos voluntários, não sendo estes
determinados a um só termo, não basta a produzir os atos humanos, se a vontade não for determinada
a um objeto pela intenção do fim, como claramente o diz o Filósofo. Logo, o fim dá a plenitude ao ser e
a espécie ao pecado.

RESPOSTA À SEGUNDA. ― Os objetos, comparados aos atos exteriores, exercem a função de matéria
sobre o qual versam. Mas comparados ao ato interior da vontade, exercem a função de fins, e por isso
especificam o ato. Embora também, enquanto são matéria sobre que eles recaem, exercem o papel de
termos, que especificam os movimentos, como diz Aristóteles. Contudo também os termos do
movimento o especificam, enquanto exercem a função de fim.

RESPOSTA À TERCEIRA. ― As divisões dos pecados referidas não foram feitas para distinguir as espécies
deles, mas para lhes manifestar as causas diversas.

## Art. 4 — Se convenientemente os pecados se distinguem em pecados contra Deus, o próximo e nós mesmos.
(II Sent., dist. XLII, q. 2, a. 2, qa 2; in Psalm, XXV)
O quarto distingue-se assim. ― Parece que inconvenientemente os pecados se distinguem em
pecados contra Deus, o próximo e nós mesmos.

1. ― Pois, o comum a todo pecado não deve ser considerado como parte na divisão do mesmo. Ora, é
comum a todos eles serem contra a lei de Deus; pois lhes entra na definição a contrariedade a essa
lei, como já dissemos (q. 71 a. 6). Logo, o pecado contra Deus não deve ser considerado como parte, na
divisão dos pecados.

2. Demais. ― Toda divisão deve ser feita baseada nas oposições. Ora, os três gêneros de pecados, em
questão, não são opostos; pois, quem peca contra o próximo peca contra si mesmo e contra Deus. Logo,
não é apropriada a tríplice divisão de pecados.

3. Demais. ― O que é extrínseco não especifica. Ora, Deus e o próximo são-nos exteriores. Logo, por um
e outro não se nos especificam os pecados. Logo, é inconveniente a divisão deles fundada nesses três
elementos.
Mas, em contrário, Isidoro, distinguindo os pecados, escreve: dizemos que o homem peca contra si
mesmo, contra Deus e contra o próximo.

SOLUÇÃO. ― Como já dissemos (q. 71, a. 1), o pecado é um ato desordenado. Ora, o homem está
submetido a uma tríplice ordem. ― uma, dependente da regra da razão, pela qual devem medir-se
todas as nossas ações e paixões. ― Outra, dependente da regra da lei divina, pela qual devemos nos
dirigir em tudo. ― Ora, se o homem fosse um animal solitário, naturalmente, essa dupla ordem bastaria.
Mas, como é naturalmente um animal político e social, segundo o prova Aristóteles, é necessária uma
terceira ordem, que o ordene relativamente aos outros homens, com quem deve conviver.
Ora, das duas ordens sobreditas, a primeira abrange a segunda e a excede, porque tudo quanto se
contém na ordem da razão contido também está na lei de Deus. Mas a ordem de Deus contém certas
coisas excedentes à razão humana, e tais são as coisas da fé e aquilo que só a Deus é devido. Por onde,
dizemos que peca contra Deus quem peca contra tais coisas, como o herético, o sacrílego, o blasfemo.
Semelhantemente, a segunda ordem inclui a terceira e a excede. Pois, em tudo quanto nos ordenamos
ao próximo é necessário nos dirigirmos pela regra da razão. Mas há certas coisas em que nos dirigimos
pela razão, só relativamente a nós e não, ao próximo. E quando pecamos contra elas, se diz que
pecamos contra nós mesmos, como é o caso do guloso, do luxurioso e do pródigo. Quando por fim
pecamos contra aquilo pelo que nos ordenamos ao próximo, se diz que pecamos contra ele, como
claramente o mostra o ladrão e o homicida.
Mas, há ainda diversas coisas por que o homem se ordena para Deus, para o próximo e para si mesmo.
Por onde, esta distinção dos pecados se funda nos objetos, que diversificam as espécies de pecados; e
portanto, ela propriamente se funda nas diversas espécies de pecados. Porque também as virtudes que
lhes são opostas se distinguem especificamente por essa diferença. Pois, como é manifesto pelo já dito,
pelas virtudes teologais o homem ordena-se para Deus; pela temperança e pela fortaleza, ordena-se
para si mesmo; e pela justiça, para o próximo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Pecar contra Deus, enquanto a ordem relativa a ele
inclui toda a ordem humana, é comum a todo pecado. Mas, na medida em que a ordem de Deus excede
as outras duas, o pecado contra Deus é um gênero especial de pecado.

RESPOSTA À SEGUNDA. ― Quando duas coisas, das quais uma excede a outra, se distinguem entre si,
entende-se que a distinção entre elas se faz não por onde uma inclui, senão, por onde excede a outra.
Como bem o patenteia a divisão dos números e das figuras; assim, o triângulo não se divide por
oposição com o quadrado, como se nele estivesse contido, mas enquanto por ele excedido. E o mesmo
se deve dizer dos números ternário e quaternário.

RESPOSTA À TERCEIRA. ― Deus e o próximo, embora exteriores em relação ao pecador, não o são
contudo em relação ao ato do pecado; mas estão para este como para seus objetos próprios.

## Art. 5 — Se a divisão dos pecados, fundada no reato em venial e mortal, lhes diversifica a espécie.
O quinto discute-se assim. ― Parece que a divisão dos pecados, fundada no reato, em venial e mortal,
lhes diversifica a espécie.

1. ― Pois, coisas que diferem ao infinito não podem ser da mesma espécie, nem ainda do mesmo
gênero. Ora, o pecado venial difere infinitamente do mortal; pois, àquele é devida uma pena temporal
e, a este, eterna. Ora, a medida da pena corresponde à gravidade da culpa, conforme àquilo da Escritura
(Dt 25, 2): O número dos golpes regular-se-á pela qualidade do pecado. Logo, pecado venial e mortal
não são do mesmo gênero e, muito menos, da mesma espécie.

2. Demais. ― Certos pecados são genericamente mortais, como o homicídio e o adultério; outros, como
a palavra ociosa e o riso vão, veniais. Logo, o pecado venial e mortal diferem especificamente.

3. Demais. ― O ato virtuoso está para o prêmio, como o pecado, para a pena. Ora, o prêmio é o fim do
ato virtuoso. Logo, a pena o é do pecado. E como os pecados se especificam pelos seus fins, conforme já
dissemos (a. 3), também se especificam pelo reato da pena.
Mas, em contrário. ― O constitutivo da espécie, como as diferenças específicas, tem prioridade de
existência. Ora, a pena segue-se à culpa, como seu efeito. Logo, os pecados não diferem
especificamente pelo reato da pena.SOLUÇÃO. ― É dupla a diferença entre coisas especificamente
diferentes. ― Uma é a diversidade específica, e esta só se encontra nas espécies diversas; tais as de
racional e irracional, animado e inanimado. ― A outra é conseqüente à diversidade específica. E esta
embora umas vezes seja conseqüente à diversidade específica, pode contudo, outras, existir na mesma
espécie. Assim, embora o branco e o preto sejam conseqüentes à diversidade específica entre o corvo e
o cisne, essa diferença se encontra contudo na mesma espécie humana.
Por onde, devemos concluir que a diferença entre pecado venial e mortal, ou qualquer outra fundada no
reato, não pode ser constitutiva da diversidade específica. Pois, nunca o acidental constitui espécie. Ora,
o que está fora da intenção do agente é acidental, como o demonstra Aristóteles. E como é manifesto
que a pena está fora da intenção do pecador, ela tem, por parte deste, relação acidental com o pecado.
Mas a este se ordena exteriormente, i. é, pela justiça do juiz, que, conforma às diversas condições dos
pecados, inflige penas diversas. Por onde, a diferença fundada no reato da pena pode ser conseqüente à
espécie diversa dos pecados, sem lhes constituir a diversidade específica.
Por outro lado, a diferença entre pecado venial e mortal resulta da diversidade da desordem, que
constitui plenamente a essência do pecado. Ora, há uma dupla desordem: uma, exclui o princípio da
ordem; a outra, salvo esse princípio, diz respeito ao que lhe é posterior. Assim, no corpo do animal, às
vezes a desordem na compleição vai até a destruição do princípio vital, e então causa a morte; outras
vezes porém, salvo o princípio da vida, só há desordem nos humores, que provoca a doença. Ora, o
princípio de toda a ordem moral é o fim último que exerce, nos atos, o mesmo papel que o princípio
indemonstrável, na ordem especulativa, como diz Aristóteles. Por onde, há pecado mortal quando a
alma por ele se desordena, até a aversão do fim último, que é Deus, a quem está unida pela caridade;
mas, só há pecado venial, quando a desordem não chega à aversão de Deus. Mas assim como a
desordem da morte corpórea, que exclui o princípio da vida, é naturalmente irreparável, ao passo que é
reparável a desordem da doença, que não destrói o princípio vital, o mesmo se dá no atinente à alma.
Pois, na ordem especulativa, quem erra nos princípios é impersuasível; mas quem erra, sem os perder a
eles, pode ser corrigido por eles próprios. E o mesmo se dá, na ordem prática, com quem pelo pecado se
desvia do fim último: pela natureza do pecado, o lapso é irreparável, donde a conclusão, que quem peca
mortalmente deve ser punido eternamente. Quem, ao contrário, peca sem se afastar de Deus comete
uma desordem reparável, pela própria natureza do pecado, que não destruiu o princípio; e por isso
dizemos que peca venialmente, por não pecar de modo a merecer uma pena interminável.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O pecado mortal difere infinitamente do venial, quanto
à aversão; mas, não, quanto à conversão, pela qual visam o objeto, que especifica o pecado. Por onde,
nada impede seja um pecado mortal e um venial incluídos na mesma espécie; assim, a primeira
tendência, no gênero do adultério, é um pecado venial; mas, a palavra ociosa, quase sempre venial,
pode vir a ser mortal.

RESPOSTA À SEGUNDA. ― De ser um pecado genericamente mortal, e outro venial, resulta que essa
diferença é conseqüente à diversidade específica dos pecados, e não que a causa. E tal diferença pode
existir ainda nos pecados da mesma espécie, como já se disse.

RESPOSTA À TERCEIRA. ― O prêmio está na intenção de quem merece ou age virtuosamente; ao passo
que na intenção do pecado não está a pena, contrária, antes, à sua vontade. Logo, o símile não colhe.

## Art. 6 — Se os pecados de comissão e omissão diferem especificamente.
O sexto discute-se assim. ― Parece que os pecados de comissão e omissão diferem especificamente.

1. ― Pois, o delito se divide por oposição com o pecado, conforme a Escritura (Ef 2, 1): quando vós
estáveis mortos pelos vossos delitos e pecados. E a Glosa a esse lugar expõe: os delitos consistem em
omitir o devido; e os pecados, em fazer o proibido. Por onde é claro, que por delito se entende o pecado
de omissão; e por pecado, o de comissão. Logo, diferem especificamente, pois, dividem-se por oposição,
como de espécies diversas.

2. Demais. ― É da essência do pecado ser contra a lei de Deus, pois, essa noção se lhe inclui na
definição, como do sobredito se colhe (q. 71, a. 6). Ora, a lei de Deus inclui certos preceitos afirmativos,
contrariados pelo pecado de omissão; e outros, negativos, aos quais se opõe o de comissão. Logo, um e
outro diferem especificamente.

3. Demais. ― A omissão difere da comissão como a afirmação, da negação. Ora, estas duas últimas não
podem ser da mesma espécie; porque, o não ser, não tendo espécies nem diferenças, como diz o
Filósofo, a negação também não tem espécie. Logo, omissão e comissão não podem ser da mesma
espécie.
Mas, em contrário. ―Omissão e comissão entram na mesma espécie. Assim, o avarento, pelo pecado de
comissão, rouba o alheio; e pelo de omissão não dá o seu a quem o deve dar. Logo, omissão e comissão
não diferem especificamente.

SOLUÇÃO. ― Há nos pecados dupla diferença: material, uma e, outra, formal. ― Aquela se funda na
espécie natural dos atos pecaminosos. ― Esta, na ordem a um fim próprio, que é o objeto próprio. Por
isso há certos atos de espécie materialmente diferentes, que contudo ordenando-se ao mesmo fim,
pertencem, formalmente, à mesma espécie de pecado. Assim, à mesma espécie de homicídio pertence
o degolamento, a lapidação e a varação, embora, pela espécie natural, esses atos sejam especificamente
diferentes.
Por onde, se considerarmos materialmente as espécies de pecados de comissão e omissão, eles diferem
em espécie; mas isso tomando a espécie em sentido lato, i. é, no sentido em que dizemos possa a
negação ou privação ter espécie. ― Se porém considerarmos a espécie dos pecados de omissão e de
comissão, formalmente, então não diferem de espécie, por se ordenarem ao mesmo fim e procederem
do mesmo motivo. Assim, o avarento, para amontoar dinheiro, ao mesmo tempo rouba e não dá aquilo
que deve dar; semelhantemente, o guloso, para satisfazer a gula, come demais e omite o jejum devido;
e o mesmo se dá, em outros casos. Ora, sempre, na realidade, a negação se funda em alguma afirmação,
que é, de certo modo, a causa dela. Por isso, também na ordem natural, pela mesma razão que o fogo
aquece, não esfria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A divisão consistente na comissão e omissão não se
funda nas diversas espécies formais, senão só materiais, como já dissemos.

RESPOSTA À SEGUNDA. ― A lei de Deus teve necessidade de estabelecer diversos preceitos afirmativos
e negativos para os homens começarem gradativamente a prática da virtude. Primeiro, abstendo-nos do
mal, abstenção a que nos levam os preceitos negativos; e depois, fazendo o bem, prática a que nos
induzem os preceitos afirmativos. E assim, uns e outros preceitos não dizem respeito a virtudes diversas,
mas a diversos graus dela. E por conseqüência, não contrariam, necessariamente, a pecados
especificamente diversos. ― O pecado também não se especifica pela aversão, pela qual é uma negação
ou privação; mas pela conversão, pela qual é um certo ato. Por onde, os pecados não se diversificam
especificamente pelos diversos preceitos da lei.

RESPOSTA À TERCEIRA. ― A objeção procede da diversidade material da espécie. Pois, devemos saber
que a negação, embora propriamente não se inclua em nenhuma espécie, nesta se constitui, entretanto,
pela redução a alguma afirmação à qual é conseqüente.

## Art. 7 — Se o pecado se divide acertadamente em pecado por pensamentos, palavras e obras.
O sétimo discute-se assim. ― Parece que o pecado não se divide acertadamente em pecado por
pensamentos, palavras e obras.

1. ― Pois, Agostinho estabelece três graus de pecado. O primeiro, quando o sentido carnal é atraído por
alguma sedução, e é o pecado de pensamento; o segundo, quando nos contentamos com o só deleite
do pensamento; o terceiro, quando o consentimento estatui o que devemos fazer. Ora, estes três graus
respeitam o pecado de pensamento. Logo, não é acertado considerá-lo como um gênero de pecado.

2. Demais. ― Gregório distingue quatro graus do pecado. O primeiro é a culpa latente no coração; o
segundo, a sua manifestação externa; o terceiro, quando é corroborada pelo costume; o quarto, quando
chegamos até a presunção da divina misericórdia, ou ao desespero. Ora, nestes quatro graus não se
distingue o pecado por obras do por palavras e acrescentam-se dois outros graus. Logo, a primeira
divisão não é acertada.

3. Demais. ― Não pode haver pecado por palavras ou obras, antes de haver o de intenção. Logo, tais
pecados não diferem especificamente, e portanto não se devem dividir uns por oposição aos outros.
Mas, em contrário, diz Jerônimo: São três os delitos gerais a que está sujeito o gênero humano, pois
pecamos por pensamento, palavras ou obras.

SOLUÇÃO. ― Dois seres podem diferir especificamente de dois modos. Ou por constituírem ambos uma
espécie completa, e assim o cavalo e o boi diferem especificamente. Ou porque, numa geração ou
movimento, consideram-se espécies diversas, em graus diversos. Assim, a edificação é a produção
completa da casa; ao passo que a colocação dos fundamentos e a ereção das paredes são espécies
incompletas, como claramente se vê no Filósofo. E o mesmo se pode dizer da geração dos animais.
Assim, pois essa tríplice divisão dos pecados por pensamentos, palavras e obras, ― não constitui
espécies completas diversas; porquanto, sendo a obra a consumação do pecado, o pecado por obra é o
que encerra a espécie completa. Mas, a primeira incoação dele é-lhe como a base, no pensamento; o
seu segundo grau é constituído pela palavra, enquanto prorrompemos facilmente na manifestação do
conceito pensado; o terceiro grau, por fim, está na consumação da obra. Por onde, esses três pecados
diferem segundo graus diversos. É porém claro que pertencem a uma mesma espécie perfeita de
pecado, como procedentes do mesmo motivo. Assim, o iracundo, ardendo pela vindita, turba-se-lhe
primeiro o pensamento; depois, prorrompe em palavras contumeliosas; e, em terceiro lugar, chega aos
fatos injuriosos. E o mesmo se dá com a luxúria e com qualquer outro pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Todo pecado de pensamento é por essência oculto. E
por isto, considera-se um só grau, distinto, contudo, em três outros, a saber: o pensamento, o prazer e o
consentimento.

RESPOSTA À SEGUNDA. ― Os pecados por palavra e por obra convêm na manifestação, e por isso
Gregório os compreende no mesmo grau. Jerônimo porém os distingue, porque no pecado por palavras
só a manifestação é a principalmente intencionada; ao passo que o pecado por obra, o é principalmente
o complemento do conceito interior da mente, sendo a manifestação uma conseqüência. Quanto ao
costume e ao desespero, são graus conseqüentes à espécie perfeita do pecado, assim como a
adolescência e a juventude, ao desenvolvimento perfeito do homem.

RESPOSTA À TERCEIRA. ― Os pecados por pensamento e por palavras não se distinguem do pecado por
obras, quando coexistentes com este; mas entre si se distinguem quando existentes isoladamente.
Assim como uma parte do movimento não se distingue da sua totalidade, quando o movimento é
contínuo, mas só quando pára no meio.

## Art. 8 — Se a superabundância e o defeito diversificam as espécies de pecados.
O oitavo discute-se assim. ― Parece que a superabundância e o defeito não diversificam as espécies
de pecados.

1. ― Pois, superabundância e defeito diferem como o mais, do menos. Ora, o mais e o menos não
diversificam a espécie. Logo, a superabundância e o defeito não diversificam a espécie dos pecados.

2. Demais. ― Como pelo pecado os nossos atos se desviam da razão reta, assim pela falsidade se desvia
da verdade real a nossa especulação. Ora, não se diversificam as espécies de falsidade por dizermos que
uma realidade é mais ou menos tal. Logo, também não diversifica as espécies de pecados o nos
desviarmos mais ou menos da razão reta.

3. Demais. ― Duas espécies não constituem uma só, como diz Porfírio. Ora, a superabundância e o
defeito podem incluir-se num mesmo pecado. Assim, certos são simultaneamente iliberais e pródigos;
ora, a iliberalidade peca por defeito, e por superabundância, a prodigalidade. Logo, superabundância e
defeito não diversificam as espécies de pecados.
Mas, em contrário. ―Os contrários diferem especificamente; pois, a contrariedade é uma diferença
formal,como diz Aristóteles. Ora, os vícios que diferem por superabundância e defeito, como a
iliberalidade e a prodigalidade, são contrários. Logo, diferem especificamente.

SOLUÇÃO. ― O pecado, incluindo dois elementos ― o ato e a desordem pela qual se desvia da ordem
da razão e da lei divina, a sua espécie depende, não da desordem, que está fora da intenção do pecador,
como já dissemos (a. 1), mas, do ato mesmo, enquanto termina num objeto visado pela intenção do
pecador. Por onde, sempre que ocorram motivos diversos, inclinando a intenção ao pecado, haverá
espécies diversas deles. Ora, é manifesto que os pecados por superabundância e os por defeito não têm
os mesmos motivos, que são, antes, contrários. Assim, o motivo do pecado de intemperança é o amor
dos prazeres corpóreos, ao passo que o da insensibilidade é o ódio deles. Por onde, tais pecados, não só
diferem especificamente, mas também são contrários entre si.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O mais e o menos, embora não sejam causas da
diversidade específica, são, contudo às vezes, enquanto provenientes de formas diversas,
especificamente diferentes, como quando dizemos, que o fogo é mais leve que o ar. Por onde, segundo
o Filósofo, os que dizem não serem diversas as espécies de amizades, só por se lhes considerarem o
mais e o menos, não se apóiam num argumento bastante firme. E deste modo, sobreexceder à razão e
ser deficiente em relação a ela, implicam diversas espécies de pecados, por serem conseqüentes a
motivos diversos.

RESPOSTA À SEGUNDA. ― A intenção do pecador não é desviar-se da razão; e por isso os pecados por
superabundância e por defeito não são da mesma natureza por se afastarem da mesma retidão racional.
Mas às vezes, quem diz uma falsidade entende ocultar a verdade, então pouco importa que a diga mais
ou menos. Ora, se desviar-se da verdade está fora da intenção, é manifesto que causas diversas nos
movem a dizê-la mais ou menos. E assim, a falsidade tem razões diversas; e tal é o caso do jactancioso
que, com o fito na glória, exagera a falsidade; e o do fraudulento, que a diminui para fugir ao pagamento
do devido. Por onde, há certas opiniões falsas contrárias entre si.

RESPOSTA À TERCEIRA. ― Podemos ser pródigo e iliberal a luzes diversas; assim, no segundo caso,
quando recebemos o que não nos é devido; no primeiro, quando damos o que não devemos. Ora, nada
impede a coexistência dos contrários num mesmo ser, a luzes diversas.

## Art. 9 — Se os vícios e os pecados se diversificam especificamente segundo as circunstâncias diversas.
O nono discute-se assim. ― Parece que os vícios e os pecados se diversificam especificamente
segundo as circunstâncias diversas.

1. ― Pois, como diz Dionísio, o mal resulta de defeitos particulares. Ora, estes supõem alterações de
circunstâncias particulares. Logo, da alteração destas resultam as espécies particulares de pecados.

2. Demais. ― Os pecados são determinados atos humanos. Ora, estes às vezes se especificam pelas
circunstâncias, como já se estabeleceu (q. 18, a. 19). Logo, diferem especificamente conforme à
alteração das diversas circunstâncias.

3. Demais. ― As diversas espécies de gula estão assinaladas pelas palavras contidas nestes
advérbios muito precipitadamente, suntuosamente, demasiadamente, ardentemente,
esforçadamente. Ora, tudo isto diz respeito a circunstâncias diversas; pois, mui
precipitadamente significa antes do tempo oportuno;demasiadamente, mais do que é necessário; e
assim por diante. Logo, as espécies de pecado se diversificam pelas diversas circunstâncias.
Mas, em contrário, diz o Filósofo, que cada vício peca por nos fazer agir mais do que é necessário e
quando não é tempo oportuno; dando-se o mesmo com todas as demais circunstâncias. Logo, por aí não
se diversificam as espécies de pecados.

SOLUÇÃO. ― Como já dissemos (a. 8), sempre que há um motivo diferente para pecar há nova espécie
de pecado, porque o motivo que leva a pecar é o fim e o objeto. ― Ora, dá-se às vezes, que as
alterações das diversas circunstâncias têm um mesmo motivo. Assim, o iliberal, pelo mesmo motivo,
recebe quando e onde não deve, e mais do que deve, e assim por diante em relação às demais
circunstâncias; e isto o faz por causa do desejo desordenado de amontoar dinheiro. Ora, em tais casos,
as alterações das diversas circunstâncias não diversificam as espécies de pecados, mas pertencem a uma
e mesma espécie deles. ― Outras vezes porém acontece que as alterações das diversas circunstâncias
provêm de motivos diversos. Assim, o comermos mui precipitadamente pode provir de não podermos
sofrer a dilação do alimento, por causa da fácil consumição da umidade. O desejarmos comer
imoderadamente pode provir da virtude da natureza, forte para diferir muito alimento. O desejarmos
comida deliciosa provém do desejo dos prazeres da mesa. Por onde, em tais casos, as alterações das
diversas circunstâncias causam as diversas espécies de pecados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O mal, como tal, é uma privação; e portanto, como as
outras privações, diversifica especificamente, pelo que priva. Ora, o pecado não tira a sua espécie da
privação ou da aversão, como já dissemos (a. 1), mas, da conversão para o objeto do ato.

RESPOSTA À SEGUNDA. ― A circunstância nunca muda a espécie do ato, senão quando o motivo é
outro.

RESPOSTA À TERCEIRA. ― As diversas espécies de gula têm motivos diversos, como já dissemos.