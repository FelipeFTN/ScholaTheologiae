# Questão 84: Da causa do pecado, enquanto é um causa de outro.
Em seguida devemos tratar da causa do pecado, enquanto é um causa de outro. E, nesta questão
discutem-se quatro artigos:

## Art. 1 — Se a cobiça é a raiz de todos os pecados.
(Art. seq.; IIª-IIae, q 119, a.2. ad 1; II Sent., dist., V, q. q. 1. a. 3, ad 1; dist. XXII, q. 1, a. 1, ad 7; dist. XLII, q.
2, a. 1 ; a. 3, ad 1; De Malo, q. 8, a. 1, ad 1; I ad Tim., cap. VI, lect. II).
O primeiro discute-se assim. — Parece que a cobiça não é a raiz de todos os pecados.

1. — Pois, a cobiça, que é o desejo imoderado das riquezas, opõe-se à virtude da liberalidade. Ora, esta
não é a raiz de todas as virtudes. Logo, a cobiça não o é de todos os vícios.

2. Demais. — O desejo dos meios procede do desejo do fim. Ora, as riquezas são desejadas pela cobiça
só por serem úteis a algum, como diz Aristóteles. Logo, a cobiça não é a raiz de todos os pecados, mas se
radica numa origem anterior.

3. Demais. — A avareza, considerada como cobiça, nasce freqüentemente de outros pecados; assim,
quando se deseja o dinheiro por causa da ambição, ou para satisfazer à gula. Logo, não é a raiz de todos
os pecados.
Mas, em contrário, diz o Apóstolo (1 Tm 6, 10): a raiz de todos os males é a avareza.

SOLUÇÃO. — Certos tomam a cobiça em tríplice acepção. Primeiro, como o desejo desordenado das
riquezas, sendo então, um pecado especial. Segundo, como implicando o desejo desordenado de
qualquer bem temporal e, então constitui o gênero de todos os pecados, pois, todos implicam a
tendência desordenada para os bens transitórios, como já se disse (q. 72, a. 2). Terceiro, como
significando uma certa inclinação da natureza corrupta para desejar desordenadamente bens
corruptíveis. E, então se diz que a cobiça é a raiz de todos os pecados, por semelhança com a raiz da
árvore, que tira da terra o alimento. Do mesmo modo, todos os pecados nascem do amor das coisas
temporais.
Ora, não obstante verdadeiras, essas distinções parecem não se incluírem na intenção do Apóstolo, que
considerou a cobiça como a raiz de todos os pecados. Pois, ele se dirige manifestamente contra aqueles
que,querendo fazer-se ricos, caem na tentação e no laço do diabo, porque a raiz de todos os males é a
avareza. Por onde é manifesto que se refere à cobiça como desejo desordenado das riquezas. E, a esta
luz, devemos ter que a cobiça, como pecado especial, é considerada raiz de todos os pecados, por
semelhança com a raiz da árvore, a toda a qual dá o alimento. Pois, segundo vemos por meio das
riquezas o homem adquire a faculdade de cometer qualquer pecado e de satisfazer o desejo de
qualquer deles. Porque o dinheiro o ajuda a possuir quaisquer bens temporais, conforme aquilo da
Escritura (Ecle 10, 19): todas as coisas obedecem o dinheiro. Por onde é claro que a cobiça das riquezas
é a raiz de todos os pecados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A virtude e o pecado não têm a mesma origem. Pois,
este nasce do desejo dos bens mutáveis; e por isso se considera como raiz de todos os pecados o desejo
daqueles bens temporais que ajudam a conseguir todos os outros. Ao passo que a virtude nasce do
desejo do bem imutável e, por isso, a caridade, que é o amor de Deus, é considerada a raiz das virtudes,
conforme aquilo da Escritura (Ef 3, 17): arraigados e fundados na caridade.

RESPOSTA À SEGUNDA. — Considera-se o desejo das riquezas como raiz dos pecados, não, certo, por
serem elas buscadas por si mesmas, como fim último; mas por serem muito procuradas como úteis para
todos os fins temporais. E sendo o bem universal mais desejável que qualquer bem particular, ele move
mais o apetite, do que quaisquer bens particulares, que, simultaneamente com muitos outros, podem
ser possuídos por meio do dinheiro.

RESPOSTA À TERCEIRA. — A ordem natural não implica na realização inevitável dos fatos, senão o que
se dá na maior parte das vezes, porque a natureza das coisas corruptíveis pode ser impedida de agir
sempre do mesmo modo. Assim também, na ordem moral, consideramos o que é mais freqüente, e não
o que se deva realizar sempre, porque a vontade não obra necessariamente. Por onde, o considerar-se a
avareza raiz de todos os males não significa que, às vezes, algum outro mal não seja a sua raiz, mas que,
no mais das vezes, dela nascem os outros, pela razão já exposta.

## Art. 2 — Se a soberba é o início de todos os pecados.
(IIª-IIªª, q. 162, a. 2; a. 5, ad 2 II Sent., dist. V, q. 1, a. 3; dist. XLII, q. 2, a. 1, ad 7; a. 3, ad 1 ; De Malo, q. 8,
a. 1, ad 1, 16; II Cor., cap. XII. lect. III; I Tim., cap. VI, lect. II).
O segundo discute-se assim. — Parece que a soberba não é o início de todo pecado.

1. — Pois, a raiz é um princípio da árvore; e, assim, parece que o mesmo é ser raiz e início do pecado.
Ora, a cobiça é a raiz de todo pecado, como já se disse (a. 1). Logo, ela também, e não a soberba, é o
início de todo pecado.

2. Demais. — A Escritura diz (Sr 10, 14): O princípio da soberba do homem é apostatar de Deus. Ora, a
apostasia de Deus é um pecado. Logo, há um pecado que é o início da soberba; e esta não é o início de
todo pecado.

3. Demais. — É início de todos os pecados o que os causa a todos. Ora, tal é o amor desordenado de si,
que gera a cidade de Babilônia, como diz Agostinho. Logo, é o amor de si, e não a soberba, o início de
todo o pecado.
Mas, em contrário, diz a Escritura (Sr 10, 15): o princípio de todo o pecado é a soberba.

SOLUÇÃO. — Certos consideram a soberba em tríplice acepção. Numa, significa o desejo desordenado
da própria excelência, e então a têm como pecado especial. Noutra, importa um certo desprezo atual de
Deus, quanto ao seu efeito, que consiste em não nos sujeitarmos à lei divina; e então a consideram
como um pecado geral. Noutra enfim, implica uma inclinação para esse referido desprezo, pela corrup-
ção da natureza; e então a consideram como o início de todos os pecados. E difere da cobiça, que
implica o pecado por prender-se aos bens mutáveis, o que, de certo modo, nutre e favorece o pecado; e
por isso é considerada como raiz dele. Ao passo que a soberba implica o pecado por afastar de Deus, a
cujo preceito o homem recusa submeter-se; e é chamada início do pecado, porque esse afastamento é o
início do mal.
Ora, se bem essas distinções sejam verdadeiras, não entram na intenção do Sábio, quando disse: o
princípio de todo o pecado é a soberba. Pois manifestamente, ele se refere à soberba como desejo
desordenado da própria excelência, como bem o esclarece o que acrescenta: Deus destruiu os tronos
dos príncipes soberbos. E trata desse assunto em quase todo esse capítulo. Donde devemos concluir,
que a soberba, mesmo enquanto pecado especial, é o início de todo o pecado. Pois, é mister considerar
que, nos atos voluntários, como o são os pecados, há uma dupla ordem: a da intenção e a da
execução.Na primeira o fim exerce a função de princípio, como já muitas vezes dissemos. Ora, o fim de
,
todos os bens temporais, que podemos adquirir, é levar-nos a uma certa perfeição e excelência. E
portanto, por aqui, a soberba, que é o desejo da excelência, é considerada como o início de todo
pecado. Por outro lado, quanto à execução, vem em primeiro lugar o que dá a oportunidade de realizar
todos os desejos pecaminosos; e tais são as riquezas, que por isso exercem a função de raiz. Por isso, a
avareza é considerada como a raiz de todos os males, como já se disse (a. 1).
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Por causa do afastamento, é que se considera o apostatar de Deus como
início da soberba. Pois, de não querer o homem sujeitar-se a Deus resulta o querer desordenadamente a
própria excelência, na ordem temporal. E assim, a apostasia de Deus não é considerada, no lugar em
questão, como um pecado especial; mas antes, como uma condição geral de todo pecado, que é o
afastamento do bem imutável. — Ou se pode dizer que o apostatar de Deus é considerado o início da
soberba, por ser a primeira espécie dela. Pois, é próprio da soberba não querer submeter-se a nenhum
superior e, principalmente, não querer submeter-se a Deus. Donde resulta que o homem se exalta
indebitamente acima de si mesmo, quanto às outras espécies de soberba.

RESPOSTA À TERCEIRA. — O homem se ama a si mesmo querendo a sua excelência; pois, o amar-se a si
é querer para si o bem. Por onde, vem a dar no mesmo considerar como o início de todo o pecado a
soberba ou o amor próprio.

## Art. 3 — Se além da soberba e da avareza, há outros pecados especiais chamados capitais.
(II Sent., dist. XLII, q. 2, a. 3; De Malo, q. 8, a. 1).
O terceiro discute-se assim. — Parece que além da soberba e da avareza não há outros pecados
especiais chamados capitais.

1. — Pois, a cabeça está para os animais, como a raiz, para as plantas, conforme diz Aristóteles; porque
as raízes se assemelham à boca. Se portanto a cobiça é considerada raiz de todos os males, só ela, e
nenhum outro pecado, deve ser tida como vício capital.

2. Demais. — A cabeça está numa certa ordem relativa aos outros membros, enquanto dela derivam, de
algum modo, para todos eles, o sentido e o movimento. Ora, o pecado assim se chama por implicar
privação da ordem. Logo, não exerce função capital; e portanto, não se devem admitir nenhuns pecados
capitais.

3. Demais. — Chamam-se capitais os crimes expiados com pena capital. Ora, certos pecados, em cada
gênero deles, são punidos com essa pena. Logo, os vícios capitais não são vícios especificamente
determinados.
Mas, em contrário, Gregório enumera certos vícios especiais a que chama capitais.

SOLUÇÃO. — Capital vem de cabeça. Ora, esta propriamente é o membro principal e diretivo de todo o
animal. Por isso, chama-se metaforicamente, cabeça a tudo o que é princípio e diretivo; e também os
homens, que dirigem e governam, são chamados cabeças. Por onde, de um modo, a denominação de
vício capital vem de cabeça, em sentido próprio. E nesta acepção chama-se pecado capital o punido com
a pena capital. Mas não é neste sentido que tratamos agora dos pecados capitais, mas consideramos
aqui o pecado capital como derivado de cabeça, em outra acepção, a saber, a metafórica, significando
que ele é o princípio ou o diretivo dos outros pecados. E assim chama-se vício capital aquele donde os
outros nascem, e principalmente quanto à origem da causa final que é a origem formal como já se disse
(q. 72, a. 6). Por onde, o vício capital não só é o princípio dos outros, mas também os dirige e de certo
modo os chefia. Pois sempre a arte ou o hábito, a que pertence o fim, tem o principado e o império
sobre os meios. Por isso Gregório compara esses vícios capitais com os chefes dos exércitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A denominação de capital vem de cabeça. E implica uma
certa derivação ou participação da cabeça, como tendo alguma propriedade desta e não como sendo a
cabeça, em sentido literal. Por isso chamam-se capitais não só os vícios que desempenham a função de
origem primeira, como a avareza, denominada raiz, e a soberba, denominada início; mas também os
que desempenham a função de origem próxima de vários pecados.

RESPOSTA À SEGUNDA. — O pecado carece de ordem pelo afastamento que causa, pois, por aí é um
mal; e naverdade, segundo Agostinho, o mal é a privação do modo, da espécie e da ordem. Quanto ao
que busca, contudo, o pecado implica um certo bem e, por este lado é susceptível de ordem.

RESPOSTA À TERCEIRA. — A objeção colhe quanto ao pecado capital, enquanto assim chamado por
causa do reato da pena. Ora, não é neste sentido que agora dele tratamos.

## Art. 4 — Se devemos admitir sete vícios capitais, a saber: a vanglória, a inveja, a ira, a avareza, a tristeza, a gula e a luxúria.
(II Sent., dist. XLII, q. 2, a. 3; De Malo, q. 8, a. 1).
O quarto discute-se assim. — Parece não devamos admitir sete vícios capitais, a saber, a vanglória, a
inveja, a ira, a avareza, a tristeza, a gula e a luxúria.

1. — Pois, os pecados se opõem às virtudes. Ora, destas são quatro as principais, como já se disse (q. 61,
a. 2). Logo, também só quatro hão de ser os vícios principais ou capitais.

2. Demais. — As paixões da alma estão entre as causas do pecado, como já se disse (q. 77). Ora, as
principais paixões da alma são quatro, e duas delas — a esperança e o temor — não se mencionam
entre os referidos pecados. Enumeram-se porém certos vícios que supõem o prazer e a tristeza. Pois,
aquele está incluído na gula e na luxúria; e esta, na preguiça e na inveja. Logo, os pecados principais são
inconvenientemente enumerados.

3. Demais. — A ira não é uma paixão principal. Logo, não devia ser colocada entre os vícios principais.

4. Demais. — Assim como a cobiça ou avareza é a raiz do pecado, assim a soberba é dele o início, como
já se disse (q. 84, a. 2). Ora, a avareza é considerada como um dos sete vícios capitais. Logo, a soberba
também devia ser enumerada entre esses vícios.

5. Demais. — Cometemos certos pecados, que não podem ser causados por nenhum dos vícios capitais.
Assim, quando erramos por ignorância ou quando alguém comete um pecado, como roubar, para dar
esmola, mas com boa intenção. Logo, os vícios capitais são enumerados insuficientemente.
Mas, em contrário, é a autoridade de Gregório, que assim os enumera.

SOLUÇÃO. — Como já se disse (q. 84, a. 3), chamam-se vícios capitais aqueles de que se originam os
outros, principalmente em relação à idéia de causa final. Ora, esta origem pode ser considerada à dupla
luz. — Primeiro, segundo a condição do pecador, disposto de maneira tal a buscar sobretudo um fim,
donde vem a praticar, no mais das vezes, outros pecados. Ora, tal origem não a pode compreender a
arte, por serem infinitas as disposições particulares dos homens. — Segundo, quanto à relação natural
dos próprios fins entre si. E a esta luz um vício nasce quase sempre de outro. E por isso, a arte pode
abranger esse modo de se originar. Então chamam-se capitais os vícios, cujos fins implicam certas razões
primárias de mover o apetite; e conforme a distinção delas assim eles se distinguem.
Ora, um objeto pode mover o apetite de dois modos. — Diretamente e por si; assim, o bem o move a
buscá-lo e o mal, pela mesma razão, a evitá-lo. — Ou indireta e como mediatamente; assim quando
buscamos um mal em vista de algum bem concomitante; ou evitamos um bem por causa de algum mal
adjunto.
Ora, tríplice é o bem do homem. — O primeiro é o da alma, cuja razão de apetibilidade depende da só
apreensão, e tal é a excelência do louvor ou da honra. E esse bem é buscado desordenadamente pela
vanglória. — Outro é o bem do corpo. E este diz respeito ou à conservação do indivíduo, como a comida
e a bebida, e é buscado desordenadamente pela gula; ou respeita a conservação da espécie, como o
coito, ao qual se ordena a luxúria. — O terceiro bem é exterior e são as riquezas, às quais se ordena a
avareza. — E esses mesmos quatro vícios fogem desordenadamente os quatro males contrários.
Ou de outro modo, o bem principalmente move o apetite, por participar de certa maneira da natureza
da felicidade, que todos naturalmente desejam. — Ora, em primeiro lugar a felicidade implica por
essência uma certa perfeição; pois é o bem perfeito, a que diz respeito a excelência ou esplendor,
desejado pela soberba ou vanglória. Em segundo lugar, implica essencialmente a suficiência, que as
riquezas prometem e é desejada pela avareza. — Em terceiro lugar, é condição da felicidade o prazer,
sem o qual não pode ela existir, como diz Aristóteles, e é desejado pela gula e pela luxúria.
Por outro lado, há três razões pelas quais evitamos um bem por causa de algum mau conjunto. — Pois,
assim agimos quanto ao nosso bem próprio, pela preguiça, que repugna ao trabalho corpóreo, exigido
para obtermos bem espiritual. — Ou quanto ao bem alheio. E isto, sendo sem excitação, é próprio da
inveja, que se entristece com o bem de outrem por ser obstáculo à nossa própria excelência. —
Havendo excitação, que provoca a vingança, tem lugar a ira. E aos mesmos vícios é próprio a
prossecução do mal oposto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os vícios e as virtudes não têm a mesma origem. Pois,
estas são causadas por ordenar-se o apetite à razão ou ao bem imutável, que é Deus; ao passo que
aqueles nascem do desejo dos bens mutáveis. Por onde, os vícios principais não hão de
necessariamente se opor às virtudes principais.

RESPOSTA À SEGUNDA. — O temor e a esperança são paixões do irascível. Ora, todas as paixões do
irascível nascem das do concupiscível, todas as quais se ordenam também, de certo modo, ao prazer e à
dor. Por isso, o prazer e a dor principalmente se enumeram entre os pecados capitais, como as
principalíssimas das paixões, segundo já se estabeleceu (q. 25, a. 4).

RESPOSTA À TERCEIRA. — A ira, embora não seja uma paixão principal, distingue-se contudo dos outros
vícios capitais, por desempenhar papel especial na atividade apetitiva; pois, atacamos o bem de outrem
levados pela idéia do homem, i. e, da justiça vindicativa.

RESPOSTA À QUARTA. — A soberba é considerada como o início de todo pecadolevando-se em conta a
idéia de fim, como já se disse (q. 84, a. 2). E nessa mesma idéia se funda o serem principais os vícios
capitais. Por onde, a soberba não entra na enumeração, por ser um quase vício universal; mas antes, é
considerada a rainha de todos os vícios, no dizer de Gregório. E é por outra razão que se considera a
avareza como a raiz, conforme já se disse (q. 84, a. 1; a. 2).

RESPOSTA À QUINTA. — Os vícios capitais assim se chamam por nascerem deles, mui freqüentemente,
os outros. Mas isso não impede tenham por vezes certos pecados, outras causas. — Também é possível
dizer que todos os pecados provenientes da ignorância podem se reduzir à preguiça a que é próprio a
negligência, causa de recusarmos adquirir os bens espirituais, por via do trabalho. Pois, a ignorância, que
pode ser causa do pecado, provém da negligência, como já dissemos (q. 76, a. 2). E o cometermos um
pecado com boa intenção supõe a ignorância de que se não deve praticar o mal para conseguir bem.