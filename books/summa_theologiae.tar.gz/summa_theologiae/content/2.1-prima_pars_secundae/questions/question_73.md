# Questão 73: Da relação dos pecados entre si.
Em seguida devemos tratar da relação dos pecados entre si. E neste ponto, discutem-se dez artigos:

## Art. 1 — Se todos os pecados são conexos.
(III Sent., dist. XXVI, a. 5; IV dist. XVI, q. 2, a. 1, qa. 2)
O primeiro discute-se assim. — Parece que todos os pecados são conexos.

1. ― Pois, diz a Escritura (Tg 2, 10): qualquer que tiver guardado toda a lei, e faltar em um só ponto, faz-
se réu de ter violado a todos. Ora, ser réu de todos os mandamentos da lei é o mesmo que ter todos os
pecados. Porque, como diz Ambrósio, o pecado é a prevaricação contra a lei divina e a desobediência
aos mandamentos celestes. Logo, quem comete um pecado comete todos.

2. Demais. ― Todo pecado exclui a virtude oposta. Ora, quem carece de uma virtude carece de todas,
como já se disse (q. 65, a. 1). Logo, quem comete um pecado fica privado de todas as virtudes. E como
quem carece de uma virtude tem o vício oposto, quem comete um pecado comete todos.

3. Demais. ― Todas as virtudes que convêm num mesmo princípio são conexas, como já se estabeleceu
(q. 65, a. 1, 2). Ora, como as virtudes, também os pecados convêm num mesmo princípio; porque assim
como o amor divino, causa da cidade de Deus, é o princípio e a raiz de todos as virtudes; assim o amor
próprio, causa da cidade de Babilônia, é a raiz de todos os pecados, como se vê claro em Agostinho.
Logo, também todos os vícios e pecados são conexos, de modo tal que, quem tem um tem todos.
Mas, em contrário. ―Certos vícios são contrários entre si, como claramente se vê no Filósofo. Ora, é
impossível os contrários coexistirem no mesmo sujeito. Logo, é impossível todos os pecados e vícios
serem conexos entre si.

SOLUÇÃO. ― A intenção do agente de, na prática da virtude, seguir a razão, difere da intenção do
pecador no afastar-se da mesma. Pois, a intenção de qualquer agente, na prática da virtude, é seguir a
regra da razão; e portanto, a intenção, em todas as virtudes, recai sobre o mesmo objeto. E por isto,
todas são conexas entre si, no seguir a razão reta dos atos, que é a prudência, como já dissemos (q. 65,
a. 1). Ao passo que a intenção do pecador não é afastar-se do racional, mas antes, tender para algum
bem desejável, que lhe especifica o ato. Ora, tais bens, a que tende a intenção do pecador, afastando-se
da razão, são diversos, sem nenhuma conexão entre si; antes, são contrários às vezes. Ora, como os
vícios e os pecados se especificam pelos seus objetos, é manifesto que nenhuma conexão têm os
pecados entre si, quanto ao que lhes dá a espécie completa. Pois, não cometemos pecados, achegando-
nos, da multidão, à unidade, como se dá com as virtudes, que são conexas, mas, ao contrário, deixando
a unidade, pela multidão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Tiago se refere ao pecado, não quanto à sua conversão,
pela qual se distinguem, como já dissemos (q. 62, a. 1), mas quanto à aversão, pela qual, pecando,
afastamo-nos dos mandamentos da lei. Ora, todos estes procedem de uma mesma fonte, como ele o diz
no mesmo lugar (Tg 2, 11); e portanto, o mesmo Deus é o desprezado em todos os pecados. E por isso,
diz, que quem faltar em um só ponto, faz-se réu de ter violado a todos. Porque, cometendo um pecado,
incorremos no reato da pena, por desprezarmos a Deus, de cujo desprezo provém o reato de todos os
pecados.

RESPOSTA À SEGUNDA. ― Como já dissemos (q. 71, a. 4), qualquer ato pecaminoso não nos priva da
virtude oposta. Assim, dela não nos priva o pecado venial; por seu lado, o pecado mortal nos priva da
verdade infusa, por nos afastar de Deus; mas, um só ato pecaminoso, ainda mortal, não nos tira o hábito
da virtude adquirida. Mas se os atos se multiplicarem a ponto de gerarem um hábito contrário, fica
excluído o hábito da virtude adquirida; e excluída esta, fica também excluída a prudência. Porque,
agindo contra qualquer virtude, agimos contra a prudência, sem a qual não pode existir nenhuma
virtude moral, como já estabelecemos (q. 58, a. 4; q. 65, a. 1). E por conseqüência, ficam excluídas todas
as virtudes morais, no atinente ao que há de perfeito e formal na virtude; e isso elas o têm na medida
em que pARTicipam da prudência; permanecem contudo as inclinações para os atos virtuosos, que não
implicam a essência da virtude. Mas daqui não se segue o incorrermos em todos os vícios ou pecados.
Primeiro, porque a uma mesma virtude se opõem vários vícios; de modo que a virtude pode ser excluída
por um deles, sem que os outros existam. Segundo, porque o pecado se opõe diretamente à virtude,
quanto à inclinação desta para o ato, como já dissemos (q. 71, a. 1). Por onde, enquanto permanecerem
algumas inclinações virtuosas, não podemos nos considerar como tendo os vícios ou pecados opostos.

RESPOSTA À TERCEIRA. ― O amor de Deus é unitivo, porque reduz à unidade os múltiplos afetos
humanos. Portanto, as virtudes causadas por esse amor têm entre si conexão. O amor próprio, pelo
contrário, dispersa-nos os afetos para diversos objetos; pois, amando-nos a nós mesmos, desejamo-nos
bens temporais, vários e diversos. E portanto, os vícios e os pecados causados pelo amor próprio, não
são conexos.

## Art. 2 — Se todos os pecados são iguais.
(II Sent., dist. XLII, q. 2, a. 5; III Cont. Gent., cap. CXXXIX; De Malo, q. 2, a. 9)
O segundo discute-se assim. ― Parece que todos os pecados são iguais.1. ― Pois, pecar é fazer o
ilícito. Ora, agir assim é geralmente repreensível em todos e do mesmo modo. Logo também, do mesmo
modo, é repreensível o pecar, e portanto, um pecado não é mais grave que outro.

2. Demais. ― Todo pecado consiste em transgredirmos a regra da razão, e esta é para os atos humanos
o que é a regra lineal para as causas corpóreas. Logo, pecar é o mesmo que transpor as linhas. Ora, nós
as transpomos igualmente e do mesmo modo, quer fiquemos mais longe, quer mais perto delas, pois as
privações não são suscetíveis de mais e de menos. Logo, todos os pecados são iguais.

3. Demais. ― Os pecados se opõem às virtudes. Ora, estas são todas iguais, no dizer de Túlio. Logo,
todos os pecados são iguais.
Mas, em contrário, o Senhor diz a Pilatos (Jo 19, 11): o que me entregou a ti tem maior pecado; e
contudo, é certo que também Pilatos, agindo como agiu, pecou. Logo, um pecado é maior que outro.

SOLUÇÃO. ― A opinião dos estóicos, que Túlio segue nos Paradoxos, era que todos os pecados são
iguais. Donde também derivou o erro de certos heréticos que, considerando iguais todos os pecados,
consideraram também iguais todas as penas do inferno. E quanto se pode depreender das palavras de
Túlio, os estóicos eram movidos por considerarem o pecado só no atinente à privação, i. é, enquanto
implica afastamento da razão. Por onde, considerando simplesmente que nenhuma privação é
suscetível de mais e de menos, afirmava a igualdade de todos os pecados.
Mas quem nisto pensar atentamente descobrirá duplo gênero de privação. ― Uma o é pura e
simplesmente e consiste na quase corrupção do ser; assim, a morte é a privação da vida e a treva, a da
luz. E tais privações não são suscetíveis de mais e de menos, porque nelas nada resta do hábito oposto.
E por isso, quem morreu não está menos morto depois do primeiro, do terceiro, do quARTo dia, de um
ano, do que depois da decomposição do cadáver. Semelhantemente, uma casa, cuja lâmpada foi
coberta de vários véus, não é menos escura do que se fosse coberta por um só, que lhe interceptasse
toda a luz.
Há porém outra privação que não é simples, mas conserva algo do hábito oposto; e essa mais consiste
em corromper-se o ser do que no estar já corrupto. Assim, a doença priva do devido equilíbrio dos
humores, mas não totalmente, pois do contrário, o animal não continuaria vivo; e o mesmo se dá com a
turpitude e coisas semelhantes. Ora, essas privações são suscetíveis de mais e de menos, no que se
refere ao remanescente do hábito contrário. Pois importa muito, para a doença ou a turpitude, o
afastar-se mais ou menos do devido equilíbrio dos humores e dos membros. ― E o mesmo devemos
dizer dos vícios e dos pecados. Assim, há neles privação do devido equilíbrio racional, sem desaparecer
contudo totalmente a ordem da razão; do contrário, o mal, sendo total, destruir-se-ia a si mesmo, como
diz Aristóteles. Pois, não pode permanecer a substância do ato ou o afeto do agente, sem permanecer
algo da ordem da razão. E portanto, importa muito, para a gravidade do pecado, o desviar-se, mais ou
menos, da razão reta. E sendo assim, devemos concluir que nem todos os pecados são iguais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Não é lícito cometer o pecado, por causa da desordem
que ele implica, qualquer que ela seja. Por onde, os que implicam maior desordem são mais ilícitos e,
por conseqüência, mais graves.

RESPOSTA À SEGUNDA. ― A objeção colheria se o pecado fosse privação pura.

RESPOSTA À TERCEIRA. ― As virtudes são iguais, proporcionalmente, num mesmo sujeito. Contudo,
uma virtude precede especificamente outra, em dignidade; e também, na mesma espécie de virtude,
um homem pode ser mais virtuoso que outro, como já dissemos (q. 66, a. 1, 2). Porém as virtudes sendo
iguais, daí não se concluiria a igualdade dos vícios; por terem elas conexão entre si e, os vícios ou
pecados, não.

## Art. 3 — Se a gravidade dos pecados varia com os objetos deles.
O terceiro discute-se assim. ― Parece que a gravidade dos pecados não varia com os seus objetos.

1. ― Pois, ela depende do modo ou qualidade do pecado. Ora, o objeto é a matéria do mesmo. Logo, a
gravidade deste não varia conforme os seus diversos objetos.

2. Demais. ― A gravidade do pecado está na intensidade da sua malícia. Ora, esta ele não o tira da
conversão para o seu objeto próprio, que é algum bem desejável, mas, antes, do afastamento desse
objeto. Logo, a gravidade do pecado não varia conforme os seus diversos objetos.

3. Demais. ― Pecados com objetos diversos são de gêneros diversos. Ora, coisas de diversos gêneros
não são suscetíveis de comparação entre si, como o prova Aristóteles. Logo, um pecado não é mais
grave que outro pela diversidade dos objetos.
Mas, em contrário. ― Os pecados se especificam pelos seus objetos, como do sobredito resulta (q. 62, a.
1). Ora, uns são especificamente mais graves que outros; assim, o homicídio, do que o furto. Logo, a
gravidade deles varia com os seus objetos.

SOLUÇÃO. ― Como do sobredito (a. 5) claramente resulta, a gravidade dos pecados difere do mesmo
modo por que uma doença é mais grave que outra. Pois, assim como o bem da saúde consiste num
certo equilíbrio dos humores, por conveniência com a natureza do animal; assim o bem da virtude está
num certo equilíbrio dos atos humanos, por conveniência com a regra da razão. Ora, é manifesto que
uma doença é tanto mais grave, quanto mais se afasta desse devido equilíbrio dos humores,
comensurado pelo princípio primeiro. Assim, a doença do coração, ou de qualquer outro órgão que
tenha quase tanta importância como ele, é mais perigosa, por ser o coração o princípio da vida. Por
onde e necessariamente, tanto mais grave será o pecado quanto mais a sua desordem ferir algum
princípio primeiro, na ordem da razão.
Ora, a razão ordena-nos todos os atos em dependência do fim. E portanto, quanto mais elevado for o
fim de que se desvia um ato humano pecaminoso, tanto mais grave será o pecado. Ora, os objetos dos
atos são os seus fins, como do sobredito claramente se colhe (q. 72, a. 3 ad 2). Logo, da diversidade dos
objetos depende a diversa gravidade do pecado. Mas, ao passo que, claramente, as coisas exteriores se
ordenam para o homem como para o fim, este se ordena ulterior e finalmente para Deus. Por onde, o
pecado que recai sobre a substância mesma do homem, como o homicídio, é mais grave do que outro
cujo objeto são as coisas exteriores, como o furto; mas ainda é mais grave o cometido diretamente
contra Deus, como a infidelidade, a blasfêmia e outros. E na ordem desses pecados, cada um é mais ou
menos grave segundo recai sobre o mais ou menos principal. E como os pecados se especificam pelos
seus objetos, a diferença de gravidade nestes fundada é a primária e a principal, sendo quase
conseqüente à espécie.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Embora o objeto seja a matéria em que termina o ato,
exerce contudo a função de fim, por recair sobre ele a intenção do agente, como já dissemos acima
(ibid). Ao passo que a forma do ato moral depende do fim, como do sobredito claramente resulta (q. 71,
a. 3).

RESPOSTA À SEGUNDA. ― Da mesma conversão indébita para algum bem mutável resulta o
afastamento do bem imutável, o que completa a essência do mal. E portanto importa que, da
diversidade do que respeita à conversão resulta a diversa gravidade da malícia dos pecados.

RESPOSTA À TERCEIRA. ― Todos os objetos dos atos humanos se ordenam uns para os outros. E
portanto todos convêm, de certo modo, num mesmo gênero, como ordenados para o fim último. Logo,
nada impede sejam todos os pecados suscetíveis de comparação entre si.

## Art. 4 — Se a gravidade dos pecados difere da dignidade das virtudes a que se opõem; de modo que à maior virtude se oponha maior pecado.
(IIa IIae, q. 20, a. 3; De Malo, q. 2, a. 10)
O quarto discute-se assim. ― Parece que a gravidade dos pecados não difere pela dignidade das
virtudes a que se opõem; de modo que à maior virtude se oponha o maior pecado.

1. ― Pois, segundo a Escritura (Pr 15, 5), na abundante justiça há uma grandíssima força. Ora, como diz
o Senhor (Mt 5, 20ss), a justiça abundante coíbe a ira, menor pecado que o homicídio, coibido por uma
justiça menor. Logo, à maior virtude se opõe o mínimo vício.

2. Demais. ― Aristóteles diz, que a virtude versa sobre o difícil e o bem; donde se conclui que a virtude
maior versa sobre maior dificuldade. Ora, falharmos no mais difícil é menor pecado que falharmos no
menos difícil. Logo, à maior virtude se opõe o menor pecado.

3. Demais. ― A caridade é maior virtude que a fé e a esperança, como diz a Escritura (1 Cor 13, 13). Ora,
o ódio, oposto à caridade, é menor pecado que a infidelidade ou o desespero, opostos à fé e à
esperança. Logo, à maior virtude se opõe o menor pecado.
Mas, em contrário, o Filósofo diz, que o péssimo é o contrário do ótimo. Ora, na ordem moral, o ótimo é
a máxima virtude, e o péssimo, o mais grave pecado. Logo, este se opõe àquela.

SOLUÇÃO. ― Um pecado se opõe a uma virtude de dois modos. ― Principal e diretamente, e tal se dá
em relação ao mesmo objeto, pois os contrários o têm idêntico. E assim, necessariamente à maior
virtude se opõe o mais grave pecado. Pois, no objeto se funda tanto a maior gravidade do pecado, como
a maior dignidade da virtude; porque um e outro se especificam pelo objeto, como do sobredito
claramente resulta (q. 60, a. 5; q. 72, a. 1). Por onde e necessariamente, a maior virtude é contrariada
de modo direto pelo maior pecado, como o que dele dista no máximo grau, no mesmo gênero.
De outro modo, podemos considerar a oposição entre a virtude e o pecado, no atinente à extensão da
virtude que o coíbe. Pois, quanto maior for a virtude, tanto mais nos afastará do pecado contrário; de
maneira que o coibirá não só a ele, mas ainda, o que a ele induz. E assim, é manifesto que quanto maior
for uma virtude, tanto menores serão os pecados por ela coibidos; do mesmo modo que, quanto melhor
for a saúde, tanto menores moléstias excluirá. E portanto, à maior virtude se opõe o menor pecado,
quanto ao efeito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção colhe no referente à oposição fundada na
coibição do pecado; pois, assim também a justiça abundante coíbe menores pecados.

RESPOSTA À SEGUNDA. ― A maior virtude, versando sobre um bem mais difícil, é contrariada
diretamente por um pecado cujo objeto é mal mais difícil. Pois, de lado a lado, descobrimos uma certa
eminência, por mostrar-se a vontade mais inclinada ao bem ou ao mal, não se deixando vencer pela
dificuldade.

RESPOSTA À TERCEIRA. ― A caridade não é um amor qualquer, mas o de Deus. Por onde, qualquer ódio
não se lhe opõe diretamente, senão só o ódio de Deus, o gravíssimo dos pecados.

## Art. 5 — Se os pecados carnais implicam menor culpa que os espirituais.
(IIa IIae, q. 154, a.3; IV Sent., dist. XXXIII, q. 1, a. 3, qa 2, ad 3; De Verit., q. 25, a. 6 ad 2; In Isaiam, cap. I)
O quinto discute-se assim. ― Parece que os pecados carnais implicam menor culpa que os espirituais.

1. ― Pois, o adultério é mais grave pecado que o furto, conforme a Escritura (Pr 6, 30.32): Não é grande
culpa quando alguém furtar. Porém o que é adúltero perderá a sua alma por causa da loucura do seu
coração. Ora, o furto se inclui na avareza, que é pecado espiritual; e o adultério, na luxúria, que é o
carnal. Logo, os pecados carnais implicam maior culpa.

2. Demais. ― Como diz Agostinho, o diabo sobretudo se compraz com o pecado de luxúria e de idolatria.
Ora, ele se mais compraz com a culpa maior. Logo, sendo a luxúria pecado carnal, resulta que os
pecados carnais implicam maior culpa.

3. Demais. ― O Filósofo prova que a concupiscência do incontinente é mais torpe que a sua ira. Ora, a
ira é pecado espiritual, segundo Gregório; ao passo que a concupiscência se inclui nos pecados carnais.
Logo, o pecado carnal é mais grave que o espiritual.
Mas, em contrário, diz Gregório, que os pecados carnais encerram menor culpa e maior infâmia.

SOLUÇÃO. ― Os pecados espirituais implicam maior culpa que os carnais. Mas isto não quer dizer que
qualquer pecado espiritual implique maior culpa que qualquer carnal; senão que, considerada só a
diferença entre a espiritualidade e a carnalidade, os espirituais são, em igualdades de condições, mais
graves que os carnais. Do que se pode dar tríplice razão. ― A primeira é tirada do sujeito. Pois, ao passo
que os pecados espirituais pertencem ao espírito, ao qual é próprio tanto o converter-se para Deus
como o afastar-se dele, os pecados carnais consumam-se no deleite do apetite carnal, ao qual é
principalmente próprio converter-se ao bem corpóreo. E portanto, o pecado carnal, como tal, a que é
própria sobretudo a conversão, adere também mais profundamente; ao passo que ao pecado espiritual
é próprio sobretudo a aversão, fundamento da culpa. Por onde, esta o pecado espiritual, em si mesmo,
a tem maior. ― A segunda razão pode ser tirada do sujeito contra quem pecamos. Pois, o pecado carnal,
como tal, recai sobre o nosso próprio corpo, menos digno de amor, na ordem da caridade, que Deus e o
próximo, contra quem pecamos pelos pecados espirituais. Logo, estes, em si mesmos, implicam maior
culpa. ― A terceira razão pode ser tirada do motivo. Pois, quanto mais grave é a tendência para pecar,
tanto menos pecamos, como mais abaixo diremos (a. seq.). Ora, os pecados carnais procedem de uma
tendência mais veemente, que é a concupiscência mesma da carne, inata em nós. Logo, os pecados
espirituais, em si mesmos, implicam maior culpa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O adultério não somente implica o pecado de luxúria
mas também o de injustiça. E por este lado, pode reduzir-se à avareza, como diz a Glosa sobre aquilo da
Escritura (Ef 5, 5):todo fornicário ou imundo, ou avaro. Por onde, o adultério é mais grave que o furto,
por nos ser mais cara a esposa do que qualquer coisa possuída.

RESPOSTA À SEGUNDA. ― Diz-se que o diabo se compraz sobretudo com o pecado da luxúria, porque
esta implica a máxima aderência, a que o homem só dificilmente pode furtar-se. Pois, no dizer do
Filósofo, é insaciável o apetite do prazer. RESPOSTA À TERCEIRA. ― Para o Filósofo, o incontinente por
concupiscência é mais torpe do que o incontinente pela ira, porque pARTicipa menos da razão. E por
isso, também diz que os pecados de intemperança são os mais dignos de exprobação, por recaírem
sobre os prazeres que nos são comuns com os brutos, e que, de certo modo, nos igualam a eles. Donde
vem, no dizer de Gregório, a maior infâmia desses pecados.

## Art. 6 — Se a gravidade dos pecados depende da causa deles.
(De Malo, q. 2, a. 10)
O sexto discute-se assim. ― Parece que a gravidade dos pecados não depende da causa deles.

1. ― Pois, quanto maior for a causa do pecado, tanto mais nos provoca a pecar, e assim, tanto mais
dificilmente lhe podemos resistir. Ora, o pecado diminui na razão da dificuldade com que lhe resistimos;
pois, por fraqueza é que o pecador não resiste facilmente ao pecado, que, por fraqueza, é considerado
mais leve. Logo, não é da sua causa que ele tira a sua gravidade.

2. Demais. ― A concupiscência é uma causa geral do pecado. Por isso a Glosa, sobre aquilo da Escritura
(Rm 6, 7) ― porque eu não conheceria a concupiscência etc. ― diz: É boa a lei que, proibindo a
concupiscência, proíbe ao mesmo tempo, todo o mal. Ora, quanto maior for a concupiscência a que
sucumbirmos, tanto menor será o nosso pecado. Logo, a gravidade deste diminui conforme a grandeza
da causa.

3. Demais. ― Assim como a retitude da razão é a causa do ato virtuoso, assim a privação dela o é do
pecado. Ora, tanto menor será o pecado quanto maior for a tal privação; a ponto que, a privação do uso
da razão excusa totalmente do pecado, e quem peca por ignorância peca mais levemente. Logo, a
gravidade do pecado não aumenta com a grandeza da causa.
Mas, em contrário. ― Multiplicada a causa, multiplicado fica o efeito. Logo, quanto maior for a causa do
pecado, tanto mais grave será ele.

SOLUÇÃO. ― No gênero do pecado, como em qualquer outro gênero, podemos considerar uma dupla
causalidade. ― Uma, é em si e propriamente a causa do pecado, e tal é a vontade de pecar, que está
para o ato pecaminoso como a árvore, para o fruto, no dizer da Glosa, sobre aquilo da Escritura: Não
pode a árvore boa dar maus frutos. Ora, quanto maior for esta causa tanto mais grave será o pecado.
Pois, quanto maior for a vontade de pecar, tanto mais gravemente pecaremos.
Quanto às outras causas do pecado, elas são consideradas como extrínsecas e remotas, e levam a
vontade a se inclinar a ele. Ora, nestas causas devemos distinguir. ― Umas induzem a vontade a pecar,
de acordo com a natureza mesma dela; tal é o fim, seu objeto próprio. E essa causa aumenta o pecado;
pois, pecamos mais gravemente quando a nossa vontade se inclina ao pecado movida pela intenção de
um fim pior. ― Outras porém inclinam a vontade a pecar, contra a sua própria natureza e ordem; pois,
é-lhe natural agir livremente e por si mesma, seguindo o juízo da razão. Portanto, as causas que o
diminuem, como a ignorância; ou as que diminuem o livre movimento da vontade, como a fraqueza, a
violência, o medo ou outra causa semelhante, diminuem o pecado, assim como diminuem o voluntário;
e a ponto de, se o ato for totalmente involuntário, não implicar nenhum pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção procede relativamente à causa motora
extrínseca, que diminui o voluntário; pois, como acabamos de dizer, o aumento dessa causa diminui o
pecado.

RESPOSTA À SEGUNDA. ― Na concupiscência também está incluído o movimento mesmo da vontade;
assim, quanto mais ardente for a concupiscência, maior será o pecado. Se esta porém for considerada
como paixão, que é o movimento da potência concupiscível, então a concupiscência maior precedente
ao juízo da razão e ao movimento da vontade, diminui o pecado. Pois, quem peca estimulado por
ardente concupiscência cai arrastado por uma tentação mais grave, e portanto menos se lhe imputa o
pecado. Se porém a concupiscência, assim considerada, for conseqüente ao juízo da razão e ao
movimento da vontade, então quanto maior for ela, tanto maior será o pecado. Porque às vezes surge
um mais ardente movimento da concupiscência, pelo tender desenfreado da vontade para o seu objeto.

RESPOSTA À TERCEIRA. ― A objeção colhe quanto à causa do voluntário, que diminui o pecado, como já
dissemos.

## Art. 7 — Se a circunstância agrava o pecado.
(IV Sent., dist. XVI, q. 3, a. 2, qa. 1; De Malo, q. 2, a. 7)
O sétimo discute-se assim. ― Parece que a circunstância não agrava o pecado.

1. ― Pois, a gravidade do pecado lhe provém da espécie. Ora, a circunstância, sendo acidente dele, não
o especifica. Logo, a gravidade do pecado não depende da circunstância.

2. Demais. ― A circunstância ou é má ou não. Se má, causa por si mesma uma espécie de mal; se não for
má, não pode aumentar o mal. Logo, de nenhum modo aumenta o pecado.

3. Demais. ― A malícia do pecado procede da sua aversão. Ora, pela conversão do mesmo é que as
circunstâncias lhe são conseqüentes. Logo, não lhe aumentam a malícia.
Mas, em contrário, a ignorância da circunstância diminui o pecado; pois, quem peca, ignorando-a,
merece perdão, como diz Aristóteles. Ora, isto não se daria se ela não agravasse o pecado. Logo, agrava.

SOLUÇÃO. ― A cada ser é natural o crescer pela mesma causa que o gerou, como diz o Filósofo,
tratando do hábito da virtude. Ora, é manifesto, que o pecado é causado pela ausência de alguma
circunstância; pois, é por não observarmos as devidas circunstâncias, que em nossos atos nos afastamos
da ordem da razão. Por onde é manifesto, que é natural ao pecado aumentar com circunstância.
O que se dá de tríplice modo. ― Primeiro, porque a circunstância muda o gênero do pecado. Assim, o
pecado de fornicação consiste na relação com mulher ilegítima. A circunstância porém, de ser casada,
muda o gênero do pecado, que vem a ser o de injustiça, consistente em usurpar o alheio. Por isso o
adultério é mais grave pecado que a fornicação. ― Às vezes contudo, a circunstância agrava o pecado,
não pelo mudar de gênero, mas só, pelo multiplicar. Assim o pródigo, dando quando não deve e a quem
não deve, peca mais vezes, no mesmo gênero de pecado, do que se desse só a quem não deve. Ora, por
isto mesmo torna-se mais grave, assim como o é a doença que ataca mais partes do corpo. E por isso,
diz Túlio: quem viola a vida do próprio pai peca multiplicadamente, pois fere quem o procriou, nutriu,
educou, deu-lhe habitação, casa e o estabeleceu na república. ―Em terceiro lugar, a circunstância
agrava o pecado, aumentando a deformidade proveniente de outra circunstância. Assim, tomar o alheio
constitui pecado de furto. Porém a circunstância de tomá-lo em grande quantidade tornará o pecado
mais grave, embora, tomar muito ou pouco, em si mesmo, não implique bondade nem malícia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Há circunstâncias especificadoras do ato moral, como já
dissemos (q. 18, a. 10). Mesmo porém uma circunstância que não o especifique pode agravar o pecado.
Pois, como a bondade de uma coisa é pesada não só pela espécie, mas também pelo acidente, assim
também, a malícia de um ato não é pesada só pela espécie, mas também pela circunstância dele.

RESPOSTA À SEGUNDA. ― De um e outro modo a circunstância pode agravar o pecado. Sendo má, nem
por isso há-de constituir necessariamente uma espécie de pecado; pois, pode aumentar a malícia, numa
mesma espécie, como se disse. Não o sendo, pode agravar o pecado, relativamente à malícia de outra
circunstância.

RESPOSTA À TERCEIRA. ― A razão deve ordenar o ato, não só quanto ao objeto, mas também quanto a
todas as circunstâncias. Portanto, qualquer aversão da regra racional se funda na corrupção de alguma
circunstância; assim, por exemplo, se agirmos quando ou onde não devemos. E tal aversão basta para
fundar a malícia. Pois, de tal aversão à regra racional resulta o afastamento de Deus, a quem devemos
nos unir, pela retitude da razão.

## Art. 8 — Se a gravidade do pecado cresce com o aumento do dano causado.
(Supra q. 20, a. 5)
O oitavo discute-se assim. ― Parece que a gravidade do pecado não cresce com o aumento do dano
causado.

1. ― Pois, o dano é conseqüência eventual do ato pecaminoso. Ora, uma conseqüência eventual não
aumenta a bondade ou a malícia do ato, como já dissemos (q. 20, a. 5). Logo, o pecado não se agrava
com o aumento do dano causado.

2. Demais. ― O dano causado provém, principalmente, dos pecados contra o próximo, porque a nós
mesmos não queremos, e a Deus não podemos fazer mal, conforme aquilo da Escritura (Jô 35, 6): se as
tuas iniqüidades se multiplicarem, que farás tu contra ele? A tua impiedade poderá fazer mal a um
homem que é teu semelhante. Ora, se o pecado se agravasse em relação ao dano causado, resultaria
que, pecando contra o próximo, pecaríamos mais gravemente que quando contra Deus ou contra nós
mesmos.

3. Demais. ― Causamos maior dano a outrem, privando-o da graça do que da vida natural; pois,
devemos desprezar a vida natural para não perder a da graça. Ora, quem induz uma mulher a pecar,
priva-a, o quanto pode, da vida da graça, levando-a a cometer pecado mortal. Se portanto, a gravidade
do pecado dependesse do dano que causa, resultaria pecar o simples fornicário mais gravemente que o
homicida, e isso é manifestamente falso. Logo, a gravidade do pecado não depende do dano que causa.
Mas, em contrário, Agostinho diz: Como o vício se opõe à natureza, a malícia dele aumenta na mesma
razão em que diminui a integridade da natureza. Ora, esta diminuição é um mal. Logo, tanto mais grave
é o pecado quanto maior é o dano causado.

SOLUÇÃO. ― O dano causado pode manter tríplice relação com o pecado. ― Assim, às vezes o dano
proveniente do pecado é previsto e intencionado; tal o caso de quem, como o homicida ou o ladrão, age
com o ânimo de danificar a outrem. E nesse caso o vulto do dano causado aumenta diretamente a
gravidade do pecado, porque então esse dano é, em si, o objeto do pecado. ― Outras vezes porém o
dano é previsto, mas não intencionado. Tal o caso de quem, atravessando um campo para poder mais
expedito cometer a fornicação danifica cientemente as sementeiras, embora sem a intenção de o fazer.
E neste caso a grandeza do dano agrava o pecado, mas indiretamente, porque, da vontade fortemente
inclinada ao pecado procede o não nos importarmos de causar dano a nós mesmos ou a outrem, o que
entretanto, absolutamente falando, não quereríamos. ― Outras vezes ainda, não é o dano previsto nem
intencionado. E então, se se relacionar com o pecado acidentalmente, não o agrava, de modo direto.
Mas, pela negligência em considerar os danos que poderiam resultar, são-nos imputados, para o efeito
da pena, os danos causados contra a nossa intenção, se praticávamos um ato ilícito. Se porém o dano,
em si mesmo, resultar do ato pecaminoso, agrava, embora não intencionado nem previsto, diretamente
o pecado. Porque todas as conseqüências resultantes, em si mesmas, do pecado, pertencem-lhe, de
certo modo, à espécie. Assim, quem fornicar publicamente escandaliza a muitos; o que, embora não
seja intencionado, nem talvez previsto, agrava contudo diretamente o pecado.
Diferem porém as relações com o dano da pena em que incorre quem peca. Assim, se esse dano tiver
relação acidental com o ato pecaminoso, mas não for previsto nem intencionado, não agrava tal ato
nem é conseqüente à maior gravidade deste. Tal o caso de quem, correndo para matar, dê um
encontrão e se fira no pé. Se porém esse dano resultar, em si mesmo, embora talvez não previsto nem
intencionado, do ato pecaminoso, então o dano maior não torna mais grave o pecado, mas
inversamente, o pecado mais grave é o que causa mais grave dano. Assim, o infiel, que nunca ouviu falar
das penas do inferno, lá sofrerá mais grave pena pelo pecado de homicídio, do que pelo de furto; e o
não ter intencionalmente desprezado o inferno nem o previsto, não lhe agrava o pecado. O contrário se
dá com o fiel, que peca mais gravemente, por isso mesmo que despreza maiores penas para satisfazer à
vontade de pecar. Mas a gravidade deste dano só é causada pela gravidade do pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como já dissemos (q. 20, a. 5), quando tratamos da
bondade e da malícia dos atos exteriores, a conseqüência eventual, sendo prevista e intencionada,
aumenta a bondade ou a malícia do ato.

RESPOSTA À SEGUNDA. ― De agravar o dano o pecado não se segue que só ele é que o faz. Antes, o
pecado, em si mesmo, é mais grave, por força da inclinação, como já dissemos (a. 2, 3). Por onde, o
dano, por si, agrava o pecado, tornando o ato mais desordenado. Donde não resulta, se há dano,
sobretudo nos pecados contra o próximo, que esses pecados sejam gravíssimos. Pois, há muito maior
desordem em certos pecados contra Deus e contra nós mesmos. Porquanto, podemos dizê-lo, embora
ninguém possa fazer mal a Deus, na sua substância, é possível entretanto atingi-lo naquilo que lhe
pertence; p. ex., extirpando a fé, violando o sagrado, que constituem pecados gravíssimos. E também, às
vezes, podemos, ciente e voluntariamente, causar dano a nós mesmos, como se dá com os suicidas,
embora o façam, finalmente, por causa de algum bem aparente, como seja livrarem-se do sofrimento.

RESPOSTA À TERCEIRA. ― A objeção não colhe, por duas razões. Primeiro, porque o homicida
intenciona diretamente danificar o próximo, ao passo que o fornicador, sedutor de uma mulher, não lhe
intenciona o dano, mas o prazer dele próprio. Segundo, porque o homicida é causa em si e suficiente da
morte corpórea; mas, da morte espiritual de outrem, ninguém pode ser por si mesmo causa suficiente,
porque ninguém morre espiritualmente senão por própria vontade, pecando.

## Art. 9 — Se o pecado se agrava conforme a condição da pessoa contra quem pecamos.
(IIa IIae, q. 65, a. 4; III, q. 80, a. 5; 1 Cor., cap. XI, lect. VII)
O nono discute-se assim. ― Parece que o pecado não se agrava conforme a condição da pessoa contra
quem pecamos.

1. ― Pois, se assim fosse, ele se agravaria sobretudo quando pecamos contra uma pessoa justa e santa.
Ora, tal não se dá, pois, é menos atingido pela injúria o virtuoso, que a tolera com equanimidade, do
que outros que, feridos, escandalizam-se interiormente. Logo, a condição da pessoa contra quem
pecamos não agrava o pecado.

2. Demais. ― Se a condição da pessoa agravasse o pecado, este tanto mais se agravaria quanto mais
próxima nos fosse ela. Pois, como diz Túlio, pecamos uma vez, matando um escravo, mas muitas,
quando atentamos contra a vida paterna. Ora, parece, a proximidade da pessoa contra quem pecamos
não agrava o pecado; pois ninguém nos é mais próximo que nós mesmos, e contudo pecamos menos
danificando-nos a nós que a outrem. Assim, se matássemos o nosso cavalo do que se matássemos o de
outrem, como o diz claramente o Filósofo. Logo, a proximidade da pessoa não agrava o pecado.

3. Demais. ― A condição do pecador agrava o pecado, sobretudo em razão da dignidade ou da ciência,
conforme aquilo da Escritura (Sb 6, 7): os poderosos serão poderosamente atormentados; e (Lc 12,
47) àquele servo que soube a vontade de seu senhor, e não se apercebeu, dar-se-lhe-ão muitos
açoites. Logo, pela mesma razão, a dignidade ou a ciência da pessoa contra quem pecamos agrava mais
o pecado. Ora, não peca mais gravemente quem injuria uma pessoa mais rica ou poderosa do que quem
o faz a um pobre, porque nãohá acepção de pessoas em Deus (Cl 3, 25), cujo juízo regula a gravidade do
pecado. Logo, a condição da pessoa contra quem pecamos não agrava o pecado.
Mas, em contrário, a Sagrada Escritura vitupera especialmente os pecados cometidos contra os servos
de Deus (3 Rs 19, 14): destruíram os teus altares, mataram os teus profetas à espada. Sobretudo
vitupera também o pecado cometido contra as pessoas próximas (Mq 7, 6): o filho faz afronta ao pai, e a
filha se levanta contra sua mãe. E ainda vitupera especialmente o pecado cometido contra as pessoas
constituídas em dignidade (Jó 34, 18). O que diz ao rei “apóstata”, e chama ímpio aos grandes. Logo, a
condição da pessoa contra quem pecamos agrava o pecado.

SOLUÇÃO. ― A pessoa contra quem pecamos é, de certo modo, objeto do pecado. Ora, como já
dissemos (a. 3), a gravidade do pecado depende primeiramente do objeto; e portanto, ela é tanto maior
quanto mais esse objeto constitui um fim principal. Ora, os fins principais dos atos humanos são Deus,
nós mesmos e o próximo; pois, todos os nossos atos visam um desses três fins, embora cada qual deles
se ordene a outro. Logo, em relação aos três, podemos considerar a maior ou menor gravidade do
pecado, quanto à condição da pessoa contra quem pecamos.
Assim, quanto a Deus, primeiramente, com quem a pessoa é tanto mais unida quanto mais virtuosa ou
mais consagrada lhe for. Por onde, a injúria assacada contra ela, redunda, principalmente, para Deus,
conforme aquilo da Escritura (Zc 2, 8): aquele que tocar em vós toca na menina dos meus olhos. Por
isso, tanto mais grave será o pecado quanto mais a pessoa contra quem pecamos estiver unida com
Deus, pela virtude ou pelo estado.
Quanto a nós mesmos, é manifesto que tanto mais gravemente pecaremos, quanto mais a pessoa
contra quem o fizermos nos for mais próxima, seja pelos laços naturais, seja pelos benefícios ou por
qualquer outra união; pois então, mais pecaremos contra nós mesmos e, portanto, mais gravemente,
conforme aquilo da Escritura (Ecle 14, 5): Para que pessoa será bom aquele que é mau para si?
E por fim, quanto ao próximo, tanto mais gravemente pecaremos quanto mais pessoas atingirmos. E por
isso o pecado contra uma pessoa pública, como o rei ou o chefe, que governa a causa pública em nome
do povo, é mais grave do que cometido contra uma pessoa privada. Donde o dizer a Escritura
especialmente (Ex 22, 28):não amaldiçoarás o principal do teu povo. E semelhantemente, a injúria
contra uma pessoa famosa é considerada mais grave porque redunda em escândalo e perturbação de
muitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Quem assaca uma injúria contra uma pessoa virtuosa, a
ofende, na medida em que pode, tanto interior como exteriormente. Mas, o não se ofender ela
interiormente depende da sua bondade, e em nada diminui o pecado de quem a injuria.

RESPOSTA À SEGUNDA. ― O dano que causamos a nós mesmos, no atinente ao dependente do
domínio da nossa própria vontade, como, por exemplo, o que possuímos, é menos pecaminoso, por isso
mesmo que agimos por vontade própria, do que o dano causado a outrem. Mas, quanto ao
independente do domínio da nossa vontade, com os bens materiais e espirituais, é maior pecado
danificarmo-nos a nós mesmos. Assim, pecamos mais gravemente matando-nos a nós mesmos do que a
outrem. Ora, como os bens dos nossos próximos não estão sujeitos ao domínio da nossa vontade, a
objeção não colhe, dizendo que, quanto aos danos que lhes causamos, pecamos menos; a menos que
eles não o queiram ou o ratifiquem.

RESPOSTA À TERCEIRA. ― Não há acepção de pessoas, se Deus pune mais gravemente quem peca
contra pessoas mais excelentes; e isso é assim porque tal pecado redunda em dano de muitos.

## Art. 10 — Se a grandeza da pessoa que peca agrava o pecado.
(Infra, q. 89, a. 3; De Malo, q. 7, a. 10, a. 5; Ad Hebr., cap. X, lect. III)
O décimo discute-se assim. ― Parece que a grandeza da pessoa que peca não agrava o pecado.

1. ― Pois, o que sobretudo nos engrandece é a nossa união com Deus, conforme aquilo da Escritura
(Ecle 15, 13): Que grande é aquele que acha a sabedoria e a ciência! Porém com tudo isso não tem
vantagem sobre aquele que teme o Senhor. Ora, quanto mais nos unimos a Deus tanto menos se nos
imputa um ato como pecado; pois, diz ainda a Escritura (2 Pr 30, 18): O Senhor que é bom será propício
para todos os que buscam de todo o seu coração o Senhor Deus de seus pais, e ele lhes não imputará
nenhuma falta de não estarem bem purificados. Logo, o pecado não é agravado pela grandeza da
pessoa do pecador.

2. Demais. ― Não há para com Deus acepção de pessoas, como diz o Apóstolo (Rm 2, 11). Logo, por um
mesmo pecado, não pune mais um, que outro. Logo, não se agrava o pecado pela grandeza da pessoa
do pecador.

3. Demais. ― Ninguém deve sofrer incômodo pelo bem que possui. Ora, sofrê-lo-ia se, por isso, mais se
lhe imputasse em ato culposo. Logo, pela grandeza da pessoa que peca não se agrava o pecado.
Mas, em contrário, diz Isidoro: Conhecemos que o pecado é tanto maior quanto maior é considerada a
pessoa que peca.

SOLUÇÃO. ― Há dupla espécie de pecados. ― Uns nascem em nós sub-repticiamente, assim os
radicados na debilidade da nossa natureza. E estes menos se imputam a quem tem maior virtude,
porque se descuida menos de os reprimir, embora livrar-se deles completamente não o permita a nossa
natureza enferma. Outros porém procedem da deliberação anterior. E estes tanto mais são imputáveis a
uma pessoa quanto maior lhe for a grandeza. E isto pode dar-se por quatro razões. Primeira, porque os
maiores, como os mais eminentes pela ciência e pela virtude, podem resistir mais facilmente ao pecado.
E por isso o Senhor diz (Lc 13, 47):àquele servo que soube a vontade de seu senhor, e não se apercebeu,
dar-se-lhe-ão muitos açoites. ―A segunda é a ingratidão; porque todo bem que nos engrandece é
benefício de Deus, a quem somos ingratos, pecando. E a esta luz qualquer grandeza, mesmo de bens
temporais, agrava o pecado, conforme aquilo da Escritura (Sb 6, 7): os poderosos serão poderosamente
atormentados. ―A terceira se funda na repugnância entre o ato do pecado e a grandeza da pessoa;
assim, se violar a justiça o príncipe, que dela deve ser o guarda; e se fornicar o sacerdote, votado à
castidade. ― A quarta, no exemplo ou escândalo; pois, como diz Gregório, o exemplo aumenta
veementemente a culpa, quando o pecador é honrado por causa da reverência ao seu grau. E também
os pecados dos grandes chegam ao conhecimento de muitos, que os suportam com maior indignação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A autoridade aduzida se refere ao que praticamos com
negligência, pela sub-reptícia debilidade da nossa natureza.

RESPOSTA À SEGUNDA. ― Deus não faz acepção de pessoas se pune mais as maiores; pois, a grandeza
delas aumenta a gravidade dos pecados, como já dissemos.

RESPOSTA À TERCEIRA. ― O homem de grande posição não sofre pelo bem que tem, mas, pelo mau uso
do mesmo.