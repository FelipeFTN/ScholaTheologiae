# Questão 50: Da substância dos anjos em absoluto.
Em seguida deve-se tratar da distinção entre a criatura corpórea e a espiritual. E, primeiro, da criatura
puramente espiritual chamada anjo na Sagrada Escritura. Segundo, da criatura puramente corpórea.
Terceiro, da criatura composta de corpo e espírito, que é o homem.
Quanto aos anjos, pois, deve-se tratar primeiro, do que lhes pertence à substância. Segundo, do que
lhes pertence ao intelecto. Terceiro, do que lhes pertence à vontade. Quarto, do que lhes pertence à
criação.
Quanto à substância, esta deve ser considerada em absoluto e por comparação com os corpos.
Sobre a substância deles em absoluto cinco artigos se discutem:

## Art. 1 — Se o anjo é absolutamente incorpóreo.
(II Cont. Gent.., cap. XLVI, XLXIX; Opusc. XV, De Angelis, cap. XVIII).
O primeiro discute-se assim. — Parece que o anjo não é absolutamente incorpóreo.

1. — Pois o incorpóreo só em relação a nós e não em relação a Deus não é absolutamente incorpóreo.
Ora, Damascenodiz que o anjo é dito incorpóreo e imaterial quanto a nós; mas, comparado com Deus,
conclui-se que é corpóreo e material. Logo, não é absolutamente incorpóreo.

2. Demais. — Só o corpo é movido, como o prova Aristóteles. Ora, Damasceno diz, ibidem, que o anjo
é uma substância intelectual sempre móvel. Logo, o anjo é substância corpórea.

3. Demais. — Ambrósio diz: Toda criatura está circunscrita pelos limites certos da sua natureza. Ora,
estar circunscrito é próprio dos corpos. Logo, toda criatura é corpórea. Mas os anjos são criaturas de
Deus, como se lê na Escritura (Sl 148, 2) Louvai o Senhor todos os seus anjos; ao que se
acrescenta: Porque Ele falou e as coisas se fizeram; mandou e foram criadas. Logo, os anjos são
corpóreos.
Mas, em contrário, diz a Escritura (Sl 103, 4): Que faz os anjos, seus espíritos.

SOLUÇÃO. — É necessário admitirem-se certas criaturas incorpóreas. Pois, o que Deus principalmente
visa, nas coisas criadas, é o bem, que consiste ao assemelhar-se com Ele. Ora, a perfeita assimilação do
efeito com a causa se dá quando aquele imita a esta segundo a virtude pela qual a causa produz o
efeito; assim o cálido produz o cálido. Ora, Deus produz a criatura pelo intelecto e pela vontade, como já
ficou dito. Donde, para a perfeição do universo se requer existam algumas criaturas intelectuais.
Inteligir, porém, não pode ser ato do corpo, nem de nenhuma virtude corpórea, porque todo corpo está
situado no lugar e no tempo. Por onde, é necessário admitir-se, para que o universo seja perfeito, a
existência de alguma criatura incorpórea. Mas os antigos, ignorando a virtude intelectiva e não
distinguindo entre o sentido e o intelecto, opinaram que nada existe no mundo, fora o que pode ser
apreendido pelos sentidos e pela imaginação. E como a imaginação só percebe o corpo, opinaram que
nenhum ente, além do corpo, pode existir, como diz o Filósofo. Donde procedeu o erro dos Saduceus
dizendo que não há espírito (At 23, 8). Mas o fato mesmo de ser o intelecto superior ao sentido prova
racionalmente que há certos seres incorpóreos compreensíveis só por aquele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As substâncias incorpóreas são o meio termo entre Deus
e as criaturas corpóreas. Ora, o meio, comparado com um extremo, é outro extremo; assim o tépido,
comparado com o cálido, é frígido. E por tal razão se diz que os anjos, comparados com Deus, são
materiais e corpóreos; e não por haver neles algo da natureza corpórea.

RESPOSTA À SEGUNDA. — Movimento aí se toma no sentido em que se diz que inteligir e querer são
certos movimentos. Por onde se diz que o anjo é substância sempre móvel porque sempre está em ato
de intelecção e não, como nós, ora em ato, ora em potência. Por onde se vê que a objeção procede de
um equívoco.

RESPOSTA À TERCEIRA. — Ser circunscrito por limites locais é próprio dos corpos; mas por limites
essenciais é comum a qualquer criatura, tanto corporal como espiritual. Por onde diz Ambrósioque,
embora certos seres não estejam contidos em lugares corpóreos, todavia não escapam à circunscrição
da substância.

## Art. 2 — Se o anjo é composto de matéria e forma.
(I Sent., dist. VIII, a. 5, a. 2; II, dist. III, q. 1, a. 1; II Cont. Gent., cap L, LI; De Spirit. Creat., a. 1; Quodl. III, q.
8, IX, q. 4, a. 1; Compend. Theol., cap. LXXIV; Opusc. XV, De Angelis, cap. V seqq.; cap. XVIII; De Ent. et
Ess., cap. V).
O segundo assim se discute. — Parece que o anjo é composto de matéria e forma.

1. — Pois, todo o contido em algum gênero é composto de gênero e diferença, a qual, acrescentada ao
gênero, constitui a espécie. Ora, o gênero provém da matéria, e a diferença, da forma, como se vê em
Aristóteles. Logo, tudo o que está em um gênero é composto de matéria e forma. Ora, o anjo está no
gênero da substância. Logo, é composto de matéria e forma.

2. Demais. — Onde existem as propriedades da matéria existe esta. Ora, propriedades da matéria são
receber e substar; por onde diz Boécioque a forma simples não pode ser sujeito. Ora, tal se dá com o
anjo. Logo, este é composto de matéria e forma.

3. Demais. — A forma é ato. Ora, o que é só forma é ato puro. Mas o anjo não é ato puro, pois só Deus o
é. Logo, não é somente forma, mas tem esta, na matéria.

4. Demais. — A forma propriamente é limitada e definida pela matéria. Logo, a forma sem matéria é
infinita. Ora, a forma do anjo não é infinita, porque toda criatura é finita. Logo, a forma do anjo existe na
matéria.
Mas em contrario diz Dionísioque a primeiras criaturas compreendidas como incorpóreas, são-no
também como imateriais.

SOLUÇÃO. — Alguns ensinam que os anjos são compostos de matéria e forma; é esta a opinião que
Avicebrãose esforça por estabelecer. Pois supõe que tudo o que for distinto pelo intelecto também o
será nas coisas. Ora, na substância incorpórea, o intelecto apreende algo pelo que ela se distingue da
corpórea e algo pelo que com esta convém. Por onde, quer concluir daí que aquilo pelo que a substância
incorpórea difere da corpórea é como que a forma daquela; e o que está sujeito a esta forma distintiva,
e é como que comum, é a matéria da substância incorpórea. E por isso ensina ser a mesma a matéria
universal dos seres espirituais e dos corpóreos; de modo que se entenda que a forma da substância
incorpórea esteja impressa na matéria dos seres espirituais, como a forma da quantidade o está na dos
corpóreos.
Mas, de primeira vista, conclui-se que é impossível seja a mesma a matéria dos seres espirituais e dos
corpóreos. Pois não é possível que a forma espiritual e a corporal sejam recebidas pela mesma parte da
matéria, porque então uma mesma coisa, numericamente, seria corpórea e espiritual. Donde se conclui
que uma parte é a parte da matéria que recebe a forma corpórea e outra a que recebe a forma
espiritual. Mas a matéria não pode ser dividida em partes senão enquanto submetida à quantidade;
removida esta, permanece a substância indivisível, como diz Aristóteles. Donde resulta que a matéria
dos seres espirituais está sujeita à quantidade, o que é impossível. Logo, é impossível que uma mesma
seja a matéria dos seres corpóreos e dos espirituais.
Mas, além disso, é impossível que a substância intelectual tenha qualquer espécie de matéria. Pois, a
operação de cada ser segue-lhe o modo da substância. Ora, inteligir é operação fundamentalmente
imaterial. O que se vê claramente pelo seu objeto; pois é deste que todo ato tira a sua espécie e sua
essência.
Assim, pois, um ser é inteligido enquanto abstraído da matéria; porque as formas da matéria são
individuais, e o intelecto não as apreende como tais. Donde se conclui que toda substância intelectual é
absolutamente imaterial.
Por onde, não é necessário seja distinta, nas coisas, o que o é pelo intelecto; pois este não apreende as
coisas ao modo delas, mas ao seu modo. E dai vem que as coisas materiais, inferiores ao nosso intelecto,
existem neste, de modo mais simples do que em si mesmas. Porem as substâncias angélicas são
superiores ao nosso intelecto. Donde, não poder ele chegar a apreendê-las tais como em si mesmas são;
mas ao seu modo, enquanto apreende coisas compostas. E assim também apreende Deus, como já
antes se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É a diferença que constitui a espécie. Ora, é constituído
numa espécie o ser determinado a um grau especial, entre os entes; porque as espécies das coisas são
como números, diferentes pela adição e subtração da unidade, como diz Aristóteles. Ora, nas coisas
materiais, é uma a coisa que determina ao grau especial, a saber, a forma, e outra a que é determinada,
a saber, a matéria; por onde, uma é a origem do gênero e outra a da diferença. Mas, nas coisas
imateriais, não há um determinante e determinado; mas, cada uma delas, em si mesmas, tem um grau
determinado entre os entes. Logo, o gênero e a diferença, nelas, não provém de origens diferentes, mas
sim de uma mesma origem. O que todavia é diferentemente compreendido pelo nosso intelecto; pois,
enquanto este considera uma dessas coisas indeterminadamente, descobre nelas a noção de gênero; e
enquanto determinadamente, a de diferença.

RESPOSTA À SEGUNDA. — Essa objeção é formulada por Avicebrão. E seria necessária se fossem
idênticos os modos pelos quais recebem o intelecto e a matéria. Ora, isto é claramente falso. Pois a
matéria recebe a forma para ser constituída, por esta, no ser de uma espécie, seja do ar, do fogo ou de
qualquer outra. Mas não é assim que o intelecto recebe a forma; do contrario se verificaria a opinião de
Empédocles, ensinando que conhecemos a terra pela terra e o fogo pelo fogo. Mas a forma inteligível
está no intelecto segundo a natureza mesma da forma, pois é assim que é conhecida por ele. Por onde,
tal recepção não é recepção da matéria, mas da substância imaterial.

RESPOSTA À TERCEIRA. — Embora, no anjo não haja composição de forma e de matéria, há todavia nele
ato e potência. E isto pode ser manifestado considerando as coisas materiais, nas quais se descobre uma
dupla composição. A primeira, de matéria e forma, pelas quais uma natureza é constituída. Mas a
natureza assim composta não é o seu ser, senão o do seu ato; por onde, tal natureza está para o seu ser
como a potencia para o ato. Logo, eliminada a matéria, e posto que a forma mesma subsista sem a
matéria, contudo ainda permanece a relação da forma com o seu ser, como a da potência com o ato. E
tal composição é a que se deve admitir nos anjos. E dai vem o dizerem alguns que o anjo é composto
do pelo que é e daquilo que é, ou, do ser e daquilo que é, como diz Boécio; pois aquilo que é é a forma
mesma subsistente; porém o ser em si é o pelo que a substância é; assim, a corrida é a pela que o
corredor corre. Mas, em Deus, não difere a essência, da existência, como antes se demonstrou. Por
onde, só Deus é ato puro.

RESPOSTA À QUARTA. — Toda criatura é finita por si mesma, enquanto a sua essência não é
absolutamente subsistente, mas limitada pela natureza à qual advém. Mas nada impede que uma
criatura seja, de certo modo, infinita. Assim as criaturas materiais têm a infinidade por parte da matéria,
mas a finidade por parte da forma, que é limitada pela matéria na qual é recebida. Porém, as
substâncias imateriais criadas, finitas na sua essência, são infinitas por não terem as suas formas
recebidas por outro ser. Seria como se disséssemos que a brancura, existindo separada, é infinita,
quanto à sua essência, por não ser esta concretizada em nenhum sujeito; mas, finita pela sua existência
por estar realizada numa natureza especial. E por isso se diz que a inteligência é finita
superiormente porque recebe o seu ser de um ser superior; mas é infinita inferiormente porque não é
recebida em matéria nenhuma.

## Art. 3 — Se é grande o número dos anjos existentes.
(Infra, q. 112, a. 4, ad 2; II Sent., dist, III, q. 1, a. 3; II Cont. Gent., cap. XCII; De Pot., q. 6, a. 6; Opusc. XV,
De Angelis, cap. II)
O terceiro discute-se assim. — Parece que os anjos não são em grande número.

1. — Pois, o número é espécie de quantidade e resulta da divisão do contínuo. Ora, este não existe nos
anjos, que são incorpóreos, como já antes de demonstrou. Logo, os anjos não podem ser em grande
número.

2. Demais. — Quanto mais um ser se aproxima da unidade, tanto menos multiplicado é, como se vê nos
números. Ora, a natureza angélica é, entre as outras naturezas criadas, a mais próxima de Deus. Logo,
sendo Deus maximamente uno, resulta que em a natureza angélica há um mínimo de multidão.

3. Demais. — O efeito próprio das substâncias separadas são os movimentos dos corpos celestes. Ora,
estes são em pequeno número determinado, que pode ser apreendido por nós. Logo, os anjos não são
em maior multidão que os movimentos dos corpos celestes.

4. Demais. — Dionísiodiz que pelos raios da divina bondade subsistem todas as substâncias inteligíveis e
intelectuais. Mas o raio não se multiplica senão pela diversidade dos que o recebem. Ora, não se pode
dizer que a matéria seja receptiva do raio inteligível, por serem as substâncias intelectuais imateriais,
como antes se demonstrou. Logo, conclui-se que a multiplicação das substâncias intelectuais não pode
ser senão segundo a exigência dos corpos primários, a saber, os celestes; de maneira que nestes
determinem, de certo modo, a multiplicação dos preditos raios. E assim se conclui o mesmo que antes.
Mas em contrário diz a Escritura (Dn 7, 10): Um milhão de ministros o serviam, e mil milhões assistiam
diante dele.

SOLUÇÃO. — Diversos trataram, por vias diversas, a questão do número das substâncias separadas.
Assim, Platão ensinou que elas são as espécies das coisas sensíveis; como, p. ex., se disséssemos que a
natureza humana em si é separada. E, segundo esta opinião, é necessário que as substâncias separadas
sejam relativas ao número das espécies sensíveis. — Porém Aristóteles refuta esta doutrina, por ser a
matéria da essência das espécies sensíveis. Por onde, as substâncias separadas não podem ser as
espécies exemplares de tais sensíveis, mas têm natureza mais elevada que a das coisas sensíveis.
Ensinou todavia Aristóteles, que essas naturezas mais perfeitas se ordenam às sensíveis, em
dependência das noções de motor e do fim, por isso se esforçou por deduzir, do número dos motores
primeiros, o das substâncias separadas.
Mas, como isto repugna ao testemunho da Sagrada Escritura, Rabbi Moisés, judeu, querendo conciliar
as coisas, ensinou que os anjos, como substâncias imateriais, multiplicam-se pelo número dos
movimentos dos corpos celestes, segundo Aristóteles. Mas acrescentou, para salvar a Escritura, quem
nesta, os anjos também são chamados homens anunciadores das coisas divinas, e das virtudes das
coisas naturais, manifestativas da onipotência de Deus. — Mas é estranho ao costume da Escritura o
chamarem-se às virtudes das coisas irracionais, anjos.
Deve-se portanto dizer que também os anjos, como substâncias imateriais, existem em multidão
máxima e excedem toda multidão material. E é isto o que Dionísio: muitos são os exércitos bem-
aventurados das inteligências supremas, excedendo a comensuração fraca e limitada dos nossos
números materiais. E a razão disto é que, sendo a perfeição do universo o que Deus principalmente
visou na criação das coisas, quanto mais perfeitos forem os seres tanto em maior excesso foram criados
por Deus. Porém, assim como, nos corpos, o excesso se realiza pela grandeza, assim, nos seres
incorpóreos, pode-se fundar ele na multidão. Pois vemos que os corpos incorruptíveis, os mais perfeitos
entre os corpos, excedem como incomparavelmente, pela grandeza, os corruptíveis. Assim, toda a
esfera dos corpos ativos e passivos é algo de pequeno em relação aos corpos celestes. Por onde, é
racional que as substâncias imateriais excedam, pela multidão, e como incomparavelmente, as
materiais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nos anjos não há o número, quantidade discreta,
causada pela divisão do continuo; mas o número causado pela distinção das formas, enquanto a
multidão pertence aos transcendentais, como já ficou dito.

RESPOSTA À SEGUNDA. — Por ser a natureza angélica próxima de Deus, importa tenha o mínimo de
multidão na sua composição; e não que a multidão se realiza em poucos.

RESPOSTA À TERCEIRA. — Essa objeção é de Aristóteles; e concluiria com necessidade, se as substâncias
separadas existissem por causa das substâncias corpóreas. Então seriam inúteis as substâncias
imateriais, salvo para causarem algum movimento nas coisas corpóreas. Mas não é verdade que as
substâncias imateriais existam por causa das corporais, porque o fim é mais nobre que os meios. E por
isso também Aristóteles diz, no mesmo passo, que essa razão não é necessária, mas provável. Demais,
foi forçado a usar dela, pois, ao conhecimento dos seres inteligíveis só podemos chegar pelos dos
sensíveis.

RESPOSTA À QUARTA. — Essa objeção procede segundo a opinião dos que ensinavam ser a matéria a
causa da distinção das coisas. Isto porém não está provado. Donde, a multiplicação dos anjos não se
pode admitir como fundada na matéria nem nos corpos; mas sim em ter a divina sabedoria planejado
diversas ordens de substâncias imateriais.

## Art. 4 — Se os anjos diferem pela espécie.
(II Sent., dist. III, q. 1, a. 4; dist. XXXII, q. 2, a. 3; IV, dist. XII, q. 1, a. 1, qª 3; II Cont. Gent., cap. XCII; De
Spirit. Creat., a. 8; Qu. De Anima. a. 3; De Ent. et Ess., cap. V).
O quarto discute-se assim. — Parece que os anjos não diferem pela espécie.

1. — Sendo a diferença mais nobre que o gênero, os seres que convém pelo que têm de mais nobre
convém pela última diferença constitutiva e, assim, são os mesmos em espécie. Ora, todos os anjos
convém pelo que têm de mais nobre, a saber, a inteligência. Logo, são todos da mesma espécie.

2. Demais. — O mais e o menos não diversificam a espécie. Ora, os anjos diferem uns dos outros só pelo
mais e pelo menos, a saber, enquanto um é mais simples que outro e de intelecto mais perspicaz. Logo,
não diferem pela espécie.

3. Demais. — A alma e o anjo dividem-se por oposição. Mas todas as almas são da mesma espécie. Logo
também os anjos.

4. Demais. — Quanto mais perfeita a natureza de um ser, tanto mais este deve se multiplicar. Ora, isto
seria impossível se, numa espécie, só existisse um individuo. Logo, há muitos anjos de uma mesma
espécie.
Mas em contrário é que, nos seres de uma mesma espécie, não há anteriores e posteriores, como diz
Aristóteles. Ora, entre os anjos, ainda da mesma ordem, há primeiros, médio e últimos, como diz
Dionísio. Logo, os anjos não são da mesma espécie.

SOLUÇÃO. — Alguns disseram que todas as substâncias espirituais, mesmo as almas, são da mesma
espécie. Outros, que todos os anjos são da mesma espécie, não porém as almas. Outros ainda, que são
da mesma espécie todos os anjos da mesma hierarquia ou da mesma ordem. — Mas isto é impossível.
Pois, os seres que convém pela espécie e diferem pelo número, convém pela forma e se distinguem pela
matéria. Ora, se os anjos não se compõem de matéria e forma, como antes se demonstrou, segue-se
que é impossível haver dois anjos da mesma espécie. Como também seriam impossíveis várias
brancuras separadas, ou várias humanidades; pois as brancuras não são várias senão enquanto existem
em substâncias. — Mesmo, porém, que os anjos tivessem matéria, nem assim poderiam existir vários
anjos da mesma espécie. Pois, então, seria necessariamente a matéria o princípio que distinguiria um do
outro; não, certo, pela divisão quantitativa, por serem os anjos incorpóreos, mas pela diversidade das
potências. Ora, esta diversidade material causa, não só a diversidade especifica, mas também a
genérica.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A diferença é mais nobre que o gênero, como o
determinado o é mais que o indeterminado, e o próprio do que o comum; não, porém, por serem de
naturezas diferentes. O contrário importaria em serem todos os irracionais da mesma espécie; ou em
existir neles alguma forma mais perfeita que a alma sensível. Logo, os irracionais diferem, pela espécie,
segundo diversos graus determinados da natureza sensitiva. E, semelhantemente, todos os anjos
diferem pela espécie, segundo os diversos graus da natureza intelectiva.

RESPOSTA À SEGUNDA. — O mais e o menos não diversificam a espécie, enquanto causados pela
intenção e remissão da mesma forma, mas enquanto causados pelas formas dos diversos graus; como
se disséssemos que o fogo é mais perfeito que o ar. E é deste modo que os anjos se diversificam pelo
mais e pelo menos.

RESPOSTA À TERCEIRA. — O bem da espécie prepondera sobre o do individuo. Por isso muito melhor é
se multipliquem as espécies angélicas do que os indivíduos de uma mesma espécie.

RESPOSTA À QUARTA. — A multiplicação numérica, podendo estender-se até ao infinito, não é a visada
pelo agente; mas só a especifica, como antes já se disse. Por onde, a perfeição da natureza angélica
exige a multiplicação das espécies e não a dos indivíduos de uma mesma espécie.

## Art. 5 — Se os anjos são incorruptíveis.
O quinto discute-se assim. — Parece não sejam os anjos incorruptíveis.

1. — Pois, diz Damasceno, do anjo, que é uma substância intelectual, dotada de imortalidade por graça
e não por natureza.

2. Demais. — Platãodiz: Ó deuses dos deuses, dos quais o autor mesmo e o pai sou eu. Sois, por certo,
minha obra; corruptíveis por natureza, mas, se eu quiser, incorruptíveis. Ora, estes deuses se podem
entender como não sendo seres diferentes dos anjos. Logo, estes são, por natureza, corruptíveis.

3. Demais. — Segundo Gregório, todas as coisas tenderiam ao nada se a mão do Onipresente não as
conservasse. Ora, o que pode ser reduzido ao nada é corruptível. Logo, como os anjos foram feitos por
Deus, resulta que são corruptíveis por natureza.
Mas, em contrario, diz Dionísio que as substâncias intelectuais têm vida indeficiente, isentas de
corrupção universal, da morte, da matéria e da geração.

SOLUÇÃO. — deve-se dizer que os anjos são, por natureza, incorruptíveis. E a razão é que nada se
corrompe senão porque a forma se separa da matéria. Donde, sendo o anjo a própria forma subsistente,
como já se disse, é impossível seja corruptível a substância dele. Pois, o que convém a um ser, pela
própria natureza deste, nunca deste pode separar-se; porém do ser ao qual alguma coisa convém, por
causa de outra, desse ela pode ser separada, separada que seja coisa pela qual a primeira lhe convinha.
Assim, a rotundidade não pode ser separada do círculo, porque lhe convém pela própria natureza dele;
mas um círculo de bronze pode perder a rotundidade se a figura circular for separada do bronze. Ora, o
ser em si compete à forma, pois é pela forma que um ser é atual. Porém, a matéria é um ser atualizado
pela forma. Por onde, o composto de matéria e forma deixa de ser atual quando a forma for separada
da matéria. Mas se a própria forma for subsistente no seu ser, como é o caso dos anjos, conforme já se
disse, ela não pode perder o ser. Por onde, a imaterialidade do anjo é a razão de ser ele incorruptível
por natureza. E um sinal dessa incorruptibilidade pode ser deduzido da operação intelectual angélica.
Pois, como cada ente opera enquanto está em ato, a operação indica o modo de ser do ente. Porém a
espécie e a natureza da operação se compreendem pelo objeto. Ora, como todo objeto inteligível,
estando fora do tempo, é sempiterno, resulta que toda substância intelectual é incorruptível por
natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Damasceno se refere à imortalidade perfeita, que inclui
onímoda imutabilidade; pois, toda mutação é de certo modo, morte, como diz Agostinho. Ora, a perfeita
imutabilidade os anjos só alcançam pela graça, como a seguir se verá.

RESPOSTA À SEGUNDA. — Platão entende, por deuses, os corpos celestes, que pensava serem
compostos de elementos e, portanto, corruptíveis por natureza, embora sempre se conservassem no
ser, por obra da vontade divina.

RESPOSTA À TERCEIRA. — Como já antes se disse, é necessário o que tem causa à sua necessidade. Por
onde, não repugna ao necessário nem ao incorruptível tenham o ser dependente de outro como da
causa. Donde, o dizer-se que todos os seres, mesmos os anjos, voltariam ao nada, se não fossem
conservados por Deus, não significa haja nos anjos algum princípio de corrupção; mas que o ser angélico
depende de Deus como da causa. Pois não se chama corruptível o que Deus pode reduzir ao nada,
subtraindo-lhe a conservação, mas o que traz consigo algum princípio de corrupção: a contrariedade,
ou, ao menos, a potência da matéria.