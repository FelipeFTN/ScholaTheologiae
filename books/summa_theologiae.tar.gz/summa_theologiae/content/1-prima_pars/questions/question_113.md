# Questão 113: Da guarda dos bons anjos.
Em seguida deve-se tratar da guarda dos bons anjos e da impugnação dos maus.
E sobre a primeira questão oito artigos se discutem:

## Art. 1 — Se os homens são guardados pelos anjos.
O primeiro discute-se assim. — Parece que os homens não são guardados pelos anjos.

1. – Pois, guardas se delegam para os que não sabem ou não podem se guardar a si mesmos, como as
crianças e os doentes. Ora, o homem, pelo livre arbítrio, pode–se guardar a si mesmo; e sabe guardar–
se pelo conhecimento natural da lei natural. Logo, não é guardado pelo anjo.

2. Demais. – A guarda mais forte torna inútil a mais fraca. Ora, os homens são guardados por Deus,
conforme a Escritura: Não adormecerá. nem dormirá o que guarda Israel. Logo, não é necessário o
homem ser governado pelo anjo.

3. Demais. A perda do guardado redunda em negligência do guarda; por onde, diz a Escritura: Guarda
este homem: se ele fugir, a tua vida responderá pela vida dele. Ora, muitos homens perecem
quotidianamente caindo em pecado, aos quais os anjos não podem socorrer, ou aparecendo
visivelmente, ou fazendo milagres, ou de qualquer modo semelhante. Portanto, os anjos seriam
negligentes, se os homens lhes tivessem sido entregues à guarda, o que. é claramente falso. Portanto,
eles não são guardas dos homens.
Mas, em contrário, diz a Escritura: Mandou aos, seus anjos acerca de ti, que te guardem em todos os
teus caminhos.

SOLUÇÃO. – Conforme a disposição da divina providência, todas as cousas móveis e variáveis são
movidas e regidas pelas imóveis e invariáveis. Assim, todos os seres corpóreos, pelas substâncias
espirituais imóveis; e os corpos inferiores, pelos superiores, substancialmente invariáveis. E também nós
somos regidos, quanto às conclusões, em relação às quais podemos opinar diversamente, pelos
princípios a que invariavelmente nos atemos. Ora, é manifesto, que o conhecimento e os afetos do
homem podem, em relação às cousas que ele deve fazer multiplicemente variar e falhar, quanto ao
bem. E por isso é necessário sejam delegados anjos para a guarda dos homens, que os rejam e movam
para o bem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Pelo livre arbítrio o homem pode de certo modo evitar o
mal, mas não suficientemente, porque os seus afetos bons são enfraquecidos pelas múltiplas paixões da
alma. Semelhantemente, também o conhecimento universal da lei natural, que o homem naturalmente
tem, de certo modo o dirige para o bem, mas não suficientemente, porque acontece que ele se engana
muitas vezes, aplicando os princípios universais de direito às obras particulares. Por onde, diz a
Escritura: Os pensamentos dos mortais são tímidos e incertos as nossas providências. E, portanto, é
necessária ao homem a guarda dos anjos.

RESPOSTA À SEGUNDA. – Duas condições são necessárias para se fazer o bem: que o afeto se incline
para ele, o que se dá em nós pelo hábito da virtude moral; e que a razão descubra vias congruentes para
realizar o bem da virtude, o que o Filósofo atribui à prudência. Quanto à primeira, Deus guarda o
homem, infundindo–lhe graça e virtudes. Quanto à segunda, guarda–o como instrutor universal, cuja
instrução chega ao homem mediante os anjos como já se estabeleceu.

RESPOSTA À TERCEIRA. – Assim como os homens desviam–se do instinto natural do bem, pela paixão
do pecado; assim também desviamse das inspirações dos bons anjos, que procedem invisivelmente,
iluminando–os, para bem agir. E por isso não é por negligência dos anjos, mas por malícia própria, que
eles perecem. E por graça especial de Deus é que eles, contra a lei comum, às vezes aparecem
visivelmente aos homens; assim como também fazem milagres, contra a lei comum.

## Art. 2 — Se cada homem é guardado por um anjo.
O segundo discute–se assim. – Parece que cada homem não é guardado por um anjo.

1. – Pois este tem maior virtude que o homem. Ora, um homem basta para guardar muitos outros. Logo,
com maior razão um anjo pode guardar muitos homens.

2. Demais. – Os seres inferiores são dependentes de Deus, por meio dos superiores, que se servem dos
médios, como diz Dionísio. Ora, sendo todos os anjos desiguais, como já se disse, há só um anjo sem
intermediário, em relação aos homens. Logo, é só um o que guarda imediatamente todos os homens.

3. Demais. – Os anjos maiores são delegados para maiores ofícios. Ora, não é maior ofício guardar antes
um homem, do que outro, sendo todos os homens iguais por natureza. Ora, como, entre todos os anjos,
um é maior que outro, como diz Dionísio, resulta que homens diversos não são guardados por anjos
diversos.
Mas, em contrário, Jerônimo, expondo aquilo da Escritura – os seus anjos nos céus diz: Deve ser grande
a dignidade das almas, para que cada uma tenha desde o princípio do nascimento, um anjo delegado
para a sua guarda.

SOLUÇÃO. – Para cada homem é delegado um anjo da guarda. E a razão é que a guarda dos anjos é uma
execução da divina Providência, em relação aos homens. Ora, a Providência de Deus procede, de um
modo, com os homens e, de outro, com as outras criaturas corruptíveis, porque aqueles e estas se
relacionam diferentemente com a incorruptibilidade. Pois, os homens são incorruptíveis, não só quanto
à espécie comum, mas também quanto às formas próprias de cada um, que são as almas racionais, o
que não se pode dizer dos outros seres corruptíveis. Ora, é manifesto que a Providência de Deus visa,
principalmente, os seres que permanecem perpetuamente; quanto aos transitórios porém a Providência
com eles se ocupa só para ordená–los para os seres perpétuos. Assim, pois a Providência de Deus está
para cada homem como está para cada género ou espécie dos seres corruptíveis. Ora, segundo
Gregório, ordens diversas são delegadas para os diversos gêneros de coisas; assim, as Potestades, para
afastar os demónios; as Virtudes, para fazer milagres, em relação às coisas corpóreas. E é provável que
às diversas espécies das coisas sejam prepostos diversos anjos duma mesma ordem. E por isso também
é racional, que a homens diversos sejam delegados, como guardas, anjos diversos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÁO. – De dois modos pode ser dado um guarda a um homem.
Como homem singular e, assim, a um mesmo homem é necessário um guarda e, às vezes, vários são
delegados para a guarda de um só. De outro modo como parte de um colégio e, então, a todo o colégio
é preposto um só homem, como guarda, ao qual pertence tomar providência sobre o que diz respeito a
cada homem, em dependência de todo o colégio; assim, sobre as obras exteriores, em relação às quais
uns são edificados e outros escandalizados. Os anjos porém são delegados como guardas dos homens,
mesmo quanto ao que é invisível e oculto, que diz respeito à salvação de cada um em si mesmo. Por
onde, a cada homem é delegado, como guarda, um anjo.

RESPOSTA À SEGUNDA. – Como já se disse, todos os anjos da primeira hierarquia, quanto a certas
cousas, são iluminados por Deus imediatamente; mas só os superiores são assim iluminados, quanto a
outras cousas, que revelam aos inferiores. E o mesmo se deve dizer em relação às ordens inferiores.
Pois, qualquer anjo ínfimo é iluminado, quanto a certas coisas, por –algum dos supremos, e quanto a
outras, por aquele que lhe é imediatamente superior. E, assim, é possível que um anjo, iluminando
imediatamente o homem, seja também superior a outros anjos, que ilumina.

RESPOSTA À TERCEIRA. – Embora os homens sejam iguais, por natureza, contudo a desigualdade neles
existe por serem ordenados pela divina Providência uns para coisas maiores e outros, para menores;
conforme aquilo da Escritura: Pela grandeza da sua sabedoria, o Senhor distingui–os: a uns abençoou e
exaltou; a outros amaldiçoou e humilhou. E, assim, maior ofício é guardar antes um homem que outro.

## Art. 3 — Se guardar os homens pertence só à Ínfima ordem dos anjos.
O terceiro discute–se assim. – Parece que guardar os homens não pertence só à ínfima ordem dos
anjos.

1. – Pois, como diz Crisóstomo, o passo de Mateus – os seus anjos nos céus – entende–se, não de
quaisquer anjos, mas dos supremos. Logo, estes guardam os homens.

2. Demais. – O Apóstolo diz que os anjos são enviados para exercer o seu ministério a favor daqueles
que hão de receber a herança da salvação; donde resulta que a missão dos anjos se ordena à guarda dos
homens. Ora, cinco ordens são enviadas para ministério externo como já se disse. Logo, todos os anjos
das cinco ordens são delegados à guarda dos homens.

3. Demais. – Para a guarda dos homens é preciso sobretudo afastar os demônios, o que pertence às
Potestades, segundo Gregório; e fazer milagres, o que pertence às Virtudes. Logo, também estas ordens,
e não só as ínfimas, são delegadas para a guarda.
Mas, em contrário, a guarda dos homens é atribuída aos Anjos da ordem ínfima, segundo Dionísio.

SOLUÇÃO. – Como já se disse, de dois modos se exerce a guarda, em relação ao homem. – Uma é a
guarda particular, pela qual a cada homem é delegado um anjo da guarda. E esta guarda pertence à
ordem ínfima dos anjos, que devem, segundo Gregório, anunciar as coisas mínimas; ora, o que é
mínimo, nas funções dos anjos, é buscar o que leva cada homem à salvação. – Outra, porém é a guarda
universal; e esta se multiplica pelas diversas ordens; pois quanto mais universal for o agente tanto mais
superior será. Assim, a guarda da multidão humana pertence à ordem dos Principados; ou talvez à dos
Arcanjos, chamados príncipes dos anjos, sendo por isso Miguel, a que chamamos Arcanjo, considerado
um dos primeiros príncipes. Depois sobre todas as naturezas corpóreas exercem guarda as Virtudes. Em
seguida, também sobre os demônios exercem guarda as Potestades. E por fim, ulteriormente, sobre os
bons espíritos, as Dominações, ou Principados, segundo Gregório.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. As palavras de Crisóstomo podem se!, entendidas como
referentes aos mais elevados, na ordem ínfima dos anjos; porque, como Dionísio diz, em qualquer
ordem há primeiros, médios e últimos. Ora, é provável que os anjos maiores são delegados para a
guarda dos que foram escolhidos por Deus para maior grau de glória.

RESPOSTA À SEGUNDA. – Nem todos os anjos enviados exercem guarda especial sobre cada homem;
mas, certas ordens têm guarda mais universal maior ou menor, como se disse.

RESPOSTA À TERCEIRA. – Mesmo os anjos inferiores exercem os ofícios dos superiores, enquanto em
algo lhes participam dos dons deles, e estão para estes como executores da sua virtude. E deste modo;
também todos os anjos da ínfima ordem podem tanto afastar os demônios como fazer milagres.

## Art. 4 — Se a todos os homens são delegados anjos da guarda.
O quarto discute–se assim. – Parece que nem a todos os homens são delegados anjos da guarda.

1. – Pois, a Escritura, diz que Cristo é semelhante aos homens, e reconhecido por condição, como
homem. Se pois a todos os homens fossem delegados anjos da guarda, também Cristo teria o seu anjo
custódio. Ora, isto é inconveniente, porque Cristo é maior que todos os anjos. Logo, nem a todos os
homens são delegados anjos da guarda.

2. Demais. – Adão foi o primeiro de todos os homens. Ora, ele não precisava de nem anjo custódio, ao
menos no estado de inocência, porque então a nenhum perigo estava exposto. Logo, os anjos não são
prepostos como guardas a todos os homens.

3. Demais. – Os anjos são delegados como guardas aos homens, para que os conduzam à vida eterna,
incitem–nos a bem agir e os defendam contra os ataques dos demônios. Ora, os homens predestinados
à condenação nunca chegarão à vida eterna; e também os infiéis, embora por vezes façam obras boas,
contudo não as fazem bem, porque agem sem reta intenção; pois, a fé dirige a intenção, como diz
Agostinho. E por fim, o Anticristo virá por obra de Satanás, como diz a Escritura. Logo, nem a todos os
homem são deputados anjos da guarda.
Mas, em contrário, é a autoridade aduzida, de Jerônimo, que diz: cada alma tem um anjo da guarda que
lhe é delegado.

SOLUÇÃO. – O homem, colocado no estado da vida presente, está como na via, que conduz à pátria.
Ora, nessa via está ele exposto a muitos perigos, interiores e exteriores, conforme a Escritura: No
caminho por onde eu andava, esconderam–me o laço. E por isso, assim como se dão guardas aos
homens que andam por caminho não seguro, assim a cada homem, enquanto viandante, é delegado um
anjo da guarda. Quando, porém já tiver chegado ao termo do caminho, não mais terá cada um o anjo
custódio; mas sim, no céu, um anjo correinante e, no inferno, um demônio punidor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Cristo, enquanto homem, sendo regido imediatamente
pelo Verbo de Deus, não precisava da guarda dos anjos. E, demais, era, pela alma, compreensor; mas
era, em razão da passibilidade do corpo, viandante. E por isso, não lhe era devido, nenhum anjo
custódio como superior, mas antes um anjo ministrante, como inferior. Por onde, diz a Escritura: Os
anjos se aproximaram, e o serviam.

RESPOSTA À SEGUNDA. – O homem, no estado de inocência, não corria nenhum perigo interior, porque
interiormente tudo estava ordenado, como antes se disse. Mas corria perigos exteriores, por causa das
insídias dos demônios, como o provaram os acontecimentos posteriores. E por isso precisava da guarda
dos anjos.

RESPOSTA À TERCEIRA. – Os predestinados à condenação, os infiéis e também o Anticristo, não estando
privados do auxílio interior da razão natural, não estão privados também do auxílio exterior concedido
por Deus a toda a natureza humana e que é a guarda dos anjos. E esta guarda, embora não os ajude
para merecerem, por boas obras, a vida eterna, ajuda–nos contudo a fugir de certos males, pelos quais
podem prejudicar a si mesmos e aos outros, pois, os próprios demónios são afastados pelos bons anjos,
para que não façam tanto mal quanto querem. E semelhantemente o Anticristo não fará o mal que
quiser.

## Art. 5 — Se o anjo é delegado para guardar o homem, desde o nascimento deste.
O quinto discute–se assim – Parece que o anjo não é delegado, para guardar o homem desde o
nascimento deste.

1. – Pois, os anjos são mandados em ministério, a favor daqueles que hão de receber a herança da
salvação, como diz o Apóstolo. Ora, os homens começam a receber a herança da salvação, quando
batizados. Logo, o anjo é delegado para guardar o homem, desde o tempo do baptismo e não desde o
do nascimento.

2. Demais. – Os homens são guardados pelos anjos, enquanto estes os iluminam pela doutrina. Ora, os
recém–nascidos não são capazes de doutrina por não terem o uso da razão. Logo, não lhes são
delegados anjos da guarda.

3. Demais. – As crianças no ventre materno têm, depois de certo tempo, alma racional, bem como a têm
depois da natividade. Ora, enquanto no ventre materno, não lhes são delegados anjos da guarda, como
se sabe, porque os ministros da Igreja ainda não lhes comunicaram os sacramentos. Logo, não são
delegados aos homens anjos da guarda imediatamente depois do nascimento.
Mas, em contrário, diz Jerônimo, que cada alma, imediatamente depois de nascida, tem um anjo da
guarda que lhe é deputado.

SOLUÇÃO. – Como diz Orígenes há, sobre este assunto, dupla opinião. Assim, uns ensinam que o anjo é
dado ao homem, como guarda, desde o tempo dó batismo. Outros porém que desde o tempo do
nascimento. E esta opinião Jerónimo a aprova, e com razão. Pois, os benefícios dados ao homem por
Deus, desde que é cristão, começam do tempo do baptismo, como receber a Eucaristia e outros. Ora o
que a Providência divina dá ao homem, desde que este tem natureza racional, ele o recebe desde que
ao nascer tem tal natureza. E tal benefício é a guarda dos anjos, como resulta claro do que já foi dito.
Por onde, desde a sua natividade, o homem tem um anjo da guarda, que lhe é deputado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os anjos são enviados em ministério eficaz só quanto
aqueles que hão de receber a herança da salvação, se se considerar o efeito último da guarda que é o
recebimento da herança. Contudo, também os outros não são privados desse ministério. Pois embora
este não tenha a eficácia de os levar à salvação, é todavia eficaz, pelos livrar de muitos males.

RESPOSTA À SEGUNDA. – A função de guardar se ordena à iluminação da doutrina como ao último e
principal efeito. Contudo, tem também muitos outros efeitos, que convêm às crianças, a saber, afastar
os demônios e livrar de outros males, tanto corpóreos como espirituais.

RESPOSTA À TERCEIRA. – Enquanto no ventre materno, a criança não está totalmente separada da mãe,
sendo por uma como ligação ainda algo dela, assim como o fruto pendente é algo da árvore. E por isso
pode–se provavelmente dizer que o anjo que guarda a mãe guarda a prole existente no ventre materno.
Mas, ao separar–se da mãe, pela natividade, é–lhe deputado um anjo da guarda, como diz Jerônimo.

## Art. 6 — Se o anjo da guarda às vezes abandona o homem para cuja guarda foi deputado.
O sexto discute–se assim. – Parece que o anjo da guarda às vezes abandona o homem à cuja guarda
foi deputado.

1. – Pois, diz a Escritura falando da pessoa dos anjos: Medicamos Babilônia, e ela não sarou, deixemo–la
– e, noutro passo: Arancar–lhe–ei a sebe, e ficará exposta ao roubo; e diz a Glossa, que isso se refere à
guarda dos anjos.

2. Demais. – Deus guarda mais que o anjo. Ora, ele às vezes abandona o homem conforme está na
Escritura: Ó Deus, Deus meu, olha para mim; porque me desamparaste? Logo, com maior razão o anjo
da guarda abandona o homem.

3. Demais. Como diz Damasceno, os anjos, estando conosco, neste mundo, não estão no céu. Ora, como
às vezes estão no céu, às vezes nos abandonam.
Mas, em contrário. – Os demónios sempre nos atacam, conforme a Escritura: O demônio, vosso
adversário, anda ao redor de vós como um leão que ruge, buscando a quem devorar. Logo, com maior
razão, os bons anjos sempre nos guardam.

SOLUÇÃO. – A guarda dos anjos, como do sobredito se colhe, é uma execução da divina Providência
relativa aos homens. Ora, é manifesto que nem o homem nem ser algum pode subtrair–se totalmente à
divina Providência; pois, na medida em que um ente participa da existência nessa mesma está sujeito à
providência universal dos seres. Diz–se, porém que Deus, conforme a ordem da sua Providência,
abandona o homem, na medida em que permite que este padeça alguma deficiência, quanto à pena ou
à culpa. E semelhantemente, deve–se dizer que o anjo da guarda nunca abandona totalmente o
homem; mas às vezes, o abandona na medida em que não impede entre em alguma tribulação, ou
mesmo caia em pecado, conforme à ordem dos juízos divinos. E neste sentido, se diz que Babilónia e a
casa de Israel foram abandonadas dos anjos, porque os seus anjos da guarda não as livraram de caírem
em tribulações.
E daqui se deduzem as RESPOSTAS À PRIMEIRA E SEGUNDA OBJEÇÕES.

RESPOSTA À TERCEIRA. – Embora o anjo abandone às vezes o homem, localmente, não o abandona,
contudo quanto ao efeito da guarda; porque, mesmo quando está no céu, sabe o que deve fazer em
relação ao homem; nem precisa de intervalo de tempo para locomover–se, mas pode estar presente
imediatamente.

## Art. 7 — Se os anjos se contristam com os males dos que guardam.
(II Sent., dist., XI, part. I, a. 5).
O sétimo discute-se assim. — Parece que os anjos se contristam com os males dos que guardam.

1. — Pois, diz a Escritura: Os anjos da paz chorarão amargamente. Ora, o pranto é sinal de dor e de
tristeza. Logo, os anjos se contristam com os males dos homens que guardam.

2. Demais. — Como diz Agostinho, a tristeza provém do que nos acontece contra a nossa vontade. Ora,
a perdição de um homem é contra a vontade do seu anjo da guarda. Logo,os anjos se contristam com a
perdição dos homens.

3. Demais. — Como a tristeza é contrária à alegria, assim o pecado, à penitência. Ora, os anjos se
alegram com o pecador penitente, como se lê no Evangelho. Logo, se contristam quando o justo cai em
pecado.

4. Demais. — Ao passo da Escritura — E tudo o que oferecem como primícias, diz a Glossa de Orígenes:
Os anjos são levados a juízo, porque caíram, quer por negligência deles, quer por ignávia dos homens.
Mas é racional que a gente sofra por causa dos males pelos quais é levado a juízo. Logo, os anjos se
condoem com os pecados dos homens.
Mas, em contrário. — Onde há tristeza e dor não há perfeita felicidade; por isso, diz o Apocalipse: E não
haverá mais morte, nem luto, nem clamor, nem mais dor. Ora, os anjos são perfeitamente felizes. Logo,
de nada se condoem.

SOLUÇÃO. — Os anjos não se condoem com os pecados nem com as penas dos homens, pois, a tristeza
e a dor procedem, como diz Agostinho, do que contraria à vontade. Ora, nada acontece no mundo
contrário à vontade dos anjos e dos outros bem-aventurados, porque a vontade deles adere totalmente
à ordem da divina justiça, e nada há no mundo que não seja feito ou permitido por essa justiça. Por
onde, absolutamente falando, nada acontece no mundo, contra a vontade dos bem-aventurados. Pois,
como diz o Filósofo, chama-se voluntário absolutamente, ao que alguém quer, em particular, quando
age, i. é, consideradas todas as circunstâncias, embora considerado em universal, não fosse voluntário.
Assim, o nauta não quer que as mercadorias sejam atiradas ao mar, absoluta e universalmente falando,
mas o quer, estando em risco eminente de perder-se; e por isso há aqui, antes, um voluntário do que
um involuntário, como no mesmo passo se diz. Por onde, os anjos, universal e absolutamente falando,
não querem os pecados e as penas dos homens; querem contudo que, por elas, se conserve a ordem da
divina justiça, que submete certos a penas e permite que pequem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras citadas de Isaías podem-se entender como
referentes aos anjos anunciadores de Ezequías, que choraram, conforme o sentido literal, por causa das
palavras de Rapsaco, de que se trata no mesmo livro. Pelo sentido alegórico porém, os anjos são
apóstolos e pregadores da paz, que choram sobre os pecados dos homens. Se porém, pelo sentido
anagógico, o passo se refere aos anjos bons, então o modo de falar é metafórico, para significar que eles
querem, em universal, a salvação dos homens. Pois, é assim que tais paixões se atribuem a Deus e aos
anjos.

RESPOSTA À SEGUNDA. — Resulta clara a SOLUÇÃO. do que acaba de ser dito.

RESPOSTA À TERCEIRA. — Tanto na penitência como no pecado dos homens, há razão para alegria dos
anjos, que é o implemento da ordem da divina providência.

RESPOSTA À QUARTA. — Os anjos são levados a juízo, por causa dos pecados dos homens, não como
réus, mas como testemunhas, para convencer os homens da ignávia própria.

## Art. 8 — Se entre os anjos pode haver luta ou discórdia.
O oitavo discute–se assim. – Parece que entre os anjos não pode haver luta nem discórdia.

1. – Pois, diz a Escritura: que mantém a concórdia nas suas alturas. Ora, a luta se opõe à concórdia.
Logo, entre os anjos sublimes não há luta.

2. Demais. – Onde há perfeita caridade e justa superioridade não pode haver luta. Ora, assim é entre os
anjos. Logo, não pode entre eles haver luta.

3. Demais. – Se se disser que os anjos lutam pelos que guardam, necessário é que um anjo favoreça uma
parte e outro, outra. Ora, se com uma está a justiça, com outra estará a injustiça. Donde resulta que um
anjo bom será fautor da injustiça, o que é inadmissível. Logo, entre os bons anjos não há luta.
Mas, em contrário, diz a Escritura, da pessoa de Gabriel: O príncipe do reino dos Persas resistiu–me
durante vinte e um dias. Ora, esse príncipe dos Persas era um anjo deputado à guarda do remo persa.
Logo, um anjo resiste a outro e, portanto, há entre eles luta.

SOLUÇÃO. – Esta questão foi suscitada a propósito das palavras de Daniel, que acabamos de citar. – E
Jerónimo as explica, dizendo que o príncipe do reino dos Persas era um anjo, que se opunha à libertação
do povo de Israel, pelo qual Daniel orava, sendo a sua oração apresentada a Deus por Gabriel. E tal
oposição podia ter–se dado, porque algum príncipe dos demónios tivesse induzido a pecado os judeus,
levados para a Pérsia, o que era um obstáculo à oração de Daniel, pelo mesmo povo. – Mas, segundo
Gregório, o príncipe do reino dos Persas era um anjo bom, deputado à guarda desse reino. – Para com
prender–se porém como um anjo pode resistir a outro, deve–se considerar, que os juízos divinos
relativos aos diversos reinos e aos diversos homens executam–se pelos anjos. Ora, embora, estes, nas
suas ações, rejam–se pela ordem divina, acontece às vezes que, relativamente aos diversos reinos ou
aos diversos homens, existem méritos ou deméritos contrários de modo que um é inferior ou superior a
outro. Como porém, não podem saber porque a ordem da divina Sapiência determinou assim, sem que
Deus lhos revele, têm os anjos necessidade de consultar essa sabedoria. Assim pois, enquanto
consultam a divina vontade, sobre os méritos contrários e que se lhes opõem, diz–se que resistem uns
aos outros; não que tenham vontades contrárias, pois são todos concordes em, cumprir a ordem de
Deus, mas porque são opostas as coisas sobre que consultam.
Donde se deduzem as RESPOSTAS ÀS OBJEÇÕES.