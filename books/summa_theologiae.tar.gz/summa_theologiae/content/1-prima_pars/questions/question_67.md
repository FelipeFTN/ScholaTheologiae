# Questão 67: Da obra da distinção em si mesma.
Em seguida, devemos tratar da obra da distinção em si mesma. E, primeiramente, da obra do primeiro
dia. Segundo, da do segundo. Terceiro, da do terceiro.
Sobre o primeiro ponto quatro artigos se discutem.

## Art. 1 — Se a luz se atribui, propriamente, aos seres espirituais.
O primeiro discute-se assim. — Parece que a luz se atribui, propriamente, aos seres espirituais.

1. — Pois, Agostinho diz que a luz é melhor e mais certa, nos seres espirituais; e que de Cristo não se diz
que é luz, do mesmo modo que é pedra; senão, luz, própria, e, pedra, figuradamente.

2. Demais. — Dionísio coloca a luz entre os nomes explicativos de Deus. Ora, estes nomes se predicam,
propriamente, dos seres espirituais. Logo, a luz se predica destes seres, propriamente.

3. Demais. — O Apóstolo diz: Porque tudo o que se manifesta é luz. Ora, a manifestação mais
propriamente se atribui aos seres espirituais que aos corporais. Logo, também a luz.
Mas, em contrário, Ambrósio coloca o esplendor entre as coisas que se dizem de Deus metaforicamente.

SOLUÇÃO. — Pode-se considerar qualquer nome de duplo ponto de vista: segundo a sua imposição
primeira e segundo o seu uso. Assim é claro que o nome de visão, primeiramente imposto para significar
o ato do sentido da vista, foi, por causa da dignidade e da certeza desse sentido, estendido, pelo uso,
não só a todo o conhecimento dos outros sentidos — sendo por isso que dizemos: vede como sabe, ou
como cheira, ou como é cálido; mas, ainda ulteriormente, ao conhecimento do intelecto, segundo a
expressão da Escritura: Bem-aventurados os puros de coração, porque verão a Deus. E
semelhantemente, deve-se dizer o mesmo do vocábulo luz, imposto, primeiramente, para significar a
causa da manifestação, no sentido da vista; e estendido, em seguida, para significar tudo o que causa a
manifestação, em qualquer conhecimento. Se, pois, se considerar tal nome na sua imposição primeira, a
luz se atribui metaforicamente aos seres espirituais, como ensina Ambrósio. Se, porém, for considerado
conforme o uso corrente e estendendo-se a todas as manifestações, então predica-se propriamente dos
seres espirituais.
Donde se deduzem claras as RESPOSTAS ÀS OBJEÇÕES.

## Art. 2 — Se a luz é corpo.
O segundo discute-se assim. — Parece que a luz é corpo.

1. — Pois, Agostinho diz que a luz tem o primeiro lugar entre os corpos. Logo, é corpo.

2. Demais. — O Filósofo diz que a luz é uma espécie de fogo. Ora, este é corpo. Logo, a luz é corpo.

3. Demais. — Ser transportado, entrecortado e refletido são propriedade dos corpos. Ora, todas essas
propriedades, que só aos corpos convém, se atribuem à luz ou aos seus raios, pois, os diversos raios se
conjugam ou separam, como diz Dionísio, o que também só aos corpos pode convir. Logo, a luz é corpo.
Mas, em contrário, dois corpos não podem estar simultaneamente no mesmo lugar. Ora, a luz está no
mesmo lugar, simultaneamente com o ar. Logo, não é corpo.

SOLUÇÃO. — Que é impossível a luz seja corpo, de tríplice modo se prova. O primeiro argumento é
tirado do lugar. Pois o lugar de um corpo não é o de outro; nem é naturalmente possível estejam dois
corpos quaisquer simultaneamente no mesmo lugar, porque o contíguo exige situação distinta.
Em segundo lugar, o mesmo resulta da natureza do movimento. Se, pois, a luz fosse corpo, a iluminação
seria o movimento local do corpo. Ora, nenhum movimento dessa espécie pode ser instantâneo, porque
tudo o que se move localmente deve chegar ao meio do espaço a percorrer, antes de chegar ao fim.
Ora, a iluminação é instantânea e nem se pode dizer que se realize num tempo imperceptível.
Porquanto, se num espaço pequeno, o tempo nos escapasse, o mesmo não se daria num grande espaço,
p. ex., o que meia entre o oriente e o ocidente. Ora, assim que o sol nasce num ponto do oriente,
ilumina-se todo o hemisfério, até o ponto oposto. — Mas ainda há outra consideração a fazer, quanto
ao movimento, a saber. Todo corpo tem um movimento natural determinado; ora, o movimento da
iluminação se opera em todas as direções, sem que seja antes circular que reto. Por onde, é manifesto
que a iluminação não é o movimento local de nenhum corpo.
Em terceiro lugar, o mesmo resulta da geração e da corrupção. Pois, se a luz fosse corpo, resultaria que
este se corromperia e a sua matéria receberia outra forma, quando o ar se entenebrece, por ausência
da luz. O que não se dá, a menos que não se considerem também as trevas como corpo. E nem ainda se
compreenderia de que matéria fosse gerado esse corpo imenso que quotidianamente enche meio
hemisfério. E seria também ridículo dizer-se que ele se corrompe unicamente pela ausência de luz. E se
dissermos que não se corrompe, mas nasce e move-se em círculo, simultaneamente com o sol, o que se
há de opor ao fato de obscurecer-se toda a casa pela só interposição de um corpo contra a candeia? E
nem se diga que a luz se congrega em torno da candeia, porque não era antes aí maior do que agora a
claridade. Ora, como todos esses fatos repugnam não só à razão, mas também aos sentidos, conclui-se
que é impossível a luz ser corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho entende por luz o corpo atualmente lúcido,
isto é, o fogo, o nobilíssimo dos quatro elementos.

RESPOSTA À SEGUNDA. — Aristóteles denomina luz ao fogo, na sua matéria própria; assim como o
fogo, na matéria aérea, se denomina chama, e, na térrea, carvão. Todavia, não se ligue muita
importância aos exemplos dados por Aristóteles nos tratados de lógica, porque os apresenta como
prováveis, segundo a opinião dos outros.

RESPOSTA À TERCEIRA. — Tais propriedades se atribuem todas à luz, metaforicamente, como também
se podem atribuir ao calor. Pois, sendo o movimento local naturalmente o primeiro dos movimentos,
como prova o Filósofo, aplicamos os nomes próprios a esse movimento local, à alteração e a todos os
movimentos; assim como também o nome de distância, derivado do lugar, se aplica a todos os
contrários, como diz Aristóteles.

## Art. 3 — Se a luz é qualidade.
O terceiro discute-se assim. — Parece que a luz não é uma qualidade.

1. — Pois, toda qualidade permanece no sujeito, mesmo depois de ter o agente desaparecido; p. ex., o
calor conserva-se na água ainda depois de afastado o fogo. Ora, retirado o foco luminoso, a luz não
permanece no ar. Logo, não é uma qualidade.

2. Demais. — Toda qualidade sensível tem o seu contrário; assim o quente e o frio, o branco e o preto.
Mas à luz nada é contrário, pois as trevas são a privação dela. Logo, a luz não é uma qualidade sensível.

3. Demais. — A causa é mais poderosa que o efeito. Ora, a luz dos corpos celestes causa as formas
substanciais nos seres inferiores terrestres, pois é a que dá o ser espiritual às cores, tornando-as
atualmente visíveis. Logo, a luz não é uma qualidade sensível, mas antes, uma forma substancial ou
espiritual.
Mas, em contrário, Damasceno diz que a luz é uma qualidade.

SOLUÇÃO. — alguns disseram que a luz, no ar, não tem o ser natural, como, p. ex., a cor não o tem na
parede; mas o ser intencional, como p. ex., a semelhança da cor, no ar. — Mas isto não pode ser, por
duas razões. Primeiro, porque a luz qualifica o ar, tornando-o atualmente luminoso. Porém a cor não o
qualifica, pois não se diz que o ar é colorido. Segundo, porque a luz produz um efeito natural, pois, com
os raios do sol aquecem-se os corpos; ao passo que as intenções não produzem transmutações naturais.
Outros, porém, disseram que a luz é a forma substancial do sol. — Mas também essa opinião é
inadmissível, por duas razões. Primeiro, porque nenhuma forma substancial é, por si mesma, sensível;
pois, a quididade é o objeto do intelecto, como diz Aristóteles, e a luz é, em si, visível. Segundo, porque
é impossível seja a forma substancial, em um ser, acidental em outro; pois, sendo próprio da forma
substancial, por si mesma, constituir a espécie, sempre e em todos os seres ela vai junto com esta. Ora,
a luz não é a forma substancial do ar, pois do contrário este se corromperia com a ausência daquela.
Logo, não pode ser a forma substancial do sol.
Deve-se, portanto, dizer que, assim como o calor é uma qualidade ativa, resultante da forma substancial
do fogo; assim a luz é uma qualidade ativa resultante da forma substancial do sol ou de qualquer outro
corpo por si lúcido, se porventura existe. E a prova é que os raios das diversas estrelas têm diversos
efeitos segundo as naturezas diversas dos corpos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Resultando a qualidade da forma substancial, conforme
o sujeito se comporta no receber a qualidade, assim mesmo se comportará no receber a forma.
Quando, pois, a matéria já recebeu a forma, perfeitamente, também firmemente fica estabelecida a
qualidade resultante da forma; assim, p. ex., se a água se convertesse em fogo. Porém, se a forma
substancial foi recebida imperfeita e como incoativa, a qualidade resultante permanece, por certo, por
algum tempo, mas não sempre; como bem se vê na água aquecida, que torna à sua natureza. Ora, a
iluminação não se opera por nenhuma transmutação da matéria, para receber a forma substancial,
como se se operasse alguma incoação desta; por onde, a luz não permanece senão enquanto
permanece o agente.

RESPOSTA À SEGUNDA. — É acidentalmente que a luz não tem contrário, como qualidade natural que é
do primeiro corpo alterante, que escapa à contrariedade.

RESPOSTA À TERCEIRA. — Assim como o calor produz a forma do fogo, quase instrumentalmente, em
virtude da forma substancial; assim a luz age, quase instrumentalmente, em virtude dos corpos celestes,
para produzir as formas substanciais e para tornar as cores atualmente visíveis, enquanto qualidade que
é do primeiro corpo sensível.

## Art. 4 — Se convenientemente a produção da luz se coloca no primeiro dia.
O quarto discute-se assim. — Parece que não se coloca convenientemente a produção da luz no
primeiro dia.

1. — Pois, sendo a luz uma qualidade, como já se disse, e sendo a qualidade um acidente, esta não é,
por natureza, um ser primeiro, mas segundo. Logo, não se deve colocar no primeiro dia a produção da
luz.

2. Demais. — Pela luz se distingue a noite, do dia; e esta é a função do sol, que se considera como feito
no quarto dia. Logo, não se deve colocar a produção da luz no primeiro dia.

3. Demais. — A noite e o dia resultam do movimento circular do corpo lúcido. Ora, o movimento circular
é próprio do firmamento, do qual se lê que foi feito no segundo dia. Logo, não se deve colocar no
primeiro dia a produção da luz, que distingue as noites e os dias.

4. Demais. — Se se disser que se trata da luz espiritual, responde-se, em contrário, que a luz da qual se
lê ter sido criada no primeiro dia, distingue-se das trevas. Ora, não havia, no princípio, trevas espirituais,
pois, mesmo os demônios eram, então, bons, como antes se disse. Logo, não se deve colocar no
primeiro dia a produção da luz.
Mas, em contrário. Era necessário fosse criado no primeiro dia aquilo sem o que não pode existir o dia.
Ora, este não pode existir sem a luz. Loo, era necessário se fizesse a luz no primeiro dia.

SOLUÇÃO. — Há duas opiniões sobre a produção da luz. — Agostinho opina que não pareceu
conveniente a Moisés ter calado a produção da criatura espiritual. Assim, quando diz: No princípio criou
Deus o céu e a terra, por céu — explica Agostinho — se entende a criatura espiritual ainda informe;
por terra, porém, a matéria informe da criatura corporal. E por ser mais digna que a corporal, a natureza
espiritual foi formada antes. Por isso, a formação da natureza espiritual foi significada pela produção da
luz, entendendo-se esta como espiritual. Pois, a formação da natureza espiritual está em ser iluminada,
para aderir ao Verbo de Deus.
Outros porém são de opinião que Moisés omitiu a produção da criatura espiritual; mas aduzem razões
diferentes. — Assim, Basílio diz que Moisés começou a sua narração, desde o princípio temporal das
coisas sensíveis; mas a natureza espiritual i. é, angélica, a omitiu, porque foi criada antes. — Crisóstomo,
porém, dá outra razão. Moisés falava a um povo rude, capaz de apreender só o corporal, e queria fazê-
lo abandonar a idolatria. Ora, dar-lhes-ia ocasião à ela, se lhes falasse em quaisquer substâncias
superiores a todas as criaturas corpóreas; pois as tomariam como deuses, inclinados que já eram a
adorar, desse modo, o sol, a luz e as estrelas, o que lhes proíbe a Escritura.
Porém, Moisés já tinha-se referido a criatura corporal como constituída em multíplice informidade. Uma
a exprimiu dizendo: A terra, porém, estava informe e vazia; outra: E as trevas cobriam a face do abismo.
— Ora, era necessário que, primeiramente, fosse removida a informidade das trevas, pela produção da
luz, por duas razões. — Primeira, porque sendo a luz, como já se disse, uma qualidade do primeiro
corpo, por ela devia começar o mundo a ser formado. Segunda, porque, pela sua comunidade, a luz faz
com que possam os corpos inferiores comunicar com os superiores Pois, assim como no conhecimento
partimos dos seres mais comuns, assim também na operação; por isso o ser vivo é gerado antes do
animal, que o é antes do homem, como diz Aristóteles. Por onde, a ordem da divina sabedoria devia
manifestar-se de modo a, entre as obras da distinção, ser produzida a luz como forma do primeiro
corpo, e como a mais comum. — Basílio acrescentou, contudo, terceira razão, convém saber que, por
meio da luz, se manifestam todos os demais seres. — Mas ainda pode-se acrescentar uma quarta, que já
se referiu numa das objeções, convém saber: não podendo haver dia sem luz, era necessário fosse essa
feita no primeiro dia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Segundo a opinião que ensina ter a informidade da
matéria precedido, na duração, à formação, necessário é dizer-se que a matéria foi, no princípio, criada
em união com as formas substanciais; sendo depois formada segundo algumas condições acidentais,
entre as quais tem a luz o primeiro lugar.

RESPOSTA À SEGUNDA. — Alguns dizem que essa luz era uma nuvem lúcida, que, após a criação do sol,
voltou à matéria preexistente. Mas isto não é admissível, porque a Escritura, no princípio do Gênesis,
comemora a instituição da natureza, que a seguir perseverou. Por onde, não se pode dizer que foi então
produzida alguma coisa, que depois deixou de ser. — Por isso, outros dizem que essa nuvem lúcida
ainda subsiste unida com o sol, de modo a não poder ser separada dele. Mas nesta suposição tal nuvem
seria supérflua; ora, nada é vão nas obras de Deus. — Por onde, outros dizem que dessa nuvem se
formou o corpo do sol. Mas ainda isto não se pode admitir, se se admite que o corpo do sol não é da
natureza dos quatro elementos, mas é incorruptível por natureza; pois então, a sua matéria não pode se
unir a outra forma.
A verdade, portanto, é, como pensa Dionísio, que tal luz era a do sol, embora ainda informe, por já ser
ela da substância do mesmo e ter a virtude iluminativa, em comum; mas em seguida foi-lhe dada, a essa
luz, uma especial e determinada virtude para um efeito particular. Assim que, conforme esta opinião,
houve na criação de tal luz uma tríplice distinção entre a luz e as trevas. Primeiro, quanto à causa,
estando a da luz na substância do sol, e a das trevas, na opacidade da terra. Segundo, quanto ao lugar,
estando a luz em um hemisfério e as trevas, no outro. Terceiro, quanto ao tempo, estando, no mesmo
hemisfério, a luz, numa parte do tempo, e as trevas, em outra. E é isto que significa o dito: Chamou à luz
dia, e às trevas noite.

RESPOSTA À TERCEIRA. — Basílio diz que a luz e as trevas existiram, então, pela emissão e contração da
luz, e não pelo movimento. — Mas Agostinho objeta, em contrário, que nenhuma razão havia para essa
vicissitude de emitir-se e retrair-se a luz, por não existirem homens e animais, a cujos usos isso serviria.
E demais, não pode a natureza do corpo lúcido retrair a luz, enquanto presente, senão
miraculosamente. Ora, na instituição primeira da natureza, não se busca o milagre, senão o que está em
a natureza das coisas, como diz Agostinho.
Por onde, deve-se dizer que é duplo o movimento, no céu: um, comum a todo céu, causa do dia e da
noite, e esse foi instituído no primeiro dia; outro, porém, diversificado pelos diferentes corpos, e causa
das diversidades dos dias, entre si, dos meses e dos anos. E por isso, no primeiro dia, menciona-se só a
distinção da noite e do dia, causada pelo movimento comum; porém, no quarto, menciona-se a
diversidade dos dias, dos tempos e dos anos, quando se diz: Para os tempos, os dias e os anos; e essa
diversidade se opera pelos movimentos próprios.

RESPOSTA À QUARTA. — Segundo Agostinho, a informidade não precedeu à formação, quanto à
duração. Por onde, é necessário dizer-se que, pela produção da luz se entende a da criatura espiritual;
não a criatura espiritual perfeita pela glória, pois, com esta não foi criada a luz, mas a perfeita pela
graça, com a qual, como já se disse, foi a luz criada. — Assim, por tal luz se operou a separação das
trevas, isto é, da informidade da outra criatura não formada. — Ou, se todas as criaturas foram criadas
simultaneamente, distinguia-se a luz das trevas espirituais, ainda não existentes, porque o diabo não foi
criado mau; mas Deus as previa como futuras.