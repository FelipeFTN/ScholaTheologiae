# Questão 51: Da relação dos anjos com os corpos.
Em seguida se trata dos anjos por comparação com os seres corpóreos. E, primeiro, da relação dos anjos
com os corpos. Segundo, da relação dos anjos com os lugares corpóreos. Terceiro, da relação dos anjos
com o movimento local.
Sobre o primeiro ponto três artigos se discutem:

## Art. 1 — Se os anjos estão naturalmente unidos a corpos.
(I Sent., dist. VIII, a. 1; II Cont. Gent., cap. XCI; De Pot. q. 6, a. 6; De Malo. q. 16, a. 1; De Spirit. Creat., a.
5; Opusc. XV, De Angelis, cap. XVIII)
O primeiro discute-se assim. — Parece que os anjos estão naturalmente unidos a corpos.

1. — Pois, diz Orígenes: só da natureza de Deus, i.é., do Padre, do Filho e do Espírito Santo, pode-se
entender que é próprio o existir sem substância material e sem nenhuma mistura de corpo. — Bernardo
também diz:Concedamos só a Deus tanto a imortalidade como a incorporeidade, do qual, somente, a
natureza, nem por si nem por outro, precisa do ajutório de um instrumento corporal. Pois é claro que
todo espírito criado precisa de tal ajutório. — Agostinho, por fim, diz: Os demônios chamam-se animais
aéreos, porque se ajudam da natureza dos corpos aéreos. Ora a mesma é a natureza do demônio e do
anjo. Logo, os anjos estão naturalmente unidos a corpos.

2. Demais. — Gregóriochama ao anjo animal racional. Ora, todo animal é composto de corpo e alma.
Logo, os anjos estão naturalmente unidos a corpos.

3. Demais. — É mais perfeita a vida dos anjos do que a das almas. Ora, a alma não somente vive, mas
também vivifica o corpo. Logo, os anjos vivificam corpos que lhes estão naturalmente unidos.
Mas, em contrário diz Dionísio que os anjos, compreendidos como incorpóreos, também o devem ser
como imateriais.

SOLUÇÃO. — Os anjos não estão naturalmente unidos a corpos. Pois o que é acidental a uma natureza
não se encontra nela universalmente; assim, ter asas não é da natureza do animal e por isso não
convém a todo animal. Ora, como inteligir não é ato do corpo, nem nenhuma virtude deste — como a
seguir se verá — não é da natureza da substância intelectual como tal, estar unida a um corpo; mas isto
é acidental, por qualquer outra razão, à uma substância intelectual. Assim, à alma humana convém estar
unida a um corpo, por ser imperfeita e potencial, no gênero das substâncias intelectuais, não tendo, por
natureza, a plenitude da ciência, mas tirando-a das coisas sensíveis por meio dos sentidos do corpo,
como a seguir se dirá. Mas havendo, em qualquer gênero, algo de imperfeito, é necessário que, nesse
mesmo gênero, preexista algo de perfeito. Há, portanto, algumas substâncias perfeitas intelectuais, em
a natureza intelectual, que não precisam de tirar a ciência, das coisas sensíveis. Logo, nem todas as
substâncias intelectuais estão unidas a corpos; mas há algumas separadas deles, e a estas chamamos
anjos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como antes já se disse, alguns opinaram que todo ente é
corpo. E considera-se como conseqüência dessa opinião, o terem alguns ensinado que não há nenhumas
substâncias incorpóreas que não estejam unidas a corpos; e portanto, terem alguns afirmado que Deus
é a alma do mundo, como Agostinho refere. Mas, como isto repugna à fé católica, que exalta Deus sobre
todas as coisas, segundo a Escritura (Sl 8, 2) — A tua magnificência se elevou sobre os céu. — Orígenes,
rejeitando tal opinião, no tocante a Deus, seguiu a opinião dos outros, no tocante às outras coisas; assim
como se enganou, em muitos outros assuntos, seguindo a opinião dos antigos filósofos. — E a expressão
de Bernardo pode-se explicar dizendo que os espíritos criados precisam de um instrumento corporal,
não que este lhes esteja naturalmente unido, mas sim que é assumido para algum fim, como a seguir se
dirá. — E quanto a Agostinho, ele não afirma mas usa da opinião dos Platônicos, que ensinavam haver
certos animais aéreos a que chamavam demônios.

RESPOSTA À SEGUNDA. — Gregório chama ao anjo animal racional, metaforicamente, pela semelhança
com a razão.

RESPOSTA À TERCEIRA. — Vivificar, efetivamente, é absolutamente uma perfeição e, por isso, convém a
Deus, segundo a Escritura (1 Rs 2, 6): O Senhor é quem tem a vida e a dá. Mas vivificar, formalmente,
pertence à substância que é parte de alguma natureza e que não tem em si a natureza íntegra da
espécie. Por onde, a substância intelectual não unida a um corpo é mais perfeita que a unida.

## Art. 2 — Se os anjos assumem corpos.
(II Sent., dist, VIII, a. 2; De Pot., q. 6, a. 7)
O segundo discute-se assim. — Parece que os anjos não assumem corpos.

1. — Pois, a operação angélica, como a da natureza, nada tem de supérfluo. Mas tê-lo-ia se os anjos
assumissem corpos, porque o anjo, tendo uma virtude que excede toda virtude corpórea, não precisa de
corpo. Logo, o anjo não assume nenhum corpo.

2. Demais. — O fato de assumir termina em alguma união, pois, assumir é como que tomar para si. Ora,
o corpo não se une ao anjo como à forma, como antes já se disse. Porém, o que se lhe une, como ao
motor, não é assumido; do contrário, resultaria que todos os corpos movidos pelos anjos seriam por
eles assumidos. Logo, os anjos não assumem corpos.

3. Demais. — Os anjos não assumem corpos de terra ou de água, porque não poderiam desaparecer
subitamente; nem de fogo,m porque queimariam as coisas em que tocassem; nem de ar, porque o ar
não é susceptível de figura nem de cor. Logo, os anjos não assumem corpos.
Mas em contrário diz Agostinho que os anjos apareceram a Abraão em corpos assumidos.

SOLUÇÃO. — Alguns disseram que os anjos nunca assumem corpos, e tudo o que se lê na divina
Escritura sobre aparições angélicas, aconteceu em visão profética, isto é, em imaginação. — Mas isto
repugna ao intento da Escritura. Pois, o que é visto por visão imaginaria o é somente na imaginação do
vidente e, por isso, é visto por todos de maneiras diferentes. Ora, na divina Escritura aparecem, por
vezes, anjos vistos igualmente por todos. Assim, os anjos aparecidos a Abraão foram vistos por ele, por
toda a sua família, por Lote e pelos habitantes de Sodoma; semelhantemente, o anjo aparecido a Tobias
foi visto por todos. Por onde é manifesto que tal aconteceu por visão corpórea, pela qual, vendo-se o
que está fora do vidente, isso pode ser visto por todos. Ora, por tal visão, não se vê senão o corpo.
Portanto, como os anjos não são corpos, nem estão naturalmente unidos a estes, como já se viu, resulta
que, às vezes, assumem corpos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os anjos não precisam de um corpo assumido, por si
mesmos, mas por causa de nós; para que, praticando familiarmente com os homens, indiquem-lhes a
sociedade espiritual que estes esperam com eles terão, na vida futura. E o fato de terem os anjos
assumido corpos, no Velho Testamento não foi senão o indício figurativo de que o Verbo de Deus
haveria de assumir um corpo humano; pois, todas as aparições do Antigo Testamento foram ordenadas
a essa aparição, pela qual o Filho de Deus se manifestou encarnado.

RESPOSTA À SEGUNDA. — O corpo assumido está unido ao anjo, não, certo, como à sua forma, nem
somente como ao seu motor, mas como ao motor representado pelo corpo móvel assumido. Pois, assim
como as propriedades das coisas inteligíveis são descritas pela Sagrada Escritura sob semelhanças com
as coisas sensíveis; assim, os corpos sensíveis são formados pelos anjos, mediante a divina virtude, de
modo que sirvam para representar as propriedades inteligíveis deles. E é assim que o anjo assume um
corpo.

RESPOSTA À TERCEIRA. — Embora o ar, pela sua rarefação, não conserve a figura nem a cor, todavia
pode às vezes condensar-se, colorir-se e configurar-se, como se vê nas nuvens. E é assim que os anjos
assumem um corpo aéreo, condensando-o, por virtude divina, quanto for necessário para a formação
do corpo a ser assumido.

## Art. 3 — Se os anjos exercem operações vitais, nos corpos que assumem.
(II Sent., dist. VIII, a. 4; De Pot., q. 6, a. 8)
O terceiro discute-se assim. — Parece que os anjos exercem operações vitais nos corpos que
assumem.

1. — Pois aos anjos não convém nenhuma dissimulação da verdade. Ora, seria dissimulação se o corpo
assumido por eles parecesse vivo, com operações vitais e, na realidade, não o fosse. Logo, os anjos
exercem, no corpo que assumem, operações vitais.

2. Demais. — Nas obras angélicas nada é em vão. Ora, em vão se formariam, no corpo assumido pelo
anjo, olhos, narizes e outros órgãos sensoriais, se ele não sentisse, com esses órgãos. Logo, o anjo sente,
com o corpo assumido; o que é mui propriamente, operação vital.

3. Demais. — Mover-se com movimento progressivo é uma das operações vitais, como se vê em
Aristóteles. Ora, manifestamente os anjos se manifestam movendo-se com os corpos que assumem.
Pois, diz a Escritura (Gn 18, 16), que Abraão ia com eles conduzindo os anjos que lhe apareceram. E
Tobias, ao anjo que lhe perguntava (Tb 5, 7) — Tu sabes o caminho que leva à terra dos Medos? —
responde: Sei, e tenho andado muitas vezes estes caminhos. Logo, os anjos exercem freqüentemente
operações vitais, nos corpos que assumem.

4. Demais. — Falar é operação do ser vivo que se realiza pela voz, som proferido pela boca do animal,
como diz Aristóteles. Ora, é manifesto, em muitos lugares na Escritura, que os anjos falaram pelos
corpos que assumiram. Logo, exercem, nesses corpos, operações vitais.

5. Demais. — Comer é operação própria do animal; por isso, o Senhor, depois da ressurreição, como
prova da vida ressurgida, comeu com os discípulos, como está na Escritura. Ora, certos anjos,
manifestando-se em corpos assumidos, comeram; e Abraão, depois de os haver adorado, ofereceu-lhes
alimentos, como se lê na Escritura (Gn 18). Logo, os anjos exercem operações vitais, nos corpos que
assumem.

6. Demais. — Gerar outro homem é ato vital. Ora, tal convém aos anjos, pelos corpos que assumiram,
pois diz a Escritura (Gn 6, 4): Depois que os filhos de Deus tiveram comercio com as filhas dos homens,
geraram estas filhos que foram homens possantes e afamados no século. Logo, os anjos exercem
operações vitais nos corpos que assumem.
Mas em contrário. — Os corpos assumidos pelos anjos não vivem, como antes já se disse. Logo, nem por
tais corpos podem se exercer operações vitais.

SOLUÇÃO. — Certas operações vitais têm algo de comum com as outras operações; assim, a locução,
operação vital, convém, como som, com os outros sons de seres inanimados; e a marcha, como
movimento, convém com outros movimentos. Ora, os anjos podem, pelos corpos que assumem, exercer
as operações vitais, no que elas têm de comum com outras operações. Não, porém, quanto ao que é
próprio às tais operações; porque, segundo o Filosofo, a ação é própria de quem é própria a potência.
Por onde, nenhuma operação vital pode realizar o ser sem vida, a qual é o princípio potencial de tal
operação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como não é contra a verdade que a Escritura
descreva coisas inteligíveis sob figuras sensíveis, pois tal não diz para afirmar que o inteligível seja
sensível, mas para dar a entender, por figuras sensíveis, as propriedades dos inteligíveis, segundo certa
semelhança; assim não repugna à veracidade dos santos anjos que os corpos por eles assumidos
pareçam homens vivos, embora não o sejam. Pois não são assumidos senão para que as propriedades e
as operações espirituais dos anjos sejam designadas pelas propriedades e operações humanas. O que
não se poderia fazer congruentemente se eles assumissem verdadeiros homens porque então
revelariam propriedades dos próprios homens e não dos anjos.

RESPOSTA À SEGUNDA. — Sentir é operação totalmente vital. Por onde, de nenhum modo se pode
dizer que os anjos sintam, pelos órgãos dos corpos assumidos. Mas nem por isso tais órgãos se
formaram superfluamente, pois não se formaram para que, por eles, se sentisse, mas para que
designassem as virtudes espirituais dos anjos; assim como, pelos olhos, se designa a virtude cognoscitiva
do anjo e, pelos outros membros, as outras virtudes deles, como ensina Dionísio.

RESPOSTA À TERCEIRA. — O movimento proveniente de um motor conjunto é operação propriamente
vital. Mas assim não é que se movem os corpos assumidos pelos anjos, pois estes não são as formas
daqueles. Por onde, movidos tais corpos, os anjos se movem por acidente; pois estão estes naqueles
como motores nos moveis; e por isso estão num ponto porque não estão em outro. O que não se pode
dizer de Deus. Por onde, embora Deus não se mova, movidas as coisas em que Ele está, porque está em
toda parte, contudo os anjos se movem por acidente, pelo movimento dos corpos assumidos. Não,
porém, pelo movimento dos corpos celestes, embora também estejam nestes como os motores nos
móveis; porque os corpos celestes não mudam, totalmente, de lugar. Nem é determinado ao espírito
que move o orbe, um lugar, segundo alguma parte determinada da substância desse orbe, o qual está
ora no oriente, ora no ocidente; mas, sim, segundo uma posição determinada, pois, a virtude motora
está sempre no oriente, como diz o Filosofo.

RESPOSTA À QUARTA. — Os anjos, propriamente, não falam pelos corpos assumidos, mas por um símile
de locução, enquanto formam, no ar, sons semelhantes às vozes humanas.

RESPOSTA À QUINTA. — Nem ainda o comer, propriamente falando, convém aos anjos, pois, importa a
absorção da comida convertível na substância de quem come. E embora o alimento não se convertesse
no corpo de Cristo ressurrecto, mas se resolvesse na matéria primitiva, todavia Cristo tinha um corpo de
natureza susceptível de se converter com o alimento e, por isso, houve verdadeiro ato de comer. Mas a
comida tomada pelos anjos nem se convertia no corpo assumido, nem esse corpo era de natureza a
poder operar tal conversão; e por isso não houve verdadeiro ato de comer, senão figurativo da
alimentação espiritual. E foi isto o que o anjo disse a Tobias, (Tb 12, 18-19) Quando eu estava convosco,
parecia-vos que eu comia e bebia convosco; mas eu sustento-me de um manjar e bebida
invisível. Abraão, porém, ofereceu-lhes alimentos, pensando que fossem homens; embora, neles,
venerasse a Deus, pois Deus costuma estar nos profetas, como diz Agostinho.

RESPOSTA À SEXTA. — Como diz Agostinho, muitos experimentados, ou instruídos pelos experientes,
confirmam que os Silvanos e os Faunos, chamados vulgarmente íncubos, são muitas vezes luxuriosos
com as mulheres, desejando-as e realizando o ato carnal com elas, de modo que é imprudência negar tal
fato. Porém os santos anjos de Deus de nenhum modo puderam assim manchar-se, antes do dilúvio. Por
onde, entendem-se por filhos de Deus os de Sete, que eram bons; porém, a Escritura chama filhas dos
homens às nascidas da estirpe de Caim, nem é para admirar que delas pudessem nascer gigantes,
embora nem todos assim o nascessem, mas muito mais antes que depois do dilúvio. Se, porém, por
vezes, alguns nasceram de coito com os demônios, tal não se operou pelo sêmen emitido por eles ou
pelos corpos assumidos, mas pelo sêmen de algum homem, obtido para tal fim; e isto por ter o mesmo
demônio, súcubo em relação ao homem, se tornado incubo em relação à mulher, assim como assumem
as sementes de outros seres para a geração de alguns deles, como diz Agostinho. De modo que o
nascido de tal operação não é filho do demônio, mas do homem de quem foi obtido o sêmen.