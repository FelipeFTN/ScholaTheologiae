# Questão 61: Da produção natural do ser angélico.
Após o que ficou dito da natureza, do conhecimento e da vontade dos anjos, resta considerar-lhes a
criação, ou o começo deles, em universal. E esta consideração é tripartita. Assim, primeiro
consideraremos como foi produzido o ser natural deles. Segundo, como foram aperfeiçoados pela graça
ou pela glória. Terceiro, como alguns deles tornaram-se maus.
Sobre o primeiro ponto quatro artigos se discutem:

## Art. 1 — Se os anjos são a causa da própria existência.
(Supra, q. 44, a. 1; Opusc. XV, De Angelis cap. IX, XVII)
O primeiro discute-se assim. – Parece que os anjos não tem causa da própria existência.

1. —Pois, na Escritura (Gn 1) se trata das coisas criadas por Deus. Ora, nela não se faz nenhuma menção
dos anjos. Logo, estes não foram criados por Deus.

2. Demais. — O filósofo diz que se houver alguma substância que seja forma sem matéria, terá
imediatamente, por si mesma, o ser e a unidade, e não terá causa que a faça ente e una. Ora, os anjos
são formas imateriais, como já antes se demonstrou. Logo, não tem causa da sua existência.

3. Demais. — A forma do que é feito por um agente deste provém. Ora, os anjos, sendo formas, não
recebem a forma de nenhum agente. Logo, não tem causa agente.
Mas, em contrário, a Escritura diz (Sl 148, 2): Louvai-o, todos os seus anjos; e depois acrescenta: Porque
ele disse, e foram feitas as coisas.

SOLUÇÃO. — É necessário admitir-se que os anjos, bem como todos os seres, menos Deus, foram feitos
por Deus. Pois, só Ele é a própria existência, diferindo, em todos os outros, a essência da existência,
como resulta do já visto. Donde, é manifesto que só Deus é o ser pela sua essência, sendo todos os
outros seres por participação. Ora, tudo o que é por participação é causado pelo que é por essência;
assim, tudo o que é ígneo é causado pelo fogo. Por onde, é necessário que os anjos tenham sido criados
por Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho diz que os anjos não foram omitidos na
primeira criação das coisas, mas estão incluídos nas expressões do céu ou da luz. Assim, pois, ou foram
omitidos ou estão incluídos em os nomes das coisas corpóreas, porque Moisés falava a um povo rude,
ainda incapaz de compreender a natureza incorpórea. E se se lhes dissesse existirem certos seres
superiores a toda natureza corpórea, isso lhes seria ocasião de idolatria, à qual eram inclinados, e à qual
Moisés precipuamente queria arrancá-los.

RESPOSTA À SEGUNDA. — As substâncias que são formas subsistentes não têm nenhuma causa formal
da sua existência e da sua unidade, nem causa agente, pela transmutação da matéria da potência para o
ato; mas tem causa que lhes produziu a substância total.
Donde se deduz a RESPOSTA À TERCEIRA OBJEÇÃO.

## Art. 2 — Se o anjo foi produzido por Deus abeterno.
O segundo discute-se assim. — Parece que o anjo foi produzido por Deus abeterno.

1. — Pois, Deus, causa da existência do anjo, não age por algo que lhe foi acrescentado à essência, mas
o seu ser é eterno. Logo, produziu os anjos abeterno.

2. Demais. — O que nem sempre existiu está sujeito ao tempo. Ora, o anjo está fora do tempo, como diz
Alberto. Logo, o anjo sempre existiu.

3. Demais. — Agostinho prova a incorruptibilidade da alma por ser o intelecto capaz da verdade. Ora,
sendo a verdade incorruptível, é também eterna. Logo, a natureza intelectual da alma e do anjo não só é
incorruptível, mas também eterna.
Mas, em contrário, diz a Escritura da pessoa a Sabedoria gerada (Pr 8, 22): O Senhor me possuiu no
princípio de seus caminhos, antes que criasse coisa alguma. Ora, os anjos foram feitos por Deus, como já
se demonstrou. Logo, houve tempo em que eles não existiram.

SOLUÇÃO. — Só Deus, Pai, Filho e Espírito Santo, existe abeterno. Pois a fé católica indubitavelmente o
ensina, sendo o contrário rejeitado como herético. Assim, Deus produziu as criaturas por tê-las feito do
nada, isto é, depois de terem sido nada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Sendo a essência de Deus o seu próprio querer, de ter
Ele, pela sua essência, produzido os anjos e as outras criaturas, não se segue não as tivesse produzido
pela sua vontade. Ora, esta quer, não porém necessariamente, a produção das criaturas, como antes
ficou dito. Logo, produziu as que quis e quando as quis.

RESPOSTA À SEGUNDA. — O anjo não está no tempo que numera o movimento do céu, pois está fora
de todo movimento da natureza corpórea. Não está, porém, fora do tempo que lhe numera tanto a
sucessão da sua existência, posterior à não existência, como a das suas operações. Por onde diz
Agostinho que Deus move a criatura espiritual no tempo.

RESPOSTA À TERCEIRA. — Os anjos e as almas dotadas de intelecto, pelo fato mesmo de terem uma
natureza pela qual são capazes da verdade, são incorruptíveis. Essa natureza, porém, não a tiveram
abeterno, mas Deus lhas deu quando quis. Por onde se não segue que os anjos existissem abeterno.

## Art. 3 — Se os anjos foram criados antes do mundo corpóreo.
(II Sent., dist. II, q. 1, a. 3; De Pot., q. 3, a. 18; Opusc. XV, De Angelis, cap. XVII, Opusc. XXIII, in Decretal. I)
O terceiro discute-se assim. — Parece que os anjos foram criados antes do mundo corpóreo.

1. — Pois, diz Jerônimo: Ainda se não completaram seis mil dos nossos anos, e quantos tempos, quantas
sucessões de séculos devem se computar, durante os quais os Anjos, os Tronos, as Dominações e as
outras ordens serviram a Deus! Damasceno também diz: Alguns afirmam que, antes de toda a criação,
foram gerados os anjos, como diz o Teólogo Gregório; pois, primeiro, Deus pensou as virtudes angélicas
e celestes e o seu pensamento foi criação.

2. Demais. — A natureza angélica é média entre a divina e a corpórea. Ora, aquela é eterna; esta,
temporal. Logo, a natureza angélica foi feita antes da criação do tempo e depois da eternidade.

3. Demais. — Mais dista a natureza angélica da corpórea do que uma natureza corpórea da outra. Ora,
destas, uma foi feita antes de outra, sendo por isso descritos, no princípio do Genesis, os seis dias da
criação das coisas. Logo, com maior razão, a natureza angélica foi feita antes de qualquer natureza
corpórea.
Mas, em contrário, diz a Escritura (Gn 1, 1): No princípio criou Deus o céu e a terra. Ora, isto não seria
verdade se Deus tivesse criado antes algum ser. Logo, os anjos não foram criados antes da natureza
corpórea.

SOLUÇÃO. — Sobre este assunto dupla é a opinião dos santos Doutores, sendo a mais provável a que
ensina terem os anjos sido criados simultaneamente com a natureza corpórea. Pois eles fazem parte do
universo, não constituindo um, por si, mas concorrendo, com a criatura corpórea, para a constituição do
mesmo universo. O que bem se verá considerando a ordem de uma criatura em relação a outra. Pois, a
ordem das coisas entre si é o bem do universo. Ora, nenhuma parte é perfeita, separada do todo. Logo,
não é provável que Deus, cujas obras são perfeitas, como diz a Escritura (Dt 32, 4), tivesse criado a
criatura angélica separadamente, antes das outras criaturas. — Todavia, não se deve reputar por
errônea a opinião contrária, sobretudo por causa da opinião de Gregório Nazianzeno, cuja autoridade é
tão grande, na doutrina cristã, que ninguém ousaria acusar-lhe de erro os ensinamentos, bem como os
ensinamentos de Atanásio, segundo diz Jerônimo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Jerônimo se exprime segundo o pensamento dos
Doutores gregos, todos concordes em sentir que os anjos foram criados antes do mundo corpóreo.

RESPOSTA À SEGUNDA. — Deus não faz parte do universo, mas está totalmente acima deste, cuja total
perfeição preencerra em si, de modo mais eminente. O anjo, porém, faz parte do universo. Logo, a razão
não é a mesma..

RESPOSTA À TERCEIRA. — Todas as criaturas corpóreas se unificam pela matéria; mas os anjos não
convém, por esta, com tais criaturas. Por onde, criada a matéria das criaturas corpóreas, todas elas
foram, de certo modo, criadas; mas, criados os anjos, nem por isso criado estaria o universo.
Se porém se aceitar a opinião em contrário, deve-se expor a passagem (Gn 1, 1) — No princípio criou
Deus o céu e a terra — assim: no princípio, i. é, no Filho ou no princípio do tempo; não no princípio, i.
é, antes de qualquer ser existir, salvo se se disser, antes de qualquer ser, no gênero das criaturas
corporais.

## Art. 4 — Se os anjos foram criados no céu empíreo.
(Infra, q. 102, a. 2, ad 1; II Sent., dict. VI, a. 3; Opusc. XV, De Angelis, cap. XVII)
O quarto discute-se assim. — Parece que os anjos não foram criados no céu empíreo.

1. — Pois, são substâncias incorpóreas. Ora, a substância incorpórea não depende do corpo pelo seu ser
e, por conseqüência, nem pelo vir-a-ser. Logo, os anjos não foram criados num lugar corpóreo.

2. Demais. — Agostinho diz que os anjos foram criados na parte superior do ar. Logo, não no céu
empíreo.

3. Demais. — O céu empíreo é chamado o céu supremo. Se, logo, os anjos tivesse sido nele criados, não
lhes caberia subir a um céu superior, o que vai contra o que a Escritura diz da pessoa do anjo pecador (Is
14, 13):Subirei ao céu.
Mas, em contrário, diz Estrabão, a propósito do passo — No princípio criou Deus o céu e a terra: Chama
aqui, céu, não ao firmamento visível, mas ao empíreo, i. é, ígneo ou intelectual, assim dito não pelo
ardor, mas pelo esplendor e o qual, imediatamente depois de feito, se encheu de anjos.

SOLUÇÃO. — Como já ficou dito, das criaturas corpóreas e espirituais se constitui o universo unido.
Assim, foram criados seres espirituais, de certo modo ordenados aos seres corpóreos e que a todos
estes presidem. Por onde, foi conveniente que os anjos, devendo presidir a toda natureza corpórea,
fossem criados no corpo supremo, quer se dê a este a denominação de empíreo ou qualquer outra. Por
isso, Isidoro diz que céu supremo é o dos anjos, comentando a passagem da Escritura (Dt 10, 14): O céu
é do Senhor teu Deus, e o céu dos céus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os anjos não foram criados em lugar corpóreo, como se
dependentes do corpo, pelo ser ou pelo vir a ser deles; pois, Deus poderia ter criado os anjos antes de
toda criatura corpórea, e muitos santos Doutores assim o pensam. Mas foram feitos em lugar corpóreo
para mostrar a relação que tem com a natureza corpórea e que, pela sua virtude, tem contato com
corpos.

RESPOSTA À SEGUNDA. — Talvez Agostinho, pela suprema parte do ar entenda a suprema parte do céu,
com a qual o ar tem certa conveniência por causa da sua sutileza e diafaneidade. — Ou se refere, não a
todos os anjos, mas aos que pecaram e que, segundo alguns, eram das ordens inferiores. Pois, nada
impede dizer-se que os anjos superiores, tendo sobre todos os corpos virtude elevada e universal, foram
criados no lugar supremo da criatura corpórea; os outros, porém, tendo virtudes mais particulares,
foram criados nos corpos inferiores.

RESPOSTA À TERCEIRA. — O passo citado se refere não a algum céu corpóreo, mas ao da santa
Trindade, ao qual o anjo pecador quis subir quando quis, de certo modo, equiparar-se a Deus, como a
seguir se verá.