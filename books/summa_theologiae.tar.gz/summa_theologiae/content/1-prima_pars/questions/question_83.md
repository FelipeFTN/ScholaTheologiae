# Questão 83: Do livre arbítrio.
Em seguida tratamos do livre arbítrio. E, sobre este ponto, quatro artigos se discutem:

## Art. 1 — Se o homem tem livre arbítrio.
(Supra, q. 59, a. 3; Ia-IIae, q. 13, a. 6; De Verit., q. 24, a. 1, 2; De Malo, q. 6).
O primeiro discute-se assim. ― Parece que o homem não tem livre arbítrio.

1. ― Pois, quem tem livre arbítrio faz o que quer. Ora, o homem não faz o que quer como se vê pela
Escritura (Rm 7, 19): Porque eu não faço o bem que quero; mas faço o mal, que não quero. Logo, o
homem não tem livre arbítrio.

2. Demais. ― Quem é livre pode querer e não querer, operar ou não. Ora, isso está no poder do homem,
conforme a Escritura (Rm 9, 16): Não pertence ao que quer, o querer, nem ao que corre, o correr. Logo,
o homem não tem livre arbítrio.

3. Demais. — É livre quem é causa de si, como diz Aristóteles. E não é livre o que é movido por outro.
Ora, Deus move a vontade, conforme a Escritura (Pr 21, 1): O coração do rei se acha na mão do
Senhor, e (Fl 2, 13): Eleo inclina para qualquer parte que quiser; e: Deus é o que opera em vós o querer e
o perfazer. Logo, o homem não tem livre arbítrio.

4. Demais. ― Quem é livre é senhor dos seus atos. Ora, o homem não o é, como diz a Escritura (Jr 10,
23): Nãoé do homem o seu caminho, nem é do varão o andar e o dirigir os seus passos. Logo, o homem
não tem livre arbítrio.

5. Demais. ― O Filósofo diz: Tal é um ser, tal é o seu fim que se propõe. Ora, não por nós mesmos, mas
pela natureza, é que somos o que somos. Logo, vem da natureza, e não do livre arbítrio, o buscarmos
um determinado fim.
Mas, em contrário, diz a Escritura (Ecle 15, 14): Deus criou o homem desde o princípio e deixou-o na
mão do seu conselho, i. é, conforme a Glossa, na liberdade do arbítrio.

SOLUÇÃO. ― O homem tem livre arbítrio; do contrário seriam inúteis os conselhos, as exortações, os
preceitos, as proibições, os prêmios e as penas. E isto se evidencia, considerando, que certos seres agem
sem discernimento; como a pedra, que cai e, semelhantemente, todos os seres sem conhecimento.
Outros, porém, agem com discernimento, mas não livre, como os brutos. Assim a ovelha que, vendo o
lobo, discerne que deve fugir, por discernimento natural, mas não livre, porque esse discernimento não
provém da reflexão, mas do instinto natural. E o mesmo se dá com qualquer discernimento dos brutos.
― O homem, porém, age com discernimento; pois, pela virtude cognoscitiva, discerne que deve evitar
ou buscar alguma coisa. Mas esse discernimento, capaz de visar diversas possibilidades, não provém do
instinto natural, relativo a um ato particular, mas da reflexão racional. Pois a razão, relativamente às
coisas contingentes, pode decidir entre dois termos opostos, como se vê nos silogismos dialéticos e nas
persuasões retóricas. Ora, os atos particulares são contingentes e, portanto, em relação a eles, o juízo
da razão tem de se avir com termos opostos e não fica determinado a um só. E, portanto, é forçoso que
o homem tenha livre arbítrio, pelo fato mesmo de ser racional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como já se disse antes (q. 81, a. 3 ad 2), o apetite
sensitivo, embora obediente à razão, pode contudo recalcitrar, desejando o que a razão proíbe. Ora, o
bem que o homem não faz quando quer é o que consiste em ser concupiscente contra a razão, como diz
a Glossa de Agostinho a esse passo.

RESPOSTA À SEGUNDA. ― Não se deve entender esse passo do Apóstolo no sentido em que o homem
não quer e não corre por livre arbítrio; mas como significando que o livre arbítrio não é suficiente para
isso, se não for movido e ajudado por Deus.

RESPOSTA À TERCEIRA. ― O livre arbítrio é causa do seu movimento, porque o homem, pelo livre
arbítrio, é levado a agir. Mas, contudo, não é necessário, para a liberdade, que o livre seja a causa
primeira de si mesmo; assim como não é necessário, para uma causa ser causa de outra, que seja sua
causa primeira. Ora, Deus, pois, é a causa primeira motora, tanto das causas naturais como das
voluntárias. E assim como, movendo-as, não faz com que os atos delas deixem de ser naturais; assim
também, movendo as voluntárias, não faz com que os seus atos deixem de ser voluntários, mas antes,
causa-lhes essa qualidade, porque obra, em cada ser, conforme a propriedade deles.

RESPOSTA À QUARTA. ― Diz-se que não está no homem escolher o seu caminho quanto à execução das
eleições, nas quais o homem pode ser impedido, queira ou não. Mas as eleições em si mesmas
dependem de nós, suposto, contudo, o auxílio divino.

RESPOSTA À QUINTA. ― Dupla é a qualidade do homem: uma natural; outra, superveniente. ― Aquela
pode ser da parte intelectiva e do corpo ou das virtudes anexas ao corpo. Assim, por ter tal qualidade
natural intelectiva é que o homem deseja o último fim, que é a beatitude; cujo desejo é natural e não
depende do livre arbítrio, como resulta do sobredito (q. 82, a. 1, 2). E é por ter tal qualidade natural,
quanto ao corpo e às virtudes anexas ao corpo, que o homem tem tal compleição ou tal disposição, em
virtude de determinada impressão das coisas corpóreas, que se não podem aplicar à parte intelectiva,
por não ser esta ato de nenhum corpo. Assim, pois, cada um se propõe o fim conforme a sua qualidade
corpórea, porque, em virtude desta disposição, é que o homem se inclina a eleger ou repudiar alguma
coisa. Essas inclinações, porém, são dependentes do juízo da razão, à qual obedece o apetite inferior,
como já se disse (q. 81, a. 3). Por onde, não tolhem a liberdade do arbítrio. ― Mas as qualidades
supervenientes são como que hábitos e paixões pelas quais alguém se inclina mais a uma que a outra
coisa, dependendo também essas inclinações do juízo da razão. E tais qualidades são, do mesmo modo,
subordinadas à razão, enquanto de nós depende adquiri-las, causal ou dispositivamente, bem como
excluí-las. Assim que, nada há de repugnante à liberdade do arbítrio.

## Art. 2 — Se o livre arbítrio é uma potência.
(II Sent., dist. XXIV, q. 1, a. 1; De Verit., q. 24, a. 4).
O segundo discute-se assim. ― Parece que o livre arbítrio não é uma potência.

1. ― Pois, o livre arbítrio não é senão o livre discernimento ou juízo. Ora, este não denomina uma
potência, mas um ato. Logo, o livre discernimento não é potência.

2. Demais. ― O livre arbítrio é uma faculdade da vontade e da razão. Ora, a faculdade denomina a
facilidade da potência, cuja facilidade provém do hábito. Logo, o livre arbítrio é um hábito. E Bernardo
também diz, que o livre arbítrio é o hábito da alma livre, em si. Logo, não é potência.

3. Demais. ― Nenhuma potência natural é tolhida pelo pecado. Ora, o livre arbítrio é por ele tolhido;
pois, Agostinho diz que o homem, usando mal do livre arbítrio, perde-se a si mesmo e a este. Logo, não
é potência.
Mas, em contrário, só a potência pode ser sujeito do hábito. Ora, o livre arbítrio é sujeito da graça, pela
assistência da qual escolhe o bem. Logo, é potência.

SOLUÇÃO. ― Embora o livre arbítrio, na sua significação própria, denomine um ato, todavia, pelo uso
comum de falar, o consideramos como o princípio desse ato, pelo qual princípio o homem julga
livremente. Ora, o princípio de um ato, em nós, é potência e hábito; pois, conhecemos alguma coisa pela
ciência e pela potência intelectiva. Logo, é forçoso seja o livre arbítrio potência, hábito, ou potência
acompanhada de um hábito. Ora, que não é hábito nem potência acompanhada deste, manifestamente
resulta das duas razões seguintes. ― Primeiro, porque, se é hábito, é necessariamente um hábito
natural, pois, é natural ao homem ter livre arbítrio. Ora, nenhum hábito natural existe em nós,
relativamente ao que depende do livre arbítrio; quando temos hábitos naturais em relação a alguma
coisa, a essa nos inclinamos naturalmente, como, p. ex., quando damos assentimento aos primeiros
princípios. Ora, aquilo ao que naturalmente nos inclinamos não depende do livre arbítrio, como já ficou
dito quando se tratou do desejo da felicidade (q. 82, a. 1, 2). Por onde, é contra a essência própria do
livre arbítrio ser hábito natural. Mas também contra a sua naturalidade é que seja um hábito não
natural. E, portanto, resulta que de nenhum modo, é hábito. ― A segunda razão vem de que se chamam
hábitos os modos pelos quais nos avimos bem ou mal, em relação às paixões ou aos atos, como já se
disse. Assim, pela temperança, bem nos avimos em relação às concupiscências; porém, pela
intemperança, mal. Também, pela ciência, bem nos avimos em relação ao ato intelectual, enquanto
conhecemos a verdade; porém, pelo ato contrário, mal. Ora, ao livre arbítrio é indiferente à boa ou a má
eleição. Por onde, é impossível que seja hábito. Logo, resulta que é potência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – É costume designar a potência pelo nome do ato. Assim,
por esse ato, que é o livre discernimento ou juízo, designamos a potência que é o princípio do mesmo.
Do contrário, se livre arbítrio denominasse um ato, não permaneceria sempre no homem.

RESPOSTA À SEGUNDA. ― Às vezes, a faculdade denomina a potência expedita para operar. E é assim
que faculdade entra na definição do livre arbítrio. ― Quanto a Bernardo, ele entende o hábito, não
enquanto é dividido por oposição com a potência, mas enquanto significa um certo feitio pelo qual
alguém se avém em relação ao ato. O que se dá tanto pela potência, como pelo hábito; pois, por aquela
o homem se comporta como capaz de operar; por este, porém, como apto a operar bem ou mal.

RESPOSTA À TERCEIRA. ― Diz-se, que o homem, pecando, perdeu o livre arbítrio, não quanto à
liberdade natural, que é a liberdade isenta da coação; mas quanto à liberdade isenta da culpa e da
miséria. Do que se tratará mais tarde, na segunda parte desta obra, no tratado da moral (IIa. IIae, q. 85;
q . 109).

## Art. 3 — Se o livre arbítrio é potência apetitiva ou cognitiva.
(Iª IIae, q. 13, a. 1).
O terceiro discute-se assim. ― Parece que o livre arbítrio não é potência apetitiva, mas cognitiva.

1. ― Pois, diz Damasceno, o livre arbítrio segue presto à parte racional. Ora, a razão é potência
cognitiva. Logo, o livre arbítrio é potência cognitiva.

2. Demais. ― Dizer livre arbítrio é como dizer livre discernimento. Ora, discernir ou julgar é ato da
virtude cognitiva. Logo, o livre arbítrio é potência cognitiva.

3. Demais. ― A eleição pertence, principalmente, ao livre arbítrio. Ora, esta, incluindo a comparação de
um juízo com outro, o que é próprio da virtude cognitiva, é uma propriedade do conhecimento. Logo, o
livre arbítrio é potência cognitiva.
Mas, em contrário, diz o Filósofo, a eleição é o desejo daquilo que está em nós. Ora, o desejo é ato da
virtude apetitiva. Logo, também a eleição. O livre arbítrio é a virtude pela qual elegemos. Logo, é virtude
apetitiva.

SOLUÇÃO. ― A eleição é propriedade do livre arbítrio. Pois, se temos livre arbítrio é que podemos
tomar uma coisa e recusar outra; e isso é eleger. Por onde, é mister considerar a natureza do livre
arbítrio partindo da eleição. Ora, para esta concorre à virtude cognitiva e a apetitiva, cada uma com a
sua parte. Por parte da cognitiva requer-se o conselho, pelo qual se julga a preferência de uma coisa
sobre outra. E, por parte da apetitiva, requer-se que seja aceito, pelo apetite, aquilo que foi julgado pelo
conselho. E por isso, Aristóteles deixou na dúvida, se a eleição pertence mais principalmente à virtude
apetitiva ou à cognitiva. Pois, diz que a eleição é o intelecto apetitivo ou o apetite intelectivo. Mas em
outra passagem, indica de mais perto que seja o apetite intelectivo, denominando a
eleição desejo conciliável. E a razão é que o objeto próprio da eleição é aquilo que conduz ao fim. Ora,
isto, como tal, tem a essência do bem chamado útil. Por onde, sendo o bem, como tal, o objeto do
apetite, resulta que a eleição é, principalmente, ato da virtude apetitiva. E assim, o livre arbítrio é
potência apetitiva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― As potências apetitivas acompanham às apreensivas. E,
neste sentido, Damasceno diz que o livre arbítrio segue presto a parte racional.

RESPOSTA À SEGUNDA. ― O juízo é como a conclusão e a determinação do conselho. Ora, este é
determinado, primeiro, pela sentença da razão; e, segundo, pela aceitação do apetite. Por onde, o
Filósofo diz, que julgando pelo conselho, desejamos pelo conselho. E, deste modo, diz-se que a eleição
mesma é um juízo; e por ele se denomina o livre arbítrio.

RESPOSTA À TERCEIRA. ― A comparação incluída em a denominação de eleição, pertence ao conselho
precedente, propriedade da razão. Pois o apetite, embora não seja reflexivo, contudo, enquanto movido
pela virtude comparativa cognitiva, têm alguma semelhança com a comparação, enquanto prefere uma
coisa à outra.

## Art. 4 — Se o livre arbítrio é potência diferente da vontade.
(III, Q. 18, A. 3, 4; II SENT., DIST. XXIV, Q. 1, A. 3; DE VERIT., Q. 24, A. 6).
O quarto discute-se assim. ― Parece que o livre arbítrio é potência diferente da vontade.

1. ― Pois, Damasceno diz, que uma coisa é a Θέλησις e outra, a βούλησις — aquela é à vontade; esta, o
livre arbítrio, porque, segundo o mesmo, a βούλησις é a vontade referente a alguma coisa, e que busca,
por assim dizer, uma coisa por comparação com outras. Logo, o livre arbítrio é potência diferente da
vontade.

2. Demais. ― As potências conhecem-se pelos atos. Ora, a eleição, ato do livre arbítrio, é diferente da
vontade, como já se disse no passo seguinte: a vontade quer o fim, a eleição, porém, aquilo que leva ao
fim. Logo, o livre arbítrio é potência diversa da vontade.

3. Demais. ― A vontade é apetite intelectivo. Ora, há no intelecto duas potências: o agente e o possível.
Logo, também no apetite intelectivo deve existir alguma potência, além da vontade, e essa não pode ser
senão o livre arbítrio. Logo, este é potência diferente da vontade.
Mas, em contrário, diz Damasceno, que o livre arbítrio não é senão à vontade.

SOLUÇÃO. ― É necessário sejam as potências apetitivas proporcionadas às apreensivas, como já se
disse (q. 64, a. 2). Ora, assim como na apreensão intelectiva o intelecto é proporcionado à razão; assim,
no apetite intelectivo proporcionam-se a vontade e o livre arbítrio, que não é senão a virtude eletiva. E
isto bem se evidencia pela relação dos objetos e dos atos. Pois, inteligir importa na recepção simples de
uma coisa; por onde, consideram-se inteligidos, no sentido próprio, os princípios que, sem raciocínio,
são conhecidos em si mesmos. Mas, raciocinar, propriamente, é passar do conhecimento de uma coisa
para o de outra; e, por isso, propriamente, raciocinamos sobre as conclusões, conhecidas pelos
princípios. Semelhantemente, por parte do apetite, querer importa no simples desejo de uma coisa; e,
por isso, diz-se que a vontade quer o fim, desejado em si mesmo. Ao passo que eleger é desejar uma
coisa por causa de outra, que se quer conseguir; e, por isso, propriamente, se refere às coisas que
conduzem ao fim. Ora, assim como, na cognição, o princípio está para a conclusão, na qual assentimos
por causa dos princípios; assim, na apetição, o fim está para as coisas conducentes ao fim e que por
causa daquele são desejadas. Por onde, é manifesto que assim como o intelecto está para a razão, assim
está à vontade para a virtude eletiva, i. é., para o livre arbítrio. Mas, como já se demonstrou antes (q.
79, a. 8), a mesma potência que intelige raciocina, assim como a mesma que repousa é movida. Logo, a
mesma potência que quer também elege. E, por isso, a vontade e o livre arbítrio não são duas potências,
mas uma só.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A Θέλησις se distingue da βούλησιςnão pela diversidade
das potências, mas pela diferença dos atos.

RESPOSTA À SEGUNDA. ― A eleição e a vontade, i. é., o querer mesmo, são atos diversos, mas, contudo
pertencem a uma mesma potência; assim como o inteligir e o raciocinar, segundo já se disse.

RESPOSTA À TERCEIRA. ― O intelecto se compara com a vontade como motor. E, por isso, não é preciso
distinguir, na vontade, o agente, do possível.