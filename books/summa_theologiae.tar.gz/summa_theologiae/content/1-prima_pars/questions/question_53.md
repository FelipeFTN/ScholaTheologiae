# Questão 53: Do movimento local dos anjos.
Em seguida devemos tratar do movimento local dos anjos. E, sobre assunto, três artigos se discutem:

## Art. 1 — Se o anjo pode mover-se localmente.
(I Sent., dist. XXXVII, q. 4, a. 1; Opusc. XV, De Angelis, cap. XVIII)
O primeiro discute-se assim. — Parece que o anjo não pode mover-se localmente.

1. — Pois, como o Filósofo o prova, nenhum ser indivisível pode mover-se, nem enquanto está no ponto
de partida porque então ainda não se move; nem quando já está no de chegada, porque, então, já se
moveu. Donde resulta que tudo o que se move está, enquanto em movimento, parte, no ponto de
partida e, parte, no de chegada. Ora, o anjo, é indivisível. Logo, não pode mover-se localmente.

2. Demais — O movimento é o ato do ser imperfeito, como diz Aristóteles. Ora o anjo bem-aventurado
não é imperfeito. Logo, o anjo bem-aventurado não pode mover-se localmente.

3. Demais. — O movimento supõe a carência. Ora, nenhuma carência há nos santos anjos. Logo, eles
não se movem localmente.
Mas, em contrário, pela mesma razão pode mover-se o anjo bemaventurado e a alma bem-aventurada.
Ora, é necessário admitir-se que esta se move localmente, pois é artigo de fé que a alma de Cristo
desceu aos infernos. Logo, o anjo beato se move localmente.

SOLUÇÃO. — O anjo beato pode mover-se localmente; mas, como o estar em um lugar convém
equivocamente ao corpo e ao anjo, o mesmo se dá com o mover-se localmente. Pois, o corpo está em
um lugar enquanto é por este contido e comensurado. E por isso é necessário também seja o
movimento local do corpo comensurado pelo lugar e submetido às exigências destes. Donde resulta
que, tal a continuidade da grandeza, tal a do movimento; e a anterioridade e a posterioridade na
grandeza, são correlatas às do movimento local do corpo, como diz Aristóteles. Mas o anjo não está
num lugar como comensurado e contido, senão, antes, como continente. Por onde, não há-de
necessariamente o movimento local do anjo ser comensurado pelo lugar, nem submetido às exigências
deste, de modo a ter continuidade local; mas é um movimento não contínuo. Assim, não estando o anjo
em um lugar senão pelo contato da sua virtude, como já se disse, o movimento local do anjo não será,
por força, senão os seus diversos contatos com os diversos lugares sucessiva e não simultaneamente,
porque o anjo não pode estar simultaneamente em vários lugares, como antes se disse. Ora, não é
necessário sejam tais contatos contínuos, pois, pode existir neles certa continuidade. Porquanto, como
já ficou dito, nada impede se assinale ao anjo um lugar divisível pelo contato da sua grandeza. Por onde,
assim como o corpo deixa, sucessiva e não simultaneamente, o lugar em que primeiro estava, e isso lhe
causa a continuidade no seu movimento local; assim também o anjo pode deixar, sucessivamente, o
lugar divisível em que primeiro estava e, assim, o seu movimento será contínuo. Mas como também
pode deixar, simultaneamente, todo um lugar, e aplicar-se do mesmo modo e totalmente a outro, o seu
movimento não será contínuo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Esta objeção falha, duplamente, o fim que visou.
Primeiramente, porque a demonstração de Aristóteles serve para o indivisível quantitativo, ao qual
corresponde um lugar necessariamente indivisível; o que se não pode dizer do anjo. Segundo, porque a
dita demonstração serve para o movimento contínuo. Pois, se o movimento não fosse contínuo, podia
dizer-se que uma coisa se move estando no ponto de partida e no de chegada; porque, se chamaria
movimento à sucessão das diversas posições, relativamente à mesma coisa: e então esta poderia
considerar-se como movendo-se, em qualquer das posições que ocupasse. Mas a continuidade do
movimento tal não permite, pois nenhum contínuo está no seu termo, como se vê pela linha, que não
está no ponto; donde necessariamente resulta, que tudo o que se move não está totalmente, enquanto
em movimento, em nenhum dos termos, mas, parte, em um e, parte, em outro. Ora, não sendo
contínuo o movimento do anjo, a demonstração de Aristóteles não colhe, no caso. Mas se o for, pode se
conceder que o anjo, enquanto se move, está, parte, no ponto de partida e, parte, no de chegada; sem
que todavia essa parcialidade se refira à substância do anjo, mas ao lugar. Porque, no inicio do seu
movimento contínuo, o anjo está no lugar divisível total, donde começou a mover-se; mas, durante o
seu movimento, está numa parte do primeiro lugar, que abandona, e noutra do segundo, que ocupa. E o
poder ocupar partes de dois lugares convém ao anjo porque ele pode ocupar um lugar divisível pela
aplicação de sua virtude, assim como o corpo pela da sua grandeza. Donde se segue que o corpo móvel
localmente é divisível pela grandeza; o anjo, porém, pode aplicar a sua virtude a algo de divisível.

RESPOSTA À SEGUNDA. — O movimento do que existe em potência é o ato do imperfeito. Mas o
resultante da aplicação de uma virtude é próprio a um ser atual, pois um ser tem virtude enquanto é
atual.

RESPOSTA À TERCEIRA. — O movimento do ser potencial supõe a carência deste; mas não supõe o do
ser atual, pois, ao contrário, tal movimento é por carência de outro ser. E, desse modo, o anjo se move
localmente por causa da nossa carência, conforme a Escritura (Hb 1, 14): Todos os espíritos são uns
administradores, enviados para exercer o seu ministério a favor daqueles que hão de receber a herança
da salvação.

## Art. 2 — Se o anjo atravessa uma posição média.
(I Sent., dist. XXXVII, q. 4, a. 2; Quodl. I, a. 3, a. 2).
O segundo discute-se assim. — Parece que o anjo não atravessa nenhuma posição média.

1. — Tudo o que atravessa uma posição média antes de atravessar um lugar que lhe seja maior
atravessa um que lhe seja igual. Ora, o anjo sendo indivisível, o lugar que lhe é igual é o próprio ao
ponto. Se portanto o anjo, no seu movimento, atravessa uma posição média, necessariamente há-de
percorrer pontos infinitos, no seu movimento, o que é impossível.

2. Demais. — O anjo tem uma substancia mais simples do que a nossa alma. Ora, esta pode, pelo
pensamento, passar de um extremo a outro sem passar pelo meio; assim, posso pensar na Gália e
depois na Síria, sem pensar na Itália, que está no meio. Logo, com maioria de razão, pode o anjo passar
de um extremo a outro sem passar pelo meio.
Mas, em contrario, se o anjo se move de um lugar para outro, quando tiver chegado já não se move,
porque já se moveu. Ora, tudo o que já se moveu movia-se, precedentemente, e portanto movia-se em
algum lugar. Porém, se ainda não se movia, quando estava no ponto de partida, necessariamente havia
de mover-se quando estava no meio. E assim é forçoso que o anjo atravesse uma posição média.

SOLUÇÃO. — Como já ficou dito antes, o movimento local do anjo pode ser contínuo ou não contínuo.
— Se, pois, for contínuo, não pode o anjo mover-se de um extremo para outro, sem passar pelo meio.
Porque, como diz Aristóteles, o meio é por onde passa o que se move continuamente, antes de chegar
ao fim; pois, a ordem de anterioridade e posterioridade, no movimento contínuo, é correlata à de
anterioridade e posteridade na grandeza, como diz o mesmo Filosofo. Se, porém, o movimento não for
contínuo, é possível que o anjo atravesse de um extremo a outro, sem passar pelo meio. O que assim se
demonstra. Entre dois lugares extremos quaisquer há infinitos lugares médios, sejam esses lugares
divisíveis ou indivisíveis. Se indivisíveis, a questão é clara; pois, entre dois pontos quaisquer, há infinitos
pontos médios, porque dois pontos de modo nenhum podem se seguir um ao outro sem um meio
termo, como o prova o Filosofo. E o mesmo se deve necessariamente dizer dos lugares divisíveis, o que
se demonstra pelo movimento contínuo de qualquer corpo. Pois um corpo não se move de um lugar
para outro sem ser num determinado tempo. Ora, nesse tempo total, que mede o movimento do corpo,
não se podem tomar dois momentos nos quais o corpo que se move não esteja num lugar ou noutro;
pois, se em ambos os momentos ele estivesse num e mesmo lugar, resultaria que nesse lugar estaria em
repouso, porque o estar em repouso não é senão o estar num mesmo lugar em todos os momentos.
Ora, como entre o primeiro e o último momento do tempo, que mede o movimento, há
infinitosmomentos, resulta que, entre o primeiro lugar, donde começou o movimento, e o último, no
qual terminou, há infinitos lugares. O que também se declara, sensivelmente, da maneira seguinte. Seja,
pois, um corpo de um palmo, e seja de dois palmos o caminho que ele percorre. Ora, é manifesto que o
primeiro lugar, donde começa o movimento, é de um palmo; e o lugar onde ele termina é de outro
palmo. E é claro que quando o corpo começa a mover-se, paulatinamente abandona o primeiro palmo e
penetra no segundo. Portanto, na medida em que se divide a grandeza do palmo, na mesma se
multiplicam os lugares médios; porque, qualquer ponto tomado na grandeza do primeiro palmo é
princípio de um lugar, cujo termo é o ponto tomado na grandeza do outro palmo. Por onde, sendo a
grandeza divisível ao infinito, e sendo também os pontos de qualquer grandeza potencialmente
infinitos, segue-se que, entre dois lugares quaisquer há infinitos lugares médios. Ora, o móvel só pode
percorrer a infinidade destes pela continuidade do movimento; porque, assim como os lugares médios
são infinitos em potência, assim também se devem admitir, no movimento contínuo, certos infinitos em
potência. Se, portanto, o movimento não for contínuo, todas as suas partes se contarão como atuais. E,
por conseqüência, se um móvel qualquer se mover por um movimento não contínuo, resulta ou que não
percorre todos os meios, ou que se contam meios infinitos como atuais, o que é impossível. Logo, se o
movimento do anjo não for contínuo, não percorre todos os meios. Ora, mover-se de um extremos para
outro, sem passar pelo meio, pode convir ao anjo, não porém ao corpo. Porque este, sendo medido e
contido pelo lugar de necessidade há de obedecer às leis do lugar, no seu movimento. Mas a substância
do anjo não está sujeita ao lugar como contida por este, ao qual é superior, como continente; por isso,
no poder do anjo está o aplicar-se ao lugar, como quiser, quer por um meio termo, quer sem ele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lugar do anjo é considerado como lhe sendo igual, não
pela grandeza deste, mas pelo contato da virtude; e assim o dito lugar pode ser divisível e nem sempre
ser da natureza do ponto. Todavia os lugares médios, mesmo divisíveis, são infinitos, como ficou dito;
são, porém, percorridos pela continuidade do movimento, como resulta do que acaba de ser
demonstrado.

RESPOSTA À SEGUNDA. — Movendo-se localmente, a essência do anjo se aplica aos diversos lugares; a
essência da alma, porém, não se aplica às coisas nas quais pensa, antes nela é que estão as coisas
pensadas. Portanto não há ponto de comparação.

RESPOSTA À TERCEIRA. — No movimento contínuo, o ter-se movido não é parte, mas termo do mover-
se; donde resulta que o mover-se é anterior ao ter-se movido. E por isso é necessário que tal
movimento suponha uma posição média. Mas, no movimento não contínuo, o ter-se movido é parte,
como a unidade é parte do número; por onde, a sucessão dos diversos lugares é o que constitui tal
movimento, mesmo sem posições médias.

## Art. 3 — Se o movimento do anjo é instantâneo.
(I Sent., dist. XXXVII, q. 4, a. 3; Quodl. IX, q. 4; XI, q. 4)
O terceiro discute-se assim. — Parece que o movimento do anjo é instantâneo.

1. — Pois, quanto mais forte for a virtude do motor, e quanto menos lhe resistir o móvel, tanto mais
veloz será o movimento. Ora, a virtude do anjo, que se move a si mesmo, excede sem proporção a do
motor de qualquer outro corpo. Ora, como as velocidades são inversamente proporcionais ao tempo, e
como qualquer tempo é proporcional a outro, resulta que se um corpo qualquer se move no tempo, o
anjo se move no instante.

2. Demais. — O movimento do anjo é mais simples do que quaisquer mutações corpóreas. Ora, certas
são instantâneas, como a iluminação; quer esta não se realize sucessivamente, como a calefação; quer o
raio luminoso atinja o que está próximo primeiro que o remoto. Logo, com maior razão, o movimento
do anjo se realiza no instante.

3. Demais. — Se o anjo se move, no tempo, de um lugar para outro, é claro que, no último instante
desse tempo, está no ponto de chegada. E assim, em todo o tempo precedente, esteve ou num lugar
imediatamente precedente, considerado como ponto de partida, ou, parte, em um e, parte, em outro.
Se, porém, se der esta última hipótese, segue-se que o anjo é divisível, o que é impossível. Logo, em
todo o tempo precedente, esteve no ponto de partida. E, logo, aí repousa, pois, estar em repouso é
estar sempre no mesmo lugar, como já se disse. Donde se segue que o anjo não se move senão no
último instante do tempo.
Mas, em contrario, em toda mutação, há posições anteriores e posteriores. Ora, a prioridade e a
posteridade, no movimento, contam-se pelo tempo. Logo, todo movimento se realiza no tempo, mesmo
o do anjo, pois neste há posições anteriores e posteriores.

SOLUÇÃO. — Alguns disseram que o movimento local do anjo é instantâneo; pois, movendo-se ele de
um lugar para outro, esteve, em todo o tempo precedente, no ponto de partida; porém, no último
instante desse tempo está no ponto de chegada. E nem é preciso haver um meio entre esses dois
pontos, assim como nenhum meio há entre o tempo e o termo do mesmo; ao passo que, entre
dois momentos do tempo, há um meio. E por isso diziam não ser possível admitir-se um último instante,
em que o anjo estava no ponto de partida; assim como na iluminação e na geração substancial do fogo
não se pode admitir um último instante em que o ar foi tenebroso, ou em que a matéria esteve sob a
privação da forma ígnea, mas, sim, um último tempo tal que, no seu termo, há luz no ar ou forma ígnea
na matéria. Assim, a iluminação e a geração substancial chamam-se movimentos instantâneos.
Mas tal explicação não colhe no caso vertente; o que assim se demonstra. Da natureza do corpo em
repouso é não estar em lugares diferentes, em tempos diferentes; logo, em qualquer dos instantes no
primeiro, no médio ou no último — do tempo que mede o repouso, o corpo está no mesmo lugar. Mas
da essência do movimento é que o móvel esteja em lugares diferentes, em tempos diferentes, e,
portanto, em posição diversa em qualquer instante do tempo que mede o movimento. Donde, no
último momento, há-de o corpo ter uma forma que antes não tinha e, assim, é claro que permanecer
sempre em alguma coisa, por ex., na brancura, é estar nela em qualquer instante de determinado
tempo. E, por isso, não é possível que um móvel em todo tempo precedente repouse no ponto de
partida e esteja, no último instante do seu tempo, no ponto de chegada. Mas isto é possível no
movimento, porque mover-se num tempo total qualquer não é estar na mesma posição em qualquer
instante desse tempo. Portanto, todas as mutações instantâneas são termos do movimento contínuo,
assim como a geração é o termo da alteração da matéria e a iluminação, o do movimento local do corpo
iluminador. Porém o movimento local do anjo não é o termo de nenhum outro movimento contínuo,
mas é um movimento próprio independente. Donde, é impossível dizer-se que o anjo estava, num
tempo total, em certo lugar, e, no último instante, em outro; mas é necessário determinar um instante
em que esteve, ultimamente, no lugar precedente. Onde, porém, há muitos momentos sucedendo uns
aos outros, ai há necessariamente tempo, pois este não é senão a sucessão do anterior e do posterior
no movimento. Donde resulta que o movimento do anjo se realiza no tempo — contínuo se o seu
movimento for contínuo; não contínuo, se assim o for. Pois tal movimento pode realizar-se desses dois
modos, como já se disse. Ora, a continuidade do tempo provém da do movimento, como diz o Filósofo.
Mas esse tempo, contínuo ou não, não é idêntico ao que mede o movimento do céu e pelo qual se
medem todos os seres corpóreos, donde resulta a mutabilidade deles. Pois, o movimento do anjo não
depende de tal movimento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Se o tempo do movimento do anjo não for contínuo,
mas uma sucessão dos instantes mesmos, não terá proporção com o tempo contínuo, que mede o
movimento dos seres corpóreos, pois não tem a mesma natureza deste. Se porém for continuo, terá a
proporção dita, não por causa do motor e do móvel, mas por causa das grandezas nas quais se opera o
movimento. — Além disso, a velocidade do movimento do anjo não depende da quantidade da sua
virtude, mas da determinação da sua vontade.

RESPOSTA À SEGUNDA. — A iluminação é termo do movimento e é alteração; não é porém, movimento
local como significando que a luz se move primeiro para o que lhe é próximo do que para o remoto. Ora,
o movimento do anjo é local e não é termo do movimento. Por onde, não há símile.

RESPOSTA À TERCEIRA. — Essa objeção é procedente em relação ao tempo continuo. Ora, o tempo do
movimento do anjo pode ser não continuo; e assim o anjo pode, em um instante, estar num lugar e, em
outro instante, noutro lugar, sem que exista nenhum tempo intermediário. Se, porém, o tempo do
movimento do anjo for continuo, este, em todo o tempo precedente ao último instante, move-se por
infinitos lugares, como antes já se expôs. Está, porém, parte, em um dos lugares contínuos e, parte, em
outro; não que a substância angélica seja divisível, mas que se aplica a uma parte do primeiro lugar e a
uma do segundo, como também já se disse antes.