# Questão 118: Da geração da alma humana.
Em seguida deve-se tratar da geração do homem. E primeiro, quanto à alma. Segundo, quanto ao corpo.
Sobre a primeira questão três artigos se discutem:

## Art. 1 — Se a alma sensitiva é transmitida com o sêmen ou por criação de Deus.
O primeiro discute-se assim. — Parece que a alma sensitiva não é transmitida com o sêmen, mas por
criação de Deus.

1. — Pois, como nada é gerado, senão da matéria, a substância perfeita, não composta de matéria e
forma, não pode ser gerada, mas criada. Ora, a alma sensitiva é uma substância perfeita; do contrário
não poderia mover o corpo; e sendo a forma deste, não é composta de matéria e forma. Logo, começa a
existir, não por geração, mas, por criação.

2. Demais. — O princípio da geração, nos seres vivos, está na potência geratriz, que, sendo uma das
virtudes da alma vegetativa, é inferior à alma sensitiva. Ora, como nada pode ultrapassar a ação da sua
espécie, a alma sensitiva não pode ser causada por virtude geratriz do animal.

3. Demais. — Como o gerador gera o seu semelhante, necessário é que a forma do gerado esteja
atualmente na causa da geração. Ora, nem a alma sensitiva, em si, nem nenhuma parte sua, está
atualmente no sêmen; porque qualquer parte dessa alma só pode estar em alguma parte do corpo e,
não há no sêmen nenhuma partícula do corpo, porque não há nenhuma que não seja gerada do sêmen
e por virtude dele. Logo, a alma sensitiva não é causada pelo sêmen.

4. Demais. — Se há no sêmen algum princípio ativo da alma sensitiva, esse princípio permanece ou não,
depois do animal gerado. Ora, não pode permanecer. Pois, ou se identificaria com á alma sensitiva do
animal gerado, o que é impossível, porque então identificar-se-ia o gerador com o gerado, e o que faz
com o que é feito, ou seria diferente, o que também é impossível, porque, como já se demonstrou, um
animal não pode ter senão um principio formal, que é a alma. Mas também, é impossível não
permanecer, porque o é que um agente atue para a corrupção de si mesmo. Logo, a alma sensitiva não
pode ser gerada do sêmen.
Mas, em contrário. — A virtude do sêmen está para os animais dele gerados, como a dos elementos do
mundo, para os animais deles produzidos — p. ex., os gerados da putrefação. Ora, nestes últimos as
almas são produzidas pela virtude dos elementos, conforme a Escritura: Produzam as águas répteis de
alma vivente. Logo, as almas dos animais gerados do sêmen são produzidas pela virtude deste.

SOLUÇÃO. — Certos disseram que as almas sensitivas dos animais são criadas por Deus; opinião
admissível, se a alma sensitiva fosse um ser subsistente, com existência e operação próprias; e então,
teria que ser feita. E como o ser simples e subsistente não pode ser feito senão por criação, essa alma
existiria, criada. — Mas, como resulta do que já se estabeleceu, é falso o ponto de partida, que a alma
sensitiva tenha existência e operação próprias; porque então não se corromperia com a corrupção do
corpo.
Por onde, não sendo forma subsistente, existe como as outras formas corpóreas às quais em si mesmas,
não é devida a existência; diz-se que existem porque fazem existir os compostos subsistentes. Por onde,
estes é que devem ser feitos. E como o gerador é semelhante ao gerado, necessário é que naturalmente
a alma sensitiva e formas semelhantes tenham a existência produzida por certos agentes corpóreos, que
transmutam a matéria, da potência para o ato, por alguma virtude corpórea neles existentes. Ora,
quanto mais potente é o agente, tanto mais pode difundir a sua ação a maior distância; assim, quanto
mais quente for um corpo tanto mais longe alcançará a sua calefação. Por onde, os corpos não-vivos,
sendo inferiores, na ordem da natureza, geram o semelhante, certo, não por meio de outro corpo, mas
por si mesmos; assim, o fogo gera por si mesmo o fogo. Mas os corpos vivos, mais potentes, geram o
semelhante sem e com intermédio de outro corpo. Sem intermédio na operação nutritiva, pela qual a
carne gera a carne; com intermédio, no ato da geração, porque da alma geratriz deriva a virtude ativa
do sêmen, mesmo do animal, ou da semente da planta, assim corno, do agente principal, deriva, a
virtude motora do instrumento. E assim corno não difere dizer que algo é movido pelo instrumento ou
pelo agente principal, assim, não difere, que a alma do gerado seja causada pela do gerador ou pela
virtude desta derivada, existente no sêmen.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A alma sensitiva não é uma substância perfeita
subsistente por si. E como já se tratou disto antes, não é necessário repetir aqui.

RESPOSTA À SEGUNDA. — A virtude geratriz não gera somente por virtude própria, mas pela de toda a
alma, da qual é potência. E por isso, a virtude geratriz da planta gera a planta, e a do animal, o animal.
Pois, quanto mais perfeita for a alma tanto mais a virtude geratriz se ordena para a perfeição dos
efeitos.

RESPOSTA À TERCEIRA. — A virtude ativa do sêmen, derivada da alma geratriz, é por assim dizer moção
dessa alma, não sendo alma, ou parte da alma, senão virtualmente; assim como na serra ou no machado
não está a forma do leito, mas uma certa moção para tal forma. Por onde, não é necessário que essa
virtude ativa tenha um órgão atual, mas funda-se no próprio espírito incluso no sêmen, que é
espumoso, como o atesta a sua brancura. E nesse espírito há também certo calor, por virtude dos
corpos celestes, por cuja virtude também os agentes inferiores agem, tendendo para a espécie, como já
se disse. E como nesse espírito concorre a virtude da alma com a celeste, diz-se que o homem, com o
sol, gera o homem. O calor elementar porém comporta-se instrumentalmente em relação à virtude da
alma, como também em relação à virtude nutritiva, segundo diz Aristóteles.

RESPOSTA À QUARTA. — Nos animais perfeitos, gerados pelo coito, a virtude ativa está no sêmen do
macho, conforme o Filósofo; e a fêmea ministra a matéria do feto. E nesta, logo, desde o princípio,
existe a alma vegetal, por ato não segundo, mas, primeiro; assim como a alma sensitiva existe nos
adormecidos. Pois, quando começa a alimentar-se, já opera atualmente. Por onde, essa matéria se
transmuta pela virtude existente no sêmen do macho até que seja levada ao ato da alma sensitiva; e
não que a virtude mesma, que existe no sêmen, venha a ser a alma sensitiva, porque então identificar-
se-ia o gerador com o gerado e haveria, antes, nutrição e crescimento, do que geração, como diz o
Filósofo. Porém, depois que, por virtude do princípio ativo, que existia no sêmen, foi produzida a alma
sensitiva do gerado, quanto à parte principal, então a alma sensitiva do ser gerado começa a operar,
como complemento do corpo próprio, nutrindo-se e crescendo. Porém, a virtude ativa, existente, no
sêmen, deixa de existir com a dissolução deste e como o evanesci mento do seu espírito. Nem é isto
inconveniente, porque essa virtude não é o agente principal, mas o instrumental; ora, a moção
instrumental cessa com a existência do efeito.

## Art. 2 — Se a alma intelectiva é causada pelo sêmen.
(Supra. q. 90, a. 2; II Sent., dist. XVIII, q. 2, a. I; II Cont. Gent., cap. LXXXVI, LXXXVIII, LXXXIX; De Pot., q. 3,
a. 9; Quodl. XI, q. 5, ad I, 4; XII, q. 7, a . 2; Compend. Theol., cap. XCIII; Ad Rom., cap. V. Iect. III).
O segundo discute-se assim. — Parece que a alma intelectiva é causada pelo sêmen.

1. — Pois, diz a Escritura: Todas as pessoas que tinham saído da coxa de Jacó eram ao todo sessenta e
seis. Ora tudo o que é gerado do homem o é pelo sêmen. Logo, também a alma intelectiva.

2. Demais. — Como já se demonstrou, o homem tem uma mesma alma substancial intelectiva, sensitiva
e nutritiva. Ora, a alma sensitiva do homem, bem como a dos animais, é gerada do sêmen; por onde, diz
o Filósofo, que o animal não é feito simultaneamente com o homem, mas antes, é feito o animal, com
alma sensitiva. Logo, também a alma intelectiva é causada pelo sêmen.

3. Demais. — É de um e mesmo agente a ação que termina na forma e na matéria; do contrário a
matéria e a forma não constituiriam, em si, uma unidade. Ora, a alma intelectiva é forma do corpo
humano, constituído por virtude do sêmen. Logo, também a alma intelectiva é causada por essa mesma
virtude.

4. Demais. — O homem gera o seu especificamente semelhante. Ora, a espécie humana é constituída
pela alma racional. Logo, esta provém do gerador.

5. Demais. — É inadmissível dizer que Deus coopera com os pecadores. Ora, se as almas racionais
fossem criadas por Deus, ele às vezes cooperaria com os adúlteros, cujo coito ilícito pode ser fecundo.
Logo, as almas racionais não são criadas por Deus.
Mas, em contrário, diz um autor: as almas racionais não são geradas pelo coito.

SOLUÇÃO. — É impossível a virtude ativa, existente na matéria, estender a sua ação até a produção de
um efeito imaterial. Ora, é manifesto que o princípio intelectivo do homem, transcende a matéria, pois,
tem uma operação sem nada de comum com o corpo. E portanto, é impossível que a virtude do sêmen
produza esse princípio. Também, semelhantemente, porque a dita virtude age pela alma do gerador, a
qual é um ato do corpo, que usa deste, para operar. Ora, pela operação do intelecto, a alma nada tem
de comum com o corpo. Por onde, a virtude do princípio intelectivo, como tal, não pode provir do
sêmen. E por isso, diz o Filósofo: Conclui-se que o intelecto só pode vir de fora. E semelhante mente, a
alma intelectiva, cuja operação vital é independente do corpo, é subsistente, como já se estabeleceu; e
portanto, deve ter existência e ser feita. Mas, como é uma substância imaterial, não pode ser causada
por geração, senão só por criação de Deus. Ensinar, pois, que a alma intelectiva é gerada, é considerá-la
não subsistente, e por conseqüência, como havendo de corromper-se com o corpo. Por onde, é herético
dizer que a alma intelectiva é gerada do sêmen.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O passo citado emprega, por sinédoque, a parte pelo
todo, i. é, a alma, por todo o homem.

RESPOSTA À SEGUNDA. — Alguns disseram, que as operações vitais, do embrião não provêm da alma
deste, mas da alma da mãe, ou da virtude do sêmen. — Mas, tudo é falso. Pois, as operações vitais,
como sentir, nutrir-se e crescer, não podem provir de princípio extrínseco. Por onde, deve-se dizer, que
a alma preexiste no embrião, sendo, a princípio, nutritiva; depois, sensitiva e, enfim, intelectiva.
Dizem porém alguns, que à alma vegetativa, existente a princípio, sobrevém a sensitiva; a esta, a
intelectiva. E assim, há no homem três almas, sendo uma potencial em re1ação à outra. — O que já se
refutou antes.
Por onde, dizem outros, que a mesma alma, a princípio somente vegetativa, em seguida, por ação da
virtude do sêmen, transforma-se em sensitiva; e por fim, transforma-se em intelectiva, não por virtude
ativa do sêmen, mas pela de um agente superior, Deus, que ilumina de fora. Sendo por isso que o
Filósofo diz que o intelecto vem de fora. — Mas esta opinião pode subsistir. — Porque nenhuma forma
substancial é susceptível de aumento nem de diminuição; mas a superadição de uma perfeição maior
produz outra espécie, assim como adição da unidade causa outra espécie numérica. Ora, não é possível
que uma mesma forma pertença a diversas espécies. — Segundo, porque havia de se seguir que a
geração do animal é um movimento contínuo, procedendo, paulatinamente, do imperfeito para o
perfeito, como acontece na alteração. — Terceiro, porque resultaria que a geração do homem ou do
animal não é em si geração, por ser o sujeito dela um ser atual. Se, pois, desde o princípio há na matéria
da geração uma alma vegetal, que depois é paulatinamente levada até à perfeição, haverá sempre a
adição de uma perfeição superveniente, sem corrupção da precedente, o que vai contra a essência da
geração, em si mesma. — Quarto, porque o causado pela ação de Deus é algo de subsistente — e então,
há-de ser diferente, necessária e essencialmente, da forma preexistente, que não era subsistente,
voltando, por conseqüência, a opinião dos que admitem várias almas no corpo; ou não é nada de sub-
sistente, mas uma perfeição da alma preexistente — e então, necessariamente se segue que a alma
intelectiva há de corromper-se uma vez corrupto o corpo, o que é impossível.
Há ainda outra opinião: a daqueles que dizem terem todos um só intelecto. E esta já foi refutada antes.
Por onde, deve dizer-se que, sendo a geração de um ser a corrupção de outro, necessário é admitir que,
tanto no homem como nos animais, advindo uma mais perfeita forma, corrompe-se a anterior; de modo
que a forma conseqüente tem tudo o que tinha a antecedente, e ainda mais. E assim, depois de muitas
gerações e corrupções, é que vem a existir a última forma substancial, tanto no homem como nos
animais. O que aparece sensivelmente nos animais gerados da putrefação. Por onde, deve-se dizer que
a alma intelectiva é criada por Deus, no último termo da geração humana, e é simultaneamente
sensitiva e nutritiva, uma vez corruptas as formas preexistentes.

RESPOSTA À TERCEIRA. — A objeção colhe relativamente aos diversos agentes não ordenados entre si.
Mas se forem muitos os agentes ordenados, nada impede que a virtude do agente superior alcance até
a última forma; alcançando as virtudes dos agentes inferiores só alguma disposição da matéria. Assim,
ao passo que a virtude do sêmen dispõe a matéria, a da alma dá a forma, na geração do animal. Ora, é
manifesto, pelo que já ficou estabelecido, que toda a natureza corpórea age como instrumento da
virtude espiritual, e sobretudo de Deus. Por onde, nada impede que a formação corpo resulte de alguma
virtude corpórea, sendo a alma intelectiva produzida só por Deus.

RESPOSTA À QUARTA. — O homem gera o seu semelhante, dispondo, pela virtude do seu sêmen, a
matéria, a receber tal forma determinada.

RESPOSTA À QUINTA. — Na ação dos adúlteros, com o que é da natureza, e portanto bom, Deus
coopera. Com o que porém é proveniente da volúpia desordenada, e portanto mau, Deus não coopera.

## Art. 3 — Se as almas humanas foram criadas simultaneamente, no princípio do mundo.
(Supra, q. 90, a. 4; I Sant., dist. VIII. q. 5. a. 2, ad 6; II Sent., dist. III, q. I, a. 4, ad I; dist. XVII, q. 2, a. 2;· II
Cont. Gent., cap.LXXXIII, LXXIV; De Pot., q.3, a. 10; De Malo, q. 5, a. 4; ad Hebr., cap. I, lect. IV).
O terceiro discute-se assim. — Parece que as almas humanas foram criadas simultaneamente, no
princípio do mundo.

1. — Pois, diz a Escritura: Deus descansou de toda a obra que fizera. Ora, tal não se daria se cada dia
Deus criasse novas almas. Logo, todas foram criadas simultaneamente.

2. Demais. — As substâncias espirituais concorrem, especialmente, para a perfeição do universo. Se,
pois, as almas fossem criadas simultaneamente com os corpos, inumeráveis substâncias espirituais
seriam acrescentadas quotidianamente à perfeição do mesmo; e então, este, desde o princípio, seria
imperfeito. O que vai contra aquilo da Escritura: Deus acabou a obra que tinha feito.

3. Demais. — Fim e princípio de uma mesma cousa se correspondem. Ora a alma intelectiva permanece,
uma vez destruído o corpo. Logo; começou a existir antes dele.
Mas, em contrário, diz um autor, que a alma é criada simultaneamente com o corpo.

SOLUÇÃO. — Alguns ensinaram que é acidental à alma intelectiva estar unida ao corpo, considerando-a
como da mesma condição que as substâncias espirituais, não unidas a corpo. Donde concluíram que as
almas dos homens foram criadas, no princípio, simultaneamente com os anjos.
Mas esta opinião é falsa. — Primeiro, quanto ao ponto de partida. Pois, se fosse acidental à alma estar
unida ao corpo, resultaria que o homem, constituído por essa união, seria um ser acidental, ou que a
alma seria o homem — tudo o que é falso, como já se demonstrou. — E além disso, que a alma humana
não é da mesma natureza que os anjos, a própria diversidade, nos modos de inteligir, o demonstra,
como se estabeleceu antes. Assim, o homem intelige recebendo os dados, dos sentidos, e voltando-se
para os fantasmas, como antes se demonstrou. E portanto, a sua alma necessita estar unida ao corpo,
do qual precisa para a operação da parte sensitiva. O que não se pode dizer do anjo. — Segundo, é falsa
a opinião em si mesma. Pois, se é natural à alma estar unida ao corpo, existir sem corpo vai-lhe contra a
natureza, e assim existindo, não realiza a perfeição desta. Ora, é inadmissível que Deus começasse a sua
obra por criaturas imperfeitas e pelo que é contra a natureza; pois, não fez o homem sem mãos ou sem
pés, que são partes naturais dele. E com maior razão, não fez a alma sem o corpo.
Mas, se alguém disser que não é natural à alma estar unida ao corpo, necessário é inquirir à causa
porque está unida. Ora, é necessário admitir-se, que o está por sua vontade ou por outra causa. —
Por sua vontade, não é admissível. Primeiro, porque essa vontade seria irracional, se, não precisando do
corpo, quisesse estar unida com ele; se porém precisasse, ser-lhe-ia natural estar com ele unida, porque
a natureza não falha no necessário. Segundo, porque nenhuma razão havia para a vontade da alma,
criada no princípio do mundo, decidir, só agora, depois de tanto tempo, a unir-se ao corpo; pois, a
substância espiritual, escapando à ação das revoluções do céu, está fora do tempo. Terceiro, porque
resultaria que é por acaso que uma determinada alma está unida a um determinado corpo; pois, para
isso, é necessário o concurso de duas vontades — a da alma adveniente e a do homem gerador. — Se
porém é contra a vontade, e contra a sua natureza, que está unida ao corpo, necessário é que tal se dê
por uma causa violenta, e então isso lhe há-de ser penoso e triste, o que é conforme o erro de Orígenes,
que dizia estarem as almas unidas ao corpo, como pena do pecado.
Por onde, todas essas conseqüências sendo inadmissíveis, deve-se admitir, absolutamente, que as almas
não foram criadas antes dos corpos, mas são criadas ao mesmo tempo que são infundidas neles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que Deus cessou, no sétimo dia, não de fazer
qualquer obra, pois, diz a Escritura: Meu Pai opera até hoje; mas, de fazer novos gêneros e espécies de
cousas, que ainda não preexistissem de certo modo nas primeiras obras. Assim, pois, as almas
atualmente criadas preexistiam, pela semelhança específica, nas primeiras obras, nas quais foi criada a
alma de Adão.

RESPOSTA À SEGUNDA. — Quanto ao numero dos indivíduos, algo pode ser acrescentado, cada dia, à
perfeição do universo, não, porém, quanto ao elas espécies.

RESPOSTA À TERCEIRA. — O permanecer a alma sem o corpo resulta da corrupção do corpo,
subseqüente ao pecado. E por isso não era conveniente que, por ele, começassem as obras de Deus,
porque, como diz a Escritura: Deus não fez a morte, mas os ímpios a chamaram para si com mãos e
palavras.