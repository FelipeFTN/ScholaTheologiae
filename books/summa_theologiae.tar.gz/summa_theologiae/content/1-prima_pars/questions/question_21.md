# Questão 21: Da justiça e da misericórdia de Deus
Depois de termos tratado do amor de Deus, devemos tratar da sua justiça e da sua misericórdia. E nesta
questão discutem-se quatro artigos:

## Art. 1 — Se em Deus há justiça.
(V Sent., dist. XLVI, q. 1, a. 1. qª 1; I Cont. Gent., cap. XCIII; De Div. Nom., cap. VIII, lect IV).
O Primeiro discute-se assim. — Parece que em Deus não há justiça.

1. — Pois, a justiça se divide por oposição à temperança. Ora, em Deus não há temperança. Logo, nem
justiça.

2. Demais. — Quem faz tudo ao bel prazer da sua vontade não obra segundo a justiça. Ora, como diz o
Apóstolo (Ef 1, 11), “Deus obra todas, as coisas segundo o conselho da sua vontade”. Logo, não se lhe
deve atribuir justiça.

3. Demais. — É ato de justiça restituir o devido. Ora, Deus a ninguém é devedor. Logo, não lhe cabe a
justiça.

4. Demais. — Tudo o que há em Deus é a sua essência. Ora, isto não convém à justiça, pois, conforme
Boécio,o bem respeita à essência, mas a justiça, ao ato. Logo, a Deus não convém à justiça.
Mas, em contrário, a Escritura (Sl 10, 8): O Senhor é justo e ele amou ajustiça.

SOLUÇÃO. — Há duas espécies de justiça. Uma consistente no mútuo dar e receber; p. ex., a que
consiste na compra e venda em outros tratos ou trocas semelhantes. Esta é chamada pelo Filósofo
justiça comutativa ou reguladora das trocas ou tratos; e essa não convém a Deus, segundo aquilo do
Apóstolo (Rm 11, 35): Quem lhe deve alguma coisa primeiro para esta lhe haver de ser
recompensada? Outra consiste na distribuição e se chama justiça distributiva, pela qual um governador
ou administrador dá segundo a dignidade de cada um. Ora, assim como a ordem devida, na família ou
em qualquer multidão governada, demonstra a justiça do governador, assim também a ordem do
universo manifesta, tanto nos seres naturais, como nos dotados de vontade, a justiça de Deus. Por isso
diz Dionísio: Devemos ver a verdadeira justiça de Deus no distribuir ele a todos os seres segundo o que
convém à dignidade de cada um, e no conservar cada natureza na sua ordem própria e virtude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Das virtudes morais, umas concernem às paixões; assim,
a temperança, à concupiscência; a fortaleza, ao temor e à audácia; a mansidão, à ira. Tais virtudes só se
podem atribuir a Deus metaforicamente, porque nele nem há paixões, como já demonstramos, nem
apetite sensitivo, que é o sujeito dessas virtudes, como diz o Filósofo. Porém, outras virtudes morais
concernem às operações; assim, quanto ao dar e ao receber, a justiça, a liberalidade e a magnificência. E
tais virtudes não existem na parte sensitiva, mas na vontade; por isso, nada impede sejam atribuídas a
Deus. Não, contudo, no concernente às ações civis, mas as convenientes a Deus. Pois, seria ridículo
louvar a Deus pelas suas virtudes políticas, como diz o Filósofo.

RESPOSTA À SEGUNDA. — Sendo o bem inteligido o objeto da vontade, Deus só pode querer aquilo que
está na razão da sua sabedoria; e esta é como a lei da justiça, pela qual a sua vontade é reta e justa. Por
onde, o que faz por sua vontade justamente o faz; assim como nós fazemos justamente o que fazemos
de acordo com a lei; nós, porém, pela lei de um superior, ao passo que Deus, pela sua própria lei.

RESPOSTA À TERCEIRA. — A cada um é devido o que lhe pertence. Ora, dizemos que uma coisa
pertence a alguém quando se lhe ordena. Assim, o servo pertence ao senhor e não, inversamente; pois,
é livre quem é causa com relação a si próprio. Por onde, a palavra devido implica uma certa ordem de
exigência ou necessidade de um ser em relação a outro, ao qual se ordena. Ora, há uma dupla ordem a
se considerar nas coisas. Uma, pela qual uma criatura se ordena para outra; assim, as partes, ao todo, os
acidentes, às substâncias, e cada coisa, ao seu fim. Outra, pela qual todas as criaturas se ordenam para
Deus. Por onde, o devido também pode ser considerado à dupla luz, quanto à obra divina. Ou enquanto
algo é devido a Deus, ou, a uma criatura. E de um e outro modo, Deus paga o devido. Pois, é devido a
Deus o cumprirem os seres aquilo que a sua sapiência e a sua vontade estabeleceram e que manifesta a
sua bondade. E deste modo a justiça de Deus concerne à sua dignidade, atribuindo-se a si o que lhe é
devido.
Por outro lado, é devido a uma criatura o ter aquilo que se lhe ordena, como ao homem ter mãos e lhe
servirem os outros animais. E assim, também Deus faz justiça, dando-lhe o devido, segundo a exigência
da natureza e à condição de cada uma. Mas este débito depende do primeiro, porque a cada criatura é
devido o que se lhe ordena pela ordem da divina sapiência. E, embora Deus dê, deste modo, o devido a
cada uma, contudo, não é devedor, pois, não se ordena para os outros seres, mas estes, para ele. Por
isso, dizemos que a justiça é, umas vezes, em Deus, conveniência com a sua bondade, e outras,
retribuição dos méritos. E a um e outro modo alude Anselmo dizendo: És justo punindo os maus, por
isso lhes convir aos méritos; mas também o és perdoando-lhes, por convir isso à tua bondade.

RESPOSTA À QUARTA. — Por dizer respeito ao ato, não resulta que a justiça deixe de ser a essência de
Deus, pois, também aquilo que é da essência de um ente pode ser princípio de ação. Mas, o bem nem
sempre concerne ao ato, pois, dizemos que um ser é bom, não somente pela ação, mas também pela
perfeição essencial. Por isso, no mesmo lugar, se diz que o bem está para o justo, como o geral, para o
especial.

## Art. 2 — Se a justiça de Deus é verdade.
(IV Sent., dist. XLVI, q. 1, a. 1, qª 3).
O segundo discute-se assim. — Parece que a justiça de Deus não é verdade.

1. — Pois, a justiça pertence à vontade, da qual é a retidão, como diz Anselmo. Ora, a verdade pertence
ao intelecto, segundo o Filósofo. Logo, a justiça não pertence à verdade.

2. Demais. — A verdade, segundo o Filósofo, é virtude diferente da justiça. Logo, ela não se inclui em a
noção da justiça.
Mas, em contrário, a Escritura (Sl 84, 11): A misericórdia e a verdade se encontraram. Onde, verdade é
tomada na acepção de justiça.

SOLUÇÃO. — A verdade consiste na adequação da inteligência com o objeto, conforme dissemos. Ora, o
intelecto que é causa do objeto é dele a regra e a medida; dá-se, porém, o inverso com o intelecto, que
tira das coisas a sua ciência. Portanto quando as causas são a medida e a regra do intelecto, a verdade
consiste na adequação deste com aquele, e tal é o nosso caso. Assim, a nossa opinião e o nosso
conhecimento são verdadeiros ou falsos conforme exprimem o que a coisa é ou que não é. Mas, quando
o intelecto é a regra ou a medida das coisas, a verdade consiste na adequação delas com o intelecto;
assim, também dizemos verdadeira a obra do artista quando concorda com a arte. Ora, os artificiados
estão para a arte, como as obras justas, para a lei, com a qual concordam. Por onde, a justiça de Deus,
que constitui a ordem das coisas, conforme a idéia da sua sabedoria, que lhes serve de lei, chama-se
convenientemente verdade. Do mesmo modo também se diz que em nós há a verdade da justiça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A justiça, quanto à lei reguladora, pertence à razão ou
intelecto; mas quanto ao império pelo qual as obras são reguladas pela lei, pertence à vontade.

RESPOSTA À SEGUNDA. — A verdade a que se refere o Filósofo, no lugar citado, é uma virtude pela qual
nos mostramos, em palavras e obras, tais quais somos. Por isso, consiste na conformidade do sinal com
a sua significação; não, porém, na conformidade do efeito com a causa e a regra, como dissemos a
respeito da verdade da justiça.

## Art. 3 — Se a Deus convém a misericórdia.
(IIa IIae, q. 30, a. 4; IV Sent., dist. XLVI, q. 2, a. 1, qa 1; I Cont. Gent., cap. XCI: Psalm.,XXIV).
O terceiro discute-se assim. — Parece que a Deus não convém a misericórdia.

1. — Pois, a misericórdia é uma espécie de tristeza, como diz Damasceno. Ora, em Deus não há tristeza.
Logo, nem misericórdia.

2. Demais. — A misericórdia é preterição da justiça. Ora, Deus não pode preterir as exigências da sua
justiça, conforme aquilo da Escritura (2 Tm 2, 13): Se não cremos, ele permanece fiel; não pode negar-se
a si mesmo. Ora, negar-se-ia a si mesmo, diz a Glosa, se negasse o que disse. Logo, não lhe convém a
misericórdia.
Mas, em contrário, a Escritura (Sl 110, 4): O Senhor é misericordioso e compassivo.

SOLUÇÃO. — A misericórdia máxima devemos atribuí-la a Deus; mas, quanto ao efeito e não, quanto ao
afeto da paixão. Para evidenciá-lo, é mister considerar que misericordioso é quem possui coração
comiserado, por assim dizer, por contristar-se com a miséria de outrem, como se fora própria e
esforçar-se por afastá-la como se esforçaria por afastar a sua própria. Tal é o efeito da misericórdia. Ora,
não é próprio de Deus contristar-se com a miséria de outrem. Mas, é muito próprio dele afastá-la,
entendendo-se por miséria qualquer defeito. Pois, defeitos não se eliminam senão pela perfeição de
alguma bondade. Ora, Deus, como dissemos, é a origem primeira da bondade.
Devemos porém ponderar que comunicar perfeições às causas pertence tanto à bondade divina, como à
justiça, à liberalidade e à misericórdia, mas segundo razões diversas. Assim, a comunicação das
perfeições, considerada absolutamente, pertence à bondade, como já demonstramos. Mas, pela justiça,
como mostramos, Deus comunica perfeições proporcionadas às coisas. Ao passo que pela liberalidade
ele lhes da perfeições, não visando a sua utilidade, mas só por mera bondade. Finalmente, pela
misericórdia, as perfeições dadas às coisas por Deus eliminam-lhes todos os defeitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procede, considerando-se a misericórdia em
relação ao afeto da paixão.

RESPOSTA À SEGUNDA. — Deus age misericordiosamente, quando faz alguma coisa não em contrário,
mas, além da sua justiça. Assim, quem desse duzentos dinheiros ao credor, ao qual só deve cem, não
pecaria contra a justiça, mas agiria liberal ou misericordiosamente. O mesmo se daria com quem
perdoasse a injúria, que lhe foi feita; pois, quem perdoa, de certo modo dá; e por isso o Apóstolo chama
ao perdão, doação (Ef 4, 32): Perdoai-vos uns aos outros como também Cristo vos perdoou. Donde
resulta que, longe de suprimir a justiça, a misericórdia é a plenitude dela. Donde, o dizer a Escritura (Tg
2 ,13): A misericórdia triunfa sobre o justo.

## Art. 4 — Se há justiça e misericórdia em todas as obras de Deus.
(IV Sent., dist. XLVI, q. 2, a. 2, qª 2; II Cont. Gent., cap. XXVIII; De Verit., q. 28, a. 1, ad 8; Psalm., XXIV;
Rom., cap. XV, lect.I).
O quarto discute-se assim. — Parece que nem em todas as obras de Deus há misericórdia e justiça.

1. — Pois, umas se atribuem à misericórdia, como a justificação dos ímpios; outras, à justiça, como a
danação deles. Por isso, diz a Escritura (Tg 2, 13): Far-se-á juízo sem misericórdia aquele que não usou
de misericórdia. Logo, nem todas as obras de Deus manifestam a misericórdia e a justiça.

2. Demais. — O Apóstolo atribui a conversão dos Judeus à justiça e à verdade; a conversão dos gentios,
porém, à misericórdia (Rm 15, 8-9). Logo, nem em todas as obras de Deus há justiça e misericórdia.

3. Demais. — Muitos justos se afligem neste mundo. Ora, isto é injusto. Logo, em nem todas as obras de
Deus há justiça e misericórdia.

4. Demais. — É de justiça pagar o devido, e de misericórdia, socorrer à miséria; por onde, tanto a obra
de justiça como a de misericórdia pressupõe um objeto. Ora, a criação nada pressupõe. Logo, nela não
há misericórdia nem justiça.
Mas, em contrário, a Escritura (Sl 24, 10): Todos os caminhos do Senhor são misericórdia e verdade.

SOLUÇÃO. — Necessariamente descobrimos, em qualquer obra de Deus, a misericórdia e a verdade; se
tomarmos misericórdia no sentido de remoção de qualquer defeito. Embora nem todo defeito possa
chamar-se miséria, propriamente dita, mas somente o defeito da natureza racional, que é capaz de
felicidade; pois a esta se opõe a miséria.
E a razão dessa necessidade é a seguinte. Sendo o débito pago pela divina justiça um débito para com
Deus ou para com alguma criatura, nem um nem outro podem faltar em qualquer obra divina. Pois,
Deus nada pode fazer que não convenha à sua sapiência e à sua bondade; e, nesse sentido, dizemos que
algo lhe é devido. Semelhantemente, tudo quanto faz, nas criaturas, o faz em ordem e proporção
convenientes, e nisso consiste a essência da justiça. E, portanto, é necessário haja justiça em todas as
obras divinas.
Mas a obra da divina justiça sempre pressupõe a da misericórdia e nesta se funda. Pois, nada é devido a
uma criatura, senão em virtude dum fundamento preexistente ou previsto; o que, por sua vez
pressupõe um fundamento anterior. Ora, não sendo possível ir até o infinito, é necessário chegar a
algum que só dependa da bondade da divina vontade, que é o fim último. Assim, se dissermos que ter
mãos é devido ao homem, em virtude da alma racional, por seu lado, ter alma racional é necessário para
que exista o homem e este existe pela bondade divina. E assim a misericórdia se manifesta radicalmente
em todas as obras de Deus. E a sua virtude se conserva em tudo o que lhe é posterior, e mesmo aí obra
mais veementemente, pois a causa primária mais veementemente influi, que a segunda. Por isso, Deus,
pela abundância da sua bondade, dispensa o devido a uma criatura mais largamente do que o exigiriam
as proporções dela. Porque, para conservar a ordem da justiça, bastaria menos do que o conferido pela
divina bondade, excedente a toda a proporção da criatura.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Certas obras se atribuem à justiça e certas, à
misericórdia, porque mais veementemente se manifesta, numas a justiça e noutras, a misericórdia. E
contudo, na danação dos réprobos, manifesta-se a misericórdia não, certo, perdoando totalmente, mas
de algum modo, aliviando, por punir aquém do merecido. Por outro lado, na justificação do ímpio
manifesta-se a justiça, perdoando as culpas por causa do amor, que entretanto Deus infunde
misericordiosamente, como de Madalena se lê no Evangelho (Lc 7,47): perdoados lhe são seus muitos
pecados, porque amou muito.

RESPOSTA À SEGUNDA. — A justiça e a misericórdia de Deus se manifestam na conversão dos Judeus e
dos Gentios. Porém, na conversão daqueles, salvos em virtude das promessas feitas aos patriarcas,
manifesta-se um aspecto da justiça, que não se manifesta na conversão destes.

RESPOSTA À TERCEIRA. — Também em serem os justos punidos neste mundo, manifesta-se a justiça e a
misericórdia. Porque essas aflições os fazem expiar alguns pecados leves e mais os separam dos afetos
terrenos, elevando-os para Deus, conforme aquilo de Gregório: Os males que nos castigam neste
mundo, nos obrigam a ir para ti.

RESPOSTA À QUARTA. — Embora a criação nada pressuponha quanto à natureza das coisas, contudo
algo se lhes pressupõe, no conhecimento de Deus. E assim, também se manifestam as exigências da
justiça pelo receberem as coisas o ser, conforme a conveniência delas com a sapiência e a bondade
divina. E também, de certo modo, as da misericórdia, por passarem as coisas do não ser para o ser.