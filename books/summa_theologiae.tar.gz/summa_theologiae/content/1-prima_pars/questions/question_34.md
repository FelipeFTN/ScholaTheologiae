# Questão 34: Do Verbo.
Em seguida, devemos tratar da Pessoa do Filho. Ora, atribuem-se três nomes ao Filho, a saber, Filho,
Verbo e Imagem. Mas, a natureza do Filho fica tratada dependentemente da do Pai. Portanto, resta
tratarmos do Verbo e da Imagem. Sobre o Verbo discutem-se três artigos:

## Art. 1 — Se o Verbo, em Deus, é nome de pessoa.
(Ia. IIae., q. 93, a. 1. ad. 2; I Sent., dist. XXVII, q. 2, a. 2, qa. 1; De Pot., q. 9, a. 9, ad 7; De Verit., q. 4, a. 2;
a. 4, ad 4).
O primeiro discute-se assim. – Parece que o Verbo, em Deus, não é nome de pessoa.

1. – Pois, os nomes pessoais em Deus se predicam em sentido próprio, como Pai e Filho. Ora, em Deus, o
Verbo se predica metaforicamente, como diz Orígenes. Logo, o Verbo, em Deus, não é nome de pessoa.

2. Demais. – Segundo Agostinho, o verbo é o conhecimento com amor. E segundo
Anselmo, para o Sumo Espírito – dizer – nada mais é do que a intuição cogitativa. Ora, o conhecimento,
a cogitação e a intuição se predicam essencialmente, em Deus. Logo, o Verbo, em Deus, não significa
nome de pessoa.

3. Demais. – Da natureza do Verbo é o ser dito. Ora, segundo Anselmo, assim como o Pai o Filho e o
Espírito Santo são inteligentes, assim também são dicentes. E, semelhantemente, cada um deles é dito.
Logo, o nome de Verbo se predica, em Deus, essencial e não pessoalmente.

4. Demais. – Nenhuma pessoa divina é feita. Ora, o Verbo de Deus é feito. Pois, diz a Escritura (Sl 128,
8): Ofogo, o granizo, a neve, a geada, o espírito das tempestades, que executam a sua palavra. Logo, em
Deus, o verbo não é nome de pessoa.
Mas, em contrário, diz Agostinho: Assim como o Filho se refere ao Pai, assim o Verbo, ao ser ao qual
pertence. Ora, Filho é nome de pessoa porque se predica relativamente. Logo, também o Verbo.

SOLUÇÃO. – O nome de Verbo, em Deus, em acepção própria, é nome de pessoa e de nenhum modo de
essência. Para evidenciá-lo devemos saber, que o verbo, em nós, de tríplice modo se usa, em acepção
própria; e, de um quarto modo, imprópria ou figuradamente. Ora, mais manifesta e comumente em nós
se chama verbo o que é proferido pela palavra e que procede do interior, quanto a duas características
que aparecem no verbo exterior, a saber, a palavra em si mesma e a sua significação. Ora, a palavra
significa o conceito do intelecto, segundo o Filósofo; e como ainda diz o mesmo, ela procede da
imaginação; ao passo que a palavra não significativa não se pode chamar de verbo. Pois, o verbo se
chama palavra exterior por significar o conceito interior da mente. Assim, chama-se verbo, primária e
principalmente, o conceito interior da mente; secundariamente, a palavra mesma significativa deste
conceito; e em terceiro lugar, a imaginação mesma da palavra. E a esta tríplice modalidade do verbo se
refere Damasceno, dizendo: Verbo se chama o movimento natural do intelecto, segundo o qual este se
move, intelige e cogita, e é uma como luz e esplendor– quanto ao primeiro modo; em seguida, verbo é
o que se não profere por palavra, mas se pronuncia no coração– quanto ao terceiro; e
enfim,o verbo é anjo, i. é, o núncio, da inteligência– quanto ao segundo. – Porém, de um quarto modo e
figuradamente, chama-se verbo o que significado ou feito pela palavra; e neste sentido costumamos
dizer: Esteé o verbo que te disse, ou, que o rei mandou, aludindo-se a algum fato significado pela
palavra de quem simplesmente a enuncia ou manda.
Porém, em Deus propriamente se usa do vocábulo verbo para significar o conceito do intelecto. Por isso,
diz Agostinho: Quem puder inteligir o verbo não somente antes da palavra soar, mas ainda,antes de
serem apreendidas pela cogitação as imagens dos seus sons, já pode ver alguma semelhança daquele
Verbo, do qual foi dito: No princípio era o Verbo. Mas, o conceito mental procede, por natureza, de
outro, i. é, do conhecimento de quem o concebe. E, por isso, o Verbo, enquanto propriamente
predicado de Deus, significa uma realidade procedente de outra; e isso pertence à essência dos nomes
pessoais, em Deus, porque as pessoas divinas se distinguem pela origem, como se disse. Donde,
necessariamente vem, que o nome de Verbo predicado propriamente de Deus, não é tomado em
acepção essencial, mas somente pessoal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os arianos, dos quais Orígenes é a fonte, ensinaram que o
Filho é outro que não o Pai por diversidade de substância. Mas, como o Filho se chama Verbo de Deus,
esforçaram-se por negar que seja esse um nome próprio dele; para não serem forçados a confessar,
admitindo a idéia de Verbo procedente, que o Filho de Deus não é extra-substancial ao Pai, pois o verbo
procede interiormente de quem o profere; de modo que lhe é imanente. – Mas é forçoso, desde que se
admita o verbo de Deus, em sentido metafórico, admitir-se o verbo divino em sentido próprio. Pois
nada, senão em virtude da manifestação, pode se chamar metaforicamente verbo, porque ou
manifesta, como verbo, ou é pelo verbo manifestado. Ora, se for deste último modo, é necessário
admitir-se o verbo pelo qual se manifeste. E se se chamar verbo, porque manifesta exteriormente, essas
manifestações exteriores não se chamam verbos senão como significativas do conceito interior da
mente, que manifestamos também por sinais exteriores. E assim, embota por vezes, em Deus, o verbo
se predique metaforicamente, todavia é necessário nele admitirmos o Verbo propriamente dito, em
sentido pessoal.

RESPOSTA À SEGUNDA. – Nada do que concerne ao intelecto se predica pessoalmente de Deus, senão o
Verbo; porque só este significa o que emana de outro; pois, o verbo é a concepção formada pelo
intelecto. Ora, o intelecto, enquanto atualizado pela espécie inteligível é considerado de modo absoluto.
E semelhantemente, o inteligir, que está para o intelecto em ato como a essência, para o ser em ato;
pois, inteligir não significa ação que saia do intelecto, mas é imanente no ser que intelige. Portanto,
quando dizemos que o Verbo éconhecimento, este conhecimento não significa o ato do intelecto
conhecente, ou qualquer hábito dele, mas, aquilo que o intelecto concebe, quando conhece. Por isso diz
Agostinho, que o Verbo é a sabedoria gerada, e que nada mais é senão a própria concepção do sábio a
qual, de igual modo, também se pode chamarconhecimento gerado. E do mesmo modo podemos
entender que, dizer, em Deus, é cogitar intuitivamente, i. é, enquanto que essa cogitação intuitiva divina
leva à concepção do Verbo de Deus. Porém esse vocábulo –cogitação– não convém propriamente ao
Verbo divino. Pois, diz Agostinho: Ao chamado Verbo não se pode denominar cogitação; para que se não
creia haver em Deus algo de mutável que, depois de ter recebido a forma do verbo, possa vir a perdê-la
sujeito a uma como informe transformação. Pois, a cogitação consiste propriamente em indagar a ver-
dade, o que não pode ter lugar em Deus. Pois, quando o intelecto já atingiu a forma da verdade, não
cogita, mas contempla perfeitamente. Por onde, Anselmo impropriamente toma a cogitação
pela contemplação.

RESPOSTA À TERCEIRA. – Assim como, propriamente falando, o Verbo se predica de Deus, pessoal e não
essencialmente, assim também o dizer. Por onde, não sendo o Verbo comum ao Pai, ao Filho e ao
Espírito Santo, também não é verdade seja o Pai o Filho e o Espírito Santo um só dicente. Por isso
Agostinho ensina: Em Deus não se entende como um só o que diz, por aquele Verbo coeterno. Mas, ser
dito convém a qualquer das Pessoas, pois, é dito não só o Verbo, mas ainda as coisas por este inteligidas
ou significadas. Assim, pois, a uma só das Pessoas divinas convém o ser dita, do modo pelo qual o verbo
é dito; porém, a cada uma delas convém ser dita do modo pelo qual o é, pelo verbo, a coisa inteligida.
Assim, o Pai concebe o Verbo inteligindo-se a si, ao Filho, ao Espírito Santo e a tudo o mais que a sua
ciência contém; de maneira que toda a Trindade e mesmo toda criatura sejam ditas pelo Verbo, do
mesmo modo que o intelecto humano diz, pelo verbo, ser pedra o que concebe como pedra. Porém,
Anselmo toma impropriamente dizerpor inteligir, que, contudo, diferem. Pois,inteligirsó importa relação
entre o inteligente e o objeto inteligido, na qual se não compreende nenhuma idéia de origem, mas só
uma certa informação do nosso intelecto, como atualizado pela forma da coisa inteligida. Em Deus,
porém, importa omnímoda identidade, em quem se identifica absolutamente o inteligente com o
inteligido, como já vimos. Ao passo que dizerimporta principalmente relação com o verbo concebido,
pois dizer nada é senão proferir o verbo. E, mediante o verbo, importa relação com o objeto inteligido, o
qual pelo proferido se manifesta a quem intelige. Assim, só a Pessoa que profere o Verbo é, em Deus,
dicente, embora cada uma das Pessoas singularmente seja inteligente e inteligida e, por conseguinte,
dita pelo Verbo.

RESPOSTA À QUARTA. – Verbo, no lugar citado se toma em sentido figurado, enquanto o significado ou
o efeito de verbo se chamam verbo. Assim, dizemos que as criaturas executam o verbo de Deus, por
executarem algum efeito ao qual foram ordenados pelo Verbo concebido da divina sabedoria. Do
mesmo modo dizemos, que alguém cumpre o verbo do Rei, quando executa a obra a qual é levada por
esse verbo.

## Art. 2 — Se Verbo é o nome próprio do Filho.
(I Sent., dist. XXVII, q. 2, a. 2, qª 2; De Verit., q. 4. a. 3; Contra errors Graec., cap. XII. Ad Hebr., cap. 1,
lect. II).
O segundo discute-se assim. – Parece que o Verbo não é o nome próprio do Filho.

1. – Pois, o filho é uma pessoa divina subsistente. Ora, o verbo não significa nenhuma realidade
subsistente, como em nós o vemos. Logo, o Verbo não pode ser nome próprio da pessoa do Filho.

2. Demais. – O verbo procede de quem o diz, por uma certa prolação. Se pois o Filho é propriamente
Verbo, não procede do Pai senão a modo de prolação; o que é a heresia de Valentino, como se vê em
Agostinho.

3. Demais. – Todo nome próprio de pessoa significa alguma propriedade desta. Se, pois, o Verbo é nome
próprio do Filho, significará alguma propriedade deste e assim haverá mais propriedades em Deus do
que as supra enumeradas.

4. Demais. – Quem intelige, inteligindo, concebe o verbo. Ora, o Filho intelige. Logo, é um certo verbo e
portanto não lhe é próprio ser o Verbo.

5. Demais. – Diz a Escritura, do Filho (Hb 1, 3): Sustentando tudo com a palavra da sua virtude; donde
conclui Basílio que o Espírito Santo é o Verbo do Filho. Logo, não é próprio do Filho ser Verbo.
Mas, em contrário, Agostinho: Só o Filho é considerado como Verbo.

SOLUÇÃO. – O Verbo divino propriamente dito é considerado como pessoa, e é o nome próprio da
pessoa do Filho. Pois significa uma certa emanação do intelecto. Ora, a pessoa divina que procede por
emanação do intelecto se chama Filho, denominando-se tal processão geração, como se demonstrou.
Por onde resulta que só o Filho propriamente pode chamar-se Verbo divino.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Em nós não se identifica o ser com o inteligir; por isso o
que em nós é essência inteligível não pertence à nossa natureza. Ora, o ser de Deus se lhe identifica com
o inteligir. Portanto, o Verbo de Deus não é nele um acidente ou algum efeito seu, mas lhe pertence à
natureza mesma. Logo e necessariamente, deve ser uma realidade subsistente; pois, tudo o que existe
em a natureza de Deus, subsiste. E por isso Damasceno diz, que o Verbo de Deus é substância e ente
hipostático; ao passo que os outros verbos, i. é, os nossos, são virtudes da alma.

RESPOSTA À SEGUNDA. – O erro de Valentino não foi condenado por ensinar que o Filho nasce por
prolação, como o faziam os Arianos, segundo refere Hilário; mas, pelo modo diverso de prolação que
admitia, como se vê em Agostinho.

RESPOSTA À TERCEIRA. – O nome de Verbo importa a mesma propriedade que a do nome de Filho. E
por isso diz Agostinho: Do modo porque se diz Verbo também se diz Filho. Pois, a natividade do Filho,
que é propriedade pessoal sua, é significada por diversos nomes, que se lhe atribuem para lhe
exprimirem diversamente a perfeição. Assim, para mostrarmos que é conatural com o Pai, lhe
chamamos Filho; que é coeterno, Esplendor; que é absolutamente semelhante, Imagem; que é
imaterialmente gerado, Verbo. E não é possível achar um só nome para designarmos tudo isso.

RESPOSTA À QUARTA. – Convém ao Filho ser inteligente do mesmo modo que lhe convém ser Deus,
desde que, em Deus, inteligir é predicado essencial, como vimos. Ora, o Filho é Deus gerado e não Deus
gerador. Por onde, é por certo inteligente, não como produtor do Verbo, mas como Verbo procedente, i.
é, enquanto em Deus o Verbo procedente não difere realmente do intelecto divino, mas só
relativamente se distingue do princípio do Verbo.

RESPOSTA À QUINTA. – Quando a Escritura diz, do Filho: Sustentando tudo com a palavra da sua
virtude – o verbo é tomado figuradamente pelo seu efeito. Por isso, a Glosa a esse lugar diz,
que verbo significa império, i. é, enquanto pelo efeito da virtude do Verbo é que as coisas se conservam
no ser, assim como pelo efeito da mesma virtude é que vem ao ser. Quando, porém, Basílio interpreta
verbo por Espírito Santo, fala imprópria e figuradamente, no sentido em que se pode dizer que verbo de
alguém é tudo aquilo que lhe é manifestativo do ser; podendo-se então dizer que o Espírito Santo é
verbo do Filho porque o manifesta.

## Art. 3 — Se o nome de Verbo importa relação com a criatura.
(Infra q. 37, a. 1, ad 3; I Sent., dist. XXVII, q. 2, a. 3; De Verit., q. 4, a. 5; Quodl. IV, q. 4, a. 1, ad 1).
O terceiro discute-se assim. – Parece que o nome de Verbo não importa relação com a criatura.

1. – Pois, todo nome, que designe um efeito na criatura, essencialmente se predica de Deus. Ora, o
verbo não se predica essencial, mas, pessoalmente, como se disse. Logo, não importa relação com a
criatura.

2. Demais. – O que importa relação com as criaturas se predica de Deus temporalmente, como Senhor e
Criador. Ora, o Verbo se predica de Deus abeterno. Logo, não importa relação com a criatura.

3. Demais. – O verbo importa relação com o ser donde procede. Se, portanto, importa relação com a
criatura, segue-se que desta procede.

4. Demais. – As idéias são várias, conforme as diversas relações com as criaturas. Se, pois, o Verbo
importa relação com as criaturas, segue-se que em Deus não há um só, mas vários verbos.

5. Demais. – Se o Verbo importa relação com a criatura, só pode ser enquanto estas são dele
conhecidas. Ora, Deus, não somente conhece o ser, mas ainda o não-ser. Logo, o Verbo, importará
relações com o não-ser, o que é falso.
Mas, em contrário, diz Agostinho, que o nome de Verbo implica, não somente relação com o Pai, mas
ainda com as potências, que foram feitas operativas pelo Verbo.

SOLUÇÃO. – O Verbo importa relação com as criaturas. Pois, Deus, conhecendo-se, conhece a todas.
Ora, o Verbo concebido na mente é representativo de tudo o que é inteligido em ato. Por isso, são
tantos os nossos verbos quantas as coisas que inteligimos. Mas, como Deus, pelo mesmo ato, se intelige
a si e a todas as coisas, o seu único Verbo é expressivo não só do Pai, mas também das criaturas. E assim
a ciência de Deus é cognoscitiva, ao passo que a da criatura é cognoscitiva e factiva; assim, o Verbo de
Deus é somente expressivo do que existe em Deus; o das criaturas, porém, é expressivo e operativo. Por
isso diz a Escritura (Sl 32, 9): Ele disse e foram feitas as coisas, porque o Verbo implica a razão factiva das
coisas que Deus faz.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O nome de pessoa inclui também indiretamente a
natureza; pois, a pessoa é uma substância individual de natureza racional. Ora, o nome de pessoa divina,
no concernente à relação pessoal, não implica relação com a criatura, mas o implica no que concerne a
natureza. Nada porém impede, desde que a essência se inclui na significação de pessoa, que esta última
importe relação com a criatura. Pois, assim como é próprio ao Filho ser Filho, assim também lhe é
próprio ser Deus gerado ou Criador gerado. E deste modo, o nome de Verbo importa relação com a
criatura.

RESPOSTA À SEGUNDA. – Derivando as relações das ações, certos nomes importam relação de Deus
com a criatura, resultante da ação de Deus transitiva para um efeito exterior, como criar e governar. E
tais nomes se predicam de Deus temporalmente. Outros porém exprimem a relação resultante de ação
não transitiva para um efeito exterior, mas imanente no sujeito, como, saber e querer; e tais nomes não
se predicam de Deus temporalmente. Ora, é esta última relação com a criatura que importa o nome de
Verbo. Nem é verdade que os nomes que importam relação de Deus com as criaturas se prediquem
todos temporalmente; mas só aqueles, que importam relação resultante da ação divina transitiva para
um efeito exterior, é que temporalmente se predicam.

RESPOSTA À TERCEIRA. – As criaturas não são conhecidas por Deus, de ciência que ele por meio delas
obtivesse, mas pela sua essência. Por onde, não é necessário que o Verbo proceda das criaturas, embora
seja delas expressivo.

RESPOSTA À QUARTA. – O nome de idéia, sendo principalmente imposto para significar relação com a
criatura, predica-se de Deus no plural, e não é nome pessoal. Mas, o nome de Verbo principalmente é
imposto para significar relação com quem o profere e, por conseqüência, com as criaturas, enquanto
que Deus, inteligindo-se, intelige a todas. E por isso de Deus só há um Verbo pessoalmente predicado.

RESPOSTA À QUINTA. – Assim como a ciência de Deus se refere ao não ser, assim também o Verbo de
Deus; pois, não há no Verbo de Deus nada menos do que na ciência de Deus, como diz Agostinho.
Contudo, do ser, o Verbo é expressivo e factivo, ao passo que, do não ser, é expressivo e manifestativo.