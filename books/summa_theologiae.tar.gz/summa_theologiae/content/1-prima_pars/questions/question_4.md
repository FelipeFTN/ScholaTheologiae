# Questão 4: Da perfeição de Deus
Depois de termos tratado da simplicidade divina, devemos tratar da perfeição de Deus. E como um ser é
bom na medida em que é perfeito, havemos de tratar, primeiro, da perfeição divina e, depois, da
bondade divina. Na primeira questão, discutem-se três artigos:

## Art. 1 — Se Deus é perfeito.
(Cont. Gent. I, 28; De Verit., q. 2, a. 3, ad 13; Compend. Theol., c. 20; De Div. Nom., c. 13, lect. 1.)
O primeiro discute-se assim. — Parece que não é próprio de Deus ser perfeito.

1. — Pois, "perfeito" é como quem diz — totalmente feito. Ora, a Deus não pode convir o ser feito. Logo,
nem ser perfeito.

2. Demais. — Deus é o princípio primeiro das coisas. Ora, este é imperfeito; assim, a semente é o
princípio dos animais e das plantas. Logo, Deus é imperfeito.

3. Demais. — Como já estabelecemos, a essência de Deus é o ser mesmo. Ora, parece que este é
imperfeitíssimo, pois é generalíssimo e susceptível de todas as adições. Logo, Deus não é perfeito.
Mas, em contrário, a Escritura (Mt 5, 48): Sede vós logo perfeitos como também vosso pai
celestial é perfeito.

SOLUÇÃO. — Conforme refere Aristóteles, certos filósofos antigos — os Pitagóricos e Espeusipo — não
concebiam que o princípio primeiro fosse ótimo e perfeitíssimo. E a razão é que tais filósofos
consideravam só o princípio material. Ora, o principio material primeiro é imperfeitíssimo; pois, sendo a
matéria em si mesma potencial, por força o princípio material primeiro há de ser totalmente potencial
por excelência e, portanto, totalmente imperfeito. Deus, porém, é considerado como primeiro princípio,
não material, mas, no gênero, da causa eficiente; e, então, há de necessariamente ser perfeitíssimo.
Pois, assim como, em si mesma, a matéria é potencial, assim, o agente é, em si mesmo, atual. Por onde,
o primeiro princípio ativo há de, por força, ser soberanamente ativo, e, por conseqüência, perfeito em
máximo grau. Pois, um ser é considerado perfeito na medida em que é atual; porque perfeito se chama
aquilo ao que nada falta, nos limites da sua perfeição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz Gregório: Balbuciando, proclamamos como podemos
os atributos excelsos de Deus: pois, o que não é feito, não pode, propriamente, ser chamado
perfeito. Ora, como, dentre as coisas feitas, chamamos perfeita à que passa da potência para o ato, essa
palavra — perfeito — foi empregada para significar tudo aquilo a que não falta o ser atual, quer o tenha
por ser feito, quer não.

RESPOSTA À SEGUNDA. — O princípio material, que em nós existe imperfeitamente, não pode ser, em
absoluto, primeiro, mas é precedido por outro, que é perfeito. Assim, embora o sêmen seja o principio
do animal dele gerado, tem contudo, como princípio, o animal ou a planta donde deriva. Pois, antes do
potencial, há de necessariamente existir o atual, porque o ser potencial não se atualiza senão pelo que
já é atual.

RESPOSTA À TERCEIRA. — O ser em si é o mais perfeito de todos por atualizar a todos; pois, nenhum ser
é atual senão enquanto existente. Por onde, o ser em si é o que atualiza todos os outros e, mesmo, as
próprias formas. Por isso, não está para outros como o recipiente para o recebido, mas, antes, como o
recebido para o recipiente. Assim, quando designo o ser do homem, do cavalo, ou de qualquer outro
ente, considero o ser mesmo como princípio formal e como recebido; e não como um sujeito a que
sobrevém a existência.

## Art. 2 — Se Deus encerra as perfeições de todos os seres.
(I Sent., dist. 2, a. 2, 3; Cont. Gent. I, 28, 31; II, 2; De Verit., q. 2, a. 1; Compend. Theol., c. 21, 22; De Div.
Nom., c. 5, lect. 1, 2.)
O segundo discute-se assim. — Parece que Deus não encerra a perfeição de todos os seres.

1. — Pois, Deus é simples, como já se demonstrou. Ora, muitas e diversas são as perfeições dos seres.
Logo, Deus não encerra todas as perfeições deles.

2. Demais. — Os contrários não podem coexistir num mesmo ser. Ora, as perfeições dos seres são
contrárias; pois, cada espécie se completa pela sua diferença especifica, e as diferenças que dividem um
gênero e constituem as espécies, são contrárias. Logo, não podendo os contrários coexistir num mesmo
ser, Deus não encerra as perfeições de todos os seres.

3. Demais. — O vivente é mais perfeito que o ser simplesmente existente, e o que pode compreender,
do que o simples vivente. Logo, viver é mais perfeito que existir e compreender, que viver. Ora, Deus é o
ser, por essência. Por onde, não encerra em si a perfeição da vida, da sabedoria e outras.
Mas, em contrário, Dionisio: Deus encerra, de modo perfeito, em seu ser, tudo o que existe.

SOLUÇÃO. — Deus encerra em si as perfeições de todos os seres e, por isso, é denominado ser
universalmente perfeito; pois, no dizer do Comentador, não lhe falta nobreza de nenhum gênero. — E
isto pode ser demonstrado de dois modos. Primeiro, porque toda a perfeição do efeito deve existir na
causa eficiente. — Segundo, conforme a mesma noção, quando o agente é unívoco; tal o caso de um
homem, que gera outro. Ou de modo mais eminente, sendo o agente equívoco; assim, no sol está o
equivalente das coisas por virtude dele geradas. Ora, como é manifesto, o efeito preexiste virtualmente
na causa agente. Mas, preexistir na virtude da causa agente é preexistir de modo não mais imperfeito,
senão, mais perfeito. Pois, preexistir na potência da causa material é preexistir de modo mais
imperfeito, porque a matéria, como tal, é imperfeita; ao contrário, o agente, como tal, é perfeito. Ora,
sendo Deus a causa primeira eficiente das coisas, necessário é que as perfeições de todas nele
preexistam de modo mais eminente. E nesta razão tocou Dionísio dizendo: Deus, sendo um ser deixa de
ser outro, mas, é tudo, como causa de tudo. — Segundo, porque, como do sobredito resulta, Deus é o
ser por si subsistente; por onde, é necessário encerre em si a perfeição total do ser. Ora, é manifesto
que, se um corpo cálido não tem toda a perfeição da calidez, é porque não participa do calor em toda a
natureza deste; mas se o calor fosse por si subsistente, nada lhe poderia faltar da sua virtude. Donde,
sendo Deus o próprio ser subsistente, nenhuma das perfeições do ser lhe pode faltar. Ora, na perfeição
do ser se incluem as perfeições de todas as causas, pois cada uma é perfeita na medida em que é ser.
Donde resulta que a Deus não pode faltar nenhuma das perfeições das causas. E também nesta razão
toca Dionísio, dizendo, que Deus não existe, de certo modo, mas de modo primário e uniforme, encerra
em si a totalidade do ser, pura, simples e incircunscritamente. E, depois, acrescenta que é ele o ser de
tudo que subsiste.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como o sol no dizer de Dionísio, sendo único e
luzindo para todos igualmente, não deixa de encerrar, virtual e antecedentemente, na unidade da sua
ação, as substâncias e as qualidades múltiplas e diferentes dos seres sensíveis, assim, com maior razão,
na causa universal, hão de necessariamente preexistir todas as coisas unificadas na sua própria
natureza. Assim, coisas diversas e opostas entre si preexistem em Deus na unidade, sem prejuízo de sua
simplicidade.
Por onde, é clara a RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — Como diz Dionísio, no mesmo capítulo, embora o ser em si seja mais perfeito
que a vida, e a vida, que a sabedoria, consideradas essas noções abstratamente, todavia, o vivente é
mais perfeito que o simples ser, porque também o tem; e o que tem a sabedoria, além de ser, vive.
Embora, pois, a noção do ser em si não inclua a do vivente e a do que tem a sabedoria, por não haver
necessidade de o participante do ser o participar em todas as suas formas; contudo, o ser mesmo de
Deus inclui em si a vida e a sabedoria, por não lhe poder faltar nenhuma das perfeições do ser, a ele que
é o ser mesmo subsistente.

## Art. 3 — Se alguma criatura pode ser semelhante a Deus.
(I Sent., dist. 48, q. 1, a. 1; II, dist. 16, q. 1, a. 1, ad 3; Cont. Gent. I, 29; De Verit., q. 2, a. 11; q. 3, a. 1, ad
9; q. 23, a. 7, ad 9 sqq.; De Pot., q. 7, a. 7; De Div. Nom., c. 9, lect. 3)
O terceiro discute-se assim. — Parece que nenhuma criatura pode ser semelhante a Deus.

1. — Pois, como diz a Escritura (Sl 85,8), não há semelhante a ti entre os deuses, Senhor. Ora, dentre
todas as criaturas, são mais excelentes as que se chamam deuses, por participação. Com muito menos
razão, portanto, podem outras criaturas ser chamadas semelhantes a Deus.

2. Demais. — Semelhança supõe comparação. Ora, não se comparam coisas de gêneros diversos, que,
portanto, também não têm semelhança entre si; assim, não dizemos que a doçura é semelhante à
brancura. E não sendo nenhuma criatura congênere com Deus, que não pertence a nenhum gênero,
segundo já se demonstrou, resulta que nenhuma criatura é semelhante a Deus.

3. Demais. — Semelhantes se chamam os seres que têm a mesma forma. Ora, nenhum ser pode ter a
mesma forma que Deus, pois em nenhum, senão só em Deus, a essência é a existência. Logo, nenhuma
criatura pode ser semelhante a Deus.

4. Demais. — Seres semelhantes têm semelhança mútua, pois a um se assemelha o outro. Se, pois,
alguma criatura for semelhante a Deus, há de Deus ser semelhante a ela, o que vai contra a Escritura (Is.
40,18) que diz: A quem, pois, tendes vós assemelhado a Deus?
Mas, em contrário, a Escritura (Gn 1, 26): Façamos o homem à nossa imagem e semelhança. E noutro
lugar (1 Jo 3, 2): Quando ele aparecer seremos semelhantes a ele.

SOLUÇÃO. — Fundando-se a semelhança na conveniência ou comunidade de forma, a sua
multiplicidade é correlativa aos múltiplos modos por que existe a comunidade formal. Assim, certas
coisas se consideram semelhantes por terem de comum a mesma forma, na mesma proporção e do
mesmo modo; e, destas se diz que são, não somente semelhantes, mas iguais na semelhança; assim,
duas coisas igualmente brancas são semelhantes pela brancura. E esta é a mais perfeita das
semelhanças. — De outra maneira, dizem-se semelhantes as coisas que têm forma comum, na mesma
proporção, não, porém, do mesmo modo, mas, mais ou menos; assim, se diz que o menos branco é
semelhante ao mais branco. E esta semelhança é imperfeita. — De terceiro modo, semelhantes se
dizem as coisas que têm forma comum, não porém, na mesma proporção, como claramente se dá com
os agentes não unívocos, Ora, todo agente, como tal, produzindo efeito semelhante a si, e agindo pela
sua forma, é necessário haver no efeito a semelhança da forma do agente. Se, pois, este for da mesma
espécie que o seu efeito, haverá semelhança formal entre um e outro, na mesma proporção especifica;
assim, um homem gera outro. Se, porém, o agente não for da mesma espécie, haverá semelhança, não,
porém, quanto à proporção específica; assim, as coisas geradas pela virtude do sol encerram,
certamente, alguma semelhança com ele, do qual recebem a forma, por semelhança, não específica,
mas genérica apenas. Se, pois, houver algum ente não contido em nenhum gênero, os seus efeitos ainda
mais remotamente terão a semelhança da forma agente e não chegarão a participar da semelhança
desta, na mesma proporção especifica ou genérica, mas só analogicamente, no sentido em que se diz
que o ser em si é comum a tudo.
E deste modo, as coisas criadas por Deus, primeiro e universal princípio de todos os seres, com ele se
assemelham, enquanto seres.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como ensina Dionísio, a expressão da Escritura — nada
é semelhante a Deus — não é contrária ao assemelhar-se com ele; pois, as mesmas coisas podem ser
semelhantes e não semelhantes a Deus. Semelhantes, enquanto o imitam, na medida em que é possível
ser imitado quem não e perfeitamente imitável, Não semelhante, por outro lado, enquanto deficientes,
relativamente à causa; e isso, não somente no concernente à intensidade e à remissão, no sentido em
que o menos branco é deficiente em relação ao mais branco, mas ainda, por não haver conveniência
específica nem genérica.

RESPOSTA À SEGUNDA. — Deus não se comporta com as criaturas como sendo seres de gêneros
diversos; mas, como o ser que está acima de todos os gêneros, dos quais é o princípio.

RESPOSTA À TERCEIRA. — Não se diz que a semelhança da criatura com Deus se funda na comunidade
de forma, relativamente à mesma proporção genérica, e específica. Mas, só relativamente à analogia,
sendo então, Deus o ser por essência e os outros, por participação.

RESPOSTA À QUARTA. — Embora de algum modo se possa conceder que a criatura é semelhante a
Deus, contudo, de maneira nenhuma é admissível seja Deus semelhante à criatura. Pois, como diz
Dionísio, entre seres da mesma ordem admite-se a mútua semelhança; não, porém, entre a causa e seu
efeito. Assim, dizemos que a imagem de uma pessoa lhe é semelhante, e não, ao contrário. E, do mesmo
modo, pode-se de certa maneira dizer que a criatura é semelhante a Deus; não, porém, que seja Deus
semelhante à criatura.