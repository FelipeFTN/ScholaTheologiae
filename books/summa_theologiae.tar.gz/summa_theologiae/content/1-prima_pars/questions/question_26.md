# Questão 26: Da beatitude divina.
Depois de termos tratado da unidade da divina essência, devemos tratar da divina beatitude. E, nesta
questão, discutem-se quatro artigos:

## Art. 1 — Se a beatitude convém a Deus.
(II Sent., dist. 1, q. 2, a. 2, ad 4; I Conto Gent., cap. C).
O primeiro discute-se assim. — Parece que a beatitude não convém a Deus.

1. — Pois, segundo Boécio, ela é o estado perfeito pela reunião de todos os bens. Ora, em Deus não
existe reunião de bens nem composição. Logo, não lhe convém a beatitude.

2. Demais. — A beatitude ou a felicidade é o prêmio da virtude, segundo o Filósofo. Ora, em Deus não
convém o prêmio, tampouco o mérito. Logo, nem a bem-aventurança.
Mas, em contrário, o Apóstolo (1 Ti 6, 15): A Cristo mostrará Deus a seu tempo o bem-aventurado e o só
poderoso, o Rei dos reis, e o Senhor dos senhores.

SOLUÇÃO. — A Deus convém a máxima beatitude. Pois, o que se entende pela denominação de
beatitude é o bem perfeito da natureza intelectual, à qual compete conhecer a suficiência do bem que
possui; da qual depende o bem ou o mal, que lhe possa suceder, e o ser senhora dos seus atos. Ora,
uma e outra coisa convém excelentissimamente a Deus, isto é, ser perfeito e inteligente. Por onde a
máxima beatitude lhe convém.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A reunião dos bens existe em Deus, não, a modo de
composição, mas, por simplicidade. Porque, o múltiplo nas criaturas preexiste em Deus de modo
simples e uno, como dissemos.

RESPOSTA À SEGUNDA. — À beatitude ou à felicidade se acrescenta o prêmio quando a adquirimos,
assim como o termo da geração se acrescenta ao ser, que passa da potência para o ato. Portanto, como
Deus tem o ser, sem que seja gerado, assim, sem merecer, tem a beatitude.

## Art. 2 — Se Deus é feliz pelo intelecto.
(II Sent., dist. XVI, a. 2; I TIM., cap. VI lect III).
O segundo discute-se assim. — Parece que Deus não é feliz pelo intelecto.

1. — Pois, a beatitude é o sumo bem. Ora, Deus é bom por essência, porque o bem é próprio ao ser que
é por essência, segundo Boécio. Logo, também a beatitude existe em Deus, pela sua essência e não,
pelo intelecto.

2. Demais. — A beatitude tem natureza de fim. Ora, o fim, como o bem, é objeto da vontade. Logo, Deus
é feliz pela vontade e não, pelo intelecto.
Mas, em contrário, Gregório: Glorioso é ele que, gozando-se a si mesmo, não precisa do louvor
acidental. Ora, ser glorioso é ser feliz. E como gozamos de Deus pelo intelecto, porque a visão é a
recompensa total, segundo Agostinho, a beatitude existe em Deus, pelo intelecto.

SOLUÇÃO. — A beatitude, como do sobredito se colhe, significa o bem perfeito da natureza intelectual.
Donde, do mesmo modo que cada ser deseja a sua perfeição, também a natureza intelectual deseja
naturalmente ser feliz. Ora, a operação da inteligência pela qual uma natureza intelectual apreende, de
certo modo, tudo, é o que há nessa natureza de mais perfeito. Logo, a beatitude de qualquer natureza
intelectual criada consiste em inteligir. Mas, em Deus, a essência e o inteligir só diferem pela noção
racional, e não, realmente. Portanto, devemos atribuir a Deus a beatitude pela inteligência, bem como
aos bem-aventurados, assim chamados por assimilação com a beatitude divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O argumento prova que Deus é feliz por essência; não
porém, que a felicidade lhe convenha em virtude da sua essência, mas antes, em virtude do intelecto.

RESPOSTA À SEGUNDA. — A beatitude, sendo um ser, é objeto da vontade. Ora, o objeto nós o
concebemos como anterior ao ato da potência. Por onde, quanto ao modo de inteligir, a beatitude
divina é anterior ao ato da vontade que nela repousa. Ora, ela não pode ser senão um ato da
inteligência. Logo, a beatitude consiste num ato do intelecto.

## Art. 3 — Se Deus é a beatitude de todos os que são felizes.
(Ia IIae, q. 3, a. 1; IV Sent., dist. XLIX, q. 1, a. 2, q. 1).
O terceiro discute-se assim. — Parece que Deus é a beatitude de todos os que são felizes.

1. — Pois, Deus é o sumo bem, como se viu. Ora, como também resulta do sobredito, é impossível haver
vários bens sumos. Logo, a beatitude, sendo por essência o sumo bem, não é outra senão Deus.

2. Demais. — A beatitude é o fim da natureza racional. Ora, ser tal fim só a Deus convém. Logo, só Deus
é a beatitude dos que são felizes.
Mas, em contrário, a felicidade de um é maior que a de outro, conforme a Escritura (1 Cor 15, 41): Há
diferença de estrela a estrela, na claridade. Ora, nada é maior do que Deus. Logo, a felicidade é algo
diverso de Deus.

SOLUÇÃO. — A beatitude da natureza intelectual consiste num ato do intelecto, no qual podemos
considerar dois elementos: o objeto do ato, que é o inteligível; e o próprio ato, que é o inteligir.
Considerada, pois, em relação ao seu objeto, a beatitude é só Deus; porque só é feliz quem intelige a
Deus, como diz Agostinho: Feliz quem te conhece, mesmo sendo ignorante do mais. Mas, relativamente
ao ato de quem intelige, a beatitude é algo de criado, nas criaturas felizes. Em Deus, porém, é algo de in-
creado, mesmo nesta segunda relação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quanto ao seu objeto, a beatitude é o sumo bem
absoluto. Mas, quanto ao ato é o sumo bem das criaturas felizes, não absoluto, mas no gênero dos bens
participados por elas.

RESPOSTA À SEGUNDA. — Há duplo fim, segundo o Filósofo: um, que consiste na coisa possuída, outro,
na posse desta coisa. Assim, para o avarento, o fim é o dinheiro e a aquisição dele. Ora, da criatura
racional é o fim último Deus, como coisa; e a beatitude criada, como uso, ou antes, como fruição da
coisa.

## Art. 4 — Se a beatitude de Deus inclui todas as outras.
(I Cont. Gent., cap. CII).
O quarto discute-se assim. — Parece que a divina beatitude não inclui todas as outras.

1. — Pois, há beatitudes falsas. Ora, em Deus nada pode ser falso. Logo, a divina beatitude não inclui
todas as outras.

2. Demais. — Para alguns a beatitude consiste em coisas corpóreas, como os prazeres, as riquezas e
coisas semelhantes, que não podem convir a um Deus incorpóreo. Logo, a beatitude de Deus não inclui
todas as outras.
Mas, em contrário, a beatitude é uma certa perfeição. Ora, a divina perfeição inclui todas as outras,
como dissemos. Logo, a divina beatitude inclui todas as outras.

SOLUÇÃO. — Tudo o que em qualquer beatitude verdadeira ou falsa, é desejável, preexiste na divina,
total e eminentemente. Pois, quanto à felicidade contemplativa, Deus tem contínua e certíssima
contemplação de si e de todos os demais seres. Quanto à ativa, tem o governo de todo o universo.
Quanto à felicidade terrena, consistente no prazer, nas riquezas, no poder, na dignidade, e na glória,
segundo Boécio, tem o gáudio de si mesmo e de todos os demais seres, em lugar do prazer; em lugar
das riquezas, a omnímoda abastança, que elas prometem; a onipotência, em lugar do poder; a regência
de tudo, em lugar da dignidade e, em lugar da glória, a admiração de todas as criaturas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Falsa, e portanto, inexistente em Deus, é a beatitude
que não tem natureza verdadeira. Mas, o que quer que se assemelhe, tenuemente que seja com a
beatitude, preexiste totalmente na divina.

RESPOSTA À SEGUNDA. — Os bens existentes corporalmente, nos seres corpóreos, existem em Deus ao
modo deste, isto é, espiritualmente.
E no atinente à unidade da divina essência, baste o que dissemos até aqui.
Tratado De Deo Trino