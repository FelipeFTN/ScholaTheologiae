# Questão 98: Do que diz respeito à conservação da espécie.
Em seguida, devemos considerar do que diz respeito à conservação da espécie. E, primeiro, a geração.
Segundo, a condição da prole gerada.
Sobre a primeira questão dois artigos se discutem:

## Art. 1 — Se no estado de inocência havia geração.
O primeiro discute–se assim. – Parece que no estado de inocência, não havia geração.

1. – Pois, como diz Aristóteles, a corrupção é contrária à geração. Ora, os contrários não podem recair
sobre o mesmo objeto. Logo, no estado de inocência não havia corrupção e, portanto nem geração.

2. Demais. – A geração tem por fim fazer com que seja conservado, na espécie, o que não pode ser
individualmente conservado; e por isso não há geração para os indivíduos que duram perpetuamente.
Ora, no estado de inocência o homem viveria perpetuamente, sem morrer. Logo, nesse estado não
havia geração.

3. Demais. – Os homens se multiplicam pela geração. Ora, entre muitos donos é necessário fazer–se a
divisão das propriedades para se evitar a confusão de domínio. Logo, tendo o homem sido instituído
senhor dos animais, daí resultaria, multiplicado o gênero humano pela geração, a divisão do domínio. O
que é contrário ao direito natural, pelo qual, como diz Isidoro, todas as coisas são comuns. Logo, não
havia geração no estado de inocência.
Mas, em contrário, diz a Escritura: Crescei e multiplicai–vos e enchei a terra. Ora, essa multiplicação não
podia dar–se sem nova geração, pois, foi criado no princípio só um casal. Logo, no primitivo estado havia
geração.

SOLUÇÃO. – No estado de inocência haveria geração, para a multiplicação do gênero humano; do
contrário o pecado do homem, de que resultou tão grande bem, teria sido muito necessário. Por onde,
devemos considerar que o homem, pela sua natureza, foi constituído um como meio entre as criaturas
corruptíveis e as incorruptíveis; pois, ao passo que a sua alma é naturalmente incorruptível, o corpo é
naturalmente corruptível. Mas devemos atentar em que uma é a intenção da natureza, em relação às
coisas corruptíveis, e outra, em relação às incorruptíveis, Ora, o que é da intenção da natureza é sempre
e perpetuamente; ao passo que o que existe só temporariamente não é da intenção dela,
principalmente, mas é ordenado para outro fim; pois, do contrário, a intenção ficaria anulada, Com a
corrupção do que é temporário. Como, pois, das coisas corruptíveis, nada é perpétuo e permanece
sempre, salvo a espécie, o bem desta está na intenção principal da natureza, e para a conservação dele
se ordena a geração natural. As substâncias incorruptíveis, porém, permanecendo sempre, não só
específica, mas ainda individualmente, nelas os próprios indivíduos estão na intenção principal da
natureza. Assim pois o homem, em relação ao corpo corruptível por natureza, tem a geração; quanto à
alma incorruptível, porém, a multidão dos indivíduos é em si, da intenção da natureza, ou antes, do
autor da natureza, que, só, é o Criador das almas humanas. Por isso, para a multiplicação do género
humano ele estabeleceu a geração, mesmo no estado de inocência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O corpo do homem, em si, no estado de inocência, era
corruptível; mas, podia ser preservado da corrupção, pela alma. Por onde, não devia ser subtraída ao
homem a geração, devida aos seres corruptíveis.

RESPOSTA À SEGUNDA. – A geração, no estado de inocência, embora não fosse por causa da
conservação da espécie, seria, todavia, por causa da multiplicação dos indivíduos.

RESPOSTA À TERCEIRA. – No estado atual, multiplicados os donos, necessário é que se faça a divisão das
propriedades, pois, como diz o Filósofo, a comunidade da propriedade é ocasião da discórdia. Mas no
estado de inocência, as vontades dos homens seriam ordenadas de modo tal, que sem nenhum perigo
de discórdia usufruiriam em comum, na medida em que coubesse a cada um, das coisas que lhes
estivessem sujeitas ao domínio; pois que, ainda agora, tal se observa entre muitos homens bons.

## Art. 2 — Se no estado de inocência havia geração por meio do coito.
O segundo discute–se assim. – Parece que no estado de inocência não havia geração por meio do
coito.

1. – Pois, como diz Damasceno, o primeiro homem estava no paraíso terrestre como se fosse um anjo.
Ora, no estado futuro da ressurreição, quando os homens forem semelhantes aos anjos, nem as
mulheres terão maridos, nem os maridos mulheres, como diz a Escritura. Logo, também no paraíso não
havia geração por meio do coito.

2. Demais. – Os primeiros homens foram criados em idade perfeita. Ora, se antes do pecado, eles
gerassem por meio do coito, terse–iam, mesmo no paraíso, unido carnalmente. O que é claramente
falso, conforme a Escritura.

3. Demais. – Na conjunção carnal o homem, pela veemente deleitação, assemelhase muitíssimo aos
brutos. E por isso a continência, pela qual os homens se abstêm de tais deleitações, é louvada. Ora, é
pelo pecado que o homem é comparado aos brutos, conforme a Escritura: O homem, quando estava na
honra, não o entendeu: foi comparado aos brutos irracionais, e se fez semelhante a eles. Logo, antes do
pecado, não havia conjunção carnal do homem e da mulher.

4. Demais. – No estado de inocência não havia nenhuma corrupção. Ora, o coito corrompe a integridade
da virgindade. Logo, não existia no estado de inocência.
Mas, em contrário, Deus, antes do pecado criou o homem e a mulher, como diz a Escritura. Ora, nada é
vão, nas obras de Deus. Logo, mesmo que o homem não pecasse, haveria coito, para o que se ordena a
distinção dos sexos.

DEMAIS. – A Escritura diz que a mulher foi feita para o auxílio do homem. Ora, esse auxílio não é senão a
geração por meio do coito, pois, em qualquer outra obra, melhor seria um homem ajudado por outro,
do que pela mulher. Logo, no estado de inocência, haveria a geração por meio do coito.

SOLUÇÃO. – Alguns dos antigos Doutores, considerando a vileza da concupiscência, no coito, no estado
atual, ensinavam que no estado de inocência não se realizava desse modo a geração. Assim, Gregório
Nisseno diz que no paraíso o gênero humano se multiplicaria como se multiplicaram os anjos, sem
concúbito, por operação da divina virtude. E diz mais que Deus, antes do pecado, criou homem e
mulher, prevendo o modo da geração que havia de existir depois do pecado, de que tinha preciência.
Mas tal opinião não é racional. Pois, o pecado não subtrai nem dá ao homem aquilo que lhe é natural.
Ora, é manifesto que ao homem, assim como aos animais perfeitos, é natural gerar, pelo coito, à vida
animal, que já tinha antes do pecado, como já se disse; e isso o indicam os membros naturais para tal
fim destinados. Por onde, não se deve dizer que antes do pecado não eram esses membros naturais
usados, como o eram os outros.
Ora, no coito há duas coisas a se considerarem, no estado presente. – Primeira, que é natural para a
geração a conjunção do homem e da mulher, pois, em tôda geração, requer–se a virtude ativa e a
passiva. Donde, em todos os seres em que há distinção dos sexos, estando a virtude activa no macho e a
passiva, na fêmea, a ordem da natureza exige que para gerar unamse ambos pelo coito. – Segunda, a
deformidade da imoderada concupiscência, que não havia no estado de inocência, quando as
virtudes inferiores estavam absolutamente sujeitas à razão. E, por isso, Agostinho diz: Longe de nos o
pensar que não pudesse gerar–se a prole sem o morbo da libidinosidade; mas, os membros carnais,
como os outros, mover–se–iam pelo império da vontade, sem ardor e estimulo sedutor, com
tranquilidade da alma e do corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O homem, no paraíso, seria como um anjo, quanto à
alma espiritual; mas teria a vida animal do corpo. Mas depois da ressurreição o homem será semelhante
ao anjo, espiritualizado, quanto à alma e quanto ao corpo. Por onde, não há semelhança de razão.

RESPOSTA À SEGUNDA. – Como diz Agostinho, se os primeiros pais não se uniram no paraíso, foi porque
logo depois da formação da mulher, foram dele expulsos por causa do pecado. Ou porque esperavam,
da autoridade divina, da qual receberam o mandato universal, o tempo determinado para a conjunção.

RESPOSTA À TERCEIRA. – Como os brutos carecem de razão, o homem, na conjunção, torna–se bruto,
porque o deleite do coito e o ardor da concupiscência não podem ser moderados pela razão. Mas no
estado de inocência nada haveria que não fosse por esta moderado. Não que houvesse menor deleite
sensível, como querem alguns; pois, este seria tanto maior quanto mais pura fosse a natureza e o corpo
mais sensível; mas a virtude concupiscível não perturbaria, desordenadamente, o referido deleite,
regulado pela razão, que faz, não com que este seja menor, mas com que a virtude concupiscível não se
lhe torne imoderadamente inerente. E digo, imoderadamente, por causa da medida da razão. Assim o
sóbrio não tem, no alimento moderadamente tomado, menor deleite que o guloso; mas o seu
concupiscível concentra–se menos em tal deleite. E as palavras de Agostinho significam que do estado
de inocência não está excluída a intensidade do deleite, mas o ardor da libidinosidade e a perturbação
da alma. Por isso a continência, no referido estado, não seria louvável, como, no tempo atual, em que o
é, não por privar da fecundação, mas pela remoção da libidinosidade desordenada. Pois então havia
aquela sem esta.

RESPOSTA À QUARTA. – Como diz Agostinho, naquele estado, sem nenhuma corrupção da integridade,
o marido se uniria com a mulher. E isto podia dar–se, ficando salva a integridade data, assim como agora
é possível, salva a mesma integridade, uma virgem ler o fluxo menstrual. Pois, assim como no parto não
seria o gemido da dor, mas o implemento do termo que distenderia as vísceras femininas, assim, na
concepção, não o desejo libidinoso, mas o uso voluntário é que uniria os sexos.