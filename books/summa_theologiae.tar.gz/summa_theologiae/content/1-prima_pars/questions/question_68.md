# Questão 68: Da obra do segundo dia.
Em seguida, devemos falar da obra do segundo dia.
E sobre este assunto, quatro artigos se discutem:

## Art. 1 — Se o firmamento foi feito no segundo dia.
O primeiro discute-se assim. — Parece que o firmamento não foi feito no segundo dia.

1. — Pois, diz a Escritura: Chamou Deus ao firmamento céu. Ora, o céu foi feito antes de todos os dias,
como é claro pela passagem: No princípio criou Deus o céu e a terra. Logo, o firmamento não foi feito no
segundo dia.

2. Demais. — As obras dos seis dias se ordenam pela disposição da divina sapiência. Ora, não lhe seria
lógico, a esta, se fizesse posteriormente o que é naturalmente anterior. Mas, o firmamento é
naturalmente anterior à água e à terra, das quais, todavia, se faz menção antes da formação da luz, no
primeiro dia. Logo, o firmamento não foi feito no segundo dia.

3. Demais. — Tudo o feito durante os seis dias foi formado da matéria criada primeiro, antes de
qualquer dia. Ora, o firmamento não podia ser formado de matéria preexistente; porque então seria
susceptível de geração e corrupção. Logo, o firmamento não foi feito no segundo dia.
Mas, em contrário, diz a Escritura: Disse também Deus: faça-se o firmamento. E a seguir: E da tarde e da
manhã se fez o dia segundo.

SOLUÇÃO. — Como diz Agostinho, devem-se observar duas coisas, em tais questões. Primeira, que se
conserve de maneira inconcussa a verdade da Escritura. Segunda, como a divina Escritura pode ser
exposta em muitos sentidos, ninguém deve aderir a uma exposição de maneira tão precisa, a ponto de
ser a Escritura objeto de irrisão para os infiéis, aos quais se fecharia, então, a via para a crença, se se
estabelecesse, por uma razão certa, como falso aquilo que se presumia ser o sentido escritural.
Ora, é preciso saber-se que a lição sobre ter sido o firmamento feito no segundo dia pode ter duplo
sentido. Num, trata-se do firmamento em que estão os astros, e então teremos que expor
diversamente, segundo as várias opiniões dos homens sobre o firmamento. — Assim, uns disseram ser
esse firmamento composto dos elementos. E tal foi a opinião de Empédocles, ensinando que, então
esse corpo era indissolúvel por não haver discórdia na sua composição, mas somente amizade. —
Outros porém disseram que o firmamento é da natureza dos quatro elementos; não que seja composto
dos elementos, mas sendo um como elemento simples. E esta foi a opinião de Platão
(no Timeu), admitindo que o corpo celeste é o elemento do fogo. — Outros ainda disseram que o céu
não é da natureza dos quatro elementos, mas é um quinto corpo, além deles. E esta foi a opinião de
Aristóteles.
Ora, segundo a primeira opinião poder-se-ia absolutamente conceder que o firmamento, mesmo na sua
substância, foi feito no segundo dia. Pois, à obra da criação pertence o produzir a substância mesma dos
elementos; à obra da distinção, porém, e da ornamentação, o formar das coisas, dos elementos
preexistentes.
Mas, segundo a opinião de Platão, não é procedente se creia que o firmamento, na sua substância, foi
feito no segundo dia. Pois, fazer o firmamento, segundo tal opinião, é produzir o elemento do fogo. Ora,
a produção dos elementos pertence à obra da criação, conforme os que admitem que a informidade da
matéria precedeu, no tempo, à formação da mesma; pois, as formas dos elementos são o que primeiro
advêm à matéria.
E muito menos pode-se admitir, conforme a opinião de Aristóteles, que o firmamento, na sua
substância, fosse produzido no segundo dia, entendendo-se, por esses dias, a sucessão do tempo. Pois o
céu, incorruptível por natureza, é de matéria que não pode ser sujeita a outra forma. Por onde, é
impossível que o firmamento fosse feito da matéria existente, anteriormente, no tempo. Por isso, a
produção da substância do firmamento pertence à obra da criação. Mas alguma formação dele, segundo
essas duas opiniões, pertence à obra do segundo dia; assim, Dionísio diz que o lume do sol foi informe
no primeiro tríduo, tendo sido formado, em seguida, no quarto dia.
Se, porém, esses dias não designam a sucessão do tempo, ma somente a ordem da natureza, como quer
Agostinho, nada impede, dizer-se, segundo qualquer das sobreditas opiniões, que a formação do
firmamento, na sua substância pertence ao segundo dia.
Mas também se pode, de outro modo, entender que o firmamento, do qual se lê como feito no segundo
dia, não é onde estão fixas as estrelas, mas a parte do ar onde se condensam as nuvens. E se chama
firmamento por causa da espessura do seu ar. Pois, do espesso e sólido se chama corpo firme,
diferentemente do corpo matemático, como diz Basílio. — E, conforme esta exposição, nada de
repugnante resultando de qualquer das opiniões, Agostinho a recomenda, dizendo: Julgo esta
consideração digníssima de louvor. Diz, nem é contra a fé e pode ser acreditada com a prova sob os
olhos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Segundo Crisóstomo, Moisés disse, primeiro
sumariamente, o que Deus fez: No princípio criou Deus o céu e a terra, e, em seguida, explicando-o por
partes. Como se alguém dissesse: este artífice fez esta casa; e, em seguida, acrescentasse: primeiro, fez-
lhe os fundamentos; segundo, erigiu as paredes; terceiro, superpôs o teto. Assim, não devemos
entender que é um o céu, quando se diz: No princípio criou Deus o céu e a terra; e outro, quando se diz
que o firmamento foi feito no segundo dia. Porém, pode-se dizer que um é o céu do qual se lê como
criado no princípio, e outro o do qual se lê como feito no segundo dia; e isto de diversos modos. — Pois,
segundo Agostinho, o primeiro é a natureza espiritual informe; o segundo, o céu corpóreo. — Porém,
segundo Beda e Estrabo, o primeiro é o céu empíreo; o segundo, o céu sidéreo. — Mas, segundo
Damasceno, o primeiro é um céu esférico, sem estrelas, do qual os filósofos falam quando dizem que
esse é a nona esfera e o móvel primeiro, movido pelo movimento diurno; pelo segundo, porém,
entende-se o céu sidéreo. — Conforme, ainda, outra exposição, à qual Agostinho alude, o céu feito no
primeiro dia é o céu sidéreo mesmo; ao passo que pelo firmamento, feito no segundo dia entende-se o
espaço do ar no qual as nuvens se condensam, e que também se chama céu equivocamente. E, assim,
para designar a equivocação, diz-se expressivamente: E chamou Deus o firmamento céu, como, antes,
dissera: E chamou à luz dia, porque dia também significa o espaço de vinte e quatro horas. E o mesmo
se deve observar, em outras passagens, como diz Rabbi Moisés.
Do que acaba de ser dito é clara a RESPOSTA À SEGUNDA E À TERCEIRA OBJEÇÃO.

## Art. 2 — Se as águas estão sobre o firmamento.
O segundo discute-se assim. — Parece que as águas não estão sobre o firmamento.

1. — Pois, a água é naturalmente pesada. Ora, o lugar mais próprio dos graves não é o superior, mas o
inferior. Logo, as águas não estão sobre o firmamento.

2. Demais. — A água é naturalmente fluida. Ora, o fluido não pode se manter sobre um corpo redondo,
como a experiência o mostra. Logo, sendo o firmamento um corpo redondo, a água não pode estar
sobre ele.

3. Demais. — A água, sendo elemento, se ordena à geração do corpo misto, assim como o imperfeito se
ordena ao perfeito. Ora, não é sobre o firmamento o lugar da mistão, mas sobre a terra. Logo, seria vão
estar a água sobre o firmamento. Mas, como nada é vão nas obras de Deus, as águas aí não estão.
Mas, em contrário, diz a Escritura que dividiu as águas que estavam por baixo do firmamento das que
estavam por cima do firmamento.

SOLUÇÃO. — Como diz Agostinho, maior é a autoridade desta Escritura do que a capacidade de todo o
engenho humano. Donde, de nenhum modo duvidamos que aí estejam as águas, de qualquer maneira
que seja e quaisquer que elas sejam. — Mas, quais sejam essas águas, todos não o explicam do mesmo
modo. — Assim, Orígines diz que as águas que estão sobre os céus são substâncias espirituais. Por onde,
diz a Escritura: Águas que estão sobre os céus louvem o nome do Senhor; e: Águas que estais por cima
dos céus bendizei todas ao Senhor. — Mas, a isto responde Basílio, que tal não se diz porque sejam as
águas criaturas racionais, massignifica que a consideração delas, contemplada prudentemente pelos que
têm senso, completa a glorificação do Criador. Por onde, no mesmo lugar o mesmo se diz do fogo, da
saraiva e de coisas semelhantes; coisas todas, sabemos, que não são criaturas racionais.
Logo, deve-se dizer, que se trata de águas materiais. Mas quais sejam, é mister defini-las diversamente,
segundo as várias opiniões sobre o firmamento. — Se, pois, por firmamento se entende o céu sidéreo,
que se admite ter a natureza dos quatro elementos, também as águas, que estão sobre os céus,
poderão ser consideradas da mesma natureza que as águas elementais. — Se, porém, por firmamento
se entende o céu sidéreo, que não tem a natureza dos quatro elementos, então, também essas águas,
que estão sobre ele, não serão da natureza das águas elementais.
Mas, assim como, segundo Estrabo, o céu empíreo, isto é, ígneo, é assim chamado por causa do seu
esplendor; assim também será chamado o outro céu, que está acima do sidéreo, aquoso, por causa da
diafaneidade.
Posto, pois, que o firmamento é de outra natureza, que não a dos quatro elementos, ainda se pode dizer
que ele divide as águas entendendo-se por água, não o elemento desse nome, mas a matéria informe
dos corpos; pois então, como diz Agostinho, tudo o que está entre os corpos divide águas de águas.
Se porém, por firmamento se entende a parte do ar na qual as nuvens se condensam, então as águas
que sobre ele estão são águas que, resolvidas pela evaporação, elevam-se sobre uma parte do ar,
gerando-se delas as chuvas. Mas, admitir que as águas resolvidas pela evaporação, elevam-se acima do
céu sidéreo, como alguns disseram e a cuja opinião alude Agostinho, é de todo impossível. Quer por
causa da solidez do céu; ou da região média ígnea, que consumiria tais vapores; ou porque o lugar, para
onde são levados os corpos leves e rarefeitos está abaixo do côncavo do orbe da luz; ou também
porque, sensivelmente, é visível que os vapores não se elevam até os cumes de certos montes. E o que
dizem da rarefação do corpo, até o infinito, por ser divisível até o infinito, é vão. Pois, o corpo natural
não se divide nem se rarifica até o infinito, senão só até um certo limite.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Parece a alguns que se resolveria essa objeção, pelo fato
de as águas, embora naturalmente graves, estarem contudo contidas sobre os céus, por virtude divina.
— Mas essa SOLUÇÃO. Agostinho a exclui, dizendo que agora nos importa indagar como Deus instituiu
as naturezas das causas; e não o que nelas quis obrar, para manifestação do seu poder. — Por onde,
deve-se dizer, de outro modo, que, a SOLUÇÃO. resulta do que acabamos de dizer, segundo as duas
últimas opiniões, sobre as águas e o firmamento. Assim, conforme a primeira opinião, é necessário
estabelecer para os elementos uma ordem diferente da de Aristóteles; de modo que certas águas
espessas estejam ao redor da terra, e outras tênues ao redor do céu; e que aquelas estejam para o céu
como estas para a terra. Ou que, pela água se entenda a matéria dos corpos, como foi dito.

RESPOSTA À SEGUNDA. — Resulta clara a resposta à segunda objeção das duas últimas opiniões. Assim,
conforme a primeira, responde Basílio de dois modos. De um, dizendo não ser necessário que tudo o
que aparece como redondo, na concavidade, seja também redondo ou convexo na parte superior. De
outro, que as águas que estão sobre os céus não são fluidas, mas firmadas, fora do céu, por uma como
solidez glacial. Por isso é chamado esse céu por alguns, céu cristalino.

RESPOSTA À TERCEIRA. — Segundo a terceira opinião, as águas estão sobre o firmamento, elevadas por
evaporação, por causa da utilidade das chuvas. Porém, conforme a segunda opinião, o firmamento
sobre o qual estão as águas é o céu totalmente diáfano, sem estrelas; este céu, o consideram como o
primeiro móvel, motor de todo o céu pelo movimento diurno, cujo movimento opera a continuidade da
geração, assim como o céu em que estão os astros opera, pelo movimento zodiacal, a diversidade da
geração e da corrupção, pelo acesso e recesso, e pelas diversas virtudes das estrelas. Porém, segundo a
primeira opinião, as águas aí estão, conforme Basílio, para temperar o calor dos corpos celestes. E como
sinal disso, alguns admitiram, conforme diz Agostinho, que a estrela de Saturno é frigidíssima por causa
da vizinhança das águas superiores.

## Art. 3 — Se o firmamento divide umas, de outras águas.
O terceiro discute-se assim. — Parece que o firmamento não divide umas, de outras águas.

1. — Pois, cada corpo tem, especificamente, o seu lugar natural. Ora, água é da mesma espécie que
água, como diz o Filósofo. Logo, não se podem distinguir, localmente, umas, de outras águas.

2. Demais. — Se se disser que essas águas da parte superior do firmamento são de outra espécie que as
da parte inferior, digo em contrário o seguinte. — Seres especificamente diversos não precisam de outro
que os distingam. Se, pois, as águas superiores e inferiores diferem especificamente, o firmamento não
as distingue umas, de outras águas.

3. Demais. — Só pode distinguir umas, de outras águas o que é tocado delas por ambos os lados; como a
parede levantada no meio de um rio. Ora, é manifesto, as águas inferiores não atingem o firmamento.
Logo, este não divide umas, de outras águas.
Mas, em contrário, diz a Escritura: Faça-se o firmamento no meio das águas, e separe umas águas das
outras águas.

SOLUÇÃO. — Quem considerasse superficialmente a letra do Gênesis, poderia ter tal imaginação,
segundo a posição de certos filósofos antigos, que ensinavam ser a água um corpo infinito, princípio de
todos os outros corpos. E que essa imensidade das águas podia estar expressa na denominação de
abismo, quando a Escritura diz: As trevas cobriram a face do abismo. E também ensinavam que esse céu
sensível, que vemos, não contém abaixo de si todos os seres corporais, mas é o corpo infinito das águas
superiores ao céu. E assim, poder-se-ia dizer que o firmamento do céu divide as águas exteriores das
interiores, i. é, de todos os corpos contidos abaixo do céu, cujo princípio ensinavam ser a água.
Como porém se demonstra por verdadeiras razões a falsidade dessa doutrina, não podemos considerá-
la como expressiva do sentido da Escritura. Mas devemos atender a que Moisés, falando a um povo
rude, e condescendendo com a ignorância deles, propôs-lhes só o manifestamente aparente aos
sentidos. Pois todos, por mais rudes que sejam, depreendem pelos sentidos que a terra e a água são
corpos. Mas já nem todos percebem que o ar é corpo; a ponto de até certos filósofos dizerem que o ar
nada é, chamando vácuo ao que está cheio de ar. Por isso, Moisés faz menção expressa da água e da
terra, sem nomear o ar, para não propor nada de ignoto a gente rude. Mas, para exprimir a verdade aos
capazes, dá lugar para se compreender o que seja o ar, denominando-o como anexo à água, quando diz
que as trevas cobriam a face do abismo; dando assim a entender que sobre a face das águas há um
corpo diáfano, sujeito da luz e das trevas.
Quer, pois, entendamos, por firmamento, o céu onde estão as estrelas, ou o espaço nebuloso do ar,
com propriedade se diz que o firmamento divide umas, de outras águas, sendo estas ou a matéria
informe, ou todos os corpos diáfanos, incluídos nessa comum denominação. Pois, o céu sidéreo
distingue os corpos inferiores diáfanos dos superiores; ao passo que o ar nebuloso distingue a parte
superior do ar, onde se geram as chuvas e outras impressões, da inferior, conexa com as águas e
compreendida nesta denominação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Se por firmamento se entende o céu sidéreo, as águas
superiores não são da mesma espécie que as inferiores. Se porém se entende o ar nebuloso, então
ambas as águas são da mesma espécie; deputando-se-lhes dois lugares, embora não pela mesma razão;
pois, o lugar superior é o da geração delas e o inferior, do repouso.

RESPOSTA À SEGUNDA. — Se se admitem as águas como especificamente diversas, diz-se que o
firmamento as divide, não como causa da divisão, mas como limite de umas e outras.

RESPOSTA À TERCEIRA. — Moisés, por causa da invisibilidade do ar e de corpos semelhantes,
compreendeu todos os corpos dessa natureza na denominação de água. Por onde, é manifesto que há
águas de ambos os lados do firmamento, como quer que se compreenda este.

## Art. 4 — Se há só um céu.
O quarto discute-se assim. — Parece que há só um céu.

1. — O céu se opõe à terra, conforme se diz: No princípio criou Deus o céu e a terra. Mas a terra é uma
só. Logo, também é um só o céu.

2. Demais. — Todo o existente com a sua matéria total é único. Ora, assim é o céu, como o prova o
Filósofo. Logo, há só um céu.

3. Demais. — O que se predica de vários univocamente, deles se predica por uma só razão. Ora, se
vários céus há, de vários se predica o vocábulo céu, univocamente; pois, se se predicasse
equivocamente, não se poderia dizer em sentido próprio, que há vários céus, haja para isso alguma
razão comum. Ora, não se pode assinalar qual esta seja. Logo, não se pode dizer que existam vários
céus.
Mas, em contrário, diz a Escritura: Louvai-o, céus dos céus.

SOLUÇÃO. — Neste assunto, há certa diversidade entre Basílio e Crisóstomo. Assim, para este, só há um
céu; e a expressão plural, céu dos céus, provém de uma propriedade da língua hebraica que usa o nome
céu só no plural, como também acontece em latim, em que há muitos nomes sem singular. Porém,
Basílio e Damasceno que o segue, dizem que há vários céus. — Mas, esta diversidade é antes de palavra,
que real. Pois, Crisóstomo denomina um só céu todo o corpo que está sobre a terra e a água; assim
também as aves do ar se chamam, por isso, aves do céu. Mas, o haver nesse corpo muitas distinções
levou Basílio a admitir vários céus.
Por onde, para se conhecer a distinção dos céus, deve-se considerar que céu, na Escritura, toma-se em
tríplice acepção. — Ora, empregado própria e naturalmente, chama-se céu qualquer corpo sublime e
luminoso, atual ou potencialmente, e incorruptível por natureza. E neste sentido admite-se três céus. O
primeiro, totalmente lúcido, chamado empíreo. O segundo, totalmente diáfano, chamado céu aquoso e
cristalino. O terceiro, em parte diáfano e em parte atualmente lúcido, chama-se céu sidéreo, e é dividido
em oito esferas, convém a saber, a das estrelas fixas e as sete dos planetas, perfazendo os denominados
oito céus.
Num segundo sentido, céu é o que participa de alguma propriedade do corpo celeste, convém a saber, a
sublimidade e a luminosidade, atual ou potencial. E assim, Damasceno compreende como um só céu
todo o espaço que vai das águas até a esfera da lua, e o denomina aéreo. Por onde, na sua opinião, há
três céus, o aéreo, o sidéreo e outro superior, entendendo-se que este último é o ao que, conforme a
lição — até ao terceiro dia — o Apóstolo foi arrebatado. Mas, como esse espaço contém dois
elementos, o fogo e o ar, e em ambos há uma região chamada superior e outra inferior, por isso Rabano
distingue, neste céu, quatro outros: a suprema região do fogo, chamando-lhe céu ígneo; depois, a
inferior ou céu Olímpio, por causa da altura do monte chamado Olimpo; em seguida, à suprema região
do ar chamou-lhe céu etéreo, por causa da inflamação; e, por fim, à região inferior, céu aéreo. E assim,
como estes quatro céus se conumeram com os três superiores, são ao todo sete céus corpóreos,
conforme Rábano.
Num terceiro sentido céu se emprega metaforicamente; assim, por vezes, a própria santa Trindade é
chamada céu, por causa da sua sublimidade e luz espiritual. Em relação a esse céu é que se entende o
dito do diabo:Subirei ao céu, isto é, à igualdade com Deus. Outras vezes, como ensina Agostinho,
também os bens espirituais, entre os quais a remuneração dos santos, se denominam céus, por causa da
eminência deles, conforme a Escritura: Grande é a vossa recompensa nos céus. Outras vezes ainda, os
três gêneros das visões sobrenaturais; a corpórea, a imaginária e a intelectual, chamam-se três céus, dos
quais Agostinho expõe, que Paulo foi arrebatado até ao terceiro céu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A terra está para o céu, como o centro para a
circunferência. Donde, assim como muitas circunferências podem ter o mesmo centro, assim, existindo
só uma terra, admitem-se muitos céus.

RESPOSTA À SEGUNDA. — Essa objeção procede, se o céu importa a universidade das criaturas
corporais; havendo então, só um céu.

RESPOSTA À TERCEIRA. — Em todos os céus encontra-se comumente a sublimidade e alguma
luminosidade, como do sobredito se colhe.