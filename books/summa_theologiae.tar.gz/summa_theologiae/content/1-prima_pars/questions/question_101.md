# Questão 101: Da condição da prole a gerar quanto a ciência.
Em seguida devemos tratar a condição da prole a gerar, quanto à ciência.
E sobre esta questão dois artigos se discutem:

## Art. 1 — Se no estado de inocência as crianças nasceriam com ciência perfeita.
O primeiro discute–se assim. – Parece que no estado de inocência as crianças nasceriam com ciência
perfeita.

1. – Pois, tal era Adão, tais filhos geraria. Mas, como já se disse antes, Adão tinha ciência perfeita. Logo,
nasceriam dele filhos com ciência perfeita.

2. Demais. – A ignorância é causada pelo pecado, como diz Beda. Ora, ela é a privação da ciência. Logo,
antes do pecado, os recémnascidos teriam a ciência universal.

3. Demais. – Os recém–nascidos teriam a justiça. Ora, para esta é necessária a ciência, diretora das
ações. Logo, teriam a ciência.
Mas, em contrário, a nossa alma é, por natureza, como uma tábua na qual nada está escrito, como diz
Aristóteles. Ora, a natureza atual da alma é a mesma que a de então. Logo, as almas das crianças
careceriam, no princípio da ciência.

SOLUÇÃO. – Como se disse antes, há de se crer só na autoridade em matéria de sobrenatural. Pois
onde, quando essa falta, devemos seguir a condição da natureza. Ora, é natural ao homem adquirir a
ciência pelos sentidos, como se disse antes. E a alma está unida ao corpo porque dele precisa para a sua
operação própria; o que não se daria se, logo desde o princípio, tivesse ciência não adquirida pelas
virtudes sensitivas. Logo, devemos pensar que as crianças, no estado de inocência, não nasceriam com
ciência perfeita; mas a adquiririam, no decurso do tempo, sem dificuldade, descobrindo ou aprendendo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A perfeição na ciência foi um acidente individual do
primeiro pai, enquanto instituído pai e instrutor de todo o gênero humano. Por onde, relativamente a
ela, não geraria filhos semelhantes a si, senão só quanto aos acidentes naturais ou gratuitos, de tôda a
natureza.

RESPOSTA À SEGUNDA. – A ignorância é a privação da ciência devida, naquele tempo. E essa ignorância
não a teriam os recém–nascidos, pois possuiriam a ciência que lhes competia então. Por onde, neles não
haveria ignorância; mas apenas deixariam de saber certas coisas, o que Dionísio admite também em
relação aos santos anjos.

RESPOSTA À TERCEIRA. – As crianças teriam a suficiente ciência para se dirigirem nas obras da justiça,
nas quais os homens agora se dirigem pelos princípios universais do direito. E essa ciência a teriam
muito mais plenamente que agora os homens naturalmente a temos; e, semelhantemente, a ciência dos
outros princípios universais.

## Art. 2 — Se no estado de inocência os recém–nascidos teriam o uso perfeito da razão.
O segundo discute–se assim. – Parece que os recém–nascidos no estado de inocência teriam o uso
perfeito da razão.

1. Pois, se agora as crianças não têm o uso perfeito da razão, é que a alma é agravada pelo corpo. O que
então não se daria, conforme a Escritura: o corpo, que se corrompe, jaz pesada a alma. Logo, antes do
pecado e da corrupção dele resultante, os recém–nascidos teriam o uso perfeito da razão.

2. Demais. – Certos animais, logo depois de nascidos, tem o uso de alguma indústria natural; assim, o
cordeiro imediatamente foge do lobo. Por onde, muito mais forçosamente, os homens, no estado de
inocência, logo depois de nascidos, teriam o uso perfeito da razão.
Mas, em contrário, a natureza procede, em todos os seres gerados, do imperfeito para o perfeito. Logo,
as crianças não teriam, desde o princípio, o uso perfeito da razão.

SOLUÇÃO. – Como resulta do que foi dito antes, o uso da razão depende, de certo modo, do uso das
virtudes sensitivas. Por onde, travados os sentidos, e impedidas as virtudes sensitivas interiores, o
homem não tem o uso perfeito da razão, como bem se vê nos adormecidos e nos frenéticos. Ora, as
virtudes sensitivas, sendo virtudes de órgãos corpóreos, impedidos que sejam os seus órgãos,
necessariamente lhes hão de ficar impedidos os atos e, por consequência, o uso da razão. Mas, como
nas crianças tais virtudes. ficam impedidas por causa da nímia umidade do cérebro, elas não têm o uso
perfeito da razão, como não têm o dos demais membros. E por isso elas, no estado de inocência, não
teriam o uso perfeito da razão, como o haveriam de ter na idade pefeita. Tê–le–iam, contudo, mais
perfeito que agora, quanto ao que lhes dizia respeito, no sobredito estado, semelhantemente ao que se
disse antes sobre o uso dos membros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O agravó proveniente da corrupção do corpo consiste em
que o uso da razão fica impedido também em relação ao que é próprio ao homem, em qualquer idade.

RESPOSTA À SEGUNDA. – Também os brutos não têm o uso perfeito da indústria natural,
imediatamente, desde o princípio, como o tem depois. E isso bem se vê nas aves, que ensinam os filhos
a voar; e o mesmo se nota nos outros géneros de animais. Mas no homem há um impedimento especial,
resultante da abundância da umidade do cérebro, como antes se disse.