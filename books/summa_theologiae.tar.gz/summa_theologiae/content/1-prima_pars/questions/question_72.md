# Questão 72: Da obra do sexto dia.

## Art. 1 — Se a obra do sexto dia é descrita convenientemente. Em seguida, trata–se da obra do sexto dia. E parece que é descrita inconvenientemente. 1. – Pois, como as aves e os peixes têm alma vivente, assim também os animais terrestres. Mas, esses.
animais não são a alma vivente mesma. Logo, inconvenientemente se diz: Produza a terra animais
viventes; devendo–se dizer: Produza a terra quadrúpede com alma viva.

2. Demais. – O gênero não se divide por oposição com a espécie. Ora, os animais domésticos e os
selvagens são computados entre os quadrúpedes, Logo, inconvenientemente estes são conumerados
com aqueles.

3. Demais. – Assim como os outros animais pertencem a gênero e espécie determinados, assim também
o homem. Ora, na produção do homem, não se faz menção do seu gênero nem da sua espécie. Logo,
nem na produção dos outros animais se deveria fazê–lo, quando se diz no seu género ou na sua espécie.

4. Demais. – Mais semelhantes ao homem, do qual se diz que foi abençoado por Deus, são os animais
terrestres do que as aves e os peixes. Ora, como se diz das aves e dos peixes, que foram abençoados,
com muito maior razão dever–se–ia também dizer o mesmo dos outros animais.

5. Demais. – Certos animais são gerados da putrefacção, que é uma corrupção. Ora, a corrupção não
convém à primeira instituição das coisas. Logo, tais animais não deveram ser produzidos, nessa primeira
instituição.

6. Demais. – Certos animais são venenosos e nocivos ao homem. Ora, antes do pecado, nada devia lhe
ser nocivo a este. Logo, tais animais ou não deveram, de nenhum modo, ser feitos por Deus, autor de
todo bem; ou não deveram ser feitos antes do pecado.
Em contrário basta a autoridade da Escritura.

SOLUÇÃO. – Assim como no quinto dia foi ornado o corpo médio, que corresponde ao segundo dia;
assim no sexto dia foi o último corpo, isto é, a terra, pela produção dos animais terrestres, e
corresponde ao terceiro dia. Por onde, em ambos esses dias, se faz menção da terra. – E também aqui,
segundo Agostinho, os animais terrestres foram produzidos potencialmente; segundo os outros Santos
Padres, porém, em ato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como diz Basílio, pelo modo de falar da Escritura,
podem–se coligir os diversos graus de vida que se encontram nos diversos viventes. – Assim as plantas,
tendo vida imperfeitíssima e oculta, não se faz na produção delas nenhuma menção da vida, mas só da
geração, porque só a vida geradora nelas se encontra; pois, a vida nutritiva e a aumentativa servem à
geradora, como a seguir se dirá. – Entre os animais porém são mais perfeitos, comumente falando, os
terrestres que as aves e os peixes; não que os peixes careçam de memória, como afirma Basílio e
Agostinho nega, mas por causa da distinção dos membros e da perfeição da geração. E quanto a certas
sagacidades, também alguns animais imperfeitos são melhores dotados, como as abelhas e as formigas.
Por isso, os peixes são chamados, não animais viventes, mas répteis animados e viventes: ao passo, que
os animais terrestres são chamados animais e viventes; por causa da perfeição da vida que têm. Pois se
os peixes são corpos dotados, de algum modo, de alma, os animais terrestres são, pela perfeição da
vida, umas quase almas que dominam os seus corpos. – Porém, o grau perfeitíssimo da vida sendo do
homem, não se diz que a vida dele foi produzida pela terra ou pela água, como a dos outros animais,
mas por Deus.

RESPOSTA À SEGUNDA. – Por animais domésticos ou animais se entendem os animais domésticos que,
de algum modo, servem ao homem. Por animais selváticos, porém, se entendem os animais ferozes,
como os ursos e os leões. Ao passo que répteis significa os animais, como as serpentes, sem pés com
que se elevem da terra; ou, como os lagartos e as tartarugas, com pés pequenos, com os quais pouco se
elevam. Mas, por haver certos animais, como os cervos e as cabras, não compreendidos em nenhuma
dessas classes, acrescenta–se, para que o sejam, a palavra quadrúpedes, – Ou então, empregou–se
quadrúpedes para significar o gênero, considerando os outros animais como espécies; pois, há certos
répteis quadrúpedes, como os lagartos e as tartarugas.

RESPOSTA À TERCEIRA. – Quanto aos outros animais e plantas, fez–se menção do gênero e da espécie,
para designar a geração dos semelhantes pelos semelhantes. Porém não era necessário dizer tal em
relação ao homem, porque o já dito dos outros animais também dele se pode entender. – Ou porque os
animais e as plantas, como muito afastados da semelhança divina, foram produzidos no seu gênero e na
sua espécie. Porém, do homem se diz que foi formado à imagem e semelhança de Deus.

RESPOSTA À QUARTA. – A bênção de Deus dá a virtude de multiplicar, pela geração. Por onde, já se
subentende, sem ser necessário repetir, dos animais terrestres, o que foi dito das aves e dos peixes,
primeiro nomeados. Para os homens, porém, se reitera a bênção, por haver neles uma certa e especial
razão de multiplicação, a saber, completar–se o número dos eleitos; e para ninguém poder dizer que há
algum pecado na junção de gerar filhos. Porém, as plantas de todo sem afeto na propagação da prole, e
que geram sem nenhuma sensibilidade, foram julgadas indignas das palavras de bênção.

RESPOSTA À QUINTA. – Sendo a geração de um a corrupção de outro, não repugna à primeira
instituição das coisas sejam gerados seres mais nobres, da corrupção dos menos nobres. Por onde
puderam então ser gerados os animais oriundos da corrupção dos seres inanimados ou das plantas; não
porem os oriundos da corrupção dos animais, senão só potencialmente.

RESPOSTA À SEXTA. – Agostinho diz, que, se o imperito entrar na oficina de algum artífice, nela verá
muitos instrumentos, cujas causas ignora; e se for por demais insipiente, reputá–las–á por supérfluas.
Se, porém, incauto, cair numa fornalha, ou ferir–se com alguma ferramenta aguda, julgará haver ai
muitas causas nocivas, dando lugar a que o artífice, conhecedor do uso delas, zombe de tal insipiência.
Assim, neste mundo, certos ousam criticar multas causas, cujas causas não vêm. Pois multas, embora
não necessárias à nossa casa, completam a integridade do todo. Ora, o homem, antes do pecado,
usando ordenadamente das coisas do mundo, os animais venenosos não lhe haviam de ser nocivos.