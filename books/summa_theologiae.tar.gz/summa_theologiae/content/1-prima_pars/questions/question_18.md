# Questão 18: Da vida de Deus.
Sendo o inteligir próprio dos seres vivos, devemos tratar, após a consideração da ciência e da
inteligência divinas, da vida de Deus.
E, nesta questão, discutem-se quatro artigos:

## Art. 1 — Se todos os seres vivem.

III Sent., dist. XXXV, q. 1, a. 1; IV, dist. XIV, q. 2, a. 3, qa. 2; dist. XLIX, q. 1, a. 2, qa. 3; I Cont. Gent.,
cap. XCVII; De Verit., q. 4, a. 8; De Pot., q. 10, a. 1; De Div. Nom., cap. VI, lect I; in Ioan., cap. XVII, lect. I; I
De Anima, lect. XIV; II, lect. 1.
O primeiro discute-se assim. — Parece que todos os seres naturais vivem.

1. — Pois, como diz o Filósofo, o movimento é como uma certa vida naturalmente existente em todos os
seres. Ora, todos os seres naturais participam do movimento. Logo, participam da vida.

2. Demais. — Dizemos que as plantas vivem por terem em si mesmas o princípio dos movimentos de
crescer e de perecer. Ora, o movimento local é mais perfeito que o de crescer e o de perecer e lhe é
anterior por natureza, como o prova Aristóteles. Por onde, todos os corpos naturais, tendo algum
princípio de movimento local, conclui-se que todos os corpos naturais vivem.

3. Demais. — Entre os corpos naturais, os elementos são os mais imperfeitos. Ora, a eles se atribui a
vida; pois, dizemos águas vivas. Logo, com maior razão, os outros corpos naturais têm vida.
Mas, em contrário, diz Dionísio: As plantas, segundo as últimas manifestações da vida, têm vida; donde
podemos concluir, que elas têm o último grau de vida. Ora, os corpos inanimados são inferiores às
plantas. Logo, não têm vida.

SOLUÇÃO. — Dos seres, que manifestamente vivem, podemos concluir quais os vivos e quais os não-
vivos. Ora, viver convém manifestamente aos animais. Pois, como diz Aristóteles, a vida é manifesta nos
animais. Por onde, o princípio da vida, nos animais, será necessariamente o critério para distinguirmos
os seres vivos dos não-vivos. Pois, nesse princípio é que a vida começa a manifestar-se, e dele
desaparece em último lugar. Ora, dizemos que um animal começa a viver quando começa a mover-se
por movimento próprio; e que vive, enquanto se manifesta esse movimento. Pois, quando já não tem
nenhum movimento, mas só é movido por outro ser, então, dizemos que o animal está morto, por falta
de vida. Por onde, é claro, que são propriamente vivos os seres que se movem por si mesmos, por
alguma espécie de movimento, quer o consideremos em sentido próprio, como quando o denominamos
ato do imperfeito, isto é, do que existe em potência; quer, na acepção geral, como quando o
denominamos ato do perfeito, chamando-se assim movimentos ao inteligir e ao sentir. Assim,
consideram-se viventes todos os seres que por si mesmos se movem ou agem. Ao contrário, os seres
que por natureza não se movem nem agem por si mesmos não podem chamar-se vivos senão por
alguma semelhança.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A expressão do Filósofo pode entender-se ou do
movimento primeiro, isto é, dos corpos celestes, ou do movimento em geral. E, de ambos os modos, o
movimento se chama como que vida dos corpos naturais, por semelhança e não, propriamente. Pois, o
movimento do céu é, no universo das naturezas corpóreas, o que é, no animal, o movimento do coração
pelo qual se conserva a vida. Semelhantemente, qualquer movimento natural desempenha nos seres
naturais papel semelhante ao da operação vital; e assim, se todo universo corpóreo fosse um animal, de
modo que o seu movimento proviesse de um motor intrínseco, como alguns ensinaram, movimento
seria a vida de todos os corpos naturais.

RESPOSTA À SEGUNDA. — Aos corpos graves e leves não é próprio serem movidos, senão enquanto
estão fora da disposição da sua natureza. Assim, quando estão fora do lugar próprio; pois, quando no
lugar próprio e natural, repousam. Mas, as plantas e os outros viventes movem-se por um movimento
vital, por estarem na sua disposição natural, e não por se aproximarem ou se afastarem dela; antes,
afastando-se de tal movimento, afastam-se da disposição natural. E, além disso, os corpos graves e leves
são movidos por um motor extrínseco, gerador, que dá a forma, ou remove o obstáculo, como diz
Aristóteles.

RESPOSTA À TERCEIRA. — Chamam-se águas vivas as que têm fluxo contínuo. Pois, as águas paradas,
que não continuam a correr, por um princípio de fluxo contínuo, chamam-se mortas, como as das
cisternas e das lagoas. E isto, por semelhança, porque enquanto se movem, assemelham-se à vida. Mas,
não têm a verdadeira essência da vida, por não terem o movimento por si mesmas, mas, da causa que
as gerou, como se dá com o movimento dos outros corpos graves e leves.

## Art. 2 — Se a vida é uma operação.
Infra., q. 54, a. 1, ad 2; III Sent., dist. XXXV, q. 1, a. 1, ad 1; IV, dist. XLIV, q. 1, a. 2, qª 3; I Cont Gent., cap.

XCVIII; De Div. Nom., cap. VI, lect. I.
O segundo discute-se assim. — Parece que a vida é uma operação.

1. — Pois, nada se divide senão em partes congêneres. Ora, a vida divide-se em operações, como se vê
no Filósofo, que nelas distingue quatro partes: alimentar-se, sentir, mover-se localmente e inteligir.
Logo, a vida é uma operação.

2. Demais. — Dizemos que a vida ativa difere da contemplativa. Ora, os contemplativos diversificam-se
dos outros por certas operações. Logo, a vida é uma operação.

3. Demais. — Conhecer a Deus é uma operação. Ora, tal operação é vida, diz a Escritura (Jo 17, 3): A vida
eterna porém consiste em que eles conheçam por um só verdadeiro Deus a ti. Logo, a vida é operação.
Mas, em contrário, diz o Filósofo: Para os viventes, viver, é ser.

SOLUÇÃO. — Conforme resulta do sobredito, o nosso intelecto conhecendo, como seu objeto próprio, a
quididade da coisa, tira os elementos do seu conhecimento, dos sentidos, dos quais o objeto próprio são
os acidentes exteriores. Donde resulta, que chegamos a conhecer a essência de um ser pelo que dele
exteriormente nos aparece. E porque, como ressalta do que foi dito, nomeamos uma coisa segundo a
conhecemos, conclui-se que, por meio das propriedades exteriores, impomos quase sempre os nomes
significativos das essências das coisas. Por isso tais nomes são tomados, umas vezes, em acepção
própria, exprimindo as essências próprias das coisas para cuja significação foram principalmente
impostos. Outras vezes, porém, e menos exatamente, exprimem as propriedades em virtude das quais
foram impostos. Por exemplo, é claro que o nome corpo foi imposto para significar um certo gênero de
substâncias, por se encontrarem nelas três dimensões; e, por isso, às vezes usamos o nome
de corpo para significar três dimensões, sendo o corpo considerado uma espécie de quantidade.
Por onde, devemos dizer o mesmo da vida. Pois, o nome vida é derivado de uma certa aparência
externa das coisas, consistente em se moverem a si mesmas; porém este nome não se aplicou para
significar tal fenômeno, mas, sim, a substância à qual convém, por natureza, mover-se a si mesma, ou
determinar-se, de qualquer modo, à operação. E, deste modo, viver não é senão o ser da natureza viva;
o que a vida significa em abstrato, do mesmo modo que o nome curso significa correr, em abstrato. Por
onde, vivo não é um predicado acidental, mas substancial. Outras vezes, porém, e menos propriamente,
a vida é tomada para exprimir as operações vitais das quais esse nome vida deriva; e assim diz o
Filósofo, que viver é principalmente sentir ou inteligir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No lugar citado, o Filósofo toma viver por operação vital.
— Ou podemos dizer, e melhor, que sentir, inteligir e outras operações semelhantes, ora, consideram-se
como tais; ora, como o ser mesmo das sustâncias que assim operam. Pois, diz9 que existir é sentir ou
inteligir, i. é, ter natureza capaz de sentir ou inteligir. E então, o Filósofo distingue as quatro operações
mencionadas da vida. Porque, nos seres deste mundo, há quatro gêneros de viventes. Uns têm natureza
capaz somente de alimentar-se e, por conseqüência, de crescer e gerar. Outros, segundo vemos nos
animais imóveis, como as ostras, a têm além disso, capaz de sentir. Outros ainda, como os animais
perfeitos, a saber, os quadrúpedes, as aves e semelhantes, têm, além disso, a capacidade de se
moverem localmente. E outros, enfim, como os homens, podem, além do mais, inteligir.

RESPOSTA À SEGUNDA OBJEÇÃO. — Chamam-se operações vitais aquelas cujos princípios, existindo
nos seres que operam, levam-nos a se determinarem por si mesmos a elas. Ora, dá-se que, de algumas
operações existem no homem, não somente os princípios naturais, como sejam as potências naturais,
mas ainda se lhes acrescentam certos outros princípios, como os hábitos, que inclinam, a modo de
natureza, a determinados gêneros de operações e as tornam deleitáveis. Por isso, e por uma certa
semelhança, chama-se vida, no homem, a operação que lhe é deleitável, à qual se inclina, na qual se
detém, e em relação à qual ordena a sua vida. E, assim, dizemos que uns levam vida luxuriosa e, outros,
honesta. E deste modo distinguimos a vida contemplativa, da ativa, e dizemos que conhecer a Deus é a
vida eterna. Donde se deduz clara a RESPOSTA À TERCEIRA OBJEÇÃO.

## Art. 3 — Se a Deus convém a vida.
I Cont. Gent., cap. XCVII, XCVIII; IV, cap. XI; in Ioan., cap. XIV, lect. III; XII Metaph., lect. VIII.
O terceiro discute-se assim. — Parece que a vida não convém a Deus.

1. — Pois, dizemos que um ser vive quando se move a si mesmo, como foi demonstrado. Ora, a Deus
não convém mover-se. Logo, nem viver.

2. Demais. — É necessário admitir em todos os viventes um princípio de vida; por isso, diz Aristóteles
que a alma é a causa e o princípio do corpo vivo. Ora, Deus não tem nenhum princípio. Logo, não lhe
convém a vida.

3. Demais. — O princípio da vida, nos viventes, que conhecemos, é a alma vegetativa, que só existe nos
seres corpóreos. Logo, aos incorpóreos não convém a vida.
Mas, em contrário, a Escritura (Sl 83, 3): O meu coração e a minha carne se regozijaram no Deus vivo.

SOLUÇÃO. — A vida existe em Deus, por excelência, de maneira própria. Para evidenciá-lo devemos
considerar, que vivos são os seres que obram por si mesmos, e sem serem movidos por outros. Por
onde, quanto mais perfeita for essa faculdade, tanto mais perfeitamente um ser terá a vida. Ora, nos
motores e nos movidos, há lugar para uma tríplice e ordenada distinção. Primeiro, o fim move o agente;
este é principal quando age pela sua forma; o qual, porém, age, às vezes, por meio de um instrumento,
que, não agindo em virtude da própria forma, mas em virtude do agente principal, só lhe compete
executar a ação.
Ora, há certos seres que se movem a si mesmos, só quanto à execução do movimento, sendo-lhes a
forma pela qual agem e o fim pelo qual agem determinados pela natureza. Tais as plantas, que se
movem a si mesmas, crescendo e perecendo, pela forma que lhes infundiu a natureza.
Outros, além disso, movem-se a si mesmos, não somente quanto à execução do movimento, mas
também quanto à forma, princípio do movimento, com que a si próprios se movem. São os animais, de
cujos movimentos é princípio uma forma, não infundida pela natureza, mas recebida pelos sentidos.
Donde, quanto mais perfeitos tiverem os sentidos, tanto mais perfeitamente se hão de mover por si.
Assim, os que têm apenas o tato, movem-se a si mesmos somente pelo movimento de dilação e
constrição, como as ostras, cujo movimento pouco excede ao da planta. Os dotados, porém, de virtude
sensitiva perfeita, capaz de conhecer não somente o que os atinge por contato, mas ainda o que está
distante, movem-se por si, avançando por um movimento processivo.
Mas, embora tais animais recebam, pelos sentidos, a forma que lhes é princípio do movimento,
contudo, não determinam por si, e para si próprios o fim da sua operação ou do seu movimento, fim
que lhes é infundido pela natureza, por cujo instinto são levados a agir, por meio da forma apreendida
pelos sentidos. Donde, superiores a esses animais são os seres que se movem a si mesmos ao fim por
eles próprios determinado. O que só o podem fazer pela razão e pelo intelecto, ao qual pertence
conhecer a proporção entre o fim e os meios, e ordenar estes para aqueles.
Portanto, o modo de viver dos que têm intelecto é mais perfeito, pois movem-se a si mesmos mais
perfeitamente. E a prova é que num mesmo homem, a virtude intelectiva move as potências sensitivas,
e estas, pelo seu império, os órgãos, que executam o movimento. É semelhança do que se dá com as
artes. Assim, a arte de pilotar, à qual pertence o uso do navio, dá preceito à que concebe a forma dele;
esta, por sua vez, preceitua à que deve executá-la, somente, pela disposição da matéria. Embora,
porém, o nosso intelecto se mova por si mesmo a agir, contudo, certas condições lhe são impostas pela
natureza, como os primeiros princípios, que ele não pode deixar de admitir, e o último fim, que não
pode deixar de querer. Donde, embora sob certos respeitos, move-se a si mesmo, a outros, contudo, é
necessário que seja movido por outro.
Mas o ser, cuja natureza é o seu próprio inteligir, e que não recebe de outro o que naturalmente tem,
este desfruta o sumo grau da vida. E tal é Deus. Logo, em Deus existe por excelência a vida. Por isso o
Filósofo, tendo demonstrado que Deus é inteligente, conclui, que tem vida perfeitíssima e sempiterna,
porque o seu intelecto é perfeitíssimo e sempre atual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Há duas sortes de ações, diz o Filósofo: uma transeunte
à matéria exterior, como aquecer e cortar; outra, imanente no agente, como inteligir, sentir, querer. A
primeira não é perfeição do agente motor, mas, do móvel; por isso difere da segunda, que é perfeição
do agente. Por onde, sendo o movimento ato do móvel, a segunda ação, enquanto ato do operante,
chama-se movimento do mesmo, por semelhança. Pois, assim como o movimento é ato do móvel,
assim, a ação de que se trata é ação do agente, embora o movimento seja ato do imperfeito, isto é, do
que existe em potência; ao passo que a ação, no caso vertente, é ato do perfeito, isto é, do que existe
em ato, como diz Aristóteles. Do modo, pois, pelo qual inteligir é movimento, dizemos que se move o
ser que se intelige. E assim também Platão ensinou, que Deus se move por si mesmo; e não, enquanto o
movimento é ato do imperfeito.

RESPOSTA À SEGUNDA. — Assim como Deus é o seu próprio ser e o seu inteligir, assim também é a sua
vida; e assim vive, porque não tem princípio o seu viver.

RESPOSTA À TERCEIRA. — A vida dos seres deste mundo é recebida numa natureza corruptível, que
precisa da geração, que precisa da geração, para conservar a espécie, e do alimento, para conservar o
indivíduo. E, por isso, não existe vida, em tais seres, sem alma vegetativa. Ora, tal não se dá com os
seres incorruptíveis.

## Art. 4 — Se todas as coisas são vida em Deus.

IV Cont. Gent., cap. XIII; De Verit., q. IV, a. 8; in Ioan., cap. I, lect. II.
O quarto discute-se assim. — Parece que todas as coisas não são vida em Deus.

1. — Pois, diz a Escritura (At 17, 28): Nele mesmo vivemos e nos movemos e existimos. Ora, nem todas
as coisas, em Deus, são movimento. Logo, nem todas são vida, nele.

2. Demais. — Todas as coisas estão em Deus como no exemplar primeiro. Ora, os exemplados devem
conformar-se, em Deus, com o exemplar. Mas, como nem todas as coisas têm vida, parece que nem
todas são vida em Deus.

3. Demais. — Como diz Agostinho, a substância viva é melhor que qualquer substância não viva. Ora, se
as coisas sem vida são vida, em Deus, parece que são mais verdadeiras em Deus que em si mesmas. O
que é falso, pois, em si, existem em ato e, em Deus, em potência.

4. Demais. — Como Deus conhece as coisas boas e as que faz em determinado tempo, assim também,
as más e as que pode fazer embora nunca as faça. Ora, se todas são nele vida, enquanto as conhece,
parece que mesmo as más, e as que nunca serão feitas são também vida em Deus, enquanto as
conhece. O que é inadmissível.
Mas, em contrário, a Escritura (Jo 1, 4): O que foi feito era vida nele. Ora, tudo, menos Deus, foi criado.
Logo, tudo é, em Deus, vida.

SOLUÇÃO. — Como já dissemos, a vida de Deus é o seu inteligir. Ora, em Deus são idênticos o intelecto,
o que é inteligido e o próprio inteligir. Logo, tudo o que está como inteligido, em Deus, é o seu próprio
viver ou a sua vida. Portanto, estando em Deus todas as coisas que ele fez, como inteligidas, resulta que
todas são a sua própria vida divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dizemos que as criaturas estão em Deus, de duplo
modo. De um modo, enquanto contidas e conservadas pela virtude divina, assim como dizemos que está
em nós aquilo que está em nosso poder. E assim dizemos que as criaturas estão em Deus mesmo,
enquanto existentes nas suas naturezas próprias. E neste sentido deve entender-se o dito do
Apóstolo: Nele mesmo vivemos e nos movemos e existimos; porque mesmo o ser nosso, a nossa vida e
o nosso movimento são causados por Deus. De outro modo, dizemos que as coisas estão em Deus,
como no conhecente. E, assim, nele estão pelas suas razões próprias, que não diferem, em Deus, da
essência divina. Por onde, as coisas, enquanto assim estão em Deus, são a divina essência. E como a
essência divina é vida e não, movimento, resulta que as coisas, segundo este modo de falar, são em
Deus vida e não movimento.

RESPOSTA À SEGUNDA. — Os exemplados necessariamente hão de conformar-se com o exemplar, pela
essência formal e não, pelo modo de existir. Ora, a forma tem o ser, de um modo, no exemplar e de
outro no exemplado. Assim, a forma da casa, na mente do artífice, tem o ser imaterial e inteligível; na
casa, porém, que existe fora da alma, tem o ser material e sensível. Por onde, as essências das coisas,
em si mesmas não vivas, são vida na mente divina, porque nela têm o ser divino.

RESPOSTA À TERCEIRA. — Se a matéria não fosse da essência das coisas naturais, mas somente a forma,
de todos os modos elas existiriam mais verdadeiramente na mente divina, pelas suas formas, do que em
si mesmas. E por isso Platão ensinou, que o homem separado é o verdadeiro homem; ao passo que o
homem material é homem por participação. Mas, sendo a matéria, da essência das coisas naturais,
devemos dizer, que elas têm o ser mais verdadeiro, absolutamente falando, na mente divina, que em si
mesmas. Porque, na mente divina, têm-no incriado e, em si mesmas, criado. Mas, um determinado ser,
como o de homem ou de cavalo, tem-no mais verdadeiramente na natureza própria que na mente
divina. Pois, ao homem real é próprio o ser material, que não tem na mente divina. Assim, uma casa tem
existência mais nobre na mente do artífice, que na matéria. Contudo, é mais verdadeira a que existe
materialmente, do que a existente na mente; porque a primeira é casa em ato, e esta, somente em
potência.

RESPOSTA À QUARTA. — Embora o mal esteja na ciência de Deus, enquanto por ela compreendido,
contudo, não está em Deus como se fosse criado ou conservado por ele, nem como tendo nele a sua
razão; pois, é conhecido por Deus em razão do bem. Por onde, não podemos dizer, que o mal seja vida
em Deus. Os possíveis, porém, que não existirão em tempo nenhum, podemos considerá-los vida em
Deus, enquanto que viver, significando somente inteligir, eles são inteligidos por Deus. Mas, não
enquanto viver implica um princípio de operação.