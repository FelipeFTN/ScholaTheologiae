# Questão 77: Do que se refere às potências da alma em geral.
Em seguida deve-se tratar do que se refere às potências da alma. Primeiro, em geral. Segundo, em
especial.
Sobre o primeiro ponto, oito artigos se discutem:

## Art. 1 — Se a essência mesma da alma é potência desta.
(Supra, q. 54, a. 3: I Sent., dist. III. q, 4, a. 2; Se Spirit. Creat., a. 11; Quodl. X. q. 3, a. 1; Qu. De Anima, a.
12).
O primeiro discute-se assim. ― Parece que a essência mesma da alma não é potência ativa desta.

1. ― Pois, diz Agostinho: o espírito, o conhecimento e o amor estão, na alma, substancialmente, ou, por
assim dizer, essencialmente; e ainda: a memória, a inteligência e a vontade são uma só vida, uma só
inteligência e uma só essência.

2. Demais. ― A alma é mais nobre que a matéria prima. Ora, esta é potência de si mesma. Logo, com
maioria de razão, a alma.

3. Demais. ― A forma substancial é mais simples que a acidental; e a prova é que ela não aumenta nem
diminui, mas permanece indivisível. Ora, a forma acidental é virtude de si mesma. Logo, com maioria de
razão, a substancial, que é a alma.

4. Demais. ― Pela potência sensitiva, sentimos; e, pela intelectiva, inteligimos. Ora é pela alma que,
primariamente, sentimos e inteligimos, segundo o Filósofo. Logo, a alma é potência de si mesma.

5. Demais. ― O que não pertence à essência de uma coisa é acidente. Se, pois, a potência da alma é
ulterior à essência da mesma, segue-se que é acidente; o que vai contra Agostinho, quando diz, que as
qualidades preditas não estão na alma como sujeito, ao modo da cor ou da figura, no corpo, ou doutra
qualquer qualidade ou quantidade; pois, tudo o que é desta natureza não excede o sujeito em que está.
Ora, o espírito pode também conhecer e amar outras coisas.

6. Demais. ― A forma simples não pode ser sujeito. Ora, a alma, não sendo composta de matéria e
forma, como já se demonstrou antes (q. 75, a. 5), é forma simples. Logo, a potência da alma não pode
estar em si mesma como num sujeito.

7. Demais. ― O acidente não é princípio substancial da diferença. Ora, o sensível e o racional são
diferenças substanciais e se radicam no sentido e na razão, potências da alma. Logo, estas não são
acidentes e, portanto, são a essência da mesma.
Mas, em contrário, diz Dionísio: os espíritos celestes se dividem em essências, virtude e operação.
Portanto, com maioria de razão, na alma, uma coisa é a essência e outra, a virtude ou potência.

SOLUÇÃO. ― É impossível admitir que a essência da alma seja potência da mesma, embora alguns assim
o ensinassem. O que se demonstra de duplo modo, quanto ao ponto em discussão. ― Primeiro, porque,
dividindo-se o ser e qualquer gênero do ser em potência e ato, necessário ê que a potência e o ato
sejam referidos ao mesmo gênero; por onde, se o ato não pertencer ao gênero da substância, a
potência, que a ele se refere, não pode pertencer a esse gênero. Ora, a operação da alma não está no
gênero da substância, salvo em Deus, do qual a operação é a própria substância. Por onde, a potência
de Deus, princípio da operação, é a essência mesma dele. O que não pode ser verdadeiro, nem da alma,
nem de qualquer criatura, como já antes se disse também do anjo (q. 54, a. 3). ― Segundo, tal é
também impossível, quanto à alma, que é, por essência, ato. Se, pois, a essência mesma da alma fosse
princípio imediato de operação, quem tivesse sempre alma, exerceria em ato as operações da vida;
assim como, quem sempre têm alma é vivo em ato. Como forma, pois, a alma não é um ato ordenado a
outro ato ulterior, mas é o último termo da geração. Por onde, não é pela essência, enquanto quanto
forma, mas pela potência, que a alma é potencial em relação a outro ato. E assim, enquanto submetida
à sua potência, ela se chama ato primeiro, ordenado ao ato segundo; pois, como se verifica, quem tem
alma nem sempre exerce, em ato, as operações da vida. Por onde, na definição da alma se diz que é o
ato do corpo tendo a vida em potência, cuja potência, todavia, não exclui a alma. Logo, conclui-se que a
essência da alma não é potência da mesma, pois nada que seja ato pode estar em potência atual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Agostinho se refere ao espírito enquanto se conhece e
se ama. Assim, pois, o conhecimento e o amor, enquanto referidos à alma, como conhecida e amada,
nela estão substancial ou essencialmente; porque a substância mesma ou essência da alma é que é
conhecida e amada.E do mesmo modo se deve entender o que diz, noutro passo, que são a mesma vida,
o mesmo espírito, a mesma essência. ― Ou, como dizem alguns, essa maneira de falar é verdadeira
quanto ao modo pelo qual o todo potencial, meio entre o todo universal ti o integral, se predica das
suas partes. Pois, o todo universal está, na sua essência e virtude totais, em qualquer das partes, como
p. ex., animal, no homem e no cavalo; e, por isso, ele se predica propriamente, de cada parte. Porém, o
todo integral não está em qualquer das partes, nem quanto à essência nem quanto à virtude totais; e,
portanto, de nenhum modo se predica de cada parte; mas de certo modo, embora impropriamente, de
todas simultaneamente; como se p. ex., dissermos que a parede, o teto e os alicerces são a casa. O todo
potencial, enfim, está em cada uma das partes quanto à essência total, mas não quanto à virtude total;
e, portanto, pode, de certo modo, predicar-se de qualquer das partes, mas não tão propriamente como
o todo universal. E deste modo Agostinho diz, que a memória, a inteligência e a vontade são a essência
mesma da alma.

RESPOSTA À SEGUNDA. ― O ato, em relação ao qual a matéria prima é potencial, é a forma substancial;
por onde, a potência da matéria não difere da essência da mesma.

RESPOSTA À TERCEIRA. ― A ação, bem como o ser, é próprio do composto; pois, age o que existe. Ora,
o composto tem pela forma substancial, o ser, substancialmente; e pela virtude, resultante da forma
substancial, opera. Por onde, a forma acidental ativa, p. ex., o calor, está para a forma substancial do
agente, a forma do fogo, assim como a potência da alma está para a alma.

RESPOSTA À QUARTA. ― O fato mesmo de ser a forma acidental princípio de ação, resulta da forma
substancial; por onde, esta é o princípio primeiro, embora não próximo da ação. E neste sentido o
Filósofo diz que a alma é que nos faz inteligir e sentir.

RESPOSTA À QUINTA. ― Se se entende por acidente o que se opõe, na divisão, à substância, então não
pode haver entre eles nenhum termo médio; pois, se dividem relativamente à afirmação e à negação, i.
é., relativamente ao estar e ao não estar num sujeito. E, deste modo, não sendo a potência da alma a
essência da mesma, necessário é seja acidente e se compreenda na segunda espécie da qualidade. Se,
porém, se se considerar o acidente como um dos cinco universais, então, haverá entre ele e a substância
um termo médio. Porque, à substância pertence tudo o que é essencial à coisa. Ora, nem tudo o que for
exterior à essência se poderá considerar como acidente, neste sentido, mas só o que não for causado
pelos princípios essenciais da espécie. Assim, o próprio não é da essência da coisa, mas é causado pelos
princípios essenciais da espécie; e, por isso, é meio termo entre a essência e o acidente, no sentido
presente. E, deste modo, as potências da alma podem ser consideradas médias entre a substância e
acidente, sendo como que propriedades naturais à alma. ― E o dito de Agostinho, que o conhecimento
e o amor não estão na alma como os acidentes no sujeito, entende-se ao modo supra-referido,
enquanto se comparam com a alma, sendo esta, não amante e conhecente, mas amada e conhecida. E,
neste sentido, a sua prova é procedente; porque, se o amor estivesse na alma amada como num sujeito,
seguir-se-ia que o acidente transcenderia o seu sujeito, pois, há ainda outras coisas amadas pela alma.

RESPOSTA À SEXTA. ― A alma, embora não composta de matéria e forma, tem, contudo, algo de
mistura com a potencialidade, como já se disse antes (q. 75, a. 5 ad 4). E, por isso, pode ser considerada
sujeito do acidente. Porém, a proposição aí empregada realiza-se em Deus, ato puro; e nesta matéria é
que Boécio a usou.

RESPOSTA À SÉTIMA. ― O racional e o sensível, como diferenças, não se radicam nas potências do
sentido e da razão, mas na alma sensitiva e racional mesma. Como, porém, as formas substanciais, em
si, desconhecidas de nós, são conhecidas pelos acidentes, nada impede tomemos, por vezes, os
acidentes pelas diferenças substanciais.

## Art. 2 — Se há várias potências ativas da alma.
O segundo discute-se assim. ― Parece que não há várias potências ativas da alma.

1. ― Pois, a alma intelectiva é a que maior semelhança tem com Deus. Ora, em Deus, a potência é una e
simples. Logo, também na alma intelectiva.

2. Demais. ― Mais a virtude é superior e mais é unificada. Ora, a alma intelectiva excede, pela virtude,
todas as outras formas. Logo, deve, em máximo grau, ter uma só virtude ou potência ativa.

3. Demais. ― Operar é próprio do que existe em ato. Ora, é pela mesma essência da alma que o homem
tem o ser, segundo os diversos graus de perfeição, como antes já se demonstrou (q. 76, a. 3, 4). Logo,
pela mesma potência ativa da alma opera as diversas operações dos diversos graus.
Mas, em contrário, o Filósofo admite várias potências ativas da alma.

SOLUÇÃO. ― É necessário admitirem-se várias potências ativas da alma; o que se evidencia
considerando, como diz o Filósofo, nos seres ínfimos, que não podem, com poucos movimentos,
conseguir a bondade perfeita, mas só algumas das imperfeitas. Porém, os seres superiores a estes
alcançam a bondade perfeita, com muitos movimentos. E são ainda superiores a estes últimos os que a
alcançam com poucos. Mas, a suma perfeição é a dos seres que, sem movimento, possuem a bondade
perfeita. Do mesmo modo, é infimamente dotado para a saúde quem não pode conseguí-la
perfeitamente, mas só parcialmente, com o uso de poucos remédios; melhor dotado é quem pode
conseguir a saúde perfeita, mas com muitos remédios; ainda melhor quem a consegue com poucos
remédios; e otimamente dotado quem a tem sem nenhum remédio. Por onde, devemos admitir que os
seres inferiores ao homem alcançam certos bens particulares e, portanto, exercem algumas poucas e
determinadas operações e virtudes. Porém o homem pode conseguir a bondade universal e perfeita,
porque pode alcançar a beatitude. Estando, porém, no último grau dos seres, que, por natureza, são
capazes da beatitude, necessita a alma humana de muitas e diversas operações e virtudes. Ao passo
que, nos anjos, há menor diversidade de potências ativas; e em Deus não há nenhum potência, ou ação
além da essência. ― Mas há ainda outra razão por que a alma humana abunda em diversidade de
potências, a saber, por estar nos confins das criaturas espirituais e corporais; e, por isso, nela concorrem
às virtudes de umas e de outras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A alma intelectiva se aproxima da semelhança com
Deus, mais do que as criaturas inferiores, pelo fato mesmo de poder conseguir a bondade perfeita,
embora por muitas e diversas operações; sendo por aí, inferior às criaturas superiores.

RESPOSTA À SEGUNDA. ― A virtude unificada é superior se se aplicar a coisas iguais; mas a virtude
multiplicada é superior se mais coisas lhe estiverem sujeitas.

RESPOSTA À TERCEIRA. ― O mesmo ente tem um só ser substancial, embora possa exercer operações
diversas. Por onde, é Uma só a essência da alma, mas são várias as potências ativas.

## Art. 3 — Se as potências ativas se distinguem pelos seus atos e objetos.
(Qu. De Anima, a. 13; II De Anima, lect IV).
O terceiro discute-se assim. ― Parece que as potências ativas não se distinguem pelos seus atos e
objetos.

1. ― Pois, nada do que é posterior ou extrínseco pode determinar um ser especificamente. Ora, o ato é
posterior à potência; e o objeto é extrínseco. Logo, não podem determinar especificamente as potências
ativas.

2. Demais. ― Os contrários diferem em máximo grau. Se, pois, as potências ativas se distinguissem pelos
seus objetos, resultaria não terem os contrários à mesma potência ativa, o que, de ordinário, é
evidentemente falso quase sempre; assim, a mesma potência visiva vê o branco e o preto, o mesmo
gosto sente o doce e o amargo.

3. Demais. ― Removida a causa, removido fica o efeito. Se, pois, a diferença das potências ativas
resultasse da dos objetos, o mesmo objeto não pertenceria a diversas potências, o que, evidentemente
é falso, pois, o mesmo que a potência cognoscitiva conhece, a apetitiva deseja.

4. Demais. ― O que por si causa alguma coisa causa-a totalmente. Mas, certos objetos diversos há que,
pertencendo a diversas potências, pertencem também a uma só potência; p. ex., o som e a car
pertencem à visão e à audição, potências ativas diversas; e contudo pertencem também à potência una
do senso comum. Logo as potências ativas se não distinguem pela diferença dos objetos.
Mas, em contrário. ― O que é posterior se distingue pelo que é anterior. Ora, o Filósofo diz, que os atos
e as operações são, por natureza anteriores às potencias; e, além disso, anteriores aos atos são os seus
opostos ou objetos. Logo, as potencias se distinguem pelos seus atos e objetos.

SOLUÇÃO. ― A potência, como tal, sendo ordenada para o ato, é necessário que a noção dela seja
deduzida do ato para o qual está ordenada; e, por conseqüência, é forçoso que a noção de potência se
diversifique pela da do ato. Ora, a noção de ato se diversifica pela noção diversa de objeto. Mas, toda
ação ou é de uma potência ativa ou de uma passiva. Ora, o objeto está para o ato da potência passiva
como princípio e causa motora; assim a cor, enquanto move a vista é princípio da visão. Porém o objeto
está para o ato da potencia ativa como termo e fim; assim, objeto da virtude aumentativa é o todo
completo que é o fim do aumento. Ora, estes dois fatores, a saber o princípio e fim ou termo, é que
especificam a ação. Assim, a calefação difere do resfriamento em que, aquela passa do cálido, i. é., ativo
para o cálido, e, este do frio para o frio. Por onde, é forçoso que as potências se diversifiquem pelos
seus atos e objetos.
Mas, todavia, deve considerar-se que o acidental não diversifica a espécie. Não é porque o animal pode
ter uma certa cor, que as espécies animais se diversificariam por essa diferença. Mas diversificam-se
pela diferença que é essencial ao animal, i. é., pela da alma sensitiva, ora dotada de razão, ora sem ela;
e, por isso, racional e irracional são as diferenças que separam os diferentes animais, constituindo-os em
diversas espécies. Assim, pois, não é uma diversidade qualquer dos objetos que diversifica as potências
da alma, mas a diferença do objeto ao qual a potência, em si, se refere. Assim, o sentido, em si, diz
respeito à qualidade passível que, em si, se divide em cor, som e qualidades semelhantes; por onde,
uma é a potência sensitiva da cor, a saber, a visão, e outra a do som, a saber, a audição. Mas à qualidade
passiva, p. ex., a de um ser colorido, pode acidentalmente convir ser músico ou gramático, grande ou
pequeno homem ou pedra. E, portanto, por semelhantes diferenças as potências da alma se não
distinguem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Embora o ato seja, pelo ser, posterior a potencia, é-lhe
contudo anterior pelo ato cognitivo e pela noção, como o fim, no agente. Porém o objeto, embora seja
extrínseco, é contudo o princípio ou o fim da ação. Ora, tudo quanto for intrínseco a uma ação deve se
proporcionar ao princípio e ao fim.

RESPOSTA À SEGUNDA. ― Se uma potência tivesse em si, um dos contrários, como seu objeto, seria
necessário que outra tivesse outro. As potências da alma porém não dizem respeito, em si, à noção
própria de contrário, mas à comum de cada um deles; assim, a visão não diz respeito, em si, à noção de
branco, mas à de cor. E isto, porque um dos contrários encerra de certo modo a noção do outro,
estando um para o outro como o perfeito para o imperfeito.

RESPOSTA À TERCEIRA. ― Nada impede que um mesmo objeto seja relativo a noções diversas,
podendo, portanto, pertencer a potências diversas da alma.

RESPOSTA À QUARTA. ― A potência superior abrange uma noção mais universal do objeto do que a
potência inferior; pois, quanto mais superior é a potência tanto maior extensão tem, em relação aos
objetos. Por onde, muitos objetos sobre os quais se estende, em si, a potência superior, entram na
mesma noção e, todavia, diferem pelas noções sobre as quais se exercem, por si, as potências inferiores.
Donde vem o pertencerem objetos diversos a diversas potências inferiores, os quais, todavia, estão
sujeitos à potência superior.

## Art. 4 — Se há alguma ordem entre as potências da alma.
(Qu. De Anima, a. 13, ad 10).
O quarto discute-se assim. ― Parece que não há nenhuma ordem entre as potências da alma.

1. ― Pois, entre coisas compreendidas na mesma divisão não há anterior nem posterior, mas
simultaneidade. Ora, as potências da alma se compreendem na mesma divisão. Logo, não há entre elas,
nenhuma ordem.

2. Demais. ― As potências da alma se referem aos objetos e à alma mesma. Mas, por parte da alma, que
é una, não há entre elas nenhuma ordem; do mesmo modo, nem por parte dos objetos, que são
diversos e completamente diferentes uns dos outros, como se vê pela cor e pelo som. Logo, não há uma
ordem entre as potências da alma.

3. Demais. ― Em potências ordenadas, a operação de uma depende da de outra. Ora, o ato de uma
potência da alma não depende do ato de outra j pois, a visão pode se atualizar sem a audição e vice-
versa. Logo, não há uma ordem entre as potências da alma.
Mas, em contrário, o Filósofo compara as partes ou potências da alma com as figuras: Ora, estas têm
uma ordem entre si. Logo, também aquelas.

SOLUÇÃO. ― Sendo a alma una, e as potências, várias; e sendo numa certa ordem que se passa da
unidade para a multidão, necessário é que haja uma ordem entre as potências da alma. Ora, descobre-
se entre elas, tríplice ordem, das quais, duas dizem respeito à dependência de uma potência da outra; e
a terceira diz respeito à ordem dos objetos. Ora, de dois modos se pode considerar a dependência de
uma faculdade, de outra: segundo a ordem de natureza, pela qual os seres perfeitos são naturalmente
anteriores aos imperfeitos; e segundo a ordem da geração e do tempo, pela qual se passa do imperfeito
para o perfeito. ― Conforme, pois, a primeira ordem das potências, as intelectivas são anteriores às
sensitivas e, por isso, dirigem-nas e governam-nas. E semelhantemente,as sensitivas, conforme esta
mesma ordem, são anteriores às potências da alma vegetativa; Conforme, porém, a segunda ordem, as
coisas se passam inversamente. Pois, as potências da alma vegetativa são anteriores, na via da geração,
às da alma sensitiva e, por isso, preparam o corpo para as atividades destas. E, semelhantemente, o
mesmo se passa com as potências sensitivas em relação às intelectivas. ― Por fim, conforme a terceira
ordem, certas forças sensitivas se ordenam umas para as outras, a saber, a visão, a audição e o olfato.
Pois, o visível é naturalmente o que é primeiro, por ser comum aos corpos superiores e aos inferiores;
ao passo que o som é perceptível no ar, o qual é naturalmente anterior à mistura dos elementos, de que
depende o odor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― As espécies de um gênero estão entre si por
anterioridade e posterioridade, como os números e as figuras, quanto ao ser; embora se considerem
simultâneas enquanto recebem a predicação do gênero comum.

RESPOSTA À SEGUNDA. ― A ordem entre as potências da alma provém da alma que, segundo certa
ordem, se inclina para diversos atos, embora seja una por essência; e também procede dos objetos, bem
como dos atos, conforme já se disse.

RESPOSTA À TERCEIRA. ― A objeção procede, só quanto às potências entre as quais há ordem
conforme ao terceiro modo. Porém as potências ordenadas conforme os outros dois modos,
comportam-se entre si de modo que o ato de uma depende da outra.

## Art. 5 — Se todas as potências da alma nela estão como no sujeito próprio.
(De Spirit, Creat., a.4, ad 3; Compend. Theol., cap. LXXXIX, XCII).
O quinto discute-se assim. ― Parece que todas as potências da alma nela estão como em sujeito
próprio.

1. ― Pois, assim como as potências do corpo estão para o corpo, assim as da alma, para a alma. Ora, o
corpo é o sujeito das potências corpóreas. Logo, a alma o é das da alma.

2. Demais. ― As operações das potências da alma se atribuem ao corpo por causa da alma; pois, como
está dito, a alma é o que nos faz, primariamente, sentir e inteligir. Ora, os primeiros princípios das
operações da alma são as potências. Logo, estas estão na alma primariamente.

3. Demais. ― Agostinho diz, que a alma sente certas coisas, como o temor e semelhantes, não pelo
intermédio do corpo; antes, sem ele; outras, porém, sente pelo corpo. Ora, se a potência não estivesse
só na alma, como no sujeito próprio, esta nada poderia sentir sem o corpo. Logo, a alma é o sujeito da
potência sensitiva e, por paridade de razão, de todas as outras potências.
Mas, em contrário, diz o Filósofo, sentir não é próprio da alma nem do corpo, mas do conjunto. Logo, a
potência sensitiva está no conjunto, como no sujeito próprio. Por onde, não só a alma é o sujeito de
todas as suas potências.

SOLUÇÃO. ― É sujeito da potência operativa aquilo que é capaz de operar; pois, todo acidente
denomina o sujeito próprio. Ora, o ser que pode operar é o mesmo que opera. Por onde, a potência
pertence, necessariamente ao mesmo sujeito que a operação, como também diz o Filósofo. Ora, é
manifesto, pelo que já ficou dito antes (q. 75, a. 2, 3; q. 76, a. 1 ad 1), que certas operações da alma se
exercem sem órgão corpóreo, como inteligir e querer. Por onde, as potências, princípios destas
operações, estão na alma como no sujeito próprio. Outras operações da alma, porém, se exercem pelos
órgãos corpóreos, como, a visão pelos olhos; a audição, pelos ouvidos. E o mesmo se dá com todas as
outras operações da parte nutritiva e da sensitiva. Por onde, as potências, princípios de tais operações,
estão no conjunto, como no sujeito próprio, e não somente na alma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Diz-se que todas as potências são da alma, não como
sendo esta o sujeito delas, mas como o princípio; pois, é pela alma que o conjunto pode realizar as suas
operações.

RESPOSTA À SEGUNDA. ― Todas essas potências referidas estão na alma, antes de estarem no
conjunto, não como sendo ela o sujeito, mas o princípio.

RESPOSTA À TERCEIRA. ― Platão era de opinião, que sentir, como inteligir, é operação própria da alma.
E Agostinho, em muitas questões filosóficas, recorre às opiniões de Platão, não defendendo-as mas,
citando-as. Contudo, no tocante ao assunto presente, o seu dito, que a alma é capaz de certas
sensações mediante o corpo, e de certas, sem ele, pode se entender de duplo modo. De um, as
expressões mediante o corpo ou semo corpo determinam o ato de sentir, enquanto este parte do ser
que sente. E, então, a alma nada sente, sem o corpo, pois, o ato de sentir não pode resultar dela senão
por um órgão corpóreo. De outro modo, essas expressões podem se estender com determinado o ato
de sentir por parte do objeto sentido. E, então, a alma sente certas coisas mediante o corpo, i. é., nele
existente; assim, quando sente um ferimento ou coisa semelhante, Certas outras coisas, porém, sente
sem o corpo, i. é., sem que existam no corpo, mas só na apreensão da alma; assim quanto esta sente
entristecer-se ou alegrar-se com qualquer audição.

## Art. 6 — Se as potências da alma defluem da essência da mesma.
(I Sent., dist. III, q. 4, a. 2).
O sexto discute-se assim. ― Parece que as potências da alma não defluem da essência da mesma.

1. ― Pois, de um ser simples não podem provir seres diversos. Ora, a essência da alma é una e simples.
Logo, sendo as suas potências muitas e diversas, não lhe podem proceder da essência.

2. Demais. ― Aquilo de que alguma coisa procede é causa dessa coisa. Ora, não se pode considerar a
essência da alma como causa das potências; conforme verá claramente quem discorrer pelos diversos
gêneros e causas. Logo, as potências da alma não defluem da essência da mesma.

3. Demais. ― Emanação denomina um certo movimento. Ora, nada se move por si mesmo, como o
prova o Filósofo; salvo, levando-se em conta a parte, pois, então, diz-se que o animal se move a si
mesmo, por ser uma parte dele a que move e outra, a movida. Ora, a alma nem mesmo é movida, como
já se provou. Logo, ela não causa em si as suas potências.
Mas, em contrário. ― As potências da alma são certas propriedades naturais da mesma. Ora, o sujeito é
causa dos acidentes próprios, entrando por isso, na definição de acidente, como se vê em Aristóteles.
Logo, as potências da alma emanam-lhe da essência, como da causa.

SOLUÇÃO. ― A forma substancial e a acidental em parte convêm entre si e, em parte diferem. Convêm,
por serem ambas ato e por atualizarem, de certo modo, as coisas, Diferem, porém, em dois pontos. ―
Primeiro, porque a forma substancial causa o ser, absolutamente, e tem como sujeito o ser apenas em
potência; ao passo que a forma acidental não causa o ser, absolutamente, mas o que tem natureza ou
tal grandeza, ou outra qualquer modalidade, pois, o sujeito dela é o ser atual. Por onde se vê
claramente, que a atualidade existe na forma substancial antes de existir no sujeito desta. E como o que
é primeiro é, em qualquer gênero, a causa, a forma substancial causa, no sujeito, o ser atual. Mas,
inversamente, a atualidade se encontra nesta e, por isso, a atualidade desta forma é causada pela do
sujeito; de modo que este, quando ainda em potência, é susceptível daquela; e. quando já em ato, é
produtivo da mesma. Isto, porém, digo do acidente próprio e em si; pois, do acidente estranho o sujeito
é somente susceptível da forma, sendo, então, o agente extrínseco o produtivo. ― Segundo, as duas
formas diferem entre si porque, existindo o que é menos principal por causa do que é mais principal, a
matéria existe por causa da forma substancial; mas, inversamente, a forma acidental existe por causa do
acabamento do sujeito.
Pois, como, é manifesto, pelo que já foi dito (a. 6), o sujeito das potências da alma é, ou a alma mesma
em separado ― que pode ser sujeito do acidente, por ter algo de potencialidade, como antes se disse (a.
1 ad 6; q. 75, a. 5 ad 4) ― ou o composto. Ora, este é atualizado pela alma. Por onde, é claro que todas
as potências da alma, quer tenham como sujeito a alma, em separado, ou o composto, emanam da
essência da mesma, como do princípio; porque, como já ficou dito, o acidente é causado pelo sujeito,
enquanto este é atual, e é recebido no mesmo enquanto este é potencial.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― De um ser simples podem proceder, naturalmente,
muitos outros, por uma certa ordem; e, além disso, por causa da diversidade dos recipientes. Assim,
pois, da essência una da alma procedem muitas e diversas potências, quer por causa da ordem delas,
quer por causa da diversidade dos órgãos corpóreos.

RESPOSTA À SEGUNDA. ― O sujeito é causa do acidente próprio; tanto causa final e de certo modo
ativa e também material, enquanto susceptível do acidente. E, por isso, pode-se admitir que a essência
da alma é a causa de todas as potências, como fim e como princípio ativo; e de certas, como susceptivo.

RESPOSTA À TERCEIRA. ― A emanação dos acidentes próprios, do sujeito, não se dá por qualquer
transmutação; mas por um certo e natural resultar; como que, de um naturalmente resultando o outro,
do mesmo modo que, da luz resulta a cor.

## Art. 7 — Se uma potência da alma nasce da outra.
(I Sent., dist. III, q. 4, a. 3; dist. XXIV, q. 1, a. 2; Qu. De Anima, a. 13, ad. 7, 8).
O sétimo discute-se assim. ― Parece que uma potência da alma não nasce de outra.

1. ― De coisas que começam a existir simultaneamente, uma não nasce de outra. Ora, todas as
potências da alma foram criadas simultaneamente com ela. Logo, uma não nasce de outra.

2. Demais. ― A potência nasce da alma como o acidente do sujeito. Ora, uma potência não pode ser o
sujeito de outra, porque não há acidente do acidente. Logo, uma não nasce de outra.

3. Demais. ― O oposto não nasce do oposto; mas cada ser nasce do que lhe é especificamente
semelhante. Ora, as potências da alma dividem-se por oposição, constituindo como espécies diversas.
Logo, uma não procede de outra.
Mas, em contrário. ― As s potências conhecem-se pelos atos. Ora, o ato de uma é causado pelo de
outra; assim, o ato da fantasia, pelo ato do sentido. Logo, uma potência da alma é causada por outra.

SOLUÇÃO. ― Em seres vários que, numa ordem natural, procedem de um só, assim como o primeiro é a
causa de todos, assim o que estiver mais próximo dele é, de certo modo, causa dos que do mesmo
estiverem mais afastados. Ora, como já ficou demonstrado antes (a. 4), há ordem múltipla entre as
potências da alma; portanto, uma potência procede da essência da alma, mediante outra. ― Mas, a
essência da alma está para as potências como princípio ativo e final e como princípio receptivo, quer
separadamente, por si, ou simultaneamente com o corpo. Ora, sendo o agente e o fim mais perfeito; e o
princípio receptivo como tal, menos perfeito, resulta, por conseqüência, que as potências da alma
primeiras, quanto à ordem da perfeição e da natureza, são os princípios das outras, como fim e princípio
ativo. Pois, vemos que o sentido é para servir ao intelecto e não inversamente; porquanto o sentido é
uma como participação deficiente do intelecto e, portanto, é de certo modo, pela sua origem natural,
proveniente do intelecto, como o imperfeito, do perfeito. Mas, por via do princípio receptivo dá-se o
inverso: as potências mais imperfeitas são princípios em relação às outras. Assim a alma, tendo a
potência sensitiva, é considerada sujeito e como algo de material, em relação ao intelecto. E, por isso, as
potências mais imperfeitas são anteriores, na via da geração, pois, antes é gerado o animal do que o
homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Assim como a potência emana da essência da alma, não
por transmutação, mas como resultante natural, e existe simultânea mente com a alma; assim o mesmo
se dá com uma potência em relação à outra.

RESPOSTA À SEGUNDA. ― Um acidente, por si, não pode ser sujeito de outro acidente; mas um
acidente pode ser recebido pela substância, antes de outro; assim, a quantidade, antes da qualidade. E,
deste modo, se diz que um acidente é sujeito de outro, como a superfície, da cor, porque, mediante um
a substância recebe outro. E o mesmo se pode dizer das potências da alma.

RESPOSTA À TERCEIRA. ― As potências da alma se opõem entre si como o perfeito se opõe ao
imperfeito e também como as espécies dos números e das figuras. Mas essa oposição não impede que
uma se origine de outra pois, o imperfeito procede naturalmente do perfeito.

## Art. 8 — Se todas as potências da alma permanecem nela, quando separada do corpo.
(IV Sent., dist. XLIV; q. 3, a. 3, qª 1, 2: dist. I, q. 1, a. 1; II Cont. Gent., cap. LXXXI: De Virtut., q. 5, a. 4, ad
13; Qu. De Anina, a. 19; Quodl. X, q. 4, a. 2).
O oitavo discute-se assim. ― Parece que todas as potências da alma nela permanecem, quando
separada do corpo.

1. ― Pois, como foi dito, a alma separa-se do corpo, levando consigo o sentido e a imaginação, a razão e
o intelecto e a inteligência, o concupiscível e o irascível.

2. Demais. ― As potências são as propriedades naturais da alma. Mas a propriedade é sempre inerente
ao ser ao qual pertence e deste nunca se separa. Logo, as potências da alma nela permanecem, mesmo
depois da morte.

3. Demais. ― As potências da alma, mesmo as sensitivas, não se debilitam com a debilitação do corpo;
porque, como já se disse, se um velho recebesse os olhos de um moço veria, por certo, como este. Ora,
a debilidade é via para a corrupção. Logo, as potências não se corrompem com a corrupção do corpo,
mas permanecem na alma separada.

4. Demais. ― A memória é uma potência da alma sensitiva, como o Filósofo o prova. Ora, a memória
permanece na alma separada; pois, na Escritura (Lc 16, 25) se diz ao conviva rico, com a alma no inferno:
Lembra-te que recebeste os teus bens em tua vida. Logo, a memória permanece na alma separada e,
por conseqüência, as outras potências da parte sensitiva também nela permanecem.

5. Demais. ― A alegria e a tristeza permanecem ao concupiscível, potência da parte sensitiva. Ora, é
manifesto, as almas separadas contristam-se e alegram-se com os prêmios ou penas que têm. Logo, a
virtude concupiscível permanece na alma separada.

6. Demais. ― Agostinho diz, que, assim como a alma vê certas coisas, por visão imaginária, quando o
corpo jaz sem sentidos, não ainda completamente morto; assim também quando estiver
completamente separada do corpo pela morte. Ora, a imaginação é uma potência da parte sensitiva.
Logo, as potências dessa parte permanecem na alma separada e, por conseqüência, todas as outras
potências. Mas, em contrário, foi dito: O homem se compõe só de duas substâncias: a alma e a sua
razão, e a carne com os seus sentidos. Logo, destruída a carne, as potências sensitivas não permanecem.

SOLUÇÃO. ― Como já ficou dito (a. 5, 6, 7), todas as potências se comparam com a alma, em separado,
como com o princípio. Mas, certas potências se comparam com a alma, em separado, como com o
sujeito, e são o intelecto e a vontade; e tais potências necessário é que permaneçam na alma, depois de
destruído o corpo. Outras porém, estão no conjunto, como no sujeito próprio; assim, todas as das partes
sensitiva e nutritiva. Ora, destruído o sujeito, o acidente não pode permanecer; por onde, corrupto o
conjunto, tais potências não permanecem na alma, atualmente, mas só virtualmente, como no princípio
ou na raiz. ― E, por isso, é falsa a opinião de alguns, que tais potências permanecem na alma, mesmo
depois de corrupto o corpo. E muito mais falsamente dizem; que também os atos dessas potências
permanecem na alma separada, o que ainda é mais falso, por não haver nenhum ato delas que se não
exerça por órgão corpóreo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A obra citada nenhuma autoridade tem e, por isso, tudo
o que nela se acha deve-se desprezar, com a mesma facilidade com que foi escrito. Pode-se, todavia,
dizer que a alma arrasta consigo as potências referidas, não atual, mas virtualmente.

RESPOSTA À SEGUNDA. ― As potências, de que dizemos não permanecerem em ato na alma separada,
não são propriedades só da alma, mas do conjunto.

RESPOSTA À TERCEIRA. ― Diz-se que tais potências não se debilitam, com a debilitação do corpo,
porque a alma, princípio virtual delas, permanece imutável.

RESPOSTA À QUARTA. ― Essa lembrança deve-se entender do modo pelo qual Agostinho admite a
memória no espírito, e não enquanto a considera parte da alma sensitiva.

RESPOSTA À QUINTA. ― Há alegria e tristeza na alma separada, não segundo o apetite sensitivo, mas
segundo o intelectivo; como também se dá com os anjos.

RESPOSTA À SEXTA. ― Agostinho, nesse passo, exprime-se inquirindo e não afirmando. E, por isso,
retrata certas coisas aí ditas.