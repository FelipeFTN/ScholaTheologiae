# Questão 89: Do conhecimento da alma separada.
Em seguida deve–se tratar do conhecimento da alma separada.
E, sobre este ponto, oito artigos se discutem:

## Art. 1 — Se a alma separada pode inteligir alguma coisa.
O primeiro discute–se assim. Parece que a alma separada não pode inteligir absolutamente nada.

1. – Pois, como diz o Filósofo, corrompe–se o inteligir de ficar com uma certa corrupção interna. Mas,
tudo o que é interno, no homem, corrompe–se pela morte. Logo, também há de corromper–se o
próprio inteligir.

2. Demais. – A alma humana, como já se disse, pode ser impedida de inteligir pela obstrução dos
sentidos e pela imaginação perturbada. Ora, pela morte, os sentidos e a imaginação se corrompem
totalmente, como resulta do sobredito. Logo, a alma, depois da morte, nada intelige.

3. Demais. – Se a alma separada intelige, necessariamente há de inteligir por meio de certas espécies.
Ora, não intelige por meio de espécies inatas, porque, a princípio, é como uma táboa na qual nada está
escrito, Nem por meio de espécies que abstraia das coisas, porque não tem os órgãos do sentido e da
imaginação, mediante os quais as espécies inteligíveis são abstraídas das coisas. Nem ainda por meio de
espécie já anteriormente abstratas e conservadas na alma, porque, então, a alma da criança nada
inteligiria, depois da morte. Nem, enfim, por meio de espécies inteligíveis divinamente influídas, pois,
então, tal conhecimento não seria o natural, que é o de que agora se trata, mas o da graça. Logo, a alma
separada do corpo nada intelige.
Mas, em contrário, diz o Filósofo, que se a alma não tem nenhuma operação própria, não pode existir
separada. Ora, ela pode existir separada. Logo, tem operação que lhe é própria e, sobretudo, a de
inteligir, Logo, intelige quando separada do corpo.

SOLUÇÃO. – Esta questão encerra dificuldade porque a alma, enquanto esta unida ao corpo, não pode
inteligir nada sem se voltar para os fantasmas, como a experiência o prova. Se, porém, como queriam os
Platônicos, não é pela sua natureza que a alma assim intelige, mas só por acidente, enquanto unida ao
corpo, então a questão pode se resolver facilmente. Pois, removido o impedimento do corpo, a alma
tornaria à sua natureza, inteligindo simplesmente os inteligíveis, sem se voltar para os fantasmas, como
acontece com as outras substâncias separadas. Mas, segundo tal opinião, não foi para a sua perfeição
que a alma foi unida ao corpo, desde que intelige menos, unida a este, do que separada do mesmo; mas
só para a perfeição do corpo. O que é irracional, porque a matéria existe para a forma e não
inversamente. Se, porém, admitirmos que a alma intelige, por natureza, voltando–se para os fantasmas,
como essa natureza não se muda pela morte do corpo, resulta que a alma, então, nada poderá inteligir,
naturalmente, por não lhe estarem presentes os fantasmas para os quais se volte.
E portanto, para eliminar a dificuldade presente, deve–se considerar que, como nenhum ser opera
senão enquanto atual, o modo de qualquer cousa operar segue–se–lhe ao modo de ser. Ora, um é o
modo de ser da alma enquanto unida ao corpo, e outro, quando dele separada, permanecendo, porém
sempre a mesma natureza dela. Não que lhe seja acidental o estar unida ao corpo, pois isso é em
virtude da natureza da mesma; assim como também a natureza leve não se muda quando está no seu
lugar próprio, como lhe é natural, e quando está fora desse lugar, o que lhe é contra a natureza. Por
onde, segundo o modo, de ser pelo qual está unida ao corpo, à alma é próprio o modo de inteligir que
consiste em voltar–se para os fantasmas dos corpos, que estão nos órgãos corpóreos. Quando, porém,
estiver separada do corpo, ser–lhe–à próprio o modo de inteligir consistente em voltar–se para o que é
absolutamente inteligível, como as demais substâncias separadas do corpo. E, portanto, o modo de
inteligir, que consiste em voltar–se para os fantasmas, é natural à alma, como natural lhe é o estar unida
ao corpo; mas, como está fora da essência da sua natureza o existir separada do corpo,
semelhantemente, é–lhe contra a natureza inteligir sem se voltar para os fantasmas. E é para operar
conforme a sua natureza que está unida ao corpo.
Mas aqui surge ainda uma dúvida. Pois, como as coisas sempre se ordenam para o que lhes está melhor,
e como é melhor modo de inteligir o que consiste em voltar–se para os inteligíveis, absolutamente, do
que o consistente em voltar–se para os fantasmas, Deus devia ter instituído a natureza da alma tal que
lhe fosse natural o modo de inteligir mais nobre, sem que ela precisasse, para isto, de estar unida ao
corpo.
Deve–se, pois, considerar que, embora inteligir, voltando–se para o que é superior, seja, absolutamente,
mais nobre do que inteligir, voltando–se para os fantasmas, contudo, aquele modo de inteligir,
conquanto possível à alma, seria mais imperfeito. O que assim se evidencia. Em todas as substâncias
intelectuais a virtude intelectiva existe por influência do lume divino. Ora, este, no primeiro princípio, é
um e simples; e quanto mais as criaturas intelectuais distam do primeiro princípio, tanto mais se divide e
diversifica esse lume, como se dá com as linhas que partem do centro. E daí vem que Deus, pela sua
essência una, intelige todas as coisas. Porém as substâncias intelectuais superiores, embora intelijarn
por meio de várias formas, contudo estas são em menor número, mais universais e mais aptas para a
compreensão das coisas, por causa da eficácia da virtude intelectiva dessas substâncias. Ao passo que,
nas substâncias inferiores, as formas são em maior número, menos universais e menos eficazes para a
compreensão das coisas, porque elas são deficientes em relação à virtude intelectiva das superiores. Se,
portanto, as substâncias inferiores tivessem formas da mesma universidade que as das superiores,
corno tais substâncias não têm a mesma eficácia no inteligir, não obteriam por meio dessas formas um
conhecimento perfeito das coisas, mas um conhecimento comum e confuso. O que, de certo modo, se
manifesta nos homens. Assim, os de intelecto mais fraco não obtêm, pelas concepções universais dos
mais inteligentes, um conhecimento perfeito, se não lhes explicarem cada questão em especial.
Ora, é manifesto que, entre as substâncias intelectuais, conforme a ordem da natureza, as Ínfimas são
as almas humanas. Pois, a perfeição do universo exigia que houvesse diversos graus nas coisas. Por
onde, se as almas humanas fossem instituídas por Deus de maneira que inteligissem pelo modo próprio
às substâncias separadas, elas não teriam um conhecimento perfeito, mas confuso e em comum. E,
portanto, para que pudessem ter das coisas um conhecimento perfeito e próprio, foram naturalmente
instituídas de maneira a estarem unidas aos corpos, de modo que tirem dos seres sensíveis, um
conhecimento próprio deles; assim como aos homens rudes não pode ser comunicada a ciência senão
por meio de exemplos sensíveis. Por onde é claro que é para a sua perfeição que a alma se acha unida
ao corpo e intelige, voltando–se para os fantasmas; e contudo pode existir separada e ter outro modo
de inteligir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO.
Discutidas diligentemente as palavras do Filósofo, ver–se–à que ele diz tal em virtude de uma suposição
anteriormente feita, a saber, que inteligir, assim como sentir, é um certo movimento do composto. Pois,
ainda não mostrara a diferença entre o intelecto e o sentido. – Ou se pode dizer que fala do modo de
inteligir que consiste em voltar–se para os fantasmas.
Donde também se origina a SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. – A alma separada não intelige por espécies inatas, nem por espécies que, na
ocasião, abstrai, nem só por espécies conservadas, como afirma a OBJEÇÃO; mas por espécies
participadas pela influência do divino lume, das quais a alma se torna participante do mesmo modo que
as outras substâncias separadas, embora em grau inferior. Donde, logo que ela cessa de se voltar para o
corpo, volta–se para o que é superior. Mas nem por isso o seu conhecimento deixa de ser natural;
porque Deus é o autor não só da influência do lume gratuito, mas também do natural.

## Art. 2 — Se a alma separada intelige as substâncias separadas.
O segundo discute–se assim. Parece que a alma separada não intelige as substâncias separadas.

1. − Pois, a alma é mais perfeita unida ao corpo do que dele separada, porque ela faz, naturalmente,
parte da natureza humana e a parte é mais perfeita quando está no seu todo. Ora, a alma unida ao
corpo não intelige as substâncias separadas, como antes já se viu. Logo, com maior razão, quando dele
estiver separada.

2. Demais. − Tudo o que é conhecido o é pela sua presença ou pela sua espécie. Ora, as substâncias
separadas não podem ser conhecidas da alma pela sua presença, pois só Deus penetra a alma. Nem
também por certas espécies que a alma pudesse abstrair, do anjo, porque este é mais simples que
aquela. Logo, de nenhum modo a alma separada pode conhecer as substâncias separadas.

3. Demais. – Certos filósofos ensinaram que no conhecimento das substâncias separadas consiste a
última felicidade do homem. Se, pois, a alma separada pode inteligir as substâncias separadas, ela
consegue, com a só separação sua, a felicidade; o que é inadmissível.
Mas, em contrário, as almas separadas conhecem as outras almas separadas; assim, o rico precipitado
no inferno, viu Lázaro e Abraão. Logo, as almas separadas vêm também os demônios e os anjos.

SOLUÇÃO. – Como diz Agostinho, a nossa alma obtém, por si mesma, o conhecimento das coisas
incorpôreas, isto é, conhecendo–se a si mesma, como antes já se disse. Ora, do modo pelo qual a alma
separada se conhece a si mesma, podemos deduzir de que modo conhece as outras substâncias
separadas. Ora, já ficou dito que, enquanto está unida ao corpo, ela intelige voltando–se para os
fantasmas. Por onde, não pode inteligir–se a si mesma senão na medida em que se atualiza, inteligindo
pela espécie, abstrata dos fantasmas; pois, é pelo seu ato que ela se intelige a si mesma, como já antes
se disse. Quando, porém, estiver separada do corpo, inteligirá voltando–se, não para os fantasmas, mas
para o que é por si mesmo inteligível e, assim, se inteligirá a si mesma por si mesma. Ora, é comum a
toda substância separada 0 inteligir, ao modo da sua substância, tanto o que lhe é superior como o que
lhe é inferior; pois, uma cousa é inteligida do modo pelo qual está em quem intelige, e está em outra ao
modo desta última. Ora, o modo da substância da alma separada é inferior ao da substância angélica,
mas é conforme ao modo das outras almas separadas. Por onde, das outras almas separadas ela tem
conhecimento perfeito; porém, dos anjos, imperfeito e deficiente, tratando–se de conhecimento natural
da alma separada. Porque o conhecimento da glória é de outra natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. − A alma separada é, por certo, mais imperfeita, se se
considerar a natureza pela qual ela comunica com a natureza do corpo; contudo é, de certo modo, mais
livre para inteligir, porque o gravame e liame do corpo impede–lhe a pureza da inteligência,

RESPOSTA À SEGUNDA. – A alma separada intelige os anjos pelas semelhanças divinamente impressas;
estas, porém, não têm a perfeita representação que eles tem, porque a natureza da alma é inferior à do
anjo.

RESPOSTA À TERCEIRA. – Não é no conhecimento de substâncias separadas quaisquer que consiste a
felicidade última do homem, senão só no de Deus, que não pode ser visto senão por graça. Há, contudo,
grande felicidade, embora não última, no conhecimento das outras substâncias separadas, se forem
perfeitamente inteIigidas. Ora, a alma separada não as intelige perfeitamente, com conhecimento
natural, como já se disse.

## Art. 3 — Se a alma separada conhece todas as coisas naturais.
O terceiro discute–se assim. – Parece que a alma separada conhece todas as coisas naturais.

1. – Pois, nas substâncias separadas estão as razões de todos os seres naturais. Ora, as almas separadas
conhecem as substâncias separadas. Logo, conhecem todas as coisas naturais.

2. Demais. – Quem intelige o mais inteligível pode, com maior razão, inteligir o menos inteligível. Ora, a
alma separada intelige as substâncias separadas, que são inteligíveis em máximo grau. Logo, com mais
razão, pode inteligir todas as coisas naturais, que são menos inteligíveis.
Mas, em contrário. – Os demónios têm conhecimento natural mais vigoroso que a alma separada. Ora,
eles não conhecem todas as coisas naturais, mas, antes, aprendem–nas pela experiência do longo
tempo, como diz Isidoro. Logo, nem as almas separadas conhecem todas as coisas naturais.

DEMAIS. – Se a alma, logo que fica separada, conhecesse todas as coisas naturais, em vão os homens se
esforçariam por adquirir o conhecimento das coisas. Ora, isto é inadmissível. Logo, a alma separada não
conhece todas as coisas naturais.

SOLUÇÃO. – Como já se disse antes, a alma separada intelige pelas espécies que recebe por influência
do divino lume, como os anjos. Contudo, como a natureza da alma é inferior à do anjo, ao qual esse
modo de conhecer é conatural, a alma separada não alcança, por meio de tais espécies, um
conhecimento perfeito das coisas, mas um conhecimento como em comum e confuso. Por onde, assim
como os anjos, por meio de tais espécies, alcançam o conhecimento perfeito das coisas naturais, assim,
as almas separadas alcançam um conhecimento imperfeito e confuso. Ora, os anjos, por meio das
sobreditas espécies, conhecem todas as coisas naturais com conhecimento perfeito, porque todas as
coisas que Deus fez com as suas naturezas próprias, Ele as fez na inteligência angélica, como diz
Agostinho. Por onde, também as almas separadas tem conhecimento de todas as coisas naturais, não
certo e próprio, mas comum e confuso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Nem o próprio anjo conhece, pela sua substâncias todas
as coisas naturais, mas por meio de certas espécies, como antes já ficou dito. E por isso, não se segue
que a alma conheça todas as coisas naturais, porque conhece a substância separada.

RESPOSTA À SEGUNDA. – Assim como a alma separada não intelige perfeitamente as substâncias
separadas, assim também não conhece perfeitamente todas as coisas naturais, senão sob certa
confusão, como já se disse.

RESPOSTA À TERCEIRA. – Isidoro fala do conhecimento dos futuros, os quais nem os anjos, nem os
demónios, nem as almas separadas alcançam, a não ser pelas causas deles ou pela revelação divina.
Nós, porém, falamos do conhecimento natural.

RESPOSTA À QUARTA. – O conhecimento que nesta vida se adquire pelo estudo, é próprio e perfeito; o
outro, porém, é confuso. Donde não se segue que esforço para aprender seja inútil.

## Art. 4 — Se a alma separada conhece as coisas singulares.
O quarto discute–se assim. – Parece que a alma separada não conhece as coisas singulares.

1. – Pois, nenhuma potência cognoscitiva, a não ser o intelecto, permanece na alma separada, como do
sobredito resulta. Ora, como já ficou estabelecido, o intelecto não conhece o singular. Logo, a alma
separada não conhece as coisas singulares.

2. Demais. – Mais determinado é o conhecimento do singular que o do universal. Ora, a alma separada
não tem nenhum conhecimento determinado das espécies das coisas naturais. Logo, com mais razão,
não conhece as coisas singulares.

3. Demais. – Se a alma conhece as coisas singulares, mas não pelos sentidos, por igual razão conheceria
todos os singulares. Ora, não os conhece todos. Logo, não conhece nenhum.
Mas, em contrário, o rico, precipitado no inferno, dizia: Tenho cinco irmãos, como se vê na Escritura.

SOLUÇÃO. – As almas separadas conhecem certas coisas singulares, mas não todas, mesmo das
presentes. O que se evidencia considerando–se que há duplo modo de inteligir. Um, por abstração dos
fantasmas; e, deste modo, as coisas singulares não podem ser conhecidas pelo intelecto diretamente,
mas só indiretamente, como antes ficou dito. Outro, pela influência das espécies, por parte de Deus; e,
deste modo, o intelecto pode conhecer as coisas singulares. Pois, assim como Deus, pela sua essência,
como causa dos princípios universais e individuais, conhece todas as coisas, tanto as universais como as
singulares, conforme já se viu antes; assim também as substâncias separadas, pelas espécies, que são
umas semelhanças participadas da mesma divina essência, podem conhecer as coisas singulares. Há
contudo diferença entre os anjos e as almas separadas, no seguinte: aqueles, por essas espécies, têm
das causas um conhecimento perfeito e próprio; ao passo que estas o têm confuso. Por onde, os anjos,
por causa da eficácia do seu intelecto, podem conhecer, pelas sobreditas espécies, não só as naturezas
das coisas, em especial, mas também as coisas singulares contidas nessas espécies. Enquanto que as
almas separadas não podem conhecer, por meio de tais espécies, senão somente aquelas coisas
singulares para as quais estão de certo modo determinadas, quer por um conhecimento precedente,
quer por alguma afeição, quer por uma relação natural ou por divina disposição; porque, tudo o que
num ser é recebido, é determinado neste ao modo do mesmo, como recipiente que é.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O intelecto, por via de abstração, não conhece as coisas
singulares. De maneira que, não assim, mas do modo referido, é que a alma separada as intelige.

RESPOSTA À SEGUNDA. – O conhecimento da alma separada é determinado para as espécies daquelas
coisas ou indivíduos para os quais tem alguma determinada relação, como antes já se disse.

RESPOSTA À TERCEIRA. – A alma separada não se comporta igualmente para com todas as coisas
singulares, mas tem, para com umas, uma determinada relação, que não tem para com outras. E,
portanto, não há a mesma razão para conhecer todas as causas singulares.

## Art. 5 — Se o hábito da ciência adquirida nesta vida permanece na alma separada.
O quinto discute–se assim. – Parece que o hábito da ciência adquirida nesta vida não permanece na
alma separada.

1. – Pois, diz a Escritura: A ciência será abolida.

2. Demais. – Certos há, menos bons, que neste mundo, são ricos de ciência; outros, porém, melhores
que eles, dela carecem. Se, pois o hábito da ciência permanecesse na alma, mesmo depois da morte,
resultaria que aqueles teriam, mesmo na vida futura, melhor posição que estes. O que é inadmissível.

3. Demais. – As almas separadas terão ciência das coisas, por influência do lume divino. Se, pois, a
ciência adquirida nesta vida permanece na alma separada, resultaria a existência de duas formas da
mesma espécie no mesmo sujeito. O que é impossível.

4. Demais. – O Filósofo diz: o hábito uma qualidade dificilmente removível; mas, pela doença ou por
outra causa semelhante, a ciência, por vezes, corrompe–se. Ora, não há nenhuma imutação tão forte,
nesta vida, como a que oriunda da morte. Logo, conclui–se que o hábito da ciência corrompe–se pela
morte.
Mas, em contrário, diz Jerónimo: Aprendamos na terra aquilo cuja ciência persevera no céu.

SOLUÇÃO. – Certos ensinaram que o hábito da ciência não está no intelecto mesmo, mas nas virtudes
sensitivas, a saber, a imaginativa, a cogitativa e a memorativa; e que as espécies inteligíveis não se
conservam no intelecto possível. E se esta opinião fosse verdadeira, resultaria que, destruído o corpo,
totalmente se destruiria o hábito da ciência adquirido nesta vida. Mas, como a ciência está no intelecto,
que é o lugar das espécies, segundo diz Aristóteles, necessário é que o hábito da ciência adquirido nesta
vida esteja, em parte, nas sobreditas virtudes sensitivas e, em parte, no intelecto mesmo. E isto se pode
concluir considerando os atos mesmos dos quais se adquire o hábito da ciência; pois, os hábitos são
semelhantes aos atos pelos quais são adquiridos, como diz o Filósofo. Ora, os atos do intelecto, pelos
quais, na vida presente, se adquire a ciência, se realizam pelo voltar–se do intelecto para os fantasmas,
que existem nas sobreditas virtudes sensitivas. Por onde, por meio de tais atos, tanto o intelecto
possível adquire uma certa faculdade de considerar por meio de espécies recebidas; como as sobreditas
virtudes inferiores adquirem uma certa habilidade, de modo que, voltando–se para elas, o intelecto
possa, mais facilmente especular os inteligíveis. Mas, assim como o ato do intelecto, principal e
formalmente está no intelecto mesmo; e, material e dispositivamente, está nas virtudes inferiores, o
mesmo também se deve dizer do hábito. Por onde, a parte da ciência presente que alguém tiver, nas
virtudes inferiores, não permanecerá na alma separada; mas, aquela que tiver no intelecto mesmo, essa
necessariamente há de permanecer. Porque, como se diz na obra da dilatação e brevidade da vida, uma
forma pode se corromper de duplo modo: em si mesma, quando corrompida pelo seu contrário, como o
cálido pelo frio; e por acidente, isto é, pela corrupção do sujeito. Ora, é manifesto que a ciência
existente no intelecto humano não pode corromper–se pela corrupção do sujeito, porque o intelecto é
incorruptível, conforme ficou demonstrado. Semelhantemente, também as espécies inteligíveis
existentes no intelecto possível não podem ser corrompidas pelo contrário, porque a intenção dos
inteligíveis não tem contrário nenhum; e, principalmente, tratando–se da inteligência simples que
intelige a quididade. Quanto, porém, à operação pela qual o intelecto compõe e divide, ou ainda,
raciocina, há nele contrariedade, por ser o falso, na proposição ou na argumentação, contrário ao
verdadeiro. E, deste modo, a ciência, às vezes, se corrompe pelo contrário, a saber, quando alguém por
uma argumentação falsa, aberra da ciência verdadeira. E por isso o Filósofo estabelece dois modos pelos
quais a ciência, em si mesma, se corrompe, a saber: pelo esquecimento, por parte da memorativa; e
pelo engano, por parte da falsa argumentação. Ora, isto não tem lugar na alma separada. Por onde,
deve–se concluir que o hábito da ciência, enquanto existente no intelecto, permanece na alma
separada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – No passo citado, o Apóstolo não se refere à ciência
quanto ao hábito, mas quanto ao ato do conhecimento. E, assim, para o comprovar, acrescenta: Ligara
conheço em parte.

RESPOSTA À SEGUNDA. – Assim como, em relação à estatura do corpo, um homem pode ser maior que
outro melhor que ele; assim também nada impede que um tenha, na vida futura, um hábito da ciência
que não tem outro melhor que ele, se bem que isso seja de quase nula importância, em comparação
com as outras prerrogativas que terão os melhores.

RESPOSTA À TERCEIRA. – Essas duas ciências não têm a mesma natureza. Donde, pois, não resulta
nenhum inconveniente.

RESPOSTA À QUARTA. – A OBJEÇÃO procede, em relação à corrupção da ciência, quanto ao que ela tem
procedente das virtudes sensitivas.

## Art. 6 — Se o ato da ciência adquirida nesta vida permanece na alma separada.
O sexto discute–se assim. – Parece que o ato da ciência adquirida nesta vida não permanece na alma
separada.

1. – Pois, diz o Filósofo, que, corrupto o corpo, a alma nem se lembra, nem ama. Ora, lembrar–se é
pensar no que já se conhecia. Logo, a alma separada não pode ter ato da ciência que adquiriu nesta
vida.

2. Demais. – As espécies inteligíveis não hão de ser mais eficientes na alma separada do que na que está
unida ao corpo. Ora, pelas espécies inteligíveis não podemos inteligir, presentemente, a não ser
voltando–nos para os fantasmas, como já se estabeleceu antes. Logo, também a alma separada não
poderá inteligir de outro modo. E, então, de nenhum modo poderá inteligir pelas espécies inteligíveis
adquiridas nesta vida.

3. Demais. – O Filósofo diz: os hábitos tornam os atos semelhantes aos atos pelos quais são adquiridos,
Ora, adquire–se o hábito da ciência, nesta vida, pelos atos do intelecto, que se volta para os fantasmas.
Logo, não pode tornar outros atos semelhantes a estes. –Ora, tais atos não são próprios à alma
separada. Logo, esta não terá nenhum ato da ciência adquirida nesta vida.
Mas, em contrário, na Escritura se diz ao rico precipitado no inferno: Lembra–te que recebeste bens em
tua vida.

SOLUÇÃO. – Duas coisas se devem considerar num ato : a espécie e o modo. Aquela se deduz do objeto
ao qual é dirigido o ato da virtude cognoscitiva, por meio da espécie, que é semelhança do objeto.
Porém o modo do ato é determinado pela virtude do agente.
Assim, vemos uma pedra por meio da espécie da mesma, que está nos olhos; mas se a vemos com
agudeza, isso provém da virtude visiva dos olhos. Como, pois, as espécies inteligíveis permanecem na
alma separada, segundo já se disse, e como o estado dela não é o mesmo que o da vida presente,
resulta que, pelas espécies inteligíveis adquiridas nesta vida, a alma separada poderá inteligir o que
antes já inteligira: não, porém, do mesmo modo, isto é, voltando–se para os fantasmas, mas por modo
que lhe seja conveniente. Assim, que os atos da ciência adquirida nesta vida permanecem, por certo, na
alma separada; mas não do mesmo modo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O Filósofo fala da reminiscência, enquanto a memória
pertence à parte sensitiva, não, porém, enquanto a memória está, de certo modo, no intelecto, como já
se disse.

RESPOSTA À SEGUNDA. – Os diversos modos de inteligir não provêm da diversidade das espécies; mas
dos diversos estados da alma que intelige.

RESPOSTA À TERCEIRA. – Os atos pelos quais se adquire o hábito são semelhantes aqueles que os
hábitos causam, quanto à espécie do ato; não, porém, quanto ao modo de agir. Pois, é o operar coisas
justas, mas não justamente, isto é, deleitavelmente, que causa o hábito da justiça política, pelo qual
operamos deleitávelmente.

## Art. 7 — Se a distância local Impede o conhecimento da alma separada.
O sétimo discute–se assim. – Parece que a distância local não impede o conhecimento da alma
separada.

1. – Pois, diz Agostinho: as almas dos: mortos estão onde não se podem saber as causar passadas neste
mundo. Sabem, entretanto, o que se faz entre elas. Logo, a distância local impede o conhecimento da
alma separada.

2. Demais. – Agostinho diz: os demônios, pela celeridade do movimento, anunciam certas coisas que nos
são desconhecidas: Ora, a agilidade do movimento de nada serviria para tal, se a distância local não
impedisse o conhecimento dos demônios. Logo, com maior razão, a distância local impede o
conhecimento da alma separada, inferior, por natureza, ao demônio.

3. Demais. – Assim como uma cousa dista localmente, assim também dista temporalmente. Ora, a
distância temporal impede o conhecimento da alma separada; pois ela não conhece os futuros. Logo,
resulta que a distância local também impede o conhecimento da mesma.
Mas, em contrário, diz a Escritura, que o rico, nos tormentos, levantando os olhos, viu Abraão de longe.
Logo, a distância local não impede o conhecimento da alma separada.

SOLUÇÃO. – Certos ensinaram que a alma separada conhece as coisas singulares abstraindo das
sensíveis. E se fosse verdade, poder–se–ia dizer que a distância local impede o conhecimento da alma
separada. Pois, seria necessário que os sensíveis agissem sobre ela, ou esta, sobre os sensíveis. E num e
noutro caso, seria necessária uma distância determinada. – Mas, tal opinião é impossível, porque a
abstração das espécies, dos sensíveis, faz–se mediante os sentidos e outras potências sensíveis, que não
permanecem atualmente na alma separada. Pois, a alma separada intelige os singulares pelo influxo das
espécies, proveniente do lume divino, cujo lume se comporta do mesmo modo, tanto com o que está
próximo como com o que está distante. Por onde, a distância local de nenhum modo impede o
conhecimento da alma separada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Agostinho não diz que é porque estão as almas dos mortos
nesse lugar, que as coisas passadas neste mundo não podem ser vistas, de modo a se crer que a
distância local seja a causa de tal ignorância; mas isso pode se dar por algum outro motivo, como a
seguir se dirá.

RESPOSTA À SEGUNDA. – Agostinho se exprime, nesse passo, segundo a opinião de certos, pela qual os
demónios têm corpos que lhe estão naturalmente unidos. E, segundo essa opinião, também eles podem
ter potências sensitivas, para cujo conhecimento é necessária determinada distância. E a essa opinião
Agostinho se refere expressamente no mesmo livro, embora pareça que nela toca antes expondo–a que
aceitando–a, como é claro pelo que diz na Cidade de Deus.

RESPOSTA À TERCEIRA. – Os futuros, que distam temporalmente, não são entes em ato. Por isso não
são cognoscíveis em si mesmos; pois, a deficiência que houver, em relação à entidade, haverá também
em relação à entidade, haverá também em relação à cognoscibilidade. Ora, os seres distantes,
localmente, são seres em ato e, em si, cognoscíveis. Por onde, não tem o mesmo fundamento a
distância local e a temporal.

## Art. 8 — Se as almas separadas conhecem as coisas que se passam neste mundo.
O oitavo discute–se assim. – Parece que as almas separadas conhecem as coisas que se passam neste
mundo.

1. – Pois, se não as conhecessem, com elas não se ocupariam. Ora, conforme diz a Escritura, elas se
ocupam com as causas que neste mundo se passam: Tenho cinco irmãos, para que lhes dê testemunho
não suceda "irem também eles parar a este lugar de tormentos. Logo, as almas separadas conhecem
tais coisas.

2. Demais. – Frequentemente os mortos aparecem aos vivos, adormecidos ou acordados, para lhes a
visarem das coisas que neste mundo se passam; assim, Samuel apareceu a Saul, como se lê na Escritura.
Ora, tal não se daria, se eles não conhecessem as coisas que se passam neste mundo.

3. Demais. – As almas separadas conhecem as coisas que entre elas se passam. Se, pois, não conhecem
o que se passa entre nós, é que esse conhecimento lhes é impedido pela distância local; o que foi
negado antes.
Mas, em contrário, diz a Escritura: ou os seus filhos estejam exaltados, ou estejam abatidos, ele não o
conhecerá.

SOLUÇÃO. – As almas dos mortos não conhecem, por conhecimento natural – que é o de que agora se
trata – as coisas que se passam neste mundo. E a razão disso pode ser deduzida do que já se disse antes.
Pois, a alma separada conhece as coisas singulares, ou porque, de certo modo, está determinada em
relação a elas, ou pelo vestígio de algum conhecimento QU afeto precedente, ou por ordem divina. Ora,
as almas dos mortos, por ordem divina e pelo modo de ser delas, estão segregadas da conversação dos
vivos, e em sociedade com as substâncias espirituais separadas do corpo. E por isso, ignoram o que se
passa entre nós. Esta razão é dada por Gregório quando diz: Os mortos não sabem como se dispõe,
depois que morreram, a "ida dos que ainda estão unidos à carne; porque a "ida do espírito dista muito
da vida carnal; e assim. como os seres corpóreos e os incorpóreos são genericamente diversos, assim
também são distintos pelo conhecimento. E isto mesmo o confirma Agostinho, ao dizer que as almas
dos mortos não têm contado com as coisas dos vivos.
Quanto às almas dos bem–aventurados, porém, diferem Agostinho e Gregório. – Pois, este no mesmo
passo, acrescenta: O que, todavia, não se deve pensar, em relação as almas santas ; pois de nenhum
modo se deve acreditar que ignorem algo de exterior, elas que, interiormente; vêm a claridade de Deus
omnipotente. – Ao passo que Agostinho diz expressamente, que os mortos, mesmo santos, não sabem
que jazem os vivos e os filhos destes, conforme está na Glossa sobre o passo da Escritura: Abraão não
nos conheceu. O que ele confirma com o fado de não ser mais visitado, nem consolado nas tristezas,
pela sua mãe, como quando ela vivia; não sendo provável que esta tenha se tornado mais cruel, numa
vida mais feliz. E ainda porque o Senhor prometeu ao rei Josias que morreria para não ver os males que
sobreviriam ao povo, como está na Escritura. Mas Agostinho explana o que fica exposto, como que
duvidando e por isso disse antes: cada um aceite o que digo, como quiser. Ao passo que Gregório se
exprime assertivamente, o que é claro pela sua maneira de escrever: de nenhum modo se deve
acreditar. E é mais aceitável a opinião de Gregório, que as almas dos santos, que vêm a Deus, conhecem
todas as causas presentes que neste mundo se passam. Pois, são iguais aos anjos, dos quais Agostinho
afirma que não ignoram o que se passa entre os vivos. Como, porém, as almas dos santos estão
perfeitissimamente unidas à justiça divina, não se contristam nem se ingerem nas causas dos vivos,
senão na medida em que o exige a disposição da justiça divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. As almas dos mortos podem se ocupar com as causas dos
vivos, mesmo se ignorem o estado destes; assim como nós nos ocupamos com as dos mortos, fazendo–
lhes sufrágios, embora lhes ignoremos o estado. E demais, os fados dos vivos podem ser conhecidos,
não por meio deles mesmos, mas pelas almas dos que vão, deste mundo, para o outro, ou pelos anjos,
ou pelos demônios, ou ainda pela revelação do Espírito de Deus, como diz Agostinho, no mesmo livro.

RESPOSTA À SEGUNDA. De qualquer modo que os mortos apareçam aos vivos, isso se dá por especial
dispensa de Deus, de modo que as almas deles possam imiscuir–se com as causas dos vivos; o que se
deve contar entre os milagres divinos. Ou tais aparições se fazem por operações dos anjos bons ou
maus, mesmo que os mortos o ignorem; assim como também os vivos, embora o ignorem, aparecem,
em sonhos, a outros vivos, conforme diz Agostinho, no livro supra citado. – Por onde, pode dizer–se que
Samuel apareceu por uma revelação divina, segundo a Escritura, que diz: dormiu e predisse ao rei o fim
da sua vida. Ou essa aparição foi causada pelos demônios, no caso em que não se queira aceitar a
autoridade do Eclesiástico, por não o contarem os Hebreus entre as Escrituras Canônicas.

RESPOSTA À TERCEIRA. – Essa ignorância não procede da distância local, mas da causa predita.