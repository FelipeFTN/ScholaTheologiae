# Questão 108: Da ordenação dos anjos por hierarquias e ordens.
Em seguida devemos tratar da ordenação dos anjos por hierarquias e ordens; pois, como já se disse, os
superiores iluminam os inferiores, e não vice-versa.
E sobre esta questão oito artigos se discutem:

## Art. 1 — Se todos os anjos são da mesma hierarquia.
(III, q. 8, a. 4; II Sent., dist. IX, a. 3; IV, dist. XXIV, q. 2, a. 1, qª 2, ad 4; Ephes., cap. I, lect. VII).
O primeiro discute-se assim. — Parece que todos os anjos são da mesma hierarquia.

1. — Pois, sendo os anjos as criaturas supremas, necessário é admitir-se que são otimamente dispostos.
Mas, como diz claramente o Filósofo, a melhor disposição é a da multidão regida por um só chefe. Ora,
como a hierarquia não é senão a chefia sagrada, resulta que todos os anjos são da mesma hierarquia.

2. Demais. — Dionísio diz, que a hierarquia é ordem, ciência e ação. Ora, todos os anjos convêm na
mesma ordem, em relação a Deus, a quem conhecem e por quem são regulados, nas suas ações. Logo,
todos são da mesma hierarquia.

3. Demais. — A chefia sagrada, chamada hierarquia, tanto existe entre os homens como entre os anjos.
Ora, todos os homens são da mesma hierarquia. Logo, também todos os anjos.
Mas, em contrário, Dionísio distingue três hierarquias de anjos.

SOLUÇÃO. — Como se disse, a hierarquia é uma chefia sagrada. Ora, a palavra chefia abrange duas
coisas: o chefe e o povo governado por ele. Ora, como Deus é o chefe, não só de todos os anjos, mas
também dos homens e de toda criatura, por isso, uma só hierarquia formam todos os anjos e toda
criatura racional, que possa ser participante das coisas sagradas, conforme a expressão de Agostinho: há
duas cidades, i. é, duas sociedades; uma a dos anjos bons e dos homens; outra, a dos maus. Se, porém,
se considerar a chefia em relação ao povo sujeito a um mesmo chefe, então forma uma chefia o povo
que pode estar, de um mesmo modo, sob o governo de um mesmo chefe; e, os povos, que não
puderem ser governados do mesmo modo, pelo mesmo chefe, formam chefias diversas. Assim, sob um
mesmo rei, estão as diversas cidades, regidas por leis e governadores diversos. Ora, é manifesto que os
homens recebem as iluminações divinas de modo diverso dos anjos; pois, estes a recebem na sua
pureza inteligível, ao passo que aqueles sob semelhanças sensíveis, como diz Dionísio. E portanto, é for-
çoso distinguir a hierarquia humana da angélica.
E do mesmo modo, distinguem-se três hierarquias de anjos. Pois, como já se disse (q. 55, a. 3), quando
se tratou do conhecimento dos anjos, os anjos superiores têm conhecimento mais universal da verdade,
que os inferiores. Ora, esta apreensão universal do conhecimento pode ser dividida por três graus, nos
anjos, pois, as razões das causas, sobre as quais os anjos são iluminados, podem-se considerar sob
tríplice aspecto. — Primeiro, enquanto procedentes do primeiro princípio universal, que é Deus. E este
modo convém à primeira hierarquia, que chega até Deus, e, corno diz Dionísio, está colocada quase nos
vestíbulos de Deus. — Segundo, enquanto tais razões dependem das causas universais criadas já, de
certa maneira, multiplicadas. E este modo convém à segunda hierarquia. — Terceiro, enfim, enquanto
tais razões se aplicam a coisas singulares dependentes das causas próprias. E este modo convém à
ínfima hierarquia, o que plenamente ficará explicado quando se tratar de cada uma das ordens (a. 6).
Assim, pois, as hierarquias se distinguem em relação à multidão governada.
Por onde, é manifesto que erram e vão contra a intenção de Dionísio, os que introduzem, nas divinas
Pessoas, a hierarquia a que chamam superceleste. Pois, nas Pessoas divinas há uma ordem de natureza
e não de hierarquia. Porque, como diz Dionísio, a ordem de hierarquia consiste em serem uns
purificados, iluminados e aperfeiçoados e em purificar, iluminar e aperfeiçoar a outros. E longe de nós
introduzir tais distinções nas Pessoas divinas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção é procedente, quanto à chefia, relativamente
ao chefe, porquanto é ótimo que o povo seja governado por um só chefe, como explica o Filósofo nos
passos citados.

RESPOSTA À SEGUNDA. — Quanto ao conhecimento de Deus mesmo, a quem todos os anjos vêm do
mesmo modo, i. é, em essência, neles não se distinguem hierarquias; mas, quanto à razão das coisas
criadas, como já se disse.

RESPOSTA À TERCEIRA. — Todos os homens são da mesma espécie e, por isso, é-lhes conatural o
mesmo modo de inteligir. Ora, como não se dá o mesmo com os anjos, não há semelhança de razão.

## Art. 2 — Se numa mesma hierarquia há muitas ordens.
(II Sent., dist. IX, a. 3; IV, dist. XXIV, q. 2, a. 1, qª 2, a. 4).
O segundo discute-se assim. — Parece que numa mesma hierarquia não há muitas ordens.

1. — Pois, multiplicada a definição, multiplica-se o definido. Ora, a hierarquia, como diz Dionísio, é uma
ordem. Se, portanto, são muitas as ordens, não haverá uma só, mas muitas hierarquias.

2. Demais. — Ordens diversas são graus diversos; e os graus, nos seres espirituais, são constituídos
segundo os diversos dons espirituais. Ora, nos anjos, todos os dons espirituais são comuns, porque nada
entre eles se possui singularmente. Logo, não são diversas as ordens dos anjos.

3. Demais. — Na hierarquia eclesiástica distinguem-se as ordens relativamente à purificação, à
iluminação e à perfeição. Pois, a ordem dos diáconos é purgativa; a dos sacerdotes, iluminativa; a dos
bispos, perfectiva, como diz Dionísio. Ora, qualquer anjo purifica, ilumina e aperfeiçoa. Logo não há
distinção de ordens, nos anjos.
Mas, em contrário, diz o Apóstolo (Ef 1, 21), que Deus constituiu Cristo homem acima de todo o prin-
cipado, e potestade, e virtude, e dominação, que são as diversas ordens dos anjos; e certos, dentre eles,
pertencem a uma mesma hierarquia, como a seguir se dirá (a. 6).

SOLUÇÃO. — Como já se disse (a. 1), uma hierarquia é uma chefia, i.é., uma multidão ordenada, do
mesmo modo, sob o governo de um chefe. Ora, não seria a multidão ordenada, mas confusa, se nela
não houvesse diversas ordens. Logo, a noção mesma de hierarquia requer a diversidade das ordens, e
esta é considerada relativamente aos diversos ofícios e atos. E isso bem se vê na cidade, em que são
diversas as ordens, segundo os diversos atos; assim, uma é a ordem dos que julgam, outra, a dos que
pugnam, outra, a dos que trabalham nos campos, e assim por diante. Mas, embora sejam muitas as
ordens de uma mesma cidade, todas, contudo, podem reduzir-se a três, por ter qualquer multidão
perfeita princípio, meio e fim. Por onde, há tríplice ordem de homens na cidade: uns são os supremos,
como os nobres; outros, ínfimos, como o baixo povo; outros, médios, como o povo honrado. Assim,
pois, em qualquer hierarquia angélica, as ordens se distinguem segundo os diversos atos e ofícios; e
toda essa diversidade se reduz a três ordens: a suma, a média e a ínfima. E por isso, em cada hierarquia,
Dionísio coloca três ordens.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ordem se toma em dupla acepção. Numa, a ordenação,
em si, compreendendo graus diversos; e, deste modo, diz-se que a hierarquia é uma ordem. De outro
modo, chama-se ordem a um mesmo grau; e assim, diz-se que há várias ordens numa mesma
hierarquia.

RESPOSTA À SEGUNDA. — Na sociedade dos anjos, tudo é possuído em comum; contudo, uns possuem
certas coisas de modo mais excelente que outros. Ora, o que pode comunicar o que possui tem posse
mais perfeita que o que não o pode; assim é mais perfeitamente cálido o que pode aquecer, do que o
que não pode; e sabe mais perfeitamente quem pode ensinar, do que quem não o pode. E quanto mais
perfeito for o dom comunicado, tanto mais perfeito será o grau de quem o comunica; assim, no grau
mais perfeito do magistério está quem pode ensinar a ciência mais elevada. E, de acordo com esta
semelhança deve-se distinguir a diversidade dos graus ou das ordens dos anjos, segundo os diversos
ofícios e atos.

RESPOSTA À TERCEIRA. — O anjo inferior é superior ao homem mais elevado, em a nossa hierarquia,
conforme aquilo da Escritura (Mt 11, 2): O que é menor no reino dos céus, é maior do que ele, i. é, do
que João Baptista, do qual entre os nascidos de mulher não se levantou outro maior. Por onde, o anjo
menor da celeste hierarquia pode não só purificar, mas iluminar e aperfeiçoar, e de modo mais alto do
que as ordens da nossa hierarquia. E assim pela distinção destes atos não se distinguem as ordens
celestes, mas por outras diferenças deles.

## Art. 3 — Se há vários anjos numa mesma ordem.
(II. Sent., dist. IX a. 3., 5).
O terceiro discute-se assim. — Parece que não há vários anjos numa mesma ordem.

1. — Pois, como já se disse antes (q. 50, a. 4), todos os anjos são desiguais entre si. Ora, consideram-se
da mesma ordem seres iguais. Logo, muitos anjos não são da mesma ordem.

2. Demais. — O que pode suficientemente ser feito por um, é supérfluo que se faça por muitos. Ora, o
pertencente a uma função angélica pode suficientemente ser feito por um anjo; assim como o atinente
à função do sol é realizado por um sol apenas; tanto mais quanto mais perfeito é o anjo do que os
corpos celestes. Se, portanto, as ordens se distinguem, pelas suas funções, como já se disse (a. 2), é
supérfluo haver vários anjos da mesma ordem.

3. Demais. — Como ficou dito (q. 50, a. 4), todos os anjos são desiguais. Se, pois, vários anjos, p. ex., três
ou quatro, são da mesma ordem, o ínfimo da ordem superior mais comunidade tem com o supremo da
ordem inferior, do que com o supremo da sua ordem; e assim, não se vê que pertença antes à mesma
ordem daquele do que deste. Logo, não há vários anjos numa mesma ordem.
Mas, em contrário, diz Isaias (Is 6, 3): Os serafins clamavam um para o outro. Logo há vários anjos na
mesma ordem dos Serafins.

SOLUÇÃO. — No que conhecemos perfeitamente podemos distinguir até as mínimas particularidades —
os atos; as virtudes e as naturezas. No que, porém, conhecemos imperfeitamente só podemos distingui-
las universalmente, distinção que pouco abrange. Assim, quem conhece imperfeitamente as coisas
naturais distingue-lhes as ordens, em geral, colocando, numa ordem, os corpos celestes; noutra, os
corpos inferiores inanimados; noutra, as plantas; noutra, os animais. Quem porém conhecer tais causas
mais perfeitamente, poderá distinguir, entre os corpos celestes, e em cada um deles, várias ordens. Ora,
nós, como diz Dionísio, conhecemos imperfeitamente os anjos e as suas funções. Por onde só em
comum é que podemos distinguir as funções e as ordens deles; e desse modo muitos anjos estão
contidos numa mesma ordem. Se, porém, lhes conhecêssemos perfeitamente as funções e as distinções,
perfeitamente saberíamos que cada anjo tem a sua função própria e a sua ordem própria, entre os
seres; e muito mais do que qualquer estrela, ainda que nos esteja oculta.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todos os anjos de uma mesma ordem são, de certo
modo, iguais, quanto à semelhança comum, que os constitui nessa ordem. Mas; em si mesmos, não são
iguais. E por isso, Dionísio diz, que é preciso admitir, numa mesma ordem de anjos, os primeiros, os
médios e os últimos.

RESPOSTA À SEGUNDA. — É-nos desconhecida a distinção especial de ordens e de funções, pela qual
cada anjo tem uma função e uma ordem própria.

RESPOSTA À TERCEIRA. — Numa superfície semi-branca e semi-negra, duas partes confinantes, dessas
cores, têm, pela situação, mais pontos comuns, que duas partes brancas; mas, menos, pela qualidade.
Assim também dois anjos, que estão nos limites de duas ordens, mais convêm, pela proximidade da
natureza, do que qualquer outro, com os demais da sua ordem; menos, porém, pela idoneidade para
funções semelhantes, porque essa idoneidade chega até certo termo.

## Art. 4 — Se a distinção de hierarquia e de ordens procede da natureza dos anjos.
(II Sent., dist. IX, a. 7; IV, dist. XXIV, q. 1, a. 1, qª 1, ad 3).
O quarto discute-se assim. — Parece que a distinção das hierarquias e das ordens não procede da
natureza dos anjos.

1. — Pois, chama-se hierarquia a chefia sagrada em cuja definição Dionísio compreende a semelhança
com a deiformidade, tanto quanto possível. Ora, a santidade e a deiformidade os anjos as têm por graça
e não por natureza. Logo, a distinção de hierarquias e ordens, nos anjos, procede da graça e não da
natureza.

2. Demais. — Serafins chamam-se os ardentes ou que incendeiam, como diz Dionísio. Ora, isto respeita
à caridade, procedente da graça e não da natureza, e que se difunde como diz a Escritura (Rm 5, 5), em
nossos corações pelo Espírito Santo, que nos foi dado. E isto pertence não só às pessoas santas, mas
também pode-se atribuir aos santos anjos, como diz Agostinho. Logo, as ordens dos anjos não
procedem da natureza, mas da graça.

3. Demais. — A hierarquia eclesiástica modela-se pela celeste. Ora, as ordens dos homens não
procedem da natureza, mas são dons da graça; pois, não é por natureza que um é bispo, outro
sacerdote, outro, diácono. Logo, também as ordens dos anjos não procedem da natureza, mas, da graça
somente.
Mas, em contrário, diz o Mestre das Sentenças: chama-se ordem dos anjos à multidão dos espíritos
celestes, semelhantes, entre si, por algum dom da graça, do mesmo modo que têm de comum, entre si,
a participação dos dons naturais. Logo, a distinção das ordens dos anjos procede, não somente dos dons
gratuitos, mas também, dos naturais.

SOLUÇÃO. — A ordem do governo, que é a ordem da multidão, regida por um chefe, supõe a relação
com um fim. Ora, duplamente se pode entender o fim dos anjos. — De um modo quanto à faculdade da
natureza, feita para conhecer e amar a Deus por conhecimento e amor naturais. E em relação a este fim,
as ordens dos anjos se distinguem pelos dons naturais deles. — De outro modo, pode-se compreender o
fim da multidão angélica como superior à faculdade natural deles, e consistente na visão da divina
essência e no gozo imutável da bondade da mesma; e tal fim os anjos não no podem alcançar senão
pela graça. Por onde, em relação a este fim, as ordens dos anjos se distinguem, completivamente,
quanto aos dons gratuitos; dispositivamente, quanto aos naturais. Pois, os anjos recebem os dons
gratuitos conforme a capacidade para os naturais, o que não se dá com os homens, segundo ficou dito
(q. 62, a. 6). E, portanto, as ordens dos homens se distinguem somente pelos dons gratuitos e não
segundo a natureza.
Donde se deduzem claras as RESPOSTAS ÀS OBJEÇÕES.

## Art. 5 — Se as ordens dos anjos são convenientemente denominadas.
(II Sent., dist. IX, a. 3, 4; III, Cont.Gent., cap. LXXX; Compend. Theol., cap. CXXVI; Coloss., cap. I, lect. IV).
O quinto discute-se assim. — Parece que as ordens dos anjos não são convenientemente
denominadas.

1. — Pois, todos os espíritos celestes chamam-se anjos e virtudes celestes. Ora, é inconveniente
apropriar só a certos os nomes comuns. Logo, é inconvenientemente denominada uma ordem a dos
Anjos e outra, a das Virtudes.

2. Demais. — Ser Senhor é próprio de Deus, conforme a Escritura (Sl 99, 3): Sabei que o Senhor é Deus.
Logo, inconvenientemente uma das ordens dos espíritos celestes é chamada das Dominações.

3. Demais. — O nome de Dominação diz respeito a governo; e semelhantemente, os dos Principados e
das Potestades. É pois, inconveniente atribuírem-se a três ordens esses três nomes.

4. Demais. — Denominam-se Arcanjos os que são como príncipes dos anjos. Logo, este nome só deve
ser aplicado à ordem dos Principados.

5. Demais. — O nome de Serafim é imposto por causa do ardor, que diz respeito à caridade; enquanto
que o de Querubim é imposto por causa da ciência. Ora, a caridade e a ciência são dons comuns a todos
os anjos. Logo, não devem ser nomes de ordens especiais.

6. Demais. — Os Tronos chamam-se sedes. Ora, diz-se que Deus tem sede na criatura racional quando
esta o conhece e ama Logo, não deve a ordem dos Tronos distinguir-se da dos Querubins e dos Serafins.
Assim, pois, conclui-se que as ordens dos anjos são inconvenientemente denominadas.
Mas, em contrário, é a autoridade da Sagrada Escritura que assim os denomina. Pois, nela se encontram
as denominações de Serafins (Is 6), Querubins (Ez 1), Tronos (Cl 1), Dominações, Virtudes, Potesta-
des,Principados (Ef 1), Arcanjos e Anjos (em várias passagens das Escrituras).

SOLUÇÃO. — Na denominação das ordens angélicas necessário é considerar-se que os nomes próprios a
cada ordem designam as propriedades delas, como diz Dionísio. Para se compreender porém, a
propriedade de cada ordem, é preciso considerar, que de três modos podemos fazer uma atribuição,
nos seres ordenados: por propriedade, excesso e participação. Assim, diz-se que uma coisa está em
outra, por propriedade, quando é adequada e proporcionada à natureza desta. Por excesso, quando a
coisa atribuída a outra é menos que esta, contudo lhe convém, por um certo excesso, como já se disse a
respeito de todos os nomes atribuídos a Deus. Por participação, enfim, quando a atribuição não está no
atribuído plenária, mas deficientemente; assim, os homens santos chamam-se deuses, parti-
cipativamente. Se, pois, um ser deve receber a denominação que lhe designe a propriedade,
taldenominação não deve provir daquilo que esse ser participa imperfeitamente, nem do que tem, em
excesso, mas do que lhe é como coigual. Assim, quem quiser denominar propriamente o homem dirá
que é uma substância racional; não, substância intelectual, denominação própria ao anjo, porque a
simples inteligência convém ao anjo, por propriedade, e ao homem, por participação; nem substância
sensível, denominação própria ao bruto, porque o sentido é menos do que o que é próprio ao homem, e
a este lhe convém excelentemente, mais que aos brutos. E, portanto, devemos considerar que, nas
ordens dos anjos, todas as perfeições espirituais são comuns a todos os anjos e todas existem mais
abundantemente nos superiores, que nos inferiores.
Mas, como há graus nas próprias perfeições, a perfeição superior é atribuída à ordem superior, por
propriedade, à inferior, porém, como participação; e, inversamente, a perfeição inferior é atribuída à
ordem inferior, por propriedade, e à superior, por excesso. Donde resulta que a ordem superior é
denominada pela perfeição superior. — E é assim que Dionísio expõe os nomes das ordens, conforme a
conveniência para as perfeições espirituais delas. Ao passo que Gregório, na exposição desses nomes,
parece atender mais aos ministérios exteriores. Assim, explica, chamam-se anjos os que, anunciam as
coisas mínimas; Arcanjos, as sumas; pelas Virtudes fazem-se os milagres; pelas Potestades são
debeladas as potestades adversas; os Principados são os que presidem aos bons espíritos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Anjo significa núncio. Logo, todos os espíritos celestes,
como manifestadores das ordens divinas, chamam-se anjos. Mas os anjos superiores têm, nessa
manifestação, certa excelência, pela qual as ordens superiores são denominadas. Enquanto que a ordem
ínfima dos anjos não acrescenta nenhuma excelência à manifestação comum; e por isso é denominada
pela simples manifestação. E assim, o nome comum aplica-se, como próprio, à ínfima ordem, como diz
Dionísio. Ou se pode dizer que a ordem ínfima pode ser chamada especialmente ordem dos anjos, por-
que nos anunciam imediatamente. — A virtude, porém, pode ser tomada em dupla acepção. Em
acepção comum, a virtude é média entre a essência e a operação; e então, todos os espíritos celestes
chamam-se virtudes celestes, bem como celestes essências. Noutra acepção, virtude importa excesso de
força e então é nome próprio de ordem. Por onde, diz Dionísio, que o nome de Virtudes significa uma
força viril e inconcussa; primeiro, em relação a todas as operações divinas que lhes são convenientes; e
segundo, para receber os dons divinos. E assim, significa que, sem nenhum temor, acercam-se das
coisas divinas que lhes dizem respeito; o que concerne à força do ânimo.

RESPOSTA À SEGUNDA. — Como diz Dionísio, a Dominação é louvada, em Deus singularmente, por
excesso; mas, por participação, as Divinas Letras chamam Dominações aos principais ornatos, pelos
quais os inferiores recebem os dons de Deus. E por isso, Dionísio diz que o nome de
Dominações significa primeiro, a liberdade, que isenta da condição servil e da sujeição plebéia, a que a
plebe está submetida; e da opressão tirânica a que, às vezes, até mesmo os maiores estão sujeitos. Em
segundo lugar, significa um governo rígido e inflexível, que não se inclina a nenhum ato servil, nem a
nenhum ato próprio aos que são sujeitos e oprimidos pelos tiranos. Em terceiro lugar, significa o desejo
e a participação do verdadeiro domínio, que está em Deus. E semelhantemente, o nome de qualquer
ordem significa a participação do que exorta em Deus; p. ex., o nome de virtudes significa participação
da divina virtude, e assim por diante.

RESPOSTA À TERCEIRA. — Os nomes de Dominação, de Potestade e de Principado dizem respeito ao
governo, diversamente. — Pois, ao senhor pertence apenas preceituar sobre o que se deve fazer, e por
isso, Gregório diz: certas ordens de anjos, a que outras, que lhes estão sujeitas, devem obedecer,
chamam-se Dominações. — Ao passo que o nome de potestade designa certa ordenação, conforme a
Escritura (Rm 13, 2): Aquele que resiste à potestade, resiste à ordenação de Deus. E, por isso, Dionísio
diz, que o nome de Potestade significa uma ordenação, relativa, tanto ao recebimento das ordens
divinas, como às ações divinas, que os superiores comunicam aos inferiores, conduzindo-os para o alto.
À ordem das Potestades, pertence, pois, ordenar o que deve ser feito pelos súbditos. — Ser principal,
por outro lado, como diz Gregório, é ser primeiro entre os demais; assim, são como que os primeiros, na
execução do que é mandado. E por isso, Dionísio diz, que o nome de Principados significa condutor,
com ordem sagrada. Pois, os que conduzem os outros, sendo os primeiros entre eles, chamam-se
propriamente príncipes, conforme a Escritura (Sl 67, 26): Foram adiante os príncipes; juntamente com
os que cantavam salmos.

RESPOSTA À QUARTA. — Os Arcanjos, segundo Dionísio, são médios entre os Principados e os Anjos.
Ora, o meio, comparado com o extremo, é equiparado ao outro extremo, como participante da natureza
de ambos; assim, o tépido, em comparação com o cálido, é frio, e em comparação com este é cálido.
Assim, pois, os Arcanjos são chamados como que Príncipes dos Anjos, porque, em relação a estes, são
príncipes, porém, em relação aos Principados são Anjos. — Segundo Gregório contudo, chamam-se
Arcanjos porque presidem só a ordem dos Anjos, sendo como núncios das grandes coisas. E chamam-se
Principados porque presidem a todas as virtudes celestes, cumpridoras das ordens divinas.

RESPOSTA À QUINTA. — O nome de Serafim não é imposto tanto pela caridade, como pelo excesso
desta, excesso em que importa o nome de ardor ou de incêndio. Por onde, Dionísio interpreta o nome
de Serafim pelas propriedades do fogo, no qual há excesso de calor. Pois, três coisas se podem
considerar, no fogo. Primeira, o movimento contínuo para cima. Pelo que se significa que são movidos
para Deus, indeclinavelmente. — Segunda, a virtude ativa, que é a calidez. E esta não existe de modo
absoluto no fogo,mas com certa acuidade; porque ele tem ação penetrativa em máximo grau, e atinge
até às mínimas intimidades; e demais com fervor super-excedente. E por aí se significa a poderosa ação
que os referidos anjos exercem sobre os que lhes estão sujeitos, excitando-os a fervor semelhante e
purificando-os totalmente pelo incêndio. — A terceira é a claridade. E isto significa que os ditos anjos
trazem, em si mesmos, luz inextinguível e iluminam perfeitamente os outros. — Semelhantemente, o
nome de Querubins é imposto, pelo excesso de ciência e é interpretado como Plenitude da ciência. O
que Dionísio explica relativamente a quatro pontos: primeiro, quanto à visão perfeita de Deus; segundo,
quanto ao pleno recebimento da divina luz; terceiro, quanto ao contemplarem, em Deus mesmo, a
beleza da ordem das coisas deles derivada; quarto, quanto a difundirem copiosamente, nos outros, esse
conhecimento, em que superabundam.

RESPOSTA À SEXTA. — A ordem dos Tronos têm excelência sobre as ordens inferiores por poderem
conhecer imediatamente, em Deus, as razões das obras divinas. Ao passo que os Querubins têm a
excelência da ciência; e os Serafins a do ardor. E embora nestas duas excelências esteja incluída a
terceira, contudo, na dos Tronos não se incluem as duas outras. Por onde, a ordem dos Tronos se
distingue das dos Querubins e Serafins. Pois, é comum para todos, que a excelência do inferior esteja
contida na do superior, e não vice-versa. — Dionísio porém, explica o nome de Tronos, por conveniência
com os sólios, na ordem material. Nos quais, há quatro causas a considerar. — Primeiro, o lugar, pois os
sólios se elevam na terra. E assim os anjos chamados Tronos elevam-se até o conhecimento imediato
em Deus, das razões das coisas. — Segundo, nos sólios materiais se considera a firmeza, porque neles
firmemente nos assentamos. No caso vertente porém, dá-se o inverso, pois os anjos é que estão
firmados por Deus. — Terceiro, porque o sólio recebe quem se assenta e este pode ser transportado
nele. Assim também os anjos, de que tratamos, recebem Deus em si mesmos e o levam, de certo modo,
aos inferiores. — Quarto, figuradamente, pois, o sólio é aberto de um lado para receber quem se
assenta. Assim também os referidos anjos estão, pela sua presteza, abertos para receber a Deus e lhe
servir.

## Art. 6 — Se os graus das ordens estão convenientemente distribuídos.
(II Sent., dist. IX, a. 3; III Cont. Gent., cap. LXXX; Compend.)
O sexto discute-se assim. — Parece que os graus das ordens estão inconvenientemente distribuídos.

1. — Pois, a ordem dos superiores é a suprema. Ora, as Dominações, os Principados e as Potestades
têm, pelos seus próprios nomes, certa superioridade. Logo, estas ordens devem ser, entre todas, as
supremas.

2. Demais. — Quanto mais próximo de Deus for uma ordem, tanto mais superior será. Ora, a ordem dos
Tronos é a mais próxima de Deus, pois, nada se une mais proximamente com quem está sentado do que
o seu assento. Logo, a ordem dos Tronos é a mais elevada.

3. — A ciência tem prioridade sobre o amor e o intelecto é mais elevado que a vontade. Logo também a
ordem dos Querubins é mais elevada que a dos Serafins.

4. Demais. — Gregório coloca os Principados acima das Potestades. Logo, eles não estão colocados
imediatamente acima dos Arcanjos, como diz Dionísio.
Mas, em contrário, Dionísio coloca na primeira hierarquia, como mais elevados, os Serafins; como
médios, os Querubins, e os Tronos, como últimos. Na hierarquia média, as Dominações, como primeiros;
as Virtudes, como médios; e as Potestades, como últimos. Na última, por fim, os Principados, como
primeiros; os Arcanjos, como médios; e os Anjos, como últimos.

SOLUÇÃO. — Gregório e Dionísio distribuem os graus das ordens angélicas diferentemente, quanto aos
Principados e às Virtudes, e, no mais, do mesmo modo. Pois, Dionísio coloca as Virtudes inferiores às
Dominações e superiores às Potestades; os Principados, porém, inferiores às Potestades e superiores
aos Arcanjos. Ao passo que Gregório coloca os Principados no meio, entre as Dominações e as
Potestades; e as Virtudes, no meio, entre as Potestades e os Arcanjos. E ambas essas disposições podem
se apoiar na autoridade do Apóstolo (Ef 1, 20) que, enumerando as ordens médias de
maneiraascendente, diz, que Deus o constituiu, i. é, Cristo, à sua mão direita no céu, acima de todo o
Principado, e Potestade, e Virtude, e Dominação; onde põe a Virtude entre a Potestade e a Dominação,
conforme a distribuição de Dionísio. Mas, noutro passo, enumerando as mesmas ordens, de maneira
descendente, diz (Cl 1, 16): quer sejam os Tronos, quer as Dominações, quer os Principados, quer as
Potestades, tudo foi criado por ele e para ele; onde coloca os Principados como médios entre as
Dominações e as Potestades, conforme a distribuição de Gregório.
Primeiro, pois, vejamos a razão da distribuição de Dionísio. Nela se deve considerar que, como já foi dito
(a. 1), a primeira hierarquia vê as razões das coisas, no próprio Deus; a segunda, nas causas universais; a
terceira, porém, quanto à determinação para efeitos especiais. E como Deus é o fim, não só dos
ministérios angélicos, mas também de todas as criaturas, à primeira hierarquia pertence à consideração
do fim; à média, a disposição universal do que se deve fazer; à última, a aplicação da disposição ao
efeito, que é a execução da obra. Ora, estas três coisas encontram-se, manifestamente, em qualquer
operação. E por isso, Dionísio, deduzindo dos nomes das ordens as propriedades delas, colocou, na
primeira hierarquia, as ordens, cujos nomes são impostos, relativos a Deus, e são os Serafins, os
Querubins e os Tronos. Colocou na hierarquia média as ordens, cujos nomes designam um governo ou
disposição comuns, e que são as Dominações, as Virtudes e as Potestades. Colocou, por fim, na terceira
hierarquia, as ordens cujos nomes designam a execução da obra e que são os Principados, os Anjos e os
Arcanjos.
Em relação ao fim, porém, três coisas se podem considerar. Pois, primeiro, considera-se o fim; depois,
adquire-se o conhecimento perfeito dele; terceiro, fixa-se nele a intenção. Ora, destas três coisas, a
segunda se adiciona a primeira e a terceira, a ambas as outras. E como Deus é o fim das criaturas, assim
como o chefe é o fim do exército, conforme diz Aristóteles, pode-se descobrir, nas coisas humanas, um
símile das ordens em questão. Assim, há certos que têm tal dignidade, que podem por si mesmos
achegar-se familiarmente ao rei ou ao chefe; outros, além disso, podem ainda conhecer-lhe os segredos;
outros por fim e ainda mais, sempre o acompanham, estando-lhe como conjuntos. E de acordo com esta
semelhança, podemos compreender a disposição das ordens da primeira hierarquia. Pois, os Tronos
estão elevados de modo que recebem a Deus, familiarmente, em si mesmos, porque podem conhecer
nele imediatamente as razões das coisas; e isso é próprio de toda a primeira hierarquia. Ao passo que os
Querubins conhecem supereminentemente os segredos divinos. E os Serafins, enfim, são excelentes
pelo que é mais elevado que tudo, a saber, estar unido ao próprio Deus. De modo que a ordem dos
Tronos é denominada pelo que é comum a toda a hierarquia; assim como, pelo que é comum a todos os
espíritos celestes, é denominada a ordem dos Anjos.
Por outro lado, em a noção de governo três coisas se incluem. A primeira é a definição daquilo que se
deve fazer, e isso é próprio às Dominações. A segunda é dar a faculdade de cumprir, e isso pertence às
Virtudes. A terceira é ordenar de que modo o preceituado ou definido pode ser cumprido, para que se
executem, e isso pertence às Potestades.
Ora, a execução dos ministérios angélicos consiste em anunciar as coisas divinas. Mas, na execução de
qualquer ato, uns começam a ação e outros a dirigem; assim, no canto, os que entoam e, na guerra, os
que comandam e dirigem os outros. E isto pertence aos Principados. Outros há porém que
simplesmente executam, e isso pertence aos Anjos. Outros, por fim, têm uma situação média, e é o que
se dá com os Arcanjos, como já se disse.
Ora, esta distribuição das ordens é congruente, porque sempre o mais elevado da ordem inferior tem
afinidade com o último da superior; assim os ínfimos animais distam pouco das plantas. A primeira
ordem, pois, é a das divinas Pessoas e tem o seu termo no Espírito Santo, que é o amor procedente; com
esta tem afinidade a ordem suprema da primeira hierarquia, que tira a denominação do incêndio do
amor. Depois, a ínfima ordem da primeira hierarquia é a dos Tronos que, em virtude do próprio nome,
têm certa afinidade com as Dominações. Pois os Tronos, como diz Gregório, são aqueles pelos quais
Deus decreta os seus juízos; e recebem as iluminações divinas para o fim de iluminarem imediatamente
a segunda hierarquia, à qual pertence à disposição dos divinos ministérios. Em seguida, a ordem das
Potestades tem afinidade com a dos Principados; pois, devendo as Potestades impor a ordem aos que
lhes estão sujeitos, essa ordenação está imediatamente designada em o nome dos Principados, que são
os primeiros na execução dos ministérios divinos, por presidirem ao governo dos povos e dos reinos,
que é o primeiro e o principal dos ministérios divinos, porque o bem do povo é mais divino que o de um
só homem. E por isso, diz a Escritura: O príncipe do reino dos Persas resistiu-me.
Mas, também a distribuição que Gregório faz das ordens é congruente. Pois, como as Dominações
definem e preceituam o que entende com os ministérios divinos, pelas disposições deles, em que se
exercem os ministérios divinos, dispõem-se às ordens que lhe estão sujeitas. Porque, como diz
Agostinho, os corpos são regidos numa certa ordem: os inferiores, pelos superiores, e todos, pela
criatura espiritual; e o espírito mau, pelo bom. E a primeira ordem, depois das Dominações, é a dos
Principados que governam também aos bons espíritos. Depois, as Potestades, pelas quais são afastados
os maus espíritos, assim como pelas potestades terrenas são afastados os malfeitores, segundo a Escri-
tura. Depois delas, as Virtudes, que têm poder sobre a natureza corpórea, na operação dos milagres. Em
seguida, os Arcanjos e os Anjos, que anunciam aos homens grandes acontecimentos superiores à razão,
ou pequenos, que a razão pode alcançar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É mais importante para os anjos estarem sujeitos a
Deus, do que presidirem aos inferiores; e isto deriva daquilo. Por onde, as ordens que recebem
denominação da superioridade não são as supremas, mas antes, as que recebem a denominação do se
voltarem para Deus.

RESPOSTA À SEGUNDA. — A proximidade de Deus designada pelo nome dos Tronos, convém também
aos Querubins e aos Serafins, e de modo mais excelente, como já se disse.

RESPOSTA À TERCEIRA. — Como já se disse, o conhecimento. supõe o objeto conhecido em quem
conhece; enquanto que o amor supõe. o amante unido à causa amada. Ora, o superior está, em si
mesmo, de modo mais nobre que no inferior; ao passo que o inferior está de modo mais nobre no
superior, que em si mesmo. Por onde, o conhecimento do que é inferior tem, preeminência sobre o
amor; ao passo que o amor do que é superior, e sobretudo de Deus, tem preeminência sobre o
conhecimento.

RESPOSTA À QUARTA. — Se considerarmos atentamente as distribuições das ordens, segundo Dionísio
e segundo Gregório, veremos que em pouco, ou nada diferem, referidas à realidade. Assim, Gregório,
deduz o nome dos Principados do presidirem aos bons espíritos; o que também convém às Virtudes, em
cujo nome se compreende a fortaleza, que dá eficácia aos espíritos inferiores para executarem os
divinos ministérios. — Ainda. As Virtudes de Gregório identificam-se com os Principados, de Dionísio.
Pois, o primeiro dos ministérios divinos é fazer milagres, preparando-se, por aí, a via para a anunciação
dos Arcanjos e dos Anjos.

## Art. 7 — Se as ordens permanecerão depois do dia do juízo.
(II Sent., dist. XI, part. II, a. 6; IV, dist. XLVII, q. 1, a. 2)
O sétimo discute-se assim. — Parece que as ordens não permanecerão depois do dia do juízo.

1. — Pois, diz o Apóstolo, que Cristo destruirá todo o Principado, e Potestade, quando tiver entregado o
reino a Deus e ao Padre, e isso há de ser na consumação última. Logo, por igual razão, nesse estado,
todas as outras ordens serão suprimidas.

2. Demais. — É função das ordens angélicas purificar, iluminar e aperfeiçoar. Ora, depois do dia do juízo,
nenhum anjo purificará, iluminará ou aperfeiçoará outro, porque não mais têm que progredir na ciência.
Logo, será inútil permanecerem as ordens angélicas.

3. Demais. — O Apóstolo diz, dos anjos, que todos esses espíritos são uns ministros, enviados para
exercer o seu ministério a favor daqueles que hão de receber a herança de salvação; por onde é patente
que as funções dos anjos se ordenam a conduzir os homens à salvação. Ora, todos os eleitos, até o dia
do juízo, hão de conseguir a salvação. Logo, depois do dia do juízo, não permanecerão as funções e as
ordens dos anjos.
Mas, em contrário, diz a Escritura: as estrelas, permanecendo na sua ordem e no seu curso o que é
explicado como referente aos anjos. Logo, estes sempre permanecerão nas suas funções.

SOLUÇÃO. — Nas ordens angélicas, duas causas se podem considerar: a distinção dos graus e o exercício
das funções. — A distinção dos graus nos anjos, se funda na diferença da natureza e da graça, como já
se disse; e ambas essas diferenças permanecerão sempre neles. Pois, não podem ser privados das
diferenças das naturezas, a não ser desaparecendo eles. E a diferença da glória sempre neles existirá,
fundada na diferença do mérito precedente. — Quanto ao exercício das funções angélicas, esse, depois
do dia do juízo, permanecerá de certo modo e, de outro, cessará. Cessará, quanto à condução de certos
homens ao fim; permanecerá, porém, no que diz respeito à consecução última do fim. Assim, umas são
as funções das ordens militares, na luta, e, outras, no triunfo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os Principados e as Potestades deixarão de existir, na
referida consumação final, no atinente à condução dos fiéis ao fim; pois, conseguido este, já não é
necessário tender para ele. E esta razão se deduz das palavras do Apóstolo: Quando tiver entregado o
reino a Deus e ao Padre, i. é, quando levar os fiéis à fruição mesma de Deus.

RESPOSTA À SEGUNDA. — As ações de uns anjos sobre outros devem-se considerar relativamente à
semelhança dos nossos atos inteligíveis. Ora, há em nós muitos atos inteligíveis ordenados pela ordem
da causa em relação ao causado; assim, quando por muitos meios chegamos gradualmente a uma
conclusão. Ora, é manifesto que o conhecimento da conclusão depende de todos os meios precedentes,
não só quanto à aquisição de nova ciência, mas também quanto à conservação desta. E a prova é que,
se a alguém esquecer algum dos meios precedentes, poderá ter opinião ou fé, quanto à conclusão, mas
não ciência, desde que é ignorada a ordem das causas. E portanto, como os anjos inferiores conhecem
as razões das obras divinas pela luz dos superiores, desta luz depende o conhecimento deles, não só
quanto à aquisição da nova ciência, mas também quanto à conservação desta. Por onde, embora depois
do juízo, os anjos inferiores não mais progridam em nenhum conhecimento, contudo nem por isso deles
se exclui a iluminação dos superiores.

RESPOSTA À TERCEIRA. — Embora depois do dia do juízo, os homens não precisem mais ser levados à
salvação pelo ministério dos anjos, contudo, aqueles que já o conseguiram terão alguma iluminação por
ofício deles.

## Art. 8 — Se os homens serão transferidos às ordens dos anjos.
(II Sent., dist. IX, a. 8)
O oitavo discute-se assim. — Parece que os homens não serão transferidos às ordens dos anjos.

1. — Pois, a hierarquia humana está compreendida na ínfima hierarquia celeste, como esta, na média, e
a média, na primeira. Ora, os anjos da ínfima hierarquia nunca serão transferidos para a média ou para a
primeira. Logo, nem os homens serão transferidos para as ordens dos anjos.

2. Demais. — Certas funções cabem às ordens dos anjos, como guardar, fazer milagres, afastar os
demônios e outras, que não se consideram cabíveis às almas dos santos. Logo, não, serão estes
transferidos às ordens dos anjos.

3. Demais. — Assim como os bons anjos levam ao bem, assim, os demônios, ao mal. Ora, como o
reprova Crisóstomo, é errôneo dizer que as almas dos homens maus convertem-se em demônios. Logo,
não se deve concluir que as almas dos santos se transfiram para as ordens dos anjos.
Mas, em contrário, diz o Senhor, falando dos santos: serão tomo os anjos de Deus no céu.

SOLUÇÃO. — Como já se disse, as ordens dos anjos distinguem-se pela condição da natureza e pelos
dons da graça. Se, pois, forem elas consideradas só quanto ao grau da natureza então de nenhum modo
os homens poderão ser transferidos para elas porque permanecerá sempre a distinção das naturezas.
Donde, certos, considerando isso, afirmaram que de nenhum modo os homens podem ser transferidos à
igualdade angélica; o que é errôneo e repugna à promessa de Cristo: são iguais aos anjos por serem
filhos da Ressurreição. Pois, o que procede da natureza é material, em relação à ordem; ao passo que o
que é completivo é dom da graça, dependente da liberalidade de Deus e não, da ordem da natureza. Por
onde, por dom da graça, os homens podem merecer glória tão grande, que se igualem aos anjos,
conforme os graus de cada ordem; e isso é serem os homens transferidos para as ordens dos anjos.
Outros, porém, dizem que, para as ordens dos anjos serão transferidos, não todos os que se salvam,
mas só os virgens ou perfeitos; enquanto que os demais constituirão uma ordem própria, como que
conjunta a toda a sociedade dos anjos. — Mas, esta opinião vai contra Agostinho, que diz não haverá
duas sociedades, de homens e de anjos, mas uma só; pois, a beatitude de todos consiste em aderir a
Deus uno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A graça é dada aos anjos em proporção dos dons
naturais; o que não se dá com os homens, como já se disse. Onde, assim como os anjos inferiores não
podem ser transferidos ao grau natural dos superiores, assim nem ao grau gratuito. Os homens, porém,
podem subir ao grau gratuito, mas não, ao natural.

RESPOSTA À SEGUNDA. — Os anjos, pela ordem da natureza, são médios entre nós e Deus. Por onde,
pela lei comum, por eles são administrados, não só as coisas humanas, mas também todos os seres
corpóreos. Porém, os homens santos, mesmo depois desta vida, conservam a mesma natureza nossa.
Por onde, pela lei comum, não administram as coisas humanas, nem intervêm nos negócios dos vivos,
como diz Agostinho. Às vezes porém, por dispensa especial, a certos santos é concedido, vivos ou
mortos, desempenhar esse ofício, quer fazendo milagres, quer afastando os demônios, ou fazendo
coisas semelhantes, como diz Agostinho, no mesmo livro.

RESPOSTA À TERCEIRA. — Não é errôneo dizer que os homens são transferidos às penas dos demônios;
mas, alguns ensinaram erradamente, que os demônios não são mais do que as almas dos defuntos, e
isso é o que Crisóstomo reprova.