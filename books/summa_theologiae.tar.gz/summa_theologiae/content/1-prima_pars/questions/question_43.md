# Questão 43: Da missão das Pessoas divinas.
Em seguida, vamos tratar da missão das Pessoas divinas. E nesta questão discutem-se oito artigos:

## Art. 1 — Se a alguma das Pessoas divinas é próprio o ser enviada.
(I Sent., dist. XV, q. 1, a. 1; IV Cont. Gent., cap. XXIII; Contra errors Graec., cap. XIV).
O primeiro discute-se assim. – Parece que não é próprio a nenhuma das Pessoas divinas o ser enviada.

1. – Pois, o enviado é menor que quem envia. Ora, uma Pessoa divina não é menor que outra. Logo, uma
não é enviada por outra.

2. Demais. – Tudo o que é enviado é separado de quem o envia. Por isso diz Jerônimo: O que está preso
e unido a um corpo não pode ser enviado. Ora, das divinas Pessoas, nada é separável, como diz Hilário.
Logo, uma Pessoa não é enviada por outra.

3. Demais. –Quem é enviado parte de um lugar e vai de novo a outro, onde não estava. Ora, isto não é
possível a uma Pessoa divina, que está em toda parte. Logo, à Pessoa divina não convém o ser enviada.
Mas, em contrário, a Escritura (Jo 8, 16): Eu não sou só, mas eu e o Pai que me enviou.

SOLUÇÃO. –Duas relações implica o conceito de missão: a do enviado com quem o enviou e a do
enviado com o termo ao qual é enviado. Ora, o fato de alguém ser enviado supõe uma processão, do
enviado, daquele que envia; ou pelo império, como quando o senhor envia o servo; ou por conselho,
como se disséssemos que o conselheiro envia o rei a guerrear; ou pela origem, como se disséssemos
que a flor é emitida pela árvore. Mas também supõe a relação com o termo ao qual é enviado, de modo
a vir a estar de certa maneira onde antes não estava. Ou porque antes de nenhum modo ai estivesse; ou
porque de algum modo comece a estar onde antes não estava. Ora, a missão pode convir à Pessoa
divina enquanto implica, de um lado, processão original de quem envia; e de outro lado, um novo modo
de estar em algum lugar. Assim, dizemos que o Filho foi enviado pelo Pai ao mundo, por neste começar
a estar, visivelmente, pela carne assumida; e, contudo, já antes estava no mundo, como diz a Escritura
(Jo 1, 10).

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –A missão importa diminuição no enviado, por implicar a
processão do princípio que envia, pelo império ou pelo conselho; pois, quem ordena é maior e quem
aconselha é mais sábio. Mas em Deus não importa senão a processão de origem, que se funda na
igualdade, como dissemos.

RESPOSTA À SEGUNDA. –O enviado, que começa a estar onde antes de nenhum modo estava, move-se
localmente, pois que foi enviado; por onde e necessariamente, separa-se localmente de quem o envia.
Ora, tal não se dá com a missão da Pessoa divina; porque a Pessoa divina enviada, assim como não
começa a estar onde antes não estava, assim não deixa de estar onde estava. Por isso tal missão não
implica separação, tendo só a distinção de origem.

RESPOSTA À TERCEIRA. –A objeção colhe quanto à missão fundada no movimento local, o que não tem
lugar em Deus.

## Art. 2 — Se a missão pode ser eterna.
(I Sent., dist. XV, q. 4, a. 3).
O segundo discute-se assim. – Parece que a missão pode ser eterna.1. – Pois, diz Gregório: O Filho é
enviado do mesmo modo que é gerado. Ora, a geração do Filho é eterna. Logo, também é a missão.

2. Demais. – O ser ao qual convém uma coisa, temporalmente, é mutável. Ora, a Pessoa divina não o é.
Logo, a missão da Pessoa divina não é temporal, mas eterna.

3. Demais. – Missão importa processão. Ora, a processão das divinas Pessoas é eterna. Logo, também a
missão.
Mas, em contrário, a Escritura (Gl 4, 4): Quando veio o cumprimento do tempo, enviou Deus a seu Filho.

SOLUÇÃO. – No atinente à origem das Pessoas divinas, devemos atender a uma certa diferença. Pois
certas coisas, pela significação, importam somente relação com o princípio, como a processão e o
nascimento. Outras, porém, além da relação com o princípio, determinam o termo da processão.
Destas, umas determinam o termo eterno, como a geração e a espiração; pois, a geração é a processão
da Pessoa divina para a natureza divina; e a espiração, em sentido passivo, importa processão do Amor
subsistente. Mas outras, além da relação com o princípio, implicam um termo temporal, como missão e
dação; pois, o enviado o é para estar em outro lugar; e o doado o é para ser possuído. Ora, só
temporalmente é que a Pessoa divina pode ser possuída por uma criatura, ou nela estar de modo pelo
qual antes não estava.
Por isso, missão e dação a Deus se atribuem apenas temporalmente; mas a geração e a espiração, só
abeterno; ao passo que a processão e o nascimento, tanto eterna como temporalmente. Pois, o Filho
procede abeterno, para ser Deus; porém, temporalmente, para ser também homem pela missão visível;
e estar no homem, pela invisível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Gregório refere-se à geração temporal do Filho, como
gerado, não do Pai, mas, da mãe; ou porque o fato mesmo de o Filho poder ser enviado vem de ser
abeterno gerado.

RESPOSTA À SEGUNDA. – O estar a Pessoa divina em alguém, de novo modo; ou ser possuída por
alguém, temporalmente, não implica nenhuma mudança na Pessoa, mas sim na criatura. Assim como
também Deus é temporalmente chamado Senhor, por causa das mudanças da criatura.

RESPOSTA À TERCEIRA. – A missão não somente importa processão de um princípio, mas determina o
termo temporal dela; por isso ela só pode ser temporal. Ou a missão inclui a processão eterna e faz o
acréscimo do efeito temporal, pois a relação da Pessoa divina com o seu princípio não é senão abeterno.
Por onde, há dupla processão, a saber, a eterna e a temporal. Não que a relação com o princípio seja
dupla, mas por serem os dois os termos: o temporal e o eterno.

## Art. 3 — Se a missão invisível da Pessoa divina é somente quanto ao Dom da graça santificante.
(I Sent., dist. XIV, q. 2, a. 2).
O terceiro discute-se assim. – Parece que a missão invisível da Pessoa divina não é só quanto ao dom
da graça santificante.

1. – Pois, ser enviada a Pessoa divina é o mesmo que ser doada. Por onde, se a Pessoa divina é enviada
só quanto aos dons da graça santificante, não será doada a Pessoa divina, mas só os seus dons. Ora,
afirmá-lo é o erro dos que dizem não ser o Espírito Santo dado, mas apenas, os seus dons.

2. Demais. – A expressão – quanto – implica uma relação causal. Ora, a Pessoa divina é causa de
possuirmos o dom da graça santificante e não, inversamente, conforme a Escritura (Rm 5, 5): A caridade
de Deus está derramada em nossos corações pelo Espírito Santo, que nos foi dado. Logo,
inconvenientemente se diz que a Pessoa divina é enviada quanto aos dons da graça santificante.

3. Demais. – Agostinho ensina: Diz-se que o Filho é enviado porque é percebido temporalmente pelo
nosso espírito. Ora, o Filho é conhecido, não só pela graça santificante, mas também pela graça gratuita,
assim como pela fé e pela ciência. Logo, a Pessoa divina não é enviada quanto apenas à graça
santificante.

4. Demais. – Rábano diz que o Espírito Santo foi dado aos Apóstolos para operarem milagres. Pelo que
não é um dom de graça santificante, mas da gratuidade. Logo, a Pessoa divina não é dada somente
quanto à graça santificante.
Mas, em contrário, diz Agostinho, que o Espírito Santo procede temporalmente, para santificar a
criatura. Ora, a missão é a processão temporal. Logo, como a santificação da criatura não se opera
senão pela graça santificante, segue-se que a missão invisível da Pessoa divina não existe senão pela
graça santificante.

SOLUÇÃO. – À Pessoa divina convém o ser enviada, no sentido em que existe de novo modo em alguém;
e ser dada, no sentido de ser possuída por alguém. Ora, nada disto é possível senão pela graça
santificante. Pois, há um modo comum pelo qual Deus está em todas as coisas pela essência, pela
potência e pela presença; assim como a causa está nos efeitos que participam da sua bondade. Mas
além desse modo comum, há um modo especial, que convém a natureza racional, na qual dizemos que
Deus está, como o conhecido, no conhecente, e o amado, no amante. E porque, conhecendo e amando,
a criatura racional atinge, pela sua operação, o próprio Deus; deste modo especial dizemos não somente
que Deus está na criatura racional, mas também nela habita, como no seu templo. E assim, nenhum
outro efeito pode ser a razão de estar a Pessoa divina na criatura racional, de novo modo, senão a graça
santificante. Por onde, somente quanto a tal graça a Pessoa divina é enviada e procede temporalmente.
– Semelhantemente, consideramo-nos possuidores só daquilo de que livremente podemos usar ou
gozar. Ora, o poder de gozar a Pessoa divina só é possível pela graça santificante. – Contudo, pelo
próprio dom dessa graça possuímos o Espírito Santo que habita em nós. Por onde, o próprio Espírito
Santo é dado e é enviado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –O dom da graça santificante aperfeiçoa a criatura racional,
para que livremente use, não só do próprio dom criado, mas para que também goze da própria Pessoa
divina. E assim, a missão invisível se opera pelo dom da graça santificante; e contudo a própria Pessoa
divina é dada.

RESPOSTA À SEGUNDA. –A graça santificante dispõe a alma para receber a Pessoa divina, e é o que
queremos significar quando dizemos que o Espírito Santo é dado, quanto ao dom da graça. Contudo, o
próprio dom da graça vem do Espírito Santo; e isto o exprimimos quando dizemos que a caridade está
derramada em nossos corações pelo Espírito Santo.

RESPOSTA À TERCEIRA. –Embora por alguns outros efeitos o Filho possa ser conhecido por nós, todavia
não habita em nós nem é possuído por nós, por outros efeitos.

RESPOSTA À QUARTA. –Fazer milagres manifesta a graça santificante, assim como a manifesta o dom da
profecia e qualquer graça gratuita. Por isso, a graça gratuita é chamada manifestação do Espírito. Assim,
pois, se diz que o Espírito Santo foi dado aos Apóstolos para fazerem milagres, porque lhes foi dada a
graça santificante como sinal manifestativo. Se, porém, fosse dado somente o sinal da graça
santificante, sem a graça, não se diria ter sido dado o Espírito Santo, pura e simplesmente; senão talvez
com alguma determinação, assim como se diz que é dado o espírito profético ou de milagres, a quem
recebeu do Espírito Santo a virtude de profetizar ou de fazer milagres.

## Art. 4 — Se também ao Pai convém ser enviado.
(I Sent., dist. XV, q. 2; Contra errores Graec., cap. XIV).
O quarto discute-se assim. – Parece que também ao Pai convém ser enviado.

1. – Pois, ser a divina Pessoa enviada é o mesmo que ser dada. Ora, o Pai dá-se a si mesmo, porquanto
não pode ser possuído se a si mesmo não se der. Logo, pode-se dizer que o Pai a si mesmo se envia.

2. Demais. – A Pessoa divina é enviada para fazer a graça habitar em nós. Ora, pela graça toda a
Trindade habita em nós, segundo a Escritura (Jo 14, 23): Nós viremos a ele e faremos nele morada. Logo,
qualquer das divinas Pessoas é enviada.

3. Demais. – O que convém a uma das Pessoas convém a todas, salvo as noções e o ser tal pessoa. Ora, a
missão não significa nenhuma pessoa; e nem a noção, pois, há somente cinco noções, como se disse.
Logo, a qualquer Pessoa divina convém o ser enviada.
Mas, em contrário, diz Agostinho, que só o Pai nunca se considera enviado.

SOLUÇÃO. – A missão, por essência, importa a processão de outrem; e, em Deus, quanto à origem,
como dissemos. Por onde, não procedendo o Pai de outrem, de nenhum modo lhe convém o ser
enviado; mas só ao Filho e ao Espírito Santo, aos quais convém o proceder de outrem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –Se dar significa a comunicação liberal de uma coisa, então
o Pai se dá a si mesmo, porque liberalmente se comunica à criatura para ser gozado. Se, porém, implica
a autoridade de quem dá, relativamente ao que é dado, então não convém ser dado senão à Pessoa
divina que procede de outra, assim como não convém o ser enviada.

RESPOSTA À SEGUNDA. –Embora o efeito da graça também provenha do Pai, que por ela habita em nós
bem como o Filho e o Espírito Santo; como, todavia, o Pai não procede de outrem, não o consideramos
enviado. E é o que afirma Agostinho quando diz que o Pai, por ser conhecido de alguém no tempo, não
se considera por isso enviado; pois não tem de quem provenha ou de quem proceda.

RESPOSTA À TERCEIRA. –A missão, importando processão de quem envia, inclui na sua significação, a
noção; não por certo em especial, mas, em geral, enquanto que provir de outro é comum às duas
noções.

## Art. 5 — Se ao Filho convém ser enviado invisivelmente.
(I Sent., dist. XV, q. 4. a. 1; IV Cont. Gent., cap. XXXIII).
O quinto discute-se assim. – Parece que não convém ao Filho ser enviado invisivelmente.

1. – Pois, a missão invisível da Pessoa divina depende dos dons da graça. Ora, todos os dons da graça
pertencem ao Espírito Santo, segundo a Escritura (1 Cor 12, 11): Todas estas coisas obra só um e o
mesmo Espírito. Logo, o Espírito Santo somente é que é invisivelmente enviado.

2. Demais. – A missão da divina Pessoa se faz pela graça santificante. Ora, os dons pertencentes à
perfeição do intelecto não são dons da graça santificante, pois podem ser possuídos sem a caridade,
conforme a Escritura (1 Cor 13, 2): E se eu tiver o dom de profecia e conhecer todos os mistérios e
quanto se pode saber, e se tiver toda a fé, até o ponto de transportar montes, e não tiver caridade, não
sou nada. Procedendo, pois, o Filho como Verbo do intelecto, resulta que lhe não convém ser
invisivelmente enviado.

3. Demais. – A missão da Pessoa divina é uma processão, como já se disse. Ora, uma é a processão do
Filho, outra, a do Espírito Santo. Logo, também são diferentes as missões, se ambos são enviados. E
então uma delas será supérflua, por ser suficiente uma para santificar a criatura.
Mas, em contrário, diz a Escritura a respeito da Sabedoria divina (Sb 9, 10): Envia-a dos teus santos céus
e do trono da tua grandeza.

SOLUÇÃO. – Pela graça santificante, toda a Trindade habita em a nossa alma, segundo a Escritura (Jo 14,
23):Nós viremos a ele e faremos nele morada. Ora, o ser a Pessoa divina enviada a alguém, pela graça
invisível, significa um novo modo dessa divina Pessoa inabitar; e a sua origem, de outra Pessoa. Por
onde, convindo tanto ao Filho como ao Espírito Santo, inabitar em alguém pela graça e o originar-se de
outrem, a ambos convém o serem enviados invisivelmente. Porém ao Pai, embora lhe convenha o
inabitar em nós pela graça, contudo não lhe convém o originar-se de outrem e, por conseqüência, nem
o ser enviado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora todos os dons, como tais, sejam atribuídos ao
Espírito Santo, por ser por essência o dom primeiro, como Amor, conforme dissemos, todavia, alguns
dons, nas suas noções próprias, são atribuídos ao Filho por uma certa apropriação, a saber, a que
pertence ao intelecto. E quanto a tais dons é que se atribui a missão ao Filho. Por onde, diz Agostinho,
que o Filho é enviado a cada um invisivelmente, quando por cada um é conhecido e percebido.

RESPOSTA À SEGUNDA. –A alma se conforma com Deus pela graça. Por onde, se alguma Pessoa divina
for enviada a alguém, pela graça, necessariamente esta há-se de assimilar com a Pessoa divina enviada,
por algum dom da graça. E sendo o Espírito Santo amor, a alma com ele se assimila pelo dom da
caridade. Por onde, relativamente ao dom da caridade é que se considera a missão do Espírito Santo. O
Filho, porém, é o Verbo, não de qualquer modo, mas como espirador do Amor. Por isso diz Agostinho: O
Verbo que pretendemos insinuar é conhecimento com amor. Logo, o Filho é enviado, não quanto a
qualquer perfeição do intelecto, mas quanto a uma instrução do intelecto tal que nos faça prorromper
nos afetos do amor, como diz a Escritura (Jo 6, 45):Todo aquele que do Pai ouviu e aprendeu, e vem a
mim. E noutro lugar (Sl 38, 4): Na minha meditação se encenderá fogo. Donde o dizer Agostinho
sinaladamente, que o Filho é enviado àquele por quem é conhecido e percebido; pois a percepção
significa uma notícia experimental. E essa é a que se chama propriamente sapiência, ou ciência
saborosa, segundo a Escritura (Ecle 6, 23): A sapiência que faz o homem inteligente é segundo o nome
que tem.

RESPOSTA À TERCEIRA. –A missão importa a origem da Pessoa enviada e a inabitação em alguém pela
graça, como dissemos. Se, pois, falamos da missão, quanto à origem, então a missão do Filho se
distingue da do Espírito Santo, assim como a geração se distingue da processão. Se porém quanto ao
efeito da graça, então as duas missões se comunicam radicalmente pela graça. Mas se distinguem pelos
efeitos da graça, que são a iluminação do intelecto e a ardência do afeto. Por onde, é manifesto que
uma pode existir sem a outra, porque nenhuma existe sem a graça santificante; nem uma pessoa se
separa de outra.

## Art. 6 — Se a missão invisível se realiza em todos os que participam da graça.
(I Sent. Dist., XV, q. 5, a. 1).
O sexto discute-se assim. – Parece que a missão invisível não se realiza em todos os que participam da
graça.

1. – Pois, os Patriarcas do Testamento Velho foram participantes da graça. Ora, não parece que a eles
lhes fosse feita a missão invisível, pois, diz a Escritura (Jo 7, 39): Ainda o Espírito não fora dado, por não
ter sido ainda glorificado Jesus. Logo, a missão invisível não se realiza em todos os participantes da
graça.

2. Demais. – O progresso na virtude não é possível senão pela graça. Ora, a missão invisível não parece
fundada no progresso da virtude, que é contínuo. Pois a caridade, ou sempre aproveitando ou sempre
faltando, a missão seria contínua. Logo, a missão invisível não se realiza em todos os que participam da
graça.

3. Demais. – Cristo e os bem-aventurados têm a plenitude da graça. Ora, parece que neles não se realiza
a missão, porque esta supõe uma distancia. – Ora, Cristo, enquanto homem, e todos os bem-
aventurados estão unidos perfeitamente a Deus. Logo, nem em todos os que têm a graça se realiza a
missão invisível.

4. Demais. – Os sacramentos da lei nova contem a graça, e todavia não se diz que neles se realiza a
missão invisível. Logo, nem em todos os que tem a graça se realiza a missão invisível.
Mas, em contrário, segundo diz Agostinho, a missão invisível se realiza para santificar a criatura. Ora,
toda a criatura que tem a graça está santificada. Logo, em toda criatura nessas condições se realiza a
missão invisível.

SOLUÇÃO. – Como dissemos, a missão, por essência, importa em vir a estar o enviado onde antes não
estava, como se dá no domínio das coisas criadas; ou estar onde antes já estivera, mas de certo modo,
no sentido em que a missão é atribuída às Pessoas divinas. E assim, naquele em que se realiza a missão
devemos considerar duas coisas, a saber: a inabitação da graça e uma certa invocação provocada pela
graça. Por onde, naqueles em quem se encontra uma e outra se realiza a missão invisível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –A missão invisível foi realizada nos Patriarcas do
Testamento Velho. Por isso, diz Agostinho que, enquanto enviado invisivelmente, o Filho está nos
homens ou com os homens. O que já se realizou com os Patriarcas e Profetas. Logo, quando a Escritura
diz: Ainda o Espírito não fora dado – entende-se da dação feita visivelmente no dia de Pentecostes.

RESPOSTA À SEGUNDA. –Mesmo relativamente ao progresso da virtude ou ao aumento da graça,
realiza-se a missão invisível. Por isso, diz Agostinho que a pessoa a quem é enviado o Filho essa o
conhece e percebe quanto ele pode ser conhecido pela apreensão de quem progride, ou da alma
racional perfeita em Deus. Contudo a missão invisível se considera, precipuamente, em relação ao
aumento da graça pelo qual praticamos atos que antes não praticávamos; ou entramos em algum novo
estado de graça. P. ex., quando alguém, pela graça, faz milagres ou profetiza, ou quando, pelo fervor da
caridade, se expõe ao martírio ou renuncia às coisas que possui ou pratica qualquer obra difícil.

RESPOSTA À TERCEIRA. – A missão invisível realiza-se nos bem-aventurados, no princípio mesmo da
bem-aventurança. Depois porém, neles se realiza a missão invisível; não quanto à intensidade da graça,
mas por lhes serem revelados alguns mistérios de novo, o que se dará até o dia do juízo. E esse aumento
depende da extensão da graça que se estende a muitas coisas. Porém em Cristo realizou-se a missão
invisível desde o momento da sua concepção, mas não depois; porque, desde o princípio da sua
concepção foi cheio de toda sabedoria e graça.

RESPOSTA À QUARTA. – A graça está nos sacramentos da nova lei instrumentalmente, assim como a
forma do artificiado está nos instrumentos da arte, pela influência que decorre do agente para o
paciente. Ora, a missão não se considera realizada senão em relação ao termo. Por onde, a missão da
divina Pessoa não se realiza nos sacramentos, mas nos que, pelos sacramentos, recebem a graça.

## Art. 7 — Se convém ao Espírito Santo ser enviado visivelmente.
(I Sent., dist. XVI, a. 1).
O sétimo discute-se assim. – Parece que não convém ao Espírito Santo ser visivelmente enviado.

1. – Pois, o Filho, enquanto visivelmente mandado ao mundo, é considerado menor que o Pai. Ora,
nunca se lê na Escritura que o Espírito Santo seja menos que o Pai. Logo, ao Espírito Santo não convém
ser enviado.

2. Demais. – A missão visível é considerada relativamente a alguma criatura tomada como visível; assim,
a missão do Filho, segundo a carne. Ora, o Espírito Santo não assumiu nenhuma criatura visível. Por
onde, não pode ser considerado como estando numas criaturas visíveis de modo diferente por que está
em outras; senão talvez por um sinal, como está também nos sacramentos e em todas as figuras da Lei.
Logo, o Espírito Santo não é enviado visivelmente; ou devemos dizer que a sua missão visível é
considerada segundo todos esses modos referidos.

3. Demais. – Qualquer criatura visível é um efeito demonstrativo de toda a Trindade. Logo, por tais
criaturas visíveis, o Espírito Santo não é mais enviado, que outra Pessoa.

4. Demais. – O Filho foi enviado visivelmente segundo a mais digna das criaturas visíveis, a saber,
segundo a natureza humana. Se, pois, o Espírito Santo é enviado visivelmente, devia tê-lo sido segundo
algumas criaturas racionais.

5. Demais. – As coisas que Deus realiza visivelmente, realiza-o pelo ministério dos anjos, como diz
Agostinho. Por onde, as formas que vieram a existir visivelmente, o devem à ação dos anjos; e assim, os
próprios anjos é que são enviados e não o Espírito Santo.

6. Demais. – Se o Espírito Santo é enviado visivelmente, isso não pode ser senão para manifestar a
missão invisível; pois, as coisas invisíveis se manifestam pelas visíveis. Logo, a quem não foi feita a
missão invisível também não deve ser feita a visível; e a todos aos quais foi feita a invisível, quer em o
novo quer no velho Testamento, também deve sê-lo a visível, o que evidentemente é falso. Logo, o
Espírito Santo não é enviado invisivelmente.
Mas, em contrário, diz Escritura (Mt 3, 16) que o Espírito Santo desceu sobre o Senhor batizado, em
forma de pomba.

SOLUÇÃO. – Deus provê a todos os seres, ao modo de cada um. Ora, é conatural ao homem ser levado
pelas coisas visíveis às invisíveis, como resulta do que já foi dito. Por onde, é necessário que as coisas
invisíveis de Deus ao homem sejam manifestadas pelas visíveis. Assim, pois como Deus, de certo modo,
se revelou aos homens, ele próprio e as processões eternas das Pessoas, por meio de criaturas visíveis, e
de certos indícios; assim foi conveniente que também as missões invisíveis das Pessoas divinas fossem
manifestadas por meio de algumas criaturas visíveis. – Mas, de modo diferente são enviados o Filho e o
Espírito Santo. Pois, a este enquanto procede como Amor, compete ser o dom da santificação; àquele,
porém enquanto princípio do Espírito Santo, compete ser o autor dessa santificação. Por isso, o Filho é
enviado visivelmente como Autor da santificação, e o Espírito Santo, como indicio dela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –O Filho assumiu a criatura visível, com que se manifestou,
na unidade da pessoa, de modo a poder ser atribuído ao Filho de Deus o que o for a essa criatura. E
assim, em razão da natureza assumida, o Filho é considerado menor que o Pai. Mas o Espírito Santo não
assumiu nenhuma criatura visível com que se manifestasse na unidade da pessoa, de modo a ser dele
predicado o que a ela lhe convém. Por isso não pode ser considerado menor que o Pai, por causa de
nenhuma criatura visível.

RESPOSTA À SEGUNDA. –A missão visível do Espírito Santo não é considerada relativamente à visão
imaginária, que é uma visão profética. Pois, diz Agostinho: A visão profética não se manifesta aos olhos
corpóreos, por formas corpóreas mas ao espírito, por imagens espirituais dos corpos. Porém a tal
pomba e o fogo, com os olhos os viram todos os que viram. Demais, nem ao Espírito Santo se aplicam
tais figuras, como ao Filho, do qual disse a Escritura (1 Cor 10, 4): Cristo porém era pedra. Pois essa
pedra já existia como criatura e, para exprimir a ação, foi tomada pelo nome de Cristo, o qual ela
significava. Mas a referida pomba e o fogo vieram à existência de súbito, para significarem
expressamente o que significam. Pois, parecem-me semelhantes àquela chama, que apareceu na sarça a
Moisés, e àquela coluna, que era seguida pelo povo no deserto, e aos relâmpagos e trovões, que
prorromperam enquanto a lei era dada no monte. Porque a figura corporal dessas coisas veio à
existência para significar e predicar uma determinada realidade. – E assim é claro, que a missão visível
não é considerada relativamente às visões proféticas, que eram figuradas e não, corpóreas; nem aos
sinais sacramentais do velho e do novo Testamento, pelos quais certas coisas já preexistentes são
assumidas para significarem outras coisas. Mas a Escritura diz, que o Espírito Santo é enviado
visivelmente, enquanto revelado por certas criaturas, como por sinais para isso adrede preparados.

RESPOSTA À TERCEIRA. – Embora essas criaturas visíveis as criasse toda a Trindade, todavia foram feitas
para revelar especialmente esta ou aquela pessoa. Pois, assim como por diversos nomes é designado o
Pai, o Filho e o Espírito Santo; assim também puderam ser significados por diversas coisas, embora entre
eles não haja nenhuma separação ou diversidade.

RESPOSTA À QUARTA. –Era necessário declarar a pessoa do Filho como o autor da santificação,
conforme dissemos. Por onde e necessariamente, a missão visível do Filho havia de realizar-se pela
natureza racional, à qual convém o agir e pode convir o ser santificada. Indício porém da santificação
podia ser qualquer outra criatura. Nem era necessário que a criatura visível formada para esse fim fosse
assumida pelo Espírito Santo na unidade de pessoa; pois que ele não a assumiria para realizar nada, mas
somente para indicar. E por isso também não devia durar mais que o tempo necessário para realizar os
seus desígnios.

RESPOSTA À QUINTA. – Essas criaturas visíveis foram formadas pelo ministério dos anjos; não contudo
para significarem a pessoa do anjo, mas a do Espírito Santo. Pois, por estar o Espírito santo nessas
criaturas visíveis como o assinalado, no sinal; por isso dizem que, por elas, o Espírito Santo é enviado
visivelmente, e não, o anjo.

RESPOSTA À SEXTA. – Não é necessário que a missão visível seja sempre manifestada exteriormente por
algum sinal visível; mas, como diz a Escritura (1 Cor 12, 7) – a cada um é dada a manifestação do Espírito
para proveito seu, i. é, da Igreja. Cuja utilidade está em, por sinais visíveis, confirmar-se e propagar-se a
fé. O que certo e principalmente foi feito por Cristo e pelos Apóstolos, segundo a Escritura (Hb 2, 3): A
qual tendo começado a ser anunciada pelo Senhor, foi depois confirmada entre nós pelos que a
ouviram. Por isso foi necessária a missão visível do Espírito Santo a Cristo, aos Apóstolos e aos outros
primitivos santos, nos quais, de algum modo, estava fundada a Igreja; de modo, porém, que a missão
visível feita a Cristo declarasse a missão invisível, missão esta a ele feita, não quando nasceu, mas no
princípio da sua concepção. Mas a missão visível foi feita a Cristo, no batismo, sob a forma de pomba,
animal fecundo, para mostrar a autoridade de Cristo para dar a graça, pela regeneração espiritual. Por
isso tonitruou a voz do Padre (Mt 3, 17) – Este é meu filho amado – para que, pela semelhança com o
Unigênito, os outros se regenerassem. Na transfiguração, sob a figura de nuvem lúcida, para mostrar a
exuberância da doutrina; e por isso foi dito (Mt 17, 5): Ouvi-o. Porém aos Apóstolos, sob a forma de
assopro, para mostrar o poder do ministério no dispensar os sacramentos; por isso foi-lhes dito (Jo 20,
23): Aos que vós perdoardes os pecados serão perdoados. Sob a figura de línguas de fogo ainda, para
significar o dever de ensinarem; por isso, foi dito (At 2, 4) que começaram a falar em várias línguas.
Enfim, aos Patriarcas do velho Testamento não foi necessária a missão visível do Espírito Santo porque a
missão visível do Filho tinha que se cumprir antes da do Espírito Santo; pois, este manifesta o Filho,
como o Filho o Pai. Todavia, houve aparições visíveis das Pessoas divinas aos Patriarcas do Testamento
velho, mas que se não podem chamar missões visíveis porque não foram feitas, segundo Agostinho,
para designar a inabitação da divina Pessoa pela graça, senão para manifestar alguma outra coisa.

## Art. 8 — Se nenhuma Pessoa é enviada senão por aquela da qual procede eternamente.
(I Sent., dist. XV, q. 3; De Pot., q. 10, a. 4, ad 14; Contra errores Graec, cap. XIV).
O oitavo discute-se assim. – Parece que nenhuma Pessoa divina senão por aquela da qual procede
eternamente.

1. – Porque, como diz Agostinho, o Pai por ninguém é enviado porque de ninguém procede. Se pois uma
Pessoa divina é enviada por outra, é necessário que dessa proceda.

2. Demais. – O mitente tem autoridade sobre o enviado. Mas, em relação à Pessoa divina, não pode
haver autoridade senão pela origem. Logo, é necessário que a Pessoa enviada se origine da que envia.

3. Demais. – Se uma Pessoa divina pode ser enviada por outra, da qual não provém, nada impede dizer
que o Espírito Santo é dado pelo homem, embora deste não provenha. O que vai contra Agostinho.
Logo, uma Pessoa divina não é enviada senão por outra, da qual procede.
Mas, em contrário, é que o Filho é enviado pelo Espírito Santo, segundo a Escritura (Is 48, 16): Agora o
Senhor Deus me enviou e o seu Espírito. Ora, o Filho não procede do Espírito Santo. Logo, uma Pessoa
divina é enviada por outra, da qual não procede.

SOLUÇÃO. – Há várias opiniões sobre esta matéria. Segundo uns, uma Pessoa divina não é enviada
senão por outra, da qual procede eternamente. E deste modo, quando se diz, que o Filho de Deus foi
enviado pelo Espírito Santo, isto se refere à natureza humana, em dependência da qual foi enviado para
pregar. Agostinho, porém, diz que o Filho é enviado tanto por si como pelo Espírito Santo; e o Espírito
Santo também é enviado por si e pelo Filho; assim, não é a qualquer Pessoa divina que convém ser
enviada, mas somente à Pessoa existente por outra; enviar, porém, convém a qualquer Pessoa.
Ora, ambas estas doutrinas encerram de algum modo a verdade. Porque quando se diz, que alguma
Pessoa é enviada, com isso tanto se designa a própria Pessoa existente por outra, como o efeito visível
ou invisível, no qual se funda a missão da Pessoa divina. Se, pois, o mitente é designado como princípio
da Pessoa enviada, então não é qualquer pessoa que envia, mas somente aquela a que é próprio ser o
princípio da outra pessoa. E assim, o Filho é enviado somente pelo Pai; o Espírito Santo, porém, pelo Pai
e pelo Filho. Mas se a Pessoa mitente for entendida como o princípio do efeito no qual se funda a
missão, nesse caso toda a Trindade envia a Pessoa enviada. Mas nem por isso o homem dá o Espírito
Santo, pois ele não pode causar o efeito da graça.
Assim ficam claras as RESPOSTAS ÀS OBJEÇÕES.
Tratado sobre a obra dos seis dias