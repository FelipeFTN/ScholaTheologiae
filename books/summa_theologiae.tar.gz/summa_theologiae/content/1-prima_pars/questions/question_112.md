# Questão 112: Da missão dos anjos.
Em seguida deve-se tratar da missão dos anjos.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se os anjos são enviados para ministério.
(Hebr., cap. I, lect. VI).
O primeiro discute-se assim. — Parece que os anjos não são enviados para ministério.

1. — Pois, qualquer missão é para algum determinado lugar. Ora, os atos intelectuais não determinam
lugar, porque o intelecto abstrai deste e do tempo. E como os atos angélicos são intelectuais, resulta
que os anjos não são enviados, para realizar os seus atos.

2. Demais. — O céu empírico é lugar pertencente à dignidade dos anjos. Se pois, eles nos são mandados,
em ministério, resulta que algo lhes perece da dignidade, o que é inadmissível.

3. Demais. — As ocupações exteriores impedem a contemplação da sabedoria e por isso diz a Escritura:
O que menos se distrai com outra qualquer ocupação alcançará a sabedoria. Se pois os anjos são
enviados para ministérios exteriores, resulta que se desviam da contemplação. Ora, toda a felicidade
deles consiste na contemplação de Deus. Se portanto, fossem enviados, diminuir-se-lhes-ia a beatitude,
o que é inadmissível.

4. Demais. — É próprio do inferior ministrar, dizendo por isso Escritura: Qual é maior, o que está
sentado à mesa, ou o que serve? Não é maior o que está sentado à mesa? Ora, os anjos são superiores a
nós, na ordem da natureza. Logo, não são enviados para o nosso ministério.
Mas, em contrário, diz a Escritura: Eis que eu enviarei o meu anjo, que vá adiante de ti.

SOLUÇÃO. — Do sobredito pode ser manifesto, que certos anjos são enviados por Deus para ministério.
Pois, como já se estabeleceu, quando se tratou da missão das Pessoas divinas, diz-se que é enviado
aquele que de algum modo, procede de alguém, de maneira que comece a estar onde antes não estava,
ou, onde antes já estava, mas de outro modo. Assim, diz-se que o Filho é enviado, bem como o Espírito
Santo, por ser procedente, originariamente, do Padre; de maneira que começa a ser, de novo, i. é, pela
graça ou pela natureza assumida, onde já antes estava, pela presença da Deidade. Pois, é próprio de
Deus estar em toda parte; sendo agente universal, a sua virtude atinge todos os entes, estando por isso
em todas as cousas, como antes já se disse. Ao passo que a virtude do anjo, agente particular, não
atinge todo o universo, mas, atingindo um ponto, não atinge outro, e assim, estando num lugar, está em
outro. Ora, é manifesto, pelo que já se disse, que a criatura corpórea é administrada pelos anjos. Por
onde, quando alguma cousa se deve fazer por algum dos anjos, em relação a alguma criatura corpórea,
nessa ocasião é que o anjo aplica a esse corpo a sua virtude e, então nele começa a estar. Mas como
tudo isso procede de ordem divina, resulta, conforme o que foi dito, que o anjo é enviado por Deus. A
ação porém que o anjo enviado por Deus, exerce, procede de Deus, como do primeiro princípio, por cuja
vontade e autoridade os anjos operam, reduz-se a Deus, como ao último fim. E essa é a razão de ser do
ministro, que é um como instrumento inteligente; ora, o instrumento é movido por outro e a sua ação
se ordena para outro. Por onde, as ações dos anjos chamam-se ministérios, e por isso se diz que eles são
enviados em ministério.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De dois modos se diz que uma operação é intelectual.
De um modo, consistindo como que no próprio intelecto, p. ex., a contemplação; e, tal operação não
tem determinado lugar; antes, segundo Agostinho, também nós, enquanto temos pela mente, algo de
externo, não estamos neste mundo. De outro modo, diz-se que uma ação é intelectual, quando regulada
e ordenada por algum intelecto. E assim, é manifesto, que as operações intelectuais às vezes, tem
lugares determinados.

RESPOSTA À SEGUNDA. — O céu empíreo pertence à dignidade do anjo, por certa congruência; pois, é
congruente que o corpo supremo seja atribuído à natureza, que está acima de todos os corpos. Mas
nem por isso o anjo recebe qualquer dignidade, do céu empíreo. Por onde, quando neste não está
atualmente, nada se subtrai à dignidade angélica; assim como nada perde o rei, quando não está
atualmente sentado no sólio real, que lhe é congruente à dignidade.

RESPOSTA À TERCEIRA. — Em nós a ocupação exterior impede a pureza da contemplação, porque nos
aplicamos à ação pelas virtudes sensitivas, cujos atos, quando praticados, retardam a atividade da
virtude intelectiva. Mas a atividade exterior do anjo, regulada só pela operação intelectual, de nenhum
modo lhe impede a contemplação; pois, a atividade que é regra e razão de outra não impede a esta
última, mas a coadjuva. E por isso Gregório diz, que os anjos não se exteriorizam de modo a serem
privados das alegrias da contemplação interna.

RESPOSTA À QUARTA. — Os anjos, nas suas ações externas, servem principalmente a Deus e,
secundariamente a nós. Não porque nós lhe sejamos superiores, absolutamente falando, mas porque
qualquer homem ou anjo é superior a toda criatura, quando, aderindo a Deus, torna-se, com Deus, um
só espírito. Donde o dizer a Escritura: Tendo cada um aos outros por superiores.

## Art. 2 — Se todos os anjos são enviados em ministério.
(II Sent., dist. X. a. 2; Hebr., Xp. I. lect. VI)
O segundo discute-se assim. — Parece que todos os anjos são mandados em ministério.

1. — Pois, diz o Apóstolo: Todos esses espíritos são uns administradores, enviados para exercer o seu
ministério.

2. Demais. — Entre as ordens a suprema é a dos Serafins, como resulta do que já foi dito. Ora, um
Serafim foi enviado para purificar os lábios do Profeta, como se lê em Isaias. Logo, com maior razão, os
anjos inferiores são enviados.

3. Demais. — As divinas Pessoas excedem infinitamente todas as ordens dos anjos. Ora, Elas são
enviadas, como antes se disse: Logo, com maior razão, qualquer dos anjos supremos.

4. Demais. — Se os anjos superiores não são enviados para ministério exterior, tal não é senão porque
executam os ministérios divinos, pelos inferiores. Ora, como todos os anjos são desiguais, conforme já
se estabeleceu, qualquer anjo, exceto o último, se serve do inferior. Logo, só o último é o enviado em
ministério, o que vai contra a Escritura que diz: Um milhão o serviam. Mas, em contrário, diz Gregório,
referente à sentença de Dionísio: As ordens superiores de nenhum modo exercem o ministério exterior.

SOLUÇÃO. — Como do sobredito resulta, é ordem da divina providência, não só quanto aos anjos, mas
quanto a todo o universo, que os seres inferiores sejam governados pelos superiores. Mas para a
manifestação da graça, que é de ordem mais alta, o princípio agora referido sofre transgressão, por
dispensa divina, quanto aos seres corpóreos. Assim, Deus iluminou o cego e ressuscitou Lázaro,
imediatamente, sem a ação dos corpos celestes. Mas, também os anjos bons e maus podem exercer
influência nos corpos, fora da ação dos corpos celestes, condensando as nuvens em chuvas, ou cousas
semelhantes. Nem deve ninguém duvidar que Deus possa imediatamente revelar certas cousas aos
homens, sem a mediação dos anjos; bem como os anjos superiores, sem a mediação dos inferiores.
Segundo, pois, esta consideração, alguns disseram que pela lei comum os superiores não são enviados,
mas só os inferiores; mas por dispensa divina às vezes também os superiores são enviados. — Mas isto
não é racional, porque a ordem angélica é relativa aos dons da graça. Ora, a ordem da graça não deve
ser preterida a nenhuma outra ordem, assim como a ordem da natureza lhe é preterida. E deve-se
considerar também que a ordem da natureza, na operação dos milagres, é preterida, para a
confirmação da fé, para o que nada serviria preterir a ordem angélica, porque nós não poderíamos
percebê-lo. Ora, nada há tão grande, nos ministérios divinos, que não possa ser exercido pelas ordens
inferiores. Por onde, Gregório diz, que os núncios das cousas mais elevadas chamam-se Arcanjos. E por
isso, foi enviado à Virgem Maria o Arcanjo Gabriel, tendo sido esse o mais elevado de todos os
ministérios divinos, como no mesmo passo se diz. Por onde, deve-se concluir, absolutamente, com
Dionísio, que os anjos superiores nunca são enviados para ministério exterior.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como, nas Pessoas divinas, uma é a missão visível,
relativa à criatura corpórea; outra, invisível, relativa ao afeto espiritual; assim também há uma missão
angélica chamada exterior, relativa a algum ministério, referente a seres corpóreos e, para tal missão
nem todos os anjos são enviados. Mas há outra missão, interior, relativa aos afetos intelectuais, pela
qual um anjo ilumina outro; e assim todos os anjos são enviados. — Ou, de outro modo, deve-se dizer,
que no passo citado, o Apóstolo quer provar que Cristo é maior que os anjos, pelos quais foi dada a lei,
mostrando assim a excelência da lei nova sobre a antiga. Donde deve-se necessariamente compreender
esse passo como referente só aos ministérios do anjo, pelos quais foi dada a lei.

RESPOSTA À SEGUNDA. — Segundo Dionísio, o anjo mandado para purificar os lábios do profeta era dos
inferiores; mas foi chamado Serafim, isto é, que incendeia, equivocamente por ter vindo incendiar os
lábios do profeta. — Ou se deve dizer, que os anjos superiores comunicam os dons próprios, pelos quais
são denominados, mediante os anjos inferiores. Assim, diz-se que um Serafim purificou, incendiando, os
lábios do profeta; não que o fizesse imediatamente, mas que, pela sua virtude, o fez por meio de um
anjo inferior. Assim como se diz que o Papa absolve alguém, mesmo que dê a absolvição por ofício de
outrem.

RESPOSTA À TERCEIRA. — As Pessoas divinas não são enviadas em ministério; mas, diz-se que o são,
equivocamente, como resulta do que se estabeleceu antes.

RESPOSTA À QUARTA. — Há muitos graus nos ministérios divinos. Donde, nada impede que mesmo
anjos desiguais sejam enviados imediatamente para esses ministérios; de modo porém que os
superiores sejam enviados para os ministérios mais altos, e os inferiores, para os inferiores.

## Art. 3 — Se os anjos enviados também assistem.
(II. Sent., dist. X, a. 1; Hebr., cap. I, lect. VI; In Iob, cap. I lect. II).
O terceiro discute-se assim. — Parece que os anjos enviados também assistem.

1. — Pois, diz Gregório: Logo, os anjos são enviados e assistem; porque embora o espírito angélico seja
circunscrito, contudo o sumo espírito, Deus, não o é.

2. Demais. — Um anjo foi enviado a Tobias, em ministério. E contudo disse: Eu sou o anjo Rafael, um dos
setes que assistimos diante de Deus, como se lê na Escritura. Logo, os anjos enviados assistem.

3. Demais. — Qualquer dos santos anjos está mais próximo de Deus do que Satan. Ora, Satan é
assistente de Deus, conforme a Escritura: Tendo-se os filhos de Deus apresentado diante do Senhor;
encontrou-se Satanás entre eles. Logo, com maior razão os anjos enviados em ministério assistem.

4. Demais. — Se os anjos inferiores não assistem é somente porque não recebem as iluminações divinas
imediatamente, mas por meio dos superiores. Ora, qualquer anjo, exceto o que de todos é o supremo,
recebe por meio do superior essas iluminações. Logo, só o anjo supremo assiste; o que vai contra aquilo
da Escritura: Mil milhões assistiam diante dele.
Mas, em contrário, a propósito daquilo da Escritura — Porventura tem número os seus soldados? — diz
Gregório: Assistem aquelas potestades, que não saem a anunciar certas cousas aos homens. Logo, os
enviados em ministério não assistem.

SOLUÇÃO. — Dividem-se os anjos em assistentes e ministrantes, à semelhança dos que servem a um rei,
dos quais uns sempre lhe assistem e lhe ouvem imediatamente as ordens; outros porém recebem, dos
assistentes, o enunciado das ordens reais. Assim, os que estão à testa da administração das cidades
chamam-se ministrantes e não assistentes. Deve-se pois considerar que, como todos os anjos vêm
imediatamente a essência divina, diz-se que todos os que ministram assistem. Por onde, diz Gregório:
podem sempre assistir, ou contemplar a face do Pai, os que são mandados em ministério exterior, para
a nossa salvação. Mas nem todos os anjos podem alcançar os segredos dos divinos mistérios, na
claridade mesma da divina essência; senão só os superiores, que anunciam aos inferiores. E então, só
aqueles, que são os da primeira hierarquia, se diz que assistem, por ser próprio dela, como ensina
Dionísio, receber a iluminação imediatamente de Deus. E daqui se deduzem as respostas à primeira e à
segunda objeções, procedentes do primeiro modo de assistir.

RESPOSTA À TERCEIRA. — Não se diz que Satan assistia, mas que estava entre os assistentes; pois, como
ensina Gregório, embora perdesse a beatitude, contudo não perdeu a natureza semelhante à dos anjos.

RESPOSTA À QUARTA. — Todos os assistentes vêm, imediatamente, certas cousas, na claridade da
divina essência; e por isso diz-se que é próprio a toda a primeira hierarquia ser iluminada
imediatamente por Deus. Mas, nela, os superiores alcançam mais que os inferiores, e isso lhes
transmitem a estes, iluminando-os; assim como, dentre os que assistem ao rei, um entra, mais que
outro, nos segredos do mesmo.

## Art. 4 — Se todos os anjos da segunda hierarquia são enviados.
(II Sent., dist. X, a. 3; Hebr., cap. I, lect.VI).
O quarto discute-se assim. — Parece que todos os anjos da segunda hierarquia são enviados.

1. — Pois, todos os anjos ou assistem ou ministram, conforme está na Escritura. Ora, os anjos da
segunda hierarquia, iluminados pelos da primeira, como diz Dionísio, não assistem: Logo, todos os anjos
da segunda hierarquia são enviados em ministério.

2. Demais. — Gregório diz serem mais os que ministram que os assistentes. Ora, tal não seria, se os
anjos da segunda hierarquia não fossem enviados em ministério. Logo, todos os dessa hierarquia são
enviados em ministério.
Mas, em contrário, diz Dionísio, que as Dominações estão acima de toda sujeição. Ora, ser enviado em
ministério supõe sujeição. Logo, as Dominações não são enviadas em ministério.

SOLUÇÃO. — Como já se disse, propriamente convém ao anjo ser enviado em ministério exterior,
enquanto opera, em relação a alguma criatura corpórea, por ordem divina; e isso é a execução do divino
ministério. As propriedades dos anjos porém manifestam-se pelos nomes dos mesmos, como diz
Dionísio. Por onde, são enviados para o ministério externo os anjos das ordens em cujos nomes se
compreende alguma execução. Ora, o nome das Dominações não importa em nenhuma execução, mas
somente em disposição e ordem sobre o que se deve executar; compreendendo-se nos nomes das
ordens inferiores tal execução. Assim, os anjos e os Arcanjos têm tais denominações, porque anunciam;
as Virtudes e as Potestades são assim designados pela relação com algum ato; e também do Príncipe é
próprio ser o primeiro entre os que operam, como diz Gregório. Por onde, é próprio a essas cinco
ordens serem mandadas em ministério exterior; não porém, às quatro superiores.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As Dominações contam-se entre os anjos ministrantes,
não porque executem o ministério, mas porque dispõem e mandam o que deve ser feito pelos outros.
Assim como nas construções os arquitetos não fazem nada manualmente, mas só dispõem e ordenam o
que os outros devem fazer.

RESPOSTA À SEGUNDA. — Pode-se dar dupla razão do número dos assistentes e dos ministrantes. —
Pois, Gregório diz, que são mais estes do que aqueles. E o passo — um milhão o serviam — não o
entende ele em acepção multiplicativa, mas, participativa, como se dissesse: mil do número dos mil. E
assim exprime-se que é indefinido o número dos ministrantes, para significar o excesso; porém o dos
assistentes é finito, pelo que se acrescenta — mil milhões assistiam diante dele. E isto está de acordo
com a razão dos Platônicos, que diziam que, quanto mais os seres se aproximam do primeiro princípio
uno, tanto menor é a multidão deles; assim como quanto mais um número se aproxima da unidade
tanto menor multidão tem. E esta opinião é exata quanto ao número das ordens, das quais seis
ministram e três assistem. — Mas Dionísio diz, que a multidão dos anjos transcende toda multidão
material. Pois, assim como os corpos superiores transcendem imensamente em grandeza os corpos
inferiores, assim as naturezas incorpóreas superiores transcendem em multidão todas as corpóreas,
porque, o melhor é o mais visado e multiplicado por Deus. E segundo esta opinião, sendo os assistentes
superiores aos ministrantes, serão mais que estes. Donde, conforme esta mesma opinião um milhão
deve-se entender multiplicativamente, como se dissesse mil milhões. E como dez vezes cem são mil, se
se dissesse, dez vezes cem mil dar-se-ia a entender, que eram tantos os assistentes como os
ministrantes. Mas, como se diz — dez mil vezes cem mil — significa-se serem muito mais os assistentes
que os ministrantes. — Mas não se quer dizer com isso que não é maior que esse o número dos anjos
senão muito maior, porque excede toda multidão material. O que é expresso pela multiplicação dos
maiores números, por si mesmos, que são os números denários, centenários e milenários, como diz
Dionísio no mesmo lugar.