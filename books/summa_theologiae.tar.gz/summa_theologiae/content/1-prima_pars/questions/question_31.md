# Questão 31: Da Unidade e da Pluralidade em Deus.
Em seguida devemos tratar da unidade e da pluralidade em Deus. E nesta questão discutem-se quatro
artigos:

## Art. 1 — Se em Deus há Trindade.
(Sent., dist. XXIV, q. 2, a. 2).
O primeiro discute-se assim. — Parece que não há trindade em Deus.

1. — Pois, todo nome divino significa substância ou relação. Ora, o nome de Trindade não significa
substância, porque então se predicaria, de cada uma das pessoas; e nem relação, porque não é
empregado como referente a outro. Logo, não se deve aplicar a Deus o nome de Trindade.

2. Demais. — O nome de Trindade, significando multidão, é coletivo e portanto não convém a Deus,
porque a unidade expressa pelo nome coletivo é mínima, ao passo que a de Deus é máxima. Logo, o
nome de Trindade não convém a Deus.

3. Demais. — Todo trino é tríplice. Ora, a triplicidade, sendo uma espécie de desigualdade, não existe
em Deus. Logo, nem a Trindade.

4. Demais. — Sendo Deus a sua essência, tudo o que nele existe está na unidade da sua essência. Ora, se
em Deus há Trindade, esta existirá na unidade da sua essência. Logo, haverá nele três unidades
essenciais, o que é herético.

5. Demais. — Em tudo o que se diz de Deus, o concreto é predicado do abstrato; assim a deidade é Deus
e a paternidade é o Pai. Ora, à Trindade se não pode chamar trina, porque então haveria nove
realidades em Deus, o que é errôneo. Logo, não se deve aplicar o nome de Trindade a Deus.
Mas, em contrário, diz Atanásio: Devemos venerar a Unidade na Trindade e a Trindade na Unidade.

SOLUÇÃO. — O nome de Trindade em Deus significa um determinado número de pessoas. Pois, assim
como pomos a pluralidade de pessoas em Deus, assim também devemos usar do nome de Trindade;
porquanto, o mesmo que a pluralidade significa indeterminadamente, determinadamente o significa o
nome de Trindade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O nome de Trindade, segundo a etimologia do vocábulo,
significa a essência una de três pessoas; e é como se disséssemos unidade de três. Mas, na sua
expressão própria esse vocábulo significa antes o número das pessoas de uma mesma essência. Por isso
não podemos dizer que o Pai seja Trindade, pois não é três pessoas. Porque o vocábulo não significa as
relações mesmas das pessoas, mas antes o número delas, nas suas relações mútuas. E daí vem que este,
pela sua denominação, não é um termo que exprima relação.

RESPOSTA À SEGUNDA. — Duas coisas implica o nome coletivo: a pluralidade dos supostos e uma certa
unidade, a saber, a de uma determinada ordem. Assim, o povo é uma multidão de homens
compreendidos numa mesma ordem. Ora, quanto à primeira, o nome de Trindade convém com os
nomes coletivos; mas quanto à segunda, deles difere; pois, na divina Trindade não somente há unidade
de ordem, mas com esta vai também a de essência.

RESPOSTA À TERCEIRA. — Trindade se emprega em sentido absoluto, pois significa o número ternário
das pessoas. Ao passo que a triplicidade significa proporção de desigualdade; pois, é uma espécie de
proporção desigual, como está claro em Boécio. Logo, não há em Deus triplicidade, mas Trindade.

RESPOSTA À QUARTA. — Pela Trindade divina se entendem o número e as pessoas enumeradas. Assim,
quando falamos da Trindade na unidade, não introduzimos o número na unidade da essência, como se
esta fosse três vezes uma; mas, as pessoas enumeradas, na unidade da natureza, assim como dizemos,
que os supostos de uma natureza nela existem. E inversamente, dizemos, que há unidade na Trindade,
como dizemos, que a natureza está nos seus supostos.

RESPOSTA À QUINTA. — Quando dizemos - A Trindade é trina - com a idéia de número, que ai
introduzimos, exprimimos a multiplicidade do mesmo número, em si mesmo; pois, o que chamamos
trino importa distinção nos supostos do ser do qual o predicamos. Portanto, não podemos dizer que a
Trindade é trina; pois seguir-se-ia, de ser trina a Trindade, que três seriam os seus supostos; assim
como, de dizer-se que Deus é trino, resulta serem três os supostos da divindade.

## Art. 2 — Se o Filho é outro que não o Pai.
(I Sent., dist. IX, q. 1, a. 1; dist. XIX, q. 1, a. 1, ad 2; dist. XXIV, q. 2, a. 1; De Pot., q. 9, a. 8).
O segundo discute-se assim. — Parece não é o Filho outro que não o Pai.

1. — Pois outro implica relação de diversidade substancial. Se, portanto, o Filho é outro que não o Pai,
resulta que é deste diverso, o que vai contra Agostinho quando afirma que, dizendo três pessoas, não
queremos nisso compreender a diversidade.

2. Demais. — Todos os seres entre si outros, de algum modo entre si diferem. Se, pois, o Filho é outro
que não o Pai, resulta que é deste diferente; o que vai contra Ambrósio, dizendo, O Pai e o Filho são
unos pela divindade; nem há entre eles diferença de substância ou qualquer outra diversidade.

3. Demais. — De ser outro deriva o ser alheio. Ora, o Filho não é alheio ao Pai: pois, Hilário diz, que nas
pessoas divinas nada é diverso, nada alheio, nada separável. Logo, o Filho não é outro que não o Pai.

4. Demais. — Outro e outra coisa significam o mesmo e só diferem pela significação genérica. Ora, se o
Filho é outro que não o Pai, resulta que o primeiro é outra coisa, diferente do Pai.
Mas, em contrário, diz Agostinho: Una é a essência do Pai, do Filho e do Espírito Santo, na qual não é
uma coisa o Pai, outra, o Filho e outra, o Espírito Santo, embora pessoalmente seja um o Pai, outro, o
Filho, outro, o Espírito Santo.

SOLUÇÃO. — Pois que se incorre em heresia proferindo palavras desordenadas, como diz Jerônimo, por
isso, quando se fala da Trindade, é necessário proceder com cautela e modéstia. Porque, como diz
Agostinho, em nenhum assunto mais perigosamente se erra, em nenhum a perquirição é mais laboriosa
e a descoberta mais frutuosa. Importa por isso, ao tratarmos da Trindade, evitar dois erros opostos,
prudentemente caminhando entre um e outro. Tais são o erro de Ário, ensinando a Trindade das subs-
tâncias com a das pessoas; e o da Sabélio, ensinando a unidade de pessoa com a de essência.
Por onde, para escapar ao erro de Ario, devemos evitar aplicar a Deus os nomes de diver-
sidade e diferença, para não o privarmos da unidade de essência. Podemos, porém, usar da
palavra distinção, por causa da oposição relativa. E assim, quando em qualquer escritura autêntica
encontramos a diversidade ou diferença de pessoas, diversidade ou diferença significam distinção. E
para não destruirmos a simplicidade da divina essência, devemos evitar os nomes
de separação e divisão, que é a do todo em suas partes. Para não destruirmos a igualdade, devemos
evitar o nome de disparidade.
Para não eliminarmos a semelhança, devemos evitar as palavras alheio e discrepante; assim, diz
Ambrósio, que no Pai e no Filho não há discrepância, mas, a divindade uma; e segundo Hilário, como se
disse, em Deus nadaé alheio, nada separável.
Por outro lado, para evitarmos o erro de Sabélio devemos evitar a palavra singularidade a fim de não
tolhermos a comunicabilidade à essência divina; por isso diz Hilário: É sacrilégio ensinar que o Pai e o
Filho são cada qual um Deus. Devemos também evitar a expressão único para lhe não tolhermos o
número das pessoas; donde, o dito de Hilário, no mesmo livro, que de Deus se excluem os conceitos de
singular e de único. Dizemos, contudo,único Filho, por não haver vários filhos em Deus; não dizemos,
porém, único Deus, por ser a divindade comum a todas as pessoas. Também devemos evitar a
palavra confundido, para não tolhermos às pessoas a ordem de natureza; donde o dizer
Ambrósio: Nem é confundido o que é uno, nem pode ser múltiplo o que não é diferente. Enfim,
devemos evitar o nome de solitário para não tolhermos o consórcio das três pessoas; assim, Hilário diz:
Não devemos ensinar que Deus é solitário nem diverso.
Ora, a palavra outro, no masculino, só importa distinção de suposto. Por isso, podemos com
conveniência dizer que o Filho é outro que não o Pai, por ser outro suposto da natureza divina, como é
outra pessoa e outra hipóstase.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Outro, sendo um nome particular, diz respeito ao
suposto, e por isso satisfaz-lhe à noção da distinção de substância, que é a hipóstase ou a pessoa. Mas
a diversidade exige a distinção substancial da essência. E, portanto, não podemos dizer que o Filho seja
diverso do Pai, embora sejaoutro.

RESPOSTA À SEGUNDA. — Diferença importa distinção formal. Ora, em Deus há uma só forma, como se
lê na Escritura (Fp 2, 6): O qual, tendo a natureza de Deus. — Por onde, não convém propriamente a
Deus o nome dediferença, como é claro pela autoridade aduzida. — Contudo, Damasceno usa do nome
de diferença, tratando das pessoas divinas, no sentido em que a propriedade relativa é significada a
modo de forma; e daí o dizer ele, que não diferem entre si as hipóstases pela substância, mas pelas
propriedades determinadas. Ao passo que a diferença é tomada no sentido de distinção, como se disse.

RESPOSTA À TERCEIRA. — Alheio é o estranho e dissemelhante. Ora, tal não dizemos quando
empregamos a palavra outro. E assim, dizemos que o Filho é outro que não o Pai, embora não digamos
que seja alheio.

RESPOSTA À QUARTA. — O gênero neutro é uniforme, ao passo que o masculino e o feminino são
formados e distintos. E por isso, pelo gênero neutro convenientemente exprimimos a essência comum;
mas, pelo masculino e pelo feminino, um suposto determinado em a natureza comum. Por isso, quando
se trata do homem, à pergunta — Quem é este? — Responde-se — Sócrates — que é nome do suposto.
Mas, à pergunta — Que coisa é este? — responde-se — animal racional e mortal. Por onde, em Deus a
distinção, sendo pessoal e não, essencial, dizemos que o Pai é outro que não o Filho, não, porém, outra
coisa; e, ao inverso, dizemos que são um, não, porém uno.

## Art. 3 — Se a locução exclusiva só deve-se acrescentar ao termo essencial, em Deus.
(I Sent., dist. XXI, q. 1, art. 1).
O terceiro discute-se assim. — Parece que não devemos acrescentar ao termo essencial, em Deus, a
locução exclusiva só.

1. — Pois, segundo o Filósofo, só é quem não está com outro. Ora, Deus está com os anjos e as almas
santas. Logo, não podemos dizer que Deus está só.

2. Demais. — Tudo o que se acrescentar ao termo essencial, em Deus, pode ser predicado de qualquer
das pessoas, em si, e de todas simultaneamente. Assim, podemos dizer com conveniência que Deus é
sábio; podemos dizer — o Padre é Deus sábio, e a Trindade é Deus sábio. Ora, Agostinho
escreve: Devemos examinar a opinião que ensina não ser só o Padre o verdadeiro Deus. Logo não se
pode dizer — só Deus.

3. Demais. — A locução só, acrescentada ao termo essencial, constituirá uma predicação pessoal ou
uma predicação essencial. Ora, pessoal não pode ser; porque a proposição só Deus é Pai é falsa, pois
também o homem pode sê-lo. Nem essencial, porque se fosse verdadeira a proposição — Só Deus cria
— sê-lo-ia também estoutra — Só o Pai cria — porque tudo o dito de Deus pode sê-lo do Pai. Ora, esta
última proposição é falsa, porque também o Filho é criador. Logo, a locução só não se pode acrescentar
ao termo essencial, em Deus.
Mas, em contrário, a Escritura (1 Tm 1, 17): Ao Rei dos séculos imortal, invisível, a Deus só.

SOLUÇÃO. — Esta locução só pode ser tomada como categoremática ou sincategoremática.
Categoremática é a locução, que atribui de modo absoluto uma realidade a um suposto, como branco,
ao homem, quando dizemos homem branco. Donde, se neste sentido tomássemos a locução só, de
nenhum modo poderia ser acrescentada a qualquer termo, em Deus; porque afirmaria a soledade
relativamente ao termo ao qual se acrescentasse; donde resultaria ser Deus solitário, o que vai contra o
que dissemos. Porém, sincategoremática é a locução, que implica uma ordenação do predicado para o
sujeito como a locução todo ou nenhum. E semelhantemente a locução só, porque exclui qualquer
outro suposto, da união com o predicado. Assim quando dizemos — Sócrates só escreve — não
queremos com isso significar que Sócrates seja solitário, mas que ninguém participa com ele do ato de
escrever, embora muitos coexistam com ele. E deste modo nada impede se acrescente a locução só, a
algum termo essencial em Deus, excluindo-se todos os outros seres de uma união predicativa com Deus;
como se disséssemos, — só Deus é eterno, pois, nada, fora dele, o é.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora os anjos e as almas santas estejam sempre com
Deus, todavia, se nele não houvesse pluralidade de pessoas, estaria só ou solitário. Pois, não exclui a
solidão o estar associado com um ser de natureza diversa; assim dizemos que alguém está só num
jardim embora nele haja muitas plantas e animais. E, de idêntica maneira, Deus estaria só e solitário,
embora estando com ele anjos e homens, se não existissem várias pessoas divinas. Logo, a sociedade
com os anjos e as almas não exclui de Deus a solidão absoluta, e muito menos a relativa, referente a um
atributo.

RESPOSTA À SEGUNDA. — A locução só, propriamente falando, não se emprega em relação ao
predicado, que é tomado formalmente; pois, diz respeito ao suposto, por excluir este, ao qual se une,
outro suposto. Mas o advérbio somente, sendo exclusivo, pode ser empregado em relação ao sujeito e
ao predicado, e assim podemos dizer — somente Sócrates corre, i. é, nenhum outro; e — Sócrates corre
somente, i. é, nada mais jaz. Por onde, não se pode propriamente dizer — o Pai só é Deus, ou a —
Trindade só é Deus; a menos que em relação ao predicado não se subentenda alguma particularidade,
como no dizer a Trindade é o Deus que só é Deus. Ora, quando Agostinho diz que não só o Pai é Deus,
mas só a Trindade o é, exprime-se expositivamente como se afirmasse: quando se diz — Ao rei dos
séculos invisível, a Deus só — esse dito não se aplica à pessoa do Pai, mas só à Trindade.

RESPOSTA À TERCEIRA. — De um outro modo a locução só pode se acrescentar ao termo essencial;
pois, duplo é o sentido da proposição — só Deus é Pai. — Porque a palavra, — Pai — pode ser predicada
da pessoa do Pai, e então a proposição é verdadeira, pois, tal pessoa não é homem. Ou pode significar a
relação somente e então é falsa, pois, a relação de paternidade também se encontra em outros seres,
embora não univocamente. Do mesmo modo, é verdadeira a proposição — só Deus cria, — mas dela se
não segue — logo, só o Pai; porque, como dizem os lógicos, a locução exclusiva imobiliza o termo ao
qual se une, de modo a se não poder descer abaixo dele, para nenhum suposto. Assim, não há
seqüência nestas duas proposições: Só o homem é um animal racional mortal; logo, só Sócrates.

## Art. 4 — Se a locução exclusiva pode ser unida ao termo pessoal, mesmo se o predicado for comum.
(I Sent., dist. XXI, q. 1, a. 2; in Matth., cap. XI).
O quarto discute-se assim. — Parece que a locução exclusiva pode se unir ao termo pessoal, mesmo se
o predicado for comum.

1. — Pois, diz o Senhor, falando ao Pai (Jo 17, 3): Para que te conheçam por um só verdadeiro Deus a ti.
Logo, só o Pai é Deus verdadeiro.

2. Demais. — Diz a Escritura (Mt 11, 27): Ninguém conheceu o Filho senão o Pai, o que é como se
dissesse: Só o Pai conheceu o Filho. Ora, ter conhecido o Filho é comum. Donde se conclui o mesmo que
antes.

3. Demais. — A locução exclusiva não exclui aquilo que pertence à noção do termo ao qual se une; e
portanto, não lhe exclui a parte nem o todo. Assim, não há seqüência nestas proposições: Sócrates só é
branco; — logo, a sua mão não é branca; ou logo, o homem não é branco. Ora, uma pessoa está
compreendida na noção de outra, como o Pai, na do Filho e reciprocamente. Portanto, o dizer-se que só
o pai é Deus não exclui o Filho ou o Espírito Santo. Donde se conclui que essa locução é verdadeira.

4. Demais. — Canta a Igreja: Tu só és altíssimo, Jesus Cristo.
Mas, em contrário. — A locução — Só o Pai é Deus — comporta duas interpretações, a saber: O Pai é
Deus — e — Nenhum outro senão o Pai é Deus. Ora, esta última é falsa, pois, o Filho é outro que não o
Pai e é Deus; logo, também estoutra é falsa: Só o Pai é Deus. E assim, em casos semelhantes.

SOLUÇÃO. — Quando dizemos — Só o Pai é Deus — esta proposição pode ter sentido múltiplo. Assim,
significando só a soledade em relação ao Pai, é falsa, pois é tomada em sentido categoremático. Mas, se
for tomada em sentido sincategoremático, de novo pode ter sentido múltiplo. Se implicar alguma
exclusão da forma do sujeito, então é verdadeira e o sentido de — só o Pai é Deus — é: Aquele com o
qual nenhum outro é Pai, é Deus. E neste sentido expõe Agostinho: Dizemos que o Pai é só, não que
esteja separado do Filho ou do Espírito Santo; mas, assim dizendo, queremos significar que, existindo
simultaneamente com ele, não são o Pai. Mas este sentido não resulta do modo habitual de falar, sem
se subentender alguma outra proposição como esta:Aquele que só é chamado Pai, é Deus. Pois, no seu
sentido próprio, a locução exclusiva repele qualquer união com o predicado. Assim que, a proposição é
falsa se exclui outro, no masculino; é porém, verdadeira se exclui somente outra causa, no neutro; pois,
o Filho é outro que não o Pai, não porém outra causa; e semelhantemente o Espírito Santo.
Mas, a locução só, dizendo respeito propriamente ao sujeito, como vimos, mais se emprega para excluir
outro que outra coisa. Por onde, tal locução não a devemos aplicar extensivamente, mas, explicá-la
como for encontrada em escritura autêntica.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dito — um só verdadeiro Deus a ti — não se entende
da pessoa do Pai, mas, de toda a Trindade, como expõe Agostinho. Ou se se entender da pessoa do Pai,
não se excluem as outras pessoas por causa da unidade de essência; pois, só exclui apenas outra coisa,
como dissemos.
E semelhante é a RESPOSTA À SEGUNDA. — Pois, quando dizemos do Pai algo de essencial, não
excluímos o Filho ou o Espírito Santo, por causa da unidade de essência. Por onde, devemos saber que,
no lugar citado, a expressão ninguém não é, conforme à significação desse vocábulo, o mesmo que
nenhum homem, pois, não poderíamos exceptuar a pessoa do Pai. Mas essa palavra é tomada no
sentido usual, distributivamente, para significar qualquer natureza racional.

RESPOSTA À TERCEIRA. — A locução exclusiva não exclui o que pertence à noção do termo ao qual está
unida, se não diferem pelo suposto, como a parte e o todo. Ora, o Filho difere do Pai, pelo suposto; e
portanto, a razão não é a mesma.

RESPOSTA À QUARTA. — Não dizemos, em sentido absoluto, que só o Filho seja altíssimo; mas, que só é
altíssimo com o Espírito Santo, na glória de Deus Padre.