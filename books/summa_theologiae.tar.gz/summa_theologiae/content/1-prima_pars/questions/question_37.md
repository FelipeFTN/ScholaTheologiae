# Questão 37: Do amor, nome do Espírito Santo.
Em seguida, vamos tratar do nome de Amor. E nesta questão discutem-se dois artigos:

## Art. 1 — Se Amor é o nome próprio do Espírito Santo.
(I Sent., dist. X, a. 1, ad 4; dist. XXVII, q. 2, a. 2, qª 2).
O primeiro discute-se assim. – Parece não é Amor o nome próprio do Espírito Santo.

1. – Pois, Agostinho diz: Não sei porque, assim como o Pai, o Filho e o Espírito Santo se chamam
sabedoria, constituindo simultaneamente, não três, mas uma só sabedoria, assim Pai, o Filho, o Espírito
Santo, constituindo todos simultaneamente uma caridade só. Ora, nenhum nome, que se predique de
cada Pessoa e de todas, em comum, singularmente, é nome próprio de qualquer das Pessoas. Logo, o
nome do Amor não é o próprio do Espírito Santo.

2. Demais. – O Espírito Santo é uma pessoa subsistente. Ora, Amor não significa uma pessoa
subsistente, mas uma ação transeunte do amante para o amado. Logo, Amor não é o nome próprio do
Espírito Santo.

3. Demais. –O amor é o nexo dos amantes; pois, segundo Dionísio, é uma força unitiva. Mas, o nexo é o
meio, entre as coisas conexas, e não algo delas procedente. Ora, o Espírito Santo procedendo do Pai e
do Filho, como já se demonstrou, parece que não seja amor nem nexo entre o Pai e o Filho.

4. Demais. – Todo amante tem algum amor. Ora, o Espírito Santo é amante. Logo, tem algum amor. Se
pois o Espírito Santo é amor, amor será do amor e espírito, do espírito, o que é inadmissível.
Mas, em contrário, diz Gregório: O próprio Espírito Santo é Amor.

SOLUÇÃO. –O nome de amor, em Deus, pode ser tomado em sentido essencial e pessoalmente.
Pessoalmente, é o nome próprio do Espírito Santo, como o Verbo é o do filho. Para evidenciá-lo,
devemos considerar o seguinte. Em Deus, como já se demonstrou, há duas processões, uma intelectual,
que é a do Verbo; outra, pela vontade, que é a do amor. Como porém a primeira nos é mais conhecida,
encontraram-se nomes mais apropriados para exprimir os conceitos a ela referentes, o que não se dá
com a processão da vontade. Daí o usarmos de certos circunlóquios para significar a Pessoa assim
procedente. E o darmos também os nomes deprocessão e espiração, como já dissemos, às relações
derivadas desta processão; significando porém esses nomes, quanto a propriedade, mais a origem que a
relação. E contudo ambas essas processões podem ser consideradas do mesmo modo. Pois assim como
em quem intelige está uma certa concepção intelectual da coisa intelegida, que se chama verbo; assim
também, quem ama alguma coisa recebe, no seu afeto, uma por assim dizer impressão da coisa amada,
que nos leva a dizer que ela está no amante como a coisa inteligida, no inteligente. De modo que quem
se intelige e se ama a si mesmo está, não só por identidade de ser, mas ainda como o inteligido, no
inteligente e o amado, no amante.
Mas, quanto ao intelecto, há vocábulos apropriados a significar a relação do inteligente com a coisa
inteligida, como é claro quando digo inteligir. E também outros vocábulos significam o processo da
concepção intelectual, como, dizer e verbo. Por onde, de Deus, o inteligir se predica só essencialmente,
por não importar relação com o verbo procedente. Verbo, porém, significando o que procede, dele se
predica pessoalmente; e, enfim, dizer, importando relação do princípio do Verbo com o Verbo mesmo,
se predica nocionalmente.
Quanto à vontade, porém, além das expressões – ter dileção e amar, que importam relação do amante
com a coisa amada, não há outras, que exprimam a relação entre a impressão mesma ou o afeto da
coisa amada – que nasce no amante, quando ama – e o seu princípio, ou inversamente. E assim, por
inópia de vocábulos, exprimimos essas relações pelas palavras – amor e dileção, como se
denominássemos o Verbo – inteligência concebida, ou sabedoria gerada.
Portanto, o amor ou a dileção, enquanto só implicam relação entre o amante e a coisa amada,
predicam-se essencialmente, como inteligência e inteligir. Se usarmos porém desses vocábulos para
exprimirmos a relação entre o que procede por amor e o seu princípio, e inversamente, de maneira que,
por amor, entendamos espirar o amor procedente; nesse caso, Amor é nome de Pessoa; e – ter
dileção ou amar – é verbo nocional, como –dizer ou gerar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –Agostinho fala da caridade, entendida de Deus
essencialmente, como se disse.

RESPOSTA À SEGUNDA. –Embora, inteligir, querer e amar exprimam ações transeuntes para um objeto,
todavia são ações imanentes no agente, como dissemos; mas de modo que importam, no próprio
agente, certa relação com o objeto. Por onde, o amor, mesmo em nós, é algo de imanente, e é verbo
mental imanente em quem o diz; mas relativo à coisa verbalmente expressa, ou amada. Mas em Deus,
no qual não há acidente algum, há algo maior, porque tanto o Verbo como o Amor são subsistentes.
Quando pois dizemos, que o Espírito Santo é o amor do Pai para com o Filho ou para com qualquer
outro ser, não dizemos que seja algo de transeunte para outro, mas assim exprimimos somente a
relação do amor com a coisa amada, assim como, no Verbo, exprimimos a sua relação com a realidade
que ele exprime.

RESPOSTA À TERCEIRA. –O Espírito Santo se chama nexo entre o Pai e o Filho, enquanto amor; pois o
amor do Pai por si mesmo e pelo Filho, sendo uma única dileção, e inversamente, implica em ser o
Espírito Santo, como Amor, uma relação recíproca entre o Pai e o Filho, que une quem ama a quem é
amado. Ora, pelo fato de que o Pai e o Filho mutuamente se amam, é necessário que de ambos proceda
o Espírito Santo, que é o mútuo Amor. Segundo pois a sua origem, o Espírito Santo não é o meio, mas a
terceira pessoa da Trindade; mas segundo o estado predito, é o nexo médio das duas de que procede.

RESPOSTA À QUARTA. – Ao Filho, embora intelija, não lhe cabe produzir o Verbo, porque inteligir lhe
convém como Verbo procedente. Assim, também embora o Espírito Santo ame, essencialmente falando,
todavia não lhe cabe espirar o amor, o que seria amar em sentido nocional; pois, ama essencialmente
como Amor procedente, e não como princípio donde procede o amor.

## Art. 2 — Se o Pai e o Filho amam-se pelo Espírito Santo.
(I Sent., dist. XXXII, q. 1; De Pot., q. 9, a. 9 ad 13).
O segundo discute-se assim. – Parece que o Pai e o Filho não se amam pelo Espírito Santo.

1. – Pois, Agostinho prova que o Pai não é sábio por sabedoria gerada. Ora, como o Filho é sabedoria
gerada, assim o Espírito Santo é Amor procedente, como já se disse. Logo, o Pai e o Filho não se amam
pelo Amor procedente, que é o Espírito Santo.

2. Demais. – Quando se diz – o Pai e o Filho se amam pelo Espírito Santo – o verbo amar é tomado em
sentido essencial ou nocional. Ora, tal proposição não pode ser verdadeira se for o verbo tomado
essencialmente, porque então, por idêntica razão, poderíamos dizer, que – o Pai intelige pelo Filho. Nem
se for tomado nocionalmente pois, ainda pela mesma razão, poderíamos dizer, que – o Pai e o Filho
espiram pelo Espírito Santo – ou que – o Pai gera pelo Filho. Logo, de nenhum modo esta proposição é
verdadeira – o Pai e o Filho amam-se pelo Espírito Santo.

3. Demais. – Pelo mesmo amor o Pai ama ao Filho, a si e a nós. Ora, ele não se ama pelo Espírito Santo,
pois nenhum ato nocional se reflete sobre o princípio desse ato; assim não se pode dizer, que o Pai se
gera ou se espira. Logo, também não se pode dizer que se ama pelo Espírito Santo, tomado amar em
sentido nocional. Demais, o amor com o qual nos ama não é o Espírito Santo, porque, importando
relação com a criatura, pertence à essência. Logo, também é falsa a proposição – o Pai ama ao Filho pelo
Espírito Santo.
Mas, em contrário, diz Agostinho, que pelo Espírito Santo é que o Gerado é amado do Gerador, e ama
ao seu Gerador.

SOLUÇÃO. – Quando se diz – o Pai ama ao Filho pelo Espírito Santo – causa dificuldade o emprego do
ablativo causal, parecendo que o Espírito Santo é o princípio de se amarem o Pai e o Filho, o que é
absolutamente impossível. Por isso certos consideram falsa a proposição – o Pai e o Filho amam-se pelo
Espírito Santo. E dizem, que Agostinho a retratou quando retratou a sua semelhante – o Pai é sábio por
sabedoria gerada. – Outros porém a consideram como proposição imprópria e dizem que deve ser
entendida: o Pai ama o Filho pelo Espírito Santo, i. é, pelo amor essencial, próprio do Espírito Santo. –
Outros ainda disseram que o ablativo, no caso vertente, exprime um sinal, sendo o sentido – o Espírito
Santo é sinal de que o Pai ama o Filho – deste procedendo aquele como Amor. – Ainda outros
consideraram o ablativo como significando causa formal; pois, o Espírito Santo é o amor pelo qual o Pai
e o Filho formalmente entre si se amam. – E outros, enfim, consideraram o ablativo como exprimindo
um efeito formal. E estes são os que mais se aproximaram da verdade.
Ora, para evidenciar a questão devemos saber que, denominando-se as coisas comumente pelas sua
formas – p. ex., o branco, pela brancura, o homem, pela humanidade – tudo aquilo que for causa da
denominação de uma coisa está para com ela na relação de causa formal. Assim, dizendo – tal pessoa
está vestida pela sua vestimenta, este ablativo, embora não seja formal, exerce a função de causa
formal. Ora, uma coisa pode ser denominada pelo que dela procede; não só como o agente, pela ação,
mais ainda pelo termo mesmo da ação, que é o efeito, quando este se inclui no conceito da ação. Assim
dizemos que o fogo aquece pela calefação, embora esta não seja calor, que é forma do fogo, mas ação
procedente do fogo; e dizemos que a árvore está florida pelas flores, embora estas não sejam a forma
daquela, mas efeitos procedentes. E por isso devemos dizer, que amar, em Deus, tendo duas acepções,
a essencial e a nocional, na essencial o Pai e o Filho não se amam pelo Espírito Santo, mas, pela sua
essência. Donde o dizer Agostinho: Quem ousará afirmar que o Pai não se ama a si mesmo, ao Filho e ao
Espírito Santo, sem ser pelo Espírito Santo? E neste sentido são procedentes as primeiras opiniões.
Porém, nocionalmente falando, amar não é senão espirar o amor, como dizer é produzir o verbo, e
florir, produzir flores. Pois, assim como dizemos que a árvore está florida, pelas flores, também dizemos
que o Pai é dicente de si e da criatura, pelo Verbo ou pelo Filho; e que o Pai e o Filho se amam a si e a
nós pelo Espírito Santo ou pelo Amor procedente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Dizemos que Deus é sábio ou inteligente só em sentido
essencial; e por isso não podemos dizer que o Pai é sábio ou inteligente, pelo Filho. Mas amar dele
predicamos não só essencial, mais ainda nocionalmente. E, então podemos afirmar que o Pai e o Filho
se amam pelo Espírito Santo, como dissemos.

RESPOSTA À SEGUNDA. – Quando o conceito de uma ação importa um efeito determinado, o princípio
da ação pode receber a sua denominação da ação e do efeito; assim, podemos dizer que a árvore está
florida pelo florescimento e pelas flores. Mas, quando não importa um efeito determinado, então o
princípio da ação não pode ser denominado pelo efeito, mas só por ela; assim, não dizemos que a
árvore produz a flor pela flor, mas, pela produção da flor. Ora, quando digo espira ou gera isso importa
somente um ato nocional; e daí o não podermos dizer que o Pai espira pelo Espírito Santo, ou gera pelo
Filho. Mas podemos afirmar que o Pai diz pelo Verbo, como por Pessoa procedente, e diz por dicção,
como por ato nocional, porque dizer importa uma determinada pessoa procedente, pois, é produzir o
verbo. E semelhantemente, amar, em sentido nocional, é produzir o amor. Portanto, podemos dizer que
o Pai ama ao Filho pelo Espírito Santo, como por Pessoa procedente; e pela própria dileção, como por
ato nocional.

RESPOSTA À TERCEIRA. – O Pai ama pelo Espírito Santo não só o Filho mas também a si mesmo e a nós.
Pois, como acaba de ser dito, amar, nocionalmente, não só importa produção de Pessoa divina, mas
ainda, a Pessoa produzida pelo amor, a qual tem relação com a coisa dileta. Por onde, assim como o Pai
se diz a si e a toda criatura; assim, ama-se a si e a toda criatura, pelo Verbo que gerou, enquanto o
Verbo gerado suficientemente representa o Pai e toda criatura; assim, ama-se a si e a toda criatura pelo
Espírito Santo, enquanto este procede, como amor, da bondade primeira, pela qual o Pai ama a si e a
toda criatura. E assim também é claro, que o Verbo e o Amor procedente importam relação com a
criatura, como secundariamente, enquanto a verdade e a bondade divina é princípio de inteligir e de
amar toda criatura.