# Questão 30: Da pluralidade das pessoas em Deus
Em seguida se trata da pluralidade das pessoas. E nesta questão discutem-se quatro artigos:

## Art. 1 — Se se devem admitir várias pessoas em Deus.
(I Sent., dist. II, 4; dist. XXIII, a. 4; De Pot., q. 9, a. 5; Compend, Theol., cap. L, LV; Quold. VII, q. 3, a. 1).
O primeiro discute-se assim. — Parece que não se devem admitir várias pessoas em Deus.

1. — Pois, pessoa é uma substância individual de natureza racional. Ora, se em Deus há várias pessoas,
segue-se que há várias substâncias, o que é herético.

2. Demais. — A pluralidade das propriedades absolutas não gera distinção de pessoas, nem em Deus
nem em nós. Logo, com muito maior razão, a pluralidade de relações. Ora, em Deus não há outra
pluralidade além da das relações, como antes se disse. Logo, não se pode dizer que há em Deus várias
pessoas.

3. Demais. — Boécio, falando de Deus diz que é verdadeiramente uno o que não é susceptível de
número nenhum. Ora, a pluralidade implica o número. Logo, não há várias pessoas em Deus.

4. Demais. — Onde quer que haja número, aí haverá todo e parte. Ora, se em Deus há número de
pessoas, será preciso nele introduzir o todo e a parte, o que repugna à divina simplicidade.
Mas, em contrário, Atanásio: Uma é a pessoa do Padre, outra a do Filho, outra a do Espírito Santo. Logo,
Padre, Filho e Espírito Santo são várias pessoas.

SOLUÇÃO. — Do que já estabelecemos, resulta haver em Deus várias pessoas. Pois, foi demonstrado
que o nome de pessoa significa, em Deus, relação, como realidade subsistente na divina natureza. Ora,
já provamosque há várias relações reais em Deus. Donde se segue a existência de várias realidades
subsistentes na divina natureza, e isto é o mesmo que existirem nela várias pessoas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na definição da pessoa não se introduz a substância
como significando essência, mas como suposto; o que é manifesto por se lhe acrescentar individual. E
para exprimir a substância, com tal significação, os Gregos têm o nome de hipóstase; por isso, como nós
dizemos três pessoas, dizem eles três hipóstases. Nós, porém, não nos acostumamos a dizer três
substâncias para se não entenderem três essências, por causa da equivocação do nome.

RESPOSTA À SEGUNDA. — As propriedades absolutas em Deus, como a bondade e a sapiência,
mutuamente se não opõem e por isso nem realmente se distinguem. Embora, pois, lhes convenha o
subsistir, não são por isso três realidades subsistentes, por onde seriam várias pessoas. Mas, nas coisas
criadas, as propriedades absolutas, como a brancura e a doçura, não subsistem, embora realmente
entre si se distingam. Em Deus, porém, as propriedades relativas subsistem, e realmente se distinguem
umas das outras, como antes se disse. Donde, a pluralidade de tais propriedades basta para causar a das
pessoas divinas.

RESPOSTA À TERCEIRA. — A suma unidade e simplicidade de Deus excluem toda a pluralidade das
atribuições absolutas; não porém a das relações. Porque estas se predicam de uma coisa
dependentemente de outra, e assim não importam composição na coisa a que se atribuem, como
ensina Boécio no mesmo livro.

RESPOSTA À QUARTA. — Há duas sortes de número: o simples ou absoluto, como dois, três, quatro; e o
existente nas coisas numeradas, como dois homens e dois cavalos. Se, pois, considerarmos o número
absoluta ou abstratamente, nada impede existir em Deus todo e parte; mas isto só se dá na acepção do
nosso intelecto, pois só neste existe o número absoluto, separado das coisas numeradas. Se, porém,
considerarmos o número enquanto nestes existente, então, no mundo das criaturas, um é parte de dois,
e dois, de três; e um homem, de dois, e dois, de três. Mas em Deus não é assim porque tanto é o Pai
quanto toda a Trindade, como a seguir se demonstrará.

## Art. 2 — Se em Deus há mais de três pessoas.
(I Sent., dist. X, a. 5; dist. XXXIII, a. 2. ad 1; IV. Cont. Gent., cap. XXVI; De Pot., q. 9, a. 9; Compend.
Theol., cap. LVI. LX).
O segundo discute-se assim. — Parece que há em Deus mais de três pessoas.

1. — Pois, a pluralidade das pessoas divinas se funda na das propriedades relativas, como se disse. Ora,
há quatro relações em Deus, segundo se disse, a saber, a paternidade, a filiação, a espiração comum e a
processão. Logo, há em Deus quatro pessoas.

2. Demais. — Não há em Deus maior diferença entre a natureza e a vontade que entre a natureza e o
intelecto. Ora, uma é a pessoa divina procedente ao modo da vontade, como amor; outra ao modo da
natureza, como filho. Logo, há também outra procedente ao modo do intelecto, como verbo; e outra
procedente ao modo da natureza, como filho. E assim, de novo resulta que não há somente três pessoas
em Deus.

3. Demais. — Das criaturas as mais excelentes são dotadas de várias operações intrínsecas; p. ex., o
homem é dotado, a mais que os outros animais, do inteligir e do querer. Ora, Deus infinitamente excede
toda a natureza. Logo, há nele a pessoa procedente, não somente como vontade e intelecto, mas, de
infinitos outros modos. Logo, são infinitas as pessoas divinas.

4. Demais. — Pela sua infinita bondade é que o Padre comunica-se infinitamente a si próprio,
produzindo uma pessoa divina. Ora, também o Espírito Santo tem infinita bondade. Logo, o Espírito
Santo também produz uma pessoa divina; e esta por sua vez outra, e assim ao infinito.

5. Demais. — Tudo o que contém um determinado número é medido, pois o número é uma medida.
Ora, as pessoas divinas são imensas, como está claro em Atanásio: imenso o pai, imenso o Filho, imenso
o Espírito Santo. Logo, não estão contidas com número ternário.
Mas, em contrário, a Escritura (1 Jo 5, 7): Três são os que dão testemunho no céu: o Pai, o Verbo e o
Espírito Santo. E aos que perguntarem — Que três? — responde-se — As Três pessoas, como diz
Agostinho. Logo, há só três pessoas divinas.

SOLUÇÃO. — Segundo já dissemos, é necessário admitir em Deus somente três pessoas. Pois, como
demonstramos, várias pessoas supõem várias relações subsistentes entre si realmente distintas. Ora, a
distinção real entre as relações divinas só existe em razão da oposição relativa. Logo, duas relações
opostas pertencem necessariamente a duas pessoas; e as relações que não forem opostas forçosamente
pertencerão à mesma pessoa. Por onde, a paternidade e a filiação, sendo relações opostas, necessaria-
mente hão de pertencer a duas pessoas. E assim, a paternidade subsistente é a pessoa do Pai, e a
filiação subsistente a pessoa do Filho. Quanto às outras duas relações, elas não se opõem a nenhuma
destas, mas se opõem entre si; é impossível, portanto, convirem ambas a uma mesma pessoa. Logo, e
necessariamente, uma delas convirá a ambas as referidas pessoas, ou uma convirá a uma pessoa e a
outra, a outra. Mas não pode a processão convir ao Pai e ao Filho, ou a um deles; porque do contrário a
processão do intelecto, que é a geração em Deus, e na qual se fundam a paternidade e a filiação,
nasceria da processão do amor, na qual se fundam a espiração e a processão, se a pessoa geradora e a
gerada procedessem da espirante — o que vai contra o já estabelecido. Donde se conclui que a
espiração convém à pessoa do Pai e à do Filho, por não ter nenhuma oposição relativa nem com a
paternidade nem com a filiação. E por conseguinte há de necessariamente convir a processão à outra
pessoa, chamada pessoa do Espírito Santo, procedente como amor, conforme estabelecemos. Logo há
somente três pessoas em Deus, a saber, o Pai, o Filho e o Espírito Santo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora haja em Deus quatro relações, contudo uma
delas, a espiração, não se separa da pessoa do Pai e do Filho, mas a ambas convém. E assim, embora
seja relação, não se chama contudo propriedade, por não convir a uma pessoa apenas; nem é
relação pessoal, i. é., constitutiva da pessoa. Mas estas três relações — a paternidade, a filiação e a
processão — chamam-se propriedades pessoais, sendo como pessoas constituintes; pois, a paternidade
é a pessoa do Pai, a filiação a do Filho, e a processão a do Espírito Santo procedente.

RESPOSTA À SEGUNDA. — O que procede a modo de intelecto, como o verbo, procede pela razão de
semelhança, como também o que procede ao modo de natureza; e por isso se disse antes que a
processão do Verbo é a geração mesma, ao modo da natureza. Porém o Amor, como tal, não procede
como semelhança daquilo donde procede, embora em Deus o Amor seja co-essencial, enquanto divino;
logo, a processão do Amor não se chama geração, em Deus.

RESPOSTA À TERCEIRA. — O homem, mais perfeito que os outros animais, é dotado de mais operações
intrínsecas que eles, porque a sua perfeição é a modo de composição. E por isso os anjos, mais perfeitos
e mais simples, têm menos operações intrínsecas que o homem, não havendo neles o imaginar, o sentir
e faculdades semelhantes. Mas, em Deus, por natureza, só há uma operação que é a sua essência. E
como há nele duas processões, já o demonstramos.

RESPOSTA À QUARTA. — A objeção procederia se o Espírito Santo tivesse uma bondade
numericamente diferente da do Pai; pois então seria necessário que, assim como o Pai, pela sua
bondade, produz uma pessoa divina, assim também o Espírito Santo. Mas uma mesma é a bondade do
Pai e a do Espírito Santo; e só se distinguem pelas relações das pessoas. Por onde, a bondade convém ao
Espírito Santo, como recebida de outrem; porém ao Pai, como de quem se comunica a outrem. Mas a
oposição de relação não permite que com a relação do Espírito Santo co-exista a relação de princípio
respeitante à divina pessoa; pois ele procede das outras pessoas que em Deus podem existir.

RESPOSTA À QUINTA. — O número determinado se mede pela unidade, considerando-se um número
simples, que só existe na acepção do intelecto. Se porém se considerar nas pessoas divinas, o número
expressivo de realidades, então elas são incompatíveis com a de medida, pois a mesma é a grandeza das
três pessoas, como a seguir se verá. Ora, nenhum ser se mede por si mesmo.

## Art. 3 — Se os termos numerais introduzem alguma realidade em Deus.
(I Sent., dist. XXIV, a. 3; De Pot., q. 9, a. 7; Quodl. X, q. 1, a. 1).
O terceiro discute-se assim. — Parece que os termos numerais introduzem alguma realidade em Deus.

1. — Pois, a unidade divina é a sua essência. Ora, todo número é a unidade repetida. Logo, todo termo
numeral, significando em Deus a essência, nele introduz alguma realidade.

2. Demais. — Tudo o que se diz de Deus e das criaturas, mais eminentemente convém àquele que a
estas. Ora, os termos numerais introduzem uma realidade nas criaturas. Logo, muito mais em Deus.

3. Demais. — Se os termos numerais não introduzem nenhuma realidade em Deus, mas se empregam
somente para remover, removendo-se assim a unidade pela pluralidade, e por esta, aquela, resulta um
círculo para a razão, causa de confusão para o intelecto e que a nenhuma certeza conduz, o que é
inconveniente. Donde se conclui que os termos numerais introduzem alguma realidade em Deus.
Mas, em contrário, diz Hilário: O estado de consórcio, que é estado de pluralidade, tira a inteligência da
singularidade e da solidão. E Ambrósio: Quando dizemos que Deus é um, a unidade exclui a pluralidade
de deuses, sem nele introduzir a quantidade. Por onde se vê, que tais nomes se empregam para
remover e não para introduzir nenhuma realidade em Deus.

SOLUÇÃO. — O Mestre das Sentenças ensina, que os termos numerais nada introduzem em Deus, mas
somente removem. Outros, porém, dizem o contrário. Mas para esclarecer esta questão devemos
considerar, que toda pluralidade resulta de alguma divisão. E esta pode ser de duas espécies. Uma é a
material, resultante da divisão do contínuo, e da qual provém o número, espécie de quantidade; e por
isso tal número só é próprio às coisas materiais susceptíveis de quantidade. Outra é a divisão formal,
que se faz por formas opostas ou diversas, e da qual resulta a multidão, que não se compreende em
nenhum gênero, mas pertence aos transcendentais, que dividem o ser em unidade e multiplicidade. E
tal multidão só pode existir nos seres imateriais.
Alguns, pois, só considerando a multidão, espécie da quantidade discreta, e vendo que esta não existe
em Deus, ensinaram, que os termos numerais nada introduzem em Deus mas somente dele removem.
— Outros, porém, considerando a mesma multidão, ensinaram, que assim como existe em Deus a
ciência, na sua noção própria e não só na sua noção genérica, pois em Deus nenhuma qualidade existe;
assim também o número existe em Deus na sua noção própria e não na sua noção genérica, que é a
quantidade.
Nós, porém, dizemos que os termos numerais, quando predicados de Deus, não provém do número
enquanto espécie de quantidade, porque então só se atribuíram a Deus metaforicamente, à semelhança
das outras propriedades corporais, como a latitude, a longitude e semelhantes; mas provém da
multidão enquanto transcendental. Ora, a multidão assim compreendida está para os seres múltiplos,
dos quais se predica, como a unidade conversível com o ser, para o ser. Ora, tal unidade, como
dissemos, ao tratarmos da unidade de Deus, nada mais acrescenta ao ser do que a negação da divisão,
pois uno significa o ser indiviso. E assim, dito de qualquer ser, uno o significa enquanto indiviso; p. ex.,
dito do homem significa-lhe a natureza ou a substância não dividida. E, pela mesma razão, quando
dizemos de certas coisas, que são múltiplas, a multidão assim compreendida as significa com indivisão
no tocante a cada uma delas. — Ao passo que o número, espécie de quantidade, acrescenta um
acidente ao ser; bem como a unidade, princípio do número. Logo, os termos numerais significam, em
Deus, as realidades das quais se predicam, e, além disto, nada mais acrescentam senão a negação, como
se disse; e, neste ponto, o Mestre das Sentenças ensinou a verdade. Assim, quando dizemos — A
essência é una — uno significa a essência indivisa; quando dizemos — A pessoa é una — significa a
pessoa indivisa; quando dizemos — As pessoas são várias — exprimimos tais pessoas com a indivisão
que cabe a cada uma delas, pois é da natureza da multidão constar de unidades.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A unidade sendo um transcendental, é mais geral que a
substância e a relação; e o mesmo se dá com a multidão. Donde o poderem existir, em Deus, em lugar
delas, na medida conveniente ao sujeito a que forem unidas. E contudo tais nomes, em virtude da
significação própria, acrescentam à essência ou à relação uma certa negação de divisão, como se disse.

RESPOSTA À SEGUNDA. — A multidão, que introduz uma realidade nas coisas criadas, é uma espécie de
quantidade e se não aplica à divina predicação; senão somente a multidão transcendental, que às coisas
das quais se predica nada mais acrescenta, salvo a indivisão de cada uma delas. E é essa a multidão, que
se predica de Deus.

RESPOSTA À TERCEIRA. — A unidade não remove a multidão mas, a divisão, que tem prioridade racional
sobre esta e aquela. A multidão porém remove, não a unidade, mas a divisão relativa a cada uma das
coisas das quais ela consta. E isto já antes expusemos quando tratamos da unidade divina.
E devemos também saber, que as autoridades aduzidas, em sentido oposto, não provam
suficientemente a tese. Pois embora a pluralidade exclua a solidão; e a unidade, a pluralidade dos
deuses, todavia dai se não segue seja apenas essa a significação de tais nomes. Assim, a brancura,
embora exclua a negrura, contudo não exprime somente essa exclusão.

## Art. 4 — Se o nome de pessoa pode ser comum às três pessoas.
(Sent., dist. XXV a. 3; De Pot., q. 8, a. 3, ad 11).
O quarto discute-se assim. — Parece que o nome de pessoas não pode ser comum às três pessoas.

1. – Pois, às três pessoas só a essência é comum. Ora, o nome de pessoa não significa diretamente a
essência. Logo, não é comum às três.

2. Demais. — O comum se opõe ao incomunicável. Ora, por essência a pessoa é incomunicável, como
resulta claro da definição de Ricardo de S. Vitor supra mencionada. Logo, o nome de pessoa não é
comum às três.

3. Demais. — Se fosse comum as três, essa comunidade considerar-se-ia do ponto de vista real ou
racional. Ora, do ponto de vista real, não, porque nesse caso as três pessoas seriam uma só. Nem
também do ponto de vista racional só, porque então a pessoa seria um universal. Ora, já se
demonstrou que em Deus não existe universal nem particular, gênero nem espécie. Logo, o nome de
pessoa não é comum às três.
Mas, em contrário, Agostinho diz que, quando se pergunta — Que três? — a resposta é — As Três
pessoas — por lhes ser comum o que constitui a essência da pessoa.

SOLUÇÃO. — O próprio modo de falar mostra que, quando dizemos três pessoas as três é comum o
nome de pessoa do mesmo modo que, dizendo três homens, queremos exprimir que homem é comum
aos três. Ora, é claro que não há comunidade real, como se uma essência fosse comum às três, pois, daí
haveria de seguir-se que, sendo uma a essência, uma só seriam as três pessoas.
Mas, os que inquiriram a questão de saber qual seja essa comunidade, deram-lhe soluções diversas. —
Assim uns disseram, que é a comunidade de negação, por se introduzir, na definição de pessoa, a
palavra incomunicável. — Outros porém ensinaram, que é a de intenção, por se pôr na definição a
palavra indivíduo, como se se dissesse que ser uma espécie é comum ao cavalo e ao boi. — Mas ambas
estas opiniões se excluem por não ser o nome de pessoa nome de negação, nem de intenção, mas de
realidade.
E portanto devemos dizer que, mesmo em se tratando do homem, o nome de pessoa é comum por uma
comunidade de razão, não como gênero ou espécie, mas como individuo indeterminado. Pois, os nomes
genéricos ou específicos, como homem ou animal, são empregados para significar as próprias naturezas
comuns, não porém as intenções delas, expressas pelos nomes de gênero ou de espécie. Mas o
indivíduo indeterminado, como algum homem, significa a natureza comum com um certo modo de
existir próprio ao ser particular que é por si subsistente e distinto dos outros. Ao passo que o nome de
um ser, enquanto expressivo de uma designação singular, significa uma determinação distintiva; assim,
o nome de Sócrates exprime tais carnes e tais ossos. Mas, entre o nome indeterminado e o de pessoa há
a diferença seguinte: aquele significa uma natureza ou um indivíduo natural, com um modo de existir
próprio dos seres singulares; ao passo que este é empregado não para exprimir o indivíduo natural, mas
uma realidade subsistente numa determinada natureza. Pois, é comum racionalmente a todas as
pessoas divinas, que cada uma delas subsista distinta das outras, em a natureza divina. E assim o nome
de pessoa, racionalmente considerado, é comum às três pessoas divinas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procede quanto à comunidade real.

RESPOSTA À SEGUNDA. — Embora a pessoa seja incomunicável, contudo o modo mesmo de existir
incomunicável pode ser comum a muitas.

RESPOSTA À TERCEIRA. — Embora haja em Deus comunidade racional e não real, daí se não segue haja
em Deus universal ou particular, gênero ou espécie. Quer porque, tratando-se do homem, nem a
comunidade de pessoa é a do gênero ou da espécie; quer porque as pessoas divinas têm uma mesma
essência, ao passo que o gênero e a espécie, como qualquer universal, se predicam de vários sujeitos,
essencialmente diferentes.