# Questão 116: Se há fado.
Em seguida deve-se tratar do fado.
E sobre esta questão, quatro artigos se discutem:

## Art. 1 — Se há fado.
(III Cont. Gent., cap. XCIII; Compend. Theol., cap. CXXXVIII; Quodl. XII, q. 3, a. 2; Opusc. XXVIII, De Fato,
cap. I; In Matth., cap. II; I Perihem., Iect. XIV; VI Metaphys., lect. III).
O primeiro discute-se assim. — Parece que não há fado.

1. — Pois, diz Gregório: Esteja longe da mente dos fieis dizer que há fado.

2. — Coisas acontecidas por fado não são improvisadas, pois, como diz Agostinho, compreendemos o
fado como originado de dizer, isto é, falar; de modo que se considera acontecido por fado aquilo que é
de antemão e determinadamente falado por alguém. Ora o que é previsto não é fortuito nem casual. Se
pois há coisas fatais, fica excluído o acaso e a fortuna, das coisas.
Mas, em contrario. — O que não existe não tem definição. Ora, Boécio define o fado assim: o fado é
uma disposição inerente às coisas móveis, pela qual a Providência sujeita tudo às suas ordens. Logo, o
fado existe.

SOLUÇÃO. — Vemos que na ordem das coisas inferiores, certas acontecem por fortuna ou acaso. Ora, às
vezes, uma coisa, relativamente às causas inferiores, é fortuita ou casual, e relativamente a uma causa
superior, é intencional. Assim, se dois servos do mesmo senhor forem mandados para o mesmo lugar,
sem que um saiba do outro, o encontro deles, a eles mesmos relativo, é casual, porque se dá fora da
intenção de ambos; relativamente porém ao senhor, que tal predeterminou, não é casual, mas
intencional.
Ora, certos não querem reduzir a nenhuma causa superior o casual e fortuito nas coisas inferiores deste
mundo. E estes negam o fado e a Providência, como, de Túlio, refere Agostinho. O que é contrário ao
que já se disse, da Providência.
Outros porém pretendem reduzir a uma causa superior, que são os corpos celestes, todo o fortuito e
casual, quer nas coisas naturais, quer nas humanas. E segundo estes o fado não é senão a disposição dos
astros, sob os quais fomos concebidos ou nascidos. — Mas esta opinião não pode subsistir, por duas
razões. — Primeira, quanto às causas humanas. Pois, como já se demonstrou, os atos humanos não
estão sujeitos à ação dos corpos celestes, senão acidental e indiretamente. Ora, a causa fatal, de que
dependem as coisas fatais, há-de necessàriamente ser causa direta e por si do que é realizado. — A
segunda, quanto a tudo o que é acidentalmente feito. Pois, como se disse antes, o acidental não é
propriamente ser uno. Ora, toda ação da natureza termina em alguma unidade. Por onde, é impossível o
acidental ser, em si, efeito de um princípio agente natural. Assim, não está no poder de nenhuma
natureza, em si mesma, cavar um sepulcro e achar um tesouro. Logo, é manifesto que o corpo celeste
age como princípio natural, e portanto os seus efeitos, neste mundo, são naturais. E por conseqüência, é
impossível que qualquer virtude ativa desse corpo seja causa do que neste mundo se realiza
acidentalmente, pelo acaso ou pela fortuna.
E portanto, deve-se dizer que o que se realiza acidentalmente neste inundo, quer em relação às causas
naturais, quer às humanas, reduz-se a alguma causa preordenada, que é a Providência divina. Pois nada
impede que o acidental seja considerado como uno, por algum intelecto; do contrário, o intelecto não
poderia formar esta proposição: o que cavava um sepulcro encontrou um tesouro. E assim como o
intelecto pode apreender tal, também pode realizá-lo; p. ex., alguém ciente do lugar em que há um
tesouro escondido, instigasse algum rústico, que o ignorasse, a cavar aí um sepulcro. Por isso nada
impede que as causas feitas acidentalmente, neste mundo, como fortuitas ou casuais, sejam reduzidas a
uma causa ordenadora, que age por meio do intelecto, e sobretudo do intelecto divino. Pois, só Deus
pode imutar a vontade, como já, se estabeleceu. E por conseqüência, a ordenação dos atos humanos,
cujo princípio é a vontade, deve ser atribuída só a Deus.
Assim, pois, estando todas as coisas feitas neste mundo sujeitas à Providência divina por serem por elas
preordenadas e como que de antemão faladas, podemos admitir o fado; embora os santos Doutores se
recusassem empregar esse nome, por causa dos que o aplicavam em relação à virtude da posição dos
astros. Por onde, diz Agostinho: Quem atribuir ao fado as coisas humanas, porque dá esse nome à von-
tade ou ao poder de Deus mesmo, conserve a sua opinião, mas corrija o modo de falar. E nesse sentido
também Gregório nega que haja fado.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Nada impede que uma coisa seja fortuita ou casual por comparação às
causas próximas, e não, por comparação à divina Providência; e é assim que nada se faz no mundo ao
acaso, como diz Agostinho.

## Art. 2 — Se há fado nas coisas criadas.
(I Sent., dist. XXXIX, q. 2. a. 1, ad. 5; III Cont. Gent., cap. XCIII; De Verit., q. 5. a. 1, ad I; Quodl. XII, q. 3, a.
2; Compend. Theol., cap. CXXXVIII; Opusc. XXXVIII. De Fato, cap. II).
O segundo discute-se assim. — Parece que não há fado, nas coisas criadas.

1. — Pois, diz Agostinho, que é a vontade mesma ou o poder mesmo de Deus que se chama fado. Ora, a
vontade e poder de Deus não está nas criaturas, mas em Deus. Logo, o fado não está nas coisas criadas;
mas em Deus.

2. Demais. — O fado não é causa do fatal, como o próprio modo de falar o mostra. Ora, a causa, em si,
universal das coisas acidentalmente feitas neste mundo, é só Deus, como já se disse. Logo, o fado está
em Deus e não, nas coisas criadas.

3. Demais. — Se o fado está nas criaturas, é substância ou acidente; e quer um ou outro, é necessário se
multiplique, com a multidão das criaturas. Ora, sendo o fado considerado como um só, resulta que não
está nas criaturas, mas em Deus.
Mas, em contrário, diz Boécio: o fado é a disposição inerente às causas humanas.

SOLUÇÃO. — Como resulta claro do que já foi dito, a Providência divina executa, por causas médias, os
seus efeitos. Ora, a ordenação mesma dos efeitos pode ser considerada de duplo modo. De um,
enquanto está em Deus, e então, se chama Providência. Enquanto, porém, a referida ordenação é
considerada nas causas médias, ordenadas por Deus à produção de certos efeitos, então ela assume a
natureza do fado. E é isto que diz Boécio: A série fatal há-se de urdir, quer o lado se realize por certos
espíritos, servos da Providência divina, ou pela alma, ou por toda a natureza, que é serva, ou pelos
movimentos celestes dos astros, ou pela angélica virtude, ou pela variada solércia dos demônios, ou por
um só destes meios, ou por todos, de cada um dos· quais já se tratou nos artigos precedentes. Assim,
pois, é manifesto que o fado está nas coisas criadas mesmas, enquanto ordenadas por Deus a
produzirem certos efeitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ordenação mesma das causas segundas, a que
Agostinho chama série das causas, não tem a natureza de fado, senão enquanto dependente de Deus. E
portanto, o poder ou a vontade de Deus pode se chamar fado, causalmente; essencialmente, porém,
fado é a ordenação mesma, ou a série, i. é, a ordem das causas segundas.

RESPOSTA À SEGUNDA. — O fado exerce a função de causa na mesma medida em que a exercem as
camas segundas, cuja ordenação se chama fado.

RESPOSTA À TERCEIRA. — Diz-se que o fado é a disposição, não no gênero da qualidade, mas
designativa da ordem, que não é substância, mas relação. E essa ordem, considerada em relação ao seu
princípio, sendo uma, diz-se que só há um fado. Se porém for considerada em relação aos efeitos, ou às
causas médias mesmas, então ela se multiplica; e deste modo é que o poeta disse: Os teus fados te
arrastam.

## Art. 3 — Se o fado é imutável.
(Opusc. XXVIII, De Fato, cap. II, III).
O terceiro discute-se assim. — Parece que o fado não é imutável.

1. — Pois, diz Boécio: Assim como o intelecto está para o raciocínio; o que é, para o que é gerado; o
tempo, para a eternidade; o círculo, para o ponto central; assim está a série mutável do fado para a
estável simplicidade da providência.

2. Demais. — Como diz o Filósofo, quando nos movemos, move-se tudo o que está em nós. Ora, o fado é
uma disposição inerente às coisas móveis, como diz Boécio. Logo o fado é imutável.

3. Demais. — Se o fado é imutável, as coisas que lhe estão submetidas se realizarão imutável e
necessàriamente. Ora, as coisas atribuídas ao fado são as mais contingentes. Logo, nada haverá de
contingente mas tudo se realizará necessariamente.
Mas, em contrário, diz Boécio: o fado é uma disposição imutável.

SOLUÇÃO. — A disposição das causas segundas, a que chamamos fado, pode ser duplamente
considerada. Em relação a si mesmas, de tal modo, dispostas ou ordenadas, e em relação ao princípio
primeiro, pelo qual são ordenadas que é Deus. — Ora, certos ensinam que a série mesma ou disposição
das causas é em si necessária; de modo que tudo se realiza necessàriamente, porque qualquer efeito
tem a sua causa e, posta esta, aquele necessàriamente se segue. Mas esta opinião é claramente falsa,
em virtude do que já se disse. — Outros porém, contràriamente, dizem que o fado é mutável, mesmo no
que depende da divina Providência. Por isso os Egípcios diziam que o fado pode ser mudado, por, certos
sacrifícios, como refere Gregório Nisseno. Mas, esta opinião já foi excluída antes, porque repugna à
imutabilidade divina.
E portanto deve-se dizer que o fado relativamente à consideração das causas segundas, é mutável; mas
enquanto sujeito à divina Providência, participa da imutabilidade, não por necessidade absoluta, mas
condicionada. Ê assim que consideramos esta condicional verdadeira ou necessária: Se Deus prevê que
tal coisa há-de ser, ela será. Por onde, depois de ter dito que a série do fado é mutável, Boécio acrescen-
tou, após poucas palavras: a qual, originando-se da imutável Providência, também há-de neces-
sàriamente ser imutável.
Donde se deduzem as RESPOSTAS ÀS OBJEÇÕES.

## Art. 4 — Se tudo está sujeito ao fado.
(Supra, a. 1)
O quarto discute-se assim. — Parece que tudo está sujeito ao fado.

1. — Pois, diz Boécio: A série do fado move o céu e os astros, tempera os elementos entre si e os
transforma por alternada comutação; os próprios seres que nascem e morrem, a todos renova por
progressos semelhantes dos fetos e do sêmen; ela mesma abrange os atos e as fortunas dos homens,
pela indissolúvel conexão das causas. Logo, nenhum exceção há que se não contenha na série do fado.

2. Demais. — Agostinho diz, que o fado existe na medida em que é referido à vontade e ao poder de
Deus. Ora, a vontade de Deus é a causa de tudo o que se faz, como o mesmo diz. Logo, tudo está sujeito
ao fado.

3. Demais. — O fado, segundo Boécio, é a disposição inerente às causas mutáveis. Ora, todas as
criaturas são mutáveis, e só Deus é verdadeiramente imutável, como já se disse. Logo, há fado para
todas as criaturas.
Mas, em contrário, diz Boécio, que coisas, colocadas sob a Providência, superam a série do fado.

SOLUÇÃO. — Como já se disse, o fado é a ordenação das causas segundas, em relação a efeitos
divinamente previstos. Logo, tudo o que está sujeito a essas causas, está sujeito ao fado. Se porém há
coisas feitas imediatamente por Deus, essas, não estando sujeitas às causas segundas, também não o
estão ao fado; assim, a criação das coisas, a glorificação das substâncias espirituais, e outras
semelhantes. E é isto o que diz Boécio: as coisas próximas da divindade suprema, estavelmente fixadas,
excedem a ordem da fatal mutabilidade. Donde também resulta claro, que quanto mais uma causa es-
tiver afastada da mente primeira, tanto mais está implicada nos maiores nexos do fado, porque mais
está sujeita à necessidade das causas segundas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tudo ao que aí se alude é feito por Deus, mediante as
causas segundas, e portanto, está contido na série do fado. Mas de todas as demais causas, não se pode
dizer o mesmo, como já se estabeleceu.

RESPOSTA À SEGUNDA. — O fado depende da vontade e do poder de Deus, como no princípio primeiro.
Por onde, não é necessário que tudo o sujeito à vontade ou ao poder divinos esteja sujeito ao fado,
como já se disse.

RESPOSTA À TERCEIRA. — Embora todas as criaturas sejam, de certo modo, mutáveis, contudo algumas
delas não procedem das causas criadas mutáveis. E portanto não estão sujeitas ao fado, como já se
disse.