# Questão 80: Das potências apetitivas em comum.
Em seguida devem-se considerar as potências apetitivas, E sobre este assunto, quatro pontos se hão de
tratar.Primeiro, do apetite em comum. Segundo, da sensualidade. Terceiro da vontade. Quarto, do livre
arbítrio.
Sobre o primeiro, dois artigos se discutem:

## Art. 1 — Se o apetite é uma potência especial da alma.
(III Sent., dist. XXVII, q. 1, a. 2; De Verit., q., 22, a 3).
O primeiro discute-se assim. ― Parece que o apetite não é uma potência da alma.

1. ― Pois, não se deve atribuir uma potência especial da alma ao que é comum aos seres animados e
aos inanimados. Ora, o apetite é-lhes comum porque, como diz Aristóteles, o bem é o que todos os
seres desejam. Logo, é uma potência especial da alma.

2. Demais. ― As potências se distinguem pelos objetos. Mas o que conhecemos é o mesmo que
desejamos. Logo, a virtude apetitiva não deve ser diferente da apreensiva.

3. Demais. ― O comum não se distingue por oposição com o próprio. Ora, cada uma das potências da
alma deseja um certo bem apetecível particular, a saber, o objeto que lhe é conveniente. Logo, em
relação a esse objeto, que é o apetecível comum, não é necessário introduzir uma potência distinta das
outras, chamada apetitiva.
Mas, em contrário, o Filósofo distingue a apetitiva das outras potências. E Damasceno também distingue
as virtudes apetitivas das cognitivas.

SOLUÇÃO. ― É necessário admitir na alma uma potência apetitiva. O que se evidencia considerando
que cada inclinação resulta de uma forma; assim, o fogo, pela sua forma, se inclina para o lugar superior
e para gerar um semelhante a si. Ora, a forma, nos entes que participam do conhecimento, se encontra
de modo mais alto do que nos privados dele. Pois, nestes últimos, encontra-se somente a forma que
determina cada um deles a um ser próprio, e que a cada qual é natural. E a inclinação natural resulta
dessa forma natural, sendo chamadaapetite natural. Ao passo que nos entes dotados de conhecimento,
cada qual é determinado, pela forma natural, ao ser natural próprio, o qual todavia é susceptível de
receber as espécies das outras coisas; assim, o sentido recebe as espécies de todos os sensíveis, e o
intelecto, de todos os inteligíveis. De modo que a alma do homem se torna, de certo modo, em tudo,
pelo sentido e pelo intelecto. Por onde, os entes dotados de conhecimento aproximam-se, de certo
modo, da semelhança com Deus, em quem todas as coisas preexistem, como diz Dionísio. Portanto,
assim como as formas existem, nos entes que têm conhecimento, de modo mais elevado que o das,
formas naturais; assim é necessário haja neles uma inclinação superior ao modo da inclinação natural e
chamada apetite natural. E essa inclinação superior pertence à virtude apetitiva da alma, pela qual o
animal pode apetecer as coisas que apreende, além daquelas às quais se inclina pela forma natural. E,
portanto, é necessário admitir, na alma, uma potência apetitiva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O apetecer encontra-se nos entes dotados de
conhecimento, mas de modo superior ao comum, que existe em todos os outros seres, como já se disse.
E, portanto, é necessário seja, para isso, determinada uma potência da alma.

RESPOSTA À SEGUNDA. ― O apreendido e o apetecido são idênticos quanto ao objeto, mas diferem
pela relação com ele. Pois, o objeto é apreendido como ente sensível ou inteligível; ao passo que é
apetecido como conveniente ou bom. Ora, a diversidade de relações com os objetos, e não a
diversidade material, é que fundamentam a diversidade das potências.

RESPOSTA À TERCEIRA. ― Cada potência da alma é uma forma ou natureza, com inclinação natural para
alguma coisa. Por onde, cada uma deseja o objeto que lhe é conveniente, por um apetite natural.
Superior a este, porém, é o apetite animal, conseqüente à apreensão, e pelo qual alguma coisa é
apetecida, não pela razão de ser conveniente ao ato de tal potência ou tal outra, como p. ex., a visão, a
ver, e audição, a ouvir; mas por ser conveniente, absolutamente ao animal.

## Art. 2 — Se o apetite sensitivo e o intelectivo são potências diversas.
(De Verit., q. 22, a. 4; q. 25, a. 1; III De Anima, lect. XIV).
O segundo discute-se assim. ― Parece que o apetite sensitivo e o intelectivo não são potências
diversas.

1. ― Pois, as potências não se diversificam pelas diferenças acidentais, como se disse antes (q. 77, a. 3).
Ora, é acidental ao apetecível ser apreendido pelo sentido ou pelo intelecto. Logo, o apetite sensitivo e
o intelectivo não são potências diversas.

2. Demais. ― O conhecimento intelectivo é o do universal e, por aí, se distingue do sensitivo que é o
conhecimento do singular. Ora, essa distinção não tem lugar na parte apetitiva; pois, sendo o apetite
movido, pela alma, para causas singulares, todos os apetites visam causas singulares. Logo, o apetite
intelectivo não deve se distinguir do sensitivo.

3. Demais. ― Assim como a apetitiva, como potência inferior, é dependente da apreensiva, assim
também a motiva. Mas, não há, no homem, uma potência motiva, conseqüente ao intelecto, diferente
da que, nos outros animais, é conseqüente ao sentido. Logo, pela mesma razão, não é diferente a
potência apetitiva.
Mas, em contrário; o Filósofo distingue um duplo apetite, e diz, que o superior move o inferior.

SOLUÇÃO. ― É necessário admitir o apetite intelectivo como potência diferente da sensitiva. Pois, a
potência apetitiva é uma potência passiva, cuja natureza é ser movida pelo que foi apreendido; por
onde, o apetecível apreendido é motor não movido; porém, o apetite é motor movido, como diz
Aristóteles. Ora, o passivo e o móvel se distinguem pela distinção do ativo e do motivo; pois, é forçoso
que o motivo seja proporcionado ao móvel e o ativo, ao passivo, e a essência da potência passiva
mesma está em ser ordenada ao que lhe é ativo. Ora, como o que é apreendido pelo intelecto é de
outro gênero do que o apreendido pelo sentido, resulta que o apetite intelectivo é potência diferente
do sensitivo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Não é por acidente que o apetecível é apreendido pelo
sentido e pelo intelecto, mas em si mesmo é que convém a este. Pois, o apetecível só como apreendido
é que move o apetite. Por onde, as diferenças do apreendido são, em si, as do apetecível. E, por isso, as
potências apetitivas distinguem-se pelas diferenças das coisas apreendidas, como sendo os objetos
próprios delas.

RESPOSTA À SEGUNDA. ― Embora o apetite intelectivo busque coisas singulares exteriores à alma,
busca-as todavia por meio de alguma noção universal; assim, quando deseja algo de bom. Por onde, diz
o Filósofo, pode-se ter ódio universalmente, p. ex., quando o temos de todo gênero de ladrões.
Semelhantemente, pelo apetite intelectivo também podemos desejar bens imateriais, que os sentidos
não apreendem, como a ciência, as virtudes e outros semelhantes.

RESPOSTA À TERCEIRA. ― Como já foi dito, a opinião universal não move senão mediante a particular;
e, semelhantemente, o apetite superior move mediante o inferior. E, portanto, não há outra virtude
motiva conseqüente ao intelecto e ao sentido.