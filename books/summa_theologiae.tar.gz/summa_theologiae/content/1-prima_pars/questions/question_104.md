# Questão 104: Dos efeitos do governo divino em especial.
Em seguida devemos tratar dos efeitos do governo divino em especial.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se as criaturas necessitam de ser conservadas na existência por Deus.
O primeiro discute–se assim. Parece que as criaturas não necessitam de ser conservadas na existência
por Deus.

1. – Pois, o que não pode deixar de existir não necessita ser conservado na existência, assim como o que
não pode morrer não o necessita, para que não morra. Ora, há certas criaturas, que por natureza, não
podem deixar de existir. Logo, nem todas necessitam ser conservadas na existência por Deus. Prova da
média. O que é inerente a um ser o é necessariamente, e é impossível que o oposto também o seja;
assim, o binário há de necessariamente ser par e é impossível seja impar. Ora, a existência em si resulta
da forma, porque um ser é atual na medida em que tem forma. Ora, como há certas criaturas que são
formas subsistentes, segundo foi dito, antes, dos anjos, a essas a existência, em si, é inerente. E a
mesma essência têm os seres cuja matéria é potencial em relação a uma só forma, conforme se disse
antes, dos corpos celestes. Logo, tais criaturas existem por natureza necessariamente e não podem
deixar de existir; pois a potência para o não ser não pode fundar–se nem na forma, de que, em si,
resulta a existência; nem na matéria existente com uma forma, que não pode perder, por não ser
potencial em relação a outra forma.

2. Demais. – Deus é mais poderoso que qualquer agente criado. Ora, há agentes criados que podem
comunicar ao seu efeito a conservação na existência; assim, cessada a ação do construtor, a casa
permanece; cessada a ação do fogo, a água permanece aquecida por algum tempo. Logo, com maior
razão, Deus pode cessada a sua operação, conferir à sua criatura a conservação na existência.

3. Demais. – Nada de violento pode suceder sem alguma causa agente. Ora, não é natural, mas violento,
que uma criatura tenda para o não ser, pois todas buscam naturalmente a existência. Logo, nenhuma
criatura pode tender para o não ser, sem que algum agente a leve à corrupção. Mas há certos seres sem
corrupção possível, como as substâncias espirituais e os corpos celestes. Logo, tais criaturas não podem
tender para o não ser, mesmo tendo cessado a operação de Deus.

4. Demais. – Há de ser por alguma ação que Deus conserva as coisas na existência. Ora, qualquer ação
eficaz do agente causa algum efeito. Logo, é necessário que a ação de Deus conservador cause algo, na
criatura. Ora, tal não se dá. Pois, tal ação não dá a existência à criatura, porque o já existente não pode
vir a existir; nem algo de acrescentado, porque então, ou Deus não conservaria a criatura
continuamente na existência, ou lhe acrescentaria algo, continuamente, o que é inadmissível. Logo, as
criaturas não são conservadas na existência por Deus.
Mas, em contrário, diz a Escritura: Sustentando tudo com a palavra da sua virtude.

SOLUÇÃO. – Necessário é admitir–se, tanto segundo a fé, como segundo a razão, que as criaturas são
conservadas na existência por Deus. Para cuja evidência deve–se considerar que, de duplo modo um ser
é conservado por outro. – De um modo, indiretamente e por acidente; assim, diz–se que conserva uma
cousa quem dela remove o que a corrompe; por exemplo, diz–se que conserva uma criança quem a
guarda para que não caia no fogo. E neste sentido se diz que Deus conserva, não todos os seres, mas
alguns, porque certos há que não tem elementos corruptores, que necessitem ser removidos, para que
sejam conservados na existência. – De outro modo se diz que um ser conserva outro, por si e
diretamente, quando o conservado depende do conservador, a tal ponto que não pode existir sem este.
E deste modo todas as criaturas necessitam da conservação divina. Pois, todas dependem de Deus, a tal
ponto que nem por um momento poderiam subsistir, mas voltariam ao nada, se a operação divina não
as conservasse na existência, como diz Gregório.
E isto pode ser compreendido do modo seguinte. Todo efeito depende da sua causa enquanto causa.
Ora, devemos notar que qualquer agente é causa do seu efeito, só quanto ao vir a ser deste, e não
diretamente, quanto à essência do mesmo. E isto se dá tanto com as coisas artificiais como com as
naturais. Assim, o construtor é causa da casa quanto ao vir a ser desta e não, diretamente, quanto à
existência dela. Porquanto, é manifesto que a forma da casa, que é composição e ordem, resulta da
virtude natural de certas coisas. Pois, como o cozinheiro coze o alimento, ajudando–se da virtude
natural ativa do fogo, assim o construtor faz a casa, servindo–se do cimento, das pedras e madeiras,
susceptíveis e conservativas de tal composição e de tal ordem. Por onde, a existência da casa depende
das naturezas dessas coisas, como o vir a ser dela depende da ação do construtor. – Ora, a essa mesma
luz devemos considerar as coisas naturais. Porque, se um agente não é causa da forma, como tal, não
será, por si, causa da existência resultante de tal forma, mas será causa do efeito, só quanto ao vir a ser.
Mas é manifesto que se dois entes são da mesma espécie, um não pode ser, por si, causa da forma
como tal do outro; porque então seria também causa da própria forma, pois arribas tem a mesma
essência. Mas pode ser causa da dita forma, enquanto pertencente a uma determinada matéria, isto é,
enquanto essa matéria adquire a tal forma. O que é ser causa só do vir a ser, como quando um homem
gera outro e um fogo, outro fogo. E, portanto, sempre que é próprio ao efeito natural receber a
impressão do agente, com a mesma essência que ela tem neste, então o vir a ser e não a existência do
efeito é que depende do agente.
Mas, às vezes, não é da natureza do efeito receber a impressão do agente com a mesma essência que
ela tem neste; como é patente em todos os agentes que não produzem o especificamente semelhante;
assim os corpos celestes são causa da geração dos corpos inferiores, especificamente deles
dissemelhantes. E tal agente pode ser causa da forma, quanto à essência de uma determinada forma e
não só enquanto esta é recebida por tal matéria; sendo, portanto, causa, não só do vir a ser, mas
também da existência.
Por onde, assim como o vir a ser de uma cousa não pode permanecer, cessada a ação do agente, causa
do vir a ser do efeito; assim também a existência da mesma não pode permanecer, cessada a ação do
agente, causa não só do vir a ser, como também da existência do efeito. E esta é a razão porque a água
aquecida conserva o calmo, cessada a ação do fogo; ao passo que o ar não permanece iluminado, nem
por um momento cessada a ação do sol. Pois a matéria da água é susceptível do calor do fogo do
mesmo modo pelo qual ele está no fogo; e por isso, unindo–se perfeitamente com a forma do fogo
conservará sempre o calor; se, porém participar algo imperfeitamente da forma do fogo, por uma como
incoação, o calor não se conservará sempre, mas só temporariamente, por causa da fraca participação
do princípio do calor. Ao passo que ao ar de nenhum modo é natural receber a luz, do mesmo modo
pelo qual ela está no sol, de maneira que receba a forma do sol, que é o princípio da luz; e por isso,
cessada a ação do sol, imediatamente cessa a luz, que se não radica no ar.
Ora, todas as criaturas estão para Deus, como o ar para o sol iluminador. Pois, assim como o sol luz por
natureza, ao passo que o ar se torna luminoso participando, não da natureza, mas da luz do sol; assim,
só Deus existe pela sua essência, porque esta é a sua existência; ao passo que todas as criaturas têm a
existência participada, e não porque se identifique, nelas, a existência com a essência. Por onde, diz
Agostinho: Se o poder governativo de Deus cessasse por algum instante nos seres criados, também
cerraria imediatamente a espécie deles e toda a natureza sucumbiria, E o mesmo: Assim como o ar, com
a presença da luz torna–se lúcido, assim o homem, quando Deus lhe esta presente, ilumina–se e,
quando ausente, imediatamente se entenebrece.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A existência, em si, resulta da forma da criatura, suposto,
contudo o influxo de Deus. Por onde, a potência para o não ser, nas criaturas espirituais e nos corpos
celestes, está antes em Deus, que pode subtrair o seu influxo, do que na forma ou na matéria de tais
criaturas.

RESPOSTA À SEGUNDA. – Deus não pode comunicar a nenhuma, criatura que se conserve existente,
cessada a sua operação; assim como não lhe pode comunicar que não seja a causa dela. Pois, uma
criatura precisa de ser conservada por Deus, na medida em que a existência do efeito depende da causa
da existência. Por onde, não há símile com o agente, que não é causa do existir, mas só do vir a ser.

RESPOSTA À TERCEIRA. – A objeção procede quanto à conservação resultante da remoção do elemento
corruptor: e, dessa, nem todas as criaturas necessitam, como já se disse.

RESPOSTA À QUARTA. – Deus não conserva as coisas por uma nova ação, mas continuando a ação pela
qual deu a existência; e essa ação é independente do movimento e do tempo, assim como a
conservação da luz, no ar, resulta do influxo continuado do sol.

## Art. 2 — Se Deus conserva todas as criaturas imediatamente.
O segundo discute–se assim. – Parece que Deus conserva imediatamente todas as criaturas.

1. – Pois, Deus é conservador das coisas pela mesma ação pela qual é criador, como já se disse. Ora, Ele
é o criador imediato de todas as coisas. Logo, também é conservador imediato delas.

2. Demais. – Uma cousa é mais próxima de si mesma que de qualquer outra. Ora, não pode ser
comunicado a nenhuma criatura o conservar–se a si mesma. Logo, com maior razão, não lhe pode ser o
conservar a outra. Portanto, Deus conserva todas as coisas, sem a mediação de nenhuma causa média
conservadora.

3. Demais. – O efeito é conservado na existência pela sua causa, não só quanto ao vir a ser, mas também
quanto ao existir. Ora, todas as coisas criadas, segundo parece, não são causas dos seus efeitos, senão
quanto ao vir a ser; pois, são apenas causas motoras como antes já se estabeleceu. Logo não são causas
conservadoras da existência dos seus efeitos.
Mas, em contrário, uma coisa é conservada pelo mesmo ser que lhe deu a existência. Ora, Deus dá a
existência às coisas mediante certas causas médias. Logo, também as conserva na existência, mediante
certas causas.

SOLUÇÃO. – Como já se disse de duplo modo um ser conserva outro na existência: indireta e
acidentalmente, removendo ou impedindo a ação do corruptor; e diretamente e por si, porque desse
ser depende a existência do outro, como da causa depende a existência do efeito. Ora, de ambos esses
modos uma criatura é conservativa da existência de outra. Pois é manifesto que, mesmo nas coisas
corpóreas, muitas são as que impedem as ações dos elementos corruptores e por isso se chamam
conservativas de outras; assim, o sal impede a putrefação da carne e, semelhantemente, o mesmo se
verifica com muitas outras coisas. Ora, dá–se também que a existência de certos efeitos depende de
certas criaturas. Pois, sendo muitas as causas ordenadas, necessariamente é que o efeito dependa,
primária e principalmente, da causa primeira; secundariamente, porém, de todas as causas médias. Por
onde, principalmente, a causa primeira é conservativa do efeito; secundariamente porém todas as
causas médias; e tanto mais quanto fôr a causa mais elevada e mais próxima da causa primeira. E por
isso a conservação e a permanência das coisas atribui–se às causas superiores, mesmo nos seres
corpóreos. Assim, como diz o Filósofo, o movimento diurno, que é o primeiro, é a causa da continuidade
da geração; ao passo que o movimento segundo, pelo zodíaco, é a causa da diversidade, quanto à
geração e à corrupção. E semelhantemente, os astrólogos atribuem a Saturno, supremo entre os
planetas, o fixo e o permanente. E, portanto devemos concluir que Deus conserva as coisas na
existência, mediante certas causas.DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Deus criou
imediatamente todas as coisas, mas na criação mesmo delas estabeleceu–lhes uma ordem, de modo
que umas dependessem de outras, pelas quais secundariamente se conservassem na existência;
pressuposta porém a conservação principal que de Deus mesmo procede.

RESPOSTA À SEGUNDA. – Causa própria sendo a conservativa do efeito dela dependente, assim como
não é possível a nenhum efeito ser causa de si mesmo, mas lhe é contudo possível ser causa de outro;
assim também, embora nenhum efeito possa ser conservativo de si mesmo, pode contudo sê–lo de
outra cousa.

RESPOSTA À TERCEIRA. – Nenhuma criatura pode ser causa de outra, de modo que esta adquira uma
nova forma ou disposição, salvo por meio de alguma mutação; pois, aquela sempre atua sobre um
sujeito pressuposto. Mas depois que infundiu uma forma ou disposição no efeito, conserva–a sem
nenhuma outra imutação deste. Assim compreende–se que haja mutação no ar recém–iluminado: mas
a conservação da luz se dá sem nenhuma imutação do ar, só pela presença da luz.

## Art. 3 — Se Deus pode reduzir algum ser ao nada.
O terceiro discute–se assim. – Parece que Deus não pode reduzir nenhum ser ao nada.

1. – Pois, diz Agostinho, Deus não é causa da tendência para o não ser. Ora, tal se daria se reduzisse ao
nada qualquer criatura. Logo, Deus não pode reduzir nenhum ser ao nada.

2. Demais. – Deus, pela sua bondade, é a causa da existência das coisas, pois, como diz Agostinho, nós
existimos porque Deus é bom. Ora, Deus não pode deixar de ser bom. Logo, não pode fazer com que as
coisas deixem de existir, o que se daria se as reduzisse ao nada.

3. Demais. – Por alguma ação é que Deus haveria de reduzir seres ao nada. Ora, tal não é possível; pois,
como toda ação tem como termo algum ser, também a ação do corruptor teria como termo um ser
gerado, porque a geração de um é a corrupção de outro. Logo, Deus não pode reduzir nenhum ser ao
nada.
Mas, em contrário, diz a Escritura: Castiga–me, Senhor; porém seja isto segundo o teu juízo, e não no
teu furor, para que não suceda que tu me reduzas a nada.

SOLUÇÃO. – Alguns ensinaram que Deus produziu as coisas agindo por necessidade de natureza. E a ser
isso verdade, Ele não poderia reduzir nenhum ser ao nada, assim como não pode sofrer mutação na sua
natureza. Mas, como já se demonstrou antes, essa posição é falsa e absolutamente contrária à fé
católica, que ensina que Deus produziu os seres por livre vontade, conforme a Escritura: quantas coisas
quis, todas fez o Senhor. Logo, o comunicar Deus a existência à criatura depende da sua vontade; nem,
como já se disse, conserva a existência das coisas de modo diverso do pelo qual continuamente lhas dá.
Por onde, assim como, antes de as coisas existirem, podia não lhes outorgar a existência e, assim, não as
fazer; do mesmo modo, depois de havê–las feito, pode deixar de lhes influir a existência e, então elas
deixariam de existir, o que seria reduzi–las ao nada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. O não ser não tem, por si, causa; porque nada pode ser
causa senão na medida em que é ente, pois este, propriamente falando, é a causa da existência. Por
onde, Deus não pode ser a causa da tendência para o não ser; essa tendência as criaturas a trazem em si
mesmas, como vindas do nada. Mas, por acidente, Deus pode ser causa da redução das coisas ao nada,
subtraindo–lhes a sua ação.RESPOSTA À SEGUNDA. – A bondade de Deus é causa das coisas, não por
necessidade de natureza, porque essa bondade não depende das coisas criadas; mas age por livre
vontade. Por onde, assim como Deus podia, sem prejuízo da sua bondade, não dar a existência às coisas;
assim também, sem detrimento da mesma, pode não lhas conservar.

RESPOSTA À TERCEIRA. – Não por uma ação, mas por cessar de agir, é que Deus reduziria um ser ao
nada.

## Art. 4 — Se algum ser é reduzido ao nada.
O quarto discute–se assim. – Parece que há seres reduzidos ao nada.

1. – Pois, o fim corresponde ao princípio. Ora, no princípio, só Deus existia. Logo, as criaturas terão um
fim tal, que nada existirá a não ser Deus; e assim serão reduzidas ao nada.

2. Demais. – Toda criatura tem potência finita. Ora, nenhuma potência finita se estende até o infinito;
por isso Aristóteles prova que uma potência finita não pode mover, num tempo infinito. Logo, nenhuma
criatura pode durar infinitamente. E, portanto, será reduzida ao nada.

3. Demais. – A forma e o acidente não tem a matéria, como parte. Ora, às vezes deixam de existir. Logo,
são reduzidas ao nada.
Mas, em contrário, diz a Escritura: Eu aprendi que todas as obras que Deus fez perseveram para sempre.

SOLUÇÃO. – O que Deus faz, em relação à criatura, ora provém do curso natural das coisas; ora é
operado milagrosamente, fora da ordem natural imposta às criaturas, como a seguir se dirá. – Quanto
ao que Deus há de fazer, segundo a ordem natural imposta às coisas, isso pode ser deduzido da própria
natureza delas; o que porém se faz milagrosamente, ordena–se à manifestação da graça, conforme o
Apóstolo que diz: A cada um é dada a manifestação do Espírito para proveito; e a seguir entre outras
coisas trata de operação dos milagres. Ora, as naturezas das criaturas demonstram que nenhuma delas
é reduzida ao nada; porque ou são imateriais e então não tem a potência para o não ser; ou são
materiais e então permanecem sempre, ao menos quanto à matéria, que é incorruptível, como sujeito
existente da geração e da corrupção. Por outro lado, reduzir algum ser ao nada não condiz com a
manifestação da graça; pois, a potência e a bondade divinas mostram–se sobretudo na conservação das
coisas na existência. – Por onde, deve–se dizer, simplesmente, que absolutamente nada será reduzido
ao nada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O terem sido as coisas trazidas à existência, do nada,
manifesta a potência de quem as produziu. Ora, se fossem reduzidas ao nada impediriam essa
manifestação, porque o poder de Deus se mostra sobretudo no conservá–las na existência, conforme
aquilo do Apóstolo: Sustentando tudo com a palavra da sua virtude.

RESPOSTA À SEGUNDA. – A potência da criatura para existir é apenas receptiva; ao passo que a
potência ativa é de Deus mesmo, de quem provém o influxo para a existência. Por onde, o durarem as
coisas infinitamente resulta da infinidade da divina virtude. A virtude de certas coisas, porém, é
determinada a permanecer num tempo determinado, porque podem ser impedidas de receber o influxo
para a existência, proveniente de Deus, por algum agente contrário, ao qual uma virtude finita não pode
resistir num tempo infinito, mas só num tempo determinado. Por onde, os seres que não tem
contrários, embora tenham a virtude finita, perseveram eternamente.

RESPOSTA À TERCEIRA. – As formas e os acidentes não são entes completos, porque não subsistem;
mas, umas e outros tem algo do ente; pois, chamam–se entes, porque fazem alguma cousa existir. E
contudo, do modo pelo qual existem, não serão absolutamente reduzidos ao nada; não porque alguma
parte deles permaneça; mas porque permanecem na potência da matéria e do sujeito.