# Questão 62: Da perfeição dos anjos na existência da graça e da glória.
Em seguida devemos investigar como os anjos foram constituídos na existência da graça ou da glória.
E sobre este assunto, nove artigos se discutem:

## Art. 1 — Se os anjos foram criados em estado de beatitude.
(II Sent., dist. IV, a. 1)
O primeiro discute-se assim. — Parece que os anjos foram criados em estado de beatitude.

1. — Pois, como foi dito, os anjos que perseveram na beatitude, na qual foram criados, não possuem por
natureza o bem que têm. Logo, os anjos foram criados em estado de beatitude.

2. Demais. — A natureza angélica é mais nobre do que a corpórea. Ora, a criatura corpórea foi
imediatamente, desde o princípio, criada, formada e perfeita; nem a sua formação foi precedida, quanto
ao tempo, de um estado informe, mas quanto à natureza somente, como diz Agostinho. Logo, nem a
natureza angélica Deus a criou informe e imperfeita. Mas a formação e a perfeição dela se realiza pela
beatitude, pela qual goza de Deus. Portanto, foi criada em estado de beatitude.

3. Demais. — Segundo Agostinho, todas as coisas das quais se lê que foram feitas na obra dos seis dias,
o foram simultaneamente; e é então necessário que todos esses seis dias tenham existido
imediatamente, desde o princípio da criação das coisas. Ora, nesses seis dias, segundo a exposição de
Agostinho, houve o conhecimento angélico matutino pelo qual os anjos conheceram o Verbo e as coisas,
no Verbo. Portanto, imediatamente, desde o princípio da criação, os anjos conheceram o Verbo e as
coisas, no Verbo. Ora, os anjos beatos são os que vêem o Verbo. Logo, imediatamente, desde o princípio
da criação, os anjos estiveram em estado de beatitude.
Mas, em contrário, da natureza da beatitude é a estabilidade ou a confirmação no bem. Ora, os anjos
não foram confirmados no bem, imediatamente, desde que foram criados, e isso o prova a queda de
alguns. Logo, não estiveram, desde a sua criação, em estado de beatitude.

SOLUÇÃO. — Por beatitude se entende a última perfeição racional ou intelectual da natureza; donde
vem ser a beatitude naturalmente desejada, pois cada ser naturalmente deseja a sua última perfeição.
Ora, a última perfeição racional ou intelectual da natureza é dupla. Uma, que pode ser atingida por essa
natureza considerada em si mesma, e essa perfeição se chama, de algum modo, beatitude ou felicidade.
Por onde, a perfeitíssima contemplação do homem, pela qual o ótimo inteligível, que é Deus, pode ser
contemplado nesta vida, Aristóteles a considera a felicidade última. Mas, acima dessa, há outra
felicidade, que esperamos no futuro, pela qual veremos Deus como Ele é. E esta é superior à natureza
de qualquer intelecto criado, como antes já se demonstrou. — Portanto, quanto à primeira beatitude,
que o anjo podia atingir, em virtude de sua natureza, foi criado beato; pois, essa perfeição o anjo não a
adquire por algum movimento discursivo, como o homem, mas imediatamente lhe é coexistente, pela
dignidade da sua natureza, como antes já se disse. Porém, a beatitude última, excedente à capacidade
da sua natureza, os anjos não a tiveram imediatamente, no princípio da sua criação, porque essa
beatitude não é algo da natureza, senão o fim desta; e, por isso eles não a deviam ter, imediatamente,
desde o princípio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No passo citado, beatitude é empregada pela perfeição
natural que o anjo tinha no estado de inocência.

RESPOSTA À SEGUNDA. — A criatura corporal não podia ter imediatamente, no princípio da sua criação,
a perfeição à qual é levada pela sua operação. Por onde, segundo Agostinho, as plantas não germinaram
da terra, imediatamente, desde as primeiras obras, que deram à terra somente a virtude germinativa
das plantas. E semelhantemente, a criatura angélica, no princípio da sua criação, teve a perfeição da sua
natureza; não porém a perfeição à qual devia chegar, pela sua operação.

REPOSTA À TERCEIRA. — O anjo tem duplo conhecimento do Verbo: um natural, outro, pela glória. Pelo
primeiro, conhece o Verbo pela semelhança deste que transluz em a natureza angélica; pelo segundo,
porém, o anjo conhece o Verbo pela sua essência. E, por um e outro, o anjo conhece as coisas no Verbo;
imperfeitamente, pelo conhecimento natural; perfeitamente, pelo conhecimento da glória. Ora, o
primeiro conhecimento das coisas, no Verbo, os anjos o tiveram desde o princípio da sua criação; o
segundo, porém, só quando se tornaram beatos pela conversão ao bem. E este é o que propriamente se
chama conhecimento matutino.

## Art. 2 — Se o anjo precisava da graça para se converter a Deus.
O segundo discute-se assim. — Parece que o anjo não precisava da graça para se converter a Deus.

1. — Pois, não precisamos da graça para o que podemos naturalmente fazer. Ora, o anjo, amando
naturalmente a Deus, como já vimos, naturalmente a ele se converte. Logo, o anjo não precisava da
graça para se converter a Deus..

2. Demais. — Precisamos de auxílio só para o que é difícil. Ora, converter-se a Deus não era difícil para o
anjo, pois neste nada existia que a tal conversão repugnasse. Logo, o anjo não precisava do auxílio da
graça para se converter a Deus.

3. Demais. — Converter-se a Deus é preparar-se para a graça e, por isso, diz a Escritura: Convertei-vos a
mim, e eu me converterei a vós. Ora, nós não precisamos da graça para nos prepararmos para ela, pois
então iríamos ao infinito. Logo, o anjo não precisava da graça para se converter a Deus.
Mas, em contrário. Convertendo-se a Deus, o anjo chega à beatitude. Portanto, se não precisasse da
graça, para se converter a Deus, resulta que dela não precisaria para ter a vida eterna, o que é contra a
Escritura, dizendo: A graça de Deus é a vida eterna.

SOLUÇÃO. — Os anjos precisava da graça para se converterem a Deus, objeto da beatitude. Pois, como
já dissemos antes, o movimento natural da vontade é o princípio de tudo o que queremos. Ora, a
inclinação natural da vontade é para o que lhe é naturalmente conveniente. Portanto, para o que lhe é
naturalmente superior a vontade não pode tender senão levada por algum princípio sobrenatural, que a
ajude. Assim, é claro que o fogo tem inclinação natural para aquecer e para gerar o fogo; mas gerar a
carne está acima da virtude natural do fogo; por isso, para gerá-la, o fogo não tem nenhuma inclinação,
salvo se for movido, como instrumento, pela alma nutritiva. Mas, já ficou demonstrado, quando se
tratou do conhecimento de Deus, que ver a Deus por essência, no que consiste a última beatitude da
criatura racional, está acima da natureza de qualquer intelecto criado. Por isso, nenhuma criatura
racional pode ter o movimento da vontade ordenado para essa beatitude, sem ser movida por um
agente sobrenatural; e é a isto que chamamos auxílio da graça. Logo, deve-se dizer que o anjo a essa
felicidade não se pode converter, senão pelo auxílio da graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O anjo naturalmente ama a Deus como ao princípio
natural da sua existência. Aqui porém falamos da conversão a Deus, enquanto Ele beatifica pela visão da
sua essência.

RESPOSTA À SEGUNDA. — Difícil é o que transcende o poder do agente; e isso de duplo modo pode dar-
se. De um primeiro modo, transcende esse poder em respeito à ordem natural do agente. E então, se
pode atingir o fim, com algum auxílio, chama-se difícil; se, porém, de nenhum modo o pode, chama-
se impossível; p. ex., é impossível ao homem voar. De outro modo, transcende o poder, não em respeito
à ordem natural deste, mas em virtude de algum impedimento adjunto ao mesmo. Assim, subir não é
contra a ordem natural da potência da alma motora, porque à alma, em si mesma, é natural mover-se
para qualquer parte; mas, ficando impedida disso, pelo peso do corpo, é difícil ao homem subir. Ora, por
certo, difícil é ao homem converter-se à felicidade última, tanto por lho ser superior à natureza como
por haver um impedimento proveniente da corrupção do corpo e da infecção do pecado. Ao anjo,
porém, lho é difícil somente por ser uma atividade sobrenatural.

RESPOSTA À TERCEIRA. — Qualquer movimento da vontade para Deus podendo chamar-se conversão,
tríplice é essa conversão. — Uma, pela dileção perfeita, e é a da criatura que já goza de Deus. E, tal
conversão requer a graça consumada. — Outra é o merecimento da beatitude; e essa requer a graça
habitual, princípio do merecimento. — Pela terceira, preparamo-nos a ter a graça. E essa não exige
nenhuma graça habitual, mas a operação de Deus que converte a alma para si, segundo a
Escritura: Converte-nos Senhor, a ti, e nós nos converteremos. Por onde se vê que não se procede até o
infinito.

## Art. 3 — Se os anjos foram criados em graça.
O terceiro discute-se assim. — Parece que os anjos não foram criados em graça.

1. — Pois, Agostinho diz: A natureza angélica foi primeiro criada informe e era chamada céu; porém,
depois, recebeu forma e se chamou luz. Ora, esta formação se realizou pela graça. Logo, os anjos não
foram criados em graça.

2. Demais. — A graça inclina a criatura racional para Deus. Se, portanto, o anjo tivesse sido criado em
graça, nenhum se teria desviado de Deus.

3. Demais. — A graça é um meio termo entre a natureza e a glória. Ora, os anjos não foram bem-
aventurados desde a sua criação. Logo, também não foram criados em graça, mas primeiro só tiveram a
natureza; depois alcançaram a graça e, por último, foram beatificados.
Mas, em contrário, diz Agostinho: Quem estabeleceu os anjos na sua vontade boa, senão aquele que os
criou com a sua vontade, i. é, com o casto amor a que eles aderem, constituindo-os simultaneamente
em a sua natureza e repartindo-lhes a graça?

SOLUÇÃO. — São diversas as opiniões nesta matéria. Embora uns dissessem que os anjos foram criados
com os seus dons naturais somente; e outros, que o foram em graça, contudo, como mais provável e
consentâneo aos ditos dos santos, deve-se admitir que foram criados em graça santificante. Assim, pois,
vemos que todas as coisas criadas no decurso do tempo, por obra da divina providência, e produzidos
pela operação de Deus, foram produzidas na primeira condição delas mediante certas razões seminais,
como diz Agostinho; assim as árvores, os animais, e seres semelhantes. Ora, é manifesto que a graça
santificante está para a beatitude, como a razão seminal, em a natureza, para o efeito natural; por onde,
a graça é chamada na Escritura, asemente de Deus. Como pois, segundo a opinião de Agostinho, se
ensina que imediatamente, desde a primeira criação da criatura corpórea, foram-lhe infundidos as
razões seminais de todos os efeitos naturais; assim também, imediatamente, desde o princípio, os anjos
foram criados em graça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa informidade do anjo pode-se compreender por
comparação com a formação da glória e, então, a informidade precedeu temporalmente a formação; ou
por comparação com a formação da graça e, assim, aquela precedeu a esta não temporal, mas
naturalmente, como também Agostinho o ensina a respeito da formação corporal.

RESPOSTA À SEGUNDA. — Toda forma inclina o seu sujeito ao modo da natureza deste. Ora, o modo
natural da natureza intelectual é que se conduza ao que quer, livremente. Por onde, a inclinação da
graça não impõe necessidade, mas quem tem a graça pode não usar dela e pecar.

RESPOSTA À TERCEIRA. — Embora a graça seja o meio termo entre a natureza e a glória, na ordem da
natureza; todavia, na ordem do tempo, não deviam simultaneamente existir, em a natureza criada, a
glória e a natureza, pois a glória é o fim da operação da natureza mesma, ajudada pela graça. A graça,
porém, não se comporta como fim da operação, porque não resulta das obras, mas é o princípio de bem
operar. E portanto, era conveniente dar a graça imediatamente, com a natureza.

## Art. 4 — Se o anjo bem-aventurado mereceu a sua beatitude.
O quarto discute-se assim. — Parece que o anjo bem-aventurado não mereceu a sua beatitude.

1. — Pois, o mérito provém da dificuldade do ato meritório. Ora, o anjo não teve nenhuma dificuldade
em obrar bem. Logo, a boa obra não lhe foi meritória.

2. Demais. — Nós não merecemos pelo que nos é natural. Ora, natural ao anjo era que se convertesse a
Deus. Logo, por isso não mereceu a felicidade.

3. Demais. — Se o anjo bem-aventurado mereceu a sua beatitude ou a mereceu antes de a ter, ou
depois de a ter tido. Ora, antes, não, pois, segundo a opinião de muitos, antes não teve a graça, sem a
qual não há nenhum mérito. Nem depois, porque então, ainda continuaria a merecer, o que é falso;
pois, se assim fosse, um anjo menor, merecendo, poderia chegar ao grau do anjo superior, e não seriam
estáveis as distinções dos graus da glória, o que é inadmissível. Logo, o anjo bem-aventurado não
mereceu a sua beatitude.
Mas, em contrário. Diz a Escritura, que a medida do anjo, na celeste Jerusalém, é a medida do homem.
Ora, o homem não pode alcançar a beatitude senão pelo mérito. Logo, nem o anjo.

SOLUÇÃO. — Só a Deus é natural a beatitude perfeita, porque nele se identifica a essência com a
beatitude. Porém, a qualquer criatura a beatitude não é natural, mas é o fim último. Ora, qualquer ser,
alcança, pela sua operação, o seu último fim. E essa operação conducente ao fim ou é factiva do fim,
quando este não excede a virtude do que opera,visando-o, e assim a medicação é factiva da saúde;ou é
meritória do fim, quando este excede a virtude do que opera, visando-o, e então o fim é esperado como
dom alheio.Ora, a beatitude última excede tanto a natureza angélica como a humana, conforme resulta
do já dito. Donde se conclui que, tanto o anjo como o homem mereceram a sua beatitude.
E se o anjo, pois, foi criado em graça, sem a qual não há nenhum mérito, podemos dizer sem dificuldade
que mereceu a sua beatitude; e semelhantemente, se alguém dissesse que o anjo teve, de algum modo,
a graça antes da glória. —Se porém o anjo não teve a graça antes de ser bem-aventurado, então
devemos dizer que alcançou a beatitude sem mérito, como nós, a graça.O que todavia é contra a
natureza da beatitude, que exerce a função de fim e é o prêmio da virtude, como também ensina o
Filósofo. —Ou se deve dizer que os anjos merecem a beatitude pelo que, já bem-aventurados operam
nos divinos ministérios, como outros sentiram. O que contudo é contra a natureza do mérito; pois,
sendo como a via para o fim, e a quem já está no termo não cabendo mover-se para este, ninguém
merece o que já tem. —Ou se deve dizer que o mesmo ato de conversão para Deus é meritório,
enquanto promana do livre arbítrio; e é a fruição bem-aventurada enquanto atinge o fim. Mas também
esta opinião é inadmissível, por não ser o livre arbítrio a causa suficiente do mérito, e portanto o ato não
poder ser meritório, enquanto livre, sem que seja informado pela graça. Ora, não pode ser informado
simultanteamente pela graça imperfeita, princípio do mérito e pela perfeita, princípio da fruição. Por
onde, não é possível, simultaneamente, fruir e merecer a fruição.
Por onde, melhor diremos que o anjo teve a graça, antes de ser beatificado, e por ela mereceu a
beatitude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A dificuldade de bem obrar aos anjos não lhes provém
de nenhuma contrariedade ou impedimento da virtude natural; mas de qualquer obra boa superar a
virtude da natureza.

RESPOSTA À SEGUNDA. — Não pela conversão natural o anjo mereceu a beatitude, mas pela conversão
da caridade, que procede da graça.

RESPOSTA À TERCEIRA. — A resposta resulta claro do já dito.

## Art. 5 — Se o anjo possuiu a beatitude imediatamente depois de um ato meritório.
O quinto discute-se assim. — Parece que o anjo não possuiu a beatitude imediatamente depois de um
ato meritório.

1. — Pois é mais difícil ao homem do que ao anjo obrar bem. Ora, o homem não é premiado
imediatamente depois de cada ato. Logo, nem o anjo.

2. Demais. — O anjo imediata e instantaneamente, desde o princípio da sua criação, já era ativo, pois,
mesmo os corpos naturais começam a mover-se no instante mesmo da sua criação; e se o movimento
do corpo pudesse ser instantâneo, como a operação do intelecto e da vontade, teria ele o movimento
desde o primeiro instante da sua geração. Se, portanto, o anjo mereceu a beatitude por um movimento
da sua vontade, mereceu-a no primeiro instante da sua criação. Logo, se a beatitude dos anjos não sofre
demora, foram bem-aventurados imediatamente, desde o primeiro instante.

3. Demais. — Entre corpos muito distantes uns dos outros deve haver muitos meios. Ora, o estado de
beatitude dos anjos muito dista do estado de natureza dos mesmos. Ora, o meio entre um e outro
estado é o mérito. Logo, é necessário tenha o anjo chegado à beatitude por muitos méritos.
Mas, em contrário. A alma do homem e o anjo se ordenam semelhantemente à beatitude, sendo por
isso prometida aos santos a igualdade com os anjos. Ora, à alma separada do corpo, se mereceu a
beatitude, imediatamente a consegue, não havendo nenhum impedimento. Logo, por igual razão
também o anjo. Ora, este, pelo primeiro ato de caridade, ganhou o mérito da beatitude. Logo, como não
havia nenhum impedimento, o anjo chegou à beatitude por um só ato meritório.

SOLUÇÃO. — O anjo, imediatamente depois do primeiro ato de caridade, pelo qual mereceu a
beatitude, foi bem-aventurado. E a razão está em que a graça aperfeiçoa a natureza ao modo desta,
assim como toda perfeição é recebida pelo perfectível ao modo deste. Ora, o próprio à natureza
angélica é o adquirir a perfeição natural, não sucessivamente, mas por natureza e imediatamente, como
antes se demonstrou. Assim, pois, como o anjo por natureza se ordena à perfeição natural, assim pelo
mérito se ordena à glória. Por onde, imediatamente depois do mérito, conseguiu a beatitude. Ora, o
mérito da beatitude, não só no anjo, como também no homem, pode existir por um único ato; pela
merecer o homem por qualquer ato informado da caridade. Donde se conclui que, imediatamente
depois de um ato informado pela caridade, o anjo tornou-se bem-aventurado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O homem, por natureza, não foi criado para alcançar
imediatamente a última perfeição, como o anjo. E por isso foi-lhe traçada uma via mais longa, para
merecer a beatitude, do que ao anjo.

RESPOSTA À SEGUNDA. — O anjo está fora do tempo que mede as coisas corpóreas. Por isso os
instantes diversos, no atinente aos anjos, não se compreendem senão pela sucessão dos atos dos
mesmos. Ora, não podiam simultaneamente ter o ato meritório da beatitude e o ato desta, que é a
fruição, por pertencer aquele à graça imperfeita e este, à consumada. Donde se conclui que se devem
admitir diversos instantes, num dos quais mereceu o anjo a beatitude e, noutro, tornou-se beato.

RESPOSTA À TERCEIRA. — É da natureza do anjo conseguir a perfeição à qual se ordena,
imediatamente. Por onde, não se requer senão um só ato meritório, que pode ser chamado meio, por se
ordenar o anjo, por ele, à beatitude.

## Art. 6 — Se os anjos conseguiram a graça e a glória conforme a quantidade das suas capacidades naturais.
O sexto discute-se assim. — Parece que os anjos não conseguiram a graça e a glória conforme a
quantidade das suas capacidades naturais.

1. — Pois a graça é dada pela mera vontade de Deus. Logo, também a quantidade de graça depende da
vontade de Deus e não da quantidade das suas capacidades naturais.

2. Demais. — Mais próximo está da graça o ato humano do que a natureza, pois aquele é preparatório
da graça. Mas esta não provém das obras, como diz a Escritura. Logo, com maior razão, a quantidade da
graça, nos anjos, não é segundo a quantidade das suas capacidades naturais.

3. Demais. — O homem e o anjo se destinam por igual à beatitude ou graça. Ora, ao homem não é dada
mais graça, segundo o grau das suas capacidades naturais. Logo, nem ao anjo.
Mas, em contrário, diz o Mestre das Sentenças que os anjos criados mais sutis, pela natureza, e mais
perspicazes, pela sabedoria, também foram dotados de maiores capacidades da graça.

SOLUÇÃO. — é racionável sejam a graça e a perfeição da beatitude dadas aos anjos segundo o grau das
suas capacidades naturais. E a razão disso é dupla. — A primeira se deduz da parte do próprio Deus que,
na ordem da sua sabedoria, constituiu diversos graus em a natureza angélica. Ora, como esta foi feita
por Deus para conseguir a graça e a beatitude, assim também os graus dessa natureza foram ordenados
aos diversos graus da graça e da glória. Do mesmo modo que se o edificador polir pedras para construir
uma casa, o fato mesmo de polir algumas mais belas e artisticamente mostra que as destina a uma parte
mais nobre da casa. Donde, resulta que Deus ordenou a maiores dons da graça e a mais ampla beatitude
os anjos, que fez de mais elevada natureza. — Em segundo lugar, o mesmo resulta por parte do próprio
anjo. Pois, este não é composto de diversas naturezas, de modo que a inclinação de uma impeça ou
retarde a tendência de outra, como acontece com o homem, no qual o movimento da parte intelectiva é
retardado ou impedido pela inclinação da parte sensitiva. Quando, porém, não há nada que a retarde ou
impeça, a natureza se move para o seu objeto segundo toda a sua virtude. Por onde, é racional que os
anjos dotados de melhor natureza se convertessem para Deus mais forte e eficazmente. E isto também
se dá com os homens, pois, segundo a intenção de converterem-se para Deus, é-lhes dada maior graça e
glória. Donde se conclui que os anjos dotados de melhores capacidade naturais tiveram mais graça e
glória.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como a graça, também a natureza do anjo provém
da mera vontade de Deus. E assim como esta ordenou para a graça a natureza, assim também os graus
da natureza para os da graça.

RESPOSTA À SEGUNDA. — Os atos da criatura racional desta mesma promanam; mas a natureza vem
imediatamente de Deus. Donde, mais racional é seja a graça dada conforme o grau da natureza, do que
segundo as obras.

RESPOSTA À TERCEIRA. — A diversidade das capacidades naturais é uma nos anjos, especificamente
diferentes, e outra nos homens, só numericamente diferentes. Pois, a diferença específica é formal, mas
a numérica, material. Por onde, no homem há alguma coisa que pode impedir ou retardar o movimento
da natureza intelectiva; não, porém, nos anjos. E, por isso, não é a mesma a razão num e noutro caso.

## Art. 7 — Se os anjos beatos conservam o conhecimento e a dileção naturais.
O sétimo discute-se assim. — Parece que os anjos beatos não conservam o conhecimento e a dileção
naturais.

1. — Pois, diz a Escritura: Mas quando vier o que é perfeito, abolido será o que é em parte. Ora, a
dileção e o conhecimento natural são imperfeitos, por comparação com o conhecimento e a dileção da
beatitude. Logo, com a beatitude, cessa esse conhecimento e essa dileção.

2. Demais. — Quando uma só coisa basta, é supérflua outra. Ora, aos santos anjos basta o
conhecimento e a dileção da beatitude. Logo, seria supérflua a subsistência neles do conhecimento e da
dileção naturais.

3. Demais. — A mesma potência não tem simultaneamente dois atos, como uma linha não termina, pelo
mesmo lado, em dois pontos. Ora, os santos anjos estão sempre em ato de conhecimento e de dileção
bem-aventurada; pois a felicidade não é habitual, mas atual, como diz Aristóteles. Logo, os anjos nunca
podem ter conhecimento e dileção naturais.
Mas, em contrário. — Enquanto permanecer uma natureza lhe permanece a operação. Ora, a beatitude
não destrói a natureza, da qual é a perfeição. Logo não destrói o conhecimento e a dileção naturais.

SOLUÇÃO. — Os anjos bem-aventurados conservam o conhecimento e a dileção naturais. Pois, a relação
mútua existente entre os princípios das operações existe também entre estas. Ora, é manifesto, a
natureza está para a beatitude como o que é primeiro para o que é segundo; pois, esta se acrescenta
àquela. Mas, como o que é primeiro se deve sempre encontrar no que é segundo, resulta se deve
conservar a natureza na beatitude. E que semelhantemente, é forçoso que, no ato da beatitude, se
conserve o da natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A perfeição superveniente destrói a imperfeição que lhe
for oposta. Ora, a imperfeição da natureza não se opõe à perfeição da beatitude, mas nela se subsume;
assim como a imperfeição da potência se subsume na da forma, ficando eliminada pela forma, não a
potência, mas a privação, oposta à forma. E também, semelhantemente, a imperfeição do
conhecimento natural não se opõe à perfeição do conhecimento da glória, pois nada impede conhecer
alguma coisa simultaneamente, por meios diversos; assim, uma coisa pode ser conhecida
simultaneamente pelo meio provável e pelo demonstrativo. E semelhantemente, o anjo pode conhecer
a Deus, simultaneamente, pela essência deste — e nisso consiste o conhecimento da glória, e pela
essência própria, o que respeita ao conhecimento da natureza.

RESPOSTA À SEGUNDA. — Os atributos da beatitude são auto-suficientes; mas, para existirem,
preexigem os da natureza; pois, nenhuma beatitude, salvo a incriada, é subsistente por si.

RESPOSTA À TERCEIRA. — Duas operações não podem promanar simultâneamente de uma só potência,
a menos que uma se ordene à outra. Ora, o conhecimento e a dileção naturais ordenam-se ao
conhecimento e à dileção da glória. Por onde, nada impede tenha o anjo o conhecimento e a dileção
naturais e o conhecimento e a dileção da glória.

## Art. 8 — Se o anjo bem-aventurado pode pecar.
O oitavo discute-se assim. — Parece que o anjo bem-aventurado pode pecar.

1. — Pois, a beatitude não suprime a natureza, como se disse. Ora, da essência da natureza criada é ser
deficiente. Logo, o anjo bem-aventurado pode pecar.

2. Demais. — As potências racionais são relativas a termos opostos, como diz o Filósofo. Ora, a vontade
do anjo beato nunca deixa de ser racional. Logo, é relativa ao bem e ao mal.

3. Demais. — Pelo livre arbítrio o homem pode escolher o bem e o mal. Ora, a liberdade do arbítrio não
diminui nos anjos beatos. Logo, podem pecar.
Mas, em contrário, diz Agostinho, que nos santos anjos há a natureza, que não pode pecar. Logo, não
podem pecar.

SOLUÇÃO. — Os anjos bem-aventurados não podem pecar, pois a beatitude deles consiste em ver a
essência de Deus. Ora, esta é a essência mesma da bondade. Donde, o anjo que vê a Deus está para o
próprio Deus, como está para a noção comum do bem quem quer que não vê a Deus. Ora, é impossível
que alguém queira ou faça alguma obra sem visar o bem; ou que queira se desviar do bem como tal.
Logo, o anjo beato, não podendo querer ou agir sem visar a Deus, não pode, assim querendo ou agindo,
pecar. Por onde, o anjo beato de nenhum modo pode pecar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O bem criado, em si considerado, pode ser deficiente.
Mas pela união perfeita com o bem incriado, como é a união da felicidade, ele consegue não poder
pecar, pela razão supra dita.

RESPOSTA À SEGUNDA. — As virtude racionais são relativas a termos opostos quanto ao a que não
estão naturalmente ordenadas; não, porém, quanto ao a que estão. Assim, o intelecto não pode deixar
de assentir aos princípios naturalmente conhecidos; e semelhantemente, a vontade não pode deixar de
aderir ao bem, como tal, porque está naturalmente ordenada para ele como para o seu objeto.
Portanto, a vontade dos anjos é relativa a termos opostos, quanto a fazer ou não fazer muitas coisas.
Mas, quanto a Deus mesmo, que vêem como sendo a própria essência da bondade, não são relativos a
termos opostos; antes, conformando-se com Deus, se dirigem a tudo, sejam quais forem os opostos que
escolham; e nisso não há pecado.

RESPOSTA À TERCEIRA. — O livre arbítrio está para a eleição dos meios como o intelecto para as
conclusões. Ora, como é manifesto pela sua virtude o intelecto pode proceder a diversas conclusões
segundo os princípios dados; mas, se proceder a alguma conclusão preterindo a ordem dos princípios
será isso defeito seu. Por onde, à perfeição da liberdade do arbítrio pertence o poder de eleger diversos
meios, conservada a ordem do fim; mas, será um defeito da sua liberdade se eleger algum meio
divertindo da ordem do fim, e pecando. Donde, maior é a liberdade do arbítrio nos anjos, que não
podem pecar, do que em nós, que podemos.

## Art. 9 — Se os anjos beatos podem progredir na beatitude.
O nono discute-se assim. — Parece que os anjos beatos podem progredir na beatitude.

1. — Pois, a caridade é o princípio do mérito. Ora, os anjos têm a caridade perfeita. Logo, os anjos
beatos podem merecer. Ora, crescendo com o mérito o prêmio da beatitude, os anjos beatos podem
progredir nesta.

2. Demais. — Agostinho diz que Deus usa de nós para a nossa utilidade e para a sua bondade; e
semelhantemente, dos anjos, dos quais usa nos ministérios espirituais, pois eles são espíritos
administradores, mandados ao ministério por causa dos que recebem a herança da salvação, conforme
a Escritura. Ora, isso em nada lhes seria útil, se por aí não merecessem nem progredissem na beatitude.
Conclui-se, portanto, que os anjos beatos podem merecer e progredir na beatitude.

3. Demais. — Só por imperfeição não pode progredir aquele que não está no sumo grau. Ora, neste grau
não estão os anjos. Logo, se não podem progredir, resulta que há neles imperfeição e defeito, o que é
inconveniente.
Mas, em contrário, merecer e progredir é próprio do estado do viandante. Ora, os anjos não são
viandantes, mas compreensores. Logo, os anjos beatos não podem merecer e nem progredir na
beatitude.

SOLUÇÃO. — Em qualquer momento, a intenção do motor visa um fim determinado, ao qual pretende
conduzir o móvel; pois, a intenção visa o fim, ao qual repugna o processo ao infinito. Ora, é manifesto,
não podendo a criatura racional atingir a beatitude, consistente na visão de Deus, pela sua virtude,
como resulta do supradito, ela necessita ser conduzida por Deus à beatitude. Logo, é forçoso haver algo
de determinado ao que qualquer criatura racional seja dirigida, como ao último fim. Mas, esse algo
determinado não pode se referir, na visão divina, ao objeto mesmo visto, pois a sua verdade é
contemplada, em graus diversos, por todos os bem-aventurados. Porém, quanto ao modo da visão, o
termo é de diversos modos prefixado, segundo a intenção do dirigente ao fim. Pois, por ser a criatura
racional levada a ver a suma essência, não é possível seja levada ao sumo modo da visão, que é a
compreensão, modo que só a Deus pode convir, como resulta do sobredito. Mas, sendo necessária
eficácia infinita para compreender a Deus, e a eficácia da criatura na visão, não podendo ser senão
finita, de infinitos modos, mais ou menos claramente, pode a criatura racional inteligir a Deus, dado que
qualquer finito diste, em infinitos graus, do infinito. E como a beatitude consiste na visão mesma, assim
o grau daquela consiste num certo modo desta. Portanto, toda criatura racional é conduzida por Deus
ao fim da beatitude, de modo a alcançar um certo grau desta, por predestinação divina; e conseguido
esse grau, não pode atingir outro mais elevado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O merecer é próprio do que se move para um fim. Ora, a
criatura racional move-se para um fim, não somente padecendo, mas também operando. E se esse fim
estiver ao alcance da sua operação, esta se considera aquisitiva do fim; assim o homem, meditando,
adquire a ciência. Se porém o fim não lhe estiver ao alcance, mas for esperado em virtude de outro, a
operação será meritória do fim. Mas, ao que está no último termo não lhe convém o mover-se, mas o
ser movido. Por onde, da caridade imperfeita, que é a da via, é próprio o merecer; porém, da perfeita é
o próprio, não o merecer, mas fruir do prêmio. Do mesmo modo que, nos hábitos adquiridos, a
operação precedente ao hábito é aquisitiva deste; porém, a proveniente do hábito já adquirido é a
operação perfeita acompanhada do prazer. E semelhantemente, o ato da caridade perfeita não tem a
natureza do mérito, mas, antes, pertence à perfeição do prêmio.

RESPOSTA À SEGUNDA. — De dois modos se diz que uma coisa é útil. De um, como via para o fim; assim
é útil o mérito da beatitude. De outro, como a parte é útil ao todo; assim as paredes, à casa; e deste
modo, os ministérios dos anjos são úteis aos anjos beatos, enquanto parte da beatitude deles; pois é da
natureza do perfeito, como tal, difundir em outros a perfeição adquirida.

RESPOSTA À TERCEIRA. — Embora o anjo beato não esteja, no sumo grau da beatitude absoluta, está
todavia no último, quanto a si mesmo, por predestinação divina. Contudo, a alegria dos anjos pode ser
aumentada por causa da salvação dos salvos, pelo ministério deles, conforme a Escritura: Haverá júbilo
entre os anjos de Deus por um pecador que faz penitência. Mas essa alegria respeita o prêmio acidental,
que certamente pode aumentar até o dia do juízo. De onde vem o dizerem certos que os anjos também
podem merecer, quanto ao prêmio acidental. Melhor, porém é dizer-se que o bem-aventurado de
nenhum modo pode merecer, a menos que não seja simultaneamente viador, como Cristo que, único,
foi viador e compreensor. Ora, a alegria predita é, antes, adquirida do que merecida em virtude da
beatitude.