# Questão 41: Das Pessoas em relação aos atos nocionais.
Em seguida devemos tratar das Pessoas em relação aos atos nocionais. E nesta questão, discutem-se
seis artigos:

## Art. 1 — Se os atos nocionais se devem atribuir às Pessoas.
O primeiro discute-se assim. – Parece que os atos nocionais não se devem atribuir às pessoas.

1. – Pois, diz Boécio, que todos os gêneros aplicados à divina predicação, transformam-se na substância
divina, exceto os relativos. Ora, a ação é um dos dez gêneros. Se, pois, alguma ação é atribuída a Deus,
pertencer-lhe-á à essência e não, à noção.

2. Demais. – Agostinho ensina, que tudo o que se diz de Deus, substancial ou relativamente se diz. Ora,
o que respeita à substância é expresso pelos atributos essenciais; porém o que respeita à relação é
expresso pelos nomes das pessoas e pelos das propriedades. Logo, além destas atribuições, não se
devem atribuir às pessoas os atos nocionais

3. Demais. – É próprio da ação provocar a paixão. Mas, em Deus, não se admitem paixões. Logo, nem se
devem nele admitir atos nocionais.
Mas, em contrário,diz Agostinho (Fulgêncio): É próprio certamente do Pai o ter gerado o Filho. Ora, a
geração é um determinado ato. Logo, devemos admitir em Deus atos nocionais .

SOLUÇÃO. – Nas Pessoas divinas, considera-se a distinção relativamente à origem. Ora, a origem não
pode ser convenientemente designada senão por certos atos. Por onde, para exprimir a ordem da
origem, nas Pessoas divinas, é necessário atribuírem-se às Pessoas atos nocionais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Toda origem é designada por algum ato. Ora, a Deus
pode ser atribuída uma dupla ordem de origem. Uma, enquanto a criatura dele procede, o que é comum
às três Pessoas. Por onde, as ações atribuídas a Deus, para designar a processão das criaturas, dele,
pertencem à essência. Porém, considera-se em Deus outra ordem de origem enquanto uma Pessoa
procede de outra. Por isso, os atos que designam a ordem dessa origem são nocionais, porque
as noções das Pessoas são as relações mútuas delas, como do sobredito resulta.

RESPOSTA À SEGUNDA. – Os atos nocionais, considerados somente no seu modo de significar, diferem
das relações das Pessoas; mas, na realidade, são-lhes absolutamente idênticos. Por isso, diz o Mestre
das Sentenças, que a geração e a natividade se chamam, por outros nomes, paternidade e filiação. –
Para evidenciá-lo devemos atender a que, primeiramente, podemos atribuir a origem de uma coisa, a
outra, pelo movimento. Pois é claro que só ao movimento, como causa, podemos atribuir a modificação,
que um ser sofreu nas suas disposições. Por onde, a ação, na sua significação primária, importa origem
do movimento. Pois, assim como o movimento, enquanto existente num móvel e procedente de outro,
chama-se paixão, assim também, a origem desse mesmo movimento, enquanto causada por outro
movimento e terminada no móvel, chama-se ação.Por onde, removido o movimento, a ação nada mais
implica senão a ordem da origem, enquanto que o proveniente de um princípio procede de alguma
causa ou princípio. Por isso, como em Deus não há movimento, a ação pessoal de quem produz a Pessoa
não é senão os modos de se haver do princípio para com a Pessoa oriunda desse principio. E tais modos
são as próprias relações ou noções. Mas, como nós não podemos falar das coisas divinas e inteligíveis
senão ao modo das coisas sensíveis, das quais tiramos o conhecimento e cujas ações e paixões,
enquanto implicam movimento, diferem das relações resultantes dessas ações e paixões; foi necessário
exprimir os modos de se haver das Pessoas, separadamente, como atos e como relações. E assim é
claro, que são idênticos na realidade, diferindo somente quanto ao modo de significar.

RESPOSTA À TERCEIRA. – A ação, enquanto importa a origem do movimento, implica por si mesma a
paixão. Por isso, não se admite ação nas Pessoas divinas. Por onde, nelas se não admitem paixões, senão
apenas gramaticalmente falando, quanto ao modo de significar; assim como ao Pai atribuímos o gerar e
ao Filho, o ser gerado.

## Art. 2 — Se os atos nocionais são voluntários.
(I Sent., dist. VI; IV Cont. Gent., cap. XI; De Pot., q. 2, a. 3; q. 10, a. 2, ad 4, 5).
O segundo discute-se assim. – Parece que os atos nocionais são voluntários.

1. – Pois, diz Hilário: O Pai gerou o Filho, não levado por uma necessidade natural.

2. Demais. – Diz a Escritura (Cl 1, 13): Transferiu-nos para o reino de seu Filho muito amado. Ora, amar
pertence à vontade. Logo, o Filho foi gerado do Pai, pela vontade.

3. Demais. – Nada é mais voluntário do que o amor. Ora, o Espírito Santo procede do Pai e do Filho,
como Amor. Logo, procede voluntariamente.

4. Demais. – O Filho, como Verbo, procede intelectualmente. Ora, todo verbo procede do dicente, pela
vontade. Logo, o Filho procede do Pai pela vontade e não, pela natureza.

5. Demais. – O que não é voluntário é necessário; se, pois, não foi pela bondade que o Pai gerou o Filho,
resulta que o gerou necessàriamente, o que vai contra Agostinho.
Mas, em contrário,diz Agostinho, que o Pai não gerou o Filho pela bondade, nem por necessidade.

SOLUÇÃO. – Quando dizemos que uma coisa existe ou a fazemos pela nossa vontade, isso pode se
entender de duplo modo. De um modo, designando pela preposição só a concomitância; e assim posso
dizer, que sou homem pela minha vontade, a saber, porque quero ser homem. E neste sentido podemos
dizer que o Pai gerou o Filho, pela vontade, assim como é Deus pela vontade, pois quer ser Deus e quer
gerar o Filho. De outro modo, importando a preposição a relação de princípio, e assim se diz que o
artífice opera pela vontade, porque a vontade é o principio da obra. E deste modo dizemos que Deus Pai
não gerou o Filho pela vontade, mas, produziu pela vontade a criatura. Donde o cânon do sínodo
Sirmiense: Se alguém disser, que o Filho foi feito pela vontade de Deus, como qualquer das criaturas,
seja anátema.
E a razão disto é que a vontade e a natureza, como causas, diferem, por ser esta determinada a um
efeito, e aquela, não. Pois, o efeito é assimilado à forma pela qual o agente age. Ora, é manifesto, que
uma coisa só tem uma forma natural, pela qual recebe o ser; por onde, age segundo o que é. Mas, a
forma pela qual a vontade age não é somente uma, senão várias, segundo forem várias as noções
inteligidas. Por isso, o que é feito pela vontade não se identifica com o agente, mas é tal qual o agente
quer e entende que o seja. Assim, a vontade é princípio de efeitos, que podem se revestir de
modalidades diferentes. Porém, daqueles que não têm senão um modo de ser, desses o princípio é a
natureza.
Ora, o poder ser de um ou outro modo, absolutamente não convém à natureza divina; ao contrário, isso
é próprio à essência da criatura; pois Deus existe necessariamente e por si, ao passo que a criatura foi
feita do nada. Por isso os Arianos, querendo concluir que o Filho é criatura, disseram que o Pai o gerou
pela vontade, entendendo por vontade o princípio. Nós, porém, devemos dizer que o Pai gerou o Filho,
não pela vontade, mas pela natureza. Donde a explicação de Hilário: A vontade de Deus deu a natureza
ao Filho, nascido de umasubstância impassível e ingênita. Pois, todas as coisas foram criadas tais quais
Deus as quis; porém o Filho, nascido de Deus, subsiste como convém a Deus.

RESPOSTA À PRIMEIRA OBJEÇÃO. – A autoridade aduzida colhe contra os que privavam a geração do
Filho também da concomitância da vontade paterna, dizendo, que o Pai gerou por natureza o Filho sem,
todavia, nele existir a vontade de o gerar; do mesmo modo que nós padecemos muitas coisas por
necessidade natural, contra a nossa vontade, como a morte, a velhice e misérias semelhantes. Ora, o
contrário é bem claro pelo que precede e se segue. Pois aí se lê: O Pai não gerou o Filho, sem querer e
quase coagido, ou levado por necessidade natural.

RESPOSTA À SEGUNDA. – O Apóstolo chama a Cristo o Filho muito amado de Deus, por ser de Deus
superabundantemente dileto; mas não por ser o amor o princípio da geração do Filho.

RESPOSTA À TERCEIRA. – Também a vontade, como natureza, quer certas coisas, naturalmente; assim,
a vontade do homem naturalmente tende à felicidade. E, semelhantemente, Deus quer-se e ama-se a si
mesmo. Mas, quanto ao que é diferente de si, a vontade de Deus é livre, de certo modo, como dissemos
(q. 19, a. 3). Porém, o Espírito Santo procede como Amor, enquanto Deus se ama a si mesmo. Por onde,
procede, naturalmente, embora proceda ao modo da vontade.

RESPOSTA À QUARTA. – Mesmo nas concepções intelectuais, fazemos a redução aos primeiros
princípios, que são naturalmente intelígidos. Ora, Deus naturalmente se intelige a si mesmo. Logo, neste
sentido, a concepção do Verbo divino é natural.

RESPOSTA À QUINTA. – O necessário ou é essencial ou acidentalmente. – Acidentalmente, de duplo
modo. Como por uma causa agente e necessitante; assim, dizemos ser necessário o que é violento. Ou
como por causa final; assim o meio conducente ao fim se chama necessário, por não podermos, sem ele,
alcançar o fim ou o alcançarmos como devemos. Ora, de nenhum destes modos a geração divina é
necessária, porque Deus não existe para um fim, nem se concebe nele a coação. – Porém, diz-se
necessário essencialmente o que não pode deixar de existir; assim é necessária a existência de Deus. E,
deste modo é necessário que o Pai gere o Filho.

## Art. 3 — Se os atos nocionais procedem de algo.
(I Sent., dist. V, q. 2; III, dist. XI, art. 1).
O terceiro discute-se assim. – Parece que os atos nocionais não procedem de algo.

1. – Pois, se o Pai gera o Filho de algo, ou é de si mesmo ou de algum outro. Se de algum outro, como o
ser de que um outro é gerado está nesse outro, segue-se que há no Filho algo de alheio ao Pai. O que vai
contra Hilário quando diz: Nada neles é diverso ou alheio. Ou então o Pai gera de si mesmo o Filho. Ora,
aquilo de que alguma coisa é gerada recebe, sendo subsistente, a predicação dessa coisa; assim, dize-
mos que um homem é branco, porque permanece quando – de não branco se torna branco. Donde se
segue, ou que o Pai não subsiste, gerado o Filho; ou que o Pai é o Filho; o que tudo é falso. Logo, o Pai
não gera o Filho de algo, mas do nada.

2. Demais. – Aquilo de que alguma coisa é gerada é princípio dessa coisa. Se pois o Pai gera o Filho da
Sua essência ou da sua natureza, segue-se que a essência ou a natureza do Pai é o princípio do Filho.
Não, porém, princípio material, pois que em Deus não há lugar para a matéria. Logo, é um como
princípio ativo, como o gerador é princípio do gerado. Donde resulta, que a essência gera; o que antes
foi contestado.

3. Demais. – Agostinho diz, que as três Pessoas não provêm da mesma essência, por não diferirem a
essência e a pessoa. Mas a Pessoa do Filho não é diferente da essência do Pai. Logo, o Filho não provém
da essência do Pai.

4. Demais. – Toda criatura vem do nada. Ora, o Filho na Escritura, é chamado criatura; pois, nela se diz
pela boca da Sabedoria gerada (Ecle 24, 5): Eu saí da boca do Altíssimo, a primogênita antes de todas as
criaturas. E em seguida, pela boca da mesma Sabedoria (Ecle 24, 14): Eu fui criada desde o princípio e
antes dos séculos. Logo, o Filho não foi gerado de algo, mas, do nada. E o mesmo se pode dizer, do
Espírito Santo, segundo a Escritura (Zc 12, 1): Disse o Senhor que estendeu o céu e que fundou a terra e
que formou o espírito do homem dentro nele. E ainda segundo outra letra (Am 4, 13): Eis quem forma
os montes e quem cria o vento.
Mas, em contrário, Agostinho: Deus Padre gerou da sua natureza e sem início o Filho, seu igual.

SOLUÇÃO. – O Filho não foi gerado do nada, mas, da substância do Pai. Pois, como demonstramos, a
paternidade, a filiação e a natividade existem em Deus verdadeira e propriamente. Ora, entre a geração
verdadeira, pela qual se procede como filho, e a produção, há a seguinte diferença: o produzir faz
alguma coisa, da matéria exterior; assim, o artífice faz um escabelo, da madeira; ao passo que o homem
gera um filho, de si mesmo. Mas assim como o artífice criado faz alguma coisa da matéria, assim Deus
faz do nada, como a seguir se demonstrará; e não que se transforme o nada na substância da coisa, mas
porque por si mesmo produz a substância inteira da coisa, sem pressuposição de nenhum outro ser. Se,
pois, o Filho procedesse do Pai, tendo recebido a existência como provindo do nada, estaria para o Pai
como o artificiado, para o artífice; e então é manifesto, que não lhe poderíamos atribuir a filiação
propriamente dita, mas só segundo certa semelhança. Donde resulta que, se o Filho procedesse do Pai,
como existindo do nada, não seria verdadeira e propriamente Filho, contrariamente ao que diz a
Escritura (1 Jo 5, 20): Para que estejamos em seu verdadeiro Filho, Jesus Cristo. Logo, o verdadeiro Filho
de Deus não procede do nada; nem é feito, mas somente gerado.
E se certos se chamarem filhos de Deus, estes feitos do nada, sê-lo-á só metaforicamente, por alguma
assimilação com aquele que verdadeiramente é Filho. Por isso, enquanto só ele é o verdadeiro e natural
Filho de Deus, chama-se unigênito, segundo a Escritura (Jo 1, 18): O Filho unigênito, que está no seio do
Pai, esse é quem o deu a conhecer. Porém, por semelhança com ele, os outros se chamam filhos
adotivos, sendo ele chamado primogênito, por assim dizer metaforicamente, conforme a Escritura (Rm
8, 29): Os que ele conhece na sua presciência também os predestinou para serem conformes à imagem
de seu Filho, para que ele seja o primogênito entre muitos irmãos.
Donde se conclui, que o Filho é gerado da substância do Pai, porém diferentemente dos filhos dos
homens. Pois, parte da substância do gerador passa para a substância do filho. Ao contrário, a divina
natureza é indivisível. Por onde, e necessariamente, o Pai, gerando o Filho, não lhe transfunde nada da
sua natureza, mas lhe comunica a natureza inteira, permanecendo a distinção só pela origem, como
vimos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Quando dizemos que o filho nasceu do Pai, a
preposição designifica o principio generante consubstancial, não porém o princípio material. Pois, o que
é produzido da matéria o é pela transmutação dela em alguma forma. Ora, a divina essência não é
transmutável nem susceptível de outra forma.

RESPOSTA À SEGUNDA. – Quando dizemos que o Filho é gerado da essência do Pai, isso significa,
segundo a exposição do Mestre das Sentenças, a relação de um como princípio ativo. Eis as suas
palavras: O Filho é gerado da essência do Pai, i. é, do Pai-essência; por isso, Agostinho ensina: O que
afirmo do Pai-essência é como se expressamente o afirmasse da essência do Pai. – Mas isto não basta
para explicar o sentido dessa locução. Pois, podemos dizer que a criatura vem de Deus-essência, sem
que todavia proceda da essência de Deus. Por onde e de outro modo, podemos dizer que a
preposição desempre denota a consubstancialidade. Por isso, não dizemos que a casa procede do
arquiteto, por não ser este causa consubstancial. Podemos, porém, dizer que uma coisa procede de
outra, de qualquer modo que esta seja entendida como princípio consubstancial. Quer seja princípio
ativo, como quando dizemos que o filho procede do pai; quer seja princípio material, como quando
dizemos que o cutelo é de ferro; quer seja principio formal, somente nos seres em que as próprias
formas são subsistentes e não, de proveniência intrínseca, podendo assim dizer, que um anjo é de
natureza intelectual. E deste modo dizemos que o Filho é gerado da essência do Pai, enquanto esta,
comunicada ao Filho pela geração, neste subsiste.

RESPOSTA À TERCEIRA. – Quando dizemos que o Filho é gerado da essência do Pai – Fazemos um
acréscimo pelo qual se pode conservar a distinção. Mas quando dizemos que as três Pessoas são da
essência divina – nenhum acréscimo fazemos que possa implicar a distinção expressa pela preposição.
Logo, não é o mesmo caso.

RESPOSTA À QUARTA. – Quando dizemos – a sabedoria é criada – podemos entendê-la, não da
sabedoria que é o Filho de Deus, mas da sabedoria criada, que Deus infundiu nas criaturas. Assim, diz a
Escritura (Ecle 1, 9-10):Ele mesmo é o que a criou, i. é, a sabedoria, no Espírito Santo, e a difundiu por
todas as suas obras. Nem há inconveniente em referir-se a Escritura, num mesmo texto, à sabedoria
gerada e à criada, porque esta é uma certa participação da sabedoria incriada. – Ou essa expressão pode
referir-se à natureza criada assumida pelo Filho, sendo o sentido: Fui criada desde o início e antes de
todos os séculos, i. é, fui prevista como devendo unir-me à criatura. – Ou, quando fala em sabedoria
criada e gerada, insinua-nos o modo da geração divina. Pois na geração, ensina-nos, o gerado recebe a
natureza do gerador, o que é uma perfeição; porém na criação, o criador não muda, mas o criado não
recebe a natureza do criador. Por isso o Filho é considerado simultaneamente criado e gerado, dedu-
zindo-se da criação a imutabilidade do Pai, e da geração a unidade da natureza no Pai e no Filho. E assim
é exposto o sentido dessa passagem da Escritura por Hilário. Quanto às citações aduzidas, elas não
falam do Espírito Santo, mas do espírito criado, que, ora é chamado vento, ora ar, ora sopro do homem,
ora também alma, ou qualquer substância invisível.

## Art. 4 — Se em Deus há potência, quanto aos atos nocionais.
(I Sent., dist. VII. q. 1. a. 1; De Pot., q. 2. a. 1).
O quarto discute-se assim. – Parece que em Deus não há potência, quanto aos atos nocionais.

1. – Pois, toda potência é ativa ou passiva. Ora, nenhuma delas pode convir a Deus, quanto aos atos
nocionais: a passiva nele não existe, como já se demonstrou; a ativa, por seu lado, não convém a uma
Pessoa em relação à outra, por não serem feitas as Pessoas divinas, como se demonstrou. Logo, em
Deus não há potência, quanto aos atos nocionais.

2. Demais. – A potência é relativa ao possível. Ora, as Pessoas divinas não são do número dos possíveis,
mas, dos necessários. Logo, quanto aos atos nocionais, dos quais as divinas Pessoas procedem, não se
deve admitir potência em Deus.

3. Demais. – O Filho procede como Verbo, que é concepção do intelecto; porém o Espírito Santo
procede como Amor, que pertence à vontade. Ora, em Deus, a potência é relativa aos efeitos e não, ao
inteligir e querer, como se estabeleceu. Logo, em Deus deve-se admitir potência, em relação aos atos
nocionais.
Mas, em contrário,Agostinho: Se Deus Padre não pôde gerar o Filho igual a si, onde está a
onipotência de Deus Padre?.Logo, em Deus. há potência, quanto aos atos nocionais.

SOLUÇÃO. – Assim como se admitem atos nocionais em Deus, assim também devemos admitir nele a
potência, quanto a tais atos; pois, esta nada mais significa senão o principio de um ato. Portanto, assim
como inteligimos o Pai, como princípio da geração, e o Pai e o Filho como princípio de inspiração,
necessário é atribuirmos ao Pai a potência de gerar, e ao Pai e ao Filho, a de espirar. Porque a potência
de gerar é o princípio pelo qual o gerador gera; pois, todo gerador gera por algum meio; por onde, é
necessário admitir a potência de gerar em todo gerador. E, no espirante, a potência de espirar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Assim como, quanto aos atos nocionais, nenhuma pessoa
procede, como feita, assim também não há potência, em Deus, quanto aos atos nocionais, em relação à
pessoa feita, mas só em relação à pessoa procedente.

RESPOSTA À SEGUNDA. – O possível, enquanto se opõe ao necessário, resulta da potência passiva, que
não existe em Deus. Por onde, nem em Deus há nada de possível, deste modo; mas só enquanto o
possível está contido no necessário. E assim podemos dizer que, como é possível existir Deus, assim é
possível o Filho ser gerado.

RESPOSTA À TERCEIRA. – Potência significa princípio, e este importa distinção daquilo de que é
princípio. Ora, há uma dupla distinção a fazer, no que dizemos de Deus: uma real e outra, apenas
racional. Assim, realmente, Deus se distingue, por essência, das coisas de que é o princípio, pela criação;
do mesmo modo que uma pessoa se distingue de outra, da qual é o princípio, pelo ato nocional. Mas a
ação não se distingue do agente, em Deus, senão apenas pela razão; do contrário a ação seria nele um
acidente. Logo, relativamente às ações pelas quais certas coisas procedem de Deus e são distintas dele,
essencial ou pessoalmente, a potência pode ser atribuída a Deus, quanto à noção própria de princípio.
Por onde, como admitimos em Deus a potência de criar, podemos também admitir a de gerar ou
espirar. Ora, inteligir e querer não são atos tais, que designem a processão de alguma coisa, de Deus
distinta, essencial ou pessoalmente. Por onde, quanto a tais atos, não se pode atribuir a noção de
potência a Deus, senão apenas racionalmente e quanto ao modo de significar. Pois, em Deus, têm
significações diversas o intelecto e o inteligir, embora o inteligir de Deus seja a sua essência, sem
princípio.

## Art. 5 — Se a potência de gerar ou de espirar significa a relação e não a essência.
(I Sent., dist. VII, q. 1, a. 2; De Pot., q. 2, a. 2).
O quinto discute-se assim. – Parece que a potência de gerar ou de espirar significa a relação e não a
essência.

1. – Pois, potência por definição significa princípio; assim, dizemos que a potência ativa é principio de
agir, como se vê no Filósofo. Ora, a Deus, o princípio, quanto à pessoa só se lhe atribui nocionalmente.
Logo, a potência, em Deus, não significa a essência, mas, a relação.

2. Demais. – Em Deus, não diferem o poder e o agir, Ora, geração, em Deus, significa relação. Logo,
também a potência de gerar.

3. Demais. – O que em Deus significa a essência é comum às três pessoas. Ora, a potência de gerar não é
comum às três pessoas, mas, própria ao Pai. Logo, não significa a essência.
Mas, em contrário,assim como Deus pode gerar o Filho, assim também o quer. Ora, a vontade de gerar
significa a essência. Logo, também a potência de gerar.

SOLUÇÃO. – Certos ensinaram que a potência de gerar significa relação, em Deus. – Mas tal não pode
ser, pois potência propriamente se chama ao princípio pelo qual um agente age. Ora, todo agente que
produz um efeito, pela sua ação, produz o que lhe é semelhante, quanto à forma pela qual age. Assim, o
homem gerado é semelhante ao gerador, pela natureza humana, por cuja virtude o pai pode gerar um
filho. Por onde, pela potência geratriz de qualquer gerador, este se assemelha ao gerado. Ora, o Filho de
Deus se assemelha ao Pai gerador, pela natureza divina. Portanto, a natureza divina, no Pai, é a sua
potência de gerar. Por isso, Hilário diz: A natividade de Deus não pode deixar de ter a natureza da qual
se originou; e nem subsiste diferente de Deus, porque não subsiste por uma causa diferente de Deus.
Donde concluímos, que a potência de gerar significa principalmente a essência divina, como ensina o
Mestre das Sentenças; e não somente, a relação ou a essência, enquanto idêntica à relação, de modo a
significar igualmente esta e aquela. Pois, embora a paternidade seja expressa como forma do Pai,
contudo é propriedade pessoal, estando para a pessoa do Pai como uma forma individual, para um
indivíduo criado. Ora, a forma individual das coisas criadas constitui a pessoa generante; mas não é o
principio pelo qual o generante gera; porque então Sócrates geraria a Sócrates Por onde, nem a pa-
ternidade pode ser concebida como o principio pelo qual o Pai gera; mas, como constituindo a pessoa
do generante, sem o que o Pai geraria o Pai. Ora, o princípio pelo qual o Pai gera é a natureza divina,
pela qual o Filho com ele se assimila. E neste sentido, Damasceno diz, que a geração é obra da
natureza, não como generante, mas como o principio pelo qual o generante gera. Por onde, a potência
de gerar significa diretamente a natureza divina, mas indiretamente, a relação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A potência não significa a relação mesma de princípio, do
contrário estaria no gênero da relação; mas significa princípio, não no sentido em que o agente o é, mas
no em que o é aquilo pelo que o agente age. Ora, o agente distingue-se do seu efeito e o gerador, do
gerado. Mas aquilo pelo que o gerador gera é comum ao gerado e ao gerador; e tanto mais
perfeitamente quanto mais perfeita for a geração. Por onde, sendo a geração divina perfeitíssima, o
princípio pelo qual o gerador gera é-lhe comum com o gerado, e com ele idêntico numericamente, como
nos seres criados. Quando dizemos, pois, que a essência divina é o princípio pelo qual o gerador gera,
não queremos significar que ela se distingue do gerado, como se concluiria se disséssemos que a
essência divina gera.

RESPOSTA À SEGUNDA. – Como em Deus se identifica a potência de gerar com a geração, assim
também a essência divina é realmente idêntica à geração e à paternidade; mas não, racionalmente.

RESPOSTA À TERCEIRA. – Quando digo – potência de gerar, significo a potência diretamente, e,
indiretamente, a geração, como se dissesse – essência do Pai. Por onde, quanto à essência significada, a
potência de gerar é comum às três Pessoas; porém, quanto à noção conotada, é própria à Pessoa do Pai.

## Art. 6 — Se o ato nocional pode ter como termo várias Pessoas, de modo a haver em Deus várias Pessoas geradas ou espiradas.
(I Sent., dist. VII, q. 2; exposit. Litt.; De Pot., q. 2. a. 4: q, 9. a. 9, ad 1 sqq.).
O sexto discute-se assim. – Parece que os atos nocionais podem ter como termo várias pessoas, de
modo a haver em Deus várias pessoas geradas ou espiradas.

1. – Pois, aquele que tem a potência de gerar pode gerar. Ora, o Filho tem a potência de gerar. Logo,
pode gerar. Não porém a si mesmo. Portanto, a outro Filho. Logo, Deus pode ter vários filhos.

2. Demais. – Agostinho diz: O Filho não gerou o Criador. Pois, não que não pudesse, mas não convinha.

3. Demais. – Deus Pai é mais poderoso para gerar do que um pai criado. Ora, um homem pode gerar
vários filhos. Logo, também Deus; tanto mais que a potência do pai não diminui, depois de ter gerado
um filho.
Mas, em contrário, em Deus não difere o ser, do poder; se, pois, Deus pudesse ter vários Filhos, eles
existiriam. E assim existiriam nele mais de três pessoas, o que é herético.

SOLUÇÃO. – Como ensina Atanásio, em Deus há somente um Pai, um Filho, um Espírito Santo. – Do que
podemos dar quatro razões. – A primeira é tirada das relações pelas quais unicamente as pessoas se
distinguem. Pois, sendo as pessoas divinas as próprias relações subsistentes, não poderiam existir vários
Pais ou vários Filhos, em Deus, sem existirem várias paternidades e várias filiações. O que certamente
não seria possível senão pela distinção material das coisas; pois, as formas específicas só se multiplicam
pela matéria, que não existe em Deus. Por onde, em Deus, não pode existir mais de uma filiação
subsistente, assim como a brancura subsistente não pode ser senão uma. – A segunda é tirada das
processões. Porque Deus intelige e quer todas as coisas por um ato simples e uno. Por onde, não pode
haver senão uma pessoa procedente ao modo do verbo, que é o Filho; e senão uma ao modo do amor,
que é o Espírito Santo. – A terceira é tirada do modo de proceder. Porque as pessoas procedem
naturalmente, como se disse, pois a natureza é determinada a um só efeito. – A quarta é tirada da
perfeição das pessoas divinas. Pois, o Filho é perfeito por conter totalmente a filiação divina, porque só
há um Filho. E o mesmo se deve dizer das outras pessoas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora absolutamente falando, devamos conceder que a
potência que tem o Pai também a tem o Filho, não podemos contudo conceder que o Filho tenha a
potência de gerar, se a expressão verbal generandi for gerúndio de um verbo ativo, sendo o sentido, que
o Filho tenha a potência para gerar. Pois, embora o ser seja o mesmo, do Pai e do Filho, todavia não
convém ao Filho ser Pai, por causa do adjunto nocional. Se, porém, a expressão verbal generandi corres-
ponder a um gerúndio de um verbo passivo, tem o Filho a potência de gerar, isto é, de ser gerado. E
semelhantemente, se corresponder ao gerúndio de um verbo impessoal, sendo o sentido – potência de
gerar, isto é, pela qual é gerado por alguma pessoa.

RESPOSTA À SEGUNDA. – Agostinho, com as palavras citadas, não pretende afirmar que o Filho possa
gerar o Filho; mas, que não é por impotência que o Filho não gera, como a seguir se verá.

RESPOSTA À TERCEIRA. – A imaterialidade e a perfeição divina requerem que não possam existir vários
Filhos em Deus, como já se disse. Donde, o não existirem vários Filhos não é por impotência do Pai, para
gerar.