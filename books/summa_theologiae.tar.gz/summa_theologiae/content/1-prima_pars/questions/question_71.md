# Questão 71: Da obra do quinto dia.

## Art. 1 — Se se descreve convenientemente a obra do quinto dia. Em seguida devemos tratar da obra do quinto dia; e parece que esta obra é descrita inconvenientemente.

1. – Pois, as águas só produzem aquilo para o que lhes basta a virtude. Ora, essa virtude não basta para
a produção dos peixes e das aves, pois, muitos deles são gerados seminalmente. Logo, não é com
conveniência que se diz: Produzam as águas répteis animados e viventes e aves que voem sobre a terra.

2. Demais. – Os peixes e as aves não são produzidos somente pela água; antes, na composição deles
parece dominar sobretudo a terra, para onde os seus corpos naturalmente se movem; e por isso na
terra descansam. Logo, sem conveniência se diz que os peixes e as aves são produzidos pela água.

3. Demais. – Como os peixes movem–se na água, assim as aves, no ar. Logo, se aqueles são produzidos
pela água, estas deveriam sê–lo, não por ela, mas pelo ar.

4. Demais. – Nem todos os peixes reptam nas águas; pois, alguns deles têm pés, com que andam em
terra, como as focas. Logo, não se designa suficientemente a produção dos peixes dizendo: Produzam as
águas répteis animados e viventes.

5. Demais. – Os animais terrestres são mais perfeitos que as aves e os peixes. O que bem se vê por
terem membros mais distintos e geração mais perfeita, pois, geram animais; ao passo que os peixes e as
aves põem ovos. Ora, os seres mais perfeitos existem primeiro, na ordem da natureza. Logo, os peixes e
as aves não deviam ter sido feitos no quinto dia, antes dos animais terrestres. Em contrário, basta a
autoridade da Escritura.

SOLUÇÃO. – Como se disse antes, a ordem da obra do ornato corresponde à ordem da distinção. Por
onde, assim como dentre os três dias deputados à distinção, o dia médio, que é o segundo, o foi à
distinção do corpo médio, isto é, as águas; assim, dentre os dias deputados à obra do ornato, o dia
médio, isto é; o quinto, o foi ao ornato do corpo médio, pela produção das aves e dos peixes. Por onde,
assim como Moisés, no quarto dia, menciona os astros e a luz, para designar que o quarto dia
corresponde ao primeiro, em que disse ter sido feita a luz; assim, neste quinto dia, menciona as águas e
o firmamento do céu, para designar que o quinto dia corresponde ao segundo. – Mas, devemos saber
que, assim como relativamente à produção das plantas, Agostinho difere dos outros expositores, assim
também, na das aves e dos peixes. Pois, ao passo que os outros dizem terem sido os peixes e as aves
produzidos, em ato, no quinto dia; Agostinho opina que no quinto dia a natureza das águas produziu,
em potência, os peixes e as aves.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Avicena ensinava, que todos os animais podem ser
gerados por uma certa mistão dos elementos, sem seminação, mesmo por via da natureza. Mas isto é
inadmissível, porque a natureza, procedendo nos seus efeitos por modos determinados, os seres
naturalmente gerados por sem inação não o podem ser sem ela. – Por onde, deve–se dizer,
diferentemente, que na geração natural dos animais, o princípio ativo: é a virtude formativa, que reside
no sémen, para os seres gerados por seminação: em lugar de cuja virtude está a do corpo celeste, nos
seres gerados da putrefacção. E o princípio material, na geração de qualquer dessas duas espécies de
animais, é algum elemento ou algum elementado, Porém, na instituição primeira das coisas, o princípio
ativo foi o Verbo de Deus, que da matéria elementar produziu os animais; quer em ato, segundo os
outros Santos Padres, quer virtualmente, segundo Agostinho (loc, cit.). Não que a água ou a terra
tenham em si a virtude de produzir todos os animais, como ensinou A vicena; mas porque o fado
mesmo de poderem os animais ser produzidos da matéria elementar, por virtude do sémen ou das
estrelas, vem da virtude primitivamente dada aos elementos.

RESPOSTA À SEGUNDA. – Os corpos das aves e dos peixes podem ser considerados de duplo modo. Ou
em si, e então é necessário domine mais neles o elemento terrestre; porque para se fazer o equilíbrio da
comistão no corpo do animal é necessário abunde nele quantitativamente o elemento menos ativo, isto
é, a terra. Ou, considerados enquanto nascidos para se moverem com determinados movimentos;
então, tendo certa afinidade com os corpos nos quais se movem a geração deles é como aqui ficou
descrita.

RESPOSTA À TERCEIRA. – O ar, sendo insensível, não é considerado isoladamente, em si mesmo, mas
junto com os outros seres: parcialmente, com a água, quanto à parte inferior, porque se incrassa com as
exalações dela; e, parcialmente, com o céu, quanto à parte superior. Ora, diz–se que as aves, movendo–
se na parte inferior do ar, voam sob o firmamento do céu, mesmo se firmamento for tomado pelo ar
nebuloso. Por onde, a produção das aves é atribuída à água.

RESPOSTA À QUARTA. – A natureza vai de um extremo a outro, passando pelo meio. Por isso, entre os
celestes e aquáticos, há certos animais médios, com pontos comuns com aqueles e computados com os
que mais comunicam,pelo que os faz comunicarem com estes, e não pelo que o faz com o outro
extremo. Contudo, para incluir todos esses seres, que têm particularidades especiais, entre os peixes,
depois de haver dito: – Produzam as águas répteis animados e viventes; – acrescentou: Deus criou os
grandes peixes etc.

RESPOSTA À QUINTA. – A produção desses animais se ordena pela ordem dos corpos que os adornam,
mais do que pela própria dignidade; e contudo, via da geração, chega–se aos mais perfeitos pelos mais
imperfeitos.