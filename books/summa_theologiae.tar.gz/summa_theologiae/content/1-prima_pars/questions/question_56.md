# Questão 56: Do conhecimento angélico dos seres imateriais.
Em seguida se tratará do conhecimento dos anjos quanto às coisas que conhecem. E, primeiro, do
conhecimento dos seres imateriais. Segundo, do conhecimento das coisas materiais.
Sobre o primeiro ponto três artigos se discutem:

## Art. 1 — Se o anjo se conhece a si mesmo.
(II Cont. Gent., cap. XCVIII; De Verit., q. 8, a. 6; III De Anima, lect. IX; De Causis, lect. XIII)
O primeiro discute-se assim. — Parece que o anjo não se conhece a si mesmo.

1. — Pois, diz Dionísioque os anjos ignoram as próprias virtudes. Ora, conhecida a substância, conhecida
está a virtude. Logo, o anjo não conhece a sua essência.

2. Demais. — O anjo é uma substância singular; do contrário, não agiria, pois, os atos são próprios dos
seres singulares subsistentes. Ora, não sendo nenhum singular inteligível, não pode ser inteligido; e,
assim, como o anjo só tem o conhecimento intelectual, nenhum anjo poderá conhecer-se a si mesmo.

3. Demais. — O intelecto se move pelo inteligível, pois, o inteligir é certo modo de padecer, como diz
Aristóteles. Ora, nada se move ou parede por si mesmo, como se vê pelas coisas corpóreas. Logo, o anjo
não pode inteligir-se a si mesmo.
Mas, em contrário, diz Agostinho, que o anjo, na sua própria conformação, i. é, na iluminação da
verdade se conhece a si mesmo.

SOLUÇÃO. — Como já ficou dito, o objeto comporta-se diferentemente em relação à ação imanente no
sujeito e à transitiva para algo de exterior. Pois, nesta última, o objeto ou a matéria, para a qual passa o
ato, é separada do agente, como, p. ex., o ser aquecido, do que aquece, e o edifício, do edificador. Mas,
para que a ação imanente resulte, é necessário, que o objeto se una com o agente; assim, é necessário
que o sensível se una com o sentido para que este se atualize. De modo que o objeto unido com a
potência, está para tal ação como forma, princípio de ação nos outros agentes; pois, como o calor é o
princípio formal da calefação, no fogo, assim a espécie da coisa vista é o princípio formal da visão nos
olhos.
Mas devemos considerar que tal espécie do objeto, ora está na faculdade cognoscitiva, em potência
somente e, então, esta só em potência conhece; sendo, para que conheça em ato, necessário esteja a
faculdade cognoscitiva reduzida ao ato da espécie. Se, porém, a faculdade tiver a espécie sempre em
ato, então por esta pode conhecer sem nenhuma mutação ou recebimento precedente. Donde resulta
que ser movido pelo objeto não é da essência do ser conhecente como tal, mas enquanto é potência
cognoscitiva. E não importa para ser a forma princípio de ação, que ela própria seja às vezes inerente, e
que seja por si subsistente; pois, o calor não aqueceria menos se fosse por si subsistente, do que aquece
sendo inerente. Portanto, se há algum ser que, no gênero dos inteligíveis, se comporte como forma
inteligível subsistente, esse se intelige a si mesmo. O anjo, porém, sendo imaterial, é uma forma
subsistente e, assim, inteligível em ato. Donde resulta que, pela sua forma, que é a sua substância,
intelige-se a si mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A citação é de antiga tradução, corrigida pela nova, que
diz:além disso também eles mesmos, i e., os anjos, terem conhecido as próprias virtudes; e em lugar
disto estava na antiga tradução: e alem disso eles ignorarem as próprias virtudes. Embora também se
possa conservar a letra da antiga tradução, quanto à este ponto, que os anjos não conhecem
perfeitamente a sua virtude, enquanto procedente da ordem da sabedoria divina, para eles
incompreensível.

RESPOSTA À SEGUNDA. — Nós não inteligimos as coisas corpóreas singularmente, não em razão da
singularidade, mas da matéria que é nelas o princípio de individuação. Donde, se alguns seres singulares
forem subsistentes, sem matéria, como os anjos, nada impede que sejam inteligíveis em ato.

RESPOSTA À TERCEIRA. — Ser movido e padecer convêm ao intelecto em potência; por isso, não tem
lugar no intelecto angélico, sobretudo quanto ao inteligir-se este a si mesmo. Pois, a ação do intelecto
não é da mesma natureza que a dos corpos, transeunte para outra matéria.

## Art. 2 — Se um anjo conhece outro.
(II Cont. Gent., cap. XCVIII; De Verit., q. 8, art 7)
O segundo discute-se assim. — Parece que um anjo não conhece outro.

1. — Pois, diz o Filósofo que, se o intelecto humano encerrasse em si alguma natureza do número das
naturezas das coisas sensíveis, essa, existente interiormente, impediria a manifestação de naturezas
estranhas; do mesmo modo que, se a pupila fosse colorida de uma certa cor, não poderia ver todas as
cores. Ora, o intelecto humano se comporta, como o angélico, no conhecimento das coisas corpóreas,
como o angélico, no dos seres imateriais. Ora, como este encerra em si uma determinada natureza, do
número das naturezas imateriais, resulta que não pode conhecer outros.

2. Demais. — Toda inteligência conhece o que lhe é superior, enquanto por este causada; e o que lhe é
inferior, enquanto o causa. Ora, um anjo não é a causa do outro. Logo, um não conhece outro.

3. Demais. — Um anjo não pode, pela sua própria essência, como conhecente, conhecer outro; pois,
todo conhecimento supõe a razão de semelhança, e a essência do anjo conhecente, não sendo
semelhante à do conhecido, senão genericamente, como já vimos, resulta que um anjo não teria de
outro conhecimento próprio, mas só geral. E também, do mesmo modo, não se pode dizer que um anjo
conheça outro pela essência do conhecido, pois o pelo que o intelecto intelige lhe é intrínseco e só a
Trindade é extrinsecamente interior à inteligência angélica. Semelhantemente, ainda, não se pode dizer
que um anjo conhece outro por uma espécie, pois esta, sendo imaterial, como o anjo inteligido, deste
não difere, logo, de nenhum modo pode um anjo conhecer outro.

4. Demais. — Se um anjo inteligisse outro, ou seria por uma espécie inata e, então, se Deus criasse um
novo anjo este não poderia ser conhecido pelos já existentes; ou por uma espécie adquirida das coisas
e, então, resultaria que os anjos superiores não poderiam conhecer os inferiores, dos quais nada
recebem. Logo, de nenhum modo, um anjo pode conhecer outro.
Mas, em contrario, é o dito: toda inteligência conhece as coisas que se não corrompem.

SOLUÇÃO. — Como diz Agostinho, de duplo modo efluiram do Verbo de Deus as coisas nele existentes
abeterno: para o intelecto angélico, e como subsistentes na sua própria natureza. Efluiram para o
intelecto angélico por lhe ter impresso as semelhanças das coisas que criou no ser natural. Porém, no
Verbo de Deus, existiram, existiram não só as noções das coisas corpóreas mas também as de todas as
criaturas espirituais. Assim, pois, em cada uma destas criaturas espirituais foram impressas pelo Verbo
de Deus a noções de todas as coisas, tanto corpóreas como espirituais. Todavia, por tal arte que, em
cada anjo fosse impressa a noção da sua espécie, segundo a existência natural e intelectual,
simultaneamente; de modo que o anjo subsistisse em a natureza de sua espécie, inteligindo-se por esta
espécie. Porém, as noções de outras naturezas, tanto espirituais como naturais foram impressas no anjo
somente segundo a existência intelectual, de modo que o anjo, por tais espécies impressas, conhecesse
tanto as criatura corpóreas como as espirituais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — as naturezas espirituais dos anjos se distinguem umas
das outras por uma certa ordem, como já se disse. Assim que a natureza de um anjo não lhe impede o
intelecto de conhecer outras naturezas angélicas; pois tanto os superiores como os inferiores têm-lhe
afinidade com a natureza, existindo diferença somente quanto aos diversos graus de perfeição.

RESPOSTA À SEGUNDA. — A relação de causa e a de causado não faz com que um anjo conheça outro,
senão em razão da semelhança, enquanto causa e causado são semelhantes. Donde, admitindo-se entre
os anjos semelhança sem causalidade, haverá em um o conhecimento do outro.

RESPOSTA À TERCEIRA. — Um anjo conhece outro pela espécie deste, existente no intelecto daquele, e
a qual difere de outro anjo, de quem é semelhança, não pela existência material e imaterial, mas pela
natural e intencional. Pois, é o anjo mesmo que é forma subsistente, com existência natural, e não a sua
espécie, existente no intelecto de outro anjo, no qual ela tem existência inteligível somente; do mesmo
modo que a forma da cor, na parede, tem existência natural, tendo, entretanto, no meio que a
transmite, existência intencional somente.

RESPOSTA À QUARTA. — Deus fez cada criatura proporcionada ao universo que quis criar. Por onde, se
Ele tivesse determinado fazer mais anjos ou mais naturezas das coisas, teria impresso nas mentes
angélicas mais espécies inteligíveis; do mesmo modo que o edificador, querendo fazer uma casa maior,
far-lhe-ia maior o fundamento. Assim a razão porque Deus acrescentasse alguma criatura ao universo
seria também a de acrescentar mais alguma espécie inteligível ao anjo.

## Art. 3 — Se os anjos, pelas suas faculdades naturais, podem conhecer a Deus.
(II Sent., dist. XXIII, q. 2, a. 1; III Cont. Gent., cap. XLI, XLIX; De Verit., q. 8, a. 3)
O terceiro discute-se assim. — Parece que os anjos, pelas suas faculdades naturais, não podem
conhecer a Deus.

1. — Pois, Dionísio diz, que Deus está colocado, por uma virtude incompreensível, sobre todas as
inteligências celestes. E, em seguida, acrescenta que, por estar acima de toda substância, está
segregado de todo conhecimento.

2. Demais. — Deus dista infinitamente do intelecto angélico. Ora, seres infinitamente distantes não
podem ser atingidos. Logo, resulta que o anjo, pelas suas faculdades naturais, não pode conhecer a
Deus.

3. Demais. — A Escritura diz (1 Cor 13, 12): Nós agora vemos a Deus como por um espelho, em enigmas;
mas então face a face. Donde resulta que há um duplo conhecimento de Deus. Por um, Deus é visto na
sua essência, no sentido em que se diz vê-lo face a face; por outro, é visto no espelho das criaturas. Ora,
conhecer a Deus, pelo primeiro modo, o anjo não o pode pelas suas faculdades naturais, como já antes
se demonstrou. E quanto à visão especular, ela não convém aos anjos, que não conhecem as coisas
divinas pelas coisas sensíveis, como diz Dionísio. Logo, pelas suas faculdades naturais, não podem
conhecer a Deus.
Mas, em contrario, os anjos têm maior poder de conhecimento que os homens. Ora, estes, pelas
faculdades naturais, podem conhecer a Deus, segundo a Escritura (Rm 1, 19): Porque o que se pode
conhecer de Deus é-lhes manifesto. Logo, com maior razão, os anjos.

SOLUÇÃO. — Os anjos podem ter, pelas suas faculdades naturais, algum conhecimento de Deus. Para a
evidencia do que, devemos considerar nos três modos pelos quais se pode conhecer alguma coisa. De
um modo, pela presença da essência da coisa no conhecente, como a luz é vista nos olhos; e, assim, se
diz que o anjo se intelige a si mesmo. De outro modo, pela presença da semelhança da coisa na potência
cognoscitiva; como uma pedra é vista pelos olhos, por estar nestes a semelhança dela. De um terceiro
modo, enquanto a semelhança da coisa conhecida não é recebida imediatamente dessa coisa, mas de
outra que primeiro a recebeu; assim, vemos um homem num espelho. Ora, ao primeiro modo pertence
o conhecimento divino, pelo qual Deus conhece pela sua essência; e este modo de conhecer não o pode
ter criatura nenhuma pelas suas faculdades naturais, como antes já se disse. Ao terceiro modo pertence
o conhecimeto pelo qual conhecemos a Deus, nesta vida, pela semelhança dele, existente nas criaturas,
segundo a Escritura (Rm 1, 20): Porque as coisas visíveis de Deus, compreendendo-se pelas obras que
foram feitas, tornaram-se visíveis. E, por isso, se diz que vemos a Deus num espelho, o conhecimento,
porém, pelo qual o anjo, pelas suas faculdades naturais, conhece a Deus, é um meio termo entre os dois
outro modos, e se assemelha ao conhecimento peço qual uma coisa é inteligida por meio da espécie
dela recebida. Pois, estando a imagem de Deis impressa na própria natureza do anjo, este, pela sua
essência, conhece a Deus, de quem é semelhança. Todavia, não contempla a essência mesma de Deus,
porque nenhuma semelhança criada é suficiente para representar tal essência. Por onde, tal
conhecimento mais se aproxima ao do terceiro modo, por ser a natureza mesma do anjo um como
espelho representativo da divina semelhança.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dionísio se refere ao conhecimento de compreensão,
como as sus palavras expressamente o declaram. E, de tal modo, Deus não é conhecido de nenhuma
inteligência criada.

RESPOSTA À SEGUNDA. — De distar infinitamente de Deus o intelecto e a essência do anjo resulta que
este não pode compreender a Deus, nem contemplar a divina essência, pelas suas faculdades naturais.
Não resultam porém, quem por isso, nenhum conhecimento possa ter d Deus; pois, assim como Deus
dista infinitamente do anjo, assim o conhecimento que Deus tem de si mesmo dista infinitamente do
que o anjo tem de Deus.

RESPOSTA À TERCEIRA. — O conhecimento, que o anjo naturalmente tem de Deus é um meio termo
entre os dois modos de conhecer; contudo se aproxima mais de um do que do outro, como acima se
disse.