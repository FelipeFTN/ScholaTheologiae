# Questão 106: Da iluminação dos anjos.
Em seguida devemos considerar como uma criatura move outra; e tal consideração será tripartida. De
modo que, primeiro, consideremos como os anjos movem, criaturas puramente espirituais, Segundo,
como os corpos movem. Terceiro, como os homens movem, que são compostos de natureza espiritual e
corpórea.
Sobre o primeiro ponto, ocorre tríplice consideração. Primeira, como um anjo age sobre outro. Segunda,
como agem os anjos sobre a criatura corpórea. Terceira, como agem sobre os homens
Na primeira questão, é necessário considerar a iluminação e a locução dos anjos, como se ordenam
entre si, tanto os bons como os maus.
Sobre a iluminação, quatro artigos se discutem:

## Art. 1 — Se um anjo ilumina outro.
(Infra, q. 111, a. 1; II, Sent., dist. IX, a. 2; dist. XI, part. II, q. 1, a. 2; De Verit., 1. 9, art. 1, 5; Compend.
Theol., cap. CXXVI).
O primeiro discute-se assim. – Parece que um anjo não ilumina outro.

1. – Pois, os anjos possuem, atualmente, a beatitude que esperamos, no futuro. Ora, então, um homem
não iluminará outro, conforme a Escritura (Jr 31, 34): E não ensinará daí em diante varão ao seu
próximo, nem varão ao seu irmão. Logo, atualmente, também um anjo não ilumina outro.

2. Demais. – Tríplice é a luz dos anjos: a da natureza, a da graça e a da glória. Ora, o anjo é iluminado,
quanto à primeira luz, pela natureza criadora; quanto à segunda, pela graça justificante; quanto à
terceira, pela glória beatíficante, o que tudo vem de Deus. Logo, um anjo não ilumina outro.

3. Demais. – A luz é uma certa forma da mente. Ora, como diz Agostinho, a mente racional é formada só
por Deus, sem interposição de nenhuma criatura. Logo, um anjo não ilumina a mente de outro.
Mas, em contrário, diz Dionísio: Os anjos da segunda hierarquia são purificados, iluminados e
aperfeiçoados pelos da primeira.

SOLUÇÃO. – Um anjo ilumina outro. E isso se evidência considerando que a luz, no referente ao
intelecto, não é mais do que uma manifestação da verdade conforme a Escritura (Ef 5, 13): Tudo o que
se manifesta é luz. Por onde, iluminar, não é mais do que transmitir a outrem a manifestação da
verdade conhecida; e nesse sentido é que o Apóstolo diz (Ef 3, 8-9): A mim, que sou o mínimo de todos
os santos, me foi dada esta graça de manifestar a todos qual seja a comunicação do sacramento
escondido, desde os séculos, em Deus. Assim, pois, diz-se que um anjo ilumina outro, manifestando-lhe
a verdade que conhece. E por isso Dionísio diz: Os teólogos mostram claramente que as ordens inferio-
res das substâncias celestes são ensinadas, no tocante às operações divinas, pelas mentes supremas.
Ora, como para a intelecção concorrem dois elementos, conforme já se disse antes (q. 103, a. 3), que
são a virtude intelectiva e a semelhança da coisa inteligida; quanto a esses dois elementos, um anjo
pode notificar a outro a verdade conhecida. – Primeiro, fortificando-lhe a virtude intelectiva. Pois, assim
como a virtude de um corpo mais imperfeito é corroborada pela situação próxima de outro mais
perfeito, aumentando, p. ex., o calor do menos cálido com a presença do mais cálido, assim, a virtude
intelectiva de um anjo inferior é corroborada pela conversão, para o mesmo, de um anjo superior. Pois,
a ordem da conversão faz, no espiritual. o que faz, nas coisas corpóreas, a ordem da proximidade local.
– Mas, em segundo lugar, um anjo manifesta a verdade a outro, quanto à semelhança da coisa
inteligida. Porque o anjo superior alcança o conhecimento da verdade por uma concepção universal,
para apreender a qual não é suficiente o intelecto do anjo inferior, pois, a este lhe é conatural
apreender a verdade mais particularmente. Por onde, o anjo superior distingue, de certo modo, a
verdade que apreende universalmente, de maneira a poder ela ser apreendida pelo inferior, e, assim,
lhe propõe a este para que seja conhecida. Assim como, entre nós, os doutores distinguem
multiformemente o que apreendem em síntese, acomodando-se à capacidade dos outros. E é o que
Dionísio diz: Cada substância intelectual divide e multiplica, com provida virtude, a inteligência uniforme
que lhe foi dada por um ser mais divino, conforme a analogia com a substância inferior, que eleva para
cima.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Todos os anjos, tanto os superiores como os inferiores,
vêm imediatamente a essência de Deus e, a esta luz, um não ensina outro. E é a esta doutrina que o
Profeta se refere quando diz: Não ensinará o varão ao seu irmão dizendo: conhece o Senhor. Porque
todos me conhecerão, desde o menor até ao maior. Mas, quanto às razões das obras divinas,
conhecidas em Deus, como na causa, por certo que Deus as conhece todas, em si mesmo, porque a si
mesmo se compreende; ao passo que, dos que vêm a Deus, nele conhecerá mais razões quem mais
perfeitamente o vir. Por onde, o anjo superior conhece mais razões das obras divinas, em Deus, do que
o inferior e, sobre elas, ilumina a este. E é o que Dionísio significa, afirmando que os anjos são
iluminados, quanto às razões das coisas existentes.

RESPOSTA À SEGUNDA. – Um anjo não ilumina outro, transmitindo-lhe a luz da natureza, da graça ou da
glória, mas corroborando-lhe o lume natural e manifestando-lhe a verdade sobre o que pertence ao
estado da natureza, da graça e da glória, como já se disse.

RESPOSTA À TERCEIRA. – A mente racional é formada imediatamente por Deus; ou como a imagem,
pelo exemplar, porque não foi feita segundo nenhuma outra imagem, a não ser a de Deus; ou como o
sujeito pela última forma completiva, porque a mente criada é sempre reputada informe, se não aderir
à verdade primeira. Ao passo que as outras iluminações, provenientes do homem ou do anjo, são umas
como disposições para a última forma.

## Art. 2 — Se um anjo pode mover a vontade do outro.
(Infra, p. 111, a, 2; 1ª IIªª, q. 9 a. 6; III Cont. Gent., cap. LXXXVIII; De Verit., q, 22, a. 9; De Malo, q. 3, a. 3).
O segundo discute-se assim. – Parece que um anjo pode mover a vontade de outro.

1. – Pois, segundo Dionísio, assim como um anjo ilumina outro, assim também o purifica e aperfeiçoa,
conforme é claro pela autoridade supracitada (a. 1). Ora, a purificação e a perfeição respeitam à
vontade; pois, aquela se refere à mácula da culpa, que concerne à vontade; esta se obtém pela
consecução do fim, que é objeto da vontade. Logo, um anjo pode mover a vontade de outro.

2. Demais. – Como diz Dionísio, os nomes dos anjos designam-lhes as propriedades. Assim, chamam-se
serafins os que abrasam ou aquecem, o que se realiza pelo amor, que diz respeito à vontade. Logo, um
anjo move a vontade de outro.

3. Demais. – O Filósofo diz que o apetite superior move o inferior. Ora, como o intelecto do anjo
superior é superior, assim também o apetite. Logo, conclui-se que o anjo superior pode imutar a
vontade de outro.
Mas, em contrário. – Pode imutar a vontade quem pode justificá-la, pois, a justiça é a retidão da
vontade. Ora, só Deus pode justificar. Logo, um anjo não pode mudar a vontade de outro.

SOLUÇÃO. – Como já se disse antes (q. 105, a. 4), a vontade é imutada duplamente: por parte do objeto
e por parte da potência mesma. – Por parte do objeto movem a vontade: o bem em si, objeto dela,
assim como o desejável move o apetite; e quem mostra o objeto, p. ex., quem mostra que alguma coisa
é boa. Mas, como já se disse (ibid), os outros bens inclinam a vontade, de certo modo, que nenhum a
mova suficientemente, o que só faz o bem universal, que é Deus; e esse bem só o mostra, como é visto
em essência pelos bem-aventurados, aquele que, a Moisés que dizia: Mostra-me a tua glória –
respondeu: Eu te mostrarei todo o bem, como se lê na Escritura (Ex 33, 18-19). Portanto, o anjo não
move suficientemente a vontade, nem como objeto, nem como indicador do objeto. Mas a inclina como
algo de amável e como manifestativo de certos bens criados ordenados para a bondade de Deus; e
assim pode inclinar por modo de persuasão, ao amor da criatura ou de Deus. – Por parte, porém, da
potência, em si, a vontade não pode ser movida, de nenhum modo, salvo por Deus. Pois, a operação da
vontade é uma inclinação de quem quer para a coisa querida. Ora, tal inclinação só pode imutá-la quem
conferiu à vontade a virtude volitiva; assim como só pode mudar a inclinação natural o agente, que
pode dar a virtude, donde resulta essa inclinação. E como, só Deus é quem dá à criatura a potência
volitiva, porque só ele é o autor da natureza intelectual, conclui-se que um anjo não pode mover a von-
tade de outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Deve-se compreender a purificação e a perfeição
conforme o modo de iluminação. E como Deus ilumina, imutando o intelecto e a vontade, assim os
purifica dos defeitos e os aperfeiçoa quanto ao fim. A iluminação angélica, porém, reportando-se ao
intelecto, como já se disse (a. 1), a purificação do anjo se entende relativamente à deficiência do
intelecto, que é a ignorância; pois a perfeição é a consecução do fim do intelecto, que é a verdade
conhecida. E é o que significa Dionísio quando diz: Na hierarquia celeste, a purificação, relativa às
essências sujeitas, é uma como iluminação, quanto ao desconhecido, que as conduz a uma ciência mais
perfeita. Assim, como se disséssemos que a visão corpórea é purificada, pela remoção das trevas;
iluminada, pela perfusão da luz; aperfeiçoada, enfim, quando levada ao conhecimento do objeto
colorido.

RESPOSTA À SEGUNDA. – Um anjo pode levar outro ao amor de Deus, a modo de persuasão, como já
antes se disse

RESPOSTA À TERCEIRA. – O Filósofo se refere ao apetite inferior sensitivo, que pode ser movido pelo
apetite superior intelectivo, pertencente à mesma natureza da alma, e porque o apetite inferior é uma
virtude do órgão corpóreo. O que não tem lugar nos anjos.

## Art. 3 — Se o anjo inferior pode iluminar o superior.
(Infra, q. 107, a. 2; De Verit., q. 9, a. 2).
O terceiro discute-se assim. – Parece que o anjo inferior pode iluminar o superior.

1. – Pois, a hierarquia eclesiástica é derivada da celeste e a representa, sendo por isso a superna
Jerusalém chamada mãe nossa (Gl 4, 26). Ora, na Igreja, os superiores são iluminados e ensinados pelos
inferiores, conforme aquilo do Apóstolo (1 Cor 14, 31): Podeis profetizar todos, um depois do outro, a
fim de que todos aprendam, e todos sejam exortados. Logo, também na hierarquia celeste, os
superiores podem ser iluminados pelos inferiores.

2. Demais. – Assim como a ordem das substâncias corpóreas depende da vontade de Deus, assim
também a das substâncias espirituais. Ora, como já se disse (q. 105, a. 6), Deus às vezes opera fora da
ordem das substâncias corpóreas. Logo, opera também às vezes fora da ordem das substâncias
espirituais, iluminando as inferiores por meios superiores. E, portanto, os inferiores, iluminados por
Deus, podem iluminar os superiores.

3. Demais – Um anjo ilumina o para o qual se converte, como antes se disse (a. 1). Ora, como essa
conversão é voluntária, o anjo supremo pode se converter para o ínfimo, sem passar por nenhum meio.
Logo, pode iluminá-lo imediatamente, e assim, este último pode iluminar os superiores.
Mas, em contrário, diz Dionísio: é lei imutável da divindade, que os seres inferiores dependam de Deus,
por meio dos superiores.

SOLUÇÃO. – Os anjos inferiores nunca iluminam os superiores; antes, são sempre iluminados por estes.
E a razão é que, como já se disse (q. 105, a. 6), uma ordem está compreendida noutra, como uma causa
noutra. E por isso não há inconveniente em que, às vezes, alguma coisa se faça fora da ordem da causa
inferior para se ordenar à causa superior; como, nas coisas humanas, abandona-se a ordem do chefe
para se obedecer ao príncipe. Donde vem que, fora da ordem da natureza corpórea, Deus opera certos
milagres, para conduzir os homens ao seu conhecimento. Ora, o abandono da ordem própria às
substâncias espirituais de nenhum modo levaria os homens a se ordenarem para Deus, pois as opera-
ções dos anjos não nos são manifestas, como as dos corpos sensíveis. Por onde, a ordem que convém às
substâncias espirituais nunca é abandonada por Deus, de modo que sempre os seres inferiores são
movidos pelos superiores e não inversamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A hierarquia eclesiástica imita a celeste, de certo modo,
mas não reproduz perfeitamente a semelhança dela. Pois, na hierarquia celeste, a razão total da ordem
provém da proximidade com Deus. E por isso, os mais próximos de Deus são de grau mais sublime e de
ciência mais clara; donde resulta que os superiores não são nunca iluminados pelos inferiores. Ao passo
que na hierarquia eclesiástica, às vezes os mais próximos de Deus, pela santidade, são de grau ínfimo e
de ciência não eminente; e certos são eminentes numa coisa, mesmo quanto à ciência, e deficientes em
outra. E por isso, os superiores podem ser ensinados pelos inferiores.

RESPOSTA À SEGUNDA. – Como já se disse, não é pelo mesmo fundamento que Deus age fora da ordem
da natureza corpórea e da espiritual. Por onde, a objeção não colhe.

RESPOSTA À TERCEIRA. – O anjo converte-se, pela vontade a iluminar outro anjo; mas a vontade do
anjo é sempre regulada pela lei divina que instituiu a ordem dos anjos.

## Art. 4 — Se o anjo superior ilumina, em relação a tudo o que sabe, o inferior.
O quarto discute-se assim. – Parece que o anjo superior não ilumina, em relação a tudo o que sabe, o
inferior.

1. – Pois, diz Dionísio, que os anjos superiores têm ciência mais universal, que a dos inferiores, que é
mais particular e dependente. Ora, maior compreensão tem a ciência universal que a particular. Logo,
nem tudo o que sabem os anjos superiores o sabem, por iluminação deles, os inferiores.

2. Demais. – O Mestre das sentenças diz, que os anjos superiores conheceram, desde os séculos dos
séculos, o mistério da Encarnação; ao passo que os inferiores não o conheceram enquanto ela não se
consumou. E isto se conclui de que, a uns anjos que interrogam, como quem ignora (Sl 23, 10) – Quem é
este Rei da glória? – outros respondem, como quem sabe – O Senhor das virtudes, esse é o Rei da
glória – segundo expõe Dionísio. Ora, tal não se daria, se os anjos superiores iluminassem, em relação a
tudo o que sabem, os inferiores; logo, não os iluminam desse modo.

3. Demais. – Se os anjos superiores anunciassem tudo o que conhecem, aos inferiores, nada do que
aqueles conhecessem seria desconhecido destes. Portanto, sobre nada mais poderiam os superiores
iluminar os inferiores, o que é inadmissível. Logo, os superiores não iluminam, sobre tudo, os inferiores.
Mas, em contrário, diz Gregório: Na pátria celeste, embora certas coisas sejam dadas, excelentemente,
contudo nada é possuído singularmente. E Dionísio: Cada essência celeste comunica à inferior a
inteligência que lhe foi dada pela superior, como é claro pelo passo supra-exarado (a. 1).

SOLUÇÃO. – Todas as criaturas participam da divina bondade, de modo a difundirem nas outras o bem
que possuem; pois, é da essência do bem comunicar-se. Donde vem que os próprios agentes corpóreos
transmitem, tanto quanto possível, a sua semelhança a outros. Por onde, quanto mais um agente
participa da divina bondade, tanto mais tende a transfundir nos outros, no máximo possível, as suas
perfeições. E por isso São Pedro adverte os que participam, pela graça, da divina bondade, dizendo (1 Pd
4, 10): Cada um, segundo o dom que recebeu, comunique-o aos outros, como bons despenseiros da
multiforme graça de Deus. Logo, com maior razão, os santos anjos, que participam plenissimamente da
divina bondade, dividem com os que lhes são inferiores tudo o que recebem de Deus. Mas o que é
recebido pelos inferiores nestes não está do mesmo modo excelente por que está nos superiores. E por
isso estes permanecem sempre em ordem mais alta e têm ciência mais perfeita; assim como o mestre
intelige uma mesma coisa mais plenamente que o discípulo, que dele aprende.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Considerar-se mais universal a ciência dos anjos
superiores, quanto ao modo mais eminente de inteligir.

RESPOSTA À SEGUNDA. – Não se devem entender as palavras do Mestre das Sentenças como
significando que os anjos inferiores ignoraram completamente o mistério da Encarnação; mas como
significando que, além de não o terem conhecido, tão plenamente como os superiores, progrediram
depois no conhecimento do mesmo, até que ele se cumprisse.

RESPOSTA À TERCEIRA. – Até o dia do juízo, sempre novas revelações serão feitas por Deus aos anjos
supremos, no tocante à disposição do mundo e sobretudo à salvação dos eleitos. Por onde, sempre
haverá matéria em que os anjos superiores iluminem os inferiores.