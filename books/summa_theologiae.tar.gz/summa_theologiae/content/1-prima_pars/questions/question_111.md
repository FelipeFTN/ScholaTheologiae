# Questão 111: Da ação dos anjos sobre os homens.
Em seguida deve-se tratar da ação dos anjos sobre os homens. E primeiro discute-se se aqui eles podem,
por virtude natural, imutar a estes. Segundo, de que modo são enviados por Deus, para o ministério dos
homens. Terceiro, como guardam os homens.
Sobre o primeiro ponto quatro artigos se discutem:

## Art. 1 — Se o anjo pode iluminar o homem.
(III Cont. Gent., cap. LXXXI; De Verit., q. II, a. 3; De Malo, q. 16, a. 12; Quodl IX, q. 4, a. 5).
O primeiro discute-se assim. — Parece que o anjo não pode iluminar o homem.

1. — Pois, o homem é iluminado pela fé; por isso Dionísio atribui a iluminação ao batismo, que é o
sacramento da fé. Ora, esta imediatamente vem de Deus, conforme a Escritura (Ef 2, 8): É pela graça
que fostes salvos, mediante a fé, é isto não vem de vós, porque é um dom de Deus. Logo, o homem não
é iluminado pelo anjo, mas, imediatamente, por Deus.

2. Demais. — A propósito do passo da Escritura (Rm 1, 19) — Deus lho manifestou — diz a Glossa: não
só por meio da razão natural foram manifestadas as coisas divinas aos homens, mas também Deus lhes
fez revelações, por meio das suas obras, i. é, por meio da criatura. Ora, tanto a razão natural, como a
criatura, procedem imediatamente de Deus. Logo, Deus ilumina o homem imediatamente.

3. Demais. — Quem é iluminado conhece a sua iluminação. Ora, os homens não têm consciência de
serem iluminados pelos anjos. Logo, não são iluminados por eles.
Mas, em contrário, Dionísio prova, que as revelações das coisas divinas chegam aos homens, mediante
os anjos. Ora, tais revelações são iluminações, como já se disse (q. 106, a. 1; q. 107, a. 2). Logo, os
homens são iluminados pelos anjos.

SOLUÇÃO. — Como esta na ordem da divina providência, que os seres inferiores estejam submetidos às
ações dos superiores, conforme já se disse (q. 109, a. 2; q. 110, a. 1), em relação aos anjos inferiores,
iluminados pelos superiores; assim também os homens, inferiores aos anjos, são por estes iluminados.
Mas o modo dessas iluminações é, em parte, semelhante e, em parte, diverso. Pois, como se disse (q.
106, a. 1), a iluminação, que é a manifestação da divina verdade, é considerada a dupla luz: enquanto o
intelecto inferior é reforçado pela ação do superior; e enquanto são propostas ao intelecto inferior as
espécies inteligíveis do superior, para que possam ser apreendidas por aquele. E isto nos anjos se faz
quando o anjo superior divide com o inferior, segundo a capacidade deste, a verdade universal
concebida, como já se disse (Ibid). Mas o intelecto humano não pode apreender a verdade inteligível,
em si mesma, por que lhe é conatural inteligir voltando-se para os fantasmas, conforme já ficou
estabelecido (q. 84, a. 7). E por isso os anjos propõem aos homens a verdade inteligível, debaixo de
semelhanças sensíveis, conforme ensina Dionísio, dizendo que é impossível chegue até nós a luz dos
raios divinos, sem que seja circunvelada pela variedade dos sagrados véus. Mas por outro lado, o
intelecto humano, como inferior, é fortificado pela ação do intelecto angélico. E nestes dois pontos de
vista é que se considera a iluminação que o homem recebe do anjo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Duas coisas levam ao fim. — A primeira é o hábito do
intelecto que o dispõe a obedecer à vontade, que tende para a divina verdade; pois, o intelecto assente
à verdade da fé não como convencido pela razão, mas como obrigado pela vontade; pois, conforme
Agostinho, só crê quem quer. E, a esta luz a fé vem só de Deus. — Em segundo lugar, para haver fé é
necessário que as coisas que se devem crer sejam propostas ao crente. E isto se opera por meio do
homem, enquanto que a fé é pelo ouvido, conforme diz a Escritura (Rm 10, 17); mas, principalmente,
por meio dos anjos, pelos quais são reveladas aos homens as coisas divinas. E portanto, os anjos
contribuem em alguma coisa, para a iluminação da fé. — E contudo os homens são iluminados por eles,
não só quanto ao que devem crer, mas também quanto ao que devem fazer.

RESPOSTA À SEGUNDA. — A razão natural, procedente de Deus, imediatamente, pode ser reforçada
pelo anjo, como já se disse. E, semelhantemente, pelas espécies recebidas das criaturas, tanto mais alto
se elevará à verdade inteligível, quanto mais forte for o intelecto humano. E assim o homem é auxiliado
pelo anjo, para que, partindo das criaturas, chegue a um conhecimento divino mais perfeito.

RESPOSTA À TERCEIRA. — A operação intelectual e a iluminação podem ser consideradas de duplo
modo. De um, em relação à coisa inteligida, assim quem intelige ou é iluminado tem de ambas estas
coisas consciência, porque conhece que algo lhe é manifestado. De outro modo, em relação ao
princípio, e assim quem intelige qualquer verdade nem por isso sabe o que seja intelecto, princípio da
operação intelectual. E semelhantemente, quem é iluminado pelo anjo nem por isso se conhece como
iluminado.

## Art. 2 — Se os anjos podem imutar a vontade do homem.
(Supra, q. 106, a. 2; 1ª II ªº, q. 80, a. 1; II Sent., dist. VIII, a. 5; III Cont. Gent., cap. LXXXVIII, XCII; De Verit.,
q. 22, a. 9; De Malo, q. 3, a. 3, 4; In Ioann, cap. XIII, lect I).
O segundo discute-se assim. — Parece que os anjos podem imutar a vontade do homem.

1. — Pois, a propósito do passo da Escritura (Heb 1, 7) — Que faz aos seus anjos espíritos, e aos seus
ministros chama de fogo — diz a Glossa, que são fogo por serem férvidos, de espírito, e queimarem os
nossos vícios. Ora, tal não seriam sem imutarem a vontade. Logo, os anjos podem imutá-la.

2. Demais. — Beda diz, que o diabo não é o causador dos maus pensamentos, mas, o incensor.
Damasceno porém diz mais, que também é o causador; pois, escreve: toda malícia e as paixões imundas
são excogitadas, por influência dos demônios, pois, lhes é concedido causarem-nas nos homens. E por
igual razão, os anjos bons causam e incitam os bons pensamentos. Ora, isso não poderiam fazê-lo se não
imutassem a vontade. Logo, imutam-na.

3. Demais. — Como já se disse (a. 1), o anjo ilumina o intelecto do homem mediante os fantasmas. Ora,
como a fantasia, que serve ao intelecto, pode ser imutada pelo anjo, assim também o apetite sensitivo,
que serve à vontade, pois, este é também uma virtude que usa de órgão corpóreo. Logo, assim como
ilumina o intelecto também pode iluminar a vontade.
Mas, em contrário, imutar a vontade é próprio de Deus, conforme a Escritura (Pr 21, 1): O coração do rei
está na mão do Senhor, ele o inclinará para qualquer parte que quiser.

SOLUÇÃO. — A vontade pode ser imutada de dois modos. — Interiormente; e então, como o seu
movimento não é senão a inclinação para a coisa querida, só Deus, que dá à natureza intelectual a
virtude para tal inclinação, pode imutá-la. Pois, assim como a inclinação natural procede de quem dá a
natureza, assim a inclinação da vontade só pode proceder de Deus, que causa a vontade. — De outro
modo, a vontade é movida pelo exterior. E isto, no anjo, se dá de uma só maneira, a saber, pelo bem
apreendido pelo intelecto. Por onde, a causa de ser alguma coisa apreendida como bem desejado, move
a vontade. De modo que só Deus pode mover eficazmente a vontade; o anjo, porém, e o homem podem
movê-la, persuadindo-a, como antes se disse (q. 106, a. 2). — Mas além deste modo, também a vontade
do homem é movida pelo exterior, e isso pela paixão referente ao apetite sensitivo; assim, pela
concupiscência ou pela ira a vontade é inclinada a querer um certo objeto. E então, também os anjos, na
medida em que podem provocar essas paixões, podem movê-la; não porém necessariamente, porque a
vontade sempre fica livre de consentir na paixão ou lhe resistir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que os ministros de Deus, homens ou anjos,
queimam os vícios e inflamam as virtudes, persuadindo.

RESPOSTA À SEGUNDA. — Os demônios não podem originar os pensamentos, causando-os
interiormente porque a virtude cogitativa está sujeita à vontade. Diz-se porém, que o diabo é incensor
dos pensamentos, na medida em que incita a pensar ou a desejar o que foi pensado, persuadindo ou
concitando a paixão. E esse mesmo incender Damasceno chama causar, porque tal operação é interior.
Ao passo que os bons pensamentos são atribuídos a Deus, princípio mais alto, embora sejam
provocados pelo ministério dos anjos.

RESPOSTA À TERCEIRA. — O intelecto humano, no estado presente, não pode inteligir, a não ser
voltando-se para os fantasmas. Mas a vontade humana pode querer alguma coisa, pelo juízo da razão,
sem seguir a paixão do apetite sensitivo. E por isso o símile não é o mesmo.

## Art. 3 — Se o anjo pode imutar a imaginação do homem.
(II Sent., dist. VIII, a. 5; De Malo, q. 3, a. 4; q. 16, a. II).
O terceiro discute-se assim. — Parece que o anjo não pode imutar a imaginação do homem.

1. — Pois, como diz Aristóteles, a fantasia é um movimento provocado pelo sentido em ato. Ora, se
fosse proveniente de imutação angélica não procederia do sentido em ato. Logo, é contra a natureza da
fantasia, ato da virtude imaginária ser causada por imutação angélica.

2. Demais. — As formas da imaginação, sendo espirituais, são mais nobres que as da matéria sensível (q.
110, a. 2). Ora, o anjo não pode imprimir formas na matéria sensível, como já se disse. Logo, não pode
imprimi-las na imaginação e, portanto não pode imutá-la.

3. Demais. — Como diz Agostinho, um espírito pode, influindo sobre outro, por meio de tais imagens,
comunicar o que sabe a este último, quer, este mesmo intelija, quer pelo primeiro, sejam manifestadas
as coisas inteligidas. Ora, o anjo não pode influir na imaginação humana; nem esta pode apreender os
inteligíveis que o anjo conhece. Logo, não pode imutar a imaginação.

4. Demais. — Na visão imaginária, o homem adere às semelhanças das coisas, como se fossem as
próprias coisas. Mas nisso vai um engano. Ora, como o anjo bom não pode ser causa de engano, conclui-
se que não pode causar a visão imaginária, imutando a imaginação.
Mas, em contrário, as coisas vêm-se nos sonhos, por visão imaginária. Ora, os anjos revelam certas
coisas nos sonhos, como se lê, no Evangelho (Mt 1; 2), do anjo que apareceu desse modo a José. Logo, o
anjo pode mover a imaginação.

SOLUÇÃO. — Tanto o anjo bom como o mau, pode, em virtude da sua natureza, mover a imaginação do
homem. O que se pode explicar do seguinte modo. Como já se disse (q. 110, a. 3), a natureza corpórea
obedece ao anjo, quanto ao movimento local. Assim, tudo quanto pode ser causado pelo movimento
local de certos corpos cai sob o alcance da virtude natural dos anjos. Ora, é manifesto que as aparições
imaginárias são às vezes causadas em nós pela mutação local dos espíritos corpóreos e dos humores.
Por onde, Aristóteles, assinalando a causa da aparição dos sonhos, diz que, quando o animal dorme
descendo muito sangue para o princípio sensitivo, descem simultaneamente os movimentos, i. é, as
impressões deixadas pelos movimentos dos sensíveis, conservadas nos espíritos sensuais — e movem o
princípio sensitivo; de modo que resulta uma aparição, como se então o princípio sensitivo fosse movido
pelas próprias coisas exteriores. E pode ser tão grande a comoção dos espíritos e dos humores, que tais
aparições se dêm mesmo nos acordados, como bem se vê nos loucos e semelhantes. Ora, como isso se
dá por movimento natural dos humores e às vezes mesmo por vontade do homem, que imagina
voluntariamente o que antes sentira; assim também pode dar-se por virtude do anjo bom ou mau, ora
com privação dos sentidos corpóreos, ora, sem tal privação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O princípio da fantasia vem do sentido em ato. Pois, não
podemos imaginar o que de nenhum modo sentimos, total ou parcialmente; assim, um cego nato não
pode imaginar a cor. Mas, às vezes a imaginação é informada, como já se disse, pelas impressões
conservadas interiormente, de modo que surja o ato do movimento fantástico.

RESPOSTA À SEGUNDA. — O anjo transmuta a imaginação, não por certo imprimindo alguma forma
imaginária, que antes não tivesse sido de nenhum modo apreendida pelo sentido; assim, não pode fazer
com que o cego imagine as cores; mas ele opera a sobredita transmutação por meio do movimento local
dos espíritos e dos humores.

RESPOSTA À TERCEIRA. — A referida influência do espírito angélico sobre a imaginação humana não é
pela essência, mas pelo efeito que, do modo predito, causa na imaginação, à qual ele manifesta o que
conhece, não porém do modo pelo qual conhece.

RESPOSTA À QUARTA. — O anjo, causando uma visão imaginária, ora, ilumina simultaneamente o
intelecto, para que este conheça o que tais semelhanças significam e, então, não há engano nenhum.
Outras vezes, porém, pela operação do anjo, aparecem na imaginação só as semelhanças das coisas;
mas então o engano não por defeito do intelecto, ao qual tais coisas aparecem. Assim, Cristo não foi
causa de engano, propondo às turbas, em parábolas, muitas coisas que lhes não explicou.

## Art. 4 — Se o anjo pode imutar os sentidos humanos.
(II Sent., dist. VIII, art., 5; De Malo, q. 3. art. 4; q. 16, art. II).
O quarto discute-se assim. — Parece que o anjo não pode imutar os sentidos humanos.

1. — Pois, a operação sensitiva é vital. Ora, esta operação vital não resulta de princípio extrínseco. Logo,
a operação sensitiva não pode ser causada pelo anjo.

2. Demais. — A virtude sensitiva é mais nobre que a nutritiva. Ora, o anjo, como se sabe, não pode
imutar a virtude nutritiva, nem as outras formas naturais. Logo, também não pode imutar a virtude
sensitiva.

3. Demais. — O sentido é naturalmente movido pelo sensível. Ora, o anjo não pode imutar a ordem da
natureza, como antes se disse. Logo, não pode imutar os sentidos, mas sempre estes são movidos pelo
sensível.
Mas, em contrário, os anjos que subverteram Sodoma, - feriram os Sodomitas de cegueira de sorte que
não podiam encontrar a porta, como diz a Escritura (Gn 19, 11). E o mesmo nesta se lê, a respeito dos
Sírios (4 Rg 6), que Eliseu levou para a Samaria.

SOLUÇÃO. — De dois modos podem os sentidos ser imutados. Pelo exterior, como quando é imutado
pelo sensível; e pelo interior. Assim, vemos que perturbados os espíritos e os humores os sentidos são
imutados; daí vem que a língua do enfermo, cheia de humor colérico, sente tudo amargo, o mesmo se
dando com os demais sentidos. Ora, de ambos os supraditos modos, o anjo pode imutar, por virtude
natural, os sentidos dos homens. Assim, pode opor exteriormente ao sentido um sensível, formado pela
natureza, ou formando-o de novo, como faz, quando assume um corpo, conforme se disse antes (q. 51,
a. 2). Semelhantemente, também pode mover interiormente os espíritos e os humores, segundo já disse
(a. 3), pelos quais os sentidos sejam diversamente imutados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O princípio da operação sensitiva não pode existir sem o
princípio interior, que é a potência sensitiva. Mas, esse princípio interior pode ser multiplicemente
movido pelo exterior, como já se disse.

RESPOSTA À SEGUNDA. — Pela moção interior dos espíritos e dos humores, o anjo pode operar algo
para imutar o ato da potência nutritiva; e semelhantemente, da potência apetitiva e da sensitiva, e de
qualquer potência que se sirva de órgão corpóreo.

RESPOSTA À TERCEIRA. — O anjo nada pode fazer contra a ordem de todas as criaturas; mas o pode
contra a ordem de uma natureza particular, porque não esta sujeito a tal ordem. E assim, de modo
singular pode imutar os sentidos, fora do modo comum.