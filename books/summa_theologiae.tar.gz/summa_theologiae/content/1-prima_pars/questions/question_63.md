# Questão 63: Da malícia dos anjos quanto à culpa.
Em seguida, devemos considerar como os anjos se tornaram maus. E primeiro, quanto ao mal da culpa.
Segundo, quanto ao mal da pena.
Sobre o primeiro ponto nove artigos se discutem:

## Art. 1 — Se pode haver nos anjos o mal da culpa.
O primeiro discute-se assim. — Parece que não pode haver nos anjos o mal da culpa.

1. — Pois, o mal da culpa só pode existir nos seres potenciais, como diz Aristóteles, por ser o ente
potencial o sujeito da privação. Ora, os anjos, sendo formas subsistentes, não têm o ser potencial. Logo,
não pode haver neles o mal da culpa.

2. Demais. — Os anjos são mais dignos do que os corpos celestes. Ora, nestes não pode haver mal, como
dizem os filósofos. Logo, nem naqueles.

3. Demais. — O natural a um ser neste sempre existe. Ora, é natural aos anjos moverem-se para Deus
pelo movimento de dileção. Logo, disto não podem eles ser privados. Mas, como amando a Deus não
pecam, os anjos não podem pecar.

4. Demais. — O apetite só pode desejar o bem ou o que tem a aparência de bem. Ora, para os anjos não
pode haver bem aparente que não seja verdadeiro, porque neles não pode de nenhum modo haver
erro; ou, pelo menos, este não podia preceder à culpa. Logo, os anjos só podem apetir o bem
verdadeiro. Mas ninguém que deseje o verdadeiro bem peca. Logo, o anjo, apetindo, não peca.
Mas, em contrário, diz Jó: E entre os seus anjos achou crime.

SOLUÇÃO. — O anjo, como qualquer criatura racional, considerado na sua natureza, pode pecar; e só
por dom da graça, não pela condição da natureza, é que pode convir a uma criatura a impecabilidade. E
a razão disto é que pecar não é senão o declinar um ato da retidão que deve ter, quer se considere o
pecado nos seres naturais, nos artificiais ou nos morais. Ora, só não pode declinar da retidão o ato cuja
regra é a virtude do agente. Assim, se a mão do artífice fosse a regra mesma da incisão, ele nunca
poderia cortar a madeira senão em linha reta; mas, se a retidão da incisão depender de outra regra a
incisão poderá ser reta e não reta. Ora, só a divina vontade é a regra do seu ato, porque não está
ordenada para um fim superior. Porém, toda vontade de qualquer criatura não traz, no seu ato, a
retidão, senão enquanto regulada pela vontade divina, da qual depende o último fim. Assim, a vontade
de um ser inferior deve se regular pela do superior, como a vontade do soldado pela do chefe do
exército. Portanto, só na vontade divina não pode haver pecado; ao passo que o pode, segundo a ordem
da natureza, na vontade de qualquer criatura.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nos anjos não há potência quanto ao ser natural;
havendo porém, quanto à parte intelectiva, que pode converter-se para tal coisa ou tal outra, pode
quanto a essa parte haver mal neles.

RESPOSTA À SEGUNDA. — Os corpos celestes só têm operação natural; por onde, como em a natureza
deles não pode existir o mal da corrupção, assim também na ação natural dos mesmos não pode existir
o mal da desordem. Mas, além da ação natural, há nos anjos a ação do livre arbítrio, em relação à qual
pode haver neles mal.

RESPOSTA À TERCEIRA. — É natural ao anjo converter-se para Deus pelo movimento de dileção,
enquanto Deus é o princípio do ser natural. Mas, converter-se a Deus como objeto da beatitude
sobrenatural, só o é por amor gratuito, do qual podia desviar-se pecando.

RESPOSTA À QUARTA. — De dois modos pode haver pecado moral, no ato do livre arbítrio. — De um,
quando se escolhe algum mal; assim, o homem peca escolhendo o adultério que, em si, é mau. E tal
pecado sempre procede de alguma ignorância ou erro; do contrário, o mal não seria escolhido como
bem. Assim, o adultero erra, em particular, escolhendo a deleitação de um ato desordenado, como um
bem a ser atualmente praticado, por causa da inclinação da paixão ou do hábito; embora, em geral, não
erre, mas pense, com verdade, nessa matéria. Ora, deste modo não podia haver pecado nos anjos,
porque neles nem há paixões que liguem a razão ou o intelecto, como do sobredito resulta: nem, além
disso, podia haver um hábito, inclinando ao pecado, e que precedeu o primeiro pecado. — De outro
modo pode-se pecar pelo livre arbítrio, escolhendo-se o bem em si, mas sem a ordem devida à medida
ou à regra; de maneira que o defeito, inducente ao pecado, só existe por parte da eleição que não
observa a ordem devida senão quanto à coisa escolhida. Assim, se alguém escolhesse o orar, sem
atender à ordem instituída pela Igreja. E pecado tal não pressupõe a ignorância, mas somente a
ausência de consideração das coisas que deviam ser consideradas. E, deste modo, o anjo pecou
convertendo-se, pelo livre arbítrio, ao bem próprio, sem se ordenar à regra da divina vontade.

## Art. 2 — Se nos anjos pode haver somente os pecados da soberba e da inveja.
O segundo discute-se assim. — Parece que nos anjos não pode haver somente os pecados da soberba
e da inveja.

1. — Quem quer que seja capaz do deleite de qualquer pecado é também capaz desse pecado. Ora, os
demônios deleitam-se também com as obscenidades dos pecados carnais, como diz Agostinho. Logo,
neles também podem existir esses pecados.

2. Demais. — Como a soberba e a inveja são pecados espirituais, assim também a preguiça, a avareza e a
ira. Mas, como ao espírito convém os pecados espirituais, à carne convém os carnais. Logo, não só a
soberba e a inveja podem existir nos anjos, mas também a preguiça e a avareza.

3. Demais. — Segundo Gregório, da soberba nascem vários vícios e, semelhantemente da inveja. Ora,
posta a causa, segue-se o efeito. Se portanto, a soberba e a inveja podem existir nos anjos, por uma
razão semelhante, também o podem os outros vícios.
Mas, em contrário, diz Agostinho que o diabo não é fornicador, ou ébrio, nem vicioso de maneiras
semelhantes; é contudo, soberbo e invejoso.

SOLUÇÃO. — De dois modos pode o pecado existir em um ser: pelo reato e pelo afeto. — Pelo reato,
por certo todos os pecados podem existir nos demônios, porque, induzindo os homens a todos,
incorrem o reato de todos. — Porém, pelo afeto, podem existir nos maus anjos só os pecados a que
pode a natureza espiritual propender. Ora, esta não pode propender para os bens próprios só aos
corpos, senão para os susceptíveis de existir nos seres espirituais; pois, nenhum ser deseja senão o que
pode, de certo modo, convir-lhe à natureza. Ora, quando desejamos bens espirituais, só pode haver
pecado se nesse afeto não for observada a regra imposta pelo que é superior; sendo pecado de soberba
esse não submeter-se ao superior, no que for devido. Donde, o primeiro pecado do anjo não pôde ser
outro senão o da soberba. — Mas, conseqüentemente, podia haver nos maus anjos a inveja; pois, pela
mesma razão porque o afeto tende a alguma coisa apetecível, por essa mesma se rebela contra o
oposto. Assim, o invejoso sofre como bem de outrem, por considerá-lo impedimento ao seu. Ora, o bem
alheio não podia ser considerado impedimento ao bem afetado pelo anjo mau, senão por desejar este
uma excelência singular, que cessa pela excelência de outrem. Donde, ao pecado da soberba seguiu-se
no anjo pecador o mal da inveja, pela qual sofre, não só com o bem do homem, mas ainda com a
excelência divina, enquanto Deus usa dela para a sua glória, contra a vontade do próprio diabo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os demônios não se deleitam com as obscenidades dos
pecados carnais, como se as desejassem; mas tudo da inveja procede: deleitam-se com quaisquer
pecados dos homens, por serem estes impedimentos ao bem humano.

RESPOSTA À SEGUNDA. — A avareza, como pecado especial, é o apetite imoderado das coisas
temporais aplicadas ao uso da vida humana e que podem ser avaliadas em dinheiro; e essas coisas, bem
como as deleitações carnais, os demônios não as desejam. Donde, a avareza, em acepção própria, não
pode existir neles. Mas, se por avareza se entender toda cobiça imoderada de possuir qualquer bem
criado, enão ela se inclui na soberba, que existe nos demônios. Porém a ira, assim como a
concupiscência, já é acompanhada de certa paixão; por isso não pode existir nos demônios senão
metaforicamente. Quanto à preguiça, ela é uma forma de tristeza, que torna o homem tardo para os
atos espirituais, por causa do trabalho corporal, o qual não convém aos demônios. Assim, resulta claro,
que somente a soberba e a inveja são pecados puramente espirituais, que podem competir aos
demônios; contanto porém, que não se tome a inveja como uma paixão, mas como vontade rebelada
contra o bem de outrem.

RESPOSTA À TERCEIRA. — Na inveja e soberba dos demônios se compreendem todos os pecados delas
derivados.

## Art. 3 — Se o diabo desejou ser como Deus.
(IIa IIae, q. 163, a. 2; II Sent., dist. V, q. 1 a. 2; dist. XXII, q. 1, a. 2; II Cont. Gent., cap. XIV; De Malo, q. 16,
a. 1)
O terceiro discute-se assim. — Parece que o diabo não desejou ser como Deus.

1. — Pois, o que não incide na apreensão também não incide no apetite; porquanto, o bem apreendido
move o apetite sensível, racional ou intelectual e só em tais apetites pode haver pecado. Ora, não é
objeto da apreensão, o ser qualquer criatura igual a Deus; pois, isso implica contradição, porque
necessariamente o finito seria infinito, se com este se iguala. Logo, o anjo não podia desejar ser como
Deus.

2. Demais. — O fim da natureza pode ser apetido sem pecado. Ora, assimilar-se a Deus é o fim para o
qual tende naturalmente toda criatura. Se portanto, o anjo desejou ser como Deus, não por igualdade,
mas por semelhança, resulta que nisso não pecou.

3. Demais. — O anjo foi criado em maior plenitude de ciência do que o homem. Ora, nenhum homem, a
menos que não seja de todo amente, elege ser igual ao anjo e muito menos a Deus; porque a eleição só
pode visar coisas possíveis, com as quais se ocupa o conselho. Logo, muito menos pecou o anjo,
desejando ser como Deus..
Mas, em contrário, diz a Escritura da pessoa do diabo: Subirei ao céu... e serei semelhante do
Altíssimo. E Agostinho diz, que inchado de soberba, quis chamar-se Deus.

SOLUÇÃO. — O anjo, sem nenhuma dúvida pecou por querer ser como Deus. Mas isto se pode entender
em duplo sentido: por equiparação e por semelhança. — Do primeiro modo, não podia desejar ser como
Deus, porque sabia, por conhecimento natural, ser isso impossível; e nem ao seu primeiro ato
pecaminoso, precedeu um hábito ou uma paixão que ligasse a virtude cognoscitiva, de modo a, sendo
esta deficiente num caso particular, eleger o impossível, como às vezes acontece conosco. E ainda, dado
que isso fosse possível, seria contra o desejo natural. Pois, há em cada um o desejo natural de conservar
o seu ser, que não se conservaria se se transmutasse em uma natureza mais elevada. Por onde, nenhum
ser de natureza de grau inferior pode desejar o grau da natureza superior; assim, não deseja o asno ser
cavalo, porque já não seria asno se se transferisse no grau da natureza superior. Mas, neste ponto, a
imaginação se engana. Pois, por desejar um homem subir a um grau mais alto, quanto a certos
acidentes, que podem aumentar sem a destruição do sujeito, imagina que pode desejar um grau mais
elevado de natureza, ao qual não pode chegar sem que deixe de existir. Ora, é manifesto que Deus
excede o anjo, não por certos acidentes mas pelo grau da natureza; e assim, também um anjo excede o
outro. Donde, é impossível um anjo inferior desejar ser igual ao superior e, muito menos, igual a Deus.
Mas, desejar ser como Deus, por semelhança, de dois modos pode se dar. — De um modo, quanto ao
pelo que é natural a um ser o assemelhar-se a Deus. E assim, quem neste sentido deseja ser semelhante
a Deus não peca, pois, deseja alcançar a semelhança com Deus, na ordem devida, a saber, enquanto
tem essa semelhança recebida de Deus. Se, porém, desejasse ser semelhante a Deus por justiça, como
por virtude própria e não pela virtude de Deus, pecaria. — De outro modo, pode alguém desejar ser
semelhante a Deus quanto ao que não lhe é natural que com Deus se assemelhe; como se alguém
desejasse criar o céu e a terra. O que é próprio de Deus; e, nesse desejo, haveria pecado.
Ora, deste modo é que o diabo desejou ser como Deus. Não que com Deus se assemelhasse, por não
haver ninguém a quem fosse inferior, absolutamente, porque, então desejaria o seu não-ser; pois
nenhuma criatura pode existir, senão por participar o ser dependentemente de Deus. Mas desejou
indebitamente ser semelhante a Deus, porque desejou como fim último da beatitude aquilo ao que
podia chegar pela virtude da sua natureza, desviando o seu desejo da beatitude sobrenatural, que é
graça de Deus. — Ou, se desejou como fim último a semelhança com Deus, que é dom da graça, quis tê-
la pela virtude da sua natureza, e não pelo auxílio divino, segundo a disposição de Deus. E isto é
consoante às palavras de Anselmo, dizendo ter o demônio desejado aquilo que obteria se perseverasse.
— E estas duas explicações se reduzem a uma só: de uma e outra maneira o diabo desejou ter a
beatitude final, pela sua virtude, o que é próprio de Deus.
Como porém o que é por si é princípio e causa do que existe por outro, daí também resulta que desejou
ter um certo principado sobre todos os outros seres. No que também perversamente quis assemelhar-
se a Deus.
E, daqui se deduzem claramente as RESPOSTAS A TODAS AS OBJEÇÕES.

## Art. 4 — Se alguns demônios são naturalmente maus.
O quarto discute-se assim. — Parece que alguns demônios são naturalmente maus.

1. — Pois, diz Porfírio, como refere Agostinho, que há um certo gênero de demônios de natureza falaz,
que simulam os deuses e as almas dos defuntos. Ora, ser falaz é ser mau. Logo, alguns demônios são
naturalmente maus.

2. Demais. — Como os anjos foram criados por Deus, assim também os homens. Ora, alguns homens são
naturalmente maus, dos quais diz a Escritura: A malícia lhes é natural. Logo, também alguns homens
podem ser naturalmente maus.

3. Demais. — Alguns animais irracionais têm certas malícias naturais; assim, as raposas são
naturalmente sorrateiras, o lobo naturalmente é rapace; e contudo são criaturas de Deus. Logo,
também os demônios, embora criaturas de Deus, podem ser naturalmente maus.
Mas, em contrário, diz Dionísio, que os demônios não são naturalmente maus.

SOLUÇÃO. — Tudo o existente, enquanto existe e tem uma determinada natureza, tende naturalmente
para algum bem, por provir de um princípio bom, pois, sempre o efeito se converte no seu princípio.
Ora, acontece que todo bem particular vai sempre acompanhado de algum mal; assim, com o fogo vai
junto o mal de ser consumido de outros seres; mas nenhum mal pode ir de mistura com o bem
universal. Se, portanto, há algum ser cuja natureza se ordene a algum bem particular, esse pode
naturalmente tender para algum mal, não como mal, mas acidentalmente, enquanto esse mal vai com
algum bem. Se, porém, há algum ser cuja natureza seja ordenada ao bem, segundo a noção comum de
bem, esse não pode tender para nenhum mal. Ora, é manifesto, toda natureza intelectual, se ordena ao
bem universal, que pode apreender e é o objeto da vontade. Donde, sendo os demônios substâncias
intelectuais, de nenhum modo podem ter inclinação natural para qualquer mal. E logo, não podem ser
naturalmente maus..

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho, no passo citado, repreende Porfírio dizendo
que os demônios são naturalmente falazes; e afirma que são falazes, não naturalmente, mas por
vontade própria. Mas Porfírio ensinou que os demônios são naturalmente falazes, pelos conceber como
animais de natureza sensitiva e alma passiva. Ora, a natureza sensitiva se ordena para algum bem
particular com o qual pode ir o mal de mistura. E, deste modo, os demônios podem ter inclinação
natural para o mal; acidentalmente, porém, enquanto o mal está de mistura com o bem.

RESPOSTA À SEGUNDA. — Pode-se dizer que a malícia de alguns homens é natural, quer pelo costume,
que é uma segunda natureza, quer por inclinação natural, por parte da natureza sensitiva, a alguma
paixão desordenada; assim, certos são chamados naturalmente iracundos ou concupiscentes. Não,
porém, por parte da natureza intelectual.

RESPOSTA À TERCEIRA. — Os brutos, segundo a natureza sensitiva, têm inclinação natural a certos bens
particulares, com os quais vão de mistura certos males. Assim a raposa, a buscar o alimento
sagazmente, com o que vai junto o dolo; por isso, ser dolosa não é mal para a raposa, porque lhe é
natural, assim como também não é mal para o cão ser furioso, conforme diz Dionísio.

## Art. 5 — Se o diabo, no primeiro instante da sua criação, foi mau por culpa da própria vontade.
O quinto discute-se assim. — Parece que o diabo, no primeiro instante da sua criação, foi mau por
culpa da própria vontade.

1. — Pois, diz a Escritura falando do diabo: Ele era homicida desde o princípio.

2. Demais. — Segundo Agostinho, a informidade da criatura não precedeu à formação no tempo, mas na
origem somente. Pois, por céu, que se lê como criado em primeiro lugar, se entende, conforme diz
Agostinho, a natureza angélica informe. E a expressão da Escritura referindo que Deus disse: Faça-se a
luz, e a luz foi feita, se entende da formação da natureza angélica pela sua conversão ao Verbo. Logo,
simultaneamente foi a natureza do anjo criada e a luz foi feita. Mas, simultaneamente, feita a luz, esta
se separou das trevas, pelas quais se entendem os anjos pecadores. Logo, no primeiro instante da sua
criação, uns anjos foram bem-aventurados e outros pecaram.

3. Demais. — O pecado se opõe ao mérito. Mas, no primeiro instante da sua criação, alguma natureza
intelectual pode merecer, como a alma de Cristo ou ainda os próprios bons anjos. Logo, também os
demônios, no primeiro instante da sua criação, puderam pecar.

4. Demais. — A natureza angélica é mais virtuosa do que a corpórea. Ora, o ser corpóreo começa
imediatamente, no primeiro instante da sua criação, a operar; assim, o fogo, no primeiro instante em
que foi gerado, começa a mover-se para o alto. Logo, também o anjo, no primeiro instante da sua
criação, pôde operar. E, então, a sua operação ou foi reta ou não-reta. Se reta, mereceram com ela a
beatitude, pois tinham a graça. Ora, como nos anjos, segundo já antes se viu, ao mérito segue-se
imediatamente o prêmio, eles teriam de ser imediatamente bem-aventurados e, então, nunca teriam
pecado, o que é falso. Logo, conclui-se que, no primeiro instante, não operando retamente, pecaram.
Mas, em contrário, diz a Escritura. E viu Deus todas as coisas que tinha feito e eram muito boas. Ora,
entre esses seres estavam também os demônios. Logo estes, algum tempo, foram bons.

SOLUÇÃO. — Alguns ensinaram que os demônios foram maus imediatamente, desde o primeiro
instante da sua criação; não, certo, por natureza, mas pelo pecado da própria vontade; pois, desde que
o demônio foi feito, recusou a justiça. E, como diz Agostinho, a essa opinião, quem com ela aquiescer
nem por isso irá com aqueles heréticos, a saber, os maniqueus, que atribuem ao diabo a natureza do
mal.
Mas esta opinião encontra a autoridade da Escritura que, sob a figura do príncipe de Babilônia, diz do
diabo:Como caíste do céu, ó Lucifer, tu que ao nascer do dia tanto brilhavas? E, noutro passo, diz ao
diabo, na pessoa do rei de Tiro: Tu estiveste nas delícias do paraíso de Deus. Por isso, a opinião supra foi
racionavelmente reprovada, como errônea.
Donde veio o dizerem alguns que os anjos, no primeiro instante da sua criação, podendo pecar, não
pecaram todavia.
Mas também esta opinião é reprovada por alguns pela razão que, quando duas operações se seguem
uma à outra, é impossível ambas terminarem no mesmo momento. Ora, é manifesto, o pecado do anjo
foi-lhe obra posterior à criação, da qual o termo é o ser mesmo do anjo; ao passo que o termo da
operação do pecado é serem os anjos maus. Logo, é impossível que o anjo tivesse sido mau, no primeiro
instante em que começou a existir.
Mas ainda esta explicação não pode ser considerada como suficiente, pois tem cabida somente nos
movimentos temporais que se realizam sucessivamente. Assim, se o movimento local se segue à
alteração, não podem esta e aquela terminar no mesmo instante. Mas, se as mudanças forem
instantâneas, simultaneamente e no mesmo instante pode se realizar o termo da primeira e o da
segunda mutação; assim, no mesmo instante, ilumina-se a lua pelo sol e o ar, pela lua. Ora, é manifesto
que a criação é instantânea e, semelhantemente, o movimento do livre arbítrio, nos anjos; pois, como
do sobredito se colhe, eles não precisam de colações e nem do discurso racional. Donde, nada impede
sejam simultâneos e no mesmo instante o termo da criação e o do livre arbítrio.
E portanto devemos dizer, diferentemente das outras doutrinas, que é impossível tivesse o anjo pecado,
no primeiro instante, por um ato desordenado do livre arbítrio. Pois, embora um ser simultaneamente,
com o primeiro instante em que começou a existir, pudesse também começar a agir, todavia, essa
operação, simultânea com a existência, lhe adveio do agente do qual recebeu a existência; assim,
mover-se para o alto é próprio ao fogo em virtude do gerador deste. Donde, o ser que tiver a existência
recebida de um agente deficiente, que possa ser causa defectiva da ação, poderá, no primeiro instante
em que começou a existir, ter operação defectiva; assim, o tíbia claudicante de nascença, pela
debilidade da geração, imediatamente começará a claudicar. Ora, o agente que trouxe os anjos ao ser,
Deus, não pode ser causa do pecado.
Donde, não se pode dizer que o diabo fosse mau, no primeiro instante da sua criação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como afirma Agostinho, quando se diz que o diabo peca
desde o começo, deve-se pensar que peca não no começo, em que foi criado, mas no começo do
pecado; isto é, que nunca se separou do seu pecado.

RESPOSTA À SEGUNDA. — Esta distinção entre a luz e as trevas, entendo-se por trevas os pecados dos
demônios, deve se compreender em relação à presciência de Deus. Por isso, Agostinho diz que só pode
discernir a luz das trevas aquele que pôde prever-lhes a queda mesmo antes de terem caído.

RESPOSTA À TERCEIRA. — Tudo o que é meritório provém de Deus; logo, no primeiro instante da sua
criação o anjo podia merecer. Mas não se pode raciocinar do mesmo modo em relação ao pecado, como
já se disse.

RESPOSTA À QUARTA. — Deus não escolheu, entre os anjos, antes da aversão de uns e da conversão de
outros, como diz Agostinho; e assim todos, criados em graça, no primeiro instante mereceram. Mas
alguns deles, imediatamente, puseram impedimento à própria beatitude, anulando o mérito
precedente; e, por isso, foram privados da beatitude, que mereceram.

## Art. 6 — Se mediou alguma demora entre a criação e a queda do anjo.
O sexto discute-se assim. — Parece que mediou alguma demora entre a criação e a queda do anjo.

1. — Pois, diz a Escritura: Tu caminhavas perfeito nos teus caminhos, desde o dia da tua criação, até que
a iniqüidade se achou em ti. Mas, o andar, sendo movimento contínuo, requer certa demora. Logo,
mediou alguma demora entre a criação e a queda do diabo.

2. Demais. — Orígenes diz que a serpente antiga não rastejou, imediatamente desde o princípio, sobre o
peito e o ventre; pelo que se lhe entende o pecado. Logo, o diabo não pecou imediatamente depois do
primeiro instante da sua criação.

3. Demais. — Poder pecar é comum ao homem e ao anjo. Ora, houve um lapso de tempo entre a
formação do homem e o seu pecado. Logo, por igual razão, houve também um lapso entre a formação
do diabo e o seu pecado.

4. Demais. — O diabo foi criado num instante e pecou em outro. Ora, entre quaisquer dois instantes,
medeia um tempo. Logo, decorreu algum tempo entre a criação e a queda do diabo.
Mas, em contrário, diz a Escritura que o diabo não permaneceu na verdade. E, como diz Agostinho, é
preciso compreender esse passo no sentido que o diabo foi constituído na verdade, não permanecendo
nela porém.

SOLUÇÃO. — Sobre esse assunto há dupla opinião. Mas a mais provável e consoante aos ditos dos
Santos é que o diabo pecou imediatamente depois do primeiro instante da sua criação. E é necessário
admiti-lo, se se estabelecer que o diabo praticou um ato de livre arbítrio, no primeiro instante da sua
criação, e foi criado em graça, como antes dissemos. Pois, os anjos obtendo a beatitude por um só ato
meritório, como antes ficou dito, se o diabo, criado em graça, no primeiro instante, mereceu, receberia
a beatitude imediatamente após esse primeiro instante, se não tivesse imediatamente posto
impedimento, pecando. Se porém se admitir que o anjo não foi criado em graça, ou que não podia
praticar um ato de livre arbítrio, no primeiro instante, nada impede tenha decorrido um lapso de tempo
entre a criação e a queda.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por movimentos corporais, medidos pelo tempo, a
Sagrada Escritura entende, às vezes, metaforicamente, os movimentos espirituais instantâneos; e assim,
pela expressão — andar — se entende o movimento do livre-arbítrio que tende para o bem.

RESPOSTA À SEGUNDA. — Orígines diz, que a serpente antiga não rastejou, imediatamente desde o
princípio, sobre o peito, por causa do primeiro instante, em que não era má.

RESPOSTA À TERCEIRA. — O anjo tem o livre arbítrio inflexível, depois da eleição; e portanto, seria
confirmado no bem se não estivesse posto impedimento à beatitude, imediatamente depois do
primeiro instante em que teve o movimento natural para o bem. O mesmo, porém, não se dando com o
homem, a objeção não colhe.

RESPOSTA À QUARTA. — É verdade que há um tempo médio entre dois instantes quaisquer, se o tempo
for contínuo, como o prova Aristóteles. Mas, em relação aos anjos, que não estão sujeitos ao
movimento celeste, primariamente medido pelo tempo contínuo, por tempo se entende a sucessão
mesma das operações do intelecto ou também do afeto. Assim pois, se entende que nos anjos o
primeiro instante corresponde à operação da mente angélica, pela qual ela se converte a si mesma pelo
conhecimento vespertino; porque, no primeiro dia se comemora a tarde e não a manhã. E certamente,
essa operação foi boa em todos os anjos. Mas, alguns deles converteram-se dessa operação para o
louvor do Verbo, pelo conhecimento matutino; outros, porém, permanecendo em si mesmos, fizeram-
se noite, intumescidos da soberba, como diz Agostinho. E assim, sendo a operação primeira comum a
todos, eles se distinguiram pela segunda. E portanto, no primeiro instante, todos foram bons; no
segundo, distinguiram-se os bons dos maus.

## Art. 7 — Se o anjo supremo, dentre os que pecaram, era o supremo de todos.
O sétimo discute-se assim. — Parece que o anjo supremo, dentre os que pecaram, não era o supremo
de todos.

1. — Pois, diz a Escritura: Tu eras um Querubim que estendia as suas asas e protegia (o trono de Deus), e
eu coloquei-te sobre o monte santo de Deus. Ora, a ordem dos Querubins está subordinada à dos
Serafins, como diz Dionísio. Logo, o anjo superior, dentre os que pecaram, não era superior a todos.

2. Demais. — Deus fez a natureza intelectual para que ela conseguisse a beatitude. Se portanto o anjo
superior a todos pecou, segue-se que o plano divino, na mais nobre das criaturas, ficou frustrado, o que
é inconveniente.

3. Demais. — Quanto mais um ser se inclina para outro, tanto menos poderá deste separar-se. Ora, o
anjo, quanto mais elevado, tanto mais se inclina para Deus. Logo, tanto menos poderá, pecando, perder
a Deus; e, assim, resulta que o anjo que pecou não foi o supremo de todos, mas estava entre os
inferiores.
Mas, em contrário, diz Gregório: o primeiro anjo que pecou, por ser o chefe de todas as ordens dos
anjos e lhes transcender o esplendor, era, comparado com eles, mais esplêndido.

SOLUÇÃO. — Duas coisas se devem considerar no pecado: a propensão e o motivo para pecar. Se, pois,
considerarmos, nos anjos, a propensão, menos parece terem pecado os superiores que os inferiores.
Por isso Damasceno diz que o maior dos que pecaram era o chefe dos da ordem terrestre. E esta opinião
parece consoante à posição dos Platônicos referida por Agostinho. Pois, diziam eles, que todos os
deuses eram bons; mas, dos demônios, uns bons, outros maus, chamando deuses às substâncias
intelectuais superiores ao globo lunar e, demônios, as inferiores a esse globo, mas superiores aos
homens na ordem da natureza. Nem se deve rejeitar esta opinião como alheia à fé, pois toda criatura
corporal é governada por Deus, por meio dos anjos, como diz Agostinho. Donde, nada impede dizer-se,
que os anjos inferiores estão divinamente ordenados a administrar os corpos inferiores; os superiores,
porém, a administrar os corpos superiores; e por fim, os mais elevados de todos, a assistirem a Deus. E
segundo esta opinião, Damasceno diz que os que caíram foram dos inferiores, na ordem dos quais,
todavia, permaneceram alguns bons.
Se porém se considerar o motivo para pecar, é este maior nos superiores que nos inferiores. Pois, o
pecado dos demônios foi a soberba, como antes se disse; e desta o motivo é a excelência, maior nos
superiores. Por isso diz Gregório que pecou o mais elevado de todos; opinião que parece mais provável.
Porquanto o pecado do anjo não procedeu de nenhuma propensão, mas somente do livre arbítrio. Por
onde, mais digna de consideração parece ser a razão tirada do motivo para pecar. — Mas nem por isto
se deve rejeitar a outra opinião, porque mesmo nos chefes dos anjos inferiores podia haver algum
motivo para pecar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Querubim quer dizer plenitude da ciência e, Serafim,
ardentesou que incendeiam. Assim, é claro que o Querubim tira a sua denominação da ciência, que
pode ir com o pecado mortal; porém, a denominação de Serafim vem do ardor da caridade, que não
pode coexistir com tal pecado. Por isso, o primeiro anjo pecador não era denominado Serafim, mas
Querubim.

RESPOSTA À SEGUNDA. — A intenção divina não se frustra nem nos que pecam nem nos que se salvam.
Pois, Deus tem a presciência de um e outro acontecimento, dos quais tira glória para si, salvando a uns
pela sua bondade, punindo aos outros pela sua justiça. Ora, a criatura intelectual, pecando, desvia-se do
último fim. E nem isso repugna a qualquer criatura sublime, pois, a criatura intelectual foi criada por
Deus, de natureza tal que esteja no arbítrio dela agir visando o fim.

RESPOSTA À TERCEIRA. — Por maior inclinação que o mais elevado de todos os anjos tivesse para o
bem, ela, todavia, não se lhe impunha com necessidade. Donde, podia não a seguir, com seu livre
arbítrio.

## Art. 8 — Se o pecado do primeiro anjo foi causa de outros pecarem.
O oitavo discute-se assim. — Parece que o pecado do primeiro anjo não foi causa de os outros
pecarem.

1. — Pois, a causa é anterior ao efeito. Ora, todos pecaram simultaneamente, como diz Damasceno.
Logo, o pecado de um não foi causa de os outros pecaram.

2. Demais. — O primeiro pecado do anjo só pôde ser a soberba, como antes se disse. Ora, a soberba
busca a excelência, e mais repugna a esta que alguém se submeta a um inferior do que a um superior. E,
assim, não parece tivessem os demônios pecado por terem querido antes se submeter a algum dos
anjos superiores, do que a Deus. O pecado de um anjo teria sido, sim, a causa de os outros pecarem se
esse tivesse induzido os outros a se lhe submeterem. Logo, resulta que o pecado do primeiro anjo não
foi a causa de os outros pecarem.

3. Demais. — É maior pecado querer submeter-se a outrem, contra Deus, do que querer, contra Deus,
governar a outrem, porque, neste último caso, é menor o motivo de pecar. Se, pois, o pecado do
primeiro anjo foi causa de os outros pecarem pelos ter induzido a se lhe submeterem, mais gravemente
pecaram os anjos inferiores que o superior; o que vai contra a Escritura: Este dragão que formaste; ao
que diz a Glossa:O que era mais excelente do que todos os outros, pelo ser, tornou-se maior pela
malícia. Logo, o pecado do primeiro anjo não foi causa de os outros pecarem.
Mas, em contrário, diz a Escritura que o dragão arrastou consigo a terceira parte das estrelas.

SOLUÇÃO. — O pecado do primeiro anjo foi causa de os outros pecarem, não os obrigando, mas os
induzindo por uma quase exortação. E a prova disto resulta de se submeterem todos os demônios ao
demônio supremo, como se vê manifestamente do que diz o Senhor, na Escritura: Apartai-vos de mim,
malditos, para o fogo eterno, que foi preparado para o diabo e para os seus anjos. Pois, a ordem da
divina justiça determina que quem consentiu na culpa, sugestionado por outrem, a este deve submeter-
se, na pena, segundo a Escritura:Todos aquele que é vencido, é escravo daquele que o venceu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora os demônios tivessem pecado
simultaneamente, contudo o pecado de um podia ser a causa de os outros pecarem. Pois, o anjo não
precisa de nenhum lapso de tempo para escolher, exortar ou consentir, como o homem, que precisa
deliberar para eleger e consentir, e carece da locução vocal para exortar; coisas todas que se realizam
no tempo. Ora, como é claro, também no mesmo instante concebemos algo na mente e começamos a
falar; e no último instante da locução, quem compreendeu o pensamento já pode assentir ao que
dissemos; e isso de dá sobretudo com os princípios primeiros, simultaneamente ouvidos e admitidos.
Portanto, eliminado o tempo da locução e da deliberação, necessário para nós, no mesmo instante em
que o primeiro anjo exprimiu o seu desejo por meio duma locução inteligível, foi possível aos outros
consentir nele.

RESPOSTA À SEGUNDA. — O soberbo, prefere em igualdade de situação, submeter-se antes ao superior
que ao inferior. Mas, se conseguir, sob o inferior, alguma excelência maior que sob o superior, antes
prefere obedecer àquele do que a este. Portanto, não era contra a soberba dos demônios o terem
querido obedecer ao inferior, consentindo-lhe no principado e querendo tê-lo como príncipe e chefe,
para conseguirem, pela virtude natural, a beatitude última; sobretudo porque, por então, estavam
também sujeitos ao anjo supremo na ordem da natureza.

RESPOSTA À TERCEIRA. — Como já ficou dito antes, nada há no anjo que lhe retarde as tendências;
antes, é movido para o seu objeto, bom ou mau, em toda a sua virtude. Assim, pois, tendo o anjo
supremo virtude natural maior que os inferiores, resvalou no pecado com mais intenso movimento. Por
onde, também veio a ser maior na malícia.

## Art. 9 — Se mais anjos pecaram do que perseveraram.
O nono discute-se assim. — Parece que mais anjos pecaram do que perseveraram.

1. — Pois, como diz o Filósofo, o mal é mais freqüente do que o bem.

2. Demais. — A justiça e o pecado encontram-se, pela mesma razão, nos anjos e nos homens. Ora, há
mais homens maus que bons, segundo a Escritura: O número dos insensatos é infinito. Logo, pela
mesma razão, nos anjos.

3. Demais. — Os anjos se distinguem pelas pessoas e pelas ordens. Se, portanto, mais anjos
perseveraram, parece que nem em todas as ordens houve pecadores.
Mas, em contrário, diz a Escritura: Muitos mais estão conosco do que tu com eles; o que se entende dos
bons anjos, que nos auxiliam, e dos maus, que se nos opõem.

SOLUÇÃO. — Mais anjos perseveraram do que pecaram, por se o pecado contra a inclinação natural.
Ora, o que é contra a natureza acontece menos freqüentemente, pois esta consegue sempre ou quase
sempre o seu efeito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No passo aduzido, o Filósofo se refere aos homens que,
abandonando o bem da razão, só conhecido de poucos, praticam o mal por seguirem os bens sensíveis,
conhecidos do maior número. Ora, a natureza dos anjos sendo somente intelectual, a objeção não
colhe.
Por onde é clara a RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — Para os que dizem que o diabo era o maior da ordem inferior dos anjos, a
que preside aos acontecimentos terrestres, é claro que houve anjos decaídos, não de todas as ordens,
mas só da ínfima. Segundo, porém, os que dizem que o maior dos diabos era da ordem suprema, é
provável terem caído alguns, de cada uma das ordens; assim como, a fim de suprirem a ruína angélica,
foram assumidos homens, para cada ordem. No que tudo mais comprova a liberdade do livre arbítrio,
capaz de se inclinar para o mal, qualquer que seja o grau da criatura. A Sagrada Escritura, contudo, não
atribui aos demônios os nomes de certas ordens, como os dos Serafins e dos Tronos; porque esses
nomes provém do ardor da caridade e da habitação com Deus, que não podem coexistir com o pecado.
Atribuem-se-lhes, porém, os nomes deQuerubins, Potestades e Principados, nomes derivados da ciência
e do poder, comuns tanto aos bons como aos maus.