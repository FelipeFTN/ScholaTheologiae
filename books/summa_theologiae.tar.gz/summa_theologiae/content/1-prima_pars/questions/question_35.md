# Questão 35: Da imagem
Em seguida devemos tratar da imagem. E nesta questão discutem-se dois artigos:

## Art. 1 — Se a imagem se predica pessoalmente, de Deus.
(Infra, q. 93, a. 5, ad. 4; I Sent., dist. XXVIII, q. 2, a. 2).
O primeiro discute-se assim. – Parece que a imagem não se predica pessoalmente, de Deus.

1. – Pois, Agostinho diz: Uma é a divindade e a imagem da santa Trindade, à semelhança da qual foi feito
o homem. Logo, a imagem se predica essencial e não, pessoalmente.

2. Demais. – Hilário diz: A imagem é a espécie que não difere da coisa imaginada. Ora, a espécie ou
forma se diz, de Deus, essencialmente. Logo, também a imagem.

3. Demais. – Imagem vem de imitar, que implica anterioridade e posterioridade. Ora, nas Pessoas
divinas não há anterior nem posterior. Logo, imagem não pode ser nome pessoal de Deus.
Mas, em contrário, diz Agostinho: Que é mais absurdo do que falar de imagem de si? Logo, a imagem se
diz de Deus, relativamente, e é, portanto, nome pessoal.

SOLUÇÃO. – A semelhança é da essência da imagem. Não basta, porém, qualquer semelhança para
haver imagem, mas, a existente na forma da coisa; ou, pelo menos, em alguma revelação da forma. Ora,
principalmente a figura é que se considera como sendo a revelação da forma das coisas corpóreas;
assim, vemos que, de animais diversos pela forma, diversas são as figuras, não porém as cores. Por
onde, a cor de uma coisa, pintada na parede, sem se lhe pintar a figura, não se chama imagem. Nem a
própria semelhança, porém, da espécie ou da figura basta, mas a essência da imagem requer a origem;
pois, como diz Agostinho, um ovo não sendo a expressão de outro, não é deste a imagem. Donde, a
verdadeira imagem há de necessariamente proceder de outro ser ao qual seja semelhante pela forma
ou, ao menos, por uma revelação desta. Ora, o que em Deus importa processão ou origem é pessoal.
Logo, o nome de Imagem é pessoal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Chama-se propriamente imagem o que procede, por
semelhança, de outro; e o de que alguma coisa procede por semelhança se chama propriamente
exemplar, e impropriamente, imagem. É no primeiro sentido que Agostinho (Fulgêncio) usa do nome de
imagem, dizendo ser a divindade da santa Trindade a imagem à qual o homem foi feito.

RESPOSTA À SEGUNDA. – Espécie, no sentido em que Hilário a considera na definição de imagem,
importa a forma de um ser aplicada a outro. E deste modo chama à imagem espécie de um ser, assim
como se chama forma de um ser aquilo que, tendo forma semelhante a tal ser, com ele se assemelha.

RESPOSTA À TERCEIRA. – A imitação nas Pessoas divinas, não implica posterioridade, mas somente
semelhança.

## Art. 2 — Se o nome de imagem é próprio do Filho.
(Infra, q. 93, a. 1. ad2; I Sent., dist. III, q. 3, ad. 5 dist. XXVIII, q. 2, a. 1. ad 3; a. 3; II, dist. XVI, a. 1; Contra
errors Graec., cap. X; I Cor., cap. XL, lect, II; II, cap. IV, lect. II Coloss, cap. I, lect. IV; Hebr., cap. I, lect II).
O segundo discute-se assim. – Parece que o nome de Imagem não é próprio do Filho.

1. – Pois, como diz Damasceno, o Espírito Santo é a imagem do Filho. Logo, este não é próprio do Filho.

2. Demais. – A imagem é por essência semelhança expressiva, como diz Agostinho. Ora, isto convém ao
Espírito Santo, que procede a modo de semelhança. Logo, o Espírito Santo é imagem; e, portanto, ser
Imagem não é próprio do Filho.

3. Demais. – Também o homem se chama imagem de Deus, segundo a Escritura (1 Cor 11, 7): O varão
não deve cobrir a sua cabeça, porque é a imagem e glória de Deus. Logo, ser Imagem não é próprio do
Filho.
Mas, em contrário, diz Agostinho, que só o Filho é Imagem do Pai.

SOLUÇÃO. – Os doutores dos Gregos dizem comumente, que o Espírito Santo é a imagem do Pai e do
Filho. Mas, os Doutores latinos só ao Filho atribuem o nome de imagem; pois, só ao Filho atribui tal
nome e Escritura canônica. Assim, o Apóstolo diz (Cl 1, 15): Que é a imagem de Deus invisível, o
primogênito de toda a criatura; e, noutro lugar (Hb 1, 3): O qual, sendo resplendor da glória é a figura da
sua substância.
E a razão disto alguns a dão dizendo, que o Filho convém com o Pai não somente pela natureza, mas
também pela noção de princípio; ao contrário, o Espírito Santo não convém com o Filho nem com o Pai
por nenhuma noção. – Mas, esta explicação não é suficiente. Pois, assim como pelas relações não há em
Deus igualdade nem desigualdade, como diz Agostinho, assim, nem semelhança, necessária
essencialmente à imagem.
E por isso outros dizem, que o Espírito Santo não pode ser chamado imagem do Filho, por não haver
imagem de imagem. Nem também do Pai, porque a imagem se refere imediatamente ao ser do qual é,
ao passo que o Espírito Santo se refere ao Pai pelo Filho. E nem tão pouco é imagem do Pai e do Filho,
porque então haverá uma só imagem, de dois, o que é impossível. Por onde se conclui, que o Espírito
Santo de nenhum modo é imagem. – Mas, nada disto é exato. Pois, sendo o Pai e o Filho princípio uno
do Espírito Santo, como adiante se dirá, nada impede sejam o Pai e o Filho, como um só, uma só
imagem, assim como o homem é a imagem una de toda a Trindade.
E, portanto, devemos dizer, diferentemente, que embora o Espírito Santo, pela sua processão, receba a
natureza do Pai, como o Filho, e todavia não se chama nato, assim, embora receba a espécie
semelhante do Pai, não se chama imagem. Porque o Filho procede como Verbo, a cuja essência
pertence à semelhança de espécie com o ser donde procede: mas isto não pertence à essência do amor,
embora convenha ao Amor chamado Espírito Santo, enquanto amor divino.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Damasceno e os outros doutores Gregos comumente
usam do nome de imagem significando perfeita semelhança.

RESPOSTA À SEGUNDA. – Embora o Espírito Santo seja semelhante ao Pai e ao Filho, todavia daí se não
segue seja imagem, pela razão já exposta.

RESPOSTA À TERCEIRA. – A imagem de um ser de duplo modo se encontra em outro. De um modo,
como no que é da mesma natureza específica; assim a imagem do rei está no seu filho. De outro modo,
como no que é de outra natureza; e assim a imagem do rei, na moeda. Ora, do primeiro modo o Filho é
a imagem do Pai; e do segundo se diz, que o homem é a imagem de Deus. Por onde, para significarmos,
no homem, a imperfeição da imagem, dele não só dizemos que é imagem, mas que é à imagem; com o
que significamos certo movimento do que tende à perfeição. Mas do Filho de Deus não podemos dizer
que seja à imagem, pois, é a perfeita imagem do Pai.