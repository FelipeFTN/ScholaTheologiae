# Questão 66: Da ordem da criação quanto à distinção.
Em seguida, devemos tratar da obra da distinção.
E, primeiro, da ordem da criação, quanto à distinção. Segundo, da distinção em si mesma.

## Art. 1 — Se a informidade da matéria precedeu, no tempo, à formação da mesma.
O primeiro discute-se assim. — Parece que a informidade da matéria precedeu, no tempo, à formação
da mesma.

1. — Pois, diz a Escritura: A terra, porém, estava informe e vazia, ou, invisível e descomposta, segundo
outra letra; pelo que se designa a informidade da matéria, conforme Agostinho. Logo, houve um tempo
em que a matéria, antes de ser formada, foi informe.

2. Demais. — O operar da natureza imita o de Deus, assim como a causa segunda imita a primeira. Ora,
na operação da natureza, a informidade precede, no tempo, à formação. Logo, também na de Deus.

3. Demais. — Como parte da substância, a matéria tem preponderância sobre o acidente. Ora, Deus
pode fazer existir o acidente sem o sujeito, como se vê no Sacramento do Altar. Logo, podia ter feito a
matéria existir sem a forma.
Mas, em contrário. A imperfeição do efeito atesta a do agente. Ora, Deus é agente perfeitíssimo, pelo
que dele se diz: As obras de Deus são perfeitas. Logo, a obra por ele criada nunca foi informe.
Demais. — a formação da criatura corporal foi realizada pela obra da distinção. Ora, à esta se opõe a
confusão como, à formação, a informidade. Se, pois, a informidade precedeu no tempo à formação da
matéria, segue-se que, no princípio, houve a confusão, na criatura corporal, a qual os antigos
chamavam Caos.

SOLUÇÃO. — Neste assunto diversas são as opiniões dos Santos Padres. Agostinho pretende que a
informidade da matéria corporal não precedeu, no tempo, mas só pela origem ou pela ordem da
natureza, à formação da mesma. Outros porém, como Basílio, Ambrósio e Crisóstomo, opinam que a
informidade precedeu, no tempo, à formação. E embora essas opiniões pareçam contrárias, contudo
pouco entre si diferem. Pois, Agostinho compreende a informidade da matéria diferentemente dos
outros.
Para ele, essa informidade significa carência de qualquer forma; sendo, portanto, impossível dizer-se
que tal informidade precedeu, no tempo, quer à formação, quer à distinção da matéria. O que é
manifesto, quanto à formação; pois, se precedeu, na duração, a matéria informe já era atual, porque a
duração, sendo termo da criação, importa o ato e este, em si mesmo, é forma. Dizer, portanto, que a
matéria precedeu, sem forma, é idêntico a dizer que o ser atual não o é, o que implica contradição. Nem
mesmo se pode dizer que tinha alguma forma comum, sobrevindo-lhe, depois, formas diversas, pelas
quais se tornou distinta. Pois, tal opinião seria idêntica à dos antigos físicos, que ensinavam ser a
matéria prima algum corpo em ato, como o fogo, o ar, a água ou um corpo médio. Donde resultaria que
o vir-a-ser não seria senão o alterar-se. Porque essa forma precedente, dando o ser atual, no gênero da
substância, e tornando o ser tal e não tal outro, resultaria que a forma superveniente não causaria
simplesmente o ser atual, mas um ser atual, o que é próprio à forma acidental; e portanto, as formas
seguintes seriam acidentes, em relação aos quais não há geração, mas alteração. Portanto, deve-se dizer
que a matéria prima nem foi criada completamente sem forma, nem com forma comum, senão com
formas distintas. Por onde, se a informidade da matéria, se refere à condição da matéria prima, que, de
si mesma, nenhuma forma tem, tal informidade não precedeu à formação ou à distinção da mesma, no
tempo, como diz Agostinho; senão somente pela origem ou pela natureza, do modo pelo qual a
potência é anterior ao ato e a parte, ao todo.
Outros Santos Padres, porém, compreendem a informidade como exclusiva, não de qualquer forma,
mas só da formosura e da beleza que, atualmente, se manifesta na criatura corpórea. E, assim, sentem
que tal informidade da matéria corporal precedeu, pela duração, à formação da mesma. Por onde, neste
sentido, Agostinho concorda com eles, em parte, e, em parte, discorda, como a seguir se virá.
Quanto à expressão do Gênesis, ela pode significar que, faltando-lhe uma tríplice formosura, por isso
informe era chamada a criatura corporal. Assim, faltando ao corpo diáfano total, chamado céu, a beleza
da luz, por isso se diz que as trevas cobriam a face do abismo. Faltava também, à terra, dupla beleza.
Uma, a que tem por estar descoberta das águas e, por isso, se diz que a terra estava
informe ou invisível; pois, o seu aspecto corporal não podia aparecer, por causa das águas que de todos
os lados a cobriam. Outra, a que tem, por estar ornada de ervas e plantas, dizendo-se, por isso, que
era vazia ou descomposta, i. é., não ornada, segundo diferente lição. E assim, tendo preestabelecido
duas naturezas criadas, o céu e a terra, exprimiu a informidade do céu dizendo: as trevas cobriam a face
do abismo, incluindo no céu também o ar; e a informidade da terra, dizendo:A terra estava informe e
vazia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Terra, aqui, é tomada em sentidos diferentes por
Agostinho e pelos outros Santos Padres. Conforme Agostinho, pelos nomes terra e água, deve se
entender neste passo a matéria prima em si mesma. Porque Moisés não podia dar a compreender a
matéria prima a um povo rude, a não ser por semelhança com coisas desse povo conhecidas. Por isso,
exprimiu-a sob multíplice semelhança, não a denominando somente água, ou somente terra, para não
parecer que, na verdade das coisas, a matéria prima fosse a terra ou a água. Se bem tenha semelhança
com a terra, como fundamento que é das formas; e com a água, como apta a ser informada por diversas
formas. Assim, neste sentido, é chamada a terra informe e vazia,ou invisível e descomposta, pois a
matéria é conhecida pela forma. Por onde, em si mesma considerada, é chamada invisível, ou vazia,
completando-se a sua potência pela forma. Por isso também Platão chamou à matéria lugar. — Outros
Santos Padres porém, entendem por terra o elemento mesmo da terra, e a opinião deles sobre a sua
informidade, já a referimos.

RESPOSTA À SEGUNDA. — A natureza produz o efeito atual, do ser em potência; sendo, portanto,
necessário que, na sua operação, a potência preceda ao ato, no tempo; assim como a informidade, à
formação. Mas Deus produz do nada o ser atual; e, portanto pode produzir imediatamente um ser
perfeito, pela magnitude do seu poder.

RESPOSTA À TERCEIRA. — O acidente, sendo forma, é um certo ato; porém a matéria, em si mesma, é
ser em potência. Por onde, mais repugna à matéria existir em ato, sem a forma, do que ao acidente sem
o sujeito.

RESPOSTA À PRIMEIRA OBJEÇÃO EM CONTRÁRIO. — Se, segundo outros Santos Padres a informidade
precedeu, no tempo, à formação da matéria, isso não foi por impotência de Deus, mas pela sua
sapiência, para que se conservasse a ordem na condição das coisas, de modo a que fossem levadas do
imperfeito ao perfeito.

RESPOSTA À SEGUNDA. — Alguns físicos antigos ensinavam a confusão, exclusiva de toda distinção,
salvo Anaxágoras que admitia somente o intelecto como distinto e sem imisção. Mas, antes da obra da
distinção, a Escritura Sagrada coloca múltiplas distinções. — Assim, primeiro, a do céu e da terra, na
qual também se mostra a distinção quanto à matéria, como a seguir se verá; e tudo isto, quando diz: No
princípio criou Deus o céu e a terra. — Segundo, a distinção dos elementos, quanto às suas formas,
nomeando a terra e a água, sem nomear o ar e o fogo, por não ser claro aos rudes, aos quais Moisés
falava, que tais seres são corpos, como manifestamente o são a terra e a água. Embora Platão
(no Timeu) entendesse, pelo ar, o espírito do Senhor, porque o ar também se chama espírito, e, pelo
fogo, o céu, porque dizia ser este de natureza ígnea, como refere Agostinho. Mas Rabbi Moisés,
concordando em outros pontos com Platão, diz que o fogo é expresso pelas trevas; pois, como afirma, o
fogo não luz na esfera própria. Porém, parece mais conveniente o que já antes ficou dito, a saber, que,
na Escritura, Espírito do Senhor costuma ser tomado pelo Espírito Santo, do qual se diz que é conduzido
na superfície das águas, não corporalmente, mas do mesmo modo que a vontade do artífice é conduzida
na superfície da matéria a que quer dar forma. — A terceira distinção é expressa em relação à situação,
porque a terra estava debaixo das águas, que a tornavam invisível; e quanto ao ar, sujeito das trevas,
dele se afirma que estava sobre as águas, quando se diz as trevas cobriam a face do abismo. E o que
restava a distinguir, pelo que se segue se verá.

## Art. 2 — Se a matéria informe é a mesma em todos os corpos.
O segundo discute-se assim. — Parece que a matéria informe é a mesma em todos os corpos.

1. — Pois, diz Agostinho: Vejo as duas coisas que fizeste: uma, informada, outra, informe. E esta, diz, é a
terra invisível e sem forma, com que exprime a matéria das coisas corporais. Logo, a matéria de todos os
corpos é a mesma.

2. Demais. — O Filósofo diz, que as coisas do mesmo gênero têm a mesma matéria. Ora, todos os corpos
têm o mesmo gênero, isto é, o corpóreo. Logo, todos têm a mesma matéria. 3. Demais. — Atos diversos
supõem potências diversas, assim como um só ato supõe uma só potência. Ora, a forma de todos os
corpos é a mesma, a saber, a corporeidade. Logo, todos têm a mesma matéria.

4. Demais. — A matéria, em si mesma, é só potência. Ora, pelas formas é que há a distinção dos seres.
Logo, em si, é a mesma a matéria de todos os corpos.
Mas, em contrário. Todos os seres que têm a mesma matéria transmutam-se uns nos outros e são
mutuamente ativos e passivos, como diz Aristóteles. Ora, não se comportam assim mutuamente os
corpos celestes e os inferiores. Logo, a matéria deles não é a mesma.

SOLUÇÃO. — Várias são as opiniões dos filósofos, nesse assunto. — Platão e todos os filósofos
anteriores a Aristóteles ensinavam que todos os corpos são da natureza dos quatro elementos. Ora,
como estes têm a mesma matéria, como o mostra a geração e a corrupção deles, resulta,
consequentemente, que todos os corpos têm a mesma matéria. E o fato de serem certos corpos
incorruptíveis, Platão o explicava (no Timeu) não pela condição da matéria, mas pela vontade do artífice,
isto é, de Deus, que ele imagina dizendo aos corpos celestes: Dissolúveis pela vossa natureza, sois
indissolúveis pela minha vontade, porque esta é maior do que a vossa constituição.
Esta opinião, porém, Aristóteles a refuta, pelos movimentos naturais dos corpos. Pois, como o corpo
celeste tem movimento natural diverso do movimento natural dos elementos, resulta que a natureza
dele é diferente da dos quatro elementos. E sendo o movimento circular próprio do corpo celeste, sem
contrariedade; e o dos elementos, contrários entre si, pois um é de baixo para cima e o outro de cima
para baixo; assim, no corpo celeste não há contrariedade, e as há nos corpos elementares. Ora, sendo os
contrários a causa da corrupção e da geração, conclui-se que o corpo celeste é incorruptível, por
natureza, ao passo que os elementos são corruptíveis.
Não obstante, porém, essa diferença, da corruptibilidade e incorruptibilidade natural, Avicebron,
considerando a unidade da forma corporal, ensinou que todos os corpos têm a mesma matéria. Mas, se
a forma da corporeidade fosse, em si, uma, à qual outras formas sobreviessem, pelas quais os corpos se
distinguissem, seria forçoso admitir tal doutrina; pois, tal forma é imutavelmente inerente à matéria e,
por ela, todos os corpos seriam incorruptíveis. Mas a corrupção, dando-se então pela remoção das
formas subseqüentes não o seria absolutamente mas relativamente, pois, um certo ser atual seria o
substrato da privação. Como também opinavam os antigos físicos, admitindo como sujeito dos corpos
um certo ser atual, p. ex., o fogo, o ar ou outros semelhantes.
Ora, suposto que nenhuma forma do corpo corruptível permaneça como substrato da geração e da
corrupção, resulta, necessariamente, que não é a mesma a matéria dos corpos corruptíveis e a dos
incorruptíveis. Pois, sendo pelo que é, potencial, em relação à forma, é forçoso que, em si, a matéria
também o seja quanto à forma de todos os corpos dos quais é a matéria comum. Portanto, atualizada
por uma forma, ela é atual só quanto à essa forma, permanecendo, portanto, potencial, quanto às
formas de todos os corpos. Nem isto se exclui se uma dessas formas for mais perfeita que as outras e as
contiver, pela sua virtude; porque a potência em si mesma, comporta-se indiferentemente em relação
ao perfeito e ao imperfeito. Por onde, quando se une a uma forma imperfeita, é potencial em relação à
perfeita, e inversamente. Portanto, a matéria, unida à forma do corpo incorruptível; e não estando
unida a esta, atualmente, será simultaneamente forma e privação; pois, a privação não é senão a
carência da forma, naquilo que, em relação à forma, é potencial. Ora, esta disposição não é senão a do
corpo corruptível; é, logo, impossível que seja a mesma, por natureza, a matéria do corpo corruptível e a
do incorruptível.
E nem se deve dizer, como Averrois o imagina que o próprio corpo celeste, matéria do céu, potencial
quanto àsituação não o é quanto ao ser; sendo a sua forma substância separada que se lhe une como
motor. Pois, é impossível supor um ser em ato sem que o seu todo seja ato e forma, ou tenha ato e
forma. Removida, portanto, pelo intelecto, a substância separada tida como motor, se o corpo celeste
não tem forma, o que é ser composto da forma e do sujeito da mesma — resulta que é totalmente
forma e ato. Ora, todo ser tal é intelecto em ato, o que não se pode dizer do corpo celeste, que é
sensível. Resta, portanto, que a matéria do corpo celeste, em si considerada, não é potencial senão
quanto à forma que tem, pouco importando, no caso, qual seja ela, alma ou qualquer outra. Por onde,
tal forma aperfeiçoa a sua matéria a ponto que, nesta, de nenhum modo resta potência para o ser, mas
somente para a situação, como diz Aristóteles. Assim que, não é a mesma a matéria do corpo celeste e a
dos elementos, salvo por analogia, enquanto convém em a noção de potência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho segue, neste ponto, a opinião de Platão, que
não admitia a quinta essência. — Ou então a matéria informe é uma, pela unidade da ordem; assim
como todos os corpos se unificam na ordem da criatura corpórea.

RESPOSTA À SEGUNDA. — Se se considerar o gênero fisicamente, os seres corruptíveis e incorruptíveis
não estão no mesmo gênero, por causa das diversas modalidades da potência que têm, como diz
Aristóteles. Porém, no ponto de vista lógico, só um é o gênero de todos os corpos, por causa da noção
uma da corporeidade.

RESPOSTA À TERCEIRA. — A forma da corporeidade não é a mesma em todos os corpos, porque não
difere das formas pelos quais estes se distinguem, como se disse.

RESPOSTA À QUARTA. — Como a potência é relativa ao ato, são diversos os seres potenciais que se
ordenam a atos diversos; assim, a vista, a cor, e o ouvido, ao som. Donde, por isso mesmo, a matéria do
corpo difere da do elemento, porque não é potencial em relação à forma do elemento.

## Art. 3 — Se o céu empíreo foi criado simultaneamente com a matéria informe.
O terceiro discute-se assim. — Parece que o céu empíreo não foi criado simultaneamente com a
matéria informe.

1. — Pois, se o céu empíreo é alguma coisa, deve ser corpo sensível e, portanto, móvel. Ora, não é
móvel porque, se o fosse, o seu movimento o depreenderíamos pelo de algum corpo aparente, fato
nunca verificado. Logo, tal céu não foi criado simultaneamente com a matéria informe.

2. Demais. — Agostinho diz que os corpos inferiores são regidos pelos superiores em uma certa
ordem. Se, pois, o céu empíreo é o corpo supremo, necessário é tenha alguma influência nos corpos
inferiores. Ora, tal não se dá, sobretudo se esse céu for considerado imóvel; porque só o corpo movido
pode mover. Logo, o céu empíreo não foi criado simultaneamente com a matéria informe.

3. Demais. — Nem vale dizer que o céu empíreo é o lugar da contemplação e não é destinado a efeitos
naturais. Pois, Agostinho diz: Nós, enquanto percebemos, com a mente, algo de eterno, não estamos
neste mundo. Por onde se vê que a contemplação eleva a mente acima dos seres corpóreos. Logo, não
há um lugar corpóreo deputado à contemplação.

4. Demais. — Entre os corpos celestes há um que é diáfano, em parte, e, em parte, lúcido, a saber, o céu
sideral. Há também o céu totalmente diáfano, chamado, por alguns, céu aquoso ou cristalino. Se, pois,
há algum céu superior, esse há de ser totalmente lúcido. Ora, tal não pode ser, porque então o ar seria
continuamente iluminado, sem que nunca fosse noite. Logo, o céu empíreo não foi criado
simultaneamente com a matéria informe.
Mas, em contrário, comenta Estrabo: no dito da Escritura: — No princípio criou Deus o céu e a terra —
céu significa não o firmamento visível, mas o empíreo, isto é, ígneo.

SOLUÇÃO. — O céu empíreo é uma doutrina de Estrabo, Beda e Basílio, sendo concordes em o
considerarem como o lugar dos bem-aventurados. Assim, Estrabo e Beda dizem que, logo depois de
criado, ficou cheio de anjos. Basílio também afirma: Assim como os danados são precipitados na últimas
trevas, assim a remuneração das boas obras se realiza nessa luz de além mundo, onde aos bem-
aventurados está o domicílio do descanso.Porém esses autores entre si diferem quanto aos
fundamentos de tal doutrina. Assim, Estrabo e Beda admitem o céu empíreo pelo identificarem com o
firmamento, que foi feito, não no princípio, mas no segundo dia. Porém o fundamento de Basílio está
em que não se deve supor tenha Deus começado, absolutamente, a sua obra pelas trevas; objeção dos
maniqueus, que chamam ao Deus do Testamento Velho Deus das trevas.
Mas tais razões não são muito cogentes. Pois, essa questão do firmamento, do qual se lê que foi feito no
segundo dia, é resolvida de um modo por Agostinho e de outro por outros Santos Padres. Santo
Agostinho resolve a questão das trevas dizendo que a informidade, pela qual elas são designadas, não
precedeu à formação, quanto à duração, mas quanto à origem. Para os outros, porém, não sendo as
trevas nenhuma criatura, senão a privação da luz, elas atestam que a divina sapiência estabeleceu
primeiro num estado de imperfeição as coisas que criou do nada, levando-as, depois, a um estado
perfeito.
De maneira que a questão formulada pode ser convenientemente resolvida considerando-se a condição
mesma da glória. Pois, dupla é a glória esperada na remuneração futura: uma espiritual; outra corporal,
consistindo, não só na glorificação dos corpos humanos, mas também na total inovação do mundo. Ora,
a glória espiritual já começou, desde o princípio do mundo, na beatitude dos anjos, igualmente
prometida aos santos, pela Escritura. E por isso convinha que, também desde o princípio, a glória
corporal começasse em algum corpo, isento desde o princípio da servidão da corrupção e da
mutabilidade; e totalmente lúcido, como o será toda criatura corpórea, depois da ressurreição futura. E
tal é o céu chamado empíreo, i. é, ígneo, não pelo ardor, mas pelo esplendor.
Devemos saber, porém, que Agostinho diz que Porfírio discernia os anjos, dos demônios, atribuindo a
estes os lugares aéreos e àqueles os etéreos ou empíreos. Mas Porfírio, sendo platônico, considerava
esse céu sidéreo como ígneo, chamando-lhe, por isso, empíreo ou etéreo, derivando de ser o nome de
éter inflamado e não de ter o movimento veloz, como quer Aristóteles. E isto aqui se diz, não vá
ninguém pensar que Agostinho concebia o céu empíreo como os modernos agora o concebem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os corpos sensíveis são móveis em virtude da natureza
mesma do mundo, pois o movimento da criatura corpórea causa a multiplicação dos elementos. Mas, na
consumação última da glória, cessará o movimento dos corpos; e tal era necessário que fosse, desde o
princípio, a disposição do céu empíreo.

RESPOSTA À SEGUNDA. — Muito provável é que o céu empíreo, segundo alguns, sendo destinado ao
estado da glória, não tenha influência sobre os corpos inferiores, subordinados a outra ordem, como
destinados ao decurso natural das coisas. — Porém é mais provável sentir que assim como os supremos
anjos assistentes, embora não sejam enviados, como quer Dionísio, influem todavia sobre os médios e
os últimos, que são os enviados; assim também o céu empíreo, embora não movido, influi sobre os
corpos movidos. E por isso pode-se dizer que não é algo de transitivo e adveniente, pelo movimento, o
que influi sobre o primeiro céu movido, mas algo de fixo e de estável; p. ex. a virtude de conter ou
causar, ou algo de semelhante que implique uma dignidade.

RESPOSTA À TERCEIRA. — O lugar corpóreo é atribuído à contemplação, não por necessidade, mas por
congruência, para que a claridade exterior convenha com a interior. Por isso, Basílio diz que o espírito
assistente não podia estar imerso em trevas, mas possuía, em si, o hábito de existir na luz e na alegria.

RESPOSTA À QUARTA. — Como diz Basílio, é certo que o céu foi feito tomando a forma redonda; com
um corpo espesso e de tal modo forte que possa separar as coisas extrínsecas das internas. Por isso foi
constituída, necessariamente, depois dele, uma região abandonada, sem luz, por estar excluído o fulgor,
irradiante na parte superior. Mas, sendo o corpo do firmamento, embora sólido, diáfano por não
interceptar a luz — pois, vemos a das estrelas, não obstante os céus intermédios — pode-se, de outro
modo, dizer que o céu empíreo tem luz não condensada, emitindo raios, como o corpo do sol, porém
mais sutil; ou tem a claridade da glória, diferente da claridade natural.

## Art. 4 — Se o tempo foi concriado com a matéria informe.
O quarto discute-se assim. — Parece que o tempo não foi concriado com a matéria informe.

1. — Pois, diz Agostinho, falando a Deus: Duas coisas encontro que fizeste não sujeitas ao tempo, a
saber, a matéria prima corpórea e a natureza angélica. Logo, o tempo não foi concriado com a matéria
informe.

2. Demais. — O tempo se divide em diurno e noturno. Ora, no princípio, não havia noite nem dia, mas
somente depois, quando Deus separou a luz das trevas. Logo, no princípio, não havia tempo.

3. Demais. — O tempo é o número do movimento do firmamento o qual, como se lê na Escritura, foi
feito no segundo dia. Logo, no princípio não havia tempo.

4. Demais. — O movimento, sendo anterior ao tempo, devia, mais que o tempo, ser das coisas criadas
em primeiro lugar.

5. Demais. — Como o tempo, assim também o lugar é uma medida extrínseca. Logo, não há porque se
conte, entre os primeiros seres criados, antes o tempo que o lugar.
Mas, em contrário, diz Agostinho que a criatura espiritual e corporal foi criada no princípio do tempo.

SOLUÇÃO. — Comumente se diz que os seres primeiramente criados foram quatro: a natureza angélica,
o céu empíreo, a matéria corpórea e o tempo. Mas deve-se atender a que tal doutrina não procede,
segundo a opinião de Agostinho. Pois, no lugar supracitado, admite dois seres como sendo os primeiros
criados, a saber, a natureza angélica e a matéria corpórea, sem mencionar o céu empíreo. Ora, estes
dois seres — a natureza angélica e a matéria informe, precedem à formação, não pela duração, mas pela
natureza; mas, como pela natureza precedem à formação, assim também do mesmo modo, precedem o
movimento e o tempo. Portanto, este não pode ser conumerado com elas. — A enumeração supra
procede, porém, segundo a opinião de outros Santos Padres, que ensinam ter a informidade da matéria
precedido, pela duração, à formação; e então é necessário supor, para essa duração, um tempo; de
outro modo, não se pode conceber medida para tal duração.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dito de Agostinho se funda em que a natureza
angélica e a matéria informe precedem o tempo, quanto à origem ou natureza.

RESPOSTA À SEGUNDA. — Assim como, segundo os outros Santos Padres, a matéria, de certo modo,
era informe e, só depois, foi formada, assim também o tempo foi, de certo modo informe e, depois, foi
formado e se dividiu em dia e noite.

RESPOSTA À TERCEIRA. — Se o movimento do firmamento não teve início imediatamente, desde o
princípio, então o tempo que o precedeu não foi o número desse movimento, mas de algum outro
movimento, que foi o primeiro. Pois, é acidental ao tempo ser o número do movimento do firmamento
enquanto esse movimento é o primeiro de todos. Se porém o movimento primeiro fosse outro, desse a
medida seria o tempo, porque todas as coisas se medem pela primeira do gênero. Logo, é necessário
concluir-se que, desde o princípio, imediatamente, houve algum movimento ao menos segundo a
sucessão dos conceitos e dos afetos, na mente angélica. Ora, não se pode compreender o movimento
sem o tempo, pois, este não é senão a enumeração da prioridade e da posterioridade no movimento.

RESPOSTA À QUARTA. — Entre os primeiro seres criados, contando-se os que têm uma relação geral
com as coisas, há-se de contar o tempo, que serve de medida comum; não, porém, o movimento que só
é relativo a um sujeito móvel.

RESPOSTA À QUINTA. — Compreende-se que haja lugar no céu empíreo, que contém todas as coisas. E
como o lugar se refere aos seres permanentes, foi concriado total e simultaneamente com eles. Porém o
tempo, que não é permanente, foi concriado com a matéria informe, no seu princípio; e, assim, ainda
agora, não há no tempo outra atualidade, salvo o momento presente.