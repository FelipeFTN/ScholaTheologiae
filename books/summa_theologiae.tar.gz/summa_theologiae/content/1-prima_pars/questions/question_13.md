# Questão 13: Dos nomes divinos.
Depois de considerado o que pertence ao conhecimento divino, devemos tratar dos nomes divinos, pois
nomeamos as coisas conforme as conhecemos.
E, nesta questão, discutem-se doze artigos:

## Art. 1 — Se algum nome convém a Deus.
(I Sent., dist. I, expos. Text., q. 6; dist. XXII, a. 1; De Div. Nom., cap. I, lect. I, III)
O primeiro discute-se assim. — Parece que nenhum nome convém a Deus.

1. — Pois, diz Dionísio: Que não se lhe pode dar nenhum nome, nem formar qualquer opinião a respeito
dele.E a Escritura (Pr 30, 4): Qual é o seu nome, e qual é o nome de seu filho, se é que o sabes?

2. Demais. — Todo nome ou é abstrato ou concreto. Os concretos não convém a Deus, que é simples. Os
abstratos, também não, porque não exprimem nada de perfeitamente existente. Logo, nenhum nome
pode ser atribuído a Deus.

3. Demais. — Os nomes exprimem a substância qualificada; os verbos e os particípios a exprimem no
tempo; e os pronomes, demonstrativa ou relativamente. Ora, nada disto convém a Deus que não tem
qualidade nem acidente, nem está no tempo, nem cai sob o alcance dos sentidos, de modo que possa
ser designado, nem pode ser expresso relativamente; pois, os relativos fazem lembrar o que já foi dito,
seja um nome, particípio ou pronome demonstrativo. Logo, Deus não pode, de nenhum modo, ser
nomeado por nós.
Mas, em contrário, a Escritura (Ex 15, 3): O Senhor é como um homem guerreiro, seu nome é
onipotente.

SOLUÇÃO. — Segundo o Filósofo, as palavras são sinais dos conceitos, que são semelhanças das coisas.
Por onde, é claro que as palavras se referem às coisas que devem significar, mediante a concepção do
intelecto. Logo, na medida em que uma coisa pode ser conhecida por nós, nessa mesma pode ser por
nós nomeada. Ora, como já demonstramos, nós não podemos ver a Deus em essência, nesta vida. Mas
somente o conhecemos por meio das criaturas, e por via da casualidade, da excelência e da remoção.
Portanto, nós podemos nomeá-lo por meio das criaturas. Não, porém, que o nome que designa exprima
a divina essência, como ela é, assim como a palavra homem significa a essência do homem tal como é,
exprimindo-lhe a definição, que lhe declara a essência, pois a noção significada pelo nome é a definição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dizemos que Deus não tem nome ou está acima de
qualquer denominação, porque a sua essência sobrepuja o que dele inteligimos e exprimimos pela
palavra.

RESPOSTA À SEGUNDA. — Como chegamos ao conhecimento e à denominação de Deus, por meio das
criaturas, os nomes que lhe atribuímos têm a significação que convém às criaturas materiais, cujo
conhecimento nos é conatural, como já dissemos. E como, dentre essas criaturas, as que são perfeitas e
subsistentes são compostas; e não sendo, por outro lado, a forma delas completa e subsistente, mas,
antes, o que faz com que alguma coisa exista, daí provém que todos os nomes que impomos para
significar o que é completo e subsistente têm significação concreta, como convém a compostos. Os
nomes, porém, impostos para significar formas simples, exprimem algo, não como subsistente, mas
como aquilo pelo que alguma coisa existe; assim a brancura significa aquilo que faz com que uma coisa
seja branca. Ora, sendo Deus simples e subsistente, atribuímos-lhe nomes abstratos, para lhe
exprimirem a simplicidade; os nomes concretos para lhe exprimirem a subsistência e a perfeição;
embora todos esses nomes sejam deficientes para lhe exprimirem o modo de ser, assim como o nosso
intelecto não o conhece, nesta vida, tal como é.

RESPOSTA À TERCEIRA. — Significar a substância qualificada é significar o suposto com a natureza ou a
forma determinada, na qual subsiste. Por onde, assim como certos nomes são atribuídos a Deus
concretamente para lhe significarem a subsistência e a perfeição, como já dissemos, assim também se
lhe atribuem nomes que significam a substância qualificada. Quanto aos verbos e aos particípios, que
exprimem o tempo, eles se atribuem a Deus, porque a eternidade inclui todos os tempos; pois, assim
como não podemos apreender e exprimir os seres simples subsistentes, senão ao modo que convém aos
compostos, assim, não podemos compreender ou exprimir pela palavra a eternidade simples senão ao
modo das coisas temporais; e isto por causa da conaturalidade do nosso intelecto com as coisas
compostas e temporais. Por fim, os pronomes demonstrativos se aplicam a Deus, enquanto designam o
que é compreendido, e, não, o que é sentido, pois na medida em que compreendemos, nessa mesma
designamos. E assim, do modo pelo qual os nomes, os particípios e os pronomes demonstrativos se
atribuem a Deus, desse mesmo podem ser significados pelos pronomes relativos.

## Art. 2 — Se algum nome se predica de Deus substancialmente.
(I Sent., dist. II, a. 2; I Cont. Gent., cap. XXXI; De Pot., q. 7, a. 5).
O segundo discute-se assim. — Parece que nenhum nome se predica de Deus substancialmente.

1. — Pois, diz Damasceno: Tudo o que dizemos de Deus não exprime o que ele é substancialmente, mas,
significa o que não é, ou alguma relação, ou alguma particularidade consecutiva à sua natureza ou ação.

2. Demais. — Dionísio diz: Em todos os santos teólogos acharás um hino às felizes participações da
tearquia, exprimindo manifestativa e laudativamente cada uma das denominações de Deus. O sentido
deste lugar é que os nomes que os Santos Doutores consagram ao divino louvor, se distinguem pelas
participações de Deus. Ora, o que exprime a participação de um ser não significa nada do que lhe
pertence à essência. Logo, os nomes predicados de Deus não se lhe atribuem substancialmente.

3. Demais. — Um ser é nomeado por nós conforme o modo pelo qual o compreendemos. Ora, nós não
inteligimos a Deus em substância, nesta vida. Logo, nenhum dos nomes que lhe aplicamos se lhe aplica
substancialmente.
Mas, em contrário, diz Agostinho: Em Deus se identificam o ser forte, sábio, ou o que quer que digamos
da sua simplicidade, para lhe significar a substância. Logo, todas essas denominações exprimem a divina
substância.

SOLUÇÃO. — Os nomes atribuídos a Deus negativamente ou os que exprimem alguma relação dele com
a criatura, é claro que de nenhum modo lhe significam a substância, mas, dele removem alguma coisa
ou exprimem alguma relação que têm com algum ser ou, antes, que algum ser tem com ele.
Mas, as opiniões variam quanto aos nomes que de Deus se predicam absoluta e afirmativamente, como
bom, sábio e outros. — Assim, uns disseram que, embora todos esses nomes se prediquem de Deus
afirmativamente, contudo, são destinados, antes, para dele remover, que para afirmar alguma coisa. Por
onde, dizem, quando afirmamos que Deus é vivo, queremos exprimir que não tem o mesmo modo de
ser das coisas inanimadas, e assim por diante. Esta é a opinião de Moisés Maimónides. — Outros,
porém, dizem que tais nomes são impostos para exprimir as relações de Deus com as criaturas; assim,
quando dizemos queDeus é bom, o sentido é, que Deus é a causa da bondade das coisas, e assim por
diante. Mas, estas duas opiniões são inconvenientes, por três razões.
Primeiro, porque nenhuma dessas duas opiniões pode explicar a razão por que certos nomes se
predicariam de Deus, de preferência a outros. Pois, ele é causa, tanto dos corpos, como dos bens;
portanto, se quando dizemos que Deus é bom queremos dizer que Deus é a causa dos
bens, semelhantemente, quando dizemos, que Deus é corpo, também significa isso que é a causa dos
corpos. E, do mesmo modo, dizendo que é corpo; dele removemos que seja um ente puramente
potencial, como a matéria prima.
Segundo, porque resultaria de tais opiniões, que todos os nomes aplicados a Deus não lhe convém
senão em sentido secundário, como quando dizemos que um remédio é são para, em sentido
secundário, significar somente que é causa da saúde no animal que, primariamente, se chama são.
Terceiro, porque tais opiniões vão contra a intenção dos que falamos de Deus, que, quando dizemos que
Deus é vivo, queremos dizer coisa diferente, que quando dizemos que é a causa da nossa vida, ou que
difere dos corpos inanimados.
E, portanto, devemos pensar, de outro modo, que tais nomes significam certamente a substância divina
e de Deus se predicam substancialmente, mas o representam de modo deficiente, o que assim se
demonstra. Os nomes exprimem a Deus do modo pelo qual o nosso intelecto o conhece. Ora, como o
nosso intelecto o conhece por meio das criaturas, há de conhecê-lo do modo pelo qual estas o
representam. Já demonstramos, porém, que Deus encerra em si, primariamente, quase absoluta e
universalmente simples, todas as perfeições das criaturas. Por onde, uma criatura qualquer o representa
e tem com ele semelhança, na medida em que tem alguma perfeição; não porém, que o represente
como sendo da mesma espécie ou do mesmo gênero, mas, como um principio excelente, em relação a
cuja: Porque ele é bom é que nós somos. forma os efeitos são deficientes, se deixarem, contudo, de
exprimir alguma semelhança dele; assim, a forma dos corpos inferiores representam a virtude solar. E
isso já o expusemos quando tratamos da perfeição divina. Por onde, os nomes em questão exprimem a
divina substância, embora imperfeitamente, assim como imperfeitamente as criaturas o representam.
Assim, pois, quando dizemos, que Deus é bom, o sentido não é, que Deus é a causa da bondade, ou
que Deus não é mau, mas que a bondade que atribuímos às criaturas, preexiste em Deus de modo mais
eminente. Donde, pois não se segue que a Deus convém o ser bom; porque causa a bondade, mas,
antes, pelo contrário, porque é bom difunde nas coisas a bondade, conforme aquilo de Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Damasceno diz que tais nomes não significam o que é
Deus, porque nenhum deles exprime o que Deus perfeitamente é, mas, cada um o significa
imperfeitamente, assim como imperfeitamente o representam as criaturas.

RESPOSTA À SEGUNDA. — Às vezes, uma coisa é a origem da qual um nome tira a sua significação, e
outra, o objeto que ele designa. Assim, o nome de lapide ou pedra se origina daquilo que lesa o pé; não
é, porém, usado para significar aquilo que lesa o pé, mas, uma espécie de corpo; do contrário, tudo o
que lesa o pé seria lápide ou pedra. Donde devemos concluir, que os nomes divinos em questão são,
certo, originados das participações da divindade. Assim, pois, como as criaturas representam a Deus,
embora imperfeitamente, segundo as diversas participações das divinas perfeições, assim o nosso
intelecto conhece e nomeia a Deus conforme cada uma dessas participações. Esses nomes, porém, não
são impostos para significar as participações mesmas; e quando dizemos que Deus é vivo, queremos
dizer que de Deus procede a vida,querendo assim significar o princípio mesmo das coisas, no qual
preexiste a vida, embora de modo mais eminente do que o que nós podemos compreender ou exprimir.

RESPOSTA À TERCEIRA. — Não podemos, nesta vida, conhecer a essência de Deus, tal como ela é em si
mesma; mas, a conhecemos enquanto representada nas perfeições das criaturas e, assim é que os
nomes que impomos a significam.

## Art. 3 — Se algum nome se predica de Deus propriamente.
(I Sent., dist. IV, q. 1, a. 1; dis. XXII, a. 2; dist. XXXIII, a. 2; dist. XXXV, a. 1, ad 2; I Cont., cap. XXX; De Pot.,
q. 7, a. 5).
O terceiro discute-se assim. — Parece que nenhum nome se predica de Deus propriamente.

1. — Pois, todos os nomes que aplicamos a Deus são tirados das criaturas, como já se disse. Ora, tais
nomes se aplicam a Deus metaforicamente; assim, quando dizemos que Deus é pedra ou leão ou algo de
semelhante. Logo, os nomes que atribuímos a Deus se aplicam metaforicamente.

2. Demais. — Um nome que é removido de um ser, mais verdadeiramente do que é dele predicado, não
se lhe aplica propriamente. Ora, todos os nomes como — bom, sábio, e semelhantes — removem-se de
Deus mais verdadeiramente do que dele se predicam, como se lê claramente em Dionísio. Logo,
nenhum desses nomes se predica propriamente de Deus.

3. Demais. — Sendo Deus incorpóreo, os nomes de corpos não se lhe atribuem senão metaforicamente.
Ora, todos os nomes em questão implicam certas condições corpóreas, como o tempo, a composição e
outras semelhantes. Logo, todos esses nomes se atribuem a Deus metaforicamente.
Mas, em contrário, diz Ambrósio: Há certos nomes que indicam evidentemente uma propriedade divina.
Outros que exprimem, com clara verdade, a majestade divina; Outros por fim que se aplicam a Deus por
metáfora e semelhança. Logo, todos esses nomes se predicam de Deus metaforicamente.

SOLUÇÃO. — Como já dissemos, conhecemos a Deus pelas perfeições que dele procedem para as
criaturas, perfeições que nele existem de modo mais eminente que nestas. Ora, o nosso intelecto as
apreende conforme o modo pelo qual elas existem nas criaturas e, como as apreende, assim as exprime
por nomes. Ora, nos nomes que atribuímos a Deus há dois elementos a se considerarem, a saber: as
perfeições mesmas que eles significam, como bondade, vida e outras; e o modo de significar. Quanto ao
que significam tais nomes, convém a Deus propriamente e mais que às criaturas, dele se predicam
primariamente. Quanto ao modo de significar, não se lhe atribuem propriamente, pois, esse modo é
próprio das criaturas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Alguns nomes significam as perfeições procedentes de
Deus para as coisas criadas, de maneira que o modo imperfeito mesmo, pelo qual a perfeição divina é
participada pela criatura, está incluída na significação deles; assim, pedra significa um ser material. E tais
nomes não se podem atribuir a Deus senão metaforicamente. Os nomes, porém, que significam as
perfeições mesmas, absolutamente, sem que nenhum modo de participação se inclua na significação
deles — como ente, bom, vivente e semelhantes — esses atribuem-se a Deus propriamente.

RESPOSTA À SEGUNDA. — Dionísio diz que os nomes em questão podem ser negados de Deus, porque
a significação deles não lhe convém, do mesmo modo pelo qual a exprimem, mas, de modo mais
excelente. E, por isso, Dionísio diz, no mesmo lugar, que Deus está acima de toda substância e de toda
vida.

RESPOSTA À TERCEIRA. — Os nomes que se predicam propriamente de Deus implicam condições
corpóreas, não pela significação mesma deles, mas, pelo modo de significar. Os que, porém, se atribuem
a Deus, metaforicamente implicam condição corporal, pela sua significação mesma.

## Art. 4 — Se os nomes predicados de Deus são sinônimos.
(I Sent., dist. II, a. 3; dist. XXII a. 3; I Cont. Gent., cap. XXXV; De Pot., q. 7, a. 6; Compend. Theol.,
cap. XXV).
O quarto discute-se assim. — Parece que os nomes predicados de Deus são sinônimos.

1. — Pois, chamam-se sinônimos os nomes que significam absolutamente o mesmo. Ora, os que de
Deus se predicam significam absolutamente o mesmo. Assim, a bondade de Deus é a sua essência e
também a sua sabedoria. Logo, tais nomes são absolutamente sinônimos.

2. Demais. — Nem vale dizer, que esses nomes significam a mesma realidade, mas, exprimem noções
diversas. — Pois, a noção a que não corresponde nenhuma realidade, é vazia de sentido. Se, portanto,
as noções em questão forem muitas e a realidade uma só, tais noções são vazias de sentido.

3. Demais. — O que tem unidade real e racional tem mais unidade que o que tem unidade real e
multiplicidade racional. Ora, Deus é uno por excelência. Logo, não pode ter unidade real e
multiplicidade racional e, portanto, os nomes que dele se predicam, não significando noções diversas,
são necessariamente sinônimos.
Mas, em contrário. — Todos os sinônimos unidos uns aos outros não passam de tautologia, como
quando se diz, roupa vestimentas. Se, portanto, todos os nomes de predicados de Deus são sinônimos,
não se pode, com conveniência, dizer, que Deus é bom, ou coisa semelhante; e, contudo, diz a Escritura
(Jr 32, 18): ó fortíssimo, grande e poderoso, o Senhor dos exércitos é o teu nome.

SOLUÇÃO. — Os nomes de que tratamos não são sinônimos predicados de Deus. E isto já o veríamos
facilmente, se disséssemos que tais nomes são usados para negar ou para exprimir a relação de causa
que há entre Deus e as criaturas; então, já seriam diversas as noções desses nomes, conforme as coisas
diversas que negam ou os efeitos diversos que conotam. — Mesmo, porém, admitindo que, como já
dissemos, tais nomes exprimam a substância divina, embora imperfeitamente, ainda resulta claro,
segundo o que já estabelecemos, que eles têm noções diversas. Pois, a noção significada pelo nome é
uma concepção do intelecto relativa ao que essa noção exprime. Ora, como o nosso intelecto conhece a
Deus por meio das criaturas, forma, para o inteligir, conceitos proporcionados às perfeições que, de
Deus procedem para as criaturas; perfeições essas que, nele, preexistem com unidade e simplicidade e,
nestas, divididas e múltiplas. Assim, pois, como às diversas perfeições das criaturas corresponde um
princípio simples, representado, vária e multiplamente, pelas diversas perfeições delas, — assim às
várias e múltiplas concepções do nosso intelecto corresponde algo de absolutamente uno e simples,
apreendido imperfeitamente por tais concepções. E, portanto, os nomes atribuídos a Deus, embora
signifiquem uma mesma realidade, contudo, não são sinônimos, porque a designam sob noções
múltiplas e diversas.
Por onde, é clara a RESPOSTA À PRIMEIRA OBJEÇÃO. — Pois, chamam-se sinônimos os nomes que,
tendo uma determinada noção, significam uma mesma realidade. Os nomes que exprimem noções
diversas de uma mesma realidade, não significam uma mesma coisa, primariamente e em si mesma,
porque o nome não exprime uma realidade senão mediante um conceito do intelecto, como já
dissemos.

RESPOSTA À SEGUNDA. — As noções várias de tais nomes não são inúteis e vãs, porque a todos eles
corresponde algo de simples, que eles representam múltipla e imperfeitamente.

RESPOSTA À TERCEIRA. — É pela sua perfeita unidade mesma que o que existe múltipla e divididamente
nas criaturas, Deus o encerra em si simples e multiplamente. E porque o nosso intelecto o apreende
multiplamente, tal como as coisas o representam, é que Deus, uno na realidade, é múltiplo
racionalmente.

## Art. 5 — Se é univocamente que os mesmos nomes se atribuem a Deus e às criaturas.
(I Sent., Prol., a. 2, ad 2; dist. XIX, q. 5, a. 2, ad 1; dist. XXXV, a. 4; I Cont. Gent., cap. XXXII, XXXIII, XXXIV;
De Verit., q. 2, a. 2; De Pot., q. 7, a. 7; Compend. Theol., cap. XXVII).
O quinto discute-se assim. — Parece que é univocamente que os mesmos nomes se atribuem a Deus e
às criaturas.

1. — Pois, todo equívoco se reduz ao unívoco, como o múltiplo à unidade. Assim, se o nome de cão se
predica equivocamente do que ladra e do cão marinho, é necessário que seja predicado de certos
animais univocamente, a saber, de todos os que ladram; pois, do contrário, teríamos que proceder ao
infinito. Ora, há certos agentes unívocos que convêm com os seus efeitos pelo nome e pela definição, p.
ex., um homem gera outro; outros agentes, porém, são equívocos, assim o sol causa o calor; embora
não seja cálido senão equivocamente. Parece, pois, que o primeiro agente, ao qual todos os outros se
reduzem, é um agente unívoco, e, portanto, os nomes atribuídos a Deus e às criaturas são predicados
univocamente.

2. Demais. — Onde há equívoco não há semelhança. Ora, como há semelhança da criatura com Deus,
conforme aquilo da Escritura (Gn 1, 26) — Façamos o homem à nossa imagem e semelhança — conclui-
se que alguma realidade, pelo menos, podemos atribuir univocamente a Deus e às criaturas.

3. Demais. — A medida é homogênea com o medido, como diz Aristóteles. Ora, Deus é a medida
primeira de todos os seres, como no mesmo lugar o diz. Logo, Deus é homogêneo com as criaturas, e
portanto podemos predicar dele e delas algo de unívoco.
Mas, em contrário. — O que se predica de vários sujeitos, por um mesmo nome, mas não no mesmo
sentido, é deles predicado equivocamente. Ora, nenhum nome convém a Deus no mesmo sentido por
que convém à criatura; assim, a sabedoria, nas criaturas é qualidade, não porém em Deus; pois, como o
gênero faz parte da definição, se ele varia, varia também o sentido. E o mesmo se dá com tudo o mais.
Logo, tudo o que se diz de Deus e das criaturas, diz-se equivocamente.
Demais. — Deus dista mais das criaturas que estas, umas das outras. Ora, dá-se que, por causa da
distância entre certas criaturas, nada pode predicar-se delas univocamente. Assim acontece com as que
não convêm num mesmo gênero. Logo, com maior razão, não se pode predicar nada univocamente,
senão só equivocamente, de Deus e das criaturas.

SOLUÇÃO. — É impossível predicar-se qualquer coisa, univocamente, de Deus e das criaturas. Pois, todo
efeito que não iguala a virtude da causa agente, recebe a semelhança do agente, não segundo o mesmo
sentido mas, deficientemente; de modo que, o que nos efeitos existe dividida e multiplamente, existe
na causa simples e uniformemente; assim, o sol, pela sua virtude una, produz nos seres da terra formas
várias e múltiplas. Do mesmo modo, como já dissemos, todas as perfeições que existem nas coisas
criadas, dividida e multiplamente, preexistem em Deus, una e simplesmente. Por onde, quando um
nome, designando uma perfeição, é atribuído a uma criatura, esse nome exprime essa perfeição
distintamente e enquanto que, pela sua definição, se separa do mais. Assim, pelo nome
de sábio, aplicado ao homem, exprimimos uma perfeição distinta da essência, da potência, do ser e do
mais que lhe convém. Quando, porém, atribuímos esse nome a Deus, não pretendemos exprimir nada
distinto da sua essência, do seu poder ou do seu ser. De maneira que o nome de sábio, atribuído ao
homem, circunscreve, de certo modo, e abrange o seu significado; não, porém, quando atribuído a Deus
porque, então, deixa a qualidade significada como incompreendida e excedente à significação do nome.
Por onde, é claro que o nome de sábio não tem o mesmo sentido, atribuído a Deus e ao homem. E o
mesmo se dá com todos os outros. Logo, nenhum nome é predicado univocamente, de Deus e das
criaturas.
Nem em sentido puramente equivoco como alguns disseram. Porque, então, por meio das criaturas, não
poderíamos conhecer nem demonstrar nada de Deus, sem cairmos no sofisma de equivocação. Demais,
esta opinião vai contra o Filósofo, que demonstra muitas verdades a respeito de Deus, como contra o
Apóstolo, que diz (Rm 1, 20): As coisas invisíveis dele, depois da criação do mundo, compreendendo-se
pelas coisas feitas, tornaram-se visíveis.
Devemos portanto dizer que os nomes em questão predicam-se de Deus e das criaturas,
analogicamente, i. é, em virtude de uma proporção. E isto pode se dar com os nomes, de dois modos.
Ou porque muitos termos são proporcionais a uma mesma realidade. E assim, são se diz tanto de um
remédio como da urina; enquanto que esta e aquele se ordenam e proporcionam à saúde do animal, da
qual a urina é o sinal, e o remédio, a causa da saúde do animal ou porque um termo é proporcional a
outro, assim, são se diz do remédio e do animal, por ser aquele a causa da saúde deste. E, deste modo,
certos nomes predicam-se de Deus e das criaturas analogicamente e não em sentido puramente
equivoco, nem puramente unívoco pois, não podemos designar a Deus senão pelas criaturas, como já
dissemos.
E assim, o que dizemos de Deus e das criaturas dizemo-lo por haver uma certa ordem da criatura para
Deus, como o principio e a causa em que preexistem excelentemente todas as perfeições dos seres. De
modo que esta como que comunidade de denominações é um meio termo entre a pura equivocação e a
simples univocação. Pois, as predicações análogas não têm o mesmo sentido, como o têm as unívocas,
nem sentidos totalmente diversos, como as equivocas; mas, o nome assim empregado em sentido
múltiplo significa proporções diversas relativas a um termo uno. Assim, o nome de são aplicado à urina é
tomado como sinal da saúde do animal; aplicado a um remédio, porém, significa que este é a causa da
saúde.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora as predicações equívocas se reduzam às
unívocas, contudo, nas ações, o agente não unívoco precede, necessariamente, ao unívoco. Pois aquele
é causa universal de toda a espécie; p. ex., o sol é a causa da geração de todos os homens. O agente
unívoco, porém, não é causa agente universal de toda a espécie; do contrário, seria a causa de si
mesmo, pois está contido na espécie; mas, é causa particular de um determinado indivíduo, que leva a
participar da espécie. Por onde, a causa universal de toda a espécie não é o agente unívoco. Ora, a causa
universal tem prioridade sobre a particular. Por outro lado, o agente universal, embora não seja
unívoco, também não é absolutamente equívoco, porque então não poderia produzir um ser
semelhante a si; mas, pode ser chamado agente análogo. É assim que todas as predicações unívocas se
reduzem a um termo primeiro não unívoco, mas, análogo, que é o ser.

RESPOSTA À SEGUNDA. — A semelhança da criatura com Deus é imperfeita a tal ponto que não
comporta gênero comum, como já dissemos.

RESPOSTA À TERCEIRA. — Deus não é uma medida proporcionada ao medido. Por onde, não é
necessário que esteja contido no mesmo gênero da criatura.
E quanto às objeções em contrário, elas concluem que os nomes em questão não se predicam
univocamente de Deus e das criaturas; mas isto não prova que se prediquem equivocamente.

## Art. 6 — Se os mesmos nomes se predicam primeiro das criaturas que de Deus.
(Supra, a. 3; I Sent., dist. XXII, a. 2; I Cont. cap. XXXIV; Comp. Thel. Cap. XXVII; Ephes., cap. III, lect. IV).
O sexto discute-se assim. — Parece que os mesmos nomes se predicam primeiro das criaturas que de
Deus.

1. — Pois, como conhecemos um ser, assim o denominamos; porque, segundo o Filósofo, os nomes são
os sinais das coisas inteligidas. Ora, nós conhecemos a criatura antes de conhecermos a Deus. Logo,
todos os nomes que impomos convêm primeiro às criaturas, que a Deus.

2. Demais. — Segundo Dionísio, nomeamos a Deus por meio das criaturas. Ora, os nomes transferidos
destas para Deus, como leão, pedra e outros, predicam-se primeiro delas que dele. Logo, todos os
nomes se predicam primeiro das criaturas que de Deus.

3. Demais. — Todos os nomes predicados, em comum, de Deus e das criaturas, atribuem-se a Deus
como causa de todos os seres, conforme diz Dionísio. Ora: o que se predica de um ser como causa é
predicado em segundo lugar; assim, diz-se primeiro, do animal, que é são, do que do remédio, causa da
saúde. Logo, tais nomes predicam-se das criaturas, antes de se predicarem de Deus.
Mas, em contrário, diz a Escritura (Ef 3, 14): Dobro os meus joelhos diante do Pai de Nosso Senhor Jesus
Cristo, do qual toda a paternidade toma o nome nos céus e na terra. E o mesmo se deve dizer dos
outros nomes que se predicam de Deus e das criaturas. Logo, tais nomes se predicam primeiro de Deus
que das criaturas.

SOLUÇÃO. — Todos os nomes atribuídos analogicamente a vários seres hão necessariamente de ser
dependentes de um primeiro termo, a que são relativos; e, portanto, este termo há de entrar na
definição de todos esses nomes. E como a noção expressa pelo nome é a definição, conforme
Aristóteles, é necessário que este nome seja atribuído, primeiramente, ao termo da analogia, que entra
na definição dos outros e, em segundo lugar, à destes, conforme se aproximam mais ou menos do
primeiro termo. Por exemplo, são, atribuído ao animal, entra na definição dessa mesma
palavra são atribuída ao remédio, assim chamado por causar a saúde do animal; e também entra na
definição de são, atribuído à urina, assim chamada por ser o sinal da saúde do animal. Por onde, todos
os nomes predicados metaforicamente de Deus, atribuem-se primeiro às criaturas que a Deus, porque,
referidos a ele, não significam senão uma semelhança com tais criaturas ou tais outras. Assim, rir,
atribuído a um prado, não significa senão que o prado, quando floresce, é agradável, como o homem,
quando ri, por semelhança de proporção; e, do mesmo modo, o nome leão, aplicado a Deus, não
significa senão que Deus age fortemente, nas suas obras, como o leão, nas suas. Por onde, é claro que
tais nomes, aplicados a Deus, não podem ser definidos senão por comparação com o sentido que têm
quando atribuídos às criaturas.
Quanto aos nomes que não são atribuídos a Deus metaforicamente, o mesmo diríamos, se eles fossem
predicados de Deus só causalmente, como certos disseram. Assim, quando dizemos — Deus é bom —
não quereríamos dizer senão que Deus é a causa da bondade da criatura; e então o nome bom,
atribuído a Deus, abrangeria na sua significação, a bondade da criatura e, por conseqüência, dir-se-ia da
criatura, antes de ser predicado de Deus. Mas, como já demonstramos, tais nomes atribuem-se a Deus
não só causal, mas também, essencialmente. Assim, quando dizemos — Deus é bom — ou —
sábio queremos dizer, não somente, que é causa da sabedoria ou da bondade, mas, que estas
qualidades nele preexistem de modo mais eminente. Por onde, neste sentido, deve-se dizer que,
levando em consideração a coisa significada pelo nome, cada um deles é predicado de Deus, antes de
ser das criaturas, porque dele é que lhe derivam as perfeições denominadas. Mas, quanto à imposição
dos nomes nós os damos, primeiro, às criaturas, que é o que primeiro conhecemos, e, por isso, eles têm
um modo de significar, que convém às criaturas, como já dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procede quanto à imposição do nome.

RESPOSTA À SEGUNDA. — O caso dos nomes atribuídos a Deus metaforicamente não é o mesmo que o
dos demais nomes, como dissemos.

RESPOSTA À TERCEIRA. — A objeção procederia se tais nomes fossem predicados de Deus só causal e
não, essencialmente, como quando se diz — o remédio é são.

## Art. 7 — Se os nomes que implicam relação com as criaturas são atribuídos a Deus temporalmente.
(Infra, q. 34, a. 3 ad 2; I Sent., dist. XXX, a. 1; dist. XXXVII, q. 2 a. 3).
O sétimo discute-se assim. — Parece que os nomes que implicam relação com as criaturas não são
atribuídos a Deus temporalmente.

1. — Pois, todos esses nomes exprimem a divina substância, como em geral se diz. Por onde, conforme
Ambrósio, o nome de Senhor é nome de poder, que é a divina substância; e Criador significa a ação de
Deus, que é a sua essência. Ora, a substância divina não é temporal, mas eterna. Logo, tais nomes não
são atribuídos a Deus temporal, mas, eternamente.

2. Demais. — Um ser a que convém um nome, a partir de um certo tempo, pode ser considerado como
feito. Ora, a Deus não convém o ser feito. Logo, de Deus nada é predicado no tempo.

3. Demais. — Se certos nomes são predicados de Deus temporalmente, por importarem relação com as
criaturas, o mesmo se pode dizer de todos os nomes que implicam tais relações. Ora, alguns desses
nomes predicam-se de Deus ab aeterno. Assim, ab aeterno Deus conhece e ama a criatura, conforme
aquilo da Escritura (Jr 31, 3):Com amor eterno te amei. Logo, todos os demais nomes, que importam
relação com as criaturas, como Senhor e Criador, predicam-se de Deus ab aeterno.

4. Demais. — Os nomes de que tratamos exprimem uma relação. Mas, necessariamente, essa relação é
alguma coisa em Deus ou somente na criatura. Ora, este último caso não pode ser, porque então Deus
seria denominado Senhor segundo a relação contrária que existe nas criaturas; mas, nada é denominado
pelo que é contrário. Logo, a relação é alguma coisa em Deus. Ora, em Deus não pode haver nada de
temporal, porque ele está fora de qualquer tempo. Logo, tais nomes não se atribuem a Deus
temporalmente.

5. Demais. — A relação faz com que uma atribuição seja relativa; p. ex., dominador vem de domínio,
como branco, de brancura. Se, pois, a relação de domínio não existe realmente em Deus, mas, só
racionalmente, conclui-se que Deus não é realmente Senhor, o que é falso, de maneira evidente.

6. Demais. — Quando dois termos relativos não são simultâneos por natureza, um pode existir sem que
exista o outro; assim, o cognoscível existe, embora não exista conhecimento, como diz Aristóteles. Ora,
os termos relativos predicados de Deus e das criaturas não são simultâneos por natureza. Logo,
podemos atribuir alguma coisa a Deus em relação com a criatura, mesmo que esta não exista. E assim,
os nomes Senhor e Criadorpredicam-se de Deus ab aeterno e não no tempo.
Mas, em contrário, diz Agostinho, que a denominação relativa de Senhor convém a Deus
temporalmente.

SOLUÇÃO. — Certos nomes, que implicam relação de Deus com a criatura, dele se predicam
temporalmente e não, ab aeterno.
Para o demonstrar, deve saber-se que alguns ensinaram que a relação não é uma realidade da natureza,
mas só da razão. Ora, esta opinião é evidentemente falsa, porquanto os seres da natureza têm, uma
ordem natural e relação mútua entre si. Contudo, deve saber-se que, exigindo a relação dois extremos,
três condições podem torná-la um objeto da natureza ou um simples ser de razão.
Assim, às vezes, esses dois extremos são seres somente de razão, e isso quando a ordem ou relação
entre eles depende só da apreensão racional; p. ex., se dissermos que um mesmo ser é, para si, isso
mesmo que é. Pois, quando a razão apreende uma mesma realidade sob dupla concepção, afirma-a
como duas, e assim apreende uma certa relação dessa coisa consigo mesma. E o mesmo se dá com
todas as relações entre o ser e o não-ser, relações que a razão forma, apreendendo o não-ser como um
extremo. E ainda, o mesmo é o caso de todas as relações conseqüentes a um ato da razão, como o
gênero, a espécie e outros.
Outras relações há, além dessas, nas quais os dois extremos são realidades da natureza; e isso se dá
quando há uma relação entre dois termos fundada em algo que lhes convém realmente aos dois. É o
que aparece manifestamente em todas as relações conseqüentes à quantidade, como grande e
pequeno, duplo e meio, e semelhantes, pois a quantidade está realmente em cada um dos extremos. E
o mesmo sucede com as relações resultantes da ação e da paixão, como, motivo e móvel, pai e filho e
outras.
Outras vezes, por fim, um dos termos da relação é uma realidade da natureza e, o outro, somente de
razão; e isto se dá sempre que os dois extremos não são da mesma ordem. Assim, o sentido e a ciência
referem-se ao sensível e ao inteligível, que, como coisas, e quanto ao ser natural que têm, são estranhos
à ordem do ser sensível e a do inteligível. Por onde, no caso da ciência e da sensação, há uma relação
real, por se ordenarem essas atividades a conhecer e a sentir as coisas; mas, estas, em si mesmas
consideradas, são estranhas a tal ordem e por isso, não têm relação real com a ciência e com a
sensação, mas, relação somente de razão, enquanto o nosso intelecto as apreende como termos das
relações da ciência e do sentido. Por onde, diz o Filósofo, que essas coisas são tomadas relativamente,
não porque se refiram a outras, mas, porque as outras se lhes referem a elas. Assim também, não
dizemos que uma coluna está à direita senão porque está colocada p. ex., à direita de um animal, e, por
isso, tal relação não está realmente na coluna, mas, no animal.
Ora, Deus, estando fora de toda a ordem das criaturas, ordenando-se-lhes todas elas, e não
inversamente, é manifesto que elas se referem realmente a Deus, que, porém, não tem nenhuma
relação real com a criatura, mas, só racional, enquanto elas se lhe referem. Assim, pois, nada impede
que os nomes em questão, que implicam relação com a criatura, sejam predicados de Deus
temporalmente; não que haja nele qualquer mutação, que só existe na criatura, assim como uma coluna
está à direita de um animal, sem que haja nela nenhuma mudança, a qual existe só no animal, que
mudou de lugar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Certos nomes relativos são impostos para exprimirem as
relações em si mesmas, e como Senhor e servo, pai e filho, e outros; e estes se chamam relativos quanto
ao ser.Outros, porém, são impostos para exprimirem coisas a que certas relações são consecutivas,
como motor emóvel, chefe e chefiado e semelhantes, que se chamam relativos quanto à
apelação. Assim, também em relação aos nomes divinos, devemos considerar as diferenças seguintes.
Certos exprimem a relação mesma que Deus mantém com a criatura, como, Senhor. E estes significam a
substância divina, não direta mas, indiretamente por que a pressupõem, assim como o domínio
pressupõe o poder que é, no caso, a substância divina. Outros nomes, porém, exprimem diretamente a
essência divina e, por via de conseqüência, implicam uma relação, como,Salvador, Criador e
semelhantes, que exprimem a ação de Deus, que é a sua essência. Ora, estas duas categorias de nomes
predicam-se de Deus temporalmente, se considerarmos a relação que implicam, principal ou
conseqüentemente; não, porém, se considerarmos como significando a essência, direta ou
indiretamente.

RESPOSTA À SEGUNDA. — Assim como as relações predicadas de Deus temporalmente nele não
existem senão como distinções da nossa razão; do mesmo modo, não podemos aplicar a Deus as
expressões — ser feito, ter sido feito — senão como um modo nosso de falar, sem que haja nenhuma
mudança em Deus mesmo; tal é o caso do passo da Escritura (Sl 89, 1): Senhor, tu tens sido feito o nosso
refúgio.

RESPOSTA À TERCEIRA. — A operação do intelecto e da vontade existem no agente; e, por isso, os
nomes que exprimem relações conseqüentes à atividade dessas duas faculdades predicam-se de
Deus ab aeterno. As relações, porém, resultantes de atos exteriores, i. é, de atos que, segundo o nosso
modo de entender, se exteriorizam, quanto aos seus efeitos, essas incluem o tempo, na sua significação,
assim, quando dizemos que Deus é Salvador, Criador, etc.

RESPOSTA À QUARTA. — As relações expressas pelos nomes em questão, predicados de Deus
temporalmente, em Deus existem só como distinção da nossa razão; as relações, porém, opostas a estas
estão realmente nas criaturas. Nem há inconveniente em Deus ser denominado pelas relações
realmente existentes na criatura, contanto que a nossa inteligência subentenda que nele existem as
relações opostas a essas; de modo tal que digamos que Deus é relativo à criatura, porque a criatura se
lhe refere a ele, assim como o Filósofo diz que o cognoscível é considerado relativamente à inteligência,
porque a ele é relativa a ciência.

RESPOSTA À QUINTA. — Estando a relação de sujeição realmente na criatura, esta é que, propriamente,
se refere a Deus e não, Deus a ela. Donde se segue, que Deus é Senhor, não só conforme o nosso modo
de falar, mas, realmente, pois é chamado Senhor, do mesmo modo porque dizemos que a criatura lhe
está sujeita.

RESPOSTA À SEXTA. — Para conhecermos se os termos relativos são simultâneos por natureza ou não,
devemos considerar, não a ordem das coisas a que eles se referem, mas, as significações mesmas deles.
Se, pois, um dos termos relativos inclui outro, na sua significação e não inversamente, não são
simultâneos por natureza como, duplo, meio, pai e filho, e semelhantes. Mas se um inclui o outro, na
sua significação, e não inversamente, não são simultâneos por natureza: E tal é a relação entre a ciência
e o cognoscível. Pois, a palavra cognoscível exprime uma potência, ao passo que, ciência exprime um
hábito ou um ato. Por onde, o cognoscível, pela sua significação mesma, preexiste à ciência. Se, porém,
considerarmos o cognoscível como atual, então, é simultâneo com a ciência, também atual, pois o
conhecido não é nada se dele não há nenhuma ciência. Por onde, embora Deus tenha prioridade sobre
as criaturas, como porém, a significação da palavra — Senhor — implica a existência do servo, e vice-
versa esses dois termos relativos, Senhor e servo, são simultâneos por natureza. Por onde, Deus não era
Senhor, antes de existir a criatura que lhe estivesse sujeita.

## Art. 8 — Se o nome de Deus é um nome de natureza.
(I Sent., dist. 2, expos. Lit.)
O oitavo discute-se assim. — Parece que o nome de Deus não é um nome de natureza.

1. — Pois, diz Damasceno, que Deus vem de theein que significa prover todas as coisas e delas cuidar;
ou também pode vir de aithein porque o nosso Deus é o fogo que consome toda malícia; ou ainda
de theasthai, i.é, ver todas as coisas. Ora, todos estes nomes designam operações. Logo, o nome de
Deus significa operação e não, natureza.

2. Demais. — Nós nomeamos um ser na medida em que o conhecemos. Ora, a natureza divina é-nos
desconhecida. Logo, o nome de Deus não significa a natureza divina.
Mas, em contrário, diz Ambrósio que Deus é nome de natureza.

SOLUÇÃO. — A origem da significação de um nome nem sempre se identifica com a coisa mesma que o
nome significa. Assim, como conhecemos a substância de um ser pelas suas propriedades ou operações,
denominamos também, às vezes, essa substância por alguma de suas operações ou propriedades. P. ex.,
denominamos a substância da pedra por uma das suas ações — a de ferir o pé; contudo, este nome é
usado, não para significar tal ação, mas, a substância mesma da pedra. Os seres, porém, que são em si
mesmos conhecidos de nós, como o calor, o frio, a brancura e semelhantes, não são denominados por
meio de outros. E, por isso, o que o nome de tais seres significa é idêntico à causa que deu origem à
significação.
Ora, como a natureza de Deus não nos é conhecida senão pelas suas operações e pelos seus efeitos,
podemos denominá-lo mediante estes e aqueles, como já dissemos. Por onde, o nome de Deus é um
nome que designa operação, considerando-lhe a origem, que é a providência universal das coisas. Pois,
todos os que falam de Deus entendem designar, com esse nome, o ser cuja providência universal cuida
de todos os seres. Por isso, diz Dionísio, que a divindade é a que vê tudo com providência e bondade
perfeita. E assim, o nome de Deus, originado dessa operação, foi imposto para significar a natureza
divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tudo isso, a que se refere Damasceno, diz respeito à
providência, origem da significação do nome de Deus.

RESPOSTA À SEGUNDA. — Na medida em que podemos conhecer a natureza de um ser pelas suas
propriedades e efeitos, podemos também impor-lhe um nome. Ora, como sabemos o que é a pedra por
lhe conhecermos a substância, mediante uma de suas propriedades, esse nome — pedra — significa a
natureza da pedra em si mesma, pois, significa-lhe a definição pela qual sabemos o que ela é; porque a
definição é a noção expressa pelo nome, como diz Aristóteles. Ora, pelos efeitos divinos não podemos
conhecer a natureza divina tal qual é, de modo que lhe conheçamos a essência, que só podemos
conhecer pelo método de eminência, de causalidade e de negação, como já dissemos. Por onde, o nome
de Deus significa a natureza divina; pois, é imposto para significar um ser superior a tudo o que existe,
princípio de tudo e de tudo separado. E é isso o que querem exprimir os que usam de tal nome.

## Art. 9 — Se o nome de Deus é comunicável.
O nono discute-se assim. — Parece que o nome de Deus é comunicável.

1. — Pois, a qualquer ser a que se comunica o que é significado pelo nome, comunica-se também o
próprio nome. Ora, o nome de Deus, como já se disse, significa a natureza divina, comunicável aos
demais seres, conforme aquilo da Escritura (2 Pd 1, 4): Comunicou-nos as mui grandes e preciosas
graças que tinha prometido, para que, por elas, sejais feitos participantes da natureza divina. Logo, o
nome de Deus é comunicável.

2. Demais. — Só os nomes próprios não são comunicáveis. Ora, o nome de Deus não é próprio, mas,
apelativo, pois, como é claro, tem plural, conforme a Escritura (Sl 81, 6): Eu disse: Sois deuses. Logo, o
nome de Deus é comunicável.

3. Demais. — O nome de Deus tem a sua origem na operação, como já se disse. Ora, outros nomes que
impomos a Deus, originados das suas operações ou dos seus feitos, como bom, sábio, e outros, são
comunicáveis. Logo, o nome de Deus é comunicável.
Mas, em contrário, diz a Escritura (Sb 14, 21): Deram às pedras e ao pau um nome
incomunicável; referindo-se ao nome de deidade. Logo, o nome de Deus é incomunicável.

SOLUÇÃO. — Um nome pode ser comunicável de dois modos: propriamente e por semelhança. É
propriamente comunicável o nome que se aplica a muitos seres na sua significação total; e, por
semelhança, quando é imposto só em relação a uma parte da sua significação. Assim, o nome de leão é,
propriamente, comunicado a todos os seres que têm a natureza que tal nome exprime; é, porém,
comunicável, por semelhança, aos seres que participam algo de leonino, como, a audácia ou a fortaleza,
e são por isso, metaforicamente, chamadosleões.
Ora, para sabermos que nomes são propriamente comunicáveis, devemos considerar que toda forma
existente num sujeito singular, que a individúa, é comum a muitos seres, realmente ou, pelo menos,
racionalmente. Assim, a natureza humana é comum a muitos seres, real e racionalmente; ao passo que
a natureza do sol não o é real, mas só racionalmente, pois pode ser entendida como existente em
muitos sujeitos; e isto porque o intelecto intelige a natureza de uma espécie por abstração do singular.
Por onde, existir num sujeito singular ou em vários é um fato estranho ao conceito que fazemos da
natureza da espécie, e, por isso, o conceito da natureza específica ficando salvo, pode ser inteligido
como existente em vários seres. O singular pelo contrário, por isso mesmo que o é, é separado de tudo
o mais, e, por isso, todo nome imposto para significar o singular é incomunicável, real e racionalmente.
Pois, a pluralidade de um de-terminado indivíduo não pode cair sob a nossa apreensão. Por onde,
nenhum nome que signifique um determinado indivíduo é comunicável propriamente, a muitos outros,
mas, só, por semelhança; assim, um indivíduo pode ser denominado metaforicamente Aquiles ou ter
alguma das propriedades de Aquiles, p. ex., a fortaleza.
As formas, porém, que não se individuam por meio de nenhum suposto estranho, mas, por si mesmas,
porque são formas subsistentes, se as consideramos em si mesmas, não podem comunicar-se nem real
nem racionalmente, mas só, talvez, por semelhança, como já dissemos tratando dos indivíduos. Mas,
como não podemos inteligir as formas simples por si subsistentes, tais quais elas são em si mesmas, mas
as inteligimos como se fossem seres compostos, que têm as formas realizadas na matéria, por isso,
como já dissemos, impomos-lhes nomes concretos, que designam a natureza existente em algum
suposto. Por onde, no que diz respeito ao conteúdo dos nomes, o caso dos nomes que impomos para
significarem as naturezas das coisas compostas é o mesmo que o dos que impomos para significarem as
naturezas simples subsistentes.
Portanto, sendo o nome de Deus imposto para significar a natureza divina, como já dissemos, e não
sendo esta multiplicável, como ficou demonstrado, resulta, que o nome de Deus é, certo, realmente
incomunicável, mas pode ser comunicável conforme a opinião de alguém; assim, como o nome sol é
comunicável, na opinião dos que admitem vários sois. E, neste sentido, diz a Escritura (Gl 4, 8): Servíeis
aos que por natureza não são deuses; o que comenta a Glosa: Não são deuses por natureza, mas na
opinião dos homens. Contudo, se o nome de Deus não é comunicável na sua significação total, o é por
algo que nele existe, por uma certa semelhança; e, neste sentido, chamamos deuses aos que
participam, por semelhança, algo de divino, conforme aquilo da Escritura (Sl 81, 6): Eu disse: sois
deuses. Se, porém, existisse algum nome imposto para significar Deus, não em sua natureza, mas como
sujeito, enquanto que ele é tal ser, esse nome seria, de qualquer modo, incomunicável, como se dá,
talvez, com o tetragrama entre os Hebreus; e o mesmo se daria se alguém impusesse ao sol um nome
que designasse precisamente esse indivíduo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A natureza divina não é comunicável senão pela
participação da semelhança.

RESPOSTA À SEGUNDA. — O nome de Deus é apelativo, e não próprio, porque significa a natureza
divina como se ela existisse num sujeito; embora Deus mesmo, na realidade, não seja universal nem
particular. Pois, os nomes não seguem o modo de ser real das coisas, mas o que existe em o nosso
conhecimento. E, contudo, na verdade das coisas, o nome de Deus é incomunicável, como já dissemos,
referindo-nos ao nome do sol.

RESPOSTA À TERCEIRA. — Os nomes — bom, sábio e semelhantes, são, certo, impostos como derivados
das perfeições que procedem de Deus para as criaturas. São, porém, aplicados para significar, não a
natureza divina mas, as perfeições mesmas, absolutamente falando; e, portanto, mesmo na verdade das
coisas, são comunicáveis a muitos. Mas, o nome de Deus é imposto como tendo a sua origem na
operação própria a Deus — e que nós experimentamos continuamente — para significarem a natureza
divina.

## Art. 10 — Se o nome de Deus dele se predica univocamente, quanto à natureza, à participação e à opinião.
O décimo discute-se assim. — Parece que o nome de Deus se lhe atribui univocamente, quanto à
natureza, à participação e à opinião.

1. — Pois, entre quem afirma e quem nega não há contradição se as palavras têm sentidos diversos,
pois, a equivocação impede que se contradigam. Ora, o católico, dizendo — um ídolo não é Deus —
contradiz o pagão que afirma um ídolo é Deus. Logo, Deus é tomado univocamente nessas duas
expressões.

2. Demais. — Assim como um ídolo é Deus conforme uma certa opinião e não na realidade das coisas,
assim o gozo dos prazeres carnais também se chama felicidade, de acordo com certa opinião e não na
realidade. Ora, a palavra felicidade predica-se univocamente tanto da que o é, por opinião, como da que
verdadeiramente é tal. Logo, também o nome de Deus se predica univocamente do Deus real, como do
que uma opinião considera tal.

3. Demais. — São unívocos os termos que têm a mesma significação. Ora, quando um católico diz que
Deus é uno, ele entende por esse nome um ser onipotente e digno de veneração, mais que todos os
outros; e o mesmo entende o gentio quando diz que um ídolo é Deus. Logo, em ambos os casos o nome
de Deus é empregado univocamente.
Mas, em contrário. — O que está na inteligência é uma semelhança do que existe na realidade, como diz
Aristóteles. Ora, o termo animal é empregado equivocamente quando atribuído a um animal verdadeiro
e a um animal pintado. Logo, o nome de Deus é predicado equivocamente quando é atribuído ao Deus
verdadeiro e ao que a opinião julga tal.
Demais. — Ninguém pode exprimir o que não conhece. Ora, o gentio não conhece a natureza divina.
Logo, quando diz — um ídolo é Deus — não exprime a verdadeira deidade, a qual o católico exprime
dizendo que Deus é um só. Logo, o nome de Deus não se predica unívoca, mas, equivocamente, do Deus
verdadeiro e do que uma opinião qualquer julga como tal.

SOLUÇÃO. — O nome de Deus não é tomado, nas três significações propostas, nem unívoca, nem
equívoca, mas analogicamente, o que assim se demonstra. Os termos unívocos têm a mesma
significação; os equívocos têm significação diversa; nos análogos, porém, é necessário que a significação
de um nome, tomado numa acepção, apareça na definição desse mesmo nome tomado em outras
acepções. Assim, a palavra ser, predicado da substância, entra na definição de ser quando predicado do
acidente; do mesmo modo são, predicado de um animal, entra na definição de são predicado da urina e
de um remédio; pois, da saúde do animal, a urina é o sinal, e o remédio, a causa.
Ora, o mesmo se dá com o caso em questão, pois quando o nome de Deus é tomado pelo verdadeiro
Deus, este vocábulo exprime, quer uma opinião, quer uma participação. Assim, quando dizemos que
alguém é Deus por participação, entendemos por esse nome, um ser que tem semelhança com o
verdadeiro Deus. Semelhantemente, quando dizemos que um ídolo é Deus, queremos, com o nome de
Deus, designar um ser que a opinião dos homens considera tal. Por onde, é manifesto que são
diferentes as significações esse nome; mas, uma delas está contida nas outras e, portanto, é claro que
tal nome é predicado analogicamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A multiplicidade de acepções dos nomes não depende
da predicação mas, da significação deles. Pois, o nome de homem tem sempre a mesma significação,
seja qual for a sua predicação, verdadeira ou falsa. Mas, teria múltiplas acepções, se com ele
quiséssemos significar seres diversos; assim, se um quisesse designar com esse nome, o homem
verdadeiro e outro, uma pedra ou coisa semelhante. Por onde, é claro que quando o católico diz que um
ídolo não é Deus, contradiz ao pagão que tal afirma, porque ambos empregam o nome de Deus para
designar o Deus verdadeiro. Mas, quando o pagão diz que um ídolo é Deus, não emprega esse nome
para significar um Deus que uma opinião considera como tal, porque então diria a verdade; pois, que
também os católicos às vezes empregam esse nome nessa significação, como quando a Escritura diz (Sl
95, 5): Todos os deuses das gentes são demônios.
E o mesmo devemos responder, à SEGUNDA e à TERCEIRA OBJEÇÕES. — Pois, essas objeções
procedem, quanto à diversidade da predicação do nome, e, não, quanto à diversidade da significação.

RESPOSTA À QUARTA. — Não é em sentido puramente equivoco que predicamos o nome de animal, do
animal verdadeiro e do pintado. Mas, o Filósofo toma os nomes equívocos em sentido lato, enquanto
em si incluem os análogos; pois o ente, empregado analogicamente é atribuído às vezes,
equivocamente, aos diversos predicamentos.

RESPOSTA À QUINTA. — Nem o católico nem o pagão conhecem a natureza de Deus como ela é em si
mesma; mas, só a conhecem pelas noções de causalidade ou de excelência ou de remoção, como já
dissemos. E neste sentido, quando o gentio usa do nome de Deus, dizendo — Um ídolo é Deus, pode
tomá-lo na mesma significação em que o toma o católico quando diz que um ídolo não é Deus. Porém se
houvesse alguém desprovido totalmente da noção de Deus, esse não poderia nomeá-lo, a não ser no
sentido em que nós proferimos nomes cuja significação ignoramos.

## Art. 11 — Se a denominação — aquele que é — é por excelência o nome próprio de Deus.
(I Sent., dist. 8, q. 1, a. 1, 3; De Pot., q. 2, a.1; q. 7, a. 5; q. 10, a. 1 ad 9; De Div. Nom., cap. V, lect. I).
O undécimo discute-se assim. — Parece que a denominação — Aquele que é — não é, por excelência,
o nome próprio de Deus.

1. — Pois, o nome de Deus é incomunicável, como já dissemos. Ora, isto não se dá com a denominação
—Aquele que é. Logo, esta denominação não é própria de Deus.

2. Demais. — Dionísio diz, que o nome de bem é manifestativo de todas as processões de Deus. Ora,
convém a Deus, por excelência, ser o princípio universal das coisas. Logo, a denominação própria de
Deus, por excelência, é a de bem e não Aquele que é.

3. Demais. — Todo nome divino parece que deve implicar uma relação com as criaturas, pois não
conhecemos a Deus senão por meio destas. Ora, a denominação — Aquele que é — não implica
nenhuma relação com as criaturas. Logo, essa denominação — Aquele que é — não é, por excelência,
própria de Deus.
Mas, em contrário, a Escritura (Ex 3, 13): a Moisés que perguntava: Se eles me disserem: que nome é
o seu? Que lhes hei-de eu responder — respondeu-lhe o Senhor: Eis-aqui o que tu hás-de dizer aos
filhos de Israel: Aquele que é me enviou a vós. Logo, é a denominação — Aquele que é — por
excelência, própria de Deus.

SOLUÇÃO. — A denominação — Aquele que é — por excelência é própria de Deus, por três razões.
Primeira, pela sua significação, pois não significa nenhuma forma, mas, o próprio ser. Ora, sendo em
Deus a existência idêntica à essência, o que não se dá com nenhum outro ser, como já demonstramos, é
manifesto que, entre outras, a denominação de que se trata é a que convém a Deus, por excelência;
pois, um ser é denominado pela sua forma.
Segunda, por causa da sua universalidade. Pois, todos os outros nomes são menos gerais, ou, se são
equivalentes à denominação vertente, contudo, acrescentam-lhe algo, racionalmente, e de certo modo
informam-na e a determinam. Ora, o nosso intelecto não pode, nesta vida, conhecer a essência mesma
de Deus, tal como ela em si é; por onde, seja qual for o modo por que determinamos o que inteligimos
de Deus, não poderemos nunca compreender o que Deus em si mesmo é. E, portanto, quanto menos
determinados e quanto mais gerais e absolutos forem certos nomes, tanto mais propriamente nós os
atribuiremos a Deus. E por isso, diz Damasceno, que de todos os nomes atribuídos a Deus, é
o principal — Aquele que é; pois, compreendendo tudo em si, exprime o ser mesmo, como uma espécie
de pélago infinito e indeterminado da substância. Ao passo que qualquer outro nome determina apenas
um aspecto da substância da coisa designada, a denominação — Aquele que é — não determina
nenhum modo de ser, porque se comporta indeterminadamente em relação a todos e, portanto,
designa o pélago mesmo infinito da substância.
Terceira, pelo que está incluído na sua significação mesma, que é o ser presente, que se atribui a Deus
por excelência, cujo ser não conhece pretérito nem futuro, como diz Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A denominação — Aquele que é — quanto à sua origem,
é mais própria de Deus, que este último nome mesmo; pois, ela se origina do ser, tanto quanto à sua
significação, como quanto ao conteúdo desta, conforme já dissemos. Mas, quanto ao ser designado, o
nome de Deus é mais próprio, porque é usado para significar a natureza divina; se bem que mais próprio
ainda é o nome do tetragrama, imposto para significar a própria essência incomunicável, e, por assim
dizer, singular, de Deus.

RESPOSTA À SEGUNDA. — O nome de bem é o principal nome de Deus, como causa; mas, não de Deus,
considerado em absoluto, pois absolutamente falando, nós inteligimos o ser antes de inteligirmos a
causa.

RESPOSTA À TERCEIRA. — Não é necessário que todos os nomes divinos impliquem relação de Deus
com as criaturas; mas, basta que sejam impostos, fundados em certas perfeições, que procedem de
Deus para elas; e entre essas perfeições a primeira é o ser mesmo, donde derivou a denominação —
Aquele que é.

## Art. 12 — Se podemos formar sobre Deus proposições afirmativas.
(I Sent., dist. IV, q. 2, a. 1; dist. XXII, a. 2, ad 1; I Cont. Gent., cap. XXXVI; De Pot., q. 7, a. 5, ad 2).
O duodécimo discute-se assim. — Parece que não podemos formar sobre Deus proposições
afirmativas.

1. — Pois, diz Dionísio, que as negações, sobre Deus, são verdadeiras, mas, as afirmações são
inconsistentes.

2. Demais. — Boécio diz, que a forma simples não pode ser sujeito. Ora, Deus é forma simples, por
excelência, como já se demonstrou. Logo, não pode ser sujeito. Ora, todo o ser sobre o qual podemos
formar uma proposição afirmativa é tomado como sujeito. Logo, não podemos formar sobre Deus
proposições afirmativas.

3. Demais. — Todo o intelecto, que compreende as coisas diferentemente do que elas são, é falso. Ora,
Deus tem o ser sem nenhuma composição, como já se provou. E, como todo intelecto, que afirmar
alguma coisa, a intelige com composição, resulta que não podemos, verdadeiramente, formar sobre
Deus proposições afirmativas.
Mas, em contrário, a fé não contém nada de falso. Ora, ela encerra certas proposições afirmativas,
como: Deus é trino e uno, é onipotente. Logo, podemos formar, verdadeiramente, a respeito de Deus
proposições afirmativas.

SOLUÇÃO. — Podemos formar, verdadeiramente, a respeito de Deus, proposições afirmativas. Para
evidenciá-lo devemos considerar que, em qualquer proposição afirmativa verdadeira, é necessário que
o predicado e o sujeito exprimam a mesma realidade, de certo modo, e coisas diversas, quanto à noção.
E isto é claro, não só quanto às proposições em que a predicação é acidental, mas também em relação
àquelas em que ela é substancial. Pois, é manifesto que — homem e branco — têm idêntico sujeito, mas
representam noções diferentes; pois, uma é a noção de homem e outra, a de branco. E o mesmo se dá
quando digo — o homem é um animal racional; pois, o homem é, em si mesmo e verdadeiramente,
animal racional; porque o mesmo é o suposto da natureza sensível, em virtude da qual é chamado
animal, e da natureza racional, em virtude da qual é chamado homem. Por onde, também neste caso, o
predicado e o sujeito têm idêntico suposto mas, noções diversas. E ainda, isto mesmo se dá, de certo
modo, com as proposições nas quais um sujeito é predicado de si mesmo; pois, então àquilo que a
inteligência toma como sujeito ela o faz desempenhar o papel de suposto; e ao que toma como
predicado dá a natureza de forma do suposto; e é isto que leva os lógicos a dizerem que os predicados
são tomados formalmente e os sujeitos, materialmente. Ora, a esta diversidade racional corresponde a
pluralidade de predicado e de sujeito; ao passo que a identidade real o intelecto a exprime pela
composição mesma. — Ora, Deus, em si mesmo considerado, é absolutamente uno e simples; contudo,
o nosso intelecto o conhece por meio de conceitos diversos, já que não pode vê-lo tal como em si
mesmo é. Mas, embora o intelija sob noções diversas, sabe, contudo que a todas as suas noções
corresponde um mesmo ser simples. Por onde, essa pluralidade racional ele o representa pela
pluralidade de predicado e sujeito; e a unidade, por meio da composição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dionísio diz, que as afirmações sobre Deus são
inconsistentes; ou inconvenientes, segundo outra tradução, porque nenhum nome lhe convém quanto
ao modo de significar, como já dissemos.

RESPOSTA À SEGUNDA. — O nosso intelecto não pode compreender as formas simples subsistentes,
tais como elas em si mesmas são; mas, as apreende ao modo dos compostos, nos quais há um sujeito e
o que a esse sujeito é inerente. Por onde, apreende a forma simples como se fosse sujeito e lhe atribui
alguma coisa.

RESPOSTA À TERCEIRA. — A proposição — o intelecto que compreende as coisas diferentemente do
que elas são é falso — tem duplo sentido, porque o advérbio diferentemente pode determinar o verbo
compreende, em relação ao objeto compreendido, ou ao sujeito que compreende. No primeiro caso, a
proposição é verdadeira e o seu sentido é: qualquer intelecto que compreende uma coisa
diferentemente do que ela é, é falso. Ora, isto não se dá no caso vertente, porque o nosso intelecto,
quando forma uma proposição sobre Deus, não diz que ele é composto, mas, simples. No segundo caso,
porém, a proposição é falsa; pois, então, o modo pelo qual o intelecto compreende é diferente do pelo
qual a coisa existe. Pois, é manifesto que o nosso intelecto intelige imaterialmente as coisas materiais
que lhe são inferiores; não que as intelija como imateriais, mas, porque tem um modo imaterial de as
inteligir. E, semelhantemente, quando intelige os seres simples, que lhe são superiores, intelige-os ao
seu modo, como se fossem compostos, mas, sem pensar que sejam realmente compostos. E assim, o
nosso intelecto não é falso, quando afirma em Deus alguma composição.