# Questão 44: De como procedem de Deus as criaturas e da causa primeira de todos os seres.
Após a consideração das Divinas Pessoas, resta considerar como procedem de Deus as criaturas. E esta
consideração será tripartida: primeiro, consideraremos a produção das criaturas; segundo, a distinção
delas; terceiro, a conservação e o governo. A respeito do primeiro ponto, três outros se devem
considerar: primeiro, qual seja a causa primeira dos seres; segundo, de como procedem da causa
primeira as criaturas; terceiro, do princípio da duração das coisas.
A respeito do primeiro quatro artigos se discutem:

## Art. 1 — Se é necessário sejam todos os seres criados por Deus.
(Infra, q. 65, a. 1; II Sent., dist. 1. q. 1, a. 2; dist. XXXVII, q. 1, a. 2; II Cont. Gent., cap. XV; De Pot., q. 3, a.
Compend. Theol., cap. LXVIII; Opusc. XV. De Angelis, cap. IX; De Div. Nom., cap. V, lect I).
O primeiro discute-se assim. – Não parece necessário sejam todos os seres causados por Deus.

1. – Nada impede existir uma coisa sem o que não é da sua essência, como, um homem sem a brancura.
Ora, a relação do causado com a causa não parece ser da essência dos seres, pois, sem ela,
compreendem-se alguns seres. Logo, podem existir sem ela. Por onde, nada impede existam alguns
seres não causados por Deus.

2. Demais. – Um ser precisa da causa eficiente para existir. Logo, o que não pode deixar de existir não
precisa de causa eficiente. Mas nada do que é necessário pode deixar de existir, pois o que
necessariamente existe não pode deixar de existir. Como, porém, muitas coisas sejam necessárias, nos
seres, parece que nem todos provêm de Deus.

3. Demais. –Os seres que tem causa podem por esta ser demonstrados. Ora, nas matemáticas não há
demonstração pela causa agente, como se vê no Filósofo. Logo, nem todos os seres provêm de Deus
como de causa agente.
Mas, em contrário, a Escritura (Rm 9, 36): Porque dele, e por ele, e nele existem todas as coisas.

SOLUÇÃO. – Necessário é admitir-se como causado por Deus tudo o que de qualquer modo existe. Pois,
a coisa existente em outra por participação, é nessa outra causada necessariamente pelo ser ao qual ela
essencialmente convém; assim, o ferro torna-se ígneo pelo fogo. Ora, já quando antes se tratou da
divina simplicidade demonstrou-se que Deus é o ser mesmo por si subsistente; e demonstrou-se
também que o ser subsistente não pode ser mais de um; assim, se fosse subsistente, a brancura não
podia ser mais de uma, pois as brancuras se multiplicam pelos seres que as contém. Donde se conclui
que todos os seres, exceto Deus, não tem o ser por si mesmo, mas por participação. Logo, todos os seres
diversificados, por participarem diversificadamente do ser, e, assim, mais ou menos perfeitos,
necessariamente devem ser causados por um ser primeiro perfeitíssimo. – Por onde, disse Platão ser
necessário admitir a unidade como anterior a toda multidão. E Aristóteles diz que o ser maximamente
ser e verdadeiro é causa de todos os seres e de toda a verdade; assim como, o maximamente cálido é
causa de toda a calidez.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –Embora a relação com a causa não entre na definição do
causado, contudo resulta da essência deste; pois do ser por participação resulta que é causado por
outro. Por onde, tal ente não pode existir sem que seja causado; assim como não o pode o homem sem
que seja capaz de rir-se. Mas como o ser causado não é da essência de um ente puro e simples, daí
resulta que certo ser não é causado.

RESPOSTA À SEGUNDA. – Por esta objeção muitos foram levados a admitir que o necessário não tem
causa, como se diz na Física de Aristóteles. Mas tal aparece manifestamente como falso nas ciências
demonstrativas, nas quais princípios necessários são causas de conclusões necessárias. Por onde, diz
Aristóteles, que há certos seres necessários que encerram a causa da sua necessidade. Pois não só por
poder o efeito não existir é que se requer a causa agente, mas porque o efeito não existiria se a causa
não existisse. E esta condicional é verdadeira, quer sejam o antecedente e o conseqüente possíveis ou
impossíveis.

RESPOSTA À TERCEIRA. –Consideradas abstratas pela razão, as entidades matemáticas não são
abstratas pelo ser. Ora, um ser tem causa agente na medida em que tem o ser. Assim, pois, embora as
entidades matemáticas tenham causa agente, contudo não é pela relação que tem com tal causa que
caem sob a consideração do matemático. Por onde, nas ciências matemáticas, nada se demonstra pela
causa agente.

## Art. 2 — Se a matéria prima é causada por Deus.
(II Cont. Gent., cap. XVI; De Pot., q. 3, a. 5; Compend. Theol., cap. LXIX; VIII Phys., lect II).
O segundo discute-se assim. – Parece que a matéria prima não é causada por Deus.

1. – Tudo o que é feito compõe-se de um sujeito e de alguma outra coisa, como diz Aristóteles. Ora, a
matéria prima não tem nenhum sujeito. Logo, não pode ser feita por Deus.

2. Demais. – A ação e a paixão dividem-se por oposição mútua. Mas assim como o primeiro princípio
ativo é Deus, assim o primeiro princípio passivo é a matéria. Logo, Deus e a matéria prima são dois
princípios divididos por oposição mútua, sem provir um do outro.

3. Demais. – Todo agente age semelhantemente a si; e assim como todo agente age enquanto está em
ato, segue-se que tudo o que é feito está, de algum modo, em ato. Ora, a matéria prima, como tal, só
existe em potência. Logo, é contra a essência da matéria prima o ser feita.
Mas, em contrário, diz Agostinho: Duas coisas fizeste, Senhor: uma semelhante a ti, isto é, o anjo; outra
semelhante ao nada, isto é, a matéria prima.

SOLUÇÃO. – Os antigos filósofos aos poucos, e como pé por pé, entraram no conhecimento da verdade.
Assim, a princípio, como que, mais grosseiros de existência, não reputavam entes senão os corpos
sensíveis. E dentre eles, os que em tais corpos admitiam o movimento, consideravam-no a este somente
segundo certos acidentes, p. ex., segundo a raridade e a densidade, por congregação e segregação. E
supondo sem causa a substância mesma dos corpos, buscavam certas causas a tais transmutações
acidentais, como a amizade, a luta, a inteligência e coisas semelhantes. Outros filósofos, porém, mais
em progresso, distinguiram, pelo intelecto, entre a forma substancial, e a matéria sem causa; e
perceberam transmutação nos corpos segundo formas essenciais. Dessas transmutações admitiam
certas causas mais universais como o círculo oblíquo, segundo Aristóteles, ou as Idéias, segundo Platão.
Deve-se, porém, considerar que a matéria é limitada pela forma a uma determinada espécie; assim
como a substância de uma espécie é limitada, por acidente superveniente, a um determinado modo de
ser; p. ex., homem é limitado por branco. Uns e outros filósofos, portanto, consideraram o ser por certa
consideração particular, seja enquanto este ser, seja enquanto tal ser. E, por isso, atribuíram às coisas
causas agentes particulares. Mas ulteriormente alguns se alçaram a considerar o ser enquanto ser e
consideraram a causa das coisas não só enquanto estas ou tais, mas enquantoentes. Ora, a causa das
coisas enquanto entes deve sê-lo não somente enquanto são tais coisas, pelas formas acidentais, nem
somente enquanto são estas coisas, pelas formas substanciais; mas também segundo tudo o que lhes
pertence ao ser de qualquer modo. Assim que, é necessário também admitir a matéria prima como
causada pela causa universal dos seres.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O Filósofo, no lugar citado, fala do vir a ser particular, que
é o da forma, em forma acidental ou substancial. No caso vertente, porém, falamos das coisas segundo
a emanação delas do princípio universal do ser; de cuja emanação nem a matéria é excluída, embora o
seja do primeiro modo de facção.

RESPOSTA À SEGUNDA. – A paixão é efeito da ação. Por onde, é racional que o primeiro princípio
passivo seja efeito do primeiro princípio ativo, pois tudo o que é imperfeito é causado pelo perfeito.
Ora, é necessário que o primeiro princípio seja perfeitíssimo, como diz Aristóteles.

RESPOSTA À TERCEIRA. – Tal objeção não prova que a matéria não seja causada, mas que não é causada
sem forma; pois embora tudo o que é causado exista em ato, não é todavia ato puro. Por onde
necessariamente, também aquilo que se comporta como potência é causado, se o todo do qual o seu
ser faz parte é causado.

## Art. 3 — Se a causa exemplar é algo diverso de Deus.
(Supra, q. 15; I Sent., dist. XXXVI, q. 2; I Cont. Gent., cap. LIV; De Verit., q. 3, a. 1, 2; De Div. Nom., cap. V,
lect. III; I Metaphys., lect. XV).
O terceiro discute-se assim. – Parece que a causa exemplar é algo diverso de Deus.

1. – Pois, o exemplado tem a semelhança do exemplar. As criaturas, porém, muito distam da divina
semelhança. Logo, Deus não é a causa exemplar delas.

2. Demais. – Tudo o que existe por participação se reduz a algo que é existente por si, como o que é
ígneo se reduz ao fogo, como já se disse. Ora, todas as coisas sensíveis só existem por participação de
alguma espécie, como claramente se depreende de se não encontrar, em nenhuma delas, somente o
pertencente à essência da espécie, mas de se acrescentarem princípios individuantes aos princípios da
espécie. Logo, é necessário admitirem-se as espécies mesmas como existentes por si, como, o homem
em si e o cavalo em sie assim por diante. Ora, tais entidades se chamam exemplares. Por onde, há, fora
de Deus, certas coisas que são causas exemplares.

3. Demais. – As ciências e as definições se referem às espécies em si mesmas e não enquanto existentes
em seres particulares, pois dos particulares não há ciência nem definição. Logo, há certos entes que são
entes ou espécies não existentes nos seres singulares, e tais se chamam exemplares. Por onde, conclui-
se o mesmo que antes.

4. Demais. – Isto mesmo se lê em Dionísio dizendo, que o ser que o é por si mesmo é anterior ao que é a
vida em si mesma e ao que é a sapiência em si mesma.
Mas, em contrário, é que o exemplar é idêntico à idéia. Ora, as idéias, como diz Agostinho, são as formas
principais contidas na inteligência divina. Logo, os exemplares das coisas não existem fora de Deus.

SOLUÇÃO. – Deus é a causa exemplar primeira de todas as coisas. Para evidenciá-lo devemos considerar
que para a produção de qualquer coisa é necessário um exemplar, para que o efeito resulte de uma
forma determinada. Assim o artífice produz uma determinada forma na matéria, por causa do exemplar
considerado, quer esse exemplar lhe seja exterior, quer seja concebido interiormente na sua mente.
Ora, é manifesto que as coisas existentes em a natureza resultam de formas determinadas; e é
necessário seja essa determinação das formas reduzida, como ao primeiro princípio, à divina sabedoria,
que cogitou a ordem do universo, consistente na distinção das coisas. E, portanto, é necessário admitir-
se que na divina sabedoria estão as razões de todas as coisas, a que chamamos antes idéias, isto é,
formas exemplares existentes na mente divina. E essas, embora multiplicadas enquanto referidas às
coisas, contudo não são realmente diversas da essência divina, pois a semelhança desta pode ser
participada diversamente por seres diversos. Assim, pois, Deus é o exemplar primeiro de todas as coisas.
Mas também, entre os seres criados, uns podem chamar-se exemplares de outros, enquanto estes tem
com aqueles semelhanças, ou segundo a mesma espécie ou segundo a analogia de alguma imitação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –Embora as criaturas não alcancem o serem semelhantes a
Deus segundo a natureza delas, por semelhança específica, como o homem gerado é semelhante ao
homem gerador; alcançam, contudo, a semelhança com Deus segundo a representação da essência
inteligida por Ele, como a casa existente na matéria é semelhante à existente na mente do artífice.

RESPOSTA À SEGUNDA. –É da essência do homem existir na matéria; por isso não se pode encontrar um
homem sem matéria. Embora, pois, tal homem exista por participação da espécie, não pode contudo ser
reduzido a algo existente por si, na mesma espécie, mas a uma espécie superexcedente, como são as
espécies separadas. E a mesma é a natureza dos outros seres sensíveis.

RESPOSTA À TERCEIRA. –Embora a ciência e a definição seja só dos seres, não é necessário contudo que
as coisas tenham o mesmo modo de existir que o intelecto, de inteligir. Pois nós,por virtude do intelecto
agente, abstraímos as espécies universais das condições particulares. Não é necessário todavia que os
universais subsistam sem os particulares, como exemplares destes.

RESPOSTA À QUARTA. –Como diz Dionísio, a vida em si mesma e a sapiência em si mesma, ora designa
o próprio Deus, ora virtudes inerentes às coisas mesmas; não porém coisas subsistentes, como queriam
os antigos.

## Art. 4 — Se Deus é a causa final de todas as coisas.
(Infra, q. 65, a. 2; q. 103, a. 2; II Sent., dist. 1, q. 2, a. 1, 2; Cont. Gent., cap. XVII; Compend. Theol., cap. C,

CI).
O quarto discute-se assim. – Parece não seja Deus a causa final de todas as coisas.

1. – Pois, agir por um fim parece ser próprio de um ser que precisa de um fim. Ora, Deus de nada
precisa. Logo, não lhe cabe agir por um fim.

2. Demais. – O fim da geração e a forma do gerado, e o agente não são numericamente idênticos, como
diz Aristóteles; pois o fim da geração é a forma do gerado. Ora, Deus é o primeiro de todos os agentes.
Logo, não é a causa final de todas as coisas.

3. Demais. – Todas as coisas desejam o fim, mas nem todas desejam Deus, porque nem todas o
conhecem. Logo, Deus não é o fim de todas as coisas.

4. Demais. – A causa final é a primeira das causas. Se, pois, Deus for causa agente e causa final, segue-se
que há n’ele anterior e posterior, o que é impossível.
Mas, em contrário, a Escritura (Pr 16, 4): Tudo fez o Senhor por causa de si mesmo.

SOLUÇÃO. – Todo agente age por um fim; ao contrário, da ação do agente não resultaria antes uma que
outra coisa senão pelo acaso. Ora, o agente e o paciente como tais têm idêntico fim, mas em sentidos
diferentes. Pois uma e mesma coisa é o que o agente visa imprimir e o que o paciente visa receber. Há,
porém, certos seres que simultaneamente agem e sofrem a ação, e são os agentes imperfeitos; e a esses
convém que, mesmo no agir, visem alguma aquisição. Mas ao agente primeiro, que é somente agente,
não cabe agir para a aquisição de algum fim; mas ele visa somente comunicar a sua perfeição, que é a
sua bondade. E cada uma das criaturas visa conseguir a própria perfeição, que é semelhança da
perfeição e da bondade divina. Assim, pois, a divina bondade é o fim de todas as coisas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. –Agir por indigência só é próprio do agente imperfeito, a
que é natural agir e sofrer a ação. Mas tal não cabe em Deus. Por onde, só ele é maximamente liberal,
porque não age para sua utilidade, mas só por sua bondade.

RESPOSTA À SEGUNDA. –A forma do gerado só é o fim da geração enquanto é semelhança da forma do
generante, que visa comunicar a sua semelhança. Do contrário, a forma do gerado seria mais nobre que
a do generante, pois o fim é mais nobre do que as coisas que dele dependem.

RESPOSTA À TERCEIRA. –Todas as coisas desejam Deus como fim, desejando qualquer bem, quer pelo
apetite inteligível, quer pelo sensível, quer pelo natural, que é sem conhecimento; pois nada tem a
natureza de bom e de desejável senão enquanto participa da semelhança de Deus.

RESPOSTA À QUARTA. – Sendo Deus a causa eficiente, exemplar e final de todas as coisas, e provindo
d’ele a matéria prima, segue-se que o primeiro princípio de todas as coisas é só um na realidade. Pois,
nada impede que em Deus se considerem muitas coisas, pela razão, das quais algumas caem, antes de
outras, sob a apreensão da nossa inteligência.
