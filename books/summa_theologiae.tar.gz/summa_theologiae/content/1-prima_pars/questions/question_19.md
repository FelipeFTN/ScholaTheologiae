# Questão 19: Da vontade de Deus.
Depois de termos tratado do que pertence à ciência divina, devemos tratar do pertencente à vontade
divina. De modo que o primeiro tratado será sobre a vontade mesma de Deus; o segundo sobre o que
pertence à vontade, em absoluto; o terceiro sobre o que pertence ao intelecto, em relação com a
vontade.
Sobre a vontade, em si mesma, discutem-se doze artigos:

## Art. 1 — Se Deus tem vontade.
Infra., q. 54, a. 2; I Sent., dist. XLV, a. 1; I Cont. Gent., cap. LXXII, LXXIII; IV, cap. XIX; De Verit., q. 23, a. 1;
Comp. Theol., cap. XXXII.
O primeiro discute-se assim. — Parece que Deus não tem vontade.

1. — Pois, o objeto da vontade é o fim e o bem. Ora, não podemos estabelecer nenhum fim para Deus.
Logo, Deus não tem vontade.

2. Demais. — A vontade é um apetite. Ora, o apetite, desejando o que não possui, implica uma
imperfeição, que não convém a Deus. Logo, Deus não tem vontade.

3. Demais. — Segundo o filósofo, a vontade é um motor movido. Ora, Deus é o primeiro motor imóvel,
como o mesmo o prova. Logo, Deus não tem vontade.
Mas, em contrário, a Escritura (Rm 12, 2): Para que experimenteis qual é a vontade de Deus.

SOLUÇÃO. — Tendo Deus intelecto, há de também ter vontade, pois esta acompanha aquele. Pois assim
como o ser natural se atualiza pela forma, assim o intelecto intelige em ato pela forma inteligível. Ora,
qualquer ser tem uma inclinação tal para a sua forma natural que, não a possuindo, tende para ela e, se
já a possui, nela repousa. E o mesmo se dá com qualquer perfeição natural, que é o bem da natureza.
Essa inclinação para o bem, nos seres privados de conhecimento, chama-se apetite natural. Por onde,
também a natureza intelectual tem uma inclinação semelhante para o bem apreendido pela forma
inteligível; de modo que, quando o possui, nele repousa, e o deseja enquanto não o possui. Ora, uma e
outra coisa pertencem à vontade. Logo, qualquer ser que tem intelecto tem vontade, assim como
qualquer que tem sentido tem o apetite animal. E portanto, como Deus tem intelecto, necessariamente
também tem vontade. E sendo o seu inteligir o seu ser, é também o seu querer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o fim de Deus não seja nenhum outro ser, senão
ele próprio, contudo, Deus mesmo é o fim de tudo o que fez. E isto pela sua essência, porque é bom, por
essência, como já demonstramos; pois, a essência do fim é o bem.

RESPOSTA À SEGUNDA. — Em nós, a vontade pertence à parte apetitiva que, embora derive o seu
nome de — apetir — contudo não é o seu único ato apetir o que não tem, mas também, amar o que
tem, e nisso deleitar-se. Ora, deste último modo, Deus tem vontade, a qual sempre possui o bem, que é
o seu objeto; pois, a sua essência não difere do bem, como já se disse.

RESPOSTA À TERCEIRA. — Sendo o objeto principal da vontade o bem, que existe fora do querente, é
necessário que a vontade seja movida por um ser diverso de si. Ora, o objeto da vontade de Deus é a
sua bondade, que é a sua essência. Por onde, a vontade, sendo a essência de Deus, não é movida por
um ser estranho, mas somente por Deus mesmo, no sentido em que se chama movimento ao inteligir e
ao querer. E, por isso, Platão disse, que o primeiro motor se move a si mesmo.

## Art. 2 — Se Deus quer coisas diversas de si.
(I Sent., dist. XLV, a. 2; I Cont. Gent., cap. LXXV, LXXVI, LXXVII, De Verit., q. 23, a. 4)).
O segundo discute-se assim. — Parece que Deus não quer coisas diversas de si.

1. — Pois, a vontade de Deus é o seu ser. Ora, Deus não é diferente de si mesmo. Logo, não pode querer
coisas diversas de si.

2. Demais. — O querido move o querente, como o apetível, o apetite, segundo Aristóteles. Ora, se Deus
quisesse coisas diversas de si, a sua vontade seria movida por algo de estranho, o que é impossível.

3. Demais. — A quem lhe basta o que quer, nada mais quer além disso. Ora, a Deus basta-lhe a sua
bondade, com a qual a sua vontade se sacia. Logo, Deus não quer coisas diversas de si.

4. Demais. — O ato da vontade multiplica-se na relação do que quer. Ora, se Deus se quisesse, a si
mesmo e a coisas diversas de si, seguir-se-ia que o ato da sua vontade seria múltiplo, e, por
conseqüente, o seu ser que é a sua vontade. Ora, tal é impossível. Logo, Deus não quer coisas diversas
de si.
Mas, em contrário, o Apóstolo (1 Ts 4, 3): Esta é a vontade de Deus, a vossa santificação.

SOLUÇÃO. — Deus não somente se quer a si mesmo, mas também a coisas diversas de si, o que resulta
do símile antes introduzido. Pois, os seres naturais, não somente têm inclinação natural para adquirir o
bem próprio, se não o possuem, e nele repousar, se já o possuem, mas também a difundi-lo nos outros,
na medida do possível. E, por isso, vemos todo o agente, na medida em que é atual e perfeito, gerar um
semelhante a si. E que é da essência da vontade comunicarmos a outrem o bem que possuímos, na
medida do possível. Ora, isto é precipuamente próprio à vontade divina, da qual, por certa semelhança,
deriva toda a perfeição. Donde, se as coisas naturais, enquanto perfeitas, comunicam a outras o seu
bem, com maioria de razão e por semelhança, é próprio à vontade divina comunicar a outros o seu, na
medida do possível. E portanto quer-se a si mesma e quer outras coisas; a si, porém, como fim; às outras
como meios, enquanto convém à divina bondade que também os demais seres dela participem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a vontade divina seja, na realidade, o seu ser,
contudo, deste difere pela razão, segundo o modo diverso de inteligir e significar, como resulta do
sobredito. Pois, quando digo, Deus existe, isto não implica nenhuma relação com outro ser, como
quando digo, Deus quer. E portanto, embora Deus não seja diferente de si, quer, contudo, coisas
diversas de si.

RESPOSTA À SEGUNDA. — No que queremos por causa de um fim, este é a razão total do querer, e é
ele que move a vontade. E isto se manifesta sobretudo naquelas coisas que queremos somente por
causa do fim. Assim quem quer tomar uma poção amarga só procura nela a saúde, e é só isso o que lhe
move a vontade. Diversamente, porém, acontece com quem toma uma poção doce, que pode querer,
não somente por causa da saúde, mas, por si mesma. Donde, Deus, não querendo coisas diversas de si,
senão por causa do fim, que é a sua bondade, como já se disse, não se segue que seja diferente da sua
bondade o que lhe move a vontade. E assim como, inteligindo a sua essência, Deus intelige as coisas
diversas de si, assim também, querendo a sua bondade, quer coisas diversas de si.

RESPOSTA À TERCEIRA. — Do bastar à vontade de Deus a sua bondade, não se segue que Deus não
queira coisas diversas de si, mas que nada diverso quer, a não ser em razão da sua bondade. Assim
também, o intelecto divino, embora perfeito, por isso mesmo que conhece a essência divina, contudo
nesta conhece outras coisas.

RESPOSTA À QUARTA. — Assim como é uno o inteligir divino, porque vê muitas coisas na unidade,
assim também, uma e simples é a vontade divina, porque quer muitas coisas, mas pela sua bondade
una.

## Art. 3 — Se Deus quer necessariamente tudo o que quer.
(I Cont. Gent., cap. LXXX sq.; III, cap. XCVII; De Verit., q. 23, a. 4; De Pot., q. 1, a. 5; q. 10, a. 2, ad 6).
O terceiro discute-se assim. — Parece que Deus quer necessariamente tudo o que quer.

1. — Pois, tudo o que é eterno é necessário. Ora, tudo o que Deus quer o quer abeterno, aliás a sua
vontade seria mutável. Logo, tudo o que ele quer o quer necessariamente.

2. Demais. — Deus, querendo a sua bondade, quer outras coisas de si diversas. Ora, quer a sua bondade
necessariamente. Logo, quer necessariamente outras coisas diversas de si.

3. Demais. — Tudo o que é natural a Deus é necessário, porque é o ser necessário, em si, e o princípio
de toda necessidade, como já se demonstrou. Ora, é natural a Deus querer tudo quanto quer, porque
nele nada pode existir contra a sua natureza, como diz Aristóteles. Logo, tudo quanto Deus quer
necessariamente o quer.

4. Demais. — Não ser, necessariamente, e não ser possivelmente são expressões eqüipolentes. Se, pois,
Deus não quer necessariamente alguma das coisas que quer, é lhe possível também não querê-la e,
portanto, querer aquilo que não quer. Logo, a vontade divina é contingente em um e outro caso e, por
conseqüência, imperfeita, porque todo contingente é imperfeito.

5. Demais. — Nenhuma ação pode resultar de uma causa capaz de produzir dois efeitos diferentes,
exceto se, por um ser estranho, for inclinada a um deles como diz o Comentador. Se, pois, a vontade de
Deus, em certos casos, tem duas possibilidades, segue-se que é determinada a uma delas por um ser
estranho, e, assim, tem uma causa anterior.

6. Demais. — Tudo o que Deus sabe, necessariamente o sabe. Ora, como a ciência divina, também a
vontade é a sua essência. Logo, Deus quer necessariamente tudo quanto quer.
Mas, em contrário, o Apóstolo (Ef 1, 11): É Deus que faz todas as coisas segundo o conselho da sua
vontade. Ora, o que é feito pelo conselho da vontade não o queremos necessariamente. Logo, Deus não
quer necessariamente tudo o que quer.

SOLUÇÃO. — Em duplo sentido dizemos que uma coisa é necessária; absolutamente e por suposição. A
necessidade absoluta resulta da natureza dos termos, ou porque o predicado está incluído na definição
do sujeito — assim, é necessário o homem ser animal; ou porque o sujeito é da essência do predicado —
assim, é necessário o número ser par ou ímpar. Ora, assim, não é necessário, p. ex., Sócrates sentar-se.
Por onde, não é necessário, absolutamente, mas podemos dizer que o é, por suposição; pois, suposto
que esteja sentado, é necessário que o esteja, enquanto o está.
Ora, no querer divino, devemos considerar que é um necessário absoluto o querer Deus alguma coisa;
mas, isso não é verdade em relação a tudo o que quer. Pois, a vontade divina tem relação necessária
com a divina bondade, que é o seu objeto próprio. Donde, o querer Deus necessariamente a existência
da sua bondade, do mesmo modo que a nossa vontade quer necessariamente a beatitude; e que
qualquer outra potência tem relação necessária com o seu objeto próprio e principal, p. ex., a vista, com
a cor; pois, é da sua natureza o tender para ela. As demais coisas, porém, Deus as quer enquanto
ordenadas à sua bondade, como o fim delas. Ora, querendo o fim não queremos necessariamente os
meios, senão os que são tais que, sem eles, o fim não possa existir: assim, querendo a conservação da
vida, queremos o alimento e, querendo atravessar o mar, queremos o navio. Mas, não queremos
necessariamente aquelas coisas sem as quais o fim pode existir; p. ex., um cavalo, para passear, porque
podemos andar sem ele; e o mesmo se dá em outros casos. Ora, sendo a bondade de Deus perfeita, e
podendo existir sem os outros seres, que nenhuma perfeição lhe acrescentam, segue-se não ser
necessário de necessidade absoluta, que Deus queira coisas diversas de si. Mas o é por suposição; pois,
suposto que queira, não pode deixar de querer, pois, suposto que queira, não pode deixar de querer,
pois, não se lhe pode mudar a vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De querer Deus abeterno tudo quanto quer, não se
segue que o queira necessariamente, exceto por suposição.

RESPOSTA À SEGUNDA. — Embora Deus queira necessariamente a sua bondade, contudo, não quer
necessariamente aquilo que quer por causa dela, pois, esta pode existir sem tais coisas.

RESPOSTA À TERCEIRA. — Não é natural nem inatural a Deus, ou contra a sua natureza, mas é
voluntário, querer alguma daquelas coisas que não quer necessariamente.

RESPOSTA À QUARTA. — Às vezes, uma causa necessária tem relação não-necessária com certo efeito;
e isso por deficiência deste e não daquela. Assim, a virtude do sol tem relação não necessária com
qualquer dos fenômenos contingentes da terra, não por deficiência de tal virtude, mas, do efeito
proveniente não necessariamente da causa. Do mesmo modo, o querer Deus não necessariamente
alguma daquelas causas que quer, não é por deficiência da sua vontade, mas, pela deficiência da coisa
querida, em virtude da natureza mesma desta, que é tal que, sem ela, pode existir a perfeita bondade
de Deus. Ora, tal deficiência acompanha todo o bem criado.

RESPOSTA À QUINTA. — Necessariamente a causa em si mesma contingente, há de ser determinada ao
efeito por algo de exterior. Ora, a vontade divina, que tem de si mesma a sua necessidade, determina-se
por si ao objeto querido, com a qual tem relação não necessária.

RESPOSTA À SEXTA. — Como o ser divino é, em si, necessário, assim também o querer e o saber divinos;
mas o saber divino tem relação necessária como seu objeto; não a tem porém o querer divino com as
coisas queridas. E isto porque a ciência tem por objeto as coisas, conforme elas existem no sujeito; a
vontade, porém, refere-se a elas conforme são em si mesmas. Logo, todas as coisas têm existência
necessária, enquanto existem em Deus, mas não têm necessidade absoluta enquanto existem em si
mesmas, de modo a serem em si mesmas necessárias. E por isso, Deus sabe necessariamente tudo o
que quer.

## Art. 4 — Se a vontade de Deus é a causa das coisas.
I Sent., dist. XLIII, q. 2, a. 1; dist. XLV, a. 3; II Cont. Gent., cap. XXIII; De Pot., q. 1, a. 5; q. 3, a. 15.
O quarto discute-se assim. — Parece que a vontade de Deus não é a causa das coisas.

1. — Pois, diz Dionísio: Assim como o nosso sol, sem raciocinar ou preeleger, mas pelo seu próprio ser,
ilumina todas as coisas que lhe podem participar da luz; assim também o bem divino, pela sua própria
essência, incute em todos os seres existentes raios da bondade divina. Ora, todo o ser que age pela
vontade, age racional e deliberadamente. Logo, Deus não age pela vontade e, portanto, a vontade de
Deus não é a causa das coisas.

2. Demais. — O essencial ocupa, em qualquer ordem, o primeiro lugar; assim, o que é essencialmente
fogo ocupa o primeiro lugar na ordem das coisas ígneas. Ora, Deus é o agente primeiro. Logo, é agente
pela sua essência, que é a sua natureza, e portanto age por natureza e não, pela vontade; e não é, pois,
a vontade divina a causa das coisas.

3. Demais. — Tudo o que, em virtude de ser o que é, causa outro ser, é causa por natureza e não pela
vontade. Assim, o fogo é causa da calefação, porque é quente; mas o artífice é causa do edifício, porque
o quer fazer. Ora, Agostinho dizque nós existimos porque Deus é bom. Logo, Deus é causa das coisas
pela sua natureza e não, pela sua vontade.

4. Demais. — Cada efeito tem sua causa. Ora, das coisas criadas é causa a ciência de Deus, como já se
disse. Logo, a vontade de Deus não pode ser a causa delas.
Mas, em contrário, a Escritura (Sb 11, 26): E como poderia subsistir coisa alguma, se tu não quisesses?

SOLUÇÃO. — É necessário admitir-se, por tríplice razão, que a vontade de Deus é a causa das coisas, e
que Deus age pela vontade e não, por necessidade de natureza, como alguns opinaram.
A primeira razão resulta da própria ordem das causas agentes. Pois, como o intelecto e a natureza agem
por causa de um fim, como o prova Aristóteles, é necessário que ao agente por natureza sejam
predeterminados, por algum intelecto superior, o fim e os meios necessários para o fim. Assim, o fim e o
modo certo de uma seta são-lhe predeterminados pelo sagitário. E, portanto, quem age pelo intelecto e
pela vontade deve ter prioridade sobre o agente por natureza. Por onde, sendo Deus o primeiro, na
ordem dos agentes, necessariamente há de agir pelo intelecto e pela vontade.
A segunda razão funda-se na função do agente natural, ao qual é próprio produzir um efeito, pois, a
natureza não sendo impedida, opera sempre do mesmo modo. E isto porque age conforme ao que é;
por isso, como tal, há de produzir um determinado efeito, pois todo agente por natureza tem o ser
determinado. Ora, o ser divino não sendo determinado, mas contendo em si toda a perfeição do existir,
não lhe é possível agir por necessidade de natureza; salvo se causasse algum ser de existência
indeterminada e infinita, o que é impossível, como do sobredito se colhe. Logo, não age por necessidade
de natureza, mas os efeitos determinados pela sua infinita perfeição procedem da determinação da sua
vontade e do seu intelecto.
A terceira razão funda-se na relação entre os efeitos e a causa. Pois, os efeitos procedem da causa
agente, na medida em que nela preexistem; porque todo agente age semelhantemente a si. Os efeitos,
porém, preexistem na causa, ao modo da causa. Ora, o ser divino, sendo o seu próprio inteligir, os seus
efeitos nele preexistem de modo inteligível. E, portanto, também dele procedem de modo inteligível e,
por conseqüência, ao modo da vontade. Pois, a sua inclinação a realizar o que foi concebido pelo
intelecto pertence à vontade. Logo, a vontade de Deus é a causa das coisas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dionísio, com as palavras citadas, não quis excluir a
eleição, de Deus, absoluta, mas relativamente; pois, embora a eleição importe um certo discernimento,
contudo, comunica não somente a alguns seres a sua bondade, mas a todos.

RESPOSTA À SEGUNDA. — A essência de Deus, sendo o seu inteligir e o seu querer, segue-se, em
virtude de agir por essência, que age ao modo do intelecto e da vontade.

RESPOSTA À TERCEIRA. — O bem é o objeto da vontade. Por onde, dizemos que existimos porque Deus
é bom, na medida em que a sua bondade é a sua razão de querer tudo o mais, como estabelecemos.

RESPOSTA À QUARTA. — De um mesmo efeito, ainda em nós, é causa a ciência, como dirigente, pois ela
é a que concebe a forma da obra; e a vontade, como imperante; pois, a forma, enquanto existente
apenas no intelecto, não é determinada, senão pela vontade, a existir ou não, no efeito. Por isso, o
intelecto especulativo em nada se ocupa com a operação. Mas, a potência é a causa exeqüente, porque
designa um princípio imediato de operação. Todas essas faculdades, porém, se unificam em Deus.

## Art. 5 — Se se pode determinar alguma causa à vontade divina.
I Sent., dist. XLI, a. 3; I Cont. Gent., cap. LXXXVI, LXXXVII; III, XCVII; De Verit., q. 6, a. 2; q. 23, a. 1, ad 3; a.
6 ad 6; Ephes., cap. I, lect. I.
O segundo discute-se assim. — Parece que se pode determinar alguma causa à vontade divina.

1. — Pois, pergunta Agostinho: Quem ousará dizer que Deus criou irracionalmente todas as coisas?Ora,
no agente voluntário, a razão de operar é também a causa de querer. Logo, a vontade de Deus tem
alguma causa.

2. Demais. — Quem quer o que fez, por nenhuma outra causa, senão porque quer, não tem nenhuma
outra causa de agir senão a sua vontade. Ora, a vontade de Deus é a causa de todas as coisas, como já
se demonstrou. Se, portanto, a sua vontade não tem nenhuma outra causa, não devemos buscar outra
causa, em todas as coisas naturais, senão essa vontade. E então, todas as ciências são vãs, que se
esforçam por descobrir as causas de certos efeitos. Ora, tal é inadmissível. Logo, devemos assinalar
alguma causa à vontade divina.

3. Demais. — O que fizemos sem nenhuma outra causa, senão porque quisemos, depende
simplesmente de nossa vontade. Se, pois, a vontade de Deus não tem nenhuma causa, resulta que todas
as coisas criadas dependem simplesmente da sua vontade, sem nenhuma outra causa, o que é
inadmissível.
Mas, em contrário, diz Agostinho: Toda causa eficiente é maior do que o seu efeito; mas, nada é maior
que a vontade de Deus. Logo, não se lhe deve buscar nenhuma causa.

SOLUÇÃO. — De nenhum modo a vontade de Deus tem causa. Para evidenciá-lo devemos considerar,
que a causa da nossa vontade querer há de ter semelhança com a causa de o nosso intelecto inteligir.
Ora, se o nosso intelecto intelige os princípios e as conclusões, a inteligência do princípio é a causa da
ciência da conclusão. Mas, se inteligir a conclusão, no próprio princípio, apreendendo a ambos por uma
mesma intuição, a ciência da conclusão não seria causada pela inteligência dos princípios, porque um
mesmo ser não pode causar-se a si próprio. Mas, inteligiria os princípios como causa da conclusão. O
mesmo se dá com a vontade, em relação à qual, o fim está para os meios, como, em relação ao
intelecto, os princípios, para as conclusões. Por onde, se por um ato quisermos o fim e, por outro, os
meios, a vontade do fim será a causa dos meios. Mas se, por um só ato, quisermos o fim e os meios, já
não se dará tal, porque um mesmo ser não pode causar-se a si próprio; e contudo será verdadeiro dizer-
se que queremos que os meios se ordenem para o fim. Ora, Deus inteligindo todas as coisas, na sua
essência, por um só ato, também por um só ato as quer todas, na sua bondade. Donde, assim como,
nele, inteligir a causa não é a causa do inteligir os efeitos, mas ele próprio intelige os efeitos, na causa,
assim também, sua vontade do fim não lhe é causa de querer os meios; contudo, quer que estes se
ordenem àqueles. Logo, quer que os meios existam por causa do fim, mas não os quer aqueles por
causa deste.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vontade de Deus é racional, não porque haja alguma
causa de Deus querer, mas porque quer que tal coisa exista por causa de tal outra.

RESPOSTA À SEGUNDA. — Deus, querendo que os efeitos provenham de causas certas, para que se
conserve a ordem das coisas, não é vão buscarmos além da vontade de Deus, outras causas. Sê-lo-ia,
contudo, se a estas buscássemos como primeiras e independentes da divina vontade. E nesse sentido,
diz Agostinho: Aprouve à vaidade dos filósofos atribuir também às outras causas efeitos contingentes;
porque de nenhum modo podiam descobrir a causa superior a todas as outras, que é a vontade de
Deus.

RESPOSTA À TERCEIRA. — Deus, querendo que os efeitos dependam das suas causas, quaisquer efeitos
que pressuponham outro não dependem só da vontade de Deus, mas também desse outro. Mas, os
efeitos primeiros só da vontade divina dependem. Assim, se disséssemos, que Deus quis que o homem
tivesse mãos para servirem ao intelecto, fazendo várias obras; e quis que tivesse intelecto, para que
fosse homem; e quis que fosse homem para que o gozasse ou para complemento do universo. O que
tudo não pode reduzir-se a fins criados ulteriores. Daí o dependerem tais efeitos da simples vontade de
Deus: os outros porém dependem, além disso, da ordem das outras causas.

## Art. 6 — Se a vontade de Deus sempre se cumpre.
I Sent., dist., XLVI, a. 1; dist. XLVII, a. 1, 3; De Verit., q. 23, a. 2; I Tim., cap. II, lect. I
O sexto discute-se assim. — Parece que nem sempre se cumpre a vontade de Deus.

1. — Pois, diz o Apóstolo (1 Tm 2, 4): Deus quer que todos os homens se salvem e que cheguem a ter
conhecimento da verdade. Ora, tal não se dá. Logo, a vontade de Deus nem sempre se cumpre.

2. Demais. — A ciência está para a verdade, como a vontade para o bem. Ora, Deus sabe toda a
verdade. Logo, quer todo o bem. Mas nem todo o bem se faz; pois, há muitos que podem ser feitos e
não se fazem. Logo, nem sempre se cumpre a vontade de Deus.

3. Demais. — A vontade de Deus, sendo a causa primeira, não exclui as causas médias, como já se disse.
Ora, os efeitos da causa primeira podem ser impedidos por deficiência da causa segunda. Assim, o efeito
da virtude motiva é impedido pela debilidade da tíbia. Logo, o efeito da vontade divina pode ser
impedido pela deficiência das causas segundas, e, portanto, nem sempre se cumpre essa vontade de
Deus.
Mas, em contrário, a Escritura (Sl 113, 3): Tudo quanto quis Deus, fez.

SOLUÇÃO. — Necessariamente, a vontade de Deus há de sempre cumprir-se. Para evidenciá-lo devemos
considerar que o efeito, conformando-se pela sua forma, com o agente, o mesmo se dá, com as causas
agentes, que se dá com as causas formais. Ora, quanto às formais, embora algum ente possa ser
deficiente, em relação a alguma forma particular, contudo nenhum pode sê-lo em relação à forma
universal; assim, pode um ente não ser homem ou vivente, nenhum porém há que não seja ser. E o
mesmo há de dar-se com as causas agentes. Pois, um ser pode escapar à ordem de uma causa agente
particular; não porém, à de uma causa agente universal, na qual estão compreendidos todos os seres
particulares. Se uma causa particular falhar seu efeito, tal será por impedimento de alguma outra causa
particular, contida na ordem da causa universal. Portanto, o efeito de nenhum modo pode escapar à
ordem da causa universal. E bem o mostram os seres corpóreos. Assim pode ficar impedida uma estrela
de produzir o seu efeito, contudo, qualquer efeito resultante, para as coisas corpóreas, da causa
corpórea impediente, é forçoso que se reduza, por algumas causas médias, à virtude universal do
primeiro céu. Ora, sendo a vontade de Deus a causa universal de todas as coisas, é impossível não
consiga o seu efeito. Donde, o que escapa à vontade divina, numa ordem, entra nela por outra. Assim, o
pecador pecando, afasta-se, o quanto pode, da vontade divina; reentra, porém, na ordem desta quando
punido pela divina justiça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lugar do Apóstolo, Deus quer que todos os homens se
salvem etc., podemos entendê-lo de tríplice modo. Primeiro, acomodando-se a distribuição a este
sentido: Deus quer que se salve todos os homens que se salvam; não que haja algum que ele queira que
não se salve, mas, que nenhum se salva sem que Deus o queira, como diz Agostinho.
De um segundo modo, podemos entendê-lo no sentido em que a distribuição se faça conforme os
gêneros dos indivíduos e não conforme os indivíduos de cada gênero: e, assim, Deus quer que haja
quem se salve, em todos os estados humanos — homens e mulheres — judeus e gentios, pequenos e
grandes: não porém, todos de cada estado.
De terceiro modo, segundo Damasceno, entendemo-lo relativamente à vontade antecedente e não à
conseqüente. Mas, esta distinção não se aplica à vontade divina, na qual não há anterioridade nem
posterioridade, mas às coisas queridas. E, para a compreensão disto, devemos atender a que cada ser,
enquanto bom, é querido de Deus. Um ser, porém, considerado em si mesmo, primária e
absolutamente, pode ser bom ou mau; contudo, considerado juntamente com outro, o que é considerá-
lo conseqüentemente, pode comportar-se de maneira contrária. Assim, considerado absolutamente, é
bom o homem viver, e mau morrer; mas se acrescentarmos que certo homem é homicida ou constitui
perigo para a multidão, nesse caso é-lhe bom morrer e mau, viver. Portanto, podemos dizer, que o juiz
justo quer, antecedentemente, que todo homem viva, mas, conseqüentemente, que o homicida seja
enforcado. Do mesmo modo, Deus quer, antecedentemente, que todo homem se salve; mas,
conseqüentemente, que alguns se danem, conforme a exigência da sua justiça. Não queremos porém,
de maneira absoluta, mas relativa, o que queremos antecedentemente. Porque a vontade quer as coisas
como são em si mesmas; ora, em si mesmas, têm existência particular. Donde, queremos uma coisa
absolutamente quando a queremos, consideradas todas as suas circunstâncias particulares; o que é
querê-la conseqüentemente. Por isso, podemos dizer, que o juiz justo quer absolutamente que o
homicida seja enforcado; mas, relativamente, e enquanto homem, que viva. O que mais se pode chamar
veleidade, que vontade absoluta. E assim, é claro, que tudo o que Deus quer, absolutamente se realiza,
embora não se realize o que quer antecedentemente.

RESPOSTA À SEGUNDA. — O ato da virtude cognoscitiva se realiza quando o conhecido está no
conhecente; porém, o da virtude apetitiva se ordena às coisas como elas existem em si mesmas. Ora,
tudo o que pode ter razão de ser e de verdade está totalmente em Deus de modo virtual; mas, não
existe totalmente nas coisas criadas. Portanto, Deus conhece toda a verdade, mas não quer todos os
bens, senão enquanto se quer a si mesmo, em quem virtualmente existem todos.

RESPOSTA À TERCEIRA. — A causa primeira quando não é universalmente primeira, isto é, quando não
compreende em si todas as causas, pode ser impedida no seu efeito, pela deficiência da causa segunda.
Mas, quando é universalmente primeira, o efeito de nenhum modo pode escapar à sua ordem. E é o que
se dá com a vontade de Deus, como dissemos.

## Art. 7 — Se a vontade de Deus é mutável.
I Sent., dist. XXXIX, q. 1, a. 1; dist. XLVIII, q. 2, a. 1, ad 2; I Cont. Gent., cap. LXXXII; III, cap. XCI, XCVI,

XCVIII; De Verit., q. 12, a. 2, ad 3; Hebr., cap. VI, lect. IV.
O sétimo discute-se assim. — Parece que a vontade de Deus é mutável.

1. — Pois, diz a Escritura (Gn 6, 7): Pesa-me de os ter feito. Ora, quem se arrependeu do que fez tem
vontade mutável.

2. Demais. — A Escritura diz (Jr 18, 7), da pessoa do Senhor: Falarei contra uma gente e contra um reino,
para desarraigá-lo e destruí-lo e arruiná-lo. Mas, se aquela gente se arrepender do seu mal, também eu
me arrependerei do mal que tenho pensado fazer contra ela. Logo, Deus tem vontade mutável.

3. Demais. — Tudo o que Deus faz, voluntariamente o faz. Ora, Deus não faz sempre as mesmas coisas:
assim, ora manda observar a lei, ora o proíbe. Logo, tem vontade mutável.

4. Demais. — Deus não quer necessariamente o que quer, como se disse antes. Logo, pode querer e não
querer a mesma coisa. Mas, tudo o que tem poder em relação a dois contrários é mutável; assim o que
pode ser e não ser é mutável, quanto à substância; e o que pode estar e não estar num lugar é mutável,
quanto ao lugar.
Mas, em contrário, a Escritura (Nm 23, 19): Deus não é, como o homem, capaz de mentir, nem, como o
filho do homem, sujeito à mudança.

SOLUÇÃO. — A vontade de Deus é absolutamente imutável. Mas, sobre este assunto, devemos
considerar que, mudar-se a vontade, é diferente de querer a mutação de certas coisas. Pois, podemos
querer que agora se faça tal coisa, e em seguida, o contrário, permanecendo a mesma vontade imóvel.
Mas, a vontade se mudaria se começássemos a querer o que antes não queríamos ou deixássemos de
querer o que queríamos. O que não se pode dar, sem pressupormos a mutação, por parte do
conhecimento, ou quanto à disposição da substância mesma da pessoa que quer. Ora, como a vontade
tem por objeto o bem, podemos começar a querer uma coisa de duplo modo. De um modo, se nos
começar a ser bom o que dantes não nô-lo era; o que não vai sem mudança nossa. Assim, chegando o
frio, começa-nos a ser bom assentarmo-nos ao fogo, o que, dantes, não nô-lo era. De outro modo,
quando conhecemos como bom o que dantes ignorávamos que o fosse. Pois, deliberamos para
sabermos o que nos é bom. Ora, já demonstramos que tanto a substância de Deus, como a sua ciência é
absolutamente imutável. Logo, é forçoso que seja a sua vontade absolutamente imutável.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa expressão do Senhor devemos entendê-la
metaforicamente e por semelhança conosco. Assim, quando nos arrependemos, destruímos o que
fizemos, embora isso possa fazer-se sem mutação da vontade; como quando às vezes queremos, sem
mutação da nossa vontade, fazer algo com intenção simultânea de o destruir em seguida. Assim, pois,
dizemos que Deus se arrependeu, por essa semelhança de agir, delindo da face da terra pelo dilúvio o
homem que criara.

RESPOSTA À SEGUNDA. — A vontade de Deus, com ser a causa primeira e universal, não exclui as
causas médias, a cuja virtude pertence produzir certos efeitos. Mas, porque todas as causas médias não
podem adequar-se à virtude da causa primeira, muitas causas existem na virtude, na ciência, e na
vontade divina, que não estão contidas na ordem das causas inferiores, como a ressurreição de Lázaro.
Por onde, quem considerasse as causas inferiores poderia dizer: Lázaro não ressurgirá; — mas
considerando a causa primeira divina, dizer: Lázaro ressurgirá. — E Deus quer tanto isto como aquilo, a
saber, que alguma coisa haja de ser, segundo as causas inferiores; que, contudo, não será, segundo a
causa superior; ou reciprocamente. Por onde, devemos concluir que Deus, por vezes, prenuncia um
futuro, enquanto contido na ordem das causas inferiores — como, p. ex., segundo a disposição da
natureza ou dos méritos — que, entretanto, não se realizará, porque existe de maneira diferente na
causa superior divina. Assim, o que predisse a Ezequias, como refere a Escritura (Is 38, 1) — Dispõe da
tua casa, porque tu morrerás e não viverás — não se realizou, porque estava determinado
diferentemente e abeterno, pela ciência e pela vontade divina, que é imutável. E, por isso, diz
Gregório: Deus muda a sentença, mas não o conselho, isto é, a sua vontade. Quando diz, pois —
Também eu me arrependerei — isso deve entender-se metaforicamente, porque os homens, quando
não cumprem o que prometeram, dizemos que se arrependeram.

RESPOSTA À TERCEIRA. — Da razão aduzida não podemos concluir, que Deus tem vontade mutável,
mas que quer a mutação.

RESPOSTA À QUARTA. — Embora não seja necessário, absolutamente, querer Deus alguma coisa,
contudo é necessário por suposição, por causa da imutabilidade da divina vontade, como dissemos.

## Art. 8 — Se a vontade de Deus impõe necessidade às coisas queridas.
(I Cont. Gent., cap. LXXXV; II, cap. XXIX, XXX; De Verit., q. 23, a. 5; De Malo, q. 16, a. 7, ad 15; Quodl., XI,
q. 3; XII, q. 3, ad 1; I Periherm., lect. XIV).
O oitavo discute-se assim. — Parece que a vontade de Deus impõe necessidade às coisas queridas.

1. — Pois, diz Agostinho: Só se salva quem quiser que se salve. Logo, devemos rogar-lhe que queira,
porque necessariamente se fará se ele o quiser.

2. Demais. — Toda a causa que não pode ser impedida produz necessariamente o seu efeito, porque a
natureza sempre obra do mesmo modo, se nada a impedir, como diz Aristóteles. Ora, a vontade de Deus
não pode ser impedida, pois o Apóstolo diz (Rm 9, 19): Quem é o que resiste à sua vontade? Logo, a
vontade de Deus impõe necessidade às coisas queridas.

3. Demais. — O necessário apriori o é absolutamente; assim, é necessário que o animal morra, por ser
composto de elementos contrários. Ora, as coisas criadas por Deus estão para a vontade divina como
para o ser primeiro, do qual recebem a necessidade; pois é verdadeira esta condicional — se Deus
quiser alguma coisa, ela existirá— e toda condicional verdadeira é necessária. Logo, tudo o que Deus
quer é necessário, absolutamente.
Mas, em contrário, Deus quer que se façam todos os bens que se fazem. Se, pois, a vontade impõe
necessidade às coisas queridas, segue-se que todo bem se produz necessariamente. E então perece o
livre arbítrio, o conselho e coisas semelhantes.

SOLUÇÃO. — A vontade divina impõe necessidade a certas coisas queridas, mas não, a todas. E a razão
disto alguns a foram buscar nas causas médias, porque aquelas coisas que Deus produz por causas
necessárias são necessárias; mas, contingentes as que produz por causas contingentes. Porém esta
opinião não é exata, por duas razões. — A primeira, porque o efeito de qualquer causa primeira é
contingente, pela deficiência da causa segunda, que lho impede; assim, a virtude do sol é impedida por
deficiência da planta. Ora, nenhuma deficiência da causa segunda pode impedir a vontade de Deus de
produzir o efeito. — A segunda é que, se a distinção entre o contingente e o necessário se referir só às
causas segundas, tal estará contra a intenção e a vontade divina, o que é inadmissível.
E portanto melhor diremos, que tal se dá pela eficácia da vontade divina. Pois, da causa eficaz para agir
resulta o efeito, não somente, de fato, mas também quanto ao seu feitio ou modo de ser. Assim, da
debilidade da virtude seminal ativa resulta que o filho nasce diferente do pai, pelos acidentes próprios,
quanto ao modo de existir. Ora, a vontade divina, sendo eficacíssima, não somente produz as coisas que
quer que se façam, mas, também do modo pelo qual assim as quer. Ora, Deus quer que algumas se
façam necessariamente outras, contingentemente, havendo assim ordem nas coisas, para complemento
do universo. E por isso, a certos efeitos adaptou causas necessárias e indeficientes, das quais resultam
necessariamente. A outros, causas contingentes, defectíveis, das quais resultam efeitos contingentes.
Por onde, não é porque as causas próximas sejam contingentes que os efeitos queridos de Deus se
realizam contingentemente, mas, porque Deus, querendo que se realizassem contingentemente,
adaptou-lhes causas contingentes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As citadas palavras de Agostinho devem entender-se
como referentes à necessidade, não absoluta, mas condicional, nas coisas queridas por Deus. Pois, é
necessário que a condicional — se Deus quiser tal coisa, ela se dará necessariamente — seja verdadeira.

RESPOSTA À SEGUNDA. — Como nada resiste à vontade divina, resulta que, não somente se farás as
coisas que Deus quer que se façam, mas se farão contingente ou necessariamente, conforme ele o
quiser.

RESPOSTA À TERCEIRA. — O posterior tira a sua necessidade do que lhe é anterior, mas ao modo deste.
Donde, as coisas feitas por vontade divina têm a necessidade que Deus quer que tenham, a saber,
absoluta, ou somente condicional. E assim, nem todas as coisas são necessárias absolutamente.

## Art. 9 — Se Deus quer o mal.
Infra., q. 48, a. 6; I Sent., dist. XLVI, a. 4; I Cont. Gent., cap. XCV; De Pot., q. 1, a. 6; De Malo., q. 2, a. 1, ad

6.
O nono discute-se assim. — Parece que Deus quer o mal.

1. — Pois, quer todo o bem que existe. Ora, é bom que o mal exista, conforme Agostinho: Embora o mal
em si não seja bem, contudo é bom que exista, para que não somente exista o bem, mas também o mal.
Logo, Deus quer o mal.

2. Demais. — Dionísio diz: O mal contribui para a perfeição de todo o universo. E Agostinho: A admirável
beleza do universo resulta de todos os seres; e nela, mesmo o que é mal, bem ordenado e posto no seu
lugar, põe mais em evidência o bem, de modo que este mais agrade e seja mais louvável, quando
comparado com o mal. Ora, Deus quer tudo o que pertence à perfeição e à beleza do universo, pois isso
é o que ele sobretudo quer nas criaturas. Logo, quer o mal.

3. Demais. — Ser feito e não ser feito o mal são opostos contraditórios. Ora, Deus não quer que o mal
não se faça, porque praticando-se certos males nem sempre se cumpriria a vontade de Deus. Logo, Deus
quer que o mal se faça.
Mas, em contrário, diz Agostinho: Ninguém se torna pior por causa de um homem sábio. Mas, Deus vale
mais que qualquer sábio. Logo, com maior razão, ninguém se torna pior por causa de Deus. Pois, uma
coisa tem como autor a quem voluntariamente a fez. Logo, pela vontade de Deus o homem não se torna
pior: Mas, sabemos que por qualquer mal uma coisa se torna pior. Portanto, Deus não quer o mal.

SOLUÇÃO. — Sendo o bem por natureza apetecível, como dissemos, e o mal se lhe opondo, é impossível
o mal como tal ser apetido, quer pelo apetite natural, quer pelo animal, ou pelo intelectual, que é a
vontade. Mas o mal podemos apetecê-lo por acidente, enquanto conduz a algum bem. E isto se dá com
qualquer apetite, pois, o agente natural não busca a privação ou a corrupção; mas uma forma
concomitante à privação de outra e à geração de um ser, que é a corrupção de outro. Assim, o leão,
matando o cervo, busca o alimento, que não é possível sem a morte deste animal. Semelhantemente, o
impudico busca o prazer, que não é possível sem a deformidade da culpa. Ora, o mal que acompanha
um bem é a privação de outro bem; pois, nunca seria apetido o mal, nem mesmo por acidente, se o
bem, que vai de mistura com ele, não fosse mais apetido do que o outro bem de que ele priva. Ora,
nenhum bem Deus quer mais do que a sua bondade: mas, quer mais um bem que outro. Donde, o mal
da culpa, que priva da ordem para o bem divino, Deus de nenhum modo o quer; mas, quer o mal do
defeito natural, ou o da pena, querendo algum bem ao qual se une esse mal. Assim, querendo a justiça,
que a pena, e querendo seja conservada a ordem da natureza, quer que algumas coisas naturalmente se
corrompam.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Alguns disseram, que, embora Deus não queira o mal
quer contudo que ele exista ou seja praticado. E isto diziam porque o mal em si mesmo, se ordena para
algum bem; e essa ordem criam estar implicada no dizerem — o mal existir ou ser praticado. Mas, esta
opinião não é verdadeira, porque o mal não se ordena ao bem, essencialmente, mas por acidente. Pois,
não está na intenção do pecador que, do pecado, resulte algum bem, assim como não estava na
intenção do tirano que, pelas suas perseguições, brilhasse a paciência dos mártires. E, portanto, não se
pode dizer que tal ordem para o bem se subentenda no dizer-se que é bom que o mal exista ou seja
praticado. Porque não se julga uma coisa pelo que lhe convém acidentalmente, senão essencialmente.

RESPOSTA À SEGUNDA. — O mal não contribui para a perfeição ou beleza do universo, senão por
acidente, como dissemos. Por onde, que o mal contribui para a perfeição do universo é uma conclusão,
que Dionísio considera como inconveniente.

RESPOSTA À TERCEIRA. — Embora o ato de praticar o mal se oponha contraditoriamente ao de não
praticá-lo, contudo, querer que o mal seja praticado e que não o seja não se opõem contraditoriamente,
pois, ambas são proposições afirmativas. Assim, Deus nem quer que o mal seja praticado, nem que não
o seja; mas, quer permitir que o seja, e isto é bem.

## Art. 10 — Se Deus tem livre arbítrio.

II Sent., dist. XXV, q. 1, a. 1; I Cont. Gent., cap. LXXXVIII; De Verit., q. 24, a. 3; De Malo, q. 16, a. 5.
O décimo discute-se assim. — Parece que Deus não tem livre arbítrio.

1. — Pois, Jerônimo diz: Só em Deus não há pecado, nem pode haver; os outros seres, tendo livre
arbítrio, podem-se inclinar para uma e outra parte.

2. Demais. — O livre arbítrio é a faculdade da razão e da vontade, que elege o bem e o mal. Ora, Deus
não quer o mal, como se disse. Logo, não tem livre arbítrio.
Mas, em contrário, diz Ambrósio: O Espírito Santo distribui a cada um conforme quer, isto é, pelo livre
arbítrio da vontade e não, por força da necessidade.

SOLUÇÃO. — Temos livre arbítrio em relação ao que queremos não necessariamente ou por instinto
natural. Assim, não é por livre arbítrio, mas, por instinto natural, que queremos ser felizes. Por onde,
dos outros animais, pelo que buscam por instinto natural, não dizemos que se movem por livre arbítrio.
Ora, Deus, querendo a sua bondade necessariamente, e os outros seres, não necessariamente, como
demonstramos, em relação ao que quer, não necessariamente, tem livre arbítrio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Parece que Jerônimo exclui de Deus o livre arbítrio, não
absolutamente, mas só quanto à possibilidade de cair em pecado.

RESPOSTA À SEGUNDA OBJEÇÃO. — O mal da culpa é assim chamado pela sua aversão à bondade
divina, pela qual Deus quer todas s coisas, como já demonstramos. Por onde, é claro que é impossível a
deus querer esse mal. E contudo, Deus pode querer termos opostos como que tal coisa exista ou não;
do mesmo modo que nós, sem pecar, podemos querer e não querer sentar.

## Art. 11 — Se devemos distinguir em Deus a vontade que se manifesta por um sinal.
I Sent., dist. XLV, a. 4; De Verit., q. 23, a. 3.
O undécimo discute-se assim. — Parece que não devemos distinguir em Deus a vontade que se
manifesta por um sinal.

1. — Pois, assim como a vontade de Deus é causa das coisas, assim também, a sua ciência. Ora, nenhum
sinal se atribui à ciência. Logo, também nenhum sinal devemos atribuir à vontade divina.

2. Demais. — Todo sinal que não concorda com o assinalado é falso. Ora, se os sinais atribuídos à
vontade divina não concordam com ela, são falsos; e se concordam, são supérfluos. Logo, nenhum sinal
devemos atribuir à vontade divina.
Mas, em contrário, a vontade de Deus é una, por ser una a própria essência de Deus. Mas, às vezes, é
expressa no plural, como quando diz a Escritura (Sl 110, 2): Grandes são as obras do Senhor, apropriadas
a todas as suas vontades. Logo, é necessário que, às vezes, o sinal da vontade seja tomado por ela.

SOLUÇÃO. — De Deus, umas coisas se predicam propriamente, e outras, metaforicamente, como
resulta do que já dissemos. Assim, certas paixões humanas se predicam de Deus metaforicamente, pela
semelhança do efeito. Daí, o que é sinal de tal paixão em nós, é significado metaforicamente em Deus,
pelo nome dessa paixão. Assim, entre nós, os irados costumam punir e, por isso, é a punição sinal da ira,
sendo daí a punição expressa pelo nome de ira, quando atribuída a Deus.
Semelhantemente, o que em nós costuma ser sinal de vontade dizemos, às vezes, metaforicamente que
é vontade em Deus; assim, o ordenar alguma coisa é sinal que quer que tal coisa se faça. Por onde, o
preceito divino às vezes se chama, metaforicamente, vontade de Deus, segundo aquilo da Escritura (Mt
6, 10): Seja feita a vossa vontade, assim na terra como no céu. Mas, entre a vontade e a ira há esta
diferença, que a ira nunca se atribui propriamente a Deus, pois, em sua significação principal, ela inclui a
paixão; ao contrário, a vontade se lhe atribui propriamente, donde o distinguirmos em Deus a vontade
propriamente dita da que o é metaforicamente. Pois, a vontade propriamente dita se chama vontade de
beneplácito; porém, a vontade metaforicamente dita se chama vontade de sinal, por se chamar vontade
ao sinal mesmo dela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ciência não é causa do que fazemos, senão pela
vontade; pois, não fazemos o que sabemos, sem querermos. Logo, o sinal não se atribui à ciência, como
se atribui à vontade.

RESPOSTA À SEGUNDA. — Os sinais da vontade se chamam vontades divinas, não porque sejam sinais
que Deus queira; mas, porque aquilo, que em nós costuma ser sinal de vontade, chama-se em Deus —
vontades divinas. Assim, a punição não é sinal de Deus estar irado, mas, porque em nós é sinal de ira,
chamamos-lhe ira divina.

## Art. 12 — Se se distinguem convenientemente cinco sinais da vontade divina, a saber: a proibição, o preceito, o conselho, a operação e a permissão.
I Sent., dist. XLV, a. 4; De Verit., q. 23, a. 3.
O duodécimo discute-se assim. — Parece inconveniente admitir cinco sinais da vontade divina, a
saber, a proibição, o preceito, o conselho, a operação e a permissão.

1. — Pois aquilo mesmo que Deus em nós preceitua ou aconselha, às vezes obra em nós; e por vezes
permite o mesmo que proibiu. Logo, tais sinais não se devem dividir por oposição.

2. Demais. — Deus nada obra sem querer, como diz a Escritura (Sb 11, 25-26). Ora a vontade de sinal se
distingue da de beneplácito. Logo, a operação não deve ser compreendida na vontade de sinal.

3. Demais. — Operação e permissão são própria em geral a todas as criaturas, porque Deus obra em
todas e em todas permite que alguma coisa seja feita. Ora, o preceito, o conselho e a proibição são
próprios somente à criatura racional. Logo, não entram convenientemente numa mesma divisão, por
não serem da mesma ordem.

4. Demais. — O mal é praticado de mais maneiras que o bem, porque o bem só se realiza de um modo, e
o mal, de muitos, como está claro no Filósofoe em Dionísio. Logo, é inconveniente determinar em
relação ao mal um só sinal — a proibição, e em relação ao bem, dois — o conselho e o preceito.

SOLUÇÃO. — Pelos sinais em questão costumamos manifestar que queremos alguma coisa. Ora,
podemos declarar que queremos alguma coisa, por nós mesmos ou por outrem. Por nós mesmos,
fazendo-a direta ou indiretamente, e por acidente. Diretamente, quando fazemos alguma coisa, em si
mesma, e então dizemos que o sinal é a operação. Indiretamente, quando não há impedimento para o
operante, pois ao que remove o obstáculo se chama motor por acidente, como ensina o Filósofo; então
dizemos que o sinal é a permissão. Manifestamos, demais, querer alguma coisa, por meio de outrem,
ordenando-o a faze-la; ou por indução necessária, preceituando o que queremos e proibindo o
contrário; ou por alguma indução persuasória, o que pertence ao conselho. Ora, como por estes modos
manifestamos querer alguma coisa, por isso, esses cinco sinais se denominam, às vezes, pelo nome de
vontade divina, como sinais da vontade. Assim, que o preceito, o conselho e a proibição se chamam
vontade de Deus, claramente o diz a Escritura (Mt 6, 10): Seja feita a vossa vontade, assim na terra como
no céu. Que a permissão ou a operação se chamem vontade de Deus, está claro em Agostinho: Nada
disso aconteceu sem que o Onipotente o queira, permitindo que aconteça, ou fazendo. — Ou também
se pode dizer, que a permissão e a operação referem-se ao presente: a permissão, ao mal, e a operação,
ao bem. Quanto ao futuro, a proibição é relativa ao mal; o preceito, ao bem necessário; o conselho, ao
bem superabundante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede que, em relação à mesma coisa,
manifestemos diversamente a nossa vontade, assim como existem muitos nomes com a mesma
significação. Por onde, nada impede tenham o mesmo objeto o preceito, o conselho, a operação, a
proibição e a permissão.

RESPOSTA À SEGUNDA. — Assim como podemos exprimir metaforicamente que Deus quer alguma
coisa, que não quer pela vontade propriamente dita, assim também podemos exprimir do mesmo
modo, o que quer propriamente. Por onde, nada impede que a vontade de beneplácito e de sinal se
refiram ao mesmo objeto. Mas, a operação sempre se identifica com a vontade de beneplácito; não
porém, o preceito ou o conselho, quer porque a operação se refere ao presente e o preceito e o
conselho, ao futuro, quer, porque a operação é, em si, efeito da vontade, e o preceito e o conselho se
exercem por meio de outrem, como dissemos.

RESPOSTA À TERCEIRA. — A criatura racional é senhora do seu ato. Por isso, em relação a ela
distinguem-se certos sinais da divina vontade, enquanto que Deus ordena a criatura racional a agir
voluntariamente e por si. Mas, as outras criaturas só agem movidas da operação divina; e por isso, em
relação a elas só têm lugar a operação e a permissão.

RESPOSTA À QUARTA. — Todos os males da culpa, embora se realizem multiplamente, contudo convém
no discordarem da vontade divina, e por isso se lhes determina um sinal — a proibição. Mas os bens se
relacionam diversamente com a bondade divina. Pois, há certos sem os quais não podemos conseguir a
fruição dessa bondade; e para esses é o preceito. Outros, porém, nós os conseguimos mais
perfeitamente, e para esses é o conselho. Ou devemos dizer, que o conselho visa, não somente a
consecução dos melhores bens, mas ainda evitar os menores males.