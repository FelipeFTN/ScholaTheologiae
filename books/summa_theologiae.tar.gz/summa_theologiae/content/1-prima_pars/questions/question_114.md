# Questão 114: Do ataque dos demônios.
Em seguida deve-se tratar do ataque dos demônios.
E sobre esta questão cinco artigos se discutem:

## Art. 1 — Se os homens são atacados pelos demônios.
(Supra, q. 64, a. 4).
O primeiro discute-se assim. — Parece que os homens não são atacados pelos demônios.

1. — Pois os anjos Deus os envia como deputados, à guarda dos homens. Ora, os demônios não são
enviados por Deus, porque a intenção deles é perder as almas, enquanto que a de Deus é salvá-las.
Logo, os demônios não são deputados a atacar os homens.

2. Demais. — Não há igualdade de condição na luta do fraco contra o forte, do ignaro contra o astuto.
Ora, ao passo que os homens são fracos e ignaros, os demônios são poderosos e astutos. Logo, Deus,
autor de toda justiça, não pode permitir que os homens sejam atacados pelos demônios.

3. Demais. — Para exercitar o homem bastam os ataques da carne e do mundo. Ora, Deus permite que
os seus eleitos sejam atacados, para exercício deles. Logo, não é necessário que sejam atacados pelo
demônio.
Mas, em contrário, diz a Escritura: Nós não temos que lutar contra a carne e o sangue; mas sim contra
os principados e potestades, contra os dominadores deste mundo tenebroso, contra os espíritos
malignos espalhados pelos ares.

SOLUÇÃO. — Duas coisas se devem considerar em relação ao ataque dos demônios: o ataque em si, e a
ordem dele. — O ataque, em si, procede da malícia dos demônios que, por inveja, esforçam-se por opor
obstáculos ao homem adiantando em perfeição: e pela soberba, usurpam a semelhança do divino poder
deputando determinados ministros seus a atacarem os homens, assim como os anjos são ministros de
Deus, exercendo determinadas funções, para a salvação dos mesmos. — Por outro lado, a ordem
mesma do ataque procede de Deus, que sabe servir-se ordenadamente dos males para deles tirar o
bem. — Quanto aos anjos porém tanto a guarda, como a ordem dela dependem de Deus, como do
autor primeiro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os maus anjos atacam os homens de dois modos. —
Instigando-os ao pecado; e então não são mandados por Deus, para atacar, mas tal lhes permitem às
vezes os justos juízos de Deus. — Outras vezes porém atacam os homens, para os punir: e então são
mandados por Deus; assim, foi mandado o espírito da mentira para punir Acabe, rei de Israel, conforme
a Escritura; pois, a pena depende de Deus, como do seu autor primeiro. Contudo, os demônios
mandados para punir punem com intenção diferente daquela pela qual foram mandados; pois punem
por ódio ou por inveja, embora Deus os tivesse mandado pela sua justiça.

REPOSTA À SEGUNDA. — Por não haver igualdade de condição na luta é que há compensação da parte
do homem; principalmente, pelo auxílio da graça divina e, secundariamente, pela guarda dos corpos.
Por onde, segundo a Escritura, Eliseu disse ao seu ministro: Não temas; muitos mais estão conosco do
que com eles.

RESPOSTA À TERCEIRA. — Bastariam para a fraqueza humana, os ataques da carne e do mundo, como
exercitação; mas não bastam, para malícia dos demônios, que usam de ambos para atacar os homens.
Contudo, por ordenação divina, isso redunda em glória dos eleitos.

## Art. 2 — Se tentar é próprio do diabo.
(II Sent., dist. XXI, q. 1, a. 1; Opusc. VII, Exposit. Orat. Dom., petit. VI; in Math., cap. IV; I Thess., cap. I
lect. Unic.: Hebr., cap. XI, lect. IV).
O segundo discute-se assim. — Parece que tentar não é próprio do diabo.

1. — Pois, a Escritura diz que Deus tenta: Tentou Deus a Abraão. Também a carne e o mundo tentam; e
dize-se ainda que o homem tenta a Deus e a outro homem. Logo, não é próprio do demônio tentar.

2. Demais. — O ignorante é que tenta. Ora, os demônios sabem o que devem fazer em relação aos
homens. Logo não tentam.

3. Demais. — A tentação é via para o pecado. Ora este reside na vontade. Portanto, como os demônios
não podem imutar a vontade do homem, segundo já se estabeleceu, resulta que deles não é próprio
tentar.
Mas, em contrário, diz a Escritura: Não vos haja tentado aquele que tenta: ao que, a Glossa: i. é, o diabo,
cujo ofício é tentar.

SOLUÇÃO. — Tentar propriamente é experimentar alguma coisa; e se experimenta para que se saiba
algo dessa coma; sendo por isso o fim próprio de quem tenta, a ciência. Mas, às vezes busca-se
ulteriormente pela ciência algum outro fim, bom ou mau; bom, quando se quer conhecer alguém,
quanto à ciência ou à virtude, para fazê-lo progredir; mau, quando é para o enganar ou prejudicar. E
deste modo pode-se compreender como tentar é diversamente atribuído a diversos. — Assim, diz-se
que o homem tenta às vezes só para saber; e então tentar a Deus é pecado, porque o homem, como se
estivesse incerto, presume experimentar a virtude de Deus. Outras vezes porém tenta para ajudar.
Outras enfim para prejudicar. O diabo porém sempre tenta para prejudicar, fazendo cair em pecado. E
por isso, diz-se que o ofício próprio dele é tentar; pois, embora também o homem às vezes tente assim,
ele o faz como ministro do diabo. — Ao passo que quando se diz que Deus tenta, para saber, isso
significa que faz os outros saberem. E por isso diz a Escritura: O Senhor vosso Deus vos tenta, para se
fazer manifesto se o amais ou não. — Diz-se porém que a carne e o mundo tentam, instrumental ou
materialmente, i. é, enquanto se pode conhecer um homem, porque seguir ou rejeitar as
concupiscências da carne, e desprezar prosperidades ou adversidades do mundo; coisa de que o diabo
também se serve, para tentar.
Donde se deduz a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Os demônios sabem o que fazem, exteriormente, em relação aos homens;
mas a condição interior do homem pela qual uns são mais inclinados a tal vício que a tal outro, só Deus,
ponderador dos espíritos, a conhece. Por onde, o diabo explora a condição interior do homem, para
tentá-lo no vício a que este é mais inclinado.

RESPOSTA À TERCEIRA. — O demônio, embora não possa imutar a vontade, pode contudo, como já se
estabeleceu, imutar de certo modo as virtudes inferiores do homem, que, embora não coajam a
vontade, contudo a inclinam.

## Art. 3 — Se todos os pecados procedem da tentação do diabo.
(Iª IIae, q. 80, a. 4; De Maio, q. 3, a. 5).
O terceiro discute-se assim. — Parece que todos os pecados procedem da tentação do diabo.

1. — Pois, diz Dionísio, que a multidão dos demônios é a causa de todos os males, próprios e dos outros.
E Damasceno: todas as malícias e todas as imundícies são excogitadas pelo diabo.

2. Demais. — De qualquer pecador pode-se dizer o que o Senhor diz dos Judeus: Vós tendes por pai o
demônio. Ora, isto é porque pecavam por sugestão do diabo. Logo, desta sugestão vem todo pecado.

3. Demais. — Assim como os anjos são deputados à guarda dos homens, assim os demônios, à luta. Ora,
todo o bem que fazemos procede da sugestão dos bons anjos, porque mediante anjos é que recebemos
os dons divinos. Logo, também todo o mal que fazemos provém da sugestão do diabo.
Mas, em contrário, se disse: Nem todas as nossas más cogitações são excitadas pela instigação diabólica
mas às vezes nascem do movimento do nosso arbítrio.

SOLUÇÃO. — De dois modos se pode considerar uma coisa: direta e indiretamente. Indiretamente,
quando um agente causa uma disposição para determinado efeito, diz-se que é ocasional e
indiretamente a causa desse efeito; assim, se se disser que o que seca a madeira é a ocasião da
combustão da mesma. E deste modo deve-se dizer que o diabo é a causa de todos os nossos pecados,
por ter instigado o primeiro homem a pecar, donde resultou, para todo o gênero humano, inclinação
para todos os pecados. E neste sentido devem-se entender as palavras aduzidas de Damasceno e
Dionísio, na primeira objeção. — Diretamente porém considera-se causa o que obra algum efeito, de
modo direto. E então o diabo não é a causa de todos os pecados, pois nem todos são cometidos à
instigação dele, mas muitos procedem da liberdade do arbítrio e da corrupção da carne. Porque, como
diz Orígenes, mesmo que o diabo não existisse, os homens teriam desejo de alimentos, dos atos
venéreos e coisas semelhantes; ora, em relação a tais coisas há muito desregramento se tais desejos
não forem refreados pela razão, e, máxime, suposta a corrupção da natureza. Ora, refrear e ordenar
esses desejos cai sob a alçada do livre arbítrio. Por onde, não é necessário que todos os pecados
procedam da instigação diabólica. Mas se porventura alguns procederem dessa instigação para os
cometer, os homens são atualmente enganados pelas mesmas blandícias com que o foram os nossos
primeiros pais, como diz Isidro.
Donde se deduz a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Pecados perpetrados sem instigação diabólica tornam, contudo, os homens
filhos do diabo, enquanto o imitam a ele, o primeiro pecador.

RESPOSTA À TERCEIRA. — O homem pode por si mesmo cair em pecado; mas, não pode obter mérito
senão pelo auxílio divino, dado ao homem pelo ministério dos anjos. E por isso os anjos cooperam para
todos os nossos bens, mas nem todos os nossos pecados procedem da sugestão dos demônios, embora
não haja nenhum gênero de pecados que às vezes não provenham dessa sugestão.

## Art. 4 — Se os demônios podem seduzir os homens com milagres verdadeiros.
(Supra. q. 110. a. 4, ad. 2; IIª IIae, q. 178 a. 1, ad. 2; a. 2; II Sent., dist. VII, q. 3, a. 1; De Pot., q. 6, a. 5; In
Matth., cap. XXIV; II Thess., cap. II, lect. II).
O quarto discute-se assim. — Parece que os demônios não podem seduzir os homens com milagres
verdadeiros.

1. — Pois, os demônios terão especial influência nas obras do Anticristo. Mas diz o Apóstolo: A vinda
dele é por obra de Satanás com todo o poder, e com sinais e prodígios mentirosos. Logo, com maior
razão, em outros tempos, os fatos demoníacos maravilhosos não passarão de mentiras.

2. Demais. — Os verdadeiros milagres se realizam com alguma imutação nos corpos. Ora, os demônios
não podem mudar a natureza de um corpo em outro: pois, diz Agostinho: Por nenhuma razão
acreditarei que o corpo humano possa vir a ser verdadeiramente convertido em corpo de animal, por
arte ou poder dos demônios. Logo, estes não podem fazer verdadeiros milagres.

3. Demais. — O argumento que pode referir-se a dois termos opostos não tem eficácia. Se pois milagres
verdadeiros pudessem ser feitos pelos demônios para persuadir à falsidade, não poderiam ser eficazes
para confirmar a verdade da fé. O que é inadmissível, conforme à Escritura: Cooperando com eles o
Senhor, e confirmando a sua pregação com os milagres que a acompanhavam.
Mas, em contrário, diz Agostinho: pelas artes mágicas se fazem milagres muito semelhantes aos feitos
pelos servos de Deus.

SOLUÇÃO. — Como resulta do já dito, milagres, em sentido próprio, não nos podem fazer os demônios
nem nenhuma criatura, mas só Deus; porque o milagre propriamente dito vai contra a ordem de toda a
natureza, cuja ordem compreende todas as virtudes criadas. Porém, chama-se milagre, em sentido lato,
ao que excede à faculdade e à razão humanas. E assim os demônios podem fazer milagres, que enchem
os homens de estupefação, porque excedem à faculdade e ao conhecimento destes. Pois também
qualquer homem, quando faz algo que excede a faculdade e o conhecimento de outro, provoca o
espanto deste, com a sua obra, de modo que parece, de certo modo, fazer milagre. Mas devemos saber
que, embora essas obras dos demônios, que nos parecem milagres, não realizem a verdadeira essência
destes, contudo eles fazem às vezes coisas verdadeiras. Assim os mágicos do Faraó, por virtude dos
demônios fizeram serpentes e rãs verdadeiras. E, como diz Agostinho, quando caiu o fogo do céu e de
um ímpeto consumiu a família de jó, com seus rebanhos; e um turbilhão destruiu-lhe a casa e lhe matou
os filhos, essas foram obras de Satanás e não fantasmagorias.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho, as obras do Anticristo podem se
chamar sinais de mentira, quer porque há-de enganar com fantasmagorias os sentidos mortais, de
modo a parecer realizar o que não realiza; quer porque, sendo os prodígios verdadeiros, arrastarão
porém ao engano os que neles crerem.

RESPOSTA À SEGUNDA. — Como já se disse antes, a matéria corpórea não obedece à vontade dos anjos
bons ou maus, de modo que os demônios possam pela sua virtude transmutar a matéria de uma forma
para outra. Mas podem aplicar certos germes existentes nos elementos do mundo, para realizar tais
efeitos, como diz Agostinho. Por onde deve-se dizer, que todas as transmutações das coisas corpóreas,
que podem ser feitas por algumas virtudes naturais, entre as quais estão os referidos germes, podem
ser feitas por operação dos demônios, com aplicação desses germes; assim quando certas coisas são
transmutadas em serpentes ou rãs, seres que podem ser gerados por putrefação. Porém as
transmutações das coisas corpóreas, que não podem ser feitas por virtude da natureza, de nenhum
modo podem ser realizadas por operação dos demônios, na verdade da expressão. E se às vezes algo de
tal parece ser feito, por operação dos demônios, isso não se dá real, mas só aparentemente, o que pode
acontecer de duplo modo. De um, interiormente; assim o demônio pode mudar a fantasia do homem e
mesmo os sentidos corpóreos, de maneira que uma coisa pareça diversa do que é, como já se disse. E
isto também se pode considerar como feito às vezes por virtude de certos agentes corpóreos. De outro
modo, exteriormente. Pois assim como o demônio pode formar, do ar, um corpo de qualquer forma ou
figura, de modo que, assumindo-o, apareça visivelmente, pela mesma razão pode revestir qualquer
coisa de uma forma corpórea, de modo que seja visto, na figura desta. E é o que diz Santo Agostinho: a
fantasia do homem, mesmo quando este pensa ou sonha, varia conforme os inumeráveis gênios das
causas e, como corporificada na imagem de algum animal, aparece aos outros sentidos entorpecidos. O
que significa, não que a virtude fantástica do homem, ou uma espécie da mesma, corporificada e com
ela numericamente idêntica, seja manifestada aos sentidos de outrem, mas que o demônio, que forma
uma certa espécie, na fantasia de um homem, também pode apresentar outra espécie semelhante aos
sentidos de outro homem.

RESPOSTA À TERCEIRA. — Como diz Agostinho, quando os magos fazem as mesmas causas que os
santos, fazem-nas com fim e por direito diverso. Pois aqueles as fazem, buscando a glória própria; estes,
a de Deus. Aqueles, por um como comércio privado; estes porém por pública ordem e mandado de
Deus, a quem estão sujeitas todas as criaturas.

## Art. 5 — Se o demônio vencido fica por isso impedido de atacar.
(II Sent., dist. VI, a. 6).
O quinto discute-se assim. — Parece que o demônio vencido nem por isso fica impedido de atacar.

1. — Pois, Cristo venceu eficacissimamente o seu tentador. Mas este depois atacou-o de novo, incitando
os Judeus a que o matassem. Logo, não é verdade que o diabo vencido cessa de atacar.

2. Demais. — Infringir uma pena ao que sucumbiu na luta é incitá-lo lutar mais fortemente. Ora, isto não
é próprio da misericórdia de Deus. Logo, os demônios vencidos não ficam impedidos de atacar.
Mas, em contrário, diz a Escritura: Então o demônio deixou-o, i. é, a Cristo que o havia vencido.

SOLUÇÃO. — Certos dizem que o demônio vencido por um homem não pode mais tentá-lo, nem quanto
ao mesmo pecado, nem quanto a outro. Outros porém dizem que podem tentar outros homens, mas
não o mesmo; e isto é mais provável se se entender como referido a um determinado tempo. Por onde,
no Evangelho se diz que, consumada toda tentação, o diabo abandonou a Cristo; por algum tempo. E a
razão disto é dupla. Uma se funda na divina clemência; pois, como Crisóstomo diz, o diabo não tenta os
homens pelo tempo que quer, mas pelo que Deus permite; e Deus, depois de lhe ter permitido tentar,
por um tempo, repele-o, por causa da fraqueza da nossa natureza. A outra razão se funda na astúcia do
diabo; e por isso Ambrósio diz, que o diabo teme instar porque evita o mais possível ser derrotado. Mas
que às vezes o diabo volte a tentar o que já abandonara, é claro pelo passo do Evangelho: Voltarei para
minha casa, donde saí.
Donde se deduzem as RESPOSTAS ÀS OBJEÇÕES.