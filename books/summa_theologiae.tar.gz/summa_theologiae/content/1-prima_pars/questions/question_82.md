# Questão 82: Da vontade.
Em seguida deve-se tratar da vontade. Sobre a qual cinco artigos se discutem:

## Art. 1 — Se a vontade deseja alguma coisa necessariamente.
(Iª IIae, q. 10, a. 1; II Sent., dist. ., q. 22, a. 5; De Malo, q. 6).
O primeiro discute-se assim. ― Parece que a vontade não deseja nada necessariamente.

1. ― Pois, como diz Agostinho, se alguma coisa é necessária não é voluntária. Ora, tudo o que a vontade
deseja é voluntário. Logo, ela nada deseja necessariamente.

2. Demais. ― As potências racionais, segundo o Filósofo, se exercem sobre termos opostos. Ora, a
vontade é uma potência racional, pois, como se disse, ela reside na razão. Logo, ela se exerce sobre
termos opostos e, portanto, não está determinada, necessariamente, a nada.

3. Demais. ― Pela vontade somos senhores dos nossos atos. Ora, não o somos do que é necessário.
Logo, o ato da vontade não pode ter necessidade.
Mas, em contrário, diz Agostinho, que todos, com vontade una, desejam a beatitude. Ora, se este desejo
não fosse necessário, mas contingente, falharia, pelo menos em alguns casos. Logo a vontade quer
alguma coisa, necessariamente.

SOLUÇÃO. ― O vocábulo ― necessidade ― tem muitas significações. Assim, é necessário o que não
pode deixar de ser; podendo tal convir a uma coisa, quer por princípio intrínseco ou material, como
quando dizemos que todo composto de elementos contrários deve necessariamente corromper-se;
quer pelo princípio formal, como quando dizemos ser necessário que todo triângulo tenha três ângulos
iguais e dois retos. E essa necessidade se chama natural e absoluta. ― De outro modo, diz-se que uma
coisa não pode deixar de ser, por um princípio intrínseco, que é fim ou agente. Fim, como quando
alguém não pode, sem este, conseguir ou bem conseguir qualquer outro fim; assim, diz-se que o
alimento é necessário à vida e um cavalo, para uma viagem. E essa é a necessidade de fim, chamada
também, às vezes, utilidade. Porém a necessidade pode provir do agente, como quando alguém é por
ele coagido de modo a não ser possível agir em sentido contrário. E essa é à vontade de coação, que
repugna, absolutamente, à vontade, pois, denominamos violento o que vai contra a inclinação de um
ser. Ora, o movimento mesmo da vontade é uma certa inclinação para alguma coisa. Por onde, assim
como se chama natural ao que é conforme, à inclinação da natureza, assim se chama voluntário ao que
é conforme a inclinação da vontade. Ora, como é impossível a simultaneidade do violento e do natural,
assim também o é que absolutamente, o coagido ou violento seja voluntário. Porém, a necessidade de
fim não repugna à vontade, quando esta não pode obtê-lo senão de um modo; assim, o desejo de
atravessar o mar faz com que a vontade queira, necessariamente, o navio. Semelhantemente, a
necessidade natural também não repugna à vontade. Antes, é necessário que, assim como o intelecto
necessariamente adere aos primeiros princípios, assim a vontade adira necessariamente ao último fim,
que é a beatitude. Pois, o fim está para a operação, como o princípio para a especulação, segundo já se
disse. Por onde, é forçoso que o que convém a um ser, natural e imovelmente, seja o fundamento e o
princípio de todas as demais conveniências; porque a natureza da coisa é, em cada ser, o que é primário,
todo movimento procedendo de algum ser imóvel.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A expressão de Agostinho deve-se entender do que é
necessário pela necessidade de coação. Pois, a necessidade natural não tira a liberdade da vontade,
como ele próprio o diz, no mesmo livro.

RESPOSTA À SEGUNDA. ― A vontade pela qual alguém quer naturalmente mais corresponde ao
intelecto dos princípios naturais do que à razão, que se exerce sobre as oposições. Por onde, desse
ponto de vista, é uma potência mais intelectual do que racional.

RESPOSTA À TERCEIRA. ― Somos senhores dos nossos atos enquanto podemos escolher tal coisa ou tal
outra. Ora, a eleição não se refere ao fim, mas ao que leva para o fim, como se disse. Por onde, o desejo
do fim último não é daqueles de que somos senhores.

## Art. 2 — Se a vontade quer necessariamente tudo quanto quer.
(Iª IIae, q. 10, a. 2; II Sent., dist. XXV, a. 2; De Verit., q. 22, a. 6; De Malo, q. 3, a. 3; q. 6; I Periherm., lect

XIV).
O segundo discute-se assim. ― Parece que a vontade quer, necessariamente, tudo quanto quer.

1. ― Pois, diz Dionísio, que o mal está fora do alcance da vontade. Logo, a vontade busca,
necessariamente, o bem a si proposto.

2. Demais. ― O objeto da vontade está para a mesma, como o motor, para o móvel. Ora, o movimento
do móvel resulta, necessariamente, do motor. Logo, o objeto da vontade move-se necessariamente.

3. Demais. ― Assim como o apreendido pelo sentido é o objeto do apetite sensitivo; assim o apreendido
pelo intelecto é o objeto do apetite intelectivo, chamado vontade. Ora, o apreendido pelo sentido
move, necessariamente, o apetite sensitivo, conforme o dito de Agostinho: os animais são movidos
pelas coisas vistas. Logo, o apreendido pelo intelecto move, necessariamente, à vontade.
Mas, em contrário, diz Agostinho que pela vontade pecamos e por ela vivemos bem; e, então ela se
exerce sobre termos opostos. Logo, não quer, necessariamente, tudo o que quer.

SOLUÇÃO. ― A vontade não quer, necessariamente, tudo o que quer. E isso se evidencia considerando
que, assim como o intelecto adere aos primeiros princípios natural e necessariamente, assim a vontade
adere ao último fim, como já se disse (a. 2). Ora, há certos inteligíveis que não têm conexão necessária
com os primeiros princípios; assim, as proposições contingentes, de cuja remoção não resulta a remoção
dos primeiros princípios. E a essas o intelecto não assente, necessariamente. Há, porém proposições
necessárias, que têm conexão necessária com os sobreditos princípios; assim, as conclusões
demonstráveis, de cuja remoção resulta a remoção dos primeiros princípios. E, a esses, o intelecto
assente necessariamente, conhecida que seja a conexão necessária das conclusões com os princípios,
pela dedução da demonstração; não assente, porém, necessariamente, antes de conhecer, pela
demonstração, a necessidade da conexão. Ora, o mesmo se passa com a vontade. Assim, há, certos bens
particulares sem conexão necessária com a beatitude, porque, sem eles, pode um ser feliz. E a tais bens
a vontade não adere necessariamente. Há outros, porém que têm com ela conexão necessária e pelos
quais o homem adere a Deus, em quem só consiste a verdadeira beatitude. Contudo, antes de ser
demonstrada, pela certeza da visão divina, a necessidade de tal conexão, a vontade não adere,
necessariamente, a Deus nem às coisas de Deus. Mas à vontade de quem vê a Deus em essência adere a
Ele necessariamente, assim como, nesta vida, queremos necessariamente, ser felizes. Por onde é claro,
que a vontade não quer necessariamente tudo o que quer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A vontade não pode buscar nada senão sob a noção de
bem. Ora, como este é múltiplo, ela, por isso, não fica determinada a um só, necessariamente.

RESPOSTA À SEGUNDA. ― O motor causa, necessariamente, o movimento no móvel, só quando o
poder do motor excede o móvel, de modo que toda a sua possibilidade fique sujeita ao motor. Ora,
como a possibilidade da vontade é em relação ao bem universal e perfeito, a possibilidade dela não fica
totalmente sujeita a nenhum bem particular. E, portanto, não é movida por este, necessariamente.

RESPOSTA À TERCEIRA. ― A virtude sensitiva não compara noções diversas, como a razão, mas
apreende, absolutamente o seu objeto como uno. E por isso, por esse objeto uno, move,
determinadamente, o apetite sensitivo. Mas a razão, comparando muitas noções, o apetite intelectivo
ou vontade pode ser movido por muitos objetos, e não por um só, necessariamente

## Art. 3 — Se a vontade é potência mais elevada que o intelecto.
(A. seq., ad 1; IIª IIae, q. 23, a. 6, ad1; II Sent., dist. XXV, a. 2, ad 4; III, dist. XXVII, q. 1, a. 4; III Cont. Gent.,
cap. XXVI; De Verit., q. 22, a. 2; De Virt., q. 2, a. 3 ad 12, 13).
O terceiro discute-se assim. ― Parece que a vontade é potência mais elevada que o intelecto.

1. ― Pois, o bem é o fim e o objeto da vontade. Ora, o fim é a primeira e a mais alta das causas. Logo, a
vontade é a primeira e a mais elevada das potências.

2. Demais. ― Vemos que as coisas naturais passam de imperfeitas a perfeitas. E isso também vemos nas
potências da alma, em que se passa do sentido para o intelecto, que é mais nobre. Ora, há uma
passagem natural do ato do intelecto para o da vontade. Logo, a vontade é potência mais perfeita e
mais nobre que o intelecto.

3. Demais. ― Os hábitos são proporcionados às potências, como as perfeições, aos perfectíveis. Ora, o
hábito pelo qual a vontade se aperfeiçoa, que é a caridade, é mais nobre que aqueles pelos quais se
aperfeiçoa o intelecto; pois diz a Escritura (Cor 13, 2): Se eu conhecer todos os mistérios e se tiver toda a
fé e não tiver caridade, não sou nada. Logo, a vontade é potência mais elevada que o intelecto.
Mas, em contrário, o Filósofo ensina que a potência altíssima da alma é o intelecto.

SOLUÇÃO. ― A eminência de uma coisa em relação à outra pode considerar-se sob duplo aspecto:
absoluta e relativamente. Absolutamente, quando se considera uma coisa tal qual ela é; relativamente,
quando se diz que ela é tal, por comparação com outra.
Assim, considerados o intelecto e a vontade em si mesmos, resulta que o primeiro é mais eminente; o
que bem se verá, comparando entre si os seus objetos. Pois, o objeto do intelecto é mais simples e
absoluto que o da vontade, porque é a noção mesma do bem desejável; ao passo que o objeto da
vontade é o bem desejável, cuja noção está no intelecto. Ora, quanto mais um objeto é simples e
abstrato, tanto mais é, em si, nobre e elevado. Por onde, o objeto do intelecto é mais elevado que o da
vontade. Ora, como é a relação com o objeto que determina a essência própria de uma potência, segue-
se que o intelecto, em si e absolutamente, é mais elevado e nobre que à vontade.
Relativamente, porém, e por comparação, com outra coisa, resulta que, às vezes, a vontade é mais
elevada que o intelecto, por consistir o seu objeto em algo de mais elevado que o objeto do intelecto.
Assim, se dissesse que o ouvido é, relativamente, mais nobre que a vista, por ser o objeto, de que
provém um som, mais nobre que o que tem a cor; embora, em si mesma, seja a cor mais nobre e
simples que o som. Ora, como se disse antes (q. 16, a. 9; q. 27, a. 4), a ação do intelecto consiste em a
noção da coisa inteligida nele residir; ao passo que a ação da vontade se completa pela sua inclinação à
coisa como em si mesma é. E por isso o Filósofo diz, que o bem e o mal, objetos da vontade, estão nas
coisas; enquanto que o verdadeiro e o falso, objetos do intelecto,estão na mente. Por onde,
comparando: quanto mais a coisa, em que consiste o bem, for mais nobre que a alma mesma, na qual
reside à noção inteligida, tanto a vontade será mais elevada que o intelecto. Porém, quanto mais a
coisa, em que consiste o bem, for inferior à alma, também, por comparação com tal coisa, o intelecto é
mais elevado que à vontade. Por isso, melhor é o amor, que o conhecimento de Deus; e, ao contrário,
melhor é o conhecimento, que o amor das coisas materiais. Todavia, absolutamente, o intelecto é mais
nobre que à vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A noção de causa se deduz da comparação de uma coisa
com outra; e, de tal comparação, deduz-se que a noção do bem é a principal. Mas a verdade tem
significação mais absoluta e exprime a noção do próprio bem. Por onde, o bem é uma espécie de
verdade. Mas, por sua vez, também a verdade é uma espécie de bem, enquanto o intelecto é uma
realidade e tem, como fim, a verdade. E, entre os demais fins, este é o mais excelente, como o intelecto
o é, entre as outras potências.

RESPOSTA À SEGUNDA. ― O que é anterior, na geração e no tempo, é mais imperfeito; pois, num
mesmo ser, a potência precede ao ato, temporalmente, e a imperfeição, à perfeição. Mas o que é, em si
mesmo e na ordem da natureza, anterior, é mais perfeito; assim, o ato é anterior à potência. E deste
modo, o intelecto é anterior à vontade, como o motor, ao móvel, e o ativo, ao passivo; pois, é o bem
inteligido que move a vontade.

RESPOSTA À SEGUNDA. ― Essa razão procede, em relação à vontade comparada com o que é superior
à alma; pois, pela virtude da caridade é que amamos a Deus.

## Art. 4 — Se a vontade move o intelecto.
(Iª IIae, q. 9, a. 1; II Cont. Gent., cap. XXVI; De Verit., q. 22, a. 12; De Malo, q. 6).
O quarto discute-se assim. ― Parece que a vontade não move o intelecto.

1. ― Pois o motor é mais nobre que o movido e anterior a este, porque é agente e o agente é mais
nobre que o paciente, como diz Agostinho e o Filósofo. Ora, o intelecto tem prioridade sobre a vontade
e é mais nobre que ela, como acima se disse (a. 3). Logo, ela não move o intelecto.

2. Demais. ― Só por acidente talvez é que o movido move o motor. Ora, o intelecto move a vontade,
porque o desejável apreendido pelo intelecto é motor não movido; ao passo que o apetite é motor
movido. Logo, o intelecto não é movido pela vontade.

3. Demais. ― Não podemos querer nada que não seja inteligido. Se, portanto, à vontade, querendo o
inteligir, é quem o provoca, será necessário que também a esse querer preceda outro inteligir, e a este,
outro querer, e assim até ao infinito, o que é impossível. Logo, a vontade não move o intelecto.
Mas, em contrário, Damasceno diz, que em nós está o conhecer ou não qualquer arte que quisermos.
Ora, alguma coisa está em nós pela vontade, ao passo que conhecemos as artes pelo intelecto. Logo, a
vontade move o intelecto.

SOLUÇÃO. ― De dois modos se diz que uma coisa move. ― Como fim, como quando se diz que o fim
move a causa eficiente. E, deste modo, o intelecto move a vontade, porque o bem inteligido é o objeto
dela e a move, como fim. ― De outro modo, como agente; assim, o alterante move o alterado e o
impelente, o impelido. E, desta maneira, a vontade move o intelecto e todas as virtudes da alma, como
diz Anselmo (Eadmeros). E a razão é que, em todas as potências ativas ordenadas, a potência que visa o
fim universal move as que visam fins particulares. O que se vê tanto nas coisas naturais como nas
políticas. Assim, o céu, que causa a conservação universal dos seres susceptíveis de geração e de
corrupção, move todos os corpos inferiores, dos quais cada um trata da conservação da própria espécie
ou mesmo, do indivíduo. Também o rei, que visa o bem comum do reino todo, move pelo seu império
cada um dos prepostos das cidades, que se esforçam por conservar o regime em cada uma delas. Ora, o
objeto da vontade é o bem e o fim, em comum; e cada potência respeita um bem próprio, que lhe é
conveniente; assim, a visão, a percepção da cor e o intelecto, o conhecimento da verdade. Por onde, à
vontade, a modo de agente, move todas as potências da alma para os atos próprios delas, excetuando
as virtudes naturais da parte vegetativa, independentes do nosso arbítrio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O intelecto pode ser considerado sob duplo aspecto;
como apreensivo do ente e da verdade universal; e como uma realidade e uma potência particular,
tendo um determinado ato. E, semelhantemente, a vontade também pode ser considerada sob duplo
aspecto: em relação à comunidade do seu objeto, como apetitiva do bem comum; e como uma
determinada potência da alma, tendo um determinado ato. Se, pois, se comparar o intelecto com a
vontade, quanto à noção de comunidade dos objetos de ambos, então, como já se disse antes (a. 3), o
intelecto é, em si, mais elevado e mais nobre que à vontade. Se porém considerarmos o intelecto e a
vontade, aquele quanto à comunidade do seu objeto, e esta como uma determinada potência, então, o
intelecto ainda é mais elevado que à vontade e tem prioridade sobre ela; porque, nas noções de ente e
de verdade, apreendidas pelo intelecto, está contida a própria vontade com o seu ato e o seu objeto.
Por onde, o intelecto intelige à vontade com o seu ato e o seu objeto, bem como as demais coisas
inteligidas em especial, como a pedra ou a madeira, que se contêm na noção comum de ente e de
verdadeiro. Se, porém, for considerada a vontade, quanto à essência comum do seu objeto, que é o
bem, e o intelecto, como uma realidade e uma potência especial, então, em a noção comum do bem
está contido o intelecto, como algo de especial, e o inteligir, com o seu objeto, que é a verdade, sendo
cada um bem especial. E, sob este aspecto, a vontade é mais elevada que o intelecto e pode movê-lo.
Por onde se vê a razão por que essas potências; pelos seus atos, se incluem uma na outra; pois, o
intelecto intelige o querer da vontade; e esta quer o inteligir do intelecto. E, por semelhante razão, o
bem está contido em a noção do verdadeiro, como um certo verdadeiro inteligido; e o verdadeiro, em a
noção do bem, como um certo bem desejado.

RESPOSTA À SEGUNDA. ― O intelecto move a vontade diferentemente do modo pelo qual a vontade
move o intelecto, como já se disse.

RESPOSTA À TERCEIRA. ― Não é preciso proceder até ao infinito, mas deve-se parar no intelecto como
no primeiro termo. Pois é necessário que a apreensão preceda a qualquer movimento da vontade; mas
nem a toda apreensão precede um movimento da vontade, pois, o princípio do conselho e da intelecção
é um princípio intelectivo mais elevado que o nosso intelecto e que é Deus, como o reconhece
Aristóteles, mostrando, desse modo, que não é preciso proceder até o infinito.

## Art. 5 — Se se devem distinguir o irascível e o concupiscível, no apetite superior, que é a vontade.
(Supra, q. 59, a. 4; III Sent., dist. XVII, a. 1. qª 3; De Verit., q. 25, a. 3; De Anima, lect. XIV).
O quinto discute-se assim. ― Parece que se devem distinguir o irascível e o concupiscível no apetite
superior, que é à vontade.

1. ― Pois, virtude concupiscível é expressão derivada de concupiscência, e, irascível, de ira. Ora, há uma
concupiscência, que não pode pertencer ao apetite sensitivo, mas só ao intelectivo, que é à vontade;
assim, a concupiscência da sabedoria, da qual diz a Escritura (Sb 6, 21): O desejo da sabedoria conduz ao
reino eterno. Há também uma ira, que não pode pertencer ao apetite sensitivo, mas só ao intelectivo; e
assim, iramo-nos contra os vícios, pelo que Jerônimo nos adverte a que possuamos o ódio dos vícios, no
irascível. Logo, devem-se distinguir o irascível e o concupiscível, no apetite intelectivo, como no
sensitivo.

2. Demais. ― Como se diz comumente, a caridade existe no concupiscível; a esperança, porém, no
irascível. E não podem existir no apetite sensitivo, por não terem objetos sensíveis, mas inteligíveis.
Logo, deve-se colocar o concupiscível e o irascível na parte intelectiva.

3. Demais. ― Diz o livro Do espírito e da alma que a alma, antes de se unir com o corpo, tem essas
potências, a saber, a irascível e a concupiscível, bem como a racional. Ora, nenhuma potência da parte
sensitiva pertence só à alma, mas, ao conjunto, como já se disse antes (q. 77, a. 5, 8). Logo, o irascível e
o concupiscível existem na vontade que é apetite intelectivo.
Mas, em contrário, diz Gregório Nisseno, que a parte irracional da alma se divide em desiderativo e
irascível, e o mesmo diz Damasceno. E o Filósofo: a vontade está na razão; porém, na parte irracional da
alma estão a concupiscência e a ira ou o desejo e o ânimo.

SOLUÇÃO. ― O irascível e o concupiscível não são partes do apetite intelectivo, chamado vontade. Pois,
como já ficou dito (q. 59, a. 4; q. 79, a. 7), a potência ordenada para algum objeto, sob um aspecto
comum, não se diversifica pelas diferenças especiais contidas nesse aspecto comum. Assim, pela vista se
referir ao visível, sob o aspecto colorido, não se multiplicam as potências visívas pelas diversas espécies
de cores. Se porém existisse alguma potência, que tivesse como objeto o branco como tal, e não como
um colorido, seria ela diversa da potência que tivesse como objeto o negro como tal. Ora, o apetite
sensitivo não respeita o aspecto comum do bem, porque o sentido não pode apreender o universal. Por
onde, pelos diversos aspectos particulares dos bens, diversificam-se as partes do apetite sensitivo.
Assim, o concupiscível se refere ao aspecto do bem enquanto deleitável ao sentido e conveniente à
natureza. O irascível, de outro lado, se refere ao aspecto do bem, enquanto repele e impugna o que é
nocivo. Ao passo que a vontade se refere ao bem segundo o aspecto comum deste. Por onde, nela, que
é apetite intelectivo, não se diversificam nenhumas potências apetitivas, de maneira a haver, nesse
apetite intelectivo, uma potência irascível e outra, concupiscível; do mesmo modo que, por parte do
intelecto, não se multiplicam as virtudes apreensivas, embora se multipliquem por parte do sentido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O amor, a concupiscência, e afetos semelhantes, têm
dupla acepção. Ora, uma acepção comum, como paixões que vão acompanhadas de certa comoção do
ânimo; e, nessa acepção, existem só no apetite sensitivo. Numa outra acepção, significam o simples
afeto, sem paixão ou comoção do ânimo e, então, são atos da vontade e se atribuem também aos anjos
e a Deus. Mas, nesta acepção, não pertencem a potências diversas, mas só a uma, chamada vontade.

RESPOSTA À SEGUNDA. ― A vontade em si mesma pode-se chamar irascível, enquanto quer impugnar
o mal, não pelo ímpeto da paixão, mas pelo juízo da razão; e, do mesmo modo, pode chamar-se
concupiscível, pelo desejo do bem. E assim, a caridade e a esperança estão no irascível e no
concupiscível, i. é., na vontade, enquanto esta se ordena para tais atos.
E, deste modo, pode-se entender o passo que o irascível e o concupiscível estão na alma, antes que ela
se una ao corpo; contanto que se refira à ordem da natureza e não à do tempo; embora não seja
necessário dar fé às palavras do livro citado.
Por onde é clara a RESPOSTA À TERCEIRA OBJEÇÃO.