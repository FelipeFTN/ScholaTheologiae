# Questão 58: Do modo do conhecimento angélico.
Em seguida, devemos tratar do modo do conhecimento angélico. E, sobre este ponto, sete artigos se
discutem:

## Art. 1 — Se o intelecto angélico às vezes está em potência.
(Ia IIae, q. 50, a. 6; II Cont. Gent., cap. XCVII, XCVIII, CI; De Malo, q. 16, a. 56)
O primeiro discute-se assim. – Parece que o intelecto angélico às vezes está em potência.

1. — Pois o movimento é o ato do existente em potência, como diz Aristóteles. Ora, as mentes
angélicas, inteligindo, movem-se, como diz Dionísio. Logo, às vezes, estão em potência.

2. Demais. — Como o desejo busca o que não se tem mas que se pode ter, quem deseja inteligir alguma
coisa está em potência em relação a ela. Mas a Escritura diz (1 Pd 1, 12): Ao qual os mesmos anjos
desejam ver. Logo, a inteligência angélica, às vezes, está em potência.

3. Demais. — No livro Das causas se diz que a inteligência intelige ao modo da sua substância. Mas a
substância angélica tem, de mistura, algo de potencial. Logo, às vezes, intelige em potência.
Mas, em contrário, diz Agostinho que os anjos, desde que foram criados, gozam, por uma santa e pia
contemplação, da eternidade mesma do Verbo. Ora, o intelecto que contempla não está em potência,
mas em ato. Logo, o intelecto angélico não é potencial.

SOLUÇÃO. — Como diz o Filósofo, de dois modos pode o intelecto estar em potência. Um é o estado em
que se encontra antes de aprender ou descobrir, i. é., antes de ter o hábito da ciência. Outro é o em que
já tem a ciência, mas sem a atualizar. — Ora, do primeiro modo, o intelecto angélico nunca está em
potência em relação às coisas que o seu conhecimento natural pode alcançar. Pois, assim como os
corpos superiores, i. é, os celestes não têm, quanto à existência, uma potência que não seja completada
pelo ato, assim as inteligências celestes, i. é, angélicas, não têm nenhuma potência inteligível que não
seja totalmente completada pelas espécies inteligíveis conaturais. Mas, quanto ao que lhes for
divinamente revelado, nada impede que lhes seja potencial o intelecto; pois, assim, também os corpos
celestes estão, às vezes, em potência a serem iluminados pelo sol. — Do segundo modo, porém, o
intelecto angélico pode estar em potência em relação às coisas que conhece por conhecimento natural;
pois, nem todas as que assim conhece sempre atualmente as considera. Todavia, o conhecimento que
tem do Verbo e das coisas vistas neste, nunca é potencial, pois o Verbo é contemplado sempre e
atualmente, bem como as coisas nele vistas. Pois esta visão é a beatitude dos anjos; e a beatitude não
consiste num hábito, mas num ato, como diz o Filósofo

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O movimento, na expressão citada, não se entende
como o ato do imperfeito, i. é, do que existe em potência, mas como o ato do perfeito, i. é, do que
existe em ato. E assim, o inteligir e o sentir se chamam movimentos, como diz Aristóteles

RESPOSTA À SEGUNDA. — Esse desejo dos anjos não exclui a coisa desejada mas o tédio que dela
pudessem ter. — Ou se diz, que desejam a visão de Deus, em respeito a novas revelações que dele
recebem, conforme o oportuno às suas atividades.

RESPOSTA À TERCEIRA. — Na substância do anjo não há nenhuma potência desprovida do ato. E
semelhantemente, nem o intelecto angélico está em potência de modo a ficar desprovido do ato.

## Art. 2 — Se o anjo pode inteligir simultaneamente muitas coisas.
(II Sent., dist. III, part. II, q. 2, a. 4; II Cont. Gent., cap. CI; De Verit., q. 8, a. 14)
O segundo discute-se assim. — Parece que o anjo não pode inteligir simultaneamente muitas coisas.

1. — Pois o Filósofo diz que se podem saber muitas coisas, mas inteligir só o que é uno.

2. Demais. — Nada é inteligido senão porque o intelecto é informado pela espécie inteligível, assim
como o corpo o é pela figura. Ora, um mesmo corpo não pode ser informado por diversas figuras. Logo,
um mesmo intelecto não pode inteligir simultaneamente diversos inteligíveis.

3. Demais. — Inteligir é um movimento. Ora, nenhum movimento termina em termos diversos. Logo,
não pode o intelecto inteligir simultaneamente muitas coisas.
Mas, em contrário, diz Agostinho: a potência espiritual da mente angélica fácil e simultaneamente
compreendo tudo o que quiser

SOLUÇÃO. — Assim como a unidade do movimento supõe a do seu termo, assim a unidade da operação
supõe a do seu objeto. Ora, certas coisas, como as partes de um contínuo, podem ser consideradas
como só uma ou como várias. Assim, considerando cada parte de per si, são muitas e, por isso, não são
apreendidas pelo sentido e pelo intelecto por uma só operação e simultaneamente. De outro modo, as
partes podem ser consideradas como formando uma unidade no todo e, então, são conhecidas
simultaneamente por uma só operação, tanto pelo sentido como pelo intelecto, por ser considerado o
contínuo, na sua totalidade, como diz Aristóteles. E, assim, também o nosso intelecto intelige
simultaneamente o sujeito e o predicado como partes de uma mesma proposição e como duas coisas
comparadas mas que convém na mesma comparação. Por onde se vê que muitas coisas, enquanto
distintas, não podem ser simultaneamente inteligidas; mas o podem enquanto unificadas num mesmo
inteligível. Ora, uma coisa é inteligível em ato quando a sua similitude está no intelecto. Portanto, todas
as coisas que podem ser conhecidas por uma mesma espécie inteligível são conhecidas como um só
inteligível e, logo, simultaneamente. As que, porém, são conhecidas por diversas espécies inteligíveis
são apreendidas como diversos inteligíveis. Assim, pois, os anjos, quando conhecem as coisas pelo
Verbo, as conhecem a todas por uma só espécie inteligível, que é a essência divina. E, portanto, por tal
conhecimento conhecem a todas simultaneamente; assim como também na pátria os nossos
pensamentos não serão volúveis, indo e vindo constantemente de umas para outras coisas, mas
veremos toda a nossa ciência por um e simultâneo conspecto, como diz Agostinho. Porém, pelo
conhecimento pelo qual os anjos conhecem por espécies inatas, podem inteligir por esse
simultaneamente tudo o que conhecem, por uma mesma espécie; não assim o que conhecerem por
espécies diversas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Inteligir muitas coisas como se fossem uma só é, de
certo modo, inteligir uma só.

RESPOSTA À SEGUNDA. — O intelecto é informado pela espécie inteligível que trás em si. E por isso
pode, por uma só, intuir simultaneamente muitos inteligíveis, do mesmo modo que um corpo, por uma
só figura, pode simultaneamente assimilar-se a muitos corpos.

RESPOSTA À TERCEIRA. — Deve-se dar a mesma resposta que à primeira.

## Art. 3 — Se o anjo conhece discorrendo.
(Infra, q. 79, ad. 8; q. 85, a. 5; De Verit., q. 8, a. 15; q. 15, a. 1)
O terceiro discute-se assim. — Parece que o anjo conhece discorrendo.

1. — Pois, o discurso do intelecto consiste em conhecer uma coisa por meio de outra. Ora, os anjos
conhecem assim quando, pelo Verbo, conhecem as criaturas. Logo, o intelecto angélico conhece
discorrendo.

2. Demais. — Tudo o que pode a virtude inferior pode a superior. Ora, o intelecto humano pode silogizar
e conhecer as causas pelos efeitos, e nisso consiste o discurso. Logo, o intelecto angélico, superior na
ordem da natureza, também o pode, com maior razão.

3. Demais. — Isidoro diz que os demônios conhecem muitas coisas por experiência. Ora, o
conhecimento experimental é discursivo; pois, como diz Aristóteles, de muitas coisas memoradas
resulta uma experiência e, de muitas experiências, resulta um universal. Logo, o conhecimento dos
anjos é discursivo.
Mas, em contrário, diz Dionísio que os anjos não congregam o conhecimento divino por meio de difusos
raciocínios, nem chegam simultaneamente a esses conhecimentos especiais por algum meio comum.

SOLUÇÃO. — Como já se disse muitas vezes, os anjos têm, entre as substâncias espirituais o grau que
têm os corpos celestes entre as corpóreas; por isso, Dionísio lhes chama inteligências celestes. Ora, a
diferença entre os corpos celestes e os terrenos está nestes alcançarem a sua última perfeição pela
mudança e pelo movimento; ao passo que aqueles logo, pela própria natureza, a atingem. Assim,
também os intelectos inferiores, i. é, dos homens, por um certo movimento e discurso da operação
intelectual, atingem a perfeição e o conhecimento da verdade, passando de um objeto conhecido para
outro. Se, porém, imediatamente, pelo próprio conhecimento do princípio, tivessem como conhecidas
todas as conclusões conseqüentes, não haveria neles lugar para o discurso. Ora, é isto o que se dá com
os anjos, pois, imediatamente, vêem tudo o que podem conhecer nas coisas que primeiro naturalmente
conhecem. E por isso se chamam eles intelectuais, pois, também em nós se dizem inteligidas as coisas
imediata e naturalmente apreendidas; sendo essa a razão por que se chama intelecto ao hábito dos
primeiros princípios. Porém, as almas humanas que chegam ao conhecimento da verdade por um certo
discurso se chamam racionais; e isso nelas se dá pela debilidade da sua luz intelectual. Se, pois, tivessem
a plenitude dessa luz, como os anjos, imediatamente, no primeiro aspecto dos princípios, apreender-
lhe-iam todo o conteúdo, vendo tudo o que dele se pudesse deduzir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O discurso designa um certo movimento. Ora, todo
movimento passa de uma posição anterior para outra posterior. Daí o considerar-se como
conhecimento discursivo o passar de um primeiro objeto conhecido para outro, que era, antes,
ignorado. Se, porém, conhecido um, o outro o fosse simultaneamente, como no espelho é vista
simultaneamente a imagem da coisa, então tal conhecimento não seria discursivo. Ora, é assim que os
anjos conhecem as coisas no Verbo.

RESPOSTA À SEGUNDA. — Os anjos podendo silogizar, como conhecedores do silogismo, vêem nas
causas os efeitos e nos efeitos as causas; não, porém, que adquiram o conhecimento da verdade
desconhecida silogizando das causas para os causados e destes para aquelas.

RESPOSTA À TERCEIRA. — Admite-se experiência nos anjos e nos demônios por certa similitude,
enquanto conhecem os sensíveis presentes, sem, todavia, nenhum discurso.

## Art. 4 — Se os anjos inteligem compondo e dividindo.
(Infra, q. 85, a. 5; De Malo, q. 16, a. 6 ad 19)
O quarto discute-se assim. — Parece que os anjos inteligem compondo e dividindo.

1. — Onde há, pois, multidão de coisas inteligidas há composição dos intelectos, como diz Aristóteles.
Ora, no intelecto angélico há tal multidão, porque intelige diversas coisas por diversas espécies, e não
todas simultaneamente. Logo, há nele composição e divisão.

2. Demais. — Mais dista a afirmação da negação do que duas naturezas opostas quaisquer, porque a
distinção primeira se faz pela afirmação e negação. Ora, como se viu, o anjo não conhece quaisquer
naturezas distantes por uma, mas por várias espécies. Logo é necessário conheça, por diversas espécies,
a afirmação e a negação. Donde resulta que o anjo intelige compondo e dividindo.

3. Demais. — A linguagem é sinal de inteligência. Ora, os anjos, falando com os homens, proferem
enunciados afirmativos e negativos, que são sinais de composição e divisão no intelecto, como se vê em
muitos lugares da Sagrada Escritura. Logo, resulta que o anjo intelige compondo e dividindo.
Mas, em contrário, diz Dionísio que a virtude intelectual dos anjos resplandece pela perspícua e simples
visão da mente divina. Ora, a inteligência simples não tem composição nem divisão, como diz
Aristóteles. Logo, o anjo intelige sem composição nem divisão.

SOLUÇÃO. — Assim como no intelecto que raciocina a conclusão se liga ao princípio; assim, no que
compõe e divide, o predicado se liga ao sujeito. Se, pois, o nosso intelecto visse, imediatamente, no
próprio princípio, a verdade da conclusão, nunca inteligiria discorrendo ou raciocinando.
Semelhantemente, se o nosso intelecto tivesse conhecimento imediato, pela apreensão da qüididade do
sujeito, de tudo o que lhe pode ser atribuído ou deste removido, nunca inteligiria compondo e
dividindo, mas somente inteligindo a qüididade. Por onde é claro que da mesma causa provém o
inteligir do intelecto que discorre e do que compõe e divide; e essa está em que o intelecto não pode
ver imediatamente, na primeira apreensão de qualquer coisa, primariamente apreendida, tudo o que
nesta, pela sua virtude, está contido; o que se dá pela debilidade da nossa luz intelectual, como já se
disse. Ora, tendo o anjo luz intelectual perfeita, por ser espelho puro e claríssimo,como diz Dionísio,
resulta que ele, que não intelige raciocinando, também não intelige compondo e dividindo. Contudo,
intelige a composição e a divisão dos enunciados, como também o raciocínio dos silogismos; pois,
intelige as coisas compostas simplesmente, as móveis, imovelmente, e as materiais, imaterialmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não é qualquer pluralidade de objetos inteligidos que
causa a composição; mas a daqueles nos quais um é atribuído a outro ou deste removido. Ora, o anjo,
inteligindo a qüididade de uma coisa, simultaneamente intelige tudo o que lhe pode ser atribuído ou
dela removido. E assim, inteligindo a qüididade intelige, pelo seu uno e simples intelecto, tudo o que nós
só podemos inteligir compondo e dividindo.

RESPOSTA À SEGUNDA. — As diversas qüididades das coisas diferem menos entre si quanto à razão de
existir, do que a afirmação e a negação. Todavia, quanto à razão do conhecimento, a afirmação e
negação mais convém entre si, porque, conhecendo-se a verdade da afirmação, imediatamente se
conhece a falsidade da negação oposta.

RESPOSTA À TERCEIRA. — O exprimirem os anjos enunciados afirmativos e negativos manifesta que
eles conhecem a composição e a divisão; não, porém, que conheçam compondo e dividindo, mas
conhecendo simplesmente a qüididade.

## Art. 5 — Se no intelecto do anjo pode haver falsidade.
(III Cont. Gent., cap. CVIII; De Malo, q. 16, a. 6)
O quinto discute-se assim. — Parece que no intelecto do anjo pode haver falsidade.

1. — Pois, a protérvia implica a falsidade. Ora, nos demônios há a fantasia proterva, como diz Dionísio.

2. Demais. — A ignorância é causa de falsa apreciação. Ora, nos anjos pode haver ignorância, como diz
Dionísio. Logo, resulta que neles pode haver falsidade.

3. Demais. — Quem quer que decaia da verdade da sabedoria e tenha razão depravada tem falsidade ou
erro no seu intelecto. Ora, Dionísio o afirma dos demônios. Logo, resulta que no intelecto dos anjos
pode haver falsidade.
Mas, em contrário, diz o Filósofo que o intelecto é sempre verdadeiro. E também Agostinho: só o
verdadeiro é inteligido. Ora, os anjos nada conhecem senão inteligindo. Logo, no conhecimento angélico
não pode haver engano e falsidade.

SOLUÇÃO. — A verdade sobre este assunto depende, de certo modo, do que já antes se disse. Pois, já
ficou dito que o anjo não intelige compondo e dividindo, mas inteligindo a qüididade. Ora, o intelecto
que atinge aqüididade é sempre verdadeiro; assim como o sentido o é, quanto ao seu objeto próprio,
como diz Aristóteles. Em nós, porém, há, por acidente, engano e falsidade no inteligir a qüididade, e isso
em razão de alguma composição; quer tomemos a definição de uma coisa pela de outra coisa; quer as
partes da definição não sejam entre si coerentes, como se, p. ex., tomássemos por definição, que certo
ser é um animal quadrúpede volátil, sem que nenhum animal o seja. E isto se dá com os seres
compostos, cuja definição consta de elementos diversos, nos quais um é matéria do outro. Mas na
intelecção das qüididades simples não há falsidade, como diz Aristóteles; porque ou elas, na sua
totalidade, não são atingidas e nós nada conhecemos, ou se conhecem como são.
Assim, pois, falsidade, erro ou engano por si, não pode haver no intelecto de nenhum anjo; mas o pode
por acidente, embora de modo diferente do pelo qual existe em nós. Pois, nós, por vezes, chegamos à
intelecção da qüididade compondo e dividindo; assim quando, dividindo, ou demonstrando,
investigamos uma definição. Ora, tal não se dá com os anjos que, pela qüididade, conhecem todos os
enunciados relativos a uma determinada coisa. É, porém, claro que a qüididade da coisa pode ser um
princípio de conhecimento em relação àquilo que naturalmente lhes convém ou dela se remove; não,
porém, em relação ao que depende da ordenação sobrenatural de Deus. Portanto, os anjos bons, tendo
a vontade reta, não julgam pelo conhecimento da qüididade da coisa, daquilo que a esta pertence
sobrenaturalmente, a não ser por ordenação divina. E, por isso, nesses anjos não pode haver falsidade
ou erro. Os demônios, porém, com vontade perversa, desviando da divina sabedoria o intelecto, julgam
das coisas, por vezes, absolutamente, segundo a condição natural. E não se enganam quanto ao que
naturalmente pertence à coisa. Mas podem enganar-se quanto ao sobrenatural; como se, considerando
um homem morto, julgassem que não haveria de ressurgir; e se, vendo Cristo homem, não o julgassem
Deus.
E daqui se deduz clara a RESPOSTA ÀS OBJEÇÕES feitas de um e outro lado. — Pois, a protérvia dos
demônios vem de não se submeterem à divina sabedoria. — A ignorância, por outro lado, existe nos
anjos não em relação aos cognoscíveis naturais, mas aos sobrenaturais. Também é claro que o seu
intelecto da qüididade é sempre verdadeiro, salvo acidentalmente, enquanto, indevidamente, se ordena
a alguma composição ou divisão.

## Art. 6 — Se nos anjos há conhecimento verspertino e matutino.
(Infra q. 62, a. 1, ad 3; q. 64, a. 1, ad 3; II Sent., dist. XII, a. 3; De Verit., q. 8, a. 16; De Pot., q. 4, a. 2,
respons. Ad object; Ephes., cap. III, lect. III)
O sexto discute-se assim. — Parece que nos anjos não há conhecimento vespertino nem matutino.

1. — Pois, a tarde e a manhã vão de mistura com as trevas. Ora, no conhecimento do anjo nenhuma
treva há, porque não há nele erro nem falsidade. Logo, esse conhecimento não pode ser chamado
matutino nem vespertino.

2. Demais. — Entre a tarde e a manhã está a noite e, entre a manhã e a tarde está o meio dia. Se,
portanto, há nos anjos conhecimento matutino e vespertino, deve neles haver, pela mesma razão,
conhecimento meridiano e noturno.

3. Demais. — A ciência se distingue pela diferença dos objetos conhecidos, e, por isso, diz o Filósofo que
as ciência se dividem segundo os seus objetos. Ora, é tríplice a existência delas, a saber: no Verbo, em a
natureza própria e em a natureza angélica, como diz Agostinho. Logo, se se admitir o conhecimento
matutino e vespertino nos anjos, em virtude da existência das coisas no Verbo e em a natureza própria,
também se deverá admitir neles o terceiro conhecimento, por causa da existência das coisas na
inteligência angélica.
Mas, em contrário, Agostinho distingue, nos anjos, os conhecimentos matutino e vespertino.

SOLUÇÃO. — Essa concepção dos conhecimentos matutino e vespertino nos anjos foi introduzida por
Agostinho, que quer entender os seis dias, nos quais se lê que Deus fez todas as coisas, de maneira a
não significarem os nossos dias comuns percorridos pelo circuito do sol, pois se lê que o sol foi feito no
quarto dia; mas um só dia, a saber, o conhecimento angélico representado nos seis gêneros de coisas.
Pois, assim como o nosso dia habitual tem a manhã por princípio e a tarde por fim, assim o
conhecimento da existência mesma primordial das coisas se chama matutino e se refere à existência das
coisas no Verbo. Porém, se chamam conhecimento vespertino ao da existência mesma da coisa criada,
considerada esta na sua própria natureza. Pois, a existência das coisas começou no Verbo como num
princípio primordial, tendo esse efluxo o seu termo na existência que as coisas têm na própria natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tarde e manhã não se entendem, no conhecimento
angélico, relativamente à mistura com as trevas, mas a um princípio e um termo. — Ou se deve
responder que nada impede, como diz Agostinho, seja uma coisa, em comparação com outra, chamada
luz e, com outra, treva. Assim como a vida dos fiéis e dos justos, em comparação com a dos ímpios, é
chamada luz, segundo a Escritura (Ef 5, 8): Outrora éreis trevas, mas agora sois luz no Senhor. Contudo,
essa mesma vida, comparada com a da glória, é chamada tenebrosa pela Escritura (2 Pd 1, 19): Temos
ainda a palavra dos profetas, à qual fazeis bem de atender, como a uma tocha que ilumina a um lugar
tenebroso. Assim, pois, o conhecimento, pelo qual o anjo conhece as coisas segundo a natureza própria
delas, é dia, comparado com a ignorância ou o erro; mas é obscuro, comparado com a visão do Verbo.

RESPOSTA À SEGUNDA. — O conhecimento matutino e vespertino se refere ao mesmo ser, i. é, aos
anjos iluminados, distintos das trevas, i. é, dos maus anjos. Porém, os bons anjos, conhecendo a
criatura, não se lhe prendem, o que seria o entenebrecer-se e fazer-se noite, mas o referem ao louvor
de Deus em quem, como no princípio, tudo conhecem. E assim, depois da tarde não vem a noite, mas a
manhã, por ser esta o fim do dia precedente e o princípio do seguinte, referindo os anjos o
conhecimento da obra precedente ao louvor de Deus. E, quanto ao meio-dia, este se compreende na
denominação de dia, como sendo o meio entre dois extremos. — Ou pode o meio dia referir-se ao
conhecimento do próprio Deus, sem princípio nem fim.

RESPOSTA À TERCEIRA. — Também os anjos são criaturas. Por isso a existência das coisas, na
inteligência angélica, se compreende no conhecimento vespertino, como o da existência delas na sua
natureza própria.

## Art. 7 — Se o conhecimento vespertino é o mesmo que o matutino.
(De Verit., q. 8, a. 16; De Pot., q. 4, a. 2, ad 10, 19, 22)
O sétimo discute-se assim. — Parece que o conhecimento vespertino é o mesmo que o matutino.

1. — Pois, diz a Escritura (Gn 1, 5): Da tarde e da manhã se fez o dia primeiro. Ora, por dia se entende o
conhecimento angélico, como diz Agostinho. Logo, o mesmo é o conhecimento matutino que o
vespertino dos anjos.

2. Demais. — É impossível uma potência ter simultaneamente duas operações. Ora, os anjos sempre
estão em ato de conhecimento matutino, porque sempre vêem a Deus e as coisas em Deus, conforme a
Escritura (Mt 18, 10): Os seus anjos sempre vêem a face de meu Pai, etc. Logo, se o conhecimento
vespertino fosse diverso do matutino, de nenhum modo o anjo poderia ter aquele em ato.

3. Demais. — Diz a Escritura (1 Cor 13, 10): Mas quando vier o que é perfeito, abolido será o que é em
parte. Ora, se o conhecimento vespertino é diferente do matutino, aquele está para este como o
imperfeito para o perfeito. Logo, não poderá o conhecimento vespertino existir simultaneamente com o
matutino.
Mas, em contrário, diz Agostinho que muito difere o conhecimento de qualquer coisa no Verbo de Deus
e na sua própria natureza; de modo que o primeiro conhecimento merecidamente pertence ao dia e o
segundo, à tarde.

SOLUÇÃO. — Como se disse, pelo conhecimento vespertino os anjos conhecem as coisas em a natureza
própria delas. O que se não deve entender no sentido que eles tirem o seu conhecimento quase da
natureza própria das coisas, como se a preposição em indicasse relação com um princípio; pois, segundo
vimos, os anjos não tiram das coisas o seu conhecimento. Resta, portanto, que a expressão natureza
própria deve ser compreendida relativamente à natureza do objeto conhecido, enquanto este cai sob o
conhecimento; e assim chama-se conhecimento vespertino ao pelo qual os anjos conhecem a existência
que as coisas têm em a natureza própria delas. E esta eles a conhecem por duplo modo: pelas espécies
inatas e pelas razões das coisas existentes no Verbo. Pois, contemplando o Verbo, não somente
conhecem a existência que elas têm nele, mas também a que têm a natureza própria; assim como Deus,
contemplando-se a si mesmo, conhece o ser que as coisas têm na própria natureza delas. Se, portanto,
se considerar como vespertino o conhecimento que têm, contemplando o Verbo, da existência das
coisas em a natureza própria, então esse conhecimento é um e essencialmente o mesmo que o
matutino, deste diferindo só quanto aos objetos conhecidos. Se, porém, se considerar como vespertino
o conhecimento que os anjos têm, por formas inatas, da existência das coisas em a natureza próprias
delas, então este difere do matutino. E é este o sentido de Agostinho dizendo que é um conhecimento
imperfeito por comparação com o outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como, no sentir de Agostinho, o número de seis
dias é considerado em relação aos seis gêneros de coisas conhecidas dos anjos; assim, a unidade do dia
é considerada em relação à do objeto conhecido, que, todavia, pode ser conhecido por diversos
conhecimentos.

RESPOSTA À SEGUNDA. — Podem pertencer simultaneamente à mesma potência duas operações, das
quais uma se refira à outra; assim, é claro que a vontade quer simultaneamente o fim e os meios; e o
intelecto intelige simultaneamente os princípios e, por estes, as conclusões, uma vez a ciência adquirida.
Ora, o conhecimento vespertino, nos anjos, referindo-se ao matutino, como diz Agostinho, nada impede
que ambos neles existam simultaneamente.

RESPOSTA À TERCEIRA. — A presença do perfeito exclui o imperfeito, que lhe é oposto; assim a fé,
referindo-se ao que se não vê, será excluída pela visão presente. Mas a imperfeição do conhecimento
vespertino não se opõe à perfeição do matutino; pois, o ser uma coisa conhecida em si mesma não se
opõe a ser conhecida na sua causa. E, do mesmo modo, em nada repugna seja uma coisa conhecida por
dois meios, dos quais um é mais perfeito e outro mais imperfeito; assim como, para a mesma conclusão,
podemos empregar um meio demonstrativo e um dialético. E semelhantemente, o anjo pode conhecer
uma mesma coisa pelo Verbo encarnado e pela espécie inata.