# Questão 76: Da união da alma e do corpo.
Em seguida, temos de tratar da união da alma e do corpo. E, sobre esta questão, oito artigos se
discutem:

## Art. 1 — Se o princípio intelectivo está unido ao corpo como forma.
(II Cont. Gent., capo LVI, LVII, LIX, LXVIII seqq.; De Spirit.Creat., a, 2; Qu. De Anima, a. 1, 2; De Unit:.
Intell.; II De Anima, lect. IV; III, lect. VII).
O primeiro discute-se assim. ― Parece que o princípio intelectivo não está unido ao corpo como
forma.

1. ― Pois, diz o Filósofo que o intelecto é separado e não é ato de nenhum corpo. Logo, não está unido
ao corpo como forma.

2. Demais. ― Toda forma é determinada pela natureza da matéria a que pertence; do contrário não
seria preciso a proporção entre aquela e esta. Se, pois, o intelecto estivesse unido ao corpo como forma,
como todo corpo tem uma natureza determinada, seguir-se-ia que também o intelecto a teria e, então,
não seria cognoscitivo, como é claro pelo que já foi dito (q. 75, a. 2). Ora, isto é contra a natureza dele;
e, logo, não está unido ao corpo como forma.

3. Demais. ― Toda potência receptiva, que é ato de algum corpo, recebe a forma material e
individualmente; porque o recebido está no recipiente ao modo deste. Ora, a forma da causa inteligida
não é recebida no intelecto, material e individualmente, mas antes, imaterial e universalmente; do
contrário, o intelecto não seria cognoscitivo do imaterial e do universal, senão só do singular, como os
sentidos. Logo, não está unido ao corpo como forma.

4. Demais. ― Ao mesmo ser pertencem a potência e o ato; pois, é o mesmo ser que pode agir e que age.
Mas, como resulta do já dito (Ibid), a ação intelectual não pertence a um determinado corpo. Logo, nem
a potência intelectiva é potência de nenhuma corpo determinado. Ora, a virtude ou potência não pode
ser mais abstrata ou mais simples do que a essência, da qual deriva. Logo, também a substância do
intelecto não é forma do corpo.

5. Demais. ― O que tem o ser em si não se une ao corpo como forma; pois esta, sendo causa de alguma
causa existir, o seu ser mesmo não é o ser da forma em si. Ora, o princípio intelectivo tem o ser em si e é
subsistente, Como já antes se disse (Ibid). Logo, não está unido ao corpo como forma.

6. Demais. ― O inerente a uma causa em si sempre nela existe. Ora, é inerente à forma em si estar
unida à matéria; e não por algum acidente, mas por essência, é o ato da matéria; do contrário, a matéria
e a forma não constituiriam unidade substancial, mas acidental. Logo, a forma não pode existir sem a
matéria própria. Ora, o princípio intelectivo, sendo incorruptível, como antes se demonstrou (Ibid, a. 6),
permanece não unido ao corpo, uma vez este corrompido. Logo, não está unido ao corpo como forma.
Mas, em contrário, segundo o Filósofo, a diferença é deduzida da forma da causa. Ora, a diferença
constitutiva do homem é ser racional, qualidade esta que se lhe atribui em virtude do princípio
intelectivo. Logo este é a forma do homem.

SOLUÇÃO. ― Deve-se admitir que o intelecto, princípio da operação intelectual, é a forma do corpo
humano. Pois, aquilo que faz, primariamente, com que um ser opere, é a forma do ser ao qual se atribui
à operação; assim, aquilo pelo que, primariamente, o corpo é são é a saúde, e o pelo que,
primariamente, a alma sabe é a ciência; por onde, a saúde é a forma do corpo e a ciência é, de certo
modo, a forma da alma. E a razão disto está em nenhum ser agir senão como atual; por onde, o que
torna um ser atual também fá-lo agir. Ora, é manifesto que a alma é o principio primário da vida do
corpo. E como a vida se manifesta por operações diversas nos diversos graus de viventes, aquilo que
produz, primariamente, cada uma das obras da vida é a alma. Pois é pela alma que, primariamente nos
nutrimos, sentimos, movemo-nos localmente e, semelhantemente, inteligimos. Logo, esse princípio pelo
qual primariamente inteligimos, quer se chame intelecto, quer alma intelectiva, é a forma do corpo. E
tal é a demonstração de Aristóteles. E quem pretender que a alma intelectiva não é a forma do corpo,
necessário é encontrar o modo pelo qual o ato de inteligir seja o ato de um determinado homem. Pois,
cada um de nós sente que é o nosso ser mesmo que intelige.
Ora, uma ação pode ser atribuída a alguém de tríplice modo, como se vê claramente no Filósofo. Assim,
diz-se que um ser move ou age, totalmente, como o médico cura; parcialmente, como o homem vê com
os olhos; acidentalmente, como se diz que o branco constrói porque acontece que um construtor é
branco. Quando, pois, dizemos que Sócrates ou Platão intelige, é manifestO que isso não lhe é atribuído
por acidente; pois, o que dele essencialmente se predica é-lhe atribuído enquanto homem. Ou então,
forçoso é dizer-se que Sócrates intelige por si mesmo, na sua totalidade, como ensinava Platão, dizendo
que o homem é a alma intelectiva; ou que o intelecto é uma parte de Sócrates
Ora, a primeira posição não se pode sustentar, como já se demonstrou antes (q. 75, a. 4), porque o
homem que se percebe o seu inteligir é o mesmo que se percebe o seu sentir. Ora, sentir não vai sem o
corpo. Portanto, necessário é seja este uma parte do homem.
Resta, portanto, que o intelecto, com o qual Sócrates intelige seja parte deste, a ponto que lhe esteja,
de certo modo, unido ao corpo. E esta união, diz o Comentador, se realiza pela espécie inteligível, que
tem duplo sujeito: o intelecto possível e os fantasmas, que estão nos órgãos corpóreos. Assim, pela
espécie inteligível, une-se o intelecto possível ao corpo de tal ou tal homem. ― Mas esta continuidade
ou união não basta para a ação do intelecto ser a ação de Sócrates. O que se torna patente pela
semelhança com o sentido, do qual Aristóteles parte para considerar as coisas do intelecto. Ora, os
fantasmas estão para o intelecto, diz, como as cores para a vista. Pois, assim como as espécies das cores
estão na vista, assim as dos fantasmas, no intelecto possível. Mas é evidente que, pelo fato de estarem
numa parede as cores, cujas semelhanças estão na vista, não se atribui à parede o ato da visão; e por
isso, não dizemos que a parede vê, mas antes, que é vista. Assim também, do fato de estarem as
espécies dos fantasmas no intelecto possível, não se segue que Sócrates, em quem estão os fantasmas,
intelija; mas antes, que ele ou os seus fantasmas são inteligidos.
Outros ensinaram que o intelecto está unido ao corpo como um motor, ambos constituindo uma
unidade, de modo que a ação do intelecto pode ser atribuída ao todo. ― Mas esta opinião é, de muitas
maneiras, vã. ―Primeiro, porque o intelecto não move o corpo senão pela apetição, cujo movimento
pressupõe a operação do intelecto. Pois, não é porque Sócrates é movido pelo intelecto, que ele
intelige, mas antes, inversamente, porque intelige é que é movido pelo intelecto. ― Segundo, porque,
sendo Sócrates um determinado indivíduo da natureza, cuja essência é una, composta de matéria e
forma, se o intelecto não for à forma dele, resulta que lhe estranha à essência; e, então, o intelecto se
há de comparar com todo Sócrates, assim como o motor com o movido. Ora, inteligir é ação imanente
no próprio sujeito e não transeunte para outro, como a calefação. Logo, inteligir não pode ser atribuído
a Sócrates por que seja este movido pelo intelecto. ― Terceiro, porque a ação do motor nunca se atribui
ao movido senão como a um instrumento; assim, a ação do carpinteiro é atribuída a serra. Se, portanto,
inteligir é atribuído a Sócrates, porque é a ação do motor deste, segue-se que lhe é atribuído como a
instrumento; o que vai contra o Filósofo, ensinando que o inteligir não é por meio de um instrumento
corpóreo. Quarto, porque, embora a ação da parte seja atribuída ao todo, como a ação dos olhos ao
homem, contudo, esta nunca é atribuída à outra parte qualquer, a não ser, talvez, por acidente; pois,
não dizemos que a mão vê porque os olhos vêm. Se, portanto, é do modo supradito que intelecto e
Sócrates constituem unidade, a ação daquele não pode ser atribuída a este. Se, porém, Sócrates é um
todo composto da união do intelecto com tudo o mais que é de Sócrates; e, contudo, o intelecto não se
une a este mais, senão como motor, então resulta que Sócrates não é um, absolutamente; e, por
conseqüência, não é ser absolutamente, pois, uma coisa é ser do mesmo modo pelo qual é uma.
Resta, portanto, só o modo ensinado por Aristóteles, a saber, que tal homem intelige porque o princípio
intelectivo é a sua: forma. Assim, pois, da operação mesma do intelecto resulta que o princípio
intelectivo está unido ao corpo como forma.
E isso mesmo também pode ser deduzido da natureza da espécie humana. Pois, a operação de um ser
indicando-lhe a natureza, e a operação própria do homem, como tal, sendo inteligir; por ela transcende
todos os animais. Donde vem que Aristóteles faz constituir a felicidade última nessa operação, como
própria do homem. Ora, é necessário que o homem pertença a uma espécie determinada pelo princípio
dessa operação; pois cada ser pertence à espécie que lhe é determinada pela forma da mesma. Resulta
daí, portanto, que o princípio intelectivo é a forma própria do homem.
Mas devemos notar que, quanto mais nobre for a forma, tanto mais dominará a matéria corpórea, tanto
menos nesta estará imersa e tanto mais a excederá pela sua operação ou virtude; por onde, vemos que
a forma do corpo misto tem uma certa operação não causada pelas qualidades elementares. E quanto
mais avançarmos em a nobreza das formas, tanto mais veremos a virtude da forma exceder a matéria
elementar; assim, a alma vegetativa é mais que a forma do metal e a alma sensível, mais que a
vegetativa. Ora, a alma humana é a última, em a nobreza das formas. Por onde, excede, pela sua
virtude, a matéria corpórea, na medida mesma em que tem uma operação e uma virtude, das quais de
nenhum modo participa a matéria corpórea. E essa virtude se chama intelecto.
Deve-se, porém, atender a que, se alguém disser que a alma é composta de matéria e forma, de
nenhum modo poderá dizer que ela é a forma do corpo. Pois, sendo a forma ato, e a matéria, ser
somente potencial, de nenhum modo o que é composto de matéria e forma poderá ser, em si e
totalmente, forma de outro ente. Se, porém, for forma só quanto a uma parte de si, então chamamos
alma ao que é forma; e primeiro animado, ao ser de que é forma, como antes já ficou dito (q. 75, a. 5).

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como diz o Filósofo, a última das formas naturais, com a
qual termina a consideração do Filósofo natural, i. é., a alma humana, é certamente separada; contudo,
está unida à matéria. E a prova está em que o homem, juntamente com o sol, gera outro homem, da
matéria. Porém, é separada quanto à virtude intelectiva; porque esta não é virtude de nenhum órgão
corpóreo, como a virtude visiva ato dos olhos; pois, inteligir é ato que se não pode exercer por um órgão
corpóreo, como se exerce a visão. Está, porém, na matéria, porque a alma mesma, a que pertence tal
virtude, é forma do corpo e o termo da geração humana. Assim, pois, o Filósofo diz, que o intelecto é
separado por não ser virtude de nenhum órgão corpóreo.
E daqui se deduzem as RESPOSTAS À SEGUNDA E À TERCEIRA OBJEÇÕES. Pois, para o homem inteligir
todas as coisas pelo intelecto, e também os seres imateriais e universais, basta que a virtude intelectiva
não seja ato do corpo.

RESPOSTA À QUARTA. ― A alma humana, por causa da sua perfeição, não é forma imersa na matéria
corpórea, ou por esta totalmente compreendida; por onde, nada impede que alguma virtude sua não
seja ato do corpo, embora, na sua essência, seja a forma deste.

RESPOSTA À QUINTA. ― A alma comunica à matéria corpórea o ser no qual subsiste; e, deste e da alma
intelectiva constitui-se uma unidade, de modo que o ser de todo o composto é também o da alma
mesma; o que não se dá com as outras formas não subsistentes. E por isso, a alma humana permanece
no ser, destruído o corpo; não, porém, as outras formas.

RESPOSTA À SEXTA. ― Em si, convém à alma estar unida ao corpo, assim como, em si, convém ao corpo
leve o elevar-se. E assim como este permanece certamente leve, quando separado do lugar próprio,
conservando, contudo, a aptidão e a inclinação para esse lugar; assim a alma humana permanece no ser,
quando separada do corpo, conservando a aptidão e a inclinação natural para a união com o mesmo.

## Art. 2 — Se o princípio intelectivo se multiplica com a multiplicação dos corpos, ou se há um só intelecto para todos os homens.
(I Sent., disto VIII. q. 5,.a. 2, ad 6; II, disto XVII, q. 2, a. 1; IICont.Gent., cap. LXXIII, LXXV; De Spirit Creat.,
a. 9; Qu. De Anima, a .3, Compende. Theol., cap. LXXXV;De Ubit Intellec. Per tot).
O segundo discute-se assim. ― Parece que o princípio intelectivo não se multiplica com a
multiplicação dos corpos, mas há um só intelecto para todos os homens.

1. ― Pois, nenhuma substância imaterial se multiplica numericamente, numa mesma espécie. Ora, a
alma humana é substância imaterial, pois, não é composta de matéria e forma, como já se demonstrou
(q. 75, a. 5). Logo, não há muitas da mesma espécie; mas todos os homens o são e, portanto, todos têm
um só intelecto.

2. Demais. ― Removida a causa, removido fica o efeito. Se, pois, com a multiplicação dos corpos, se
multiplicassem as almas humanas, conseqüentemente, removidos aqueles, não permaneceria a
multidão destas, restando só uma, de todas elas. O que é herético porque, então, desapareceria a
diferença entre os prêmios e as penas.

3. Demais. ― Se o meu intelecto é diferente do teu, o meu é um certo indivíduo, bem como o teu; pois,
seres particulares são os que, diferindo pelo número, convêm na mesma espécie. Ora, tudo o que
noutro ser é recebido o é ao modo do que recebe. Logo, as espécies das coisas seriam recebidas,
individualmente, pelo meu e pelo teu intelecto. O que é contra a natureza deste, que é cognoscitivo do
universal.

4. Demais. ― O inteligido está no intelecto que intelige. Se, pois, o meu intelecto é diferente do teu, é
necessário seja uma a coisa inteligida por mim e outra, a por ti; e, assim, o inteligido será multiplicado
individualmente e será somente potencial. E será forçoso abstrair de um e outro o ato cognitivo comum;
pois de dois seres diversos quaisquer é necessário abstrair o que neles haja de inteligível comum. O que
vai contra a natureza do intelecto, pois que, então não se poderia distinguir o intelecto da virtude
imaginativa. Logo, é forçoso concluir ser um só o intelecto para todos os homens.

5. Demais. ― Embora o discípulo receba a ciência do mestre, não se pode dizer que esta gera a daquele;
porque, assim, também a ciência seria uma forma ativa, como o calor, o que evidentemente é falso.
Portanto, numericamente a mesma é a ciência do mestre, comunicada ao discípulo; o que não é
possível, a menos que ambos tenham o mesmo intelecto. Logo, um só é o intelecto do mestre e do
discípulo e, por conseqüência, de todos os homens.

6. Demais. ― Agostinho diz: Se afirmar, que somente as almas humanas são muitas, a mim mesmo me
tornarei ridículo. Ora, é sobretudo quanto ao intelecto que a alma humana é considerada una. Logo, há
um só intelecto para todos os homens.
Mas, em contrário, diz o Filósofo: as causas universais estão para as coisas universais, como as
particulares para as coisas particulares. Ora, é impossível a alma, especificamente una, ser a mesma
para animais especificamente diversos. Logo, é impossível que a alma intelectiva, numericamente una,
possa ser a de seres numericamente diversos.

SOLUÇÃO. ― É absolutamente impossível haja um só intelecto para todos os homens. E isto é evidente
se, segundo a opinião de Platão, o homem é o seu intelecto mesmo. Pois, daí resultaria que, se Sócrates
e Platão têm o mesmo intelecto, ambos são o mesmo homem e não se distinguirão um do outro senão
pelo que lhes for exterior à essência. E, assim, a distinção entre eles seria a mesma que entre um
homem vestido de túnica e outro de capa, o que é completamente absurdo. ― Semelhantemente,
também se verá a mesma impossibilidade se, conforme a opinião de Aristóteles, se admitir o intelecto
como parte ou potência da alma, que é a forma do homem. Pois, é impossível que muitos seres,
numericamente diversos, tenham a mesma forma; assim como o é tenham o mesmo ser, do qual a
forma é o princípio.
Do mesmo modo verá essa impossibilidade quem, de qualquer maneira que seja, admitir a união do
intelecto com tal homem ou tal outro. Pois, é manifesto, dado um só princípio agente e dois
instrumentos, pode haver um só agente, absolutamente, mas várias ações; assim, se o mesmo homem
tocar coisas diversas com as duas mãos, haverá, certamente, vários agentes, mas uma só ação; como se
muitos puxarem, com uma corda, uma embarcação, haverá muitos que puxam, mas uma só ação
tratora. Se, porém, for um o agente principal e um o instrumento, haverá um só agente e uma só ação;
assim, se um ferreiro percute com um martelo um é o percutidor e uma a percussão. Ora, é manifesto,
que seja como for o modo por que o intelecto, esteja unido ou ligado a tal homem ou tal outro, ele têm,
entre os demais atributos do homem, a principalidade, pois, as forças sensitivas lhe obedecem e
servem. Se, pois, se admitissem, para dois homens, vários intelectos e um só sentido, e se, assim, dois
homens tivessem os mesmos olhos, seriam dois a ver, com uma só visão. Se, portanto, o intelecto é um,
embora sejam diversos os meios de que todo intelecto usa, como de instrumentos, de nenhum outro
modo poderiam Sócrates e Platão ser considerados senão como um só e mesmo homem, que intelige. E
se acrescentarmos que o ato mesmo de inteligir, próprio do intelecto, não se realiza por nenhum outro
órgão a não ser pelo intelecto, resultará, mais, a unidade do agente e da ação, i. é., todos os homens
serão um só ser inteligente, com o mesmo ato de inteligir, em relação ao mesmo inteligível.
Porém, a minha ação intelectual poderia diversificar-se da tua, pela diversidade dos fantasmas, pois que
um é o fantasma de uma pedra em mim e outro, em ti, se o fantasma mesmo, enquanto um, o meu e
outro, o teu, fosse a forma do intelecto possível. Porque, o mesmo agente, segundo as diversas formas,
produz diversas ações; assim, segundo são diversas as formas das coisas, em relação aos mesmos olhos,
assim são diversas as visões. Mas, o fantasma não é a forma do intelecto possível, mas sim, a espécie
inteligível, dele abstraída. Ora, num mesmo intelecto, de fantasmas diversos da mesma espécie só pode
ser abstraída uma espécie inteligível. O que bem se vê, considerando-se um mesmo homem, no qual
podem existir diversos fantasmas das coisas; e, todavia, de todos eles é abstraída uma só espécie
inteligível da pedra, pela qual o seu intelecto, por operação una, intelige a natureza da pedra, não
obstante a diversidade dos fantasmas. Se, pois, fosse um só o ’intelecto de todos os homens, as
diversidades dos fantasmas, neles, não poderiam causar a diversidade da operação intelectual, neste ou
naquele, como supõe o Comentador. Conclui-se, portanto, que é absolutamente impossível e
inconveniente admitir que há um só intelecto para todos os homens.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. . Embora nem a alma intelectiva, nem o anjo, tenham
matéria de que provenham, aquela é, todavia, a forma de uma certa matéria. Por onde, conforme a
divisão da matéria, assim há muitas almas da mesma espécie; ao passo que é absolutamente impossível
assim existirem muitos anjos.

RESPOSTA À TERCEIRA. ― Cada ser tem a unidade do mesmo modo pelo qual tem o ser e, por
conseqüência, o que se diz da multiplicação das coisas diz-se-lhes também do ser. Ora, é manifesto, a
alma intelectual, está, por natureza, unida ao corpo, como forma; e contudo, destruído este, ela
permanece no ser. E, pela mesma razão, a multidão das almas é relativa à dos corpos; contudo,
destruídos estes, elas permanecem multiplicadas no seu ser.

RESPOSTA À TERCEIRA. ― A individuação do ser inteligente ou da espécie pela qual intelige, não exclui
a inteligência dos universais; do contrário, sendo os intelectos separados substâncias subsistentes e, por
conseqüência, particulares, não poderiam inteligir os universais. Mas, a materialidade do conhecente e
da espécie, pela qual conhece, impede o conhecimento do universal. Pois, assim como toda ação é
relativa ao modo da forma pela qual o agente age, como, p. ex., a cale facção é relativa ao modo do
calor; assim, o conhecimento é relativo ao modo da espécie, pela qual o conhecente conhece. Ora, é
manifesto que a natureza comum se distingue e multiplica segundo os princípios individuantes, que
dependem da matéria. Se, pois, a forma, pela qual se faz o conhecimento, for material, não abstraída
das condições da matéria, essa forma será a semelhança da natureza da espécie ou do gênero, porque
será distinta e multiplicada, pelos princípios individuantes; e, então, não poderá ser conhecida à
natureza da coisa, na sua comunidade. Se, porém, a espécie for abstraída das condições da matéria
individual, haverá a semelhança da natureza sem aquilo que a distingue e multiplica; e, assim, será
conhecido o universal. Nem importa, quanto a isto, se o intelecto for um só ou se forem muitos; porque,
mesmo que fosse só um, seria necessário sê-lo determinadamente, e também deveria ser a espécie pela
qual intelige uma espécie determinada.

RESPOSTA À QUARTA. ― Quer o intelecto seja um, quer sejam muitos, só uma e mesma coisa é o que é
inteligido. Pois, isto não está no intelecto, conforme o que é, mas pela sua semelhança. Assim, não a
pedra, mas sim a sua espécie é que está na alma como diz Aristóteles. E, contudo, é a pedra a inteligida,
e não a sua espécie, a não ser pela reflexão do intelecto sobre si mesmo; do contrário, não haveria
ciências das causas, mas só das espécies inteligíveis. Ora, forçosamente, se diversas coisas se
assemelham ao mesmo ser, se-lo-á por formas diversas. E como o conhecimento se opera pela
assimilação do conhecente com a causa conhecida, resulta que a mesma coisa pode ser conhecida por
diversos conhecentes, como se dá com os sentidos. Assim, vários vêm à mesma cor, sob semelhanças
diferentes; e, do mesmo modo, vários intelectos inteligem a mesma causa. Mas, na opinião de
Aristóteles, entre os sentidos e o intelecto há só esta diferença: uma causa é sentida, conforme a
disposição que tem, na sua particularidade, fora da alma; ao passo que a natureza da causa inteligida
existindo, por certo, fora da alma, aí não tem, contudo, o modo de ser pelo qual é inteligida. Pois, o que
é inteligido é a natureza comum, separada de todos os princípios individuantes. Ora, tal modo de existir,
a causa não o tem fora da alma. Mas, conforme a opinião de Platão, que admitia serem as naturezas das
causas separadas da matéria, a coisa inteligida está fora da alma do mesmo modo pelo qual é inteligida.

RESPOSTA À QUINTA. ― De um modo está à ciência no mestre e, de outro, no discípulo. E a seguir se
verá como ela é causada (q. 117, a. 1).

RESPOSTA À SEXTA. ― Agostinho quer dizer que não há pluralidade de almas sem que estejam unidas
sob a noção de uma mesma espécie.

## Art. 3 — Se, além da alma intelectiva, há no homem, outras almas essencialmente diferentes, a saber, a sensitiva e a nutritiva.
(II Cont. Gent., cap.LVIII; De Pot., q.3, a. 9, ad 9; De Spirit. Creat., a. 3; Qu. De Anima, a. 2; Quodl. XI, q. 5;
Compend. Theol., cap. XC sqq.).
O terceiro discute-se assim. ― Parece que, além da alma intelectiva, há no homem, outras almas ― a
sensitiva e a nutritiva ― essencialmente diferentes.

1. ― Pois, a mesma substância não pode ser corruptível e incorruptível. Ora, ao passo que a alma
intelectiva é incorruptível, as outras almas - a sensitiva e a nutritiva ― são corruptíveis, como resulta do
que já vimos antes (q. 75, a. 6). Logo, no homem, não podem ter a mesma essência as almas intelectiva,
sensitiva e nutritiva.

2. ― Se se disser que a alma sensitiva, no homem, é incorruptível, responde-se em contrário. ― O
corruptível e o incorruptível diferem genericamente, como diz o Filósofo. Ora, a alma sensitiva, no
cavalo, no leão e nos outros animais, é corruptível. Se, pois, no homem, for incorruptível, não será do
mesmo gênero a ― alma sensitiva, no homem e no bruto. Ora, como o animal assim se chama porque
tem alma sensitiva, não serão do mesmo gênero o homem e o animal, o que é inadmissível.

3. Demais. ― O Filósofo diz que o embrião, antes de ser homem, é animal. O que não poderia ser, se as
almas sensitiva e intelectiva tivessem a mesma essência, porque então, seria animal, pela alma sensitiva
e homem, pela intelectiva. Logo, no homem, não é a mesma a essência das almas sensitiva e intelectiva.

4. Demais. ― O Filósofo diz que o gênero provêm da matéria e a diferença, da forma. Mas racional,
diferença constitutiva do homem, provém da alma intelectiva; pois, o animal assim se chama por ter o
corpo animado da alma sensitiva. Por onde, a alma intelectiva está para o corpo animado pela alma
sensitiva, como a forma para a matéria. Logo, a alma intelectiva não é, no homem, essencialmente a
mesma que a alma sensitiva, mas aquela pressupõe esta como o seu suposto material.
Mas, em contrário, está dito: Nem dizemos, como Jacó e os outros sírios escrevem, que há, num homem
duas almas: uma animal, misturada com o sangue, que anime o corpo, e outra espiritual, dotada de
razão. Mas dizemos que, no homem, só há uma mesma alma, que, pela sua união, vivifica o corpo,
dispondo-se de si mesma, pela sua razão.

SOLUÇÃO. ― Platão, como refere Aristóteles, admitia que um mesmo corpo têm diversas almas, mesmo
distintas pelos órgãos, aos quais atribuía as diversas operações vitais. Assim, a virtude nutritiva está no
fígado; a concupiscível, no coração; a cognoscitiva, no cérebro. Mas Aristóteles rejeita essa opinião,
quanto àquelas partes da alma, que usam de órgãos corpóreos, nas suas operações, baseado em que
nos animais vivos ainda, quando cortados em partes, em, cada uma delas se encontram as diversas
operações da alma, como a sensibilidade e o apetite. O que não se daria, se os vários princípios das
operações da alma, diversos por essência, fossem distribuídos pelas diversas partes do corpo. Mas fica
na dúvida, quanto à parte intelectiva, sobre se está separada das outras partes da alma só
racionalmente, ou se também localmente. ― A opinião de Platão, porém, poderia sustentar-se, se se
admitisse que a alma está unida ao corpo, não como forma, mas como motor, segundo ele queria. Pois,
nenhum inconveniente resultaria de o mesmo móvel ser movido por diversos motores, sobretudo
segundo partes diversas.
Mas, se admitimos que a alma está unida ao corpo, como forma, é absolutamente impossível existirem,
no mesmo corpo, várias almas essencialmente diferentes. O que se pode demonstrar por tríplice razão.
E a primeira é que, o animal, com três almas, não seria absolutamente uno. Pois, nenhum ser é pura e
simplesmente uno, senão pela forma una, pela qual as coisas existem; porque é em virtude do mesmo
princípio que uma coisa existe e é una. Por onde, seres denominados por formas diversas não têm a
unidade absoluta como, p. ex., homem branco. Se, portanto, o homem fosse vivo por uma forma, a alma
vegetativa; animal, por outra, a sensitiva; homem, por outra, a racional, daí resultaria que não seria
homem absolutamente. Ou, como também Aristóteles argumenta contra Platão, se uma fosse a idéia de
animal e outra a de bípede, o animal bípede não seria uno absolutamente E por isso, aos que admitem
diversas almas num mesmo corpo, pergunta o que as contém, i. é., o que lhes dá unidade. E não se pode
responder que sejam unidas pela unidade do corpo, porque, antes, é a alma que contém o corpo e lhe
dá unidade, do que inversamente.
A segunda demonstra a impossibilidade, pelo modos da predicação. Pois, as predicações, dependentes
de formas diversas, convêm entre si, umas às outras: ou por acidente, se as formas não forem
ordenadas umas para as outras, assim p. ex., quando dizemos que o branco é doce; ou, se as formas
forem ordenadas umas para as outras, haverá predicação em si, conforme o segundo modo dessa
predicação, em que o sujeito entra na definição do predicado. Assim, a superfície, sendo precedente, à
cor, se dissermos que um corpo, dotado de superfície, é colorido, haverá o segundo modo da predicação
em si. Se, portanto, por uma forma, um ser é animal e, por outra, homem, resulta daí, ou que um desses
predicados não convém ao outro, senão acidentalmente, se essas duas formas não forem ordenadas
uma para a outra; ou que haverá então predicação, conforme o segundo modo de se predicar em si, se
uma das almas for ordenada para a outra. Ora, ambas estas posições são manifestamente falsas, porque
animal se predica, em si, do homem, e não por acidente; e homem não entra na definição de animal,
mas inversamente. Logo, necessariamente é em virtude da mesma forma que um ser é animal e é
homem; do contrário o homem não seria verdadeiramente animal, de modo que animal se predicasse,
em si, do homem.
A terceira razão da impossibilidade está em que uma operação da alma, quando intensa, impede outra;
o que de nenhum modo se daria se o princípio das ações não fosse essencialmente uno.
Portanto, é forçoso admitir que a alma sensitiva, intelectiva e nutritiva é, no homem, uma só alma.
E como seja isso possível, é fácil compreender se se considerarem as diferenças das espécies e das
formas.
Pois, vemos que as espécies e as formas das causas diferem umas das outras, como o mais perfeito
difere do menos perfeito. Assim, na ordem das causas, os seres animados são mais perfeitos que os
inanimados; os animais, que as plantas; os homens, que os brutos; e, em cada um destes gêneros, há
graus diversos. E, por isso, Aristóteles assimila as espécies das causas aos números, especificamente
diferentes pela adição ou subtração da unidade; e compara as diversas almas às espécies das figuras,
nas quais uma contém outra, como o pentágono contém e excede o tetrágono. Do mesmo modo, a
alma intelectiva contém, pela sua virtude, tudo o que tem a alma sensitiva dos brutos e a nutritiva das
plantas. Assim como, pois, a superfície pentagonal não o é, pela figura pentagonal e pela tetragonal,
porque esta seria inútil, desde que está contida naquela; assim também Sócrates não é homem, por
uma alma, e animal, por outra, senão por uma só e mesma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. . A alma sensitiva não é incorruptível só pelo fato de ser
sensitiva, mas por ser intelectiva. Enquanto, pois, unicamente sensitiva, é corruptível; quando, porém,
unida ao princípio intelectivo, é incorruptível. Por onde, embora o sensitivo não dê a incorruptibilidade,
todavia, não pode privar desta o intelectivo.

RESPOSTA À SEGUNDA. ― As formas não se unem ao gênero nem à espécie, mas ao composto. Por
isso, o homem é corruptível, como os outros animais. Por onde, a diferença fundada no corruptível e no
incorruptível, das formas, não torna o homem genericamente diferente dos outros animais.

RESPOSTA À TERCEIRA. ― O embrião tem, primeiro, a alma que é somente sensitiva; desaparecida essa,
advém à alma sensitiva e intelectiva, que é mais perfeita, como a seguir se mostrará mais plenamente
(q. 118, a. 2 ad 2).

RESPOSTA À QUARTA. ― Não se deve, das diversas razões ou intenções lógicas, resultantes do modo de
inteligir, concluir a diversidade das coisas naturais; porque a razão pode apreender uma mesma coisa
por modos diversos. Como, pois, segundo já se disse, a alma intelectiva contém, na sua virtude, aquilo
que tem a sensitiva e ainda mais; a razão pode considerar separadamente o que pertence à virtude
sensitiva como algo de imperfeito e material; e, vendo que isso é comum ao homem e aos outros
animais, daí forma o conceito de gênero. Porém, aquilo em que a alma intelectiva excede a sensitiva, a
razão o toma como formal e completivo, formando, daí, o conceito diferencial do homem.

## Art. 4 — Se há, no homem, além da alma intelectiva, outra forma.
(IV. Sent., dist. XLIV, q; 1, a. 1, qª 1, ad 4; IV Cont. Gent., cap LXXX De Spirit. Creat., a. 3; Qu. De Anima,
a. 9; QuodI. I, q. 4, a.1; XI, q. 5; Compend. Theol., cap. XC).
O quarto discute-se assim. ― Parece que há, no homem, outra forma, além da alma intelectiva.

1. ― Pois, diz o Filósofo, a alma é o ato do corpo físico que tem a vida em potência. Ora, a alma está
para o corpo como a forma para a matéria. Mas, o corpo tem uma forma substancial pela qual é corpo.
Logo, à alma precede, no corpo outra forma substancial.

2. Demais. ― O homem, bem como qualquer animal, move-se a si mesmo. Ora, todo ser que se move a
si mesmo divide-se em duas partes, uma motora e, outra, movida, como o prova Aristóteles28. Ora, a
parte motora sendo a alma, é necessário que a outra parte seja tal, que possa ser movida. Mas, a
matéria prima não pode ser movida, por ser potencial apenas, como o prova Aristóteles; e, tudo o que é
movido é corpo. Logo, é necessário que, no homem e em qualquer animal, haja outra forma substancial
pela qual seja constituído o corpo.

3. Demais. ― A ordem das formas depende da tendência delas para a matéria prima; pois, anterior e
posterior se dizem por comparação com algum princípio. Se, portanto, não houvesse, no homem,
nenhuma forma substancial, além da alma racional, mas esta aderisse imediatamente à matéria prima,
daí resultaria que a alma pertence à ordem das formas as mais imperfeitas, que aderem imediatamente
à matéria.

4. Demais. ― O corpo humano é um corpo misto. Ora, a missão não se opera só pela matéria, porque,
então, só haveria corrupção. Logo, é necessário que permaneçam as formas dos elementos, no corpo
misto, que são as formas substanciais. Portanto, no corpo humano, há outras formas substanciais, além
da alma intelectiva.
Mas, em contrário. ― Uma mesma coisa tem um só ser substancial. Ora, como a forma substancial é
que dá o ser substancial, cada coisa tem só uma forma substancial. Logo, é impossível que haja, no
homem, alguma outra forma substancial, além da alma intelectiva.

SOLUÇÃO. ― Se se admitisse, com os Platônicos, que a alma intelectiva não está unida ao corpo, como
forma, mas só corno motor, seria necessário admitir, no homem, outra forma substancial que
constituísse, no seu ser, o corpo, movido pela alma. Mas se, como já dissemos antes (a. 1), a alma
intelectiva está unida ao corpo como forma substancial, é impossível haja, no homem, qualquer outra
forma substancial, além dela.
Para a evidência do que devemos considerar que a forma substancial difere da acidental, por não dar
esta o ser absolutamente mas o ser sob certo aspecto; assim, o calor faz o seu objeto ser, não
absolutamente, mas ser quente. Por onde, pela adveniência da forma acidental, um ser não é feito ou
gerado, absolutamente, senão sob certo aspecto ou de determinado modo; e, semelhantemente,
desaparecida a forma acidental, um corpo não .se corrompe absolutamente, mas só de certo modo. Ao
passo que a forma substancial dá o ser absoluto. Por isso, com a sua adveniência, um ser é gerado, pura
e simplesmente; e, pelo seu desaparecimento, fica pura e simplesmente, concorrido. E, por essa razão,
os antigos Filósofos da natureza, admitindo a matéria prima como um ser atual, ao modo do fogo, do ar
ou corpos semelhantes, diziam que nenhum ser é, pura e simplesmente, gerado nem corrompido, mas
que todo o vir a ser é alteração, como se vê em Aristóteles. Se, portanto além da alma intelectiva,
preexistisse, na matéria, qualquer outra forma substancial, que tornasse atual o sujeito da alma,
resultaria daí que a alma não dá o ser, pura e simplesmente e, por conseqüência não é forma
substancial; e que, advindo à alma ou separando-se, não haveria geração nem corrupção, pura e
simplesmente, mas só sob certo aspecto. Coisas manifestamente falsas.
Por onde, deve-se admitir que, além da alma intelectiva, nenhuma outra forma substancial há no
homem; e que esta, assim como, na sua virtude, contém a alma sensitiva e a nutritiva, assim também
contém todas as formas inferiores, fazendo, ela só, tudo o que as formas menos imperfeitas fazem nos
outros seres.
E o mesmo se deve dizer da alma sensitiva, nos brutos, da nutritiva, nas plantas e, universalmente, de
todas as formas mais perfeitas, em relação às mais imperfeitas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. . Aristóteles não diz que a alma é o ato do corpo somente,
mas o ato do corpo físico orgânico tendo a vida em potência e, que tal potência não exclui a alma. Por
onde, é manifesto, a alma também está incluída no ser de que ela é ato, do mesmo modo que o calor é
o ato do que é cálido, a luz do que é lúcido; não que, separadamente, haja corpo lúcido sem luz, senão
que é lúcido por ela. E, semelhantemente, se diz, que a alma é o ato do corpo, etc., porque, pela alma, é
que há corpo, e esse, orgânico com vida potencial. Mas, o ato primeiro é assim chamado em relação ao
ato segundo, que é a operação. Portanto, tal potência não rejeita, i. é., não exclui a alma.

RESPOSTA À SEGUNDA. ― A alma não move o corpo pelo seu ser, enquanto unida a este como forma.
Mas, pela potência motora, cujo ato pressupõe o corpo já atualizado pela alma; de modo que esta, pela
força motora, é a parte que move, sendo o corpo animado, a parte motora.

RESPOSTA À TERCEIRA. ― Na matéria, consideram-se diversos graus de perfeição, como, ser, viver,
sentir e inteligir. Mas, sempre, o que sobrevém, em segundo lugar, é mais perfeito do que o que existe
em primeiro. Por onde, a forma, que dá só o primeiro grau da perfeição da matéria, é imperfeitíssima;
mas, a que dá o primeiro, o segundo e o terceiro, e assim por diante, é perfeitÍssima e, contudo imediata
à matéria.

RESPOSTA À QUARTA. ― Avicena ensinava que as formas substanciais dos elementos permanecem
integras no misto; e a mistão se faz pela redução das qualidades contrárias dos elementos à
média. ― Mas isto é impossível. Pois, as diversas formas dos elementos só podem existir nas diversas
partes da matéria e, para essas diversidades, é necessário se suporem as dimensões, sem as quais a
matéria não pode ser divisível. Ora, matéria sujeita à dimensão só se encontra no corpo. E, como corpos
diversos não podem ocupar o mesmo lugar, segue-se que os elementos estão, no misto, distintos pela
situação e, assim, não haverá verdadeira micção, em relação à totalidade, mas só em relação aos nossos
sentidos, o que se dá quando corpos mínimos estão justapostos. ― Porém Averróisensinava que as
formas dos elementos, pela sua imperfeição, são médias entre as formas acidentais e as substanciais e,
portanto, admitindo o mais e o menos, ficando, mitigadas, na micção, reduzem-se ao médio e, deles, se
compõe uma só fôrma. ― Mas, isto ainda é mais impossível. Porque o ser substancial de qualquer coisa
é indivisível; e toda adição ou subtração varia a espécie, como nos números, conforme diz Aristóteles.
Por onde, é impossível que qualquer forma substancial seja susceptível de mais e de menos. Nem é
menos impossível que haja um meio entre a substância e o acidente. ― E, portanto, deve-sê admitir,
com o Filósofo, a permanência, não atual, mas virtual, das formas dos elementos, no misto.
Permanecem, assim, as qualidades próprias dos elementos, embora mitigados e nas quais está a virtude
das formas elementares. E, deste modo, a qualidade da mistão é a disposição própria para receber a
forma substancial do corpo misto, p. ex., a forma da pedra ou de qualquer ser animado.

## Art. 5 — Se a alma intelectiva deve estar unida a um corpo humano.
(II. Sent., dist. 1, q. 2, a. 5; De Malo, q. 5, a. 5; Qu. De Anima, a. 8).
O quinto discute-se assim. ― Parece que a alma intelectiva não deve estar unida a um corpo humano.

1. ― Pois, a matéria deve ser proporcionada à forma. Ora, a alma intelectiva é forma incorruptível. Logo,
não deve estar unida a um corpo corruptível.

2. Demais. ― A alma intelectiva é uma forma imaterial em sumo grau; e a prova é que tem operações
que não participam da matéria corpórea. Ora, quanto mais sutil é o corpo tanto menos tem de material.
Logo, a alma deveria estar unida a um corpo sutilíssimo, como o fogo, e não a um corpo misto e,
sobretudo, terrestre.

3. Demais. ― Sendo a forma o princípio da espécie, de uma só forma não podem provir diversas
espécies. Ora, a alma intelectiva é forma una. Logo, não deve estar unida a um corpo composto de
partes de espécies dessemelhantes.

4. Demais. ― Uma forma mais perfeita deve estar unida a um corpo mais perfeito. Ora, a alma
intelectiva é a mais perfeita das almas. Se pois, os corpos dos outros animais têm proteções naturais,
como os pêlos, que lhes servem de vestes, e as unhas, de calçado; e se têm, também, armas naturais,
como as unhas, os dentes e os chifres; conclui-se que a alma intelectiva não deveria estar unida a um
corpo tão imperfeito, privado de tais auxílios.
Mas, em contrário, diz o Filósofo: a alma é o ato do corpo físico orgânico tendo a vida em potência.

SOLUÇÃO. ― Não existindo a forma pela matéria, mas, antes, a matéria pela forma, deve-se buscar, na
forma, a razão de existir a matéria de tal ou tal modo, e não inversamente. Ora, a alma intelectiva, como
já se estabeleceu antes (q. 55, a. 2), tem por ordem da natureza, o grau ínfimo, entre as substâncias
intelectuais; pois, não tendo naturalmente infuso o conhecimento da verdade, como os anjos, deve
hauri-la nas coisas divisíveis, por via dos sentidos, como diz Dionísio. Ora, a natureza não falta com o
necessário a nenhum ser. E, por isso, a alma intelectiva deve ter não só a faculdade de inteligir, mas
também a de sentir. E, como a ação dos sentidos não se realiza sem o instrumento corpóreo, é
necessário esteja a alma intelectiva unida a um corpo, que possa ser o órgão conveniente dos sentidos.
Ora, é necessário que o órgão do tacto seja o meio entre os contrários que ele apreende, a saber, o
cálido e o frio, úmido e o seco e semelhantes; por isso, o tacto é potencial em relação a eles e pode
senti-los. Donde, quanto maior igualdade de compleição tiver, tanto mais capaz de perceber será. Mas,
a alma intelectiva tem, da maneira a mais completa, a virtude sensitiva, porque o inferior preexiste,
mais perfeitamente, no superior, como diz Dionísio. Por onde, é necessário seja misto o corpo ao qual
está unida a alma intelectiva, e possuindo, entre todos os outros, maior unidade de compleição. E é por
isso que, entre todos os outros animais, o homem tem o melhor tacto; e, dentre os homens, os que têm
melhor tacto têm melhor intelecto, sendo a prova que, os que são delicados de carne vemos serem bem
dotados de inteligência, como diz o Filósofo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. . Talvez alguém quisesse responder a esta objeção, dizendo
que o corpo do homem era incorruptível, antes do pecado. ― Mas essa resposta não seria suficiente;
porque o corpo do homem era imortal, antes do pecado, não por natureza, mas pela graça divina; pois,
do contrário, o pecado não o privaria da imortalidade, como não privou os demônios. ― E, portanto,
deve-se responder diferentemente, que, na matéria, há uma dupla condição: uma escolhida para torná-
la apta à forma, outra resultante necessariamente da disposição anterior. Assim, o artífice, para a forma
da serra, escolhe matéria férrea, apta para cortar corpos duros; mas resulta necessariamente da
matéria, que os dentes da serra possam embotar-se e ser roídos pela ferrugem. Assim, pois, à alma
intelectiva é necessário um corpo de compleição uniforme. E, quanto a ser corruptível, isso resulta
necessariamente da matéria. ― E, se alguém dissesse que Deus poderia ter evitado essa necessidade,
responde-se que, na constituição das coisas naturais, não se considera o que Deus poderia fazer, mas
sim o que exige a natureza das coisas, como diz Agostinho. Contudo, Deus proviu, ministrando, com o
dom da graça, remédio contra a morte.

RESPOSTA À SEGUNDA. ― À alma intelectiva não é necessário o corpo para a operação intelectual em si
mesma, mas para a virtude sensitiva, que exige um órgão de compleição uniforme. Por onde, é
necessário seja a alma intelectiva unida ao corpo humano e não ao simples elemento ou ao corpo misto,
no qual seria excessivo, quantitativamente, o fogo e não poderia haver uniformidade de compleição, por
causa dessa virtude ígnea excessiva. Ora, o corpo humano, de uniforme compleição, tem uma certa
dignidade, por estar longe dos contrários; e, por aí, assimila-se, de algum modo, ao corpo celeste.

RESPOSTA À TERCEIRA. ― As partes do animal, como os olhos, as mãos, a carne, os ossos e
semelhantes, não estão especificamente no animal, mas sim o todo; e, por isso, propriamente falando,
não se pode dizer que pertençam a espécies diferentes mas sim, a disposições diferentes. Ora, sendo a
alma intelectiva, embora una em essência, múltipla em virtudes; por causa da sua perfeição, precisa,
para as suas diversas operações, de disposições diversas, nas partes do corpo ao qual está unida. Por
isso, vemos que a diversidade das partes é maior nos animais perfeitos do que nos imperfeitos e, nestes,
que nas plantas.

RESPOSTA À QUARTA. ― A alma intelectiva, sendo compreensiva dos universais, tem faculdade para
infinitas causas. E, por isso, a natureza não lhe podia estabelecer determinados conhecimentos naturais,
ou ainda, determinados auxílios de defesa ou de proteção, como para os outros animais, cujas almas
tem apreensão e virtudes determinadas para causas particulares. Mas, em lugar de tudo isso, o homem
tem naturalmente a razão; e as mãos, órgãos dos órgãos, e com elas pode preparar para si instrumentos
de modos infinitos e com infinitos efeitos.

## Art. 6 — Se a alma intelectiva está unida ao corpo mediante certas disposições acidentais.
(II Cont. Gent., cap. LXXI; De Spirit. Creat., a. 3; Qu. De Anima, a. 9; II De Anima, lect. I; VIII Metaphs.,
lect. V).
O sexto discute-se assim. ― Parece que a alma intelectiva está unida ao corpo, mediante certas
disposições acidentais.

1. ― Pois, toda forma está em matéria para si própria e disposta. Ora, as disposições para a forma são
acidentes. Logo, é necessário se preintelijam, na matéria, certos acidentes, antes da forma substancial e,
portanto, antes da alma, que é urna forma substancial.

2. Demais. ― Diversas formas da mesma espécie exigem partes diversas da matéria. Ora, estas não
podem ser inteligidas, senão pela divisão das quantidades dimensivas. Logo, é necessário se intelijam
dimensões, na matéria, antes das formas substanciais, que são muitas da mesma espécie.

3. Demais. ― O espiritual se une ao corpóreo pelo contacto de virtude. Ora, a virtude da alma é a sua
potência. Logo, está unida ao corpo mediante a potência, que é um acidente.
Mas, em contrário, o acidente é posterior à substância, temporal e racionalmente, como diz Aristóteles.
Logo, não se pode compreender haja na matéria alguma forma acidental anterior à alma, que é a forma
substancial.

SOLUÇÃO. ― Se a alma estivesse unida ao corpo só como motor, nada impediria, antes, seria necessário
existir certas disposições médias entre a alma ,e o corpo, a saber: a potência, por parte da alma, com a
qual moveria o corpo; e certa disposição, por parte do corpo, que o fizesse movido da alma. ― Mas se a
alma intelectiva está unida ao corpo, como forma substancial, segundo ficou dito antes (a. 1), é
impossível haver qualquer disposição acidental entre o corpo e a alma, ou entre qualquer forma
substancial e a sua matéria. E a razão disto é que, sendo a matéria potencial, em relação a todos os atos,
numa certa ordem, é necessário que se suponha, em primeiro lugar, na matéria, aquele, dentre os atos,
que for o primeiro absolutamente. Ora, o primeiro de todos os atos é o ser. Logo, é impossível supor a
matéria como cálida ou quantitativa, antes de ter o ser em ato. Ora, este ela o tem pela forma
substancial, que dá o ser absolutamente, como já ficou dito (a. 4). Por onde, é impossível a
preexistência, na matéria, de quaisquer disposições acidentais, anteriores à forma substancial e, por
conseguinte à alma. DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. . Como resulta do que já foi dito (a. 3,
4), a forma que é mais perfeita contém, virtualmente, tudo o que pertence às formas inferiores; e,
portanto, existindo una e a mesma, aperfeiçoa a matéria segundo os diversos graus de perfeição. Ora é
uma e essencialmente a mesma a forma pela qual o homem é ser atual, corpo, vivo, animal, homem.
Pois, é manifesto, de cada gênero resultam os seus acidentes próprios. Por onde, como se supõe a
matéria perfeita, quanto ao ser, antes de se lhe supor a corporeidade, e assim por diante; também se
supõem os acidentes próprios ao ser, antes de supor-lhes a corporeidade. E, assim, pressupõem, na
matéria, disposições anteriores à forma, não quanto ao seu efeito total, mas só quanto ao efeitos
posteriores.

RESPOSTA À SEGUNDA. ― As dimensões quantitativas são acidentes resultantes da corporeidade, que é
própria a toda matéria. Por onde, a matéria já incluída na corporeidade e nas dimensões pode ser
compreendida como distinta em partes diversas, recebendo, assim, formas diversas, segundo os graus
ulteriores de perfeição. Pois, embora seja essencialmente a mesma a forma que atribui à matéria os
diversos graus de perfeição, como já se disse, todavia difere, quanto à consideração da razão.

RESPOSTA À TERCEIRA. ― A substância espiritual, unida ao corpo só como motor, unida está só pela
potência e pela virtude; mas a alma intelectiva está unida ao corpo, como forma, pelo seu ser; pois,
governa-o e move-o pela sua potência e virtude.

## Art. 7 — Se a alma está unida ao corpo do animal mediante algum outro corpo.
(II Sent., dist. I, q. 2, a. 4, ad 3; II Cont. Gent., cap. LXXI; De Spirit.Creat., a. 3; Qu. De Anima, a. 9; II De
Anima, lect. I; VIII Metaphys., lect.V).
O sétimo discute-se assim. ― Parece que a alma está unida ao corpo do animal mediante algum outro
corpo.

1. ― Pois, diz Agostinho, a alma governa o corpo pela luz, i. é, pelo fogo e pelo ar, corpos os mais
semelhantes ao espírito. Ora, sendo corpos o fogo e o ar, a alma está unida ao corpo humano mediante
outro corpo.

2. Demais. ― Aquilo que, eliminado, dissolve a união de dois seres unidos, deve ser considerado como o
termo médio entre eles. Ora, faltando o espírito, a alma separa-se do corpo. Logo, o espírito, que é um
corpo sutil, é o termo médio entre a união do corpo e da alma.

3. Demais. ― Seres muito distantes entre si não se unem senão por um ser médio. Ora, a alma
intelectiva dista muito do corpo, tanto por ser incorpórea como por ser incorruptível. Logo, resulta que
com ele está unida, mediante algum corpo incorruptível, considerado como sendo uma luz celeste, que
concilia os elementos e os reduz à unidade.
Mas, em contrário, diz o Filósofo, não se deve perguntar nem se o corpo e a alma são um só ser, nem se
o são a cera e a sua forma. Mas, assim como a forma se une à cera, sem a mediação de nenhum corpo,
assim a alma ao corpo.

SOLUÇÃO. ― Se a alma, segundo os Platônicos, estivesse unida ao corpo somente como motor, seria
necessário admitir entre a alma do homem, ou de qualquer animal, e o corpo, a intervenção de outros
corpos médios; pois, é da natureza do motor mover um corpo distante por outros médios, mais
próximos. ― Se, porém, a alma se une ao corpo como forma, segundo já foi dito (a. 1), é impossível se
faça essa união, mediante qualquer outro corpo. E a razão é que um ser é uno do mesmo modo pelo
qual é ser. Ora, a forma, sendo essencialmente ato, atualiza por si mesma um ser, sem precisar de
nenhum meio. Por onde, a unidade da coisa, composta de matéria e forma, provém da forma mesma
que, em si, se une à matéria como ato desta. Nem há nenhum outro ser que una, senão o agente, que
atualiza a matéria, como diz Aristóteles.
Donde resulta a falsidade das opiniões daqueles que supuseram corpos médios entre a alma e o corpo
do homem. ― Desses, certos Platônicos ensinavam que a alma intelectiva está naturalmente unida a um
corpo incorruptível do qual nunca se separa e, mediante esse, se une ao corpo corruptível do homem.
Outros, porém, diziam que se une ao corpo mediante o espírito corpóreo. ― Outros, ainda, que se une
mediante a luz que consideravam com corpo e com a natureza da quinta essência; de modo que, a alma
vegetativa se une ao corpo, mediante a luz do céu sidéreo; a sensível, mediante a do céu cristalino; a
intelectual, mediante a do céu empíreo. Coisas que são fictícias e ridículas; porque a luz não é corpo;
porque, a quinta essência, sendo inalterável, não entra materialmente, mas só virtualmente, na
composição do corpo misto; e porque a alma, como a forma à matéria, une-se imediatamente ao corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Agostinho se refere à alma enquanto move o corpo e,
por isso, usa da palavra governo. E é verdade, que ela move as partes mais grosseiras do corpo pelas
mais sutis; e o primeiro instrumento da virtude motora é o espírito, como diz o Filósofo.

RESPOSTA À SEGUNDA. ― Faltando o espírito, desaparece a união da alma e do corpo; não que, por
isso, ele seja médio entre ambos, mas porque desaparece a disposição pela qual o corpo está preparado
para tal união. E, contudo, o espírito é meio no mover, como primeiro instrumento do movimento.

RESPOSTA À TERCEIRA. ― A alma dista muito do corpo se se considerarem separadamente as condições
de um e de outro. Por onde, se cada qual tivesse existência separada, seria necessária a intervenção de
muitos corpos médios. Mas, como forma do corpo, a alma não têm o ser separado do ser do corpo, mas
une-se imediatamente, pelo seu ser, com ele. Assim, pois, também qualquer forma, considerada como
ato, dista imenso da matéria, ente somente potencial.

## Art. 8 — Se a alma está toda em qualquer parte de todo.
(I Sent., dist. VIII, q. 5, a. 3; II Cont. Gent., cap. LXXII; De Spirit Creat., a. 4; Qu. De Anima, a. 10).
O oitavo discute-se assim. ― Parece que a alma não está toda em qualquer parte do corpo.

1. ― Pois, o Filósofo diz: não é necessário que a alma esteja em cada parte do corpo; mas, existindo
num certo princípio do mesmo, faz viver as outras partes; pois, é-lhes simultaneamente natural
executarem o movimento próprio, pela natureza.

2. Demais. ― A alma está no corpo de que é ato. Ora, é ato do corpo orgânico. Logo, só neste pode
estar. E como não é qualquer parte do corpo humano que é corpo orgânico, a alma não está toda em
qualquer parte do corpo.

3. Demais. ― Aristóteles diz, que uma parte da alma está para uma parte do corpo assim como o
sentido da vista para a pupila; e assim, a alma toda, para o corpo todo do animal. Se, portanto, toda ela
está em qualquer parte do corpo, resulta que qualquer parte do corpo é animada.

4. Demais. ― Todas as potências da alma fundam-se na essência mesma da alma. Se, pois, a alma está
toda em qualquer parte do corpo, resulta que todas as potências da alma estão em qualquer parte do
corpo; e assim, a visão estará nos ouvidos e a audição nos olhos, o que é inadmissível.

5. Demais. ― Se em qualquer parte do corpo estivesse toda a alma, qualquer delas dependeria
imediatamente da alma. Logo, uma parte não dependeria de outra, nem seria mais importante uma que
outra, o que é manifestamente falso. Logo, a alma não está toda em qualquer parte do corpo.
Mas, em contrário, diz Agostinho: a alma, em qualquer corpo, está toda em todo ele e toda em qualquer
das partes dele.

SOLUÇÃO. ― Como já se disse em outros artigos, se a alma estivesse unida ao corpo só como motor,
poder-se-ia dizer que não estaria em qualquer parte do corpo, mas só numa, pela qual movesse as
outras. ― Mas, estando unida ao corpo corno forma, necessário é que esteja no todo e em qualquer
parte do corpo, pois, não é forma acidental do corpo, mas substancial. Ora, esta é a perfeição não só do
todo, mas de qualquer das partes. E como o todo consiste em partes, a forma daquele, que não der o
ser a cada uma destas, é um todo de composição e ordem, como a forma de uma casa; e tal forma é
acidental. Ora, sendo a alma forma substancial, necessário é que seja a forma e o ato, não só do todo,
mas de cada parte. Por onde, separada a alma, assim corno já não se poderá falar de animal ou homem,
senão equivocamente, como se fala de um animal pintado ou de pedra; assim também não se poderá
dizer tal das mãos, dos olhos, da carne ou dos ossos, segundo o Filósofo. E a prova está em que,
separada a alma, nenhuma parte do corpo tem ação própria, porque tudo o que conserva a espécie
conserva-lhe a operação. Ora, o ato está no ser de que é ato. Por onde, é necessário que a alma esteja
em todo o corpo e em qualquer parte dele.
E que em qualquer dessas partes está toda, pode-se deduzir das considerações seguintes. Sendo todo o
que se divide em partes, há uma tríplice totalidade correspondendo a tríplice divisão. Assim, há um todo
que se divide em partes quantitativas, como toda a linha ou todo o corpo. Há outro que se divide nas
partes da noção e da essência, como o definido, nas partes da definição, e o composto se resolve na
matéria e na forma. Há ainda um terceiro todo, potencial, que se divide em partes virtuais.
Ora, o primeiro modo de totalidade só por acidente poderá convir às formas; e só àquelas formas que
tenham inclinação indiferentemente para o todo quantitativo e suas partes; assim, à brancura, por
natureza, é igualmente indiferente o estar em toda a superfície e em qualquer parte da mesma; e
portanto, dividida esta, a brancura se divide por acidente. Mas a forma corno a alma, sobretudo a dos
animais perfeitos, que requer a diversidade das partes, não se relaciona igualmente com o todo e com
as partes; por onde, não se divide por acidente, i. é., pela divisão da quantidade. Logo, a totalidade
quantitativa não pode ser atribuída à alma, nem em si, nem por acidente. Mas, a totalidade da segunda
espécie considerada segundo a perfeição da noção e da essência, convém propriamente e por si às
formas. Semelhantemente, também a totalidade virtual, pois, a forma é princípio de operação.
Se, portanto, se perguntasse se a brancura está toda na superfície e em qualquer parte desta, seria
necessário distinguir; porque, se se trata da totalidade quantitativa que a brancura têm por acidente,
então, não estaria toda em qualquer parte da superfície. E o mesmo se deve dizer da totalidade virtual;
pois, mais pode ferir a vista a brancura que está em toda a superfície, do que a que está em alguma
partícula dela. Mas se se trata da totalidade da espécie e da essência, toda a brancura está em qualquer
parte da superfície.
Mas como a alma não têm totalidade quantitativa, nem em si nem por acidente, como já se disse, basta
dizer que a alma está toda em qualquer parte do corpo, quanto à totalidade da perfeição e da essência;
não, porém, quanto à totalidade da virtude, porque está em qualquer parte do corpo, não por qualquer
potência sua, mas, pela visão, nos olhos, pela audição, nos ouvidos e assim por diante.
Contudo, deve-se considerar que a alma, requerendo diversidade de partes, não se compara, do mesmo
modo, com o todo e com as partes; mas, com o todo, primariamente e por si, como com o perfectível
próprio e proporcionado; com as partes, porém, por posterioridade, enquanto elas se ordenam para o
todo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O Filósofo trata da potência motora da alma.

RESPOSTA À SEGUNDA. ― A alma é o ato do corpo orgânico, como do perfectível primeiro e
proporcionado.

RESPOSTA À TERCEIRA. ― O animal se compõe da alma e de todo o corpo, que é o seu perfectível
primeiro e proporcionado. Ora, assim, a alma não está na parte e não é necessário que à parte do
animal seja o animal.

RESPOSTA À QUARTA. ― Da potências da alma, umas excedem toda a capacidade do corpo, a saber, a
inteligência e a vontade; e de tais potências não se diz que estejam em alguma parte do corpo. Porém,
outras potências são comuns à alma e ao corpo; e não é necessário que qualquer dessas potências
esteja em toda parte onde está a alma, mas só na parte do corpo que for proporcionada à operação de
tal potência.

RESPOSTA À QUINTA. ― Diz-se que uma parte do corpo é mais importante que outra, por causa das
potências diversas de que são órgãos partes do corpo; assim, o órgão da potência mais importante é
parte mais importante do corpo; ou ainda, é parte mais importante aquela que a essa mesma potência
serve de maneira mais importante.