# Questão 119: Da propagação do homem quanto ao corpo.
Em seguida, deve-se tratar da propagação do homem, quanto ao corpo.
E sobre esta questão, dois artigos se discute:

## Art. 1 — Se algo do alimento se transforma realmente em a natureza humana.
(II Sent., disto XXX, q. 2, a. I; IV, dist. XLIV, q. I, a. 2, qª 4; Quodl. VIII, q. 3, a. I).
O primeiro discute-se assim. — Parece que nada, do alimento, se converte, realmente em a natureza
humana.

1. — Pois, diz a Escritura: Tudo o que entra pela boca passa ao ventre, e se lança depois num lugar
escuro. Ora, o que é expulso, não se transforma realmente em a natureza humana. Logo, realmente,
nada, do alimento, se transforma nessa natureza.

2. Demais. — O Filósofo distingue na carne a espécie e a matéria; e diz que a carne material advém e
desaparece. Ora, o gerado do alimento advém e desaparece. Logo, este se converte na carne material, e
não na específica. Ora, o que pertence realmente à natureza humana pertence à espécie humana. Logo,
realmente o alimento não se transforma em a natureza humana.

3. Demais. — A umidade faz parte, fundamental e realmente, da natureza humana; e uma vez perdida
não pode ser recuperada, como dizem os médicos. Ora, podê-lo-ia, se o alimento se convertesse na
umidade mesma. Logo, realmente a nutrição não se converte em a natureza humana.

4. Demais. — Se o alimento se convertesse realmente em a natureza humana, o homem não teria nada
que, perdido, não pudesse ser recuperado. Ora, a morte sobrevém ao homem por alguma perda. Logo,
o homem poderia, alimentando-se, defender-se perpetuamente contra a morte.

5. Demais. — Se o alimento se convertesse realmente em a natureza humana, o homem poderia
recuperar tudo o que perde; pois, o que nele é gerado do alimento pode perder-se e ser recuperado. Se,
pois, vivesse muito tempo, seguir-se-ia que nada do que nele existia, no princípio da sua geração,
permaneceria ao fim. E assim, um homem não seria numericamente idêntico a si mesmo, no decurso
total da sua vida; pois, a identidade numérica exige a identidade da matéria. Ora, isto é inadmissível.
Logo, o alimento não se transforma, realmente, em a natureza humana.
Mas, em contrário, diz Agostinho: Os alimentos corruptos da carne, i. é, que perderam a forma, passam
a formar os membros. Ora, a formação dos membros pertence realmente à natureza humana. Logo, os
alimentos se transformam realmente nessa natureza.

SOLUÇÃO. — Segundo o Filósofo, cada ser está para a verdade, como esta para a existência. Ora, à
natureza de um ser pertence, realmente, o que lhe pertence à constituição. Porém a natureza pode ser
considerada a dupla luz: em comum, especificamente; e individualmente. Ora, à natureza real de um
ser, considerada em comum, pertencem a forma, e a matéria comum; porém, a essa natureza,
considerada em particular, pertencem a matéria individual signada e a forma individuada por essa
matéria. Assim, a natureza humana, em comum, é, na sua realidade, constituída pela alma e pelo corpo;
mas a natureza humana real de Pedro e Martinho é uma determinada alma e um determinado corpo.
Ora, há certos seres cujas formas não podem se conservar senão numa certa matéria signada; assim, a
forma do sol que se não pode conservar senão na matéria que ela atualmente contém. E deste modo,
alguns ensinaram que a forma humana não pode conservar-se senão numa certa matéria signada,
informada por tal forma, desde o princípio, no primeiro homem; por onde, tudo quanto foi acrescen-
tado, além do que os primeiros pais transmitiram aos pósteros, não pertence realmente à natureza
humana, por não receber, por assim dizer, a forma dessa natureza. Como porém a matéria do primeiro
homem, sujeita à forma humana, multiplica-se, em si mesma, originou-se, do corpo do primeiro
homem, a multidão dos corpos humanos. E conforme aos desta opinião, o alimento não se converte
realmente em a natureza humana; mas o consideram como um certo fomento para que a natureza,
resistindo à ação do calor natural, este não lhe consuma a umidade fundamental. Assim, mistura-se o
chumbo ou o estanho com a prata, para esta não ser consumida pelo fogo.
Mas esta opinião é irracional por muitas razões. — Primeiro, porque, pela mesma razão, uma forma
pode ser realizada numa certa matéria e abandonar a matéria própria, e, portanto, todos os seres
susceptíveis de geração são também susceptíveis de corrupção, é inversamente. Ora, é manifesto que a
forma humana pode separar-se de determinada matéria que lhe está sujeita; do contrário, o corpo
humano não seria corruptível. Logo, pode unir-se a outra matéria, convertendo-se então realmente, em
algo de novo em a natureza humana. — Segundo, em todos os seres, nos quais a matéria está
compreendida toda num só indivíduo, este é especificamente uno; como claramente se vê no sol, na
lua, e seres semelhantes. — Terceiro, porque a matéria só pode multiplicar-se quantitativamente, como
nos seres rarefeitos, cuja matéria é susceptível de maiores dimensões, ou substancialmente. Pois,
permanecendo só a mesma substância material, não se pode dizer que a matéria multiplica-se, porque o
ser idêntico a si mesmo não constitui multidão, sendo esta, necessariamente causada pela divisão. Por
onde, é necessário que a matéria receba qualquer outra substância, por criação ou por conversão de
outra causa na dita matéria. Donde se conclui que matéria nenhuma pode se multiplicar, a não ser pela
rarefação, como quando, da água, resulta o ar; ou pela adição de outra causa, como quando o fogo se
multiplica pela adição de lenha; ou por criação de matéria. Ora, é manifesto, que a matéria, nos corpos
humanos, não se multiplica pela rarefação, porque então os corpos dos homens, em idade perfeita,
seriam mais imperfeitos que os das crianças. Nem ainda por criação de matéria nova, porque, segundo
Gregório, todas as causas foram criadas simultaneamente, quanto à substância material, embora, não,
quanto à forma específica. Donde se conclui que a multiplicação do corpo humano só se dá porque o
alimento nele se converte realmente. — Quarto, porque o homem, não diferindo dos animais e das
plantas, pela alma vegetativa, resultaria que também os corpos destas e daqueles não se multiplicariam
pela conversão do alimento no corpo nutrido, mas por uma certa multiplicação. O que não pode ser
natural, porque a matéria por natureza não é susceptível senão de uma certa quantidade; e nada cresce
naturalmente senão pela rarefação, ou pela conversão de outra coisa, nessa que cresce. E então, todas
as operações gerativas e nutritivas, que constituem as virtudes naturais, seriam miraculosas. O que é
absolutamente inadmissível.
E por isso, outros disseram, que a forma humana pode começar a existir em alguma outra matéria,
considerada a natureza humana em comum; não porém considerada num determinado indivíduo, no
qual a forma humana permanece fixa em determinada matéria, na qual foi primàriamente impressa,
quando gerado o indivíduo, de modo que este nunca a abandona até a sua corrupção final. E dizem que
essa matéria faz parte, principal e realmente da natureza humana. Mas, como tal matéria não tem a
quantidade devida, forçoso é que advenha outra, pela conversão do alimento, que seja suficiente para o
crescimento necessário. E dizem que essa matéria faz parte, secundária e realmente, da natureza
humana, porque não é necessária para o ser primeiro do indivíduo, mas para o seu aumento. E
portanto, tudo o mais, proveniente do alimento, não faz parte, verdadeira e propriamente falando, da
natureza humana.
Mas esta opinião também é inadmissível. — Primeiro, porque considera a matéria dos corpos vivos
como se fosse dos corpos inanimados, que, embora tenham a virtude de gerar o especificamente
semelhante, não têm, contudo, a de gerar o individualmente semelhante, virtude que, nos viventes, é a
nutritiva. Do contrário, a virtude nutritiva não acrescentaria nada aos corpos vivos e o alimento não se
converteria realmente em a natureza deles. — Segundo, porque, como já se disse, a virtude ativa do
sêmen é uma impressão derivada da alma geratriz. E portanto, não pode ter maior virtude de ação, do
que a alma mesma, da qual deriva. Se, pois, da virtude do sêmen, uma certa matéria adquire
verdadeiramente a forma da natureza humana, com maior razão a alma pode, na nutrição conjunta,
imprimir, pela potência nutritiva, a verdadeira forma da natureza humana. — Terceiro, porque a
nutrição é necessária, não só para o crescimento — do contrário, não mais seria necessária, terminado
este — mas também para a restauração do perdido pela ação do calor natural. Pois, não haveria
restauração se o gerado do alimento, não substituísse o perdido. Por onde, se o que primitivamente
existia fazia verdadeiramente parte da natureza humana, assim também o faz o que é gerado do
alimento. Por onde, segundo outros, deve-se dizer, que o alimento converte-se realmente, em a na-
tureza humana, transformando-se nas espécies da carne, dos ossos e demais partes. E isto mesmo diz o
Filósofo, quando escreve, que o alimento nutre porque é carne em potência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Senhor não disse que a totalidade do que entra pela
boca é expulso organicamente, mas, tudo, no sentido em que, em cada alimento, há algo de impuro,
expulso organicamente. — Ou se pode dizer que tudo o que é gerado do alimento pode também ser
eliminado pelo calor natural, e expulso por certos poros ocultos, como explica Jerônimo.

RESPOSTA À SEGUNDA. — Alguns, pela carne específica entenderam aquilo que primeiro recebe a
espécie humana e que provém do gerador; e dizem que isso permanece enquanto durar o indivíduo. Ao
passo que a carne material, dizem, é gerada do alimento e não permanece sempre, mas, assim como
veio a existir, assim deperece. — Esta opinião, porém, vai contra a intenção de Aristóteles, que diz, no
lugar citado: assim como se dá com os seres que têm a espécie material, p. ex., o vegetal e a pedra,
assim também com a carne, uma parte é específica e outra material. Ora, é manifesto que a referida
distinção não tem lugar nos seres inanimados, não gerados do sêmen, e que não se nutrem. E demais,
como o gerado, do alimento, é assimilado por mistura, pelo corpo, que se nutre, — como a água
misturada com o vinho, segundo o próprio exemplo do Filósofo — não pode a natureza, do que
sobrevém, diferir da do que o recebe, porque já verdadeiramente a mistura operou a unidade. Por
onde, nenhuma razão há de ser a carne material consumida pelo calor natural, e a específica,
permanecer. — E portanto, deve-se dizer, de outro modo, que a distinção do Filósofo não se refere a
carnes diversas, mas à mesma, segundo diversos pontos de vista. Assim, considerada a carne especifi-
camente, i. é, no que tem de formal, então permanece sempre, porque sempre lhe permanece a
natureza e a disposição natural. Considerada, porém, materialmente, não permanece, mas se consome
e restaura, lentamente, como se vê no fogo da fornalha, cuja forma permanece, ao passo que a matéria
consumida lentamente, é substituída por outra.

RESPOSTA À TERCEIRA. — À umidade fundamental pertence tudo o em que se funda a virtude
específica; e perdida, não pode ser readquirida, como se se amputasse a mão, o pé ou algo semelhante.
Mas a umidade nutritiva é a que ainda não chegou a adquirir perfeitamente a natureza específica,
estando em via para esta, como o sangue e outras semelhantes. Por onde, perdida essa umidade, não
desaparece, mas permanece fundamentalmente, a virtude específica.

RESPOSTA À QUARTA. — Toda virtude do corpo passível enfraquece pela ação contínua, porque esses
agentes também são paciente,s. E por isso, a virtude assimiladora é tão forte, no princípio que pode
assimilar, não só o suficiente para a restauração das perdas, mas também para o crescimento. Mais
tarde, porém, só pode assimilar o suficiente para restaurar as perdas, e então cessa o crescimento.
Finalmente, nem isso o pode, e então começa o deperecimento, até que, faltando a virtude, totalmente
o animal morre. Assim como a virtude do vinho que assimila a água que lhe é misturada, a pouco e
pouco, pela mistura da água, se enfraquece, até tornar-se aquoso, como exemplifica o Filósofo.

RESPOSTA À QUINTA. — Como diz o Filósofo, quando uma certa matéria, em si, converte-se, em fogo,
então se diz que este existe de novo; quando porém ela se converte no fogo preexistente, diz-se que
este é alimentado. Por onde, se uma certa matéria, simultaneamente perder de todo, a espécie ígnea, e
outra se converter em fogo, este será outro, numericamente. Se porém lentamente queimar-se um
lenho, e se lhe substituir outro, e assim por diante, até que o primeiro fique totalmente consumido,
permanecerá sempre o mesmo fogo, numericamente, porque sempre o que é acrescentado se
transforma no fogo preexistente. E o mesmo, deve entender-se dos corpos vivos, nos quais, pela nutri-
ção, é recuperado o consumido pelo calor natural.

## Art. 2 — Se o sêmen é um alimento supérfluo ou faz parte da substância do gerador.
(II. Sent., dist. XXX. q. 2. a. 2).
O segundo discute-se assim. — Parece que o sêmen não é um alimento supérfluo, mas faz parte da
substância do gerador.

1. — Pois, diz Damasceno, que a geração é a obra da natureza, pela qual, da substância do gerador é
produzido o gerado. Ora, o gerado o é, do sêmen. Logo, este faz parte da substância do gerador.

2. Demais. — O filho se assimila com o pai, porque deste recebeu alguma coisa. Ora, se o sêmen, do
qual o ser é gerado, é um alimento supérfluo, ele nada receberia do avô e dos predecessores, nos quais
tal alimento não existia, de nenhum modo. Logo, não teria relações com o avô e os demais ancestrais,
como não tem com os outros homens.

3. Demais. — O gerador alimenta-se às vezes da carne do boi, do porco, e de animais semelhantes. Se,
pois, o sêmen fosse um alimento supérfluo, o homem gerado do sêmen teria maior afinidade com o boi
e o porco do que com o pai e os outros consangüíneos.

4. Demais. — Agostinho diz, que nós existimos em Adão, não só pelo princípio seminal, mas também
pela substância do corpo. Ora, tal não se daria, se o sêmen fosse alimento supérfluo. Logo, não é tal.
Mas, em contrário, o Filósofo prova abundantemente que o sêmen é um alimento supérfluo.

SOLUÇÃO. — Esta questão depende, de certo modo, do que já foi estabelecido. Se, pois, a natureza
humana tem a virtude de comunicar a sua forma à matéria, dela diferente, não só relativamente a outro
ser, como relativamente a si mesma, manifesto é que o alimento, dissemelhante a princípio, torna-se
semelhante pela forma comunicada. Ora, é ordem natural que um ser passe gradativamente da
potência para o ato. Por onde, vemos que os seres gerados são a princípio imperfeitos, aperfeiçoando-
se em seguida. Ora, é claro que o comum está para o próprio e o determinado, como o imperfeito, para
o perfeito; e por isso, vemos que na geração do animal antes é gerado este, que o homem ou o cavalo.
Assim, pois, também o alimento, em si, primeiro recebe uma virtude comum, em relação a todas as
partes do corpo e, afinal, é determinado a esta parte ou aquela outra.
Ora, não é possível considerar como sêmen aquilo que já se converteu resolvendo-se na substância dos
membros. Pois, o que se resolveu, se não conservasse nada da natureza do ser donde proveio, então
estaria, separando-se da natureza do gerador, em via de corrupção; e, portanto, não teria a virtude de
provocar a natureza do todo, senão só a da parte. A menos que alguém diga que se separou de todas as
partes do corpo, conservando a natureza de todas elas; porque então o sêmen seria um como
animálculo em ato, e a geração animal se daria por divisão, assim como o lodo é gerado do lodo e como
acontece com os animais que vivem, cortados em partes. Mas isto é inadmissível.
Conclui-se pois daqui, que o sêmen foi separado não do todo atual, mas do todo potencial; e tem a
virtude de produzir todo o corpo, derivada da alma do gerador, como já se disse. E o que é potencial, em
relação ao todo, é o que é gerado do alimento, antes de se converter na substância dos membros; e daí
é derivado o sêmen. Por onde se diz que a virtude nutritiva serve à geração; pois, o que foi assimilado
por essa virtude, a virtude geradora o recebe como sêmen. Para prova do que o Filósofo diz que os
animais de copo grande, que necessitam de muito alimento, têm pouco sêmen, relativamente ao
tamanho do corpo, e pouca geração; e, semelhantemente, os homens gordos têm pouco sêmen, pela
mesma causa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A geração faz parte da substância do gerador, nos
animais e nas plantas, porque o sêmen tira a sua virtude da forma do gerador, e é potencial em relação
à substância deste.

RESPOSTA À SEGUNDA. — A assimilação do gerador ao gerado não se funda na matéria, mas na forma
do agente, que gera o que lhe é semelhante. Por onde, não é necessário, para que alguém seja
relacionado com o avô, que neste existisse a matéria corpórea do sêmen, mas que tenha alguma virtude
procedente do avô, mediante o pai.
E o mesmo se deve RESPONDER À TERCEIRA OBJEÇÃO. — Pois, a afinidade não se funda na matéria,
mas é, antes, derivada da forma.

RESPOSTA À QUARTA. — Pelas palavras de Agostinho não se deve entender que em Adão existia em ato
próximo a virtude seminal de um determinado homem, ou a substância do seu corpo. Mas que ambas
estavam em Adão originàriamente. Pois, a matéria corpórea ministrada pela mãe, e a que ele chama
substância do corpo, deriva originalmente, de Adão; e semelhantemente, a virtude ativa existente no
sêmen do pai, que é o princípio seminal próprio de um determinado homem.
Mas diz-se que Cristo estava em Adão, quanto à substância corpórea, não porém, quanto ao princípio
seminal. Porque a matéria do seu corpo, ministrada pela Virgem Maria, era derivada de Adão; não
porém a virtude ativa, porque o corpo de Cristo não foi formado por virtude do sêmen viril, mas por
obra do Espírito Santo. Pois, tal era a origem que convinha a Deus, bendito sobre todas as causas pelos
séculos dos séculos. Amém.

FIM DA PRIMEIRA PARTE.