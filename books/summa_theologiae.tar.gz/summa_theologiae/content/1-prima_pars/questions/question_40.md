# Questão 40: Das Pessoas quanto às relações ou propriedades.
Em seguida, vamos tratar das Pessoas quanto às relações ou propriedades. E discutem-se quatro artigos:

## Art. 1 — Se, em Deus, a relação é o mesmo que Pessoa.
(I Sent., dist. XXVI, q. 2, a. 1; dist. XXXIII, a. 2; Compend. Theol., cap. LXVII).
O primeiro discute-se assim. – Parece que em Deus, a relação não é o mesmo que pessoa.

1. – Pois, entre coisas idênticas, multiplicada uma, também as outras se multiplicam. Ora, numa mesma
pessoa podem existir várias relações. Assim, na Pessoa do Pai há a paternidade e a espiração comum.
Ainda mais: pode uma só relação existir em duas pessoas; assim a espiração comum existe no Pai e no
Filho. Logo, relação não é o mesmo que pessoa.

2. Demais. – Nada existe em si mesmo, segundo o Filósofo. Ora, a relação existe na pessoa. Nem se pode
dizer, que o seja em razão de identidade; porque, assim, existiria também na essência. Logo, a relação
ou propriedade e pessoa não são o mesmo, em Deus.

3. Demais. – Todas as coisas entre si idênticas, o são de modo tal que tudo o que for predicado de uma
sê-lo-á também das outras. Ora, nem tudo o que é predicado da pessoa o é também da propriedade.
Assim, dizemos que o Pai gera, sem dizermos que a paternidade seja gerativa. Logo, a propriedade não é
o mesmo que pessoa, em Deus.
Mas, em contrário, em Deus não difere – o que é – do pelo que é, como se vê em Boécio. Ora, o Pai é
Pai. E pela paternidade. Logo, é o mesmo que a paternidade. E pela mesma razão as outras
propriedades identificam-se com as pessoas.

SOLUÇÃO. – Nesta matéria há diversas opiniões. Uns disseram, que as propriedades nem são pessoas
nem estão nas pessoas. E a isso foram levados pelo modo de significar das relações, que não significam
o que está num sujeito, mas, antes, o que se refere a um sujeito. E por isso disseram que asrelações são
de proveniência extrínseca, como já expusemos. – Mas, como a relação, sendo uma realidade em Deus,
é a própria essência, e a essência é o mesmo que pessoa, como do sobredito resulta, conclui-se
necessariamente, que relação é o mesmo que pessoa.
Outros, porém, considerando esta mesma identidade, disseram, que as propriedades são pessoas, mas,
não estão nas pessoas, porque admitiam propriedades em Deus só como um modo de falar, segundo já
vimos. Ora, é necessário admitirmos propriedades em Deus, como demonstramos, que têm significação
abstrata, como formas das pessoas. Por onde, sendo da essência da forma o existir no ser ao qual per-
tence, é necessário admitir que as propriedades existem nas pessoas e, contudo, são as pessoas; assim
como dizemos estar em Deus a essência, que, todavia, é Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A pessoa e a propriedade são idênticas realmente, mas
diferem logicamente. E por isso não é necessário que, multiplicada uma, se multiplique a outra. Mas
devemos saber que, por causa da divina simplicidade, distingue-se dupla identidade real em Deus, em
relação a coisas, que diferem nas criaturas. Pois, por excluir a divina simplicidade a composição de
forma e de matéria, segue-se que em Deus identifica-se o abstrato com o concreto, como divindade e
Deus. E como a divina simplicidade exclui a composição de sujeito e de acidente, segue-se que tudo o
que é atribuído a Deus o é à essência; por isso, sabedoria e virtude identificam-se em Deus, por
existirem ambas na divina essência. Ora, em virtude desta dupla identidade, a propriedade em Deus é o
mesmo que pessoa. Porque as propriedades pessoais são o mesmo que as pessoas, pela mesma razão
por que o abstrato é o mesmo que o concreto. Pois, são aspróprias pessoas subsistentes, como a
paternidade é o próprio Pai; a filiação, o Filho, e a processão, o Espírito Santo. Porém, as propriedades
não pessoais identificam-se com as pessoas por outra razão de identidade, em virtude da qual o que é
atribuído a Deus é a sua essência. Quanto à espiração comum ela identifica-se com a pessoa do Pai e
com a do Filho; não que seja uma pessoa por si subsistente, mas assim como essa essência existe em
duas pessoas, assim também, uma propriedade, como dissemos.

RESPOSTA À SEGUNDA. – Dizemos que as propriedades estão na essência só a modo de identidade. Nas
pessoas, porém, dizemos estarem a modo de identidade, não só realmente, mas também quanto ao
modo de significar, como a forma está no suposto. Logo, as propriedades determinam e distinguem as
pessoas, não porém, a essência.

RESPOSTA À TERCEIRA. – Os particípios e as palavras nocionais significam atos nocionais. Ora, os atos
pertencem aos supostos. As propriedades, porém, não significam supostos, mas, formas destes. Por
onde repugna, pelo seu modo de significar, que os particípios e as palavras nocionais se prediquem das
propriedades.

## Art. 2 — Se as Pessoas se distinguem pelas relações.
(I Sent., dist. XXVI, q. 2, a. 2; IV Cont. Gent., cap. XXIV; De Pot. q. 8, a. 3; q. 9, a. 4, ad 15; Quodl.. IV, q. 4,
a. 2).
O segundo discute-se assim. – Parece que as pessoas não se distinguem pelas relações.

1. – Pois, os seres simples se distinguem por si mesmos. Ora, as Pessoas divinas são simples por
excelência. Logo, distinguem-se por si mesmas e não, pelas relações.

2. Demais. – Nenhuma forma se distingue a não ser pelo seu gênero. Assim, o branco não se distingue
do preto senão pela qualidade. Ora, a hipóstase significa o indivíduo, no gênero da substância. Logo, as
hipóstases se não podem distinguir pelas relações.

3. Demais. – O absoluto é anterior ao relativo. Ora, a distinção primária é a das divinas Pessoas. Logo,
estas se não distinguem pelas relações.

4. Demais. – O que pressupõe distinção não pode ser deste primeiro princípio. Ora, a relação pressupõe
a distinção, porque entra na definição desta; pois, é próprio do relativo o referir-se a outro. Logo, o
primeiro princípio distintivo em Deus não pode ser relação.
Mas, em contrário, diz Boécio, que só a relação multiplica a Trindade das divinas Pessoas.

SOLUÇÃO. – Quaisquer seres, que têm algo de comum, hão de necessariamente ter também algum
distintivo. Por onde, convindo as três Pessoas pela unidade de essência, é necessário inquirir algo que as
distinga para serem várias. Ora, duas diferenças há entre as divinas Pessoas, a saber, a de origem e a
relação, que embora não difiram realmente, diferem contudo pelo modo de significar. Pois, a origem
significa um ato, como geração; e a relação, uma forma, como paternidade.
Certos, porém, atendendo a que a relação resulta do ato, disseram que as hipóstases, em Deus, se
distinguem pela origem; assim dizemos que o Pai se distingue do Filho enquanto aquele gera e este é
gerado. Porém as relações ou propriedades manifestam conseqüentemente as distinções das hipóstases
ou das pessoas; assim como nas criaturas as propriedades manifestam as distinções dos indivíduos, que
se fazem por princípios materiais.
Mas esta opinião se não pode sustentar, por duas razões. – Primeiro porque, para serem duas coisas
consideradas distintas, é necessário essa distinção ter um fundamento intrínseco a ambas; assim, as
criaturas se distinguem pela matéria ou pela forma. Ora, a origem de um ser não significa nada de
intrínseco, mas como um ponto de partida, de um termo, e como chegada a outro. Assim, a geração
significa a tendência para o ser gerado e a procedência do gerador. Por onde, não é possível o gerado e
o gerador se distinguirem só pela geração, mas hão de distinguir por sinais existentes tanto no gerador
como no gerado. Ora, na Pessoa divina não se podem conceber outras realidades além da essência e da
relação ou propriedade. Donde, convindo pela essência, resulta que as Pessoas divinas se distinguem
pelas relações umas das outras. – Segundo, porque a distinção, nas Pessoas divinas, não se deve
entender como algo de comum, que se divide, pois a essência comum permanece indivisa; mas é
necessário que as próprias distinções constituam realidades distintas. Pois, as relações ou propriedades
distinguem ou constituem hipóstases ou pessoas por serem as próprias pessoas subsistentes; assim, a
paternidade é o Pai e a filiação, o Filho, por não diferir em Deus, o abstrato do concreto. Mas, contra a
noção de origem é que constituam hipóstase ou pessoa. Porque a origem, no sentido atual significa uma
procedência da pessoa subsistente e, portanto, a pressupõe. Porém em sentido passivo, como
natividade, significa a tendência para a pessoa subsistente, que ainda não constitui.
Por onde, melhor se dirá, que as pessoas ou hipóstases se distinguem antes pelas relações do que pela
origem. Pois embora se distingam de um outro modo, todavia, primária e mais principalmente se
distinguem pelas relações, segundo o modo de entender. Por isso, o nome de Pai não somente significa
a propriedade, mas também a hipóstase; mas o nome de Gerador ou Generante significa somente a
propriedade. Porque o nome de pai significa a relação distintiva e constitutiva da hipóstase; porém, o
nome de Generante ou Gerador significa a origem, que não é distintiva e constitutiva da hipóstase.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As Pessoas são as próprias relações subsistentes. Por isso
não repugna à simplicidade das divinas Pessoas o serem distintas pelas relações.

RESPOSTA À SEGUNDA. – As Pessoas divinas não se distinguem pelo ser no qual subsistem, nem por
nada de absoluto; mas quanto sujeitos de relações. Para distinguir basta a relação.

RESPOSTA À TERCEIRA. – Quanto mais primária a relação, tanto mais próxima da unidade e, portanto,
deve ser mínima. Logo, a distinção das Pessoas não deve se fundar senão no que minimamente as
distingue, a saber, na relação.

RESPOSTA À QUARTA. – A relação pressupõe a distinção dos supostos, quando é acidente; mas se a
relação for subsistente não pressupõe, mas implica a distinção. Quando pois, se diz, que é próprio ao ser
relativo o referir-se a outro, por outro se entende o correlativo, que não lhe é anterior, mas, simultâneo,
por natureza.

## Art. 3 — Se, abstraídas das Pessoas, pelo intelecto, as propriedades ou as relações ainda permanecem as hipóstases.
(I Sent., dist. XXVI, q. 1, a. 2; De Pot., q. 8, a. 4; Compend. Theol., cap. IX).
O terceiro discute-se assim. – Parece que, abstraídas das pessoas, pelo intelecto, as propriedades ou
as relações, ainda permanecem as hipóstases.

1. – Pois, aquilo ao que alguma coisa se refere, por adição, pode ser concebido, mesmo depois de
separada essa coisa. Assim, animal pode ser concebido, mesmo separado de racional. Ora, a pessoa se
refere à hipóstase por adição; pois, a pessoa é a hipóstase, com propriedade distinta, que respeita à
dignidade. Logo, removida, da pessoa, a propriedade pessoal, ainda é concebível a hipóstase.

2. Demais. – Não é pela mesma razão, que o Pai é Pai e é alguém. Pois, sendo Pai pela paternidade, se
por esta também fosse alguém, seguir-se-ia, que o Filho, em quem não há paternidade, não seria
ninguém. Removida pois pelo intelecto a paternidade, do Pai, ainda lhe resta o ser alguém, que é o ser
hipóstase. Logo, removida a propriedade, da pessoa, permanece a hipóstase.

3. Demais. – Agostinho ensina: Dizer ingênito não é o mesmo que dizer Pai; pois, mesmo que não tivesse
gerado o Filho, nada impediria chamar-lhe ingênito. Ora, se não tivesse gerado o Filho não teria a
paternidade, Logo, removida esta, ainda permanece a hipóstase do Pai, como ingênita.
Mas, em contrário, diz Hilário: Nada tem o Filho, que não seja nascido. Pois, pela natividade é que é
Filho. Logo, removida a filiação, não permanece a hipóstase do Filho. E o mesmo se dá com as outras
Pessoas.

SOLUÇÃO. – Dupla é a abstração feita pelo intelecto. Uma pela qual o universal é abstraído do
particular; assim, animal, de homem. Outra, pela qual a forma é abstraída da matéria; assim a forma do
círculo é abstraída, pelo intelecto, de toda matéria sensível.
Ora, entre estas abstrações há a seguinte diferença. Na que se funda no universal e no particular, não
permanece aquilo do que se fez a abstração; assim, removida do homem a diferença de racional, já não
permanece, no intelecto, a idéia de homem, mas somente, a de animal. Porém, na abstração, que
separa a forma da matéria, ambas permanecem no intelecto; assim, abstraindo do ar a forma do circulo,
permanece separadamente em nosso intelecto tanto o conceito de círculo como o de ar. Ora, em Deus
não há realmente universal nem particular, nem forma nem matéria; contudo, segundo o nosso modo
de falar, existe em Deus alguma semelhança de tais coisas; e nesse sentido Damasceno diz, que a
substância é comum, porém a hipóstase é particular.
Se, pois, nos, referimos à abstração fundada no universal e no particular, então, removidas as
propriedades, permanece no intelecto a essência comum;não, porém, a hipóstase do Pai, que é por
assim dizer particular. Se, porém, nos referimos à abstração pela qual a forma se separa da matéria,
então, removidas as propriedades não pessoais, permanece o conceito das hipóstases e das pessoas,
assim como, removido do Pai, pelo nosso intelecto, o ser ingênito ou espirante, permanece a hipóstase
ou a pessoa do Pai.
Mas, removida pelo intelecto a propriedade pessoal, elimina-se o conceito de hipóstase. Pois, as
propriedades pessoais não se entendem acrescentadas às hipóstases divinas, como a forma, ao sujeito
preexistente, mas essas propriedades implicam em si os supostos, sendo elas próprias pessoas
subsistentes; assim, a paternidade é o próprio Pai. Pois, a hipóstase, sendo substância individual,
significa algo de distinto, em Deus. Ora, sendo a relação a que distingue e constitui as hipóstases, como
vimos (a. 2), resulta que, removidas pelo intelecto as relações pessoais, não permanecem as hipóstases.
Mas, como dissemos (Ibid), alguns ensinam que as hipóstases, em Deus, não se distinguem pelas
relações, mas somente pela origem; de modo que se entenda ser o Pai uma hipóstase, por não provir de
outro; o Filho, porém, por provir de outro, por geração. Mas as relações acrescentadas, sendo como
propriedades, que respeitam a dignidade constituem a essência da pessoa e por isso se chamam
pessoais. Donde, removidas pelo intelecto tais relações, permanecem certamente as hipóstases; não
porém as pessoas.
Mas isto não pode ser, por duas razões. Primeiro, porque as relações distinguem e constituem as
hipóstases, como já demonstramos (Ibid). Segundo, porque toda hipóstase de natureza racional é
pessoa, como é claro pela definição de Boécio: Pessoa é uma substância individual de natureza racional.
Por onde, para haver hipóstase, e não pessoa, seria necessário abstrairmos a racionalidade, da natureza,
não, porém, a propriedade, da pessoa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A pessoa não acrescenta, além da hipóstase, nenhuma
propriedade distintiva em sentido absoluto; mas, uma propriedade distintiva concernente à dignidade;
pois, tudo isso devemos admitir em lugar de uma diferença. À dignidade, porém, pertence a
propriedade distintiva, enquanto concebida como subsistente em a natureza racional. Por isso,
removida da pessoa, a propriedade distintiva, não permanece a hipóstase, que permaneceria se fosse
eliminada da natureza a racionalidade. Pois, tanto é substância individual a pessoa como a hipóstase;
donde, em Deus, da essência de ambos é a relação distintiva.

RESPOSTA À SEGUNDA. – Pela paternidade, não somente o Pai é Pai, mas é também pessoa e é alguém,
ou hipóstase. Sem, contudo, seguir-se que o Filho não seja ninguém ou hipóstase, como se não segue
que não seja pessoa.

RESPOSTA À TERCEIRA. – A intenção de Agostinho não foi dizer, que a hipóstase do Pai permaneça
como ingênita, removida a paternidade; como se a inascibilidade constituísse e distinguisse essa
hipóstase do Pai. Pois tal não pode ser, porque ser ingênito, não implicando nenhum acréscimo, é
expressão empregada negativamente, como diz o próprio Agostinho. Mas fala em geral; pois, nem todo
ingênito é o Pai. Removida, pois, a paternidade, não permanece em Deus, a hipóstase do Pai, como o
que odistingue das outras Pessoas, mas como o que o distingue das criaturas, segundo entendem os
Judeus.

## Art. 4 — Se os atos nocionais se preinteligem às propriedades.
(I Sent., dist. XXVII, q. 1, a. 2; De Pot., q. 8. a. 3, ad 7; q. 10, a. 3; Compend. Theol., cap. LXIII).
O quarto discute-se assim. – Parece que os atos nocionais se preinteligem às propriedades.

1. – Pois, diz o Mestre das Sentenças, que o Pai sempre é, porque sempre gerou o Filho. E assim, parece
que a geração, intelectualmente, precede à paternidade.

2. Demais. – Toda relação pressupõe, no intelecto, aquilo no que se funda; p. ex., a igualdade supõe a
quantidade. Ora, a paternidade é uma relação fundada na ação chamada geração. Logo, a paternidade
pressupõe a geração.

3. Demais. – A geração ativa está para a paternidade como a natividade, para a filiação. Ora, a filiação
pressupõe a natividade, pois, o Filho o é porque nasceu. Logo, também a paternidade pressupõe a
geração.
Mas, em contrário. – A geração é obra da pessoa do Pai. Ora, esta é a paternidade que a constitui. Logo,
a paternidade é anterior, conceptualmente, à geração.

SOLUÇÃO. – Segundo os que ensinam que as propriedades não distinguem e não constituem hipóstases,
mas manifestam as hipóstases distintas e constituídas, deve-se concluir, absolutamente, que as
relações, pelo modo de serem inteligidas, são consecutivas aos atos nocionais; de maneira que podemos
dizer, em sentido absoluto – porque gera, é Pai.
Mas, supondo que as relações distingam e constituam hipóstases, em Deus, é necessário distinguirmos.
Porque a palavra origem tem, em Deus, significação ativa e passiva. Ativa, como quando a geração se
atribui ao Pai, e a espiração considerada como ato nocional, se atribui ao Pai e ao Filho.Passiva, como
quando a natividade se atribui ao Filho e a processão, ao Espírito Santo. Ora, a origem, com significação
passiva, precede, absoluta e conceitualmente falando, às propriedades das pessoas procedentes,
mesmo às pessoais; porque origem, em tal sentido, considera-se como significando a tendência (via)
para a pessoa constituída pela propriedade.Semelhantemente, a origem, em sentido ativo, é anterior,
pelo intelecto, à relação da pessoa originante, que não é pessoal. Assim, o ato nocional da espiração,
pelo intelecto, precede a propriedade relativa inominada, comum ao Pai e ao Filho.
Mas, a propriedade pessoal do Pai pode ser considerada a dupla luz. De um modo, como relação, e
assim, ainda uma vez, conceitualmente pressupõe o ato nocional; porque a relação, como tal, funda-se
no ato. De outro modo, enquanto constitutiva da pessoa; e assim é necessário, que a relação se
preintelija ao ato nocional, como a pessoa agente se preintelige à ação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Quando o Mestre das Sentenças diz – porque gera, é Pai
– toma-se a denominação de Pai como designando somente a relação, e não, como exprimindo a pessoa
subsistente; porque, do contrário, seria necessário, inversamente, dizer – porque é Pai, gera.

RESPOSTA À SEGUNDA. – A objeção procede no tocante à paternidade, como relação, e não, como
constitutiva da pessoa.

RESPOSTA À TERCEIRA. – A natividade é a tendência (via) para a pessoa do Filho. Logo, conceitualmente
falando, precede à filiação, mesmo enquanto esta é constitutiva da pessoa do Filho. Mas a geração ativa
é considerada como nascendo da pessoa do Pai; e portanto pressupõe a propriedade pessoal do Pai.