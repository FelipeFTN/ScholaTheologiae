# Questão 36: Da pessoa do Espírito Santo
Em seguida devemos tratar do que se refere à pessoa do Espírito Santo; o qual, não somente assim se
chama, mas também, Amor e Dom de Deus.
Assim sobre o Espírito Santo, discutem-se quatro artigos:

## Art. 1 — Se o nome de Espírito Santo é nome próprio de alguma das pessoas divinas.
(I Sent., dist. X, a. 4; I Cont. Gent., cap. XIX; Compend. Theol., cap. XLVI, XLVII).
O primeiro discute-se assim. – Parece que o nome de Espírito Santo não é nome próprio de nenhuma
das Pessoas divinas.

1. – Pois, nenhum nome comum às três Pessoas é próprio de qualquer delas. Ora, o nome Espírito
Santo é comum às três Pessoas. Assim, Hilário mostra que o Espírito Santo de Deus, umas vezes,
significa o Pai, como quando diz a Escritura (Is 61, 1): O Espírito do Senhor repousou sobre mim, outras,
o Filho, como quando diz (Mt 12, 28): Lanço fora os demônios pela virtude do Espírito de Deus,
mostrando que expulsa os demônios pelo poder da sua natureza; outras ainda, o Espírito Santo, como
neste lugar (Jl 2, 28): Eu derramarei o meu espírito sobre toda a carne. Logo, o nome de Espírito Santo
não é próprio de nenhuma das Pessoas divinas.

2. Demais. – Os nomes das Pessoas divinas predicam-se relativamente, como afirma Boécio. Ora, o
nome de Espírito Santo não se predica relativamente. Logo, não é próprio de Pessoa divina.

3. Demais. – Por ser nome de uma das Pessoas divinas, o Filho não se pode predicar de qualquer. Ora,
diz-se espírito deste ou daquele homem, como se vê pela Escritura (Nm 11, 17): Disse o Senhor a
Moisés: Tirarei do teu espírito e lho darei a eles; e noutro lugar (IV Rg 2, 15): O espírito d’Elias repousou
sobre Eliseu. Logo, Espírito Santo não parece ser nome próprio de nenhuma das Pessoas divinas.
Mas, em contrário, a Escritura (1 Jo 5, 7): São três os que dão testemunho no céu: O Pai, o Verbo e o
Espírito Santo. Pois, como diz Agostinho, quando se pergunta – Que três? – a resposta é – As três
Pessoas. Logo, Espírito Santo é nome de Pessoa divina.

SOLUÇÃO. – Havendo em Deus duas processões, a que é ao modo do amor não tem nome próprio,
como dissemos. Por onde, as relações fundadas nessa processão são inominadas, como também
dissemos. E por isso, o nome da Pessoa procedente desse modo não tem nome próprio, pela mesma
razão. Mas, isso como o falar usual aplicou certos nomes para significar as referidas relações, quando
lhes chamamos processão e espiração, que, na sua significação própria, mais exprimem atos nocionais,
que relações; assim também, para exprimir a Pessoa divina procedente por amor, o uso da Escritura
aplicou o nome de Espírito Santo.
E da razão desse modo de falar podemos dar dupla explicação. – A primeira é a própria comunidade da
pessoa chamada Espírito Santo; pois, como diz Agostinho, sendo o Espírito Santo comum às duas outras
Pessoas, o que destas duas se diz comumente, dele se diz propriamente. Pois, o Pai, é espírito, e
também o Filho; o Pai é santo e também o Filho. – A segunda é a sua significação própria. Pois, o nome
de espírito, nas coisas corpóreas, significa certo impulso e certa moção; assim chamamos espírito ao
sopro e ao vento. Ora, é próprio do amor mover e impelir a vontade do amante para o amado. E quanto
à santidade, ela se atribui à coisas ordenadas para Deus. E como a Pessoa divina procede pelo amor por
que Deus é amado, convenientemente ela se chama Espírito Santo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O que chamamos Espírito Santo, levando em conta a
força das duas expressões, é comum a toda a Trindade. Pois, o nome de espírito significa a
imaterialidade da substância divina, porque o espírito corpóreo é invisível e pouco material; por isso, a
todas as substâncias imateriais e invisíveis damos o nome de espírito. E quando dizemos santo,
queremos significar a pureza da divina bondade. Se porém tomarmos as duas palavras – Espírito Santo –
como uma só expressão, nesse caso, pelo uso da Igreja, Espírito Santo é empregado para significar uma
das três Pessoas, i. é, a procedente por amor, pela razão já dada.

RESPOSTA À SEGUNDA. – Embora o ao que chamo Espírito Santo não se predique relativamente,
todavia é tomado como nome relativo, quando usado para significar a Pessoa distinta das outras só pela
relação. Contudo, pode-se também compreender nesse nome alguma relação, significando então
Espírito o que é por assim dizer espirado.

RESPOSTA À TERCEIRA. – Pelo nome de Filho se entende só a relação do que vem de um princípio, com
esse princípio; mas pelo nome de Pai se entende a relação do princípio e, semelhantemente, pelo de
Espírito, enquanto importa uma certa força motora. Ora, a nenhuma criatura convém ser princípio em
relação a qualquer das Pessoas divinas: mas, ao inverso. Por onde, podemos dizer Pai nosso e Espírito
nosso, não porém, Filho nosso.

## Art. 2 — Se o Espírito Santo procede do Filho.
(I Sent., dist. XI, a. 1; IV Cont. Gent., cap. XXIV, XXV; De port., q. 10, a. 4, 5; Contra errores Graec., parte

II, cap. XXVII usque ad XXXII; Compend. Theol., cap. XLIX; Contra Graecos, Armenos, etc., cap. IV; in
Ioan., cap. XV, lect. VI; cap. XVI, lect IV).
O segundo discute-se assim. – Parece que o Espírito Santo não procede do Filho.

1. – Pois, segundo Dionísio, não devemos ousar dizer nada da divindade substancial, além do que nos foi
devidamente expresso nas Sagradas Letras. Ora, a Sagrada Escritura não diz que o Espírito Santo
procede do Filho, mas só, que procede do Pai (Jo 15, 26): O espírito de verdade que procede do Pai.
Logo, o Espírito Santo não procede do Filho.

2. Demais. – No símbolo do Sínodo Constantinopolitano lê-se: Cremos no Espírito Santo, Senhor e
vivificador, procedente do Pai, e que deve ser com o Pai e o Filho adorado e glorificado. Logo, de
nenhum modo se devia acrescentar, em o nosso símbolo, que o Espírito Santo procede do Filho; mas
devem se considerar réus de anátema os que o fizeram.

3. Demais. – Damasceno diz: dizemos que o Espírito Santo procede do Pai e lhe chamamos Espírito do
Pai; porém não dizemos que procede do Filho, embora lhe chamemos Espírito do Filho. Logo, o Espírito
Santo não procede do Filho.

4. Demais. – Nada procede do ser em que repousa. Ora, o Espírito Santo repousa no Filho, pois diz a
legenda de Santo André: A paz convosco e com todos os que crêem em um Deus Padre, e num só seu
Filho, único Senhor Jesus Cristo, e em um Espírito Santo procedente do Pai e que permanece no Filho.
Logo, o Espírito Santo não procede do Filho.

5. Demais. – O Filho procede como Verbo. Ora, o nosso espírito parece que não procede, em nós, do
nosso verbo. Logo, nem o Espírito Santo procede do Verbo.

6. Demais. – O Espírito Santo procede perfeitamente do Pai. Logo, é supérfluo dizer que procede do
Filho.

7. Demais. – No que é perfeito não difere o ser, do poder, como diz o Filósofo; e, muito menos em Deus.
Ora, o Espírito Santo pode se distinguir do Filho, mesmo se deste não procede; pois, diz Anselmo: O
Filho e o Espírito Santo têm certamente o ser do Pai, mas de diverso modo; um nascendo, o outro,
procedendo, de maneira que ambos entre si se distinguem. E depois acrescenta: Pois, se por outra razão
não se diversificassem o Filho e o Espírito Santo, só por aí se diversificariam. Logo, o Espírito Santo, não
existindo pelo Filho, deste se distingue.
Mas, em contrário, diz Atanásio: O Espírito Santo não é feito, nem criado, nem gerado pelo Pai e pelo
Filho, mas é deles procedente.

SOLUÇÃO. – É necessário admitir-se que o Espírito Santo procede do Filho. Pois, se deste não
procedesse, dele não poderia de modo nenhum pessoalmente distinguir-se, o que resulta claro do que
já dissemos. Nem é possível dizer-se que as Pessoas divinas se distingam entre si, absolutamente
falando, pois, daí seguir-se-ia não ser uma a essência das três, porquanto tudo o que de Deus
absolutamente se predica pertence à unidade de essência. Donde se conclui, que só pelas relações se
distinguem, entre si as Pessoas divinas. Ora, as relações só como opostas é que podem distinguir as
Pessoas, o que assim se demonstra: tem o Pai duas relações; uma referente ao Filho e outra, ao Espírito
Santo; as quais todavia, por não serem opostas, não constituem duas pessoas, mas pertencem
unicamente à só pessoa do Pai. Se, portanto, no Filho e no Espírito Santo só houvesse duas relações,
pelas quais um e outro se referissem ao Pai, elas não seriam opostas entre si, como não o são as duas
pelas quais o Pai a eles se refere. Por onde, como a pessoa do Pai é una, seguir-se-ia também ser una a
pessoa do Filho com a do Espírito Santo, tendo duas relações opostas às duas do Pai. Ora, isto é herético
porque destrói a fé na Trindade. Logo, é necessário refiram-se entre si o Filho e o Espírito Santo por
opostas relações senão as de origem, como já provamos. Mas as relações opostas de origem se fundam
no princípio e no que provém do princípio. Logo, e necessariamente, ou o Filho procede do Espírito
Santo, o que ninguém diz, ou o Espírito Santo procede do Filho, como nós confessamos.
Com o que também está de acordo a razão da processão de um e outro. Pois, já dissemos que o Filho,
como Verbo, procede a modo de intelecto; porém, o Espírito Santo a modo de vontade, como Amor.
Ora, necessariamente, do verbo procede o amor. Pois não amamos senão a quem apreendemos pela
concepção mental. Por onde, desta maneira, é manifesto que o Espírito Santo procede do Filho.
Mas também a própria ordem das coisas assim o ensina. Pois, nunca vemos de um ser procederem
desordenadamente outros, salvo quando diferem só materialmente; assim, um ferreiro faz muito
cutelos materialmente distintos entre si, sem nenhuma ordem mútua. Porém as coisas, que se
distinguem não só pela distinção material, sempre mantém uma certa ordem entre si. Por isso, também
a ordem das criaturas manifesta o esplendor da divina sabedoria. Se pois de uma mesma pessoa, a do
Pai, procedem duas outras, o Filho e o Espírito Santo, é necessário tenham elas entre si uma certa
ordem, e esta não pode ser outra senão a de natureza, por cuja ordem um procede do outro. Logo, não
é possível dizer-se, que o Filho e o Espírito Santo procedem do Pai de modo tal que nenhum deles
proceda do outro; a menos que introduzamos entre eles uma distinção material, o que é impossível.
Por isso, também os próprios Gregos admitem certa ordem relativa ao Filho, na processão do Espírito
Santo; pois concedem que o Espírito Santo é Espírito do Filho e que procede do Pai pelo Filho. E diz-se
que alguns deles concedem, que o Espírito Santo vem do Filho, ou dele promana; não, porém, que
proceda. O que provém da ignorância ou da petulância. Pois quem refletir atentamente verá que é
generalíssimo o vocábulo processão, dentre todos os que exprimem uma origem qualquer. Assim, dele
usamos para designar qualquer origem, dizendo, p. ex., que a linha procede do ponto; o raio, do sol; o
rio, da fonte, e em outros casos semelhantes. Por onde, de tudo o que se refere à origem podemos
concluir, que o Espírito Santo procede do Filho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Não devemos dizer de Deus o que não se acha na Sagrada
Escritura textualmente ou pelo sentido. Embora pois nela não leiamos textualmente, que o Espírito
Santo procede do Filho, encontramo-lo todavia, quanto ao sentido e precipuamente onde diz o Filho,
falando do Espírito Santo (Jo 16, 14): Ele me clarificará porque há de receber do que é meu. E também
de ordinário devemos entender na Sagrada Escritura, como necessariamente dito, do Filho, o que diz do
Pai, mesmo quando acrescentar a locução exclusiva, exceto quando o Pai e o Filho se distinguem
segundo relações opostas. Assim, as palavras do Senhor (Mt 11, 27): Ninguém conhece o Filho senão o
Pai – não impedem o Filho de se conhecer a si mesmo. Logo, quando se diz que o Espírito Santo procede
do Pai, mesmo acrescentando que só do Pai procede, isso não exclui o Filho; pois, como princípio do
Espírito Santo, não se opõem Pai e Filho, senão somente enquanto um é Pai e outro Filho.

RESPOSTA À SEGUNDA. – Cada Concílio instituiu algum símbolo, por causa de algum erro que
condenava. Por isso, o Concílio seguinte não constituía símbolo diferente do primeiro, mas apenas o
explanava, contra os heréticos insurgentes, desenvolvendo o que já implicitamente continha o primeiro.
Assim, o Sínodo Calcedonense determinou que os membros do Concílio Constantinopolitano
transmitiriam a doutrina do Espírito Santo, não inferindo ser insuficiente o que estabeleceu o Concílio
anterior, reunido em Nicéia, mas declarando-lhe o sentido, contra os heréticos. Pois, como no tempo
dos antigos Concílios ainda não era nascido o erro dos que dizem não proceder o Espírito Santo, do
Filho, não foi necessária referência explicita a este erro. Mas, quando ele mais tarde apareceu, foi
expresso em certo Concílio reunido no ocidente por autoridade do Romano Pontífice, por cuja
autoridade também foram reunidos e confirmados os antigos Concílios. – Ora, que o Espírito Santo
procede do Filho já estava implícito no dizer-se que procede do Pai.

RESPOSTA À TERCEIRA. – Foram os Nestorianos os primeiros a ensinarem que o Espírito Santo não
procede do Filho, como se vê por um símbolo deles, condenado no Sínodo Efesino. E tal erro foi seguido
por Teodoreto Nestoriano e vários depois deles, entre os quais também Damasceno; razão pela qual a
opinião deste não a devemos seguir, nesta matéria. Embora certos digam que Damasceno, se não
confessa que o Espírito Santo procede do Filho, também não o nega, pelas palavras citadas.

RESPOSTA À QUARTA. – O dizer-se que o Espírito Santo repousa ou permanece no Filho, não exclui que
dele proceda; pois, também dizemos que o Filho permanece no Pai, e todavia dele procede. E também
dizemos que o Espírito Santo repousa no Filho, ou como o amor do amante, no amado, ou considerando
a natureza humana de Cristo, em virtude do que diz a Escritura (Jo 1, 33): Aquele sobre que tu vires
descer o Espírito e repousar sobre ele, esse é o que batiza no Espírito Santo.

RESPOSTA À QUINTA. – O Verbo divino não é comparável ao verbo vocal, do qual não procede o
espírito; porque então o Verbo divino teria sentido metafórico. Mas é comparável ao verbo mental, do
qual procede o amor.

RESPOSTA À SEXTA. – Por proceder perfeitamente do Pai, não somente não é supérfluo dizer-se que o
Espírito Santo procede do Filho, mas antes, é absolutamente necessário. Pois sendo uma mesma a
virtude do Pai e do Filho, tudo quanto procede do Pai há de necessariamente proceder do Filho, salvo o
que repugnar à propriedade da filiação. Assim o Filho não procede de si mesmo, embora proceda do Pai.

RESPOSTA À SÉTIMA. – O Espírito Santo distingue-se pessoalmente do Filho porque a origem de um se
distingue da do outro. Mas a diferença mesma da origem consiste em proceder o Filho só do Pai, ao
passo que o Espírito Santo, do Pai e do Filho. E nem de outro modo se distinguiriam as processões, como
já ficou antes demonstrado.

## Art. 3 — Se o Espírito Santo procede do Pai, pelo Filho.
(I Sent., dist. XII, a. 3; Contra errores Graec., parte II, cap. IX).
O terceiro discute-se assim. – Parece que o Espírito Santo não procede do Pai, pelo Filho.

1. – Pois quem procede de outrem por meio de um terceiro não procede imediatamente. Logo, se o
Espírito Santo procede do Pai, pelo Filho, não procede imediatamente, o que parece inadmissível.

2. Demais. – Se o Espírito Santo procede do Pai, pelo Filho, deste procede por causa do Pai. Ora, o que
faz com que uma coisa seja o que é mais essa coisa do que ela própria o é. Logo, procede o Espírito
Santo mais do Pai do que do Filho.

3. Demais. – O Filho tem o ser por geração. Se pois o Espírito Santo procede do Pai, pelo Filho, segue-se
que, primeiro, é gerado o Filho e, depois, procede o Espírito Santo. E assim, não é eterna esta processão,
o que é herético.

4. Demais. – Quando se diz que alguém obra por meio de outrem, pode-se também dizer o inverso.
Assim, dizendo-se que o rei obra por meio do súdito pode-se também dizer que o súdito obra por meio
do rei. Ora, de modo nenhum se pode dizer que o Filho espira o Espírito Santo, pelo Pai. Logo, de
nenhum modo se pode dizer que o Pai espira o Espírito Santo, pelo Filho.
Mas, em contrário, diz Hilário: Suplico-te conserves a religião da minha fé, para que sempre te obtenha
a ti, ó Pai; e adore juntamente contigo o teu Filho; e mereça o teu Espírito Santo, que vem de ti, pelo teu
Unigênito.

SOLUÇÃO. – Em todas as locuções onde se diz, que alguém obra por outro, a preposição por designa, na
causal, alguma causa ou princípio desse ato. Mas, como o ato é uma mediania entre o autor e a sua
obra, algumas vezes a locução causal, à qual se adjunge a preposição por, é causa do ato como partindo
do agente. E, então é a causa de o agente agir, quer seja causa final, formal, efetiva ou motora. Final,
quando, p. ex., dizemos que o artífice obra por cobiça do lucro; formal, se dissermos que obra pela sua
arte; motora, se dissermos, que obra por ordem de outro. Outras vezes porém a locução causal, à qual
se adjunge a preposição por, é causa do ato enquanto este termina no seu resultado; como se
dissermos: O artífice obra pelo martelo. Pois isto não significa que o martelo seja a causa de agir o
artífice, mas sim, a de proceder, deste, o artificiado; e que isto mesmo o martelo recebe do artífice. E tal
é o que certos ensinam, dizendo que a preposição por, ora designa o autor, diretamente, como quando
se diz – o rei obra pelo súdito; ora indiretamente, como na frese – o súdito obra pelo rei.
Ora, como o Filho recebe do Pai a razão de proceder de si o Espírito Santo, podemos dizer que o Pai,
pelo Filho, espira o Espírito Santo, ou que este procede do Pai, pelo Filho, o que é o mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Em qualquer ação duas coisas se devem considerar: o
suposto agente e a virtude pela qual age; assim o fogo aquece pelo calor. Considerando-se pois no Pai e
no Filho a virtude pela qual espiram o Espírito Santo, não há aí lugar para nenhuma mediania, por ser
essa uma mesma virtude. Considerando-se porém as próprias Pessoas espirantes, então de proceder o
Espírito Santo comumente do Pai e do Filho, resulta proceder imediatamente do Pai, por vir deste; e,
mediatamente, por vir do Filho; e daí o dizer-se que procede do Pai, pelo Filho. Assim como Abel
procedeu imediatamente de Adão, como pai; e mediatamente, por proceder a sua mãe, Eva, de Adão;
embora tal exemplo de processão material seja impróprio para exprimir a processão imaterial das
Pessoas divinas.

RESPOSTA À SEGUNDA. – Se o Filho recebesse do Pai outra virtude numericamente diversa, para espirar
o Espírito Santo, resultaria ser o Filho uma como causa segunda e instrumental; e, então, mais
procederia o Espírito Santo do Pai, que do Filho. Mas uma mesma virtude espirativa, numericamente,
existe no Pai e no Filho; logo, igualmente de um e outro procede o Espírito Santo. Embora por vezes se
diga que este, principal ou propriamente, procede do Pai, por ter o Filho, do Pai, tal virtude.

RESPOSTA À TERCEIRA. – Assim como a geração do Filho é coeterna com quem o gera e, por isso, o Pai
não existia anteriormente à geração do Filho, assim, a processão do Espírito Santo é coeterna com o seu
princípio. Por onde, o Filho não foi gênito antes de proceder o Espírito Santo, mas ambos são eternos.

RESPOSTA À QUARTA. – Quando se diz que alguém obra por meio de outro, nem sempre essa
preposição é conversível; assim, não dizemos que o martelo obra por meio do ferreiro.
Mas dizemos que o súdito obra por meio do rei, porque age como senhor do seu ato; ao passo que o
martelo, não agindo, mas sendo usado, só é designado como instrumento. E dizemos, que o súdito obra
por meio do rei, embora a preposição por designe meio; porque quanto mais primário for o suposto, no
agir, tanto mais a sua virtude se manifestará imediata, no efeito. Pois, a virtude da causa primaria
prende ao seu efeito a causa segunda; e por isso os primeiros princípios, nas ciências demonstrativas, se
chamam imediatos. Assim pois, sendo o súdito um meio, na ordem dos supostos agentes, dizemos, que
por ele obra o rei; mas na ordem das virtudes, dizemos que o súdito obra pelo rei, porque a virtude
deste faz com que a ação daquele atinja o seu efeito. Ora, entre o Pai e o Filho não se considera a
ordem, quanto à virtude, mas somente, quanto aos supostos; e por isso dizemos, que o Pai espira pelo
Filho e não, inversamente.

## Art. 4 — Se o Pai e o Filho são um mesmo princípio do Espírito Santo.
(I Sent., dist. XI, a. 2, 4; dist. XXIX, a. 4; IV Cont. Gent., cap. XXV).
O quarto discute-se assim. – Parece que o Pai e o Filho não são um mesmo princípio do Espírito Santo.

1. – Pois, o Espírito Santo não procede do Pai e do Filho, enquanto são um mesmo princípio: nem
quanto à natureza, porque então procederia de si mesmo, por ter com eles unidade de natureza; nem
quanto a alguma propriedade, porque dois supostos não podem ter uma mesma propriedade, como se
sabe. Logo, o Espírito Santo procede do Pai e do Filho como de vários, e portanto estes não são um
mesmo princípio do Espírito Santo.

2. Demais. – Quando se diz que o Pai e o Filho são um mesmo princípio do Espírito Santo, não se quer
assim designar a unidade pessoal, porque então o Pai e o Filho seriam uma só pessoa. Nem tampouco a
unidade de propriedade, porque se, por uma propriedade, o Pai e o Filho são um mesmo princípio do
Espírito Santo, pela mesma razão, por duas propriedades, o Pai seria um duplo princípio do Filho e do
Espírito Santo, o que é inadmissível. Logo, o Pai e o Filho não são um mesmo princípio do Espírito Santo.

3. Demais. – O Filho não convém mais com o Pai do que o Espírito Santo. Ora, o Espírito Santo e o Pai
não são um mesmo princípio, em relação a nenhuma pessoa divina. Logo, nem o Pai e o Filho.

4. Demais. – Se o Pai e o Filho são um mesmo princípio do Espírito Santo, esse princípio único ou é o Pai
ou o que não o é. Ora, nenhuma destas duas hipóteses é possível, pois se o princípio único for o Pai,
resulta que o Filho é Pai; e se for o que não é Pai, resulta que o Pai não é Pai. Logo, não se deve dizer,
que Pai e o Filho sejam um mesmo princípio do Espírito Santo.

5. Demais. – Se o Pai são um mesmo princípio do Espírito Santo, pode-se dizer, inversamente, que um
princípio do Espírito Santo são o Pai e o Filho. Ora, esta proposição é falsa; pois, o a que chamo princípio
necessariamente é suposto à pessoa do Pai ou à do Filho e, de ambos os modos, a proposição é falsa.
Logo, também esta o é: o Pai e o Filho são um mesmo princípio do Espírito Santo.

6. Demais. – A unidade substancial produz a identidade. Se, pois, o Pai e o Filho são um mesmo princípio
do Espírito Santo, segue-se que constituem um mesmo princípio. Ora, isto é negado por muitos. Logo,
não se deve conceder que o Pai e o Filho sejam um mesmo princípio do Espírito Santo.

7. Demais. – O Pai, o Filho e o Espírito Santo, por serem um mesmo princípio da criatura, são
considerados um só Criador. Ora, o Pai e o Filho não são um só espirador, mas, dois espiradores, como
muitos dizem e é consoante à opinião de Hilário, de acordo com a qual devemos confessar ter o Espírito
Santo por autores o Pai e o Filho. Logo, estes não são um mesmo princípio do Espírito Santo.
Mas em contrário, diz Agostinho, que o Pai e o Filho não são os dois princípios, mas um mesmo princípio
do Espírito Santo.

SOLUÇÃO. – O Pai e o Filho não são um só, em tudo o que a oposição de relação não os distingue entre
si. Ora, o serem o princípio do Espírito Santo não os opõe relativamente. Donde se segue, que o Pai e o
Filho são um mesmo princípio do Espírito Santo. Certos, porém, consideram impróprio dizer – o Pai e o
Filho são um mesmo princípio do Espírito Santo. Pois, o nome de princípio em sentido particular, não
significando a pessoa, mas, a propriedade, é tomado, dizem, adjetivamente. E como o adjetivo não se
determina pelo adjetivo, não se pode afirmar convenientemente que o Pai e o Filho sejam um mesmo
princípio do Espírito Santo, a menos que se não entenda – um mesmo – adverbialmente, sendo então o
significado: são um mesmo princípio, i. é, de um modo. Mas, por semelhante razão, poderíamos dizer,
que o Pai é duplo princípio do Filho e do Espírito Santo, i. é, de dois modos. Logo, devemos dizer, que
embora o nome de princípio signifique propriedade, todavia significa-a a modo de substantivo, como o
nome de pai ou de filho, mesmo aplicado às criaturas. Por isso, é susceptível de número, pela forma
significada, como se dá com os outros substantivos. Assim, pois, como o Pai e o Filho são um só Deus,
por causa da unidade da forma, significada pelo nome Deus, assim também são um mesmo princípio do
Espírito Santo, por causa da unidade de propriedade significada pelo nome de princípio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Atendendo-se à virtude espirativa, o Espírito Santo
procede do Pai e do Filho, enquanto essa virtude lhes dá unidade, significando, de certo modo, a
natureza com propriedade, como depois demonstraremos. Nem é inconveniente ter uma propriedade
dois supostos, que tem a mesma natureza. Se porém considerarmos os supostos da espiração, então o
Espírito Santo procede do Pai e do Filho como vários; pois deles procede como amor unitivo de ambos.

RESPOSTA À SEGUNDA. – Quando dizemos: O Pai e o Filho são um mesmo princípio do Espírito Santo -
queremos designar uma propriedade, que é a forma significada pelo nome. Não se segue porém daí
que, por serem várias as propriedades, possamos dizer que o Pai são vários princípios, o que implicaria
pluralidade de supostos.

RESPOSTA À TERCEIRA. – Não pelas propriedades relativas, mas pela essência é que há em Deus
semelhança e díssemelhança. Donde, como o Pai não é mais semelhante a si do que ao Filho, assim,
nem o Filho o é mais ao Pai do que o Espírito Santo.

RESPOSTA À QUARTA. – Estas duas proposições – o Pai e o Filho são um mesmo princípio, que é o Pai –
ou – um mesmo princípio, que não é o Pai – não são opostas contraditoriamente; e, portanto não é
necessário conceder-se uma, com exclusão da outra. Pois, quando dizemos – o Pai e o Filho são um
mesmo princípio – o que chamamos princípio não tem suposição determinada, mas antes, confusa e
aplicada simultaneamente às duas pessoas. Por onde, a objeção se funda no sofisma de Figura de
Dicção, passando da suposição confusa para a determinada.

RESPOSTA À QUINTA. – Também esta proposição é verdadeira – Um mesmo princípio do Espírito Santo
é o Pai e o Filho. Pois, o a que chamamos princípio não é aplicado a uma pessoa somente, mas
indistintamente, às duas, como foi dito.

RESPOSTA À SEXTA. – Podemos dizer, convenientemente, que o Pai e o Filho, são um mesmo princípio,
aplicando a palavra princípio confusa, indistinta e simultaneamente às duas pessoas.

RESPOSTA À SÉTIMA. – Alguns dizem, que o Pai e o Filho, embora sejam um mesmo princípio do Espírito
Santo, são todavia dois espiradores, por causa da distinção dos supostos, como também dois espirantes,
porque os atos se referem aos supostos. Não é a mesma porém a significação do nome Criador, pois, o
Espírito Santo procede do Pai e do Filho como de duas pessoas, distintas, segundo foi dito; ao passo que
a criatura não procede das três pessoas, como de pessoas distintas, mas como dotadas de uma mesma
essência. – Contudo, parece melhor dizer que, sendo espirante adjetivo e espirador substantivo,
podemos afirmar que o Pai e o Filho são dois espirantes, por causa da pluralidade dos supostos, não
sendo porém dois espiradores, por causa da unidade de espiração. Pois os adjetivos recebem o número
dos supostos; ao passo que os substantivos o têm de si mesmos, pela forma significada. E o dito de
Hilário, que o Espírito Santo provém do Pai e do Filho como de autores, deve ser entendido como
empregando um substantivo em vez de adjetivo.