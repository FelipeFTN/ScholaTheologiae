# Questão 99: Da condição da prole a gerar, quanto ao corpo.
Em seguida devemos tratar da condição da prole a gerar. Primeiro quanto ao corpo. Segundo, quanto à
justiça. Terceiro, quanto a Ciência.
Sobre a primeira questão dois artigos se discutem:

## Art. 1 — Se as crianças recém–nascidas, no estado de inocência, tinham virtude perfeita, quanto ao movimento dos membros.
O primeiro discute–se assim. – Parece que as crianças, recém–nascidas, no estado de inocência,
tinham virtude perfeita, quanto ao movimento dos membros.

1. – Pois, como diz Agostinho, à debilidade da mente é correlata a do corpo, o que bem se vê nas
crianças. Ora, no estado de inocência, não havia nenhuma fraqueza da mente. Logo, também não
haveria nas crianças a dita fraqueza do corpo.

2. Demais. – Certos animais têm, logo depois de nascidos, virtude suficiente para usarem dos membros.
Ora, o homem sendo mais nobre que os animais, com muito maior razão lhe há de ser natural ter essa
virtude, logo depois de nascido. E é por pena consequente ao pecado que não a tem.

3. Demais. – Não poder conseguir o deleitável desejado causa sofrimento. Ora, se as crianças não
tivessem a virtude de mover os membros, frequentemente acontecer–lhes–ia não poderem conseguir
tal deleitável. Donde o caírem em sofrimento, o que não podia ser, antes do pecado. Logo, no estado de
inocência, não faltaria às crianças a virtude de mover os membros.

4. Demais. – A deficiência da velhice corresponde à da puerícia. Ora, aquela não existia, no estado de
inocência. Logo, nem esta.
Mas, em contrário, tudo o que é gerado é imperfeito, antes de vir a ser perfeito. Ora, no estado de
inocência, filhos eram produzidos por geração. Logo, a princípio seriam imperfeitos pelo tamanho e pela
virtude do corpo.

SOLUÇÃO. – Só pela fé conhecemos o sobrenatural; e o que cremos à autoridade o devemos. Por onde,
em tudo o que afirmarmos, devemos seguir a natureza das coisas, exceto em relação às verdades
sobrenaturais, transmitidas pela autoridade divina. Ora, é manifestamente natural e de acordo com os
princípios da natureza humana; que as crianças recémnascidas não tenham virtude suficiente para
mover os membros. Pois o homem tem naturalmente o cérebro de tamanho maior, proporcionalmente
ao seu corpo, do que os brutos. E por isso é natural que, por causa da muita umidade do cérebro das
crianças, os nervos, instrumentos do movimento, não sejam idóneos para mover os membros. Mas por
outro lado, para nenhum católico é duvidosa a divina virtude de fazer com que os recém–nascidos
tenham virtude perfeita para mover os membros. Pois, consta da autoridade da Escritura que Deus criou
o homem reto: e esta retidão consiste, como diz Agostinho, na perfeita sujeição do corpo à alma. Assim
como, pois, no primeiro estado, não podia haver nos membros do homem nada que lhes repugnasse à
vontade ordenada; assim, esses membros não podiam ser deficientes em relação à vontade. Ora, é
ordenada a vontade do homem, que tende para atos que lhe são convenientes, E como não são os
mesmos os atos convenientes, às várias idades do homem, conclui–se que as crianças recém–nascidas
não tinham suficiente virtude para mover os membros para quaisquer atos, mas só para os que fossem
convenientes à puerícia, por exemplo, apegar–se aos seios e outros semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Agostinho refere–se à debilidade atual das crianças, que
aparece mesmo relativamente aos atos convenientes à puerícia delas; como é claro pelo que dissera
antes, que estando ao lado dos seios, antes chorariam e padeceriam fome, que se apegassem a eles.

RESPOSTA À SEGUNDA. – Não é por perfeição, que certos animais recém–nascidos tem o uso dos
membros, pois, outros mais perfeitos não o tem. Mas tal lhes advém da secura do cérebro, e de serem
imperfeitos os atos que lhes são próprios, para os quais pode bastar uma virtude, mesmo fraca,

RESPOSTA À TERCEIRA. – Deduz–se clara a resposta do que foi dito no corpo do artigo. – Ou se pode
dizer que nada desejariam senão do que lhes conviesse, no seu estado, por uma vontade ordenada.

RESPOSTA À QUARTA. – O homem, no estado de inocência, seria gerado, mas não, corrupto. Por onde,
nesse estado, poderiam existir algumas deficiências pueris resultantes da geração; não, porém, senis,
que levam à corrupção.

## Art. 2 — Se no primitivo estado nasceriam mulheres.
O segundo discute–se assim. – Parece que no primitivo estado não nasceriam mulheres.

1. – Pois, diz o Filósofo, a fêmea é um macho falho, nascida como que contra a intenção da natureza.
Ora, no dito estado, nada seria contra a natureza, na geração do homem. Logo, não nasceriam
mulheres.

2. Demais. – Todo gerador gera o semelhante a si, se não for impedido, ou por deficiência da virtude, ou
por indisposição da matéria; assim, um fogo pequeno não pode queimar a madeira verde. Ora, na
geração, ao homem pertence a virtude ativa. E como, no estado de inocência, não havia no homem
nenhuma deficiência de virtude, nem, na mulher, nenhuma indisposição da matéria, resulta que
haveriam de nascer sempre homens.

3. Demais. – No estado de inocência a geração era ordenada à multiplicação dos homens. Ora, estes
podiam suficientemente multiplicar–se pelo primeiro homem e pela primeira mulher, desde que
viveriam perpetuamente. Logo, não era necessário nascessem mulheres, no estado de inocência.
Mas, em contrário, a natureza procederia, na geração, conforme Deus a instituiu. Ora, Deus instituiu o
homem e a mulher, em a natureza humana, como diz a Escritura. Logo, mesmo no sobredito estado,
haviam de ser gerados homens e mulheres.

SOLUÇÃO. – No estado de inocência, não faltaria nada do que pertence ao complemento da natureza
humana. Ora, assim como para a perfeição do universo concorrem os diversos graus dos seres, assim
também a diversidade dos sexos concorre para a perfeição da natureza humana. E por isso, no estado
de inocência, ambos os sexos seriam produzidos por geração.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A mulher chama–se macho falho por ser contra a
intenção da natureza particular; não, porém, contra a da natureza universal, como já se disse antes.

RESPOSTA À SEGUNDA. – A geração da mulher se dá, não só por deficiência da virtude ativa ou pela
indisposição da matéria, como refere a objeção, mas também, às vezes, por algum acidente extrínseco.
Assim, como diz o Filósofo, o vento setentrional ajuda a geração dos machos; o austral, porém, a das
fêmeas. As vezes também pela concepção da alma, pela qual facilmente é imutado o corpo. E isto podia
dar–se precipuamente no estado de inocência. quando o corpo estava melhor sujeito à alma, de modo
que, conforme a vontade do gerador, assim se distinguisse o sexo, na prole.

RESPOSTA À TERCEIRA. – A prole seria gerada, com vida animal, à qual é próprio não só usar de
alimento, como também gerar. Por onde, convinha que todos gerassem e não só os primeiros pais;
donde resultaria que seriam gerados tanto mulheres quanto homens.