# Questão 70: Da obra do ornato, quanto ao quarto dia.
Em seguida, devemos tratar da obra do ornato. E, primeiro, de cada um dos dias, em si. Segundo, de
todos os seis dias, em comum.
Quanto ao primeiro ponto, devemos tratar da obra do quarto dia. Segundo, da do quinto. Terceiro, da
do sexto. Quarto, do concernente ao sétimo dia.
Sobre o primeiro ponto, três artigos se discutem:

## Art. 1 — Se os astros deviam ser produzidos no quarto dia.
O primeiro discute-se assim. — Parece que os astros não deviam ser produzidos no quarto dia.

1. — Pois, são corpos naturalmente incorruptíveis. Logo, a matéria deles não pode existir sem as
respectivas formas. Ora, essa matéria foi produzida pela obra da criação, antes dos dias. Logo, também
as suas formas o foram. Logo, não foram feitas no quarto dia.

2. Demais. — Os astros são uns quasi vasos de luz. Ora, esta foi feita no primeiro dia. Logo, nesse
mesmo dia, e não no quarto, também deviam ter sido feitos aqueles.

3. Demais. — Como as plantas estão fixas na terra, assim estão fixos os astros no firmamento; por onde,
a Escritura diz que colocou-os no firmamento. Mas, a produção das planta é descrita simultaneamente
com a formação da terra, à qual são aderentes. Logo, também a produção dos astros devia ter sido feita,
simultaneamente com a do firmamento, no segundo dia.

4. Demais. — O sol, a lua e os outros astros são causa das plantas. Mas, pela ordem natural, a causa
precede o efeito. Logo, os astros não deviam ter sido feitos no quarto dia, mas no terceiro, ou antes.

5. Demais. — Muitas estrelas, segundo os astrólogos, são maiores que a lua. Logo, o sol e a lua,
somente, não deviam ser considerados como os dois grandes luzeiros.
Mas, em contrário, basta a autoridade da Escritura.

SOLUÇÃO. — Na recapitulação das obras divinas, a Escritura assim diz (Gn 2, 1): Assim foram acabados
os céus e a terra, e todo o seu ornato. Nessas palavras pode-se compreender uma tríplice obra: a da
criação, pela qual, como se lê, foram produzidos o céu e a terra, mas informes; a da distinção, pela qual
o céu e a terra foram aperfeiçoados, quer pelas formas substanciais, atribuídas à matéria totalmente
informe, como sente Agostinho, quer quanto à decoração e à ordem convenientes, como dizem os
outros Santos Padres. E a estas duas obras se ajunta o ornato, que difere da perfeição. Por onde, a
perfeição do céu e da terra diz respeito ao que lhes é intrínseco; porém o ornato, ao que é delas
distinto. Assim como o homem, que se aperfeiçoa pelas próprias partes e formas, orna-se, porém, com
os vestimento ou coisas semelhantes. Ora, a distinção dos seres por excelência se manifesta no
movimento local, que os separa uns dos outros. Por isso, à obra do ornato pertence a produção das
coisas que têm movimento, no céu e na terra. Ora, como antes se disse, de três coisas se faz menção, na
criação: do céu, da terra e da água. E essas três se formam pela obra da distinção, em três dias: no
primeiro dia, o céu; no segundo, separam-se as águas; no terceiro, separa-se, na terra, o mar, da parte
enxuta. E semelhantemente, na obra do ornato: no primeiro dia, que é o quarto, são produzidos os
astros que se movem no céu, para ornato do mesmo; no segundo, que é o quinto, as aves e os peixes,
para ornato do elemento médio, pois se movem no ar e na água, que se consideram idênticos; no
terceiro dia, que é o sexto, são produzidos os animais, que se movem na terra, para ornato da mesma.
Mas, importa saber que, na produção dos astros, Agostinho não discorda dos outros Santos Padres.
Pois, ensina que os astros foram feitos atual e não só virtualmente; porque o firmamento não tem a
virtude produtiva deles, como a terra tem a das plantas. Por onde, a Escritura não diz: — Produza o
firmamento astros — como diz: — Produza a terra erva verdejante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Segundo Agostinho, nenhuma dificuldade oferece esta
objeção. Pois, não admitindo a sucessão do tempo, em tais obras, não deve, por consequência dizer que
a matéria dos astros estava sujeita a outra forma. Também nenhuma dificuldade há para os que dizem
que os corpos celestes, sendo da natureza dos quatro elementos, são formados da matéria preexistente,
como os animais e as plantas. Mas os que ensinam serem os corpos celestes de natureza diferente da
dos elementos, e incorruptívei por natureza, devem também dizer que a substância dos astros foi criada
informe desde o princípio, estando agora formada, não, por certo, pela forma substancial, mas por
acrescentamento de uma determinada virtude. E por isso, no princípio, não se faz menção dos astros,
senão só no quarto dia, como diz Crisóstomo; para que, assim, se afaste o povo da idolatria, mostrando-
se que eles não são deuses, pois não existiam no princípio. RESPOSTA À SEGUNDA. — Segundo
Agostinho, nenhuma dificuldade resulta desta objeção; pois, a luz de que se fez menção, no primeiro
dia, era espiritual e a que agora foi feita, é corporal. Se, porém, se entender que a luz feita no primeiro
dia é corporal, deve-se dizer que tal luz foi produzida, segundo a natureza comum da luz; porém, no
quarto dia, foi atribuida aos astros uma determinada virtude para determinados efeitos; sendo por isso
que vemos o raio do sol ter uns efeitos, e o da lua, outros, e assim por diante. E, por causa dessa
determinada virtude, diz Dionísio, que a luz do sol, primeiramente informe, foi formada no quarto dia.

RESPOSTA À TERCEIRA. — Segundo Ptolomeu, os astros não são fixos nas esferas, mas têm movimento
diferente do delas. Por onde, ensina Crisóstomo, não se diz que Deus os colocou no firmamento porque
nele estejam fixos, mas porque mandou que aí estivessem; assim como pôs o homem no paraíso, para
que nele estivesse. Mas, segundo a opinião de Aristóteles, as estrelas estão fixas nas esferas e só pelo
movimento destas se movem. Contudo, a verdade real é que o movimento dos astros é percebido pelos
sentidos; não, porém, o das esferas. Mas Moisés, condescendendo com um povo rude, exprimiu-se
conforme ao sensivelmente, como já se disse (q. 68, a. 3). A objeção cessa, porém, se houver outro
firmamento, que os sentidos, aos quais como se disse , se atém Moisés, não distinguem, e que seja
diferente, por natureza, do em que estão postos os astros. Pois, o firmamento, feito no segundo dia,
quanto à parte inferior, só recebeu os astros, no quarto dia, quanto à parte superior; de modo que,
conforme o que aparece aos sentidos, toma-se o todo pela parte.

RESPOSTA À QUARTA. — Como diz Basílio, coloca-se a produção das plantas antes da dos astros, para
excluir a idolatria. Pois, os que crêem serem os astros deuses, dizem que as plantas tiram deles a sua
origem primordial; embora, como diz Crisóstomo, assim os astros, com os seus movimentos, cooperem
para a produção das plantas, como o agricultor.

RESPOSTA À QUINTA. — Segundo Crisóstomo, chamam-se dois grandes luzeiros, não tanto pelo
tamanho, como pela eficácia e pela virtude; pois, embora as outras estrelas sejam maiores, em tamanho
que a lua, contudo os efeitos desta se fazem mais sentir nos seres do nosso mundo; demais, ela aparece
maior aos sentidos.