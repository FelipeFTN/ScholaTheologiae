# Questão 29: Das Pessoas divinas
Depois de termos estudado o que necessário conhecer preliminarmente a respeito das processões e das
relações, é mister tratarmos das Pessoas.
Primeiro, consideradas absolutamente; depois, relativamente. Do primeiro modo devemos considerar
as Pessoas em geral e, em seguida, em particular. Ora, consideradas em geral, dão lugar a quatro
questões. A primeira é a significação da palavra pessoa. A segunda é o número das Pessoas. A terceira, a
que resulta do número das Pessoas ou se lhe opõe, como a diversidade, a semelhança e coisas
semelhantes. A quarta, a que respeita ao conhecimento das Pessoas. Na primeira questão discutem-se
quatro artigos:

## Art. 1 — Se é acertada a seguinte definição de pessoa: A pessoa é uma substância individual de natureza racional.
(III.ª, q. 2, a. 2; I Sent., dist. XXV, a. 1; De Pot., q. 9, a. 2; De unione Verbi, a. 1).
O primeiro discute-se assim. — Parece desacertada a seguinte definição de pessoa que dá Boécio: A
pessoa é uma substância individual de natureza racional.

1. — Pois, não é possível definir o singular. Ora, pessoa significa um ser singular. Logo, é
inconvenientemente definida.

2. Demais. — A substância incluída na definição de pessoa é tomada como substância primeira ou como
segunda. Se como primeira, é supérfluo acrescentar individual, porque a substância primeira é
individual. Se como segunda, o acréscimo é falso e implica oposição nos adjetivos, pois, as substâncias
segundas são os gêneros ou as espécies. Logo, a definição é mal enunciada.

3. Demais. — O nome intencional não deve entrar na definição de um ser. Assim, não faria um
enunciado certo quem dissesse — O homem é uma espécie de animal; pois, homem designa um ser, e
espécie é o nome intencional. Ora, pessoa, designando um ser, pois significa uma substância de
natureza racional, é inconveniente introduzir-lhe, na definição, indivíduo, que é o nome intencional.

4. Demais. — A natureza é princípio de movimento e de quietação no ser em que ela existe essencial e
não acidentalmente, como diz o Filósofo. Ora, o conceito de pessoa se realiza em seres imutáveis, como
Deus e os anjos. Logo, na definição de pessoa não se deveria incluir a natureza mas, antes, a essência.

5. Demais. — A alma separada é uma substância individual de natureza racional. Ora, não é uma pessoa.
Logo, tal definição de pessoa não é acertada.

SOLUÇÃO. — Embora o universal e o particular se encontrem em todos os gêneros, contudo, de certo
modo especial, o indivíduo se encontra no gênero da substância. Pois, esta se individua por si mesma,
ao passo que os acidentes se individuam pelo seu sujeito, que é a substância; assim, uma determinada
brancura denomina-se tal enquanto está num certo sujeito. Por isso, e convenientemente, os indivíduos
substanciais diferem dos outros por um nome especial, pois se chamam hipóstases ou substâncias
primeiras.
Mas ainda, de modo mais especial e perfeito manifesta-se o particular e o individual nas substâncias
racionais, que são senhoras dos próprios atos; e não somente são levadas, como os outros, mas agem
por si mesmas; pois, os atos são de natureza singular. E, portanto, entre as outras substâncias, os
indivíduos de substância racional têm certo nome especial, a saber, o de pessoa. E por isso, à predita
definição de pessoa, acrescenta-se substância individual, para significar o singular no gênero da
substância; e acrescenta-se mais — de natureza racional, para exprimir o singular na ordem das
substâncias racionais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora nenhum singular seja susceptível de definição,
todavia o que constitui a essência comum da singularidade o é; e assim o Filósofo define a substância
primeira, e do mesmo modo Boécio define a pessoa.

RESPOSTA À SEGUNDA. — Segundo alguns, a substância entra na definição de pessoa como substância
primeira, que é a hipóstase. Mas nem por isso é supérfluo acrescentar-se individual. Pois, o nome de
hipóstase, ou substância primeira exclui noção de universal e de parte; assim, não dizemos que o
homem, em geral, seja hipóstase, nem da mão, que é parte; mas, acrescentando-se individual, exclui-se
da pessoa a idéia de assumível; porque a natureza humana, em Cristo, não é pessoa, por ter sido
recebida por um ser mais digno, a saber, pelo Verbo de Deus. Mas melhor será dizer, que a palavra
substância é usada em sentido geral e se divide em primeira e segunda; e, acrescentando-se-lhe
individual, ela usurpa as funções de substância primeira.

RESPOSTA À TERCEIRA. — As diferenças substanciais, não nos sendo conhecidas, ou também, não
tendo denominação, é-nos necessário às vezes recorrer às diferenças acidentais, em lugar delas como se
disséssemos: o fogo é um corpo simples, cálido e seco. Pois, os acidentes próprios são efeitos das
formas substanciais e as manifestam. E, semelhantemente, podemos recorrer aos nomes intencionais
para definir certas realidades não susceptíveis de definição adequada. É assim que o nome de indivíduo
entra na definição de pessoa para designar o modo de subsistir próprio às substâncias particulares.

RESPOSTA À QUARTA. — Segundo o Filósofo, o nome de natureza foi primeiramente imposto para
significar a geração dos seres vivos, que se chama natividade. E porque tal geração provém de um
princípio intrínseco, estendeu-se esse nome a significar o princípio intrínseco de qualquer movimento.
Nesse sentido é que Aristóteles define a natureza. E porque tal princípio é formal ou material tanto a
forma como a matéria se chamam geralmente natureza. Completando-se, porém, pela forma e essência
de cada ser, comumente se chama natureza a essência, significada pela definição. E é nessa acepção que
aqui se toma a palavra natureza. E por isso Boécio, no mesmo livro, diz que natureza é a que informa
pela diferença específica; pois, a diferença específica completa a definição e é tomada da própria forma
da coisa. E portanto, foi mais conveniente usar, na definição de pessoa, que é um ser singular de um
gênero determinado, o nome de natureza, que o de essência, derivado de ser, que é generalíssimo.

RESPOSTA À QUINTA. — A alma faz parte da espécie humana. Logo, como embora separada, tende por
natureza para a união, não pode chamar-se substância individual, que é a hipóstase, ou substância
primeira; assim como não o pode a mão nem qualquer outra parte do homem. E portanto, não lhe cabe
a definição e nem o nome da pessoa.

## Art. 2 — Se pessoa é o mesmo que hipóstase, subsistência e essência.
(I Sent., dist. XXIII, a. 1; De pot., q. 9, a. 1).
O segundo discute-se assim. — Parece que pessoa é o mesmo que hipóstase, subsistência e essência.

1. — Pois, diz Boécio que os Gregos davam à substância individual de natureza racional o nome
hipóstase. Ora, também para nós isto é significado pelo nome de pessoa. Logo, pessoa é absolutamente
o mesmo que hipóstase.

2. Demais. — Como dizemos que há em Deus três pessoas, assim também dizemos que há três
subsistências; o que não seria possível se pessoa e subsistência não significassem o mesmo. Logo,
pessoa significa absolutamente o mesmo que subsistência.

3. Demais. — Boécio diz: a ousia, o mesmo que essência, significa um composto de matéria e forma.
Ora, o que é composto de matéria e forma é o individuo substancial, que se chama hipóstase e pessoa.
Logo, todos os nomes referidos parecem significar o mesmo.
Mas, em contrário, Boécio: Os gêneros e as espécies somente subsistem: os indivíduos, porém, não
somente subsistem, mas também substão. Ora, como de subsistir deriva a palavra subsistência; de
substar, as substâncias ou hipóstases. Ora, como ser hipóstase ou pessoa não convém aos gêneros e às
espécies, a hipóstase ou pessoa não é o mesmo que subsistência.
Demais. — Boécio diz: A hipóstase chama-se matéria, mas a ousiosis, isto é, a subsistência, se chama
forma. Ora, nem a forma nem a matéria se podem chamar pessoas. Logo, pessoa difere da hipóstase e
da subsistência.

SOLUÇÃO. — Segundo o Filósofo, em dois sentidos se emprega a palavra substância. Num sentido,
significa aqüididade da coisa, expressa pela definição, e por isso dizemos que a definição exprime a
substância da coisa; e a essa substância os Gregos chamam ousia, o que nós podemos traduzir
por essência. Noutro sentido, chama-se substância ao sujeito ou suposto que subsiste no gênero da
substância. E este, em acepção comum, pode receber o nome significativo da intenção; e assim, se
chama suposto. Mas também pode receber os três nomes significativos da coisa, a saber: ser de
natureza, subsistência e hipóstase, conforme ao tríplice aspecto da substância na acepção presente.
Assim, enquanto existente por si, e não em outro ser, chama-se subsistência; pois, dissemos subsistirem
por si as coisas existentes, não em outro ser, mas em si mesmas. Enquanto é o suposto de alguma
natureza comum, chama-se ser de natureza; como, este homem é um ser de natureza. E enquanto é o
suposto dos acidentes, chama-se hipóstase ou substância. Porém, o que esses três nomes significam
comumente em todo o gênero das substâncias, o nome de pessoa significa no gênero das substâncias
racionais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Hipóstase, entre os Gregos, pela própria significação do
nome, pode exprimir qualquer indivíduo substancial; mas pelo modo usual de falar, veio a significar o
indivíduo de natureza racional, por causa da excelência dessa natureza.

RESPOSTA À SEGUNDA. — Assim como nós dissemos que há em Deus a pluralidade de três pessoas e
três subsistências, assim os Gregos dizem que há nele três hipóstases. Mas como o nome de substância,
que pela significação própria corresponde ao de hipóstase, nós o empregamos equivocamente,
significando, ora, essência e, ora, hipóstase; preferiram, para não haver ocasião de erro,
traduzir hipóstase por subsistência e não por substância.

RESPOSTA À TERCEIRA. — A essência propriamente é a significada pela definição, e esta abrange os
princípios específicos e não os individuais. Por isso, nos seres compostos de matéria e forma, a essência
significa não somente a forma ou a matéria, mas o composto da matéria e da forma comum, como
princípios da espécie. Ora, o composto de tal matéria e de tal forma é por natureza hipóstase e pessoa.
Assim, a alma, a carne, os ossos são da essência do homem, mas tal alma, tal carne e tais ossos são da
essência de tal homem. Logo, a hipóstase e a pessoa acrescentam à noção de essência a de princípios
individuais; nem são o mesmo que a essência, nos compostos de matéria e forma, como dissemos,
quando tratamos da simplicidade divina.

RESPOSTA À QUARTA. — Boécio diz subsistirem os gêneros e as espécies, enquanto que a alguns
indivíduos é próprio o subsistir, por estarem compreendidos em gêneros e espécies inclusos no
predicamento da substância. E não que as próprias espécies ou gêneros subsistam, exceto segundo a
opinião de Platão, que admitia subsistirem as espécies das coisas separadamente dos indivíduos.
Substar, porém, é próprio aos mesmos indivíduos, em relação aos acidentes, que estão fora das idéias
de gêneros e de espécies.

RESPOSTA À QUINTA. — O indivíduo composto de matéria e forma pode substar ao acidente, pela
propriedade da matéria; por isso Boécio diz: A forma simples não pode ser sujeito. Mas se subsiste por
si, é pela propriedade da sua forma, que não se acrescenta à coisa subsistente, mas dá o ser atual à
matéria, de modo a poder assim subsistir o indivíduo. E por isso Boécio atribui a hipóstase à matéria, e
a ousiosis, ou subsistência, à forma; porque a matéria é o princípio do substar, e a forma, o do subsistir.

## Art. 3 — Se deve ser aplicado a Deus o nome de pessoa.
(I Sent., dist. XXIII, a. 2; De Pot., q. 9, a. 3).
O terceiro discute-se assim. — Parece que não deve ser aplicado a Deus o nome de pessoa.

1. — Pois, Dionísio diz: Universalmente falando, não devemos ousar dizer ou pensar nada, a respeito da
divindade oculta e supersubstancial, exceto o que nos foi divinamente revelado pelas Sagradas Letras.
Ora, o nome de pessoa não nos é expresso, na Sagrada Escritura, nem em o Novo nem no Velho
Testamento. Logo, não se deve aplicar a Deus o nome de pessoa.

2. Demais. — Boécio diz: O nome de pessoa originou-se das pessoas que representavam certos homens,
nas comédias e nas tragédias. Pois pessoa vem de personar, porque necessàriamente numa
concavidade o som se desenvolve mais intenso. Os Gregos, porém, chamavam a tais pessoas –
prósopa(máscaras), por se colocarem na face e, estando diante dos olhos, ocultarem o vulto. Mas tal
nome só metaforicamente talvez possa convir a Deus. Logo, o nome de pessoa só metaforicamente se
aplica a Deus.

3. Demais. — Toda pessoa é hipóstase. Ora, o nome de hipóstase parece não convir a Deus; pois, ela é,
segundo Boécio, o que substá aos acidentes, que em Deus não existem. E Jerônimo também diz que o
nome de hipóstase esconde o veneno debaixo do mel. Logo, o nome de pessoa se não deve aplicar a
Deus.

4. Demais. — Ao que não convém uma definição também não convém o definido. Ora, a definição
referida de pessoa parece não convir a Deus. Quer por importar a razão o conhecimento discursivo, que,
não convindo a Deus, como se demonstrou, não pode Deus ser dito de natureza racional. Quer também
porque Deus se não pode chamar substância individual; pois, de um lado, o princípio de individuação é a
matéria e Deus é imaterial; e, de outro, Deus, não substando aos acidentes, não se pode chamar
substância. Logo, o nome de pessoa não se deve aplicar a Deus.
Mas, em contrário, o símbolo de Atanásio diz: Uma é a pessoa do Pai, outra á do Filho, outra a do
Espírito Santo.

SOLUÇÃO. — Pessoa significa o que há de mais perfeito de toda a natureza, i. é, o que subsiste em a
natureza racional. Donde, como se devem atribuir a Deus todas as perfeições, pois a sua essência as
contêm todas, devemos aplicar-lhe o nome de pessoa. Não porém do mesmo modo pelo qual o
aplicamos à criatura, mas de modo mais excelente, como se dá com os outros nomes impostos à
criatura e atribuídos a Deus, conforme demonstramos quando tratamos dos nomes divinos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a Escritura, tanto no Velho como no Novo
Testamento, não aplique a Deus o nome de pessoa, contudo, o que o nome significa muitas vezes nela o
encontramos, aplicado a Deus, a saber, que é por excelência o ser existente por si mesmo e
perfeitíssimamente inteligente. Pois, se a Deus somente devêssemos aplicar necessariamente as
palavras que dele diz a Sagrada Escritura, seguir-se-ia que nunca poderíamos falar de Deus em língua
diversa daquela em que primeiro foi transmitida a Escritura do Velho e do Novo Testamento. Ora, a
necessidade de disputar com os heréticos obrigou a fé antiga a buscar novos nomes aplicáveis a Deus. E
nem tal novidade se devia evitar, que não é profana, por não se desviar do sentido das Escrituras. Pois, o
Apóstolo ensina que devemos evitar as palavras de novidade profana(1 Ti 6, 20).

RESPOSTA À SEGUNDA. — Embora o nome de pessoa não convenha a Deus, considerando-se a origem
desse nome, contudo convém-lhe soberanamente pelo seu conteúdo. Pois, de serem representados nas
comédias e nas tragédias certos varões famosos, veio a usar-se o nome de pessoa para significar os
homens revestidos de certa dignidade; e dai o costume de se chamarem pessoas, nas igrejas, aos que
têm alguma dignidade. Por isso certos definem como pessoa a hipóstase com propriedade distinta
pertencente à dignidade. E como muito digno é o subsistir em a natureza racional, por isso se chama
pessoa todo individuo de natureza racional, como vimos. Ora, a dignidade da natureza divina,
excedendo toda dignidade, também, a esta luz, convém a Deus o nome de pessoa, por excelência.

RESPOSTA À TERCEIRA. — O nome de hipóstase, considerada a causa que deu origem a esse nome, não
convém a Deus, pois, não é substância de acidentes. Mas, lhe convém se considerarmos o seu conteúdo,
pois, foi imposto para significar um ser subsistente. E Jerônimo diz que nesse nome se oculta o veneno,
porque antes de claramente conhecida a sua significação, entre os latinos, os helênicos dele usavam
para enganar os simples e os levar a admitir várias essências, desde que admitiam várias hipóstases, pois
o nome de substância, ao qual corresponde em grego o de hipóstase comumente é tomado, entre nós,
no sentido de essência.

RESPOSTA À QUARTA. — Deus pode chamar-se natureza racional, enquanto razão não implica discurso,
mas a natureza intelectual em geral. Mas ser indivíduo não pode convir a Deus, considerada a matéria
como princípio de individuação, senão somente enquanto implica a incomunicabilidade. A substância,
porém, convém a Deus, por significar ela o que existe por si. Alguns, contudo, dizem que a referida
definição de Boécio, não é definição de pessoa no sentido em que dizemos haver pessoas em Deus. E
por isso Ricardo de São Vitor, querendo corrigir essa definição, disse que a pessoa, quando se trata de
Deus, é a existência incomunicável da natureza divina

## Art. 4 — Se o nome de pessoa significa, em Deus, relação ou substância.
(I Sent., dist. XXIII, a. 3; De Pot., q. 9, a. 4).
O quarto discute-se assim. — Parece que não significa relação, em Deus, o nome de pessoa, mas a
substância divina.

1. — Pois, Agostinho escreve: Quando falamos na pessoa do Pai, nada dizemos diferente da substância
do Pai, referindo-se pessoa a ele, e não ao Filho.

2. Demais. — A questão o que é se formula a respeito da essência. Ora, como diz Agostinho, no mesmo
lugar, quando se afirma que Três são os que dão testemunho no céu, o Pai, o verbo e o Espírito Santo, e
se pergunta — Que três? — responde-se: As Três Pessoas. Logo, o nome de pessoa significa a essência.

3. Demais. — Segundo o Filósofo, o que é significado pelo nome é a sua definição. Ora, a definição de
pessoa é: substância individual de natureza racional, como se disse. Logo, o nome de pessoa significa
substância.

4. Demais. — A pessoa, nos homens e nos anjos, não significa relação, mas algo de absoluto. Se,
portanto, em Deus, significasse relação, equivocamente se diria dele, dos homens e dos anjos.
Mas, em contrário, diz Boécio, que todo nome concernente às Pessoas significa relação. Ora, nenhum
nome concerne de mais perto às Pessoas do que o nome de pessoa. Logo, tal significa relação.

SOLUÇÃO. — A significação do nome de pessoa, em Deus, dá origem a uma dificuldade, por ser
predicado, com pluralidade, das três Pessoas, fugindo, assim, à natureza dos nomes essenciais; e, além
disso, não se emprega em sentido relativo, como os nomes que exprimem relação. Por isso pensaram
alguns que o nome de pessoa, pura e simplesmente, por força do vocábulo, significa a essência divina,
como o nome de Deus e o de sábio. Mas, por causa dos ataques dos heréticos, e por ordem do Concílio,
conveio-se em que pudesse ser usado em sentido relativo, e sobretudo no plural ou com nome partitivo,
como quando dizemos — As Três Pessoas; ou — Uma é a Pessoa do Pai e outra, a do Filho. Porém, no
singular pode se tomar absoluta ou relativamente. — Mas, esta razão não é suficiente. Porque se o
nome de pessoa, por força da sua significação, não pode exprimir senão a essência divina, quando se diz
— três pessoas — não se elimina o erro dos heréticos; antes, dar-se-lhe-á ocasião de fortalecer-se.
E por isso outros disseram, que o nome de pessoa, em Deus, simultaneamente significa a essência e a
relação. — E desses, uns ensinaram que ele significa a essência principalmente, e a relação,
secundàriamente. Pois, pessoa significa, por assim dizer — por si uma. Ora, a unidade é própria da
essência. E o dizer-se — por si — implica relação, secundàriamente; pois, entende-se que o Pai existe
por si, como distinto do Filho, pela relação. — outros porém ensinaram, inversamente, que tal nome
significa relação, principalmente, e essência, secundàriamente; porque, na definição de pessoa,
natureza é posta secundariamente. E estes se achegaram mais da verdade.
Ora, para esclarecermos esta questão, devemos considerar que o que é próprio a uma significação
menos geral, pode não o ser a outra mais geral; assim, racional se inclui na significação de homem, sem
contudo incluir-se na de animal. Por isso, uma coisa é indagar a significação de animal, e outra, a do
animal que é homem. Semelhantemente, uma coisa é indagar a significação do nome de pessoa em
geral, e outra, a da pessoa divina. Pois, em geral, pessoa significa uma substância individual de natureza
racional, como se disse. O individuo, por outro lado, é em si mesmo indistinto, mas, distinto dos outros.
Logo, pessoa, em qualquer natureza, significa aquilo que, em tal natureza é distinto; assim, em a
natureza humana, tais carnes, tais ossos e tal alma, que são princípios individuantes do homem, e que,
embora não pertençam à significação da pessoa, em geral, pertencem contudo à da pessoa humana.
Ora, em Deus, a distinção não se faz senão pelas relações de origem, como se disse. Mas, nele, a relação
não é um acidente inerente ao sujeito, mas, a própria divina essência; portanto, é subsistente, como
esta. Logo, assim como a deidade é Deus, assim a paternidade divina é Deus Padre, que é uma pessoa
divina. Logo, a pessoa divina significa uma relação subsistente; o que é significá-la a modo de substância,
que é a hipóstase subsistente na divina natureza, embora desta não difira a sua subsistência.
E assim, é verdade que o nome de pessoa significa a relação, principalmente, e a essência,
secundariamente; não contudo a relação, como tal, mas como hipóstase. E semelhantemente, significa a
essência, principalmente, e a relação, secundariamente, enquanto essência é o mesmo que hipóstase; e
esta, em Deus, é uma relação distinta; e assim, a relação, como tal, secundariamente se inclui em a
noção de pessoa. E deste modo podemos também dizer, que essa significação do nome de pessoa não
foi percebida antes do ataque dos heréticos. Por isso, só era usado em sentido absoluto. Mas depois foi
aplicado em sentido relativo, por congruência com a sua significação. De modo que tal emprego relativo
lhe provém não somente do uso, segundo a primeira opinião, mas também da significação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O nome de pessoa se diz em sentido absoluto e não,
relativo, porque significa a relação, não como tal, mas, a modo de substância, que é a hipótese. E neste
sentido Agostinho diz, que significa a essência, por ser em Deus a essência idêntica à hipóstase, não
diferindo, nele,aquilo que é do pelo que é.

RESPOSTA À SEGUNDA. — A questão — o que é — ora se formula a respeito da natureza significada
pela definição, como quando se pergunta — que é o homem? e se responde — um animal
racional mortal. Ora, do suposto, como quando se pergunta — que nada no mar? e se responde — o
peixe. E assim a quem pergunta —que três? — responde-se — as Três Pessoas.

RESPOSTA À TERCEIRA. — Como se disse, a relação se entende em Deus no sentido de substância
individual, isto é, distinta ou incomunicável.

RESPOSTA À QUARTA. — A noção diversa do que é menos geral não gera equivocação, no mais geral.
Assim, embora diferente da do cavalo a definição própria do asno, ambas contudo se univocam em o
nome de animal, porque a ambas convém a definição geral deste. Donde, embora a significação da
pessoa divina implique a relação, e não, a pessoa angélica, ou humana, dai não se segue que o nome de
pessoa seja usado equivocamente. Embora também não o seja univocamente; pois, como se
demonstrou, nada se pode dizer univocamente de Deus e das criaturas.