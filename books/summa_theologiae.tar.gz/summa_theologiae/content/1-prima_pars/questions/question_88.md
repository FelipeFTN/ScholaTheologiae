# Questão 88: Como a alma humana conhece as coisas que lhe são superiores.
Em seguida deve-se considerar como a alma humana conhece as coisas que lhe são superiores, a saber,
as substâncias imateriais. E, sobre este ponto, três artigos se discutem:

## Art. 1 — Se a alma humana, no estado da vida presente, pode inteligir as substâncias imateriais, em si mesmas.
(II Cont. Gent., cap. LX ; III, cap. XLII usque ad XLVI; De Verit., q.10, a.11; q.18, a.5, ad 7 . 8 ; Qu. De
Anima, a.16 ; In Boet. De Trin., q.6, art. 3; II Metaphys., lect. I).
O primeiro discute-se assim. ― Parece que a alma humana, no estado da vida presente, pode inteligir
as substâncias imateriais em si mesmas.

1. ― Pois diz Agostinho: Assim como a alma colhe, pelos sentidos do corpo, os conhecimentos das coisas
corpóreas, assim, por si mesma, alcança conhecer os seres incorpóreos. Ora, estes são as substâncias
imateriais, Logo, a alma humana intelige tais substâncias.

2. Demais. ― O semelhante pelo semelhante se conhece. Ora, a mente humana mais se assemelha aos
seres imateriais que às coisas materiais, pois é imaterial, como resulta do que já disse antes (q. 76, a. 1).
Ora, se a nossa mente intelige as coisas materiais, com maior razão inteligirá as materiais.

3. Demais. ― Como a excelência dos sensíveis corrompe o sentido, daí vem que os sensíveis em si, em
máximo grau, não são nesse mesmo grau sentidos por nós. Ora, a excelência dos inteligíveis não
corrompe o intelecto, como já se disse. Logo, aquilo que é, em si, inteligível em máximo grau, é também
inteligível para nós, no mesmo grau. Como, porém, as coisas materiais não são inteligíveis, senão
porque as tornamos inteligíveis em ato, abstraindo da matéria, é manifesto que, em si, são mais
inteligíveis as substâncias imateriais, por natureza. Por onde, são muito mais inteligíveis por nós, que as
coisas materiais.

4. Demais. ― O comentador diz, que se as substâncias abstratas não pudessem ser inteligidas por
nós, então a natureza teria operado em vão, fazendo com que não seja inteligido por nenhum intelecto
aquilo que é, em si, naturalmente inteligido. Ora, nada é inútil ou vão, em a natureza. Logo, as
substâncias imateriais podem ser inteligidas por nós.

5. Demais. ― O sentido está para os sensíveis, como o intelecto para os inteligíveis. Ora, a nossa vista
pode ver todos os corpos, quer sejam superiores e incorruptíveis, quer inferiores e corruptíveis. Logo, o
nosso intelecto pode inteligir todas as substâncias inteligíveis, mesmo as superiores e imateriais.
Mas, em contrário, diz a Escritura (Sb 9, 16): As coisas que há nos céus, quem as investigará? Ora, as
sobreditas substâncias consideram-se como estando no céu, segundo a Escritura (Mt 18, 10): Os seus
anjos nos céus vêm incessantemente a face de meu Pai, que está nos céus. Logo, as substâncias
imateriais não podem ser conhecidas pela investigação humana.

SOLUÇÃO. ― Na opinião de Platão, as substâncias imateriais são não só inteligidas por nós, mas o são
primariamente. Pois, Platão ensinava, que as formas imateriais subsistentes, a que chamava idéias, são
os objetos próprios do nosso intelecto, sendo, assim, inteligidas por nós primariamente e por si. Ora, a
alma conhece as coisas materiais na medida em que a fantasia e o sentido se imiscuem no intelecto. Por
onde, quanto mais depurado for este, tanto mais perceberá a verdade inteligível dos seres imateriais.
Mas, segundo a doutrina de Aristóteles, mais de acordo com a nossa experiência, o nosso intelecto, no
estado da vida presente, tem relação natural com as naturezas das coisas materiais; e, por isso, nada
intelige senão voltando-se para os fantasmas, como é claro pelo que já foi dito (q. 84, a. 7). E, assim, é
manifesto que não podemos inteligir as substâncias imateriais, que não caem primariamente e por si
sob a alçada dos sentidos e da imaginação conforme o modo do conhecimentos que experimentamos.
Averróis, porém, diz que por fim, nesta vida, o homem pode chegar a inteligir as substâncias separadas,
pela continuação em nós ou pela união conosco de certa substância separada, a que
chama intelecto agente, a qual, como substância separada que é, intelige, naturalmente, as substâncias
separadas. Por onde, quando estiver unida conosco, de modo que, por ela, possamos inteligir
perfeitamente, também inteligiremos as substâncias separadas; como agora, pela nossa união com o
intelecto possível, inteligimos as coisas materiais.
E essa união do intelecto agente conosco ele a compreende do modo seguinte. Quando inteligimos pelo
intelecto agente e pelos inteligíveis especulados — como quando inteligimos as conclusões pelos
princípios já inteligidos — necessário é que o intelecto agente esteja para as coisas especuladas
inteligidas, como o agente principal está para os instrumentos ou como a forma para a matéria. Pois, é
destes dois modos que a ação é atribuída a dois princípios: ao agente principal e ao instrumento, como,
p. ex., a secção, atribuída ao artífice e à serra; à forma e ao sujeito, como, p. ex., a calefação, atribuída
ao calor e ao fogo. Ora, de ambos os modos, o intelecto agente há de estar para os inteligíveis
especulados, como a perfeição, para o perfectível e ao ato, para a potência. É simultaneamente, porém,
que um ser recebe o perfeito e a perfeição; assim a pupila recebe o visível em ato e a luz. Por onde, o
intelecto possível recebe simultaneamente os princípios especulados inteligidos, e o intelecto agente. E
quanto mais recebemos princípios especulados inteligidos, tanto mais nos aproximaremos do ponto em
que o intelecto agente há de unir-se conosco perfeitamente. De modo que, quando conhecermos todos
os princípios especulados inteligidos, então o intelecto agente unirá conosco perfeitamente e
poderemos, por ele, conhecer todos os seres, tanto os materiais como os imateriais. E nisto faz consistir
a felicidade última do homem. Nem importa, para a questão, que Averróis admita por si mesmo que,
nesse estado de felicidade, o intelecto possível intelige as substâncias separadas pelo intelecto agente;
ou que deduza essa opinião mostrando que, se fosse verdadeira a opinião de Alexandre, considerando
como corruptível o intelecto possível, então este nunca poderia inteligir as substâncias separadas.
Ora, também a opinião de Averróis, que acaba de ser exposta, não pode subsistir.
Primeiro, porque, se o intelecto agente é uma substância separada, impossível é que, por esta,
intelijamos formalmente; pois, é pela forma e pelo seu ato que o agente, formalmente, age, visto, que
todo agente age enquanto atual, como já disse antes (q. 76, a. 1), a respeito do intelecto possível.
Segundo, porque se o intelecto agente é como acaba de ser dito, uma substância separada, não se unirá
substancialmente, mas só pela sua luz, enquanto está é participada pelas coisas inteligidas especuladas,
e não em relação às outras ações do intelecto agente; de modo que, quando vemos as cores iluminadas
pelo sol, não se une conosco a substancia do sol, para que possamos fazer as ações deste; mas somente,
a luz do sol, para podermos ver as cores.
Terceiro, porque, dado que, pelo modo sobredito, a substância do intelecto agente se unisse conosco,
contudo os da opinião de Averróis ensinam que essa união é total, não quanto a um ou dois inteligíveis,
mas quanto a todas as coisas inteligidas. Ora, a virtude do intelecto agente não é esgotada por todas as
coisas especulativas inteligidas; porque muito mais é inteligir as substâncias separadas, do que, todas as
coisas materiais. Por onde é manifesto que, mesmo inteligidas que sejam todas as coisas materiais, nem
assim ficaria o intelecto agente unido conosco, de modo a podermos, por ele, inteligir as substâncias
separadas.
Quarto, porque, sendo concedido a muito raros, neste mundo, inteligir todos os objetos materiais,
ninguém, ou pouquíssimos, chegariam à felicidade. O que vai conta o Filósofo, dizendo que a felicidade
é um bem comum que podem alcançar todos os que não são privados da virtude. E é também contra a
razão que, de seres contidos numa espécie, só poucos consigam o fim da espécie.
Quinto, porque o Filósofo diz expressamente que a felicidade é a operação conforme à virtude perfeita.
E tendo enumerado muitas virtudes, conclui que a felicidade última, consistente no conhecimento dos
máximos inteligíveis, deve ser conforme à virtude da sapiência, que estabelecera como a capital, dentre
as ciências especulativas. Por onde se vê Aristóteles colocou a felicidade última do homem no
conhecimento das substâncias separadas, tais como podem ser alcançadas pelas ciências especulativas,
e não por união com o intelecto agente, imaginada por alguns.
Sexto, porque, como já se demonstrou antes (q. 79, a. 4), o intelecto agente não é uma substância
separada, mas uma virtude da alma, estendendo-se, ativamente, às mesmas coisas às quais, se estende,
receptivamente, o intelecto possível. Pois, como já se disse, o intelecto possível é o princípio pelo qual a
alma pode vir a ser todas as coisas, e o intelecto agente é o princípio de fazer todas as coisas. Por onde,
ambos esses intelectos se estendem, no estado da vida presente, só às coisas materiais que, tornadas
inteligíveis em ato, pelo intelecto agente, são recebidas no intelecto possível.
E portanto, no estado da vida presente, nem pelo intelecto possível, nem pelo intelecto agente,
podemos inteligir as substâncias separadas imateriais, em si mesmas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Do passo citado de Agostinho pode-se concluir que
aquilo que a nossa mente conhece, dos seres incorpóreos, pode conhecer por si mesma. E isto é tão
verdadeiro que, mesmo os filósofos podem dizer que a ciência da alma é um princípio para se
conhecerem as substâncias separadas. Pois, conhecendo-se a si mesma, a nossa alma atinge, na medida
em que isso lhe é possível, um certo conhecimento das substâncias incorpóreas; não as conhece, porém,
em si e perfeitamente, conhecendo-se a si mesma.

RESPOSTA À SEGUNDA. ― Se a semelhança de natureza fosse razão suficiente do conhecimento, então
seria necessário dizer, com Empédocles, que a alma, conhecendo tudo, tem a natureza de tudo. Mas o
necessário, para conhecer, é que a semelhança da coisa conhecida esteja no conhecente, como forma
deste. Ora, ao nosso intelecto possível, no estado da vida presente, é natural ser informado pelas
semelhanças das coisas materiais abstratas dos fantasmas; e, por isso, conhece melhor as coisas
materiais do que as substâncias imateriais.

RESPOSTA À TERCEIRA. ― Entre o objeto e a potência cognoscitiva é necessário haver a mesma relação
que há entre o ativo e o passivo, entre a perfeição e o perfectível. Por onde, se os sensíveis mais
excelentes não são apreendidos pelos sentidos, a razão não é só porque eles corrompam os órgãos
sensíveis, mas também porque são desproporcionadas às potências sensitivas. E, deste modo, as
substâncias imateriais são desproporcionadas ao nosso intelecto, no estado da vida presente, de modo
a não poder ser inteligidas por ele.

RESPOSTA À QUARTA. ― A razão abduzida, do Comentador, é deficiente sob múltiplos aspectos. ―
Primeiro, porque se as substâncias separadas não são inteligidas por nós, daí não se segue que não
sejam inteligidas por nenhum intelecto; pois, são inteligidas por si mesmas e umas, pelas outras. ―
Segundo, porque o fim das substâncias separadas não é serem inteligidas por nós. Ora, diz-se que é
inútil e vão o que não consegue o fim para qual existe. E assim, não se seguiria que as substâncias
imateriais fossem vãs, mesmo se, de nenhum modo, fossem inteligidas por nós.

RESPOSTA À QUINTA. ― Os sentidos conhecem os corpos superiores e os inferiores pelo mesmo modo,
que é a imutação do órgão, pelo sensível. Ora, as substâncias materiais, que inteligimos por meio da
abstração, não são inteligidas por nós do mesmo modo por que o são as substâncias imateriais; pois
estas, não tendo nenhuns fantasmas, não podem ser inteligidas pelo mesmo meio.

## Art. 2 — Se o nosso intelecto pode chegar a inteligir as substâncias imateriais, pelo conhecimento das coisas materiais.
(IV Sent., dist, XLIX, q.2, a.7, ad 12 ; II Cont. Gent., cap. XLI; De Verit., q.18, a. 5, ad 6; Qu. De Anima, a.16;
In Boet. De Trin., q.6, a.3, 4 ; I Poster., XLI; De Causis, lect. VII).
O segundo discute-se assim. ― Parece que o nosso intelecto pode chegar a inteligir as substâncias
imateriais, pelo conhecimento das coisas materiais.

1. ― Pois, como diz Dionísio, não é possível à mente humana subir à contemplação imaterial das
hierarquias celestes, sem ajudar-se do auxílio material em si. Logo, conclui-se que, pelas coisas
materiais, podemos ser levados a inteligir as substâncias imateriais.

2. Demais. ― A ciência está no intelecto. Ora, há ciências e definições das substâncias imateriais; pois,
Damasceno define o anjo; e, tanto as disciplinas teológicas como as filosóficas nos transmitem certos
ensinamentos a respeito dos anjos. Logo, as substâncias imateriais podem ser inteligidas por nós.

3. Demais. ― A alma humana pertence ao gênero das substâncias imateriais. Ora, ela pode ser inteligida
por nós, por meio do seu ato, pelo qual intelige as coisas materiais. Logo, também as outras substâncias
imateriais podem ser inteligidas por nós, por meio dos seus efeitos sobre as coisas materiais.

4. Demais. ― Só não pode ser compreendida pelos seus efeitos a causa que dista infinitamente deles.
Ora, isto só é próprio de Deus. Logo, as outras substâncias imateriais criadas podem ser inteligidas por
nós, por meio das coisas materiais.
Mas, em contrário, diz Dionísio, que os inteligíveis não podem ser apreendidos pelos sensíveis, nem os
seres simples pelos compostos, nem os incorpóreos pelos corpóreos.

SOLUÇÃO. ― Como refere Averróis, um certo Avempace ensinava que, pelos verdadeiros princípios da
filosofia, podemos chegar a inteligir as substancias imateriais, por meio da intelecção das materiais.
Pois, sendo natural ao nosso intelecto abstrair, da matéria, a qüididade da coisa material, se houver
ainda, nessa qüididade, algo de material, o intelecto poderá, de novo abstrair; e, como isto não vai até
ao infinito, ele poderá, finalmente, chegar a inteligir uma qüididade absolutamente sem matéria. E isto é
inteligir a substância imaterial. O que seria exatamente dito, se as substâncias imateriais fossem as
formas e as espécies das matérias, como ensinavam os Platônicos. Não posto, porém, mas suposto que
as substâncias imateriais sejam de essência totalmente diversa das qüididades das coisas materiais, por
mais que o nosso intelecto abstraia, da matéria, a qüididade da coisa imaterial, nunca chegará a algo de
semelhante à substância imaterial. Por onde, pelas substâncias materiais não podemos perfeitamente
inteligir as imateriais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Pelas coisas materiais podemos subir a um certo
conhecimento das imateriais; não porém, a um conhecimento perfeito. Pois, não há comparação
própria entre as coisas materiais e as imateriais; mas as semelhanças são muito dissemelhantes, como
diz Dionísio, se porventura algumas se deduzem, dos seres materiais, para se inteligirem os imateriais.

RESPOSTA À SEGUNDA. ― É sobretudo por via de remoção que, nas ciências, se tratam as coisas
superiores. Assim, Aristóteles dá a conhecer os corpos celestes pela negação das propriedades dos
corpos inferiores. Por onde, com maioria de razão, as substâncias imateriais não pode ser conhecidas
por nós, de modo que lhes apreendamos as qüididades. Mas as ciências nos transmitem ensinamentos
sobre elas, por via de remoção e por certas relações que têm com as coisas materiais.

RESPOSTA À TERCEIRA. ― A alma humana se intelige a si mesma pelo seu inteligir, ato próprio dela e
que revela perfeitamente a virtude e a natureza da mesma. Mas nem deste modo, nem pelo mais que
se descobre nas coisas materiais, pode ser conhecida perfeitamente a virtude e a natureza das
substâncias imateriais; porque os meios sobreditos não são adequados às virtudes delas.

RESPOSTA À QUARTA. ― As substâncias imateriais criadas não têm o mesmo gênero natural que as
substâncias materiais, porque não há nelas a mesma essência da potência e da matéria. Têm, todavia, o
mesmo gênero lógico, porque também as substâncias imateriais, nas quais a qüididade não se identifica
com o ser, entram no predicamento da substância. Ao passo que Deus não tem de comum com as coisas
materiais nem o gênero natural nem o lógico; pois Deus não está, absolutamente, em nenhum gênero,
como já disse antes (q. 3, a. 5). Por onde, pelas semelhanças das coisas materiais, pode ser conhecido,
afirmativamente, algo, sobre os anjo, quanto à essência comum deles, embora não quanto a essência
específica. De Deus, porém, de nenhum modo.

## Art. 3 — Se Deus é o que primariamente é conhecido pela mente humana.
(In Boet., De Trin., q. 1, a. 3).
O terceiro discute-se assim. ― Parece que Deus é o que primariamente é conhecido pela mente
humana.

1. ― Pois aquilo pelo qual todas as outras coisas são conhecidas e pelo que as julgamos, é
primariamente conhecido por nós; assim, a luz, pelos olhos, e os primeiros princípios, pelo intelecto.
Ora, à luz da verdade primeira conhecemos e julgamos todas as coisas, como diz Agostinho. Logo, Deus
é o que primariamente é conhecido por nós.

2. Demais. ― O que faz uma coisa ser o que é, tem, primariamente, as qualidades desta. Ora, Deus é a
causa de todo o nosso conhecimento; pois, como diz a Escritura (Jo 1, 9), é luz verdadeira que ilumina
todo homem vindo a este mundo. Logo, Deus é o que primariamente e em máximo grau é conhecido
por nós.

3. Demais. O que é primariamente conhecido, em imagem, é o exemplar pelo qual é formada. Ora, a
nossa mente é a imagem de Deus, como diz Agostinho. Logo, o que primariamente é conhecido pro ela
é Deus.
Mas, em contrário, diz a Escritura (Jo 1, 18): Ninguém jamais viu a Deus.

SOLUÇÃO. ― Como o intelecto humano ao estado da vida presente, não pode inteligir as substâncias
imateriais criadas, conforme já se disse (a. 1); não pode, com maior razão, inteligir a essência da
substância incriada. Por onde, deve-se dizer, simplesmente, que Deus não é o que primariamente é
conhecido por nós; mas, antes, pelas criaturas é que chegamos ao conhecimento de Deus, segundo
aquilo da Escritura (Rm 1, 20): As coisas invisíveis de Deus vêm-se, consideradas pelas coisas que foram
feitas. E o que primariamente é inteligido por nós, no estado da vida presente, é a qüididade da coisa
material, do objeto do nosso intelecto, como muitas vezes já se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― À luz da verdade primeira inteligimos e julgamos tudo,
enquanto a luz mesma do nosso intelecto, natural ou gratuita, não é senão uma certa impressão da
verdade primeira, como antes se disse (q. 84, a. 5). Por onde, como essa luz do nosso intelecto não está
para este como o que é inteligido, mas como o por que se intelige, com maior razão Deus não é o que
primariamente é inteligido pelo nosso intelecto.

RESPOSTA À SEGUNDA. ― O dito: o que faz uma coisa ser o que é tem, primariamente, as qualidades
desta, deve ser entendido de seres de uma mesma ordem, como antes se disse (q. 87, a. 2, ad 3). Ora, as
coisas são conhecidas por causa de Deus; não porque Deus seja o primeiro conhecido, mas porque é a
causa primeira da virtude cognoscitiva.

RESPOSTA À TERCEIRA. ― Se a nossa alma fosse a perfeita imagem de Deus, como o filho é do Pai, a
nossa alma inteligiria Deus imediatamente. Ora, como é uma imagem imperfeita, a objeção não colhe.
