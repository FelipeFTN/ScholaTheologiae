# Questão 55: Dos meios do conhecimento angélico.
Em seguida trataremos dos meios do conhecimento angélico. E, sobre este assunto, três artigos se
discutem:

## Art. 1 — Se os anjos conhecem pela sua substância.
(Infra, q. 84, a. 2, q. 87, a. 1; Iª IIª, q. 50, a. 6; q. 51, a.1, ad 2; II Sent., dist. III, part, II, a. 2, a. 1; III, dist.,

XIV, a. 1, qª 2; II Cont. Gent., cap. XLVIII; De Verit., q. 8, a. 8)
O primeiro discute-se assim. — Parece que os anjos conhecem pela substância.

1. — Pois Dionísio diz que os anjos conhecem as coisas da terra pela natureza própria da
inteligência. Ora, a natureza do anjo é a sua essência. Logo, é por esta que o anjo conhece as coisas;

2. Demais. — Segundo o Filósofo, nos seres sem matéria identificam-se a inteligência e o que é
inteligido. Ora, é em virtude daquilo pelo que se intelige que o inteligido se identifica com o ser que
intelige. Logo, nos seres sem matéria, como os anjos, o pelo que se intelige é a substância mesma do ser
inteligente.

3. Demais. — O que existe em outrem neste está ao modo do mesmo. Ora, o anjo, tendo natureza
intelectual, tudo o que nele existe aí está por modo inteligível, mas tudo nele está, porque os seres
inferiores estão nos superiores essencialmente, e estes, naqueles, participativamente; por onde, diz
Dionísio, que Deus congrega tudo em todos, isto é, todas as coisas em todos os seres. Logo, o anjo
conhece, na sua substância, todas as coisas.
Mas, em contrário, Dionísio diz que os anjos são iluminados pelas razões das coisas, logo, conhecem por
estas e não pela substância própria.

SOLUÇÃO. — O pelo que o intelecto intelige, está para o intelecto, que intelige, como se lhe fosse a
forma; pois é pela forma que o agente age. Ora, para a potência ser perfeitamente completada pela
forma, é necessário seja contido por esta tudo o ao que a potência se estende; e daí vem que, nos seres
corruptíveis, a forma não completa perfeitamente a potência da matéria, porque esta se estende a mais
seres que os abrangidos por tal ou tal forma. A potência intelectiva do anjo, porém, estende-se à
intelecção de todas as coisas, por ser o ente ou o verdadeiro comum o objeto do intelecto. Todavia, a
essência angélica, determinada a um gênero e a uma espécie, não compreende em si todas as coisas,
sendo isto próprio à essência divina, de tal modo infinita, que em si e de modo perfeito, compreende,
absolutamente, a todas. Por onde, só Deus conhece tudo pela sua essência; ao passo que o anjo assim
não conhece, sendo necessário que o seu intelecto sela aperfeiçoado por certas espécies, para as
conhecer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando se diz que o anjo conhece as coisas pela sua
natureza, a preposição pela não determina o meio de cognição, que pe a semelhança do objeto, mas a
virtude cognoscitiva, que convém ao anjo pela sua natureza.

RESPOSTA À SEGUNDA. — Como o sentido em ato é o sensível em ato, no dizer de Aristóteles, sem que,
todavia, a própria faculdade sensitiva seja a semelhança mesma do sensível que está no sentido, mas
que de ambos resulta a unidade como do ato e da potência; assim também se diz que a inteligência em
ato é o objeto inteligido em ato, não por ser a substância da inteligência a semelhança mesma pela qual
intelige, mas por lhe ser tal semelhança a forma. Assim, identifica-se esta expressão: nos seres sem
matéria o mesmo é a inteligência e o objeto inteligido. – como esta outra: inteligência em ato é o
inteligido em ato. Pois, é por ser imaterial que alguma coisa é inteligida em ato.

RESPOSTA À TERCEIRA. — As coisas inferiores, bem com as superiores, ao anjo lhe estão, de certo
modo, na substância; não por certo, perfeitamente, nem pela razão própria, pois a essência do anjo,
sendo finita, distingue-se, pela sua própria natureza, dos outros seres; mas por uma certa razão comum,
na essência de Deus, porém, estão todas as coisas perfeitamente e segundo a razão própria, como na
primeira e universal virtude operativa, da qual procede tudo quanto existe, seja próprio ou comum, em
qualquer coisa. E por isso Deus, pela sua essência, tem o conhecimento próprio de todas as coisas; não,
porém, o anjo, que só o tem comum.

## Art. 2 — Se os anjos inteligem por espécies recebidas das coisas.
(II Sent., dist. III, part. II, q. 2, a. 1 ad 2; II Cont. Gent., cap. XCVI; De Verit., q. 8, a. 9)
O segundo discute-se assim. — Parece que os anjos inteligem por espécies das coisas.

1. — Pois, tudo o que é inteligido o é por alguma semelhança de si existente no ser que intelige. Ora, a
semelhança de um ser, existente em outro, neste existe, ou a modo de exemplar, de maneira que tal
semelhança é a causa do ser. Por onde e necessariamente toda a ciência do ser inteligente ou será a
causa da coisa inteligida, ou será causada por esta. Ora, a ciência do anjo não é a causa das coisas
existentes, em a natureza, mas só a ciência divina. Logo, é necessário que todas as espécies pelas quais
o intelecto angélico intelige sejam recebidas das coisas.

2. Demais. — A luz da inteligência angélica é mais forte que a luz do intelecto agente, na alma. Ora, este
abstrai dos fantasmas as espécies inteligíveis. Logo, aquela pode abstrair as espécies mesmo das
próprias coisas sensíveis. E assim nada impede se diga que o anjo intelige por espécies recebidas das
coisas.

3. Demais. — As espécies existentes no intelecto comportam-se indiferentemente para com o presente
ou o distante, salvo enquanto recebidas das coisas sensíveis. Se, pois, o anjo não intelige por tais
espécies, o seu conhecimento, se comportaria indiferentemente para com as coisas próximas e as
distantes e, o anjo se moveria localmente em vão.
Mas, em contrário, diz Dionísioque os anjos não congregam o conhecimento divino mediante as coisas
divisíveis ou sensíveis.

SOLUÇÃO. — As espécies pelas quais os anjos inteligem não são recebidas das coisas, mas lhes são
conaturais a eles. Pois, a distinção e a ordem das substâncias espirituais devem ser entendidas como a
distinção e a ordem das corporais. Ora, os corpos superiores têm, em a sua natureza, a potência
totalmente aperfeiçoada pela forma; o que se não dá com os inferiores, que recebem ora, uma, ora,
outra forma, pela ação de algum agente. Semelhantemente, também as substâncias inferiores
intelectuais, a saber, as almas humanas, têm uma potência intelectiva naturalmente incompleta, mas
que se completa sucessivamente ao receberem das coisas as espécies inteligíveis. Porém, nas
substâncias espirituais superiores, isto é, nos anjos, a potência intelectiva é naturalmente completa
pelas espécies inteligíveis, enquanto estas lhe são conaturais para inteligir tudo que naturalmente
podem conhecer.
E isto mesmo também resulta do próprio modo de ser de tais substâncias. Pois, as almas substanciais
inferiores; i. é, as almas, têm um ser afim com o corpo, enquanto formas dos corpos; assim que, pelo
seu próprio modo de ser, lhes cabe obtenham dos corpos e por eles a sua perfeição inteligível; do
contrario, em vão estariam unidas a estes. Porém as substâncias superiores, i. é, os anjos, são
totalmente independentes dos corpos, subsistentes imaterialmente e no seu ser inteligível; e, por isso,
alcançam a sua perfeição inteligível por um efluxo inteligível, pelo qual recebem de Deus as espécies das
coisas conhecidas simultaneamente com a natureza intelectual. Por onde, diz Agostinho, que os outros
seres inferiores aos anjos são causados de tal modo que primeiro cheguem ao conhecimento da criatura
racional e, depois, sejam constituídos no seu gênero.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na mente do anjo estão as semelhanças das criaturas,
não destas mesmas promanadas, mas de Deus, causa delas e em quem primariamente existem a
semelhanças das coisas. E por isso Agostinho que, assim como a razão pela qual a criatura é feita está
primeiro no Verbo de Deus, do que essa criatura mesma, assim o conhecimento dessa mesma razão
primeiro se realiza na criatura intelectual, vindo, depois, a constituição mesma da criatura.

RESPOSTA À SEGUNDA. — Só pelo meio se pode chegar de um extremo a outro. Ora, o ser da forma, na
imaginação, e que, se bem não tenha matéria, não vai sem condições materiais, é o meio entre o ser da
forma, que está na matéria, e o da que está no intelecto pela abstração da matéria e das condições
materiais. Por onde, por poderoso que seja o intelecto angélico, não poderia reduzir as formas materiais
ao ser inteligível, sem que primeiro as reduzisse ao das formas imaginadas; ora, isto é impossível por
não ter o anjo imaginação, como já se disse. Mas mesmo dado que pudesse abstrair das coisas materiais
as espécies inteligíveis, não as abstrairia porque, tendo espécies inteligíveis conaturais, delas não
precisaria.

RESPOSTA À TERCEIRA. — O conhecimento do anjo se comporta indiferentemente para com o que é
localmente distante e próximo. Mas nem por isso o movimento local do anjo é em vão, pois, não se
move localmente para buscar o conhecimento, mas obrar alguma coisa em algum lugar.

## Art. 3 — Se os anjos superiores inteligem por espécies mais universais que a dos inferiores.
(Infra., q. 89, a. 1; Sent., dist. III, part. II, q. 2, a. 2; II Cont. Gent., cap. XCVIII; De Verit., q. 8, a. 10; Qu. De
Anima, a. 7, ad 2; a. 18; De Causis, lect. X)
O terceiro discute-se assim. — Parece que os anjos superiores não inteligem por espécies mais
universais que as dos inferiores.

1. — Pois, considera-se o universal como abstraído do particular. Ora, os anjos não inteligem por
espécies abstraídas das coisas. Logo, não se pode dizer que as espécies do intelecto angélico sejam mais
ou menos universais.

2. Demais. — O conhecido em especial o é mais perfeitamente do que o conhecido em universal; pois,
conhecer alguma coisa em universal é, de certo modo, o meio entre a potência e o ato. Se, portanto, os
anjos superiores conhecem por formas mais universais do que as dos inferiores, segue-se que aqueles
têm uma ciência mais imperfeita que a destes; o que é inadmissível.

3. Demais. — Coisas diversas não podem ter a mesma noção. Ora, se o anjo superior conhece, por uma
forma universal, as diversas coisas, que o inferior conhece por várias formas especiais, resulta que
aquele usa uma forma universal para conhecer coisas diversas. Logo, não poderá ter um conhecimento
próprio de cada uma; o que é inadmissível.
Mas em contrário diz Dionísio que os anjos superiores participam mais em universal, da ciência, do que
os inferiores. E, noutro passo que os superiores têm formas mais universais.

SOLUÇÃO. — entre os seres superiores são os que mais próximos e semelhantes são ao ser primeiro,
que é Deus. Ora, em Deus, toda a plenitude do conhecimento intelectual contém-se na una essência
divina, pela qual Ele tudo conhece. Esta plenitude inteligível porém existe nas criaturas inteligíveis de
modo inferior e menos absolutamente. E por isso é forçoso que as inteligências inferiores conheçam por
muitas espécies o que Deus conhece pela sua essência una; e tanto mais serão essas espécies quanto
mais inferior for a inteligência. Assim, pois, quanto mais for o anjo superior, tanto mais poderá
apreender, por menos espécies, a universalidade dos inteligíveis. E portanto e necessariamente as suas
formas serão mais universais, abrangendo cada uma delas muitas coisas. E mesmo em nós temos de
certo modo exemplo disto. Pois certos, por debilidade da inteligência, não podem compreender a
verdade inteligível sem que lhes expliquem cada verdade em particular; ao passo que outros, de mais
forte inteligência, com pouco podem compreender muito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O universal pode ser abstraído dos seres particulares,
enquanto o intelecto, conhecendo-o tira das coisas o conhecimento. Porém, ao intelecto que não
conhecer deste modo o universal por ele conhecido não será abstraído das coisas, mas lhes preexistirá
de certo modo; quer na ordem causal, sendo assim que as razões universais das coisas existem no Verbo
de Deus; quer ao menos, na ordem da natureza, estando assim tais razões no intelecto angélico.

RESPOSTA À SEGUNDA. — De dois modos se pode conhecer uma coisa em universal. Em relação à coisa
conhecida, como se se lhe conhecesse somente a natureza universal; e assim conhecer alguma coisa em
universal é conhecer de modo mais imperfeito; pois, imperfeitamente conheceria o homem quem dele
conhecesse apenas a qualidade de animal. De outro modo, quanto ao meio de conhecer e, assim, é mais
perfeito conhecer alguma coisa em universal; pois, mais perfeito é o intelecto que, por um meio
universal, pode conhecer cada ser em particular, do que não pode.

RESPOSTA À TERCEIRA. — Seres diversos não podem ter a mesma razão adequada. Mas, se for
excelente, pode ser uma mesma a razão própria e a semelhança de seres diversos. Assim, no homem, há
uma prudência universal quanto a todos os atos de virtude; e essa mesma pode ser considerada como
razão própria e semelhança da prudência particular do leão, quanto aos atos de magnanimidade; da
prudência da raposa, quanto aos atos de cautela, e assim por diante. Semelhantemente, a essência
divina, pela sua excelência, é tomada como a razão própria de tudo o que nela está singularmente;
donde o se lhe assimilarem os seres singulares pelas suas razões próprias. E do mesmo modo se deve
dizer, da razão universal existente na mente angélica, que por esta, em virtude da sua excelência, muitas
coisas podem ser conhecidas por conhecimento próprio.