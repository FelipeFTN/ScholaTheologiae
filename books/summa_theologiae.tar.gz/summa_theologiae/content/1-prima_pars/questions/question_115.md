# Questão 115: Da ação da criatura corpórea.
Em seguida deve-se tratar da ação da criatura corpórea; e do destino atribuído a certos corpos.
Sobre as ações corpóreas seis artigos se discutem:

## Art. 1 — Se há algum corpo ativo.
(III Cont. Gent., cap. LXIX; De Verit., q. 5, a. 9 ad. 4, De Pot., q. 4, a. 7)
O primeiro discute-se assim. — Parece que não há nenhum corpo ativo.

1. — Pois, diz Agostinho, há seres que são feitos e não agem, como os corpos; há um ser que é agente e
não feito, que é Deus; e há outros, agentes e feitos, que são as substâncias espirituais.

2. Demais. — Todos os agentes, exceto o primeiro, necessitam, para agir, de um sujeito, sobre o qual
lhes recaia a ação. Ora, abaixo da substância corpórea não há substância que seja susceptível de tal
ação, porque essa substância está no último grau dos seres. Logo, a substância corpórea não é ativa.

3. Demais. — Toda substância corpórea tem quantidade. Ora, a quantidade impede o movimento e a
ação da substância, porque a compreende e está como imersa nesta; assim como o ar nebuloso fica
impedido de receber a luz. E prova disto é que, quanto maior for a quantidade do corpo, tanto mais este
será pesado e grave ao mover-se. Logo, nenhuma substância corpórea é ativa.

4. Demais. — Todo agente recebe a sua virtude ativa da proximidade do ser ativo primeiro. Ora, os
corpos compostos, em máximo grau, são os mais afastados do ser abaixo primeiro, que é simplicíssimo.
Logo, nenhum corpo é agente.

5. Demais. — O corpo, que for agente, há-de agir, pela forma substancial ou pela acidental. Ora, hão por
aquela, porque os corpos não têm nenhum princípio de ação, a não ser as qualidades ativas, que são
acidentais; e o acidente não pode ser causa da forma substancial, porque a causa é superior ao efeito.
Nem, semelhantemente, pela forma acidental, porque o acidente não alcança além do seu sujeito, como
diz Agostinho. Logo, nenhum corpo é ativo.
Mas, em contrário, diz Dionísio que, entre as outras propriedades do fogo corpóreo, está a manifestação
da sua grandeza, como ativo e poderoso, em relação às matérias dela susceptíveis.

SOLUÇÃO. — É sensível que certos corpos são ativos. Mas há três opiniões erradas, relativamente às
ações dos corpos.
Assim, para uns os corpos são totalmente privados de ação. E esta é a opinião de Avicebrão, na obra A
Fonte da vida, em que aduz razões, esforçando-se por provar que nenhum corpo age, sendo todas as
ações, que parecem deles, as de alguma virtude espiritual, que os penetra a todos. Segundo tal opinião,
pois, não é o fogo que aquece, mas uma virtude espiritual, que penetra, por meio dele. E essa opinião
considera-se derivada da de Platão, que ensina serem todas as formas da matéria corpórea participadas,
determinadas e realizadas numa particular matéria; ao passo que as formas separadas são absolutas e
como que universais. E por isso considera essas formas separadas como causas das formas existentes na
matéria. Por onde, sendo a forma da matéria corpórea de terminada a uma certa matéria, individuada
pela quantidade, esta mesma quantidade, ensina Avicebrão, como princípio de individuação, retém e
impede a forma corpórea, para que não possa agir sobre outra matéria. E só a forma espiritual e
imaterial, não coarctada pela quantidade, pode influir sobre outra, pela sua ação.
Esta opinião porém não conclui que a forma corpórea não é agente, mas que não é agente universal.
Pois, na medida em que uma coisa é participada, nessa mesma há-de necessariamente ser participado o
que a essa coisa é próprio; assim, na medida em que um ser participa da luz, nessa mesma participa da
visibilidade. Ora, agir, que não é mais do que atualizar alguma coisa, é em si próprio do ato, como ato; e,
por isso todo agente age de modo semelhante a si. Por onde, a forma não determinada pela matéria
quantificada é agente indeterminado e universal; sendo porém determinada a uma certa matéria
particular, é agente determinado e particular. E assim se a forma do fogo fosse separada, como querem
os Platônicos, seria de certo modo a causa de toda ignição. Porém a forma do fogo, existente numa
determinada matéria corpórea, é a causa de uma determinada ignição, procedente de tal corpo para tal
outro; sendo por isso que esse ato se realiza pelo contato dos dois corpos.
Mas esta opinião de Avicebrão sobreexcede a de Platão. Pois, este ensina que só as formas substanciais
são separadas, e reduz as acidentais aos princípios materiais da grandeza e da pequenez, que considera
como os primeiros contrários, do mesmo modo que outros consideram tais a rarefação e a densidade.
Por onde, tanto Platão como Avicena, que em algo o segue, admitem que os agentes corpóreos agem
pelas formas acidentais, dispondo a matéria para a forma substancial; ao passo que a perfeição última,
que se realiza pela união com a forma substancial, procede de um princípio imaterial.
E esta é a segunda opinião sobre a ação dos corpos, à qual se aludiu antes, quando se tratou da criação.
A terceira opinião, enfim, é a de Demócrito, ensinando que a ação resulta do eflúvio dos átomos, do
corpo agente; e a paixão, do recebimento destes nos poros do corpo paciente. Esta opinião é refutada
por Aristóteles, pois dela resultaria que o corpo não seria passivo, na sua totalidade, e que a quantidade
do corpo agente diminuiria pela ação, conseqüências manifestamente falsas.
Logo, deve-se concluir que um corpo age, como atual, sobre outro corpo, como potencial.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dito de Agostinho pode ser concedido, como referente
a toda a natureza corpórea, simultaneamente considerada, que não tem nenhuma natureza inferior
sobre que atue, como a natureza espiritual age sobre a corpórea e a incriada, sobre a criada. Porém o
corpo que é potencial em relação a outro, no que tem este de atual, é-lhe inferior.

DONDE SE DEDUZ CLARA A RESPOSTA À SEGUNDA OBJEÇÃO. — Deve-se contudo saber que é
admissível o argumento seguinte de Avicebrão: Há um motor não movido, e é esse o autor primeiro das
causas; logo, por oposição, há algo que é somente movido e paciente, que é a matéria prima, potência
pura, como Deus é o ato puro. O corpo, porém, sendo composto de potência e ato, é agente e paciente.

RESPOSTA À TERCEIRA. — A quantidade não priva, de nenhum modo, a forma corpórea, da ação, como
já se disse; mas a impede de ser agente universal, porque a forma é individuada pela matéria sujeita à
quantidade. Não vem a ponto, porém, a prova deduzida do peso dos corpos. Primeiro, porque a
quantidade adicionada não é a causa da gravidade, como o prova Aristóteles. Segundo, por ser falso que
o peso torna o movimento mais lento; antes, quanto mais um corpo é pesado, tanto mais se move com
movimento próprio. Terceiro, porque a ação não se realiza pelo movimento local, como ensina
Demócrito, mas pela passagem da potência para o ato.

RESPOSTA À QUARTA. — O corpo não é o que dista de Deus, em máximo grau; pois, participa algo da
semelhança do ser divino, pela forma que tem. Mas é a matéria prima o que há de mais distante de
Deus, a qual, sendo somente potencial, de nenhum modo é agente.

RESPOSTA À QUINTA. — O corpo age tanto pela forma acidental como pela substancial. Assim, a
qualidade ativa, como o calor,embora seja acidente, age contudo em virtude da forma substancial,
como instrumento desta; e portanto pode agir como forma substancial. Assim, o calor natural, enquanto
instrumento da alma, age para a geração da carne. Como acidente porém age por virtude própria. Nem
é contra a essência do acidente o exceder o seu sujeito, pela ação, mas sim, pela existência; a menos
talvez que alguém imagine que um acidente, numericamente o mesmo, deflua do agente para o
paciente, no sentido de Demócrito, que ensina que a ação se realiza pelo eflúvio dos átomos.

## Art. 2 — Se na matéria corpórea há razões seminais.
(II Sent., dist. XVIII, q. 1, a. 2; De Verit., q. 5, a. 9, ad 8).
O segundo discute-se assim. — Parece que na matéria corpórea não há razões seminais.

1. — Pois, razão importa algo de espiritual. Ora, na matéria corpórea nada há espiritual, mas somente
material, i. é, conforme a natureza dela. Logo, não há nela razões seminais.

2. Demais. — Agostinho diz, que os demônios fazem certas obras, servindo-se, com movimentos
ocultos, de certos germes, que conhecem como existentes nos elementos. Ora, coisas aplicadas por
meio do movimento local são corpos e não razões. Logo, é incongruente dizer-se que há na matéria
corpórea razões seminais.

3. Demais. — O sêmen é princípio ativo. Ora, na natureza corpórea não há nenhum princípio ativo,
porque não é próprio dela agir, como já se disse. Logo, nela não há razões seminais.

4. Demais. — Diz-se que há na matéria certas razões causais que se consideram suficientes para a
produção das coisas. Ora, essas razões são diferentes das seminais, porque, há milagres que vão contra
aquelas e não contra estas. Logo, é inconveniente dizer-se que há razões seminais na matéria corpórea.
Mas, em contrário, diz Agostinho: Há nos elementos corpóreos de todas as coisas diste mundo, que
nascem, corporal e visivelmente, certos germes latentes.

SOLUÇÃO. — Como diz Aristóteles, é costume derivar as denominações, do que é mais perfeito. Ora, em
toda a natureza corpórea são os seres vivos os mais perfeitos, e por isso o próprio nome de natureza
passou, dos seres vivos, para todos os seres naturais. Pois, como diz o Filósofo, o próprio nome de
natureza foi primitivamente imposto para exprimir a geração dos seres vivos, chamada natividade. E
sendo os seres vivos gerados de um princípio conjunto, como o fruto, da árvore, e o feto, da mãe, a que
está ligado, estendeu-se, por conseqüência, o nome da natureza a todo princípio de movimento, que
existe no ser movido. Ora, é manifesto que o princípio ativo e passivo da geração dos seres vivos é o
sêmen, de que são gerados. E por isso Agostinho convenientemente chama razões seminais a todas as
virtudes ativas e passivas, princípios das gerações e dos movimentos naturais.
Estas virtudes ativas e passivas porém podem ser consideradas em múltipla ordem. — Pois, em primeiro
lugar, como diz Agostinho, existem no Verbo mesmo de Deus, principal e originàriamente, como razões
ideais. — Em segundo lugar, existem nos elementos do mundo, como nas causas universais, e foram
produzidas simultaneamente com eles. — Em terceiro lugar, estão nas coisas produzidas pelas causas
universais, na sucessão dos tempos; assim, estão numa determinada planta e num determinado animal,
como em causas particulares. — De quarto modo, existem nos germes gerados dos animais e das
plantas, estando então para os outros efeitos particulares, como as causas primordiais universais para
os primeiros efeitos produzidos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essas virtudes ativas e passivas dos seres naturais,
embora se não possam chamar razões, por existirem na matéria corpórea, podem contudo se chamar
assim quanto à origem, porque são derivadas das razões ideais.

RESPOSTA À SEGUNDA. — Essas virtudes ativas e passivas estão em certas partes corpóreas; e se diz
que são aplicados pelos demônios os germes, quando eles empregam tais virtudes, pelo movimento
local, para produzirem certos efeitos.

RESPOSTA À TERCEIRA. — O sêmen masculino é o princípio ativo na geração do animal; mas também se
pode chamar sêmen ao princípio feminino, que é passivo. E assim o mesmo nome pode significar as
virtudes ativas e as passivas.

RESPOSTA À QUARTA. — Das palavras de Agostinho, ao tratar das razões seminais, pode-se
suficientemente concluir que essas mesmas razões são também causais, como o sêmen; pois, diz ele,
que assim como as mães são grávidas dos seus fetos, assim também o mundo está prenhe das causas
dos seres que se vão produzir. Mas também as razões ideais podem se chamar causais; não porém
propriamente falando, seminais, porque o sêmen não é um princípio separado. E contra tais razões não
podem ser feitos milagres, bem como não o podem contra as virtudes passivas infusas na criatura, de
modo que desta possa ser feito tudo o que Deus mandar. Mas contra as virtudes ativas naturais e as
potências passivas ordenadas a tais virtudes, consideram-se feitos os milagres operados contra as
razões seminais.

## Art. 3 — Se os corpos celestes são a causa do que é feito neste mundo, nos corpos inferiores.
(II Sent., dist. XV, q. 1, a. 2; III Cont. Gent., cap. LXXXII; De Verit., q. 5, a. 9; Compend. Theol., cap.

CXXVII).
O terceiro discute-se assim. — Parece que os corpos celestes não são a causa do que é feito, neste
mundo, nos corpos inferiores.

1. Pois, diz Damasceno: Nós porém dizemos que eles, i. é, os corpos celestes, não são a causa de nada
que é feito, nem da corrupção do que se corrompe; são porém, sobretudo, os sinais das chuvas e da
transmutação do ar.

2. Demais. — O agente e a matéria bastam para produzir uma coisa. Ora, há nos corpos inferiores deste
mundo a matéria paciente e também agentes contrários, como o calor, o frio e outros semelhantes.
Logo, não é necessário, atribuir a causalidade do que é feito, nas coisas inferiores sobreditas, aos corpos
celestes.

3. Demais. — O agente age semelhantemente a si. Ora, vemos que tudo, neste mundo é causado pelo
calor e pelo frio, pela umidade e pela secura, e alterações qualitativas semelhantes, que não se dão nos
corpos celestes. Logo, estes não são a causa do que é feito nas coisas deste mundo.

4. Demais. — Como diz Agostinho, nada é mais corpóreo do que o sexo. Ora, o sexo não é causado pelos
corpos celestes; e a prova é que, de dois gêmeos, nascidos sob a mesma constelação, um é masculino e
outro, feminino. Logo, os corpos celestes não são causa das coisas corpóreas realizadas neste mundo.
Mas, em contrário, diz Agostinho: os corpos mais grosseiros e inferiores são regidos, numa certa ordem,
pelos mais subtis e poderosos. E Dionísio diz: a luz do sol contribui para a geração dos corpos sensíveis,
gera a própria vida, nutre, faz crescer e leva ao termo.

SOLUÇÃO. — Considerando que toda multidão procede da unidade; que o imóvel conserva-se do
mesmo modo, e o movido tem aspectos multiformes, deve-se concluir que em toda a natureza,
qualquer movimento procede do que é imóvel. Por onde, quanto mais um ser é imóvel, tanto mais é
causa do que é móvel. Ora, os corpos celestes são os mais imóveis de todos os corpos, pois só têm
movimento local. E portanto os movimentos vários e multiformes dos corpos inferiores deste mundo
dependem do movimento dos corpos celestes, como de causa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dito de Damasceno deve-se entender como
exprimindo que os corpos celestes não são a causa primeira da geração e da corrupção das coisas, que
se operam neste mundo, como dizem os que os consideram como deuses.

RESPOSTA À SEGUNDA. — Como princípios ativos, os corpos inferiores deste mundo têm só as
qualidades ativas dos elementos, a saber, o calor, o frio e outros. E se as formas substanciais dos corpos
inferiores só se diversificassem por esses acidentes, cujos princípios os antigos fisiólogos diziam ser a
rarefação e a condensação, não seria necessária a existência de nenhum princípio ativo superior a esses
corpos, mas eles agiriam por si mesmos. Os que pensarem bem, pois, concordarão que esses acidentes
comportam-se como disposições materiais para as formas substanciais dos corpos naturais. Ora, a
matéria não podendo agir por si mesma, é necessário admitir-se algum princípio ativo superior a essas
disposições materiais. Daí o terem os Platônicos admitido as espécies separadas, pela participação das
quais os corpos inferiores alcançam as suas formas substanciais. Estas porém não bastam; porque, tais
espécies sendo consideradas como imóveis, daí resultaria que os corpos inferiores não teriam nenhuma
variação, quanto à geração e à corrupção, o que é falso. Por onde, segundo o Filósofo, necessário é
admitir-se algum princípio ativo móvel, causa, pela sua presença e ausência, da variedade dos corpos
inferiores, quanto à geração e à corrupção; e tais são os corpos celestes. E por isso, tudo o que, nos
corpos inferiores deste mundo, gera e especifica, é como que instrumento do corpo celeste, o que
permite dizer que o homem e o sol geram o homem.

RESPOSTA À TERCEIRA. — Os corpos celestes não são semelhantes aos corpos inferiores, por
semelhança específica, mas porque contêm em sua virtude universal tudo o que nos inferiores é gerado.
E desse modo dizemos também que todas as coisas são semelhantes a Deus.

RESPOSTA À QUARTA. — As ações dos corpos celestes são recebidas diversamente pelos corpos
inferiores, conforme à disposição diversa da matéria deles. Assim, acontece às vezes que a matéria da
concepção humana não está totalmente disposta para o sexo masculino e, por isso forma em parte· o
masculino e em parte o feminino. E disto se serve Agostinho para repelir a adivinhação por meio dos
astros, porque os efeitos destes variam, mesmo em relação às coisas corpóreas, segundo as disposições
diversas da matéria.

## Art. 4 — Se os corpos celestes são causa dos atos humanos.
(IIª IIae, q. 95, a. 5; II Sent., dist.. XV, q. I, a. 3; XXV, a. 2, ad 5; III Cont. Gent., cap. LXXXIV, LXXXV. LXXXVII;
De Verit., q. 5, a. 10; Compend. Theol., cap. CXXVII, CXXVIII; I Pheriherm., Iect. XIV; III De Anima, lect: IV;

VI Metaphys., Iect. III; In Matth., capo II).
O terceiro discute-se assim. — Parece que os corpos celestes são causa dos atos humanos.

1. — Pois, esses corpos, sendo movido: pelas substâncias espirituais, como já se disse, agem como
instrumentos, pela virtude delas. Ora, tais substâncias são superiores às nossas almas. Donde resulta,
que podem causar impressão nestas e, portanto, serem causa dos atos humanos.

2. Demais. — Tudo o que é multiforme depende de princípio uniforme. Ora, os atos humanos são vários
e multiformes. Logo, dependem dos movimentos uniformes dos corpos celestes, como do princípio.

3. Demais. — Os astrólogos freqüentemente vaticinam sobre os acontecimentos bélicos e outros atos
humanos, cujos princípios são o intelecto e a vontade. Ora, tal não poderiam fazer se os corpos celestes
não fossem causa dos atos humanos. Logo, eles são tal causa.
Mas em contrário, diz Damasceno: os corpos celestes não são de nenhum modo causa dos atos
humanos.

SOLUÇÃO. — Os corpos celestes podem diretamente e por si impressionar os outros corpos, como já se
disse; nas potências da alma humana, porém, que são atos de órgãos corpóreos, causam impressão,
direta, mas acidentalmente; pois, os atos dessas potências são necessariamente obstruídos pelo
obstáculo dos órgãos; assim, os olhos torvos não vêm bem.
Por onde, se o intelecto e a vontade fossem virtudes ligadas a órgãos corpóreos, como ensinaram
alguns, dizendo que o intelecto não difere do sentido, daí necessariamente resultaria que os corpos
celestes são causa das eleições e dos atos humanos. E, por conseqüência o homem agiria por instinto
natural, como os animais, que lhe são inferiores e que. tendo as virtudes da alma ligadas a órgãos
corpóreos, sempre agem naturalmente, por impressão dos corpos celestes. E dai a conclusão que o
homem não teria livre arbítrio, mas seria determinado nas suas ações, como os outros seres naturais.
Conclusões manifestamente falsas e contrárias à linguagem humana.
Deve-se pois saber que, indiretamente e por acidente, as impressões dos corpos celestes podem influir
sobre o intelecto e a vontade, enquanto aquele e esta recebem algo das virtudes inferiores, ligadas a
órgãos corpóreos. Mas, relativamente a isso, o intelecto se comporta diferentemente da vontade. Pois,
recebe os seus dados, necessariamente, das virtudes inferiores; por onde, turbadas as virtudes imagina-
tiva, cogitativa ou memorativa, necessariamente há-de turbar-se a ação do intelecto. A vontade porém
não segue necessariamente a inclinação do apetite inferior. Pois, embora as paixões do irascível e do
concupiscível, exerçam certa influência para inclinar a vontade, contudo esta conserva o poder de as
seguir ou combater. Por onde, a impressão dos corpos celestes, na medida em que podem imutar as
virtudes inferiores, alcança menos a vontade, causa próxima dos atos humanos, que o intelecto.
Admitir, pois, que os corpos celestes são causa dos atos humanos, é opinião própria dos que dizem que
o intelecto não difere dos sentidos. Assim, um deles dizia: a vontade dos homens é tal qual o pai dos
homens e dos deuses a causa, cada dia. Ora, como é certo que o intelecto e a vontade não são atos de
órgãos corpóreos, impossível é sejam os corpos celestes a causa dos atos humanos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As substâncias espirituais, que movem os corpos
celestes, agem por certo sobre as corpóreas, mediante tais corpos; mas sobre o intelecto humano agem
imediatamente, iluminando, embora não possam imutar a vontade, como já se estabeleceu.

RESPOSTA À SEGUNDA. — Assim como a multiformidade dos movimentos corpóreos se reduz, como à
causa, à uniformidade dos movimentos celestes, assim a multiformidade dos atos do intelecto e da
vontade se reduz ao princípio uniforme, que são o intelecto e a vontade de Deus.

RESPOSTA À TERCEIRA. — A maior parte dos homens seguem as paixões, movimentos sensitivos do
apetite, para as quais podem concorrer os corpos celestes; ao passo que são poucos os prudentes, que
resistem a tais paixões. E por isso os astrólogos, na maioria dos casos, podem predizer a verdade; e,
sobretudo, em comum. Não porém em especial, porque nada impede que um homem, com o livre
arbítrio, resista às paixões. Por onde, os próprios astrólogos dizem, que o homem prudente domina os
astros, na medida em que domina as paixões próprias.

## Art. 5 — Se os corpos celestes podem causar impressões sobre os demônios.
(De Pot., q. 6: a. 10).
O quinto discute-se assim. — Parece que os corpos celestes podem causar impressões sobre os
demônios.

1. — Pois, os demônios, em dependência de certos crescentes da lua, Vexam os homens, que por isso se
chamam lunáticos, como se lê na Escritura. Ora, tal não se daria se os demônios não estivessem sujeitos
aos corpos celestes. Logo, eles o estão.

2. Demais. — Os nigromantes observam certas constelações para invocar os demônios. Ora, estes não
seriam invocados, por meio dos corpos celestes, se a eles não estivessem sujeitos. Logo, estão sujeitos
às ações de tais corpos.

3. Demais. — Os corpos celestes têm maior virtude que os inferiores. Ora, os demônios são afastados
por certos corpos inferiores, como ervas, pedras e animais; por certos sons determinados; e por vezes,
figurações e fingimentos, como diz Porfírio, citado por Agostinho. Logo, com maior razão, estão sujeitos
à ação dos corpos celestes.
Mas, em contrário, os demônios são superiores, na ordem da natureza, aos corpos celestes. Pois, o
agente é superior ao paciente, como diz Agostinho. Logo, os demônios não estão sujeitos à ação dos
corpos celestes.

SOLUÇÃO. — Sobre os demônios há tríplice opinião. — A primeira é a dos Peri patéticos, que ensinam a
não existência deles; e o que a arte nigromântica lhes atribui faz-se por virtude dos corpos celestes. E
neste sentido é que Agostinho cita o dito de Porfírio: na terra são fabricadas pelos homens, potestades
aptas a obedecerem aos vários efeitos dos astros. Mas esta opinião é manifestamente falsa. Pois, a
experiência ensina que, por meio dos demônios, são feitas muitas coisas, para o que de nenhum modo
bastaria a virtude dos corpos celestes. Assim, o falarem os possessos língua que desconhecem; citarem
versos e passos de autores que nunca conheceram; fazerem os nigromantes com que estátuas falem e
se movam, e coisas semelhantes.
Isto levou os Platônicos a dizer que os demônios são animais de corpo aéreo e espírito passivo,
conforme Apuleio, citado por Agostinho. E esta é a segunda opinião, de acordo com a qual os demônios
estão sujeitos aos corpos celestes, do mesmo modo pelo qual, como já se estabeleceu, o estão os
homens. Mas, pelo que ficou exposto, esta opinião é evidentemente falsa. Pois, como já dissemos, os
demônios são substâncias intelectuais não unidas a corpos. — Por onde é claro que não estão sujeitos à
ação dos corpos celestes; nem em si mesmos, nem acidental, nem direta, nem indiretamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por duas razões é que os demônios podem vexar os
homens, conforme certos crescentes da lua. — Primeira, para infamarem uma criatura de Deus, como o
é a lua, segundo dizem Jerônimo e Crisóstomo. — A segunda está em que, podendo operar só mediante
as virtudes naturais, como antes se disse, consideram, nas suas obras, as aptidões dos corpos para os
efeitos intencionados. Ora, é manifesto que o cérebro é a mais úmida de todas as partes do corpo, como
diz Aristóteles; e por isso está sujeito em máximo grau à ação da lua, que tem a propriedade de mover o
humor. E como no cérebro é que têm o seu complemento as virtudes animais, por isso os demônios,
conforme certos crescentes da lua, perturbam a fantasia do homem, quando descobrem que o cérebro
está disposto para isso.

RESPOSTA À SEGUNDA. — Os demônios invocados sob certas constelações, acodem por duas razões. —
Primeira, para fazerem os homens erradamente crer que há, nas estrelas, algum nome. — Segunda,
porque vêm que, sob certas constelações, a matéria corpórea está mais disposta aos efeitos para os
quais foram invocados.

RESPOSTA À TERCEIRA. — Como diz Agostinho, os demônios são aliciados por vários gêneros de pedras,
ervas, vegetais, animais, versos e ritos, não como os animais, pelos alimentos, mas como os espíritos,
pelos sinais, a saber, enquanto tais coisas lhes são exibidas como sinal da honra divina, que para si
desejam.

## Art. 6 — Se os corpos celestes impõem necessidade ao que lhes está sujeito à ação.
(II Sent., dist. XV. q. I, a. 2, ad 3; a. 3. ad 4; III Cont. Gent., cap. LXXXVI; De Verit., q. 5, a. 9, ad I, 2; De
Malo, q. 6, ad 21; q. 16, a. 7. ad 14, 16; I Perihem., lect. XIV; VI Metaphys., lecl. III).
O sexto discute-se assim. — Parece que os corpos celestes impõem necessidade ao que lhes está
sujeito à ação.

1. — Pois, posta a causa suficiente, necessariamente segue-se o efeito. Ora, os corpos celestes são causa
suficiente dos seus efeitos. E como esses corpos, com os seus movimentos e disposições, são
considerados seres necessários, conclui-se que os efeitos deles se seguem necessariamente.

2. Demais. — O efeito do agente resulta, na matéria, necessariamente, quando a virtude daquele for tal
que possa submeter esta a si totalmente. Ora, a matéria total dos corpos inferiores está sujeita à virtude
dos corpos celestes, como sendo mais excelente. Logo, o efeito desses corpos é recebido,
necessariamente, pela matéria corpórea.

3. Demais. — Se os efeitos do corpo celeste não se produzirem necessariamente, há-de ser por alguma
causa impediente. Mas qualquer causa corpórea, que possa impedir o eleito do corpo celeste, há-de
necessariamente reduzir-se a algum princípio celeste, porque os corpos celestes são a causa de tudo o
que neste mundo se faz. Logo, como esse princípio é necessário, segue-se que necessariamente fica
impedido o efeito de outro corpo celeste, e assim tudo, neste mundo acontece necessariamente.
Mas, em contrário, diz o Filósofo: não há inconveniente em que deixem de produzir-se muitas daquelas
coisas corpóreas, como as águas e os ventos, que são sinais celestes. Assim, pois, nem todos os efeitos
dos corpos celestes realizam-se necessariamente.

SOLUÇÃO. — A questão presente já está em parte resolvida pelo que ficou estabelecido; em parte,
porém, encerra alguma dificuldade. Pois, como já se demonstrou, embora, por impressão dos corpos
celestes, realizam-se certas inclinações em a natureza corpórea, a vontade contudo não obedece a essas
inclinações necessariamente. E portanto nada impede que, pela eleição voluntária, fique impedido o
efeito dos corpos celestes, não só em relação ao homem, mas também em relação a outras coisas a que
se estende a operação humana. Ora, nenhum princípio semelhante existe nos seres naturais, pelo qual
tenham a liberdade de obedecer ou não ás impressões celestes. Donde resulta, que em relação a tais
seres, pelo menos, tudo se realiza necessariamente, segundo a opinião antiga de certos que, supondo
que tudo o que existe tem causa e que, introduzida a causa, o efeito se segue necessariamente,
concluíam que tudo se produz necessariamente.
Mas essa opinião Aristóteles a rejeita refutando os dois princípios mesmos donde os adversários
partem. — Primeiro, não é verdade resulte o efeito, necessariamente, de qualquer causa suposta;
assim, certas causas se ordenam aos seus efeitos, não necessariamente, mas quase sempre; e por isso,
às vezes falham, em alguns casos. Mas se falham às vezes, por efeito de alguma outra causa impediente,
não fica de pé a refutação proposta porque esse impedimento mesmo, se dá necessariamente. — E por
isso, deve-se dizer que, tudo o existente por si tem causa; não a tem porém o que é acidental, porque
não tendo verdadeira unidade, não é verdadeiro ente. Assim, o branco tem causa; e semelhantemente,
o músico; mas não, músico branco porque, não e verdadeiro ente, nem tem verdadeira unidade. Ora, é
,
manifesto que a causa impediente da ação de qualquer outra causa ordenada, na maior parte das vezes,
ao seu efeito, concorre com esta, às vezes acidentalmente; e, tal concurso, sendo acidental, não tem
causa. Por onde, o que resulta desse concurso não se reduz a nenhuma causa preexistente, da qual haja
necessariamente de resultar. Assim, é alguma causa celeste que faz um corpo terrestre ígneo ser gerado
na parte superior do ar e cair; semelhantemente, a existência na superfície da terra de qualquer matéria
combustível pode se reduzir a algum princípio celeste.
Mas nenhum corpo celeste é causa de que o fogo cadente encontre essa matéria e a queime — fato
acidental. Por onde, é claro que nem todos os efeitos dos corpos celestes são necessários.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os corpos celestes são causa dos efeitos inferiores
mediante as causas particulares inferiores, que às vezes podem falhar.

RESPOSTA À SEGUNDA. — A virtude do corpo celeste não é infinita e por isso exige uma determinada
disposição na matéria, para produzir o seu efeito, tanto em relação à distância local como em relação às
outras condições. E portanto, assim como a distância local impede o efeito do corpo celeste — pois o sol
não produz o mesmo efeito calorífico na Dácia e na Etiópia — assim também a espessura, a frigidez, a
calidez e outras disposições semelhantes da matéria podem impedir o efeito desse corpo.

RESPOSTA À TERCEIRA. — Embora a causa impediente do efeito de outra causa seja redutível a algum
corpo celeste, como à causa; contudo o concurso de duas causas, sendo acidental, não se reduz à causa
celeste, como já se disse.