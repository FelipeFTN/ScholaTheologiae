# Questão 95: Do que se refere à vontade do primeiro homem, a saber da
graça e da justiça.
Em seguida devemos tratar o que diz respeito à vontade do primeiro homem. E sobre este ponto duas
questões se discutem. A primeira, da graça e da justiça do primeiro homem. A segunda, do uso da
justiça, quanto ao domínio sobre os demais seres.

## Art. 1 — Se o primeiro homem foi criado em graça.
O primeiro discute–se assim. – Parece que o primeiro homem não foi criado em graça.

1. – Pois, a Escritura, distinguindo Adão de Cristo, diz: Foi feito o primeiro homem Adão em alma
vivente, o último Adão em espírito vivificante. Ora, a vivificação de Cristo vem da graça. Logo, é próprio
de Cristo ter sido feito em graça.

2. Demais. – Agostinho diz, que Adão não leve o Espirito Santo. Ora, quem tem a graça tem o Espírito
Santo. Logo, Adão não foi criado em graça.

3. Demais. – Agostinho diz: Deus ordenou a vida dos anjos e a dos homens de modo que, nela, primeiro
mostrasse o poder do livre arbítrio deles; em seguida, o poder do beneficio da sua graça e o juízo da
justiça. Portanto, primeiro fez o homem e o anjo só com a liberdade do arbítrio natural; e depois
conferiu–lhes a graça.

4. Demais. – O Mestre das Sentenças diz: Ao homem, na criação lhe foi dado auxilio com o qual podia
subsistir, mas não progredir. Ora, quem tem a graça pode progredir, pelo mérito. Logo, o primeiro
homem não foi criado em graça.

5. Demais. – Para receber a graça é necessário o consentimento da parte de quem recebe; pois assim se
consuma um como matrimônio espiritual entre Deus e a alma. Ora, consentimento para a graça não
pode haver senão da parte de quem anteriormente já existia. Logo, o homem não recebeu a graça no
primeiro instante da sua criação.

6. Demais. – Mais dista a natureza, da graça, do que esta, da glória, que não é senão a graça consumada.
Ora, no homem, a graça precedeu à glória. Logo, com muito maior razão, a natureza precedeu a graça.
Mas, em contrário. – O homem e o anjo ordenam–se igualmente para a graça. Ora, este foi criado em
graça, pois, Agostinho diz: Deus estava simultaneamente neles, criando a natureza e distribuindo a
graça. Logo, também o homem foi criado em graça.

SOLUÇÃO. – Alguns dizem que o primeiro homem não foi criado em graça, contudo esta lhe foi depois
conferida antes que pecasse. E na verdade, muitas autoridades dos Santos atestam que o homem, no
estado de inocência, tinha a graça. – Mas, como outros dizem, ele foi criado em graça; e para isto é
necessário admitir a retidão mesma do primeiro estado, na qual Deus fez o homem, conforme a
Escritura: Deus criou o homem reto.
E tal retidão consistia em que a razão era sujeita a Deus; à razão, as virtudes inferiores; e à alma, o
corpo. Ora, a primeira sujeição era a causa da segunda e da terceira. Pois, enquanto a razão permanecia
sujeita a Deus, as virtudes inferiores eram–lhe sujeitas a ela, como diz Agostinho. Ora, é manifesto que
tal sujeição do corpo à alma e a das virtudes inferiores à razão, não era natural, porque do contrário
permaneceriam depois do pecado; pois, nos demônios, os dons naturais permaneceram depois do
pecado como diz Dionísio. Por onde é manifesto, que também aquela primeira sujeição pela qual a
razão se submetia a Deus, não era só natural, mas em virtude do dom natural da graça; pois o efeito não
pode ser superior à causa. Por isso, Agostinho diz: imediatamente depois que transgrediram o preceito,
abandonados da graça divina ficaram confusos com a nudez dos seus corpos; pois, sentiram o
movimento novo da desobediência da carne, como pena reciproca da própria desobediência. Por onde
se da a entender, que se, com o abandono da graça, dissipou–se a obediência da carne em relação à
alma, pela graça, existente na alma é que as virtudes inferiores lhe estavam sujeitas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Com as palavras aduzidas, o Apóstolo quer mostrar que
há um corpo espiritual, se há um corpo animal; pois a vida daquele começou com Cristo, primogênito
dentre os mortos, como a vida deste começou com Adão. Mas nas palavras do Apóstolo não esta que
Adão não tinha alma espiritual, senão que não foi espiritual quanto ao corpo.

RESPOSTA À SEGUNDA. – Como se diz no mesmo passo, não se nega que de algum modo o Espírito
Santo estivesse em Adão, como esta nos outros justos; mas que não estava nele como agora está nos
fiéis, admitidos a entrarem na herança eterna logo depois da morte.

RESPOSTA À TERCEIRA. – Do passo citado de Agostinho não se conclui que o anjo ou o homem fossem
criados com a natural liberdade do arbítrio, antes de terem a graça. Mas mostra primeiro o que neles
podia o livre arbítrio, antes da confirmação; e o que, depois, conseguiram com o auxílio da graça
confirmante.

RESPOSTA À QUARTA. – O Mestre se exprime de acordo com a opinião dos que admitiam que o homem
não foi criado em graça, mas somente com faculdades naturais. – Ou pode–se dizer que, embora o
homem fosse criado em graça, todavia foi–lhe concedido, por criação da natureza, que pudesse
progredir pelo mérito, mas em virtude de graça super–adveniente.

RESPOSTA À QUINTA. – Não sendo contínuo o movimento da vontade, nada impedia que, mesmo no
primeiro instante da sua criação o primeiro homem consentisse na graça.

RESPOSTA À SEXTA. – Merecemos a glória por ato da graça; não porém a graça por ato da natureza. Por
onde, a razão da comparação não e a mesma.

## Art. 2 — Se o primeiro homem tinha paixões da alma.
O segundo discute–se assim. – Parece que o primeiro homem não tinha paixões da alma.

1. – Pois, por tais paixões é que a carne deseja contra o espírito, Ora, isso não se dava no estado de
inocência. Logo, nesse estado não havia paixões da alma.

2. Demais. – A alma de Adão era mais nobre que o corpo. Ora, o seu corpo era impassível. Logo,
também na alma de Adão não havia paixões.

3. Demais. – Pela virtude moral se refreiam as paixões da alma. Ora, em Adão havia virtude moral
perfeita. Logo, dele estavam totalmente excluídas as paixões.
Mas, em contrário, diz Agostinho: havia neles o amor imperturbado de Deus, e algumas outras paixões
da alma.

SOLUÇÃO. – As paixões da alma estão no apetite sensível, cujos objetos são o bem e o mal. Por onde,
dessas paixões, umas se ordenam ao bem, como o amor e a alegria; outras, ao mal, como o temor e a
dor. Ora, no primeiro estado não havia nenhum mal existente nem iminente; nem faltava nenhum bem
dos que a vontade, nesse tempo, quisesse ter, como se vê claramente em Agostinho. Por onde, todas as
paixões, que dizem respeito ao mal, como o temor, a dor e outras, não existiam em Adão;
semelhantemente, nem as que dizem respeito ao bem não alcançado e atualmente desejado, como a
cobiça estuante. Porém, existiam no estado de inocência as paixões referentes ao bem presente, como a
alegria e o amor; ou as referentes a um bem futuro, a obter em tempo devido, como o desejo e a
esperança sem aflições. Mas de modo diferente do pelo que existem em nós. Pois em nós o apetite
sensível, onde se radicam as paixões, não se sujeita totalmente à razão; e por isso as nossas paixões
previnem, umas vezes, e impedem o juízo da razão e, outras vezes, resultam desse juízo quando o
apetite sensível obedece de algum modo à razão. Ao passo que, no estado de inocência, o apetite
inferior, estando totalmente sujeito à razão, não havia nele, das paixões da alma, senão as resultantes
do juízo da mesma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A carne deseja contra o espírito, porque as paixões
repugnam à razão; ora tal não se dava no estado de inocência.

RESPOSTA À SEGUNDA. – O corpo humano no estado de inocência era impassível, quanto às paixões
que removem a disposição natural, como a seguir se dirá. E semelhantemente, a alma era impassível,
quanto às paixões que travam a razão.

RESPOSTA À TERCEIRA. A virtude moral perfeita não elimina totalmente as paixões, mas as ordena;
pois, como diz Aristóteles, é próprio do homem sóbrio desejar como deve e o que deve.

## Art. 3 — Se Adão tinha todas as virtudes.
O terceiro discute–se assim. – Parece que Adão não tinha todas as virtudes.

1. – Pois, certas virtudes visam refreiar a imoderação das paixões; assim, a temperança refreia a
concupiscência imoderada; e a fortaleza, o temor imoderado. Ora, não havia imoderação das paixões no
estado de inocência. Logo, nem as sobreditas virtudes.

2. Demais. – Certas virtudes dizem respeito às más paixões; assim, a mansidão, refreia a ira e a fortaleza,
o temor. Ora, como já se disse, tais paixões não existiam no estado de inocência. Logo, nem as
sobreditas virtudes.

3. Demais. – A penitência é virtude atinente ao pecado anteriormente cometido. De seu lado, a
misericórdia é virtude que diz respeito à miséria. Ora, no estado de inocência não havia pecado nem
miséria. Logo, nem tais virtudes.

4. Demais. – A perseverança é uma virtude. Ora, Adão não a teve, como bem o mostra o pecado
subsequente. Logo, não teve todas as virtudes.

5. Demais. – A fé é uma virtude. Ora, ela não existia no estado de inocência; pois, importa um
conhecimento velado, que repugna à perfeição do primeiro estado.
Mas, em contrário, diz Agostinho: O príncipe dos vícios venceu Adão, feito do limo da terra à imagem de
Deus, armado de pudicícia, formado na temperança, magnífico pelo esplendor.

SOLUÇÃO. – O homem, no estado de inocência, teve, de certo modo, todas as virtudes; o que pode se
tornar manifesto pelo que já ficou dito. Pois, como já se disse antes, era tal a retidão do primeiro
estado, que a razão era submissa a Deus, e as virtudes inferiores, à razão. Ora, estas nada mais são que
certas perfeições, pelas quais a razão se ordena para Deus; e as virtudes inferiores dispõem–se pela
regra da razão, como se verá mais claramente quando se tratar das virtudes. Por onde, a retidão do
primeiro estado exigia que o homem tivesse, de certo modo, todas as virtudes.
Mas devemos considerar que há certas virtudes, como a caridade e a justiça que, por essência, não
importam nenhuma imperfeição. E tais virtudes existiam, no estado de inocência, em si mesmas,
habitual e atualmente.
Há outras virtudes, porém, que, por essência, importam a imperfeição, ou quanto ao ato, ou quanto à
matéria. E se tal imperfeição não repugna à perfeição do primeiro estado, então tais virtudes podiam
existir nesse estado. Assim a fé, referente às coisas que se não vêm; e a esperança, às que não se tem.
Pois, a perfeição do primeiro estado não chegava até à visão de Deus em essência e à posse dele com o
gozo da beatitude final. Por onde, a fé e a esperança podiam existir, no primeiro estado, tanto habitual
como atualmente. Se porém a imperfeição, da essência de uma determinada virtude repugna à
perfeição do primeiro estado, então essa virtude podia nele existir, habitual, mas não atualmente. Como
claramente se vê na penitência, que é a dor pelo pecado cometido; e na misericórdia, que é a dor pela
miséria alheia. Pois, à perfeição do primeiro estado tanto repugna a dor como a culpa e a miséria. Por
onde, tais virtudes existiam, no primeiro homem, habitual mas não atualmente. Pois, era o primeiro
homem de tal modo disposto que, se precedesse o pecado, condoer–se–ia; e, semelhantemente, se
visse a miséria alheia, socorrer–lhe–ia tanto quanto pudesse. E por isso o Filósofo diz: a vergonha, que
se refere a um fato torpe, existe no virtuoso só condicionalmente; pois ele é de tal modo disposto que
haveria de se envergonhar, se cometesse algo de torpe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A temperança e a fortaleza constituem a super
abundância das paixões, só acidentalmente, enquanto encontram paixões super abundantes no sujeito.
Mas por natureza é próprio dessas virtudes, moderar as paixões.

RESPOSTA À SEGUNDA. – Repugnam à perfeição do primeiro estado as paixões ordenadas ao mal, que
dizem respeito a este enquanto existente em quem é afetado pela paixão, como o temor e a dor. Mas as
paixões referentes ao mal, em outrem, não repugnam à perfeição do primeiro estado. Pois nesse estado
o homem podia odiar a malícia dos demônios, bem como amar a bondade de Deus. E por isso as
virtudes referentes a tais paixões podiam existir no sobredito estado, habitual e atualmente. As que são,
porém referentes às paixões, que dizem respeito ao mal no mesmo sujeito, se se referirem só a tais
paixões, não podiam ter existido atualmente no primeiro estado, mas só habitualmente, como já se
disse no tocante à penitência e à misericórdia. Há porém certas virtudes referentes não só a essas, como
às outras paixões; assim, a temperança, referente não só às dores, mas também aos prazeres; e a
fortaleza, referente não só ao temor, como também à audácia e à esperança. Por onde, podia haver, no
primeiro estado, o ato da temperança, enquanto moderador dos prazeres; e, semelhantemente, a
fortaleza, enquanto moderadora da audácia ou da esperança. Não, porém enquanto moderam a tristeza
e o temor.

RESPOSTA À TERCEIRA. – Deduz–se clara a resposta, do que foi dito.

RESPOSTA À QUARTA. – Em dupla acepção se entende a perseverança. – Como virtude e exprimindo
um hábito, pelo qual alguém elege o perseverar no bem; nesse sentido Adão teve a perseverança. – Ou,
noutra acepção, como circunstância da virtude, e exprimindo uma certa continuação da virtude, sem
corrupção; e nesse, Adão não a teve.

RESPOSTA À QUINTA. – Deduz–se clara a resposta, daquilo que acaba de ser dito.

## Art. 4 — Se as obras do primeiro homem eram menos eficazes para merecer, que as nossas.
O quarto discute–se assim. – Parece que as obras do primeiro homem eram menos eficazes para
merecer, que as nossas.

1. – Pois, a graça é dada pela misericórdia de Deus, que mais socorre aos mais indigentes. Ora, nós
precisamos mais da graça, do que o primeiro homem, no estado de inocência. Logo, ela nos é infundida
mais copiosamente; e, sendo ela a raiz do mérito, as nossas obras tornam–se mais eficazes para
merecer.

2. Demais. – O mérito supõe necessariamente a luta e a dificuldade, conforme a Escritura : Não é
coroado senão depois que combateu conforme a Lei. E o Filósofo diz: a virtude implica o bem difícil. Ora,
na vida presente maior é a luta e a dificuldade. Logo, também maior é a eficácia para merecer.

3. Demais. – O Mestre das Sentenças diz: o homem, então não mereceria, resistindo à tentação; agora,
porém merece quem a ela resiste. Logo, mais eficazes são as nossas obras para merecer, do que no
estado primitivo..
Mas, em contrário, neste caso, o homem estaria em melhor condição, depois do pecado.

SOLUÇÃO. – O grau do mérito pode ser avaliado de dois modos. – Primeiro, pelo radicar–se na caridade
e na graça. E tal grau corresponde ao prémio essencial, consistente na fruição de Deus; assim, quem
proceder com maior caridade mais perfeitamente gozará de Deus. – De outro modo, pode–se avaliar o
grau do mérito pelo grau da obra. E este é duplo: absoluto e proporcional. Assim a viúva, que colocou
duas pequenas moedas no gazofilácio, fez obra menor, absolutamente falando que aqueles que fizeram
grandes dádivas; mas, pela quantidade proporcional, fez mais, conforme o julgamento do Senhor,
porque a sua dádiva, ia mais além das suas posses. Um e outro grau do mérito porém corresponde ao
prêmio acidental, que é o gozo do bem criado.
Portanto devemos concluir que as obras do homem eram mais eficazes para merecer, no estado de
inocência, do que depois do pecado, se se atender ao grau do mérito, relativamente à graça, mais
copiosa então, por não encontrar nenhum obstáculo da parte da natureza humana. Semelhantemente,
se se considerar o grau absoluto da obra; pois, como o homem tinha maior virtude suas obras eram
mais meritórias. Mas se se considerar a quantidade proporcional, maior é o grau do mérito depois do
pecado, por causa da fraqueza do homem; pois, uma obra de pequena monta excede mais o poder
daquele, que a faz com dificuldade, do que uma obra de grande valia, o poder de quem a faz sem
dificuldade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O homem, depois do pecado, precisa da graça para maior
número de obras do que antes dele, mas não de mais graças. Pois, antes do pecado precisava da graça,
e era essa a necessidade principal dela, para alcançar a vida eterna. Mas depois, precisa da graça
também para remissão do pecado e sustentáculo da fraqueza.

RESPOSTA À SEGUNDA. – A dificuldade e a luta respeitam ao grau do mérito, quanto à quantidade
proporcional da obra, conforme já se disse. E é sinal da presteza da vontade, que se esforça por alcançar
aquilo que lhe é difícil. Ora, essa presteza é causada pela magnitude da caridade. Assim, pode dar–se
que faça um qualquer obra fácil, com vontade tão pronta, como outro, uma difícil; porque está
preparado para fazer também o que lhe fosse difícil. Porém a dificuldade atual, como pena, acarreta
também o ser satisfatória pelo pecado.

RESPOSTA À TERCEIRA. – Resistir à tentação não era meritório, para o primeiro homem, na opinião dos
que dizem que ele não tinha a graça; assim como, ainda agora, não o é para quem não a tem. Mas há
diferença no seguinte, que, no primeiro estado, nada, interiormente, impelia ao mal, como agora. Por
onde, então, o homem podia resistir á tentação, sem a graça, mais que agora.