# Questão 24: Do Livro da Vida
Devemos em seguida tratar do livro da vida. E sobre este assunto discutem-se três artigos:

## Art. 1 — Se o livro da vida é o mesmo que a predestinação.
(I Sent., dist. XL, q. 1, a. 2, ad 5; III, dist. XXXI, q. 1, a. 2, q. 2; De Verit., q. 7, a. 1, 4; ad Philipp., cap. IV,
lect. I; ad Hebr., cap. XII; lect. IV).
O primeiro discute-se assim. — Parece que o livro da vida não é o mesmo que a predestinação.

1. — Pois, diz a Escritura (Eclli 24, 32): Tudo isto é o livro da vida; e a Glosa: Isto é, o Novo e o Velho
Testamento. Ora, isto não é a predestinação. Logo, o livro da vida não é o mesmo que a predestinação.

2. Demais. — Agostinho diz que o livro da vida é uma certa virtude divina, por força da qual cada um
conserva na memória as suas boas ou más obras. Ora, a virtude divina não pertence à predestinação,
mas, antes, ao atributo do poder. Logo, o livro da vida não é o mesmo que a predestinação.

3. Demais. — A predestinação se opõe a reprovação. Por onde, se o livro da vida fosse a predestinação,
também haveria um livro da morte.
Mas, em contrário, àquilo da Escritura (Sl 68, 29): sejam riscados do livro dos viventes — diz a Glo-
sa: Este livro é o conhecimento de Deus, pelo qual predestinou à vida os que previu.

SOLUÇÃO. — Em relação a Deus falamos metaforicamente de livro da vida, por semelhança com as
coisas humanas. Pois é costume dos homens inscrever num livro os eleitos a algum cargo, como os
soldados, os conselheiros, que antigamente se chamavam Padres Conscritos. Ora, é claro, pelo que já
dissemos, que todos os predestinados são eleitos por Deus à vida eterna. Por onde, a inscrição dos
predestinados se chama livro da vida.
Dizemos, porém, metaforicamente, que está inscrito no intelecto o que alguém conserva com segurança
na memória, conforme a Escritura (Pr 3, 1): Não te esqueças da minha lei e guarde o teu coração os
meus preceitos; e logo em seguida: Grava-as sobre as tábuas do teu coração. Pois inscrevemos nos livros
materiais para socorrer a memória. Por isso, chamamos livro da vida à ciência mesma de Deus, pela qual
se lembra com segurança dos predestinados à vida eterna. Pois, assim como a escritura de um livro
indica as coisas que devemos fazer, assim a ciência de Deus lhe significa os que devem ser levados à vida
eterna, segundo aquilo da Escritura (2 Ti 2, 19): Porém, o fundamento de Deus está firme, o qual tem
este selo: o Senhor conhece os que são dele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De dois modos podemos conceber o livro da vida. De
um, significa a inscrição dos eleitos à vida; e é nesse sentido que agora tratamos de tal livro. De outro
modo, significa as coisas que levam à vida. E isto de duas maneiras. Ou das coisas a serem feitas, e,
assim, o Novo e o Velho Testamento se chamam livro da vida. Ou das já feitas, e assim livro da vida se
chama aquela virtude divina pela qual cada um conserva na memória os próprios feitos. Como também
livro da milícia pode chamar-se o livro onde se inscrevem os escolhidos para a milícia; ou onde se ensina
a arte militar, ou onde se narram feitos militares.
Donde se deduz clara a RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — Não se costumam inscrever os rejeitados, mas os escolhidos. Por isso, não
corresponde à reprovação um livro da morte, como à predestinação, o da vida.

RESPOSTA À QUARTA. — Racionalmente, difere da predestinação o livro da vida; pois, implica o
conhecimento daquela, como resulta da Glosa citada.

## Art. 2 — Se o livro da vida só concerne à vida gloriosa dos predestinados.
(III Sent., dist. XXXI, q. 1, a. 2, qª 2; De Verit., q. 7, a. 5, 6, 7).
O segundo discute-se assim. — Parece que o livro da vida não concerne somente à vida gloriosa dos
predestinados.

1. — Pois, o livro da vida é o conhecimento desta. Ora, Deus conhece pela sua, todas as outras vidas.
Logo, o livro da vida concerne precipuamente à vida divina e não só à dos predestinados.

2. Demais. — Assim como a da glória, também a vida da natureza vem de Deus. Se, pois, o
conhecimento daquela se chama livro da vida, também o desta há de assim chamar-se.

3. Demais. — Alguns são eleitos para a graça, que não o são para a vida da glória, como está claro na
Escritura (Jo 6, 71): Não é assim que eu vos escolhi em número de doze? E contudo um de vós é o diabo.
Ora, o livro da vida é a inscrição da eleição divina, como foi dito. Logo, também concerne à vida da
graça.
Mas, em contrário, o livro da vida é o conhecimento da predestinação, como se disse. Ora, a
predestinação só concerne à vida da graça, enquanto ordenada para a glória; pois não são
predestinados os que, tendo a graça, ficam privados da glória. Logo, o livro da vida não concerne senão
à glória.

SOLUÇÃO. — Como dissemos, o livro da vida supõe a inscrição ou conhecimento dos eleitos à vida. Ora,
alguém só é eleito para o que não lhe cabe por natureza. E além disso, aquilo para o que alguém é eleito
desempenha o papel de causa final. Assim o soldado não é escolhido ou inscrito para que se arme, mas
para lutar, que é o fim próprio da milícia. Ora, o fim sobrenatural é a vida da glória, como dissemos.
Logo, propriamente, é a esta que o livro da vida concerne.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vida divina, mesmo como gloriosa, é natural a Deus.
Por onde, em relação a ela não há eleição nem por conseqüência livro da vida. Pois, não dizemos que
um homem é eleito para ter sentidos, ou para qualquer atributo resultante da natureza.
Donde se deduz clara aRESPOSTA À SEGUNDA OBJEÇÃO. — Em relação à vida natural, não há eleição
nem livro da vida.

RESPOSTA À TERCEIRA. — A vida da graça não tem natureza de fim, mas de meio. Por onde, não
dizemos de ninguém, que para ela seja eleito, senão enquanto ordenada para a glória. E por isso não se
consideram eleitos, absolutamente falando, mas sim, relativamente, os que, tendo a graça, não
alcançam a glória. Semelhantemente, só relativa, e não absolutamente, é que se consideram inscritos
no livro da vida. Enquanto deles está determinado, na ordenação e na ciência divina, que hão de
alcançar uma certa ordem para a vida eterna, conforme a participação da graça.

## Art. 3 — Se alguém é riscado do livro da vida.
(I Sent., dist. XL, q. 1. a. 2, ad 5; q. 3, ad 3; III, dist. XXXI, q. 1, a. 2, qª 2; Ad Phílipp., cap. IV. lect. 1).
O terceiro discute-se assim. — Parece que ninguém é riscado do livro da vida.

1. — Pois, diz Agostinho: O livro da vida é a presciência de Deus, que não pode enganar-se. Ora,
ninguém pode escapar à presciência de Deus, nem à predestinação. Logo, ninguém, pode ser riscado do
livro da vida.

2. Demais. — Tudo o que existe num sujeito, existe ao modo deste. Ora, o livro da vida é algo de eterno
e imutável. Logo, tudo o que nele existe há de existir, não temporal, mas imóvel e indelevelmente.

3. Demais. — Ser riscado opõe-se a ser inscrito. Ora, ninguém pode ser de novo inscrito no livro da vida.
Logo, nem do mesmo, riscado.
Mas, em contrário, a Escritura (Sl 68, 29): Sejam riscados do livro dos viventes.

SOLUÇÃO. — No pensar de alguns, ninguém pode ser verdadeiramente riscado do livro da vida, mas
somente, na opinião dos homens. Pois, é habitual a Escritura dizer, que uma coisa é feita quando é
conhecida. E assim são considerados inscritos no livro da vida os de que os homens assim opinam, por
causa da justiça presente, que neles descobrem. Mas então dele consideram-se riscados quando se sabe
que, neste ou no futuro século, decaíram dessa justiça. E a Glosa também assim explica o sentido do
salmo: — Sejam riscados do livro dos viventes.
Mas, entre os prêmios dos justos, está não serem riscados do livro da vida, segundo àquilo da Escritura
(Ap 3, 5): Aquele que vencer será assim vestido de vestiduras brancas e eu não apagarei o seu nome do
livro da vida. Ora, o prometido aos santos não o é só na opinião dos homens. Por onde, podemos dizer
que não só à essa opinião, mas ainda à realidade se refere o ser ou não riscado do livro da vida. Pois,
esse livro é a inscrição dos que são ordenados à vida eterna, à qual alguém é ordenado por duas causas:
por predestinação divina, que nunca falha, e pela graça. Pois quem tem a graça por isso mesmo é digno
da vida eterna; todavia esta ordenação, às vezes, falha, porque alguns eram ordenados, pela graça
recebida, a alcançar a vida eterna, e, contudo, a perderam, pelo pecado mortal. Por onde, os ordenados
pela predestinação divina a alcançar a vida eterna estão, absolutamente falando, inscritos no livro da
vida; porque nele estão inscritos como havendo de alcançá-la, em si mesma; e esses não serão nunca
dele riscados. Dizemos, porém, que estão inscritos no livro da vida, não absoluta, mas relativamente, os
ordenados a alcançar a vida eterna, não por predestinação divina, mas só pela graça. Porque nele estão
inscritos como havendo de alcançar a vida eterna em sua causa e não, em si mesma. E esses podem ser
dele riscados, sem que isto se refira ao conhecimento de Deus, que ignoraria o que previu, mas à coisa
conhecida, sabendo então Deus que, embora anteriormente ordenado à vida eterna, o que perdeu a
graça já não o é.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ser riscado não se refere, como dissemos, ao livro da
vida, relativamente à presciência, como se em Deus houvesse mudança; mas, relativamente às coisas
previstas, que são mutáveis.

RESPOSTA À SEGUNDA. — Embora as coisas sejam, em Deus, imutáveis, contudo em si mesmas, são
mutáveis. E a esta situação é que se refere o ser riscado do livro da vida.

RESPOSTA À TERCEIRA. — Do modo por que dizemos que alguém é riscado do livro da vida, podemos
também dizer que é nele inscrito de novo. Quer quanto à opinião dos homens, ou porque de novo
começa, pela graça, a ordenar-se para a vida eterna. O que também está compreendido no
conhecimento divino, embora não de novo.