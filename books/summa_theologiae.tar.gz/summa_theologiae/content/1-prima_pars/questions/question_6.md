# Questão 6: Da bondade de Deus.
Em seguida devemos tratar da bondade de Deus. E, nesta questão, discutem-se quatro artigos:

## Art. 1 — Se ser bom convém a Deus.
(I Cont. Gent., cap. XXXVII; XII Metaphys., lect. VII)
O primeiro discute-se assim. — Parece que ser bom não convém a Deus.

1. — Pois a noção de bem implica a de modo, espécie e ordem. Ora, sendo Deus imenso e não ordenado
a nenhum outro ser, estas noções não lhe convém. Logo, também, não lhe convém o ser bom.

2. Demais. — Bem é o que todos os seres desejam, ora, como nem todos o conhecem, nem todos o
desejam, porque não se deseja o que não se conhece. Logo, ser bom não convém a Deus.
Mas, em contrário, diz a Escritura (Lm 3, 25): Bom é o Senhor para os que nele esperam, para a alma que
o busca.

SOLUÇÃO. — Ser bom convém a Deus de modo excelente. Pois uma coisa é boa na medida em que é
desejável. Por outro lado, todo ser deseja a perfeição própria; e a perfeição e a forma do efeito é uma
certa semelhança do agente, porque todo agente produz um ato que lhe é semelhante. Por onde, o
agente, em si mesmo, é desejável e assume o caráter de bem; pois dele é desejada a participação, por
semelhança. Ora, como Deus é a causa eficiente primeira de todos os seres, é claro que lhe convém a
característica de bom e desejável. E, por isso, Dionísio atribui o bem a Deus, como causa eficiente
primeira, dizendo que Deus é chamado bom como sendo o princípio porque todas as coisas subsistem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO — Ter modo, espécie, e ordem pertence à natureza do bem
criado. Ora, o bem existe em Deus, como na sua causa. Logo, pertence a Deus impor aos outros o modo,
a espécie e a ordem, que nele existem como na causa.

RESPOSTA À SEGUNDA. — Todos os seres, desejando as próprias perfeições, desejam a Deus mesmo,
por serem elas umas semelhanças do ser divino, conforme resulta claro do que já dissemos. E assim, das
criaturas que desejam a Deus, umas — as racionais — o conhecem em si mesmo; outras, porém,
conhecem certas participações de sua bondade de que também é susceptível o conhecimento sensível;
outras, por fim, têm um apetite natural, sem conhecimento, inclinadas que são para seus fins por um ser
superior dotado de conhecimento.

## Art. 2 — Se Deus é o sumo bem.
(II Sent., dist. I, q.2, a.2, ad. 4; I Cont. Gent. Cap. XLI)
O segundo discute-se assim. — Parece que Deus não é o sumo bem.

1. — Pois o sumo bem diz algo mais que bem; do contrário, conviria a qualquer bem. Ora, tudo o que é
constituído por adição é composto. Logo, o sumo bem o é. Mas, sendo Deus sumamente simples, como
já se demonstrou, não é o sumo bem.

2. Demais. — O bem é o que todos os seres desejam, como diz o Filósofo. Ora, além de Deus, fim de
todos os seres, nada mais há que todos desejem. Logo, não há outro bem além de Deus; o que também
se vê na Escritura (Lc 18, 19): Ninguém é bom senão só Deus. Ora, sumo implica comparação com
outros: assim, o sumo cálido supõe comparação com tudo o que é cálido. Logo, Deus não pode ser
considerado sumo bem.

3. Demais. — sumo importa comparação. Ora, não se comparam coisas que não são do mesmo gênero;
assim, inconvenientemente seria dizer que a doçura é maior ou menos que a linha. Ora, Deus, não
sendo do mesmo gênero que os outro bens, como resulta claro do sobredito, conclui-se que não pode
ser considerado, em relação a eles, o sumo bem.
Mas, em contrario, diz Agostinho que a Trindade das divinas Pessoas é o sumo bem, que sabem
discernir as almas inteiramente puras.

SOLUÇÃO. — Deus é o sumo bem, absolutamente, e não só num determinado gênero ou ordem de
coisas. Assim, o bem é atribuído a Deus, conforme já se disse, enquanto todas as perfeições desejadas
dele efluem, como de causa. Não efluem dele, porém, como de agente unívoco, segundo do sobredito
claramente resulta. Mas, como de agente, que não tem de comum com os seus efeitos nem a espécie
nem o gênero. Ora, a semelhança do efeito que se encontra, na causa unívoca, de maneira uniforme,
encontra-se na causa equivoca, de maneira mais excelente; assim, o calor existe de modo mais
excelente no sol, que no fogo. Por onde, existindo o bem em Deus, como na causa primeira, não unívoca
de todos os seres, nele necessariamente existe de modo excelentíssimo. E, por isso, é chamado sumo
bem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O sumo bem não acrescenta ao bem nenhuma realidade
absoluta mas, somente, uma relação. A relação, porém, em virtude da qual alguma coisa se diz de Deus,
relativamente às criaturas, só nestas existe realmente e não, nele, em quem existe só racionalmente;
assim, um objeto é considerado cognoscível relativamente à ciência, não porque se refira a esta, mas
porque esta se lhe refere a ele. E assim, de nenhum modo, há qualquer composição no sumo bem, mas
os outros seres é que lhe são inferiores em bondade.

RESPOSTA À SEGUNDA. — O dito — o bem é o que todos os seres desejam — não significa que cada
bem seja desejado por todos, mas, que tudo o que é desejado tem o caráter de bem. E o dito —
ninguém é bom senão só Deus — se entende do bem por essência, como a seguir se dirá.

RESPOSTA À TERCEIRA. — Coisas que não pertencem a um mesmo gênero não podem ser comparadas,
desde que estão contidas em gêneros diversos. Ora, negamos que Deus seja do mesmo gênero que os
outros bens, não por pertencer a algum outro gênero, mas por estar fora de todos os gêneros e ser o
princípio de todos. De modo que é comparável a tudo o mais, por excelência; relação essa expressa pela
qualidade de sumo bem.

## Art. 3 — Se é próprio de Deus ser bom por essência.
(I Cont. Gent., cap. XXXVIII; III, cap. XX; De Verit., q. 21, a. 1, ad 1; a. 5; Compend. Theol., cap. CIX; De Div.
Nom., cap. IV, lect. I; In Boet., De Hebdomad., Lect. III, IV)
O terceiro discute-se assim. — Parece que não é próprio de Deus ser bom por essência.

1. — Pois também como a unidade, o bem se converte no ser, conforme já se disse. Ora, todo ser é
essencialmente um, segundo claramente se vê no Filósofo. Logo, todo ser é bom por essência.

2. Demais. — Se o bem é o que todos os seres desejam, como todas as coisas desejam a existência, a
existência de cada uma delas é-lhe o bem próprio. Ora, cada coisa existe pela sua essência. Logo,
também será boa por essa mesma essência.

3. Demais. — Cada coisa é boa pela sua bondade; se pois, alguma há que não seja boa pela sua essência,
a essência não lhe há-de necessariamente ser a bondade. Logo, sendo a bondade ente, é necessário que
seja boa; mas, se outra por bondade o for, ressurge a questão. Ora, ou se há-de proceder ao infinito, ou
se há-de chegar a alguma bondade que não seja boa por outra. Logo, pela mesma razão, devia-se ficar
no primeiro termo, sendo, então, cada coisa boa pela sua própria essência.
Mas, em contrario, diz Boécio que todos os seres, menos Deus, são bons por participação e, portanto,
não por essência.

SOLUÇÃO. — Só Deus é bom pela sua essência. Pois dizemos que um ser é bom enquanto perfeito, e
uma coisa pode ter perfeição de três modos. A primeira a constitui na sua existência; pela segunda,
alguns acidentes se lhe acrescentam, necessários à sua perfeita operação; pela terceira atinge uma
outra coisa, como fim. Assim, a primeira perfeição de fogo consiste na sua existência, que lhe advém da
forma substancial; a segunda, na calidez, leveza, secura e acidentes semelhantes; a terceira perfeição
em repousar no seu lugar. Ora, esta tríplice perfeição a nenhum ser é própria, por essência, senão só a
Deus, de quem só a essência é a existência, e a quem nenhum acidente advém; e o que dos mais seres
se diz acidentalmente, a ele lhe convém essencialmente, como, ser poderoso, sábio e atribuições
semelhantes, conforme do sobredito claramente resulta; e assim, também ele a nenhum outro ser se
ordena como ao fim, antes é o fim último de todas as coisas. Por onde, é manifesto que só Deus tem,
por essência, omnímoda perfeição. Logo, só ele é bom por essência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A unidade não implica a noção de perfeição mas, só a de
indivisibilidade, que convém a cada coisa em conformidade com a sua essência. Quanto às essências dos
seres simples, elas são indivisas, atual e potencialmente; as dos compostos, porém, só atualmente.
Logo, é forçoso que cada coisa seja uma por essência, mas não boa, desse mesmo modo, como se
demonstrou.

RESPOSTA À SEGUNDA. — Embora uma coisa seja boa na medida em que tem a existência, contudo, a
essência da criatura não se lhe identifica com a existência. Logo, não se conclui que uma coisa criada
seja boa pela sua essência.

RESPOSTA À TERCEIRA. — A bondade da criatura não é a essência da mesma, mas, algo de
acrescentado que consiste, quer, na sua existência, quer em alguma perfeição sobreveniente, ou na sua
ordem para um fim. Porém essa mesma bondade acrescentada chama-se boa, do mesmo modo por que
se chama ser. Ora, é considerada ser pela razão de, por ela, alguma coisa existir e não, por existir ela, em
virtude de outra coisa. Logo, será considerada boa porque, por ela, alguma coisa é boa e não por ter
alguma outra bondade que a torne tal.

## Art. 4 — Se todas as coisas são boas pela bondade divina.
(I Sent., dist. XIX, q. 5, a. 2, ad 3; I Cont. Gent., cap. XL; De Verit., q. 21, a. 4)
O quarto discute-se assim. — Parece que todas as coisas são boas pela bondade divina.

1. — Pois, diz Agostinho: Considera tal bem e tal outro; elimina isto e aquilo e contempla o bem em si
mesmo, se puderes; então, verás Deus, bem que não o é por outro, mas, bem de todos os bens. Logo, as
coisas são boas pelo bem mesmo, que é Deus.

2. Demais. — Como diz Boécio, todas as coisas se consideram boas enquanto ordenadas a Deus, e isto
em razão da bondade divina. Logo, todas são boas em razão desta bondade.
Mas, em contrario, todas as coisas são boas enquanto existem. Ora, dizemos que existem, não pelo ser
divino, mas, pelo próprio. Logo, todas são boas, não pela bondade divina, mas pela própria.

SOLUÇÃO. — Nada impede, que aquilo que implica relação seja denominado como do exterior; assim, o
que está colocado num lugar é por este denominado, e o que é medido é designado pela sua medida.
Variaram, porém, as opiniões, quanto ao que recebe denominação absoluta. — Assim, Platão admitia
espécies separadas de todas as coisas, e que os indivíduos recebem a sua denominação, quase
participando dessas espécies; p. ex., dizemos que Sócrates é homem, por participar da idéia separada de
homem, e assim como admitia serem separadas as idéias de homem e de cavalo, a que chamava
homem em si, e cavalo em si, assim também considerava separadas as idéias de ser e de unidade, a que
chamava ser em si e unidade em si, pela participação das quais cada ser é ente e uno. Porém, ensinava
que o ente em si, e a unidade em si, constituem o sumo bem, e como o bem e a unidade no ser se
convertem, dizia que o bem em si mesmo é Deus, por cuja participação todas as coisas são chamadas
boas. — E embora tenhamos por irracional esta opinião, como também Aristóteles abundantemente o
prova, por ensinar que as espécies separadas das coisas naturais são subsistentes por si mesmas,
contudo é absolutamente verdadeiro, que há uma realidade primeira que é, por essência, ser e bondade
e é chamada Deus, conforme de sobredito resulta. E com este modo de ver também Aristóteles
concorda. — Ora, é participando dessa realidade, primaria e essencialmente ser e bondade, por uma
certa forma de assimilação, embora remonta e deficiente, que as coisas podem ser consideradas seres e
boas, como do sobredito se conclui. — Assim, pois, cada ser é bom pela divina bondade, princípio
primeiro exemplar, efetivo e final de toda bondade. Contudo, cada realidade é considerada boa também
por uma semelhança da divina bondade, que lhe é inerente, que é a sua forma própria e o fundamento
essencial das suas denominações. De modo que há uma só bondade, em virtude da qual todas as coisas
são boas; e, por outro lado, há muitas bondades. Donde se deduzem claras as RESPOSTAS ÀS

OBJEÇÕES.