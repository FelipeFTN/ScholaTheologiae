# Questão 25: Da Potência divina.
Depois de termos tratado da ciência e da vontade divinas, e do que lhes concerne, resta-nos tratar da
potência divina.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se Deus tem potência.
(I Sent., dist. XLII, q. 1, a. 1; I Cont. Gent., cap. XVI; II. cap. II: De Pot., q. 1, a. 1; q. 7, a. 1).
O primeiro discute-e assim. — Parece que Deus não tem potência.

1. — Pois, a matéria prima está para a potência, como Deus, agente primeiro, para o ato. Ora, nenhum
ato há na matéria prima, em si mesma considerada. Logo, nenhuma potência tem Deus, agente
primeiro.

2. Demais. — Segundo o Filósofo, melhor que a potência é o seu ato, pois é melhor a forma que a
matéria, e a ação que a potência ativa, da qual é o fim. Ora, nada é melhor do que o existente em Deus,
por ser divino tudo o que em Deus existe, como se demonstrou. Logo, nenhuma potência há em Deus.

3. Demais. — A potência é principio de operação. Ora, como em Deus não há acidente, a operação
divina é a sua essência. Mas, esta não tem nenhum princípio. Logo, a idéia de potência não convém a
Deus.

4. Demais. — Como ficou demonstrado, a ciência e a vontade divinas são a causa das coisas. Ora, causa
e princípio se identificam. Logo, não se pode atribuir a Deus potência, mas somente ciência e vontade.
Mas, em contrário, a Escritura (Sl 88, 9): Poderoso és, Senhor, e a tua vontade está sempre em roda de
ti.

SOLUÇÃO. — Há duas espécies de potência — a passiva, que de nenhum modo existe em Deus; e a
ativa, que lhe devemos atribuir, soberanamente. Pois, como é manifesto, um ser é principio ativo de um
efeito, na medida em que é atual e perfeito; e recebe uma ação, na medida em que é deficiente e
imperfeito. Ora, como demonstramos, Deus é ato puro, absoluta e universalmente perfeito, não
deixando lugar a nenhuma imperfeição. Por isso, soberanamente lhe convém ser princípio ativo, mas de
nenhum modo, passivo. Pois, a natureza de princípio ativo convém à potência ativa, por ser esta
princípio de ação transitiva. A potência passiva, pelo contrário, é princípio de sofrer a ação exterior,
como diz o Filósofo. Donde se conclui, que Deus tem soberanamente a potência ativa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A potência ativa não se divide do ato, por oposição, mas
nele se funda; pois um ser age na medida em que é atual. Ao contrário, a potência passiva se divide do
ato, por oposição; pois, um ser sofre na medida em que é potencial. Por onde, esta é a potência excluída
de Deus, e não, a ativa.

RESPOSTA À SEGUNDA. — Sempre que o ato difere da potência, necessariamente aquele é que é mais
nobre que esta. Ora, a ação de Deus não difere da sua potência, pois tanto esta como aquela lhe
pertencem à essência, porque o seu ser não difere da sua essência. Por onde, nenhuma necessidade há
de existir nada mais nobre que a potência de Deus.

RESPOSTA À TERCEIRA. — A potência, nas criaturas, não só é princípio de ação, mas também de efeito.
Assim, pois, em Deus se verifica a noção de potência, como princípio do efeito, mas não como princípio
de ação, a qual é a divina essência. Salvo conforme o modo de o entendermos. Assim, enquanto a
essência divina encerra, exemplarmente, tudo o que há de perfeição nas criaturas, podemos concebê-la
como dotada de ação e de potência, como também a concebemos sob a noção de suposto, que tem
natureza, e sob a de natureza.

RESPOSTA À QUARTA. — Não concebemos a potência, em Deus, como diferente da ciência e da
vontade divinas realmente, mas só racionalmente. Isto é, enquanto potência implica a idéia de princípio
executor do que é mandado pela vontade, dirigida pela ciência, três coisas que existem em Deus
identificadas. — Ou devemos dizer que a ciência mesmo ou a vontade divina, enquanto princípios
efetivos, têm natureza de potência. Por onde, a consideração da ciência e da vontade precede, em Deus,
à da potência, como a causa precede à obra e ao efeito.

## Art. 2 — Se a potência de Deus é infinita.
(I Sent., dist. XLIII, q. I, a. 1; I Cont. Gent., cap. XLIII: De Pot., q. 1, a. 2: Compend. Theol., cap. XIX; VIII
Physic., lect. XXIII: XII Metaph., lect. VIII).
O segundo discute-se assim. — Parece que a potência de Deus não é infinita.

1. — Pois, todo infinito é imperfeito, segundo o Filósofo. Ora, a potência de Deus não é imperfeita. Logo,
não é infinita.

2. Demais. — Para não ser frustrada, toda potência há de manifestar-se pelo efeito. Ora, se a potência
de Deus fosse infinita, poderia causar um efeito infinito. O que é impossível.

3. Demais. — O Filósofo prova, que se a potência de um corpo fosse infinita, moveria instantaneamente.
Ora, Deus não move instantaneamente, mas, no tempo, a criatura espiritual; e no espaço e no tempo, a
corpórea, segundo Agostinho. Logo, a sua potência não é infinita.
Mas, em contrário, Hilário diz que Deus tem imenso poder, é vivo e poderoso. Ora, o imenso é infinito.
Logo, o poder divino é infinito.

SOLUÇÃO. — Como já dissemos, a potência ativa existe em Deus enquanto ele é um ser em ato. Ora, o
seu ser, não sendo limitado por nada de receptivo, é infinito, como ficou claro pelo que dissemos,
quando tratamos da infinidade da essência divina. Por onde, necessariamente, a potência ativa de Deus
é infinita. Ora, verifica-se que, quanto mais perfeita é a forma pela qual um agente obra, tanto maior é a
sua potência de agir. Assim, quanto mais quente for um corpo, tanto maior será a sua potência de
aquecer; e tê-la-ia mesmo infinita se o seu calor fosse infinito. Por onde, a essência divina, em si mesma,
pela qual Deus age, sendo infinita, como demonstramos, infinita lhe há de ser a potência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo se refere ao infinito da matéria não
determinada pela forma, infinito esse que convém à quantidade. Ora, não é assim infinita a divina
essência, como demonstramose, por conseqüência, nem a sua potência. Donde não se segue que seja
imperfeita.

RESPOSTA À SEGUNDA. — A potência de um agente unívoco se manifesta inteira no seu efeito; assim, a
potência geratriz do homem só pode gerar outro homem. Mas a potência do agente não unívoco não se
manifesta inteira na produção do seu efeito; assim, a potência solar, não se manifesta inteira na geração
de um animal nascido da putrefação. Ora, manifestamente, Deus não é um agente unívoco; pois, como
demonstramos, nada pode com ele convir, nem em espécie nem em gênero. Portanto, o seu efeito
sempre será menor que a sua potência. Logo, não é necessário esta se manifeste infinita, pela produção
de um efeito infinito. Mas ainda, nem se frustraria a potência de Deus, se nenhum efeito produzisse.
Pois, frustrado fica o que não atinge o fim para que se ordena. Ora, a potência de Deus não se ordena a
nenhum efeito, como ao fim; antes, é o fim do seu efeito.

RESPOSTA À TERCEIRA. — O Filósofo prova que, se um corpo tivesse potência infinita moveria
instantaneamente. E, contudo, demonstra que a potência do motor do céu é infinita porque pode
mover em tempo infinito. Donde se conclui, segundo o seu pensamento, que se existisse, a potência
infinita de um corpo moveria instantaneamente; não, porém, a potência de um motor incorpóreo. E a
razão é que o corpo motor de outro é um agente unívoco, e, por isso, toda a potência do agente se
manifesta no movimento. Ora, sendo tanto maior a potência do corpo motor, quanto mais velozmente
move, por força, sendo infinita, moverá improporcionalmente mais rápido, o que é mover num instante.
Mas o motor incorpóreo é um agente não unívoco. Por onde, não é necessário se manifeste toda a sua
virtude no movimento, de modo que mova num instante. E, sobretudo, porque move segundo a
disposição da sua vontade.

## Art. 3 — Se Deus é onipotente.
(IIIª, q. 13, a. 1; I Sent., dist. XLII, q. 2, a. 2; III, dist. I, q. 2, a. 3; II Cont. Gent., cap. XXII, XXV; De Pot., q. 1,
a. 7; q. 5, a. 3; Quodl., III, q. 1, a. 1; V, q. 2, a. 1; XII, q. 2, a. 1; VI Ethic., lect. II).
O terceiro discute-se assim. — Parece que Deus não é onipotente.

1. — Pois, todas as coisas podem ser movidas e sofrer uma ação. Ora, Deus, sendo imóvel, como vimos,
não o pode. Logo, não é onipotente.

2. Demais. — Pecar é praticar um ato. Ora, Deus não pode pecar nem se negar a si mesmo, como diz a
Escritura (2 Ti 2, 13). Logo, não é onipotente.

3. Demais. — Diz-se que Deus manifesta a sua onipotência, sobretudo perdoando e comiserando-se.
Logo, o máximo que pode a divina potência é perdoar e comiserar-se. Ora, muito mais que perdoar e
comiserar-se é criar outro mundo ou causa semelhante. Logo, Deus não é onipotente.

4. Demais. — Àquilo da Escritura (1 Cor 1, 20): — Deus convenceu de estultícia a sabedoria deste
mundo — diz a Glosa: Deus convenceu de estultícia a sabedoria deste mundo mostrando ser possível o
que ela julgava impossível. Por onde, não devemos julgar nada possível ou impossível, pelas causas
inferiores, como o faz a sabedoria deste mundo, senão pelo poder divino. Logo, se Deus é onipotente
tudo lhe é possível, e nada impossível. Mas, eliminando o impossível, eliminado fica o necessário; pois é
impossível não existir o que existe necessàriamente. Logo, nada será necessário se Deus for onipotente;
e, portanto, Deus não é onipotente.
Mas, em contrário, diz o Evangelho (Lc 1, 37): Porque a Deus nada é impossível.

SOLUÇÃO. — Todos, em geral, confessam que Deus é onipotente, mas é difícil mostrar a razão dessa
onipotência. Pois, pode ser dúbio o sentido dessa atribuição: Deus pode tudo. — Mas, quem considerar
retamente compreenderá que, referindo-se a potência ao possível, o dizer-se que Deus pode tudo não
significa senão que pode tudo o que for possível e, por isso, dize-mo-lo onipotente. Ora — possível — é
susceptível de duplo sentido, segundo o Filósofo.
Num sentido, é relativo a alguma potência; assim, dizemos ser possível ao homem o que lhe depende da
potência. Ora, não podemos dizer que Deus é onipotente por poder tudo o possível à natureza criada,
porque a divina potência tem maior amplitude. Por outro lado, se dissermos que Deus é onipotente,
porque pode tudo o que ao seu poder é possível, haverá círculo nesta explicação da onipotência. Pois,
seria o mesmo dizer que Deus é onipotente por poder tudo o que pode. Donde se conclui que Deus é
dito onipotente por poder tudo o que é absolutamente possível; que é outro sentido da expressão —
possível. Assim, uma coisa é possível ou impossível, absolutamente, pela relação dos termos. Há possível
absoluto quando o predicado não repugna ao sujeito, p. ex., Sócrates estar sentado; e impossível
absoluto, quando repugna, p. ex., ser um homem asno. Mas, devemos considerar que, agindo todo
agente conforme a sua natureza, a cada potência ativa, segundo a natureza do ato em que se funda,
assim, lhe corresponde o possível, como objeto próprio. P. ex., o que pode ser aquecido é objeto próprio
da potência calefactiva. Ora, o ser divino, fundamento da divina potência, é infinito, não limitado a
nenhum gênero de ser, mas encerra exemplarmente a perfeição de todo o ser. Por onde, tudo o que
tem ou pode ter natureza de ente está contido na possibilidade absoluta, em relação à qual dizemos
que Deus é onipotente. Pois, só a noção de não ser se opõe à de ser. Portanto, só repugna à noção do
possível absoluto, objeto da onipotência divina, o que implica em si simultaneamente o ser e o não-ser.
Porque isto não está sujeito a ela; não por deficiência da potência divina, mas, por não ter natureza de
factível, nem de possível. Por onde, tudo o que não implique contradição está contido nesses possíveis,
relativamente aos quais dizemos que Deus é onipotente. As coisas, porém, que implicam contradição
não constituem objeto da divina onipotência, por não poderem ter a natureza de coisas possíveis. Por
isso, é mais conveniente dizer que não podem ser feitas, em vez de dizer que Deus não pode fazê-las.
Nem isto vai contra as palavras do Anjo: Porque a Deus nada é impossível. Pois, o contraditório, não
podendo ser conceito, nenhum intelecto pode concebê-lo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como vimos, é pela potência ativa e não, pela passiva,
que dizemos ser Deus onipotente. Logo, não repugna à onipotência não poder ser movida nem sofrer.

RESPOSTA À SEGUNDA. — Pecar é desviar-se da ação perfeita. Por onde, poder pecar é poder desviar-
se, ao agir, o que repugna à divina onipotência. Por isso, Deus sendo onipotente, não pode pecar. E o
dito do Filósofo — Deus, como o homem virtuoso, pode fazer o mal — pode-se entender
condicionalmente, isto é, como aquilo cujo antecedente é impossível; assim, se dissermos que Deus
pode agir mal, se quiser. Pois, nada impede seja verdadeira uma cláusula condicional, de que o
antecedente e o conseqüente são impossíveis; como se dissermos, p. ex., — se o homem é asno, tem
quatro pés. Ou então, podemos entender essa afirmação no sentido que Deus pode fazer certas coisas
que, agora, nos parecem más, e que seriam boas se ele as fizesse. Ou então, o Filósofo se exprime de
acordo com a comum opinião dos gentios, que diziam transformarem-se os homens em deuses, como
Júpiter ou Mercúrio.

RESPOSTA À TERCEIRA. — Dizemos que a onipotência de Deus se manifesta, sobretudo em perdoar e
comiserar-se, porque o perdoar livremente os pecados é prova do seu poder sumo; pois, quem está
sujeito à lei de um superior não pode livremente perdoá-los. Ou porque, perdoando aos homens e deles
comiserando-se, leva-os Deus a participar do infinito bem, último efeito da divina virtude. Ou ainda
porque, como dissemos, o efeito da divina misericórdia é o fundamento de todas as obras divinas, pois,
o devido a alguém só o é pelo indevido que Deus lhe deu. E nisto principalmente sê manifesta a divina
bondade à qual pertence à instituição primeira de todos os bens.

RESPOSTA À QUARTA. — O possível absoluto é assim chamado por sê-lo por si mesmo, e não, por
causas superiores ou inferiores. O possível, porém, assim denominado relativamente a uma potência, o
é pela causa próxima. Por onde, o que, por natureza, só pode ser feito por Deus, como criar, justificar e
coisas semelhantes, chama-se possível em virtude de uma causa superior. Aquilo porém que é de
natureza a ser feito por causas inferiores chama-se possível em virtude dessas causas; pois, da condição
da causa próxima provém a contingência ou a necessidade do efeito, conforme dissemos. Por onde,
considera-se estulta a sabedoria do mundo por julgar impossível a Deus o que o é à natureza. E assim, é
claro que a onipotência de Deus não exclui das coisas a impossibilidade e a necessidade.

## Art. 4 — Se Deus pode tornar o passado inexistente.
(IIa IIae, q. 152, a 3, ad 3; I Sent., dist. XLII, q. 2, a. 2; II Cont. Gent., cap. XXV; De Pot., q. 1, a. 3, ad 3;
Quodl., V, q. 7, a. 1; VI Ethic., 1ecl. II).
O quarto discute-se assim. — Parece que Deus pode tornar o passado inexistente.

1. — Pois, o impossível por si é mais impossível que o por acidente. Ora, Deus pode fazer o impossível
por si, como, dar vista a um cego ou ressurgir um morto. Logo, com maior razão, pode fazer o impossível
por acidente. Ora, o passado não ter sido é impossível por acidente; por ex., só por ser já passado, é
acidentalmente impossível Sócrates não correr. Logo, Deus pode tornar o passado inexistente.

2. Demais. — Como o seu poder não diminui, tudo o que Deus pôde fazer ainda o pode. Ora, antes de
Sócrates ter corrido, Deus podia fazer com que não corresse. Logo, depois que correu, pode fazer com
que não tenha corrido.

3. Demais. — A caridade é maior virtude que a virgindade. Ora, Deus pode reparar a caridade perdida.
Logo, também a virgindade. E, portanto pode fazer com que não seja corrupta aquela que o foi.
Mas, em contrário, Jerônimo: Deus, que pode tudo, não pode tornar virgem uma corrupta. Logo, pela
mesma razão, não pode fazer com que o passado não seja.

SOLUÇÃO. — O poder de Deus, como dissemos, não abrange o que implica contradição. Ora, o passado
não ter sido implica contradição. Pois, assim como a implica dizer que Sócrates está e não está sentado,
assim também que esteve e não esteve sentado. Porque, se dizer que esteve sentado é enunciar um
passado, dizer que não o esteve é enunciar o que não se deu. Por onde, não está no poder divino tornar
inexistente o passado. E é o que diz Agostinho: Quem diz: se Deus é onipotente torne o feito não feito,
não vê que diz: se é onipotente torne falso o que em si é verdadeiro. E o Filósofo: Deus só está privado
de tornar o feito não feito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É impossível, por acidente, o passado não ter sido,
considerando-se o passado, i. é, a corrida de Sócrates. Contudo, considerando o passado, como tal, é
impossível a inexistência, não só em si mesma, mas absolutamente, por implicar contradição. E assim, é
mais impossível do que ressurgir um morto, que não a implica, e se chama impossível relativamente ao
poder natural. Ora, impossíveis como este estão no poder de Deus.

RESPOSTA À SEGUNDA. — Deus, pela perfeição do seu poder, pode tudo, mas lhe escapa à potência o
que não tem natureza de possível. Assim também, se atendermos à imutabilidade do seu poder, Deus
pode tudo o que pôde; porém, certas coisas que, antes quando eram factíveis, tinham a natureza de
possível, já não a têm quando feitas. E, então dizemos que não as pode, por não poderem elas ser feitas.

RESPOSTA À TERCEIRA. — Embora Deus possa remover toda corrupção da alma e do corpo da mulher
corrupta, todavia, não pode fazer com que não tenha sido corrupta; como também não pode fazer com
que um pecador não o tenha sido e que não tivesse perdido a caridade.

## Art. 5 — Se Deus só pode fazer o que faz.
(I Sent., dist. XLIII, q. 2; II Cont. Gent., cap. XXIII. XXVI, XXVII; III, cap. XCVIII, De Pot., q. 1, a. 5).
O quinto discute-se assim. — Parece que Deus só pode fazer o que faz.

1. — Pois, não pode fazer o que não previu nem preordenou que devia fazer. Ora, só previu e
preordenou que havia de fazer o que faz. Logo, só pode fazer o que faz.

2. Demais. — Deus só pode o que deve e o que é justo que se faça. Ora, nem deve nem é justo fazer o
que não faz. Logo, só pode fazer o que faz.

3. Demais. — Deus só pode fazer o bom e conveniente às coisas feitas. Ora, não lhes é bom nem
conveniente às coisas feitas por Deus, o que existirem diferentemente do que existem. Logo, Deus só
pode fazer o que faz.
Mas, em contrário, o Evangelho (Mt 26, 53): Acaso cuidas tu que eu não posso rogar a meu pai, e que
ele me não porá aqui logo pronto mais de doze legiões de anjos? Mas nem ele rogava, nem o pai
mandava, para repelir os Judeus. Logo, Deus pode fazer o que não faz.

SOLUÇÃO. — Sobre este assunto houve duas sortes de erros.
Uns disseram que Deus age como por necessidade de natureza. Pois, assim como da ação dos seres
naturais só podem provir os efeitos dela provenientes, p. ex. do sêmen humano, o homem, e da
semente da oliveira, a oliveira, assim também, da ação divina não poderiam resultar outros seres ou
outra ordem de seres diferentes dos atualmente existentes. — Mas, como já demonstramos, Deus não
age por necessidade de natureza, senão que a sua vontade é a causa de todas as coisas; e nem a sua
vontade, natural e necessariamente, está determinada a produzi-las. Por onde, de nenhum modo a
ordem atual das coisas provém de Deus necessariamente e de maneira tal, que não possa provir outra.
Outros, porém, disseram que o poder divino se determinou à ordem atual dos seres, por causa da
ordem da sapiência e da justiça divinas, sem as quais Deus nada faz. — Mas, a potência, que é a essência
de Deus, não difere da sua sabedoria. Por onde, podemos dizer, com razão, que nada está no poder de
Deus, que não esteja na ordem da divina sabedoria; pois, esta compreende todo o poder da potência.
Contudo, a ordem que a divina sabedoria infundiu nas coisas, e na qual está o fundamento da justiça,
como dissemos, não condiz de modo tal com a sabedoria divina, que esta fique limitada a tal ordem.
Pois é manifesto que todo o fundamento da ordem que o sábio infunde nas coisas que faz, deriva do
fim. Quando, pois, o fim se proporciona às coisas feitas em vista dele, a sabedoria de quem as fez se
limita a uma ordem determinada. Mas a divina bondade é um fim que excede, sem proporções, a todas
as criaturas. Portanto não está a divina sabedoria determinada a nenhuma ordem de seres com exclusão
de qualquer outra. Por onde, devemos concluir que Deus pode, absolutamente falando, fazer coisas
diferentes do que faz.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Em nós, a potência e a essência diferem da vontade e do
intelecto; o intelecto, da sapiência; à vontade, da justiça. Por isso, o que está na potência pode não estar
na vontade justa ou no intelecto sábio. Mas, em Deus, identificam-se a potência, a essência, a vontade,
o intelecto, a sapiência e a justiça. Portanto, nada pode lhe estar na potência que também não o possa
na vontade justa e no intelecto sábio. Contudo, a sua vontade, como vimos, não está necessàriamente
determinada a esta ou àquela coisa, a não ser talvez por suposição. Nem a sabedoria de Deus e a sua
justiça estão determinadas a essa ordem, como dissemos. Pois, nada impede esteja alguma coisa no
poder divino, que Deus não quer e não está incluído na ordem de coisas que estabeleceu. E
compreendendo nós o poder como exeqüente, a vontade, como imperante, e o intelecto e a sapiência,
como dirigentes, dizemos que Deus pode,por potência absoluta, tudo o que é atribuído ao seu poder,
em si mesmo considerado. E isto abrange tudo o que tem natureza de ser, como vimos. Dizemos,
porém, que Deus pode, por potência ordenada o que a esta é atribuído, enquanto executora da ordem
da vontade justa. Por onde, devemos concluir, que, pela potência absoluta, Deus pode fazer coisas
diversas das que previu e preordenou que haveria de fazer. Não é possível, porém, faça coisas diversas
das que previu e predeterminou que haveria de fazer. Pois, o seu próprio fazer está sujeito à presciência
e à preordenação; não porém o seu poder, que lhe é natural. Por onde, Deus faz o que quer; porém, o
que pode não é porque o queira, mas, porque está na sua natureza.

RESPOSTA À SEGUNDA. — Deus nada deve a ninguém, senão a si próprio. Por isso, dizer que Deus só
pode fazer o que deve é dizer que só pode o que lhe é conveniente e justo. Mas, duplo é o sentido da
expressão conveniente e justo. Considerando a expressão — conveniente e justo — como ligada,
primeiro, com o verbo é, de modo que se restrinja ela às causas presentes e, assim, se refira à potência,
essa expressão é falsa e o seu sentido é: Deus só pode fazer o que presentemente é conveniente e justo.
Mas, se a ligarmos, primeiramente, ao verbo pode — que tem força ampliativa, e, depois, ao verbo — é
— significará algo de presente e confuso; e, então, será verdadeira neste sentido: Deus só pode fazer
aquilo que, se o fizesse, seria conveniente e justo.

RESPOSTA À TERCEIRA. — Não obstante a ordem atual das causas determinadas às existências, contudo
a tal ordem não ficam limitadas a sapiência nem o poder divino. Donde, embora às coisas existentes
nenhuma outra ordem seja boa e conveniente, entretanto Deus poderia fazer outras e lhes impor outra
ordem.

## Art. 6 — Se Deus pode fazer coisas melhores que as que faz.
(I Sent., dist. XLIV, a. 1, 2, 3).
O sexto discute-se assim. — Parece que Deus não poderia fazer coisas melhores que as que faz.

1. — Pois, tudo o que Deus faz, potentíssima e sapientíssimamente o faz. Ora, tanto melhor fazemos o
que tanto mais poderosa e sabiamente fazemos. Logo, Deus não pode fazer melhor do que faz.

2. Demais. — Agostinho assim argumenta: Se Deus podia e não quis gerar o Filho igual a si, foi invejoso.
Pela mesma razão, foi invejoso, se podia e não quis fazer as coisas melhores, que as fez. Ora, a inveja de
nenhum modo existe em Deus. Logo, tudo o que fez é ótimo e, portanto, nada pode fazer melhor do
que faz.

3. Demais. — Não é possível fazer nada melhor do que aquilo que em máximo grau é bom, pois, nada é
maior que o máximo. Ora, como diz Agostinho, cada coisa que Deus fez é boa; mas muito boa é a
simultânea universalidade das coisas; porque todas compõem a admirável beleza do universo. Logo,
Deus não pode fazer melhor o bem do universo.

4. Demais. — Cheio de graça, de verdade e repleto sem medida, do Espírito, o Homem Cristo não pode
ser melhor. Mas, também se diz que a beatitude criada é o sumo bem e, portanto não pode ser melhor.
E ainda, a Virgem Maria, exaltada sobre todos os coros dos anjos, não pode ser melhor. Logo, nem tudo
Deus pode fazer melhor do que fez.
Mas, em contrário, o Apóstolo diz que Deus é poderoso para fazer todas as coisas mais abundantemente
do que pedimos ou entendemos (Ef 3, 20).

SOLUÇÃO. — Dupla é a bondade de uma coisa. Uma, pertence-lhe à essência; assim, ser racional é da
essência do homem. E, quanto a esta bondade, Deus não pode fazer um ser melhor do que é, embora
possa fazer outro melhor. Assim, não pode fazer o número quaternário maior; pois, se fosse maior, já
não seria quaternário, mas outro número. Ora, a adição da diferença substancial, nas definições, é como
a da unidade, nos números, como diz Aristóteles. Outra é a bondade exterior à essência do ser; assim o
bem do homem é ser virtuoso ou sábio. E, quanto a esta, Deus pode fazer coisas melhores do que as
que fez. Mas, absolutamente falando, Deus pode fazer qualquer coisa melhor que a fez.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Se, quando dizemos que Deus pode fazer melhor alguma
coisa do que fez, melhor for um nome, a proposição é verdadeira, pois, pode fazer uma coisa melhor do
que qualquer outra. E a mesma coisa pode, de certo modo, fazê-la melhor; embora, de outro modo, não
o possa. Mas, como dissemos, se melhor for advérbio e implicar o modo por parte de quem faz, então
Deus nada pode fazer melhor, porque nada pode fazer com maior sabedoria e bondade. Se, porém, o
advérbio implica o modo no que é feito, então Deus pode fazer melhor, porque pode dar às coisas que
fez um melhor modo acidental de existir, embora não essencial.

RESPOSTA À SEGUNDA. — Da natureza do filho é, quando for perfeito, igualar-se ao pai; mas não é da
natureza de nenhuma criatura ser melhor do que Deus a fez. Logo, a comparação não colhe.

RESPOSTA À TERCEIRA. — Supostas coisas existentes, o universo não pode ser melhor, por causa da
convenientíssima ordem, que Deus lhes atribuiu, no que consiste o bem do mesmo. Pois, se uma delas
fosse melhor, corromper-se-ia a proporção da ordem; como haveria de corromper-se a melodia da
citara, se fosse uma corda mais tensa que outra. Mas Deus poderia fazer outras coisas, ou acrescentá-las
às já feitas, e então o universo seria melhor.

RESPOSTA À QUARTA. — A humanidade de Cristo, por estar unida a Deus; a beatitude criada, por ser a
fruição de Deus, e a beata Virgem, por ser a Mãe de Deus, têm uma certa dignidade infinita, proveniente
do bem infinito, que é Deus. E, por este lado, nada pode ser melhor que elas, bem como, nada pode ser
melhor que Deus.