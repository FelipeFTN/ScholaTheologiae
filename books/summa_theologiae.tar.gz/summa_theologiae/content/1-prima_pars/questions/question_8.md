# Questão 8: Da existência de Deus nas coisas.
Parecendo, pois, convir ao infinito estar em toda parte e em todos os seres, devemos examinar se isso
realmente é assim. E nesta questão discutem-se quatro artigos:

## Art. 1 — Se Deus está em todas as coisas.
(I Sent., dist. XXXVII, q. 1, a. 1; III Cont. Gent., cap. LXVII)
O primeiro discute-se assim. — Parece que Deus não está em todas as coisas.

1. — Pois, o que é superior a tudo, não está em tudo. Ora, Deus é superior a tudo, conforme a Escritura
(Sl 112, 4): Excelso é o Senhor sobre todas as gentes, etc. Logo, Deus não está em todas as coisas.

2. Demais. — O que está em outra coisa, por esta é contido. Ora, Deus não está contido nas coisas, mas
antes, as contém. Logo, não está nelas, mas elas é que estão nele. Por isso diz Agostinho: Todas as
coisas estão, antes, nele, que ele, em qualquer delas.

3. Demais. — Quanto mais intensa é a virtude de um agente, a tanto mais longe se estende. Ora, Deus é
agente de máxima virtude. Logo, a sua ação pode estender-se a tudo o que dele dista, sem ser
necessário estar em todas as coisas.

4. Demais. — Os demônios também são seres e, contudo, Deus não está neles, pois como diz a Escritura
(2 Cor 6, 14), não há comércio entre a luz e as trevas. Logo, Deus não está em todas as coisas.
Mas, em contrário. — Um ser está onde age. Ora, Deus age em todas as coisas, segundo a Escritura (Is
26, 12): Senhor, tu és o que fizeste em nós todas as nossas obras. Logo, Deus está em todas as coisas.

SOLUÇÃO. — Deus está em todas as coisas, não, por certo, como parte da essência ou como acidente de
cada uma delas, mas como o agente está presente ao que aciona. Pois, é necessário que todo agente
esteja em conjunção com o ser sobre o qual age imediatamente, e o atinja pela sua virtude; e assim
Aristóteles prova que móvel e motor devem existir simultaneamente. Ora, tendo Deus a existência
idêntica à essência, o ser criado há de necessariamente ser efeito próprio seu, assim como queimar é
efeito próprio do fogo. Ora, tal efeito Deus causa nas coisas, não somente quando começam a existir,
mas enquanto subsistem; assim como a luz é causada no ar pelo sol, durante todo o tempo em que
permanece iluminado. Logo, enquanto subsistir uma coisa, é necessário que Deus lhe esteja presente,
conforme o modo de existência próprio dela. Ora, o ser é o que de mais íntimo tem uma coisa e o que
de mais profundo existe em todas as coisas; pois, comporta-se como forma em relação a tudo o que na
coisa existe, conforme no sobredito se colhe. Logo, é necessário que Deus esteja, e intimamente, em
todas as coisas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus é superior a todos os seres pela excelência da sua
natureza; e contudo está em todas as coisas e lhes é causa do ser, como antes se disse.

RESPOSTA À SEGUNDA. — Embora se diga que uma coisa corpórea esteja em outra, quando nesta está
contida, contudo, os seres espirituais contêm aquilo em que estão; assim, a alma contém o corpo. Por
isso Deus está nas coisas por as conter. Todavia, por semelhança com as coisas corpóreas, dizemos que
todas estão em Deus, porque as contém.

RESPOSTA À TERCEIRA. — A ação de nenhum agente, por maior virtude que tenha este, atinge o
distante, senão por intermédio de um meio. Ora, é pela sua virtude máxima que Deus age
imediatamente sobre todas as coisas. Por isso nada há tão distante que Deus, por assim dizer, não
contenha em si. Dizemos porém, que as coisas distam de Deus, por dissemelhança de natureza ou de
graça, assim como dizemos que ele é superior a todas pela excelência da sua natureza.

RESPOSTA À QUARTA. — Os demônios têm, de Deus, a natureza, não, porém, a deformidade da culpa.
Por onde, não se pode conceder, de modo absoluto, que Deus esteja neles, senão acrescentando-se:
enquanto seres. Devemos porém dizer, absolutamente, que Deus está nas coisas cujos nomes designam
uma natureza não deformada.

## Art. 2 — Se Deus está em toda parte.
(Infra., q. 16, a. 7, ad 2; q. 52, a. 2; I Sent., dist. XXXVII, q. 2, a.1; III Cont. Gent., cap. LXVIII; Quodl. XI, a.
1).
O segundo discute-se assim. — Parece que Deus não está em toda parte.

1. — Pois, estar em toda parte significa estar em todos os lugares. Ora, isto não convém a Deus, que não
está em nenhum lugar, como se dá com todos os seres incorpóreos, conforme Boécio. Logo, Deus não
está em toda parte.

2. Demais. — O tempo está para o sucessivo, como o lugar para o permanente. Ora, o indivisível no
gênero da ação ou do movimento não pode estar em diversos tempos. Logo, nem o indivisível no gênero
das coisas permanentes pode estar em todos os lugares. E não sendo o ser divino sucessivo, mas
permanente, Deus não pode estar em vários lugares e, portanto, não está em toda parte.

3. Demais. — O que está totalmente em algum lugar nada tem fora desse lugar. Ora, se Deus está em
algum lugar, há de sê-lo totalmente, pois não tem partes. Logo, nada tem desse lugar e, portanto, não
está em toda parte.
Mas, em contrário, diz a Escritura (Jr 23, 24): Encho eu o céu e a terra.

SOLUÇÃO. — Sendo o lugar uma realidade, de dois modos podemos entender a expressão — estar num
lugar: como as outras coisas, quando dizemos que uma está em outras, de qualquer modo — assim, os
acidentes do lugar nele estão; ou de um modo próprio ao lugar — assim, as coisas estão colocadas num
lugar. Ora, de ambos esses modos, Deus está, de certa maneira, em todos os lugares, o que é estar em
toda parte. Do primeiro modo, assim como está em todas as coisas, a que dá virtude e operação, assim,
está em todos os lugares, dando-lhes o ser e a virtude locativa. Demais, as coisas estão colocadas em
lugares, porque os enchem. Ora, Deus enche todos os lugares, não como um corpo, do qual se diz que
enche um lugar porque dele exclui qualquer outro corpo; pois Deus, embora estando em todos os
lugares, deles não exclui os outros seres, antes, os enche a todos porque dá o ser às coisas que os
ocupam.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os seres incorpóreos não ocupam lugar pelo contato da
unidade dimensiva, como os corpos, mas pelo contato da virtude.

RESPOSTA À SEGUNDA. — Há duas espécies de indivisível. Um é termo do contínuo, como o ponto, nas
coisas permanentes, e o momento, nas sucessivas. Ora, o indivisível permanente, tendo situação
determinada, não pode estar nas várias partes do lugar ou em vários lugares. Semelhantemente, o
indivisível da ação ou do movimento, tendo neste ou naquela uma ordem determinada, não pode estar
em muitas partes do tempo. O outro indivisível é o que está fora de todo gênero do contínuo e, deste
modo, chamam-se indivisíveis as substâncias incorpóreas, como Deus, o anjo e a alma. Ora, tal
indivisível não se aplica ao contínuo como parte dele, mas enquanto o atinge pela sua virtude. Por onde,
conforme essa virtude pode se estender a uma ou muitas coisas, grandes ou pequenas, estará em um
ou muitos lugares, em lugar grande ou pequeno.

RESPOSTA À TERCEIRA. — O todo é assim denominado em relação às partes. Ora, há duas espécies de
partes. A das partes da essência e, assim, a forma e a matéria consideram-se partes do composto, o
gênero e a diferença, partes da espécie. E a das partes da quantidade, nas quais qualquer quantidade se
resolve. Ora, o que está totalmente num lugar, pela totalidade quantitativa, não pode estar fora desse
lugar, pois, a quantidade do que ocupa um lugar é comensurada pela quantidade deste e, portanto, não
há totalidade quantitativa se não houver totalidade local. A totalidade da essência, porém, não é
comensurada pela totalidade do lugar; e por isso o que está todo, por totalidade de essência, em algum
lugar, não está impedido, de nenhum modo, de estar fora desse lugar. E isto se vê também nas formas
acidentais que têm quantidade acidental. Assim, a brancura, pela totalidade essencial está em toda e
qualquer parte de uma superfície, porque em qualquer apresenta a essência perfeita da sua espécie. Se
lhe considerarmos, porém, a totalidade, quanto à sua quantidade acidental, não está toda em cada
parte da superfície. Nas substâncias incorpóreas, porém, não há totalidade essencial nem acidental,
senão a que é realizada pela plenitude da essência. Logo, assim como a alma está toda em cada parte do
corpo, assim Deus está todo em todos os seres e em cada um em particular.

## Art. 3 — Se estão bem assinalados os modos por que Deus existe em todas as coisas, dizendo-se que existe por essência, poder e presença.
(I Sent., dist, XXXVII, q. 1, a. 2; et in expos. lit.).
O terceiro discute-se assim. — Parece que estão mal assinalados os modos por que Deus existe em
todas as coisas, dizendo-se que existe por essência, poder e presença.

1. — Pois, estar por essência em alguma coisa é estar essencialmente. Ora, Deus, não sendo da essência
de nenhuma coisa, em nenhuma está essencialmente. Logo, não se deve dizer que nelas está por
essência, presença e poder.

2. Demais. — Estar presente a uma coisa é não lhe faltar. Ora estar Deus por essência nas coisas é não
lhes faltar. Logo, o mesmo é estar em todas por essência e por presença e, portanto, é supérfluo dizer
que Deus está nas coisas por essência, presença e poder.

3. Demais. — Assim como Deus é o princípio de todas as coisas pelo seu poder, assim, também o é pela
ciência e pela vontade. Ora, não se diz que está nas coisas por esta e por aquela. Logo, nem pela
potência.

4. Demais. — Como a graça, há muitas outras perfeições acrescentadas à substância de um ser. Se, pois,
dizemos que Deus está em certos seres, de modo especial, pela graça, devemos admitir um modo
especial pelo qual está nas coisas, segundo uma determinada perfeição.
Mas, em contrário, diz Gregório: Deus, de modo comum está em todas as coisas pela presença, poder e
substância; contudo, de modo familiar, diz-se que está em certos seres pela graça.

SOLUÇÃO. — De dois modos se pode dizer que Deus está numa coisa: como causa agente e, assim, está
em todas as que criou: e como o objeto da ação está no agente, o que é próprio das operações da alma,
pois assim é que está o objeto conhecido no ser que conhece e o desejado, no que deseja. — Ora, deste
segundo modo, Deus está especialmente na criatura racional, que o conhece e o ama atual ou
habitualmente. E como isto a criatura o tem da graça, como a seguir se verá, dizemos que Deus está nos
santos pela graça.
Para compreendermos, porém, como é que ele está nos demais seres, que criou, devemos examinar o
que se dá com as coisas humanas. Ora, dizemos que um rei está, pelo poder, em todo reino, embora ele
não esteja presente em todo. Por outro lado, dizemos que alguém está presente a todas as coisas que
abrange com o seu olhar; e que todas as coisas, situadas numa parte da casa, estão presentes a alguém
que, contudo não está, pela sua substância, em todas as partes da mesma. Por fim, dizemos que um ser
está, pela sua substância ou essência, no lugar pela substância ocupado.
Alguns, porém, como os Maniqueus, disseram que ao divino poder estão sujeitas as criaturas espirituais
e incorpóreas; mas, que as visíveis e corpóreas estão sujeitas ao poder do princípio oposto. Ora, contra
estes devemos dizer que Deus está em todos os seres pelo seu poder. — Outros, ainda, embora
acreditassem que todas as coisas estão sujeitas ao divino poder, não admitiam contudo que a
providência divina estendesse até às inferiores realidades corpóreas. E esses poderiam se servir das
palavras de Jó (Jó 22, 14): Nas nuvens está escondido, nem tem cuidado das nossas coisas. Ora, contra
estes, tivemos que estabelecer que Deus está em todas as coisas pela sua presença. — Outros, por fim,
embora admitindo que todas as coisas dependem da providência divina, ensinavam contudo, que nem
todas foram criadas imediatamente por Deus, mas só as primeiras criaturas, que, por sua vez, criaram as
outras. Ora, contra estes, há de dizer-se, que ele está em todas pela essência. — Assim, pois, Deus está
em todas as coisas pelo poder, porque todas lhe estão sujeitas; pela presença, porque tudo lhe está
descoberto e como a nú diante dos olhos; e pela essência, porque a todas está presente como causa de
serem, conforme se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dizemos que Deus está em todas as coisas, não pela
essência delas, como se delas fizesse parte, mas, pela sua, porque a sua substância está presente a
todas como causa de serem, conforme já se disse.

RESPOSTA À SEGUNDA. — Um ser pode estar presente a outro, que o vê, embora dele diste pela
substância, como dissemos; e por isso, distinguimos dois modos — por essência e por presença.

RESPOSTA À TERCEIRA. — É da natureza da ciência e da vontade, que a coisa conhecida esteja em quem
conhece, e a querida, em quem quer. Por onde, pela ciência e pela vontade, as coisas estão, antes em
Deus, que Deus nelas. Mas, é da essência do poder ser princípio de ação sobre outrem. Por onde,
quanto ao poder, o agente se relaciona com a coisa exterior e a ela se aplica; e, assim, podemos dizer
que, desse modo, o agente está em outro ser.

RESPOSTA À QUARTA. — Nenhuma outra perfeição acrescentada à substância, a não ser a graça, faz
com que Deus esteja em algum ser, como objeto conhecido e amado. Por onde, só a graça constitui um
modo particular de existir Deus, nas coisas. Há, porém, outro modo singular de Deus existir no homem,
que é a união, do qual em seu lugar se tratará.

## Art. 4 — Se estar em toda parte é próprio de Deus.
(Infra, q. 52, a. 2; 112, a. 1; I Sent., dist. XXXVII, q. 2, a. 2; q. 3, a. 2; IV Cont. Gent., cap. XVII; Quodl., XI, a.
1; De Div. Nom., cap. III, lect. I).
O quarto discute-se assim. — Parece que estar em toda parte não é próprio de Deus.

1. — Pois, o universal, segundo o Filósofo, existe em toda parte e sempre; e a matéria prima, existindo
em todos os corpos, está em toda parte. Ora, nem esta é Deus, nem aquele, como do sobredito resulta.
Logo, estar em toda parte não é próprio de Deus.

2. Demais. — O número está nas coisas numeradas. Ora, todo o universo foi constituído com número,
como se vê na Escritura (Sb 2, 21). Logo, há um número que está em todo universo e, portanto, em toda
parte.

3. Demais. — Todo o universo é no seu conjunto uma espécie de corpo perfeito, como diz Aristóteles.
Ora, o universo está em toda parte, porque fora dele não há nenhum lugar. Logo, nem só Deus está em
toda parte.

4. Demais. — Se houvesse um corpo infinito, nenhum lugar existiria, fora dele. Logo, estaria em toda
parte, e, portanto, esse modo de existir não é próprio de Deus.

5. Demais. — A alma, como diz Agostinho, está toda em todo corpo e em cada uma das partes dele. Se,
portanto, no mundo não existisse senão um só animal, a alma do mesmo estaria em toda parte. Logo,
estar em toda parte, não é próprio de Deus.

6. Demais. — Como diz Agostinho, a alma onde vê, aí sente; e onde sente, aí vive; e onde vive, aí
está. Ora, a alma vê quase em toda parte, porque vê, sucessivamente, mesmo todo céu. Logo, ela está
em toda parte.
Mas, em contrário, diz Ambrósio: Quem ousará considerar como criatura o Espírito Santo, que está em
todas as coisas, e em toda parte e sempre, o que, certo, é próprio da divindade? SOLUÇÃO. — Estar em
toda parte, primariamente e por si, é próprio de Deus. Quando digo estar em toda parteprimariamente,
entendo estar desse modo por si, totalmente. Pois, não estaria primariamente em toda parte o ser que
tivesse partes diversas em lugares diversos, porquanto, o que convém a um ser, em razão de uma parte,
não lhe convém primariamente; assim a brancura do dente de um homem convém primariamente, não
ao homem, mas ao dente. Em seguida, quando digo — por si — refiro-me àquilo a que não convém
estar em toda parte por acidente, em virtude de alguma condição restritiva, como seria o caso de um
grão de milho, que existiria em toda parte, dado que, nenhum outro corpo existisse. Logo, convém o
existir em toda parte, por si, ao ser que desse modo existe, qualquer que seja a hipótese. Ora, isto
convém propriamente a Deus; pois, sejam quantos forem os lugares supostos, mesmo que sejam
infinitos mais que os existentes, em todos eles estará necessariamente, porque nada pode existir sem
ser por ele. Por onde, existir em toda parte, primariamente e por si, convém a Deus, e lhe é próprio;
pois, por mais lugares que se suponham, Deus existe necessariamente em cada um deles, não por
partes, mas por si mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O universal e a matéria prima existem, certo, em toda
parte, mas não com identidade de ser.

RESPOSTA À SEGUNDA. — O número, sendo acidente, está num lugar, não por si, mas acidentalmente;
nem está todo, mas por partes, em cada uma das coisas numeradas. Donde, pois, não se segue que
esteja em toda parte, primariamente e por si.

RESPOSTA À TERCEIRA. — O corpo total do universo está em toda parte, mas não primariamente,
porque não está todo em qualquer lugar, mas por partes. Demais, nem por si, porque se supusessem
outros lugares neles não estaria.

RESPOSTA À QUARTA. — Se existisse um corpo infinito estaria em toda parte, parcialmente.

RESPOSTA À QUINTA. — Se existisse um só animal, a sua alma estaria em toda parte, primariamente,
por certo, mas por acidente.

RESPOSTA À SEXTA. — A expressão — onde vê — pode-se entender em duplo sentido. Ou o advérbio
onde determina o ato de ver, considerado em relação ao objeto e, então, é verdade que, vendo o céu,
no céu vê e, pela mesma razão, sente no céu; mas, daí não se segue que viva, ou esteja no céu, porque
viver e existir não implicam nenhum ato transitivo para um objeto exterior. Ou, pode-se tomar o
advérbio como determinando o ato de ver, que emana do sujeito que vê, e, então, é verdade que a
alma, onde sente e vê, aí está e vive, conforme este modo de falar; mas daqui não se segue que ela
esteja em toda parte.