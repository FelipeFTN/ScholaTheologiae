# Questão 97: O estado do corpo de Adão: Preservação do indivíduo.
Em seguida devemos tratar do que diz respeito ao estado do primeiro homem, quanto ao corpo. E
primeiro quanto à conservação do indivíduo. Segundo, quanto à conservação da espécie.

## Art. 1 — Se o homem, no estado de inocência, era imortal.
O primeiro discute–se assim. – Parece que o homem no estado de inocência não era imortal.

1. Pois, mortal entra na definição do homem. Ora, removida a definição, removido fica o definido. Logo
se o homem existia não podia ser imortal.

2. Demais. – O corruptível e o incorruptível diferem genericamente, como diz Aristóteles. Ora, coisas
genericamente diferentes não se transmutam umas nas outras. Logo, se o primeiro homem era
incorruptível não podia o homem ser corruptível na vida presente.

3. Demais. – Se o homem, no estado de inocência, era imortal, havia de sê–lo por natureza ou por graça.
Ora, por natureza não, porque como esta permanece especificamente a mesma, ainda agora o homem
seria imortal. Nem, semelhantemente, pela graça; porque tendo o primeiro homem recuperado a graça
pela penitência, conforme a Escritura: – Tirou–o de seu pecado – também teria necessariamente
recuperado a imortalidade, o que é evidentemente falso. Logo, o homem não era imortal, no estado de
inocência.

4. Demais. – A imortalidade é prometida ao homem como prêmio, conforme a Escritura: não haverá
mais morte. Ora, o homem não foi criado na posse de prémio, mas capaz de merecê–lo. Logo, no estado
da inocência, não era imortal.
Mas, em contrário, diz a Escritura: pelo pecado entrou a morte neste mundo. Logo, antes do pecado, o
homem era imortal.

SOLUÇÃO. – De três modos se pode dizer Que um ser é corruptível. – Primeiro, porque, quanto à
matéria, ou não a tem, como o anjo; ou a tem potencial a uma 'só forma, como o corpo celeste. E de tal
ser se diz que é materialmente incorruptível. – Segundo, porque, quanto à forma, a um ser corruptível
por natureza seja inerente alguma disposição que o livra, totalmente da corrupção. E de tal ser se diz
que é incorruptível, quanto à glória; pois, como diz Agostinho, Deus formou a alma de tão poderosa
natureza que faz redundar para o corpo, da felicidade, a plenitude da saúde, isto é, o vigor da
incorruptibilidade. – Terceiro, porque, quanto à causa eficiente, o homem, no estado de inocência, seria
incorruptível e imortal. Pois, como diz Agostinho, Deus fez o homem tal que, enquanto não pecasse,
floresceria na imortalidade, de maneira a ser ele próprio o autor da sua vida ou morte. Logo, o seu corpo
não era indissolúvel, por qualquer influxo de imortalidade nele existente; mas era–lhe inerente uma tal
virtude da alma, sobrenatural e divinamente dada, pela qual podia preservar o corpo de toda corrupção,
enquanto permanecesse a mesma sujeita a Deus. E isso foi racionalmente feito. Pois, excedendo a alma
racional a proporção da matéria corpórea, como já se disse antes, era conveniente que, no princípio, lhe
fosse dada virtude, pela qual pudesse conservar o corpo superior à natureza da matéria corpórea.

DONDE AS RESPOSTAS À PRIMEIRA E SEGUNDA OBJEÇÕES. – Essas objeções se fundam no
incorruptível e imortal por natureza.

RESPOSTA À TERCEIRA. – Essa virtude de preservar o corpo da corrupção não era natural à alma
humana mas dom da graça. E embora recuperasse a graça, para o efeito da remissão da culpa e o mérito
da glória, não a recuperou contudo para o da imortalidade perdida. E isso estava reservado a Cristo, que
repararia, melhorando–a a deficiência da natureza, como a seguir se dirá.

RESPOSTA À QUARTA. – A imortalidade da glória, prometida como prêmio, difere da imortalidade
conferida ao homem no estado de inocência.

## Art. 2 — Se o homem, no estado de inocência era passível.
O segundo discute–se assim. – Parece que o homem no estado de inocência era passível.

1. Pois, sentir é de certo modo sofrer. Ora, o homem no estado de inocência, era sensível. Logo,
também passível.

2. Demais. – O sono é uma paixão. Ora, o homem no estado de inocência dormia, segundo a Escritura:
Infundia pois o Senhor Deus, um profundo sono a Adão. Logo, era passível.

3. Demais. – A mesma Escritura acrescenta que tirou uma das suas costelas, Logo, era passível, ao
menos pela ablação de uma das suas partes.

4. Demais. – O corpo do homem era mole, que é passivo, em relação ao duro. Ora, o corpo do primeiro
homem sofreria se lhe viesse de encontro algum corpo duro. E, portanto, o primeiro homem era
passível.
Mas, em contrário, se fosse passível seria corruptível, pois, a paixão, aumentada, altera a substância.

SOLUÇÃO. – Paixão tem duplo sentido. – Um próprio; e então se diz que sofre aquilo que é removido da
sua disposição natural. Pois, a paixão é efeito da ação: ora, nas coisas naturais, os contrários agem e
sofrem, entre si, removendo um ao outro, da disposição natural. – Noutro sentido, a paixão é tomada
em comum, relativamente a qualquer imutação, mesmo que esta diga respeito à perfeição da natureza:
assim, inteligir ou sentir é de certo modo sofrer. Ora, neste segundo sentido, o homem no estado de
inocência era passível e sofria, tanto na alma como no corpo. Ao passo que no primeiro sentido da
paixão era impassível, na alma e no corpo, e ainda, imortal. E podia, se persistisse sem pecado, livrar–se
da paixão e da morte.
Donde se deduzem as RESPOSTAS ÀS DUAS PRIMEIRAS OBJEÇÕES. – Pois, sentir e dormir não tiram ao
homem a sua disposição natural; mas ordenam–se para o bem da natureza.

RESPOSTA À TERCEIRA. – Como já se disse antes, a referida costela estava em Adão, como princípio do
gênero humano; assim como o sêmen nele está como princípio, pela geração. Assim pois como a
emissão do sêmen não é acompanhada de paixão, que remova o homem da sua disposição natural, o
mesmo se deve dizer da ablação da referida costela.

RESPOSTA À QUARTA. – O corpo do homem, no estado de inocência, podia ser preservado de modo a
não sofrer nenhuma lesão proveniente de qualquer corpo duro. E isso, em parte, pela própria razão pela
qual podia evitar as causas nocivas; e, em parte, pela divina providência, que o defendia de tal modo,
que nada lhe ocorresse de improviso, que o ferisse.

## Art. 3 — Se o homem; no estado de inocência, precisava de alimentos.
O terceiro discute–se assim. – Parece que o homem, no estado de inocência, não precisava de
alimentos.

1. – Pois, o alimento é necessário ao homem para recuperar as forças perdidas. Ora, o corpo de Adão,
sendo incorruptível, não sofria nenhuma perda. Logo, não lhe era necessário o alimento.

2. Demais. – O alimento é necessário para nutrir; mas, nutrição implica paixão. Ora, como o corpo do
homem era impassível, não lhe era necessário o alimento, segundo parece.

3. Demais. – O alimento nos é necessário para a conservação da vida. Ora, Adão podia conservar a vida
de outro modo; pois, se não tivesse pecado não morreria. Logo, o alimento não lhe era necesssário,

4. Demais. – Da alimentação resulta a rejeição do supérfluo, o que implica certa torpeza, que não condiz
com a dignidade do primeiro estado. Logo, conclui–se que o homem, no primeiro estado, não usava de
alimentos.
Mas, em contrário, diz a Escritura: Come de todos os frutos das árvores do paraíso.

SOLUÇÃO. – O homem no estado de inocência tinha a vida animal, que necessita de alimentos: porém,
depois da ressurreição, terá a vida espiritual que deles não necessita. Para o entendimento do que
devemos considerar que a alma racional é alma e espírito. E alma pelo que tem de comum com os
animais, que é dar a vida ao corpo; e por isso diz a Escritura: Foi jeito o homem em alma vivente, isto é,
que dá vida ao corpo, Mas é espírito pelo que lhe é próprio a si e não aos animais, isto é, ter virtude
intelectiva imaterial. Por onde, no primeiro estado, o que a alma tinha como alma, era comum com o
corpo, e, por ter a vida, da alma, é que o sobredito corpo chamava–se animal. Ora, o princípio primeiro
da vida, nos seres inferiores, é como diz Aristóteles, a alma vegetal, cujas operações são: usar de
alimento, gerar e crescer. Por onde, tais operações cabiam ao homem, no primeiro estado. No último
estado, porém, depois da ressurreição, a alma comunicará de certo modo ao corpo o que lhe é próprio
como espírito, a saber: a imortalidade, a todos; a impassibilidade, a glória e a virtude, só aos bons, cujos
corpos serão chamados espirituais. E por isso depois da ressurreição os homens não precisarão de
alimentos; mas no estado de inocência precisavam.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Segundo diz Agostinho, como havia de ler corpo imortal,
o que se sustentava de alimento? Pois, o que é imortal não necessita comer nem beber. Porque como já
se disse antes, a imortalidade do primeiro estado era quanto a uma virtude sobrenatural residente na
alma, e não quanto a qualquer disposição inerente ao corpo. Por onde, pela ação do calor, podia
perder–se alguma umidade, do referido corpo; e para que não se consumisse totalmente, era necessário
que o homem se restaurasse, alimentando–se.

RESPOSTA À SEGUNDA. – Há por certo na nutrição, paixão e alteração; mas relativamente ao alimento,
que se converte na substância do ser alimentado. Por onde, não se pode daí concluir que o corpo do
homem fosse passível, mas sim, que o era o alimento tomado; embora tal paixão fosse para a perfeição
da natureza.

RESPOSTA À TERCEIRA. – Se o homem não buscasse alimento para si, pecaria; assim como pecou
tomando do alimento proibido. Pois, simultaneamente lhe foi preceituado se abstivesse da árvore da
ciência do bem e do mal e se alimentasse de todas as outras árvores do paraíso.

RESPOSTA À QUARTA. – Uns dizem que o homem, no estado de inocência não se alimentaria senão na
medida do necessário. E por isso não haveria emissão de superfluidades. Mas é irracional que não
houvesse, no alimento tomado, partes inúteis, e não aptas a se converterem em nutrição do homem.
Por onde necessariamente haveriam de ser emitidas superfluidades. Contudo, por provisão divina, daí
não resultaria nenhuma indecência.

## Art. 4 — Se a árvore da vida podia ser causa de imortalidade.
O quarto discute–se assim. – Parece que a árvore da vida não podia ser causa da imortalidade.

1. – Pois, nada pode atuar além do que lhe permite a espécie, o efeito não podendo exceder à causa.
Ora, a árvore da vida era corruptível; do contrário não podia ser tomada como alimento pois que este,
como já se disse, se converte na substância do ser nutrido. Logo, a árvore da vida não podia conferir a
incorruptibilidade ou imortalidade.

2. Demais. – Os efeitos causados pelas virtudes das plantas e dos outros seres da natureza são naturais.
Se pois a árvore da vida causasse a imortalidade, esta seria natural.

3. Demais. – Tal imortalidade viria a se confundir com as fábulas dos antigos ridicularizados pelo
Filósofo, que diziam tornarem–se imortais os deuses que comiam de certo alimento.
Mas, em contrário, diz a Escritura: Para que não suceda que ele lance a sua mão e tome também da
árvore da vida, e coma e viva eternamente.

DEMAIS. – Agostinho diz: O fato de comer da árvore da vida impediria a corrupção do corpo; e por isso
este, ainda depois do pecado, podia permanecer indissolúvel se lhe fosse logo permitido comer da
sobredita árvore.

SOLUÇÃO. – A árvore da vida causava a imortalidade, não absolutamente, mas de certo modo. Para a
evidência do que devemos considerar que o homem, no primeiro estado, tinha, para a conservação da
vida, dois remédios contrários a duas deficiências. – Destas, a primeira é a perda da umidade por ação
do calor natural, instrumento da alma. E essa deficiência o homem a eliminaria comendo das outras
árvores do paraíso, como agora a eliminamos pelos alimentos que tomamos. – A segunda deficiência
vem, como diz o Filósofo, de que, o assimilado de um corpo estranho, e acrescentado à umidade
preexistente diminui a virtude ativa da espécie. Assim, a água acrescentada ao vinho, primeiro
converte–se no sabor deste; mas quanto mais for acrescentada tanto mais diminui a fortidão do vinho,
até que enfim este se torna aquoso. Pois do mesmo modo, vemos que, no princípio, a virtude ativa da
espécie é de tal modo forte, que pode tirar do alimento não só o que lhe basta para a restauração do
perdido, mas também o suficiente para o crescimento. Porém depois o assimilado não basta para o
crescimento; mas só para a restauração do perdido. E por fim, na idade da velhice, nem para isso basta,·
donde vem o decremento e finalmente a dissolução do corpo. Ora, essa deficiência o homem a
eliminava pela árvore da vida, que ti ilha a virtude de fortificar a espécie contra a debilidade proveniente
da imissão de elementos estranhos. E por isso diz Agostinho: o homem tomava do alimento para que
não tivesse fome; da bebida, para que não tivesse sede; da árvore da vida, para que a velhice não o
dissolvesse, E ainda: a árvore da vida, ao modo de remédio, impedia qualquer corrupção.
Mas, nem por isso causava, absolutamente a imortalidade. Porque, nem a virtude inerente à alma, para
a conservação do corpo, era causada pela árvore –da vida; nem também a imortalidade podia causar
uma disposição tal ao corpo, que este nunca viesse a dissolver–se. E isso resulta claro de ser finita a
virtude de todos os corpos. Pois, a virtude da árvore da vida não podia chegar até dar ao corpo a virtude
de durar por tempo infinito, senão só por determinado tempo. Porquanto é manifesto que quanto
maior é uma virtude tanto mais durável efeito influi. Por onde, sendo finita a virtude da árvore da vida,
preservava, uma vez que dela se comesse, da corrupção, por determinado tempo, acabado o qual o
homem, ou seria transferido para a vida espiritual, ou precisaria, de novo comer da sobredita árvore.
E daqui se deduzem as RESPOSTAS ÀS OBJEÇÕES. – Pois, as primeiras concluem que a árvore da vida
não causava a incorruptibilidade, absolutamente. – Enquanto as outras concluem que a causava,
impedindo a corrupção, ao modo predito.