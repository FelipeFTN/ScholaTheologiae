# Questão 3: Da simplicidade de Deus
Conhecida a existência de uma coisa, resta inquirir como existe, para que se saiba o que é. Porém, como
não podemos saber o que é Deus, mas o que não é, não podemos considerar como é, mas, como não é.
Logo, 1o. consideraremos como não é; 2o. como é de nós conhecido; 3o. como se nomeia.
Ora, podemos mostrar como Deus não é removendo o que lhe não convém, p. ex.: a composição, o
movimento, e atributos semelhantes.
Portanto, 1o. devemos tratar da sua simplicidade, pela qual dele se remove a composição. E sendo os
seres corpóreos simples, imperfeitos e partes, devemos tratar, 2 o. da perfeição de Deus; 3 o. da sua
infinidade; 4 o. da sua imutabilidade; 5 o. da sua unidade.
Na primeira questão, discutem-se oito artigos:

## Art. 1 — Se Deus é corpo.
(Cont. Gent. I, 20; II, 3; compend. Theol., c. 16.)
O primeiro discute-se assim — Parece que Deus é corpo.1. Pois, corpo é o que tem três dimensões.
Ora, a Sagrada Escritura atribui a Deus dimensão tríplice, dizendo (Jó 11,8-9): Ele é mais elevado que o
céu, e que farás tu? E mais profundo do que o inferno, e como o conhecerás? A sua medida é mais
comprida do que a terra e mais longa que o mar. Logo, Deus é corpo.

2. Demais — Todo figurado é corpo, pois a figura é qualidade quantitativa. Ora, Deus é figurado, como
escreve a Escritura (Gn I, 26): Façamos o homem à nossa imagem e semelhança; e a figura se chama
imagem, segundoo Apóstolo (Heb I, 3): sendo o resplendor da glória e a figura da sua substância, i. é, a
imagem. Logo, Deus é corpo.

3. Demais. — Tudo o que tem partes corpóreas é corpo. Ora, a Escritura as atribui a Deus: Se tu tens
braços como Deus (Jó 40, 4); e a destra do Senhor fez proezas (Sl 33, 16); e os olhos do Senhor estão
sobre os justos (Sl 117, 16). Logo, Deus é corpo.

4. Demais. — O corpo tem situação. Ora, o que se diz desta, a Escritura diz de Deus: Vi ao Senhor
assentado(Is 6,1); e o Senhor está para julgar (Is 3, 13). Logo, Deus é corpo.

5. Demais. — Nada pode significar lugar donde ou para onde, sem ser corpo ou algo de corpóreo. Ora,
na Escritura, Deus é denominado termo local para onde (Sl 33, 6): Chegai-vos a ele e sereis iluminados; e
donde (Jr 17, 13): Os que se apartam de ti serão escritos sobre a terra. Logo, Deus é corpo.
Mas, em contrário, diz a Escritura (Jo 4, 24): Deus é espírito.

SOLUÇÃO. — Que, absolutamente, Deus não é corpo, pode-se demonstrar de três modos: Primeiro,
porque nenhum corpo move sem ser movido, como claramente se induz dos casos singulares. Ora, já se
demonstrou ser Deus o primeiro motor imóvel . Logo, é manifesto que não é corpo; Segundo, porque é
necessário que o ser primeiro exista em ato e de nenhum modo em potência. Pois, embora num mesmo
ser, que passa da potência para o ato, aquela seja, temporalmente, anterior a este, em si, contudo, o ato
é anterior à potência, porque o potencial não se atualiza senão pelo atual. Ora, como se demonstrou,
Deus é o ente primeiro; logo, é impossível existir nele algo de potencial. E, sendo todo corpo potencial,
porque o contínuo, como tal é divisível ao infinito, é impossível Deus ser Corpo; Terceiro, porque Deus é
o mais nobre dos seres, como do sobredito resulta. Ora, é impossível um corpo ser tal, porque todo o
corpo é vivo ou não vivo. Se vivo, é manifestamente mais nobre que o não vivo; não vivendo, porém,
enquanto corpo — porque então todo corpo viveria — necessariamente há-de viver por outro princípio;
assim o nosso corpo vive pela alma. Ora, o princípio da vida do corpo é mais nobre que este. Logo, é
impossível Deus ser corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — como já se disse, a Sagrada Escritura nos transmite as
coisas espirituais e divinas comparando-as com as corpóreas. Assim, quando atribui a Deus dimensão
tríplice, designa-lhe a quantidade virtual, por comparação com a quantidade corpórea; com a
profundidade atribuí-lhe a virtude de conhecer as coisas ocultas; com a altitude, a excelência da sua
virtude sobre todos os seres; com a longitude, a duração do seu ser; com a latitude, o afeto de dileção
para com todos. — Ou, como diz Dionísio,pela profundidade de Deus se lhe intelige a
incompreensibilidade da essência; pela longitude, o processo da virtude que tudo penetra; e pela
latitude, a sua superextensão sobre os seres enquanto todos caem sob a sua proteção.

RESPOSTA À SEGUNDA. — O homem é considerado imagem de Deus, não pelo corpo, mas pelo que o
torna mais excelente que os outros animais; por isso a Escritura, depois de ter dito (Gn I,
26): Façamos o homem à nossa imagem e semelhança, acrescenta: O qual presida aos peixes do
mar, etc. Ora, o homem é mais excelente que todos os animais, pela razão e pelo intelecto. Donde, pelo
intelecto e pela razão, que são incorpóreos, é a imagem de Deus.

RESPOSTA À TERCEIRA. — A Escritura atribui a Deus partes corpóreas, em razão de seus atos, por uma
certa semelhança. Pois, assim como o ato dos olhos é ver, atribuem-se olhos a Deus, para lhe significar a
virtude visual, inteligível e não, sensivelmente, E assim, simultaneamente, em relação às outras partes.

RESPOSTA À QUARTA. — Mesmo o que é próprio da situação não se atribui a Deus, senão por
semelhança; assim, diz-se que se assenta, por causa da imobilidade e autoridade; e que está de pé por
causa da força em debelar tudo o que se lhe opõe.

RESPOSTA À QUINTA. — Não nos aproximamos de Deus com passos corpóreos, pois, está em toda
parte; mas, com afetos mentais: e do mesmo modo, dele nos afastamos. E assim, o aproximar-se e o
afastar-se, à semelhança com o movimento local, designam o afeto espiritual.

## Art. 2 — Se em Deus há composição de matéria e forma.
(I Sent., dist. 35, a. 1; Cont. Gent. I, I, 17; Compend. Theol., c. 28)
O segundo discute-se assim. — Parece que há em Deus composição de forma e matéria.

1. — Pois, sendo a alma a forma do corpo, tudo o que tem alma é composto de
matéria e forma. Ora, a Escritura atribui a alma a Deus, quando o Apóstolo, falando da pessoa divina, diz
(Heb 10, 38): Mas o meu justo vive de fé; porém, se ele se apartar, não agradará à minha alma. Logo,
Deus é composto de matéria e forma.

2. Demais. — A ira, a alegria e paixões tais são próprias do composto, diz o Filósofo. Ora, a Escritura
atribui a Deus todas as paixões (Sl 105, 40): E se acendeu de furor o Senhor contra o seu povo. Logo,
Deus é composto de matéria e forma.

3. Demais. — A matéria é o princípio da individuação. Ora, parece que Deus é um indivíduo: pois, não se
predica de muitos. Logo, é composto de matéria e forma.
Mas, em contrário, todo composto de matéria e forma é corpo; pois, a quantidade dimensiva é a
primeira inerente à matéria. Ora, Deus não é corpo, como se demonstrou. Logo, não é composto de
matéria e forma.

SOLUÇÃO. — É impossível haver matéria em Deus. Primeiro, porque esta é potencial. Ora, como
demonstramos, Deus é ato puro, sem nenhuma potencialidade. Logo, é impossível ser composto de
matéria e forma. Segundo, por ser a forma a causa da bondade de todo composto em que ela concorre
com a matéria; o qual, por isso, e necessariamente, é bom por participação, na medida em que a
matéria participa da forma. Ora, Deus, ser primariamente bom e ótimo, não é bom por participação,
porque o bem essencial é anterior ao participado. Terceiro, porque todo agente age pela sua forma e,
portanto, esta é que determina o modo de ser daquele. Ora, o ser que é agente primária e
essencialmente há de, por força, ser também forma, essencial e primariamente. Mas, Deus é o agente
primeiro, por ser causa eficiente primeira, como já demonstramos. Logo, é essencialmente a sua forma
e não é composto de matéria e forma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A alma é atribuída a Deus por semelhança no agir. Pois,
como pela nossa alma é que queremos alguma coisa, assim, consideramos agradável à alma de Deus o
que lho é à vontade.

RESPOSTA À SEGUNDA. — A ira e outras paixões se atribuem a Deus por semelhança de efeito; pois,
sendo próprio do irado punir, à ira de Deus se chama punição, metaforicamente.

RESPOSTA À TERCEIRA. — As formas de que a matéria é susceptível, por ela se individuam; a qual, por
sua vez, não pode existir em outro ser, porque é o sujeito primeiro. Porém, a forma, em si mesma, e se
nada o impedir, pode ser recebida por muitos sujeitos. Mas, a forma que não puder ser recebida pela
matéria, e for subsistente por si mesma, individua-se pelo fato mesmo de não poder ser recebida. Ora,
tal é a forma de Deus. Logo, daí se não segue que ele tenha matéria.

## Art. 3 — Se Deus é idêntico à sua essência ou natureza.
(I Set., dist. 34, q. 1, a. 1; Cont. Gent. I, 21; Qq. Disp. De Un. Verb., a. 1; de Anima, a. 17, ad 10; Quodlib.

II, q. 2, a. 2; Compend. Theol., c. 10; Opusc. XXXVII, de Quattuor Oppos., c. 4)
O terceiro discute-se assim. — Parece que Deus não é idêntico à sua essência ou natureza.

1. — Pois, nada pode estar em si mesmo. Ora, diz-se que a essência ou a natureza de Deus, que é a
divindade, está em Deus. Logo, Deus não é idêntico à sua essência ou natureza.

2. Demais. — O efeito assimila-se à causa, porque todo agente, como é, assim age. Ora, nos seres
criados, não se identificam o suposto e a sua natureza; assim, o homem não é o mesmo que a
humanidade. Logo, nem Deus é idêntico à divindade.
Mas, em contrário. — Dizemos que Deus não somente é vivo, mas, que é a vida, como o faz a Escritura
(Jo 14, 6): Eu sou o caminho, a verdade e a vida. Ora, a vida está para o vivente como a deidade, para
Deus. Logo, Deus é a própria divindade.

SOLUÇÃO. — Para entendermos que Deus é idêntico à sua essência ou natureza, é preciso saber que,
nos seres compostos de matéria e forma, necessariamente diferem entre si a natureza, a essência e o
suposto, Pois, a essência ou natureza, em si mesma, compreende somente o que entra na definição da
espécie. Assim, ahumanidade, em si mesma, compreende o que constitui a definição do homem e faz
com que este seja o que é. A humanidade é, pois, o que faz o homem ser homem. Mas, a matéria
individual, com todos os acidentes individuantes, não entra na definição da espécie; assim, a definição
do homem não implica que ele tenha tais carnes e tais ossos, tal brancura e tal negrura, ou atributos
semelhantes. Por isso, tais carnes e tais ossos, bem como os acidentes designativos de uma
determinada matéria, não se incluem na humanidade. E, contudo, incluindo-se no ser humano, este
encerra em si algo que não encerra a humanidade. Por onde, não são totalmente idênticos o homem e a
humanidade: esta constitui como que a parte formal daquele, pois os princípios definidores
desempenham o papel de forma, relativamente à matéria individuante. Ora, a individuação dos seres
não compostos de matéria e forma não se opera pela matéria individual, i. é, por uma determinada
matéria, mas antes, as próprias formas por si se individuam. Por onde, em tais seres, essas formas
mesmas é que hão de, necessariamente ser os supostos subsistentes, não diferindo, por isso, o suposto,
da natureza. E, como já demonstramos, não sendo Deus composto de matéria e forma, há de por força
ser a sua divindade, a sua vida e o mais que dele se predicar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não podemos dizer nada dos seres simples, senão
comparando-os com os compostos, de que temos conhecimento. Por isso, tratando de Deus, usamos de
palavras concretas para lhe exprimirmos a subsistência, porque, para nós, só os compostos subsistem; e
empregamos nomes abstratos para lhe significarmos a simplicidade. Quando, pois, atribuímos a Deus a
divindade, a vida ou outro atributo qualquer, essa atribuição deve referir-se à diversidade existente na
acepção do nosso intelecto e não, a qualquer diversidade existente em Deus.

RESPOSTA À SEGUNDA. — Os efeitos de Deus o imitam, não perfeitamente, mas na medida do possível,
por causa da deficiência na imitação. Pois, o ser simples e uno não pode ser representado senão pelo
múltiplo. Por isso, esses efeitos implicam a composição, donde resulta não terem o suposto idêntico à
natureza.

## Art. 4 — Se em Deus se identificam a essência e a existência.
(I Sent., dist. 8, q. 4, a. 1, 2; q. 5, a. 2; dist. 34, q. 1, a. 1; II dist. 1, q. 1, a. 1; Cont. gent. I, 22, 52; Qq. Disp.,
de Pot., q. 7, a. 2; de Spirit. Creat., a. 1; Compend. Theol., c. 11; Opusc. XXXVII, de Quattuor Oppos., c. 4;
De Ent. Et Ess., c. 5)
O quarto discute-se assim. — Parece que em Deus não se identificam a essência e a existência.

1. — Pois, se assim não fosse, nada se poderia acrescentar ao ser divino. Ora, o ser que não é susceptível
de nenhuma adição é o ser em geral, que se predica de todos; e, portanto, Deus seria tal ser de todos
predicado. Ora; isto é falso, segundo aquilo da Escritura (Sb 14,21): Deram às pedras e ao pau um nome
incomunicável.Logo, a existência de Deus não é idêntica à sua essência.

2. Demais. — Como já se disse, podemos saber se Deus existe, mas não, o que é. Logo, não se
identificam a existência de Deus e a sua essência, quididade ou natureza.
Mas, em contrário, diz Hilário: A existência não é um acidente, em Deus, mas verdade subsistente. Logo,
o que subsiste em Deus é a sua existência.

SOLUÇÃO. — Deus é, não somente, a sua essência, como já demonstramos, mas também a sua
existência, o que se pode provar de muitos modos. Primeiro, porque tudo o que existe num ente, sem
lhe constituir a essência, deve ser causado pelos princípios desta, como acidentes próprios resultantes
da espécie. Assim, a faculdade de rir resulta do ser humano e é causada pelos princípios essenciais da
espécie. Ou, então, deve ser causado por algum ser exterior: assim, o calor da água é causado pelo fogo.
Por onde, sendo a existência mesma do ente diferente da sua essência, é necessário seja essa existência
causada por algum ser exterior, ou pelos princípios essenciais do referido ente. Ora, é impossível seja ela
causada somente pelos princípios essenciais deste, pois, nenhum ente de existência causada é suficiente
para ser causa da sua própria existência. Portanto e necessariamente, o ente cuja existência difere da
essência, há de ter aquela causada por outro ser. Mas, isto não se pode dizer de Deus, pois, já provamos
ser ele a causa eficiente primeira. Logo, é impossível que, em Deus, a existência seja diferente da
essência. Segundo, porque a existência é a atualidade de toda forma ou natureza; assim, a bondade ou a
humanidade não são atuais senão quando as supomos existentes. Necessariamente, pois, a existência
está para a essência, da qual difere, como o ato para a potência. Ora, Deus nada tendo de potencial,
como demonstramos, resulta que a sua essência não difere da sua existência e, portanto, são idênticas.
Terceiro, porque, assim como o que tem fogo, sem ser fogo, é ígneo por participação, assim também o
que existe, sem ser a existência, existe por participação. Ora, como já estabelecemos, Deus é a sua
essência. Se, portanto, não for a sua existência, será ser por participação e não, por essência. Logo, não
será o ser primeiro, o que é absurdo. Por conseqüência, Deus é a sua existência e não somente, a sua
essência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A expressão — ser que não é susceptível de nenhuma
adição — pode ser entendida em duplo sentido. Ou porque é tal que, por natureza, não se lhe pode
adicionar nada, como se dá com o animal irracional, que, por natureza, não pode ter razão; ou porque a
sua essência não comporta nenhuma adição, como é o caso do animal em geral, que, por essência,
sendo desprovido de razão, não a comporta, sem que, por outro lado essa essência exija que seja
privado dela.
Ora, no primeiro sentido é o ser divino que não é susceptível de adição; e no segundo, o ser em geral.

RESPOSTA À SEGUNDA. — O vocábulo ser é susceptível de duplo sentido. Ora significa o ato de existir;
ora a composição proposicional, que o espírito descobre quando une o predicado ao sujeito. Na
primeira acepção, não podemos conhecer a existência de Deus nem a sua essência, mas só na segunda.
Pois, sabemos que a proposição que formamos sobre Deus, quando dizemos —Deus existe — é
verdadeira; e isto sabemos pelos efeitos de Deus, como já dissemos.

## Art. 5 — Se Deus pertence a algum gênero.
(I Sent., dist. 8, q. 4, a. 2; dist. 19, q. 4, a. 2; Cont. Gent. I, 25; De Pot., q. 7, a. 3; Compend. Theol., c. 12;
De Ent. Et Ess., c. 6)
O quinto discute-se assim. — Parece que Deus pertence a algum gênero.

1. — Pois, substância é o ser por si subsistente, o que é por excelência próprio de Deus. Logo, Deus
pertence ao gênero da substância.

2. Demais. — Uma coisa mede-se pela sua congênere, como as longitudes, pela longitude e os números,
pelo número. Ora, Deus é a medida de todas as substâncias, como o diz o Comentador. Logo, Deus
pertence ao gênero da substância.
Mas, em contrário, o gênero é, racionalmente, anterior ao seu conteúdo. Ora, nada é anterior a Deus,
nem material nem racionalmente. Logo, não pertence a nenhum gênero.

SOLUÇÃO. — De dois modos uma coisa pode pertencer a um gênero: absoluta e propriamente, como as
espécies, que ele abrange; ou por via de redução, como os princípios e as privações. Assim, o ponto e a
unidade se reduzem ao gênero da quantidade, como princípios; a cegueira, como toda privação, ao
gênero do seu hábito. — Ora, de nenhum desses modos Deus pertence a um gênero. E, por outro lado,
que não pode ser espécie de nenhum, de três modos pode ser demonstrado. Primeiro, porque uma
espécie é constituída pelo seu gênero e pela sua diferença; e sempre a origem da diferença constitutiva
da espécie está para a origem do gênero, como o ato, para a potência. Assim, animal deriva da natureza
sensitiva, por concreção; pois, chama-se animal o ser dessa natureza sensitiva. Racional, por seu lado,
deriva da natureza intelectiva, pois racional é o ser que tem essa natureza. Ora, intelectivo está para
sensitivo como o ato, para a potência, o mesmo se dando em casos semelhantes. Ora, como em Deus
nenhuma potência vem acrescentar-se ao ato, impossível é que seja espécie de qualquer gênero.
Segundo, porque sendo a existência a essência de Deus, como já demonstramos, se Deus pertencesse a
algum gênero, este seria necessariamente o do ser, pois o gênero exprime a essência de uma coisa e
predica o que a coisa é. Ora, como o Filósofo o demonstra, o ser não pode constituir gênero de nada;
pois, todo gênero implica diferenças estranhas à sua essência. E não é possível descobrir nenhuma
diferença exterior ao ser, visto que não pode o não-ser diferenciar nada. Donde resulta que Deus não
pertence a nenhum gênero. Terceiro, porque todas as coisas pertencentes a um mesmo gênero devem
ter também a mesma quididade ou essência genérica, que lhes é atribuída por atribuição essencial. Mas
diferem pela existência; assim, não é a mesma a existência do homem e a do cavalo, nem a de tal
homem e a de tal outro. Por onde é necessário que, em todas as coisas de um mesmo gênero, difira a
existência da quididade ouessência. Ora, em Deus não há tal diferença, como já demonstramos.
Portanto, é manifesto que Deus não pertence especificamente a nenhum gênero. Donde resulta que
não tem gênero, nem diferenças, nem definição, nem demonstração — salvo pelo efeito; porque a
definição consta de gênero e diferença e é o meio para chegar à demonstração. — E também é claro
que Deus não se inclui em nenhum gênero, como princípio, por via de redução. Pois, o principio
redutível a um gênero não pode estender-se além desse gênero. Assim, o ponto só é princípio da
quantidade contínua, e a unidade, da discreta. Ora, Deus é o princípio de todos os seres, como a seguir
se demonstrará. Logo, não está contido em nenhum gênero, como em princípio.

DONDE A RESPOSTA A PRIMEIRA OBJEÇÃO. — O nome de substância não significa somente o que
subsiste por si, porque o ser em si mesmo não é gênero, como demonstramos. Mas, significa a essência,
à qual convém existir desse modo, i. é, por si mesma; sem que isso, porém, lhe constitua a essência
própria. Por onde, é claro que Deus não está incluído no gênero da substância.

RESPOSTA À SEGUNDA. — A objeção colhe quanto à medida proporcionada, pois esta há de,
necessariamente, ser homogênea com o que mede. Ora, Deus não é medida proporcionada a nenhum
ser; mas é considerado como medida de todos, porque cada um existe enquanto dele se aproxima.

## Art. 6 — Se em Deus há acidentes.
(I Sent., dist. 8, q. 4, a. 3; Cont. Gent. I, 23; De Pot., q. 7, a. 4; Compend. Theol., c. 23.)
O sexto discute-se assim. Parece que em Deus há acidentes.

1. — Pois, a substância em nenhum ser é acidente. Ora, o que num é acidente não pode ser substância
em outro. Assim, prova-se que o calor, sendo acidente em outros seres, não pode ser a forma
substancial do fogo. Ora, a sabedoria, a virtude e qualidades semelhantes, que são acidentes em nós,
atribuem-se a Deus. Logo, há nele acidentes.

2. Demais. — Em cada gênero há um primeiro termo. Ora, muitos são os gêneros de acidentes. Se,
portanto, os termos primeiros desses gêneros não existem em Deus, haverá muitos seres primeiros
além de Deus, o que é inadmissível.
Mas, em contrário, todo acidente existe num sujeito. Ora, Deus não pode ser sujeito, porque não pode
sê-lo a forma simples, como diz Boécio. Logo, não há nele acidentes.

SOLUÇÃO. — Do que dissemos, claramente resulta que, em Deus, não pode haver acidentes. —
Primeiro, porque o sujeito está para o acidente como a potência para o ato; pois, em relação ao
acidente, o sujeito é, de certo modo, atual. Ora, em Deus não há absolutamente nada de potencial,
conforme se conclui do que já dissemos.
Segundo, porque Deus é o seu ser. Ora, como diz Boécio, embora o que existe seja susceptível de
acréscimo, contudo, o ser em si de nenhum modo o é. Assim, um corpo cálido pode ter algo de estranho
à calidez, como a brancura; mas, no calor mesmo, nada mais há além dele próprio.
Terceiro, porque tudo o que existe por si mesmo é anterior ao que tem existência acidental. Donde,
sendo Deus o ser absolutamente primeiro, nada pode ter de acidental; nem mesmo os acidentes
próprios, — como o de risível, no homem — podem nele existir. Porque todos os acidentes são
causados pelos princípios do sujeito, e, em Deus, causa primeira, nada pode ser causado. Donde se
conclui, que em Deus, não há nenhum acidente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A virtude e a sabedoria não se atribuem univocamente a
Deus e a nós, como a seguir se dirá. — Donde se não segue que os acidentes existam em Deus como em
nós.

RESPOSTA À SEGUNDA. — Sendo a substância anterior aos acidentes, os princípios destes se reduzem
aos daquela, como ao que lhes é anterior. Mas, para que todos os seres dependam de Deus, não é
necessário que ele seja o primeiro no gênero da substância, senão, o primeiro, fora de todo gênero,
relativamente ao ser total.

## Art. 7 — Se Deus é absolutamente simples.
(I Sent., dist. 8, q. 4, a. 1; Cont. Gent. I, 16, 18; De Pot., q. 7, a. 1; Compend. Theol., c. 9; Opusc. XXXVII,
de Quattuor Oppos., c. 4; De Caus., lect. 21)
O sétimo discute-se assim. — Parece que Deus não é absolutamente simples.

1. — Pois, como o que provém de Deus o imita, do ser primeiro procedem todos os outros e, do bem
primeiro, todos os bens. Ora, dos seres provenientes de Deus nenhum é absolutamente simples. Logo,
também não o é Deus.

2. Demais. — Tudo o que há de melhor deve ser atribuído a Deus. Ora, para nós, o composto é melhor
que o simples; assim, os corpos mistos são melhores que os elementos e estes, que as suas partes. Logo,
não devemos dizer que Deus é absolutamente simples.
Mas, em contrário, como diz Agostinho, Deus é verdadeira e sumamente simples.

SOLUÇÃO. — De muitos modos podemos provar que Deus é absolutamente simples. Primeiro, pelo que
já dissemos. Pois, não havendo em Deus composição de partes quantitativas, por não ser corpo, nem de
forma e matéria; nem havendo nele, diferença entre a natureza e o suposto; nem composição de
gêneros e diferenças; nem de sujeito e acidentes, é claro que Deus de nenhum modo é composto, mas
absolutamente simples. Segundo, porque todo composto é posterior aos seus componentes, dos quais
depende. Ora, Deus é o ser primeiro, como já demonstramos. Terceiro, porque todo composto terá
causa; pois, coisas entre si diversas não se reduzem à unidade, senão por um princípio que as unifique.
Ora, Deus não tem causa, como já demonstramos, por ser a causa eficiente primeira. Quarto, em todo
composto deve haver potência e ato, que não existem em Deus; pois das partes, uma haveria de ser ato
da outra, ou, pelo menos, todas seriam como que potências em relação ao todo. Quinto, porque
nenhum composto se identifica com qualquer das suas partes, como manifestamente se dá num todo
de partes dessemelhantes. Assim, nenhuma das suas partes é o homem, como não é o pé nenhuma das
partes deste. Quanto a um todo de partes dessemelhantes, embora algumas atribuições do todo
também o sejam das partes — p. ex., qualquer parte do ar ou da água é ar ou água — contudo há
atribuições do todo que não convêm às partes — p. ex., por ter uma quantidade de água dois côvados,
não há de tê-los também cada uma das suas partes. Logo, todo composto tem alguma coisa que dele
difere. E embora se possa dizer que também no ser que tem forma há algo que dele difere, p. ex., no
branco há algo que lhe não pertence à essência — contudo nada há na forma mesma que lhe seja
alheio. Por onde, sendo Deus a forma pura, ou antes o ser em si mesmo, de nenhum modo pode ser
composto. E a esta razão alude Hilário quando diz: Deus, sendo o poder, não tem fraquezas; nem sendo
luz, consta de trevas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os seres provenientes de Deus o imitam, como os seres
causados imitam a causa primeira. Pois, da natureza do causado é, de certo modo, ser composto,
porque o seu ser é, pelo menos, diverso da sua quididade, como a seguir se verá.

RESPOSTA À SEGUNDA. — Para nós, os seres compostos são melhores que os simples, porque a
perfeição da bondade da criatura não se encontra no simples, mas no múltiplo. Ao contrário, a perfeição
da divina bondade está na simplicidade, como a seguir se verá.

## Art. 8 — Se Deus entra na composição dos outros seres.
(I Sent., dist. 8, q. 1, a. 2; Cont. Gent., I, 17, 26, 27; III, 51; de Pot., q. 6, a. 6; De Verit., q. 21, a. 4)
O oitavo discute-se assim. — Parece que Deus entra na composição dos outros seres.

1. — Pois, Dionísio diz: Ser de todas as coisas é o que, além de existir, é a divindade. Ora, tal ser entra na
composição do ser individual. Logo, Deus entra na composição dos outros seres.

2. Demais. — Deus é forma, como o diz Agostinho: O verbo de Deus (que é Deus) é forma não
informada. Ora, a forma faz parte do composto. Logo, Deus é parte dos seres compostos.

3. Demais. — Coisas que existem e de nenhum modo diferem são idênticas. Ora, Deus e a matéria
prima, em nada diferindo entre si, são absolutamente idênticos. Mas, como a matéria prima entra na
composição de todos os seres, o mesmo há de dar-se com Deus. — Prova da média. Seres diferentes
hão de diferir por certas diferenças; logo, hão de necessariamente ser compostos. Ora, Deus e a matéria
prima são absolutamente simples; portanto, de nenhum modo diferem.
Mas, em contrário, Dionísio: Não há nele (em Deus) contacto nem qualquer comunhão por onde vá de
mistura com partes.

SOLUÇÃO. — Três erros se cometeram neste assunto. Uns ensinaram ser Deus a alma do mundo, como
se lê em Agostinho; e a ele se reduzem os que disseram ser Deus a alma do primeiro céu. — Outros,
porém, afirmaram ser ele o principio formal de todas as coisas, e tal se diz ter sido a opinião dos
Almarianos. — E o terceiro erro foi o de Davi de Dinant, concebendo estultissimamente Deus como
matéria prima. — Ora, todas estas doutrinas são falsas, pois de nenhum modo é possível que Deus entre
na composição de qualquer ser, nem como princípio formal, nem como material. — Primeiro, porque,
consoante ficou dito, Deus é a causa eficiente primeira. Ora, a causa eficiente não coincide
numericamente com a forma de seu efeito, mas só especificamente; assim, um homem gera outro. A
matéria, porém, não coincide com a causa eficiente, nem numérica nem especificamente, pois é
potencial, e esta atual. — Segundo, porque sendo Deus a causa eficiente primeira, é-lhe próprio,
primária e essencialmente o agir. Ora, o que faz parte da composição de um ser não é agente primário e
essencial; pois é, antes, o composto que age. Assim, não é a mão que age, mas, o homem, por meio
dela; e o fogo aquece pelo calor. Logo, Deus não pode fazer parte de nenhum composto. — Terceiro,
porque nenhuma parte do composto pode ser, absolutamente, a primeira entre os seres; nem,
portanto, a matéria e a forma que são as partes primeiras dos compostos. Pois, aquela é potencial, e a
potência é, em si mesma, posterior ao ato, como do sobredito resulta. A forma, por seu lado, como
parte do composto, é participada. Ora, como o participante é posterior ao ser que existe por essência,
assim também o é o próprio participado. P. ex., o fogo, matéria ígnea, é posterior, ao que é fogo por
essência. Ora, já demonstramos que Deus é o ser absolutamente primeiro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A divindade é chamada ser de todos os seres, efetiva e
exemplarmente, e não, por essência.

RESPOSTA A SEGUNDA. — O verbo é forma exemplar; mas não é forma como parte de um composto.

RESPOSTA À TERCEIRA. — Os seres simples, ao contrário dos compostos, não diferem entre si senão
pelo que são. Assim, o homem e o cavalo diferem entre si, por ser aquele racional e este irracional; mas
essas diferenças não mais diferem entre si, por outras. Por onde, em rigor de expressão, não se dirá
propriamente — diferem, mas — são diversos. Pois, segundo o Filósofo, a palavra — diverso — se
emprega em sentido absoluto; ao passo que todo ser diferente de outro, difere por alguma coisa. Por
isso, rigorosamente falando, a matéria prima e Deus não diferem, mas são diversos entre si. Donde, não
se segue que sejam idênticos.