# Questão 9: Da imutabilidade de Deus.
Em seguida devemos tratar da imutabilidade divina e da eternidade divina, que daquela resulta.
Na imutabilidade discutem-se duas questões:

## Art. 1 — Se Deus é absolutamente imutável.
(I Sent., dist. VIII, q. 3, a. 1; I Cont. Gent., cap. XIII, XIV; II, cap. XXV; De Pot., q. 8, a. 1, ad 9; Compend.
Theol., cap. IV; in Boet., De Trin., q. 5, a. 4, ad 2).
O primeiro discute-se assim. — Parece que Deus não é absolutamente imutável.

1. — Pois, tudo o que se move a si mesmo é, de certo modo, mutável. Ora, diz Agostinho: O espírito
criador move-se a si mesmo não, porém, temporal e localmente. Logo, Deus é de certo modo mutável.

2. Demais. — A Escritura diz (Sb 7, 24), que a sabedoria é mais ágil do que todo o movimento. Ora, Deus
é sabedoria mesma. Logo, é mutável.

3. Demais. — Aproximar-se e afastar-se implicam movimento. Ora, a Escritura diz de Deus (Tg 4,
8): Chegai-vos para Deus e ele se chegará para vós. Logo, Deus é mutável.
Mas, em contrário, diz a mesma Escritura (Ml 3, 6): Porque eu sou o Senhor, e não mudo.

SOLUÇÃO. — Do que já foi estabelecido resulta a imutabilidade de Deus. — Primeiro, porque como já se
demonstrou, há um ser primeiro chamado Deus, ato puro, necessariamente, sem nenhuma mistura de
potência, pois que esta é em si posterior ao ato. Ora, tudo o que muda, de qualquer modo, é, de certa
maneira, potencial. Logo, é impossível que Deus seja mutável, de qualquer modo.
Segundo, porque de todo movido há algo que permanece e algo que se modifica: assim o que se move
da brancura para negrura permanece pela substância; de maneira que todo ser movido implica uma
composição. Ora, como já demonstramos, Deus, absolutamente simples, não tem nenhuma
composição. Logo, é claro que não pode sofrer nenhuma mudança.
Terceiro, porque todo ser movido adquire, pelo seu movimento, algo que não possuía, e atinge o que
primeiro não atingia. Ora, Deus, sendo infinito, compreendendo em si a plenitude da perfeição da
totalidade do ser, nada pode adquirir, e nem atingir nada que antes não atingisse. Logo, de nenhum
modo é suscetível de movimento. E por isso certos antigos, quase arrastados por essa verdade,
ensinaram que o princípio primeiro é imóvel.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — No passo aduzido, Agostinho se exprime ao modo de
Platão, cuja doutrina era que o primeiro móvel se move a si mesmo, denominando movimento toda
operação, no sentido em que são considerados movimentos, também, inteligir, querer e amar. Ora,
como Deus se intelige e ama a si mesmo, diziam que a si mesmo se move. Não, porém, no sentido em
que agora tomamos o movimento e a mutação, a saber, como próprios do ser potencial.

RESPOSTA À SEGUNDA. — É pelas suas participações, que a sabedoria é considerada móvel, enquanto
que a sua semelhança se difunde até aos últimos elementos das coisas. Pois, nada pode existir que não
proceda da divina sapiência por uma certa imitação, como do princípio primeiro eficiente e formal, no
mesmo sentido em que as produções da arte procedem da mente do artista. Assim, pois, dizemos que
há um quase lanço e movimento para as coisas, da divina sapiência, cuja semelhança se infunde
gradualmente, começando pelos seres mais elevados, que dela mais perfeitamente participam, até às
coisas ínfimas, que menos participam; assim como dizemos, que o sol avança até à terra, porque a toca
com os raios da sua luz. E, neste sentido, diz Dionísio:Que toda a derivação pela qual Deus se nos
manifesta, chega até nós pela ação do pai das luzes.

RESPOSTA À TERCEIRA. — As expressões citadas da Escritura são metafóricas. Pois, assim como dizemos
que o sol entra pela casa ou dela sai, porque os seus raios a invadem, assim, dizemos que Deus se
aproxima ou se afasta de nós, na medida em que percebemos a influência ou a deficiência da sua
bondade.

## Art. 2 — Se ser imutável é próprio de Deus.
(Infra, q. 10, a. 3; q. 65, a. 1, ad 1; III, q. 57, a. 1, ad 1; I Sent., dist. VIII, q. 3, a. 2; dist. XIX. q. 5, a. 3; II,
dist. VII, q. 1, a. 1; De Malo, q. 16, a. 2, ad 6; Quodl., X, q. 2).
O segundo discute-se assim. — Parece que ser imutável não é próprio de Deus.

1. — Pois, como diz o Filósofo, existe matéria em todo ser que se move. Ora, há certas substâncias
criadas, como os anjos e as almas, que, na opinião de muitos, não têm matéria. Logo, ser imutável não é
próprio de Deus.

2. Demais. — Tudo o que é movido é levado para um fim. Ora, o ser que já alcançou o fim último não é
mais movido, como é o caso de certas criaturas, p. ex., de todos os bem-aventurados. Logo, certas
criaturas são imóveis.

3. Demais. — Tudo o que é mutável é variável. Ora, as formas são invariáveis, como se lê no livro Dos
seis princípios: A forma consiste na essência simples e invariável. Logo, ser imutável não é próprio só de
Deus.
Mas, em contrário, diz Agostinho: Só Deus é imutável; tudo o que fez é mutável porque veio do nada.

SOLUÇÃO. — Só Deus é absolutamente imutável; toda criatura, pelo contrário, é de certo modo
mutável. — Mas, é preciso saber que um ente pode ser considerado mutável de dois modos: por um
poder de mutação que lhe é inerente, ou em virtude de um poder estranho. Ora, todas as criaturas,
antes de existirem, não eram possíveis em virtude de qualquer poder criado, porque nenhuma criatura
é eterna; mas, só pelo poder de Deus, que podia trazê-las à existência. Ora, da vontade de Deus
depende tanto o dar a existência às coisas, como lhas conservar, pois ele lhes conserva o ser dando-o
continuamente. Por onde, se a elas lhes retirasse a sua ação todas voltariam ao nada, como se lê
claramente em Agostinho. Assim, pois, como no poder do Criador estavam as coisas antes de existirem
realmente, assim, no mesmo poder está fazer com que não existam, depois de terem existido. Por onde,
pelo poder de um outro ser, Deus, elas são mutáveis porque por ele puderam vir a existir, tiradas do
nada, e podem vir a cair em o não-ser.
Se, porém, considerarmos mutável o ser em virtude de um poder que lhe é inerente, ainda assim, toda
criatura é, de algum modo, mutável. Pois, há na criatura dupla potência, a ativa e a passiva. Pela passiva,
um ser pode conseguir a sua perfeição, existindo ou conseguindo o fim. Se, pois, considerarmos a
mutabilidade de um ser quanto ao poder existir, nem todos implicam a mutabilidade, mas, só aqueles
em que a potencialidade pode coexistir com o não-ser. Por onde, os corpos inferiores implicam a
mutabilidade, tanto pelo ser substancial, porque a matéria deles pode coexistir com a privação da forma
substancial dos mesmos, como pelo ser acidental, se o sujeito for compatível com a privação do
acidente. Assim, o sujeito homem comporta o não ser branco e, portanto, pode mudar-se do branco
para o não branco. Se, porém, o acidente for tal, que resulte dos princípios essenciais do sujeito, a
privação desse acidente não é compatível com a existência do sujeito, e, por isso, não pode variar em
relação a tal acidente; assim, a neve não se pode tornar negra. A matéria dos corpos celestes, porém,
não é compatível com a privação da forma, porque esta esgota, aperfeiçoando o ato, toda a
potencialidade daquela. Por onde, não são mutáveis quanto ao ser substancial, mas, podem mudar de
lugar, porque o sujeito é compatível com a privação de tal lugar ou tal outro. As substâncias incorpóreas,
enfim, formas por si mesmas subsistentes, mas que estão para o ser próprio como a potência para o ato,
não são compatíveis com a privação desse ato, porque a existência, seguindo-se à forma, e só se
corrompendo o que perde a forma, as formas por si mesmas não são suscetíveis potencialmente do
não-ser. Tais substâncias, são portanto, em si mesmas, imutáveis e invariáveis. E é o que diz Dionísio: As
substâncias intelectuais criadas são puras de toda geração e de toda variação, porque são incorpóreas e
imateriais. Entretanto, elas continuam sujeitas à mutabilidade, de dois modos. Primeiro, por serem
potenciais, em relação ao fim, e assim podem, por livre escolha, variar do bem para o mal, como diz
Damasceno. Segundo, localmente, enquanto que, por sua virtude finita, podem atingir certos lugares
que antes não podiam. Ora, tal não se pode dizer de Deus, que enche todos os lugares pela sua
infinidade, como já dissemos.
Assim, pois, toda criatura tem o poder de mudar: ou substancialmente, como os corpos corruptíveis; ou
só localmente, como os corpos celestes; ou pela relação com o fim e pela aplicação da virtude própria a
diversos objetos, como os anjos. E, universalmente, todas as criaturas, em geral, são mutáveis em
relação ao poder do Criador, de quem depende o ser ou o não-ser delas. Ora, como Deus não é mutável
de nenhum desses modos, ele é própria e absolutamente imutável.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procede quanto ao mutável substancial ou
acidentalmente; e de tal movimento trataram os filósofos.

RESPOSTA À SEGUNDA. — Os bons anjos, além da imutabilidade do ser, que por natureza lhes convém,
têm a imutabilidade da escolha, em virtude do poder divino; contudo, neles permanece a mutabilidade
local.

RESPOSTA À TERCEIRA. — As formas são invariáveis no sentido em que não podem ser sujeito de
variação, à qual contudo estão submetidas, enquanto o sujeito muda, justamente em relação a elas. Por
onde, é claro que elas variam, conforme o que são; pois, não são seres, porque são sujeito da existência,
mas por fazerem alguma coisa existir.