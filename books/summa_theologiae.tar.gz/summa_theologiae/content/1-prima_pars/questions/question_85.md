# Questão 85: Do modo e da ordem de inteligir.
Em seguida deve-se considerar o modo e a ordem de inteligir. E, sobre este ponto, oito artigos se
discutem:

## Art. 1 — Se o nosso intelecto intelige as coisas corpóreas e materiais por abstração dos fantasmas.
(Supra, q. 12, a. 4; II Cont. Gent., cap. LXXVII; II Metaphys., lect. 1).
O primeiro discute-se assim. ― Parece que o nosso intelecto não intelige as coisas corpóreas e
materiais, por abstração dos fantasmas.

1. ― Pois, o intelecto que intelige uma coisa diferentemente do que ela é, é falso. Ora, as formas das
coisas materiais não são abstraídas das coisas particulares, cujas semelhanças são os fantasmas. Se,
portanto, inteligimos as coisas materiais abstraindo as espécies, dos fantasmas, haverá falsidade em
nosso intelecto.

2. Demais. ― As coisas materiais são as coisas naturais, em cuja definição entra a matéria. Ora, nada
pode ser inteligido sem aquilo que entra na sua definição. Logo, as coisas materiais não podem ser
inteligidas sem a matéria. Ora, esta é o princípio de individuação. Por onde, as coisas materiais não
podem ser inteligidas, abstraindo o universal do particular, como seria o abstrair as espécies inteligíveis,
dos fantasmas.

3. Demais. ― Os fantasmas estão para a alma intelectiva, como as cores para a vista. Ora, esta não se
exerce abstraindo, das cores, certas espécies, mas pela impressão das cores, na vista. Logo, também o
inteligir não resulta da abstração de alguma coisa, dos fantasmas, mas da impressão destes no intelecto.

4. Demais. ― Há, na alma intelectiva, o intelecto possível e o agente. Ora, é próprio do intelecto
possível, não abstrair, dos fantasmas, as espécies inteligíveis, mas receber as espécies já abstraídas. E
essa abstração, dos fantasmas, também não é própria ao intelecto agente, que está para eles como a luz
para as cores; pois esta não abstrai nada das cores, mas, antes, influi nelas. Logo, de nenhum modo
inteligimos, abstraindo dos fantasmas.

5. Demais. ― O Filósofo diz que o intelecto intelige as espécies nos fantasmas. Logo, não é abstraindo-
as.
Mas, em contrário, na medida em que as coisas são separáveis da matéria, nessa mesma se relacionam
com o intelecto. Logo, é necessário que as coisas materiais sejam inteligidas enquanto abstraídas, tanto
da matéria, como das semelhanças materiais, que são os fantasmas.

SOLUÇÃO. ― Como já se disse antes (q. 84, a. 7), o objeto cognoscível se proporciona à virtude
cognoscitiva. Ora, há tríplice grau nesta virtude. ― Há uma virtude cognoscitiva que é ato de órgão
corpóreo, a saber, do sentido. Por onde, o objeto de qualquer potência sensitiva é a forma, enquanto
existente na matéria corpórea. E como tal matéria é o princípio da individuação, forçosamente toda
potência da parte sensitiva é cognoscitiva só do particular. ― Há, porém, outra virtude cognoscitiva que
nem é ato de órgão corpóreo, nem está, de qualquer modo, conjunta com a matéria corpórea, como o
intelecto dos anjos. Por onde, o objeto desta virtude é a forma subsistente sem a matéria. Pois, embora
conheçam os anjos as coisas materiais, só as vêm no imaterial a saber, em si mesmos ou em Deus. ― O
intelecto humano, porém, ocupa uma posição média. Pois não é ato de nenhum órgão; contudo, é uma
virtude da alma, a qual é forma do corpo, como é claro pelo que já se demonstrou (q. 76, a. 1). Por
onde, é-lhe próprio conhecer a forma, existente, por certo, individualmente, na matéria corpórea, mas
não enquanto existente em tal matéria. Pois, conhecer aquilo que existe na matéria individual, mas não
enquanto está em tal matéria, é abstrair a forma, da matéria individual, representada pelos fantasmas.
Donde é necessário concluir-se que o nosso intelecto intelige as coisas materiais, abstraindo dos
fantasmas; e por essas coisas assim consideradas, chegamos a um certo conhecimento das imateriais;
como, inversamente, os anjos conhecem as coisas materiais pelos seres imateriais. ― Platão, porém,
atendendo só à imaterialidade do intelecto humano e não ao fato de estar unido, de certo modo, a um
corpo, disse que o objeto do intelecto são as idéias separadas; que inteligimos, não, por certo,
abstraindo, mas, antes, participando dos seres abstratos, como se viu antes. (q. 84, a. 1)

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― De dois modos se pode abstrair. De um modo,
compondo e dividindo; assim, quando inteligimos que uma coisa não está em outra ou está separada
desta. De outro, considerando simples e absolutamente; assim, quando inteligimos uma coisa sem
considerar nada de outra. Ora, abstrair, pelo intelecto, causas que na realidade não estão separadas,
conforme o primeiro modo, não vai sem falsidade. Mas nenhuma falsidade há em abstrair, com o
intelecto, ao segundo modo, causas que na realidade, não estão separadas; como se vê
manifestamente, nos sensíveis. Se, pois, inteligirmos ou dissermos que a cor não está no corpo colorido,
ou está deste separada, haverá falsidade na opinião ou na oração. Se, porém, considerarmos a cor e a
sua propriedade, sem considerar nada a respeito do pomo colorido; ou se exprimirmos com palavras o
que inteligimos, não haverá falsidade nem na opinião nem na oração. Pois, o pomo, não fazendo parte
da essência da cor, nada impede inteligir esta, sem inteligir nada daquele. Semelhantemente, digo que o
pertencente à essência da espécie de qualquer causa material, por exemplo, da pedra, do homem ou do
cavalo, pode ser considerado sem os princípios individuais, que não são da essência da espécie. E isto é
abstrair o universal, do particular, ou a espécie inteligível, dos fantasmas; isto é, considerar a natureza,
sem considerar os princípios individuais, representados pelos fantasmas. Por onde, o dizer que o
intelecto é falso quando intelige uma coisa diferentemente do que ela é, é verdade
se diferentemente se referir à coisa inteligida. Pois, falso é o intelecto quando intelige a causa de modo
diferente do que ela é. Assim, seria falso o intelecto se abstraísse, da matéria, a espécie da pedra, de
modo a inteligir que essa espécie não está na matéria, como ensinava Platão. Porém não é verdadeiro
esse dito se diferentemente se referir ao que intelige. Pois, não há falsidade em ser um o modo do
intelecto ao inteligir, e outro o da coisa, enquanto existe; pois, a coisa inteligida está em quem intelige,
imaterialmente, ao modo do intelecto; não porém, materialmente, ao modo da coisa material.

RESPOSTA À SEGUNDA. ― Alguns opinaram que a espécie de uma coisa natural é só a forma, e que a
matéria não faz parte da espécie. Ora, segundo esta opinião, a matéria não entraria nas definições das
coisas naturais. ― E portanto, deve se dizer, de outro modo, que a matéria é dupla: a comum e a
signada ou individual. A comum é, p. ex., a carne e o osso; a individual, estas carnes e estes ossos. Ora, o
intelecto abstrai a espécie de uma coisa natural, da matéria sensível individual, e não da matéria
sensível comum. Assim, abstrai a espécie do homem, de tais carnes e tais ossos determinados, os quais
não sendo da essência da espécie, mas partes do indivíduo, como já se disse, a espécie pode ser
considerada, sem eles. Mas a espécie do homem não pode ser abstraída, pelo intelecto, das carnes e
dos ossos. Ao passo que as espécies matemáticas podem ser abstraídas, pelo intelecto, da matéria
sensível; e não só da individual, mas também da comum; não, porém, da matéria inteligível comum, mas
só da individual. E a matéria sensível é chamada matéria corporal, enquanto está sujeita às qualidades
sensíveis, a saber, a calidez e a frieza a dureza e a moleza e outras; ao passo que a matéria inteligível é
chamada substância, enquanto está sujeita à quantidade. Ora, como é manifesto, a quantidade existe na
substância antes das qualidades sensíveis. Por onde, as quantidades, como os números, as dimensões e
as figuras, que são limites das quantidades, podem ser consideradas sem as qualidades sensíveis; o que
é abstraí-las da matéria sensível. Mas não podem ser consideradas sem o intelecto da substância sujeita
à quantidade; o que seria abstraí-las da matéria inteligível comum. Mas podem ser consideradas sem tal
ou tal substância; o que é abstraí-las da matéria inteligível individual. ― Há porém certas coisas que
podem ser abstraídas mesmo da matéria inteligível comum, como o ente, a unidade a potência e o ato e
outras semelhantes; e essas também podem existir sem nenhuma matéria, como se vê claramente, nas
substâncias imateriais. Ora, como Platão não considerou o que acabamos de dizer sobre o duplo modo
da abstração, ensinou ser separado, na realidade, tudo o que consideramos como abstraído pelo
intelecto.

RESPOSTA À TERCEIRA. ― As cores têm o mesmo modo de existir tanto na matéria corporal individual,
como na potência visiva, e por isso, podem imprimir a sua semelhança na vista. Mas os fantasmas,
sendo semelhanças de indivíduos, e existindo em órgãos corpóreos, não têm o mesmo modo de existir
que tem o intelecto humano, como é claro pelo que já foi dito; e, portanto, não podem, pela sua
virtude, imprimir nada no intelecto possível. Mas, pela virtude do intelecto agente, resulta uma certa
semelhança, no intelecto possível, pela reflexão do intelecto agente sobre os fantasmas, a qual
representa os objetos imaginados, só quanto à natureza da espécie. E deste modo, se diz que a espécie
inteligível é abstraída dos fantasmas; não, porém, que alguma forma, numericamente a mesma,
estivesse, antes, nos fantasmas, e viesse a estar, depois, no intelecto possível, do modo por que um
corpo é tirado de um lugar e transferido para outro.

RESPOSTA À QUARTA. ― Os fantasmas são iluminados pelo intelecto agente; e, depois, por virtude
desse mesmo intelecto, as espécies inteligíveis são abstraídas deles. São, pois, iluminados, porque,
assim como a parte sensitiva, pela união com a intelectiva, torna-se de maior virtude; assim os
fantasmas, por virtude do intelecto agente, tornam-se aptos para que sejam deles abstraídas as
intenções inteligíveis. E, depois, o intelecto agente abstrai, dos fantasmas, as espécies inteligíveis,
enquanto, por virtude desse mesmo intelecto, podemos fazer entrar, em a nossa consideração, as
naturezas das espécies, sem as condições individuais, pelas semelhanças das quais é informado o
intelecto possível.

RESPOSTA À QUINTA. ― O nosso intelecto não só abstrai as espécies inteligíveis, dos fantasmas,
considerando as naturezas das coisas, universalmente; mas também as intelige, nos fantasmas, porque
não pode inteligir as coisas, das quais abstrai as espécies, senão voltando-se para os fantasmas, como
antes se disse (q. 84, a. 7).

## Art. 2 — Se as espécies inteligíveis, abstraídas dos fantasmas, são o objeto que o nosso intelecto intelige.
(II Cont. Gent., cap. LXXV; IV, cap. XI; De Verit., q. 10, a. 9; De Spirit.. Creat., a. 9, ad 6; Compend. Theol.,
cap. LXXXV; III De Anima, lect. VIII).
O segundo discute-se assim. ― Parece que as espécies inteligíveis, abstraídas dos fantasmas, são o
objeto que o nosso intelecto intelige.

1. ― Pois, o intelecto é atual em quem intelige; porque a coisa atualmente inteligida é o intelecto atual
mesmo. Ora, da coisa inteligida nada está no intelecto que intelige, a não ser a espécie inteligível
abstrata. Logo, tal espécie é o intelecto mesmo, em ato.

2. Demais. ― É forçoso que o que é inteligido em ato esteja em alguma coisa; do contrário não seria
nada. Ora, não está na coisa exterior à alma, porque, sendo esta coisa exterior material, nada do que
nela existe pode ser inteligido em ato. Resta, pois, que o que é inteligido em ato esteja no intelecto. E
então, não é senão a predita espécie inteligível.

3. Demais. ― O Filósofo diz, que as palavras são as designações das paixões da alma. Ora, as palavras
exprimem as coisas inteligidas, pois; exprimimos com a palavra o que inteligimos. Logo, as paixões
mesmas da alma, a saber, as espécies inteligíveis, são o que é inteligido em ato.
Mas, em contrário. ― A espécie inteligível está para o intelecto, como a espécie sensível para o sentido.
Ora, esta não é o que é sentido, mas antes o meio pelo qual o sentido sente. Logo, aquela não é o que é
inteligido, mas sim o meio pelo qual o intelecto intelige.

SOLUÇÃO. ― Alguns ensinaram que as nossas virtudes cognoscitivas não conhecem senão as próprias
paixões; assim, o sentido não sente senão a paixão do seu órgão. E, segundo esta opinião, o intelecto só
intelige a sua paixão, que é a espécie inteligível que ele recebe. E então, tal espécie é o objeto mesmo
da intelecção.
Mas esta opinião é manifestamente falsa, por dois motivos. ― Primeiro, porque as coisas que
inteligimos são idênticas às de que tratam as ciências. Se, pois, as que inteligimos fossem só as espécies
que estão na alma, seguir-se-ia que todas as ciências não tratariam das coisas exteriores à alma, mas só
das espécies inteligíveis que nela estão. E assim, segundo os Platônicos, todas as ciências tratam das
idéias, que admitiam ser inteligidas em ato. ― Segundo, porque cairíamos no erro dos antigos que
diziam ser verdadeiro tudo o que se vê, de maneira tal que as proposições contraditórias seriam
simultaneamente verdadeiras. Pois, se uma potência não conhece senão a própria paixão, só desta
julga; e então, uma coisa é vista do modo pelo qual é afetada a potência cognoscitiva. Por onde, o juízo
da potência cognoscitiva há de referir-se àquilo de que ela julga, a saber, à própria paixão e conforme
esta última é. De modo que todos os juízos são verdadeiros. Assim, se o gosto somente sente a própria
paixão, quem, tendo-o são, julgar que o mel é doce, julgará com verdade; e semelhantemente, quem,
tendo o gosto corrompido, julgar que o mel é amargo, julgará com verdade. E ambos julgarão de acordo
com o modo pelo qual o próprio gosto é afetado. Donde resulta que todas as opiniões serão igualmente
verdadeiras e, universalmente, todas as acepções.
Por onde, deve-se dizer que a espécie inteligível é, para o intelecto, o meio pelo qual ele intelige. O que
assim se demonstra. Como já se disse, dupla é a ação: uma imanente ao agente, como ver e inteligir;
outra, transeunte para coisas exteriores, como aquecer e cortar. E uma e outra se realizam por alguma
forma. Ora, como a forma segundo a qual nasce à ação, tendente para a coisa exterior, é semelhança do
objeto da ação ― como o calor do corpo que aquece é semelhança do corpo aquecido ― assim
também, a forma, segundo a qual nasce à ação imanente ao agente, é semelhança do objeto. Por onde,
pela semelhança da coisa visível é que a vista vê; e a semelhança da causa inteligida, que é a espécie
inteligível, é a forma pela qual o intelecto intelige. Ora, como o intelecto reflete sobre si mesmo, pela
mesma reflexão intelige o seu inteligir e a espécie pela qual intelige. De modo que, secundariamente, a
espécie intelectiva é o objeto inteligido; mas o que é inteligido primariamente é a coisa da qual a
espécie inteligível é semelhança. E isto mesmo resulta da opinião dos antigos dizendo que o semelhante
se conhece pelo semelhante. Assim, diziam que a alma, pela terra nela existente, conhece a terra que
lhe é exterior; e assim por diante. Se, portanto, tomamos a espécie da terra, pela terra, conforme a
doutrina de Aristóteles, que diz que a pedra não está na alma, mas sim a espécie da pedra, daí resulta
que a alma, pelas espécies inteligíveis, conhece as coisas, que lhe são exteriores.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A coisa inteligida está em quem intelige, pela sua
semelhança. E deste modo se diz que a coisa inteligida em ato é o intelecto em ato, enquanto a
semelhança da coisa inteligida é a forma do intelecto, do mesmo modo que a semelhança da coisa
sensível é a forma do sensível em ato. Donde não se segue que a espécie inteligível abstrata seja o que é
inteligido em ato; mas que ela é a semelhança daquilo que é inteligido.

RESPOSTA À SEGUNDA. ― A expressão coisa inteligida em ato inclui a coisa inteligida e o ato mesmo de
inteligir. E semelhantemente, a expressão universal abstrato abrange a natureza mesma da coisa e a
abstração ou universalidade. Ora, a natureza mesma que pode inteligir, abstrair, ou que é dotada da
intenção da universalidade, só existe nos seres singulares; mas o ato mesmo de inteligir, abstrair, ou a
intenção da universalidade existem no intelecto. O que podemos ver pela semelhança com os sentidos.
Assim, a vista vê a cor de um pomo sem o odor. Se, pois, se perguntar onde está a cor que é vista, sem o
odor, é claro que essa cor não pode estar senão no pomo. Mas o ser ela percebida, sem o odor,
depende da vista, na qual está a semelhança da cor e não a do odor. Semelhantemente, a humanidade
que é inteligida só pode estar em tal ou tal homem determinado. Mas o intelecto, no qual está a
semelhança da natureza da espécie e não a dos princípios individuais, apreende a humanidade sem as
condições individuais dela, isto é, tem-na abstraída, donde resulta a intenção da universalidade.

RESPOSTA À TERCEIRA. ― Há dupla operação na parte sensitiva. Uma consiste só na imutação; e assim
completa-se a operação do sentido, quando é imutado pelo sensível. Outra, é a formação pela qual a
virtude imaginativa forma, para si, a imagem de uma coisa ausente, ou mesmo nunca vista. E ambas
estas operações unem-se no intelecto. Pois, primeiro, há a paixão do intelecto possível, pela qual é
informado pela espécie inteligível. Assim informado, forma, em segundo lugar, ou a definição ou a
divisão ou a composição, expressas pela palavra. Donde, a essência significada pelo nome é a definição;
exprimindo, a enunciação, a composição e a divisão do intelecto. Logo, as palavras significam não as
espécies inteligíveis, mas aquilo que o intelecto forma, para si, a fim de julgar das coisas exteriores.

## Art. 3 — Se o que é mais universal tem prioridade em o nosso conhecimento intelectual.
(I Poster., lect. IV; I Metaphys., lect. I).
O terceiro discute-se assim. ― Parece que o que é mais universal não tem prioridade em o nosso
conhecimento intelectual.

1. ― Pois, o que tem prioridade e é mais conhecido, por natureza, é posterior e menos conhecido por
nós. Ora, os universais têm prioridade, por natureza, porque se chama primeiro aquilo de que não há
reciprocação quanto à conseqüência pela qual dizemos que uma coisa existe. Logo, os universais são
posteriores.

2. Demais. ― O composto é, para nós, anterior ao simples. Ora, os universais são o que há de mais
simples. Logo, são conhecidos por nós posteriormente.

3. Demais. ― O Filósofo diz, que nós conhecemos o definido antes de conhecermos as partes da
definição. Ora, o mais universal é parte da definição do menos universal; assim, animal é parte da
definição do homem. Logo, os universais são, quanto a nós, conhecidos posteriormente.

4. Demais. ― Pelos efeitos, chegamos às causas e aos princípios. Ora, os universais são princípios. Logo,
são conhecidos por nós posteriormente.
Mas, em contrário, pelo universal é que devemos chegar ao singular.

SOLUÇÃO. ― Duas coisas devem-se considerar no conhecimento do nosso intelecto. A primeira é que o
conhecimento intelectivo tem o seu princípio, de certo modo, no sensitivo. E como o sentido conhece o
singular e o intelecto, o universal, forçoso é que o conhecimento do singular seja, quanto a nós, anterior
ao do universal. A segunda consideração é que o nosso intelecto procede da potência para o ato. Ora,
tudo o que assim procede chega ao ato incompleto, meio termo entre a potência e o ato, antes de
chegar ao ato perfeito. Ora, esse ato perfeito, ao qual chega o intelecto, é a ciência completa, pela qual
as coisas são conhecidas distinta e determinadamente. O ato incompleto, porém, é a ciência imperfeita,
pela qual as coisas são conhecidas indistintamente, com certa confusão; e o que é assim conhecido sob
certo aspecto o é em ato e, de certo modo, em potência. Por onde, diz o Filósofo: o mais confuso é o
que, primariamente, nos é manifesto e certo; depois, é que conhecemos os princípios e os elementos
distintos.
Ora, é claro que conhecer uma coisa na qual várias outras se contêm, sem ter conhecimento próprio de
cada uma das coisas naquela contidas, é conhecê-la com certa confusão. E assim, pode ser conhecido
tanto o todo universal no qual se contêm as partes, potencialmente, como o todo integral; pois, ambos
esses todos podem ser conhecidos com certa confusão, sem serem conhecidas, distintamente, as
partes. Ao passo que conhecer distintamente o que se contém no todo universal, é ter conhecimento de
coisa menos comum. Assim, conhecer um animal, indistintamente, é conhecê-lo como animal; conhecê-
lo, porém, distintamente é conhecê-lo como animal racional ou irracional, o que é conhecer o homem
ou leão. Ora, o nosso intelecto conhece o animal antes de conhecer o homem. E o mesmo se verá se se
comparar o que quer que seja de mais universal com o menos universal.
Como, porém, o sentido, semelhantemente ao intelecto, passa da potência para o ato, a mesma ordem
do conhecimento nele aparece. Pois, pelo sentido, discernimos o mais comum antes do menos comum,
tanto local como temporalmente. Localmente, como quando alguma coisa, vista de longe, é apreendida
como corpo antes de o ser como animal; antes como animal do que como homem; e antes como
homem do que como Sócrates ou Platão. Temporalmente, pois que a criança, a princípio, distingue um
homem do que não é homem e, depois, tal homem, de tal outro; donde vem que as crianças, a princípio
denominam todos os homens, pais; depois, determinam cada pessoa, como diz Aristóteles. E a razão
disto é manifesta. Pois, quem conhece uma coisa indistintamente ainda está em potência para conhecer
o princípio da distinção; assim, quem conhece o gênero está em potência para conhecer a diferença. Por
onde se vê que o conhecimento indistinto é médio entre a potência e o ato.
Logo, deve-se dizer que o conhecimento do singular é anterior, em relação a nós, ao do universal, bem
como o conhecimento sensitivo é anterior ao intelectivo. Mas, tanto em relação ao sentido como ao
intelecto, o conhecimento mais comum é anterior ao menos comum.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― De dois modos se pode considerar o universal. ― De um
modo, considerando-se a natureza do universal simultaneamente com a intenção da universalidade. E
como esta, que faz com que o que tem unidade e identidade se refira a muitas coisas, provém da
abstração do intelecto, necessário é que, deste modo, o universal seja posterior. Por onde, diz-se que, o
animal universal ou não é nada ou é o que é posterior. Mas, para Platão, admitindo os universais como
subsistentes, o universal é anterior ao particular que, na sua opinião, não existe senão por participação
dos universais subsistentes chamados idéias. ― De outro modo, o universal pode ser considerado
quanto à própria natureza mesma, a saber, de animalidade ou humanidade, tal como existe nos seres
particulares. E então, deve-se dizer que há uma dupla ordem da natureza. Uma, segundo a via da
geração e do tempo e, então, o que é imperfeito e potencial tem prioridade. E, deste modo, o mais
comum tem prioridade, quando à natureza; o que manifestamente aparece na geração do homem e do
animal; pois, este é gerado antes daquele, como diz Aristóteles. Outra é a ordem da perfeição ou da
tendência da natureza; assim, ato, em si mesmo e pela sua natureza, é anterior à potência, e o perfeito,
ao imperfeito. E, deste modo, o menos comum é anterior, por natureza, ao mais comum, como, p. ex., o
homem, ao animal; pois, a tendência da natureza não estaca na geração do animal, mas busca gerar o
homem.

RESPOSTA À SEGUNDA. ― O universal mais comum está para o menos comum como o todo para a
parte. Como todo, nele está potencialmente contido, não só o menos universal, mas ainda outras coisas;
assim, no animalestá contido, não só o homem, mas também o cavalo. Como parte, a noção do menos
comum contém, não só o mais comum, mas também outras coisas: assim no homem se contém, não só
o animal, mas também o racional. Assim, pois, o animal, considerado em si, é anterior, em o nosso
conhecimento, ao homem; mas o homem, é conhecido antes da noção de animal, como parte do
mesmo homem.

RESPOSTA À TERCEIRA. ― Uma parte pode ser conhecida de duplo modo. Absolutamente, como é em si
mesma; e, então, nada impede conhecer as partes antes do todo, p. ex., as pedras antes da casa. De
outro modo, como partes de um determinado todo, e então, necessário é conheçamos o todo antes da
parte; pois, conhecemos a casa, por um conhecimento confuso, antes de lhe distinguirmos cada uma
das partes. Por onde, deve-se dizer que as partes da definição, absolutamente consideradas, são
conhecidas antes do definido, do contrário não se conheceria este por aquelas; mas, como partes da
definição são conhecidas posteriormente. Assim, conhecemos o homem por um conhecimento confuso,
antes que saibamos distinguir tudo o que é da essência do homem.

RESPOSTA À QUARTA. ― O universal, entendido simultaneamente com a intenção da universalidade, é,
de certo modo, princípio de conhecimento, enquanto essa intenção é conseqüente ao modo de inteligir,
que se opera pela abstração. Não é necessário, porém, que tudo o que é princípio de conhecimento seja
princípio de existência, como pensava Platão; pois, por vezes, conhecemos a causa pelo efeito e a
substância pelo acidente, como se vê em Aristóteles. ― Se porém considerarmos a natureza mesma do
gênero e da espécie, como existe nos seres particulares, então exerce a função de princípio formal em
relação a eles; pois, ao passo que o singular existe pela matéria, a noção da espécie é deduzida da
forma. Ora, a natureza do gênero se compara com a da espécie, sobretudo como princípio material;
porque a natureza do gênero se deduz do que é material na coisa, ao passo que a da espécie, do que é
formal; assim, a noção de animal se tira do sensitivo; a do homem, do intelectivo. E daí vem que a
última tendência da natureza é para a espécie, não, porém, para o indivíduo nem para o gênero; porque
a forma é o fim da geração; ao passo que a matéria existe pela forma. Não é necessário, porém, que o
conhecimento de qualquer causa ou princípio seja posterior, quanto a nós; pois; às vezes conhecemos,
pelas causas sensíveis, efeitos ignotos, e às vezes, inversamente.

## Art. 4 — Se podemos inteligir muitas coisas simultaneamente.
(Supra. Q. 12, a. 10; q. 58, a. 2; II Sent., dist. III. Q. 3, a. 4; III, dist. XIV, a. 2, qª 4; I Cont. Gent., cap. LV; De
Verit., q. 8, a. 14; Qu. De Anima, a. 16, ad 5; Quodl., VII, q. 1, a. 2).
O quarto discute-se assim. ― Parece que podemos inteligir muitas coisas simultaneamente.

1. ― Pois, o intelecto está fora do tempo. Ora, anteriormente e posteriormente supõem o tempo. Logo,
o intelecto não intelige coisas diversas, por anterioridade e posterioridade, mas simultaneamente.

2. Demais. ― Nada impede que diversas formas não opostas existam simultaneamente no mesmo ato;
assim, o odor e a cor, num pomo. Ora, as espécies inteligíveis não são opostas. Logo, nada impede que
um mesmo intelecto se atualize simultaneamente, segundo diversas espécies inteligíveis. E portanto,
pode inteligir muitas coisas simultaneamente.

3. Demais. ― O intelecto intelige simultaneamente certos todos, como um homem ou uma casa. Ora,
qualquer todo contém muitas partes. Logo, o intelecto intelige simultaneamente muitas coisas.

4. Demais. ― Não se pode conhecer a diferença entre duas coisas sem que elas sejam apreendidas
simultaneamente, como diz Aristóteles; e o mesmo se dá com qualquer outra comparação. Ora, o nosso
intelecto conhece a diferença e a comparação entre muitas coisas. Logo, conhece muitas
simultaneamente.
Mas, em contrário, diz Aristóteles: podemos inteligir só uma coisa, mas saber muitas.

SOLUÇÃO. ― Certamente o intelecto pode inteligir simultaneamente muitas coisas sob o aspecto da
unidade, mas não sob o da multiplicidade. Digo, porém, sob o aspecto da unidade ou da multiplicidade,
por uma ou várias espécies inteligíveis. Pois, o modo de uma ação resulta da forma, que é o princípio da
ação. Ora, todas as coisas que o nosso intelecto pode inteligir, sob uma mesma espécie, ele as pode
inteligir simultaneamente; donde vem que Deus vê tudo simultaneamente porque vê tudo pela unidade
da sua essência. Tudo, porém, que o intelecto intelige por diversas espécies, não intelige
simultaneamente. E a razão é que é impossível o mesmo sujeito ser simultaneamente perfeito por várias
formas de um mesmo gênero de diversas espécies; assim como é impossível um mesmo corpo ser
colorido, sob o mesmo ponto de vista, por diversas cores ou figurado por diversas figuras. Ora, todas as
espécies inteligíveis pertencem ao mesmo gênero, porque são perfeições da mesma potência
intelectiva, embora as coisas de que são espécies sejam de gêneros diversos. Logo, é impossível que um
mesmo intelecto seja perfeito simultaneamente por diversas espécies inteligíveis, afim de inteligir coisas
atualmente diversas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O intelecto está fora do tempo, que é o número do
movimento das coisas corpóreas. Mas a pluralidade mesma das espécies inteligíveis causa uma certa
sucessão de operações inteligíveis, pela qual uma operação é anterior a outra; e esta sucessão
Agostinho a denomina tempo, quando diz que Deus move a criatura espiritual, pelo tempo.

RESPOSTA À SEGUNDA. ― Não só as formas opostas não podem existir simultaneamente num mesmo
sujeito, mas nem mesmo quaisquer formas de um mesmo gênero, embora não sejam opostas; como se
vê pelo exemplo aduzido, das cores e das figuras.

RESPOSTA À TERCEIRA. ― As partes podem ser inteligidas de duplo modo. Com certa confusão,
enquanto estão no todo; e, assim, conhecidas pela forma una do todo, são conhecidas
simultaneamente. E, de outro modo, com conhecimento distinto, enquanto cada parte é conhecida pela
sua espécie; e então, não são as partes conhecidas simultaneamente.

RESPOSTA À QUARTA. ― Quando o intelecto intelige a diferença ou a comparação entre uma coisa e
outra, conhece ambas essas coisas, que entre si diferem ou são comparadas, sob a noção da
comparação mesma ou da diferença; do mesmo modo que, como já se disse, conhece as partes sob a
noção do todo.

## Art. 5 — Se o nosso intelecto intelige compondo e dividindo.
(Supra, q. 58 a. 4).
O quinto discute-se assim. ― Parece que o nosso intelecto não intelige compondo e dividindo.

1. ― Pois, composição e divisão só se podem referir a muitas coisas. Ora, o intelecto não pode inteligi-
las simultaneamente. Logo, não pode inteligir compondo e dividindo.

2. Demais. ― Com toda composição e divisão vai junto o tempo presente, o pretérito ou o futuro. Ora, o
intelecto faz abstração do tempo bem como de outras condições particulares. Logo, não intelige
compondo e dividindo.

3. Demais. ― O intelecto intelige por assimilação da coisa. Ora, nas coisas não há composição nem
divisão; pois cada coisa, singularmente, designada pelo predicado e pelo sujeito, tem unidade e
identidade, se a composição for verdadeira; assim, o homem é verdadeiramente animal. Logo, o
intelecto não compõe nem divide.
Mas, em contrário. ― As palavras exprimem a composição do intelecto, como diz o Filósofo. Ora, nelas
há composição e divisão, como é claro nas proposições afirmativas e negativas. Logo, o intelecto
compõe e divide.

SOLUÇÃO. ― O intelecto humano intelige compondo e dividindo, necessariamente. Pois, como sai da
potência para o ato, tem certa semelhança com as coisas geradas, que não têm a sua perfeição
imediatamente, mas a adquirem sucessivamente. Semelhantemente, o intelecto humano não adquire,
imediatamente, pela primeira apreensão, conhecimento completo da coisa; mas, primeiro, apreende-
lhe algo, por exemplo, a qüididade, que é o objeto primeiro e próprio do intelecto; e em seguida,
intelige as propriedades, os acidentes, e as relações circunstantes à essência da coisa. E então, o
intelecto há de, necessariamente, compor uma coisa apreendida, com outra, ou dividi-las, e de uma
composição e divisão passar para outra, o que é raciocinar.
O intelecto angélico, porém, e o divino comportam-se como coisas incorruptíveis que são:
imediatamente, desde o princípio, têm perfeição total. Por onde, tais intelectos têm imediata e
perfeitamente o conhecimento total de uma coisa. E assim, conhecendo a qüididade da coisa, dela
conhece simultaneamente tudo o que nós podemos conhecer compondo, dividindo e raciocinando. E
portanto, o intelecto humano conhece compondo, dividindo e raciocinando. Ao passo que o intelecto
divino e o angélico conhecem, certamente, a composição, a divisão e o raciocínio, não, porém,
compondo, dividindo e raciocinando; mas pela intelecção da simples qüididade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A composição e a divisão do intelecto realizam-se por
diferenciação ou comparação. Por onde, conhecer muitas coisas, compondo e dividindo, é, para o
intelecto, como conhecer a diferença ou a comparação das coisas.

RESPOSTA À SEGUNDA. ― O intelecto abstrai, dos fantasmas; e contudo não intelige, em ato, senão
voltando-se para eles, como antes ficou dito (a. 1; q. 84, a. 7). E, voltando-se para os fantasmas, à
composição e à divisão do intelecto adjunge-se o tempo.

RESPOSTA À TERCEIRA. ― A semelhança da coisa é recebida no intelecto, ao modo deste e não ao
daquela. Por onde, à composição e à divisão do intelecto corresponde, certo, algo por parte da coisa,
que, todavia não está na coisa do mesmo modo por que está no intelecto. Pois, o objeto próprio do
intelecto humano é a qüididade da coisa material, que está ao alcance do sentido e da imaginação. Ora,
dupla é a composição que se encontra nas coisas materiais. A primeira é a da forma e da matéria; e a
esta corresponde, no intelecto, a composição, pela qual o todo universal é predicado da sua parte. Pois,
o gênero é deduzido da matéria comum; a diferença completiva da espécie, da forma; e o particular, da
matéria individual. A segunda composição é a do acidente em relação ao sujeito. E a esta composição
real corresponde a composição do intelecto pela qual o acidente é predicado do sujeito; assim, quando
se diz ― O homem é branco. Contudo, difere a composição do intelecto da composição das coisas. Pois,
na composição das coisas há diversidade; ao passo que a composição do intelecto é sinal de identidade
das coisas compostas. Assim, o intelecto não compõe de modo a dizer que um homem é a brancura;
mas diz que um homem é branco. i. é, tem brancura; pois há identidade, no sujeito, entre o que é tal
homem e o que tem a brancura. E, semelhantemente, a composição da forma e da matéria. Pois, animal
significa o que tem a natureza sensitiva; racional, o que tem a natureza intelectiva; homem, o que tem
alma; Sócrates, por fim, o que tem tudo isso, com a matéria individual.
E conforme essa noção da identidade, o nosso intelecto compõe uma coisa com outra, predicando.

## Art. 6 — Se o intelecto pode ser falso.
(Supra, q. 17, a. 3; q. 58, a. 5; I Sent., dist. XIX, q. 5, a. 1, ad 7; Cont. Gent., cap. LIX; III, cap. CVIII; De
Verit., q. 1, a. 12; I Periherm., lect. III; III De Anima, lect XI; VI Metaphys., lect. IV; IX, lect, IX).
O sexto discute-se assim. ― Parece que o intelecto pode ser falso.

1. ― Pois, diz o Filósofo, que a verdade e a falsidade estão na mente. Ora, mente e intelecto são
idênticos, como antes já se disse (q. 79). Logo, existe falsidade no intelecto.

2. Demais. ― A opinião e o raciocínio pertencem ao intelecto. Ora, numa e noutro pode haver falsidade.
Logo, pode haver falsidade no intelecto.

3. Demais. ― O pecado está na parte intelectiva. Ora, há falsidade no pecado, conforme o dito da
Escritura (Pr 14, 25), pois, os que praticam o mal erram. Logo, pode haver falsidade no intelecto.
Mas, em contrário, diz Agostinho: todos os que se enganam não lhe inteligem o porquê. E o Filósofo
diz: o intelecto é sempre verdadeiro.

SOLUÇÃO. ― Neste ponto, o Filósofo compara o intelecto com os sentidos. Pois, estes não se enganam,
em relação ao seu objeto próprio ― assim à vista em relação à cor ― salvo por acidente, sobrevindo
algum impedimento ao órgão, como quando o gosto de um febricitante julga doces as coisas amargas,
porque a sua língua está repleta de maus humores. Porém os sentidos podem enganar-se em relação
aos sensíveis comuns, como quando julgam da grandeza ou da figura; assim, se se julgar que o sol é
como tamanho de um pé, que, entretanto, é maior que a terra. E com maior razão, eles se enganam em
relação aos sensíveis por acidente; assim, quando julgam que o fel é mel, pela semelhança da cor. E a
causa disso é evidente. Pois, cada potência, em si mesma, se ordena para o seu objeto próprio. Ora,
potências assim ordenadas comportam-se sempre do mesmo modo. Por onde, enquanto permanecem
tais, não lhes erra o juízo sobre o objeto próprio.
Ora, o objeto próprio da inteligência é a qüididade da coisa, e, por isso, o intelecto não pode enganar-se
no tocante a essa qüididade, em si mesma considerada. Mas pode-o, no tocante aos acidentes da
essência ou qüididade, enquanto ordena um para outro, compondo, dividindo ou raciocinando. Por
onde, não pode errar em relação às proposições imediatamente conhecidas, desde que o seja a
qüididade dos termos, como se dá, com os primeiros princípios, dos quais resulta também a
infalibilidade da verdade, quanto à certeza das ciências, no tocante às conclusões.
Acidentalmente, porém, o intelecto pode enganar-se quanto a qüididade, em se tratando de coisas
compostas; não por causa do órgão, porque o intelecto não é virtude que se sirva de órgão, mas por
causa da composição interveniente na definição; quer porque a definição de uma coisa é falsa aplicada à
outra ― assim a definição do círculo é falsa aplicada ao triângulo ― quer porque a definição é falsa, em
si mesma, implicando composição de elementos impossíveis ― assim se se admitisse, como definição de
um ser, animal racional alado. Por onde, nas coisas simples, em cujas definições não pode intervir a
composição, não podemos nos enganar; podemos, porém, ser deficientes, quanto totalmente não as
atingimos, como diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Diz-se que há falsidade na mente, pela composição e
divisão.
E o mesmo se deve RESPONDER À SEGUNDA OBJEÇÃO, quanto à opinião e ao raciocínio.
E TAMBÉM À TERCEIRA, quanto ao erro dos que pecam, que consiste na aplicação ao apetecível.
Mas, na consideração absoluta da qüididade e do que por ela é conhecido, o intelecto nunca se engana.
― E assim se exprimem os autores aduzidos em contrário.

## Art. 7 — Se um pode inteligir melhor que outro uma mesma coisa.
(Supra, q. 12, a. 6, ad 1; IV Sent., dist. XLIX, q. 2, a. 4, ad 1; De Verit., q. 2, a. 2, ad II).
O sétimo discute-se assim. ― Parece que um não pode inteligir melhor que outro uma mesma coisa.

1. ― Pois, como diz Agostinho, quem intelige uma coisa diferentemente do que ela é, não a intelige.
Porque não se pode duvidar que é perfeita a inteligência em relação à qual não há melhor. Por onde,
não se pode ir ao infinito quanto ao modo de inteligir qualquer coisa; nem pode um inteligir a mais que
outro.

2. Demais. ― O intelecto, no inteligir, é verdadeiro. Ora, a verdade, sendo uma equação entre o
intelecto e a coisa, não é susceptível de mais nem de menos, pois não se pode dizer, propriamente, que
uma coisa é mais ou menos igual. Logo, também não se pode dizer que é mais ou menos inteligida.

3. Demais. ― O intelecto é o que há de formalíssimo no homem. Ora, a diferença de forma causa a
diferença de espécie. Se, pois, um homem intelige mais que outro, resulta que não são ambos da
mesma espécie.
Mas, em contrário, a experiência mostra que uns inteligem mais profundamente que outros; assim,
quem pode reduzir uma conclusão qualquer aos primeiros princípios e às primeiras causas intelige mais
profundamente do que quem pode reduzi-la só às causas próximas.

SOLUÇÃO. ― De dois modos pode-se conceber que alguém intelija uma mesma coisa, mais que outrem.
De modo tal que mais determine o ato de inteligir em relação à coisa inteligida. E, então, um não pode
inteligir uma mesma coisa mais que outro; porque se inteligisse a coisa diferentemente do que ela é,
melhor ou pior, enganar-se-ia e não inteligiria, como argui Agostinho. De outro modo, pode-se conceber
que mais determine o ato de inteligir, por parte de quem intelige. E, então, um pode inteligir a mesma
coisa melhor que outro, porque tem melhor virtude no inteligir, assim como vê melhor uma coisa, pela
visão corpórea, quem é dotado de virtude mais perfeita e que tem mais perfeita a virtude visiva.
Ora, isto pode se dar, no intelecto, de dois modos. De um modo, porque o intelecto mesmo é mais
perfeito. Pois, como é manifesto, quanto melhor disposto for o corpo, tanto melhor disposta será a
alma; o que se vê claramente nos seres especificamente diversos. E a razão está em que o ato e a forma
são recebidos na matéria, segundo a capacidade desta. Por onde, os homens de corpo melhor disposto
terão alma de melhor virtude para inteligir; e, por isso, como diz Aristóteles, vemos que os moles de
carne são bem dispostos de mente. De outro modo, por parte das virtudes inferiores, que o intelecto
necessita para a sua operação. Assim, os que são melhor dispostos quanto às virtudes imaginativa,
cogitativa e memorativa, são-no também melhor para inteligir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A SOLUÇÃO. resulta claro do que acaba de ser dito.
E SEMELHANTEMENTE À SEGUNDA. ― Pois, a verdade do intelecto consiste em que ele intelige a coisa
como ela é.

RESPOSTA À TERCEIRA. ― A diferença de forma, somente proveniente da disposição diversa da matéria,
não produz a diversidade específica, mas só a numérica. Pois, as formas diversas de indivíduos diversos
é a matéria que as diversifica.

## Art. 8 — Se o intelecto intelige o indivisível antes do divisível.
(Supra, q. 11, a. 2, ad 4; III De Anima, lect. XI).
O oitavo discute-se assim. ― Parece que o intelecto intelige o indivisível antes do divisível.

1. ― Pois, o Filósofo diz que inteligimos e sabemos, pelo conhecimento dos princípios e dos elementos.
Ora, os indivisíveis são os princípios e os elementos dos divisíveis. Logo, aqueles são-nos conhecidos
antes destes.

2. Demais. ― O que entra na definição de uma coisa é conhecido por nós em primeiro lugar, porque a
definição parte do que é primeiro e mais conhecido, como diz Aristóteles. Ora, o indivisível entra na
definição do divisível, como o ponto na definição da linha; pois, a linha, segundo diz Euclides, é
longitude sem latitude, cujas extremidades são dois pontos. E a unidade entra na definição de número,
porque o número é a multidão mensurada pela unidade, como diz Aristóteles. Logo, o nosso intelecto
intelige o indivisível antes do divisível.

3. Demais. ― O semelhante pelo semelhante se conhece. Ora, o indivisível é mais semelhante ao
intelecto do que o divisível, porque o intelecto é simples, como diz Aristóteles. Logo, o nosso intelecto
conhece primeiro o indivisível.
Mas, em contrário, diz Aristóteles que o indivisível se manifesta como a privação. Ora, a privação
conhecida ulteriormente. Logo, também o indivisível.

SOLUÇÃO. ― O objeto do nosso intelecto, no estado da vida presente, é a qüididade da coisa material,
que ele abstrai dos fantasmas, como resulta claro do que já foi dito (a. I; q. 84, a. 7). E como aquilo que é
conhecido primariamente e por si, pela virtude cognoscitiva, é o objeto próprio desta, pode-se
considerar a ordem em que o indivisível é inteligido por nós pela sua relação com a sobredita qüididade.
Ora, indivisível pode ser tomado em tríplice acepção. ― Primeiro, como o contínuo e indivisível, pois é
indiviso em ato, embora seja divisível em potência. E tal indivisível é inteligido por nós antes de lhe
inteligirmos a divisão, que o desdobra em partes, porque o conhecimento confuso é anterior ao distinto,
como já se disse (a. 3). ― Segundo, especificamente; assim, a noção de homem é um indivisível. E
também deste modo o indivisível é inteligido antes que o seja a sua divisão em partes de razão, como
antes já se disse (loc. cit.); e ainda antes que o intelecto componha e divida, afirmando ou negando. E a
razão disto é que tal duplo indivisível o intelecto o intelige, inteligindo-se a si mesmo, como o seu objeto
próprio. ― Terceiro, como absolutamente indivisível; assim, o ponto e a unidade, que não se dividem
nem atual nem potencialmente. E este indivisível é conhecido ulteriormente, pela privação do divisível.
Por onde, o ponto é definido privativamente: Ponto é o que não tem partes. E semelhantemente, a
essência da unidade é ser indivisível, como diz Aristóteles. E a razão disto é que tal indivisível tem certa
oposição com a causa corpórea, cuja qüididade, primariamente e por si, é apreendida pelo intelecto. ―
Se porém o nosso intelecto inteligisse por participação dos indivisíveis separados, como ensinavam os
Platônicos, seguir-se-ia que tal indivisível seria inteligido primariamente, pois, segundo os Platônicos, o
que tem prioridade é primariamente participado pelas coisas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Na aquisição da ciência nem sempre os princípios e os
elementos têm prioridade; pois, por vezes, pelos efeitos sensíveis chegamos ao conhecimento dos
princípios e das coisas inteligíveis. Mas, no complemento da ciência, o conhecimento dos efeitos
depende do conhecimento dos princípios e dos elementos; porque, como no mesmo passo diz o
Filósofo, opinamos que sabemos quando podemos reduzir os principiados às suas causas.

RESPOSTA À SEGUNDA. ― O ponto não entra na definição da linha, comumente compreendida. Ora é
manifesto que numa linha infinita e mesmo circular, não há ponto senão em potência. Mas Euclides
define a linha finita reta; e por isso introduziu o ponto na definição da linha, como o limite na definição
do limitado. E quanto à unidade, ela é a medida do número e, portanto, entra na definição do número
mensurado. Não entra, porém, na definição do divisível, mas antes, inversamente.

RESPOSTA À TERCEIRA. ― A semelhança, pela qual inteligimos, é a espécie do conhecido no
conhecente. Por onde, não é pela semelhança da natureza com a potência cognitiva que uma coisa é
conhecida primariamente, mas pela conveniência com o objeto; do contrário, a vista conheceria mais o
ouvido do que a cor.