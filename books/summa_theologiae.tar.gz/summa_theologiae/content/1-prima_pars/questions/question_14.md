# Questão 14: Da ciência de Deus.
Depois de termos considerado o que pertence à substância divina, resta considerarmos o que lhe
pertence à operação. E como há duas espécies de operações, uma imanente no agente, e outra, que
produz um efeito exterior, trataremos, primeiro, da ciência e da vontade, pois, o ato de inteligir é
imanente no sujeito que intelige e o de querer, no sujeito que quer. E, em segundo lugar, trataremos do
poder divino considerado como princípio de operação divina que produz um efeito exterior. — Como,
porém, inteligir é viver, depois de considerarmos a divina essência, trataremos da vida divina. — E,
como a ciência diz respeito à verdade, trataremos da verdade e da falsidade. — Enfim, como todo
objeto conhecido está no sujeito que conhece; e como as razões das coisas, enquanto existentes em
Deus, que as conhece, chamam-se idéias, quando tratarmos da ciência também, conjuntamente,
trataremos das idéias.
Ora, sobre a ciência discutem-se dezesseis artigos:

## Art. 1 — Se em Deus há ciência.
(I Sent., dist. XXXV, a. 1; I Cont. Gent., cap. XLIV; De Verit., q. 2, a. 1; Compend. Theol., cap. XXVIII; XII
Metaph., lect. VIII).
O primeiro discute-se assim. — Parece que em Deus não há ciência.

1. — Pois, a ciência é um hábito que, sendo meio termo entre a potência e o ato, não podemos atribuir
a Deus. Logo, em Deus não há ciência.

2. Demais. — A ciência, respeitante às conclusões, é um certo conhecimento causado por outro, a saber,
pelo conhecimento dos princípios. Ora, em Deus, não há nada de causado. Logo, não há ciência.

3. Demais. — Toda ciência é universal ou particular. Ora, em Deus não há nem universal nem particular,
como já se viu. Logo, nele não há ciência.
Mas, em contrário, diz o Apóstolo (Rm 11, 33): Ó profundidade das riquezas da sabedoria e da ciência de
Deus!

SOLUÇÃO. — Em Deus há ciência perfeitíssima. Para evidenciá-lo, devemos considerar que os seres
dotados de conhecimento distinguem-se dos que não o são, neste sentido que estes têm apenas a sua
forma própria, ao passo que àqueles é natural poderem conter em si também a forma de outro ser,
pois, a espécie do objeto conhecido está no conhecente. Por onde, é manifesto que a natureza do ser
que não conhece é mais restrita e limitada; ao passo que a dos que são dotados de conhecimento tem
maior amplitude e extensão; e por isso, diz o Filósofo que a alma é de certo modo tudo. Ora, a limitação
da forma se dá pela matéria. Por isso, dissemos antes que, quanto mais imateriais são as formas, mais
se aproximam de uma certa infinidade. Ora, é claro que a imaterialidade de um ser é a razão que o torna
capaz de conhecimento; e conforme o modo da imaterialidade, assim o do conhecimento. Por isso, diz
Aristóteles, que as plantas, por causa da sua materialidade, não conhecem; ao passo que o sentido é
susceptível de conhecimento porque é capaz de receber as espécies sem matéria. E ainda mais capaz de
conhecimento é o intelecto, porque é ainda mais separado e emerge da matéria, como diz Aristóteles.
Por onde, sendo Deus o ser sumamente imaterial, como do sobredito resulta conclui-se que é, por
excelência, dotado de conhecimento.

DONDE A RESPOSTA À PRIMEIRA QUESTÃO. — Como as perfeições procedentes de Deus para as
criaturas estão em Deus de modo eminente, como já dissemos, sempre que um nome, derivado de
qualquer perfeição da criatura, é atribuído a Deus, é necessário que seja eliminado da sua significação
tudo o que pertence ao modo imperfeito próprio à criatura. Por onde, a ciência não é, em Deus,
qualidade nem hábito, mas, substância e ato puro.

RESPOSTA À SEGUNDA. — O que nas criaturas existe dividida e multiplicadamente existe em Deus
reduzido à simplicidade e à unidade, como dissemos. Ora, no homem, à diversidade de objetos
conhecidos corresponde a diversidade de conhecimentos. Assim, quando conhece os princípios, dizêmo-
lo dotado de inteligência; de ciência, porém, quando conhece as conclusões; quando conhece a causa
altíssima, dizêmo-lo dotado de sabedoria; e, por fim, de conselho ou prudência, quando conhece o que
deve fazer. Deus, porém, conhece tudo o que acabamos de enumerar, por um conhecimento uno e
simples, como a seguir se dirá. Por onde o conhecimento simples de Deus pode receber, todas essas
denominações supra referidas, mas, de modo que de cada uma delas, quando usada para a predicação
divina, seja eliminado tudo o que há de imperfeição e seja conservado o que há de perfeito. E, neste
sentido, diz a Escritura (Jó, 12, 13): A sabedoria e a fortaleza está em Deus; ele possui o conselho e a
inteligência.

RESPOSTA À TERCEIRA. — A ciência depende do modo de ser do sujeito que conhece; pois, o objeto
conhecido está no sujeito conhecente ao modo deste. Por onde, sendo o modo de ser da divina essência
mais elevado que o da criatura, a ciência divina não será como a da criatura, universal ou particular,
habitual ou potencial, ou com qualquer disposição semelhante.

## Art. 2 — Se Deus se conhece a si mesmo.
(I Cont. Gent., cap. XLVII; De Verit., q. 2, a. 2; Comp. Theol., cap. XXX; XII Metaph., lect. XI; De Causis,
lect. XIII).
O segundo discute-se assim. parece que Deus não se conhece a si mesmo.

1. — Pois, como diz o livro De Causis: todo ser dotado de conhecimento, que conhece a sua própria
essência, volta-se para ela de um modo perfeito. Ora, Deus não sai da sua própria essência, nem se
move de modo nenhum e portanto, não lhe cabe voltar-se para a sua essência. Logo, não a conhece.

2. Demais. — Conhecer é de certo modo sofrer e ser movido, diz Aristóteles; a ciência é, por sua vez, um
assimilar-se do espírito com a coisa conhecida; e por fim, o conhecido é a perfeição de quem conhece.
Ora, nada se move, sofre ou se aperfeiçoa por si mesmo, nem é semelhante a si mesmo, como diz
Hilário. Logo, Deus não se conhece a si mesmo.

3. Demais. — Principalmente pelo intelecto é que nós somos semelhantes a Deus, porque, por ele é que
fomos feitos à imagem de Deus, como diz Agostinho. Ora, o nosso intelecto não se compreende a si
mesmo senão conhecendo outras coisas, no dizer de Aristóteles. Logo, Deus não se conhece a si mesmo
senão, talvez, conhecendo outros seres.
Mas, em contrário, diz a Escritura (1 Cor 2, 11): As coisas que são de Deus, ninguém as conhece, senão o
espírito de Deus.

SOLUÇÃO. — Deus se conhece a si mesmo e por meio de si mesmo. Para evidenciá-lo devemos saber
que, nas operações que produzem um efeito exterior, o objeto desta, que lhe é assinalado como termo,
é algo de exterior ao agente; mas, nas operações imanentes ao sujeito mesmo que opera, o objeto que
lhe é assinalado como termo está no próprio sujeito e, por isto, é que a operação se atualiza. Por isso diz
o Filósofo, que o sensível em ato é idêntico ao sentido em ato, e o inteligível em ato, ao intelecto em
ato. Pois, sentimos ou inteligimos alguma coisa em ato, porque o nosso intelecto ou o nosso sentido é
informado pela espécie do sensível ou do inteligível. E, então, tanto o sentido como o intelecto diferem
do sensível ou do inteligível, porque um e outro são potenciais. Ora, não havendo em Deus nenhuma
potencialidade, mas sendo ato puro, necessariamente nele há de o intelecto ser idêntico, sob todos os
pontos de vista, ao inteligível. Por onde, nem carece de espécie inteligível, como o nosso intelecto
quando intelige em potência; nem a espécie inteligível difere da substância do intelecto divino, como se
dá com a nossa inteligência quando intelige em ato; mas, a espécie inteligível mesma é o próprio
intelecto divino e, portanto, conhece-se a si mesmo por meio de si mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Voltar-se para a sua própria essência não é senão o
subsistir da coisa, em si mesma. Pois, a forma, aperfeiçoando a matéria a que dá o ser, como que se
difunde, de certo modo, nela; mas, se tem o ser em si mesma, para si mesma se volta. Por onde, as
potências cognoscitivas não subsistentes, mas que são atos de certos órgãos, não se conhecem a si
mesmas, como cada um dos sentidos bem o demonstra. Pelo contrário, as potências cognoscitivas, por
si mesmas subsistentes, a si mesmas se conhecem. E, por isso, diz o livro De causis, que todo ser
dotado de conhecimento, que conhece a sua própria essência, volta-se para ela. Ora, ser subsistente por
si mesmo convém, por excelência, a Deus. Por onde, conforme a este modo de falar, ele, mais que
nenhum outro ser, volta-se para a sua própria essência e a si mesmo se conhece.

RESPOSTA À SEGUNDA. — As expressões — passividade e mutação — tomam-se equivocamente, no
sentido em que consideramos o conhecimento como uma espécie de passividade e mutação, segundo
diz Aristóteles. Pois, inteligir não é o movimento, ato do imperfeito, que procede de um sujeito e é
recebido por outro; mas, o movimento, ato do perfeito, existente no próprio agente. Semelhantemente,
quando dizemos que o intelecto é aperfeiçoado pelo inteligível ou com ele se assimila, entendemos que
isso se dá com o intelecto que é, às vezes, potencial. Pois, por ser tal, é que difere do inteligível, com o
qual se assimila, por meio da espécie inteligível — semelhança do objeto inteligido — que aperfeiçoa o
intelecto, como o ato, a potência. Ora, o intelecto divino, que não é, de nenhum modo, potencial, não se
aperfeiçoa pelo inteligível, nem com ele se assimila, mas é a sua própria perfeição e o seu próprio
inteligível.

RESPOSTA À TERCEIRA. — A matéria prima, que existe em potência, não tem o seu ser natural, senão
quando atualizada pela forma. Ora, o nosso intelecto possível comporta-se, na ordem do inteligível,
como a matéria prima, na ordem dos seres naturais; pois, é potencial em relação aos inteligíveis, como a
matéria prima em relação aos seres naturais. Por onde, o nosso intelecto possível não pode exercer a
operação inteligível, senão aperfeiçoado pela espécie inteligível de algum objeto. E, como se intelige a si
mesmo, por meio da espécie inteligível, assim também, do mesmo modo intelige as demais coisas. Pois,
é manifesto que, conhecendo o inteligível, intelige o seu próprio ato de conhecer e, por meio do ato,
conhece a potência intelectiva. Ora, Deus é ato puro, tanto na ordem da existência como na dos
inteligíveis; e, portanto conhece-se a si mesmo por meio de si mesmo.

## Art. 3 — Se Deus se compreende a si mesmo.
(I Sent., dist. XLIII, q. 1, a. 1, ad 4; III, dist. XIV, a. 2, qa. 1; I Cont. Gent., cap. III; III, cap. LV; De Verit., q. 2,
a. 2, ad 5; Compend. Theologiae, cap. CVI).
O terceiro discute-se assim. Parece que Deus não se compreende a si mesmo.

1. — Pois, como diz Agostinho, um ser que se compreende, é para si mesmo, finito. Ora, Deus é, de
todos os modos, infinito. Logo, não se compreende a si mesmo.

2. — Nem colhe dizer que Deus é infinito para nós, mas, para si mesmo, finito. — Pois, o que é
verdadeiro para Deus é mais verdadeiro do que o que para nós o é. Se, portanto, Deus é para si mesmo
finito, mas para nós, infinito, mais verdadeiro é ser ele finito do que infinito, o que vai contra o já
estabelecido. Logo, Deus não se compreende a si mesmo.
Mas, em contrário, diz Agostinho, no mesmo passo: Todo ser que a si mesmo se intelige, a si mesmo se
compreende. Ora, Deus intelige-se a si mesmo. Logo, a si mesmo se compreende.

SOLUÇÃO. — Deus compreende-se perfeitamente a si mesmo, o que se demonstra do modo seguinte.
Compreendemos uma coisa quando chegamos a ter dela um conhecimento total; e isto se dá quando
conhecemos essa coisa tão perfeitamente quanto ela é cognoscível. Assim, uma proposição
demonstrável é compreendida quando conhecida por demonstração, não, porém, quando conhecida
por alguma razão provável. Ora, é manifesto que Deus se conhece a si mesmo tão perfeitamente quanto
é cognoscível. Pois, um ser é cognoscível na medida em que é atual, porque conhecemos uma coisa, não
enquanto potencial, mas, enquanto atual, como diz Aristóteles. Por onde, a faculdade cognoscitiva de
Deus iguala à atualidade da sua existência, porque, enquanto atual, livre de toda a matéria e de toda
potência é que Deus é suscetível de conhecimento, como já demonstramos. Logo, é manifesto que se
conhece a si mesmo na medida em que é cognoscível. E, por isso compreende-se perfeitamente a si
mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Compreender, em sentido próprio, significa ter e incluir
em si alguma coisa; por onde, necessariamente, tudo o que é compreendido, como tudo o que é
incluído, é finito. Ora, quando se diz que Deus se compreende a si mesmo, não se quer dizer que o seu
intelecto seja algo diferente do seu ser, de modo que o apreenda e o inclua; mas, essa expressão deve
ser entendida negativamente. Pois, assim como dizemos que Deus está em si mesmo, porque não é
contido por nenhum ser exterior, assim dizemos que se compreende a si mesmo porque nada há do seu
ser que lhe escape. E isto é o que leva Agostinho a afirmar, que uma coisa é totalmente apreendida pela
vista, quando é percebida de tal modo que nenhuma parte dela escape a quem a vê.

RESPOSTA À SEGUNDA. — Quando se diz que Deus é, para si mesmo, finito, isso se entende por
semelhança de proporção. Pois, Deus não excede a capacidade do seu intelecto, assim como um ser
finito não excede a capacidade de um intelecto finito. Mas, não dizemos que ele seja finito, para si
mesmo, porque se compreenda como finito.

## Art. 4 — Se o inteligir de Deus é a sua própria substância.
(I Cont. Gent., cap. XLV; Comp. Theol., cap. XXXI; XXII Metaph., lect. XI).
O quarto discute-se assim. — Parece que o inteligir de Deus não é a sua própria substância.

1. — Pois, inteligir é uma operação. Ora, esta significa algo procedente do agente que opera. Logo, o
inteligir de Deus não é a sua própria substância.

2. Demais. — Quando conhecemos pela reflexão o nosso ato de inteligir, não conhecemos nada de
grande ou principal, mas algo de secundário e acessório. Ora, se Deus é o seu próprio inteligir, o seu ato
de intelecção será como aquele pelo qual conhecemos, pela reflexão, o nosso ato de inteligir; e, assim, o
inteligir de Deus não será de grande importância.

3. Demais. — Todo ato de inteligir consiste em inteligir alguma coisa. Ora, quando Deus se intelige a si
mesmo, se não é diferente do seu ato de inteligir, intelige-se como inteligindo e como inteligindo que se
intelige, e assim ao infinito. Logo, o inteligir de Deus não é a sua própria substância.
Mas, em contrário, diz Agostinho: Para Deus, ser é ser sábio. Ora, ser sábio, é inteligir. Logo, para Deus,
ser é inteligir. Ora, o ser de Deus é a sua própria substância, como já se disse. Logo, o inteligir de Deus é
a sua própria substância. SOLUÇÃO. — É necessário admitir que o inteligir de Deus é a sua própria
substância. Pois, se fosse diferente dela, seria necessário, como diz o Filósofo, que a substância divina
tivesse o seu ato e a sua perfeição em algo dela diferente; e, para isso estaria a divina substância, como
a potência, para o ato; o que é absolutamente, impossível, pois, inteligir é a perfeição e o ato do ser que
intelige. Por onde, para explicar a questão de que tratamos, devemos considerar o seguinte. Como já
dissemos, inteligir não é ato orientado para nada de exterior, mas, imanente no sujeito, como ato e
perfeição do mesmo, porque o ser é a perfeição do que existe; pois, como o ser é consecutivo à forma,
assim o inteligir é consecutivo à espécie inteligível. Ora, em Deus não há forma diferente do seu ser,
como já dissemos. Por onde, como a sua essência mesma é também a espécie inteligível, conforme já
dissemos, segue-se necessariamente, que o seu ato mesmo de inteligir é a sua essência e o seu ser.
E assim é claro, por tudo o que precede, que, em Deus, o intelecto que intelige, o objeto da intelecção, a
espécie inteligível e o ato mesmo de inteligir são, absolutamente, uma só e mesma realidade. Por onde,
é manifesto que, dizer que Deus é inteligente não introduz na sua substância nenhuma multiplicidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Inteligir não é uma operação transitiva para fora do
agente, mas, nele imanente.

RESPOSTA À SEGUNDA. — Inteligir que inteligimos, quando se trata de um ato de intelecção não-
subsistente, não é ato de grande importância; tal é o caso, quando inteligimos o nosso ato de
intelecção, em que não há semelhança com o inteligir divino, que é subsistente.

DONDE SE DEDUZ CLARA ARESPOSTA À TERCEIRA OBJEÇÃO. — Pois, o inteligir de Deus, subsistente em
si mesmo, é relativo a Deus mesmo, e não, a qualquer outro ser, de modo que houvesse processo ao
infinito.

## Art. 5 — Se Deus conhece seres diferentes de si.
(I Sent., dist. XXXV, a. 2; I Cont. Gent., cap. XLVIII, XLIX; De Verit., q. 2, a. 3; Comp. Theol., cap. XXX; XII
Metaph., lect. XI; De Causis, sect. XIII).
O quinto discute-se assim. — Parece que Deus não conhece seres diferentes de si.

1. — Pois, tudo o que é diferente de Deus está fora dele. Ora, Agostinho diz que Deus não vê nada fora
de si próprio. Logo, não conhece os seres diferentes de si.

2. Demais. — A inteligência é a perfeição do ser inteligente. Se, pois, Deus intelige seres de si diferentes,
a sua perfeição ser-lhe-á algo de exterior e mais nobre que ele, o que é impossível.

3. Demais. — O ato mesmo de inteligir especifica-se pelo objeto inteligível, assim como todo ato se
especifica pelo seu objeto. Por onde, a intelecção é tanto mais nobre, quanto mais nobre for o objeto
inteligido. Ora, Deus é a sua própria intelecção, como do sobredito resulta. Se, portanto, conhece causas
diferentes do seu ser, é especificado por algo que lhe é exterior, o que é impossível. Logo, não intelige
tais seres.
Mas, em contrário, diz a Escritura (Heb 4, 13): Todas as coisas estão nuas e descobertas aos seus olhos.

SOLUÇÃO. — Deus conhece necessariamente seres de si diferentes. Pois, é manifesto que se intelige
perfeitamente a si mesmo, do contrário, o seu ser, que é o seu inteligir, não seria perfeito. Ora,
devemos conhecer perfeitamente a virtude da coisa que conhecemos perfeitamente. Mas, a virtude do
que conhecemos não pode ser perfeitamente conhecida se não conhecermos até onde ela se estende.
Ora, como a virtude divina, sendo a causa primeira eficiente dos seres, a eles se estende, como do
sobredito resulta, Deus há necessariamente de conhecer seres dele diferentes. — E isto se torna ainda
mais evidente, se acrescentarmos que o ser mesmo da causa agente primeira, i. é, Deus, é o seu
inteligir. Por onde, todos os efeitos preexistentes em Deus, como na causa primeira, preexistem-lhe,
necessariamente, na inteligência; e, portanto, todas as coisas nele existem sob uma forma inteligível,
dado que tudo quanto existe em outro ser existe ao modo deste último.
Para sabermos, porém, de que modo Deus conhece os seres que lhe são diferentes, devemos considerar
que uma coisa pode ser conhecida de duplo modo: em si mesma, e noutra coisa. Em si mesma, quando
conhecida por uma espécie própria, a ela adequada; assim, quando os olhos vêem um homem sob
forma humana. Noutra coisa, quando é vista pela espécie daquilo que a contém; assim, quando a parte
é vista no todo, pela espécie deste; ou, quando um homem é visto num espelho pela imagem desse
espelho; ou, por qualquer outro modo por que possamos ver uma coisa em outra. Por onde, devemos
dizer que Deus se vê a si mesmo em si mesmo, porque vê pela sua essência. Os outros seres, porém, ele
os vê, não neles, mas, em si mesmo, pois, a sua essência contém as semelhanças deles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras de Agostinho, dizendo que Deus nada vê
fora de si mesmo, não devem ser entendidas como se significassem que Ele nada vê do que lhe é
exterior, mas, que não vê as coisas exteriores, senão em si mesmo, como já dissemos.

RESPOSTA À SEGUNDA. — A coisa inteligida é a perfeição do ser que intelige; não, certo, pela sua
substância mesma mas, pela sua espécie, pela qual existe no intelecto como forma e perfeição deste;
assim, não é uma pedra, mas a sua espécie, que está na alma, como diz Aristóteles. Ora, as coisas
exteriores a Deus ele as intelige, porque a sua essência contém as espécies delas, como dissemos.
Donde não se segue, que uma coisa seja a perfeição do intelecto divino e outra, a essência mesma de
Deus.

RESPOSTA À TERCEIRA. — O ato mesmo de inteligir não é especificado pelo que é inteligido em outro
ser, mas, pelo objeto visto, principalmente, e no qual os outros se inteligem. Pois, a intelecção é
especificada pelo seu objeto, na medida em que a forma inteligível é o princípio da operação intelectual.
Porque toda operação se especifica pela forma que é o seu princípio; assim, a calefação, pelo calor. Por
onde, a operação intelectual se especifica pela forma inteligível, que atualiza o intelecto. E esta é a
espécie principal do intelecto, a qual, em Deus, não é senão a sua essência mesma, em que estão
compreendidas todas as espécies das coisas. Por isso, não é necessário que o inteligir divino, ou antes,
Deus mesmo, seja especificado por algo diferente da essência divina.

## Art. 6 — Se Deus tem dos outros seres conhecimento próprio.
(I Sent., dist. XXXV, a. 3; I Cont. Gent., cap. I; De Pot., q. 6, a. 1; De Verit., q. 2, a. 4; De Causis, lect. X)
O sexto discute-se assim. — Parece que Deus não tem dos outros seres conhecimento próprio.

1. — Pois, como já se disse, Deus conhece todas as coisas do modo pelo qual elas estão nele. Ora todas
elas estão em Deus como na causa primeira comum e universal. Logo, todas são por ele conhecidas
como pela causa primeira e universal. Ora, isto é conhecer em geral e não, por conhecimento próprio.
Logo, Deus tem dos outros seres um conhecimento geral e não próprio.

2. Demais. — Quanto dista a essência da criatura, da essência divina, tanto esta dista daquela. Ora, pela
essência da criatura não pode ser conhecida a essência divina, como já dissemos. Logo, também, pela
essência divina, não pode ser conhecida a essência da criatura. E assim como Deus não conhece nada,
senão pela sua essência, resulta que não conhece a essência, de modo a lhe apreender a quididade, o
que é ter conhecimento próprio de uma coisa.

3. Demais. — Não é possível ter conhecimento próprio de uma coisa senão pela sua essência própria.
Ora, como Deus conhece tudo pela sua essência, parece que não conhece a essência própria de cada
coisa; porque uma mesma realidade não pode ser a essência própria de coisas múltiplas e diversas.
Logo, Deus não tem um conhecimento próprio das coisas.
Mas, em contrário. — Ter conhecimento próprio das coisas é conhece-las, não só em geral, mas
enquanto distintas umas das outras. Ora, é assim que Deus conhece as coisas, conforme a Escritura (Heb
4, 12): Ela penetra, a palavra de Deus, até o íntimo da alma e do espírito, também às juntas e medulas, e
discerne os pensamentos e intenções do coração. E não há criatura que esteja encoberta à sua
presença.

SOLUÇÃO. — Certos erraram, dizendo que Deus não tem, das coisas, senão conhecimento geral, isto é,
enquanto entes. Pois, assim como o fogo, se se conhecesse a si mesmo como princípio do calor,
conheceria a natureza do calor, e todas as coisas como cálidas, assim Deus, conhecendo-se a si mesmo
como princípio do ser, conhece a natureza do ser e todas as outras coisas, enquanto seres.
Mas, isto não é admissível; pois, inteligir uma coisa em geral e não, em particular, é inteligí-la
imperfeitamente. Por onde, o nosso intelecto, quando passa da potência para o ato, antes de ter das
coisas conhecimento próprio, tem conhecimento universal e confuso, como procedendo do imperfeito
para o perfeito, segundo diz Aristóteles. Por onde, se Deus tivesse dos seres apenas conhecimento geral
e não, especial, seguir-se-ia que o seu inteligir não seria absolutamente perfeito, e, por conseqüência,
nem o seu ser; ora, isto vai contra o já demonstrado. Logo, devemos dizer, que Deus tem das coisas
conhecimento próprio, não só por terem elas a comunidade do ser, mas, enquanto distintas umas das
outras. E, para evidenciá-lo, devemos considerar, que certos, querendo demonstrar que Deus conhece
muitas coisas, usam de exemplos como os seguintes: se um centro se conhecesse a si mesmo
conheceria todas as linhas que dele partem; ou se a luz a si mesma se conhecesse, conheceria todas as
cores.
Mas, estes exemplos, embora tenham certa semelhança, a saber, quanto à causalidade universal, não
colhem, se considerarmos que a multidão e a diversidade não são causadas pelo princípio universal uno,
quanto ao que é princípio de distinção, mas só quanto àquilo pelo que elas têm de comum entre si.
Assim, a diversidade das cores não é causada só pela luz, mas pelas disposições diversas do meio
diáfano que a recebe; e, semelhantemente, a diversidade das linhas é causada pela diversidade das
situações. E daqui vem que a diversidade e a multidão, de que se trata, não podem ser conhecidas no
princípio delas, por conhecimento próprio, mas, só em geral. Mas, com Deus tal não se dá; pois, como já
demonstramos, tudo o que de perfeição existe em qualquer criatura, preexiste e está contido
totalmente nele, de modo excelente. Ora, não é só o que as criaturas têm de comum — o ser — que
pertence à perfeição delas, mas também o pelo que se distinguem umas às outras, como, viver, inteligir,
e outros caracteres pelos quais os seres vivos se distinguem dos não-vivos, e os inteligentes dos não-
inteligentes. Demais, toda forma pela qual uma coisa é constituída na sua espécie própria é uma certa
perfeição. Por onde, todas as coisas preexistem em Deus, não só pelo que é comum a todas, mas
também no pelo que se distinguem.
Assim, pois, contendo Deus em si todas as perfeições, a sua essência está para a essência de todas as
coisas, não como o comum está para o próprio, ou a unidade para os números, ou o centro para as
linhas, mas, como o ato perfeito, para os atos imperfeitos; como se, p. ex., disséssemos que o homem
está para o animal, ou o senário, que é número perfeito, para os números imperfeitos, que ele contém.
Ora, é manifesto que, pelo ato perfeito, podem ser conhecidos os atos imperfeitos, não só em geral,
mas também por conhecimento próprio; assim, quem conhece o homem tem do animal conhecimento
próprio; e quem conhece o número senário, tem do ternário conhecimento próprio. Por onde,
encerrando a essência de Deus, em si, todas as perfeições que tem a essência de qualquer ser, e ainda
mais, Deus em si mesmo pode ter de todas as coisas conhecimento próprio. Ora, a natureza própria de
cada coisa consiste em, de algum modo, participar da perfeição divina. Logo, Deus não se conheceria
perfeitamente a si mesmo, se não conhecesse todos os modos pelos quais a sua perfeição é suscetível
de ser participada pelos outros seres. E, também não conheceria perfeitamente a natureza mesma do
ser, se não conhecesse todos os modos de ser. E, portanto, é manifesto que Deus tem, de todas as
coisas, conhecimento próprio, enquanto que cada uma se distingue das outras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O conhecimento de uma coisa como ela está no sujeito
conhecente, podemos compreendê-lo de duas maneiras.
De uma, o advérbio como implica o modo de conhecer relativamente à coisa conhecida, e, então, o
sentido é falso. Pois, nem sempre o sujeito conhece o objeto conforme o ser que este tem naquele;
assim os olhos não conhecem uma pedra, conforme o ser que esta tem neles; mas, pela espécie da
pedra, que eles têm em si, é que os olhos conhecem a pedra, conforme o ser dela, em si mesma, fora
dos olhos. O sujeito, pois, que conhece um objeto, conforme o ser que este tem, nele, não deixa, por
isso, de conhecê-lo conforme o ser do objeto em si mesmo, fora do sujeito. Assim o intelecto conhece a
pedra, conforme o ser inteligível, que esta tem nele, enquanto o sujeito sabe que conhece; mas, nem
por isso, deixa de conhecer o ser que a pedra tem na sua natureza própria.
Se, porém, entendemos que o advérbio como implica o modo pelo qual o sujeito conhece, então, é
verdade que só o sujeito conhece o objeto do modo pelo qual este nele está; pois, quanto mais
perfeitamente o objeto está no sujeito, tanto mais perfeito é o modo de conhecer. Por onde, devemos
dizer, que Deus, não somente conhece que as coisas nele estão, mas também, porque em si as contém,
conhece-lhes a natureza própria delas, e tanto mais perfeitamente, quanto mais perfeitamente cada
uma nele estiver.

RESPOSTA À SEGUNDA. — A essência da criatura está para a essência de Deus, como o ato imperfeito,
para o perfeito. Por onde, a essência da criatura não conduz suficientemente ao conhecimento da
essência divina, mas, inversamente.

RESPOSTA À TERCEIRA. — Uma mesma realidade não pode ser considerada como a expressão
adequada da essência de coisas diversas. Ora, a essência divina excede todas as criaturas. Por onde,
pode ser considerada como a expressão própria de cada coisa, enquanto susceptível de ser
diversamente participada ou imitada pelas diversas criaturas.

## Art. 7 — Se a ciência de Deus é discursiva.
(Infra, q. 85, a. 5; I Cont. Gent., cap. LV, LVII; De Verit., q. 2, a. 1, ad 4, 5; a. 3, ad 3; a. 13;
Compend. Theol., cap. XXIX; in Iob., cap. XII, lect. II).
O sétimo discute-se assim. — Parece que a ciência de Deus é discursiva.
1 — Pois, a ciência de Deus não é habitual, mas, um conhecimento atual. Ora, segundo o Filósofo,
podemos saber habitualmente muitas coisas ao mesmo tempo; mas conhecer em ato, uma de cada vez.
Logo, como Deus conhece muitas coisas, pois que se conhece a si mesmo e a seres diferentes de si,
segundo se demonstrou, resulta que não conhece a todas simultaneamente, mas discorre de uma para
outra.

2. Demais. — Conhecer os efeitos pela causa é ciência discursiva. Ora, Deus conhece os outros seres por
si mesmo, como o efeito, pela causa. Logo, o seu conhecimento é discursivo.

3. Demais. — Deus conhece cada criatura mais perfeitamente do que nós. Ora, nós, pelas causas criadas
lhes conhecemos os efeitos, e assim, discorremos das causas para os causados. Logo, o mesmo se dá
com Deus.
Mas, em contrário, diz Agostinho: Deus não vê tudo particular ou separadamente como por um
conceito, alternando, daqui para ali e dali para aqui; mas, vê todas as coisas simultâneamente.

SOLUÇÃO. — Na ciência divina não há nenhum discurso, o que assim se demonstra. Na ciência humana
há duplo discorrer: um sucessivo, como quando, depois de conhecermos alguma coisa em ato;
passamos a conhecer outra coisa. Outro, causal, quando, pelos princípios, chegamos ao conhecimento
das conclusões. — Ora, o primeiro modo de discorrer não pode convir a Deus. Pois, se considerarmos,
de per si, muitas das coisas que conhecemos sucessivamente, conheceremos a todas simultaneamente
se as conhecermos numa terceira; p. ex. se conhecemos as partes no todo, ou se vemos no espelho
diversas coisas. Ora, Deus vê todas as coisas num só Ser, que é ele próprio, como já se demonstrou.
Logo, as vê todas simultânea e não, sucessivamente. Também o segundo modo de discorrer não pode
convir a Deus. Primeiro, porque este segundo modo pressupõe o primeiro; pois, os que procedem dos
princípios para as conclusões não consideram a ambos simultaneamente. Em segundo lugar, porque tal
modo é o de quem procede do conhecido para o desconhecido. Donde é manifesto, que quando o
primeiro é conhecido, ainda o segundo é ignorado, e, assim, o segundo não é conhecido no primeiro,
mas pelo primeiro. E o termo do discurso é quando o segundo é visto no primeiro, resolvidos os efeitos
nas causas, cessando, então, o discurso. Logo, Deus, vendo os seus efeitos em si mesmo, como na causa,
o seu conhecimento não é discursivo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora conhecer seja, em si mesmo, um ato único,
contudo, podemos conhecer muitas coisas numa só, como dissemos.

RESPOSTA À SEGUNDA. — Deus não conhece efeitos desconhecidos pela causa como que
primeiramente conhecida; mas os conhece na causa. Logo, o seu conhecimento não é discursivo, como
dissemos.

RESPOSTA À TERCEIRA. — Certamente Deus, muito melhor que nós, vê os efeitos das coisas criadas, nas
próprias causas; não, porém, que o conhecimento dos efeitos nele seja causado pelo conhecimento das
coisas criadas, como em nós. Logo, a sua ciência não é discursiva.

## Art. 8 — Se a ciência de Deus é causa das coisas.
(I Sent., dist. XXXVIII, art. 1; De Verit., q. 2, art. 14).
O oitavo discute-se assim. — Parece que a ciência de Deus não é a causa das coisas.

1. — Pois, Orígenes diz: Não é porque Deus sabe, que alguma coisa será, que ela há-de ser; mas, porque
há-de ser, é que é conhecida por Deus antes que seja.

2. Demais. — Posta a causa, é posto o efeito. Ora, a ciência de Deus é eterna. Se, pois, a ciência de Deus
é a causa das coisas criadas, parece que as criaturas existem abeterno.

3. Demais. — O cognoscível é anterior à ciência; e é a medida dela, como diz Aristóteles. Ora, o que é
posterior e medido não pode ser causa. Logo, á ciência de Deus não é a causa das coisas.
Mas, em contrário, diz Agostinho: Todas as criaturas espirituais e corpóreas, não porque existem, Deus
as conhece, mas, antes existem porque ele as conhece.

SOLUÇÃO. — A ciência de Deus é a causa das coisas. Pois, a sua ciência está para todas as coisas criadas,
assim como a ciência do artífice, para as coisas artificiadas. Ora, a ciência do artífice é a causa dos
artificiados, porque o artífice obra pelo seu intelecto. Donde, é necessário que a forma do intelecto seja
o princípio da operação, como o calor, da calefação. Mas, devemos considerar que a forma natural,
enquanto imanente na coisa à qual dá o ser, não designa um princípio de ação, mas, o princípio pelo
qual tem inclinação para o efeito. Semelhantemente, a forma inteligível não designa um princípio de
ação enquanto existe somente no ser inteligente, se não se lhe acrescenta uma inclinação para o efeito,
o que se realiza pela vontade. Como, porém, a forma inteligível se reporta a realidades contrárias,
objetos de uma mesma ciência, ela não produziria um efeito determinado, se não fosse a tal efeito
determinada pelo apetite, como diz Aristóteles. Ora, é manifesto que Deus, pela sua inteligência, causa
as coisas, pois, o seu ser é a sua ciência; donde, é necessário seja esta a causa das coisas, enquanto junta
com a vontade. Por isso, a ciência de Deus, enquanto causa das coisas, costuma chamar-se ciência de
aprovação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO — Orígenes exprimiu-se atendendo à noção da ciência, com
a qual não convém a noção da causalidade, senão com a vontade adjunta, como se disse. Mas, quando
diz que Deus tem presciência de alguns seres, porque hão-de existir, isso se deve entender
relativamente à causa de conseqüência e não, de ser. Donde se segue, que se alguns seres hão-de
existir, Deus tem deles presciência; contudo, não são os seres futuros a causa de Deus conhecê-los.

RESPOSTA À SEGUNDA. — A ciência de Deus é a causa das coisas, enquanto elas são objeto da sua
ciência. Ora, não está na ciência de Deus que as coisas existissem abeterno. Donde, embora a ciência de
Deus seja eterna, não se segue que abeterno sejam as criaturas.

RESPOSTA À TERCEIRA. — Os seres naturais são meio termo entre a ciência de Deus e a nossa. Pois, nós
derivamos o nosso conhecimento das coisas naturais, das quais Deus é a causa, pela sua ciência. Por
onde, assim como os cognoscíveis naturais são anteriores à nossa ciência e são dela a medida, assim, a
ciência de Deus é-lhes anterior e é deles a medida. Do mesmo modo, uma casa é meio termo entre a
ciência do artífice, que a fez, e a de quem a conhece já feita.

## Art. 9 — Se Deus tem ciência do não-ser.
(I Sent., dist. XXXVIII, a. 4; III, dist. XIV, art. 2, q. 2; I Cont. Gent., cap. LXVI; De Verit., q. 2, art. 8).
O nono discute-se assim. — Parece que Deus não tem ciência do não-ser.

1. — Pois, Deus não tem ciência senão da verdade. Ora, o ser e a verdade convertem-se. Logo, Deus não
tem ciência do não-ser.

2. Demais. — A ciência exige semelhança entre o ciente e o sabido. Ora, o que não existe não pode ter
nenhuma semelhança com Deus, que é o ser mesmo. Logo, o que não existe, não pode ser conhecido
por Deus.

3. Demais. — A ciência de Deus é a causa do que ele conhece. Ora, não há causa do não-ser porque o
não-ser não tem causa. Logo, Deus não tem ciência do que não existe.
Mas, em contrário, diz o Apóstolo (Rm 4, 17): O qual chama as coisas que não são como as que são.

SOLUÇÃO. — Deus conhece todas as coisas de qualquer modo que existam. Pois, nada impede aquelas
coisas, que absolutamente não existem, virem de algum modo, a existir. Ora, existem, absolutamente
falando, as coisas existentes em ato; e as que não existem em ato existem em potência, em relação ou a
Deus mesmo, ou, à criatura. Em potência ativa ou passiva; ou, em potência de opinar, de imaginar, ou
de qualquer outro, modo de significar. Ora, tudo o que pode a criatura fazer, pensar ou dizer, e também
tudo o que, Deus mesmo pode fazer, ele o conhece, ainda que não exista em ato. Logo, pode dizer-se,
que tem ciência, mesmo do não-ser; Mas, há uma certa diversidade a que devemos atender, nas coisas
não existentes em ato. Pois, certas, embora não existam atualmente, contudo, existiram ou hão de
existir; e de todas essas se diz que Deus as conhece pela ciência de visão. Porque, medindo-se o
conhecimento de Deus, que é o seu ser, pela eternidade que, existindo sem sucessão, compreende a
totalidade dos tempos, a intuição presente de Deus abarca essa totalidade temporal e todas as coisas
existentes em qualquer tempo, como seres que lhe estão presentes. Há outras coisas, porém, que estão
no poder de Deus, ou da criatura, e que, contudo, nem existem, nem existirão, nem existiram e, em
relação a essas, não se diz que Deus tem a ciência de visão, mas, a de simples inteligência. E assim
dizemos, porque as coisas, que vemos, têm um ser distinto, fora de nós.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O que não existe em ato, mas, em potência, tem, nessa
mesma medida, a verdade; pois é verdadeiro que existe em potência, e desse modo é conhecido de
Deus.

RESPOSTA À SEGUNDA. — Deus, sendo seu próprio ser, cada ser é, na medida em que participa da
semelhança de Deus, como cada ser é cálido, na medida em que participa do calor. E assim, as coisas
existentes em potência, embora não existam em ato, são conhecidas por Deus.

RESPOSTA À TERCEIRA. — A ciência de Deus é causa das coisas, juntamente com a vontade. Por onde,
não é necessário, que tudo o que Deus sabe, seja, ou fosse, ou haja de ser, mas, somente, aquilo que ele
quer que seja ou permitir que seja. E, logo, não está na ciência de Deus que isso seja, mas que possa ser.

## Art. 10 — Se Deus conhece o mal.
(I Sent., dist. XXXVI, q. 1, a. 2; I Cont. Gent., cap. LXXI; De Verit., q. 2, a. 15, Quodl., XI, q. 2)
O décimo discute-se assim. — Parece que Deus não conhece o mal.

1. — Pois, diz o Filósofo, que o intelecto, que não está em potência, não conhece a privação. Ora, o mal
é a privação do bem, como diz Agostinho. Logo, como a inteligência de Deus nunca está em potência,
mas, sempre em ato, como do sobredito se colhe, conclui-se que Deus não conhece o mal.

2. Demais. — Toda ciência, ou é causa do que é sabido, ou é por este causada. Ora, a ciência de Deus
não é causa do mal, nem pelo mal é causada. Logo, Deus não tem ciência do mal.

3. Demais. — Tudo o que é conhecido o é, ou por semelhança, ou por oposição. Ora, tudo o que Deus
conhece o conhece pela sua ciência, como resulta do já dito. Mas, a essência divina nem é semelhança
do mal, nem o mal se lhe opõe; pois, nada é contrário à essência divina, como diz Agostinho. Logo, Deus
não conhece o mal.

4. Demais. — O conhecido por meio de outra coisa, e não, por si mesmo, é conhecido imperfeitamente.
Ora, o mal não é conhecido de Deus em si mesmo, porque, então haveria de estar em Deus; pois,
necessariamente o conhecido está no conhecente. Logo, o mal, sendo conhecido por outra coisa, i. é,
pelo bem, é conhecido imperfeitamente, o que é impossível, porque nenhum conhecimento de Deus é
imperfeito. Logo, Deus não tem ciência do mal.
Mas, em contrário, a Escritura (Pr 15, 11): O inferno e a perdição estão diante do Senhor.

SOLUÇÃO. — Quem quer que conheça alguma coisa perfeitamente deve conhecer tudo o que lhe diga
respeito. Ora, há certas coisas boas, que podem ser corrompidas pelo mal. Logo, Deus não as conheceria
perfeitamente se também não conhecesse o mal. Pois, um ser é cognoscível na medida em que é; e,
sendo a essência do mal a privação do bem, pelo mesmo conhecer Deus o bem, conhece também o mal,
como pela luz se conhecem as trevas. Por isso, diz Dionísio: Deus por si mesmo tem a visão das trevas,
não as vendo senão pela luz.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Devemos entender a expressão do Filósofo do seguinte
modo. O intelecto, que não está em potência, não conhece a privação, pela privação em si existente; e
isso concorda com o que dissera antes, que o ponto, e todo indivisível é conhecido pela privação da
divisão. E tal se dá porque as formas simples e indivisíveis não existem em ato na nossa inteligência,
mas, somente em potência; pois, se existissem em ato em nossa inteligência, não seriam conhecidas
pela privação. E é assim que os seres simples são conhecidos pelas substâncias separadas. Deus,
portanto não conhece o mal por uma privação nele existente, mas pelo bem oposto.

RESPOSTA À SEGUNDA. — A ciência de Deus não é a causa do mal, mas é a do bem, pelo qual é
conhecido o mal.

RESPOSTA À TERCEIRA. — Embora o mal não se oponha à essência divina, que não é corruptível por ele,
opõe-se, contudo, aos efeitos de Deus, que Deus conhece pela sua essência e, conhecendo-os, conhece
os males opostos.

RESPOSTA À QUARTA. — Conhecer uma coisa somente por meio de outra é um conhecimento
imperfeito, se essa coisa for cognoscível em si mesma. Ora, o mal não é cognoscível em si mesmo,
porque é, por essência, privação do bem; e, assim, não pode ser definido nem conhecido a não ser pelo
bem.

## Art. 11 — Se Deus conhece o singular.
(I Sent., dist. XXXVI, q. 1, a. 1; II, dist. III, q. 2, a. 3; I Cont. Gent., cap. L, LXIII, LXV; Qu. Disp. De Anima, a.
20; De Verit., q. 2, a. 5; Compend. Theol., cap. XXXXIII; I Periherm., lect. XIV).
O undécimo discute-se assim. — Parece que Deus não conhece o singular.

1. — Pois, o intelecto divino é mais imaterial do que o intelecto humano. Ora, o intelecto humano, por
causa da sua imaterialidade, não conhece os seres singulares. Porque, como diz Aristóteles, a razão
atinge o universal, e os sentidos, o particular. Logo, Deus não conhece o singular.

2. Demais. — Só conhecem o singular as nossas potências que recebem as espécies não separadas das
condições materiais. Ora, em Deus, as coisas são, em sumo grau, separadas de toda a materialidade.
Logo, ele não conhece o singular.

3. Demais. — Todo o conhecimento se realiza por alguma semelhança. Ora, a semelhança do singular,
como tal, parece não estar em Deus; porque o princípio da singularidade é a matéria, que, como ser
puramente potencial, é por completo dissemelhante de Deus, ato puro. Logo, Deus não pode conhecer
o singular.
Mas, em contrário, a Escritura (Pr 16, 2): Todos os caminhos dos homens estão patentes aos seus olhos.

SOLUÇÃO. — Deus conhece o singular. Pois, todas as perfeições, que se encontram nas criaturas,
preexistem em Deus de maneira eminente, como do sobredito resulta. Ora, de conhecer o singular é
capaz a nossa perfeição. Logo, necessariamente, Deus há de conhecê-lo também. Pois, o Filósofo
considera inconveniente que alguma coisa seja conhecida de nós e o não seja de Deus; e daí,
argumentando contra Empédocles, conclui que Deus seria insipientíssimo se ignorasse a discórdia. Ora,
as perfeições existentes, divididas nos seres inferiores, existem em Deus, unida e simplesmente. Por
onde, embora nós conheçamos, por uma faculdade, os seres universais e imateriais e, por outra, os
singulares e materiais, Deus, pela sua simples inteligência, conhece a ambos.
Alguns, entretanto, querendo explicar como isso pode ser, disseram, que Deus conhece o singular, por
causas universais. Pois, nada há em qualquer ser singular, que não seja originado de alguma causa
universal. E põem para exemplo: um astrólogo que conhecesse todos os movimentos universais do céu,
poderia pré-anunciar todos os eclipses futuros. — Mas, isto não basta; porque os seres singulares
participam, pelas causas universais, de certas formas e virtudes que, embora unidas entre si, não se
individuam senão pela matéria individual. Por isso, quem conhecesse Sócrates, como branco, ou filho de
Sofrónisco, ou qualquer outra modalidade, como essas, não o conheceria como um determinado
homem. Donde, do referido modo, Deus não conheceria os seres singulares, na singularidade deles.
Outros, porém, disseram, que Deus conhece os seres singulares aplicando causas universais a efeitos
singulares. — Mas, não é tal, porque ninguém pode aplicar uma coisa à outra, sem ter conhecimento
prévio da primeira. — Logo, a referida aplicação não pode ser a razão de conhecer os seres particulares,
mas, pressupõe o conhecimento destes.
E, portanto devemos dizer, diferentemente, que, sendo Deus a causa das coisas, pela sua ciência, como
estabelecemos, a tanto se estende esta, a quanto se estende a sua causalidade. Portanto, a virtude ativa
de Deus, estendendo-se não somente às formas, das quais deriva a noção universal, mas também, até à
matéria, como se mostrará em seguida, é necessário, que a ciência de Deus se estenda até aos seres
singulares, individuados pela matéria. Pois, Deus, conhecendo, pela sua essência, os seres diferentes de
si, enquanto ela é semelhança das coisas, ou princípio ativo delas, necessariamente a sua essência será
o princípio suficiente de conhecer tudo o que faz, não somente em universal, mas também,
singularmente. E o mesmo se daria com a ciência do artífice, se fosse produtiva da coisa total e não, da
forma somente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A nossa inteligência abstrai a espécie inteligível dos
princípios individuantes. Por isso, a espécie inteligível do nosso intelecto não pode ser semelhança dos
princípios individuais, e por isso não conhece os seres singulares. Mas, a espécie inteligível do intelecto
divino, que é a essência de Deus, não é imaterial, por abstração, mas, por si mesma; e existe como
princípio de todos os princípios, que entram na composição dos seres, quer sejam princípios da espécie,
quer do indivíduo. E assim, por ela, Deus conhece, não somente o universal, mas também o singular.

RESPOSTA À SEGUNDA. — Embora a espécie do intelecto divino, na sua essência mesma, não esteja
sujeita a condições materiais, como as espécies recebidas pela imaginação e pelos sentidos, contudo,
pela sua Virtude, estende-se aos seres materiais e imateriais, como foi dito.

RESPOSTA À TERCEIRA — A matéria, embora se afaste da semelhança com Deus, pela sua
potencialidade, contudo, enquanto tem o ser potencial, conserva uma certa semelhança com o ser
divino.

## Art. 12 — Se Deus pode conhecer infinitos seres.
(Sent., dist. XXXIX, q. 1, a. 3; I Cont. Gent., cap. LXIX; De Verit., q. 2, a. 9; q. 20, a. 4, ad 1; Quodl., III, q. 2,
a. 1; Compend.Theol., cap. XXXIII)
O duodécimo discute-se assim. — Parece que Deus não pode conhecer infinitos seres.

1. — Pois, o infinito, como tal é desconhecido porque o infinito é aquilo além do que podemos sempre
continuar a tomar algo de novo quantitativamente, como diz Aristóteles. E Agostinho também diz, que
tudo o que écompreendido pela ciência é limitado pela compreensão do ciente. Ora, o infinito não pode
ser limitado. Logo, não pode ser compreendido pela ciência de Deus.

2. Demais. — Se se disser que o infinito, em si mesmo, é finito para a ciência de Deus, objeta-se em
contrário: é da essência do infinito ser intransponível, como diz Aristóteles. Ora, o infinito não pode ser
percorrido, nem pelo finito, nem pelo infinito, como ainda o prova Aristóteles. Logo, o infinito não pode
ser finito para o finito, nem para o infinito; e portanto o infinito não é finito para a ciência de Deus, que
é infinita.

3. Demais. — A ciência de Deus é a medida das coisas conhecidas. Ora, é contra a essência do infinito
ser medido. Logo, o infinito não pode ser conhecido de Deus.
Mas, em contrário, diz Agostinho: embora não haja nenhum número de números infinitos, contudo, não
é incompreensível àquele cuja ciência não tem número.

SOLUÇÃO. — Deus conhece não só o ato, mas também o que está no seu poder ou no da criatura, como
já demonstramos. Ora, como isso é infinito, devemos concluir que Deus conhece o infinito.
E embora a ciência da visão, cujo objeto são somente as coisas que existem, existirão, ou existiram, não
conheça, como alguns dizem, o infinito, — pois, não supomos o mundo abeterno, nem que a geração e
o movimento hão de permanecer eternamente, para que os indivíduos se multipliquem ao infinito —
contudo, uma consideração mais diligente nos levará necessariamente a dizer que Deus conhece o
infinito, mesmo pela ciência de visão. Pois, Deus conhece também as cogitações e as afeições dos
corações, que se multiplicarão ao infinito, se permanecerem sem fim as criaturas racionais.
E isto é assim, porque o conhecimento de qualquer sujeito se estende conforme o modo da forma, que
é o princípio do conhecimento. Pois, a espécie sensível, que está no sentido, tem semelhança de um só
indivíduo, e, portanto, por ela, pode ser conhecido só um indivíduo. Porém a espécie inteligível do nosso
intelecto é semelhante da coisa, na sua natureza específica, participável por infinitos seres particulares.
Por onde, o nosso intelecto, pela espécie inteligível do homem, conhece, de certo modo, infinitos
homens; não, enquanto se distinguem uns dos outros, mas enquanto comunicam pela natureza
específica. E isto, porque a espécie inteligível do nosso intelecto não tem semelhança dos homens,
quanto aos princípios individuais, mas somente quanto aos princípios específicos. Ora, a essência divina
pela qual o intelecto divino intelige, tem semelhança suficiente de todas as coisas, que existem, ou
podem existir, não somente quanto aos princípios comuns, mas também quanto aos próprios, de cada
ser, como já se demonstrou. Donde se segue, que a ciência de Deus se estende a seres infinitos, mesmo
enquanto distintos uns dos outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O infinito é relativo à quantidade, segundo o Filósofo.
Ora, é da essência da quantidade conter partes ordenadas. Portanto, conhecer o infinito, como tal, é
conhecer uma parte após outra. Ora, assim, de nenhum modo pode ser conhecido o infinito, porque,
por maior quantidade das partes, que se suponha, sempre é possível acrescentar mais uma. Ora, Deus
não conhece o infinito, como enumerando-lhe parte por parte, pois, conhece todas as coisas,
simultaneamente, sem sucessão, como já dissemos. Por isso, nada o impede de conhecer o infinito.

RESPOSTA À SEGUNDA. — A transição importa numa certa sucessão de partes; donde vem, que o
infinito não pode ser percorrido, nem pelo finito nem pelo infinito. Mas, para haver compreensão, basta
a adequação, pois dizemos que uma coisa é compreendida, quando nada dela foge à nossa
compreensão. Donde, não é contra a noção do infinito o ser compreendido pelo infinito. E, assim, o
infinito, em si mesmo, pode ser considerado finito, para a ciência de Deus, como compreendido, não,
porém, como transponível.

RESPOSTA À TERCEIRA. — A ciência de Deus é a medida das coisas; não, quantitativa, pois, o infinito
carece de tal medida, mas porque mede a essência e a verdade delas. Pois, cada ser tem a verdade, na
sua natureza, na medida em que imita a ciência de Deus, como o artificiado, enquanto concorda com a
arte. Dado, porém, que existissem alguns seres numericamente infinitos, em ato — p. ex., homens
infinitos; ou segundo a quantidade contínua, como se o ar fosse infinito, conforme alguns antigos
disseram, contudo, é manifesto que teriam o ser determinado e finito, porque a essência deles seria
limitada a algumas naturezas determinadas. Donde, seriam mensuráveis pela ciência de Deus.

## Art. 13 — Se Deus tem ciência dos futuros contingentes.
(Infra, q. 86, a. 4; I Sent., dist. XXXVIII, a. 5; I Cont. Gent., cap. LXVII; De Verit., q. 2, a. 12; De Malo, q. 16
a. 7; Quodl., XI, q. 3; Opusc., II, Contra Graecos, Armênios, etc., cap. X; Compend. Theol., cap. CXXXIII; I
Periherm., lect. XIV).
O décimo terceiro discute-se assim. Parece que Deus não tem ciência dos futuros contingentes.

1. — Pois, de causa necessária procede efeito necessário. Ora, a ciência de Deus é causa das coisas
conhecidas, como se disse. Mas, sendo necessária, também será o que sabe, necessário. Logo, Deus não
tem ciência do contingente.

2. Demais. — De toda condicional, cujo antecedente é absolutamente necessário, o conseqüente
também o é; pois, o antecedente está para o conseqüente, como os princípios, para a conclusão. Ora, de
princípios necessários não resulta senão conclusão necessária, como o prova Aristóteles. Mas, a
seguinte proposição é uma condicional verdadeira: se Deus sabe que um contingente existirá, ele há de
existir. Porque a ciência de Deus não tem por objeto senão a verdade. Ora, o antecedente desta
condicional é absolutamente necessário, tanto por ser eterno, como por ser expresso no pretérito. Logo,
também o conseqüente é absolutamente necessário. Portanto, tudo o que é sabido por Deus é
necessário; e, assim, ele não tem ciência dos contingentes.

3. Demais. — Necessariamente, tudo o que é sabido por Deus, existe, porque também tudo o que nós
sabemos ser necessário existe; pois, a ciência de Deus é mais certa que a nossa. Ora, não existe
necessariamente nenhum futuro contingente. Logo, nenhum futuro contingente é conhecido de Deus.
Mas, em contrário, diz o salmista (Sl 32, 15): Deus, que formou o coração de cada um deles, entende
todas suas obras, i. é, dos homens. Ora, as obras dos homens, estando sujeitas ao livre arbítrio, são
contingentes. Logo, Deus conhece os futuros contingentes.

SOLUÇÃO. — Como já demonstramos, Deus sabe, não somente tudo o que existe, em ato, mas também
tudo o que está no seu poder ou no da criatura. Ora, como destas coisas umas são, para nós, futuros
contingentes, segue-se que Deus conhece esses futuros.
Para evidenciá-lo, devemos ponderar, que qualquer contingente pode ser considerado à dupla luz.
Primeiro, em si mesmo, enquanto já atual. E, então, não é tido como futuro, mas, como presente; nem
como contingente, em relação a qualquer de duas atualizações, mas, como determinado por uma. Por
isso, pode ser infalivelmente objeto de um conhecimento certo, por ex., do sentido da vista, como
quando vejo Sócrates sentar-se. De outro modo, pode ser considerado o contingente como existe na sua
causa, e, então, é tido como futuro e como contingente ainda não determinado por uma atualização;
porque, a causa contingente, podendo tender para termos opostos, o contingente não é objeto de
nenhum conhecimento. Por onde, quem conhece o efeito contingente, somente na sua causa, tem dele
conhecimento apenas conjetural. Ora, Deus conhece todos os contingentes, não só enquanto existentes
nas suas causas, mas também enquanto cada um deles existe em si mesmo.
Embora, porém, os contingentes se atualizem sucessivamente, Deus não os conhece, como nós,
sucessivamente, tais como são, mas simultaneamente. Porque o seu conhecimento, como o seu ser,
mede-se pela eternidade; e a eternidade, existindo toda simultaneamente, abrange o tempo todo,
como já dissemos. Donde, tudo o que existe no tempo é abeterno presente a Deus; não somente
porque ele encerra as razões das coisas, para si presentes, como alguns dizem, mas, porque a sua
intuição projeta-se abeterno sobre tudo, enquanto existente na sua presencialidade.
Por onde, é manifesto que os contingentes infalivelmente são conhecidos por Deus, enquanto objetos
do divino olhar, que os tem como na sua presença. E, contudo, são futuros contingentes, referidos às
suas causas próximas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a causa suprema seja necessária, contudo, o seu
efeito pode ser contingente, em virtude da causa próxima contingente. Assim, a germinação da planta é
contingente, pela causa próxima, embora o movimento do sol, que é a causa primeira, seja necessária.
Semelhantemente, o que Deus sabe é contingente, pelas causas próximas, embora a ciência de Deus,
que é a causa primeira seja necessária.

RESPOSTA À SEGUNDA. — Uns dizem que o antecedente — Deus soube que um determinado
contingente há de existir — não é necessário, mas, contingente; pois, embora pretérito, diz respeito ao
futuro. — Mas, isso não lhe tira a necessidade, porque aquilo que dizia respeito ao futuro,
necessariamente o disse, embora, às vezes, o futuro não se realize.
Outros, porém, dizem, que esse antecedente é contingente, por ser composto de necessário, e de
contingente, como é contingente a afirmação — Sócrates é um homem branco. — Mas, também isto
não é verdade, porque quando dizemos — Deus soube que um determinado contingente há de existir —
contingente é posto, aí, como objeto do verbo, e não, como parte principal da proposição. Portanto, a
sua contingência ou a sua necessidade em nada influem para a proposição ser necessária ou
contingente, verdadeira ou falsa. Pois, tanto pode ser verdade ter eu dito que o homem é asno, como,
que Sócrates corre, ou Deus existe; a mesma sendo a essência do necessário e a do contingente.
Portanto, devemos concluir, que o antecedente é absolutamente necessário. Mas daí não resulta, como
querem alguns, que o conseqüente também, o seja, por ser o antecedente a causa remota dele, o qual,
pela sua causa próxima é contingente. — Pois, tal não é verdade, porque então seria falsa a condicional,
cujo antecedente fosse causa remota necessária, e cujo conseqüente, um efeito contingente; como, p.
ex., se eu dissesse: se o sol se move, a erva germinará.
E, portanto, devemos dizer, diferentemente, que, quando no antecedente se inclui o que pertence a um
ato da alma, devemos tomar o conseqüente, não como ele em si mesmo é, mas, como está na alma.
Pois um é o ser da coisa, em si mesma, e outro, o que tem na alma; assim, se eu disser — se a alma
inteligir um objeto, esse é imaterial — deve-se compreender que tal objeto é imaterial, segundo está no
intelecto; não, segundo o que em si mesmo é. Semelhantemente, se disser — se Deus conheceu uma
coisa, ela existirá — deve-se compreender o conseqüente como objeto da ciência de Deus, i. é,
enquanto lhe é presente. E então, é necessário, como o seu antecedente; porque, tudo o que existe,
enquanto existir, existe necessariamente, como diz Aristóteles.

RESPOSTA À TERCEIRA. — O que se atualiza no tempo é por nós sucessivamente conhecido nele; mas,
por Deus, na eternidade, que é superior ao tempo. Donde, para nós, que os conhecemos como tais, os
futuros contingentes não podem ser certos; mas o são só para Deus, cujo inteligir está na eternidade,
acima do tempo. Assim, quem vai por um caminho não vê os que lhe vêem atrás; mas, quem olhar todo
o caminho, de uma certa altura, vê, ao mesmo tempo todos os que por ele transitam. E portanto, o que
nós sabemos há de ser necessário ainda considerado no que em si mesmo é; porque os futuros
contingentes não podemos conhecê-los.
As coisas, porém, sabidas de Deus, devem ser necessárias, pelo modo por que são objetos da ciência
divina, como dissemos; não porém, absolutamente, enquanto considerados nas suas causas próprias.
Donde, na proposição — é necessário, que tudo o que é sabido de Deus exista. — costuma-se distinguir.
Pois, pode referir-se à realidade ou à afirmação. Entendida no real,é dividida e falsa, e o sentido é —
toda realidade que Deus conhece é necessária. Entendida da afirmação, é composta e verdadeira, e o
sentido é — esta afirmação, o que é sabido por Deus existe, é necessária.
Mas, alguns objetam, que essa distinção tem lugar nas formas separáveis da matéria, como se disser —
é possível o branco ser preto. O que é certamente falso, quanto à afirmação, mas verdadeiro, quanto à
realidade; pois, uma coisa branca pode ser preta. Ao contrário, esta afirmativa — o branco é preto —
nunca pode ser verdadeira. Porém, nas formas inseparáveis da matéria, tal distinção não tem lugar,
como se dissesse — é possível um corvo preto ser branco. Porque, em ambos os sentidos, tal afirmação
é falsa.
Ora, o ser sabido de Deus é inseparável da realidade, porque o que é sabido de Deus não pode ser não-
sabido. — Esta instância teria lugar se o que chamo — sabido — importasse alguma disposição inerente
ao sujeito. Mas, como importe o ato do ciente, à realidade mesma sabida, embora sempre o seja, pode-
se-lhe atribuir, em si mesma, algo que não se lhe atribui enquanto depende do ato do ciente. Assim, o
ser material é atribuído à pedra em si, que não lhe é atribuído enquanto inteligível.

## Art. 14 — Se Deus conhece os enunciáveis.
(I Sent., dist. XXXIII, a. 3; dist. XLI, a. 5; I Cont. Gent., cap. LVIII, LIX; De Verit., q. 2, a. 7).
O décimo quarto discute-se assim. — Parece que Deus não conhece os enunciáveis.

1. — Pois, conhecer os enunciáveis é próprio da nossa inteligência, enquanto compõe e divide. Ora, no
intelecto divino não há nenhuma composição. Logo, Deus não conhece os enunciáveis.

2. Demais. — Todo conhecimento se realiza por alguma semelhança. Ora, em Deus, não há nenhuma
semelhança dos enunciáveis, pois, é absolutamente simples. Logo, Deus não conhece os enunciáveis.
Mas, em contrário, a Escritura (Sl 93, 11): O Senhor conhece os pensamentos dos homens. Ora, os
enunciáveis existem no pensamento dos homens. Logo, Deus conhece os enunciáveis.

SOLUÇÃO. — Como está no poder do nosso intelecto formar os enunciáveis, e como Deus sabe tudo o
que está no seu poder, ou no da criatura, como dissemos, é necessário Deus conheça todos os
enunciáveis, que podemos formular. Mas, como ele conhece as coisas materiais, imaterialmente, e as
compostas, simplesmente, assim, conhece os enunciáveis não como tais, de maneira que haja no seu
intelecto a composição ou a divisão deles; senão que conhece cada um por simples inteligência,
inteligindo-lhes a essência. Como se nós, por isso mesmo que inteligimos o que é o homem,
inteligíssemos tudo o que do homem se pode predicar. O de que não é capaz a nossa inteligência, que
discorre de um termo para outro; pois, a espécie inteligível representa um objeto, porque não
representa outro. Por isso, inteligindo o que é o homem, não inteligimos ao mesmo tempo, mas, numa
certa sucessão, o mais que nele existe; donde, o que inteligimos separada e divididamente, é necessário
reduzi-lo à unidade, compondo e dividindo, formando assim a enunciação. Ora, a espécie do intelecto
divino, i. é, a sua essência, basta para explicar tudo; por isso, inteligindo a sua essência, conhece as
essências de todas as coisas, e tudo o de que são susceptíveis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procederia se Deus conhecesse os
enunciáveis, como tais.

RESPOSTA À SEGUNDA. — A composição do enunciável significa alguma realidade do objeto; e, assim,
Deus, pelo seu ser, que é a sua essência, é semelhança de tudo aquilo significado pelos enunciáveis.

## Art. 15 — Se a ciência de Deus é variável.
(I Sent., dist. XXXVIII, art. 2; dist. XXXIX, q. 1, a. 1, 2; dist. XLI, a. 5; De Verit., q. 2, a. 5, ad 2; a. 13).
O décimo quinto, discute-se assim. — Parece que a ciência de Deus é variável.

1. — Pois, a ciência é considerada relativamente ao cognoscível. Ora, aquilo que importa relação com a
criatura predica-se de Deus temporal e variavelmente, segundo a variação das criaturas. Logo, a ciência
de Deus é variável, segundo a variação das criaturas.

2. Demais. — Quem pode fazer muitas coisas, também pode conhecê-las. Ora, Deus pode fazer mais
coisas, do que as que faz. Logo, pode conhecer mais do que as que conhece. E, portanto, a sua ciência
pode variar, por aumento e diminuição.

3. Demais. — Deus soube que Cristo havia de nascer. Agora, porém, não sabe que Cristo há de nascer,
porque Cristo já não deve nascer. Logo, nem tudo o que Deus soube, sabe; é portanto, a ciência de Deus
é variável.
Mas, em contrário, a Escritura (Tg 1, 17): Em Deus, não há mudança nem sombra alguma de variação.

SOLUÇÃO. — Sendo a ciência de Deus a sua substância, como resulta do que já foi dito, e sendo a sua
substância absolutamente imutável, como já se demonstrou, resulta necessariamente, que a sua ciência
é absolutamente invariável.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As expressões — Senhor, Criador e semelhantes —
implicam relações com as criaturas, como tais. Mas, a ciência de Deus implica relação com elas, do
modo pelo qual existem em Deus; pois, é por estar no ser, que intelige, que um objeto é inteligido, em
ato. Ora, as coisas criadas estão, em Deus, invariavelmente; em si mesmas, porém, variavelmente. —
Ou, devemos responder, de outro modo, que — Senhor, Criador e expressões semelhantes — implicam
relações conseqüentes a atos, que se entendem como terminados nas criaturas; como elas em si
mesmas existem; e, portanto, tais relações predicam-se variavelmente de Deus, conforme a variação
das criaturas. Ao passo que a ciência, o amor e causas semelhantes implicam relações conseqüentes a
atos, que se entendem como existentes em Deus e, por isso, dele se predicam invariavelmente.

RESPOSTA À SEGUNDA. — Deus conhece mesmo aquilo que pode fazer e não faz. Mas, de poder fazer
mais do que faz não se deduz que possa saber mais do que sabe; salvo se nos referirmos à ciência da
visão, pela qual dizemos que sabe o que existe em ato, num determinado tempo. Porém, de saber que
podem existir coisas, que não existem, ou não existirem, que existem, não se conclui que a sua ciência
seja variável, mas sim, que conhece a variabilidade das coisas. Se existisse, ao contrário, alguma coisa
cujo ser Deus antes não conhecesse, e depois viesse a conhecer, então a sua ciência seria variável. Ora,
tal não pode dar-se, porque tudo o que existe ou pode existir em qualquer tempo, Deus o sabe, no seu
ser eterno. E, portanto, desde que se admita que alguma coisa pode existir, num determinado tempo, é
necessário admitir-se como sabida por Deus abeterno. Logo, não se deve conceder que Deus possa
saber mais do que sabe, porque tal proposição implica que, antes, não soubesse o que depois veio a
saber.

RESPOSTA À TERCEIRA. — Os antigos Nominalistas disseram, que é o mesmo enunciável — Cristo
nascer, haver de nascer e haver nascido — porque essas três proposições têm a mesma significação: a
natividade de Cristo. E de tal opinião resulta, que Deus sabe tudo o que soube; pois, o saber agora que
Cristo nasceu, significa-lhe o mesmo que Cristo haverá de nascer. — Mas esta opinião é falsa, tanto
porque a diversidade das partes da oração causa a diversidade dos enunciáveis, como porque dela
resultaria, que uma proposição verdadeira, uma vez, sê-lo-ia sempre, o que vai contra o Filósofo, que diz
que a oração — Sócrates está sentado — é verdadeira, estando ele sentado, e falsa, quando se levanta.
— Logo, devemos pensar que a proposição —tudo o que Deus soube, sabe — não é verdadeira,
referente aos enunciáveis. Mas, daí não se segue que a ciência de Deus seja variável. Pois, como Deus,
sem variação da sua ciência, sabe que um mesmo ser, ora é, e, ora, não, assim sem variação essa mesma
ciência sabe, que um enunciável, ora, é verdadeiro, e, ora, falso. Mas, a ciência de Deus seria variável se
conhecesse os enunciáveis como tais, compondo e dividindo, como acontece com a nossa inteligência.
E, por isso, o nosso conhecimento varia, segundo a verdade ou a falsidade; p. ex., se, mudada a
realidade, conservamos dela a mesma opinião; ou segundo as diversas opiniões, como se, primeiro,
disséssemos que alguém está sentado, e, em seguida, que não. Ora, nada disso se pode dar com Deus.

## Art. 16 — Se Deus tem ciência especulativa das coisas.
(De Verit., q. 3, a. 3).
O décimo sexto discute-se assim. — Parece que. Deus não tem, das coisas, ciência especulativa.

1. — Pois, a ciência de Deus é a causa das coisas, como antes foi demonstrado. Ora, a ciência
especulativa não é a causa das coisas sabidas. Logo, a ciência de Deus não é especulativa.

2. Demais. — A ciência especulativa nasce da abstração das coisas, o que não convém à ciência divina.
Logo, a ciência de Deus não é especulativa.
Mas, em contrário, tudo o que é mais nobre devemos atribuir a Deus. Ora, a ciência especulativa é mais
nobre que a prática, como está claro no Filósofo. Logo, Deus tem das coisas ciência especulativa.

SOLUÇÃO. — Há uma ciência, que é somente especulativa; outra, somente prática; outra, enfim,
especulativa, num ponto de vista, e prática, em diverso.
Para evidenciá-lo devemos saber, que qualquer ciência pode ser considerada especulativa, de tríplice
modo. Primeiro, quanto às coisas sabidas, que não são realizáveis por quem as conhece; tal a ciência
humana das coisas naturais, ou das divinas. Segundo, quanto ao modo de conhecer; p. ex., se o
construtor considerar uma casa, definindo e dividindo e considerando os predicados universais da
mesma. O que é, por certo, considerar, de modo especulativo, o que é objeto de prática, e não,
enquanto tal objeto. Pois, o praticável é tal, pela aplicação de uma forma à matéria, e não, pela
resolução. do composto aos princípios formais universais. Terceiro, quanto ao fim; pois, o intelecto
prático difere, pelo fim, do especulativo, como diz Aristóteles. Porque o intelecto prático ordena-se ao
fim da operação, ao passo que o fim do intelecto especulativo é a consideração da verdade. Donde, o
construtor que examinasse como uma casa possa ser feita, não a ordenando ao fim da operação, mas,
somente ao do conhecimento, a examinaria especulativamente, quanto ao fim, e contudo, a respeito de
um objeto de uma operação. Portanto, a ciência especulativa, em razão da própria coisa conhecida, é
somente especulativa. A especulativa, porém, pelo modo ou pelo fim, é de certa maneira, especulativa,
e de certa outra, prática. Quando porém, ordenada ao fim da operação, é prática, pura e simplesmente.
Segundo, pois, o que acaba de ser exposto, devemos concluir, que Deus tem, de si mesmo, somente a
ciência especulativa, pois não é objeto de operação. Mas, de todos os outros seres, a tem especulativa e
prática. Especulativa, quanto ao modo; pois, tudo o que nas coisas nós conhecemos especulativamente,
definindo e dividindo, tudo isso Deus conhece muito mais perfeitamente. Daquelas coisas, porém, que
pode certamente fazer, sem que as faça em tempo nenhum, não tem ciência prática, enquanto que tal
ciência tira a sua denominação do fim. Assim, pois, tem ciência prática daquilo que faz num
determinado tempo. Quanto ao mal, embora não possa praticá-lo, contudo tem dele conhecimento
prático, como o tem do bem, permitindo-o, impedindo-o, ou ordenando-o. Assim, as doenças não
compreende a ciência prática do médico, que as cura com a sua arte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A ciência de Deus é causa, não certamente de si mesmo,
mas dos outros seres. De uns, i. é, daqueles que são feitos, num tempo determinado, em ato; e doutros,
i. é, daqueles que pode fazer, embora nunca venha a fazê-los, pelo seu poder.

RESPOSTA À SEGUNDA. — O ser a ciência oriunda das coisas conhecidas não convém à ciência
especulativa, como tal, mas, por acidente, enquanto humana.

RESPOSTA AO OBJETADO EM CONTRÁRIO. — Respondemos: não há ciência perfeita das coisas
praticáveis, senão enquanto conhecidas como tais. Por onde, sendo a ciência de Deus, a todos os
respeitos, perfeita, necessariamente conhece as coisas que pode fazer, como tais, e não somente,
enquanto objeto de especulação. E contudo, nada perde da nobreza da ciência especulativa, porque vê
todas as coisas diferentes de si, em si mesmo, a quem conhece especulativamente. Por onde, pela
ciência especulativa de si mesmo, tem conhecimento especulativo e prático de todos os outros seres.