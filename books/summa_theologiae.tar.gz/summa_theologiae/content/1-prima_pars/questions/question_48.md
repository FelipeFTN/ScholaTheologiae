# Questão 48: Da distinção das coisas em especial.
Em seguida devemos tratar da distinção das coisas em especial. E em primeiro lugar, da distinção do
bem e do mal; depois, da distinção entre a criatura espiritual e a corporal.
Sobre o primeiro ponto, devemos estudar o mal e a sua causa. Sobre o mal seis artigos se discutem:

## Art. 1 — Se o mal é alguma natureza.
(II Sent., dist. XXXIV, a. 2; III Cont. Gent., cap. VII sqq.; De Malo. q. 1, a. 1; Compend. Theol., cap. CXV; De
Div. Nom., cap. IV, lect XIV).
O primeiro discute-se assim. – Parece que o mal é uma certa natureza.

1. – Pois, todo gênero é alguma natureza. Ora, o mal é um gênero e, por isso, diz Aristóteles, que o bem
e omal não estão em um gênero, mas são gêneros de outros seres. Logo, o mal tem uma certa natureza.

2. Demais. – Toda diferença constitutiva de uma certa espécie é uma natureza. Ora, em moral, o mal é
uma diferença constitutiva; pois, o hábito mau difere especificamente do bom como a liberalidade, da
iliberalidade. Logo, o mal significa uma certa natureza.

3. Demais. – Cada um de dois contrários significa uma certa natureza. Ora, o mal e o bem não se opõem
como a privação ao hábito, mas como contrários, conforme prova o Filósofo; por haver entre o bem e o
mal um certo meio e por ser possível a volta do mal para o bem. Logo, o mal exprime uma certa
natureza.

4. Demais. – O que não é não age. Ora, o mal age, porque corrompe o bem. Logo, o mal é um certo ente
e uma certa natureza.

5. Demais. – Para a perfeição do universo só pode concorrer o que é ser e natureza. Ora, o mal concorre
para tal perfeição, segundo diz Agostinho: De todas as coisas compõe-se a admirável beleza do universo;
na qual, mesmo o que se chama mal, quando bem ordenado e no seu lugar, mais eminentemente
realça o bem. Logo, o mal é uma certa natureza.
Mas, em contrário,diz Dionísio: o mal não é existente, nem é bom.

SOLUÇÃO. – Um contrário se conhece pelo outro; assim, pela luz as trevas. Poronde, também se deve
concluir o que seja o mal pela natureza do bem. Ora, já antes dissemos que bem é tudo o que é apetível.
E assim, buscando toda natureza o seu ser e a sua perfeição, necessariamente resulta que o ser e a
perfeição de cada natureza têm razão de bondade. Por onde, não é possível que o mal exprima um ser,
uma certa forma ou natureza. E logo conclui-se que a palavra mal exprime uma certa ausência de bem.
Donde vem o dizer-se que o mal nem é existente nem é bom; pois o ser, enquanto tal, sendo bom,
desaparecido este, desaparece aquele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Aristóteles, no lugar citado, exprime-se segundo a
opinião dos Pitagóricos que, opinando ser o mal uma certa natureza, ensinavam que o bem e o mal são
gêneros. Pois, Aristótelescostuma, sobretudo nas obras de lógica, pôr exemplos que eram prováveis no
seu tempo, segundo a opinião de alguns filósofos. – Ou também se pode responder que, como diz o
Filósofo, a primeira contrariedade é o hábito e a privação, porque essa contrariedade mantém-se
sempre em todos os contrários, por ser sempre um deles imperfeito em relação ao outro; assim, o negro
em relação ao branco, o amargo em relação ao doce. Por onde, o bem e o mal se chamam gêneros, não
pura e simplesmente, mas dos contrários; pois, como toda forma tem a natureza de bem, assim toda
privação, como tal, tem a de mal.

RESPOSTA À SEGUNDA. – Como o bem e o mal têm natureza de fim, só dos atos morais são diferenças
constitutivas, pois estes se especificam pelo fim, objeto da vontade, do qual eles dependem. E nem a
remoção do fim devido constitui espécie aos atos morais, senão enquanto essa remoção se liga ao fim
indevido; assim como nos seres materiais não há privação de uma forma substancial senão pela
substituição de outra. Assim, pois, o mal, diferença constitutiva nos atos morais, é um certo bem
adjunto à privação de outro bem; p. ex. o fim do intemperante é, não por certo o privar-se do bem
racional, mas o deleitável aos sentidos, sem o governo da razão. Por onde o mal, como tal, não é
diferença constitutiva, senão em virtude do bem adjunto.
Por onde também é clara a RESPOSTA À TERCEIRA. – Pois, no lugar citado, o Filósofo fala do bem e do
mal no atinente aos atos morais. Assim que, entre o bem e o mal há um meio; pois, bem se chama o que
é ordenado; mal, não só o que é desordenado, mas também nocivo a outrem. Donde o dizer o Filósofo,
que o pródigo é certamente vão, não porém mau. E por isso, do mal moral podemos voltar para o bem;
não, porém, de nenhum mal, pois da cegueira não se sai para a visão, embora seja a cegueira um certo
mal.

RESPOSTA À QUARTA. – De três modos se pode dizer que um ser age. De modo formal, como quando se
diz que a brancura faz o branco; e, assim dizemos que o mal, em razão da privação mesma, corrompe o
bem, pois o mal é a corrupção mesma ou privação do bem. De modo efetivo, como quando se diz que o
pintor faz uma parede branca. De terceiro modo, como causa final, quando se diz que o fim é eficiente
por mover a causa eficiente. Ora, por estes dois últimos modos, o mal nada faz por si mesmo, isto é,
enquanto implica uma certa privação, senão enquanto o bem lhe é adjunto. Pois, toda ação o é por
alguma forma; e tudo o que é desejado como fim é alguma perfeição. Por onde, como diz Dionísio, o
mal não age nem é desejado senão por virtude do bem adjunto; por si, porém, é infinito e está fora da
vontade e da intenção.

RESPOSTA À QUINTA. – Como já se disse, as partes do universo têm ordem entre si, enquanto uma age
sobre outra e é desta fim e exemplar. Ora tal, como dissemos, não pode convir ao mal, senão por
virtude do bem adjunto. Por onde, o mal não pertence à perfeição do universo, nem se inclui na ordem
deste, senão por acidente, isto é, em razão do bem adjunto.

## Art. 2 — Se há mal nas coisas.
(Supra, q. 22, a. 2. ad 2; I Sent., dist. XLVI, a. 3; II, dist. XXXIV, a. 1; III Cont. Gent., cap. LXXI; De Pot., q. 3,
a. 6, ad 4: Compend. Theol., cap. CXLII; De Div., Nom., cap. IV, lect. XVI).
O segundo discute-se assim. – Parece que não há mal nas coisas.

1. – Pois, tudo o que há nas coisas ou é algum ente, ou privação de alguma coisa, o que é não-ente. Ora,
Dionísio diz que o mal difere do existente e ainda mais do não existente. Logo, de nenhum modo há mal
nas coisas.

2. Demais. – Ente e coisa são termos que se convertem. Por onde, se há mal nas coisas, segue-se que
este é uma coisa; o que vai contra o que estabeleceu a objeção anterior.

3. Demais. – Muito branco é o que nenhuma mistura tem de preto, como diz Aristóteles, Logo, melhor é
o que nenhuma mistura tem de mau. Ora, Deus sempre faz o que é melhor, e muito mais do que a
criatura. Logo, nas coisas feitas por Ele nenhum mal se encontra.
Mas, em contrário,se a opinião supra fosse exata, desapareceriam todas as proibições e penas, que só
existem por causa dos males.

SOLUÇÃO. – Como já antes se disse, a perfeição do universo exige a desigualdade entre as coisas, para
que todas representem um grau de bondade. Ora, há um grau de bondade que leva uma coisa a ser de
tal modo boa que nunca possa ser deficiente. Há outro, porém, que não exclui a deficiência. E ambos
estes graus se acham realizados nos seres; pois, há certas coisas, como as incorruptíveis, que nunca
podem perder o ser que têm; outras, porém, como as corruptíveis, que o podem. Ora, assim como a
perfeição do universo exige existam não somente seres incorruptíveis, mas também corruptíveis; assim
também exige existam certos seres de bondade deficiente e que, por isso mesmo às vezes descambam
para o mal. Pois, a essência do mal consiste precisamente em haver num ente deficiência do bem. Por
onde é manifesto, que há mal nas coisas, bem como corrupção, pois esta é uma espécie de mal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O mal difere do ser e do não-ser, ambos considerados em
absoluto; pois nem um como hábito, nem uma como pura negação, mas existe a modo de privação.

RESPOSTA À SEGUNDA. – O ser tem dupla acepção. Numa, significando a entidade da coisa, enquanto
dividida pelos dez predicamentos, converte-se na coisa. Noutra, significa a verdade da proposição
consistente na composição e notificada pelo verbo é; e, nesta acepção, o ser responde à pergunta: se é.
E assim dizemos que a cegueira, ou qualquer outra privação, está nos olhos. De modo que, nesta
acepção, também o mal é chamado ente. E foi pela ignorância desta distinção que alguns, considerando
que algumas coisas se chamam más, ou que se diz existir o mal nas coisas, pensaram que o mal tem uma
certa realidade.

RESPOSTA À TERCEIRA. – Deus, a natureza ou qualquer agente fazem o que é melhor totalmente, mas
não o que o é em cada uma das partes, senão pela relação com o todo, conforme já se disse. Ora, o todo
em si, que é a universalidade das criaturas, é melhor e mais perfeito se nele existirem certas realidades
que possam ter e que, de fato, às vezes tenham deficiência de bem; e Deus tal não impede. Quer por
não ser próprio da providência destruir, senão salvar a natureza, como diz Dionísio; e da natureza
mesma das coisas resulta, que as susceptíveis de deficiência às vezes são deficientes. Quer porque como
diz Agostinho, Deus é tão poderoso de modo a poder tirar o bem do mal. Por onde, muitos bens seriam
tolhidos se Deus não permitisse nenhum gênero de mal. Assim, não se geraria o fogo se o ar se não
corrompesse; nem se conservaria a vida do leão se não fosse morto o asno. Nem tão pouco seria
louvada a justiça do vingador e a paciência do padecente, se não fosse a iniqüidade do perseguidor.

## Art. 3 — Se o mal tem no bem o seu sujeito.
(Supra, q. 9, a. 4, ad 2; II Sent., dist. XXXIV, q. 1, a. 4; III Cont. Gent., cap. XI; De Malo, q. 1, a. 2;
Compend. Theol., cap. CXVIII).
O terceiro discute-se assim. – Parece que o mal não tem no bem o seu sujeito.

1. – Pois, todos os bens são existências. Ora, Dionísio diz que – o mal não é existente, nem está nos
seres existentes. Logo, o mal não tem no bem o seu sujeito.

2. Demais. – O mal não é um ente; mas o bem o é. Ora, o não-ser não exige um ser no qual exista como
num sujeito. Logo, nem o mal exige o bem como sujeito de existência.

3. Demais. – Um contrário não pode ser sujeito de outro. Ora, o bem e o mal são contrários. Logo, este
não está naquele como no sujeito.

4. Demais. – Chama-se branco aquilo em que a brancura está como no seu sujeito. Logo, também o mal
é aquilo em que a maldade está como no seu sujeito. Se portanto, o mal tiver no bem o seu sujeito,
segue-se que o bem é mal, contra o que diz a Escritura (Is 5, 20): Ai de vós os que ao mal chamais
bom, e ao bom mau!
Mas, em contrária, diz Agostinho, que o mal não pode existir senão no bem.

SOLUÇÃO. – Como já se disse, o mal importa a remoção do bem, não porém qualquer remoção. Pois,
podemos considerar a remoção do bem privativa e negativamente. A remoção do bem, negativamente
considerada, não tem natureza de mal; do contrário se seguiria que as coisas de nenhum modo
existentes seriam más; e ainda, que uma coisa seria má por não ter a bondade de outra coisa; por ex.,
que o homem seria mau por não ter a velocidade da cabra ou a fortaleza do leão. Porém a remoção do
bem, em acepção privativa, chama-se mal; assim, a privação da vista chama-se cegueira. Ora, o sujeito
da privação e da forma é um e o mesmo, a saber, o ser em potência; quer o ser em potência pura e
simplesmente, como a matéria, que é sujeito da forma substancial e da privação oposta; quer o ser em
potência, sob certo ponto de vista, e em ato, absolutamente; como o corpo diáfano, que é sujeito das
trevas e da luz. Ora, é manifesto que a forma pela qual alguma coisa existe em ato, é uma certa per-
feição e um certo bem; assim que, todo ser em ato é um certo bem. E semelhantemente, todo ser em
potência, como tal, é um certo bem enquanto ordenado para o bem; pois, assim como é ser em
potência, assim é bem em potência. Logo, resulta que o sujeito do mal é o bem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Dionísio entende que o mal não está nos seres existentes,
como se fosse parte ou propriedade natural de um ser existente.

RESPOSTA À SEGUNDA. – O não-ser, em acepção negativa, não exige um sujeito. Mas a privação é a
negação num sujeito, como diz Aristóteles; e tal não-ser é o mal.

RESPOSTA À TERCEIRA. – O mal não tem, como o sujeito, bem que se lhe opõe, mas algum outro bem;
assim, o sujeito da cegueira não é a vista, mas o animal. Parece, então, como diz Agostinho, que nesta
questão falha a regra dos dialectas, afirmando que os contrárias não pedem existir
simultaneamente. Deve-se porém entendê-la, segundo a acepção comum do bem e do mal e não
enquanto especialmente se considera tal bem e tal mal. Assim, o branco e o preto, o doce e o amargo e
semelhantes contrários não se tomam senão em acepção especial, por estarem em certos gêneros
determinados. Mas o bem abrange todos os gêneros; por onde, um bem pode simultaneamente existir
com a privação de outro.

RESPOSTA À QUARTA. – O profeta impreca o ai! contra os que dizem que o bem, como tal, é mau. Isto,
porém, não resulta das premissas, como se vê do que foi dito.

## Art. 4 — Se o mal corrompe totalmente o bem.
(Ia IIae, q. 85, a. 2; II Sent., dist. XXXIV, a. 5; Cont. Gent., cap. XII; De Malo, q. 2, a. 12).
O quarto discute-se assim. – Parece que o mal corrompe totalmente o bem.

1. – Pois um dos contrários é totalmente corrompido pelo outro. Ora, o bem e o mal são contrários.
Logo, este pode corromper totalmente aquele.

2. Demais. – Agostinho diz que o mal prejudica enquanto priva do bem. Ora, o bem é semelhante e
uniforme a si mesmo. Logo, é totalmente eliminado pelo mal.

3. Demais. – O mal, enquanto dura, prejudica e elimina o bem. Ora, um ser ao qual sempre se tira
alguma coisa, um dia há-se de consumir, a menos que seja infinito, o que não se pode dizer de nenhum
bem criado. Logo, o mal consome totalmente o bem.
Mas, em contrário,diz Agostinho que o mal não pode consumir totalmente o bem.

SOLUÇÃO. – O mal não pode consumir totalmente o bem, o que se evidencia se se considerar a tríplice
divisão do bem. Há um certo bem totalmente eliminado pelo mal, e é o que a este se opõe; assim a luz é
totalmente eliminada pelas trevas, e a vista pela cegueira. Há outro bem que não é totalmente
diminuído pelo mal, nem diminui; a saber, o bem que é sujeito do mal; assim, pelas trevas, nada é
diminuído da substância do ar. Há, por fim, outro bem diminuído certamente pelo mal, não porém total-
mente; e este é a capacidade do sujeito para o ato.
Mas a diminuição deste bem não deve ser entendida como subtração, o que se dá com a diminuição
quantitativa, mas como remissão, o que se dá com a diminuição qualitativa e formal. Ora, a remissão
dessa capacidade se mede pelo contrário à intenção da mesma. Pois, tal intenção depende das
disposições pelas quais a matéria é preparada para o ato: quanto mais elas se multiplicarem no sujeito,
tanto mais capaz será este de receber a perfeição e a forma. E contrariamente, a capacidade sofre
remissão pelas disposições contrárias: quando mais se multiplicarem na matéria e forem intensas, tanto
mais se há de remitir o poder de agir.
Se, portanto, as disposições contrárias não puderem ser multiplicadas e intensas ao infinito, mas até
certo limite, também a capacidade predita não poderá sofrer diminuição ou remissão ao infinito. O que
bem se vê nas qualidades ativas e passivas dos elementos; assim, a frigidez e a umidade, que diminuem
ou remitem a capacidade da matéria para a forma ígnea, não podem multiplicar-se ao infinito. Se,
porém, as disposições contrárias o puderem, também a capacidade referida diminuirá ou se remitirá ao
infinito. Todavia, não poderá ser totalmente eliminada, porque permanece sempre radicalmente na
substância do sujeito. Assim, se se interpuserem infinitos corpos opacos entre o sol e o ar, ao infinito
diminuirá a capacidade do ar para a luz; não poderá ela, porém, ser totalmente eliminada, enquanto
permanecer o ar, que, por natureza, é diáfano. Semelhantemente, podem-se adicionar pecados ao
infinito, pelos quais cada vez mais diminuirá a capacidade da alma para a graça, pois eles são como
obstáculos postos entre nós e Deus, conforme aquilo de Isaías (Is 59, 2): Más são as vossas iniqüidades
que puseram uma separação entre vós e o vosso Deus. Todavia a referida capacidade nunca será total-
mente aniquilada, na alma, porque resulta da natureza desta.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O bem oposto ao mal fica totalmente eliminado; não
assim, porém, os outros bens, como se disse.

RESPOSTA À SEGUNDA. – A capacidade de que se acabou de falar é meio entre o sujeito e o ato. Por
onde, pela parte por que atinge o ato, diminui pelo mal; permanece porém pela parte pela qual se atém
ao sujeito. Logo, embora o bem seja semelhante a si mesmo, contudo, pela sua comparação com
elementos diversos, é eliminado parcial e não totalmente.

RESPOSTA À TERCEIRA. – Alguns, imaginando a diminuição do bem predito, por semelhança com a
diminuição quantitativa, disseram que, assim como o contínuo pode ser dividido ao infinito, feita a
divisão segundo a mesma proporção, de modo que se torne, p. ex., a metade da metade ou o terço do
terço; assim acontece no caso vertente. – Mas neste caso não cabe tal SOLUÇÃO. Pois, na divisão em
que se conserva a mesma proporção, subtrai-se cada vez menos; assim a metade da metade é menos
que a do todo. Mas, o segundo pecado não diminui menos do que o precedente a capacidade referida,
mas talvez, igualmente ou mais. – Por onde, devemos concluir que, embora a capacidade mesma seja
algo de finito, contudo diminui ao infinito, não em si, mas por acidente, enquanto as disposições
contrárias também aumentam ao infinito, como se disse.

## Art. 5 — Se o mal é suficientemente dividido em pena e culpa.
(II Sent., dist. XXXV, a. 1: De Malo, q. 1, a. 4).
O quinto discute-se assim. – Parece que o mal é insuficientemente dividido em pena e culpa.

1. – Pois, um defeito é um mal. Ora, em todas as criaturas, há defeitos, por não poderem se conservar
no ser, cujo defeito, entretanto, nem é pena nem culpa. Logo, o mal não é suficientemente dividido em
pena e culpa.

2. Demais. – Nos seres irracionais não há culpa nem pena; há neles, todavia, corrupção e defeito, coisas
que implicam essencialmente o mal. Logo, nem todo mal é pena ou culpa.

3. Demais. – A tentação é um mal, sem todavia ser culpa; pois, a tentação não consentida não é pecado,
mas matéria para exercer a virtude, como diz a Glosa sobre aquilo da Escritura (2 Cor 12, 7): E para que
a grandeza das revelações. Nem também pena, pois a tentação precede à culpa, ao passo que a pena se
lhe segue a esta. Logo, insuficientemente se divide o mal em pena e culpa.
Mas, em contrário,parece que a divisão é supérflua. Pois, como diz Agostinho, mal é o que
prejudica. Ora, o que prejudica merece pena. Logo, todo mal se contém na pena.

SOLUÇÃO. – O mal, como já antes se disse, é a privação do bem; e este, principalmente e por si, consiste
na perfeição e no ato. Ora, o ato existe de dois modos: como ato primeiro e como segundo. Aquele é a
forma e a integridade da coisa; este é a operação. Logo, também importa que o mal de duplo modo
exista. De um modo, por privação da forma ou de alguma parte requerida para a integridade da coisa;
assim, a cegueira e o carecer de um membro são males. De outro modo, por privação da operação
devida; quer esta completamente inexista, quer não tenha o modo e a ordem devidos. Como, porém, o
bem absoluto é o objeto da vontade, o mal, privação do bem, segundo uma razão especial, existe nas
criaturas racionais que têm vontade. Portanto o mal, por privação da forma e integridade da coisa, tem
a natureza de pena; pois é da natureza da pena ser contrária à vontade e principalmente suposto que
todas as coisas estão sujeitas à providência e à justiça divinas, como antes se demonstrou. Porém, o mal
que consiste na privação da operação devida, quanto ao que é voluntário, tem a natureza de culpa; pois,
se imputa alguma coisa por culpa a quem se transvia da ação perfeita, da qual é senhor pela vontade.
Assim, portanto, todo mal, considerado como voluntário, é pena ou culpa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Sendo o mal a privação do bem e não negação pura,
como já antes se disse, nem toda falta de bem é mal, mas a do bem natural ao ser e que este deve ter.
Assim, a falta de visão não é um mal na pedra, mas no animal; porque é contra a natureza da pedra o ter
a visão. Semelhantemente, também é contra a natureza da criatura o conservar-se no ser por si mesma;
pois então, o mesmo ente daria e conservaria o ser. Donde, tal falta não é mal da criatura.

RESPOSTA À SEGUNDA. – A pena e a culpa não dividem o mal absolutamente, mas sim, o voluntário.

RESPOSTA À TERCEIRA. – A tentação, importando provocação ao mal, sempre há o mal da culpa no
tentador. Mas, no tentado não existe propriamente o mal, senão enquanto é de certo modo alterado,
ao modo porque a ação do agente está no paciente. Porém, enquanto induzido ao mal pelo tentador, o
tentado incide em culpa.

RESPOSTA À QUARTA. – Da natureza da pena é o atingir o agente em si mesmo afligindo-o. Porém, da
natureza da culpa é o prejudicar o agente na sua ação. Assim, ambas se contem no mal, enquanto este,
por natureza, prejudica.

## Art. 6 — Se a pena participa, mais do que a culpa, da natureza do mal.
(IIa IIae, q. 19, a. 1; II Sent., dist. XXXVII. q. 3, a. 2; De Malo, q. 1, a. 5).
O sexto discute-se assim. – Parece que a pena participa, mais do que a culpa, da natureza do mal.

1. – Pois, a culpa está para a pena como o mérito para o prêmio. Ora, o prêmio participa, mais do que o
mérito, da natureza do bem, pois é deste o fim. Logo, a pena participa, mais do que a culpa, da natureza
do mal.

2. Demais. – Maior mal é o que se opõe ao maior bem. Ora, a pena, como já se disse, opõe-se ao bem do
agente; e a culpa, ao da ação. Sendo, porém, o agente melhor do que a ação, resulta que pior é a pena
do que a culpa.

3. Demais. – A privação mesma do fim é uma certa pena, chamada a carência da visão divina; porém o
mal da culpa vem da privação da ordem em relação ao fim. Logo, a pena é maior mal que a culpa.
Mas, em contrário. – O artífice sábio faz mal menor para evitar o maior; assim como o médico amputa
um membro para se não corromper o corpo. Ora, a sabedoria de Deus inflige a pena para evitar a culpa.
Logo, esta é maior mal que aquela.

SOLUÇÃO. – A culpa participa, mais do que a pena, da natureza do mal. E não só mais do que as penas
sensíveis, que consistem na privação dos bens corpóreos, e às quais a maior parte dos homens
atendem; mas também mais do que a pena em acepção universal, segundo a qual a privação da graça
ou da glória são determinadas penas. E disto é dupla a razão. – A primeira é que pelo mal da culpa nós
nos tornamos maus; não porém pelo da pena, segundo aquilo de Dionísio: Ser punido não é mal, mas
sim fazer-se digno da pena.E isto porque, consistindo o bem puro e simples, no ato, e não na potência, e
sendo o último ato a operação ou o uso de quaisquer coisas possuídas, o bem absoluto do homem é
relativo à boa operação ou ao bom uso das coisas possuídas. Ora, nós usamos de todas as coisas pela
vontade. Por onde, pela vontade boa, porque o homem usa bem das coisas possuídas, dizem que ele é
bom; e pela vontade má, mau. Porém, o que tem a vontade má também pode usar mal do bem que
possui; como se um gramático voluntariamente falar de modo incôngruo. Logo, consistindo a culpa em
si mesma num ato desordenado da vontade, e a pena em a privação de qualquer dos bens de que usa a
vontade, mais perfeitamente participa da natureza do mal a culpa do que a pena. – A segunda razão
pode se deduzir de ser Deus o autor do mal da pena, não porém do mal da culpa. E a razão é que o mal
da pena priva do bem a criatura; quer se considere como bem da criatura um bem criado; assim a
cegueira priva da visão; quer como bem incriado, assim pela carência da visão divina fica privada a
criatura do bem incriado. Porém, o mal da culpa opõe-se propriamente ao bem incriado em si mesmo.
Pois contraria ao implemento da divina vontade e ao divino amor, pelo qual o bem divino é amado em si
mesmo e não só enquanto participado pela criatura. Por onde se vê, que a culpa mais participa da
natureza do mal do que a pena.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora a culpa tenha na pena o seu termo, como o
mérito no prêmio, contudo a culpa não é incorrida por causa da pena, como o mérito é adquirido por
causa do prêmio; mas antes inversamente, a pena é estabelecida para ser evitada a culpa. E assim esta é
pior que aquela.

RESPOSTA À SEGUNDA. – A ordem da ação, eliminada pela culpa, é bem mais perfeito do agente, por
ser perfeição segunda, do que o bem eliminado pela pena, que é perfeição primeira.

RESPOSTA À TERCEIRA. – Não se compara a culpa com a pena, como o fim com a ordem para o mesmo;
porque de ambos pode se vir a ficar privado de certo modo, tanto pela culpa como pela pena. Pela pena,
enquanto o próprio homem mesmo se afasta do fim e da ordem para o fim. Pela culpa, porém,
enquanto tal privação pertence à ação, não ordenada para o fim devido.