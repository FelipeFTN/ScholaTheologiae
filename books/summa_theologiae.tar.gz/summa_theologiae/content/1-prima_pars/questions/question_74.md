# Questão 74: De todos os seis dias em comum.
Em seguida tratamos de todos os seis dias em comum. E três artigos se discutem:

## Art. 1 — Se esses dias são enumerados suficientemente.
O primeiro discute–se assim. Parece que esses dias não são suficientemente enumerados.

1. – Pois, a obra da criação não se distingue menos das da distinção e do ornato, do que estas duas
últimas entre si. Ora, uns dias foram destinados à distinção e outros, ao ornato. Logo, também se
deviam destinar outros à criação.

2. Demais. – O ar e o fogo são elementos mais nobres que a terra e a água. Ora, há um dia destinado à
separação da água e outro, à da terra. Logo, também outros dias devem ser destinados à separação do
fogo e à do ar.

3. Demais. – Não diferem menos as aves, dos peixes, do que dos animais terrestres; e o homem, por sua
vez, difere mais dos outros animais, do que, entre eles, um, de outro. Ora, há um dia deputado à
produção dos peixes do mar, e outro à dos animais da terra. Logo, também deve ser deputado um à
produção das aves do céu, e outro, à do homem.
Mas em contrário. – Parece que há alguns dias destinados, superfluamente. Pois, a luz estando para o
luzeiro como o acidente para o sujeito, é produzido este simultaneamente com o seu acidente próprio.
Logo, não se devia destinar um dia para a produção da luz, e outros, para a dos astros. Demais. – Esses
dias foram deputados à instituição primeira do mundo. Ora, no sétimo dia nada foi instituído
primariamente. Logo, esse dia não devia ser conumerado com os outros.

SOLUÇÃO. – Do que já foi dito pode–se tornar manifesta a razão da distinção desses seis dias. Pois, era
necessário distinguir, primeiro, as partes do mundo; e em seguida, orná–las, pelo como povoamento, de
seus habitantes. – Porém, segundo outros Santos Padres três partes são designadas, na criatura
corporal: a primeira se inclui na denominação de céu; a média, na de água; a ínfima, na de terra. Por
onde, segundo os Pitagóricos, em três coisas consiste a perfeição: no principio, no meio e no fim, como
diz Aristóteles. Assim, a primeira parte é distinta no primeiro dia e ornada no quarto; a média é distinta
no segundo e ornada no quinto; a Ínfima é distinta no terceiro e ornada no sexto. – Agostinho, porém,
concordando com estes, quanto aos últimos três dias, deles difere nos três primeiros. Porque, na sua
opinião é formada no primeiro dia a criatura espiritual e nos dois últimos a corporal; assim que, no
segundo dia são formados os corpos superiores e no terceiro os inferiores. E então, a perfeição das
obras divinas corresponde à do número senário, resultante das suas partes alíquotas – um, dois, três –
simultaneamente juntas. Assim, um dia é destinado à formação da criatura espiritual; dois, à da
corporal, e três ao ornato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Segundo Agostinho, a obra da criação pertence à produção
da matéria informe e da natureza espiritual informe; e estando ambas, fora do tempo, como ele diz, a
criação delas se faz antes de qualquer dia. – Mas, segundo os outros Santos Padres, pode–se dizer que a
obra da distinção e a do ornato se consideram em relação a certas mudanças da criatura, que é medida
pelo tempo. Porém, a obra da criação consiste somente na ação divina, que produz num instante a
substância das coisas; por onde se diz que qualquer das obras da distinção e do ornato, se fez nó tempo;
da criação, porém, se diz que foi feita no princípio, por significar algo de indivisível.

RESPOSTA À SEGUNDA. – O fogo e o ar, por não serem distinguidos pelo vulgo, não são expressamente
nomeados por Moisés entre as partes do mundo. Mas são computados, sobretudo quanto à parte
inferior do ar, com a parte média, isto é, a água; sendo, quanto à parte superior, computados com o
céu, como diz Agostinho.

RESPOSTA À TERCEIRA. – A produção dos animais é narrada, como servindo eles de ornato das partes
do mundo. Por onde, os dias da produção dos animais distinguem–se ou unem–se segundo a
conveniência ou diferença que têm, no ornar alguma parte do mundo.

RESPOSTA À QUARTA. – No primeiro dia, foi feita a natureza da luz, em algum sujeito; mas, no quarto
dia se diz terem sido feitos os astros, não por ser a substância deles produzida de novo, mas por serem
formados de modo como dantes não eram, como já se disse.

RESPOSTA À QUINTA. – Ao sétimo dia, segundo Agostinho, se destina alguma cousa, além de todas as
atribuídas aos seis dias; e é que Deus repousou em si mesmo, das suas obras, por onde, era necessário
que, após os seis dias, se fizesse menção do sétimo. – Segundo outros, porém, pode–se dizer que no
sétimo dia o mundo teve um novo estado, tal que nada de novo se lhe acrescentasse. Por onde; depois
dos seis dias, se coloca o sétimo, deputado ao cessar das obras.

## Art. 2 — Se todos esses dias são um só dia.
O segundo discute–se assim. – Parece que todos esses dias são um só dia.

1. – Pois, diz a Escritura: Tal foi a origem do céu e da terra, quando foram criados, no dia em que o
Senhor Deus fez o céu e a terra e toda a planta do campo antes que nascesse na terra. Logo um é o dia
em que fez o céu e a terra e toda a planta do campo. Mas, fez o céu e a terra no primeiro dia, ou
melhor, antes de qualquer dia; e fez os arbustos do campo no terceiro dia. Logo, um só dia são o
primeiro, o terceiro e, por igual razão, todos os outros.

2. Demais. – Diz a Escritura: Aquele que vive eternamente, criou todas as coisas juntas. Ora, isto não se
daria se os dias dessas obras fossem vários, porque vários dias não são simultâneos. Logo, não há vários
dias, mas um só.

3. Demais. – No sétimo dia Deus cessou de fazer novas obras. Se, pois, o sétimo dia é dia diferente dos
outros, segue–se que ele não fez esse dia, o que é inconveniente.

4. Demais. – Deus fez num instante a obra de cada dia, pois, de cada obra se diz: Disse e se fez. Se, pois,
a obra seguinte a reservasse para outro dia, resultaria que, na parte restante do dia anterior teria
cessado as obras; o que seria supérfluo. Logo, não há nenhum dia seguinte ao da obra precedente.
Mas, em contrário, diz a Escritura: Fez–se tarde e manhã e segundo dia e o terceiro dia, e assim por
diante. Ora, não se pode falar de segundo e terceiro onde só há um. Logo, não houve só um dia.

SOLUÇÃO. – Neste assunto, Agostinho dissente dos outros expositores. Pois, ensina que todos os
chamados sete dias não são mais do que um só dia, que se apresenta sete vezes. Porém, os outros
expositores sentem que foram sete dias diversos e não um só.
Ora, estas duas opiniões, referidas à exposição da letra da Escritura, têm entre si grande diversidade. –
Assim, segundo Agostinho, por dia se entende o conhecimento da mente angélica; de modo que o
primeiro dia é o conhecimento da primeira obra divina; o segundo, o da segunda, e assim por diante. Daí
o dizer–se que cada obra teve o seu dia, porque Deus não produziu nada, nas coisas da natureza, que
não imprimisse na mente angélica, podendo esta conhecer simultaneamente muitas coisas, sobretudo
no Verbo, em quem todo conhecimento angélico se termina e aperfeiçoa. De modo que os dias se
distinguem pela ordem natural das coisas conhecidas e não pela sucessão do conhecimento ou pela da
produção das coisas. Ora, o conhecimento angélico pode, própria e verdadeiramente, ser denominado
dia, porque a luz, causa do dia, se encontra propriamente, segundo Agostinho, nos seres espirituais.
Porém, segundo os outros, por esses dias se entende tanto a sucessão dos dias temporais como a da
produção das coisas.
Se contudo, essas duas opiniões se referirem ao modo da produção das coisas, não há entre elas grande
diferença. E isto por dois motivos, cujas exposições diversificam Agostinho dos outros, como resulta
claro do que já se disse antes. – E o primeiro é que Agostinho pela terra e água, primeiramente criadas,
entende a matéria totalmente informe; e pela produção do firmamento, congregação das águas e
aparecimento da terra árida entende a impressão das formas na matéria corporal. Os outros Santos
Padres, porém, pela terra e água primeiramente criadas, entendem os elementos mesmos do mundo
existentes com formas próprias; e pelas obras seguintes entendem alguma distinção nos corpos, já
antes existentes, como antes se disse. – Em segundo lugar, difere Agostinho dos outros quanto à
produção das plantas e dos animais, por admitirem estes que, na obra dos seis dias, umas e outros
foram produzidos atualmente; ao passo que, para Agostinho, o foram apenas potencialmente. Assim, o
admitir este que as obras dos seis dias foram feitas simultaneamente, importa em terem as coisas o
mesmo modo de produção.
De modo que, segundo todos, a matéria, na produção primeira das coisas, existia sob as formas
substanciais dos elementos; e demais, nessa primeira instituição não havia animais nem plantas, em ato.
Mas Agostinho difere dos outros em quatro pontos; pois, segundo os outros Santos Padres, depois da
produção primeira da criatura, houve tempo em que não existia a luz; não havia Um firmamento
formado; a terra não estava a descoberto das águas; e não estavam formados os astros do céu, que é o
quarto ponto; coisas todas que não admite Agostinho. Por onde, para não ficar prejudicada nenhuma
dessas opiniões, devem–se responder as objecções de uns e de outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. No mesmo dia em que Deus criou o céu e a terra, criou
também todos os arbustos do campo, não em ato, mas antes que nascessem na terra, isto é, em
potência; o que Agostinho atribui ao terceiro dia e, os outros, à instituição primeira das coisas.

RESPOSTA À SEGUNDA. – Deus criou todas as coisas simultaneamente, quanto à substância delas, de
certo modo informe; mas não simultaneamente, quanto à formação feita pela distinção e pelo ornato; e
por isso se usa, expressamente, da palavra criação.

RESPOSTA À TERCEIRA. – No sétimo dia, Deus cessou de fazer novas obras; não, porém, de propagar
certas delas; e essa propagação é causa de sucederem outros dias, ao primeiro.

RESPOSTA À QUARTA. – Não é por impotência de Deus, como se precisasse de tempo para operar, que
todas as coisas não foram simultaneamente distintas e ornadas; mas para que se conservasse a ordem,
na instituição delas. Por onde, era necessário servissem diversos dias aos diversos estados do mundo.
Assim sempre cada uma das obras seguintes acrescentava ao mundo um novo estado de perfeição.

RESPOSTA À QUINTA. – Segundo Agostinho, essa ordem dos dias deve referir–se à ordem natural das
obras a eles atribuídas.

## Art. 3 — Se a Escritura usa de palavras convenientes para exprimir as obras dos seis dias.
O terceiro discute–se assim. Parece que a Escritura não usa de palavras convenientes para exprimir as
obras dos seis dias.

1. – Pois, se a luz, o firmamento e obras semelhantes foram feitos pelo Verbo de, Deus; assim também,
o céu e a terra, porque todas as coisas foram feitas por ele, como diz a Escritura. Logo, na criação do céu
e da terra devia fazer–se menção– do Verbo de Deus, como nas outras obras.

2. Demais. – A água, apesar de criada por Deus, não é comemorada. Logo, se descreve
insuficientemente a criação das coisas.

3. Demais. – Como diz a Escritura: E Deus viu todas as causas que tinha jeito, e eram muito bom , logo,
de cada uma das obras se devia dizer: E Deus viu que isto era bom. Ora, isto se omite
inconvenientemente na obra da criação e na do segundo dia.

4. Demais. – O Espírito de Deus é Deus. Ora, não é próprio de Deus ser transportado nem ter situação.
Logo, inconvenientemente se diz que o Espírito de Deus movia–se sobre as águas.

5. Demais. – Ninguém faz o que já está feito. Logo, depois de se haver dito: Deus disse: Faça–se o
firmamento e assim foi feito, é inconveniente acrescentar–se: E fez Deus o firmamento. E,
semelhantemente, nas outras obras de Deus.

6. Demais. – A tarde e a manhã não dividem o dia suficientemente, pois este tem várias partes. Logo,
inconvenientemente se diz que: E fez–se tarde e manhã, e foi o segundo dia ou o terceiro.

7. Demais. – Segundo e terceiro não correspondem propriamente a um, mas a primeiro. Logo, devia se
ter dito: E fez–se tarde e manhã, e foi o primeiro dia, onde se diz: um dia.

SOLUÇÃO. – À primeira objeção respondo que, segundo Agostinho, a pessoa do Filho se comemora
tanto na primeira criação das coisas, corno na distinção e ornato delas, porém de maneira diferente.
Pois, a distinção e o ornato pertencem à formação das coisas. Ora, assim como a formação das coisas
artificiadas é pela forma da arte, que está na mente do artífice e que pode ser chamada o verbo
inteligível do mesmo; assim, a formação de toda criatura é pelo Verbo de Deus. Por onde, na obra da
distinção e na do ornato, se faz menção do Verbo. Porém, na criação se comemora o Filho, corno
princípio, quando se diz: No princípio criou Deus; porque por criação se entende a produção da matéria
informe. – Mas, segundo os outros, que ensinam que, primeiramente, foram criados os elementos, sob
formas próprias, é míster dizer–se de outro modo. Assim, Basílio ensina que a expressão, Disse Deus,
importa o império divino, pois, era necessário ser produzida a criatura que obedecesse, antes de se
fazer menção do divino império.

RESPOSTA À SEGUNDA. – Segundo Agostinho, entende–se por céu a natureza espiritual informe; e por
terra, a matéria informe de todos os corpos. Assim nenhuma criatura foi omitida. – Segundo Basílio,
porém, o céu e a terra são postos como dois extremos, para deles se deduzirem os médios; sobretudo
porque o movimento de todos os corpos médios ou é para o céu, como o dos corpos leves, ou para a
terra, como o dos graves. – Os outros, porém, dizem que, sob o nome de terra a Escritura costuma
incluir todos os quatro elementos; por onde, depois de dizer: Louvai ao Senhor os que sois da terra,
acrescenta: O jogo, o granizo, a neve, a geada.

RESPOSTA À TERCEIRA. – Na obra da criação se põe algo de correspondente ao dito na obra da distinção
e do ornato – Viu Deus que isto ou aquilo era bom. Para a evidência do que, se deve considerar, que o
Espírito Santo é amor. Ora, há duas coisas, diz Agostinho, por causa das quais Deus ama a sua criatura,
convém saber, para que exista e para que perdure. E para que existisse o que devia perdurar, diz–se: O
Espírito de Deus movia–se sobre as águas, entendendo–se por água a matéria informe; no mesmo
sentido em que se diz que o amor do artífice é levado sobre alguma matéria, para formar dela a sua
obra. Porém para que perdurasse o que fizera, se diz: Viu Deus que era bom. E com isto quer–se
exprimir uma como complacência de Deus opífice, na cousa feita; e não que tivesse conhecimento da
criatura já feita e comprazimento nela, diferentemente do que os tinha antes de havê–Ia feito. E assim,
nas duas obras, da criação e da formação, insinua–se a Trindade das Pessoas. Na criação: a pessoa do
Pai, como Deus criador; a do Filho, como o princípio pelo qual criou; e a do Espírito Santo, como o
Espírito que é levado sobre as águas. E na formação: a pessoa do Pai, como Deus dicente; a do Filho,
como o Verbo no qual é dito; a do Espírito Santo, como a complacência com a qual Deus viu ser bom o
que estava feito. – Porém, na obra do segundo dia, não se põe – Viu Deus que era bom, porque, então,
começa a obra da separação das águas, que se completa no terceiro dia. Por onde, o que se diz no
terceiro dia refere–se também ao segundo. – Ou então, porque a separação feita no segundo dia é das
obras não manifestas ao povo; por isso a Escritura não usa de tal aprovação. – Ou ainda, porque se
entende por firmamento, absolutamente, o ar nebuloso, não pertencente às partes permanentes do
universo, ou às partes principais do mundo. E estas três razões são alegadas pelo Rabbi Moisés. –
Certos, porém, dão uma razão mística, tirada do número: porque o binário afasta–se da unidade, por
isso não é aprovada a obra do segundo dia.

RESPOSTA À QUARTA. – Rabbi Moisés entende, com Platão, que o espírito do Senhor é o ar ou o vento;
e diz, que com a expressão Espírito do Senhor a Escritura costuma sempre, em todos os passos, atribuir
a Deus o Flato dos ventos. – Mas, segundo os outros Santos Padres, por Espírito do Senhor se entende o
Espírito Santo, de quem se diz que é levado sobre a água, isto é, a matéria informe, segundo Agostinho;
para não se pensar que Deus amasse as obras que ia fazer com amor de indigência, amor que depende
das causas amadas, Por onde, procedeu–se acertadamente, insinuando primeiro algo de começado
sobre o que se dissesse, do Espírito que o Espírito era levado, não localmente, mas com sobre excelente
poder, como diz Agostinho. – Porém, segundo Basílio, era levado sobre o elemento da água, isto é,
aquecia e vivificava a natureza da água, à semelhança da galinha incubadora, transmitindo a virtude vital
aos ovos aquecidos, Pois, a água tem principalmente virtude vital, por se gerarem nela muitos animais e
ser húmido o sémen de todos. – E também, como a vida espiritual é dada pela água do batismo, diz a
Escritura: Quem não renascer da água e do Espírito Santo não pode entrar no reino de Deus.

RESPOSTA À QUINTA. – Segundo Agostinho, essas três expressões designam o ser tríplice das coisas. O
primeiro, o ser no Verbo, designa–o o dito: faça–se. O segundo, na mente angélica, o dito: foi feito. O
terceiro, em a natureza própria, o dito: fez, E como, no primeiro dia se descreve a formação dos anjos,
não era necessário acrescentar então: fez, – Porém, segundo outros, pode–se admitir que o dito: Disse
Deus, faça–se importa o império de Deus, quanto ao fazer. O dito: foi feito importa o complemento da
obra. Mas também era necessário acrescentar de que modo foi feito, sobretudo por causa dos que
disseram que todas as coisas visíveis foram feitas pelos anjos. E então, para afastar essa opinião,
acrescenta–se que Deus mesmo fez. Por onde, em cada uma das obras, depois de se dizer: e foi feito,
acrescenta–se algum ato de Deus, como fez ou separou, ou chamou, ou outro semelhante.

RESPOSTA À SEXTA. – Segundo Agostinho, por tarde e manhã se entende o conhecimento angélico
vespertino e matutino, de que já se tratou antes. – Ou, segundo Basílio, costumavase denominar o
tempo total pela sua parte principal, o dia, conforme o dito da Escritura: Os dias da minha peregrinação,
nenhuma menção feita da noite. Porém, a tarde e a manhã estão postas como os termos do dia, do qual
esta é o princípio e aquela o fim. – Ou porque a tarde, designando o princípio da noite; e a manhã, o do
dia, era congruente, ao comemorar–se a distinção primeira das coisas, designarem–se só os princípios
dos tempos. E põe–se em primeiro lugar a tarde porque, começando o dia com a luz, ocorre primeiro o
termo da luz, que é a tarde, do que o das trevas e da noite, que é a manhã. – Ou, segundo Crisóstomo,
para significar que o dia natural não termina com a tarde, mas com a manhã.

RESPOSTA À SÉTIMA. – Diz–se um dia na instituição primeira do dia, para exprimir que o espaço de
vinte e quatro horas constitui um dia; por onde, dizendo–se um, prefixa–se a medida do dia natural. –
Ou para exprimir, assim, que o dia se consuma pela volta do sol a um mesmo ponto. – Ou porque,
completo o setenário dos dias, volta–se ao primeiro dia, que é um com o oitavo. E essas três razões são
aduzidas por Basílio.
Tratado sobre o homem