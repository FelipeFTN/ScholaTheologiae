# Questão 105: Da mutação das criaturas, por Deus.
Em seguida devemos tratar do segundo efeito do governo divino, que é a mutação das criaturas. E
primeiro da mutação das criaturas por Deus. Segundo, da mutação de uma criatura por outra.
Sobre o primeiro ponto oito artigos se discutem:

## Art. 1 — Se Deus pode mover imediatamente a matéria para a forma.
O primeiro discute-se assim. — Parece que Deus não pode mover imediatamente a matéria para a
forma.

1. Pois, como o prova o Filósofo, só a forma de uma determinada matéria pode causar a forma noutra
matéria, porque o semelhante causa o semelhante. Ora, Deus não é forma de nenhuma matéria. Logo,
não pode causar aquela, nesta.

2. Demais. — Se um agente se refere a muitos termos, não produzirá nenhum deles, se não for
determinado, em relação a um destes, por alguma outra causa; pois, como diz Aristóteles, a opinião
universal não move, senão mediante alguma apreensão particular. Ora, a virtude divina é a causa
universal de todas as coisas. Logo, não pode produzir nenhuma forma particular, senão mediante algum
agente particular.

3. Demais. — Assim como o ser existente comum depende da causa primeira universal, assim, o ser
determinado depende de determinadas causas particulares, como antes já se estabeleceu (q. 104, a. 2).
Ora, é a forma própria de uma coisa que lhe determina a existência. Logo, as formas próprias das coisas
não são produzidas por Deus, senão mediante causas particulares.
Mas, em contrário, diz a Escritura (Gn 2, 7): Formou o Senhor Deus ao homem do barro da terra.

SOLUÇÃO. — Deus pode mover imediatamente a matéria para a forma, porque o ente em potência
passiva pode ser atualizado pela potência ativa que a contém no seu poder. Estando, pois, a matéria
contida no poder divino, como produzida por Deus, pode ser atualizada pela divina potência. E isto é ser
a matéria movida para a forma, pois, esta não é senão o ato daquela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um efeito pode assimilar-se com a causa agente, de
duplo modo; de um, segundo a mesma espécie, assim, o homem é gerado pelo homem e o fogo, pelo
fogo; de outro, pela compreensão virtual, enquanto a forma do efeito está virtualmente compreendida
na causa, e assim os animais gerados da putrefação, as plantas e os corpos minerais são assimilados ao
sol e às estrelas, por cuja virtude são gerados. Portanto, o efeito se assimila com a causa agente
segundo a extensão total da virtude do agente. Ora, como já ficou estabelecido (q. 44, a. 2), a virtude de
Deus se estende à forma e à matéria. Por onde, o composto gerado é assimilado com Deus pela
compreensão virtual, assim como se assimila com o composto gerador pela semelhança da espécie. Por
onde, assim como o composto gerador pode mover a matéria para a forma, gerando um composto que
lhe é semelhante, assim também Deus. Não o pode, porém, qualquer outra forma existindo sem
matéria, porque esta não está contida na virtude de nenhuma outra substância separada. Por isso os
demônios e os anjos operam sobre as coisas visíveis deste mundo, não, certo, imprimindo formas, mas
aplicando germens corpóreos.

RESPOSTA À SEGUNDA. — A objeção procederia se Deus agisse por necessidade de natureza. Mas,
agindo pela vontade e pelo intelecto, que conhece as razões próprias de todas as formas, e não só as
razões universais, pode, determinadamente, imprimir na matéria esta forma ou aquela outra.

RESPOSTA À TERCEIRA. — Mesmo o ordenarem-se as causas segundas para determinados efeitos
provém-lhes de Deus. Por onde, Deus, que ordena as outras causas para determinados efeitos, pode
também produzir estes, por si mesmo.

## Art. 2 — Se Deus pode mover imediatamente algum corpo.
(Opusc. XI, Resp. de XXXVI Art., 8. 13).
O segundo discute-se assim. — Parece que Deus não pode mover imediatamente nenhum corpo.

1. Pois, o motor e o movido devendo ser simultâneos, como o prova Aristóteles, necessário é haver
contado entre eles. Ora, não pode haver contado entre Deus e qualquer corpo; pois, como diz
Dionísio, Deus não é susceptível de contato, e, logo, não pode mover imediatamente nenhum corpo.

2. Demais. — Deus é motor não movido, pois, tal é o objeto desejável apreendido. Logo, Deus move
como desejado e apreendido. Ora, o que não é corpo, nem virtude do corpo, só pode ser apreendido
pelo intelecto. Logo, Deus não pode mover nenhum corpo imediatamente.

3. Demais. — Como o prova o Filósofo, a potência infinita move instantaneamente. Ora, é impossível a
qualquer corpo ser movido instantaneamente; porque, realizando-se o movimento entre dois termos
opostos, resultaria que esses dois opostos existiriam simultaneamente no mesmo ser, e tal é impossível.
Logo, nenhum corpo pode ser movido imediatamente por uma potência infinita. Ora, a potência de
Deus é infinita (q. 25, a. 2). Logo, Ele não pode mover imediatamente nenhum corpo.
Mas, em contrário. — Deus fez imediatamente as obras dos seis dias e nelas está incluído o movimento
dos corpos, como é patente por aquilo da Escritura (Gn 1, 9): As águas ajuntem-se num mesmo lugar.
Logo, Deus pode mover os corpos, imediatamente.

SOLUÇÃO. — É errôneo dizer-se que Deus não pode fazer, por si mesmo, todos os efeitos determinados
operados por qualquer causa criada. Por onde, como os corpos são movidos imediatamente pelas
causas criadas, a ninguém é lícito duvidar que Deus possa mover imediatamente qualquer corpo. E isto
resulta conseqüentemente do que já foi dito antes (a. 1). Pois, o movimento de qualquer corpo ou
resulta de alguma forma, como o movimento local dos graves e dos leves resulta da forma que lhes é
dada pelo gerador, em razão do que, este se chama motor; ou é via para alguma forma, como, a
calefação é via para a forma do fogo. Ora, é o mesmo ser que imprime a forma, dispõe para ela e dá o
movimento, dela resultante.
Pois o fogo não somente gera outro fogo, mas também aquece e move para cima. Ora, como Deus pode
imprimir imediatamente a forma na matéria, conseqüente é que possa mover, por qualquer
movimento, qualquer corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Duplo pode ser o contato — o corpóreo, como quando
dois corpos se tocam; e o virtual como quando dizemos que o que molesta toca o molestado. Ora, do
primeiro modo, Deus, sendo incorpóreo, nem toca nem é tocado. Mas, pelo contato virtual, toca,
movendo as criaturas; mas não é tocado, porque a virtude natural de nenhuma criatura pode atingi-lo. E
é neste sentido que entende Dionísio dizendo que não há contado com Deus, i. é., de maneira que seja
tocado.

RESPOSTA À SEGUNDA. — Deus move como desejado e inteligido. Mas não é necessário que sempre
mova como desejado e inteligido pelo ser movido; senão enquanto desejado e conhecido por si mesmo,
pois, tudo obra pela sua bondade.

RESPOSTA À TERCEIRA. — O Filósofo pretende provar que a virtude do primeiro motor não o é em
grandeza, pela razão seguinte. A virtude do primeiro motor é infinita; e o prova pelo fato de poder
mover num tempo infinito. Ora, uma virtude infinita, se tivesse qualquer grandeza, moveria num tempo
nulo, o que é impossível. Logo e necessariamente, a virtude infinita do primeiro motor não pode ter
grandeza. Por onde é claro que o ser um corpo movido num tempo nulo não resulta senão de uma
virtude de grandeza infinita. E a razão é que toda virtude susceptível de grandeza move pela sua
totalidade, pois move por uma necessidade de natureza. Ora, a virtude infinita sobre excede, sem
nenhuma proporção, qualquer virtude finita. E quanto maior for o poder do motor, tanto maior será a
velocidade do movimento. Por onde, como um poder finito move num tempo determinado, resulta que
o poder infinito não move num tempo tal, pois há sempre alguma proporção entre um tempo e outro.
— Ora, uma virtude fora de qualquer grandeza é virtude de um ser inteligente, que age sobre os efeitos,
conforme eles o comportam. E portanto, não podendo convir ao corpo o ser movido num tempo nulo,
não se segue que mova num tempo tal.

## Art. 3 — Se Deus move imediatamente o intelecto criado.
(Ia IIae, q. 109, a. 1; Compend. Theol., cap. CXXlX).
O terceiro discute-se assim. — Parece que Deus não move imediatamente o intelecto criado.

1. Pois, a ação do intelecto é imanente ao indivíduo de que provém e, por isso, não passa para a matéria
exterior, como diz Aristóteles. Ora, a ação do ser movido por outro, não é imanente aquele, mas provém
deste. Logo, o intelecto não é movido por outro ser; donde resulta que Deus não pode movê-lo.

2. Demais. — O que tem em si o princípio suficiente do seu movimento não é movido por outro. Ora, o
movimento do intelecto é o seu próprio inteligir-se a si mesmo; assim, diz-se, segundo o Filósofo, que
inteligir e sentir são movimentos. Ora, o princípio suficiente de inteligir é a luz inteligível ínsita no
intelecto. Logo, este não é movido por outro.

3. Demais. — Como o sentido é movido pelo sensível, assim o intelecto, pelo inteligível. Ora, Deus não é
inteligível para nós, mas excede o nosso intelecto. Logo, não no-lo pode mover.
Mas, em contrário. — O docente move o intelecto do discente. Ora, Deus ensina ao homem a ciência,
como diz a Escritura (Sl 93, 10). Logo, move a intelecto do homem.

SOLUÇÃO. — Assim como nos movimentos corpóreos chama-se movente o que dá a forma, princípio do
movimento; assim diz-se que move o intelecto o que causa a forma, princípio da operação intelectual,
chamada movimento do intelecto. Ora, no ser que intelige, é duplo o princípio da operação do intelecto:
um, a virtude intelectual mesma, cujo princípio está também no ser que intelige em potência; o outro é
o princípio do inteligir atual, que é a semelhança da coisa inteligida nesse ser.
Por onde, diz-se que move o intelecto o que lhe dá a virtude de inteligir, para que intelija, ou o que nele
imprime a semelhança da coisa inteligida. Ora, de ambos esses modos Deus move o intelecto criado. —
Pois, ele é o ser primeiro imaterial. E como a intelectualidade resulta da imaterialidade, segue-se que ele
é o ser inteligente primeiro. Por onde, como o primeiro, em qualquer ordem, é causa de tudo o mais
dele resultante, conclui-se que de Deus provém toda virtude de inteligir. — Semelhantemente, sendo
Deus o ser primeiro, e preexistindo nele, como na causa primeira, todos os entes, necessário é que estes
estejam em Deus inteligivelmente, ao modo d´Ele. Pois, assim como todas as razões inteligíveis das
coisas existem, primeiramente, em Deus, de quem derivam para os outros intelectos, afim de
inteligirem em ato, assim também derivam para as criaturas, afim de que subsistam. Por onde, Deus
move o intelecto criado dando-lhe a virtude, natural ou acrescentada, de inteligir, e imprimindo-lhe as
espécies inteligíveis; e de tudo isso ele governa e conserva a existência.DONDE A RESPOSTA À

PRIMEIRA OBJEÇÃO. — A operação intelectual provém, por certo, do intelecto em que está, como da
causa segunda; mas provém de Deus, como da causa primeira, pois, é ele que dá ao ser que intelige o
poder de inteligir.

RESPOSTA À SEGUNDA. — A luz intelectual, simultaneamente com a semelhança da coisa inteligida, é o
princípio suficiente, embora secundário, do inteligir, pois, é dependente do primeiro princípio.

RESPOSTA À TERCEIRA. — O inteligível move o nosso intelecto, imprimindo-lhe, de certo modo, a sua
semelhança pela qual ele pode inteligir. Mas as semelhanças que Deus imprime no intelecto criado não
bastam para que ele seja inteligido em essência, como antes já se estabeleceu (q. 12, a. 2). Por onde,
Deus move o intelecto criado, embora a este não lhe seja inteligível, como já se disse.

## Art. 4 — Se Deus pode mover a vontade criada.
(Infra, q. 106, a. 2; q. 111, a. 2; Ia IIae, q. 9, a. 6; III Cont. Gent., cap. LXXXVIII, LXXXIX, XCI; De Verit., q.
22, a. 8; De Malo, q. 3, a. 3; Compend. Theol., cap. CXXIX).
O quarto discute-se assim. — Parece que Deus não pode mover a vontade criada.

1. Pois, tudo o que é movido por algo de estranho é coagido. Ora, como a vontade não pode ser coagida,
não é movida por nada de estranho. E portanto não pode ser movida por Deus.

2. Demais. — Deus não pode fazer com que os contraditórios sejam simultaneamente verdadeiros. Ora,
tal se daria se movesse a vontade; pois, ser movido voluntariamente é ser movido por si e não por
outro. Logo, Deus não pode mover a vontade.

3. Demais. — O movimento é atribuído mais ao motor do que ao móvel; por isso, um homicídio não é
atribuído à pedra, mas a quem a atirou. Se pois Deus move a vontade, resulta que as obras voluntárias
não são imputadas ao homem por o mérito ou o demérito. Ora, isto é falso. Logo, Deus não move a von-
tade.
Mas, em contrário, diz a Escritura (Fl 2, 13): Deus é o que opera em vós o querer e o perfazer.

SOLUÇÃO. — Assim como o intelecto, como já se disse (a. 3), é movido pelo objeto e por quem lhe deu
a virtude de inteligir, assim a vontade é movida pelo objeto, que é o bem, e por quem causa a virtude
volitiva. — Ora, a vontade pode ser movida por qualquer bem, como objeto; porém, só por Deus pode
ser movida suficiente e eficazmente. Pois, só pode mover um móvel, suficientemente, o motor, cuja
virtude ativa excede, ou, pelo menos, iguala a virtude passiva do móvel. Ora, a virtude Passiva da
vontade se estende ao bem universal, que é o seu objeto, assim como o objeto do intelecto é o ente
universal. Ora, como qualquer bem criado é particular e só Deus é o bem universal, só Deus satisfaz a
vontade e a move, suficientemente, como objeto. — Semelhantemente, a virtude volitiva também é
causada só por Deus. Pois, querer não é senão uma certa inclinação para o objeto da vontade, que é o
bem universal. Ora, é o primeiro motor, ao qual é proporcionado o fim último, que inclina para o bem
universal; assim como, nas coisas humanas, quem governa a multidão é que dirige para o bem comum.
— Por onde, de um e outro modo, é próprio de Deus mover a vontade; mas sobretudo, do segundo
modo, inclinando-a interiormente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que o movido por outro é coagido, se for movido
contra a sua inclinação própria; mas tal não se poderá dizer, se for movido por outro que lhe dá a
inclinação própria. Assim não é coagido o grave movido para baixo, pelo gerador. Por onde, Deus, que
dá à vontade a sua inclinação própria, não a coage, movendo-a.

RESPOSTA À SEGUNDA. — Ser movido voluntariamente é ser movido por si, i. é., por um princípio
intrínseco; mas este princípio pode proceder de outro princípio, que seja extrínseco. E assim, ser movido
por si não repugna ao ser movido por outro.

RESPOSTA À TERCEIRA. — Se a vontade fosse movida por outro, de modo a não ser absolutamente
movida por si, as suas obras não lhe seriam imputadas por mérito ou demérito. Mas o ser movida por
outro, não excluindo o ser movida por si mesma, como já se disse, resulta, conseqüentemente, que não
fica eliminada a razão do mérito nem do demérito.

## Art. 5 — Se Deus opera em todo agente.
(II Sent., dist., I, part. I, q. I, a. 4; III Cont. Gent., cap. LXVII ; De Pot., q. 3, a. 7; Compend. Theol.,
cap. CXXXV).
O quinto discute-se assim. — Parece que Deus não opera em todo agente.

1. Pois, não se deve atribuir a Deus nenhuma insuficiência. Ora, se Deus opera em todo agente, há-de
operar suficientemente. Logo, será supérflua a ação do agente criado.

2. Demais. — Uma operação não pode provir simultaneamente de dois agentes, assim como o
movimento numericamente uno não pode pertencer simultaneamente a dois móveis. Se portanto, a
operação da criatura agente provém de Deus, não pode provir da criatura, simultaneamente; e então
nenhuma criatura exerce qualquer operação.

3. Demais. — O que faz alguma coisa é causa da operação da coisa feita, porque lhe dá a esta a forma
pela qual opera. Se pois Deus é a causa da operação das coisas feitas por ele, é porque lhes dá a virtude
de operar. Mas isso foi no princípio, quando fez as coisas. Donde resulta que, ulteriormente, ele não age
sobre a criatura agente.
Mas, em contrário, diz a Escritura (Is 26, 12): Senhor, tu és o que fizeste em nós todas as nossas obras.

SOLUÇÃO. — Alguns entenderam a operação de Deus nos agentes, de modo tal que nenhuma virtude
criada pode operar nada, nas coisas, mas só Deus opera tudo imediatamente; assim, não seria o fogo
que aquece, mas Deus, no fogo; e assim por diante, semelhantemente. — Ora isto é impossível. —
Primeiro, porque ficaria destruída, nas coisas criadas, a ordem entre a causa e o causado, o que
importaria na impotência do criador, pois, pertence à virtude do agente dar ao seu efeito a virtude de
agir. Segundo, porque as virtudes operativas das coisas ser-lhes-iam atribuídas em vão se, com elas,
nada operassem. Demais, todas as coisas criadas seriam, de certo modo, vãs se fossem destituídas da
operação própria, porque cada coisa é feita para a sua operação. Pois, o imperfeito é sempre por causa
do perfeito. Por onde, assim como a matéria é por causa da forma, assim esta, que é um ato primeiro, é
por causa da sua operação, que é um ato segundo; de modo que a operação é o fim da coisa criada. E
portanto, a operação de Deus, nas coisas, há-de se entender de modo que estas tenham operação
própria.
Para evidenciá-lo devemos considerar que, dos quatro gêneros de causas, a matéria não é princípio de
ação, mas se comporta como sujeito recipiente do efeito da ação. Ao passo que o fim, o agente e a
forma se comportam como princípio de ação, mas numa certa ordem. Pois, o primeiro princípio da ação
é o fim, que move o agente; o segundo, o agente; o terceiro, afinal, a forma daquilo que o agente faz
agir, embora também o próprio agente atue pela sua forma, como é patente nas coisas artificiais. Assim,
o artífice é levado a agir pelo fim, que é a causa mesma operada, p. ex., uma arca ou um leito; e aplica à
ação o machado, que corta com o seu gume.
E, é, pois, destes três modos que Deus, opera em qualquer agente. — Primeiro, pela moção do fim.
Porque, buscando toda operação algum bem, verdadeiro ou aparente, e nada sendo ou parecendo bem
senão enquanto participa de alguma semelhança do sumo bem, que é Deus, resulta que Deus mesmo é
a causa final de qualquer operação. — Semelhantemente, deve-se também considerar que, sendo
muitos os agentes ordenados, sempre o agente segundo age em virtude do primeiro, pois, o primeiro
agente é que leva o segundo a agir. E então todos os seres agem em virtude de Deus mesmo e,
portanto, ele é a causa de todas as ações dos agentes. — Em terceiro lugar deve-se considerar que Deus
dá também as formas às criaturas agentes e lhes conserva a existência, além de mover as coisas a
operarem, aplicando as formas e as virtudes delas à operação, assim como o artífice usa do machado
para cortar, embora possa não ser quem deu a forma ao machado. Por onde, não somente Deus é a
causa das ações, por lhes ter dado a forma, princípio de ação, assim como se diz que o gerador dos
graves e dos leves é-lhes a causa do movimento; mas também porque conserva as formas e as virtudes
das coisas, assim como o sol é considerado a causa da manifestação dos corpos, por lhes dar e conservar
a luz, pela qual se manifestam as cores. E como a forma é intrínseca à coisa, e tanto mais quanto mais
primeira e universal; e como Deus mesmo é a causa própria, em todas as coisas, do ser universal, em si,
que de tudo, é o que nelas é mais íntimo; segue-se que Deus opera intimamente em todas as coisas. E
por isto, na Sagrada Escritura, as operações da natureza são atribuídas a Deus que é como operante nela
(Jó 10, 11): De pele e de carne me vestiste, de ossos e nervos me compuseste.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus opera suficientemente, nas coisas, ao modo de
agente primeiro; mas, nem por isso é supérflua a operação dos agentes segundos.

RESPOSTA À SEGUNDA. — Uma mesma ação não pode proceder de dois agentes, de uma mesma
ordem; mas, nada impede que uma e mesma ação proceda do agente primeiro e do segundo.

RESPOSTA À TERCEIRA. — Deus, não somente dá as formas às coisas, mas também as conserva na
existência, leva-as a agir e é fim de todas as ações, como ficou dito.

## Art. 6 — Se Deus pode fazer alguma coisa fora da ordem estabelecida para as coisas.
(Infra, q. 106, a. 3; III Cont. Gent., cap. XCVIII, XCIX; De Pot., q. 6, a 1; Compende. Theol., cap. CXXXVI).
O sexto discute-se assim. — Parece que Deus não pode fazer nada fora da ordem estabelecida para as
coisas.

1. Pois, como diz Agostinho, Deus instituidor e criador de todas as naturezas, nada faz contra a natureza.
Ora, o que está fora da ordem, naturalmente estabelecida para as coisas, é contra a natureza. Logo,
Deus não pode fazer nada fora dessa ordem estabelecida.

2. Demais. — Assim como a ordem da justiça provém de Deus, assim também, a da natureza. Ora, Deus
não pode fazer nada fora da ordem da justiça, porque então haveria de fazer coisas injustas. Logo, não
pode fazer nada fora da ordem da natureza.

3. Demais. — Deus instituiu a ordem da natureza. Se pois, fizesse alguma coisa fora dessa ordem seria
mutável, o que é inadmissível.
Mas, em contrário, diz Agostinho: Deus às vezes faz certas coisas contrárias ao curso habitual da
natureza.

SOLUÇÃO. — Como toda causa exerce o papel de princípio, de qualquer deriva uma certa ordem para os
seus efeitos. Por onde, as ordens se multiplicam com a multiplicação das causas; e assim como uma
causa está contida noutra, assim uma ordem, na outra. E portanto, a causa superior não está contida na
ordem da causa inferior, mas inversamente. E um exemplo claro disso nos dão as coisas humanas; pois,
do pai de família depende a ordem da casa, contida na ordem da cidade, que procede do seu
governador, o qual, por sua vez, está compreendido na ordem do rei, que rege todo o reino.
Se portanto, considera-se a ordem das coisas enquanto dependente da causa primeira, então Deus não
pode fazer nada contra a ordem delas; pois, se o fizesse, fá-lo-ia contra a sua presciência, vontade ou
bondade. — Se porém se considerar a ordem das coisas, enquanto dependente de qualquer das causas
segundas, então Deus pode operar fora da ordem delas. Porque ele não está sujeito à ordem das causas
segundas; antes, esta é que lhe está sujeita, como procedente dele, não por necessidade de natureza,
mas pelo arbítrio da vontade; pois poderia estabelecer outra ordem de coisas. Por onde, pode quando
quiser, agir contra a ordem instituída; p. ex., causando efeitos das causas segundas, sem elas, ou, produ-
zindo certos efeitos de que as causas segundas não são capazes. E por isso Agostinho diz: Deus age
contra o curso habitual da natureza; mas, contra a lei suma não age, porque seria agir contra si mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Se dois modos pode se dar algo, nas coisas naturais, fora
da ordem estabelecida. — De um modo, por ação do agente, que não deu a inclinação natural; assim, é
contra a natureza, o homem que não deu ao corpo grave a sua inclinação natural movê-lo para cima. —
De outro modo, por ação do agente de que depende a ação natural; o que não é contra a natureza,
como bem se vê no fluxo e refluxo do mar; embora seja contra o modo natural da água, que se move
para baixo. Pois, isto provém da impressão do corpo celeste, do qual depende a inclinação natural dos
corpos inferiores. Ora, como a ordem da natureza foi infundida nas coisas por Deus, o que ele fizer fora
dessa ordem não é contra a natureza. Por onde, diz Agostinho, que é natural a qualquer coisa o que lhe
foi estabelecido por quem é o autor de todo o modo, de todo número e de toda ordem da natureza.

RESPOSTA À SEGUNDA. — A ordem da justiça depende da relação com a causa primeira, que é a regra
de toda justiça. Por onde, fora dessa ordem, Deus nada pode fazer.

RESPOSTA À TERCEIRA. — Deus infundiu nas coisas uma ordem tal que reservasse para si o que
houvesse, às vezes, de fazer, diferentemente da causa. E por isso quando age fora dessa ordem não
muda.

## Art. 7 — Se tudo o que Deus faz, fora da ordem natural das coisas, é milagre.
(II Sent., dist. XVIII, q. 1, a. 3; III Cont. Cent., cap. CI; De Pot., q. 6, a. 2; II Thessal., cap. II. lect. II).
O sétimo discute-se assim. — Parece que nem tudo o que Deus faz, fora da ordem natural das coisas,
é milagre.

1. Pois, a criação do mundo e das almas, e a justificação dos ímpios, Deus as fez fora da ordem natural,
pois, não as fez por meio da ação de nenhuma causa natural. E contudo nada disso é considerado
milagre. Logo, nem tudo o que Deus faz, fora da ordem natural das coisas, é milagre.

2. Demais. — Considera-se milagre, como diz Agostinho, algo de árduo e insólito, superior à faculdade
da natureza e à esperança de quem o admira. Ora, há certas coisas feitas, fora da ordem da natureza, e
que contudo não são árduas, como a restauração e a sanificação das águas (IV Rg, 2). Nem são insólitas,
porque acontecem freqüentemente; como quando os enfermos eram colocados nas praças para que, à
sombra de Pedro, sarassem. Nem são superiores à faculdade da natureza; assim, quando doentes saram
de febres. Nem são superiores à esperança; assim, todos esperamos a ressurreição dos mortos, que
todavia se há de dar, fora da ordem da natureza. Logo, nem tudo o que se faz, fora da ordem da
natureza, é milagre.

3. Demais. — A palavra milagre vem de admiração. Ora, esta se dá em relação às coisas manifestas aos
sentidos. E às vezes algumas coisas se dão, fora da ordem natural, não manifestas ao sentido; como
quando os Apóstolos vieram a ter ciência, sem que a procurassem ou a aprendessem. Logo, nem tudo o
que se dá, fora da ordem da natureza; é milagre.
Mas, em contrário, diz Agostinho: O que Deus faz contra o curso da natureza, de nós conhecido, e
habitual, chama-se maravilha ou milagre.

SOLUÇÃO. — A palavra milagre vem de admiração. Ora, esta surge quando, sendo a causa oculta, os
efeitos são manifestos; assim, admiramo-nos vendo um eclipse do sol e ignorando-lhe a causa, como diz
Aristóteles. Ora, como a causa de um efeito aparente pode ser conhecida de uns e ignorada de outros,
daí vem que é admirável para aqueles e não o é para estes; assim, quando o rústico se admira de um
eclipse do sol, mas não, o astrólogo. Ora, chama-se milagre o que como provoca a admiração, porque
tem em si causa oculta a todos, e que é Deus. Por onde, chama-se milagre tudo o que Deus faz, fora das
causas que nós conhecemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a criação e a justificação do ímpio sejam
operadas só por Deus, nem por isso, propriamente falando, se chamam milagres, porque não são de
natureza a ser feitas por outras causas; e, assim, não se dão fora da ordem da natureza, pois que a essa
ordem não pertencem.

RESPOSTA À SEGUNDA. — Chama-se ao árduo milagre, não por causa da dignidade da coisa na qual ele
se dá, mas porque excede à faculdade da natureza. E semelhantemente, também se chama insólito, não
porque não se dê freqüentemente, mas porque está fora da ordem natural. E ainda superior à faculdade
da natureza se chama a uma coisa feita, não só por causa da sua substância, mas também por causa da
ordem e do modo de fazer. Enfim, diz-se que o milagre é superior à esperança da natureza, não, porém,
superior à esperança da graça, proveniente da fé, pela qual acreditamos na ressurreição dos mortos,

RESPOSTA À TERCEIRA. — Embora a ciência dos Apóstolos não fosse em si manifesta, manifestava-se
contudo nos efeitos, que a tornavam miraculosa.

## Art. 8 — Se um milagre é maior que outro.
(Ia IIae, q. 113; a. 10; III Cont. Gent., cap. CI).
O oitavo discute-se assim. — Parece que um milagre não é maior que outro.

1. Pois, diz Agostinho: Nas coisas miraculosamente feitas, toda a razão do feito está na potência de
quem faz. Ora, todos os milagres se fazem pela potência de Deus. Logo, um não é maior que outro.

2. Demais. — O poder de Deus é infinito. Ora, como o infinito excede, sem nenhuma proporção, todo
finito, não causa admiração que produza antes um efeito, que outro. Logo, um milagre não é maior que
outro.
Mas, em contrário, é o que o Senhor diz, na Escritura, falando das obras miraculosas (Jo 14, 12): Esse
fará também as obras que eu faço, e fará outras ainda maiores.

SOLUÇÃO. — Não se pode dizer que nada seja milagroso, relativamente ao poder divino; porque
qualquer coisa feita é mínima em comparação com esse poder, conforme a Escritura (Is 40, 15): Eis que
as nações são reputadas como uma gota de água que cai dum balde e como um grão na balança. Mas
podemos chamar milagroso a um fato, por comparação com a faculdade da natureza, que ele excede.
Por onde, tanto maior se considera o milagre quanto mais excede essa faculdade. Ora, pode algum fato
exceder a faculdade da natureza, de três modos. — De um, quanto à sua substância; assim, se dois
corpos ocupam simultaneamente o mesmo lugar, se o sol retrocede, se o corpo humano é glorificado,
coisas todas que a natureza de nenhum modo pode fazer e por isso ocupam o grau sumo, entre os
milagres. — De outro modo, um fato excede a faculdade da natureza, não em si mesmo, mas
relativamente à coisa na qual se dá; assim, a ressuscitação dos mortos, a iluminação dos cegos e coisas
semelhantes. Pois, a natureza pode causar a vida, mas não num morto; e pode sustentar a vista, mas
não num cego. E tais fatos ocupam o segundo lugar entre os milagres. — De terceiro modo, um fato
excede a faculdade da natureza, quanto à maneira e à ordem por que é feito; assim, se alguém,
subitamente, por virtude divina, sara de febre, sem a cura e o processo habitual da natureza, em tais
casos; e se o ar, imediatamente, por divina virtude, se condensa em chuvas, sem as pausas naturais,
como aconteceu pelas preces de Samuel e de Elias. E tais fatos ocupam o ínfimo lugar, entre os milagres.
— Ora, todos esses fatos têm graus diversos relativamente aos modos diversos pelos quais excedem a
faculdade da natureza.
Donde se deduzem claras as RESPOSTAS ÀS OBJEÇÕES relativas ao poder divino.