# Questão 15: Das idéias.
Depois da consideração da ciência de Deus resta considerar as idéias. E nesta questão discutem-se três
artigos:

## Art. 1 — Se existem idéias.
(Infra, q. 44, a. 3; I Sent., dist. XXXVI, q. 2, a. 1; De Verit., q. 3, a. 1; I Metaph., lect. XV).
O primeiro discute-se assim. — Parece que não existem idéias.

1. — Pois, Dionísio diz que Deus não conhece as coisas pela idéia. Ora, as idéias não têm outro fim,
senão serem meios de se conhecerem as coisas. Logo, não existem idéias.

2. Demais. — Deus conhece, em si mesmo, todos os seres, como se disse. Ora, não se conhece a si
mesmo, por meio da idéia. Logo, nem outros seres.

3. Demais. — A idéia existe como princípio de conhecer e de operar. Ora, a ciência divina é princípio
suficiente de conhecer e operar todas as coisas. Logo, não é necessário que tenha idéias.
Mas, em contrário, diz Agostinho: As idéias têm tanta importância que, sem as inteligir, ninguém poderá
ser sábio.

SOLUÇÃO. — É necessário admitir-se a existência das idéias na mente divina. Pois, ao que se chama em
grego idéia chama-se, em latim, forma. Por onde, entendem-se por idéias as formas das outras coisas
existentes fora delas. Ora, a forma de qualquer ser, existente fora deste, pode servir para dois fins: de
exemplar daquilo de que é forma, ou de princípio de conhecimento do mesmo, enquanto as formas dos
cognoscíveis se consideram existentes no conhecente. E, quanto a esses dois fins, é necessário
admitirem-se idéias, o que assim se demonstra. Em todos os seres não gerados pelo acaso, é necessário
seja a forma o fim da geração de cada um deles. Pois, o agente agiria, por causa da forma, senão
enquanto também é semelhança desta, o que se pode dar de dois modos. Em certos agentes a forma da
coisa a ser feita preexiste, pelo ser natural, como nos que agem por natureza; assim, o homem gera o
homem e o fogo, o fogo. Em outros, porém, pelo ser inteligível, como nos que agem pelo intelecto;
assim, a semelhança da casa preexiste, na mente do construtor. E a essa semelhança podemos chamar
idéia da casa, porque o artífice entende assimilar a casa à forma que concebeu na mente. Ora, o mundo,
não sendo feito por acaso, mas por Deus, agindo pela inteligência, como a seguir se dirá, é necessário
que haja na mente divina uma forma, à semelhança da qual o mundo foi feito. E nisto consiste a
essência da idéia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus não intelige as coisas por uma idéia existente fora
de si. E assim, Aristóteles refuta a opinião de Platão sobre as idéias, que as admitia existentes por si, e
não no intelecto.

RESPOSTA À SEGUNDA. — Embora Deus, pela sua essência, se conheça a si mesmo, e aos outros seres,
contudo, aquela é princípio operativo destes, mas, não de si mesma. Por onde tem caráter de idéia,
enquanto comparada com os outros seres, mas não, enquanto comparada com Deus mesmo.

RESPOSTA À TERCEIRA. — Deus, pela sua essência é semelhança de todas as coisas. Por onde, a idéia,
em Deus, não difere da sua essência.

## Art. 2 — Se há muitas idéias.
(Infra, q. 44, a. 3; q. 47, a. 1, ad 2; I Sent., dist. XXXVI, q. 2, a. 2; III, dist. XIV, a. 2, q. 2; I Cont. Gent., cap.

LIX; De Pot., q. 3, a. 16, ad 12, 13; De Verit., q. 3, a. 2; Quodl., IV, q. 1).
O segundo discute-se assim. — Parece que não há muitas idéias.

1. — Pois, a idéia, em Deus, é a sua essência. Ora a essência de Deus é só uma. Logo, só uma também a
idéia.

2. Demais. — Assim como a idéia é princípio de conhecer e de obrar, assim também, a arte e a
sapiência. Ora, em Deus, não há muitas artes e muitas sapiências. Logo, nem muitas idéias.

3. Demais. — Se se disser que as idéias se multiplicam, pelas relações às diversas criaturas, responde-se
em contrário. — A pluralidade das idéias existe abeterno. Se, pois, são muitas as idéias, e as criaturas
são temporais, o temporal será a causa do eterno.

4. Demais. — Tais relações, ou existem realmente, só nas criaturas, ou também em Deus. Se somente
nas criaturas, como estas não existem abeterno, não existirá a pluralidade das idéias, se se multiplicam
só segundo essa relação. Se, porém, realmente existem em Deus, segue-se que, em Deus, há outra
pluralidade real, que não a das Pessoas, o que vai contra Damasceno quando diz que, em Deus, tudo é
unidade, exceto a não geração, a geração e a processão. Logo, não há muitas idéias.
Mas, em contrário, Agostinho: As idéias são certas formas principais, ou razões estáveis e incomutáveis
das coisas, pois, elas não são formadas; e, por isso são eternas, existentes sempre do mesmo modo e
contidas na inteligência divina. Mas, embora não nasçam nem desapareçam, dizemos, contudo, que,
segundo elas, se forma tudo o que pode nascer e perecer, e tudo o que nasce e perece.

SOLUÇÃO. — É necessário admitir muitas idéias. Para evidenciá-lo, devemos considerar que, em
qualquer efeito, o fim último é o propriamente visado pelo agente principal; assim, a ordem do exército,
pelo general. Ora, o que de melhor existe nas coisas é o bem da ordem do universo, como se vê no
Filósofo. Portanto, a ordem do universo é propriamente a visada por Deus, e não provém de uma
sucessão acidental de agentes, como quiseram alguns. Esses diziam, que Deus criou somente a primeira
criatura; esta criou a segunda, e assim por diante, até produzir-se a tão grande multidão dos seres; e,
segundo esta opinião, Deus não teria tido senão a idéia da primeira criatura. Mas, se a ordem mesma do
universo a criou ele e a teve em mira, é necessário que tenha tido a idéia dessa ordem. Ora, não
podemos ter idéias de um todo se não tivermos as idéias próprias das partes de que ele se constitui. P.
ex., o construtor não pode conceber a espécie de uma casa sem ter a idéia própria de cada uma das suas
partes. E, portanto, hão de necessariamente existir, na mente divina, as idéias próprias de todas as
coisas. E, por isso, diz Agostinho: Cada ser foi, com a sua idéia própria, criado por Deus. Donde se conclui
que há muitas idéias na mente divina.
E é fácil compreender, que tal não repugna à simplicidade divina, se refletirmos que a idéia da coisa feita
está na mente do operante, como inteligida; não, porém, como espécie, pela qual é inteligida, que é a
forma atualizante do intelecto. Pois, a forma da casa é, na mente do construtor, algo por ele inteligido, à
semelhança da qual constrói a casa, na matéria. Portanto, não é contra a sua simplicidade o divino
intelecto inteligir muitas coisas; mas sê-lo-ia, se fosse informado por muitas espécies.
Por onde, há na mente divina, como inteligidas por ela, muitas idéias, o que podemos explicar da
seguinte maneira. Deus conhece perfeitamente a sua própria essência, e, portanto, a conhece de todos
os modos pelos quais ela é cognoscível. Ora, pode ser conhecida, não somente como em si é, mas
enquanto participável pelas criaturas, por algum modo de semelhança. Pois, cada criatura tem a sua
espécie própria, segundo participa de algum modo da semelhança da divina essência. Assim, pois,
enquanto Deus conhece a sua essência, como imitável, de certo modo, por tal criatura, conhece-a como
a razão própria e como a idéia dessa criatura; e assim por diante. Por onde, é claro que Deus intelige
muitas razões próprias, de muitas coisas, que são muitas idéias.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A idéia não designa a essência divina, como tal. Mas,
enquanto exemplar ou razão desta ou daquela coisa. Por isso, havendo várias razões inteligidas, numa
mesma essência, dizemos haver muitas idéias.

RESPOSTA À SEGUNDA. — A sapiência e a arte assim se chamam como designativas do modo pelo qual
Deus intelige; mas, a idéia, como o que intelige. Ora, Deus, por uma só intelecção intelige muitas coisas,
e não somente as intelige tais como são, mas também como foram inteligidas, o que é inteligir muitas
razões das mesmas. Assim, do artífice, que intelige a forma de uma casa, realizada na matéria, dizemos
que intelige a casa; quando, porém, intelige a forma da casa, enquanto pensada por si, inteligindo-se
como a inteligindo, intelige a idéia ou a razão da casa. Ora, Deus, não somente intelige muitas coisas,
pela sua essência, mas intelige-se ainda como as inteligindo assim. Ora, isto é inteligir muitas razões
delas, ou existirem muitas idéias, no seu intelecto, como inteligidas.

RESPOSTA À TERCEIRA. — Tais relações, pelas quais se multiplicam as idéias, não são causadas pelas
coisas, mas, pelo intelecto divino, comparando a sua essência com elas.

RESPOSTA À QUARTA. — As relações multiplicativas das idéias não estão nas coisas criadas, mas, em
Deus. Pois, não são relações reais, como aquelas pelas quais as Pessoas se distinguem, mas, relações
inteligidas por Deus.

## Art. 3 — Se Deus tem idéias de tudo o que conhece.
(I Sent., dist. XXXVI, q. 2, a. 3; De Pot., q. 1, a. 5, ad 10, 11; q. 3, a. 1, ad 13; De Verit., q. 3, a. 3, sqq.; De
Div. Nom., cap. V, lect. III).
O terceiro discute-se assim. — Parece que Deus não tem idéias de tudo o que conhece.

1. — Pois, Deus não tem idéia do mal, porque daí resultaria que nele há mal. Ora, o mal Deus o conhece.
Logo, nem de tudo o que Deus conhece tem idéias.

2. Demais. — Deus conhece as coisas que não existem, nem existirão, nem existiram, como se disse.
Ora, de tais coisas não há idéias; pois, diz Dionísio: os exemplares são as divinas vontades,
determinativas e efetivas das coisas. Logo, nem de tudo o que Deus conhece tem idéias.

3. Demais. — Deus conhece a matéria prima, não suscetível de idéia, por não ter nenhuma forma. Logo,
a mesma conclusão.

4. Demais. — Sabemos que Deus conhece, não só as espécies, mas também os gêneros, os singulares e
os acidentes. Ora, deles não há idéias, segundo a opinião de Platão, que, primeiro, introduziu as idéias,
como diz Agostinho. Logo, nem de tudo o que Deus conhece tem idéias.
Mas, em contrário. — As idéias são as razões existentes na mente divina, como se vê em Agostinho. Ora,
Deus tem razões próprias de tudo o que conhece. Logo, tem idéia de tudo o que conhece.

SOLUÇÃO. — Considerando Platão as idéias como princípio do conhecimento e da geração das
coisas, com ambos estes princípios se relaciona a idéia, enquanto existente na mente divina. Assim,
como princípio da produção das coisas, pode chamar-se exemplar e é próprio do conhecimento prático.
Como, de outro lado, princípio cognoscitivo, chama-se propriamente razão, e pode também ser próprio
à ciência especulativa. Ora, como exemplar, diz respeito a todas as coisas feitas por Deus, em qualquer
tempo; como princípio cognoscitivo, diz respeito a todas as coisas conhecidas de Deus, embora não
sejam criadas em nenhum tempo; e a todas as conhecidas de Deus, na sua razão própria, e enquanto
dele conhecidas por modo especulativo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O mal é conhecido de Deus, não pela razão própria, mas
pela do bem. Por onde, Deus não tem idéia do mal, enquanto a idéia é exemplar, nem enquanto é razão.

RESPOSTA À SEGUNDA. — Daquelas coisas que não existem, nem existirão, nem existiram, Deus não
tem conhecimento prático, senão só relativamente ao seu poder. Por onde, delas Deus não tem idéia
enquanto esta significa exemplar, mas somente, enquanto significa noção.

RESPOSTA À TERCEIRA. — Platão, segundo alguns, admitia a matéria não criada, e assim, não ensinou
que houvesse idéia, mas, concausa da matéria. Mas, para nós, que consideramos a matéria criada por
Deus, embora não sem a forma, Deus tem certamente idéia da matéria; não diferente, porém, da idéia
do composto. Pois, a matéria, em si, não tem existência nem é cognoscível.

RESPOSTA À QUARTA. — Aos gêneros não pode corresponder uma idéia diferente da de espécie, idéia
significando exemplar; pois, um gênero nunca se realiza a não ser em alguma espécie. O mesmo
também se dá com os acidentes ligados ao sujeito inseparavelmente, porque existem simultaneamente
com este. Mas, aos acidentes sobrevenientes ao sujeito corresponde uma idéia especial. Assim, por
exemplo, o artífice, pela forma da casa, faz todos os acidentes conseqüentes à casa, desde o princípio;
mas os que sobrevêm à casa já feita, como as pinturas e outros, ele os faz por alguma outra forma. Ora,
segundo Platão, aos indivíduos não convém idéia diferente da espécie, tanto porque os seres singulares
se individuam pela matéria, que considerava increada, como alguns dizem, e concausa da idéia, como
porque a tendência da natureza se detém nas espécies, nem produz os indivíduos senão para as
conservar. Ora, a providência divina, não só se estende às espécies, mas também, aos indivíduos, como
a seguir se dirá.