# Questão 79: Das potências intelectivas.
Em seguida se tratará das potências intelectivas. E nesta questão treze artigos se discutem:

## Art. 1 — Se o intelecto é uma potência da alma ou se é a essência mesma dela.
O primeiro discute-se assim. ― Parece que o intelecto não é uma potência da alma, mas é a essência
mesma dela.

1. ― Pois, intelecto é o mesmo que mente. Ora esta é, não uma potência, mas a essência mesma da
alma, como diz Agostinho: A mente e o espírito não tem significação relativa, mas demonstram a
essência. Logo, o intelecto é a essência mesma da alma.

2. Demais. ― Os diversos gêneros de potências da alma não se unificam por nenhuma potência, mas só
pela essência da alma. Ora, o apetitivo e o intelectivo são dois gêneros diversos das potências da alma,
como já se disse, e que se unificam pela mente; pois Agostinho nesta compreende a inteligência e a
vontade. Logo, a mente e o intelecto são a essência mesma da alma e não potências suas.

3. Demais. ― Segundo Gregório, o homem intelige com os anjos. Ora estes são chamados mentes e
intelectos. Logo, a mente e o intelecto do homem não constituem uma potência da alma, mas a alma
mesma.

4. Demais. ― É por ser imaterial que uma substância é intelectiva. Ora, a alma é imaterial por essência.
Logo, por essência, é intelectiva.
Mas, em contrário, o Filósofo considera o intelectivo como potência da alma.

SOLUÇÃO. ― É necessário admitir-se, conforme o que já ficou estabelecido, que o intelecto é uma
potência da alma e não a essência mesma dela. Pois, o princípio imediato de operação é a essência
mesma do operante só quando a operação mesma é ser deste. Porquanto, do mesmo modo que a
potência está para a operação, como para o seu ato, assim também está a essência para o ser. Ora, só
em Deus é que se identifica o intelecto com a essência. Ao passo que em todas as criaturas inteligentes,
o intelecto é uma potência do inteligente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Umas vezes sentido se toma na acepção de potência;
outras, porém, pela alma sensitiva mesma. Ora, esta é designada pelo nome da sua potência mais
importante, que é o sentido. E, semelhantemente, a alma intelectiva é designada, umas vezes, pelo
nome de intelecto, como pela sua virtude mais importante; assim, se diz que o intelecto é uma
substância. E também deste modo Agostinho diz que a mente é espírito ou essência.

RESPOSTA À SEGUNDA. ― O apetitivo e o intelectivo são gêneros diversos das potências da alma,
segundo as naturezas diversas dos objetos. Ora, o apetitivo, em parte, convém com o intelectivo e, em
parte, com o sensitivo, quanto ao modo de operar por meio de um órgão corpóreo ou sem tal órgão;
pois o apetite resulta da apreensão. E é assim que Agostinho compreende a vontade na mente e o
Filósofo, na razão.

RESPOSTA À TERCEIRA. ― Nos anjos não pode haver outra virtude senão a intelectiva e a vontade,
conseqüente ao intelecto. E, por isso, o anjo se chama mente ou intelecto, porque nisso consiste toda a
virtude do mesmo. A alma, porém, têm muitas outras potências; assim, as sensitivas e as nutritivas. E
portanto, não há símile.

RESPOSTA À QUARTA. ― A imaterialidade mesma da substância inteligente criada não se lhe identifica
com o intelecto; mas, dessa imaterialidade lhe advém à virtude de inteligir. Por onde, não é necessário
que o intelecto seja a substância da alma, senão virtude e potência dela.

## Art. 2 — Se o intelecto é uma potência passiva.
(III. Sent., dist. XIV, a. 1, qª 2; De Verit., q. 16, a. 1, ad 13; III De Anima, lect. VIII, IX).
O segundo discute-se assim. ― Parece que o intelecto não é uma potência passiva.

1. ― Os seres sofrem pela matéria e agem pela forma. Ora, a virtude intelectiva resulta da
imaterialidade da substância inteligente. Logo, conclui-se que o intelecto não é potência passiva.

2. Demais. ― A potência intelectiva é incorruptível, como antes se disse (q. 75, a. 6). Ora, o intelecto,
sendo passivo, é corruptível, como já se disse. Logo, a potência intelectiva não é passiva.

3. Demais. ― O agente é mais nobre que o paciente, como diz Agostinho e Aristóteles. Ora, as potências
da parte vegetativa, que, entretanto, são as ínfimas, dentre as potências da alma, são todas ativas. Logo,
com maioria de razão, as potências intelectivas, que são as supremas, são todas ativas.
Mas, em contrário, diz o Filósofo, que inteligir é, de certo modo, sofrer.

SOLUÇÃO. ― Sofrer se emprega em tríplice sentido. ― De modo propríssimo, quando uma coisa que
convém a outra, por natureza ou inclinação própria desta, é da mesma removida. Assim, quando a água
perde a frieza, pela calefação, ou quando um homem está doente ou triste. ― Segundo, de modo
menos próprio, diz-se que alguém sofre, quando é privado de alguma causa, quer esta lhe seja
conveniente, quer não; e, assim, diz-se que sofre não só quem está doente, mas ainda quem está são;
não só quem está triste, mas ainda quem está alegre; ou de qualquer modo por que alguém seja
alterado ou movido. ― Terceiro, diz-se que alguém sofre, comumente, só porque o que é potencial em
relação a alguma causa recebe aquilo em relação ao que era potencial, sem ser privado de nada. E,
deste modo, diz-se que sofre tudo o que passa da potência para o ato, mesmo quando se aperfeiçoa.
Assim, o nosso inteligir é sofrer.
O que bem se evidencia pela razão seguinte. A operação do intelecto, como já ficou dito antes (q. 78, a.
1), se exerce sobre o ser universal. Ora, pode-se saber se o intelecto está em ato ou em potência, se se
sabe como ele se comporta em relação ao ser universal. Assim, há um intelecto que está para o ser
universal como o ato do ser total. E tal é o intelecto divino, que é a essência de Deus, no qual original e
virtualmente todo ser preexiste como na causa primeira; por isso, o intelecto divino não é potencial,
mas é ato puro. E nenhum intelecto criado pode ser ato em relação ao ser universal total porque, então,
deveria ser infinito. Por onde, todo intelecto criado, pelo fato mesmo de o ser, não pode ser ato de
todos os inteligíveis, mas está para eles como a potência para o ato.
Ora, esta se comporta de duplo modo em relação ao ato. Há uma potência que é sempre perfeita pelo
ato; como acontece com a matéria dos corpos celestes. Há outra potência que não é sempre atual, mas
passa para o ato, como acontece com os seres susceptíveis de geração e corrupção. ― Assim, o intelecto
angélico está sempre em ato em relação aos seus inteligíveis, por causa da proximidade com o intelecto
primeiro, que é ato puro, como antes se disse (q. 58, a. 1). Porém, o intelecto humano, ínfimo na ordem
dos intelectos e maximamente remoto da perfeição do intelecto divino, é potencial em relação aos
inteligíveis; e, no princípio, éuma como tábua em que nada está escrito, como diz o Filósofo. E isto se vê
claramente do fato de, a princípio, sermos inteligentes só em potência; depois é que nos tornamos
inteligentes em ato. ― Assim, pois, é claro que o nosso inteligir é um como sofrer, conforme o terceiro
modo da paixão. E, por conseqüência, o intelecto é uma potência passiva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção é procedente, em relação ao primeiro e ao
segundo modo da paixão, que são próprios da matéria prima, Porém, o terceiro modo é o de qualquer
ser existente em potência e reduzido a ato.

RESPOSTA À SEGUNDA. ― O intelecto passivo, segundo alguns, chama-se apetite sensitivo, no qual
estão as paixões da alma e que também, segundo Aristóteles, se chama racional por participação,
porque obedece à razão. Segundo outros, porém, o intelecto passivo se chama virtude cogitativa, que é
denominada razãoparticular. E, de um e outro modo, passivo pode ser tomado em acepção conforme
aos dois primeiros modos da paixão: enquanto o assim chamado intelecto é o ato de um órgão
corpóreo. Mas, o intelecto que é potencial em relação aos inteligíveis e ao qual Aristóteles, por isso,
chama intelecto possível, só é passivo do terceiro modo; pois, não é ato de órgão corpóreo. E, portanto,
é incorruptível.

RESPOSTA À TERCEIRA. ― O agente é mais nobre que o paciente se à mesma coisa se referirem à ação e
a paixão; não, porém, sempre, se se referirem a coisas diversas. O intelecto, porém, é virtude passiva,
em relação ao ser universal total. Ao passo que o vegetativo é ativo em relação a um certo ser
particular, a saber, o corpo conjunto. Por onde, nada impede tal passividade seja mais nobre que uma
tal atividade.

## Art. 3 — Se se deve admitir um intelecto agente.
(Supra. Q. 54. a. 4; II Cont. Gent., cap. LXXVII; De Spirit. Creat., a. 9, Compend. Theol., cap. LXXXIII; Qu.
De Anima, a. 4; III De Anima, lect. X).
O terceiro discute-se assim. ― Parece que não se deve admitir um intelecto agente.

1. ― Pois, o sentido está para os sensíveis assim como o intelecto para os inteligíveis. Ora, como o
sentido é potencial em relação aos sensíveis, não se admite um sentido agente, mas somente o
paciente. Logo, como o nosso intelecto é potencial em relação aos inteligíveis, resulta que não se deve
admitir um intelecto agente, mas só o possível.

2. Demais. ― Se se disser que, no sentido, há também algum agente, como luz, responde-se, em
contrário, o seguinte. ― A luz é necessária para a visão, enquanto torna o meio atualmente lúcido; mas
é a cor mesma, em si, a causa do lúcido. Ora, não havendo, na operação do intelecto, nenhum meio que
precise ser atualizado, nenhuma necessidade há de intelecto agente.

3. Demais. ― O paciente recebe em si e a seu modo a semelhança do agente. Ora, o intelecto possível é
uma virtude imaterial e, portanto, a sua imaterialidade basta para que nele sejam recebidas as formas,
imaterialmente. Mas é pelo fato mesmo de ser imaterial que uma forma é inteligível em ato. Logo,
nenhuma necessidade há de admitir um intelecto agente que torne as espécies inteligíveis em ato. Logo,
nenhuma necessidade há de admitir um intelecto agente que torne as espécies inteligíveis em ato.
Mas, em contrário, diz o Filósofo: como em toda a natureza, assim também na alma há um princípio
pelo qual ela tudo se faz e outro pelo que tudo faz. Logo é preciso admitir um intelecto agente.

SOLUÇÃO. ― Para Platão, nenhuma necessidade havia de se admitir um intelecto agente que
atualizasse os inteligíveis, senão talvez para fornecer a luz inteligível a quem intelige, como a seguir se
dirá (a. 4; q. 84, a. 6). Pois, o mesmo filósofo ensina que as formas das coisas naturais subsistem sem
matéria e, por conseqüência, são inteligíveis; pois é por ser imaterial que um ser é inteligível em ato. E
tais formas ele as denomina, espécies ouidéias, por cuja participação, ensina, se forma não só a matéria
corpórea, para que os indivíduos fiquem naturalmente constituídos nos gêneros e espécies próprios,
mas também os nossos intelectos, para que tenham ciência dos gêneros e espécies das coisas.
Mas Aristóteles, de um lado não admitindo a subsistência das formas das coisas naturais, sem matéria; e
de outro, dizendo que as formas existentes na matéria não são inteligíveis em ato, resulta que as
naturezas ou formas das coisas sensíveis, que inteligimos, não são inteligíveis em ato. Ora, nada passa
da potência para o ato senão por um ser em ato; assim, o sentido torna-se atual pelo sensível atual.
Logo, é necessário admitir-se uma virtude, no intelecto, que atualize os inteligíveis, abstraindo as
espécies das condições materiais. E essa é a necessidade de se admitir um intelecto agente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como os sensíveis existem em ato fora da alma, não é
necessário haver um sentido agente. ― Por onde é claro que, na parte nutritiva, todas as potências são
ativas; porém, na sensitiva, todas passivas; e, por fim, na intelectiva, há algo de ativo e algo de passivo.

RESPOSTA À SEGUNDA. ― A respeito do efeito da luz há duas opiniões. ― Assim dizem uns, a luz,
tornando as cores visíveis em ato, é necessária para a visão. E, então, semelhantemente e pela mesma
razão, é necessário um intelecto agente, para inteligir, como é necessária a luz para ver. ― Outros,
porém, dizem que a luz é necessária para a visão, não porque torne as cores visíveis em ato, mas para
que torne o meio lúcido em ato, como ensina o Comentador. E, então, a semelhança que Aristóteles
descobre entre o intelecto agente e a luz está em que, assim como esta é necessária para se ver, assim
aquele, para se inteligir; não porém pela mesma razão.

RESPOSTA À TERCEIRA. ― Suposto o agente, a sua semelhança deve ser recebida nos diversos seres,
diversamente, segundo a disposição diversa deles. Mas, se o agente não preexiste, para nada serve a
disposição do recipiente. Ora, o inteligível em ato não é algo de existente em a natureza das coisas,
quanto à natureza dos seres sensíveis, não subsistentes sem matéria. Por onde, para inteligir não basta
à imaterialidade do intelecto possível, sem o intelecto agente, que, por abstração, atualiza os
inteligíveis.

## Art. 4 — Se o intelecto agente faz parte da alma.
(II Sent., dist. XVII. Q. 2, a. 1; II Cont. Gent., cap. LXXVI, LXXVIII; De Spirit Creat., a 10; Qu. De Anima, a. 5;
Compend. Theol, cap. LXXXVI; III De Anima, lect. X).
O quarto discute-se assim. ― Parece que o intelecto agente não faz parte da alma.

1. ― Pois, o efeito do intelecto agente é iluminar, para que possamos inteligir. Ora, isto se faz por algo
de mais elevado que a alma, segundo a Escritura (Jo 1, 9): Era a luz verdadeira que ilumina a todo
homem que vem a este mundo. Logo resulta, que o intelecto agente não faz parte da alma.

2. Demais. ― O Filósofo diz que não se pode atribuir ao intelecto agente que ora intelige e ora, não. Ora,
a nossa alma não intelige sempre, mas, ora, sim, ora, não. Logo, o intelecto agente não faz parte da
alma.

3. Demais. ― O agente e o paciente bastam para agir. Se, pois, o intelecto possível ― virtude passiva ―
e, semelhantemente, o intelecto agente ― virtude ativa ― fazem parte da nossa alma, resulta que o
homem poderá inteligir sempre que quiser, o que, evidentemente, é falso. Logo, o intelecto agente não
faz parte da nossa alma.

4. Demais. ― O Filósofo diz, que o intelecto agente é um ser de substância atual. Ora, nada pode ser ao
mesmo tempo atual e potencial. Se, portanto, o intelecto possível ― potencial em relação a todos os
inteligíveis ― faz parte da nossa alma, resulta a impossibilidade de também dela fazer parte o intelecto
agente.

5. Demais. ― Se o intelecto agente faz parte da nossa alma, é necessário que seja uma potência.
Porquanto, não é nem paixão nem hábito; pois, os hábitos e as paixões não desempenham função de
agente em relação às paixões da alma; mas antes, a paixão é a ação mesma da potência passiva, ao
passo que o hábito é algo resultante dos atos. Ora, toda potência, emanando da essência da alma,
segue-se que o intelecto agente procede dessa mesma essência e, então, não está na alma por
participação de algum intelecto superior, o que é inadmissível. Logo, o intelecto agente não faz parte da
alma.
Mas, em contrário, diz o Filósofo, que é necessário existam na alma estas diferenças, a saber, o intelecto
possível e o agente.

SOLUÇÃO. ― O intelecto agente, de que se fala o Filósofo, faz parte da alma. E isso se evidencia
considerando que é necessário admitir-se, além da alma intelectiva humana, a existência de um
intelecto superior, do qual a alma obtém a virtude de inteligir. Pois, sempre, o ser participante, móvel,
imperfeito, preexige algo de anterior a si, que seja tal, por essência, imóvel e perfeito. Ora, a alma
humana é intelectiva, por participação da virtude intelectual. E a prova está em que é intelectiva, não na
sua totalidade, mas só em parte; pois, chega à inteligência da verdade, pelo discurso e pelo movimento,
argumentando. E também tem inteligência imperfeita, quer por não inteligir tudo, quer por passar da
potência para o ato, quando intelige. Logo, é necessário exista um intelecto mais alto, que ajude a alma
a inteligir.
Ora, certos ensinaram que esse intelecto, separado por substância, é o intelecto agente que,
iluminando, por assim dizer, os fantasmas, torna-os inteligíveis em ato. ― Mas, dado que exista tal
intelecto agente separado, ainda assim é necessário admitir, na alma humana mesma, alguma virtude
participada desse intelecto superior, pela qual a alma atualize os inteligíveis. Do mesmo modo que nos
outros seres naturais perfeitos, existem, além das causas universais agentes, as virtudes próprias ínsitas
neles, singularmente, e derivadas dos agentes universais. Assim, não somente o sol gera o homem, mas
há ainda, em cada homem, a virtude geratriz de outro; e o mesmo se dá com os outros animais
perfeitos. Ora, dentre os seres inferiores, não há nenhum mais perfeito que a alma humana. Por onde, é
necessário concluir que há, nela, uma virtude derivada do intelecto superior e pela qual ela pode
iluminar os fantasmas. E isto conhecemos pela experiência, quando nós percebemos abstrair as formas
universais, das condições particulares; o que é torná-las inteligíveis em ato. Ora, nenhuma ação convém
a uma coisa, senão por um princípio que lhe seja formalmente inerente, como antes se disse (q. 76, a.
1), ao tratar do intelecto potencial ou possível. Logo, é necessário que a virtude ― princípio de tal ação
― faça parte da alma. E, por isso, Aristóteles comparou o intelecto agente com a luz, que se dissemina
no ar. Ao passo que Platão comparou o intelecto separado, que imprime em as nossas almas, com o sol,
como refere Temístio.
Mas, pelos ensinamentos da nossa fé, o intelecto separado é Deus mesmo, Criador da alma e só em
quem ela acha a sua beatitude, como a seguir se mostrará. Por onde, dele é que a alma humana
participa a luz intelectual, segundo aquilo da Escritura (Sl 4, 7): Gravada está , Senhor, sobre nós a luz do
teu rosto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Essa luz verdadeira ilumina como causa universal, da
qual a alma humana participa uma certa virtude particular, como já se disse.

RESPOSTA À SEGUNDA. ― O Filósofo não refere essas palavras ao intelecto agente, mas ao intelecto
atual. Por isso, antes, do mesmo tinha dito: Pois ele é, quanto ao ato, o mesmo que a ciência da coisa.
Ou, se se quiser entendê-las como referentes ao intelecto agente, significam então que não é por esse
intelecto que ora inteligimos e ora, não; mas pelo intelecto potencial.

RESPOSTA À TERCEIRA. ― Se o intelecto agente se comparasse com o intelecto possível na qualidade de
objeto agente em relação à potência, do mesmo modo que o visível em ato se compara com o que é
visto, resultaria que, instantaneamente, inteligiríamos tudo, por ser o intelecto agente o princípio de
atualização de todo conhecimento. Ora, ele não se comporta como objeto, mas como o atualizador dos
objetos; e, para isso, é necessária, além da presença do intelecto agente, a presença dos fantasmas com
a boa disposição das forças sensitivas e a exercitação em tal obra. Pois, uma coisa inteligida faz com que
outras também o sejam; assim como, pelos termos, se inteligem as proposições e, pelos primeiros
princípios, as conclusões. E, neste ponto, pouco importa que o intelecto agente faça parte da alma ou
seja algo de separado.

RESPOSTA À QUARTA. ― A alma intelectiva é, por certo, atualmente imaterial; mas é potencial em
relação a determinadas espécies das coisas. Porém os fantasmas, inversamente, são semelhanças
atualizadas de certas espécies, mas imateriais em potência. Por onde, nada impede seja uma e mesma a
alma que, como atualmente imaterial, tenha uma virtude, que atualiza as coisas imateriais, abstraindo
das condições da matéria individual, virtude essa chamada intelecto agente; e tenha outra virtude,
chamada intelecto possível, receptiva de tais espécies e potencial em relação às mesmas.

RESPOSTA À QUINTA. ― Sendo a essência da alma, criada pelo intelecto supremo, imaterial, nada
impede que a virtude, participada desse intelecto e pela qual ela abstrai da matéria, proceda da
sobredita essência do mesmo modo que as outras potências suas.

## Art. 5 — Se o intelecto agente é um só para todos.
(II Sent., dist. XVII, q. 2, a. 1; De Spirit. Creat., a. 10; Qu De Anima, a. 5; Compend. Theol., cap. LXXXXVI).
O quinto discute-se assim. ― Parece que o intelecto agente é um só para todos.

1. ― Pois, nada do que é separado do corpo se multiplica com a multiplicação dos corpos. Ora, o
intelecto agente é separado, como já se disse. Logo, não se multiplica nos muitos corpos dos homens,
mas é um só para todos.

2. Demais. ― O intelecto agente gera o universal, que é um para muitos seres. Mas a causa da unidade é
una em máximo grau. Logo, o intelecto agente é um só para todos.

3. Demais. ― Todos os homens convêm nas primeiras concepções do intelecto, pois, assentem nelas
pelo intelecto agente. Logo, todos convêm num só intelecto agente.
Mas, em contrário, o Filósofo diz que o intelecto agente é como a luz. Ora, esta não é a mesma, nos
diversos seres iluminados. Logo, não é o mesmo o intelecto agente, em todos os homens.

SOLUÇÃO. ― A verdade, nesta questão, depende das remissas. Se, pois, o intelecto agente não fizesse
parte da alma, mas fosse uma substância separada, seria um só o intelecto agente de todos os homens;
e assim o entendem os que admitem a unidade desse intelecto. Se, porém, tal intelecto faz parte da
alma, sendo uma virtude dela, necessário é admitirem-se vários intelectos agentes, segundo a
pluralidade das almas, multiplicadas com a multiplicação dos homens, corno já antes se disse (q. 76, a.
2). Pois, diversas substâncias não podem ter a mesma virtude, numericamente única.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O Filósofo prova que o intelecto agente é separado,
porque o possível o é; ora, diz, o agente é mais digno que o paciente. O intelecto possível diz-se
separado por não ser ato de nenhum órgão corpóreo. E é desse mesmo modo que também se chama
separado o intelecto agente, e não corno se fosse uma substância separada.

RESPOSTA À SEGUNDA. ― O intelecto agente causa o universal abstraindo-o da matéria. Mas, por isso,
é necessário, não que seja um só para todos os que têm intelecto, mas que seja um só na sua relação
com todas aquelas coisas das quais abstrai o universal, relativamente às quais o universal é um. E essa é
a função do intelecto agente, enquanto imaterial.

RESPOSTA À TERCEIRA. ― Todos os seres de uma mesma espécie comunicam pela ação conseqüente à
natureza da espécie; e, portanto pela virtude, que é princípio da ação; sem ser necessário que essa
virtude seja, numericamente, a mesma, em todos. Ora, conhecer os primeiros inteligíveis é ação
conseqüente à espécie humana. Por onde, é necessário que todos os homens comuniquem pela virtude
que é princípio dessa ação; e tal é a virtude do intelecto agente. Mas, nem por isso, é necessário que ela
seja a mesma, numericamente, em todos, embora o seja que derive, para todos, de um mesmo
princípio. E, assim, essa comunicação dos homens, pelos primeiros inteligíveis, demonstra a unidade do
intelecto separado, que Platão compara ao sol; não, porém, a do intelecto agente, que Aristóteles
compara à luz.

## Art. 6 — Se a memória está na parte intelectiva da alma.
(Iª IIae q. 67, a. 2; I Sent., dist. III q. 4, a. 1; III, dist. XXVI, q. 1, a. 5 ad. 4; IV, dist. XLIV, q. 3, a. 3qª 2, ad 4;
dist. L, q. 1, a. 2; II Cont. Gent., cap. LXXIV; De Verit., q. 10, a. 2; q. 19, a. 1; Quodl. III, q. 9, a. 1; XII, q. 9,
a. 1; I Cor., cap. XIII, lect. III; De Mem. et Remin., lect. II).
O sexto discute-se assim. ― Parece que a memória não está na parte intelectiva da alma.

1. ― Pois, Agostinho diz que à parte superior da alma pertencem aquelas coisas que não
são comuns aos homens e aos animais. Ora, a memória é comum a uns e a outros, pois, o mesmo autor
diz, que os animais podem sentir, pelos sentidos do corpo, as coisas corpóreas, e mandá-las à memória.
Logo, a memória não pertence à parte intelectiva da alma.

2. Demais. ― A memória guarda as coisas pretéritas. Mas pretérito se refere a um tempo determinado.
Logo, a memória é cognoscitiva das causas, num determinado tempo, o que é conhecê-las local e
atualmente. Ora, isto não é próprio do intelecto, mas do sentido. Logo, a memória não está na parte
intelectiva, mas só na sensitiva.

3. Demais. ― Na memória se conservam as espécies das coisas que não são pensadas atualmente. Ora,
isso não se pode dar com o intelecto, pois este se atualiza informado pela espécie inteligível; ora, como
o intelecto em ato é o inteligir mesmo, em ato, resulta que o intelecto intelige atualmente. todas as
coisas cujas espécies traz em si. Logo, a memória não está na parte intelectiva.
Mas, em contrário, Agostinho diz que a memória, a inteligência e a vontade são uma somente.

SOLUÇÃO. ― Sendo da natureza da memória conservar as espécies das coisas não atualmente
apreendidas, é preciso, antes de tudo, examinar se as espécies inteligíveis podem se conservar desse
modo, no intelecto. Ora, Avicena ensinava que isso é impossível, dizendo que tal se dá com certas
potências, atos de órgãos corpóreos, nas quais podem conservar-se algumas espécies sem a apreensão
atual. Porém no intelecto, que não tem órgão corpóreo, nada existe senão inteligivelmente. Por onde é
necessário ser inteligido em ato aquilo cuja semelhança existe no intelecto. Assim, pois, na opinião dele,
logo que alguém acaba de inteligir alguma coisa em ato, acaba de existir a espécie dessa coisa no
intelecto; sendo necessário, se quiser de novo inteligir tal coisa, converter-se ao intelecto agente, que
Avicena admite como substância separada, para que dele efluam as espécies inteligíveis para o intelecto
possível. E desse exercício e uso de se converter ao intelecto agente, resulta, segundo o mesmo filósofo,
uma certa habilidade, para o intelecto possível, de se converter ao intelecto agente, e dizia ser o hábito
da ciência. Segundo, pois, tal opinião, nada se conserva, na parte intelectiva, que não seja inteligido em
ato. Por isso, não se pode admitir, desse modo, a memória na parte intelectiva.
Essa opinião, porém, manifestamente repugna as palavras de Aristóteles, dizendo que o intelecto
possível,quando considerado em ato, torna-se, como ciente, nas coisas singulares; o que, porém,
acontece, quando ele pode operar por si mesmo. Está, pois, então, em potência, de certo modo; não,
porém, absolutamente, como antes de aprender ou descobrir. Ora diz-se que o intelecto possível se
torna nas coisas singulares, recebendo as espécies delas. Por onde, recebendo as espécies dos
inteligíveis, pode operar quando quiser, mas não operar sempre; porque então está, de certo modo, em
potência, embora de maneira diferente da de antes de inteligir, a saber, do modo pelo qual o ciente
habitual está em potência para considerar em ato. ― Demais, tal opinião também repugna à razão. Pois,
o que é recebido em algum ser o é ao modo do ser recipiente. Ora, o intelecto é de natureza mais
estável e imóvel do que a matéria corpórea. Se, portanto, esta conserva as formas que recebe, não só
enquanto, por elas, age atualmente, mais ainda depois que cessou de agir pelas mesmas; com muito
maior razão, o intelecto, imóvel e inamissívelmente, recebe as espécies inteligíveis, tanto as recebidas
dos sentidos, como as dimanadas de algum intelecto superior.
Se, portanto, se entende a memória somente como a virtude conservativa das espécies, é necessário
admiti-la como existente na parte intelectiva. Se, porém, da natureza dela é ter como objeto o pretérito
como tal, então não existe na parte intelectiva, senão só na sensitiva, apreensora dos particulares. Pois,
o pretérito, como tal, exprimindo o ser, num determinado tempo, tem a condição do particular.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A memória, como conservativa das espécies, não nos é
comum com os animais; pois, aquelas se conservam, não somente na parte sensitiva da alma, mas
sobretudo no conjunto, porque a virtude memorativa é o ato de um órgão. Porém o intelecto, em si, é
conservativo das espécies, mesmo sem a cooperação do órgão corpóreo. E, por isso, o Filósofo diz que a
alma é o lugar das espécies, não toda ela, mas só o intelecto.

RESPOSTA À SEGUNDA. ― A preterição tem duplo ponto de referência: o objeto conhecido e o ato do
conhecimento; ambos simultaneamente se unem na parte sensitiva, apreensiva das coisas, quando
sofre mutação proveniente do sensível presente. Por onde, é simultaneamente que o animal se lembra
de que, primeiro, sentiu no passado, e depois, de que sentiu um certo pretérito sensível. Mas, no
atinente à parte intelectiva, a preterição é acidental e não conveniente por si mesma, quanto ao objeto
do intelecto. Pois, o intelecto intelige o homem como tal. Ora, a este, como tal, é-lhe acidental estar no
presente, no pretérito ou no futuro. Quanto ao ato, porém, a preterição pode ser admitida, em si, tanto
no intelecto como no sentido; porque o inteligir da nossa alma é um ato particular existente num
determinado tempo, segundo o qual é considerado inteligir agora, ontem ou amanhã. O que não
repugna à intelectualidade; porque tal inteligir, embora seja um particular é, contudo, um ato imaterial,
como antes já se disse (q. 76, a. 1), tratando-se do intelecto. E, portanto, assim como o intelecto se
intelige a si mesmo, embora seja um intelecto singular; assim também intelige o seu inteligir, que é um
ato singular, existindo no pretérito, no presente ou no futuro. Assim, pois, fica salva a natureza da
memória, quanto a referir-se às coisas passadas, no intelecto, e segundo os quais ela se intelige como
tendo inteligido anteriormente; não porém enquanto intelige o pretérito, local e atualmente
determinado.

RESPOSTA À TERCEIRA. ― As espécies inteligíveis ora estão no intelecto só potencialmente, e então o
intelecto é chamado potencial; ora estão segundo o acabamento último do ato e, então, o intelecto
intelige em ato; ora, estão de um modo intermédio entre a potência e o ato,e então o intelecto se
chama habitual; e, deste último modo, o intelecto conserva as espécies, mesmo quando não as intelige
em ato.

## Art. 7 — Se a memória intelectiva é potência diferente do intelecto.
(Infra, q. 23, a. 7, ad 3; I Send., dist. III, q. 4, a. 1; II Cont. Gent., cap. LXXIV; De Verit., q. 10, a. 3).
O sétimo discute-se assim. ― Parece que uma potência é a memória intelectiva e outra, o intelecto.

1. ― Pois, Agostinho compreende na mente a memória, a inteligência e a vontade. Ora, é manifesto que
a memória é uma potência diferente da vontade. Logo, semelhantemente, também do intelecto.

2. Demais. ― O fundamento da distinção das potências da parte sensitiva é idêntico ao da distinção das
potências da parte intelectiva. Ora, a memória, na parte sensitiva, é potência diferente do sentido,
como antes já se disse (q. 78, a. 4). Logo, a memória da parte intelectiva é uma potência diferente do
intelecto.

3. Demais. ― Segundo Agostinho, a memória, a inteligência e a vontade são iguais entre si, nascendo
uma, da outra. Ora, isso não poderia ser, se a memória fosse a mesma potência que o intelecto. Logo,
não é a mesma potência.
Mas, em contrário. ― A memória é, por natureza, o tesouro ou o lugar conservativo das espécies. Ora,
essa função o Filósofo atribui ao intelecto, como já se disse (a. 6). Logo, na parte intelectiva, a memória
não é potência diferente do intelecto.

SOLUÇÃO. ― Como já ficou dito antes (q. 77, a. 3), as potências da alma se distinguem pelos, aspectos
diversos dos objetos, porque o de cada potência consiste em ser ordenada para seu objeto próprio. Ora,
como também já se disse antes (Ibid., ad 4), desde que se ordene por essência a algum objeto, conforme
o aspecto comum deste, nenhuma potência poderá ser diversificada pelas variadas diferenças
particulares. Assim, a potência visiva, que diz respeito ao seu objeto, conforme a noção de colorido, não
se diversifica pelas noções de branco e preto. Ora, o, objeto do intelecto cai sob o aspecto comum de
ente; pois, o intelecto possível é o princípio pelo qual a alma se torna em todas as causas. Por onde, a
diferença do intelecto possível não se diversifica por nenhuma diferença entitativa.
Porém, diversifica-se a potência do intelecto agente da do intelecto possível. Porque em relação ao
mesmo objeto, é necessário que um princípio seja potência ativa, que atualiza o objeto, e outro,
potência passiva, que é movido pelo objeto atualizado. E, assim, a potência ativa está para o seu objeto
como o ser em ato para o ser em potência; porém, a potência passiva está para o seu objeto,
inversamente, como ser em potência para o ser em ato. E portanto, não pode haver no intelecto
nenhuma outra diferença de potências, a não ser a de intelecto possível e intelecto agente. Por onde é
claro, que a memória não é potência diferente do intelecto. Porém, é da essência da potência passiva
conservar, bem como receber.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Embora se diga que a memória, a inteligência e a
vontade são três potências, contudo, não é conforme a intenção de Agostinho, que diz
expressamente: se tomamos a memória, a inteligência e a vontade, como sempre presentes à alma, que
sejam objetos de cogitação, quer não, então se incluem na memória. Porém, agora me refiro à
inteligência pela qual inteligimos, cogitando; e vontade, amor ou dileção, a que une a sobredita prole e
parentela. Por onde se vê que Agostinho não toma essas três atividades como potências; mas entende
por memória a retenção habitual à alma; por inteligência, o ato do intelecto; por vontade, o ato da
vontade.

RESPOSTA À SEGUNDA. ― O pretérito e o presente podem ser as diferenças próprias diversificativas
das potências sensitivas; não, porém, das potências intelectivas, pela razão sobredita (a. 6, ad 2).

RESPOSTA À TERCEIRA. ― A inteligência nasce da memória, como o ato, do hábito e, deste modo,
também se iguala com ela; não se iguala, porém, como uma potência com outra.

## Art. 8 — Se a razão é potência diferente do intelecto.
(III Sent., dist. XXXV, q. 2, a. 2, qª 1; De Verit., q. 15, a. 1).
O oitavo discute-se assim. ― Parece que a razão é potência diferente do intelecto.

1. ― Pois, foi dito: Quando queremos subir do que é inferior para o que é superior, primeiro nos ajuda o
sentido, depois a imaginação, em seguida a razão e, por fim, o intelecto. Portanto, a razão é uma
potência diferente do intelecto, como a imaginação da razão.

2. Demais. ― Boécio diz, que o intelecto está para a razão como a eternidade para o tempo. Mas, não é
próprio de uma mesma virtude estar na eternidade e no tempo. Logo, a razão e o intelecto não são
potências idênticas.

3. Demais. ― O homem tem de comum com os anjos o intelecto; com os brutos, porém, o sentido. Ora,
a razão, própria do homem e que o torna animal racional, é potência diferente do sentido. Logo,
igualmente, também difere do intelecto, que, convindo, propriamente, aos anjos, faz com que sejam
chamados intelectuais.
Mas, em contrário, diz Agostinho: o que torna o homem mais excelente que os animais irracionais, é a
razão, ou mente, ou inteligência, ou qualquer outro vocábulo mais cômodo que se use. Logo a razão, o
intelecto e a mente são uma só potência.

SOLUÇÃO. ― A razão e o intelecto, no homem, não podem ser potências diversas; o que
manifestamente se compreenderá se se considerar no ato deles. Pois, inteligir é apreender, pura e
simplesmente, a verdade inteligível; ao passo que raciocinar é proceder de uma para outra intelecção,
para conhecer a verdade inteligível. Por onde, os anjos que possuem perfeitamente, ao modo da sua
natureza, o conhecimento da verdade inteligível, não têm necessidade de proceder de uma para a
outra; mas, simplesmente e sem discurso, apreendem a verdade das coisas, como diz Dionísio. Porém,
os homens, chegam a conhecer a verdade inteligível, procedendo de uma para outra, como diz o mesmo
autor, no mesmo passo; e, por isso, se chamam racionais. Ora, é patente que o raciocinar está para o
inteligir, como o ser movido para o repousar, ou o adquirir para o possuir; dos quais termos um
pertence ao perfeito, o outro, porém, ao imperfeito. E como o movimento sempre procede do imóvel e
termina no repouso, daí vem que o raciocínio humano, por via de inquisição ou de invenção, procede de
certos princípios absolutamente inteligidos, que são os primeiros princípios; e, de novo, por via do juízo,
volta, decompondo, aos primeiros princípios, à luz dos quais examina o que descobriu. Ora, é manifesto,
que o ser movido e o repousar, mesmo nas coisas naturais, não se reduzem a potências diversas, mas a
uma só e mesma; pois, é pela mesma natureza que uma coisa se move e repousa localmente. Logo, com
muito maior razão, pela mesma potência inteligimos e raciocinamos. E assim, é claro que, no homem, a
razão e o intelecto constituem a mesma potência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Essa enumeração se faz segundo a ordem dos atos e não
segundo a distinção de potência; embora o livro citado não tenha grande autoridade, como já se disse
(q. 77, a. 8 ad 1).

RESPOSTA À SEGUNDA. ― Resulta clara a resposta do que acaba de ser dito. Pois, a eternidade está
para o tempo como o imóvel para o móvel. E, por isso, se Boécio compara o intelecto com a eternidade,
comparou a razão com o tempo.

RESPOSTA À TERCEIRA. ― Os outros animais são de tal modo inferiores ao homem, que não podem
atingir o conhecimento da verdade, que a razão indaga. Ao passo que o homem atinge, mas
imperfeitamente, ao conhecimento da verdade inteligível, que os anjos conhecem. Por onde, a virtude
cognoscitiva dos anjos não é de gênero diferente da virtude cognoscitiva da razão; mas está para esta
como o perfeito para o imperfeito.

## Art. 9 — Se a razão superior e a inferior são potências diversas.
(II Sent., dist. XXIV, q. 2, a. 2; De Verit q. 15, a 2).
O nono discute-se assim. ― Parece que a razão superior e a inferior são potências diversas.

1. ― Pois, Agostinho diz, que a imagem da Trindade está na parte superior da razão, não porém na
inferior. Ora, as partes da alma são as potências mesmas dela. Logo, duas potências são a razão superior
e a inferior.

2. Demais. ― Nada nasce de si mesmo. Ora, a razão inferior nasce da superior e por esta é regulada e
dirigida. Logo, a razão superior é potência diferente da inferior.

3. Demais. ― O Filósofo diz que o princípio intelectivo da alma, pelo qual ela conhece o necessário, é
princípio diferente e parte diversa do princípio opinativo e do raciocinativo, pelos quais conhece os
contingentes. E isto o prova dizendo, que a causas genericamente diferentes ordenam-se partes da alma
genericamente diferentes. Ora, o contingente e o necessário, assim como o corruptível e o incorruptível,
são genericamente diferentes. Sendo, pois, o necessário idêntico ao eterno e o temporal, ao
contingente, resulta que o princípio intelectivo, do Filósofo, é idêntico à parte superior da razão, que,
segundo Agostinho, considera e delibera sobre as coisas eternas; e o raciocinativo ou opinativo do
Filósofo, é idêntico à razão inferior, que, segundo Agostinho, busca a disposição das coisas temporais.
Logo, são potências diferentes da alma a razão superior e a inferior.

4. Demais. ― Damasceno diz: pela imaginação se faz a opinião; em seguida a mente, separando a
opinião verdadeira da falsa julga de verdade e, por isso, mente provém de medir. E, por fim, o intelecto
é relativo ao que já foi julgado e determinado verdadeiramente. Assim, pois, o opinativo ou razão
inferior difere da mente e do intelecto, que se pode compreender como a razão superior.
Mas, em contrário, Agostinho diz, que a razão superior só se distingue da inferior pela sua função. Logo,
não são duas potências.

SOLUÇÃO. ― A razão superior e a inferior, como Agostinho as entende, de nenhum modo podem ser
duas potências da alma. Pois, diz que a razão superior é a que considera ou delibera nas coisas eternas;
considera, examinando-as em si mesma; delibera, tirando delas as regras das ações. Porém, denomina
razão inferior a que se ocupa com as coisas temporais. Ora, as coisas temporais e as eternas se
comparam com o nosso conhecimento, como sendo umas o meio de se conhecerem as outras. Pois, por
via da invenção, chegamos ao conhecimento das coisas eternas, pelas temporais, conforme àquilo da
Escritura (Rm 1, 20): Porque as coisas invisíveis de Deus, compreendendo-se pelas coisas feitas,
tornaram-se visíveis. Ao passo que, por via do juízo, julgamos das coisas temporais pelas eternas, já
conhecidas, e dispomos as temporais pelas noções das eternas. Mas pode suceder que o meio e aquilo a
que, pelo meio, chegamos, pertençam a hábitos diversos. Assim, os primeiros princípios
indemonstráveis pertencem ao hábito do intelecto; porém, as conclusões desses deduzidas, ao hábito
da ciência. E, por isso, dos princípios da geometria é que se devem tirar as conclusões, noutra ciência, p.
ex., na perspectiva. Mas a potência da razão, que atinge o termo médio e o último, é a mesma. Pois, o
ato da razão é um como movimento, que passa daquele para este; e também é o móvel que, passando
pelo meio, chega ao fim. Por onde, a razão superior e a inferior são uma só e mesma potência;
distinguindo-se, porém, pela função dos atos e pelos diversos hábitos; assim, à razão superior se atribui
a sapiência e, à inferior, a ciência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Pode-se chamar parte ao que resulta de uma partição,
de qualquer espécie que esta seja. Assim, a razão superior e a inferior chamam-se partes, não por serem
potências diversas, mas como provenientes da divisão da razão pelas suas diversas funções.

RESPOSTA À SEGUNDA. ― A razão inferior é considerada como deduzida da superior e como por esta
regulada, enquanto os princípios, de que usa aquela, são deduzidos dos princípios desta e por eles
regulados.

RESPOSTA À TERCEIRA. ― O princípio do conhecimento intelectivo, de que o Filósofo fala, não se
identifica com a razão superior. Pois, verdades conhecidas como necessárias também se encontram na
ordem temporal, na qual se funda a ciência natural e a matemática. Porém, o opinativo e
o raciocinativo têm objeto ainda menor que o da razão inferior, pois só se referem aos contingentes.
Mas isso não quer dizer que seja absolutamente, uma a potência pela qual o intelecto conhece o
necessário e, outra, pela qual conhece o contingente; porque conhece um e outro pela mesma noção do
objeto, a saber, a noção de ente e de verdade. Por onde, os necessários, que têm o ser perfeito na
verdade, conhece-os perfeitamente, atingindo-lhes a qüididade, pela qual demonstra os acidentes
próprios dos mesmos. Porém, conhece os contingentes imperfeitamente, por terem o ser imperfeito,
bem como a verdade. Ora, o perfeito e o imperfeito em ato não diversificam a potência; mas
diversificam os atos, quanto ao modo de agir e, por conseqüência, os princípios dos atos e os hábitos. E,
por isso, o Filósofo introduziu duas sub-partes da alma, a capaz do conhecimento científico e a
raciocinativa, não por serem duas potências, mas por se distinguirem pela aptidão diversa a receberem
os diversos hábitos cuja diversidade é o que ele quer indagar no passo citado. Pois, os contingentes e os
necessários, embora diferentes pelos gêneros próprios, convêm todavia, pela noção comum de ente,
visada pelo intelecto, e em relação à qual eles se comportam diferentemente, como o perfeito e o
imperfeito.

RESPOSTA À QUARTA. ― Essa distinção de Damasceno é segundo a diversidade dos atos e não a das
potências. Assim, opinião significa o ato do intelecto que abraça uma parte da contradição com temor
da outra. Ao passo que julgar ou medir ― donde provém o vocábulo mente ― é o ato do intelecto pelo
qual ele aplica princípios certos ao exame do que lhe é proposto. Enfim, inteligir é aderir,
aprovativamente, ao que foi julgado.

## Art. 10 — Se a inteligência é potência diferente do intelecto.
O décimo discute-se assim. ― Parece que a inteligência é potência diferente do intelecto.

1. ― Pois, como disse alguém, quando queremos subir do inferior para o superior, primeiro nos
socorremos do sentido, depois da imaginação, em seguida, da razão depois, do intelecto e, por último,
da inteligência. Ora, a imaginação e o sentido são potências diversas. Logo, também o intelecto e a
inteligência.

2. Demais. ― Boécio diz, que o homem é considerado diferentemente pelo sentido, pela imaginação,
pela razão e pela inteligência. Ora, o intelecto é a mesma potência que a razão. Logo, conclui-se que a
inteligência é potência diferente do intelecto, como a razão o é da imaginação e do sentido.

3. Demais. ― Os atos são anteriores às potências, como diz Aristóteles. Ora, a inteligência é um ato
separado dos outros, que são atribuídos ao intelecto. Pois, como diz Damasceno o primeiro
movimento (no conhecimento) se chama intelecção; a intelecção aplicada a um objeto se chama
intenção; a permanente e configurativa da alma conforme ao objeto conhecido se chama cogitação; a
cogitação que permanece no mesmo sujeito, que a si mesmo se examina e julga, chama-se frónesis, i. e.,
sapiência; a frónesis desenvolvida constitui o raciocínio, i. é., a palavra interiormente ordenada; donde
procede a palavra articulada pela língua. Logo resulta que a inteligência é uma potência especial.
Mas, em contrário, diz o Filósofo, a inteligência se refere aos indivisíveis, nos quais não há falsidade.
Ora, tal modo de conhecer pertence ao intelecto. Logo, a inteligência não é potência diferente do
intelecto.

SOLUÇÃO. ― O vocábulo inteligência significa, propriamente, o ato mesmo do intelecto, que é inteligir.
Porém, em certos livros traduzidos do árabe, as substâncias separadas, a que nós chamamos anjos,
denominam-se Inteligências, talvez porque tais substâncias sempre inteligem em ato. Ao passo que, nos
livros traduzidos do grego, chamam-se Intelectos ou Mentes. Assim, pois, a inteligência não se distingue
do intelecto como uma potência, de outra, mas como o ato, da potência. E tal divisão é aceita, também
pelos filósofos. Assim, ora admitem quatro intelectos: o agente, o possível, o habitual e o atual. Dos
quais, o agente e o possível são potências diferentes; pois, como em todos os seres, há uma potência
ativa e outra, passiva. Porém, os outros três se distinguem pelos três estados do intelecto possível, que,
ora sendo somente potencial chama-se possível: ora, estando em ato primeiro, que é a ciência, chama-
se habitual; ora, em ato segundo, que é a reflexão, chama-se intelecto em ato atual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Se tal autoridade deve ser aceita, por inteligência aí se
entende o ato do intelecto; e, então, ela se divide por oposição com o intelecto, como o ato por
oposição com a potência.

RESPOSTA À SEGUNDA. ― Boécio entende por inteligência o ato do intelecto, que transcede o ato da
razão. Por onde, no mesmo passo, diz que a razão tanto é própria ao gênero humano, como a
inteligência só, ao divino; pois, é próprio de Deus inteligir todas as coisas, sem nenhuma investigação.

RESPOSTA À TERCEIRA. ― todos esses atos, que Damasceno enumera, pertencem à mesma potência, a
saber, à intelectiva. Esta, primeiro, apreende, absolutamente, uma coisa, e tal ato se chama intelecção;
segundo, ordena o que apreende a conhecer ou operar outra coisa, e a isso se chama intenção; o
persistir na indagação do que intenciona chama-se cogitação; o exame do que foi cogitado, à luz de
princípios certos, chama-se saber ou ter sabedoria, nisso consistindo a prudência ou sapiência, pois,
pertence as sapiência julgar, como diz Aristóteles. Depois de estar certa de algo, por ter sido como
examinado, cogita como possa manifestá-lo aos outros, e tal é à disposição da elocução interior; da qual
procede a elocução exterior. Não é, pois, toda diferença dos atos que diversifica as potências; mas só a
que se não pode reduzir ao mesmo princípio, como já se disse antes (q. 78, a. 4).

## Art. 11 — Se o intelecto especulativo e o prático são potências diversas.
(III Sent., dist. XXIII, q.2, a. 3, qª 2; De Verit., q. 3, a. 3; VI Ethic., lect. II; III De Anima, lect. XV).
O undécimo discute-se assim. ― Parece que o intelecto especulativo e o prático são potências
diversas.

1. ― Pois, o apreensivo e o motivo são gêneros diversos de potências, como se vê em Aristóteles. Ora, o
intelecto especulativo é somente apreensivo, ao passo que o prático é motivo. Logo, são potências
diversas.

2. Demais. ― Os aspectos diversos do objeto diversificam as potências. Ora, ao passo que o objeto do
intelecto especulativo é a verdade, o do prático, é o bem; e ambos esses objetos diferem
essencialmente. Logo, o intelecto especulativo e o prático são potências diversas.

3. Demais. ― Na parte intelectiva, o intelecto prático está para o especulativo, como a estimativa para a
imaginativa, na parte sensitiva. Ora, a estimativa difere da imaginativa como uma potência, de outra,
como se disse antes (q. 78, a. 4). Logo, também o intelecto prático, do especulativo.
Mas, em contrário, como diz Aristóteles, o intelecto especulativo, por extensão, torna-se prático. Ora,
uma potência não se muda em outra. Logo, o intelecto especulativo e o prático não são potências
diversas.

SOLUÇÃO. ― O intelecto prático e o especulativo não são potências diversas. E a razão é que, como já
se disse antes (q. 77, a. 3), o acidental, em relação ao aspecto do objeto a que se refere uma potência,
não diversifica a esta. Assim, é acidental ao colorido ser homem, grande ou pequeno; por isso, tais
acidentes são apreendidos pela mesma potência visíva. Ora, é acidental ao que é apreendido pelo
intelecto ser ou não ordenado à operação. E nisto está a diferença entre o intelecto especulativo e o
prático; o que aquele apreende não se ordena à operação, mas só à consideração da verdade; ao passo
que, o apreendido, por este se ordena à operação. E, por isso, o Filósofo diz que o fim especulativo
difere do prático; por onde, denominados pelos seus fins, um se chama intelecto especulativo; o outro,
prático, i. é., operativo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O intelecto prático é motivo, não por executar o
movimento, mas porque dirige para o movimento. O que lhe convém, segundo o modo da sua
apreensão.

RESPOSTA À SEGUNDA. ― A verdade e o bem incluem-se um no outro. Pois, a verdade é um certo bem,
do contrário não seria desejável; e o bem é uma certa verdade, do contrário não seria inteligível.
Portanto, assim como objeto do apetite pode ser o verdadeiro, sob o aspecto de bom, como p. ex.,
quando alguém deseja conhecer a verdade; assim também o objeto do intelecto prático é o bem que se
ordena à operação, sob o aspecto de verdadeiro. Pois, o intelecto prático, como o especulativo, conhece
a verdade, mas ordenando a verdade conhecida para a operação.

RESPOSTA À TERCEIRA. ― Há muitas diferenças que diversificam as potências sensitivas, e que não
diversificam as intelectivas, como já se disse antes (a. 7, ad 2; q. 77, a. 3 ad 4).

## Art. 12 — Se a sindérese é uma potência especial distinta das outras.
(II Sent., dist. XXIV, q. 2, a. 3; De Verit., q. 16, a. 1).
O duodécimo discute-se assim. ― Parece que a sindérese é uma potência especial, distinta das outras.

1. ― Pois, as coisas que caem sob uma divisão pertencem ao mesmo gênero. Mas, na Glosa de
Jerônimo, a sindérese é dividida por oposição ao irascível, ao concupiscível e ao racional, que são
potências. Logo, a sindérese é uma potência.

2. Demais. ― Os opostos são do mesmo gênero. Ora, a sindérese e a sensualidade se opõem, porque
aquela sempre inclina para o bem e esta, sempre para o mal, sendo, por isso, representada pela
serpente, como se vê em Agostinho. Logo, conclui-se que a sindérese é uma potência, como a
sensualidade.

3. Demais. ― Agostinho diz, que para o judicatório natural há certas regras, e sementes das virtudes,
verdadeiras e incomutáveis. E a essas chamamos sindérese. Logo, pertencendo às regras incomutáveis,
pelas quais julgamos, à razão, na sua parte superior, como diz Agostinho, conclui-se que a sindérese é
idêntica à razão. E, assim, é uma potência.
Mas, em contrário. ― As potências racionais se referem a termos opostos, segundo o Filósofo. Ora, a
sindérese não se refere a tais termos mas inclina somente para o bem. Logo, não é potência; porque se
o fosse, tinha que ser potência racional, pois, não se encontra nos brutos.

SOLUÇÃO. ― A sindérese não é potência, mas hábito; embora certos tenham dito que é uma potência
mais alta que a razão; e outros, que é a razão mesma, não enquanto razão, mas enquanto natureza.
E, para a evidência disto, deve-se considerar que, como já se disse antes (a. 8), o raciocínio do homem,
sendo movimento, parte, como de um princípio imóvel da inteligência, de certas noções, naturalmente
conhecidas, sem a investigação da razão; e termina também pelo intelecto, enquanto julgamos, pelos
princípios naturalmente conhecidos por si mesmos, daquilo que descobrimos raciocinando. Ora, dá-se
que, assim como a razão especulativa raciocina sobre as coisas especulativas, assim a razão prática,
sobre as operáveis. Logo, é necessário que, não só os princípios das coisas especulativas, mas também o
das operáveis, nos sejam naturalmente ínsitos.
Ora, os primeiros princípios das coisas especulativas, naturalmente ínsitos, em nós não pertencem a
nenhuma potência especial, mas a um hábito especial, chamado intelecto dos princípios, como se vê em
Aristóteles. Por onde, também os princípios das coisas operáveis, naturalmente ínsitos em nós, não
pertencem a uma potência especial, mas a um hábito natural especial, a que chamamos sindérese. E,
por isso, se diz que a sindérese instiga ao bem e murmura contra o mal, enquanto, pelos primeiros
princípios, procedemos a descobrir e julgamos do descoberto. Logo, é claro, a sindérese não é uma
potência, mas um hábito natural.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Essa divisão de Jerônimo se funda na diversidade dos
atos e não na das potências. Pois, atos diversos podem pertencer à mesma potência.

RESPOSTA À SEGUNDA. ― A oposição entre a sensualidade e a sindérese se funda na oposição dos atos;
e não que pertençam elas a diversas espécies do mesmo gênero.

RESPOSTA À TERCEIRA. ― Essas regras incomutáveis são os primeiros princípios das coisas operáveis,
em relação às quais não é possível errar; e se atribuem à razão como à potência, e a sindérese como ao
hábito. Por onde, por uma e outra, a saber, pela razão e pela sindérese, julgamos naturalmente.

## Art. 13 — Se a consciência é uma potência.
(II Sent., dist. XXIV, q. 2, a. 4; De Verit., q. 17, a. 1).
O décimo terceiro discute-se assim. ― Parece que a consciência é uma potência.

1. ― Pois, diz Origines, a consciência é o espírito corretor e o pedagogo associado à alma, pelo qual ela
foge das coisas más e adere às boas. Mas o espírito, na alma, denomina uma potência: quer a mente
mesma, segundo aquilo da Escritura (Ef 4, 23) ― Renovai-vos pois no espírito do vosso entendimento;
quer a imaginação, chamando-se, por isso, imaginária a visão espiritual, com se vê Agostinho. Logo, a
consciência é uma potência.

2. Demais. ― Só uma potência da alma pode ser sujeito do pecado. Ora, a consciência é sujeito do
pecado; pois, a Escritura diz, de certos (Tt 1, 15): acham-se contaminadas tanto a sua mente como a sua
consciência. Logo, a consciência é uma potência.

3. Demais. ― A consciência é, necessariamente, ato, hábito ou potência. Ora, não é ato, porque, então,
não permaneceria sempre no homem. Nem hábito, porque, então, não seria uma só a consciência, mas
muitas; pois somos dirigidos, nas ações, por muitos hábitos cognoscitivos. Logo, a consciência é uma
potência.
Mas, em contrário. ― A consciência pode se perder; não, porém, a potência. Logo, não é potência.

SOLUÇÃO. ― A consciência, propriamente falando, não é potência, mas ato. O que se evidencia quer em
razão do nome, quer pelo que, conforme o uso comum de falar, se atribui à consciência.
Segundo, pois, a propriedade do vocábulo, a consciência importa a ordenação da ciência para alguma
coisa, porquanto, consciência significa ciência com outra coisa. Ora, a aplicação da ciência a alguma
coisa se faz por um ato. Por onde, em virtude dessa noção do nome, é claro que a consciência é um ato.
E o mesmo resulta daquilo que se atribui à consciência. Assim, diz-se que ela testifica, liga, instiga e,
mesmo, acusa ou remorde ou repreende. E tudo isso resulta da aplicação de algum conhecimento nosso
ou ciência nossa aquilo que praticamos. E essa aplicação se faz de três modos. ― Primeiro, quando
reconhecemos ter ou não feito alguma coisa, segundo a Escritura (Ecle 7, 23): Porque sabes na tua
consciência que também tu muitas vezes tens dito mal de outros. E, neste caso, diz-se que a
consciência testifica. ― Segundo, quando pela nossa consciência julgamos dever fazer alguma coisa, ou
não. E então, diz-se que a consciência instiga ou liga. ― Terceiro, quando, pela consciência, julgamos
que alguma coisa foi bem ou mal feita. E então, diz-se que a consciência excusa, ou acusa ou remorde.
Ora, é, claro que tudo isso resulta da aplicação atual da ciência àquilo que praticamos. Por onde,
propriamente falando, a consciência denomina o ato.
Porém, como o hábito é o princípio do ato, às vezes se atribui o nome de consciência ao hábito primeiro
natural, a saber, a sindérese; e é assim que Jerônimo denomina a consciência sindérese;
Basílio, judicatório natural; e Damasceno, lei do nosso intelecto. Pois é costume nomear as causas pelos
efeitos e vice-versa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Chama-se espírito à consciência, entendendo aquele
pela mente, pois é um ditame desta.

RESPOSTA À SEGUNDA. ― Diz-se que há inquinação na consciência, não como num sujeito, mas do
modo por que o conhecido está no conhecimento, a saber, enquanto alguém se conhece como
inquinado.

RESPOSTA À TERCEIRA. ― O ato, embora em si não permaneça sempre, permanece, contudo, na sua
causa, que é a potência e o hábito. Ora, os hábitos pelos quais a consciência é informada, embora sejam
muitos, recebem todos, porém, a eficácia de um hábito primeiro, a saber, o hábito dos primeiros
princípios, chamado sindérese. Por onde, tal hábito se chama, por vezes, especialmente, consciência,
como se disse acima.