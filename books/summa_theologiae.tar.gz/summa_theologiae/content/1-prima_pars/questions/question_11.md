# Questão 11: Da unidade divina.
Após o que precede, devemos tratar da unidade divina. E sobre esta questão discutem-se quatro
artigos:

## Art. 1 — Se a unidade acrescenta alguma coisa ao ser.
(Infra, q. 30, a. 3; I Sent., dist. XIX, q. 4, a. 1, ad 2; dist. XXIV, a. 3; De Pot., q. 9, a. 7; Quodl., X, q. 1, a. 1;

IV, Metaphys., lect. II; X, lect. III).
O primeiro discute-se assim. — Parece que a unidade acrescenta alguma coisa ao ser.

1. — Pois, tudo o que pertence a um gênero determinado acrescenta algo ao ser. Ora, a unidade, sendo
o princípio do número, espécie de quantidade, pertence a um gênero determinado. Logo, acrescenta
alguma coisa ao ser.

2. Demais. — O que divide uma noção comum adiciona-lhe alguma realidade. Ora, o ser é dividido pela
unidade e pela multiplicidade. Logo, a unidade acrescenta algo de real ao ser.

3. Demais. — Se a unidade não acrescenta nada ao ser, este identifica-se com ela. Ora, é tautologia dizer
que um ente é ente. Logo, também o é dizer que o ser é um — o que é falso. Portanto, a unidade
acrescenta alguma coisa ao ser.
Mas, em contrário, diz Dionísio: Nada existe que não participe da unidade; o que não se daria se esta
acrescentasse ao ser alguma coisa. Logo, não acrescenta.

SOLUÇÃO. — A unidade não acrescenta nada ao ser, mas, só a negação da divisão; pois, ser uno não é
senão ser indiviso; e daqui resulta claramente, que a unidade é conversível no ser. Pois, todo o ser ou é
simples ou composto. Aquele é indiviso, atual e potencialmente. Este não recebe o ser enquanto as suas
partes estiverem divididas. Mas, só depois que elas o constituem e compõem. Por onde, é manifesto
que o ser de qualquer coisa consiste na sua indivisão; e daí vem que todo ente conserva o seu ser na
medida em que conserva a unidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Certos, pensando que a unidade convertível no ser se
identifica com a que é princípio do número, professaram opiniões diversas. Assim, Pitágoras e Platão,
vendo que a unidade convertível no ser não acrescenta a este nenhuma realidade, mas lhe significa a
substância indivisa, pensaram que o mesmo se dá com a unidade, princípio do número. E como este se
compõe de unidades, pensaram que os números são as substâncias de todas as coisas. Avicena, ao
contrário, considerando que a unidade, princípio do número, acrescenta alguma realidade à substância,
aliás, o número, composto de unidade não seria uma espécie de quantidade, acreditou que a unidade
convertível no ser adiciona-lhe à substância alguma realidade, como branco, ao homem. Mas, isto é
manifestamente falso. Pois, um ser é uno pela sua substância; porque, se o fosse em virtude de outra
causa, como esta, de novo, seria una, havia de sê-lo, por sua vez, em virtude de uma terceira e, assim
iríamos ao infinito. Por isso, devemos parar no primeiro termo e, portanto, dizer que a unidade
convertível no ser nenhuma realidade lhe acrescenta; mas a unidade, princípio do número, acrescenta-
lhe um atributo que pertence ao gênero da quantidade.

RESPOSTA À SEGUNDA. — Nada impede que uma realidade dividida, de um certo modo, seja indivisa,
de outro; assim, o que é numericamente dividido é indiviso especificamente. De modo que um ente uno
sob um aspecto, pode ser múltiplo sob outro. Contudo será uno, absolutamente falando, e múltiplo,
relativamente, o ser que for absolutamente indiviso, de qualquer dos modos seguintes. Ou pela
essência, embora dividido no que não lhe é essencial, como se dá com um mesmo sujeito afetado de
acidentes diversos; ou pelo ato, embora dividido em potência, como acontece com o que é uno pelo
todo e múltiplo pelas partes. O que, pelo contrário, for indiviso relativamente, e dividido
absolutamente, como se dá com o que é dividido quanto à essência, e indiviso só quanto à apreensão da
razão, ou ao seu princípio ou causa, será múltiplo absolutamente, e uno relativamente. Tal é o caso do
que, numericamente múltiplo, é uno especificamente, ou quanto ao princípio. Assim pois, o ser é
dividido pela unidade e pela multiplicidade: por aquele absolutamente, e por esta relativamente, pois a
própria multidão não poderia participar do ser se, de certo modo, não estivesse contida na unidade. E,
por isso, diz Dionísio: Não há multidão que não participe da unidade. Assim o múltiplo pelas partes é
uno pelo todo: o múltiplo quanto aos acidentes é uno pelo sujeito; o que é múltiplo numericamente é
especificamente uno; as coisas especificamente múltiplas unificam-se pelo gênero, e as múltiplas, pela
procedência, são unificadas pelo princípio.

RESPOSTA À TERCEIRA. — Não há tautologia em dizer-se que o ser é uno, porque a unidade acrescenta
algo de racional ao ser.

## Art. 2 — Se unidade e multiplicidade se opõem.
(I Sent., dist. XXIV, q. 1, a. 3, ad 4; De Pot., q. 3, a. 16, ad 3; q. 9, a. 7, ad 14 sqq.; X Metaphys., lect. IV,

VIII).
O segundo discute-se assim. — Parece que unidade e multiplicidade não se opõem.

1. — Pois, não se pode predicar de uma coisa o que lhe é contrário. Ora, toda multidão é, de certo
modo, uma, como acabamos de ver. Logo, a unidade não se lhe opõe.

2. Demais. — Nenhum ser é constituído pelo seu contrário. Ora, a unidade constitui a multidão. Logo,
não se lhe opõe.

3. Demais. — A unidade se opõe à unidade. Ora, a multiplicidade se opõe ao pequeno número. Logo, a
unidade não lhe é contrária.

4. Demais. — Se a unidade se opõe à multidão há-de se lhe opor como o indiviso ao dividido e, portanto,
como a privação ao hábito. Ora, isto é inadmissível, porque daí resultaria que a unidade é posterior à
multidão e por ela definida, quando a verdade é que esta se define por aquela. Logo, haveria círculo na
definição, o que é inconveniente. Logo, unidade e multiplicidade são contrárias.
Mas, em contrário. — Os opostos têm noções opostas. Ora, a noção da unidade funda-se na
indivisibilidade, ao passo que a da multiplicidade implica a divisão. Logo, unidade e multiplicidade
opõem-se.

SOLUÇÃO. — A unidade se opõe à multiplicidade, mas, de modos diversos. Pois, a que é princípio do
número opõe-se à multidão numérica como a medida, ao medido, porque corresponde à noção de
primeira medida; e o número é a multidão por essa unidade medida, como se vê em Aristóteles. Ao
passo que a unidade convertível no ser opõe-se à multidão a modo de privação, como o indiviso, ao
dividido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A privação, sendo uma negação no sujeito, segundo o
Filósofo, nenhuma elimina totalmente o ser, mas, só parcialmente. Por onde, em se tratando do ser
mesmo, a sua universalidade faz com que a privação do ser neste ser se funde; o que não se dá com as
privações das formas especiais como a da vista, da brancura ou semelhantes. E o que se dá com o ser
dá-se com a unidade e a bondade, que nele se convertem; pois, a privação de um bem há-de se fundar
no bem, assim como na unidade se há de fundar a remoção de qualquer parte dela. Donde vem, que a
multidão é uma certa unidade, assim como o mal é um certo bem e o não-ser, um certo ser. Um
contrário, porém, não se predica de outro, porque um deles é absolutamente, e o outro relativamente.
Assim, um ser relativo, como potencial, é não ser, absolutamente, i. é, em ato; ou ainda, o ser,
absolutamente, no gênero da substância, é não ser relativamente quanto a algum acidente. E, logo, do
mesmo modo, o bem, relativamente, é absolutamente mal, ou ao inverso; assim como o que é
absolutamente uno é, relativamente, múltiplo, e ao inverso.

RESPOSTA À SEGUNDA. — Há duas espécies de todo: um homogêneo, composto de partes
dissemelhantes. Ora, qualquer todo homogêneo é constituído de partes, que têm a mesma forma que
ele, assim, qualquer parte da água é água; e tal é a constituição do contínuo, nas suas partes. Em
qualquer todo heterogêneo, pelo contrário, as partes não têm a mesma forma que ele; assim nenhuma
parte da casa é casa, como nenhuma parte do homem é homem. E tal espécie de todo é a multidão.
Pois, como nenhuma das suas partes tem a sua forma, compõe-se a multidão de unidades, como a casa,
do que não é casa. Não que as unidades constituam a multidão, enquanto que, sendo de natureza
indivisível, a ela se lhe oponham mas, pelo que elas têm de ser; do mesmo modo por que as partes de
uma casa a constituem, não por não serem casa, mas por serem determinados corpos.

RESPOSTA À TERCEIRA. — O múltiplo tem muitas acepções. Absolutamente, opõe-se à unidade; e,
noutro sentido, implicando um certo excesso, opõe-se ao pequeno número. Por onde, no primeiro
sentido, dois é multidão; no segundo, não.

RESPOSTA À QUARTA. — A unidade opõe-se privativamente ao múltiplo, enquanto este é dividido. Por
onde, é necessário que a divisão exista, primeiro, na unidade; não absolutamente, mas, em virtude da
apreensão da nossa razão. Pois, apreendemos o simples pelo composto e, por isso, definimos o ponto —
o que não tem parte, ou, o princípio da linha. A multidão, porém, mesmo racionalmente, é conseqüente
à unidade; pois, não concebemos seres divididos como multidão, senão porque atribuímos a unidade a
cada parte da divisão. Logo, a unidade entra na definição da multidão, mas não esta, na daquela. A idéia
de divisão, porém, o nosso intelecto a tira da negação do ser, de modo tal que, primeiramente, o
intelecto apreende o ente; depois, diferençando esse ente de outro, apreende a divisão; em terceiro
lugar, a unidade, e em quarto e último, a multidão.

## Art. 3 — Se Deus é uno.
(Infra., q. 103, a. 3; I Sent., dist. II, a. 1; Il. dist. 1, q. 1, a 1; I Cont. Gent., cap. XLII ; De Pot., q. 3, a. 6;
Compend. Theol., cap. XV; De Div. Nom., cap. XIII, lect. II, III; VIII Physic., lect. XII; XII Metaphys., lect. X).
O terceiro discute-se assim. — Parece que Deus não é uno.

1. — Pois, diz a Escritura (1 Cor 8, 5): E assim sejam muitos os deuses e muitos os senhores.

2. Demais. — Nem a unidade, princípio do número, nem quantidade nenhuma pode ser predicada de
Deus. Do mesmo modo, nem a unidade, que se converte no ser, porque importa privação, sendo
imperfeição, não pode convir a Deus. Logo, não se pode dizer que Deus é uno.
Mas, em contrário, a Escritura (Dt 6, 4): Ouve, Israel, o Senhor nosso Deus é o único Senhor.

SOLUÇÃO. — Por três razões se demonstra que Deus é uno. — A primeira funda-se na sua simplicidade.
Pois, como é manifesto, aquilo que faz um ente singular ser o que é, de nenhum modo é comunicável a
muitos, assim, o que faz Sócrates ser homem pode convir a muitos outros seres, mas só a um ser pode
convir o que o constitui um determinado homem. Se portanto, Sócrates fosse o determinado homem,
que é, pela mesma razão porque é homem, então, como não podem existir vários Sócrates, também
não poderiam existir vários homens. E o mesmo se dá com Deus que, sendo a sua própria natureza,
como já se demonstrou, é Deus pela mesma razão porque é um Deus e, portanto, é impossível existirem
vários deuses.
A segunda funda-se na infinidade da sua perfeição. Pois, como já se demonstrou, Deus compreende em
si a perfeição total do ser. Ora, se existissem vários deuses, necessariamente tinham que diferir e,
portanto, algo conviria a um que não conviria aos outros; e se tal fosse uma privação, eles não seriam
absolutamente perfeitos; se fosse perfeição, esta faltaria aos outros. Logo, é impossível existirem vários
deuses. E, por isso, os antigos filósofos, quase arrastados pela verdade, admitindo um princípio infinito,
consideravam-no único. — A terceira razão funda-se na unidade do mundo. Pois, vemos que todos os
seres existentes se ordenam uns para os outros, na medida em que uns servem aos outros. Ora, coisas
diversas não podem convir numa mesma ordem, se não forem assim dispostas por um só ordenador.
Pois, a multiplicidade de seres reduz-se melhor à unidade da ordem por um só, do que por muitos
ordenadores; porque a unidade é, em si, a causa da unidade, ao passo que a multiplicidade causa a
unidade só acidentalmente, enquanto a tem, de certo modo. Ora, como o ser primeiro é perfeitíssimo
por si mesmo e não por acidente, necessariamente, o que reduz todos os seres à unidade da ordem há-
de ser uno. E a isto chamamos Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Quando o Apóstolo diz que os deuses são muitos, alude
ao erro de certos, que adoravam muitos deuses, considerando tais os planetas, os demais astros, ou
mesmo cada uma das partes deste mundo. E por isso, o Apóstolo acrescenta, no mesmo passo (1 Cor 8,
6): Para vós, porém há um só Deus.

RESPOSTA À SEGUNDA. — A unidade, princípio do número, não é predicada de Deus, mas só do que
tem o ser material. Pois, essa unidade pertence ao gênero dos seres matemáticos, que têm o ser na
matéria, embora dela abstraído pela razão. A unidade, porém, convertível no ser é metafísica e, por isso,
não depende, em si mesma, da matéria. Ora, embora em Deus não haja nenhuma privação, contudo,
pelo nosso modo de apreender, ele não é de nós conhecido senão por meio da privação e da remoção. E
desde então, nada impede que prediquemos de Deus certas afirmações, privativamente, como: é
incorpóreo, infinito. E do mesmo modo dizemos que é uno.

## Art. 4 — Se Deus é soberanamente uno.
(I Sent., dist. XXIV, q. 1, a. 1; De Div. Nom., cap. XIII, lect. III).
O quarto discute-se assim. — Parece que Deus não é soberanamente uno.

1. — Pois, unidade significa privação de divisão. Ora, a privação não é suscetível de mais e de menos.
Logo, Deus não é mais uno que os outros seres, que têm esse atributo.

2. Demais. — Nada é mais indivisível que o que o é, atual e potencialmente, como o ponto e a unidade.
Ora, um ser é considerado uno na medida em que é indivisível. Logo, Deus não é mais uno que a
unidade e que o ponto.

3. Demais. — O que é bom por essência é bom soberanamente. Logo, soberanamente uno é o que tem
esse atributo por essência. Ora, todo ser é uno por essência, como se vê no Filósofo. Logo, todo ser é
uno soberanamente e, portanto, Deus não o é mais que os outros seres.
Mas, em contrário, diz Bernardo: Entre todos os seres que consideramos unos, a unidade da Divina
Trindade ocupa o primeiro lugar.

SOLUÇÃO. — O uno é o ente indiviso, logo, para que algo seja ao máximo uno é preciso que seja ente ao
máximo e indiviso ao máximo. Ora, Deus é um e outro. Ele é ente ao máximo, uma vez que não tem um
ser determinado por nenhuma natureza que o receba, mas Ele é o próprio ser subsistente, sem
nenhuma determinação. Além do mais, é indiviso ao máximo, não estando dividido nem em ato nem em
potência, de qualquer maneira que se possa dividir, mas é simples absolutamente, como já se
demonstrou. Fica então claro que Deus é ao máximo uno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a privação em si mesma não seja suscetível de
mais nem de menos, contudo, como o seu contrário o é, dizemos que também o privativo está sujeito a
essa lei. Logo, na medida em que um ser é mais, menos, ou de nenhum modo dividido ou divisível, nessa
mesma o consideramos mais, menos, ou soberanamente uno.

RESPOSTA À SEGUNDA. — O ponto e a unidade, que é princípio do número, não são soberanamente
entes, porque não têm o ser senão num sujeito. Por onde, nenhum deles é soberanamente uno. Pois,
como o sujeito não é tal, por causa da diversidade entre eles e os seus acidentes, assim, o mesmo se dá
com o acidente.

RESPOSTA À TERCEIRA. — Embora todo ser seja uno pela substância, contudo, a substância de qualquer
não pode causar, a título igual, a unidade, porque a substância de certos seres é composta de partes e a
de outros, não.