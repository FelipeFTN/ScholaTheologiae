# Questão 110: Do governo dos anjos sobre a criatura corpórea.
Em seguida devemos considerar o governo dos anjos sobre a criatura corpórea.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se a criatura corpórea é governada pelos anjos.
(III Cont. Gent., cap. LXXVIII; De Verit., q. 5, a. 8).
O primeiro discute-se assim. — Parece que a criatura corpórea não é governada pelos anjos.

1. — Pois, seres com determinado modo de obrar não precisam ser governados por nenhum superior; e
se precisamos ser governados é para não agirmos de modo diverso do necessário. Ora, os seres
corpóreos obram determinados atos resultantes dos dons naturais, outorgados por Deus. Logo, não
necessitam o governo dos anjos.

2. Demais. — Os seres inferiores são governados pelos superiores. Ora, há certos corpos considerados
inferiores, e outros, superiores. Logo, aqueles são governados por estes, sem necessidade de serem
governados pelos anjos.

3. Demais. — As diversas ordens dos anjos distinguem-se pelas diversas funções. Ora, se as criaturas
corpóreas são governadas pelos anjos, estes terão tantas funções quantas às espécies daquelas. Logo,
também haverá tantas ordens de anjos, quantos estas espécies, o que é contra o que já ficou
estabelecido (q. 108, a. 2). Logo, a criatura corpórea não é governada pelos anjos.
Mas, em contrário, diz Agostinho: todos os corpos são governados pelo espírito racional da vida. E
Gregório: neste mundo visível nada pode ser disposto senão pela criatura invisível.

SOLUÇÃO. — Tanto nas coisas humanas, como nas naturais, é comum seja o poder particular submetido
ao universal e por este regido; assim, o poder do bailio está submetido ao do rei. E também em relação
aos anjos já foi dito (q. 108), que os superiores, que presidem aos inferiores, têm ciência mais universal.
Ora, é manifesto, que a virtude de qualquer corpo é mais particular que a da substância espiritual; pois,
ao passo que toda forma corpórea é individuada pela matéria e determinada, local e temporalmente, as
formas imateriais são absolutas e inteligíveis. Por onde, assim como os anjos inferiores, de formas
menos universais, são governados pelos superiores, assim todos os corpos são governados pelos anjos.
E isto é ensinado não só pelos santos Doutores, mas também por todos os filósofos que admitem
substâncias incorpóreas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As coisas corpóreas têm determinados atos, que só se
exercem quando elas são movidas, porque é próprio do corpo não agir senão pelo movimento. Logo, é
necessário seja a criatura corpórea movida pela espiritual.

RESPOSTA À SEGUNDA. — A objeção procede, segundo a opinião de Aristóteles, que ensinava serem os
corpos celestes movidos pelas substâncias espirituais; e ele procurou determinar o número delas pelo
dos movimentos que se verificam nos corpos celestes. Mas não ensinou existirem quaisquer substâncias
espirituais com governo imediato sobre os corpos inferiores, a não serem talvez as almas humanas. E
isto porque não admitia outras operações, nos corpos inferiores, senão as naturais para explicar as quais
bastava o movimento dos corpos celestes. Mas nós admitimos que muitas coisas se realizam, nos corpos
inferiores, que escapam aos atos naturais dos corpos. E para explicá-los não bastam as virtudes dos
corpos celestes, sendo necessário admitirmos que os anjos têm governo imediato, não só dos corpos
celestes, mas também dos inferiores.

RESPOSTA À TERCEIRA. — Os filósofos trataram diversamente das substâncias imateriais. — Assim, para
Platão, elas são as razões e as espécies dos corpos sensíveis, sendo umas mais universais que outras. E
por isso ensina que essas substâncias têm o governo imediato de todos os corpos sensíveis,
correspondendo a diversos corpos diversas substâncias. — Para Aristóteles porém, elas não são espécies
de corpos sensíveis, mas algo de mais elevado e universal. E por isso, não lhes atribuiu o governo
imediato de cada um dos corpos, mas só dos agentes universais, que são os corpos celestes. — Avicena
enfim seguiu uma via média. Com Platão, admite uma substância espiritual que preside imediatamente
à esfera dos corpos ativos e passivos; porque com Platão, admite serem as formas desses sensíveis
derivadas das substâncias imateriais. Mas, diferindo de Platão, ensina a existência de uma só substância
imaterial, que governa todos os corpos inferiores e a que chama Inteligência agente.
Mas os santos Doutores, de outro lado, ensinam com os Platônicos, que os diversos seres corpóreos são
presididos por diversas substâncias corporais. Assim, Agostinho diz: Cada ser visível deste mundo tem
uma inteligência, que lhe é preposta. Damasceno: O diabo era das virtudes angélicas que presidiam à
ordem terrestre. E Orígenes, a propósito daquilo da Escritura — A jumenta vendo o anjo: o mundo
precisa de anjos, que governem os animais, presidam-lhes ao nascimento, bem como ao crescimento
dos rebentos, das plantações e dos demais seres. Mas isto não se funda em que um anjo por natureza
seja mais apto a presidir aos animais, que às plantas; porque qualquer anjo, ainda mínimo, tem virtude
mais alta e universal do que qualquer gênero de corpos; mas, sim, na ordem da divina sabedoria, que
prepôs, a coisas diversas, diversos superiores. Daqui porém não se segue haja mais de nove ordens de
anjos; pois, como já foi dito (q. 108, a. 2), as ordens se distinguem pelas funções gerais. Por onde, assim
como, segundo Gregório, à ordem das Potestades pertencem todos os anjos que, propriamente,
governam os demônios, assim, à das Virtudes pertencem todos os que governam as coisas puramente
corpóreas e, pelo ministério destes realizam-se às vezes os milagres.

## Art. 2 — Se a matéria corpórea obedece à vontade dos anjos.
(Supra, q. 65, a. 4; q. 91, a. 2; III, Cont. Gent., cap.CIII. De Pot., q. 6, a. 3; De Malo, q. 16, a. 9; Quodl., IX,
q. 4, a. 5; Galat., cap. III, lect 1).
O segundo discute-se assim. — Parece que a matéria corpórea obedece à vontade dos anjos.

1. — Pois, maior é a virtude do anjo que a da alma. Ora, a matéria corpórea obedece à idéia da alma;
assim, pela idéia desta, o corpo do homem sofre a imutação do calor e do frio e, às vezes, até mesmo a
da saúde e da doença. Logo, com maior razão, pela idéia do anjo se transmuta a matéria corpórea.

2. Demais. — Tudo o que pode a virtude inferior pode a superior. Ora, a virtude angélica é superior à
corpórea. Ora, o corpo tem a virtude de transmutar a matéria corpórea para que esta receba
determinada forma; assim quando o fogo gera o fogo. Logo, com maior razão, os anjos por virtude
própria podem levar a matéria corpórea a determinada forma, transmutando-a.

3. Demais. — Toda a natureza corpórea é governada pelos anjos, como já se disse (a. 1); assim pois os
corpos estão para eles como instrumentos, porquanto é da essência do instrumento ser motor movido.
Ora, nos efeitos há algo da virtude dos agentes principais, que não pode ser causado pela virtude do
instrumento e isto é o que há de principal no efeito. Assim, a digestão da nutrição dá-se em virtude do
calor natural, instrumento da alma nutritiva; mas, se daí resulta a carne viva, é em virtude da alma.
Semelhantemente, é virtude própria da serra cortar a madeira; mas por virtude da arte é que esta chega
a receber a forma de um leito. Logo, a forma substancial, que é o principal nos efeitos corpóreos, resulta
da virtude dos anjos; e portanto, a matéria, quanto à sua informação, obedece aos anjos.
Mas, em contrário, diz Agostinho: Não se deve pensar que a matéria das coisas visíveis obedeça à
vontade dos anjos transgressores, mas, só a Deus.

SOLUÇÃO. — Os Platônicos ensinam que as formas materiais são causadas pelas imateriais, porque as
concebem como umas participações destas. E a estes adere Avicena, sob certo aspecto, admitindo que
todas as formas materiais procedem da concepção da Inteligência e que os agentes corpóreos só
dispõem para as formas. — Mas enganaram-se pensando que a forma é algo feito por si mesmo,
procedente, como tal, de um princípio formal. Pois, como o Filósofo o prova, o que vem propriamente a
ser é o composto, que existe, propriamente, como por assim dizer subsistente. Ao passo que a forma
não se chama ente, porque exista, mas porque é o princípio da existência de alguma coisa: e assim, por
conseqüência, ela não vem propriamente a ser, pois, vem a ser o que existe, não passando o vir-a-ser se
não de via para o existir. Ora, é manifesto que o feito é semelhante ao que o fez, porque todo agente
age semelhantemente a si mesmo. Por onde, o que faz as coisas naturais tem semelhança com o
composto, ou porque é composto, e assim o fogo gera o fogo; ou porque o composto total, quanto à
matéria e quanto à forma, existe em virtude de quem os fez, o que é próprio de Deus. Assim, pois, toda
informação da matéria ou vem imediatamente de Deus, ou de algum agente corpóreo; não porém
imediatamente, do anjo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A nossa alma está unida ao corpo, como forma, não
sendo pois, de admirar se este se transmuta, formalmente, à idéia daquela; sobretudo estando o
movimento do apetite sensitivo, que se realiza com certa transmutação corpórea, sujeito ao império da
razão. Ora, como o anjo não se comporta assim em relação aos corpos naturais, a objeção não colhe.

RESPOSTA À SEGUNDA. — O que pode a virtude inferior pode a superior, não do mesmo, mas de modo
mais excelente; assim como o intelecto conhece os sensíveis de modo mais excelente que o sentido. O
anjo, pois, transmuta a matéria corpórea de modo mais excelente que os agentes corpóreos, a saber,
movendo, como causa superior, estes agentes.

RESPOSTA À TERCEIRA. — Nada impede que, por virtude dos anjos, resultem, nas coisas naturais, certos
efeitos, para os quais não bastariam os agentes corpóreos. Mas isto não quer dizer que a matéria
obedeça à vontade do anjo; assim como ela não obedece à vontade dos cozinheiros que, com uma certa
sabedoria artística, obtêm um modo de decocção, por meio do fogo, que este por si só não poderia
causar. E isto porque reduzir a matéria ao ato da forma substancial não excede à virtude do agente
corpóreo, pois, é natural a este poder obrar o que lhe é semelhante.

## Art. 3 — Se os corpos obedecem aos anjos quanto ao movimento local.
(De Pot., q. 6, a. 3; De Malo, q. 16, a. 1, ad 14; a. 10; Quodl. IX. Q. 4, a. 5; In Iob, cap. I, lect III).
O terceiro discute-se assim. — Parece que os corpos não obedecem aos anjos, quanto ao movimento
local.

1. — Pois, o movimento local dos corpos naturais resulta da forma deles. Ora, os anjos não causam as
formas dos corpos naturais, como já se disse (a. 2). Logo, também não podem causar-lhes o movimento
local.

2. Demais. — Como o prova Aristóteles, o movimento local é o primeiro dos movimentos. Ora, os anjos
não podem causar os outros movimentos, transmutando formalmente a matéria. Logo, também não
podem causar o movimento local.

3. Demais. — Os membros corpóreos obedecem às concepções da alma, quanto ao movimento local,
por terem em si mesmos um princípio vital. Ora, nos corpos naturais não há nenhum princípio vital.
Logo, eles não obedecem aos anjos, quanto ao movimento local.
Mas, em contrário, diz Agostinho, que os anjos aplicam os germes corpóreos para produzirem certos
efeitos. Ora, tal não podem fazer, senão movendo-se localmente. Logo, os corpos lhes obedecem,
quanto ao movimento local.

SOLUÇÃO. — Como diz Dionísio, a divina sabedoria une as ínfimas, das criaturas superiores, às
supremas, das inferiores. Por onde se vê, que a natureza inferior, no que há nela de supremo, tem
contato com a natureza superior. Ora, a natureza corpórea é inferior à espiritual. Entre todos os
movimentos corpóreos, porém, o movimento local é o mais perfeito, como o prova Aristóteles; e a
razão é que o móvel, no movimento local, não é potencial em relação a algo do intrínseco, como tal,
mas só a algo de extrínseco, que é o lugar. E por isso da natureza corpórea é natural ser movida, quanto
ao movimento local, imediatamente, pela natureza espiritual. Por onde, os filósofos ensinaram, que os
corpos supremos são movidos localmente pelas substâncias espirituais; e por isso vemos que a alma
move o corpo, primária e principalmente, pelo movimento local.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Há nos corpos outros movimentos locais, além dos que
resultam das formas; assim, o fluxo e o refluxo do mar não resultam da forma substancial da água, mas
se dão por virtude da lua. E com maior razão, certos movimentos locais podem ser causados pela
virtude das substâncias espirituais.

RESPOSTA À SEGUNDA. — Os anjos, causando o movimento local, que é o primeiro, podem por este
causar os outros movimentos, empregando os agentes corpóreos, para produzirem tais efeitos; assim
como o ferreiro emprega o fogo para amolecer o ferro.

RESPOSTA À TERCEIRA. — Os anjos têm virtude menos limitada que a alma. Por onde, a virtude motiva
desta é limitada pelo corpo a que esta unida, que ela vivifica e mediante o qual pode mover outros
seres. Enquanto que, a virtude do anjo, não estando limitada por nenhum corpo, ele pode mover
localmente corpos que não lhe estão conjuntos.

## Art. 4 — Se os anjos podem fazer milagres.
(Infra, q. 114, a. 4; III Cont. Gent., cap. CII, CIII; De Pot., q. 6, a. 3, 4; Compend. Theol., cap. CXXXVI;
Opusc.XI, Resp. de XXXVI Artic., a. 15, 16, 18; in Ioan, cap. X, lect. V).
O quarto discute-se assim. — Parece que os anjos podem fazer milagres.

1. — Pois, como diz Gregório, chamam-se virtudes os espíritos pelos quais mais freqüentemente se
fazem presságios e os milagres.

2. Demais. — Como diz Agostinho, os magos fazem milagres por contratos privados; os bons Cristãos,
por pública justiça; os maus Cristãos, por sinais da justiça publica. Ora, os magos fazem milagres por
serem ouvidos pelos demônios, como o mesmo autor diz, no mesmo livro. Logo, os demônios podem
fazer milagres e com maior razão os anjos bons.

3. Demais. — Como Agostinho diz, crê-se que as coisas visivelmente feitas, mesmo pelas potestades
inferiores do ar, podem ser feitas, sem absurdo. Ora, dizemos que há milagre, quando um efeito das
causas naturais é produzido sem dependência da causa; p. ex., quando alguém sara de febre, sem ser
por operação da natureza. Logo, os anjos e os demônios podem fazer milagres.

4. Demais. — A virtude superior não esta sujeita à ordem da causa inferior. Ora, a natureza corpórea é
inferior ao anjo. Logo, este pode operar fora da ordem dos agentes corpóreos, o que é fazer milagres.
Mas, em contrário, diz a Escritura, de Deus (Sl 135, 4): O que faz grandes maravilhas só.

SOLUÇÃO. — Diz-se que há propriamente milagre, quando alguma coisa se realiza, contra a ordem da
natureza. Não basta porém para a existência do milagre que alguma coisa se faça contra a ordem de
alguma natureza particular; pois então quem atirasse uma pedra para cima faria milagre, por isso contra
a ordem da natureza da pedra. Chama-se, portanto, milagre ao que se faz contrariamente à ordem de
toda a natureza criada. Ora, isso Deus apenas pode fazer; porque tudo quanto fizer o anjo, ou qualquer
natureza criada, por virtude própria, fa-lo-á conforme à ordem da natureza criada e então não é milagre.
Donde se conclui que só Deus pode fazer milagres.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que certos anjos fazem milagres ou porque por
desejo deles Deus os faz, assim como também se diz que os santos os fazem; ou porque desempenham
certas funções, nos milagres, p. ex., reunindo as cinzas, na ressurreição geral, ou fazendo coisas
semelhantes.

RESPOSTA À SEGUNDA. — Chamam-se milagres, simplesmente falando, segundo já disse, as coisas
feitas contra a ordem de toda a natureza criada. Mas, como não nos é conhecida toda a virtude da
natureza criada, por isso dizemos que para nós há milagre quando alguma coisa é feita contra a ordem
da natureza criada, que conhecemos, por alguma virtude criada, que ignoramos. Assim não é milagre,
em si mesmo, mas só para nós, qualquer coisa que os demônios façam por virtude natural; sendo desse
modo que os magos fazem milagres, por meio dos demônios. E diz-se que isso se faz por contratos
privados porque qualquer virtude criada está para o universo como a virtude de qualquer pessoa
privada está para a cidade. Por onde, quando um mago faz qualquer coisa, por pacto concluído com o
demônio, faz tal por um como contrato privado. A justiça divina porém está para todo o universo, como
a lei pública, para a cidade. E por isso, diz-se que os bons Cristãos, quando fazem milagres, por meio da
justiça divina, fazem-nos por justiça pública. Ao passo que os maus Cristãos os fazem pelos sinais da
justiça pública, invocando o nome de Cristo ou empregando certos sacramentos.

RESPOSTA À TERCEIRA. — As potestades espirituais podem fazer coisas viáveis neste mundo,
empregando germes corpóreos, por meio do movimento local.

RESPOSTA À QUARTA. — Embora os anjos possam fazer coisas contra a ordem da natureza corpórea,
não podem entretanto fazer nada contra a ordem de toda a criatura; o que é exigido para a existência
do milagre, como já se disse.