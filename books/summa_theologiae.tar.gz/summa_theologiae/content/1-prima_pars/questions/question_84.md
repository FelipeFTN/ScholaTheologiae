# Questão 84: Por meio do que a alma, unida ao corpo, intelige as coisas corpóreas.
Em seguida deve-se tratar dos atos e dos hábitos da alma, quanto às potências intelectivas e apetitivas;
pois, outras potências não pertencem diretamente à consideração do teólogo. Como, porém, os atos e
os hábitos da parte apetitiva pertencem à consideração da ciência moral, serão, por isso, tratados na
segunda parte desta obra, que versará a matéria moral. Agora só se tratará dos atos e dos hábitos da
parte intelectiva. E, primeiro, dos atos. Segundo, dos hábitos. Na consideração dos atos procederemos
do modo seguinte. Primeiro, há a considerar como é que intelige a alma unida ao corpo. Segundo, como
intelige quando separada do corpo. A primeira consideração, por sua vez, será tripartida. Assim,
primeiro se considerará como a alma intelige as coisas corpóreas, que lhe são inferiores. Segundo, como
se intelige a si mesma, e às coisas que lhe são interiores. Terceiro, como intelige as substâncias
imateriais, que lhe são superiores. Ora, sobre o conhecimento das coisas corpóreas, ocorre tríplice
consideração. Primeiro, por meio do que as conhece. Segundo, como e em que ordem. Terceiro, o que
nelas conhece.
Sobre o primeiro ponto, oito artigos se discutem:

## Art. 1 — Se a alma conhece os corpos pelo intelecto.
(De Verit., q.10, a. 4).
O primeiro discute-se assim. ― Parece que a alma não conhece os corpos pelo intelecto.

1. ― Pois, diz Dionísio que os corpos não podem ser compreendidos pelo intelecto; porque só os
sentidos podem perceber o que é corpóreo. E diz também que a visão intelectual é só daquelas coisas
que estão pela sua essência na alma. Ora, essas não são corpos. Logo, a alma pelo intelecto, não pode
conhecer os corpos.

2. Demais. ― O sentido está para os inteligíveis, como o intelecto para os sensíveis. Ora, a alma, pelo
sentido, de nenhum modo pode conhecer as coisas espirituais, que são inteligíveis. Logo, de nenhum
modo, pelo intelecto, pode conhecer os corpos, que são sensíveis.

3. Demais. ― O intelecto se refere às coisas necessárias e que existem sempre do mesmo modo. Ora,
todos os corpos são móveis e não existem sempre do mesmo modo. Logo, pelo intelecto, a alma não
pode conhecer o corpo.
Mas, em contrário, a ciência está no intelecto. Se, pois, este não conhece os corpos, resulta que não há
nenhuma ciência deles. E, então, desaparecerá a ciência natural, que é a do corpo móvel.

SOLUÇÃO. ― Para evidenciar esta questão, deve-se dizer que os primeiros filósofos que pesquisaram as
naturezas das coisas, pensavam que no mundo só existe corpo. E como viam que todos os corpos são
móveis e julgavam estarem num fluxo contínuo, concluíram que nós não podemos ter nenhuma certeza
da verdade das coisas. Pois, o que está em fluxo contínuo não pode ser apreendido com certeza porque,
antes de ser discernido pela mente, já desapareceu: e, por isso, Heráclito disse que não é possível tocar
duas vezes a água de um rio que corre, como refere o Filósofo.
Platão, porém, que veio depois, para poder salvar o conhecimento certo da verdade adquirida, por nós,
por meio do intelecto, introduziu, além desses seres corpóreos, outro gênero de entes separado da
matéria e do movimento, a que chamou espécies ou idéias. E, pela participação destas cada um dos
seres singulares e sensíveis se chama homem, cavalo ou coisa semelhante. Assim, pois, dizia que as
ciências e as definições e tudo o que pertence ao ato do intelecto, não se refere aos corpos sensíveis
que vemos, mas a esses seres imateriais e separados. De modo que a alma não intelige esses seres
corpóreos, mas sim, as espécies separadas deles.
Ora, de duplo modo se mostra à falsidade desta opinião. ― Primeiro porque, sendo essas espécies
imateriais e imóveis, seria excluído das ciências o conhecimento do movimento e da matéria, o que é
próprio da ciência natural, bem como a demonstração pelas causas motoras e materiais. ― Segundo,
seria visível que, procurando conhecer as causas que nos são manifestas, introduzamos outras
intermediárias, que não podem ser as substâncias das primeiras por diferirem delas essencialmente. De
modo que, conhecidas essas substâncias separadas, nem por isso poderemos julgar das coisas sensíveis.
E a causa de Platão ter-se desviado da verdade está em que, julgando que todo conhecimento se dá em
virtude de certa semelhança, pensava que a forma do conhecido está necessariamente no conhecente,
do modo pelo qual ela está no conhecido. Assim, considerou que a forma da causa inteligida está no
intelecto universal, imaterial e imovelmente; coisa que ressalta da própria operação do intelecto, que
intelige universalmente e como por uma certa, necessidade; ora, o modo da ação é dependente do
modo da forma agente. E então, concluiu pela necessidade de as coisas inteligidas subsistirem em si
mesmas imaterial e imovelmente. Ora, isto não é necessário. Pois, mesmo nos seres sensíveis, vemos
que a forma está, num dos sensíveis, de modo diverso que em outro; p. ex., num a brancura é mais
intensa, noutro, mais remissa; num a brancura vai com a doçura, noutro, sem ela. Ora, é também assim
que a forma sensível está, de um modo, na coisa exterior à alma e, de outro, no sentido, que recebe as
formas sensíveis sem matéria, p. ex., a cor do ouro sem o ouro. E, semelhantemente, o intelecto recebe,
ao seu modo, imaterial e imovelmente, as espécies móveis e materiais dos corpos; pois, o recebido esta
no recipiente ao modo deste. ― Logo, deve-se concluir que a alma, pelo intelecto, conhece os corpo por
um conhecimento imaterial, universal e necessário.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O passo de Agostinho deve se entender daquelas coisas
pelas quais o intelecto conhece, e não daquelas que ele conhece. Ora, ele conhece os corpos,
inteligindo, mas não por meio de corpos nem de semelhanças materiais e corpóreas; mas por espécies
imateriais e inteligíveis que, por essência, podem estar na alma.

RESPOSTA À SEGUNDA. ― Como ensina Agostinho, não se deve dizer que, assim como sentido conhece
só as coisas corpóreas, assim o intelecto, só as espirituais; porque, então, resultaria que Deus e os anjos
não conheceriam os seres corpóreos. E a razão desta diversidade é que a virtude inferior não se estende
ao domínio da virtude superior; mas a virtude superior opera, de modo mais excelente, o que pertence
à inferior.

RESPOSTA À TERCEIRA. ― Todo movimento supõe algo imóvel. Quando, pois, a transmutação é
qualitativa, a substância permanece imóvel; e quando se transmuda a forma substancial, a matéria
permanece imóvel. Ora, os modos de ser das coisas móveis são imóveis; assim, embora Sócrates nem
sempre esteja sentado, contudo é imovelmente verdade que, quando está sentado, permanece num
lugar. Por onde, nada impede ter uma ciência imóvel das coisas móveis.

## Art. 2 — Se a alma, pela sua essência, intelige os seres corpóreos.
(II Sent., dist. III, parte II, q. 2, a. 1; III dist. XIV, a. 1, qª 2; II Cont. Gent., cap. XCVIII; Ve Verit., q. 8, a. 8 ).
O segundo discute-se assim. ― Parece que a alma, pela sua essência, intelige as coisas corpóreas.

1. ― Pois, diz Agostinho, a alma resolve as imagens dos corpos e as tira feitas em si mesma, de si
mesma; porquanto dá, para a formação delas, algo de sua substância. Ora, pelas semelhanças dos
corpos é que os intelige. Logo, pela sua essência, que dá para a formação de tais semelhanças e da qual
as forma, conhece os seres corpóreos.

2. Demais. ― O Filósofo diz que a alma, de certo modo, é tudo. Ora, como o semelhante se conhece
pelo semelhante, resulta que a alma, por si mesma, conhece os seres corpóreos.

3. Demais. ― A alma é superior às criaturas corpóreas. Ora, as inferiores estão nas superiores de modo
mais eminente que em si mesmas, como diz Dionísio. Logo, todas as criaturas corpóreas existem de
modo mais nobre na essência mesma da alma do que nelas próprias. Logo, pela sua substância, a alma
pode conhecer as criaturas corpóreas.
Mas, em contrário, diz Agostinho: a mente colige os conhecimentos das coisas corpóreas pelos sentidos
do corpo. Ora, a alma mesma não é cognoscível pelos sentidos do corpo. Logo, não conhece os seres
corpóreos pela sua substância.

SOLUÇÃO. ― Os antigos filósofos ensinaram que a alma, pela sua essência, conhece os corpos. Pois, é
ínsito em comum às almas de todos os animados conhecer o semelhante pelo semelhante. Assim,
pensavam que a forma do conhecido está no conhecente do modo pelo qual está na coisa conhecida.
Porém os Platônicos pensavam de modo contrário. Pois Platão, conhecendo que a alma intelectual é
imaterial e conhece imaterialmente, ensinou a subsistência imaterial das formas das causas conhecidas.
Ao passo que os primitivos fisiólogos, considerando que as coisas conhecidas são corpóreas e materiais,
ensinavam ser necessário estejam na alma conhecente, materialmente. E como atribuíam à alma o
conhecimento de tudo, diziam que a natureza dela é comum com a de todos os seres. E ainda, como a
natureza dos principiados é constituída pelos princípios, atribuíram à alma a natureza de princípio; de
modo que, quem admitia o fogo como princípio de tudo admitia que a alma é de natureza ígnea; e,
semelhantemente, em relação ao ar e à água. Porém Empédocles, que admitia quatro elementos
materiais e dois motores, ensinou que também a alma é composta deles. Assim que, introduzindo as
coisas na alma, materialmente, concluíram que todo conhecimento da alma é material, sem discernirem
entre o intelecto e o sentido.
Mas tal opinião não tem provas. ― Primeiro, porque no princípio material, do qual falavam, existem os
principiados só em potência. Ora, nada é conhecido como potencial, mas como atual, como já se
evidenciou. Por onde, nem a potência mesma se conhece senão pelo ato. Portanto, não basta atribuir à
alma a natureza dos princípios, para que ela conheça tudo, sem existirem nela as naturezas e as formas
dos efeitos singulares, p. ex., do osso, da carne e coisas semelhantes, como argumenta Aristóteles
contra Empédocles. ― Segundo, porque se fosse necessário à coisa conhecida existir materialmente no
conhecente, nenhuma razão haveria de carecerem de conhecimento as coisas que subsistem
materialmente fora da alma. P.ex., se a alma conhece o fogo pelo fogo, também este, que existe fora da
alma, conheceria o fogo.
Conclui-se, portanto, pela necessidade de existirem as coisas materiais conhecidas, no conhecente, não
material, mas antes, imaterialmente. E a razão disto é que o ato do conhecimento se estende às coisas
existentes fora do conhecente. Ora, nós conhecemos também aquilo que está fora de nós, pois, pela
matéria à forma de uma coisa é reduzida à unidade. Por onde é manifesto que a essência do
conhecimento é oposta à da materialidade. E por isso, seres que recebem as formas só materialmente,
de nenhum modo são cognoscitivas, como as plantas, segundo já se disse. E quanto mais
imaterialmente um ser tem em si a forma da coisa conhecida, tanto mais perfeitamente conhece. Por
onde, o intelecto, que abstrai a espécie, não só da matéria, mas também das condições materiais
individuantes, conhece mais perfeitamente que o sentido, que recebe a forma da coisa conhecida sem
matéria, por certo, mas em condições materiais. E dentre os próprios sentidos, a vista é o mais
cognoscitivo, por ser menos material, como antes se disse. E, dentre os intelectos, mais perfeito é o
mais imaterial.
Do sobredito resulta, pois, que, se há algum intelecto que, pela sua essência, conheça todas as coisas,
necessário é que a sua essência contenha em si, imaterialmente, a todas elas; e é assim que os antigos
ensinavam que a essência da alma é atualmente composta dos princípios de todos os seres materiais,
para conhecer todas as coisas. Ora, é próprio de Deus ter a essência imaterialmente compreensiva de
todas as coisas, enquanto que os efeitos preexistem virtualmente na causa. Portanto, só Deus intelige,
pela sua essência, todas as coisas; não a alma humana nem o anjo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― No passo aduzido Agostinho fala da visão imaginária,
que se faz por imagens corpóreas; para a formação de cujas imagens, a alma dá algo da sua substância,
assim como o sujeito é dado para ser informado por alguma forma. E assim faz, de si mesma, tais
imagens; não que a alma ou algo da alma se converta a ser tal ou tal imagem, mas no sentido em que se
diz que um corpo torna-se colorido por ser informado pela cor. E essa interpretação ressalta do que se
vai seguir. Pois, diz ele, que conserva alguma coisa, a saber, não formada com tal imagem, pela qual
julgará livremente da espécie de tais imagens; e a isso chama mente ou intelecto. Porém à parte
informada por tais imagens, a saber, a imaginativa, chama comum a nós e aos animais.

RESPOSTA À SEGUNDA. ― Aristóteles não ensinou, como os antigos fisiólogos, que a alma é composta,
atualmente, de todas as coisas; mas disse que a alma é de certo modo tudo, enquanto potencial em
relação a tudo: pelo sentido, em relação aos sensíveis; pelo intelecto, em relação aos inteligíveis.

RESPOSTA À TERCEIRA. ― Qualquer criatura tem o ser finito e determinado. Por onde, a essência da
criatura superior, embora tenha alguma semelhança da inferior, enquanto tem de comum o mesmo
gênero, não tem, contudo, semelhança com ela, completamente; pois, é determinada a uma certa
espécie, fora da qual está a espécie da criatura inferior. Mas, a essência de Deus é a semelhança perfeita
de tudo, quanto a tudo o que se encontra nas coisas, como o princípio universal de todas elas.

## Art. 3 — Se a alma intelige todas as coisas por meio de espécies que lhe são naturalmente inatas.
(II Cont. Gent., cap. LXXXIII; De Verit., q. 10, a. 6; q. 11, a. 1; q. 18, a. 7; q. 19, a. 1; Qu. De Anima, a. 15 ).
O terceiro discute-se assim. ― Parece que a alma intelige todas as coisas por espécies que lhe são
naturalmente ínsitas.

1. ― Pois, diz Gregório, o homem tem comum com o anjo o inteligir. Ora, o anjo intelige tudo por
formas que lhe são naturalmente ínsitas; por onde, se diz no livro De causis, que toda inteligência está
cheia de formas. Logo, também a alma tem ínsitas em si as espécies das coisas naturais, pelas quais
intelige as coisas corpóreas.

2. Demais. ― A alma intelectiva é mais nobre que a matéria prima corpórea. Ora, esta foi criada por
Deus com formas, em relação às quais está em potência. Logo, com maioria de razão, a alma intelectiva
foi criada por Deus com as espécies inteligíveis. E assim, intelige as causas corpóreas por espécies que
lhe são naturalmente ínsitas.

3. Demais. ― Ninguém pode responder a verdade senão do que sabe. Mas, qualquer pessoa, sem
ciência adquirida, pode responder a verdade atinente a cada assunto, contanto que seja habilmente
interrogado, como narra Platão de um certo indivíduo. Logo, antes de alguém adquirir a ciência já tem
conhecimento das causas; o que não se daria, se a alma não tivesse espécies que lhe são naturalmente
ínsitas. Logo, por tais espécies é que ela intelige as coisas corpóreas.
Mas, em contrário, diz o Filósofo, falando do intelecto, que este é como uma tábua na qual nada está
escrito.

SOLUÇÃO. ― Como a forma é o princípio da ação, necessário é que uma coisa esteja para a forma, seu
princípio de ação, como está para a ação. Assim, se o ser movido para o alto provém da levidade, o que
só potencialmente é levado para cima é leve só em potências; o que, porém, é levado em ato é leve em
ato. Ora, vemos que o homem conhece às vezes, só em potência, tanto quanto ao sentido como quanto
ao intelecto. E de tal potência é reduzido ao ato: para sentir, pelas ações dos sensíveis no sentido; para
inteligir, pela disciplina ou invenção. Por onde, deve-se dizer que a alma cognoscitiva está em potência
tanto para as semelhanças, que são os princípios do sentir, como para as semelhanças, que são os
princípios do inteligir. E por isto Aristóteles ensinou, que o intelecto, pela qual a alma intelige, não tem
nenhumas espécies que lhe sejam naturalmente ínsitas, mas é, no princípio, potencial em relação a
todas essas espécies.
Mas, o que tem forma atual, não pode, às vezes, agir segundo essa forma, por causa de algum
impedimento; assim se dá com um corpo leve se ficar impedido de ser levado para cima. E por isso Pia
tão ensinava, que o intelecto do homem está naturalmente cheio de todas as espécies inteligíveis, mas,
pela união com o corpo, é impedido de atualizar-se.
Mas esta opinião não é conforme a verdade. ― Primeiro, porque, se a alma tem ciência natural de todas
as coisas, não é possível que se esqueça de tal modo dela que não tenha consciência de a possuir. Pois,
ninguém esquece o que naturalmente conhece; p. ex., que qualquer todo é maior que a sua parte e
coisas semelhantes. E, sobretudo, ver-se-á a incongruência de tal opinião, se se admite como natural à
alma estar unida ao corpo, como antes ficou estabelecido; pois, é incongruente que a operação natural
a qualquer ser seja totalmente impedida por aquilo que lhe é natural a ele. ― Em segundo lugar,
aparecerá manifesta a falsidade de tal opinião no fato de, faltando algum sentido, faltar à ciência
daquilo que, por esse sentido, é apreendido; assim, o cego de nascença não pode ter nenhum
conhecimento das cores. O que não se daria se ao intelecto da alma fossem naturalmente ínsitas as
noções de todos os inteligíveis. ― E portanto, deve-se concluir que a alma não conhece as coisas
corpóreas por espécies que lhe sejam naturalmente ínsitas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O homem tem de comum com os anjos o inteligir; mas
não tem a eminência do intelecto deles. Assim como os corpos inferiores, que apenas existem, segundo
Gregório, são deficientes em relação à existência dos corpos superiores. Pois, a matéria destes não é
totalmente completa pela forma, mas é potencial em relação às formas que não tem; ao passo que a
matéria dos corpos celestes é totalmente completa pela forma, de modo que não é potencial em
relação à outra forma, como já se demonstrou. E, semelhantemente, o intelecto do anjo é perfeito, na
sua natureza, pelas espécies inteligíveis; ao passo que o intelecto humano é potencial, em relação a tais
espécies.

RESPOSTA À SEGUNDA. ― A matéria prima tem o ser substancial, pela forma; por onde, era necessário
que fosse criado sob alguma forma, pois, do contrário, não existiria em ato. Porém, existindo sob uma
forma, é potencial em relação às outras. Ao passo que o intelecto não tem o ser substancial, pela
espécie inteligível; por isso não há símile.

RESPOSTA À TERCEIRA. ― A interrogação ordenada procede de princípios comuns, conhecidos por si
mesmos, para as noções próprias. E por tal processo é causada a ciência na alma do discente. Por onde,
quando este responde a verdade a respeito daquilo sobre que é pela segunda vez interrogado, não é
porque já a conhecesse de antemão, mas porque a aprende de novo. E nada importa se quem ensina,
propondo ou interrogando, procede de princípios comuns, para a conclusão. Pois, de qualquer modo, o
espírito do ouvinte se certifica do que é posterior pelo que é anterior.

## Art. 4 — Se as espécies inteligíveis efluem, para a alma, de algumas foras separadas.
(De Verit., q. 10 a. 6; q. 11, a. 1; Qu. De Anima, a. 15 ).
O quarto discute-se assim. ― Parece que as espécies inteligíveis efluem, para a alma, de algumas
formas separadas.

1. ― Todo ser participado é causado por um ser essencial; assim, um corpo ígneo se reduz ao fogo,
como à sua causa. Ora, a alma intelectiva, enquanto intelige em ato, participa dos inteligíveis; pois, o
intelecto em ato é, de certo modo, a coisa inteligida em ato. Logo, as coisas que, em si e por essência,
são inteligidas em ato, são as causas de a alma intelectiva inteligir em ato. Ora, as coisas inteligidas em
ato, por essência, são formas agentes, sem matéria. Logo, as espécies inteligíveis, pelas quais a alma
intelige, são causadas por certas formas separadas.

2. Demais. ― Os inteligíveis estão para a coisa inteligida como os sensíveis para o sentido. Ora, os
sensíveis, que estão em ato, fora da alma, são as causas dos mesmos sensíveis que estão no sentido e
pelos quais sentimos. Logo, as espécies inteligíveis, pelas quais o nosso intelecto intelige, são causadas
por certos inteligíveis em ato existentes fora da alma. Ora, estes não são senão formas separadas da
matéria. Logo, as formas inteligíveis do nosso intelecto efluem de certas substâncias separadas.

3. Demais. ― Tudo o que está em potência se reduz ao ato por aquilo que já está em ato. Portanto, a
causa de o nosso intelecto, ser primeiramente potencial, e em seguida inteligir em ato, é algum
intelecto sempre atual. Ora, este é o intelecto separado. Logo, é por certas substâncias separadas que
são causadas as espécies inteligíveis, pelas quais inteligimos em ato.
Mas, em contrário, se fosse assim, não precisaríamos dos sentidos para inteligir. O que é evidentemente
falso, principalmente pelo fato de não poder, de nenhum modo, quem carece de um sentido ter ciência
dos sensíveis desse sentido.

SOLUÇÃO. ― Alguns ensinaram que as espécies inteligíveis do nosso intelecto procedem de certas
formas ou substâncias separadas. E isso, de duplo modo.
Assim, para Platão, como já se disse, as formas das coisas sensíveis são subsistentes por si, sem matéria;
p. ex., a forma do homem a que chamava homem em si, a forma ou idéia do cavalo, a que chamava
cavalo em si, e assim por diante. Ora, tais formas separadas, ensinava, são participadas tanto pela nossa
alma como pela matéria corpórea; por aquela, a fim de conhecer; por esta, a fim de existir. Pois, assim
como a matéria corpórea, participando da idéia da pedra, faz-se pedra, assim o nosso intelecto,
participando dessa mesma idéia intelige a pedra. E a participação da idéia faz-se por uma certa
semelhança da idéia mesma, naquele que dela participa, ao modo pelo qual o exemplar é participado
pelo exemplado. Portanto, ensinando que as formas sensíveis, existentes na matéria corpórea, efluem
das idéias, como certas semelhanças delas que são, ensinava também que as espécies inteligíveis do
nosso intelecto são certas semelhanças das idéias das quais efluem. E por isso, como se disse antes,
Platão referia as ciências e as definições às idéias. Mas, sendo contra – essência das coisas sensíveis que
as formas delas subsista sem as matérias, como Aristóteles o prova super abundantemente, por isso
Avicena, rejeitando tal posição, ensinou que as espécies inteligíveis de todas as coisas, não subsistem,
por certo, sem matéria, mas preexistem imaterialmente, nos intelectos separados. E destes derivam,
primariamente, tais espécies para o intelecto seguinte; e assim por diante, até o último intelecto
separado, a que chamava intelecto agente, do qual, como dizia, efluem as espécies inteligíveis para as
nossas almas, e as formas sensíveis, para a matéria corpórea. ― E assim, Avicena concorda com Platão
em que as espécies inteligíveis do nosso intelecto efluem de certas formas separadas; ao passo que,
para Platão, elas subsistem por si, como o refere Aristóteles, para Avicena elas existem no intelecto
agente. E ainda Avicena, diferindo de Platão, ensina que as espécies inteligíveis não permanecem em o
nosso intelecto, depois de ter este acabado de inteligir em ato, sendo preciso que o intelecto se
converta a recebê-las de novo, reiteradamente. Por onde, não admite que a ciência seja naturalmente
inata na alma, como Platão, que ensinava permanecerem na alma, imovelmente, as participações das
idéias. Mas, segundo tal posição, não se poderia dar a razão suficiente porque a nossa alma está unida
ao corpo. Pois, não se poderia dizer que a alma intelectiva está unida ao corpo, por causa do corpo;
porque, nem a forma existe para a matéria, nem o motor para o móvel, mas antes, ao contrário. Mas,
principalmente, o corpo é necessário à alma intelectiva para a operação própria dela, que é o inteligir,
pois, pela sua essência, não depende do corpo. Se, pois, a alma fosse apta, por natureza, a receber as
espécies inteligíveis, por influência somente de certos princípios separados, sem que as recebesse pelos
sentidos, não precisaria, então, de corpo para inteligir e estaria unida ao corpo em vão. E nem é
suficiente dizer que a nossa alma precisa dos sentidos para inteligir, sendo por eles excitada, de certo
modo, à consideração das coisas, cujas espécies inteligíveis recebe, dos princípios separados. Porque tal
excitação não é necessária à alma, senão por estar de certo modo adormecida, segundo os Platônicos, e
esquecida, por causa da união com, o corpo. De modo que então, os sentidos só serviriam à alma
intelectiva para eliminar o impedimento que lhe advém da união com o corpo. Logo, resta indagar qual
a causa da união da alma com o corpo. Ora, não basta admitir, com Avicena, que os sentidos são
necessários à alma, para, excitada por eles, converter-se à inteligência agente, da qual recebe as
espécies. Porque, se estivesse em a natureza da alma inteligir por espécies influídas da inteligência
agente, seguir-se-ia que, às vezes; a alma poderia converter-se à inteligência agente, por inclinação da
sua natureza; ou ainda, excitada por um sentido, poderia converter-se a tal inteligência para receber as
espécies de sensíveis próprios a outro sentido de que, p. ex., alguém estivesse privado. E, então, o cego
de nascença poderia ter ciência das cores, coisa manifestamente falsa. ― Por onde, deve-se concluir
que as espécies inteligíveis, pelas quais a nossa alma intelige, não efluem de formas separadas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― As espécies inteligíveis, participadas pelo nosso
intelecto, reduzem-se, como à causa primeira, a algum princípio inteligível por sua essência, que é Deus.
E desse princípio procedem elas, mediante as formas das coisas sensíveis e materiais, das quais obtemos
a ciência, como diz Dionísio.

RESPOSTA À SEGUNDA. ― As coisas materiais, segundo o ser que têm fora da alma, podem ser
sensíveis em ato, não porém, inteligíveis em ato. Por onde não há símile entre o sentido e o intelecto.

RESPOSTA À TERCEIRA. ― O nosso intelecto possível reduz-se da potência ao ato por algum ser em ato,
i. é., pelo intelecto agente, que é uma virtude da nossa alma, como já se disse; e não por algum intelecto
separado, como pela causa próxima, embora talvez como pela causa remota.

## Art. 5 — Se a alma intelectiva conhece as coisas materiais nas razões eternas.
(Supra, q. 12 a. 2 ad 3; De Verit., q. 8, a. 7, ad 13; q. 1a. 8 ).
O quinto discute-se assim. ― Parece que a alma intelectiva não conhece as coisas materiais nas razões
eternas.

1. ― Aquilo, no que alguma coisa é conhecida, é objeto de conhecimento maior e anterior. Ora, a alma
intelectiva do homem, no estado da vida presente, não conhece as razões eternas, porque não conhece
a Deus, em quem existem tais razões e a quem está unido como a um ignoto, segundo diz Dionísio.
Logo, a alma não conhece todas as coisas nas razões eternas.

2. Demais. ― A Escritura diz: as coisas invisíveis de Deus vêm-se por aquelas que foram feitas. Logo,
entre as coisas invisíveis de Deus enumeram-se as razões eternas. Portanto, estas razões são conhecidas
pelas criaturas materiais, e não inversamente.

3. Demais. ― As razões eternas não são senão as idéias. Pois, Agostinho diz, que as idéias são as razões
estáveis das coisas existentes na mente divina. Se, portanto, se admite que a alma intelectiva conhece
todas as coisas nas razões eternas, há-se de admitir a opinião de Platão, ensinando que toda ciência
deriva das idéias.
Mas, em contrário, diz Agostinho: Se ambos vemos ser verdade o que dizes, e ambos vemos ser verdade
o que digo, onde, pergunto, o vemos? Por certo não o vejo eu em ti, nem tu em mim, mas ambos o
vemos na verdade incomutável superior às nossas mentes. Ora, a verdade incomutável está contida nas
razões eternas. Logo, a alma intelectiva conhece todas as coisas verdadeiras, nas razões eternas.

SOLUÇÃO. ― Como diz Agostinho, os chamados filósofos, se porventura, disseram algumas coisas
verdadeiras e acomodadas à nossa fé, devemos indicá-las a eles, como de possuidores injustos, para o
nosso uso. Pois, as doutrinas dos gentios tem certas ficções simuladas e supersticiosas que cada um de
nós, saindo da sociedade deles, deve evitar. E por isso Agostinho, que fora imbuído das doutrinas dos
Platônicos, tomou o que encontrou de acomodado à verdade, nos ditos deles; porém o que achou
contrário à nossa fé, mudou para melhor. Assim, como já se viu antes, Platão ensinava que as formas
das coisas subsistem por si, separadas da matéria, e lhes chamava idéias, por participação das quais –
dizia – o nosso intelecto conhece todas as coisas; pois, como a matéria corpórea, participando da idéia
de pedra, faz-se pedra, assim o nosso intelecto, por participação da mesma idéia, conhece a pedra. Ora,
é alheio à fé que as formas das coisas subsistam por si, fora delas, sem matéria, como queriam os
Platônicos, dizendo que a vida em si ou a sapiência em si são certas substâncias criadoras, como refere
Dionísio. Por onde, Agostinho ensinou, em lugar dessas idéias que Platão admitia, que as razões de
todas as coisas existem na mente divina, de acordo com as quais todas as coisas são formadas, e
segundo as quais também a alma humana conhece tudo.
Quando, pois, se pergunta se a alma humana conhece tudo nas razões eternas, deve-se responder que
de duplo modo se pode dizer que uma coisa é conhecida em outra. ― De um modo, corno no objeto
conhecido; como quando alguém vê num espelho as coisas cujas imagens nele se refletem. E deste
modo, a alma, no estado da vida presente, não pode ver tudo nas razões eternas; pois esse é o
conhecimento dos bem-aventurados que vêm a Deus e, nEle, tudo. ― De outro modo, diz-se que uma
coisa é conhecida em outra, como no princípio da cognição; como quando dizemos que no sol se vêm as
coisas vistas por meio do sol. E assim, necessário é admitir que a alma humana conhece tudo nas razões
eternas, por cuja participação conhecemos todas as coisas. Pois, o mesmo lume intelectual existente em
nós não é senão uma semelhança participada do lume incriado, no qual estão contidas as razões
eternas. Por onde, diz a Escritura: Muitos dizem: Quem nos patenteará os bens? A cuja pergunta o
Salmista dá a seguinte resposta: Gravada está sobre nós, Senhor, a luz do teu rosto; como se dissesse:
pela sigilação mesma do divino lume em nós todas as coisas são reveladas.
Como, porém, além do lume intelectual, são necessárias, em nós, espécies inteligíveis derivadas das
coisas, para que possamos ter ciência das coisas materiais, por isso, não é só pela participação das
razões eternas que temos ciência destas, como ensinavam os Platônicos, dizendo que só a participação
das idéias basta para a aquisição da ciência. Por onde, diz Agostinho: Pois, pelo fato de os filósofos
terem persuadido, com ensinamentos certíssimos que, pelas razões eternas se fazem todas as coisas
temporais, puderam, por isso, contemplar nessas razões ou delas coligir quantos são os gêneros dos
animais e quais as origens de cada um? Pois, não indagaram todas estas coisas pela história dos Lugares
e dos tempos?
E que Agostinho não era de opinião que todas as coisas são conhecidas nas razões eternas, ou na
verdade incomutável, como se essas próprias razões fossem vistas, é claro pelo que diz em outro passo:
assegura-se, que não toda e qualquer alma racional é idônea para essa visão; a saber, das razões
eternas, mas a que for santa e pura; como são as almas dos bem-aventurados.
E daqui se deduzem as RESPOSTAS ÀS OBJEÇÕES.

## Art. 6 — Se o conhecimento intelectivo é derivado das coisas sensíveis.
(De Verit., q. 10, a. 6; q. 19, a. 1; Qu De Anima, a. 15; Quodl. VIII q. 2, a. 1; Compend. Theol., cap. LXXXI).
O sexto discute-se assim. ― Parece que o conhecimento intelectivo não é derivado das coisas
sensíveis.

1. ― Pois, diz Agostinho, não se deve derivar a plenitude da verdade, dos sentidos do corpo. O que
prova de duplo modo. Primeiro, porque tudo o que o sentido corpóreo atinge, sofre comutação, sem
nenhuma intermissão de tempo; ora, o que não permanece não pode ser percebido. De outro modo,
porque todas as coisas que sentimos pelo corpo, conservamos as imagens, mesmo quando já não
estejam presentes aos sentidos; como se dá no sono ou na loucura. Ora, pelos sentidos, não podemos
discernir se sentimos os próprios sensíveis ou se as falsas imagens deles. Ora, nada pode ser percebido
se não for discernido do que é falso. Donde conclui que não deve derivar a verdade, dos sentidos. Ora,
como o conhecimento intelectual é apreensivo da verdade, não se pode derivá-lo, dos sentidos.

2. Demais. ― Agostinho diz: Não é admissível que o corpo opere alguma coisa no espírito, sendo este
como a matéria sobre a qual opera aquele; pois, de qualquer modo, o ser que opera é mais presente
que o ser do qual jaz alguma coisa. Donde conclui que não é o corpo que opera no espírito a sua própria
imagem, mas é o espírito que a causa em si mesmo. Logo, o conhecimento intelectual não é derivado
dos sentidos.

3. Demais. ― O efeito não se estende para além da virtude da sua causa. Ora, o conhecimento
intelectual, inteligindo o que o sentido não pode perceber, vai além dos sensíveis. Logo, o conhecimento
intelectual não é derivado das coisas sensíveis.
Mas, em contrário, como o prova o Filósofo, o princípio do nosso conhecimento provém do sentido.

SOLUÇÃO. ― Os filósofos se repartiram em três opiniões, no tocante a este assunto. ― Assim,
Demócrito dizia, que toda causa de qualquer conhecimento nosso está somente em que, dos corpos em
que pensamos, provêm imagens que entram em as nossas almas, segundo refere Agostinho. E, como
Aristóteles também refere, Demócrito ensinava que o conhecimento se opera por influições das
imagens. E a razão desta opinião é que tanto Demócrito, como os antigos fisiólogos, não diferençavam o
intelecto, do sentido segundo Aristóteles. E portanto, como o sentido é imutado pelo sensível,
pensavam que todo o nosso conhecimento se faz só pela imutação causada pelos sensíveis. E essa
imutação Demócrito a explicava pelas influições das imagens.
Platão porém, contrariamente, ensinava que o intelecto difere do sentido e é uma virtude imaterial, que
não se serve, para o seu ato, de órgão corpóreo. E como o incorpóreo não pode ser imutado pelo
corpóreo, concluía que o conhecimento intelectual não se faz pela imutação do intelecto, causada pelos
sensíveis, mas sim pela participação das formas inteligíveis separadas, como já se disse. E também dizia
ser o sentido uma virtude que opera por si mesma. Por onde, o próprio sentido, por ser uma virtude
espiritual, não é imutado pelos sensíveis, mas sim os órgãos dos sentidos; por cuja imutação, a alma é,
de certo modo, excitada de maneira a formar em si as espécies dos sensíveis. E parece que Agostinho
alude a esta opinião quando diz: o corpo não sente; mas a alma, por ele, do qual usa, como de núncio,
para formar em si mesma o que é anunciado, de fora. Assim, pois, segundo a opinião de Platão, nem o
conhecimento intelectual procede do sensível, nem este, totalmente, das coisas sensíveis; mas, os
sensíveis excitam a alma sensível para que sinta; e, semelhantemente, os sentidos excitam a alma
intelectiva para que intelija.
Aristóteles, por fim, seguiu a via média. De um lado, admite com Platão, que o intelecto difere do
sentido; mas, de outro ensina que o sentido não tem, sem comunicação do corpo, operação própria; de
modo que sentir não é ato só da alma, mas do conjunto. E o mesmo doutrina em relação a todas as
operações da parte sensitiva. Como, pois, não há inconveniência em que os sensíveis, exteriores à alma,
causem alguma coisa no conjunto, Aristóteles concorda com Demócrito em que as operações da parte
sensitiva são causadas pela impressão dos sensíveis no sentido; não, porém, por influição, como
Demócrito ensinara, mas por uma operação. Pois Demócrito também ensinava que toda ação se dá por
influição dos átomos, como se vê em Aristóteles. Porém, quanto ao intelecto, Aristóteles ensina que
opera sem comunicação do corpo; pois, nada do que é corpóreo pode imprimir-se num ser incorpóreo.
Por onde, para causar a operação intelectual, segundo Aristóteles, não basta só a impressão dos corpos
sensíveis, mas se requer algo de mais nobre, porque o agente é mais nobre que o paciente, como ele
mesmo o diz. Não porém a ponto tal que a operação intelectual Seja causada em nós só pela impressão
das outras coisas superiores, como queria Platão; mas, aquele agente mais nobre e superior, a que
chamou intelecto agente, e de que já tratamos, torna os fantasmas, recebidos dos sentidos, em
inteligíveis atuais, por meio da abstração.
Ora, segundo esta doutrina, a operação intelectual, quanto aos fantasmas, é causada pelo sentido.
Como porém os fantasmas não bastam para imutar o intelecto possível, mas é preciso que se tornem
em inteligíveis atuais, por meio do intelecto agente, não se pode dizer que o conhecimento sensível seja
a causa perfeita e total do conhecimento intelectual, mas, antes e de certo modo, a matéria da causa.

RESPOSTA À PRIMEIRA OBJEÇÃO. — Pelas palavras citadas, Agostinho quer dizer que a verdade não
deve ser buscada totalmente, nos sentidos. Pois, é necessário o lume do intelecto agente para que
conheçamos, imutavelmente, a verdade, nas coisas mutáveis, e discernamos as coisas mesmas, das sua
semelhanças.

RESPOSTA À SEGUNDA. ― Agostinho não se refere ao conhecimento intelectual, mas ao imaginário. E
como, segundo a opinião de Platão, a virtude imaginária tem operação pertencente só à alma,
Agostinho, para mostrar que os corpos não imprimem as suas semelhanças na virtude imaginária, o que
é feito pela própria alma, usou da mesma razão de que usa Aristóteles para provar que o intelecto
agente é algo de separado, a saber, que o agente é mais nobre que o paciente. E sem dúvida, é forçoso,
segundo esta opinião, admitir, na virtude imaginativa, não só uma potência passiva, mas também uma
ativa. Porém, se admitimos, conforme a opinião de Aristóteles, que a operação da virtude imaginativa
pertence ao conjunto, desaparece toda dificuldade; pois, o corpo sensível é mais nobre que o órgão do
animal, enquanto é comparado com este órgão como ser atual para o potencial, ao mesmo modo
porque o colorido em ato se compara com a pupila, que é colorida em potência. ― Mas também se
pode dizer que, embora a primeira imutação da virtude imaginária se realize pelo movimento dos
sensíveis, por ser a fantasia um movimento sensível, contudo, há certa operação da alma, no homem,
que, dividindo e compondo, forma as diversas imagens das coisas, mesmo as que não são recebidas dos
sentidos. E nesta acepção podem-se admitir as palavras de Agostinho.

RESPOSTA À TERCEIRA. ― O conhecimento sensitivo não é a causa total do conhecimento intelectual.
Por onde, não é para admirar se estenda para além daquele.

## Art. 7 — Se o intelecto pode inteligir em ato, pelas espécies inteligíveis, que traz em si mesmo, sem se valer dos fantasmas.
(Infra, q. 89, a. 1; II Sent., dist. XX, q. 2, a. 2, ad 3; III, dist. XXXI, q. 2, a. 4; II Cont. Gent., cap. LXXIII, LXXXI;
De Verit., q. 10, a. 2, ad 7; a. 8, ad 1; q. 19, a. 1; I Cor., cap. XIII, lect. XII; De Mem. et Remin., lect. III).
O Sétimo discute-se assim. ― Parece que o intelecto pode inteligir, em ato, pelas espécies que traz em
si, sem se valer dos fantasmas.

1. ― Pois, o intelecto é atualizado pela espécie inteligível que o informa. Ora, o intelecto atualizado é o
inteligir mesmo. Logo, as espécies inteligíveis bastam para o intelecto se atualizar sem se valer dos
fantasmas.

2. Demais. ― Mais depende a imaginação, do sentido, do que o intelecto, da imaginação. Ora, esta pode
imaginar em ato, estando ausentes os sensíveis. Logo, com maioria de razão, o intelecto pode inteligir
em ato, sem se valer dos fantasmas.

3. Demais. ― Não há fantasmas de seres incorpóreos, porque a imaginação não transcende o tempo e o
contínuo. Se, pois, o nosso intelecto não pudesse inteligir nada em ato, sem se valer dos fantasmas,
resultaria que não poderia inteligir nada de incorpóreo. O que é claramente falso; pois inteligimos a
verdade mesma, Deus e os anjos.
Mas, em contrário, diz o Filósofo que, a alma não intelige nada sem o fantasma.

SOLUÇÃO. ― É impossível ao nosso intelecto, no estado da vida presente, enquanto unido ao corpo,
inteligir qualquer coisa, em ato, sem se valer dos fantasmas. O que ressalta de dois indícios. ― Primeiro,
sendo o intelecto uma virtude que não se serve de órgão corpóreo de nenhum modo seria impedido, no
seu ato, por uma lesão em qualquer desses órgãos, se não fosse necessário, para tal ato, o ato de
alguma potência que se serve do sobredito órgão. Ora, o sentido, a imaginação, e outras virtudes
pertencentes à parte sensitiva servem-se de órgão corpóreo. Por onde, é manifesto que, para o
intelecto inteligir em ato, não só adquirindo ciência nova, mas usando da ciência já adquirida, é
necessário o ato da imaginação e das outras virtudes. Pois, vemos que, impedido o ato da virtude
imaginativa, por lesão do órgão, como nos frenéticos, e, semelhantemente, impedido o ato da virtude
memorativa, como nos letárgicos, o homem fica impedido de inteligir em ato, mesmo aquelas coisas
cuja ciência já possuía. ― Segundo, qualquer pode experimentar em si mesmo que, quando se esforça
por inteligir uma coisa, forma fantasmas, para si, a modo de exemplos, nos quais como que vê o que se
esforça por inteligir. E daí procede também que quando queremos fazer alguém inteligir alguma coisa,
propomos-lhe exemplos pelos quais pode formar, para si, fantasmas, afim de inteligir.
E a razão disto é que a potência cognoscitiva é proporcionada ao cognoscível. Por onde, o intelecto
angélico, totalmente separado do corpo, tem como objeto próprio à substância inteligível separada do
corpo e, nesse inteligível, conhece as coisas materiais. Porém o intelecto humano, unido ao corpo, tem
como objeto próprio a qüididade ou natureza existente na matéria corpórea; e, por tais naturezas, do
conhecimento das coisas visíveis ascende a um certo conhecimento das invisíveis. Ora, é da essência de
tal natureza existir num indivíduo, o qual não existe sem matéria corpórea; como é da essência da
natureza da pedra existir numa determinada pedra; da essência da natureza do cavalo, existir num
determinado cavalo, e assim por diante. Por onde, a natureza da pedra, ou de qualquer coisa material,
não pode ser conhecida completa e verdadeiramente, senão enquanto conhecida como existente num
ser particular. Ora, este nós o apreendemos pelo sentido e pela imaginação. E por isso, é necessário,
para inteligir em ato o seu objeto próprio, que o intelecto se valha dos fantasmas a fim de conhecer a
natureza universal existente no particular. Se, porém o objeto próprio do nosso intelecto fosse a forma
separada, ou se as formas das coisas sensíveis não subsistissem nos particulares, segundo Platão, não
seria necessário que o nosso intelecto sempre, inteligindo, se voltasse para os fantasmas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― As espécies conservadas no intelecto possível neste
existem habitualmente, quando ele não intelige em ato, como já se disse antes. Por onde, para
inteligirmos em ato, não basta à conservação mesma das espécies; mas é necessário que delas nos
sirvamos como convém às coisas das quais são espécies, que são as naturezas existentes nos
particulares.

RESPOSTA À SEGUNDA. ― Mesmo o próprio fantasma é semelhança da coisa particular; por onde, a
imaginação não precisa de nenhuma outra semelhança particular, como precisa o intelecto.

RESPOSTA À TERCEIRA. ― Os seres incorpóreos, dos quais não há fantasmas, são conhecidos por nós
por comparação com os corpos sensíveis, de que existem os fantasmas. Assim, inteligimos a verdade
considerando a coisa sobre a qual procuramos a verdade; ao passo que Deus, como diz Dionísio, o
conhecemos como causa, quer por excesso, quer pela remoção. Porém, as outras substâncias
incorpóreas não podemos conhecê-las, no estado da vida presente, senão pela remoção ou por alguma
comparação com as coisas corpóreas. E portanto, quando de tais substâncias inteligimos alguma coisa,
necessário é que nos valhamos dos fantasmas dos corpos, embora elas mesmas não tenham fantasmas.

## Art. 8 — Se o juízo do intelecto fica impedido, por privação dos sentidos.
(IIª IIae, q. 154, a. 5; III Sent., dist. XV, q. 2, a. 3, qª 2. ad 2; De Verit., q. 12, a. 3, ad 1 sqq.; q. 28, a. 3, ad
6).
O oitavo discute-se assim. ― Parece que o juízo do intelecto não fica impedido, por privação dos
sentidos.

1. ― Pois, o superior não depende do inferior. Ora, o juízo do intelecto é superior aos sentidos. Logo,
não fica impedido pela privação deles.

2. Demais. ― Silogizar é ato do intelecto. Ora, no sono há privação dos sentidos, como se diz em certa
obra; todavia, acontece que alguém, dormindo, silogize. Logo, o juízo do intelecto não fica impedido
pela privação dos sentidos.
Mas, em contrário, não se imputam, como pecado, as coisas contrárias, durante o sono, aos costumes
lícitos. Ora, tal não se daria se o homem, dormindo tivesse o livre uso da razão e do intelecto. Logo, fica
impedido o uso da razão, pela privação dos sentidos.

SOLUÇÃO. ― Como já se disse, o objeto próprio e proporcionado ao nosso intelecto é a natureza da
coisa sensível. Ora, não é possível fazer juízo perfeito de uma coisa sem que se conheça tudo o que
pertence a tal coisa; e, sobretudo, se se ignorar o termo e o fim do juízo. Pois, o Filósofo diz: como o fim
da ciência operativa é a obra, o fim da ciência natural é aquilo que é apreendido sempre e propriamente
pelos sentidos. Assim, o ferreiro não procura o conhecimento da faca, senão por causa da operação, que
o leva a fazer uma determinada faca; e, semelhantemente, o naturalista não procura conhecer a
natureza da pedra e do cavalo, senão para conhecer as razões do que é percebido pelo sentido. Ora, é
claro que o ferreiro não poderia formar um juízo perfeito a respeito da faca, se ignorasse como se faz
uma faca; e, semelhantemente, o naturalista não poderia fazer um juízo perfeito das causas materiais,
se ignorasse os sensíveis. Ora, todas as coisas que inteligimos, no estado da vida presente, nós as
conhecemos por comparação com as coisas sensíveis naturais. Por onde, é impossível haver em nós um
juízo perfeito do intelecto, durante a privação dos sentidos, pelos quais conhecemos as coisas sensíveis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Embora o intelecto seja superior ao sentido, recebe
contudo deste, de certo modo, os seus dados; e os seus objetos primeiros e principais fundam-se nos
sensíveis. Por onde, necessariamente; o juízo do intelecto fica impedido pela privação dos sentidos.

RESPOSTA À SEGUNDA. ― Nos adormecidos, a privação dos sentidos é causada por certas evaporações
e fumosidades que se desprendem, como se diz na obra citada. Por onde, segundo a disposição de tais
evaporações, assim maior ou menor é a privação dos sentidos. E por isso, se for intenso o movimento
dos vapores, haverá privação não só dos sentidos, mas também da imaginação, de modo que nenhum
fantasma aparecerá; como acontece, principalmente quando alguém começa a dormir depois de muito
haver comido e bebido. Se porém, o movimento dos vapores for um pouco remisso, aparecerão os
fantasmas, mas disformes e desordenados, como acontece com os febricitantes. Mas se o movimento
for ainda mais calmo, aparecerão os fantasmas ordenados, como costuma acontecer, sobretudo, no fim
do sono, com os homens sóbrios e dotados de forte imaginação. Se por fim, o movimento dos vapores
for módico, não só a imaginação ficará livre, mas também o próprio sentido comum fica-lo-á, em parte ;
de modo que o homem julga, por vezes, dormindo, que as coisas vistas são sonhos, discernindo, por
assim dizer, entre as coisas e as semelhanças delas. Mas por outro lado, o sentido comum permanece
ligado; e por isso, embora discirna, das coisas, algumas semelhanças, contudo cai sempre em alguns
enganos. Assim pois, do modo pelo qual o sentido e a imaginação ficam livres, no sono, desse mesmo
fica livre o juízo do intelecto, não, porém, totalmente, Por onde, aqueles que, dormindo, silogizam,
quando acordam sempre reconhecemos que, em algo, se enganaram.
