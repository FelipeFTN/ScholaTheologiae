# Questão 28: Das relações divinas.
Em seguida devemos tratar das relações divinas, sobre as quais quatro questões se discutem:

## Art. 1 — Se há em Deus relações reais.
(I Sent., dist. XXVI, q. 2, 2, a. 1; IV Cont, Gent., cap. XIV; De Pot., q. 8, a. Compend. Theol., cap. LIII; in
Ioan., cap. XVI, lect. IV).
O primeiro discute-se assim. — Parece não haver em Deus nenhumas relações reais.

1. — Pois, diz Boécio: Quando usamos dos predicamentos, na predicação divina, tudo o que podemos
predicar inclui-se na substância; e absolutamente não pode ser predicado o que importa relação com
outra coisa. Ora, tudo o que realmente existe em Deus, dele podemos predicar. Logo, em Deus não
existe realmente relação.

2. Demais. — Diz Boécio, no mesmo livro: A mesma relação existente na Trindade entre o Pai e o Filho; e
ambos, com o Espírito Santo, é a que existe entre o idêntico e o idêntico. Ora, esta última é relação
somente de razão, porque toda relação real exige dois extremos reais. Logo, em Deus não são reais, mas
somente de razão.

3. Demais. — A relação de paternidade é uma relação de princípio. Ora, quando se diz — Deus é o
princípio das criaturas — não importa isso nenhuma relação real, mas somente de razão. Logo, nem a
paternidade, em Deus, é relação real, e pela mesma razão, nem as outras relações que se lhe atribuem.

4. Demais. — A geração em Deus funda-se na processão do verbo inteligível. Ora, as relações nascidas
da operação do intelecto são somente de razão. Logo, a paternidade e a filiação que se atribuem a Deus,
pela geração, são relações somente de razão.
Mas, em contrário, o pai é assim chamado por causa da paternidade; e o filho, por causa da filiação. Se,
pois, em Deus não há realmente nem paternidade nem filiação, segue-se que Deus não é realmente Pai
nem Filho, mas somente segundo a noção de inteligência, o que é a heresia sabeliana.

SOLUÇÃO. — Certas relações existem realmente em Deus, o que se evidencia considerando que só nas
coisas relativas a outras encontram-se relações só de razão e não, reais. O que não existe nos outros
gêneros; pois, estes, como a quantidade e a qualidade, na sua noção própria, significam o que é
inerente a um sujeito. Ora, as coisas relativas a outras exprimem, na sua noção própria, só tal relação. E
tal relação está, às vezes, na própria natureza das coisas; como p. ex., nas que por natureza se
coordenam e têm inclinação umas para as outras; e essas relações são necessariamente reais. Assim, p.
ex., o corpo pesado tem inclinação e tendência para o centro e por isso há uma relação entre aquele e
este; e o mesmo se dá em casos semelhantes. Outras vezes, porém, a relação expressa pelas coisas
relativas a outras só existe na apreensão mesma da razão, comparando umas com as outras; e neste
caso a relação é somente de razão, como quando, p. ex., a razão compara o homem com o animal e a
espécie, com o gênero. Mas quando uma coisa procede de um princípio da mesma natureza,
necessariamente ambos, o procedente e o princípio da processão, devem convir na mesma ordem, e
assim é necessário tenham mútuas relações reais. Ora, como em Deus as processões existem na
identidade de natureza, como mostramos, necessariamente serão reais as relações admitidas nas
processões divinas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A relação com alguma coisa de nenhum modo se predica
de Deus, na noção própria do que é relativo a alguma coisa; isto é; enquanto tal noção própria deriva da
comparação com o ser onde existe a relação, mas com outra coisa. Mas nem por isso quis Boécio excluir
de Deus a relação, senão apenas significar que dele se não deve predicar a modo de inerência, segundo
a relação própria de razão; mas antes ao modo do que é relativo a outra coisa.

RESPOSTA À SEGUNDA. — A relação que importa a denominação de idêntico é só de razão, se idêntico
se toma no seu sentido absoluto; pois, tal relação só pode consistir na ordem que a razão descobre
numa coisa para consigo mesma, segundo dois quaisquer dos seus aspectos. É porém diferente o caso,
quando certas coisas se dizem idênticas não pelo número, mas pela natureza do gênero ou da espécie.
Boécio, pois, assimila as relações existentes em Deus à relação de identidade, não em todos os aspectos,
mas só quando tais relações não diversificam a relação de identidade.

RESPOSTA À TERCEIRA. — Procedendo a criatura, de Deus, com diversidade de natureza, Deus está fora
da ordem de todas as criaturas; nem é por natureza que com elas mantém relações. Pois não as produz
por uma necessidade imposta à sua natureza, mas pelo intelecto e pela vontade, como dissemos. E,
portanto, em Deus, não há relação real com as criaturas. Ao contrário, estas mantém com Deus relação
real, pois estão incluídas na ordem divina, e por natureza dependem de Deus. Ora, as processões divinas
existem na mesma natureza. Logo, não há semelhança, na objeção.

RESPOSTA À QUARTA. — As relações oriundas da só operação do intelecto, nas coisas mesmas
inteligíveis, são relações apenas de razão, porque esta a descobre entre duas coisas inteligíveis. Mas as
relações oriundas da operação do intelecto, e que existem entre o verbo intelectualmente procedente e
o princípio donde procede, não são apenas de razão, mas reais; pois, realidade é o próprio intelecto ou a
razão e está realmente para o que procede inteligivelmente, como as coisas corporais, para o que
procede corporalmente. E assim a paternidade e a filiação são relações reais em Deus.

## Art. 2 — Se a relação em Deus é o mesmo que a sua essência.
(I Sent., dist. XXXIII, a. 1; IV Cont. Gent., cap. XIV; De Pot., q. 8, a. 2; Quodl. VI, q. 1; Compend. Theol.,
cap. LIV. LXVI, LXVII).
O segundo discute-se assim. — Parece que em Deus a relação não é o mesmo que a sua essência.

1. — Pois, como diz Agostinho: Nem tudo o que se predica de Deus se predica substancialmente; assim,
algumas predicações são relativas, como a do Pai, relativamente ao Filho; e estas não se predicam
substancialmente. Logo a relação não é a essência divina.

2. Demais. — Diz Agostinho: Tudo o que se predica relativamente tem, além disso, um ser próprio,
como, homem-senhor e homem-servo. Se, pois, há em Deus quaisquer relações, necessariamente nele
haverá algo mais que elas.

3. Demais. — Um ser relativo é referente a outro, como diz Aristóteles. Se, pois, a relação é a própria
essência divina, segue-se que o ser da divina essência consiste em referir-se a outro; o que repugna à
perfeição do ser divino, por excelência absoluto e por si subsistente, como se demonstrou. Logo, a
relação não é a própria essência divina.
Mas, em contrário, tudo o que não é a essência divina é criatura. Ora, a relação realmente convindo a
Deus, e não sendo a essência divina, será necessariamente criatura. Então, não se deve render-lhe um
culto de latria, o que vai contra ao que a Igreja canta num Prefácio: Para que seja adorada, nas Pessoas,
a propriedade, e na majestade, a igualdade.

SOLUÇÃO. — Nesta matéria dizem ter errado Gilberto Porretano, que depois retratou o seu erro no
concílio Remense. Ensinava ele, que as relações em Deus são acrescentadas ou de proveniência
extrínseca.
Ora, para esclarecer o assunto, devemos considerar que dois elementos se hão de levar em conta em
qualquer dos nove gêneros de acidentes. Um é o ser conveniente a cada gênero, enquanto acidente. E
isso é, em geral, em todos, ser inerente a um sujeito, pois o ser do acidente consiste na inerência. O
outro elemento a considerar é a noção própria de cada um dos referidos gêneros. Ora, nos outros
gêneros que não o da relação, como a quantidade e a qualidade, a noção própria do gênero reside na
sua relação com o sujeito; pois, a quantidade se chama medida, e a qualidade, disposição da substância.
Ao contrário, a essência própria da relação não consiste em referir-se ao ser em que está, mas a algo de
exterior.
Se, portanto, considerarmos criaturas as relações como tais, veremos que são acrescentadas, e não, de
proveniência intrínseca. E exprimem uma referência que de certo modo atinge a própria coisa
relacionada, para outra. Se porém considerarmos a relação como acidente, então é inerente ao sujeito e
neste tem o ser acidental.
Mas Gilberto Porretano a considerou somente do primeiro modo. Ora, tudo o que nas coisas criadas
tem ser acidental tem-no substancial quando referido a Deus; pois, nada existe, em Deus, como um
acidente num sujeito, porque tudo o que nele existe é a sua essência. Por onde, considerada a relação
como tendo um ser acidental, nas coisas criadas, que lhes servem de sujeito, ela, realmente existindo
em Deus, tem o ser da essência divina, sempre idêntico a si mesma. Mas quando referente a outro
termo, a relação exprime antes uma referência ao termo do que à essência. Por onde, é claro que a
relação realmente existente em Deus é, realmente, o mesmo que a essência; e só desta difere
racionalmente, porque a relação supõe referência ao termo oposto, o que não está compreendido na
denominação de essência. Donde resulta com clareza que, em Deus, não diferem, mas se identificam, o
ser da relação e o da essência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As palavras de Agostinho não significam que a
paternidade, ou qualquer outra relação essencial existente em Deus, não seja idêntica à divina essência;
mas que não se predica substancialmente como existindo no sujeito a que se atribui; senão,
relativamente. Por isso só dois predicamentos se atribuem a Deus; pois, os outros supõem relação com
o sujeito de que se predicam, tanto quanto ao ser como quanto à noção do gênero próprio. Ora, nada
do que existe em Deus pode, por causa da sua simplicidade, ter relação com o seu sujeito ou com o que
se predica, senão a de identidade.

RESPOSTA À SEGUNDA. — Como nas coisas criadas, assim em Deus, se bem de maneira diferente, as
predicações relativas implicam não somente o caráter de relatividade, mas ainda algo absoluto. Pois, na
criatura difere a realidade do conteúdo do nome relativo; em Deus, porém, não há diferença, mas tudo
é uma mesma realidade, não perfeitamente expressa pelo nome de relação, como compreendida na
significação de tal nome. Pois, já dissemos, quando tratamos dos nomes divinos, que mais contém a
perfeição da divina essência do que pode ser expresso por qualquer nome. Donde se não segue, que em
Deus, alem da relação, haja realmente outro ser, senão apenas quando se considera a significação do
nome.

RESPOSTA À TERCEIRA. — Se a divina perfeição nada mais contivesse do que significa o nome relativo, o
ser divino seria imperfeito, como referente a algum outro; como p. ex., se Deus não contivesse mais do
que significa o nome de sapiência, não seria um ser subsistente. Mas de ser a perfeição da divina
essência maior do que o conteúdo significativo de qualquer nome, não se segue tenha a divina essência
ser imperfeito, pelo fato de o nome relativo, ou qualquer outro, dito de Deus, não implicar sentido de
perfeição; pois, a divina essência em si compreende a perfeição de todos os gêneros, como dissemos.

## Art. 3 — Se as relações atribuídas a Deus real e mutuamente se distinguem.
(I Sent., dist. XXVI, q. 2, a. 2; De Pot., q. 2, a. 5, 6).
O terceiro discute-se assim. — Parece que real e mutuamente não se distinguem as relações
atribuídas a Deus.

1. — Pois, coisas idênticas a uma terceira são idênticas entre si. Ora, toda relação existente em Deus é
idêntica à divina essência. Logo, as relações reais mutuamente se não distinguem.

2. Demais. — Como a paternidade e a filiação se distinguem pelo que significam, da essência divina,
assim também a bondade e a potência. Mas, por tal distinção, não há nenhuma diferença real entre a
bondade e a potência divina. Logo, nem entre a paternidade e a filiação.

3. Demais. — Entre as relações divinas não há distinção real senão quanto à origem. Ora, não parece
que uma relação nasça de outra. Logo, as relações não se distinguem realmente umas das outras.
Mas, em contrário, Boécio: Em Deus, a substância contém a unidade, a relação multiplica a Trindade. Se,
pois, as relações se não distinguissem, real e mutuamente, não haveria em Deus Trindade real, mas só
racional; o que é erro sabeliano.

SOLUÇÃO. — Quando a uma coisa se atribui outra é necessário atribuir àquela tudo o que for da
essência desta; p. ex., a quem se atribuir o ser humano há-se se lhe atribuir o racional. Pois, a essência
da relação está em referir-se uma coisa a outra, pelo que uma se opõe relativamente à outra, como
dissemos. Ora, em Deus havendo relação real, segundo dissemos, há necessariamente oposição real.
Ora, a oposição relativa inclui por natureza a distinção. Donde o haver necessariamente em Deus
distinção real, não por certo quanto à realidade absoluta da essência que é suma unidade e
simplicidade; mas, de natureza relativa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Segundo o Filósofo, o argumento segundo o qual coisas
idênticas a uma terceira são idênticas entre si, colhe em relação a coisas real e racionalmente idênticas,
como túnica e vestuário. E por isso, no mesmo lugar diz, que embora seja o mesmo que o movimento
tanto a ação como a paixão, contudo daí se não segue sejam idênticas; pois, a ação implica relação com
o agente que causa o movimento do móvel; ao passo que a paixão supõe a receptividade. Do mesmo
modo, embora a paternidade e a filiação se identifiquem, por natureza, com divina essência, contudo
uma e outra, pelas suas noções próprias, implicam relações opostas. Por isso mutuamente se
distinguem.

RESPOSTA À SEGUNDA. — Potência e bondade não implicam, por essência, nenhuma oposição. Por isso
a comparação não colhe.

RESPOSTA À TERCEIRA. — Embora as relações propriamente falando, não nasçam nem procedam umas
das outras, contudo consideram-se como opostas, no proceder uma realidade de outra.

## Art. 4 — Se em Deus só há quatro relações reais, a saber, a paternidade, a filiação, a espiração e a processão.
O quarto discute-se assim — Parece não haver em Deus senão quatro relações reais, a saber, a
paternidade, a filiação, a espiração e a processão.

1. — Pois, há a considerar em Deus as relações da inteligência com o inteligido e da vontade com o
objeto querido; que são relações reais, nem se contém nas supra mencionadas. Logo, não há em Deus
somente quatro relações reais.

2. Demais. — Admitem-se relações reais em Deus, quanto à processão inteligível do Verbo. Ora, as
relações inteligíveis se multiplicam ao infinito, como diz Avicena. Logo, há em Deus infinitas relações
reais.

3. Demais. — As idéias existem em Deus abeterno, como se disse. Nem se distinguem entre si senão
relativamente ao seu objeto, segundo foi dito. Logo, em Deus há muitas relações eternas.

4. Demais. — A igualdade, a semelhança e a identidade são relações e em Deus existem abeterno. Logo,
nele existem abeterno mais revelações que as supra mencionadas.
Mas, em contrário, parece que são menos. Pois, segundo o Filósofo, o mesmo caminho de Atenas a
Tebas é o de Tebas a Atenas. Logo, pela mesma razão, idêntica é a relação entre o Pai e o Filho,
chamada paternidade, e a entre o Filho e o Pai, chamada filiação. E assim não há em Deus quatro
relações.

SOLUÇÃO. — Segundo o Filósofo, toda relação se funda ou na quantidade, como a que há entre o duplo
e o meio; ou na ação e na paixão, como a existente entre um agente e o seu ato, entre o senhor e o
escravo, e outras. Ora, em Deus não existindo quantidade, pois, é grande, sem quantidade, como diz
Agostinho, resulta que nele relação real só pode existir fundada na ação. Não porém em ações que
causem em Deus uma processão extrínseca,; pois, as relações de Deus com as criaturas, nele não estão
realmente, como dissemos. Por onde, as relações reais, só se podem admitir em Deus mediante ações
que causem nele uma processão interna e não, externa. Ora, processão dessa natureza só há duas,
como dissemos; uma, fundada na ação do intelecto, que é a processão do Verbo; outra, na da vontade,
que é a do Amor. E, segundo qualquer delas é necessário admitir duas relações opostas: uma, a do que
procede do princípio, e outra, a do próprio princípio. A processão do Verbo se chama geração, na sua
noção própria, pela qual convém aos seres vivos. Ora, a relação do princípio da geração, nos seres vivos
perfeitos, se chama paternidade; e a do que procede do princípio, filiação. Porém a processão do Amor
não tem nome próprio, como dissemos e, portanto, nem as relações que nela se fundam. Chama-se
contudo espiração à relação do princípio desta processão, e à do procedente, processão. Embora esses
dois nomes pertençam às próprias processões ou origens, e não às relações.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nos seres em que diferem o intelecto e o inteligido, a
vontade e o seu objeto, pode haver relação real entre a ciência e a coisa sabida, a vontade e a coisa
querida. Mas em Deus, são absolutamente idênticos o intelecto e o inteligido, pois, inteligindo-se, tudo
intelige; e pela mesma razão nele se identificam a vontade e a coisa querida. Por onde, tais relações em
Deus não são reais, como não são as que existem entre duas identidades. Real é, contudo, a relação com
o Verbo, compreendendo-se este como coisa inteligida; assim, quando inteligimos uma pedra, o que o
intelecto concebe, da coisa inteligida, se chama verbo.

RESPOSTA À SEGUNDA. — As relações inteligíveis multiplicam-se em nos ao infinito, pois por um ato
inteligimos a pedra, e por outro, essa relação, ainda por outro, esta última, e assim ao infinito se
multiplicam os atos de inteligir e, por conseqüência, as relações inteligidas. O que não se dá com Deus,
que por um só ato tudo intelíge.

RESPOSTA À TERCEIRA. — As relações são ideais, como inteligidas por Deus. Donde, da pluralidade
delas se não segue que haja muitas em Deus, mas que Ele conhece muitas.

RESPOSTA À QUARTA. — A igualdade e a semelhança não são em Deus relações reais, mas apenas de
razão, como depois se verá.

RESPOSTA À QUINTA. — Embora o caminho de um termo para outro seja o mesmo que em sentido
inverso, contudo as relações são diferentes. Por isso, daí não se pode concluir que seja a mesma relação
entre o Pai e o Filho e reciprocamente. Mas poderíamos concluir tal, de um meio termo absoluto que
porventura houvesse entre eles.