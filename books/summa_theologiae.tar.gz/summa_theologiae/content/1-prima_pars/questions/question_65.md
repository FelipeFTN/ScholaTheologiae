# Questão 65: Da obra da criação da criatura corpórea.
Depois de tratar da criatura espiritual devemos tratar da corpórea, em cuja produção a Escritura
comemora as três obras seguintes. A obra da criação, quando diz: No princípio criou Deus o céu e a
terra etc.; da distinção, quando diz: Dividiu a luz das trevas e as águas que estavam por baixo do
firmamento das que estavam por cima do firmamento; e a obra da ornamentação, quando diz: Façam-
se uns luzeiros no firmamento, etc. Portanto, devemos tratar, em primeiro lugar, da obra da criação; em
segundo, da da distinção; em terceiro, da da ornamentação.
Sobre o primeiro ponto quatro artigos se discutem:

## Art. 1 — Se a criatura corpórea procede de Deus.
O primeiro discute-se assim. — Parece que não procede de Deus a criatura corpórea.

1. — Pois, diz a escritura: Aprendi que todas as obras que Deus fez perseverarão para sempre. Ora, os
corpos visíveis não duram eternamente, conforme a Escritura: As coisas visíveis são temporais, e as
invisíveis são eternas. Logo, Deus não fez os corpos visíveis.

2. Demais. — Diz a Escritura: E viu Deus todas as coisas que tinha feito, e eram muito boas. Ora, as
criaturas corpóreas são más, e o experimentamos por muitos males que nos causam, por exemplo,
muitas serpentes, o calor do sol e coisas semelhantes; assim, pois, é mau o que é nocivo. Logo, as
criaturas corpóreas não procedem de Deus.

3. Demais. — O que procede de Deus dele não afasta, antes, a ele conduz. Ora, as criaturas corpóreas
afastam de Deus, como diz a Escritura: Não atendendo nós às coisas que se vêem. Logo, as criaturas
corpóreas não procedem de Deus.
Mas, em contrário, diz a Escritura: Qual fez o céu e a terra, o mar, e todas as coisas que neles há.

SOLUÇÃO. — Vários heréticos opinam que os seres visíveis não foram criados por Deus, mas pelo mau
princípio, e tiram argumentos para o seu erro do lugar do Apóstolo: Deus deste século cegou os
entendimentos dos infiéis. — Mas tal opinião é absolutamente inadmissível. Pois, se seres diversos para
algo se unificam é necessário que essa unificação tenha alguma causa, pois não se unificam por si
mesmos. Donde, sempre que se encontra alguma unidade em seres diversos, é necessário recebam
estes de alguma causa una a sua unidade; assim, diversos corpos cálidos recebem do fogo o calor. Ora,
o ser se encontra comumente em todas as coisas, embora diversas. Logo, é forçoso haver um princípio
do ser, em virtude do qual exista tudo o que de qualquer modo existe — seres invisíveis e espirituais ou
visíveis e corporais. — Quanto ao diabo, ele se chama deus do século presente, não pela criação, mas
por lhe servirem os que vivem mundamente, segundo o modo de falar do Apóstolo: O deus deles é o
ventre.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todas as criaturas de deus perduram, de certo modo,
eternamente, ao menos quanto à matéria; pois, as criaturas de nenhum modo se reduzem ao nada,
mesmo as corruptíveis. Porém, quanto mais se aproxima de Deus, que é imóvel, tanto mais imóveis são.
Pois, as criaturas corruptíveis perduram perpetuamente quanto à matéria, transformando-se quanto à
forma substancial. As criaturas incorruptíveis, porém, permanecem, por certo, substancialmente, mas
são mutáveis sob outros aspectos, p. ex., localmente, como os corpos celestes, ou em relação aos
afetos, como as criaturas espirituais. E o dito do Apóstolo — As coisas visíveis são temporais — embora
verdadeiro quanto às coisas em si mesmo consideradas, por estar toda criatura visível sujeita ao tempo,
quanto ao seu ser ou ao seu movimento, todavia o Apóstolo quis aplicá-lo às coisas visíveis consideradas
como prêmios do homem. Pois, dos prêmios do homem, os consistentes em tais coisas são
temporalmente transitórios; ao passo que permanecem eternamente os que consistem nas coisas
invisíveis. Por isso, antes já tinha dito: Produz em nós um peso eterno de glória.

RESPOSTA À SEGUNDA. — A criatura corpórea, por natureza, é boa; mas não é o bem universal, senão
um certo bem particular e restrito; e dessa particularidade e restrição resulta, na criatura, a
contrariedade, em virtude da qual um bem se contrapõe ao outro, embora um e outro, em si mesmo,
seja bem. Donde vem que certos, considerando, nas coisas, não a natureza própria delas, mas a
conveniência deles, julgam absolutamente más as que lhes são nocivas; sem atenderem que o nocivo
para um, sob certo aspecto, é profícuo para outro ou para os mesmos, sob diferente aspecto. O que de
nenhum modo se daria se os corpos fossem maus e nocivos em si mesmos.

RESPOSTA À TERCEIRA. — As criaturas, me si mesmas, não afastam, mas aproximam de Deus, pois as
coisas invisíveis de Deus, compreendendo-se pelas coisas feitas, tornaram-se visíveis, como diz o
Apóstolo. E se afastam de Deus, é por culpa dos que delas usam insipientemente; por onde, diz a
Escritura: as criaturas se fizeram um laço para os pés dos insensatos. Mas o fato mesmo de afastarem de
Deus prova que dele procedem; pois, se afastam de Deus os insipientes, é que os aliciam por algum bem
nelas existentes, bem que têm de Deus.

## Art. 2 — Se a criatura corpórea foi feita para a bondade de Deus.
O segundo discute-se assim. — Parece que a criatura corpórea não foi feita para a bondade de Deus.

1. — Pois diz a Escritura: Criou as coisas para que todas subsistissem. Logo, todas as coisas foram criadas
para o próprio ser delas, e não para a bondade de Deus.

2. Demais. — O bem, exercendo a função de fim, o que, nas coisas, é melhor há-de ser fim do menos
bom. Ora, a criatura espiritual está para a corpórea, como o melhor para o menos bom. Logo, esta é
para aquela e não para a bondade de Deus.

3. Demais. — A justiça dá coisas desiguais a seres desiguais. Ora, Deus é justo. Logo, antes de qualquer
desigualdade criada por Deus, está a que Ele não criou. Ora, esta só pode ser a proveniente do livre
arbítrio. Por onde, toda desigualdade resulta dos diversos movimentos do livre arbítrio. Mas as criaturas
corpóreas não sendo iguais às espirituais, foram feitas para certos movimentos do livre arbítrio e não,
para a bondade de Deus.
Mas, em contrário, diz a Escritura: Tudo fez o Senhor por causa de si mesmo.

SOLUÇÃO. — Orígines ensinou que a criatura corpórea não estava na intenção primeira de Deus o fazê-
la, mas o fez como pena da criatura espiritual, que pecou. Pois, admitia que Deus, no princípio, fez só as
criaturas espirituais, e todas iguais; e essas sendo dotadas de livre arbítrio, converteram-se umas, para
Deus; e segundo a grandeza da conversão, assim lhes coube grau maior ou menor, permanecendo elas
na sua simplicidade; outras, porém, afastaram-se de Deus e foram ligadas a corpos diversos, segundo o
modo da sua aversão de Deus. — Mas, esta opinião é errônea. Primeiro, por contrariar a Escritura que,
após ter narrado a criação de todas as espécies de criaturas corpóreas, acrescenta: E Deus viu que isto
era bom, quase dizendo que cada qual por isso foi feita por que a existência em si mesma é boa. Ao
passo que, segundo a opinião de Orígines, a criatura corpórea foi feita, não porque é bom que ela exista,
mas para que fosse punido o mal de outrem. Segundo, porque resultaria proveniente do acaso a
disposição do mundo corpóreo tal como existe. Pois, se o corpo do sol foi feito tal que conviesse à
punição de algum pecado da criatura espiritual, resultaria a existência de vários sois no mundo, se várias
criaturas espirituais pecaram semelhantemente àquela, para a punição de cujo pecado, Orígines admite
como criado o sol. E o mesmo se daria com os outros seres, o que é absolutamente inadmissível.
Por onde, eliminada esta opinião como errônea, devemos considerar que a totalidade do universo se
constitui de todas as criaturas, como o todo das partes. Se porém quisermos determinar o fim de algum
modo e das suas partes, descobriremos, primeiro, que cada parte é para os seus atos, assim, os olhos,
para ver; segundo, que a parte menos nobre é para a mais nobre, assim, os sentidos para o intelecto, o
pulmão para o coração; terceiro, todas as partes são para a perfeição do todo, assim, a matéria para a
forma, pois as partes são quase a matéria do todo; e por fim, o homem total é para algum fim
extrínseco, a saber, para gozar de Deus. Por onde, também nas partes do universo cada criatura é para o
seu próprio ato e perfeição; segundo, as criaturas menos nobres para as mais nobres, como as criaturas
inferiores do homem são para este; depois, cada criatura é para a perfeição de todo o universo; e por
fim, todo o universo, com as suas partes, se ordena para Deus como para o fim, enquanto nelas, por
uma certa imitação, é representada a bondade divina, para a glória de Deus. Mas, além disso, as
criaturas racionais, de certo modo especial, têm Deus como fim porque podem alcançá-lo pelas suas
operações, conhecendo e amando. E assim é claro que a bondade divina é o fim de todos os seres
corporais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Toda criatura, pelo fato mesmo de existir, representa o
ser divino e a sua bondade. Por onde, o ter Deus dado o ser a todas as coisas, para que existissem, não
exclui que as tivesse criado para a sua bondade.

RESPOSTA À SEGUNDA. — O fim próximo não exclui o fim último. Donde, o ter a criatura corpórea sido
feita, de certo modo, para a espiritual, não exclui que tenha sido feita para a bondade de Deus.

RESPOSTA À TERCEIRA. — A igualdade da justiça se dá na retribuição; pois o justo consiste em dar
coisas iguais a seres iguais. Mas ela não tem lugar na primeira instituição das coisas. Pois, assim como o
artífice coloca pedras no mesmo gênero em partes diversas do edifício, sem injustiça; não por alguma
diversidade precedente delas, mas atendendo à perfeição de todo o edifício, que não existiria se as
pedras nele não ocupassem posições diversas; assim Deus instituiu, desde o princípio, criaturas diversas
e desiguais, para que houvesse perfeição no universo, e isso segundo a sua sapiência, sem injustiça, e
sem nenhuma pressuposição, portanto, de diversidade de méritos.

## Art. 3 — Se a criatura corpórea foi criada por Deus mediante os anjos.
O terceiro discute-se assim. — Parece que a criatura corpórea foi criada por Deus, mediante os anjos.

1. — Pois, assim como todas as coisas são governadas pela divina sabedoria, assim também por esta
todas foram feitas, conforme a Escritura: Todas as coisas fizeste com sabedoria. Mas, ordenar é próprio
do sábio, como diz Aristóteles. Por onde, no governo das coisas, as inferiores são regidas pelas
superiores, numa certa ordem, como diz Agostinho. Logo, também na criação das coisas houve uma
ordem tal, que a criatura corpórea, como inferior, foi criada pela espiritual, como superior.

2. Demais. — A diversidade dos efeitos mostra a das causas, porque a mesma causa sempre produz o
mesmo efeito. Se, pois, todas as criaturas, tanto espirituais como corpóreas fossem criadas
imediatamente por Deus, não haveria entre elas diversidade, nem uma distaria de Deus mais do que
outra. O que é evidentemente falso, pois, como diz o Filósofo, alguns seres são corruptíveis por distarem
muito de Deus.

3. Demais. — Para a produção de um efeito finito não se requer virtude infinita. Ora, todos os corpos
são finitos. Logo, podiam ser produzidos por virtude finita das criaturas espirituais e o foram; pois, em
tais criaturas não difere o ser do poder, sobretudo porque nenhuma dignidade conveniente a um ser,
segundo a sua natureza, lhe é denegada, salvo por sua culpa.
Mas, em contrário, diz a Escritura: No princípio criou Deus o céu e a terra, pelos quais se entende a
criatura corpórea. Logo, esta foi imediatamente criada por Deus.

SOLUÇÃO. — Alguns ensinaram, que as coisas procederam de Deus gradativamente, de modo que dele
imediatamente procedeu a primeira criatura; esta produziu, outra, e assim por diante, até a criatura
corpórea. — Mas esta opinião é inadmissível. Porque a primeira produção da criatura corpórea foi por
via de criação, pela qual é produzida a matéria em si mesma; pois, no vir-a-ser, o imperfeito tem
prioridade sobre o perfeito. Ora, é impossível que alguma coisa seja criada a não ser por Deus.
Para evidenciá-lo devemos considerar que, quanto mais superior é uma causa, tanto mais seres abrange
no causar. Ora, o que nas coisas é substrato é mais comum do que o que as informa e restringe; assim,
ser é mais comum do que viver e viver do que inteligir e a matéria do que a forma. Por tanto, quanto
mais alguma coisa é substrato, tanto mais diretamente procede da causa superior. E logo, o que é o
primeiro de todos os substratos propriamente depende da causalidade da causa suprema e, por
conseqüência, nenhuma causa segunda pode produzir nada, sem que se pressuponha, na coisa
produzida, algo causado pela causa superior. Ora, a criação é a produção de uma coisa na sua substância
total, sem se pressupor nada de incriado ou de criado por outrem. Donde se conclui que ninguém pode
criar nada, salvo Deus, causa primeira. E por isso, Moisés, para mostrar que todos os corpos foram
criados imediatamente por Deus, disse: No princípio criou Deus o céu e a terra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na produção das coisas há uma certa ordem; não, por
certo, de modo a ter uma criatura sido criada por outra, o que é impossível; mas de modo a terem sido,
pela divina sapiência, constituídos diversos graus nas criaturas.

RESPOSTA À SEGUNDA. — O próprio Deus, sem detrimento da sua simplicidade, conhece coisas
diversas, como antes se demonstrou. E portanto, também é a causa pela sua sapiência das diversas
coisas criadas, segundo as diversas coisas conhecidas; assim como o artífice, apreendendo diversas
formas, produz diversos artefatos.

RESPOSTA À TERCEIRA. — A grandeza da virtude do agente não só é medida pela coisa feita, mas
também pelo modo de fazer; pois, uma mesma coisa é diferentemente feita por uma virtude maior e
por uma menor. Ora, produzir um ser finito, sem que nada se lhe pressuponha, sendo próprio, como é,
da virtude infinita, não pode competir a nenhuma criatura.

## Art. 4 — Se as formas dos corpos procedem dos anjos.
O quarto discute-se assim. — Parece que as formas dos corpos procedem dos anjos.

1. — Pois, Boécio diz, que das formas que são sem matéria procedem as que são na matéria. Ora,
aquelas são substâncias espirituais, ao passo que estas são as dos corpos; logo, provém das primeiras.

2. Demais. — O que é participado se reduz ao que é essencialmente. Ora, as substâncias espirituais são,
por essência, formas; ao passo que as criaturas corpóreas participam das formas. Logo, as formas das
coisas corpóreas são derivadas das substâncias espirituais.

3. Demais. — As substâncias espirituais têm maior virtude causal que os corpos celestes. Ora, estes
causam as formas dos seres inferiores, que vemos, e, por isso, são considerados a causa da geração e da
corrupção. Logo, muito mais, as formas existentes na matéria são derivadas das substâncias espirituais.
Mas, em contrário, diz Agostinho, que não se deve pensar que a matéria corporal serve à vontade dos
anjos; mas, antes, à de Deus. Pois, diz-se que a matéria corporal serve à vontade daquele do qual
recebeu a espécie. Logo, as formas corporais não procedem dos anjos, mas de Deus.

SOLUÇÃO. — Certos foram de opinião que todas as formas corporais são derivadas das substâncias
espirituais chamadas anjos. E esta opinião se subdivide em dois ramos. — Assim, Platão ensinava que as
formas subsistentes na matéria corporal são derivadas das subsistentes sem matéria, ao modo de uma
certa participação. Admitia, pois, a subsistência imaterial do homem, e semelhantemente, a do cavalo e
dos outros seres, de cujas substâncias se constituem os correspondentes seres singulares sensíveis; de
modo que permanece na matéria corporal, certa impressão das tais formas separadas, por uma como
assimilação, a que chamavam participação. E ensinavam os Platônicos que a ordem das formas
corresponde à das substâncias separadas. Assim, a substância separada, que é cavalo, é a causa de
todos os cavalos; acima dessa há a vida separada, chamada a vida em si e causa de toda vida; e, por fim,
estava a substância, a que chamavam o ser em si, causa de todo o ser. — Avicena porém e certos outros
ensinavam que as formas das coisas corporais não subsistem, por si, na matéria, mas só no intelecto.
Assim, todas as formas existentes na matéria corporal procedem das existentes no intelecto das
criaturas espirituais, a que uns chamam inteligências e nós chamamos anjos; do mesmo modo que das
formas existentes na mente do artífice procedem as formas dos artefatos. — E esta opinião vem a cair
na de alguns modernos heréticos, que admitem, por certo, um Deus criador acima de tudo, mas dizem
que a matéria corporal foi formada pelo diabo e por ele distribuída em várias espécies.
Ora, todas essas opiniões procedem da mesma raiz. Pois, procuravam a causa das formas, como se
estas, em si mesmas, fossem feitas. — Mas, como Aristóteles o prova, tudo o que é propriamente feito é
composto. Ora, às formas das coisas corruptíveis é natural ora serem, ora não serem, não sendo elas
mesmas as geradas ou corrompidas, senão os seus compostos; e pois, as formas não têm o ser, senão os
compostos; e do modo pelo qual a alguma coisa convém o vir-a-ser, desse mesmo lhe convém o ser. E,
portanto, como o semelhante é feito pelo semelhante, não se deve considerar como causa das formas
corporais nenhuma forma imaterial, mas algum composto; assim um fogo é gerado por outro. De
maneira que, as formas corporais são causadas, não de alguma forma imaterial, mas por ser a matéria
quase reduzida da potência ao ato, por algum agente composto. Mas, como o agente composto, que é
corpo, é movido pela substância espiritual criada, conforme diz Agostinho, segue-se ulteriormente, que
também as formas corporais derivam das substâncias espirituais; não que estas infundam formas, senão
que movem para elas. Finalmente, se reduzem a Deus, como à causa primeira, mesmo as espécies do
intelecto angélico, que são umas como razões seminais das formas corpóreas.
Ora, na criação primeira da criatura corporal não há a considerar nenhuma transmutação da potência
para o ato. Por onde, as formas corporais que os corpos, na primeira criação, tiveram, foram
imediatamente produzidas por Deus, a cuja única vontade a matéria obedece como à causa própria. Por
isso, para o significar, Moisés antes de narrar as obras de cada um dos dias, diz: — Deus disse: faça-se
isto ou aquilo; querendo exprimir que a formação das coisas foi feita pelo Verbo de Deus, do qual,
conforme Agostinho, procede toda forma, toda união e concórdia das partes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Boécio entende por formas sem matéria as razões das
coisas existentes na mente divina, como também diz o Apóstolo: Pela fé reconhecemos que os séculos
foram formados pela palavra de Deus; de sorte que o visível fosse feito do invisível. Se, porém, por
formas sem matéria entende os anjos, deve-se concluir que deles vêm as formas existentes na matéria,
não por influxo, mas por movimento.

RESPOSTA À SEGUNDA. — As formas participadas pela matéria reduzem-se, não a certas formas da
mesma natureza, por si subsistentes, como queriam os Platônicos, mas às formas inteligíveis ou do
intelecto angélico, donde procedem pelo movimento; ou, ulteriormente, das razões do intelecto divino,
pelas quais também as sementes das formas são infundidas nas coisas criadas, de modo que possam ser
reduzidas ao ato , pelo movimento.

RESPOSTA À TERCEIRA. — Os corpos celestes causam as formas nos seres inferiores deste mundo, não
influindo, mas movendo.