# Questão 91: Da produção do corpo do primeiro homem.
Em seguida devemos tratar da produção do corpo do primeiro homem.
E, sobre esta questão, quatro artigos se discutem:

## Art. 1 — Se o corpo do primeiro homem foi feito do limo da terra.
O primeiro discute–se assim. – Parece que o corpo do primeiro homem não foi feito do limo da terra.

1. – Pois, é necessário maior poder para fazer alguma cousa, do nada, do que de outra cousa: porque o
não ser dista mais, do ato, do que o ser em potência. Ora, como o homem é a mais digna das criaturas
inferiores, convinha que o poder de Deus se manifestasse, em máximo grau, na produção do corpo do
mesmo. Logo, não devia ter sido feito do limo da terra, mas do nada.

2. Demais. – Os corpos celestes são mais nobres que os terrestres. Ora, o corpo humano, aperfeiçoado
por uma forma nobilíssima, qual é a alma racional, tem a máxima nobreza. Logo, não devia ter sido feito
da matéria terrestre, mas. antes. da celeste.

3. Demais. – O fogo e o ar são corpos mais nobres que a terra e a água; o que se vê, pela subtileza deles,
Ora, como o corpo humano é digníssimo, devia ter sido feito, antes, do fogo e do ai, do que do limo da
terra.

4. Demais. – O corpo humano é composto dos quatro elementos. Logo, não é feito do limo da terra, mas
de todos os elementos.
Mas, em contrário, diz a Escritura: Formou pois o Senhor Deus ao homem do barro da terra.

SOLUÇÃO. – Como Deus é perfeito, deu a perfeição às suas obras, conforme o modo de cada uma,
segundo aquilo da Escritura: das obras de Deus são perfeitas, Ora, Ele, em si mesmo, é perfeito, porque
preencerra em si todas as causas, não a modo de composição, mas simples e unificadamente, como diz
Dionísio, do modo pelo qual os diversos efeitos preexistem na causa, segundo a virtude una desta. Esta
perfeição, por sua vez, deriva para os anjos, enquanto no conhecimento deles estão todas as coisas
produzidas por Deus, em a natureza, por formas diversas. Ao passo que tal perfeição deriva, para o
homem, de modo inferior. Pois, ele não tem conhecimento natural de todas as coisas naturais; mas é
composto, de certo modo, de todas as coisas. Assim, do género das substâncias espirituais, tem, a alma
racional; da semelhança dos corpos celestes, o afastamento dos contrários, pela uniformidade máxima
da compleição; e os elementos os tem substancialmente. De modo que os elementos superiores a
saber; o fogo e o ar, predominam, nele, pela virtude; porque a vida consiste, principalmente, na calidez,
produzida pelo fogo, e na umidade, pelo ar. Ao passo que os elementos inferiores nele abundam
substancialmente. Pois, de outro modo, não poderia haver a homogeneidade na mistão, se os
elementos inferiores, de menor virtude, não abundassem no homem, quantitativamente. E, por isso,
porque se chama limo à terra misturada com a água, diz–se que o corpo do homem foi formado do limo
da terra. Por onde, o homem é chamado mundo menor, por nele se encontrarem, de certo modo, todas
as criaturas do mundo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A virtude de Deus criador manifestou–se no corpo
humano, por ser a matéria deste produzida por criação. Ora, era necessário fosse esse corpo produzido
da matéria dos quatro elementos, para que o homem tivesse conveniência com os corpos inferiores,
sendo um como meio entre as substâncias espirituais e as corpóreas.

RESPOSTA À SEGUNDA. – Embora o corpo celeste seja, em si, mais nobre que o terrestre, contudo
convém menos com o ato da alma racional. Pois, esta adquire, de certo modo, o conhecimento da
verdade, pelos sentidos, cujos órgãos não podem ser formados do corpo celeste, que é impassível. Nem
é verdadeira a opinião de certos, que, admitindo a união da alma com o corpo, mediante uma certa luz,
dizem advir algo, materialmente, da quinta essência, à composição do corpo humano. Pois, primeiro,
estão em falso quando consideram a luz como corpo. Segundo, é impossível, por causa da
impassibilidade do corpo celeste, que algo da quinta essência ou do corpo celeste seja dividido ou
misturado com os elementos. Por onde, não entra, na composição dos corpos mistos, senão por efeito
da sua virtude.

RESPOSTA À TERCEIRA. – Se o fogo e o ar, que têm maior poder de ação, abundassem na composição
do corpo humano, mesmo quantitativamente, atrairiam completamente para si tudo o mais; e não
poderia dar–se a homogeneidade da mistura, necessária, na composição do homem, para a perfeição do
sentido do tacto, fundamento dos outros sentidos. Pois, é mister que o órgão de cada sentido não
contenha, em ato, mas só em potência, os contrários, que o sentido percebe. E isso de modo que
careça, absolutamente, de qualquer gênero de contrários, como a pupila carece da cor, para ser
potencial em relação a todas as cores; o que não seria possível no órgão do tacto, que é composto dos
elementos, cujas qualidades percebe. Ou de modo que o órgão seja médio, entre os contrários, como
necessariamente há de acontecer com o tato; pois, o médio é, de certo modo, potencial em relação aos
extremos.

RESPOSTA À QUARTA. – O limo da terra contém terra e água, que conglutina as partes daquela. Porém,
dos outros elementos a Escritura não fez menção. Quer, porque quantitativamente abundam menos, no
corpo do homem, como já se disse; quer também porque, na produção total das coisas, a Escritura,
composta para um povo de rudes, não devia mencionar o fogo e a água, não percebidos pelo sentido
deles.

## Art. 2 — Se o corpo humano foi produzido imediatamente por Deus.
O segundo discute–se assim. – Parece que o corpo humano não foi produzido imediatamente por
Deus.

1. – Pois, como diz Agostinho, os seres corpóreos são dispostos por Deus, por meio da criatura angélica.
Ora, o corpo humano foi formado da matéria corpórea, como já se disse. Logo, tinha que ser produzido
mediante os anjos e não imediatamente por Deus.

2. Demais. – O que é susceptível de ser feito pelo poder criado, não é necessário seja produzido
imediatamente por Deus. Ora, o corpo humano pode ser produzido, pela virtude criada, do corpo
celeste; assim como certos animais são gerados da putrefacção, pela virtude ativa do corpo celeste. E
Albumazar diz, que nos lugares onde muito abunda o calor ou o frio, os homens não se geram, senão
somente nos lugares temperados. Logo, não era necessário que o corpo humano fosse formado
imediatamente por Deus.

3. Demais. – Nada se faz da matéria corpórea, senão por alguma transmutação material. Ora, toda
transmutação corpórea é causada pelo movimento do corpo celeste, que é o primeiro dos movidos.
Mas, como o corpo humano é produzido da matéria corpórea, resulta que, para a formação dele, o
corpo celeste contribuiu com alguma operação.

4. Demais. – Agostinho diz que, nas obras dos seis dias, o homem foi feito, corporalmente, nas suas
razões causais, que Deus inseriu na criatura corpórea só depois é que foi formado em ato. Ora, o que
preexiste na criatura corpórea, pelas razões causais, pode ser produzido por uma virtude corpórea.
Logo, o corpo humano foi produzido por alguma virtude criada, e não imediatamente por Deus.
Mas, em contrário, diz a Escritura: Deus criou o homem da ferra.

SOLUÇÃO. – A formação do corpo humano, no princípio, não podia ter sido por nenhuma virtude criada,
mas, imediatamente, por Deus. Se bem ensinassem alguns, que as formas existentes na matéria
corpórea são derivadas de certas formas imateriais.
Mas o Filósofo repele essa opinião, porque não convém às formas serem feitas, em si mesmas, mas ao
composto, como já se expôs antes. E como, necessariamente, o agente há de ser semelhante ao seu
efeito, não convém à forma pura e imaterial produzir uma forma material, que não é produzida senão
porque o composto o é. E portanto, é forçoso, que a forma existente na matéria seja a causa de outra
do mesmo modo existente, pois, o composto é gerado pelo composto. Porém Deus, embora
absolutamente imaterial, é o único que, pela sua virtude, pode produzir a matéria, criando. Por onde, só
dele é próprio produzir a forma na matéria, sem nenhum adminículo de qualquer forma material
precedente. E por isso os anjos não podem transmutar os corpos, no atinente a qualquer forma, sem a
cooperação de sementes, conforme Agostinho. Ora, como nunca foi constituído nenhum corpo humano,
cuja virtude formasse, via de geração, outro, especificamente semelhante, necessariamente o primeiro
corpo humano foi formado imediatamente por Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora os anjos sirvam a Deus em certos ministérios,
relativamente aos corpos, há porém determinadas operações que Deus exerce sobre a criatura
corpórea, que os anjos não podem realizar de nenhum modo, como, ressuscitar os mortos e dar vista
aos cegos. Ora, por esse poder é que Deus também formou o corpo do primeiro homem, do limo da
terra. Contudo, podia ter–se dado que os anjos exercessem algum ministério, na formação do corpo do
primeiro homem, assim como exercerão, na ressurreição última, o de coligir as cinzas.

RESPOSTA À SEGUNDA. – Os animais perfeitos, gerados de semente, não podem ser produzidos só pela
virtude do corpo celeste, como imagina Avicena; embora, para a geração natural deles coopere a
virtude desse corpo, conforme o dito do Filósofo, segundo o qual o homem e o sol geram o homem, da
matéria. E daí vem o ser necessário uma região temperada para a geração do homem e dos outros
animais perfeitos. Ao passo que basta a virtude dos corpos celestes para gerar, da matéria já disposta,
certos animais imperfeitos. Pois, é manifesto–que para a produção de um ser perfeito é necessário mais
que para a de um imperfeito.

RESPOSTA À TERCEIRA. – O movimento do céu é a causa das transmutações naturais; não porém das
que se fazem fora da ordem da natureza e pela só virtude divina, como, a ressurreição dos mortos e a
visão dos cegos. Ora, a isso é semelhante a formação do homem, do limo da terra.

RESPOSTA À QUARTA. – Pelas razões causais dizemos, de duplo modo, que al juma cousa preexiste nas
criaturas. De um modo, pela potência ativa e passiva, de maneira que essa causa não só possa ser feita
da matéria preexistente, mas também, que alguma criatura preexistente possa fazê–las. De outro modo,
só pela potência passiva, isto é, que possa ser feita da matéria preexistente, por Deus. E, segundo
Agostinho, deste modo é que o corpo do homem, pelas razões, causais, preexistia nas obras produzidas.

## Art. 3 — Se o corpo do homem teve disposição conveniente.
O terceiro discute–se assim. – Parece que o corpo do homem não teve disposição conveniente.

1. – Sendo o homem o mais nobre dos animais, o seu corpo deveria ter sido disposto, do melhor modo,
para a vida própria ao animal, a saber, a dos sentidos e a do movimento. Ora, há certos animais de
sentidos mais agudos que os do homem, e de movimento mais veloz; assim, os cães têm melhor odor e
as aves movem–se mais velozmente. Logo, o corpo do homem não está convenientemente disposto.

2. Demais. – Perfeito é o ser ao qual nada falta. Ora, falham ao corpo humano mais atributos que aos
corpos cios outros animais, que têm tegumentos e armas naturais, para se protegerem, coisas que o
homem não tem. Logo, o corpo humano está imperfeitissimamente disposto.

3. Demais. – O homem dista mais das plantas do que dos brutos. Ora, as plantas têm estatura ereta e os
brutos, inclinada. Logo, o homem não devia ter estatura ereta.
Mas, em contrário, diz a Escritura: Deus criou o homem reto.

SOLUÇÃO. – Todos os seres naturais foram produzidos pela arte divina; e por isso são de certo modo
artificiados pelo próprio Deus. Ora, qualquer artífice procura dar a melhor disposição à sua obra, não
absolutamente, mas por comparação com o fim. E se a tal disposição acompanhar algum defeito, disso
não cura o artífice. Assim, o artífice que faz uma serra para cortar, fá–la de ferro, para ser capaz do
corte; e não pensa em fazê–la de vidro, que é matéria mais bela, pois tal beleza seria impedimento para
o fim. Assim Deus deu a cada ser natural a melhor disposição, não, certo, absolutamente, mas conforme
a ordenação ao fim. E é o que diz o Filósofo: E por ser mais digno assim ; não, certo, absolutamente, mas
para a substância de cada ser. Ora o fim próximo do corpo humano é a alma racional e as operações
dela; pois, a matéria é para a forma e os instrumentos, para as ações do agente. Portanto, digo que
Deus instituiu o corpo humano com ótima disposição, segundo a conveniência para determinada forma
e determinadas operações. E se se manifesta algum defeito na disposição de tal corpo, devemos
considerar que esse defeito resulta da necessidade da matéria, em relação às coisas necessárias, no
corpo, para haver a proporção devida entre a alma e as suas operações.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O tato, fundamento dos outros sentidos, é mais perfeito
no homem do que em qualquer outro animal. E, por isso, era necessário que o homem tivesse uma
compleição mais homogênea que todos os outros animais. Pois precede a todos quanto às virtudes
sensitivas inferiores, como resulta do que já foi dito. E, por uma certa necessidade é inferior aos outros
animais, quanto a alguns sentidos exteriores. Assim, o homem tem um olfato péssimo relativamente ao
de todos os animais. Por isso era forçoso, que em relação ao seu corpo, tivesse cérebro melhor que o
deles todos. Quer para mais livremente realizar com perfeição as operações das virtudes sensitivas
internas, necessárias à operação do intelecto, como já se disse antes; quer também para a frigidez do
cérebro mitigar o calor do coração, que necessariamente deve abundar no homem, para ter estatura
ereta. Ora, o desenvolvimento do cérebro impede, pela sua umidade, o de– olfato, que exige a secura.
Semelhantemente, pode–se descobrir a razão por que certos animais têm visão mais aguda e audição
mais subtil do que o homem, no impeçilho oposto a esses sentidos, que resulta necessariamente, o
homem, da perfeita homogeneidade de compleição. E a mesma razão explica por que certos animais
são mais velozes que o homem: é que a homogeneidade da compleição humana repugna a essa
excelência na velocidade.

RESPOSTA À SEGUNDA. – Os chifres e as unhas, armas dos animais: a espessura da pele, a multidão dos
pelos e das penas, que lhes são os tegumentos atestam a abundância do elemento terrestre,
repugnante à homogeneidade e à delicadeza da compleição humana por isso tais atributos não
convinham ao homem. Mas em lugar deles, tem a razão e as mãos, com as quais pode preparar para si,
de infinitos modos, armas, cobertas e outras coisas necessárias à vida; e por isso, às mãos o Filósofo lhes
chama órgão dos órgãos. E tal constituição convinha mais à criatura racional, capaz de infinitas
concepções, para que tivesse a faculdade de preparar para si infinitos instrumentos.

RESPOSTA À TERCEIRA. – Ter estatura ereta era conveniente ao homem, por quatro razões. – Primeira,
porque os sentidos lhe foram dados não só para buscar o necessário à vida, como fazem os outros
animais, mas também para conhecer. Por onde, ao passo que os outros animais não se deleitam com os
sensíveis, senão no tocante ao alimento e à geração, o homem e só ele se compraz com a beleza dos
sensíveis em si mesma. Por isso, corno precipuamente no rosto é que os sentidos se manifestam, os
outros animais têm o focinho inclinado para a terra, como para buscarem a comida e proverem–se de
alimento. Ao contrário, o homem traz a fronte ereta, de modo que, pelos sentidos, e principalmente
pela vista, que é o mais subtil e descobre mais diferenças nas coisas, possa, livremente e em toda parte,
conhecer os objetos sensíveis, celestes e terrestres, e coligir de todos a verdade inteligível. – Segunda,
para que as virtudes interiores exerçam mais livremente as suas operações por não ficar o cérebro,
sede, de certo modo, das suas perfeições, deprimido, mas sobranceiro a todas as partes do corpo. –
Terceira, porque seria forçoso, se o homem trouxesse a postura inclinada, usar das mãos como de patas
anteriores isto e assim cessar–lhes–ia a utilidade para exercerem completamente as suas diversas
atividades. – Quarta, porque, se tivesse a postura inclinada e usasse das mãos como de patas anteriores,
teria necessariamente que tornar o alimento com a boca. E então têIa–ia oblonga, os lábios rígidos e
grossos, a língua também áspera para não ser ferida pelos contatos externos, como se dá com os outros
animais. Ora, tal disposição impediria, de todo, a locução, atividade própria da razão. – E contudo, tendo
a estatura ereta, o homem dista maximamente das plantas. Pois traz a sua parte superior, que é a
cabeça, dirigida para a parte superior do mundo; e a inferior, para a parte inferior do mesmo: e assim
está otimamente disposto, relativamente à disposição do todo. Ao contrário, as plantas têm a parte
superior dirigida para a parte inferior do mundo, pois as raízes são comparáveis ao rosto; enquanto que
a parte inferior delas se dirige para a parte superior do mundo. Por fim, os brutos oferecem uma posição
média; pois a parte superior do animal é a receptora do alimento; e a inferior, a emissora do supérfluo.

## Art. 4 — Se na Escritura está convenientemente descrita a produção do corpo humano.
O quarto discute–se assim. – Parece que na Escritura está inconvenientemente descrita a produção do
corpo humano.

1. – Pois assim como o corpo humano foi feito por Deus, assim também, as outras obras dos seis dias.
Mas, nessas outras, se diz: Disse Deus: Faça–se a luz e foi feita a luz. Logo, semelhantemente, também
se devia–dizer, da produção do homem.

2. Demais. – O corpo humano foi feito imediatamente por Deus, como antes ficou estabelecido. Logo,
está dito inconvenientemente: Façamos o homem.

3. Demais. – A forma do corpo humano é a alma mesma, que é o espiráculo da vida. Portanto, depois de
se ter dito: Formou o Senhor Deus ao homem do barro da ferra, acrescentou–se inconvenientemente: E
inspirou no seu rosto um sopro de vida.

4. Demais. – A alma, espiráculo da vida, está em todo o corpo e, principalmente, no coração. Logo, não
se devia dizer que: E inspirou no seu rosto um sopro de vida.

5. Demais. – Os sexos masculino e feminino são a tributos do corpo; ao passo que a alma é a imagem de
Deus. Ora, a alma, segundo Agostinho, foi feita antes do corpo. Logo, depois de se ter dito: Criou Deus o
homem à sua imagem, inconvenientemente se acrescentou Macho e fêmea os criou.
Em contrário está a autoridade da Escritura.

RESPOSTA À PRIMEIRA OBJEÇÃO. – Como diz Agostinho, o homem tem preeminência sobre os outros
seres, porque foi feito à imagem de Deus, e não, porque o próprio Deus tivesse feito só a ele e não aos
outros. Pois, está escrito: Os céus são obras das tuas mãos, e: As suas mãos formaram a terra árida. Mas
a Escritura usa, na produção do homem, de especial modo de falar, para mostrar que os outros seres
foram feitos por causa do homem. Pois, o que queremos principalmente isso costumamos fazer com
maior deliberação e esforço.

RESPOSTA À SEGUNDA. – Não se deve entender que Deus disse aos anjos – Façamos o homem – como
alguns perversamente entenderam. Mas essas palavras significam a pluralidade das Pessoas divinas,
cuja Imagem se acha mais expressivamente no homem.

RESPOSTA À TERCEIRA. – Alguns entenderam que o corpo do homem foi, primeiro, formado no tempo
e, depois, Deus lhe infundiu a alma nele já formado. – Mas é contra a razão da perfeição da primeira
instituição das coisas, que Deus tivesse feito o corpo sem a alma ou esta sem aquele; pois ambos fazem
parte da natureza humana. E tal seria ainda mais inconveniente, do corpo, que depende da alma, do que
inversamente. – E então, para excluir essa opinião, outros ensinavam que quando se diz: Criou Deus o
homem, quer se significar a produção do corpo simultaneamente com a alma; e o que se acrescenta: E
inspirou no seu rosto, um sopro de vida, entende–se do Espírito Santo, assim como o Senhor o insuflou
nos Apóstolos, conforme o dito: Recebei o Espírito Santo. Mas tal exposição fica excluída, como diz
Agostinho, pelas palavras da Escritura. Pois ela ao que antes disse acrescenta: E foi jeito o homem em
alma vivente; o que o Apóstolo refere, não à vida espiritual, mas à animal. Logo, por espiráculo da vida
entende–se a alma; de modo que quando se diz: Inspirou no sete rosto, um sopro de vida, isso é uma
como exposição do que se dissera antes; pois, a alma é a forma do corpo.

RESPOSTA À QUARTA. – As operações da vida manifestam–se sobretudo na face do homem, por meio
dos sentidos aí existentes; e por isso a Escritura diz que na face do homem foi inspirado o espiráculo da
vida.

RESPOSTA À QUINTA. – Segundo Agostinho, todas as obras dos seis dias foram feitas simultaneamente.
Por isso, a alma cio primeiro homem, que considera como produzida simultaneamente com os anjos,
não a considera feita antes do sexto dia; mas, nesse mesmo sexto dia, diz que foi feita em ato a alma do
primeiro homem, e o corpo do mesmo, pelas razões causais. Porém outros Doutores dizem que tanto a
alma como o corpo do homem foram feitos em ato, no sexto dia.