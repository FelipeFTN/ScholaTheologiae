# Questão 22: Da providência de Deus
Depois de havermos tratado do que pertence absolutamente à vontade, devemos passar a tratar do que
concerne simultaneamente ao intelecto e a vontade, a saber: da providência, a respeito de todos os
seres; da predestinação, da reprovação e do que delas depende, em relação especialmente ao homem,
em ordem à salvação eterna. Pois, a ciência moral, após tratar das virtudes morais, trata da prudência, à
qual pertence à providência.
Ora, sobre a providência de Deus discutem-se quatro artigos:

## Art. 1 — Se a providência convém a Deus.
(I Sent., dist. XXXIX, q. 2; De Verit., q. 5, a. 1, 2).
O primeiro discute-se assim. — Parece que a providência não convém a Deus.

1. — Pois, segundo Túlio, a providência faz parte da prudência. Ora, o papel da prudência sendo
aconselhar o bem, como diz o Filósofo, não pode convir a Deus, que, não tendo dúvidas, não precisa de
conselho. Logo, a Deus não convém a providência.

2. Demais. — Tudo em Deus é eterno. Ora, a providência concernente aos seres não eternos, como diz
Damasceno, não é eterna. Logo, em Deus não há providência.

3. Demais. — Nenhuma composição há em Deus. Ora, a providência, incluindo em si a vontade e o
intelecto, parece ser composta. Logo, em Deus não há providência.
Mas, em contrário, a Escritura (Sb 15, 3): Mas a tua providência, ó Pai, é a que governa todas as coisas.

SOLUÇÃO. — É necessário admitir a providência em Deus. Pois, todo bem existente nas coisas foi criado
por Deus, como demonstramos. Ora, o bem existe, não só na substância delas, mas ainda, no
ordenarem-se para o fim e, sobretudo, para o fim último, que é a bondade divina, segundo
estabelecemos. Logo, o bem da ordem, existente nas criaturas, foi criado por Deus. Mas, Deus é a causa
dos seres, pelo seu intelecto; portanto, é necessário, como vimos, que a razão de qualquer efeito seu
nele preexista. Por onde, também necessàriamente a razão da ordem das coisas para o fim há de
preexistir na mente divina. Ora, a razão de se ordenarem os seres para um fim se chama propriamente
providência. Pois, é parte principal da prudência, à qual se ordenam duas outras partes — a memória
das causas passadas e a inteligência das presentes; porque, lembrando o passado e inteligindo o
presente é que conjecturamos sobre a providência do futuro. Ora, é próprio da prudência, segundo o
Filósofo, ordenar as causas para um fim. Quer em relação a nós mesmos chamando-se então prudente o
homem que ordena bem os seus atos para o fim da sua vida; quer em relação a outros que nos estão
sujeitos, na família, na cidade ou na república. E, nesta acepção, a Escritura diz (Mt 24, 25): O servo fiel e
prudente a quem seu senhor pôs sobre sua família. Ora, neste sentido, a prudência ou providência pode
convir a Deus. Pois, Deus sendo o fim último, nada tem que se ordena a outro fim. Por isso, chamamos
providência divina à razão da ordem dos seres para um fim. Donde o dizer Boécio, que a providência é a
mesma razão divina própria ao sumo de todos os chefes, a qual tudo dispõe. Ora, disposição tanto pode
chamar-se à razão da ordem dos seres para um fim, como à da ordem das partes no todo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Segundo o Filósofo, a prudência propriamente ordena o
que a eubulia aconselha retamente, e a sínese retamente julga. Donde, embora o conselho, sendo uma
indagação sobre o que é duvidoso, não convenha a Deus, contudo, cabe-lhe preceituar sobre as coisas
que devem ordenar-se para um fim e das quais tem a razão reta, conforme aquilo da Escritura (Sl 148,
6): Preceito pôs e não se quebrantará. E, deste modo convém a Deus, essencialmente, a prudência e a
providência. Entretanto, também podemos dizer, que a própria razão das coisas a serem feitas se
chama, em Deus, conselho; não por causa da indagação, mas, pela retidão do conhecimento, à qual
chegam os que tomam conselho, perquirindo. Daí o dito da Escritura (Ef 1, 11): Aquele que obra todas as
coisas segundo o conselho da sua vontade.

RESPOSTA À SEGUNDA. — Ao cuidado da providência duas coisas pertencem: a razão da ordem, que se
chama providência, e a disposição e execução dela, que se chama governo. Aquela é eterna, esta,
temporal.

RESPOSTA À TERCEIRA. — A providência pertence ao intelecto, mas pressupõe a vontade do fim. Pois
ninguém ordena o que deve fazer, em vista de um fim, sem conhecê-la. Por isso, a prudência pressupõe
as virtudes morais, pelas quais o apetite busca o bem. E, contudo, se a providência concernisse
igualmente à vontade e ao intelecto divinos, seria sem nenhum detrimento da divina simplicidade,
porque, em Deus, vontade e intelecto são idênticos, como vimos.

## Art. 2 — Se todos os seres estão sujeitos à providência divina.
(Infra, q. 102, a. 5; I Sent., dist. XXXIX, q. 2, a. 2; III Cont. Gent., cap. I, LXIV, LXXV, XCIV; De Verit., q. 5, a.
2" sqq.; Compend. Theol., cap. CXXIII. CXXX, CXXXII; Opusc. XV. De Angelis, cap. XIII, XIV, XV; De Divin.
Nom. cap. III. lect. I).
O segundo discute-se assim. — Parece que nem todos os seres estão sujeitos à providência divina.

1. — Pois, nenhum objeto da providência é fortuito. Logo, se Deus providencia sobre tudo, nada será
fortuito, não havendo assim acaso e sorte; o que vai contra a opinião geral.

2. Demais. — Todo provedor sábio procura, na medida do possível, excluir o defeito e o mal das coisas
que administra. Ora, vemos que existem muitos males nas coisas. Logo, Deus, ou não os pode impedir, e
não é onipotente, ou não cura de todos os seres.

3. Demais. — O que se realiza necessariamente não requer providência ou prudência. Por isso,
conforme o Filósofo, a prudência é a razão reta acerca das coisas contingentes, que supõe conselho e
eleição. Por onde, muitas coisas, realizando-se necessariamente, nem todas dependem portanto da
providência.

4. Demais. — Quem depende de si próprio não depende da providência de nenhum governador. Ora, os
homens fê-los Deus dependerem de si próprios, conforme a Escritura (Ecle 15, 14): Deus criou o homem
desde o princípio, e o deixou na mão do seu conselho. E especialmente os maus, segundo ainda o
mesmo (Sl 80, 13): Eos abandonou segundo os desejos do seu coração. Logo, nem todos os seres estão
submetidos à divina providência.

5. Demais. — Diz o Apóstolo (1 Cor 9,9): Acaso tem Deus cuidado dos bois? Ora, pela mesma razão não o
tem das outras criaturas irracionais. Logo, nem todos os seres estão submetidos à divina providência.
Mas, em contrário, diz a Escritura, da divina sapiência (Sb 8, 1): Ela, pois, toca desde uma extremidade
até a outra com fortaleza, e dispõe todas as causas com suavidade.

SOLUÇÃO. — Certos, como Demócrito e os epicuristas, pensando ser o mundo obra do acaso, negaram
totalmente a providência. Outros disseram que estão sujeitos à providência só os seres incorruptíveis. E
também os corruptíveis, não individual, mas especificamente, pois, como tais, são incorruptíveis. É
representando a opinião desses que Jó diz (Jó 22, 14): Nas nuvens está escondido, nem tem cuidado das
nossas causas, e passeia pelos pólos do céu.Mas Rabi Moisés, que da generalidade dos seres corruptí-
veis excetua os homens, pelo esplendor do intelecto, de que participam, segue a opinião dos outros
quanto aos demais indivíduos corruptíveis.
É necessário, porém, admitir que todos os seres estão sujeitos à divina providência, não só universal,
mas também singularmente. O que assim se demonstra. Todo agente agindo para um fim, a ordenação
dos efeitos para o fim é proporcional à extensão da causalidade do agente primeiro. E quando, nas
obras de um agente, o efeito não se ordena ao fim, é que tal efeito resulta de alguma outra causa contra
a intenção do agente. Ora, a causalidade de Deus, agente primeiro, se estende a todos os seres, tanto
corruptíveis como incorruptíveis, e não só quanto aos princípios da espécie, mas também quanto aos
indivíduos. Por onde, tudo o que tem de algum modo o ser foi necessàriamente ordenado por Deus a
um fim, segundo a Escritura (Rm 13,1): E as (potestades) que há, essas foram por Deus ordenadas. E
sendo a providência de Deus a razão da ordem das coisas para o fim, como dissemos, todos os entes
estão necessàriamente sujeitos à providência divina na medida mesma em que participam do ser.
E, do mesmo modo, já demonstramos que Deus, conhece tudo, tanto o universal como o particular. E
estando o seu conhecimento para as coisas, como o conhecimento da arte para o artificiado, como
dissemos, necessariamente tudo há-de depender da sua ordem, como todos os artificiados dependem
da ordem da arte.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Uma é a ordem da causa universal e outra, a da
particular. Pois, é possível escapar-se à ordem desta, mas não à daquela. Um efeito escapa à ordem de
uma causa particular só por outra causa particular impediente; p. ex., a ação da água impede a
combustão da madeira. Mas, incluindo-se todas as causas particulares na causa universal, é impossível
qualquer efeito escapar à ordem desta. Donde o chamar-se casual ou fortuito, em relação à uma causa
particular, o efeito que lhe escapa à ordem. Mas, em relação à causa universal, à qual não pode
subtrair·se, diz-se que tal efeito foi previsto. Assim, o encontro de dois escravos, embora casual, quanto
a eles, foi contudo previsto pelo senhor, que cientemente os mandou a um determinado lugar, sem que
um soubesse do outro.

RESPOSTA À SEGUNDA. — O que se dá com o que cura de uma causa particular não se dá com o
provisor universal. Pois, o provisor particular exclui, na medida do possível, a deficiência do que lhe está
sujeito aos cuidados; mas o provisor universal, se permite algum defeito num ser particular, é para não
ficar impedido o bem do todo. Por isso, dizemos que as corrupções e deficiências dos seres naturais são
contrárias à natureza particular, embora estejam na intenção da natureza universal, porque o defeito de
um ser contribui para o bem de outro, ou mesmo de todo o universo; pois a corrupção de um ser é a
geração de outro, pela qual se conserva a espécie. Ora, sendo Deus o provisor universal de todos os
entes, é próprio à sua providência permitir certos defeitos, em certos seres particulares, a fim de que
não se impeça o bem perfeito do universo. Porquanto muitos bens faltariam ao universo se se
impedissem todos os males. Assim não seria possível a vida do leão, sem a morte de outros animais;
nem existiria a paciência dos mártires, sem a perseguição dos tiranos. Por isso, diz Agostinho: Deus
onipotente de nenhum modo permitiria o mal nas suas obras se não fosse tão poderoso e bom, para
tirar o bem, mesmo do mal. E os que subtraíram à divina providência os seres corruptíveis, sujeitos ao
acaso e ao mal, foram sem dúvida levados pelas duas objeções, ora resolvidas.

RESPOSTA À TERCEIRA. — O homem não é o instituidor da natureza, mas usa das causas naturais, nas
obras da arte e da virtude. Por isso a providência humana não se estende aos seres naturais necessários,
a que, entretanto, se estende a providência de Deus, autor da natureza. E foram levados sem dúvida
pela objeção formulada os que subtraíram à divina providência o curso dos seres naturais, atribuindo-a
a lei da matéria, como Demócrito, e outros físicos antigos.

RESPOSTA À QUARTA. — Dizer-se que Deus entregou o homem a si próprio não exclui a divina
providência, mas significa que não lhe foi infundida uma virtude operativa, determinada a um só termo,
como o foi aos seres naturais. Pois, estes são levados e como dirigidos por outro ser para o fim que lhes
é próprio, e não agem por si mesmos, dirigindo-se a si mesmos para esse fim, como o fazem as criaturas
racionais, pelo livre arbítrio, pelo qual aconselham e elegem. Donde o dito expressivo da Escritura: na
mão do seu conselho. Mas reduzindo-se a Deus, como à causa, os atos mesmos do livre arbítrio
necessariamente estão sujeitos à divina providência; pois a providência humana se inclui na divina como
a causa particular, na universal. — Mas a providência de Deus se estende, de modo mais excelente aos
justos, que aos ímpios, não permitindo que contra eles aconteça o que possa, afinal, impedir-lhes a
salvação; pois os que amam a Deus todas as coisas lhes contribuem para seu bem. Porém, por isso
mesmo que não livra os ímpios do mal da culpa, dizemos que os abandona; não que sejam por isso
totalmente excluídos da sua providência; pois se não fossem conservados pela sua providência,
voltariam ao nada. E foi sem dúvida esta a razão que levou Túlio a subtrair à divina providência as coisas
humanas, sobre as quais exercemos o nosso conselho.

RESPOSTA À QUINTA. — A criatura racional sendo, pelo livre arbítrio, senhora de seus atos, como
dissemos, está sujeita de maneira especial à divina providência, de modo que Deus lhe imputa por culpa
ou mérito o que ela faz, e lhe atribui a pena ou o prêmio. E é porque Deus, segundo o Apóstolo, não
cura dos bois; sem querer com isso dizer que as criaturas irracionais não dependam individualmente da
providência de Deus, como pensava Rabi Moisés.

## Art. 3 — Se Deus providencia imediatamente sobre todos os seres.
(Infra, q. 103, a. 6; III Cont. Gent., cap. LXXVI, LXXVII, LXXXIII, XCIV; Compend. Theol., cap. CXXX, CXXXI;
Opusc. XV, De Angelis., cap. XIV).
O terceiro discute-se assim. — Parece que Deus não providencia imediatamente sobre todos os seres.

1. — Pois, devemos atribuir a Deus toda dignidade. Ora, é próprio da dignidade real ter ministros,
mediante os quais exerça a providência sobre os seus súditos. Logo, com maior razão, Deus não provê
imediatamente a todos os seres.

2. Demais. — É próprio da providência ordenar as coisas para um fim, que lhes é a perfeição e o bem.
Pois, é da essência de uma causa levar a bom termo o seu efeito. Ora, toda causa agente é efeito da
providência. Logo, se Deus provê imediatamente a todos os seres, anular-se-ão todas as causas
segundas.

3. Demais. — Agostinho diz: É preferível não saber, a saber certas coisas, p. ex., as vis; e o mesmo diz o
Filósofo. Ora, devemos atribuir a Deus tudo o que há de melhor. Logo, ele não tem providência imediata
de certos seres vis e mínimos.
Mas, em contrário, a Escritura (Jó 34,13): A qual outro estabeleceu sobre a terra? Ou a quem pôs sobre
o mundo que fabricou? Ao que diz Gregório: Rege por si mesmo o mundo que por si mesmo criou.

SOLUÇÃO. — Duas coisas cabem à providência: a razão da ordem dos seres a quem ela provê, a um fim;
e a execução dessa ordem, a que se chama governo. — Quanto à primeira, Deus, que tem no seu
intelecto a razão de todos os seres, mesmo dos mínimos, a todos provê imediatamente. E
preestabelecendo certas causas a certos efeitos, deu-lhes a virtude de os produzir. Logo, é necessário
nele preexista a razão da ordem desses efeitos. — Quanto à segunda, a providência, que governa os
inferiores pelos superiores, emprega certos seres médios; não por defeito do seu poder, mas pela
abundância da sua bondade, que comunica a dignidade de causa, mesmo às criaturas.
E, deste modo, fica excluída a opinião de Platão, que, segundo Gregório Nisseno (Nemésio), admitia
tríplice providência. A primeira, a do sumo Deus, primária e principalmente provê aos seres espirituais e
por conseqüência a todo mundo, quanto aos gêneros, às espécies e às causas universais. A segunda
provê aos seres particulares susceptíveis de geração e corrupção; e esta atribui aos deuses, que percor-
rem os céus, isto é, às substâncias separadas, que movem em círculos os corpos celestes. A terceira é a
providência das coisas humanas, que atribui aos demônios, que os Platônicos consideravam seres
médios entre nós e os deuses, segundo refere Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É próprio da dignidade real ter ministros executores da
sua providência. E só por defeito é que ela não tem a razão do que devem fazer; pois toda ciência
operativa é tanto mais perfeita quanto mais particularidades considera num ato.

RESPOSTA À SEGUNDA. — O ter Deus providência imediata de todos os seres não exclui as causas
segundas, executoras da sua ordem, como do sobredito se colhe.

RESPOSTA À TERCEIRA. — Não podendo inteligir muitas coisas simultaneamente é nos preferível não
conhecer o vil e o mal que nos impede a consideração do melhor. E porque, às vezes, pensar mal nos
inclina a vontade para ele. Mas tal não se dá com Deus, que, tudo vendo simultaneamente, por simples
intuição, não pode ter vontade inclinada ao mal.

## Art. 4 — Se a divina providência impõe necessidade às coisas sobre que providencia.
(I Sent., dist. XXXIX, q. 2, a. 2; III Cont. Gent., cap. LXXII, XCIV; De Malo, q. 16, a. 7, ad 15; Opusc. II,
Contra Graecos, Armenos, etc., cap. X; Compend. Theologiae, cap. CXXXIX. CXL; Opusc. XV., De Angelis,
cap. XV; I Periherm., lect. XIV; IV Metaph., lect. III).
O quarto discute-se assim. — Parece que a divina providência impõe necessidade às coisas sobre que
providência.

1. — Pois, todo efeito procedente de uma causa direta, a qual ainda existe ou já existiu, e da qual ele
resulta necessariamente, tem uma procedência necessária, como o prova o FilósoFo. Ora, a providência
de Deus, sendo eterna, preexiste, e, não podendo ser frustrada, produz o seu efeito necessariamente.
Logo, a providência divina impõe necessidade às coisas sobre que previdência. 2. Demais. — Todo
provisor procura o mais possível dar firmeza à sua obra, para que não falhe. Ora, Deus é sumamente
poderoso. Logo, infunde a firmeza da necessidade às coisas de que tem providência.

3. Demais. — Boécio diz: O destino, procedendo das imóveis origens da providência, adstringe os atos e
as fortunas dos homens ao indissolúvel nexo causal. Logo, a providência impõe necessidade às causas.
Mas, em contrário, Dionísio: Não é da providência corromper a natureza. Ora, certas coisas são de
natureza contingente. Logo, a providência divina não impõe necessidade às coisas excluindo-lhes a
contingência.

SOLUÇÃO. — A providência divina impõe necessidade a umas coisas, mas não a todas, como certos
acreditavam. Pois, a ela pertence ordenar os seres para um fim. Ora, depois da bondade divina, fim
exterior aos seres, o bem principal neles próprios existentes é a perfeição do universo. E esta não
existiria senão se encontrassem neles todos os graus de existência. Por onde, pertence à providência
divina criar todos os graus de seres. Por isso, adaptou causas necessárias a certos efeitos, para estes se
realizarem necessariamente; a outros, porém, causas contingentes, para se realizarem con-
tingentemente, conforme a condição das causas próximas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Efeito da divina providência é realizar-se uma coisa, não
somente de qualquer modo, mas contingente ou necessariamente. Por onde, infalível e
necessariamente, como também contingentemente, se realiza o que a razão da divina providência assim
determinou que se realizasse.

RESPOSTA À SEGUNDA. — A ordem imóvel e certa da divina providência consiste em realizar-se tudo
conforme ela previu, necessária ou contingentemente.

RESPOSTA À TERCEIRA. — A indissolubilidade e a imutabilidade, de que fala Boécio, pertencem à
certeza da providência, cujo efeito nunca falha, como não falha também o modo de realização, que
Deus previu, mas não pertence à necessidade dos efeitos. E devemos ponderar que o necessário e o
contingente resultam propriamente do ser como tal. Por isso, o modo da contingência e da necessidade
se incluem na previsão de Deus, universal provisor de todos os seres; não porém na previsão de
quaisquer provisores particulares.