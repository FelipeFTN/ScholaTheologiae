# Questão 78: Das potências da alma em especial.
Em seguida devem-se considerar as potências da alma em especial. Ao teólogo pertence indagar,
especialmente, só das potências intelectivas e apetitivas, susceptíveis de virtude. Mas, como o
conhecimento dessas potências depende, de certo modo, das outras, por isso a nossa consideração
sobre as potências da alma, em especial, será tripartida. Pois, primeiro, devem-se considerar coisas que
servem de preâmbulo ao intelecto. Segundo, as potências intelectivas. Terceiro, as potências apetitivas.
Sobre a primeira questão, quatro artigos se discutem:

## Art. 1 — Se se devem distinguir cinco gêneros de potências da alma, a saber: o vegetativo, o sensitivo, o apetitivo, o motivo local e o intelectivo.
(Supra, q. 16, a. 3; De Verit., q. 10, a. 1, ad 2; Qu. De Anima a. 13; I De Anima, lect. XIV; II, lect. III, V).
O primeiro discute-se assim. ― Parece que não se devem distinguir cinco gêneros de potências da
alma, a saber: o vegetativo, o sensitivo, o apetitivo, o motivo local e o intelectivo.

1. ― Pois, as potências da alma são consideradas partes da mesma. Ora, em geral, todos lhe admitem só
três partes: a alma vegetativa, a sensível e a racional. Logo, só há três gêneros de potências e não cinco.

2. Demais. ― As potências da alma são os princípios das operações vitais. Ora, como ensina o Filósofo,
de quatro modos pode-se dizer que um ser vive: Embora os modos de viver sejam múltiplos, dizemos
que um ser é vivo quando nele exista um apenas desses modos, a saber, o intelecto e os sentidos, o
movimento e o repouso locais; e a estes devendo acrescentar-se o movimento alimentar, o de
decrescimento e de aumento. Logo, só há quatro gêneros de potências da alma, excluindo-se o
apetitivo.

3. Demais. ― Ao que é comum a todas as potências não se deve atribuir nenhum gênero especial de
alma. Ora, desejar convém a qualquer das potências da alma; assim, a visão deseja o visível
conveniente, dizendo, por isso, a Escritura: A praça do corpo e a beleza do rosto desejará o teu olho;
mas a verdura dos campos semeados leva muita vantagem a ambas as coisas. E, do mesmo modo,
qualquer outra potência deseja o seu objeto conveniente. Logo, não se deve admitir o apetitivo como
gênero especial das potências da alma.

4. Demais. ― O princípio motor, nos animais, é o sentido ou o intelecto ou o apetite, como já se disse.
Logo, não se deve considerar o gênero motivo, como especial da alma, além dos outros gêneros já
mencionados.
Mas, em contrário,diz o Filósofo: Consideramos como potências a vegetativa, a sensitiva, a apetitiva, a
motiva local e a intelectiva.

SOLUÇÃO. ― Cinco são os gêneros das potências da alma, já enumerados; mas as almas são três; e os
modos de viver, quatro.
E a razão desta diversidade está em se distinguirem diversas almas segundo os modos diversos pelos
quais a operação da alma sobreexcede a da natureza corpórea. Pois, esta, totalmente, está sujeita à
alma, e com ela se compara como matéria e instrumento. ― Ora, há uma operação da alma excedente
de tal modo à natureza corpórea, que nem mesmo se exerce por meio de qualquer órgão corpóreo. E tal
é a operação da alma racional. ― Há outra inferior a esta, que se realiza pelo órgão, mas não por
qualquer qualidade corpórea. E tal é a da alma sensitiva; pois, embora o cálido e o frio, o úmido e o
seco, e outras qualidades corpóreas semelhantes sejam necessárias para a operação do sentido, todavia
não o são, a ponto tal, que a operação da alma sensível se exerça, mediante a virtude de tais qualidades;
sendo elas só necessárias para a devida disposição do órgão. ― Por fim, a operação ínfima da alma é a
que exerce pelo órgão corpóreo e em virtude de qualidade corpórea. Mas, ainda assim, sobreexcede a
operação da natureza corpórea; pois, ao passo que as moções dos corpos procedem de um princípio
exterior, tais operações procedem de um intrínseco, o que é comum a todas as operações da alma,
porquanto, todo ser animado move-se, de certo modo, a si mesmo. E tal é a operação da alma
vegetativa; assim, a digestão, e tudo o que dela resulta, realiza-se instrumentalmente pela ação do
calor, como já se disse.
Quanto aos gêneros das potências da alma, eles se distinguem pelos objetos. Pois, quanto mais elevada
for a potência, tanto mais universal será o seu objeto, como já antes se disse. Ora, o objeto da operação
da alma pode ser encarado sob tríplice ordem. ― Há uma potência que têm por objeto o corpo
somente, unido à alma. E este gênero de potências se chama vegetativo;pois, a potência vegetativa só
pode agir no corpo unido à alma. ― Há, porém outro gênero de potências que visa um objeto mais
universal, a saber, todo o corpo sensível, e não só o corpo unido à alma. ― Há, por fim, outro gênero,
que visa um objeto ainda mais universal e é, não só o corpo sensível, mas todo ente, universalmente. ―
Por onde se vê, que estes dois últimos gêneros de potências exercem operação relativa, não só a uma
coisa conjunta, mas também a uma coisa extrínseca. Como porém é necessário que o ser ativo esteja
ligado, de certo modo, ao seu objeto, em relação ao qual opera, necessário é que a coisa extrínseca,
objeto da operação da alma, se compare com esta por dois aspectos da sua natureza. ― De um modo,
por lhe ser natural estar unida à alma e nesta estar pela sua semelhança. E, sob este aspecto, há dois
gêneros de potências: o sensitivo, relativo ao objeto menos comum, que é o corpo sensível; e o
intelectivo, relativo ao objeto comuníssimo, que é o ente universal. ― De outro modo, porém, enquanto
a alma mesma se inclina e tende para a coisa exterior. E ainda, a esta luz, há dois gêneros de potências:
o apetitivo,pelo qual a alma está para a coisa extrínseca como fim, que é primeiro na intenção; e outro,
o motivolocal,enquanto a alma está para a coisa exterior como para o termo da operação e do
movimento; assim, todo animal se move para conseguir a coisa desejada intencionada.
Quanto aos modos de viver, eles se distinguem pelos graus dos viventes. ― Assim, há certos viventes,
como as plantas, em que só há o modo vegetativo. ― Outros há, porém, nos quais, com o vegetativo
existe também o sensitivo, não, porém, o motivo local; assim, os animais imóveis, como as conchas. ―
Outros ainda, além disso, têm o motivo local; assim, os animais perfeitos que, precisando de muitas
coisas necessárias à vida, precisam por isso do movimento para poderem procurá-las, colocadas que
estão à distância. ― Outros viventes há, por fim, como os homens, nos quais, além desses, há o modo
intelectivo. Quanto ao apetitivo, esse não constitui nenhum grau de vivência porque todos os que têm
sentido também têm apetite, como já se disse.
E, por aqui, se resolvem as DUAS PRIMEIRAS OBJEÇÕES.

RESPOSTA À TERCEIRA. ― Apetite natural é a inclinação natural de um ser para alguma coisa. Por onde,
toda potência deseja, por apetite natural, o que lhe é conveniente. Mas o apetite animal resulta da
forma apreendida e supõe uma potência especial da alma, não bastando só a apreensão. Pois, a coisa
desejada o é como naturalmente existe; ela não está porém desse modo na virtude apreensiva, mas só
por semelhança. Por onde é claro, que a visão deseja naturalmente o visível, só para realizar o seu ato
que é ver. O animal, porém, deseja a coisa vista, pela virtude apetitiva, não só para vê-la, mas também
para outros usos. Pois, se a alma não precisasse das coisas percebidas pelo sentido senão por causa dos
atos dos sentidos, a saber, para que as sentisse, não seria necessário considerar o apetitivo como um
gênero especial, entre as potências da alma, porque bastaria o apetite natural das potências.

RESPOSTA À QUARTA. ― Embora o sentido e o apetite sejam princípios motores, nos animais perfeitos,
contudo, como sentidos, não bastam para mover, se não se lhes acrescentar alguma virtude. Pois,
embora os animais imóveis tenham sentido e apetite, não têm, contudo, a virtude motora. Ora, esta não
só está no apetite e no sentido, como ordenadora do movimento, mas também está nas partes mesmas
do corpo, para que sejam aptas a obedecer ao apetite da alma motiva. E a prova está em que, quando
os membros são privados da sua disposição natural, não obedecem à tendência para o movimento.

## Art. 2 — Se as partes vegetativas estão bem enumeradas assim: a nutritiva, a aumentativa e a geratriz.
(IV Cont. Gent., cap. LVIII; Qu. De Anima, a. 13; II De anima, lect IX).
O segundo discute-se assim. ― Parece que as partes vegetativas não estão bem enumeradas assim: a
nutritiva, a aumentativa e a geratriz.

1. ― Pois, tais virtudes são naturais. Ora, as potências da alma lhes são superiores. Logo, as mesmas não
devem ser consideradas como potências.

2. Demais. ― Ao que é comum aos viventes e aos não-viventes não se deve atribuir nenhuma potência
da alma. Ora, a geração é comum a todos os seres susceptíveis de geração e corrupção, tanto viventes
como não-viventes. Logo, a virtude geratriz não deve ser considerada como potência da alma.

3. Demais. ― A alma é mais potente que a natureza corpórea. Ora, esta, pela mesma virtude ativa, dá a
espécie e a quantidade devidas. Logo, com maioria de razão, a alma não tem uma potência aumentativa
diferente da geratriz.

4. Demais. ― A causa que dá o ser é a mesma que o conserva. Ora, pela potência geratriz é que o
vivente adquire o ser; logo, pela mesma é que se conserva vivo. Ora, à conservação do vivente é que se
destina a virtude nutritiva, como já se disse: Pois, é a potência capaz de conservar o ser que o recebe.
Logo, a potência nutritiva não se deve distinguir da geratriz.
Mas, em contrário, diz o Filósofo, as operações desta alma são gerar, alimentar-se e, por fim, crescer.

SOLUÇÃO. ― São três as potências da alma vegetativa. Pois, o gênero vegetativo, como já se disse, tem
como objeto o corpo mesmo, que vive pela alma, para cujo corpo necessária é tríplice operação dela.
Uma, pela qual adquire o ser; e, a essa se destina à potência geratriz. Outra, pela qual adquire a
quantidade devida; e a essa se destina à virtude aumentativa. Outra, enfim, pela qual se conserva no ser
e na quantidade devida, e a essa se destina à virtude nutritiva.
Deve-se, porém, atender a uma certa diferença entre essas potências. Assim, a nutritiva e a aumentativa
produzem o seu efeito no ser em que existem; pois é o corpo mesmo, que está unido à alma, que cresce
e se conserva pela virtude aumentativa e pela nutritiva existentes na mesma alma. Porém, a virtude
geratriz produz o seu efeito, não no mesmo corpo, mas em outro, pois nenhum ser é gerador de si
mesmo. E, por isso, a virtude geratriz se aproxima, de certo modo, em dignidade, da alma sensitiva, cuja
operação recai sobre coisas exteriores, embora de modo mais excelente e universal. Pois, o que é
supremo, em a natureza inferior, confina com o que é ínfimo, na superior, como se vê em Dionísio. E,
portanto, dessas três potências, a que é sobretudo final, principal e perfeita é a geratriz, como já se
disse. Pois, é próprio da coisa já perfeita fazer outra semelhante a si. Ora, as virtudes aumentativa e
nutritiva servem à geratriz; porém, à aumentativa, a nutritiva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Essas virtudes se chamam naturais, quer porque
produzem efeito semelhante à natureza, que também dá o ser, a quantidade e a conservação, embora o
façam de modo mais alto; quer porque exercem a sua ação instrumentalmente, pelas qualidades ativas
e passivas, princípios da ação natural.

RESPOSTA À SEGUNDA. ― A geração, nas coisas inanimadas, tem proveniência totalmente extrínseca.
Mas, nos seres vivos ela se processa por certo modo mais elevado; por algo do próprio vivente, o
sêmen, no qual reside o princípio formador do corpo. Por onde, é necessário existir uma potência no ser
vivo que lhe prepare o sêmen; e essa é a virtude geratriz.

RESPOSTA À TERCEIRA. ― Realizando-se a geração do ser vivo pelo semen, necessário é que, no
princípio, o animal seja gerado pequeno; e, por isso, é preciso que tenha uma potência da alma que o
leve ao tamanho devido. Ao passo que o corpo inanimado é gerado de uma determinada matéria, por
um agente extrínseco; e, por isso, recebe simultaneamente a espécie e a quantidade, segundo a
condição da matéria.

RESPOSTA À QUARTA. ― Como já se disse, a operação do princípio vegetativo se completa mediante o
calor, que consome a umidade. Por onde, para a recuperação da umidade perdida, há necessidade da
potência nutritiva, pela qual o alimento se converte na substância do corpo. O que também é necessário
para o ato das virtudes aumentativa e geratriz.

## Art. 3 — Se se distinguem convenientemente só cinco sentidos externos.
(II Sent., dist. II, q. 2, a. 2, ad 5; Qu. De Anima, a. 13; II De Anima, lect. XIV; III, lect. I).
O terceiro discute-se assim. ― Parece que se distinguem inconvenientemente só cinco sentidos
externos.

1. ― Pois, o sentido é cognoscitivo dos acidentes. Ora, como estes são de muitos gêneros, e as
potências se distinguem pelos seus objetos, resulta que os sentidos se hão de multiplicar pelo número
dos gêneros dos acidentes.

2. Demais. ― A grandeza, a figura e coisas semelhantes, chamadas sensíveis comuns, não são sensíveis
por acidente, antes, dividem-se por oposição com estes. Ora, a diversidade dos objetos, por si,
diversifica as potências. E como, mais que o som, a grandeza e a figura diferem da cor, resulta que,
muito mais necessariamente, deve haver uma potência sensitiva cognoscitiva da grandeza ou da figura,
que da cor e do som.

3. Demais. ― Cada sentido se refere a um contrário; assim, a visão à do branco e preto. Ora, o tacto
conhece vários contrários, a saber: o cálido e o frio, o úmido e o seco, e outros semelhantes. Logo, não
constitui um só sentido, mas vários. Logo, há mais de cinco sentidos.

4. Demais. ― A espécie não se divide por oposição com o gênero. Ora, o gosto é uma espécie de tacto.
Logo, não se deve admitir nenhum outro sentido além do tacto.

SOLUÇÃO. ― A razão da distinção e do número dos sentidos externos, alguns quiseram deduzi-la dos
órgãos, no quais domina um dos elementos ― a água, o ar ou outro qualquer. Outros porém, do meio,
que é conjunto ou extrínseco; sendo este o ar, a água ou coisa semelhante. Outros, ainda, da natureza
diversa das qualidades sensíveis, segundo a qual a qualidade ou é a de um corpo simples ou a resultante
de um complexo. ― Mas nenhuma destas opiniões é aceitável. Pois, as potências não existem para os
órgãos, mas estes para aquelas; por onde, não é por haver diversos órgãos que há de haver diversas
potências, mas, antes, a natureza instituiu a diversidade de órgãos para corresponderem à das
potências. E semelhantemente, atribuiu meios diversos aos diversos sentidos, como era conveniente
aos atos das potências. Porém, conhecer as naturezas das qualidades sensíveis não é próprio do sentido,
mas do intelecto.
Mas a razão do número e da distinção dos sentidos exteriores funda-se no que, propriamente e por si,
pertence ao sentido. Ora, este é uma potência passiva, à qual é natural ser alterada pelo sensível
externo. E o exterior é capaz de alterar porque, em si, é percebido pelo sentido, distinguindo-se, pela
sua diversidade, as potências sensitivas.
Ora, dupla é a alteração: uma natural; outra, espiritual. Aquela consiste em a forma do alterante ser
recebida no alterado, pelo seu ser natural; assim, o calor, no corpo aquecido. A espiritual, porém,
consiste em a forma do alterante ser recebida no alterado, pelo seu ser espiritual; assim, a forma da cor,
na pupila, que, nem por isso, se torna colorida. Ora, para a operação do sentido se requer a alteração
espiritual, pela qual se realize no órgão do mesmo a espécie intencional da forma sensível; do contrário,
se só a alteração natural bastasse para sentir, todos os corpos naturais, alterados, sentiriam.
Mas, em certos sentidos, como no da visão, só há a alteração espiritual. ― Em outros porém, além
dessa, há também a natureza, quer só por parte do objeto, quer também por parte do órgão. ― Do
objeto provém à transmutação natural, quer quanto ao lugar, como no som, objeto do ouvido, e
resultante da percussão e da comoção do ar; quer quanto à alteração, como no odor, objeto do olfato, e
o qual, para se evolar, é preciso que o corpo seja, de algum modo, alterado pela calidez. ― Por parte do
órgão a mutação é natural no tacto e no gosto; assim, a mão, tocando corpos quentes, se aquece; e a
língua se umedece pela umidade dos sabores. Ao passo que o órgão do olfato e o da audição não sofrem
nenhuma mutação natural, quando sentem, salvo por acidente.
O sentido da visão, porém, que não precisa de nenhuma mutação natural do órgão e do objeto é, dentre
todos os sentidos, o mais espiritual, perfeito e comum; em seguida, vem o sentido da audição, e, depois,
o olfato, que sofrem mutação natural por parte do objeto. E, quanto ao movimento local, ele é mais
perfeito do que o movimento de alteração e é anterior a este, como já se provou. Sendo o tacto e o
gosto os sentidos os mais materiais, de cuja distinção a seguir se tratará. E daí resulta, que os outros três
sentidos não se exercem por um meio conjunto e sem que alguma transmutação natural atinja o órgão,
como acontece com os dois últimos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Nem todos os acidentes têm a virtude de causar a
mutação em si, mas só as qualidades da terceira espécie, que causam a alteração. Por onde, só tais
qualidades são os objetos dos sentidos; porque, como diz Aristóteles, o sentido se altera pelas mesmas
causas que alteram os corpos inanimados.

RESPOSTA À SEGUNDA. ― A grandeza, a figura e atributos semelhantes, chamados sensíveis, comuns,
são meios entre os sensíveis por acidente e os sensíveis próprios, objetos dos sentidos. Pois, os sensíveis
próprios, sendo qualidades alterantes, causam, primariamente e por si, mutação no sentido. ― Porém,
todos os sensíveis comuns se reduzem à quantidade. Assim, é evidente que a grandeza e o número são
espécies de quantidade. A figura, porém, é uma qualidade quantitativa, pois, a sua natureza consiste em
limitar a grandeza. Ao passo que o movimento e o repouso são sentidos, na medida em que o sujeito, de
um só ou de muitos modos, se comporta relativamente à sua grandeza ou a distância local, quanto ao
movimento de aumento e ao local; ou ainda relativamente às qualidades sensíveis, quanto ao
movimento de alteração. Assim, sentir o movimento e o repouso é, de certo modo, sentir o que é uno e
o que é múltiplo. A quantidade, por fim, é o sujeito próximo da qualidade alterativa; assim, a superfície
é o sujeito da cor. Por onde, os sensíveis comuns não movem o sentido primariamente e por si, mas em
razão da qualidade sensível, como a superfície, em razão da cor. E nem são, por isso, sensíveis por
acidente, porque causam uma certa diversidade na mutação do sentido. Pois, este sofre mutação
diferente, segundo a superfície é grande ou pequena, porque também a brancura pode ser considerada
grande ou pequena e, portanto, é dividida segundo o seu sujeito próprio.

RESPOSTA À TERCEIRA. ― Como diz o Filósofo, o sentido do tato é, genericamente, um; mas,
especificamente se divide em muitos sentidos e por isso, diz respeito às contrariedades diversas. Como
estas, porém, não se separam, organicamente, umas das outras mas aplicam-se ao corpo todo, por isso
a distinção delas não aparece. Porém o gosto, que percebe o doce e o amargo, identifica-se com o tacto,
na língua e não por todo o corpo e, por isso, facilmente dele se distingue. ― Mas também se poderia
dizer que todas aquelas contrariedades convêm, singularmente, pelo gênero próximo e, totalmente,
pelo gênero comum, que é o objeto do tacto, segundo a noção comum. Mas esse gênero comum não
têm denominação, como também não a tem o gênero próximo do cálido e do frio.

RESPOSTA À QUARTA. ― O sentido do gosto, segundo diz o Filósofo, é uma certa espécie de tacto, que
só existe na língua. Não se distingue porém do tacto, genericamente, mas quanto às outras espécies
espalhadas por todo o corpo. Se, pois, o tacto é um seu tido só, por causa da noção comum única do
objeto, deve-se concluir que, pela natureza diversa da mutação se há de distinguir o gosto do tacto. Pois
o órgão deste sofre mutação natural, e não só espiritual, quanto à qualidade que lhe serve de objeto
próprio. Ao passo que o órgão do gosto não sofre mutação necessariamente natural, quanto à qualidade
que lhe serve de objeto próprio, de modo que a língua se torne doce ou amarga; mas, quanto à
qualidade preliminar, em que se funda o sabor, a saber, o humor, objeto do tacto.

## Art. 4 — Se os sentidos internos se distinguem convenientemente.
(Qu. De Anima, art. 13).
O quarto discute-se assim. ― Parece que os sentidos externos se distinguem inconvenientemente.

1. ― Pois, o comum não se divide por oposição com o próprio. Logo, o sentido comum não deve ser
enumerado entre as virtudes sensitivas interiores, além dos sentidos exteriores próprios.

2. Demais. ― Para o que basta o sentido próprio e externo não se deve atribuir nenhuma virtude
apreensiva interna. Ora, para julgar dos sensíveis bastam os sentidos próprios e externos, pois, cada
sentido julga do seu objeto próprio. E, semelhantemente, bastam para perceberem os seus próprios
atos; pois, sendo a ação do sentido, de certo modo, média entre a potência e o objeto, resulta que o
sentido da vista pode perceber a sua visão, como lhe sendo mais próxima, muito mais do que percebe a
cor; e assim por diante. Logo, não é necessário, para isso, admitir uma potência interna, chamada
sentido comum.

3. Demais. ― Segundo o Filósofo, a fantasia e a memorativa são paixões do primeiro sensitivo. Ora, a
paixão não se divide por oposição com o sujeito. Logo, não se devem admitir a memória e a fantasia
como potências outras, além do sentido comum.

4. Demais. ― O intelecto depende do sentido, menos que qualquer potência, da parte sensitiva. Ora, o
intelecto não conhece nada que não receba do sentido; e, por isso, diz Aristóteles que, aos que falta
uma, sentido falta uma ciência. Logo, com maioria de razão, não se deve admitir uma potência da parte
sensitiva chamada estimativa, para perceber as apreensões que o sentido não percebe.

5. Demais. ― O ato da cogitativa ― comparar, compor e dividir ― e o da reminiscitiva ― usar de um
silogismo, para indagar ― não distam menos do ato da estimativa e da memorativa, do que o ato da
estimativa, do ato da fantasia. E, portanto, deve-se admitir a cogitativa e a reminiscitiva como outras
virtudes, além da estimativa e da memorativa; ou, então, não se deve admitir a estimativa e a
memorativa, como outras virtudes, além da fantasia.

6. Demais. ― Agostinho admite três gêneros de visões: a corpórea, que se realiza pelo sentido; a
espiritual, pela imaginação ou fantasia; e a intelectual, pelo intelecto. Logo, não há outra virtude
interna, média entre o sentido e o intelecto, a não ser a imaginativa.
Mas em contrário, Avicena admite cinco potências sensitivas internas: o sentido comum, a fantasia, a
imaginativa, a estimativa e a memorativa.

SOLUÇÃO. ― Como a natureza não falha, nas coisas necessárias, forçoso é haver tantas ações da alma
sensitiva quantas bastem para a vida do animal perfeito. E delas, as que não puderem se reduzir a um
princípio, exigem potências diversas; pois, uma potência da alma não é outra coisa senão o princípio
próximo da operação da alma.
Ora, deve-se considerar que, para a sua vida, é necessário que o animal perfeito apreenda a coisa,
estando o sensível não só presente, mas ainda ausente; do contrário, pois que o seu movimento e ação
resultam da apreensão, o animal não se moveria a buscar qualquer coisa ausente. Ora, é o contrário
disso que se vê, sobretudo nos animais perfeitos, que se movem por movimento progressivo; pois,
movem-se para alguma coisa apreendida como ausente. Logo, não somente é necessário que o animal,
pela alma sensitiva, receba as espécies dos sensíveis, quando sofre mutação pela presença deles; mas
ainda as retenha e conserve. Ora, receber e reter reduzem-se, nos seres corpóreos, a princípios
diversos; assim, as coisas úmidas recebem bem mas retêm mal; e o contrário acontece com as secas.
Por onde, sendo a potência sensitiva o ato do órgão corpóreo, é necessário haja outra potência que
receba as espécies dos sensíveis e as conserve.
Além disso, deve-se considerar que, se o animal se movesse só pelo deleitável, e pelo doloroso,
sensivelmente, não seria necessário admitir, no animal, senão a apreensão das formas percebidas pelo
sentido, e com as quais se deleita ou sofre. Mas é necessário que o animal busque ou fuja certas coisas;
não só por que sejam convenientes ou inconvenientes para serem sentidas, mas também por certas
outras comodidades e utilidades ou nocividades. Assim, a ovelha, vendo o lobo aproximar-se, foge, não
pela feiúra da cor ou da figura do mesmo, mas como sendo um inimigo da sua natureza. E,
semelhantemente, a ave colhe a palha, não porque lhe deleite o sentido, mas por lhe ser útil para a
feitura do ninho. Logo, é necessário ao animal perceber tais espécies intencionais, não percebidas pelo
sentido externo. E essa percepção deve ter algum outro princípio, pois que a percepção das formas
sensíveis provém da imutação sensível, não porém a das espécies intencionais preditas.
Assim portanto, à recepção das formas sensíveis é destinado o sentido próprio e comum, de cuja
distinção a seguir se tratará. ― Porém, à retenção e à conservação dessas formas é destinada à fantasia
ou imaginação, que é um como tesouro das formas recebidas pelo sentido. Ao passo que, a apreender
as espécies intencionais, que não são recebidas pelo sentido, se destina à virtude estimativa. ― E, por
fim, a conservá-las se destina à virtude memorativa, que é o como tesouro de tais espécies intencionais.
E a prova é que o princípio da lembrança resulta, nos animais, de alguma espécie intencional como esta,
a saber, o que é nocivo ou inconveniente. E o passado, na sua natureza, à qual se reporta a memória, é
computado entre tais espécies.
Deve-se considerar, porém, que, quanto às formas sensíveis, não há diferença entre o homem e os
outros animais que, semelhantemente, sofrem mutação dos sensíveis externos. Mas há diferença
quanto às espécies intencionais preditas. Pois, os animais percebem tais espécies só por um como
instinto natural; ao passo que o homem, por uma certa comparação. E por isso, a chamada estimativa
natural, nos animais, chama-se cogitativa no homem, que chega a tais espécies intencionais por uma
certa comparação. Donde vem o chamar-se também razão particular, à qual os médicos assinalam um
órgão determinado, a saber, a parte média da cabeça. Pois, é apreensiva das espécies intencionais
individuais, assim como a razão intelectiva o é das espécies intencionais universais. ― E, quanto a
memorativa, o homem não somente tem a memória, como os outros animais, pela recordação súbita
das coisas pretéritas; mas também a reminiscência, pela qual indaga silogísticamente a memória do
passado, segundo as espécies intencionais individuais.
E, quanto a Avicena, ele admite uma quinta potência, média entre a estimativa e a imaginativa e que
compõe e divide as formas imaginadas. E isso bem claramente se vê, quando, das formas imaginadas do
ouro e de uma montanha, compomos a forma única de uma montanha de miro, que nunca vimos. Mas
essa operação não existe nos animais, mas só no homem em quem, para tal, basta à virtude imaginativa.
E a ele também Averróis lhe atribui tal ação, em certo livro que escreveu.
Assim que não é necessário admitir mais de quatro virtudes internas da parte sensitiva, a saber: o
sentido comum, a imaginação, a estimativa e a memorativa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O sentido interno não se chama comum por predicação,
como se fosse gênero; mas como sendo a raiz comum e o princípio dos sentidos externos.

RESPOSTA À SEGUNDA. ― O sentido próprio julga do sensível próprio, discernindo-o dos outros, que
lhes são também subordinados;assim, discernindo o branco do preto ou do verde. Mas nem o sentido
da vista nem o do gosto podem discernir o branco do doce; porque, necessariamente, quem discerne
entre duas causas deve conhecê-las. Por onde, é forçoso pertença ao sentido comum o juízo, por
discernimento do termo a que se refiram como ao término comum, todas as apreensões dos sentidos; e
pelo qual sejam também percebidas as ações dos sentidos, como, p. ex., quando alguém se vê ver. Pois,
isto não se pode dar pelo sentido próprio, que só conhece a forma do sensível que lhe causou mutação,
na qual mutação se completa a visão, e da qual resulta outra mutação no sentido comum, que percebe a
visão.

RESPOSTA À TERCEIRA. ― Assim como uma potência nasce da alma, mediante outra, como antes se
disse; assim também a alma está sujeita a outra potência, mediante uma terceira. E, deste modo, a
fantasia e a memorativa se chamam paixões do primeiro sensitivo.

RESPOSTA À QUARTA. ― Embora a operação do intelecto nasça do sentido, contudo, na causa
apreendida por este último, o intelecto conhece muitas coisas que o sentido não pode perceber j e o
mesmo se dá com a estimativa, embora de modo inferior.

RESPOSTA À QUINTA. ― Essa eminência, que a cogitativa e a memorativa têm no homem, não é pelo
que é próprio à parte sensitiva, mas por uma certa afinidade e propinqüidade com a razão universal,
segundo certa refluência. Por onde, não são virtudes diferentes, mas as mesmas, mais perfeitas do que
às existentes nos outros animais.

RESPOSTA À SEXTA. ― Agostinho chama visão espiritual a que se dá pelas semelhanças dos corpos, na
ausência destes. Por onde se vê que ela é comum a todas as apreensões internas.