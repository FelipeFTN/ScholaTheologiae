# Questão 64: Da pena dos demônios.
Conseqüentemente devemos tratar da pena dos demônios. E sobre este ponto quatro artigos se
discutem:

## Art. 1 — Se o intelecto dos demônios ficou entenebrecido pela privação do conhecimento de toda verdade.
O primeiro discute-se assim. — Parece que o intelecto dos demônios ficou entenebrecido pela
privação do conhecimento de toda verdade.

1. — Pois, se conhecesse alguma verdade, conheceriam sobretudo a si mesmos, o que seria conhecerem
substâncias separadas. Ora, isto não lhes conviria à miséria, pois, é própria de uma grande beatitude; a
ponto que alguns ensinaram ser a felicidade última do homem o conhecimento das substâncias
separadas. Logo, os demônios estão privados de todo conhecimento da verdade.

2. Demais. — O que por natureza é manifesto, em máximo grau, parece ser, em máximo grau, manifesto
aos anjos, bons ou maus. E se não nos é a nós, nesse mesmo grau, isso provém da debilidade do nosso
intelecto que recebe os dados dos fantasmas; assim como, por debilidade dos olhos a coruja não pode
ver a luz do sol. Ora, os demônios não podem conhecer a Deus, manifestíssimo em si mesmo, pois é a
suma das verdades, porque não têm o coração puro, que só pode ver a Deus. Logo, também não podem
ter conhecimento dos outros objetos.

3. Demais. — O conhecimento angélico das coisas é duplo, segundo Agostinho: o matutino e o
vespertino. Ora, aquele não compete aos demônios, porque não vêm as coisas no Verbo. Nem também
o vespertino, que refere as coisas conhecidas ao louvor do Criador; donde o vir a ser tarde depois da
manhã, como diz a Escritura. Logo, os demônios não podem ter conhecimento das coisas.

4. Demais. — Os anjos, no seu conhecimento, conheceram o mistério do reino de Deus, como diz
Agostinho. Ora, os demônios estão privados desse conhecimento, pois, se eles o conhecessem nunca
sacrificariam o Senhor da glória, como diz a Escritura. Logo, pela mesma razão, estão privados de
qualquer outro conhecimento da verdade.

5. Demais. — Quem conhece qualquer verdade, ou a conhece naturalmente, como conhecemos os
primeiros princípios; ou pela receber de outrem, como o que sabemos aprendendo; ou pela experiência
de um longo tempo, como o que sabemos pelo ter descoberto. Ora, os demônios não podem, pela
própria natureza, conhecer a verdade, porque deles estão separados os bons anjos, como a luz das
trevas, segundo diz Agostinho; e toda manifestação se faz pela luz, na expressão da Escritura.
Semelhantemente, nem pela revelação; nem por aprender dos bons anjos, pois, não há comércio entre
a luz e as trevas, como diz a Escritura. Nem pela experiência de longo tempo, porque esta nasce dos
sentidos. Logo, os demônios não têm nenhum conhecimento da verdade. Mas, em contrário, diz
Dionísio que, dados aos demônios os dons angélicos, nós de nenhum modo os consideramos mudados,
permanecendo íntegros e esplendíssimos. Ora, entre esses dons naturais está o conhecimento da
verdade. Logo, eles têm algum conhecimento desta.

SOLUÇÃO. — Há um duplo conhecimento da verdade: o obtido pela natureza e o pela graça. Sendo este
último, também duplo: um é somente especulativo, quando, p. ex., são revelados a algumas pessoas
certos segredos divinos; outro, porém, é afetivo, produz o amor de Deus e pertence propriamente ao
dom da sabedoria. — Ora, destas três formas de conhecimento, a primeira nem foi suprimida nem
diminuída nos demônios. Pois, resulta da própria natureza angélica, que é naturalmente inteligência ou
mente. Por isso, por causa da simplicidade da substância, essa natureza de nada pode ser privada, de
maneira a ser punida pela privação dos dons naturais, como o homem o é pela privação da mão, do pé
ou de outro qualquer membro. Por onde diz Dionísio (loc. cit) que os dons naturais permanecem
íntegros, nos demônios e, por isso o conhecimento natural não se lhes diminuiu. — Porém, a segunda
forma de conhecimento, a que se obtém pela graça e consiste na especulação, não lhes tendo sido
tirada, foi-lhes contudo diminuída. Porque, dos segredos divinos é-lhes revelado somente o necessário,
ou mediante os anjos, ou por alguns efeitos temporais da divina virtude, como diz Agostinho. Não,
porém, como o é aos próprios santos anjos, aos quais mais claramente mais coisas são reveladas no
Verbo mesmo. — Mas, da terceira forma de conhecimento eles são totalmente privados, bem como da
caridade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A felicidade consiste na aplicação ao que nos é superior.
Ora, as substâncias separadas são-nos superiores, na ordem da natureza; por isso, pode haver uma certa
razão de felicidade para o homem em as conhecer, embora a felicidade perfeita dele esteja em
conhecer a substância primeira, Deus. Mas às substâncias separadas é-lhes conatural mutuamente se
conhecerem, assim como é a nós conhecer as naturezas sensíveis. Por onde, assim como a felicidade do
homem não consiste em conhecer estas naturezas, assim a dos anjos não consiste em mutuamente se
conhecerem.

RESPOSTA À SEGUNDA. — O que é manifestíssimo, por natureza, é-nos oculto como excedente à
capacidade do nosso intelecto e não só porque este receba os dados, dos fantasmas. Ora, a substância
divina excede não só a capacidade do intelecto humano, mas também a do angélico. Por onde, nem o
próprio anjo, pela sua natureza, pode conhecer a substância de Deus. Contudo pode, pela sua natureza,
ter de Deus um conhecimento mais elevado que o homem, por causa da perfeição do seu intelecto. E
um tal conhecimento de Deus permanece também nos demônios; pois, embora não tenham a pureza,
que vem da graça, têm, todavia, a pureza natural, suficiente para o conhecimento natural que têm de
Deus.

RESPOSTA À TERCEIRA. — A criatura é treva, comparada com a excelência da luz divina. E por isso, o
conhecimento próprio à criatura, na sua natureza própria, se chama vespertino, porque a tarde vai de
mistura com as trevas, se bem tenha alguma luz; quando, porém, esta faltar totalmente, faz-se a noite.
Assim, pois, também o conhecimento das coisas, em a natureza própria delas, quando for referido ao
louvor do Criador, como se dá com os bons anjos, tem algo da luz divina e pode chamar-se vespertino;
se, porém, não se referir a Deus, como se dá com os demônios, não se chama vespertino, mas noturno.
Por isso, se lê na Escritura que Deus chamou noite às trevas, que separou da luz.

RESPOSTA À QUARTA. — O mistério do reino de Deus, realizado por Cristo, certamente todos os anjos o
conheceram, desde o princípio, de algum modo; sobretudo desde que foram beatificados pela visão do
Verbo, que os demônios nunca tiveram. Mas, todos os anjos não o conheceram, nem perfeita nem
igualmente. Por onde, muito menos os demônios conheceram perfeitamente o mistério da Encarnação,
durante a existência de Cristo, no mundo. Pois, como diz Agostinho, não lhes foi dado a conhecer, como
aos santos anjos, que fruem da eternidade participada do Verbo; mas lhes foi, por certos efeitos
temporais, como para os aterrar. Porque, se perfeitamente e com certeza tivessem sabido ser Cristo o
Filho de Deus e tivessem conhecido o efeito da sua Paixão, nunca teriam tentado crucificar o Senhor da
glória.

RESPOSTA À QUINTA. — De três modos os demônios conhecem qualquer verdade. — Primeiro, pela
sutileza de sua natureza; pois, embora entenebrecidos pela privação da luz da graça, são todavia lúcidos
pela luz da natureza intelectual. — Segundo, pela revelação aos santos anjos, com os quais, embora não
convenham pela conformidade da vontade, convém, contudo, pela semelhança da natureza intelectual,
podendo, por essa natureza, receber o que por outros for manifestado. — Terceiro, conhecem pela
experiência de um longo tempo, embora não a adquiram pelos sentidos, mas como pelas coisas
singulares se completa a semelhança da espécie inteligível que lhes é naturalmente infusa, conhecem
certas coisas presentes, que não conheciam enquanto ainda eram futuras, como já se disse antes, ao
tratar do conhecimento dos anjos.

## Art. 2 — Se a vontade dos demônios está obstinada no mal.
O segundo discute-se assim. — Parece que a vontade dos demônios não está obstinada no mal.

1. — Pois a liberdade do arbítrio pertence à natureza do ser intelectual, que permanece nos demônios,
como já se disse. Ora, essa liberdade, por si e primariamente, se ordena ao bem e não ao mal. Logo, a
vontade do demônio não está obstinada no mal, de modo que não possa voltar ao bem.

2. Demais. — Maior é a misericórdia infinita de Deus que a malícia finita do demônio. Ora, da malícia da
culpa à bondade da justiça ninguém volta senão pela misericórdia de Deus. Logo, também os demônios
podem voltar ao estado da malícia para o da justiça.

3. Demais. — Se os demônios têm a vontade obstinada no mal, a teriam obstinada sobretudo no pecado
pelo qual pecaram. Mas esse pecado, a soberba, não mais permanece neles por não permanecer o
motivo dela, a excelência. Logo, o demônio não está obstinado na malícia.

4. Demais. — Gregório diz que o homem pôde ser resgatado por outrem, porque por outrem caiu. Ora,
os demônios inferiores caíram pelo primeiro deles, como se disse antes. Logo, a queda deles podia ser
resgatada por outrem. Logo, não está obstinados na malícia.

5. Demais. — Quem está obstinado na malícia nunca pratica boas obras. Ora, o demônio faz algumas
boas obras; assim, confessa a verdade, dizendo a Cristo: Sei quem és, o Santo de Deus; também os
demônios crêem e estremecem, como diz a Escritura; e Dionísio também diz que eles desejam o bom e
o ótimo: existir, viver e inteligir. Logo, não estão obstinados na malícia.
Mas, em contrário, diz a Escritura: A soberba daqueles que te aborrecem, sobe continuamente; o que se
entende dito dos demônios. Logo, perseveram sempre obstinados na malícia.

SOLUÇÃO. — Era opinião de Orígines, que toda vontade da criatura pode inclinar-se para o bem e para o
mal, por causa da liberdade do arbítrio; exceto a alma de Cristo, por efeito da união do Verbo. — Mas
esta opinião destrói a verdade da beatitude em relação aos santos anjos e aos homens; porque a
estabilidade sempiterna é da essência da verdadeira beatitude, sendo, por isso, que esta se chama vida
eterna. Também repugna à autoridade da Sagrada Escritura, declarando que os demônios e os homens
maus serão enviados para o suplício eterno; mas os bons serão transferidos para a vida eterna. Por
onde, essa opinião deve ser reputada por errônea e se deve ter firmemente, segundo a fé católica, que a
vontade dos bons anjos está confirmada no bem e a dos demônios obstinada no mal.
Porém, a causa desta obstinação deve ser buscada, não na gravidade da culpa, mas na condição da
natureza ou do estado. Pois, como diz Damasceno, a morte é para os homens o que é a queda para os
anjos. Ora, é manifesto, todos os pecados mortais, grandes ou pequenos, dos homens são remissíveis,
antes da morte; porém, depois dela, são irremissíveis e perpetuamente permanecem.
Logo, para se inquirir da causa dessa obstinação, é mister considerar que a virtude apetitiva, em todos
os seres, é proporcionada à apreensiva, da qual é movida, assim como é o móvel proporcionado ao
motor. Ora, o apetite sensitivo busca o bem particular, ao passo que a vontade atinge o universal, como
já antes se disse; do mesmo modo que a apreensão sensível atinge o singular, ao passo que o intelecto,
o universal.
Mas, a apreensão do anjo difere da do homem por apreender imovelmente, pelo intelecto, assim como
nós apreendemos os primeiro princípios, objeto do intelecto; ao passo que o homem apreende
movelmente, pela razão, discorrendo de uma verdade para outra, podendo tender para qualquer de
dois opostos. Por onde, a vontade do homem adere a um objeto, movelmente, quase podendo
abandoná-lo para aderir ao contrário; a do anjo, porém, adere fixa e imovelmente. E portanto,
considerada antes da adesão, pode a vontade angélica aderir livremente a um termo ou ao seu oposto,
isso nas coisas que ela não quer necessariamente; mas, depois de já ter aderido, adere imovelmente.
E, por isso, se costuma dizer que o livre arbítrio do homem é flexível e capaz de termos opostos, tanto
antes como depois da eleição; porém, o do anjos é flexível quanto aos opostos, antes da eleição, não,
porém, depois. Assim, pois, os bons anjos, uma vez tendo aderido à justiça, nela foram confirmados;
mas os maus, pecando, obstinaram-se no pecado. Quanto à obstinação dos homens condenados, a
seguir se dirá (Supplem.Q. 98, a. 1, 2).

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tanto os bons como os maus anjos têm o livre arbítrio;
mas segundo o modo e a condição da sua natureza, como foi dito.

RESPOSTA À SEGUNDA. — A misericórdia de Deus libera do pecado os penitentes. Porém, os incapazes
de penitência, por aderirem imovelmente ao mal, esses não são liberados pela divina misericórdia.

RESPOSTA À TERCEIRA. — Ao diabo ainda lhe permanece o pecado pelo qual pecou, quanto ao apetite,
embora não quanto ao que crê poder alcançar. Como quem pensasse poder cometer um homicídio, e o
quisesse sendo, em seguida, privado do poder de o perpetrar; contudo poderia permanecer-lhe a
vontade do homicídio, de modo a querer tê-lo cometido ou a cometê-lo, se pudesse.

RESPOSTA À QUARTA. — Não é a causa total de ser o pecado do homem remissível, o ter pecado por
sugestão de outrem. Logo, a objeção não colhe.

RESPOSTA À QUINTA. — O ato do demônio é duplo. Um procede da vontade deliberada e esse pode ser
propriamente chamado ato do demônio. E tal ato sempre é mau, porque, embora algumas vezes faça
algo de bom, todavia não o faz bem; assim, dizendo a verdade para enganar, e não a acreditando e
confessando voluntariamente, mas coagido pela evidência das coisas. Porém, outro ato do demônio
sendo natural, pode ser bom e lhe atesta a bondade da natureza. E todavia abusa também desse ato,
para o mal.

## Art. 3 — Se há dor nos demônios.
O terceiro discute-se assim. — Parece que não há dor nos demônios.

1. — Pois, a dor e a alegria, mutuamente se opondo, não podem simultaneamente existir no mesmo ser.
Ora, nos demônios há alegria; porquanto Agostinho diz: O diabo tem poder sobre aqueles que
desprezam os preceitos de Deus, e se alegram com esse tão infeliz poder. Logo, neles não há dor.

2. Demais. — A dor é a causa do temor; pois, tememos o futuro daquilo que sofremos, quando é
presente. Ora, nos demônios não há temor, conforme a Escritura: Foi feito para que não temesse a
nada. Logo, neles não há dor.

3. Demais. — Doer-se do mal é bom. Ora, os demônios não podem fazer o bem. Logo, não podem ter
dor, ao menos pelo mal da culpa, o relativo ao verme da consciência.
Mas, em contrário, o pecado do demônio é mais grave que o do homem. Ora, este é punido pela dor,
por causa do deleite no pecado, segundo a Escritura: Quanto ela se tem glorificado e vivido em deleites,
tanto lhe daí de tormento e pranto. Logo, com maioria de razão, o diabo, que se glorificou
maximamente, é punido pelo pranto da dor.

SOLUÇÃO. — O temor, a dor, a alegria e outras paixões, como tais, não podem existir nos demônios;
pois, como tais, pertencem propriamente ao apetite sensitivo, virtude que se exerce pelo órgão
corpóreo. Mas, enquanto designam atos simples da vontade, podem neles existir; sendo necessário
então dizer que neles há dor. Pois esta, significando ato simples da vontade, não é senão o recalcitrar
desta quanto ao que é ou ao que não é. Ora, é claro, os demônios querem não fossem muitas coisas que
são, e fossem muitas que não são; assim, invejosos, querem fossem danados os que se salvam. Por
onde, é forçoso admitir que neles há dor; e, precipuamente, porque é da natureza da pena repugnar à
vontade. Ora, eles estão privados da beatitude, que naturalmente desejam; e, em muitos deles, é
reprimida a vontade iníqua.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A dor e a alegria, relativamente ao mesmo objeto, são
opostos; não são porém, relativamente a objetos diversos. Por onde, nada impede que alguém
simultaneamente se doa de uma coisa e goze com outra; e sobretudo enquanto a dor e a alegria
supõem atos simples da vontade, pois não só em relação a coisas diversas,mas também em relação a
uma mesma coisa, pode haver algo que queremos e algo que não.

RESPOSTA À SEGUNDA. — Assim como, nos demônios, há a dor do presente, assim há o temor do
futuro. E a expressão — Foi feito para que não temesse a nada — se entende do temor de Deus, que
coíbe o pecado. Pois, alhures está escrito, que os demônios crêem e estremecem.

RESPOSTA À TERCEIRA. — O doer-se do mal da culpa, em si mesma, atesta a bondade da vontade, à
qual esse mal se opõe. Doer-se porém do mal da pena, ou do mal da culpa, por causa da pena, atesta a
bondade da natureza, à qual o mal da pena se opõe. Por isso Agostinho diz, que a dor do bem perdido,
no suplício, é testemunho da natureza boa. Logo, o demônio, de vontade perversa e obstinada, não se
dói do mal da culpa.

## Art. 4 — Se o nosso ar é o lugar da pena dos demônios.
O quarto discute-se assim. — Parece que o nosso ar não é o lugar da pena dos demônios.

1. — Pois, o demônio é de natureza espiritual. Ora, a natureza espiritual não é afetada pelo lugar. Logo,
não há nenhum lugar de pena para os demônios.

2. Demais. — O pecado do homem não é mais grave que o do demônio. Ora, o lugar da pena do homem
é o inferno. Logo, muito mais, o do demônio. Logo, não o é o ar caliginoso.

3. Demais. — Os demônios são punidos pela pena do fogo. Ora, no ar caliginoso não há fogo. Logo, esse
ar não é o lugar a pena dos demônios.
Mas, em contrário, diz Agostinho, que o ar caliginoso é um quase cárcere para os demônios, até o
tempo do juízo.

SOLUÇÃO. — Os anjos, por natureza, são medianeiros entre Deus e os homens. Ora, está na ordem da
divina providência, que o bem dos seres inferiores seja obtido pelos superiores. O bem do homem,
porém, pode ser obtido duplamente pela divina providência. De um modo, diretamente; induzindo ao
bem e retraindo do mal, o que convenientemente se faz pelos anjos bons. De outro modo,
indiretamente: p. ex., quando alguém se exerce atacado pela impugnação de um contrário. E era
conveniente que esta obtenção do bem humano se realizasse pelos maus anjos, afim de que não fossem
eliminados totalmente, depois do pecado, da utilidade da ordem natural. Assim, pois, duplo lugar de
pena é devido aos demônios. Um, em razão da culpa, e esse é o inferno. Outro, porém, em razão da
exercitação humana e, esse é o ar caliginoso. Mas, como a busca da salvação humana se prolongará até
o dia do juízo, até então durará o ministério dos anjos e a exercitação causada pelos demônios. Por isso,
até então, também os bons anjos nos serão para cá mandados, e os demônios hão-de exercitar-nos
neste ar caliginoso; embora alguns destes estejam também agora no inferno, para atormentar os que
induziram ao mal, assim como alguns bons anjos estão com as almas santas no céu. Mas depois do dia
do juízo, todos os maus, homens e anjos, estarão no inferno; os bons, porém, no céu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um lugar não é de pena, para o anjo, nem para a alma,
porque lhes afete a natureza, alterando-a; mas porque lhes afeta a vontade, contristando-a, enquanto o
anjo ou a alma compreende estar num lugar, que não lhe convém à vontade.

RESPOSTA À SEGUNDA. — Uma alma, na ordem da natureza, não é superior a outra, como os
demônios, na ordem da natureza, são superiores aos homens. Por isso a razão não é a mesma.

RESPOSTA À TERCEIRA. — Alguns disseram que a pena sensível dos demônios e das almas, bem como a
beatitude dos santos, serão diferidas até o dia do juízo; o que é errôneo e repugna à sentença do
Apóstolo: Se a nossa casa terrestre desta morada for desfeita, temos um edifício no céu. Outros, porém,
embora não sejam da mesma opinião, quanto às almas, são-no quanto aos demônios. Mas é melhor
sentir que se deve fazer o mesmo juízo das almas más e dos maus anjos, de um lado, e das almas boas e
dos bons anjos, de outro. Donde, assim como o lugar celeste pertence à glória dos anjos e, contudo, esta
não diminui por virem eles a nós, porque consideram esse lugar como seu, do mesmo modo pelo qual
dizemos que a honra do bispo não diminui quando não se assenta atualmente na cátedra;
semelhantemente, embora os demônios não estejam atualmente ligados ao fogo da Geena, quando
estão em o ar caliginoso, contudo, por isso mesmo que sabem que essa prisão lhes é devida, a pena não
se lhes diminui. Por isso diz uma certa Glossa, que eles levam consigo o fogo da Geena para onde quer
que vão. Nem vai contra o dito da Escritura, que pediram ao Senhor que não os mandasse ir para o
abismo; porque assim o pediram reputando por pena se fossem excluídos do lugar em que podem
prejudicar aos homens. Por onde, em outra passagem se diz, que pediam-lhe instantemente que os não
lançasse fora do país.
Tratado da criação corpórea