# Questão 52: Da relação dos anjos com os lugares.
Em seguida se trata do lugar que ocupa o anjo. E, sobre este ponto, três artigos se discutem:

## Art. 1 — Se o anjo está em algum lugar.
(I Sent., dist. XXXVII, q. 3, a. 1; II, dist. VI, q. 1, a. 3; De Pot., q. 3, a. 19, ad 2; Quodl. I, q. 3, a. 1; Opusc.

XV, De Angelis, cap. XVIII)
O primeiro artigo discute-se assim. — Parece que o anjo não está em nenhum lugar.

1. — Pois, diz Boécio: A opinião comum entre os sábios, é que os seres incorpóreos não estão em
nenhum lugar; e Aristóteles diz que nem tudo o que existe está em algum lugar, mas só o corpo
móvel. Ora, o anjo não é corpo, como se demonstrou. Logo, o anjo não está num lugar.

2. Demais. — O lugar é uma quantidade com posição. Logo, tudo o que está em algum lugar tem alguma
situação. Ora, ter uma situação não pode convir ao anjo, cuja substância é independente da quantidade,
cuja propriedade diferencial é ter posição. Logo, o anjo não está em um lugar.

3. Demais. — Estar em um lugar é ser medido e contido por ele, como se vê pelo Filósofo. Ora, o anjo
não pode ser medido nem contido pelo lugar, porque o continente é mais formal que o conteúdo, como,
p. ex, o ar do que a água, como diz o Filósofo. Logo, o anjo não está em um lugar.
Mas em contrario é o que se diz na Coleta (do Completório): Os teus santos anjos, que habitam nessa
casa, nos guardem em paz.

SOLUÇÃO. — Convém ao anjo estar em um lugar, mas só equivocadamente é que se diz que o anjo e o
corpo estão num lugar. Pois, o corpo está em um lugar pelo ocupar, segundo o contato da quantidade
dimensiva; ora, esta não existe nos anjos, mas sim a quantidade virtual. Portanto, pela aplicação da
virtude angélica, de algum modo, a algum lugar, diz-se que o anjo está num lugar corpóreo.
Donde é claro que não se deve dizer que o anjo seja comensurado pelo lugar, ou que tenha uma
situação no contínuo. Pois, tal convém ao corpo situado num lugar enquanto dotado de quantidade
dimensiva. — Semelhantemente, também não se deve dizer tal, fundando-se em que o anjo seja contido
pelo lugar. Pois, a substância incorpórea, atingindo pela sua virtude a coisa corpórea, contém-na sem
que por essa seja contida. Assim, semelhantemente diz-se que o anjo está num lugar corpóreo, não
como contido, mas como contendo, de certo modo.
Donde resulta clara A RESPOSTA ÀS OBJEÇÕES.

## Art. 2 — Se o anjo pode estar em vários lugares simultaneamente.
(Supra, q. 8, a. 2, ad 2; infra, q. 112, a. 1; I Sent., dist. XXXVII, q. 3, a. 2; IV dist. X, q. 1, a. 3, qa. 2; Qu. De
Anima, a. 10, ad 18).
O segundo discute-se assim. — Parece que o anjo pode estar em vários lugares simultaneamente.

1. — Pois, não é menor a virtude do anjo que a da alma. Ora, a alma está simultaneamente em vários
lugares, por estar toda em qualquer parte do corpo, como diz Agostinho. Logo, o anjo pode estar em
vários lugares simultaneamente.

2. Demais. — O anjo está no corpo assumido; e, como tal corpo é contínuo, resulta que o anjo está em
qualquer parte dele. Ora, as diversas partes deste lhe determinam os diversos lugares. Logo, o anjo está
simultaneamente em vários lugares.

3. Demais. — Damasceno diz que o anjo opera onde está. Ora, Às vezes ele opera simultaneamente em
vários lugares, como se vê do anjo que subverteu Sodoma. Logo, o anjo pode estar em vários lugares
simultaneamente.
Mas em contrario diz Damasceno, que os anjos, estando no céu, não estão na terra.

SOLUÇÃO. — O anjo tem virtude e essência finitas. Pelo contrario, a essência e a virtude divina é infinita
e é a causa universal de tudo; por isso, tal virtude atinge todos os seres em toda parte e não só em
alguns lugares. Porém, a virtude do anjo, sendo finita, não atinge todos os seres, senão um ser
determinado. Ora, é necessário que o ser relativo a uma virtude, o seja como ser uno. Assim, pois, como
o universo dos seres se refere, como dotados de unidade, à universal virtude de Deus, assim qualquer
ser particular se refere, como um ser uno, à virtude angélica. Por onde, o anjo, estando em um lugar
pela aplicação de sua virtude a esse lugar, segue-se que não está em toda parte, nem em muitos
lugares, mas em um somente.
Mas, neste ponto, alguns se enganaram. Assim, certos, não podendo furtar-se à imaginação,
conceberam a indivisibilidade angélica como a do ponto; e por isso acreditaram que o anjo não pode
estar senão num lugar como o do ponto. — Porém manifestamente se enganaram. Pois o ponto é um
indivisível que tem uma situação, ao passo que o anjo é um indivisível existente fora do gênero da
quantidade e da situação. Por onde, não é necessário se lhe determine um lugar indivisível pela
situação, mas sim divisível ou indivisível, maior ou menor segundo aplique voluntariamente e mais ou
menos a sua virtude a um corpo. E assim a todo corpo ao qual ele se aplicar, pela sua virtude,
corresponder-lhe-á um lugar.
Nem contudo é necessário, se algum anjo move o céu, que esteja em toda parte. — Primeiro, porque a
sua virtude não se aplica senão ao que primariamente move. Ora, é uma a parte do céu na qual
primariamente está o movimento, a saber, a do oriente. Por isso, o Filósofo atribui à parte do oriente a
virtude de motor dos céus. — Segundo, porque não ensinam os filósofos que uma substância separada
mova todos os orbes imediatamente. E, por isso, não é necessário esteja ela em toda parte.
Por onde é claro que estar em um lugar convém diversamente ao corpo, ao anjo e a Deus. Pois, o corpo
está em um lugar circunscritivamente, porque é medido pelo lugar. O anjo, porém, não
circunscritivamente, por não ser medido pelo lugar, mas definitivamente, pois se está em um lugar é
que não está noutro. Deus, enfim, nem circunscritiva nem definitivamente, pois está em toda parte.
E daqui se deduz facilmente a RESPOSTA ÀS OBJEÇÕES; pois, tudo aquilo ao que se aplica a ação do
anjo, imediatamente, se lhe reputa por lugar, embora seja este contínuo.

## Art. 3 — Se vários anjos podem estar simultaneamente no mesmo lugar.
(I Sent., dist. XXXVII, q. 3, a. 3; De Pot., q. 3, a. 7, ad 11; a. 19, ad 1; Quodl. I, q. 3, a. 1, ad 2)
O terceiro discute-se assim. — Parece que vários anjos podem estar simultaneamente no mesmo
lugar.

1. — Pois, vários corpos não podem estar simultaneamente no mesmo lugar pelo encherem. Ora, os
anjos não o enchem, porque só o corpo enche o lugar de modo a não haver vácuo, como se vê pelo
Filósofo. Logo, vários anjos podem estar no mesmo lugar.

2. Demais. — O anjo e o corpo diferem entre si mais do que dois anjos. Ora, o anjo e o corpo podem
estar simultaneamente no mesmo lugar, por não haver nenhum lugar que não esteja cheio pelo corpo
sensível, como o prova Aristóteles. Logo, com maioria de razão, dois anjos podem estar no mesmo lugar.

3. Demais. — A alma está em qualquer parte do corpo, segundo Agostinho. Ora, os demônios, embora
não se intrometam na mente, intrometem-se, contudo, por vezes, nos corpos; e assim a alma e o
demônio estão no mesmo lugar. Logo, por semelhante razão, o mesmo se dá com quaisquer outras
substâncias espirituais.
Mas em contrario. — Duas almas não podem estar num mesmo corpo. Logo, pela mesma razão, nem
dois anjos poderão estar no mesmo lugar.

SOLUÇÃO. — Dois anjos não podem estar simultaneamente no mesmo lugar. E a razão é por ser
impossível duas causalidades completas procederem imediatamente de um mesmo agente. O que se
evidencia em todo gênero de causas, pois, uma é a forma próxima de uma coisa e um é o motor
próximo, embora possam existir vários motores remotos. Nem vale a instância apoiada no fato de vários
puxarem um navio; porque, como a força de cada um, por si, é insuficiente para movê-lo, nenhum deles
é o motor perfeito, mas todos, simultaneamente, exercem a função de um só motor, enquanto todas as
forças se agregam para produzirem um si movimento. Por onde, entendendo-se que o anjo está num
lugar porque sua virtude imediatamente ocupa um lugar ao modo de um continente perfeito, como já
se disse, em um mesmo lugar não pode estar senão um só anjo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não é o implemento o que impede estejam vários anjos
no mesmo lugar; mas outra causa, como já se disse.

RESPOSTA À SEGUNDA. — O anjo e o corpo não estão do mesmo modo num lugar. Por isso a objeção
não colhe.

RESPOSTA À TERCEIRA. — Também o demônio e a alma não se comparam com o corpo segundo a
mesma relação causal; pois, a alma é a forma do corpo, não, porém, o demônio. Por onde, a objeção
não colhe.