# Questão 1: Do que é e do que abrange a doutrina sagrada
Para que fique bem delimitado o nosso intento, cumpre investigar, primeiro, qual seja a doutrina
sagrada, em si mesma, e a que objetos se estende. Sobre este assunto discutem-se dez artigos:

## Art. 1 — Se, além das ciências filosóficas, é necessária outra doutrina.
(IIa IIae., q. 2, a. 3, 4; I Sent., prol., a. 1; I Cont. Gent., cap. IV, V; De Verit., q. 14, a. 10).
O primeiro discute-se assim — Parece desnecessária outra doutrina além das disciplinas filosóficas.

1. — Pois não se deve esforçar o homem por alcançar objetos que ultrapassem a razão, segundo a
Escritura (Ecle. 3, 22): Não procures saber coisas mais dificultosas do que as que cabem na tua
capacidade. Ora, o que é da alçada racional ensina-se, com suficiência, nas disciplinas filosóficas; logo,
parece escusada outra doutrina além das disciplinas filosóficas.

2. — Ademais, não há doutrina senão do ser, pois nada se sabe, senão o verdadeiro, que no ser se
converte. Ora, de todas as partes do ser trata a filosofia, inclusive de Deus; por onde, um ramo filosófico
se chama teologia ou ciência divina, como está no Filósofo. Logo, não é preciso que haja outra doutrina
além das filosóficas.
Mas, em contrário, a Escritura (2 Tm 3, 16): Toda a Escritura divinamente inspirada é útil para ensinar,
para repreender, para corrigir, para instruir na justiça. Porém, a Escritura, divinamente revelada, não
pertence às disciplinas filosóficas, adquiridas pela razão humana; por onde, é útil haver outra ciência,
divinamente revelada, além das filosóficas.

SOLUÇÃO. — Para a salvação do homem, é necessária uma doutrina conforme à revelação divina, além
das filosóficas, pesquisadas pela razão humana. Porque, primeiramente, o homem é por Deus ordenado
a um fim que lhe excede a compreensão racional, segundo a Escritura (Is 64, 4): O olho não viu, exceto
tu, ó Deus, o que tens preparado para os que te esperam. Ora, o fim deve ser previamente conhecido
pelos homens, que para ele têm de ordenar as intenções e atos. De sorte que, para a salvação do
homem, foi preciso, por divina revelação, tornarem-se-lhe conhecidas certas verdades superiores à
razão.
Mas também naquilo que de Deus pode ser investigado pela razão humana, foi necessário ser o homem
instruído pela revelação divina. Porque a verdade sobre Deus, exarada pela razão, chegaria aos homens
por meio de poucos, depois de longo tempo e de mistura com muitos erros; se bem do conhecer essa
verdade depende toda a salvação humana, que em Deus consiste. Logo, para que mais conveniente e
segura adviesse aos homens a salvação, cumpria fossem, por divina revelação, ensinados nas coisas
divinas. Donde foi necessária uma doutrina sagrada e revelada, além das filosóficas, racionalmente
adquiridas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora se não possa inquirir pela razão o que sobrepuja
a ciência humana, pode-se entretanto recebê-lo por fé divinamente revelada. Por isso, no lugar citado
(Ecle 3, 25), se acrescenta: Muitas coisas te têm sido patenteadas que excedem o entendimento dos
homens. E nisto consiste a sagrada doutrina.

RESPOSTA À SEGUNDA. — O meio de conhecer diverso induz a diversidade das ciências. Assim, o
astrônomo e o físico demonstram a mesma conclusão, p. ex., que a terra é redonda; se bem o
astrônomo, por meio matemático, abstrato da matéria; e o físico, considerando a mesma. Portanto,
nada impede que os mesmos assuntos, tratados nas disciplinas filosóficas, enquanto cognoscíveis pela
razão natural, também sejam objeto de outra ciência, enquanto conhecidos pela revelação divina.
Donde a teologia, atinente à sagrada doutrina, difere genericamente daquela teologia que faz parte da
filosofia.

## Art. 2 — Se a doutrina sagrada é ciência.
(IIa IIae., q.1, a. 5, ad 2; I Sent., prol., a. 3. qa. 2; De Verit., q. 14 a. 9, ad 3; in Boet., De Trin., q. 2, a. 2)
O segundo discute-se assim — Parece não ser ciência a doutrina sagrada.

1. — Pois toda ciência provém de princípios por si evidentes, ao passo que procede a doutrina sagrada
dos artigos da fé, inevidentes em si, por serem não universalmente aceitos; porque a fé não é de todos,
diz a Escritura (2 Ts 3, 2). Logo, não é ciência a doutrina sagrada.

2. — Ademais, do indivíduo não há ciência. Mas a doutrina sagrada trata de fatos individuais, como
sejam os feitos de Abraão, Isaac, Jacó e semelhantes. Logo, não é ciência a doutrina sagrada.
Mas, em contrário, Agostinho: A esta ciência só aquilo se atribui com que se gera, nutre, defende e
corrobora a fé salubérrima. Ora, a nenhuma ciência pertence tal, senão à doutrina sagrada. Por onde, é
ciência a doutrina sagrada.

SOLUÇÃO. — A doutrina sagrada é ciência. Porém, cumpre saber que há dois gêneros de ciências. Umas
partem de princípios conhecidos à luz natural do intelecto, como a aritmética, a geometria e
semelhantes. Outras provém de princípios conhecidos por ciência superior; como a perspectiva, de
princípios explicados na geometria, e a música, de princípios aritméticos. E deste modo é ciência a
doutrina sagrada, pois deriva de princípios conhecidos à luz duma ciência superior, a saber: a de Deus e
dos santos. Portanto, como aceita a música os princípios que lhe fornece o aritmético, assim a doutrina
sagrada tem fé nos princípios que lhe são por Deus revelados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os princípios de qualquer ciência, ou são por si mesmos
evidentes, ou se reduzem à evidência de alguma ciência superior. E tais são os princípios da doutrina
sagrada, como dissemos.

RESPOSTA À SEGUNDA. — Na doutrina sagrada, os fatos individuais não são tratados principalmente,
senão apenas introduzidos a título de exemplo prático, como nas ciências morais; ou também no intuito
de apurar a autoridade dos homens que nos transmitiram a revelação divina, na qual se funda a Sagrada
Escritura ou doutrina.

## Art. 3 — Se a doutrina sagrada é uma só ciência.
(I Sent., prol., a. 2, 4)
O terceiro discute-se assim — Não parece uma só ciência a doutrina sagrada.

1. — Pois, como diz o Filósofo, cada ciência se ocupa com um só gênero de objetos. Ora, criador e
criatura, objetos da doutrina sagrada, não pertencem ao mesmo gênero. Logo, não é uma só ciência a
doutrina sagrada.

2. — Ademais, a doutrina sagrada trata dos anjos, das criaturas corpóreas e dos costumes humanos, se
bem tais assuntos respeitem a ciências filosóficas diversas. Por onde, não é uma só ciência a doutrina
sagrada.
Mas, em contrário, a ela se refere a Sagrada Escritura no singular, quando diz (Sb 10, 10): E lhe deu a
ciência dos santos.

SOLUÇÃO. — É só uma ciência a doutrina sagrada. Pois, da potência, como do hábito, deve-se
determinar a unidade pelo respectivo objeto, considerado na idéia formal e não materialmente. Assim:
homem, asno e pedra convêm num só conceito formal de cor, objeto da potência visiva. Ora,
considerando a Sagrada Escritura vários assuntos como divinamente revelados, conforme dissemos
antes (a. 1 ad 2), todas as coisas divinamente reveláveis comunicam num só conceito formal do objeto
desta ciência. Donde as abrange a doutrina sagrada como sendo uma só ciência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A doutrina sagrada não assenta conclusões a título igual
sobre Deus e as criaturas, mas sim de Deus principalmente, e das criaturas enquanto se referem a Deus
como princípio ou fim; o que não tolhe a unidade da ciência.

RESPOSTA À SEGUNDA. — Nada impede se distingam as potências inferiores ou hábitos por objetos,
todos dependentes de uma potência ou hábito superior; pois estes últimos consideram o objeto por
modo formalmente mais extenso. Assim, o sentido comum tem por objeto o sensível, que abrange o
visível e o audível; por onde, apesar de ser uma só potência, estende-se a todos os objetos dos cinco
sentidos. Semelhantemente, a doutrina sagrada, suposto seja uma somente, pode ocupar-se com os
objetos de ciências filosóficas diversas, sob um aspecto, enquanto reveláveis divinamente; de modo que
ela parece impressão da ciência divina, saber simples e singular de todos os objetos.

## Art. 4 — Se a doutrina sagrada é ciência prática.
(I Sent., prol. a. 3, q. 1)
O quarto discute-se assim — Parece que a doutrina sagrada é uma ciência prática.

1. — Pois, segundo o Filósofo, no livro II da Metafísica, o fim do saber prático é o operar; e a doutrina
sagrada à operação se ordena, conforme a Escritura (Tg 1, 22): Sede, pois, fazedores da palavra, e não
ouvintes tão somente. Logo, é ciência prática.

2. Demais — A doutrina sagrada abrange a lei antiga e a nova. Ora, a lei respeita à ciência moral, que é
prática. Donde, é ciência prática a doutrina sagrada.
Mas, em contrário, toda ciência prática tem por objeto as coisas factíveis pelo homem; v.g. a moral, os
atos humanos e a arquitetura, os edifícios. Ora, a doutrina sagrada tem por objeto principal Deus, de
quem, pelo contrário, são obras os seres humanos. Por onde, não é ciência prática, mas, antes,
especulativa.

SOLUÇÃO. — A doutrina sagrada, sendo uma única ciência, como dissemos antes (a. 3 ad 2), contém os
objetos de várias disciplinas filosóficas pelo aspecto formal, que neles considera, de serem cognoscíveis
à luz divina. Donde, embora nas ciências filosóficas, seja uma a especulativa, e outra, a prática, a
sagrada doutrina compreende o objeto de ambas; bem como Deus, pela mesma ciência, conhece o
próprio ser e suas obras. Contudo, é mais especulativa que prática, por conhecer antes das coisas
divinas que dos atos humanos, tratando destes enquanto o homem, por eles, se ordena ao
conhecimento perfeito de Deus, essência da felicidade eterna.
Donde resultam claras as RESPOSTAS ÀS OBJEÇÕES.

## Art. 5 — Se a doutrina sagrada é mais digna que as outras ciências.
(IIa IIae, q. 66, a. 5, ad 3; I Sent., prol., a.1; II Cont. Gent., cap. IV)
O quinto discute-se assim — Parece não ser a doutrina sagrada mais digna que as outras ciências.

1. — Pois é digno o saber enquanto certo; e as demais ciências, que partem de princípios indubitáveis,
parecem mais certas que a doutrina sagrada, cujos princípios, ou artigos de fé, são sujeitos à dúvida.
Donde, as outras ciências parecem mais dignas que ela.

2. Demais — a ciência inferior aproveita-se da superior; assim, do aritmético, o músico. Ora, a doutrina
sagrada recebe algo das disciplinas filosóficas, pois, diz Jerônimo, os doutores antigos de tal modo
encheram os livros de doutrinas e sentenças dos filósofos, que não sabemos o que mais seja neles de
admirar: se a erudição secular ou a ciência das Escrituras. Logo, a doutrina sagrada é inferior às outras
ciências.
Mas, em contrário, as demais ciências são chamadas escravas desta, segundo a Escritura (Pr 9, 3): Enviou
as suas escravas a chamar à fortaleza.

SOLUÇÃO. — A dita ciência, por ser especulativa a um respeito e a outro, prática, sobreleva a todas as
demais, tanto especulativas como práticas. Pois, das ciências especulativas, uma é considerada mais
digna que outra, quer pela certeza, quer pela nobreza do assunto; e, de ambos os pontos-de-vista
excede esta ciência às outras especulativas. Quanto à certeza, porque as outras a têm pelo lume natural
da razão humana, que pode errar, e a possui esta pela luz da ciência divina, que se não pode enganar.
Quanto à nobreza do assunto, porque esta versa principalmente sobre matérias que, pela sua
profundeza, ultrapassam a razão; considerando as outras só aquilo que se pode alcançar racionalmente.
— Das ciências práticas, mais digna é aquela que não é subordinada a um fim ulterior; assim, a civil
supera a militar, pois o bem do exército se subordina ao do Estado. Ora, o fim da doutrina sagrada,
enquanto prática, é a eterna felicidade, para a qual se ordenam, como ao fim último, todos os outros
fins das ciências práticas. Por onde, é manifesto que, a todas as luzes, é mais digna que as outras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Nada impede ser o mais certo, por natureza, menos
certo, pelo que nos toca, por causa da fraqueza do nosso intelecto, que está para as coisas mais
evidentes como os olhos da coruja para a luz do sol, como diz Aristóteles. Donde, a dúvida de certos
sobre os artigos da fé não provém da incerteza do assunto, senão da fraqueza do intelecto humano; se
bem o mínimo conhecimento que pudermos adquirir das coisas altíssimas é mais desejável que o
conhecimento certíssimo de coisas mínimas, conforme o Filósofo.

RESPOSTA À SEGUNDA. — Esta ciência pode receber auxílio das filosóficas, não por lhe serem
indispensáveis, mas para maior clareza dos assuntos de que trata. Porém, das outras ciências não
recebe os seus princípios, senão de Deus, por imediata revelação. Nem, portanto, recebe das outras
ciências como de superiores, senão que delas usa como inferiores e servas, como as arquitetônicas, das
auxiliares e a civil, da militar. E esse mesmo usar delas não é por defeito ou insuficiência sua, e sim por
imperfeição do nosso entendimento, que das coisas conhecidas pela razão natural (donde procedem as
outras ciências) mais facilmente é levado para aquelas que a sobrepujam e são o objeto desta ciência.

## Art. 6 — Se esta doutrina é sabedoria.
(I Sent., prol., a. 3, qI, 3; II Cont. Gent., cap. IV)
O sexto discute-se assim — Parece que esta doutrina não é sabedoria.

1. Pois nenhuma doutrina que receba de outra os seus princípios, merece o nome de
sabedoria, cabendo ao sábio ordenar e não ser ordenado, como diz Aristóteles. Ora, esta doutrina
recebe de outra os seus princípios, como do sobredito aparece (a. 2). Logo, não é sabedoria.

2. Demais — À sabedoria compete provar os princípios das outras ciências, por onde é chamada cabeça
das demais, como se vê no Filósofo. Ora, não justifica esta doutrina os princípios das outras ciências,
nem é, portanto, sabedoria.

3. Demais — Adquire-se esta doutrina pelo estudo, mas recebemos a sabedoria por infusão, e, por isso,
se conta entre os sete dons do Espírito Santo, como se vê na Escritura (Is 2,2). Logo, esta doutrina não é
sabedoria.
Mas, em contrário, a Escritura (Dt 4, 6): Porque nisto mostrarei a vossa sabedoria e inteligência aos
povos.

SOLUÇÃO. — De toda a sabedoria humana, é esta doutrina a mais alta, não relativa, mas
absolutamente. Pois sendo próprio do sábio ordenar e julgar, e, pela causa mais alta, considerar as
inferiores, sábio se chama, em qualquer gênero, quem lhe atende à altíssima causa. Assim, no tocante à
construção, o artífice que traça a planta da casa é chamado sábio e arquiteto, em relação aos operários
inferiores, que aplainam a madeira e preparam as pedras; donde o dito da Escritura (1 Cor 3,10): Lancei
o fundamento como sábio arquiteto. Também, no que respeita à vida humana em conjunto, é o
prudente chamado sábio, enquanto ordena os atos humanos ao fim obrigatório; donde outro dito da
Escritura (Pr 10, 23): A sabedoria é, para o homem, prudência. Quem, portanto, considera a causa
absoluta mais alta do universo, que é Deus, deve ser chamado sábio por excelência. Pelo que também
se define a sabedoria conhecimento das coisas divinas, como se vê em Agostinho. Ora, o próprio da
sagrada doutrina é considerar a Deus, causa altíssima, não só enquanto cognoscível por meio das
criaturas — o que souberam os filósofos, como diz a Escritura (Rm 1, 19): O que se pode conhecer de
Deus lhes é manifesto — senão também naquilo que só ele de si mesmo conhece e foi aos outros
revelado e comunicado. Por isso, tal doutrina em sumo grau merece o nome de sabedoria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não recebe a sagrada doutrina os seus princípios de
nenhum saber humano, senão da ciência divina, a qual regula todo o nosso conhecimento, a título de
suprema sabedoria.

RESPOSTA À SEGUNDA. — Os princípios das demais ciências ou são por si evidentes, e não podem ser
provados; ou se demonstram noutra ciência por algum motivo natural. Porém, o conhecimento próprio
desta ciência assenta na revelação, e não em premissas naturais. Donde, não lhe cabe provar os
princípios das outras ciências, mas só julgá-las; porque tudo o que nelas repugnar à verdade desta,
condena-se, de vez, como falso, segundo o Apóstolo (2 Cor 10, 4-5): Derribando os conselhos e toda a
altura que se levanta contra a ciência de Deus.

RESPOSTA À TERCEIRA. — Por ser o juízo próprio do sábio, e por haver dois modos de julgar, deve a
sabedoria ter dois sentidos. O primeiro modo de julgar é por inclinação: por exemplo, quem tiver bons
costumes, por atração da virtude, pode com acerto julgar dos atos que se devem praticar moralmente.
Por isto está em Aristóteles: o virtuoso é medida e regra dos atos humanos. — O segundo modo é pelo
conhecimento: como o instruído na ciência moral poderia julgar dos atos de virtude, mesmo se a não
tivesse. Ora, o primeiro modo de julgar as coisas divinas pertence à sabedoria enquanto dom do Espírito
Santo, segundo a Escritura (1 Cor 2,15):O espiritual julga todas as coisas; e Dionísio: Hieroteu é douto,
não só por aprender mas, antes, por sentir as coisas divinas. O segundo modo de julgar é próprio desta
doutrina, enquanto se adquire por estudo, embora sejam os princípios recebidos pela revelação.

## Art. 7 — Se Deus é o objeto desta ciência.
(I Sent. Prol., a. 4; in Boet., De Trin., q. 5, a. 4).
O sétimo discute-se assim — Parece não ser Deus o objeto desta ciência.

1. — Pois é necessário, em qualquer ciência, supor a essência do objeto, segundo o Filósofo. Ora, esta
ciência não supõe a essência de Deus, pois, diz Damasceno: É impossível assinalar a essência divina.
Donde, não é Deus o objeto desta ciência.

2. Demais — abrange o objeto da ciência tudo o que ela trata. Porém, na sagrada doutrina, há muitos
outros assuntos além de Deus, p. ex.: as criaturas e os costumes humanos. Logo, não é Deus o objeto
desta ciência.
Mas, em contrário, objeto da ciência é o assunto nela principalmente tratado. Ora, Deus é o assunto
principal desta ciência, pois é chamada teologia ou tratado de Deus. Logo, Deus é o objeto desta ciência.

SOLUÇÃO. — Deus é o objeto desta ciência, porque o objeto está para a ciência como para a potência
ou hábito. Ora, propriamente, é considerado objeto de potência ou hábito aquilo sob cujo aspecto se
lhes refere qualquer coisa. Donde, referindo-se à vista, enquanto coloridos, o homem e a pedra, é a cor
o objeto próprio da vista. Ora, a sagrada doutrina tudo trata com referência a Deus, por tratar ou do
mesmo Deus ou das coisas que lhe digam respeito, como princípio ou fim. Pelo que, é Deus,
verdadeiramente, o objeto desta ciência — o que também se demonstra pelos princípios da dita ciência,
ou artigos da fé, de que Deus é objeto. Ora, idêntico objeto têm os princípios e toda a ciência, por estar
a última, total e virtualmente, contida nos princípios. — Certos, porém, atendendo às matérias tratadas
e não ao ponto-de-vista, a esta ciência assinalaram outro objeto; como, a realidade e os símbolos, ou as
obras da reparação; ou todo Cristo, i.é., a cabeça e os membros. E, com efeito, são consideradas nesta
ciência todas essas matérias, se bem com relação a Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora seja impossível conhecermos a essência divina,
contudo nesta doutrina, lhe usamos do efeito, no domínio natural ou da graça, em vez da definição da
causa, para daí tirar as conclusões da ordem divina, consideradas na mesma doutrina. Assim como, em
certas ciências filosóficas, pelo efeito se demonstra algo da causa, tomando aquele em lugar da
definição desta.

RESPOSTA À SEGUNDA. — Todos os demais assuntos tratados na doutrina sagrada estão incluídos em
Deus, não como partes, espécies ou acidentes, mas como a ele de certo modo ordenados.

## Art. 8 — Se esta doutrina é argumentativa.
(IIa IIae, q. I, a. 5, ad 2; I Sent., prol., a. 5; I Cont. Gent., cap. IX; in Boet., De Trin., q. 2, a. 3; Quodlib., IV,
q. 9, a.3)
O oitavo discute-se assim — Parece que esta doutrina não é argumentativa.

1. — Pois, diz Ambrósio: Deixa os argumentos quando se procura a fé. Ora, por esta doutrina
procuramos principalmente a fé, pelo que diz a Escritura (Jo 20, 31): Foram escritos
estes (prodígios) afim de que vós creais. Logo, a doutrina sagrada não é argumentativa.

2. Demais — se for argumentativa, há de sê-lo pela autoridade ou pela razão. Se pela autoridade tal não
lhe parece caber à dignidade, pois fragilíssimo é o argumento de autoridade, conforme Boécio. Se pela
razão, isso não lhe convém ao fim, porque, segundo Gregório, não tem mérito a fé onde a razão fornece
a prova. Donde, não é argumentativa a doutrina sagrada.
Mas, em contrário, diz a Escritura (Tt 1, 9) a respeito do bispo: Que abrange a palavra fiel, que é segundo
a doutrina, para que possa exortar conforme à sã doutrina e convencer aos que o contradizem.

SOLUÇÃO. — Como as outras ciências não argumentam para provar os seus princípios, mas, com estes,
raciocinam para demonstrar outros pontos, assim também, não argumenta esta doutrina para provar os
seus princípios ou artigos da fé, senão que destes procede para mostrar outra verdade. Assim é que o
Apóstolo (1 Cor 15) argumenta com a ressurreição de Cristo para provar a de todos os homens.
Cumpre, no entanto, considerar que as ciências filosóficas inferiores nem provam os seus princípios,
nem disputam contra aqueles que os negam, mas isto deixam para a ciência superior. Porém, dentre
elas, a suprema, a saber, a Metafísica, discute contra quem lhe nega os princípios, se o adversário
concede algum ponto; mas, se nada concede, não se pode com ele discutir, bem que se lhe possam
refutar as objeções. Da mesma forma, a sagrada doutrina, por não ter nenhuma superior, disputa contra
quem lhe nega os princípios, com argumentos, se o adversário conceder algum ponto revelado; e assim,
com as autoridades da doutrina sagrada, discutimos contra os hereges e, por um artigo da fé, contra os
negadores de outro. Se, porém, o adversário não acredita em ponto algum da revelação divina, já não
há meio para lhe provar com razões os artigos da fé, mas, sim, para lhe refutar as objeções contra esta,
porventura assacadas. Porque, assentando a fé na verdade infalível, e sendo impossível demonstrar o
contrário da verdade, claro está que as razões dirigidas contra a fé não são demonstráveis, senão
argumentos refutáveis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora não tenham cabimento, para provar os pontos
da fé, os argumentos da razão humana, todavia, com os artigos da fé, esta doutrina argumenta para
provar outras verdades, segundo o sobredito.

RESPOSTA À SEGUNDA. — Muitíssimo próprio a esta doutrina é o argumentar por autoridade, sendo-
lhe os princípios obtidos pela revelação; pelo que é mister acreditar na autoridade daqueles a quem a
revelação foi feita. Nem isso derroga à dignidade de tal doutrina; pois, embora fragilíssima a autoridade
fundada na razão humana, eficacíssima é contudo a quem assenta na revelação divina.
Apesar disso, a doutrina sagrada também usa da razão humana, não, por certo, para provar a fé, o que
lhe suprimiria o mérito, senão para manifestar, de algum modo, ensinamentos seus. Pois, como a graça
não tolhe, mas aperfeiçoa a natureza, importa que a razão humana preste serviços à fé, assim como a
inclinação natural da vontade está às ordens da caridade. No mesmo sentido julga a Escritura (2 Cor
10,5): Reduzindo a cativeiro todo o entendimento para que obedeça a Cristo. Donde provém que a
doutrina sagrada até lança mão da autoridade dos filósofos, nos assuntos em que pela razão natural
puderam conhecer a verdade. Assim, Paulo alega a palavra de Arato (At 17, 28): Como disseram ainda
alguns de vossos poetas: Que somos linhagem divina.
Porém, de tais autoridades se aproveita a doutrina sagrada como de argumentos estranhos e prováveis,
ao passo que emprega as autoridades dos escritores canônicos como argumentos próprios e
necessários. Quanto às autoridades dos outros doutores da Igreja, delas usa como argumentos próprios
mas de valor provável. Porque a nossa fé se apóia na revelação feita aos Apóstolos e Profetas, que
escreveram os livros canônicos; não, porém, na revelação porventura feita aos demais doutores. Donde
o dizer Agostinho: Somente aos livros da Escritura, chamados canônicos, aprendi a deferir a honra de
crer firmissimamente que nenhum dos seus autores erraram, que os escreveram. Os outros escritores,
porém, por mais eminentes que sejam na santidade ou na doutrina, eu os leio de modo a não ter por
verdadeira uma sentença só porque foi por eles aceita ou escrita.

## Art. 9 — Se a doutrina sagrada deve usar de metáforas.
(I Sent. Prol., a. 5; dist. XXXIV, q. 3, a. 1.2; III Cont. Gent., cap. CXIX; in Boet. De Trin., q. 2, a. 4)
O nono discute-se assim — Parece não dever a doutrina sagrada usar de metáforas.

1. — Pois o que é próprio de doutrina ínfima não pode convir a esta ciência, que ocupa, entre todas, o
lugar supremo, como já se disse (a. 5). Ora, proceder por comparações e representações é próprio da
poética, ínfima entre todas as doutrinas. Logo, usar de tais comparações não convém a esta ciência.

2. Demais — esta doutrina considera-se como ordenada à manifestação da verdade e, por isso, prêmio é
prometido aos seus expositores (Eccle 24, 31): Aqueles que me esclarecem têm a vida eterna. Ora, nas
comparações, a verdade se oculta. Logo, não convém a esta doutrina ensinar as coisas divinas por
comparação com as corpóreas.

3. Demais — quanto mais sublimes as criaturas, tanto mais se assemelham a Deus. Se, pois, algumas
delas são assimiladas, metaforicamente, a Deus, para tal hão de, necessariamente e sobretudo, ser
escolhidas as mais sublimes e não as ínfimas; o que, entretanto freqüentemente se encontra na
Escritura.
Mas, em contrário, a Escritura (Os 12, 10): Eu lhes multipliquei as visões; e pela mão dos mesmos
profetas fui representado. Ora, transmitir alguma coisa, com semelhança, é metafórico. Logo, é próprio
da doutrina sagrada usar de metáforas.

SOLUÇÃO. — É conveniente à Sagrada Escritura transmitir as coisas divinas e espirituais por
comparações metafóricas com as corpóreas. Pois, provendo Deus a todos, segundo a natureza de cada
um, e sendo natural ao homem chegar, pelos sensíveis, aos inteligíveis — pois todo o nosso
conhecimento começa pelos sentidos — convenientemente, a Sagrada Escritura nos transmite as coisas
espirituais por comparações metafóricas com as corpóreas. E é isto o que diz Dionísio: É impossível
alumiar-nos o raio divino sem ser circumvelado pela variedade dos véus sagrados.
Também convém à Sagrada Escritura, comumente proposta a todos, segundo o Apóstolo (Rm 1, 14) —
Eu sou devedor a sábios e a ignorantes — propor as coisas espirituais por comparações com as
corpóreas para que, ao menos assim, as compreendam os rudes, não idôneos para conceber os
inteligíveis em si.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A poética usa de metáforas para representar, pois a
representação é naturalmente deleitável ao homem. Ao passo que a doutrina sagrada dela usa por
necessidade e utilidade, como se disse.

RESPOSTA À SEGUNDA. — O raio da divina revelação não se destrói, como diz Dionísio, pelas figuras
sensíveis que o velam, mas persiste na sua verdade. E não permitem, assim, que permaneçam nas
semelhanças os espíritos aos quais foi feita a revelação; antes, eleva-os ao conhecimento dos inteligíveis
e, por eles também outros se instruem no referente a tais assuntos. Por onde, o que em um lugar da
Escritura é exposto metaforicamente, o é, em outros, mais expressamente. E, ainda o próprio ocultar
das figuras é útil, para exercício dos estudiosos e contra a irrisão dos infiéis, dos quais diz o Evangelho
(Mt 7, 6): Não deis aos cães o que é santo.

RESPOSTA À TERCEIRA. — Como ensina Dionísio, é mais conveniente, pelas três razões seguintes, que
as coisas divinas se transmitam, na Escritura, sob figura de corpos vis, do que sob a de corpos nobres —
Primeiro, porque, assim, mais a alma humana se livra do erro; pois é manifesto que tais coisas não se
dizem propriamente de Deus. O que poderia ser dúbio se as coisas divinas fossem descritas sob figuras
de corpos nobres, sobretudo para aqueles que nada de mais nobre conhecem que os corpos. —
Segundo, por ser este método mais conforme ao conhecimento que temos de Deus nesta vida; pois
dele, mais do que aquilo que é, se nos manifesta o que não é. Por onde, as semelhanças com as coisas
mais afastadas de Deus, mais verdadeiro nos tornam pensar, que as ultrapassa o que de Deus dizemos
ou cogitamos. — Terceiro, porque assim mais se ocultam aos indignos as coisas divinas.

## Art. 10 — Se na Sagrada Escritura uma mesma letra tem vários sentidos: o histórico ou literal, o alegório, o tropológico ou moral e o anagógico.
(I Sent., prol., a. 5; IV, dist XXI, q.1, a.2, qa 1, ad 3; De Pot., q. 4, a. 1; Quodlib., III, q. 14, a. 1; VIII, q. 6; ad
Gal., c. IV, lect. VII)
O décimo discute-se assim — Parece que na Sagrada Escritura, uma mesma letra não tem vários
sentidos: o histórico ou literal, o alegórico, o tropológico ou moral e o anagógico.

1. — Pois a multiplicidade dos sentidos, num escrito, gera a confusão e o engano e obsta à segurança da
argüição. Donde, não resulta nenhuma argumentação da multiplicidade de proposições, causa esta,
antes, de sofismas. Ora, a Escritura Sagrada deve ser eficaz para mostrar a verdade, sem nenhuma
falácia. Logo, nela não deve haver, numa mesma letra, vários sentidos.

2. Demais — diz Agostinho: A Escritura chamada Antigo Testamento transmite-se quadriformemente:
pela história, pela etiologia, pela analogia e pela alegoria. Ora, essas quatro formas são completamente
diferentes das quatros supra enumeradas. Logo, não é admissível que a mesma letra da Escritura
Sagrada se exponha nos quatro sentidos preditos.

3. Demais — além dos sentidos preditos, há o parabólico, não contido nos quatro.
Mas, em contrário, Gregório: A Sagrada Escritura, pelo modo mesmo da sua locução, transcende todas
as ciências; pois, com a mesma expressão, assim narra o feito como expõe o mistério.

SOLUÇÃO. — O autor da Sagrada Escritura é Deus, em cujo poder está dar significação não só às
palavras, o que também o homem pode fazer, mas ainda às próprias coisas. Por isso, além do que se dá
com todas as ciências, nas quais as palavras têm significação, esta ciência tem de próprio que as coisas
mesmas significadas pelas palavras, por sua vez, também significam. Ora, a primeira significação, pela
qual as palavras exprimem as coisas, é a do primeiro sentido, que é o histórico ou literal. E a significação
pela qual as coisas expressas pelas palavras têm ainda outras significações, chama-se sentido espiritual,
que se funda no literal e o supõe. Mas, este sentido espiritual tem três subdivisões. Pois, como diz o
Apóstolo (Heb 7, 19), a lei antiga é figura da nova e esta, por sua vez, como diz Dionísio, o é da glória
futura; e, demais, na lei nova, as coisas feitas pelo chefe são sinais das que nós devemos fazer. Ora,
quando as coisas da lei antiga significam as da nova, o sentido é alegórico; quando as realizadas em
Cristo, ou nos que o que significam, são sinais das que devemos fazer, o sentido é moral; e quando
significam as coisas da glória eterna, o sentido é anagógico.
Mas como o sentido literal é o que o autor tem em vista, e o autor da Sagrada Escritura é Deus, cuja
inteligência tudo compreende simultaneamente, não há inconveniente, como diz Agostinho, se, mesmo
no sentido literal, uma expressão da Sagrada Escritura tem vários sentidos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A multiplicidade de tais sentidos não gera o equívoco
nem nenhuma outra espécie de multiplicidade; pois, como já se disse, esses sentidos se multiplicam,
não por ter uma palavra muitas significações, mas porque as próprias coisas significadas pelas palavras
podem ser sinais de outras coisas. Donde o não haver nenhuma confusão na Sagrada Escritura, por se
fundarem todos os sentidos em um, o literal, com o qual somente se pode argumentar, e não com o
sentido alegórico, como diz Agostinho. Mas, nem por isso, nada se perde da Escritura Sagrada; pois, não
há nada de necessário à fé, contido no sentido espiritual, que ela não explique manifestamente, alhures,
no sentido literal.

RESPOSTA À SEGUNDA. — A história, a etiologia, a analogia pertencem a um mesmo sentido literal.
Pois, como expôs o próprio Agostinho, a história propõe algo pura e simplesmente; a etiologia assinala a
causa de uma expressão, como quando o Senhor assinalou a causa por que Moisés deu licença de
repudiar as mulheres, isto é, pela dureza do coração dos hebreus; a analogia mostra que a verdade de
um passo da Escritura não repugna à de outro. Ora, dentre as quatro divisões propostas, só a alegoria
abrange os três sentidos espirituais. E, assim, Hugo de São Vitor compreende, no sentido alegórico,
também o anagógico, admitindo somente três sentidos: o histórico, o alegórico e o tropológico.

RESPOSTA À TERCEIRA. — O sentido parabólico se contém no literal, pois as palavras têm uma
significação própria e outra figurada; e nem é o sentido literal a figura, mas o figurado. Pois, quando a
Escritura se refere ao braço de Deus, o sentido literal não é que, em Deus, há esse membro corpóreo,
mas o que é por tal membro significado, i.e, a virtude operativa.
Por onde se vê que nunca pode haver falsidade no sentido literal da Escritura Sagrada.
Tratado De Deo Uno