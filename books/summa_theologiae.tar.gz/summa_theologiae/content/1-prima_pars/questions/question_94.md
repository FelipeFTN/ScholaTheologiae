# Questão 94: Do estado e da condição do primeiro homem, quanto ao intelecto.
Em seguida devemos tratar do estado ou da condição do primeiro homem. E, primeiro quanto à alma.
Segundo, quanto ao corpo.
Sobre o primeiro ponto duas questões se discutem. Primeira da condição do homem quanto ao
intelecto. Segunda, da condição do homem quanto à vontade.
Sobre a primeira questão quatro artigos se discutem:

## Art. 1 — Se o primeiro homem via a Deus em essência.
O primeiro discute–se assim. – Parece que o primeiro homem via a Deus em essência.

1. Pois, a beatitude do homem consiste na visão de Deus. Ora, o primeiro homem, vivendo no paraíso,
tinha uma vida feliz e rica de todos os bens, como diz Damasceno. E Agostinho: Se os homens tinham os
seus afetos, como agora os temos, como eram felizes naquele lugar de inenarrável beatitude, isto é, no
paraíso? Logo, o primeiro homem, no paraíso, via a Deus em essência.

2. Demais. – Agostinho diz: ao primeiro homem não faltava nada do que a boa vontade pode alcançar.
Ora, nada de melhor pode alcançar a boa vontade do que a visão da divina essência. Logo, o homem via
a Deus em essência.

3. Demais. – Pela visão de Deus em essência, vê–se a Deus, sem termo médio e sem enigma. Ora, o
homem, no estado de inocência, via a Deus sem termo médio, como diz o Mestre das Sentenças.
Também o via sem enigma, porque, como diz Agostinho, o enigma importa obscuridade, e esta foi
introduzida pelo pecado. Logo, o homem, no primeiro estado, via a Deus por essência.
Mas, em contrário, diz a Escritura: Não primeiro o que é espiritual, senão o que é animal. Ora, o que é
espiritual em máximo grau é ver a Deus em essência. Logo, o primeiro homem, no primeiro estado da
vida animal, não via a Deus em essência.

SOLUÇÃO. – O primeiro homem não via a Deus em essência, no estado comum da sobredita vida; a
menos que não se diga que o visse em rapto, quando infundiu o Senhor Deus um profundo sono a Adão,
segundo refere a Escritura. E a razão é que, sendo a divina essência a beatitude mesma, o intelecto de
quem vê tal essência está para Deus como qualquer homem está para a beatitude. Ora, é manifesto que
nenhum homem pode, voluntariamente, deixar de querer a felicidade; pois, natural e necessariamente
o homem a busca, e foge da infelicidade. Por onde ninguém que veja a Deus em essência pode afastarse
dele voluntariamente e pecar. Por isso todos os que assim o vêm estão de tal modo consolidados no
amor de Deus, que não poderão pecar, eternamente. Ora, como Adão pecou, é claro que não via a Deus
em essência.
Conhecia–o, todavia, por um certo conhecimento mais elevado que aquele com o qual agora o
conhecemos; e assim, de certo modo, o seu conhecimento era intermédio entre o da vida presente e o
da pátria, onde se vê a Deus em essência. Para a evidência do que devemos considerar que a visão de
Deus, em essência, se divide por oposição com a visão de Deus, por meio da criatura. Ora, quanto mais
uma criatura é elevada e semelhante a Deus, tanto mais claramente O vê; assim como um homem vê–se
mais perfeitamente no espelho que mais nitidamente lhe reflete a imagem. Por onde é claro que Deus é
muito mais eminentemente visto pelos efeitos inteligíveis, do que pelos sensíveis e corpóreos. Ora, na
vida presente o homem está privado do conhecimento pleno e lúcido dos efeitos inteligíveis, porque é
solicitado pelas coisas sensíveis e a elas se atém. Mas, como diz a Escritura: Deus criou o homem reto, E
a retidão do homem criado por Deus consistia em que as coisas inferiores se sujeitassem às superiores,
e estas não fossem impedidas por aquelas. Por onde, o primeiro homem não ficava privado, pelas coisas
exteriores, da contemplação firme e clara dos efeitos inteligíveis, que percebia pela irradiação da
verdade primeira, fosse por conhecimento natural ou gratuito. E, por isso, diz Agostinho: Talvez, Deus
antes falasse com os primeiros homens, como agora fala com os anjos, ilustrando–lhes as mentes pela
própria verdade incomutável; embora não com tanta participação da divina essência como a de que os
anjos são susceptíveis. Assim, pois, por esses efeitos inteligíveis de Deus, conhecia–o mais claramente
do que agora conhecemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O homem era feliz no paraíso, não daquela perfeita
beatitude à qual havia de ser transferido, consistente na visão da divina essência; levava, contudo, como
diz Agostinho, uma vida feliz, de certo modo, por ter a integridade e uma certa perfeição natural.

RESPOSTA À SEGUNDA. – Boa é a vontade bem ordenada. Ora, a do primeiro homem não seria
ordenada, se, no estado de merecimento, quisesse ter o que lhe estava prometido como prêmio.

RESPOSTA À TERCEIRA. – Há duplo termo médio. Um, no qual o que por ele é visto o é
simultaneamente com ele; assim, quando um homem se vê no espelho vê–se simultaneamente com o
próprio espelho. Outro é aquele, pelo conhecimento do qual, chegamos ao conhecimento de algo
desconhecido; tal é o termo médio da demonstração. Ora, Deus era visto sem este termo médio; não
porém sem primeiro. Pois, não era necessário ao primeiro homem, como o é para nós, chegar ao
conhecimento de Deus por uma demonstração deduzida de algum efeito; mas, simultaneamente, com
os efeitos, sobretudo com os inteligíveis, conhecia a Deus ao seu modo. – Semelhantemente, devemos
notar que a obscuridade que implica o nome de enigma pode ser entendida de duplo modo. Enquanto
qualquer criatura é algo de obscuro, comparada com a imensidade do esplendor divino; e então Adão
via a Deus em enigma, porque o via pelo efeito criado. De outro modo, pode se entender por
obscuridade a que resultou do pecado, pela qual o homem fica privado, pela atração das coisas
sensíveis, da consideração dos inteligíveis; e então não via a Deus a não ser em enigma.

## Art. 2 — Se Adão, no estado de inocência, via os anjos em essência.
O segundo discute–se assim. – Parece que Adão, no estado de inocência, via os anjos em essência.

1. Pois, diz Gregório: Pois, no paraíso, o homem se acostumara a gozar das palavras de Deus e a conviver
com os anjos, pela pureza do coração e celsitude da visão.

2. Demais. – No estado da vida presente, a alma, por estar unida a um corpo corruptível, fica privada do
conhecimento das substâncias separadas; e isso a oprime, como diz a Escritura. E, daí vem, segundo já
foi dito, que a alma separada pode ver as substâncias separadas. Ora, a alma do primeiro homem não
sendo corruptível, não era oprimida pelo corpo. Logo, podia ver as substâncias separadas.

3. Demais. – Uma substância, conhecendose a si mesma, conhece outra, como foi dito. Ora, a alma do
primeiro homem conhecia–se a si mesma. Logo, também conhecia as substâncias separadas.
Mas, em contrário. – A alma de Adão era da mesma natureza que as nossas. Ora, as nossas não podem
inteligir as substâncias separadas. Logo, nem o podia a do primeiro homem.

SOLUÇÃO. – O estado da alma humana pode ser a dupla luz considerado. Primeiro, quanto aos modos
diversos da sua existência natural; e então distingue–se o estado da alma separada, do estado da alma
unida ao corpo. De outro modo, considera–se o estado da alma quanto à integridade e à corrupção,
conservado o mesmo modo de existir natural e então distingue–se o estado de inocência do estado do
homem depois do pecado. Ora, a alma do homem, no estado de inocência, bem como agora, era
acomodada a um corpo que devia aperfeiçoar e governar. Por isso está dito que o primeiro homem foi
feito em alma vivente, isto é, com uma alma que dá ao corpo a vida animal. Mas a integridade dessa
vida ele a tinha, por ser o corpo totalmente sujeito à alma, não a empecendo– em nada, como já antes
se disse. Ora, é manifesto, pelo que já ficou estabelecido, que, sendo a alma acomodada ao governo e à
perfeição do corpo, quanto à vida animal, é próprio à nossa alma o modo de inteligir que consiste em
recorrer aos fantasmas. Por onde, este modo de inteligir era próprio também à alma do primeiro
homem.
Ora, quanto a este modo, há um movimento na alma, como diz Dionísio, de três graus. O primeiro é o
pelo qual a alma, partindo das coisas exteriores, concentra–se em si mesma. Pelo segundo, ela sobe a
unir–se às virtudes superiores unidas, isto é, aos anjos. Pelo terceiro, ulteriormente, é levada ao bem
superior a todas as coisas, isto é, Deus. – Ora, pelo primeiro processo, consistente em partir a alma, das
coisas sensíveis, para se concentrar em si, completa–se–lhe o conhecimento. Pois como já se disse
antes, a operação intelectual da alma ordenando–se, naturalmente, às coisas exteriores, pode assim
pelo conhecimento destas, ser conhecida perfeitamente a nossa operação intelectual, como o ato o é
pelo seu objeto. E por essa operação intelectual pode ser perfeitamente conhecido o intelecto humano,
como a potência o é pelo próprio ato. No segundo processo, porém não há o conhecimento perfeito,
pois, como o anjo não intelige recorrendo aos fantasmas, mas de modo muito mais eminente, como já
se viu antes, o referido modo de conhecer, pelo qual a alma se conhece a si mesma, não leva
suficientemente ao conhecimento do anjo. E muito menos ainda o terceiro processo termina em
conhecimento perfeito, pois, mesmo os próprios anjos, por se conhecerem a si mesmos, não podem
alcançar o conhecimento da divina substância, por causa do excedente dela.
Assim, pois a alma do primeiro homem não podia certamente ver os anjos em essência. Todavia tinha
deles um modo de conhecimento mais excelente que o que temos, pois o seu conhecimento era mais
certo e fixo, em relação aos inteligíveis interiores, do que o nosso. E por causa dessa tão grande
eminência, diz Gregório que ele convivia com os espíritos dos anjos.
Donde resulta a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. – Não por opressão do corpo a alma do primeiro homem era deficiente, na
intelecção das substâncias separadas; mas porque o era o seu objeto conatural em relação à excelência
das substâncias separadas. Ao passo que nós somos deficientes sob ambos esses aspectos.

RESPOSTA À TERCEIRA. – A alma do primeiro homem não podia, pelo conhecimento de si mesmo,
chegar ao das almas separadas, como já se disse antes; porque é ao seu próprio modo que uma
substância separada conhece outra.

## Art. 3 — Se o primeiro homem tinha ciência de todas as coisas.
O terceiro discute–se assim. – Parece que o primeiro homem não tinha ciência de todas as coisas.

1. – Pois, tal ciência ele a tinha por espécies adquiridas, por conaturais ou infusas. Ora, não por espécies
adquiridas, porque o conhecimento por meio delas provém da experiência, como diz Aristóteles; e o
primeiro homem ainda não podia ter experiência de todas as coisas. Semelhantemente, nem por
espécies conaturais: por ter ele a mesma natureza que nós, e a nossa alma é como uma tábua em que
nada esta escrito, como diz Aristóteles. Se era, pois, por espécies infusas, então a ciência que tinha das
coisas não era da mesma natureza que a nossa, que haurimos delas.

2. Demais. – Todos os indivíduos da mesma espécie conseguem do mesmo modo a perfeição. Ora, os
outros homens não têm ciência de todas as coisas, imediatamente, desde o princípio; mas a adquirem
ao seu modo, na sucessão do tempo. Logo, nem Adão, desde que foi formado, teve ciência de todas as
coisas.

3. Demais. – O homem foi colocado no estado da vida presente para que a sua alma progrida no
conhecimento e no mérito: pois para isso foi a alma unida ao corpo. Ora, o homem naquele primeiro
estado progrediria, no mérito; logo, também no conhecimento das coisas. E portanto, não tinha
conhecimento de todas.
Mas, em contrário, ele, por si mesmo, impôs os nomes aos animais, como diz a Escritura. Ora, os nomes
devem convir às naturezas das coisas. Logo, Adão conhecia as naturezas de todos os animais; e pela
mesma razão tinha conhecimento de todas as outras coisas.

SOLUÇÃO. – Na ordem natural o perfeito precede o imperfeito, como o ato, a potência; pois o potencial
só é atualizado pelo que já é atual. E como as coisas foram, no princípio, instituídas por Deus, não só
para existirem em si mesmas, mas para serem os princípios de outras, por isso foram produzidas num
estado perfeito, em virtude do qual pudessem ser princípios de outras. Ora, um homem pode ser
princípio de outro, não somente pela geração corpórea, mas também pela instrução e pelo governo. E
portanto, assim como o primeiro homem foi instituído no estado perfeito, quanto ao corpo, de modo
que imediatamente pudesse gerar, assim também o foi quanto à alma, para que imediatamente,
pudesse instruir os outros e governar.
Ora, como não pode instruir quem não tem ciência, por isso o primeiro homem foi instituído por Deus
de modo a ter ciência de todas as coisas em relação às quais deve ser instruído. E estas são todas as que
virtualmente existem nos primeiros princípios conhecidos por si mesmos, isto é, todas as que os homens
podem naturalmente conhecer. – Mas para o governo da vida própria e o das dos outros é necessário
não só o conhecimento das coisas que podem ser naturalmente conhecidas, mas também o das que
excedem o conhecimento natural, porque a vida do homem se ordena a um fim sobrenatural; assim,
para o governo da nossa vida é necessário conhecer as coisas da fé, Por isso o primeiro homem recebeu
o conhecimento das coisas sobrenaturais na medida em que era necessário para o governo da vida
humana, de conformidade com aquele primeiro estado. Porém ele não conhecia as outras coisas, que
não podem ser conhecidas pelo seu esforço natural nem são necessárias ao governo da vida humana;
como são as cogitações dos homens, os futuros contingentes e certos conhecimentos particulares como;
por exemplo, quantos seixos jazem num rio e outros semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O primeiro homem tinha ciência de todas as coisas, por
meio de espécies infusas por Deus. Mas nem por isso a sua ciência era de natureza diversa da natureza
da nossa ciência; assim como os olhos, que Cristo deu ao cego de nascença, não eram de natureza
diferente da daqueles que a natureza produziu.

RESPOSTA À SEGUNDA. – Adão, como Primeiro homem, devia ter alguma perfeição que não cabe aos
outros homens, segundo resulta do que já foi dito.

RESPOSTA À TERCEIRA. – Adão, relativamente à ciência das coisas naturais, que se podem conhecer,
não progrediria quanto ao número das coisas sabidas, mas quanto ao modo de saber; pois, o que sabia
pela inteligência, saberia, depois, pela experiência. Relativamente porém, aos conhecimentos
sobrenaturais, progrediria mesmo quanto ao número, por meio de novas revelações; assim como os
anjos progridem por novas iluminações. Mas não há símile entre o progresso no mérito e o na ciência,
porque um homem não é o princípio do merecimento de outro, como é o da ciência.

## Art. 4 — Se o homem, no estado primitivo, podia enganar–se.
O quarto discute–se assim. – Parece que o homem, no estado primitivo, podia enganar–se.

1. – Pois, diz a Escritura: A mulher foi enganada em prevaricação.

2. Demais. – O Mestre das Sentenças diz: a mulher não se horrorizou, com a serpente falante, por ter
pensado que esta recebera esse poder de Deus. O que era falso. Logo, a mulher enganouse antes do
pecado.

3. Demais. – É natural que quanto mais de longe uma cousa é vista, tanto menos vista é. Ora, a natureza
dos olhos não tendo sido afetada pelo pecado, o princípio supra se lhe aplicava, já no estado de
inocência. Logo, o homem havia de se enganar relativamente ao tamanho da cousa vista, como agora.

4. Demais. – Agostinho diz, que no sonho, a alma adere à semelhança da cousa, como se fosse a própria
cousa. Ora, no estado de inocência, o homem havia de comer e, por conseguinte, de dormir e sonhar.
Logo, enganouse quando aderiu às semelhanças, como se estas fossem as coisas.

5. Demais. – O primeiro homem não conhecia como já se disse, as cogitações dos outros homens e os
futuros contingentes. Se, pois, alguém lhe dissesse algo de falso, sobre tais coisas ele ter–se–ia
enganado.
Mas, em contrário, diz Agostinho: Tomar o falso como verdadeiro não é da natureza criada do homem,
mas pena de danado.

SOLUÇÃO. – Alguns disseram que, sob o nome de engano duas coisas podem se entender: qualquer
opinião irrefletida, pela qual aderimos ao falso, como se fosse verdadeiro, sem o assentimento da
crença; e, além dessa, a crença firme. Ora, em relação às coisas das quais Adão tinha ciência, de nenhum
dos dois sobreditos modos o homem podia enganar–se, antes do pecado; mas, quanto às coisas de que
não tinha conhecimento, podia enganar–se, tomando–se o engano na acepção lata, como opinião
qualquer, sem o assentimento da crença. E isto dizem, porque pensa com falsidade, relativamente a tais
coisas, não é nocivo ao homem; e, desde que não aderiu, assentindo temerariamente, não há culpa.
Mas tal posição não se coaduna com a integridade do primeiro estado. Pois, como diz Agostinho,
naquele primeiro estado evitava–se tranquilamente o pecado, permanecendo o que, não era de
nenhum modo possível qualquer mal.
Ora, é manifesto que, assim como a verdade é o bem do intelecto, assim a falsidade é–lhe o mal,
segundo diz Aristóteles. Por onde, não era possível, o intelecto do homem, no estado de inocência,
aderir a uma falsidade como se fosse verdade. Pois, assim como nos membros do corpo do primeiro
homem havia certa carência de uma perfeição, a saber o esplendor, sem que todavia qualquer mal nele
pudesse existir; assim também no intelecto podia haver carência de algum conhecimento sem que nele,
de qualquer modo, pudesse existir qualquer opinião falsa.
E isto também claramente resulta da retidão mesma do primitivo estado, pela qual, enquanto a alma
permanecesse sujeita a Deus, as virtudes inferiores do homem seriam sujeitas às superiores, nem a
estas poriam obstáculos aquelas. Ora, sendo manifesto, pelo que já foi dito, que o intelecto é sempre
verdadeiro, em relação ao seu objeto próprio, nunca poderá em si mesmo, enganar–se; mas todo
engano lhe advém de alguma potência inferior, por exemplo, da fantasia ou outra semelhante. E por
isso vemos que quando à faculdade natural de julgar não há nenhum obstáculo, não nos enganamos
com tais aparições, mas só quando lhe há obstáculo, como acontece com os que dormem. Por onde é
claro, que a retidão do primitivo estado não era compatível com nenhum engano do intelecto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora à sedução da mulher se seguisse o pecado por
obra, contudo ela já foi subsequente ao pecado da elação interior. Pois, diz Agostinho: a mulher não
teria acreditado nas palavras da serpente, se já não lhe existisse na mente o amor do próprio poder e
uma certa soberba presunção de si.

RESPOSTA À SEGUNDA. – A mulher pensava que a serpente recebera o poder de falar, não da natureza,
mas de alguma operação sobrenatural. – Embora não seja necessário seguir, neste ponto, a autoridade
do Mestre das Sentenças.

RESPOSTA À TERCEIRA. – Se fosse representado algo ao sentido ou à fantasia do primeiro homem de
modo diferente do da existência natural, nem por isso ele se enganaria porque pela razão discerniria a
verdade.

RESPOSTA À QUARTA. – O que acontece em sonho não se imputa ao homem, porque não tem então o
uso da razão, ato próprio do homem.

RESPOSTA À QUINTA. – O homem, no estado de inocência, não acreditaria em quem dissesse uma
falsidade sobre os contingentes futuros ou as cogitações dos corações; mas acreditaria que tal seria
possível, o que não era pensar com falsidade. – Ou se pode dizer que lhe adviria algum socorro divino,
para que não se enganasse no tocante às coisas de que não tinha ciência. – Nem vale a instância que
certos aduzem, dizendo que, na tentação, não lhe adveio o socorro, para que não se enganasse, embora
então dele mais tivesse necessidade; porque já lhe precedera o pecado, na alma, e não recorreu ao
auxílio divino.
