# Questão 93: O fim da produção do homem, na medida em que ele é "imagem e semelhança de Deus".
Em seguida devemos tratar do estado ou da condição do primeiro homem. E, primeiro quanto à alma.
Segundo, quanto ao corpo.
Sobre o primeiro ponto duas questões se discutem. Primeira da condição do homem quanto ao
intelecto. Segunda, da condição do homem quanto à vontade.
Sobre a primeira questão quatro artigos se discutem:

## Art. 1 — Se a Imagem de Deus está no homem.
O primeiro discute–se assim. – Parece que a imagem de Deus não está no homem.

1. Pois, diz Escritura: A quem pois tendes vós assemelhado a Deus? Ou que imagem fareis dele?

2. Demais. – Ser imagem de Deus é próprio do Primogénito, do qual diz a Escritura: que é a imagem do
Deus invisível, o primogénito de toda a criatura. Logo, no homem não está a imagem de Deus.

3. Demais. – Hilário diz, que a imagem, é a espécie indiferente da causa de que e imaginada; e diz mais,
que a imagem é a semelhança indiscreta e unida de uma causa que se iguala com outra. Ora, não há
espécie indiferente de Deus e do homem; nem pode haver igualdade do homem com Deus. Logo,
naquele não pode haver a imagem de Deus.
Mas, em contrário, diz a Escritura: Façamos o homem à nossa imagem e semelhança.

SOLUÇÃO. – Como diz Agostinho, onde há imagem, imediatamente há também semelhança; mas, onde
há semelhança, não há, imediatamente, imagem. Por onde é claro que a semelhança é da essência da
imagem, e que esta acrescenta algo à noção daquela, a saber, que seja a expressão de outra cousa; pois,
imagem se chama aquilo que é feito como imitação de outra cousa. Por onde, por mais que um ovo seja
semelhante e igual a outro, como, todavia, não é a expressão deste, não se diz que seja a imagem do
mesmo. Enquanto que a igualdade não é da essência da imagem; pois, como diz Agostinho, no mesmo
passo, onde está a imagem não, imediatamente, a igualdade, como claramente se vê na imagem de
alguém refletida pelo espelho. É, contudo da essência da imagem perfeita; pois, nesta, nada falta do que
esteja no ser de que ela é a expressão. – Ora, é manifesto, que no homem se encontra alguma
semelhança de Deus, decorrente dele como do exemplar. Não há porém, nele semelhança, quanto à
igualdade, porque o exemplar excede infinitamente esse exemplado. Por onde, diz–se que no homem
está a imagem de Deus, não perfeita, mas imperfeita. E isso o exprime a Escritura, dizendo que o
homem foi feito à imagem de Deus. Pois, a preposição à exprime uma certa aproximação, própria ao
que está distante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O Profeta fala das imagens corpóreas fabricadas pelos
homens e, por isso, diz assinaladamente: que imagem fareis dele? Ao passo que o próprio Deus
imprimiu no homem sua imagem espiritual.

RESPOSTA À SEGUNDA. – O Primogênito de toda criatura é a imagem perfeita de Deus, reproduzindo
perfeitamente o ser de que é a imagem. Por isso se chama Imagem e nunca, à imagem. Porém, do
homem, diz–se que é imagem, pela semelhança, e, à imagem, pela imperfeição da semelhança. E como
a semelhança perfeita de Deus não pode existir senão na identidade da natureza, a imagem de Deus
está no seu Filho primogénito, assim como a imagem do rei, no filho que lhe é conatural. No homem,
porém, como numa natureza estranha, do mesmo modo que a imagem do rei, numa moeda de prata,
como está claro em Agostinho.

RESPOSTA À TERCEIRA. – Como uno é o ente indiviso, a espécie se diz indiferente do mesmo modo pelo
qual se diz que é una. Ora, diz–se que um ser é uno, não só numericamente, especifica ou
genericamente, mas também por analogia ou por uma certa proporção; e essa é a unidade de
conveniência da criatura com Deus. E a expressão – de uma cousa que se iguala com outra – pertence à
essência da imagem perfeita.

## Art. 2 — Se a imagem de Deus está nas criaturas irracionais.
O segundo discute–se assim. – Parece que a imagem de Deus está nas criaturas irracionais.

1. Pois, diz Dionísio: As coisas causadas têm imagens contingentes das suas causas: Ora, Deus é causa,
não só das criaturas racionais, como também das irracionais. Logo, a imagem de Deus está nas criaturas
irracionais.

2. Demais. – Quanto mais expressiva é a semelhança num ser, tanto mais ele realiza a essência da
imagem. Ora, Dionísio diz que o raio solar tem a máxima semelhança com a bondade divina. Logo, é à
imagem de Deus.

3. Demais. – Tanto mais um ser é perfeito em bondade, e tanto mais semelhante é a Deus. Ora, o todo
universal é de bondade mais perfeita que a do homem; pois, embora os seres singulares sejam bons,
contudo, todos, simultaneamente, são chamados, pela Escritura, muito bons, Logo, o todo universal é à
imagem de Deus, e não só o homem.

4. Demais. – Boécio diz de Deus: Dirige o mundo com a mente e forma outros seres de imagem
semelhante. Logo, todo o mundo é à imagem de Deus, e não só a criatura racional.
Mas, em contrário, diz Agostinho: É excelente, no homem o havê–la feito Deus à sua imagem, porque
lhe deu um espirito inteligente pelo qual é superior aos animais. Logo, os seres que não têm intelecto
não são à imagem de Deus.

SOLUÇÃO. – Qualquer semelhança, mesmo que seja a expressão de outra cousa, não basta para realizar
a essência da imagem. Pois, se a semelhança for só genérica ou por algum acidente comum, nem por
isso se dirá que uma cousa é à imagem de outra. Assim, não se pode dizer que um verme, nascido do
homem, seja a imagem deste, por semelhança genérica. Nem ainda se pode dizer que se uma cousa se
torna branca, à semelhança de outra, seja por isso à semelhança desta; porque branco é um acidente
comum a várias espécies. Por onde, a essência da imagem requer a semelhança específica, como, p. ex.,
a imagem do rei, no filho; ou, pelo menos a semelhança por algum acidente próprio da espécie e,
principalmente, pela figura e, assim, se diz que a imagem do homem está no cobre. Por isso, Hilário diz,
assinaladamente que a imagem é uma espécie não diferente. – Ora, é manifesto que a semelhança
específica é relativa à última diferença. Certas criaturas porém se assemelham a Deus, primeiro e
sobretudo, comumente, enquanto são; segundo, enquanto vivem; terceiro, enquanto sabem ou
inteligem; e estas, como diz Agostinho, não próximas de Deus, pela semelhança, de modo que não há
criaturas que o sejam mais. Assim, pois, é claro que só as criaturas inteligentes, propriamente falando,
são à imagem de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Todo imperfeito é uma certa participação do perfeito. Por
isso, mesmo os seres deficientes, em relação à essência da imagem, enquanto, todavia, têm uma certa
semelhança com Deus, participam algo da essência da imagem. Por onde, como diz Dionísio, as coisas
causadas têm imagens contingentes das suas causas, isto é, na medida em que lhes é possível tê–Ias, e
não absolutamente.

RESPOSTA À SEGUNDA. – Dionísio assimila o raio solar à divina bondade, quanto à causalidade; não
quanto à dignidade de natureza, exigida pela essência da imagem.

RESPOSTA À TERCEIRA. – O universo é mais perfeito, em bondade, que a criatura inteligente, extensiva
e difusivamente; mas, intensiva e coletivamente, a semelhança da divina perfeição está, sobretudo, na
criatura inteligente, capaz do sumo bem. – Ou se deve dizer que a parte não se divide por oposição com
o todo, mas por oposição com outra parte. Por onde, quando se diz que só a natureza inteligente é à
imagem de Deus, não se exclui que o universo não seja, por alguma das suas partes, à imagem de Deus,
mas excluem–se as outras partes do mesmo.

RESPOSTA À QUARTA. – Boécio considera a imagem sob o ângulo da semelhança, pela qual o artificiado
imita a espécie de arte que está na mente do artífice. Assim pois, qualquer criatura é imagem da razão
exemplar, cuja imagem ela tem na mente divina. Ora, não é neste sentido que tratamos agora da
imagem, mas enquanto se considera nela a semelhança de natureza; assim, enquanto todos os entes,
como tais, assemelham–se ao ente primeiro; e à vida primeira, como vivos; e à suma sapiência, como
inteligentes.

## Art. 3 — Se o anjo é mais à imagem de Deus que o homem.
O terceiro discute–se assim. – Parece que o anjo não é mais à imagem de Deus, que o homem.

1. Pois, diz Agostinho, que Deus a nenhuma outra criatura, a não ser ao homem, concedeu que fosse à
sua imagem. Logo, não é verdade que o anjo seja mais à imagem de Deus, que o homem.

2. Demais. Segundo Agostinho: O homem é à imagem de Deus, de modo tal que, foi formado por Deus,
sem a interposição de nenhuma criatura; por onde, nada está mais próximo de Deus que ele. Ora diz a
imagem de Deus a criatura que d'Ele está próxima. Logo, o anjo não é mais a imagem de Deus que o
homem,

3. Demais, – Diz–se que é à imagem de Deus a criatura de natureza intelectual. Ora, a natureza
intelectual não padece intensão nem remissão; pois, pertencendo ao gênero da substância, não
pertence ao do acidente. Logo, o anjo não é mais à imagem de Deus, que o homem.
Mas, em contrário, diz Gregório, que do anjo se diz que é o sinete da semelhança, porque, nele, a
semelhança da divina imagem se manifesta mais expressivamente.

SOLUÇÃO. – A dupla luz podemos considerar a imagem de Deus, – Primeiro, quanto àquilo em que
primariamente, se considera a essência da imagem, que é a natureza intelectual. E assim, a imagem de
Deus está mais nos anjos do que nos homens; porque a natureza intelectual é mais perfeita neles, como
do sobredito resulta, Segundo, pode–se considerar a imagem de Deus no homem, quanto àquilo no que
ela é secundariamente, a saber, enquanto que, no homem, se encontra uma certa imitação de Deus.
Pois o homem vem do homem, como Deus, de Deus; e a alma do homem está toda em todo o corpo e
em qualquer parte do mesmo, como Deus, no mundo. E, segundo esta e outras semelhanças, a imagem
de Deus está mais no homem, que no anjo. Mas, quanto a este ponto de vista só se considera a
existência da divina imagem, no homem, pressupondo a primeira imitação, segundo a natureza
intelectual; do contrário, também os brutos seriam à imagem de Deus. E portanto, como, no referente à
natureza intelectual, o anjo é mais à imagem de Deus, que o homem, é forçoso conceder que ele é,
absolutamente, mais à imagem de Deus; o homem, porém, de certo modo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Agostinho exclui da imagem de Deus, as outras criaturas
inferiores, que carecem de intelecto; não, porém, os anjos.

RESPOSTA À SEGUNDA. – Assim como se diz que o fogo é, especificamente, o mais subtil dos corpos,
embora possa um fogo ser mais subtil que outro; assim se diz que nada é mais próximo de Deus, que a
mente humana, no gênero da natureza intelectual. Pois, como dissera antes Agostinho, as criaturas
inteligentes são de tal modo próximas de Deus, pela semelhança, que não há outras que mais que elas o
sejam. Por onde, não exclui esse dito que o anjo seja mais à imagem de Deus.

RESPOSTA À TERCEIRA. – Quando se diz que a substância não é susceptível de mais nem de menos, não
se entende, por aí, que uma espécie de substância não seja mais perfeita que outra. Mas que um
mesmo indivíduo não participa da sua substância, ora mais, ora menos; nem também a espécie da
substância é participada, mais e menos, por diversos indivíduos.

## Art. 4 — Se a imagem de Deus está em qualquer homem.
O quarto discute–se assim. – Parece que a imagem de Deus não está em qualquer homem.

1. Pois, diz a Escritura: O homem é a imagem de Deus, mas a mulher é a imagem do homem. Ora, como
a mulher é indivíduo da espécie humana, não a qualquer indivíduo é próprio ser a imagem de Deus.

2. Demais. – A Escritura diz, que aqueles que Deus conheceu na sua presciência, também os predestinou
para serem conformes à imagem de seu Filho, a estes também chamou. Ora, nem todos os homens são
predestinados. Logo, nem todos têm a conformidade da imagem.

3. Demais. – A semelhança é da essência da imagem, como já se disse antes. Ora, pelo pecado o homem
torna–se dissemelhante de Deus. Logo, perde a imagem de Deus.
Mas, em contrário, diz a Escritura: Certamente o homem passa como em imagem.

SOLUÇÃO. – Como se diz que o homem é a imagem de Deus, pela natureza intelectual, ele é a essa
imagem no máximo grau, na medida em que, nesse mesmo grau, a natureza intelectual de Deus pode
ser imitada. Ora, a natureza intelectual imita a Deus, em máximo grau, no ponto de vista em que Deus a
si mesmo se intelige e ama. Por onde, a imagem de Deus pode ser considerada, no homem, a tríplice
luz. Primeiro, enquanto o homem tem aptidão natural para inteligir e amar a Deus; e essa aptidão
consiste em a natureza mesma da mente, comum a todos os homens. Depois, enquanto o homem, atual
ou habitualmente, conhece e ama a Deus, embora imperfeitamente; e essa é a imagem por
conformidade da graça. Terceiro, enquanto o homem conhece a Deus atualmente e perfeitamente o
ama; e assim essa é a imagem por semelhança da glória. Por onde, a propósito do passo da Escritura –
Gravado esta, Senhor, sobre nos o lume do teu rosto a Glossa distingue tríplice imagem: a da criação, a
da segunda criação e a da semelhança. Ora, a primeira imagem está em todos os homens; a segunda, só
nos justos; a terceira, porém, só nos bem–aventurados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. Tanto no homem como na mulher está a imagem de Deus,
quanto aquilo em que, principalmente, consiste a essência da imagem, a saber, a natureza intelectual.
Por onde, depois de a Escritura ter dito – Deus o criou à sua imagem – isto é, o homem, acrescenta:
macho e fêmea os criou. – E disse no plural, os como comenta Agostinho, para não se entender que,
num só indivíduo estivessem reunidos ambos os sexos. Mas, num ponto de vista secundário, a imagem
de Deus está no homem de um modo pelo qual não está na mulher. Pois aquele é o princípio e o fim
desta, assim como Deus é o princípio e o fim de toda criatura. Por onde, depois de ter dito a Escritura,
que o homem é a imagem e glória de Deus, mas a mulher é a glória do homem, mostra–se porque tal se
disse, ao acrescentar: Porque não foi feito o homem da mulher, mas a mulher do homem; e não foi
criado o homem por causa da mulher, mas sim a mulher por causa do homem.

RESPOSTAS À SEGUNDA E TERCEIRA. – Essas objeções colhem quanto à imagem pela conformidade da
graça e da glória.

## Art. 5 — Se no homem está a imagem de Deus quanto à Trindade das divinas Pessoas.
O quinto discute–se assim. – Parece que no homem não está a imagem de Deus quanto à Trindade das
divinas pessoas.

1. Pois, Agostinho diz: Uma e essencial é a divindade e a imagem da santa Trindade, à cuja imagem foi
feito o homem. E Hilário diz, que o homem é feito à imagem comum da Trindade. Logo, há, no homem,
a imagem de Deus, quanto à essência e não quanto à Trindade das Pessoas.

2. Demais. – Como diz um autor, considera–se a imagem de Deus, no homem, segundo a eternidade. E
Damasceno também diz, que ser o homem a imagem de Deus significa ser intelectual, ter livre arbítrio e,
ser em si, revestido de poder. E Gregório Nisseno afirma que quando a Escritura diz que o homem foi
feito à imagem de Deus, é o, mesmo que se dissesse que a natureza humana foi feita participante de
todo bem, pois a divindade é a plenitude da bondade. Ora, nada disto respeita à distinção das Pessoas,
mas, antes, à unidade da essência. Logo, no homem, está a imagem de Deus, não quanto à Trindade das
Pessoas, mas quanto à unidade da essência.

3. Demais. – A imagem leva ao conhecimento do ser a que ela pertence. Se, pois, no homem está a
imagem de Deus, quanto à Trindade das Pessoas, como o homem pode se conhecer a si mesmo pela
razão natural, seguir–se–ia, que ele, por esse conhecimento, poderia conhecer a Trindade das divinas
Pessoas; o que é falso, como antes já se demonstrou.

4. Demais. – O nome de imagem não convém a qualquer das três pessoas, mas só ao Filho. Pois, como
diz Agostinho, só o Filho é a imagem do Pai. Se pois se considerasse, no homem a imagem de Deus,
quanto à Pessoa, nele não haveria a imagem de toda a Trindade, mas só a do Filho.
Mas, em contrário, Hilário entende pela expressão – o homem foi feito à imagem de Deus, a pluralidade
das divinas Pessoas.

SOLUÇÃO. – Como já ficou dito antes, a distinção das divinas Pessoas é só quanto à origem, ou antes,
quanto às relações de origem. Ora, não é o mesmo o modo da origem, em todos os seres; mas esse
modo, em cada ser, é segundo a conveniência da natureza do mesmo. Pois, de um modo, são
produzidos os seres; animados, de outro, os inanimados; de um modo, os animais, de outro, as plantas.
Por onde, é manifesto que a distinção das divinas pessoas é segundo. o que convém à natureza divina. E
portanto, ser à imagem de Deus, quanto à imitação da divina natureza, não exclui o ser à mesma
imagem, quanto à representação das três Pessoas; antes, uma cousa se segue à outra. – Assim pois,
deve dizer–se que há no homem, a imagem de Deus, quanto à natureza divina e quanto à Trindade das
Pessoas; pois, em Deus, nas três pessoas existe uma só natureza.
E daqui se deduz a RESPOSTA ÀS DUAS PRIMEIRAS OBJEÇÕES.

RESPOSTA À TERCEIRA. – A objeção procederia, se a imagem de Deus estivesse no homem,
representando Deus perfeitamente. Mas, como diz Agostinho, é extrema a diferença entre a trindade,
que está em nós, e a Trindade divina. Por isso, ainda diz, na mesma obra: a trindade que esta em nós,
antes a vemos, que nela cremos; que Deus, porém, é a Trindade, mais o cremos, que vemos.

RESPOSTA À QUARTA. – Certos disseram que no homem há só a imagem do Filho; mas isto é refutado
por Agostinho. Primeiro, porque, sendo o Filho semelhante ao Pai, por igualdade essencial, necessário é
que, se o homem foi feito à semelhança do Filho, também o fosse à do Pai. Segundo, porque se o
homem tivesse sido feito só à imagem do Filho, o Pai não teria dito: Façamos o homem à nossa imagem
e semelhança. Quando, pois, se diz, criou Deus o homem à sua imagem, não se deve entender por aí,
que o Pai fez o homem só à imagem do Filho, que é Deus – como alguns expuseram mas que Deus Trino
fez o homem à imagem sua, isto é, de toda a Trindade. Assim, o dito criou o homem à sua imagem, pode
ser entendido de duplo modo. Ou designando a preposição à o termo da produção e sendo, então, o
sentido: Façamos o homem de tal modo que nele esteja a nossa imagem. Ou designando essa
preposição a causa exemplar, assim como quando se diz, este livro foi feito à imagem daquele. E então a
imagem de Deus é a essência divina mesma, chamada abusivamente imagem, enquanto por esta se
entende o exemplar. Ou, como dizem alguns, a divina essência se chama imagem porque, por ela, uma
pessoa imita a outra.

## Art. 6 — Se a Imagem de Deus está no homem só quanto à alma.
O sexto discute–se assim. – Parece que a imagem de Deus não está no homem só quanto à alma.

1. Pois, como diz a Escritura o homem é a imagem de Deus, Ora, o homem não é somente. Logo, a
imagem de Deus não está só na alma.

2. Demais. – A Escritura diz: Criou Deus o homem à sua imagem, ele o criou à imagem de Deus; macho e
fêmea os criou. Ora, a distinção entre macho e fêmea é corporal. Logo, a imagem de Deus está no
homem também corporalmente e não só quanto à alma.

3. Demais. – A imagem é considerada, principalmente, em relação à figura. Ora, esta diz respeito ao
corpo, Logo, a imagem de Deus está no homem também corporalmente, e não só quanto à alma.

4. Demais. – Como diz Agostinho, há em nós tríplice visão: a corporal, a espiritual, ou imaginária, e a
intelectual. Se pois, relativamente à visão intelectual, que pertence à mente, há alguma trindade em
nós, enquanto somos à imagem de Deus; por idêntica razão o mesmo se dá com as outras visões.
Mas, em contrário, diz a Escritura: Renovaivos pois no espírito do vosso entendimento, e vesti–vos do
homem novo. Pelo que se dá a entender, que a nossa renovação que se opera segundo a vestimenta do
homem novo, pertence à mente. Mas, noutro passo diz: E revestindo–se do novo, que é aquêle que se
renova para o conhecimento, segundo a imagem daquele que o criou; onde a renovação, quanto à
vestimenta do homem novo, é atribuída à imagem de Deus. Logo, ser à imagem de Deus diz respeito só
à alma.

SOLUÇÃO. – Embora haja, em todas as criaturas, certa semelhança de Deus, só na criatura racional se
encontra essa semelhança ao modo de imagem, como antes já se disse; ao passo que, nas outras, ao
modo de vestígio.
Ora, é pelo intelecto ou mente que a criatura racional excede as outras criaturas. Donde resulta que, na
própria criatura racional, a imagem de Deus só existe, quanto à mente; porém, em outras partes que
tenha essa criatura, há a semelhança de vestígio, assim como nos outros seres aos quais, quanto a tais
partes, ela é assimilada.
E a razão disto pode ser manifestamente conhecida, a tendendo–se ao modo pelo qual representa o
vestígio e o pelo qual representa a imagem. A imagem representa por semelhança específica, como
antes já se disse. Ao passo que o vestígio é como o efeito, que representa a sua causa sem que o seja
pela semelhança específica; assim as impressões deixadas pelo movimento dos animais chamam–se
vestígios, e, semelhantemente, a cinza considera–se vestígio do fogo, e a desolação de um país, vestígio
do exército inimigo.
Ora, a diferença referida pode ser considerada relativamente às criaturas racionais e às outras, e
também à representação, naquelas, não só da semelhança da divina natureza como também da
Trindade incriada. – Assim no atinente à semelhança da natureza divina, as criaturas racionais se
consideram como realizando, de certo modo, a representação específica por imitarem a Deus, não só
quanto ao ser e à vida, mas também quanto ao inteligir, como antes já se disse. Ao passo que as outras
criaturas não inteligem, mas trazem em si um como vestígio do intelecto produtor, se se atender à
disposição delas. – Semelhantemente, como a Trindade incriada se distingue, quanto à processão do
verbo, da Pessoa dicente, e à do Amor, de arribas, conforme já se demonstrou; a criatura racional, na
qual existe a processão do verbo, quanto ao intelecto, e a do amor, quanto à vontade, pode–se dizer
que é a imagem da Trindade incriada, por uma certa representação específica. Enquanto que nas outras
criaturas não existe o princípio do verbo, o verbo e o amor, mas manifestam certo vestígio de que essas
distinções existam na causa produtora. Pois o fato mesmo de ter a criatura uma substância limitada e
finita mostra que é proveniente de algum principio. Enquanto que a espécie em si da criatura revela o
verbo que a fez, como a forma da casa revela a concepção do artífice. E por fim, a ordem demonstra o
amor de quem a produziu, pelo qual o efeito se ordena para o bem, assim como o uso do edifício
demonstra a vontade do artífice.
Assim, pois, há no homem a semelhança de Deus, por meio da imagem, no que diz respeito à mente;
mas, no respeitante às outras partes, por meio do vestígio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Diz–se que o homem é a imagem de Deus, não por ser
essencialmente imagem, mas por trazer no espírito impressa tal imagem; assim como se diz que a
moeda é a imagem de Cesar, por ter a imagem deste. Por onde, não é necessário introduzir a imagem
de Deus em qualquer parte do homem.

RESPOSTA À SEGUNDA. – Como refere Agostinho, alguns viram a imagem de Deus no homem, não
relativamente a um só indivíduo, mas a vários. Assim, diziam que o varão representa a pessoa do Padre;
a do Filho é representada pelo que procede do varão por nascimento; e a terceira pessoa, como o
Espírito Santo, diziam é a mulher que procede do varão sem ser dele filho ou filha. Mas esta opinião é
visivelmente absurda. Primeiro, porque levaria a concluir que o Espírito Santo é o principio do Filho,
como a mulher é o princípio da prole nascida do homem. Segundo, porque um homem não seria à
imagem senão de uma Pessoa. Terceiro, porque então a Escritura não devia ter mencionado a imagem
de Deus no homem, senão depois da prole já produzida. – E, portanto, deve admitir–se, que a Escritura,
depois de ter dito: Criou Deus o homem à sua imagem, acrescentou: macho e fêmea os criou não
considerando a imagem de Deus quanto às distinções dos sexos, mas porque essa imagem é comum a
ambos os sexos, por estar na mente, na qual não há distinção de sexos. Por isso a Escritura, depois de
ter dito: Segundo a imagem daquele que o criou, acrescentou: não há macho nem fêmea.

RESPOSTA À TERCEIRA. – Embora a imagem de Deus não esteja no homem pela figura corpórea,
contudo, no dizer de Agostinho, como só o corpo do homem entre os corpos dos animais terrestres, não
é estirado e inclinado sôbre o ventre, mas é tal que se torna mais apto a contemplar o céu, por isto
pode–se com razão, admitir que tal corpo foi feito à imagem e à semelhança de Deus, mais que os
corpos dos outros animais, o que contudo não se deve entender como se no corpo do homem estivesse
a imagem de Deus, mas que a figura mesma do corpo humano representa, como vestígio, a imagem de
Deus na alma.

RESPOSTA À QUARTA. – Tanto na visão corpórea, como na imaginária, manifesta–se uma certa
trindade, como diz Agostinho. Assim, na visão corpórea, há primeiro, a espécie do corpo exterior;
segundo, a visão mesma, que nasce da impressão de certa semelhança da predita espécie, na vista;
terceiro, a intenção da vontade, que aplica a vista à visão, detendo–a na cousa vista. Semelhantemente,
na visão, imaginária há, primeiro, a espécie, conservada na memória; segundo, a visão imaginária,
proveniente de que o acume da alma, isto é, a virtude imaginária, é informado pela referida espécie; e,
terceiro, há a intenção voluntária, que une a ambas. Ora, ambas essas trindades são deficientes,
relativamente à essência da divina imagem. Pois, a espécie do corpo exterior está fora da natureza da
alma. E a espécie que está na memória, embora não seja exterior à alma, é lhe contudo adventícia. E
assim, de ambos os lados, é deficiente a representação da conaturalidade e da coeternidade das divinas
Pessoas. Quanto à visão corpórea, ela não procede somente da espécie do corpo exterior, mas
simultaneamente com esta, do sentido do vidente. E semelhantemente, a visão imaginária não só
procede da espécie conservada na memoria, mas também da virtude imaginativa.
Assim que, por aí, não é representada convenientemente a processão do Filho, só do Pai. E quanto à
intenção da vontade, que une as duas visões referidas, ela destas não procede, nem na visão corpórea,
nem na espiritual. Por onde, não é convenientemente representada a processão do Espírito Santo, do
Pai e do Filho.

## Art. 7 — Se a imagem de Deus está na alma atualmente.
O sétimo discute–se assim. – Parece que a imagem de Deus não está na alma, atualmente.

1. Pois, diz Agostinho, que o homem foi feito à imagem de Deus, enquanto somos, sabemos que somos,
e amamos o nosso ser e o nosso conhecimento. Ora, ser não significa ato. Logo, a imagem de Deus não
está na alma, atualmente.

2. Demais. – Agostinho distingue a imagem de Deus na alma, enquanto esta é de tríplice modo, mente,
conhecimento e amor. Ora, a mente não exprime o ato, mas antes, a potência, ou também, a essência
intelectiva da alma. Logo, a imagem de Deus não se manifesta atualmente.

3. Demais. – Agostinho distingue a imagem da Trindade na alma, quanto à memória, à inteligência e à
vontade. Ora, são estas três, virtudes naturais da alma, como diz o Mestre das Sentenças. Logo, a
imagem de Deus se manifesta quanto às potências e não quanto aos atos.

4. Demais. – A imagem da Trindade sempre permanece na alma. Ora, o ato não permanece sempre.
Logo, a imagem de Deus não se manifesta na alma quanto aos atos.
Mas, em contrário, Agostinho distingue a trindade nas partes inferiores da alma, quanto à visão atual,
sensível e imaginária. Logo, também a trindade, que está na mente, segundo a qual o homem é à
imagem de Deus, deve ser considerada quanto à visão atual.

SOLUÇÃO. – Como já se disse antes, a essência da imagem implica uma certa representação da espécie.
Se pois devemos admitir na alma a imagem da Trindade divina, necessário é que ela seja considerada,
principalmente, por onde, tanto quanto possível, mais aproximadamente representa a espécie das
divinas Pessoas. Ora, as divinas Pessoas se distinguem pela processão do Verbo, da Pessoa dicente, e
pela processão do Amor, que liga as outras duas. Ora, em a nossa alma, o verbo não pode exigir sem a
cogitação atual, como diz Agostinho. Por onde, primária e principalmente, a imagem da Trindade está
na mente pelos atos, enquanto que, do conhecimento que temos, formamos interiormente, cogitando,
o verbo e, daí, prorrompemos no amor. Mas, como os princípios dos atos são os hábitos e as potências,
e como o ser está, virtualmente, no seu princípio, a imagem da Trindade pode ser admitida, na alma,
secundária e como consequentemente, quanto às potências e, principalmente, quanto aos hábitos,
enquanto que, nestes, os atos existem virtualmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Em o nosso ser está a imagem de Deus, isso nos é
próprio, e nos torna superiores aos outros animais; ora, tal nos cabe pela mente. Por onde, esta
trindade é idêntica com aquela que Agostinho admite e que consiste na mente, no conhecimento e no
amor.

RESPOSTA À SEGUNDA. – Agostinho distingue essa trindade, primeiro, na mente. Mas a mente embora,
de certo modo, se conheça a si mesma, totalmente, também, de certo modo, ignora–se, enquanto,
sendo distinta das outras coisas, a si mesma também se busca, como Agostinho consequentemente o
prova. Por onde, como o conhecimento não é totalmente adequado à mente, ele admite, na alma, três
propriedades da mente, a saber, a memória, a inteligência e a vontade, que ninguém ignora que as
possui. E, nessas três, distingue, principalmente, a imagem da Trindade, como sendo a primeira
distinção, de certo modo, deficiente.

RESPOSTA À TERCEIRA. – Como Agostinho o prova, dizemos que inteligimos, queremos ou amamos
certas coisas, tanto quando delas cogitamos como quando não cogitamos. Ora, quando essas coisas não
são objeto do nosso pensamento, são–no somente da memória, que, segundo o mesmo, não é senão a
retenção habitual do conhecimento e do amor. Mas como, segundo ele próprio o diz, o verbo aí não
pode estar, sem um pensamento atual, pois, pensamos em tudo o que dizemos, ainda que seja por
aquele verbo interior, que não pertence à língua de nenhum povo, é antes por aquelas três potências
que a imagem é conhecida, a saber, pela memória, pela inteligência e pela vontade . E chamo agora
inteligência o ato mesmo pelo qual inteligimos, quando pensamos ; e vontade, ou amor ou dileção o que
une esse pai e que filho, Por onde é claro, que coloca a imagem da divina Trindade antes na inteligência
e na vontade atual, do que no modo pelo qual ela existe na retenção habitual da memória; embora
também quanto a esse modo, a imagem da Trindade esteja de certa maneira na alma, como no mesmo
passo diz. E assim é manifesto que a memória, a inteligência e a vontade não são três virtudes, como se
diz nas Sentenças.

RESPOSTA À QUARTA. – Poder–se–ia responder com as palavras de Agostinho: a mente sempre se
lembra de si mesma, sempre a si mesma se intelige e ama. O que alguns entendem como significando
que a alma tem como que a inteligência atual e o amor de si mesma. Mas esta interpretação Agostinho
a exclui acrescentando, que nem sempre ela se pensa como separada das causas diferentes de si. E
assim, é claro que, a alma sempre se intelige e ama, não atual, mas habitualmente. Embora se possa
dizer que, percebendo o seu ato, intelige–se a si mesma sempre que intelige qualquer objeto. Mas nem
sempre inteligindo atualmente, como se dá com quem está adormecido, necessariamente deve
concluir–se que os atos, embora não permaneçam sempre, em si mesmos, permanecem, contudo
sempre nos seus princípios, isto é, nas potências e nos hábitos. Por onde, diz Agostinho: Se a alma
racional foi feita à imagem de Deus afim de poder usar da razão e do intelecto para inteligir e
contemplar a Deus, tal imagem existiu, nela desde o princípio em que começou a existir.

## Art. 8 — Se a Imagem da divina Trindade está na alma só por comparação com o objeto, que é Deus.
O oitavo discute–se assim. – Parece que a imagem da divina Trindade está na alma não só por
comparação com o objeto, que é Deus.

1. Pois, como já se disse, a imagem da divina Trindade está na alma, porque o verbo, em nos, procede
do dicente e o amor, de ambos. Ora isto se dá, em nós, em relação a qualquer objeto. Logo, em relação
a qualquer objeto, esta em a nossa mente a imagem da divina Trindade.

2. Demais. – Agostinho diz, que, quando buscamos na alma a trindade, buscamo–Ia em toda a alma, sem
separar a ação racional, relativa às causas temporais, da contemplação das coisas eternas, Logo,
também em relação aos objetos temporais, a imagem da Trindade está na alma.

3. Demais. – Por dom da graça é que podemos inteligir e amar a Deus. Se pois, pela memória,
inteligência e vontade, ou amor de Deus, é que a imagem da Trindade está na alma, essa imagem está
no homem, não pela natureza deste, mas pela graça. E assim, não é comum a todos.

4. Demais. – Os santos, que estão na pátria, são conformes em máximo grau à imagem de Deus, quanto
à visão da glória. Por onde, diz a Escritura: Somos transformados de claridade em claridade, na mesma
imagem. Ora, pela visão da glória, conhecem–se as coisas temporais. Logo, também por comparação
com as coisas temporais, a imagem de Deus está em nos.
Mas, em contrário, diz Agostinho: a imagem de Deus está na mente, não porque esta se lembra de si e a
si se intelige e ama; mas porque também pode lembrar–se de Deus, por quem foi feita, bem como
inteligí–lo e amá–lo. Logo, é muito menos, relativamente aos outros objetos, que a imagem de Deus
está na mente.

SOLUÇÃO. – Como já se disse antes, imagem importa semelhança, realizando, de certo modo, a
representação da espécie. Por onde, necessariamente, a imagem da divina Trindade está na alma
segundo algo que represente as divinas Pessoas pela representação da espécie, como é possível à
criatura. Ora, como já se disse, as divinas Pessoas distinguem–se pela processão do Verbo, do dicente, e
pela do Amor, de ambos! Ora, o verbo divino nasce de Deus pelo conhecimento de si mesmo, e o Amor
procede de Deus enquanto Deus a si mesmo se ama. Mas é manifesto, que a diversidade dos objetos
diversifica a espécie do verbo e a do amor. Pois, na mente do homem, o verbo concebido no
concernente a uma pedra não é idêntico, especificamente, ao que respeita a um cavalo, nem é o amor
especificamente o mesmo. Por onde, a imagem divina se considera no homem, quanto ao verbo
concebido a respeito do conhecimento de Deus e ao amor, daí derivado. E assim, a imagem de Deus
está na alma enquanto ela é levada ou lhe é natural ser levada para Deus. Ora, a mente é levada para
algum objeto, de duplo modo: direta e imediatamente; e indireta e mediatamente, como quando se diz
que alguém, vendo a imagem de um homem num espelho, levado para esse homem. E por isso
Agostinho diz: a mente lembra–se de si, intelige–se, ama–se, Se discernimos isso, discernimos a
trindade; não, por certo. Deus, mas já a imagem de Deus. E isto se dá, não porque a mente seja levada
para si mesma, absolutamente, mas porque, desse modo, pode ulteriormente ser levada para Deus,
como é claro pela autoridade supra citada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A essência da imagem, necessariamente inclui que uma
cousa há de proceder de outra, mas também devemos considerar que cousa é a procedente dessa
outra; isto é, que o Verbo de Deus procede do conhecimento de Deus.

RESPOSTA À SEGUNDA. – Por certo que a alma toda representa uma trindade, não porque, como
sustenta a objeção, além da ação relativa às coisas temporais e da contemplação das eternas, haja–se
de buscar um terceiro termo em que a trindade se complete. Mas, na parte racional, que se ocupa com
coisas temporais, embora se possa distinguir a trindade, não se pode, contudo, distinguir a imagem de
Deus, como a seguir se diz; porque o conhecimento dessas coisas temporais é adventício à alma. E
demais, os próprios hábitos pelos quais se conhecem tais coisas, nem sempre estão em exercício; mas,
ora, se exercem pela sua presença; ora, só pela memória, mesmo depois que começam a se manifestar
como presentes. O que é claro na fé, a qual, temporalmente nos advém, no presente; porém no estado
da futura beatitude já não haverá fé, senão só a memória dela.

RESPOSTA À TERCEIRA. – O conhecimento e o amor meritórios de Deus só existem pela graça. Há,
contudo certo conhecimento e amor natural, como antes já se disse. Mas também é natural o fato
mesmo de a mente poder inteligir a Deus, usando da razão, pelo que dissemos que a imagem de Deus
sempre permanece na mente; e segundo diz Agostinho, quer essa imagem de Deus esteja esquecida,
como obumbrada, de modo a quase não existir, como se dá com aqueles que não tem o uso da razão;
quer seja obscura e deformada, como nos pecadores; quer seja clara e bela, como nos justos.

RESPOSTA À QUARTA. – Pela visão da glória, as coisas temporais serão vistas no próprio Deus; e por isso
a visão de tais coisas pertencerá à imagem de Deus. E é o que diz Agostinho: naquela natureza à qual a
mente felizmente aderir, verá imutavelmente tudo o que vir. Pois, no Verbo incriado estão as razões de
todas as criaturas.

## Art. 9 — Se a semelhança se distingue, com propriedade da imagem.
O nono discute–se assim. – Parece que a semelhança não se distingue com propriedade da imagem.

1. Pois, o gênero não se distingue, com propriedade, da espécie. Ora, a semelhança esta para a imagem
como o gênero para a espécie; porque, onde está a imagem, esta imediatamente a semelhança, mas
não inversamente, como se diz numa certa obra. Logo, não é com propriedade que a semelhança se
distingue da imagem.

2. Demais. – A essência da imagem consiste não só na representação das divinas Pessoas, mas também
na da divina essência; a cuja representação pertence a imortalidade e a indivisibilidade. Logo, não é com
propriedade que se diz: a semelhança esta na essência, porque é imortal e indivisível; e a imagem, nas
outras propriedades.

3. Demais. – A imagem de Deus no homem é tríplice: a da natureza, a da graça e a da glória, como antes
já se estabeleceu. Ora, a inocência e a justiça pertencem à graça. Logo, é com impropriedade que se diz:
a imagem é entendida quanto à memória, à inteligência e à vontade; a semelhança, porém, quanto à
inocência e à justiça.

4. Demais. – O conhecimento da verdade pertence à inteligência; porém o amor da virtude, à vontade; e
essas são duas partes da imagem. Logo, é com impropriedade que se diz: a imagem esta no
conhecimento da verdade; a semelhança, no amor da virtude.
Mas, em contrário, diz Agostinho: Há quem pense não serem inúteis dois nomes, para a imagem e para
a semelhança; pois, se fossem o mesmo, bastar–lhes–ia um só nome.

SOLUÇÃO. – A semelhança é uma unidade; pois, a unidade na qualidade causa a semelhança, como diz
Aristóteles. Ora, a unidade, como a bondade e a verdade, sendo um dos transcendentais, é comum a
todos os seres e pode aplicarse a cada ser em particular. Por onde, assim como o bem pode não só ser
precedente a um determinado ser em particular, como também subsequente, enquanto lhe designa
alguma perfeição; o mesmo se dá na comparação da semelhança com a imagem. Assim; o bem do
homem é lhe precedente, por ser o homem um bem particular; mas também é lhe subsequente,
enquanto dizemos, especialmente, que um homem é bom pela perfeição da virtude. Do mesmo modo, a
semelhança é considerada como preliminar à imagem, enquanto é mais comum que esta, conforme já
se disse. Mas é considerada como subsequente à mesma, enquanto exprime uma perfeição dela. Assim,
dizemos que uma imagem é ou não semelhante ao ser ao qual pertence, enquanto o representa perfeita
ou imperfeitamente.
Por onde, a semelhança pode distinguir–se da imagem de dois modos. Primeiro, como preliminar a esta
e existente em vários seres. Então, a semelhança se funda naquilo que é mais comum às propriedades
da natureza intelectual, em relação às quais, propriamente, se considera a imagem. E neste sentido se
disse: ninguém duvida que o espírito, isto é, a mente, foi jeito à imagem de Deus; e algum querem que
as outras propriedades do homem, isto é, as que pertencem às partes inferiores da alma, ou ainda ao
corpo mesmo, tenham sido feitas à semelhança. E também se disse que a semelhança de Deus se funda
na alma, enquanto esta é incorruptível: pois, o corruptível e o incorruptível são diferenças do ente em
comum. De outro modo, pode–se considerar a semelhança enquanto significa a expressão e a perfeição
da imagem. E neste sentido Damasceno diz: o que é feito à imagem exprime o elemento intelectual e
dotado do Livre arbítrio, tendo o poder de dispor de si; o que, porém, a semelhança exprime é a
semelhança da virtude, na medida em que ela pode existir no homem. E a isto mesmo se reduz o dito,
que a semelhança diz respeito ao amor da virtude; pois, não há virtude sem amor da mesma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A semelhança não se distingue da imagem, pela noção
comum da semelhança; pois assim, esta se inclui na noção da imagem mesma; mas porque alguma
semelhança é deficiente em relação à essência da imagem, ou ainda, é perfectiva da imagem.

RESPOSTA À SEGUNDA. – A essência da alma está implicada na imagem, enquanto a alma representa a
divina essência, quanto às propriedades da natureza intelectual; não, porém quanto às condições
consequentes ao ser em comum, como é ser simples e indissolúvel.

RESPOSTA À TERCEIRA. – Também há certas virtudes que existem naturalmente na alma, ao menos
quanto a alguns germens; e, quanto a estes, poder–se–ia admitir a semelhança natural. Embora não seja
impróprio que a chamada imagem, num ponto de vista, se chame semelhança em outro.

RESPOSTA À QUARTA. – O amor do verbo, que é o conhecimento amado, pertence à essência da
imagem; mas o amor da virtude pertence à semelhança, bem como a virtude.
