# Questão 27: Da processão ou da origem das pessoas divinas
Depois de termos tratado do que concerne à unidade da essência divina, resta tratar do que pertence à
Trindade das Pessoas, em Deus. E distinguindo-se as Pessoas divinas pelas relações de origem, devemos,
conforme a ordem da doutrina, tratar primeiro da origem ou da processão; segundo, das relações de
origem; terceiro, das Pessoas.
Sobre a processão discutem-se cinco artigos:

## Art. 1 — Se em Deus há alguma processão.
(I Sent., dist. XIII, a. 1; IV Cont. Gent., cap. XI; De Pot., q. 10, a. 1).
O primeiro discute-se assim. — Parece que em Deus não há nenhuma processão.

1. — Pois, processão significa movimento para o exterior. Ora, em Deus nada há de móvel nem exterior.
Logo, nem processão.

2. Demais. — Todo procedente é diverso daquilo de que procede. Ora, em Deus, sumamente simples,
não há nenhuma diversidade. Logo, em Deus não há processão.

3. Demais. — Proceder de outro parece repugnar à noção de primeiro princípio. Ora, Deus é o primeiro
princípio, como já se demonstrou. Logo, em Deus não pode haver processão.
Mas, em contrário, diz o Senhor (Jo 8, 42): Eu saí de Deus.

SOLUÇÃO. — A Escritura usa, falando das coisas divinas, de expressões que implicam processão. Ora,
dessa processão há vários conceitos. Uns a compreendem no sentido em que o efeito procede da causa;
e assim Ário, dizendo que o Filho procede do Pai como a primeira criatura deste, e o Espírito Santo, do
Pai e do Filho, como criatura de ambos. E segundo esta opinião, nem o Filho nem o Espírito Santo seriam
verdadeiro Deus, o que vai contra a Escritura quando diz, do Filho (1 Jo, 5, 20): E estejamos em seu
verdadeiro Filho. Este é o verdadeiro Deus; e do Espírito Santo (1 Cor 6, 19): Acaso não sabeis que os
vossos membros são templos do Espírito Santo? Ora, só Deus pode ter templo. — Outros, porém,
concebem a processão no sentido em que se diz que a causa se manifesta no efeito, movendo-o ou
imprimindo-lhe a sua semelhança. Assim o entendeu Sabélio, ensinando que o mesmo Deus Padre se
chama Filho, enquanto encarnado na Virgem, e Espírito Santo enquanto santifica e dá vida à criatura
racional. Mas contra esta doutrina vão as palavras do Senhor, a respeito de si mesmo (Jo 5, 19): O Filho
não pode de si mesmo fazer coisa alguma; e muitas outras, mostram não ser o Pai o mesmo que o Filho.
Mas, consideradas diligentemente, ambas essas opiniões concebem a processão como tendendo para o
exterior; e por isso não a atribuem a Deus. Mas como toda processão supõe uma certa ação, assim
como pela ação que recai sobre a matéria exterior, a processão é exterior, assim pela que permanece no
próprio agente, é interior. O que sobretudo se vê no intelecto, cuja ação, o inteligir, permanece no ser
que intelige; pois, quem intelige, por isso mesmo causa algo dentro de si, que é o conceito da coisa
inteligida, nascida da potência intelectiva e procedente do conhecimento da coisa. E esse conceito,
expresso pela palavra, chama-se verbo mental, significado pelo verbo oral. Mas, como Deus está acima
de tudo, o que dele se diz não se deve entender ao modo das criaturas ínfimas, que são os corpos, mas
por semelhança com as criaturas supremas, que são as substâncias intelectuais, se bem tal semelhança
seja deficiente para representar o divino. Por onde, não se deve conceber a processão como a dos seres
corpóreos, quer pelo movimento local, quer pela ação de alguma causa produtora de um efeito exterior,
como o calor procedente do agente, que aquece, para o corpo aquecido; mas segundo a emanação
inteligível, isto é, do verbo inteligível emanando de quem o pronuncia e neste permanecendo. E é assim
que a fé católica atribui a processão a Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ela se funda na processão por movimento local, ou na
que se realiza pela ação transitiva para a matéria exterior ou o efeito exterior. Ora, tal processão não
existe em Deus, como dissemos.

RESPOSTA À SEGUNDA. — O que procede por processão exterior deve ser diverso daquilo donde
procede; mas o que procede interiormente pelo processo inteligível, não é necessariamente diverso;
antes, quanto mais perfeitamente proceder, tanto mais se unifica com o ser donde procede. Pois, é
manifesto, que quanto mais uma coisa é inteligida, tanto mais íntima e mais unida com o ser inteligente
é a concepção intelectual; porque o intelecto, ao inteligir em ato, unifica-se com a coisa inteligida.
Donde, como o inteligir divino é o auge da perfeição, como vimos, necessário se faz que o Verbo divino
seja perfeitamente uno com o ser donde procede, sem a mínima diversidade.

RESPOSTA À TERCEIRA. — Proceder de um principio, como de estranho e diverso, repugna à essência
do primeiro princípio; mas proceder como íntimo e sem diversidade, de maneira inteligível, é da
essência do primeiro princípio. Assim, pois, quando dizemos ser o construtor o princípio da casa, esse
princípio inclui, por essência, a concepção da sua arte, que também se incluiria na essência do primeiro
princípio se tal princípio fosse o construtor. Ora, Deus, primeiro princípio das coisas, está para as coisas
criadas como o artífice, para as artificiadas.

## Art. 2 — Se a processão, em Deus, pode chamar-se geração.
(IV Cont. Gent., cap. X, XI; De Pot., q. 2, a. 1; Opusc. II, Contra Graecos, Armemos, etc., cap. III;
Compend. Theologiae, cap. XL, XLIII; ad Coloss., cap. 1, lect IV).
O segundo discute-se assim. — Parece que a processão, em Deus, não pode chamar-se geração.

1. — Pois, a geração é a passagem do não ser para o ser e se opõe à corrupção, sendo a matéria o
sujeito de uma e outra. Ora, nada disto convém a Deus. Logo, não pode haver nele geração.

2. Demais. — Como se disse, em Deus há processão ao modo inteligível. Ora, em nós, tal processão não
se chama geração. Logo, nem em Deus.

3. Demais. — Todo gerado, recebendo o ser do gerador, o ser de qualquer gerado é recebido. Mas
nenhum ser recebido é por si subsistente. Ora, como o ser divino é por si subsistente, segundo antes se
provou, segue-se que o ser de nenhum gerado é divino. Logo, em Deus não há geração.
Mas, em contrário, a Escritura (Sl 2, 7): Eu te gerei hoje.

SOLUÇÃO. — A processão do Verbo, em Deus, chama-se geração. O que se evidencia considerando-se
que em duplo sentido usamos do vocábulo geração. Num sentido, é comum a todos os seres
susceptíveis de geração e de corrupção; e assim, a geração nada mais é que a mudança do não-ser para
o ser. Noutro sentido, refere-se propriamente aos seres vivos; e assim, a geração significa a origem de
um ser vivo do princípio vivente conjunto, ao que propriamente se chama natividade. Todavia, nem
tudo que de tal maneira existe se diz gerado, senão propriamente o que procede por semelhança de
natureza. Assim, o pêlo ou o cabelo não têm a natureza de ser gerado ou de filho, mas somente aquilo
que procede por semelhança de natureza. Não, porém, qualquer semelhança. Assim, os vermes,
gerados dos animais, não têm natureza de geração nem de filiação, embora tenham semelhança
genérica. O que é necessário, pois, para haver em essência tal geração, é que ela proceda por
semelhança, em a natureza da mesma espécie, como o homem procede do homem e o cavalo, do
cavalo. Ora, nos seres vivos, que passam da potência para o ato, como o homem e os animais, incluem-
se ambos os modos de geração. Se, porém houver algum ser vivo cuja vida não seja uma passagem da
potência para o ato, a processão, se porventura existir em tal ser, exclui absolutamente a primeira
espécie de geração, mas pode ter a própria dos seres vivos. — Por onde, a processão do Verbo, em
Deus, é por natureza uma geração, pois procede a modo de atividade inteligível, que é uma operação
vital, e de um princípio conjunto, como dissemos; e pela razão de semelhança, pois a concepção do
intelecto é semelhança da coisa inteligída, e é existente na mesma natureza, sendo em Deus idênticos o
inteligir e o existir, como demonstramos. Portanto, a processão do Verbo, em Deus, se chama geração e
o próprio Verbo procedente se chama Filho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ela colhe, quanto à geração no primeiro sentido,
enquanto implica a passagem da potência para o ato. E, nesse sentido, não existe em Deus, como o
dissemos.

RESPOSTA À SEGUNDA. — O inteligir em nós não é a substância mesma do intelecto. Por onde, o nosso
verbo, procedente da atividade intelectual, não é da mesma natureza que o ser donde procede; e por
isso não tem a natureza própria e completa da geração. Ao contrário, o inteligir divino é a substância
mesma do ser divino que intelíge, como vimos. Por onde, o Verbo procede como subsistente na mesma
natureza, e por isso propriamente se chama gerado e Filho. Daí o empregar a Escritura expressões
próprias a significar a geração dos seres vivos, como a concepção e o parto, para exprimir a processão
da divina Sapiência. Assim, da pessoa da divina Sapiência diz (Pr 8, 24): Ainda não havia os abismos e eu
estava já concebida. Antes de haver outeiros era eu dada à luz. Porém, usamos do nome concepção, em
relação ao nosso intelecto, por existir no verbo deste semelhança com a causa inteligida, embora não
haja identidade de natureza.

RESPOSTA À TERCEIRA. — Nem tudo o que é recebido o é num sujeito; do contrário não se poderia
dizer que toda a sua substância a criatura a tenha recebido de Deus; pois, não há nenhum sujeito capaz
de receber toda a sua substância. Por onde, o que é gerado, em Deus, recebe o ser do gerador; não que
tal ser seja recebido em alguma matéria, o que repugna à subsistência do ser divino; mas se diz recebido
enquanto, procedendo de outro, tem o ser divino, e não como tendo existência diversa da do ser divino.
Pois a própria perfeição do ser divino contém o Verbo, por processão inteligível; e o principio do Verbo,
bem como tudo o que lhe pertence à perfeição, como dissemos.

## Art. 3 — Se há em Deus outra processão além da geração do Verbo.
(I Sent., dist. XIII, a. 2; IV Cont. Gent., cap. XIX; De Pot., q. 10, a. 1, 2; Opusc. II, Contra Graecos, Armenos.
etc., cap. III).
O terceiro discute-se assim. — Parece não haver em Deus outra processão além da geração do Verbo.

1. — Pois, pela mesma razão haveria, dessa processão, outra, e assim ao infinito, o que repugna. Logo, é
mister limitarmo-nos à primeira, de modo que haja em Deus só uma processão.

2. Demais. — Cada natureza tem apenas um modo de comunicação; e isto porque as operações
tendentes a um termo têm unidade e diversidade. Ora, a processão, em Deus, implica a comunicação da
natureza divina; e sendo esta somente uma, como se viu, conclui-se que só uma processão há em Deus.

3. Demais. — Se há em Deus outra processão além da processão inteligível do Verbo, não poderá ser
senão a do Amor, que implica ato da vontade. Ora, tal processão não pode ser diferente da do intelecto
inteligível, porque em Deus a vontade não difere do intelecto, como se viu. Logo, em Deus não há outra
processão além da do Verbo.
Mas, em contrário, o Espírito Santo procede do Pai. Pois é diferente do Filho, segundo a Escritura (Jo 15,
26):Eu rogarei ao Pai e Ele vos dará outro consolador. Logo, em Deus há outra processão, além da do
Verbo.

SOLUÇÃO. — Em Deus há duas processões, a do Verbo e uma outra. O que se evidencia considerando
que em Deus a processão implica um ato que não tende a nenhum termo extrínseco, mas permanece no
próprio agente. Ora, tal ato, nos seres de natureza intelectual, pertence ao intelecto e à vontade. Ora, a
processão do Verbo implica um ato inteligível. Segundo, porém, o ato da vontade, há em nós outra pro-
cessão — a do amor, pela qual o amado está no amante, assim como, pela concepção do verbo, a coisa
dita ou inteligida está no inteligente. Donde, além da processão do Verbo, há em Deus outra processão,
que é a do Amor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não é necessário ir até ao infinito, nas processões
divinas; pois, a processão interior, em a natureza intelectual, termina na processão da vontade.

RESPOSTA À SEGUNDA. — Tudo o que há em Deus é Deus, como vimos; o que não se dá com os outros
seres. Por onde, a natureza divina se comunica por qualquer processão sem termo exterior; não assim
as demais naturezas.

RESPOSTA À TERCEIRA. — Embora em Deus não haja diferença entre a vontade e o intelecto, contudo é
da essência da vontade e do intelecto que as processões dependentes da ação de uma e de outro se
realizem numa certa ordem. Não há, portanto, processão do amor senão relativamente à processão do
verbo; pois, nada pode ser amado pela vontade sem ser concebido pelo intelecto. Assim, pois, como há
uma certa ordem entre o Verbo e o principio donde procede, embora em Deus sejam idênticas a
substância e a concepção do intelecto, assim também, embora em Deus se identifiquem a vontade e o
intelecto, a processão do amor divino distingue-se, por ordem, da processão do Verbo divino; porque da
essência do Amor é proceder da concepção do intelecto.

## Art. 4 — Se a processão do Amor, em Deus, é geração.
(Infra, q. 30, a. 2, ad 2; I Sent., dist. XIII, a 3, ad 3, 4; III. dist. VIII. a. 1, ad 8; IV Contra Cent., cap. XIX; De
Pot., q. 2. a. 4, ad 7; q. 10, a. 2, ad 22; Compend. Theol., cap. XLVI).
O quarto discute-se assim. — Parece que a processão do Amor, em Deus, é geração.

1. — Pois, o que procede por semelhança de natureza, nos seres vivos, se diz gerado e nascido. Ora, o
que em Deus procede ao modo do amor procede por semelhança de natureza, do contrário seria
estranho à natureza divina e haveria então processão para o exterior. Logo, o que em Deus procede ao
modo do amor procede como gerado e nascido.

2. Demais. — Como a semelhança é da essência do verbo, assim também é da essência do amor; e por
isso diz a Escritura (Eccl 13, 19): Todo animal ama o seu semelhante. Se, portanto, em razão da
semelhança, convém ao Verbo procedente ser gerado e nascido, resulta que também ao Amor
procedente convém o ser gerado.

3. Demais. — Não está num gênero o que não está em nenhuma das suas espécies. Se pois, há em Deus
alguma processão do Amor, é necessário que, além desse nome comum, tenha ela um nome especial.
Ora, não se lhe pode dar outro nome sem ser o de geração. Logo, resulta que a processão do Amor em
Deus é geração.
Mas, em contrário, é que, se assim fosse, seguir-se-ia que o Espírito Santo, procedente como Amor,
procederia como gerado; o que vai contra o dito de Atanásio: O Espírito Santo vem do pai e do Filho,
não feito, nem criado, nem gerado, mas procedente.

SOLUÇÃO. — A processão do Amor em Deus se não deve chamar geração. Para evidenciá-lo, devemos
saber que a diferença entre o intelecto e a vontade está em que o intelecto se atualiza quando nele está
à causa inteligida, segundo a semelhança dela; ao passo que a vontade se atualiza, não porque nela
exista alguma semelhança do que é querido, mas por inclinar-se para a causa querida. Portanto, a
processão, segundo a natureza do intelecto, funda-se na noção de semelhança e como tal, pode ter
natureza de geração, pois todo gerador gera o seu semelhante. Porém a processão, segundo a natureza
da vontade, não se funda na noção de semelhança, mas antes, na noção de um agente que impele e
move para algum termo. Logo, o que em Deus procede ao modo do amor não procede como gerado ou
como filho, mas antes como espírito, nome que designa uma certa moção vital e um impulso, no sentido
em que se diz que alguém é movido ou impelido pelo amor a fazer alguma causa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Tudo o que existe em Deus se identifica com a divina
natureza, não se podendo portanto, em razão dessa identificação, conceber a noção própria de tal ou tal
processão, segundo a qual uma se diferencia de outra. Mas, é necessário que a noção distinta de tal e
tal processão seja considerada segundo a ordem de uma em relação à outra. Ora, semelhante ordem é
considerada segundo a noção de vontade e de intelecto. Donde, segundo tal noção própria, a cada
processão, em Deus, lhe cabe o nome adequado, imposto para significar a noção própria do objeto. E
daí resulta que o procedente ao modo do amor recebe a natureza divina e contudo não se chama
nascido.

RESPOSTA À SEGUNDA. — Uma é a semelhança do verbo e outra a do amor. Tem-na o verbo enquanto
é certa semelhança da causa inteligida, como o gerado é semelhança do gerador. Tem-na o amor, não
por ser em si mesmo semelhança, mas por esta ser princípio do amor. Donde se não segue que o amor
seja gerado, mas que o gerado é princípio do amor.

RESPOSTA À TERCEIRA. — Só pelas criaturas podemos nomear a Deus, como dissemos. E porque nas
criaturas a comunicação da natureza só se dá pela geração, a processão em Deus não tem outro nome
próprio ou especial senão o de geração. Dai o ficar sem nome especial a processão que não é geração,
podendo contudo chamar-se espiração por ser processão do Espírito.

## Art. 5 — Se em Deus há mais de duas processões.
(IV Cont Gent., cap. XXIV; De Pot., q. 9,a. 9; 10, a. 2. ad argumenta sed contra)
O quinto discute-se assim. — Parece que há em Deus mais de duas processões.

1. — Pois, assim como a ciência e a vontade se atribuem a Deus, assim também a potência. Se, portanto,
se admitem em Deus duas processões, segundo o intelecto e a vontade, resulta que se deve admitir
uma terceira, segundo a potência.

2. Demais. — A bondade é por excelência o princípio da processão; pois, como se disse, o bem é difusivo
de si. Logo, devemos admitir uma processão, em Deus, segundo a bondade.

3. Demais. — O vigor da fecundidade é maior em Deus que em nós. Ora, em nós não há só uma, mas
muitas processões do verbo; pois de um verbo procede outro, e semelhantemente, de um, outro amor.
Logo, há em Deus mais de duas processões.
Mas, em contrário, em Deus só há dois procedentes, o Filho e o Espírito Santo. Logo, só há nele duas
processões.

SOLUÇÃO. — Em Deus só se podem admitir processões segundo os atos imanentes no agente. Ora, tais
atos, em a natureza intelectual e divina, são apenas dois — inteligir e querer. Pois o sentir, que também
se considera como operação do que sente, está fora da natureza intelectual; nem é totalmente diverso
do gênero de atos tendentes ao exterior, pois o sentir se completa pela ação sensível, no sentido. Donde
se conclui que em Deus não pode haver outra processão, além da do Verbo e do Amor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A potência é princípio de ação transitiva, e por isso,
fundados nela, admitimos a ação transitiva. E assim, quanto ao atributo da potência, não se admite
processão da Pessoa divina, mas só das criaturas.

RESPOSTA À SEGUNDA. — A bondade, como diz Boécio, pertence à essência e não à operação, a não
ser talvez como objeto da vontade. Donde, como é necessário admitir as processões divinas, em relação
a certos atos, não se podem admitir outras processões, relativamente à bondade e atributos
semelhantes, a não ser a do Verbo e a do Amor, pelas quais Deus intelige e ama a sua essência, a sua
verdade e a sua bondade.

RESPOSTA À TERCEIRA. — Como já demonstramos, Deus, por um ato simples, tudo intelige e
semelhantemente tudo quer. Donde, o não poder existir nele um verbo, procedendo, de outro verbo,
nem um amor procedendo de outro amor; mas existe um só Verbo perfeito com um só perfeito amor. E
isto lhe manifesta a perfeita fecundidade.