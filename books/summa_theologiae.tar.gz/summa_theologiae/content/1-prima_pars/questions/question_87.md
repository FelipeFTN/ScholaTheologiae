# Questão 87: Como a alma intelectiva se conhece a si mesma e àquilo que
nela existe.
Em seguida deve-se considerar como a alma intelectiva se conhece a si mesma e àquilo que nela existe.
E, sobre estes pontos, quatro artigos se discutem:

## Art. 1 — Se a alma intelectiva se conhece a si mesma pela sua essência.
(Supra, q. 14, a. 2, ad 3; II Cont. Gent., cap. LXXV; III, cap. XLVI; De Verit., q. 8, a. 6; q. 10, a. 8; Qu. De
Anima, a. 16, ad 8; II De Anima, lect. VI; III, lect. IX).
O primeiro discute-se assim. ― Parece que a alma intelectiva se conhece a si mesma, pela sua
essência.

1. ― Pois diz Agostinho, que a mente incorpórea conhece a si mesma por si mesma.

2. Demais. ― O anjo e a alma humana convêm no gênero da substância intelectual comum. Ora, o anjo
se intelige a si mesmo, pela sua essência. Logo, também a alma humana.

3. Demais. ― No que não há matéria, o intelecto se identifica com o que é inteligido, como diz
Aristóteles. Ora, a alma humana, não sendo ato de nenhum corpo (q. 76, a. 1), não tem matéria. Logo,
nessa alma, o intelecto se identifica com o que é inteligido; e, portanto, ela se intelige pela sua essência.
Mas, em contrário, como diz Aristóteles, o intelecto se intelige tanto a si mesmo como às outras coisas.
Ora, estas ele as intelige, não pela essência, mas pelas semelhanças delas. Logo, também não se intelige
a si, pela sua essência.

SOLUÇÃO. ― É cognoscível o que é atual e não o que é potencial, como diz Aristóteles; assim, um ser
conhecido é ente e verdadeiro, enquanto atual. O que manifestamente se vê, nas coisas sensíveis; pois,
a vista não percebe o colorido potencial, mas só o atual. E, semelhantemente, é manifesto que o
intelecto, como cognoscitivo das coisas materiais, só conhece o que é atual; donde vem que não
conhece a matéria prima, senão enquanto esta tem proporção com a forma, como diz Aristóteles. Por
onde, as substâncias imateriais, na medida em que são atualizadas pela essência própria, nessa mesma
são inteligíveis por essa essência.
Ora, a essência de Deus; que é ato puro e perfeito, é, em si e perfeitamente, por si mesma inteligível.
Por onde, Deus, pela sua essência, intelige, não só a si mesmo, como a todas as causas. ― A essência do
anjo, porém, pertence ao gêneros dos inteligíveis, como ato que é, mas não como ato puro e completo.
Por onde, o inteligir angélico não é completo, pela essência do anjo; pois embora este se intelija a si
mesmo, pela sua essência, contudo não pode conhecer tudo, por essa mesma essência; mas conhece as
coisas diferentes de si pelas semelhanças delas. ― Ao passo que o intelecto humano se comporta, no
gênero das coisas inteligíveis, somente como ser potencial, assim como a matéria prima se comporta no
gênero das coisas sensíveis; e, por isso ele se chama possível. Assim, pois, considerado na sua essência,
comporta-se como potência inteligente. Por onde, tem, de si mesmo, virtude para inteligir, não, porém,
para ser inteligido, senão quando se atualiza. E assim, até os próprios Platônicos admitiam a ordem dos
entes inteligíveis como superior à dos intelectos; porque, o intelecto não intelige senão pela
participação do inteligível; ora, o que participa é inferior ao que é participado, na opinião deles.
Se, pois, o intelecto humano se atualizasse por participação das formas inteligíveis separadas, como
ensinavam os Platônicos, por uma tal participação das coisas incorpóreas o intelecto humano se
inteligiria a si mesmo. Ora, como é conatural ao nosso intelecto, no estado da vida presente, referir-se
às coisas materiais e sensíveis, como se disse antes (q. 84, a. 7), é conseqüente que ele se intelija a si
mesmo, na medida em que é atualizado pelas espécies abstraídas das coisas sensíveis, pela luz do
intelecto agente, que é o ato dos próprios inteligíveis e, mediante estes, ato do intelecto possível. Logo,
não é pela sua essência, mas pelo seu ato, que o nosso intelecto se conhece a si mesmo. E isto, de dois
modos. ― Particularmente, enquanto Sócrates ou Platão percebe a si mesmo como tendo uma alma
intelectiva, porque percebe o inteligir próprio. ― De outro modo, universalmente, enquanto
consideramos a natureza da mente humana, pelo ato do intelecto.
É verdade, porém, que o juízo e a eficácia deste conhecimento, pelo qual conhecemos a natureza da
alma, compete-nos pela derivação da luz do nosso intelecto, da verdade divina, na qual se contêm as
razões de todas as coisas, como antes se disse (q. 84, a. 5). Por onde, Agostinho diz: Contemplamos a
verdade inviolável, pela qual, tão perfeitamente quanto podemos, definimos, não qual seja a mente de
cada homem, mas qual deva ser, pelas razões sempiternas.
Ora, há diferença entre estes dois conhecimentos. ― Pois, para se ter o primeiro conhecimento da alma,
basta a presença mesma desta, que é o princípio do ato, pelo qual a alma se percebe a si mesma. ―
Mas, para ter da alma o segundo conhecimento, não basta a presença da mesma, mas requer-se
diligente e sutil inquisição. Donde vem que muitos ignoram a natureza da alma, e muitos erraram
também sobre a natureza dela. Pelo que Agostinho diz, falando de tal inquisição da alma: Que a alma
não procure considerar-se como ausente, mas cure de se discernir como presente, i. é., conhecer a sua
diferença, das outras coisas, o que é conhecer a sua qüididade e natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A alma se conhece a si mesma por si mesma, porque,
afinal, chega ao conhecimento de si mesma, embora por ato seu. Pois, é ela mesma que é conhecida,
porque se ama a si mesma, como no mesmo passo citado se acrescenta. Uma coisa, porém, pode ser
considerada como conhecida por si mesma, de dois modos: porque lhe adquirimos o conhecimento sem
ser pelo intermédio de nenhuma outra e, assim, é que se consideram os primeiros princípios conhecidos
por si mesmos; ou porque não é cognoscível por acidente, como a cor é visível por si e a substância, por
acidente.

RESPOSTA À SEGUNDA. ― A essência do anjo está, como ato, no gênero dos inteligíveis; e portanto, se
comporta como intelecto e como causa inteligida. Por onde, o anjo apreende a sua essência, por si
mesmo. Não porém o intelecto humano, que, ou é absolutamente potencial, em relação aos inteligíveis,
como intelecto possível; ou é o ato dos inteligíveis abstratos dos fantasmas, como intelecto agente.

RESPOSTA À TERCEIRA. ― O passo citado do Filósofo é, universalmente, verdadeiro de todo intelecto.
Pois, assim como o sentido em ato é o sensível em ato, por causa da semelhança do sensível, que é a
forma do sentido em ato; assim o intelecto em ato é a coisa inteligida em ato, por causa da semelhança
da coisa inteligida que é a forma do intelecto em ato. Por onde, o intelecto humano, atualizado pela
espécie da coisa inteligida, é inteligido pela mesma espécie, como pela sua forma. Pois, dizer que, nos
seres que não têm matéria, o intelecto é idêntico ao inteligido, é o mesmo que dizer que, nas coisas
inteligidas em ato, o intelecto é idêntico ao que é inteligido. Porquanto, o que é inteligido em ato não
tem matéria. Mas a diferença está em que as essências de certos seres não têm matéria; assim, as
substâncias separadas, a que chamamos anjos, das quais cada uma tanto é inteligida como inteligente.
Há porém certas coisas das quais as essências não são sem matéria, mas só as semelhanças abstratas
delas. Por onde diz o Comentador, que a proposição induzida só é verdadeira das substâncias separadas;
verifica-se de certo modo, nelas, o que não se verifica em outros seres, como já se disse.

## Art. 2 — Se o nosso intelecto conhece os hábitos da alma pela essência deles.
(III Sent., dist. XXIII, q. 1, a. 2; De Verit., q. 10, a. 9; Quold. VIII, q. 2, a. 2).
O segundo discute-se assim. ― Parece que o nosso intelecto conhece os hábitos da alma pela essência
deles.

1. ― Pois, diz Agostinho, A fé não se manifesta no coração em que ela está, como se manifesta a alma
de um homem, pelos movimentos do corpo; mas é possuída com ciência certíssima e proclamada pela
consciência. E o mesmo se dá com os outros hábitos da alma. Logo, os hábitos da alma não são
conhecidos pelos atos, mas por si mesmos.

2. Demais. ― As coisas materiais exteriores à alma são conhecidas pelas semelhanças delas, que nela
estão presencialmente; e por isso se diz que são conhecidas pelas suas semelhanças. Ora, os hábitos da
alma estão nela, presencialmente, pela sua essência. Logo, são conhecidos pela sua essência.

3. Demais. ― O que faz com que uma coisa seja o que é, tem, primariamente, as qualidades desta. Ora,
as coisas externas são conhecidas da alma pelos hábitos e espécies inteligíveis. Logo, estes são, em si
mesmos, mais conhecidos da alma.
Mas, em contrário. ― Os hábitos são os princípios, tanto dos atos como das potências. Mas, como já
ficou dito,os atos e as operações são, pela razão, anteriores às potências. Logo, pela mesma razão, são
anteriores aos hábitos. E assim, tanto os hábitos como as potências são conhecidos pelos atos.

SOLUÇÃO. ― O hábito, de certo modo, é o meio entre a potência pura e o ato puro. Pois, como já se
disse (a. 1), só o atual é conhecido. Donde, na medida em que o hábito é deficiente, quanto ao ato
perfeito, nessa mesma o é quanto a ser cognoscível por si mesmo. Mas é necessário que seja conhecido
pelo seu ato, ou porque alguém percebe que tem um hábito, percebendo que produz um ato próprio
desse hábito; ou porque inquire a natureza e a essência do hábito, pela consideração do ato. Ora,
aquele modo de conhecer o hábito dá-se pela presença mesma dele, pois, é por esta causa do ato, pelo
qual é imediatamente percebido. Ao passo que este dá-se pela perquirição atenta, como antes já se
disse, a respeito da alma (a. 1).

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Embora a fé não seja conhecida pelos movimentos
exteriores do corpo, é, todavia, percebida, por aquele em quem existe, também pelo ato interior do
coração. Pois, ninguém tem consciência de ter fé, senão porque tem a percepção de que crê.

RESPOSTA À SEGUNDA. ― Os hábitos estão presentes ao nosso intelecto, não como objetos dele,
porque o objeto do nosso intelecto, no estado da vida presente, é a natureza da coisa material, como
antes já se disse (q. 84, a. 7); mas estão presentes ao intelecto, como o meio pelo qual o intelecto
intelige.

RESPOSTA À TERCEIRA. ― O dito ― o que jaz uma coisa ser o que é, tem, primariamente as qualidades
desta, é verdadeiro quando entendido de coisas pertencentes a uma mesma ordem, como no mesmo
gênero de causa; assim, quando se diz que a saúde é desejável por causa da vida, resulta que esta é
ainda mais desejável. Não é, porém, verdadeiro, entendido de coisas de ordens diversas; assim, se se
disser que a saúde é desejável por causa do remédio, daí não se segue que este seja ainda mais
desejável, porque a saúde pertence à ordem dos fins, ao passo que o remédio, à das causas eficientes.
Assim, pois, de duas coisas pertencentes, em si, à ordem dos objetos do conhecimento, mais conhecida
será a pela qual a outra é conhecida; como os princípios, mais que as conclusões. Ora, o hábito, como
tal, não pertence à ordem dos objetos; nem é o objeto conhecido pelo qual certas coisas sejam
conhecida, mas sim, a disposição ou forma pela qual o conhecente conhece. E, portanto, a objeção não
colhe.

## Art. 3 — Se o nosso intelecto conhece o ato próprio.
(III Sent., dist. XXIII, q. 1, a. 2, ad 3; II Cont. Gent., cap. LXXV; De Verit., q. 10, a. 9; II De Anima, lect VI).
O terceiro discute-se assim. ― Parece que o nosso intelecto não conhece o ato próprio.

1. ― Pois, é propriamente conhecido o que é objeto da virtude cognoscitiva. Ora, o ato difere do objeto.
Logo, o intelecto não conhece o ato próprio.

2. Demais. ― Tudo o que é conhecido o é por algum ato. Ora, se o intelecto conhece o ato próprio, por
algum ato o conhece; e, de novo, esse ato, por outro. Donde, há-se de proceder até o infinito, o que é
impossível.

3. Demais. ― O sentido está para o seu ato, como o intelecto para o seu. Ora, o sentido próprio não
sente o seu ato, pois isso pertence ao sentido comum, como já se disse. Logo, nem o intelecto intelige o
seu ato.
Mas, em contrário, diz Agostinho: Intelijo-me como inteligente.

SOLUÇÃO. ― Como já ficou dito (a. 1, 2), só se conhece aquilo que é atual. Ora, a perfeição última do
intelecto é a sua operação. Esta operação, porém, não é ao modo da ação tendente para uma coisa
exterior, como p. ex., a edificação é a perfeição da coisa edificada; mas permanece no operante, como
perfeição e ato deste, segundo já se disse. Por onde, isto é que primeiro é inteligido, do intelecto, a
saber, o seu próprio inteligir. ― Mas, nesta intelecção, os diversos intelectos se comportam
diversamente. ― Assim, há um intelecto, o divino, que é o seu próprio inteligir. Por onde, Deus,
inteligindo-se como inteligente, intelige a sua essência, pois esta é o seu inteligir. ― Há, porém, outro
intelecto, o angélico, que não é o inteligir próprio, como já se disse (q. 76, a. 1); todavia, o primeiro
objeto do inteligir do anjo é a própria essência dele. Por onde, embora no anjo se distinga, pela razão, o
inteligir-se a si próprio, do inteligir a sua essência, contudo, ele intelige uma e outra coisa por um
mesmo ato simultâneo. Porque, inteligir a sua essência é a perfeição própria desta; mas, por um mesmo
ato simultâneo é inteligida a coisa, com a sua perfeição. ― Há, por fim, outro intelecto, o humano, que
nem é o inteligir próprio, nem do seu inteligir é o objeto primeiro a essência própria, mas, algo de
extrínseco, que é a natureza material da coisa. Por onde, o que é primariamente conhecido pelo
intelecto humano é um objeto tal; secundariamente, é conhecido o ato mesmo pelo qual é conhecido o
objeto; e, pelo ato, é conhecido o intelecto, em si, cuja perfeição é o inteligir. E, por isso, o Filósofo diz,
que os objetos são conhecidos antes dos atos; e os atos, antes das potências.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O objeto do intelecto é algo de comum, a saber, o ser e
a verdade, no que está também compreendido o ato mesmo de inteligir. Por onde, o intelecto pode
conhecer o ato próprio, mas não primariamente. Porque o primeiro objeto do nosso intelecto, no
estado da vida presente, não é qualquer ser e qualquer verdade, mas o ser e a verdade considerados
nas coisas materiais, como já se disse (q. 84, a. 7); e por eles é que o intelecto chega ao conhecimento
de todas as outras coisas.

RESPOSTA À SEGUNDA. ― O inteligir humano, em si, não é o ato e a perfeição da natureza inteligida, de
modo que possa, por um só ato, ser inteligida a natureza da coisa material e o inteligir mesmo, assim
como, por um só ato, é inteligida a coisa com a sua perfeição. Por onde, um é o ato pelo qual o intelecto
intelige uma pedra e outro, o pelo qual se intelige como inteligindo a pedra, e assim por diante. Nem há
inconveniente em que o intelecto seja potencialmente infinito, como antes já se disse (q. 86, a. 2).

RESPOSTA À TERCEIRA. ― O sentido próprio sente por meio da imutação do órgão material pelo
sensível exterior. Ora, não é possível que algo de material se imute a si mesmo; mas uma coisa é
imutada por outra. Por onde, o ato do sentido próprio é percebido pelo sentido comum. Ora, como o
nosso intelecto não intelige por imutação material do órgão, não há símile.

## Art. 4 — Se o intelecto intelige o ato da vontade.
(Supra, q. 82, a. 4, ad 1; III Sent., dist. XXIII, q. 1, a. 2, ad 3).
O quarto discute-se assim. ― Parece que o intelecto não intelige o ato da vontade.

1. ― Pois, só é conhecido do intelecto aquilo que, de certo modo, lhe está presente. Ora, o ato da
vontade não está presente ao intelecto, pois, são potências diversas. Logo, o ato da vontade não é
conhecido pelo intelecto.

2. Demais. ― O ato se específica pelo seu objeto. Ora, o objeto da vontade difere do objeto do intelecto.
Logo, o ato da vontade tem espécie diversa do objeto do intelecto. Logo, não é conhecido por este.

3. Demais. ― Agostinho diz, que os afetos da alma não são conhecidos, nem pelas imagens, como os
corpos, nem pela presença, como as artes, mas por certas noções. Ora, não pode haver na alma noções
de outras coisas, senão da essência das coisas conhecidas ou das semelhanças destas. Logo, é impossível
que o intelecto conheça os afetos da alma, que são atos da vontade.
Mas, em contrário, diz Agostinho: Intelijo-me como querendo.

SOLUÇÃO. ― Como já se disse antes (q. 59, a. 1), o ato da vontade não é senão uma certa inclinação
conseqüente à forma inteligida; assim como o apetite natural é a inclinação conseqüente à forma
natural. Ora, a inclinação está, a seu modo, na coisa à qual pertença. Por onde, a inclinação natural está
naturalmente na coisa natural; a do apetite sensível está sensivelmente, no ser que sente; e
semelhantemente, a inteligível, que é ato da vontade, está inteligívelmente, no ser que intelige, como
no primeiro princípio e no sujeito próprio. Por isso, o Filósofo usa da locução: a vontade está na razão.
Ora, é conseqüente que, o que está, inteligívelmente, num ser inteligente, seja por este inteligido. Por
onde, o ato da vontade é inteligido pelo intelecto, enquanto alguém tem consciência de querer e
enquanto conhece a natureza deste ato e, por conseqüência, a natureza do princípio do mesmo, que é o
hábito ou a potência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção procederia, se a vontade e o intelecto, sendo
potências diversas, também diferissem; então, o que estivesse na vontade estaria ausente do intelecto.
Ora, como ambas se radicam numa mesma substância da alma, e uma é, de certo modo, o princípio da
outra, resulta conseqüentemente, que o que está na vontade está também, de certo modo, no
intelecto.

RESPOSTA À SEGUNDA. ― O bem e o verdadeiro, objetos da vontade e do intelecto, diferem, certo,
pela razão; contudo, um se contém no outro, como antes já se disse (q. 82, a. 4, ad 1); pois, o verdadeiro
é um certo bem e o bem, um certo verdadeiro. Por onde, o que é da vontade cai sob a alçada do
intelecto; e o que é do intelecto pode cair sob a da vontade.

RESPOSTA À TERCEIRA. ― Os afetos da alma não estão no intelecto, nem pela semelhança, somente,
como os corpos, nem pela presença, como no sujeito próprio, conforme se dá com as artes; mas como o
principiado está no princípio, no qual é ela a noção do principiado. E por isso Agostinho diz que os
objetos da alma estão na memória, por meio de certas noções.