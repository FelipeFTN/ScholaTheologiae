# Questão 57: Do conhecimento angélico em relação às coisas materiais.
Em seguida se trata das coisas materiais conhecidas dos anjos. E, sobre este assunto, cinco artigos se
discutem:

## Art. 1 — Se os anjos conhecem as coisas materiais.
(II Cont. Gent., cap. XCIX; De Verit., q. 8, a. 8; q. 10, a. 4)
O primeiro discute-se assim. — Parece que os anjos não conhecem as coisas materiais.

1. — Pois, o objeto inteligido é a perfeição de quem intelige. Ora, as coisas materiais não podem ser a
perfeição dos anjos, por lhes serem inferiores. Logo, os anjos não as conhecem.

2. Demais. — A visão intelectual apreende as coisas que estão na alma pela essência delas, como diz a
Glosa. Ora, os seres materiais não podem estar na alma do homem ou na inteligência do anjo, pelas
essências delas. Logo, não podem ser conhecidos pela visão intelectual, mas só pela imaginaria, que
apreende as semelhanças dos corpos, e pela sensível, que apreende os próprios corpos. Como, porém,
os anjos não têm visão imaginaria, nem a sensível, mas só a intelectual, não podem conhecer as coisas
materiais.

3. Demais. — As coisas materiais não são inteligíveis em ato, mas são cognoscíveis pela apreensão do
sentido e da imaginação, que não existem nos anjos. Logo, estes não as conhecem.
Mas, em contrário, o que pode a virtude inferior pode também a superior. Ora, se o intelecto humano,
que é, na ordem da natureza, inferior ao angélico, pode conhecer as coisas materiais, como muito maior
razão o pode este último.

SOLUÇÃO. — A ordem dos seres e tal, que os superiores são mais perfeitos que os inferiores e, o que
estes contém de deficiente, parcial e multiplicente, aqueles contêm eminentemente e por uma certa
totalidade e simplicidade. E, portanto, como no sumo vértice das coisas, todas preexistem
sobresubstancialmente, em Deus, no seu ser simples, como diz Dionísio. Ora, dentre todas as outras
criaturas, os anjos, sendo as mais próximas e semelhantes a Deus, mais e mais perfeitamente participam
da bondade divina, como diz Dionísio. Portanto, nos anjos, todas as coisas materiais preexistem, mais
simples e imaterialmente do que nelas próprias; porém, mais multíplice e imperfeitamente do que em
Deus. Mas, como o ser está noutro ao está ao modo desse outro; e sendo os anjos, por naturezas
inteligentes; por isso, como Deus, por essência, conhece as coisas materiais, eles as conhecem pelas
possuírem nas espécies inteligíveis delas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O objeto inteligido é a perfeição de quem intelige pela
espécie inteligível existente. E, assim, as espécies inteligíveis existentes no intelecto angélico são deste
as perfeições e os atos.

RESPOSTA À SEGUNDA. — O sentido apreende as essências das coisas, mas somente os acidentes
exteriores. Do mesmo modo a imaginação, que só apreende as semelhanças dos corpos. Só o intelecto
apreende as essências das coisas; e por isso, diz Aristóteles, que o objetivo dele é a qüididade da coisa,
em relação à qual o intelecto não erra, assim como também não erra o sentido em relação ao sensível
próprio. Assim, pois, as essências das coisas materiais estão na inteligência do homem ou do anjo, como
o inteligido está em quem intelige e não pela existência real delas. Há, porém, certas coisas que estão na
inteligência ou na alma, por ambos os modos de ser; e, de ambos, há visão intelectual.

RESPOSTA À TERCEIRA. — Se o anjo recebesse das próprias coisas materiais o conhecimento que delas
tem, necessariamente abstraindo-as, as tornaria inteligíveis em ato, ora, não é delas que ele tira o
conhecimento; mas as conhece pela espécies inteligíveis, em ato, das coisas que são conaturais, assim
como a nossa inteligência conhece pelas espécies que torna inteligíveis por abstração.

## Art. 2 — Se o anjo conhece o singular.
(Infra., q. 89, a. 4; II Sent., dist. III, part. II, q. 2, a. 3; II Cont. Gent., cap. C; De Verit., q. 8, a. 11; q. 10, a. 5;
Qu. De Anima, a. 20; Quodl. VII, a. 1, a. 3; Opusc. XV, De Angelis, cap. XII, XV.)
O segundo discute-se assim. — Parece que o anjo não conhece o singular.

1. — Pois, diz o Filósofo que o sentido conhece o singular porém, a razão (ou o intelecto), o
universal. Ora, os anjos têm unicamente o intelecto, como faculdade cognoscitiva, segundo já se viu.
Logo,

2. Demais. — Todo conhecimento se realiza por certa assimilação do conhecente com o conhecido. Ora,
como o anjo é imaterial, conforme se viu, e a matéria é o princípio da singularidade, não pode haver
nenhuma assimilação do anjo com o singular como tal, logo, aquele não pode conhecer este.

3. Demais. — Só por espécies singulares ou por espécies universais é que o anjo poderia conhecer o
singular. Ora, não pelas primeiras, porque, então, ele deveria ter infinitas espécies. Nem pelas ultimas,
pois, o universal não é princípio suficiente do conhecimento do singular como tal, porque todo universal
se conhece o singular só em potência. Logo, o anjo não conhece o singular.
Mas, em contrario. Ninguém pode guardar o que não conhece. Ora, os anjos guardam os homens,
conforme a Escritura (Sl 90, 11): Mandou aos seus anjos acerca de ti, que te guardem em todos os teus
caminhos. Logo, o anjo não conhece o singular.

SOLUÇÃO. — Alguns negaram totalmente aos anjos o conhecimento do singular. — Mas isto, em
primeiro lugar, derroga a fé católica dizendo que as coisas inferiores deste mundo são administradas
pelos anjos, como diz a Escritura (Heb 1, 14): Todos os espíritos são administradores. Ora, se não
conhecessem o singular nenhuma providência poderiam tomar em respeito do que se faz neste mundo,
porque os atos têm por objeto o singular. O que vai contra a Escritura (Ecle 5, 5): Não digas diante do
anjo: Não há Providência. E, segundo lugar, derroga o ensinamento da filosofia dizendo que os anjos são
os motores dos orbes celestes, pela inteligência e pela vontade.
E, por isso, outros ensinaram que o anjo tem, certamente, conhecimento do singular, mas por causas
universais, às quais se reduzem todos os efeitos particulares; como se um astrólogo julgasse certo
eclipse futuro pelas disposições dos movimentos celestes. — Mas esta opinião não escapa às
dificuldades apontadas, porque conhecer de tal modo o singular não é conhecê-lo como tal, isto é, como
existente num lugar e momento dados. Assim, o astrólogo, conhecendo o eclipse futuro pelo cômputo
dos movimentos celestes, conhece-o universalmente e não como realizado num lugar e momento
dados, salvo se o conhecer pelos sentidos. Ora, a administração, a providência e o movimento visam o
singular, enquanto relativos de um determinado lugar e tempo.
Portanto deve-se responder diferentemente, que, assim como o homem conhece, por diversas
potências cognoscitivas, os gêneros de todas as coisas — pelo intelecto o universal e o imaterial; pelo
sentido, o singular e o corpóreo; assim o anjo, por uma só potência intelectiva tem ambos esses
conhecimentos. Pois a ordem das coisa postula que, quanto mais for um ser superior, tanto mais íntima
tenha a sua potência, que mais coisas abranja. Assim, como no homem mesmo se vê, o sentido comum,
superior ao próprio, embora seja uma potência única, conhece tudo o que conhecem os cinco sentidos
exteriores, e certas outras coisas, como a diferença entre o branco e o doce, que nenhum dos sentidos
exteriores conhece; e o mesmo se dá em outros casos. Donde, sendo o anjo pela ordem natural superior
ao homem, inconveniente é dizer-se que o homem, por qualquer das suas potências, conheça alguma
coisa, que o anjo, pela sua única potência cognoscitiva, o intelecto, não conheça. Por isso, Aristóteles
não admite que uma disputa conhecida de nós Deus a ignore.
Quanto ao modo, porém, pelo qual o intelecto angélico conhece o singular, podemos explica-lo assim.
De Deus efluem as criaturas para subsistirem em as suas naturezas próprias, de modo a também serem
objeto do conhecimento angélico. Ora, é manifesto que, de Deus, eflui para as coisas não só o
pertencente à natureza universal, mas também o que constitui o princípio de individuação; pois, Deus é
a causa da substância total da coisa, material e formalmente. E, como causa, do mesmo modo conhece,
porque a ciência divina é causa das coisas, como já se demonstrou. Portanto, assim como Deis, pela sua
essência. Pela qual causa todas as coisas não só é de todas a semelhança; mas também conhece a todas,
tanto pelas naturezas universais como pela singularidade delas; assim também os anjos, pelas espécies
neles infundidas por Deus, conhecem a coisas, não só quanto à natureza universal, mas também quanto
à singularidade delas, por serem elas certas representações multiplicadas da única e simples essência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo se refere à nossa inteligência, que só por
abstração intelige as coisas; e, por essa mesma abstração das condições materiais, o abstraído torna-se
universal. Ora, tal modo de inteligir não convém aos anjos, como já se disse; e, logo, a razão não é a
mesma.

RESPOSTA À SEGUNDA. — Os anjos, por natureza, não se assimilam às coisas materiais, como uma coisa
assimila a outra por conveniência genérica, especifica ou acidental; mas como o superior se assimila ao
inferior; assim, o sol com o fogo. E, por este mesmo modo, Em Deus há a semelhança formal e material
de todas as coisas, por preexistir, nele, como na causa, tudo o que se encontra nas coisas. Assim, pela
mesma razão, as espécies da inteligência angélica, que são certas semelhanças das coisas, não só
formal, mas também materialmente.

RESPOSTA À TERCEIRA. — Os anjos conhecem o singular por formas universais, que, todavia, são
semelhanças das coisas, tanto quanto aos princípios universais como aos princípios de individuação. E,
como podem conhecer muitas coisas, pela mesma espécie, já antes ficou dito.

## Art. 3 — Se os anjos conhecem o futuro.
(Infra, q. 86, a. 4; IIa Iiae, q. 95, a. 1; I Sent., dist. XXXVIII, a. 5; II, dist. III, q. 2, a. 3, ad 4; dist. VII, q. 2, a.
2; III Cont. Gent., cap. CLIV; De Verit., q. 8, art. 12; De Malo, q. 16, a. 7; De Spirit Creat., a. 5, ad 7; Qu. De
Anima, a. 20, ad 4; Quodl. VII, q. 3, a. 1, ad 1; Compend. Theol., cap. CXXXIV; In Isaiam, cap. III).
O terceiro discute-se assim. — Parece que os anjos conhecem o futuro.

1. — Pois, os anjos são superiores aos homens, pelo conhecimento. Ora, alguns homens conhecem o
futuro. Logo, com maior razão, os anjos.

2. Demais. — O presente e o futuro são diferenças de tempo. Ora, o intelecto do anjo está acima do
tempo; pois, a inteligência se equipara à eternidade, i. é., ao evo, como diz o livro Das causas. Logo, para
o intelecto angélico não difere o pretérito do futuro, os quais ele conhece indiferentemente.

3. Demais. — O anjo não conhece por espécies oriundas das coisas, mas por espécies inatas universais.
Ora, estas se referem igualmente ao pretérito, ao presente e ao futuro. Logo, resulta que os anjos
indiferentemente os conhecem.

4. Demais. — Diz-se que alguma coisa está distante tanto temporal como localmente. Ora, os anjos
conhecem as coisas localmente distantes. Logo, também as distantes no futuro.
Mas, em contrário. O que é próprio só à divindade não convém aos anjos. Ora, é-lhe sinal próprio
conhecer o futuro, conforme a Escritura (Is 41, 23): Anunciar as coisas que hão de vir para o futuro, é
ficaremos sabendo que vós sois deuses. Logo, os anjos não conhecem o futuro.

SOLUÇÃO. — De dois modos se pode conhecer o futuro. Na sua causa; e, então o futuro,
necessariamente oriundo das suas causas, pode ser conhecido pela ciência certa, como, p. ex., que o sol
nascerá amanha. Porém, as coisas oriundas na maioria dos casos das suas causas, são conhecidas, não
certa mas conjecturalmente; assim, o médico conhece de antemão a saúde do enfermo. Este modo de
conhecer o futuro o têm os anjos, e, tanto mais que nós, quanto mais universal e perfeitamente
conhecem a causas das coisas; assim como os médicos, que mais agudamente vêm as causas, melhor
prognosticam do futuro estado da doença. As coisas, porém, provenientes das suas causas, mas na
minoria dos casos, são de todo desconhecidas, como o que é casual e fortuito.
Por outro lado, o futuro é conhecido em si mesmo. E, assim, só Deis conhece as coisas futuras, não só as
provenientes das suas causas necessariamente, ou na maioria dos casos, como também as casuais e
fortuitas, pois Deus vê tudo na sua eternidade. Pois esta, sendo simples, está presente a todo o tempo e
o encerra em si. Por isso, Deus, de um intuito, percorre todas as coisas feitas na totalidade do tempo,
como se foram presentes e as vê todas como em si mesmas são, conforme já antes se disse, quando se
tratou da ciência de Deus. Ao passo que o intelecto angélico, como qualquer outro intelecto criado, é
deficiente, em comparação com a eternidade divina. Por onde, o futuro, na sua substância, não pode ser
conhecido por nenhum intelecto criado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os homens não conhecem o futuro, senão pelas suas
causas, ou pela revelação de Deus. E, deste modo, os anjos conhecem muito mais sutilmente as coisas
futuras.

RESPOSTA À SEGUNDA. — Embora o intelecto angélico esteja fora do tempo que mede os movimentos
corpóreos, há todavia, nesse intelecto, o tempo segundo a sucessão das concepções inteligíveis, pois
conforme diz Agostinho, Deus move a criatura espiritual no tempo. E assim, havendo sucessão no
intelecto angélico, não lhe são presentes todas as coisas feitas na totalidade do tempo.

RESPOSTA À TERCEIRA. — Embora, em si mesmas, a espécies existentes no intelecto angélico
igualmente se refiram ao presente, ao pretérito e ao futuro, todavia, estes tempos não se referem
igualmente às espécies. Pois, as coisa presentes são de natureza a se assimilarem às espécies existentes
na mente do anjo e, assim, por estas, podem ser conhecidas. Mas, as coisas futuras ainda não têm tal
natureza e, por isso, não podem ser conhecidas por meio de tais espécies.

RESPOSTA À QUARTA. — As distâncias locais já estão em a natureza das coisas e participam de alguma
espécie cuja semelhança existe no anjo; p que não é verdade das coisas futuras, como já e disse. Logo, o
símile não é o mesmo.

## Art. 4 — Se os anjos conhecem as cogitações dos corações.
(De Verit., q. 8, a. 13; De Malo, a. 16, a. 8; Opusc. X, a. 38; Opusc. XII, a. 36; I Cor., cap. II, lect. II)
O quarto discute-se assim. — Parece que os anjos conhecem as cogitações dos corações.

1. — Pois, Gregório diz, a propósito da passagem da Escritura (Jó 28) — Não se lhe igualará o ouro, ou o
cristal – que, então, i. é., na beatitude dos ressurgidos, um será conhecido de outro como a si
mesmo; e,como se trata do intelecto de cada um, a consciência é simultaneamente penetrada. Ora, os
ressurgidos serão semelhantes aos anjos, como diz a Escritura (Mt 22, 30). Logo, um anjo pode ver o que
está na consciência do outro.

2. Demais. — As figuras estão para os corpos como as espécies inteligíveis para o intelecto. Ora, o corpo,
vista lhe fica a figura. Logo, vista a substância intelectual, vista foca a espécie inteligível que nela está.
Portanto, como um anjo vê outro, e mesmo a alma, resulta que pode lhes conhecer o pensamento.

3. Demais. — As coisas que estão em o nosso intelecto são mais semelhantes ao anjo, que as existentes
na fantasia; pois aquelas são inteligidas em ato, estas, porém, só em potência., ora, as existentes na
fantasia podem ser conhecidas pelo anjo, como seres corporais, pois, a fantasia é uma virtude do corpo.
Logo, resulta que o anjo pode conhecer as cogitações do intelecto.
Mas, em contrário, o que é próprio de Deus não convém aos anjos. Ora, é próprio de Deus conhecer as
cogitações dos corações, segundo a Escritura (Jr 17): Depravado é o coração do homem, e impenetrável:
quem o conhecerá? Eu sou o Senhor que esquadrinha os corações. Logo, os anjos não conhecem os
segredos dos corações.

SOLUÇÃO. — A cogitação do coração pode ser conhecida de duplo modo. — De um modo, pelo seu
efeito. E assim pode ser conhecida, não só pelo anjo, mas também pelo homem; e tanto mais sutilmente
quanto tal efeito for mais oculto. Pois, às vezes, uma cogitação é conhecida, não só pelo ato exterior,
mas também pela imutação do vulto; assim como também os médicos podem conhecer certos afetos da
alma, pelo pulso. E tanto mais os anjos, ou os demônios, quanto mais sutilmente compreendem tais
imutações corporais ocultas. Por isso Agostinho diz que, por vezes, compreendem mui facilmente as
disposições humanas, não só as exteriorizadas pela voz, mas ainda as concebidas no pensamento, por
serem sinais expressos no corpo pela alma; embora também diga não se possa afirmar como isso se
realiza.
De outro modo, as cogitações podem ser conhecidas, enquanto existentes no intelecto, e os afetos,
enquanto na vontade. E, assim, só Deus pode conhecer as cogitações dos corações e os afetos das
vontades. Sendo a razão disto que a vontade da criatura racional só de Deus depende e só ele pode agir
sobre Lea, da qual é o objeto principal e o último fim; o que a seguir se demonstrará. Portanto, as coisas
existentes na vontade ou que só dela dependem apenas de Deus são conhecidas. Ora, é manifesto que
só da vontade depende que alguém considere alguma coisa atualmente; pois, quem tem o hábito da
ciência, ou espécies inteligíveis em si existentes, deles usa quando quiser. E por isso, diz a Escritura (1
Cor 2, 11): Ninguém conhece as coisas que são do homem, senão o espírito do homem, que nele mesmo
reside.

DONDE A RESPOSTA À PRIMEIRA PERGUNTA. — Atualmente o pensamento de um homem não é
conhecido de outro, por duplo impedimento: pela crassidão do corpo, ou pela vontade que esconde os
seus segredos. Ora, o primeiro obstáculo desaparecerá na ressurreição e não existe nos anjos. Mas o
segundo permanecerá depois dela e existe atualmente nos anjos. E contudo, a claridade do corpo
representará a qualidade da inteligência, quanto à quantidade da graça e da glória. Assim que um
poderá ver a inteligência do outro.

RESPOSTA À SEGUNDA. — Embora um anjo veja as espécies inteligíveis de outro, por ser proporcionado
à nobreza das substâncias o modo das espécies inteligíveis, na sua maior e menor universalidade;
todavia não se segue que um conheça, como outro, pensando atualmente, uma dessas espécies
inteligíveis.

RESPOSTA À TERCEIRA. — O apetite dos brutos não é senhor do seu ato, mas segue a impressão de
outra causa, corporal ou espiritual. Como, pois, os anjos conhecem as coisas corpóreas e as disposições
delas, pode, por aí, conhecer o que está no apetite e na apreensão fantástica dos brutos e também dos
homens, enquanto, nestes, o apetite sensitivo se atualiza por alguma impressão corpórea, como sempre
acontece com os brutos. Contudo não resulta daí necessariamente, que os anjos conheçam o
movimento do apetite sensitivo e a apreensão da fantasia no homem, enquanto movidos pela vontade e
pela razão; pois, a parte inferior da alma participa, de certo modo, da razão, como obediente à que
impera, segundo diz Aristóteles. E, por isso, não se segue que o anjo, conhecendo o que está no apetite
sensitivo ou na fantasia do homem, conheça o que está na cogitação ou na vontade; porque o intelecto
e a vontade não dependem do apetite sensitivo e da fantasia, antes, pode usar destes de diversos
modos.

## Art. 5 — Se os anjos conhecem os mistérios da graça.
(IV Sent., dist, X, a. 4, qa. 4; Ephes., cap. III, lect. III).
O quinto discute-se assim. — Parece que os anjos conhecem os mistérios da graça.

1. — Pois, dentre todos os mistérios, o mais excelente é o da Encarnação de Cristo. Ora, os anjos o
conhecem desde o princípio; pois Agostinho diz, que este mistério estava escondido em Deus, desde os
séculos, de modo que fosse conhecido dos principies e potestades celestes. E a Escritura diz (1 Tm 3,
16), que foi visto pelos anjos aquele grande sacramento de piedade. Logo, os anjos conhecem os
mistérios da graça

2. Demais. — As razões de todos os mistérios da graça estão contidas na divina sabedoria. Ora, os anjos
vêm a sabedoria mesma de Deus, que lhe é a essência. Logo, os anjos conhecem os mistérios da graça.

3. Demais. — Os profetas são instruídos pelos anjos, como se vê em Dionísio. Ora, os profetas
conheceram os mistérios da graça, conforme diz a Escritura (Am 3, 7): Porque o Senhor Deus não faz
nada sem ter revelado antes o seu segredo aos profetas, seus servos. Logo, os anjos conhecem os
mistérios da graça.
Mas, em contrário, ninguém aprende o que conhece. Ora, os anjos, mesmo os mais elevados,
interrogam sobre os mistérios divinos da graça e aprendem; pois, como se disse, a Sagrada Escritura
introduz certas essências celestes fazendo perguntas ao próprio Jesus e aprendendo a ciência da sua
divina operação por nós, e Jesus ensinando-as sem intermediário. E isto mesmo se vê na Escritura (Is 63,
1), onde aos anjos que perguntam: Quem é este que vem de Edom? Jesus responde: Eu, que falo a
justiça.

SOLUÇÂO. — Os anjos têm duplo modo de conhecer. – Um, natural, pelo qual conhecem as coisas, quer
pela essência deles, quer por espécies inatas. E, por este modo, não podem conhecer is mistérios da
graça, que dependem da pura vontade de Deus. Pois, se um anjo não pode conhecer os pensamentos de
outro, dependentes da vontade deste, muito menos poderá conhecer o que só da vontade de Deus
depende: e assim argumenta a Escritura (1 Cor 2, 11): Ninguém conhece as coisas que são do homem,
senão o espírito do homem, que nele mesmo reside; assim também as coisas que são de Deus ninguém
as conhece, senão o Espírito de Deus.
Há, porém, outro modo de conhecimento angélico, que os torna felizes, pelo qual vêm o Verbo e neste
as coisas. E, por este modo, conhecem os mistérios da graça, não todos, por certo, nem todos os anjos
igualmente, mas na medida em que Deus quiser lhes revelar, segundo a Escritura (1 Cor 2, 10): A nós,
porém, Deus revelou-o por meio de seu Espírito. E isto de maneira que os anjos superiores,
contemplando mais profundamente a divina sabedoria, conhecem, na visão de Deus, mais e mais altos
mistérios e os manifestam aos inferiores, iluminando-os. E, desses mistérios, alguns eles os conheceram
desde o princípio da sua criação; outros, porém, mais tarde lhes foram revelados, segundo lhes
convinham aos deveres.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De duplo modo podemos nos referir ao mistério da
Encarnação de Cristo. Em geral, e assim a todos os anjos foi revelado desde o princípio da beatitude
deles. E a razão é que todos os ofícios deles dependem deste princípio geral, como diz a Escritura (Heb
1,14): Em verdade todos os espíritos são uns administradores, enviados para exercer o seu ministério a
favor daqueles que hão de receber a herança da salvação; o que se realiza pelo mistério da Encarnação.
Por isso é necessário que esse mistério tenha sido revelado a todos comumente, desde o princípio. De
outro modo, podemos considerar o mistério da Encarnação quanto à condições especiais. E, assim, nem
a todos os anjos foram todas reveladas, desde o princípio; antes, certas só mais tarde foram conhecidas
dos anjos, mesmos superiores, como se vê pela citada autoridade de Dionísio.

RESPOSTA À SEGUNDA. — Embora os anjos bem-aventurados contemplem a divina sabedoria, todavia,
não a compreendendo, não conhecem necessariamente tudo o que ela encerra.

RESPOSTA À TERCEIRA. — Tudo o que os profetas conheceram sobre o mistério da graça, pela divina
revelação, mais excelentemente foi revelado aos anjos. E embora Deus tivesse revelado, em geral, aos
profetas, o que haveria de fazer para a salvação do gênero humano, contudo, nesta matéria, os
Apóstolos conheceram os profetas, conforme está na Escritura (Ef 3, 4): Por onde podeis, lendo-as,
conhecer a inteligência que tenho do mistério de Cristo, o qual em outras gerações não foi conhecido
dos filhos dos homens, assim como agora tem sido revelado aos seus santos Apóstolos. Mas ainda,
dentre os próprios profetas, os posteriores conheceram o que não conheceram os anteriores, segundo a
Escritura (118, 100):Mais que os anciãos entendi; e Gregório diz que na sucessão dos tempos acentuou-
se o aumento do conhecimento divino.