# Questão 10: Da eternidade de Deus.
Em seguida devemos tratar da eternidade. E nesta questão discutem-se seis artigos:

## Art. 1 — Se é boa a seguinte definição de eternidade: a posse total, simultânea e perfeita de uma vida interminável.
(I Sent., dist. VIII, q. 2, a. 1; De Causis, lect. II).
O primeiro discute-se assim. — Parece que não é boa a definição de eternidade, que dá Boécio: a
posse total, simultânea e perfeita de uma vida interminável.

1. — Pois, “interminável” é um conceito negativo. Ora, a negação é própria à noção de deficiência, que
não convém à eternidade. Logo, na definição desta não deve entrar a palavra interminável.

2. Demais. — A eternidade implica uma espécie de duração. Ora, esta é própria, mais do ser, que da
vida. Logo, a palavra vida não se devia incluir na noção de eternidade, mas, antes a de ser.

3. Demais. — Chama-se totalidade o que tem partes. Ora, isto não pode convir à eternidade, que é
simples. Logo, é mal aplicada na definição a palavra total.

4. Demais. — Nem vários dias, nem vários tempos podem existir simultaneamente. Ora, na eternidade
distinguem-se muitos dias e tempos, pois diz a Escritura (Mq 5, 2): Cuja geração é desde o princípio,
desde os dias da eternidade; e (Rm 16, 25): segundo a revelação do mistério encoberto desde tempos
eternos. Logo, a eternidade não é total e simultânea.

5. Demais. — “Todo” é idêntico a “perfeito”. Ora, se já se incluiu na definição a palavra total, é inútil
acrescentar perfeita.

6. Demais. — A posse não é própria da duração. Ora, a eternidade é uma duração. Logo, não é posse.

SOLUÇÃO. — Assim como devemos partir do simples para chegar ao conhecimento do composto, assim
devemos partir do tempo para chegar ao conhecimento da eternidade. Ora, o tempo não é senão o
número das partes do movimento, por anterioridade e posteridade. Pois, como em qualquer
movimento, a uma parte sucede outra, pela enumeração das diversas partes, anteriores e posteriores,
apreendemos o tempo, que não é senão o número do que é anterior e posterior, no movimento. Mas,
onde não há movimento, mas, sempre o mesmo modo de existir, não se pode descobrir anterioridade e
posteridade. Por onde, assim como a essência do tempo consiste na enumeração do que é anterior e
posterior no movimento, assim, a da eternidade, consiste na apreensão da uniformidade do que está
absolutamente fora do movimento.
Demais. Consideram-se medidas pelo tempo as coisas que nele têm princípio e fim, como diz
Aristóteles; e isto, porque tudo o que é movido inclui um princípio e um fim. Logo, o que é
absolutamente imutável, não tendo sucessão, também não pode ter princípio nem fim. — Assim, pois,
por duas características se conhece a eternidade: o que nela está é interminável, isto é, não tem
princípio nem fim, duas noções que implica o termo, e em segundo lugar, justamente por não ter
sucessão, a eternidade existe total e simultaneamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Costuma-se definir o que é simples, por negação; assim,
ponto é o que não tem parte; mas isto não quer dizer, que a negação seja a essência de tais seres, senão
que o nosso intelecto, apreendendo primeiro o composto, só pode chegar ao conhecimento do simples,
removendo a composição.

RESPOSTA À SEGUNDA. — O que é verdadeiramente eterno não só é ser, como também vivente; e a
vida se estende, de certo modo, até à operação, mas não ao ser. Ora, a extensão da duração parece que
deve ser considerada relativamente à operação, antes que relativamente ao ser; e, por isso, o tempo é o
número do movimento.

RESPOSTA À TERCEIRA. — Diz a definição, que a eternidade é total, não por ter partes, mas, porque
nada lhe falta.

RESPOSTA À QUARTA. — Assim como a Deus, embora incorpóreo, a Escritura aplica, metaforicamente,
nomes de coisas corpóreas, assim também à eternidade, que existe total e simultaneamente, aplica a
denominação própria do que é sucessivo no tempo.

RESPOSTA À QUINTA. — O tempo pode ser considerado, em si mesmo, como sucessivo, ou em um dos
seusmomentos, que é imperfeito. Ora, a definição diz — total e simultaneamente — para excluir o
tempo; e,perfeita, para excluir o momento temporal.

RESPOSTA À SEXTA. — O que é possuído o é firme e tranqüilamente; e, por isso, para designar a
imutabilidade e a indeficiência da eternidade a definição empregou a palavra posse.

## Art. 2 — Se Deus é eterno.
(I Sent., dist. XIX, q. 2, art. 1; I Cont. Gent., cap. XV; De Pot., q. 3, a. 17, ad 23; Compend Theol., cap. V,

VIII).
O segundo discute-se assim. — Parece que Deus não é eterno.

1. — Pois, nada do que lhe é feito lhe pode ser atribuído. Ora, a eternidade é feita, conforme a
expressão de Boécio: O momento que passa constitui o tempo; o que permanece, a eternidade; e
Agostinho : Deus é o autor da eternidade. Logo, Deus não é eterno.

2. Demais. — O anterior e o posterior à eternidade por ela não se mede. Ora, Deus é anterior, como diz
o livro De Causis; e posterior, conforme a Escritura (Ex 15, 18): O Senhor reinará eternamente e além da
eternidade. Logo, ser eterno não é próprio de Deus.

3. Demais. — A eternidade é uma espécie de medida. Ora, a Deus não convém ser medido. Logo, nem
ser eterno.

4. Demais. — A eternidade não tem presente, pretérito, nem futuro, porque existe total e
simultaneamente, como se disse. Ora, a Escritura aplica a Deus palavras que exprimem os tempos
presente, pretérito e futuro. Logo, Deus não é eterno.
Mas, em contrário, diz Atanásio: Eterno Padre, Eterno Filho, Eterno Espírito Santo. SOLUÇÃO. — A noção
da eternidade resulta da imutabilidade, como a de tempo resulta do movimento, conforme do sobredito
resulta. Ora, sendo Deus o ser imutável por excelência, convém-lhe, excelentemente, a eternidade. Nem
só é eterno, mas é a sua eternidade, ao passo que nenhuma coisa é a própria duração, porque não é o
próprio ser. Deus, porém, sendo o seu ser uniformemente e a sua própria essência, há de,
necessariamente, ser a sua eternidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Pela nossa apreensão é que se diz que o momento
permanenteconstitui a eternidade. Pois, assim, como a nossa apreensão do tempo tem a sua causa no
apreendermos o fluxo mesmo do momento, assim procede em nós a apreensão da eternidade, de
apreendermos o momento permanente. E a expressão de Agostinho — Deus é o autor da eternidade —
entende-se da eternidade participada. Pois, Deus comunica a sua eternidade a certos seres, do mesmo
modo por que comunica a sua imutabilidade.
E daqui se deduz clara aRESPOSTA À SEGUNDA OBJEÇÃO. — Pois, diz-se que Deus é anterior à
eternidade, enquanto participado pelas substâncias materiais; e, por isso, o mesmo livro diz, que
a inteligência se alça ao nível da eternidade. E na expressão do Êxodo: o Senhor reinará eternamente e
além da eternidade — eternamente é empregado no sentido de século, como se lê em outra versão.
Assim, pois, diz-se que reinará além da eternidade, porque dura mais que qualquer século, i. é, além de
qualquer duração dada; pois, século não é mais que o período de um ser, como diz Aristóteles. Ou
ainda, diz-se que reina além da eternidade, porque, se alguma coisa existisse sempre, como o
movimento do céu, segundo certos filósofos, ainda Deus reinaria mais, porque o seu reino existe total e
simultaneamente.

RESPOSTA À TERCEIRA. — A eternidade não é outra coisa senão Deus. Por onde, diz-se que Deus é
eterno, não porque seja, de certo modo, medido; pois, a noção de medida emprega-se aí só para auxiliar
nossa apreensão.

RESPOSTA À QUARTA. — As palavras que designam os diversos tempos atribuem-se a Deus, porque a
sua eternidade os inclui a todos; não, porém, que ele encerre qualquer variação, que se desenvolva no
presente, no pretérito e no futuro.

## Art. 3 — Se ser eterno é próprio só de Deus.
(I Sent., dist. VIII, q. 2, a. 2; IV, dist. XLIX, q. 1, a. 2, q. 3; Quodl., X, q. 2; De Div. Nom., cap.X, lect. III; De
Causis, lect. II).
O terceiro discute-se assim. — Parece que ser eterno não é próprio de Deus.

1. — Pois, diz a Escritura (Dn 12, 3): E os que tiverem ensinado a muitos o caminho da justiça, esses
luzirão como as estrelas por todas as eternidades. Ora, não haveria várias eternidades se só Deus fosse
eterno. Logo, nem só ele o é.

2. Demais. — Diz ainda a Escritura (Mt 25, 41): Apartai-vos de mim, malditos, para o fogo eterno. Logo,
nem só Deus é eterno.

3. Demais. — Todo necessário é eterno. Ora, há muitas coisas necessárias, como p. ex., todas as
proposições demonstrativas. Logo, nem só Deus é eterno.
Mas, em contrário, diz Jerônimo a Dámaso: Só Deus não tem princípio. Ora, tudo o que tem princípio
não é eterno. Logo, só Deus é eterno.

SOLUÇÃO. — A eternidade, verdadeira e propriamente, só a Deus convém; pois resulta da
imutabilidade, como já vimos, e só Deus é absolutamente imutável, segundo estabelecemos. E, na
medida em que os seres dele recebem a imutabilidade, nessa mesma lhe participam da eternidade. Ora,
há certos seres que recebem de Deus a imutabilidade, de modo tal que nunca mais deixam de existir; e,
neste sentido, a Escritura (Ecl 1, 4) diz que aterra permanece sempre firme. Há outros seres que, na
Escritura, também se denominam eternos, por durarem diuturnamente, embora sejam corruptíveis;
assim os montes chamam-se eternos (Sl 45, 5) e fala-se dos frutos eternos (Dt 33, 15). Mas, há ainda
outros seres, que mais amplamente participam da eternidade, por terem o ser incorruptível ou mesmo,
além disso, imutável a operação, como os anjos e os bem-aventurados, que gozam do Verbo; pois,
quanto à visão do Verbo, não são mutáveis as cogitações dos santos, conforme diz Agostinho. Por isso
se diz que os que vêem a Deus possuem a vida eterna, segundo a Escritura (Jo 17, 3): A vida eterna
porém consiste em que eles te conheçam por um só verdadeiro Deus, etc.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Consideram-se muitas as eternidades, por serem muitos
os que dela participam, contemplando a Deus.

RESPOSTA À SEGUNDA. — O fogo do inferno chama-se eterno, só por ser interminável. Há, porém,
mudança nas penas dos condenados, como se vê na Escritura (Jó 24, 19): Ele passa das águas da neve
para um excessivo calor. Por onde, no inferno não há verdadeira eternidade, mas antes, tempo,
conforme a mesma Escritura (Sl 80, 16): E durará o tempo deles por todos os séculos.

RESPOSTA À TERCEIRA. — Necessário significa um certo modo de ser da verdade, pois esta, segundo o
Filósofo, está no intelecto. O verdadeiro e o necessário são, assim, eternos por existirem num intelecto
eterno, que é só o divino. Donde não se segue, que alguma coisa, fora de Deus, seja eterna.

## Art. 4 — Se a eternidade difere do tempo.
(Infra, a. 5; I Sent., dist. VIII, q. 2, a. 2; dist. XIX, q. 2, a. 1; De Pot., q. 3, a. 14, ad 10, 18; De Div. Nom.,
cap. X, lect. III)
O quarto discute-se assim. — Parece que a eternidade não difere do tempo.

1. — Pois, é impossível existirem duas medidas simultâneas de duração, se uma for parte da outra;
assim, não podem existir simultaneamente dois dias ou duas horas, ao passo que a hora e o dia são
simultâneos porque aquela faz parte deste. Ora, a eternidade e o tempo existem simultaneamente e
ambos implicam uma certa medida da duração. Logo, a eternidade, não sendo parte do tempo, porque
o excede e o inclui, resulta que este é parte daquela e dela não difere.

2. Demais. — Segundo o Filósofo, o momento temporal permanece idêntico a si mesmo na totalidade
do tempo. Ora, isto mesmo é o que constitui a essência da eternidade, a saber, permanecer
indivisivelmente idêntica a si mesma em todo decurso do tempo. Logo, a eternidade é
um momento temporal. Ora, este não difere essencialmente do tempo. Logo, deste não difere
substancialmente a eternidade.

3. Demais. — Assim como a medida do primeiro movimento é a medida de todos os outros, segundo
Aristóteles, assim também a medida do primeiro ente há-de ser a de todos os demais. Ora, a eternidade
mede o ser primeiro, que é o divino. Logo, mede todos os demais seres. E como o ser das coisas
corruptíveis é medido pelo tempo, este ou é a eternidade ou parte dela.
Mas, em contrário, a eternidade existe toda simultaneamente. Ora, no tempo há anterioridade e
posterioridade. Logo, não se identificam.

SOLUÇÃO. — É claro que o tempo não se identifica com a eternidade. A razão da diversidade deles,
porém, alguns a descobriram em a eternidade não ter princípio nem fim e o tempo tê-los. Mas, esta
diferença é acidental e não essencial, porque, dado que o tempo sempre existiu e sempre existirá,
permanece ainda, admitindo-se a opinião dos que consideram sempiterno o movimento do céu, uma
diferença entre a eternidade e o tempo, como diz Boécio. Essa consiste em ser a eternidade a medida
do permanente e o tempo, a do movimento; pois, a primeira existe toda simultaneamente e o tempo,
não. Se, porém, considerarmos a diferença referida, relativamente ao medido, e não às medidas, então
a doutrina em questão tem certo fundamento. Pois, só é medido pelo tempo o que tem princípio e fim
temporais, como diz Aristóteles. Por onde, se o movimento do céu durasse sempre, o tempo não o
mediria na totalidade da sua duração, porque o infinito não é mensurável; medir-lhe-ia, porém, os
círculos, que têm princípio e fim temporais. Podemos ainda descobrir outro fundamento na opinião que
discutimos, relativamente às medidas mesmas, se considerarmos o fim e o princípio, potencialmente.
Pois, mesmo dado que o tempo dure sempre, ainda assim seria possível descobrir nele princípio e fim,
considerando-lhe as partes, no sentido em que falamos do princípio e do fim do dia ou do ano. Ora, isto
não pode convir à eternidade, embora tais diferenças resultem da diferença primária e essencial, a
saber, que a eternidade existe toda simultaneamente, e o tempo, não.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção procederia se o tempo e a eternidade fossem
medidas do mesmo gênero; o que, evidentemente é falso, dadas as naturezas daquele e desta.

RESPOSTA À SEGUNDA. — O momento temporal constitui um mesmo sujeito, em todo o decurso do
tempo, mas não na concepção racional. Pois, assim como o tempo corresponde ao movimento, assim
o momento temporal, ao móvel. Ora, este é um mesmo sujeito em todo decurso do tempo, mas muda
na concepção racional, segundo está aqui ou acolá. E essa alternação constitui o movimento, do mesmo
modo que o fluxo do momento,enquanto alternado racionalmente, constitui o tempo. A eternidade, ao
contrário, permanece a mesma quanto ao sujeito e quanto à nossa concepção. Logo, não se identifica
com o momento temporal.

RESPOSTA À TERCEIRA. — Assim como a eternidade é a medida do ser em si mesmo, assim o tempo é a
medida própria do movimento. Por onde, na medida em que um ser se afasta da existência permanente
e sujeita-se à mudança, nessa mesma se afasta da eternidade e se sujeita ao tempo. Logo, o ser das
coisas corruptíveis, sendo mutável, não é medido pela eternidade, mas, pelo tempo. Pois, este mede
não só o que atualmente muda, mas também o que é suscetível de mudança e, portanto, mede, não só
o movimento, mas também o repouso, próprio ao ser ao qual o movimento é natural embora não seja
atualmente movido.

## Art. 5 — Se o evo difere do tempo.
(I Sent., dist. VIII, q. 2, a. 2; dist. XIX, q. 2, a. 1; II, dist. 2, q. 1, a 1; De Pot., q. 3, a. 14, ad 18; Quodl., X, q.
2).
O quinto discute-se assim. — Parece que o evo não difere do tempo.

1. — Pois, diz Agostinho, que Deus move as criaturas espirituais no tempo. Ora, entende-se por evo a
medida das substâncias espirituais. Logo, o tempo não difere do evo.

2. Demais. — É da essência do tempo ter anterioridade e posterioridade, ao passo que a eternidade, por
essência, existe toda simultaneamente, como já dissemos. Ora, o evo não é a eternidade, pois diz a
Escritura (Ecle 1, 1), que a sabedoria eterna é anterior ao evo. Logo, este não existe todo
simultaneamente mas tem anterioridade e, portanto, é tempo.

3. Demais. — Se no evo não há anterioridade e posterioridade, segue-se que nos seres eviternos não há
diferença entre ser, ter sido, ou haver de ser. Ora, como é impossível tais seres não tenham existido,
segue-se que é impossível não hajam de ser, o que é falso, porque Deus pode reduzi-los a nada.

4. Demais. — A duração dos seres eviternos sendo infinita, na sua continuidade, se o evo existe total e
simultaneamente, segue-se que há seres criados atualmente infinitos, o que é impossível. Logo, o evo
não difere do tempo.
Mas, em contrário, diz Boécio: Tu que fazes sair o tempo, do evo.

SOLUÇÃO. — O evo difere do tempo e da eternidade, sendo o termo médio entre ambos.
Esta diferença, porém, uns a descobrem em que a eternidade não tem princípio nem fim; o evo tem
princípio, mas não tem fim; e o tempo tem princípio e fim. — Mas esta diferença é acidental, como já
dissemos, pois mesmo que os seres eviternos tivessem existido sempre e sempre houvessem de existir;
e mesmo que viessem a deixar de existir um dia, o que Deus poderia fazer, mesmo assim, o evo se
distinguiria da eternidade e do tempo.
Outros, porém, descobrem a diferença em que a eternidade não tem antes nem depois; o tempo tem
antes e depois, implicando inovação e antiguidade; e o evo tem antes e depois, mas, sem renovação e
antiguidade. — Mas, esta opinião implica contradição, que manifestamente ressalta, se a renovação e a
antiguidade se referirem à medida mesma. Pois, não podendo ser simultâneos o anterior e o posterior
da duração, se o evo tem antes e depois, é necessário que, desaparecendo uma parte anterior,
sobrevenha, como renovamento, a que lhe sucede; e, desde logo, haveria no evo renovação, como no
tempo. Se, porém, se referirem às coisas medidas, também daí resultam inconvenientes. Pois, as coisas
temporais envelhecem no tempo, porque têm o ser transmutável; e é dessa transmutabilidade que
resultam o antes e o depois do tempo, como se vê em Aristóteles. Se, portanto, o sujeito de
eviternidade não envelhece nem se renova temporalmente, é porque tem o ser intransmutável. Logo, a
sua medida não tem antes nem depois.
Devemos, portanto, admitir que, sendo a eternidade a medida do ser permanente, na medida em que
uma criatura se afasta da permanência do ser, nessa mesma se afasta da eternidade. Ora, certas se
afastam de modo tal, que o ser delas está sujeito à transmutação ou nesta consiste. Outras, porém,
afastam-se menos, porque o ser delas nem consiste na transmutação, nem está sujeito a esta; contudo
tem a transmutação adjunta, atual ou potencialmente. E isto bem se vê nos corpos celestes cujo ser
substancial é intransmutável mas tem adjunto o movimento local. O mesmo se dá com os anjos, que
têm o ser intransmutável, mas variável quanto à eleição, na medida em que isso lhes pertence à
natureza; e variável, ainda, pelos pensamentos, pelos afetos, e a seu modo, localmente. Por isso
medem-se pelo evo, meio termo entre a eternidade e o tempo. Ora, o ser que se mede pela eternidade,
nem é mutável, nem admite nenhuma espécie de mudança; assim pois, no tempo, há antes e depois; no
evo, não há, mas pode vir conjuntamente com eles; a eternidade não os tem, nem com eles é
compatível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As criaturas espirituais, quanto aos afetos e
pensamentos, em que há sucessão, medem-se pelo tempo; e, por isso, diz Agostinho, que ser movido no
tempo é ser movido quanto aos afetos. Quanto ao ser natural, porém, elas são medidas pelo evo. E, por
fim, quanto à visão da glória, participam da eternidade.

RESPOSTA À SEGUNDA. — O evo existe todo e simultaneamente; não é porém a eternidade, porque em
si comporta antes e depois.

RESPOSTA À TERCEIRA. — No ser do anjo em si mesmo considerado, não há diferença do pretérito e
futuro, senão só por mutações adjuntas. Mas, quando dizemos que o anjo é, foi ou há-de ser, isso
implica diferença na acepção do nosso intelecto, que compreende o ser angélico por comparação com
as diversas partes do tempo. E quando o nosso intelecto diz, que o anjo é ou foi, supõe algo de
incompatível com a suposição contrária, mesmo para o poder divino; e quando diz que será, não
faz ainda tal suposição. Ora, o ser e o não-ser do anjo, dependendo do poder divino, Deus pode,
absolutamente falando, fazer com que o ser dele não venha a existir; não pode, porém, fazer que não
exista, existindo; ou que não seja, depois que foi.

RESPOSTA À QUARTA. — A duração do evo é infinita, porque não tem limites no tempo. Por onde, não
é inconveniente existir uma criatura infinita, por não ser limitada por nenhuma outra.

## Art. 6 — Se há só um evo.
(II Sent., dist. II, q. 1, a. 2; Quodl., V, q. 4; Opusc. XXXVI, De Instant., cap. III).
O sexto discute-se assim. — Parece que não há um só evo.

1. — Pois, diz o livro apócrifo de Esdras (III, IV, 40): a majestade e o poder dos evos está em ti, Senhor.

2. Demais. — Gêneros diversos têm medidas diversas. Ora, certos seres eviternos — os corpos celestes
— pertencem ao gênero das coisas corpóreas; outros, porém — os anjos — são substâncias espirituais.
Logo, não há um só evo.

3. Demais. — Designando o evo a duração, os seres que têm o mesmo evo têm a mesma duração. Ora,
nem todos os seres eviternos têm a mesma duração, porque uns começam a existir depois de outros,
bem o demonstram as almas humanas. Logo, não há um só evo.

4. Demais. — Seres que não dependem uns dos outros não têm a mesma medida de duração; por isso é
que todas as coisas temporais são medidas pelo mesmo tempo, porque a causa de todos os movimentos
é, de certo modo, o primeiro movimento, medido pelo primeiro tempo. Ora, os seres eviternos não
dependem uns dos outros. Logo, não há um só evo.
Mas, em contrário. — O evo é mais simples que o tempo e mais se aproxima da eternidade. Ora, o
tempo é um só. Logo, com maior razão, o evo.

SOLUÇÃO. — Sobre este assunto houve duas opiniões. Uns dizem que o evo é um só e outros, que
muitos. Para sabermos qual delas é a mais verdadeira, devemos considerar a causa da unidade do
tempo, pois pelo conhecimento do corporal, chegamos ao do espiritual. Assim, uns dizem que há um só
tempo para todos os seres corpóreos, porque só há um número para todas as coisas numeradas; pois, o
tempo é número, segundo o Filósofo. Mas, isto não basta, porque o tempo não é um número separado
da coisa numerada, mas, nesta existente; do contrário, não seria contínuo, pois a continuidade de dez
braças de pano, por exemplo, não está em um número, mas no pano numerado. Ora, o número
existente nos numerados não é o mesmo para todos, mas cada um tem o seu.
Por isso, outros querem ver a causa da unidade do tempo na unidade da eternidade, princípio de toda
duração. De modo que todas as durações se reduzem a uma, se lhes considerarmos o princípio; são
muitas, pelo contrário, se considerarmos a diversidade dos seres que recebem a duração do influxo do
primeiro princípio. — Outros, por fim, descobrem a causa da unidade do tempo na matéria prima,
sujeito primeiro do movimento, cuja medida é o tempo. Ora, nenhuma destas duas opiniões pode ser
considerada suficiente, porque seres que se unificam em virtude de um princípio, ou pelo sujeito,
sobretudo remoto, não têm unidade, pura e simplesmente, mas sobre certo ponto de vista.
Por onde, a verdadeira razão da unidade do tempo é a unidade do primeiro movimento, pelo qual,
sendo simplicíssimo, todos os demais são medidos, como diz Aristóteles. Assim, pois, o tempo está para
esse movimento, não só como a medida, para o medido, mas também como o acidente, para o sujeito
e, portanto, dele recebe a unidade; ao passo que está para os outros movimentos somente como
medida, para o que é medido; e nem se multiplica com a multidão deles, porque uma medida distinta
pode medir muitas coisas.
Isto posto, devemos saber que houve dupla opinião a respeito das substâncias espirituais. Assim, uns
diziam que todas ou, pelo menos, muitas, no sentir de outros, procederam de Deus em uma quase
igualdade, como ensina Orígenes. Outros, porém, diziam que todas as substâncias procederam de Deus
num certo grau e numa certa ordem; este foi o sentir de Dionísio que diz haver, entre as substâncias
espirituais e ainda, numa mesma ordem de anjos, primeiras, médias e últimas. Ora, pela primeira
opinião, é necessário admitirem-se vários evos correlativos aos vários seres eviternos primeiros e iguais.
Pela segunda, é necessário admitir-se um só evo, porque, medindo-se cada ser pelo que é mais simples
no seu gênero, como diz Aristóteles, o ser de todas as criaturas coeternas há-de forçosamente ser
medido pelo que o é primariamente, tanto mais simples quanto mais elevado for. Ora, sendo esta
opinião mais verdadeira, como a seguir se demonstrará, concedemos, no caso presente, que há um só
evo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Evo é às vezes tomado por século, período de duração
de um ser; e, então consideram-se os evos muitos, como os séculos.

RESPOSTA À SEGUNDA. — Embora os corpos celestes e os espirituais difiram pelo gênero da natureza,
têm, contudo, de comum, o serem intransmutáveis, e, por isso, medem-se pelo evo.

RESPOSTA À TERCEIRA. — Embora os seres temporais não comecem todos simultaneamente, contudo,
todos estão no mesmo tempo, por causa do movimento primeiro medido pelo tempo. E, assim, todos os
seres eviternos têm um mesmo evo, em virtude do primeiro dentre eles, embora nem todos comecem
simultaneamente.

RESPOSTA À QUARTA. — Para que várias coisas tenham a mesma medida, não é necessário que esta
seja a causa de todas aquelas, mas, que seja mais simples que elas.