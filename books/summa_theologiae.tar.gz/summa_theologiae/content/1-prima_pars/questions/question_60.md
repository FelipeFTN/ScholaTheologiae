# Questão 60: Do amor ou da dileção dos anjos.
Em seguida deve se considerar o ato da vontade, que é o amor ou dileção, pois, todo ato da virtude
apetitiva deriva do amor ou dileção.
E, sobre este ponto, cinco artigos se discutem:

## Art. 1 — Se nos anjos há amor ou dileção natural.
(III Sent., dist. XXVII, q. 1, a. 2.)
O primeiro discute-se assim. – Parece que nos anjos não há amor ou dileção natural.

1. —Pois, o amor natural se opõe ao intelectual, como se vê em Dionísio. Ora, o amor do anjo é
intelectual. Logo, não é natural.

2. Demais. — Os seres que amam por amor natural mais são conduzidos do que agem por si; pois
nenhum tem o domínio da sua natureza. Ora, os anjos não são conduzidos, mas agem por si, dotados
que são de livre arbítrio, como já se demonstrou. Logo, neles não há amor ou dileção natural.

3. Demais. — Toda dileção ou é reta ou não; respeitando aquela à caridade, esta, à iniqüidade. Ora, a
caridade não respeita à natureza, por ser superior a esta; nem a iniqüidade, por ser contrária à mesma.
Logo, não há nos anjos dileção natural.
Mas, em contrário, a dileção se segue ao conhecimento, pois só se ama o que se conhece, como diz
Agostinho. Ora, nos anjos há conhecimento natural. Logo, também há a dileção natural.

SOLUÇÃO. — É necessário admitir-se nos anjos a dileção natural; o que se evidencia considerando-se
que o anterior deve existir no posterior. Ora, sendo a natureza, essência do ser, anterior ao intelecto, o
que pertence à natureza deve existir também nos seres inteligente. Mas, é comum a toda natureza uma
certa inclinação, que é o apetite natural ou o amor; e essa inclinação existe diversamente nas diversas
naturezas; em cada uma ao modo dessa. Donde, na natureza intelectual, a inclinação natural se funda
na vontade; na sensitiva, no apetite sensitivo; enfim, na desprovida de conhecimento, na só tendência
da natureza. Por isso, o anjo, sendo de natureza intelectual, necessário é tenha na sua vontade a dileção
natural.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O amor intelectual se opõe ao natural, que é somente
natural; pois, como tal lhe não acrescenta a natureza, além da essência da mesma, a perfeição do
sentido ou do intelecto.

RESPOSTA À SEGUNDA. — Todos os seres da totalidade do universo são conduzidos por outro; salvo o
agente primeiro, o qual, identificando-se nele a natureza e a vontade, age de modo que por nenhum
outro é conduzido. Por onde, não é inconveniente que o anjo seja conduzido, pois a sua inclinação
natural lhe foi infundida pelo autor da sua natureza. Contudo, ele não é conduzido de modo tal que não
tenha atividade própria, dotado que é de vontade livre.

RESPOSTA À TERCEIRA. — Assim como o conhecimento natural sempre é verdadeiro, a dileção natural
sempre é reta, pois, o amor natural nada mais é do que a inclinação da natureza, nela infundida pelo seu
autor. Dizer, portanto, que não seja reta a inclinação da natureza é ir contra o autor desta. Contudo,
uma é a retidão da dileção natural, outra a da caridade e da virtude; pois, esta é perfectiva daquela. Do
mesmo modo que uma é a verdade do conhecimento natural, e outra a do conhecimento infuso ou
adquirido.

## Art. 2 — Se nos anjos há dileção eletiva.
(Ia IIae, q. 10, a. 1; De Verit., q. 22, a. 2.)
O segundo discute-se assim. — Parece que nos anjos não há dileção eletiva.

1. — Pois a dileção eletiva é o amor racional resultando do conselho, que consiste numa inquisição,
como diz Aristóteles. Ora, o amor racional se opõe ao intelectual, próprio dos anjos, como diz Dionísio.
Logo, nos anjos não há dileção eletiva.

2. Demais. — Além do conhecimento infuso, só há nos anjos o natural, pois eles não partem de
princípios para chegar a conclusões. E assim comportam-se para com tudo o que naturalmente podem
conhecer como o nosso intelecto para com os primeiro princípios naturalmente cognoscíveis, conforme
já se disse. Logo, nos anjos, além da dileção gratuita só há a dileção natural, não havendo, portanto, a
eletiva.
Mas, em contrário — Pelo que nos é natural, nem merecemos nem desmerecemos. Ora, os anjos, pela
sua dileção, merecem ou desmerecem. Logo, há neles dileção eletiva.

SOLUÇÃO. — Há nos anjos uma dileção natural e outra eletiva, sendo aquela o princípio desta, pois
sempre o que tem prioridade de existência exerce a função de princípio. Por onde, sendo a natureza o
que é primário em qualquer ser, é necessário que o atinente a ela seja nesse ser o princípio. E isto bem
se vê no homem, quanto ao intelecto e quanto à vontade. Pois, o intelecto conhece os princípios
naturalmente e desse conhecimento resulta para a ciência das conclusões, não conhecidas
naturalmente, mas por invenção ou por doutrina. E semelhantemente, o fim é na vontade o que o
princípio é no intelecto, conforme diz Aristóteles. Donde, a vontade tende naturalmente para o seu fim
último, pois todo homem quer naturalmente a felicidade. E dessa vontade natural resultam todas as
demais vontades, porque o homem quer, por causa de um fim, tudo o que quer. Portanto, a dileção do
bem, que o homem naturalmente quer como fim, é uma dileção natural; porém, a dileção do bem,
amado por causa do fim, é derivada da primeira e é a dileção eletiva
Mas as coisas se passam diferentemente em relação ao intelecto e à vontade. Pois, como já ficou dito,
pelo conhecimento intelectual as coisas conhecidas estão no ser que conhece. Sendo por imperfeição da
natureza intelectual que o intelecto humano não apreende imediata e naturalmente todos os
inteligíveis, mas só alguns, pelos quais, de certo modo, alcança os outros. — Ao passo que,
inversamente, o ato da virtude apetitiva parte do apetente para as coisas, das quais, umas são por si
boas e apetecíveis, e outras o são dependentemente de outra. Por isso, não é imperfeição apetecer
naturalmente uma coisa, como fim e outra, por eleição, como ordenada ao fim. Ora, sendo a natureza
intelectual dos anjos perfeita, neles há só o conhecimento natural; não o racionativo; havendo porém a
dileção natural e a eletiva. — Tudo porém o que se acaba de dizer é com exclusão do sobrenatural, do
qual não é a natureza o princípio suficiente, e disso se tratará em seguida

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dividindo-se por oposição o amor racional do
intelectual, nem toda dileção eletiva é amor racional. Pois, chama-se amor racional ao que resulta do
conhecimento racionativo. Ora, nem toda eleição resulta do discurso da razão, mas só a eleição
humana, como já se dissequando se tratou do livre arbítrio. Logo, a objeção não colhe.

RESPOSTA À SEGUNDA. — Resulta a resposta do que ficou dito.

## Art. 3 — Se o anjo se ama a si mesmo por dileção natural e eletiva.
(Ia IIae, q. 26, a. 4; q. 29, a. 4; De Div. Nom., cap. IV, lect. IX)
O terceiro discute-se assim. — Parece que o anjo não se ama a si mesmo por dileção natural e eletiva.

1. — Pois a dileção natural se refere ao fim, como já se disse; ao passo que a eletiva, aos meios. Mas o
referente ao fim não se pode identificar com o referente aos meios, no mesmo ponto de vista. Logo, a
dileção natural e a eletiva não podem ter o mesmo objeto.

2. Demais. — O amor é virtude unitiva e concretiva, como diz Dionísio. Mas a união e a concreção se
referem a diversos objetos reduzidos a um só. Logo, não pode o anjo amar-se a si mesmo.

3. Demais. — Dileção é movimento. Mas todo movimento tende para um termo. Logo, o anjo se não
pode amar a si mesmo por amor natural nem eletivo.
Mas, em contrário, diz o Filósofo que a amizade para com outrem vem da que temos para conosco
mesmo.

SOLUÇÃO. — Tendo o amor por objeto o bem, e sendo este substancial e acidental, conforme diz
Aristóteles, de dois modos pode uma coisa ser amada: como bem subsistente e como bem acidental ou
inerente. A que se ama pelo primeiro modo, a essa se lhe deseja algum bem; a que se ama pelo segundo
é a que se deseja para outra coisa: assim a ciência é amada, não por ser boa, mas por ser possuída. A
esta espécie de amor alguns chamaram concupiscência; à primeira, porém, amizade. Ora, é claro que os
seres privados de conhecimento naturalmente apetecem o que lhes é o bem; assim, o fogo apetece o
lugar superior. Por isso, também o anjo e o homem naturalmente apetecem o bem próprio e a própria
perfeição; e a isto se chama amar-se a si mesmo. Por onde, naturalmente o anjo, como o homem, ama-
se a si mesmo, pois deseja para si algum bem, pelo apetite natural. Mas, na medida em que deseja para
si e por eleição algum bem, nessa mesma ama-se a si por dileção eletiva.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O anjo, como o homem, não se ama a si mesmo por
dileção natural e eletiva, em relação ao mesmo ponto de vista, mas a diversos, como se disse.

RESPOSTA À SEGUNDA. — Assim como mais é ser uno do que ser unido, assim é mais uno o amor a si
mesmo do que o às diversas coisas que estão unidas ao amante. E Dionísio, usando os
termos união e concreção, quis mostrar como o amor deriva do amante para os outros seres, do mesmo
modo que, de um deriva unicidade.

RESPOSTA À TERCEIRA. — Como o amor é ação imanente no agente, assim é movimento imanente no
amante, e não transitivo, necessariamente, a algo de exterior; pode, porém, refletir-se sobre o amante
para que se ame a si mesmo, assim como o conhecimento se reflete no conhecente, para que se
conheça a si mesmo.

## Art. 4 — Se um anjo, pela dileção natural, ama a outro como a si mesmo.
(De div. nom., cap. IV, lect. IX)
O quarto discute-se assim. — Parece que um anjo, por dileção natural, não ama a outro como a si
mesmo.

1. — Pois, a dileção resulta do conhecimento. Ora, um anjo não conhece a outro como a si mesmo, pois,
conhecendo-se a si mesmo por meio da sua essência, só conhece a outro pela sua semelhança, como já
se disse antes. Logo, um anjo não ama a outro como a si mesmo.

2. Demais. — A causa é superior ao causado e o princípio, ao que de si deriva. Ora, a dileção para com
outrem deriva da para consigo mesmo, conforme diz o Filósofo. Logo, um anjo não ama a outro como a
si mesmo, mas se ama a si mesmo mais.

3. Demais. — A dileção natural ama o fim e não se pode perder. Ora, um anjo não é fim de outro; e além
disso, essa dileção pode perder-se, como se vê pelos demônios, que não amam aos bons anjos. Logo,
um anjo não ama a outro, por dileção natural, como a si mesmo.
Mas, em contrário, o que se encontra em todos os seres, mesmo nos desprovidos de razão, é natural.
Ora, como diz a Escritura (Ecle 13, 19), todo animal ama ao seu semelhante. Logo, um anjo ama
naturalmente a outro como a si mesmo.

SOLUÇÃO. — Como já se disse, o anjo e o homem naturalmente se amam a si mesmo. Ora, o que com
outro ser se unifica com este se identifica e, por isso, cada ser ama o que consigo se unifica. E se o for
por união natural, ama-lo-á por dileção natural; se por união não-natural, ama-lo-á por dileção não-
natural. Assim, o homem ama o seu concidadão por dileção da virtude política; o consangüíneo, porém
por dileção natural, pois se unifica com ele pelo princípio da geração natural. Ora, é manifesto que o que
com outro se unifica, genérica ou especificamente, por natureza se unifica. Por onde, um ser ama, por
dileção natural, aquilo que com ele especificamente se unifica, na medida em que ama a sua própria
espécie. O que se vê, mesmo nos seres desprovidos de conhecimento; pois, o fogo tem inclinação
natural para comunicar a sua forma, que é o seu bem, a outro ser; assim como naturalmente se inclina a
buscar o seu bem, isto é, estar na parte superior. Portanto, deve-se dizer que um anjo ama a outro, por
natural dileção, na medida em que com esse outro convém, por natureza. Na medida, porém, em que
com esse outro convém, por outras conveniências ou dele difere, por certas diferenças, não o ama por
natural dileção.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A expressão como a si mesmo pode, de um modo,
determinar o conhecimento ou a dileção da parte do conhecido e do amado. E assim um anjo conhece a
outro como a si mesmo, conhecendo a existência desse outro como se conhece a si mesmo existente.
De outro modo, pode determinar o conhecimento e a dileção, da parte de quem ama e conhece. E
assim, não conhece a outro como a si mesmo, pois, se conhece a si por meio da sua essência, a outro,
porém, não o conhece pela essência desse. Semelhantemente, não ama a outro como a si mesmo,
porquanto a si mesmo se ama pela sua vontade, a outro, porém, não o ama pela vontade desse..

RESPOSTA À SEGUNDA. — Como não designa a igualdade, mas a semelhança. Pois, fundando-se a
dileção natural na unidade natural, o que está menos unificado com o anjo, naturalmente é menos
amado. Por onde, ele ama naturalmente o que consigo se unifica, numericamente, mais do que o
unificado específica ou genericamente. Mas é natural tenha, para com outro, dileção semelhante à para
consigo mesmo, enquanto que, amando-se a si mesmo, por querer para si o bem, ame a outro
querendo-lhe o bem desse outro.

RESPOSTA À TERCEIRA. — Diz-se que a dileção natural visa o fim, não enquanto alguém deseja para
outro algum bem, mas enquanto, desejando para si algum bem, conseqüentemente o deseja para
outrem, estando este identificado com aquele. E nem pode essa dileção natural ser perdida, mesmo dos
anjos maus, de modo que deixassem de ter dileção natural para com os santos anjos, com os quais
comunicam pela natureza, embora os odeiem, diversificados que são pela justiça e pela injustiça.

## Art. 5 — Se o anjo, pela dileção natural, mais ama a Deus que a si mesmo.
(Ia IIae, q. 109, a. 3; IIa IIae, q. 26, a. 3; II Sent., dist. III, part. II, q. 3; III dist. 29, a. 3; Quodl. I, q. 4, a. 3;
De div. nom., cap. IV, lect. IX, X)
O quinto discute-se assim. — Parece que o anjo, por dileção natural, não ama a Deus mais que a si
mesmo.

1. — Pois, como já se disse, a dileção natural se funda na união natural. Ora, a natureza divina dista
maximamente da do anjo. Logo, por dileção natural, o anjo ama a Deus menos que a si próprio ou
mesmo que a outro anjo.

2. Demais. — Toda causa inclui, em grau eminente, o seu efeito. Ora, o que alguém ama por dileção
natural é por causa de si, pois todo ser ama alguma coisa, enquanto é o seu bem. Logo, por dileção
natural, o anjo não ama a Deus mais que a si mesmo.

3. Demais. — A natureza se reflete sobre si mesma, pois vemos que todo agente naturalmente age para
a conservação de si. Ora, a natureza não se refletiria sobre si mesma se tendesse mais para outra coisa
do que para si própria. Logo, por dileção natural, o anjo não ama a Deus mais que a si mesmo.

4. Demais. — É próprio à caridade o amarmos a Deus mais que a nós mesmos. Ora, a dileção da caridade
não é natural aos anjos, mas se lhes infunde nos corações pelo Espírito Santo, que lhes foi dado, como
diz Agostinho. Logo, por dileção natural, os anjos não amam a Deus mais que a si mesmos.

5. Demais. — A dileção natural sempre permanece, permanecendo a natureza. Ora, o amor a Deus mais
que a si mesmo não permanece no anjo ou no homem pecadores; pois, como diz Agostinho dois amores
fizeram duas cidades, a saber: a terrena, o amor de si até o desprezo de Deus; a celeste, porém, o amor
de Deus até o desprezo de si. Logo, amar a Deus mais que a si mesmo não é natural.
Mas, em contrário. Todos os preceitos morais da lei pertencem à lei natural. Ora, amar a Deus mais que
a si mesmo, sendo preceito moral da lei, o é também da lei natural. Logo, por dileção natural, o anjo
ama a Deus mais que a si mesmo.

SOLUÇÃO. — Alguns disseram que o anjo, por dileção natural, ama a Deus mais que a si mesmo, por
amor de concupiscência, pois mais deseja para si o bem divino do que o seu bem. E também por amor
de amizade, querendo o anjo, naturalmente, para Deus, maior bem do que para si; pois, naturalmente,
quer que Deus seja Deus, querendo, porém, para si, a sua natureza própria. Mas, absolutamente
falando, por dileção natural, mais se ama a si do que a Deus, pois, naturalmente mais intensa e
principalmente ama-se a si do que a Deus.
Mas, surgirá de manifesto a falsidade desta opinião a quem considerar para o que se movem,
naturalmente, os seres naturais; pois, a inclinação natural, nos seres desprovidos de razão indica a da
vontade da natureza intelectual. Ora, o ser natural que, por natureza, depende de outro, naquilo
mesmo que é, mais principalmente se inclina para esse outro do que para si próprio. E essa inclinação
natural se verifica nas coisas naturalmente feitas. Assim, uma coisa é produzida pela natureza como é
natural que a façamos, diz Aristóteles. Ora, vemos a parte se expor, naturalmente, para a conservação
do todo; assim, a mão se expõe ao golpe, sem deliberar, para a conservação de todo o corpo. E, como a
razão imita a natureza, tal imitação encontramos nas virtudes políticas; pois, é próprio do cidadão
virtuoso expor-se ao perigo de morte pela conservação de toda a república; e se o homem fosse parte
natural de tal república, natural lhe seria essa inclinação. Como, porém, em Deus mesmo é o bem
universal, e esse bem abrange também o anjo, o homem e toda criatura, porque toda criatura,
naturalmente, pelo seu ser, vem de Deus, resulta que, por dileção natural, também o anjo, como o
homem, ama a Deus mais e mais principalmente do que a si próprio. Do contrário, se naturalmente
amasse mais a si mesmo que a Deus, resultaria que a dileção natural seria perversa e não se
aperfeiçoaria, mas se destruiria pela caridade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa objeção procede quanto aos seres que entre si se
distinguem no mesmo pé de igualdade, nos quais um, não sendo a razão da existência e da bondade do
outro, ama naturalmente mais a si mesmo do que ao outro, pois, mais unificado está consigo mesmo do
que com o outro. Mas ao ser que é a razão total da existência e da bondade dos outros, mais se ama,
naturalmente, do que a si mesmo; e assim, dissemos que cada parte ama, naturalmente, o todo mais
que a si; e cada indivíduo singular ama, naturalmente, mais o bem da sua espécie do que o seu bem
singular. Ora, Deus, sendo não somente o bem de uma espécie, mas o mesmo bem universal
absolutamente, daí resulta que cada ser ama naturalmente, ao seu modo, mais a Deus que a si mesmo.

RESPOSTA À SEGUNDA. — No dizer-se que deus é amado pelo anjo enquanto é o bem deste,
se enquantoexprimir o fim, então há falsidade, pois, o anjo não ama naturalmente a Deus por causa do
bem do anjo, mas por causa de Deus mesmo. Se, porém, exprimir a razão do amor, por parte do
amante, então há verdade, pois, não estaria na natureza de nenhum ser amar a Deus se cada um não
dependesse do bem, que é Deus.

RESPOSTA À TERCEIRA. — A natureza se reflete em si mesma, não só quanto ao que lhe é singular, mas
muito mais quanto ao comum. Pois, cada ser se inclina não somente para a sua conservação individual,
mas ainda para a específica. E muito mais cada ser tem inclinação natural para o bem absolutamente
universal.

RESPOSTA À QUARTA. — Deus, como bem universal de que depende todo bem natural, é amado por
dileção natural, de cada ser; mas, enquanto bem beatificante, universalmente, de todos os seres, pela
beatitude sobrenatural, é amado pela dileção da caridade.

RESPOSTA À QUINTA. — Identificando-se, em Deus, a sua substância e o bem comum, todos os que
vêem a essência divina, em si, pelo mesmo movimento de dileção, movem-se para ela como distinta dos
outros seres e como sendo um bem comum. E sendo, enquanto bem comum, naturalmente amada de
todos, é impossível não a ame quem a vê. Os que, porém, não a vêem a conhecem por certos efeitos
particulares que, por vezes, contrariando-lhes a vontade, diz-se, então, que esses odeiam a Deus. Mas,
como bem comum de todos, cada qual naturalmente o ama mais que a si mesmo.