# Questão 39: Das Pessoas referidas à essência.
Depois de termos tratado, em absoluto, das Pessoas divinas, resta tratar das Pessoas referidas à
essência, às propriedades e aos atos nocionais, e das relações delas entre si.
Ora, na primeira destas questões discutem-se oito artigos:

## Art. 1 — Se em Deus, essência é o mesmo que Pessoa.
(Supra. Q. 3, a. 3; I Sent., dist. XXXIV, q. 1, a. 1; III dist. VI, q. 2, ad 2).
O primeiro discute-se assim. – Parece que em Deus não é essência o mesmo que pessoa.

1. – Pois, nos seres em que essência é o mesmo que pessoa ou suposto, necessariamente há, para uma
natureza, só um suposto, como é claro em todas as substâncias separadas. Porque, de causas idênticas
realmente, uma não pode ser multiplicada sem que as outras também o sejam. Ora em Deus, há uma só
essência e três Pessoas, como do sobredito resulta. Logo, essência não é o mesmo que pessoa.

2. Demais. – De um mesmo sujeito não se pode fazer uma afirmação e uma negação simultaneamente e
da mesma vez. Ora, a afirmação e a negação verificam-se na essência e na pessoa; pois, esta é distinta e
aquela não o é. Logo, não se identificam pessoa e essência.

3. Demais. – Nada a si mesmo é sujeito. Ora, a pessoa é sujeita à essência, sendo por isso chamada
suposto ou hipóstase. Logo, não se identificam pessoa e essência.
Mas, em contrário, Agostinho: O mesmo é dizer pessoa do Pai e substância do Pai.

SOLUÇÃO. – Aos que refletirem na simplicidade divina esta questão não padece dúvidas. Pois já
demonstramosque a divina simplicidade exige em Deus a identidade de essência e de suposto; este, nas
substâncias intelectuais, não difere da pessoa. Mas a dificuldade surge, de conservar a essência a sua
unidade, embora multiplicadas as Pessoas divinas. E por dizer Boécio que a relação multiplica a Trindade
das pessoas, afirmaram alguns que, em Deus, a essência e a pessoa diferem, do mesmo modo por que
diziam que as relações são assistentes, considerando-as somente como relativas a um termo e não
como realidades.
Mas, como antes já demonstramos, se bem que as relações existam acidentalmente nas coisas criadas,
em Deus são a própria essência divina. Donde se segue que, em Deus, a essência não difere realmente
da pessoa, embora as Pessoas entre si se distingam realmente. Pois pessoa, como dissemos, significa
relação enquanto subsistente na natureza divina. Porém a relação, comparada com a essência, não
difere realmente, senão só racionalmente; mas comparada com a relação oposta, dela se distingue
realmente em virtude da sua oposição. Assim, permanece una a essência e três, as Pessoas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Nas criaturas, não podem os supostos distinguir-se pelas
relações, mas hão necessariamente de distinguir-se pelos princípios essenciais; porque as relações, nas
criaturas, não são subsistentes.Porém em Deus as relações são subsistentes; logo, os supostos podem
distinguir-se enquanto mutuamente se opõem. Mas nem por isso se distingue a essência; porque as
próprias relações mutuamente se não distinguem, enquanto realmente idênticas à essência.

RESPOSTA À SEGUNDA. – Diferindo em Deus a essência e a pessoa, pelo modo de conceber da
inteligência, segue-se que um atributo se pode afirmar de uma, que se nega de outra; e por conseguinte
suposta uma, não se supõe a outra.

RESPOSTA À TERCEIRA. – Impomos nomes a Deus ao modo das coisas criadas, como dissemos. E como
as naturezas das coisas criadas se individuam pela matéria, sujeita à natureza específica, resulta que os
indivíduos se chamam sujeitos, supostos ou hipóstases. Donde vem que também as Pessoas divinas se
chamam supostos ou hipóstases, sem que nelas haja qualquer suposição ou sujeição real.

## Art. 2 — Se devemos dizer que as três Pessoas são de uma só essência.
(I Sent., dist. XXV, exposit. text.; dist. XXXIV, q. 1, a. 2).
O segundo discute-se assim. – Parece que não devemos dizer serem as três Pessoas de uma só
essência.

1. – Pois, diz Hilário: O Padre, o Filho e o Espírito Santo são três certamente pela substância, porém um
pela consonância. Ora, a substância é a essência de Deus. Logo, não são as três Pessoas de uma só
essência.

2. Demais. – Nada devemos afirmar de Deus que não esteja expresso pela autoridade da Sagrada
Escritura, como está claro em Dionísio. Ora, nunca a Sagrada Escritura diz, que o Pai, o Filho e o Espírito
Santo sejam de uma só essência. Logo, tal não devemos afirmar.

3. Demais. – A natureza divina é o mesmo que a essência divina. Bastaria, pois, dizer, segundo parece,
que as três Pessoas têm a mesma natureza.

4. Demais. – Não se costuma dizer, que a pessoa é da essência, mas antes, que esta é daquela. Logo, não
parece conveniente dizer, que as três Pessoas são de uma só essência.

5. Demais. – Segundo Agostinho, não dizemos que as três Pessoas provêm de uma só essência, para que
se não pense que, em Deus, uma coisa é a essência e outra, a pessoa. Mas como as preposições,
também os casos oblíquos encerram a idéia de transição. Donde, pela mesma razão não devemos dizer,
que as três Pessoas são de uma só essência.

6. Demais. – O que pode ser ocasião de erro não se deve dizer de Deus. Ora, dizer que as três Pessoas
são de uma só essência ou substância dá ocasião a erro. Assim, diz Hilário: A substância una predicada
do Pai e do Filho significa ou um ser subsistente, em dois sentidos diversos; ou uma substância dividida
em duas substâncias imperfeitas; ou uma terceira substância primária apropriada e assumida pelas duas
outras. Por onde, não se deve dizer, que as três Pessoas sejam de uma só substância.
Mas, em contrário, diz Agostinho, que o nome homoousion firmado no Concílio Niceno, contra os
Arianos, significa o mesmo que dizer serem as três Pessoas de uma só essência.

SOLUÇÃO. – Como dissemos, o nosso intelecto nomeia as coisas divinas, não ao modo delas, pois assim
não nas pode conhecer; mas ao modo das coisas criadas. Ora, nas coisas sensíveis, das quais o nosso
intelecto tira a sua ciência, a natureza de uma espécie se individualiza pela matéria, fazendo a natureza
a função de forma e o indivíduo, de suposto da forma. Por isso, também em Deus, pelo seu modo de
significar, a essência é como a forma em relação às três Pessoas. Assim, na ordem das coisas criadas,
dizemos que uma forma pertence ao ser do qual ela é; como a saúde ou a beleza, a um certo homem.
Porém não dizemos que um ser, que tem uma forma, pertença a essa forma, senão acrescentando um
adjetivo designativo de tal forma; assim, dizemos: que esta mulher é de egrégia forma, este homem é
de perfeita virtude. E semelhantemente, como, em Deus, a multiplicidade de pessoas não implica a da
essência, dizemos que uma só é a essência das três Pessoas; e que as três Pessoas são de uma só
essência, entendendo-se, que esses genitivos são empregados para designarem a forma.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Substância, no caso, se toma como hipóstase e não como
essência.

RESPOSTA À SEGUNDA. – Embora não se encontre textualmente dito na Escritura que as três Pessoas
são de uma só essência, encontra-se, todavia, nesse sentido. Como nos lugares: Eu e o Pai somos uma
mesma coisa(Jo 10, 30); O Pai está em mim, e eu no Pai (Jo 38; 14, 10). E o mesmo se conclui de muitos
outros lugares.

RESPOSTA À TERCEIRA. – Designando a natureza o princípio do ato, e derivando, porém, a essência do
verbo ser, podem considerar-se da mesma natureza os seres que convêm em algum ato, como, p. ex.,
todos os que aquecem; mas da mesma essência se não podem chamar senão os que têm o mesmo
ser.Poronde, melhor exprimimos a unidade divina dizendo que as três Pessoas são de uma só essência,
do que dizendo que são de uma só natureza.

RESPOSTA À QUARTA. – A forma, absolutamente falando, é de ordinário expressa como pertencendo
ao ser do qual é; p. ex.: a virtude de Pedro. Porém, inversamente, não costumamos dizer, que pertence
à forma o ser que a tem, senão quando queremos determiná-la ou designá-la. E então se requerem dois
genitivos, significando um a forma e o outro, a determinação dela; como se dissermos: Pedro é de
grande virtude. Ou então se requer um genitivo com a força de dois, como se dissermos:Este é homem
de sangue, i. é, derramador de muito sangue. Ora, a essência divina, considerada forma em relação à
pessoa, convenientemente se chama essência da pessoa. Porém não, inversamente; salvo se se fizer um
acréscimo à designação da essência; p. ex., dizendo, que o Padre é uma pessoa de essência divina, ou
que as três Pessoas são de uma só essência.

RESPOSTA À QUINTA. – A preposição de (por e de) não designa relação de causa formal, mas antes, de
causa eficiente ou material. Ora, estas causas sempre se distinguem dos seres dos quais o são; pois,
nenhum ser é a sua própria matéria ou o seu princípio ativo. Porém, há seres, que são a sua própria
forma como o demonstram todos os seres imateriais. Logo, quando dizemos que as três Pessoas são de
uma só essência, significando essência, forma, não queremos dizer seja uma coisa a essência e outra, a
pessoa, o que assim seria se disséssemos, que as três Pessoas são provenientes da mesma, essência.

RESPOSTA À SEXTA. – Diz Hilário: Muito prejudicadas ficariam as coisas santas se deixassem de o ser
porque muitos assim não as reputam. Assim, se entendem mal a expressão homoousion, que isso me
importa a mim, que bem a entendo? E antes: Pois, é uma substância pela mesma propriedade de
geração e não resultante de porções, de uma união ou comunhão.

## Art. 3 — Se os nomes essenciais, como o de Deus, se predicam das três Pessoas no singular ou plural.
(I Sent., dist. IX, q. 1, art. 2).
O terceiro discute-se assim. – Parece que os nomes essenciais, como o de Deus, não se predicam das
três Pessoas, no singular, mas no plural.

1. – Pois, assim como homem significa o que tem humanidade, assim Deus, o que tem a divindade. Ora,
as três Pessoas têm todas as três a divindade. Logo, as três Pessoas são três Deuses.

2. Demais. – Diz a Escritura (Gn 1, 1): No principio criou Deus o céu e a terra, estando no texto
hebraicoElohim, que se pode interpretar como deuses ou juízes. O que assim é dito, por causa da
pluralidade das Pessoas. Logo, as três Pessoas são vários deuses e não um só Deus.

3. Demais. – O vocábulo coisa, empregado em sentido absoluto, parece significar a substância. Ora, esse
vocábulo se predica no plural, das três Pessoas. Assim, diz Agostinho: As coisas de que devemos gozar
são o Padre, o Filho e o Espírito Santo. Logo, também os outros nomes essenciais podem predicar-se no
plural, das três Pessoas.

4. Demais. – Assim como Deus significa o que tem a divindade, assim Pessoa significa que subsiste em
alguma natureza intelectual. Ora, dizemos três Pessoas. Logo, pela mesma razão, podemos dizer três
Deuses.
Mas, em contrário, a Escritura (Dt 6, 4): Ouve Israel, o Senhor nosso Deus é o único Senhor.

SOLUÇÃO. – Dos nomes essenciais, uns exprimem a essência, substantivamente, outros, porém,
adjetivamente. Os primeiros predicam-se das três Pessoas só no singular e não no plural; porém os
segundos dos três se predicam no plural.
E a razão é que os nomes substantivos significam a substância de uma coisa; porém os adjetivos, o
acidente, inerente ao sujeito. Ora, a substância, tendo o ser por si, também por si tem a unidade ou a
multiplicidade; e por isso, a singularidade ou a pluralidade do nome substantivo é considerada em
relação à forma significada pelo nome. Os acidentes, porém, existindo num sujeito, também deste
recebem a unidade ou a multiplicidade. Por isso, nos adjetivos, consideram-se a singularidade e a
pluralidade relativamente aos supostos.
Ora, nas criaturas, uma mesma forma não tem vários supostos senão pela unidade da ordem; assim, a
forma da multidão ordenada. Por onde, os nomes que significam essa forma, sendo substantivos e
empregados no singular, predicam-se de vários; não, porém, se fossem adjetivos. Assim, dizemos que
muitos homens são um colégio, um exército ou um povo; mas dizemos que vários homens são
colegiados. Ora, em Deus, a essência divina é expressa, como se disse, em sentido formal; pois, é
simples e soberanamente una, como demonstramos. Por onde, os nomes que significam
substantivamente a essência divina, predicam-se das três Pessoas no singular e não no plural. E é a
razão de dizermos, que Sócrates, Platão e Cícero são três homens; e não que o Padre, o Filho e o Espírito
Santo são três deuses, senão um só. Porque nos três supostos da natureza humana há três
humanidades; ao contrário, nas três Pessoas só há uma essência divina. Mas os nomes, que significam a
essência, como adjetivos, predicam-se das três Pessoas no plural, por causa da pluralidade dos supostos.
Pois, adjetivamente, dizemos três existentes, três sábios, ou três eternos, incriados e imensos.
Substantivamente, porém, dizemos, como Atanásio diz no Símbolo, um incriado, imenso e eterno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Embora signifique o que tem a divindade, contudo o
nome de Deus também tem outra significação, pois é empregado substantivamente, ao passo que a
expressão – tem a divindade – o é adjetivamente. Por onde, embora sejam três os que têm a divindade,
daí se não segue a existência de três deuses.

RESPOSTA À SEGUNDA. – Línguas diversas têm modo diverso de falar. Por isso, onde os Gregos dizem
três hipóstases, por causa da pluralidade dos supostos, os Hebreus dizem Elohim no plural. Nós, porém,
não dizemos, no plural, nem deuses nem substâncias, para não referirmos a pluralidade à substância.

RESPOSTA À TERCEIRA. – O nome de coisa pertence aos transcendentais. Por isso, enquanto implica
relação, predica-se de Deus no plural; mas, quando significa substância, no singular, Por isso, diz
Agostinho, no mesmo lugar, que a mesma Trindade é uma realidade suma.

RESPOSTA À QUARTA. – A forma significada pelo nome de pessoa não é a essência ou a natureza, mas a
personalidade. Por onde, sendo três as personalidades, i. é, três propriedades pessoais, no Padre, no
Filho e no Espírito Santo, dos três se predicam não no singular mas, no plural.

## Art. 4 — Se os nomes essenciais concretivos podem ser supostos pela Pessoa, de modo a ser verdadeira a proposição seguinte: Deus gerou a Deus.
(I Sent., dist. IV, q. 1 a. 2; dist. V, q. 1, a. 2).
O quarto discute-se assim. – Parece que os nomes essenciais concretivos não podem ser supostos pela
pessoa, de modo a ser verdadeira a proposição – Deus gerou a Deus.

1. – Pois, como dizem os lógicos, um termo singular significa e supõe a mesma realidade. Ora, o nome
de Deus é um termo singular, porque não pode ser predicado no plural, como se disse. Logo,
significando a essência, é tomado pela essência e não, pela pessoa.

2. Demais. – O termo tomado como sujeito não restringe pelo termo tomado como predicado, em razão
da significação deste, mas somente em razão do tempo juntamente significado. Ora, quando digo –
Deus cria – esse nome supõe a essência. Logo, quando digo – Deus gerou – o termo Deus não pode, em
razão do predicado nocional, ser suposto pela pessoa.

3. Demais. – Se é verdadeira a proposição – Deus gerou – porque o Padre gera; igualmente o será esta
outra – Deus não gera – porque o Filho não gera. Logo, há Deus gerador e Deus não gerador. Donde
parece seguir-se, que há dois Deuses.

4. Demais. – Se Deus gerou a Deus, ou a si mesmo se gerou como Deus, ou gerou outro Deus. Ora, a si
mesmo como Deus, não; pois, segundo Agostinho, nenhuma coisa a si mesma se gera. Nem outro Deus,
pois, só há um. Logo, é falsa a proposição Deus gerou a Deus.

5. Demais. – Se Deus gerou a Deus, este último é o Deus Padre, ou um Deus que não é o Padre. Se o
Deus Padre, então este é gerado. Se um Deus, que não é o Padre, então há um que não é o Padre, o que
é falso. Logo, não se pode dizer, que Deus gerou a Deus.
Mas, em contrário, diz o Símbolo: Deus de Deus.

SOLUÇÃO. – Alguns disseram, que o nome de Deus e outros semelhantes, são, por natureza,
propriamente supostos pela essência; mas, com um adjunto nocional, empregam-se como supostos pela
pessoa. E parece que esta opinião nasceu da consideração da divina simplicidade, que exige se
identifiquem em Deus o possuidor e o possuído. Assim, o ser que tem a divindade, que é o significado
do nome Deus, identifica-se com a divindade.
Mas, na propriedade das locuções, não devemos atender somente à coisa significada, mas também ao
modo de significar. Ora, como o nome de Deus significa a essência divina como ela existe no ser que a
tem, assim o nome de homem significa a humanidade no suposto. Donde o dizerem outros, e melhor,
que o nome de Deus, pelo modo de significar, pode propriamente ser suposto pela pessoa, como o
nome de homem. Por isso, umas vezes, o nome de Deus é suposto pela essência, como quando dizemos
– Deus cria; porque esse predicado convém ao sujeito em razão da forma significada, que é a divindade.
Outras vezes, porém, supõe a pessoa: uma somente como quando dizemos – Deus gera; ou duas como
quando dizemos – Deus espira; ou três, como no lugar da Escritura (1 Ti 1, 17): Ao rei dos séculos,
imortal, invisível, a Deus só honra e glória.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O nome de Deus, embora convenha com os termos
singulares por não se multiplicar a forma significada, todavia, convém com os termos comuns por se
encontrar esta em vários supostos. Por onde, não é necessário seja sempre suposto pela essência, que
significa.

RESPOSTA À SEGUNDA. – A objeção procede contra os que diziam, que o nome de Deus não tem
natural suposição pela pessoa.

RESPOSTA À TERCEIRA. – Não se aplica do mesmo modo o nome de Deus, quando suposto pela pessoa,
e o nome de homem. Pois, como a humanidade, forma significada pelo nome de homem, realmente se
divide em diversos supostos, tal forma, em si, é suposta pela pessoa, mesmo nada se acrescentando que
o determine, em relação à pessoa, que é um suposto distinto. Porque a unidade ou comunidade da
natureza humana não é real, mas somente, lógica. Por isso, o termo de homem não é suposto pela
natureza comum senão por exigência de algum acréscimo; p. ex., quando dizemos – homem é espécie.
Ora, a forma significada pelo nome de Deus, a saber, a essência divina, é uma mesma e comum,
realmente. Por isso é suposta, em si, pela natureza comum; mas a sua suposição se determina, em
relação à pessoa, por um adjunto. E, portanto, quando dizemos – Deus gera, o nome de Deus, em razão
do ato nocional, é suposto pela pessoa do Padre. Ao contrário, quando dizemos – Deus não gera, nada
acrescentamos que determine esse nome à pessoa do Filho, a locução será verdadeira, como se
disséssemos – O Deus gênito não gera. Donde se não segue, que haja um Deus gerador e um Deus não
gerador; salvo se acrescentamos alguma propriedade pessoal; como, p. ex., se dissermos – O Padre é o
Deus gerador e o Filho é o Deus não gerador. – Donde não resulta que existam vários deuses; pois, o
Padre e o Filho são um só Deus, como dissemos.

RESPOSTA À QUARTA. – Falsa é a proposição – o Padre gerou-se a si mesmo Deus, porque o se,
exprimindo reciprocidade, designa o mesmo suposto. Nem é a isto contrário o dito de Agostinho, que
Deus Padre gerou a um outro de Si mesmo. Porque, o pronome se ou é um ablativo e significa – gerou
outro, diferente de si; ou exprime uma relação simples e, assim, importa identidade de natureza, mas
sendo a locução imprópria ou enfática e significando – gerou outro simílimo a si. Do mesmo modo, é
falsa a proposição – gerou outro Deus. Pois, embora o Filho seja outro que não o Pai, como dissemos,
todavia se não pode dizer, que seja outro Deus. Porque se entenderia, que a significação do adjetivo
outro recaísse sobre o substantivo Deus, exprimindo então uma distinção da divindade. Certos porém
admitem a proposição – gerou outro Deus, considerando – outro, um substantivo, e construindo Deus,
como aposto à expressão – outro que é Deus. Mas, este modo de falar é impróprio e devemos evitá-lo
para não darmos ocasião a erro.

RESPOSTA À QUINTA. – É falsa a proposição – Deus gerou um Deus que é o Deus Padre, porque Padre,
construído aí como aposto de Deus, restringe-o a exprimir a pessoa do Padre, e o sentido é – gerou um
Deus, que é o próprio Padre; sendo então o Padre gerado, o que é falso. Por isso, é verdadeira a
negativa – gerou um Deus que não é o Deus Padre. Se porém se entender, que não há aposto e que se
deve fazer uma interposição de palavras, então, inversamente, a afirmativa seria verdadeira e a nega-
tiva, falsa, sendo o sentido – gerou um Deus, que é o Deus que é o Padre. Mas essa explicação é forçada
e, por isso, é melhor que a afirmativa seja negada simplesmente e a negativa concedida. – Contudo,
Prepositino disse, que tanto é falsa a negativa como a afirmativa. Pois, o relativo que, na afirmativa,
pode implicar o suposto; mas, na negativa, implica o significado e o suposto. Por onde, o sentido da
afirmativa é: ser Deus Padre convém à Pessoa do Filho. E o da negativa: ser Deus Padre não somente
não convém à Pessoa do Filho, mas, nem à divindade deste. – Mas isto é irracional porque, segundo o
Filósofo, a um mesmo sujeito pode convir a afirmação e a negação.

## Art. 5 — Se os nomes essenciais tomados em abstrato podem ser supostos pela Pessoa, de modo a ser verdadeira a proposição: a essência gera a essência.
(I Sent., dist. V, q. 1, a. 1, 2; De Um. Verb., a. 1, ad 12; Contra Errores Graec., cap. IV; in Decretal., II).
O quinto discute-se assim. – Parece que os nomes essenciais, tomados em abstrato, podem ser
supostos pela pessoa, de modo a ser verdadeira a proposição – a essência gera a essência.

1. – Pois, Agostinho diz: O Pai e o Filho são uma mesma sabedoria porque são uma mesma essência; e,
em particular, a sabedoria da sabedoria, como a essência da essência.

2. Demais. – As coisas, que em nós estão, geram-se ou corrompem-se com a nossa geração ou a nossa
corrupção. Ora, o Filho é gerado. Logo, estando no Filho à essência divina, parece que esta é gerada.

3. Demais. – Deus é o mesmo que a essência divina, como do sobredito resulta. Ora, como se viu, é
verdadeira a proposição – Deus gera a Deus. Logo, também o é esta outra – a essência gera a essência.

4. Demais. – O que é predicado de um sujeito pode ser suposto por ele. Ora, a essência divina é o Pai.
Logo, ela pode supor-se pela pessoa do Pai. E, portanto, a essência gera.

5. Demais. – A essência é um princípio gerador, pois é o Pai, que é gerador. Se, portanto, a essência não
for um princípio de geração, será a essência geratriz e não geratriz, o que é impossível.

6. Demais. – Agostinho diz: O Pai é o princípio de toda a divindade. Ora, só e princípio, gerando ou
espirando. Logo, o Pai gera ou espira a divindade.
Mas, em contrário, diz Agostinho, que nada se gera a si mesmo. Ora, se a essência gera a essência, não
gera senão a si mesma; pois, não há nada em Deus, que se distinga da essência divina. Logo, a essência
não gera a essência.

SOLUÇÃO. – Nesta matéria, errou o abade Joaquim quando asseverou, que, como se diz – Deus gerou a
Deus, também se pode dizer – a essência gerou a essência; considerando, que, por causa da divina
simplicidade, não se distingue Deus, da divina essência. – Mas, nisto se enganou, pois que, para haver
verdade numa proposição, devemos considerar não somente a coisa significada, senão também o modo
de significar, como já vimos. Por onde, embora, na realidade, seja Deus o mesmo que a divindade,
contudo, o modo de significar não é o mesmo em ambos os casos. Pois, o nome de Deus, significando a
essência divina, no ser que a tem, pelo modo da sua significação é-lhe natural poder ser suposto pela
pessoa. E assim, as propriedades das pessoas podem ser predicadas do nome de Deus, podendo dizer-se
que Deus é gerado ou gerador, como vimos. Mas, o nome de essência não pode, pelo modo da sua signi-
ficação, ser suposto pela pessoa; porque significa a essência como forma abstrata. Logo, as pro-
priedades das Pessoas, pelas quais se distinguem umas das outras, não podem ser atribuídas à essência;
o que significaria, que há uma distinção na essência divina, como há distinção nos supostos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Para nos fazer entender a unidade da essência e da
pessoa, os santos Doutores por vezes manifestaram o seu pensamento de modo mais expressivo do que
o permite a natureza do assunto. Por isso, as suas expressões não se devem amplificar, mas, explicar;
por ex., os nomes abstratos, pelos concretos, ou mesmo pelos nomes pessoais. Assim, quando dizem –
essência da essência, – ou – sabedoria da sabedoria, o sentido é – o Filho, que é essência e sabedoria,
vem do Pai, que é essência e sabedoria. Demais, nesses nomes abstratos devemos atender a uma certa
ordem. Assim, o que é próprio do ato mais proximamente se refere às pessoas; porque os atos se
atribuem aos supostos. Por onde, menos imprópria é a proposição – natureza da natureza, ou –
sabedoria da sabedoria, do que esta – essência da essência.

RESPOSTA À SEGUNDA. – Nas criaturas, o gerado não recebe a mesma natureza, numericamente, que a
do gerador; mas diversa, numericamente, que começa no gerado, de novo, pela geração e extingue-se
pela corrupção. Portanto, o gerado gera-se e corrompe-se por acidente. Ora, o Deus gerado tem a
mesma natureza, numericamente, que o gerador. Logo, a natureza divina do Filho não é gerada, nem
por essência nem por acidente.

RESPOSTA À TERCEIRA. – Embora Deus e a divina essência sejam realmente idênticos, contudo, em
razão do modo de significar de uma e da outra, devemos nos referir a cada qual, de modo diverso.

RESPOSTA À QUARTA. – A essência divina é predicada do Pai por modo de identidade, por causa da
divina simplicidade. Mas, daí se não segue, que possa ser suposta pelo Pai, por causa do modo diverso
de significar. A objeção seria porém procedente, relativamente aos conceitos, que se predicam uns dos
outros, como o universal, do particular.

RESPOSTA À QUINTA. – A diferença entre os nomes substantivos e adjetivos está em implicarem
aqueles o seu suposto; ao passo que estes não, pois ligam a realidade significada ao substantivo. Por
isso, dizem os lógicos que os nomes substantivos supõem, ao passo que os adjetivos não supõem, mas
copulam. Portanto, os nomes pessoais substantivos podem ser predicados da essência por causa da
identidade. Nem de tal resulta, que a propriedade pessoal determine uma essência distinta. Mas é
atribuída ao suposto implicado pelo nome substantivo. Ao passo que os adjetivos nocionais e os
pessoais não podem ser predicados da essência, senão com um substantivo adjunto. Por isso, não
podemos dizer que a essência é geratriz. Podemos, porém, dizer que a essência é uma realidade
geratriz, ou Deus gerador, supondo-se realidade e Deus pela pessoa; mas não, se forem supostos pela
essência. Assim não hácontradição em dizer-se, que a essência é uma realidade geratriz e uma realidade
não geratriz; porque, no primeiro caso, realidade é tomada como pessoa; no segundo, como essência.

RESPOSTA À SEXTA. – A divindade, enquanto é a mesma em várias pessoas, tem certa conveniência
com a forma do nome coletivo. Por isso, quando dizemos – O Pai é o princípio de toda divindade, isso
pode significar a universalidade das Pessoas, por ser ele de todas as Pessoas divinas o princípio. Nem
por isso há de necessariamente ser o princípio de si mesmo, do mesmo modo que um indivíduo do povo
é chamado guia de todo o povo, não, porém de si mesmo. Ou podemos dizer que o Pai é o princípio de
toda divindade, não por gerá-la ou espirá-la, mas, porque a comunica, gerando-a e espirando-a.

## Art. 6 — Se as Pessoas podem ser predicadas dos nomes essenciais concretos, de modo a dizermos: Deus é as três Pessoas ou a Trindade.
(I Sent., dist. IV, q. 2, a, 2, ad 4, 5,).
O sexto discute-se assim. – Parece que as Pessoas não podem predicar-se dos nomes essenciais
concretos, de modo a dizermos – Deus é as três Pessoas ou a Trindade.

1. – Pois, a proposição – um homem é todo homem – é falsa porque Sócrates não é todo homem, nem
Platão, nem qualquer outro. Ora, semelhantemente, a proposição – Deus é a Trindade – não pode ser
verificada em nenhum dos supostos da natureza divina; pois, nem o Pai é a Trindade, nem o Filho, nem
o Espírito Santo. Logo, é falsa a proposição – Deus é a Trindade.

2. Demais. – Os inferiores não se predicam dos seus superiores senão por predicação acidental, como
quando digo – um animal é homem; pois, é um acidente para o animal ser homem. Ora, o nome de Deus
está para as três Pessoas como um nome comum, para os inferiores, segundo Damasceno. Logo, os
nomes das Pessoas não podem ser predicados do nome de Deus, senão acidentalmente.
Mas, em contrário, Agostinho: Cremos que um mesmo Deus é a Trindade una do nome divino.

SOLUÇÃO. – Como já dissemos, embora os nomes pessoais ou os adjetivos nocionais não possam ser
predicados da essência, contudo os substantivos o podem, por causa da identidade real da essência e da
pessoa. Ora, a essência divina é idêntica realmente não só a cada uma das pessoas, mas às três. Por isso
uma pessoa, as duas ou as três podem ser predicadas da essência, como se dissermos – A essência é o
Pai, o Filho e o Espírito Santo. E como o nome de Deus pode, por si, ser suposto pela essência, como
vimos, assim como é verdadeira a proposição – A essência é as três Pessoas – também o será esta outra
– Deus é as três Pessoas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como dissemos, o nome de homem pode, em si, ser
suposto pela pessoa; mas, pelo seu adjunto, pode ser tomado pela natureza comum. Assim, é falsa a
proposição – Um homem é todo homem, por não poder ser verificada em nenhum suposto. Ora, o
nome de Deus é, em si mesmo, tomado pela essência. Por onde, embora de nenhum dos supostos da
natureza divina seja verdadeira a proposição – Deus é a Trindade – contudo é verdadeira pela essência.
E foi por não atender a isso que Porretano a negou.

RESPOSTA À SEGUNDA. – Quando dizemos – Deus ou a divina essência é o Pai – há predicação por
identidade, e não como a de um inferior predicado do superior; porque em Deus não há universal nem
singular. Por onde, como implica predicação essencial a proposição – o Pai é Deus – assim também esta
outra – Deus é o Pai – implica predicação essencial e, de nenhum modo; acidental.

## Art. 7 — Se os nomes essenciais devem ser apropriados às Pessoas.
(I Sent., dist. XXXI, q. 1, a. 2; De Verit., q. 7, a. 3).
O sétimo discute-se assim. – Parece que os nomes essenciais não devem ser apropriados às pessoas.

1. – Pois, devemos evitar o que pode redundar em erro de fé, quando falamos de Deus; porque, como
diz Jerônimo, por palavras desordenadamente proferidas incorre-se em heresia. Ora, apropriar a uma
das Pessoas o que é comum às três pode levar a um erro contra a fé. Pois poderíamos entender que
somente a essa Pessoa convém o que se lhe apropria, ou que mais lhe convém, que às outras. Logo, os
atributos essenciais se não devem apropriar às Pessoas.

2. Demais. – Os atributos essenciais empregados em abstrato, significam ao modo da forma. Ora, uma
Pessoa não se comporta, em relação à outra, como forma; pois a forma não se distingue do suposto ao
qual pertence. Logo, os atributos essenciais, sobretudo empregados em abstrato, não se devem
apropriar às Pessoas.

3. Demais. – O próprio é anterior ao apropriado, pois pertence à ação deste. Ora, os atributos essenciais,
pelo modo de os compreendermos, são anteriores às Pessoas, como o comum é anterior ao próprio.
Logo, os atributos essenciais não devem ser apropriados.
Mas, em contrário, a Escritura (1 Cor 1, 24): Cristo, virtude de Deus e sabedoria de Deus.

SOLUÇÃO. – É conveniente, para explicar as verdades da fé, apropriar os atributos essenciais às Pessoas.
Pois, embora a Trindade das Pessoas não possa ser provada demonstrativamente, como vimos, convém
entretanto que seja declarada por certas noções mais manifestas. Ora, os atributos essenciais das
Pessoas nos são mais manifestos, pela razão, do que as próprias; porque, pelas criaturas, das quais
temos conhecimento, podemos com certeza chegar ao conhecimento das propriedades essenciais; não,
porém, ao das propriedades pessoais, como vimos. Assim, pois, como recorremos à semelhança de
vestígio ou de imagem, que descobrimos nas criaturas, para a manifestação das Pessoas divinas, assim
também, para a dos atributos essenciais. E a esta manifestação das Pessoas pelos atributos essenciais se
chama apropriação.
Ora, as Pessoas divinas podem ser manifestadas pelos atributos essenciais, de dois modos. De um
modo, por via de semelhança; e assim, os atributos pertencentes ao intelecto apropriam-se ao Filho,
que procede ao modo do intelecto, como Verbo. De um outro modo, por dissemelhança; assim, o poder
é apropriado ao Pai, como diz Agostinho, porque de ordinário nossos pais tornam-se fracos na velhice, o
que não devemos pensar de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os atributos essenciais não os apropriamos às Pessoas de
modo a os considerar próprios delas; mas para os manifestar por via de semelhança ou dissemelhança,
como vimos. Donde se não segue nenhum erro para a fé; ao contrário, melhor se manifesta assim a
verdade.

RESPOSTA À SEGUNDA. – Se os atributos essenciais se apropriassem às Pessoas de modo que lhes
fossem próprios, seguir-se-ia, que uma estaria para a outra na relação de forma. O que refuta
Agostinho, mostrando que o Pai não é sábio pela sabedoria que gerou, como se só o Filho fosse
sabedoria; de modo que o Pai só possa chamar-se sabedoria simultaneamente com o Filho, e não,
separado deste. Ora, a verdade é que o Filho se chama sabedoria do Pai porque é sabedoria pela
sabedoria do Pai. Pois, cada um é, por si mesmo, sabedoria, e ambos simultaneamente são uma só
sabedoria. Por onde, o pai não é sábio pela sabedoria que gerou, mas pela sua sabedoria essencial.

RESPOSTA À TERCEIRA. – Embora o atributo essencial, na sua noção própria, seja anterior à Pessoa;
segundo o modo de inteligir, contudo, em razão de ser apropriado, nada impede seja o próprio da
Pessoa anterior ao apropriado. Assim como a cor é posterior ao corpo enquanto corpo, mas é
naturalmente anterior ao corpo branco, enquanto branco.

## Art. 8 — Se os nomes essenciais são convenientemente atribuídos ou apropriados às Pessoas pelos santos doutores.
(I Sent., dist. XIV, exposit. litt.; dist. XXXI, q. 2, a. 1; q. 3, a. 1; dist. XXXIV, q. 2; dist. XXXVII q. 1, a. 3, ad 5;
De Verit., q. 1, a. 7; a. 3; ad Rom., cap. XI, lect. V; II ad Cor., cap. XIII, lect. III).
O oitavo discute-se assim. – Parece que os nomes essenciais são inconvenientemente atribuídos ou
apropriados às Pessoas pelos santos Doutores.

1. – Pois, Hilário diz: A eternidade está no Pai; a beleza, na Imagem; o uso, no Dom. Com cujas palavras
introduz três nomes próprios das Pessoas, a saber: o de Pai, o de Imagem, próprio ao Filho, como se
disse; e o de Dom, próprio ao Espírito Santo, como se demonstrou. E introduz também três apropriados;
pois, a eternidade a apropria ao Pai; a beleza, ao Filho; o uso, ao Espírito Santo. E parece que
irracionavelmente. Porque a eternidade implica a duração da existência; a beleza, por seu lado, é o
princípio do existir; e o usorespeita à operação. Ora, a essência e a operação não vemos que sejam
apropriadas a nenhuma das Pessoas. Logo, parecem inconvenientes estes apropriados às Pessoas.

2. Demais. – Diz Agostinho: No Pai está a unidade; no Filho, a igualdade; no Espírito Santo, a combinação
da unidade e da igualdade. E parece que inconvenientemente. Pois, uma Pessoa não é formalmente
denominada por aquilo que se apropria a outra; assim, o Pai não é sábio por sabedoria gerada, como se
disse. Mas no mesmo lugar acrescenta: Todas essas três coisas são uma só por causa do Pai; todas
iguais, por causa do Filho; todas conexas, por causa do Espírito Santo. Logo, não se apropriam
convenientemente às Pessoas.

3. Ainda. – Segundo Agostinho, ao Pai se atribui o poder; ao Filho, a sabedoria; ao Espírito Santo, a
bondade. Mas, isto parece inadmissível. Assim, a virtude é própria do poder; e, entretanto, a Escritura a
considera propriedade do Filho, quando diz (1 Cor 1, 24): Cristo, virtude de Deus; e também do Espírito
Santo, segundo o lugar (Lc 6, 19): Saía dele uma virtude que curava a todos. Logo, o poder não deve ser
apropriado ao Pai.

4. Ainda. – Agostinho diz: Não se devem compreender indiscriminadamente as palavras do Apóstolo –
dele, por ele e nele, pois, diz – dele, por causa do Pai; por ele, por causa do Filho; nele, por causa do
Espírito Santo. Mas isto parece inconvenientemente dito. Pois, o dizer – nele – parece importar a
relação de causa final, que é a primeira das causas. Logo, essa relação causal deveria ser apropriada ao
Pai, que é princípio sem principio.

5. Ainda. – A verdade aparece na Escritura como apropriada ao Filho (Jo 16, 6): Eu sou o caminho e a
verdade e a vida. E semelhantemente, o livro da vida, segundo o salmo (Sl 39, 8): Na cabeceira do livro
está escrito de mim; o que a Glosa comenta: i. é, junto do Pai, que é a minha cabeça. Do mesmo modo,
a expressão – Aquele que é; pois, aquilo da Escritura (Is 65, 1) – Eu me dirijo às nações, diz a Glosa: Fala
o Filho, que disse a Moisés: Eu sou quem sou. Ora, parece que esses atributos são considerados próprios
ao Filho e não, apropriados. Pois a verdade,segundo Agostinho, é a suma semelhança do princípio, sem
nenhuma dissemelhança; e portanto parece que propriamente convém ao Filho, que tem princípio.
Também o ser livro da vida parece-lhe próprio, por significar um ser, de outro, porque todo livro é es-
crito por alguém. E enfim, a expressão – Que é – parece própria ao Filho. Porque, se pelas palavras de
Moisés – Eu sou quem sou – é a Trindade quem fala, ele poderia também ter dito: Aquele que é o Pai, o
Filho e o Espírito Santo mandou-me para vós.Logo, também a seguir poderia dizer: Aquele que é o Pai, o
Filho e o Espírito Santo mandou-me para vós, declarando uma Pessoa certa. Ora, isto é falso, pois
nenhuma Pessoa é Pai e Filho e Espírito Santo. Logo, não pode a referida expressão ser comum à
Trindade, mas é própria do Filho.

SOLUÇÃO. – O nosso intelecto, que parte das criaturas para chegar ao conhecimento de Deus, deve
considerá-lo do modo pelo qual as considera.Ora, o exame de qualquer criatura faz-nos descobrir nelas
quatro coisas, na ordem seguinte. Primeira, que, considerada absolutamente, é um ser. Segunda, que se
manifesta como una. Terceira, que é dotada de virtude operativa e causal. Quarta, que tem relação com
os seus efeitos. Donde o aplicarmos a Deus essa quádrupla consideração.
Por onde, se do primeiro modo considerarmos Deus absolutamente, no seu ser mesmo, então a
apropriação de Hilário significa que a eternidade é apropriada ao Pai; a beleza ao Filho; o uso, ao
Espírito Santo.
Pois eternidade, enquanto significa o ser não principiado, tem semelhança com a propriedade do Pai, de
ser princípio sem princípio.
A beleza ou especiosidade tem semelhança com os próprios do Filho. Pois, três condições exige a beleza.
Primeiro, a integridade ou perfeição; donde vem, que coisas mesquinhas são por isso mesmo feias.
Segundo, a proporção devida ou consonância. E, por fim, o esplendor, que nos leva a chamarmos belas
às coisas de colorido brilhante. – Ora, pela primeira condição, a beleza tem semelhança com a proprie-
dade do Filho, por trazer o Filho em si, verdadeira e perfeitamente, a natureza do Pai. Por isso,
Agostinho, indicando-o, diz na sua exposição:Em quem, i. é, no Filho, está à suma e primeira vida, etc.
Pela segunda ela convém com a propriedade do Filho, como imagem expressa do Pai. Por isso
chamamos bela à imagem, que representa perfeitamente o seu objeto, embora feio. Ao que
aludeAgostinho quando diz: Em quem há tão grande conveniência, e a primeira igualdade, etc..
Finalmente, pela terceira, convém com a propriedade do Filho, enquanto Verbo, que é a luz e esplendor
do intelecto, no dizer de Damasceno. E a isto alude Agostinho, quando diz: Como Verbo perfeito a quem
nada falta, e como arte de Deus onipotente, etc.
Quanto ao uso, ele tem semelhança com as propriedades do Espírito Santo, tomando-se, o uso em
sentido lato, segundo o qual usar compreende em si também o gozar; pois, usar é submeter alguma
coisa ao império da nossa vontade; e gozar é usar com prazer, como diz Agostinho. Ora, o uso pelo qual
o Pai e o Filho mutuamente se gozam convém com a propriedade do Espírito Santo, enquanto Amor. E a
isso se refere Agostinho: Aquela dileção, aquele prazer, aquela felicidade ou beatitude é chamada uso
por ele. Quanto ao uso, pelo qual gozamos de Deus, ele tem semelhança com a propriedade do Espírito
Santo, enquanto Dom. E isso o mostra Agostinho quando diz: Na Trindade é o Espírito Santo a suavidade
do Gerador e do Gerado, derramando-se sobre nós com grande largueza e fertilidade.
Por onde, é claro que a eternidade, a especiosidade e o uso se atribuem ou apropriam às Pessoas; não
porém a essência ou a operação. Porque, sendo por natureza comum, não têm nenhuma semelhança
com as propriedades das Pessoas.
Pela segunda consideração, vemos que Deus é uno. E assim, Agostinho apropria a unidade ao Pai; a
igualdade, ao Filho; a concórdia ou o nexo, ao Espírito Santo. O que tudo manifestamente importa a
unidade, mas de modo diferente. Assim, a unidade tem sentido absoluto, nada mais pressupondo. Por
isso se apropria ao Pai que não pressupõe nenhuma outra pessoa, por ser princípio sem princípio.
Porém a igualdade importa a unidade em relação a outro ser; pois, é igual a outro o ser que tem a
mesma quantidade que ele.Por isso a igualdade se apropria ao Filho, princípio com princípio. O nexo,
enfim, implica unidade de dois seres. Por isso se apropria ao Espírito Santo, enquanto o Espírito Santo
procede das duas Pessoas.
Por onde também podemos entender o dito de Agostinho, que os três são um, por causa do Pai; iguais,
por causa do Filho; conexos, por causa do Espírito Santo. Pois, é claro que uma atribuição pertence
primariamente ao ser ao qual primeiro convém; assim, dizemos que todos os seres inferiores vivem,
pela alma vegetativa, na qual primeiramente se encontra a essência da vida deles. A unidade, por seu
lado, imediatamente existe na Pessoa do Pai, mesmo se, por impossível, fossem removidas as outras
Pessoas. Por isso as outras Pessoas recebem do Pai a unidade. Mas, removidas elas, não existe no Pai a
igualdade, a qual imediatamente aparece, reposto o Filho. Por isso, todos se consideram iguais por
causa do Filho; não que o Filho seja princípio da igualdade do Pai; mas que, se não fosse o Filho igual ao
Pai, este não poderia chamar-se igual. Pois, a sua igualdade é primeiramente considerada em relação ao
Filho; assim, mesmo o ser o Espírito Santo igual ao Pai vem do Filho. Semelhantemente, excluído o
Espírito Santo, nexo das outras duas Pessoas, não poderíamos compreender a unidade de ligação entre
o Pai e o Filho. Por isso que são conexos pelo Espírito Santo; pois, posto o Espírito Santo,
compreendemos porque o Pai e o Filho podem chamar-se conexos.
Segundo, porém, o terceiro ponto de vista, pelo qual consideramos em Deus a virtude suficiente para
causar, tem lugar uma terceira apropriação, a saber, a do poder, da sabedoria e da bondade. Essa
apropriação se funda na idéia de semelhança, se levarmos em conta a realidade das divinas pessoas; e
na idéia de dissemelhança, se levarmos em conta a realidade das criaturas. Assim, o poder tem a
natureza de princípio, e por isso tem semelhança com o Pai celeste, princípio de toda divindade. Mas
falta, por vezes, ao pai humano, por causa da velhice. A sabedoria, por sua vez, tem semelhança com o
Filho celeste, como Verbo, que nada mais é do que o conceito da sabedoria. Falta, porém, às vezes aos
filhos dos homens, quando ainda em tenra idade. Por fim, abondade, razão e objeto do amor, têm
semelhança com o Espírito divino, que é Amor. Mas parece repugnar ao espírito terreno, por importar
um certo impulso violento, conforme diz a Escritura (Is 25, 4): O espírito dos robustos é como um torve-
linho que impele uma parede. Quanto à virtude, ela se apropria ao Filho e ao Espírito Santo, não no
sentido em que chamamos virtude à potência mesma de um ser, mas no sentido em que às vezes
chamamos virtude ao que resulta da potência desse ser, quando dizemos que um ato virtuoso é a
virtude de um agente.
Finalmente, o quarto ponto de vista, pelo qual consideramos a Deus em relação aos seus efeitos, tem
lugar a apropriação de quem, por quem e em quem. Pois, a preposição de importa por vezes a relação
de causa material, o que não é possível em Deus. Outras vezes, porém, importa relação de causa
eficiente; a qual convém a Deus em razão da sua potência ativa; e por isso se apropria ao pai, do mesmo
modo que a potência. Quanto à preposição por, ela designa às vezes a causa média (instrumental),
como quando dizemos que o ferreiro trabalha por meio do martelo. E assim, às vezes a preposição por
não é um apropriado, mas próprio do Filho, segundo aquilo da Escritura (Jo 1, 3): Todas as coisas foram
feitas por ele; não que o Filho seja instrumento, mas por ser em si princípio com princípio. Outras vezes,
porém, a preposição por designa uma relação de forma pela qual o agente opera; como quando
dizemos que o artífice opera pela arte. Por onde, como a sabedoria e a arte se apropriam ao Filho, assim
também a locução por quem. Enfim, a preposição em denota propriamente a relação de continente.
Ora, Deus contém as coisas de duplo modo. De um modo, pelas semelhanças delas; no sentido em que
dizemos que as coisas estão em Deus por estarem na ciência dele. E assim a locução – nele mesmo, deve
apropriar-se ao Filho. Mas, de outro modo, as coisas estão contidas em Deus, enquanto Deus pela sua
bondade as conserva e governa, conduzindo-as ao fim conveniente. E assim a locução em quem se
apropria, como a bondade, ao Espírito Santo. Nem é necessário, que a relação de causa final, embora
seja esta causa a primeira das causas, se aproprie ao Pai, princípio sem princípio. Porque as Pessoas
divinas, das quais o Pai é o princípio, não procedem como tendendo a um fim, pois cada uma delas é o
último fim; mas por uma processão natural, considerada como pertencente essencialmente, antes, à
potência natural.
Quanto ao que se objeta, concernente a outros pontos, devemos responder, que a verdade,
pertencendo ao intelecto, como já vimos, apropria-se ao Filho, embora não lhe seja própria. Pois a
verdade, como dissemos, pode serconsiderada em relação ao intelecto ou ao objeto. Pois, assim como o
intelecto e o objeto, essencialmente considerados, são realidades essenciais e não pessoais, assim
também a verdade. Ora; a definição aduzida de Agostinho, é da verdade enquanto apropriada ao Filho.
Quanto ao livro da vida, ele importa diretamente o conhecimento; mas, indiretamente, a vida, pois é,
como dissemos, o conhecimento que Deus tem dos que devem alcançar a vida eterna. Por isso se
apropria ao Filho, embora a vida se aproprie ao Espírito Santo, por importar um certo movimento
interior,convindo assim com o próprio do Espírito Santo, como Amor. Mas ser escrito por outro não é da
essência do livro, como tal, mas enquanto produto da arte. Por isso não implica origem, nem é nada de
pessoal, mas, apropriado à Pessoa. Quanto à expressão – Que é, ela é apropriada à Pessoa do Filho, não
na noção própria dessa expressão, mas como adjunto; a saber, enquanto que a fala de Deus a Moisés
prefigurava a liberdade do gênero humano, operada pelo Filho. Contudo, tomadorelativamente, poderia
o que referir-se, às vezes, à Pessoa do Filho e então seria tomado em sentido pessoal como por
exemplo, se disséssemos: O Filho é o gerado que é, do mesmo modo que o Deus gerado é pessoal. Mas
tomado como indefinido, o sentido é essencial. Embora o pronome – este, gramaticalmente falando,
diga respeito a uma pessoa certa, todavia qualquer coisa susceptível de designação pode,
gramaticalmente falando, ser designada por esse pronome, se bem não seja, por natureza, pessoa;
assim, dizemos esta pedra e este asno. Por onde, a essência divina, gramaticalmente falando, enquanto
significa e suposta pelo nome de Deus, pode ser designada pelo pronome este, conforme a Escritura (Ex
15, 2): Este é o meu Deus e eu o glorificarei.