# Questão 16: Da Verdade
Tendo a ciência por objeto a verdade, depois da consideração da ciência de Deus, devemos tratar da
verdade, sobre a qual discutem-se oito artigos:

## Art. 1 — Se a verdade existe somente no intelecto, ou, antes, nas coisas.
I Sent., dist. XIX, q. 5, a. 1; Cont. Gent., cap. LX; De Verit., q. 1, a. 2; I Periherm., lect. III; VI Metaph., lect.

IV.
O primeiro discute-se assim. — Parece que a verdade não está somente no intelecto, mas, antes, nas
coisas.

1. — Pois, Agostinhoreprova esta definição da verdade: A verdade é aquilo que é visto; porque, então,
as pedras, ocultas no mais profundo seio da terra, não seriam verdadeiras pedras, porque não se vêem.
Também reprova esta outra: A verdade é tal que é vista pelo sujeito, se quiser e puder conhecê-la; pois,
se assim fosse nenhuma verdade existiria, se ninguém pudesse conhecê-la. E define assim a verdade: A
verdade é o que é. Donde se conclui, que a verdade está nas coisas e, não, no intelecto.

2. Demais. — Tudo o que é verdadeiro o é pela verdade. Se, pois, a verdade existe somente no intelecto,
nada será verdadeiro senão na medida em que for inteligido; erro dos antigos Filósofos, como se vê em
Aristóteles, dizendo ser verdadeiro tudo o que é visto. Donde se segue que os contraditórios são
simultaneamente considerados verdadeiros, por diversos.

3. Demais. — A causa de ser uma coisa o que é, é essa coisa ainda em maior grau, como diz Aristóteles.
Mas, conforme uma coisa é ou não é, assim a opinião ou a oração é verdadeira ou falsa, conforme o
Filósofo. Logo, a verdade está, mais nas coisas, que no intelecto.
Mas, em contrário, diz o Filósofo: O verdadeiro e o falso não estão nas coisas, mas no intelecto.

SOLUÇÃO. — Assim como o bem designa o termo para o qual tende o apetite, assim, a verdade, o termo
para o qual tende o intelecto. Ora, a diferença entre o apetite e o intelecto, ou qualquer conhecimento,
está em que o conhecimento supõe o objeto conhecido, no conhecente, ao passo que o apetite supõe
que o apetente se inclina para a coisa mesma apetecida. E, assim, o termo do apetite, que é o bem, está
na coisa apetecível, enquanto o termo do conhecimento, que é a verdade, está no próprio intelecto.
Ora, o bem está na coisa, enquanto esta se ordena para o apetite; por isso, a noção da bondade deriva
da coisa apetecível para o apetite, sendo, assim, a razão por que chamamos bom ao apetite do bem. Do
mesmo modo, a verdade, estando no intelecto, enquanto este se conforma com a coisa intelegida,
necessariamente a noção da verdade deriva para essa coisa, de maneira que também esta se chama
verdadeira, enquanto se ordena, de certo modo, para o intelecto.
Ora, a coisa inteligida pode se ordenar para um certo intelecto ou em si, ou por acidente. Em si, ordena-
se para o intelecto do qual o seu ser depende; por acidente, a um intelecto do qual é cognoscível. Como
se dissermos que a casa depende, em si, do intelecto do artífice; e, por acidente, é relativa a um
intelecto do qual não depende. Ora, julgamos uma coisa fundada, não no que ela existe por acidente,
mas, no que lhe pertence por essência. Por onde, uma coisa é considerada verdadeira, absolutamente
falando, quando se ordena para o intelecto, do qual depende. Por isso, são chamadas verdadeiras as
coisas artificiais, em ordem ao nosso intelecto; assim, é chamada verdadeira a casa resultante da
semelhança da forma, existente na mente do artífice; e verdadeira a oração, enquanto procede do
intelecto verdadeiro. Semelhantemente, as coisas naturais chamam-se verdadeiras, enquanto realizam a
semelhança das espécies existentes na mente divina; assim, chamamos verdadeira à pedra que realiza a
natureza própria da pedra, preexistente no conceito do intelecto divino. Por onde, a verdade,
principalmente, existe no intelecto, e secundariamente, nas coisas, enquanto estas dependem do
intelecto, como do princípio.
E, por onde a verdade é conhecida de modos diversos. Assim, Agostinho diz: A verdade é o meio pelo
qual se manifesta aquilo que é. E Hilário: A verdade é declarativa e manifestativa do ser. O que é próprio
dela, enquanto existente no intelecto. Mas, pertence à verdade da coisa, em ordem ao intelecto, a
seguinte definição de Agostinho no mesmo lugar: A verdade é a suma semelhança do princípio, a qual
não tem nenhuma dessemelhança. E esta definição de Anselmo: A verdade é a retidão, perceptível só da
mente; pois, reto é o que concorda com o princípio. E uma outra, de Avicena: A verdade de uma coisa é
a propriedade do ser que lhe foi atribuído.
Quando, porém, dizemos que a verdade é a adequação da coisa com o intelecto, essa definição pode
convir a um e outro modo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho refere-se à verdade da coisa; e exclui dessa
noção da verdade a comparação com o nosso intelecto. Pois, de toda definição se exclui o que lhe é
acidental.

RESPOSTA À SEGUNDA. — Os antigos filósofos não diziam que as espécies das coisas naturais
procediam de algum intelecto, mas, que provinham do acaso. E por considerarem que a verdade implica
relação com o intelecto, viam-se forçados a constituir a verdade das coisas em dependência do nosso
intelecto; donde, as incongruências assinaladas pelo Filósofo, no lugar citado. Mas, tais incongruências
desaparecem, se admitirmos que a verdade das coisas consiste na relação com o intelecto divino.

RESPOSTA À TERCEIRA. — Embora a verdade do nosso intelecto seja causada pela realidade, não é
necessário, que a noção dela se encontre primariamente na realidade. Assim como a noção da saúde
não se encontra, primeiro, no remédio, que no animal; pois, é a virtude e não a sanidade do remédio, a
causa da saúde, que não é um agente unívoco. Semelhantemente, não é a verdade da coisa, mas o seu
ser, que causa a verdade do intelecto. Por isso, o Filósofo diz, no lugar citado, que a opinião e a oração é
verdadeira, porque a realidade existe, não porque seja verdadeira.

## Art. 2 — Se a verdade existe somente no intelecto que compõe e divide.
I Sent., dist. XIX, q. 5, a. 1, ad 7; I Cont. Gent., cap. LIX; De Verit., q. 1, a. 3, 9; I Periherm., lect. III; VI
Metaph., lect. IV; III De Anima, lect. XI.
O segundo discute-se assim. — Parece que a verdade não existe somente no intelecto que compõe e
divide.

1. — Pois, o Filósofodiz que, assim como os sentidos dos sensíveis próprios são sempre verdadeiros,
assim também o intelecto, que apreende a quididade. Ora, a composição e a divisão não existem, nem
no sentido, nem no intelecto, que apreende a quididade. Logo, a verdade não existe somente no
intelecto que compõe e divide.

2. Demais. — Isaquediz que a verdade é a adequação da coisa com o intelecto. Ora, como o intelecto
das coisas complexas pode-se-lhes adequar, assim também o das incomplexas, e, ainda, o sentido, que
recebe a coisa como ela é. Logo, a verdade não está somente na composição e na divisão do intelecto.
Mas, em contrário, diz o Filósofo, que, dos seres simples e da quididade, não há verdade, nem no
intelecto, nem nas coisas.

SOLUÇÃO. — A verdade, como dissemos, na sua noção primária, existe no intelecto. Pois, sendo toda
realidade verdadeira, na medida em que tem a forma própria da sua natureza, necessariamente o
intelecto conhecente será verdadeiro, na medida em que tem semelhança com a coisa conhecida, que é
a forma do mesmo enquanto conhecente. E, por isso, a verdade é definida como a conformidade da
coisa com a inteligência. Donde, conhecer tal conformidade é conhecer a verdade. Ora, esta o sentido
de modo nenhum a conhece. Pois, embora a vista, por exemplo, tenha a semelhança do visível,
contudo, não conhece a relação existente entre a coisa vista e aquilo que apreende dessa coisa. O
intelecto, porém, pode conhecer a sua conformidade com a coisa inteligível; contudo, não apreende
essa conformidade quando conhece a essência de uma coisa. Mas, quando julga estar a coisa de
conformidade com a forma que dela apreendeu, então somente conhece e afirma a verdade. E isso o
intelecto faz, compondo e dividindo. Pois, em toda proposição, o intelecto aplica alguma forma expressa
pelo predicado, a alguma coisa, expressa pelo sujeito ou dela remove. Por onde, bem vemos que o
sentido é verdadeiro, em relação à coisa que percebe, como também o é o intelecto, quando conhece a
essência, sem que por isso conheça ou diga a verdade. E o mesmo se dá com as vozes incomplexas. A
verdade, pois, pode existir no sentido, ou no intelecto, que conhece a essência, como numa coisa
verdadeira; não, porém, como o conhecido no conhecente, que é o que implica o nome de verdadeiro.
Ora, a perfeição do intelecto é a verdade enquanto conhecida. Logo, propriamente falando, a verdade
está no intelecto que compõe e divide, não porém, no sentido nem no intelecto, que conhece
a essência.
Donde se deduzem claras as RESPOSTAS ÀS OBJEÇÕES.

## Art. 3 — Se a verdade e o ser se convertem.
I Sent., dist. VIII, q. 1, a. 3; dist. XIX, q. 5, a. 1, ad 3, 7; De Verit., q. 3, a. 1; 2, ad 1.
O terceiro discute-se assim. — Parece que a verdade e o ser não se convertem.

1. — Pois, a verdade existe, propriamente, no intelecto, como se disse; o ser, porém, existe,
propriamente, nas coisas. Logo, não se convertem.

2. Demais. — O que se estende ao ser e ao não-ser não se converte com o ser; ora, a verdade estende-
se ao ser e ao não ser, pois, é verdade que o que é, é e o que não é, não é. Logo, a verdade e o ser não
se convertem.

3. Demais. — Os seres que se relacionam por anterioridade e posterioridade, não se convertem uns nos
outros. Ora, é certo que a verdade é anterior ao ser, pois, este não é inteligido, senão sob a noção da
verdade. Logo, não são conversíveis.
Mas, em contrário, diz o Filósofoque a mesma é a disposição das coisas, no ser e na verdade.

SOLUÇÃO. — Como o bem tem a natureza de apetecível, assim, a verdade se ordena ao conhecimento.
Ora, cada ser é cognoscível na medida em que é, e, por isso, diz Aristóteles: Que a alma é, de certo
modo, tudo, quanto ao sentido e ao intelecto. E, portanto, assim como o bem se converte com o ser,
assim também a verdade. Mas, assim como o bem acrescenta ao ser a noção de apetibilidade, assim a
verdade, a relação com o intelecto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A verdade está nas coisas e no intelecto, como
dissemos. Mas, a verdade existente nas coisas converte-se substancialmente com o ser; a que, porém,
existe no intelecto converte-se com o ser, como o manifestativo com o manifestado. Pois, isto é da
essência da verdade, como se disse. Embora possamos dizer, que também o ser está nas coisas e no
intelecto, como a verdade; embora a verdade esteja, principalmente, no intelecto, ao passo que o ser
está, principalmente, nas coisas. E isto é assim, por haver, entre a verdade e o ser, uma diferença de
razão.

RESPOSTA À SEGUNDA. — O não-ser não tem por onde seja conhecido; mas o é enquanto o intelecto o
torna conhecível. Por onde, a verdade funda-se no ser, ao passo que o não ser é um ente de razão, isto
é, apreendido pela razão.

RESPOSTA À TERCEIRA. — O dizer-se que o ser não pode ser apreendido, sem a noção da verdade,
pode-se entender duplamente. De um modo, significa que não podemos apreendê-lo, sem que a noção
da verdade acompanhe essa apreensão; e, neste sentido, a locução é verdadeira. De outro modo,
poderíamos compreendê-la, como significando que não podemos apreender o ser sem apreendermos a
noção da verdade, o que é falso. A verdade, porém, não pode ser apreendida sem apreendermos a
noção do ser, porque este se inclui na noção daquela. Seria isto o mesmo que compararmos o inteligível
com o ser, que, não podendo ser inteligido sem ser inteligível, pode ser inteligido sem que seja inteligida
a sua inteligibilidade. Semelhantemente, o ser inteligido é verdadeiro; contudo, não é inteligindo o ser
que inteligimos o verdadeiro.

## Art. 4 — Se o bem é racionalmente anterior à verdade.
De Verit., q. 21, a. 3; Hebr., cap. XI, lect. I.
O quarto discute-se assim. — Parece que o bem é racionalmente anterior à verdade.

1. — Pois, o que é mais universal é, na razão, anterior, como se lê em Aristóteles. Ora, o bem é mais
universal que a verdade, que é um certo bem do intelecto. Logo, o bem é, racionalmente, anterior à
verdade.

2. Demais. — O bem está nas coisas, a verdade, porém, na composição e divisão do intelecto, como se
disse. Ora, as coisas existentes realmente são anteriores às existentes no intelecto. Logo, o bem é
racionalmente anterior à verdade.

3. Demais. — A verdade é uma espécie de virtude, como se lê em Aristóteles. Ora, a virtude está incluída
no bem, pois, ela é uma boa qualidade da mente, como diz Agostinho. Logo, o bem é anterior à verdade.
Mas, em contrário, diz o que existe em muitos é racionalmente anterior. Ora, a verdade existe em certas
coisas, nas quais não existe o bem, a saber, nas matemáticas. Logo, a verdade é anterior ao bem.

SOLUÇÃO. — Embora o bem e a verdade se convertam no ser, pelo suposto, contudo diferem pela
razão. E assim, a verdade, absolutamente falando, é anterior ao bem, o que se evidencia pelas duas
considerações seguintes. Primeiro, porque a verdade está mais próxima do ser, e este é anterior ao
bem; pois, a verdade diz respeito ao próprio ser, simples e imediatamente, ao passo que a noção do
bem é consecutiva ao ser, enquanto este é, de certo modo, perfeito, pois é, como tal, apetecível.
Segundo, porque o conhecimento naturalmente precede ao apetite; por onde, a verdade, dizendo
respeito ao conhecimento, e o bem, ao apetite, a verdade será racionalmente anterior ao bem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A vontade e o intelecto mutuamente se incluem; pois, o
intelecto intelige a vontade, e a vontade quer que o intelecto intelija. Assim, entre as coisas ordenadas
ao objeto da vontade, estão contidas também as que pertencem ao intelecto, e reciprocamente. Por
onde, na ordem das coisas apetecíveis, o bem comporta-se como universal e a verdade, como
particular; mas, na ordem dos inteligíveis dá-se o inverso. Logo, por ser a verdade um certo bem, segue-
se que este é anterior, na ordem dos apetecíveis; não, porém, que seja anterior, absolutamente.

RESPOSTA À SEGUNDA. — É anterior, na razão, o que em primeiro lugar cai sob a apreensão do
intelecto. Ora, o intelecto, em primeiro lugar, apreende o ser em si; em segundo, a sua intelecção do
ser; em terceiro, a sua apetência do ser. Donde, em primeiro lugar está a noção do ser; em segundo, a
de verdade; em terceiro, a do bem, embora o bem esteja nas coisas.

RESPOSTA À TERCEIRA OBJEÇÃO. — A verdade, considerada como virtude, não é a verdade comum,
mas uma certa verdade, pela qual o homem se mostra como é, nas palavras e obras. A verdade da vida é
aquela pela qual o homem, na sua vida, realiza o fim para o qual foi ordenado pelo intelecto divino; e,
deste modo, também se disse que a verdade existe em outras coisas. A verdade da justiça é aquela pela
qual o homem atribui a outrem o que lhe deve, segundo a ordem das leis. Ora, destas verdades
particulares não se pode passar para a verdade geral.

## Art. 5 — Se Deus é a verdade.
Ia IIae, q. 3, a. 7; I Sent., dist. XIX, q. 5, a. 1; I Cont. Gent., cap. LIX sqq; III, cap. LI.
O quinto discute-se assim. — Parece que Deus não é a verdade.

1. — Pois, a verdade existe na composição e divisão do intelecto. Ora, em Deus, não há composição nem
divisão. Logo, não há verdade.

2. Demais. — A verdade, segundo Agostinho, é semelhança de princípio. Ora, não há em Deus
semelhança de princípio. Logo, em Deus não há verdade.

3. Demais. — Tudo o que dissemos de Deus dizemo-lo como da causa primeira universal, porque o ser
de Deus é a causa de todo o ser, e a sua bondade, a causa de todo o bem. Se, pois, há em Deus verdade,
tudo o que é verdadeiro sê-lo-á por ele. Ora, é verdade que alguns pecam. Logo, isso provirá de Deus, o
que é claramente falso.
Mas, em contrário, a Escritura (Jo 14, 6): Eu sou o caminho, a verdade e a vida.

SOLUÇÃO. — Conforme dissemos, a verdade existe no intelecto, que apreende a realidade como ela é;
e, na realidade, enquanto tem o ser conformável com o intelecto. Ora, isto existe sobretudo em Deus.
Pois, o seu ser não só é conforme com o seu intelecto, mas também é o seu próprio inteligir; e o seu
inteligir é a medida e a causa de qualquer outro ser e de qualquer outro intelecto; e ele mesmo é o seu
ser e o seu inteligir. Donde se segue, que não somente há nele verdade, mas também que é a mesma
suma e primeira verdade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora no intelecto divino não haja composição nem
divisão, contudo, ele julga de tudo e conhece todos os complexos, pela sua simples inteligência; e assim
há verdade no seu intelecto.

RESPOSTA À SEGUNDA. — A verdade de nosso intelecto está em conformar-se com o seu princípio, isto
é, com as coisas de que tira o conhecimento. E também a verdade das coisas consiste em conformarem-
se com o seu princípio, isto é, com o intelecto divino. Ora, propriamente falando, não se pode dizer da
verdade divina, a não ser, talvez, enquanto a verdade é própria do Filho, que tem princípio. Mas, se nos
referimos à verdade essencialmente dita, a conformidade com o princípio não tem lugar, senão
resolvendo a afirmativa na negativa, assim, quando dizemos que o Pai é por si, porque não é por outro.
Semelhantemente, a verdade divina pode ser considerada semelhança de princípio, enquanto o seu ser
não é dissemelhante do seu intelecto.

RESPOSTA À TERCEIRA. — O não ser e as privações não têm a verdade por si mesmas, mas só, pela
apreensão do intelecto. Ora, toda apreensão do intelecto provém de Deus. Donde, tudo o que houver
de verdade na afirmação — é verdade que este fornicou — vem de Deus. Mas quem objetar: logo, vem
de Deus a fornicação deste — cometerá um sofisma de acidente.

## Art. 6 — Se há uma só verdade pela qual todas as coisas são verdadeiras.
I Sent., dist. XIX, q. 5, a. 2; III Cont. Gent., cap. XLVII; De Verit., q. 1, a. 4; q. 21, a. 4 ad 5; q. 27, a. 1 ad 7;
Quodl., X, q. 4, a. 1.
O sexto discute-se assim. — Parece que uma só é a verdade pela qual todas as coisas são verdadeiras.

1. — Pois, segundo Agostinho, nada é maior que a mente humana, exceto Deus. Ora, a verdade é maior
que a mente humana; do contrário esta julgaria da verdade, ao passo que, na realidade, ela tudo julga
segundo a verdade e não, segundo a si mesma. Logo, só Deus é a verdade, e portanto, não há outra
verdade fora dele.

2. Demais. — Anselmo diz, que assim como o tempo está para as coisas temporais, assim, a verdade,
para as coisas verdadeiras. Ora, um só é o tempo de todas as coisas temporais. Logo, uma só é a
verdade, pela qual todas as coisas são verdadeiras.
Mas, em contrário, a Escritura (Sl 11, 2): Vieram a menos as verdades entre os filhos dos homens.

SOLUÇÃO. — De certo modo, uma é a verdade pela qual todas as coisas são verdadeiras, e de certo
modo, não. Para evidenciá-lo devemos saber, que quando alguma coisa é predicada, univocamente, de
muitas, ela se encontra em qualquer destas, segundo a sua noção própria; assim, animal, em qualquer
espécie de animal. Mas, quando uma coisa se predica, analogicamente, de muitas, encontra-se, segundo
a noção própria, numa delas somente, da qual as outras tiram a sua denominação; assim, aplicamos o
vocábulo — são — ao animal, à urina e ao remédio. Não que a saúde exista somente no animal, mas
pela saúde deste é que o remédio se denomina são, porque a produz; e a urina, enquanto sinal da
saúde. E embora a saúde não exista no remédio, nem na urina, contudo, em ambos existe alguma coisa
pela qual um produz a saúde, e a outra a significa.
Ora, como dissemos, a verdade existe primariamente no intelecto e, posteriormente, nas coisas,
enquanto estas se ordenam ao intelecto divino. Se, portanto, considerarmos a verdade em sua noção
própria, enquanto existente no intelecto, então, em muitos intelectos criados, existem muitas verdades.
E também em um só e mesmo intelecto, conforme os vários objetos conhecidos. Donde o dizer a Glosa
àquilo da Escritura — Vieram a menos as verdades entre os filhos dos homens: assim como, da face de
um mesmo homem resultam várias imagens semelhantes no espelho, assim de uma mesma verdade
divina resultam muitas verdades. Se, porém, considerarmos a verdade enquanto existente nas coisas,
então estas são todas verdadeiras, em virtude de uma primeira verdade, à qual cada uma delas se
assemelha, segundo a sua entidade. E assim, embora muitas sejam as essências ou as formas das coisas,
uma só é a verdade do intelecto divino, em virtude da qual se denominam verdadeiras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A alma julga de todas as coisas, não segundo qualquer
verdade, mas, segundo a verdade primeira, enquanto esta nela se reflete, como num espelho, por meio
dos inteligíveis primeiros. Donde se segue, que a verdade primeira é maior que a alma. Contudo,
também a verdade criada, existente em nosso intelecto, é maior que a alma, não absolutamente, mas
de certo modo, enquanto é a perfeição dela; assim como também podemos dizer, que a ciência é maior
do que a alma. Mas, é verdade que nada de subsistente é maior que a mente racional, exceto Deus.

RESPOSTA À SEGUNDA. — O dito de Anselmo é exato, consideradas as coisas verdadeiras por
comparação como intelecto divino.

## Art. 7 — Se a verdade criada é eterna.
Supra, q. 10, a. 3 ad 3; I Sent., dist. XIX, q. 5, a. 3; II Contra Gent., cap. XXXV; III cap. LXXXII, LXXXIV; De
Verit., q. 1, a. 5; De Pot., q. 3, a. 17 ad 27.
O sétimo discute-se assim. — Parece que a verdade criada é eterna.
1 — Pois, Agostinho diz, que nada é mais eterno do que a noção do círculo, e que dois e três são cinco.
Ora, tais verdades são criadas. Logo, a verdade criada é eterna.

2. Demais. — Tudo o que existe sempre é eterno. Ora, os universais existem em toda a parte e sempre.
Logo, são eternos; e portanto também o é a verdade, em máximo grau universal.

3. Demais. — Do que é verdade, no presente, podemos dizer que sempre foi verdade que haveria de
ser. Ora, como a verdade da proposição, no presente, é uma verdade criada, assim também, a verdade
da proposição, no futuro. Logo, alguma verdade criada é eterna.

4. Demais. — Tudo o que não tem princípio nem fim é eterno. Ora, a verdade dos enunciáveis não tem
princípio nem fim. Porque se a verdade começou a existir, como antes não existisse, era verdadeiro que
não existia, e portanto a verdade existia em virtude de alguma verdade; e, assim, a verdade existia antes
de ter começado a existir. Semelhantemente, se dissermos que a verdade tem fim, segue-se que existe
depois de cessar de existir, pois, será verdade que não existe. Logo, a verdade é eterna.
Mas, em contrário, só Deus é eterno, como já se demonstrou.

SOLUÇÃO. — A verdade dos enunciáveis não é outra senão a do intelecto, pois, o enunciável existe no
intelecto e nos termos. Ora, enquanto no intelecto, tem a verdade por si mesmo. Mas, enquanto nos
termos, diz-se verdadeiro, por significar alguma verdade do intelecto, e não, por nenhuma verdade
existente nele próprio, como num sujeito; do mesmo modo que a urina se diz sã, não pela saúde, que
nela exista, mas, por significar a saúde do animal. Semelhantemente, como dissemos acima, as coisas se
chamam verdadeiras pela verdade do intelecto. Por onde, se nenhum intelecto fosse eterno, nenhuma
verdade sê-lo-ia; mas, porque só o intelecto divino é eterno, só nele a verdade tem a sua eternidade.
Nem daí resulta que algum outro ser, além de Deus, seja eterno; porque a verdade do intelecto divino é
o próprio Deus, como já demonstramos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As noções do círculo e que dois e três são cinco têm a
eternidade na mente divina.

RESPOSTA À SEGUNDA. — O existir alguma coisa, sempre e em toda a parte, pode se entender de dois
modos. De um modo, porque pode, por si, estender-se a todos os tempos e a todos os lugares; assim,
convém a Deus existir em toda a parte e sempre. De outro modo, por não ter em si motivo para se
determinar a algum lugar ou tempo; assim, uma se chama a matéria prima, não por ter uma forma,
como o homem, que é um pela unidade formal, mas, pela remoção de todas as formas determinantes.
E, deste modo, dizemos que todo universal existe em toda parte e sempre, por se abstraírem os
universais, do lugar e do tempo. Mas, daí não se segue que sejam eternos, a não ser em algum intelecto
eterno.

RESPOSTA À TERCEIRA. — O que agora existe foi futuro, antes de existir, porque pela sua causa havia de
existir. Por isso, supressa a causa, tal existência não mais se realizaria. Ora, só a causa primeira é eterna.
Donde, do que existe não se deduz que sempre foi verdadeiro o que haveria de existir, senão enquanto
essa existência futura dependia de causa sempiterna; e tal causa só é Deus.

RESPOSTA À QUARTA. — Não sendo eterno o nosso intelecto, também não é eterna a verdade dos
enunciáveis formados por nós, mas, começou em algum tempo. E, antes que tal verdade existisse, não
era verdadeiro dizer que não existia, senão em virtude do intelecto divino, no qual somente a verdade é
eterna. Mas, atualmente, é verdadeiro dizer que a verdade, antes, não existia. O que não é verdadeiro
senão pela verdade atualmente existente em nosso intelecto e não, por alguma verdade fundada no
real. Pois, a verdade de que se trata é uma verdade relativa ao não ser. Ora, o não ser não tira de si
mesmo a sua verdade mas, somente, do intelecto que o apreende. Logo, dizer-se que a verdade não
existia é verdadeiro, na medida em que lhe apreendemos o não ser, como lhe precedendo o ser.

## Art. 8 — Se a verdade é imutável.
I Sent., dist. XIX, q. 5, a. 3; De Verit., q. 1, art. 6.
O oitavo discute-se assim. — Parece que a verdade é imutável.

1. — Pois, diz Agostinho, que a verdade não é igual à mente, porque seria mutável como a mente.

2. Demais. — O que permanece, após todas as mutações, é imutável. Assim, a matéria prima é ingênita
e incorruptível, porque permanece, após todas as gerações e corrupções. Ora, a verdade permanece,
após todas as mutações, porque, após todas elas, é verdadeiro dizer-se, existir ou não existir. Logo, a
verdade é imutável.

3. Demais. — Se a verdade da enunciação muda, há de sobretudo mudar, com a mudança da realidade.
Ora, tal não se dá; pois, segundo Anselmo, a verdade é uma certa retidão, pela qual uma coisa realiza o
modo por que existe na mente divina. Ora, esta proposição — Sócrates está sentado — tira da mente
divina a significação deSócrates sentar-se — significação que permanece, mesmo que ele não esteja
sentado. Logo, a verdade da proposição de maneira nenhuma se muda.

4. Demais. — Onde existe a mesma causa existe o mesmo efeito. Ora, a mesma realidade é a causa da
verdade destas três proposições: Sócrates está sentado, estará sentado e esteve sentado. Logo, a
mesma é a verdade delas. Mas, necessariamente, uma dessas três proposições será a verdadeira, Logo,
a verdade delas permanece imutável e, pela mesma razão, a verdade de qualquer outra proposição.
Mas, em contrário, a Escritura (Sl 11, 2): Vieram a menos as verdades entre os filhos dos homens.

SOLUÇÃO. — Como já dissemos, a verdade, propriamente, só existe no intelecto. Pois, as coisas se
dizem verdadeiras pela verdade existente em algum intelecto; donde, a mutabilidade da verdade deve
ser considerada em dependência do intelecto. Ora, a verdade deste consiste na sua conformidade com
as coisas inteligidas, conformidade que pode variar de dois modos, assim como qualquer outra
semelhança, pela mutação de um dos extremos. Assim, de um modo, a verdade varia por parte do
intelecto, enquanto que da mesma coisa, existindo da mesma maneira, cada qual tem a sua opinião. De
outro modo, se a coisa mudar-se, fincando a opinião a mesma. E, de ambos os modos, a mutação se faz
do verdadeiro para o falso. Se, porém, existir algum intelecto, no qual não possa haver variação de
opiniões, ou a cujo conhecimento nenhuma coisa possa escapar, nesse, a verdade é imutável. Ora, tal é
o intelecto divino, como resulta do que vimos. Logo, a verdade do intelecto divino é imutável; ao passo
que é mutável a do nosso, não porque seja sujeito à mutação, mas porque o nosso intelecto se muda, da
verdade para a falsidade; pois, assim, as formas podem-se considerar mutáveis. Mas, a verdade do
intelecto divino é aquela pela qual as coisas naturais se chamam verdadeiras, e é absolutamente
imutável.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO — Agostinho refere-se à verdade divina.

RESPOSTA À SEGUNDA. — A verdade e o ser convertem-se e são generalíssimos. Donde, assim como o
ser não é gerado nem corrompido, em si mesmo, mas, por acidente, enquanto tal ser e tal outro é
corrompido ou gerado, como diz Aristóteles, assim, a verdade muda; não que nenhuma permaneça,
mas, porque não permanece aquela que antes existia.

RESPOSTA À TERCEIRA. — Uma proposição é verdadeira, não só como as outras realidades o são, assim
chamadas enquanto realizam o que é ordenado pelo intelecto divino; mas ainda, de um certo modo
especial, enquanto exprime a verdade do intelecto. E esta consiste na conformidade do intelecto com o
seu objeto, desaparecida a qual, muda-se a verdade da opinião e, por conseguinte, a da proposição.
Assim, pois, a proposição — Sócrates está sentado — é verdadeira, estando ele sentado, tanto pela
verdade do objeto, enquanto é uma voz significativa, como pela verdade da significação, enquanto
significa uma opinião verdadeira. Porém, quando Sócrates se levanta, permanece a primeira verdade,
mas muda a segunda.

RESPOSTA À QUARTA. — O sentar-se de Sócrates, causa da verdade da proposição — Sócrates está
sentado— não tem a mesma causalidade, enquanto ele está sentado, e depois e antes de sentar-se. Por
onde, também a verdade por ele causada apresenta-se diversamente e é diversamente expressa pelas
proposições, no presente, no passado e no futuro. Portanto, de ser uma dessas três proposições
verdadeira, não resulta que a mesma verdade permaneça invariável.