# Questão 92: Da produção da mulher.

## Art. 1 — Se a mulher devia ter sido produzida na primeira produção das causas.
O primeiro discute–se assim. – Parece que a mulher não devia ter sido produzida na primeira
produção das coisas.

1. – Pois, diz o Filósofo que a fêmea é o macho falho, Ora, nada de falho e deficiente devia existir na
primeira instituição das coisas. Logo, nessa primeira instituição, a mulher não devia ter sido produzida.

2. Demais. – A sujeição e a diminuição foram subsequentes ao pecado. Pois, à mulher foi dito, depois do
pecado: estará sob o poder de teu marido; e como diz Gregório; no que não delinquimos somos todos
iguais. Ora, a mulher tem, naturalmente, menor virtude e dignidade que o homem; pois, como diz
Agostinho, sempre é mais digno de honra o agente que o paciente. Logo, a mulher não devia ter sido
produzida na primeira produção das coisas, antes do pecado.

3. Demais. – Devem–se evitar as ocasiões do pecado. Ora Deus tinha presciência que a mulher havia de
ser, para o homem, ocasião de pecado. Logo, não devia tê–la produzido.
Mas, em contrário, diz a Escritura: Não é bom que o homem esteja só, façamos–lhe um adjutório
semelhante a ele.

SOLUÇÃO. – Era necessário que a mulher fosse feita para adjutório do homem. Não, certo, adjutório
para qualquer outra obra, como alguns disseram; pois, nisso o homem pode ser ajudado, mais
convenientemente, por outro homem, do que pela mulher; mas para o adjutório da geração. O que se
pode compreender mais manifestamente, se se considerar o modo da geração, nos seres vivos. – Assim,
certos têm conjuntamente 1) virtude da geração ativa e passiva, como acontece com as plantas, geradas
da semente; pois, não há nelas nenhuma operação vital mais nobre que a geração e, por isso, a todo
tempo e convenientemente, nelas, a virtude geratriz ativa vai junta com a passiva. – Porém os animais
perfeitos têm a virtude gera triz ativa, no sexo masculino, e a passiva, no feminino. E como eles são
capazes de alguma operação vital mais nobre que a geração, para cuja operação a vida se lhes ordena
principalmente, por isso, o sexo masculino não se une com o feminino a todo o tempo, mas só no do
coito. E assim podemos pensar que, pelo coito, constituem um só ser o macho e a fêmea, como na
planta, a todo tempo, conjugam–se as virtudes masculina e feminina, embora em umas abunde mais
uma dessas virtudes, e, noutras, a outra. – Ora, o homem se ordena a uma operação vital mais nobre,
que é o inteligir. E por isso ne]e, com maior razão, devia haver a distinção entre uma e outra virtude, de
modo que a fêmea fosse produzida separadamente do macho; e contudo, ambos se unissem,
carnalmente, para a obra da geração. Por onde, logo depois da formação da mulher, diz a Escritura:
Serão dois numa só carne.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Na sua natureza particular, a fêmea é um ser deficiente e
falho. Porque a virtude ativa, que está no sémen do macho, tende a produzir um ser perfeito
semelhante a si, do sexo masculino. Mas o facto de ser a fêmea a gerada provém da debilidade da
virtude ativa, ou de alguma indisposição da matéria; ou ainda, de alguma transmutação extrínseca, p.
ex., dos ventos austrais, que são úmidos, como diz Aristóteles. Mas, por comparação com a natureza
universal, a fêmea não é um ser falho, pois está destinada, por intenção da natureza, à obra da geração.
Ora, a intenção da natureza universal depende de Deus, universal autor da mesma. Por isso na
instituição desta produziu não só o macho mas também a fêmea.

RESPOSTA À SEGUNDA. – Há dupla sujeição. Uma servil, pela qual o superior usa do súdito, em sua
utilidade, e essa sujeição foi introduzida depois do pecado. Outra é a sujeição econômica ou civil, pela
qual o chefe usa dos súditos para o bem destes: e tal sujeição já existia antes do pecado. Pois faltaria o
bem da ordem, na sociedade humana, se uns não fossem governados por outros, mais sábios. E assim,
por essa sujeição, é que a mulher é naturalmente dependente do homem; porque este tem
naturalmente maior discreção racional. Nem fica excluída a desigualdade dos homens, pelo estado da
inocência, como a seguir se dirá.

RESPOSTA À TERCEIRA. – Se Deus tirasse do mundo todas as coisas nas quais o homem haure ocasião
de pecar, o universo ficaria imperfeito. Nem devia eliminar–se o bem comum a pretexto de evitar o mal
particular; e sobretudo. Deus é de tal modo poderoso que pode fazer redundar qualquer mal, em bem.

## Art. 2 — Se a mulher devia ter sido feita do homem.
O segundo discute–se assim. – Parece que a mulher não devia ter sido feita do homem.

1. – Pois, o sexo é comum ao homem e aos brutos. Ora, as fêmeas destes não são feitas dos machos.
Logo, nem a do homem deveria tê–lo sido.

2. Demais. Seres da mesma espécie têm a mesma matéria. Ora, o macho e a fêmea são da mesma
espécie. Portanto, se o homem foi feito do limo da terra, deste mesmo, e não daquele, devia a mulher
ter sido feita.

3. Demais. – A mulher foi feita para adjutório do homem, na geração. Ora, o parentesco muito próximo
torna uma pessoa inepta para tal; e por isso os parentes próximos são excluídos do matrimónio, como
se vê na Escritura. Logo, a mulher não devia ter sido feita do homem.
Mas, em contrário, diz a Escritura: Criou da sua mesma substância, isto é, ao homem, um ajuda
semelhante a ele, a mulher.

SOLUÇÃO. – Foi conveniente na primeira instituição das coisas, a mulher, diferentemente dos brutos,
ser formada do varão. – Primeiro, para que, assim, se conferisse a este uma certa dignidade; de modo
que, semelhantemente a Deus, também ele fosse o princípio de toda a sua espécie, assim como Deus é
o princípio de todo o universo. Por isso a Escritura diz, que De um só Deus fez todo o gênero humano.
Segundo, para que o homem amasse mais a mulher e mais inseparavelmente se lhe unisse, quando
soubesse que de si mesmo foi ela produzida. – E por isso diz a Escritura: De varão foi tomada: por isso
deixará o homem a seu pai e a sua mãe e se unirá à sua mulher, – O que era sumamente necessário, na
espécie humana, na qual o homem e a mulher permanecem unidos por toda a vida; o que não se dá
com os brutos. – Terceiro, porque, como diz o Filósofo, na espécie humana, o varão e a mulher unem–
se, não só pela necessidade da geração, como os brutos, mas também para a vida doméstica, na qual há
uns atos próprios ao homem e outros, à mulher, sendo aquele a cabeça desta, Por onde
convenientemente, a mulher foi formada do homem, como do seu princípio. A quarta razão, enfim, é
sacramental. Pois, com essa formação está figurado que a Igreja tira de Cristo o seu princípio. Por isso
diz a Escritura: Este sacramento é grande, mas eu digo em Cristo e na Igreja.
E daqui se deduz a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. – Matéria é aquilo de que alguma cousa se faz. Ora, natureza criada tem um
determinado princípio; e como é determinada a um termo, também tem um determinado processo; por
isso de determinada matéria, produz algo especificamente determinado. Mas, o poder divino, sendo
infinito, pode fazer um mesmo ser, especificamente, de qualquer matéria; assim, o homem, do limo da
terra, e a mulher, do homem.

RESPOSTA À TERCEIRA. – Pela geração natural se contrai um certo parentesco, que impede o
matrimônio. Ora, a mulher não foi produzida, do homem, por geração natural, mas pela só virtude
divina; por isso Eva não é chamada filha de Adão. Portanto, a objeção não colhe.

## Art. 3 — Se a mulher devia ter sido formada da costela do homem.
O terceiro discute–se assim. – Parece que a mulher não devia ter sido feita da costela do homem.

1. – Pois a costela do homem é muito menor que o corpo da mulher. Ora, do menor não se pode fazer o
maior senão por adição; e se assim tivesse sido, havia de dizer–se que a mulher foi formada, antes, por
essa adição, do que da costela. Ou pela rarefação, pois, como diz Agostinho, não é possível que um
corpo cresça se não se rarefizer; ora, não parece que o corpo da mulher seja mais rarefeito que o do
homem, pelo menos na proporção que tem a costela com o corpo de Eva. Logo, Eva não foi formada da
costela de Adão.

2. Demais. – Nas obras primeiramente criadas nada havia de supérfluo. Logo, a costela de Adão lhe
pertencia à perfeição do corpo. E portanto, faltando aquela, este ficou imperfeito. O que é inadmissível.

3. Demais. – A costela não pode ser separada do homem sem dor. Ora, esta não existia antes do pecado.
Logo, a costela não devia ser separada do homem, para que, dela, a mulher fosse formada.
Mas, em contrário, diz a Escritura: Da costela que tinha tirado de Adão formou o Senhor Deus a mulher.

SOLUÇÃO. – Era conveniente que a mulher fosse formada da costela do homem. – Primeiro, para
significar que deve haver união entre o homem e a mulher. Pois, nem esta deve dominar aquele e, por
isso, não foi formada da cabeça; nem deve ser desprezada pelo homem, numa como sujeição servil, c
por isso não foi formada dos pés. – Segundo, por causa do sacramento; porque, – do lado de Cristo,
dormindo na cruz, fluíram os sacramentos, isto é, o sangue e a água, com os quais foi a Igreja instituída.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Alguns dizem que, pela multiplicação da matéria, sem
adição de mais nada, foi formado o corpo da mulher, do mesmo modo pelo qual o Senhor multiplicou os
cinco pães. – Mas isso é absolutamente impossível. Pois, a multiplicação referida se deu ou pela
transmutação da substância da própria matéria, ou pela transmutação das dimensões da mesma. Ora,
não se deu pela transmutação da sobredita substância, quer porque a matéria, em si considerada, é
absolutamente intransmutável, como potencial que é, e por ser essencialmente sujeito; quer porque a
multiplicidade e a grandeza não se incluem na essência da matéria em si. Por onde, de nenhum modo se
pode compreender a multiplicação da matéria, enquanto esta permanece sem adição, salvo se ela
receber maiores dimensões. Mas, como diz o Filósofo, quando a mesma matéria recebe maiores
dimensões, ela se rarefaz. Ora, admitir a multiplicação de uma mesma matéria, sem rarefacção, é
afirmar a simultaneidade dos contraditórios, isto é, a definição sem o definido. – Por onde, como nas
tais multiplicações não houve rarefação, necessário é admitir–se a adição da matéria, ou por criação, ou,
o que é mais provável, pela conversão. E por isso. Agostinho diz que, Cristo saciou cinco mil homens,
com cinco pães, do mesmo modo que, de poucos grãos produz a multidão das sementes; o que se dá
pela conversão do alimento. E assim, diz–se que, com cinco pães, alimentou as turbas, ou que, da
costela, formou a mulher, por ter sido feita adição à matéria preexistente da costela, ou dos pães.

RESPOSTA À SEGUNDA. – A referida costela era da perfeição de Adão, considerado este, não como
indivíduo, mas como princípio da espécie; assim como o sémen, que pertence à perfeição do gerador,
põe–se em liberdade, com deleite, por operação natural. Por onde, com muito maior razão, o–corpo da
mulher podia ter sido formado, pela virtude divina, da costela do homem, sem dor. E daí se deduz a
resposta à terceira objeção.

## Art. 4 — Se a mulher foi formada imediatamente por Deus.
O quarto discute–se assim. – Parece que a mulher não foi formada imediatamente por Deus.

1. – Pois nenhum indivíduo produzido pelo seu semelhante, especificamente, é feito imediatamente por
Deus. Ora, a mulher foi feita do homem, que é da mesma espécie que ela. Logo, não foi feita
imediatamente por Deus.

2. Demais. – Agostinho diz que os seres corpóreos são feitos por Deus, por intermédio dos anjos. Ora, o
corpo da mulher é formado de matéria corpórea. Logo, foi feito pelo ministério dos anjos e não
imediatamente, por Deus.

3. Demais. – As criaturas que preexistiam, pelas razões causais, são produzidas em virtude de alguma
criatura e não, imediatamente, por Deus. Ora, o corpo da mulher foi produzido, segundo as razões
causais, nas primeiras obras, como diz Agostinho. Logo, a mulher não foi produzida imediatamente por
Deus.
Mas, em contrário, diz Agostinho: Só Deus, por quem subsiste toda a natureza, podia formar ou produzir
a costela, para que a mulher existisse.

SOLUÇÃO. – Como já se disse antes, a geração natural de cada espécie é mediante uma determinada
matéria. Ora, a matéria da qual naturalmente é gerado o homem é o sémen humano, do homem ou da
mulher. Por onde, de qualquer outra matéria um indivíduo da espécie humana não pode ser
naturalmente gerado. Ora, só Deus, instituidor da natureza, pode, fora da ordem desta, dar o ser às
coisas. E portanto só ele podia formar tanto o homem, do limo da terra, como a mulher, da costela do
homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A objeção procede quando um indivíduo é gerado do
especificamente semelhante, por geração natural.

RESPOSTA À SEGUNDA. – Como diz Agostinho, não sabemos se os anjos prestaram o seu ministério a
Deus, na formação da mulher; todavia, é certo que, assim como o corpo do homem não foi formado do
limo da terra, pelos anjos, assim também nem o corpo da mulher, da costela de Adão, foi formado por
eles.

RESPOSTA À TERCEIRA. – Como diz Agostinho, no mesmo livro, na condição primeira das causas não
estava que a mulher, absolutamente, fosse assim feita; mas estava, que pudesse sê–Ia. E logo, nas suas
razões causais, o corpo da mulher preexistia, nas primeiras obras, não pela potência ativa, mas só pela
passiva, em ordem à potência ativa do Criador.