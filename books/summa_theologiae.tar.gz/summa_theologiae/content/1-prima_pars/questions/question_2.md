# Questão 2: Deus existe?
O principal intento, pois, da doutrina sagrada é transmitir o conhecimento de Deus, não somente
enquanto existente em si, mas ainda como princípio e fim dos seres, e, especialmente, da criatura
racional, como é claro pelo que antes se disse. Ora, pretendendo fazer a exposição desta doutrina, 1o.
trataremos de Deus; 2o. do movimento da criatura racional para Deus; 3o. de Cristo que, enquanto
homem, é via para tendermos a Deus.
Mas a consideração sobre Deus será tripartida. Assim, 1o. trataremos do que pertence à essência divina;
2o. do que pertence à distinção das pessoas; 3o. do que pertence à processão, que de Deus têm as
criaturas.
Sobre a essência divina, porém, devemos considerar: 1o. se Deus existe; 2o. como é, ou antes, como não
é; 3o. devemos considerar o que pertence à operação de Deus, a saber, a ciência, a vontade e o poder.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se a existência de Deus é por si mesma conhecida.
(I Sent., dist. 3, q. 1, a. 2; Cont. Gent. I, 10, 11; III, 38; De Verit., q. 10, a. 12; De Pot., q. 7, a. 2, ad 2; in Os
8; in Boet. De Trin., q. 1, a. 3, ad 6)
O primeiro discute-se assim — Parece que a existência de Deus é conhecida por si mesma.

1. — Pois são assim conhecidas de nós as coisas cujo conhecimento temos naturalmente, como é claro
quantos aos primeiros princípios. Ora, diz Damasceno: O conhecimento da existência de Deus é
naturalmente ínsito em todos. Logo, a existência de Deus é conhecida por si mesma.

2. Demais — Dizem-se por si mesmas conhecidas as proposições que, conhecidos os termos,
imediatamente se conhecem, o que o filósofo atribui aos primeiros princípios da demonstração; pois
sabido o que são o todo e a parte, imediatamente se sabe ser qualquer todo maior que a parte. Ora,
inteligida a significação do nome Deus, imediatamente se intelige o que é Deus. Pois, tal nome significa
aquilo do que se não pode exprimir nada maior; ora, maior é o existente real e intelectualmente, do que
o existente apenas intelectualmente. Donde, como o nome de Deus, uma vez inteligido, imediatamente
existe no intelecto, segue-se que também existe realmente. Logo, a existência de Deus é por si mesma
conhecida.

3. Demais — A existência da verdade é por si mesma conhecida, pois quem lhe nega a existência a
concede; porquanto, se não existe, é verdade que não existe. Portanto, se alguma coisa é verdadeira, é
necessária a existência da verdade. Ora, Deus é a própria verdade, como diz a Escritura (Jo 14, 6): Eu sou
o caminho, a verdade e a vida. Logo, a existência de Deus é por si mesma conhecida.
Mas, em contrário — Ninguém pode pensar o contrário do que é conhecido por si, como se vê no
Filósofo, sobre os primeiros princípios da demonstração. Ora, podemos pensar o contrário da existência
de Deus, segundo a Escritura (Sl 52, 1): Disse o néscio no seu coração: Não há Deus. Logo, a existência
de Deus não é por si conhecida.

SOLUÇÃO. — De dois modos pode uma coisa ser conhecida por si: absolutamente, e não relativamente
a nós; e absolutamente e relativamente a nós. Pois qualquer proposição é conhecida por si, quando o
predicado se inclui em a noção do sujeito, p. ex.: O homem é um animal, pertencendo animal à noção
de homem. Se, portanto, for conhecido de todos o que é o predicado e o sujeito, tal proposição será
para todos evidente; como se dá com os primeiros princípios da demonstração, cujos termos — o ser e
o não ser, o todo e a parte e semelhantes — são tão comuns que ninguém os ignora. Mas, para quem
não souber o que são o predicado e o sujeito, a proposição não será evidente, embora o seja,
considerada em si mesma. E por isso, como diz Boécio, certas concepções de espírito são comuns e
conhecidas por si, mas só para os sapientes, como p. ex.: os seres incorpóreos não ocupam lugar.
Digo, portanto, que a proposição Deus existe, quanto à sua natureza, é evidente, pois o predicado se
identifica com o sujeito, sendo Deus o seu ser, como adiante se verá (q. 3, a. 4). Mas, como não
sabemos o que é Deus, ela não nos é por si evidente, mas necessita de ser demonstrada, pelos efeitos
mais conhecidos de nós e menos conhecidos por natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Conhecer a existência de Deus de modo geral e com
certa confusão, é-nos naturalmente ínsito, por ser Deus a felicidade do homem: pois, este naturalmente
deseja a felicidade e o que naturalmente deseja, naturalmente conhece. Mas isto não é pura e
simplesmente conhecer a existência de Deus, assim como conhecer quem vem não é conhecer Pedro,
embora Pedro venha vindo. Pois, uns pensam que o bem perfeito do homem, a felicidade, consiste nas
riquezas; outros, noutras coisas.

RESPOSTA À SEGUNDA. — Talvez quem ouve o nome de Deus não o intelige como significando o ser,
maior que o qual nada possa ser pensado; pois, alguns acreditam ser Deus corpo. Porém, mesmo
concedido que alguém intelija o nome de Deus com tal significação, a saber, maior do que o qual nada
pode ser pensado, nem por isso daí se conclui que intelija a existência real do que significa tal nome,
senão só na apreensão do intelecto. Nem se poderia afirmar que existe realmente, a menos que se não
concedesse existir realmente algum ser tal que não se possa conceber outro maior, o que não é
concedido pelos que negam a existência de Deus.

RESPOSTA À TERCEIRA. — A existência da verdade em geral é conhecida por si; mas a da primeira
verdade não o é, relativamente a nós.

## Art. 2 — Se é demonstrável a existência de Deus.
(Infra, q. 3, a. 5; III Sent., dist. 24, q. 1, a. 2, q. 1ª 2; Cont. Gent. I, 12; De Pot., q. 7, a. 3; in Boet. De Trin,
q. 1, a. 2)
O segundo discute-se assim — Parece que não é demonstrável a existência de Deus.

1. Pois, tal existência é artigo de fé. Ora, as coisas da fé não são demonstráveis, porque a demonstração
dá a ciência, e a fé é própria do que não é aparente, como se vê no Apóstolo (Heb 11,1). Logo, a
existência de Deus não é demonstrável.

2. Demais — O termo médio da demonstração é a quididade. Ora, não podemos saber o que é Deus,
como diz Damasceno. Logo, não lhe podemos demonstrar a existência.

3. Demais — Se se demonstrasse a existência de Deus, só poderia sê-lo pelos seus efeitos. Ora, sendo
Deus infinito e estes, finitos, e não havendo proporção entre o finito e o infinito, os efeitos não lhe são
proporcionados. E, como a causa se não pode demonstrar pelo efeito, que não lhe é proporcionado,
conclui-se que não se pode demonstrar a existência de Deus.
Mas, em contrário, diz a Escritura (Rm 1, 20): As coisas invisíveis de Deus se vêm depois da criação do
mundo, consideradas pelas obras que foram feitas. Ora, isto não se daria, se a existência de Deus não se
pudesse demonstrar pelas coisas feitas, pois o que primeiro se deve inteligir de um ser é se existe.

SOLUÇÃO. — Há duas espécies de demonstração. Uma, pela causa, pelo porquê das coisas, a qual se
apóia simplesmente nas causas primeiras. Outra, pelo efeito, que é chamada a posteriori, embora se
baseie no que é primeiro para nós; quando um efeito nos é mais manifesto que a sua causa, por ele
chegamos ao conhecimento desta. Ora, podemos demonstrar a existência da causa própria de um
efeito, sempre que este nos é mais conhecido que aquela; porque, dependendo os efeitos da causa, a
existência deles supõe, necessariamente, a preexistência desta. Por onde, não nos sendo evidente, a
existência de Deus é demonstrável pelos efeitos que conhecemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A existência de Deus e outras noções semelhantes que,
pela razão natural, podem ser conhecidas de Deus, não são artigos de fé, como diz a Escritura (Rm 1,19),
mas preâmbulos a eles; pois, como a fé pressupõe o conhecimento natural, a graça pressupõe a
natureza, e a perfeição, o perfectível. Nada, entretanto, impede ser aquilo, que em si é demonstrável e
cognoscível, aceito como crível por alguém que não compreende a demonstração.

RESPOSTA À SEGUNDA. — Quando se demonstra a causa pelo efeito, é necessário empregar este em
lugar da definição daquela, cuja existência se vai provar: e isto sobretudo se dá em relação a Deus. Pois,
para provar a existência de alguma coisa, é necessário tomar como termo médio o que significa o
nome e não o que a coisa é, porque a questão — o que é — segue-se à outra — se é. Ora, os nomes a
Deus se impõe pelos efeitos, como depois se mostrará; donde, demonstrando a existência de Deus, pelo
efeito, podemos tomar como termo médio a significação do nome de Deus.

RESPOSTA À TERCEIRA. — Efeitos não proporcionados à causa não levam a um conhecimento perfeito
dela; todavia, por qualquer efeito nos pode ser, manifestamente, demonstrada a existência da causa,
como se disse. E assim, pelos seus efeitos, pode ser demonstrada a existência de Deus, embora por eles
não possamos perfeitamente conhecê-lo na sua essência.

## Art. 3 — Se Deus Existe.
(I Sent., dist. 3, div. Prim. Part. Textus; Cont. Gent. I, 13, 15, 16, 44; II, 15; III, 44; De Verit., q. 5, a. 2; De
Pot., q. 3, a. 5; Compend. Theol., c. 3; VII Physic., lect. 2; VIII, lect. 9 sqq; XII Metaph., lect. 5 sqq.)
O terceiro discute-se assim — Parece que Deus não existe.

1. Pois, um dos contrários, sendo infinito, destrói o outro totalmente. E como, pelo nome de Deus, se
intelige um bem infinito, se existisse Deus, o mal não existiria. O mal, porém, existe no mundo. Logo,
Deus não existe.

2. Demais — O que se pode fazer com menos não se deve fazer com mais. Ora, tudo o que no mundo
aparece pode ser feito por outros princípios, suposto que Deus não exista; pois, o natural se reduz ao
princípio, que é a natureza; e o proposital, à razão humana ou à vontade. Logo, nenhuma necessidade
há de se supor a existência de Deus.
Mas, em contrário, diz a Escritura (Ex 3, 14), da pessoa de Deus: Eu sou quem sou.

SOLUÇÃO. — Por cinco vias pode-se provar a existência de Deus. A primeira e mais manifesta é a
procedente do movimento; pois, é certo e verificado pelos sentidos, que alguns seres são movidos neste
mundo. Ora, todo o movido por outro o é. Porque nada é movido senão enquanto potencial,
relativamente àquilo a que é movido, e um ser move enquanto em ato. Pois mover não é senão levar
alguma coisa da potência ao ato; assim, o cálido atual, como o fogo, torna a madeira, cálido potencial,
em cálido atual e dessa maneira, a move e altera. Ora, não é possível uma coisa estar em ato e potência,
no mesmo ponto de vista, mas só em pontos de vista diversos; pois, o cálido atual não pode ser
simultaneamente cálido potencial, mas, é frio em potência. Logo, é impossível uma coisa ser motora e
movida ou mover-se a si própria, no mesmo ponto de vista e do mesmo modo, pois, tudo o que é
movido há-de sê-lo por outro. Se, portanto, o motor também se move, é necessário seja movido por
outro, e este por outro. Ora, não se pode assim proceder até ao infinito, porque não haveria nenhum
primeiro motor e, por conseqüência, outro qualquer; pois, os motores segundos não movem, senão
movidos pelo primeiro, como não move o báculo sem ser movido pela mão. Logo, é necessário chegar a
um primeiro motor, de nenhum outro movido, ao qual todos dão o nome de Deus.
A segunda via procede da natureza da causa eficiente. Pois, descobrimos que há certa ordem das causas
eficientes nos seres sensíveis; porém, não concebemos, nem é possível que uma coisa seja causa
eficiente de si própria, pois seria anterior a si mesma; o que não pode ser. Mas, é impossível, nas causas
eficientes, proceder-se até o infinito; pois, em todas as causas eficientes ordenadas, a primeira é causa
da média e esta, da última, sejam as médias muitas ou uma só; e como, removida a causa, removido fica
o efeito, se nas causas eficientes não houver primeira, não haverá média nem última. Procedendo-se ao
infinito, não haverá primeira causa eficiente, nem efeito último, nem causas eficientes médias, o que
evidentemente é falso. Logo, é necessário admitir uma causa eficiente primeira, à qual todos dão o
nome de Deus.
A terceira via, procedente do possível e do necessário, é a seguinte — Vemos que certas coisas podem
ser e não ser, podendo ser geradas e corrompidas. Ora, impossível é existirem sempre todos os seres de
tal natureza, pois o que pode não ser, algum tempo não foi. Se, portanto, todas as coisas podem não
ser, algum tempo nenhuma existia. Mas, se tal fosse verdade, ainda agora nada existiria pois, o que não
é só pode começar a existir por uma coisa já existente; ora, nenhum ente existindo, é impossível que
algum comece a existir, e portanto, nada existiria, o que, evidentemente, é falso. Logo, nem todos os
seres são possíveis, mas é forçoso que algum dentre eles seja necessário. Ora, tudo o que é necessário
ou tem de fora a causa de sua necessidade ou não a tem. Mas não é possível proceder ao infinito, nos
seres necessários, que têm a causa da própria necessidade, como também o não é nas causas eficientes,
como já se provou. Por onde, é forçoso admitir um ser por si necessário, não tendo de fora a causa da
sua necessidade, antes, sendo a causa da necessidade dos outros; e a tal ser, todos chamam Deus.
A quarta via procede dos graus que se encontram nas coisas. — Assim, nelas se encontram em
proporção maior e menor o bem, a verdade, a nobreza e outros atributos semelhantes. Ora, o mais e
o menos se dizem de diversos atributos enquanto se aproximam de um máximo, diversamente; assim, o
mais cálido é o que mais se aproxima do maximamente cálido. Há, portanto, algo verdadeiríssimo,
ótimo e nobilíssimo e, por conseqüente, maximamente ser; pois, as coisas maximamente verdadeiras
são maximamente seres, como diz o Filósofo. Ora, o que é maximamente tal, em um gênero, é causa de
tudo o que esse gênero compreende; assim o fogo, maximamente cálido, é causa de todos os cálidos,
como no mesmo lugar se diz. Logo, há um ser, causa do ser, e da bondade, e de qualquer perfeição em
tudo quanto existe, e chama-se Deus.
A quinta procede do governo das coisas — Pois, vemos que algumas, como os corpos naturais, que
carecem de conhecimento, operam em vista de um fim; o que se conclui de operarem sempre ou
freqüentemente do mesmo modo, para conseguirem o que é ótimo; donde resulta que chegam ao fim,
não pelo acaso, mas pela intenção. Mas, os seres sem conhecimento não tendem ao fim sem serem
dirigidos por um ente conhecedor e inteligente, como a seta, pelo arqueiro. Logo, há um ser inteligente,
pelo qual todas as coisas naturais se ordenam ao fim, e a que chamamos Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz Agostinho, Deus sumamente bom, de nenhum
modo permitiria existir algum mal nas suas obras, se não fosse onipotente e bom para, mesmo do mal,
tirar o bem. Logo, pertence à infinita bondade de Deus permitir o mal para deste fazer jorrar o bem.

RESPOSTA À SEGUNDA. — A natureza, operando para um fim determinado, sob a direção de um agente
superior, é necessário que as coisas feitas por ela ainda se reduzam a Deus, como à causa primeira. E,
semelhantemente, as coisas propositadamente feitas devem-se reduzir a alguma causa mais alta, que
não a razão e a vontade humanas, mutáveis e defectíveis; é, logo, necessário que todas as coisas móveis
e suscetíveis de defeito se reduzam a algum primeiro princípio imóvel e por si necessário, como se
demonstrou.