# Questão 59: Da vontade dos anjos.
Em seguida devemos tratar do que respeita à vontade dos anjos. E, primeiro, trataremos da vontade
mesma. Segundo, do seu movimento, que é amor ou dileção.
E, sobre o primeiro ponto, quatro artigos se discutem:

## Art. 1 — Se nos anjos há vontade.
(II Cont. Gent., cap. XLVII; De Verit., q. 23, a. 1)
O primeiro discute-se assim. – Parece que nos anjos não há vontade.

1. —Porque, como diz o Filósofo, a vontade está na razão. Ora, nos anjos não há razão, mas algo que lhe
é superior. Logo, neles não há vontade, mas algo que lhe é superior.

2. Demais. — A vontade é uma espécie de apetite, como é claro pelo Filósofo Ora, este é de natureza
imperfeita, pois se refere ao que ainda não é possuído. Resulta, logo, que nos anjos não há vontade,
porque neles não há, sobretudo nos santos, nenhuma imperfeição.

3. Demais. — O Filósofo diz que a vontade é um motor movido, pois é movida pelo objeto apetecível
inteligido. Ora, os anjos, sendo incorpóreos são imóveis. Logo neles não há vontade.
Mas, em contrário, diz Agostinho que na alma está a imagem da Trindade representada pela memória, a
inteligência e a vontade. Ora, a imagem de Deus se encontra, não só na alma humana, mas também no
espírito angélico, pois também este é capaz de Deus. Logo, nos anjos há vontade.

SOLUÇÃO. — É forçoso admitir-se a vontade nos anjos. Para a evidência do que se deve considerar na
procedência de todos os seres, da vontade divina; todos, a seu modo, mas diversamente, inclinando-se
ao bem, pelo apetite. — Assim, certos buscam o bem pela só tendência natural, sem conhecimento,
como as plantas e os corpos inanimados. E essa inclinação para o bem se chama apetite natural. —
Outros, porém, buscam o bem com algum conhecimento; não, certo, conhecendo a natureza mesma do
bem, mas conhecendo algum bem particular, como o sentido, que conhece o doce, o branco e coisas
semelhantes. E essa inclinação resultante de tal conhecimento se chama apetite sensitivo. — Outros
seres, por fim, buscam o bem conhecendo-lhe a natureza mesma, o que é próprio do intelecto. E esses
buscam-no perfeitissimamente não como somente dirigidos ao bem por meio de outrem, como os seres
sem conhecimento; nem como se dirigidos fossem ao bem particular somente, como os seres que têm
apenas conhecimento sensível; mas como inclinados que são ao mesmo bem universal. E esta inclinação
se chama vontade. Donde, conhecendo os anjos, pelo intelecto, a natureza universal do bem, é
manifesto que neles há vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um é o modo pelo qual a razão transcende o sentido, e
outro o pelo qual o intelecto transcende a razão. A razão transcende o sentido pela diversidade dos
objetos conhecidos: este conhece o particular, aquela, o universal. E, por isso, é forçoso seja um o
apetite próprio à razão, e tendente ao bem universal; outro, o próprio ao sentido e tendente ao bem
particular. O intelecto e a razão, porém diferem quanto ao modo de conhecer, pois aquele conhece por
intuição simples, e esta, discorrendo de um objeto para outro. Todavia, a razão, pelo discurso, chega a
conhecer o universal, que o intelecto conhece sem discurso. Portanto, o mesmo é o objeto proposto ao
apetite pela razão e pelo intelecto. Por onde, nos anjos, puras inteligências, não há apetite superior à
vontade.

RESPOSTA À SEGUNDA. — Embora o nome da parte apetitiva seja derivado de se apetirem as coisas
que se não têm, todavia ela se estende não só a tais coisas, mas ainda a muitas outras; assim como o
nome lápida é derivado de lesão do pé, sem que, contudo, tal denominação convenha somente à lápida.
Semelhantemente, a potência irascível é assim chamada por causa da ira, embora compreenda várias
outras paixões, como a esperança, a audácia e demais.

RESPOSTA À TERCEIRA. — Diz-se que a vontade é um motor movido porque o querer é um certo
movimento e uma certa intelecção; ora, nada impede exista nos anjos um tal movimento, que é ato do
ser perfeito, como diz Aristóteles.

## Art. 2 — Se nos anjos difere a vontade, do intelecto e da natureza.
(I Sent., dist. XLII, q. 1, a. 2, ad 3; De Verit., q. 22, a. 10)
O segundo discute-se assim. — Parece que nos anjos não difere a vontade do intelecto e da natureza.

1. — Pois o anjo é mais simples que o corpo natural. Ora, este, pela forma, busca o seu fim, que lhe é o
bem. Logo, com maior razão, o anjo. Mas a forma deste é ou a natureza mesma, na qual subsiste, ou a
espécie, que lhe está no intelecto. Logo, o anjo, pela sua natureza ou pela espécie inteligível, busca o
bem. Ora, essa tendência para o bem, pertencendo à vontade, esta, no anjo, não lhe difere da natureza
ou do intelecto.

2. Demais. — O objeto da inteligência é o verdadeiro; o da vontade, porém, o bem. Ora, o bem e o
verdadeiro não diferem real mas só nocionalmente. Logo, a vontade e o intelecto não diferem
realmente.

3. Demais. — A distinção entre o próprio e o comum não diversifica as potências; pois a mesma potência
visiva atinge a cor e a brancura. Ora, o bem e o verdadeiro estão entre si como o comum está para o
próprio, por ser o verdadeiro um certo bem, a saber, do intelecto. Logo, a vontade, cujo objeto é o bem,
não difere do intelecto, cujo objeto é o verdadeiro.
Mas, em contrário, nos anjos a vontade só tende para o bem; ao passo que o intelecto tende pelo
conhecimento, para o bem e para o mal. Logo, a vontade, nos anjos, difere do intelecto.

SOLUÇÃO. — A vontade angélica não é senão uma certa virtude e potência, que não se lhes confunde
com a natureza, nem com o intelecto. — Que se não lhes confunde com a natureza o prova o seguinte: a
natureza ou a essência de um ser dentro nesse mesmo ser se compreende; e assim, tudo que se refere a
algo de exterior a esse ser não lhe pertence à essência. Por isso vemos que a causa da inclinação ao ser,
nos corpos naturais, não é algo que se lhes acrescente à essência; mas é a matéria, apetitiva da
existência, que não tem, e a forma, que mantém o ser na existência. Mas a causa da inclinação deles a
algo de extrínseco é-lhes acrescentada à essência; assim, inclinam-se ao lugar pelo peso ou leveza; e
inclinam-se a fazer algo de semelhante a si, pelas qualidade ativas. Ora, a vontade, tendo inclinação
natural para o bem, só haverá identidade entre a vontade e a essência quando o bem estiver totalmente
contido na essência do ser que quer, a saber, em Deus, que senão em razão da sua bondade, nada quer
fora de si. O que se não pode dizer de nenhuma criatura, por estar o bem infinito fora da essência de
qualquer ser causado. Por onde, nem a vontade do anjo nem a de qualquer outra criatura podem-se
lhes identificar com a essência. — Semelhantemente, a vontade se não pode identificar com o intelecto
do anjo ou do homem. Pois, ao passo que o conhecimento se opera por estar o conhecido no
conhecente, a vontade tende para a coisa exterior. Donde, o intelecto humano ou angélico atinge a
coisa exterior, enquanto a esta, existente pela essência fora dele, lhe é natural existir nele de certo
modo. Porém, a vontade atinge a coisa exterior, enquanto que, por uma certa inclinação, tende de
algum modo para tal coisa. Ora, é próprio de uma faculdade ter em si o exterior, e de outra, que esse
ser tenda para tal coisa. E, portanto, em qualquer criatura, necessariamente difere o intelecto da
vontade. Não, porém, em Deus, que tem em si mesmo o ser e o bem universais; por onde, tanto a
vontade como o intelecto se lhe identificam com a essência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O corpo natural, pela forma substancial, tem inclinações
essenciais; mas tende para o exterior por meio de algo que lhe é acrescentado, como se disse.

RESPOSTA À SEGUNDA. — as potências não se diversificam pela distinção material dos objetos, mas por
uma distinção formal, fundada na noção do objeto. Portanto, as noções diversas de bem e de
verdadeiro bastam para diversificar o intelecto, da vontade.

RESPOSTA À TERCEIRA. — De se converterem o bem e o verdadeiro, resulta na realidade que o bem é
inteligido pelo intelecto sob a noção de verdadeiro, e este é apetecido pela vontade sob a noção de
bem. Contudo, a diversidade das noções basta para diversificar as potências, como já se disse.

## Art. 3 — Se nos anjos há livre arbítrio.
(II Sent., dist. XXV, q. 1, a. 1; II Cont. Gent., cap. XLVIII; De Verit., q. 23, a. 1; q. 24, a. 3; De Malo, q. 16, a.
5; Compend. Theol., cap. LXXVI)
O terceiro discute-se assim. — Parece que nos anjos não há livre arbítrio.

1. — Pois, o ato do livre arbítrio é eleger. Mas, como a eleição depende do apetite pré-aconselhado, e o
conselho, de um certo exame, conforme diz Aristóteles, não pode haver eleição, nos anjos, que não
conhecem inquirindo, por ser isto próprio ao discurso da razão. Logo, conclui-se que, neles, não há livre
arbítrio.

2. Demais. — O livro arbítrio supõe duplo termo. Ora, no intelecto angélico nada há que possa tender
para um duplo termo, porque esse intelecto nunca se engana, como se disse, quanto aos inteligíveis
naturais. Logo, nem pelo apetite pode haver nos anjos livre arbítrio.

3. Demais. — O que é natural aos anjos, lhes convém mais ou menos; pois, a natureza intelectual dos
anjos superiores é mais perfeita. Ora, o livre arbítrio não é suscetível de mais nem menos. Logo, nos
anjos, não há livre arbítrio.
Mas, em contrário. A liberdade do arbítrio supõe a dignidade humana. Ora, os anjos são mais dignos do
que os homens. Logo, se existe nos homens, existe nos anjos, com maior razão, essa liberdade.

SOLUÇÃO. — Certos seres há que não agem com livre arbítrio, mas quase levados e movidos por outros;
assim, a seta é movida ao fim pelo arqueiro. Outros, porém, agem com certo arbítrio, mas que não é
livre, como os animais irracionais; assim, a ovelha foge do lobo, em virtude de um juízo pelo qual o julga
nocivo a si, sem esse juízo ser livre, mas ínsito naturalmente. Por onde, só o ser inteligente pode agir
com livre juízo, conhecendo a noção universal do bem, pela qual poderá julgar boa tal ou tal coisa. Por
isso, onde houver intelecto, haverá livre arbítrio. E daí resulta que o livre arbítrio, bem como o intelecto,
existe nos anjos, e mesmo de maneira mais excelente que nos homens.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo fala da eleição própria ao homem. Ora, como
o juízo especulativo do homem difere do angélico, por ser este sem inquisição e aquele, inquisitivo,
assim também os juízos operativos. Por isso, há nos anjos eleição, sem todavia deliberação inquisitiva do
conselho, mas com a imediata captação da verdade.

RESPOSTA À SEGUNDA. — Como se disse, o conhecimento se dá quando as coisas conhecidas estão no
ser que conhece. Ora, só por imperfeição um ser não tem o que naturalmente deve ter. Donde, o anjo
não seria de natureza perfeita, se o seu intelecto não fosse capaz de todas as verdades que
naturalmente pode conhecer. Porém, o ato da virtude apetitiva implica a inclinação do afeto para a
coisa exterior. Ora, a perfeição de um ser não depende de qualquer objeto, para o qual se incline, mas
somente do objeto que lhe é superior. Por onde, não lhe é imperfeição, se o anjo não tem a vontade
determinada às coisas que lhe são inferiores; mas ser-lhe-ia, se não fosse inclinada às que lhe são
superiores.

RESPOSTA À TERCEIRA. — O livre arbítrio, bem como o juízo do intelecto, existe de modo mais nobre
nos anjos superiores do que nos inferiores. Contudo, é verdade que a liberdade, em si mesma,
considerando-se nela a remoção da coação, não padece aumento nem diminuição; porque as privações
e as negações, em si mesmas, não se remitem nem intensificam, mas só pela sua causa ou por alguma
afirmação adjunta.

## Art. 4 — Se nos anjos há o apetite irascível e o concupiscível.
(Infra, q. 8, a. 5; II Sent., dist. VII, q. 2, a. 1; ad 1; De Malo, q. 14, a. 1, ad 3)
O quarto discute-se assim. — Parece que nos anjos há o apetite irascível e o concupiscível.

1. — Pois, diz Dionísio que, nos demônios, há furor irrascível e concupiscência amente. Ora, os
demônios têm a mesma natureza que os anjos bons, pois o pecado não lhes mudou a natureza. Logo,
nos anjos há o apetite irascível e o concupiscível.

2. Demais. — O amor e a alegria pertencem ao apetite concupiscível; porém, a ira, a esperança e o
temor, ao irascível. Ora, essas paixões se atribuem, na Escritura, aos anjos bons e aos maus. Logo, nos
anjos, há o apetite irascível e o concupiscível.

3. Demais. — Há certas virtudes atribuídas tanto ao apetite irascível como ao concupiscível; assim, a
caridade e a temperança pertencem ao concupiscível; a esperança, porém, e a fortaleza, ao irascível.
Ora, essas virtudes existem nos anjos. Logo, neles existem ambos os apetites.
Mas, em contrário, diz o Filósofo que os apetites irascível e concupiscível pertencem à parte sensitiva,
que não existe nos anjos. Logo, neles não há os dois apetites.

SOLUÇÃO. — Não o apetite intelectivo, mas só o sensitivo é que se divide em irascível e concupiscível. E
disso a razão é que as potências se distinguem, não pela distinção material, mas só pela formal dos seus
objetos; por isso, se a uma potência corresponde um objeto nocionalmente comum, não haverá
distinção de potências pela diversidade dos objetos próprios contidos no comum. Assim, sendo a cor
como tal o objeto próprio da potência visiva, não se distinguirão várias potências visivas pela diferença
entre o branco e o preto. Mas, se objeto próprio de uma potência fosse o branco, como tal, distinguir-
se-ia a potência visiva do branco da visiva do preto. Ora, é manifesto, pelo já dito, que o objeto do
apetite intelectivo, chamado vontade, é o bem sob a sua noção comum; nem pode haver apetite que
não busque o bem. Donde, o apetite da parte intelectiva não se divide pela distinção de quaisquer bens
particulares, como acontece com o apetite sensitivo, que não visa o bem nocionalmente comum, mas
um certo bem particular. Portanto os anjos, tendo apenas o apetite intelectivo, o apetite deles se não
divide em irascível e concupiscível, mas permanece indiviso e se chama vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Metaforicamente é que se atribui o furor e a
concupiscência aos demônios; assim como também se atribui a Deus a ira, pela semelhança de efeito.

RESPOSTA À SEGUNDA. — O amor e a alegria, como paixões, pertencem ao apetite concupiscível; mas,
como denominações de um ato simples da vontade, pertencem à parte intelectiva; sendo então amar
querer um bem para si ou para outro e o alegrar-se é o descansar da vontade no bem possuído. E em
geral nenhum afeto, como paixão, se predica dos anjos, segundo Agostinho.

RESPOSTA À TERCEIRA. — A caridade, como virtude, não pertence ao apetite concupiscível, mas à
vontade, Pois, o objeto desse apetite sendo o bem deleitável sensível, não pode atingir o bem divino,
objeto da caridade. E pela mesma razão deve se dizer que a esperança não pertence ao apetite irascível;
pois o objeto deste é o árduo sensível, que não é o arrastado pela virtude da esperança, que visa o
árduo divino. Porém a temperança, como virtude humana, diz respeito às concupiscências dos
deleitáveis sensíveis, as quais pertencem ao apetite concupiscível; e semelhantemente, a fortaleza diz
respeito às audácias e aos temores do apetite irascível. Donde, a temperança, como virtude humana,
pertence ao apetite concupiscível; e a fortaleza, ao irascível. Não é, porém, assim que essas virtudes
existem nos anjos; pois, não há neles paixões de concupiscências, ou do temor e da audácia, que devam
ser reguladas pela temperança e pela fortaleza. Mas se lhes atribui a temperança enquanto manifestam
moderadamente a vontade pela regra da vontade divina; e a fortaleza enquanto firmemente executam
a vontade divina; o que tudo fazem pela vontade e não pelos apetites irascível e concupiscível.