# Questão 45: Do modo da emanação das coisas, do primeiro princípio.
Em seguida discute-se sobre o modo da emanação das coisas, do primeiro princípio, que se chama
criação.
Sobre o que oito artigos se discutem:

## Art. 1 — Se criar é fazer alguma coisa do nada.
(II Sent., dist. I, q. 1, a. 2).
O primeiro discute-se assim. – Parece que criar não é fazer alguma coisa do nada.

1. – Pois, diz Agostinho: fazer é produzir o que antes de nenhum modo existia; ao passo que criar é
constituir alguma coisa, tirando-a do que já existia.

2. Demais. – A nobreza da ação e do movimento depende do seu termo. Por onde, mais nobre é a ação
que parte de um bem para outro e de um para outro ser, do que a transitiva do nada para alguma coisa.
Ora, a criação é a nobilíssima das ações e a primeira de entre todas. Logo, não é a passagem do nada
para o ser, mas antes, de um ser para outro.

3. Demais. – Esta preposição – de (ex) – implica relação de alguma causa, e sobretudo da causa material,
como quando falamos de uma estátua feita de bronze. Ora, não pode o nada ser matéria do ser, nem de
nenhum modo causa dele. Logo, criar não é fazer alguma coisa, do nada.
Mas em contrário, àquilo da Escritura (Gn 1) – no princípio criou Deus o céu, etc. – diz a Glossa; criar é
fazer alguma coisa, do nada.

SOLUÇÃO. – Como já dissemos, não devemos considerar somente a emanação de qualquer ser
particular, de um agente particular, mas também o da totalidade dos seres, da causa universal, que é
Deus; e é a esta emanação que designamos com o nome de criação. Pois, o procedente a modo de
emanação particular não lhe é pressuposto a esta; assim, à geração do homem não é pressuposta a
existência do homem, mas o homem é feito do não-homem, e o branco, do não-branco. Por onde,
considerando-se a emanação universal de todos os seres, do primeiro princípio, é impossível seja
pressuposto qualquer ser a essa emanação. Pois, o nada é o mesmo que nenhum ente. Por onde, assim
como o homem é gerado do não-ser, que é não-homem, assim também a criação, que é a emanação do
ser total, procede do não-ser que é o nada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Agostinho emprega, em sentido equívoco, o nome de
criação, no sentido em que dizemos serem criadas as coisas que se mudam para melhor, como quando
dizemos ter sido alguém criado bispo. Ora, não é neste sentido que agora tratamos da criação, como
dissemos.

RESPOSTA À SEGUNDA. – As mudanças recebem a sua espécie e dignidade, não do termo de origem (a
quo), mas do termo final (ad quem). Por onde, tanto mais perfeição e prioridade tem uma mudança,
quanto mais o seu termo final tem nobreza e prioridade, embora seja mais imperfeito o termo de
origem, oposto ao termo final. Pois, embora a geração, absolutamente, tenha maior nobreza e
prioridade que a alteração por ser a forma substancial mais nobre que a acidental, contudo a privação
da forma substancial, termo originário da geração, é maior imperfeição que o contrário, termo
originário da alteração. Semelhantemente, a criação tem maior perfeição e prioridade que a geração e a
alteração, porque o termo final é a substância total da coisa; ao passo que o considerado termo
originário é, absolutamente, não-ser.

RESPOSTA À TERCEIRA. – Quando se diz que alguma coisa é feita do nada, a preposição de (ex) não
designa a causa material, mas somente a ordem; como quando dizemos que da manhã se faz o meio
dia, i. é., o meio dia vem após a manhã. Devemos, porém, entender que a preposição de (ex) pode
incluir a negação implicada na expressão nada, ou ser incluída por ela. Se for o primeiro o sentido, então
há ai a afirmação da ordem e indica a ordem daquilo que é, relativamente, ao não ser precedente. Se
porém a negação incluir a preposição, então a ordem é negada, e o sentido da expressão – feito do
nada, é: não é feito de alguma coisa, como se disséssemos: este fala do nada, porque não fala de
ninguém. E ambos esses modos de nos exprimirmos se verificam, quando dizemos que alguma coisa é
feita do nada. Mas, no primeiro sentido, a preposição de (ex) implica a ordem, como se disse. O segundo
sentido importa a relação de causa material, que é negada.

## Art. 2 — Se Deus pode criar alguma coisa.
(II Sent., dist. I, q. 1, a. 2; II Cont., Gent., cap. XVI; De Pot., q. 3, a. 1; Compend. Theol., cap. LXIX; Opusc.

XXXVII. De Quatuor Opposit., Ca; p. VIII Phys., lect. III).
O segundo discute-se assim. – Parece que Deus não pode criar nada.

1. – Pois, segundo o Filósofo, os antigos filósofos admitiram como concepção comum do espírito que do
nada nada se faz. Mas o poder de Deus não se estende até contrariar os primeiros princípios, de modo a
fazer, por exemplo, com que o todo não seja maior que sua parte; ou que a afirmação e a negação
sejam simultaneamente verdadeiras. Logo, Deus não pode fazer alguma coisa do nada, ou criar.

2. Demais. – Se criar é fazer alguma coisa do nada, então ser alguma coisa criada é vir-a-ser. Ora, todo
vir-a-ser é mudar-se. Logo, criação é mutação. Mas toda mutação está em algum sujeito, como é claro
pela definição de movimento, pois movimento é o ato do que existe em potência. Logo, é impossível
que alguma coisa seja feita do nada por Deus.

3. Demais. – O que está feito necessariamente esteve, em algum tempo, para vir-a-ser. Ora, não se pode
dizer que aquilo que é criado venha a ser e esteja feito simultaneamente; pois, nos seres permanentes,
o que vem a ser não é, e o que já está feito já é; do contrário alguma coisa seria e não seria
simultaneamente. Logo, se alguma coisa vem a ser, o seu vir-a-ser precede sua existência. Mas tal é
impossível, sem que preexista um sujeito em que se sustente o próprio vir-a-ser. Logo, é impossível que
alguma coisa se faça do nada.

4. Demais. – Não se pode percorrer uma distância infinita. Ora, é infinita a distância entre o ser e o nada.
Logo, não é possível que do nada alguma coisa se faça.
Mas, em contrário, a Escritura (Gn 1, 1): No princípio criou Deus o céu e a terra; a isso diz a Glossa que
criar é fazer alguma coisa do nada.

SOLUÇÃO. – Não somente não é impossível que alguma seja criada por Deus, mas é necessário admitir-
se que todos os seres foram criados por Deus, como resulta do que já foi estabelecido (q. 44). Pois, se
alguém faz alguma coisa de outra, aquela da qual faz é pressuposta à ação de quem faz e não é
produzida por tal ação. Assim, o artífice opera com as coisas naturais, p. ex., a madeira e o ar, que não
são causados pela ação da arte, mas pela da natureza; por sua vez, a própria natureza causa os seres
naturais, quanto à forma, mas pressupõe a matéria. Se pois Deus não atuasse senão sobre algum
pressuposto, seguir-se-ia que esse pressuposto não foi causado por ele. Pois, já mostramos antes, que
nada pode existir nos seres que não provenha de Deus, causa universal de todo o ser. Donde, necessário
é dizer-se que Deus, do nada, traz as coisas ao ser.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os antigos filósofos como já antes se disse, só
consideraram o emanarem os efeitos particulares das causas particulares, que, na sua ação, devem
pressupor alguma coisa; e, assim, era comum opinião deles que do nada nada se faz. Mas isto não se dá
com a primeira emanação, do princípio universal das coisas.

RESPOSTA À SEGUNDA. – A criação é mutação somente segundo o modo de se inteligir. Pois, é da
essência da mutação que um mesmo ser seja diferente, agora, do que era antes. Assim, ora um mesmo
ser atual é diferente agora do que era antes, como se dá com os movimentos segundo a quantidade, a
qualidade e a ubiquação; outras vezes o ser é o mesmo só em potência, como na mutação substancial,
cujo sujeito é a matéria. Mas na criação, pela qual é produzida toda a substância da coisa, só pelo
intelecto é que se pode admitir que um mesmo ser seja agora diferentemente do que foi antes; como se
se entender que alguma coisa, que não existiu antes totalmente, agora exista. Mas, como a ação e a
paixão convenham na substância una do movimento, e difiram somente segundo relações diversas,
como diz Aristóteles, necessário é que, subtraído o movimento, não remanesçam senão relações
diversas no criador e no criado. Como, porém, o modo de exprimir siga o inteligir, como já se disse, a
criação é expressa a modo de mutação; e por isso se diz que criar é fazer alguma coisa do nada. Embora,
neste assunto, mais convenha se diga fazer e ser feito do que mudar e ser mudado; porque fazer e ser
feito importam relação de causa e efeito e de efeito a causa, mas a mutação importa conseqüência.

RESPOSTA À TERCEIRA. – Nas coisas que vem a ser, sem movimento, simultâneos são o virem a ser e o
serem feitas; quer tal feitura seja o termo do movimento, como a iluminação, pois simultaneamente
uma coisa se ilumina e está iluminada; quer não seja termo do movimento, como simultaneamente se
forma o verbo na mente e está formado. Assim, em tais casos, o que vem a ser é; mas, quando se diz vir-
a-ser, quer-se significar que alguma coisa provém de outra e que antes não existia. Donde, realizando-se
a criação sem movimento, simultaneamente alguma coisa é criada e está criada.

RESPOSTA À QUARTA. – Tal objeção procede de uma falsa imaginação, como se existisse algum termo
médio infinito entre o nada e o ser, o que é claramente falso. E tal falsa imaginação provém de que a
criação é expressa como certa mutação existente entre dois termos.

## Art. 3 — Se a criação é alguma coisa na criatura.
(I Sent., dist. XL. Q. 1, a. 1, ad 1, II, dist. I q. 1, a. 2, ad 4, 5; II Cont., Gent., cap. XVIII; De Pot., q. 3, a. 3).
O terceiro discute-se assim. – Parece que a criação não é alguma coisa na criatura.

1. – Pois, assim como a criação, em acepção passiva, é atribuída à criatura, assim, em acepção ativa, é
atribuída ao Criador. Mas a criação, em acepção ativa, não é alguma coisa no Criador, porque então se
seguiria que em Deus há algo temporal. Logo, a criação, em acepção passiva, não é alguma coisa na
criatura.

2. Demais. – Não há meio termo entre o Criador e a criatura. Ora, criação exprime um meio termo entre
ambos, pois não é Criador por não ser eterna; nem criatura, porque então seria necessário, pela mesma
razão, admitir outra criação pela qual ela fosse criada, e assim ao infinito. Logo, a criação não é alguma
coisa.

3. Demais. – Se a criação é alguma coisa, além da substância criada, é necessário seja acidente desta.
Ora, todo acidente está num sujeito. Logo, a coisa criada seria o sujeito da criação e assim se
identificariam o sujeito e o termo da criação, o que é impossível. Porque o sujeito é anterior ao acidente
e o conserva; porém o termo é posterior à ação ou à paixão da qual é termo e, desde que existe, cessa a
ação ou a paixão. Logo, a criação mesma não é alguma coisa.
Mas, em contrário. – Fazer-se alguma coisa, em toda a sua substância, é mais do que só pela sua forma
substancial ou acidental. Ora, a geração pura e simples ou condicionada, pela qual alguma coisa se faz,
na forma substancial ou acidental, é algo no ser gerado. Logo, com a maioria de razão a criação, pela
qual alguma coisa se faz em toda a sua substância, é algo no criado.

SOLUÇÃO. – A criação introduz alguma coisa no criado, mas só relativamente. Pois, o que é criado não o
é por movimento ou por mutação, porque o feito por movimento ou por mutação o é por algo
preexistente, e tem lugar nas produções particulares de certos entes. Ora, tal se não pode dar na
produção do ser total pela causa universal de todos os entes, que é Deus. Por onde Deus, criando,
produz as coisas sem movimento. Ora, eliminando o movimento à ação e à paixão, não remanesce
senão a relação, como já se disse. Donde resulta que a criação, na criatura, não é senão uma certa
relação com o Criador como com o princípio do seu ser; assim como a paixão, que supõe o movimento,
importa relação com o princípio deste.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A criação, em acepção ativa, significa a ação divina, que é
a sua essência, em relação à criatura. Mas, em Deus, a relação com a criatura não é real, senão somente
racional. Porém, a relação da criatura com Deus é real, como já antes se disse quando se tratou dos
nomes divinos.

RESPOSTA À SEGUNDA. – Sendo a criação significada como mutação, como já se disse; e sendo a
mutação um termo médio, de certo modo, entre o movente e o movido, resulta que a criação é
significada como termo médio entre o Criador e a criatura. E contudo a criação, em acepção passiva,
está na criatura e é criatura. E nem por isso é necessário que esta seja criada por uma outra criação;
porque as relações, referindo-se a outra coisa, pelo fato mesmo de serem tais, não se referem por
algumas outras relações, mas por si mesmas, como já antes se disse, quando se tratou da igualdade das
pessoas.

RESPOSTA À TERCEIRA. – O ser criado é termo da criação enquanto esta significa mutação; mas
enquanto verdadeiramente ela é relação, o criado é o sujeito dela e anterior a ela no ser, como o sujeito
é anterior ao acidente. Mas a criação tem certa razão de prioridade, por parte do objeto ao qual se
refere, porque é princípio do criado. Mas nem por isso há-se necessariamente de dizer que, enquanto
existe a criatura é criada, pois a criação importa de· novo ou em começo, a relação da criatura com o
Criador.

## Art. 4 — Se ser criado é próprio dos seres compostos e subsistentes.
(De Pot., q. 3, a. 1, ad 12; a. 3, ad 2; a. 8, ad 3; De Verit., q. 27, a. 3, ad 9; Quot., IX, q. 5, a. 1;
Opusc.XXXVII; De Quatuor Opposit., cap. IV).
O quarto discute-se assim. – Parece que ser criado não é próprio dos seres compostos e subsistentes.

1. – Pois, se diz no livro De causis: A primeira das coisas criadas é o ser. Ora, o ser da coisa criada não é
subsistente. Logo, a criação não é própria do ser subsistente e composto.

2. Demais. – É criado o que vem do nada. Ora, os seres compostos não provêm do nada, mas dos seus
componentes. Logo, não convém aos entes compostos o serem criados.
3·. Demais. – É propriamente produzido pela primeira emanação, o que é suposto na segunda; assim, a
coisa natural é produzida pela geração natural, que é suposta na operação da arte. Ora, o que é suposto
na geração natural é a matéria. Logo, a matéria é que propriamente é criada e não o composto.
Mas, em contrário,a Escritura (Gn 1, 1): No princípio criou Deus o céu e a terra. Ora, o céu e a terra são
coisas compostas subsistentes. Logo, são propriamente criadas.

SOLUÇÃO. – Como já se disse, ser criado é de certo modo vir a ser. Ora, este se ordena ao ser da coisa.
Por onde, convém propriamente o vir a ser e o ser criado aos entes aos quais convém o ser. Ora, tal
convém propriamente aos seres subsistentes, quer simples como as substâncias separadas, quer
compostos como as substâncias materiais. Pois, o ser propriamente convém ao que o tem, e esse é
subsistente no seu ser. Porém as formas, os acidentes e outras coisas semelhantes não se chamam
seres, como se por si existissem, mas porque por elas alguma coisa existe; assim à brancura se chama
ser porque por ela um sujeito é branco. Donde, segundo o Filósofo, do acidente mais propriamente se
diz que é do ser, do que ser. Portanto, assim como os acidentes, as formas e atribuições semelhantes,
não subsistentes, são mais coexistentes do que entes; assim, mais se devem chamar concriadasdo que
criadas. Pois propriamente criados são os seres subsistentes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Quando se diz que a primeira das coisas criadas é o ser, a
palavra ser não importa a substância criada, mas a razão própria do objeto da criação. Pois, uma coisa se
diz criada porque é ser, e não porque é tal ser; porquanto a criação é o emanar o ser total do ser
universal, como já se disse. Um modo semelhante de falar seria dizer que o primeiro visível é a
cor, embora o que propriamente é visto seja um objeto colorido.

RESPOSTA À SEGUNDA. – Criação não significa constituição de uma coisa composta por princípios
preexistentes; mas se diz que um composto é criado quando é produzido para o ser simultaneamente
com todos os seus princípios.

RESPOSTA À TERCEIRA. – A objeção não prova que só a matéria seja criada; mas que a matéria não
existe senão por criação. Pois a criação é a produção do ser total e não só da matéria.

## Art. 5 — Se só Deus pode criar.
(Infra. q. 65, a. 3; 90, a. 3; II Sent., dist. I, q. 1, a. 3; IV, dist. V, q. 1, a. q.ª 3; II Cont. Gent., cap. XX, XXI,De
Verit., q. 5, a. 9, De Pot., q. 3, a. 4; Quodl., III, q. 3, a. 1; Compend. Theol., cap. LXX; Opusc. XV, De
Angelis, cap. X; XXXVII, De Quatuor Opposit., cap. VI).
O quinto discute-se assim. – Parece que nem só Deus pode criar.

1. – Pois, segundo o Filósofo, perfeito é o que pode fazer algo de semelhante a si. Ora, as criaturas
imateriais são mais perfeitas que as materiais; e estas últimas fazem outras semelhantes a si, pois o fogo
gera o fogo e o homem, o homem. Logo, a substância imaterial pode fazer outra semelhante a si; mas
não o pode fazer senão por criação, porque não tem matéria com que faça. Portanto, alguma criatura
pode criar.

2. Demais. – Quanto maior é a resistência por parte da coisa feita, tanto maior virtude se requer no que
faz. Ora, mais resiste o contrário do que o nada. Logo, maior virtude há em fazer alguma coisa de um
contrário – o que todavia a criatura faz – do que fazer alguma coisa do nada. Portanto, com maioria de
razão, a criatura pode fazer tal.

3. Demais. – A virtude de quem faz se considera segundo a medida do que é feito. Ora, o ser criado é
finito, como já se provou quando se tratou da infinidade de Deus. Logo, para produzir por criação algo
criado, não se requer mais que uma virtude finita. Mas ter uma virtude finita não é contra a natureza da
criatura. Logo, não é impossível a criatura criar.
Mas, em contrário,diz Agostinho que nem os bons nem os maus anjos podem ser criadores de nada.
Portanto, muito menos as outras criaturas.

SOLUÇÃO. – Como aparece logo, à primeira vista e segundo o que já se demonstrou, criar não pode ser
ação própria senão de Deus somente. Pois, é necessário que os efeitos mais universais sejam reduzidos
a causas mais universais e primeiras. Ora, dentre todos os efeitos, o mais universal é o ser em si mesmo.
Por onde, importa seja ele o efeito próprio da causa primeira e universalíssima que é Deus. E por isso
também se diz que nem a inteligência nem a alma nobre dá o ser senão enquanto opera por operação
divina. Porém, produzir o ser em absoluto, e não enquanto tal ou tal, pertence à noção de criação. Por
onde é manifesto, que a criação é ação peculiar do próprio Deus.
Pode dar-se, porém, que uma coisa participe da ação peculiar a outra, não por virtude própria, mas
instrumentalmente, enquanto age por virtude dessa outra; assim o ar, por virtude do fogo, pode
aquecer e queimar. E por isso alguns opinaram que, embora a criação seja ação própria de uma causa
universal, contudo uma causa inferior, enquanto age em virtude da causa primeira, pode criar. E assim
ensinou Avicena que a substância primeira separada, criada por Deus, cria outra depois de si, e a
substância do orbe com a sua alma; e que a substância do orbe cria a matéria dos corpos inferiores. E
também, do mesmo modo, o Mestre das Sentenças diz que Deus pode comunicar à criatura o poder de
criar, de modo a criar por ministério e não por autoridade própria.
Mas isto não pode ser. Pois, a causa segunda instrumental não participa da ação da causa superior,
senão enquanto, por alguma causa que lhe é própria, coopera para o efeito do agente principal. Pois, se
assim não agisse, segundo o que lhe for próprio, em vão se esforçaria para agir; e nem seria necessário
haver instrumentos determinados de determinadas ações. Assim vemos que o machado, cortando a
madeira, fabrica um escabelo, efeito próprio do agente principal. Mas o efeito próprio de Deus criador –
o ser em absoluto – é pressuposto a todos os outros. Por onde não pode nenhum outro ser cooperar
dispositiva e instrumentalmente para tal efeito, porque a criação não depende de um pressuposto que
possa ser disposto por ação do agente instrumental.Assim que é impossível convenha a alguma criatura
o criar, quer por virtude própria, quer instrumentalmente, quer por ministério.
E, sobretudo, é impróprio dizer que um corpo crie, pois nenhum corpo age senão por contacto ou
movendo; e assim requer para a sua ação algo de preexistente que possa ser tocado ou movido; o que é
contra a noção de criação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Um ser perfeito, participante de alguma natureza, faz
outro semelhante a si; não por certo produzindo absolutamente tal natureza, mas aplicando-a a alguma
coisa. Assim tal homem não pode ser causa da natureza humana absolutamente, porque então seria
causa de si mesmo; mas é causa de existir a natureza humana num outro homem gerado, pressupondo,
portanto, para a sua ação uma matéria determinada pela qual é tal homem. Mas, assim como o homem
participa da natureza humana, assim também qualquer ser criado participa, para que assim digamos, da
natureza de existir, porquanto só Deus é o ser, como antes se viu (q. 7, a. 1, ad 3; a. 2). Por onde,
nenhum ser criado pode produzir algum ente absolutamente, senão enquanto causa nesteo ser; e assim
é necessário que aquilo pelo que alguma coisa é tal serse preintelija à ação pela qual faz algo de
semelhante a si. Ora, na substância imaterial não se pode preinteligir nada pelo que ela seja tal, porque
ela é tal pela sua forma, pela qual tem o ser, pois as substâncias imateriais são formas subsistentes.
Logo, a substância imaterial não pode produzir outra semelhante a si, quanto ao ser desta, mas quanto
a alguma perfeição superveniente, como se dissermos que um anjo superior ilumina o inferior, segundo
está em Dionísio. E conforme tal modo também nos seres celestes há paternidade, consoante as
palavras do Apóstolo (Ef 3, 15): Do qual toda a paternidade toma onome nos céus e na terra. E disto
evidentemente resulta que nenhum ser criado pode causar alguma coisa, salvo pressupondo-se outra
coisa; o que repugna à noção de criação.

RESPOSTA À SEGUNDA. – De um contrário alguma coisa se faz por acidente, como diz Aristóteles;
porém, em si, alguma coisa se faz de um sujeito em potência. Pois, o contrário resiste ao agente,
privando a potência do ato ao qual o agente tende a reduzir a matéria; assim o fogo tende a reduzir a
água a um ato semelhante a ele, mas é impedido pela forma e pelas disposições contrárias pelas quais a
potência é como que ligada para que se não reduza ao ato. E quanto mais ligada estiver a potência,
tanto maior virtude se requer no agente para reduzir a matéria ao ato. Por onde, muito maior virtude se
requer no agente se não preexistir nenhuma potência. E assim é claro que muito maior virtude é fazer
alguma coisa do nada do que do contrário.

RESPOSTA À TERCEIRA. – A virtude de quem faz não se considera somente na substância da coisa feita,
mas também no modo de fazer; assim, o maior calor não somente aquece mais senão ainda mais
rapidamente. Embora, pois, causar um efeito finito não demonstre poder infinito, todavia causá-lo do
nada demonstra tal poder, o que resulta claro do já dito. Se pois, tanto maior virtude se requer no
agente quanto mais remota do ato estiver a potência, necessário é que a virtude de um agente,
nenhuma potência sendo pressuposta, como é o agente infinito, seja infinita; porque nenhuma
proporção entre uma potência e outra, que pressupõe a virtude de um agente natural, é como a
proporção entre o não-ser e o ser. E como nenhuma criatura tem pura e simplesmente um poder
infinito, nem um ser infinito, conforme já antes se provou, resulta que nenhuma criatura pode criar.

## Art. 6 — Se criar é próprio de uma das Pessoas.
(II Sent., prol.; De Pot., q. 9, a. 5. ad 20).
O sexto discute-se assim. – Parece que criar é próprio de uma das Pessoas.

1. – Pois, o anterior é causa do posterior, e o perfeito, do imperfeito. Ora, a processão da divina Pessoa
é anterior à da criatura e mais perfeita; porque a divina Pessoa procede por semelhança perfeita do seu
princípio, ao passo que a criatura procede por semelhança imperfeita. Logo, as processões das divinas
Pessoas são a causa da processão das coisas.E assim, criar é próprioda pessoa.

2. Demais. – As Pessoas divinas não se distinguem entre si senão pelas suas processões e relações.
Portanto, o que é diferentemente atribuído às divinas Pessoas convém-lhes segundo as processões e
relações delas. Ora, a causalidade das criaturas lhes é diversamente atribuída; pois, no Símbolo da
fé(Niceno) atribui-se ao Pai o ser Criadorde todas as coisas visíveis e invisíveis; ao Filho, porém, que por
ele todas as coisas foram feitas; e por fim ao Espírito santo, que é o Senhor e o vivificador. Logo, a
causalidade das criaturas convém às Pessoas segundo processões e relações.

3. Demais. – Se se disser que a causalidade da criatura é considerada segundo algum atributo essencial
apropriado a uma das Pessoas, isso não parece suficiente. Porque qualquer efeito divino é causado por
qualquer atributo essencial, a saber, o poder, a bondade e a sapiência e, assim, não pertence mais a um
que a outro. Logo, um determinado modo de causalidade não deve ser atribuído a uma Pessoa antes
que a outra, salvo se se distinguirem as Pessoas, na criação, segundo relações e processões.
Mas, em contrário,diz Dionísio que todas as causalidades são comuns a toda a divindade.

SOLUÇÃO. – Criar é propriamente causar ou produzir o ser das coisas. Ora, como todo agente age
conforme a natureza que tem, o princípio da ação podemos considerá-la pelo efeito da mesma; assim, é
o fogo que gera o fogo.Portanto, criar convém a Deus segundo o seu ser, que é a sua essência, a qual é
comum às três Pessoas. Por onde, criar não é próprio a uma qualquer das Pessoas, mas comum à toda a
Trindade.
Contudo, as divinas Pessoas, segundo a natureza da processão delas, exercem a causalidade em relação
à criação das coisas. Pois, como já se demonstrou antes, quando se tratou da ciência e da vontade de
Deus, Deus é a causa das coisas pelo intelecto e pela vontade, assim como o artífice é causa das coisas
artificiadas. Mas este opera pelo verbo concebido no intelecto e pelo amor da vontade referido a algum
objeto. Por onde, Deus Padre fez a criatura pelo seu Verbo que é o Filho; e pelo seu Amor, que é o
Espírito santo. E, deste modo, as processões das Pessoas são as razões da produção das criaturas,
enquanto incluem os atributos essenciais, que são a ciência e a vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As processões das divinas Pessoas são a causa da criação,
conforme foi dito.

RESPOSTA À SEGUNDA. – Assim como a natureza divina, embora comum às três Pessoas, convém-lhes
contudo numa certa ordem, enquanto o Filho recebe a natureza divina do Pai, e o Espírito Santo, de
ambos; assim também, a virtude de criar, embora comum às três pessoas, convém-lhes contudo numa
certa ordem, pois o Filho a tem do Pai, e o Espírito Santo, de ambos. Por onde, o ser Criador se atribui
ao Pai como a quem não recebe de outrem a virtude de criar. Do Filho porém se diz – Todas as coisas
foram feitas por ele, – enquanto tem a mesma virtude, mas recebida de outrem; pois a
preposição pordenota de ordinário a causa média ou o princípio proveniente de outro princípio. Mas ao
Espírito Santo, que recebe de ambos a mesma virtude, atribui-se-lhe, que, dominando, governe e
vivifique as coisas criadas pelo Pai por meio do Filho. – E também pode a razão comum destaatribuição
ser deduzida da apropriação dos atributos essenciais. Pois, como já antes se disse, ao Pai é atribuído e
apropriado o poder, que se manifesta maximamente na criação; e por isso lhe é atribuído o ser Criador.
Ao Filho, porém, apropria-se a sabedoria, em virtude da qual o agente opera pelo intelecto; e por isso se
diz do Filho: Todas as coisas foram feitas por ele. Ao passo que ao Espírito Santo se apropria a bondade,
à qual pertence o governo, que conduz as coisas aos devidos fins, e a vivificação, porque a vida consiste
num movimento interior, e o primeiro movente é o fim e a bondade.

RESPOSTA À TERCEIRA. – Embora qualquer efeito de Deus proceda de qualquer dos atributos, contudo
cada efeito se reduz ao atributo com o qual tem conveniência, segundo a razão própria; assim a
ordenação das coisas, com a sabedoria; e a justificação do ímpio, com a misericórdia e a bondade que se
difunde com superabundância. Porém a criação, produção da própria substância da coisa, reduz-se ao
poder.

## Art. 7 — Se necessariamente se encontra nas criaturas o vestígio da Trindade.
(Infra, q. 93, a. 6; I Sent., disto III, q. 2, a. 2; IV Cont. Gent., cap. XXVI: De Pot., q. 9, a. 9).
O sétimo discute-se assim. – Parece não se encontrar necessàriamente nas criaturas o vestígio da
Trindade.

1. – Qualquer ser pode se investigar pelos seus vestígios. Ora, a Trindade das Pessoas não pode ser
investigada partindo das criaturas, como já antes se disse. Logo, vestígios da Trindade não há nas
criaturas.

2. Demais. – Tudo o que há na criatura é criado. Se, pois, o vestígio da Trindade se encontra nas
criaturas, por alguma das propriedades destas, é forçoso haja também em cada uma delas o vestígio da
Trindade; e assim ao infinito.

3. Demais. – Um efeito não representa senão a sua causa. Ora, a causalidade das criaturas pertence à
natureza comum, mas não às relações pelas quais as Pessoas se distinguem e enumeram. Logo, na
criatura não se encontra o vestígio da Trindade, mas somente da unidade de essência.
Mas, em contrário,diz Agostinho, que o vestígio da Trindade aparece nas criaturas.

SOLUÇÃO. – Todo efeito representa de certa maneira a sua causa, mas de diversos modos. Pois, tal
efeito representa somente a causalidade e não a forma da causa; assim, o fumo representa o fogo. E tal
representação se chama representação do vestígio; pois, o vestígio indica o passar de algum transeunte,
não porém qual este seja. Mas tal outro efeito representa a causa quanto à semelhança da forma dela;
assim o fogo gerado representa o fogo gerador e a estátua de Mercúrio, Mercúrio. E esta é a represen-
tação da imagem. Ora, as processões das divinas Pessoas se consideram relativamente aos atos do
intelecto e da vontade, como já se disse. Pois, o Filho procede como Verbo do intelecto e o Espírito
Santo, como Amor da vontade. Por onde, nas criaturas racionais, em que há intelecto e vontade,
encontra-se a representação da Trindade, a modo de imagem, enquanto nelas se encontram o verbo
concebido e o amor procedente. Porém em todas as criaturas se encontra a representação da Trindade
a modo de vestígio, enquanto que em qualquer delas se encontram certos aspectos que de necessidade
se hão de reduzir às divinas Pessoas como à causa. Pois, qualquer criatura subsiste no seu ser, tem uma
forma pela qual está numa determinada espécie, e se ordena a algum outro ser. Portanto, enquanto é
uma certa substância criada, representa a causa e o princípio e demonstra, assim, a pessoa do Pai, que é
princípio sem princípio. Enquanto porém tem uma certa forma e espécie, representa o Verbo, porque a
forma do artificiado provém da concepção do artífice. E, por fim, enquanto ordenada, representa o
Espírito Santo, que é Amor; porquanto a ordem do efeito para outra coisa, provém da vontade do
criador. E por isso diz Agostinho, que o vestígio da Trindade se encontra em cada criatura, enquanto
é alguma coisa determinada, é formada por alguma espécie e tem uma certa ordem. E a isto se reduzem
aqueles três aspectos – número, peso e medida– de que fala a Escritura (Sb 9); pois a medida se refere à
substância da coisa limitada pelos seus princípios; o número, à espécie; o peso, à ordem. E ainda a estes
três aspectos se reduzem outros três de que fala Agostinho: o modo, a espécie e a ordem.Assim como o
de que fala alhures: o que consta, o que é discernido e o que é congruente: pois alguma coisa subsiste,
pela sua substância; é discernida, pela forma, é congruente, pela ordem. Sendo que a isto facilmente
pode ser reduzido tudo o que de semelhante for dito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A representação do vestígio funda-se nas coisas
apropriadas; desse modo se pode chegar, pelas criaturas, à Trindade das divinas pessoas, como já se
disse.

RESPOSTA À SEGUNDA. – A criatura é um ser propriamente subsistente, na qual se encontram os três
aspectos referidos; nem é necessário que em cada uma das propriedades da criatura se encontrem os
três aspectos; mas, na medida deles é que o vestígio se atribui à coisa subsistente.

RESPOSTA À TERCEIRA. – Também as processões das Pessoas são causa e razão da criação, de certo
modo, como se disse.

## Art. 8 — Se há criação nas obras da natureza e da arte.
(II Sent., dist. I. q. 1, a. 3, ad 5; a. 4, ad 4; De Pot., q. 3, a. 8; VII Metaphys., Lect. VII).
O oitavo discute-se assim. – Parece haver criação nas obras da natureza e da arte.

1. – Pois, em qualquer obra da natureza e da arte se produz alguma forma. Ora, esta não é produzida de
alguma coisa, porque, por sua parte, não tem matéria. Logo, é produzida do nada. Assim que, em
qualquer operação da natureza e da arte há criação.

2. Demais. – O efeito não é mais poderoso que a causa. Ora, nas coisas naturais só se encontra, como
agente, a forma acidental, que é forma ativa ou passiva. Logo, por operação da natureza, não se produz
nenhuma forma substancial. Resta, portanto, que o seja por criação.

3. Demais. – A natureza faz o semelhante a si. Ora, encontram-se certos seres gerados, em a natureza,
que não o são por algo de semelhante a eles, como é claro nos animais gerados por putrefação. Logo, a
forma deles não provém da natureza, mas existe por criação. E idêntica é a razão em casos similares.

4. Demais. – O que não é criado não é criatura. Se, pois nos seres da natureza não há criação, segue-se
que não são criaturas; o que é herético.
Mas, em contrário,Agostinho distingue a obra da propagação, que é obra da natureza, da de criação.

SOLUÇÃO. – A dúvida presente é suscitada por causa das formas. Sobre as quais alguns, admitindo-as
como latentes, ensinaram que não começam por ação da natureza, mas que já existiam anteriormente
na matéria. E estes assim ensinaram por ignorância do que seja a matéria, não sabendo distinguir entre
a potência e o ato. Pois, por preexistirem as formas potencialmente na matéria, admitiram-nas como
absolutamente preexistentes. Outros, porém, ensinaram que as formas são produzidas ou causadas por
um agente separado, a modo de criação; e, segundo estes, há criação em qualquer operação da
natureza. Mas assim o ensinaram por ignorarem o que seja a forma. Pois, não consideravam que a
forma natural do corpo não é subsistente, mas é o meio pelo qual alguma coisa existe. Assim, pois, que,
como o ser feito e o ser criado convenham propriamente só ao ser subsistente, como já se disse, não é
próprio das formas o serem feitas nem criadas, mas o serem concriadas. O que, porém, se faz por um
agente natural é composto, porque é feito da matéria. Por onde, nas obras da natureza, não há criação,
mas algo se pressupõe à operação da natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As formas começam a existir em ato quando os
compostos estão feitos; não que elas sejam feitas por si, mas somente por acidente.

RESPOSTA À SEGUNDA. – As qualidades ativas em a natureza agem em virtude das formas substanciais.
Por onde, o agente natural não somente produz um semelhante a si pela qualidade, mas pela espécie.

RESPOSTA À TERCEIRA. – Para a geração dos animais imperfeitos basta o agente universal, que é a
virtude celeste, à qual eles se assemelham, não pela espécie, mas por certa analogia; nem vale dizer que
as formas deles são criadas por um agente separado. Porém para a geração dos animais perfeitos não
basta o agente universal, mas se requer um agente próprio, que é um gerador unívoco.

RESPOSTA À QUARTA. – A operação da natureza pressupõe princípios criados; assim que, as coisas
feitas pela natureza se chamam criaturas.