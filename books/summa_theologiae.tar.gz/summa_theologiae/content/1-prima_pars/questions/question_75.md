# Questão 75: Da alma em si mesma.
Depois da consideração da criatura espiritual e corpórea, é mister considerar o homem, composto da
substância espiritual e corpórea. E, primeiro, a natureza do homem mesmo; segundo, a sua produção.
Ora, considerar a natureza do homem, quanto à alma, pertence ao teólogo; não porém, quanto ao
corpo, senão para tratar da relação que tem este com aquela. Por onde, a primeira consideração versará
sobre a alma. E como, segundo Dionísio, três coisas se encontram nas substâncias espirituais, a saber, a
essência, a virtude e a operação, consideraremos, primeiro, as coisas pertencentes à essência da alma;
segundo, as pertencentes à virtude ou às potências dela; terceiro, as pertencentes à sua operação.
Sobre o primeiro ponto ocorre dupla consideração: a primeira é a da alma mesmo, em si; a segunda é a
da sua união como o corpo.
Sobre a primeira destas duas considerações sete artigos se discutem:

## Art. 1 — Se a alma é corpo.
(III Cont. Gent., cap. LXV; II De Anima, lect.I).
O primeiro discute-se assim. ― Parece que a alma é corpo.

1. ― Pois, a alma é o motor do corpo. Ora, não há motor não movido. Primeiro, porque, parece só pode
mover aquilo que é movido, pois, ninguém dá a outrem o que não tem; assim, o que não é quente não
aquece. Segundo, porque o que se move sem ser movido, causaria o movimento sempiterno, sempre
atualmente do mesmo modo, como o prova Filósofo; ora, tal não se vê no movimento do animal,
proveniente da alma. Logo esta é um motor movido. Mas, como todo motor movido é corpo, a alma,
logo também o é.

2. Demais. ― Todo conhecimento se realiza por alguma semelhança. Ora, nenhuma semelhança pode
haver entre um corpo e um ser incorpóreo; se, pois, a alma não fosse corpo não poderia conhecer as
coisas corpóreas.

3. Demais. ― É preciso haver algum contato do motor com o movido. Ora o contato só há entre corpos.
Logo, como a alma move o corpo, resulta que não é corpo.
Mas, em contrário, diz Agostinho, que a alma é dita simples por comparação com o corpo, porque não
se difunde pela massa no espaço local.

SOLUÇÃO. ― Para discutir a natureza da alma, é necessário pressupô-la como o primeiro princípio da
vida dos seres vivos; assim, dizemos que os seres animados são vivos e as coisas inanimadas carecem de
vida. Ora, esta se manifesta maximamente pela dupla operação do conhecimento e do movimento, cujo
princípio os antigos filósofos, não podendo transcender a imaginação, consideravam como corpo; pois,
diziam, só os corpos são coisas e o que não é corpo nada é. E então, consideravam a alma como um
certo corpo. Ora, embora se possa mostrar, de múltiplos modos, a falsidade dessa opinião,
empreguemos só um argumento com o qual mais comum e certamente se patenteará que a alma não é
corpo. Assim, é manifesto, a alma não é um princípio qualquer da operação vital; pois, se o fosse, então
os olhos, princípio da visão, seriam a alma; o mesmo devendo dizer-se dos outros instrumentos desta.
Mas, chamamos alma ao princípio primeiro da vida. Pois, embora algum corpo possa ser um certo
princípio da vida, como o coração o é, no animal; contudo não pode ser o princípio primeiro da vida de
qualquer corpo. Ora, é manifesto, ser princípio da vida ou vivente não cabe ao corpo como tal; do
contrário todo corpo seria vivo ou princípio da vida. Logo, só cabe a um certo corpo como tal ser vivo,
ou ainda, princípio da vida. Ora, o que torna esse corpo atualmente tal é algum princípio, chamado o
seu ato. Por onde, a alma, princípio primeiro da vida, não é corpo, mas o ato dele, assim como o calor,
princípio da calefação, não é corpo, mas um ato do corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Sendo tudo o que se move movido por outro, e como
não se pode continuar assim até o infinito, necessário é dizer-se que nem todo motor é movido. Pois,
ser movido sendo o passar da potência para o ato, o motor dá o que tem ao móvel, atualizando-o. Mas,
como o demonstra o Filósofo, há um certo motor absolutamente imóvel, não movido nem por si nem
por acidente; e tal motor pode mover o movido sempre uniformemente. Há, porém, outro motor
movido, não por si, mas por acidente e que, por isso, não move o movido sempre uniformemente; e tal
motor é a alma. E há, ainda, outro motor não movido por si, e que é o corpo. E como os antigos filósofos
da natureza pensavam que só o corpo existe, ensinavam que todo motor é movido e que a alma, movida
por si, é também corpo.

RESPOSTA À SEGUNDA. ― Não é necessário que a semelhança da causa conhecida esteja atualmente
em a natureza do conhecente; mas, se há algo que conhece, primeiro, em potência e, depois, em ato,
não é necessário que a semelhança do conhecido seja atual, senão apenas potencial, em a natureza do
conhecente; assim, a cor está na pupila, não atual mas só potencialmente. Por onde, não é necessário
que, em a natureza da alma, haja a semelhança atual das coisas corpóreas, mas sim que ela seja
potencial em relação a tais semelhanças. Como, porém, os antigos filósofos da natureza não sabiam
distinguir entre o ato e a potência, diziam que a alma é corpo para poder conhecer todos os corpos; e
que é composta dos princípios de todos os corpos.

RESPOSTA À TERCEIRA. ― Há um duplo contacto: o da quantidade e o da virtude. Pelo primeiro, o
corpo só pode ser tocado pelo corpo; pelo segundo, pode ser facada por um ser incorpóreo que o mova.

## Art. 2 — Se a alma humana é algo de subsistente.
(De Pot.,q. 3, a. 9, 11; De Spirit.Creat., a. 2 Qu. De Anima, a.1, 14; III De Anima, lect. VII).
O segundo discute-se assim. ― Parece que a alma humana não é algo de subsistente.

1. ― Pois, o que é subsistente é um determinado ser. Ora, a alma não é um determinado ser, mas um
composto de corpo e alma. Logo não é ela algo de subsistente.

2. Demais. ― Tudo o que é subsistente pode ser considerado capaz de operação. Ora, a alma não é
assim considerada, pois, segundo o Filósofo, dizer que a alma sente ou intelige é o mesmo que dizer
alguém que ela tece ou edifica. Logo, a alma não é algo de subsistente.

3. Demais. ― Se a alma fosse algo de subsistente, alguma operação dela haveria, independente do
corpo. Mas nenhuma das suas operações é assim, nem ainda o inteligir, porque não é possível inteligir
sem fantasma e os fantasmas não existem sem o corpo. Logo, a alma humana não é algo de subsistente.
Mas, em contrário, diz Agostinho: Quem vê a natureza da mente, que é substância, mas não corpórea,
vê que os que opinam ser ela corpórea erram por lhe adjungirem as fantasias dos corpos, sem as quais
não podem conceber nenhuma natureza. Logo, a natureza da alma humana não só é incorpórea, mas
também é substância, isto é, algo de subsistente.

SOLUÇÃO. ― Necessário é admitir-se que o princípio da operação intelectual, a que chamamos alma do
homem, é um certo princípio incorpóreo e subsistente. Pois, é manifesto, pela inteligência o homem
pode conhecer a natureza de todos os corpos. Ora, o que pode conhecer certas causas,
necessariamente não deve ter nada delas, na sua natureza, porque a causa que a esta fosse
naturalmente inerente impedir-lhe-ia o conhecimento das outras. Assim, vemos que a língua do doente,
afetada de humor colérico e amargo, nada pode sentir de doce, mas tudo lhe parece amargo. Se, pois, o
princípio intelectual tivesse em si a natureza de algum corpo, não poderia conhecer todos os corpos,
porque cada corpo tem a sua natureza determinada. Logo, é impossível que o princípio intelectual seja
corpo. E, semelhantemente, também é impossível que intelija por meio de órgão corpóreo, porque
também a natureza determinada desse órgão corpóreo impediria o conhecimento de todos os corpos.
Assim, se uma determinada cor estivesse, não só na pupila, mas ainda num vaso de vidro, o líquido
contido neste seria dessa mesma cor. Por onde, o princípio intelectual chamado alma ou intelecto, tem
a sua operação própria, não comum com o corpo. Ora, só pode operar por si o que por si subsiste, pois
operar só é próprio do ser atual. Por isso, uma causa opera dó mesmo modo pelo qual existe e, assim,
não dizemos que o calor aquece, mas que é cálido. Logo, conclui-se que a alma humana, chamada
intelecto ou mente, é algo de incorpóreo e subsistente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Um determinado ser pode compreender-se de duplo
modo: significando qualquer subsistente, ou um subsistente completo em a natureza de alguma
espécie. O primeiro modo exclui a inerência acidental e a da forma material. O segundo exclui também a
imperfeição da parte. Assim, pode-se dizer que a mão é um determinado ser, no primeiro sentido, não,
porém, no segundo. E, portanto, sendo a alma humana parte da espécie humana, pode chamar-se um
determinado ser, segundo o primeiro modo, como algo de quase subsistente; mas não conforme o
segundo, que é o em que se chama algo de determinado o composto de alma e corpo.

RESPOSTA À SEGUNDA. ― Aristóteles usa dessas palavras, não para exprimirem opinião própria, mas a
dos que diziam que inteligir é ser movido, como é claro pelo que afirma antes. ― Ou deve dizer-se que o
agir por si convém ao que existe por si. Ora, o existir por si pode-se atribuir a alguma causa que não seja
inerente como acidente ou como forma material, mesmo se for parte. Mas diz-se que é, propriamente,
subsistente por si o que nem é inerente desse predito modo, nem é parte; e segundo este modo de
dizer, o olho ou a mão não se pode considerar subsistente por si e, por conseqüência, nem como
operando por si. Por onde, também as operações das partes se atribuem ao todo, por meio delas; assim
dizemos que o homem vê com os olhos e apalpa com as mãos; diferentemente de quando dizemos que
o cálido aquece pelo calor, pois, propriamente falando, o calor de nenhum modo aquece. Logo, pode-se
dizer que a alma intelige como o olho vê; mas é mais próprio dizer-se que o homem intelige por meio da
alma.

RESPOSTA À TERCEIRA. ― O corpo é necessário para a ação do intelecto, não como o órgão pelo qual
tal ação se exerce, mas em razão do objeto; pois os fantasmas estão para o intelecto como a cor para o
sentido. Assim que, o precisar do corpo não impede, seja o intelecto subsistente; do contrário, o animal
não seria algo de subsistente, por precisar dos sensíveis exteriores para sentir.

## Art. 3 — Se as almas dos brutos são subsistentes.
(II. Cont. Gent., cap. LXXXII).
O terceiro discute-se assim. ― Parece que as almas dos brutos são subsistentes.

1. ― O homem tem o mesmo gênero que os outros animais. Ora, a alma humana é algo de subsistente,
como já se demonstrou (a. 2). Logo, também as dos outros animais.

2. Demais. ― O sensitivo está para os sensíveis como o intelectivo para os inteligíveis. Ora, o intelecto
intelige, sem o corpo, os inteligíveis. Logo também, do mesmo modo, o sentido apreende os sensíveis.
Ora; as almas dos brutos são sensitivas. Logo, são subsistentes, pela mesma razão por que o é a alma
intelectiva do homem.

3. Demais. ― A alma dos brutos move-lhes o corpo. Ora, este não move mas é movido. Logo, aquela
tem alguma operação independente do corpo.
Mas em contrário, foi dito: Cremos que só o homem tem alma substantiva; e não são substantivas as
almas dos animais.

SOLUÇÃO. ― Os antigos filósofos não faziam nenhuma distinção entre o sentido e o intelecto; e
atribuíam ambos a um princípio corpóreo, como já se disse (a. 1). ― Porém Platão distinguia entre o
intelecto e o sentido, atribuindo ambos a um princípio incorpóreo e dizendo que, como o inteligir,
também o sentir convém à alma, em si mesma. E daí resultava que também as almas dos brutos são
subsistentes. ― Mas Aristóteles estabeleceu que só o inteligir, entre as operações da alma, se exerce
sem órgão corpóreo. Porém, o sentir, bem como as operações resultantes das operações da alma
sensitiva, manifestamente se realizam com alguma imutação do corpo; assim, na visão, imuta-se a
pupila, pela contemplação da cor, o mesmo se dando com as outras operações semelhantes. Por onde é
manifesto que a alma sensitiva não tem, por si mesma, nenhuma operação própria, mas toda operação
da alma sensitiva pertence ao conjunto. Donde resulta que as almas dos brutos, não operando por si
mesmas, não são subsistentes, pois, cada ser tem, de maneira semelhante, o ser e a operação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O homem, tendo o mesmo gênero que os outros
animais, deles difere pela espécie. Ora, a diferença específica depende da diferença formal. Nem é
necessário que toda diferença formal importe na diversidade genérica.

RESPOSTA À SEGUNDA. ― O sensitivo, de certo modo, está para os sensíveis, como o intelectivo para os
inteligíveis, a saber, enquanto ambos são potenciais em relação aos seus objetos. Mas, de certo modo,
comportam-se dissemelhantemente; pois, o sensitivo sofre a ação do sensível, com imutação do corpo
e, por isso, a excelência dos sensíveis corrompe o sentido. Ao passo que isso não se dá com o intelecto,
pois, este, inteligindo os máximos inteligíveis, mais facilmente poderá inteligir os menores. E se, no
inteligir, o corpo se fatiga, isso o é só por acidente; porque o intelecto precisa da operação das forças
sensitivas, pelas quais lhe são preparados os fantasmas.

RESPOSTA À TERCEIRA. ― A força motiva é dupla. Uma, a apetitiva, que governa o movimento, e a
operação dessa, na alma sensitiva, não se realiza sem o corpo; assim, a ira, a alegria e outras paixões
semelhantes supõem certa imutação do coração. A outra força motiva é a que resulta do movimento,
pela qual os membros tornam-se capazes de obedecer ao apetite; e o ato dessa força não é mover, mas
ser movido. Por onde se evidencia que mover não é ato da alma sensitiva que se realize sem o corpo.

## Art. 4 — Se a alma é o homem.
(III Sent., dist., V, q. 3, a. 2; dist. XXII, q. 1, a. 1; II Cont. Gent., cap. LVII; Opusc. XVI, De Unit. Intell.; De
Ent. Et Ess., cap. II;VII Metaphys., lect IX).
O quarto discute-se assim. ― Parece que a alma é o homem.1. ― Pois, diz a Escritura (2 Cor 4, 16): Essa
é a razão porque não desfalecemos; mas ainda que se destrua em nós o homem exterior, todavia o
interior se vai renovando de dia em dia. Ora, o que no homem é interior é a alma. Logo, a alma é o
homem interior.

2. Demais. ― A alma humana é uma determinada substância, mas não é a substância universal. Logo, é
particular e, portanto, hipóstas e ou pessoa e não outra senão humana. Logo, a alma é o homem; pois, a
pessoa humana é o homem.
Mas, em contrário, Agostinho elogia Varrão dizendo que o homem não é só alma, nem só corpo, mas
simultaneamente, alma e corpo.

SOLUÇÃO. ― Que a alma seja o homem, pode-se entender de dois modos. De um modo, que o homem
é a alma, mas não este determinado homem, composto de alma e corpo, como Sócrates. E digo assim
porque certos ensinaram que só a forma pertence à natureza da espécie, sendo a matéria parte do
indivíduo e não da espécie.― O que certamente não pode ser verdadeiro. Pois, à natureza da espécie
pertence aquilo que significa a definição. Ora, a definição, nas coisas naturais, não significa só a forma,
mas a forma e a matéria. Por onde, a matéria é parte da espécie, nas sobreditas coisas; não por certo a
matéria signada, que é o princípio de individuação, mas a matéria comum. Assim, pois, como da
natureza de um determinado homem é que seja composto de tal alma e tais carnes e tais ossos, assim
da natureza do homem é que o seja da alma e das carnes e dos ossos; pois, é necessário que a
substância da espécie tenha tudo o que comumente pertence à substância de todos os indivíduos
contidos na espécie.
Porém, de outro modo, pode-se entender no sentido em que uma determinada alma seja um
determinado homem. E isso se poderia sustentar se se estabelecesse que a operação da alma sensitiva
fosse só dela, sem o corpo, porque as operações atribuídas ao homem conviriam só à alma. Ora, cada
coisa produzindo as suas operações próprias, o homem é o que opera as suas. Pois, já se demonstrou (a.
3) que sentir não é operação só da alma. ― Sendo, portanto, o sentir uma certa operação do homem,
embora não própria, é manifesto que este não é só a alma, mas algo composto de alma e corpo. Platão,
porém, ensinando que o sentir é próprio da alma, podia ensinar que o homem é uma alma que usa de
um corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Segundo o Filósofo, um ser é principalmente aquilo que
nele é o principal; assim, o que faz o chefe de uma cidade se considera como feito pela cidade. E, desse
modo, às vezes se chama homem ao que neste é o principal; umas vezes, à parte intelectiva, segundo a
verdade das coisas, chamada o homem interior; outras vezes, porém, à parte sensitiva com o corpo,
segundo a opinião de alguns que só se detêm nas coisas sensíveis; e este se chama o homem exterior.

RESPOSTA À SEGUNDA. ― Nem toda substância particular é hipóstase ou pessoa, mas a que tem a
natureza completa da espécie. Por onde, a mão ou o pé não se pode chamar hipóstase ou pessoa; e
semelhantemente, nem a alma, que é parte da espécie humana.

## Art. 5 — Se a alma é composta de matéria e forma.
(I Sent., dist. VIII, q. 5, a. 2; II dist. XVII, q. 1, a. 2; II Cont. Gent., cap. L; Quodl. III, q. VIII; IX, q. 4, a. 1; De
Spirit. Creat., a. 1; a. 9, ad; Qu. De Anima, a. 6; Opusc. XV, De Angelis, cap. VII).
O quinto discute-se assim. ― Parece que a alma é composta de matéria e forma.

1. ― Pois, a potência se divide por oposição com o ato. Ora, todos os seres em ato, quaisquer que
sejam, participam do primeiro ato, que é Deus; por cuja participação todos são bons, entes e viventes,
como é claro pela doutrina de Dionísio. Logo, quaisquer seres em potência participam da primeira
potência. Ora, esta é a matéria prima. Como, pois, a alma humana é, de certo modo, potencial, o que se
evidência por ser o homem, às vezes, inteligente em potência, resulta que ela participa da matéria
prima, tendo a esta como parte sua.

2. Demais. ― Onde quer que se encontrem as propriedades da matéria, aí se encontra a matéria. Ora,
na alma se encontram tais propriedades, a saber, o ser sujeito e o transmutar-se; pois, é sujeito da
ciência e da virtude e muda-se da ignorância para a ciência ou do vicio para a virtude. Logo, na alma, há
matéria.

3. Demais. ― O que não tem matéria não tem a causa do seu ser, como diz Aristóteles. Ora, a alma,
sendo criada por Deus, tem essa causa. Logo, tem matéria.

4. Demais. ― O que não tem matéria, mas só forma, é ato puro e infinito. Ora, tal só Deus o é. Logo, a
alma tem matéria.
Mas, em contrário, Agostinho prova que a alma não é feita de matéria corpórea nem espiritual.

SOLUÇÃO. ― A alma não tem matéria, o que se pode duplamente provar. ― Primeiro, pela natureza da
alma, em comum, que a torna forma de certo corpo. Ora, ou a alma é, em si, forma total ou parcial. Se
total, é impossível tenha, como parte, a matéria, considerada esta última como ser somente potencial;
pois, a forma, como tal, sendo ato; o que é puramente potencial não pode ser parte dês te, pois, a
potência, repugna ao ato, dividida, como é, por oposição a ele. Se parcial, essa parte a consideraremos
como alma; e a matéria, de que é o ato primário, como o primeiro animado. Segundo, especialmente,
pela natureza da alma humana, enquanto intelectiva. Pois, é manifesto, tudo o que é recebido por outro
ser o é ao modo desse ser recipiente. Assim, o que é conhecido o é do modo pelo qual a sua forma está
no conhecente. Ora, a alma intelectiva conhece as coisas em a natureza absoluta delas, p. ex., uma
pedra enquanto absolutamente pedra. Por onde, a forma da pedra, na sua razão formal própria, está
absolutamente na alma intelectiva. Logo, esta é forma absoluta e não algo composto de matéria e
forma; pois, se o fosse, as formas das coisas ela as receberia como individuais; e assim não conheceria
senão o singular, como se dá com as potências sensitivas, que recebem as formas das coisas num órgão
corpóreo; pois, a matéria é o princípio da individuação das formas. Resulta, portanto, que a alma
intelectiva e toda substância intelectual conhecedora das formas, absolutamente, carece da composição
de forma e matéria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O ato primeiro é o princípio universal de todos os atos,
pois, é o infinito, que virtualmente em si compreende todas as coisas, como diz Dionísio. Por isso, é
participado por elas, não como parte, mas pela difusão da processão de si mesmo. Porém, a potência,
como receptiva do ato, deve se proporcionar a este. Ora, os atos recebidos, procedentes do primeiro
ato infinito, e sendo determinadas participações dele, são diversos. Por onde, não pode haver uma
potência única receptiva de todos os atos, como há um ato único que influi em todos os atos
participados; do contrário, a potência receptiva se adequaria à potência ativa do ato primeiro. Há,
porém, outra potência receptiva, na alma intelectiva, diferente daquela da matéria prima, como se vê
pela diversidade das coisas recebidas; pois, ao passo que a matéria prima recebe as formas individuais, o
intelecto recebe as absolutas. E, portanto, tal potência, existente na alma intelectiva, mostra que a alma
não é composta de matéria e forma.

RESPOSTA À SEGUNDA. ― Ser sujeito e transmutar-se convêm à matéria como potencial. Se, portanto,
uma é a potência do intelecto e outra a da matéria prima, também haverá noções diversas da sujeição e
da transmutação. Assim, o intelecto é. sujeito da ciência e transmuta-se da ignorância para a ciência,
enquanto é potencial em relação às espécies inteligíveis.

RESPOSTA À TERCEIRA. ― A forma é, para a matéria, a causa do existir e do agir; por onde, o agente,
como redutor da matéria ao ato da forma, transmutando-a, é-lhe a causa da existência. Se, porém, há
alguma forma subsistente, esta não existe por nenhum princípio formal nem tem causa que a transmute
da potência para o ato. Por isso, depois das palavras anteriores, o Filósofo conclui que os seres
compostos de matéria e forma não têm outra causa a não ser a que os move da potência para o ato;
todos os seres, porém, que não têm matéria e são seres, absolutamente, são a sua mesma qüididade.

RESPOSTA À QUARTA. ― Todo participado se compara com o participador, como ato deste. Ora,
necessário é que qualquer forma criada, que se suponha por si subsistente, participe do ser; pois, a
própria vida, ou qualquer causa de semelhante, participa do ser em si, como diz Dionísio. Ora, o ser,
participado, sendo limitado pela capacidade do participante, segue-se que só Deus, que é o seu próprio
ser é ato puro e infinito. Nas substâncias intelectuais, porém, há composição de ato e de potência; não
de matéria e forma mas, de forma e do ser participado. E, por isso, alguns as consideram compostas da
causa do ser e do ser; pois, o ser em si mesmo é a causa de qualquer outro ser existir.

## Art. 6 — Se a alma humana é corruptível.
(II Sent. disto XIX, a. 1; IV, dist. q. 1, a. 1; II Cont. Gent., cap.LXXIX sqq.; Quodl. X, q. 3, a. 2; Qu. De
Anima, a. 14; Compend. Theol., cap. LXXXIV).
O sexto discute-se assim. ― Parece que a alma humana é corruptível.

1. ― Pois, seres que têm princípio e processão semelhantes também têm fim semelhante. Ora, o
princípio da geração dos homens é semelhante ao da dos asnos, pois ambos foram feitos da terra; e
também é semelhante, em ambos. a processão da vida, pois, como diz a Escritura (Ecle 3, 19), todos
respiram da mesma sorte, e o homem não tem nada de mais do que o bruto. Logo, como no mesmo
passo da Escritura se conclui, por issouma é a morte dos homens e dos brutos, e de uns e outros é igual
à condição. Mas, a alma dos brutos é corruptível. Logo, também o é a alma humana.

2. Demais. ― Tudo o que provém do nada é redutível ao nada, porque o fim deve corresponder ao
princípio. Mas, como diz a Escritura (Sb 2, 2), do nada somos nascidos; o que é verdade, não só do
corpo, mas também da alma. Logo, como ainda no mesmo passo se conclui, depois desta vida seremos
como se nunca tivéramos sido, mesmo em relação à alma.

3. Demais. ― Não há ser que não tenha a sua operação própria. Ora, a operação própria da alma,
inteligir por meio do fantasma, não vai sem o corpo. Pois, a alma não intelige nada sem fantasma e este
não existe sem o corpo, como diz Aristóteles. Logo, a alma não pode subsistir uma vez destruído o
corpo.
Mas, em contrário, diz Dionísio, que as almas humanas têm da bondade divina o serem intelectuais e o
terem a vida substancial inconsumível.

SOLUÇÃO. ― É necessário admitir-se que a alma humana, a que chamamos princípio intelectivo, é
incorruptível. Pois, um ser pode se corromper de duplo modo: por si ou por acidente. Ora, é impossível
um ser subsistente ser gerado ou corrompido por acidente, i. é., porque nele houve alguma parte
gerada ou corrupta. Pois, a todo ente lhe convém o ser gerado ou corrompido do mesmo modo pelo
qual lhe convém o ser, que pela geração se adquire e pela corrupção se perde. Por onde, o que tiver o
ser por si só por si pode gerar-se ou corromper-se. Os seres porém não subsistentes, como os acidentes
e as formas materiais, dizem-se feitos e corruptos pela geração e corrupção dos compostos. Ora, já se
demonstrou antes (a. 3), que as almas dos brutos não são por si subsistentes, senão só a alma humana.
Por isso, aquelas se corrompem, uma vez corruptos os seus corpos; porém esta só por si poderia
corromper-se. Ora, isto é absolutamente impossível, não só a esta, mas a qualquer ser subsistente que
seja só forma. Pois, é manifesto, o que convém, em si, a um ser, é inseparável deste. Ora, o ser em si,
convém à forma, que é um ato. Por onde, a matéria adquire o ser atual na medida em que adquire a
forma e corrompe-se na medida em que lhe sucede separar-se dela. Ao passo que, sendo impossível à
forma separar-se de si mesma, impossível é também que a forma subsistente perca o ser.
Dado, porém, que a alma seja composta de matéria e forma, como certos dizem, ainda assim é
necessário admiti-la como incorruptÍvel. Pois, só se encontra corrupção onde se encontra a
contrariedade; porque as gerações e as corrupções são passagens de uns para outros contrários. Por
isso os corpos celestes, sem matéria sujeita à contrariedade, são incorruptíveis. Ora, na alma intelectiva
nenhuma contrariedade pode haver. Pois, ela é receptiva ao modo do seu ser e as coisas por ela
recebidas o são sem contrariedade; pois que as noções dos contrários não são contrárias no intelecto,
mas há uma só ciência dos contrários. Logo, é impossível que a alma intelectiva seja corruptível.
Também se pode tirar uma prova desta doutrina do fato de cada ente desejar ser naturalmente, ao seu
modo. Ora, o desejo, nos seres que conhecem, segue-se ao conhecimento. E, ao passo que o sentido
não conhece o ser senão num determinado lugar e tempo, o intelecto o apreende absolutamente e
referente a qualquer tempo. Por isso, todo ser que tem intelecto deseja existir sempre. Ora, o desejo
natural não pode ser vão. Logo, toda substância intelectual é incorruptível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Salomão aplica essa razão à pessoa dos insipientes,
como se exprime noutra parte. E quanto a dizer-se que o homem e os outros animais têm o princípio da
geração semelhante, isso é verdade quanto ao corpo, pois, todos os animais foram feitos da terra,
semelhantemente. Não, porém, quanto à alma; pois, ao passo que a dos brutos é produzida por uma
virtude corpórea, a alma humana o é por Deus. E, para o exprimir, a Escritura (Gn 1) diz dos outros
animais: Produza a terra animais viventes. Mas do homem: inspirou no seu rosto um assopro de vida.
Por onde, conclui Salomão (Ecl 12, 7): E o pó se torne na sua terra de onde era, e o espírito volte para
Deus que o deu. Do mesmo modo, a processão da vida é semelhante quanto ao corpo; e a isso se
referem os passos (Ecl 3, 19): Todos respiram da mesma sortee (Sb 2, 2) a respiração nos nossos narizes
é um fumo. Mas não é semelhante a essa a processão da alma, pois, o homem intelige e os brutos não.
Por isso é falso o dito: O homem não tem nada de mais do que o bruto. Por onde, semelhante é a morte,
quanto ao corpo, mas não quanto à alma.

RESPOSTA À SEGUNDA. ― Assim como se diz que um ser pode ser criado, não pela potência passiva,
mas só pela potência ativa do Criador que, do nada, pode produzir uma coisa; assim também dizer que
um ser é redutível ao nada não importa, na criatura, a potência para o não ser, mas sim a potência do
Criador não influindo o ser. Ora, chama-se corruptível ao ente em que existe a potência para o não ser.

RESPOSTA À TERCEIRA. ― Inteligir, por meio do fantasma é, propriamente, operação da alma,
enquanto unida ao corpo. Separada deste, porém, terá outro modo de inteligir, semelhante ao das
outras substâncias separadas, como a seguir melhor se verá (q. 89, a. 1).

## Art. 7 — Se a alma e o anjo são da mesma espécie.
(II Sent., dist. III. q. 1, a. 6; II Cont. Gent., cap. XCIV; Qu. De Anima, a. 7).
O sétimo discute-se assim. ― Parece que a alma e o anjo são da mesma espécie.

1. ― Pois, cada ser é ordenado ao próprio fim pela natureza da sua espécie, que lhe dá a inclinação para
o fim. Ora, idênticos são os fins
da alma e do anjo, a saber, a felicidade eterna. Logo, ambos são da mesma espécie.

2. Demais. ― A diferença específica última é a mais nobre, porque realiza plenamente a noção da
espécie. Ora, nada há de mais nobre, no anjo e na alma, do que o ser intelectual. Logo, eles convêm na
última diferença específica, sendo, assim, da mesma espécie.

3. Demais. ― A alma só difere do anjo por estar unida ao corpo. Ora este, sendo estranho à essência da
alma, não é da mesma espécie que ela. Logo, a alma e o anjo são da mesma espécie.
Mas, em contrário. ― Seres diferentes, por operações naturais diversas, diferem pela espécie. Ora, a
alma e o anjo têm operações naturais diversas; pois, como diz Dionísio, os espíritos angélicos tem
conceitos intelectuais simples e bons e não congregam elementos divisíveis para chegar à união com
Deus; e, depois, diz ao contrário da alma. Logo, a alma e o anjo não são da mesma espécie.

SOLUÇÃO. ― Orígenes ensinou que todas as almas humanas e os anjos são da mesma espécie. E isto
porque ensinava que a diversidade de graus existentes em tais substâncias é acidental, como
proveniente do livre arbítrio, segundo já se disse antes (q. 47, a. 2). Ora, tal não pode ser. Porque nas
substâncias incorpóreas não pode haver diversidade numérica sem diversidade específica e sem
desigualdade natural. Pois, não sendo compostas de matéria e forma, mas sendo formas subsistentes, é
claro que necessário será haver entre elas diversidade específica. Porque não se pode compreender
exista alguma forma separada que não seja única da sua espécie; assim como, se existisse a brancura
separada, essa não poderia ser senão uma única, pois uma brancura não difere de outra senão porque é
tal ou tal. Ora, a diversidade específica sempre vai com a diversidade natural concomitante; assim, nas
espécies de cores, uma cor é mais perfeita que outra; e, semelhantemente, em outras espécies. E isto
porque as diferenças que dividem o gênero são contrárias. Ora, os contrários entre si se comportam
como o perfeito com o imperfeito, porque o princípio da contrariedade é a privação e o hábito, como diz
Aristóteles. Também o mesmo se seguiria se tais substâncias fossem compostas de matéria e forma. Se,
pois, a matéria de uma se distingue da de outra, necessário é que ou a forma seja o princípio da
distinção da matéria, de modo que as matérias sejam diversas pela tendência para formas diversas,
donde também resultaria a diversidade específica e a desigualdade natural; ou que a matéria seja o
princípio da distinção das formas. Nem se pode dizer que esta matéria seja diferente daquela, senão
quanto à divisão quantitativa, que não tem lugar nas substâncias incorpórea, como o anjo e a alma. Por
onde, não é possível sejam ambos da mesma espécie. Como é porém que há muitas almas da mesma
espécie, a seguir se demonstrará (q. 76, a. 2 ad 1).

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Essa doutrina é procedente quanto ao fim próximo e
natural. Ora, a beatitude eterna é o fim último e sobrenatural.

RESPOSTA À SEGUNDA. ― A diferença específica última é a mais nobre, enquanto determinada em
máximo grau, ao modo pelo qual o ato é mais nobre que a potência. Ora, desse modo, o intelectual não
é nobilíssimo, por ser indeterminado e comum a muitos graus de intelectualidade, como o sensível a
muitos graus, quanto ao ser sensível. Por onde, assim como nem todos os sensíveis são da mesma
espécie, assim nem todos os intelectuais.

RESPOSTA À TERCEIRA. ― O corpo não é da essência da alma; mas é da essência desta que seja capaz
de união com o corpo. Por onde, nem, propriamente, a alma pertence a uma espécie, mas sim, o
composto. E o fato mesmo de a alma precisar, de certo modo, do corpo para a sua operação, mostra
que ela tem um grau de intelectualidade inferior ao do anjo, que não está unido a um corpo.