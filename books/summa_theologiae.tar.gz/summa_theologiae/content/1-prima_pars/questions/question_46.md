# Questão 46: Do princípio da duração das coisas criadas.
Conseqüentemente devemos considerar o princípio da duração das coisas criadas. E sobre este assunto,
três questões se discute:

## Art. 1 — Se a universalidade das criaturas, designada atualmente pela denominação de mundo, começou ou existiu abeterno.
(II Sent .. dist. I, q. 1, a. 5; II Cont. Gent., cap. XXXI; seqq.; De Pot., q. 3, a. 17; Quodl., III, q. 14, a. 2;
Compend. Theol., cap. XCVIII; VIII Phys., Lect. II; I De coel. et mund., 1ect. VI, XXIX; XII Metaphys., lect.
V).
O primeiro discute-se assim. – Parece que a universalidade das criaturas, atualmente designada pela
denominação de mundo, não começou, mas existe abeterno.

1. – Tudo o que começou a existir foi, antes, possível; do contrário seria impossível o existir. Ora, o ser
possível é a matéria, potencial em relação ao ser que existe pela forma, e ao não-ser que é privação. Se
pois o mundo começou a existir, antes foi matéria. Mas não pode ser matéria sem forma. Ora, a matéria
do mundo com a forma é o mundo. Logo, o mundo existiu antes de começar a existir, o que é
impossível.

2. Demais. – O que tem a virtude de existir sempre não pode ora ser e ora não ser, porque uma coisa
perdura no ser enquanto a virtude dela o permite. Mas todo incorruptível tem a virtude de existir
sempre, pois esta não se limita a um determinado tempo de duração. Logo, nenhum incorruptível pode
ora ser e ora não ser. Mas tudo o que começa a existir, ora é e ora não é. Por onde, nenhum
incorruptível começa a existir. Há porém muito seres incorruptíveis no mundo, como os corpos celestes,
e todas as substâncias intelectuais. Logo, o mundo, não começou a existir.

3. Demais. – Nada do que é ingênito começou a existir. Mas o Filósofo diz que a matéria e o céu são
ingênitos. Logo, a universalidade das coisas não começou a existir.

4. Demais. – Vácuo é onde não há, mas pode haver corpo. Ora, se o mundo começou a existir, onde
agora está o corpo do mundo antes não havia corpo nenhum, embora pudesse havê-lo; pois, do
contrário, agora aí não estaria. Logo, antes do mundo, havia o vácuo, o que é impossível.

5. Demais. – O começar de novo a ser movido é em virtude do princípio que o motor ou o móvel tem
atualmente em estado que antes não tinha; pois por isso um ser é movido. Por onde, antes de qualquer
movimento de novo incipiente, houve outro e, logo, o movimento sempre existiu. E portanto também o
móvel, pois o movimento não existe senão no móvel.

6. Demais. – Todo movente ou é natural ou voluntário. Ora, nenhum começa a mover sem que preexista
algum movimento, pois a natureza sempre opera do mesmo modo. Por onde, sem que preceda alguma
mutação em a natureza do movente ou no móvel, não começa a existir, pelo movente natural, um
movimento que antes não existia. Mas, a vontade, sem imutação própria pode retardar em fazer o que
propõe. Ora, tal não se dá senão em virtude de alguma imutação imaginada pelo menos, relativamente
ao tempo. Assim, quem quer fazer uma casa amanhã e não hoje, espera exista amanhã, o que hoje não
existe; e, ao menos, espera que dia de hoje passe e o de amanhã chegue; ora, isto não vai sem
mudança, pois o tempo é o número do movimento. Conclui-se portanto que, antes de qualquer
movimento incipiente de novo, existiu outro. E assim conclui-se o mesmo que antes.

7. Demais. – Tudo o que está sempre no seu princípio e sempre no seu fim não pode começar nem
acabar; pois, o que começa não está no fim, e o que acaba não está no princípio. Ora, o tempo sempre
está no seu princípio e no seu fim, pois não existe do tempo senão o momento presente, fim do
pretérito e princípio do futuro. Logo, o tempo não pode começar nem acabar. E, por conseqüência, nem
o movimento, do qual o tempo é o número.

8. Demais. – Deus é anterior ao mundo, ou por natureza somente ou também por duração. Se só por
natureza, então, sendo Ele abeterno, também o mundo o é. Se porém é anterior pela duração, como o
anterior e o posterior na duração constituem o tempo, então antes do mundo existia o tempo, o que é
impossível.

9. Demais. – Posta a causa suficiente, posto fica o efeito; pois a causa à qual se não segue o efeito é
imperfeita e necessita de outra que o faça seguir-se. Ora, Deus é a causa suficiente do mundo: final, em
razão da sua bondade; exemplar, em razão da sua sabedoria; e efetiva, em razão do seu poder, como
resulta do que já antes se viu. Como, porém, Deus é abeterno, também o mundo o é.
10. Demais. – De quem a ação é eterna também o efeito o é. Ora, a ação de Deus é a sua substância
eterna. Logo, também o mundo é eterno.
Mas, em contrário, a Escritura: (Jo 17, 5) Pai, glorificai-me a mim em ti mesmo, com aquela glória que eu
tive em ti antes que houvesse mundo, e (Pr 8, 22): O Senhor me possui no princípio de seus caminhos,
desde o princípio, antes que criasse coisa alguma.

SOLUÇÃO. – Nada existe abeterno, exceto Deus; o que não é impossível de se provar. Pois, já se
demonstrou antes que a vontade de Deus é a causa das coisas. Portanto, existem necessariamente as
coisas que Deus quiser necessariamente, porque a necessidade do efeito depende da necessidade da
causa, como diz Aristóteles. Ora, já antes se demonstrou que, falando em absoluto, Deus não quer
necessariamente senão a si mesmo. Logo, não é necessário Deus querer que o mundo sempre existisse;
mas o mundo existe enquanto Deus assim o quiser, porque a existência do mundo depende da vontade
de Deus como da sua causa. Logo, não é necessário que o mundo tenha existido sempre; e isso não
pode ser provado por demonstração.
Nem as razões que para isso apresenta Aristóteles são demonstrativas pura e simplesmente, mas só de
certo modo, isto é, para contraditar as razões dos antigos que ensinavam que o mundo começou; mas
segundo certos modos na verdade impossíveis. O que se verá por uma tríplice consideração. – Primeira,
porque tanto na Física como tratado Do céu, rejeita certas opiniões, como as de Anaxágoras,
Empédocles e Platão, contra as quais apresenta razões contraditórias. – Segunda, porque, sempre que
trata desta matéria, traz os testemunhos dos antigos; o que não é próprio de quem demonstra, mas
dequem persuade com probabilidade. – Terceira, porque expressamente diz haver certos problemas
dialéticos dos quais não temos as razões; como – se o mundo é eterno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O mundo, antes de existir, foi possível, não por certo pela
matéria, potência passiva, mas pela potência ativa, Deus. E também no sentido em que se diz que
alguma coisa é absolutamente possível, mas não por alguma potência, senão pela só natureza dos
termos, que não se repugnam entre si; sentido em que o possível se opõe ao impossível, como é claro
pelo Filósofo.

RESPOSTA À SEGUNDA. – O que tem a virtude de existir sempre, desde que a tem, não pode ora existir
e ora não existir; mas, antes que a tivesse, não existia. Por onde, a razão apresentada por
Aristóteles não conclui pura a simplesmente que os seres incorruptíveis não começaram a existir; mas
que não começaram a existir, ao modo natural pelo qual o começam os seres geráveis e corruptíveis.

RESPOSTA À TERCEIRA. – Aristóteles na Física, prova que a matéria é ingênita porque não tem um
sujeito do qual ela seja; no tratado Do Céu, porém, que o céu é ingênito porque não é gerado de
nenhum contrário. Por onde, é claro que de nenhum modo se conclui senão que a matéria e o céu não
começaram por geração, como alguns ensinavam, sobretudo do céu. Nós, porém, dizemos que a
matéria e o céu vieram ao ser pela criação, como resulta claro do que já foi dito.

RESPOSTA À QUARTA. – Para a noção do vácuo não basta defini-lo como aquilo no que nada está; mas
se requer que ele seja um espaço capaz de conter um corpo e no qual não haja nenhum corpo, como é
claro por Aristóteles. Nós, porém, dizemos que não houve lugar nem espaço antes do mundo.

RESPOSTA À QUINTA. – O motor primeiro existiu sempre do mesmo modo; não assim, porém, o
primeiro móvel que, tendo começado a existir, antes não existia. Contudo não começou a existir por
mutação, senão por criação, que não é mutação, como já antes se disse. Por onde, é claro que a razão
dada por Aristóteles procede contra os que admitiam os móveis eternos, mas o movimento não-eterno,
como se vê pelas opiniões de Anaxágoras e Empédocles. Nós, porém, ensinamos que, desde que os
móveis começaram, o movimento sempre existiu.

RESPOSTA À SEXTA. – O agente primeiro é um agente voluntário; e embora tivesse a vontade eterna de
produzir algum efeito, contudo não o produziu eterno. E nem é necessário pressupor-se qualquer
mutação, mesmo por imaginação de tempo. Pois, um é o modo de se inteligir o agente particular, que
pressupõe alguma coisa para causar outra; e outro o de se inteligir o agente universal, que produz o
todo. Assim, o agente particular produz a forma e pressupõe a matéria; e por isso importa que produza
uma forma proporcionada à matéria devida. Por onde, e racionavelmente, nele se leva em conta o
produzir a forma em tal matéria e não em tal outra, pela diferença que vai de matéria a matéria. Não é,
porém, racionável a Deus, que simultaneamente produza a forma e a matéria; mas o é dele pensar-se
que produz a natureza congruente com a forma e com o fim. Porém o agente particular pressupõe o
tempo, como pressupõe a matéria. Por onde, e racionavelmente, nele se leva em conta ao agir num
tempo posterior e não no anterior, por imaginação de suceder o tempo ao tempo. Mas do agente
universal, que produz o ser e o tempo, não se pode pensar que atue agora e não antes, por imaginação
de um tempo depois de outro, como se o tempo se lhe propusesse à ação; e deve-se pensar que deu ao
seu efeito, quanto e quando quis, o tempo, conforme julgava conveniente para demonstrar o seu poder.
Assim, o mundo leva mais manifestamente ao conhecimento do divino criador, não tendo existido
sempre, do que sempre tendo existido; pois se é manifesto, do que não existiu sempre, que tem causa,
não o é do que sempre existiu.

RESPOSTA À SÉTIMA. – Como diz Aristóteles, a anterioridade e a posterioridade existem no tempo do
mesmo modo que no movimento. Por onde, princípio e fim devem ter, no tempo, a mesma acepção que
têm no movimento. Suposta porém a eternidade do movimento, é necessário que qualquer momento,
em relação ao movimento, seja deste princípio e termo; o que se não dará se o movimento começou. E
a mesma é a noção do momento do tempo. Assim, é claro que a objeção, instando quanto ao momento,
como sendo sempre o princípio e o fim do tempo, pressupõe a eternidade do tempo. Por isso
Aristóteles apresenta essa objeção contra os que, admitindo a eternidade do tempo, negavam a do
movimento.

RESPOSTA À OITAVA. – Deus é anterior ao mundo pela duração. Anterior, porém, não designa a
anterioridade do tempo, mas a da eternidade. – Ou, ainda, designa a eternidade do tempo imaginado e
não realmente existente; assim como quando se diz “acima do céu nada há”, acima designa um lugar
imaginário somente,segundo o que, é possível imaginarem-se outras dimensões acrescentadas às do
corpo celeste.

RESPOSTA À NONA. – Assim como o efeito resulta da causa agente natural, ao modo da forma desta;
assim resulta do agente voluntário segundo a forma por este preconcebida e definida, como já antes se
viu. Embora, pois, Deus seja abeterno a causa suficiente do mundo, deve-se, contudo, admitir o mundo
produzido por ele enquanto isso estava na predefinição da sua vontade; isto é, tendo o ser depois de
não o ter tido, para que mais manifestamente declare o seu autor.

RESPOSTA À DÉCIMA. – Posta a ação segue-se o efeito, segundo a exigência da forma, que é princípio
da ação. Mas nos agentes voluntários, o que é concebido e predefinido é tomado como a forma, que é
princípio da ação. Logo, da ação eterna de Deus não resulta um efeito eterno, mas o efeito que Deus
quiser, como, p. ex., existir depois de não ter existido.

## Art. 2 — Se é artigo de Fé ou conclusão demonstrável que o mundo começou.
(II Sent., dist. I, q. 1. art. 5; II Cont. Gent., cap. XXXVIII; De Pot., q. 3, a. 14; Quodl., XII, q. 6, a. 1; Opusc.

XXVII, De AEternitate Mundi).
O segundo discute-se assim. – Parece não ser artigo de fé – que o mundo começou – mas conclusão
demonstrável.

1. – Pois tudo o que é feito tem o princípio da sua duração. Ora, pode-se provar demonstrativamente
que Deus é a causa efetiva do mundo; e, mesmo, assim o admitiram os filósofos mais prováveis. Logo,
pode-se provar demonstrativamente que o mundo começou.

2. Demais. – Se é necessário admitir-se o mundo como feito por Deus, ou o foi do nada ou de alguma
coisa. Ora, não de alguma coisa, porque então a matéria do mundo lhe seria anterior; contra o que,
procedem as razões de Aristóteles ensinando que o céu é ingênito. Logo, é necessário admitir-se o
mundo como feito do nada, e, assim, tendo o ser depois do não-ser e, portanto, como tendo começado.

3. Demais. – Tudo o que opera pelo intelecto opera começando de um certo princípio, como é claro por
todas as coisas artificiais. Ora, Deus é agente pelo intelecto. Logo, opera começando de um certo
princípio. E portanto o mundo, que é seu efeito, nem sempre existiu.

4. Demais. – É manifesto que certas artes e a habitação das regiões começaram em determinados
tempos. Ora, isto não se daria se o mundo sempre tivesse existido. Logo, é manifesto que ele nem
sempre existiu.

5. Demais. – É certo que nada pode se equiparar a Deus. Mas, se o mundo sempre existiu equipara-se a
Deus pela duração. Logo, é certo que ele nem sempre existiu.

6. Demais. – Se o mundo sempre existiu, dias infinitos precederam um determinado dia. Ora, não se
pode percorrer o infinito. Logo, nunca se teria chegado a esse determinado dia, o que é manifestamente
falso.

7. Demais. – Se o mundo é eterno também a geração o é. Logo, um homem foi gerado por outro, ao
infinito. Ora, o pai é a causa eficiente do filho, como diz Aristóteles. Logo, nas causas eficientes, pode-se
proceder até ao infinito, o que é refutado pelo mesmo filósofo.

8. Demais. – Se o mundo e a geração sempre existiram, infinitos homens já existiram. Ora, a alma do
homem é imortal. Logo, existiriam atualmente infinitas almas humanas, o que é impossível. Por onde e
necessariamente, pode-se saber, e sem que o seja somente pela fé, que o mundo começou.
Mas, em contrário. – Os artigos da fé não se podem provar demonstrativamente, porque a fé se refere
ao que se não vê, como diz a Escritura (Heb 11). Mas que Deus é o Criador do mundo, de modo que este
tenha começado, é artigo de fé; pois dizemos – Creio em um só Deusetc.; e, demais, Gregório escreve
que Moisés profetou do passado, dizendo – No princípio criou Deus o céu e a terra– por onde exprimiu a
novidade do mundo. Logo, o começo do mundo só se conhece pela revelação. E logo, não pode ser
provado demonstrativamente.

SOLUÇÃO. – Que o mundo não existiu sempre só se sabe pela fé e não pode ser demonstrativamente
provado, como já antes se disse do mistério da Trindade. E a razão disto é que não se pode dar uma
demonstração de que o mundo começou, tirada do próprio mundo. Pois o princípio da demonstração é
aquilo que a coisa é. Ora, cada ser, segundo a natureza da sua espécie, faz abstração do lugare
do tempoe, por isso, se diz que os universais existem em toda parte e sempre. Por onde, não se pode
demonstrar que o homem, o céu ou a pedra não existissem sempre. Semelhantemente, também a
demonstração não pode ser tirada do agente voluntário. Pois, a vontade de Deus não pode ser
investigada pela razão, senão no tocante às coisas que, em absoluto, são necessariamente queridas por
Ele, como já se disse.Pode,porém, a vontade divina ser manifestada ao homem pela revelação, na qual
se apóia a fé. Por onde, pode-se acreditar que o mundo começou, não porém demonstrá-lo nem o saber
pela ciência. E é útil atentemos nisto, não vá alguém, presumindo demonstrar o que é de fé, apresentar
razões não necessárias, matéria de irrisão aos infiéis, que ficariam pensando que nós cremos, por tais
razões, nas coisas de fé.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como diz Agostinho, dupla é a opinião dos filósofos que
ensinaram a eternidade do mundo. Pois admitiam que a substância do mundo não provém de Deus; e
destes o erro é intolerável e, portanto, por si mesmo refutado. Outros admitiam o mundo eterno, mas
diziam que foi feito por Deus. Pois não querem tenha o mundo início no tempo, mas início na sua
criação; assim que, de um modo apenas inteligível, ele sempre seja feito. E, como diz o mesmo autor,
encontraram um meio para explicarem o seu pensamento. Pois assim como, dizem, um pé calcando
desde toda a eternidade na poeira, sempre estaria por baixo o vestígio, que ninguém duvidaria ter sido
causado pelo pé; assim também o mundo sempre existiu, se sempre existiu quem o fez.Mas para o
entendermos devemos considerar que a causa eficiente, que age por movimento, necessariamente
precede no tempo o seu efeito, pois este existe no termo da ação e é necessário seja todo agente
princípio da ação. Se a ação, porém, for instantânea e não sucessiva, não é necessário a causa eficiente
seja anterior ao que é feito, como é patente na iluminação. Por onde dizem que, de ser Deus a causa
ativa do mundo não se segue necessariamente seja anterior ao mundo na duração, porque a criação que
produziu o mundo não é uma mutação sucessiva, como já antes se disse.

RESPOSTA À SEGUNDA. – Os que admitem o mundo eterno dizem que ele foi feito, por Deus, do nada;
não que tenha sido feito depois do nada, no sentido em que entendemos o vocábulo criação; mas
porque não foi feito de alguma coisa. Assim, alguns deles não recusam o nome de criação, como se vê
claramente em Avicena.

RESPOSTA À TERCEIRA. – Essa é a objeção de Anaxágoras, que apresenta Aristóteles. Mas não conclui
com necessidade senão quanto ao intelecto que, deliberando, investiga o que deva ser feito; o que é
semelhante ao movimento. Ora, tal é o intelecto humano, mas não o divino, como já antes se viu.

RESPOSTA À QUARTA. – Os que admitem a eternidade do mundo admitem que uma região infinitas
vezes se mudou de inabitável para habitável, e vice-versa. E semelhantemente, que as artes, por
diversas corrupções e acidentes, infinitas vezes foram inventadas e de novo corrompidas. Donde vem o
dizer Aristóteles que é ridículo concluir de tais mutações particulares, a novidade total do mundo.

RESPOSTA À QUINTA. – Mesmo que o mundo sempre tenha existido, nem por isso se equipararia à
Deus na sua eternidade, como diz Boécio; porque o ser divino é o ser totalmente simultâneo, sem
sucessão, o que se não dá com o mundo.

RESPOSTA À SEXTA. – Um percurso sempre se entende de termo a termo. Ora, sejam quantos forem os
dias passados que se quisessem, daí até o dia atual é finito o número dos dias e puderam ser
percorridos. Porém a objeção procederia se, postos os extremos, os meios fossem infinitos.

RESPOSTA À SÉTIMA. – Nas causas eficientes em si mesmas é impossível proceder até ao infinito, como,
p. ex., se as causas requeridas para um efeito se multiplicassem ao infinito; assim, se, uma pedra fosse
movida por um bastão e este pela mão, e isto ao infinito. Mas não se reputa por impossível o poder
proceder-se até ao infinito, por acidente, nas causas agentes; de modo que, por exemplo, todas as
causas, multiplicadas ao infinito se ordenem a uma só causa, sendo porém a multiplicação delas
acidental. Assim, se um artífice usa de muitos martelos, por acidente, porque um se quebra após outro,
resulta por conseqüência que tal martelo entra em ação depois de tal outro. E semelhantemente sucede
a tal homem, capaz de gerar, o ser gerado por outro, pois gera enquanto homem e não enquanto filho
de outro homem. Por onde, todos os homens, que geram, têm o mesmo grau, nas causas eficientes a
saber, o grau de gerador particular. E, portanto, não é impossível que o homem seja gerado pelo
homem, ao infinito. Mas sê-lo-ia, se a geração de tal homem dependesse de tal outro e do corpo
elementar e do sol e assim ao infinito.

RESPOSTA À OITAVA. – Os que admitem a eternidade do mundo fogem, de muitas maneiras, a esta
objeção. Assim, uns não reputam por impossível existirem infinitas almas em ato, como se vê em
Algazel, por se tratar, dizem, de um infinito por acidente. Mas isto já foi refutado antes. Outros, porém,
afirmam que a alma se corrompe com o corpo. Outros, ainda, que, de todas as almas só remanesce
uma. Outros, por fim, como se refere Agostinho, admitiam que haja um circuito de almas, por isto que
as almas separadas dos corpos, após um determinado currículo temporal, de novo voltam a eles. E de
todas estas opiniões vamos tratar nos artigos seguintes. Devemos todavia considerar que a objeção
supra é particular; por ela poderia dizer alguém que o mundo foi eterno, ou, pelo menos, alguma
criatura, como o anjo; mas não o homem. Nós porém indagamos universalmente, se alguma criatura
existe abeterno.

## Art. 3 — Se a criação das coisas teve um princípio temporal.
(II Sent., dist. 1, q. 1, a. 6).
O terceiro discute-se assim. – Parece que a criação das coisas não teve um princípio temporal.

1. – Pois, o que não está no tempo não está em algum tempo. Ora, a criação das coisas não foi no
tempo; porque, por ela, a substância é produzida quanto ao ser, e o tempo não mede a substância das
coisas, sobretudo das incorpóreas. Logo, a criação não teve um princípio temporal.

2. Demais. – O Filósofo prova que tudo o que está vindo a ser esteve vindo a ser, e, assim, todo vir à ser
implica anterioridade e posterioridade. Ora, o principio do tempo, sendo indivisível, não tem anterior e
posterior. Logo, como o ser criado é de certo modo vir à ser, parece que as coisas não tiveram um
princípio temporal.

3. Demais. – Também o próprio tempo foi criado. Ora, o tempo, sendo divisível, não pode ter um
princípio temporal, pois o princípio do tempo é indivisível. Logo, a criação das coisas não teve um
princípio temporal.
Mas, em contrário, diz a Escritura (Gn 1, 1): No princípio criou Deus o céu e a terra.

SOLUÇÃO. – As palavras da Escritura – No princípio criou Deus o céu e a terra– são construídas de
tríplice maneira, para excluir três erros. – Pois, alguns ensinaram que o mundo sempre existiu e o tempo
não teve princípio. E para excluir esse erro se constrói – No princípio – isto é, do tempo. – Outros,
porém, ensinaram serem dois os princípios da criação: um, dos bens; outro, dos males. E, para excluir
este se constrói: No princípio, isto é, no Filho. Pois assim como o princípio efetivo é apropriado ao Pai,
por causa do seu poder; assim, o princípio exemplar o é ao Filho, por causa da sua sabedoria. De modo
que o dito da Escritura (Sl 103, 24), Todas as coisas fizeste com sabedoria, se entenda no sentido que
Deus fez tudo no Princípio, isto é, no Filho, segundo as palavras do Apóstolo (Cl 1, 16): Nele, isto é, no
Filho, foram criadas todas as coisas. – Outros, por fim, disseram que os seres corpóreos foram criados
por Deus, mediante as criaturas espirituais. E, para excluir este erro constrói-se: No princípio criou
Deus o céu e a terra, isto é, antes de todas as coisas.Pois quatro seres se admitem como
simultaneamente criados, a saber: o céu empíreo, a matéria corpórea chamada terra, o tempo e a na-
tureza angélica.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Não se diz que as coisas foram criadas num princípio
temporal, como se o princípio do tempo fosse a medida da criação; mas que, simultaneamente com o
tempo, foram criados o céu e a terra.

RESPOSTA À SEGUNDA. – Essa expressão do Filósofo se entende do vir a ser por movimento ou que é
termo deste. Porque, como é forçoso admitir, em qualquer movimento, uma posição de anterioridade e
outra de posterioridade, antes de qualquer movimento imaginado, isto é enquanto alguma coisa é
movida e vem a ser – deve-se admitir um anterior e também algo que virá depois. Pois o princípio ou o
termo do movimento, não é movimento em ato, como já antes se disse. Por onde, alguma coisa é
criada, que anteriormente não o era.

RESPOSTA À TERCEIRA. – Nada vem a ser senão segundo o que é. Ora, da essência do tempo é
o momento; por onde, não pode ele vir a ser senão segundo algum momento; não que no tempo o
momento seja primariamente tempo, mas que, por ele, começa o tempo.