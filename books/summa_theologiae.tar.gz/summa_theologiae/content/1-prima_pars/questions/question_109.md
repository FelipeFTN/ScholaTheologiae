# Questão 109: Da ordem dos anjos maus.
Em seguida devemos considerar a ordem dos anjos maus.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se há ordens de demônios.
(II Sent., dist. VI. Q. 1, a. 4; IV dist. XLVII, q. 1, a. 2, qa 4; Ephes., cap. VI, lect. III).
O primeiro discute-se assim. — Parece que não há ordens de demônios.

1. — Pois, a ordem é da essência do bem, como o modo e a espécie, segundo diz Agostinho. E ao
contrário, a desordem é da essência do mal. Ora, nos bons anjos, nada é desordenado. Logo, não há
ordens de maus anjos.

2. Demais. — As ordens angélicas estão compreendidas em alguma hierarquia. Ora, os demônios,
privados de toda santidade, não estão em nenhuma hierarquia, que é o principado sagrado. Logo, não
há ordens de demônios.

3. Demais. — Os demônios decaíram das varias ordens dos anjos, como se diz comumente. Se pois,
alguns demônios são considerados pertencentes a alguma ordem, porque dela decaíram, conclui-se que
lhes deveriam ser atribuídos os nomes das várias ordens. Ora, nunca se soube que fossem chamados
Serafins, Tronos ou Dominações. Logo, por igual razão, não estão nas demais ordens.
Mas, em contrário, diz o Apóstolo (Ef 6, 12): nós temos que lutar contra os Principados e Potestades,
contra os dominadores deste mundo tenebroso.

SOLUÇÃO. — Como já se disse (q. 108, a. 4, 7, 8), a ordem angélica é considerada em relação ao grau da
natureza e ao da graça. Ora, a graça tem duplo estado: o imperfeito, que é o de merecer; e o perfeito,
que é o da glória consumada. Se, pois, considerarem-se as ordens angélicas quanto à graça imperfeita,
então os demônios lhes pertenceram, outrora, mas delas decaíram: e isto é conforme ao que já
estabelecemos (q. 62, a. 3), que todos os anjos foram criados em graça. Se porém forem considerados
quanto à natureza, então ainda agora eles a elas pertencem, pois não perderam os dons da natureza,
como diz Dionísio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como já se estabeleceu (q. 49, a. 3), o bem pode existir
sem o mal, mas não este, sem aquele. Por onde, os demônios, na medida em que têm a natureza boa,
são ordenados.

RESPOSTA À SEGUNDA. — A ordenação dos demônios, considerada em relação a Deus ordenador, é
sagrada, pois, ele usa deles para si mesmo. Mas em relação à vontade dos demônios, não o é, porque
abusam da natureza própria, para o mal.

RESPOSTA À TERCEIRA. — O nome de Serafins é imposto por causa do ardor da caridade; o de Tronos,
por habitar neles a divindade; o de Dominações, por fim, importa uma certa liberdade. Tudo o que se
opõe ao pecado. Por onde, tais nomes não se podem atribuir aos anjos pecadores.

## Art. 2 — Se entre os demônios há superiores.
(Supra. Q. 63. a. 8; II Sent., dist. VI, q. 1. a. 4; IV, dist. XLVII, a. 2, qa 4).
O segundo discute-se assim. — Parece que, entre os demônios, não há superiores.

1. — Pois, toda superioridade se funda nalguma ordem da justiça. Ora, os demônios perderam
totalmente a justiça. Logo, entre eles não há superiores.

2. Demais. — Onde não há obediência e sujeição não há superioridade. Ora, esta não pode existir sem a
concórdia, que de nenhum modo existe nos demônios, conforme a Escritura (Pr 23, 10): Entre os
soberbos há sempre contendas. Logo entre os demônios não há superiores.

3. Demais. — Se entre eles existisse alguma superioridade, esta haveria de lhes pertencer, quer à
natureza, quer à culpa ou à pena. Ora, não à natureza, porque não desta, mas do pecado é que resultou
a sujeição e a servidão. Nem à culpa ou à pena, porque então os demônios superiores, que pecaram
mais, estariam sujeitos aos inferiores. Logo, não há superiores entre os demônios.
Mas, em contrário, diz a Glossa: Enquanto durar o mundo, os anjos governarão, os anjos; os homens, os
homens e os demônios, os demônios.

SOLUÇÃO. — Como o ato resulta da natureza da coisa, nos seres, cuja natureza é ordenada,
necessariamente hão-de os atos se ordenar entre si. Como é patente nos seres corpóreos; pois, porque
os corpos inferiores dependem, por ordem natural, dos corpos celestes, os atos e os movimentos
daqueles estão sujeitos aos atos e movimentos destes. Ora, é manifesto, pelo que já foi dito (a. 1), que
os demônios estão constituídos uns sob a dependência dos outros. Por onde, os atos daqueles
dependem dos atos destes. E nisto consiste a essência da superioridade, a saber, que o ato do súdito
esteja submetido ao do superior. Assim, pois, a disposição natural mesma dos demônios exige que haja
entre eles superior. E isto também convém à divina sabedoria, que nada deixa desordenado no
universo, e que atinge fortemente desde uma extremidade à outra, e dispõe todas as coisas com
suavidade, como diz a Escritura (Sb 8, 1).

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A superioridade, nos demônios, não se lhes funda na
justiça, mas na justiça de Deus que tudo ordena.

RESPOSTA À SEGUNDA. — A concórdia, pela qual uns demônios obedecem a outros, não nasce da
amizade que tenham entre si, mas da nequícia comum com que odeiam os homens e repugnam à justiça
de Deus. Pois, é o próprio aos homens ímpios unirem-se e submeterem-se aos de forças superiores,
para executarem a própria nequícia.

RESPOSTA À TERCEIRA. — Os demônios não são iguais por natureza e por isso há entre eles superiores.
O que não se dá com os homens, iguais por natureza. Ora, submeterem-se os demônios inferiores aos
superiores, não é para bem, mas antes para mal destes; pois, fazer o mal sendo a máxima miséria,
governar maus é ser mais miserável que eles.

## Art. 3 — Se nos demônios há iluminação.
O terceiro discute-se assim. — Parece que nos demônios há iluminação.

1. — Pois, a iluminação consiste na manifestação da verdade. Ora, um demônio pode manifestar a
verdade a outro, porque os superiores têm maior vigor, quanto ao acume da ciência natural. Logo, os
demônios superiores podem iluminar os inferiores.

2. Demais. — O corpo com luz superabundante pode iluminar o que é dela deficiente; assim, o sol
ilumina a lua. Ora, os demônios superiores têm mais abundante participação do lume natural. Logo,
podem iluminar os inferiores.
Mas, em contrário. — A iluminação vai com a purificação e a perfeição, como antes se disse (q. 106, a. 1,
2). Ora, purificar não cabe aos demônios, conforme a Escritura (Ecle 34, 4): que coisa será limpa por um
imundo?Logo, nem a iluminação.

SOLUÇÃO. — Nos demônios não pode haver iluminação. Pois, como já se disse (q. 107, a. 2), a
iluminação sendo propriamente, a manifestação da verdade, ela se ordena por Deus, que ilumina todo
intelecto. Mas, outra manifestação da verdade pode ser a locução, como quando um anjo manifesta a
outro o seu conceito. Ora, a perversidade dos demônios faz com que um não procure ordenar o outro
para Deus, mas, antes, afastá-lo da ordem divina. E por isso um não ilumina o outro, mas pode
comunicar a este o seu conceito, por meio da locução.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Não é qualquer manifestação da verdade que se domina
iluminação, mas só a que foi referida.

RESPOSTA À SEGUNDA. — No que diz respeito ao conhecimento natural, não é necessária a
manifestação da verdade, nem entre os anjos, nem entre os demônios. Pois, como já se disse (q. 55, a.
2), logo, desde o princípio do conhecimento deles, conheceram tudo o que respeita o conhecimento
natural. Por onde, a maior plenitude de luz natural, existente nos demônios superiores, não pode ser
causa de iluminação.

## Art. 4 — Se os bons anjos têm superioridade sobre os maus.
O quarto discute-se assim. — Parece que os bons anjos não têm superioridade sobre os maus.

1. — Pois, a superioridade, nos anjos, se baseia sobretudo na iluminação. Ora, os maus anjos, sendo
trevas, não são iluminados pelos bons. Logo, estes não têm superioridade sobre aqueles.

2. Demais. — O que os súbditos fazem de mal é atribuído à negligência do chefe. Ora, os demônios
fazem muito mal. Se, pois, estão sujeitos ao governo dos bons anjos, resulta que há nestes alguma
negligência, o que é inadmissível.

3. Demais. — A superioridade dos anjos resulta da ordem da natureza, como se disse antes (a. 2). Ora,
se como se diz comumente, os demônios decaíram, das várias ordens, muitos deles são superiores, na
ordem da natureza, a muitos bons anjos. Logo, estes não têm superioridade sobre todos os maus.
Mas, em contrário, diz Agostinho: o espírito, transviado da vida racional e pecador, é governado pelo de
vida racional, pio e justo. E Gregório: chamam-se potestades os anjos a cujo império estão sujeitas as
virtudes adversas.

SOLUÇÃO. — Toda a ordem da superioridade está primária e originalmente em Deus; e é participada
pelas criaturas, conforme o grau em que se aproximam de Deus. Assim, as mais perfeitas e mais
próximas de Deus têm influência sobre as outras. Ora, a máxima perfeição, e que mais aproxima de
Deus, é a das criaturas que o fruem, como os santos anjos, e dessa perfeição os demônios estão
privados. Por onde, os bons anjos têm superioridade sobre os maus, que são governados por eles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os santos anjos revelam aos demônios muitas coisas dos
mistérios divinos, quando a divina justiça exige certas se façam pelos demônios, quer para punição dos
maus, quer para exercitação dos bons; assim como nas coisas humanas, os assessores do juiz revelam
aos algozes a sentença do mesmo. E tais revelações, referidas aos anjos reveladores, são iluminações,
porque eles as ordenam para Deus. Não o são, porém, em relação aos demônios, que assim não as
ordenam, senão à satisfação da iniqüidade própria.

RESPOSTA À SEGUNDA. — Os santos anjos são ministros da divina sabedoria. Por onde, assim como
esta permite que certos males sejam feitos pelos maus anjos ou pelos homens, por causa do bem que
deles venha, assim, os bons anjos não coíbem totalmente os maus de fazerem o mal.

RESPOSTA À TERCEIRA. — O anjo inferior, na ordem da natureza, governa os demônios, embora
superiores, nessa ordem; porque a virtude da divina justiça, a que inerem os bons anjos, é mais
poderosa que a virtude natural angélica. Por isso, entre os homens, o espiritual julga todas as coisas,
como diz a Escritura (1 Cor 11, 15). E o filósofo diz, que o virtuoso é a regra e a medida de todos os atos
humanos.