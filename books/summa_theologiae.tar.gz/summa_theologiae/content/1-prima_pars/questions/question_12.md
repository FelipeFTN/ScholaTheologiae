# Questão 12: Como Deus é conhecido por nós.
Tendo, no que fica dito, tratado de como Deus é, em si mesmo, resta tratarmos como é, em relação ao
nosso conhecimento, i. é, como é conhecido pelas criaturas.
E nesta questão, discutem-se treze artigos:

## Art. 1 — Se algum intelecto criado pode ver a Deus em essência.
(Infra., a. 4, ad 3; Ia Iae., q. 3, a. 8, et q. 5, a. 1; IV Sent., dist. XLIX, q. 2, a. 1; III Cont. Gent., cap. LI, LIV,

LVII; De Verit., q. 8, a. 1; Quodl., X, q. 8; Compend. Theol., cap. CIV, et part. II cap. XI, X; in Matt., cap. V;
in Ioan., cap. I, lect. XI).
O primeiro discute-se assim. — Parece que nenhum intelecto criado pode ver a Deus em essência.

1. — Pois, Crisóstomo, expondo aquilo do Evangelho (Jo 1, 18): Ninguém jamais viu a Deus, diz: o que
Deus é, em si mesmo, não somente os profetas mas, nem os anjos e os arcanjos o viram. Pois, que
criatura poderá ver, como é, o incriado? E também Dionísio, falando de Deus: os sentidos não o
alcançam, nem a fantasia, nem a opinião, nem a razão, nem a ciência. 2. Demais. — O infinito, como tal,
é, em si mesmo, inconhecível. Ora, Deus é infinito, como se demonstrou. Logo é, como tal, inconhecível.

3. Demais. — O intelecto criado só pode conhecer o que existe, pois o que primeiramente cai sob a
apreensão do sentido é o ente. Ora, Deus, não é um existente, mas está acima de toda a existência,
como diz Dionísio.

4. Demais. — Sendo o objeto conhecido a perfeição do ser que conhece, deve haver proporção entre
um e outro. Ora, o intelecto criado, distando infinitamente de Deus, não há nenhuma proporção entre
eles. Logo, nenhum intelecto criado pode ver a Deus em essência.
Mas, em contrário, diz a Escritura (1 Jo 3, 2): Nós outros o veremos bem como ele é.

SOLUÇÃO. — Como um ser é conhecível enquanto atual, Deus, ato puro, sem nenhuma potência, é, em
si mesmo, soberanamente conhecível. Mas, o que é, em si mesmo, soberanamente conhecível pode não
o ser a um determinado intelecto, pelo próprio excesso de sua inteligibilidade; assim, o sol,
soberanamente visível, não pode ser visto pelo morcego, por causa do excesso da sua luz. — levando
isto em consideração, certos disseram que nenhum intelecto criado pode ver a Deus, em essência. —
Mas, esta opinião é errônea. Pois, consistindo a felicidade última do homem, na sua altíssima operação,
que é a do intelecto, se o intelecto criado não pudesse nunca ver a essência de Deus, ou não alcançaria
nunca a beatitude, ou esta haveria de consistir em outro ser que não Deus, o que é contrário à fé. Pois, a
perfeição última da criatura racional está no que é o princípio da sua existência, e um ser é perfeito na
medida em que atinge o seu princípio. Além disso, tal opinião é também contrária à razão, pois é ínsito
no homem o desejo natural de conhecer a causa, depois de conhecido o efeito, nascendo daqui a
admiração. Se, portanto, a inteligência da criatura racional não pudesse atingir a causa primeira das
coisas, seria vão o desejo da natureza. — Por onde, devemos admitir, pura e simplesmente, que os bem-
aventurados vêem a essência de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Um e outro passo referem-se à visão da compreensão e,
por isso, antes, Dionísio tinha dito: De todos ele é universalmente incompreensível e os sentidos etc. E
Crisóstomo, logo depois das palavras citadas, acrescenta: Visão, aqui, significa a contemplação e a
compreensão certíssima do Pai, tal como o Pai mesmo a tem do Filho.

RESPOSTA À SEGUNDA. — O infinito próprio à matéria, não delimitada pela forma, é, em si mesmo,
inconhecível, porque todo o conhecimento se realiza por meio da forma. Más, o infinito da forma não
delimitada pela matéria é, em si mesmo, soberanamente conhecível. Ora, é deste último modo, e não
do primeiro, que Deus é infinito, como do sobredito resulta.

RESPOSTA À TERCEIRA. — Não se diz que Deus é um inexistente porque de nenhum modo exista, mas,
por estar acima de tudo o que existe, sendo o seu próprio ser. Donde se segue, não que seja
absolutamente inconhecível, mas, que excede todo conhecimento, isto é, não pode ser compreendido.

RESPOSTA À QUARTA. — Proporção tem duplo sentido. Num, significa relação certa entre duas
quantidades; assim, duplo, triplo, igual são espécies de proporção. Noutro, significa qualquer proporção
entre dois termos; e assim, pode haver proporção entre a criatura e Deus, enquanto aquele se lhe refere
como o efeito à causa, e a potência ao ato. E neste sentido o intelecto criado pode ser proporcionado ao
conhecimento de Deus.

## Art. 2 — Se a essência de Deus é vista pelo intelecto criado mediante alguma imagem interior.
(III Sent., dist. XIV, a. 1, q. 3; IV, dist. XLIX, q. 2, a. 1; De Verit., q. 8, a. 1; q. 10, a. 2; III Cont. Gent., cap.

XLIX, LI; IV, cap. VII; Quodl., VII, q. 1, a. 1; Compend. Theol., cap. CV, et part II, cap. IX; in Ioan., cap. I,
lect. XI; cap. XIV, lect. II; in I Cor., cap. XIII, lect. IV; De div. Nom., cap. I, lect. I; in Boet., De Trin., q. 1, a.
2)
O segundo discute-se assim. — Parece que a essência de Deus é vista pelo intelecto criado mediante
uma imagem interior.

1. — Pois, diz a Escritura (1 Jo 3, 2): Sabemos que, quando ele aparecer, seremos semelhantes a ele;
porquanto, nós outros o veremos bem como ele é.

2. Demais.— Agostinho diz: Quando conhecemos a Deus, forma-se em nós uma imagem dele.

3. Demais. — A inteligência em ato é idêntica ao inteligível em ato, como o sentido em ato o é ao
sensível em ato. Ora, tal, não se dá senão em quanto o sentido é informado pela imagem da coisa
sensível, e o intelecto pela da coisa inteligida. Logo, se Deus for visto em ato pelo intelecto criado,
necessariamente há de sê-lo por alguma imagem.
Mas, em contrário, Agostinho, explicando o passo do Apóstolo — vemos agora como num espelho em
enigma. — diz: As palavras espelho e enigma podem-se entender como significando quaisquer imagens
acomodadas ao nosso conhecimento de Deus. Ora, ver a Deus em essência, não é vê-lo
enigmaticamente, nem através de um espelho; antes, é vê-lo de modo oposto a este último. Logo, a
divina essência não é vista por meio de imagens.

SOLUÇÃO. — Tanto para a visão sensível, como para a intelectual, duas condições se requerem: a
virtude visiva e a união da coisa vista com a potência que vê; pois, a visão atualiza-se só porque a coisa
vista está, de certo modo, em quem vê. Ora, é claro que as coisas corpóreas vistas não podem estar em
essência, em quem as vê, mas só em imagem; assim como está nos olhos, não a substância, mas, a
imagem da pedra, pela qual a visão se atualiza. Do contrário, se a coisa vista fosse também o princípio
da virtude visiva, necessariamente, quem a visse dela receberia tanto a virtude da visão como a forma
pela qual a vê.
Ora, é manifesto que Deus é, de um lado, o autor da faculdade intelectiva e, de outro lado pode ser
visto pela inteligência. E como a virtude intelectiva da criatura não é a essência de Deus, conclui-se que
é uma imagem participada dela, que é a inteligência primeira. Por onde, a virtude intelectual da criatura
é chamada um certo lume inteligível, quase derivado da luz primeira, quer isto se entenda da virtude
natural, ou de alguma perfeição acrescentada, na ordem da graça ou da glória. Logo, para ver a Deus, é
necessária uma certa imagem dele, na potência visiva, pela qual a inteligência se torna capaz de vê-lo.
Mas, quanto à coisa vista, que, necessariamente há de unir-se, de algum modo, ao sujeito que vê, a
essência de Deus não pode ser vista por nenhuma imagem criada. Primeiro, porque, como diz Dionísio,
por meio de imagens de coisas de ordem inferior, de nenhum modo podem ser conhecidas coisas
superiores; assim pela imagem de um corpo, não pode ser conhecida a essência de um ser incorpóreo;
e, com maioria de razão, a essência de Deus não pode ser vista por nenhuma espécie criada. Segundo,
porque a essência de Deus é o seu próprio ser, como já se demonstrou, o que não se dá com nenhuma
forma criada, que, logo, não pode ser imagem que represente, ao sujeito que vê, a sobredita essência —
Terceiro, porque a divina essência é algo de incircunscrito, contendo em si de modo sobre-eminente
tudo o que pode ser expresso ou inteligido pelo intelecto criado; e, portanto, de nenhum modo pode ser
representada por qualquer espécie que seja, porque toda forma criada é determinada por alguma
noção, como a sabedoria, ou a potência, ou a existência mesma, ou algo de semelhante. Por onde, dizer
que Deus pode ser visto por meio de alguma imagem, é dizer que a essência divina não pode ser vista, o
que é errôneo.
Logo, devemos dizer que para vermos a essência de Deus, é necessário alguma semelhança por parte da
potência visiva, a saber, o lume da glória divina, ajudando o intelecto para que veja a Deus, como está
na Escritura (Sl 35, 10): E no teu lume veremos o lume. Logo, a essência de Deus não pode ser vista por
nenhuma imagem criada, que a represente tal como ela em si mesma é.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O passo aduzido se refere à imagem que participa do
lume da glória.

RESPOSTA À SEGUNDA. — No lugar citado, Agostinho refere-se ao conhecimento de Deus, que temos
nesta vida.

RESPOSTA À TERCEIRA. — A divina essência é o seu ser mesmo. Por onde, assim como as outras formas
inteligíveis, que não são o próprio ser, unem-se ao intelecto por um certo ser, pelo qual o informam e
atualizam, assim, a essência divina une-se ao intelecto, criado, como inteligência em ato que já é,
atualizando o intelecto, por si mesma.

## Art. 3 — Se a essência de Deus pode ser vista com os olhos do corpo.
(Infra., a. 4, ad 3; IIa IIae, q. 175, a. 4; IV Sent., dist. XLIV, q. 2, a. 2; in Matt., cap. V.)
O terceiro discute-se assim. — Parece que a essência de Deus pode ser vista com os olhos do corpo.

1. — Pois, diz a Escritura (Jó 19, 26): E na minha carne verei a Deus, etc.; e ainda (42, 5): Eu te ouvi por
ouvido da orelha, mas agora te vê o meu olho.

2. Demais. — Agostinho diz: A virtude dos olhos deles (dos bem-aventurados) será, pois, mais poderosa;
não que vejam mais penetrantemente do que dizem que as serpentes ou as águias vêem;
porquanto, por maior que seja a intensidade da vista desses animais, não podem ver mais
que os corpos; mas, porque verão os seres incorpóreos. Ora, quem pode ver o incorpóreo pode elevar-
se até à visão de Deus. Logo, os olhos glorificados podem ver a Deus.

3. Demais. — Deus pode ser visto, em visão imaginária, pelo homem, pois diz a Escritura (Is 6, 1): Vi o
Senhor assentado sobre um alto e elevado sólio, etc. Ora, sendo a fantasia um movimento produzido
pelo sentido, em ato, a visão imaginária origina-se do sentido, como ensina Aristóteles: Logo, Deus pode
ser visto por visão sensível.
Mas, em contrário, diz Agostinho: A Deus nunca ninguém viu, nem nesta vida, tal como ele é, nem na
vida dos anjos, de modo porque são vistos os seres materiais, por visão corpórea.

SOLUÇÃO. — É impossível que Deus seja visto, quer pelo sentido da vista, quer por algum outro sentido
ou potência da parte sensitiva. Pois, toda potência desse gênero é ato de um órgão corpóreo, como a
seguir se dirá. Ora, o ato é proporcionado à potência a que pertence. Logo, nenhuma potência sensível
pode ir além dos seres corpóreos. Ora, sendo Deus incorpóreo, como já demonstramos, não pode ser
visto pelo sentido, nem pela imaginação, mas só pelo intelecto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A expressão — na minha carne verei a Deus, meu
salvador — não significa que Deus haja de ser visto com os olhos da carne. Assim também o passo —
mas agora te vê o meu olho se refere à visão mental, no sentido do Apóstolo (Ef 1, 17): Deus vos dê o
espírito de sabedoria e de luz, para o conhecerdes, os olhos iluminados do vosso coração.

RESPOSTA À SEGUNDA. — Agostinho emprega, no passo aduzido, linguagem dubitativa e condicional, o
que é claro pelo que diz antes: Pois eles teriam uma potência toda diferente (i. é, os olhos dos
glorificados) se por eles fossem vistas as naturezas incorpóreas. E, logo depois, vem a SOLUÇÃO.:
É muito crível que, então, veremos os corpos que formam os novos céus e as terras novas, de modo que
vejamos, com claríssima evidência, Deus presente em toda parte e governando todas as coisas, mesmo
as corpóreas; não como agora, apreendendo com inteligência as coisas invisíveis de Deus, por meio das
suas criaturas; mas, como no meio de homens vivos, e exercendo os movimentos da vida, logo que os
vemos, não cremos apenas que vivem, mas os vemos realmente, como tais. Donde é claro, que ele quer
dizer, que os olhos glorificados. hão-de ver a Deus como agora os nossos olhos vêem a vida de um
homem. Ora, esta não é vista pelos olhos corpóreos, como algo de visível em si mesma, mas como um
sensível acidental, que não é conhecido pelo sentido, mas conjuntamente com este, por alguma outra
potência cognoscitiva. Porém, em virtude da perspicácia do intelecto e da refulgência da claridade
divina, num mundo renovado, pode-se dar que, da visão dos corpos, imediatamente conheçamos
intelectualmente a divina presença;

RESPOSTA À TERCEIRA. — Na visão imaginária não se vê a essência de Deus, mas realiza-se uma forma
na imaginação, representativa de Deus, segundo uma certa semelhança, no gênero daquelas de que se
serve a Escritura divina, quando descreve metaforicamente as coisas sensíveis.

## Art. 4 — Se o intelecto criado pode, pelas suas potências naturais, ver a essência divina.
(Infra., q. 64, a. 1, ad 2; Ia IIae., q. 5, ª 5; II Sent., dist. IV a. 1; dist. XXIII, q.2, a. 1; IV, dist. XLIX, q. 2, a. 6; I
Cont. Gent., cap. III; III, cap. XLIX, LII; De Verit., q. 8, art. 3; De Anima, a. 17, ad 10; in I Tim., cap. VI, lect.

III).
O quarto discute-se assim. — Parece que o intelecto criado pode, pelas suas potências naturais, ver a
essência divina.

1. — Pois, diz Dionísio: O anjo é um espírito puro, claríssimo, recebendo em si, por assim dizer, toda a
beleza de Deus . Ora, um ser é visto quando é visto o seu espelho. Logo, como o anjo se intelige a si
mesmo, pelas suas faculdades naturais, há-de inteligir também, do mesmo modo, a essência divina.

2. Demais. — O que é sumamente visível torna-se-nos menos visível por defeito da possa vista corpórea
ou intelectual. Ora, o intelecto angélico não padece nenhum defeito. Logo, sendo Deus sumamente
inteligível, há-de sê-lo para o anjo, e, portanto, este pode, pelas suas potências naturais, apreender
outros inteligíveis, e, com maior razão, inteligir a Deus.

3. Demais. — O sentido do corpo não pode elevar-se até inteligir a substância incorpórea, que lhe está
acima da natureza. Se, pois, ver a Deus em essência excede a natureza de qualquer intelecto criado,
conclui-se que nenhuma pode chegar a ver a essência de Deus, o que é errôneo, como do sobredito
resulta. Logo, é natural ao intelecto criado ver a essência de Deus.
Mas, em contrário, a Escritura (Rm 6, 23): A graça de Deus é a vida eterna. Ora, esta consiste na visão da
essência divina, conforme aquilo do Evangelho (Jo 17, 3): Esta é a vida eterna em que eles conheçam por
um só verdadeiro Deus a ti, etc. Logo, ver a essência de Deus convém ao intelecto criado, por graça e
não por natureza.

SOLUÇÃO. — É impossível ao intelecto criado ver a essência de Deus, pelas suas faculdades naturais.
Pois, o conhecimento opera-se pela presença do objeto no sujeito, Ora, aquele está no segundo,
conforme ao modo deste. Logo, o conhecimento de qualquer sujeito conhecente há-de ser conforme ao
modo da natureza deste. Se, portanto, o modo de ser do objeto conhecido exceder o modo da natureza
do sujeito, que conhece, o conhecimento desse objeto há-de, necessariamente, exceder a natureza do
sujeito.
Ora, é múltiplo o modo de existir das coisas. Umas, por natureza, não têm o ser senão numa certa
matéria individual, e tais são todos os seres corpóreos. Outras, e tais as substâncias incorpóreas a que
chamamos anjos, são por natureza subsistentes por si mesmas, sem nenhuma matéria; contudo, não
são o próprio ser mas o possuem pois, só de Deus é próprio o modo de existir, pelo qual é o seu mesmo
ser subsistente.
Ora, sendo a nossa alma, pela qual conhecemos, a forma de uma determinada matéria, é-nos conatural
conhecer as coisas que têm o ser só na matéria individual. A nossa alma, porém, encerra virtudes
cognoscitivas de duas espécies, uma é ato de órgão corpóreo e a esta é conatural conhecer as coisas
que têm o ser na matéria individual; e, por isso, os sentidos não podem conhecer senão o singular.
Outra, porém, é a virtude cognoscitiva do intelecto... que não é ato de nenhum órgão corpóreo; e por
isso é-nos conatural conhecer, por meio dele as naturezas que têm o ser numa determinada matéria
individual, mas não como tais, senão enquanto abstrai dessa matéria pela consideração da inteligência.
Por onde, pela inteligência, podemos conhecer tais coisas universalmente, o que sobrepuja a
capacidade do sentido. — Ao intelecto angélico, por seu lado, é conatural conhecer as naturezas, que
não existem na matéria, o que sobreleva a faculdade natural do intelecto, no estado da vida presente,
em que está unida ao corpo.
Ora, de tudo isto se conclui, que conhecer o ser mesmo subsistente é conatural só ao intelecto divino e
sobre-excede a faculdade natural de qualquer intelecto criado, porque nenhuma criatura é o seu
próprio ser, mas o tem participadamente. — Logo, o intelecto criado não pode ver a Deus, por essência,
a menos que Deus, por graça, se lhe una e se lhe torne inteligível.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É conatural ao anjo o modo de conhecer a Deus
consistente em ter o próprio anjo, em si, uma refulgente semelhança de Deus. Ora, conhecer a Deus por
qualquer semelhança criada não é conhecer a essência de Deus, como acima ficou dito. Logo, não se
conclui que o anjo possa, pelas suas potências naturais, conhecer a essência de Deus.

RESPOSTA À SEGUNDA. — A inteligência do anjo não tem defeito, entendendo-se esta palavra
privativamente, i. é, de modo que ao anjo falte algo do que deve ter. Tomada, porém, em sentido
negativo, não há criatura que não seja deficiente comparada com Deus, pois não tem aquela excelência
própria de Deus.

RESPOSTA À TERCEIRA. — A vista, sendo absolutamente material, de nenhum modo pode elevar-se ao
que quer que seja de imaterial. Porém o nosso intelecto, como o angélico, elevado, de certo modo e por
natureza, acima da matéria, pode ascender, pela graça, a algo de mais alto que lhe sobrepassa a
natureza. E a prova é que a vista de modo nenhum conhece por abstração o que conhece
concretamente; assim, de nenhum modo pode perceber uma natureza senão como individual. Porém, o
nosso intelecto pode considerar abstratamente o que conhece de maneira concreta. Assim, embora
conheça coisas que têm a forma realizada na matéria, contudo, decompõe o composto nas suas duas
componentes e considera a forma em si mesma. Semelhantemente, o intelecto angélico, embora lhe
seja conatural conhecer o ente concreto em uma natureza particular, pode contudo separá-lo pelo
intelecto, conhecendo que uma coisa é ele e outra, o ser que tem. Por onde, o intelecto criado sendo
capaz, por natureza, de apreender uma forma concreta e um ser concreto, abstratamente, por uma
como análise resolutiva, pode também, pela graça, ser elevado, de modo que conheça a substância
separada e o ser separado subsistente.

## Art. 5 — Se o intelecto criado precisa, para ver a essência de Deus, de algum lume criado.
(II Sent., dist. XIV, a. 1, q. 3; IV, dist., XLIX, q. 2, a. 6; III Cont. Gent., cap. LIII, LIV; De Verit., q. 8, a. 3; q.
18, a. 1, ad 1; q. 20, a. 2; Quodl., VII, q. 1, a. 1; Compend. Theol., cap. CV).
O quinto discute-se assim. — Parece que o intelecto criado não precisa de nenhum lume criado para
ver a essência de Deus.

1. — Pois, as coisas sensíveis, por si mesmas lúcidas, não precisam de nenhum outro lume para serem
vistas. Logo, nem as inteligíveis. Ora, como Deus é inteligível, não é visto por nenhum lume criado.

2. Demais. — Se Deus é visto por um intermediário não o é em essência. Ora, tal se dá se é visto por
meio de um lume criado. Logo, não é visto em essência.

3. Demais. — Nada impede que o que é criado seja natural a uma criatura. Se, pois, a essência de Deus é
vista por meio de algum lume criado, este lume poderá ser natural a alguma criatura que, então, não
precisaria de nenhum outro lume para ver a Deus, o que é impossível. Logo, não é necessário a toda
criatura acrescentar-se um lume, para ver a essência de Deus.
Mas, em contrário, a Escritura (Sl 35, 10): No teu lume veremos o lume.

SOLUÇÃO. — Tudo o que é elevado acima da natureza própria é necessário que tenha uma disposição,
que lhe seja superior; assim, se o ar tiver que receber a forma do fogo, é necessário que receba alguma
disposição para tal forma. Ora, quando um intelecto criado vê a Deus em essência, esta torna-se-lhe a
forma inteligível. Por onde, é necessário lhe seja acrescentada alguma disposição sobrenatural, para que
se eleve a tanta sublimidade. Ora, como a virtude natural do intelecto criado não lhe basta para que
veja a essência de Deus, como já demonstramos, necessário é lhe seja aumentada pela divina graça a
virtude intelectual, e este aumento chama-se iluminação do intelecto, assim como o próprio inteligível é
chamado luz ou lume, do qual diz a Escritura (Ap 21, 23): A claridade de Deus a alumiou, i. é, a sociedade
dos bem-aventurados que vêem a Deus. E este lume os torna deiformes, i. é, semelhantes a Deus,
conforme aquilo do Evangelho (1 Jo 3, 2):Quando ele aparecer, seremos semelhantes a ele e o veremos
bem como ele é.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lume criado é necessário para ver a essência de Deus;
não que torne essa essência inteligível, que, em si mesma, é incompreensível, mas porque dá ao
intelecto a capacidade de inteligir, do modo pelo qual o hábito dá a uma potência capacidade de operar.
Semelhantemente, o lume corpóreo é necessário para a visão exterior, tornando, atualmente, o meio
transparente, de maneira que possa a cor afetá-lo.

RESPOSTA À SEGUNDA. — Não é preciso que o lume em questão, necessário para vermos a essência de
Deus, seja uma imagem na qual vejamos essa essência, mas, sim uma quase perfeição do intelecto, que
o fortifica para que possa ver a Deus. Por onde, pode-se dizer, que não é um intermediário no qual, mas
antes, pelo qual Deus é visto. Ora, isto não tolhe a visão de Deus.

RESPOSTA À TERCEIRA. — A disposição para a forma do fogo não pode ser natural, senão para o que já
tem essa forma. Por onde, o lume da glória só poderia ser natural à criatura se esta fosse de natureza
divina, o que é impossível. Mas, por este lume, a criatura racional torna-se deiforme, como dissemos.

## Art. 6 — Se os que vêem a essência de Deus, uns a vêem mais perfeitamente que outros.
(Infra, q. 62, a. 9; IV Sent., dist. XLIX, q. 2, a. 4; III Cont. Gent., cap. LVIII)
O sexto discute-se assim. Parece que, dos que vêem a essência de Deus, uns não a vêem mais
perfeitamente que outros.

1. — Pois, diz a Escritura (1 Jo 3, 2): Nós outros o veremos bem como ele é. Ora, Deus só tem um modo
de ser. Logo, será visto por todos do mesmo modo e, portanto, não mais perfeitamente por uns do que
por outros.

2. Demais. — Agostinho diz que uma mesma coisa não pode ser inteligida mais por um do que por
outro. Ora, todos os que vêem a Deus em essência a inteligem; pois, Deus é visto pelo intelecto e não
pelo sentido, como já se estabeleceu. Logo, dos que vêem a essência de Deus, uns não a vêem mais
claramente que outros.

3. Demais. — Por duas razões pode uma coisa ser vista mais perfeitamente por uns do que por outros:
por causa do objeto visível, ou por causa da potência visual de quem vê. No primeiro caso, é porque o
objeto é recebido por quem vê mais perfeitamente, i. é, por semelhança mais perfeita. Ora, isto não se
dá no caso vertente, pois Deus está presente ao intelecto, que lhe contempla a essência, não por
qualquer semelhança, mas pela essência mesma. Donde se conclui, que só por diferença da potência
intelectiva é que uns a vêem mais perfeitamente que outros e, portanto, quem tiver a potência.
intelectiva naturalmente mais sublime, mais claramente a verá. Ora, isto é inadmissível, porque foi
prometida aos homens uma beatitude igual à dos anjos.
Mas, em contrário, a vida eterna consiste na Visão de Deus, conforme aquilo da Escritura (Jo 17, 3): A
vida eterna porém consiste em que eles conheçam por um só verdadeiro Deus, etc. Logo, se todos vêem
igualmente a essência de Deus, na vida eterna, todos serão iguais. Ora, o Apóstolo diz o contrário (1 Cor
15, 41): Há diferença de estrela a estrela na claridade.

SOLUÇÃO. — Dos que vêem a essência de Deus, uns a vêem mais perfeitamente que outros, o que não
se dá, porque haja em uns semelhança de Deus mais perfeita que em outros; pois, essa visão não se há-
de realizar por nenhuma semelhança, como demonstramos; mas, sim, porque o intelecto de uns terá
maior virtude ou faculdade para ver a Deus, que o de outros. Ora, a faculdade de ver a Deus não é
própria ao intelecto criado, pela sua natureza mesma, mas, pelo lume da glória, que o constitui numa
como deiformidade, conforme resulta do que já foi visto. Por onde, o intelecto que mais participar do
lume da glória mais perfeitamente verá a Deus. Ora, desse lume mais participa quem mais caridade tem,
porque onde há maior caridade há mais desejo e este torna, de certo modo, quem deseja, apto e
preparado para receber o desejado. Logo, quem mais caridade tiver mais perfeitamente verá a Deus e
mais feliz será.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Na expressão — nós outros o veremos bem como ele é
— o advérbio como determina o modo da visão relativamente à coisa vista, sendo o sentido: nós o
veremos bem como ele é, porque lhe veremos o ser mesmo que se lhe identifica com a essência. Mas,
não determina o modo da visão relativamente a quem yê, como se significasse que o modo de ver será
perfeito, como perfeito é, em Deus o modo de ser.
Donde se deduz clara aRESPOSTA À SEGUNDA OBJEÇÃO. — Pois, quando se diz que uns não inteligem a
mesma coisa mais que outros, isto é verdade se se refere ao modo de ser inteligido, pois quem o
inteligir diferentemente do que é não o intelige verdadeiramente; não é verdade, porém, se se referir ao
modo de quem intelige, pois o inteligir de uns é mais perfeito que o de outros.

RESPOSTA À TERCEIRA. — A diversidade da visão não será por causa do objeto, porque o mesmo objeto
— a essência de Deus — será apresentado a todos; nem por causa da participação diversa do objeto,
por meio de semelhanças diferentes; mas, por causa da capacidade diversa dos intelectos, não natural,
mas gloriosa, como dissemos.

## Art. 7 — Se os que vêem a Deus em essência o compreendem.
(III Sent., dist. XIV, a. 2, q. 1; dist. XXVII, q. 3, a. 2; IV, dist. XLIX q. 2, a. 3; III Cont. Gent., cap. LV; Qq disp.,
De Verit., q. 2, a. 1, ad 3; q. 8, a. 2; q. 20, a. 5; De Virtut., q. 2, a. 10, ad 5; Comp. Theol., cap. CVI; in
Ioan., cap. I, lect. XI; Eph., cap. V, lect. III)
O sétimo discute-se assim — Parece que os que vêem a Deus em essência o compreendem.

1. — Pois, diz o Apóstolo (Fp 3, 12): Mas eu prossigo, para ver se de algum modo poderei compreender.
Ora, não prosseguia em vão, como ele próprio o diz (1 Cor 9, 26): Pois eu assim corro, não como a coisa
incerta. Logo, compreende. E, pela mesma razão os outros, que ele para tal convida, dizendo (1 Cor 9,
24): correi de tal maneira que o alcanceis.

2. Demais. — Como diz Agostinho, é compreendido o que é totalmente visto, de modo que nada escape
a quem vê. Ora, se Deus é visto em essência, há-de sê-lo totalmente e de modo que nada escape a
quem o vê, pois Deus é simples. Logo, quem o vê em essência o compreende.

3. Demais. — E nem vale dizer que é visto todo, mas não totalmente. — Totalmente exprime o modo de
quem vê, ou o modo de ser visto. Ora, quem vê a Deus em essência o vê totalmente, se nos referirmos
ao modo do ser visto, pois o vê como ele é, conforme se disse. Semelhantemente, vê-o totalmente, se
nos referirmos ao modo de quem vê, pois o intelecto de quem vê a essência de Deus a vê com toda
virtude de que é capaz. Logo, quem vê a Deus em essência vê-o totalmente. Logo, compreende-o.
Mas, em contrário, a Escritura (Jr 32, 18): Ó fortíssimo, grande e poderoso, o Senhor dos exércitos é o
teu nome. Grande conselho e incompreensível no pensamento. Logo, não pode ser compreendido.

SOLUÇÃO. — Nenhum intelecto criado pode compreender a Deus; porém, atingi-lo, de qualquer modo,
pela mente, é grande beatitude, diz Agostinho.
E isto se evidencia considerando que compreendemos o que perfeitamente conhecemos. Ora, é
perfeitamente conhecido o que o é em toda a sua cognoscibilidade. Por onde, não é compreendido
aquilo que, sendo cognoscível por ciência demonstrativa, é admitido por opinião fundada em alguma
razão provável. Assim, compreende que um triângulo tem os três ângulos iguais a dois retos quem
aceitar essa verdade em virtude de uma demonstração; quem a aceitar, porém, por uma opinião
provável, porque é uma proposição expressa pelos sábios ou por muitos outros, não a compreende,
porque não alcança o perfeito modo do conhecimento pelo qual essa verdade é cognoscível.
Ora, nenhum intelecto criado pode alcançar aquele perfeito modo de conhecimento pelo qual a
essência divina é cognoscível, o que assim se demonstra. Um ser é cognoscível na medida em que é
atual. — Ora, Deus, cujo ser é infinito, como já demonstramos, é infinitamente cognoscível; mas,
nenhum intelecto criado pode conhecê-lo infinitamente, porque cada qual conhece a divina essência
mais ou menos perfeitamente, conforme é inundado de maior ou de menor lume da glória. Ora, como o
lume criado da glória, recebido por qualquer intelecto criado, não pode ser infinito, é impossível que
qualquer intelecto dessa natureza conheça infinitamente a Deus. Logo, não pode compreendê-lo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A palavra compreensão tem duplo sentido. Um estrito e
próprio, segundo o qual um objeto se inclui no sujeito que compreende; e, neste sentido, Deus não
pode, de nenhum modo, ser compreendido pelo intelecto, nem por nenhuma outra potência, porque,
sendo infinito, não pode ser incluído no finito, de maneira que algum ser finito possa compreendê-lo tal
como infinitamente é. Ora, é dessa compreensão que agora se trata. Mas, a compreensão, em sentido,
mais amplo, opõe-se à pesquisa; assim, diz-se que compreende aquele que possui a quem procurava. E
neste sentido, Deus é compreendido pelos bem-aventurados, conforme aquilo da Escritura (Ct 3,
4): Aferrei dele nem o largarei; sentido no qual se entendem os lugares do Apóstolo sobre a
compreensão. Neste sentido, a compreensão é um dos três dotes da alma correspondente à esperança,
como a visão à fé, e a fruição à caridade. Nós, porém, não temos ou possuímos tudo o que vemos, pois
vemos às vezes, o que está distante ou o que escapa ao nosso poder. Nem tão pouco, fruímos de tudo o
que temos, quer porque não nos deleitamos com tais causas, quer porque não são o fim último do
nosso desejo, que não satisfazem nem acalmam. Ora, estas três coisas os eleitos as possuem em Deus:
vêem-no e, por isso, têm-no sempre presente e podem vê-lo sempre; e, por fim, possuindo-o, fruem-no
como fim último, que satisfaz o desejo.

RESPOSTA À SEGUNDA. — Deus é incompreensível, não porque haja uma parte dele que é vista e outra
não; mas, porque não é visto tão perfeitamente como é visível. Assim, uma proposição demonstrável
não é conhecida total e perfeitamente, como é cognoscível, quando conhecida por uma razão provável,
embora desse tudo, tudo dela se conheça — sujeito, predicado e composição. Por isso Agostinho,
definindo a compreensão, diz: Compreendemos o todo quando o vemos de modo tal que nada dele nos
escape, ou quando os seus limites podem ser vistos pelo olhar. Ora, vemos os limites de um objeto
quando chegamos ao fim, no modo de conhecê-lo.

RESPOSTA À TERCEIRA. — A palavra — totalmente — significa o modo de ser do objeto; não que o
modo total de ser do objeto não seja apreendido pelo conhecimento mas, porque não é o modo de ser
do conhecimento. Por onde, quem vê a Deus em essência vê, nele, que existe infinitamente e é
infinitamente cognoscível; mas, esse modo infinito não lhe pertence, de maneira que conheça
infinitamente; assim, podemos saber provavelmente que uma proposição é demonstrável, embora não
a conheçamos demonstrativamente.

## Art. 8 — Se os que vêem a Deus em essência vêem tudo em Deus.
(Infra., q. 57, a. 5; q. 106, a. 1, ad 1; III q. 10, a. 2; II Sent., dist. XI, a. 2; III, dist. XIV, a. 2, q. 2; IV, dist. XLV,
q. 3, a. 1; dist. XLIX, q. 2, a. 5; III Cont. Gent., cap. LVI LIX; De Verit., q. 8, a. 4; q. 20, a. 4, 5).
O oitavo discute-se assim. — Parece que os que vêem a Deus em essência vêem tudo em Deus.

1. Pois, diz Gregório: O que não verão os que vêem a quem tudo vê? Ora, Deus vê tudo. Logo, tudo
vêem os que vêem a Deus.

2. Demais. — Quem vê um espelho vê tudo o que nele reflete. Ora, todos os seres feitos por Deus, ou os
que ele pode fazer, nele se refletem como num espelho; pois Deus conhece, em si mesmo, todas as
coisas. Logo, quem vê a Deus vê tudo o que existe ou pode existir.

3. Demais. — Quem intelige o mais intelige o menos, como diz Aristóteles. Ora, tudo o que Deus faz ou
pode fazer é menos que a sua essência. Logo, quem intelige a Deus intelige tudo que Deus faz ou pode
fazer.

4. Demais. — A criatura racional deseja naturalmente saber tudo. Se, pois, vendo a Deus, não souber
tudo, não acalma o seu desejo natural e, então, vendo a Deus, não será feliz, o que é inadmissível. Logo,
vendo a Deus sabe tudo.
Mas, em contrário, os anjos vêem a Deus por essência e, entretanto, não sabem tudo. Pois os inferiores
são purificados da ignorância, pelos superiores, como diz Dionísio. E, além disso, eles não conhecem os
futuros contingentes e as cogitações dos corações, que só a Deus pertencem. Logo, os que vêem a
essência de Deus nem por isso vêem tudo.

SOLUÇÃO. — O intelecto criado, vendo a essência divina, não vê nela, por isso, tudo o que Deus faz ou
pode fazer. Pois, é manifesto que as coisas são vistas em Deus segundo nele estão. Ora, todas as coisas
estão em Deus como os efeitos estão virtualmente na causa. Por onde, são vistas em Deus como
aqueles, nestas. Mas, é manifesto que, quanto mais perfeitamente uma coisa for vista, tanto mais
efeitos nela poderão ser descobertos. Assim, quem tem um intelecto eminente deduz imediatamente,
de um principio demonstrativo proposto, o conhecimento de muitas conclusões, o que não pode fazer
quem, dotado de intelecto mais fraco, precisa de receber de outrem a explicação de cada uma dessas
conclusões. Por onde, o intelecto que compreende totalmente a causa, pode conhecer, nela, todos os
efeitos com as suas razões. Ora, nenhum intelecto criado pode compreender totalmente a Deus, como
já demonstramos. Logo, nenhum, vendo a Deus, pode saber tudo o que ele faz ou pode fazer, o que
seria compreender-lhe o poder. Mas o intelecto que mais perfeitamente vir a Deus, tanto mais poderá
conhecer o que ele faz ou pode fazer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Gregório refere-se à suficiência do objeto, i. é, Deus que,
em si mesmo, contém suficientemente todas as cousas e as manifesta. Mas daí não se segue que, quem
o vê tudo conheça, porque ninguém o compreende perfeitamente.

RESPOSTA À SEGUNDA. — Quem vê um espelho não vê necessariamente tudo o que ele reflete, a
menos que, com o olhar, o abranja perfeitamente.

RESPOSTA À TERCEIRA. — Embora seja mais ver a Deus, que todo o resto, contudo, é mais vê-lo de
modo tal a conhecer nele todas as coisas, que de modo a nele conhecer não todas, mas poucas ou
muitas. Pois, como já se demonstrou, a multidão das causas conhecidas em Deus depende do modo
mais ou menos perfeito de o ver.

RESPOSTA À QUARTA. — O desejo natural da criatura racional é conhecer tudo o que lhe pertence à
perfeição do intelecto, a saber, as espécies, os gêneros e as razões das coisas, que verá em Deus quem
lhe vir a essência. Porém, conhecer seres singulares ou os seus pensamentos e atos não é da perfeição
do intelecto criado, nem é essa a tendência do seu desejo, bem como não lhe pertence conhecer o que
Deus não fez, mas pode fazer. Aliás, se só Deus fosse visto, fonte e princípio de todo ser e de toda
verdade, ele satisfaria o desejo natural de saber, de modo tal, que nada mais buscaríamos e seríamos
felizes. Por isso, diz Agostinho: (Ó Deus), como o homem é infeliz! Conhece tudo, menos a ti! Feliz,
contudo, de quem te conhecer, ignorando tudo o mais! Quem te conhecer, porém, a ti e a todas as
coisas, não por elas será mais feliz, mas, por ti só, bem-aventurado.

## Art. 9 — Se os que vêem a divina essência nela vêem as coisas por meio de certas imagens.
(III Sent., dist. XIV, a. 1, q. 4, 5; De Verit., q. 8, a. 5).
O nono discute-se assim. — Parece que os que vêem a divina essência nela vêem as coisas por meio
de certas imagens.

1. — Pois, todo conhecimento se dá por uma assimilação entre o conhecente e o conhecido. Assim, se o
intelecto, em ato de conhecimento, se torna, no objeto inteligido, em ato de inteligibilidade, é por ser
informado pela semelhança do que deve conhecer; do mesmo modo que, se a visão em ato se torna no
sensível em ato, é porque a pupila é informada pela semelhança da cor. Por onde, o intelecto que vê a
Deus em essência, para ver nele algumas criaturas há-de ser informado pelas semelhanças delas.

2. Demais. — Conservamos na memória as coisas que vimos primeiro. Ora, São Paulo, vendo num rapto
a essência de Deus, como diz Agostinho, recordava-se, depois de acabada a visão, de muitas coisas que
nela vira; e, por isso, ele mesmo diz (2 Cor 12, 4) que ouviu lá palavras secretas que não é permitido a
um homem referir. Logo, é forçoso admitir que no seu intelecto permaneceram certas semelhanças das
coisas de que se recordava. E, pela mesma razão, quando contemplava presencialmente a essência de
Deus, tinha certas semelhanças ou espécies das coisas que nela via.
Mas, em contrário, pela mesma espécie vemos o espelho e as coisas que ele reflete. Ora, todas as coisas
são vistas em Deus, que é um como espelho inteligível. Logo, se Deus mesmo não é visto por meio de
nenhuma semelhança, mas pela sua essência, também as coisas nela vistas não são vistas por nenhumas
semelhanças ou espécies.

SOLUÇÃO. — Os que contemplam a Deus em essência não vêem por nenhumas espécies as coisas que
nela vêem, mas, por essa essência divina mesma, que lhes está unida ao intelecto. Assim, conhecemos
uma coisa quando temos uma imagem dela, o que de dois modos se pode dar. Pois, como duas coisas
iguais a uma terceira são iguais entre si; de dois modos a potência cognoscitiva pode assimilar-se a um
objeto cognoscível. Ou em si, quando é diretamente informada pela imagem do objeto, e então o
conhece em si mesmo; ou quando informada pela espécie de outro objeto semelhante ao primeiro, e
então este não é conhecido em si mesmo mas, por meio do que lhe é semelhante. Assim, um é o
conhecimento que temos de um homem, em si mesmo, e outro, o que dele temos por meio de uma
imagem. Por onde, conhecer as coisas pelas semelhanças delas em nós existentes é conhecê-las em si
mesmas ou nas suas naturezas próprias; mas, conhecê-las por meio das imagens delas preexistentes em
Deus, é vê-las em Deus. E estes dois modos de conhecimento diferem. Por isso, o conhecimento que
têm das coisas os que as vêem em Deus mesmo, cuja essência contemplam, não é um conhecimento
mediante outras imagens, mas mediante a só essência divina presente ao intelecto, pela qual também
Deus é visto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O intelecto criado de quem vê a Deus se assimila às
coisas vistas enquanto ele está unido com a divina essência, na qual preexistem as imagens de todas as
coisas.

RESPOSTA À SEGUNDA. — Há certas potências cognoscitivas, que, das espécies primeiramente
concebidas, podem formar outras; assim, a imaginação forma, das espécies pré-concebidas de monte e
de ouro, a espécie de monte áureo; e o intelecto, das espécies pré-concebidas de gênero e de diferença,
a diferença específica. E, igualmente, da semelhança de imagem podemos formar, em nós, a
semelhança do ser ao qual ela pertence. E assim, Paulo, ou qualquer outro, vendo a Deus, pela visão
mesma da essência divina, pode formar em si semelhanças das coisas vistas na divina essência; e essas
permaneceram em Paulo mesmo depois que deixou de contemplar a essência de Deus. Esta visão,
porém, pela qual são vistas as coisas, por meio de tais espécies assim concebidas, é diferente da visão
pela qual as coisas são vistas em Deus.

## Art. 10 — Se os que vêem a Deus em essência vêem simultaneamente tudo o que nele vêem.
(Infra., q. 58, a. 2; II Sent., dis. III, q. 2, a. 4; III dist. XIV, a. 2, q. 4; III Cont. Gent., cap. LX; De Verit., q. 8, a.
14; Quodl., VII, q. 1, a. 2).
O décimo discute-se assim. — Parece que os que vêem a Deus em essência não vêem
simultaneamente tudo o que nele vêem.

1. — Pois, segundo o Filósofo, podemos saber muitas coisas; mas, inteligir só uma. Ora, como Deus é
visto pelo intelecto, inteligimos o que nele vemos. Logo, os que vêem a Deus não podem ver muitas
coisas simultaneamente.

2. Demais. — Agostinho diz que Deus move a criatura espiritual no tempo, i. é, pela inteligência e pelo
afeto. Ora, a criatura espiritual é o anjo, que vê a Deus. Logo, os que vêem a Deus inteligem e amam
sucessivamente, pois o tempo implica a sucessão.
Mas, em contrário, diz Agostinho: Nossos pensamentos não serão volúveis, indo e vindo de um objeto
para outro, mas, simultaneamente e de um só olhar veremos toda a nossa ciência.

SOLUÇÃO. — As coisas vistas no Verbo sê-lo-ão simultânea e não, sucessivamente. Isto se prova
considerando que não podemos inteligir muitas coisas simultaneamente, porque as inteligimos por
espécies diversas. Ora, por espécies diversas, o intelecto de um mesmo homem não pode ser
simultaneamente informado, para, por meio delas, inteligir, assim como um mesmo corpo não pode ter
simultaneamente diversas figuras. Por onde, as coisas que podem ser inteligidas por meio de uma só
espécie, podem ser simultaneamente inteligidas. Assim, as diversas partes de um todo são inteligidas
sucessiva, e não, simultaneamente, se cada uma delas for inteligida por meio da sua espécie própria;
serão inteligidas, ao contrário, simultaneamente, se todas o forem pela espécie do todo. Ora, como já
demonstramos, as coisas vistas em Deus não são vistas cada uma pela sua representação, mas, todas,
pela essência una de Deus. Por onde, são vistas simultânea e não, sucessivamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Por meio de uma só espécie inteligimos um só objeto;
mas, as coisas inteligidas por meio de uma mesma espécie são inteligidas simultaneamente; assim, pela
espécie de homem inteligimos o que é animal e o que é racional e, pela espécie de casa, a parede e o
teto.

RESPOSTA À SEGUNDA. — Os anjos não conhecem simultaneamente todas as coisas, pelo
conhecimento que lhes é natural, em virtude do qual conhecem as coisas por espécies diversas infusas:
e, portanto, quanto à inteligência, são movidos no tempo. Mas, as coisas que vêem em Deus eles as
vêem simultaneamente.

## Art. 11 — Se nesta vida podemos ver a Deus em essência.
(IIa. IIae., q. 180, a. 5; III Sent., dist. XXVII, q. 3, art. 1; dist. XXXV, q. 2, a. 2, q. 2; IV, dist. XLIX, q. 2, a. 7; III
Con. Gent., cap. XLVII; De Verit., q. 10, a. 2; Quodl. I, q. 1; II Cor., cap. II, lect. 1).
O undécimo discute-se assim. — Parece que nesta vida podemos ver a Deus em essência.

1. — Pois, diz a Escritura (Gn 32, 30): Eu vi a Deus face a face. Ora, ver Deus face a face é vê-lo em
essência, como diz o Apóstolo (1 Cor 13, 12): Nós agora vemos a Deus como por um espelho, em
enigmas; mas então face a face. Logo, nesta vida podemos ver a Deus em essência.

2. Demais. — O Senhor diz de Moisés (Nm 12, 8): Porque eu lhe falo cara a cara, e ele vê o Senhor
claramente, e não debaixo de enigmas ou figuras. Ora, isto é ver a Deus em essência.

3. Demais. — Aquilo pelo que conhecemos e julgamos tudo o mais deve-nos ser conhecido em si
mesmo. Ora, já nesta vida, conhecemos tudo em Deus, pois diz Agostinho: Se ambos vemos que é
verdade o que dizes e o que digo, onde, pergunto, o vemos? Nem em ti nem em mim, mas ambos, nessa
verdade mesma incomunicável superior às nossas mentes. E o mesmo, noutro lugar, diz que julgamos
de tudo segundo a verdade divina. E ainda, noutro: É próprio da razão julgar das coisas corpóreas por
meio de razões incorpóreas e sempiternas que, se não fossem superiores à nossa mente, não seriam por
certo incomutáveis. Logo, já nesta vida vemos a Deus em si mesmo.

4. Demais. — Segundo Agostinho, tudo o que está na alma em essência é visto por uma visão
intelectual. Ora, esta atinge as coisas inteligíveis, não por semelhanças, mas pelas essências mesmas
delas, como diz ainda esse autor, no mesmo passo. Ora, como Deus está em essência em a nossa alma,
por essa essência nós o vemos.
Mas, em contrário, a Escritura (Ex 33, 20): Nenhum homem me verá e depois, viverá. O que comenta a
Glosa: Nesta vida mortal podemos ver a Deus por certas imagens, não porém pela espécie mesma da
sua natureza.

SOLUÇÃO. — Um homem puramente homem não pode ver a Deus, em essência, senão separado desta
vida mortal. E a razão é que, como já dissemos, o modo de conhecer depende da natureza do sujeito
conhecente. Ora, nesta vida, a nossa alma tem o ser na matéria corpórea. Logo, não conhece
naturalmente senão o que tem a forma na matéria, ou que, por meio desta, pode ser conhecido. Ora, é
manifesto, que a divina essência não pode ser conhecida pelas naturezas das coisas materiais. Pois,
como já demonstramos, o conhecimento de Deus, por meio de qualquer semelhança criada, não é a
visão da sua essência. Por onde, é impossível à alma do homem, nesta vida, ver a essência de Deus. E a
prova está em que a nossa alma, quanto mais abstrata das coisas corpóreas, tanto mais capaz se torna
dos inteligíveis abstratos; e, por isso, no sonho e no alheamento dos sentidos do corpo, são melhor
percebidas as revelações divinas e as previsões dos futuros. Logo, ser a alma elevada até ao supremo
inteligível, que é a essência divina, não lhe é possível enquanto viver esta vida mortal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Segundo Dionísio, quando a Escritura diz que certos
viram a Deus, refere-se a certas figuras formadas, sensíveis ou imaginárias, e que representam algo de
divino, por meio de alguma semelhança. E o dito de Jacó — Eu vi a Deus face a face — refere-se, não à
essência divina, mas, à figura que representava a Deus. E o fato mesmo de ver a Deus falando, embora
em visão imaginária, implica um caso eminente de profecia, como a seguir se dirá, quando se tratar dos
graus da profecia. Ou quer designar uma certa eminência da contemplação inteligível, superior ao
estado comum.

RESPOSTA À SEGUNDA. — Assim como Deus opera miraculosa e sobrenaturalmente sobre as coisas
corpóreas, assim também, sobrenaturalmente e fora da ordem comum, elevou até à visão da sua
essência certos espíritos que, embora vivendo na carne, não lhe usavam os sentidos. É o que diz
Agostinhode Moisés, o doutor dos Judeus; e de Paulo, doutor dos gentios. E disto mais abundantemente
trataremos, quando estudarmos o rapto do Apóstolo.

RESPOSTA À TERCEIRA. — Quando dizemos que vemos tudo em Deus e de conformidade com ele
julgamos de tudo, queremos significar que tudo conhecemos e julgamos por uma participação da sua
luz; pois, o mesmo lume natural da razão é uma certa participação do divino lume; e assim também
dizemos que vemos e julgamos todos os sentidos no sol, i. é, por meio da luz do sol. Por isso, diz
Agostinho: Os objetos das ciências formam uma paisagem, que não pode ser vista senão iluminada pelo
seu sol, i. é, por Deus. Assim, pois, como para vermos o sensível não necessitamos ver a substância do
sol, assim, para vermos o inteligível não necessitamos ver a essência de Deus.

RESPOSTA À QUARTA. — A visão intelectual apreende o que está na alma em essência, como objetos
inteligíveis no intelecto. E é assim, que Deus está na alma dos bem-aventurados; não, porém, em a
nossa, na qual está pela presença, pela essência e pela potência.

## Art. 12 — Se pela razão natural podemos conhecer a Deus nesta vida.
(Infra., q. 32, a. 1; q. 86, a. 2, ad 1; I Sent., dist. III, q. 1, a. 1; III, dist. XXVII, q. 3, a. 1; IV Cont. Gent., cap. I;
in Boet. De Trinit., q. 1, a. 2; I Rom., cap. I, lect. VI).
O duodécimo discute-se assim. — Parece que pela razão natural não podemos conhecer a Deus nesta
vida.

1. — Pois, diz Boécio, que a razão não apreende uma forma simples. Ora, Deus é a forma simples por
excelência, como já se demonstrou. Logo, a razão natural não pode chegar ao conhecimento dele.

2. Demais. — A alma nada intelige pela razão natural sem fantasma, como diz Aristóteles. Ora, de Deus,
que é incorpóreo, não podemos ter em nós um fantasma. Logo, não podemos dele ter conhecimento
natural.

3. Demais. — O conhecimento da razão natural é comum aos bons e aos maus, como lhes é comum a
natureza. Ora, o conhecimento de Deus é próprio só dos bons; pois, diz Agostinho, que a fraca
penetração do intelecto humano não pode chegar a uma luz tão excelente sem ser purificada pela
santidade da fé. Logo, Deus não pode ser conhecido pela razão natural.
Mas, em contrário, o Apóstolo (Rm 1, 19): O que se pode conhecer de Deus lhes é manifesto a eles, i. é.,
Deus é conhecível pela razão natural.

SOLUÇÃO. — O nosso conhecimento natural tem o seu princípio nos sentidos. Por onde, podemos
entender até onde pudermos chegar mediante os sensíveis. Ora, mediante eles, o nosso intelecto não
pode chegar a ver a divina essência. Pois, as criaturas sensíveis, sendo efeitos de Deus, não adequadas à
virtude da causa, partindo do conhecimento sensível, não podem chegar a conhecer a virtude total de
Deus; e por conseqüência, não lhe podem ver a essência. Mas, como os efeitos são dependentes da
causa, podemos por eles chegar ao conhecimento da existência de Deus e dos atributos que lhe convém
necessariamente, como causa primeira de todos os seres, que sobrepassa todos os seus efeitos. E assim
conhecemos a sua relação com as criaturas de todas as quais é causa; e como estas diferem dele por
que não é nenhuma das que criou; e enfim, sabemos que o que dele removemos não é por deficiência
sua, mas, por sobre-excelência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A razão não pode atingir uma forma simples de modo a
lhe conhecer a quididade; pode, contudo, conhecer-lhe a existência.

RESPOSTA À SEGUNDA. — Deus é conhecido pelos fantasmas que, dos seus efeitos, apreende o
conhecimento natural.

RESPOSTA À TERCEIRA. — O conhecimento da essência de Deus, sendo efeito da graça, só os bons o
podem ter; mas, o conhecimento de Deus pela razão natural podem-no ter tanto os bons como os
maus. Por isso, diz Agostinho: Não aprovo o que disse nesta oração: Deus, que só aos puros permitiste
saberem a verdade — pois poderiam responder que muitos, embora não puros conhecem muitas
verdades, i. é, pela razão natural.

## Art. 13 — Se pela graça alcançamos um conhecimento mais elevado de Deus, que pela razão natural.
O décimo terceiro discute-se assim. — Parece que pela graça não alcançamos um conhecimento mais
elevado de Deus, que pela razão natural.

1. — Pois, diz Dionísio, que quem se unir a Deus nesta vida une-se-lhe como ao que é absolutamente
desconhecido. E diz o mesmo de Moisés, que contudo foi elevado a uma certa excelência, no
conhecimento da graça. Ora, também pela razão natural podemo-nos unir a Deus, ignorando o que ele
é. Logo, pela graça, não conhecemos a Deus mais plenamente, que pela razão natural.

2. Demais. — Pela razão natural não podemos chegar ao conhecimento das coisas divinas sem nos
servirmos dos fantasmas. Logo, o mesmo se dará com o conhecimento pela graça. Pois, diz Dionísio,
que o divino raio não pode luzir para nós senão coado através da variedade dos sagrados véus. Logo,
pela graça não conhecemos mais plenamente a Deus, do que pela razão natural.

3. Demais. — O nosso intelecto adere, pela graça, à fé em Deus. Ora, parece que a fé não é um
conhecimento, pois como diz Gregório, as coisas que se não vêem são o objeto da fé e não, do
conhecimento. Logo, a graça não nos acrescenta nenhum conhecimento mais excelente de Deus.
Mas, em contrário, o Apóstolo (1 Cor 2, 10): Deus nos revelou pelo seu espírito, a saber, aquilo que
nenhum dos príncipes deste século conhece; i. é, nenhum filósofo, como expõe a Glosa.

SOLUÇÃO. — Pela graça, alcançamos de Deus um conhecimento mais perfeito que pela razão natural, o
que assim se demonstra. O conhecimento que temos, pela razão natural, exige duas condições: os
fantasmas recebidos dos sentidos e o lume natural inteligível, em virtude do qual abstraímos dos
fantasmas as concepções inteligíveis. Ora, quanto a estas duas condições, o conhecimento humano é
ajudado pela revelação da graça. Pois, o lume natural do intelecto é reforçado pela infusão da luz da
graça. E, por vezes, os fantasmas se formam, na imaginação do homem, por influência divina e
exprimem melhor as coisas divinas, que os recebidos naturalmente dos sentidos, como se dá com as
visões proféticas. E, também, às vezes, certas coisas sensíveis ou mesmo, palavras, são formadas
divinamente, para exprimirem algo de divino. Assim, no batismo de Cristo, o Espírito Santo foi visto em
forma de pomba e ouviu-se a voz do Pai, dizendo (Mt 3, 17): Este é meu Filho amado.

RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora pela revelação da graça não conheçamos, nesta vida, o
que Deus é, e, assim, a ele nos unamos como a um desconhecido, contudo, conhecemo-lo mais
plenamente enquanto se nos revelam efeitos seus, em maior número e excelência, e enquanto, por
divina revelação, lhe atribuímos certas perfeições que a razão natural não pode alcançar, como p. ex,
que é uno e trino.

RESPOSTA À SEGUNDA. — Por meio dos fantasmas recebidos dos sentidos pela razão natural, ou
formados na imaginação por influência divina, alcançamos um conhecimento intelectual tanto mais
excelente quanto mais forte for o nosso lume inteligível. E, assim, pela revelação, o conhecimento
derivado dos fantasmas é mais perfeito, ajudado como é pela infusão do divino lume.

RESPOSTA À TERCEIRA. — A fé é um certo conhecimento, enquanto que, por ela, o intelecto é
determinado a algo de cognoscível. Mas, esta determinação a um objeto procede, não da visão do
crente, mas, da visão daquele no qual se crê. E, assim, por essa falta de evidência, o conhecimento da fé
é inferior ao conhecimento científico; pois, a ciência determina o intelecto a um objeto, pela visão e pela
inteligência dos primeiros princípios.