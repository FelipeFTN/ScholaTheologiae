# Questão 117: Do que respeita a ação do homem.
Em seguida deve-se tratar do que respeita à ação do homem, composto de criatura espiritual e
corpórea. E primeiro deve-se tratar da ação do homem. Segundo, da propagação da espécie humana.
Sobre a primeira questão quatro artigos se discutem:

## Art. 1 — Se um homem pode ensinar a outro.
(II Sent., dist. IX, a. 2, ad 4; dist. XXVIII, a. 5. ad. 3; II Cont. Gent., cap. LXXV; De Verit., q. II a. I; Opusc.

XVI, De Unit. Intell., cap. V).
O primeiro discute-se assim. — Parece que um homem não pode ensinar a outro.

1. — Pois, diz o Senhor, no Evangelho: Não queirais ser chamados mestres; ao que a Glossa de Jerônimo:
Para que não atribuais aos homens a honra divina. Portanto, ser mestre é propriamente honra divina.
Ora, ensinar é próprio do mestre. Logo, o
homem não pode ensinar, mas só de Deus isso é próprio.

2. Demais. — Um homem ensina causando, pela sua ciência, a ciência de outro. Ora, é por uma
qualidade ativa que fazemos o que nos é semelhante. Donde se segue que a ciência é uma qualidade
ativa, como o calor.

3. Demais. — A ciência requer o lume inteligível e a espécie da coisa inteligida. Ora, nada disto um
homem pode causar em outro. Logo, não pode, ensinando, causar a ciência de outro.

4. Demais. — O mestre age sobre o discípulo somente propondo-lhe certos sinais vocais ou gestos, para
exprimir alguma causa. Ora, por sinais ninguém pode ensinar, causando em outro a ciência; pois, esses
sinais são de coisas conhecidas ou desconhecidas. Se de conhecidas, aquele a quem são feitos já possui
a ciência e, logo, não a recebe do mestre. Se de desconhecidas, tais sinais nada ensinam; assim, se al-
guém propusesse, a um latino palavras gregas, cuja significação este ignora, não poderia ensiná-lo. Logo,
ninguém pode, ensinando, causar a ciência em outrem.
Mas, em contrário, diz o Apóstolo: Eu fui constituído pregador e Apóstolo, doutor das gentes na fé e na
verdade.

SOLUÇÃO. — Sobre este assunto são várias as opiniões. — Assim, Averróis ensina que há um só
intelecto possível para todos os homens, como já se disse; donde resulta que todos têm a mesma
espécie inteligível. E então, diz que um homem, ensinando, não causa em outro ciência diversa da que
tem; mas comunica-lhe a mesma que tem, movendo-o a ordenar os fantasmas da sua alma, para que se
disponham convenientemente à apreensão inteligível. E tal opinião é verdadeira, quanto a ser a ciência
do mestre igual à do discípulo, considerando-se a identidade relativamente à unidade da coisa sabida;
pois, a mesma verdade conhecem discípulo e mestre. Mas, como já se viu, é falsa essa opinião quando
ensina que todos os homens têm o mesmo intelecto possível, e as mesmas espécies inteligíveis só
diferentes pela diversidade dos fantasmas.
Outra é a opinião dos Platônicos, para os quais a ciência é ínsita, desde o princípio, nas nossas almas,
por participação das formas separadas, como já se disse; mas a alma, pela união com o corpo, fica
impedida de considerar livremente aquilo de que tem ciência. E segundo esta opinião, o discípulo não
recebe de novo, a ciência, do mestre; mas este o exercita na consideração daquilo de que já tem ciência;
e então aprender não é mais do que lembrar-se. Do mesmo modo, ensinam que os agentes naturais só
dispõem para o recebimento das formas, que a matéria corpórea adquire por participação das espécies
separadas. Mas, contra esta opinião já se estabeleceu antes, de conformidade também com Aristóteles,
que o intelecto possível da alma humana é potência pura, relativamente aos inteligíveis. E, portanto,
deve-se, diferentemente e conforme Aristóteles, dizer que o mestre causa a ciência no discípulo, con-
duzindo-o da potência ao ato. O que se evidencia considerando que, dos efeitos provenientes de um
princípio exterior, uns procedem somente desse princípio; assim, a forma da casa é causada na matéria
só pela arte. Outras porém procedem, ora de princípio exterior, ora, de interior; assim, a saúde é
causada no enfermo, ora por um princípio exterior, a saber, a arte médica; ora, por um princípio
interior, como quando alguém sara por virtude da natureza. Ora, em tais efeitos, a duas coisas se devem
atender. Primeiro, que a arte, na sua operação, imita a natureza; pois, assim como esta cura um
enfermo, alterando, digerindo e expulsando a matéria que causa a doença, assim também a arte.
Segundo, o princípio exterior, que é a arte, não opera como agente principal, mas como coadjutor deste,
que é o princípio interno, reforçando-o e ministrando-lhe os instrumentos e auxílios, de que se sirva a
natureza para produzir o efeito; assim, o médico reforça a natureza e lhe fornece os alimentos e
remédios de que ela necessita para o fim a que tende. Ora, o homem adquire a ciência pelo princípio in-
terno, como bem se vê naquele que a adquire por invenção própria; e pelo externo, como claramente o
mostra quem aprende. Pois, é ínsito em cada homem um certo princípio de ciência, a saber, a luz do
intelecto agente, pelo qual conhece, logo, inicial e naturalmente,certos princípios universais de todas as
ciências. Por onde, quando alguém aplica esses princípios universais a casos particulares, dos quais o
sentido lhe ministram a memória e a experiência, adquire, por invenção própria, a ciência do que
ignorava, partindo do conhecido para o desconhecido. E assim, qualquer docente conduz o discípulo, do
que este conhece, para o que ignora, conforme Aristóteles, que diz, que toda doutrina e toda disciplina
parte do conhecimento preexistente. Ora, o mestre conduz o discípulo, do conhecido ao desconhecido,
de dois modos. Primeiro, ministrando-lhe certos auxílios ou instrumentos de que use o intelecto, para
adquirir a ciência; assim, quando lhe propõe certas proposições menos universais, das quais entretanto
o discípulo, pelo que sabe, pode julgar. Ou quando lhe propõe certos exemplos sensíveis —
semelhantes, opostos, ou outros — pelos quais o intelecto do discente é levado ao conhecimento da
verdade desconhecida. De outro modo, reforçando o intelecto do discente, não por qualquer virtude
ativa, como de natureza superior conforme já se disse quando se tratou da iluminação angélica —
pois, todos os intelectos humanos são do mesmo grau, na ordem da natureza; mas, propondo a ordem
dos princípios, relativamente às conclusões, ao discípulo, que talvez não tenha tal virtude reflexiva, que
possa, daqueles, deduzir estas. E, por isso, diz Aristóteles, que a demonstração é um silogismo, que faz
saber; e assim, quem demonstra faz o ouvinte saber.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como já se disse, o mestre, ensinando, usa somente do
ministério externo, como o médico, curando; mas assim como a natureza interior é a causa principal do
sarar, assim o lume interior do intelecto é a causa principal da ciência. E ambas essas coisas vêm de
Deus. Por onde, assim como a Escritura diz de Deus — que sara todas as tuas enfermidades — assim,
também diz — que ensina ao homem a ciência, enquanto o lume do seu rosto está gravado sobre nós,
pelo qual todas as coisas nos são ensinadas.

RESPOSTA À SEGUNDA. — O mestre não causa a ciência no discípulo, ao modo de agente natural, como
objeta Averróis; por onde, não é necessário que a ciência seja uma qualidade ativa. Mas é o princípio
pelo qual quem ensina se dirige, assim como a arte e o princípio pelo qual se dirige quem opera.

RESPOSTA À TERCEIRA. — O mestre não causa o lume inteligível no discípulo, nem diretamente as
espécies inteligíveis; mas, com a sua doutrina, move-o a que forme, pelo intelecto, os conceitos
inteligíveis, cujos sinais o mestre lhe propõe exteriormente.

RESPOSTA À QUARTA. — Os sinais que o mestre apresenta ao discípulo, são de coisas conhecidas,
universal e como confusamente, mas desconhecidas em particular e como distintamente. Por onde, não
se pode dizer que quem adquire a ciência por si mesmo a si mesmo se ensine, ou seja mestre de si,
porque não tem preexistente a ciência completa, como se exige para mestre.

## Art. 2 — Se os homens podem ensinar os anjos.
(II Sent., dist. XI, part. II, a. 4; Opusc. I, Contra ERR. Graec., cap. XXVI; Ad Ephes., cap. III, lect. III).
O segundo discute-se assim. — Parece que os homens podem ensinar os anjos.

1. — Pois, diz o Apóstolo: Para que a multiforme sabedoria de Deus seja manifestada por meio da Igreja
aos principados e potestades nos céus. Ora, a Igreja é a reunião dos fiéis. Logo, os anjos aprendem
alguma coisa, dos homens.

2. Demais. — Os anjos superiores, imediatamente iluminados por Deus, sobre as coisas divinas, podem
instruir os inferiores, como já se disse. Ora, certos homens, e sobretudo os Apóstolos, são
imediatamente instruídos pelo Verbo de Deus, sobre as coisas divinas, conforme a Escritura:
Ultimamente, nestes dias, falou-nos por meio de seu Filho. Logo, certos homens puderam ensinar certos
anjos.

3. Demais. — Os anjos inferiores são instruídos pelos superiores. Ora, certos homens são superiores a
certos anjos, pois, como diz Gregório, num lugar, aqueles serão elevados às ordens supremas destes.
Logo, certos anjos inferiores podem ser instruídos, sobre as coisas divinas, por certos homens.
Mas, em contrário, diz Dionísio, que todas as iluminações divinas são trazidas aos homens, pelos anjos.
Logo, estes não são instruídos por aqueles, sobre as causas divinas.

SOLUÇÃO. — Como já se estabeleceu, os anjos inferiores podem falar com os superiores, manifestando-
lhes os seus pensamentos; mas, sobre as coisas divinas, os superiores não são nunca iluminados pelos
inferiores. Ora, é manifesto, que os mais elevados dos homens estão sujeitos, mesmo aos ínfimos dos
anjos, do mesmo modo porque os anjos inferiores estão sujeitos aos superiores. O que é claro pelo dito
do Senhor, no Evangelho: Entre os nascidos de mulheres não se levantou outro maior que João Baptista;
mas o que é menor no reino dos céus, é maior do que ele. Assim, pois, os anjos não são nunca
iluminados pelos homens, sobre as causas divinas. Contudo, podem manifestar a estes, falando, as
cogitações do coração, porque os segredos dos corações só Deus conhece.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Agostinho expõe do modo seguinte o passo aduzido, do
Apóstolo. Este já havia dito antes: A mim, o mínimo dentre todos os santos, foi-me dada esta graça de
iluminar a todos, sobre a economia do sacramento oculto, desde a origem dos séculos, em Deus; e digo
de tal modo oculto, para que os Principados e as Potestades, nos céus, conheçam, pela Igreja, a
multiforme sabedoria de Deus. Que é como se dissesse: Este sacramento era oculto aos homens; de
modo tal porém que fosse conhecido da Igreja celeste, representada pelos Principados e Potestades,
desde os séculos, e não antes; porque primitivamente, a Igreja estava onde, depois da ressurreição,
também será congregada a Igreja dos homens. — Mas, também se pode dizer, de outro modo, como
acrescenta o mesmo Agostinho, que o que está oculto os anjos não o conhecem tanto em Deus, mas,
antes, é-lhes manifesto quando se realiza e propala, neste mundo. E assim, quando foram completados,
pelos Apóstolos, os mistérios de Cristo e da Igreja, algo de tais mistérios, que antes lhes estava oculto,
foi manifestado. E deste modo, pode-se entender o dito de Jerônimo, que os anjos conheceram certos
mistérios pela pregação dos Apóstolos; porque, com essa predicação apostólica, tais mistérios se
completaram, relativamente aos objetos mesmos deles; assim, com a pregação de Paulo os gentios se
converteram, assunto de que trata o Apóstolo no passo aduzido.

RESPOSTA À SEGUNDA. — Os Apóstolos foram instruídos imediatamente pelo Verbo de Deus, porque
lhes falou, não a divindade do Verbo, mas a humanidade. Por onde, a objeção não colhe.

RESPOSTA À TERCEIRA. — Certos homens, mesmo em vida, são maiores que alguns anjos, não em ato,
mas por virtude, i. é, enquanto têm caridade tão intensa, que podem merecer maior grau de beatitude,
que o de certos anjos. Assim, como se disséssemos que a semente de lima grande árvore tem maior
virtude que a de lima pequena árvore, embora seja tal semente muito menor, atualmente.

## Art. 3 — Se o homem, por virtude da alma, pode imutar a matéria corpórea.
(Ad Galat., cap. III. Lect. I).
O terceiro discute-se assim. — Parece que o homem, por virtude da alma, pode imutar a substância
corpórea.

1. — Pois, diz Gregório, que os santos fazem milagres, às vezes pela oração, às vezes pelo poder; assim
Pedro, orando, ressuscitou Tabita morta e, increpando-os, fez morrerem Ananias e Safira, que haviam
mentido. Ora, a obra miraculosa opera certa imutação na matéria corpórea. Logo, os homens, por
virtude da alma, podem imutar a matéria corpórea.

2. Demais. — Aquilo da Escritura — quem vos fascinou para não obedecerdes à verdade? diz a Glossa:
alguns têm olhos ardentes, que só pelos fixar infectam os outros, e sobretudo as crianças. Ora, tal não
se daria, se a virtude da alma não pudesse imutar a matéria corpórea. Logo, o homem, por virtude da
alma, pode imutar tal matéria.

3. Demais. — O corpo humano é mais nobre que os corpos inferiores. Ora, por apreensão da alma
humana, este corpo é imutado, quanto ao calor e o frio, como o demonstram nos irados e pavorosos; e
às vezes essa imutação chega até a doença e à morte. Logo, com maior razão, a alma pode, pela sua
virtude, imutar a matéria corpórea.
Mas, em contrário, diz Agostinho: a matéria corpórea obedece só à vontade de Deus.

SOLUÇÃO. — Como já se disse, antes, a matéria corpórea não é imutada, para receber a forma, senão
por algum agente composto de matéria e forma, ou por Deus mesmo, em quem, como na causa
primordial, ambas existem virtualmente. E, por isso, como já se disse, os anjos não podem, por virtude
natural, imutar a matéria corpórea, senão aplicando os agentes corpóreos à produção de certos efeitos.
Logo, com maior razão, a alma, por natural virtude, não pode imutar a matéria corpórea, senão me-
diante certos corpos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Diz-se que os santos fazem milagres por poder da graça
e não da natureza. O que é claro pelo que Gregório diz, no mesmo lugar: Os que são filhos de Deus, pelo
poder, como diz João, que há de admirar possam fazer milagres, por esse poder?

RESPOSTA À SEGUNDA. — Avicena ensina que a causa da fascinação está em ser natural à matéria
corpórea obedecer, antes, à substância espiritual, do que aos agentes contrários naturais. E por isso,
quanto mais forte for à imaginação da alma, tanto mais poderá imutar a matéria corpórea; e tal é, diz, a
causa da fascinação dos olhos. — Mas, como já se demonstrou, a matéria corpórea não obedece à
vontade da substância espiritual, mas só à do Criador. Por onde, melhor é dizer-se que a forte
imaginação da alma imuta o espírito do corpo, que lhe está unido. E essa imutação dos espíritos se dá,
principalmente, nos olhos, onde chegam os espíritos mais subtis. Os olhos, porém, infectam o ar
contínuo, até um determinado espaço; e por esse modo, os espelhos, sendo novos e puros, contraem
certa impureza da imagem da mulher menstruada, como diz Aristóteles. Assim, pois, da alma,
veementemente agitada pela malícia, como acontece sobretudo com as velhas, resulta, pelo modo
supradito, o olhar venenoso e nocivo, sobretudo para as crianças, que têm corpo tenro e facilmente
impressionável. Mas, também é possível que, por permissão de Deus, ou ainda, por qualquer pato
oculto, coopere para tal a malícia dos demônios, com os quais têm aliança as velhas adivinhas.

RESPOSTA À TERCEIRA. — A alma está unida ao corpo humano, como forma; e o apetite sensitivo, que
de certo modo obedece à razão, como antes se disse, é o ato de um órgão corpóreo. Por onde, é
necessário que, para a alma humana apreender, seja movido o apetite sensitivo, por alguma operação
corpórea. A apreensão da alma humana não basta porém para imutar os corpos exteriores, senão
mediante a imutação do próprio corpo, como já foi dito.

## Art. 4 — Se a alma humana separada pode mover os corpos, ao menos localmente.
(De Malo, q. 16, a. 10, ad 2).
O quarto discute-se assim. — Parece que a alma humana separada pode mover os corpos, ao menos
localmente.

1. — Pois, o corpo obedece naturalmente à substância espiritual, quanto ao movimento local, como já
se disse. Ora, a alma separada é uma substância espiritual. Logo, pode pelo seu império mover os corpos
exteriores.

2. Demais. — No Itinerário de Clemente se diz conforme a narração de Nicetas a Pedro, que Simão
Mago, com artes mágicas, conservava a alma de um menino, que matara, pela qual fazia operações
mágicas. Mas isto não poderia se dar sem alguma transmutação dos corpos, pelo menos local. Logo, a
alma separada tem a virtude de mover localmente os corpos.
Mas, em contrário, diz o Filósofo, que a alma não pode mover nenhum outro corpo, a não ser o próprio.

SOLUÇÃO. — A alma separada, por virtude natural sua, não pode mover nenhum corpo. Pois, é
manifesto que, estando unida ao corpo, não move senão o corpo vivo; por onde, qualquer membro
morto do corpo não obedece à alma, quanto ao movimento local. Ora, sendo claro que nenhum corpo é
vivificado pela alma separada, resulta que nenhum obedece a esta, quanto à virtude da sua natureza,
relativamente ao movimento local, para o que algo pode lhe ser concedido, pela virtude divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Há certas substâncias espirituais, cujas virtudes não são
determinadas a nenhum corpo, como os anjos, naturalmente separados de corpos; e por isso muitos
corpos podem lhes obedecer ao movimento. Porém a virtude motiva de uma substância separada, que
for naturalmente determinada a mover algum corpo, poderá mover um corpo menor, mas não um
maior. Assim, segundo o Filósofo, o motor do céu inferior não pode mover o céu superior. Por onde, a
alma, que por natureza está determinada a mover o corpo, do qual é forma, não pode mover nenhum
outro, por virtude natural.

RESPOSTA À SEGUNDA. — Como diz Agostinho e Crisóstomo, os demônios simulam freqüentemente
que são almas de mortos, para confirmarem o erro dos Gentios, que tal acreditavam. Por onde, é crível
que Simão Mago fosse iludido por algum demônio, que simulava ser a alma da criança que aquele
matara.