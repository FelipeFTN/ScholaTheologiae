# Questão 23: Da Predestinação.
Depois de termos tratado da divina providência, devemos tratar da predestinação e do livro da vida.
Sobre a predestinação, discutem-se oito artigos:

## Art. 1 — Se os homens são predestinados por Deus.
(I Sent., dist. XL, q. 1, a. 2; III Contr. Gent., cap. CLXIII; De Verit.; q. 6, a. 1; Ad Rom., cap. I, lect. III)
O primeiro discute-se assim. — Parece que os homens não são predestinados por Deus.

1. — Pois, Damasceno diz: Devemos saber que Deus tem presciência de tudo, mas nem tudo
predetermina; assim tem presciência do que existe em nós, mas não o predetermina. Ora, os méritos e
os deméritos estão em nós, por sermos senhores dos nossos atos, pelo livre arbítrio. Logo, o que
pertence ao mérito ou ao demérito não é predestinado por Deus; e, assim, desaparece a predestinação
do homem.

2. Demais. — Todas as criaturas se ordenam aos seus fins pela divina providência, como se disse. Ora,
não dizemos que as outras criaturas são predestinadas por Deus. Logo, nem os homens.

3. Demais. — Os anjos são capazes de felicidade, como os homens. Ora, aos anjos não convém serem
predestinados, segundo parece, por não ter nunca havido miséria neles, e por implicar a predestinação
opropósito da comiseração, como diz Agostinho. Logo, os homens não são predestinados.

4. Demais. — Os benefícios conferidos por Deus aos homens são revelados aos varões santos pelo
Espírito Santo, conforme aquilo do Apóstolo (1 Cor 2, 12): Ora, nós não recebemos o espírito deste
mundo, mas sim, o espírito que vem de Deus, para sabermos as coisas que por Deus nos foram dadas.
Logo, sendo a predestinação um benefício de Deus, se Deus predestinasse os homens, os predestinados
o saberiam, o que é evidentemente falso.
Mas, em contrário, a Escritura (Rm 8, 30): E aos que predestinou, a estes também chamou.

SOLUÇÃO. — Convém a Deus predestinar os homens. Pois, tudo está sujeito à divina providência, como
estabelecemos. Ora, à providência pertence ordenar as coisas para um fim, conforme dissemos. Mas,
duplo é o fim ao qual se ordenam os seres criados. Um excede à proporção e à faculdade da natureza
criada. Esse fim é a vida eterna, consistente na visão divina, que excede à natureza de toda criatura,
como vimos. Outro é o fim proporcionado à natureza, que a criatura pode atingir em virtude dessa
mesma natureza. Ora, para um ser alcançar um fim, a que não pode chegar em virtude da sua natureza,
é preciso ser levado por outro, assim como a seta é impelida ao alvo pelo seteiro. Por onde,
propriamente falando, a criatura racional, capaz da vida eterna, atinge-a, como que levada por Deus. E a
razão dessa levada preexiste em Deus, como nele existe a razão da ordem de todas as coisas para o fim,
a que chamamos providência. Pois, a razão de uma coisa ser feita, existente na mente do seu autor, é
uma certa preexistência, neste, daquela. Por onde, à razão da referida levada da criatura racional para o
fim da vida eterna chama-se predestinação; pois, destinar é levar. Portanto, é claro que a predestinação,
quanto ao seu objeto faz parte da providência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Damasceno chama predestinação à imposição da
necessidade, como se dá com os seres naturais, que são predeterminados a um fim; o que é claro, pelo
que acrescenta: Pois nem quer a malícia, nem compele à virtude. Por onde, não exclui a predestinação.

RESPOSTA À SEGUNDA. — As criaturas irracionais não são capazes de alcançar aquele fim excedente à
faculdade da natureza humana. Por isso, não dizemos propriamente, que são predestinadas; embora,
por abuso de linguagem, falemos às vezes de predestinação, relativamente a qualquer outro fim.

RESPOSTA À TERCEIRA. — Ser predestinado convém aos anjos, como aos homens, embora aqueles
nunca fossem pecadores. Pois, o movimento não se especifica pela sua origem, mas, pelo seu termo.
Assim, para o embranquecimento, em si mesmo, não importa ter sido negro, pálido ou ruivo aquilo que
embranquece. Semelhantemente, em nada importa para a predestinação, em si mesma, que um ser
seja predestinado de um estado miserável ou não, à vida eterna. Todavia, podemos dizer, que conferir a
alguém um bem superior ao que lhe é devido, é próprio, como vimos, à misericórdia.

RESPOSTA À QUARTA. — Embora, por especial privilégio, a certos lhes seja revelada a predestinação,
contudo não convém que o seja a todos; porque então os que não são predestinados desesperariam, e a
certeza dos predestinados geraria a negligência.

## Art. 2 — Se a predestinação atribui alguma realidade ao predestinado.
(I Sent., dist. XL, q. 1, a. 1).
O segundo discute-se assim. — Parece que a predestinação algo atribui ao predestinado.

1. — Pois, toda ação produz uma paixão. Logo, se a predestinação é, em Deus, ação, deve ser nos
predestinados, paixão.

2. Demais. — Orígenes comentando aquilo de S. Paulo (Rm 1, 4) - O que é predestinado, etc., diz: A
predestinação concerne ao que não existe, mas a destinação, ao que existe. E Agostinho: A
predestinação é a destinação de um ser que existe. Logo, a predestinação só é própria a algum ser que
existe; e, portanto, atribui uma realidade ao predestinado.

3. Demais. — A preparação é uma realidade no preparado. Ora, a predestinação é a preparação dos
benefícios de Deus, como diz Agostinho. Logo, a predestinação é uma realidade nos predestinados.

4. Demais. — O temporal não entra na definição do eterno. Ora, a graça, que é algo de temporal, entra
na definição da predestinação; pois dizemos que a predestinação é a preparação da graça, nesta vida, e
a da glória na outra. Logo, a predestinação nada tem de eterno. Portanto e necessariamente, não existe
em Deus, em quem tudo é eterno, mas nos predestinados.
Mas, em contrário, diz Agostinho, que a predestinação é a presciência dos benefícios de Deus. Ora, a
presciência não está no seu objeto, mas no presciente. Logo, também a predestinação não está nos
predestinados, mas no predestinador.

SOLUÇÃO. — A predestinação não é uma realidade nos predestinados, mas somente no predestinador.
Pois, como dissemos, faz parte da providência. Ora, a providência não está nas coisas que constituem o
seu objeto, mas é uma razão existente no intelecto do provisor, segundo ficou estabelecido. Mas, a
execução da providência, a que se chama governo, passivamente está nos governados e ativamente, no
governador. Por onde, é manifesto, que a predestinação é uma certa razão da ordem de determinados
seres para a salvação eterna, existente na mente divina. Porém, a execução dessa ordem incumbe aos
predestinados, passivamente, e a Deus, ativamente. Pois, a execução da predestinação se
chama vocação e glorificação, conforme a Escritura (Rm 8, 30): E aos que predestinou, a estes também
chamou; e aos que chamou, a estes também glorificou.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As ações transeuntes à matéria exterior produzem uma
paixão; assim, a calefação e a ação de cortar. Não porém as ações imanentes no agente, como inteligir e
querer, segundo dissemos. E tal ação é a predestinação. Por onde, nada atribui aos predestinados; mas,
a execução dela, transeunte às coisas exteriores, produz neles algum efeito.

RESPOSTA À SEGUNDA. — Às vezes, a destinação é tomada como a missão real de alguém para um
termo e neste sentido só tem destinação o que existe. Outras vezes, tem o sentido de missão, concebida
mentalmente; e então se diz, que destinamos aquilo que com firmeza mentalmente propomos. E nesta
acepção, diz a Escritura (2 Mc 6, 20): Eleazar resolveu (destinou) não admitir coisas ilícitas por amor da
vida. E assim a destinação pode se referir ao que não existe. Contudo, a predestinação, em virtude da
precedência, que importa, pode convir ao não existente como quer que deste se compreenda a
destinação.

RESPOSTA À TERCEIRA. — Há dupla preparação. Uma, a do paciente para sofrer, e essa, está no
preparado. Outra, a do agente para agir, e essa está no agente. E tal é a predestinação, pela qual
dizemos que um agente dotado de inteligência se prepara a agir, preconcebendo a razão da obra a
realizar. E assim, Deus, concebendo a razão da ordem de alguns para a salvação, desde a eternidade
preparou, predestinando.

RESPOSTA À QUARTA. — Não é como existente, por essência, que a graça entra na definição da
predestinação. Mas enquanto esta diz respeito à graça, como a causa ao efeito e o ato ao objeto. Donde
não se conclui que a predestinação seja algo de temporal.

## Art. 3 — Se Deus reprova alguém.
(I Sent., dist. XL, q. 4, a. 1; III Cont. Gent., cap. CLXIII; ad Rom., cap. IX, lect. II).
O terceiro discute-se assim. — Parece que Deus não reprova ninguém.

1. — Pois, ninguém reprova a quem ama, segundo aquilo da Escritura (Sb 11, 25): Porque tu amas todas
as coisas que existem e não aborreces nada de quanto fizeste. Logo, Deus não reprova ninguém.

2. Demais. — Se Deus reprova alguém, a reprovação necessariamente está para os reprovados, como a
predestinação, para os predestinados. Ora, a predestinação é a causa da salvação dos predestinados.
Logo, a reprovação é a da perdição dos réprobos. O que é falso, segundo a Escritura (Os 13, 9): A tua
perdição, ó Israel, toda vem de ti; só em mim está o teu auxílio. Logo, Deus não reprova ninguém.

3. Demais. — A ninguém se lhe deve imputar o que não pode evitar. Ora, quem Deus reprovasse
pereceria inevitavelmente, segundo a Escritura (Eccle 7, 14): Considera as obras de Deus; porque
ninguém pode corrigir a quem ele desprezou. Logo, não se lhes pode imputar aos homens o perecerem,
o que é falso. Logo, Deus não reprova ninguém.
Mas, em contrário, a Escritura (Ml 1, 2-3): Eu amei a Jacó e aborreci a Esaú.

SOLUÇÃO. — Deus reprova certos homens. Porque, como dissemos, a predestinação faz parte da
providência. Ora, esta pode permitir alguns defeitos nas coisas que lhe estão sujeitas, segundo ficou
estabelecido. Por onde, como pela divina providência é que os homens alcançam a vida eterna, pode
também ela permitir que certos não a alcancem. E a isto se chama reprovar. Se pois, a predestinação,
concernente aos que Deus ordenou à salvação eterna, faz parte da providência, também o faz a
reprovação, concernente aos que aberram do fim. Logo, reprovação não somente significa presciência,
mas algo lhe acrescenta racionalmente, como aprovidência, conforme dissemos. Assim, pois, como a
predestinação inclui a vontade de conferir a graça e a glória, assim a reprovação a de permitir a
incidência na culpa, e a de infligir a esta a pena do dano.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus ama a todos os homens, e mesmo a todas as
criaturas, por lhes querer algum bem; mas, nem por isso quer a todos qualquer bem. Assim, aos que não
quer o bem da vida eterna dizemos que os odeia ou reprova.

RESPOSTA À SEGUNDA. — O causar da reprovação não é o mesmo que o da predestinação. Pois, esta é
causa, tanto da glória esperada pelos predestinados na vida futura, como da graça recebida na vida
presente. Aquela porém não é causa da culpa, na vida presente, mas sim do abandono de Deus. É,
contudo, causa da pena eterna, que lhe é aplicada na vida futura. Ora, a culpa provém do livre arbítrio
do reprovado, que é abandonado da graça. E assim se verifica o dito do Profeta: A tua perdição, ó Israel,
vem de ti.

RESPOSTA À TERCEIRA. — A reprovação de Deus não priva de nada a capacidade do reprovado. E assim,
quando se diz que o reprovado não pode alcançar a graça, devemos entendê-lo não, por impossibilidade
absoluta, mas condicional. No sentido em que dissemos acima, que necessariamente se salva o
predestinado, por necessidade condicionada, que não tira a liberdade do arbítrio. Por onde, embora o
reprovado por Deus não possa alcançar a graça, contudo, só por seu livre arbítrio é que cai em
determinados pecados. O que merecidamente se lhe imputa por culpa.

## Art. 4 — Se os predestinados são eleitos por Deus.
(I Sent., dist. XLI, a. 2; De Verit., q. 6, a. 2; ad Ram., cap. IX, lect. II).
O quarto discute-se assim. — Parece que não são os predestinados eleitos por Deus.

1. — Pois, Dionísio diz que assim como o sol material projeta luz em todos os corpos, sem os eleger,
assim, Deus, a sua bondade. Ora, esta se comunica precipuamente aos participantes da graça e da
glória. Logo, Deus comunica, sem eleição, a graça e a glória, o que constitui a predestinação.

2. Demais. — Elegemos o que existe. Ora, mesmo os seres que não existem são predestinados abeterno.
Logo, certos são predestinados sem eleição.

3. Demais. — Eleição supõe discriminação. Ora, Deus quer que todos os homens se salvem, como está
na Escritura (1 Ti 2, 4). Logo, na predestinação, que preordena os homens a que se salvem, não há
eleição.
Mas, em contrário, a Escritura (Ef 1, 4): Assim como nos elegeu mesmo antes do estabelecimento do
mundo.

SOLUÇÃO. — O conceito de predestinação pressupõe a eleição, e esta, o amor. Porque, segundo
dissemos, a predestinação faz parte da providência. Ora, como a prudência, a providência é a razão
existente no intelecto e que determina que certos seres se ordenem ao seu fim, como vimos. Ora, sem
preexistir a vontade do fim, nada pode ser determinado a se ordenar para ele. Por onde, a
predestinação de certos, a que se salvem, pressupõe racionalmente, que Deus lhes quer a salvação, o
que inclui a eleição e o amor. O amor, por querer-lhes Deus o bem da salvação eterna; pois, amar é
querer um bem a alguém, como dissemos. A eleição, por querer-lhes tal bem a uns de preferência a
outros; pois, certos são reprovados, conforme vimos. Mas a eleição e o amor não se exercem do mesmo
modo em nós e em Deus. Porque a nossa vontade não causa o bem que ama; ao contrário, o bem
preexistente é que nos incita a amá-lo. Por isso, elegemos a quem amamos. Por onde, em nós, a eleição
precede o amor, mas o inverso se dá com Deus, cuja vontade, querendo bem a quem ama é causa de
que este, de preferência a outro, possua esse bem. E portanto é claro que o amor, racionalmente, é
anterior à eleição, e esta, à predestinação. Por onde, todos os predestinados são eleitos e amados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Considerada em geral a comunicação da bondade divina,
Deus a comunica sem eleição, porque nenhum ser há que, de algum modo, não participe dela, conforme
dissemos. Mas, considerada a comunicação de um determinado bem, Deus não o concede sem eleição;
pois, dá certos bens a uns, que não dá a outros. Por onde, é mister levar em conta a eleição, na
atribuição da graça e da glória.

RESPOSTA À SEGUNDA. — Necessariamente a eleição concerne ao que existe quando, como acontece
conosco, a vontade é a ela provocada pelo bem preexistente realmente. Ora, em Deus não é assim,
como vimos. E por isso, diz Agostinho: Deus, elegendo o que não existe, nem por isso erra.

RESPOSTA À TERCEIRA. — Como já vimos, Deus quer por vontade antecedente, que todos os homens se
salvem; o que não é querer de modo absoluto, mas relativo. Mas, não o quer por vontade conseqüente,
o que seria querer de modo absoluto.

## Art. 5 — Se a presciência dos méritos é causa da predestinação.
(I Sent., dist. XLI, a. 3; III Cont. Gent., cap. CLXIII; De Verit., q. 6, a. _ 2; in Ioan., cap. XV, lect. III ad Ram.,
cap. I, 1ect. III; cap. VIII, 1ect. VI; cap. IX, 1ect. III; ad Ephes., cap. 1, lect. I, IV).
O quinto discute-se assim. — Parece que a presciência dos méritos é a causa da predestinação.
1 - Pois, diz a Escritura (Rm 8, 29): porque os que ele conheceu na sua presciência também os pre-
destinou. E àquilo do Apóstolo (Rm 9, 15) — Eu terei misericórdia com quem me aprouver, etc., diz a
Glosa: Terei misericórdia com aquele que prevejo voltará a mim, de todo o coração. Logo, a presciência
dos méritos é a causa da predestinação.

2. Demais. — A predestinação divina, sendo o propósito de se comiserar, como diz Agostinho, inclui a
vontade divina, que não pode ser irracional. Ora, nenhum outro fundamento pode ter a predestinação
senão a presciência dos méritos. Logo, esta é a causa ou a razão da predestinação.

3. Demais. — Como diz a Escritura (Rm 9, 14), não há injustiça em Deus. Ora, é injusto que a iguais se
dêem coisas desiguais. Mas todos os homens são iguais por natureza e pelo pecado original; ao passo
que a desigualdade deles se funda no mérito e no demérito dos próprios atos. Logo, só pela presciência
dos diferentes méritos é que Deus prepara situações desiguais aos homens, predestinando e
reprovando.
Mas, em contrário, diz o Apóstolo (Tt 3, 5): Não por obras de justiça que tivéssemos feito nós outros,
mas, segundo a sua misericórdia, nos salvou. Ora, se nos salvou, nos predestinou à salvação. Logo, não é
a presciência dos méritos a causa ou a razão da predestinação.

SOLUÇÃO. — Incluindo a predestinação a vontade, como dissemos, devemos perquirir a noção da
predestinação, como perquirimos a da vontade divina. Ora, segundo ficou dito, não podemos descobrir
nenhuma causa do ato de querer da divina vontade; mas podemos descobrir-lhe a razão de querer,
relativamente às coisas queridas, enquanto Deus quer uma coisa por causa de outra. Ora, ninguém
houve nunca, tão insano de mente, a ponto de dizer que os méritos, quanto ao ato do Predestinador,
fossem a causa da divina predestinação. Mas o que se discute é saber se, relativamente ao efeito, a
predestinação tem alguma causa. O que é o mesmo que indagar se Deus, pelos méritos de alguém
preordenou dar-lhe o efeito da predestinação.
Ora, alguns disseram, que tal efeito se preordena a alguém por causa dos méritos preexistentes em
outra vida. Tal foi a opinião de Orígenes, ensinando que as almas humanas, criadas desde o início,
recebem, quando neste mundo unidas ao corpo, diversos estados correspondentes à diversidade das
suas obras. Mas, esta opinião é rejeitada pelo Apóstolo, quando diz (Rm 9, 11-13): Porque não tendo
elas ainda nascido, nem tendo ainda feito bem ou mal... não por respeito às suas obras, mas por causa
da vocação de Deus lhe foi dito a ela: O mais velho, pois, servirá ao mais moço.
Outros dizem, que os méritos preexistentes nesta vida são a causa e razão do efeito da predestinação.
Assim, os Pelagianos ensinavam, que do bem fazer está em nós o início, mas, em Deus, a consumação.
Donde resulta ser o efeito da predestinação dado a quem se preparou inicialmente, e recusado a
qualquer outro. Mas, contra esta opinião diz o Apóstolo (2 Cor 3, 5): Não que sejamos capazes de nós
mesmos, de ter algum pensamento como de nós mesmos. Ora, não podemos descobrir nenhum
princípio anterior ao pensamento. Por onde, não podemos dizer exista em nós algum início, razão do
efeito da predestinação.
E, por isso, opinaram outros, que os méritos conseqüentes ao efeito da predestinação é que são a razão
dela. E querem dizer com isso, que Deus, tendo preordenado a dar a graça, e sabendo quem haverá de
usar bem dela, a esse a dá. Como um rei que desse um cavalo ao soldado que soubesse haveria de usá-
lo bem. — Mas estes distinguem entre o efeito da graça e o do livre arbítrio, como se não pudesse da-
quela e deste provir um mesmo efeito. Ora, é claro, que o resultado da graça, sendo o próprio efeito da
predestinação, a este não lhe pode servir de causa, pois, nela se inclui. Logo, se alguma outra causa em
nós causar a predestinação será diferente do efeito desta. Mas não diferem os efeitos do livre arbítrio,
dos da predestinação, como os da causa segunda não diferem dos da causa primeira. Pois como já disse-
mos, a divina providência produz os seus efeitos, mediante as operações das causas segundas. Por onde,
o que fazemos por livre arbítrio provém da predestinação.
Devemos, pois, dizer que podemos considerar o efeito da predestinação à dupla luz. Primeiro, em
particular. E assim, nada impede seja um efeito dela a razão de outro; o posterior, do anterior, na ordem
da causa final; por seu lado, o anterior, do posterior, na ordem da causa meritória, que se reduz à
disposição da matéria. Assim se disséssemos, que Deus preordenou haver de dar a alguém, por causa
dos seus méritos, a glória; e que preordenou haver de dar a alguém a graça, para que merecesse a
glória. De outro modo, podemos considerar o efeito da predestinação em geral. E então é impossível
que todo o efeito da predestinação em geral tenha alguma causa dependente de nós. Pois tudo o que
há no homem, ordenando-o à salvação, está compreendido no efeito da predestinação, até mesmo a
preparação para a graça. E nem isto se opera senão por auxílio divino, conforme aquilo da
Escritura: Converte-nos, Senhor, a ti, e nós nos converteremos. Contudo, o efeito da predestinação
neste sentido tem como causa a divina bondade, à qual se ordena como ao fim, na sua totalidade; e da
qual procede, como do princípio primeiro motor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O uso previsto da graça não é a razão de ela ser
conferida, senão na ordem da causa final, como dissemos.

RESPOSTA À SEGUNDA. — Em geral, o efeito da predestinação tem na própria bondade divina a sua
razão. Em particular, porém, um efeito é a razão de outro, como dissemos.

RESPOSTA À TERCEIRA. — Da própria bondade divina podemos deduzir a razão de serem uns
predestinados e outros, reprovados. Pois, dizemos que Deus fez todas as coisas por causa da sua
bondade, i. é, para que elas a manifestem. Ora, é forçoso que as criaturas, não podendo atingir a
simplicidade divina, representem de maneira multiforme a una e simples divina bondade. Por isso, a
bem do acabamento do universo, requerem-se diversos graus de seres, dos quais uns nele ocupam lugar
preeminente e outros, ínfimo. E para que os seres conservem a variedade dos graus, Deus permite
aconteçam certos males, para que se não impeçam muitos bens, como dissemos.
Consideremos, pois, todo o gênero humano, como consideramos a universalidade das coisas. Assim
quanto aos homens, Deus quis mostrar a sua bondade, pela misericórdia, perdoando os predestinados e
pela justiça, punindo os réprobos. E esta é a razão de eleger Deus a uns e reprovar a outros; a qual
assinala o Apóstolo quando diz (Rm 9, 22-23): Querendo Deus mostrar a sua ira, (i. é, a vindicta da
justiça), e fazer manifesto o seu poder, sofreu (i. é, permitiu) com muita paciência, os vasos de ira
aparelhados para a morte, a fim de mostrar as riquezas da sua glória, sobre os vasos de misericórdia,
que preparou para a glória. E noutro lugar (2 Ti 2, 20):Ora, numa grande casa não há somente vasos de
ouro e de prata, mas também vasos de pau e de barro; e uns por certo são destinados a usos de honra,
outros, porém, a usos de desonra.
Mas, só a divina vontade é a razão da eleição de uns para a glória e da reprovação de outros. Por isso,
diz Agostinho: Se não queres errar, não te metas a indagar porque Deus chama a si uns e não outros.
Como também, apesar de a matéria prima ser toda e em si mesma uniforme, podemos, na ordem dos
seres naturais, assinalar uma razão por que uma parte dessa matéria Deus a criou desde o princípio sob
a forma de fogo, e outra, sob a de terra; e essa razão é a diversidade específica desses seres. Mas, só da
simples vontade de Deus depende o ter esta parte da matéria uma forma, e aquela, outra. Como da
simples vontade do artífice depende a posição de tal pedra nesta parte da parede e de tal outra,
naquela; embora a arte exija que numa e noutra parte estejam algumas pedras. Mas nem por isso Deus
é injusto, por preparar coisas desiguais a seres desiguais. Pecaria ele contra a noção de justiça, se o
efeito da predestinação fosse pago como um débito e não, dado de graça. Ora, o que alguém dá
gratuitamente pode dá-lo a seu talante e sem lesar a justiça a quem lhe aprouver; mais ou menos,
contanto que a ninguém prive do que é devido. E é o que diz o pai da família no Evangelho (Mt 20, 14-
15): Toma o que te pertence e vai-te... não me é lícito fazer o que quero?

## Art. 6 — Se a predestinação é certa.
(I Sent., dist. XL, q. 3; De Vert., q. 6, a. 3; Quodl., XI, q. 3; XII, q. 3).
O sexto discute-se assim. — Parece que não é certa a predestinação.

1. — Pois, sobre aquilo do Apocalipse (Ap 3, 11): Guarda o que tens, para que ninguém tome a tua
coroa, diz Agostinho: Outro não receberá se este não perder. Logo a coroa, efeito da predestinação,
pode ser ganha e perdida; e, portanto, a predestinação não é certa.

2. Demais. — Do possível não pode resultar o impossível. Ora, é possível um predestinado, p. ex., Pedro,
pecar, e em seguida ser morto. Dessa suposição resulta ficar frustrado o efeito da predestinação. Ora,
isto não é impossível. Logo, não é certa a predestinação.

3. Demais. — Deus pode tudo o que pôde. Ora, podia não predestinar quem predestinou. Logo, pode
atualmente não predestinar. Portanto, não é certa a predestinação.
Mas, em contrário, àquilo da Escritura (Rm 8, 29): — porque os que ele conheceu na presciência tam-
bém os predestinou, etc. — diz a Glosa: A predestinação é a presciência e a preparação dos benefícios
de Deus, pela qual com certeza se salvam os que se salvam.

SOLUÇÃO. — A predestinação certíssima e infalivelmente produz o seu efeito; todavia, não impõe
necessidade, causando-o necessariamente. Pois, como dissemos, a predestinação faz parte da
providência. Ora, nem tudo o que desta depende é necessário, mas certos efeitos se realizam
contingentemente, segundo a condição das causas próximas, que a providência ordenou para eles.
Contudo, conforme demonstramos, é infalível a ordem da providência. Por onde, também é certa a
ordem da predestinação, que porém não elimina o livre arbítrio do qual provém contingentemente o
efeito daquela. — E, nesta questão, também devemos relembrar o que antes dissemos, que embora
certíssimas e infalíveis, a ciência e a vontade divinas não tiram às causas a contingência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De dois modos dizemos que tem alguém uma coroa. De
um modo, pela predestinação divina, e então ninguém perde a sua coroa. De outro, pelo mérito da
graça, pois, o merecido, de certa maneira, é nosso; e então, como conseqüência do pecado mortal,
podemos perder a coroa. Mas outro recebe a coroa perdida, subrogado no lugar de quem a perdeu.
Pois, Deus não permite a queda de uns sem lhes substituir outros, segundo a Escritura (Jó 34, 24): Ele
destruirá a sua inumerável multidão e porá outros em seu lugar. Assim, os homens substituíram os anjos
decaídos, e os Gentios, os Judeus. E o substituto em estado de graça também recebe a coroa, no sentido
em que gozará, na vida eterna, dos bens que o outro praticou; pois, nessa vida, gozaremos do bem
praticado tanto por nós mesmos, como por outros.

RESPOSTA À SEGUNDA. — Embora, em si considerado, seja possível o predestinado morrer em pecado
mortal, todavia tal é impossível, uma vez que é predestinado. Donde não se segue, que a predestinação
pode falhar.

RESPOSTA À TERCEIRA. — Incluindo a predestinação a divina vontade, assim como já dissemos ser
necessário, por suposição, por causa da imutabilidade dessa vontade, mas não absolutamente, que
Deus queira uma determinada criatura, assim o mesmo devemos dizer a propósito da predestinação.
Por onde, não devemos dizer que Deus possa não predestinar quem predestinou, entendendo-o num
sentido composto; embora, absolutamente falando, Deus possa predestinar ou não; o que, porém, não
destrói a certeza da predestinação.

## Art. 7 — Se é certo o número dos predestinados.
(I Sent., dist. XL, q. 3; De Verit., q. 6, a 4).
O sétimo discute-se assim. — Parece que não é certo o número dos predestinados.

1. — Pois, não é certo o número que podemos aumentar. Ora, o número dos predestinados podemos
aumentá-lo, como diz a Escritura (Dt 1, 11): O Senhor Deus... ajunte a este número muitos milhares. E a
Glosa: Isto é, um número definido para Deus, que conhece os que o compõem. Logo, não é certo o
número dos predestinados.

2. Demais. — Não se pode dar a razão porque Deus preordenou à salvação um número de homens, de
preferência a outro. Ora, Deus nada faz sem razão. Logo, não foi preordenado por ele o número certo
dos que se devem salvar.

3. Demais. — A obra de Deus é mais perfeita que a da natureza. Ora, nas obras desta, o bem se
manifesta quase sempre; e, em poucos casos, a falha é o mal. Se, pois, Deus instituísse um número certo
dos que se deveriam salvar, mais numerosos deveriam ser os que se salvassem que os que se
condenassem. Mas, a Escritura diz o contrário (Mt 7, 13-14): Larga é a porta e espaçoso é o caminho que
guia para a perdição e muitos são os que entram por ela. Que estreita é a porta e que apertado o
caminho que guia para a vida! E que poucos são os que acertam com ele! Logo, não foi preordenado por
Deus o número dos que se devem salvar.
Mas, em contrário, diz Agostinho: É certo e não pode aumentar, nem diminuir o número dos
predestinados.

SOLUÇÃO. — O número dos predestinados é certo. Alguns porém disseram que o é formal, mas não
materialmente. Como p. ex., se disséssemos ser certo que cem ou mil se salvarão, mas não estes ou
aqueles. Ora, esta opinião destrói a certeza da predestinação, de que já tratamos. E portanto devemos
dizer que, para Deus, o número dos predestinados é certo, não só formal, mas ainda, materialmente.
Devemos, porém advertir, que afirmamos ser certo o número dos predestinados para Deus, não só em
razão do conhecimento, porque sabe quantos devem salvar-se; pois, assim, também sabe ao certo o
número das gotas da chuva e da areia do mar; mas, em razão de uma certa eleição e determinação.
Para evidenciá-lo devemos saber, que todo agente busca produzir um efeito finito, como resulta do que
dissemos sobre o infinito. Ora, quem busca uma medida determinada, no efeito que produz, procura um
certo número, nas partes essenciais dele, necessárias para a perfeição do todo; não escolhe
determinado número, em si mesmo, nas partes exigidas não principalmente, mas em razão de outras; e
só as toma em número tal que seja necessário por causa dessas outras. Assim, um construtor escolhe a
medida determinada da casa, e mesmo o número determinado dos compartimentos que nela quer
fazer, bem como o das dimensões da parede ou do teto; mas, não escolhe o número determinado das
pedras, senão que as toma tantas quantas bastem a construir a parede, nas suas dimensões
demarcadas.
Ora, o mesmo devemos dizer de Deus, em relação a todo o universo que é seu efeito. Assim, Deus lhe
preordenou as dimensões e o número conveniente das suas partes essenciais, as quais se ordenam, de
certo modo, à perpetuidade: quantas esferas, quantas estrelas, quantos elementos, quantas espécies de
seres. Mas, os indivíduos corruptíveis se ordenam ao bem do universo, não principal, mas,
secundàriamente, enquanto conservam o bem da espécie. Por isso, embora Deus saiba deles todos o
número certo, não preordenou contudo, em si, o número dos bois ou dos mosquitos ou de seres
semelhantes, que a sua divina providência somente cria na medida bastante à conservação das
espécies. Ora, dentre todas as criaturas, ordenam-se principalmente ao bem do universo as racionais,
como tais incorruptíveis; sobretudo as que, alcançando a beatitude, mais imediatamente atingem o fim
último. Por onde, o número dos predestinados é certo, para Deus, não somente em razão do
conhecimento, mas também em razão de uma certa e principal predeterminação. O que porém de
nenhum modo se dá com o número dos réprobos, que Deus preordenou ao bem dos eleitos, aos quais
todas as causas lhes contribuem para seu bem.
Quanto ao número de todos os predestinados — tantos homens se salvarão quantos os anjos decaídos,
dizem uns; quantos os anjos fiéis, dizem outros; não somente quantos os decaídos, mas mesmo,
quantos os anjos criados, dizem ainda outros. Mas, é melhor pensar, que só Deus sabe o número dos
eleitos à suprema felicidade (como está na Coleta pelos vivos e defuntos).

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O lugar citado do Deuteronômio deve ser entendido dos
que são prenotados por Deus, relativamente à justiça presente. Ora, o número deles aumenta e diminui;
mas não o dos predestinados.

RESPOSTA À SEGUNDA. — A noção da quantidade da parte se deduz da sua proporção com o todo. E
assim, a razão porque Deus fez tantas estrelas, e tantas espécies de seres e tantos predestinou, é a
proporção das partes principais com o bem do universo.

RESPOSTA À TERCEIRA. — O bem proporcionado ao estado comum da natureza se realiza em muitos
seres e falha em poucos. Mas, o contrário se dá com o bem excedente a esse estado comum. Assim, a
ciência suficiente para administrar a própria vida muitos a têm, e os poucos que dela carecem se
chamam tolos ou estultos; são porém pouquíssimos em relação aos outros os que atingem à ciência
profunda das coisas inteligíveis. Ora, consistindo na visão de Deus, a eterna beatitude excede o estado
comum da natureza, sobretudo porque a graça se perdeu pela corrupção do pecado original, e por isso
poucos se salvam. E aqui refulge por excelência a misericórdia de Deus, elevando alguns à salvação, que
muitos não alcançam abandonados ao curso comum e inclinação da natureza.

## Art. 8 — Se a predestinação pode ajudar-se das preces dos santos.
(I Sent., dist. XLI, a. 4; III, dist. XVII, a. 3, qª 1, ad 3; IV, dist. XLV, q. 3, a. 3, ad 5; De Verit., q. 6, a. 6).
O oitavo discute-se assim. — Parece que a predestinação não pode ajudar-se das preces dos santos.

1. — Pois, nada do que é eterno pode ser precedido pelo temporal; e por conseqüência, não pode o
temporal contribuir para a existência do eterno. Ora, a predestinação é eterna. Logo, sendo temporais,
as preces dos santos não podem contribuir para ninguém ser predestinado. Por onde, a predestinação
não é ajudada pelas preces dos santos.

2. Demais. — Ninguém, senão por falta de conhecimento, precisa de conselho, assim como nada, senão
por falta de virtude, precisa de auxílio. Ora, nada disto convém a Deus predestinador; donde o dizer a
Escritura (Rm 11, 34): Quem ajudou o espírito do Senhor? Ou quem foi o seu conselheiro? Logo, a
predestinação não se pode ajudar das preces dos santos.

3. Demais. — O que pode ser ajudado também pode ser impedido. Ora, de nenhum modo pode a
predestinação ser impedida. Logo, nem pode ser de ninguém ajudada.
Mas, em contrário, a Escritura (Gn 25, 21): E orou Isaque por sua mulher ... ao Senhor, o qual ... permitiu
que Rebeca concebesse. Ora, dessa concepção nasceu Jacó, que foi predestinado. Mas não se cumpriria
a predestinação se não tivesse nascido. Logo, a predestinação pode ajudar-se das preces dos santos.

SOLUÇÃO. — Houve diversos erros sobre essa questão. — Uns, atendendo à certeza da divina
predestinação, disseram, que são supérfluas as orações e tudo o mais que se faça para alcançar a
salvação eterna; porque, feitas tais coisas ou não, os predestinados se salvam e não se salvam os
réprobos. — Mas, tal opinião vai contra todas as advertências da Sagrada Escritura, exortando à oração
e a outras boas obras.
Outros, porém, disseram, que, pelas orações muda-se a divina predestinação. E tal se diz ter sido a
opinião dos Egípcios, ensinando que a ordenação divina, a que chamavam fado, pode ser impedida por
alguns sacrifícios e orações. — Mas também contra esta opinião é a autoridade da Sagrada Escritura (1
Rg 15, 29): Mas o triunfador em Israel não perdoará e nem se dobrará pelo arrependimento; e (Rm 11,
29): os dons e a vocação de Deus são imutáveis.
Por onde, devemos dizer, de outro modo, que duas coisas se devem considerar na predestinação; a
preordenação divina em si mesma e seu efeito. Quanto àquela, de maneira alguma pode a
predestinação ajudar-se das preces dos santos. Pois, estas não fazem com que ninguém seja
predestinado por Deus. Quanto ao efeito, dizemos que a predestinação se ajuda das preces dos santos e
de outras boas obras. Porque a Providência, da qual ela faz parte, não elimina as causas segundas, mas
prevê o efeito de maneira tal que mesmo a ordem das causas segundas se lhe sujeite. Assim como, pois,
da providência dependem os efeitos naturais, de modo que mesmo as causas naturais se ordenem a
esses efeitos, sem as quais estes não poderiam existir, assim também, quando Deus predestina a
salvação de alguém, entra também na ordem da predestinação tudo o que tal pessoa faça para salvar-
se, como as orações ou outros bens, e causas semelhantes, próprias ou de outrem, sem as quais
ninguém alcançará a salvação. Por isso, os predestinados devem se esforçar por bem agir e orar,
porque, de tal modo se cumpre com certeza o efeito da predestinação. Donde o dito da Escritura (2 Pd
1, 10): Ponde cada vez maior cuidado em fazerdes certa a vossa vocação e eleição por meio das boas
obras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção mostra que a predestinação não se pode
ajudar das preces dos santos, quanto à preordenação em si mesma.

RESPOSTA À SEGUNDA. — De duplo modo dizemos que alguém é ajudado por outrem. De um modo,
quando dele recebe auxílio; o que, sendo próprio do fraco, não convém a Deus. E nesse sentido que se
deve entender o lugar: Quem ajudou o espírito do senhor? De outro modo, dizemos que alguém é
ajudado por outrem, quando este lhe executa a obra; assim, o senhor é ajudado pelo criado. E deste
modo Deus é de nós ajudado, quando lhe executamos a ordem, segundo a Escritura (1 Cor 3, 9): Porque
nós outros somos uns cooperadores de Deus. Nem é isto por defeito da divina virtude, mas porque ela
usa de causas intermédias para conservar nas coisas a beleza da ordem e também para comunicar às
criaturas a dignidade causal.

RESPOSTA À TERCEIRA. — As causas segundas não podem, como vimos, escapar à ordem da causa
primeira universal; antes, elas a executam. Por onde, a predestinação pode ser ajudada, mas não
impedida pelas criaturas.