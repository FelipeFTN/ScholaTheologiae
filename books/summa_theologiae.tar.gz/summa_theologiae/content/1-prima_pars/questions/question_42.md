# Questão 42: Da igualdade e da semelhança das Pessoas divinas entre si.
Em seguida devemos tratar da relação das Pessoas entre si. E primeiramente, da igualdade e da
semelhança; segundo, da missão.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a igualdade convém às Pessoas divinas.
(I Sent., dist. XIX, q. 1. a. 1).
O primeiro discute-se assim. – Parece que a igualdade não convém às pessoas divinas.

1. – Pois, a igualdade supõe a unidade quantitativa, como está claro no Filósofo. Ora, em Deus não há
nem a quantidade contínua intrínseca, chamada grandeza; nem a quantidade contínua extrínseca
chamada lugar e tempo; nem a igualdade fundada na quantidade discreta, pois duas pessoas são mais
que uma. Logo, às pessoas divinas não convém à igualdade.

2. Demais. – As pessoas divinas têm a mesma essência, como se disse. Ora, a essência é expressa como
forma. Ora, a conveniência pela forma não produz a igualdade, mas, a semelhança. Logo, às pessoas
divinas devemos atribuir a semelhança e não a igualdade.

3. Demais. – Quaisquer seres iguais o são entre si, pois, chamamos igual ao igual ao igual. Ora, as
pessoas divinas não podem se considerar iguais entre si. Porque, como diz Agostinho, a imagem, que
perfeitamente reproduz o ser de que é imagem, deve-lhe ser igual a ele, e não, ele a ela. Ora, imagem
do Pai é o Filho, e portanto não é o Pai igual ao Filho. Logo, nas pessoas divinas não há igualdade.

4. Demais. – A igualdade é uma determinada relação. Ora, nenhuma relação é comum a todas as
pessoas; pois, pelas relações é que as pessoas se distinguem umas das outras. Logo, a igualdade não
convém às pessoas divinas.
Mas, em contrário, diz Atanásio, que as três pessoas são entre si coeternas e coiguais.

SOLUÇÃO. – É forçoso admitirmos a igualdade das pessoas divinas. Pois, segundo o Filósofo, o igual é
uma quase negação do menor e do maior. Ora, não podemos, nas pessoas divinas, introduzir o conceito
de maior nem de menor; porque, como diz Boécio, a diferença de divindade resulta da opinião dos que
a aumentam ou a diminuem, como os Arianos que, fazendo variar a Trindade pelos graus dos méritos, a
destroem e introduzem nela a pluralidade. E a razão disso está em não poderem seres desiguais ter a
mesma quantidade numérica. Ora, a quantidade em Deus não é senão a sua essência mesma. Donde
resulta, que se existisse qualquer desigualdade nas pessoas divinas, elas não teriam a mesma essência e,
portanto, não constituiriam um só Deus, o que é impossível. Logo, devemos admitir a igualdade das
pessoas divinas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Há duas sortes de quantidade. Uma a chamada
de massa ou dimensiva, só existente na matéria, e, portanto não nas pessoas divinas. Outra é a
quantidade de virtude, assim chamada por se fundar na perfeição de uma natureza ou forma. E essa nós
a designamos quando dizemos que um corpo é mais ou menos cálido segundo tiver o calor mais ou
menos perfeitamente. Ora, esta quantidade virtual é considerada, primeiro, radicalmente, isto é, quanto
à perfeição mesma da forma ou da natureza; e nesse sentido falamos em grandeza espiritual, como
chamamos grande ao calor que o é pela sua intensidade e perfeição. Por isso, diz Agostinho, que, em
coisas que não são grandes pela massa, ser maior é o ser melhor;pois, melhor se diz o que é mais
perfeito. Em segundo lugar, a quantidade é considerada virtual, pelos efeitos da forma. Ora, o primeiro
efeito da forma é o ser, pois, cada coisa tem o ser pela sua forma. E o segundo efeito é a ação, pois todo
agente age pela sua forma. Por onde, a quantidade virtual se funda no ser e na ação. No ser, porque as
coisas de natureza mais perfeita são de maior duração. E na ação, porque as coisas de natureza mais
perfeita têm maior poder de agir. E assim, como diz Agostinho, entende-se que há igualdade no Pai, no
Filho e no Espírito santo, porque nenhum deles precede pela eternidade, excede pela grandeza ou
supera pelo poder.

RESPOSTA À SEGUNDA. – Considerada relativamente à quantidade virtual, a igualdade inclui em si a
semelhança e ainda mais, porque exclui o excesso. Pois, todos os seres que comunicam pela mesma
forma, podem ser chamados semelhantes, mesmo se participarem desigualmente dessa forma; como se
se disser que o ar é semelhante ao fogo, pelo calor. Mas não se podem chamar iguais se um participar
da forma mais perfeitamente que os outros. Ora, como não somente é a mesma a natureza do Pai e do
Filho, mas também em ambos há igualdade perfeita, podemos dizer que o Filho é semelhante ao Pai,
para excluirmos o erro de Eunômio; mas também podemos dizer que é igual, para excluirmos o erro de
Ario.

RESPOSTA À TERCEIRA. – A igualdade ou a semelhança em Deus podem ser expressas de dois modos:
por nomes e por verbos. Quando expressa por nomes, dizemos que há nas pessoas divinas mútua
igualdade e semelhança; porque o Filho é igual e semelhante ao Pai, e inversamente. E isto por não ser a
essência divina mais do Pai do que do Filho. Por onde, assim como o Filho tem a grandeza do Pai, que o
torna igual a este, assim o Pai tem a do Filho, que também o torna igual a ele. Mas nas criaturas, como
diz Dionísio, não há conversão da igualdade em semelhança. Pois, as coisas causadas se dizem
semelhantes às causas por terem as formas destas; não, porém, inversamente, porque a forma está
principalmente na causa e secundariamente, no causado. Os verbos, porém, significam a igualdade com
movimento. E embora não haja movimento em Deus, pode ele todaviareceber. Pois, pelo Filho receber
do Pai o que o torna igual ao Pai, e não, inversamente, por isso dizemos que o Filho é o igual ao Pai, e
não inversamente.

RESPOSTA À QUARTA. – Nas pessoas divinas não devemos considerar senão a essência em que
comunicam, e as relações pelas quais se distinguem. Mas a igualdade supõe uma e outra coisa: a
distinção das pessoas, porque nada é igual a si mesmo; e a unidade de essência, pois as pessoas são
iguais entre si por terem a mesma grandeza e a mesma essência. É, porém, manifesto que uma coisa
não se refere a si mesma por nenhuma relação real. E também nenhuma relação se refere a outra por
qualquer terceira relação. Quando, pois, dizemos que a paternidade se opõe à filiação, essa oposição
não é uma relação média entre a paternidade e a filiação, porque de um e outro modo a relação se
multiplicaria ao infinito. Por onde, a igualdade e a semelhança, nas pessoas divinas, não é nenhuma
relação distinta das relações pessoais, mas no seu conceito incluem tanto as relações distintivas das
pessoas como a unidade de essência. Por isso o Mestre das Sentenças diz, que em Deus a
apelação é somente relativa.

## Art. 2 — Se a Pessoa procedente é coeterna com o seu princípio, como o Filho com o Pai.
(III Sent., dist. XI, a. 1; De Pot., q. 3, a. 13; Compend, Theol., cap. XLIII; In Decretal. I; Ioan., cap. I. lect. I).
O segundo discute-se assim. – Parece que a pessoa procedente não é coeterna com o seu princípio,
como o Filho, com o Pai.

1. – Pois Ario assinala doze modos de geração. O primeiro modo é o pelo qual a linha provém do ponto,
no que falta a igualdade da simplicidade. O segundo, pelo qual a emissão dos raios provém do sol, no
que falta a igualdade de natureza. O terceiro, pelo qual o caráter ou a impressão provem do carimbo, no
que falta a consubstancialidade e a eficiência do poder. O quarto, pelo qual a imissão da boa vontade
provém de Deus, no que também falta a consubstancialidade. O quinto, pelo qual provem o acidente da
substância; mas ao acidente falta a subsistência. O sexto, pelo qual a abstração da espécie provém da
matéria, da mesma maneira que o sentido recebe a espécie, da coisa sensível; no que falta a igualdade
de espiritualidade. O sétimo, pelo qual a excitação da vontade provém do conhecimento, cuja excitação
é temporal. O oitavo é pela transfiguração, da maneira pela qual do ar se faz a imagem; e esse é
material. O nono, pelo qual o movimento provém do motor, onde também há efeito e causa. O décimo,
pelo qual as espécies provém gênero, o que não convém a Deus, pois, o Pai não é predicado do Filho,
como o gênero da espécie. O undécimo é o pela ideação, como a arca exterior procede da que está na
mente. O duodécimo, pelo qual os seres que nascem, p. ex., um homem, procede de um pai, no que há
anterioridade e posterioridade no tempo. É, portanto, claro que, em todos os modos pelos quais uma
coisa procede de outra, ou falta a igualdade de natureza ou a de duração. Se, pois, o Filho procede do
Pai, é necessário dizer ou que ele é menor que o Pai, ou que é posterior, ou uma e outra coisa.

2. Demais. – Tudo o que provém de outro tem princípio. Logo, o Filho não é eterno e nem o Espírito
Santo.

3. Demais. – Tudo o que se corrompe deixa de existir. Logo, tudo o que é gerado começa a existir, pois, o
gerado o é, para existir. Ora, o Filho foi gerado pelo Pai. Logo começa a existir e não é coeterno com o
Pai

4. Demais. – Se o Filho foi gerado pelo Pai, ou foi sempre ou devemos admitir um instante em que foi
gerado. Se sempre foi gerado, como toda coisa gerada é imperfeita, segundo claramente o mostram as
sucessivas, como o tempo e o movimento, que estão sempre em vir a ser, resulta que o Filho é sempre
imperfeito, o que é inadmissível. Logo, devemos admitir de sorte que, antes desse momento, o Filho
não existia.
Mas, em contrário, diz Atanásio, no Símbolo que todas as três pessoas são coeternas entre si.

SOLUÇÃO. – Devemos admitir que o Filho é coeterno com o Pai. Para evidenciá-lo é mister notar que, o
ser tudo o que existe, em virtude de um princípio, posterior ao seu princípio, pode dar-se de dois
modos: relativamente ao agente ou relativamente à ação. – Relativamente ao agente, devemos
distinguir entre os agentes voluntários e os naturais. Nos voluntários, por causa da eleição no tempo;
pois, assim como está no poder de um agente voluntário escolher a forma que vai conferir ao efeito,
segundo dissemos, assim no poder do mesmo está escolher o tempo em que produzirá esse efeito. Com
os agentes naturais, porém, tal se dá porque esses agentes não tem originariamente a perfeição da
virtude natural para agir, mas a recebem só depois de certo tempo; assim, o homem não pode gerar
desde que começa a existir. – Relativamente à ação, é impossível o que provém de um princípio ser
simultâneo com este, porque a ação é sucessiva. Por onde, dado que um agente viesse a agir, deste
modo, imediatamente depois de ter começado a existir, o efeito não existiria concomitantemente, no
mesmo instante, mas no instante em que terminasse a ação.
Ora, é claro, pelo que demonstramos, que o Pai não gera o Filho pela vontade, mas pela natureza; e
demais, que a natureza do Pai é perfeita abeterno; e ainda que a ação pela qual o Pai produz o Filho não
é sucessiva, porque então o Filho de Deus seria gerado sucessivamente, e a sua geração seria material e
sujeita ao movimento, o que é impossível. Donde se conclui, que o Filho existiu desde que existiu o Pai.
E portanto é coeterno com o Pai. E, semelhantemente, o Espírito Santo, com ambos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como ensina Agostinho, nenhum modo de processão de
qualquer criatura representa perfeitamente a geração divina. Por onde, é necessário buscarmos a
semelhança, de muitos modos de maneira a completar por uma o que a outra falta. Por isso diz o Sínodo
Efesino: Que o Esplendor te mostre que o Filho coexiste sempre coeterno com o Pai. Que o Verbo te
mostre ser impassível a natividade. Que o nome de Filho te insinue a consubstancialidade. Mas, dentre
todas as semelhanças, a processão do verbo, do intelecto, é a que mais expressamente a representa;
pois, o verbo não é posterior ao princípio donde procede, a menos que não seja o intelecto tal que
passe da potência para o ato; o que não se pode dizer de Deus.

RESPOSTA À SEGUNDA. – A eternidade exclui o princípio de duração, mas não o de origem.

RESPOSTA À TERCEIRA. – Toda corrupção é uma certa mutação; donde, tudo o que se corrompe
começa a não ser e cessa de ser. Ora, a geração divina não é uma transmutação, como se disse. Por isso,
o Filho sempre é gerado e o Pai sempre gera.

RESPOSTA À QUARTA. – No tempo, uma coisa é o seu elemento indivisível, que é o instante e outra, o
persistente, que é o tempo. Mas na eternidade, o próprio instante é indivisível e sempre existente,
como se disse. Ora, a geração do Filho não é num instante do tempo ou no tempo, mas na eternidade. E
portanto, para exprimirmos a presencialidade e a permanência da eternidade, podemos, com Origines,
dizer que sempre nasce. Mas, com Gregório e Agostinho, melhor é dizermos sempre nascido,
designando sempre a permanência da eternidade, e nascido, a perfeição do ser gerado. Assim, pois, o
Filho não é imperfeito, nem existia quando ainda não existia, como disse Ário.

## Art. 3 — Se nas Pessoas divinas há a ordem da natureza.
(I Sent., dist. XII, a. 1; dist. XX, a. 3; De Pot., q. 10, a. 3; Contra errors Graec., parte II, cap. XXXI).
O terceiro discute-se assim. – Parece que nas pessoas divinas não há a ordem da natureza.

1. – Pois, tudo o que existe em Deus é essência ou pessoa ou noção. Ora, a ordem da natureza não
significa a essência, nem nenhuma das pessoas ou das noções. Logo, a ordem da natureza não existe em
Deus.

2. Demais. – Em todos os seres onde há a ordem da natureza, um é anterior ao outro, ao menos pela
natureza e pelo conceito. Ora, nas pessoas divinas, não há anterior nem posterior, como diz Atanásio
(no Símbolo). Logo, nas pessoas divinas não há a ordem da natureza.

3. Demais. – Tudo o ordenado é distinto. Ora, a natureza, em Deus, não é distinta. Portanto, não é
ordenada. Logo, não há em Deus a ordem da natureza.

4. Demais. – A natureza divina é a sua essência. Ora, em Deus, não há a ordem da essência. Logo, nem a
da natureza.
Mas, em contrário. – Onde quer que haja pluralidade sem ordem, há confusão. Ora, nas pessoas divinas
não há confusão, como diz Atanásio. Logo; há ordem.

SOLUÇÃO. – A ordem supõe sempre relação com um princípio. Ora, a palavra princípio tem múltiplos
sentidos, a saber: o locativo, como o ponto; o intelectivo, como o princípio da demonstração; o relativo
a cada causa. Assim também a ordem. Mas, em Deus, o princípio é relativo à origem, sem idéia de
prioridade, como vimos. Por onde, há necessariamente em Deus a ordem, quanto à origem, sem idéia
de prioridade. E essa é a ordem da natureza, conforme Agostinho, quando diz: Não por ser um anterior
ao outro, mas por ser um procedente do outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Ordem da natureza significa a noção de origem, em
comum, não porém, em especial.

RESPOSTA À SEGUNDA. – Nas criaturas, embora a que provém de um princípio seja com este coevo,
quanto à duração, todavia o seu princípio lhe é anterior, real e logicamente se o considerarmos na sua
noção própria. Mas, considerando as relações mesmas de causa e de causado, e de principio e de
principiado, é claro que são relativas, simultaneamente, real e logicamente, porque um entra na
definição do outro. Ora, em Deus as próprias relações são pessoas subsistentes numa mesma natureza.
Donde, nem quanto a natureza nem quanto às relações, uma pessoa pode ser anterior à outra, e nem
quanto à natureza e ao intelecto.

RESPOSTA À TERCEIRA. – Quando falamos da ordem da natureza, isso não significa que a natureza
mesma seja ordenada, mas que a ordem, nas pessoas divinas, é considerada na sua origem natural.

RESPOSTA À QUARTA. – A natureza, de certo modo, importa a noção de princípio; não porém a
essência. Por isso a ordem de origem melhor se denomina ordem de natureza do que de essência.

## Art. 4 — Se o Filho é igual ao Pai em grandeza.
(I Sent., dist. XIX, q. 1, a. 2; IV Cont. Gent., cap. VII, XI. In Boet. De Trin., q. 3, a. 4).
O quarto discute-se assim. – Parece que o Filho não é igual ao Pai em grandeza.

1. – Pois, ele próprio o diz, na Escritura (Jo 14, 28): O Pai é maior do que eu. E o Apóstolo (1 Cor 15,
28): O mesmo Filho estará sujeito aquele que sujeitou a ele todas as coisas.

2. Demais. – A paternidade é própria à dignidade do Pai. Ora, a paternidade não convêm ao Filho. Logo,
nem toda dignidade que tem o Pai tem o Filho. Portanto, não é igual ao Pai em grandeza.

3. Demais. – Onde há todo e partes, muitas são mais que uma só ou algumas; assim, três homens são
mais que dois ou um. Ora, em Deus, o todo é universal e parte; pois, a relação ou a noção inclui várias
noções. Portanto, como no Pai há três noções, e no Filho somente duas, não é este igual ao Pai.
Mas, em contrário, a Escritura (Fp 2, 6): Não julgou que fosse uma usurpação o ser igual a Deus.

SOLUÇÃO. – Devemos admitir que o Filho seja igual ao Pai em grandeza. Mas a grandeza de Deus não é
outra coisa senão a perfeição da sua natureza. Ora, é da essência da paternidade e da filiação que o
filho, pela geração, tenha a perfeição da natureza existente no pai, como também o pai. Mas como a
geração humana é uma transmutação do ser, que passa da potência para o ato, o filho não é
imediatamente igual, desde o seu nascimento, ao pai que o gerou, mas, pelo crescimento continuado,
chega à igualdade, a menos que não suceda de outro modo, por defeito do princípio da geração.
Ora, é manifesto pelo que dissemos, que em Deus há, própria e verdadeiramente, paternidade e
filiação. Nem se pode dizer que a virtude de Deus Pai fosse deficiente ao gerar; nem que Filho de Deus
chegasse à perfeição sucessivamente e por mudanças. Por onde, necessário é concluir, que abeterno foi
igual ao Pai em grandeza. E por isso Hilário diz: Suprime as enfermidades do corpo,
suprime o desenvolvimento da inteligência, suprime as dores do parto e toda a humana necessidade:
todo filho, pela natividade natural, é igual ao pai porque tem a semelhança da natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As palavras citadas entendem-se ditas da natureza
humana de Cristo, pela qual é menos do que o Pai e a este sujeito. Mas, pela sua natureza divina, é igual
ao Pai. E é o que diz Atanásio no Símbolo: Igual ao Pai pela divindade; menor que o Pai, pela
humanidade. Ou conforme Hilário: OPai é maior pela autoridade Doador; mas menor não é aquele a
quem foi dado o mesmo ser. E diz ainda, quea sujeição do Filho é o amor da natureza, i. é, o
reconhecimento da autoridade paterna; porém, a sujeição aos demais é pela imperfeição da criação.

RESPOSTA À SEGUNDA. – A igualdade se funda na grandeza. Ora, esta, em Deus, exprime perfeição da
natureza, como se disse, e pertence à essência. Portanto, a igualdade em Deus e a semelhança dizem
respeito ao essencial; nem podemos lhe atribuir desigualdade ou semelhança quanto à distinção das
relações. Por isso diz Agostinho: A questão da origem é a de saber de que um ser provém: a da
igualdade, a de saber, que qualidade tem. Logo, a paternidade é a dignidade do Pai, assim como é a sua
essência. Pois, a dignidade é um absoluto e pertence à essência. Portanto, assim como a mesma
essência, que no Pai é a paternidade, no Filho é a filiação; assim, a mesma dignidade, que no Pai é a
paternidade, no Filho é a filiação. Por onde, verdadeiramente dizemos que toda dignidade que tem o
Pai, tem o Filho, sem daí seguir-se que pelo Pai ter a paternidade, também a tenha o Filho. Porque se
muda o ponto de vista absoluto (quid) no relativo (ad aliquid). Pois a mesma é a essência e a dignidade
do Pai e do Filho; mas, no Pai, pela relação de dador: no Filho, pela de quem recebe.

RESPOSTA À TERCEIRA. – A relação em Deus não é um todo universal, embora seja predicada de cada
uma das relações; porque todas as relações são essencial e existencialmente uma mesma relação; o que
repugna à noção de universal, cujas partes se distinguem pelo ser. E semelhantemente, a pessoa, como
dissemos, não é um universal em Deus. Por onde, todas as relações juntas não são em nada maiores que
uma só delas; nem todas as pessoas juntas são em nada maiores que uma delas somente; porque a
perfeição total da natureza divina está em cada uma das pessoas.

## Art. 5 — Se o Filho está no Pai e inversamente.
(I Sent., dist. XIX, q. 3, a. 2; IV Cont. Gent., cap. IX; Ioan., cap. X; cap. XVI, lect. VII).
O quinto discute-se assim. – Parece que o Filho não está no Pai e inversamente.

1. – Pois, segundo o Filósofo, de oito modos pode um ser existir em outro; e por nenhum deles o Filho
está no Pai; e inversamente, como claramente o verá quem examinar cada um desses modos. Logo, o
Filho não está no Pai, nem inversamente.

2. Demais. – O que saiu de um ser já neste não está. Ora, o Filho abeterno saiu do Pai, segundo a
Escritura (Mq 5, 2): Cuja geração é desde o princípio, desde os dias da eternidade. Logo, o Filho não está
no Pai.

3. Demais. – Um dos contrários não está no outro. Ora, o Filho e o Pai opõem-se relativamente. Logo,
um não pode estar no outro.
Mas, em contrário,a Escritura (Jo 14, 10): Eu estou no Pai e o Pai está em mim.

SOLUÇÃO. – Três coisas devemos considerar no Pai e no Filho, a saber: a essência, a relação e a origem.
E segundo cada uma delas, o Filho está no Pai e inversamente. – Pela essência o Pai está no Filho,
porque o Pai é a sua essência e a comunica ao Filho sem sofrer nenhuma mudança. Donde se segue que,
estando no Filho a essência do Pai, no Filho está o Pai. Semelhantemente, sendo o Filho a sua essência,
segue-se que está no Pai, no qual também ela está. E é o que diz Hilário: Conseqüente com a sua
natureza, para assim nos exprimirmos, Deus imutável gera um imutável Deus subsistente. E entendemos
que neste está a natureza subsistente de Deus, por estar nele Deus. – Mas, quanto às relações, é claro
que um contrário está no outro relativamente, pelo intelecto. – Também quanto à origem, é claro que a
processão do verbo inteligível não é exterior, mas permanece no dicente. Pois, o que é dito pelo verbo
no verbo está contido. – E o mesmo devemos dizer do Espírito Santo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O modo de ser das criaturas não representa
suficientemente o modo de ser de Deus. Por isso, de nenhum dos modos, que o Filósofo enumera, o
Filho está no Pai e inversamente. O modoporém que mais se aproxima é aquele pelo qual dizemos que
um ser está no seu principio originante; salvo que, nos seres criados, falta a unidade de essência entre o
princípio e o que dele provém.

RESPOSTA À SEGUNDA. – O Filho sai do Pai a modo de processão interior, assim como o verbo sai da
mente e nela permanece. Por onde, esse modo de proceder, em Deus, funda-se na só distinção das
relações, e não em nenhuma separação essencial.

RESPOSTA À TERCEIRA. – O Pai e o Filho opõem-se pelas suas relações e não, pela essência. E contudo
um dos contrários está relativamente no outro, como se disse.

## Art. 6 — Se o Filho é igual ao Pai pelo poder.
(I Sent., dist. XX, a. 2; IV Cont. Gent., cap. VII, VIII).
O sexto discute-se assim. – Parece que o Filho não é igual ao Pai pelo poder.

1. – Pois, diz a Escritura (Jo 5, 19): O Filho não pode de si mesmo fazer coisa alguma senão o que vir
fazer ao Pai. Mas, o Pai pode fazer por si. Logo, o Pai é maior que o Filho, pelo poder.

2. Demais. - Maior é o poder de quem manda e ensina do que o de quem obedece e ouve. Ora, o Pai
manda o Filho, segundo a Escritura (Jo 14, 31): Faço o que o Pai me ordena. O Pai também ensina ao
Filho, segundo ainda o Evangelho (Jo 5, 20): O Pai ama ao Filho e mostra-lhe tudo o que faz. Enfim o
Filho ouve, ainda segundo a Escritura (Jo 5, 30): Assim como ouço, julgo. Logo, o Pai tem maior poder
que o Filho.

3. Demais. – Pela sua onipotência é que o Pai gera um Filho igual a si, segundo Agostinho: Se não pôde
gerar um filho igual a si, onde está a onipotência de Deus Padre?Ora, o Filho não pode gerar o Filho,
como se demonstrou. Logo, nem tudo o que pode a onipotência do Pai o pode também o Filho.
Portanto, este não lhe é igual em poder.
Mas, em contrário,a Escritura (Jo 5, 19): Tudo o que fizer o Pai o faz também semelhantemente o Filho.

SOLUÇÃO. – Éforçoso admitirmos que o Filho é igual ao Pai em poder. Pois, o poder de agir resulta da
perfeição da natureza. Assim, vemos que quanto mais perfeita for a natureza de uma criatura, tanto
maior será o seu poder de agir. Porque, como demonstramos, a essência mesma da paternidade e da
filiação divina exige que o Filho seja igual ao Pai em grandeza, i. é, em perfeição natural. Donde resulta
que o Filho é igual ao Pai em poder. – E o mesmo devemos dizer do Espírito Santo, em relação às outras
duas pessoas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Quando a Escritura diz: O Filho não pode de si mesmo
fazer coisa alguma– não o priva por isso de nenhum poder do Pai; pois, logo acrescenta: - Tudo o que
fizer o Pai o faz também semelhantemente o Filho. Mas essa expressão mostra que o Filho tem o poder,
do Pai, de quem recebeu a natureza. Por isso diz Hilário: A unidade da natureza divina é tal que o Filho
faz por si o que não fazde si.

RESPOSTA À SEGUNDA. – Quando a Escritura diz que o Pai ensina e o Filho ouve, não quer dizer senão
que o Pai comunica a sua ciência ao Filho e também a sua essência. No mesmo sentido podemos
entender o mandado do Pai; porque abeterno deu ao Filho, gerando-o, a ciência e a vontade de agir. –
Ou antes, devemos referir o mandado a Cristo, na sua natureza humana.

RESPOSTA À TERCEIRA. – Assim como a mesma essência é no Pai a paternidade, e no Filho, a filiação,
assim pelo mesmo poder o Pai gera e o Filho é gerado. Por onde é manifesto que tudo quanto pode o
Pai pode o Filho. Donde, porém não se segue que este possa gerar; mas que se muda o ponto de vista
absoluto (quid) o relativo a (ad aliquid). Pois, geração significa relação em Deus. Tem portanto o Filho o
mesmo poder que o Pai, mas com outra relação. Porque o Pai o tem como dador, e é o que se exprime
quando se diz que pode gerar; o Filho, porém, o tem como quem recebe e é o que se exprime quando se
diz que pode ser gerado.