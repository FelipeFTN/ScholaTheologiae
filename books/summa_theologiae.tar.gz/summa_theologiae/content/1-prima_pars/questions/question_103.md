# Questão 103: Do governo das coisas em comum.
Depois que se tratou da criação das coisas e da distinção delas, resta agora, em terceiro lugar, tratar do
governo das mesmas. E primeiro, em comum. Segundo, em especial; dos efeitos do governo.
Sobre a primeira questão oito artigos se discutem:

## Art. 1 — Se o mundo é governado por alguém.
O primeiro discute–se assim. – Parece que o mundo não é governado por ninguém.

1. – Pois, são governados os seres que são movidos ou operam em vista de um fim. Ora, os seres
naturais, que são a maior parte do mundo, como não conhecem o fim, não são movidos nem operam
em vista dele. Logo, o mundo não é governado.

2. Demais. – São governados os seres movidos para algum termo. Ora, o mundo, tendo em si a sua
estabilidade, não é movido para nada. Logo não é governado.

3. Demais. – O que tem em si a necessidade, pela qual é determinado a um só termo, não precisa de
governante externo. Ora, as principais partes do mundo são determinadas, nos seus atos e movimentos,
a um só termo, necessariamente. Logo, o mundo não precisa de governo.
Mas, em contrário, diz a Escritura: Tua providência ó Pai, é a que governa. E Boécio: Ó tu, que governas
o mundo com perpétua razão.

SOLUÇÃO. – Alguns filósofos antigos negaram o governo do mundo, dizendo que tudo se realiza
fortuitamente. Mas se demonstra a impossibilidade desta opinião, por duas razões. – Primeiro, pelo que
se manifesta nos próprios seres. Pois vemos que os seres naturais realizam o melhor, sempre ou na
maioria dos casos; o que não se daria se tais seres não fossem dirigidos a um fim bom, por alguma
providência, o que é governar. Por onde, a mesma ordem certa das coisas demonstra manifestamente o
governo do mundo; assim como quem entrasse numa casa bem ordenada, dessa mesma ordem
concluiria a razão do ordenador, como diz Aristóteles (Cleantes), citado por Túlio. – Em segundo lugar, o
mesmo resulta da consideração da divina bondade, da qual as coisas receberam o ser, como claramente
se conclui do que já foi dito. Pois, como ser ótimo produz efeitos ótimos, repugna à suma bondade de
Deus não levar as coisas produzidas até a perfeição. Ora, a perfeição última de um ser é a consecução
do seu fim. Por onde, à divina bondade pertence, depois de ter dado às coisas a existência, levá–las ao
fim. E isso é governar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – De dois modos um ser é movido ou opera, em vista de
um fim. De um modo, conduzindo–se a si mesmo ao fim, como o homem e as outras criaturas racionais;
e tais seres conhecem a razão do fim e dos meios a ele conducentes. De outro modo se diz que um ser
opera ou é movido para um fim, quando é por alguém conduzido ou dirigido para ele; assim, a seta, que
não conhece o fim, é movida quando dirigida para o alvo, pelo sagifário, que o conhece. Por onde, assim
como o movimento da seta para um determinado fim demonstra abertamente que ela é dirigida por
alguém dotado de conhecimento; assim, o curso certo dos seres naturais, privados de conhecimento,
declara manifestamente que o mundo é governado por uma razão.

RESPOSTA À SEGUNDA. – Em todas as coisas criadas há algo de estável. pelo menos a matéria prima; e
algo de móvel, compreendendo–se, no movimento, também a operação. E de um e outro modo, as
coisas precisam de governo; pois, isso mesmo que nas coisas é estável reduzir–se–ia ao nada, donde
vieram, se as mãos do governador não as conservassem, como a seguir se verá.

RESPOSTA À TERCEIRA. – A necessidade natural, inerente aos seres determinados a um termo, foi
impressa neles por Deus, que dirige para o fim; assim como a necessidade pela qual a seta é levada a
tender a um alvo determinado, é impressão do sagitário e não dela. Mas há diferença em que as
qualidades recebidas de Deus pelas criaturas constituem a natureza delas; ao passo que, por violência é
que o homem imprime nos seres naturais o que Ihes é estranho à natureza. Por onde, assim como a
fatalidade da violência, no movimento da seta, demonstra a direção do sagitário: assim, a necessidade
natural das criaturas demonstra o governo da providência divina.

## Art. 2 — Se o fim do governo do mundo é algo de exterior ao mesmo.
O segundo discute–se assim. Parece que o fim do governo do mundo não é nada de exterior ao
mesmo.

1. – Pois, o fim do governo de um ser é o para o que tal ser tende. Ora, aquilo para o que um ser tende é
um certo bem nele mesmo existente; assim o enfermo busca a saúde, que é um bem nele mesmo
existente. Logo, o fim do governo dos seres é um bem não extrínseco, mas existente neles próprios.

2. Demais. – O Filósofo diz: dos fins, umas são tu operações e outras, tu obras, isto é, as coisas feitas.
Ora, como a operação esta nos operantes, nada de extrínseco a todo o universo pode ser operado. Logo,
nada de extrínseco pode ser o fim do governo das coisas.

3. Demais. – O bem da multidão é a ordem e a paz, que é a tranquilidade da ordem, como diz Agostinho.
Logo, o mundo consiste numa multidão de coisas. E portanto o fim do governo do mundo é a ordem
pacífica, existente nas coisas mesmas. Por onde, o fim do governo das coisas não é nenhum bem
extrínseco.
Mas, em contrário, diz a Escritura: Tudo fez o Senhor por causa de si mesmo, Mas, Ele mesmo está fora
da ordem total do universo. Logo, o fim das coisas é algum bem extrínseco.

SOLUÇÃO. – Como o fim corresponde ao princípio, não é possível, uma vez conhecido este, ignorar–se o
fim das coisas. Ora, sendo, conforme resulta do que já foi dito, o princípio das coisas, Deus, ser
extrínseco a todo o universo, necessariamente também o fim delas há de ser algo de extrínseco. E isto
racionalmente se demonstra. Pois, é manifesto que o bem tem natureza de fim. Por onde, o fim
particular de um ser é algum bem particular; e o fim universal de todos, é algum bem universal. Ora,
universal é o bem em si e essencial, que é a essência mesma da bondade; e particular é o bem,
participativamente. E sendo manifesto que, em toda a universidade das criaturas, nenhum bem há que
não o seja participado, necessariamente há de o bem, que é fim de todo o universo, ser extrínseco à
totalidade do mesmo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – De muitos modos podemos conseguir um bem: de um
modo, como forma existente em nós, e assim a saúde ou a ciência; de outro, como algo operado por
nós, e assim o edificador consegue o fim fazendo a casa. De outro, como um bem adquirido ou
possuído, e assim quem comprou consegue o fim, possuindo o campo. Por onde, nada impede seja
aquilo, a que é levado o universo, um bem extrínseco.

RESPOSTA À SEGUNDA. – O Filósofo se refere aos fins das artes, das quais umas tem como fim, as
próprias operações. sendo assim o fim do citarista tocar citara : ao passo que outras tem, como fim uma
cousa feita, sendo assim o fim do edificador, não edificar, mas a casa. Ora, dá–se, que o extrínseco pode
ser fim, não só como operado, mas também como possuído e como adquirido, ou ainda, como
representado; assim, se dissermos que Hércules é o fim da imagem feita para representá–lo. Por onde,
pode–se dizer que o bem extrínseco a todo o universo é fim do governo dos seres; como adquirido e
como representado; porque todos eles tendem a participar dele, e a assimilá–lo o mais possível.

RESPOSTA À TERCEIRA. – Há um fim do universo que é um bem nele mesmo existente e esse fim é a
ordem do dito universo. Porém tal bem não é o último fim, mas se ordena ao bem extrínseco como ao
fim último; assim como também a ordem de um exército se ordena ao chefe, como diz Aristóteles.

## Art. 3 — Se o mundo tem um só governador.
O terceiro discute–se assim. – Parece que o mundo não tem um só governador.

1. – Pois, julgamos da causa pelo efeito. Ora, o governo dos seres manifesta que eles não são
uniformemente governados e nem operam uniformemente; porque, certos fenômenos são
contingentes, certos, necessários, e outros, ainda, tem modalidades diversas. Logo, o mundo não tem
um só governador.

2. Demais. – Seres submetidos a um só governador não dissentem entre si, a não ser por imperícia,
insipiência ou impotência do governador; o que não se pode supor em Deus. Ora, os seres criados
dissentem entre si, entre si se combatem, como se vê nos contrários. Logo, o mundo não tem um só
governador.

3. Demais. – A natureza sempre tende para o melhor. Ora, como diz a Escritura, melhor é pois estarem
dois juntos do que alar um só. Logo, o mundo não é governado por um só governador, mas por vários.
Mas, em contrário, confessamos existir um só Deus e um só Senhor, conforme aquilo da Escritura: Para
nós, há um só Deus, o Pai e só um Senhor. Ora, ambos dizem respeito ao governo: pois, ao senhor
pertence o governo dos súbditos: e o nome de Deus é derivado da providência, como já se disse antes.
Logo, o mundo tem um só governador.

SOLUÇÃO. – Necessário é admitir–se que o mundo tem um só governador. Pois, como o fim do governo
do mundo é o essencialmente bom, que é óptimo, necessário é seja óptimo o governo do mundo. Ora,
óptimo é o governo de um só. E á razão é que o governo não é senão a direção dos governados para um
fim, que é um certo bem. Ora, a unidade se implica em a noção da bondade, como o prova Boécio; pois,
como todas as coisas desejam o bem, desejam ao mesmo tempo a unidade, sem a qual não podem
existir, porquanto, um ser existe na medida em que é uno. E por isso vemos que as coisas
soberanamente repugnam à divisão, e que a dissolução de um ser provém de alguma deficiência sua.
Por onde, aquilo para o que tende a intenção de quem governa a multidão é a unidade ou a paz. Ora, a
causa da unidade, é o ser uno em si; sendo manifesto que diversos não podem unir e fazer
concordarem, coisas múltiplas, a não ser que eles próprios se unam de algum modo. Ao passo que o ser
uno, em si, pode ser causa da unidade mais convenientemente que muitos unidos; e por isso, a multidão
é melhor governada por um só do que por vários. E conclui–se, portanto, que o governo do mundo,
governo ótimo, provém de um só governador. E é isto mesmo que o Filósofo ensina: os entes não
querem ter mal dispostos; nem é boa a pluralidade dos principados ; haja, pois, um só príncipe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O movimento é o ato do móvel, proveniente do motor.
Donde, a não uniformidade dos movimentos procede da diversidade dos móveis, exigida pela perfeição
do universo, como se disse antes, e não pela pluralidade dos governadores.

RESPOSTA À SEGUNDA. – Embora os contrários dissintam quanto aos fins próximos, convêm, contudo,
quanto ao fim último, enquanto compreendidos numa mesma ordem do universo.

RESPOSTA À TERCEIRA. – Nos bens particulares, dois são melhores que um só; mas ao bem essencial
nenhuma adição de bondade pode ser feita.

## Art. 4 — Se o efeito do governo do mundo é um só e não vários.
O quarto discute–se assim. – Parece que o efeito do governo do mundo é um só e não vários.

1. – Pois, efeito do governo é o causado pelo mesmo, nas coisas governadas. Ora este é um só a saber, o
bem da ordem, como claramente se vê num exército. Logo é um só o efeito do governo do mundo.

2. Demais. – É natural que de um ser proceda só um outro. Ora, o mundo tem um só governador, como
já se demonstrou. Logo, também é um só o efeito do governo.
3 . Demais. – Se o efeito do governo não fosse um só, por causa da unidade do governador, então devia
necessariamente ser multiplicado relativamente à multiplicidade dos seres governados. Ora, estes são
para nós inumeráveis. Logo, os efeitos do governo não podem ser compreendidos num determinado
número.
Mas, em contrário, diz Dionísio, que a Divindade com providência e bondade perfeita contém todas as
causas, e as completa a todas em si mesma. Ora, o governo se inclui na providência. Logo, são alguns,
determinados, os efeitos do governo divino.

SOLUÇÃO. – Devemos considerar o efeito de qualquer ação relativamente ao fim desta; pois, da
operação resulta a consecução do fim. Ora, o fim do governo do mundo é o bem com o qual tendem
todas as coisas. Por onde, em tríplice acepção pode–se tomar o efeito do governo, – Primeiro,
relativamente ao fim, em si mesmo; e, então, o governo só tem um efeito, que é assimilar–se ao Sumo
Bem. Segundo, pode–se considerar o efeito do governo relativamente ao que leva a criatura à
assimilação com Deus. E então, em geral, tem o governo dois efeitos, porque, quanto a duas coisas a
criatura se assimila com Deus, a saber: quanto a ser Deus bom, e a criatura, boa; e quanto a ser Deus a
causa da bondade dos outros seres, e uma criatura mover a outra para a bondade. Por onde, dois são os
efeitos do governo: a conservação das coisas no bem, e a moção delas para o bem. – Terceiro, o efeito
do governo pode ser considerado em particular e, então são para nós inúmeros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A ordem do universo inclui em si tanto a conservação das
diversas coisas instituídas por Deus, como a moção delas; pois, segundo esta doutrina, dupla ordem se
encontra nas coisas, por ser uma cousa melhor que outra, e uma movida por outra.

RESPOSTAS ÀS OUTRAS DUAS. – Deduzemse claras, do que acaba de ser dito.

## Art. 5 — Se todos os seres estão sujeitos ao governo divino.
O quinto discute–se assim. – Parece que nem todos os seres estejam sujeitos ao governo divino.

1. – Pois, diz a Escritura: Vi que debaixo do sol não é o prêmio para os que melhor correm, nem a guerra,
para os que são mais fortes, nem o pão para os que são mais sábios, nem as riquezas para os que são
mais doutos, nem a boa aceitação para os que são mais hábeis artífices; mas que tudo se faz por
encontro e por casualidade. Ora, seres submetidos a um governo não são casuais. Logo, o que está
debaixo do sol não está sujeito ao governo divino.

2. Demais. – A Escritura diz: Acaso tem Deus, cuidado dos bois? Ora, cada qual cuida do que lhe está
submetido ao governo. Logo, nem todos os seres estão sujeitos ao governo divino.

3. Demais. – Quem pode se governar a si mesmo não precisa do governo de outrem. Ora, a criatura
racional pode se governar a si mesma, pois, tem o domínio dos seus atos, age por si; e não é levada por
outrem, somente, o que é próprio de coisas governadas. Logo, nem todos os seres estão sujeitos ao
governo divino.
Mas, em contrário, diz Agostinho: Deus não abandonou o céu e a terra, o anjo e o homem, e nem ainda
a estrutura interna de qualquer ser animado, por pequeno e desprezível que seja, nem a penazinha da
ave, nem a florzinha da erva, nem a folha da árvore, sem a das suas partes, Logo, todos os sujeitos ao
seu governo:

SOLUÇÃO. – Pela mesma razão Deus é governador e causa dos seres; pois a Ele pertence produzi–los e
dar–lhes a perfeição, o que tudo é próprio de quem governa. Ora, Deus é, não a causa particular de um
gênero de seres, mas a universal, da totalidade dos seres, como já se demonstrou. Por onde, assim
como nada pode existir sem ser criado por Deus, assim também nada há que lhe possa escapar ao
governo. – E isto mesmo também se deduz claramente da noção do fim. Pois, o governo de alguém se
estende até onde pode alcançar o fim desse governo, Ora, o fim do governo divino é a bondade mesma
de Deus, como antes se demonstrou. Por onde, como nada pode haver que se não ordene à bondade
divina, como fim, segundo do sobredito se colhe, impossível é a qualquer ser subtrair–se ao governo
divino. – Logo, estulta é a opinião dos que dizem que os seres inferiores corruptíveis deste mundo, ou
mesmo ser em particular, ou ainda as coisas humanas, não são governados por Deus. E em nome desses
diz a Escritura: O Senhor deixou a terra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Diz–se que estão debaixo do sol as coisas geradas e
corrompidas pelo movimento do mesmo. E em todas elas se encontra o acaso; não que seja casual tudo
quanto nelas se faz, mas porque em cada uma delas pode–se encontrar algo de casual. E isto mesmo
demonstra que elas estão sujeitas ao governo divino. Pois, se tais seres corruptíveis não fossem
governados por um superior, sobretudo, os que não tem conhecimento não tenderiam para nada; e,
então, não poderia existir neles nada contrário à intenção, sendo esta contrariedade o que constitui a
essência do acaso. Por onde, para significar que o casual realiza–se conforme à ordem de uma causa
superior, na Escritura não se diz simplesmente que se viu o acaso em todas as coisas, mas se diz tempo e
casualidade porque segundo certa ordem do tempo, encontram–se nas coisas deste mundo defeitos
casuais.

RESPOSTA À SEGUNDA. – O governo é uma mutação das coisas governadas, proveniente do
governador. Ora, todo movimento é um ato do móvel, proveniente do motor, como diz Aristóteles. Ora,
como todo ato é proporcionado ao ser do qual resulta, necessário é que móveis diversos sejam movidos
diversamente, mesmo relativamente ao movimento de um só motor. Assim pois, por um só modo do
governo de Deus as coisas são governadas diversamente, conforme a diversidade delas. E então, certas,
tendo domínio sobre os seus atos, agem, por natureza, por si mesmas; e estas são governadas por Deus,
não só por serem movidas por Ele, que nelas opera interiormente, mas ainda porque Ele as induz ao
bem e retrai do mal por meio de preceitos e proibições, prêmios e penas. Ao passo que desse modo não
são governadas por Deus as criaturas irracionais, que são levadas a agir, somente, e não agem. Assim,
pois quando o Apóstolo diz, que Deus não cura dos bois, não os subtrai totalmente ao cuidado do
governo divino; mas só quanto ao modo que convém propriamente à criatura racional.

RESPOSTA À TERCEIRA. – A criatura racional governa–se a si mesma pelo intelecto e pela vontade; e
ambas essas faculdades necessitam ser governadas e completadas pelo intelecto e pela vontade de
Deus. E portanto, além do governo pelo qual a criatura racional se governa a si mesma, como senhora
dos seus atos, necessita ela ser governada por Deus.

## Art. 6 — Se todas as coisas são imediatamente governadas por Deus.
O sexto discute–se assim. – Parece que todas as coisas são governadas imediatamente por Deus.

1. – Pois, Gregório Nisseno ataca a opinião de Platão, que admitia três sortes de providência: a primeira,
a do primeiro Deus que provê aos corpos celestes e a todos os seres do universo; a segunda, a dos
deuses secundários, que percorrem o céu e provêm às coisas sujeitas à geração e à corrupção: e a
terceira, enfim, a de certos demônios, guardas na terra, das ações humanas. Logo, resulta que todas as
coisas são governadas imediatamente por Deus.

2. Demais. – Sendo possível, melhor é fazer–se uma cousa por um só que por muitos, como diz
Aristóteles. Ora, Deus pode, por si mesmo, sem causas intermediárias, governar todas as causas. Logo,
conclui–se que as governa a todas imediatamente.

3. Demais. – Em Deus nada há de deficiente e imperfeito. Ora, é um defeito do governador governar
mediante outros; assim um rei terreno, não podendo fazer tudo, nem estar presente em todas as partes
do reino, necessita ter, ministros, para o seu governo. Logo, Deus governa todas as coisas
imediatamente.
Mas, em contrário, diz Agostinho: Assim como os corpos mais crassos e inferiores são regidos, numa
certa ordem, pelos mais subtis e potentes, assim, todos os corpos, pelo espírito racional da vida; e o
espírito desertado da vida racional e pecador, pelo espírito da vida racional pio e justo; e esse, pelo
próprio Deus.

SOLUÇÃO. – Dois elementos se devem considerar, no governo: o plano do governo, que é a providência
mesma, e a execução. Quanto àquela, Deus governa imediatamente todas as coisas; quanto à esta,
governa certos seres mediante outros. – E a razão é que, sendo Deus a essência mesma da bondade,
deve–se–lhe atribuir tudo o que for ótimo. Ora, é ótimo em qualquer gênero, noção ou conhecimento
prático – e tal é o governo por essência que sejam conhecidas as particularidades, em que consistem os
atos. Assim, é ótimo o médico que não só conhece as coisas em universal, mas também pode conhecer
as menores particularidades; e o mesmo se dá em outras condições. Por onde, deve–se dizer que Deus
governa, essencialmente, todas as coisas, ainda nas mínimas particularidades. Mas como as coisas
governadas devem pelo governo ser levadas à perfeição, tanto melhor será ele, quanto maior for a
perfeição comunicada pelo governador às coisas governadas. Ora, maior perfeição é que um ser, além
de ser bom em si mesmo, seja também para os outro; causa de bondade, do que ser somente bom em si
mesmo. E portanto, Deus governa as coisas de modo a fazer de umas as causas das outras, quanto ao
governo; como se um mestre não só comunicasse a ciência aos seus discípulos, mas ainda os fizesse
mestres de outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A opinião de Platão é atacada porque, mesmo quanto à
essência do governo, admitia que Deus não governa imediatamente todas as coisas; o que bem se vê
por ter tripartido a providência, que é da essência do governo.

RESPOSTA À SEGUNDA. – Se Deus governasse só, seriam as coisas privadas da perfeição causal. Por
onde não seria melhor fazer–se por um só o que é feito por muitos.

RESPOSTA À TERCEIRA. – Não só por imperfeição é que um rei terreno tem executores do seu governo,
mas ainda por dignidade; pois, pela ordem dos ministros o poder real se torna mais excelente.

## Art. 7 — Se podem acontecer coisas fora da ordem do governo divino.
O sétimo discute–se assim. Parece que podem acontecer coisas fora da ordem do governo divino.

1. – Pois, como diz Boécio, Deus dispõe tudo por meio do bem. Se portanto, nas coisas, nada
acontecesse fora da ordem do governo divino, resultaria que nada nelas seria mau.

2. Demais. – Não é casual o que se realiza segundo a preordenação do governador. Se pois, nada
acontece, nas coisas, fora da ordem do governo divino, resulta que, nelas, nada há de fortuito e casual.

3. Demais. – A ordem do governo divino é certa e imutável, porque se funda na razão eterna. Se pois,
nas coisas, nada pode acontecer fora da ordem desse governo, resulta que tudo se realiza
necessariamente e nada há, nelas, contingente, o que é inadmissível. Logo, podem–se dar coisas fora da
ordem do governo divino.
Mas, em contrário, diz a Escritura: Senhor, Senhor Rei Onipotente, porque no teu poder estão postas
todas as coisas, e não há quem possa resistir à tua vontade.

SOLUÇÃO. – Pode um efeito resultar fora da ordem de uma causa particular; não, porém, fora da causa
universal. E a razão é que, só por impedimento de alguma outra causa é que pode se dar alguma cousa
fora da ordem de uma causa particular; e essa causa impediente há de necessariamente reduzir–se à
causa primeira universal. Assim, uma indigestão se dá, fora da ordem da virtude nutritiva, por algum
impedimento, por exemplo, de alimentos pesados, que hão de reduzir–se, necessariamente, a alguma
outra causa, e assim até à causa primeira universal. Ora, como Deus é a causa primeira universal, não só
de um gênero, mas da totalidade dos seres, é impossível que alguma cousa aconteça, fora da ordem do
governo divino. Por onde, qualquer cousa que escape, de um lado, à ordem da divina providência,
considerada essa ordem em relação a alguma causa particular, necessariamente há de entrar na
sobredita ordem, por outra causa,

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Nada há no mundo que seja totalmente mau, porque o
mal sempre se funda no bem, como antes se demonstrou. Por onde, diz–se má a cousa que escapa à
ordem de algum bem particular. Se pois escapasse, totalmente à ordem do governo divino, reduzir–se–
ia totalmente ao nada.

RESPOSTA À SEGUNDA. – Chama–se casual, nas coisas, aquilo que escapa à ordem das causas
particulares; mas, em relação à divina providência, nenhum acaso há no mundo, como diz Agostinho.

RESPOSTA À TERCEIRA. – Alguns efeitos se chamam contingentes por comparação às causas próximas
que, nos seus efeitos, podem ser deficientes. E não porque alguma cousa possa realizar–se escapando à
ordem total do governo divino, porque o fato mesmo de alguma cousa se dar fora da ordem da causa
próxima é em virtude de alguma causa sujeita ao governo divino.

## Art. 8 — Se pode haver alguma resistência à ordem do governo divino.
O oitavo discute–se assim. – Parece que alguma resistência pode haver à ordem do governo divino.

1. – Pois, a Escritura diz: a língua deles e as invenções da sua fantasia são contra o Senhor.

2. Demais. – Nenhum rei justo pune os que não lhe resistem às ordens. Se pois, nada se opusesse à
ordem divina, ninguém seria punido justamente por Deus.

3. Demais. – Cada ser está sujeito à ordem do governo divino. Ora, há seres opostos a outros. Logo, há
coisas que contrariam à ordem divina.
Mas, em contrário, diz Boécio: nada há que queira ou possa opor–se a este Sumo Bem. É pois o Sumo
Bem. que rege firmemente todas as causas e as dispõe suavemente, como diz a Escritura falando da
divina sapiência.

SOLUÇÃO. – De duplo modo podemos considerar a ordem da divina providência: em geral, enquanto
resultante da causa governadora de tudo; e em especial, enquanto resultante de uma causa particular,
executiva do governo divino. – Ora, do primeiro modo, nada se opõe à ordem do governo divino, o que
se evidencia por duas razões. A primeira é que a ordem desse governo tende totalmente para o bem; e
cada cousa, na sua operação e no seu impulso, não tende senão para o bem; pois, ninguém opera o mal
refletidamente, como diz Dionísio. A segunda resulta clara de que, como já se disse antes, toda
inclinação natural ou voluntária de um ser não é mais do que uma impressão do primeiro motor, assim
como a inclinação da seta para o alvo determinado não é mais do que uma impressão do sagitário. Por
onde todos os seres que agem, natural ou voluntariamente, chegam como espontaneamente ao fim
para que foram ordenados divinamente. Por onde se diz que Deus dispõe de tudo suavemente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Diz–se que alguns pensam, falam ou agem contra Deus,
não porque totalmente resistam à ordem do governo divino, pois mesmo os pecadores buscam algum
bem; mas porque se opõem a algum determinado bem que lhes é conveniente pela sua natureza ou
estado. E por isso são justamente punidos por Deus.
E daqui se deduz clara a RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. – O fato de uma cousa se opor a outra mostra que um ser pode resistir à uma
ordem procedente de alguma causa particular; não porém à ordem dependente da causa universal
total.