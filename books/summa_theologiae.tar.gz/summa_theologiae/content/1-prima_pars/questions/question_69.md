# Questão 69: Da obra do terceiro dia.
Em seguida, devemos considerar a obra do terceiro dia. E, nesta questão, dois artigos se discutem:

## Art. 1 — Se com propriedade se diz que a congregação das águas foi feita no terceiro dia.
O primeiro discute-se assim. — Parece que não se diz com propriedade que a congregação das águas
foi feita no terceiro dia.

1. — Pois, a palavra faça-se exprime as coisas feitas no primeiro e no segundo dia. Assim, está
escrito: Disse Deus, faça-se a luz; e disse também: faça-se o firmamento. Ora, o terceiro dia entra na
mesma divisão que a dos outros dois. Logo, a obra desse dia devia ser expressa pela palavra faça-se e
não somente pela palavracongreguem-se.

2. Demais. — Primitivamente, a terra estava coberta de águas por toda parte, sendo por isso dita
invisível. Portanto, não havia nenhum lugar, sobre a terra, em que as águas pudessem congregar-se

3. Demais. — Coisas sem mútua continuidade não ocupam o mesmo lugar. Ora, nem todas as águas têm
mútua continuidade. Logo, nem todas foram congregadas no mesmo lugar.

4. Demais. — A congregação é própria do movimento local. Ora, as águas são naturalmente fluentes e
correm adunadas. Logo, para tal não era necessário recorrer-se a um preceito divino.

5. Demais. — A terra também aparece denominada no princípio da sua criação, quando se diz: No
princípio criou Deus o céu e a terra. Logo, é impróprio dizer-se que o nome de terra foi imposto no
terceiro dia.
Mas, em contrário, basta a autoridade da Escritura.

SOLUÇÃO. — Neste assunto devemos sentir diferentemente, conforme a exposição de Agostinho ou dos
outros Santos Padres. Agostinho, em todas as suas obras, não fala em ordem de duração, mas só na de
origem e natureza. Assim diz que em primeiro lugar foi criada a natureza espiritual informe e a natureza
corpórea sem nenhuma forma, designada esta primeiramente pelos nomes de terra e água; não que
essa informidade precedesse temporalmente à formação, senão só quanto à origem. Nem, na sua
opinião, uma formação precedeu à outra, na duração, mas só na ordem da natureza. E segundo esta
ordem era necessário que, primeiro, se colocasse a formação da natureza suprema, i. é, a espiritual;
lendo-se, por isso, que, no primeiro dia foi feita a luz. Mas, assim como a natureza espiritual tem
preeminência sobre a corporal, assim também têm preeminência os corpos superiores sobre os
inferiores. Por onde, em segundo lugar, toca na formação dos corpos superiores, quando se diz: Faça-se
o firmamento; pelo que se entende a impressão da forma celeste na matéria informe, no princípio ainda
não existente, no tempo, mas só em origem. Por fim, em terceiro lugar, a impressão das formas
elementais da matéria informe, precedente, não temporal, mas originalmente. Por onde, pelo dito as
águas ajuntem-se num só lugar, e apareça o elemento árido, entende-se que na matéria corporal foi
impressa a forma substancial da água, pela qual lhe compete à mesma um determinado movimento; e a
forma substancial da terra, pela qual esta aparece com determinado aspecto.
Porém os outros Santos Padres, como nessas obras também se atende à ordem da duração, ensinam
que a informidade da matéria precedeu, no tempo, à formação; e uma forma, à outra. Mas, dizem, pela
informidade da matéria não se entende a carência de toda forma, porque já existia o céu, a água e a
terra, três denominações de seres manifestamente perceptíveis pelos sentidos; mas a carência da
distinção devida e de uma certa beleza consumada. E por três nomes introduziu a Escritura três
informidades. Ao céu, que está na parte superior e é a origem da luz, respeita a informidade das trevas.
Ao passo que a informidade da água, que é média, é expressa pelo nome de abismo, significativo de
uma certa imensidade desordenada de águas, como diz Agostinho. E por fim alude-se à terra quando se
diz que a terra estava informe, ou invisível, por estar coberta de águas. Assim, pois, a formação do corpo
supremo foi feita no primeiro dia; e como o tempo, resultante do movimento do céu, é o número do
movimento desse corpo, fez-se, por essa formação, a distinção do tempo, i. é, da noite e do dia. Porém,
no segundo dia, foi formado o corpo médio, i. é, a água que recebeu pelo firmamento uma certa
distinção e ordem, de modo que o nome de água compreende também outras coisas, como antes se
disse. Enfim, no terceiro dia foi formado o último corpo, i. é, a terra, por ter sido descoberta das águas, e
fez-se a distinção no ínfimo lugar, entre a terra e o mar. Por onde, assim como, com bastante
congruência, exprimiu-se a informidade da terra, dizendo que a terra era invisível, ou informe, assim a
sua formação foi expressa pelo dito:E o elemento árido apareça.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Segundo Agostinho, na obra do terceiro dia, a Escritura
não usa da palavra faça-se, como nas obras precedentes, para mostrar que as formas superiores, i. é, as
espirituais, dos anjos e dos corpos celestes, são perfeitas no ser e estáveis; ao passo que as formas
inferiores são imperfeitas e móveis. Por onde, a congregação das águas e a aparição do árido designam
a impressão de tais formas: pois a água tem fluxo corredio e a terra está fixa estavelmente, como diz o
mesmo. Porém, segundo os outros, devemos dizer que na obra do terceiro dia, completando-se
somente quanto ao movimento local, não era necessário que a Escritura usasse da palavra faça-se.

RESPOSTA À SEGUNDA. — Para Agostinho é clara a SOLUÇÃO.: não se deve dizer que a terra estava,
primeiro, coberta de águas e que, depois, estas se congregaram; mas sim que foram feitas já
congregadas. — Segundo os outros, porém, de três modos se responde, como diz Agostinho. De um,
dizendo-se que no lugar onde se congregaram, se elevaram a maior altitude; pois, que o mar é mais alto
que a terra, a experiência, no Mar Vermelho, o prova, como diz Basílio. De outro modo, dizendo-se
que a água mais rarefeita, como nuvem, que cobria as terras, densificou-se pela congregação. De um
terceiro, dizendo-se que a terra podia oferecer algumas partes côncavas, onde as águas, refluindo,
fossem recebidas. Dentre essas opiniões a primeira parece mais provável.

RESPOSTA À TERCEIRA. — Todas as águas têm um termo, i. é, o mar, ao qual confluem, por meatos
manifestos ou ocultos; e por isso se diz que as águas se congregam em um lugar. — Ou esse único lugar
é assim chamado, não absolutamente, mas por comparação com o lugar da terra dessecada, sendo
então o sentido: As águas ajuntem-se num só lugar, i. é, separadas da terra árida. Pois, para designar a
pluralidade dos lugares da água, acrescenta: ao caminho das águas chamou mares.

RESPOSTA À QUARTA. — A ordem de Deus constitui os corpos no seu movimento natural; por onde, se
diz que eles executam, pelos seus movimentos naturais, esse verbo. — Ou se pode dizer que era natural
cercasse a água à terra, por todos os lados, como o ar cerca, por todos os lados, a água e a terra; mas,
por necessidade de fim, i. é, para existirem animais e plantas sobe a terra foi necessário que alguma
parte dela ficasse a descoberto das águas. O que alguns filósofos atribuem à ação do sol, dessecando a
terra pela elevação dos vapores. Mas a Sagrada Escritura o atribui ao poder divino, não só no Gênesis,
mas também em Jó, onde se diz da pessoa do Senhor: Encerrei o mar nos limites que lhe prescrevi; e
Jeremias: não me temereis a mim, diz o Senhor..., que pus a areia por limite ao mar?.

RESPOSTA À QUINTA. — Segundo Agostinho, pela terra, da qual primeiro se fez menção, entende-se a
matéria prima; agora, porém, se entende o elemento mesmo da terra. — Ou, se pode dizer, segundo
Basílio, que, primeiro, era a terra assim denominada, quanto à sua natureza, agora porém, o é quanto à
sua principal propriedade, que é secura. Por onde se diz que chamou ao elemento árido terra. — Ou se
pode dizer, conforme Rabbi Moisés, que a expressão chamou, onde quer que apareça, significa a
equivocação do nome. Por onde, primeiro se disse que chamou à luz dia, porque também se chama dia
ao espaço de vinte e quatro horas, conforme o que no mesmo lugar se diz: E da tarde e da manhã se fez
o dia primeiro. Semelhantemente, deve-se dizer que o firmamento, i. é, o ar chamou céu, porque
também se chama céu ao que foi criado em primeiro lugar. E ainda, semelhantemente, aí se dizárido, i.
é, a parte descoberta das águas, chamou terra, para que esta se distinga do mar; embora seja chamada
pelo nome comum de terra, quer esteja coberta quer descoberta das águas. E, em todos os passos, o
dito chamou significa deu uma natureza ou propriedade para poder se assim chamado.

## Art. 2 — Se se lê com conveniência que a produção das plantas foi feita no terceiro dia.
O segundo discute-se assim. – Parece que não se lê com conveniência que a produção das plantas foi
feita no terceiro dia.

1. – Pois as plantas, como os animais, têm vida. Ora, a produção dos animais não se coloca entre as
obras da distinção, mas pertence à obra do ornato. Logo, nem a produção das plantas devia se
comemorar no terceiro dia, que pertence à obra da distinção.

2. Demais. – O que implica a maldição da terra não devia ser comemorado com a formação da mesma.
Ora, a produção de certas plantas implica a maldição da terra, segundo a Escritura (Gn 3, 17-18): A terra
será maldita na tua obra... ela te produzirá espinhos e abrolhos. Logo, não devia, universalmente, ser
comemorada no terceiro dia, que é o da formação da terra.

3. Demais. – Como as plantas, também as pedras e os minerais aderem à terra; e todavia deles não se
faz menção, na formação desta. Logo, nem as plantas deviam ter sido feitas no terceiro dia.
Mas, em contrário, diz a Escritura (Gn 1, 12): E produziu a terra erva verde; e, em seguida, se
acrescenta: E da tarde e da manhã se fez o dia terceiro.

SOLUÇÃO. – Como antes se disse, no terceiro dia foi removida a informidade da terra. Ora, descreve-se-
lhe uma dupla informidade: uma, porque a terra era invisível, ou informe, por estar coberta das águas; a
outra, porque estava desordenada, ou vazia, i. é, sem o devido decoro, adveniente das plantas que de
certo modo a vestem. Assim, uma e outra informidade se lhe removeu nesse terceiro dia; a primeira,
porque as águas, ajuntem-se num só lugar, e apareça o elemento árido; a segunda, porque a terra
produziu erva verde.
Contudo, sobre a produção das plantas, Agostinho opina diferentemente dos outros expositores. Estes
dizem, que as plantas foram produzidas, no terceiro dia, com as suas espécies atuais, conforme o
sentido superficial do texto. Porém, opina Agostinho, diz-se que, então, a terra produziu a erva e as
árvores, casualmente, i. é, recebeu a virtude de produzir. E ele o confirma com a autoridade da
Escritura, dizendo (Gn 2, 4-5): Tal foi a origem do céu e da terra, quando foram criados, no dia em que o
Senhor Deus fez o céu e a terra e toda a planta do campo antes que nascesse na terra e toda a erva da
campina antes que germinasse. Logo, antes de nascerem na terra, nela se fizeram como na sua causa. E
isto também se confirma pela razão. Porque, naqueles primeiros dias, Deus criou a criatura, originária
ou causalmente; e descansou em seguida, porque desde então até agora ele opera, no governo das
coisas criadas, pela obra da propagação. Ora, produzir da terra, as plantas, pertence à essa obra. Por
onde, no terceiro dia, não foram produzidas as plantas atual, senão causalmente.
Embora, segundo outros, possa-se dizer, que a primeira instituição das espécies pertence às obras dos
seis dias. Mas, o proceder, das espécies primeiro instituídas, a geração de seres especificamente
semelhantes, já isso pertence ao governo das coisas. E é o que diz a Escritura: Antes que nascesse na
terra, ou antes que germinasse, i. é, antes que os semelhantes fossem produzidos dos semelhantes,
como vemos agora realizar-se naturalmente, por via de seminação. Donde o dizer a Escritura
sinaladamente: Produza a terra erva verde, e que dê semente; pois, foram produzidas espécies perfeitas
de plantas, das quais nasceriam as sementes de outras. Nem importa onde tenham a força seminal, se
na raiz, no tronco ou no fruto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A vida, nas plantas, é oculta, pois carecem do movimento
local e dos sentidos, que distinguem, por excelência, o animado do inanimado. Por isso as plantas,
aderindo imovelmente à terra, considera-se-lhe a produção uma como formação da terra.

RESPOSTA À SEGUNDA. – Mesmo antes dessa maldição, os espinhos e os abrolhos foram produzidos,
virtual ou atualmente, embora não o fossem para pena do homem; como se, p. ex., a terra, cultivada
para dar-lhe alimento, germinasse em certas plantas infrutíferas e nocivas; por isso foi dito: Ela te
produzirá.

RESPOSTA À TERCEIRA. – Moisés só propôs aquelas coisas que manifestamente aparecem, como já se
disse (q. 67, a. 4). Ora, os corpos minerais têm a geração oculta nas vísceras da terra; e, demais, desta
não têm distinção manifesta, sendo, antes, considerados como espécies de terra. E por isso, não fez
menção deles.