# Questão 86: Do que o nosso intelecto conhece nas coisas materiais.
Em seguida deve-se tratar do que o nosso intelecto conhece nas coisas materiais.
E, sobre este ponto, quatro artigos se discutem:

## Art. 1 — Se o nosso intelecto conhece o singular.
(II Sent., dist. III, q. 3, a. 3, ad 1; IV, dist. L, q. 1, a. 3; I Cont. Gent., cap. LXV; De Verit., q. 2, a. 5, 6; q. 10,
a. 5; Qu. De Anima, a. 20; Quodl, VII, q. 1, a. 3; XII, q. 8; Opusc. XXIX, De Princip. Individ.: III De Anima
Lect. VIII).
O primeiro discute-se assim. ― Parece que o intelecto conhece o singular.

1. ― Pois, quem conhece a composição conhece-lhe os extremos. Ora, o nosso intelecto conhece esta
composição ― Sócrates é homem ― porque é capaz de formar uma proposição. Logo, o nosso intelecto
conhece Sócrates como singular.

2. Demais. ― O intelecto prático dirige para a ação. Ora, os atos se referem ao singular. Logo o intelecto
o conhece.

3. Demais. ― O nosso intelecto se intelige a si mesmo. Ora, ele, em si mesmo, é um singular; do
contrário não exerceria nenhum ato, pois os atos são próprios só do singular. Logo, este é conhecido
pelo nosso intelecto.

4. Demais. ― Tudo o que pode a virtude inferior pode a superior. Ora, o sentido conhece o singular.
Logo, com maioria de razão, o intelecto.
Mas, em contrário, diz o Filósofo: o universal é conhecido pela razão e o singular, pelo sentido.

SOLUÇÃO. ― O nosso intelecto não pode conhecer o singular, nas coisas materiais, direta e
primariamente. E isso porque o princípio da singularidade delas é a matéria individual. Ora, o nosso
intelecto, como já se disse antes (q. 85, a. 1), intelige abstraindo a espécie inteligível, de tal matéria; e
isso que ele abstrai é universal. Por onde, o nosso intelecto não conhece diretamente senão o universal.
― Porém, indiretamente e por uma como reflexão, pode conhecer o singular. Pois, como já se disse (q.
84, a. 7), mesmo depois de haver abstraído as espécies inteligíveis, não pode, por ela, inteligir em ato,
senão voltando-se para os fantasmas, nos quais intelige as espécies inteligíveis, como diz Aristóteles.
Assim, pois, intelige diretamente o universal em si, pela espécie inteligível; indiretamente, porém, o
singular, do qual são os fantasmas. E, assim, forma a proposição ― Sócrates é homem.
Donde é clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. ― A eleição do particular operável é uma como conclusão de um silogismo do
intelecto prático, como diz Aristóteles. Pois, de uma proposição universal não se pode concluir
diretamente o singular, senão mediante o aceite de alguma proposição particular. Por onde, a razão
universal do intelecto prático não move senão mediante uma apreensão particular da parte sensitiva,
como diz Aristóteles.

RESPOSTA À TERCEIRA. ― Não repugna seja inteligido o singular como tal, senão só enquanto material;
pois, só imaterialmente é que uma coisa pode ser inteligida. Por onde, não repugna seja inteligido o que
é singular e imaterial, como o intelecto.

RESPOSTA À QUARTA. ― A virtude superior pode tanto como a inferior, mas de modo mais eminente.
Por onde, aquilo de que o sentido tem conhecimento, material e concretamente, i. é., do singular,
diretamente, isso mesmo o intelecto conhece imaterial e abstratamente, o que é conhecer o universal.

## Art. 2 — Se o nosso intelecto pode conhecer o infinito.
(De Verit., q. 2, art. 9; Compend. Theol., cap. CXXXIII).
O segundo discute-se assim. ― Parece que o nosso intelecto pode conhecer infinitas coisas.

1. ― Pois, Deus excede toda a infinidade de todos os seres. Ora, o nosso intelecto pode conhecê-lo,
como já se disse (q. 12). Logo, com maior razão, pode conhecer infinitas outras coisas.

2. Demais. ― É natural ao nosso intelecto conhecer os gêneros e as espécies. Mas, de certos gêneros
são infinitas as espécies, como os números, as proposições e as figuras. Logo, o nosso intelecto pode
conhecer infinitas coisas.

3. Demais. ― Se um corpo não impedisse outro de existir num mesmo lugar, nada impediria existirem
infinitos corpos num mesmo lugar. Ora, uma espécie inteligível não impede outra de existir
simultaneamente no mesmo intelecto, pois, é possível saberem-se muitas coisas habitualmente. Logo,
nada impede que o nosso intelecto tenha, habitualmente, ciência de infinitas coisas.

4. Demais. ― O intelecto, não sendo virtude da matéria corpórea, como já se viu (q. 76, a. 1), é potência
infinita. Ora, uma virtude infinita pode se referir ao infinito. Logo, o nosso intelecto pode conhecer
infinitas coisas.
Mas, em contrário, diz Aristóteles: o infinito, como tal é desconhecido.

SOLUÇÃO. ― Sendo a potência proporcionada ao seu objeto, necessário é que o intelecto esteja para o
infinito, na mesma relação em que está o seu objeto, que é a qüididade da coisa material. Ora, nas
coisas materiais, não há infinito atual, mas só potencial, enquanto que uma coisa sucede à outra, como
diz Aristóteles. Por onde, em o nosso intelecto há o infinito potencial, enquanto ele apreende uma coisa
depois de outra; pois, o nosso intelecto nunca intelige tantas coisas de modo que não possa inteligir
mais. Ora, nem atual nem habitualmente o nosso intelecto pode inteligir infinitas coisas. ― Atualmente
não, porque não pode conhecer simultaneamente em ato senão o que conhece por uma espécie. Ora, o
infinito não tem uma só espécie; do contrário teria a essência de todo e de perfeito. Por onde, não pode
ser inteligido senão apreendendo-se lhe uma parte depois de outra, como resulta da sua definição em
Aristóteles. Pois o infinito é aquilo de que se pode apreender uma quantidade, restando sempre alguma
coisa mais a apreender. De modo que o infinito não poderia ser conhecido atualmente, sem que se lhe
enumerassem todas as partes, o que é impossível. ― E pela mesma razão, não podemos inteligir
infinitas coisas, habitualmente. Pois, em nós, o conhecimento habitual é causado pela consideração
atual. Assim que, inteligindo, tornamo-nos cientes, como diz Aristóteles. Por onde, não poderíamos ter o
conhecimento distinto habitual de coisas infinitas, sem que considerássemos todas elas, enumerando-as
pela sucessão do conhecimento, o que é impossível. ― E assim, nem atual nem potencialmente o nosso
intelecto pode conhecer causas infinitas; mas só potencialmente, como já se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― Como já ficou estabelecido antes (q. 7, a. 1), diz-se que
Deus é infinito, como forma não determinada por qualquer matéria. Ao passo que, nas coisas materiais,
diz-se infinita a que tem privação da determinação formal. E como a forma é conhecida em si, ao passo
que a matéria sem a forma é desconhecida, daí vem que o infinito material é, em si, desconhecido.
Porém o infinito formal, que é Deus, é conhecido em si mesmo; desconhecido, porém, para nós, pela
deficiência do nosso intelecto que, no estado da vida presente, tem aptidão natural para conhecer as
coisas materiais. E portanto, na vida presente, não podemos conhecer a Deus, senão pelos efeitos
materiais. Na vida futura, porém, será eliminada, pela glória, a deficiência do nosso intelecto. E então,
poderemos ver o próprio Deus, na sua essência, sem que, todavia, o compreendamos.

RESPOSTA À SEGUNDA. ― É natural ao nosso intelecto conhecer as espécies pela abstração dos
fantasmas. Por onde, as espécies dos números e das figuras, quem não as imaginou, não as pode
conhecer, nem atual nem habitualmente; salvo, talvez, genericamente e pelos princípios universais, o
que é conhecer potencial e confusamente.

RESPOSTA À TERCEIRA. ― Se dois ou muitos corpos estivessem num lugar, não seria necessário que
entrassem nesse lugar, sucessivamente, de modo que pela sucessão mesma desse fato esses corpos
localizados fossem enumerados. Ora, as espécies inteligíveis entram em o nosso intelecto
sucessivamente, porque muitas, simultaneamente, não podem ser inteligidas. Por onde,
necessariamente, em o nosso intelecto estão espécies enumeradas e não infinitas.

RESPOSTA À QUARTA. ― Sendo infinito pela virtude, o nosso intelecto conhece o infinito. E a sua
virtude é infinita por que não é determinada pela matéria corpórea. E, sendo capaz de conhecer o
universal, abstrato da matéria individual, não fica conseqüentemente limitado a um indivíduo, mas, em
si mesmo, se aplica a infinitos indivíduos.

## Art. 3 — Se o nosso intelecto conhece os contingentes.
(De Verit., 9 isto é, q. 15, a. 2, ad 3; VI Ethic., lect. 1).
O terceiro discute-se assim. ― Parece que o intelecto não conhece os contingentes.

1. ― Pois, como diz Aristóteles, o intelecto, a sapiência e a ciência não se ocupam com coisas
contingentes, mas necessárias.

2. Demais. ― Como diz Aristóteles, coisas que ora existem e ora não existem são mensuradas pelo
tempo. Ora, o intelecto faz abstração do tempo, como das outras condições materiais. Ora, como o
próprio das coisas contingentes é, ora, existir e ora, não existir, resulta que tais coisas não são
conhecidas pelo intelecto.
Mas, em contrário. ― Toda ciência está no intelecto. Ora, há certas ciências que se ocupam com os
contingentes, como as ciências morais, que têm por objeto os atos humanos sujeitos ao livre arbítrio; e
também as ciências naturais, quanto à parte que trata dos seres susceptíveis de geração e corrupção.
Logo, o intelecto conhece os contingentes.

SOLUÇÃO. ― De dois modos podem-se considerar as coisas contingentes: enquanto contingentes e
enquanto têm algo de necessário, pois nada há de tal modo contingente, que nada tenha em si de
necessário. Como o fato mesmo de Sócrates correr é, em si, contingente; mas a dependência da corrida,
em relação ao movimento, é necessária, pois é necessário que Sócrates se mova, se corre.
Ora, é pela matéria que um ser é contingente; pois, é contingente o que pode ser e não ser, e a potência
pertence à matéria. Ao passo que a necessidade é resultante da essência da forma; pois, as coisas
conseqüentes à forma existem necessariamente. A matéria, porém, é o principio da individuação. Ora, a
noção do universal é apreendida, abstraindo a forma, da matéria particular. Pois, como já se disse antes
(a. 1), o intelecto, por si e diretamente, busca o universal; o sentido, porém, o singular, embora,
indiretamente este também seja apreendido pelo intelecto, de certo modo, corno ficou dito antes (Ibid).
Por onde, os contingentes, corno tais, são conhecidos diretamente pelo sentidos e, indiretamente, pelo
intelecto; porém as noções universais e necessárias dos contingentes são conhecidas pelo intelecto.
Por onde, se se atender às noções universais das coisas que se podem saber, todas as ciências se
ocupam com o necessário. Se se atender, porém, às coisas mesmo, então há certas ciências que buscam
o necessário e outras, o contingente.
Donde se deduzem AS RESPOSTAS ÀS OBJEÇÕES.

## Art. 4 — Se o nosso intelecto conhece os futuros.
(Supra, q. 57, a. 3; IIª IIae, q. 95, a. 1; q. 172, a. 1; I Sent., dist. XXXVIII, a. 5, ad; II, dist. VII, q. 2, a. 2; III
Cont. Gent., cap. CLIV; De Verit. Q. 8, a. 12; De Malo, q. 16, a. 7; Compend. Theol., cap. CXXXIII; In Isai.,
cap. III).
O quarto discute-se assim. ― Parece que o nosso intelecto conhece as coisas futuras.

1. ― Pois, o nosso intelecto conhece pelas espécies inteligíveis, que abstrai das condições particulares
de lugar e tempo; e por isso elas se referem indiferentemente a todos os tempos. Ora, ele pode
conhecer o presente. Logo, também as coisas futuras.

2. Demais. ― O homem, mesmo quando privado dos sentidos, pode conhecer certos futuros, como é
patente nos adormecidos e nos frenéticos. Ora, essa privação dos sentidos dá maior vigor à inteligência.
Logo, o intelecto, por si mesmo, pode conhecer as coisas futuras.

3. Demais. ― O conhecimento intelectivo do homem é mais eficaz do que qualquer conhecimento dos
brutos. Ora, certos animais prevêem certos futuros; assim, as gralhas pequenas, freqüentemente
crocitando, anunciam a chuva que em breve virá. Logo, com maioria de razão, o intelecto humano pode
conhecer as coisas futuras.
Mas, em contrário, diz a Escritura (Ecle 8, 6-7): É muita a aflição do homem, porque ignora as coisas
passadas, e por nenhum mensageiro pode saber as futuras.

SOLUÇÃO. ― Sobre o conhecimento dos futuros deve-se distinguir, do mesmo modo que sobre o dos
contingentes. Pois, os futuros, enquanto sujeitos ao tempo, são singulares, que o intelecto humano não
conhece senão pela reflexão, como já se disse antes (a. 1). Porém, as noções dos futuros podem ser
universais e perceptíveis pelo intelecto, de modo que se pode ter ciência delas. Para tratarmos, porém,
completamente do conhecimento dos futuros, deve-se saber que podem ser conhecidos de duplo
modo: em si mesmos e nas suas causas. Em si mesmos, só podem ser conhecidos por Deus, a quem
estão presentes, quando ainda são futuros, no decurso das causas; pois o olhar eterno de Deus domina,
simultaneamente, todo o decurso do tempo como já se disse antes (q. 14, a. 13), quando se tratou da
ciência de Deus. Mas, nas suas causas, podem ser conhecidos também de nós. E se provêm das causas
necessariamente, são conhecidos com a certeza da ciência; assim, o astrólogo conhece o eclipse futuro.
Se porém provêm das causas, no mais das vezes, então podem ser conhecidos por conjectura mais ou
menos certa, conforme as causas forem mais ou menos inclinadas para os efeitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A objeção procede, quanto ao conhecimento por meio
das noções universais das coisas; pelas quais os futuros podem ser conhecidos segundo a dependência
do efeito em relação à causa.

RESPOSTA À SEGUNDA. ― Como diz Agostinho, a alma recebe uma certa colaboração do acaso de
modo que, por sua natureza pode conhecer os futuros. Assim, quando se retrai dos sentidos corpóreos
e, de certo modo, volta-se para si mesma, torna-se participante do conhecimento dos futuros. Tal
opinião seria racional se admitíssemos que a alma adquire o conhecimento das causas pela participação
das idéias, como ensinavam os Platônicos; porque então, ela conheceria, por natureza, as causas
universais de todos os efeitos, mas ficaria impedida pelo corpo; de modo que, uma vez separada dos
sentidos, conheceria os futuros. Ora, este modo de conhecer não é conatural ao nosso intelecto, que
tira dos sentidos os elementos do seu conhecimentos. Por onde, não é por natureza que a alma, quando
separada dos sentidos, conhece os futuros; mas é, antes, pela impressão de certas causas superiores
espirituais e corporais. ― Espirituais, como quando, pelo ministério dos anjos, com a virtude divina, o
intelecto humano é iluminado e os fantasmas são ordenados ao conhecimento de certos futuros. Ou
também quando, por operação dos demônios produz-se uma comoção na fantasia, designando de
antemão certos futuros, que os demônios conhecem, como já se disse antes (q. 57, a. 3). Ora, essas
impressões das causas espirituais a alma pode naturalmente recebê-las, sobretudo quando separada
dos sentidos; porque, então, se torna mais próxima das substâncias espirituais e mais livre das agitações
exteriores. ― Mas também o fato pode sedar pela impressão das causas superiores corporais; pois, é
manifesto que os corpos superiores causam impressão nos inferiores. Por onde, como as virtudes
sensitivas são atos dos órgãos corpóreos, é conseqüente que a impressão dos corpos celestes cause, de
certo modo, imutação na fantasia. E por isso, sendo os corpos celestes causa de muitos futuros,
produzem-se na imaginação sinais de certos deles. E tais sinais são percebidos mais de noite, pelos que
dormem, do que de dia, pelos que estão acordados; porque, como diz Aristóteles, as coisas transmitidas
de dia dissipam-se facilmente; ao passo que o ar da noite é tranqüilo porque as noites são mais
silenciosas. E despertam o sentido, no corpo, por causa do sono; pois, os pequenos movimentos
interiores são sentidos mais pelos adormecidos do que pelos acordados. Ora, esses movimentos
produzem os fantasmas, pelos quais são previstos os futuros.

RESPOSTA À TERCEIRA. ― Os brutos nada têm, acima da fantasia, que ordene os fantasmas, como os
homens, que têm a razão; e por isso, a fantasia dos brutos é conseqüente, totalmente, à impressão
celeste. Por onde, pelos movimentos deles podem-se conhecer certos futuros, como a chuva e outros,
mais do que pelo movimento dos homens, que se movem pelo conselho da razão. E por isso diz o
Filósofo: há certos homens imprudentíssimos que são previdentes em sumo grau; porque a inteligência
deles não é trabalhada de cuidados; mas, deserta e vazia de tudo é, quando movida, como que levada
pelo motor.