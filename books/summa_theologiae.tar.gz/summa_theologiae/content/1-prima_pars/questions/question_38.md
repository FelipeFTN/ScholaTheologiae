# Questão 38: O Dom como nome do Espírito Santo.
Em seguida vamos tratar do dom, sobre o qual discutem-se dois artigos:

## Art. 1 — Se o Dom é nome Pessoal.
(I Sent., dist. XVIII, a. 1).
O primeiro discute-se assim. – Parece que o dom não é um nome pessoal.

1. – Pois, todo nome pessoal importa alguma distinção em Deus. Ora, o nome de dom não importa
nenhuma distinção em Deus; assim, como diz Agostinho, o Espírito Santo é dado, como dom de Deus, de
modo que se dá a si mesmo como Deus. Logo, dom não é nome pessoal.

2. Demais. – Nenhum nome pessoal convém à essência divina. Ora, esta é um dom, que o Pai faz ao
Filho, como diz Hilário. Logo, dom não é nome pessoal.

3. Demais. – Nenhuma das divinas Pessoas, segundo Damasceno, é sujeita ou dependente. Ora, o dom
importa uma certa sujeição a quem e àquele por quem é dado. Logo, não é nome pessoal.

4. Demais. – O dom, importando relação com a criatura, há-se de atribuir a Deus temporalmente. Ora,
os nomes pessoais se atribuem de Deus abeterno, como Pai e Filho. Logo, dom não é nome pessoal.
Mas, em contrário, Agostinho: Assim como o corpo carnal não passa de carne, assim o dom do Espírito
Santo é o Espírito Santo mesmo. Logo, o Espírito Santo, sendo nome pessoal, é também dom.

SOLUÇÃO. – O nome de dom importa aptidão para ser dado. Ora, o que é dado tem relação com quem
dá e com aquele a quem é dado; pois não o daria quem não o possuísse e a alguém é dado para que
possua. Ora, dizemos que uma Pessoa divina é de alguém, ou pela origem, e assim o Filho é do Pai; ou
porque é possuída de alguém. E como possuímos o que podemos usar e gozar como queremos, deste
modo a divina Pessoa não pode ser possuída senão pela criatura racional unida a Deus. Certamente as
outras criaturas podem ser movidas por uma Pessoa divina; não está porém no poder delas gozar dessa
Pessoa e usar-lhe do efeito. O que às vezes alcança a criatura racional; p. ex., tornando-se participante
do Verbo divino e do Amor procedente, de modo a poder verdadeira e livremente conhecer a Deus e
amá-lo retamente. Por onde, só a criatura racional pode possuir uma Pessoa divina. Mas não o pode por
virtude própria: é necessário que do alto lho seja dado. Ora, dizemos que uma coisa nos é dada quando
a temos de outrem. E assim, à divina Pessoa convém o ser dada e ser Dom.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O nome de dom importa distinção pessoal no sentido em
que se diz ser originariamente de alguém. E, contudo, o Espírito Santo se dá a si mesmo, como a si
mesmo se pertencendo e de si mesmo podendo usar, ou antes, gozar, assim como chamamos livre ao
homem que a si mesmo se pertence. E é o que diz Agostinho: Que mais é teu que tu? – Ou se deverá
melhor dizer, que o dom deve ser, de certo modo, de quem o dá. Ora, em muitos sentidos dizemos que
uma coisa é de alguém. Num sentido, a modo de identidade, como o faz Agostinho; e, então, dom, não
se distinguindo do doador, mas de quem o recebe, dizemos, que o Espírito Santo se dá. Outras vezes,
dizemos que uma coisa é de alguém como uma possessão ou uma servidão; e, então, o dom necessária
e essencialmente distinguindo-se de quem o dá, o dom de Deus é algo de criado. Em terceiro sentido se
diz que uma coisa é de alguém somente pela origem; e assim o Filho é do Pai e o Espírito Santo, de
ambos. Ora, neste sentido dizemos, que o dom é doador, do qual então se distingue pessoalmente e é
nome pessoal.

RESPOSTA À SEGUNDA. – No primeiro sentido é que se diz, que a essência é dom do Pai, pois é a
essência, por identidade.

RESPOSTA À TERCEIRA. – Como nome pessoal, o dom não importa sujeição ao doador, mas somente
origem dele. Importa, porém, livre uso ou fruição por parte do doado, como se disse.

RESPOSTA À QUARTA. – Dom não se chama ao que é atualmente dado, mas ao que é de natureza a ser
dado; e por isso a Pessoa divina abeterno se chama Dom, embora temporalmente dada. E nem por
importar relações com a criatura é necessário que seja essencial; mas é necessário inclua no seu
conceito algo de essencial, como a essência se inclui no conceito de Pessoa, segundo dissemos.

## Art. 2 — Se o Dom é nome próprio do Espírito Santo.
(I Sent., dist. XVIII, a. 2).
O segundo discute-se assim. – Parece que Dom não é um nome próprio de Espírito Santo.

1. – Pois, chama-se dom o que é dado. Ora, diz a Escritura (Is 9, 6): Um filho nos foi dado a nós. Logo, ser
Dom tanto convém ao Filho como ao Espírito Santo.

2. Demais. – Todo nome próprio de uma pessoa significa-lhe alguma propriedade. Ora, o nome de Dom
não significa nenhuma propriedade do Espírito Santo. Logo, não é nome próprio dele.

3. Demais. – Espírito Santo pode ser o espírito de qualquer homem, como se disse. Não pode, porém,
ser o dom atribuído a qualquer homem, mas só a Deus. Logo, Dom não é nome próprio do Espírito
Santo.
Mas, em contrário, Agostinho: Assim como ser nascido consiste em o Filho provir do Pai, assim, ser Dom
de Deus consiste, para o Espírito Santo, em proceder do Pai e do Filho. Ora, o Espírito Santo recebe o
seu nome próprio de proceder do Pai e do Filho. Logo, Dom é o nome próprio do Espírito Santo.

SOLUÇÃO. – Dom, pessoalmente considerado, em Deus, é o nome próprio do Espírito Santo. Para
evidenciá-lo, devemos saber que dom, propriamente, é uma doação irretribuível, segundo o Filósofo; i.
é, dado sem intenção de retribuição, e portanto é, por natureza, gratuita. Ora, a razão da doação
gratuita é o amor; pois, a quem damos uma coisa gratuitamente a esse lhe queremos bem; e, portanto,
a primeira coisa que lhe damos é esse amor pelo qual lhe queremos bem. Por onde, é manifesto que o
amor é por essência um dom do primeiro, pelo qual todos os outros se dão gratuitamente. Logo,
procedendo o Espírito Santo como Amor, consoante já se disse, procede em razão de dom primeiro. Por
isso Agostinho diz, que pelo dom, que é o Espírito Santo, muitos dons próprios se dividem pelos
membros de Cristo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Assim como o Filho, por proceder como Verbo, cuja
essência é ser semelhança do seu princípio, se chama propriamente Imagem, embora também o Espírito
Santo seja semelhante ao Pai; assim também o Espírito Santo, por proceder do Pai, como Amor, se
chama propriamente Dom, embora também o Filho seja dado. Pois o mesmo ser dado o Filho provém
do amor do Pai, segundo a Escritura (Jo 3, 16): Assim amou Deus ao mundo, que lhe deu o seu Filho
unigênito.

RESPOSTA À SEGUNDA. – O nome de dom importa em ser do doador por origem. E assim importa a
propriedade da origem do Espírito Santo, que é a processão.

RESPOSTA À TERCEIRA. – O dom, antes de ser dado, é só do doador; mas depois de ser dado, é do
doado. Como pois o Dom não importa doação em ato, não se pode dizer, que seja dom do homem, mas,
de Deus doador. Porém quando já tiver sido doado, então, é o espírito ou o dom do homem.