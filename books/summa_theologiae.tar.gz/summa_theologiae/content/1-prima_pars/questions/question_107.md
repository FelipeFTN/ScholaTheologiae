# Questão 107: Da locução dos anjos.
Em seguida devemos tratar da locução dos anjos. E nesta questão cinco artigos se discutem:

## Art. 1 — Se um anjo fala com outro.
(II Sent., dist. I, part. II, a. 3; De Verit., q. 9, a. 4; I Cor., cap. XIII, lect. I).
O primeiro discute-se assim. — Parece que um anjo não fala com outro.

1. — Pois, diz Gregório, que no estado da ressurreição a corpulência dos membros não esconderá a
mente de um dos olhos de outro. Por onde, com maior razão, a mente de um anjo não poderá
esconder-se a outro. Ora, a locução serve para manifestar a outrem o que está oculto na mente. Logo,
não é preciso que um anjo fale a outro.

2. Demais. — Há dupla locução: a interior, pela qual falamos conosco mesmos; e a exterior, pela qual
falamos com os outros. Ora esta manifesta-se por algum sinal sensível, como a voz ou um aceno; ou por
algum membro do corpo, como a língua ou o dedo; o que tudo não pode convir ao anjo. Logo, um anjo
não fala com outro.

3. Demais. — Quem fala excita o ouvinte a atentar para o que diz. Ora, não se vê por onde um anjo
excite outro a que atente; pois isso se faz, nos homens, por algum sinal sensível. Logo, um anjo não fala
com outro.
Mas, em contrário, diz a Escritura (1 Cor 13, 1): Se eu falar as línguas dos homens e dos anjos.

SOLUÇÃO. — Os anjos falam de certo modo. Mas como diz Gregório, é digno que a nossa mente,
excedendo a qualidade da linguagem corpórea, fique suspensa em relação aos modos sublimes e
incógnitos da linguagem íntima. Para se entender, pois, como um anjo fala com outro, deve-se
considerar que, como já dissemos ao tratar dos atos e das potências da alma (q. 82, a. 4), a vontade
move o intelecto à operação deste. Ora, o inteligível está no intelecto de tríplice modo: habitualmente,
ou pela memória, como diz Agostinho; como atualmente considerado ou concebido; e como referido a
outra coisa. É manifesto, porém, que o inteligível transfere-se do primeiro para o segundo grau, pelo
império da vontade; e por isso define-se o hábito comoaquilo de que alguém usa, quando quer. E se-
melhantemente, também, pela vontade transfere-se do segundo grau para o terceiro; pois, por ela, o
conceito da mente se ordena a outra coisa p. ex., a fazer ou a manifestar algo a outrem. Ora, quando a
mente se atualiza, considerando o que tem, habitualmente, então falamos conosco mesmos; pois, o
conceito mesmo da mente se chama verbo interior. Quando, pois, o conceito da mente de um anjo se
ordena a manifestar-se a outro, por vontade do primeiro, então, esse conceito faz-se conhecido do
outro; sendo assim que um anjo fala com outro. Pois, falar com outrem não é senão manifestar-lhe o
conceito da mente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O conceito interior da nossa mente se oculta por um
como duplo obstáculo. O primeiro é a vontade mesma, que pode reter interiormente o conceito do
intelecto ou ordená-la para o exterior; e, no primeiro caso, só Deus, e mais ninguém, pode conhecer a
mente de um homem, conforme aquilo da Escritura (1 Cor 2, 11): Qual dos homens conhece as coisas
que são do homem, senão o espírito do homem que nele mesmo reside? O segundo é a materialidade
do corpo. E assim, mesmo quando a vontade ordena o conceito da mente a manifestar-se a outrem,
nem por isso ele é imediatamente conhecido deste, sendo necessário acrescentar-se algum sinal
sensível. E é o que pensa Gregório, quando diz:conservamos o segredo da mente, aos olhos alheios,
como ocultando-o por trás da parede do corpo; e quando desejamos nos manifestar, saímos pela como
janela da língua, mostrando-nos como interiormente somos. Ora, este obstáculo não existe no anjo; e
por isso quando um quer manifestar o seu conceito, imediatamente o outro o conhece.

RESPOSTA À SEGUNDA. — A locução externa por meio da palavra nos é necessária por causa do
obstáculo do corpo. Por onde, convém ao anjo, não esta, mas só a locução interior, pela qual pode um
anjo, não só falar consigo mesmo, concebendo interiormente, mas ainda manifestar-se voluntariamente
a outro. E assim diz-se metaforicamente, que a locução dos anjos é a virtude mesma de cada um, pela
qual manifesta o seu conceito, do modo predito.

RESPOSTA À TERCEIRA. — Em relação aos anjos bons, que sempre se vêm mutuamente no Verbo, não é
necessário haver nenhum excitante, porque, como um sempre vê a outro, assim também sempre vê,
nesse outro, tudo quanto para si for destinado. Mas, como já no primeiro estado da natureza, podiam
falar uns com os outros; e como os anjos maus, ainda agora, falam-se entre si; deve-se dizer que, assim
como o sentido é movido pelo sensível, assim, o intelecto, pelo inteligível. Assim como, pois, o sentido é
excitado pelo sinal sensível, assim pode ser excitada a atenção da mente angélica por alguma virtude
inteligível.

## Art. 2 — Se o anjo inferior fala com o superior.
(De Verit., q. 9, a. 5; 1 Cor., cap. XIII, lect I).
O segundo discute-se assim. — Parece que o anjo inferior não fala com o superior.

1. — Pois, a respeito do passo (1 Cor 13, 1) — Se eu falar as línguas dos homens e dos anjos — diz a
Glossa, que a linguagem dos anjos são as iluminações, pelas quais os superiores iluminam os inferiores.
Ora, os inferiores nunca iluminam os superiores, como antes se disse (q. 106, a. 3). Logo, também nunca
falam com os superiores.

2. Demais. — Como já se disse antes (q. 106, a. 1), iluminar não é senão manifestar a outrem o que já é,
a si mesmo, manifesto; e isto é o mesmo que falar. E portanto, sendo falar o mesmo que iluminar,
conclui-se o idêntico à objeção anterior.

3. Demais. — Gregório diz que Deus fala com os santos anjos quando lhes mostra às mentes os seus
desígnios ocultos e invisíveis. Ora, isto é iluminar. Por onde, toda fala de Deus é iluminação e, por igual
razão, toda fala do anjo. E, portanto, de nenhum modo o anjo inferior pode falar com o superior.
Mas, em contrário, como expõe Dionísio, os anjos inferiores disseram aos superiores (Sl 23, 10): Quem é
este Rei da glória?

SOLUÇÃO. — Os anjos inferiores podem falar com os superiores. E, para evidenciá-lo, devemos
considerar que, nos anjos, toda iluminação é locução, mas nem toda locução é iluminação. Pois, como já
se disse (a. 1), o falar de um anjo não é senão fazer com que, por vontade própria, o seu conceito seja
conhecido de outro. Ora, o que a mente concebe pode se referir a um duplo princípio: a Deus mesmo,
verdade primeira; e à vontade de quem intelige, pela qual um objeto é considerado em ato. Ora, como a
verdade é a luz do intelecto, e a regra de toda verdade é o próprio Deus, a manifestação do que é conce-
bido pela mente, é, no que depende da verdade primeira, tanto locução como iluminação; assim, p. ex.,
se um homem disser a outro, que o céu foi criado por Deus, ou o homem é um animal. Porém a
manifestação do que depende da vontade de quem intelige não pode se chamar iluminação, mas
somente locução; assim, p. ex., se alguém disser a outrem: quero aprender isto, quero fazer isto ou
aquilo. E a razão é que a vontade criada não é luz, nem regra da verdade, mas participante da luz. Por
onde, comunicar o que depende da vontade criada, como tal, não é iluminar. Pois, constitui a perfeição
do meu intelecto, não, conhecer o que tu queres ou inteliges, mas somente o que se encerra na verdade
da causa
É pois manifesto que os anjos são considerados superiores ou inferiores por comparação ao princípio,
que é Deus. Por onde, a iluminação, dependente desse princípio, desce aos anjos inferiores por meio
dos superiores. Ao passo que, em relação ao princípio, que é a vontade, o ser mesmo que quer é
primeiro e supremo. E por isso, a manifestação do que depende da vontade comunica-se a outrem por
meio do indivíduo mesmo que quer. E deste modo, tanto os anjos superiores falam com os inferiores,
como estes com aqueles.
Donde se deduzem as RESPOSTAS À PRIMEIRA E À SEGUNDA OBJEÇÕES.

RESPOSTA À TERCEIRA. — Toda locução dos anjos com Deus é iluminação; porque, como a vontade de
Deus é a regra da verdade, mesmo saber o que Deus quer pertence à perfeição e à iluminação da mente
criada. Mas, como já se disse, o mesmo não se dá com a vontade do anjo.

## Art. 3 — Se o anjo fala com Deus.
(In Iob., cap. I, lect. II).
O terceiro discute-se assim. — Parece que o anjo não fala com Deus.

1. — Pois, a locução serve para manifestar alguma coisa a alguém. Ora, o anjo não pode manifestar nada
a Deus, que conhece tudo. Logo, não fala com Deus.

2. Demais. — Falar é ordenar para outrem conceito do intelecto, como já se disse (a. 1). Ora, o anjo
ordena sempre para Deus o conceito da sua mente. Se, pois, às vezes fala com Deus, fala sempre; o que
poderá parecer inadmissível a alguns, porque às vezes, um anjo fala com outro.
Mas, em contrário, diz a Escritura (Zc 1, 12): E o anjo do Senhor replicou, e disse: Senhor dos exércitos,
até quando diferirás tu o compadecer-te de Jerusalém? Logo, o anjo fala com Deus.

SOLUÇÃO. — Como já se disse (a. 1, 2), a locução do anjo consiste em o conceito da sua mente se
ordenar para outrem. Ora, uma coisa se ordena para outra duplamente: — De um modo, para que
comunique a outrem alguma coisa; assim, nos seres naturais, o agente se ordena para o paciente; e na
linguagem humana, o mestre se ordena para o discípulo. E, neste ponto de vista; de maneira nenhuma o
anjo fala com Deus, nem no referente à verdade das coisas, nem no que depende da vontade criada,
porque Deus é o princípio e o instituidor de toda verdade e de toda vontade. — De outro modo, uma
coisa se ordena a outra, da qual recebe algo; assim, nos seres naturais, o paciente se ordena para o
agente e, na locução humana, o discípulo, para o mestre. E desta maneira, o anjo fala com Deus, ou
consultando a divina vontade, quanto ao que deve fazer; ou admirando, sem nunca a compreender, a
excelência de Deus, como diz Gregório: os anjos falam com o Senhor quando, considerando-se a si
mesmos, ficam tomados de admiração.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A locução nem sempre serve para nos manifestarmos a
outrem; mas às vezes se ordena, finalmente, a que alguma coisa seja manifestada a quem fala; assim,
quando o discípulo pergunta ao mestre.

RESPOSTA À SEGUNDA. — Os anjos sempre falam com Deus pela locução que consiste em louvá-lo e
admirá-lo. Mas, na locução pela qual lhe consultam a sabedoria, sobre como devem agir, falando-lhe só
quando lhes ocorre algo de novo a fazer, sobre o que desejam ser iluminados.

## Art. 4 — Se a distância local tem alguma influência na locução angélica.
(II Sent., dist. XI, part. II, a. 3. ad 3; De Verit., q. 9, a. 6).
O quarto discute-se assim. — Parece que a distância local tem alguma influência na locução angélica.

1. — Pois, como diz Damasceno, o anjo opera onde está. Ora, a locução é uma operação do anjo. Logo,
quando o anjo está num determinado lugar, resulta que pode falar até a uma distância do determinado
lugar.

2. Demais. — Por causa da distância do ouvinte é necessário o gritar de quem fala. Ora, a Escritura diz,
do Serafim (Is 4, 3): clamava um para o outro. Logo, na locução dos anjos, a distância local tem alguma
influência.
Mas, em contrário, o rico, posto no inferno clamava a Abraão, diz a Escritura (Lc 16, 24), sem que lho
impedisse a distância local. Logo, com maioria de razão, a distância local não pode impedir que um anjo
fale com outro.

SOLUÇÃO. — A locução do anjo consiste numa operação intelectual, como resulta do que já foi dito (a.
1, 2, 3). Ora, tal operação, no anjo, é abstrata do lugar e do tempo. Pois, mesmo a nossa operação
intelectual se dá pela abstração das circunstâncias de lugar e de tempo, exceto por acidente, por parte
dos fantasmas, que de nenhum modo existem nos anjos. Por ser, pois, a operação intelectual deles
absolutamente abstrata do lugar e do tempo, nada operam sobre ela nem a diversidade deste, nem a
distância local. Por onde, esta não traz nenhum impedimento à locução angélica.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A locução angélica, como já se disse (a. 1, ad 2), é
interior; percebida, todavia, por outro anjo. Logo, está no anjo que fala e, por conseguinte, onde está
esse anjo. Mas, como a distância local não impede que um anjo possa ver outro, assim, também não
impede que um perceba, em outro, o que, neste, está ordenado para aquele; e isso é perceber um a
locução do outro.

RESPOSTA À SEGUNDA. — O referido clamor não é voz corpórea, necessitado pela distância local; mas
significa a grandeza da coisa dita, ou a grandeza do efeito, conforme explica Gregório: cada um tanto
menos clama quanto menos deseja.

## Art. 5 — Se todos os anjos conhecem a linguagem de um anjo com outro.
(De Verit., q. 9, a. 7).
O quinto discute-se assim. — Parece que todos os anjos conhecem a locução de um anjo com o outro.

1. — Pois, a desigualdade da distância local faz com que nem todos ouçam a fala de um homem. Ora, na
linguagem angélica, nenhuma influência tem a distância local, como já foi dito (a. 4). Logo, todos
percebem quando um anjo fala com outro.

2. Demais. — Todos os anjos têm a mesma virtude de inteligir. Se, pois, o conceito da mente de um,
ordenado para outro, é conhecido por um, sê-lo-á também pelos outros.

3. Demais. — A iluminação é uma espécie de locução. Ora a todos os anjos chega a iluminação que vai
de um para outro; porque, como diz Dionísio, cada essência celeste comunica às outras a inteligência
que lhe foi dada. Logo, também a locução de um anjo com outro chega a todos.
Mas, em contrário, um homem pode falar só a um outro. Logo, com maior razão, o mesmo também
pode o anjo.

SOLUÇÃO. — Como já se disse (a. 1, 2), o conceito da mente de um anjo pode ser percebido por outro,
quando aquele, por sua vontade, ordena o seu conceito para este. Ora, por alguma causa, uma coisa
pode ser ordenada para um fim e não, para outro. Por onde, o conceito de um anjo pode ser conhecido
só por outro e não por todos. De modo que um anjo pode perceber a locução de outro, sem que os
demais a percebam; não que o impeça a distância local, mas tal se dando pela ordenação voluntária,
como já se disse.
Donde se deduzem as RESPOSTAS À PRIMEIRA E À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. — A iluminação se refere ao que emana da regra primeira da verdade, princípio
comum a todos os anjos; e, por isso, as iluminações são comuns a todos. Ao passo que a locução pode
se referir ao que se ordena ao princípio da vontade criada, o que é próprio a cada anjo; e por isso, não é
necessário que tais locuções sejam comuns a todos.