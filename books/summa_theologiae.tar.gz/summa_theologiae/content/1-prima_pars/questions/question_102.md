# Questão 102: Do paraíso morada do homem.
Em seguida devemos tratar do paraíso, morada do homem.
E sobre esta questão quatro artigos se discutem:

## Art. 1 — Se o paraíso era um lugar material.
O primeiro discute–se assim. – Parece que o paraíso não era um lugar corpóreo.

1. – Pois, diz Beda, que o paraíso chega até o círculo lunar. Ora, tal não pode se dar com nenhum lugar
terreno; quer por que fosse contra a natureza da terra o elevar–se tanto; quer por existir, sob o globo
lunar, uma região ígnea, que consumiria a terra. Logo, o paraíso não é um lugar material.

2. Demais. – A Escritura menciona quatro rios nascidos no paraíso. Ora, esses rios aí mencionados tem,
em outros lugares, origens manifestas, como também se vê claramente no Filósofo. Logo, o paraíso não
é um lugar material.

3. Demais. – Alguns perquiriram muito diligentemente todos os lugares da terra habitável, e todavia
nenhuma menção fizeram da situação do paraíso. Logo não é um lugar material.

4. Demais. – Afirma–se que a árvore da vida estava no paraíso. Ora tal árvore é espiritual, conforme a
Escritura: É árvore da vida para aqueles que lançarem mão dela. Logo também o paraíso não era um
lugar material, mas espiritual.

5. Demais. – Se o paraíso fosse um lugar material, necessariarnente também seriam materiais as suas
árvores. Ora, tal não podia ser, por terem elas sido produzidas no terceiro dia; pois, a Escritura
menciona a plantação das árvores do paraíso depois das obras dos seis dias. Logo, o paraíso não é um
lugar material.
Mas, em contrário, diz Agostinho: Há três como opiniões geral, a respeito do paraíso; uma a dos que o
querem compreender somente como material; a outra, a dos que se espiritualmente o compreendem "
a terceira, a dos que o concebem de ambos os modos ; e confesso que esta é a que me agrada.

SOLUÇÃO. – Como diz Agostinho, o que se acomoda à concepção espiritual do paraíso nada impede que
seja admitido; contanto que seja acreditada a verdade fidelíssima da história, confirmada pela narração
dos factos passados; ora, o que a Escritura diz, do paraíso, é proposto como narração histórica. E assim,
de tudo o que a Escritura historicamente nos transmite, deve–se ter como fundamento a verdade da
história e, ulteriormente é que se devem procurar as exposições em sentido espiritual. E, pois o paraíso,
como diz Isidoro, um lugar colocado nas partes do Oriente, cuja denominação, traduzida do grego para
o latim, significa jardim. Por onde, convenientemente se considera situado na parte Oriental; pois há–se
de crer que estava colocado no lugar mais nobre da terra toda. Ora, sendo o Oriente a dextra do céu,
como se vê claramente no Filósofo, e sendo a dextra mais nobre que a esquerda, era conveniente que o
paraíso terrestre fosse instituído por Deus na parte Oriental.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As palavras de Beda não são verdadeiras, entendidas de
uma situação manifesta. Podem contudo ser explicadas como significando que ascendia até o lugar do
globo lunar, não pela eminência da situação, mas pela semelhança; pois, há nesse lugar uma perpétua
tempérie de ar, como diz Isidoro; e por aí assemelha–se aos corpos celestes, que não têm
contrariedade. Porém, é feita menção, antes do globo lunar, do que das outras esferas, porque esse
globo é o limite dos corpos celestes, em relação a nós. E a lua também tem mais afinidades com a terra,
do que todos os corpos celestes; sendo por isso que, sujeita a certas trevas nebulosas, chega a ser quase
opaca. Outros, porém dizem que o paraíso chegava até o globo lunar, isto é, até o meio do intervalo do
ar, onde são produzidas as chuvas, os ventos e fenômenos semelhantes; e isso porque a influência sobre
tais evaporações se atribuem, sobretudo à lua. Mas, a se seguir esta opinião, tal lugar não seria
conveniente para a habitação humana, quer porque nele há a máxima intempérie, quer por não ser
apropriado à compleição humana, como o ar inferior, mais vizinho da terra.

RESPOSTA À SEGUNDA. – Como diz Agostinho, deve–se acreditar que o lugar do paraíso está muito
longe do conhecimento dos homens; que os rios, cujas fontes se dizem conhecidas, afundiram–se, em
outras partes, nas terras e, depois de haverem percorrido espaçosas regiões, prorromperam em outros
lugares. Pois, quem ignora que isso costuma dar–se com alguns rios?

RESPOSTA À TERCEIRA. – O referido lugar ficou separado das partes que habitamos por certas balisas:
montes, mares ou alguma região ardente, que não podem ser ultrapassados. E é por isso que os
descritores dos lugares não fizeram menção de tal lugar.

RESPOSTA À QUARTA. – A árvore da vida é uma árvore material, assim chamada por terem os seus
frutos a virtude de conservar a vida, como já se disse antes. E contudo também significava algo de
espiritual; assim como a pedra, no deserto era uma cousa material e todavia simbolizava Cristo.
Semelhantemente, também a árvore da ciência do bem e do mal era uma árvore material, assim
chamada por causa do futuro acontecimento. Porque, após havê–la comido, o homem, experimentando
a pena, compreendeu a diferença entre o bem da obediência e o mal da desobediência, Mas também
espiritualmente essa árvore podia significar o livre arbítrio, como certos disseram.

RESPOSTA Á QUINTA. – Segundo Agostinho, no terceiro dia foram produzidas as plantas, não
atualmente. mas por certas razões seminais; mas, depois das obras dos seis dias, foram elas produzidas
atualmente, tanto as do paraíso como as demais. – Porém, segundo outros Santos, necessário é dizer
que todas as plantas foram produzidas, atualmente, no terceiro dia, e também as árvores do paraíso. E
quanto à plantação das árvores do mesmo, depois das obras dos seis dias, isso se entende dito como
recapitulação. E por isso em o nosso texto lê–se: O Senhor Deus tinha plantado desde o princípio um
paraíso.

## Art. 2 — Se o paraíso era lugar conveniente à habitação humana.
O segundo discute–se assim. – Parece que ri paraíso não era lugar conveniente à habitação humana.

1. – Pois, o homem e o anjo ordenam–se, semelhantemente para a felicidade. Ora, o anjo logo, desde o
princípio, foi constituído habitante do lugar dos bem–aventurados, isto é, do céu empireo, Logo,
também essa devia ser a habitação humana.

2. Demais. – Ao homem deve ser assinalado um lugar, por causa da alma ou por causa do corpo. Por
causa daquela, devido lhe é o céu, lugar natural da alma, desde que a todos é ínsito o desejo do mesmo.
Por causa deste, devido lhe é o mesmo lugar dos outros animais. Logo, o paraíso de nenhum modo era
lugar conveniente à habitação humana.

3. Demais. – É inútil o lugar em que nada está localizado. Ora, depois do pecado, o paraíso já não era
lugar da habitação humana. Logo, se era lugar congruente à habitação humana, Deus o instituiu
inutilmente.

4. Demais. – Ao homem, de compleição temperada, congruente lhe é um lugar de clima temperado.
Ora, tal não era o paraíso; pois, diz–se que estava sob o círculo equinoxial, lugar calidíssimo, segundo
parece; porque, duas vezes no ano, o sol passa pelo alto das cabeças dos que aí habitam. Logo, o paraíso
não era lugar congruente à habitação humana.
Mas, em contrário, Damasceno diz, que o paraíso era uma região divina e digna morada de quem foi
jeito à imagem de Deus.

SOLUÇÃO. – Como já se disse antes, o homem era incorruptível e imortal, não porque o seu corpo
tivesse disposição incorruptível, mas por lhe ser inerente uma certa virtude da alma que preservava o
corpo da corrupção.
Ora, o corpo humano pode ser corrompido interior e exteriormente. Inferiormente, pela consumpção da
umidade e pela velhice, como já se disse antes; e esta corrupção o homem podia evitar, usando de
alimentos. Por outro lado, o ar corrupto, principal causa da corrupção externa, se evita pela tempérie do
mesmo. Ora, de ambos esses modos se podia evitar a corrupção, no paraíso; pois, como diz Damasceno,
era lugar esplêndido pelo ar temperado, tenuissimo e purissimo, sempre coberto de plantas floridas, Por
onde, é manifesto que o paraíso era lugar conveniente à habitação humana, no estado da primitiva
imortalidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O céu ernpíreo é o mais elevado, dos lugares materiais e
está fora de toda mutabilidade. Pela primeira qualidade, era lugar congruente à natureza angélica: pois,
como diz Agostinho, Deus rege a criatura corpórea pela espiritual. E por isso é conveniente que a
natureza espiritual seja constituída superior a toda a corpórea, como que presidindo–a. A segunda
convém ao estado de beatitude, firmado em suma estabilidade. E, portanto o lugar da beatitude, sendo
congruente ao anjo pela sua natureza, aí foi ele criado. Mas não era congruente ao homem pela sua
natureza, pois ele não preside a todas as criaturas corpóreas, governando–as, o que só lhe compete em
razão da beatitude. Por onde, não foi colocado, desde o princípio, no céu empireo, mas para ele devia
ser transferido, no estado final da beatitude.

RESPOSTA À SEGUNDA. – É ridículo dizer que a alma, ou qualquer substância espiritual, tenha algum
lugar natural; mas, por uma certa congruência, um lugar especial é atribuído à criatura espiritual. O
paraíso terrestre, porém, era lugar congruente ao homem, quanto à alma e quanto ao corpo; e isso
porque. a alma tinha a virtude de preservar o corpo humano, da corrupção, o que não cabia aos outros
animais. E, por isso, como diz Damasceno, nenhum irracional habitava o paraíso; embora, por
dispensação divina, os animais fossem para ali conduzidos a Adão, e a serpente nele penetrasse, por
obra do diabo.

RESPOSTA À TERCEIRA. – O referido lugar não foi inútil, por não ter sido a habitação dos homens,
depois do pecado; como também não foi inútilrnente atribuída ao homem a imortalidade, que não havia
de conservar. Mas por aí se manifesta a bondade de Deus para com o homem e o que este, pecando,
perdeu. Embora seja dito que, atualmente, Enoque e Elias habitem o paraíso.

RESPOSTA À QUARTA. – Os que colocam o paraíso sob o círculo equinoxial, opinam que há, sob tal
circulo, um lugar temperadíssimo. E isso por causa da contínua igualdade dos dias e das noites; e porque
o sol nunca se afasta muito, de modo que os habitantes viessem a ter excesso de frio. Nem sofrem eles,
segundo dizem, excesso de calor, pois embora o sol lhes passe por sobre as cabeças, contudo não se
demora muito nessa posição. Aristóteles porém diz expressamente que a dita região é inabitável, por
causa do calor. E isso parece mais provável; porque as terras onde o sol nunca passa diretamente por
sobre as cabeças sofrem calor imoderado, só pela vizinhança do mesmo. Seja como for, devemos crer
que o paraíso foi constituído num lugar temperadissimo, sob o círculo equinoxial ou algures.

## Art. 3 — Se o homem foi colocado no paraíso para cultivá–lo e guardá–lo.
O terceiro discute–se assim. – Parece que o homem não foi colocado no paraíso para cultivá–lo e
guardá–lo.

1. – Pois, o que foi imposto como pena do pecado não podia existir no paraíso, no estado de inocência.
Ora, a agricultura foi imposta como pena do pecado, conforme a Escritura. Logo, o homem não foi
colocado no paraíso para que o cultivasse.

2. Demais. – A guarda não é necessária onde não se teme nenhum ataque violento. Ora, tal ataque não
era para temer, no paraíso. Logo, não era necessário que o homem o guardasse.

3. Demais. – Se o homem tivesse sido colocado no paraíso para cultivá–lo e guardá–lo, resultaria que
aquele foi feito para este e não inversamente, o que é falso. Logo, o homem não foi colocado no paraíso
para cultivá–lo e guardá–lo. Mas, em contrário, diz a Escritura: Tomou pois o Senhor Deus ao homem, e
pô–la no paraíso dar delicias para ele o hortar e guardar.

SOLUÇÃO. – Como diz Agostinho, esse passo da Escritura pode ser entendido em duplo sentido. – Em
um, assim: Deus colocou o homem no paraíso, de maneira que Deus mesmo tratasse do homem e o
guardasse. Tratasse, digo justificando–o; pois se tal operação cessar, o homem imediatamente se
entenebrece, assim como o ar, se cessar a influência da luz. E o guardasse de toda corrupção e de todo o
mal. – Em outro sentido, pode–se entender que o homem cultivasse e guardasse o paraíso. Porém essa
operação não seria laboriosa, como o é depois do pecado; mas agradável, por causa da experiência das
forças da natureza. E quanto à guarda, ela não podia ser contra nenhum ataque, mas seria para que o
homem guardasse o paraíso para si afim de não perdê–lo pecando; o que tudo reverteria para seu bem.
E assim o paraíso foi ordenado para o bem do homem, e não inversamente.
E daqui se deduzem claras as RESPOSTAS ÀS OBJEÇÕES.

## Art. 4 — Se o homem foi feito no paraíso.
O quarto discute–se assim. – Parece que o homem foi feito no paraíso.

1. – Pois, o anjo foi criado no céu empíreo, lugar da sua habitação. Ora, o paraíso era lugar congruente à
habitação humana, antes do pecado. Logo, o homem devia ter sido feito no paraíso.

2. Demais. – Os outros animais são conservados no lugar da sua geração; assim, os peixes, nas águas; e
os animais que andam na terra, onde foram produzidos. Ora, o homem havia de ser conservado no
paraíso, como já se disse. Portanto, devia nele ter sido feito.

3. Demais. – A mulher foi feita no paraíso. Ora, o homem, sendo mais digno que a mulher, com maior
razão devia ter sido feito nele.
Mas, em contrário, diz a Escritura: Tomou, pois o Senhor Deus ao homem, e pô–lo no paraíso das
delicias.

SOLUÇÃO. – O paraíso era lugar congruente à habitação humana, quanto à incorrupção do primitivo
estado. Ora, essa incorrupção o homem não a tinha por natureza, mas por dom sobrenatural de Deus. E
para que fosse imputada à graça de Deus e não à natureza humana, Deus fez o homem fora do paraíso;
e depois nele o colocou, para que aí habitasse todo o tempo da vida animal, para, após haver alcançado
a vida espiritual, ser transferido ao céu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O céu empíreo é lugar congruente aos anjos, quanto à
natureza deles, e, por isso, nele foram criados.
E, semelhantemente, devemos RESPONDER À SEGUNDA. – Pois, tais lugares eram apropriados aos
animais, pela natureza destes,

RESPOSTA À TERCEIRA. – A mulher foi feita no paraíso, não por causa da sua dignidade, mas por causa
da dignidade do princípio pelo qual o seu corpo foi formado. Porque, semelhantemente, também os
filhos teriam nascido no paraíso, no qual já os pais estavam colocados.
Tratado sobre a conservação e o governo
das coisas