# Questão 90: Da produção primeira do homem quanto a alma.
Em seguida deve–se considerar a produção primeira do homem. E, sobre este ponto, quatro pontos se
devem examinar. Primeiro, a produção do homem em si mesmo. Segundo, do fim da produção.
Terceiro, do estado e da condição do homem primeiramente produzido. Quarto, do lugar do mesmo.
Ora, sobre a produção, três pontos se devem examinar. Primeiro, da produção do homem quanto à
alma. Segundo, quanto ao corpo do varão. Terceiro, quanto à produção da mulher.
Sobre o primeiro ponto quatro artigos se discutem:

## Art. 1 — Se a alma humana foi feita, ou é da substância de Deus.
O primeiro discute–se assim. – Parece que a alma não foi feita, mas é da substância de Deus.

1. – Pois, diz a Escritura: Formou pois o Senhor Deus o homem do barro da terra, e inspirou no seu rosto
um assopro de vida, e foi feito o homem em alma vivente. Ora, quem inspira emite algo de si. Logo a
alma, pela qual o homem vive, é algo da substância de Deus.

2. Demais. – Como se estabeleceu antes, a alma é uma forma simples. Ora, a forma é ato, Logo, a alma é
ato puro, o que só Deus é. Logo, a alma é da substância de Deus.

3. Demais. – Seres que existem e de nenhum modo diferem são idênticos. Ora, Deus e a alma existem e
de nenhum modo diferem; porque, do contrário, seria necessário se diversificassem por algumas
diferenças e, então, seriam compostos. Logo, Deus e a alma humana são idênticos.
Mas, em contrário, Agostinho enumera certas opiniões que diz serem muito e abertamente perversas e
contrárias à fé católica; entre as quais a primeira é a dos que ensinam que Deus fez a alma, não do nada,
mas de .li mesmo,

SOLUÇÃO. – Considerar a alma como da substância de Deus é opinião que encerra manifesta
improbabilidade. Pois, como resulta do que já foi dito, a alma é, ora, potencial na sua intelecção
haurindo a ciência, de certo modo, nas coisas; e tem diversas potências; o que tudo é alheio à natureza
de Deus, que é ato puro, nada recebe de nenhum outro ser e não encerra em si nenhuma diversidade,
como ficou provado antes. – Mas parece que esse erro se originou de duas opiniões, entre os antigos.
Pois, os primeiros que começaram a investigar a natureza das coisas, não podendo ultrapassar os dados
da imaginação, ensinaram que, além dos corpos, nada mais existe. E, por isso, consideravam Deus um
determinado corpo, tendo–o como princípio dos outros corpos. E, concebendo a alma como da natureza
desse corpo, considerado como princípio, conforme refere Aristóteles, concluíam que ela é da
substância de Deus. Também os Maniqueus, conforme essa opinião, considerando Deus como uma luz
material, ensinavam que a alma é uma parte dessa luz, ligada ao corpo. Ulteriormente, porém, outros
conceberam a existência de um ser incorpóreo, não todavia separado do corpo, mas forma deste.
Donde, o dizer Varrão que Deus é uma alma que governa o mundo, pela intuição ou movimento, e pela
razão, segundo refere Agostinho. Assim, pois, certos ensinavam que a alma humana é parte dessa alma
total, como o homem o é do mundo total, não conseguindo distinguir intelectualmente os graus das
substâncias espirituais senão pelas distinções dos corpos, Ora, todas essas opiniões são insustentáveis,
como ficou provado antes. Por onde, é manifestamente falso que a alma seja da substância de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Não se deve tomar a palavra inspirar em acepção
material. Mas o inspirar de Deus é o mesmo que produzir o espírito; embora o homem, inspirando
corporalmente, não emita nada da sua substância, mas algo de uma natureza estranha.

RESPOSTA À SEGUNDA. – Embora a alma seja uma forma simples, por essência, esta essência, contudo,
não é a sua existência; mas a alma é um ente por participação, como se vê pelo que foi dito antes. Logo,
não é ato puro, como Deus.

RESPOSTA À TERCEIRA. – O diferente, em acepção própria, por algo difere; por isso busca–se diferença
onde há conveniência. Por onde, entes diferentes hão de ser, de certo modo, compostos, pois diferem,
por um lado e convêm por outro. Mas, conforme esta doutrina, embora todo diferente seja diverso,
contudo, nem todo diverso é diferente, como diz Aristóteles. Pois, os seres simples são diversos, entre si
mesmos; não diferem, porém por quaisquer diferenças das quais fossem compostos. Assim, o homem e
o asno diferem pelas diferenças de racional e irracional, das quais não se pode dizer que difiram,
ulteriormente, por outras diferenças.

## Art. 2 — Se a alma tem o ser produzido por criação.
O segundo discute–se assim. – Parece que a alma não tem o ser produzido por criação.

1. – Pois, o que tem em si algo de material é produzido da matéria. Ora, a alma tem em si algo de
material, por não ser ato puro. Logo, é feita da matéria e, portanto, não é criada.

2. Demais. Todo ato de qualquer matéria é tirado da potência desta; pois, como a matéria é potencial
em relação ao ato, qualquer ato preexiste potencialmente na matéria. Ora, a alma é o ato da matéria
corpórea, como resulta da definição da mesma. Logo, a alma é tirada da potência da matéria.

3. Demais. – A alma é uma forma. Se, pois, é produzida por criação, pela mesma razão todas as outras
formas também o são. E, assim, nenhuma forma vem ao ser pela geração. O que é inadmissível.
Mas, em contrário, diz a Escritura: Deus criou o homem segundo a sua imagem. Logo, o homem é
segundo a imagem de Deus, pela alma. Logo, a alma veio a existir por criação.

SOLUÇÃO. – A alma racional não pode ser produzida senão por criação, o que não é verdade das outras
formas. E a razão é que, como o devir é via para o ser, a um ente convém o devir na mesma medida em
que lhe convém o ser. Ora, propriamente, considera–se como sendo aquilo que tem o ser em si mesmo,
e como subsistente nele, Por onde, só as substâncias são, própria e verdadeiramente, consideradas
entes. Ao passo que o acidente não tem o ser, mas faz com que alguma cousa seja e, por isso, se chame
ente; assim, a brancura chama–se ente porque faz alguma cousa ser branca. E por isso Aristóteles diz
que o acidente é considerado mais como dependência do ente, do que ente. E o mesmo fundamento
têm todas as outras formas não subsistentes. E, portanto, a nenhuma forma não subsistente convém,
propriamente, o devir; mas se consideram como devindo, porque os seres compostos subsistentes
devêm. Ora, a alma racional é uma forma subsistente, como antes já se estabeleceu; e por isso,
propriamente, lhe convém o ser e o devir. E como não pode ser feita de matéria preexistente corpórea,
porque então seria de natureza corpórea; nem espiritual, porque então as substâncias espirituais se
transmutariam umas nas outras, necessário é concluir que a alma só pode devir por criação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A alma tem, como elemento material, a sua própria
essência simples; e tem como elemento formal, o ser participado que, necessária e simultaneamente se
implica na essência da alma, porque o ser em si é consecutivo à forma. E a doutrina seria a mesma se se
considerasse a alma como composta de determinada matéria espiritual, como certos dizem; pois essa
matéria não é potencial em relação à outra forma, semelhante, nisso, à matéria do corpo celeste; do
contrário, a alma seria corruptível. Por onde, de nenhum modo a alma pode ser feita de uma matéria
preexistente.

RESPOSTA À SEGUNDA. – Quando se diz que um ato é tirado da potência da matéria, não se quer dizer
senão que é reduzido a ato o que antes existia em potência. Ora, como a alma racional não tem o ser
dependente da matéria corpórea, mas sim, o ser subsistente, e excede a capacidade da matéria
corpórea, como antes se disse por isso ela não é tirada da potência da matéria.

RESPOSTA À TERCEIRA. – Não há símile entre a alma racional e as outras formas como já se disse.

## Art. 3 — Se a alma racional é produzida imediatamente por Deus, ou mediante.
O terceiro discute–se assim. – Parece que a alma racional não é produzida imediatamente por Deus,
mas mediante os anjos.

1. – Pois, os seres espirituais são de ordem superior aos corpóreos. Ora, os corpos inferiores são
produzidos pelos superiores, como diz Dionísio. Logo, também os espíritos inferiores, que são as almas
racionais, são produzidos pelos superiores, que são os anjos.

2. Demais. – O fim das coisas corresponde ao princípio, pois, Deus é o princípio e o fim delas. Logo,
também a procedência das coisas, do princípio, corresponde à redução das mesmas ao fim. Ora, os
seres ínfimos são reduzidos pelos supremos, como diz Dionísio. Logo, também obtêm o ser pelos
primeiros; isto é, as almas, pelos anjos.

3. Demais. Perfeito é o ser que pode jazer outro semelhante a si, como diz Aristóteles. Ora, as
substâncias espirituais são muito mais perfeitas que as corpóreas, Mas como os corpos produzem
outros que lhes são especificamente semelhantes, com muito maior razão os anjos poderão fazer um
ser, a alma racional, que lhes é inferior pela espécie da natureza.
Mas em contrário, diz a Escritura, que Deus mesmo inspirou. no rosto do homem um assopro de vida.

SOLUÇÃO. – Alguns ensinaram que os anjos, enquanto operam em virtude de Deus, causam as almas
racionais. Mas tal opinião é absolutamente inadmissível e contrária à fé. Pois, como já se demonstrou
antes, a alma racional não pode ser produzida senão por criação; porquanto só Deus pode criar. Porque
só o primeiro agente pode agir, sem nenhum pressuposto; ao passo que o agente segundo pressupõe
algo procedente do agente primeiro, como antes já se estabeleceu. Ora, o que produz alguma cousa, de
outra, pressuposta, produz transmutando. Por onde, só Deus age criando; e nenhum outro agente age
senão transmutando. E como a alma racional não pode ser produzida por transmutação de qualquer
matéria, conclui–se que não pode ser produzida imediatamente, senão por Deus.
E daqui se deduzem as RESPOSTAS ÁS OBJEÇÕES, Pois, o causarem uns corpos outros, semelhantes ou
inferiores: e o reduzirem os superiores os inferiores, tudo isso se dá por via de transmutação.

## Art. 4 — Se a alma humana foi produzida antes do corpo.
O quarto discute–se assim. – Parece que a alma humana foi produzida antes do corpo.

1. – Pois, a obra da criação precedeu à da distinção e do ornato, como se disse antes. Ora, a alma tem o
ser produzido por criação, segundo já ficou demonstrado; ao passo que o corpo é feito para ornato.
Logo, a alma do homem foi produzida antes do corpo.

2. Demais. – A alma racional convém mais com os anjos do que com os brutos. Ora, aqueles foram
criados antes dos corpos; ou logo, desde o princípio, imediatamente com a matéria corpórea; enquanto
que o corpo do homem foi formado no sexto dia, quando já haviam sido produzidos os brutos. Logo, a
alma humana foi criada antes do corpo.

3. Demais. – O fim se proporciona com o princípio. Ora, a alma permanece, ao termo da vida,
posteriormente ao corpo. Logo, também, no princípio, foi criada antes do corpo.
Mas, em contrário, o ato próprio realiza–se na potência própria. Ora, como a alma é o ato próprio do
corpo, neste foi produzida.

SOLUÇÃO. – Segundo Orígenes, não só a alma do primeiro homem, mas as almas de todos os homens
foram criadas antes dos corpos, simultaneamente com os anjos. Pois, pensava que todas as substâncias
espirituais, tanto as almas como os anjos, iguais, pela condição da natureza, só diferem pelo mérito.
Assim, umas estão unidas aos corpos, e são as almas dos homens ou dos corpos celestes; outras, porém,
permanecem na sua pureza, conforme as diversas ordens. Mas, como já tratamos dessa opinião, agora a
deixamos de lado.
Agostinho também ensina que a alma do primeiro homem foi criada antes do corpo, com os anjos, mas,
por outra razão. E é que, diz, o corpo do homem, nas obras dos seis dias, não foi produzido em ato, mas
só nas suas razões causais. O que não se pode dizer da alma, que não foi feita de nenhuma matéria
corpórea ou espiritual preexistente, nem podia ter sido produzida por nenhuma virtude criada. Donde
conclui que a alma, em si mesma, foi criada simultaneamente com os anjos, nas obras dos seis dias, nos
quais todas as coisas foram feitas; e que depois, por vontade própria, inclinou–se a governar um corpo.
Mas isso ele não o diz afirmativamente, como as suas palavras o demonstram. Pois, escreve: Pode–se
crer, se a nenhuma autoridade das Escrituras ou a nenhum princípio verdadeiro contradisser, que o
homem foi jeito no sexto dia, de todo que a razão causal do corpo humano estivesse nos elementos do
mundo, enquanto que a alma, em si, já tinha sido criada.
Ora, esta opinião só pode ser admitida por aqueles que consideram a alma como tendo, em si, espécie e
natureza completa; e unida ao corpo, não como forma, mas só para o governar. Se, porém a alma está
unida ao corpo como forma e faz naturalmente, parte da natureza humana, tal opinião é absolutamente
inadmissível. Pois, é manifesto, que Deus instituiu os primeiros seres, no estado perfeito da sua
natureza, como o exigia a espécie de cada um. Ora, a alma, sendo parte da natureza humana, não tem
sua perfeição natural senão unida ao corpo. Por onde, não era conveniente que fosse criada sem ele.
Sustentando–se, porém, a opinião de Agostinho, quanto às obras dos seis dias, poder–se–ia dizer que a
alma humana precedeu, nessas obras, quanto a certa semelhança genérica, enquanto convém com os
anjos no atinente à natureza intelectual; mas, em si mesma, foi criada simultaneamente com o corpo.
Porém outros Santos ensinam, que tanto a alma como o corpo do primeiro homem, foram produzidos
nas obras dos seis dias.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Se a natureza da alma tivesse a espécie Íntegra, de modo
que fosse criada, em si mesma, então a OBJEÇÃO procederia, afirmando que, no princípio, foi criada, em
si mesma. Mas, como, naturalmente, ela é a forma do corpo, não podia ter sido criada separadamente,
mas tinha que o ser num corpo.
E o mesmo se deve RESPONDER À SEGUNDA OBJEÇÃO. – Pois, a alma, se tivesse uma espécie, em si
mesma, se assemelharia mais com os anjos; mas, sendo forma do corpo, pertence ao gênero dos
animais, como princípio formal.

RESPOSTA À TERCEIRA. – É pela morte, deficiência do corpo, que a alma acidentalmente permanece
posteriormente a Este. Ora, essa deficiência não podia existir ao princípio, na criação da alma.