# Questão 5: Do bem em geral
Em seguida, devemos tratar do bem. Primeiro, do bem em geral; segundo, da bondade de Deus; na
primeira questão discutem-se seis artigos:

## Art. 1 — Se o bem difere realmente do ser.
(I. Sent., dist. VIII, q.1, a.3; dist. XIX, q.5, a.1, ad 3; De Verit., q.1, a.1., q.21, a.1; De Pot., q.3, a.7, ad 6)
O primeiro discute-se assim. — Parece que o bem difere realmente do ser.

1. — Pois diz Boécio: Vejo que, nas coisas, difere o ser do bem. Logo, ser e bem diferem realmente.

2. Demais. — Nenhum ser se dá forma a si mesmo. Ora, o bem se concebe como informação do ser,
como se vê no Comentador. Logo, o bem difere realmente do ser.

3. Demais. — O bem é susceptível de mais e de menos, e o ser não o é. Logo, este difere realmente
daquele.
Mas, em contrário, Agostinho: Somos bons na medida em que somos.

SOLUÇÃO. — O bem e o ser, realmente idênticos, diferem racionalmente, o que assim se demonstra. A
essência do bem consiste em tornar alguma coisa desejável; pois, por isso, diz o Filósofo, que o bem é
o que todas as coisas desejam. Ora, é claro que uma coisa é desejável na medida em que é perfeita, pois
todos os seres desejam a própria perfeição. E como um ser é perfeito na medida em que é atual, é claro
que é bom na medida em que é ser, pois o ser é a atualidade das coisas, como resulta manifestamente
do que já se disse. Por onde, é claro, que o bem e o ser são realmente idênticos; mas, o bem acrescenta
à noção de ser a de desejável, que lhe é estranha.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o ser e o bem sejam na realidade idênticos,
contudo, como racionalmente diferem, essas duas noções não têm, tomadas em absoluto, a mesma
significação. Pois, como o ser significa, propriamente, o que é atual, e o ato, em sentido próprio, se
ordena à potência, é ente, absolutamente falando, o que se distingue, primariamente da potência pura.
Ora, tal é o caso de toda realidade substancial; e, por isso, pelo seu ser substancial, é que uma coisa é
chamada ente, em sentido absoluto. Pelos atos que se lhe acrescentarem, porém, é chamada ser, de
certo modo; assim, ser branco exprime o ser sob determinado aspecto, porque o tornar-se branco,
advindo ao já atualmente preexistente, não elimina nenhum estado potencial absoluto. Mas, bem
significa perfeição desejável e, por conseqüência, refere-se a um estado último. Por onde, o que tem a
perfeição última se chama o bem perfeito absoluto. Aquilo, porém, que não tem essa perfeição, que
deve ter, embora tenha a perfeição proveniente da atualidade, não é considerado, contudo,
absolutamente, nem perfeito, nem bom, senão só relativamente. Assim, pois, pelo seu ser primeiro, e
que é substancial, uma coisa é considerada ser, no sentido absoluto da palavra, e boa relativamente,
isto é na medida em que é ser. Pelo contrário, quanto ao último ato, é considerada ser, relativamente, e
boa, absolutamente. Por onde, o dito de Boécio, que nas coisas, difere o ser, do bem, deve ser referido
ao bem e ao ser, tomados absolutamente; pois, pelo ato primeiro, uma coisa é ser, absolutamente,
como, pelo ato último é bem, em sentido absoluto. E contudo, pelo ato primeiro, é bem, de certo modo,
assim como, de certo modo é ente, quanto ao último ato.

RESPOSTA À SEGUNDA. — O bem se concebe como informação, quando considerado, em sentido
absoluto, quanto ao último ato.
E semelhantemente, deve-se RESPONDER À TERCEIRA OBJEÇÃO, que o bem é susceptível de mais e de
menos, enquanto ato superveniente, p. ex., como ciência ou virtude.

## Art. 2 — Se o bem é logicamente anterior ao ser.
(I. Sent., dist. VIII, q.1, a.3; III Cont. Gent., cap. XX; De Verit., q. 21. a.2, ad 5; a. 3)
O segundo discute-se assim. — Parece que o bem é logicamente anterior ao ser.

1. — Pois a ordem dos nomes é relativa ao que significam. Ora, entre os nomes de Deus, Dionísio coloca
o bem, antes do ser. Logo, aquele é logicamente anterior a este.

2. Demais. — Devemos considerar como primeira a noção que se estende a maior número de objetos.
Ora, o bem tem maior extensão que o ser; pois, como diz Dionísio, o bem se estende ao que existe e ao
que não existe, ao passo que o ser, só ao que existe. Logo, o bem é logicamente anterior ao ser.

3. Demais. — O que é mais universal tem, logicamente prioridade. Ora, o bem é mais universal que o
ser, porque é, por natureza, desejável, e certos desejam mesmo o não-ser, como diz a Escritura (Mt
26,24): Melhor fora ao tal homem não haver nascido, etc. logo, o bem é logicamente anterior ao ser.

4. Demais. — não só o ser é desejável, mas também a vida, a sabedoria e coisas semelhantes. Por onde
se vê, que o ser é um caso particular do desejável, do qual o bem exprime o aspecto universal. Logo, o
bem é logicamente anterior ao ser.
Mas, em contrário, diz o livro De Causis: A primeira das coisas criadas é o ser.

SOLUÇÃO. — O ser é logicamente anterior ao bem. Pois a noção que o nome significa é aquilo que a
inteligência concebe a respeito do objeto e que exprime pela palavra. Ora, é anterior logicamente aquilo
que o intelecto concebe em primeiro lugar; e isto é o ser, porque uma coisa é cognoscível na medida em
que é atual, como diz Aristóteles. Por onde, o ser é o objeto próprio do intelecto e, portanto, é o
primeiro inteligível, assim como o som é o primeiro audível. Logo, logicamente o ser é anterior ao bem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dionísio considera os nomes divinos e os classifica
enquanto se referem à causalidade divina; pois diz, designamos a Deus pelas criaturas, como a causa,
pelos efeitos. Ora, o bem, sendo de natureza desejável, implica relação de causa final, cuja causalidade é
a primeira de todas; pois o fim é considerado causa das causas porque faz agir o agente, que, por sua
vez, move a matéria para a forma. E assim, no causar, o bem é anterior ao ser, como o fim, à forma; e é
por isso que, entre os nomes designativos da causalidade divina, o bem vem antes do ser. — Por outro
lado, os Platônicos, não distinguindo a matéria da privação, e considerando-a não-ser, davam maior
extensão à participação do bem que à do ser; mas como a matéria prima participa do bem, para o qual
tende, e como nada tende senão para o semelhante, a matéria dos platônicos, sendo não-ser, não
participa do ser. E por isso diz Dionísio que o bem se estende ao que não existe.
Donde se deduz clara a RESPOSTA À SEGUNDA OBJEÇÃO— Ou também se pode dizer que o bem se
estende ao existente e ao não-existente; não, pela predicação, mas, pela causalidade; e, assim, devemos
entender por não-existente, não o que absolutamente não existe, mas o que, sendo potencial, está
privado da atualidade. Pois o bem exerce a função de fim, no qual repousa o que já é atual e para o qual
se move o que, ainda não estando atualizado, é potencia pura. O ser, porém, implica somente a relação
de causa formal e inerente ou exemplar; ora, essa causalidade só se estende ao que já é atual.

RESPOSTA À TERCEIRA. — O não-ser é desejável, não por si, mas acidentalmente, enquanto é desejável
a suspensão de um mal, a qual se dá pelo não-ser. — Mas, a eliminação do mal só é desejável por privar
de algum ser; e, portanto, este é que é desejável em si, ao passo que o não-ser o é só acidentalmente,
enquanto o homem deseja um certo ser cuja privação não suporta. E, neste sentido, se diz que o não-ser
é um bem acidentalmente.

RESPOSTA À QUARTA. — A vida, a sabedoria e causas semelhantes são desejadas enquanto atuais; o
que em tudo isso se deseja é um certo ser. E assim, só o ser é desejável e, por conseqüência, só ele é
bom.

## Art. 3 — Se todo o ser é bom.
(I. Sent., dist. VIII, q.1, a.3; II Cont. Gent., cap. XLI; III, cap. XX; De Verit., q.21, a.2; In Boet., De Hebd.,
lect. II)
O terceiro discute-se assim. — Parece que nem todo ser é bom.

1. — Pois a idéia de bem acrescenta alguma coisa à de ser, conforme do sobredito resulta; e, portanto a
restringe, como o faz a substância, a quantidade, a qualidade e atributos semelhantes. Se, pois, a idéia
de bem restringe a de ser, nem todo ser é bom.

2. Demais. — Nenhum mal é bom, pois diz a Escritura (Is 5, 20): ai de vós os que ao mal chamais bem, e
ao bom mau! Ora, há seres maus. Logo, nem todo ser é bom.

3. Demais. — O bem é por natureza desejável. Ora, tal não é a natureza da matéria prima, que é,
somente, uma tendência ou um desejo. Logo, ela não é boa por natureza e, por tanto, nem todo ser é
bom.

4. Demais. — Como diz o Filósofo, na ordem matemática não há bem. Ora, as idéias matemáticas são
seres, pois, do contrario não constituiriam ciência. Logo, nem todo ser é bom.
Mas, em contrario. — Tudo o que não é Deus é criatura de Deus. Ora, toda criatura de Deus é boa, como
diz a Escritura, (1 Tm 4, 4); e Deus mesmo é o máximo bem. Logo, todo ser é bom.

SOLUÇÃO. — Todo ser, como tal, é bom, pois é atual e, de certo modo, perfeito, porque toda atualidade
é perfeição. Ora, esta, sendo, por natureza desejável e boa, como do sobredito resulta, conclui-se daí, a
bondade de todo ser.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A substância, a quantidade, a qualidade e tudo o que
nelas se contém, restringem o ser, aplicando-o a alguma quididade ou natureza. Assim, o bem nada
acrescenta ao ser senão o atributo de desejável e perfeito, o que convém a este em qualquer natureza
em que se encontre. Por onde, o bem não restringe o ser.

RESPOSTA À SEGUNDA. — Nenhum ser é como tal, considerado mau, mas enquanto tem alguma
deficiência; assim, considera-se mau o homem sem virtude, como a vista sem penetração.

RESPOSTA À TERCEIRA. — A matéria prima, sendo ser potencial, também é bem potencial. E embora,
com os platônicos, se possa dizer que ela é não-ser, por causa da privação que lhe é adjunta, contudo,
participa algo do bem, a saber, a sua ordenação ou aptitude para o mesmo. E, por isso, não lhe convém
o ser desejado, mas, o desejar.

RESPOSTA À QUARTA. — As idéias matemáticas não subsistem realmente separadas, pois, se
subsistissem, o ser mesmo delas seria um bem. São separáveis só racionalmente, enquanto abstraídas
do movimento e da matéria; e, assim, são estranhas ao fim, que tem natureza motora. E nem é
inconveniente haver algum ser que nosso espírito não identifica com o bem, porque a noção de ser é
anterior a de bem, como já se disse.

## Art. 4 — Se o bem tem, antes, a natureza da causa final do que as demais causas.
(I. Sent., dist. XXXIV. Q.2, a.1, ad 4; I Cont. Gent., cap. XL; De Verit., q.21, a.1; De Div. Nom., cap. I. Lect.

III; II Phys., lect. V)
O quarto discute-se assim. — Parece que o bem tem mais a natureza das outras causas do que a da
final.

1. — Pois, como diz Dionísio, o bem é louvado como belo. Ora, este implica a natureza da causa formal.
Logo, o bem implica igualmente essa natureza.

2. Demais. — O bem é difusivo de si, como resulta das palavras de Dionísio, dizendo: pelo bem é que
tudo subsiste e é. Ora, ser difusivo implica a natureza de causa eficiente. Logo, o bem tem a natureza
dessa causa.

3. Demais. — Diz Agostinho que nós existimos porque Deus é bom. Ora, nós existimos porque Deus é a
nossa causa eficiente. Logo, o bem implica a natureza de tal causa.
Mas, em contrário, diz o Filósofo: Aquilo para o que alguma coisa existe é o fim e o bem de tudo o mais.
Logo, o bem tem a natureza de causa final.

SOLUÇÃO. — Sendo o bem aquilo que todos os seres desejam, e implicando isto a idéia de fim, é claro
que o bem implica essa mesma idéia, mas também a de causa eficiente e de causa formal. Pois vemos
que aquilo que é primeiro no causar, é último no efeito; assim o fogo aquece antes de comunicar sua
forma, embora esta lhe resulte da sua forma substancial. Assim, na ordem da causalidade, primeiro,
vem o bem e o fim, que move a causa eficiente; depois, ação desta, que move para a forma; e, terceiro,
sobrevém a forma. E universalmente, quanto ao efeito: primeiro, vem a forma, que determina o ser;
segundo, nessa forma descobrimos uma virtude ativa, própria do ser enquanto perfeito, pois é perfeito
o que pode produzir algo de semelhante a si, como diz o Filósofo; terceiro, segue-se a noção do bem,
pela qual a perfeição se funda no ser.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O belo e o bem considerados em relação ao sujeito, se
identificam, porque têm o mesmo fundamento — a forma; e, por isso, o bem é louvado como belo. Mas,
racionalmente, diferem, pois o bem, propriamente, se refere ao apetite, sendo o que todos os seres
desejam; e, portanto, exerce a função de fim, porque o apetite é um como que movimento para a
realidade. O belo, porém, diz respeito à faculdade cognoscitiva, pois, chamam-se belas às coisas, que,
vistas, agradam. E, por isso, o belo consiste na proporção devida; pois os sentidos se deleitam com os
seres, devidamente proporcionados, como se lhes fossem semelhantes; porque eles, ao modo de toda
virtude cognoscitiva, são, de certa maneira, proporção. Ora, o conhecimento implicando assimilação, e
esta supondo uma forma, o belo depende, propriamente, da noção de causa formal.

RESPOSTA À SEGUNDA. — O bem é considerado difusivo de si, no mesmo sentido em que se diz que o
fim move.

RESPOSTA À TERCEIRA. — O ser dotado de vontade é considerado bom se a tem boa, porque, por meio
da vontade é que usamos de todas as nossas faculdades; e por isso não se chama bom o homem que
tem bom intelecto, mas o que tem a vontade boa. Pois a vontade visa o fim como objeto próprio; e
assim, a expressão —nós existimos porque Deus é bom — refere-se à causa final.

## Art. 5 — Se a noção de bem implica o modo, a espécie e a ordem.
(Ia. Ilae, q. 85, a.4; De Verit., q.21, a.6)
O quinto discute-se assim. — Parece que a noção de bem não implica o modo, a espécie e a ordem.

1. — Pois o bem e o ser diferem racionalmente, como já se disse. Ora, o modo, a espécie e a ordem
parece pertencerem à noção de ente; pois, diz a Escritura (Sb 11, 21): Todas as coisas dispuseste com
medida, e conta, e peso, reduzindo-se a esta trindade a espécie, o modo e a ordem; e, como diz
Agostinho — A medida determina o modo a cada coisa, o número dá-lhe espécie, e o peso a atrai para o
repouso e a estabilidade. Logo, a noção de bem não implica o modo, a espécie e a ordem.

2. Demais. — O modo, a espécie e a ordem são bens. Ora, se a noção de bem os implicasse, o modo
também seria modo, espécie e ordem, o mesmo se dando com a espécie e com a ordem; o que seria
proceder ao infinito.

3. Demais. — o mal é privação do modo, da espécie e da ordem. Ora, ele não elimina totalmente o bem.
Logo, a noção de bem não consiste no modo, na espécie e na ordem.

4. Demais. — Aquilo que implica a noção de bem não pode ser chamado mal. Oram diz-se mau modo,
má espécie, má ordem. Logo, a noção de bem não implica o modo, a espécie e a ordem.

5. Demais. — O modo, a espécie e a ordem, são causados pelo peso, pelo número e pela medida, como
se vê no passo aduzido de Agostinho. Ora, nem todos os bens tem peso, número e medida, pois diz
Ambrósio: é da natureza da luz não ter sido criada com número, peso e medida. Logo, a noção de bem
não consiste no modo, na espécie e na ordem.
Mas, em contrário, diz Agostinho: Estas três coisas — o modo, a espécie e a ordem, — existem nas
coisas feitas por Deus como bens gerais; e assim, onde elas são grandes os bens são grandes; onde
pequenas, também eles são pequenos e, onde não existem, nenhum bem existe. Ora, tal não se daria se
a noção de bem as implicasse. Logo, esta noção implica o modo, a espécie e a ordem.

SOLUÇÃO. — Um ser é considerado bom na medida em que é perfeito, pois, nessa mesma, é desejável,
como já se demonstrou. Ora, consideramos como perfeito aquilo a que nada falta, segundo o modo da
sua perfeição. E como pela forma é que cada ser é o que é, e esta tem as suas pressuposições e as suas
conseqüências necessárias, para um ente ser perfeito e bom é necessário que tenha a forma, com o que
ela preexige a determinação ou comensuração ou dos seus princípios, materiais ou eficientes; e isso é
expresso pela palavramodo, dizendo-se, por isso, que a medida determina o modo. A forma mesma, por
sua vez, é expressa pela palavra espécie, porque é a forma que constitui cada ser na sua espécie; e se diz
que o número dá a espécie porque as definições, que a significam, são como os números, segundo o
Filósofo. Pois, assim como a unidade adicionada ou subtraída ao número faz-lhe variar a espécie, assim,
as diferenças apostas ou subtraídas às definições. Da forma, em último lugar, resulta a tendência para
um fim, para a ação ou para algo semelhante, porque o ser atual age e tende para o que formalmente
lhe convém; o isso pertence ao peso e à ordem. Por onde a noção de bem, implicando a perfeição, há de
implicar o modo, a espécie e a ordem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A divisão do bem em questão não resulta do ser
enquanto perfeito e, como tal, bom.

RESPOSTA À SEGUNDA. — O modo, a espécie e a ordem chamam-se bens da mesma maneira porque se
chamam entes; não por serem como subsistentes, mas por fazerem com que certas coisas sejam entes e
boas. Mas, por isso, não é necessário tenham outros atributos, pelos quais sejam bons, pois são
considerados tais, não em virtude de uma informação estranha, mas por serem a razão formal de certas
coisas serem boas. Assim, dizemos que a brancura é um ser, não porque sejam em si mesma, um
princípio de ser, mas porque faz um sujeito ser, sob certo ponto de vista, i. é, branco.

RESPOSTA À TERCEIRA. — Um ser corresponde a uma determinada forma; por onde, quantos modos de
ser tiver um sujeito, tantas vezes haverá lugar para o modo, a espécie e a ordem. Assim, um homem
realiza uma vez essa trindade enquanto homem, outra, enquanto branco, outra enquanto virtuoso,
enquanto sábio e enquanto ao mais que se possa dizer dele. O mal, porém, priva de um desses modos
de ser; p. ex., a cegueira, privando da vista, não elimina totalmente o modo, a espécie e a ordem, mas,
só na medida em que resultem do ser dela.

RESPOSTA À QUARTA. — Como diz Agostinho, todo modo, como tal, é bom, o mesmo podendo-se
afirmar da espécie e da ordem; mas, o mau modo, a má espécie ou a má ordem chamam-se assim por
serem menores, que o que deveriam ser; ou por se não acomodarem às coisas a que se deviam
acomodar, considerando-se, portanto, maus por seres não adaptados e incongruentes.

RESPOSTA À QUINTA. — Diz-se que a natureza da luz é sem número, peso e medida, não
absolutamente, mas por comparação com as coisas corpóreas; pois a virtude da luz atinge a todos os
seres corpóreos, como qualidade ativa do céu, que é o primeiro corpo alterante.

## Art. 6 — Se o bem se divide adequadamente em honesto, útil e deleitável.
(Ila. Hae, q. 145, a. 3; II Sent., dist. 21, q. 1, a. 3; I Eth., lect. V)
O sexto discute-se assim. — Parece que o bem não se divide adequadamente em honesto, útil e
deleitável.

1. — Pois o bem, como diz o Filósofo, se reparte pelos dez predicamentos. Ora, o honesto, o útil e o
deleitável, podem-se encontrar num só. Logo, tal divisão não é adequada.

2. Demais. — Toda divisão se faz por contrariedades. Ora, as três partes da divisão supra não são
contrárias; pois o honesto também é deleitável e nada de desonesto é útil, como também diz Túlio.
Logo, tal divisão não é adequada.

3. Demais. — Quando uma coisa tem sua razão de ser em outra, ambas não constituem mais que uma.
Ora, o útil é bom, só por causa do deleitável ou do honesto. Logo, não deve ser-lhes considerado
contrário, na divisão.
Mas, em contrario, Ambrosio aceita esta divisão do bem.

SOLUÇÃO. — Esta divisão é propriamente do bem humano. Mas serve também, propriamente, para o
bem como tal, se considerarmos essa noção mais alta e largamente. Pois é bem aquilo que é desejável e
termo do movimento do apetite, termo que pode ser apreciado conforme o movimento dos corpos
naturais. Ora, o movimento de um corpo natural acaba, absolutamente falando, no seu último termo;
relativamente, porém, no termo médio, pelo qual chega ao último; e assim, chama-se termo de um
movimento qualquer ponto em que uma parte dele acaba. Porém, o termo último do movimento pode
ser tomado, em sentido amplo, como a causa mesma para o qual ele tende, p. ex., o lugar ou a forma;
ou como o repouso na mesma. Por onde, chama-se útilo que é desejável e termina o movimento do
apetite, relativamente, como meio de tender a outra coisa.Honesto se chama ao que é desejado com
uma coisa, que termina total e ultimamente o movimento do apetite, à qual, em si mesma este tende;
pois, honesto se denomina aquilo que é desejado em si mesmo. A deleitação, por fim, é o que termina o
movimento do apetite, como repouso na coisa desejada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O bem, enquanto tem o mesmo sujeito que o ente, se
reparte pelos dez predicamentos; mas em na sua noção própria, aplica-se-lhe a divisão supra.

RESPOSTA À SEGUNDA. — A referida divisão não se estabelece por contrariedades reais, mas,
nocionais. — Assim, chama-se propriamente deleitável aquilo que nada tem de desejável, além da
deleitação; podendo ser, às vezes, nocivo e desonesto. Útil é chamado aquilo que é desejado, não por si
mesmo, mas só enquanto conducente a outra coisa, como p. ex., tomar um remédio amargo. Honesto,
por fim, o que é desejado em si mesmo.

RESPOSTA À TERCEIRA. — Ao bem se aplica a tripartida divisão supra, não como se ele fosse unívoco,
isto é, predicado igualmente de cada um dos três termos; mas, como análogo, que se predica por
prioridade e posteridade. Assim, é predicado, primariamente, do honesto; secundariamente, do
deleitável e, em terceiro lugar, do útil.