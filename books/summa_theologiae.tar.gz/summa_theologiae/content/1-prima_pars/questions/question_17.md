# Questão 17: Da falsidade
Em seguida devemos tratar da falsidade. E nesta questão, discutem-se quatro artigos:

## Art. 1 — Se há falsidade nas coisas.
I Sent., dist. XIX, q. 5, a. 1; De Verit., q. 1, a. 10; V Metaph., lect. XXII; VI lect. IV.
O primeiro discute-se assim. — Parece que não há falsidade nas coisas.

1. — Pois, diz Agostinho: Se a verdade é o que é, havemos de concluir, que o falso em nenhuma parte
existe, quem quer que a isso repugne.

2. Demais. — Falso vem de falir (enganar). Ora, as coisas não enganam, como diz Agostinho, porque não
manifestam senão a sua espécie. Logo, nelas não há falsidade.

3. Demais. — Como se disse, as coisas chamam-se verdadeiras relativamente ao intelecto divino,
enquanto o imitam. Ora, qualquer coisa, como tal, imita a Deus. Logo, é verdadeira e sem falsidade.
Portanto, nenhuma coisa é falsa.
Mas, em contrário, diz Agostinho: Todo corpo é verdadeiro corpo e falsa unidade; porque imita a
unidade mas não é unidade. Ora, todas as coisas imitam a divina unidade, mas deficientemente. Logo,
em todas há falsidade.

SOLUÇÃO. — Como o verdadeiro e o falso se opõem, e os contrários têm o mesmo sujeito,
necessariamente há de existir, em primeiro lugar, a falsidade, na potência onde, em primeiro, existe a
verdade, isto é, no intelecto. Ora, nas coisas não há verdade nem falsidade, senão pela relação delas
com o intelecto. E como um ser se nomeia, absolutamente, segundo o que lhe convém, por essência, e,
relativamente, segundo o que lhe convém, por acidente, uma coisa se pode chamar falsa,
absolutamente, pela relação essencial com o intelecto de que depende e a que se compara por si.
Porém, relativamente a outro intelecto, com o qual se relacione acidentalmente, só se pode chamar
falsa relativamente.
Ora, as coisas naturais dependem do intelecto divino como as artificiais do humano. E estas chamam-se
falsas, absolutamente e em si mesmas, quando lhes falta a forma da arte; e por isso dizemos que um
artífice fez obra falsa quando falhou na operação da sua arte. Assim, pois, nas coisas dependentes de
Deus, não pode haver falsidade, relativamente ao intelecto divino, porque tudo o que existe, nelas,
procede da ordenação desse intelecto. Exceto, talvez os agentes voluntários, que têm o poder de se
subtrair a tal ordenação, nisso consistindo o mal da culpa. E, em tal sentido, os pecados chamam-se na
Escritura, falsidades e mentiras, segundo aquilo (Sl 4, 3): Por que amais a vaidade e buscais a
mentira? Assim também, e ao contrário, a operação virtuosa se chama verdade da vida, enquanto se
subordina à ordem do divino intelecto, conforme a Escritura (Jo 3, 21): Aquele que obra a verdade
chega-se para a luz.
Mas, relativamente ao nosso intelecto, com o qual as coisas naturais têm relação acidental, podem
chamar-se falsas, não simples, mas: Chamamos falsas às coisas que apreendemos como verossímeis. E o
Filósofo dizrelativamente, e isto de dois modos. Primeiro, em razão do significado; chamando-se, assim,
falso nas coisas, ao que é significado ou representado por palavra ou pensamento falso. E deste
primeiro modo, qualquer coisa pode chamar-se falsa, relativamente ao que nela não existe. Assim,
como se dissermos que é falso o diâmetro comensurável, segundo o Filósofo; ou se dissermos, com
Agostinho, que um trágico é um falso Heitor. E, ao contrário, uma coisa pode chamar-se verdadeira,
pelo que lhe convém. Segundo, em razão da causa. E, assim, chama-se falsa a uma coisa, que é causa de
se formar dela uma opinião falsa. Pois, é-nos natural julgar das coisas pela aparência exterior, porque o
nosso conhecimento, atingindo, primeiramente e em si mesmo, os acidentes exteriores, tem a sua
origem nos sentidos. Por isso, as coisas que, pelos seus acidentes externos, se assemelham a outras,
chamam-se falsas por comparação com estas últimas; assim, o fel é um falso mel e o estanho, uma falsa
prata. E, deste modo, diz Agostinho, que se chamam falsas todas as coisas a que é natural mostrarem-se
quais não são ou o que não são. E também, deste modo, chama-se falso ao homem amante das opiniões
ou locuções falsas. Mas, não pelas poder formar, porque, então, também os sapientes e os sábios se
chamariam falsos, como diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A realidade, relativamente ao intelecto, chama-se
verdadeira, pelo que é; falsa, pelo que não é. Por onde, um verdadeiro ator trágico é um falso Heitor,
como diz Agostinho. Assim pois, como há um certo não-ser, nas coisas existentes, assim também há
nelas uma certa razão de falsidade.

RESPOSTA À SEGUNDA. — As coisas nos enganam, não por si mesmas, mas, por acidente, oferecendo
ocasião à falsidade, por terem a semelhança com outras coisas, de que não têm a existência.

RESPOSTA À TERCEIRA. — Relativamente ao intelecto divino, não se chamam falsas as coisas. Porque,
então, seriam absolutamente falsas; mas, relativamente ao nosso intelecto, sendo então, falsas por
acidente.

RESPOSTA À QUARTA. — A semelhança ou representação deficiente não induz razão de falsidade,
senão quando dá ocasião à falsa opinião: por isso, não é qualquer semelhança que torna falsa uma
realidade, mas, uma semelhança tal que seja capaz de causar opinião falsa, e isso, não a toda pessoa,
mas em geral.

## Art. 2 — Se há falsidade nos sentidos.
(Infra., q. 85, a. 6; De Verit., q. 1, a. 2; III De Anima, lect. VI; IV Metaph. Lect. XII).
O segundo discute-se assim. — Parece que nos sentidos, não há falsidade.

1. — Pois, diz Agostinho: Se todos os sentidos do corpo indicam o que os afeta, ignoro o que mais se
possa exigir deles. Por onde se vê que não somos enganados pelos sentidos; e, portanto, neles não há
falsidade.

2. Demais. — O Filósofodiz que a falsidade não é própria dos sentidos, mas da fantasia.

3. Demais. — Nas vozes incomplexas não há verdade nem falsidade, mas, só, nas complexas. Ora,
compor e dividir não pertence aos sentidos. Logo, neles não há falsidade.
Mas, em contrário, diz Agostinho: Parece que todos os nossos sentidos nos enganaram, transviados pela
semelhança.

SOLUÇÃO. — Não há falsidade nos sentidos, senão do mesmo modo pelo qual há verdade. Ora, esta
neles não existe, de modo que a conheçam, mas, enquanto verdadeiramente apreendem os sensíveis,
como dissemos antes. E isso se dá, porque eles apreendem as coisas como elas são. Donde, o poder
haver neles falsidade, quando apreendem ou julgam as coisas de maneira diversa do que são. Mas, os
sentidos apenas podem conhecer as coisas, enquanto têm em si a semelhança delas. Ora, a semelhança
de uma coisa pode existir, nos sentidos, de três modos. Primariamente e em si mesma, como, p. ex., na
vista está a semelhança da cor e dos outros sensíveis próprios. Ou, em si mesma, mas não
primariamente, como, p. ex., na vista está a semelhança da figura ou da grandeza e de todos os outros
sensíveis comuns. De um terceiro modo, nem primariamente, nem em si: mas, por acidente; p. ex., na
vista está a semelhança do homem, não enquanto homem, mas enquanto tal ser colorido é homem. Por
onde, relativamente aos sensíveis próprios, os sentidos não têm conhecimento falso, senão por
acidente, e em casos excepcionais. P. ex., por não ter sido, em virtude de uma indisposição do órgão,
convenientemente recebida a forma sensível; assim como outros seres passivos, por causa da
indisposição, recebem deficientemente a impressão dos agentes. Donde vem que, pela corrupção da
língua enferma, as coisas doces parecem amargas. Porém, quanto aos sensíveis comuns, e aos por
acidente, mesmo os sentidos bem dispostos podem julgar falsamente, por não se referirem a esses
sensíveis direta, mas, acidental ou conseqüentemente, porque se referem também a outras coisas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Para os sentidos, sentir é ser afetado; donde, se se
exprimem de maneira pela qual são afetados, não nos enganamos no juízo pelo qual julgamos sentir
alguma coisa. Mas, de serem às vezes afetados de maneira diferente da realidade resulta nos
exprimirem a coisa diferentemente do que ela é; e, então, eles nos enganam em relação à coisa; mas
não, em relação ao sentir, em si mesmo.

RESPOSTA À SEGUNDA OBJEÇÃO. — Dizemos não ser a falsidade própria aos sentidos, porque não se
enganam em relação ao seu objeto próprio. Por isso, outra tradução diz mais claramente, que o sentido
do sensível próprio não é falso. À fantasia porém atribui-se a falsidade, porque representa a semelhança
da coisa, mesmo ausente. Donde, quando alguém toma a semelhança pela realidade mesma, provém de
tal apreensão a falsidade; e, por isso, o próprio Filósofo diz, que as sombras, as pinturas e os sonhos se
dizem falsos, por não existirem as realidades de que têm a semelhança.

RESPOSTA À TERCEIRA OBJEÇÃO. — A objeção procede, pois não há falsidade nos sentidos como há no
sujeito, que conhece o verdadeiro e o falso.

## Art. 3 — Se há falsidade no intelecto.
Infra., q. 58, a. 5; q. 85, a. 6; Sent., dist. XIX, q. 5, a. 1, ad 7; I Cont Gent., cap. LIX; III, cap. XVIII, De Verit.,
q. 1, a. 12; I Periherm., lect. III; III De Anima, lect XI; VI Metaph., lect. IV; IX, lect. XI.
O terceiro discute-se assim. — Parece que não há falsidade no intelecto.

1. — Pois, diz Agostinho: Todo o que se engana não entende aquilo por onde se enganou. Ora, diz-se
que há falsidade num conhecimento quando por ele nos enganamos. Logo, não há falsidade no
intelecto.

2. Demais. — O Filósofo diz, que o intelecto é sempre reto. Logo, nele não há falsidade.
Mas, em contrário, diz Aristóteles: Onde há composição de intelecções há verdadeiro e falso. Ora, tal
composição existe no intelecto. Logo, nele há verdadeiro e falso.

SOLUÇÃO. — Como as coisas têm o ser pela forma própria, assim, a potência cognoscitiva, o
conhecimento, pela semelhança da coisa conhecida. Ora, a uma coisa natural não lhe falta o ser, que,
pela sua forma, lhe convém, embora possa faltar-lhe algum acidente ou conseqüente. Assim, a um
homem podem-lhe faltar os pés, mas, não, a essência humana. Assim também à potência cognoscitiva
não lhe pode faltar o conhecimento quanto à coisa por cuja semelhança é informada, embora lhe possa
faltar algum conseqüente ou acidente dela. Pois, como dissemos, a vista não se engana relativamente
ao seu sensível próprio, mas sim, aos sensíveis comuns que lhes são conseqüentes, e aos sensíveis por
acidente. Por onde, como o sentido é informado diretamente pela semelhança dos sensíveis próprios,
assim também o intelecto, pela semelhança da quididade da coisa. Portanto, quanto à quididade, o
intelecto não se engana, como também não se engana um sentido quanto ao seu sensível próprio.
Porém, o intelecto pode enganar-se no compor ou dividir, atribuindo à coisa, cuja quididade intelige,
algo que dela não resulte ou lhe seja contrário. Pois o intelecto, julgando de tais realidades comporta-se
como os sentidos quando julgam dos sensíveis comuns acidentais; sempre conservada, contudo, a
diferença já explicada, quando tratamos da verdade, a saber, que a falsidade pode existir no intelecto,
não somente quando é falso o seu conhecimento, mas também porque ele a conhece, assim como
conhece a verdade; ao passo que nos sentidos, a falsidade não existe como conhecida, segundo já
dissemos
Como, porém, só pode existir falsidade no intelecto, quando ele compõe, também pode ela existir por
acidente, na operação do intelecto, que conhece a quididade, quando tal conhecimento implica a
composição. O que se pode dar de dois modos. De um modo se o intelecto atribuir a definição de uma
coisa, a outra; como, por ex., se atribuir ao homem a definição do círculo. E então, a definição de uma
coisa é falsa, atribuída a outra. De outro modo, quando compõe entre si partes da definição que não se
podem adunar; e então, a definição não somente é falsa, em relação a uma determinada coisa, mas é
falsa em si mesma. P. ex., se formasse essa definição —animal racional quadrúpede — o intelecto, que
assim definisse, seria falso, porque é falso ao formar essa composição — algum animal racional é
quadrúpede. Por isso, o intelecto não pode ser falso, quando conhece as quididades simples; mas, ou é
verdadeiro, ou não intelige absolutamente nada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A quididade da coisa, sendo o objeto próprio do
intelecto, dizemos propriamente que inteligimos alguma coisa quando dela julgamos, reduzindo-a
à quididade; e tal se dá nas demonstrações em que não há falsidade. E nesse sentido é que se entende a
expressão de Agostinho quando diz: Todo o que se engana não entende aquilo por onde se enganou. E
não, como querendo significar que não nos enganamos em nenhuma operação do intelecto.

RESPOSTA À SEGUNDA. — O intelecto dos princípios é sempre reto, pois, sobre eles não se engana, pela
mesma razão porque não se engana sobre a quididade. Pois, princípios evidentes são os que se
conhecem logo que se lhes conheçam os termos, porque o predicado está incluído na definição do
sujeito.

## Art. 4 — Se o verdadeiro e o falso são contrários.
O quarto discute-se assim. — Parece que o verdadeiro e o falso não são contrários.

1. — Pois, o verdadeiro e o falso opõem-se como o que é, ao que não é; porque a verdade é o que é,
como diz Agostinho. Ora, o que é e o que não é não se opõem como contrários. Logo, o verdadeiro e o
falso não são contrários.

2. Demais. — Um dos contrários não existe no outro. Ora, o falso existe no verdadeiro, pois, como diz
Agostinho,um trágico não seria um falso Heitor, se não fosse um verdadeiro trágico. Logo, o verdadeiro
e o falso não são contrários.

3. Demais. — Em Deus não há nenhuma contrariedade. Pois, diz Agostinho, nada é contrário à
substância divina. Ora, Deus se opõe à falsidade; pois, a Escritura chama ao ídolo mentira (Jr 8, 5): Têm
abraçado a mentira, i. é, os ídolos, diz a Glosa. Logo, o verdadeiro e o falso não são contrários.
Mas, em contrário, o Filósofoconsidera a falsa opinião contrária à verdadeira.

SOLUÇÃO. — O verdadeiro e o falso opõem-se como contrário e não, como a afirmação e a negação,
consoante disseram alguns. Para evidenciá-lo devemos considerar, que a negação não acrescenta nada,
nem determina sujeito algum e, por isso, pode predicar-se tanto do ser como do não-ser. P. ex., não
vendo e não-sentando. A privação, porém, não acrescenta nada, mas determina o seu sujeito. Pois, a
negação está no sujeito, diz Aristóteles; assim, cego só se chama àquele a que é natural ver. O contrário,
porém, acrescenta alguma coisa e determina o sujeito; o negro, p. ex., é uma espécie de cor. A falsidade
acrescenta alguma coisa. Pois consiste, como diz o Filósofo, em afirmar ou parecer que é alguma coisa
que não é, ou que não é o que é. Assim, pois, como a verdade estabelece a acepção adequada à coisa, a
falsidade, a que não é adequada. Logo, é manifesto, que a verdade e a falsidade são contrárias.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O que é, na realidade, é a verdade das coisas; mas o que
é, como apreendido, é a verdade do intelecto, no qual reside a verdade primariamente. Donde, o falso é
aquilo que não existe como apreendido. Ora, apreender o ser é contrário a apreender o não-ser; pois,
como prova o Filósofo, à opinião — o bem é o bem — é contrária a outra — o bem não é o bem.

RESPOSTA À SEGUNDA. — O falso não se funda no verdadeiro, que lhe é contrário, do mesmo modo
que o mal não se funda no bem contrário; mas no que lhes é sujeito. E isto se dá, tanto com a verdade,
como com a bondade, porque a verdade e o bem são comuns e convertem-se no ser. Por onde, assim
como toda privação se funda num sujeito, que é o ser, assim, todo mal se funda nalgum bem, e toda
falsidade, nalguma verdade.

RESPOSTA À TERCEIRA. — Os contrários e os opostos, privativamente, é natural fundarem-se num
mesmo sujeito; por isso, em Deus, em si mesmo considerado, não há nenhuma contrariedade, nem em
razão da sua bondade, nem da sua verdade, porque no seu intelecto não pode existir nenhuma
falsidade. Mas, relativamente à apreensão nossa, há nele contrariedade, pois, à verdadeira opinião, a
respeito de Deus, se opõe a falsa. E assim, os ídolos se chamam mentiras, opostas à verdade divina,
porque a falsa opinião, sobre eles, contraria a verdadeira, sobre a unidade de Deus.