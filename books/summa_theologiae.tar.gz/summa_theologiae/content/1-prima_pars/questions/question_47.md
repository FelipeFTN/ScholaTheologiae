# Questão 47: Da distinção das coisas em comum.
Depois da produção do ser das criaturas, deve-se considerar a distinção das coisas. E esta consideração
será tripartida. Pois, primeiro, consideraremos a distinção das coisas em comum. Segundo, a distinção
do bem e do mal. Terceiro, a distinção da criatura espiritual e da corporal.
Sobre o primeiro ponto quatro artigos se discutem:

## Art. 1 — Se a multidão e a distinção das coisas vêm de Deus.
(II Cont. Gent., cap. XXXIX usque XLV inclus.: III, cap. XCVII; De Pot., q. 3, a. 1, ad 9; art. 16; Compend.
Theol., cap. LXXI, LXXII, CII, XII Metaphys., lect. II: De Causis, lect. XXIV).
O primeiro discute-se assim. – Parece que a multidão e a distinção das coisas não vêm de Deus.

1. – É natural à unidade produzir a unidade. Ora, Deus é maximamente um, como resulta do já provado.
Logo, não produz senão um efeito.

2. Demais. – O exemplado assemelha-se ao seu exemplar. Ora, Deus é a causa exemplar do seu efeito,
como já antes se disse. Logo, Deus, sendo único, também um só é o seu efeito e não vários.

3. Demais. – O que depende do fim ao fim se proporciona. Ora, o fim da criatura é só um, a saber, a
divina bondade, como antes se demonstrou. Logo, o efeito de Deus não é mais de um.
Mas, em contrário, diz a Escritura (Gn 1) que Deus separou a luz das trevas edividiu as águas das
águas.Logo, a distinção e a multidão das coisas vêm de Deus.

SOLUÇÃO. – Vários pensaram diversamente sobre a causa da distinção das coisas.
Assim, alguns atribuíram-na à matéria só, ou de simultaneidade com um agente. À matéria só, como
Demócrito e todos os antigos físicos, que só admitiam a causa material; e, de acordo com estes, a
distinção das coisas provém do acaso, pelo movimento da matéria. Porém à matéria simultaneamente
com um agente atribuiu Anaxágoras a multidão das coisas, ensinando que o intelecto distingue as
coisas, separando o que estava de mistura com a matéria. Mas esta opinião não pode se manter, por
duas razões. Primeira, é que jáantes se demonstrou ter sido também a própria matéria criada por Deus.
Por onde, é necessário reduzir a uma causa mais alta a distinção que, por algum modo pertence à
matéria. Segunda, que a matéria existe por causa da forma e não inversamente. Ora, as coisas se
distinguem pelas formas próprias. Logo, não é a matéria que lhes dá a distinção, mas antes e
inversamente, na matéria criada há deformidade para se acomodar às diversas formas.
Outros porém atribuíram a distinção das coisas aos agentes segundos, como Avicena ensinando que
Deus, inteligindo-se, produziu a inteligência primeira, na qual, não sendo a essência idêntica à
existência, teve necessariamente começo a composição de potência e ato, como a seguir se verá. Assim,
pois, a primeira inteligência, inteligindo a causa primeira, produziu a inteligência segunda; inteligindo-se
a si mesma, no que tem de potência, produziu o corpo do céu que ela move; por fim, inteligindo-se a si
mesma, no que têm de ato, produziu a alma do céu. Mas esta opinião não pode se manter, por duas
razões. Primeira, porque, como já antes se demonstrou, só a Deus pertencendo o criar, as coisas que
não podem ser causadas senão por criação são produzidas só por Deus. Ora, tais coisas são todas as que
estão submetidas à geração e à corrupção. Segunda, porque, de acordo com tal posição, a universa-
lidade das coisas não proviria da intenção do agente primeiro, mas do concurso de muitas causas
agentes. Ora, isso é o mesmo que dizer que provêm do acaso; e assim, pois, o complemento do
universo, consistente na diversidade das coisas, proviria do acaso, o que é impossível.
Donde o dever-se admitir que a multidão e a distinção das coisas vêm da intenção do agente primeiro,
Deus. Pois, trouxe as coisas ao ser, para comunicar a sua bondade às criaturas, que a representam. E,
como esta não pode ser representada suficientemente por uma só criatura, produziu muitas e diversas;
e assim o que falta a uma, para representar a divina bondade, é suprido por outra. Pois, a bondade,
existente em Deus pura e simplesmente, bem como uniformemente, existe nas criaturas multíplice e
divididamente. Por onde, com mais perfeição participa da divina bondade e a representa todo o
universo do que outra criatura qualquer. – E por ser a divina sabedoria a causa da distinção das coisas,
diz Moisés que as coisas são distintas pelo Verbo de Deus, que é a concepção da sabedoria; e isso
mesmo diz a Escritura (Gn 1, 3): E disse Deus: Faça-se a luz... E dividiu a luz das trevas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O agente natural age pela forma pela qual existe, e esta
sendo só uma para cada ser, só o ser uno é que age. Porém o agente voluntário, como Deus, segundo o
que já antes se viu, age pela forma inteligida. Portanto, não repugnando à unidade e à simplicidade de
Deus inteligirmuitas coisas, como já vimos, resulta que Ele, embora seja único, pode fazer muitas coisas.

RESPOSTA À SEGUNDA. – A objeção valeria quanto ao exemplado perfeitamente representativo do
exemplar, que se não multiplica senão materialmente; por onde a imagem incriada, que é perfeita, é só
uma. Porém nenhuma criatura representando perfeitamente o exemplar primeiro, a divina essência,
esta pode ser representada por muitas. E contudo, chamando-se às idéias exemplares, à pluralidade das
coisas corresponde na mente divina a das idéias.

RESPOSTA À TERCEIRA. – Nas ciências especulativas, o meio da demonstração, o qual perfeitamente
demonstra a conclusão, é só um; mas os meios prováveis são muitos. E semelhantemente, nas
operações, não se exige que seja mais de um o meio que leva ao fim, quando esse meio é adequado,
para que assim digamos, ao fim. Mas assim não se comporta a criatura com o fim, que é Deus. Por onde,
é necessário sejam elas multiplicadas.

## Art. 2 — Se a desigualdade das coisas provém de Deus.
(Infra, q. 65. a. 2; II Cont. Gent., cap. XLIV, XLV; III, cap. XCVII; De Pot., q. 3, a. 16; De Anima, a. 7;
Compend. Theol., cap. LXXIII, c. II; De Div. Nom., cap. IV. lect. XVI).
O segundo discute-se assim. – Parece não provém de Deus a desigualdade das coisas.

1. – Quem é ótimo produz coisas ótimas. Ora, entre coisas ótimas, uma não o é mais que outra. Logo
Deus, que é ótimo, deve fazer todas as coisas iguais.

2. Demais. – A igualdade é efeito da unidade, como diz Aristóteles. Ora, Deus é um. Logo, fez todas as
coisas iguais.

3. Demais. – A justiça consiste em dar a indivíduos desiguais coisas desiguais. Ora, Deus é justo em todas
as suas obras. Como, porém, a sua operação, pela qual comunica o ser às coisas, não pressupõe nelas
nenhuma desigualdade, resulta que as fez todas iguais.
Mas, em contrário, a Escritura (Eccle 33, 7-8): Porque é que um dia é preferido a outro dia, uma luz a
outra luz, e um ano a outro ano, provindo todos do mesmo sol? Foi a ciência do Senhor que os
diferenciou.

SOLUÇÃO. – Orígenes, querendo excluir a opinião dos que admitem distinção nas coisas, pela
contrariedade dos princípios do bem e do mal, ensinou que, no princípio, todas as coisas foram criadas
por Deus iguais. Dizia, pois, que Deus primeiramente criou só as criaturas racionais, e todas iguais. Nelas
nasceu a desigualdade primeiramente do livre arbítrio, por se converterem umas mais ou menos a Deus
e se afastarem outras mais ou menos d'Ele. Donde, as criaturas racionais que, por livre arbítrio, se
converteram para Deus, foram promovidas às diversas ordens de anjos, segundo a diversidade dos
méritos. Porém, as que se afastaram de Deus foram ligadas a diversos corpos, segundo a diversidade do
pecado; e tal diz ser a causa da criação e da diversidade dos corpos.
Mas, segundo essa opinião, a universalidade das criaturas corpóreas não teria como causa a bondade de
Deus a elas comunicada, mas sim a punição do pecado, o que vai contra as palavras da Escritura (Gn 1,
31): Viu Deus todas as coisas que tinha feito e eram muito boas. E, como diz Agostinho, que há de mais
insensato que pretender que este sol único neste mundo único não foi destinado pelo Artífice supremo
ao ornamento e a utilidade da criação corpórea, mas que tal se deu por uma alma ter pecado? E por
conseqüência, se cem almas tivessem pecado este mundo teria cem sóis?
Portanto devemos dizer que, assim como a sabedoria de Deus é a causa da distinção das coisas, assim
também da desigualdade. O que do seguinte modo se esclarecerá. Há dupla distinção nas coisas: uma
formal, para as que só especificamente diferem; outra, porém, material, para as que só numericamente
diferem. Mas como a matéria existe pela forma, a distinção material existe pela formal. Por onde vemos
que, nas coisas incorruptíveis, há um só indivíduo de uma espécie, porque esta em um só
suficientemente se conserva; mas nos seres geráveis e corruptíveis são muitos os indivíduos de uma
espécie, para a conservação desta. Por onde se vê que a distinção formal é mais importante que a
material. Ora, a distinção formal sempre requer a desigualdade, porque, como diz Aristóteles, as formas
das coisas são como os números, nos quais as espécies variam pela adição ou subtração da unidade. Por
onde, nos seres naturais, vemos que as espécies são gradativamente ordenadas; assim, os compostos
são mais perfeitos do que os elementos, as plantas do que os minerais, os animais do que as plantas e
os homens do que os outros animais; e, em cada uma dessas classes, encontram-se espécies mais
perfeitas do que as outras. Portanto, sendo a divina sabedoria a causa da distinção das coisas, para a
perfeição do universo, assim o será da desigualdade. Pois, não seria perfeito o universo se nas coisas só
se encontrasse um grau de bondade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – O agente ótimo deve produzir o seu efeito total ótimo;
não contudo que faça ótima, pura e simplesmente, qualquer parte do todo, mas ótima em proporção
com o todo; assim, desapareceria a bondade do animal se qualquer parte dele tivesse a dignidade dos
olhos. Assim, pois, Deus fez ótimo todo o universo, ao modo da criatura; não fez ótimas porém cada
uma das criaturas, mas uma melhor que outra. E por isso de cada uma delas diz a Escritura (Gn 1, 4): Viu
Deus que a luz era boa, e assim com outras. Mas de todas juntas diz: Viu Deus todas as coisas que tinha
feito; e eram muito boas.

RESPOSTA À SEGUNDA. – O que primeiro procede da unidade é a igualdade, e, depois, a multiplicidade.
Por isso do Pai, a quem, segundo Agostinho, se apropria a unidade, procedeu o Filho, a quem se
apropria a igualdade; e, depois procedeu a criatura, à qual convém a desigualdade. Contudo também a
criatura participa de uma certa igualdade, a saber, a de proporção.

RESPOSTA À TERCEIRA. – Foi essa razão a que moveu Orígenes. Mas não tem lugar senão na retribuição
dos prêmios, cuja desigualdade é devida à desigualdade no mérito. Mas, na constituição das coisas, não
há desigualdade das partes em virtude de qualquer desigualdade precedente, quer dos méritos, quer da
disposição da matéria; mas em virtude da perfeição do todo. O que bem se vê nas obras da arte, pois
não é por ter matéria diversa que o teto difere dos alicerces, mas o artífice busca matéria diversa para
que a casa seja perfeita, pelas diversas partes e tal matéria ele a faria, se pudesse.

## Art. 3 — Se nas criaturas há uma ordem dos agentes.
O terceiro discute-se assim. – Parece que, nas criaturas não há ordem dos agentes.

1. – Pois, o agente que age sem intermediário é mais perfeito que o agente por intermediário. Ora, Deus
é agente potentíssimo. Logo, não age por intermediário e, assim, uma criatura não age sobre outra.

2. Demais. – Um agente faz, por natureza, outro ser semelhante a si. Ora, aquilo à semelhança do que
alguma coisa se faz é o exemplar. Se, pois, uma criatura é causa agente em relação a outra, segue-se
que os seres mais dignos são os exemplares dos inferiores; opinião reprovada por Dionísio.

3. Demais. – Agente e fim incidem na mesma espécie, como diz Aristóteles. Se, pois, uma criatura é
causa ativa de outra, será também uma a causa final da outra. O que vai contra a Escritura (Pr 16,
4): Tudo fez oSenhor por causa de si mesmo.
Mas, em contrário, diz o Apóstolo (Rm 13, 1): Todo homem esteja sujeito aos poderes
superiores. E Dionísio diz que a lei da Divindade é reduzir a si os seres inferiores por meio dos
superiores. Logo, uma criatura age sobre outra.

SOLUÇÃO. – Alguns, opinando segundo a lei dos Mouros, ensinaram que as criaturas nenhuma ação
têm; assim diziam que o fogo não aquece, mas Deus pelo fogo. – Ora, segundo estes, seriam em vão
atribuídas às coisas as virtudes ativas, as qualidades e as formas. Por onde, deve-se dizer que a
desigualdade mesma constituída nas coisas criadas pela divina sabedoria, como já se viu, exige que uma
criatura atue sobre outra. Pois, a desigualdade das criaturas resulta de ser mais perfeita uma do que
outra. Ora, o mais perfeito está para o menos perfeito como o ato para a potência. E como é da
natureza do existente em ato agir sobre o existente em potência, é necessário que uma criatura atue
sobre outra. Mas assim como a criatura, pelo seu ser atual, participa de Deus, ato puro, assim também
de Deus participa quanto à virtude de agir, e age por virtude de Deus como a causa segunda por virtude
da causa primeira.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Tudo o que se faz pela ação da criatura Deus pode fazer
sem a criatura. Não é portanto por deficiência do seu poder que age mediante a criatura; mas por
abundância da sua bondade; donde provém que não somente comunica à criatura que seja em si boa,
mas ainda a dignidade de ser causa de bondade para outras.

RESPOSTA À SEGUNDA. – É reprovada por Dionísio a opinião dos que ensinavam que certas
inteligências separadas são exemplares primeiros; porque o primeiro de todos os exemplares é Deus.
Nada porém impede que, secundariamente, uma criatura seja o exemplar de outra.

RESPOSTA À TERCEIRA. – O fim último de todos os seres é Deus. Há todavia outros fins subordinados a
este, enquanto uma criatura é ordenada para outra como para o seu fim; isto é, as mais imperfeitas
ordenadas às mais perfeitas, como a matéria para a forma; os simples para o composto; as plantas para
os animais; os animais para os homens, como se vê na Escritura (Gn 1). Por onde se vê, que a ordem do
universo se manifesta no agir uma criatura sobre outra, no ser uma feita à semelhança de outra e no ser
uma o fim de outra.

## Art. 4 — Se há um mundo só ou vários.
(De Pot., q. 3, a. 16, ad 1: XII Metaphys., lect. X; I De Cael. et Mund., lect. XVI sqq.).
O terceiro discute-se assim. – Parece que não há só um mundo, mas vários.

1. – Pois, como diz Agostinho, é inconveniente dizer que Deus criou as coisas sem razão. Mas, pela
mesma razão por que criou um mundo podia criar muitos, por não estar o seu poder limitado à criação
de um só, e ser infinito, como antes se demonstrou. Logo, Deus criou vários mundos.

2. Demais. – A natureza faz o que é melhor, e, com maioria de razão, Deus. Ora, melhor é haver vários
mundos que um só, porque melhor é haver muitos do que um só. Logo vários mundos foram feitos por
Deus.

3. Demais. – Tudo o que teve uma forma numa matéria pode ser numericamente multiplicado,
permanecendo a espécie a mesma, porque a multiplicação numérica vem da matéria. Ora, o mundo tem
uma forma material. Pois, assim como dizendo homem exprimo a forma, e dizendo este
homem exprimo a forma na matéria; assim, dizendo mundo exprimo a forma, e dizendo este
mundo exprimo a forma na matéria. Logo, nada impede haja diversos mundos.
Mas, em contrário, diz a Escritura (Jo 1, 10): O mundo foi feito por ele; falando do mundo no singular,
como se só existisse um.

SOLUÇÃO. – A ordem existente nas coisas criadas por Deus manifesta a unidade do mundo. Pois, se diz
uno este mundo pela unidade da ordem, segundo a qual uns seres se ordenam a outros. Porque todos
os seres criados por Deus mantêm entre si e para com Ele uma ordem, como já antes se demonstrou.
Por onde, é necessário que todas as coisas pertençam a um só mundo. E só puderam admitir vários
mundos os que admitiam não ser uma sabedoria ordenadora, mas o acaso, a causa do mundo; como
Demócrito, dizendo que do concurso dos átomos nasceu este mundo e poderiam resultar infinitos
outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A razão de ser o mundo um só é que todas as coisas
devem ser ordenadas por uma só ordem e em relação a um ser. E por isso Aristóteles concluiu a unidade
de Deus governador, da unidade da ordem existente nas coisas; e Platão pela unidade do exemplar
prova a unidade do mundo, que é como exemplado.

RESPOSTA À SEGUNDA. – Nenhum agente visa a pluralidade material como fim, porque a multidão
material não tem termo certo, mas, por si, tende ao infinito; ora, este repugna à noção de fim. Mas
quando se diz que é melhor existirem muitos mundos que um só, isso se diz segundo a multidão
material. Ora, tal melhoria não está na intenção de Deus agente; porque, pela mesma razão se poderia
dizer, se Deus tivesse feito dois mundos, que melhor teria sido se tivesse feito três, e assim ao infinito.

RESPOSTA À TERCEIRA. – O mundo consta da sua matéria total. Pois, não é possível existir outra terra
diferente desta, porque qualquer outra, onde quer que se achasse, tenderia para o centro desta. E a
mesma razão vale para os outros corpos, que são partes do mundo.