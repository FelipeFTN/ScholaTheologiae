# Questão 81: Da sensualidade.
Em seguida deve-se tratar da sensualidade, sobre a qual três artigos se discutem:

## Art. 1 — Se a sensualidade é somente apetitiva.
(II Sent., Dist. XXIV, q. 2, a. 1; De Verit., q. 25, a. 1).
O primeiro discute-se assim. ― Parece que a sensualidade não somente é apetitiva mas também
cognitiva.

1. ― Pois, Agostinho diz, que o movimento sensual da alma, que se exerce pelos sentidos do corpo, é-
nos comum com os animais. Ora, os sentidos do corpo estão contidos na virtude cognitiva. Logo, a
sensualidade é virtude cognitiva.

2. Demais. ― Coisas que entram na mesma divisão pertencem ao mesmo gênero. Ora, Agostinho divide
a sensualidade por oposição com a razão superior e a inferior, que pertencem ao conhecimento. Logo,
também a sensualidade é uma virtude cognitiva.

3. Demais. ― Na tentação do homem, a sensualidade está no lugar da serpente. Ora, a tentação dos
nossos primeiros pais, desempenhou-se como anunciante e proponente do pecado, o que pertence à
virtude cognitiva. Logo, a sensualidade é uma virtude cognitiva.
Mas, em contrário, a sensualidade se define: o apetite das coisas que pertencem ao corpo.

SOLUÇÃO. ― Sensualidade é palavra tirada do movimento sensual, de que fala Agostinho; assim, como
do ato se tira o nome da potência, como da visão a vista. Ora, o movimento sensual é o apetite
conseqüente à apreensão sensível; pois, o ato da virtude apreensiva não se chama propriamente
movimento, como a ação do apetite. Porque, a operação da virtude apreensiva se completa estando as
coisas apreendidas no apreendente; ao passo que a operação da virtude apetitiva se completa pelo
inclinar-se do apetente para a coisa apetecida. Por onde, a operação da virtude apreensiva é assimilada
ao repouso; ao passo que a da virtude apetitiva mais se assimila ao movimento. Por isso, por
movimento sensual se entende a operação da virtude apetitiva. Assim, a sensualidade é o nome do
apetite sensitivo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― O dito de Agostinho, que o movimento sensual da alma
se exerce pelos sentidos do corpo, não quer dizer que os sentidos do corpo estejam compreendidos na
sensualidade; mas antes, que o movimento desta é uma como inclinação para os sentidos do corpo,
enquanto apetecemos as coisas apreendidas por eles. E assim, estes são como que os preâmbulos da
sensualidade.

RESPOSTA À SEGUNDA. ― A sensualidade se divide por oposição com a razão superior e a inferior,
enquanto estas têm de comum o ato da moção. Pois, a virtude cognitiva, à qual pertencem a razão
superior e a inferior, é motiva; como também a virtude apetitiva, à qual pertence a sensualidade.

RESPOSTA À TERCEIRA. ― A serpente não só mostrou e propôs o pecado, mas também inclinou para o
afeto deste; e por isto é que a sensualidade é representada pela serpente.

## Art. 2 — Se o apetite sensitivo se divide em irascível e concupiscível, como potências diversas.
(Infra, q. 82, a. 5; III Sent., dist. XXVI, q. 1, a. 2; De Verit., q. 25, a. 2 De Malo, q. 8, a. 3; III De Anima, lect

XIV).
O segundo discute-se assim. ― Parece que o apetite sensitivo não se divide em irascível e
concupiscível, como potências diversas.

1. ― Pois, cada potência da alma se refere a uma contrariedade, como a vista, ao branco e ao negro,
conforme já foi dito. Ora, o conveniente e o nocivo são contrários. Portanto, como o concupiscível diz
respeito ao conveniente, e o irascível, ao nocivo, resulta que à mesma potência da alma pertencem o
irascível e o concupiscível.

2. Demais. ― Ao apetite sensitivo pertence o que convém sensualmente. Ora, o que assim convém é
objeto do concupiscível. Logo, nenhum apetite sensitivo é diferente do concupiscível.

3. Demais. ― O ódio pertence ao irascível, pois, diz Jerônimo: Possuamos no irascível o ódio dos vícios.
Ora, o ódio, como contrário do amor, pertence ao concupiscível. Logo, a faculdade do concupiscível é a
mesma que a do irascível.
Mas, em contrário, Gregório Nisseno e Damasceno dizem que são duas as virtudes, o irascível e o
concupiscível, partes do apetite sensitivo.

SOLUÇÃO. ― O apetite sensitivo é, genericamente, uma só potência, que se chama sensualidade; mas
divide-se em duas potências, que são espécies do apetite sensitivo, a saber, a irascível e a concupiscível.
E isto se evidencia considerando que, nas coisas naturais corruptíveis, deve existir, não somente a
inclinação para conseguir o conveniente e fugir o nocivo, mas também para resistir às coisas que,
corrompendo e sendo contrárias, trazem impedimento e causam dano ao que é conveniente. Assim, o
fogo tem inclinação natural, não só para afastar-se do lugar inferior, que não lhe é conveniente, e para
tender ao superior, que lho é, mas também para resistir ao que lhe traz corrupção e impedimento. Ora,
sendo o apetite sensitivo a inclinação conseqüente à apreensão sensitiva, assim como o apetite natural
é a conseqüente à forma natural, necessário é haver, na parte sensitiva, duas potências apetitivas. Uma,
pela qual o animal se inclina, absolutamente, a buscar o que lhe é conveniente, conforme ao sentido, e a
fugir o que é nocivo; e, essa se chama concupiscível. Outra, porém, pela qual resiste ao que se opõe às
coisas convenientes e lhes causam dano, e essa se chama irascível; donde o considerar-se como objeto
desta potência aquilo que é árduo, pois ela tende a superar e vencer os contrários.
Mas estas duas inclinações não se reduzem a um mesmo princípio; porque, por vezes, o animal arrosta a
dor, contra a inclinação do concupiscível, para se opor ao que lhe é contrário, seguindo a inclinação do
irascível. Por onde se vê que as paixões do irascível repugnam às do concupiscível. Pois, a
concupiscência, acesa, diminui a ira e esta, acesa, diminui aquela na maior parte dos casos. E por aí é
também claro que o irascível pugna pelo concupiscível e o defende, insurgindo-se contra o que, de um
lado, impede as coisas convenientes ao concupiscível e por este apetecidas e, de outro, causa danos que
o concupiscível quer evitar. Donde vem, que todas as paixões do irascível começam pelas do
concupiscível e nelas terminam; assim, a ira, nascendo da pena que a provoca, termina pela alegria,
depois que se vingou. E é por isso que os animais lutam pelas coisas do concupiscível, a saber, as que
dizem respeito ao alimento e as venéreas, como diz Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A virtude concupiscível diz respeito tanto ao
conveniente como ao inconveniente; ao passo que a irascível visa resistir ao inconveniente, contra o
qual luta.

RESPOSTA À SEGUNDA. ― Assim como, nas virtudes apreensivas da parte sensitiva, há uma virtude
estimativa, perceptiva das coisas que não causam mutação no sentido, conforme já se disse (q. 78, a. 4);
assim também, no apetite sensitivo, há uma virtude apetitiva do que lhe é conveniente, não segundo a
deleitação do sentido, mas segundo é útil ao animal, para a sua defesa. E esta é a virtude irascível.

RESPOSTA À TERCEIRA. ― O ódio pertence, absolutamente, ao concupiscível; mas, em razão da
impugnação causada pelo ódio, pode pertencer ao irascível.

## Art. 3 — Se o irascível e o concupiscível obedecem à razão.
(Iª IIae., q. 17, art. 7; De Verit., q. 25, a. 4; I Ethic., lect. XX).
O terceiro discute-se assim. ― Parece que o irascível e o concupiscível não obedecem à razão.

1. ― Pois, são partes da sensualidade. Ora, esta não obedece à razão, sendo por isso
denominada serpente por Agostinho. Logo, o irascível e o concupiscível também não lhe obedecem.

2. Demais. ― O que obedece a alguém não lhe repugna. Ora, o irascível e concupiscível repugnam à
razão, conforme a Escritura (Rm 7, 23): Mas sinto nos meus membros outra lei que repugna à lei do meu
espírito. Logo, o irascível e o concupiscível não obedecem à razão.

3. Demais. ― Assim como a virtude apetitiva é inferior à parte racional da alma, assim também o é a
sensitiva. Ora, esta não obedece à razão, pois não ouvimos nem vemos quando queremos. Logo,
semelhantemente, nem as virtudes do apetite sensitivo, a saber, o irascível e o concupiscível, lhe
obedecem.
Mas, em contrário, diz Damasceno, a parte obediente à razão e que se deixa por ela persuadir se divide
em concupiscência e ira.

SOLUÇÃO. ― O irascível e o concupiscível obedecem à parte superior, em que residem o intelecto ou
razão e a vontade, de dois modos: um quanto à razão; outro, quanto à vontade.
Assim, obedecem à razão, quanto aos atos próprios deles. E isso porque ao apetite sensitivo, nos
animais, é natural ser movido pela virtude estimativa; como, p. ex., a ovelha, tendo o lobo como
inimigo, teme. Ora, como já ficou dito (q. 78, a. 4), em lugar da estimativa o homem tem a virtude
cogitativa, chamada por certos razão particular, por ser a que compara entre si as intenções individuais.
Donde o ser natural ao apetite sensitivo, no homem, mover-se por ela. Mas a essa razão particular
mesma é natural ser movida e dirigida pela razão universal; e daí vem que, nos raciocínios silogísticos,
de proposições universais se tiram conclusões particulares. Por onde, como é claro, a razão universal
impera sobre o apetite sensitivo, que se divide em concupiscível e irascível, e obedece àquela. E como
deduzir conclusões singulares, de princípios universais, não é função do simples intelecto, mas da razão,
resulta o dizer-se que o irascível e o concupiscível mais obedecem à razão do que ao intelecto. E isso
todos podem experimentar em si mesmos; pois, a aplicação de certas considerações universais mitiga
ou instiga a ira, o temor e afetos semelhantes.
À vontade, porém, está sujeito o apetite sensitivo, quanto à execução, que se faz pela virtude motiva.
Pois, nos animais, o movimento se segue, imediatamente, ao apetite concupiscível e ao irascível; assim,
a ovelha, temendo o lobo, foge imediatamente; e isso porque não há, nos animais, um apetite superior
que repugne. Ao passo que o homem não se move imediatamente pelo apetite concupiscível e pelo
irascível; mas espera o império da vontade, que é apetite superior. Ora, em todas as potências motivas
ordenadas, o segundo motor não move senão em virtude do primeiro. Por onde, o apetite inferior não
basta para mover, sem que nisso consinta o superior. E isso diz o Filósofo: o apetite superior move o
inferior, como a esfera superior, a inferior.
É, pois, desse modo, que o irascível e o concupiscível estão sujeitos à razão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ― A sensualidade é representada pela serpente, naquilo
que a primeira é próprio, quanto à parte sensitiva. Porém, o irascível e o concupiscível sobretudo
denominam o apetite sensitivo, quanto ao ato ao qual induzem a razão, como já se disse.

RESPOSTA À SEGUNDA. ― Como diz o Filósofo, deve-se distinguir, no animal, o principado despótico e o
político. Assim, a alma domina o corpo pelo principado despótico; porém, o intelecto domina o apetite
pelo principado político e real. Ora, chama-se principado despótico aquele pelo qual alguém governa
escravos, que, como nada têm de seu, nenhuma faculdade têm para resistir, seja no que for, ao império
de quem manda. Ao passo que se chama principado político e real aquele em virtude do qual alguém
governa homens livres, que, embora sujeitos ao regime de quem preside, tendo contudo algo de
próprio, podem opor-se ao império de quem manda. Ora, é pelo principado despótico, que a alma
governa o corpo, porque os membros do corpo não podem resistir ao império da alma, em nada; mas,
imediatamente, ao desejo desta, movem-se às mãos, os pés e qualquer outro membro susceptível de
mover-se pelo movimento voluntário. Porém o intelecto ou razão governam o irascível e o concupiscível
pelo principado político; porque o apetite sensível, tendo algo de próprio, pode opor-se ao império da
razão. Pois, é natural a esse apetite ser movido, não somente pela estimativa, nos animais, e pela
cogitativa, no homem, que é dirigido pela razão universal, mas também pela imaginativa e pelo sentido.
Por onde, experimentamos que o irascível ou o concupiscível repugnam à razão, quando sentimos ou
imaginamos algo de deleitável, que a razão proíbe, ou de triste, que ela ordena. Assim que, pelo
repugnarem, em alguma coisa, à razão, não se exclua que o irascível e o concupiscível obedeçam à
mesma.

RESPOSTA À TERCEIRA. ― Os sentidos externos necessitam, para os seus atos, dos sensíveis externos,
que neles causam mutação e cuja presença não depende do poder da razão. Mas as virtudes internas,
tanto as apetitivas como as apreensivas, não necessitam das coisas externas. E, portanto, sujeitam-se ao
império da razão, que pode, não somente instigar ou mitigar o afeto da virtude apetitiva, como também
formar os fantasmas da virtude imaginativa.