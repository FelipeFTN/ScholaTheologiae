# Questão 73: Das coisas pertencentes ao sétimo dia.
Em seguida, devemos considerar as coisas pertencentes ao sétimo dia.
E, sobre este assunto, três artigos se discutem:

## Art. 1 — Se o sétimo dia deve ser considerado como o do acabamento das obras divinas.
O primeiro discute–se assim. – Parece que o sétimo dia não deve ser considerado como o do
acabamento das obras divinas.

1. – Pois, tudo o que neste século se realizou se inclui nas obras divinas. Ora, além de ser a consumação
dos séculos, no fim do mundo, como diz a Escritura, o tempo da encarnação de Cristo também é tempo
de um certo acabamento; pois, diz a mesma: tempo da plenitude; e o próprio Cristo, moribundo, disse:
Tudo está consumado. Logo, o acabamento das obras divinas não foi próprio do sétimo dia.

2. Demais. – Quem completa a sua obra faz alguma cousa. Ora, não se lê que Deus tivesse feito alguma
cousa no sétimo dia; mas, antes, que descansou de todas as obras. Logo, o acabamento das obras não é
próprio do sétimo dia.

3. Demais. – Sendo perfeito o que não carece de nada do que deve ter não se pode considerar completo
aquilo a que muitas coisas, não supérfluas, se acrescentam. Ora, depois do sétimo dia, foram feitas
muitas coisas e produzidos muitos indivíduos; e mesmo certas espécies novas, que frequentemente
aparecem, sobretudo, de animais gerados da putrefacção. E também Deus cria quotidianamente novas
almas e foi nova a obra da encarnação, da qual diz a Escritura: O Senhor criou uma causa nova sobre a
terra. Novas são as obras milagrosas, das quais diz a mesma Escritura: Renova os teus prodígios e faze
novas maravilhas. Muitas causas por fim são inovadas na glorificação dos santos, conforme o passo: E o
que estaca sentado no trono disse: Eis que eu renovo todas as causas. Logo, o acabamento das obras
divinas não deve ser atribuído ao sétimo dia.
Mas, em contrário, diz a Escritura: E Deus acabou no sétimo dia a obra que tinha feito.

SOLUÇÃO. – Dupla é a perfeição de uma cousa: a primeira e a segunda. A primeira torna perfeitas as
coisas, na sua substância; e essa perfeição é a forma do todo, resultante da integridade das partes.
Porém a perfeição segunda é fim. E este ou é operação; é assim que o fim do citarista é tocar cítara; ou
é algo a que se chega pela operação; assim, o fim do edificador é a casa que edifica. Ora, como a forma
é o princípio da operação, a perfeição primeira é a causa da segunda. A perfeição última, porém, fim de
todo o universo, é a perfeita beatitude dos santos, que existirá na consumação última do século. Ora, a
perfeição atribuída ao sétimo dia, e que foi a da primeira instituição das coisas, é a primeira, consistente
na integridade do universo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como se disse, a perfeição primeira é a causa da segunda.
Ora, a consecução da beatitude requer duas condições: a natureza e a graça; sendo que a perfeição
mesma da beatitude será no fim do mundo, como se disse. Mas esta consumação preexistiu
causalmente: quanto à natureza, na primeira instituição das coisas; quanto à graça, na encarnação de
Cristo, pois, a graça e a verdade foi trazida por Jesus Cristo, como diz a Escritura. Assim que, no sétimo
dia, foi a consumação da natureza; na encarnação de Cristo, a da graça; no fim do mundo, a da glória.

RESPOSTA À SEGUNDA. – No sétimo dia Deus fez alguma cousa. Não, criando novas criaturas, mas
governando–as e movendo–as às suas operações próprias; o que, de algum modo, já pertence a uma
certa incoação da perfeição segunda. Por onde, consumação das obras, segundo a nossa tradução, é
atribuída ao sétimo dia. Mas, segundo outra tradução, é atribuída ao sexto. E ambas estas traduções se
podem admitir, sendo, no sexto dia, a consumação quanto à integridade das partes do universo; e no
sétimo, quanto à operação das partes. – Ou se pode dizer, que, no movimento contínuo, enquanto uma
cousa ainda puder mover–se, não se pode considerar o movimento como perfeito, antes do repouso;
pois, este é que indica a consumação do movimento. Ora Deus, podendo fazer mais criaturas, além das
que fez, nos seis dias, o fato mesmo de ter cessado, no sétimo, de criar novas, se considera como a
consumação das suas obras.

RESPOSTA À TERCEIRA. – Nada do que, a seguir, foi feito por Deus é de maneira totalmente nova, que
não tenha preexistido, de algum modo, nas obras dos seis dias. Assim, certas coisas preexistiram
materialmente, como a formação da mulher da costela de Adão. Outras, porém, preexistiram, nas obras
dos seis dias, não só material, mas também causalmente; assim, os indivíduos agora gerados
preexistiram, nos primeiros indivíduos das suas espécies. Porém, se aparecerem algumas espécies
novas, essas preexistiram em certas virtudes ativas; assim, os animais gerados da putrefação são
produzidos pelas virtudes das estrelas e dos elementos, virtudes que desde o princípio eles receberam,
mesmo se forem produzidas novas espécies de tais animais. Também certos animais de nova espécie
nascem, por vezes, da união de animais especificamente diversos; assim, do asno e da égua é gerado o
mulo. E esses animais também preexistiram, nas obras dos seis dias. Outros, porém, preexistiram pela
semelhança; assim, as almas, que são criadas; e, semelhantemente, a obra da encarnação, pois, corno
diz a Escritura, o Filho de Deus foi feito por semelhança com os homens. E também a glória espiritual
preexistiu, por semelhança, nos anjos; e a corporal, no céu, sobretudo no empíreo. Por onde diz a
Escritura: Não há nada novo debaixo do sol... porque ela já existiu nos séculos que passaram antes de
nós.

## Art. 2 — Se Deus descansou de todas as suas obras no sétimo dia.
O segundo discute–se assim. – Parece que Deus não descansou de todas as suas obras, no sétimo dia.

1. – Pois, diz a Escritura: Meu Pai até agora não cessa de obrar, e eu obro também incessantemente.
Logo, não descansou de todas as suas obras, no sétimo dia.

2. Demais. – O repouso se opõe ao movimento ou ao trabalho, que às vezes é causado do movimento.
Ora, Deus produziu as suas obras, imóvel e sem trabalho. Logo, não se pode dizer que tivesse
descansado delas no sétimo dia.

3. Se se disser que Deus descansou no sétimo dia, porque mandou ao homem descansar, responde–se o
seguinte: o descanso contrapõe–se à operação. Ora o dito: Deus criou, ou fez isto ou aquilo não se
interpreta como significando que Deus mandou criar ou fazer. Logo, também não é interpretação
satisfatória dizer, que Deus descansou porque mandou o homem descansar.
Mas, em contrário, diz a Escritura: Descansou no sétimo dia de toda a obra que tinha jeito.

SOLUÇÃO. – O repouso se opõe propriamente, ao movimento e, por consequente, ao trabalho,
resultante do movimento. Mas, embora este, em acepção própria, seja próprio aos corpos, todavia
aplica–se também às coisas espirituais, de duplo modo. Primeiro, enquanto que toda operação é
chamada movimento; assim, mesmo a bondade divina, de certo modo, se move e dirige para as coisas,
porque a elas se comunica, como diz Dionísio. Segundo, o desejo tendente a um objeto se chama de
certo modo movimento. Por onde, também o repouso pode ser tomado em dupla acepção; como
cessação das obras ou como satisfação do desejo. – Ora, de ambos os modos se diz que Deus descansou
no sétimo dia. Do primeiro, por ter cessado, nesse dia, de criar novas criaturas; pois, nada fez a seguir
que não estivesse incluído, de algum modo, nas primeiras obras, como se disse. Do segundo, porque
Deus tendo a sua beatitude no gozo de si mesmo não precisava das coisas que criou. Por isso não se diz
que, feitas as obras, nelas repousou, como se delas precisasse, para a sua beatitude; mas, sim que
repousou delas, isto é, em si mesmo, pois a si se basta e satisfaz o seu desejo. E embora repousasse em
si mesmo abeterno, contudo, o tê–lo feito, depois das obras, é o próprio do sétimo dia; e é isso a que
Agostinho chama repousar das obras.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Deus até agora não cessa de obrar, conservando e
administrando as criaturas criadas, e não criando novas.

RESPOSTA À SEGUNDA. – O repouso não se opõe ao trabalho ou ao movimento; mas à produção de
novas coisas e ao desejo tendente a algum objeto, como se disse.

RESPOSTA À TERCEIRA. – Assim como Deus só em si mesmo repousa e tem no gozo de si a sua
beatitude, assim também nós nos tomamos felizes unicamente pela fruição de Deus. E por isso, faz–nos
repousar nele, das suas e das nossas obras. Por onde, embora seja exposição aceitável dizer que Deus
repousou, porque nos manda repousar, todavia não é a única, sendo mesmo, a outra, principal e
primeira.

## Art. 3 — Se a benção e a santificação são próprias do sétimo dia.
O terceiro discute–se assim. – Parece que a bênção e a santificação não são próprias do sétimo dia.

1. – Pois, costuma–se considerar abençoado e santo qualquer tempo em que aconteça algum bem, ou
em que se evite algum mal. Ora, para Deus nada acresce ou deperece; quer opere, quer cesse de operar.
Logo, não é próprio ao sétimo dia especial bênção e santificação.

2. Demais. – Bênção vem de bondade. Ora, o bem é difusivo e comunicativo de si, segundo Dionísio.
Logo, mais deviam ser abençoados os dias em que produziu as criaturas, do que quando cessou de
produzi–las.

3. Demais. – Cada um dos dias em que foram criadas as novas criaturas é comemorado por uma bênção,
pois, de cada um deles se diz : E Deus viu que era bom. Logo, não era necessário que, após a produção
de todas as criaturas, fosse abençoado o sétimo dia.
Mas, em contrário, diz a Escritura: Abençoou o dia sétimo, e o santificou, porque nele tinha cerrado de
toda a sua obra.

SOLUÇÃO. – Como se disse antes, o repouso de Deus, no sétimo dia, se compreende em dupla acepção.
Pela primeira, significa que cessou Deus de fazer novas obras, conservando e governando, apenas as
criaturas já criadas. Pela segunda, repousou em si mesmo, depois das obras. Assim, pela primeira, a
benção é própria do sétimo dia; pois, como antes se disse, ela supõe a multiplicação. Por onde, foi dito
às criaturas abençoadas: Crescei e multiplicai–vos. Ora, a multiplicação das coisas se faz pela atividade
das criaturas; em virtude da qual se geram os semelhantes dos semelhantes. – Pela segunda, é própria
ao sétimo dia a santificação. E a santificação máxima de um ser, consistindo no repousar em Deus,
chamam–se santas as coisas consagradas a Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – A santificação do sétimo dia não está em poder alguma
cousa crescer ou decrescer, para Deus; mas em que, para as criaturas, alguma cousa acresce, pela
multiplicação e pelo repouso, em Deus.

RESPOSTA À SEGUNDA. – Nos primeiros seis dias foram produzidas as coisas, nas suas primeiras causas;
mas depois, por essas primeiras causas, as coisas se multiplicam e conservam; o que também pertence à
bondade divina, cuja perfeição se ostenta, sobretudo, em que, só nela, Deus repousa; bem como nós,
gozando–a.

RESPOSTA À TERCEIRA. – O bem comemorado em cada um dos seis dias pertence à instituição primeira
da natureza; porém, a bênção pertence ao sétimo dia, para a propagação da natureza.