# Questão 54: Do conhecimento angélico.
Considerado o que pertence à substância do anjo, deve se considerar o que lhe diz respeito ao
conhecimento. Ora, esta consideração será quadripartita. Assim, primeiro, deve-se considerar o que
pertence à virtude cognoscitiva do anjo. Segundo, o que pertence ao meio pelo qual o anjo conhece.
Terceiro, o que é conhecido por ele. Quarto, o modo do conhecimento angélico.
Sobre o primeiro ponto cinco artigos se discutem:

## Art. 1 — Se o inteligir do anjo é a sua substância.
(Opusc, XV, De Angelis, cap. XIII)
O primeiro se discute assim. — Parece que o inteligir do anjo é a sua substância.

1. — Pois o anjo é mais sublime e simples que o intelecto agente da alma. Ora, a substância do intelecto
agente é a sua ação, como está claro em Aristóteles e em Averroes. Logo com maior razão, a substância
do anjo é a sua ação, a saber, o inteligir.

2. Demais. — O Filósofodiz que a ação do intelecto é vida. Ora, sendo o viver a essência dos viventes,
como diz Aristóteles, resulta que a vida é essência. Logo, a ação do intelecto é a essência do anjo que
intelige.

3. Demais. — Se os extremos são idênticos, o meio não difere deles, porque mais dista um extremo do
outro, do que o meio. Ora, no anjo se identificam o inteligente e o inteligido, ao menos quando o anjo
intelige a sua essência. Logo o inteligir, meio entre o inteligente e o inteligido, identifica-se com a
substância do anjo inteligente.
Mas, em contrario, mais difere da substância de uma coisa a ação do que a existência mesma da coisa.
Ora, de nenhuma criatura a existência é substância, porque isto só é próprio de Deus, como resulta do
anteriormente dito. Logo, nem do anjo, nem de qualquer outra criatura a ação é a substância.

SOLUÇÃO. — É impossível a ação do anjo, ou de qualquer outra criatura, ser a sua substância. Pois a
ação é propriamente a atualidade da virtude, como a existência é a da substância ou essência. Ora, é
impossível um ser, que não é ato puro, mas tem algo de potencial, ser a sua atualidade, porquanto esta
repugna a potencialidade. E como só Deus é ato puro, só nele a substância é a existência e o agir. —
Demais. Se o inteligir fosse a substância do anjo, seria necessário que esse inteligir fosse subsistente.
Ora, não podendo haver mais de um inteligir subsistente, como não pode haver mais de um abstrato
subsistente, a substância de um anjo não se distinguira da de Deus, que é o inteligir mesmo subsistente,
nem da de outro anjo. — Se, além disso, o anjo mesmo fosse o seu inteligir, não poderia haver graus
mais e menos perfeitos, no inteligir, pois isto se dá pela participação diversa do inteligir em si.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dito, que o intelecto agente é a sua ação, é uma
predicação, não por essência, mas por concomitância; porque, estando a sua substância em ato,
imediatamente, quanto nessa substância está, segue-se-lhe a ação. O que não se dá com o intelecto
possível, que só age depois de atualizado.

RESPOSTA À SEGUNDA. — A vida não está para o viver como a essência para a existência, mas como a
corrida para o correr, em que aquela significa um ato em abstrato e este, em concreto. Donde se não
segue que, se viver é existir, a vida seja essência. Todavia, algumas vezes, a vida é considerada como
essência; assim, na expressão de Agostinho, que a memória, a inteligência e a vontade são uma essência
e uma vida. Mas não é isso o que quer dizer o Filósofo quando afirma que a ação do intelecto é vida.

RESPOSTA À TERCEIRA. — A ação transitiva para algo extrínseco é, realmente, um meio entre o agente
e o paciente; mas a que permanece no agente não é senão e unicamente pelo modo de significar. Pois,
realmente, ela resulta da união do objeto com o agente; assim, é de unificar-se o inteligido com o
inteligente que resulta o inteligir, um como efeito diferente de um e outro.

## Art. 2 — Se o inteligir do anjo é a sua essência.
O segundo discute-se assim. — Parece que o inteligir do anjo seja a sua essência.

1. — Pois, para os viventes o viver é a essência, como diz Aristóteles. Ora, o inteligir é, de certo modo,
viver, como diz o mesmo. Logo, o inteligir do anjo é a sua essência.

2. Demais. — Uma causa está para outra como um efeito para outro. Ora, a forma pela qual o anjo
existe é a mesma pela qual intelige, pelo menos, a si mesmo. Logo o seu inteligir se lhe identifica com a
essência.
Mas, em contrario. O inteligir do anjo é o seu movimento, como se vê claramente em Dionísio. Oram a
essência não é movimento. Logo, a essência do anjo não é o seu inteligir.

SOLUÇÃO. — A ação do anjo não é a sua essência como não é a de nenhuma criatura. Pois, há duplo
gênero de ação, como diz Aristóteles. Uma transitiva para algo de exterior, causando-lhe paixão, como
queimar e cortar. Outra, porém, não passa para algo de extrínseco mas permanece no próprio agente,
como sentir, inteligir e querer; e por tal ação, nada de extrínseco se muda, mas tudo se passa no próprio
agente que age. Ora, é manifesto que, no primeiro gênero, a ação não pode ser a essência mesma do
agente, pois esta é constitutiva do agente em si, ao passo que a ação considerada eflui do agente para o
ato. A ação do segundo gênero, porém, tem, por natureza, a infinidade ou absolutamente ou de certo
modo. Absolutamente como: o inteligir, cujo objeto é o verdadeiro; o querer, cujo objeto é o bem; e
convertendo-se ambos com o ser, ambos, por essência, se referem a tudo e recebem a espécie do
objeto. De certo modo, porém, o sentir é infinito, por se referir a todos os seres sensíveis, como, p. ex., a
visão a todos os visíveis. Todavia, o ser de qualquer criatura está incluído num gênero e numa espécie;
ao passo que só o ser de Deus é absolutamente infinito compreendendo em si tudo, como diz Dionísio.
Por isso só a essência divina é o divino inteligir e o divino querer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Viver, umas vezes, se toma pela essência mesma do
vivente; outras vezes, porém, pela operação vital, isto é, a operação pela qual se manifesta um ser vivo.
E, neste sentido, o Filósofo diz que inteligir é, de certo modo, viver, distinguindo assim os diversos graus
de seres vivos pelas diversas operações vitais.

RESPOSTA À SEGUNDA. — A essência mesma do anjo é a razão de todo o seu ser; não, porém, a de todo
o seu inteligir, porque não pode inteligir tudo pela sua essência. Por onde, na sua noção própria,
enquanto é uma determinada essência, respeita a existência mesma do anjo; mas lhe respeita o inteligir
pela noção de um objeto mais universal, i. é. o verdadeiro ou o ente. E assim é claro que, embora seja a
forma a mesma, não é esta todavia, segundo a mesma noção, o princípio de existir e de inteligir. E, por
isso, não se segue que, no anjo, se identifiquem a essência e o inteligir.

## Art. 3 — Se a virtude ou a potência intelectiva do anjo difere da sua essência.
(Infra, q. 77, a. 1; q. 79, a. 1)
O terceiro discute-se assim. — Parece que a virtude ou potência intelectiva do anjo não difere da sua
essência.

1. — Pois, inteligência e intelecto designam a potência intelectiva. Mas Dionísio, em vários lugares de
seus livros, chama aos anjos intelectos e inteligências. Logo, o anjo é sua potência intelectiva.

2. Demais. — Se a potência intelectiva do anjo é diferente da essência deste, é necessário seja um
acidente, pois chamamos acidente de um ser ao que é diferente da essência. Ora, a forma simples não
pode ser sujeito, como diz Boécio. Logo, o anjo não é forma simples, o que vai contra o já estabelecido.

3. Demais. — Agostinho diz que Deus fez a natureza angélica aproximada d´Ele; porém. A matéria prima
aproximada do nada. Donde resulta que o anjo é mais simples que a matéria prima, como mais próximo
de Deus. Mas, a matéria prima é a sua potência. Logo, com maior razão, o anjo é a sua potência
intelectiva.
Mas, em contrario, Dionísiodiz que os anjos se dividem em substância, virtude e operação. Logo, neles,
uma coisa é a substância, outra a virtude e outra a operação.

SOLUÇÃO. — Nem no anjo, nem em nenhuma criatura, a virtude ou potência operativa é o mesmo que
a essência. E isto assim se prova. Como a potência é relativa ao ato, é necessário que, tal a diversidade
dos atos, tal a das potências; e por isso se diz que um ato próprio corresponde a uma potência própria.
Ora, em toda criatura, a essência difere da existência e aquela está para esta como a potência para o
ato, segundo resulta do que já foi dito. O ato, porém, ao qual é relativa a potência operativa é a
operação. Ora, no anjo, o inteligir não se lhe identifica com a essência, como não se identifica com esta
nenhuma outra operação, quer no anjo quer em qualquer outro ser criado. Por onde, a essência do anjo
não é a sua potência intelectiva, como a essência de nenhuma criatura é a sua potência operativa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O anjo se chama intelecto e inteligência porque todo o
seu conhecimento é intelectual. Porém o conhecimento da alma é, em parte, intelectual e, em parte,
sensitivo.

RESPOSTA À SEGUNDA. — A forma simples, sendo ato puro, não pode ser sujeito de nenhum acidente;
porque o sujeito está para o acidente como a potência para o ato. E um tal ser é só Deus; sendo essa
forma à qual se refere Boécio no lugar citado. Porém a forma simples que não é a sua existência mas
está para esta como a potência para o ato, pode ser o sujeito do acidente e, precipuamente, do acidente
resultante da espécie, pois este pertence à forma; ao passo que o acidente do individuo, não resultante
da espécie total, resulta da matéria, que é o princípio de individuação. E uma tal forma simples é o anjo.

RESPOSTA À TERCEIRA. — A potência da matéria corresponde ao ser mesmo substancial; não, porém, a
operativa, que corresponde ao ser acidental. E, por isso, não há símile.

## Art. 4 — Se no anjo há os intelectos agente e possível.
(II Cont. Gent., cap. XCVI)
O quarto discute-se assim. – Parece que no anjo há os intelectos agente e possível.

1. — Pois, o Filósofo diz que, assim como em toda a natureza há um princípio que é a causa de todas as
coisas serem feitas, e outro que as faz a todas, assim também o mesmo se dá com a alma. Ora, o anjo é
uma natureza de certa espécie. Logo, há nele os intelectos agente e possível.

2. Demais. — Receber é próprio do intelecto possível; iluminar, porém, é próprio do intelecto agente,
como se vê em Aristóteles. Ora, um anjo recebe iluminação de outro que lhe é superior e ilumina o
inferior. Logo, há nele os intelectos agente e possível.
Mas, em contrário, os intelectos agente e possível, em nós supõem relação com os fantasmas, que estão
para o intelecto possível, como as cores para a visão; e, para o intelecto agente, como as cores para a
luz, segundo se vê em Aristóteles. Ora, tal não se dá com o anjo. Logo, neste não há os intelectos agente
e possível.

SOLUÇÃO. — A necessidade de supor, em nós, um intelecto possível, foi porque, de fato, ora,
inteligimos em potência e não em ato. Donde ser necessário existir uma virtude potencial em relação
aos inteligíveis, antes do ato mesmo de inteligir mas que se atualize, em relação a eles, quando adquire
a ciência e, depois, quando raciocina. E uma tal virtude se chama intelecto possível. Por outro lado, a
necessidade de se supor um intelecto agente está em que as naturezas das coisas materiais, que nós
inteligimos, não subsistem fora da alma como imateriais e inteligíveis em ato, mas são somente, como
tais, inteligíveis em potência. Donde ser forçoso existir alguma virtude que torne tais naturezas
inteligeveis em ato, e tal virtude, em nós, se chama intelecto agente.
Ora, ambas essas necessidades não existem nos anjos porque estes não são, nunca, inteligentes em
potência somente, em relação às coisas que naturalmente inteligem; nem os inteligíveis deles são
potenciais, mas atuais; pois, inteligem, primária e principalmente, as coisas imateriais, como a seguir se
verá. E, portanto, não pode haver neles os intelectos agentes e possível, senão equivocamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Filósofo admite a existência desses dois princípios em
todos os seres susceptíveis de geração e vir-a-ser, como as suas próprias palavras o demonstram.
Porém, nos anjos, a ciência não é gerada, mas existe naturalmente. Por isso não se lhes deve atribuir a
agência e a possibilidade.

RESPOSTA À SEGUNDA. — Ao intelecto agente é próprio o iluminar, não, por certo, outro ser
inteligente, mas os inteligíveis, atualizando-os, pela abstração. Porém, ao intelecto possível é próprio o
ser potencial em relação aos cognoscíveis naturais; e, por vezes, atualizar-se. donde, o fato de um anjo
iluminar a outro não pertence à essência do intelecto agente; nem à do intelecto possível pertence o de
ser iluminado quanto aos mistérios sobrenaturais, em relação a cujo conhecimento esse intelecto está,
por vezes, em potência. Se, contudo, alguém quiser chamar a tais fatos intelectos agente e possível, fa-
lo-á equivocamente; nem devemos nos importar com as denominações.

## Art. 5 — Se os anjos têm somente o conhecimento intelectual.
(III Cont. Gent., cap. CVIII; De Malo, q. 16, a. 1, ad 14)
O quinto discute-se assim. — Parece que os anjos não têm somente o conhecimento intelectual.

1. — Pois, diz Agostinhoque nos anjos há a vida que intelige e sente. Logo, tem a potência sensitiva.

2. Demais. — Isidoro diz que os anjos conhecem muitas coisas por experiência. Ora, esta consta de
muitos fatos rememorados, como diz Aristóteles. Logo, têm eles também a potência memorativa.

3. Demais. — Dionísio diz que, nos demônios, a fantasia é proterva. Ora, a fantasia pertence à virtude
imaginativa. E, pela mesma razão, os anjos, por serem da mesma natureza.
Mas, em contrario, diz Gregório que o homem sente, como os animais, e intelige, como os anjos.

SOLUÇÃO. — A nossa alma tem certas potências, cujas operações se exercem por órgãos corpóreos; e
tais operações são o ato de certas partes do corpo, como a visão o é dos olhos e a audição, dos ouvidos.
Porém, ela tem certas faculdades, cujas operações não se exercem por órgãos corpóreos, como a
inteligência e a vontade; e tais operações não são o ato de nenhuma parte do corpo. Ora, os anjos, não
tendo corpos que lhes estejam naturalmente unidos, como no sobredito se colhe, só o intelecto e a
vontade, dentre as faculdades humanas, podem lhes convir. E mesmo o Comentador reconhece que as
substâncias separadas se dividem em inteligência e vontade. Pois, convém à ordem do universo que a
suprema criatura intelectual o seja total e não parcialmente, como a nossa alma. E, por isso, os anjos são
também chamados Intelectos e Inteligências, como antes já se disse.
E quanto às OBJEÇÕES em contrario pode-se lhes responder de duplo modo. — Ou que as autoridades
citadas seguem a opinião dos que ensinavam terem os anjos e os demônios corpos que lhes estão
naturalmente unidos. E assim Agostinho, nos seus livros, usa freqüentemente dessa opinião, embora
sem pretender afirmá-la; e por isso diz que não se deve gastar muito tempo com tal assunto. — Ou
então, de outro modo, pode-se responder que tais autoridades, e outras semelhantes, devem ser
interpretadas como por comparação. Pois, assim como o sentido tem apreensão certa do sensível
próprio, assim é costume dizer-se que também o intelecto sente as coisas por uma apreensão certa,
chamada, igualmente, sentença. Porém a experiência, podendo ser atribuída aos anjos, por semelhança
das coisas conhecidas, não o pode pela virtude cognoscitiva. Assim, há em nós experiência quando
conhecemos o singular pelos sentidos; ma os anjos, embora conheçam o singular, como a seguir se verá,
não o conhecem pelos sentidos. A memória, contudo, podemos admiti-la, nos anjos, na acepção que
Agostinhoa admite em a nossa alma, se bem não lhes possa convir considerada como parte da alma
sensitiva. Semelhantemente, a fantasia proterva é atribuída aos demônios por termo uma falsa
estimação prática do verdadeiro bem; pois, o engano, em nós, propriamente resulta da fantasia, pela
qual, à vezes, tomamos as semelhanças das coisas pelas próprias coisas, como acontece com os
adormecidos e os loucos.