# Questão 100: Da condição da prole a gerar, quanto à justiça.
Em seguida devemos tratar da questão da prole a gerar, quanto à justiça. Nesta, se discutem dois
artigos:

## Art. 1 — Se os homens nasceram justos.
O primeiro discute-se assim. – Parece que no estado de inocência os homens não nasceram justos
(Tradução do artigo inteiro por mim, pode e deve conter erros).

1. – Pois Hugo de São Vítor diz: "Antes do pecado, o primeiro homem gerou filhos livres do pecado; mas
não herdeiros da justiça paterna."

2. – Demais. – A justiça é efetuada pela graça, como o Apóstolo diz em Romanos 5,16-21. Atualmente, a
graça não é passada de um para outro, pois seria natural; mas é infundida apenas por Deus. Logo, os
filhos não nasceriam justos.

3. – Demais. – A justiça está na alma. Mas a alma não é transmitida pelos pais. Logo, tampouco a justiça
seria transmitida dos pais para os filhos.
Mas, em contrário, Anselmo diz: “Enquanto o homem não pecasse, ele teria gerado filhos dotados com
justiça e alma racional”.

SOLUÇÃO. – O homem gera uma semelhança específica para si mesmo. Daí quaisquer qualidades
acidentais resultam da natureza da espécie, o pai e o filho devem ser semelhantes, a menos que a
natureza falhe no seu funcionamento, o que não teria ocorrido no estado de inocência. Mas acidentes
individuais não existem necessariamente tanto no pai como no filho. Agora, a justiça original, em que o
primeiro homem foi criado, foi um acidente pertencente a natureza das espécies, não como causado
pelos princípios das espécies, mas como um dom conferido por Deus na natureza humana inteira. Isto é
claro do fato que os opostos estão no mesmo gênero; e o pecado original, que é oposto à justiça
original, é chamado de pecado da natureza, onde é transmitido do pai para a próle; e por esta razão
também, os filhos devem ser assimilados a seus pais no que diz respeito à justiça original.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Estas palavras de Hugo são para ser entendidas não como
o hábito da justiça, mas à ação.

RESPOSTA À SEGUNDA. – Alguns dizem que os filhos deveriam nascer, não com a justiça da graça, que é
o princípio do mérito, mas com a justiça original. Mas uma vez que a raiz da justiça original, que conferiu
justiça ao primeiro homem quando ele foi feito, consiste na sujeição sobrenatural da razão de Deus, em
que a sujeição resulta da graça santificante, como explicado acima, devemos concluir que se os filhos
nascessem em justiça original, eles também deveriam ter nascido em graça; assim dissemos acima que o
primeiro homem foi criado em graça. Esta graça, contudo, não deve ter sido natural, pois não teriam
sido transmitido pela virtude do sêmem; mas conferido ao homem imediatamente ao receber a alma
racional. Do mesmo modo que a alma racional, que não é transmitida pelos pais, é infundida por Deus a
medida que o corpo humano está apto para recebê-la.
Donde se deduz clara a RESPOSTA À TERCEIRA OBJEÇÃO.

## Art. 2 — Se no estadode inocência, os filhos haviam nascidos confirmados na justiça.
In Sent. l.2 d.20 q.2 a.3 ad 5.7; De Malo q.5 a.4 ad 8; Quodl 5 q.5 a.1.O segundo discute-se assim. –
Parece que no estado de inocência as crianças nasceram confirmadas na justiça (Tradução do artigo
inteiro por mim, pode e deve conter erros).

1. – Diz Gregório comentando Jó 3,13: (Pois agora, dormindo, eu estaria calado e repousaria no meu
sono, etc): “Se a queda do homem não tivesse degradado aos primeiros pais, não gerariam filhos para o
inferno, mas apenas gerariam os que devem agora devem ser salvos pelo Redentor”. Logo, todos
nasceriam confirmados na justiça.2. – Demais. – Anselmo diz: “Se os primeiros pais não houvessem
caído na tentação, seriam confirmados, junto com sua descendência, para nunca mais poder pecar”.
Logo, os filhos nasceriam confirmados na justiça.3. – Demais. – O bem é mais poderoso que o mal. Mas
no pecado do primeiro homem havia força para arrastar ao pecado todos os seus descendentes. Logo,
se o primeiro homem se mantivesse na justiça, todos os seus descendentes haveriam sido confirmados
na justiça.4. – Demais. – O anjo que vence a tentação, mesmo que outros caiam, imediatamente é
confirmado na justiça para que não pudessem pecar. Logo, de modo semelhante, o homem, se
houvesse vencido a tentação, seria confirmado. Mas ele teria gerado filhos como ele. Logo, seus filhos
nasceriam confirmados na justiça.
Mas, em contrário, Agostinho diz: "Quão feliz seria a sociedade humana se nem eles, isto é, os primeiros
pais, houvessem cometido o mal que transmitiram aos seus descendentes, nem tampouco descendente
algum cometesse pecado pelo que merecesse ser condenado". Com isso, se dá a entender que, se os
primeiros homens não tivessem pecado, algum de seus descendentes teria podido pecar. Logo, não
deveriam nascer confirmados na graça.SOLUÇÃO. – Não parece possível que os filhos em estado de
inocência nasceram confirmados na justiça. É evidente que os filhos ao nascer não possuíriam uma
perfeição superior a de seus pais no momento de gerá-los. E os pais, mesmo se gerassem, não estariam
confirmados na justiça, pois a criatura racional se diz que está confirmada na justiça quando alcança a
bem-aventurança pela visão clara de Deus, a quem, ao ser bondade por essência, não pode ser
rejeitado, dado que todo quanto se deseja e se ama está em ordem desta suma verdade. Mas estamos
falando segundo a lei geral, porque, por um privilegio especial, como a fé ensina sobre a Virgem Maria,
pode suceder o contrário, e logo que Adão alcançasse a bem-aventurança pela visão de Deus, viria a ser
espiritual em inteligência e corpo, acabando assim sua vida animal e, com ela, a geração. Por isso, é
evidente que os filhos não nasceríam confirmados na justiça.DONDE A RESPOSTA À PRIMEIRA

OBJEÇÃO. – Se Adão não tivesse pecado não geraria filhos para o inferno, isto é, ninguém contrairia seu
pecado, que é causa do inferno. Mas poderiam chegar alí se usassem mal sua liberdade. Pode também
contestar-se que, ainda quando fossem condenados ao inferno pelo pecado, não se deveria estar
confirmados na graça, sem uma especial providência que os guardaria imunes de pecado.RESPOSTA À

SEGUNDA. – O que diz Anselmo não é uma afirmação, e sim uma opinião. Isto se prova no seu mesmo
modo de falar quando diz: "Parece que, se não houvessem caído, etc"RESPOSTA À TERCEIRA. – Este
argumento não é conclusivo, ainda quando Anselmo afirmou tal coisam como aparece em suas palavras.
Os descendentes dos primeiros pais não são arrastados de tal modo ao pecado que não possam se
voltar para a justiça. Isto é próprio dos condenados. Por isso tampouco transmítiriam uma tal
necessidade de não pecar que lhes fizera absolutamente impecáveis. Isto é próprio dos bem-
aventurados.RESPOSTA À QUARTA. – Não vale a comparação do homem com o anjo. O homem tinha
livre arbítrio, mutável antes da escolha e depois dela. Mas não é o caso dos anjos, como dissemos
anteriormente ao estuda-los.