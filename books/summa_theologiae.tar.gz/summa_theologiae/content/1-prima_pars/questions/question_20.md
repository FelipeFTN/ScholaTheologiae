# Questão 20: Do Amor de Deus.
Em seguida devemos tratar do que pertence absolutamente à vontade de Deus. Ora, em nossa parte
apetitiva residem as paixões da alma, como a alegria, o amor, e outras; e os hábitos das virtudes morais,
como a justiça, a fortaleza e outros. Donde, primeiro, trataremos do amor de Deus, e, segundo, da
justiça e da misericórdia.

## Art. 1 — Se em Deus há amor.
Infra., q. 82, a. 5, ad 1; III Sent., dist. XXXII, a. 1, ad 1; I Cont. Gent., cap. XCI; IV, cap. XIX; De Div. Nom.,
cap. IV, lect. IX.
O primeiro discute-se assim. — Parece que em Deus não há amor.

1. — Pois, em Deus não há nenhuma paixão. Ora, o amor é uma paixão; logo, em Deus não há amor.

2. Demais. — O amor, a ira, a tristeza, e paixões semelhantes se dividem por oposição. Ora, a tristeza e a
ira só se dizem de Deus metaforicamente. Logo, também o amor.

3. Demais. — Dionísio diz: O amor é uma força unitiva e concretiva. Ora, isto não pode ter lugar em
Deus, que é simples. Logo, em Deus não há amor.
Mas, em contrário, a Escritura (1 Jo 4, 16): Deus é caridade.

SOLUÇÃO. — É necessário admitir o amor em Deus. Pois, o primeiro movimento da vontade e de
qualquer virtude apetitiva é o amor. Ora, o ato da vontade e de qualquer virtude apetitiva tende para o
bem e para o mal, como para seus objetos próprios: para o bem, principalmente e em si mesmo, como
objeto da vontade e do apetite; para o mal, porém, secundária e mediatamente, enquanto se opõe ao
bem. Por onde e necessariamente, os atos da vontade e do apetite, que dizem respeito ao bem,
naturalmente têm prioridade sobre os que dizem respeito ao mal. Assim, a alegria deve ter prioridade
sobre a tristeza, e o amor, sobre o ódio. Pois, o que é em si tem sempre prioridade sobre o que é por
outro. Além disso, o que é mais geral tem naturalmente prioridade; por isso, o intelecto busca a verdade
geral de preferência a certas verdades particulares. Ora, há certos atos da vontade e do apetite, que
dizem respeito ao bem, sob certa e especial condição; assim, a alegria e o prazer recaem sobre o bem
presente e possuído; o desejo, porém, e a esperança, sobre o bem ainda não alcançado. O amor visa o
bem em geral, quer já obtido, quer ainda por obter; donde, o ser naturalmente o primeiro ato da
vontade e do apetite. Por isso, todos os outros movimentos do apetite o pressupõem, como a raiz
primeira. Assim, ninguém deseja senão o bem amado, ninguém se alegra senão com ele, só há ódio ao
que contraria a coisa amada. Semelhantemente, a tristeza e as outras paixões da mesma espécie
manifestamente se referem ao amor como ao primeiro princípio. Logo, qualquer ser que tenha vontade
e apetite há-de ter amor. Ora, eliminado o primeiro princípio, tudo mais se elimina. Mas, já
demonstramos que em Deus há vontade. Logo, é forçoso admitir que há nele também amor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A virtude cognoscitiva não move senão mediante a
apetitiva. E assim como a razão universal nos move mediante a particular, conforme diz Aristóteles,
assim também o apetite intelectivo, chamado vontade, move-nos mediante o apetite sensitivo. Por
onde, o motor próximo do nosso corpo é o apetite sensitivo. Por isso, certas alterações no corpo sempre
acompanham o ato do apetite sensitivo, e sobretudo do coração, que é o primeiro princípio do
movimento do animal, como diz o Filósofo. Assim, pois, os atos do apetite sensitivo, enquanto têm
anexa uma transmutação corporal, chamam-se paixões; mas não atos da vontade. Portanto o amor, a
alegria e o prazer, enquanto significam atos do apetite sensitivo, são paixões; não porém, enquanto
significam atos do apetite intelectivo. Ora, assim é que existem em Deus. Por isso, diz o Filósofo,
que Deus se compraz numa operação una e simples; e, pela mesma razão, ama sem paixão.

RESPOSTA À SEGUNDA. — Nas paixões do apetite sensitivo devemos distinguir uma parte, por assim
dizer, material, isto é, a transmutação corporal; e outra formal, relativamente ao apetite. Assim na ira,
como diz Aristóteles, a parte material é a subida do sangue ao coração ou algo de semelhante; a formal,
porém, o apetite da vindicta. Além disso, quanto ao formal, descobrimos em algumas destas paixões
uma certa imperfeição; assim, no desejo, que busca um bem não obtido, e na tristeza, cujo objeto é um
mal presente. O mesmo se dá com a ira, que pressupõe a tristeza. Outras paixões, porém, nenhuma
imperfeição implicam, como o amor e a alegria. Ora, nenhuma destas paixões convêm a Deus pelo que
têm de material, como dissemos. Por onde, aquelas que implicam uma imperfeição, mesmo formal, não
podem convir a Deus, a não ser metaforicamente e por semelhança de efeitos, como estabelecemos.
Porém, as que não implicam imperfeição se predicam de Deus propriamente, como o amor e a alegria;
contudo, sem paixão, conforme ficou dito.

RESPOSTA À TERCEIRA. — O ato de amor sempre tende a dois objetos, a saber, ao bem, que desejamos
para outrem e à pessoa a quem o queremos, pois, amar alguém é propriamente querer-lhe bem. Por
isso, quem se ama a si mesmo, a si mesmo se quer bem, e assim, quanto pode, procura unir-se ao bem
que quer. E por isso o amor se chama virtude unitiva, mesmo em Deus, mas sem composição. Porque o
bem que ele para si quer não é outro senão ele próprio, que é bom por essência, como já
demonstramos. Quando porém, amamos a outrem, nós lhe queremos bem. Por isso, tratamo-lo como a
nós mesmos, referindo-lhe o bem, como a nós mesmos. Pelo que, dizemos que o amor é uma força
concretiva, porque por ele, atraímos outrem a nós, tratando-o como a nós próprios. E também o amor
divino é uma força concretiva existente em Deus, sem nenhuma composição, pela qual Deus quer o bem
a outros seres.

## Art. 2 — Se Deus ama todos os seres.
Infra., q. 23, a. 3, ad 1; Ia IIae., q. 110, a. 1; II Sent., dist. XXVI, a. 1; III, dist. XXXII a. 1, 2; I Cont. Gent.,
cap. CXI; III, cap. CL; De Verit., q. 27 a. 1; De Virtut., q.2, a. 7, ad 2; in Ioan., cap. V, lect. III; De Div. Nom.,
cap. IV, lect. IX.
O segundo discute-se assim. — Parece que Deus não ama todos os seres.

1. — Pois, o amor põe o amante fora de si e, de certo modo, o transfere para o amado. Ora, é impróprio
dizer que Deus, exteriorizando-se a si mesmo, se transfere aos outros seres. Logo, é inadmissível que
Deus ame seres diversos de si.

2. Demais. — O amor de Deus é eterno. Ora, os outros seres, diferentes de Deus, não existem abeterno
senão em Deus. Logo, Deus não os ama senão em si mesmo. Mas, enquanto estão nele, dele não
diferem. Portanto, Deus não ama seres diversos de si.

3. Demais. — O amor é duplo: de concupiscência ou de amizade. Ora, Deus não ama as criaturas
irracionais por amor de concupiscência, porque de nada precisa, além de si mesmo; e nem pelo de
amizade, que não pode existir em relação aos irracionais, como está claro no Filósofo. Logo, Deus não
ama todos os seres.

4. Demais. — A Escritura diz (Sl 5, 6): Aborrece a todos os que obram a iniqüidade. Ora, nada pode ser
ao mesmo tempo odiado e amado. Logo, Deus não ama todos os seres.
Mas, em contrário, a Escritura (Sb 11, 24): Tu amas todas as coisas que existem e não aborreces nada
que fizeste.

SOLUÇÃO. — Deus ama tudo o que existe, porque tudo o que existe, na medida mesma em que existe, é
bom; pois, o ser mesmo de qualquer coisa, assim como qualquer perfeição sua, é um bem. Ora, já
demonstramos que a vontade de Deus é a causa de todos os seres. Donde resulta necessariamente, que
um ente tem o ser, ou qualquer bem, na medida mesma em que é querido de Deus. Logo, a cada ser
existente Deus quer algum bem. Por onde, o amor não sendo senão querer bem a alguém, é claro que
Deus ama tudo quanto existe. Não porém como nós. Pois, longe de ser causa da bondade das coisas, a
nossa vontade é movida por essa bondade, como pelo seu objeto. O nosso amor, pelo qual queremos
bem a alguém, não é a causa da bondade desse ser; mas, inversamente, a bondade verdadeira ou
suposta do ser, a quem queremos bem, provoca o nosso amor, que nos faz querer que tal se conserve o
bem que possui e se lhe acrescente o que não possui; e para isso cooperamos. Ao contrário, o amor de
Deus infunde e cria a bondade dos seres.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O amante, transferindo-se para o amado, exterioriza-se
a si mesmo, enquanto quer o bem para o amado e obra, pela sua providência, como se o fizesse para si
próprio. Por isso, diz Dionísio: Devemos ousar dizer, que é verdade que a própria causa de tudo, por
abundância da bondade amante, se exterioriza a si mesma, pela providência para com tudo o que
existe.

RESPOSTA À SEGUNDA. — Embora as criaturas não existissem abeterno senão em Deus, contudo, por
terem nele existido desse modo, Deus as conheceu abeterno nas suas naturezas próprias. E pela mesma
razão as amou. Assim como nós, pelas semelhanças das coisas que em nós existem, conhecemos as que
existem em si mesmas.

RESPOSTA À TERCEIRA. — Só pode haver amizade para com as criaturas racionais, capazes de retribuir o
amor e de participarem das obras da vida. E às quais é próprio suceder bem ou mal, conforme a fortuna
e a felicidade; assim como também lhes é própria a benevolência. Mas, as criaturas irracionais não
podem chegar a amar a Deus nem à participação da vida intelectual e feliz, que Deus vive. Portanto
Deus, propriamente falando, não ama as criaturas irracionais, por amor de amizade mas, como por
amor de concupiscência, ordenando-as às racionais. E mesmo a si próprio; não que delas precise, mas,
pela sua bondade e para nossa utilidade. Pois, nós desejamos alguma coisa tanto para nós como para os
outros.

RESPOSTA À QUARTA. — Nada impede que, a uma luz, amemos, e, a outra, odiemos a uma mesma
coisa. Assim, Deus ama os pecadores enquanto têm uma certa natureza; pois, como tais, existem e
provêm de Deus. Mas enquanto pecadores não existem, mas, têm o ser falho; e, como isso não lhes vem
de Deus, são, como tais odiados dele.

## Art. 3 — Se Deus ama igualmente todos os seres.

II Sent., dist. XXVI, a. 1, ad 2; III, dist. XIX, a. 5, qa 1; dist. XXXII, a. 4; I Cont. Gent., cap. XCI.
O terceiro discute-se assim. — Parece que Deus ama igualmente todos os seres.

1. — Pois, diz a Escritura (Sb 6, 7): Tem igualmente cuidado de todos. Ora, a providência, que Deus tem
das coisas, provém do amor com que as ama. Logo, ama igualmente a todos os seres.

2. Demais. — O amor é a essência de Deus. Ora, tal essência não é suscetível de mais nem menos. Logo,
nem o seu amor. Portanto, não ama a uns seres mais que outros.

3. Demais. — Assim como o amor de Deus se estende às criaturas, assim também a sua ciência e a sua
vontade. Ora, não se diz que Deus conhece nem quer uns seres mais do que outros. Logo, não ama a uns
mais que a outros.
Mas, em contrário, diz Agostinho: Deus ama todos os seres que criou e, dentre eles, mais ama às
criaturas racionais; e, dentre estas, mais as que são membros do seu Unigênito. E muito mais o seu
próprio Unigênito.

SOLUÇÃO. — Consistindo o amor em querer bem a alguém, qualquer ser pode ser mais ou menos
amado, de duplo modo. Primeiro, quanto ao ato mesmo da vontade, que é mais ou menos intenso. E
assim Deus não ama a uns seres mais do que a outros, porque os ama a todos por um ato uno da
vontade, o qual permanece sempre o mesmo. Segundo, quanto ao bem mesmo que se quer ao para o
ser amado; e assim dizemos que alguém mais ama a quem maior bem deseja, embora, não com vontade
mais intensa. E deste modo é forçoso dizer-se que Deus ama a uns seres mais do que a outros. Pois,
sendo o seu amor a causa da bondade dos seres, como demonstramos, não seria um melhor do que
outro se Deus não quisesse a um maior bem que a outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Dizemos que Deus cura igualmente de todos os seres;
não que, assim fazendo, dispense a todos os mesmos bens, mas porque governa tudo com sapiência e
bondade iguais.

RESPOSTA À SEGUNDA. — A objeção procede, quanto à intensidade do amor, relativamente ao ato da
vontade, que é a divina essência. Mas o bem que Deus quer à criatura não é a divina essência. Logo,
nada impede que esse bem seja suscetível de intensidade ou de remissão.

RESPOSTA À TERCEIRA. — Inteligir e querer significam apenas atos, e não incluem na sua significação
nenhuns objetos, por cuja diversidade se possa dizer que Deus sabe ou quer mais ou menos, como se diz
a respeito do amor.

## Art. 4 — Se Deus ama sempre mais os seres melhores.

III Sent., dist. XXXI, q. 2, a. 3, qa. 3; dist. XXXII, a. 5.
O quarto discute-se assim. — Parece que Deus nem sempre mais ama os seres melhores.

1. — Pois, é manifesto que Cristo, sendo Deus e homem, é melhor que todo gênero humano. Ora, Deus
mais amou o gênero humano que a Cristo, conforme aquilo da Escritura (Rm 8, 32): Ao seu próprio Filho
não perdoou, mas por nós todos o entregou. Logo, Deus nem sempre mais ama os melhores.

2. Demais. — O anjo é melhor que o homem; por isso, diz a Escritura (Sl 8, 6), a respeito do
homem: Pouco menos o fizeste que os anjos. Ora, Deus mais ama o homem do que o anjo, conforme o
Apóstolo (Heb 2, 16):Em nenhum lugar tomou aos anjos, mas, tomou a descendência de Abraão. Logo,
nem sempre Deus mais ama os seres melhores.

3. Demais. — Pedro foi melhor que João, porque mais amava a Cristo, o que o Senhor, sabendo que era
verdade, perguntou a Pedro (1 Jo 21, 15): Simão, filho de João, tu me ama mais do que estes? Contudo,
Cristo mais amou a João que a Pedro, como diz Agostinho sobre aquilo — Viu o discípulo a quem Jesus
amava. — Por este sinal do Evangelho distingue-se João aos outros discípulos: Não que só a ele amasse,
mas, porque mais do que aos outros o amava. Logo, nem sempre Deus ama os melhores.

4. Demais. — O inocente é melhor que o penitente; pois, a penitência é a segunda tábua, depois do
naufrágio,diz Jerônimo. Ora, Deus mais ama o penitente, que o inocente, porque mais com ele se
rejubila, diz o Evangelho (Lc 15, 7): Digo-vos que assim haverá maior júbilo no céu sobre um pecador
que fizer penitência, que sobre noventa e nove justos, que não hão mister de penitência. Logo, Deus
nem sempre mais ama aos melhores.

5. Demais. — Melhor é o justo precito, que o pecador predestinado. Ora, Deus mais ama o pecador
predestinado, porque lhe quer maior bem: a vida eterna. Logo, nem sempre Deus mais ama os
melhores.
Mas, em contrário, cada ser ama o seu semelhante, como é manifesto pela Escritura (Ecle 13, 19): Todo
animal ama ao seu semelhante. Ora, um ser é tanto melhor quanto mais se assemelha a Deus. Logo, os
seres melhores são os mais amados de Deus.

SOLUÇÃO. — É necessário admitir-se que Deus mais ama os seres melhores. Pois, como já dissemos o
amar a Deus mais a um que a outros, significa querer-lhe maior bem porque a vontade de Deus é a
causa da bondade dos seres. Por onde, são melhores aqueles aos quais quer maior bem. Logo, Deus
mais ama aos melhores.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Deus ama a Cristo, não somente mais que a todo o
gênero humano, mas, mais que a toda a universalidade das criaturas. Pois, quis-lhe maior bem e deu-
lhe um nome superior a qualquer outro nome, como a verdadeiro Deus. E nem Cristo perde nada da sua
excelência por Deus tê-lo entregue à morte, para a salvação do gênero humano; antes, tornou-se
vencedor glorioso, pois, foi posto o principado sobre o seu ombro, diz a Escritura (Is 9, 5).

RESPOSTA À SEGUNDA. — Conforme o que foi dito, Deus ama, de preferência a todos os anjos, a
natureza humana assumida pelo Verbo de Deus, na pessoa de Cristo, melhor que eles, sobretudo em
virtude da união. Mas, falando em geral, da natureza humana e comparando-a com a angélica, na
ordem da graça e da glória, descobrimos entre elas uma igualdade, porque a mesma é a medida do
homem e do anjo, como diz a Escritura (Ap 21, 17). De modo que, a esta luz, certos anjos são superiores
a certos homens, e certos homens, a certos anjos. Mas, pela condição da natureza, o anjo é melhor que
o homem. Nem Deus assumiu a natureza humana porque, em absoluto, mais amasse o homem, mas
porque este era mais necessitado. Assim, o bom pai de família dá o mais precioso ao servo doente que
ao filho são.

RESPOSTA À TERCEIRA. — Essa dúvida, sobre Pedro e João, resolve-se de muitas maneiras. — Assim,
Agostinhoa considera um mistério, dizendo que a vida ativa, simbolizada em Pedro, mais ama a Deus,
que a contemplativa, simbolizada em João. Porque sente mais as angústias da vida presente e mais
ardentemente deseja libertar-se delas a fim de ir para Deus. Mas, Deus mais ama a vida contemplativa
porque mais a conserva; pois, não acaba com a vida do corpo, como a ativa. — Outros, porém, dizem
que Pedro mais amou a Cristo, nos seus membros, e do mesmo modo também foi dele mais amado; por
isso, confiou-lhe a sua Igreja. João, porém, mais amou a Cristo em si mesmo, e assim também foi mais
amado dele, que lhe confiou por isso a sua Mãe. — Outros ainda dizem, que é incerto qual dos dois
amou mais a cristo com amor de caridade; e, semelhantemente, qual Deus mais amou, quanto à maior
glória da vida eterna. Mas, dizemos que Pedro mais o amou, pela presteza ou pelo fervor, João porém
foi mais amado, por certos indícios de familiaridade, que Cristo mais lhe demonstrava, por causa da sua
juventude e pureza. — Outros, finalmente, dizem que Cristo mais amou a Pedro, quanto ao dom mais
excelente da caridade, e mais a João, quanto ao dom da inteligência. Logo, Pedro foi melhor e mais
amado, absolutamente falando, e João, relativamente. — Mas é presunção querer julgar de tais coisas,
porque, como diz a Escritura (Pr 16, 2), o Senhor pesa os espíritos, e mais ninguém.

RESPOSTA À QUARTA. — Os penitentes estão para os inocentes como o excedente para o excedido.
Pois, inocentes ou penitentes, melhores e mais amados são os que têm maior graça. Porém, todas as
condições iguais, a inocência é mais digna e mais amada. Dizemos contudo que Deus mais se rejubila
com o penitente do que com o inocente, porque mais freqüentemente os penitentes ressurgem mais
cautos, humildes e fervorosos. Por isso, diz Gregório: Na batalha, o mais querido do chefe é o soldado
que, arrependido da fuga, volta-se e ataca fortemente o inimigo, mais que o que nunca fugiu, mas
também nunca atacou fortemente. Ou, outra razão é que o mesmo dom da graça custa mais ao
penitente, que mereceu a pena, do que ao inocente, que não a mereceu; assim como cem marcos são
dom maior ao pobre que ao rei.

RESPOSTA À QUINTA. — A vontade de Deus, sendo a causa da bondade dos seres, devemos pesar a
bondade de um ser amado de Deus, de acordo com o tempo em que a vontade divina lhe dá algum
bem. Ora, durante o tempo em que ela der ao pecador predestinado um bem maior, melhor será ele,
embora seja pior noutro tempo; pois também, num certo tempo, não é bom nem mau.