# Questão 33: Da Pessoa do Pai.
Em seguida, devemos tratar das Pessoas em especial. E primeiro da Pessoa do Pai, sobre a qual quatro
artigos se discutem:

## Art. 1 — Se compete ao Pai ser princípio do Filho, ou do Espírito Santo.
(I Sent., dist. XII, a. 2, ad 1; dist. XXIX, a. 1; III, dist. XI, a. 1. ad 5; De Pot., q. 10, a. 1, ad 8 sqq.; Contra
errores Graec., cap. 1).
O primeiro discute-se assim. — Parece que o Pai não pode ser princípio do Filho ou do Espírito Santo.

1. — Pois, princípio e causa se identificam, segundo o Filósofo. Ora, não dizemos que o Pai é causa do
Filho. Logo, nem devemos dizer que é deste o princípio.

2. Demais. — Um princípio supõe um principiado. Se, pois, o Pai é o princípio do Filho, segue-se que este
principiou e, por conseqüência, foi criado, o que é errôneo.

3. Demais. — O nome de princípio supõe prioridade. Ora, em Deus não há anterior nem posterior, como
diz Atanásio. Logo, a ele não lhe devemos aplicar o nome de princípio.
Mas, em contrário, Agostinho: O pai é o princípio de toda divindade.

SOLUÇÃO. — O nome de princípio significa aquilo de que alguma coisa procede, pois damos tal nome a
tudo aquilo de que alguma causa de qualquer modo procede, e inversamente. Donde, como do Pai
procede outro, resulta que o Pai é princípio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os Gregos aplicam a Deus, indiferentemente os nomes
de coisa e de princípio, mas os Doutores latinos não usam do nome de causa, mas só do de princípio. E a
razão é que princípio é mais que causa, como causa o é mais que elemento; assim, o primeiro termo ou
mesmo a primeira parte de uma coisa se chama princípio e não, causa. Ora, quanto mais comum é um
nome tanto mais convém a Deus, como dissemos, porque os nomes, quanto mais especiais tanto mais
determinam o modo conveniente à criatura. Donde, o nome de causa importa diversidade de substância
e dependência entre uma coisa e outra, o que não importa o nome de princípio. Pois, em todos os
gêneros de causa, sempre existe diferença entre a causa e o efeito, relativamente a alguma perfeição ou
virtude. Usamos do nome de princípio, porém, mesmo entre coisas que não diferem do modo por que
acabamos de expor, mas somente segundo certa ordem; assim, quando dizemos que o ponto é o
princípio da linha, ou ainda, que a primeira parte da linha é desta o princípio.

RESPOSTA À SEGUNDA. — Os Gregos dizem, que o Filho e o Espírito Santo principiaram. Mas isto não
usam dizer os nossos Doutores; pois, embora atribuamos ao Pai alguma autoridade, em razão de
princípio, todavia não atribuímos, quer ao Filho, quer ao Espírito Santo, qualquer sujeição ou minoração,
para evitar a ocasião de algum erro. E deste modo diz Hilário: O Pai é maior pela autoridade de doador;
mas não é menor o Filho, ao qual um ser é dado.

RESPOSTA À TERCEIRA. — Embora o nome de princípio, quanto à proveniência da sua significação, se
considere como supondo a prioridade, todavia não significa a prioridade, mas a origem. Pois, o que o
nome significa não é o mesmo que a razão da sua significação, como dissemos.

## Art. 2 — Se o nome de Pai é propriamente nome de Pessoa divina.
(Infra, q. 40, a. 2).
O segundo discute-se assim. — Parece que o nome de Pai não é propriamente nome de Pessoa divina.

1. — Pois, o nome de Pai significa uma relação. Ora, a pessoa é uma substância individual. Logo, o nome
de Pai não é propriamente significativo de pessoa.

2. Demais. — Generante tem significação mais geral do que pai; pois, todo pai é generante, não porém
inversamente. Ora, o nome de significação mais geral, mais propriamente se aplica a Deus, como se viu.
Logo, mais propriamente se aplica à Pessoa divina o nome de generante e o de genitor, que o de Pai.

3. Demais. — Nenhum nome metafórico pode ser aplicado em sentido próprio. Ora, o verbo, em nós,
metaforicamente se chama genito, ou prole; e por conseqüência, aquele de quem o verbo procede
metaforicamente se chama pai. Logo, em Deus, o princípio do Verbo não se pode propriamente chamar
Pai.

4. Demais. — Tudo quanto propriamente se diz de Deus, dele e não das criaturas sé diz primàriamente.
Ora, a geração a título primário não se atribui a Deus, mas às criaturas, segundo parece; pois, mais
verdadeiramente parece que há a geração onde um ser procede de outro, distinto este, daquele, não só
relativa mas ainda essencialmente. Logo, o nome de pai, originado da geração, não é próprio a nenhuma
das divinas pessoas.
Mas, em contrário, a Escritura (Sl 88, 27): Ele me invocará dizendo: Tu és meu Pai.

SOLUÇÃO. — O nome próprio de uma pessoa significa aquilo pelo qual ela se distingue de todas as
outras. Assim, pois, como da natureza do homem é o ter alma e corpo, assim da idéia de tal homem é
tal alma e tal corpo, como diz o Filósofo; porquanto é dessa maneira que tal homem se distingue dos
outros. Ora, o que distingue a pessoa do Pai de todas as outras é a paternidade. Logo, o nome próprio
dessa pessoa é Pai, significativo da paternidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Em nós, a relação não é uma pessoa subsistente. Por
isso, o nome de pai, em nós, não significa a pessoa mas a sua relação. Ora, em Deus, não é assim, como
alguns falsamente opinaram, porque a relação que significa o nome de Pai é uma pessoa subsistente.
Por isso dissemos, que o nome de pessoa em Deus significa relação subsistente na divina natureza.

RESPOSTA À SEGUNDA. — A denominação de um ser deve se tirar sobretudo da sua perfeição e do seu
fim, como diz o Filósofo. Ora, a geração exprime o vir à ser; ao passo que a paternidade significa o
complemento da geração. Por onde, mais próprio é da divina pessoa o nome de pai do que o de
generante ou genitor.

RESPOSTA À TERCEIRA. — Em a natureza humana, o verbo, não sendo nada de subsistente, não se pode
propriamente chamar genito ou filho. Ao contrário, o Verbo divino é uma realidade subsistente em a
natureza divina; por isso própria e não metaforicamente se chama Filho; e o seu princípio, Pai.

RESPOSTA À QUARTA. — Os nomes de geração, paternidade e outros que propriamente se atribuem a
Deus, primeiro se predicam dele que das criaturas, quanto à realidade significada, embora não quanto
ao modo de significar. Daí o dizer a Escritura (Ef 3, 14-15): Dobro eu os meus joelhos diante do Pai de
Nosso Senhor Jesus Cristo, do qual toda a paternidade toma o nome nos céus e na terra. E isto assim se
explica. É manifesto que do seu termo — a forma do gerado — é que a geração recebe a sua espécie. E
quanto mais tal forma estiver próxima da do generante, tanto mais verdadeira e perfeita será a geração;
assim, a geração unívoca é mais perfeita que a não unívoca, por ser da natureza do generante o gerar o
que lhe é semelhante pela forma. Donde, o fato mesmo de se identificarem numericamente, em Deus,
as formas do generante e do genito, e de nas coisas criadas se não identificarem numérica, mas apenas
especificamente, mostra que a geração, e por conseqüência a paternidade, primeiro se atribui a Deus
que às criaturas. Logo, o haver em Deus distinção entre o genito e o generante, mas apenas quanto à
relação, pertence à verdade da divina geração e paternidade.

## Art. 3 — Se o nome de Pai, tomado pessoalmente, se atribui primariamente a Deus.
O terceiro discute-se assim. — Parece que o nome de pai, tomado pessoalmente, não se atribui
primàriamente a Deus.

1. — Pois, o comum é intelectualmente anterior ao próprio. Ora, o nome de Pai, tomado pessoalmente,
é próprio da Pessoa do Pai; tomado essencialmente, é comum a toda a Trindade, pois, a toda a Trindade
chamamos Pai nosso. Logo, o nome de pai, tomado essencialmente, se atribui primeiro do que tomado
pessoalmente.

2. Demais. — De coisas da mesma natureza nada se predica por anterioridade e posterioridade. Ora, a
paternidade e a filiação predicam-se como constituindo uma só noção, por ser uma Pessoa divina Pai do
Filho, e toda a Trindade Pai nosso ou da criatura; pois, segundo Basílio, receber é comum à criatura e ao
Filho. Logo, a Deus a denominação de Pai, tomada essencialmente, não se atribui, antes, do que quando
tomada pessoalmente.

3. Demais. — Não se comparam coisas que não correspondem a uma mesma noção. Ora, o Filho é
comparável à criatura em razão da filiação ou da geração, segundo a Escritura (Cl 1, 15): Que é a
imagem do Deus invisível, o primogênito de toda a criatura. Logo, em Deus, a paternidade, em sentido
pessoal, não se atribui a Deus primeiro que em sentido essencial; mas, segundo a mesma noção.
Mas, em contrário, o eterno é anterior ao temporal. Ora, Deus é abeterno Pai do Filho, ao passo que é
Pai temporal das criaturas. Logo, a paternidade, em Deus, relativamente ao Filho, se diz primeiro do que
em relação à criatura.

SOLUÇÃO. — Um nome se atribui primeiro ao ser ao qual perfeitamente se aplica toda a sua noção, do
que àquele ao qual a noção se aplica parcialmente; pois a este se atribui como por semelhança com
aquele do qual perfeitamente se predica, porque todo o imperfeito deriva do perfeito. Assim, o nome
de leão atribui-se primeiro ao animal ao qual convém a noção total do leão, e que é chamado
propriamente tal, do que a um homem no qual se encontre algo da noção do leão, p. ex., a audácia, a
força, ou qualquer outro atributo semelhante: pois, a esse homem se atribui por semelhança. Ora, é
manifesto, pelo que já dissemos, que a noção perfeita de paternidade e de filiação existe em Deus Pai e
em Deus Filho, pois, a mesma é a natureza e a glória do Pai e do Filho. Ao passo que na criatura existe a
filiação, relativamente a Deus, não na sua noção perfeita, pois não é a mesma a natureza do Criador e a
da criatura; mas, por certa semelhança. E esta, quanto mais perfeita, tanto mais se aproximará da
verdadeira noção da filiação. Assim, de certas criaturas como as irracionais, se diz que Deus é Pai, só
pela semelhança de vestígio, segundo a Escritura (Jó 38, 28): Quem é o pai da chuva? ou: Quem
produziu as gotas de orvalho? De certas outras, porém, como as racionais, por semelhança de imagem,
conforme a Escritura (Dt 32, 6): Não é ele teu pai, que te possuiu e te fez e te criou? Ainda de outras é
Pai pela semelhança da graça, e estas também se chamam filhos adotivos, enquanto ordenadas à
herança da glória eterna por um dom recebido da graça, segundo o Apóstolo (Rm 8, 16-17): porque o
mesmo Espírito dá testemunho ao nosso espírito de que somos filhos de Deus, e se somos filhos,
também herdeiros. De outras, enfim, pela semelhança da glória, enquanto desta já possuem a herança
segundo o Apóstolo (Rm 5, 2): E nos gloriamos na esperança da glória dos filhos de Deus.
Donde resulta claro que, de Deus, a paternidade se predica primariamente enquanto importa relação de
Pessoa com Pessoa, do que enquanto importa relação sua com as criaturas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os nomes comuns, empregados em sentido absoluto,
têm prioridade sobre os próprios, quanto à ordem do nosso intelecto, pois se incluem no conceito
destes; não porém inversamente. Assim, o conceito da Pessoa de Pai inclui o de Deus, se bem não ao
inverso. Mas, os nomes comuns, que implicam relação com as criaturas, predicam-se posteriormente
aos próprios, que incluem relações pessoais; porque, em Deus, a pessoa procedente procede como
principio da produção das criaturas. Pois, assim como se entende que o verbo concebido pela mente do
artífice procede deste antes de proceder o artificiado, o qual é produzido por semelhança com o verbo
mentalmente concebido; assim, do Pai procede o Filho, antes da criatura, à qual se atribui o nome de
filiação por participar algo da semelhança do Filho, como está claro na Escritura (Rm 8, 29): Os que Ele
conheceu na sua presciência, também os predestinou para serem conformesà imagem de seu Filho.

RESPOSTA À SEGUNDA. — Diz-se que receber é comum à criatura e ao Filho, não por invocação, mas
por certa semelhança remota, em razão da qual ele se chama primogênito da criatura. Por isso a
autoridade citada acrescenta: Para ser ele o primogênito entre muitos irmãos — depois de haver dito:
Certos se tornam conformes à imagem do Filho de Deus. Ora, o Filho de Deus tem naturalmente, sobre
todos os seres uma certa singularidade, a saber, possuir por natureza o que recebe, como diz o mesmo
Basílio. E é neste sentido que se chama unigênito, como se vê na Escritura (Jo 1, 18): O unigênito, que
está no seio do Pai, esse é quem nos deu a conhecer.
Donde resulta a RESPOSTA À TERCEIRA OBJEÇÃO.

## Art. 4 — Se é próprio do Pai ser ingênito.
(I Sent., dist. XIII, a. 4; dist. XXVIII, q. 1, a. 1; Cont. Errores Graec., cap. VIII).
O quarto discute-se assim. — Parece que não é próprio do Pai ser ingênito.

1. — Pois, toda propriedade introduz alguma realidade no ente ao qual pertence. Ora, ingênito nada
introduz no Pai, mas somente dele remove. Logo, não implica nenhuma propriedade sua.

2. Demais. — Ingênito é palavra que se emprega em sentido privativo ou negativo. Se negativo, então
tudo o que não for genito pode se chamar ingênito. Ora, o Espírito, bem como a essência divina, não é
genito. Por isso, também lhes convém o ser ingênito; o que não é, portanto, próprio do Pai. Se porém o
sentido for privativo, como toda privação implica uma imperfeição no ser privado, segue-se que a
pessoa do Pai é imperfeita; o que é impossível.

3. Demais. — Ingênito, por não se predicar de Deus relativamente, não significa relação. Logo, significa
substância. Portanto ingênito e genito substancialmente diferem. Ora, o Filho, que é genito, não difere
substancialmente do Pai. Logo, este se não deve chamar ingênito.

4. Demais. — É próprio o que a um só convém. Ora, como em Deus há vários procedentes de outro,
nada impede haver também vários não existentes por outro. Logo, não é próprio do Pai ser ingênito.

5. Demais. — Sendo o Pai princípio da pessoa genita, sê-lo-á também da procedente. Se portanto, pela
contrariedade que tem com a pessoa genita, é próprio do Pai ser ingênito, também dele deve se admitir
como próprio não poder ser procedente.
Mas, em contrário, diz Hilário: Um vem de outro, isto é, do ingênito o genito, pela propriedade de cada
um, a saber, a inascibilidade e a origem.

SOLUÇÃO. — Como as criaturas têm um princípio primeiro e outro, segundo, assim as Pessoas divinas,
nas quais não há prioridade e posterioridade, têm um princípio sem princípio, que é o Pai, e um
princípio com princípio, que é o Filho. Ora, nas criaturas um princípio primeiro de dois modos se nos
manifesta: como tendo relação com o que de si provém, e como não procedente de outro. Assim, pois,
o Pai se nos manifesta pela paternidade e pela espiração comum, quanto às pessoas dele procedentes;
porém, como princípio sem princípio, manifestasse-nos por não proceder de outro, o que constitui a
propriedade de inascibilidade, significada pelo nome ingênita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Alguns dizem que a inascibilidade, significa da pelo
nome ingênito, como propriedade do Pai, não se aplica só negativamente, mas importa ao mesmo
tempo, em o Pai, de ninguém proceder e ser princípio de outros; ou importa uma autoridade universal;
ou ainda plenitude primária. — Mas isto não é verdade, porque então a inascibilidade não seria
propriedade distinta da paternidade e da espiração, mas as incluiria, como o comum inclui o próprio;
pois as palavras — primário e autoridade — não significam em Deus senão o princípio da origem. — E
portanto devemos dizer, segundo Agostinho, que ingênito importa a negação da geração passiva, pois,
diz, tanto vale dizer ingênita como dizer não Filho. Mas, daí não se segue que se não deva considerar
ingênito como noção própria do Pai, pois, conhecemos o primário e o simples por meio de negações;
assim dizemos que ponto é o que não tem parte.

REPOSTA À SEGUNDA. — As vezes ingênito se toma só em acepção negativa, e é assim que Jerônimo diz,
que o Espírito Santo é ingênito, i. é, não genito. — Outras vezes se emprega ingênito em sentido, de
certo modo, privativo, sem que, contudo, importe qualquer imperfeição; pois, múltiplo é o sentido da
palavra privação. Ora, significa que um ser não tem o que lhe seria natural ter, de outro, embora não
seja da natureza de tal ser possuir tal atributo; como se chamássemos à pedra coisa morta por não ter a
vida, que certos seres naturalmente têm. Ora, significa que um ser não tem o que lhe seria natural ter,
como recebido de outro ser congênere; assim, se chamássemos à toupeira cega. E de um terceiro modo
significa, que um ser não tem o que naturalmente deveria ter, e então importa imperfeição. Assim, pois,
ingênito diz-se do Pai, não privativamente, mas sim do segundo modo, i. é, enquanto um suposto da na-
tureza divina não é genito, e outro o é. — Mas, a esta luz, também ao Espírito Santo se pode chamar
ingênito. Por onde, para que seja próprio só do Pai, é necessário incluir-se ulteriormente, em o nome de
ingênito, a conveniência a uma das Pessoas divinas, como sendo princípio de outra, e assim importando
a negação, no gênero do princípio, aplicado a Deus em sentido pessoal. Ou ainda, devemos entender
por ingênita o que de nenhum modo procede de outro, e não sàmente o que não procede pela geração.
Assim pois, ao Espírito Santo. procedente de outro por processão, como pessoa subsistente, não
convém ser ingênito; e nem também à divina essência da qual se pode dizer que, no Filho e no Espírito
Santo, procede de outro, a saber do Pai.

RESPOSTA À TERCEIRA. — Segundo Damasceno, ingênito, de um modo, significa o mesmo que incriado,
no sentido substancial; pois, por aí difere a substância criada da incriada. De outro modo, significa o que
não é genito, e é em sentido relativo, da mesma maneira que a negação se reduz ao gênero da
afirmação; assim não-homem se reduz ao gênero da substância, e não-branco, ao da qualidade. Donde,
genito, em Deus, importando relação, ingênito também a esta se reduz. E daí se não segue, que o Pai
ingênito se distinga substancialmente do Filho genito, senão só relativamente, enquanto se nega do Pai
a relação do Filho.

RESPOSTA À QUARTA. — Assim como na ordem dos gêneros é preciso admitir-se um que é o primeiro,
assim em a natureza divina é necessário admitir-se um princípio chamado ingênito, não proveniente de
outro. Logo, admitir dois inascíveis é admitir dois deuses e duas naturezas divinas. Por isso diz
Hilário: sendo Deus um só não podem ser dois os inascíveis. E isto precipuamente porque, se estes
fossem dois, um deles não procederia do outro e assim, não se distinguindo por oposição relativa,
necessàriamente se distinguiriam por diversidade de natureza.

RESPOSTA À QUINTA. — A propriedade do Pai, de não proceder de outro, antes é significada pela
remoção da natividade do Filho, do que pela da processão do Espírito Santo. Tanto porque esta última
não tem nome especial, como já vimos, como porque, mesmo na ordem da natureza, pressupõe a
geração do Filho. Por onde, removido do Pai o não ser genito, como todavia é princípio de geração,
resulta conseqüentemente, que não é procedente pela processão do Espírito santo, pois este não é
princípio de geração, mas procedente do genito.