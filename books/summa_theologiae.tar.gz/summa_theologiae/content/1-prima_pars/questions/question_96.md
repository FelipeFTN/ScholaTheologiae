# Questão 96: Do domínio que tocava ao homem no estado de inocência.
Em seguida devemos considerar o domínio que tocava ao homem, no estado de inocência.
E, sobre esta questão, quatro artigos se discutem:

## Art. 1 — Se Adão no estado de inocência tinha domínio sobre os animais.
O primeiro discute–se assim. – Parece que Adão no estado de inocência não tinha domínio sobre os
animais.

1. – Pois, diz Agostinho que, pelo ministério dos anjos, os animais foram trazidos a Adão para este lhes
impor os nomes. Ora, não seria necessário para isso o ministério deles, se Adão, por si mesmo tivesse o
domínio sobre os animais. Logo, no estado de inocência, o homem não tinha domínio sobre os animais.

2. Demais. – Seres opostos entre si não se podem bem reunir sob um mesmo senhor. Ora, muitos
animais são naturalmente inimigos, como a ovelha e o lobo. Logo, todos os animais não estavam
submetidos ao domínio do homem.

3. Demais. – Jeronimo diz: ao homem não necessitado antes do pecado, Deus deu o domínio sobre os
animais ; pois, tinha presciência que Ele, depois da queda, leria neles um adminículo.

4. Demais. – É próprio do senhor ordenar. Ora, ordem só se pode sensatamente dar a quem tem razão.
Logo, o homem não tinha domínio sobre os animais irracionais.
Mas, em contrário, diz a Escritura, falando do homem: presida aos peixes do mar, às aves do céu, às
bestas e a todos os répteis que se movem sobre a terra.

SOLUÇÃO. – Como já se disse antes, a desobediência, para com o homem, dos seres que lhe deviam
estar sujeitos, foi–lhe pena subsequente a ter sido desobediente a Deus. Por onde, no estado de
inocência, antes da sobredita desobediência, não lhe resistia nenhum dos seres que lhe deviam estar
naturalmente sujeitos. Ora, todos os animais estão naturalmente sujeitos ao homem. – O que resulta
claro de três razões. – Primeiro, do processo mesmo da natureza. Pois, como na geração das coisas
manifesta–se uma certa ordem, pela qual se sobe do imperfeito ao perfeito, sendo assim a matéria por
causa da forma; e uma forma mais imperfeita por causa de outra mais perfeita, assim o mesmo se dá
com o uso dos seres naturais. Pois os seres mais imperfeitos servem ao uso dos mais perfeitos; assim, as
plantas tiram da terra a sua nutrição, os animais, das plantas; o homem; enfim, das plantas e dos
animais. Por isso, diz o Filósofo, que a caça dos animais silvestres é justa e natural, porque, por ela, o
homem vindica para si o que é naturalmente seu. – Segundo, da ordem da divina providência, que
sempre governa as coisas superiores pelas inferiores. Por onde, sendo o homem superior a todos os
animais, como feito à imagem de Deus, é racional que eles lhe estejam sujeitos ao domínio. Terceiro, da
propriedade dos homens e da dos animais. Pois estes têm, na estimativa natural, uma participação da
prudência, para certos atos particulares; enquanto que o homem tem a prudência universal, que é a
razão de todas as suas ações. Ora, tudo o que é participado é dependente do que é essencial e
universalmente. Donde resulta ser natural a sujeição dos animais ao homem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Nos seres sujeitos, muitos coisas pode, fazer o poder
superior que não pode o inferior. Ora, o anjo é naturalmente superior ao homem. Por onde, a virtude
angélica podia agir sobre os animais, de modo por que não o podia o poder humano, a saber, que,
imediatamente todos se reunissem.

RESPOSTA À SEGUNDA. – Certos dizem que os animais atualmente ferozes e que matam os outros,
eram, no primeiro estado, mansos, não só relativamente ao homem, como também aos outros animais.
Mas tal é absolutamente irracional. Pois, pelo pecado do homem não se mudou a natureza dos animais,
de modo que vivessem de ervas os que agora, naturalmente, comem as carnes dos outros, como os
leões e os falcões. Nem a Glosa de Beda diz que os vegetais e as ervas fosse dados como alimento a
todos os animais, mas só a alguns; pois, do contrário, haveria discrepância natural entre alguns deles.
Mas, nem por isso haviam de subtrair–se ao domínio do homem, como atualmente não se subtraem ao
de Deus, cuja providência governa a todos. E desta o homem seria o executor, como agora ainda se dá
com os animais domésticos; pois damos as galinhas em alimento aos falcões domésticos.

RESPOSTA À TERCEIRA. – Os homens, no estado de inocência, não precisavam dos animais para as
necessidades corpóreas : nem para se cobrirem, pois estavam nus e não se envergonhavam, não sendo
excitados por nenhum movimento de concupiscência desordenada; nem para se alimentarem, pois se
nutriam dos vegetais do paraíso; nem para se transportarem, pois tinham a força do corpo. Deles
necessitavam porém para haurirem o conhecimento experimental da natureza dos mesmos. E isso o
significa o fato de ter Deus apresentado ao homem os animais, para que lhes impusesse nomes
designativos das suas naturezas.

RESPOSTA À QUARTA. – Todos os animais participam de certo modo, pela estimativa natural, da
prudência e da razão; assim, os grous seguem o chefe e as abelhas obedecem ao rei. E desse mesmo
modo todos os animais de então haviam de obedecer, por si mesmos, ao homem, como, agora, os
domésticos lhe obedecem.

## Art. 2 — Se o homem tinha domínio sobre todas as outras criaturas.
O segundo discute–se assim. –– Parece que o homem não tinha domínio sobre todas as outras
criaturas.

1. – Pois, o anjo tem naturalmente maior poder que o homem. Mas, como Jiz Agostinho, a matéria
corpórea não obedeceria à vontade mesmo dos santos anjos, Logo. muito menos ao homem, no estado
de inocência.

2. Demais. – Das virtudes da alma, só existem, nas plantas, a nutritiva, a aumentativa, e a gera triz. Ora,
a estas não é natural obedecer à razão, como hem se yê num mesmo homem. Logo, como pela razão é
que o homem tem o domínio, resulta que este, no estado de inocência, não dominaria sobre as plantas.

3. Demais. – Quem domina sobre uma cousa pode mudá–la. Ora, o homem não pode mudar o curso dos
corpos celestes, o que só Deus pode, como diz Dionísio. Logo, não dominava sobre eles.
Mas, em contrário, diz a Escritura, falando do homem: Domine em toda a terra.

SOLUÇÃO. – No homem de certa maneira estão todas as coisas; por onde, do modo pelo qual domina o
que em si mesmo está desse mesmo lhe cabe dominar os outros seres. Ora quatro atributos se devem
considerar no homem a saber: a razão, pela qual convém com os anjos; as potências sensitivas, pelas
quais convém com os animais; as potências naturais, pelas quais convém com as plantas; e o corpo, em
si, pelo qual convém com os seres inanimados. Ora, a razão no homem exercendo a função de
dominador, e não do sujeito ao domínio, ele, no primitivo estado não dominava sobre os anjos. E a
expressão sobre toda criatura entende–se das que não são à imagem de Deus. Porém, sobre as
potências sensitivas, como o irascível e o concupiscível, que de certo modo obedecem à razão, a alma
domina, imperando; por isso no estado de inocência dominava pelo império sobre os animais. Ao passo
que o homem domina as potências naturais e ao mesmo corpo, não imperando, mas usando. E desse
mesmo modo também ele no estado de inocência, dominava sobre as plantas e os seres inanimados;
não pelo império ou pela imutaçâo, mas usando sem impedimento do auxílio delas.
E daqui resultam as RESPOSTAS ÀS OBJEÇÕES.

## Art. 3 — Se os homens eram iguais em estado de inocência.
O terceiro discute-se assim. –– Parece que no estado de inocência todos eram iguais (Tradução minha
das três objeções e em contrário, pode e deve conter erros).

1. – Pois, diz Gregório: "Onde não há pecado, não há desigualdade." Mas no estado de inocência não
havia pecado. Logo, todos eram iguais.

2. – Demais. – Além disso, semelhança e igualdade são as bases do amor mútuo, de acordo com
Eclesiástico 13,19 "Todo ser vivo ama o seu semelhante, assim todo homem ama o seu próximo."
Naquele estado havia entre os homens uma abundância de amor, que é o vínculo da paz. Logo, todos
eram iguais no estado de inocência.

3. – Demais. – Além disso, a causa cessando, o efeito também cessa. Mas a causa da desigualdade atual
entre os homens parece surgir, por parte de Deus, a partir do fato de que Ele recompensa alguns e pune
outros; e por parte da natureza, a partir do fato de que alguns, através de um defeito da natureza,
nascem fracos e deficientes, outros fortes e perfeitos, o que não teria sido o caso no estado primitivo.
Logo, etc.
Mas em contrário,diz a Escritura (Romanos 13: 1): "As coisas que são de Deus, são bem ordenadas" [.
Vulg "Aqueles que são, são ordenados por Deus"]. Mas a ordem consiste principalmente na
desigualdade; pois diz Agostinho: "A ordem dispõe coisas iguais e desiguais em seu devido lugar." Logo,
no estado primitivo, que era mais adequado e ordenado, a desigualdade teria existido.

SOLUÇÃO. – Forçoso é admitir–se alguma disparidade no primeiro estado ao menos quanto ao sexo,
pois sem a diversidade sexual não havia geração. E também semelhantemente quanto à idade, pois uns
nasciam dos outros, não sendo estéreis os que se unissem.
Mas, no tocante à alma, também haveria diversidade, quanto à justiça e à ciência. Pois, o homem não
obrava coagido, mas com livre arbítrio, pelo qual pode aplicar o espírito, mais ou menos, a fazer, querer
ou conhecer alguma cousa. Por onde, uns progrediriam na justiça e na ciência, mais que outros.
Também por parte do corpo podia haver disparidade. Pois, o corpo humano não estava de tal modo
isento das leis da natureza que não recebesse, mais ou menos, alguma ajuda ou auxilio dos agentes
exteriores, porquanto a vida do homem sustentava–se de alimentos. E assim, nada impede dizer que,
segundo a disposição diversa do ar e o sitio diverso das estrelas, uns fossem gerados mais robustos de
corpo, maiores, mais belos e de melhor compleição: que outros. Mas, de modo tal que, naqueles que se
salientassem, não houvesse nenhuma deficiência ou pecado, quer da alma quer do corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Pelas palavras citadas, Gregório entende excluir a
disparidade que se funda na, diferença da justiça e do pecado; pela qual uns devem sofrer, penalmente,
a coerção de outros.

RESPOSTA À SEGUNDA. – A igualdade é a causa de ser igual a dileção mútua. Todavia, entre desiguais
pode haver maior dileção que entre iguais, embora não haja de lado a lado igual correspondência.
Assim, o pai ama naturalmente, o filho, mais do que um irmão, a outro; embora o filho não ame o pai
tanto quanto dele é amado.

RESPOSTA À TERCEIRA. – A causa da disparidade podia provir, por parte de Deus, não de ele punir a uns
e premiar a outros; mas, de sublimar mais a uns, e a outros, menos, de modo que a beleza da ordem
resplendesse mais nos homens. E também por sua parte, a natureza podia causar a disparidade, ao
modo supra–dito, sem nenhum defeito da mesma.

## Art. 4 — Se um homem, no estado de inocência, tinha domínio sobre outro.
O quarto discute–se assim. – Parece que um homem, no estado de inocência, não tinha domínio sobre
outro.

1. – Pois, diz Agostinho: Deus não quis que o homem racional, jeito à sua imagem, exercesse o domínio a
não ser sobre os irracionais; não sobre outro homem, mas sobre o animal.

2. Demais. – As consequências penais do pecado não existiam no estado de inocência. Ora, foi
consequência penal do pecado, que um homem exercesse domínio sobre outro; pois, na Escritura, se diz
à mulher, após o pecado: Estarás sob o poder de teu marido. Logo, no estado de inocência, não estava
um homem sujeito a outro.

3. Demais. – A sujeição se opõe à liberdade. Ora, esta é um dos principais bens, que não faltaria no
estado da inocência, em que não havia ausência de nada que a boa vontade pudesse desejar, como diz
Agostinho. Logo, no estado de inocência um homem não dominaria sobre outro.
Mas, em contrário. – A condição do homem no estado de inocência não era mais digna que a dos anjos.
Ora, entre estes, uns dominam os outros, donde vem o chamar–se Dominações uma das ordens. Logo,
não era contra a dignidade do estado de inocência que um homem dominasse outro.

SOLUÇÃO. – Em duplo sentido se pode entender o domínio. De um modo, enquanto se opõe à servidão;
e assim chama–se senhor àquele a quem outrem está sujeito, como servo. De outro modo, o domínio é
comumente referido a qualquer sujeito; e assim quem tem o ofício de governar e dirigir homens livres,
pode se chamar senhor. Ora, na primeira acepção, um homem não dominava sobre outro, no estado de
inocência; mas, na segunda, podia dominar.
E a razão é que o servo difere do homem livre por ser o livre causa de si, como diz Aristóteles: ao passo
que aquele se ordena para outrem. Assim pois quando alguém domina a outrem como servo, fá–Io
servir à sua utilidade. E como todos desejam o bem próprio e, por consequência, se contristam quando
cedem a outrem o bem que devera ser próprio, daí vem que tal domínio não pode deixar de ser
acompanhado da pena dos que são sujeitos; e por isso, no estado de inocência, não existia tal domínio
de um homem sobre outro.
Ora, quem domina um homem livre dirige–o para o bem próprio deste, ou para o bem comum. E tal
domínio de um homem sobre outro existiria, no estado de inocência, por duas razões. – Primeira,
porque sendo o homem animal naturalmente social, os homens, no estado de inocência, viveriam
socialmente. Ora, não podia haver vida social de muitos, sem que presidisse alguém, que os dirigisse
para o bem comum. Pois, muitos tendem para a multiplicidade e um, para a unidade. Por onde, como
diz o Filósofo, quando muitos se ordenam para um fim, sempre existe um principal e dirigente.
Segunda, porque se um homem tivesse sobre os outros sobre eminência de ciência e de justiça,
inconveniente seria que não a empregasse para a utilidade dos outros, conforme a Escritura: Cada um,
segundo a graça que recebeu, comunique–a aos outros, E Agostinho: os justos imperam, não por cobiça
de dominar, mas por dever de dirigir; e: isso a ordem natural o prescreve; assim criou Deus o homem.
Donde se deduzem as RESPOSTAS À TODAS AS OBJEÇÕES, fundadas na primeira acepção do domínio.