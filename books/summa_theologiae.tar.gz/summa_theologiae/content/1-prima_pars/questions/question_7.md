# Questão 7: Da infinidade de Deus.
Após havermos tratado da perfeição de Deus, devemos tratar da sua infinidade e da sua existência nas
coisas; pois, dizemos que Deus, sendo sem limites e infinito, está em toda parte e em todas as coisas. Na
primeira questão discutem-se quatro artigos:

## Art. 1 — Se Deus é infinito.
(I Sent., dist. XLIII, q. 1, a. 1; I Cont. Gent., cap. XLIII; De Verit., q. 2, a. 2, ad 5; q. 29, a. 3; De Pot. q. 1, a.
2; Quod Lib., III, a. 3; Compend. Theol., cap. XVIII, XX).
O primeiro discute-se assim. — Parece que Deus não é infinito.

1. — Pois, todo infinito é imperfeito, porque implica as características de parte e de matéria, como diz
Aristóteles. Ora, Deus é perfeitíssimo. Logo, não é infinito.

2. Demais. — Segundo o Filósofo, finito e infinito se referem à quantidade. Ora, Deus, não sendo corpo,
não tem quantidade, como já se demonstrou. Logo, não é infinito.

3. Demais. — O que está em um lugar porque não está em outro é localmente finito; e, portanto, de
substância finita também há de ser o que é uma coisa, por não ser outra. Ora, Deus é o que é e não
outro ser, pois não é pedra, nem madeira. Logo, não é de substância infinita.
Mas, em contrário, diz Damasceno, que Deus é infinito, eterno e incircunscritível.

SOLUÇÃO. — Todos os filósofos antigos, considerando como as causas efluem, indefinidamente, do
primeiro princípio, atribuem-lhe com razão a infinidade, segundo refere Aristóteles. Mas, como certos
erraram sobre a natureza desse princípio, conseqüentemente, tinham que errar em relação à sua
infinidade. Assim, considerando o primeiro princípio, matéria, atribuíram-lhe logicamente a infinidade
material, dizendo que o primeiro princípio das coisas é um corpo infinito.
Ora, devemos considerar, que se chama infinito ao que não é finito; e que de certo modo, a matéria é
limitada pela forma e esta, por aquela. A matéria, pela forma, porque antes de receber a esta, é
potencial em relação a muitas formas; mas, desde que recebe uma fica por essa limitada. A forma, de
seu lado, é limitada pela matéria enquanto que, em si mesma considerada, é comum a muitos seres;
mas, uma vez recebida numa matéria, torna-se determinadamente a forma de um certo ser. A matéria,
ademais se aperfeiçoa pela forma que a delimita. Por onde, o infinito atribuído à matéria é algo de
imperfeito, pois é quase a matéria sem forma.
A forma, porém, não é aperfeiçoada pela matéria; antes, esta lhe contrai a amplitude. Portanto, o
infinito resultante da forma não determinada pela matéria tem caráter de perfeito. Ora, o que é formal,
por excelência, é o ser em si mesmo, como do sobredito se colhe. E como o ser divino não é recebido
em nenhum outro, mas é o seu próprio ser subsistente, como já demonstramos, é manifesto que Deus é
infinito e perfeito.
Donde resulta clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — O limite é como que a forma da quantidade; e a prova está em que a figura,
que consiste num limite da quantidade, é uma forma quantitativa. Por onde, o infinito próprio à
quantidade é um infinito relativo à matéria e que não pode ser atribuído a Deus, como se disse.

RESPOSTA À TERCEIRA. — Por isso mesmo que o ser de Deus é por si subsistente e não recebido por
nenhum sujeito — como infinito que é — é que se distingue de todos os demais, e todos dele diferem;
assim como, se a brancura por si subsistente existisse, o fato mesmo de ela não existir em outro ser a
diferenciaria de qualquer brancura existente num sujeito.

## Art. 2 — Se algum outro ser, que não Deus, pode ser infinito por essência.
(I Sent., dist. XLIII, q. 1, a. 2; De Verit., q. 29, a. 3; Quodlib., IX, a. 1; X, q. 2, a.1, ad 2; XIII, q. 2, ad 2; XI
Metaph., lect. X).
O segundo discute-se assim. — Parece que além de Deus, seres há que podem ser infinitos por
essência.

1. — Pois, a virtude de um ser lhe é proporcional à essência. Ora, se a essência de Deus é infinita,
necessariamente infinita lhe há de ser a virtude. Logo, pode produzir efeito infinito, desde que a
quantidade da virtude se conhece pelo seu efeito.

2. Demais. — O que tem virtude infinita tem essência infinita. Ora, o intelecto criado, apreendendo o
universal, capaz de abranger muitos singulares, tem virtude infinita. Logo, toda substância intelectual
criada é infinita.

3. Demais. — A matéria prima é diferente de Deus, como já se demonstrou. Ora, é infinita. Logo, há
algo, além de Deus, que pode ser infinito.
Mas, em contrário, o infinito não pode proceder de nenhum princípio, como diz Aristóteles. Ora, fora de
Deus, todo ser tem nele o primeiro princípio, de que procede. Logo, além de Deus, nenhum ser é
infinito.

SOLUÇÃO. — Além de Deus, pode existir o infinito relativo, mas não, o absoluto. Assim, se nos referimos
ao infinito próprio da matéria, é claro que todo ser atualmente existente tem uma certa forma e,
portanto, a sua matéria há de ser por esta determinada. Mas, como a matéria assim sujeita a uma forma
substancial é potencial em relação a muitas formas acidentais, o finito absoluto pode ser relativamente
infinito; p. ex., um pedaço de madeira, finito pela forma é contudo relativamente infinito, por ser
suscetível potencialmente de infinitas figuras.. Se, porém, tratamos do infinito formal, é claro que os
sujeitos que têm a forma unida à matéria são absolutamente finitos e de nenhum modo infinitos. Se
existirem, porém, formas criadas não sujeitas à matéria, mas por si subsistentes — como certos
opinaram, dos anjos, — essas serão de certo modo infinitas, por não serem determinadas nem
contraídas por matéria nenhuma. Mas, como a forma criada assim subsistente possui o seu ser e não o
tem por essência, este necessariamente há de ser recebido e contraído por uma determinada natureza
e, portanto, não pode ser absolutamente infinito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — É contrário à noção mesma de coisa feita ter a essência
idêntica à existência, porque o ser por si subsistente não é um ser criado. Por onde, é contrário à noção
de coisa feita ser absolutamente infinita. Logo, assim como Deus, embora tenha o poder infinito, não
pode contudo fazer com que uma coisa por ele feita não o seja — o que seria contraditório — assim
também não pode fazer uma criatura sua absolutamente infinita.

RESPOSTA À SEGUNDA. — O fato mesmo de ter o intelecto uma virtude que se estende, de certo modo,
a infinitas coisas, procede de ser ele uma forma não imersa na matéria, mas, totalmente separada,
como a substância dos anjos; ou, pelo menos, uma potência intelectiva da alma intelectiva unida ao
corpo e que não é ato de nenhum órgão.

RESPOSTA À TERCEIRA. — A matéria prima, não sendo atual, mas somente potencial, não existe por si
mesma na natureza das coisas; e, por isso, tem mais de concriado que de criado. Além disso, mesmo
como potencial, é infinita, não absoluta, mas relativamente, porque a sua potência não se estende
senão às formas naturais.

## Art. 3 — Se pode haver um infinito atual em grandeza.
(De Verit., q. 2, a. 2, ad 5; Quodlib., IX, a. 1; XII, q. 2, ad 2; I Physic., lect. IX; III, lect VII; I De Caelo, lect.

IX).
O terceiro discute-se assim. — Parece que pode haver um infinito atual em grandeza.

1. — Pois, nas ciências matemáticas não há falsidade, porque na abstração não há mentira, como diz
Aristóteles. Ora, essas ciências empregam o infinitamente grande; assim, diz o geômetra nas suas
demonstrações: Seja tal linha infinita. Logo, não é impossível haver o infinitamente grande.

2. Demais. — Não é impossível convir a uma coisa o que não lhe contraria a noção. Ora, ser infinito não
vai contra a noção de grandeza; ao contrário, finito e infinito parece que são atribuições que a
quantidade sofre. Logo, não é impossível haver uma grandeza infinita.

3. Demais. — A grandeza é como o contínuo, que se define: o divisível ao infinito, como se vê em
Aristóteles. Ora, os contrários são correlativos e têm medida comum. E sendo a divisão oposta à adição,
e o aumento, à diminuição, resulta que a grandeza pode crescer ao infinito e, portanto, pode ser
infinita.

4. Demais. — O movimento e o tempo têm, da grandeza percorrida pelo primeiro, a quantidade e a
continuidade, como diz Aristóteles. Ora, não repugna à natureza do tempo e do movimento serem
infinitos, porque cada indivisível que se pode designar no tempo e no movimento circular é princípio e
fim. Logo, também não é contra a noção de grandeza o ser infinito.
Mas, em contrário. — Todo corpo tem superfície e portanto é finito, por lhe ser ela o limite. Logo, todo
corpo é finito, podendo-se dizer o mesmo da superfície e da linha. Logo, nada é infinito em grandeza.

SOLUÇÃO. — Uma coisa é ser infinito em essência e outra, em grandeza. Ora, dado que existisse um
corpo infinito em grandeza, como o fogo, ou o ar, nem por isso o seria em essência, porque esta seria
determinada a alguma espécie pela forma e a algum indivíduo, pela matéria. Por onde, estabelecido,
pelo que já vimos, que nenhuma criatura é infinita por essência, resta indagar se alguma o é pela
grandeza. — Ora, devemos saber que o corpo, que é a grandeza completa, pode ser tomado em dupla
acepção: matematicamente, quando nele se considera só a quantidade; e naturalmente, quando se
levam em conta a matéria e a forma. — Ora, que o corpo natural não pode ser atualmente infinito, é
manifesto. Pois, todos têm forma substancial determinada; e como desta resultam os acidentes,
necessariamente de uma determinada forma resultarão determinados acidentes, entre os quais, a
quantidade. Por onde, todo corpo natural tem uma determinada quantidade, maior ou menor e,
portanto, não pode ser infinito. E isto também se deduz claramente no movimento. Pois, todo corpo
natural tem algum movimento natural. Ora, tal movimento não pode ser um corpo infinito; o reto, não,
porque só tem naturalmente esse movimento o que está fora do seu lugar, o que não pode convir ao
corpo infinito que, então, ocuparia todos os lugares e qualquer lugar, indiferentemente, seria o seu. O
movimento circular, também não, porque, neste, é necessário cada parte do corpo ser transferida para
o lugar em que estava outra, o que não pode dar-se com um corpo circular suposto infinito; pois, do
contrário, duas linhas, partindo do centro, quanto mais dele se afastassem tanto mais distanciaria uma
da outra e, dada a infinidade do corpo, haveria entre elas uma distância infinita; e, então, uma nunca
poderia ocupar o lugar da outra. — O mesmo se pode dizer do corpo matemático, pois se o
imaginarmos atual, havemos de lhe atribuir uma forma determinada, porque nada se atualiza senão por
uma forma. Por onde, a forma do ser quantitativo, como tal, sendo a figura, o corpo em questão há de
ter alguma figura e, então, será finito, pois a figura é, precisamente o que está compreendido em um ou
vários termos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O geômetra não precisa supor nenhuma linha
atualmente infinita, mas, uma da qual possa subtrair quanto for necessário e a que chama infinita.

RESPOSTA À SEGUNDA. — Embora o infinito não contrarie a idéia de grandeza, em geral, contraria,
contudo, a de qualquer grandeza de espécie quantitativa, como dois côvados, três côvados, a grandeza
circular ou triangular e semelhantes. Ora, não é possível existir num gênero o que em nenhuma espécie
existe. Logo, não é possível haver nenhuma grandeza infinita, pois nenhuma espécie de grandeza é tal.

RESPOSTA À TERCEIRA. — O infinito quantitativo, conforme se disse, é o próprio à matéria. Assim, pela
divisão do todo avançamos na matéria, que é a razão de existirem as partes. Ao contrário, pela adição,
aproximamo-nos do todo, que se comporta como forma. Por isso, não encontramos o infinito na adição
da grandeza, mas, só, na divisão.

RESPOSTA À QUARTA. — O movimento e o tempo existem em ato sucessivo e não, simultaneamente e,
por isso, têm a potência de mistura com o ato; ao passo que a grandeza é toda atual. Logo, o infinito
próprio à quantidade e dependente da matéria repugna à totalidade da grandeza; não porém, à do
tempo ou do movimento, pois existir em potência é próprio da matéria.

## Art. 4 — Se é possível existir atualmente uma infinita multidão de seres.
(II Sent., dist. I, q. 1, a. 5, ad 17; De Verit., q. 2, a. 10; Quodlib., IX, a. 1; XII, q. 2, ad 2; III Physic., lect. XII).
O quarto discute-se assim. — Parece que é possível existir atualmente uma infinita multidão de seres.

1. — Pois não é impossível o potencial atualizar-se. Ora, o número é multiplicável ao infinito. Logo, não é
impossível existir atualmente uma infinita multidão de seres.

2. Demais. — De uma espécie qualquer é possível existir atualmente um indivíduo. Ora, as espécies de
figuras são infinitas. Logo, é possível existirem atualmente infinitas figuras.

3. Demais. — Seres que se não opõem uns aos outros não mantêm, entre si, impedimentos. Ora,
admitida uma multidão de seres, ainda se poderiam admitir muitos outros, não opostos aos primeiros.
Logo, não é impossível, simultaneamente, existirem outros ainda, e assim ao infinito. Logo, é possível
existirem, atualmente, seres infinitos.
Mas, em contrário, diz a Escritura (Sb 11, 21): Todas as coisas dispuseste com medida e conta e peso.

SOLUÇÃO. — Sobre este assunto houve duas opiniões. — Uns, com Avicena e Algazal, disseram ser
impossível existir atualmente uma multidão infinita, em si mesma; mas que, acidentalmente, tal
multidão não é impossível. Pois, diz-se que a multidão é infinita em si mesma, quando é necessária à
realização de alguma coisa; o que é impossível, porque, então, essa coisa dependeria de um número
infinito de condições e nunca viria a existir, por não ser possível percorrer o infinito. Acidentalmente,
porém, diz-se infinita a multidão que não contribui, senão por acidente, para a existência de alguma
coisa. E isto pode se ver p. ex., na operação do ferreiro, que exige uma certa multidão em si mesma, a
saber, a arte, existente na alma, a mão, que move, e o martelo, elementos estes que, multiplicados ao
infinito, não permitiriam nunca a existência da obra, que dependeria, então, de infinitas causas. Porém,
a multidão dos martelos empregados sucessivamente para substituir os que se quebraram é acidental;
pois, é por acidente que se empregam muitos martelos, nada importando o emprego de um, de dois, de
muitos ou de infinitos, se o ferreiro operar num tempo infinito. E, deste modo, admitiam a possibilidade
da multidão atualmente infinita, por acidente. — Ora, isto é impossível, porque toda multidão deve
pertencer a uma determinada espécie, e as espécies de multidão dependem das espécies dos números;
e como nenhuma espécie de número é infinita, pois cada um é uma multidão medida pela unidade,
conclui-se a impossibilidade de existir uma infinita multidão atual, em si, ou acidentalmente. — Demais.
Toda a multidão realmente existente é criada, e todo criado está compreendido em alguma
determinada intenção do criador; pois, nenhum agente obra em vão. Por onde, necessariamente, todos
os seres criados estão compreendidos em um certo número. Logo, é impossível existir uma infinita
multidão atual, mesmo acidentalmente. — É possível, porém, existir uma infinita multidão potencial.
Pois, o aumento da multidão resulta da divisão da grandeza; quanto mais um ser é dividido, tanto mais
elementos numéricos resultam. Por onde, assim como o infinito existe potencialmente na divisão do
contínuo, porque avançamos na matéria, como já demonstramos, assim também, do mesmo modo
existe no aumento da multidão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O potencial se atualiza, conforme o seu modo de ser;
assim, os dias se atualizam, não simultânea, mas sucessivamente. Semelhantemente, é de modo
sucessivo e não simultâneo, que a multidão infinita se atualiza, pois além de qualquer multidão
podemos sempre supor outra, ao infinito.

RESPOSTA À SEGUNDA. — Numericamente é que são infinitas as espécies de figuras, como o trilátero, o
quadrilátero e assim por diante. Ora, a multidão, numericamente infinita, não se atualizando ao mesmo
tempo, o mesmo se dá com a multidão de figuras.

RESPOSTA À TERCEIRA. — Embora certas coisas não contrariem as outras, contudo o infinito é contrário
a qualquer espécie de multidão. Por onde, não é possível existir uma infinita multidão atual.