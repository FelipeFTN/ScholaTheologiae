# Questão 32: Do conhecimento das pessoas divinas.
Em seguida devemos tratar do conhecimento das Pessoas divinas. E nesta questão discutem-se quatro
artigos:

## Art. 1 — Se podemos conhecer a Trindade das Pessoas divinas pela razão natural.
(I Sent., dist. III, q. 1, a. 4; De Verit., q. 10, a. 13; in Boet. De Trin., q. 1, a. 4; ad Rom., cap. I, lect. VI).
O primeiro discute-se assim. — Parece que a Trindade das divinas Pessoas pode ser conhecida pela
razão natural.

1. — Pois, os filósofos não chegaram ao conhecimento de Deus senão pela razão natural. Ora, disseram
muitas coisas sobre a Trindade das Pessoas. — Assim, diz Aristóteles: Com este número ternário,
aplicamo-nos a magnificar o Deus uno, superior às propriedades das coisas criadas. — E Agostinho
também diz: Aí li (nos livros dos Platônicos), não certamente com estas palavras, mas exatamente com
este sentido, que no princípio era o Verbo, e o Verbo estava junto de Deus, e Deus era o Verbo, e o mais
que se segue; ora, tais palavras ensinam a distinção das Pessoas divinas. — E por sua vez diz a Glosa, que
os magos do Faraó erraram no terceiro sinal, a saber, no conhecimento da terceira Pessoa, i. é, o
Espírito Santo; e portanto conheceram pelo menos duas. — E enfim o Trimegisto diz: A mónada gerou a
mónada, e em si refletiu o seu ardor; por onde declara a geração do Filho e a processão do Espírito
Santo. Logo, podemos ter conhecimento das Pessoas divinas, pela razão natural.

2. Demais. — Ricardo de S. Vitor diz: Creio sem dúvida que a qualquer explanação da verdade não
somente não faltam os argumentos prováveis, mas, nem os necessários. Donde, as razões para provar a
Trindade das Pessoas alguns as foram buscar no infinito da bondade divina, que a si mesma
infinitamente se comunica, na processão das divinas Pessoas. Outros, porém, foram-nas buscar no fato
de não poder ser agradável a posse de nenhum bem, sem a co-participação de outrem. Porém
Agostinho, para manifestar a Trindade das Pessoas, parte da processão do verbo e do amor em a nossa
mente; e essa via nós a seguimos no que antes dissemos. Logo, pela razão natural pode ser conhecida a
Trindade das Pessoas.

3. Demais. — É supérfluo revelar ao homem o que ele não pode conhecer pela sua razão. Ora, não se
pode dizer, que a revelação divina, quanto ao conhecimento da Trindade, seja supérflua. Logo, a
Trindade das Pessoas pode ser conhecida pela razão humana.
Mas, em contrário, Hilário: Não pense o homem poder alcançar com a inteligência o sacramento da
geração. E Ambrósio: É impossível conhecer o segredo da geração: a mente falha, a palavra emudece.
Ora, pela origem da geração e da processão se distingue a Trindade das Pessoas divinas, como do
sobredito resulta. Logo, como o homem não pode saber e alcançar com a inteligência aquilo de que não
pode obter a razão necessária, segue-se que a Trindade das Pessoas não pode ser pela razão conhecida.

SOLUÇÃO. — É impossível chegar, pela razão natural, ao conhecimento da Trindade das Pessoas divinas.
Pois, já demonstramos, que o homem, pela razão natural, não pode chegar ao conhecimento de Deus, a
não ser pelas criaturas. Ora, estas levam ao conhecimento daquele como o efeito, ao da causa. Donde,
podemos conhecer, de Deus, pela razão natural, o que necessariamente lhe convém como princípio de
todos os seres; e este fundamento já usamos quando tratamos de Deus. Mas, sendo comum a toda a
Trindade, a virtude criadora de Deus pertence à unidade da essência e não à distinção das Pessoas.
Logo, pela razão natural podemos conhecer o que pertence à unidade essencial de Deus e não, o
concernente à distinção das Pessoas.
E quem pretender provar a Trindade das Pessoas pela razão natural, duplamente irá de encontro à fé. —
Primeiro, quanto à dignidade mesma desta, cujo objeto são as realidades invisíveis, sobre excedentes à
razão humana. Donde o dizer o Apóstolo (Hb 11, 1): A fé se refere às coisas que não aparecem; e noutro
lugar (1 Cor 2, 6): Entre os perfeitos falamos da sabedoria; não porém da sabedoria deste século nem da
dos príncipes deste século; mas falamos da sabedoria de Deus, em mistério, que está encoberta. —
Segundo, quanto à utilidade de atrair os outros à fé. Pois quando, para provar a fé, apresentamos razões
não necessitantes, caímos na irrisão dos infiéis, crentes que nos apoiamos em tais razões para crermos.
Logo, não devemos tentar provar as verdades da fé senão com autoridades, para os que as admitem.
Para os outros, porém, basta provar não ser impossível o que a fé ensina. Daí o dizer Dionísio: Quem
recusa totalmente as Sagradas Letras longe estará da nossa filosofia; mas com quem admitir a verdade
das Sagradas Escrituras também nós usaremos da mesma regra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os filósofos não conheceram o mistério da Trindade das
divinas Pessoas, pelas suas propriedades, que são a paternidade, a filiação e a processão, segundo
aquilo do Apóstolo (1 Cor 2, 6): Falamos da sabedoria de Deus, a qual nenhum dos príncipes deste
século conheceu, i. é, dos filósofos, segundo a Glosa. Conheceram porém eles alguns atributos
essenciais próprios às Pessoas, como o poder, ao Pai, a sabedoria, ao Filho, a bondade, ao Espírito
Santo, como a seguir se verá — Quanto ao dito de Aristóteles — Com este número aplicamo-nos etc.,
não devemos entendê-lo como introduzindo o número ternário, em Deus, mas como significando que os
antigos usavam este número nos sacrifícios e nas orações, por causa de certa perfeição que ele encerra.
— Também nos livros dos Platônicos se lê — No princípio era o Verbo — não que o Verbo signifique a
pessoa gerada em Deus, mas enquanto que por tal palavra se entende a razão ideal das coisas, própria
ao Filho, pela qual Deus as criou a todas. — E embora conhecessem as propriedades das três Pessoas,
diz-se contudo que erraram no terceiro sinal, i. é, no conhecimento da terceira Pessoa, transviando-se
quanto à bondade, própria do Espírito Santo, pois, conhecendo-o como Deus, não o glorificaram como
Deus, segundo diz o Apóstolo (Rm 1, 21). Ou porque, admitindo os Platônicos um ser primeiro, a que
chamavam o pai de toda a universalidade das coisas, conseqüentemente admitiam outra substância
inferior a ele, a que denominavam mente ou intelecto paterno, que encerrava as razões de todas as
coisas, como o expõe Macróbio no Sonho de Cipião. Mas não admitiam nenhuma terceira substância
separada correspondente ao Espírito Santo. Assim também nós não admitimos o Pai e o Filho,
diferentes pela substância, erro de Orígenese de Ário, discípulos neste ponto dos Platônicos. — Quanto
ao dito de Trimegisto — A mónada gerou a mónada e em si refletiu o seu ardor, não devemos referi-lo à
geração do Filho nem à processão do Espírito Santo, mas à produção do mundo; pois, um só Deus
produziu um mundo, por amor de si mesmo.

RESPOSTA À SEGUNDA. — De duplo modo podemos dar a razão de uma coisa. De um modo, para lhe
provar suficientemente o fundamento; assim, nas ciências da natureza damos a razão suficiente para
provar que o movimento do céu é sempre de velocidade, uniforme. De outro modo, damos, não a razão
que lhe prove suficientemente o fundamento, mas a explicativa da congruência desse fundamento já
estabelecido, com os efeitos dele resultantes. Assim, a astrologia dá a razão dos excêntricos e dos
epiciclos, mostrando que, admitido esse fundamento, podem-se explicar as aparências sensíveis dos
movimentos celestes, sem ser contudo essa razão suficientemente probante; pois talvez, admitida outra
opinião, as referidas aparências se pudessem explicar. Por onde, do primeiro modo, podemos dar a
razão para provar a unidade de Deus e outros semelhantes atributos. Mas, ao segundo modo pertencem
as razões dadas para manifestar a Trindade; a saber, que esta admitida, são tais razões congruentes,
embora não provem suficientemente a Trindade das Pessoas. E isto mesmo se evidencia, em particular.
— Assim, a bondade infinita de Deus se manifesta também na produção das criaturas; porque só um
poder infinito é capaz de produzir do nada; mas necessário não é, de comunicar-se Deus com infinita
bondade, que dele proceda um ser infinito, senão que cada ser deve receber a divina bondade segundo
o seu modo. E semelhantemente, o dito — sem a co-participação de outrem não pode ser agradável a
posse de nenhum bem — se aplica a uma pessoa que, não possuindo a bondade perfeita, precisa, para
ter a plena bondade do prazer, do bem de outro ser que lhe esteja unido. — Quanto à semelhança do
nosso intelecto, ela nada prova, suficientemente, de Deus, pois o intelecto não existe univocamente em
Deus e em nós. — Donde vem o dizer Agostinho, que pela fé chegamos ao conhecimento, mas não
inversamente.

RESPOSTA À TERCEIRA. — O conhecimento das divinas Pessoas nos é necessário duplamente. —
Primeiro, para pensarmos retamente da criação das coisas; pois, dizendo que todas as fez Deus pelo seu
Verbo, excluímos o erro dos que ensinam que Deus as produziu por necessidade de natureza.
Introduzindo a processão do Amor, mostramos que Deus não produziu as criaturas por precisar delas ou
por qualquer outra causa extrínseca, mas pelo amor da sua bondade. Por isso Moisés, depois de ter dito
— No princípio criou Deus o céu e a terra — acrescenta — Disse Deus: Faça-se a luz — para manifestar o
Verbo divino; e em seguida: — E viu Deus que a luz era boa — para mostrar a aprovação do divino
Amor; e semelhantemente nas outras obras. — Segundo e mais principalmente, para pensarmos
retamente sobre a salvação do gênero humano, levada a cabo pelo Filho encarnado e pelo dom do
Espírito Santo.

## Art. 2 — Se devemos introduzir noções em Deus.
(I Sent., dist. XXXIII, a. 2).
O segundo discute-se assim. — Parece que não devemos introduzir noções em Deus.

1. — Pois, Dionísio diz: Não devemos ousar afirmar de Deus nada mais do que o que nos foi expresso
pelas Sagradas Letras. Ora, a Sagrada Escritura nenhuma menção faz das noções. Logo, não devemos
admitir noções em Deus.

2. Demais. — Tudo quanto dizemos de Deus concerne à unidade da essência ou à Trindade das Pessoas.
Ora, nem a esta nem àquela concernem as noções. Pois, das noções nada se predica essencialmente;
assim, não dizemos que a paternidade seja sábia ou crie; nem lhes atribuímos propriedades da pessoa,
pois não dizemos que a paternidade gere e a filiação seja gerada. Logo, em Deus se não devem introdu-
zir noções.

3. Demais. — Nos seres simples não devemos introduzir noções abstratas, que sejam princípios de
conhecimento; pois, os seres simples a si mesmos se conhecem. Ora, as Pessoas divinas são
simplicíssimas. Logo, nelas não devemos introduzir noções.
Mas, em contrário, diz João Damasceno: Reconhecemos a diferença das hipóstases, i. é, das Pessoas, por
três propriedades, a saber, a paternal, a filial e a processional. Logo, devemos introduzir em Deus,
propriedades e noções.

SOLUÇÃO. — Prepositivo, atendendo à simplicidade das Pessoas, disse que se não devem introduzir em
Deus propriedades e noções; e quando as encontra, expõe o abstrato pelo concreto. E assim como
costumamos dizer — Rogo à tua benignidade — i. é, — a ti benigno — assim, quando se fala da
paternidade em Deus, entende-se o Deus Padre.
Mas, como já ficou demonstrado, não prejudica a divina simplicidade aplicarmos a Deus nomes
concretos e abstratos, porque, como inteligimos assim nomeamos. Porque o nosso intelecto, não
podendo atingir a simplicidade divina, em si mesma considerada, por isso apreende e nomeia as
realidades divinas ao seu modo, i. é, segundo o que descobre nas coisas sensíveis, das quais tira o
conhecimento. Ora, para significar as formas simples destas, usamos de nomes abstratos; e para
significar as coisas subsistentes, de nomes concretos. E por isso, como já dissemos, exprimimos as
realidades divinas, pelo concernente à simplicidade, com nomes abstratos; e pelo concernente à
subsistência e ao complemento, com nomes concretos. Ora, é necessário exprimir, abstrata e
concretamente, não só os nomes essenciais, como quando dizemos divindade e Deus, sabedoria e sábio;
mas também os pessoais, como quando dizemos paternidade e pai.
E a isto sobretudo nos obrigam duas razões. A primeira é a instância dos heréticos. Pois, se nos
perguntassem, ao confessarmos que o Pai, o Filho e o Espírito Santo são um só Deus em três Pessoas,
pelo que são um só Deus e pelo que são três Pessoas, do mesmo modo que responderíamos serem um
Deus pela essência e pela divindade, assim também devem existir certos nomes abstratos pelos quais
possamos responder que as Pessoas se distinguem. E tais são as propriedades ou noções expressas em
abstrato, como paternidade e filiação. E assim, em Deus, a essência significa o que é, a Pessoa, quem é,
e a propriedade, enfim, pelo que é.
A segunda é que, em Deus, uma Pessoa se refere a duas, a saber, a Pessoa do Pai à do Filho e à do
Espírito Santo. Não porém pela mesma relação; porque daí resultaria referirem-se também o Filho e o
Espírito Santo ao Pai por uma e mesma relação; e assim como em Deus só a relação multiplica a
Trindade, seguir-se-ia não serem duas Pessoas o Filho e o Espírito Santo.
Nem se pode dizer, como queria prepositivo, que assim como Deus de um só modo se refere às
criaturas, embora estas diversamente se lhe refiram a ele, assim também o Pai, por uma só relação, se
refere ao Filho e ao Espírito Santo, se bem estes se lhe refiram a ele por duas relações. Porque,
consistindo a razão específica do relativo em referir-se a outro, necessário é dizer-se, que duas relações
não são especificamente diversas se lhes corresponde, por contrariedade, uma só relação; e por isso
necessariamente são diversas as relações entre senhor e pai, segundo a diversidade entre filiação e
escravidão. Ora, todas as criaturas de Deus se lhe referem por uma só espécie de relação. Porém o Filho
e o Espírito Santo não se referem ao Pai pelas relações da mesma natureza; e portanto, o caso não é o
mesmo.
Além disso, Deus não tem necessariamente uma relação real com as criaturas, como já dissemos. E de
outro lado, não há inconveniente em se multiplicarem nele as relações de razão. Mas no Padre é
necessário haver uma relação real que o refira ao Filho e ao Espírito Santo; e daí, segundo a dupla
relação do Filho e do Espírito Santo com o Padre, o ser forçoso admitir neste duas relações, que o
refiram ao Filho e ao Espírito Santo. Por onde, sendo a Pessoa do padre uma só, é necessário
separadamente exprimir as relações em abstrato, chamadas propriedades e noções.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora a Sagrada Escritura não mencione as noções,
menciona contudo as Pessoas, nas quais aquelas se compreendem, como abstrato, no concreto.

RESPOSTA À SEGUNDA. — As noções, em Deus, não significam realidades, mas umas certas razões,
pelas quais se conhecem as Pessoas, embora essas noções ou razões nele existam realmente, como já
dissemos. Por onde, tudo o que se referir a um ato essencial ou pessoal não se pode predicar das
noções, porque isto lhes repugna ao modo da significação. Assim, não podemos dizer que a paternidade
gere ou crie, seja sábia ou inteligente. Porém, o que for essencial e não se referir a nenhum ato, mas
remover de Deus as condições da criatura, pode-se predicar das noções; e assim pode dizer, que a
paternidade é eterna ou imensa, ou predicações semelhantes. Semelhantemente, pela sua identidade
real, podem os substantivos pessoais e essenciais ser predicados das noções; e assim podemos dizer: A
paternidade é Deus e a paternidade é Pai.

RESPOSTA À TERCEIRA. — Embora as Pessoas sejam simples, contudo, sem prejuízo da simplicidade,
podem ser expressas em abstrato as razões próprias delas, como dissemos.

## Art. 3 — Se há cinco noções.
(I Sent., dist. XXVI, q. 2, a. 3; dist. XXVIII, q. 1, a. 1; De Pot., q. 3, a. 9, ad 21, 27; q. 10, a. 5, ad 12;
Compend Theol., cap. LVII sqq).
O terceiro discute-se assim. — Parece que não há cinco noções.

1. — Pois, as noções próprias das Pessoas são as relações pelas quais se distinguem. Ora, em Deus,
como se disse, não há senão quatro relações. Logo, só há também quatro noções.

2. — Demais. — Por ter uma só essência, diz-se que Deus é uno; mas, por serem três as Pessoas, que é
trino. Se portanto, há nele cinco noções, há de se chamar quino, o que é inconveniente.

3. — Demais. — Se, por existirem em Deus três Pessoas, existem cinco noções, é necessário que em
alguma das pessoas haja certas noções, duas ou mais, assim como na Pessoa do Pai existe a
inascibilidade, a paternidade e a expiração comum. Ora, ou estas três noções diferem realmente, ou
não. Se diferem, segue-se que a Pessoa do Pai é composta de várias realidades. Se, porém, só
racionalmente diferem, segue-se que uma delas pode predicar-se da outra, podendo então dizer-se, que
assim como a bondade de Deus é a sua sabedoria, por não haver entre elas diferença real, assim a
expiração comum é a paternidade — o que se não concede. Logo, não há cinco noções.
Mas, em contrário, parece sejam mais as noções. Pois, assim como o Pai, de ninguém procedendo, dá
origem à noção da inascibilidade, assim do Espírito Santo não procede outra pessoa. E, portanto, será
necessário admitir-se uma sexta noção.
Demais. — Sendo comum ao Pai e ao Filho o proceder deles o Espírito Santo, assim é comum ao Filho e
ao Espírito Santo o procederem do Pai. Logo, assim como há uma noção comum ao Pai e ao Filho, assim
deve haver outra comum ao Filho e ao Espírito Santo.

SOLUÇÃO. — Chama-se noção à razão própria pela qual se conhece a Pessoa divina. Ora, as Pessoas,
divinas se multiplicam pela origem; e como esta implica a proveniência de outro ser e o ser proveniente
doutro, por estes dois modos podemos conhecer a pessoa. Por onde, não pode a Pessoa do Pai ser
conhecida como provinda de outro, mas como a que ninguém provém; cabendo-lhe então deste modo a
noção da inascibilidade. Mas, enquanto alguém dele provém de duplo modo pode o Pai ser conhecido
pela noção de paternidade; e enquanto dele provém, o Espírito Santo, o é pela noção de espiração
comum. O Filho, por seu lado, pode ser conhecido como proveniente de outro por nascimento; e assim,
é conhecido pela filiação; e porque dele procede outra Pessoa, a saber, o Espírito Santo, é conhecido
ainda pelo mesmo modo porque o Pai o é, a saber, pela espiração comum. Quanto ao Espírito Santo,
pode ser conhecido enquanto procedente de outro ou de outros, e assim o é pela processão; não o é,
porém, por dele proceder outro, pois, nenhuma pessoa divina dele procede. Logo, há cinco noções em
Deus, a saber: a inascibilidade, a paternidade, a filiação, a espiração comum, e a processão. Mas delas só
quatro são relações, pois a inascibilidade só por uma redução é relação, como depois se dirá. Enquanto
às outras quatro, elas são somente propriedades, pois, a espiração comum, convindo a duas pessoas,
não é uma propriedade. E três são as noções pessoais, i. é, constitutivas das Pessoas, a saber, a
paternidade, a filiação e a processão; pois, a espiração comum e a inascibilidade se chamam noções de
Pessoas, não porém pessoais, como a seguir mais claro ficará.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Além das quatro relações é necessário introduzir outra
noção, como se disse.

RESPOSTA À SEGUNDA. — A essência em Deus é entendida como significativa de uma certa realidade;
e, semelhantemente, como certas realidades, são entendidas as Pessoas. Mas as noções consideram-se
como razões notificativas das Pessoas. Por onde, embora Deus seja denominado uno pela unidade de
essência, e trino, pela Trindade das Pessoas, todavia não lhe chamamos quino, por causa das cinco
noções.

RESPOSTA À TERCEIRA. — Como só a oposição relativa faz a pluralidade real em Deus, às varias
propriedades de uma Pessoa, não se opondo relativamente entre si, realmente não diferem. Mas nem
por isso se predicam umas das outras, pois se consideram como significativas das diversas razões das
Pessoas; assim como também não dizemos, que o atributo da potência é o atributo da ciência, embora
digamos que a ciência é uma potência.

RESPOSTA À QUARTA. — A pessoa, importando dignidade, como já se disse, nenhuma noção pode ser
admitida, no Espírito Santo, por não provir dele nenhuma Pessoa. Pois, isto não lhe pertence à
dignidade, como pertence a autoridade do Pai não provir ninguém.

RESPOSTA À QUINTA. — O Filho e o Espírito Santo não convém em se originarem do Pai de um modo
especial, como o Pai e o Filho convém em produzirem o Espírito Santo de um modo especial. Ora é
necessário que o princípio de conhecimento seja algo de especial. Portanto, não há semelhança.

## Art. 4 — Se é lícito opinar contrariamente sobre as noções.
(I Sent., dist. XXXIII, a. 5).
O quarto discute-se assim. — Parece que não é lícito opinar contrariamente sobre as noções.

1. — Pois, Agostinho diz em matéria nenhuma se erra mais perigosamente do que na da Trindade, à
qual é certo pertencerem as noções. Ora, opiniões contrárias não vão sem erro. Logo, não é lícito opinar
contrariamente sobre as noções.

2. Demais. — Pelas noções se conhecem as Pessoas, como se disse. Ora, destas não é lícito opinar
contrariamente. Logo, nem daquelas.
Mas, em contrário, os artigos da fé não concernem às noções. Logo, destas se pode opinar de tal
maneira ou de tal outra.

SOLUÇÃO. — Duplamente pode uma verdade ser de fé. — De um modo direto; e assim aquelas que
principalmente nos foram por Deus transmitidas, como o ser ele trino e uno, o ter-se encarnado o seu
Filho e semelhantes. E opinar falsamente sobre tais coisas é ao mesmo tempo incidir em heresia,
sobretudo se isso for acompanhado de pertinácia. — Porém, de modo indireto pertencem à fé as
afirmações das quais resulta algo de contrário a ela; assim, de se dizer que Samuel não foi filho de
Elcana seguir-se-ia a falsidade da Escritura Divina. Donde, no tocante a tais assuntos, alguém pode
opinar falsamente, sem perigo de heresia, antes de ser considerado determinado que daí se segue algo
contrário a fé; e sobretudo se não aderir pertinazmente. Mas, depois de ser manifesto e sobretudo se
for determinado pela Igreja, que daí segue algo contrário a fé, já não pode então errar sem heresia.
Donde vem o se reputarem hoje heresia muitas opiniões que outrora se não reputavam tais, por ser
hoje mais manifesto o que delas se segue. Assim, pois, devemos dizer que sobre as noções, alguns
opinaram contrariamente sem perigo de heresia, não entendendo sustentar nada de contrário a fé. Mas
quem opinasse falsamente sobre as noções, considerando que daí se seguiria algo de contrário a fé,
incidiria em heresia.
Donde se deduzem claras as RESPOSTAS ÀS OBJEÇÕES.