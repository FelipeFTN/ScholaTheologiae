# Questão 49: Da causa do mal.
Em seguida se trata da causa do mal. E, sobre este assunto, três artigos se discutem:

## Art. 1 — Se o bem pode ser causa do mal.
(Ia IIae, q. 75, a. 1; II Sent., dist. I, q. 1. a. 1, ad 2; dist. XXXIV; a. 3; II Cont. Gent., cap. XLI; III, cap. X, XIII;
De Pot., q. 3, a. 6, ad 1 sqq.; De Malo, q. 1, a. 3; De Div. Nom., cap. IV, lect. XXII).
O primeiro discute-se assim. – Parece que o bem não pode ser causa do mal.

1. – Pois, a Escritura diz (Mt 7, 18): Não pode a árvore boa dar maus frutos.

2. Demais. – De dois contrários um não pode ser a causa do outro. Ora, o mal é o contrário do bem.
Logo, o bem não pode ser causa do mal.

3. Demais. – O efeito deficiente não procede senão da causa deficiente. Ora, o mal, se tiver causa, é um
efeito deficiente. Logo, tem uma causa deficiente. Mas, como tudo o que é deficiente é mau, só o mal
pode ser a causa do mal.

4. Demais. – Dionísio diz que o mal não tem causa. Logo, o bem não é a causa do mal.
Mas, em contrário, dia Agostinho: De nada mais pode nascer o mal, a não ser do bem.

SOLUÇÃO. – É forçoso admitir-se que todo mal tenha, de certo modo, causa. Pois, o mal é a falta do
bem natural ao ser e que este deve ter. Mas a deficiência de um ser, em relação à sua natural e devida
disposição, só pode provir de alguma causa que o arrasta contrariamente à sua disposição; assim, um
grave não pode mover-se para cima senão por uma causa que o impele; e a ação do agente só é
deficiente, por algum impedimento. Ora, só o bem pode ser causa, porque nada é causa senão
enquanto ser, e todo ser, como tal, é bom.
E se considerarmos a natureza especial das causas veremos que o agente, a forma e o fim importam
certa perfeição e se prendem à natureza do bem; e também a matéria, como potência para o bem, tem
a natureza deste. E assim, do que já se disse antes, é claro que o bem é causa do mal, por meio da causa
material; pois, se demonstrou que o bem é o sujeito do mal. Quanto à causa formal, o mal não a tem,
pois ele é, antes, a privação da forma. E, semelhantemente, nem causa final, sendo, pelo contrário, o
mal a privação da ordenação ao fim devido; pois, não só o fim tem a natureza de bem, mas também o
útil, que se ordena ao fim. Porém, o mal tem causa ao modo do agente, não certo por si, mas por
acidente.
Para cuja evidência deve saber-se que de um modo é causado o mal na ação e de outro no efeito. Na
ação, o mal é causado por defeito de algum dos princípios dela, a saber, do agente principal ou do
instrumental; assim, o defeito no movimento do animal pode provir da debilidade da força motora,
como nas crianças, ou só na inaptidão do instrumento, como nos côxos. Porém, num efeito qualquer, o
mal é causado ora pela virtude do agente, sem que o seja no efeito mesmo dele; ora por defeito do
agente ou da matéria. Assim; é causado pela virtude do agente, quando, da forma visada pelo agente
resulta necessariamente a privação de outra forma; p. ex., da existência da forma ígnea resulta a
privação da forma do ar ou da água. Donde, quanto mais o fogo for perfeito em virtude, tanto mais
perfeitamente imprimirá a sua forma e assim, também, tanto mais perfeitamente corromperá o seu
contrário. Por onde, o mal e a corrupção do ar e da água resultam da perfeição do fogo. Mas isso por
acidente, pois o fogo não visa privar a forma da água, senão imprimir a forma própria; mas, fazendo tal,
causa a dita privação, por acidente. Porém, se houver defeito no efeito próprio do fogo, p. ex., que este
seja deficiente no aquecer, tal se terá dado ou por defeito da ação, o que redunda no defeito de algum
princípio, como ficou dito; ou por indisposição da matéria que não recebe a ação do fogo agente. Mas o
fato mesmo da deficiência atinge o bem, ao qual é próprio, por si, agir. Por onde, é verdade que o mal
denenhum modo tem causa, a não ser por acidente. Assim, o bem é a causa do mal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Como diz Agostinho, O Senhor chama árvore má à má
vontade e árvore boa à boa vontade. Mas a vontade boa não produz nenhum ato moralmente mau, pois
é pela própria vontade boa que o ato moral é julgado bom. Porém, o ato mesmo da vontade má é
causado pela criatura racional, que é boa. E assim é a causa do mal.

RESPOSTA À SEGUNDA. – O bem não causa o mal que lhe é contrário, mas outro; assim, a bondade do
fogo causa o mal da água; o homem, bom por natureza, causa o ato moral mau. E isto mesmo por
acidente, como se disse. Contudo, acontece que também, de dois contrários, um causa o outro por
acidente; assim, o frio reinante no exterior aquece, fazendo o calor retrair-se para o interior.

RESPOSTA À TERCEIRA. – O mal tem causa deficiente, de um modo nas coisas voluntárias, e de outro
nas naturais. Pois, o agente natural produz o seu efeito tal como este é, salvo se for impelido por alguma
causa extrínseca; e isto mesmo é um defeito do agente. Por onde, nunca aparece o mal no efeito, sem
que preexista algum outro mal no agente ou na matéria, como já se disse. Nos atos voluntários, porém,
o defeito da ação procede da vontade deficiente no ato porque não se submete, neste, à sua regra. Cujo
defeito porém não é culpa, se bem dele resulta esta, porque a vontade obra com tal defeito.

RESPOSTA À QUARTA. – O mal não tem causa por si mesmo, mas só por acidente, como já se disse.

## Art. 2 — Se o sumo bem, Deus, é causa do mal.
(Supra, q. 48, a. 6; II Sent., disto XXXII, q. 2, a. 1; dist. XXXIV, a. 3; dist. XXXVII, q. 3, a. 1; II Cont; Gent..,
cap. XLI; III, cap. LXXI; De Malo, q. 1, a. 5; Compend. Theol., cap. CXLI; ln Ioan., cap. IX, lect. ad Rom., cap.
I, lect. VII).
O segundo discute-se assim. – Parece que o sumo bem, Deus, é causa do mal.

1. – Pois, diz a Escritura (Is 45, 6-7): Eu Sou o Senhor, e não há outro. Eu o que formo a luz e crio as
trevas, o que faço a paz e crio o mal; e outra passagem (Am 3, 6): Se acontecerá algum mal na cidade,
que o senhor não fizesse?

2. Demais. – O efeito da causa segunda reduz-se à causa primeira. Ora, o bem é a causa do mal, como já
se disse. Sendo portanto Deus a causa de todo bem, como mais acima se demonstrou, segue-se também
que todo o mal vem de Deus.

3. Demais. – Como diz Aristóteles, a causa da salvação de uma nau é idêntica à do perigo. Ora, Deus é a
causa da salvação de todas as coisas. Logo também é a causa de toda perdição e de todo mal.
Mas, em contrário, diz Agostinho que Deus não é o autor do mal, porque não é causa da tendência para
o não-ser.

SOLUÇÃO. – Como resulta do que já foi dito, o mal consistente na deficiência da ação é sempre causado
pela deficiência do agente. Em Deus porém não há nenhuma deficiência, pois Ele é a suma perfeição,
como já antes se demonstrou. Por onde, o mal consistente na deficiência da ação, ou causado por
deficiência do agente, não se reduz a Deus como a sua causa. – Porém, o mal consistente na corrupção
de certas coisas reduz-se a Deus como à sua causa. E isto é claro tanto nas coisas naturais como na
ordem do voluntário. Pois, já se disse que um agente produtor, pela sua virtude, de uma forma, da qual
resulte corrupção e deficiência, causa, pela mesma virtude a corrupção e a deficiência. Ora, é manifesto
que a forma principalmente visada por Deus nas coisas criadas é o bem da ordem do universo. Esta,
porém, requer, como antes foi dito, existam certos seres susceptíveis da deficiência, que por vezes
realmente têm. E assim Deus, causando, nas coisas, o bem da ordem do universo, por conseqüência e
como por acidente causa as corrupções delas, conforme diz a Escritura (1 Rg 2, 6): O Senhor é o que tira
a vida e a dá. E no dito da mesma (Sb 1, 13) –Deus não fez a morte– deve-se entender a morte como
visada em si mesma. Pois, à ordem do universo pertence também a da justiça, exigindo que se inflija
uma pena aos pecadores. E, neste sentido, Deus é o autor do mal que é pena, não porém do que é
culpa, pela razão supra exposta.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – As passagens citadas se referem ao mal da pena, não
porém ao da culpa.

RESPOSTA À SEGUNDA. – O efeito da causa segunda deficiente reduz-se à causa prima não deficiente,
quanto ao que ele tem de entidade e de perfeição; não porém quanto ao que tem de deficiência. Assim,
tudo o que na claudicação é movimento é causado pela virtude motora; mas o que nela é obliqüidade
não vem da virtude motora mas da curvatura da perna. E semelhantemente, tudo o que é realidade e
ato na má ação reduz-se a Deus como à sua causa; mas o que nela é deficiência não é causado por Deus,
mas pela causa segunda deficiente.

RESPOSTA À TERCEIRA. – A submersão da nau é atribuída ao nauta, como à causa, porque não fez o
necessário para a salvação dela; mas Deus não deixa de fazer o necessário à salvação. Por onde o símile
não colhe.

## Art. 3 — Se há um mal sumo, causa de todo mal.
(II Sent., dist. I, q. 1, a. 1, ad 1; dist. XXXIV, a. 1, ad 4; II Cont. Gent., cap. XLI; III, cap. XV; De Pot., q. 3, a.
6; Compend. Theol., cap. CXVII; Opusc. XV, De Angelis, cap. XVI; De Div. Nom., cap. IV, lect. XXII).
O terceiro discute-se assim. – Parece que há um mal sumo, causa de todo mal.

1. – Pois, efeitos contrários têm causas contrárias. Ora, há contrariedade nas coisas, segundo a Escritura
(Ecle 33, 15): Contra o mal está o bem, e contra a morte a vida; assim também contra o homem justo o
pecador.Logo, há dois princípios contrários, um do bem, outro do mal.

2. Demais. – Se um dos contrários está em a natureza das coisas, também o outro, como diz Aristóteles.
Ora, o sumo bem está em a natureza das coisas, pois ele é a causa de todo bem, como já antes se
demonstrou. Logo, também o mal sumo, que lhe é oposto, é causa de todo o mal.

3. Demais. – Como nas coisas há o bom e o melhor, assim também o mau e o pior. Ora, bem e o melhor
se dizem pela relação com o ótimo. Logo, o mau e o pior pela relação com algum sumo mau.

4. Demais. – Tudo o que é por participação se reduz ao que é por essência. Ora, as coisas más para nós
não são más por essência, mas por participação. Logo, deve haver algum mal sumo, causa de todo mal.

5. Demais. – Tudo o que é acidental se reduz ao que é essencial. Ora, o bem é causa do mal acidental.
Logo, é necessário admitir algum mal sumo, causa essencial dos males. Nem se pode dizer que o mal
não tenha causa por si, senão só acidente; porque daí resultaria que o mal não existe na maioria, mas só
na minoria dos casos.

6. Demais. – O mal do efeito se reduz ao da causa, porque o efeito deficiente vem de causa deficiente,
como já antes se disse. Ora, não se pode ir até o infinito. Logo, é necessário admitir um primeiro mal,
causa de todo mal.
Mas, em contrário, o sumo bem é causa de todo ser, como já antes se demonstrou. Logo, não pode
haver um princípio que lhe seja oposto e causa dos males.

SOLUÇÃO. – Do já dito resulta que não há um primeiro principio do mal, como há um do bem.
Primeiro, porque o primeiro princípio do bem é por essência bom, como antes já foi demonstrado. Ora,
nada pode ser mau por essência, pois já se demonstrou que todo ser, como tal, é bom, e que o mal só
pode existir no bem como no seu sujeito.
Segundo, porque o primeiro principio do bem é o sumo e perfeito bem, que preencerra em si toda
bondade, como antes ficou demonstrado. Porém, não pode haver um mal sumo, pois, segundo já se
demonstrouembora o mal sempre diminua o bem, todavia não pode nunca consumi-lo totalmente, e,
assim, sempre remanescendo o bem, nada pode haver íntegra e perfeitamente mau. Pelo que o Filósofo
diz: o mal integral se destruirá a si mesmo, pois, destruído todo o bem, o que é exigido para a
integridade do mal, elimina-se também o próprio mal, cujo sujeito é o bem.
Terceiro, porque a essência do mal repugna à noção de princípio. Quer por ser o mal causado pelo bem,
como antes já se demonstrou. Quer por não poder assim ser causa primeira; pois, a causa acidental é
posterior à essencial, como está claro em Aristóteles.
E os que admitiram dois princípios primeiros, um bom e outro mau, esses caíram em tal erro pelo
mesmo fundamento por que professaram semelhantes opiniões estranhas aos antigos; a saber, por não
considerarem a causa universal de todo ser, mas somente as causas particulares de efeitos particulares.
E por isso, se verificavam ser nociva a outra uma coisa, em virtude da sua natureza, consideravam a
natureza dessa coisa má, como se, por ex., disséssemos ser a natureza do fogo má porque queimou a
casa de um pobre. Ora, o juízo sobre a bondade de uma coisa não se deve formar pela referência a algo
de particular, mas por si mesmo e pela referência a todo o universo, no qual cada coisa tem o seu lugar
mui ordenadamente, como se vê pelo já dito. E semelhantemente, os que pensaram que dois efeitos
particulares contrários têm duas causas particulares contrárias, não souberam reduzir estas à causa
universal comum. E por isso julgaram que até quanto aos primeiros princípios há contrariedade nas
causas. Mas, como todos os contrários convêm em algo de comum, necessário é descobrir-lhes uma
causa comum superior às causas contrárias próprias; assim, superior às qualidades contrárias dos
elementos encontra-se a virtude do corpo celeste. E semelhantemente, superior a tudo o que de
qualquer modo existe, encontra-se um primeiro principio de existir, como antes já se demonstrou.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. – Os contrários convêm num mesmo gênero e também na
razão de existirem. Por onde, embora tenham causasparticulares contrárias, todavia é necessário
chegar-se a uma causa primeira comum.

RESPOSTA À SEGUNDA. – Da natureza da privação e do modo de ser (hábito) é que se refiram à mesma
coisa. Ora, o sujeito da privação é o ser em potência, como já ficou dito. Por onde, sendo o mal a
privação do bem, como resulta do já dito (ibid), o mal se opõe ao bem com o qual vai junta a potência;
não porém ao sumo bem, que é ato puro.

RESPOSTA À TERCEIRA. – Cada coisa se considera segundo a sua noção própria. Ora, assim como a
forma é uma perfeição, assim a privação é uma remoção. Por onde toda forma, toda perfeição e todo
bem se consideram pela aproximação ao termo perfeito; porém a privação e o mal, pelo afastamento do
termo. Por isso não se considera o mau e o pior pela aproximação ao mal sumo, como se considera o
bom e o ótimo pela aproximação ao sumo bem.

RESPOSTA À QUARTA. – Não se considera mal nenhum ser, por participação, mas por privação da
participação. Por onde, não é necessário fazer-se a redução a algo que seja por essência mau.

RESPOSTA À QUINTA. – O mal não pode ter causa senão por acidente, como antes se demonstrou.
Donde é impossível fazer-se a redução a algo que seja por si causa do mal. E o dizer-se que o mal existe
na maioria dos casos é absolutamente falso. Pois, os seres geráveis e corruptíveis, em que unicamente
consiste o mal da natureza, são pequena parte de todo o universo. E demais, em cada espécie, a
deficiência da natureza se dá na minoria dos casos. Só nos homens o mal aparece na maioria, porque
não o bem, quanto aos sentidos do corpo, é o bem do homem como homem, mas sim o bem racional;
ora, são mais numerosos os sequazes dos sentidos que os da razão.

RESPOSTA À SEXTA. – Nas causas do mal não se pode proceder até ao infinito; mas é mister reduzir
todos os males a alguma causa boa, da qual resulta o mal por acidente.
Tratado dos anjos