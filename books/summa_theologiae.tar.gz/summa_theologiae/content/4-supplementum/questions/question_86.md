# Questão 86: Da condição dos corpos dos condenados, depois da ressurreição.
Devemos em seguida tratar da condição dos corpos dos condenados, depois da ressurreição.
E nesta questão discutem-se três artigos:

## Art. 1 — Se os corpos dos condenados ressurgirão com as suas deformidades.
O primeiro discute-se assim. ─ Parece que os corpos dos condenados ressurgirão com as suas
deformidades.

1. ─ Pois, o que foi estabelecido como pena do pecado não pode cessar senão com a remissão dele. Ora,
a falta de membros, causada pela mutilação, é uma consequência da pena do pecado; e
semelhantemente todas as mais deformidades do corpo. Logo, os condenados não ficarão isentos
dessas deformidades, depois da ressurreição, que não foram perdoados dos pecados.

2. Demais. ─ Assim como a ressurreição dos santos será a consumação da felicidade deles, assim a dos
ímpios, a da sua miséria. Ora, os santos ressurrectos não ficarão privados de nada que lhe possa
constituir uma perfeição. Logo, também os ímpios ressuscitados não ficarão privados de nenhum dos
seus defeitos ou misérias. Ora, tais lhes são as deformidades. Logo, etc.

3. Demais. ─ Assim como a deformidade, a lentidão é um defeito do corpo passível. Ora, os corpos dos
condenados ressuscitados não perderão a sua lentidão, pois não terão o dote da agilidade. Logo e pela
mesma razão também não perderão a sua deformidade.
Mas, em contrário. ─ Diz o Apóstolo: Os mortos ressuscitarão incorruptíveis. E comenta a Glosa: Os
mortos, i. é, os pecadores, ou em geral todos os mortos, ressurgirão incorruptos, i. é, sem nenhuma
diminuição de membros. Logo, os maus ressurgirão sem as suas deformidades.

2. Demais. ─ Os condenados nada terão que os possa impedir de sentir dores. Ora, a doença impede de
as sentirmos, pois nos debilita os órgãos da sensibilidade. Semelhantemente, a falta de um membro não
permitiria mais que a dor fosse sentida por todo o corpo. Logo, os condenados ressurgirão sem tais
defeitos.

SOLUÇÃO. ─ O corpo humano é susceptível de duas espécies de deformidade.
Uma vem da falta de algum membro; assim, dizemos que os mutilados são disformes, por lhes faltar a
proporção devida entre as partes e o todo. E essa deformidade nenhuma dúvida há, que os corpos dos
condenados não na sofrerão; porque todos os corpos, tanto o dos bons como o dos maus, ressurgirão
íntegros.
Outra espécie de deformidade é a resultante da má disposição das partes, na sua grandeza, na sua
qualidade ou pelo lugar que ocupam. O que também não se coaduna com a proporção devida entre as
partes e o todo. E quanto a essas deformidades e defeitos semelhantes, como as febres de doenças com
elas, que são às vezes causas de deformidades, dessas Agostinho deixa indeterminado e duvidoso se os
condenados estão isentos, como o refere o Mestre.
Mas, entre os doutores modernos duas opiniões há a respeito.
Certos dizem que tais deformidades e defeitos permanecerão nos corpos dos condenados,
considerando que, condenados, caem num estado de miséria suma, a que nenhum mal pode faltar. ─
Mas não é racional esse modo de pensar. Pois, na reconstituição do corpo ressuscitado mais é de
atender-se à perfeição da natureza do que a sua condição anterior; por isso, os que morreram antes de
chegar à idade perfeita ressurgirão na idade viril. Assim também os que tiveram certos defeitos naturais
no corpo, ou deformidades dele provenientes, ressurgirão sem esses defeitos ou deformidades. Mas, a
modalidade da pena depende da medida da culpa. Pode porém acontecer que um pecador que deve ser
condenado por pecados mais leves, tenha certas deformidades ou defeitos que não teve outro que deve
ser condenado por pecados mais graves. Por isso, se o que teve deformidades nesta vida ressurgir com
elas, sem com elas ressurgir outro que deve sofrer mais grave pena, pelas nesta vida não ter, o modo da
pena não corresponderia à gravidade da culpa e, antes, resultaria que seria mais punido quem nesta
vida já sofreu penas; o que é absurdo.
Por isso outros com mais razão dizem, que o Autor da natureza restituirá integramente ao corpo a sua
natureza, na ressurreição. Portanto, todos os defeitos ou deformidades corporais provenientes da
corrupção ou debilidade natural ou dos princípios naturais, como a febre e semelhantes, tudo isso
desaparecerá elo corpo ressuscitado. Mas os defeitos que o corpo humano padece provenientes dos
seus princípios naturais, como a gravidade, a passibilidade e outros, esses subsistirão nos corpos do
condenados; defeitos esses que a glória da ressurreição tornará isentos os corpos dos eleitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Como em qualquer foro uma pena é infligida segundo as
condições dele, as penas infligidas por algum pecado nesta vida temporal são temporais e não
ultrapassam os termos dela. Por onde, embora aos condenados não lhes tenham sido perdoados os
pecados, nem por isso hão de sofrer no outro mundo as mesmas penas que sofreram neste; mas a
divina justiça exige que sejam na outra vida atormentados por penas mais graves.

RESPOSTA À SEGUNDA. ─ Não se dá o mesmo com os bons e com os maus, porque um ser pode ser
absolutamente bom, mas não absolutamente mau. Por isso, a felicidade consumada dos santos requere
sejam totalmente imunes de qualquer mal; ao contrário, a miséria suprema não exclui completamente o
bem, porque o mal que fosse completo se destruiria a si mesmo, como ensina o Filósofo. Por onde e
necessariamente, a miséria dos condenados terá como substrato o bem da natureza; e o Criador, que é
a perfeição mesma, também restaurará a natureza na perfeição mesma da sua espécie.

RESPOSTA À TERCEIRA. ─ A lentidão é de aqueles defeitos naturalmente consequentes aos princípios do
corpo humano; não porém a deformidade. Não há, pois, semelhança de razões.

## Art. 2 — Se os corpos dos condenados serão corruptíveis.
O segundo discute-se assim. ─ Parece que os corpos dos condenados serão corruptíveis.

1. ─ Pois, todo composto de elementos contrários é necessariamente corruptível. Ora, os corpos dos
condenados serão compostos dos mesmos elementos corruptíveis de que presentemente o são; do
contrário não seriam da mesma espécie e por consequência, nem individualmente os mesmos. Logo,
serão corruptíveis.

2. Demais. ─ Se na vida futura os corpos dos condenados forem incorruptíveis não o será por natureza;
pois, terão a mesma natureza que agora tem. Nem pela graça ou pela glória, porque, de uma e de outra
estarão totalmente privados. Logo, serão corruptíveis.

3. Demais. ─ É inadmissível que fiquem livres da pena máxima os que estão num estado de miséria
suma. Ora, a máxima das penas é a morte, como o Filósofo o prova. Logo, os condenados, cujo estado é
de suma miséria, não poderão livrar-se da morte. Logo, os seus corpos serão corruptíveis.
Mas, em contrário, a Escritura: Naqueles dias os homens buscarão a morte e não na acharão; eles
desejarão morrer e a morte fugirá deles. eles desejarão morrer e a morte fugirá deles.

2. Demais. ─ Os condenados sofrerão na alma e no corpo uma pena perpétua, conforme aquilo do
Evangelho: Irão estes para o suplício eterno. Ora, isto não seria possível se o corpo lhes fosse
corruptível. Logo, o corpo não se lhes corromperá.

SOLUÇÃO. ─ Como todo movimento deve ter um princípio, móvel de dois modos, pode um móvel ficar
privado de um movimento ou mudança: por lhe faltar o princípio motor ou por encontrar um obstáculo
o princípio do movimento. Ora, a corrupção é uma espécie de mudança. Por onde, de dois modos é
possível tornar-se incorruptível um corpo corruptível pela condição dos seus princípios constitutivos. ─
Primeiro, por se lhe arredar completamente o princípio causador da corrupção. E deste modo os corpos
dos condenados serão incorruptíveis. Pois, sendo o céu, pelo seu movimento local, a primeira causa da
alteração; e todos os agentes segundos atuem em virtude dele e como por ele movidos,
necessariamente, cessado o movimento do céu, nenhum agente poderá haver capaz de, por alteração
natural, transformar as propriedades naturais de um corpo. Por isso, depois da ressurreição, cessado o
movimento do céu, nenhuma qualidade haverá capaz de modificar o tamanho natural do corpo
humano. Ora, a corrupção é, como a geração, o termo da alteração. Logo, os corpos dos condenados
não poderão corromper-se. E assim executam a justiça que requer sejam punidos eternamente numa
vida eterna, como mais adiante diremos. Assim como presentemente a corruptibilidade dos corpos
servem aos desígnios da divina providência, que estabeleceu a geração de uns da corrupção de outros. ─
Mas o princípio da corrupção pode ainda ficar impedido de outro modo, pelo qual o corpo de Adão foi
incorruptível. Pois, as qualidades contrárias do corpo humano a graça da inocência as impedia de lhe
operarem a dissolução. E muito mais impedidas serão de corromper os corpos gloriosos,
completamente sujeitos ao espírito. E assim nos corpos dos bem-aventurados, depois da ressurreição
universal, se conjugarão as duas causas referidas de incorruptibilidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os elementos contrários componentes do corpo são os
princípios segundos produtores da corrupção; sendo o agente primeiro o movimento celeste. Por onde,
suposto o movimento do céu, necessariamente há de corromper-se um corpo composto de elementos
contrários; salvo se uma causa mais poderosa impedir essa corrupção. Mas, cessado o movimento do
céu, os elementos contrários componentes do corpo não bastam a causar a corrupção, mesmo segundo
a natureza, como do sobredito se colhe. Ora, a cessação do movimento celeste não na conheceram os
Filósofos. Por isso tinham como verdade infalível que um corpo composto de elementos contrários há
de corromper-se, mesmo naturalmente considerado.

RESPOSTA À SEGUNDA. ─ Essa incorruptibilidade será por virtude da natureza. Não que haja um
princípio de incorrupção nos corpos dos condenados, mas por não haver neles nenhum princípio de
corrupção.

RESPOSTA À TERCEIRA. ─ Embora a morte seja, absolutamente falando, a máxima das penas, sob certos
respeitos porém: nada impede seja a morte um remédio das penas; e por consequência privar dela é
aumentá-las a estas. Pois, como diz o Filósofo, se viver é agradável a todos os viventes é que todos os
seres desejam perdurar na existência; mas não é um bem, continua no mesmo lugar, viver uma vida má
nem corrupta nem imersa em sofrimentos. Assim, portanto, como viver, absolutamente falando, é
agradável, mas não viver nos sofrimentos, assim também a morte, que é a privação da vida, é penosa,
considerada em si mesma, e a máxima das penas, por nos privar da existência, que é o primeiro dos
bens, e com ela de tudo o mais. Mas, enquanto nos livra de uma vida má e cheia de tristezas, remédio
de penas e o que nô-la acaba. Por consequência, a isenção da morte aumenta as penas pelas fazer
perpétuas. ─ Se, porém, dissermos que a morte é uma pena por causa dos sofrimentos que os
moribundos padecem no corpo, não há dúvida que muito maiores serão as penas sofridas
continuamente pelos condenados. Por isso sofrem uma morte perpétua, conforme aquilo da Escritura.

## Art. 3 — Se os corpos dos condenados serão impassíveis.
O terceiro discute-se assim. ─ Parece que os corpos dos condenados serão impassíveis.

1. ─ Pois, segundo o Filósofo, toda paixão, aumentando, causa detrimento à substância. Ora, se
diminuirmos sempre um corpo finito, acabará ele necessariamente por desaparecer, diz ainda
Aristóteles. Logo, os corpos dos condenados, sendo sempre passíveis e padecentes, hão de acabar
deperecendo e consumindo-se. O que já se demonstrou ser falso. Portanto, serão impassíveis.

2. Todo agente torna o paciente semelhante a si. Se, pois, os corpos dos condenados sofrerem o suplício
do fogo, ao fogo hão de assemelhar-se. Ora, o fogo não consome os corpos senão fazendo-os
desaparecer pelos tornar semelhantes a si. Se, portanto, os corpos dos condenados forem impassíveis,
hão de acabar consumidos pelo fogo, De onde a mesma conclusão que antes.

3. Demais. - Os animais, como a salamandra, de que se conta que podem suportar o fogo, não sofrem
com ele; pois, nenhum animal sofrerá dor no seu corpo sem este ser de algum modo ofendido. Se,
portanto, o corpo dos condenados podem sofrer o fogo sem se aniquilarem, como os referidos animais,
segundo o diz Agostinho, parece que nenhum detrimento deles lhes advirá, O que não seria possível se
não tivessem o corpo impassível. Logo, etc.

4. Demais. ─ Se os corpos dos condenados são passíveis, a dor que os tormentos lhes causam hão de,
segundo parece, superar todas as dores que nesta vida lhes afligiram o corpo; assim como a felicidade
dos santos superará todas as felicidades desta vida. Ora, nesta vida, uma dor pode ser tão intensa que
cause a separação da alma, do corpo. Logo e com muito maior razão, se na vida futura os corpos dos
condenados forem passíveis, a imensidade dos sofrimentos lhes separará a alma do corpo, que será
então corruptível. O que é falso. Logo, os corpos dos condenados serão impassíveis.
Mas, em contrário, aquilo do Apóstolo ─ E nós outros seremos mudados ─ diz a Glosa: Só os bons é que
seremos transformados pela imutabilidade e pela impassibilidade da glória. Logo, os corpos dos
condenados serão impassíveis.

2. Demais. ─ Assim como o corpo colabora com a alma para o mérito, assim também para o pecado. Ora,
por causa dessa cooperação, não só a alma será premiada depois da ressurreição, mas também o corpo.
Logo e pela mesma razão, também serão punidos os corpos dos condenados. O que não se daria se
fossem impassíveis. Logo, serão passíveis.

SOLUÇÃO. ─ A causa principal, por que os corpos dos condenados não serão consumidos pelo fogo, será
a divina justiça, que lhes jungiu os corpos a uma pena perpétua. Mas a justiça divina se serve das
disposições naturais do corpo, quer do paciente, quer do agente. Porque, sendo a paixão uma recepção
há uma dupla modalidade de paixão, conforme os dois modos por que pode uma causa ser recebida por
outra. ─ Pois, pode um sujeito receber uma forma só no ser material desta; assim o ar recebe o calor do
fogo. E este modo de receber determina uma espécie de paixão chamada paixão da natureza. ─ De
outra maneira, uma cousa é recebida por outra espiritualmente e a modo de semelhança; assim, o ar e a
pupila recebem a imagem da brancura. E este modo de receber é comparável ao pelo qual a alma
recebe as semelhanças das cousas; e nele se funda outra modalidade da paixão, chamada paixão da
alma.
Ora, como depois da ressurreição, cessado o movimento do céu, nenhum corpo pode sofrer alteração
nas suas qualidades naturais, como se disse, nenhum corpo poderá sofrer a paixão da natureza. E assim,
quanto a esta modalidade da paixão, os corpos dos condenados serão impassíveis bem como
incorruptíveis. ─ Mas, cessado o movimento do céu, ainda restará a paixão da alma; porque ainda o ar
será iluminado pelo sol e fará com que as diferenças de cores atinjam a vista. E assim, conforme esta
modalidade da paixão, os corpos dos condenados serão passíveis. E como tal paixão aguça a
sensibilidade, por isso os corpos dos condenados serão sensíveis à pena, sem alteração da sua
disposição natural.
Quanto aos corpos gloriosos, mesmo que recebam certas impressões e de certo modo sejam passíveis
ao sentir, contudo não serão passíveis. Porque nada receberão como pena nem dor, ao contrário do que
se dá com os corpos dos condenados, chamados por isso passíveis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O Filósofo se refere à paixão que altera a disposição
natural do paciente. E essa não a sofrerão os corpos dos condenados, como dissemos.

RESPOSTA À SEGUNDA. ─ A semelhança do agente de dois modos está no paciente. ─ Primeiro, pelo
mesmo modo por que está no agente, como se dá com todos os agentes unívocos; assim o calor gera o
calor e o fogo, o fogo. ─ De outro modo, com existência diversa da que tem no agente; tal o caso de
todos os agentes equívocos. E nestes pode-se dar que a forma exista no agente espiritualmente e seja
recebida materialmente pelo paciente; assim, a forma de uma casa feita por um arquiteto tem na casa o
seu ser material, e o espiritual na mente do artífice. Outras vezes se dá o contrário: a forma esta
materialmente no agente e é recebida espiritualmente pelo paciente; assim a brancura que esta
materialmente numa parede, donde é recebida espiritualmente pela pupila e pelo meio transmitente. E
o mesmo se dá no caso vertente. Porque a forma, existente materialmente no fogo, é recebida
espiritualmente pelos corpos dos condenados. E assim o fogo torná-los-á semelhantes a si, sem contudo
as consumir.

RESPOSTA À TERCEIRA. ─ Segundo o Filósofo, nenhum animal pode viver no fogo. E Galeno também diz
que nenhum corpo há que, exposto ao fogo, não acabe sendo consumido por ele; embora haja certos
corpos, como o ébano, que podem ficar algum tempo no fogo sem lhe sofrer a ação. Por isso, o caso
aduzido, da salamandra, não pode de nenhum modo ser verossímil; pois não podia perseverar no fogo
sem finalmente ser consumida, ao contrário do que se dá com os corpos dos condenados no inferno. ─
Nem se deve, do fato de os corpos dos condenados não serem em nada consumidos pelo fogo do
inferno, que não sejam torturados pelo fogo. Porque é da natureza do sensível não só deleitar ou afligir
os sentidos, pela sua ação natural de fortificar ou alterar o organismo, mas também pela sua ação
espiritual. Pois, quando o sensível é proporcionado ao sentido, causa-lhe prazer; e ao contrário, quando
há nele superabundância ou defeito. Por isso as cores médias e as vozes harmônicas são deleitáveis;
mas os sons discordes ofendem o ouvido.

RESPOSTA À QUARTA. ─ A dor não separa a alma do corpo enquanto permanece numa das potências
dela, que é o sujeito da dor; mas quando a paixão da alma muda a natural disposição do corpo; assim,
vemos que a cólera escandesce o corpo, ao passo que o temor o esfria. Mas depois da ressurreição já
não pode a disposição natural do corpo ser transformada, como do sobre dito se colhe. Por onde, por
maior que seja a dor, não poderá separar a alma do corpo.
