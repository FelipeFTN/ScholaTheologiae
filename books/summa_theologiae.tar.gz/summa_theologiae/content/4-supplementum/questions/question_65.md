# Questão 65: Da pluralidade das mulheres.
Em seguida devemos tratar da plural idade de mulheres.
E nesta questão discutem-se cinco artigos:

## Art. 1 — Se ter várias mulheres é contra a lei da natureza.
O primeiro discute-se assim. ─ Parece que ter várias mulheres não é contra a lei da natureza.

1. Pois, o costume não prejudica à lei natural. Ora, ter várias mulheres não constituía pecado, quando o
costume o permitia; como diz Agostinho. Logo ter várias mulheres não é contra a lei da natureza.

2. Demais. ─ Quem vai contra a lei da natureza contraria um preceito; pois, assim como a lei escrita tem
os seus preceitos, assim também a lei da natureza. Ora, Agostinho diz, que ter várias mulheres não ia
contra nenhum preceito, porque não era proibido por nenhuma lei. Logo, ter várias mulheres não é
contra a lei da natureza.

3. Demais. ─ O matrimônio foi sobretudo ordenado para a geração de filhos. Ora, um homem pode
fecundar várias mulheres e ter delas filhos. Logo, não é contra a lei da natureza ter várias mulheres.

1. Demais. ─ Direito natural é o que a natureza ensina a todos os animais, como se diz no princípio do
Digesto. Ora, a natureza não ensina a todos os animais, que a um macho cabe uma só fêmea; pois, em
muitas espécies animais um macho tem várias fêmeas. Logo, não é contra a lei da natureza ter várias
mulheres.

5. Demais. ─ Segundo o Filósofo, na geração dos filhos o varão está para a mulher como o agente para o
paciente o artífice para a matéria. Ora, não é contra a ordem da natureza um agente obrar sobre vários
pacientes ou um artífice trabalhar sobre diversas matérias. Logo, também não é contra a lei da natureza
um homem ter várias mulheres.
Mas, em contrário, é sobretudo de direito natural o que foi infundido no homem, na instituição da
natureza humana. Ora, que um homem deve ter uma só mulher, foi-lhe infundido na própria instituição
da natureza humana, segundo aquilo da Escritura: serão dois numa só carne. Logo, é isso da lei da
natureza.

2. Demais. ─ É contra a lei da natureza homem obrigar-se ao impossível e a dar a um que já foi dado a
outro. Ora, o homem que casou com uma mulher deu poder sobre o seu corpo, obrigando-se a cumprir
o dever conjugal quando ela o pedir. Logo, é contra a lei da natureza dar a outra também esse mesmo
poder, não lhe sendo assim possível cumprir o dever conjugal para com ambas, se o pedissem.

3. Demais. ─ A lei da natureza ordena que não façamos aos outros o que não queremos que nos façam.
Ora, nenhum marido quereria que sua mulher tivesse outro esposo. Logo, procederia contra a lei da
natureza tomando uma segunda mulher.

4. Demais. ─ Tudo o que contraria o nosso desejo natural é contra a lei da natureza. Ora, como vemos
em toda parte é natural o marido ter ciúmes da mulher e a esta, de aquele. Logo, sendo o ciúme um
amor, que não admite participação no ser amado, parece contra a lei da natureza terem várias mulheres
um só marido.

SOLUÇÃO. ─ Todos os seres naturais dependem de certos princípios, que não somente lhes tornam
possíveis as atividades, mas também as conduzem aos seus devidos fins. Quer essas atividades resultem
da natureza genérica, quer da natureza específica do ser. Assim, é natural ao magnete elevar-se, pela
sua natureza genérica; e atrair, pela natureza específica. Ora, assim como dos seres de natureza
necessariamente ativa, os seus princípios de atividade são as suas formas, donde resulta a adaptação ao
fim, dessas atividades, assim dos seres dotados de conhecimento os princípios de agirem são o
conhecimento e o apetite. Por onde, há de a potência cognitiva ter uma concepção natural, e a apetitiva
uma natural inclinação, mediante as quais tanto a operação genérica como a específica se adaptam ao
fim devido. Mas como o homem, dentre os outros animais, tem a noção do fim e conhece a
proporcionalidade entre, a sua atividade e esse fim, por isso a concepção que a natureza lhe infundiu e
que o dirige nas suas operações se chama convenientemente lei natural ou direito natural. E isso mesmo
se denomina, nos outros animais, estimativa natural; pois os brutos são antes, por força da natureza,
impelidos a realizar as suas operações próprias, do que agentes dirigidos por arbítrio próprio.
Por onde, a lei natural outra causa não é senão um conceito naturalmente infuso no homem, pelo qual é
levado a praticar convenientemente os atos, que lhe são próprios. Quer esses atos os pratique ele em
virtude da sua natureza genérica; como o de gerar, comer e semelhantes; quer em virtude da sua
natureza específica, como raciocinar e outros. E assim, tudo o que lhe torna as ações inadaptadas ao fim
que, num caso determinado, a natureza tem em vista, diz-se que vai contra a lei da natureza.
Ora, um ato pode não se adaptar ao fim principal ou ao secundário; e de um e outro modo, de duas
maneiras é isso possível. Primeiro, por um obstáculo absolutamente impediente da conservação do fim:
assim, comer demasiado ou muito pouco impede a saúde do corpo, fim principal da alimentação; a boa
disposição para comércio da vida, fim secundário da alimentação. Segundo, por um obstáculo que torna
difícil ou menos conveniente a consecução do fim principal ou do secundário; assim, comer
desordenadamente, em tempo impróprio. Portanto, uma ação contrária ao fim, a ponto de excluir
absolutamente o fim principal, é diretamente proibida pelos preceitos primários da lei natural, que
desempenham, na ordem da ação o mesmo papel que as concepções gerais do espírito, na ordem
especulativa. Se porém de qualquer modo for contrária do fim secundário, ou se também o for ao fim
principal, tornando difícil ou menos conveniente a consecução dele, será proibida, não pelos preceitos
primários da lei natural, mas pelos secundários, derivados dos primários como, na ordem especulativa,
as conclusões tiram a sua certeza dos princípios evidentes.
Ora, a fim principal do matrimônio é a geração e a criação dos filhos; e a esse fim tende o homem pela
sua natureza genérica, sendo por isso comum também aos outros animais, como diz Aristóteles. Daí o
dizer-se que um bem do matrimônio são os filhos. Seu fim secundário porém, e próprio do homem, é a
comunicação das atividades necessárias à vida, no dizer do Filósofo. Por isso, devem-se a fé mútua ─
ainda um dos bens do matrimônio. Tem além disso um fim ulterior, quando contratado entre cristãos,
que é simbolizar a união entre Cristo e a Igreja. E então, um terceiro bem do matrimônio é ser
sacramento. Assim, ao primeiro fim tende o matrimônio, enquanto é o homem um animal; ao segundo,
enquanto homem; ao terceiro, como cristão.
Por onde, a pluralidade de mulheres, nem exclui totalmente, nem de certo modo impede o fim primário
do matrimônio; pois, um homem basta a fecundar várias mulheres e a criar os filhos delas nascidos. Mas
o fim secundário, embora não no exclua totalmente contudo grandemente o impede, porque não pode
haver paz numa família em que um homem está unido a várias mulheres. Pois, além de não poder um só
homem satisfazer aos desejos de várias mulheres, a participação de vários no desempenho de uma
mesma função causa as disputas; e como os oleiros vivem em rixas contínuas, assim também as
mulheres de um mesmo homem. ─ Quanto ao terceiro fim, totalmente o exclui, porque assim como
Cristo é um só, assim também uma só é a Igreja.
Por onde é claro, pelo que acabamos de dizer, que a pluralidade de mulheres e de certo modo contra a
lei da natureza, e de certo modo não o é.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O costume não contraria à lei da natureza nos seus
preceitos primários que são umas como idéias gerais do espírito, na ordem especulativa. Mas as que são
como umas conclusões desses princípios primários, o costume lhes dá maior vigor, como diz Túlio, mas
também pode-lhos diminuir. E tal é o preceito da lei da natureza, sobre a unicidade da esposa.

RESPOSTA À SEGUNDA. ─ Como diz Túlio, o temor das leis e a religião consagraram as regras fundadas
em a natureza e aprovadas pelo costume. Por onde é claro, que aquilo que a lei natural dita, como
conclusões dos princípios primários da lei natural, não tem força obrigatória a modo de preceito
absoluto, senão depois de sancionado pela lei divina e pela humana. E tal é o dito de Agostinho, que não
procediam contra os preceitos da lei, por que por nenhuma lei era proibido.

RESPOSTA À TERCEIRA. ─ Resulta do que foi dito.

RESPOSTA À QUARTA. ─ A expressão direito natural e susceptível de vários sentidos. ─ Num primeiro
sentido, o direito natural tira a denominação do seu princípio, pois foi infundido pela natureza. E assim o
define Túlio: O direito natural não é gerado pela opinião mas infundido por uma certa virtude inata. ─
Na ordem dos seres naturais, porém certos movimentos se chamam naturais, não por provirem de um
princípio intrínseco, mas de um princípio movente superior. Assim, os movimentos dos elementos
causados pela impressão dos corpos celestes se chamam naturais, como o explica o Comentador. Por
isso, as prescrições do direito divino se consideram como de direito natural, por procederem da
impressão e infusão de um princípio superior, Deus, Talo sentido de lsidoro quando afirma: Direito
natural é o contido na lei e no Evangelho, ─ Num terceiro sentido, o direito natural é assim chamado,
não só em virtude do seu princípio, mas da sua matéria, que são os seres naturais. Ora, a natureza se
divide, por contrariedade, da razão, que faz o homem ser homem. Por isso, no sentido estritíssimo do
direito natural, os preceitos só aos homens aplicáveis, sendo ditames da razão natural não se
consideram como pertencentes a esse direito; senão só aqueles que a razão natural dita e se aplicam
em comum aos homens e aos outros animais. E nesse sentido se definiu: O direito natural é o que a
natureza ensinou a todos os animais. ─ Ora, a pluralidade de mulheres, embora não contrarie o direito
natural, no seu terceiro sentido, vai-lhe porém contra o segundo, por ser proibido por direito divino. E
também contra o direito natural, na primeira recepção, como do sobredito se colhe; pois, a natureza a
dita a cada animal, ao modo que lhe convém à espécie. Por isso também entre certos animais, nos quais
a criação dos filhos exige a solicitude, tanto do macho como da fêmea há a união de um macho com
uma só fêmea, como se dá com os pombos e outros.
Mas, como as objeções em contrário pretendem mostrar que a pluralidade de mulheres é contrária dos
princípios primeiros da lei da natureza, por isso devemos lhes a elas responder.

RESPOSTA À QUINTA. ─ A natureza humana foi instituída sem nenhum defeito. Por isso lhe foi infuso
não só aquilo sem o que o fim principal do matrimônio não podia ser conseguido, mas também aquilo
sem o que não podia sê-lo, senão com dificuldade, o fim secundário dele. E para tal bastava ao homem,
quando foi criado, ter uma só mulher.

RESPOSTA À SEXTA. ─ O marido não confere, pelo matrimônio, poder absoluto à mulher sobre o seu
corpo, mas só quanto ao ato matrimonial. Ora, por ter casado não está o marido obrigado do
cumprimento do dever conjugal em qualquer tempo que a mulher lh'o peça se se considera o fim
principal para que foi o matrimônio instituído, que é a geração de filhos; pois para um basta ser a
mulher fecunda. Atendendo-se por ela ao fim secundário do matrimônio que é ser remédio à
concupiscência, então fica o marido obrigado ao ato conjugal, sempre que a mulher lh'o pedir. Por onde
é claro, que quem casou com várias mulheres não se obriga ao impossível, considerado o fim primário
do casamento. Portanto, a pluralidade, de mulheres não colide com os preceitos primeiros da lei
natural.

RESPOSTA À SÉTIMA. ─ No preceito da lei natural ─ não faças aos outros o que não queres que te façam
─ deve subentender-se ─ conservada a mesma proporção. Pois não é por um prelado não querer admitir
a oposição do súbito, que não deve também se lhe opor a ele. Por onde, não será por força do princípio
citado, que assim como o marido não admite que sua mulher tenha outro, assim também não poderá
ele tomar mais uma mulher. Pois, um só homem pode ter várias mulheres, sem colidir com os preceitos
primários da lei da natureza, como dissemos; contra esses princípios primeiros, porém, é uma mesma
mulher ter vários maridos porque então, de certo modo, fica totalmente escluído e, de certo outro,
impedido o bem da prole, fim principal do matrimônio. E por bem da prole se entende não só a geração
mas também a criação dos filhos. Ora, quanto à geração, embora não fique totalmente excluída, porque
pode a mulher, depois de uma primeira concepção, conceber de novo, como ensina Aristóteles, contudo
fica esse bem grandemente tolhido porque será difícil não resultar algum mal a ambas essas
fecundações ou a uma delas. Quanto à criação porém, fica totalmente impedida, pois de ter uma só
mulher vários maridos procede a incerteza do prole relativamente ao pai, cujos cuidados são
necessários a essa criação. Por isso, nenhuma lei ou costume permitiu uma só mulher ter vários
maridos, como permitiu o contrário.

RESPOSTA À OITAVA. ─ A inclinação natural da potência apetitiva depende da concepção natural da
faculdade cognitiva. E não sendo contra nenhum conceito natural ter um homem várias mulheres, como
o é ter uma mulher vários maridos, por isso à mulher não repugna tanto outras uniões do marido, como
ao marido outras da mulher. Por isso, tanto entre os homens como entre os animais mais ciúmes tem o
macho da fêmea, que ao inverso.

## Art. 2 — Se outrora podia ser lícito ter várias mulheres.
O segundo discute-se assim. ─ Parece que nunca pode ser lícito ter um marido várias mulheres.

1. Pois, segundo o Filósofo, o direito natural tem sempre e em toda parte o mesmo vigor. Ora, o direito
natural proíbe a pluralidade de mulheres, como do sobredito se colhe. Logo, como agora não é lícito,
nunca poderia tê-lo sido.

2. Demais. ─ Se outrora foi lícito, não o podia ter sido, senão em si mesmo a coisa considerada ou por
alguma dispensa. Se do primeiro modo, então deveria sê-lo ainda agora. Se do segundo, não era
possível; pois conforme Agostinho, Deus, sendo o Criador da natureza, nada faz contra a ordem que
para ela estabeleceu. Ora, como Deus instituiu a nossa natureza de modo a ter um marido uma só
mulher, parece que nunca poderia ter dispensado dessa determinação.

3. Demais. ─ O lícito por dispensa só o é aqueles é quem foi concedida. Ora, nenhuma notícia há de
dispensa geral de uma lei, concedida para todos. Logo, o fato de todos os que, na vigência do
Testamento Velho, queriam várias mulher terem-nas recebido, sem serem repreendidos pela lei nem
pelos profetas, não autoriza a concluir que tal fosse lícito por dispensa.

4. Demais. ─ Onde há a mesma razão de dispensar deve haver a mesma dispensa. Ora, a razão da
dispensa não podia ser outra senão a multiplicação dos filhos, para manter o culto de Deus; o que ainda
agora é necessário. Logo, essa dispensa ainda devia durar, sobretudo que não há notícia de haver sido
revogada.

5. Demais. ─ Uma dispensa não deve ser por um bem maior a um menor. Ora, a fé e o sacramento, que
não podem existir no matrimônio de um homem com várias mulheres, são maiores bens que a
multiplicação dos filhos. Logo, com o fim posto nessa multiplicação, não devia a dispensa ter sido
concedida.
Mas, em contrário. ─ O Apóstolo diz, que a lei foi feita por causa dos prevaricados, a fim de os coibir.
Ora, a Lei Velha faz menção da pluralidade das mulheres, sem nenhuma proibição, como se lê: se um
homem tiver duas mulheres, etc. Logo, tendo duas mulheres não eram prevaricadores; e portanto tal
lhes era lícito.

2. Demais. ─ Isso mesmo se conclui do exemplo dos santos Patriarcas, como Jacó, lsaac e outros, de
Deus, sem embaraço de terem várias mulheres. Logo, outrora era lícito.

SOLUÇÃO. ─ Como do sobredito se colhe, diz-se ser contra a lei da natureza a pluralidade das mulheres,
não quanto aos preceitos primários dela, mas quanto aos segundos, derivados como conclusões, desses
primeiros princípios. Ora, os atos humanos necessariamente variam conforme as diversas condições de
pessoas, tempo e outras circunstâncias. Por isso, as referidas conclusões dos preceitos primeiros da lei
natural, deles não procedem de modo a serem tempo eficazes, senão só no mais das vezes; pois tal é a
natureza em comum dos atos morais, como ensina o Filósofo. Por onde, quando a eficácia lhes falha,
podem ser licitamente preteridos. Como tais casos, por variados, não é possível determiná-los, por isso
aqueles de cuja autoridade deriva a sua eficácia; é reservado da licença de ser preterida a lei nos casos
que essa eficácia não deve atingir. E essa licença se chama dispensa. ─ Ora, a lei sobre a unidade de
esposas não é de instituição humana, mas divina. Nem foi nunca transmitida por palavras nem pela
escrita, mas impressa nos corações, como tudo o mais de qualquer modo pertencente à lei natural. Por
isso, em tal matéria só Deus podia dispensar, por inspiração interna. E essa a tiveram principalmente os
santos Patriarcas, e do exemplo deles derivou para outros, em tempo em que era necessário omitir-se o
referido preceito da natureza, a fim de aumentar a população e se manter o culto de Deus. Pois, um fim
mais principal deve sempre ter preferência sobre o secundário. Ora, sendo o bem da prole o fim
principal do matrimônio, quando era necessário a multiplicação dos filhos foi mister arredar o que
poderia ser impedimento à consecução dos fins secundários. Mas para removê-lo foi ordenado o
preceito proibitivo da pluralidade das esposas como do sobredito se colhe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O direito natural, em si mesmo considerado, tem sempre
e em toda parte a mesma vigência mas por acidente por via de algum impedimento, pode às vezes e em
certos lugares variar, do que no mesmo lugar o Filósofo dá exemplos, relativos a outros seres naturais.
Assim, sempre e em toda parte a mão direita é por natureza melhor que a esquerda; mas
acidentalmente pode ser uma pessoa ambidestra, porque a nossa natureza é variável. O mesmo
também se dá com o justo natural, como no mesmo lugar o diz o Filósofo.

RESPOSTA À SEGUNDA. ─ Uma decretal determina: nunca foi lícito ter várias esposas sem dispensa
fundada em inspiração divina. Nem essa dispensa é dada contrariando a ordem que Deus infundiu em a
natureza. Mas apesar dela; porque essa ordem não foi instituída para valer sempre, mas no mais das
vezes, como dissemos. Assim como também não vão contra a natureza os fatos miraculosos, na ordem
natural fora do curso do que frequentemente costuma dar-se.

RESPOSTA À TERCEIRA. ─ Tal é a lei e tal a dispensa de que é susceptível. Ora, a lei natural não foi dada
por escrito, mas impressa nos corações. Logo, a dispensa dos preceitos pertinentes à lei natural não
havia necessidade de ser dada por escrito mas por inspiração interna.

RESPOSTA À QUARTA. ─ Com o advento de Cristo veio o tempo da plenitude da sua graça pela qual o
culto de Deus difundiu-se entre todas as gentes pela propagação espiritual. Por onde, não há a mesma
razão de dispensa que havia antes do advento de Cristo, quando o culto de Deus se multiplicava pela
propagação carnal e por ela se conservava.

RESPOSTA À QUINTA. ─ A prole, enquanto bem do matrimônio, inclui a fé que se deve conservar para
com Deus. Pois, a prole é considerada bem do matrimônio enquanto deve ser criada para o culto de
Deus. Quanto a fé que devemos manter para com Deus, é superior à que os esposos mutuamente se
devem e que é considerada bem do casamento; é superior também ao simbolismo, concernente ao
sacramento, porque esse simbolismo se ordena ao conhecimento da fé. Não há, pois, nenhum
inconveniente, se por causa do bem da prole algo se diminui aos outros dois bens. ─ Mas nem por isso
ficam de todo tolhidos. Porque a fé subsiste mesmo para com várias esposas; e de certo modo também
o sacramento. Pois, embora não signifique a união de Cristo e da Igreja, como se a esposa fosse única, é
contudo significado pela pluralidade delas a distinção de graus na Igreja; e isso não somente na
militante, mas também na triunfante. Por onde, o casamento com várias mulheres de algum modo
significava a união de Cristo com a Igreja, não só a militante, como certos dizem, mas também a
triunfante, onde ha diversas mansões.

## Art. 3 — Se ter uma concubina é contra a lei da natureza.
O terceiro discute-se assim. ─ Parece que ter uma concubina não é contra a lei da natureza.

1. Pois, as leis cerimoniais não fazem parte da lei natural. Ora, a fornicação era proibida, entre os outros
preceitos cerimoniais da lei impostos temporariamente aos gentios crentes. Logo, a fornicação simples,
que é a relação com a concubina, não é contra a lei da natureza.

2. Demais. ─ O direito positivo deriva do natural, como diz Túlio. Ora, pelo direito positivo, a fornicação
simples não era proibida; ao contrário até as mulheres eram condenadas, pelas leis antigas, a serem
entregues aos lupanares, como pena. Logo, ter uma concubina não é contra a lei da natureza.

3. Demais. ─ A lei natural não impede que o que é pura e simplesmente dado não no possa ser
temporariamente e com restrições. Ora, uma mulher solteira pode dar a um homem solteiro perpétuo
poder sobre o seu corpo, para que dele use licitamente, quando quiser. Logo, não é contra a lei da
natureza se lhe der um poder apenas momentâneo sobre o seu corpo.

4. Demais. ─ Quem usa do seu como quer a ninguém faz injúria. Ora, a escrava é coisa do Senhor. Logo,
se este dela usar como quiser, a ninguém faz injúria. Portanto, ter uma concubina não é contra a lei da
natureza.

5. Demais. ─ Todos podemos dar a outrem o nosso. Ora, a esposa tem poder sobre o corpo do marido,
como diz o Apóstolo. Logo, permitindo ela, o marido pode ter conjunção com outra sem pecado.
Mas, em contrário. ─ Segundo todas as leis, é censurável ter filhos nascidos de concubina. Ora, tal não
seria se o concúbito, donde nasceram, não fosse naturalmente condenável. Logo, ter uma concubina é
contra a lei natural.

2. Demais. ─ O matrimônio é natural. Ora, tal não seria se, sem prejuízo da lei da natureza, o homem
pudesse ter união com uma mulher, fora do matrimônio. Logo, contra a lei natural é ter uma concubina.

SOLUÇÃO. ─ Considerada é contra a lei da natureza a ação, contrária ao fim intencionado pela natureza;
quer por se lhe não ordenar por obra do agente, ou por se lhe não ordenar por natureza. Ora, o fim
intencionado pela natureza, na conjunção matrimonial, é a geração de filhos e a criação deles; e para
esse bem ser alcançado, tornou ela deleitável a cópula carnal, como diz Constantino. Ora, toda relação
carnal buscada só pelo prazer que encerra, sem a referir ao fim visado pela natureza, colide com esta. E
o mesmo se dá com todo concúbito que não possa ordenar-se convenientemente a esse fim. Ora, uma
coisa, no mais das vezes, tira a sua denominação do seu fim, como do que lhe é mais importante. Por
onde, assim como a conjunção matrimonial tira o seu nome do bem da prole, fim principal do
matrimônio, assim o nome de concubina exprime aquela conjunção em que só se busca o prazer a
carnal. Mesmo porém que de tal conjunção nasçam filhos, não lhes consulta contudo o bem que não
consiste só serem gerados, recebendo assim dos pais a existência, mas ainda em serem criados e
instruídos, recebendo deles a nutrição e a aprendizagem; e nisso consiste o tríplice dever dos pais para
com os, filhos, segundo o Filósofo. Por onde, como a criação e a instrução dos filhos pelos pais se
prolonga diuturnamente, a lei natural exige a diuturna coabitação entre pai e mãe, a fim de em comum
criarem os filhos. Por isso as aves que nutrem os filhos em comum não se separam os casais antes de
completamente criados os filhos, criação começada pela conjunção. Ora, é esta obrigação de
permanecer a mulher unida ao marido que se chama casamento. Por onde, é claro que ter um homem
conjunção com uma mulher a que não está unido em matrimônio, e se chama por isso concubina, é
contra a lei da natureza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Entre os gentios muitos preceitos da lei natural estavam
obliterados; por isso não julgavam mal manter um homem uma concubina. Mas recorriam
habitualmente à fornicação, como a uma coisa lícita, e à outras práticas contrárias às cerimônias dos
judeus, embora não o fossem contra a lei natural. Por isso os Apóstolos introduziram a proibição da
fornicação nas cerimônias da lei, pela diferença existente nessa matéria entre judeus e gentios.

RESPOSTA À SEGUNDA. ─ A lei referida nasceu, não de procedência da lei natural, mas da predita
obliteração em que caíram os gentios, não dando a Deus a glória que lhe é devida, como diz o Apóstolo.
Por isso tal lei foi extirpada quando veio a prevalecer a religião cristã.

RESPOSTA À TERCEIRA. ─ Em certos casos pode não resultar nenhum inconveniente de cedermos a
outrem o que é nosso de pleno direito, tanto para sempre como temporariamente; e assim de nenhum
modo procedemos contra a lei natural. Ora, nada disso se dá no caso vertente. Logo, o símile não colhe.

RESPOSTA À QUARTA. ─ A injúria se opõe à justiça. Ora, a lei natural proíbe não só a injustiça mas o
oposto às todas as virtudes. Assim é contra a lei da natureza comermos imoderadamente, embora assim
procedendo a ninguém façamos injúria. ─ Além disso, uma escrava, é propriedade do Senhor, mas para
lhe prestar serviços e não para usar dela para os seus prazeres carnais. ─ Demais, importa saber o modo
pelo qual usamos do que é nosso. ─ Enfim, quem vive corri uma concubina colide com o bem da
procriação dos filhos, a cujo bem essa união suficientemente não se ordena, como se disse.

RESPOSTA À QUINTA. ─ A mulher tem poder sobre o corpo do marido, não absolutamente e em relação
a tudo, mas só no concernente às exigências do matrimônio. Portanto, não pode, contrariando o bem ao
casamento, ceder a outrem o corpo do marido.

## Art. 4 — Se ter relações com a concubina é pecado mortal.
O quarto discute-se assim. ─ Parece que ter relações com a concubina não é pecado mortal.

1. Pois, mais grave pecado é a mentira que a fornicação simples. Isso se conclui do fato de Judas ter
recusado mentir, que não lhe repugnou conter fornicação com Tamar, dizendo: Ao menos não poderá
arguir-nos de mentira. Ora, a mentira nem sempre é pecado mortal. Logo, nem a fornicação simples.

2. Demais. ─ O pecado mortal deve ser punido de morte. Ora, a Lei Velha só em certos casos punia de
morte o concúbito com a concubina. Logo, não é pecado mortal.

3. Demais. ─ Segundo Gregório, os pecados carnais são de menor culpa que os espirituais. Ora, nem
sempre a soberba ou a avareza, que são pecados espirituais, são pecados mortais. Logo, nem toda
fornicação, que é um pecado carnal, é pecado mortal.

4. Demais. Onde há maior incitamento há menor pecado, pois mais peca quem é atacado por menor
tentação. Ora, a concupiscência é uma violenta instigação ao ato sexual. Logo, assim como o ato da gula
nem sempre é pecado mortal, nem pecado mortal será a fornicação simples.
Mas, em contrário. ─ Só pelo pecado mortal ficamos excluídos do reino de Deus. Ora, os fornicários são
excluídos dele, como diz o Apóstolo. Logo, a fornicação simples é pecado mortal.

2. Demais. ─ Só aos pecados mortais se chamam crimes. Ora, toda fornicação é crime, conforme àquilo
da Escritura: Preserva-te de toda impureza e fora de tua mulher nunca consintas em conhecer o crime.
Logo, etc.

SOLUÇÃO. ─ Como ficou dito aqueles atos são genericamente pecados mortais que rompem o pacto de
aliança entre o homem e Deus e entre um homem e outro. Pois, colidem com os dois preceitos da
caridade, que é a vida da alma. Portanto, como o concúbito fornicário destrói a ordenação natural do
pai para os filhos, que é o fim intencionado pela natureza, nenhuma duvida há que seja pecado a
fornicação simples, por natureza, mesmo se não fosse proibida por lei escrita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ É frequente não evitarmos um pecado mortal e, contudo,
evitarmos um pecado venial, para o qual não nos atrai a mesma grande tentação. Assim foi que Judas
evitou a mentira sem que evitasse a fornicação. Embora essa mentira fosse perniciosa, implicando uma
injustiça, se não cumprisse o prometido.

RESPOSTA À SEGUNDA. ─ Não se chama o pecado mortal por ser punido de morte temporal, mas pelo
ser de morte eterna. Por isso também o furto, que é um pecado mortal, e muitos outros, às vezes não
são punidos pelas leis, de morte temporal. Ora, o mesmo se dá com a fornicação.

RESPOSTA À TERCEIRA. ─ Assim como não qualquer movimento de soberba é pecado mortal, assim
também não o é todo movimento de luxúria: Porque os primeiros movimentos de luxúria, como outros
semelhantes, são pecado veniais, e mesmo às vezes o concúbito matrimonial. Entretanto, certos atos de
luxúria são pecados mortais, ao passo que são veniais certos movimentos de soberba. Pois, das palavras
de Gregório não se deve concluir uma comparação dos vícios genericamente considerados, senão só
singularmente.

RESPOSTA À QUARTA. ─ Aquela circunstância é mais agravante que mais atinente é à espécie de
pecado. Por onde, embora a fornicação pela intensidade da excitação que a ela nos impele, perca da sua
gravidade, recebe contudo maior gravidade da sua matéria, que o ato desordenado da gula; pois, da
fornicação, a matéria é desenvolver os laços da sociedade humana, como se disse. Por isso a objeção
não colhe.

## Art. 5 — Se outrora era licito ter concubina.
O quinto discute- se assim. ─ Parece que outrora era lícito ter concubina.

1. Pois, assim como ter uma só esposa, assim também não ter concubina é uma exigência da lei natural.
Ora, outrora era permitido ter várias mulheres. Logo, também ter concubina.

2. Demais. ─ Não pode uma ser ao mesmo tempo escrava e mulher; donde o determinar a Lei; que o
casamento de uma escrava por si mesmo a libertava. Ora, de certos homens amicíssimos de Deus, como
Abraão e Jacó, refere a Escritura que tinham como concubinas, escravas. Logo, essas não lhes eram
esposas. Portanto, antigamente era lícito ter concubinas.

3. Demais. ─ A mulher tomada como esposa não pode ser deitada fora, e o seu filho deve participar da
herança. Ora, Abraão deitou fora Agar, e o filho dela não foi herdeiro. Logo, não era esposa de Abraão.
Mas, em contrário. ─ Atos contrários aos preceitos do Decálogo nunca foram lícitos. Ora, ter concubina é
contra o preceito do Decálogo, que dispõe: não cometerás adultério. Logo, nunca foi lícito.

2. Demais. ─ Ambrósio diz: ao marido não é lícito o que não o é à mulher. Ora, nunca foi lícito a mulher
separando-se do seu marido legítimo, ter relações com outro homem. Logo, também nunca e foi ao
marido ter uma concubina.

SOLUÇÃO. ─ Ensina Rabi Moisés, que antes do tempo da lei, não era pecado a fornicação; e o conclui do
fato de ter Judas tido congresso com Tamar. ─ Mas esta razão não é cogente. Pois, não é preciso que os
filhos de Jacó sejam escusados de pecado mortal, eles que foram perante o pai acusados de um crime
péssimo e consentiram na morte ou venda de José. Devemos, pois, pensar que, sendo contra a lei da
natureza ter uma concubina, não ligada por matrimônio em nenhum tempo foi isso lícito, em si mesmo
considerado, nem por dispensa. Pois, como do sobredito se colhe, o concúbito com mulher a que o
homem não está unido pelo matrimônio não é um ato conveniente ao bem da prole, fim principal do
matrimônio. Colide portanto com os princípios primários da lei natural, que não são susceptíveis de
dispensa. Por onde, sempre que o Antigo Testamento refere, de certos que tinham concubinas, ficando
contudo escusados de pecado mortal devemos entender que estavam unidos em matrimônio com
mulheres chamadas contudo concubinas, porque eram em parte esposas e, em parte, concubinas. Pois,
por isso mesmo que o matrimônio se ordena ao bem da prole, que é o seu fim principal, a mulher fica
ligada ao marido por uma união perpétua, ou ao menos diuturna, como do sobredito se colhe; e
nenhuma dispensa sofre esse vínculo. Mas pelo fim secundário do matrimônio, que é a manutenção da
família e a assistência mútua, a mulher está unida do marido como companheira. O que não se dava
com essas chamadas concubinas. Pois, esse fim secundário do matrimônio era susceptível de dispensa.
Por isso, por participarem de certo modo da natureza da concubina, concubinas se chamavam.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Ter várias mulheres não colide com os preceitos
primários da lei da natureza, como colide ter concubina. Por onde, a razão não colhe.

RESPOSTA À SEGUNDA. ─ Os antigos Patriarcas, tendo dispensa para casar com várias mulheres, tinham
vida com as escravas, com afeto marital. Pois, eram esposas, quanto ao fim primário do matrimônio;
mas não quanto à outra união atinente ao fim secundário, a que se opõe a condição servil, pois não
pode uma ser ao mesmo tempo companheira e escrava.

RESPOSTA À TERCEIRA. ─ Assim como a lei de Moisés, por dispensa, permitia mandar libelo de repúdio,
para evitar o uxoricídio, como diremos, assim, em virtude dessa mesma dispensa, foi lícito a Abraão
deitar fora a Agar, para significar o mistério, a que o Apóstolo alude. Onde também diz que constitui um
mistério o não lhe ser herdeiro dele o filho dela. Como também constitui mistério o fato de não ter sido
herdeiro de Esaú o filho que teve com uma livre. E ainda, só como mistério se explica que fossem
herdeiros de Jacó os filhos que teve de escravas e de livres, como ensina, Agostinho; porque a Cristo lhe
nascem, pelo batismo, filhos, tanto pelos bons, que as livres significavam, como pelos maus ministros,
simbolizados pelas escravas.