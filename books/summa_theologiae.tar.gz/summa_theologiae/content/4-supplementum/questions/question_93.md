# Questão 93: Da beatitude dos santos e das suas mansões.
Em seguida devemos tratar da beatitude dos santos e das suas mansões.
E nesta questão discutem-se três artigos:

## Art. 1 — Se a beatitude dos santos será maior depois do juízo que antes.
O primeiro discute-se assim. ─ Parece que a beatitude dos santos não será maior depois do juízo que
antes.

1. ─ Pois, quanto mais um ser é semelhante a Deus tanto mais perfeitamente participará da felicidade.
Ora, a alma separada do corpo, é mais semelhante a Deus que quando unida com o corpo. Logo, maior
será a sua beatitude antes de reassumir o corpo, que depois.

2. Demais. ─ A virtude unificada é mais potente que uma multiplicada. Ora, a alma separada do corpo
tem maior unidade que quando unida a ele. Logo, a sua virtude é capaz de uma operação mais intensa.
E portanto, participa mais perfeitamente da beatitude, que consiste numa atividade.

3. Demais. ─ A beatitude consiste num ato do intelecto especulativo. Ora, o intelecto não necessita, para
exercer o seu ato, da cooperação de nenhum órgão corpóreo; e assim, o corpo reassumido em nada
contribuirá para a alma conhecer mais perfeitamente. Logo, a beatitude da alma não será
perfeitamente. Logo, a beatitude da alma não será maior depois da ressurreição que antes.

4. Demais. ─ Nada pode ser maior que o infinito; e assim o infinito acrescentado de uma quantidade
finita nem por isso se torna mais infinito. Ora, a alma bem- aventurada, antes de reassumir o corpo, a
beatitude lhe consiste no gozo de Deus, bem infinito; mas depois da ressurreição do corpo não terá
outra felicidade senão talvez a proveniente da glória do corpo, que é um bem finito. Logo, a felicidade
dos ressuscitados, depois de terem reassumido o corpo, não será maior que antes.
Mas, em contrário, aquilo da Escritura ─ Vi debaixo do olhar as almas dos que tinham sido mortos, etc.,
diz a Glosa: Atualmente as almas dos santos desfrutam uma dignidade inferior, i. é, menor, que a que
hão de alcançar. Logo, também a felicidade dos santos será maior depois da ressurreição dos corpos,
que antes.

2. Demais. ─ Assim como para os bons a felicidade lhe é a paga de um prêmio, assim para os maus a sua
miséria. Ora, depois da ressurreição dos corpos, a miséria dos maus será maior que antes, pois hão de
ser punidos, não só na alma, mas também no corpo. Logo, também a felicidade dos santos será maior
depois, que antes da ressurreição dos corpos.

SOLUÇÃO. ─ Que a beatitude dos santos há de aumentar extensivamente, depois da ressurreição, é
manifesto, porque a gozarão eles então não só no corpo mas também na alma. E mesmo a felicidade da
alma será extensivamente maior, porque há de comprazer-se não só com o bem próprio, mas também
com o do corpo. E podemos ainda dizer que a felicidade da alma crescerá também intensivamente. Pois,
o nosso corpo pode ser considerado a dupla luz: enquanto perfectível pela alma, e enquanto contrário,
de certo modo a ela, nas suas operações, quando ainda não de todo por ela aperfeiçoado. Ora, à
primeira luz, a união da alma com o corpo acrescenta-lhe a ela uma perfeição, porque toda parte é
imperfeita e se completa pelo seu todo, por isso o todo está para a parte como a forma para a matéria.
Portanto, também a alma será mais perfeita no seu ser natural, quando integrada no todo, i. é, no
homem composto de alma e de corpo, do que quando existe separada. Mas, à segunda luz, a união do
corpo com a alma é um obstáculo à perfeição desta; por isso diz a Escritura - o corpo que se corrompe
faz pesada a alma. Por onde, removido do corpo tudo quanto nele resiste à ação da alma, será esta,
absolutamente falando, mais perfeita unida a um tal corpo, que dele separada. Pois, quanto mais
perfeito um ser tanto mais perfeita a sua operação; por isso, a operação da alma unida a esse corpo será
mais perfeita que separada dele. Ora, corpo dessa natureza será o glorioso, completamente submisso ao
espírito. Portanto, como a beatitude consiste numa operação, mais perfeita será a felicidade da alma
depois de reassumido o corpo, que antes. Pois, assim como a alma separada do corpo corruptível pode
obrar mais perfeitamente que unida a ele, assim, depois de unida ao corpo glorioso, mais perfeita será a
sua operação que quando dele separada. Pois, todo ser imperfeito busca a sua perfeição. Por isso a alma
separada naturalmente deseja unir-se ao corpo. E por causa dessa tendência, derivada de uma
imperfeição, menos intenso é o ato que a leva para Deus. E tal é o que diz Agostinho: O seu desejo de
unir-se ao corpo impede a alma de tender para o sumo bem, com todas as suas forças.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A alma unida ao corpo glorioso é mais semelhante a
Deus, que dela separada, porque, unida, tem o ser mais perfeito; e quanto mais perfeito é um ser tanto
mais é semelhante a Deus. Assim o coração, cuja vida perfeita consiste no movimento, é mais
semelhante a Deus quando se move que quando em repouso, embora Deus nunca se mova.

RESPOSTA À SEGUNDA. ─ A potência que por natureza deve estar unida à matéria, melhor exerce a sua
atividade unida à matéria, que dela separada; embora, absolutamente falando, separada da matéria,
tenha maior poder de ação.

RESPOSTA À TERCEIRA. ─ Embora para o ato de inteligir a alma não precise da cooperação do corpo,
contudo a perfeição do corpo de certo modo cooperará para a perfeição da operação intelectual,
porque pela sua união com o corpo glorioso a alma será mais perfeita na sua natureza e por
consequência de atividade mais eficaz. E a esta luz, o próprio bem do corpo cooperará, quase
instrumentalmente, para a atividade na qual consiste a beatitude; e assim o Filósofo também diz, que os
bens externos cooperam como instrumentos para a felicidade da vida.

RESPOSTA À QUARTA. ─ Embora o finito acrescentado ao infinito não no torne maior, contudo faz algo
de mais; porque finito e infinito são dois, ao passo que o infinito, em si mesmo considerado, é uma só
realidade. Ora, a extensão da felicidade não se refere ao que nela fosse maior, senão só ao que é mais.
Por onde, aumenta extensivamente a felicidade que a alma goza com a visão de Deus e com a glória do
corpo, relativamente a que antes da ressurreição lhe advinha de Deus. Quanto à glória do corpo, ela
cooperará para a intensidade da beatitude derivada, para a alma, de Deus, cooperando para maior
perfeição do ato que transporta a alma para Deus. Pois, quanto mais perfeita for a operação própria a
um ser, tanto maior será o prazer, como se concluí de um lugar do Filósofo.

## Art. 2 — Se os graus de beatitude devem chamar-se moradas.
O segundo discute-se assim. ─ Parece que os graus de beatitude não devem chamar-se moradas.

1. - Pois, beatitude implica idéia de prêmio. Ora, a idéia de mansão em nada se relaciona com a de
prêmio. Logo, os diversos graus de beatitude não devem chamar-se moradas.

2. Demais. ─ Morada designa um lugar. Ora, o lugar onde os santos serão beatificados não é um lugar
corporal, mas espiritual; pois, é Deus, que é único. Logo, não há mais que uma só morada. Logo, os
diversos graus de beatitude não devem chamar-se moradas.

3. Demais. ─ Assim como na pátria haverá homens de méritos diversos, assim também atualmente os há
no purgatório, e os houve no limbo dos Patriarcas. Ora, no purgatório e no limbo não se distinguem
moradas diversas. Logo, também não devem distinguir-se na pátria.
Mas, em contrário, a Escritura: Na casa de meu Pai há muitas moradas, o que Agostinho expõe como
sendo os vários graus de prêmios.

2. Demais. ─ Em toda cidade há uma ordenada distinção de moradas. Ora, a pátria celeste é comparável
a uma cidade, como diz o Apocalipse. Logo, devemos distinguir nela diversas moradas segundo os
diversos graus de felicidade.

SOLUÇÃO. ─ O movimento local tem prioridade sobre todos os outros movimentos. Por isso, segundo o
Filósofo, as denominações de movimento, de distância e todas as mais a essas semelhantes, derivaram
do movimento local para todos os outros movimentos. Ora, o termo do movimento local é o lugar onde,
tendo-o atingido o móvel fica em repouso e nele se conserva. Por isso, ao descanso, no seu termo, de
qualquer movimento, dizemos que é a colocação ou a morada do móvel. Donde, quando o nome de
movimento derivou para os atos do apetite e da vontade, à consecução mesma do fim do movimento
apetitivo se chama a sua morada a sua colocação no termo final. Daí o se chamarem moradas diversas
os diversos modos de se conseguir o fim último. E assim a unidade da casa responde à da beatitude,
fundada na unidade do objeto; e a pluralidade das moradas responde às diferenças de felicidade de que
gozam os bem-aventurados. Assim como também vemos, na ordem natural, que é um só o lugar
superior para onde tendem todos os corpos leves, mas cada um deles tanto mais se aproxima desse
lugar quanto mais leve é; e assim ocupam moradas diversas, conforme as diferenças de leveza.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Morada implica idéia de fim; e assim, por consequência, a
de prêmio, que é o fim do mérito.

RESPOSTA À SEGUNDA. ─ Embora seja um só o lugar espiritual, diversos porém são os graus de
aproximação desse lugar. Donde a constituição de moradas diversas.

RESPOSTA À TERCEIRA. ─ Os que estarão no limbo ou os que atualmente estão no purgatório, ainda não
alcançaram o seu fim. Por isso, no purgatório nem no limbo se distinguem moradas, mas só no paraíso e
no inferno, fins dos bons e dos maus.

## Art. 3 — Se as diversas moradas se distinguem pelos diversos graus de caridade.
O terceiro discute-se assim. ─ Parece que as diversas moradas não se distinguem pelos diversos graus
de caridade.

1. ─ Pois, diz o Evangelho: Deu a cada um segundo a sua capacidade. Ora, a capacidade de um ser se
mede pela sua virtude natural. Logo, também os dons da graça e da glória se distribuem conforme os
diversos graus de virtude natural.

2. Demais. ─ A Escritura diz: Tu retribuirás a cada um segundo as suas obras. Ora, o que é distribuído é a
medida da felicidade. Logo, os graus de beatitude se distinguem pela diversidade das obras e não pela
da caridade.

3. Demais. - O prêmio é devido ao ato e não ao hábito; por isso não são os mais fortes os coroados, mas
os que melhor lutaram, diz Aristóteles; e o Apóstolo diz, que não será coroado senão quem combateu
conforme à lei. Ora, a beatitude é um prêmio. Logo, os diversos graus de beatitude se distinguirão pelos
diversos graus das obras e não da caridade.
Mas, em contrário, quanto mais unido estiver um a Deus tanto mais feliz será. Ora, tal o modo da
caridade, tal o da união com Deus. Logo, conforme as diferenças da caridade assim as da beatitude.

2. Demais. ─ Como o simples resulta do simples, assim o mais, do mais. Ora, terá a beatitude quem
praticou a caridade. Logo, fruir de uma beatitude maior depende de se ter tido maior caridade.

SOLUÇÃO. ─ O princípio distintivo das moradas ou dos graus de beatitude é duplo: um próximo e outro
remoto. O princípio próximo é as disposições diversas que terão os bem-aventurados, donde lhes
resultará a diversidade da perfeição do ato no qual consiste a felicidade. O princípio remoto é o mérito,
pelo qual alcançaram a beatitude. Ora, de acordo com o primeiro princípio as moradas se distinguem
pela caridade da pátria, que quanto mais um santo a tiver perfeita tanto mais capaz será da claridade
divina, conforme cujo aumento também aumentará a perfeição da visão divina. De acordo com o
segundo princípio, distinguem-se as moradas segundo a caridade desta vida. Ora, os nossos atos não são
meritórios pela substância mesma deles, mas só pelo hábito virtuosa que os informa. Ora, o princípio do
mérito em todas as virtudes é a caridade, que tem como objeto o próprio fim último. Por onde, todas as
diversidades de mérito vêm a fundar-se nas de caridade. E assim pela caridade desta vida se distinguem
as moradas, quanto ao mérito delas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A palavra virtude no lugar aduzido não significa só a
capacidade natural, mas pela capacidade natural acompanhada do esforço para ter a graça. E então,
assim concebida, a virtude será a como disposição material que medirá a graça e a glória que devem ser
recebidas. Ora, a caridade é o complemento termal do mérito para a glória. Por onde, a distinção dos
graus de glória se funda antes nos graus da caridade que nos da referida virtude.

RESPOSTA À SEGUNDA. ─ As nossas obras em nada merecem a retribuição da glória senão quando
informadas pela caridade. E assim, conforme os diversos graus de caridade serão os diversos graus de
glória.

RESPOSTA À TERCEIRA. - Embora o hábito da caridade ou de qualquer virtude não seja um mérito
merecedor de prêmio, é contudo o princípio e a razão total de um ato ser meritório. Por isso conforme
as diversidades deles assim lhes serão atribuídos os prêmios. ─ Embora também no gênero mesmo de
um ato possamos fundar de certo modo o grau do mérito, isso será não em relação ao prêmio essencial,
que é a felicidade consistente na posse de Deus; mas só em relação a algum prêmio acidental, que é a
felicidade pela posse de algum bem criado.