# Questão 54: Do impedimento de consangüinidade.
Em seguida devemos tratar do impedimento de consangüinidade.
Sobre o que quatro artigos se discutem:

## Art. 1 — Se é boa a seguinte definição de consanguinidade: A consangüinidade é o vínculo, que liga os descendentes ele um mesmo tronco por geração carnal.
O primeiro discute-se assim. ─ Parece má a seguinte definição da consangüinidade dada por certos: A
consangüinidade é o vínculo, que liga os descendentes de um mesmo tronco, por geração carnal.

1. Pois, todos os homens descendem de um tronco, que é Adão. Se, pois, a referida definição da
consangüinidade fosse boa, todos os homens seriam consangüíneos uns dos outros. O que é falso.

2. Demais. ─ Vínculo não pode existir senão entre semelhantes, pois, o vínculo une. Ora, os
descendentes de um tronco comum não tem maior semelhança entre si, que com os outros homens;
pois,sendo da mesma espécie, que os demais homens, só numericamente diferem entre si. Logo, a
consangüinidade não é um vínculo.

3. Demais. ─ A propagação carnal, segundo o Filósofo, provém do alimento supérfluo. Ora, esse
supérfluo tem mais relações com as coisas ingeridas, em si mesmas, que com a pessoa que as ingeriu.
Logo, assim como não há nenhum vínculo de consangüinidade entre o que nasce do sêmen e os
alimentos ingeridos, assim também nenhum vínculo prende o filho e os pais que o geraram.

4. Demais. ─ Na Escritura Labão diz a Jacó: Tu és o osso dos meus ossos e a carne da minha carne, por
causa do parentesco existente entre eles. Logo, esse parentesco deve ser chamado antes carnal que
consangüíneo .

5. Demais. ─ A geração carnal é comum aos homens e aos animais. Ora, nenhum vínculo de
consangüinidade liga os animais filhos carnais de uma mesma geração. Logo, o mesmo se dá com os
homens.

SOLUÇÃO. ─ Segundo o Filósofo, toda amizade implica uma certa comunhão de vida. E como a amizade
é uma ligação ou união, por, isso à comunhão da amizade se chama vínculo. Eis porque dessa vida em
comum deriva o nome designativo dos que ela liga reciprocamente. Assim, chamam-se concidadãos os
que vivem em comunhão política; e companheiros de armas os que participam da mesma vida militar.
Do mesmo modo, consangüíneos se chamam os ligados por uma vida comum natural. Por isso a referida
definição introduz o vínculo, como, por assim dizer, o gênero da consangüinidade; como sujeito, os
descendentes de um mesmo tronco, porque entre eles é que esse vínculo existe; e a geração carnal,
como princípio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A virtude ativa não tem a mesma perfeição no
instrumento segundo e no agente principal. E como todo motor movido é um instrumento, daí resulta
que, em qualquer gênero, a virtude do primeiro motor, passando por muitos intermediários, acaba de
esgotar-se e vem dar num ser, só móvel e não motor. A virtude porém do gerador, não só transmite os
caracteres específicos, mas também os individuais, em razão dos quais o filho se assemelha ao pai, não
somente pelos caracteres específicos, mas ainda, pelos acidentais. Contudo, essa virtude individual do
pai não se manifesta no filho tão perfeitamente como no pai; em o neto ainda menos, e assim por
diante, enfraquecendo-se cada vez mais. Razão por que essa virtude às vezes falha e acaba por esvair-
se. E como a consangüinidade consiste em muitas pessoas procederem, por via de geração do mesmo
poder ativo gerador, da vai aos poucos desaparecendo, corno diz Isidoro. Por onde, na definição da
consangüinidade não se deve mencionar o antepassado mais afastado, mas o mais próximo, cuja virtude
ativa ainda perdura nos que dele nasceram.

RESPOSTA À SEGUNDA. ─ Já resulta do que dissemos, que os consangüíneos se assemelham, não
somente pela natureza específica, mas também pelos traços individuais, que receberam de um mesmo
indivíduo e se transmitiram a muitos. Eis a razão pela qual os filhos às vezes se assemelham, não
somente ao pai, mas também ao avô, ou aos parentes remotos, como ensina Aristóteles.

RESPOSTA À TERCEIRA. ─ A semelhança se funda, antes, na forma, que atualiza o ser, que na matéria,
princípio da potencialidade. E isso bem se vê no carvão, mais semelhante ao fogo, do que à arvore
donde foi cortada a lenha. Do mesmo modo, o alimento já convertido na substância do ser vivo, pela
virtude nutritiva, mais se assemelha ao ser que dele se nutria, que à matéria que serviu de nutrição.
Quanto à objeção, ela colheria, na opinião daqueles que diziam que a natureza de um ser provém
totalmente da matéria, e que todas as formas são acidentes. O que é falso.

RESPOSTA À QUARTA. ─ O que proximamente se converte no sêmen é o sangue, como o prova
Aristóteles. E por isso o vínculo fundado na geração carnal, mais propriamente se chama
consangüinidade que parentesco carnal. E quando se usa da expressão, que um consangüíneo é a carne
de outro, entende-se no sentido que o sangue, convertido em sêmen viril ou em mênstruo, é
potencialmente carne e ossos.

RESPOSTA À QUINTA. ─ Certos ensinam que a razão de ser a geração carnal o vínculo de
consangüinidade, que liga só os homens, e não os animais é a seguinte: Todo o realmente pertencente à
natureza, em todos os homens, já existia no primeiro homem ─ o que não se dá com os animais. Mas, se
assim fosse, a consangüinidade, no matrimônio, nunca deixaria de existir. Ora, essa opinião já foi
refutada no segundo livro. E por isso devemos pensar, que isso se dá porque os animais não se unem,
para contrair uma amizade, e depois propagar a vida em vários seres, a partir de um antepassado
próximo, como se dá com o homem.

## Art. 2 — Se a consangüinidade se divide bem por graus e por linhas.
O segundo discute-se assim. ─ Parece que a consangüinidade não se divide bem por graus e por linhas.

1. Pois, chama-se linha de consangüinidade uma série ordenada de pessoas unidas pelo sangue,
descendentes de um mesmo tronco e abrangendo graus diversos. Ora, a consangüinidade outra coisa
não é senão a série de tais pessoas. Logo, a linha da consangüinidade é o mesmo que a
consangüinidade. Mas, nada se distingue de si mesmo. Logo, a consangüinidade não se divide bem por
graus e por linhas.

2. Demais. ─ As divisões de um gênero comum não podem entrar na sua definição. Ora, o descendente
entra na referida definição da consangüinidade. Logo, esta não pode dividir-se em linha dos
ascendentes, dos descendentes e dos colaterais.

3. Demais. ─ A linha se define ─ o intervalo que separa dois pontos. Ora, dois pontos não constituem
senão um grau. Logo, uma linha só tem um grau; e assim, pela mesma razão, parece que não se deve
fazer a divisão da consangüinidade por linhas e graus.

4. Demais. ─ O grau assim se define: A relação entre pessoas afastadas pelo qual conhecemos a distância
a que estão uma da outra. Ora, a consangüinidade sendo uma proximidade, a distância entre as pessoas
é antes o oposto que uma parte dela. Logo; a consangüinidade não pode dividir-se em graus.

5. Demais ─ Se a consangüinidade é dividida em graus e por eles se conhece, necessariamente os
pertencentes ao mesmo grau hão de ser por igual consangüíneos. Ora, isto é falso; pois, o irmão do
bisavô e o bisneto de uma mesma pessoa são parentes no mesmo grau, mas não são igualmente
consangüíneos. Logo, a consangüinidade não se divide bem, em graus.

6. Demais. ─ Em coisas bem ordenadas qualquer grau acrescentado a outro produz um novo grau, assim
como uma unidade acrescentada a outra produz outra espécie de número. Ora, uma pessoa
acrescentada a outra nem sempre dá lugar a outro grau de consangüinidade. Pois, no mesmo grau de
consangüinidade estão o pai, e o avô que se lhe acrescenta. Logo, não se divide bem por graus a
consangüinidade.

7. Demais. ─ Entre dois parentes próximos existe sempre a mesma consangüinidade, porque um
extremo dista igualmente de outro e vice-versa. Ora, um grau de consangüinidade nem sempre é o
mesmo de parte a parte; pois, pode um ser parente de terceiro grau e o outro, no quarto. Logo, a
consangüinidade não pode ser bem conhecida pelos seus graus.

SOLUÇÃO. - A consangüinidade é um parentesco fundado numa comunicação natural, em virtude do ato
da geração pelo qual se propaga a natureza. Ora, segundo Aristóteles, tríplice pode ser essa
comunicação. Uma, fundada na relação entre o princípio e o principiado. E essa é a consangüinidade
existente entre pai e filho. Por isso Aristóteles diz, que os pais amam os filhos como sendo partes deles
próprios. ─ Outra é a fundada na relação entre o principiado e o princípio. E essa é a existente entre filho
e pai. Por isso diz, que os filhos amam os pais como os princípios donde procedem. ─ A terceira se funda
na relação existente entre os que procedem de um mesmo tronco; assim dizemos que os irmãos nascem
dos mesmos pais, conforme no mesmo lugar o ensina o Filósofo. E como o ponto em movimento produz
a linha; e o pai, transmitindo a vida, se põe como em movimento para o filho, por isso das três relações
referidas, derivam três linhas de consangüinidade ─ a dos descendentes, fundada na primeira relação; a
dos ascendentes, na segunda; e a linha colateral, na terceira. Como porém o movimento da propagação
não acaba num só termo, mas vai além, daí resulta que, de um pai, procede outro, de um filho, outro
filho e assim por diante. E dessas diversas progressões resultam os diversos graus de uma mesma linha.
E como os graus de uma coisa constituem partes dela, não pode haver graus de proximidade onde não
há proximidade. Por isso a identidade e a distância excessiva excluem os graus de consangüinidade;
pois, ninguém é parente de si mesmo, como não é semelhante a si mesmo. Eis porque nenhuma pessoa,
em si mesma considerada, pode constituir um grau; mas comparada com outra pessoa pode dar origem
a ele.
Mas o critério para se contarem os graus das diversas linhas varia. Assim, o grau de consangüinidade, na
linha dos ascendentes e dos descendentes, resulta do facto de ser uma pessoa gerada por outra,
daquelas entre as quais se contam os graus. Por isso, segundo o cômputo canônico e legal, a pessoa que
vem em primeiro lugar na série das gerações, quer em linha ascendente quer em descendente, dista de
outra ─ por exemplo, de Pedro, no primeiro grau, como o pai, do filho; a que vem em segundo lugar
dísta no segundo grau, como o avô, do neto, e assim por diante.
Na linha colateral o parentesco se funda, não no fato de uma pessoa descender de outra, mas no de
descenderem de um tronco comum. Por isso deve o grau de consangüinidade, nesta linha, ser contado
relativamente ao princípio comum donde deriva. Assim sendo, o cômputo canônico difere do cômputo
do direito civil. Pois a deste se funda na descendência da raiz comum, por ambos os ramos, ao passo
que o canônico só considera o ramo onde mais numeroso é o número dos graus. Assim, segundo o
cômputo legal, o irmão e a irmã ou dois irmãos são parentes em segundo grau, porque uns e outros
distam do tronco comum num grau. Semelhantemente, os filhos de dois irmãos distam entre si no
quarto grau. Segundo o cômputo canônico porém, dois irmãos são parentes no primeiro grau; porque
cada um deles dista do tronco comum só por um grau, mas o filho de um irmão dista do outro irmão no
segundo grau, porque só em dois graus dista do tronco comum. Por onde, segundo o cômputo canônico,
em tantos graus quantos alguém dista de um grau superior, nesses mesmos dista de qualquer dos
descendentes desse mesmo antepassado, e nunca menos; pois, a causa de uma qualidade a possui a
esta em sumo grau. Por onde, embora outros descendentes do princípio comum tenham laços com um
descendente da mesma origem, mas de outra linha, não podem ser mais próximos deste do que o é o
parente comum. Contudo uma pessoa pode estar mais afastada de outra, do que do parente comum, de
onde ambas descendem, por distar mais deste a segunda pessoa, que a primeira. Pois que devem
contar-se os graus de parentesco pela maior distância.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A objeção procede de um erro. Pois, a consangüinidade
não é uma série de pessoas, mas uma seleção mútua entre várias pessoas, cuja série forma a linha de
consangüinidade.

RESPOSTA À SEGUNDA. ─ A descendência, tomada em sentido geral, se funda em qualquer linha de
parentesco; porque toda geração carnal, donde procede o vínculo do parentesco, é uma espécie de
descendência. Ora, a descendência da pessoa, de que se procura saber o grau de parentesco, forma a
linha dos descendentes.

RESPOSTA À TERCEIRA. ─ A palavra linha é susceptível de dois sentidos. Propriamente significa a
dimensão, que é a primeira espécie de quantidade contínua. E assim, a linha reta só tem dois pontos em
ato, que são os terminais; mas os tem infinitos em potência; e se determinarmos na linha um outro
ponto atual, ela se divide em duas. - Outras vezes porém a palavra linha significa coisas dispostas em
linha. E então a linha e a figura entram na categoria dos números, pois uma unidade acrescentada a
outra forma um número. E assim, qualquer unidade acrescentada constitui um grau de uma
determinada linha. Ora, o mesmo se dá com a linha da consangüinidade. Por isso é que uma linha
contém vários graus.

RESPOSTA À QUARTA. ─ Assim como não pode haver semelhança onde não há nenhuma diversidade,
assim também proximidade não há onde nenhuma distância existe. Por isso não é qualquer distância
que se opõe à consangüinidade, mas uma distância tal, que exclua a proximidade do parentesco.

RESPOSTA À QUINTA. ─ Assim como uma brancura pode aumentar de dois modos ─ por maior
intensidade qualitativa e pela maior extensão da superfície branca, assim também dizemos que um
parentesco é maior ou menor ─ intensivamente, pela natureza mesma dele; e como que
dimensivamente, e então a quantidade do parentesco se mede nelas pessoas unidas pelo mesmo laço
da geração carnal. E neste segundo sentido é que se dividem os graus de parentesco. Donde resulta que
de duas pessoas que estão no mesmo grau de consangüinidade, em relação a uma terceira, uma pode
ser mais parente desta que outra, considerando-se o primeiro sentido da palavra consangüinidade.
Assim, o pai e o irmão de uma pessoa são parentes dela no primeiro grau, porque de nenhum lado há
nenhuma pessoa intermediária; mas, no sentido intensivo mais parente dela é o pai que o irmão,
porque este não lhe é parente senão pela descendência do pai comum. Por onde, quanto mais próxima
estiver uma pessoa do princípio comum donde resulta o parentesco, tanto mais parente é, embora não
o seja no grau mais próximo. E assim sendo, o irmão do bisavô é parente mais chegado de uma pessoa
que o seu bisneto, embora sejam dela parentes no mesmo grau.

RESPOSTA À SEXTA. ─ Embora o pai e o tio sejam parentes no mesmo grau, em relação ao tronco do
parentesco, porque ambos distam de um grau, do avô; contudo, em relação àquele cujo parentesco se
procura, não estão mais no mesmo grau. Pois, o pai está no primeiro grau, ao passo que o tio só pode
ser parente em segundo grau, porque o avô, é parente nesse grau da pessoa em questão.

RESPOSTA À SÉTIMA. ─ Duas pessoas sempre distam uma da outra num mesmo número de graus,
embora possam estar em distâncias desiguais do parente comum, como do sobredito se colhe.

## Art. 3 — Se a consangüinidade impede o matrimônio por direito natural.
O terceiro discute-se assim. ─ Parece que a consangüinidade não impede o matrimônio por direito
natural.

1. Pois, nenhuma mulher pode ser mais chegada a um homem do que Eva o foi de Adão, da qual diz a
Escritura: Eis aqui agora o osso dos meus ossos e a carne da minha carne. Ora, Eva estava unida em
matrimônio com Adão. Logo, nenhuma consangüinidade impede, pela lei da natureza, o matrimônio.

2. Demais. ─ A lei natural é a mesma para todos. Ora, em as nações bárbaras, nenhuma pessoa pode
contrair casamento com outra com quem seja aparentada. Logo, a consangüinidade não é um
impedimento de direito natural.

3. Demais. ─ Como diz o Digesto, no princípio o direito natural é o que a natureza ensinou a todos os
animais. Ora, não é de lei natural que o casamento seja interdito a uma pessoa, por causa das suas
relações de parentesco.

4. Demais. ─ Tudo o que impede o matrimônio lhe contraria a algum bem. Ora, a consangüinidade não
contraria a nenhum bem do matrimônio. Logo, não no impede.

5. Demais. ─ Quanto mais dois seres são próximos e semelhantes, tanto melhor e mais firme é a união
entre eles. Ora, o matrimônio é uma união. Logo, sendo a consangüinidade um parentesco próximo,
longe de impedir, favorece o matrimônio.
Mas, em contrário. ─ O que impede o bem da prole também por lei natural impede o matrimônio. Ora, a
consangüinidade impede o bem da prole; pois, como se conclui das palavras de Gregório, sabemos por
experiência que os filhos nascidos de tais uniões não podem desenvolver-se. Logo, a consangüinidade,
pela lei da natureza, impede o matrimônio.

2. Demais, ─ Os bens da natureza humana, na sua condição primeira, são fundados na lei dessa
natureza. Ora, desde as origens dessa natureza já era proibido aos filhos casarem com; os pais,
conforme o diz a Escritura: Por isso deixará o homem a seu pai e a sua mãe! O que, não se podendo
entender da convivência, há de entender-se da conjunção matrimonial. Logo, pela lei natural, a
consangüinidade impede o matrimônio.

SOLUÇÃO. ─ No matrimônio dizemos ser contrário à lei natural o que frustra o fim para o qual ele foi
instituído. Ora, o fim essencial e primário do matrimônio é o bem da prole. E esse fica impedido por
qualquer consangüinidade, por exemplo, na união entre o pai e a filha ou entre o filho e a mãe. Mas não
o exclui totalmente, pois uma filha pode conceber do pai e, de concerto com este, criar e educar o filho,
e nisso consiste o bem da prole. Mas não convém que assim seja, porque é uma união desordenada a da
filha com o pai, como esposa, a fim de ter filhos dele e com ele os criar, ela que em tudo lhe deve estar
sujeita, como procedente dele que é. Por isso a lei natural proíbe ao pai e à mãe contraírem tal
casamento. E mais ainda à mãe que ao pai, porque com a reverência devida ao pai mais diretamente
colide o casamento do filho com a mãe que a do pai com a filha, porque a mulher deve de certo modo
estar sujeita ao marido.
Quanto ao fim secundário do matrimônio, é a repressão da concupiscência. E esse ficaria frustado se
qualquer pudesse casar com um parente. Pois, abriria largas as portas à concupiscência o não ser a
conjunção carnal proibida entre as pessoas que convivem sob o mesmo teto. Por isso a lei divina não
somente proibiu o casamento ao pai e à mãe, mas também a outras pessoas chegadas, que fazem parte
da mesma família e que devem guardar entre si um respeito mútuo. E tal o determina a Lei Mosaica:
Não descobrirás a fealdade (de tal ou tal outra), porque é fealdade tua.
Por outro lado, o fim acidental do matrimônio, é desenvolver a associação dos homens, numa só
amizade mútua. Assim, o marido alimenta para com os parentes da sua mulher o mesmo afeto que para
com os seus. E seria, pois, causar dano ao desenvolvimento dessa amizade o casar alguém com uma
parenta próxima. Pois de um tal matrimônio não resultaria nenhuma nova amizade. Por isso, as leis
humanas e as disposições da Igreja determinaram que pessoas aparentadas em certos graus não podem
casar entre si. E assim, do sobredito resulta que o parentesco impede o casamento de certas pessoas,
por direito natural; outras, por direito divino; e ainda outras, por direito positivo humano.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Eva embora nascida de Adão, não era contudo filha dele,
porque dele não nasceu ao modo pelo qual naturalmente o homem gera um semelhante em espécie.
Mas, por obra divina, que assim como fez a Eva da costela de Adão, poderia também ter feito um
cavalo. Eis porque não houve entre Eva e Adão o mesmo parentesco que entre uma filha e seu pai. Nem
Adão foi o princípio natural de Eva, como o pai o é do filho.

RESPOSTA À SEGUNDA. ─ A promiscuidade carnal praticada por certos bárbaros não a justifica a lei
natural, mas tem a sua explicação no jogo da concupiscência, que neles ofuscou essa lei.

RESPOSTA À TERCEIRA. ─ Dizemos que a união entre o homem e a mulher é de direito natural porque a
natureza assim o ensinou a todos os animais. Mas essa união ela o ensinou diversamente conforme a
diversidade dos animais e as suas diferentes condições. Ora, a conjunção carnal com os pais se opõe ao
respeito que lhes é devido. Pois, assim como a natureza infundiu nos pais a solicitude com que velam
sobre os filhos, assim também nos filhos a reverência para com os pais. Em nenhum gênero de animais
porém infundiu um desvelo perpétuo para com os filhos ou a reverência para com os pais, como o fez
no homem. Nos outros animais tê-lo mais ou menos, na medida em que são mais ou menos necessários
─ os filhos aos pais ou os pais aos filhos. E isso explica que, em certas espécies animais, repugna ao filho
ter relação carnal com a mãe, enquanto a reconhece como tal e lhe presta por isso um certo respeito,
como o narra Filósofo, do camelo e do cavalo. E como tudo que haja de moral nos animais se reuniu e
aperfeiçoou no homem, por isso tem ele uma repugnância natural a ter conjunção carnal não só com a
mãe, mas também com a filha, o que ainda menos colide com a lei natural, como dissemos. Além disso,
nos outros animais, a geração carnal não produz parentesco, como na espécie humana. Logo, não há
semelhança de razões.

RESPOSTA À QUARTA. ─ Do sobredito já resulta como a consangüinidade dos cônjuges contraria ao bem
do matrimônio. Em falsas razões se funda pois a objeção.

RESPOSTA À QUINTA. ─ Nenhum inconveniente há em duas uniões serem impedidas uma pela outra;
assim como não há semelhança onde há identidade. Do mesmo modo, o vínculo da consangüinidade
pode impedir a união matrimonial.

## Art. 4 — Se a Igreja podia fixar no quarto grau os laços de parentesco impedientes de matrimônio.
O quarto discute-se assim. ─ Parece que a Igreja não podia fixar no quarto grau os laços de parentesco
impedientes do matrimônio.

1. Pois, diz o Evangelho: Não separe o homem o que Deus ajuntou. Ora, Deus ajuntou os casados,
dentro do quarto grau de parentesco; pois, nenhuma lei divina lhes proíbe a união. Logo, também
nenhuma lei positiva deve separá-los.

2. Demais. ─ O matrimônio é um sacramento, como o batismo. Ora, nenhuma lei da Igreja pode fazer
com que não receba o caráter batismal, sendo dele capaz por direito divino, quem recebe o batismo.
Logo, nenhuma lei da Igreja pode proibir o matrimônio entre os não proibidos de casar por direito
divino.

3. O direito positivo não pode ampliar nem remover o que é de direito natural. Ora, a consangüinidade é
um vínculo natural impeditivo do matrimônio. Logo, a Igreja não pode fazer nenhuma lei determinando
quem pode ou não pode contrair matrimônio, assim como não pode fazer com que deixem de ser
parentes os que realmente o são.

4. Demais. ─ Toda lei positiva deve ter uma causa racional; pois por essa causa racional, que tem, é que
procede da lei natural. Ora, o número de graus, aceito como causa, é absolutamente irracional, por não
terem nenhuma relação com o cansado. Assim, se o parentesco é causa de proibição até ao quarto grau
é em virtude dos quatro elementos; até ao sexto, em virtude das seis idades do mundo; até ao sétimo,
em virtude dos sete dias, que são o abreviado do tempo total. Logo, parece que essa proibição nenhum
valor tem.

5. Demais. ─ Onde há a mesma causa deve haver o mesmo efeito. Ora, a causa por que a
consangüinidade impede o matrimônio, é o bem de prole, a repressão da concupiscência e a
multiplicação da amizade, como resulta do sobredito; e essas causas valem para todas as épocas. Logo,
deveriam também, em todos, os graus de parentesco impedir o matrimônio. O que não é verdade, pois,
atualmente, só até o quarto grau, ao passo que outrora até ao sétimo, o parentesco impedia o
matrimônio.

6. Demais. ─ Uma mesma união não pode ser genericamente um sacramento e uma união ilegítima. Ora,
tal se daria se a Igreja tivesse o poder de determinar um número diverso de graus impedi entes do
matrimônio. Assim o casamento entre parentes em quinto grau, quando esse parentesco era
impediente, foi ilegítimo; veio a ser porém legítimo se depois a Igreja revogou a sua proibição. O
contrário também poderia dar-se ─ se a Igreja depois de ter permitido contrair casamento dentro de
certos grau de parentesco, viesse a proibi-lo. Logo, parece que a Igreja nenhum poder tem nessa
matéria.

7. Demais. ─ O direito humano deve imitar o divino. Ora, segundo o direito divino, contido na Lei Antiga,
não corre igual proibição na linha ascendente e descendente dos graus. Assim, ao passo que a Lei Velha
proibia o casamento com a tia, não o proibia como a sobrinha. Logo, também agora não deve haver
nenhuma proibição entre sobrinhos e tios.
Mas, em contrário, o Senhor disse aos discípulos: Quem vos ouve me ouve. Logo, o preceito da Igreja
tem a mesma vigência que o de Deus. Mas, a Igreja ora proibiu e ora permitiu o casamento dentro de
certos graus, em que a lei antiga não proibia. Logo, esses graus impedem o matrimônio,

2. Demais. ─ Assim como outrora os casamentos entre gentios era regulado pelas leis civis, assim
também os casamentos entre cristãos agora os regula a Igreja. Ora, antigamente a lei civil determinava
os graus de parentesco impedientes ou não do matrimônio. Logo, também atualmente a Igreja pode
determiná-los.

SOLUÇÃO. ─ O impedimento ao matrimônio resultante dos graus de parentesco, não atuou de mesmo
modo no decurso dos tempos.
Assim, no princípio do gênero humano, só o pai e a mãe estavam proibidos de casar com a filha ou o
filho; porque então era o gênero humano pouco numeroso e havia grande necessidade de o aumentar .
Por isso não ficavam impedidas de casar senão as pessoas incapazes de realizar o fim principal do
matrimônio, que é o bem da prole, como dissemos. Mas, depois, multiplicando-se o gênero humano, a
lei de Moisés, que já começava a reprimir as paixões dá carne, impôs impedimento a um maior número
de pessoas. Por isso, como diz Rabbi Moisés, ficavam proibidos de contrair matrimônio todos os
membros de uma mesma família, habitando sob o mesmo teto. Porque seria grande incentivo à
concupiscência o permitir-lhes-a conjunção carnal entre si. Mas a Lei Velha permitia o casamento entre
os parentes em outros graus e até mesmo os ordenava, de certo modo. Assim, cada um devia casar com
uma mulher da sua parentela, a fim de evitar confusão nas heranças, porque nesse tempo o culto divino
se propagou pela sucessão hereditária.
Mais tarde porém, no regime da Lei Nova, que é a lei do Espírito e do amor, os impedimentos
abrangeram mais graus de parentesco. Porque então o culto de Deus se propagava e multiplicava pela
graça espiritual e não pela geração carnal. E os homens tiveram o dever de coibir os prazeres carnais,
para vacar às coisas espirituais e difundir com maior amplitude a caridade.
Por isso, nos tempos primitivos, o impedimento se estendia até os graus mais afastados do parentesco,
a fim de dar maior desenvolvimento à amizade pela mais ampla consangüinidade e afinidade. E, com
razão, o impedimento ia até ao sétimo grau. Quer porque, além dele, facilmente podia perder-se a
memória de uma origem comum; quer porque concordava esse contrito com a graça septiforme do
Espírito Santo.
Mais tarde, porém, nestes últimos tempos, a Igreja restringiu a interdição até ao quarto grau, por ser
inútil e perigoso proibir até graus mais remotos. Inútil, porque ninguém dava mostras de maior amizade
para com os parentes, que para com os estranhos, devido ao resfriar-se da caridade nos corações de
muitos. Perigoso porque, prevalecendo a concupiscência e a negligência, os homens já não respeitavam
suficientemente um tão grande número de parentes. E assim, estender a proibição até graus mais
remotos seria armar um laço para a condenação de muitos.
Por isso, suficiente e convenientemente a proibição ficou restrita ao quarto grau. Quer porque os
homens, continuando a viver até a quarta geração, não perdem a lembrança do seu parentesco, sendo
por isso que Deus ameaça punir os pecados, dos pais, nos filhos, até a terceira e a quarta geração. Quer
porque, em qualquer geração, uma nova mistura de sangue, cuja identidade forma o parentesco, se faz
com o sangue estranho, e quanto mais se mistura com o alheio tanto mais deixa de ser o que a princípio
era. E como os elementos são quatro, e cada um deles mais facilmente se mistura, quanto mais sutil é,
por isso, na primeira mixtão evanece a identidade do sangue, quanto ao primeiro elemento, que é
subtilíssimo. Na segunda, quanto ao segundo; na terceira, quanto ao terceiro; e na quarta, quanto ao
quarto. E assim, convenientemente, depois da quarta geração, pode reiterar-se a conjunção carnal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Assim como Deus não retifica uma união contrária aos
seu preceitos, assim também não ratifica as uniões contrárias ao preceito da Igreja, que tem a mesma
eficácia obrigatória que o preceito divino.

RESPOSTA À SEGUNDA. ─ O matrimônio não é só um sacramento, mas também uma função social. Por
isso depende mais do poder dos ministros da Igreja, que o batismo, que é unicamente sacramento. Pois,
assim como os contratos e as funções humanas por leis humanas se determinam, assim os contratos e
as funções espirituais, pela lei da Igreja.

RESPOSTA À TERCEIRA. ─ Embora o vínculo de consangüinidade seja natural, natural contudo não é que
ela impida a cópula carnal, senão dentro de um certo grau, como se disse. Por isso, a igreja não
determina por lei que certas pessoas sejam ou não parentes, pois, se o são, assim o permanecem
sempre no mesmo grau. Mas, determina a liceidade da conjunção carnal, conforme os tempos e os
graus de parentesco.

RESPOSTA À QUARTA. ─ Essas razões alegadas são antes indicadas a modo de adaptação ou de
conveniência, que a modo de causa e de necessidade.

RESPOSTA À QUINTA. ─ Com a diversidade dos tempos variam as causas de se proibir o casamento,
conforme os graus de parentesco. Por isso, o que num tempo se permite com utilidade, noutro
salutarmente se proíbe.

RESPOSTA À SEXTA. ─ Uma determinação legal não dispõe para o passado, mas para o futuro. Por isso,
se atualmente não podem casar os parentes em quinto grau, que outrora podiam, nem por isso devem
ser separados os parentes em quinto grau casados. Pois, nenhum impedimento sobreveniente ao
matrimônio pode dirimi-lo. E assim, uma união matrimonial legítima não pode, por determinações da
Igreja, tornar-se ilegítima. O mesmo se daria se fosse permitido o casamento em grau atualmente
proibido: esse matrimônio não se tornaria legítimo, por disposição da Igreja, em virtude do contrato
anterior; pois, poderiam os casados separar-se, se assim o quisessem. Mas poderiam de novo contrair
matrimônio, o que constituiria nova união.

RESPOSTA À SÉTIMA. ─ Quando a Igreja proíbe o casamento por causa dos graus de parentesco, leva em
conta sobretudo a razão do amor. Ora, tanta razão há de amor ao sobrinho, como ao tio; há até mais,
porque mais chegado é o filho ao pai que ao filho o pai, como diz Aristóteles. Por isso a Igreja proibiu
por igual o casamento entre sobrinhos e tios. ─ Mas a Lei Velha, nas suas proibições, atende sobretudo à
convivência. Proíbe por isso o casamento dos que vivendo sobre o mesmo teto, mais facilmente
poderiam dar largas à concupiscência. Ora, mais frequentemente convivia uma sobrinha com o tio, do
que uma tia com o sobrinho. Por que uma filha quase se identifica com o pai, por ser uma como parte
dele; ao passo que uma irmã não é assim chegada ao irmão, porque não é parte deste, mas com ele
nascida do mesmo pai. Por isso não havia a mesma razão de proibir o casamento em relação à sobrinha,
como em relação à tia.