# Questão 2: Do objeto da contrição.
Em seguida devemos tratar do objeto da contrição. Sobre o que seis artigos se discutem:

## Art. 1 — Se devemos ter contrição das penas e não só da culpa.
O primeiro discute-se assim. ─ Parece que devemos ter contrição não somente das penas, mas
também da culpa.

1. ─ Pois, Agostinho diz: Ninguém deseja a vida eterna, que não se penitencie desta vida mortal. Ora, a
vida mortal é uma pena. Logo, o penitente deve ter contrição também da pena.
Como diz Agostinho, temos dor do que nos sucede contra a vontade. Ora, tal não se dá com os pecados.
Logo, a contrição não é a dor dos pecados.

2. Demais. ─ Como se estabeleceu antes, com palavras de Agostinho, o penitente deve condoer-se de se
ter privado da virtude. Ora, a privação da virtude é uma pena Logo, a contrição é uma dor também dos
pecados.
Mas, em contrário. ─ Ninguém tem o de que se condoí. Ora, a penitência, como o nome indica, tem a
pena (poenam tenet). Logo, não se condói da pena. E assim, a contrição, que é uma dor penitente, não
tem por objeto a pena.

SOLUÇÃO. ─ A contrição implica, como se disse, a trituração de um corpo integro e duro. Ora, essa
integridade e dureza existe no mal da culpa, pois, a vontade, causa dela, por ter procedido mal,
permanece no que é, nem cede ao preceito da lei. Por isso, a displicência desse mal se chama, por
semelhança, contrição. Mas essa semelhança não pode aplicar-se ao mal da pena; pois, a pena significa
simplesmente uma diminuição. Por onde, do mal da pena pode haver dor, mas não contrição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A penitência, segundo Agostinho, deve ter por objeto
esta vida mortal, não por causa da sua mortalidade mesma, salvo se tomarmos a penitência em sentido
lato, para significar qualquer dor. Mas, em razão dos pecados aos quais somos arrastados pela fraqueza
desta vida.

RESPOSTA À SEGUNDA. ─ A dor pela qual nos arrependemos do pecado, que nos fez perder a virtude,
não é, essencialmente a contrição, mas o principio desta. Pois, assim como somos levados a desejar uma
coisa pelo bem que dela esperamos, assim a ter dor de um ato, pelo mal dele resultante.

## Art. 2 — Se devemos ter contrição do pecado original.
O segundo discute-se assim. ─ Parece que devemos ter contrição do pecado original

1. ─ Pois, devemos ter contrição do pecado atual, não em virtude do ato, enquanto um certo ser, mas
por causa da deformidade; porque um ato, na sua substância, é um bem e procede de Deus. Ora, o
pecado original tem a sua deformidade, como o atual. Logo, também dele devemos ter contrição.

2. Demais. - Pelo pecado original o homem se afastou de Deus; pois a sua pena foi ficar privado da visão
de Deus. Ora, a todos deve desagradar o ter-se afastado de Deus. Logo, devemos nos desagradar do
pecado original. E assim, devemos ter contrição dele.
Mas, em contrário. ─ O remédio deve ser proporcionado à doença. Ora, o pecado original foi contraído
sem a nossa vontade. Logo, não é necessário nos purifiquemos dele pelo ato de vontade chamado
contrição.

SOLUÇÃO. ─ A contrição, como dissemos, é uma dor que respeita e de certo modo tritura a dureza da
vontade. Portanto pode recair só sobre os pecados que nascem em nós pela dureza da nossa vontade. E
como o pecado original não foi cometido por vontade nossa, mas contraído pela natureza originalmente
viciada, por isso não podemos ter contrição dele, propriamente falando, mas uma simples displicência
ou dor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A contrição não tem por objeto o pecado em razão da
substância do ato somente, porque como tal não tem natureza de mal; nem em razão da deformidade
somente, porque a deformidade, em si mesma, não tem natureza de culpa, mas às vezes implica a pena.
Devemos porém ter contrição dos pecados, enquanto implica uma deformidade proveniente do ato da
vontade. O que não existe no pecado original. Por isso não precisamos ter contrição dele.
E o mesmo, devemos responder à segunda objeção. ─ Pois, é da aversão da vontade que devemos ter
contrição.

## Art. 3 — Se devemos ter contrição de todos os pecados atuais que cometemos.
O terceiro discute-se assim. ─ Parece que não devemos ter contrição de todos os pecados atuais que
cometemos.

1. ─ Pois, os contrários se curam pelos contrários. Ora, certos pecados, como a acédia e a inveja, se
cometem por tristeza. Logo, o remédio deles não deve ser a tristeza da contrição, mas a alegria.

2. Demais. ─ A contrição é um ato da vontade, que não pode recair sobre o que não pode ser objeto do
conhecimento. Ora, há certos pecados, tais os esquecidos, que não são objeto do nosso conhecimento.
Logo, não podemos ter contrição deles.

3. Demais. ─ Pela contrição voluntária delimos o que voluntariamente cometemos. Ora, a ignorância
elimina o vocabulário, como está claro no Filósofo. Logo, não devemos ter contrição do que por
ignorância cometemos.

4. Demais. ─ Não devemos ter contrição de um pecado que não pode ser por ela delido. Ora, certos
pecados não são de lidos pela contrição, como os veniais, que ainda permanecem depois da graça da
contrição. Logo, não devemos ter contrição de todos os pecados passados.
Mas, em contrário. ─ A penitência é o remédio contra todos os pecados atuais. Ora, não podemos fazer
penitência de pecados de que não podemos ter contrição, por esta ser a primeira parte de aquela. Logo,
a contrição deve ser de todos os pecados.

2. Demais. ─ Nenhum pecado pode ser perdoado sem a justificação do pecador. Ora, para a justificação
é necessária a contrição, como antes dissemos. Logo, devemos ter contrição de todos os pecados.

SOLUÇÃO. ─ Toda culpa atual procede de a nossa vontade não ceder à lei de Deus, pela transgredir, por
omissão ou por agir contra ele. E como duro se chama o que tem uma potência que não cede facilmente
ao sofrimento, por isso todo pecado atual implica uma certa dureza de vontade. Por onde, devendo nos
curar do pecado, é necessário nos seja perdoado mediante a contrição que o dele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Como do sobredito resulta, a contrição se opõe ao
pecado por proceder este da eleição da vontade, que não segue o império da lei divina; e não pelo que
tem o pecado de material, sobre o que recai a eleição da vontade. Ora, a eleição da vontade recai não só
sobre os atos das outras potências, das quais ela usa para os seus fins, mas também sobre o ato próprio
dela; pois, a vontade quer o seu querer. E assim, a eleição da vontade recai sobre a dor ou tristeza que
encerra a inveja e pecados semelhantes, quer essa dor seja sensível, quer seja da vontade mesma. Por
isso a dor da contrição se opõe a tais pecados.

RESPOSTA À SEGUNDA. ─ De dois modos podemos nos esquecer de alguma coisa. Ou porque ela se nos
deliu totalmente da memória; e então não pode ninguém indagar dela; ou porque se nos deliu da
memória parcialmente e parcialmente nela permanece, como quando me recordo em geral de ter
ouvido alguma coisa, sem que saiba especialmente o que ouvi, procurando então provocar a memória
ao reconhecimento. ─E assim sendo, também qualquer pecado pode ser esquecido, de dois modos, Ou
por permanecer na memória em geral, mas não em especial. E então devemos nos esforçar por
relembrar o pecado, porque de todo pecado mortal devemos ter contrição atual. Se porém, apesar de
toda a diligência aplicada, não nos pudermos lembrar, basta termos contrição do pecado tal como ele se
nos apresenta ao conhecimento; e devemos ter dor, não só do pecado, mas também do esquecimento
dele, causado da negligência. Se contudo o pecado de todo se nos deliu da memória, então somos
escusados do dever por impotência de agir e basta a contrição geral de tudo o por que ofendemos a
Deus. Mas desaparecendo essa impotência, como quando à memória voltar o pecado, então, estamos
obrigados a ter contrição dele em especial. Seria o mesmo caso do pobre, escusado por não poder pagar
o débito, mas contudo obrigado a fazê-lo desde que o possa.

RESPOSTA À TERCEIRA. ─ Depois da contrição do pecado mortal, pode permanecer o venial; mas não,
depois da contrição deste. Por isso, dos pecados veniais também devemos ter contrição, do mesmo
modo por que devemos fazer penitência deles, como dissemos.

RESPOSTA À QUARTA. ─ Depois da contrição do pecado mortal pode permanecer o venial. Mas não
após a contrição do venial. Por isso deve haver contrição dos pecados veniais, do mesmo modo que
penitência deles, como acima dito.

## Art. 4 — Se devemos ter contrição também dos pecados futuros.
O quarto discute-se assim. - Parece que devemos ter contrição também dos pecados futuros.

1. ─ Pois, a contrição é um ato do livre arbítrio. Ora, o livre arbítrio se estende mais ao futuro que ao
passado; pois, a eleição, ato do livre arbítrio, recai sobre os futuros contingentes, como diz Aristóteles.
Logo, a contrição tem por objeto, antes, os pecados futuros que os passados.

2. Demais. ─ O pecado se agrava pelo seu efeito conseqüente. Por isso Jerônimo diz que a pena de Ario
ainda não foi determinada, porque ainda é possível haver quem lhe caia na heresia. E o mesmo se dá
com quem é julgado homicida se ferir mortalmente, mesmo antes de o ferido morrer. Mas, nesse tempo
intermédio deve o pecador ter contrição do pecado. Logo, não só na sua extensão passada, mas
também na futura. E assim, a contrição respeita o futuro.
Mas, em contrário. ─ A contrição faz parte da penitência. Ora, a penitência sempre respeita o passado.
Logo, também a contrição.

SOLUÇÃO. ─ Em todos os motores e móveis ordenados, dá-se que o motor inferior além de seu
movimento próprio recebe, de certo modo, o movimento do motor superior; tal o que passa com o
movimento dos planetas que, além dos seus movimentos próprios, seguem o movimento do orbe
primeiro. Ora, em todas as virtudes morais, o motor é a prudência mesma, chamada auriga das virtudes.
Por onde qualquer virtude moral, além do seu movimento próprio, se conjuga com o de prudência. Ora,
o seu ato próprio recai sobre o seu objeto próprio, que é o pecado cometido. Por isso, o seu ato
principal, a saber, a contrição, respeita especificamente só o pecado pretérito. Mas, por consequência,
respeita o pecado futuro, enquanto participa do ato adjunto da prudência. E contudo não se move para
esse futuro pela sua essência própria e específica. Por isso, quem tem contrição sente dor do pecado
passado e se acautela quanto ao futuro; mas não se diz que o pecado futuro é objeto da contrição, mas
antes, da cautela, parte da prudência anexa à contrição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Diz-se que o livre arbítrio respeita os futuros
contingentes, enquanto respeita aos atos; mas não por concernir dos objetos dos atos. Por que
podemos, com o nosso livre arbítrio, cogitar das coisas passadas e necessárias; contudo, o ato mesmo
de pensar, enquanto cai sob o livre arbítrio, é um futuro contingente. E assim, também o ato de
contrição é um futuro contingente, enquanto objeto do livre arbítrio; mas o objeto deste também pode
ser o passado.

RESPOSTA À SEGUNDA. ─ Esse efeito consequente, que agrava o pecado, já precedeu em ato, como a
causa. Por onde, quando foi cometido, teve a totalidade da sua extensão: e o efeito consequente nada
lhe acrescenta essencialmente à culpa. Embora lhe acresça a pena acidental, pois muitos terão razões
de sofrer no inferno, pelos muitos males que se lhes seguiram aos pecados. Tal o sentido das palavras
de Jerônimo. Por onde não é necessário tenha a contrição outro objeto diferente dos pecados passados.

## Art. 5 — Se devemos ter contrição dos pecados alheios.
O quinto discute-se assim. ─ Parece que devemos ter contrição dos pecados alheios.

1. ─ Pois, ninguém pede perdão a não ser do pecado de que está contrito. Ora, na Escritura se pede
perdão dos pecados alheios: Perdoa ao teu servo os alheios. Logo, devemos ter contrição dos pecados
alheios.

2. Demais. ─ É dever de caridade amar ao próximo como a si mesmo. Ora, o amor de nós mesmos, nos
leva a nos afligir dos nossos males e desejar o que nos é bom. Logo, estando obrigado a desejar ao
próximo, como a nós mesmos, o bem da graça, parece que devemos ter, como dos nossos, dor pelos
pecados deles. Ora, a contrição não é senão a dor dos pecados. Logo, devemos ter contrição dos
pecados alheios.
Mas, em contrário. ─ A contrição é um ato da virtude de penitência. Ora, ninguém se penitência senão
de atos que praticou. Logo, ninguém pode ter contrição de pecados alheios.

SOLUÇÃO. ─ O que se tritura é o que antes era duro e íntegro. Por onde e necessàriamente, a contrição
do pecador deve recair sobre o mesmo que fora, antes, a dureza dele. Assim, não pode haver contrição
dos pecados alheios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O profeta roga lhe sejam perdoados os pecados alheios,
enquanto que a convivência dos pecados nos leva a consentir na contaminação da macula pecaminosa.
Por isso diz a Escritura: Serás perverso com o perverso.

RESPOSTA À SEGUNDA. ─ Devemos ter dor dos pecados alheios. Mas não é preciso termos contrição
deles; porque nem toda dor dos pecados passados é contrição, como do sobredito se colhe.

## Art. 6 — Se devemos ter contrição de cada pecado mortal.
O sexto discute-se assim. ─ Parece que não devemos ter contrição de cada pecado mortal.

1. ─ Pois, o movimento de contrição implica numa justificação instantânea. Ora, num instante não nos
podemos lembrar de cada pecado. Logo, não é necessário ter contrição de cada pecado.

2. Demais. ─ A contrição devemo-la ter dos pecados, por nos afastarem eles de Deus; pois, a conversão
para a criatura, sem a aversão de Deus, não exige a contrição, Ora, todos os pecados mortais convêm
pela aversão. Logo, basta de todo uma só contrição.

3. Demais. ─ Os pecados mortais atuais têm maior conveniência entre si, do que o atual com o original.
Ora, um só batismo dele todos os pecados atuais e o original. Logo, uma contrição geral dele todos os
pecados mortais.
Mas, em contrário. ─ Doenças diversas se curam com remédios diversos; assim, não cura os olhos o que
se aplica ao calcanhar, como diz Jerônimo. Ora, a contrição é um remédio particular contra um pecado
mortal. Logo não basta ter uma contrição geral de todos os pecados mortais.

2. Demais. ─ A contrição se completa pela confissão. Ora, é necessário confessar cada um dos pecados
mortais. Logo, também o é ter contrição de cada um.

SOLUÇÃO. ─ A contrição pode ser considerada a dupla luz: quanto ao seu princípio e quanto ao seu
termo. E chamo princípio da contrição o pensar no pecado e ter dor dele, embora não a dor de
contrição, mas a de atrição. Quanto ao termo da contrição, é dor referida, já informada pela graça. Ora,
relativamente ao seu princípio a contrição deve recair sobre cada um dos pecados que repassamos na
memória. Mas, relativamente ao termo, basta seja ela uma contrição geral de todos os pecados; pois,
então, esse movimento opera em virtude de todas as disposições precedentes.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. ─ Embora todos os pecados mortais convenham na aversão, contudo diferem
pela causa e pelo modo da aversão e pelo maior afastamento de Deus. E isto segundo a diversidade da
conversão.

RESPOSTA À TERCEIRA. ─ O batismo age em virtude dos méritos de Cristo, que teve uma virtude infinita
para delir todos os pecados; e por isso um só desses méritos basta contra todos os pecados. Mas, na
contrição, com o mérito de Cristo é necessário o nosso ato. Por onde, é necessário que ela recaia sobre
cada pecado em particular, pois não tem virtude infinita. - Ou devemos responder que o batismo é uma
geração espiritual; mas a penitência, quanto à contrição e as outras partes, é uma como cura espiritual a
modo de alteração. Pois, é claro que na geração corporal de um ser, resultante de corrupção de outro,
pela mesma geração ficam removidos todos os acidentes contrários ao ser gerado, que vieram do ser
corrupto; ao passo que na alteração fica removido apenas o acidente contrário ao que é o termo da
alteração. E semelhantemente, um só batismo dele simultaneamente todos os pecados, trazendo uma
nova vida; enquanto que a penitência não dele todos os pecados, se não recair sobre cada um em
particular. Logo, é necessário ter contrição de cada um e confessá-los de per si.