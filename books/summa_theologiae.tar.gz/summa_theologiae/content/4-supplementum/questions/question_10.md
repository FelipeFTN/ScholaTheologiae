# Questão 10: Do efeito da confissão.
Em seguida devemos tratar do efeito da confissão.
Sobre o que se discutem cinco artigos:

## Art. 1 — Se a confissão livra da morte do pecado.
O primeiro discute-se assim. ─ Parece que a confissão não livra da morte do pecado.

1. ─ Pois, a confissão vem depois da contrição. Ora, a contrição apaga suficientemente a culpa. Logo, a
confissão não livra da morte do pecado.

2. Demais. ─ Como o pecado mortal é culposo, também o venial. Ora, pela confissão torna-se venial o
que antes era mortal, como diz a letra do Mestre das Sentenças. Logo, pela confissão não fica perdoada
a culpa, mas uma culpa se muda em outra.
Mas, em contrário. ─ A confissão faz parte do sacramento da penitência. Ora, a penitência livra da culpa.
Logo, também a confissão.

SOLUÇÃO. ─ A penitência, enquanto sacramento, sobretudo se perfaz na confissão; pois que por ela nós
nos sujeitamos aos ministros da Igreja, que são os dispensa dores dos sacramentos. Pois, a contrição vai
junta com o desejo da confissão; e a satisfação é determinada pelo juízo do sacerdote, a quem a
confissão é feita. E como o sacramento da penitência infunde a graça, pela qual se faz a remissão dos
pecados, como no batismo, por isso e do mesmo modo a confissão, por força da absolvição anexa,
perdoa a culpa, como o faz o batismo. Mas o batismo livra da morte do pecado; não só quando
atualmente recebido, mas também enquanto já está no nosso desejo. Talo caso dos que se achegam aos
batismos já santificados. E se nenhum obstáculo o impedisse, a própria colação do batismo daria a graça
que perdoa os pecados, se já antes não tivessem sido remitidos. E o mesmo devemos dizer da confissão
preexistente acompanhada da absolvição; a qual, enquanto já no desejo do penitente, era suficiente a
livrar da culpa; mas depois, no ato da confissão e da absolvição, aumenta a graça. E então obteria o
confitente perdão dos pecados, se a dor precedente deles não fosse suficiente para haver contrição, e
ele não opusesse então nenhuma resistência à graça. Por onde, assim como dizemos que o batismo livra
da morte, assim também podemos dizê-lo da confissão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A contrição vai junta com o desejo da confissão. E por
isso livra da culpa os penitentes como o desejo do batismo, os batizandos.

RESPOSTA À SEGUNDA. ─ O pecado venial não é aí tomado no sentido da culpa, mas no de uma pena
facilmente expiável. Donde, não se segue que uma culpa se converta em outra; mas é antes, totalmente
apagada. Pois, em três sentidos podemos tomar o pecado venial: genericamente, como uma palavra vã;
casualmente, isto é, por ter em si causa de vênia, como o pecado cometido por fraqueza; e enfim,
eventualmente, como no caso vertente, pois da confissão provém o conseguirmos vênia do pecado
passado.

## Art. 2 — Se a confissão livra, de algum modo, da pena.
O segundo discute-se assim. ─ Parece que a confissão não livra, de nenhum modo, da pena.

1. ─ Pois, ao pecado não é devida senão uma pena eterna ou temporal. Ora, a pena eterna é perdoada
pela contrição: e a pena temporal, pela satisfação. Logo, pela confissão nada é perdoado da pena.

2. Demais. ─ A vontade é reputada como ato, como diz a letra do Mestre. Ora, o contrito tem o
propósito de confessar. Logo, isso lhe é o mesmo que já ter confessado. E assim, pela confissão depois
feita, nada lhe resta a ser perdoado da pena.
Mas, em contrário. ─ A confissão é uma obra penal. Ora, por todas as obras penais se expia a pena
devida ao pecado. Logo, também pela confissão.

SOLUÇÃO. ─ A confissão simultaneamente com a absolvição tem o poder de livrar da pena, de dois
modos. - Primeiro, por força mesmo da absolvição. E assim, já existindo em desejo, livra da pena eterna,
como também da culpa; e essa pena é uma pena de danação e de morte total. Mas dela livres, ainda
ficamos obrigados à pena temporal, pena que é um remédio purificador e reparador. E essa pena devem
sofrê-la no purgatório, mesmo os que foram livres das penas do inferno. Não é ela proporcionada às
forças do penitente, enquanto ainda vive neste mundo; mas, pelo poder das chaves, é diminuída, de
modo a proporcionar-se às forças do penitente, de maneira que, satisfazendo, pode purificar-se nesta
vida. ─ De outro modo diminui a pena o ato do confitente, pela sua natureza mesma, que vai junto com
a pena do pêjo. E assim quanto mais vezes confessarmos os mesmos pecados tanto mais se nos diminui
a pena.
Donde se deduz a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. ─ A vontade não se reputa como fato quando este procede de outrem, como no
batismo; pois, a vontade de receber o batismo não vale tanto quanto o ato mesmo de receber. Mas, a
vontade é reputada como fato em matéria absolutamente dependente de nós. ─ E além disso, quanto
ao prêmio essencial; não porém quanto à remoção da pena e coisas semelhantes, em relação ao que se
leva em conta o mérito, acidental e secundàriamente. Por isso quem confessou e foi absolvido será
punido no purgatório, menos do que quem só teve contrição.

## Art. 3 — Se a confissão abre o paraíso.
O terceiro discute-se assim. ─ Parece que a confissão não abre o paraíso.

1. ─ Pois, causas diversas produzem efeitos diversos. Ora, abrir o paraíso é efeito do batismo. Logo, não
é efeito da confissão.

2. Demais. ─ No que está fechado não podemos entrar, antes de se abrir. Ora, quem morre antes da
confissão pode entrar no paraíso. Logo, a confissão não abre o paraíso.
Mas, em contrário. ─ A confissão nos torna sujeitos ao poder das chaves da Igreja. Ora, por ela se abre o
paraíso. Logo, também pela confissão.

SOLUÇÃO. ─ Ficamos impedidos de entrar no paraíso pela culpa e pelo reato da pena. E como a
confissão remove esses obstáculos, conforme do sobredito se colhe, por isso dizemos que abre o
paraíso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora o batismo e a penitência sejam sacramentos
diversos, contudo atuam em virtude da paixão única de Cristo, por quem nos foi aberta a porta do
paraíso.

RESPOSTA À SEGUNDA. ─ Antes do desejo da confissão o paraíso estava fechado ao pecador em estado
de pecado mortal, embora depois, pela contrição que implica o desejo da confissão, se abra, mesmo
antes da confissão atualmente feita. Contudo, o obstáculo do reato não fica totalmente removido, antes
da confissão e da satisfação.

## Art. 4 — Se devemos considerar como efeito da confissão o dar esperança da salvação.
O quarto discute-se assim. ─ Parece que não devemos considerar como efeito da contrição o dar
esperança da salvação.

1. ─ Pois, a esperança procede de todos os atos meritórios. Logo, não parece efeito próprio da confissão.

2. Demais. ─ Pela tribulação chegamos à esperança, como diz o Apóstolo. Ora, atribulação sobretudo a
sofremos na satisfação. Logo dar à esperança da salvação pertence antes satisfação que à confissão.
Mas, em contrário. ─ Pela confissão tornamo-nos mais humildes e doces, como diz à let o Mestre. Ora,
daí haurirmos a esperança da salvação. Logo, o efeito da confissão é dar a esperança da salvação.

SOLUÇÃO. ─ Esperança do perdão para os nossos pecados não a temos senão de Cristo. E como pela
confissão nos sujeitamos ao poder das chaves da Igreja, que tira a sua virtude da paixão de Cristo, por
isso dizemos que a confissão dá a esperança da salvação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Nos nossos atos não pode fundar-se de maneira principal
a esperança da salvação; mas na graça do Redentor. E como a confissão se funda nessa graça, por isso
dá a esperança da salvação, não só como ato meritório, mas também como parte do sacramento.

RESPOSTA À SEGUNDA. ─ A tribulação dá a esperança da salvação porque serve de prova à nossa
virtude e de purificar da pena; mas a confissão dá a esperança também do modo predito.

## Art. 5 — Se uma confissão geral basta para apagar os pecados mortais esquecidos.
O quinto discute-se assim. ─ Parece que uma confissão geral não basta para apagar os pecados
mortais esquecidos.

1. ─ Pois, o pecado perdoado pela confissão não temos necessidade de confessá-lo de novo. Se,
portanto, os pecados esquecidos fossem perdoados pela confissão geral, não seria necessário confessá-
los quando de novo nos recordássemos deles.

2. Demais. ─ Quem não tem consciência de um pecado ou não o cometeu ou o esqueceu. Se, portanto,
pela confissão geral fossem perdoados os pecados mortais esquecidos, quem não tivesse consciência de
um pecado mortal, sempre que faz uma confissão geral, pode estar certo de estar imune do pecado
mortal. O que vai, contra as palavras do Apóstolo: De nada me argui a consciência, mas nem por isso me
dou por justificado.

3. Demais. ─ A negligência não nos pode dar nenhuma vantagem. Ora, só por negligência é que
poderemos esquecer um pecado mortal, que não nos foi perdoado. Logo, não pode dai nos advír uma
vantagem tal que o pecado pudesse nos ser perdoado sem uma confissão especial.

4. Demais. ─ Está mais afastado do conhecimento do confítente aquilo que ele ignora de todo, que
aquilo de que se esqueceu. Ora, os pecados cometidos por ignorância a confissão geral não os apaga;
porque então os heréticos, ou ainda alguns homens simples, que ignoram serem pecados certos, em
cujo estado vivem, esses ficariam absolvidos pela confissão geral ─ o que é falso. Logo, a confissão geral
não perdoa os pecados esquecidos.
Mas, em contrário. ─ A Escritura diz: Chegai-vos a ele e sereis iluminados e vossos rostos não serão
confundidos. Ora, quem confessa todos os pecados, de que tem consciência, se aproxima de Deus o
quanto pode. E mais não se lhe pode exigir. Portanto, não é confundido, para sofrer uma repulsa, mas
para obter perdão.

2. Demais. ─ Quem confessa e não é dissimulado alcança o perdão. Ora, quem confessa todos os
pecados, que tem na memória e os de que se esqueceu, não procede dissimuladamente; pois, incorre
na ignorância de fato, que escusa do pecado. Logo, consegue o perdão. E assim os pecados esquecidos
lhe são perdoados, pois seria ímpio esperar o perdão só da metade dos pecados.

SOLUÇÃO. ─ A confissão produz os seus efeitos, pressuposta a contrição, que apaga a culpa. E assim a
confissão diretamente se ordena ao perdão da pena; o que ela produz, pelo pejo de que é
acompanhada, em virtude do poder das chaves a que o confitente se sujeita. Pode dar-se porém, que,
pela contrição precedente, um pecado foi perdoado quanto à culpa, ou em geral, quando dele já não
nos lembrávamos, ou em especial, e contudo antes da confissão não nos lembrarmos desse pecado.
Nesse caso a confissão geral sacramental produz a remissão da pena em virtude do poder das chaves, a
que o confitente se sujeita, não opondo da sua parte nenhum obstáculo. Mas como a vergonha de
confessar o pecado em especial ao sacerdote, e que diminui a pena, o confitente não a teve, por isso a
sua pena não lhe fica diminuída.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Na confissão sacramental não só é necessário a
absolvição, mas também o juízo do sacerdote, que impõe a satisfação exterior. Por onde, embora o
penitente já tenha recebido a absolvição, contudo está obrigado a confessar, para suprir o que faltou à
confissão sacramental.

RESPOSTA À SEGUNDA. ─ Como dissemos, a confissão não é eficaz sem a contrição precedente. Mas
esta não podemos saber se verdadeiramente a tivemos, nem podemos ter a certeza de haver recebido a
graça. Por isso também não podemos saber com certeza se pela confissão geral o pecado esquecido nos
foi perdoado, embora possamos presumi-lo por certas conjecturas.

RESPOSTA À TERCEIRA. ─ No caso suposto, nenhuma vantagem resulta da negligência. Porque o
confitente não alcança a plena remissão dos pecados, como de outro modo teria conseguido. Nem
merece do mesmo modo. E além disso, está obrigado a confessar o pecado, quando lhe vier à memória.

RESPOSTA À QUARTA. ─ A ignorância de direito não excusa, porque já ela é um pecado; mas a
ignorância de fato escusa. Portanto, quem não confessava um pecado, por não saber que o fosse, por
ignorância do direito divino, não fica livre da dissimulação. Escusado porém ficaria, se não soubesse que
era pecado, por ignorância de uma circunstância particular; assim, se teve relação com mulher alheia,
pensando que fosse a sua. Mas, o esquecimento de um ato pecaminoso constitui ignorância de fato. Por
isso escusa do pecado da dissimulação na confissão, o qual impede o fruto da absolvição e da confissão.