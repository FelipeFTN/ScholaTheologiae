# Questão 63: Das segundas núpcias.
Em seguida devemos tratar das segundas núpcias.
E nesta questão, discutem-se dois artigos:

## Art. 1 — Se as segundas núpcias são lícitas.
O primeiro discute-se assim. ─ Parece que as segundas núpcias não são lícitas.

1. Pois, um juízo sobre uma realidade deve fundar-se na verdade da mesma. Ora, como diz Crisóstomo,
receber segundo marido é cometer uma verdadeira fornicação. Que não é lícito. Logo, nem o é o
segundo matrimônio.

2. Demais. ─ Tudo o que não é bom não é lícito. Ora, Ambrósio diz, que um duplo matrimônio não é
bom. Logo, não é lícito.

3. Demais. ─ Ninguém deve ser proibido de tomar parte nas coisas honestas e lícitas. Ora, os sacerdotes
são proibidos de tomar parte nas segundas núpcias, como diz o Mestre. Logo, não são lícitas.

4. Demais. - Ninguém deve sofrer pena senão por uma culpa. Ora, quem contrai segundas núpcias
incorre na pena de irregularidade. Logo, não são lícitas.
Mas, em contrário, lemos na Escritura, que Abraão contraiu segundas núpcias.

2. Demais. ─ O Apóstolo diz: Quero pois que as que são moças, i.é, viúvas, se casem, criem filhos. Logo,
as segundas núpcias são lícitas.

SOLUÇÃO. ─ O vínculo matrimonial não dura senão até a morte, como o diz o Apóstolo. Por onde,
morrendo um dos cônjuges, esse vínculo desaparece. Portanto, por causa de um precedente
matrimônio ninguém fica impedido de contrair segundo, desde que morreu o outro cônjuge. E assim,
não só as segundas núpcias são lícitas, mas também as terceiras e todas as demais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Crisóstomo se refere à concupiscência, que costuma ser a
causa de se contraírem segundas núpcias, e que também provoca à concupiscência.

RESPOSTA À SEGUNDA. ─ Diz-se que o segundo matrimônio não é bom, não por ser ilícito, mas por não
ter aquela honra simbólica, que as primeiras núpcias tem, pelas quais há a unidade entre os cônjuges
como entre Cristo e a sua Igreja.

RESPOSTA À TERCEIRA. ─ Os sacerdotes, consagrados às coisas divinas, ficam proibidos não só do ilícito,
mas também do que implica qualquer espécie de imperfeição. Por isso ficam também proibidos de
tomar parte nas segundas núpcias, que não se revestem da honestidade das primeiras.

RESPOSTA À QUARTA. ─ Incorre-se em irregularidade não sempre por culpa, mas por deficiência do que
exige o sacramento. Logo, a objeção não colhe.

## Art. 2 — Se o segundo matrimônio é sacramento.
O segundo discute-se assim. ─ Parece que o segundo matrimônio não é sacramento.

1. Pois, quem reitera um sacramento o profana. Ora, não devemos profanar nenhum sacramento. Logo,
se o segundo matrimônio fosse sacramento, de nenhum modo devia ser reiterado.

2. Demais. ─ Em todo sacramento é concedida uma bênção. Ora, nas segundas núpcias não se confere
nenhuma bênção, como diz o Mestre. Logo, não constituem nenhum sacramento.
3 . Demais. ─ A significação é da essência do sacramento. Ora, o segundo matrimônio já não tem a
significação desse sacramento, pois, não há mais a unidade entre os cônjuges, como entre Cristo e a sua
Igreja. Logo, não é sacramento.

4. Demais. ─ Um sacramento não impede receber outro, o segundo matrimônio impede receber as
ordens. Logo, não é sacramento.
Mas, em contrário. ─ A cópula carnal, no segundo matrimônio, é isenta de pecado, como no primeiro.
Ora, a cópula carnal no matrimônio é isenta de pecado por causa dos três bens dele ─ a fé, a prole e o
sacramento. Logo, o segundo matrimônio é sacramento.

2. Demais. ─ De uma segunda conjunção não sacramental, entre um homem e uma mulher, não resulta
nenhuma irregularidade, ao contrário do que se dá com a fornicação. Ora, das segundas núpcias resulta
a irregularidade. Logo, são sacramentais.

SOLUÇÃO. ─ Onde há o essencial ao sacramento, aí também existe o sacramento. Ora, as segundas
núpcias realizam tudo o essencial ao sacramento do matrimônio, a saber: a matéria devida qual é a
legitimidade das pessoas; a forma devida, que é a expressão do consentimento interior por palavras de
presente. Logo, como o primeiro, também o segundo matrimônio é sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Isso se entende do sacramento, com efeito perpétuo.
Então, o fato de ser o sacramento reiterado dá a compreender que o primeiro não era ficaz, donde
resulta a profanação deste. Tal é o caso de todos os sacramentos, que imprimem caráter. Mas os
sacramentos sem efeito perpétuo, como a penitência, podem-se reiterar sem serem por isso
profanados. Ora, como o vínculo matrimonial desaparece pela morte, nenhuma profanação sofre o
sacramento, se a mulher, depois da morte do marido, casar com outro.

RESPOSTA À SEGUNDA. ─ O segundo matrimônio, em si mesmo considerado, é um sacramento perfeito.
Contudo, relativamente ao primeiro, falta-lhe algo do sacramento, por não ter a significação plena do
matrimônio, desde que não há unidade de cônjuges, como há entre Cristo e a Igreja. Essa é a razão de
serem as segundas núpcias privadas da bênção, ─ Mas isto deve-se entender, quando as núpcias são
segundas, tanto para o ─ homem como para a mulher, ou só para a mulher. Assim, se uma virgem
contrair matrimônio com um viúvo, não deixa esse matrimônio de receber a bênção nupcial. Pois de
certo modo, mesmo comparado com as primeiras núpcias conserva o simbolismo; porque Cristo,
embora tenha como esposa única a sua Igreja, numa só Igreja são várias as pessoas desposadas. A alma,
porém, não pode ser esposa de outrem senão de Cristo; porque do contrário haveria fornicação com o
demônio, nem existiria o matrimônio espiritual. Por isso, quando a mulher contrai segundas núpcias,
estas não recebem a bênção, por deficiência ao que exige o sacramento.

RESPOSTA À TERCEIRA. ─ No segundo matrimônio, em si mesmo considerado, o simbolismo é perfeito;
mas não, se o consideramos em relação com o primeiro.

RESPOSTA À QUARTA. ─ O segundo matrimônio impede receber o sacramento da ordem, pela
deficiência sacramental que implica, e não enquanto sacramento.