# Questão 91: Do estado do mundo depois do juízo.
Em seguida devemos tratar do estado do mundo e dos ressuscitados, depois do juízo. O que abrange
uma tríplice consideração. Primeira, do estado e das disposições do mundo. Segunda, do estado dos
bem-aventurados. Terceira, do estado dos maus.
Na primeira questão discutem-se cinco artigos:

## Art. 1 — Se o mundo será renovado.
O primeiro discute-se assim. ─ Parece que o mundo não será nunca renovado.

1. ─ Nada existirá senão o que já antes existia especificamente, conforme aquilo da Escritura: Que é o
que foi? É o mesmo que o que há de ser. Ora, o mundo não teve nunca outra disposição, diferente da
atual, quanto às suas partes essenciais, aos gêneros e às espécies. Logo, nunca será renovado.

2. Demais. ─ Toda inovação é uma alteração. Ora, é impossível o universo alterar-se; porque todo
alterado se reduz ao ser alterante, mas não alterado, sujeito contudo ao movimento local e impossível
de ser colocado fora do universo. Logo, não é mundo susceptível de alteração.

3. Demais. ─ A Escritura diz: Deus descansou no sétimo dia de toda a obra, que fizera; o que significa,
expõe os Santos Padres, que cessou de criar novos seres. Ora, nessa primeira Instituição não impôs às
criaturas um modo de ser diverso do que agora tem naturalmente. Logo, nunca tiveram outro modo de
ser.

4. Demais. ─ A atual disposição dos seres do universo é natural. Se, portanto, fossem mudados para
outra disposição, esta última lhes contrariaria a natureza. Ora, o que não é natural e é acidental não
pode ser perpétuo, como o demonstra Aristóteles. Por consequência, essa nova disposição as criaturas
teriam de a perder. Daí a necessidade de se admitir, com Empédoeles e Orígenes, uma transformação
circular do mundo: depois deste mundo haveria outro, e em seguida outro e assim por diante.

5. Demais. ─ A glória da renovação é dada como prêmio à criatura racional. Ora, onde não há mérito,
não pode haver prêmio. Logo, como as criaturas insensíveis não podem merecer, resulta que não serão
renovadas.
Mas, em contrário, a Escritura: Eis aqui estou eu que crio uns céus novos e uma terra nova, e não
persistirá na memória o que antes existiu. E noutro lugar: Vi um céu novo e uma terra nova; porque o
primeiro céu e a primeira terra se foram.

2. Demais. ─ Uma habitação deve ser adaptada ao habitante. Ora, o mundo foi feito para ser habitação
do homem. Logo, deve-lhe ser adaptada. Ora, o homem será renovado. Portanto, também o mundo.

3. Demais. ─ Todo animal ama ao seu semelhante, diz a Escritura; donde se conclui ser a semelhança a
causa do amor. Ora, o homem tem certa semelhança com o universo, sendo por isso chamado pequeno
mundo. Logo, o homem ama naturalmente o mundo universo. Portanto, lhe deseja o bem. Logo, para o
desejo do homem ser satisfeito, também o universo deve ser renovado.

SOLUÇÃO. ─ Cremos que todos os seres corpóreos foram feitos para o homem, e por isso dizemos que
todos lhe estão sujeitos. Ora, podem lhe servir de dois modos: sustentando-lhe a vida do corpo e
fazendo-o progredir no conhecimento de Deus, pois, as cousas de Deus invisíveis ele as vê consideradas
pelas obras que foram feitas, como diz o Apóstolo. Ora, do primeiro serviço prestado pelas criaturas o
homem glorificado de nenhum modo precisará; pois, o poder divino, glorificando-lhe imediatamente a
alma, tornar-lhe-á o corpo, por meio dela, absolutamente incorruptível. Do segundo ministério também
não precisará, para o conhecimento intelectual, porque com esse conhecimento os santos verão
imediatamente a essência de Deus. Mas, os olhos carnais não poderão alcançar essa visão da essência.
Por isso, a fim de terem a consolação de gozarem, na medida do que lhes for possível, da visão divina,
contemplarão a divindade nos seus efeitos corporais, onde aparecerão indícios manifestos da majestade
divina; sobretudo na carne de Cristo, depois nos corpos dos santos e enfim em todos os mais corpos.
Será portanto necessário todos os corpos receberem maior influência da bondade divina, que neste
mundo; não para os fazer variar de espécie, mas para lhes acrescentar à perfeição da glória. E tal será a
renovação do mundo. Por onde, ao mesmo tempo será o mundo renovado e o homem glorificado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Salomão se refere, nesse lugar, ao curso natural das
cousas, como se vê pelo que acrescenta: Nada de novo debaixo do sol. Ora, como o sol se move
circularmente, por força o que lhe está sujeito a ação deve também de certo modo mover-se em círculo.
E isso consiste em o que já existir voltar de novo à existência, na mesma espécie, mas com
individualidade diferente, como diz Aristóteles. Ora, o que já está na vida da glória não depende do sol.

RESPOSTA À SEGUNDA. ─ Essa objeção se funda na alteração natural, produzida por um agente natural,
cuja ação se produz fatalmente. Pois, tal agente não pode infundir nenhuma disposição nova nos seres
que lhe estão sujeitos, salvo se for modificado no mesmo sentido. Ora, o que Deus faz procede da sua
livre vontade por onde, sem haver em Deus mudança nenhuma, sua vontade pode introduzir no
universo ora uma ora outra alteração, que, portanto, não se reduzirão a nenhum princípio movido, mas
a Deus, princípio imóvel.

RESPOSTA À TERCEIRA. ─ Quando se diz que Deus no sétimo dia cessou de fazer novas criaturas,
significa isso que nada depois foi feito que já antes - não preexistisse por alguma semelhança genérica
ou específica; ou pelo menos no seu principio seminal; ou enfim em potência virtual. Ora, afirmo que a
futura renovação do mundo já preexistia nas obras dos seis dias, numa como remota semelhança, na
glória e na graça dos anjos. Preexistiu também em potência virtual, então infundida na criatura, para
receber da ação divina essa renovação.

RESPOSTA À QUARTA. ─ Essa nova disposição não será natural nem contra a natureza; mas superior à
natureza, como a graça e a glória são superiores à natureza da alma. E emanará de um agente eterno
que eternamente a fará subsistir.

RESPOSTA À QUINTA. ─ Embora os corpos insensíveis não possam merecer essa glória, propriamente
falando, o homem contudo mereceu que ela fosse conferida a todo o universo, redundando-lhe isso em
aumento da sua glória. Assim como pode um merecer vestir-se de roupas mais ornadas, sem que essas
vestes de nenhum modo merecessem tais ornatos.

## Art. 2 — Se o movimento dos corpos celestes cessará, nessa renovação do mundo.
O segundo discute-se assim. - Parece que o movimento dos corpos celestes não cessará, nessa
renovação do mundo.

1. Pois, diz a Escritura: ver-se-ão sempre as sementes e as searas, o frio e o estio, o verão e o inverno, o
dia e a noite sucedendo um ao outro todo o tempo que a terra durar. Ora, o dia e a noite, o verão e o
inverno são causados pelo movimento do sol. Logo, nunca o movimento do sol cessará.

2. Demais. ─ A Escritura diz: Isto diz o Senhor, que dá o sol para a luz do dia, a ordem da lua e das
estrelas para a luz da noite; o que turba o mar e logo soam as suas ondas; se faltarem estas leis diante
de mim, então furtará também a linhagem de Israel, para que não haja diante de mim todos os dias.
Ora, a linhagem de Israel não faltará nunca mas durará perpetuamente. Logo, as leis do dia e da noite, e
das ondas do mar, causadas pelo movimento do céu, durarão perpetuamente. Portanto, o movimento
do céu nunca cessará.

3. Demais. ─ A substância dos corpos celestes existirá sempre. Ora, é vão admitir a existência de uma
cousa sem lhe admitir a causa que a produziu. Ora, os corpos celestes foram feitos para que dividam o
dia e a noite e sirvam de sinais para mostrar os tempos, os dias e os anos, na expressão da Escritura. O
que não poderão fazer senão pelo movimento. Logo, o movimento deles perdurará sempre; do
contrário seria inútil continuarem a existir.

4. Demais. ─ Essa renovação do mundo torná-lo-á melhor. Logo, nenhum dos corpos que continuarão á
existir será privado de nenhuma das suas perfeições. Ora; o movimento faz parte da perfeição dos
corpos celestes; pois, como diz Aristóteles, é pelo movimento que esses corpos participam da divina
bondade. Logo, o movimento do céu não cessará.

5. Demais. ─ O sol, movendo-se em círculo, ilumina sucessivamente as diversas partes do mundo. Se
pois o movimento circular do céu cessasse, em algum ponto da superfície da terra haveria perpétua
obscuridade. O que não se coaduna com o mundo renovado.

6. Demais. ─ Se o movimento cessasse não seria senão por acarretar no céu uma certa imperfeição, uma
como fadiga ou cansaço. O que não pode ser, porque esse movimento é natural e os corpos celestes são
impassíveis e, portanto, nenhuma fadiga lhes causará o seu movimento, como diz Aristóteles. Logo, o
movimento do céu não cessará nunca.

7. Demais. ─ Inútil é uma potência que não se atualiza. Ora, seja qual for a posição ocupada por um
corpo celeste, está em potência em relação a outra. Logo, se não se atualizar, essa potência existirá em
vão e será sempre imperfeita. Ora, não pode atualizar-se senão pelo movimento local. Logo, há de
mover-se sempre.

8. Demais. ─ O que é indiferente a quaisquer modificações, ou se lhe atribuem todas ou nenhuma. Ora,
ao sol é indiferente estar no oriente ou no ocidente; do contrário o seu movimento não seria uniforme
em todas as suas posições, e se moveria mais rápido para o lugar que lhe fosse mais natural ocupar.
Logo, ou o sol não se lhe pode atribuir nenhuma das duas posições referidas, ou se lhe hão de atribuir
ambas. Ora, nem ambas nem nenhuma das duas lhe podem ser atribuídas senão sucessivamente; pois,
se está em repouso, necessariamente há de ser em algum lugar. Logo, o corpo do sol há de mover-se
sempre. E pela mesma razão todos os corpos celestes.

9. Demais. ─ O movimento do céu é a causa do tempo. Portanto, faltando ele desaparecerá este. Ora, se
faltasse deveria ser instantaneamente, mas, a definição do instante é: o que é o início do futuro e o fim
do passado, segundo o diz Aristóteles. E assim, depois do último instante do tempo ainda haveria
tempo. O que é impossível. Logo, o movimento do céu não cessará nunca.
10. Demais. ─ A glória não destrói a natureza. Ora, o movimento do céu é natural. Logo, não será
destruído pela glória.
Mas, em contrário, o Apocalipse: diz que o anjo que apareceu jurou por aquele que vive por século de
séculos, porque não haverá mais tempo, i. é, depois de ter o sétimo anjo tocado a corneta, durante o
som da qual, os mortos ressurgirão, diz o Apóstolo. Ora, não havendo tempo, não haverá também
movimento do céu. Logo, o movimento do céu cessará.

2. Demais. ─ A Escritura ordena: Não se porá o teu sol de ali em diante e a tua lua não minguará. Ora, o
ocaso do sol e o minguante da lua são causados pelo movimento do céu. Logo, o movimento do céu um
dia cessará.

3. Demais. ─ Como o prova Aristóteles, o movimento do céu tem por fim as contínuas gerações que se
dão neste mundo. Ora, a geração cessará uma vez completo o número dos eleitos. Logo, o movimento
do céu cessará.

4. Demais. ─ Todo movimento tende para algum termo, como diz Aristóteles. Ora, todo movimento que
tende para um termo nele repousa uma vez alcançado. Logo, ou o movimento do céu não atingirá nunca
o seu fim, sendo então inútil, ou há de acabar no repouso.

5. Demais. ─ O repouso é mais nobre que o movimento; porque os seres imóveis mais se assemelham a
Deus, que é a suma imobilidade. Ora, o movimento dos corpos terrestres tem por termo natural o
repouso. Logo, sendo os corpos celestes muito mais nobres que os terrestres, o movimento deles há de
ter como termo natural o repouso.

SOLUÇÃO. ─ Sobre esta questão há três opiniões.
A primeira é dos filósofos, que dizem que há de durar sempre o movimento do céu. ─ Mas esta opinião
não concorda com a nossa fé, consoante à qual o número dos eleitos foi predeterminado por Deus.
Portanto, a geração humana não pode durar perpetuamente; e pela mesma razão tudo o mais ordenado
a essa geração, como o movimento do céu e as variações dos elementos.
Outros porém, pretendem, que o movimento do céu deve cessar, de acordo com as leis da natureza. ─
Mas isto também é falso. Porque a todo corpo dotado de movimento natural um lugar lhe compete
onde naturalmente repousa, para o qual naturalmente se move e do qual só por violência se afasta. Ora,
não podemos determinar nenhum lugar como esse aos corpos celestes; pois, não é mais natural ao sol
mover-se para o oriente do que dele se afastar. Portanto, ou o seu movimento não seria totalmente
natural, ou não terminaria naturalmente no repouso.
Por isso devemos responder, com outros, que o movimento do céu cessará no mundo renovado, não
por nenhuma causa natural, mas pelo querer da vontade divina. Pois, os corpos celestes, como todos os
mais, foram feitos, a dupla luz, para a utilidade do homem, como dissemos. Ora, no estado da glória, o
homem não precisará do ministério dos corpos celestes para sustentar a vida do corpo. Pois, desse
modo, os corpos celestes lhe servem mediante o movimento, pois, é o movimento do céu a causa da
multiplicação dos homens; da geração das plantas e dos animais, necessários ao uso humano; e também
do equilíbrio da atmosfera, pela qual se conserva a saúde. Portanto, glorificado o homem, o movimento
do céu cessará.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essas palavras se referem à terra na sua condição atual,
em que pode ser princípio da geração e da corrupção das plantas. O que se conclui das palavras mesmas
citadas ─ em todo o tempo que a terra durar, ver-se-ão sempre as sementes e as searas, etc. Ora,
devemos conceder, pura e simplesmente, que, enquanto a terra durar, produzindo sementes e searas, o
movimento do céu não cessará.
E semelhantemente devemos responder à segunda objeção, que Deus se refere, no lugar aduzido, à
duração da linhagem de Israel, na situação presente. O que é claro pela sequência: E a linhagem de
Israel, para que não haja gente diante de mim todos os dias. Ora, depois desta vida, já não haverá a
sucessão dos dias. Por isso as leis mencionadas também não existirão no mundo renovado.

RESPOSTA À TERCEIRA. ─ O fim aí assinalado aos corpos celestes é o fim próximo, por ser o ato próprio
deles. Mas esse ato se ordena a um fim ulterior, a saber, servir ao homem, como é claro pelo lugar
seguinte: Não seja que, levantando os olhos ao céu, vejas o sol e a lua e todos os astros do céu, e caindo
em erro, adores e desculto a essas causas, que o Senhor teu Deus criou para o serviço de todas as
gentes que vivem debaixo do céu. Por onde, devemos julgar dos corpos celestes antes pelo serviço que
prestam ao homem do que pelo fim que a Escritura lhes assinala. E os corpos celestes de outro modo
servirão ao ministério do homem glorificado, como já dissemos. Donde, pois, não se segue que
continuem a existir em vão.

RESPOSTA À QUARTA. ─ O movimento não é da perfeição dos corpos celestes, senão enquanto,
mediante ele, são a causa da geração e da corrupção dos seres terrestres. E por aí também o
movimento fá-los participarem da bondade divina por uma certa semelhança de causalidade. Mas o
movimento não é da perfeição da substância do céu, que subsistirá. Donde portanto não se segue que,
cessado o movimento, a substância do céu, enquanto subsistente, sofra qualquer detrimento na sua
perfeição.

RESPOSTA À QUINTA. ─ Todos os corpos elementares por si mesmos de certo modo participarão do
esplendor da glória. Por onde, embora algum ponto da superfície da terra não seja iluminado pelo sol,
de maneira nenhuma reinará aí a obscuridade.

RESPOSTA À SEXTA. ─ Aquilo do Apóstolo ─ Todas as criaturas gemem, etc. ─ a Glosa de Ambrósio diz
expressivamente: Todos os elementos cumprem a sua missão laboriosamente; assim, o sol e a lua
ocupam o espaço, que lhes foi determinado no céu, não sem labor. Essa como pena tem em nós a sua
causa. Por isso descansarão quando nós subirmos ao céu. ─ Tal labor, como creio, não significa nenhuma
fadiga ou paixão que os corpos celestes sofram no seu movimento, pois, este é natural, não
acompanhado de qualquer violência, como o prova Aristóteles. Mas a palavra labor, no lugar citado,
significa a falta do termo a que tende o movimento. Por onde, sendo o movimento de tais corpos
ordenado pela divina providência a completar o número dos eleitos, enquanto este não se acha
completo, ainda não alcançou o movimento dos corpos celestes o fim para que foi ordenado. E então,
por semelhança, se diz que trabalham, como o homem que ainda não possui o que busca. Ora, essa
privação não mais a terá o céu, quando o número dos eleitos estiver completo. ─ Ou pode ainda o texto
referir-se ao desejo que nutrem as criaturas dessa futura renovação, que esperam, por divina
disposição.

RESPOSTA À SÉTIMA. ─ Nos corpos celestes não há nenhuma potência a ser aperfeiçoada pelo lugar, ou
que tenha por finalidade existir num determinado lugar. Mas, nesses corpos, a potência está para o
lugar, assim como a potência que tem um artífice para as diversas casas do mesmo gênero que poderá
construir; pois, se fizer apenas uma delas, já não podemos dizer que tenha essa potência em vão.
Semelhantemente, qualquer que seja o lugar ocupado por um corpo celeste, a potência que tem a
ocupar um lugar não fica por isso incompleta nem vã.

RESPOSTA À OITAVA. ─ Embora um corpo celeste seja por natureza indiferente a qualquer lugar: que
possa vir a ocupar, contudo, já não é indiferente a esses lugares, quando comparado a outros corpos.
Assim, ocupando um determinado lugar, poderá dispor-se mais nobremente a certas atividades, que
ocupando outro; desse modo, a posição do sol, em relação a nós, lhe é mais nobre durante o dia que
durante a noite. Por onde, é provável que, como a futura renovação do mundo se ordenará totalmente
para o homem, o céu terá, nessa renovação, o lugar mais nobre possível relativamente à nossa
habitação. Ou, segundo outros, o céu repousará no mesmo lugar onde foi feito, do contrário qualquer
revolução do céu ficaria incompleta. Mas, essa explicação não é satisfatória. Porque, havendo no céu
uma revolução que não se perfará senão em trinta e seis mil anos, resultaria que o mundo deveria durar
esse espaço de tempo; e isso não parece provável. Além disso, se assim fosse poderíamos saber quando
acabará o mundo. Pois, os astrólogos deduzem o lugar onde os corpos celestes foram feitos,
considerando o número de anos decorridos desde o princípio do mundo. Do mesmo modo, poder-se-ia
saber com certeza o número de anos depois do qual os astros voltariam à mesma posição. Ora, o tempo
do fim do mundo nos é desconhecido, por disposição divina.

RESPOSTA À NONA. ─ O tempo há de acabar um dia, quando cessar o movimento do céu; nem o último
momento do tempo será o princípio de um tempo futuro. Pois, a definição citada não se aplica ao
momento senão como continuação das partes do tempo, e não enquanto termo do tempo total.

RESPOSTA À DÉCIMA. ─ O movimento do céu não é considerado natural por ser como parte da
natureza, no mesmo sentido em que dizemos ser naturais os princípios da natureza. Nem outrossim por
ter um princípio ativo em a natureza do corpo celeste, pois, é um princípio puramente receptivo; sendo-
lhe o princípio ativo a substância espiritual, como diz o Comentador. Não portanto inconveniente se a
renovação gloriosa do mundo fizer desaparecer esse movimento; pois, essa disparição não acarreta
qualquer alteração em a natureza do corpo celeste.

AS OUTRAS TRÊS OBJEÇÕES concedemos, i. é, as três primeiras, em contrário, porque concluem como
devem. Mas como as outras duas concluem pela cessação natural do movimento do céu, devemos por
isso lhes responder.

DONDE RESPOSTA À PRIMEIRA DELAS. ─ O movimento cessa quando foi atingido o termo por causa do
qual existia, desde que esse termo lhe seja consecutivo e não concomitante. Ora, o termo em vista do
qual, segundo os filósofos, o movimento celeste existe, é concomitante a esse movimento, pois, é a
imitação da divina bondade, pela causalidade que ele exerce sobre os seres terrestres. Donde não se
segue que esse movimento deva cessar naturalmente.

RESPOSTA À SEGUNDA. ─ Embora a imobilidade seja, absolutamente falando, mais nobre que o
movimento, contudo este, quando é um meio para uma participação mais perfeita da divina bondade, é
mais nobre que o repouso que de nenhum modo poderia fazer alcançar essa participação. Por isso a
terra, ínfimo dos elementos, é privada de movimento, embora também Deus, o nobilíssimo dos seres e
causa do movimento universal, não tenha movimento. Donde também o movimento dos corpos
superiores poder ser admitido como naturalmente perpétuo, sem nunca vir a acabar no repouso,
embora seja este o termo do movimento dos corpos inferiores.

## Art. 3 — Se com a renovação do mundo aumentará a claridade dos corpos celestes.
O terceiro discute-se assim. ─ Parece que com a renovação do mundo não aumentará a claridade dos
corpos celestes.

1. ─ Pois, essa renovação se dará, nos corpos terrestres, pela purificação do fogo. Ora, o fogo purificador
não atingirá os corpos celestes. Logo, estes não serão renovados pela suscepção de uma claridade
maior.

2. Demais. ─ Assim como os corpos celestes, pelo seu movimento, são a causa da geração dos corpos
terrestres, assim também pela sua luz. Ora, cessada a geração, cessará o movimento, como se disse.
Logo e semelhantemente, longe de aumentar, a luz dos corpos celestes se extinguirá.

3. Demais ─ Se a renovação do homem acarreta a dos corpos celestes, por força corrompendo-se aquele
também se corromperão estes. Ora, isto não é provável, por ser invariável a substância de tais corpos.
Logo, também a renovação do homem não acarretará a deles.

4. Demais. ─ Se se corrompessem eles, então, necessariamente havia de sê-lo na mesma medida em que
se aperfeiçoariam com a renovação do homem. Ora, a Escritura diz, que no mundo renovado, a luz da
lua será como a do sol. Logo, também no seu estado primitivo, antes do pecado, a lua luzia quanto o sol
atualmente. Logo, sempre que a lua estava acima do horizonte terrestre, produzia o dia, como o faz
agora o sol. O que é manifestamente falso, pelo dito da Escrita, quando refere que a lua foi feita para
presidir à noite. Logo, o pecado do homem não acarretou nenhuma diminuição da luz dos corpos
celestes. Portanto, nem, segundo parece, lh'as aumentará a glorificação do homem.

5. Demais. - A claridade dos corpos celestes, como a outras criaturas, se ordena ao uso do homem. Ora,
depois da ressurreição a claridade do sol não será mais para uso dele, conforme aquilo da Escritura: Tu
não terás mais o sol para luzir de dia nem o resplendor da lua te alumiará. E o Apocalipse: E esta cidade
não há de mister sol nem lua que alumiem nela. Logo, a claridade não lhes aumentará.

6. Demais. ─ Não seria um artífice experimentado o que fizesse instrumentos enormes para executar
uma pequena obra. Ora, o homem é um corpo mínimo em relação aos corpos celestes, cuja grandeza
lhe excedem o tamanho quase incomparavelmente. Ainda mais, o volume total da terra esta para o céu
como o ponto para a esfera, como dizem os astrólogos. Ora, sendo Deus sapientíssimo, parece que não
podia constituir o homem em fim da criação. Portanto, parece que o pecado do homem em nada fez
degenerar o céu; como também este nada aproveita com a glorificação do homem.
Mas, em contrário, a Escritura: A luz da lua será como a luz do sol, e a luz do sol será sete vezes maior.

2. Demais. ─ Todo o mundo será renovado para melhor. Ora, o céu é a parte mais nobre do mundo dos
corpos. Logo, será renovado para melhor. Mas, isto não pode ser senão resplandecendo com maior
claridade. Logo, será mais perfeito e a claridade lhe aumentará.

3. Demais. ─ Toda criatura, que geme e está com, dores de parto, espera a revelação da glória dos filhos
de Deus, na linguagem do Apóstolo. Ora, tais são os corpos celestes, como o explica a Glosa a esse lugar.
Logo, esperam a glória dos santos. Ora, não na esperariam se daí não lhes adviesse nenhuma vantagem.
Portanto, terão a sua clareza, aumentada, que lhes é a principal beleza.

SOLUÇÃO. ─ A renovação do mundo tem por fim tornar Deus como que sensível à vista do homem, pela
prova palpável de um mundo novo. Ora, a criatura conduz a Deus sobretudo pelo seu brilho e
esplendor, que manifestam a sabedoria do seu autor e governador. Donde o dizer a Escritura: Pela
grandeza da formosura e da criatura se poderá visivelmente chegar ao conhecimento do Criador dela.
Mas, a beleza dos corpos celestes está principalmente na sua luz, donde ainda o dito da Escritura: A
refulgência das estrelas é a formosura do céu; o Senhor é que esclarece o mundo desde as alturas. Por
onde, sobretudo na sua claridade é que os corpos celestes serão aperfeiçoados. Ora, o modo e a
extensão da perfeição serão conhecidos só pelo Autor da perfeição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O fogo purificador não causará a forma da renovação,
mas apenas disporá para ela, purgando-a da mácula do pecado e da impureza da mescla, que não
podem contaminar os corpos celestes. Logo, embora estes não devam ser purificados pelo fogo, há de
lhes subsistir o esplendor, mas não o movimento.

RESPOSTA À SEGUNDA. ─ O movimento não implica qualquer perfeição no que é movido, se
considerado em si mesmo, pois é ato do imperfeito; mas pode pertencer à perfeição do corpo,
enquanto é causa de algo. Mas a luz pertence à perfeição do corpo luminoso, mesmo considerado em
sua substância. Por isso, depois que o corpo celeste deixa de ser causa de geração, permanece sua
claridade, mas não seu movimento.

RESPOSTA À TERCEIRA. ─ Aquilo da Escritura ─ será a luz da lua como a luz do sol ─ diz a Glosa: Todas as
cousas feitas para o homem sofreram detrimento com a queda do mesmo, ficando o sol e a lua
diminuídos na sua luz. Diminuição essa que certos entendem como uma diminuição real de luz. Nem
obsta que os corpos celestes sejam por natureza imutáveis, porque essa alteração lhes foi feita pelo
poder divino. ─ Outros porém, e com maior probabilidade, entendem que essa diminuição não foi
realmente um decréscimo de luz, senão só quanto ao uso do homem, que, depois do pecado, já não
colhia da luz dos corpos celestes o mesmo benefício de antes. Pelo que diz também a Escritura: A terra
será maldita na tua obra, ela te produzirá espinhos e abrolhos. É verdade que já antes germinava
espinhos e abrolhos, mas não redundavam em pena do homem. ─ Mas do fato de a luz dos corpos
celestes não terem diminuído na sua essência depois do pecado do homem não se deduz que não
poderão aumentar com a glorificação dele. Pois, o pecado do homem não alterou a constituição do
universo, porque, tanto antes como depois do pecado, vivia uma vida animal, que precisa para se
manter do movimento e da geração das criaturas corpóreas. Mas a glorificação dele mudará o estado de
todas estas criaturas, como dissemos. Logo, não há símil.

RESPOSTA À QUARTA. ─ Essa diminuição, segundo é mais provável, não foi na substância, mas só no
efeito. Donde não se segue que a lua, estando acima do horizonte, iluminasse a terra com a luz do dia,
mas sim, que então o homem tiraria tanta vantagem da luz da lua como agora tira da do sol. Mas depois
da ressurreição, quando a luz da lua realmente aumentar, não haverá mais trevas na superfície da terra,
mas só no centro dela, onde será o inferno. Porque então, como dissemos, a lua luzirá quanto luz
atualmente o sol, e este sete vezes mais que agora; e os corpos dos bem-aventurados sete vezes mais
que o sol, embora nada disto esteja provado por nenhuma autoridade ou razão.

RESPOSTA À QUINTA. ─ De dois modos pode uma cousa servir ao uso do homem. ─ Ou para lhe obviar a
uma necessidade. E então nenhuma criatura servirá mais ao uso do homem porque de Deus terá ele
então satisfeitos todos os seus desejos. Tal é o sentido do lugar citado do Apocalipse, quando diz que
essa cidade não há de mister sol nem lua. ─ Outro uso é o que serve para se atingir uma perfeição maior.
E então o homem usará das outras criaturas; não porém como de meio necessário para conseguir o seu
fim, como nesta vida usa delas.

RESPOSTA À SEXTA. ─ Esse é um raciocínio de Rabbi Moisés, visando refutar, como absolutamente
errônea, a opinião de que o mundo foi feito para o homem. E assim, o que lemos no Velho Testamento
sobre a renovação do mundo, como na autoridade citada de Isaías, isso, diz ele, tem sentido puramente
metafórico. Pois, assim como dizemos que o sol se obscureceu para um indivíduo acabrunhado de
veemente tristeza, a ponto de não saber o que faz ─ modo de exprimir-se habitual na Escritura ─, assim
também ao inverso, dizemos que lhe luz o sol e todo o mundo se lhe renova, quando o seu estado de
tristeza se lhe converte em intensa exultação. ─ Mas isto colide com as autoridades e as exposições dos
Santos Padres. ─ Por isso ao raciocínio aduzido devemos responder o seguinte. Embora os corpos
celestes sobrepujem incomparavelmente o corpo humano, contudo muito mais os sobrepuja a alma
racional, do que eles a ela. Não há pois, nenhum inconveniente em afirmar que os corpos celestes foram
feitos para o homem; não porém como se fosse o fim principal deles esse; porque o fim principal de
todas as causas é Deus.

## Art. 4 — Se os elementos serão renovados pela recepção de alguma claridade.
O quarto discute-se assim. ─ Parece que os elementos não serão renovados pela recepção de
nenhuma claridade.

1. Pois, como a luz é uma qualidade própria dos corpos celestes, assim o calor, o frio e a secura são
qualidades próprias dos elementos.
Logo, assim como o céu será renovado pelo aumento de claridade, assim os elementos o devem ser pelo
aumento das suas qualidades ativas e passivas.

2. Demais. ─ A rarefação e a condensação são qualidades dos elementos, as quais eles não perderão na
renovação do mundo. Ora, a rarefação e a condensação são obstáculos à claridade. Porque um corpo
claro há de ser condensado; donde vem que a rarefação do ar é incompatível com a claridade.
Semelhantemente, não é susceptível de claridade a terra, por causa da sua densidade, que a torna
impermeável à luz. Logo, não poderão os elementos ser renovados por nenhum aumento de claridade.

3. Demais. ─ Sabemos que os condenados serão encarcerados no centro da terra. Ora, estarão imersos
nas trevas, não só interiores, mas também exteriores. Logo, na renovação do mundo a terra não será
dotada de claridade; e pela mesma razão nem os outros elementos.

4. Demais. ─ A multiplicação da claridade nos elementos lhes multiplica também o calor. Se, portanto,
na renovação do mundo, os elementos tiverem maior claridade que a de agora, terão por consequência
também maior calor. E assim terão transformadas as suas qualidades naturais, que as tem numa certa
medida. O que é absurdo.

5. Demais. ─ O bem do universo, consistente na ordem e na harmonia, é mais nobre que qualquer bem
de uma natureza particular. Ora, o fato de uma criatura tornar-se mais perfeita tolhe o bem do universo,
porque lhe perturba a harmonia. Logo, se os corpos elementares, que, segundo o grau da sua natureza,
em que estão colocados no universo, devem ser desprovidos de claridade, vierem a recebê-la, isso
acarretará antes detrimento que acréscimo à perfeição do universo.
Mas, em contrário, o Apocalipse: Eu vi um céu novo e uma terra nova. Ora, o céu será renovado por uma
claridade maior. Logo, também a terra. E semelhantemente os outros, elementos.

2. Demais. ─ Tanto os corpos terrestres como os celestes se destinam ao uso do homem. Ora, a criatura
corpórea será remunerada pelo ministério que prestou ao homem, conforme uma Glosa. Logo, tanto os
elementos como os corpos celestes serão clarificados.

3. Demais. ─ O corpo humano é composto de elementos. Logo, as partes elementares que o compõem,
glorificado o homem serão também glorificadas pela recepção da claridade. Ora, a disposição do todo é
a mesma das partes. Logo, também os elementos serão dotados de claridade.

SOLUÇÃO. ─ Assim está a ordem dos espíritos celestes para os terrestres, i. é, humanos, como a dos
corpos celestes para os terrestres. Logo, tendo sido feita a criatura corporal para a espiritual, que a
governa, hão de as criaturas corpóreas ser dispostas do mesmo modo que as espirituais. Ora, na
consumação última das causas, os espíritos terrestres receberão as propriedades dos celestes, porque
os homens serão como os anjos do céu, na expressão do Evangelho. E isto será pela elevação à máxima
perfeição do que o espírito humano tem de comum com o angélico. Por onde e semelhantemente,
como os corpos terrestres não tem de comum com os celestes senão a sua natureza luminosa e diáfana,
como diz Aristóteles, é mister os corpos terrestres atingirem a sua máxima perfeição luminosa. Por
onde, todos os elementos serão revestidos de uma certa claridade. Não todos igualmente, mas cada um
a seu modo; assim, afirma-se que a terra terá a sua superfície externa transparente como o vidro; a água
será como um cristal; o ar, como o céu, o fogo, como os lampadários celestes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Como dissemos, a renovação do mundo se ordena a
manifestar, de certo modo mesmo sensivelmente aos olhos do homem, os indícios claros da divindade,
por meio dos corpos. Ora, dos nossos sentidos o mais espiritual e subtil é a vista. Por onde, quanto às
qualidades visuais, cujo princípio é a luz, é mister todos os corpos terrestres serem aperfeiçoados em
sumo grau. Quanto às qualidades elementares, elas pertencem ao tato, dos sentidos o mais material; e
a ação excessiva delas sobre os órgãos causa antes dor que prazer. Mas o excesso de luz é deleitável,
pois não contraria o órgão senão pela fraqueza deste, que na ressurreição desaparecerá.

RESPOSTA À SEGUNDA. ─ O ar não será claro a ponto de projetar raios, mas como um corpo diáfano
iluminado. A terra porém, embora seja de natureza opaca por falta de luz, contudo, por virtude divina,
terá revestida da glória da claridade a sua superfície, sem prejuízo da sua condensação.

RESPOSTA À TERCEIRA. ─ No lugar onde se acha o inferno a terra não será glorificada pela claridade;
mas em lugar de tal glória essa parte da terra conterá os espíritos racionais dos homens e dos demônios,
que embora ínfimos por causa da culpa, são contudo, pela dignidade da sua natureza, superiores a
qualquer qualidade corpórea. ─ Ou devemos responder que, mesmo se toda a terra for glorificada,
contudo os réprobos serão imersos nas trevas exteriores; porque o fogo do inferno, que de certo modo
os iluminará, de outro não lhes poderá luzir.

RESPOSTA À QUARTA. ─ Essa claridade esses corpos a terão como a tem os corpos celestes, nos quais
não causa calor. Porque tais corpos serão então inalteráveis, como agora o são os celestes.

RESPOSTA À QUINTA. ─ A perfeição dos elementos não tolherá em nada a ordem do universo. Porque
também as outras partes dele serão aperfeiçoadas, subsistindo pois a mesma harmonia.

## Art. 5 — Se as plantas e os animais hão de subsistir, nessa renovação.
O quinto discute-se assim. ─ Parece que as plantas e os animais subsistirão nessa renovação.

1. ─ Pois, nada deve ser subtraído aos elementos do que lhes constitui a beleza. Ora, diz-se com razão
que os animais e as plantas fazem a beleza dos elementos. Logo, não desaparecerão na renovação do
mundo.

2. Demais. ─ Assim como os elementos serviram ao homem, assim também os animais, as plantas e os
corpos minerais. Ora, por causa do referido ministério os elementos serão glorificados. Logo,
glorificados também serão os animais, as plantas e os corpos minerais.

3. Demais. ─ O universo ficará imperfeito se ficar privado de alguma das suas perfeições. Ora, as várias
espécies de animais, de plantas e de corpos minerais contribuem para a perfeição do universo. Logo,
como não podemos admitir a imperfeição do mundo depois da sua renovação, parece forçoso admitir
que as plantas e os animais subsistirão.

4. Demais. ─ Os animais e as plantas tem mais nobre forma que os elementos. Ora, o mundo, depois da
sua renovação final, terá maior perfeição. Logo, por serem mais nobres, devem subsistir antes os
animais e as plantas, que os elementos.

5. Demais, ─ É inadmissível afirmar-se que uma tendência natural possa ser vã. Ora, os animais e as
plantas tem a tendência natural a se perpetuarem, senão individualmente, ao menos especificamente; e
a isso se lhes ordena a contínua geração, como o diz o Filósofo. Logo, é inadmissível dizer que essas
espécies hão de desaparecer.
Mas, em contrário. ─ Se as plantas e os animais hão de subsistir, ou o serão todos ou certos. Se todos,
então os brutos já mortos terão também de ressurgir, como os homens. O que não pode admitir-se,
porque tendo-se-lhes a forma reduzido a nada, não pode reconstituir-se na sua individualidade. Se não
todos, mas apenas certos, como não há maior razão de subsistir um indivíduo em vez de outro, parece
que nenhum subsistirá perpetuamente. Ora, tudo o que permanecer depois da renovação do mundo
durará sempre, uma vez cessada a geração e a corrupção. Logo, as plantas e os animais de nenhum
modo subsistirão depois da renovação do mundo.

2. Demais. ─ Segundo o Filósofo, as espécies dos animais, das plantas, e de outros seres assim
corruptíveis, não se conservarão perpetuamente senão pela continuidade do movimento celeste. Ora,
então este cessará. Logo, essas espécies não poderão conservar-se perpetuamente.

3. Demais. ─ Desaparecido o fim, necessariamente desaparecerão os meios a ele conducentes. Ora, os
animais e as plantas foram feitos para sustento da vida animal do homem. Por isso diz a Escritura: Eu
vos entreguei todas estas cousas como as viçosas hortaliças. Ora, depois da renovação, já o homem não
terá a vida animal. Logo, não deverão subsistir nem as plantas e nem os animais.

SOLUÇÃO. ─ Como a renovação do mundo se fará em vista do homem, há de conformar-se com a
renovação deste. Ora, o homem renovado passará do estado de corrupção para o de incorrupção e
perpétuo repouso, conforme aquilo do Apóstolo: Importa que este corpo corruptível se revista da
incorruptibilidade, e que este corpo mortal se revista da imortalidade. Por onde, o mundo será
totalmente renovado, de modo que, desaparecida toda corrupção, permaneça em repouso perpétuo.
Portanto, nada poderá participar dessa renovação senão o que poderá se tornar incorruptível. Ora, tais
são os corpos celestes, os elementos e os homens. Os corpos celestes são por natureza incorruptíveis,
tanto no seu todo como nas suas partes. Quanto aos elementos, são corruptíveis nas partes, mas
incorruptíveis no todo. O homem é sujeito à corrupção, tanto nas suas partes como no todo; mas isso só
em relação à matéria, não quanto à forma, i. é, a alma racional, que depois da morte permanece
incorrupta. Os brutos, enfim, as plantas e os minerais e todos os corpos mistos são corruptíveis no todo
e nas partes, tanto em relação à matéria, que perde a forma, quanto em relação à forma que não
permanece atual; e assim de nenhum modo podem ser incorruptíveis. Portanto, na futura renovação do
mundo não subsistirão, senão só os seres que foram mencionados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Diz-se que os animais e as plantas servem de embelezar
os elementos, enquanto que as virtudes ativas e passivas gerais, que os elementos encerram se
condensam em ações especiais. Por isso os animais e as plantas concorrem para a beleza deles no seu
estado de atividade e de passividade. Ora, esse estado dos elementos desaparecerá. Donde o não ser
necessário subsistirem nem os animais nem as plantas.

RESPOSTA À SEGUNDA. ─ Nem os animais, nem as plantas nem quaisquer outros corpos, não tendo
livre arbítrio, nada podem merecer por servirem ao homem. Assim, quando se diz que certos, corpos
serão remunerados, é no sentido que o homem mereceu fossem renovados os susceptíveis de fazerem
parte da nova ordem. Ora, nem as plantas nem os animais podem entrar nessa renovação do mundo
corruptível. Por isso o homem não lhes podia merecer a renovação; pois, ninguém pode merecer para
outrem o de que este não é susceptível, como não é possível nessas condições ninguém merecer para si
mesmo. Por onde, mesmo dado que os brutos merecessem; por terem servido ao homem, não devem
por isso ser renovados.

RESPOSTA À TERCEIRA. ─ Assim como a perfeição do homem é susceptível de muitas modalidades, pois
há a da natureza criada e da natureza glorificada, assim também a perfeição do universo é dupla ─ uma
própria ao estado de mutabilidade deste mundo; outra própria do mundo futuro renovado. Ora, as
plantas e os animais pertencem à perfeição do mundo na sua mutabilidade presente; mas não ao estado
da renovação futura, para o qual não são ordenados.

RESPOSTA À QUARTA. ─ Embora os animais e as plantas sejam, quanto a outros aspectos, mais nobres
que os elementos, contudo, por se ordenarem à incorrupção, mais nobres são os elementos, como do
sobredito se colhe.

RESPOSTA À QUINTA. ─ A tendência natural a perpetuarem-se, ínsita nos animais e nas plantas, deve
ser considerada na sua dependência do movimento do céu, de modo que durem enquanto durar esse
movimento. Pois, não pode um efeito ter a tendência de subsistir mais do que a sua causa. Por onde, se
cessado o movimento do primeiro móvel, as plantas e os animais não continuarem a subsistir nas suas
espécies, daí não se segue que fiquem frustradas as suas tendências naturais.