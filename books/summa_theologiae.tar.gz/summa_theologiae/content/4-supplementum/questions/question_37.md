# Questão 37: Da distinção das ordens, das suas funções e do caráter que imprimem.
Em seguida devemos tratar da distinção das ordens, das suas funções e do caráter que imprimem.
Sobre o que discutem-se cinco artigos:

## Art. 1 — Se se devem distinguir várias ordens.
O primeiro discute-se assim. ─ Parece que não se devem distinguir várias ordens.

1. ─ Pois, quanto mais nobre é uma virtude tanto menos multiplicada é. Ora, o sacramento da ordem é
mais nobre que os outros, porque constitui os que recebem em grau superior aos demais. Logo, como
os outros sacramentos não se dividem em vários, que tenham uma denominação comum, também o da
ordem não deve ser dividido em vários.

2. Demais. ─ Se se dividisse a ordem em várias, esta divisão seria ou a de um todo em suas partes
integrantes ou em partes subjetivas. Ora, não em partes integrantes, porque então não receberiam elas
a denominação do todo. Logo, será a divisão em partes subjetivas. Ora, as partes subjetivas recebem a
sua denominação genérica no plural, tanto a do gênero próximo como a do remoto; assim, dizemos do
homem e do asno, que são duas espécies de animais e de corpos animados. Logo, sendo o sacramento
um como gênero, de que as ordens são as espécies, o sacerdócio e o diaconato, sendo ordens
diferentes, são também sacramentos diferentes.

3. Demais. ─ Segundo o Filósofo, o regime em que um só governa é mais nobre que a aristocracia, na
qual as várias funções públicas são desempenhadas por diversos. Ora, o governo da Igreja deve ser o
mais nobre de todos. Logo, não devia haver nela distinção de ordens relativamente às diversas
atividades delas, mas o poder deveria residir totalmente em um só sujeito. E assim, deveria ser a ordem
uma só.
Mas, em contrário. ─ A Igreja é o corpo místico de Cristo, semelhante a um corpo natural, segundo o
Apóstolo. Ora, os vários membros de um corpo natural tem cada qual a sua função. Logo, na Igreja deve
haver diversas ordens.

2. Demais. ─ O Ministério do Testamento Novo é mais nobre que o do Velho, como diz o Apóstolo. Ora,
no Testamento Velho, não só os sacerdotes, mas também os levitas, seus ministros, eram santificados.
Logo, também não somente os sacerdotes do Testamento Novo, mas também os seus ministros, devem
ser consagrados pelo sacramento da ordem.

SOLUÇÃO. ─ A variedade das ordens foi introduzida na Igreja por três razões. ─ Primeiro, para mostrar a
sabedoria de Deus, que esplende sobretudo na ordenada variedade dos seres, tanto na ordem natural
como na espiritual. Eis porque o texto sagrado refere, que a rainha de Sabá, vendo a ordem reinante
entre os oficiais de Salomão, estava toda transportada, não cabendo em si de admiração pela sua
sabedoria. ─ Segundo, para obviar à fraqueza humana; porque uma só ordem não poderia exercer sem
grande gravame, tudo o concernente aos divinos mistérios. Por isso, são várias as ordens,
correspondentes a ofícios diversos. O que é corroborado pelo fato de ter o Senhor dado como
coadjutores a Moisés setenta anciãos os do povo. ─ Terceiro, para facilitar aos homens os meios do
aperfeiçoamento espiritual, sendo vários os que exercem funções diversas de modo a serem todos
cooperadores de Deus, não havendo ministério mais divino que esse, na expressão de Dionísio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os outros sacramentos são conferidos para deles
colherem certos efeitos; ao passo que este nos é ministrado principalmente em vista de praticarmos
certos atos. Por onde, o sacramento da ordem há de dividir-se conforme a diversidade dos atos, assim
como pelos atos se diversificam as potências.

RESPOSTA À SEGUNDA. ─ A divisão, no caso vertente, não é a de um todo nas suas partes integrantes,
nem a de um todo universal, mas a de um todo potencial. E da natureza deste é estar na sua essência
total em uma das partes, tendo as outras uma certa participação dela. Ora, o mesmo se dá aqui. Pois, a
plenitude total deste sacramento tem-na uma das ordens ─ o sacerdócio; as outras são participações
dele. Tal o significado das palavras do Senhor ─ Tirarei do teu espírito e lh'o darei a eles para que
sustentem comigo a carga do povo. Por onde, todas as ordens são um só sacramento.

RESPOSTA À TERCEIRA. ─ Num reino, embora o poder na sua plenitude total resida no rei, não ficam
porém excluídos os poderes dos ministros, que são umas participações do poder real. O mesmo se dá
com a ordem. Ao passo que na aristocracia, a plenitude do poder não reside em ninguém, mas em
todos.

## Art. 2 — Se há sete ordens.
O segundo discute-se assim. ─ Parece que não são sete as ordens.

1. ─ Pois, as ordens da Igreja se ordenam a atos hierárquicos. Ora, os atos hierárquicos são só três ─
purificar, iluminar e aperfeiçoar ─ correlatos às três ordens que distingue Dionísio. Logo, as ordens não
são sete.

2. Demais. ─ Todos os sacramentos tem a sua eficácia e autoridade, da instituição de Cristo, ou ao
menos, dos seus Apóstolos. Ora, na doutrina de Cristo e dos Apóstolos não se faz menção senão dos
presbíteros e dos diáconos. Logo, parece que, não há outras, ordens além dessas.

3. Demais. ─ Pelo sacramento da ordem é o ordenado constituído dispensador dos outros sacramentos,
Ora, os outros sacramentos são seis. Logo só seis devem ser as ordens.
Mas, em contrário. ─ Parece que devem ser mais de sete. Pois, quanto mais nobre é uma virtude tanto
menos se multiplica. Ora, o poder hierárquico os anjos o tem de maneira mais digna que nós, como diz
Dionísio. Logo, sendo nove as ordens da hierarquia angélica, outras tantas ou mais deveriam ser as da
Igreja.

2. Demais. ─ A profecia dos salmos é mais nobre que todas as outras profecias. Ora, uma ordem ─ a dos
leitores, é a incumbida de ler na igreja as profecias. Logo, devia haver outra ordem incumbida de ler os
salmos, sobretudo que nas Decretais é colocada em segundo lugar, entre as ordens, depois do ostiário.

SOLUÇÃO. ─ Certos buscam o fundamento do número das diversas ordens nas graças gratuitas, às quais
se refere o Apóstolo. Assim, dizem que a palavra de sabedoria compete ao bispo, por ser o ordenador
dos outros, o que concerne à sabedoria. A palavra de ciência, ao sacerdote, que deve ter a chave da
ciência; a fé, ao diácono, que prega o Evangelho; a operação de milagres, ao subdiácono, que se dá às
obras de perfeição, pelo voto de continência; a interpretação das palavras, ao acólito, significa da pelo
archote que conduz; a graça de curar as doenças, ao exorcista; a variedade de línguas, ao salmista; a
profecia, ao leitor; o discernimento dos espíritos, ao ostiário, que exclui uns e admite outros. ─ Mas
nada disto é exato. Porque as graças gratuitas não são todas, como as ordens, dadas à mesma pessoa.
Assim, como diz o Apóstolo, há divisões de graças. E por isso enumeram-se entre as ordens o
episcopado e a função de salmista, apesar de não o serem.
Por isso outros procuraram fundamentá-las comparando-as com a hierarquia celeste, nas quais as
ordens se distinguem correlatamente à purificação, a iluminação e a perfeição. Assim, dizem que o
ostiário purifica exteriormente, segregando os bons dos maus, mesmo corporalmente; o acólito, por seu
lado, opera a purificação interna, significando o círio, que conduz, a dissipação das trevas interiores; e
de ambos os modos o exorcista, porque o diabo, que expulsa, perturba de ambos os modos. Quanto à
iluminação, feita pela doutrina, se a doutrina é profética compete aos leitores; se apostólica, aos
subdiáconos: se evangélica, aos diáconos, Quanto à perfeição comuns, que é a da penitência, do
batismo e de sacramentos tais, incumbe ao sacerdote; a perfeição por excelência incumbe ao bispo,
como a consagração dos sacramentos e das virgens; e a excelentíssima, ao sumo Pontífice, em quem
reside a plenitude da autoridade. ─ Mas nada disto é admissível. Quer por as ordens da hierarquia
celeste não se distinguirem pelas preditas ações hierárquicas, por qualquer delas convir à qualquer das
ordens. Quer porque, segundo Dionísio, só aos bispos é próprio aperfeiçoar; iluminar convindo aos
sacerdotes e purificar, a todos os ministros.
Por isso, outros apropriam as ordens aos sete dons, de modo que ao sacerdócio responde o dom da
sabedoria, que nos nutre com o pão da vida e da inteligência, assim como o sacerdote nos fortalece com
o pão celeste; a temor se apropria ao ostiário, que nos separa dos maus, e assim as ordens intermédias
respondem aos dons médios. ─ Mas, de novo, nada disto é exato: porque qualquer das ordens nos
confere os sete dons do Espírito Santo.
Por isso e diferentemente devemos responder que o sacramento da ordem tem por fim direto o da
Eucaristia ─ o sacramento dos sacramentos, na expressão de Dionísio. Pois assim como o templo, o altar,
os vasos e as vestes, assim também os ministérios, ordenados à Eucaristia, devem ser consagrados: e
esta consagração é o sacramento da ordem. Por onde, as ordens se diversificam pela sua relação com a
Eucaristia.
Porque o poder da ordem ou é para consagrar a Eucaristia, ou para algum ministério cujo fim é o
sacramento da Eucaristia. No primeiro caso a ordem é a dos sacerdotes. Por isso, quando se ordenam,
recebem o cálice com o vinho e a patena com o pão, recebendo assim o poder de consagrar o corpo e o
sangue de Cristo.
Quanto à cooperação dos ministros, tem por fim ou o sacramento mesmo ou os que o recebem.
No primeiro caso, de três modos. ─ Primeiro, vem o ministério pelo qual o ministro coopera com o
sacerdote para a dispensa do sacramento, mas não para a consagração que só o sacerdote faz. E esse é
o ofício do diácono. Por isso diz o Mestre das Sentenças, que ao diácono pertence servir aos sacerdotes
em tudo o referente aos sacramentos de Cristo. Por onde, eles mesmos são os dispensadores do sangue
de Cristo. ─ Depois vem o ministério ordenado a preparar a matéria do sacramento nos vasos próprios
dele. E esse é o ofício do subdiácono. Por isso diz o Mestre, que levam os vasos do corpo e do sangue do
Senhor, e colocam as oblações no altar. Eis porque recebem o cálice das mãos do bispo, quando se
ordenam, mas vazio. ─ Vem enfim o ministério ordenado a apresentar a matéria do sacramento. E isso
compete ao acólito. Pois, este, como diz o Mestre, enche as galhetas de vinho e de água. Por isso recebe
as galhetas vazias.
Quanto ao ministério ordenado à preparação dos que devem receber o sacramento, não pode ele
exercer-se senão sobre os impuros, porque os puros já são aptos para recebê-las. Ora, os impuros são
de três gêneros, segundo Dionísio. ─ Uns, são os de todo infiéis, que não querem crer. E esses devem ser
completamente afastados, mesmo de ver as coisas sagradas, e do grêmio dos fiéis. Tal é a função do
ostiário. ─ Outros são os que querem crer mas ainda não estão instruídos e são os catecúmenos. Instruí-
las é o ofício dos leitores. Por isso os primeiros rudimentos da
doutrina da fé ─ o Testamento Velho, são eles os Que devem ler. ─ Outros enfim são os energúmenos,
os fiéis instruídos, mas sob ação dos impedimentos que lhes impõe o poder dos demônios. O cuidar-se
com eles é ofício dos exorcistas.
Assim se compreende a razão, o número e os graus das ordens.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Dionísio se refere às ordens, não enquanto sacramentos,
mas enquanto destinadas às funções hierárquicas. Por isso distingue três ordens correlatas às três
funções. Dessas ordens a primeira, a do bispo, abrange as três funções referidas; a segunda, a do
sacerdote, duas delas; a terceira, a do diácono, chamado ministro, só exerce uma ─ a de purificar,
compreendendo em si todas as ordens inferiores. ─ Mas as ordens, enquanto sacramentos, devem ser
apreciadas, na sua relação com o máximo dos sacramentos. Daí o ser esse o fundamento do número
delas.

RESPOSTA À SEGUNDA. ─ Na Igreja primitiva, por causa do pequeno número dos ministros, todos os
ministérios inferiores eram cometidos aos diáconos. Assim o lemos em Dionísio: Dos ministros, uns se
postam junto às portas fechadas do templo; outros exercem alguma junção da sua ordem; outros
apresentam aos sacerdotes no altar o pão sagrado e o cálice da bênção. Contudo, todos os poderes
referidos estavam implicitamente incluídos, no do diácono. Mas depois, ampliado o culto divino,
também a Igreja confiou explicitamente a diversos o que estava implicitamente incluído numa só
ordem. Por isso o Mestre diz que a Igreja teve necessidade de instituir outras ordens.

RESPOSTA À TERCEIRA. - As ordens se destinam principalmente ao sacramento da Eucaristia; e aos
outros, por consequência; porque também os outros sacramentos derivam do conteúdo deste. Por
onde, não é necessário sejam as ordens divididas pela sua relação com os sacramentos.

RESPOSTA À QUARTA. - Os anjos diferem especificamente; por isso podem participar diferentemente
uns dos outros dos bens divinos. Donde o distinguirmos diversas hierarquias deles. Mas dos homens só
há uma hierarquia, por causa do modo único pelo qual podem receber os dons divinos consequente à
espécie humana, a saber, pelas semelhanças das coisas sensíveis. Por isso, as ordens angélicas não se
podem dividir por comparação com nenhum sacramento, como se dá conosco, mas só por comparação
com as funções hierárquicas, que qualquer ordem deles exerce sobre as inferiores. E assim as nossas
ordens correspondem às deles: pois, em a nossa hierarquia são três as ordens, distintas pelas suas
relações com as três funções hierárquicas, do mesmo modo que cada hierarquia angélica tem a sua
função hierárquica própria.

RESPOSTA À QUINTA. ─ A função do salmista não é uma ordem, mas um ofício anexo à ordem; pois, por
serem os Salmos cantados, por isso se chama ao salmista cantor. Mas cantor não é nome especial de
nenhuma ordem, que por ser cantar função de todo o coro, quer por não ter nenhuma relação especial
com o sacramento da Eucaristia, quer por ser um ofício às vezes enumerado entre as ordens
consideradas num sentido lato.

## Art. 3 — Se as ordens devem ser divididas em sacras e não-sacras.
O terceiro discute-se assim. ─ Parece que as ordens não devem ser divididas em sacras e não sacras.

1. ─ Pois, todas as ordens são sacramentos. Ora, todos os sacramentos são sagrados. Logo, sacras todas
as ordens o são.

2. Demais. ─ As ordens da Igreja só destinam aos ofícios divinos. Ora, todos eles são sagrados. Logo,
todas as ordens são sacras.
Mas, em contrário, as ordens sacras impedem contrair matrimônio e dirimem o já contraído. Ora, quatro
ordens inferiores não impedem de o contrair nem dirimem o já contraído. Logo, não são ordens sacras.

SOLUÇÃO. ─ Uma ordem pode ser considerada sagrada de dois modos. ─ Primeiro, em si mesma; e
então toda ordem é sagrada, por ser sacramento. ─ Depois, em razão da matéria sobre a qual recai a
função. E assim sagrada se considera toda ordem cuja função recai sobre matéria consagrada. Por onde,
só há três ordens sacras: a do sacerdote e a do diácono ─ cujos atos se exercem sobre o corpo de Cristo
e o sangue consagrado; e a do subdiácono, cuja ação se exerce sobre os vasos sagrados. Por isso se lhes
impõe a continência, a fim de serem puros os que tratam coisas sagradas.
Donde se deduz a resposta às objeções.

## Art. 4 — Se as funções das ordens estão bem determinadas pelo Mestre das Sentenças.
O quarto discute-se assim. ─ Parece que as funções das ordens não estão bem determinadas pelo
Mestre das Sentenças.

1. ─ Pois, a absolvição nos prepara a receber o corpo de Cristo. Ora, preparar os que devem receber o
sacramento é função das ordens inferiores. Logo, a absolvição dos pecados não devia ser enumerada
entre as funções do sacerdote.

2. Demais. ─ Pelo batismo imediatamente nos tornamos semelhantes a Deus, porque recebemos o
caráter que obra essa semelhança. Ora, orar e oferecer oblações são atos ordenados imediatamente a
Deus. Logo, todo batizado, e não só o sacerdote, pode praticar tais atos.

3. Demais. ─ Ordens diversas tem funções diversas. Ora, por as oferendas no altar e ler a epístola é
função do subdiácono. Também os subdiáconos apresentam a cruz ao Papa. Logo não se devem
considerar essas funções do diácono.

4. Demais. ─ Tanto o Testamento Velho como o Novo encerram a mesma verdade. Ora, ler o
Testamento Velho é função dos leitores. Logo e pela mesma razão devem ler o Novo, não sendo pois,
essa, função dos diáconos.

5. Demais. ─ Os Apóstolos nada mais pregaram senão o Evangelho de Cristo, como se vê na Escritura.
Ora, publicar a doutrina dos Apóstolos é função dos subdiáconos. Logo, também a doutrina do
Evangelho.

6. Demais. ─ Segundo Dionísio, funções de uma ordem superior não podem caber à inferior. Ora, lidar
com as galhetas é função dos subdiáconos. Logo, não deve ser atribuída aos acólitos.

7. Demais. Os atos espirituais devem ter preeminência sobre os materiais. Ora, o acólito só exerce uma
função material. Logo, o exorcista não pode exercer a função espiritual de expulsar os demônios, por ser
inferior.

8. Demais. ─ Funções que convêm entre si devem ser postas juntas. Ora, ler o Velho Testamento deve
ter conveniência máxima com a leitura do Novo, que cabe aos ministros superiores. Logo, a função de
ler o Testamento Velho não deve ser atribuída ao leitor, mas antes, ao acólito, principalmente porque o
lume corporal que o acólito apresenta, significa o lume da doutrina espiritual.

9. Demais. ─ Toda função de ordem espiritual implica uma virtude espiritual que, mais que os outros,
desempenham os ordenados. Ora, a função que tem o ostiário de abrir e fechar as portas também
outros a exercem. Logo, não deve ser essa uma função peculiar a eles.

SOLUÇÃO. ─ Como a consagração conferida pelo sacramento da ordem se destina ao sacramento da
Eucaristia, conforme dissemos, é ato principal de cada ordem aquele pelo qual ela mais proximamente
tem por fim o sacramento da Eucaristia. Assim sendo, uma ordem é mais eminente que outra, na
medida em que uma função mais proximamente tem por fim o referido sacramento, como ao
sacramento da Eucaristia, quase digníssimo se ordenam muitas outras funções, por isso nenhum
inconveniente há em abranger uma ordem muitas funções, além da sua principal; e tanto mais quanto
mais nobre for, por que um poder, quanto mais superior, maior raio de ação tem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Dupla é a preparação que devem ter os que recebem um
sacramento. Uma remota, e essa é dada pelos ministros. Outra, próxima, que os torna logo aptos a
receberem os sacramentos. E esta é função dos sacerdotes. Assim também na ordem natural o mesmo
agente dá à matéria a última disposição para receber a forma e a confere. E como estamos em
disposição próxima para receber a Eucaristia quando já nos purificamos dos pecados, por isso é o
sacerdote o ministro próprio de todos os sacramentos instituídos principalmente para purificar dos
pecados ─ o batismo, a penitência e a extrema unção.

RESPOSTA À SEGUNDA. ─ Um ato pode ordenar-se imediatamente para Deus de dois modos. ─
Primeiro, por parte só de uma pessoa; assim fazer orações e votos em particular, e outros. E tal ato
qualquer batizado pode praticá-lo. ─ De outro modo, por parte de toda a Igreja. E então só os atos
praticados pelo sacerdote se ordenam imediatamente para Deus; porque só ele pode representar a
pessoa de toda a Igreja, que consagra a Eucaristia, sacramento da Igreja universal.

RESPOSTA À TERCEIRA. ─ As oferendas feitas pelo povo o sacerdote é quem as oferece. Por isso é
necessário um duplo ministério para a oferta dessas oblações. Um por parte do povo; e esse é próprio
do subdiácono, que recebe do povo as oblações e as coloca no altar ou oferece ao diácono. Outra é o
ministério do sacerdócio, próprio do diácono, que apresenta as oblações diretamente ao sacerdote. E
nisso consiste a função principal de cada ordem. Donde vem que a ordem do diácono é superior.
Quanto à leitura da epístola, não é ofício do diácono, senão enquanto as funções das ordens inferiores
se atribuem às superiores. O mesmo se dá com a função de levar a cruz. Isso segundo o costume de
certas Igrejas, porque não há inconveniente haver costumes diversos relativos a atos secundários.

RESPOSTA À QUARTA. ─ A doutrina é a preparação remota para a recepção dos sacramentos; por isso, a
transmissão da doutrina é confiada aos ministros. Ora, a doutrina do Velho Testamento é ainda mais
remota que a do Novo; porque não instrui senão figuradamente sobre o sacramento da ordem. Por isso,
ensinar o Novo Testamento é função dos ministros superiores; ao passo que ensinar o Antigo pertence
aos inferiores. Além disso, a doutrina do Novo Testamento, que o nosso Senhor mesmo ensinou, é mais
perfeita que a sua divulgação por meio dos Apóstolos. Por isso ler o Evangelho é função confiada aos
diáconos; e a epístola, aos subdiáconos.
Donde se deduz a resposta à quinta objeção.

RESPOSTA À SEXTA. - Os acólitos lidam só com as galhetas nenhuma ação tendo sobre o conteúdo
delas. Mas o subdiácono tem ação sobre esse conteúdo, porque depõe a água e o vinho no cálice e além
disso derrama a água nas mãos do sacerdote. Quanto ao diácono e ao subdiácono, tem ação só sobre o
cálice, não sobre o conteúdo dele; ao passo que o sacerdote a tem sobre esse conteúdo. Por isso, assim
como o subdiácono, quando se ordena, recebe o cálice vazio, e o sacerdote o recebe cheio, assim o
acólito recebe as galhetas vazias, e cheias o subdiácono. De modo que há uma certa conexão entre as
ordens.

RESPOSTA À SÉTIMA. ─ As funções materiais do acólito se ordenam mais proximamente à das ordens
sacras, que as dos exorcistas, embora seja esta de certo modo espiritual. Porque os acólitos exercem o
seu ministério sobre os vasos que contêm a matéria do sacramento, quanto ao vinho, que, por causa da
sua umidade, necessita um vaso que o contenha. Por isso, dentre todas as ordens menores a dos
acólitos é a superior.

RESPOSTA À OITAVA. ─ A função dos acólitos mais se aproxima das funções principais dos ministros
superiores, que as funções das outras ordens, como é fácil de ver. E semelhantemente, quanto aos atos
secundários, cujo objeto é preparar o povo por meio da instrução. Porque o acólito, portador do círio,
simboliza visivelmente a doutrina do Novo Testamento; ao passo que o leitor, lendo, as outras figuras
do Velho Testamento. Por isso, o acólito é superior. O mesmo se passa com o exorcista. Pois, assim
como está a função do leitor para a função secundária do diácono e do subdiácono, assim a função do
exorcista para a função secundária do sacerdote ─ a de ligar e absolver, que nos livra totalmente da
escravidão do demônio. ─ E nisto se manifesta a regular progressão das ordens. Pois, com o ato principal
do sacerdote - consagrar o corpo de Cristo ─ cooperam as três ordens superiores. E com o seu ato
secundário, de absolver e ligar cooperam juntamente as superiores e as inferiores.

RESPOSTA À NONA. ─ Alguns dizem que quando recebe a ordem, ao ostiário é conferido um certo poder
divino, de impedir a outrem de entrar no templo, como o teve Cristo quando dele expulsou os ladrões.
Mas isto mais é obra da graça gratuita, que da graça do sacramento. Por onde, devemos pensar que ele
recebe o poder de assim agir como no exercício de uma função própria; embora também outros possam
fazer o mesmo, mas não por ofício. O mesmo se dá com todas as funções das ordens menores, que
podem ser licitamente exercidas por outros, não porém como função própria deles. Assim, também
numa casa não consagrada pode-se dizer missa, embora a igreja seja consagrada para nela celebrar-se.

## Art. 5 — Se ao sacerdote se lhe imprime o caráter quando lhe é apresentado o cálice.
O quinto discute-se assim. ─ Parece que ao sacerdote não se lhe imprime o caráter quando lhe é
apresentado o cálice.

1. - Pois, a consagração do sacerdote é como a confirmação, acompanhada de uma unção. Ora, na
confirmação, é a unção mesma que imprime caráter. Logo, é o sacerdócio mesmo o que imprime caráter
e não o cálice apresentado.

2. Demais. ─ O Senhor deu aos discípulos o poder sacerdotal quando disse: Recebei o Espírito Santo;
aqueles a quem perdoardes os pecados, etc. Ora, o Espírito Santo é conferido pela imposição das mãos.
Logo, a imposição das mãos por si mesma imprime o caráter da ordem.

3. Demais. ─ Assim como são consagrados os ministros, assim também as vestes deles. Ora, as vestes só
a bênção, por si, as consagra. Logo, a consagração do bispo por si só, torna o sacerdote consagrado.

4. Demais. ─ Assim como ao sacerdote é apresentado o cálice, assim também as vestes sacerdotais.
Logo, se a apresentação do cálice lhe imprime o caráter, pela mesma razão a da casula. E assim o
sacerdote receberia dois caracteres; o que é falso.

5. Demais. ─ A ordem do diácono mais se aproxima da do sacerdote, que a do subdiácono. Ora, se a
simples apresentação do cálice imprimisse o caráter sacerdotal, o subdiácono estaria mais próximo do
sacerdote que o diácono, porque aquele recebe o caráter pela só apresentação do cálice, mas não o
diácono. Logo, a apresentação do cálice só por si não imprime o caráter sacerdotal.

6. Demais. ─ A ordem dos acólitos exerce uma função mais próxima da do sacerdote, por se ocupar com
as galhetas, do que por levar o círio. Mas o caráter mais imprime o acólito quando os acólitos recebem o
círio, que quando recebem as galhetas; pois, o nome de acólito, significa ─ o que leva um círio. Logo, os
sacerdotes não se lhes imprime o caráter quando recebem o cálice.
Mas, em contrário. ─ O ato principal da ordem sacerdotal é consagrar o corpo de Cristo. Ora, esse poder
lhe é conferido quando lhe apresentam o cálice. Logo, é então que se lhe imprime o caráter.

SOLUÇÃO. ─ Como dissemos, o mesmo agente que infunde uma forma também dá à matéria a
preparação próxima para receber a forma. Por isso o bispo, ao conferir a ordem, faz duas coisas ─
prepara os ordenandos para a receberem e confere o poder da ordem.
Prepara-os, instruindo-se por ofício próprio, e influindo sobre eles a fim de se tornarem aptos para
receber. E essa preparação em três coisas consiste: na bênção, na imposição das mãos e na unção. ─
Pela bênção, ficam ligados ao serviço divino; e por isso ela é dada a todos. ─ A imposição das mãos dá-
lhes a plenitude da graça, que os torna aptos a elevados ofícios. Por isso, só os diáconos e os sacerdotes-
recebem imposição de mãos, por lhes competir dispensar os sacramentos, embora estes o tenham
como função principal e os outros, como ministros. ─ Além disso, a unção que recebem, os consagra
para o trato do sacramento. Razão pela qual só os sacerdotes recebem a unção, eles que tocam com as
mãos o corpo de Cristo; por isso também é ungido o cálice, que contém o sangue; e a patena, que
contém o corpo.
Quanto à colação do poder, é a do que lhes concerne a função própria que exercem. E como a função
principal do sacerdote é consagrar o corpo e o sangue de Cristo, por isso quando lhe é oferecido o
cálice, pela forma determinada das palavras se lhe imprime o caráter sacerdotal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A confirmação não confere o poder de obrar sobre a
matéria exterior. Por isso não imprime caráter mediante a apresentação de um objeto material, mas só
pela imposição das mãos e pela unção. Diferente é o que se passa com a ordem sacerdotal. Logo, o
símile não colhe.

RESPOSTA À SEGUNDA. ─ O Senhor, quando na ceia disse antes da paixão ─ Tomai e comei, deu aos
discípulos o poder sacerdotal, no seu ato principal. Por isso acrescentou: Fazei isto em memória de mim.
Mas depois da ressurreição deu-lhes função secundária da ordem sacerdotal, que é ligar e absolver.

RESPOSTA À TERCEIRA. ─ As vestes não precisam outra consagração senão a que as destina ao culto
divino. Por isso lhes basta, como consagração, a bênção. Outra coisa porém é o que se dá com os
ordenados, conforme dissemos.

RESPOSTA À QUARTA. ─ As vestes sacerdotais não significam o poder dado ao sacerdote, mas a
idoneidade que deles se requer para o desempenho das suas funções. Por isso, nem ao sacerdote nem a
nenhum outro se lhe imprime caráter por se revestirem de qualquer veste.

RESPOSTA À QUINTA. ─ O poder do diácono é médio entre o do subdiácono e o do sacerdote. Pois, o
sacerdote tem poder direto sobre o corpo o subdiácono, apenas sobre os vasos; o diácono sobre o
corpo de Cristo contido no vaso. Por isso não pode ele tocar no corpo de Cristo, mas conduzi-la na
patena, e distribuir o sangue com o cálice. E é porque o ato principal das suas funções não podia
exprimir-se nem pela apresentação só do vaso, nem pela apresentação da matéria. Mas apenas o ato
secundário das suas funções é expresso quando se lhe dá o livro dos Evangelhos; e nessa função se
incluem as outras. Por isso a só apresentação dos livros já lhe imprime caráter.

RESPOSTA À SEXTA. ─ A função mais principal do acólito é, antes, a de servir as galhetas que o levar o
círio. Embora tire a denominação da sua função secundária, que é mais conhecida e mais própria dele.
Por isso o caráter se lhe imprime ao acólito quando se lhe dão as galhetas, em virtude das palavras
pronunciadas pelo bispo.
