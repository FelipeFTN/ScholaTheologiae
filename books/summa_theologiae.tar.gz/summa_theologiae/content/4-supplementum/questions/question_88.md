# Questão 88: Do tempo e do lugar do juízo universal.
Em seguida devemos tratar do tempo e do lugar do juízo universal.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se haverá um juízo universal.
O primeiro discute-se assim. ─ Parece que não haverá nenhum juízo universal.

1. ─ Pois, como diz a Escritura, não julgará Deus duas vezes a mesma cousa. Ora, presentemente Deus
julga as obras de cada um; pois, depois da morte atribui a cada qual penas ou recompensas, conforme o
mérito; e também premeia ou pune a certos nesta vida, pelas suas boas ou más obras. Logo, parece que
não haverá outro juízo.

2. Demais. ─ Nenhum juízo é precedido pela execução da sentença. Ora, a sentença do juízo divino
discerne entre os que devem alcançar o Reino ou ser dele excluídos, como lemos no Evangelho. Logo,
como depois da morte já uns alcançaram o reino eterno e outros foram excluídos dele para sempre,
parece que não haverá outro juízo.

3. Demais. ─ É necessário levar uma questão a juízo quando não se sabe como decidi-la. Ora, antes do
fim do mundo, cada condenado já teve proferida a sua condenação, e a cada santo a sua beatitude.
Logo, parece não haver necessidade de nenhum outro juízo.
Mas, em contrário. ─ O Evangelho diz: Os habitantes de Nínive se levantarão no dia do juízo com esta
geração e a condenarão. Logo, depois da ressurreição haverá o juízo.

2. Demais. ─ O Evangelho diz: Os que obraram bem sairão para a ressurreição da vida; mas os que
obraram mal sairão ressuscitados para a condenação. Logo, parece que depois da ressurreição haverá
ainda o juízo.

SOLUÇÃO. - Assim como a operação concerne ao princípio que dá às cousas o ser, assim o juízo
concerne à condução delas ao seu termo final. Ora, há duas espécies de obras de Deus. Uma pela qual
deu, no princípio, o ser as cousas, instituindo a natureza e determinando tudo o necessário ao
complemento dela; e dessa obra diz a Escritura que Deus descansou. Outra obra de Deus é a pela qual
governa as criaturas, da qual diz o Evangelho: Meu Pai até agora não cessa de obrar, e eu obro também
incessantemente. Do mesmo modo também se distingue em duplo juízo divino, mas em ordem inversa.
Um, correspondente à obra do governo, que não pode existir sem o juízo. E por esse juízo cada qual é
julgado pelas suas obras, cada uma em particular, não só no concernente a cada indivíduo, mas também
no concernente ao governo universal. Donde o ser diferido o prêmio de um em utilidade dos outros,
como diz o Apóstolo, e o redundar a pena de um em benefício dos demais. Daí a necessidade de um
outro juízo, o universal, correspondente, por oposição, à produção primeira do ser das cousas; de modo
que, assim como então tudo proveio imediatamente de Deus, assim também no juízo receberá o mundo
o seu último complemento, cada um recebendo finalmente o que lhe é estritamente devido. Por isso no
juízo final a justiça divina se manifestará em todo o seu esplendor e universalidade, pondo em evidência
o que agora fica oculto, porque às vezes os atos de um são aplicados em utilidade de outro, mais do que
o permitiriam as exigências das obras aparentes. E assim também haverá então a separação completa
entre os bons e os maus, porque depois já não será possível concorrerem aqueles para o proveito
destes, nem ao inverso, proveito que, nesta vida, justifica provisoriamente a mistura dos bons com os
maus, enquanto as cousas deste mundo são governadas pela providência divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Todo homem ao mesmo tempo é uma pessoa singular e
faz parte de todo o gênero humano. Por isso será objeto de um duplo juízo. Um particular, a que
responderá depois da morte, e pelo qual receberá a recompensa do que fez neste mundo, embora não
totalmente, porque só a alma, sem o corpo, é que terá essa recompensa. A outro juízo responderá como
parte de todo o gênero humano, no mesmo sentido em que dizemos de alguém que é julgado pela
justiça humana quando o é a comunidade a que pertence. Portanto, também cada um será julgado
então quando, no juízo universal de todo o gênero humano, se fizer a completa separação entre os bons
e os maus. Nem por isso Deus julgará duas vezes a mesma causa, porque não infligirá duas penas ao
mesmo pecado; mas a pena não completamente infligida antes do juízo será completada no juízo final
depois que os ímpios forem punidos tanto no corpo como na alma simultaneamente.

RESPOSTA À SEGUNDA. ─ A sentença própria proferida no juízo universal será a separação completa
entre os bons e os maus, que não se realizará antes dele. Mas nem quanto a sentença particular de cada
um, o juízo produzirá plenamente o seu efeito; porque também os bons, depois do juízo universal serão
mais plenamente premiados, quer pela glória de que participará o corpo, quer por estar completo o
número dos santos; assim como os maus sofrerão maiores tormentos pela pena infligida também ao
corpo e por estar completo o número dos condenados a serem punidos, pois, quanto maior o número
dos que arderem tanto mais arderão.

RESPOSTA À TERCEIRA. ─ O juízo universal concerne mais diretamente à universalidade dos homens que
a cada um deles em particular, como dissemos. Pois, embora cada um, antes do juízo, tenha já um
conhecimento certo da sua condenação ou do seu prêmio, contudo nem todos lhe conhecem a
condenação ou a recompensa que recebeu. Daí a necessidade do juízo universal.

## Art. 2 — Se o juízo universal será instruído e sentenciado oralmente.
O segundo discute-se assim. ─ Parece que o juízo universal será instruído e sentenciado oralmente.

1. ─ Pois, como diz Agostinho, é incerto quantos dias durará esse juízo. Ora, não seria incerto se todas as
fases desse juízo respondessem a um processo mental. Logo, o juízo final há de processar-se oralmente
e não só mentalmente.

2. Demais. ─ Gregório diz, como o assinala o Mestre: Aqueles ao menos ouvirão as palavras do Juiz, que
lhe deram fé às palavras. Ora, isto não pode aplicar-se ao verbo mental, porque então todos ouvirão as
palavras do Juiz, porque todos, bons e maus, conhecerão os atos uns dos outros. Logo, parece que o
juízo final se processará oralmente.

3. Demais. ─ Cristo virá julgar com forma humana, de modo a poder ser corporalmente visto de todos.
Logo e pela mesma razão parece que falará realmente de modo a ser ouvido de todos.
Mas, em contrário. ─ Agostinho diz: O livro da vida, de que fala o Apocalipse, significa uma ação especial
do poder divino, que despertará na memória de cada um todas as suas obras, boas ou más, e os fará
percorrer todas, com maravilhosa celeridade e de um só olhar da mente, de modo que a ciência de cada
qual lhe acuse ou excuse a consciência, sendo assim julgados simultaneamente todos e cada um. Ora, se
se fossem discutir oralmente os méritos individuais, não poderiam ser todos e cada um julgados a um
tempo. Logo, parece que essa discussão não será oral.

2. Demais. ─ A sentença deve corresponder proporcionalmente ao testemunho. Ora, o testemunho,
acusatório ou excusatório, será mental. Donde o dizer o Apóstolo: Dando testemunho a eles a sua
mesma consciência e os pensamentos de dentro, que umas vezes os acusam e outras os defendem, no
dia em que Deus há de julgar as causas ocultas dos homens. Logo, parece que a sentença e o juízo total
se processará mentalmente.

SOLUÇÃO. ─ A verdade nesta matéria não pode ser estabelecida com certeza. Podemos contudo pensar,
com probabilidade, que o juízo final na sua totalidade ─ quanto a sua instrução, à acusação dos maus, à
glorificação dos bons e à sentença de ambos ─ se processará mentalmente. Pois, se os atos de cada um
fossem discriminados oralmente, levaria isso um inconcebivelmente grande espaço de tempo. Donde a
perguntar Agostinho: Se o livro, de acordo com cuja escrita todos devem ser julgados, segundo a
Escritura, fosse um livro material, quem lhe poderia calcular o volume ou o tamanho? Ou em quanto
tempo poderia ser lido um livro onde estivessem descritas as vidas de todos universalmente? Ora, não
seria necessário menos tempo para narrar oralmente as obras de cada um, que para as ler, se
estivessem escritas num livro material. Por onde, é provável que as profecias do Evangelho devem ser
entendidas como havendo de se cumprir, não vocal, mas mentalmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Agostinho diz ser incerto por quantos dias durará esse
juízo, por não ser determinado se há de processar-se mental ou oralmente. Pois, se o fosse oralmente,
exigiria tempo muito mais dilatado. Se porém mentalmente, num momento poderia realizar-se.

RESPOSTA À SEGUNDA. ─ Mesmo se o juízo se processar só mentalmente, as palavras de Gregório
podem ser verdadeiras. Pois, ainda que, por ação especial do poder divino ─ ao que o Evangelho chama
locução. ─ todos conheçam os seus atos e os alheios, contudo os que tiveram fé fundada nas palavras de
Deus serão julgados por essas mesmas palavras, porque, como diz o Apóstolo ─ Todos quantos com lei
pecaram por lei serão Julgados. Assim e de um modo especial os fiéis ouvirão palavras que os infiéis não
ouvirão.

RESPOSTA À TERCEIRA. ─ Cristo aparecerá corporalmente para todos corporalmente reconhecerem o
juiz; o que poderá dar-se de súbito. A locução, porém, medida pelo tempo, exigiria um enorme espaço
dele, se o juízo devesse processar-se oralmente.

## Art. 3 — Se o tempo do juízo final é ignoto.
O terceiro discute-se assim. ─ Parece que o tempo do juízo final não é ignoto.

1. ─ Pois, assim como os santos Patriarcas esperavam o primeiro advento, assim nós o segundo. Ora, os
santos Patriarcas conheceram o tempo do primeiro advento, como o demonstra o número de semanas
referido por Daniel. Por isso o Evangelho repreende os judeus por não terem conhecido o tempo do
advento de Cristo, quando diz: Hipócritas, sabeis distinguir os aspectos do céu e da terra, pois como não
sabeis reconhecer o tempo presente? Logo, parece que também para nós deve ser determinado o
tempo do segundo advento, quando Deus virá julgar.

2. Demais. ─ Os sinais nos levam ao conhecimento das cousas assinaladas. Ora, a Escritura nos dá muitos
sinais do juízo futuro. Logo, podemos chegar a lhe conhecer o tempo.

3. Demais. ─ O Apóstolo diz: Nós outros somos a quem os fins do século tem chegado. E noutro lugar da
Escritura: Filhinhos, é chegada a última hora, etc. Logo, como já se passou muito tempo desde que essas
palavras foram ditas, parece que ao menos agora podemos saber que o juízo final está próximo.

4. Demais. ─ O tempo do juízo não deve ser oculto senão porque, ignorando-lhe o tempo determinado,
cada um se preparará para ele mais solicitamente. Ora, a mesma solicitude empregaríamos mesmo se
lhe conhecessemos o dia com certeza. Pois, também ignoramos o dia da morte; e, como diz Agostinho,
no estado em que nos encontrar o nosso último dia, nesse mesmo nos encontrará o último dia do
mundo. Logo, não há necessidade de nos ser oculto o tempo do juízo.
Mas, em contrário, o Evangelho: A respeito porém a este dia ou desta hora, ninguém sabe quando há de
ser, nem os anjos do céu, nem o Filho, mas só o Pai. Ora, diz que o Filho não sabe por não nô-lo fazer
saber.

2. Demais. ─ O Apóstolo diz: Assim como costumes vir um ladrão de noite, assim virá o dia do Senhor.
Logo, como a vinda de um ladrão à noite é absolutamente incerta, também absolutamente incerto será
o dia do juízo final.

SOLUÇÃO. ─ Deus, pela sua ciência, é a causa das cousas. Ele se comunica às criaturas de dois modos:
dando a virtude de serem causas produtoras de outras cousas, e dando a certas delas o conhecimento.
Mas em ambos os casos faz certas reservas para si: fazendo certas cousas sem a cooperação de
nenhuma criatura, e tendo para si certos conhecimentos que nenhuma simples criatura pode conhecer.
Ora, tal deve ser por excelência o conhecimento do que depende só do poder divino, com o qual
nenhuma criatura coopera. E tal é o que se dá com o fim do mundo, quando será o dia do juízo; pois, o
mundo não acabará por ação de nenhuma causa criada, assim como começou a existir por obra
imediata de Deus. Por isso e convenientemente, o conhecimento do fim do mundo fica reservado só a
Deus. E isso mesmo o Senhor o diz, com aquelas palavras: Não é da vossa conta, diz, saber os tempos
nem momentos que o Padre reservou ao seu poder; como se dissesse ─ só ao seu poder estão
reservados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ No primeiro advento Cristo veio oculto, segundo aquilo
da Escritura: Tu verdadeiramente és um Deus escondido, o Deus d'Israel, o Salvador. Por onde, para os
fiéis o poderem conhecer era preciso predeterminar o tempo certo desse advento. Mas no segundo
advento virá manifestamente, como diz a Escritura: Deus virá manifestamente, etc. Por isso nenhum
erro poderá haver sobre ele. Portanto, não há símil.

RESPOSTA À SEGUNDA. ─ Como diz Agostinho, os sinais referidos pelos Evangelhos, nem todos
concernem ao segundo advento, o do juízo final; mas certos respeitam o tempo da destruição de
Jerusalém, já passado. Outros porém, e em maior número, dizem respeito ao advento em que
quotidianamente vem ter com a sua Igreja, visitando-a espiritualmente, enquanto em nós habita pela fé
e pelo amor. ─ Mas nem o que os Evangelhos ou as Epístolas dizem referente ao último advento em
nada podem contribuir para podermos conhecer com certeza o tempo do juízo. Porque as tribulações
prenunciadas e precursoras do advento próximo de Cristo, também existiram nos tempos primitivos da
Igreja, ora mais intensas, ora mais remissas. Por isso os dias dos Apóstolos também foram chamados os
últimos dias, como lemos nos Atos, quando Pedro expõe aquelas palavras de Joel ─ Haverá nos últimos
dias, etc., aplicando-as ao segundo advento. E contudo, já muito tempo decorreu desde então, e a Igreja
sofreu ora mais ora menos tribulações. Por onde, não é possível determinar quanto tempo ainda falta,
nem com uma aproximação de mês, de ano, de século ou de milênio, como Agostinho o diz no mesmo
livro. Se porém acreditarmos que no fim mais abundarão as tribulações, não podemos contudo saber
com certeza qual será a extensão delas, imediatamente precedentes ao dia de juízo e ao advento do
Anticristo. Pois, também nos tempos da Igreja primitiva houve perseguições de tal modo cruéis e tal
abundância de heresias, que certos esperavam como próxima ou iminente a vinda do Anticristo, como
referem Eusébio e Jerônimo.

RESPOSTA À TERCEIRA. ─ A expressão ─ última hora, e outras locuções semelhantes, que se lêem na
Escritura, não pode nos dar a conhecer nenhum determinado espaço de tempo. Pois, não são usados
para exprimir um breve tempo, mas o último estado do mundo, que lhe é como a idade novíssima, da
qual porém não sabemos por que espaço de tempo durará, assim como também a velhice, última idade
da vida humana, não tem nenhum termo definido e pode às vezes durar tanto quanto todas as idades
precedentes e mesmo mais, como diz Agostinho. Por isso também o Apóstolo exclui o falso sentido que
alguns deram às suas palavras, pensando que já estava iminente o dia do Senhor.

RESPOSTA À QUARTA. ─ Mesmo suposta incerta a morte, de dois modos concorre para a vigilância a
incerteza do juízo. ─ Primeiro, por ignorarmos se ainda faltará um espaço de tempo igual ao da vida
humana; e assim, essa dupla incerteza tornará maior a diligência. ─ Segundo, porque não devemos ser
solícitos só com a nossa pessoa, mas também com a família, ou a nação, ou o reino ou toda a Igreja, cujo
tempo de duração não se mede pelo da vida humana; e contudo, cada um desses organismos há de
dispor-se para o dia do Senhor não os surpreender despreparados.

## Art. 4 — Se o juízo se dará no vale de Josafá ou em lugar adjacente.
O quarto discute-se assim. ─ Parece que o juízo não se dará no vale de Josafá nem em nenhum lugar
adjacente.

1. ─ Pois, é preciso pelo menos todos os que vão ser julgados estarem na terra, só se elevarem nas
nuvens os julgadores. Ora, toda a Terra da Promissão não poderia conter a multidão dos que devem ser
julgados. Logo, o juízo final não poderá realizar-se no Vale de Josafá.

2. Demais. ─ A Cristo humanado foi dado o poder de julgar, para que julgasse com justiça quem foi
injustamente julgado no pretório de Pilatos e cumpriu no Gólgota a sentença de um julgamento iníquo.
Logo, este deveria ser, antes, o teatro do juízo.

3. Demais. ─ As nuvens se formam da exalação dos vapores. Ora, no tempo do juízo final, não haverá
mais evaporação nem exalação. Logo, não será possível os justos serem arrebatados nas nuvens a
receber a Cristo nos ares. Portanto, todos, bons e maus, estarão na terra, e haverá necessidade de um
lugar muito mais amplo que o vale de Josafá.
Mas, em contrário, a Escritura: Ajuntarei todas as gentes e levá-las-ei ao vale de Josafá e ali entrarei com
das em juízo.

2. Demais. ─ Diz a Escritura: Assim virá do mesmo modo que haveis visto ir ao céu. Ora, Cristo subiu ao
céu, do monte Olivete, sobranceiro ao vale de Josafá. Logo, nesse lugar é que virá julgar.

SOLUÇÃO. ─ Não podemos ter absoluta certeza sobre o modo por que se dará o juízo e como os homens
se reunirão para ele. Podemos contudo com probabilidade concluir, do que diz a Escritura, que Cristo
descerá nas proximidades do monte Olivete, donde subiu ao céu; de modo que se mostre que aquele
que desceu esse mesmo é também o que subiu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Uma grande multidão pode ser contida num pequeno
espaço. Aliás bastará acrescentar ao referido lugar um espaço suficiente a abranger a multidão dos que
devem ser julgados, contanto que de todos os pontos desse espaço possam todos ver a Cristo, que,
elevado nos ares e refulgente de intenso brilho, possa ser visto de longe.

RESPOSTA À SEGUNDA. ─ Embora Cristo, por ter sido julgado injustamente, merecesse o poder
judiciário, contudo não julgará no estado de abatimento em que foi injustamente julgado, mas na forma
gloriosa com que subiu ao Pai. Por onde, o lugar da ascensão será mais próprio para o juízo, que o lugar
onde foi condenado.

RESPOSTA À TERCEIRA. ─ Por nuvens deve-se aqui entender, como interpretam certos, uma
condensação de raios luminosos emitidos pelos corpos dos santos, e não quaisquer evaporações da
terra e da água. ─ Ou podemos dizer que essas nuvens serão geradas por virtude divina, para mostrar a
conformidade entre o advento para o juízo e a ascenção; de modo que quem ascendeu nas nuvens
também nas nuvens virá julgar. ─ Além disso, as nuvens, por serem frias, indicam a misericórdia do juiz.