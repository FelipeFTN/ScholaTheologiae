# Questão 4: Do tempo da contrição.
Em seguida devemos tratar do tempo da contrição.
Sobre o que três artigos se discutem:

## Art. 1 — Se toda esta vida é tempo de contrição.
O primeiro discute-se assim. - Parece que esta vida não é toda tempo de contrição.

1. ─ Pois, assim como devemos ter dor do pecado cometido, assim também vergonha. Ora, o pejo do
pecado não dura toda a vida; pois, como diz Ambrósio, não tem de que envergonhar-se quem foi
perdoado do pecado. Logo, nem deve ter contrição, que e a dor do pecado.

2. Demais. ─ A Escritura diz: A caridade perfeita lança fora ao temor, porque o temor anda
acompanhado de pena. Ora, a dor também implica a pena. Logo, no estado da caridade perfeita não
pode existir a dor da contrição.

3. Demais. ─ Não pode haver dor do passado, que propriamente tem por objeto o mal presente, salvo se
o mal presente conserva alguma causa do mal passado. Ora, às vezes chegamos nesta vida a um estado
em que nada permanece do pecado, nem disposição, nem culpa, nem qualquer reato. Logo, não
devemos mais ter dor desse pecado.

4. Demais. ─ O Apóstolo diz: Aos que amam a Deus, todas as causas contribuem para seu bem, até
mesmo os pecados, como diz a glosa. Logo, não é necessário que, depois de lhe terem sido perdoados
os pecados, deles tenham dor.

5. Demais. ─ A contrição é parte da penitência, que se divide, por contrariedade, da satisfação. Ora, não
devemos satisfazer sempre. Logo, não devemos ter sempre contrição dos pecados.
Mas em contrário. - Agostinho diz: onde acaba a dor acaba a penitência; onde já não há penitência
também já não há perdão. Logo, como não devemos perder o perdão concedido, resulta que devemos
ter sempre dor dos pecados.

2. Demais. ─ A Escritura diz: Não estejas sem temor da ofensa que te foi remitida. Logo, devemos ter
sempre dor dos pecados para alcançar a remissão deles.

SOLUÇÃO. ─ A contrição encerra dupla dor: uma, da razão, que é o detestarmos o pecado que
cometemos; outra, da parte sensitiva, resultante da primeira. E quanto a ambas, o tempo da contrição é
o estado de toda a vida presente. ─ Pois, enquanto viandamos nesta vida, procuramos arredar os óbices
que nos impedem ou retardam a chegada ao termo. Por onde, como os pecados pretéritos retardam a
nossa rota para Deus, por não podermos recuperar o tempo que nela devíamos empregar, é necessário
vivermos na contrição durante o tempo desta vida, quanto à detestação do pecado. ─
Semelhantemente, também quanto à dor sensível, assumida como pena pela vontade. Pois, tendo
merecido a pena eterna, pelo pecado, e tendo pecado contra um Deus eterno, devemos, mudada a
pena eterna em temporal, ter sempre dor dos pecados, no que é eterno ao nosso modo, isto é, durante
todo o tempo desta vida. E por isto diz Hugo de S. Vitor, que Deus, absolvendo-nos da culpa e da pena
eternas, liga-nos pelo vínculo da detestação perpétua do pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O pejo respeita o pecado só pela torpeza deste. Por onde,
já não há lugar para ele, depois que a culpa do pecado foi perdoada. Mas permanece a dor, cujo objeto
é a culpa, não sé enquanto torpe, mas também pelo mal que causa.

RESPOSTA À SEGUNDA. ─ O temor servil excluído pela caridade, se opõe à caridade em razão dessa ser
virtude, que implica numa pena. Mas a dor da contrição é causada pela caridade, como se disse. Logo, o
símile não colhe.

RESPOSTA À TERCEIRA. ─ Embora pela penitência o pecador recobre a graça primitiva e a imunidade do
reato da pena, não poderá nunca mais recobrar, porém, a dignidade da primitiva inocência. Por onde,
sempre permanecem nele traços do pecado passado.

RESPOSTA À QUARTA. ─ Assim como não devemos fazer o mal para alcançar o bem, assim não devemos
nos comprazer com o mal, por provir dele, ocasionalmente e por obra da divina providência, o bem.
Pois, desse bem causa não foi o pecado, mas antes, impedimento; quem o causou foi a divina
providência e com isso devemos nos regozijar, ao mesmo tempo que devemos detestar o pecado.

RESPOSTA À QUINTA. ─ A satisfação depende da pena aplicada, que deve ser infligida ao pecado. Por
isso pode ficar determinado o não ser preciso satisfazer mais. Ora, essa pena precipuamente se
proporciona à culpa, quanto à conversão, donde ela tira a sua finidade. Ao passo que a dor da contrição
corresponde à culpa, quanto à aversão, donde lhe advém uma certa afinidade. E assim a verdadeira
contrição deve existir sempre. Nem há nenhum inconveniente em fazer cessar um ato posterior,
deixando permanecer o anterior.

## Art. 2 — Se devemos ter dor incessante do pecado.
O segundo discute-se assim. - Parece que não devemos ter dor incessante do pecado.

1. ─ Pois, devemos às vezes nos alegrar; assim, àquilo do Apóstolo - Alegrai-vos incessantemente no
Senhor, diz a Glosa, que é necessário nos alegrarmos. Ora, não podemos ter ao mesmo tempo alegria e
dor. Logo, não é mister tenhamos dor incessante do pecado.

2. Demais. ─ O que é em si mesmo mal e deve ser evitado não o devemos praticar, senão sendo
necessário como remédio: tal o caso do emprego do fogo e do ferro na arte de curar. Ora, a tristeza é
em si mesma um mal, segundo aquilo da Escritura: Afugenta para longe de ti a tristeza. E acrescenta a
causa: Porque a tristeza tem morto a muitos e não há utilidade nela. E o mesmo diz Filósofo
expressamente. Logo, não devemos ter dor do pecado senão a suficiente para o deliro Ora, logo depois
do primeiro ato de contrição o pecado fica delido. Portanto não é preciso ter mais dor dele.

3. Demais. ­─ Bernardo diz: A dor é boa, não sendo incessante; pois, devemos misturar o mel com o
absinto. Logo, parece que não é preciso termos dor incessante.
Mas, em contrário, diz Agostinho: Tenha sempre dor o penitente e com isso se regozige.

2. Demais. ─ Os atos constitutivos da beatitude devemos praticá-los incessantemente, tanto quanto
possível. Ora, tal é a dor do pecado, como está claro no Evangelho: Bem-aventurados os que choram.
Logo, devemos ter uma dor continuada, tanto quanto possível.

SOLUÇÃO. ─ Os atos de virtude implicam tal condição, que não são susceptíveis de aumento nem de
diminuição, como o prova o Filósofo. Por onde, sendo a contrição, pela displicência que ela implica no
apetite racional, ato da virtude de penitência, não poderá nunca haver nela aumento, nem quanto à
intensidade nem quanto à duração; senão enquanto o ato de uma virtude impede o ato de outra, mais
necessário num determinado tempo. Por isso, se pudermos manter incessantemente o ato dessa
displicência, é melhor; contanto que vaquemos aos atos das outras virtudes, oportunamente e segundo
for necessário. - As paixões, ao contrário, são susceptíveis de aumento e de diminuição, quanto à sua
intensidade e quanto à sua duração. Por onde, assim como a paixão da dor, assumida pela vontade,
deve ser moderadamente intensa, assim também deve durar moderadamente; pois, durando em
excesso, levar-nos-ia à alma o desespero, a pusilanimidade e misérias semelhantes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A alegria do século fica impedida pela dor da contrição;
mas não a alegria que tem Deus por objeto, pois tem como sua matéria a própria dor.

RESPOSTA À SEGUNDA. ─ O Eclesiástico se refere à tristeza do século. E o Filósofo, à tristeza como
paixão, da qual devemos usar moderadamente enquanto conduz ao fim assumido.

RESPOSTA À TERCEIRA. ─ Bernardo se refere à dor como paixão.

## Art. 3 — Se mesmo depois desta vida as almas têm contrição dos pecados.
O terceiro discute-se assim. ─ Mesmo depois desta vida parece que as almas têm contrição dos
pecados.

1. ─ Pois, o amor da caridade causa displicência do pecado. Ora, depois desta vida permanece nas almas
a caridade, quanto ao ato e quanto ao hábito, porque a caridade nunca jamais há de acabar, como diz o
Apóstolo. Logo, permanece a displicência pelo pecado cometido, que é essencialmente a contrição.

2. Demais. ─ Devemos ter maior dor da culpa, que da pena. Ora, as almas do purgatório têm dor da pena
sensível e da dilação da glória. Logo e muito mais, têm dor da culpa que cometeram.

3. Demais. ─ A pena do purgatório é satisfatória pelo pecado. Ora, a satisfação tira a sua eficácia da
contrição Logo, a contrição permanece depois desta vida.
Mas, em contrário. - A contrição faz parte do sacramento da penitência. Ora, os sacramentos não
permanecem depois desta vida. Logo, nem a contrição.

2. Demais. ─ A contrição pode ser grande a ponto de delir tanto a culpa como a pena. Se, pois, as almas
do purgatório pudessem ter contrição, ser-lhes-ia possível, em virtude dessa contrição, o perdão do
reato da pena e a total liberação da pena sensível ─ o que é falso.

SOLUÇÃO. ─ Três elementos devemos considerar na contrição: o seu gênero, que é a dor; a sua forma,
porque é o ato de virtude informado pela graça; e a sua eficácia porque é um ato meritório, sacramental
e de certo modo satisfatório. Por onde, as almas que estão na pátria não podem, depois desta vida, ter
contrição, por terem a isenção da dor, isenção produzida pela plenitude da alegria. Do seu lado, as que
estão no inferno, também não podem ter contrição; porque, embora tenham a dor, falta-lhes contudo a
graça que a informa. Quanto às do purgatório, têm dor dos pecados informada pela graça; mas não
meritória, por não estarem em estado de merecer. Ao passo que nesta vida todos os três elementos
supra referidos podem existir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A caridade não causa a referida dor senão naqueles que
são susceptíveis de dor. Ora, a plenitude da alegria dos bem-aventurados exclui toda capacidade de dor.
Por onde, embora tenham caridade, não podem contudo ter contrição.

RESPOSTA À SEGUNDA. ─ As almas do purgatório têm dor dos pecados. Mas essa dor não é contrição,
por lhes faltar a eficácia da contrição.

RESPOSTA À TERCEIRA. ─ Essas penas, que as almas sofrem no purgatório, não podem chamar-se
propriamente satisfação, porque esta implica uma obra meritória. Mas, em sentido lato, chama-se
satisfação a solução da pena devida.