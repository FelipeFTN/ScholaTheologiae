# Questão 31: Do ministro do sacramento da extrema unção.
Em seguida devemos tratar da administração deste sacramento.
Sobre o que se discutem três questões:

## Art. 1 — Se também um leigo pode conferir este sacramento.
O primeiro discute-se assim. ─ Parece que também um leigo pode conferir este sacramento.

1. ─ Pois, este sacramento haure a sua eficácia na oração, como diz Tiago. Ora, a oração de um leigo é às
vezes tão aceita de Deus como a de sacerdote. Logo, pode o leigo conferir este sacramento.

2. Demais. ─ Lemos de certos padres do Egito, que aplicavam o óleo aos enfermos e eles saravam. E o
mesmo também se conta de santa Genoveva, que ungia com óleo os doentes. Logo, este sacramento
pode ser conferido mesmo pelos leigos.
Mas, em contrário, neste sacramento se dá o perdão aos pecados. Ora, os leigos não tem o poder de
perdoar os pecados. Logo, etc.

SOLUÇÃO. ─ Segundo Dionísio, uns são os que exercem a atividade hierárquica; outros, os leigos, os que
a recebem. Por onde, a nenhum leigo cabe por ofício dispensar qualquer sacramento; mas, por divina
dispensa podem batizar em caso de necessidade, a fim de não faltar a ninguém a faculdade da
regeneração espiritual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A oração referida não na faz o sacerdote em seu próprio
nome, porque, como também às vezes poderia estar em pecado, não seria ouvido. Mas a faz em nome
de toda a Igreja, em cujo nome pode orar, como pessoa pública; e isso não pode fazer o leigo, que é
uma pessoa privada.

RESPOSTA À SEGUNDA. ─ Essas unções não eram sacramentais; mas, por uma certa devoção dos que as
recebiam ou pelos méritos dos que ungiam ou aplicavam o óleo, produziam o efeito da saúde do corpo,
pela graça de curar as doenças, não porém pela graça sacramental.

## Art. 2 — Se os diáconos podem conferir este sacramento.
O segundo discute-se assim. ─ Parece que os diáconos podem conferir este sacramento.

1. ─ Pois, segundo Dionísio, os diáconos tem o poder de purificar. Ora, este sacramento foi instituído só
para purificar da doença da alma e do corpo. Logo, também os diáconos podem conferi-lo.

2. Demais. ─ Mais digno do que sacramento da extrema unção é o do batismo. Ora, os diáconos podem
batizar, como o demonstra o caso de S. Lourenço. Logo, também podem conferir este sacramento.
Mas, em contrário, a Escritura: Chame os presbíteros da Igreja.

SOLUÇÃO. ─ Os diáconos tem só a faculdade de purificar mas não a de iluminar. Ora, como a iluminação
é obra da graça, o diácono não pode, por ofício próprio, ministrar nenhum sacramento que confira a
graça. Logo, nem este, que a confere.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Este sacramento purifica, iluminando pela colação da
graça. Por onde, ao diácono não lhe compete conferi-lo.

RESPOSTA À SEGUNDA. ─ Este sacramento não é de necessidade à salvação, como o batismo. Por isso, o
poder de o conferir não é dado a todos, em caso de necessidade, mas só àqueles a quem por oficio
compete esse poder. Ora, aos diáconos não cabe por ofício batizar.

## Art. 3 — Se só o bispo pode conferir este sacramento.
O terceiro discute-se assim. ─ Parece que só o bispo pode conferir este sacramento.

1. ─ Pois, este sacramento, como a confirmação, se perfaz pela unção. Ora, só o bispo pode confirmar.
Logo, só o bispo pode conferir este sacramento.

2. Demais. ─ Quem não pode o menos não pode o mais. Ora, mais é usar da matéria santificada que
santificá-la, pois, aquilo é a finalidade disto. Logo, como o sacerdote não pode santificar a matéria,
também não pode usar da matéria santificada.
Mas, em contrário. ─ O ministro deste sacramento deve ir ter com quem o recebe, como está claro na
Escritura. Ora, o bispo não poderia ir ter com todos os enfermos da sua diocese. Logo, nem só o bispo
pode conferir este sacramento.

SOLUÇÃO. ─ Segundo Dionísio, o ofício próprio do bispo é aperfeiçoar, como iluminar é o do sacerdote.
Por onde, só os bispos podem dispensar os sacramentos, que colocam quem os recebe num estado de
perfeição superior aos outros estados. Ora, tal não se dá com este sacramento, que é dado a todos.
Logo, pode ser administrado pelos simples sacerdotes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A confirmação imprime caráter, que coloca o homem no
estado de perfeição, como dissemos. Ora, isto não se dá com este sacramento. Logo, o símile não colhe.

RESPOSTA À SEGUNDA. ─ Embora, na ordem da causa final, o uso da matéria santificada tenha
prioridade sobre a santificação dela, contudo na ordem da causa eficiente a santificação da matéria é a
que tem prioridade, porque dela depende o uso, como da sua causa ativa. Por onde, a santificação
demanda uma virtude ativa mais elevada que o uso.