# Questão 53: Do impedimento do voto e da ordem.
Em seguida devemos tratar do impedimento do voto e da ordem.
Sobre o que discutem-se quatro artigos:

## Art. 1 — Se pela obrigação de um voto simples deve ser anulado o matrimônio contraído.
O primeiro discute-se assim. ─ Parece que pela obrigação de um voto simples deve ser anulado o
matrimônio contraído.

1. Um vínculo mais forte anula o mais fraco. Ora, o vínculo do voto é mais forte que o do matrimônio,
porque aquele é feito a Deus e este ao homem. Logo, o vínculo de voto anula o do matrimônio.

2. Demais. ─ O preceito de Deus não vale menos que o da Igreja. Ora, o da Igreja obriga, a ponto de
anular o matrimônio contraído contra ele, Tal o caso dos que o contraem em grau de parentesco
proibido pela Igreja. Logo, como guardar voto feito é preceito divino, resulta que será nulo o
matrimônio de quem o contrair em oposição do voto emitido.

3. Demais. ─ No matrimônio pode ser praticada sem pecado a conjunção carnal. Ora, quem faz o voto
simples de castidade não poderá nunca ter relações com a esposa, sem pecado. Logo, o voto simples
dirime o matrimônio. Prova da proposição média: quem, depois de ter feito voto simples de continência,
contrair matrimônio, peca mortalmente, porque, segundo Jerônimo, os que fizeram o voto de
virgindade ficam impedidos, não só de casar, mas mesmo de querer fazê-lo; ora, o contrato do
matrimônio não encontra o voto de continência senão por causa da conjunção carnal; logo, desde a
primeira relação que tiver com a mulher, peca. E portanto, todas as outras vezes, porque o pecado
primeiro cometido não pode escusar do seguinte.

4. Demais. ─ O homem e a mulher no matrimônio devem ser iguais, sobretudo no concernente à
conjunção carnal. Ora, quem fez voto simples de continência não pode exigir o cumprimento do dever
conjugal sem pecado. pois este é manifestamente contra o voto de continência, a qual se obrigou, por
ele. Logo, também não poderá sem pecado cumprir esse dever.
Mas, em contrário, o Papa Clemente diz, que o voto simples impede contrair matrimônio, mas não anula
o matrimônio já contraído.

SOLUÇÃO. ─ Uma coisa deixa de nos pertencer quando passa para o poder de outro. Mas a promessa de
dar uma coisa não a transfere para o domínio daquele a quem foi prometido. Por onde, não é pelo fato
de a termos prometido que ela deixa de nos pertencer. Ora, o voto simples não é senão uma simples
promessa feita de consagrar a Deus a continência do nosso corpo. Por onde, depois dele feito, ainda
continuamos senhor do nosso corpo. Portanto é possível dá-lo a outrem, por exemplo, à mulher, e nessa
dação consiste o sacramento do matrimônio, que é indissolúvel. Por isso, o voto simples, embora
impeça contrair matrimônio, porque peca quem o contrair, depois do voto simples de continência,
contudo como o contrato é válido, não pode depois, por causa desse voto, ser anulado o matrimônio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O voto é um vínculo mais forte que o matrimônio,
relativamente a quem é feito e ao a que obriga. Pois, pelo matrimônio um homem se obriga a cumprir o
dever conjugal para com uma mulher, ao passo que pelo voto se obriga para com Deus a guardar
continência. Contudo, quanto ao modo de ligar, o matrimônio é um vínculo mais forte que o do voto
simples. Pois, por aquele o marido se entrega imediatamente ao poder da mulher; o que não se dá com
o voto simples, em que a entrega não é imediata, como se disse. Mas o voto simples obriga do mesmo
modo por que o fazem os esponsais. Portanto os dirime a estes.

RESPOSTA À SEGUNDA. - O preceito que proíbe o casamento entre parentes não anula, enquanto
preceito de Deus ou da Igreja, o matrimônio que vai ser contraído; mas faz com que sobre o corpo da
mulher, parente em grau proibido, não pode ter poder outro cônjuge. ─ Ora, tal não resulta do preceito
que proíbe o matrimônio, depois de um voto simples, como do sobredito resulta. Logo, a objeto não
colhe, por tornar como causa o que não o é.

RESPOSTA À TERCEIRA. ─ Quem contrai matrimônio por palavras de presente, depois de um voto
simples, não pode sem pecado mortal ter relação com sua esposa; porque ainda lhe é possível, antes do
casamento consumado, cumprir o voto de continência. Mas depois de consumado o matrimônio, já se
lhe torna ilícito não cumprir o dever conjugal para com a mulher, quando o exija; contudo isso se dá por
culpa sua. Por isso até aí não vai a obrigação do voto, como do sobredito se colhe. Deve contudo essa
pessoa reparar pela penitência a transgressão do voto.

RESPOSTA À QUARTA. ─ Quem contrair matrimônio está obrigado a cumprir o voto feito de continência,
na medida em que não está impedido de o fazer. Por isso, morta a mulher, está totalmente obrigado à
continência. E como pelo vínculo do matrimônio não está obrigado a pedir a satisfação do dever
conjugal, por isso não no pode pedir sem pecado; embora possa: sem pecado cumprir esse dever, para
com a mulher, quando lh'o ela pedir, desde que a isso se obrigou pela conjunção carnal precedente. E
isso deve entender-se tanto no caso de a mulher o pedir expressamente, como interpretativamente, no
caso de ter vergonha de lh'o exigir e o marido perceber-lhe a vontade. Então poderá sem pecado
cumprir o dever conjugal, e sobretudo se teme que corra perigo a castidade da esposa, se não o fizer.
Nem obsta o serem iguais quanto ao ato matrimonial, porque todos podemos renunciar ao nosso
direito. ─ Certos porém dizem, que pode tanto pedir o cumprimento desse dever como retribuí-lo, a fim
de não vir a tornar-se demasiado oneroso à esposa o estar sempre a exigir o cumprimento do débito. ─
mas quem atentar bem no caso verá que isso é pedir interpretativamente.

## Art. 2 — Se o voto solene anula o casamento já contraído.
O segundo discute-se assim. ─ Parece que o voto solene não anula o matrimônio já contraído.
1 Pois, como diz uma decretal, perante Deus não obriga menos o voto simples que o solene. Ora, o
matrimônio tem a sua validade e a sua nulidade dependente da aceitação divina. Logo, como o voto
simples não dirime o matrimônio, também o voto solene não poderá dirimi-lo.

2. Demais. ─ O voto solene não acrescenta maior força ao voto simples que o juramento. Ora, o voto
simples, mesmo acompanhado de juramento, não dirime o matrimônio já contraído. Logo, nem o voto
solene.

3. Demais. ─ O voto solene nada tem que não possa ter o voto simples. Porque o voto simples poderia
implicar escândalo, por ser, como o voto solene, público. Semelhantemente, a Igreja podia e devia
estatuir que o voto simples dirime o matrimônio já contraído, e muitos pecados se evitariam. Logo, pela
razão por que o voto simples não dirime o matrimônio, por essa mesma não no deve dirimir o voto
solene.
Mas, em contrário, quem emite um voto solene contrai matrimônio espiritual com Deus, muito mais
solene que o matrimônio material. Ora, o matrimônio material já contraído dirime o contratado depois.
Logo, também o voto solene.

2. Demais ─ O mesmo também pode ser provado pelas muitas autoridades citadas pelo Mestre.

SOLUÇÃO. ─ Todos opinam que assim como o voto solene impede o matrimônio de ser contraído, assim
dirime o já contraído.
Mas certos assinalam como causa o escândalo ─ Não há porém tal. Pois, também um simples voto pode
às vezes causar escândalo, por ser de certo modo público. Além disso, a indissolubilidade do matrimônio
é de direito divino, que não pode ser transgredido para evitar escândalo.
Por isso outros dizem que tal se dá por determinação da Igreja. ─ Mas essa opinião também é
insuficiente. Porque de acordo com ela a Igreja poderia também determinar o contrário. O que não é
verdadeiro.
Por onde, devemos opinar, com outros, que o voto solene por natureza dirime o matrimônio já
contraído. Pois, por ele, o homem perde o poder sobre o seu corpo, pelo consagrar a Deus por
continência perpétua, como do sobredito resulta. Portanto, não pode submetê-la ao poder de uma
mulher, contraindo matrimônio. E como o matrimônio subsequente a esse voto é nulo, dizemos que o
voto solene anula o matrimônio já contraído.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O voto simples é considerado como implicando a mesma
obrigação, perante Deus, que o voto solene, enquanto se trata do que tem com Deus relações, como no
caso da separação de Deus causada pelo pecado mortal. Pois, peca mortalmente tanto quem quebra o
voto simples como quem quebra o voto solene, embora seja pecado mais grave quebrar o primeiro que
o segundo. Mas esta comparação só vale para o gênero de reato, e não para o grau de gravidade dele.
No matrimônio porém, que liga um esposo ao outro, os dois votos não produzem a mesma obrigação,
mesmo genericamente falando. Pois, certas obrigações resultam do voto solene, que não resultam do
simples.

RESPOSTA À SEGUNDA. ─ O juramento, considerada a obrigação dele oriunda, liga mais que o voto. Ora,
o voto solene impõe maior liame pelo modo por que obriga, porque consiste em darmos imediatamente
o que prometemos ─ o que não sucede com o juramento. Logo, a objeção não colhe.

RESPOSTA À TERCEIRA. ─ O voto solene implica a entrega imediata do corpo próprio, o que não implica
o voto simples, como do sobredito resulta. Logo, a objeção tem um fundamento suficiente.

## Art. 3 — Se a ordem impede o matrimônio.
O terceiro discute-se assim. ─ Parece que a ordem não impede o matrimônio.

1. Pois, nada fica impedido senão pelo seu contrário. Ora, a ordem não é contrária ao matrimônio, por
serem ambos sacramentos. Logo, não no impede.

2. Demais. ─ A ordem é o mesmo para nós como para a Igreja Oriental. Ora, na Igreja Oriental não
impede o matrimônio. Logo, etc.

3. Demais. ─ O matrimônio significa a união entre Cristo e a Igreja. Ora, esse significado devem
sobretudo pô-lo em evidência os ministros de Cristo, isto é, os ordenados. Logo, a ordem não impede o
matrimônio.

4. Demais. ─ Todas as ordens preparam para as funções espirituais. Ora, a ordem não pode impedir o
matrimônio senão em razão da espiritualidade. Logo, se a ordem impede o matrimônio, qualquer delas
o impedirá. O que é falso.

5. Demais. ─ Todos os ordenados podem receber benefícios eclesiásticos e gozar igualmente dos
privilégios clericais. Se, pois, a ordem impede o matrimônio, porque os casados não podem receber um
benefício eclesiástico nem gozar dos privilégios clericais, como dizem os juristas, então qualquer ordem
deveria impedilo. O que é falso, como o demonstra a decretal de Alexandre III. E assim, nenhuma
ordem, segundo parece, impede o matrimônio.
Mas, em contrário, uma decretal dispõe: Os que receberam o subdiaconato e outras ordens superiores,
e dos quais se souber que tomaram mulher, sejam obrigados a deixá-las imediatamente. O que não se
daria se o matrimônio estivesse verdadeiramente contraído.

2. Demais. ─ Ninguém, que tenha feito voto de continência, pode contrair matrimônio. Ora, certas
ordens implicam o voto de continência, como diz o mestre. Logo, tais ordens impedem, o matrimônio.

SOLUÇÃO. ─ É da natureza mesma das ordens sagradas impedir o matrimônio, e razões de conveniência
assim o exigem. Porque os constituídos nas ordens sacras tocam nos vasos sagrados e mostram os
sacramentos. Donde a conveniência. Quanto a serem impedimento ao matrimônio, isso resulta da
legislação da Igreja. De um modo porém, entre os latinos, e de outro, entre os gregos. Pois, entre os
gregos, a ordem, por sua própria forma, impede o matrimônio de ser contraído. E entre os latinos, fica
ele impedido, não só por forma mesma da ordem, mas ainda pelo voto de continência a ela anexo.
Mesmo quem não emitiu esse voto verbalmente, entende-se tê-lo feito tàcitamente, desde que recebeu
a ordem segundo o rito da Igreja Ocidental. Por onde, entre os gregos e os outros orientais, uma ordem
sagrada impede o matrimônio de ser contraído, mas não impede o uso do casamento já contraído. Pois,
podem usar do matrimônio anteriormente contraído, embora não possam contraí-lo depois de recebida
a ordem. Na Igreja Ocidental porém impede o matrimônio e o uso dele, salvo se foi um marido quem a
recebeu, ignorando-a a mulher ou opondo-se a tal. Porque daí não lhe pode advir a ela nenhum dano. ─
Quanto a saber como se distinguem as ordens sacras das que não o são, atualmente e na Igreja
primitiva, já o dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora uma ordem sagrada não contrarie o matrimônio,
enquanto sacramento, repugna-lhe porém de certo modo em virtude da natureza do seu ato que
impede as funções espirituais.

RESPOSTA À SEGUNDA. ─ O argumento se funda num erro. Pois, a ordem impede o matrimônio de ser
contraído, embora nem em toda parte seja acompanhado do voto.

RESPOSTA À TERCEIRA. ─ Os constituídos nas ordens sacras significam a Cristo pelo exercício de funções
mais nobres, como resulta do que dissemos no tratado da ordem, do que a dos unidos pelo matrimônio.
Por isso a objeção não colhe.

RESPOSTA À QUARTA. ─ Os constituídos em ordens menores não ficam proibidos, por forma mesma
delas, de contrair matrimônio. Embora essas ordens os destinem a certas funções espirituais, não têm
contudo poder imediato de tocar nos vasos sagrados, como o tem os constituídos em ordens sacras.
Mas, segundo a legislação da Igreja Ocidental, o uso do matrimônio impede o exercício de uma ordem
não sagrada. Isso para dar mais dignidade aos ofícios eclesiásticos. E como quem recebeu um beneficio
eclesiástico é obrigado ao exercício da sua ordem e por isso mesmo goza dos privilégios clericais. por
isso entre os latinos os clérigos casados ficam privados desses privilégios.

DONDE SE DEDUZ À RESPOSTA À ÚLTIMA OBJEÇÃO.

## Art. 4 — Se é possível, depois de ter contraído o matrimônio, receber uma ordem sagrado.
O quarto discute-se assim. ─ Parece que, depois de se haver contraído matrimônio, não é possível
receber uma ordem sagrada.

1. Pois, o mais forte prejudica o menos forte. Ora, mais forte é o vínculo espiritual que o corporal. Logo,
quem, depois de unido pelos laços do matrimônio, receber a ordem, causará dano à esposa, que não
poderá pedir o cumprimento da obrigação conjugal, porque a ordem é um vínculo espiritual e o
matrimônio, corporal. Logo, parece que não pode receber ordem sacra quem já consumou o
matrimônio.

2. Demais. ─ Consumado o matrimônio, não pode um cônjuge fazer voto de continência sem o
consentimento do outro. Ora, uma ordem sacra é acompanhada do voto de continência. Logo, o marido,
que receber uma ordem sacra sem o consentimento da mulher, obriga-la-á a observar continência
contra a vontade; pois, não poderia casar com outro na vigência desse casamento.

3. Demais. ─ Mesmo temporariamente, não pode o marido vacar à oração, sem o consentimento da
esposa, como diz o Apóstolo. Ora, entre os orientais, os constituídos em ordens sacras, estão obrigados
à continência no tempo em que desempenharem as funções delas. Logo, nem eles podem ordenar-se
sem o consentimento da mulher. E muito menos entre os latinos.

4. Demais. ─ Marido e mulher estão no mesmo pé de igualdade. Ora, um sacerdote grego morto a
esposa, não pode convolar a segundas núpcias. Logo, nem a mulher, falecido o marido. Mas não pode
ela ser privada do direito de casar, depois da morte do marido, por um ato praticado por ele quando
ainda vivo. Logo, não pode o marido, depois de casado, receber as ordens sacras.

5. Demais. ─ O matrimônio tanto se opõe à ordem, como inversamente. Ora, a ordem precedente
impede o matrimônio subsequente. Logo, ao inverso.
Mas, em contrário. ─ Os religiosos estão obrigados à continência, como os que receberam ordens sacras.
Ora, quem contraiu matrimônio, e depois enviuvou ou obteve o consentimento da mulher, pode entrar
em religião. Logo, também receber a ordem.

2. Demais. ─ Pode quem contraiu matrimônio tornar-se escravo de outro homem. Logo, também servo
de Deus, pela recepção da ordem.

SOLUÇÃO. ─ O matrimônio não impede o casado de receber, uma ordem sacra. Pois, se o fizer, mesmo
contra a vontade da esposa, nem por isso deixa a ordem recebida de lhe imprimir caráter. Se a receber,
porém, com o consentimento dela ou depois de morta, tanto recebe a ordem, como o poder de lhe
exercer as funções.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O vínculo da ordem solve o vínculo do matrimônio, em
razão do dever conjugal que implica. Por isso à ordem lhe repugna ele, considerando-se quem a recebe;
pois, não pode pedir o cumprimento desse dever nem a esposa está obrigada para com ele, a cumpri-lo.
Mas não dissolve o vínculo matrimonial relativamente à mulher, pois, está obrigado a lhe cumprir a
obrigação conjugal, se não puder induzi-Ia à continência.

RESPOSTA À SEGUNDA. ─ O marido tendo recebido a ordem, com ciência e consentimento da mulher,
fica esta obrigada a voto de perpétua continência. Não está porém obrigada a entrar em religião, se não
temer perigo para a sua castidade, pelo fato de ter o marido emitido um voto solene. Mas
diferentemente, se pronunciou um voto simples. Se porém o marido recebeu ordens contra sua
vontade, não fica obrigada ao voto de continência, por que do ato do marido nenhum prejuízo lhe pode
resultar.

RESPOSTA À TERCEIRA. ─ Parece mais provável, embora certos pensem o contrário, que também entre
os gregos não pode o marido receber ordens sem o consentimento da mulher. Pois, ao menos durante o
tempo em que exerce o ministério, ficaria a mulher privada do seu direito ao dever conjugal, dano que
juridicamente não está obrigada a sofrer, se não consentiu ou ignorava que o marido tivesse recebido
ordens.

RESPOSTA À QUARTA. ─ Como está dito, pelo fato mesmo de, entre os gregos, a mulher consentir que
seu marido receba ordens, obriga-se perpetuamente a não casar com outro, Do contrário, a significação
simbólica do matrimônio não se verificaria, e ela é capital no casamento de um sacerdote. Se porém se
ordenar sem o consentimento da mulher, esta não fica adstrita à referida obrigação.

RESPOSTA À QUINTA. ─ O matrimônio tem como causa o nosso consentimento. Não porém a ordem,
cuja causa sacramental é determinada por Deus. Por onde, o matrimônio pode ser impedido, na sua
validade, pela ordem precedentemente recebida, mas a ordem não pode ficar impedida de
verdadeiramente o ser, por causa de um matrimônio precedente. Porque a virtude dos sacramentos é
imutável, e os atos humanos podem ficar impedidos.