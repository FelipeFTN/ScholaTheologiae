# Questão 68: Dos filhos ilegitimamente nascidos.
Em seguida devemos tratar dos filhos ilegitimamente nascidos.
E nesta questão discutem-se três artigos:

## Art. 1 — Se os filhos nascidos fora de um verdadeiro matrimônio são ilegítimos.
O primeiro discute-se assim. ─ Parece que os filhos nascidos fora de um verdadeiro matrimônio são
legítimos.

1. Pois o filho legítimo é o nascido de um matrimônio legal. Ora, todos nascem de uma união legal, ao
menos pela lei da natureza, que é a fortíssima das leis. Logo, todo filho é legítimo.

2. Demais. ─ Geralmente se chama legítimo o filho nascido de matrimônio legítimo, ou do que é assim
reputado em face da Igreja. Ora, pode acontecer seja um casamento reputado legítimo à face da Igreja e
contudo tenha um impedimento para ser verdadeiro matrimônio, conhecido contudo dos que à face da
Igreja o contraíram. Ora, se casarem ocultamente ignorando o impedimento, é considerado legítimo à
face da Igreja, desde que esta não o proibiu. Logo, os filhos nascidos de um matrimônio não verdadeiro
não são ilegítimos.
Mas, em contrário. ─ Ilegítimo se chama ao contrário da lei. Ora os nascidos fora de um matrimônio
legitimo nasceram contra a lei. Logo, são ilegítimos.

SOLUÇÃO. ─ Os filhos podem encontrar-se num dos quatro estados seguintes. Uns são naturais e
legítimos, como os nascidos de um verdadeiro e legítimo matrimônio. Outros são naturais e não
legítimos, como os nascidos da fornicação simples. Outros são legítimos e não naturais, como os filhos
adotados. Outros, nem legítimos nem naturais, como os espúrios nascidos do adultério e do estupro;
pois esses tais nasceram tanto em oposição à lei positiva como, e expressamente, contra a lei da
natureza. Donde, devemos conceder que certos filhos são ilegítimos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora os nascidos de um concúbito ilícito nasçam de
acordo com a natureza comum ao homem e aos outros animais, nascem contudo em contrariedade da
lei natural própria ao homem. Pois, a fornicação, o adultério e atos semelhantes são contra a lei da
natureza. Por onde, tais filhos não legítimos em virtude de nenhuma lei.

RESPOSTA À SEGUNDA. ─ A ignorância, não sendo afetada, escusa de pecado o concúbito ilícito. Por
onde, os que se unem de boa fé à face da Igreja, embora haja algum impedimento, que contudo
ignorem, nem pecam, nem os filhos nascidos são ilegítimos. Mas se o conhecerem embora a Igreja lhes
santifique a união, por lhes ignorar o impedimento, não ficam isentos de pecado nem os filhos de serem
ilegítimos. Mas se não o conhecerem e contraírem casamento às ocultas, também não ficam escusados,
porque essa ignorância é considerada como afetada.

## Art. 2 — Se os filhos ilegítimos devem sofrer o detrimento da sua ilegitimidade.
O segundo discute-se assim. ─ Parece que os filhos ilegítimos nenhum detrimento devem sofrer pela
sua ilegitimidade.

1. Pois, o filho não deve ser punido pelo pecado do pai, como está claro nas palavras do Senhor. Ora, o
fato de um ter nascido de concúbito ilícito, não é pecado seu, mas do pai. Logo, disso não deve sofrer
nenhum sofrimento.

2. Demais. ─ A justiça humana tem na divina o seu modelo. Ora, Deus distribuiu os seus bens naturais
igualmente tanto aos filhos legítimos como aos ilegítimos. Logo, pelo direito humano também os filhos
ilegítimos devem ser equiparados aos legítimos.
Mas, em contrário, a Escritura diz, que Abrão deu tudo quanto possuía a Isaac, e pelos filhos das
concubinas distribuiu dádivas. E contudo estes não eram nascidos de concúbito ilícito. Logo e com maior
razão, os nascidos de concúbito ilícito devem sofrer o detrimento de não receberem a herança paterna.

SOLUÇÃO. ─ De dois modos podemos dizer que alguém sofre detrimento de alguma coisa. Primeiro, por
ter sido privado do que lhe era devido. E então o filho ilegítimo não sofre nenhum detrimento. ─ De
outro modo, por não lhe ser devido o que, de outra maneira, lh'o seria. E então, um filho ilegítimo
padece duplo detrimento. Um, o de não ser admitido a atos legítimos, como às funções e às dignidades
que requerem uma determinada honorabilidade da parte daqueles que são delas investidos. O outro
detrimento que sofre é o de não poder herdar do pai: ─ Contudo, os filhos naturais podem suceder só na
sexta parte. ─ Mas os espúrios em nenhuma parte, embora por direito natural os pais estejam obrigados
a lhes fornecer o necessário à vida. Por onde, pertence à solicitude do bispo obrigar os pais a manter
tais filhos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Sofrer detrimento nesse segundo sentido não é nenhuma
pena. Assim, não dizemos que sofre uma pena quem, por não ser filho de rei, não lhe sucede do reino.
Semelhantemente, nenhuma sofre quem, por não ser filho legítimo, não lhe é devido o que só aos filhos
legítimos o é.

RESPOSTA À SEGUNDA. ─ O concúbito ilegítimo não é contrário à lei, enquanto ato da potência geratriz,
mas enquanto procedente de uma vontade depravada. Por onde, o filho ilegítimo não sofre nenhum
sofrimento nas causas que se adquirem pela sua origem natural, mas só naquela cuja produção ou posse
dependeu da vontade.

## Art. 3 — Se o filho ilegítimo pede ser legitimado.
O terceiro discute-se assim. ─ Parece que o filho ilegítimo não pode ser legitimado.

1. Pois, tanto dista o legítimo do ilegítimo, como ao contrário, o ilegítimo do legítimo. Ora, o legítimo
nunca pode tornar-se ilegítimo. Logo, nem o ilegítimo, legítimo.

2. Demais. ─ Do concúbito ilegítimo nasce um filho ilegítimo. Ora um concúbito ilegítimo não pode
nunca tornar-se legítimo. Logo, nem seu filho ilegítimo ser legitimado.
Mas, em contrário. ─ O que a lei estabelece pode também revogar. Ora, ilegitimidade dos filhos é
criação da lei positiva. Logo, pode um filho ilegítimo ser legitimado por quem tem poder legal para tal.

SOLUÇÃO. ─ Um filho ilegítimo pode ser legitimado, não para ser considerado nascido de um concúbito
legítimo, porque este concúbito já é um ato passado e não poderá nunca ser legitimado, desde que uma
vez foi ilegítimo. Mas diz-se que o filho é legitimado, por ficar livre do detrimento, sofrido pelos filhos
ilegítimos.
E há seis modos de legitimação.
Dois pertencem ao direito canônico. E são quando um homem casa com aquela de quem gerou um filho
ilegítimo, se não foi em adultério; e por uma indulgência especial e dispensa do soberano Pontífice.
Os outros quatro modos pertencem à lei civil. ─ O primeiro, quando o pai oferece o filho natural à cúria
do Imperador; por isso mesmo fica legitimado por causa da dignidade curial. ─ O segundo, quando o pai
o nomeia em testamento como herdeiro legítimo, e o filho depois oferece o testamento ao Imperador. ─
O terceiro, quando não há nenhum filho legítimo, e o próprio filho ilegítimo se oferece ao príncipe. ─ O
quarto quando o pai, por instrumento público, ou com a assinatura de quatro testemunhas, nomeia o
filho como legítimo, sem acrescentar natural.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Podemos sem injustiça fazer uma graça a alguém; mas
ninguém pode ser condenado a sofrer um dano senão por alguma culpa. Por isso, um filho ilegítimo
pode tornar-se legítimo, mas não do inverso. Pois, embora possa um filho legítimo ser privado da
herança, por alguma culpa, nem por isso, contudo se chama ilegítimo, porque legítima foi a sua geração.

RESPOSTA À SEGUNDA. ─ Um concúbito ilegítimo é viciado por um defeito intrínseco, que o opõe ao
legítimo. Por isso não pode tornar-se legítimo. Nem colhe o símile com o filho ilegítimo, que não tem tal
defeito.
A Ressurreição