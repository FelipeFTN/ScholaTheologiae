# Questão 66: Da bigamia e da irregularidade dela derivada.
Em seguida devemos tratar da bigamia e da irregularidade dela derivada. E nesta questão discutem-se
cinco artigos:

## Art. 1 — Se a bigamia de quem teve duas esposas sucessivas implica irregularidades.
O primeiro discute-se assim. ─ Parece que a bigamia de quem teve duas esposas sucessivas não
implica irregularidade, porque a multiplicidade e a unidade resultam do ser.

1. Como, pois, o não ser não constitui multiplicidade alguma, aquele que tem sucessivamente duas
esposas, quando uma está no ser e outra no não ser, por isso não se torna marido de não uma só
mulher, ao qual, segundo o Apóstolo, é vedado o episcopado.

2. Demais. ─ Dá mais visíveis sinais de incontinência quem teve relações ilícitas com varias mulheres,
que quem teve sucessivamente várias esposas. Ora, no primeiro caso não resulta nenhuma
irregularidade. Logo, nem do segundo.

3. Demais. ─ Se a bigamia causasse irregularidade, se-lo-ia em razão do sacramento ou da cópula carnal.
Ora, não em razão daquele, porque então quem contraísse matrimônio com uma, por palavras de
presente, e morta ela antes da cópula carnal, casasse com outra, ficaria irregular o que colide com o
decreto de Inocêncio III. Nem pela segunda razão, porque nesse caso quem tivesse tido concúbito ilícito
com várias seria irregular ─ o que é falso. Logo, de nenhum modo a bigamia causa irregularidade.

SOLUÇÃO. ─ Quem se ordena é constituído ministro dos sacramentos; e quem deve ministrá-los aos
outros não deve ter recebido defeituosamente nenhum sacramento. E um sacramento é assim recebido
quando não tem a sua significação íntegra. Ora, o sacramento do matrimônio significa a união entre
Cristo e a Igreja, união de um só com uma só. Por onde, a fim de o sacramento ter a sua significação
perfeita, há de um homem casar com uma só mulher e uma mulher com um só marido. Portanto a
bigamia, que contraria essa significação, acarreta uma irregularidade. E há quatro modalidades de
bigamia. A primeira quando um tem, de direito, duas esposas sucessivamente. A segunda quanto tem
simultaneamente duas, uma de direito e a outra de fato. A terceira, quando tem duas sucessivas, uma
de direito e outra de fato. A quarta, quando casa com viúva. E assim todos esses Casos implicam
irregularidade. Assinala-se ainda outra causa consequente de irregularidade. Porque, quem recebe o
sacramento da ordem deve revelar a máxima espiritualidade, quer por ministrar os sacramentos, que
são realidades espirituais, quer por ensinar uma doutrina espiritual e dever-se ocupar com coisas
espirituais. Ora, como a concupiscência repugna sobremaneira à espiritualidade e torna o homem
totalmente carnal, não deve quem se ordenou dar mostras de uma concupiscência permanente. Ora,
dela dão mostras os bígamos, que não quiseram contentar-se com uma só mulher. A primeira razão
porém é melhor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A multiplicidade simultânea de mulheres o é uma
absoluta. Por onde, essa multiplicidade totalmente repugna à significação do sacramento. Por isso o
tolhe a este. Mas a multidão sucessiva de esposas o é relativamente. Por isso não tolhe de todo a
significação do sacramento, nem o elimina na sua essência, senão só quanto à perfeição exigida dos
dispensadores dos sacramentos.

RESPOSTA À SEGUNDA. ─ Embora os fornicários dêem provas de maior concupiscência, não a dão
porém de uma concupiscência permanente; pois, pela fornicação não assumem nenhuma obrigação
perpétua para com nenhuma mulher. Não há logo deficiência de sacramento.

RESPOSTA À TERCEIRA. ─ Como dissemos, a bigamia causa irregularidade por tolher a perfeita
significação do sacramento, que consiste tanto na união das almas pelo consentimento, como na dos
corpos. Assim, em virtude a essas duas causas, simultaneamente a bigamia produz a irregularidade. Por
isso um decreto de Inocêncio III derroga a doutrina do Mestre das Sentenças, quando ensina que o seu
consentimento por palavras de presente basta para fazer incorrer em irregularidade.

## Art. 2 — Se a irregularidade resulta da bigamia pela qual um tem duas esposas, simultânea ou sucessivamente, uma de direito e outro de fato.
O segundo discute-se assim. ─ Parece que a irregularidade não resulta da bigamia pela qual um tem
várias esposas, simultânea ou sucessivamente, uma de direito e outra de fato.

1. Pois, onde não há sacramento não pode haver deficiência sacramental. Ora, quem contrai uma
ligação de fato com uma mulher, e não de direito, não recebe nenhum sacramento, porque essa união
não significa a conjunção de Cristo com a Igreja. Logo, como a irregularidade não resulta da bigamia
senão pela falta de sacramento, parece que dessa bigamia nenhuma irregularidade resulta.

2. Demais. ─ Quem tem relação com uma mulher a que vive ligado simplesmente de fato e não de
direito, comete fornicação se não tem esposa legítima, e adultério se a tem. Ora, o fato de ter relações
carnais pela fornicação e pelo adultério não causa nenhuma irregularidade. Logo, nem o referido modo
de bigamia.

3. Demais. ─ Pode um antes de ter cópula carnal com a que é esposa de direito, contrair com outra um
liame de fato e não de direito, e com esta ter conjunção, quer durante a vida quer depois da morte da
primeira. Ora, esse tal contraiu um liame com duas, quer de direito, quer de fato, e contudo não é
irregular, porque não dividiu o seu corpo com várias. Logo, desse modo a bigamia não implica
irregularidade.

SOLUÇÃO. ─ A segunda e a terceira espécie de bigamia fazem contrair irregularidade; porque embora
em um e outro caso não haja sacramento, há porém uma certa semelhança de sacramento. Por isso,
esses dois modos são secundários, ao passo que o primeiro é principal, como causas da irregularidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora no caso figurado não haja sacramento, há
contudo uma semelhança dele, que não há na fornicação nem no concúbito adulterino. Logo, o símile
não colhe.
Donde se deduz a resposta à segunda.

RESPOSTA À TERCEIRA. ─ Nesse caso não é o homem bígamo, porque o primeiro matrimônio não teve a
sua perfeita significação. ─ Contudo, se por juízo da Igreja for compelido a retomar à primeira mulher e a
ter relações com ela, por isso mesmo incorre em irregularidade, resultante, não do pecado, mas da
significação imperfeita.

## Art. 3 — Se incorre em irregularidade quem casou com uma não virgem.
O terceiro discute-se assim. ─ Parece que não incorre em irregularidade quem casou com uma não
virgem.
1 . Pois, maior impedimento nos causa um defeito próprio que o alheio. Ora, o fato de o contraente não
ser virgem não gera nenhuma irregularidade. Logo e com maior razão, se não no for a mulher.

2. Demais. ─ Pode acontecer que um homem deflore a mulher com a qual depois veio a casar. Ora, esse
não contrai nenhuma irregularidade, porque, como a sua esposa, não dividiu com mais de uma o seu
corpo; e contudo casou com uma mulher já deflorada. Logo esse modo de bigamia não causa nenhuma
irregularidade.

3. Demais. ─ Ninguém pode contrair irregularidade senão voluntariamente. Ora, pode um casar
involuntariamente com uma não virgem; assim, se a cria virgem e depois de ter tido relação com ela
verificou que já estava deflorada. Logo, esse modo nem sempre causa irregularidade.

4. Demais. ─ A cópula ilegítima subsequente ao matrimônio é mais grave que a antecedente. Ora, se a
mulher, depois de consumado o matrimônio, teve relação carnal com outro, seu marido não se torna
irregular. Do contrário, seria punido pelo pecado da esposa. E também pode dar-se que, depois de o ter
sabido, cumpra para com ela, que lh'o pede, o dever conjugal antes de ela acusada de adultério, ser
condenada. Logo, parece que esse modo de bigamia não causa irregularidade.
Mas, em contrário, Gregório diz: mandamos nunca faças ordenações ilícitas nem permitas receber as
ordens sagradas um bígamo, quem, não casou com uma mulher virgem, quem for iletrado, um
defeituoso em qualquer parte do corpo, um penitente, ou o atingido por uma acusação, ou submetido a
qualquer outra condição.

SOLUÇÃO. ─ Na conjunção entre Cristo e a Igreja, há unidade de lado a lado. E, assim há deficiência no
sacramento se qualquer dos cônjuges já havia contraído outro matrimônio. Mas diversamente: pois, do
marido se exige que não haja casado com outra, e não que seja virgem; e da mulher se exige que
também seja virgem.
E disso os decretistas dão a razão seguinte. O esposo significa a Igreja militante, a cuja testa está o bispo
e que é susceptível de muitas corruptelas; ao passo que a esposa significa a Cristo, que foi virgem. Por
isso é exigida da esposa a virgindade, mas não do esposo, para poder ascender ao episcopado. ─ Mas
esta razão vai diretamente contra as palavras do Apóstolo: Vós, maridos, amai a vossas mulheres, como
também Cristo amou à Igreja. Donde se colhe que a esposa significa a Igreja e o esposo, Cristo. E o
Apóstolo ainda continua: Porque o marido é a cabeça da mulher como Cristo é a cabeça da Igreja. Por
isso outros ensinam, que o esposo significa a Cristo, e a esposa a Igreja triunfante sem nenhuma mácula.
Cristo porém teve primeiro a Sinagoga como concubina; e assim nada tolhe à perfeita significação do
sacramento o ter o esposo tido antes uma concubina. ─ Mas isto é de todo absurdo. Porque como é uma
só a fé dos antigos e dos modernos, assim uma só e a Igreja. Por isso, os que no tempo da Sinagoga,
serviam a Deus, pertenciam à unidade da Igreja, na qual lhe servimos nós. Além disso uma tal opinião
vai expressamente contra certos lugares da Escritura, onde se faz menção clara dos desponsórios de
Cristo com a Sinagoga. Logo, não lhe era esta concubina, mas esposa. Além disso, segundo esse modo
de ver, a fornicação seria o sacramento dessa conjunção, o que é absurdo. Por isso a gentilidade, antes
de desposada por Cristo, na fé da Igreja, foi corrompida pelo diabo por meio da idolatria.
Devemos, pois, de outro modo, pensar que é a deficiência do sacramento a causa da irregularidade.
Pois, a corrupção da carne, anterior ao matrimônio, não causa nenhum defeito ao sacramento, relativo
à parte que a sofreu, mas, à outra parte. Porque o ato de contrair matrimônio não recai sobre o sujeito
mesmo que o pratica, mas sobre a outra parte. Por isso é especificado pelo seu termo, que também é,
em relação a esse ato, como a matéria do sacramento. Por onde, se a mulher pudesse receber o
sacramento da ordem, assim como o homem se torna irregular por casar com uma mulher já deflorada,
mas não por contrair casamento sem ser virgem, assim também a mulher incorreria em irregularidade
se casasse com um não virgem, mas não se o fizesse já não sendo virgem, salvo se já tivesse sido
deflorada em outro casamento.
Donde se deduz a resposta à primeira objeção.

RESPOSTA À SEGUNDA. - Sobre esse caso divergem as opiniões. Contudo é mais provável não ser esse
tal irregular, por que não dividiu o seu corpo com mais de uma.

RESFOSTA À TERCEIRA. ─ A irregularidade não é uma pena infligida, mas um defeito na recepção do
sacramento. Por onde, não é necessário que sempre seja voluntária a bigamia, para causar
irregularidade. Portanto, quem casou com uma mulher já deflorada, crendo-a virgem, incorre em
irregularidade tendo relação carnal com ela.

RESPOSTA À QUARTA. ─ O fato de a mulher claudicar, depois de contraído o casamento, não torna
irregular o marido; salvo se este tiver relações repetidas com ela depois de a saber adúltera; porque de
outro modo, a corrupção da mulher de maneira nenhuma cai sob o ato matrimonial do marido. Se este
porém for compelido pelo direito a cumprir para com ela o dever conjugal, ou se o fizer por vontade
própria para lhe aceder ao desejo, antes da sua condenação como adúltera, torna-se irregular, embora
divirjam sobre isso as opiniões. Mas a opinião aqui exarada é a mais provável, porque no caso vertente
para haver irregularidade não é necessário que haja pecado, mas basta haver a significação do
sacramento.

## Art. 4 — Se a bigamia desaparece pelo batismo.
O quarto discute-se assim. ─ Parece que a bigamia desaparece pelo batismo.

1. Pois, como diz Jerônimo, quem antes do batismo teve mais de uma mulher, ou uma antes e outra
depois dele, não é bígamo.

2. Demais. ─ O que faz o mais faz o menos. Ora, o batismo faz desaparecer qualquer pecado, que é mais
grave que a irregularidade. Logo, faz desaparecer a irregularidade da bigamia.

3. Demais. ─ O batismo faz desaparecer toda a pena que um ato merece. Ora, tal é a irregularidade da
bigamia. Logo, etc.

4. Demais. ─ O bígamo é irregular porque o seu casamento não simboliza a união de Cristo com a Igreja.
Ora, pelo batismo nós nos conformamos plenamente com Cristo. Logo, o batismo faz desaparecer essa
irregularidade.

5. Demais. ─ Os sacramentos da lei nova são mais eficazes que os da lei velha. Ora, os sacramentos, da
lei velha faziam desaparecer as irregularidades, como o disse o Mestre das Sentenças.
Logo, também o batismo, o eficassíssimo dos sacramentos da Lei Nova, faz desaparecer a irregularidade
contraída pela bigamia.
Mas, em contrário, diz Agostinho: Mais agudamente pensaram os que entenderam que não podia
ordenar-se o catecúmeno ou o pagão que tiveram mais de uma esposa; pois, trata-se, no caso, do
Sacramento e não do pecado.

2. Demais. ─ Como diz ainda Agostinho, a mulher catecúmena ou pagã deflorada não pode, depois do
batismo, ser consagrada como virgem a Deus. Logo, pela mesma razão, nem o bígamo pode-se ordenar,
antes do batismo.

SOLUÇÃO. ─ O batismo dele as culpas mas não dissolve a união conjugal. Por onde, se do casamento
mesmo resultar uma irregularidade, não pode esta fazê-la desaparecer o batismo, como diz Agostinho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ No caso vertente não é defensável a opinião de Jerônimo:
salvo se a quisessemos entender como referente a uma dispensa mais fácil.

RESPOSTA À SEGUNDA. ─ Não é necessário que um agente, capaz de um efeito maior, seja o também
de um menor, salvo se a este se ordenar. O que não se dá no caso proposto, porque o batismo não se
ordena a fazer desaparecer a irregularidade.

RESPOSTA À TERCEIRA. ─ Isso deve entender-se das penas resultantes do pecado atual e que são como
infligidas e não a serem infligidas. Pois pelo batismo ninguém recupera a virgindade, nem a indivisão da
carne.

RESPOSTA À QUARTA. ─ O batismo se conforma com Cristo, quanto à virtude da alma, mas não quanto
ao estado da carne, considerada na sua virgindade ou na sua divisão.

RESPOSTA À QUINTA. ─ Essas irregularidades foram contraídas por causas leves não perpétuas. Por isso,
podiam desaparecer mediante esses sacramentos, ─ Além disso, estes eram ordenados para tal fim, o
que não se dá com o batismo.

## Art. 5 — Se é lícito dar dispensa a um bígamo.
O quinto discute-se assim. ─ Parece que não é lícito dar dispensa a um bígamo.
1 . Pois, determina uma decretal: não é licito conceder dispensa aos clérigos que, por vontade própria,
se uniram em matrimônio com uma segunda mulher, como se fossem aos bígamos.

2. Demais. ─ O direito divino não é susceptível de nenhuma dispensa. Ora, toda a legislação canônica
constitui direito divino. Logo, como o Apóstolo, numa Escritura canônica diz ─ Importa que o bispo seja
esposo de uma só mulher ─ parece que nesta matéria não pode haver dispensa.

3. Demais. ─ Ninguém pode ser dispensado no que é uma exigência essencial do sacramento. Ora,
sacramento da ordem necessariamente exige que ordenando não seja irregular; pois, a irregularidade
faz desaparecer a significação, e esta é essencial ao sacramento. Logo, essa matéria não é susceptível de
dispensa.

4. Demais. ─ O que teve razão de se fazer não pode mudar-se sem razão. Se, pois, a razão persuade que
se de dispensa ao bígamo, não é racional fazê-lo incorrer em irregularidade por causa da sua bigamia. O
que é inadmissível.
Mas, em contrário. ─ Lúcio Papa concedeu dispensa ao bispo de Palermo, que era bígamo.

2. Demais. ─ Martinho Papa (Bracarense) diz: O leitor que foi casado com viúva permaneça no seu
leitorado; se a necessidade o exigir, ascenda ao subdiaconato, mas não mais além; O mesmo se dará se
foi bígamo. Logo, pelo menos até ao subdiaconato, pode-se conceder dispensa.

SOLUÇÃO. ─ A bigamia não anda anexa à irregularidade, por direito natural, mas por direito positivo. ─
Nem a ordem essencialmente exige que o ordenando não seja bígamo; e a prova está em que o bígamo
que se ordenar recebe o caráter. Portanto, o Papa pode dispensar totalmente em tal irregularidade; e o
bispo, quanto às ordens menores. E certos (Alb. Magno) dizem até, que quanto às ordens maiores, se se
trata de quem quer servir a Deus em religião, para evitar viagens, que do contrário, deveriam fazer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essa decretal mostra que há a mesma dificuldade em
conceder dispensa aos que de fato contraíram matrimônio mais de uma vez, como se de direito o
fizessem; não que o Papa fique privado, absolutamente falando, do poder de dispensar em tais casos.

RESPOSTA À SEGUNDA. ─ Isso é verdade em matéria de direito natural e ao que é essencial aos
sacramentos e à fé. Mas no mais que foi instituído pelos apóstolos, a Igreja tem atualmente o mesmo
poder de estatuir e de dispensar, que tinha outrora. Por isso pode, mediante aquele que nela tem o
primado, conceder dispensas.

RESPOSTA À TERCEIRA. ─ Não é qualquer significação que é da essência do sacramento, mas só a
pertinente à função dele ; e essa não fica tolhida pela irregularidade.

RESPOSTA À QUARTA. ─ Dos casos particulares não se pode concluir um princípio geral aplicável
igualmente a todos, por causa da diversidade deles. Por isso, o que foi racionalmente estatuído de um
modo geral, considerados os casos mais frequentes, pode também ser racionalmente removido, pela
dispensa, em algum caso determinado.