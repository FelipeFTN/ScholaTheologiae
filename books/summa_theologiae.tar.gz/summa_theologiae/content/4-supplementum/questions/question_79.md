# Questão 79: Das condições dos ressurrectos e, primeiro, da identidade deles.
Em seguida devemos tratar das condições dos ressurrectos. Sobre o que devemos, primeiro tratar do
que respeita primeiro aos bons e aos maus. Segundo, do que concerne só aos bons. Terceiro, do que
respeita só aos maus. Ora, três coisas concernem em comum aos bons e aos maus; a identidade, a
integridade e a qualidade deles. E primeiro devemos tratar da identidade dos ressurrectos. Segundo da
integridade dos seus corpos. Terceiro, da qualidade deles.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se a alma retomará, na ressurreição, o mesmo corpo a que estava unida antes.
O primeiro discute-se assim. ─ Parece que a alma não retomará, na ressurreição, o mesmo corpo a
que o estava unida antes.

1. ─ Pois, diz o Apóstolo: Quando tu semeias, não semeias o corpo da planta que há de nascer, senão o
mero grão. Ora, o Apóstolo aí compara a morte ao ato de semear, e a ressurreição, a germinação. Logo,
a alma não retomará, na ressurreição, o mesmo corpo de que se separou na morte.

2. Demais. ─ A matéria deve adaptar-se à condição da sua forma; do mesmo modo, o instrumento, à do
agente. Ora, o corpo está para a alma como a forma para a matéria, e como o instrumento para o
agente. Mas a alma, depois da ressurreição, não estará na mesma condição em que agora está, porque
ou será alçada à vida celeste, se já neste mundo viveu na expectativa dela; ou será rebaixada a uma vida
de bruto, se como bruto viveu neste mundo. Logo, parece que não retomará o mesmo corpo de antes,
mas um corpo celeste ou um animal.

3. Demais. ─ O corpo humano se resolverá, depois da morte, nos seus elementos, como se disse. Ora,
aquelas partes elementares em que o corpo se resolveu, não convêm com o corpo humano, nelas
resoluto, senão pela matéria prima. Modo pelo qual quaisquer outras partes dos elementos convêm
com esse corpo. Se, portanto, o corpo fosse formado de outras partes elementares, já não seria
identicamente o mesmo. Logo, também identicamente o mesmo não seria se fosse reconstituído pelas
referidas partes.

4. Demais. ─ É impossível um corpo conservar a sua identidade individual se as suas partes essências são
individualmente heterogêneas. Ora a forma do misto, que, como forma, é parte essencial do corpo
humano, não pode ser retomada na sua identidade individual. Logo, o corpo não será identicamente o
mesmo. ─ Prova da média. O que cai totalmente em a não existência não pode ser retomado na sua
identidade individual. Pois, é claro, que não conserva a sua identidade individual o ser cuja existência é
diversa; mas a existência interrompida, que é um ato do ser, é diversa. Ora, a a forma do misto cai
totalmente em a não existência pela morte, por ser uma forma corpórea. E semelhantemente as
qualidades contrárias, donde resulta a mistão. Logo, a forma do misto não poderá voltar a ser
individualmente a mesma.
Mas, em contrário, a Escritura: Na minha própria carne verei a Deus meu salvador. E se refere à visão
após a ressurreição, como claramente o mostra o que precede: No derradeiro dia ressurgirei da terra.
Logo, será o corpo identicamente o mesmo que ressurgirá.

2. Demais. ─ Como diz Damasceno, a ressurreição consiste em o corpo morto surgir de novo à vida. Ora,
o corpo que agora temos pereceu pela morte. Logo, ressurgirá idêntica e individualmente o mesmo.

SOLUÇÃO. ─ Sobre esta questão tanto erraram certos filósofos como alguns heréticos modernos.
Assim, certos filósofos ensinaram que as almas separadas do corpo voltam a se unir com ele. Mas assim
pensando, erravam em dois pontos. Primeiro, quanto ao modo de união; porque uns ensinavam que a
alma separada de novo se une naturalmente ao corpo por via de geração. Segundo, quanto ao corpo a
que se unia a alma. Pois, afirmavam que a segunda união não era identicamente com o mesmo corpo,
de que pela morte se tinha separado, mas com outro, ora especificamente idêntico, ora diverso. Com
um corpo diverso, quando a alma, enquanto unida ao corpo, levou uma vida contrária à alma racional;
por isso passava, depois da morte, do corpo humano para o corpo do animal a cujo gênero de vida se
havia conformado. Assim, num corpo de cão, se viveu entregue à luxúria; no do leão, se praticou rapinas
e violências, e assim por diante. Com um corpo da mesma espécie porém, quando a alma, levando uma
vida racional enquanto unida ao corpo, depois de ter gozado de uma certa felicidade, após a morte,
começava, decorridos alguns séculos, a querer voltar a unir-se ao corpo; e assim de novo se unia ao
corpo humano.
Ora, esta opinião se assenta em dois princípios errôneos. O primeiro é afirmarem que a alma não está
unida ao corpo essencialmente, como a forma à matéria, mas só acidentalmente como o motor ao
móvel, ou o homem ao seu vestuário. Daí podiam deduzir que a alma pré existia antes de ser infundida
ao corpo gerado pela geração natural; e que também podia unir-se a corpos diversos. ─ O segundo é o
admitirem que o intelecto não difere dos sentidos senão acidentalmente; e assim diziam que o homem,
ao contrário dos irracionais, tem intelecto, por ter uma potência sensitiva mais perfeita em virtude da
sua melhor compleição corpórea. Donde podiam concluir que a alma humana poderia se unir ao corpo
de um bruto, sobretudo se viveu uma vida própria de brutos.
Ora, esses dois princípios referidos o Filósofo os refuta cabalmente; e refutados eles fica a nu a falsidade
dessa opinião.
Do mesmo modo se refutam os erros de certos heréticos. Desses, uns repetiram as referidas opiniões
dos filósofos. ─ Outros ensinaram que as almas se unirão de novo a corpos celestes ou ainda a corpos
subtis como o vento, como refere Gregório de certo bispo Constantinopolitano, quando expõe as
palavras de Job: Na minha própria carne verei a Deus, etc.
Além disso, os erros desses heréticos podem ser refutados por contrariarem a verdade da ressurreição,
proclamada pela Sagrada Escritura. Pois, não pode haver ressurreição senão voltando a alma a unir-se
de novo ao mesmo corpo; porque a ressurreição consiste em surgir de novo à vida. Ora, é o mesmo ser
que morre que ressurge. Por onde, a ressurreição mais respeita ao corpo, que se dissolve depois da
morte, que a alma que vive depois da morte. Portanto, se o corpo que a alma reassume não é o mesmo
a que esteve unida, não poderemos falar de ressurreição, mas antes de assunção de um novo corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A comparação citada não se aplica totalmente, mas só
em parte. Pois, na semeadura do grão, o grão semeado não idêntico individualmente ao germinado;
nem se apresenta do mesmo modo porque quando semeado não tinha folículos, que tem quando
germina. Ao contrário, o corpo ressurrecto será individualmente idêntico ao morto, mas com atributos
diversos, pois, de mortal, que era, ressurge imortal.

RESPOSTA À SEGUNDA. ─ A diferença entre a alma de um ressurrecto e a do que ainda vive neste
mundo não é fundada em nada de essencial, mas na glória e na miséria, que causam uma diferença
apenas acidental. Por onde, não é necessário que o corpo ressurrecto seja diferente do que morreu,
mas basta que tenha atributos diferentes, a fim de a diferença dos corpos ser proporcionada à das
almas.

RESPOSTA À TERCEIRA. ─ O que se concebe na matéria, anteriormente à forma, nela subsiste depois da
corrupção; pois, removido o posterior, pode ainda permanecer o anterior. Ora, como nota o
Comentador na matéria dos seres sujeitos à geração e à corrupção concebe-se, antes da forma
substancial, dimensões indeterminadas, nas quais se funda a divisão da matéria, de modo que partes
diversas dela possam receber formas diversas. Por onde, depois de a forma substancial se separar da
matéria, ainda essas dimensões permanecem as mesmas. E assim, a matéria existente com essas
dimensões, seja qual for a forma que recebam, tem maior identidade com o que dela foi gerado, que
qualquer outra parte da matéria existente sob qualquer outra forma. Por onde, na reconstituição do
corpo humano será aplicada a mesma matéria de que antes fora feito.

RESPOSTA À QUARTA. ─ Assim como uma qualidade simples não é a forma substancial do elemento,
mas um acidente próprio dele e uma disposição que torna a matéria própria a tal forma, assim a forma
do misto, qualidade resultante de qualidades simples, numa união proporcional, não é forma
substancial do corpo misto, mas um acidente próprio e uma disposição que torna a matéria necessária à
forma. Ora, o corpo humano, além dessa forma de mistão, não tem nenhuma outra forma substancial
senão a alma racional; pois, se tivesse outra forma substancial anterior, essa dar-lhe-ia o ser substancial
e então ficaria constituído por ela no gênero da substância. E assim a alma viria a unir-se a um corpo já
constituído no gênero da substância. E então a alma estaria para o corpo como as formas artificiais para
as suas matérias, se se leva em conta que por esta ficam constituídas no gênero da substância. Por
onde, a união da alma e do corpo seria acidental ─ erro dos antigos Filósofos, refutados pelo Filósofo. E
daí também se seguiria que o corpo humano e cada uma das suas partes não podiam mais conservar,
depois da união com a alma, as mesmas denominações que tinham antes; o que vai contra o que ensina
o Filósofo. Portanto, como a alma racional é imortal, nenhuma forma substancial do corpo humano é
totalmente reduzida ao não ser. Quanto à variação das formas acidentais, não produz nenhuma
diversidade numérica. Portanto, será o mesmo corpo, individualmente, que ressurgirá, pois a alma
retomará a mesma matéria anterior, como dissemos na resposta à objeção precedente.

## Art. 2 — Se o mesmo homem individualmente é quem ressurgirá.
O segundo discute-se assim. - Parece que não é o mesmo homem individualmente quem ressurgirá.

1. - Pois, como diz o Filósofo, seres com forma sujeita à corrupção e ao movimento não se reproduzem
na sua realidade individual. Ora, tal é a substância do homem na vida presente. Logo, não pode, depois
de sofrida a mudança causada pela morte, renascer individualmente o mesmo.

2. Demais. ─ Onde há humanidades diferentes não há um mesmo homem. Por isso, Sócrates e Platão
são dois homens e não um só, porque difere a humanidade em ambos. Ora, a humanidade do
ressurrecto não é a mesma da que teve neste mundo. Logo, o ressurrecto não é o mesmo homem que
antes viveu. ─ A proposição média é susceptível de dupla prova. Primeiro, porque a humanidade, que é
a forma do todo, não é uma forma e substância, como a alma, mas é apenas forma. Ora, tal forma pode
reduzir-se completamente ao não-ser, e portanto não pode reiterar-se. Segundo, porque a humanidade
resulta da união das partes. Ora, uma união anteriormente existente não pode reiterar-se
identicamente a mesma, porque essa reiteração opõe-se à identidade; pois, implica pluralidade, ao
passo que a identidade supõe a unidade; ora, pluralidade e unidade se excluem. Mas a união se
reiterará, na ressurreição. Logo, não será a mesma união. E portanto, nem a mesma humanidade, nem o
mesmo homem.

3. Demais. ─ Não há um mesmo homem onde há vários animais. Logo, não sendo o animal o mesmo,
não será o homem individualmente o mesmo. Ora, onde não há o mesmo sentido não há o mesmo
animal, porque o animal se define primariamente pelo sentido do tato, como está claro em Aristóteles.
Ora, não havendo mais sentido na alma separada, como certos dizem, não pode ser reassumido idêntico
ao que existia antes. Logo, na ressurreição o homem ressurrecto não será o mesmo ser animal que
antes era. Portanto, nem o mesmo homem.

4. Demais. ─ A matéria da estátua mais principalmente a constitui do que constitui o homem a sua
matéria; porque os seres artificiais a sua matéria os coloca totalmente no gênero da substância, ao
passo que os naturais entram nesse gênero pela sua forma, como o prova o Filósofo e o Comentador.
Ora, uma estátua feita do mesmo bronze, de outro já não será individualmente a mesma de antes. Logo
e com maior razão, o homem reconstituído das mesmas cinzas já não será individualmente o mesmo
que antes fora.
Mas, em contrário, a Escritura: A quem eu mesmo hei de ver e não outro, referindo-se à visão após a
ressurreição. Logo, ressurgirá o homem idêntica e individualmente o mesmo.

2. Demais. ─ Agostinho diz, que ressurgir não é senão tornar a viver. Ora, não diríamos que reviveu
portanto nem que ressurgiu se não voltou à vida o mesmo homem que antes morreu. O que é contra a
fé.

SOLUÇÃO. ─ É necessário admitir a ressurreição, dado que o homem deve alcançar o fim último para o
qual foi feito, e que não pode alcançar nesta vida nem na da alma separada do corpo. Aliás, o homem
teria sido constituído em vão se não pudesse chegar ao fim para que foi feito. Ora, um ser deve atingir
sempre individualmente idêntico a si próprio, o fim para que foi feito; do contrário teria sido feito em
vão. Portanto, o homem há de ressurgir idêntico ao que individualmente existiu antes. E isto se dá
ficando a mesma alma, individualmente idêntica a si própria, unida ao corpo individualmente o mesmo
a que neste mundo esteve unida. Aliás não haveria propriamente ressurreição, se não fosse o mesmo
homem o reconstituído. Por onde, afirmar que o ressurrecto não é idêntico ao que individualmente
existiu antes, é herético e contrário à verdade da Escritura, que prediz a ressurreição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O Filósofo se refere à reiteração pelo movimento ou pela
mutação natural. Pois, mostra a diferença entre o movimento circular da geração e da corrupção e o do
movimento circular do céu. Porque o céu, pelo movimento local, volta, identicamente o mesmo, ao
princípio desse movimento; por ser uma substância incorruptível movida. Ao passo que os seres sujeitos
à geração e à corrupção voltam ao mesmo tempo específico mas não individual. Assim, de um homem
nasce o sangue, deste o sêmen e assim por diante, até chegar-se a outro homem idêntico ao primeiro
pela espécie mas não individualmente. Do fogo nasce o ar, donde a água, donde a terra, donde de novo
o fogo, idêntico ao primeiro, não individual, mas especificamente. Por onde é claro que a razão aduzida
não vem, na intenção do Filósofo, a propósito.
Ou devemos responder que a forma dos seres sujeitos à geração e à corrupção não é por si subsistente,
de modo a poder continuar a existir depois da corrupção do composto. O contrário se dá com a alma
racional, que conserva, mesmo depois da separação do corpo, o ser que nele tinha. E na ressurreição, o
corpo será participante dessa existência; porque quando unida ao corpo, não tem a alma uma existência
distinta da dele; aliás a união de ambos seria acidental. E assim nenhuma interrupção sofrerá a
existência substancial do homem a ponto de por causa dessa interrupção, não poder voltar a ser
idêntico ao que individualmente antes era; ao contrário do que se dá com os outros seres corruptíveis,
cuja existência desaparece totalmente com a separação da forma, porque a matéria deles assume outra
existência.
Pois, nem o próprio homem retoma, pela geração natural, a mesma existência individual. Porque o
corpo gerado do homem não se forma da matéria total do gerador. Por onde, há diversidade numérica
no corpo e, por consequência na alma e em todo o homem.

RESPOSTA À SEGUNDA. ─ Duas são as opiniões sobre a humanidade e sobre qualquer forma de um
todo. ─ Uns (S. A. Magno) dizem que a forma do todo é realmente idêntica à da parte; a forma da parte
é a que aperfeiçoa a matéria; a forma do todo é a de onde resulta na sua totalidade a noção de espécie.
E segundo esta opinião, a humanidade não é realmente diferente da alma racional. Por onde, como é
individualmente a mesma alma racional que ressurgirá, a humanidade será numericamente a mesma. E
esta subsistirá também depois da morte, embora não sob a noção de humanidade; porque, separado
dela, o composto não logra a sua natureza específica. ─ Outra opinião, e mais verdadeira é a de Avicena,
de acordo com a qual a forma do todo não é só a forma da parte, nem outra forma qualquer, diversa da
parte, mas é o todo resultante da composição da forma e da matéria, compreendendo em si ambas. E
essa forma do todo é chamada essência ou quididade. Logo, como na ressurreição o corpo será
identicamente o mesmo de antes, e identicamente a mesma será a alma racional, por força a mesma
também há de ser a humanidade.
Ora, a primeira opinião, de acordo com a qual a humanidade do ressurrecto será diferente da atual,
procederia se a humanidade fosse uma outra forma superveniente à forma e à matéria. O que é falso. A
segunda também não pode obstar a identidade da forma humana. Porque união significa ação ou
paixão. As quais, embora diversas, não podem impedir a identidade da forma humana; pois, a ação e a
paixão, de que se compunha a humanidade, não são da essência desta e portanto a diversidade delas
não implica a diversidade humana. Assim, a geração e a ressurreição não são um mesmo movimento,
nem por isso contudo fica impedida a identidade do ressurrecto com o gerado. ─ Semelhantemente, não
fica impedida a identidade da humanidade, se tomarmos a união como relação. Porque essa relação não
é da essência da humanidade, mas dela resulta. Pois, a humanidade não é daquelas formas, que
consistem, como as formas dos artefatos, em composição e ordem, segundo ensina o Filósofo. Portanto,
sobrevindo outra composição diferente a uma casa já a sua forma não será identicamente a mesma que
antes era.

RESPOSTA À TERCEIRA. ─ A objeção conclui otimamente contra os que diziam ser a alma sensível e
racional diversas no homem. Porque então a alma sensitiva do homem não seria, como a dos brutos,
incorruptível. Por onde, o ressurrecto não teria a mesma alma sensível e por consequência não seria o
mesmo animal nem o mesmo homem que antes fora. Se porém admitirmos que no homem a mesma
alma é, na sua substância, racional e sensível, não cairemos nessas dificuldades. Pois, o animal é
definido pelo sentido, enquanto alma sensitiva, como pela sua forma essencial; e, pelo sentido,
enquanto potência sensitiva, conhecemos-lhe a definição, como pela forma acidental, que sobretudo
contribui para conhecermos a quilididade, na expressão de Aristóteles. Ora, depois da morte, subsiste
substancialmente tanto a alma sensível como a alma racional. Mas as potências sensitivas, segundo
certos, não perduram. Essas potências porém, sendo propriedades acidentais, suas variações não
podem destruir totalmente a identidade do animal, nem mesmo das partes deste. Nem se chamam as
potências perfeições ou atos dos órgãos senão por serem os princípios do agir, como o calor o é, do
fogo.

RESPOSTA À QUARTA. ─ Uma estátua pode ser considerada a dupla luz: como uma determinada
substância ou como obra de arte. E como entra no gênero da substância em razão da sua matéria, por
isso, considerada enquanto substância, a segunda estátua, feita com a matéria da primeira, é
individualmente idêntica a esta.
Mas pertence ao gênero das obras de arte, enquanto forma, que é um acidente, e desaparece com a
destruição da estátua. Portanto, não pode mais reaparecer na sua identidade numérica nem poderia
mais voltar a ser numericamente a mesma estátua de antes. Ora, a forma do homem, i. é, a alma,
subsiste depois da dissolução do corpo. Portanto, não há símile.

## Art. 3 — Se as cinzas de um corpo humano devem, na ressurreição, voltar a constituir a mesma parte do corpo que nelas se dissolveu.
O terceiro discute-se assim. ─ Parece que as cinzas de um corpo humano devem, na ressurreição,
voltar a constituir a mesma parte do corpo que nelas se dissolveu.

1. ─ Pois, segundo o Filósofo, assim está toda a alma para todo o corpo, como uma parte da alma para
uma parte do corpo; p. ex., o sentido da vista, para a pupila. Ora, depois da ressurreição o mesmo corpo
há de ser reassumido pela mesma alma. Logo, também as mesmas partes do corpo virão a formar os
mesmos membros, partes identicamente as mesmas de que a alma se servia como de órgãos.

2. Demais. ─ A diversidade material produz a diversidade numérica. Ora, se as cinzas não voltarem a
constituir as mesmas partes a que pertenceram, essas partes já não serão formadas da mesma matéria
de que antes eram feitas. Logo, já não serão numericamente as mesmas. Ora, sendo diversas as partes,
também diverso há de ser o todo, pois, as partes estão para o todo como a matéria para a forma, na
expressão do Filósofo. Logo, o ressurrecto não será idêntico ao que antes era. O que colide contra a
verdade da ressurreição.

3. Demais. ─ O fim da ressurreição é fazer com que cada um receba a recompensa das suas obras. Ora, a
obras diversas, meritórias ou demeritórias, foram executadas por partes diversas do corpo. Logo, na
ressurreição, há de cada parte voltar ao seu estado, a fim de ser premiada como merece.
Mas, em contrário. ─ Os seres artificiais dependem mais estreitamente da sua matéria, que os naturais.
Ora, nas cousas artificiais não é necessário, para reparar uma obra com a mesma matéria, que as partes
dessa matéria sejam colocadas no mesmo lugar. Logo, nem é necessário que tal se de com o homem.

2. Demais. ─ A variação do acidente não causa a diversidade numérica. Ora, a situação das partes é um
acidente. Logo, a sua diversidade no homem não produz nenhuma diversidade numérica.

SOLUÇÃO. ─ A questão vertente assume um aspecto diferente conforme se considera o que se poderá
fazer, na ressurreição, sem prejuízo da identidade, ou o que se fará para conservar a conveniência.
Quanto ao primeiro ponto, devemos saber que é possível considerarem-se no homem duas espécies de
partes diferentes: partes diferentes de um todo homogêneo, assim, diferentes partes de carne ou de
ossos; ou partes de diversas espécies de um todo heterogêneo, como os ossos ou a carne. ─ Se, pois,
dissermos, que na ressurreição, uma parte voltará a unir-se a outra parte da mesma espécie, isso
nenhuma variedade causará senão na situação das partes. Ora, a situação diversa das partes não varia a
espécie de um todo homogêneo. Por onde, se a matéria de uma parte voltar a unir-se com outra,
nenhum detrimento daí advirá para a identidade do todo. E isso se dá no exemplo citado pelo Mestre: a
estátua não volta a ser numericamente a mesma na sua forma, mas na sua matéria, enquanto uma
determinada substância que é; e assim a estátua é homogênea, embora não por uma forma artificial. ─
Se se disser porém que a matéria de uma parte volta a unir-se a outra de espécie diferente, isso acarreta
necessariamente a alteração não só da situação das partes, como também da identidade delas. Mas
contanto que o transferido de uma para a outra parte seja a matéria total, o que verdadeiramente
pertencia à natureza humana; não porém, se o supérfluo numa parte fosse o transferido para outra.
Ora, desaparecida a identidade das partes, destruída fica a do todo, se se trata de partes essenciais; mas
não se nos referimos a partes acidentais, como os cabelos e as unhas, a que se refere Agostinho. ─ Por
onde é claro que transferência da matéria de uma parte para a outra é a que tolhe a identidade do todo
e qual a que não tolhe.
Se se trata porém de conservar a conveniência, é mais provável que na ressurreição se conservará a
mesma situação das partes, sobretudo a das partes essenciais e orgânicas; embora não talvez a das
acidentais, como as unhas e os cabelos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A objeção colhe quanto às partes orgânicas e não quanto
às semelhantes.

RESPOSTA À SEGUNDA. ─ A situação diversa das partes da matéria não produz a diversidade numérica
das mesmas, embora o produza a diversidade da matéria.

RESPOSTA À TERCEIRA. ─ Uma operação, propriamente falando, não pertence à parte, mas ao todo. Por
onde, prêmio não é devido à parte, mas ao todo.
