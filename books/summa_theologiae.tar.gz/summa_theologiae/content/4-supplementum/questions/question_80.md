# Questão 80: Da integridade do corpo dos ressurrectos.
Em seguida devemos tratar da integridade do corpo dos ressurrectos.
E nesta questão discutem-se cinco artigos:

## Art. 1 — Se todos os membros do corpo humano ressurgirão.
O primeiro discute-se assim. ─ Parece que nem todos os membros do corpo humano ressurgirão.

1. ─ Pois, removido o fim, é inútil lançar mão dos meios a ele conducentes. Ora, o fim de cada membro é
o seu ato. Mas nada há de vão nas obras divinas; e de certos membros o homem não mais se servirá
depois da ressurreição, sobretudo dos genitais, porque então, nem as mulheres terão maridos, nem os
maridos mulheres. Logo, parece que nem todos os membros ressurgirão.

2. Demais. ─ Os intestinos também são partes do corpo. Ora, não ressurgirão. Pois, não poderão
ressurgir cheios das imundícias que contêm. Nem vazios, porque não há vácuo em a natureza. Logo,
nem todas as partes do corpo ressurgirão.

3. Demais. ─ O corpo ressurgirá para ser premiado pelas obras que a alma praticou por meio dele. Ora, o
membro amputado pelo furto cometido, a um ladrão, que porém fez depois penitência e se salvou, não
pode ser remunerado na ressurreição ─ nem por um bem praticado, pois para tal não cooperou; nem
pelo mal, pois a pena imposta a um membro redundaria em pena do homem. Logo, nem todos os
membros do ressurrecto ressurgirão.
Mas, em contrário. ─ Mais verdadeiramente constituem a natureza humana os outros membros, que os
cabelos e as unhas. Ora, estes restituir-se-ão aos resurrectos, como diz o Mestre. Logo e com maior
razão, os outros membros.

2. Demais. ─ As obras de Deus são perfeitas, diz a Escritura. Ora, a ressurreição será obra divina. Logo, o
ressurrecto se reconstituirá perfeito em todos os membros.

SOLUÇÃO. ─ Como diz Aristóteles, a alma exerce, no corpo, não só a função de forma e de fim, mas
também a de causa eficiente. Pois, a alma está para o corpo como a arte para o artefato, no dizer do
Filósofo. Ora, tudo o que explicitamente se mostra no artefato estava já contido implícita e
originariamente na arte. Assim também tudo o que se revela nas partes do corpo, já está original e de
certo modo implicitamente na alma. Mas, assim como a obra artística não seria perfeita se algo lhe
faltasse do que a arte contém, assim nem o homem poderia ser perfeito se não se manifestasse
externamente no corpo tudo o contido implicitamente pela alma. Nem então o corpo corresponderia à
alma de maneira plenamente proporcionada. Ora, na ressurreição o corpo humano há de corresponder
totalmente à alma, pois não ressurgirá senão na sua relação com a alma racional. Logo, o homem há de
ressurgir perfeito, pois se reconstituirá para receber a sua última perfeição. Portanto, todos os membros
que o corpo humano tiver nesta vida hão de reconstituir-se na ressurreição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os membros podem considerar-se a dupla luz, nas suas
relações com a alma: ou na relação de matéria para forma, ou na de instrumento para agente. Ora, a
mesma relação existe entre todo o corpo e toda a alma, e das partes entre si, como ensina Aristóteles.
Se, pois, considerarmos os membros na primeira acepção, o fim deles não é a operação, mas antes, a
perfeição da espécie, necessária também depois da ressurreição. Se, porém, os considerarmos na
segunda acepção, então tem como fim a operação. Mas daí não se segue que o instrumento seja inútil
por não poder exercer a sua operação própria; pois, o instrumento serve não só para executar a ação do
agente, mas também para mostrar a sua virtude própria. Por onde, há de a virtude das potências da
alma se revelar mediante instrumentos corpóreos, embora estes nunca sejam usados, para assim
manifestar-se a sabedoria de Deus.

RESPOSTA À SEGUNDA. ─ Os intestinos ressurgirão com o corpo, assim como os outros órgãos. E
estarão cheios não de imundos excrementos, mas de humores nobres.

RESPOSTA À TERCEIRA. ─ Os atos pelos quais merecemos não pertencem, propriamente falando, às
mãos nem aos pés, mas ao homem total; assim como uma obra de arte não se atribui ao instrumento,
mas ao artífice. Embora portanto um membro mutilado antes da penitência, não tenha cooperado ao
estado glorioso merecido depois da ressurreição, contudo o homem completo é o que merece ser
premiado, pois serviu a Deus com tudo o que tinha.

## Art. 2 — Se os cabelos e as unhas ressurgirão com o corpo.
O segundo discute-se assim. ─ Parece que os cabelos e as unhas não ressurgirão com o corpo.

1. ─ Pois, assim como os cabelos e as unhas são gerados pela superfluidade da nutrição, assim também a
urina, o suor e fezes semelhantes. Ora, estas não ressurgirão com o corpo. Logo, nem os cabelos e as
unhas.

2. Demais. ─ Entre as outras superfluidades geradas pela alimentação, constitui por excelência a
natureza humana, em sua realidade, o sêmen, superfluidade necessária. Ora, o corpo humano não
ressurgirá com o sêmen. Logo e com muito maior razão, não hão de ressurgir os cabelos e as unhas.

3. Demais. ─ Nenhuma perfeição tem a alma racional que não tenha também a alma sensível. Ora, os
cabelos e as unhas não tem a perfeição da alma sensível, pois por eles não sentimos, como o explica
Aristóteles. Logo, como o corpo não ressurgirá senão para as perfeições da alma racional, parece que os
cabelos e as unhas não ressurgirão.
Mas, em contrário, o Evangelho: Não se perderá um cabelo da vossa cabeça.

2. Demais. ─ Os cabelos e as unhas foram dados como ornato para o homem. Ora, os corpos humanos,
sobretudo os dos eleitos, devem ressurgir com todos os seus ornatos. Logo, devem ressurgir com os
cabelos.

SOLUÇÃO. ─ A alma está para o corpo animado como a arte para o artificiado, e para as partes dele
como a arte para os seus instrumentos; por isso o corpo animado se chama orgânico. Ora, a arte usa de
certos instrumentos para executar a obra intencionada; e esses são os que lhe servem primariamente à
intenção. Mas também se serve de outros instrumentos para a conservação dos instrumentos principais;
e esses lhe servem secundariamente à intenção. Assim, a arte militar se serve da espada para a guerra; e
da bainha, para a conservação da espada. Do mesmo modo, das partes do corpo animado umas ─ como
o coração, o fígado, as mãos e os pés ─ se ordenam a executar as operações da alma; outras porém, à
conservação das demais partes, como as folhas servem para cobrir os frutos. Assim também os cabelos
e as unhas servem para resguardar as outras partes do corpo humano. Por isso pertencem
secundariamente à perfeição do corpo humano, embora não primariamente. E como o corpo ressurgirá
em toda a perfeição da sua natureza, por isso também os cabelos e as unhas hão de ressurgir com ele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A natureza expulsa aquelas superfluidades que para nada
são úteis e portanto não contribuem para a perfeição do corpo humano. Mas procede diferentemente
com aquelas superfluidades que conserva para a geração dos cabelos e das unhas, de que precisa para a
conservação dos membros.

RESPOSTA À SEGUNDA. ─ O sêmen não é necessário, como os cabelos e as unhas, para a perfeição do
indivíduo, mas só para a da espécie.

RESPOSTA À TERCEIRA. ─ Os cabelos e as unhas se nutrem e crescem; por onde é claro que participam
de uma certa, perfeição. O que não poderia dar-se se não fossem de algum modo partes perfeitas da
alma. E como o homem não tem senão uma alma única, que é a racional, resulta que as unhas e os
cabelos recebem da alma racional a sua perfeição. Embora não a ponto de participarem da atividade
sensível, como também se dá com os ossos, dos quais sabemos que ressurgirão e que pertencem à
integridade do indivíduo.

## Art. 3 — Se os humores ressurgirão com o corpo.
O terceiro discute-se assim. ─ Parece que os humores não ressurgirão com o corpo.
1 ─ Pois, o Apóstolo diz: A carne e o sangue não podem possuir o reino de Deus. Ora, o sangue é o
humor mais principal. Logo, não ressurgirá com o corpo dos bem-aventurados, que possuirão o reino de
Deus. Logo e com maior razão, não hão de ressurgir os outros humores.

2. Demais. ─ Os humores servem para reparar as perdas do corpo. Ora, depois da ressurreição o corpo
nenhuma perda sofrerá. Logo, o corpo não ressurgirá com os humores.

3. Demais. ─ O que está no corpo humano, em via de ser gerado, ainda não recebeu da alma racional a
sua perfeição. Ora, os humores, sendo carne e ossos em potência, estão ainda em via de ser gerados.
Logo, ainda não receberam a sua perfeição da alma racional. Ora, o corpo humano não é destinado à
ressurreição senão enquanto aperfeiçoado pela alma racional. Logo, os humores não ressurgirão com
ele.
Mas, em contrário. ─ O que pertence à constituição do corpo humano ressurgirá com ele. Ora, tais são
os humores, conforme Agostinho, que diz: O corpo consta de órgãos, os órgãos de partes similares, e
estas de humores. Logo, os humores ressurgirão com o corpo.

2. Demais. ─ A nossa ressurreição será conforme à de Cristo. Ora, Cristo ressurgiu com o sangue; aliás no
sacramento do Altar o vinho não se lhe transubstanciaria no sangue. Logo, também o nosso corpo
ressurgirá com sangue. E pela mesma razão, com os outros humores.

SOLUÇÃO. ─ Pela razão já dada, tudo o pertencente à integridade da natureza humana, no ressurrecto,
ressurgirá. Logo, há de ressurgir com o corpo aquele líquido pertencente à integridade da natureza
humana.
Ora, no corpo há três espécies de líquidos.
Uns, não contribuem para a perfeição do Indivíduo. Ou por estarem, como a urina, o suor, o puz e
outros, em via de corrupção e serem por isso expulsos; ou pelos ordenar a natureza para a conservação
da espécie em outro indivíduo, quer pelo ato da geração, como o sêmen. quer pela função nutritiva,
como o leite. E nenhum desses líquidos ressurgirá, por não pertencerem a perfeição do indivíduo
ressurrecto.
A segunda espécie de líquidos é a dos que ainda não chegaram à última perfeição que a natureza produz
no indivíduo, mas é ordenada a ela pela natureza. ─ E esta espécie é dupla. Porque certos líquidos tem
uma forma determinada inclusa entre as partes do corpo; assim o sangue e os outros três humores, que
a natureza ordenou a formar os órgãos, pela geração; mas tem certas formas determinadas, como
também as outras partes do corpo. E por isso com essas outras ressurgirão. ─ Outros líquidos porém
estão em via de passar de uma forma para outra, i. é, da forma de humor para a de órgão. E esses não
ressurgirão. Porque depois da ressurreição cada parte do corpo terá a sua forma fixada, de modo que
não poderá transformar-se em outra. Por isso não ressurgirá aquele líquido que está no ato mesmo de
passar de uma forma para outra. E esses podemos considerá-los num duplo estado. Ou enquanto estão
no princípio da transformação; e então se chama ros, que é o líquido existente nos orifícios das
pequenas veias, ou enquanto já numa transformação adiantada e começando a mudar de forma, e
então se chamam cambium. Ora, em nenhum desses estados ressurgirão.
A terceira espécie de líquido é o que já chegou à perfeição última visada pela natureza, no corpo do
indivíduo; já transformado e incorporado nos membros. E essa se chama gluten. E fazendo parte da
substância dos membros, ressurgirá, como ressurgirão os demais órgãos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Carne e sangue, nas palavras citadas do Apóstolo, não se
devem tomar pela substância da carne e do sangue, mas pelas obras da carne e do sangue, que são as
obras do pecado ou da vida animal. ─ Ou, segundo interpreta Agostinho, carne e sangue aí se tomam
pela corrupção agora dominante na carne e no sangue. Por isso o Apóstolo acrescenta as palavras: Nem
a corrupção possuirá a incorruptibilidade.

RESPOSTA À SEGUNDA. ─ Os membros que servem à geração concorrerão, depois da ressurreição, para
a integridade da natureza humana e não exercerão mais os atos que exercem nesta vida. Assim também
os humores existirão no corpo, não para restaurar as perdas, mas para contribuírem à integridade da
natureza humana e à manifestação da virtude dela.

RESPOSTA À TERCEIRA. ─ Assim como os elementos estão em via para a geração em relação aos corpos
mistos, por serem a matéria destes e não por estarem sempre se transformando para os produzir, o
mesmo se dá com os humores em relação aos membros. Por isso, assim como os elementos tem nas
partes do universo as suas formas determinadas, razão por que lhe constituem a perfeição, bem como
os corpos mistos, assim também os humores, como as outras partes, fazem parte da perfeição do corpo
humano, embora não alcancem, como as outras partes, a perfeição total; nem tenham os elementos
formas assim perfeitas como os mistos. Ora, assim como todas as partes do universo recebem de Deus a
sua perfeição, mas não igualmente, senão cada qual a seu modo, assim também os humores são de
certa maneira aperfeiçoados pela alma racional, mas não do mesmo modo por que o são as partes mais
perfeitas.

## Art. 4 — Se tudo o pertencente verdadeiramente à natureza humana ressurgirá com o corpo.
O quarto discute-se assim. ─ Parece que nem tudo o pertencente verdadeiramente à natureza
humana ressurgirá com o corpo.
1 ─ Pois, a alimentação converte-se verdadeiramente em a natureza humana. Ora, a carne do boi e dos
outros animais nos servem de alimento. Se portanto ressurgir tudo quanto realmente nos constituiu a
natureza, ressurgirá também a carne do boi e a dos outros animais. O que é inadmissível.

2. Demais. ─ A costela de Adão, que serviu para formar Eva, fazia realmente parte dele como a nossa, de
nós. Ora, essa costela não ressurgirá em Adão, mas em Eva; aliás, Eva não ressurgiria, que foi formada
da costela de Adão. Logo, não ressurgirá tudo quanto realmente fazia parte da natureza humana.

3. Demais. ─ Não pode uma mesma causa ressurgir em diversos homens. Ora, pode acontecer que uma
mesma causa pertencesse realmente à natureza humana em diversos homens; assim se alguém se
nutriu de carne humana, que lhe veio a fazer parte da substância. Logo, não ressurgirá em nós tudo
quanto realmente fez parte da nossa natureza.

4. Demais. ─ Se se responder que a carne ingerida por manducação não fez total e realmente parte da
natureza, sendo então possível ressuscitar uma parte dela em um e outra em outro, redarguimos o
seguinte. Real e principalmente pertence à natureza humana o que foi herdado dos pais. Ora, quem só
se nutrisse de carne humana e viesse a gerar um filho, necessariamente o que o filho recebeu do pai
fazia parte da carne dos outros homens, que seu pai comeu; porque o sêmen é formado pelo supérfluo
dos alimentos, segundo o Filósofo o prova. Logo, o que fizer realmente parte da natureza humana nessa
criança fez também realmente parte da natureza humana de outros homens cujas carnes comeu o pai.

5. Demais. ─ Se se disser que aquilo que fazia realmente parte da natureza humana, na carne dos corpos
humanos comidos, não se transforma em sêmen, senão aquilo que não fazia realmente parte dessa
natureza, respondemos em contrário o seguinte. Suponhamos que alguém se alimentasse só do
embrião, que nada contém que não constitua realmente a natureza humana, pois, tudo o existente nele
vem dos pais. Se, portanto, o supérfluo do alimento se converte no sêmen, por força aquilo que
encerrava realmente da natureza humana o embrião, que também há de ressurgir depois de ter
recebido a alma racional, isso fará também realmente parte da natureza humana da criança gerada de
tal sêmen. E assim, como uma causa não pode ressurgir em dois corpos, em nenhum poderá ressurgir
tudo o que fazia realmente parte da natureza humana.
Mas, em contrário. ─ Tudo o que realmente fez parte da natureza humana recebeu da alma racional a
sua perfeição. Ora, o corpo humano é destinado a ressurgir por ter recebido da alma racional a sua
perfeição. Logo, em cada um ressurgirá tudo o que realmente lhe fez parte da natureza humana.

2. Demais. ─ Se um corpo humano for privado de algo que realmente lhe fazia parte da sua natureza
humana, já não será perfeito. Ora, toda imperfeição do corpo desaparecerá com a ressurreição; salvo no
dos eleitos, a quem foi prometido que não se lhes perderá um cabelo da cabeça. Logo, em cada corpo
ressurgirá tudo o que realmente lhe fazia parte da natureza humana.

SOLUÇÃO. ─ Todas as cousas tem com a verdade a mesma relação que tem com o ser, diz Aristóteles;
pois, verdadeira é a causa que é tal como aparece a quem atualmente a vê. E por isso diz Avicena, que a
verdade de uma cousa é uma propriedade constante do seu ser. Assim sendo, diremos que real e
essencialmente pertence a natureza humana o que propriamente lhe pertence ao ser. E isso é o que lhe
participa da forma; assim como verdadeiro ouro se chama ao que tem a forma verdadeira do ouro, da
qual lhe resulta o seu ser próprio. Para sabermos, pois, o que verdadeiramente constitui a natureza
humana, devemos saber que há sobre esta questão três opiniões. Assim, uns ensinaram que nada
começa verdadeiramente a existir de novo em a natureza humana; mas tudo o que verdadeiramente lhe
pertence, pertenceu-lhe total e verdadeiramente desde a sua instituição. E isso por si mesmo se
multiplica, destacando-se do gerador o sêmen que vai formar o filho; e neste também se multiplica essa
parte destacada do pai e chega ao desenvolvimento perfeito pelo crescimento, e assim por diante;
sendo assim que se multiplicou todo o gênero humano. Por onde, segundo esta opinião, tudo o gerado
dos alimentos, embora pareça ter a espécie da carne ou do sangue, não pertence contudo
verdadeiramente à natureza humana.
Outros porém opinaram que algum acréscimo verdadeiramente se faz em a natureza humana, pela
transformação natural do alimento no corpo humano, considerada a realidade da natureza humana
especificamente, a cuja conservação se ordena o ato da faculdade genésica. Se porém considerarmos
essa natureza no indivíduo, a cuja conservação e perfeição se ordena o ato da função nutritiva, nenhum
acréscimo faz a alimentação que pertença primariamente, senão só secundariamente, à verdadeira
natureza humana desse indivíduo. Ensinam então que a natureza humana, verdadeira, primária e
principalmente, consiste numa umidade radical, donde procede a constituição primeira do gênero
humano. O que porém se converte, de alimento, verdadeiramente em carne e em sangue, não constitui
principal e verdadeiramente, senão só secundariamente, a natureza desse indivíduo; mas pode
verdadeira e principalmente constituir a natureza de outro indivíduo, gerado do sêmen do primeiro.
Pois, consideram o sêmen como o supérfluo do alimento, quer adicionado a certos elementos
pertencentes primária e verdadeiramente à natureza humana do gerador, como certos dizem, ou sem
nenhuma adição dessa espécie, como pretendem outros. De modo que a umidade nutritiva em um se:
torna umidade radical no outro.
A terceira opinião professa que alguma causa começa a existir de novo, principal e verdadeiramente, em
a natureza humana, mesmo individualmente considerada. Porque não se pode fazer nenhuma distinção
de partes do corpo humano, de acordo com a qual haja certas determinadas, que hão de
necessariamente permanecer durante toda a vida; mas qualquer parte que se considere em especial é
indiferente a permanecer sempre no que tem de específica; mas desaparecer e retornar à existência
pelo que tem de material. E assim, a umidade nutritiva não se distingue da radical pelo seu princípio, de
modo que chamássemos radical ao gerado do sêmen, e nutritivo ao gerado do alimento. Mas se
distingue, antes, pelo seu termo, chamando-se então radical ao que alcança o termo da geração pelo
ato da virtude genésica ou também da nutritiva; e denominando-se nutritivo o que ainda não tendo
atingido esse termo, está em via de nutrir.
Essas três opiniões são mais plenamente examinadas e discutidas pelo Mestre no livro 2 das Sentenças.
Não devemos por isso repeti-lo aqui senão enquanto vem a propósito.
Devemos, pois, saber que segundo se adapta uma dessas três opiniões, diferente será a resposta a dar à
questão formulada acima.
Assim, a primeira opinião, por via da multiplicação que admite, pode explicar a perfeição verdadeira da
natureza humana, tanto quanto ao número dos indivíduos como quanto ao crescimento próprio de cada
um, sem recorrer ao gerado pela alimentação. O que não se acrescenta ao corpo senão para resistir à
consumpção que poderia provir da ação do calor natural, como à prata se acrescenta o chumbo a fim de
não se consumir liquefeita. Ora, na ressurreição há de a natureza humana reconstituir-se na sua
perfeição, nem o calor natural terá então por função consumir a umidade natural. Por isso nenhuma
necessidade haverá de ressurgir com o corpo nada de gerado por alimentação. Mas só ressurgirá aquilo
que verdadeiramente fazia parte da natureza humana do indivíduo, e que a separação e a multiplicação
levaram à perfeição referida, em o número e quantidade dos indivíduos.
Quanto à segunda opinião, admitindo que o gerado por nutrição é necessário ao crescimento perfeito
do indivíduo e a multiplicação resultante da geração, é levada forçosamente a fazer ressurgir certas
cousas das produzidas no corpo pelo alimento; mas não todas, senão só as necessárias à perfeita
reintegração da natureza humana em todos os seus indivíduos. Por isso ensina essa opinião que tudo o
que constituía substancialmente o sêmen ressurgirá no corpo de tal sêmen gerado; por isso era o que
principal e verdadeiramente lhe constituía a natureza humana. Quanto ao que se lhe acrescentou
depois pela nutrição, isso ressurgirá na medida necessária à plenitude do crescimento; e não tudo,
porque não lhe pertence verdadeiramente à natureza humana senão enquanto esta, como natureza,
disso precisa para o crescimento perfeito. Mas como essa umidade nutritiva passa e volta, a
reconstituição do corpo ressurrecto se fará na ordem seguinte. O que constituía primariamente a
substância do corpo humano será totalmente restaurado; o que se lhe acrescentou em segundo, em
terceiro lugar e assim por diante será refeito o quanto necessário para reintegrar-lhe o crescimento. E
por duas razões. Primeiro, porque o acrescentado o foi para compensar as perdas anteriores; e assim
não pertence principal e verdadeiramente à natureza humana como as cousas precedentes. Segundo,
porque a adjunção de uma umidade estranha à umidade primeira radical faz com que o todo composto
não participe tão perfeita e verdadeiramente da espécie como dela participa a substância primeira do
corpo. E o Filósofo dá o exemplo da água misturada com vinho, que sempre enfraquece as qualidades
deste, até acabar pelo transformar em água. Por onde, assim como a segunda água, embora apresente
ainda a aparência do vinho, contudo não lhe participa da espécie tão perfeitamente como a água que
em primeiro lugar foi nele posta; assim também parte do alimento posteriormente convertido em
carne, não a forma especificamente de modo tão perfeito como o alimento que primeiro nela se
converteu. E assim não constitui verdadeiramente a natureza humana nem participará da ressurreição.
Por onde é claro que esta opinião admite a total ressurreição do que principal e verdadeiramente
constitui a natureza humana; mas não a total ressurreição de tudo o que a constitui verdadeira mas
secundariamente.
A terceira opinião enfim em parte difere da segunda e em parte com ela convém. Difere em admitir que
tudo o que tem forma de carne e de ossos pertence verdadeiramente e pela mesma razão à natureza
humana. Porque não distingue, com a segunda opinião, entre o determinadamente permanente no
homem durante todo o tempo da sua vida e que em si pertenceria primária e verdadeiramente a
natureza humana; e o que, passando e tornando a voltar, pertenceria verdadeiramente a essa natureza
só para o pleno desenvolvimento dela, e não pelo seu ser específico primário. Mas admite, que todas as
partes não geradas contra a intenção da natureza pertencem verdadeiramente à natureza humana, pelo
que tem de específico, porque como tais são permanentes. Mas não pelo que tem de material, porque
como tais desaparecem e voltam, indiferentemente. De modo que também entendamos que se dá com
as partes de cada homem em particular o que se passa com a população de uma cidade, onde aos que a
deixam pela morte outros lhes vem ocupar o lugar; por isso as partes dela fluem e refluem
materialmente, mas formalmente permanecem, porque nos mesmos ofícios e ordens os que partiram
são substituídos por outros, o que nos leva a dizer que a república permanece numericamente a mesma.
Também o mesmo se dá quando umas partes desaparecendo outras se lhes substituem, na mesma
figura e situação; e assim todas vão e voltam materialmente, mas permanecem especificamente, não
deixando por isso de permanecer o homem individualmente o mesmo.
Enfim a terceira opinião convém com a segunda por admitir que as partes acrescidas em segundo lugar
não constituem tão perfeita e verdadeiramente a espécie, como as que vieram em primeiro lugar. E
assim o mesmo, que a segunda opinião diz ressurgir no homem, também o diz a terceira, mas não
exatamente pela mesma razão. Pois afirma que ressurgirá tudo o gerado do sêmen, não por pertencer,
por uma outra razão, à verdadeira natureza humana, do que aquilo que se lhe acresceu posteriormente;
mas por participar mais perfeita e verdadeiramente da espécie. Ordem essa admitida pela segunda
opinião em relação ao que se acrescenta por efeito do alimento. No que também esta opinião concorda
com a terceira.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os seres naturais não são tais pela matéria, mas pela
forma. Por onde, embora a matéria, antes unida à forma da carne bovina, ressurja no homem sob a
forma de carne humana, daí não resulta que ressurja a carne do boi, mas a do homem. Do contrário,
também podia concluir-se que ressurgiria o barro de que foi formado o corpo de Adão. Contudo, a
primeira opinião concede a essa objeção.

RESPOSTA À SEGUNDA. ─ Essa costela não pertencia à perfeição individual de Adão, mas era ordenada à
multiplicação da espécie. Por isso não ressurgirá em Adão, mas em Eva, assim como o sêmen não
ressurgirá no gerador, mas no gerado.

RESPOSTA À TERCEIRA. ─ Se se adota a primeira opinião é fácil responder. Pois, as carnes ingeridas não
fizeram nunca verdadeiramente parte da natureza humana de quem as comeu, mas fizeram realmente
parte da natureza humana daquele curas carnes foram comidas. Por isso ressurgirão com este e não
com aquele. Mas se adotarmos a segunda opinião e a terceira diremos que cada cousa ressurgirá
naquele em quem mais perfeitamente participou da virtude da espécie. E se participou igualmente em
ambos ressurgirá naquele em que existiu primeiro, pois neste primeiro se ordenou à ressurreição pela
união com a sua alma racional. Por onde, se as carnes ingeridas continham alguma superfluidade que
não pertencessem verdadeiramente à natureza humana do primeiro, poderá ressurgir no segundo. Mas
se não continham nenhuma superfluidade. ressurgirá no primeiro o que lhe pertencia à ressurreição, e
não no segundo. E para reparar esta perda no último, seria tomada uma parte das suas carnes em que
se converteram outros alimentos, ou se nunca se nutriu de outra causa a não ser de carne humana, o
poder divino suprirá de outro modo no suficiente à perfeição do crescimento, assim como supre nos
mortos antes da idade perfeita. E tudo isso não causa nenhum detrimento à identidade numérica, do
mesmo modo que não a destrói a disparição e a reaparição material das partes.

RESPOSTA À QUARTA. ─ De acordo com a primeira opinião é fácil resolver, pois afirma que o sêmen não
provém de alimento supérfluo. Por isso a carne comida não se transforma no sêmen que causa a
geração. Mas de acordo com as outras duas opiniões, devemos responder que não é possível as carnes
comidas terem-se convertido totalmente no sêmen; porque, de uma longa depuração do alimento
resulta a decocção do sêmen, que é o supérfluo do último alimento. Ora, o que das carnes ingeridas se
converte em esperma, mais verdadeiramente pertence à natureza humana de quem dela nasce, do que
daquele de cujas carnes foi gerado. Por onde, segundo a regra anteriormente dada, o que se converte
em sêmen ressurgirá naquele que desse sêmen nasceu; e o que resta da matéria ressurgirá naquele que
ingeriu as carnes de que o sêmen foi gerado.

RESPOSTA À QUINTA. ─ Os embriões não se incluem na ressurreição antes de animados pela alma
racional. E nesse estado recebe da alimentação muitas causas que se acrescentam à substância do
esperma, porque o feto é nutrido no seio materno. Quem, pois, se nutre de embriões e engendra do
supérfluo dessa alimentação, o que resultar da substância do sêmen ressuscitará naquele que deste foi
gerado. Salvo se essa substância contiver alguma cousa que pertencesse à substância seminal daqueles
que forneceram as carnes ingeridas; pois, então, elas ressuscitarão no primeiro que formou a substância
e não no segundo que as comeu. Quanto ao resíduo das carnes comidas, que se não converteram em
sêmen, ressuscitaria no primeiro, e a virtude divina supriria o que faltasse a um e a outro. Mas esta
objeção não cria nenhuma dificuldade à primeira opinião, que não admite ser o sêmen formado do
supérfluo dos alimentos; mas em compensação, presta o flanco a muitas outras objeções, como o
mostra o Mestre.

## Art. 5 — Se tudo o que as partes do corpo humano tinham de material ressuscitará.
O quinto discute-se assim. ─ Parece que tudo o que as partes do corpo humano tinham de material
ressuscitará.

1. ─ Pois, menos são susceptíveis de ressurreição os cabelos que os outros órgãos. Ora, toda a matéria
dos cabelos ressuscitará, embora não nos cabelos, ao menos nas outras partes do corpo, como diz
Agostinho. Logo e com maior razão, tudo o que de material encerravam os outros órgãos ressurgirá.

2. Demais. ─ Assim como as partes específicas do corpo são aperfeiçoadas pela alma racional, assim
também as partes materiais. Ora, o corpo humano é destinado à ressurreição por ter sido aperfeiçoado
pela alma racional. Logo, não só as partes específicas, mas também as materiais ressurgirão.

3. Demais. ─ A totalidade do corpo vem donde lhe procede a divisão em partes. Ora, a divisão de um
corpo em partes se funda na sua matéria, que forma pela sua disposição a quantidade, objeto da
divisão. Logo, também a totalidade corpórea se funda nas partes da matéria. Portanto, nem todas as
partes da matéria ressurgindo também não ressurgirá o corpo na sua totalidade. O que é inadmissível.
Mas, em contrário. ─ As partes materiais do corpo não permanecem, mas se transformam
continuamente, como o prova Aristóteles. Se, portanto, todas as partes materiais ressurgirem, o corpo
ressurrecto será excessivamente denso ou de desmesurada quantidade.

2. Demais. ─ Tudo o pertencente verdadeiramente à natureza de um corpo humano pode vir a constituir
a matéria do corpo de outro homem que do primeiro se nutriu. Se portanto todas as partes materiais do
corpo humano ressurgirem, resulta que ressurgirá em um o que verdadeiramente pertence à natureza
humana de outro. O que é inadmissível.

SOLUÇÃO. ─ A parte material do homem não se destina à ressurreição senão enquanto realmente
pertencente à natureza humana; porque assim está ligada a alma racional. Ora, o todo material humano
pertence por certo verdadeiramente à natureza humana pelo que tem de específico; mas não
totalmente, levada em conta a matéria da totalidade; porque toda a matéria que existiu num indivíduo
humano, desde o princípio até o fim da sua vida, excederia as proporções especificas do seu corpo,
como pretende a terceira opinião, que me parece a mais provável das três. Por onde, o todo humano
ressurgirá, considerada a totalidade específica, fundada na quantidade, na figura, na situação e na
ordem das partes; mas não ressurgirá todo, se se considera como todo a totalidade da matéria. ─ A
segunda opinião, porém, e a primeira não entram nessa distinção; mas distinguem entre as partes, cada
uma das quais tem espécie e matéria. Mas essas duas opiniões convêem em ensinarem que o todo
gerado do sêmen ressurgirá, mesmo considerada como tal a totalidade material. Mas diferem em dizer
a primeira que nada ressurgirá do gerado pela alimentação; o que por certo ressurgirá, pondera a
segunda, mas não totalmente, como do sobredito se colhe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Assim como tudo o existente nas outras partes do corpo
ressurgirá, considerada a totalidade especifica, mas não a totalidade material, o mesmo se dará com os
cabelos. Ora, às outras partes algo se lhes acrescenta pela nutrição, que produz o crescimento; e isso se
conta como outra parte, considerada a totalidade específica, porque ocupa no corpo outro lugar e outra
situação, e constitui a substância das outras partes da dimensão. Mas algo se lhe acrescenta que não
produz crescimento, aplicando-se apenas em compensar pela nutrição as perdas; e não é computado
como outra parte do todo considerado especificamente, pois não ocupa outro lugar nem outra situação
no corpo, diferentes do que ocupava a parte que desapareceu. Embora possamos contá-la como outra
parte, considerada a totalidade material. Ora, o mesmo se dá com os cabelos. Mas Agostinho se refere
aos cabelos cortados durante a vida, que eram partes susceptíveis de crescimento. Que por isso hão de
necessariamente ressurgir; não que devam se acrescentar aos outros cabelos, para não ficar
desmesurada a quantidade deles, mas às outras partes, como o julgar necessário a divina providência. ─
Ou se refere ao caso de serem deficientes as outras partes; pois então essa deficiência poderá ser
suprida pelo excesso de cabelos.

RESPOSTA À SEGUNDA. ─ Conforme à terceira opinião, as mesmas são as partes específicas e as
materiais. Nem o Filósofo recorre a essa distinção para introduzir diversidade nas partes, mas para
mostrar que as mesmas partes podem ser consideradas especificamente, pelo que tem de forma e de
espécie; e materialmente, como constituindo o substrato da forma e da espécie. Pois, a matéria da
carne não se ordena à alma racional, senão enquanto tem uma determinada forma. E por essa razão se
ordena a ressurgir. ─ A primeira e a segunda opinião, porém, professando a diferença entre as partes
específicas e as naturais, dizem que a alma racional, embora aperfeiçoe ambas essas partes, não
aperfeiçoa contudo as partes materiais senão mediante as partes específicas. Por isso não se ordenam
elas igualmente à ressurreição.

RESPOSTA À TERCEIRA. ─ As dimensões indeterminadas se concebem necessariamente, na matéria dos
seres sujeitos à geração e à corrupção, antes da recepção da forma substancial. Por isso a divisão
fundada nessas dimensões pertence propriamente à matéria. Mas a quantidade completa e
determinada a quantidade a recebe depois da sua união com a forma substancial. Por onde, a divisão
feita em formas determinadas respeita a espécie; sobretudo quando a idéia de espécie implica, como no
corpo humano, situações determinadas das partes.