# Questão 35: Do efeito do sacramento da ordem.
Em seguida devemos tratar do efeito deste sacramento.
Sobre o que discutem-se cinco artigos:

## Art. 1 — Se o sacramento da ordem confere a graça santificante.
O primeiro discute-se assim. ─ Parece que o sacramento da ordem não confere a graça santificante.

1. ─ Pois, geralmente se diz que o sacramento da ordem é um remédio contra a ignorância. Ora, a graça,
que visa expelir a ignorância, não é a santificante, mas a gratuita; porque a santificante concerne, antes,
ao afeto. Logo, o sacramento da ordem não confere a graça santificante.

2. Demais. ─ A ordem implica uma distinção. Ora, os membros da Igreja não se distinguem uns dos
outros pela graça santificante, mas antes, pela graça gratuita, da qual diz o Apóstolo: Há repartição de
graças. Logo, a ordem não confere a graça santificante.

3. Demais. ─ Nenhuma causa pressupõe o seu efeito. Ora, quem vai receber as ordens há de ter tido
antes a graça, que o torna idôneo a recebê-las. Logo, tal graça não é dada quando é conferida a ordem.
Mas, em contrário. ─ Os sacramentos da lei nova realizam o que figuram. Ora, a ordem pelo número
sete significa os sete dons do Espírito Santo, como diz o Mestre. Logo, os dons do Espírito Santo, que
não existem sem a graça santificante, são conferidos juntamente com a ordem.

2. Demais. ─- A ordem é um sacramento da Lei Nova. Ora, na definição desse sacramento se diz ─ para
que seja a causa da graça. Logo, causa a graça em quem o recebe.

SOLUÇÃO. ─ As obras de Deus são perfeitas, como diz a Escritura. Por onde, a quem Deus dá um poder
qualquer dá também os meios de pô-la convenientemente em exercício. O que bem vemos na ordem
natural; assim, aos animais foram dados membros, pelos quais as potências da alma possam exercer os
seus atos, salvo se alguma deficiência da matéria a isso se opuser. Ora, assim como a graça santificante
é necessária, para recebermos dignamente os sacramentos, assim também o é para serem dignamente
dispensados. Por onde, assim como pelo batismo, que nos torna capazes de receber os outros
sacramentos, é dada a graça santificante, assim, pelo sacramento da ordem, que destina alguém a
dispensador dos outros sacramentos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A ordem é conferida em benefício, não de uma pessoa,
mas de toda a Igreja. Por isso a expressão ─ remédio contra a ignorância ─ não se deve entender como
significando, que o fato de receber a ordem elimina a ignorância de quem a recebe; mas, que quem a
recebe está preparado a acabar com a ignorância do povo.

RESPOSTA À SEGUNDA. ─ Embora os dons da graça santificante sejam comuns a todos os membros da
Igreja, contudo ninguém, que não tenha a caridade, pode dignamente receber a ação daqueles dons,
nos quais se funda a distinção entre os vários membros da Igreja; e a caridade não pode existir sem a
graça santificante.

RESPOSTA À TERCEIRA. ─- Para o cabal exercício das ordens não basta qualquer bondade, mas é
necessário uma bondade excelente. De modo que, como aqueles que recebem a ordem, ela os coloca
em grau superior ao povo, assim também lhe sejam superiores pelo mérito da santidade. Por isso
devem ter antes a graça bastante para fazerem dignamente parte do povo cristão; quando porém
recebem a ordem, recebem também maior dom da graça, que os torna capazes de coisas maiores.

## Art. 2 — Se o sacramento da ordem, em todos os seus graus, imprime caráter.
O segundo discute-se assim. ─ Parece que o sacramento da ordem não imprime caráter em todos os
seus graus.

1. ─ Pois, o caráter da ordem é um poder espiritual. Ora, certas ordens só se ordenam a certos atos
materiais; como as de ostiário ou acólito. Logo, essas não imprimem caráter.

2. Demais. ─ Todo caráter é indelével. Por isso, o caráter coloca o ordenado em tal estado, donde não
pode sair. Ora, os que receberam certas ordens, podem voltar ao laicato. Logo, nem todas as ordens
imprimem caráter.

3. Demais. ─ O caráter consagra aquele, em quem se imprimiu, a administrar ou receber certas coisas
santas. Ora, para receber os sacramentos já ficamos suficientemente preparados pelo caráter batismal.
Mas, dispensador dos sacramentos ninguém é constituído senão pela ordem sacerdotal. Logo, as outras
ordens não imprimem caráter.
Mas, em contrário. ─ Todo sacramento, que não imprime caráter, pode ser reiterado. Ora, nenhuma
ordem pode ser reiterada. Logo, toda ordem imprime caráter.

2. Demais. ─ O caráter é um sinal distintivo. Ora, toda ordem causa uma distinção. Logo, toda ordem
imprime caráter.

SOLUÇÃO. ─ Nesta matéria três são as opiniões.
Assim, certos disseram, que só a ordem sacerdotal imprime caráter. ─ Mas isto não é verdade. Pois, os
atos do diácono ninguém os pode licitamente praticar senão o diácono. Por onde, é claro que tem um
poder especial de dispensar os sacramentos, que os outros não tem. Por isso outros opinaram, que as
ordens sacras imprimem caráter, mas não as ordens menores. ─ Mas também isto é inadmissível. Por
que qualquer ordem constitui o ordenado num grau de poder superior ao povo, poder ordenado à
dispensa dos sacramentos.
Por onde, sendo o caráter um sinal que distingue uns cristãos dos outros, é necessário seja impresso por
todas as ordens. E prova disso é que permanece perpetuamente e nunca pode ser reiterada. Esta é a
terceira opinião e a mais comum.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Toda ordem, qualquer que seja, tem como objeto do seu
exercício ou o próprio sacramento, ou se ordena à dispensação dos sacramentos. Por exemplo, a função
dos ostiários é admitir os fiéis à assistência dos divinos sacramentos; e assim por diante. Por isso, todas
essas funções implicam um poder espiritual.

RESPOSTA À SEGUNDA. - Embora se transfira um para o laicato, nele permanece sempre contudo o
caráter. E bem o demonstra o fato de não precisar receber de novo a ordem, que já tinha, se reverter ao
clericato.

RESPOSTA À TERCEIRA. ─ Veja-se a resposta à primeira.

## Art. 3 — Se o caráter da ordem pressupõe o do batismo.
O terceiro discute-se assim. ─ Parece que o caráter da ordem não pressupõe o do batismo.

1. ─ Pois, o caráter da ordem dá a quem o recebe o poder de dispensar os sacramentos; ao passo que o
caráter batismal só lhe confere a faculdade de os receber. Ora, o poder ativo não supõe
necessàriamente o passivo, porque pode existir sem este, como se dá com Deus. Logo, o caráter da
ordem não pressupõe necessariamente o caráter batismal.

2. Demais. ─ Pode acontecer que um não batizado se tenha na conta de provável batizado. Se esse tal,
pois, receber as ordens não lhes receberá o caráter, se este pois, supõe o do batismo. E assim os atos de
consagração ou de absolvição, que praticar, nenhum valor terão; de modo que a Igreja será enganada. O
que é inadmissível.
Mas, em contrário. ─ O batismo é a porta dos sacramentos. Logo, sendo a ordem um sacramento,
pressupõe o batismo.

SOLUÇÃO. ─ Ninguém pode receber aquilo de que não é susceptível. Ora, o caráter batismal nos torna
susceptíveis dos outros sacramentos. Por onde, quem não tem o caráter batismal não pode receber
nenhum outro sacramento. E assim, o caráter da ordem pressupõe o do batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A potência ativa não pressupõe a passiva quando quem
tem aquela por si mesmo a tem. Mas em quem a tem recebida, pressupõe ela a uma potência passiva,
que seja a susceptível da ativa.

RESPOSTA À SEGUNDA. ─ Esse tal, promovido ao sacerdócio, não é sacerdote; não poderá consagrar
nem absolver no foro da penitência. Por isso, segundo os cânones, deve ser de novo batizado e
ordenado. Além disso, se for elevado a bispo, não terão a ordem aqueles a quem tiver ordenado.
Contudo, podemos piamente crer que quanto aos efeitos últimos dos sacramentos, o Sumo Sacerdote
poderia lhes suprir a falta; e que não permitiria que isso passasse despercebido a ponto de poder a sua
Igreja correr o risco de ser enganada.

## Art. 4 — Se a ordem pressupõe necessariamente o caráter da confirmação.
O quarto discute-se assim. - Parece que a ordem pressupõe necessariamente o caráter da
confirmação.

1. Pois, em seres entre si ordenados, assim como o médio pressupõe o primeiro, assim o último, o
médio. Ora, o caráter da confirmação pressupõe o batismal como primeiro. Logo, o caráter da ordem
pressupõe como médio o caráter da confirmação.

2. Demais. - Os colocados a confirmar os outros devem ser os confirmados por excelência. Ora, os que
recebem o sacramento da ordem são os confirmados dos outros. Logo, ninguém mais do que eles deve
ter o sacramento da confirmação.
Mas, em contrário. ─ Os Apóstolos receberam o poder da ordem antes da ascenção, quando se lhes
disse: Recebei o Espírito Santo. Mas foram confirmados depois da Ascensão pelo advento do Espírito
Santo. Logo, a ordem não supõe a confirmação.

SOLUÇÃO. ─ Certas condições são necessárias a quem recebe a ordem; outras são de conveniência. É
necessário à validade do sacramento, que quem receba as ordens seja susceptível delas; e isso lhe é
facultado pelo batismo. Por onde, o caráter batismal é necessàriamente pressuposto a validade da
ordem, de modo que sem ele o sacramento da ordem não pode ser conferido. Quanto à conveniência,
requer a ordem que quem a receber tenha todas as perfeições que o tornem idôneo ao exercício dela; e
uma dessas perfeições está em ser confirmado. Por onde, o caráter da ordem pressupõe como
conveniente, mas não como necessário, o da confirmação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A relação entre o médio e o último não é da mesma
natureza que a entre o primeiro e o médio, no caso vertente. Pois, o caráter batismal nos torna
susceptíveis do sacramento da confirmação; mas o caráter da confirmação a ninguém torna susceptível
do sacramento da ordem. Logo, a razão não é a mesma.

RESPOSTA À SEGUNDA. ─ A objeção se funda na idoneidade por conveniência.

## Art. 5 — Se o caráter de uma ordem necessariamente pressupõe o de outra.
O quinto discute-se assim. - Parece que o caráter de uma ordem pressupõe necessariamente o caráter
de outra.

1. - Pois, maior é a conveniência entre uma ordem e outra, que entre a ordem e outro sacramento. Ora,
o caráter da ordem pressupõe o de outro sacramento ─ o batismo. Logo, com maior razão, o caráter de
uma ordem pressupõe o de outra.

2. Demais. ─ As ordens são determinados graus. Ora, ninguém pode chegar a um grau superior, sem
primeiro chegar ao que o antecede. Logo, ninguém pode receber o caráter de uma ordem mais elevada
sem primeiro ter recebido a ordem precedente.
Mas, em contrário. ─ O sacramento a que faltar uma condição necessária à sua validade há de
forçosamente ser reiterado. Ora, quem receber uma ordem superior, passando por sobre a que conduz
a ela, não precisará de ser ordenado de novo, conferindo-se-lhe apenas a que faltava, segundo o
estatuído nos cânones. Logo, a ordem inferior não é necessária para se receber a mais elevada.

SOLUÇÃO. ─ Não é necessário que se tenham as ordens menores, antes de se receberem as maiores,
por serem distintos os poderes; e uma não exige, por natureza, que o mesmo sujeito tenha já a outra.
Por isso também na primitiva Igreja ordenava-se presbítero quem ainda não tinha as ordens inferiores; e
contudo os assim ordenados tinham todos os poderes das ordens inferiores. Pois, o poder inferior está
compreendido no superior, como os sentidos na inteligência e o ducado no reino. Mas depois, por
constituição da Igreja, foi determinado que não tenha o exercício das ordens superiores quem antes não
exercitar a sua humildade nos ofícios inferiores. Donde vem, que quem se ordena, passando por sobre
as ordens inferiores, não precisa, segundo os cânones, de ser reordenado, conferindo-se-lhe tão
somente as ordens inferiores que deixou de receber.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Por semelhança específica, mais convêm as ordens entre
si, que a ordem, com o batismo; mas se se leva em conta a proporção entre a potência e o ato, mais
convém o batismo com a ordem, que uma ordem com outra. Porque o batismo confere a potência
passiva de receber as ordens; ao passo que uma ordem inferior não outorga a potência passiva de
receber as ordens maiores.

RESPOSTA À SEGUNDA. ─ As ordens não são degraus que devamos percorrer sucessivamente numa
mesma ação, ou movimento, de maneira que devêssemos passar pelo último para chegar ao primeiro.
Mas são como os graus existentes entre coisas diversas. Tal o grau entre o homem e o anjo; assim, não é
necessário que o anjo tenha sido antes homem. Tais são também os graus entre a cabeça e os outros
membros do corpo: não é necessário tenha a cabeça principiado por ser pé. Ora, tal é o que se dá no
caso vertente.