# Questão 83: Da subtileza dos corpos dos bem-aventurados.
Em seguida devemos tratar da subtileza dos corpos dos bem-aventurados.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se a subtileza é propriedade dos corpos gloriosos.
O primeiro discute-se assim. ─ Parece que a subtileza não é propriedade dos corpos gloriosos.

1. ─ Pois, a propriedade da glória excede à da natureza, assim como a claridade da glória excede a do
sol, que é a máxima claridade natural. Se, portanto, a subtileza é propriedade dos corpos gloriosos,
parece que um corpo glorioso será mais subtil que tudo quanto há de subtil em a natureza. E assim será
mais subtil que o vento e o ar, o que é a heresia por Gregório condenada na cidade de Constantinopla,
como ele mesmo o narra.

2. Demais. ─ Assim o calor e a frigidez são umas qualidades dos elementos, corpos simples, assim
também a subtileza. Ora, o calor e as outras qualidades dos elementos não terão maior intensidade nos
corpos gloriosos que nos mortais; ao contrário, então mais se hão de reduzir ao equilíbrio. Logo, não
terão maior subtileza do que presentemente.

3. Demais. ─ Os corpos são subtis quando rarefeitos de matéria; por isso consideramos como mais subtis
os corpos de menor matéria em dimensões iguais; assim, o fogo, mais subtil que o ar, o ar, que a água, a
água, que a terra. Ora, os corpos gloriosos terão a mesma de matéria que presentemente tem nem lhes
são maiores as dimensões. Logo, não serão mais subtis então que agora.
Mas, em contrário, o Apóstolo: É semeado o corpo animal, ressuscitará o corpo espiritual, i. é,
semelhante ao espírito. Ora, a subtileza do espírito excede toda a subtileza dos corpos. Logo, os corpos
gloriosos serão subtilissimos.

2. Demais. ─ Os corpos quanto mais subtis tanto mais nobres. Ora, os corpos gloriosos são nobilíssimos.
Logo, serão subtilíssimos.

SOLUÇÃO. ─ A denominação de subtileza deriva do poder de penetração dos corpos; por isso, como diz
Aristóteles, subtil é o que tem a propriedade de encher os corpos e as diversas partes dos corpos. ─ Ora,
o poder de penetração dos corpos pode provir de duas causas. ─ Primeiro, das suas pequenas
proporções, sobretudo em profundidade e largura, mas não em comprimento; porque a penetração
fazendo-se em profundidade, a largura nenhum obstáculo lhe opõe. Segundo, da pouca quantidade da
matéria, por isso chamamos aos corpos de matéria rarefeita subtis. E como nos corpos rarefeitos mais
predomina a forma do que a matéria, daí a transladação da denominação de subtil aos corpos que se
sujeitam do melhor modo possível à forma e se deixam aperfeiçoar por ela da maneira mais completa.
Assim, atribuímos a subtileza ao sol, a lua e a corpos semelhantes; e também podemos chamar subtil ao
ouro e matérias tais, quando perfeitissimamente completos no ser e na virtude da sua espécie.
E como as cousas incorpóreas carecem de quantidade e de matéria, foi-lhes transladada a denominação
de subtilesa, não só em razão da sua subtileza, mas também da virtude. Pois, assim como chamamos
subtil ao que é penetrante, porque atinge até ao íntimo das cousas, assim também chamamos subtil ao
intelecto capaz de penetrar no seu exame até aos princípios intrínsecos e as propriedades naturais
ocultas das cousas. Semelhantemente dizemos que tem uma vista subtil quem pode perceber um
objeto, por mínimo que seja, E o mesmo se dá com os outros sentidos.
E a esta luz também de diversos modos se atribuiu a subtileza aos corpos gloriosos.
Assim, certos heréticos consoante o refere Agostinho, atribuíram-lhes a subtileza ao modo por que as
substâncias espirituais se chamam subtis, ensinando que na ressurreição os corpos se transformarão em
espírito; razão pela qual o Apóstolo chama espirituais aos corpos ressurrectos. ─ Mas isto é inadmissível.
Primeiro, porque um corpo não pode transformar-se em espírito, pois, não tem matéria nenhuma
comum, como também o mostra Boécio. Segundo, porque se isso fosse possível, uma vez o corpo
convertido em espírito, o homem, naturalmente composto de alma e corpo, não ressurgiria. Terceiro,
porque se o Apóstolo assim o tivesse entendido, como usa da expressão ─ corpos espirituais, pela
mesma razão usaria da outra ─ corpos animais, para designar os que se converteram na alma. O que é
evidentemente falso.
Por isso outros heréticos disseram que o corpo não deixará de existir na ressurreição, mas terá a
subtileza a modo da rarefação; de modo que os corpos humanos ressurrectos serão semelhantes ao ar
ou ao vento, como refere Gregório. ─ Mas isto não pode sustentar-se. Porque o corpo do Senhor depois
da ressurreição era palpável, segundo diz o Evangelho, e contudo devemos crer que era subtil por
excelência. Além disso o corpo humano ressurgirá com carnes e ossos, como o corpo do Senhor,
conforme o refere o Evangelho; Um espírito não tem carne nem ossos, como vós vedes que eu tenho. E
noutro lugar da Escritura se lê: Na minha própria carne verei a Deus, meu Salvador. Ora, a natureza da
carne e dos ossos não se compadece com a referida raridade.
Devemos, pois, atribuir aos corpos gloriosos outro modo de subtileza, chamando-lhes subtis por causa
da sua completíssima perfeição.
Mas essa completa perfeição uns lhes atribuem em razão da quinta essência que sobretudo neles
domina. ─ O que não pode ser. Primeiro, porque a quinta essência não pode de modo nenhum entrar na
composição de qualquer corpo, como já se demonstrou. Segundo, porque, dado que viesse a entrar na
composição do corpo humano, não poderíamos conceder que se fosse então mais predominante que o
é presentemente sobre a natureza elementar. Salvo se o corpo humano resurrecto encerrasse maior
quantidade da natureza celeste; mas então não seriam da mesma estatura, a não ser que a matéria
elementar do homem sofresse uma diminuição, o que repugna à integridade dos corpos ressuscitados.
Ou então, que a natureza elementar se revestisse das propriedades da natureza celeste, por causa da
predominância desta no corpo. Donde, uma virtude natural seria a causa da propriedade gloriosa. O que
é absurdo.
Daí o pretenderem outros que a referida plenitude de perfeição que nos leva a chamar subtis os corpos
humanos, virá da preponderância da alma glorificada sobre o corpo, do qual é forma, em razão do que o
corpo glorioso e chamado espiritual, quase totalmente sujeito ao espírito. Ora, o corpo humano está
sujeito à alma, primeiramente, para lhe participar da sua essência específica, como à forma está sujeita
a matéria. Em seguida também lhe está sujeito como executor das obras de que a alma é o móvel. Por
onde, a razão primeira de ser o corpo subtil está na sua subtileza; depois, na agilidade e nas outras
propriedades do corpo glorioso. Por isso o Apóstolo quando fala em espiritualidade se refere ao dote da
subtíleza, como o explica o Mestre. Donde o dizer Gregório, que o corpo glorioso é chamado subtil por
efeito da potência espiritual.
Donde se deduzem as respostas às objeções, fundadas na subtileza resultante da rarefação.

## Art. 2 — Se em razão da sua subtileza pode um corpo glorioso ocupar simultaneamente o mesmo lugar de um corpo não glorioso.
O segundo discute-se assim. ─ Parece que em razão da sua subtileza pode um corpo glorioso ocupar
simultaneamente o mesmo lugar que um corpo não glorioso.

1. ─ Pois, diz o Apóstolo: O que reformará o nosso corpo abatido, para o fazer conforme ao seu corpo
glorioso. Ora, o corpo de Cristo podia ocupar simultaneamente com outro o mesmo lugar; como o
demonstra o fato de, depois da ressurreição, ter entrado onde estavam seus discípulos, estando as
portas fechadas, como o refere o Evangelho. Logo, também os corpos gloriosos, em razão da sua
subtileza poderão ocupar simultaneamente o mesmo lugar com os corpos não gloriosos.

2. Demais. ─ Os corpos gloriosos serão mais nobres que todos os outros corpos. Ora, no nosso mundo,
alguns corpos, como p. ex., os raios solares, podem, em razão da sua nobreza, estar simultaneamente
com outros no mesmo lugar. Logo e com muito maior razão hão de podê-lo os corpos gloriosos.

3. Demais. ─ O corpo celeste não pode ser dividido, ao menos quanto à substância das esferas; donde o
dizer Job, que os céus são tão sólidos como se fossem de metal. Se, portanto, um corpo glorioso não
pudesse ocupar em razão da sua subtileza, o mesmo lugar que outro, não glorioso, nunca poderia subir
ao céu empíreo, o que é errôneo.

4. Demais. ─ Um corpo que não pode ocupar simultaneamente o mesmo lugar que outro, pode ficar
impedido por este no seu movimento ou mesmo ficar dele cativo. Ora, tal não se pode dar com os
corpos gloriosos. Logo, poderão ocupar simultaneamente o mesmo lugar que os outros corpos.

5. Demais. ─ Um ponto está para outro, como uma linha para outra, uma para outra superfície e um
corpo para outro corpo. Ora, dois pontos podem coexistir no mesmo lugar, como o demonstram duas
linhas que se tocam; semelhantemente, duas linhas, pelo contato de duas superfícies; e duas superfícies
pelo contato de dois corpos. Porque contíguas são as cousas cujos extremos se tocam, como explica o
Filósofo. Logo, não colide com a natureza do corpo poder ocupar simultaneamente o mesmo lugar que
outro. Ora, toda nobreza de que um corpo naturalmente susceptível será apanágio dos corpos gloriosos.
Logo, o corpo glorioso, em virtude da propriedade da subtileza, poderá ocupar simultaneamente o
mesmo lugar que outro.
Mas, em contrário, ─ diz Boécio: A diversidade dos acidentes é a causa das diferenças numéricas. Assim,
três homens diferem entre si pelos seus acidentes e não pelo gênero nem pela espécie. Pois, se os
despirmos absolutamente de todos os acidentes, contudo cada um ocupará lugares diferentes, que de
nenhum modo poderemos reduzir a um só. Logo, postos dois corpos num mesmo lugar, ficarão
reduzidos a um só.

2. Demais. ─ Os corpos gloriosos tem maior conveniência com o lugar do que os espíritos angélicos. Ora,
os espíritos angélicos, como certos dizem, não poderiam distinguir─se individualmente uns dos outros
se não ocupassem lugares diversos. Por isso afirmam que ocupam necessariamente lugar e não podiam
ser criados antes da criação do mundo. Logo e com muito maior razão, deviam admitir que dois corpos
quaisquer não podem ocupar simultaneamente o mesmo lugar.

SOLUÇÃO. ─ Não é possível admitir-se que um corpo glorioso, em razão da sua subtileza, possa coexistir
com outro corpo no mesmo lugar, sem admitir-se também que a subtileza tem como efeito despojá-la
do que, como mortal, o impede de ocupar simultaneamente com outro corpo o mesmo lugar.
Ora, como pretendem certos, o que impede, neste mundo, um corpo de ocupar o mesmo lugar que
outro é a sua massa, que o leva a ocupar um lugar; ora, esse volume lhe desaparece em virtude da
subtileza. ─ Mas isto é insustentável por duas razões.
Primeiro, porque a massa, eliminada pelo dote da subtileza, é a que constitui um defeito; p. ex., matéria
desordenada não perfeitamente unida à sua forma. Mas tudo o constitutivo da integridade dos corpos
com eles ressurgirão, tanto quanto à forma como quanto à matéria, Ora, o fato de um corpo ocupar um
lugar, resulta-lhe da sua natureza íntegra, e não defeituosa. Pois, como o cheio se opõe ao vazio, só não
enche um lugar o que, apesar de nele colocado, o deixa vazio. Ora o vácuo, como o define Aristóteles, é
um lugar não cheio por um corpo sensível. E dizemos que um corpo é sensível pela sua matéria, pela sua
forma e pelos seus acidentes, o que tudo lhe constitui a integridade natural. Ora, sabemos que os
corpos gloriosos terão também a sensibilidade táctil, como a tinha o corpo do Senhor, consoante o
refere o Evangelho. Nem ficarão privados da matéria, da forma, nem dos acidentes naturais, como a
calidez, a frigidez e outros. Por onde, é claro que um corpo glorioso, não obstante o dom da subtileza,
ocupará um lugar. E insânia seria dizer que o lugar ocupado por um corpo glorioso estará vazio.
Além disso, a razão dada não vale, porque impedir um corpo de ocupar um determinado lugar é algo
mais que ocupar um lugar. Assim, se supusermos as dimensões existindo separadas, sem matéria, essas
dimensões não ocuparão nenhum lugar. Por isso certos, admitindo o vácuo, disseram ser este um lugar
onde estão as dimensões, sem nenhum corpo sensível. E contudo essas dimensões não poderão existir
simultaneamente com outro corpo no mesmo lugar, como o prova o Filósofo, demonstrando ser
impossível um corpo matemático, que outra coisa não é senão essas dimensões existindo
separadamente; ocupar simultaneamente o mesmo lugar com outro corpo sensível. Por onde, dado que
a subtileza dos corpos gloriosos tira-lhes a propriedade de ocupar um lugar, não se seguiria contudo daí
que pudessem ocupar simultaneamente com outro corpo um mesmo lugar. Porque, removido o menos,
nem por isso fica removido o mais.
Donde pois se conclui, que o impedimento do nosso corpo mortal de não poder simultaneamente com
outro ocupar um mesmo lugar, não lhe rica removido pelo dote da subtileza. Ora, nada pode impedir
um corpo de ocupar simultaneamente com outro um mesmo lugar, senão a lei natural pela qual cada
corpo deve ocupar um lugar diverso do ocupado por outro. Pois, não há outro obstáculo à identidade
senão o princípio da diversidade. Mas essa diversidade de lugar não implica no corpo nenhuma
qualidade, porque não é em razão de uma qualidade sua que ocupa um determinado lugar. Por onde,
removida de um corpo sensível a sua qualidade de quente ou frio, grave ou leve, nem por isso deixa de
haver a necessidade de nele introduzirmos a referida distinção, como está provado pelo Filósofo e já por
si mesmo é claro. Semelhantemente essa distinção não pode ter o seu fundamento na matéria; porque
a matéria não ocupa lugar senão mediante a quantidade dimensiva. Nem afinal à forma é devido um
lugar senão quando unida à matéria. Resta, pois, que o fato de dois corpos ocuparem dois lugares
diversos se funda na natureza da quantidade dimensiva, que por natureza ocupa um lugar: pois, na sua
definição se diz, que a quantidade dimensiva é a que ocupa um lugar. Donde vem que removidos todos
os atributos de um ser, o fundamento da referida distinção se encontra na só quantidade dimensiva.
Assim, considerando-se a linha separadamente, necessariamente forem duas ou duas partes de uma
mesma linha, hão de ocupar lugares distintos; do contrário, uma linha acrescentada a outra não se
tornaria maior, o que colide com o senso comum. E o mesmo se dá com as superfícies e os corpos
matemáticos. E como é da natureza da matéria, enquanto fundamento das dimensões, ocupar um lugar,
daí deriva para essa matéria como necessária a referida distinção.
De modo que assim como não é possível existirem duas linhas ou duas partes de uma mesma linha, se
não ocupando lugares distintos, assim é impossível existirem duas matérias ou duas partes de matéria
sem distinção de lugares. E como a distinção da matéria é o princípio da distinção dos indivíduos por isso
Boécio diz, que não podemos atribuir a dois corpos um mesmo lugar; de modo que ao menos essa
diversidade de acidentes a distinção dos indivíduos a requer.
Mas, como dizíamos, a subtileza não tira aos corpos gloriosos a dimensão. E portanto de nenhum modo
os isenta da necessidade de ocuparem lugares diversos. Portanto, um corpo glorioso não terá na sua
subtileza razão de poder ocupar simultaneamente com outro corpo o mesmo lugar. Mas poderá ocupar
o mesmo lugar simultaneamente com outro por obra do poder divino. Assim como também Pedro não
dava, por alguma propriedade que lhe fosse natural, à sua sombra o poder de curar os enfermos; mas o
poder divino assim o permitia para a propagação da fé. Do mesmo modo, o poder divino poderá fazer,
para perfeição da glória, que um corpo glorioso ocupe com outro simultaneamente o mesmo lugar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O corpo de Cristo não foi pelo dote da subtileza que pôde
ocupar simultaneamente com outro o mesmo lugar, mas isso se deu por virtude da sua divindade,
depois da ressurreição, como na natividade. Por isso Gregório diz: Aquele corpo do Senhor, que entrou
até onde estavam os discípulos, estando as portas fechadas, foi o mesmo que, pela sua natividade,
apareceu aos olhos dos homens, saído do seio virginal de Maria. Por onde, não é necessário que isso
convenha aos corpos gloriosos em razão da sua subtileza.

RESPOSTA À SEGUNDA. ─ A luz não é corpo, como já se estabeleceu, Por onde, a objeção procede de
falsas premissas.

RESPOSTA À TERCEIRA. ─ O corpo glorioso pode atravessar as esferas celestes sem as dividir, não por
força da sua subtileza, mas por poder divino, que lhes vem em auxílio, quando quer.

RESPOSTA À QUARTA. ─ Porque Deus concede, por um ato da sua soberana vontade, aos santos tudo o
que querem, é que não poderão ser cativos nem encarcerados.

RESPOSTA À QUINTA. ─ Segundo o Filósofo, ao ponto não é natural ocupar um lugar. Por onde, se
dissermos que está num lugar não será senão por acidente porque um corpo delimitado ocupa um
lugar. E como o lugar total corresponde ao corpo total, assim os limites do lugar correspondem aos
limites do corpo. Pode porém dar-se que lugares diversos tenham um termo comum, como duas linhas
terminem num mesmo ponto. Por isso, embora dois corpos não possam ocupar senão lugares diversos,
contudo a dois termos de dois corpos pode corresponder um mesmo termo de dois lugares. E neste
sentido se diz, que os extremos de dois corpos contíguos ocupam simultaneamente o mesmo lugar.

## Art. 3 — Se por milagre podem dois corpos ocupar simultaneamente o mesmo lugar.
O terceiro discute-se assim. ─ Parece que nem por milagre podem dois corpos ocupar
simultaneamente o mesmo lugar.

1. ─ Pois, nenhum milagre pode fazer com que dois corpos sejam simultaneamente dois e um só, porque
seria fazer os contraditórios existirem ao mesmo tempo. Ora, se admitíssemos dois corpos ocupando
simultaneamente o mesmo lugar resultaria que esses dois seriam um só corpo. Logo, não n'o pode
operar nenhum milagre. ─ Prova da média. Sejam dois corpos a ocuparem um mesmo lugar e chame-se
um A e B o outro. Ora, as dimensões de A serão as mesmas que as do lugar ou serão diversas. Se
diversas, haverá então dimensões separadas da matéria. O que é inadmissível, porque as dimensões
delimitadas por um lugar nenhum outro sujeito tem senão o corpo que ocupa esse lugar. Se porém
forem as mesmas, logo e pela mesma razão as dimensões do corpo B coincidem com as do lugar. Ora,
causas idênticas a uma terceira são idênticas entre si, diz Aristóteles. Logo, as dimensões de A e de B são
idênticas. Mas, dois corpos não podem ter as mesmas dimensões como não podem ser brancos pela
mesma brancura. Logo, A e B são um só corpo. E eram dois por suposição. Portanto, são
simultaneamente dois e um só.

2. Demais. ─ Nada pode ser feito milagrosamente contra as noções do senso comum; p. ex., que a parte
não seja menor que o todo, pois o que encontra as noções do senso comum diretamente implica
contradição. Semelhantemente, nenhum milagre pode contrariar as conclusões da geometria,
infalivelmente deduzidas das idéias do senso comum; assim, não pode fazer um triângulo não ter os
seus três ângulos iguais a dois retos. Do mesmo modo, nada pode ser suposto, considera uma linha,
contra a sua definição, porque separar a definição do definido é admitir a existência simultânea de dois
contraditórios. Ora, supor dois corpos ocupando simultaneamente o mesmo lugar contraria as noções
do senso comum, as conclusões da geometria e a definição da linha. Logo, nenhum milagre pode fazê-
lo. ─ Prova da média. É uma conclusão da geometria que dois círculos não podem tocar-se senão num
ponto. Ora, se dois corpos circulares ocuparem o mesmo lugar, dois círculos deles que supuséssemos se
tocariam na sua totalidade. Contraria também a definição da linha, porque levaria a existência de mais
de uma reta entre dois pontos, o que se daria se dois corpos ocupassem simultaneamente o mesmo
lugar, pois, entre dois pontos determinados em diversas superfícies do lugar haveria duas linhas retas,
dos dois corpos que ocupassem o mesmo lugar.

3. Demais. ─ Nenhum milagre pode fazer que um corpo incluso em outrem não ocupe lugar; porque
então ocuparia um lugar comum e não próprio ─ o que não pode ser. Ora, tal seria a consequência se
dois corpos ocupassem simultaneamente o mesmo lugar. Logo, isso nenhum milagre pode fazê-la. ─
Prova da média. ─ Sejam dois corpos num mesmo lugar, dos quais um tem uma das suas dimensões
maior que a do outro. O corpo menor estará incluso no maior e o lugar do maior será o lugar comum de
ambos. E não terá o corpo menor nenhum lugar próprio, por não haver nenhuma superfície atualmente
determinada que o contenha ─ o que é da essência do lugar. Logo, não terá o seu lugar próprio.

4. Demais. ─ O lugar corresponde proporcionalmente ao locado. Ora, nenhum milagre poderá jamais
fazer com que um mesmo corpo esteja simultaneamente em vários lugares, senão por uma espécie de
conversão, como se dá no sacramento do Altar. Logo, de nenhum modo pode um milagre fazer dois
corpos ocuparem simultaneamente o mesmo lugar.
Mas, em contrário. ─ A SS. Virgem deu a luz o seu filho milagrosamente. Ora, nesse parto bendito, dois
corpos ocuparam necessariamente o mesmo lugar ao mesmo tempo, porque o corpo do menino nasceu
sem detrimento da virgindade materna.

2. Demais. ─ O mesmo se pode demonstrar pelo fato de o Senhor ter entrado, estando as portas
fechadas, até onde estavam os discípulos.

SOLUÇÃO. ─ Como do sobre dito se colhe, dois corpos hão de necessariamente ocupar dois lugares
diversos, porque a diversidade de matéria exige a diversidade de lugares. E assim vemos, que quando
dois corpos se fundem num só, desaparece o ser distinto de um e de outro, ambos se reduzindo a um
corpo único, como o demonstram os mitos. Logo, não é possível dois corpos conservarem cada qual a
sua individualidade e contudo existirem simultaneamente, senão conservando cada um o seu ser
distinto primitivo, que fazia de cada um deles um ser em si mesmo indiviso e dividido de todos os mais.
Ora, a existência distinta de cada ser depende dos princípios essenciais de cada um, como da causa
próxima, mas de Deus como da causa primeira. Mas a causa primeira pode conservar a existência de um
ser, fazendo cessar a ação das causas segundas, como o demonstra a primeira proposição do livro De
causis. Por onde, o poder divino e só ele pode fazer um acidente existir sem o sujeito, como se dá no
sacramento do Altar. Do mesmo modo, o poder divino, e só ele, pode fazer com que um corpo conserve
o seu ser distinto do outro, embora a sua matéria não ocupe lugar diferente do lugar ocupado pela
matéria de outro. E assim, podem milagrosamente dois corpos ocuparem ao mesmo tempo o mesmo
lugar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O raciocínio feito é sofístico por proceder de uma falsa
suposição ou de uma petição de princípio. ─ Pois, começa supondo que entre as duas superfícies
opostas de um lugar exista uma dimensão própria ao lugar a que se unisse a dimensão do corpo que
nele viesse colocar-se. Ora, esta suposição é falsa; pois, do contrário, sempre que um corpo passasse a
ocupar um novo lugar, necessariamente sofreriam uma modificação as dimensões do lugar ou do corpo
locado; porque não é possível dois corpos virem a constituir um só, senão sofrendo um deles uma
alteração. Mas se, como é verdade, o lugar não tem outras dimensões senão as do corpo locado, é claro
que o raciocínio aduzido nada prova. ─ Mas o raciocínio em questão se funda numa petição de princípio.
Pois, outra causa não afirma, além de afirmar as dimensões do corpo locado idênticas às do lugar, senão
que as dimensões do corpo locado estão contidas entre os limites do lugar, e nessas mesmas dimensões
distam os limites do lugar como se lhes fossem suas dimensões próprias de distância, se as tivessem. E
assim as dimensões de dois corpos seriam as de um só lugar, o que outra causa não é senão ocuparem
os dois corpos simultaneamente o mesmo lugar. Ora, era essa mesma a hipótese inicial.

RESPOSTA À SEGUNDA. ─ Suposto que dois corpos ocupem simultaneamente o mesmo lugar, por
milagre, daí nada se segue contra as noções do senso comum, nem contra a definição da linha, nem
contra nenhuma conclusão da geometria. Pois, como dissemos, a quantidade dimensiva difere de todos
os outros acidentes, por ter um princípio próprio de individuação e de distinção, na situação local das
suas partes; além do princípio de individuação e de distinção ─ a matéria, sujeito da forma ─ que lhe é
comum com todos os outros acidentes. Assim, pois, podemos conceber uma linha como diversa de
outra, ou por ter um outro sujeito, como no caso da linha material; ou por ter uma situação diferente,
como no caso da linha matemática, cujo conceito é abstrato da matéria. Removida pois a matéria, não
poderá haver distinção entre as linhas, senão pelas posições diversas delas; e semelhantemente, nem
dos pontos, nem das superfíceis, nem de quaisquer outras dimensões. E assim a geometria não pode
supor uma linha acrescentada à outra, como distinta uma da outra, senão tendo posição diferente. Mas,
suposta a distinção de sujeitos sem a de posições, por milagre divino, podem considerar-se diversas as
linhas com diversidade de sujeito embora sem diferirem de posição; e também diversos os pontos. E
assim, linhas diversas traçadas em dois corpos, que ocupam o mesmo lugar, ficam delimitadas por
pontos diversos; o ponto é então concebido por nossa, inteligência não no espaço, mas no corpo locado,
porque uma linha não é delimitada senão pelos seus pontos terminais. Do mesmo modo, dois círculos
determinados em dois corpos esféricos existentes num mesmo lugar, são dois, não pela diversidade de
suas posições, aliás não podiam tocar-se na sua totalidade, mas pela diversidade de seus sujeitos; e por
isso, apesar de se tocarem na sua totalidade, ainda permanecem dois. Assim como também um círculo,
determinado num corpo esférico, locado, é tangente na sua totalidade a outro círculo determinado no
corpo que o localiza.

RESPOSTA À TERCEIRA. ─ Deus poderia fazer com que um corpo não ocupasse nenhum lugar. Mas daí
não se segue que outro corpo também não ocupe um lugar. Porque o corpo maior é o lugar do menor
em razão de aquela superfície que seria determinada pelo contacto das extremidades do corpo menor.

RESPOSTA À QUARTA. ─ Nenhum milagre pode fazer com que um corpo ocupe simultaneamente dois
lugares: pois, o corpo de Cristo, não está localmente no altar; embora milagrosamente possam dois
corpos ocupar ao mesmo tempo o mesmo lugar. Porque estar em vários lugares simultaneamente
repugna ao indivíduo em razão de ser ele, na sua essência, um todo indiviso. Pois, do contrário resultaria
a sua divisão pela diferença das situações. Mas ocupar o mesmo lugar já ocupado por outro corpo,
repugna-lhe por ser um indivíduo como tal dividido de qualquer outro. Pois, a unidade se completa pela
indivisão, como ensina o Filósofo; mas o ser separado dos outros resulta da essência da unidade. Por
onde, estar um corpo localmente em diversos lugares ao mesmo tempo implica contradição, como a
implica conceber-se um homem privado de razão. Mas nenhuma contradição implica dois corpos
ocuparem simultaneamente o mesmo lugar, como do sobredito se colhe. Logo, não há símil.

## Art. 4 — Se um corpo glorioso pode ocupar o mesmo lugar já ocupado por outro corpo glorioso.
O quarto discute-se assim. ─ Parece que um corpo glorioso pode ocupar o mesmo lugar ocupado por
outro corpo glorioso.

1. ─ Pois, onde há maior subtileza há menor resistência. Se, portanto, um corpo glorioso é mais subtil
que um não-glorioso, menos resistência oferecerá este àquele. E assim, desde que um corpo glorioso
pode ocupar o mesmo lugar já ocupado por um não-glorioso, com muito maior razão poderá ocupar
simultaneamente com outro corpo glorioso o mesmo lugar.

2. Demais. ─ Assim como o corpo glorioso será mais subtil que o não glorioso, assim um corpo glorioso
será mais subtil que outro. Se, portanto, um corpo glorioso pode ocupar o mesmo lugar já ocupado por
um corpo não glorioso, também um corpo glorioso mais subtil para coexistir num mesmo lugar com um
corpo glorioso menos subtil.

3. Demais. ─ O corpo celeste é subtil, e na ressurreição será glorificado. Ora, o corpo glorioso de um
santo poderá ocupar o mesmo lugar que o corpo celeste; porque os santos poderão descer à terra e
subir ao céu conforme quiserem. Logo, dois corpos gloriosos poderão ocupar simultaneamente o
mesmo lugar.
Mas, em contrário. ─ Os corpos gloriosos serão espirituais, i. é, de certo modo semelhantes aos espíritos.
Ora, dois espíritos não poderão ocupar simultaneamente o mesmo lugar, embora o corpo e o espírito o
possam, como se disse. Logo, nem dois corpos gloriosos poderão ocupar simultaneamente o mesmo
lugar.

2. Demais. ─ Dois corpos ocupando o mesmo lugar, um será penetrado pelo outro. Ora, é sinal de
inferioridade ser um corpo penetrado por outro, inferioridade que de nenhum modo existirá nos corpos
gloriosos. Logo, dois corpos gloriosos não poderão ocupar simultaneamente o mesmo lugar.

SOLUÇÃO. ─ Um corpo glorioso nenhuma propriedade tem que lhe permita ocupar o mesmo lugar já
ocupado por outro corpo glorioso ou não-glorioso. Mas o poder divino pode fazer que ocupem
simultaneamente o mesmo lugar dois corpos gloriosos ou dois não gloriosos ou um glorioso e outro não
glorioso. Não é contudo curial dois corpos gloriosos ocuparem simultaneamente o mesmo lugar. Quer
porque a ordem devida a que devem obedecer exige a separação; quer porque um corpo glorioso não
pode opor-se a outro. E assim dois corpos gloriosos não ocuparão nunca simultaneamente o mesmo
lugar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A objeção colheria se um corpo glorioso pudesse, em
razão da sua subtileza, ocupar simultaneamente com outro o mesmo lugar. O que é falso.
E do mesmo modo devemos responder à segunda objeção.

RESPOSTA À TERCEIRA. ─ O corpo celeste e os demais corpos se chamam equivocamente gloriosos,
enquanto de certo modo participam da glória, e não por lhes convir os dotes dos corpos humanos
glorificados.

## Art. 5 — Se pela sua subtileza um corpo glorioso não está mais adstrito a existir num lugar que lhe seja igual.
O quinto discute-se assim. ─ Parece que pela sua subtileza um corpo glorioso não está mais adstrito a
existir num lugar que lhe seja igual.

1. ─ Pois, os corpos gloriosos serão conformes ao corpo de Cristo, como diz o Apóstolo. Ora, o corpo de
Cristo não está adstrito num lugar que lhe seja igual, antes, está contido todo numa hóstia consagrada
de pequena ou grande dimensão. Logo, o mesmo se dará com os corpos gloriosos.

2. Demais. ─ O Filósofo prova, que de dois corpos ocuparem o mesmo lugar resulta que o corpo maior
ocupará menos espaço, porque as suas diversas partes poderiam ocupar ao mesmo tempo uma só e
mesma parte do espaço. E se dois corpos podem ocupar um mesmo espaço, nada impede que multas
também o possam. Ora, um corpo glorioso ocupará simultaneamente o mesmo lugar que outro,
segundo a opinião comum. Logo, pode também ser encerrado num espaço mínimo.

3. Demais. ─ Assim como é a cor que toma os corpos visíveis, assim é pela quantidade que ocupam um
lugar no espaço. Ora, um corpo glorioso está de tal modo sujeito ao espírito, que poderá ser visto ou
não, conforme a sua vontade, sobretudo por olhos não glorificados; tal o caso de Cristo. Logo, de modo
a sua quantidade está sujeita ao império do espírito, que poderá o corpo glorioso ocupar um grande ou
pequeno espaço e ter pequena ou grande quantidade, conforme lh'o aprouver.
Mas, em contrário, diz o Filósofo, que tudo o que ocupa um lugar, ocupa-o de dimensões igual a si. Ora,
o corpo glorioso ocupará um lugar. Logo, um lugar igual a si.

2. Demais. ─ As dimensões de um corpo são idênticas às do lugar que ele ocupa, como o prova
Aristóteles. Logo, se um lugar fosse maior que o corpo nele encerrado, a mesma causa seria maior e
menor que ela própria. O que é inadmissível.

SOLUÇÃO. ─ Um corpo não se relaciona com um lugar senão mediante as dimensões de um e de outro,
pelas quais o corpo que ocupa um lugar é circunscrito pelo contato de outro corpo, que o localiza. Por
onde, o ocupar um corpo um lugar menor que o exigido pela sua quantidade, não pode ser senão
porque a sua quantidade própria assume tamanho menor.
O que não podemos conceber senão de dois modos.
De um modo, por variação da quantidade da mesma matéria; de maneira que a matéria tivesse, antes,
uma quantidade maior, vindo a ser menor depois. E isto certos o atribuíram aos corpos gloriosos,
dizendo que fazem variar a sua quantidade como lhes apraz, de modo que poderão, à vontade, ter uma
quantidade grande ou pequena. ─ Mas isto é insustentável. Porque nenhum movimento, cujo objeto é o
que é intrínseco a uma causa pode existir sem que a substância mesma dessa causa sofra uma alteração.
Por isso os corpos incorruptíveis, i. é, os celestes, só podem se mover localmente, movimento que não
atinge nada do que intrínsecamente os constitui. Por onde, é claro que a alteração da quantidade da
matéria repugnaria à impassibilidade. Donde, além disso, se seguiria que um corpo glorioso seria ora
mais rarefeito e ora mais denso. Porque, não podendo sofrer nenhuma divisão na sua matéria, esta teria
umas vezes dimensões menores e outras vezes maiores, e assim seria ora mais rarefeito e ora mais
denso. O que não é possível.
De outro modo, podemos conceber que a quantidade de um corpo glorioso venha a ser menor por
variação do lugar; de modo que as partes desse corpo entrem umas nas outras, de sorte que possa
reduzir-se a uma quantidade mínima. E isto certos o pretenderam, dizendo que, em razão da sua
subtileza, poderá um corpo não glorioso existir simultaneamente com outro corpo não glorioso no
mesmo lugar. Do mesmo modo, poderá uma parte ficar dentro da outra, a ponto de poder um corpo
glorioso entrar na sua totalidade por um orifício mínimo do outro corpo. E afirmam que assim o corpo
de Cristo nasceu do ventre virginal e entrou, pelas portas fechadas, até onde estavam os discípulos. ─
Mas isto não pode ser. Quer porque um corpo glorioso não será, em razão da sua subtileza, que poderá
ocupar simultaneamente com outro o mesmo lugar. Quer também porque se pudesse ocupar o mesmo
lugar já ocupado por outro corpo, não seria contudo este último um corpo glorioso como dizem muitos.
Quer porque repugnaria à disposição do corpo humano, que exige um lugar determinado e uma
determinada diferença de partes. Por isso nem por milagre tal poderia dar-se.
Donde pois devemos concluir que um corpo glorioso ocupará sempre um lugar que lhe seja igual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O corpo de Cristo não está localmente no sacramento do
Altar, como se disse.

RESPOSTA À SEGUNDA. ─ A prova do Filósofo se funda na hipótese de uma parte, pela mesma razão,
entrasse em outra. Ora, não é possível as partes dos corpos gloriosos entrarem umas nas outras, como
dissemos. Logo, a objeção não colhe.

RESPOSTA À TERCEIRA. ─ Um corpo é visto por agir sobre a nossa vista. Mas que nos atinja ou não a
vista, nenhuma alteração acarreta para o corpo. Não repugna, pois, que se deixe ver ou não, ao arbítrio
da sua vontade. Mas ocupar um lugar não é ação procedente do corpo em razão da sua quantidade,
como ver o é em razão da sua cor. Logo, não há símil.

## Art. 6 — Se o corpo glorioso em razão da sua subtileza é impalpável.
O sexto procede-se assim. ─ Parece que o corpo glorioso é impalpável em razão da sua subtileza.

1. ─ Pois, Gregório diz: O palpável é necessariamente corruptível. Ora, o corpo glorioso é incorruptível.
Logo, será impalpável.

2. Demais. ─ Tudo o que é palpável opõe resistência a quem o apalpa. Ora, um corpo, que pode ocupar
simultaneamente com outro um mesmo lugar, não lhe opõe nenhuma resistência. Logo, como um corpo
glorioso pode ocupar simultaneamente com outro o mesmo lugar, não será palpável.

3. Demais. ─ Todo corpo palpável é tangível. Ora, todo corpo tangível tem qualidades tangíveis
excedentes ao poder do agente que o toca. Logo, como as qualidades tangíveis dos corpos gloriosos
nada tem de excessivo, mas são dotadas de um equilíbrio máximo, resulta que não são esses corpos
tangíveis.
Mas, em contrário, o Senhor ressurgiu com um corpo glorioso; e contudo teve um corpo palpável,
conforme aquilo do Evangelho: Apalpai e vede, que um espírito não tem carne nem ossos. Logo,
também os corpos gloriosos serão palpáveis.

2. Demais. ─ É a heresia de Eutíquio Constantinopolitano bispo, como refere Gregório, afirmar que o
nosso corpo ressurrecto será impalpável.

SOLUÇÃO. ─ Todo corpo palpável é tangível, mas não ao inverso. Pois, tangível é todo corpo que tem
qualidades naturais capazes de afetar o sentido do tato; assim, o ar, o fogo e corpos semelhantes são
corpos tangíveis. Mas a idéia de palpável acrescenta o poder de resistir ao corpo tangente; por isso, o ar,
que nunca opõe resistência a quem o atravessa, mas é de uma divisão facílima, é tangível, mas não
palpável. Por onde é claro que por duas razões dizemos que um corpo é palpável: pelas suas qualidades
tangíveis e pela resistência que opõe a ser atravessado pelo agente que o toca. Ora, as qualidades
tangíveis são o calor, o frio e outras semelhantes, que só existem nos corpos graves e nos leves, que tem
contrariedade entre si e por isso são corruptíveis. Por isso os corpos celestes, por natureza
incorruptíveis, podem ser atingidos pela vista, mas não tangíveis e, portanto, nem palpáveis. Daí o dizer
Gregório, que necessariamente é corruptível tudo o que é palpável.
Logo, o corpo glorioso tem por natureza qualidades capazes de atingir o tato. Contudo, como esse corpo
está completamente sujeito ao espírito, do seu poder depende que essas qualidades atinjam ou não o
tato. Semelhantemente, por natureza pode opor resistência à penetração de qualquer outro corpo, de
modo que não pode ocupar simultaneamente com este o mesmo lugar. Mas isto pode dar-se
milagrosamente por obra do poder divino, de modo que, conforme à sua vontade, possa ocupar
simultaneamente com outro o mesmo lugar sem opor resistência à penetração deste. Por onde, um
corpo glorioso é por natureza palpável; mas, por virtude sobrenatural, pode, quando quiser, não se
deixar tocar por um corpo não-glorioso. Por isso Gregório acrescenta: O Senhor consentiu que o seu
corpo fosse tocado, esse mesmo corpo que atravessou portas fechadas, para mostrar que, depois da
ressurreição, o seu corpo tinha a mesma natureza, mas uma glória diferente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A incorruptibilidade do corpo glorioso não vem da
natureza de nenhuns elementos componentes, que torna corruptível todo corpo susceptível de ser
tocado, como do sobredito resulta. Logo, a objeção não colhe.

RESPOSTA À SEGUNDA. ─ Embora de algum modo seja possível um corpo glorioso ocupar um lugar
ocupado ao mesmo tempo por outro, contudo tal corpo tem o poder de resistir a qualquer tangente
quando quiser. E portanto pode ser tocado.

RESPOSTA À TERCEIRA. ─ As qualidades tangíveis dos corpos gloriosos não reduzem à mediania real
pela equidistância dos extremos; mas a uma mediania proporcional, a mais conveniente a cada uma das
partes na compleição do corpo humano. Por isso o contato com tais corpos será deleitabilissimo; porque
uma potência se compraz sempre com o objeto que lhe convém, e sorri com o que lhe é
desproporcionado.