# Questão 38: Dos que conferem este sacramento.
Em seguida devemos tratar dos que conferem este sacramento.
Sobre o que discutem-se duas questões:

## Art. 1 — Se só o bispo é quem pode conferir o sacramento da ordem.
O primeiro discute-se assim. ─ Parece que não é só o bispo quem pode conferir o sacramento da
ordem.

1. ─ Pois, a imposição das mãos produz de certo modo a consagração. Ora, aos ordenandos não só o
bispo impõe as mãos, mas também os sacerdotes assistentes. Logo, não é só o bispo quem confere o
sacramento da ordem.

2. Demais. ─ Confere-se o poder da ordem quando se lhe apresenta o concernente às funções das suas
ordens. Ora, ao subdiácono o arcedíago lhe apresenta as galhetas com a água e os pratinhos e o
manutégio. Semelhantemente, os acólitos recebem a tacha com o círio e as galhetas vazias. Logo, não só
o bispo é quem pode conferir o sacramento da ordem.

3. Demais. - As funções da ordem não podem ser cometidas senão a quem na tem. Ora, conferir as
ordens menores é atribuído a certos que não são bispos, como os cardeais presbíteros. Logo, conferir as
ordens não é privativo da ordem episcopal.

4. Demais. ─ A quem é atribuído o principal também o é o acessório. Ora, o sacramento da ordem se
destina ao da Eucaristia, como o acessório ao principal. Logo, como o sacerdote consagra a Eucaristia,
também poderá conferir as ordens.

5. Demais. ─ Mais dista o sacerdote, do diácono que um bispo, de outro. Ora, um bispo pode consagrar a
outro. Logo, também um sacerdote pode promover um diácono.
Mas, em contrário. ─ Os ministros ordenados servem ao culto divino de maneira mais nobre que os
vasos sagrados. Ora, consagrar os vasos só o pode o bispo. Logo e com maior razão só ele pode
consagrar os ministros.

2. Demais. ─ O sacramento da ordem é mais excelente que o da confirmação. Ora, só o bispo pode
confirmar. Logo e com maior razão, só ele pode conferir o sacramento da ordem.

3. Demais. ─ As virgens, pela bênção que recebem, não ficam constituídas em nenhum grau de poder
espiritual, como o ficam os ordenados. Ora, dar a bênção às virgens só o pode o bispo. Logo e com
maior razão, só ele pode ordenar.

SOLUÇÃO. ─ O poder episcopal está para o das ordens inferiores, como a política, cujo fim é o bem
comum, para as artes e virtudes inferiores, que visam algum bem particular, conforme do sobre dito
resulta. Ora, como dissemos, a política da lei às disciplinas inferiores, regulando quem deve exercê-las,
quanto e de que modo. Por isso cabe ao bispo determinar a cada um dos seus subordinados o ministério
divino que devem exercer. Donde vem que só ele pode confirmar, porque aos confirmados incumbe o
dever de confessar a fé. Por isso também só ele abençoa as virgens, que representam a Igreja, esposa de
Cristo, cujo governo principalmente foi confiado ao bispo. Também ele é quem consagra os ordenandos
aos ministérios das ordens, e os vasos ele os determina pela sua consagração. Assim como as funções
seculares, nas cidades, são distribuídas por quem tem o poder mais elevado, como por exemplo, o rei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A imposição das mãos não confere o caráter sacerdotal
da ordem, como do sobredito resulta, pelo qual o ordenado se torna idôneo ao exercício dela. E como
precisam de uma graça amplíssima, por isso os sacerdotes, com o bispo, impõem as mãos aos
promovidos ao sacerdócio; ao passo que aos diáconos só o bispo lhes impõe as mãos.

RESPOSTA À SEGUNDA. ─ Sendo o arcedíago o como chefe do ministério, ele é quem confere tudo o
concernente a estes assim, o círio, que o acólito traz, servindo ao diácono, diante do Evangelho, e as
galhetas, com que serve ao subdiácono. E semelhantemente, dá ao subdiácono o com que serve às
ordens superiores. Nisso porém não consiste a função principal do subdiácono, mas em cooperar na
produção da matéria do sacramento. Por isso recebe o caráter quando lhe é oferecido o cálice pelo
bispo. Ao passo que o caráter o acólito o recebe das palavras do bispo, quando lhe apresenta o
arcedíago os objetos supra-referidos: e antes, quando recebe as galhetas, que quando recebe o círio.
Donde não se segue que o arcedíago confira a ordem.

RESPOSTA À TERCEIRA. ─ O Papa, que tem a plenitude do poder pontifical, pode conferir a quem não é
bispo a dignidade episcopal, contanto que ela não tenha imediata relação com o verdadeiro corpo de
Cristo. Assim, por comissão episcopal, pode um simples sacerdote conferir as ordens menores e a
confirmação; não porém quem não for sacerdote. Mas nem mesmo um sacerdote poderá conferir as
ordens maiores, que tem relação imediata com o corpo de Cristo, para consagrar o qual o Papa não tem
maior poder que um simples sacerdote.

RESPOSTA À QUARTA. ─ Embora o sacramento da Eucaristia seja de todos o máximo, em si mesmo
considerado, contudo a ninguém confere uma função, como o sacramento da ordem. Logo, não há
semelhança de razão.

RESPOSTA À QUINTA. ─ Para comunicarmos a outrem o que temos não é necessário só proximidade,
mas também plenitude de poderes. E como o sacerdote não tem essa plenitude, nos ofícios
hierárquicos, como o bispo, daí não se segue que possa conferir o diaconato, embora esta ordem seja a
mais próxima da sua.

## Art. 2 — Se os heréticos excluídos da Igreja podem conferir as ordens.
O segundo discute-se assim. ─ Parece que os heréticos e excluídos da Igreja não podem conferir as
ordens.

1. ─ Pois, mais é conferir ordens do que absolver ou ligar. Ora, o herético não pode absolver nem ligar.
Logo, não pode conferir ordens.

2. Demais. ─ O sacerdote excluído da Igreja pode consagrar, porque o caráter que lhe deu esse poder
nele permanece indelevelmente. Ora, o bispo, quando promovido à sua dignidade, não recebe nenhum
caráter. Logo, não é forçoso que o poder episcopal nele permaneça depois da sua exclusão da Igreja.

3. Demais. ─ Todo o que é excluído de uma comunidade não pode mais dispor dos ofícios dela. Ora, as
ordens são uns ofícios da Igreja. Logo, quem é excluído dela não pode conferir.

4. Demais. ─ Os sacramentos haurem a sua eficácia na paixão de Cristo. Ora, o herético não lhe
aproveita a paixão de Cristo ─ nem pela sua fé própria, pois é infiel; nem pela da Igreja, pois dela está
excluído. Logo, não pode conferir o sacramento da ordem.

5. Demais. ─ A colação da ordem implica a bênção. Ora, o herético não pode abençoar; ao contrário, a
sua bênção se converte em maldição, como o demonstram as autoridades citadas pelo Mestre. Logo,
não pode conferir as ordens.
Mas, em contrário, o bispo que incidir em heresia, quando se reconcilia não precisa ser sagrado de novo.
Logo, não perdeu o poder que tinha de conferir as ordens.

2. Demais. ─ O poder de conferir as ordens é superior ao de exercê-las. Ora, o poder de as exercer não
fica perdido por heresia ou coisa semelhante. Logo, nem o poder de as conferir.

3. Demais. ─ Como quem batiza exerce um ministério só externo, assim também quem confere as
ordens, pois quem obra interiormente é Deus. Ora, por nenhuma razão quem é excluído da Igreja perde
o poder de batizar. Logo, nem o de conferir as ordens.

SOLUÇÃO. ─ Nesta matéria o Mestre das Sentenças apresenta quatro opiniões.
Assim, certos disseram que os heréticos, enquanto tolerados na Igreja, tem o poder de conferir as
ordens, mas não depois de excluídos dela; do mesmo modo os degradados e outros tais. E esta é a
primeira opinião. ─ Mas não é admissível. Porque todo poder dado em virtude de uma consagração em
nenhum caso pode desaparecer, enquanto existe o seu titular, como também a consagração não pode
ser anulada; assim, mesmo o altar ou o crisma, uma vez consagrados, consagrados permanecem
perpetuamente. Por onde, como o bispo recebe o seu poder mediante uma consagração, há de ela
permanecer perpetuamente, por mais que pequena ou seja excluído da Igreja. Por isso outros disseram
que os excluídos da Igreja, que nela desempenhavam funções episcopais, conservam o poder de
ordenar e promover, mas os promovidos não recebem deles as dignidades a que o foram. E esta é a
quarta opinião. ─ Mas também isto não pode ser. Porque se os promovidas a uma dignidade eclesiástica
conservam o poder que receberam, é claro que, exercendo as suas funções, consagram
verdadeiramente. E portanto conterem verdadeiramente todo poder que receberam com a
consagração. E assim os ordenados ou promovidos por eles tem o mesmo poder que eles tem.
Por isso disseram outros, que também os excluídos da Igreja podem conferir a ordem e os demais
sacramentos contanto que observem a forma devida e também a intenção de à conferir. E a conferem
tanto quanto ao primeiro efeito, que é a colação do sacramento, como quanto ao último, que é a
colação da graça. E esta é a segunda opinião. ─ Mas também não pode sustentar-se. Porque o fato
mesmo de comunicarmos, em matéria de sacramentos, com um herético excluído da Igreja é pecado.
Por onde, quem assim recebe o sacramento o faz dissimulado e não pode obter a graça, salvo no
batismo e em artigo de necessidade. Por isso outros dizem, que conferem verdadeiramente os
sacramentos mas com estes não é dada a graça; não por ineficácia deles, mas pelo pecado de quem
recebe, desses tais, os sacramentos, com proibição da Igreja. E esta é a terceira opinião e a verdadeira.

DONDE A RESPOSTA À OBJEÇÃO. ─ O efeito da absolvição não é outro senão o perdão dos pecados
dado de graça. Por isso, um herético não pode absolver como nem conferir a graça com os sacramentos.
Além disso, para absolver é preciso ter jurisdição, e essa não na tem o excluído da Igreja.

RESPOSTA À SEGUNDA. ─ Quando o bispo é promovido ao episcopado é-lhe dado um poder, que
permanece sempre, embora não possa ser chamado caráter; porque esse poder não destina ninguém
diretamente para Deus, mas para o corpo místico de Cristo. E contudo, permanece indelével, como o
caráter, e é dado pela consagração.

RESPOSTA À TERCEIRA. ─ Os promovidos pelos heréticos, embora recebam a ordem, não recebem
contudo o exercício dela de modo a poderem licitamente ministrar de acordo com as ordens que tem,
pela razão aduzida na objeção.

RESPOSTA À QUARTA. ─ Pela fé da Igreja continuam os heréticos a receber os benefícios da paixão de
Cristo. Pois, embora a ela não lhe pertençam, como tais; pertencem-lhe porém pelo rito da Igreja, que
observam.

RESPOSTA À QUINTA. ─ Isso se deve referir ao efeito último dos sacramentos, como ensina a terceira
opinião.