# Questão 27: Daqueles para quem valem as indulgências.
Em seguida devemos tratar daqueles a quem valem as indulgências.
Nesta questão discutem-se quatro artigos:

## Art. 1 — Se a indulgência vale para quem está em pecado mortal.
O primeiro discute-se assim. — Parece que a indulgência vale para os que estão em pecado mortal.

1. — Pois, pode um, mesmo em pecado mortal, merecer para outrem a graça e muitos outros bens. Ora,
as indulgências tiram sua eficácia da aplicação dos méritos dos santos a uma determinada pessoa. Logo,
produzem o seu efeito sobre os que estão em pecado mortal.

2. Demais. — Onde há maior indigência, aí há mais lugar à misericórdia. Ora, quem está em pecado
mortal está na máxima indigência. Logo, a ele sobretudo se lhe deve misericórdia, mediante a
indulgência.
Mas, em contrário. — Um membro morto já não recebe influência dos outros membros vivos. Ora,
quem está em pecado mortal é um como membro morto. Logo, pela indulgência não sofre a influência
dos méritos dos membros vivos.

SOLUÇÃO. — Certos dizem que as indulgências valem mesmo para os que estão em pecado mortal. Não
certo para perdão da pena, porque não pode a pena ser perdoada senão a quem o foi a culpa; porque
quem não conseguiu de Deus a remissão da culpa não pode conseguir de um ministro da Igreja a
remissão da pena, nem mediante as indulgências, nem no foro da penitência; as indulgências porém lhe
valem para adquirir a graça. — Mas esta opinião não é verdadeira. Porque, embora os méritos
comunicados pela indulgência possam valer para se merecer a graça, não é para isso contudo que são
dispensados, mas determinadamente para a remissão da pena. Portanto, não vale para quem está em
pecado mortal. Por isso, em todas as indulgências se faz menção dos verdadeiramente contritos e
confessados. — Se a comunicação fosse feita porem deste modo — Faço-te participante dos méritos de
toda a Igreja, ou de uma comunidade, ou de uma pessoa em especial - então poderá valer para merecer
algo, a quem esta em pecado mortal, como diz a opinião referida.
Donde se deduz a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Embora quem esta em pecado mortal seja mais indigente, contudo é menos
capaz.

## Art. 2 — Se as indulgências valem para os religiosos.
O segundo discute-se assim. — Parece que as indulgências não valem para os religiosos.

1. — Pois, não se deve suprir aqueles cuja superabundância supre os outros. Ora é da superabundância
das obras satisfatórias dos religiosos que se suprem os outros, pelas indulgências. Logo, não devem eles
ser supridos pelas mesmas.

2. Demais. — Nada deve fazer-se na Igreja que leve outrem à dissolução. Ora, se as indulgências
aproveitassem aos religiosos dariam ocasião à dissolução da disciplina regular; porque então os
religiosos passariam a vida em peregrinações, para ganhar tais indulgências, e não cumpririam as penas
que lhes foram impostas no capítulo. Logo, não lhas aproveitam.
Mas, em contrário. — Ninguém colhe dano, e um bem. Ora, a religião é um bem. Logo, não podem os
religiosos sofrer o dano de não lhes valerem as indulgências.

SOLUÇÃO. — Tanto aos seculares como aos religiosos valem as indulgências, contanto que tenham a
caridade e observem as condições nas quais elas são concedidas; pois, os religiosos não aproveitam
menos que aos seculares os méritos alheios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o religioso esteja no estado de perfeição,
contudo não pode viver isento de pecado. Por onde, se vier a ser réu de uma pena, por um pecado
cometido, pode expiá-lo pelas indulgências. Pois, nenhuma impossibilidade há em aquele que tem
superabundância, absolutamente falando, sofrer necessidade em tempo determinado e em certas
condições, e assim precisa de um suplemento de méritos que o socorra. Donde o dizer o Apóstolo: Levai
uns as cargas dos outros.

RESPOSTA À SEGUNDA. — As indulgências não devem ser causa da dissolução da observância regular;
pois, os religiosos merecem mais, observando as regras da sua religião para alcançarem o prêmio da
vida eterna, do que buscando ganhar indulgências, embora mereçam menos, procedendo do primeiro
modo; quanto ao perdão da pena, que é um menor bem. Além disso, pelas indulgências não ficam
perdoadas as penas impostas no capítulo, porque este funciona antes como foro judicial do que como
foro da penitência; por isso, mesmo um não sacerdote pode presidir o capítulo. Quanto às penas
devidas pelos pecados cometidos, é no tribunal da penitência que um religioso é absolvido da pena
imposta ou devida, pelo pecado.

## Art. 3 — Se a quem não praticou o ato prescrito, para ganhar a indulgência, se lhe pode às vezes conceder esta.
O terceiro discute-se assim. — Parece que a quem não praticou o ato prescrito, para ganhar a
indulgência, se lhe pode às vezes conceder esta.

1. — Pois, quem não pode agir, a vontade lhe supre o ato. Ora, às vezes se concede uma indulgência por
uma esmola a ser feita, que um pobre não pode fazer embora de boa vontade o fizesse. Logo, a
indulgência não lhe aproveita.

2. Demais. — Um pode satisfazer por outro. Ora, a Indulgência, como a satisfação, se ordena ao perdão
da pena. Logo, um pode ganhar indulgência por outro. E assim, ganhará a indulgência quem não estava
nas condições de a ganhar.
Mas, em contrário. — Eliminada a causa, eliminado fica o efeito. Quem, pois, não se submeter à
condição exigida para ganhar a indulgência, o que é a causa dela, esse não a alcançará.

SOLUÇÃO. — Sem a condição não se ganha o que condicionalmente é dado. Ora, como a indulgência é
concedida sob a condição de fazermos ou darmos alguma coisa, se não o fizermos, não ganharemos a
indulgência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Isso se entende quanto ao prêmio essencial; mas não
quanto aos prêmios acidentais, como o perdão da pena e outros semelhantes.

RESPOSTA À SEGUNDA. — Uma obra própria nossa podemos aplicá-la pela intenção que quisermos;
portanto, podemos satisfazer por quem quisermos. Mas, uma indulgência a ninguém podemos aplicá-la,
senão conforme à intenção de quem a concede. Por onde, se este a concede a quem fizer ou dar uma
coisa, quem tal fizer não pode transferir a indulgência a outra intenção. Se porém a indulgência fosse
concedida nestes termos — Aquele que fizer ou aquele por quem fizer tal causa ganhará tanto de
indulgência — valeria ela para aquele a quem tal coisa é feita. Mas nem por isso quem fizesse tal obra
daria ao outro a indulgência; senão aquele que a concede sob tal forma.

## Art. 4 — Se a indulgência vale para quem a concede.
O quarto discute-se assim. — Parece que a indulgência não vale para quem a concede.

1. — Pois, conceder uma indulgência é de quem tem a jurisdição. Ora, ninguém pode exercer a
jurisdição sobre si mesmo. Logo, ninguém pode participar da indulgência por si mesmo concedida.

2. Demais. — Se assim fosse, quem concede a indulgência poderia, com uma prática de valor mínimo,
perdoar-se a si mesmo a pena de todos os seus pecados; e assim pecaria impunemente. O que é
inadmissível.

3. Demais. — Quem pode conceder indulgências também pode excomungar. Ora, ninguém pode
excomungar a si mesmo. Logo, também não pode ser participante da indulgência que concede.
Mas, em contrário, ficaria em piores condições que os outros, se não pudesse usar do tesouro da Igreja,
que dispensa a eles.

SOLUÇÃO. — Uma indulgência deve ser dada por alguma causa, para sermos levados à prática de um
ato que redunde em utilidade da Igreja e honra de Deus. Ora, o prelado a quem foi cometido o dever de
zelar pela utilidade da Igreja e pela honra divina, não tem causa para se excitar a si mesmo a ganhar a
indulgência. Por isso não pode conferir nenhuma indulgência a si mesmo. Mas pode aproveitar da que
concede aos outros, pois, tem alguma causa para lhes conceder a eles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Ninguém pode exercer sobre si mesmo um ato de
jurisdição. Ora, daquilo que é dado a outrem pela autoridade, que tem jurisdição, pode também o
prelado servir-se, tanto na ordem temporal como na espiritual; assim como o sacerdote, que dá a
Eucaristia aos outros também a recebe. E ainda, o bispo, que pode receber para si os sufrágios da Igreja,
que dispensa aos outros, cujo efeito imediato é a remissão das penas pelas indulgências, e não um
efeito de jurisdição.

RESPOSTA À SEGUNDA. — Deduz-se do que foi dito.

RESPOSTA À TERCEIRA. — A excomunhão é proferida como uma sentença, que ninguém pode
pronunciar contra si mesmo, porque em juízo ninguém pode ser ao mesmo tempo juiz e réu. Ao passo
que a indulgência não é dada a modo de sentença, mas como uma certa dispensa, que uma pessoa pode
se dar a si mesma.