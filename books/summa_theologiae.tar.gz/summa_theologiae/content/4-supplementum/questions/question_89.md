# Questão 89: Dos que devem julgar e, dos que devem ser julgados no juízo universal.
Em seguida devemos tratar dos que devem julgar e dos que devem ser julgados no juízo universal.
E nesta questão discutem-se oito artigos:

## Art. 1 — Se há homens que julgarão com Cristo.
O primeiro discute-se assim. ─ Parece que ninguém julgará com Cristo.

1. ─ Pois, o Evangelho diz: O pai deu ao Filho todo o juízo, a fim de que etc. Ora, uma tal honorificência
não é devida senão a Cristo. Logo, etc.

2. Demais. ─ Quem julga tem autoridade sobre o julgado. Ora, os méritos e os deméritos, objeto do juízo
final, só a autoridade divina o pode apreciar. Logo, ninguém poderá julgar em tal matéria.

3. Demais. ─ O juízo final não se processará oralmente, mas mentalmente, como é mais provável pensar.
Ora, o serem os méritos e os deméritos conhecidos de todos, que é como acusar e glorificar; e a
retribuição da pena ou do prêmio, que é como o proferir a sentença, tudo isso só por divino poder se
fará. Logo, só Cristo, que é Deus, será o julgador.
Mas, em contrário, o Evangelho: Vós estareis sentados sobre doze tronos e julgareis as doze tribos de
Israel.

2. Demais. ─ A Escritura diz: O Senhor entrará em juízo com os anciãos do seu povo. Logo, parece que
também outros julgarão com Cristo.

SOLUÇÃO. - A palavra julgar é susceptível de muitos sentidos.
Assim, em sentido causal dizemos que julga a causa pela qual alguém deve ser julgado. E, nesta acepção,
dizemos que alguém julga, por comparação, enquanto certos devem ser julgados por comparação com
outros. Tal o lugar do Evangelho: Os habitantes de Nínive se levantarão no dia de juízo com esta geração
e a condenarão. E assim, julgar, no juízo final, tanto o poderão os bons como os maus.
Noutro sentido, empregamos a palavra julgar interpretativamente. Pois, por interpretação, julgamos
que faz uma cousa quem consente com aquele que a faz. Dai o dizermos que quem aprova a sentença
de Cristo, consentindo nela, julga com Cristo. E nesta acepção, todos os eleitos julgarão; e por isso diz a
Escritura ─ Os justos julgarão as nações.
Em terceiro sentido, empregamos o vocábulo julgar por semelhança; assim, dizemos que julga quem,
sentando-se num lugar elevado, como o juiz, com ele se assemelha; e nesta acepção, dizemos que os
assessores julgam. Deste modo também dizem uns, que os varões perfeitos, a quem o Evangelho
promete o poder judiciário, julgarão, por ocuparem um lugar honroso; porque aparecerão superiores
aos outros no juízo acorrendo ao encontro de Cristo no ar.
Nada disto basta porém para a execução da promessa do Senhor, quando disse: Vós estareis sentados e
julgareis; pois, o juízo é mais que o assentar-se um em lugar eminente.
Há, pois, um quarto modo de julgar, apropriado aos varões perfeitos, que julgarão por trazerem
gravados em si os decretos da justiça divina, pelos quais os homens serão julgados; tal como se
disséssemos que julga o livro onde esta contida a lei. Donde a expressão da Escritura: O juiz estará
sentado e os livros estão abertos. E é neste sentido que Ricardo Vitorino explica a judicatura de que se
trata. São suas palavras: Os que se entregam à contemplação divina, os que todos os dias lêem no livro
da sabedoria, transcrevem nas páginas do seu coração tudo o que de, verdade perceberam na agudeza
da sua inteligência. E mais adiante: Que são os corações desses homens, a quem Deus ensinou todas as
verdades, senão uns como decretos canônicos?
Mas como julgar implica um ato que tem um terceiro por objeto, por isso, propriamente falando,
dizemos que julga quem profere uma sentença contra outrem. O que de dois modos pode ser. ─
Primeiro, por autoridade própria, quando se trata de quem tem domínio e poder sobre os outros e de
quem estes, que são os julgados, dependem, sendo por isso que pode exercer a justiça sobre eles. E
neste sentido julgar só a Deus pertence. ─ De outro modo julgar é levar ao conhecimento dos outros,
publicando-a, a sentença proferida por autoridade de outrem. E neste sentido os varões perfeitos
julgarão, porque darão aos demais o conhecimento da divina justiça, para saberem o que justamente
pelos seus méritos lhes é devido; e então juízo se chama a própria manifestação da justiça. Donde o
dizer Ricardo Vitorino: O abrirem os juízes os livros dos seus decretos aos que devem julgar é permitir
aos seus inferiores, quaisquer que sejam, ler-lhes no íntimo do coração e revelar-lhes o seu pensamento
no concernente ao juízo que devem proferir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A objeção procede; quanto ao juízo por autoridade
própria, que só a Cristo compete. E o mesmo se deve responder à segunda.

RESPOSTA À TERCEIRA. ─ Não há inconveniente em uns santos fazerem certas revelações a outras ─ ou
a modo de iluminação, como os anjos superiores iluminam os inferiores; ou a modo de locução, como os
inferiores falam aos superiores.

## Art. 2 — Se o poder judiciário compete à pobreza voluntária.
O segundo discute-se assim. ─ Parece que o poder judiciário não compete à pobreza voluntária.

1. ─ Pois, julgar só foi prometido aos doze Apóstolos, conforme aquilo do Evangelho: Vós estar eis
sentados sobre doze tronos e julgareis, etc. Ora, todos os Apóstolos não eram voluntariamente pobres.
Logo, parece que nem a todos compete o poder judiciário.

2. Demais. ─ É maior sacrifício oferecermos a Deus o nosso próprio corpo do que cousas exteriores. Ora,
os mártires e também as virgens oferecem o próprio corpo em sacrifício a Deus; ao passo que os
voluntariamente pobres só oferecem os bens exteriores, em sacrifício. Logo, a sublimidade do poder
judiciário mais compete aos mártires e às virgens que aos pobres voluntários.

3. Demais. ─ Diz o Evangelho: O mesmo Moisés, em quem vós tendes as esperanças é o que vos acusa.
Ao que diz a Glosa: porque não lhe credes na palavra. E continua o evangelista: A palavra que eu vos
tenho falado essa o julgará no dia último. Logo, o fato mesmo de alguém propor a lei ou exortar com
palavras à correção dos costumes, dá-lhe o direito de julgar os que o desprezarem. Ora, essa é função
dos doutores. Logo, mais compete aos doutores julgar que aos que voluntariamente abraçaram a
pobreza.

4. Demais. ─ Cristo, por ter sido julgado injustamente como homem, mereceu ser o juiz de toda a
humanidade, conforme o diz o Evangelho: E lhe deu o poder de exercitar o juízo porque é Filho do
homem. Ora, os que sofrem perseguição por amor da justiça são julgados injustamente. Logo, mais que
aos pobres, lhes compete o poder judiciário.

5. Demais. ─ O superior não pode ser julgado pelo inferior. Ora, muitos que usaram licitamente das suas
riquezas serão superiores no mérito a muitos que abraçaram a pobreza voluntária. Logo, não serão os
pobres voluntários que os hão de julgar a eles.
Mas, em contrário. ─ Diz a Escritura: Não salva aos ímpios e faz justiça aos pobres. Logo, pertence aos
pobres julgar.

2. Demais. ─ Aquilo do Evangelho ─ Vós que abandonastes tudo, etc. ─ diz a Glosa: Os que abandonaram
tudo e seguiram a Deus, esses serão os juízes; os que usaram retamente dos bens que licitamente
possuíram, serão esses os julgados. Donde a mesma conclusão anterior.

SOLUÇÃO. ─ Por três razões especiais à pobreza voluntária pertence o poder judiciário. ─ Primeiro, por
uma razão de conveniência. Pois, a pobreza voluntária é a daqueles que, desprezados todos os bens do
mundo, se consagraram totalmente a Cristo. Nada tiveram assim na mente, que lhes pudesse desviar da
justiça o pensamento. Tornavam-se por isso idôneos para julgar, como amantes da justiça acima de
tudo. ─ Segundo, pelo seu mérito. Pois, à humildade corresponde a exaltação fundada no mérito. Ora,
nada torna o homem mais desprezível neste mundo que a pobreza. Por isso, o Evangelho promete aos
pobres a excelência do poder judiciário, quando diz que quem se humilhar por Cristo será exaltado. ─
Terceiro, porque a pobreza predispõe ao referido modo de julgar. Pois, quando dizemos que cada um
dos santos julgará, isso significa, como explicamos, que terá gravado no coração o tesouro das verdades
divinas, que poderá manifestar aos outros. Ora, no progresso para a perfeição, a primeira cousa que
devemos abandonar são as riquezas exteriores, que são as que adquirimos em último lugar; e o que vem
em último lugar na geração virá em primeiro na destruição. Por isso, entre as bem-aventuranças, meios
pelos quais progredimos na perfeição, ocupa o primeiro lugar a pobreza. E assim à pobreza compete o
poder judiciário, enquanto é ela a disposição primeira para a perfeição referida. Razão por que não é a
quaisquer pobres; mesmo voluntários, prometido o poder judiciário, mas só aos que, tendo abandonado
tudo, seguiram a Cristo, num estado de vida perfeita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Diz Agostinho: Não é pelo Evangelho prometer, que os
doze Apóstolos estarão sentados sobre doze tronos, que serão só doze homens os que exercerão com
Cristo o poder judiciário. Do contrário, como o Evangelho também refere que em lugar de Judas, traidor,
foi escolhido o Apóstolo Matias, Paulo, que trabalhou mais que os outros Apóstolos, nenhum assento
teria entre os juízes. Por onde, o número doze significa toda a multidão dos que devem julgar, porque é
esse número o resultado da multiplicação das duas partes do número sete ─ três e quatro. Ora, o
número doze é um número perfeito por consistir na soma de seis mais seis, e seis é um número
perfeito. ─ Ou porque, literalmente, Cristo falava aos doze Apóstolos e nas pessoas deles prometia o
poder judiciário a todos os que no futuro os imitassem.

RESPOSTA À SEGUNDA. ─ A virgindade e o martírio não dispõem o coração a conservar os decretos da
justiça divina, como a pobreza; assim como, ao contrário, as riquezas materiais, pela solicitude que
causam, abafam a palavra de Deus, na expressão do Evangelho. ─ Ou devemos responder que a
pobreza, não só basta para merecer o exercício do poder judiciário, mas é a primeira parte da perfeição
a que o poder judiciário compete. Por isso entre as consequências da pobreza, que visam a perfeição,
podemos contar a virgindade, o martírio, e todas as obras perfeitas. Mas nada disso é tão principal
como a pobreza, porque o princípio de uma cousa é a sua parte mais importante.

RESPOSTA À TERCEIRA. ─ Quem propôs a lei ou exortou ao bem julgará, causalmente falando, porque
os outros serão julgados conforme as palavras que ele pronunciou ou propôs. Por isso, em sentido
próprio, o poder judiciário não incumbe à pregação nem à doutrina. ─ Ou devemos responder, segundo
outros, que o poder judiciário requer três condições: a primeira, o despreendimento dos cuidados
temporais, a fim de não ficar a alma impedida de receber a sabedoria; a segunda, o hábito que
realmente contenha o conhecimento e a observância da justiça; a terceira, o ensino dessa justiça aos
outros. E assim, a doutrina será a perfeição que completa o mérito para exercer o poder judiciário.

RESPOSTA À QUARTA. ─ Cristo, deixando condenar-se injustamente, humilhou-se a si próprio: Foi
oferecido, diz a Escritura, porque ele mesmo quis. E o mérito da sua humildade lhe mereceu as honras
do poder judiciário, em virtude do qual tudo lhe foi submetido, como diz o Apóstolo. Por onde, o poder
judiciário é devido de preferência aos que voluntariamente se humilharam, desprezando os bens
temporais, por causa dos quais o mundo nos honra, do que aos que foram humilhados pelos outros.

RESPOSTA À QUINTA. ─ O inferior não pode, por autoridade própria, julgar o superior; mas o pode, em
virtude de uma autoridade superior, como no caso da delegação de juízos. Por isso, não há
inconveniente em ser concedido como prêmio acidental aos pobres, julgarem os outros, mesmo os de
mérito mais excelente em relação ao prêmio essencial.

## Art. 3 — Se os anjos devem julgar.
O terceiro discute-se assim. ─ Parece que os anjos devem julgar.

1. ─ Pois, diz o Evangelho: Quando vier o Filho do homem na sua majestade e todos os anjos com ele.
Ora, refere da vinda para o juízo. Logo, parece que também os anjos julgarão.

2. Demais. ─ As ordens dos anjos recebem a sua denominação do ofício que exercem. Ora, uma ordem
de anjos é a dos Tronos, a que incumbe o poder judiciário; pois trono é o assento real, o sólio do rei, a
cátedra de doutor. Logo, certos anjos julgarão.

3. Demais. - Aos santos depois desta vida é prometida a igualdade com os anjos. Se, portanto, os
homens terão o poder de julgar, com maior razão os anjos.
Mas, em contrário. ─ O Evangelho diz: E lhe deu o poder de exercitar o juízo, porque é Filho do homem.
Ora, os anjos não participam da natureza humana. Logo, nem do poder judiciário.

2. Demais. ─ Não pode julgar o ministro do juiz. Ora, no juízo final, os anjos serão como uns ministros,
conforme aquilo do Evangelho: Enviará o Filho do homem os seus anjos e tirarão do seu reino todos os
escândalos. Logo, os anjos não julgarão.

SOLUÇÃO. ─ Os assessores do juiz devem-lhe ser conformes. Ora, o juízo é atribuído ao Filho, que se
manifestará, na sua natureza humana, tanto aos bons como aos maus; embora toda a Trindade julgue
por autoridade própria. Por onde, é também necessário que os assessores do juiz tenham a natureza
humana, na qual possam ser vistos de todos, bons e maus. E assim aos anjos não compete julgar. ─
Embora possam, de certo modo, julgar, pela aprovação da sentença.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Como se vê pela Glosa ao lugar citado, os anjos virão com
Cristo, não como juízes, mas, como testemunhas dos atos humanos, pois, foi sob a guarda deles que os
homens procederam bem ou mal.

RESPOSTA À SEGUNDA. ─ O nome de Trono é atribuído aos anjos em razão de aquele juízo que Deus
sempre exerce, governando todas as cousas com suma justiça; de cujo juízo os anjos são de certo modo
executores e promulga dores. Mas, no juízo com que Cristo homem julgará os homens, terá homens
como assessores.

RESPOSTA À TERCEIRA. ─ Aos homens é prometida a igualdade com os anjos, quanto ao prêmio
essencial. Mas nada impede receberem os homens um prêmio acidental, que os anjos não terão. Tal a
auréola das virgens e dos mártires. E o mesmo podemos dizer do poder judiciário.

## Art. 4 — Se depois do dia do juízo os demônios executarão contra os condenados a sentença do juiz.
O quarto discute-se assim. ─ Parece que depois do dia de juízo os demônios não executarão contra os
condenados a sentença do juiz.

1. ─ Pois, segundo o Apóstolo, Cristo destruirá todo principado, poder e virtude. Logo, cessará toda
superioridade (Glosa). Ora, executar a sentença do juiz implica uma certa superioridade. Logo, os
demônios, depois do dia do juízo, não executarão a sentença do juiz.

2. Demais. ─ Assim como os demônios sugerem aos homens o mal, assim os anjos bons, o bem. Ora,
premiar os bons não será ofício dos bons anjos, mas Deus diretamente o fará. Logo, também não será
ofício dos demônios punir os maus.
Mas, em contrário, os pecadores, pecando, sujeitaram-se ao diabo. Logo, é justo que também lhe
fiquem sujeito quanto às penas, como se fossem punidos por ele.

SOLUÇÃO. ─ O Mestre refere duas opiniões, nesta matéria, de acordo ambas com as exigências da
justiça de Deus. Pois, pecando, o homem fica, com justiça, sujeito ao demônio, embora o domínio do
demônio sobre o pecador seja injusto. Por onde, a opinião que não concede presidam os demônios no
futuro, depois do dia de juízo, às penas dos homens, leva em conta a ordem da divina justiça, no
concernente às penas de que os demônios fossem os executores. E a opinião contrária considera a
ordem da divina justiça em relação aos homens punidos. Mas qual dessas duas opiniões seja a mais
verdadeira, não podemos ter certeza. Penso contudo que mais verdadeiro é pensar o seguinte. Assim
como os que se salvaram observarão a ordem de serem uns iluminados, e aperfeiçoados pelos outros,
porque todas as ordens da hierarquia celeste serão perpétuas, assim também, na aplicação das penas,
se observará a ordem de serem os homens punidos pelos demônios, a fim de não ficar totalmente
anulada a disposição divina, pela qual os anjos foram constituídos como termo médio entre a natureza
humana e a divina. Por onde, assim como as iluminações divinas são deferidas aos homens pelos anjos
bons, assim também os demônios serão os executores da justiça divina sobre os maus. Nem isso lhes
diminui em nada as penas, porque o mesmo torturar os outros, lhes servirá de tortura; pois, no inferno,
a sociedade dos miseráveis, longe de diminuir a miséria, a aumentará.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essa superioridade da qual o Apóstolo diz, que Cristo fará
desaparecer no século futuro, deve ser considerada como sendo da mesma natureza das deste mundo.
De acordo com a qual homens governam homens os anjos, aos homens; Os anjos, aos anjos; os
demônios, aos demônios; e os demônios, aos homens. E isto tudo para conseguirem o fim ou dele se
desviarem. Mas então, quando todos os seres tiverem atingido ao seu fim, nenhuma superioridade mais
haverá que a ele conduza ou dele desvie; só haverá então a que conservará bons e maus nos seus fins.

RESPOSTA À SEGUNDA. ─ Embora os demônios não mereçam ser postos acima dos homens, pelos ter
sujeitado a si injustamente, contudo assim o exige a relação da natureza, deles com a humana. Pois, os
bens naturais eles os conservam íntegros, como diz Dionísio.

RESPOSTA À TERCEIRA. ─ Os anjos bons não são a causa principal de os eleitos serem premiados,
porque os seus prêmios estes os recebem diretamente de Deus. Mas de certos prêmios acidentais dos
homens podem os anjos ser a causa, enquanto os anjos superiores iluminam os inferiores e os homens
sobre certos arcanos divinos, não pertencentes à substância da beatitude. Semelhantemente, a sua
pena capital os condenados a receberão diretamente de Deus, i. é, a exclusão perpétua da visão
beatífica; mas quanto a outras penas, as sensíveis, não há inconveniente em serem infligidas aos
homens pelos demônios. ─ Há porém a seguinte diferença: ao passo que o mérito exulta, o pecado
deprime. Por onde, sendo a natureza angélica mais elevada que a humana, certos homens de mérito
excelente, serão exaltados a ponto de essa exaltação exceder à capacidade da natureza e do prêmio de
certos anjos. Donde o serem estes anjos iluminados por tais homens. Mas nenhuns pecadores terão
nunca um grau de malícia tal, que cheguem à eminência própria da natureza demoníaca.

## Art. 5 — Se todos os homens comparecerão ao juízo.
O quinto discute-se assim. ─ Parece que nem todos os homens comparecerão ao juízo.

1. ─ Pois, diz o Evangelho: Vós estareis sentados sobre doze tronos e julgareis as doze tribos de Israel.
Ora, nem todos os homens pertencem a essas doze tribos. Logo, parece que nem todos comparecerão
ao juízo.

2. Demais. ─ O mesmo se conclui do lugar seguinte da Escritura: Os ímpios não ressurgirão no juízo. Ora,
muitos são ímpios, Logo, parece que nem todos comparecerão ao juízo.

3. Demais. ─ Os homens serão trazidos a juízo para lhes serem avaliados os méritos. Ora, certos, como
as crianças mortas antes da idade de razão, nenhum mérito tiveram. Logo, não é necessário
comparecerem a juízo.
Mas, em contrário, a Escritura: Cristo foi constituído por Deus juiz de vivos e mortos. Ora, nessas duas
classes estão compreendidos todos os homens, seja como for que os vivos se distinguam dos mortos.
Logo, todos comparecerão a juízo.

2. Demais. ─ A Escritura diz: Ei-lo, aí vem sobre as nuvens e todo olho o verá. Ora, isto não seria, se nem
todos comparecessem ao juízo. Logo, etc.

SOLUÇÃO. ─ O poder judiciário foi delegado a Cristo homem como prêmio da humilhação que sofreu na
sua paixão. Ora, na paixão derramou o seu sangue por todos os homens, o suficiente para se salvarem,
embora não produza o seu efeito em todos, por causa do obstáculo que certos lhe opõem. É, pois,
conveniente que todos os homens se reúnam no juízo para presenciarem a exaltação de Cristo na sua
natureza humana, enquanto constituído por Deus juiz dos vivos e dos mortos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Diz Agostinho: Não é pelo fato de Cristo dizer ─ Julgareis
as doze tribos. de Israel ─ que a tribo de Leví, que era a décima terceira, não será julgada; ou que os
Apóstolos só julgarão o povo judaico e não as outras nações. E assim, nas doze tribos estão
compreendidas todas as mais nações, pois todas estas Cristo as chamou a si juntamente com as tribos
de Israel.

RESPOSTA À SEGUNDA. ─ O lugar citado ─ Os ímpios não ressurgirão no juízo ─ se o referirmos a todos
os pecadores, significa então que não ressurgirão para julgarem. Mas se por ímpios se entendem os
infiéis, então o texto significa que não ressurgirão para serem julgados, porque já estão julgados. Mas
todos ressurgirão para comparecerem ao juízo e contemplarem a glória do juiz.

RESPOSTA À TERCEIRA. ─ Também as crianças: mortas antes da idade de razão comparecerão ao juízo,
não para serem julgadas, mas para presenciarem a glória do juiz.

## Art. 6 — Se os bons serão julgados no juízo.
O sexto discute-se assim. ─ Parece que os bons não serão julgados no juízo.

1. ─ Pois, diz o Evangelho: Quem nele crê não é julgado. Ora, todos os bons creram em em Cristo. Logo,
não serão julgados.

2. Demais. ─ Felizes não são os incertos da sua felicidade; donde conclui Agostinho, que os demônios
nunca foram felizes. Ora, os varões santos são felizes já neste mundo. Logo, estão certos da sua
felicidade. Ora, o que é certo não pode constituir objeto de juízo. Logo, os bons não serão julgados.

3. Demais. ─ O temor repugna à felicidade. Ora, o juízo final, o mais tremendo de todos, não pode deixar
de causar temor aos que devem ser julgados. Por isso, àquilo da Escritura ─ Quando se elevar temerão
os anjos, etc. ─ diz Gregório: Consideremos como se abalará então a consciência dos maus, quando
mesmo os justos terão a vida cheia de horror. Logo, os santos não serão julgados.
Mas, em contrário. ─ Parece que todos os bons serão julgados. Pois, diz o Apóstolo: Importa que todos
nós compareçamos diante do tribunal de Cristo, para que cada um receba o galardão segundo o que
tem feito, ou bom ou mau, estando no próprio corpo. Ora, ser julgado não é senão isso. Logo, todos,
mesmo os bons, serão julgados.

2. Demais. ─ O universal abrange tudo. Ora, esse juízo será chamado universal. Logo, todos nele serão
julgados.

SOLUÇÃO. ─ Duas cousas compreende o juízo: a avaliação dos méritos e a retribuição dos prêmios. Ora,
quanto à retribuição dos prêmios, todos serão julgados, mesmo os bons; pois, cada um receberá, por
sentença divina, o prêmio correspondente ao mérito. Mas, a avaliação dos méritos não terá lugar senão
quando houver mescla de bens com males. Ora, os que elevam sobre o fundamento da fé edifício
d'ouro, de prata, de pedras preciosas, totalmente entregues ao serviço divino e que não mesclaram com
as suas boas ações nenhum mal grave, para esses não haverá lugar a avaliação dos méritos; tal, p. ex., o
que se dará com aqueles que, desprezadas completamente as cousas do mundo, só cuidam solícitos nas
cousas de Deus. Por isso hão de salvar-se, mas não serão julgados. Mas aqueles que levantam sobre o
fundamento da fé edifício de madeira, de feno e de palha, i. é, os que amem ainda as cousas do mundo,
e vivem enredados em negócios seculares, mas de modo que nada anteponham a Cristo e se esforçam
por redimir os seus pecados com esmolas, esses mesclam com o mal os méritos das suas boas obras, por
isso esses méritos devem ser ponderados. Por isso esses tais embora sejam assim julgados, contudo se
salvarão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Sendo a punição um efeito da justiça e o prêmio, da
misericórdia, por isso antonomásticamente a punição é, de preferência, considerada objeto do juízo; de
modo que às vezes o juízo é tomado no sentido de condenação. Tal o sentido da autoridade citada,
como o corrobora a Glosa a esse lugar.

RESPOSTA À SEGUNDA. ─ A avaliação dos méritos dos eleitos a serem julgados não tem por fim privar-
lhes o coração da certeza da felicidade, mas para mostrar a todos manifestamente a preeminência do
bem sobre o mal e proclamar assim a justiça de Deus.

RESPOSTA À TERCEIRA. ─ Gregório se refere aos justos que ainda vivem esta vida mortal. Por isso tinha
dito antes: Os que, na ocasião do juízo, viverem ainda neste mundo, embora já fortes e perfeitas,
contudo, apesar de ainda viverem esta vida, não poderão deixar de ser sacudidas pelo pavor no meio
desse turbilhão de tantos terrores. Por onde é claro que esse terror se refere ao tempo imediatamente
precedente ao juízo, por certo soberanamente tremendo para os maus, mas não para os bons, nos quais
não haverá nenhuma suspeita de mal.
Quanto às objeções em contrário, fundam-se no juízo quanto à retribuição dos prêmios.

## Art. 7 — Se os maus serão julgados.
O sétimo discute-se assim. ─ Parece que nenhum mau será julgado.

1. ─ Pois, assim como é certa a condenação dos infiéis, assim a dos mortos em pecado mortal. Ora, é por
causa da certeza da condenação que o Evangelho diz: Quem nele não crê já está condenado. Logo, pela
mesma razão os mais pecadores também não serão julgados.

2. Demais. ─ A voz do juiz há de ser muito terrível de ouvir aos condenados no juízo final. Mas, como diz
Gregório, citado pelo Mestre, o juiz não dirigirá a palavra aos infiéis. Logo, se a dirigisse aos fiéis a serem
condenados, os infiéis tirariam vantagem da sua infidelidade. O que é absurdo.
Mas, em contrário. ─ Parece que todos os maus devem ser julgados. Porque a todos lhes é infligida a
pena segundo a gravidade da culpa. Ora, isso não é possível sem primeiro o juízo o determinar. Logo,
todos os maus serão julgados.

SOLUÇÃO. ─ O juízo como retribuição da pena ao pecado, todos os maus devem a ele comparecer; mas
só os fiéis, se se trata do juízo como ponderação dos méritos. Porque os infiéis não tem o fundamento
da fé, sem o qual todas as obras que praticarem carecem da perfeita retidão de intenção. Não há por
isso nessas obras nenhuma mescla de bem ou de mérito e de mal, o que é necessário para poder haver
avaliação. Mas os fiéis, que conservam o fundamento da fé, tem pelo menos o mérito do ato de fé, que
embora não seja meritório sem a caridade, contudo, por natureza pode ser causa de merecer. Por isso
as obras dos fiéis serão susceptíveis de ponderação, no juízo. Por onde, os fiéis que pelo menos foram
do número dos cidadãos da Cidade de Deus, como cidadãos serão julgados, e não poderão sofrer uma
sentença de morte sem os seus méritos serem apreciados. Ao passo que os infiéis serão condenados
como inimigos, que os homens costumam exterminar sem lhes entrar na apreciação dos méritos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora não haja dúvida sobre a condenação dos que
morreram em pecado mortal, contudo como na vida praticaram talvez certas ações meritórias, é
necessário, para a manifestação da justiça divina, fazer-lhes a avaliação dos méritos por onde fique claro
que foram justamente excluídos da Cidade dos santos, a cujo número apenas aparentemente
pertenciam.

RESPOSTA À SEGUNDA. ─ Espiritualmente entendida, a palavra dirigida pelo Soberano Juiz aos fiéis, que
deve condenar, não lhes será áspera de ouvir, porque lhes manifestará uns restos de complacência, que
não poderá haver para com os infiéis, pois; sem fé é impossível agradar a Deus. Mas a sentença de
condenação pronunciada contra uns e outros será para todos eles terrível.
Quanto às objeções em contrário se fundam no juízo de retribuição.

## Art. 8 — Se os anjos serão julgados no juízo final.
O oitavo discute-se assim. - Parece que os anjos serão julgados no juízo final.

1. ─ Pois, pergunta o Apóstolo: Não sabeis que havemos de julgar aos anjos? Ora, isto não pode referir-
se às condições da vida presente. Logo, deve referir-se ao juízo final.

2. Demais. ─ A Escritura diz de Behemoth, que significa o diabo: Será precipitado à vista de todos. E o
demônio perguntou a Cristo, como o refere o Evangelho: Viestes a perder-nos antes do tempo.
Comentário da Glosa: Os demônios, vendo o Senhor no mundo, pensavam que iam ser julgados
imediatamente. Logo, parece que estão reservados para o juízo final.

3. Demais. ─ A Escritura diz: Se Deus não perdoou aos anjos que pecaram, mas tirados pelos calabres do
inferno, os precipitou no abismo, para serem atormentados e tidos como de reserva até o juízo. Logo,
parece que os anjos serão julgados.
Mas, em contrário. ─ Deus não julgará duas vezes a mesma causa, diz a Escritura. Ora, os maus anjos já
estão julgados, donde o dizer o Evangelho: O príncipe deste mundo já está julgado. Logo, Os anjos não
serão julgados no juízo final.

2. Demais. ─ Os anjos superam, em bondade e em malícia, a maior parte dos homens neste mundo. Ora,
certos homens, bons e maus, não serão julgados. Logo, também não serão julgados os anjos bons ou
maus.

SOLUÇÃO. ─ O juízo para avaliar os méritos não se exercerá sobre bons anjos nem sobre os maus;
porque nem os bons terão nenhum mal, nem os maus nenhum bem a ser discernido pelo juízo. Mas, se
nos referimos ao juízo de retribuição, então devemos distinguir duas espécies de retribuição. ─ Uma
correspondente aos méritos próprios dos anjos. E essa a receberam desde o princípio tanto os bons
como os maus anjos, quando foram aqueles sublimados à felicidade e estes imersos na miséria. ─ Outra
retribuição é a correspondente aos méritos ou deméritos adquiridos com a cooperação dos anjos. E essa
se fará no juízo futuro, porque os bons anjos mais se regozijarão com a salvação daqueles para cujos
méritos contribuíram, assim como mais serão torturados os maus com a condenação de maior número
de maus, que eles incitaram ao mal, ─ Por onde, diretamente falando, não haverá juízo para os anjos,
nem para o pronunciarem nem para lhe responderem, senão só para os homens. Mas, indiretamente, o
juízo de certo modo lhes dirá respeito, na medida em que forem comparsas dos atos humanos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essas palavras do Apóstolo se referem ao juízo
comparativo; porque certos homens aparecerão, no juízo final, superiores a certos anjos.

RESPOSTA À SEGUNDA. ─ Os próprios demônios serão precipitados à vista de todos, porque serão
atirados ao cárcere perpétuo do inferno, donde não terão mais a liberdade de sair. Pois o saírem dele
não lhes fora concedido senão na medida em que a providência divina o ordenara para provar a vida dos
homens.
E a mesma resposta devemos dar à terceira objeção.
