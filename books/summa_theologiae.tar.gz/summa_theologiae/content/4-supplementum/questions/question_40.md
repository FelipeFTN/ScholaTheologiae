# Questão 40: Dos anexos ao sacramento da ordem.
Em seguida devemos tratar dos anexos ao sacramento da ordem.
E sobre esta questão discutem-se sete artigos:

## Art. 1 — Se os ordenados devem fazer a rasura da coroa.
O primeiro discute-se assim. ─ Parece que os ordenados não devem fazer a rasura da coroa.

1. ─ Pois, o Senhor ameaça de cativeiro e de dispersão os que assim se tonsuram, como lemos na
Escritura: Os inimigos que estão no cativeiro com a cabeça raspada. E noutro lugar: Espalharei a todo o
vento os que cortam os cabelos em redondo. Ora, os ministros devem viver em liberdade e não em
cativeiro. Logo, a rasura e a tonsura da coroa não nas devem eles praticar.

2. Demais. ─ Deve a verdade responder ao figurado. Ora, a coroa já tinha sido figurada antes, no regime
da Lei Velha, pela tonsura dos Nazarenos, como diz o Mestre. Mas, como os Nazarenos não eram
destinados ao ministério divino, parece que não devem os ministros da Igreja fazer o tonsura ou a
rasura da coroa. E isso também se deduz do fato de os irmãos conversos das religiões serem tonsurados,
apesar de não serem ministros da Igreja.

3. Demais. ─ Os cabelos significam o supérfluo, porque são gerados de matérias supérfluas. Ora, os
ministros do altar devem excluir de si toda superfluidade. Logo, devem rapar totalmente a cabeça e não
a modo de coroa.
Mas, em contrário, segundo Gregório, servir a Deus é reinar. Ora, a coroa é sinal de reinado. Logo, os
destinados ao ministério divino devem ter coroa.

2. Demais. ─ Os cabelos foram dados em lugar de véu, como o diz o Apóstolo. Ora, os ministros do altar
devem ter o coração descoberto. Logo, devem fazer a rasura da coroa.

SOLUÇÃO. ─ Os destinados aos ministérios divinos devem fazer a rasura e a tonsura, a modo de coroa,
por causa do simbolismo desta. Pois, a coroa sendo circular, é sinal de reinado e de perfeição. Ora, os
destinados aos ministérios divinos recebem uma dignidade regia e devem ser de virtude perfeita. ─
Convém-lhes ainda por isso cortarem os cabelos. A rasura, na parte superior da cabeça advertindo-os
que a alma não se lhes apegue aos negócios temporais em detrimento da contemplação das coisas
divinas. A tonsura, na parte superior, em sinal de que o coração se não lhes deixa enredar pelos bens
sensíveis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O Senhor ameaça aos que o faziam para prestar culto aos
demônios.

RESPOSTA À SEGUNDA. ─ As práticas do Testamento Velho representam imperfeitamente as do Novo.
Por isso, o concernente aos ministros do Novo Testamento era significado, não somente pelos ofícios
dos levitas, mas também por todos aqueles que faziam uma profissão. Ora, os Nazarenos professavam
uma certa perfeição, pelo corte dos cabelos, exprimindo assim o seu desprezo pelos bens temporais.
Embora os cortassem de todo e não só a modo de coroa; porque ainda não era chegado o tempo do
sacerdócio real e perfeito. ─ Por isso também, pela renúncia dos bens temporais, é que os conversos
recebem a tonsura. Mas não a rasura, por não exercerem os ministérios divinos, que os deve elevar a
mente à contemplação das coisas divinas.

RESPOSTA À TERCEIRA. ─ A forma da coroa deve significar não só o desprezo dos bens temporais mas
também a dignidade real. Por isso, os cabelos não devem ser totalmente cortados. ─ E também para não
dar lugar ao ridículo.

## Art. 2 — Se a coroa é uma ordem.
O segundo discute-se assim. ─ Parece que a coroa é uma ordem.

1. - Pois, nos atos da Igreja, o espiritual deve corresponder ao corporal. Ora, a coroa é um sinal material
que a Igreja usa. Logo, parece que lhe há de corresponder uma significação espiritual. Portanto o fato de
se receber a coroa imprime caráter e é ela uma ordem.

2. Demais. ─ Assim como a confirmação e as outras ordens são conferidas só pelo bispo, assim também
a coroa. Ora, a confirmação e as outras ordens imprimem caráter. Logo, também a coroa. Donde, a
mesma conclusão que antes.

3. Demais. ─ A ordem implica um certo grau de dignidade. Ora, um clérigo, só pelo fato de o ser, é
constituído num grau superior ao povo. Logo, a coroa, que o torna clérigo, é uma ordem.
Mas, em contrário. ─ Nenhuma ordem é dada senão com a celebração da missa. Ora, a coroa pode ser
conferida mesmo sem missa. Logo, não é uma ordem.

2. Demais. ─ Na cotação de qualquer ordem, faz-se menção do poder conferido. Ora, tal não se faz na
cotação da coroa. Logo, não é ordem.

SOLUÇÃO. - Os ministros da Igreja são separados do povo para poderem nascer ao culto divino. Ora, no
culto divino há certas funções cujo exercício supõe poderes determinados; e para isso é conferido o
poder espiritual da ordem. Outras funções há porém exercidas em comum por todo o colégio dos
ministros, como cantar os louvores divinos. E para essas não é necessário em nada o poder da ordem,
mas só uma certa destinação a esse ofício. E isso se dá pela coroa, a qual, pois, não é uma ordem, mas
um preâmbulo para ela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A coroa corresponde, em si mesma, algo de espiritual,
como ao sinal corresponde a causa significada. Mas isso não é nenhum poder espiritual. Por isso a coroa
não imprime nenhum caráter, nem é ordem.

RESPOSTA À SEGUNDA. ─ Embora a coroa não imprima caráter, contudo destina quem a recebe ao
culto divino. Eis porque essa destinação deve fazer-se pelo mais elevado dos ministros, que é o bispo, o
qual também abençoa as vestes, os vasos e tudo o mais destinado ao culto divino.

RESPOSTA À TERCEIRA. ─ O clérigo, só pelo ser, já se acha num estado mais elevado que o leigo; mas
não tem por isso o grau mais elevado de poder, que a ordem requer.

## Art. 3 — Se quem recebe a coroa renuncia aos bens, temporais.
O terceiro discute-se assim. ─ Parece que quem recebe a coroa renuncia os bens temporais.

1. ─ Pois, os que recebem a coroa dizem então: O Senhor é parte da minha herança. Ora, como diz
Jerônimo, o Senhor dedigna ser parte da nossa herança, junto com os bens temporais. Logo, os que
recebem a coroa renunciam aos bens temporais.

2. Demais. ─ A justiça dos ministros do Novo Testamento deve abundar mais que a dos ministros do
Velho, como lemos no Evangelho. Ora, os ministros do Testamento Velho, como os levitas, não
receberam parte da herança, como os seus irmãos. Logo, nem a devem ter os ministros do Novo
Testamento.

3. Demais. ─ Hugo Vitorino diz, desde que alguém foi feito clérigo, deve sustentar-se com os estipêndios
da igreja. Ora, isto não se daria se conservasse o seu patrimônio. Logo, parece que fazendo-se clérigo,
renuncia a ele.
Mas, em contrário, Jeremias pertenceu à ordem sacerdotal. Ora, entrou de posse da sua herança, como
claramente o diz. Logo, os clérigos podem ter bens patrimoniais.

2. Demais. ─ Se não o pudessem, não haveria então diferença entre clérigos seculares e regulares.

SOLUÇÃO. ─ Os clérigos pelo fato de terem recebido a coroa, não renunciam ao seu patrimônio nem a
nenhum bem temporal. Porque a posse dos bens terrenos não contraria ao culto divino, a que os
clérigos são destinados; mas o que lhe contraria é só a demasiada solicitude posta neles, porque, como
diz Gregório, dar-lhes o ajecto seria criminoso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O Senhor dedigna fazer parte; de modo que viesse a ser
amado tanto quanto os bens temporais, de maneira que viéssemos a pôr o novo fim tanto nele como
nos bens do mundo. Mas não dedigna ser parte daqueles, que de modo possuem as coisas do mundo,
que por elas não se afastam do culto divino.

RESPOSTA À SEGUNDA. ─ Os levitas, no Testamento Velho, tinham direito à herança paterna. Mas não
receberam partes iguais às das outras tribos, porque deviam dispersar-se por todas elas; e isso não
poderia dar-se se, como as outras, tivessem recebido uma determinada parte de terra.

RESPOSTA À TERCEIRA. ─ Se os clérigos promovidos às ordens sagradas fossem indigentes, o bispo que
os promove fica obrigado a olhar por eles; do contrário, a isso não estaria obrigado. Quanto a eles, estão
obrigados, por força d

## Art. 4 — Se deve haver um poder episcopal, superior à ordem sacerdotal.
O quarto discute-se assim. ─ Parece que não deve haver nenhum poder episcopal, superior à ordem
sacerdotal.

1. ─ Pois, como diz a letra do Mestre, a ordem sacerdotal começou com Arão. Logo, na Lei Nova não
deve haver nenhum poder superior ao sacerdotal.

2. Demais. ─ Um poder se ordena à prática de determinados atos. Ora, nenhum ato sagrado pode ser
mais nobre que o de consagrar o corpo de Cristo, que compete ao sacerdote. Logo, o poder episcopal
não deve ser superior ao sacerdotal.

3. Demais. ─ O sacerdote quando oferece o sacrifício faz a figura de Cristo na Igreja, que se ofereceu ao
Padre por nós. Ora, na Igreja ninguém é maior que Cristo, porque ele é a cabeça da Igreja. Logo, não
deve haver nenhum poder superior ao sacerdotal.
Mas, em contrário. ─ Um poder é tanto mais elevado quanto maior raio de ação tem. Ora, o poder
sacerdotal, como diz Dionísio, só tem por objeto purificar e iluminar; ao passo que o episcopal, além
desses, tem também o de aperfeiçoar. Logo, o poder episcopal deve ser o superior ao sacerdotal.

2. Demais. ─ Os ministérios divinos devem ser melhor ordenados que os humanos. Ora, a ordem dos
ofícios humanos requer que cada ofício tenha o seu preposto, que é nele o principal; assim, o chefe dos
soldados é o general. Logo, devem os sacerdotes ter um preposto, que lhe seja o chefe; e este é o bispo.
Portanto, o poder episcopal deve ser superior ao sacerdotal.

SOLUÇÃO. ─ O sacerdote exerce duas espécies de atos: um principal, que é consagrar o corpo de Cristo;
outro secundário, que é preparar o povo de Deus para a recepção desse sacramento, como dissemos.
Quanto ao primeiro, o poder sacerdotal não depende de nenhum outro poder superior, a não ser o de
Deus. Mas quanto ao segundo, depende de um poder humano superior. Pois, todo poder, que não pode
exercer-se senão pressuposta uma certa ordem, depende do poder causador dessa ordem. Ora, o
sacerdote não pode absolver nem ligar independente da jurisdição episcopal, que lhe torna sujeitos os
que absolve. Mas pode consagrar qualquer matéria determinada por Cristo; nem requer mais nada o
sacramento para existir, embora uma certa conveniência pressuponha o ato episcopal de consagrar o
altar, os paramentos e coisas semelhantes. Por onde, é clara a necessidade de um poder episcopal
superior ao sacerdotal, quanto ao ato secundário do sacerdote; mas não quanto ao primeiro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Arão era sacerdote e pontífice, isto é, chefe dos
sacerdotes. Por isso o poder sacerdotal começou com ele, enquanto como sacerdote oferecia os
sacrifícios, o que também os sacerdotes menores podiam fazer. Mas não enquanto pontífice, pois como
tal tinha o poder privativo de praticar certos atos, como entrar no Santo dos Santos uma vez por ano, o
que os outros sacerdotes não podiam fazer.

RESPOSTA À SEGUNDA. ─ Para a prática desse ato o sacerdote não depende de nenhum poder superior;
mas só para o exercício da segunda função, que referimos.

RESPOSTA À TERCEIRA. ─ Assim como as perfeições de todas as causas naturais preexistem
exemplarmente em Deus, assim Cristo foi o exemplar de todos os ofícios eclesiásticos. Por onde, cada
ministro da Igreja de certo modo representa a pessoa de Cristo, como diz a letra do Mestre; e contudo
aquele é superior, que representa Cristo mais plenamente. Ora, o sacerdote representa a Cristo
enquanto por si mesmo exercer um determinado ministério; o bispo, de seu lado, o representa
enquanto instituidor dos outros ministros e fundador da Igreja. Por isso ao bispo pertence atribuir certas
causas ao ofício divino, estabelecendo por assim dizer o culto divino à semelhança de Cristo. E também
por isso, é chamado como Cristo, esposo da Igreja.

## Art. 5 — Se o episcopado é uma ordem.
O quinto discute-se assim. ─ Parece que o episcopado é uma ordem.

1. ─ Primeiro, porque Dionísio distingue as três ordens seguintes da hierarquia eclesiástica: a do bispo,
do sacerdote e do ministro. E a letra do Mestre também diz que a ordem episcopal é quadripartita.

2. Demais. ─ A ordem não é senão um certo grau de poder de dispensar os bens espirituais. Ora. os
bispos podem dispensar certos sacramentos, que os sacerdotes não podem, como o da confirmação e o
da ordem. Logo, o episcopado é uma ordem.

3. Demais. ─ Na Igreja não há nenhum poder espiritual além do da ordem e da jurisdição. Ora, as
funções do poder episcopal não são jurisdicionais, do contrário poderiam ser cometidas a um não bispo,
o que é falso. Logo, são funções da ordem. Portanto. o bispo tem uma ordem que o simples sacerdote
não tem. Por onde o episcopado é uma ordem.
Mas, em contrário, uma ordem não depende da precedente, para o sacramento valer. Ora, o poder
episcopal depende do sacerdotal, porque ninguém pode receber aquele sem ter primeiro recebido este.
Logo, o episcopado não é uma ordem.

2. Demais. ─ As ordens maiores não se conferem a não ser aos sábados. Mas o poder episcopal se
transfere aos domingos, como estabelece uma Decretal. Logo, não é uma ordem.

SOLUÇÃO. ─ A ordem é susceptível de dupla acepção. ─ Primeiro, como sacramento. E então, como
dissemos, toda ordem se destina ao sacramento da Eucaristia. Por onde, não tendo, por si, o bispo um
poder superior ao do sacerdote, ordem não será o episcopado. ─ A outra luz, a ordem pode ser
considerada, enquanto um ofício ao qual incumbem certas funções sacras. E assim, lendo o bispo Um
poder hierárquico, superior ao do sacerdote, sobre o corpo místico de Cristo. O episcopado será uma
ordem. Ora, é este o sentido das autoridades aduzidas. Donde se deduz a resposta à primeira objeção.

RESPOSTA À SEGUNDA. ─ A ordem enquanto sacramento, que imprime caráter, se destina
especialmente ao sacramento da Eucaristia, que contém ao próprio Cristo; pois, pelo caráter nos
configuramos com Cristo mesmo. Portanto, embora ao bispo, quando é promovido ao episcopado, seja
dado um certo poder espiritual em relação aos outros sacramentos, esse poder entretanto não chega a
imprimir caráter. Por onde, o episcopado não é uma ordem, tomando-se a ordem como um dos
sacramentos.

RESPOSTA À TERCEIRA. ─ O poder episcopal não é somente jurisdicional; mas também um poder de
ordem, tomada esta no sentido geral.

## Art. 6 — Se pode haver na Igreja um superior aos bispos.
O sexto discute-se assim. ─ Parece que acima eles bispos nenhum superior pode haver na Igreja.

1. ─ Pois, todos os bispos são sucessores dos Apóstolos. Ora, o poder dado a Pedro, um dos Apóstolos, a
todos o foi. Logo, todos os bispos são iguais e um não é superior ao outro.

2. Demais. ─ O rito da Igreja deve ser conforme antes, ao dos judeus que ao dos gentios. Ora, a distinção
da dignidade episcopal e a ordenação de um superior a outro, como diz o Mestre. foi introduzida pelos
gentios, pois não existia na Lei Antiga. Logo, também na Igreja não deve um bispo ser superior a outro.

3. Demais. ─ Um poder superior não pode ser conferido pelo inferior, nem um igual pelo igual, porque
sem nenhuma contradição o que é inferior recebe a bênção do que é superior. Por isso um sacerdote
não pode sagrar um bispo nem outro sacerdote, mas o bispo é quem ordena o sacerdote. Ora, o bispo
pode promover ao episcopado; assim, o bispo ostiense é o que consagra o Papa. Logo, a dignidade
episcopal de todos os bispos é a mesma. Portanto, não deve um bispo ser inferior a outro, como diz a
letra do Mestre.
Mas, em contrário, lemos ao concílio Constantinopolitano: Veneramos, segundo as Escrituras e segundo
as definições canônicas, o santíssimo Bispo da Velha Roma como o primeiro e o máximo dos bispos; e
depois dele o bispo mesmo de Constantinopla. Logo, pode um bispo ser superior a outro.

2. Demais. ─ S. Cirilo, bispo Alexandrino, diz: A fim de permanecermos unidos ao nosso chefe apostólico,
que ocupa o trono dos Pontífices Romanos, de quem nos compete receber o que devemos crer e
professar, nós o veneramos e a ele rogamos, de preferência a todos os mais. Porque só ele pode
repreender, corrigir, determinar, dispor, desatar e ligar, em lugar do fundador da Igreja, que a nenhum
outro, senão só a ele, deu a plenitude do poder; a quem todos, por direito divino, inclinam a cabeça e os
mais elevados chefes do mundo lhe obedeçam como ao próprio Senhor Jesus Cristo. Logo, os bispos
dependem por direito divino, de um superior.

SOLUÇÃO. ─ Em toda parte onde muitos governantes dependem de um só, há de necessariamente
haver um regime universal superior aos regimes particulares. Porque em todas as virtudes e em todos
os atos, como diz Aristóteles, a ordem depende da ordenação dos fins. Ora, o bem comum é mais divino
que o bem particular. Por onde, além do poder governamental, que visa o bem particular, deve haver
um poder universal, que visa o bem comum; do contrário não poderia haver redução à unidade. Por
isso, sendo toda a Igreja um só corpo, é necessário, para conservar essa unidade, haver um poder
governativo da Igreja universal, superior ao poder episcopal a que obedece cada igreja especial. E esse é
o poder do Papa. Por isso, os que rejeitam esse poder chamam-se cismáticos, quase mutiladores da
unidade da Igreja. Mas entre o simples bispo e o Papa há outros graus de dignidade, correspondentes
aos graus de união, em virtude do que uma congregação ou comunidade inclui outra. Assim como a
comunidade da província inclui a da cidade; a do reino inclui a de cada província; e a de todo o mundo, a
de cada reino.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora a todos os Apóstolos tenha sido dado em geral o
poder de ligar e de absolver, contudo, para haver ordem na distribuição de poderes, primeiro foi dado
só a Pedro, para mostrar que dele devia derivar para os mais. Por isso o Senhor lhe disse em particular:
Conforta a teus irmãos. E ainda: Apascenta as minhas ovelhas. Isto é, em meu lugar, como diz
Crisóstomo, sê o chefe e a cabeça de teus irmãos, para que estes, considerando-te como o meu
representante, te anunciem e confirmem a ti, em todo o mundo universo, que estás sentado no teu
trono.

RESPOSTA À SEGUNDA. ─ O rito dos Judeus não estava espalhado pelos diversos reinos e províncias,
mas era praticado por um só povo. Por isso não era necessário que quem detinha o poder principal
tivesse sob si outros pontífices. Ao contrário, o rito da Igreja, como o dos gentios, está divulgado pelas
várias nações. Ora, sendo assim, há de a Igreja, pela sua constituição, conformar-se, antes, com o rito
dos gentios que com o dos judeus.

RESPOSTA À TERCEIRA. ─ O poder do sacerdote é excedido pelo do bispo, como por um poder de
gênero diferente. Mas o do bispo é excedido pelo do Papa, como por um poder do mesmo gênero. Por
isso, todo poder hierárquico que pode exercer o Papa, na ministração dos sacramentos, pode também
exercer o bispo; mas nem todos os atos que pode praticar o bispo o pode também o sacerdote, na
colação dos sacramentos. Por isso, todos os bispos são iguais na ordem episcopal. Razão por que
qualquer bispo pode consagrar a outro.

## Art. 7 — Se as vestes dos ministros a Igreja as instituiu acertadamente.
O sétimo discute-se assim. ─ Parece que as vestes dos ministros a Igreja não as instituiu
acertadamente.

1. ─ Pois, os ministros do Novo Testamento estão mais adstritos à castidade que os do Velho. Ora, entre
as vestes dos ministros do Testamento Velho havia também calções para cobrir as partes verendas, em
sinal de castidade. Logo e com maior razão, devem eles estar entre as vestes dos ministros da Igreja.

2. Demais. ─ O sacerdócio do Novo Testamento é mais digno que o do Antigo. Ora, os antigos sacerdotes
tinham mitras, símbolo da dignidade. Logo, também nas devem ter os da Lei Nova.

3. Demais. ─ O sacerdote está mais próximo da ordem dos ministros que a ordem episcopal. Ora, os
bispos usam da dalmática, que é veste dos diáconos e da túnica, veste do subdiácono. Logo e com muito
maior razão, devem usar delas os simples sacerdotes.

4. Demais. ─ Na Lei antiga, o pontífice trazia o efod, símbolo do peso do Evangelho, como diz Beda. Ora,
esta veste é própria sobretudo dos nossos pontífices. Logo, devem trazer o efod.

5. Demais. ─ No racional, de que usavam os pontífices da Lei Velha estava escrito: Doutrina e Verdade.
Ora, a verdade sobretudo se revelou na Lei Nova. Logo, devem trazê-lo os pontífices da Lei Nova.

6. Demais. ─ A lâmina de ouro, onde estava escrito o digníssimo nome de Deus, era o mais nobre dos
ornatos da Lei Velha. Logo, devia, mais que os outros, passar para a Lei Nova.

7. Demais. ─ As práticas externas dos ministros da Igreja, são sinais das internas. Ora, o arcebispo não
tem um gênero de poder diferente do episcopal, como se disse. Logo, não deve ter o pálio, que não têm
os bispos.

8. Demais. ─ A plenitude do poder reside no Romano Pontífice. Ora, ele não traz o báculo. Logo, também
os outros bispos não no devem trazer.

SOLUÇÃO. ─ As vestes dos ministros designam a idoneidade que devem ter para tratar as coisas divinas.
E como certos requisitos todos devem ter e outros, só os superiores e não os inferiores, por isso certas
vestes são comuns a todos os ministros, e outras, só aos superiores.
Por isso, todos os ministros devem vestir o amicto, que lhes cobre os ombros e significa a fortaleza com
que devem exercer os ofícios divinos a que foram consagrados. Também a alva, símbolo da pureza de
vida; e o cíngulo, que significa a repressão da carne. O subdiácono deve além disso, usar o manipulo,
símbolo da sua absoluta pureza, porque o manipulo e, por assim dizer, um lenço para enxugar o rosto;
pois a sua ordem é uma como introdução ao ministério sagrado. Usa também uma túnica estreita,
símbolo da doutrina de Cristo; por isso dela pendiam, na Lei Antiga, campainhas. Pois, os subdiáconos
tem como dever primacial anunciar a doutrina da Lei Nova.
Além disso, porém o diácono usa a estola no ombro esquerdo, em sinal de que o seu ministério se
exerce sobre os sacramentos, diretamente. E a dalmática, veste larga, assim chamada por ter sido
primeiro usada nas terras da Dalmácia para significar que o diácono tem como função ser dispensador
dos sacramentos, pois, distribui o sangue de Cristo, e quem dispensa deve fazê-lo com largueza.
Quanto ao sacerdote, em cada ombro se lhe coloca a estola, para mostrar que lhe é conferido o pleno
poder de dispensar os sacramentos e não como ministro de outrem; por isso a estola lhe desce até em
baixo. Também usa a casula, símbolo da caridade, porque consagra a Eucaristia, sacramento do amor.
Ao bispo se lhe acrescentam nove ornamentos além dos do sacerdote, que são: As meias, as sandálias, o
cinto, a túnica, a dalmática, a mitra, as luvas, o anel e o báculo. Porque tem nove poderes além dos do
sacerdote: ordenar os clérigos, abençoar as virgens, consagrar os pontífices, impor as mãos, dedicar as
basílicas, depor os clérigos, celebrar sínodos, consagrar o crisma e consagrar vestes e vasos. ─ Ou as
meias, significam a retidão dos passos. As sandálias, que cobrem os pés, o desprezo dos bens terrenos.
O cinto, que liga a estola com a alva, o amor da decência. A túnica, a perseverança; porque a Escritura
refere que José tinha uma túnica talar, que lhe descia até aos calcanhares, símbolos do extremo da vida.
A dalmática significa a generosidade nas obras de misericórdia. As luvas, a cautela no agir. A mitra, a
ciência de ambos os Testamentos, sendo por isso que tem duas pontas. O báculo, o zelo pastoral, que o
levará a reunir os errantes, simbolizado pela curvatura no topo do báculo; a sustentar os fracos, como a
própria haste do báculo o exprime; mas espertar os lentos, simbolizado pela ponta, na extremidade do
báculo. Daí o verso:
Reúne, sustenta, estimula os errantes, os doentes, os lentos.
Quanto ao anel, significa os sacramentos da fé, pelos quais a Igreja é desposada; pois, os bispos são os
esposos da Igreja, em lugar de Cristo. Além disso, os arcebispos usam o pálio, em sinal do seu poder
privilegiado; pois significa o colar de ouro outorgado aos que combateram com bravura.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Aos sacerdotes da Lei Velha era imposta a continência só
no tempo em que desempenhavam o seu ministério. Por isso como sinal da castidade, que deviam
então observar, usavam, na oblação de sacrifício de calções para lhes cobrir as partes verendas. Ora, os
ministros do Novo Testamento estão obrigados a continência perpétua. Por isso o símile não colhe.

RESPOSTA À SEGUNDA. ─ A mitra não era sinal de nenhuma dignidade; pois era um como chapéu, no
dizer de Jerônimo. Quanto à tiara, era um sinal de dignidade e só permitido aos pontífices, assim como
agora a mitra.

RESPOSTA À TERCEIRA. - O poder dos ministros tem no dos bispos a sua origem; mas não no do
sacerdote, pois não é ele quem lhes confere as ordens. Por isso, antes o bispo, que o sacerdote, é quem
usa das vestes dos ministros.

RESPOSTA À QUARTA. ─ Em lugar do efod usam da estola, cujo significado é o mesmo que era o do
efod.

RESPOSTA À QUINTA. ─ O pálio veio tomar o lugar do racional.

RESPOSTA À SEXTA. ─ Em lugar dessa lâmina o nosso pontífice traz a cruz, como diz Inocêncio III. Assim
como em lugar do calção, as sandálias; em lugar da túnica de linho, a alva; pelo cinto, o cíngulo; pelo
talar, a túnica, pelo efod, o amicto; pelo racional, o pálio e a mitra, pela tiara.

RESPOSTA À SÉTIMA. - Embora não tenha um poder de outro gênero, tem contudo o arcebispo um
poder mais amplo. E por isso, afim de designar essa perfeição reveste-se do pálio, que o envolve todo.

RESPOSTA À OITAVA. ─ O Pontífice Romano não usa do báculo, porque Pedro emprestou um dia o seu
para despertar um dos seus discípulos que depois se tornou bispo trevirense. Por isso, na diocese
trevirense, mas não em outros lugares, o Papa traz o báculo. ─ Ou ainda como sinal de que não tem um
poder limitado, o que é significado pela curvatura do báculo.
O Sacramento do matrimônio