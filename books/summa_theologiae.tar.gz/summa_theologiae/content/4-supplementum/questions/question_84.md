# Questão 84: Da agilidade dos corpos bem-aventurados ressurrectos.
Em seguida devemos tratar da agilidade dos corpos bem-aventurados ressurrectos.
E nesta questão discutem-se três artigos:

## Art. 1 — Se os corpos gloriosos serão ágeis.
O primeiro discute-se assim. ─ Parece que os corpos gloriosos não serão ágeis.

1. ─ Pois, o que pode mover-se por si mesmo não precisa de ser movido por outro. Ora, os corpos
glorificados serão arrebatados, pelos anjos, depois da ressurreição, nas nuvens a receber a Cristo nos
ares, como diz uma glosa. Logo, os corpos gloriosos não serão ágeis.

2. Demais. ─ Não se pode chamar ágil um corpo que se mova trabalhosa e penosamente. Ora, assim se
moverão os corpos gloriosos, pois, a alma, motor deles, os move contrariamente à natureza deles; do
contrário seriam movidos sempre na mesma direção. Logo, não serão ágeis.

3. Demais. ─ Dentre todas as operações animais, a sensibilidade é mais nobre e mais própria que o
movimento. Ora, não se atribui aos corpos gloriosos nenhuma propriedade que lhes de a perfeição de
sentir. Logo, também não lhes deve ser atribuída a agilidade que lhes dá a perfeição de por si mesmos
se moverem.

4. Demais. ─ A natureza dá aos diversos animais disposições orgânicas diferentes conforme às diversas
virtudes deles; assim, não dá as mesmas disposições orgânicas ao animal tardo e ao veloz. Ora, Deus age
muito mais ordenadamente que a natureza. Logo, como os corpos gloriosos tem os membros dispostos
com a mesma figura e as mesmas dimensões que tinham nesta vida, parece que não serão de outro
modo ágeis que agora o são.
Mas, em contrário, o Apóstolo: Semeia-se em vileza, ressuscitará em glória; i. é, móvel e vivo, diz a
Glosa. Ora, a mobilidade outra cousa não é senão a agilidade no movimento. Logo, os corpos gloriosos
serão ágeis.

2. Demais. ─ Nada repugna mais a um ente espiritual que o ser tardo. Ora, os corpos gloriosos serão
espirituais por excelência, como diz o Apóstolo. Logo, serão ágeis.

SOLUÇÃO. ─ O corpo glorioso estará perfeitamente sujeito à alma glorificada. Não só por não resistir em
nada à vontade do espírito, porque assim já era o corpo de Adão, mas também porque lhe deflui da
alma glorificada uma perfeição, que o torna hábil para essa sujeição, perfeição chamada dote do corpo
glorificado. Ora, alma está unida ao corpo, não só como forma, mas também como o seu princípio
motor. E de ambos os modos o corpo glorioso há de ser sumamente sujeito à alma glorificada. Por onde,
assim como pelo dote da subtileza lhe está totalmente sujeito, enquanto lhe dá ela o ser específico
como sua forma que é, assim pelo dote da agilidade lhe está sujeito como ao principio motor. De modo
que estará pronto e hábil a obedecer a todos os movimentos e ações da alma. ─ Certos porém dão como
causa dessa agilidade a quinta essência, predominante depois da ressurreição nos corpos gloriosos. Mas
já dissemos mais de uma vez que isto não é admissível. É preferível atribuir a causa da agilidade à alma,
donde emana a glória do corpo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O dizer o Apóstolo que os corpos gloriosos serão levados
pelos anjos e também nas nuvens, não significam que lhes seja isso necessário. Mas é apenas para
designar a reverência com que os anjos e todas as criaturas tratarão os corpos gloriosos.

RESPOSTA À SEGUNDA. ─ Quanto mais a virtude motriz da alma domina sobre o corpo, tanto menos
laborioso é o movimento, mesmo contrário à natureza do corpo. Por onde, aqueles corpos cujo princípio
motor é mais forte e que, pelo exercício, são mais aptos a obedecer ao movimento do espírito, esses se
movem menos laboriosamente. E como depois da ressurreição alma será perfeitamente governada pelo
corpo, quer pela perfeição da sua virtude própria, quer pela aptidão do corpo glorioso a obedecer, em
virtude da redundância nele da glória da alma, de nenhum modo será laborioso o movimento dos
santos. E assim, podemos dizer que os seus corpos são ágeis.

RESPOSTA À TERCEIRA. ─ Pelo dote da agilidade o corpo glorioso torna-se capaz, não só do movimento
local, mas também de sentir e de exercer todas as demais atividades da alma.

RESPOSTA À QUARTA. ─ Assim como a natureza da aos animais velozes disposições orgânicas diversas
da dos outros animais, quanto à forma e o número dos membros, assim Deus dará aos corpos dos
santos disposição diferente da que neste mundo tiveram, não quanto à forma e ao número dos
membros, mas pela propriedade da glória chamada agilidade.

## Art. 2 — Se os santos não empregarão nunca a sua agilidade para moverem-se.
O segundo discute-se assim. ─ Parece que os santos não empregarão nunca a sua agilidade para
moverem-se.

1. ─ Pois, segundo o Filósofo, o movimento é o ato de um ser imperfeito. Ora, nos corpos gloriosos não
haverá nenhuma imperfeição. Logo, nem movimento nenhum.

2. Demais. ─ Todo movimento supõe uma indigência porque todo o ser que se move é em busca de
algum fim. Ora, os corpos gloriosos não sofrerão nenhuma indigência; pois, como diz Agostinho, no céu
terás tudo quanto quiseres e nada do que não quiseres. Logo, não se moverão.

3. Demais. ─ Segundo o Filósofo, o ser participante da divina bondade sem mover-se, dela participa mais
nobremente do que outro que dela participa movendo-se. Ora, um corpo glorioso participa mais
nobremente da divindade que qualquer outro corpo, Logo, como certos outros corpos permanecerão
sem nenhum movimento, tais os corpos celestes, parece que com maior razão os corpos humanos.

4. Demais. ─ Agostinho diz, que a alma fundada em Deus nele fundará também o corpo, por
consequência. Ora, a alma estará de tal modo fundada em Deus, que de maneira nenhuma dele será
movida. Logo, também não causará nenhum movimento no corpo.

5. Demais. ─ Quanto mais nobre for o corpo, tanto mais nobre será o lugar que merece. Por onde, o
corpo de Cristo, que é nobilíssimo, terá o lugar mais eminente de todos, segundo aquilo do Apóstolo: Foi
feito mais elevado que os céus ─ em lugar e dignidade, diz a Glosa. E semelhantemente, cada corpo
glorioso terá, pela mesma razão, um lugar conveniente à medida da sua dignidade. Ora, o lugar
conveniente é dos que pertencem à glória. Logo, como depois da ressurreição a glória dos santos não
variará para mais nem para menos, por estarem no fim absolutamente último, parece que os corpos
deles nunca se arredarão do seu lugar determinado. E portanto não se moverão.
Mas, em contrário, a Escritura: Correrão e não se fatigarão, voarão e não desfalecerão. E noutro lugar:
Como faíscas por um canavial discorrerão. Logo, de certo modo se moverão os corpos gloriosos.

SOLUÇÃO. ─ Devemos admitir que os corpos gloriosos podem mover-se; pois, o próprio corpo de Cristo
moveu-se na ascenção e também os corpos dos santos, que hão de ressurgir da terra, subirão ao céu
empíreo. Mas mesmo depois de subidos ao céu, é verossímil que poderão mover-se quando quiserem,
para, exercendo um poder que tem, proclamarem a sabedoria divina. E também para repastar a vista na
beleza das várias criaturas em que eminentemente resplandece a sapiência de Deus. Porque os sentidos
não podem exercer-se senão na presença de um sensível, embora os corpos gloriosos possam ver de
mais longe que os não gloriosos. Nem por se moverem perderão nada da sua felicidade, consistente na
visão de Deus, que terão presente em toda parte; assim, dos anjos diz Gregório, que sejam enviados
para onde for não perdem nunca a presença de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O movimento local não altera em nada o que é intrínseco
à natureza intrínseca do móvel, mas só a sua posição, que lhe é extrínseca. Por onde, o ser movido pelo
movimento local fica perfeito na sua constituição intrínseca, como diz Aristóteles. E o movimento local
revela a sua imperfeição pelo lugar que ocupa, pois, enquanto está num é potencial em relação a outro,
porque não pode, como só é possível a Deus, estar em vários lugares ao mesmo tempo. Mas essa
imperfeição não repugna à perfeição da glória, como não lhe repugna a imperfeição da criatura, saída
do nada. Por onde, tais imperfeições existirão nos corpos gloriosos.

RESPOSTA À SEGUNDA. ─ De dois modos podemos dizer que um ser precisa de outro: absoluta e
relativamente falando. Absolutamente falando um ser precisa daquilo sem o que não pode conservar a
sua existência ou a sua perfeição. E assim não é por nenhuma indigência que os corpos gloriosos se
moverão, pois plenamente lhes satisfaz a sua felicidade. Mas relativamente um ser precisa daquilo sem
o que não pode alcançar completamente ou de tal modo o fim visado. E então será por indigência que
se moverão os corpos gloriosos; pois, não poderão de fato manifestar a sua virtude motiva, senão
movendo-se. Mas nenhum inconveniente há em os corpos gloriosos terem essa indigência.

RESPOSTA À TERCEIRA. ─ A objeção colheria se o corpo glorioso não pudesse, mesmo sem mover-se,
participar da bondade divina muito mais perfeitamente que os corpos celestes ─ o que é falso. Por onde,
os corpos gloriosos não se movem para poderem participar perfeitamente da bondade divina, da qual
participam pela glória, mas para manifestarem uma virtude da alma. Pelo movimento dos corpos
celestes porém não poderia manifestar-se senão a virtude que tem de mover os corpos inferiores para a
geração ou para a corrupção; o que não cabe ao corpo no estado da glória. Logo, a objeção não
procede.

RESPOSTA À QUARTA. ─ O movimento local nenhum detrimento causa à imobilidade da alma unida
com Deus, pois não atinge a constituição intrínseca do móvel, como dissemos.

RESPOSTA À QUINTA. ─ É por um prêmio acidental que a cada corpo glorioso é atribuído um lugar
segundo o grau da sua dignidade. Mas o estar ele fora desse lugar não lhe diminui em nada o prêmio
pois, esse lugar não constitui prêmio, por envolver atualmente o corpo que o ocupa, porque em nada
influi no corpo glorioso, mas ao contrário, participa-lhe do esplendor; mas enquanto, lhe é devido pelo
seu mérito. Por isso, o gáudio resultante do lugar subsiste mesmo ao corpo glorioso que esteja fora
dele.

## Art. 3 — Se os santos se movem instantaneamente.
O terceiro discute-se assim. ─ Parece que os santos se movem instantaneamente.

1. ─ Pois, diz Agostinho, que o corpo estará onde bem o quiser o espírito. Ora, o movimento da vontade,
pelo qual o espírito vai para onde quer, é instantâneo. Logo, também instantâneo será o movimento do
corpo.

2. Demais. - Como o prova o Filósofo, nenhum movimento é possível no vácuo, porque nele o móvel se
moveria instantaneamente, desde que o vácuo não lhe opõe nenhuma resistência. Mas o espaço cheio
opõe resistência. E assim nenhuma proporção haveria entre a velocidade do movimento no vácuo e no
espaço cheio, pois a proporção entre as velocidades dos movimentos se funda na proporção da
resistência do meio. Ora, dois movimentos, que se desenvolvem no tempo, hão de ter velocidades
proporcionais, porque um tempo é proporcional a outro. Semelhantemente, nenhum espaço cheio pode
opor resistência a um corpo glorioso, que pode simultaneamente com outro ocupar o mesmo lugar, de
qualquer modo que seja; assim como o vácuo não pode opor resistência ao outro corpo. Logo, se um
santo se move, há de mover-se instantaneamente.

3. Demais. ─ O poder da alma glorificada excede como que sem proporção o da alma não glorificada.
Ora, a alma não glorificada pode mover um corpo no tempo. Logo, a alma glorificada pode movê-lo num
instante.

4. Demais. ─ Tudo o que percorre com a mesma velocidade um espaço pequeno ou grande se move
instantaneamente. Ora, tal é o movimento do corpo glorioso; pois, percorre num tempo imperceptível
um espaço qualquer. Donde o dizer Agostinho, que o corpo glorioso, como o raio do sol, vence espaços
desiguais com a mesma celeridade. Logo, o corpo glorioso se move num instante.

5. Demais. ─ Tudo o que se move ou é no tempo ou no instante. Ora, o corpo glorioso, depois da
ressurreição, não se moverá no tempo porque então não haverá mais tempo, como diz a Escritura. Logo,
há de mover-se no instante.
Mas, em contrário. ─ No movimento local o espaço, o movimento e o tempo se medem pela mesma
divisão, como Aristóteles o demonstra. Ora, o espaço atravessado pelo corpo glorioso em movimento é
divisível. Logo, tanto o seu movimento como o tempo que emprega são divisíveis. Ora, o instante é
indivisível. Portanto, o movimento do corpo glorioso não se dá no instante.

2. Demais. ─ Um corpo não pode estar totalmente num lugar e parcialmente em outro. Porque então,
uma das suas partes estaria simultaneamente em dois lugares, o que não pode ser. Ora, todo móvel está
parte na origem e parte no termo do movimento, como o demonstra o Filósofo. Ora, tudo o que foi
movido está totalmente no termo final do movimento. Logo, não pode simultaneamente estar em
movimento e já ter-se movido. Ora, todo ser que se move num instante ao mesmo tempo que se move
já se moveu. Logo, o movimento local do corpo glorioso não pode ser instantâneo.

SOLUÇÃO. ─ Nesta matéria são muitas as opiniões.
Assim certos pretendem que um corpo glorioso pode passar de um lugar para outro sem passar pelas
posições intermediárias, assim como a vontade de um lugar se transfere para outro sem passar por
essas posições. Por isso, como o da vontade, pode o movimento de um corpo glorioso ser instantâneo. ─
Mas esta opinião é insustentável. Porque um corpo glorioso não deixa nunca de ser corpo. Além disso,
quando dizemos que a vontade se move de um lugar para outro, não significa isso que se transfira
essencialmente de um para outro lugar, pois nenhum desses lugares a contém na sua essência. Mas,
dirige-se para um lugar depois de se ter em intenção dirigido para outro, sendo nesse sentido que
dizemos que se move de um para outro lugar.
Por isso ensinam outros que o corpo glorioso é naturalmente próprio, como corpo, atravessar as
posições intermediárias e, assim, de mover-se no tempo. Mas em virtude da glória, cuja virtude é de
certo modo infinita em relação à da natureza, tem a faculdade de não precisar atravessar essas posições
e de mover-se, assim, num instante. ─ Mas isto é inadmissível, porque implica em si contradição, como a
seguir se verá. Seja o móvel Z, que se move de A para B. Quando está todo em A é claro que ainda não
se move. Nem quando está todo em B, porque então já se moveu. Logo, se se move, não estará
totalmente em A nem em B. Portanto, quando se move: ou não está em nenhum lugar; ou está parte
em A e parte em B; ou todo num lugar intermediário; p. ex., C; ou parte em A e C; ou parte em C e B.
Mas não é possível que não esteja em nenhum lugar, porque então teríamos o impossível de uma
quantidade dimensiva não ocupar nenhum lugar. Nem se pode admitir que esteja parte em A e parte
em B, sem ocupar nenhuma posição intermediária. Porque, sendo A um lugar distante de B, resultaria,
desde que há um meio interjacente, que a parte de Z que estivesse em B não seria contínua com a que
estivesse em A. Logo, só resta, ou que está Z totalmente C; Ou parte em C e parte noutra posição média
entre C e A, p. ex., D; e assim por diante. Logo e necessariamente, não pode Z partir de A e chegar a B,
sem primeiro ocupar todas as posições intermediárias. Salvo se se disser que parte de A e chega a B sem
se ter movido; o que implica contradição, porque a sucessão mesma das posições é movimento local. E
o mesmo raciocínio se aplica a qualquer mutação entre dois termos contrários, dos quais cada qual é
um termo positivo. Diferentemente se dá, porém, com as mutações que tem só um termo positivo,
sendo o outro uma simples privação. Porque entre uma afirmação e uma negação ou privação, não há
nenhuma distância determinada. Por onde, o que está no termo negativo pode estar mais próximo ou
mais afastado da afirmação, ou inversamente, em razão de uma causa geradora de um desses termos
ou que dispõe para eles. E assim, da posição negativa, onde o móvel totalmente esteja, pode passar
para a afirmativa, e ao inverso. Por onde, também neste caso o móvel primeiro se move para depois
repousar no termo do movimento, como Aristóteles o prova. Nem há aqui nenhuma semelhança com o
movimento angélico; porque só equivocam ente podemos dizer, de um corpo e de um anjo, que
ocupam um lugar. Por onde, é claro que de nenhum modo pode um corpo passar de um lugar para
outro, sem percorrer as posições intermediárias.
Por isso outros, apesar de o concederem, afirmam que o corpo glorioso se move no instante. ─ Mas daí
resulta que um corpo glorioso iria ocupar, num mesmo instante, dois ou mais lugares simultaneamente;
i. é, no termo último do seu movimento e em todas as posições intermediárias. O que não é possível.
Mas sustentam a sua opinião dizendo que, embora o instante seja realmente um mesmo, não o é
contudo no conceito racional, como se dá com o ponto em que terminam linhas diversas. ─ Isto porém
não basta. Porque o instante mede o que nele realmente se passa e não o que é objeto de uma
consideração racional. Por onde, fazer considerações diversas sobre o instante não tornam possível que
ele meça fatos que não se dão simultaneamente no tempo; assim como considerações diversas sobre o
ponto não podem fazer com que um mesmo ponto local contenha cousas que ocupam outras posições
espaciais.
Por isso outros, e com maior probabilidade, dizem que o corpo glorioso se move no tempo, mas num
tempo imperceptível pela sua brevidade. E que contudo um corpo glorioso pode percorrer num tempo
mais breve o mesmo espaço que outro; porque o tempo, por menor que seja, é divisível ao infinito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Ao que falta pouco é quase como se nada lhe faltasse, diz
Aristóteles. Assim dizemos ─ faço já, o que vamos fazer só depois de algum tempo. E é este o sentido de
Agostinho quando escreve: O corpo estará logo onde o quiser a vontade. ─ Ou devemos responder que a
vontade dos bem-aventurados nunca será desordenada. Por isso não quererão nunca ter
instantaneamente o corpo num lugar em que ele não possa assim estar. E assim, qualquer instante que
a vontade determinar, nesse mesmo o corpo estará onde ela o quiser.

RESPOSTA À SEGUNDA. ─ Certos contradisseram à proposição estabelecida pelo Filósofo na obra citada,
como diz o Comentador a esse lugar. E afirmavam que não é necessário haver proporção entre dois
movimentos completos, fundada na proporção dos meios respectivos que hão de atravessar. Mas é
necessário haver proporção entre os meios, que devem atravessar, e o retardamento que lhes resulta
da resistência desses meios. Pois, o retardamento e a aceleração de um movimento durante um tempo
determinado lhes resulta do impulso eficaz do motor sobre o móvel, mesmo sem nenhuma resistência
da parte do meio. E bem o manifestam os corpos celestes a que nenhuma resistência lhes serve de
obstáculo ao movimento; e contudo não se movem no instante, mas num tempo determinado,
proporcionalmente ao impulso do motor sobre o móvel. Por onde é claro que, mesmo admitindo-se que
um móvel se mova no vácuo, não resulta necessariamente que se mova no instante; mas num tempo
determinado proporcionalmente ao poder do motor sobre o móvel. Por onde, é claro que, mesmo
admitindo um móvel movendo-se no vácuo, isso não implica que se mova instantaneamente. Mas que,
nesta hipótese, não devemos nada acrescentar à duração do tempo exigido pelo movimento, em virtude
da referida proporção entre o impulso do motor e a resistência do móvel, porque nenhum
retardamento sofreu o movimento.
Mas esta resposta, como o mostra o comentador, no mesmo lugar, procede de se imaginar falsamente
que o retardamento, causado pela resistência do meio, é um acréscimo feito ao movimento natural,
movimento este cuja quantidade é determinada pela proporção entre o motor e o móvel, do mesmo
modo por que uma linha se acrescenta a outra, resultando assim, em virtude desse acréscimo, que a
linha total não tem mais a mesma proporção das linhas acrescentadas entre si. E assim, também não
haverá a mesma proporção entre o movimento totalidade do movimento sensível resultante dos
retardamentos causados pela resistência do meio. Ora, como dissemos, essa imaginação é falsa. Porque
cada parte do movimento tem a mesma velocidade que o movimento total, mas qualquer parte da linha
não tem a mesma quantidade dimensiva que a linha total. Por onde, o retardamento ou a aceleração
com que um movimento se realiza, lhe redunda para cada uma das partes, o que não se dá com as
linhas. Portanto, o retardamento com que o movimento se efetua nenhum acréscimo lhe constitui, ao
contrário do que se dá com o acréscimo feito à linha, que constitui uma parte dela.
Por isso, a fim de entendermos a prova do Filósofo, como expõe o Comentador, no mesmo lugar,
devemos saber que, no caso vertente, o todo há de ser tomado na sua unidade, i. é, levando em conta a
resistência oposta pelo móvel ao impulso do motor, e a resistência do meio onde se realiza o
movimento, além de qualquer outra resistência, De modo que calculemos a intensidade do
retardamento do movimento total, causado pela resistência oposta pelo móvel ou por um elemento
estranho, proporcionalmente a essa resistência e ao impulso da causa motriz. Pois, há de sempre o
móvel resistir de qualquer modo ao motor, porque motor e movido, agente e paciente são entre si
contrários. ─ Mas pode também o móvel resistir ao motor por si mesmo. Ou por possuir uma virtude
que o inclina para um movimento contrário, como no caso dos movimentos violentos; ou ao menos por
ocupar um lugar contrário ao da intenção do motor, resistência essa que também os corpos celestes
opõem aos seus motores. ─ Mas outras vezes o móvel resiste ao motor, não por si mesmo, senão por
uma causa estranha. Tal o que se dá com o movimento natural dos corpos graves e leves, que em
virtude da sua própria forma se inclinam a um determinado movimento; pois, a forma é uma impressão
do agente gerador, que é também o princípio do movimento dos corpos graves e leves. A matéria
porém não opõe nenhuma resistência, nem a proveniente de uma virtude, que inclinasse a um
movimento contrário; nem a procedente da contrariedade de lugar, porque a matéria não ocupa lugar
senão enquanto recebe da sua forma natural dimensões determinadas. Portanto, a resistência não pode
provir senão do meio; e essa resistência é conatural à natureza mesma do movimento dos corpos de
que tratamos. ─ Outras vezes porém a resistência procede tanto do móvel como do meio, como se dá
com o movimento dos animais.
Quando, pois, a resistência ao impulso motor vem só do móvel, como se dá com os corpos celestes,
então o tempo se mede proporcionalmente ao movimento de um e à resistência do outro. E em tal caso
não procede o raciocínio do Filósofo, porque, removido totalmente o meio, ainda resta que esses corpos
se movem no tempo. ─ Mas nos movimentos em que a resistência só provém do meio, a medida do
tempo se funda só nessa resistência. Portanto, esta desaparece totalmente, desde que totalmente se
elimine o meio. E então ou o corpo se moverá no instante, ou no mesmo tempo se moverá no vácuo
como num espaço cheio. Pois, dado que se movesse no vácuo, empregando um certo tempo, este
tempo seria de certo modo proporcional ao tempo que empregasse em se mover num espaço cheio.
Assim, se imaginássemos, como é possível, um corpo mais subtil, na mesma proporção em que o é o
corpo que enche o meio, e se com esse corpo mais subtil enchermos um espaço igual, o móvel
atravessaria esse meio no mesmo tempo em que atravessasse o vácuo. Porque quanto mais subtil
supusermos o meio tanto mais diminuiremos o tempo empregado em percorrê-la; e quanto subtil ele
for tanto menos resistirá. ─ Mas em relação aos outros movimentos, onde a resistência nasce tanto do
móvel como do meio, o tempo se calcula na proporção entre o agente motor, e à resistência móvel e do
meio simultaneamente. E assim, nem por supor-se de todo removido o meio ou a sua resistência resulta
que o movimento seja instantâneo, mas que o tempo do movimento se mede só pela resistência do
móvel. Nem há inconveniente em mover-se o móvel empregando o mesmo tempo, tanto no vácuo
como num espaço cheio de um corpo que imaginemos subtilissimo. Porque quanto maior for uma
determinada subtileza do meio, tanto mais será de natureza a retardar o movimento. E assim podemos
supor uma tal subtileza do meio de natureza a causar um retardamento menor que o causado pela
resistência do móvel; e então a resistência do meio não tornará de nenhum modo o movimento
retardado.
Por onde, é claro que embora o meio não resista aos corpos gloriosos, por poderem ocupar
simultaneamente com outro o mesmo lugar, contudo o movimento deles não será instantâneo. Porque
o móvel resiste ao impulso do motor só pelo fato de ocupar um lugar, como o dissemos a respeito dos
corpos celestes.

RESPOSTA À TERCEIRA. ─ Embora a virtude da alma glorificada exceda inestimavelmente a da alma não
glorificada, não a excede contudo infinitamente, porque ambas as virtudes são finitas. Donde não se
segue que mova no instante. ─ Mas se, absolutamente falando, fosse de infinita virtude, daí não se
seguiria que movesse num instante, senão superando de todo a resistência do móvel. E embora a
resistência oposta pelo móvel ao motor ─ por causa da contrariedade que lhe opõe ao movimento do
motor, em razão da sua inclinação para um movimento contrário ─ possa ser completamente superado
por um motor de virtude infinita, contudo, a resistência que opõe, pela contrariedade que manifesta a
ocupar o lugar a que o impele o movimento do motor, não pode ser totalmente superada, senão
tirando-se ao móvel a possibilidade de ocupar um determinado lugar ou uma determinada posição. Pois,
assim como o branco opõe resistência ao negro,em razão da sua brancura, e tanto mais quanto mais
oposta For a brancura à negrura, assim um corpo resiste à ação de outro por ocupar um lugar oposto a
este último, e tanto maior será a resistência quanto maior a distância entre eles. E não pode um corpo
ser privado de ocupar um lugar ou posição, sem ser privado da sua corporeidade que o põe num lugar
ou numa posição. Portanto, enquanto conservar a sua natureza corpórea, de nenhum modo poderá
mover-se num instante, seja qual for a virtude do motor. Ora, os corpos gloriosos não perderão nunca a
sua corporeidade. Logo, não poderão nunca mover-se instantaneamente.

RESPOSTA À QUARTA. ─ A palavra celebridade, no texto citado de Agostinho, significa o excesso
imperceptível de um movimento sobre outro; assim como imperceptível é o tempo do movimento total.

RESPOSTA À QUINTA. ─ Embora depois da ressurreição não haja mais tempo, que é o número do
movimento do céu, contudo haverá o tempo resultante das relações numéricas de anterioridade e
posterioridade, que todo movimento supõe.