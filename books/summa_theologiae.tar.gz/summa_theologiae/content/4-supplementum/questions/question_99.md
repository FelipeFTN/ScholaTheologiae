# Questão 99: Da misericórdia e da justiça de Deus para com os condenados.
Em seguida devemos tratar da justiça e da misericórdia de Deus para com os condenados.
E nesta questão discutem-se cinco artigos:

## Art. 1 — Se a justiça divina inflige aos pecadores uma pena eterna.
O primeiro discute-se assim. ─ Parece que a divina justiça não inflige aos pecadores uma pena eterna.

1. ─ Pois, a pena não deve exceder a culpa, segundo aquilo da Escritura: O número dos golpes regular-
se-á pela qualidade do pecado. Ora, a culpa é temporal. Logo, não deve a pena ser eterna.

2. Demais. ─ De dois modos mortais um há de ser mais grave que outro. Logo, deve um ser punido com
uma pena mais intensa que a do outro. Ora, nenhuma pena é mais intensa, que a eterna, que é infinita.
Portanto, a nem todo pecado é devida uma pena eterna. E se não é devida a um, não o é a nenhum, pois
não é infinita a distância entre um pecado e outro.

3. Demais. ─ Um juiz justo não aplica senão penas corretivas, por isso diz Aristóteles, que as penas são
uns remédios. Ora, o serem os ímpios punidos com pena eterna não lhes pode servir de correção a eles
nem a ninguém mais, porque então já não haverá quem possa ser corrigido. Logo, a divina justiça não
aplicará aos pecados uma pena eterna.

4. Demais. ─ Uma cousa que não queremos por si mesma só por alguma utilidade sua podemos querê-
la. Ora, as penas Deus, que não se alegra com os nossos sofrimentos, não as quer por si mesmas. Logo,
como nenhuma utilidade pode provir de uma pena eterna, parece que tal pena não deve ser aplicada
pelo pecado.

5. Demais. ─ Nada do que é acidental é perpétuo, como diz Aristóteles. Ora, a pena, sendo contra a
natureza, é acidental. Logo, não pode ser perpétua.

6. Demais. ─ A justiça de Deus parece exigir que os pecados sejam reduzidos ao nada. Porque os ingratos
merecem ser privados dos benefícios recebidos. Ora, a existência é um dos benefícios de Deus. Por
onde, parece justo que o pecador, um ingrato para com Deus, perca a própria existência. Mas se os
pecadores fossem reduzidos ao nada, a sua pena não poderá ser perpétua. Logo, não parece
consentâneo com a justiça divina serem os pecados punidos eternamente.
Mas, em contrário, o Evangelho: Irão estes, i. é, os pecadores, para o suplício eterno.

2. Demais. ─ Assim está o prêmio para o mérito, como a pena para a culpa. Ora, pela divina justiça, a um
mérito temporal é devido um prêmio eterno, conforme o Evangelho: Todo o que vê o Filho e crê nele
tem a vida eterna. Logo, também à culpa temporal é devida, pela divina justiça, uma pena eterna.

3. Demais. ─ Segundo o Filósofo, a pena é determinada de conformidade com a dignidade de aquele
contra quem se pecou; e assim, com maior pena é punido quem deu um tapa no príncipe, que se o fez
em qualquer outro. Ora, todo o que peca mortalmente peca contra Deus, cujos mandamentos
transgride, e cuja honra atribui aquilo em que constituiu o seu fim. Mas a majestade de Deus é infinita.
Logo, todo aquele que peca mortalmente é digno de uma pena infinita. Portanto, parece justo sofrer
uma pena eterna quem cometeu um pecado mortal.

SOLUÇÃO. ─ A pena é susceptível de uma dupla grandeza: a da intensidade da sua crueza e a da sua
duração temporal. Ora, a grandeza da pena, quanto à intensidade da sua crueza, corresponde à
gravidade da culpa, de modo que a quem mais gravemente pecou maior pena lhe será infligida, segundo
aquilo da Escritura: Quanto ela se tem glorificado e vivido em deleites, tanto lhe dai de tormentos e
prantos. Não corresponde porém a duração da pena à duração da culpa, como diz Agostinho; assim, um
adultério, perpetrado num momento do tempo não é punido com uma pena momentânea, mesmo
pelas leis humanas. Mas a duração da pena concerne à disposição do pecador. Assim, umas vezes quem
comete um crime, numa cidade, pela própria natureza dele pode tornar-se digno de ser expulso
totalmente da sociedade dos seus co-cidadãos, quer pelo exílio perpétuo, quer pela morte. Outras
vezes, porém, não se torna digno de ser totalmente excluído da convivência com os seus co-cidadãos: e
por isso, para poder ser um membro útil à cidade, prolonga-se-lhe ou se lhe abrevia a pena, conforme o
necessário à sua correção, de modo que possa viver na cidade conveniente e pacificamente.
Assim também, pela divina justiça pode um se tornar, em virtude do pecado cometido, digno de ser
completamente segregado da convivência com os cidadãos da cidade de Deus; o que se dá por todo
pecado contrário à caridade vínculo que dá união aos membros dessa cidade. Portanto, quem comete
um pecado mortal, que é contrário à caridade, é-lhe aplicada a pena eterna de ficar para sempre
excluído da sociedade dos santos. Pois, como diz Agostinho, do mesmo modo que se é excluído da
cidade temporal pelo suplício da primeira morte, assim se é excluído da cidade imortal pelo suplício da
segunda morte. E se a pena infligida pela cidade temporal não é considerada perpétua, é por acidente
ou porque o homem não vive eternamente; ou ainda porque a cidade pode perder a existência. Mas, se
o homem vivesse eternamente, a pena do exílio ou de escravidão, infligida pela lei humana, duraria
eternamente. ─ Os que pecam porém sem contudo merecerem ser completamente segregados do
consórcio com os cidadãos da cidade santa, como os que pecam venialmente, tanto mais breve ou
diuturna lhes será a pena, quanto mais ou menos precisarem de purificação, na medida em que mais ou
menos se afeiçoaram ao pecado. Regra que, pela divina justiça, se observa no aplicar as penas deste
mundo ou as do purgatório.
Mas há ainda outras razões dadas pelos Santos Padres, para justificar a pena eterna com que é punido o
pecador, por um pecado temporal.
Uma é, que, desprezando a vida eterna, pecaram contra o bem eterno. E é o que também diz Agostinho
na obra supra-citada: O pecador é digno de um mal eterno por ter-se privado de um bem, que poderia
ser eterno.
Outra é que o homem peca pelo que tem de eterno. Donde o dizer Gregório: Pertence à justiça do
soberano Juiz sujeitar a um suplício eterno quem nesta vida não quis nunca separar-se do pecado. ─ E se
se objeta que certos, que pecam mortalmente, tem a intenção de um dia melhorar de vida, e assim não
seriam, parece, dignos de um suplício eterno, devemos responder, segundo alguns, que Gregório se
refere à vontade que se manifesta por obras. Pois, quem de própria vontade cai em pecado mortal
coloca-se num estado donde não pode ser retirado senão com o auxílio divino. Portanto, o fato mesmo
de querer pecar revela, por consequência, que quer permanecer perpetuamente no pecado; pois, o
homem é um espírito que passa i. é, ao pecado, e não torna, por si mesmo. Como se alguém se atirasse
num poço donde não pudesse sair senão ajudado, desse poderíamos dizer que aí quereria ficar
eternamente, embora pensasse o contrário. ─ Ou podemos responder, e melhor, quem peca
mortalmente por isso mesmo põe o seu fim na criatura. E como a nossa vida se ordena totalmente para
um fim, por isso, o pecador faz do seu pecado o fim da sua vida; e quereria ficar perpetuamente em
estado de pecado mortal, se isso lhe ficasse impune. Por isso, aquilo da Escritura ─ Reputará o abismo
como cheio de cans, etc., diz Gregório: Se os pecados dos iníquos tiveram um fim é porque também fim
lhes teve a vida. Pois, quereriam viver sem fim para que sem fim pudessem permanecer nos seus
pecados; porque mais desejam pecar que viver.
Mas pode-se também dar outra razão de ser eterna a pena da culpa mortal; é que por ela se peca contra
Deus, que é infinito. Por onde, não podendo a pena ter uma intensidade infinita, por não ser a criatura
capaz de nenhuma qualidade infinita, é necessário que pelo menos seja infinita na duração.
Enfim, para o explicar, há ainda uma quarta razão. E é que a culpa permanece eternamente, pois, não
pode ser perdoada sem a graça, e esta ninguém pode mais adquirir depois da morte. Ora, não deve a
pena cessar enquanto permanece a culpa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Não deve a pena equiparar-se à culpa na quantidade da
duração, como o vemos mesmo estabelecido pelas leis humanas. ─ Ou devemos responder, como o faz
Gregório, que embora a culpa seja temporal no seu ato, é eterna na vontade que a quis.

RESPOSTA À SEGUNDA. ─ A gravidade do pecado corresponde a intensidade da pena. Por isso, pecados
mortais de gravidade desigual terão penas de intensidade desigual, mas de duração igual.

RESPOSTA À TERCEIRA. ─ As penas infligidas aos que não foram totalmente segregados da sociedade
civil se lhes ordenam à correção. Mas não são para a correção do delinquente as que a eliminam
totalmente da comunidade social. Podem porém servir à correção e à tranquilidade dos mais membros
da cidade. Assim também, a condenação eterna dos ímpios serve para a correção dos membros
remanescentes da Igreja. Pois, as penas não são corretivas só quando infligidas, mas também quando
determinadas por lei.

RESPOSTA À QUARTA. ─ Não é, absolutamente, inútil que as penas dos ímpios durem eternamente.
Pois, tem uma dupla utilidade. ─ Primeiro, porque mantém sobre os culpados o reino da justiça divina, a
qual em si mesma faz parte dos planos de Deus. Por isso diz Gregório: Deus onipotente, por ser
bondoso, não se compraz com o suplício dos condenados. Como porém é justo, não pode deixar de se
vingar eternamente aos maus. ─ Segundo, são úteis para com elas se alegrarem os eleitos, adorando
nelas a justiça divina, e rejubilando por lhes ter escapado. Por isso diz a Escritura: Alegrar-se-á o justo
quando vir a vingança. E noutro lugar: Os ímpios servirão de espetáculo até à saciedade, i. é, aos santos,
como explica a Glosa. E isto é o que diz Gregório: Todos os maus, condenados ao suplício eterno, são
punidos pela sua iniquidade. E contudo arderão para alguma utilidade: para todos os justos verem em
Deus a felicidade que alcançaram, e nos condenados os suplícios de que se livraram. De tal sorte que
tanto mais se reconheçam eternamente devedores da graça divina, quanto virem para sempre punido o
mal que ela os ajudou vencer.

RESPOSTA À QUINTA. ─ Embora a pena só acidentalmente se aplique à alma, contudo se aplica
essencialmente à alma contaminada pela culpa. E como a culpa nela permanecerá perpetuamente, por
isso perpétua também será a pena.

RESPOSTA À SEXTA. ─ A pena corresponde à culpa, propriamente falando, pela desordem que esta
implica, e não pela dignidade daquele contra quem se pecou. Porque, do contrário, a qualquer pecado
corresponderia uma pena de intensidade infinita. Embora, pois, se quem peca contra Deus, autor da
existência, merece por isso perdê-la, contudo não a deve perder considerada a desordem do seu ato.
Porque a existência é um pressuposto para o mérito e o demérito; nem a desordem do pecado priva da
existência ou a corrompe. Por onde, não pode ser a pena devida a nenhuma culpa o ficar o seu autor
privado da existência.

## Art. 2 — Se a divina misericórdia porá um termo a toda pena, tanto dos condenados como dos demônios.
O segundo discute-se assim. ─ Parece que a divina misericórdia porá um termo a toda a pena, tanto
dos condenados como dos demônios.

1. ─ Pois, diz a Escritura: Tu tens compaixão de todos, Senhor, porque tudo podes. Ora, nesses todos
estão incluídos também os demônios, que são criaturas de Deus. Logo, a pena dos demônios também
acabará.

2. Demais. ─ Diz o Apóstolo: Deus a todos encerrou no pecado para usar com todos de misericórdia. Ora,
Deus encerrou os demônios no pecado, i. é, permitiu que fossem encerrados. Logo, parece que um dia
também usará de misericórdia para com os demônios.

3. Demais. ─ Diz Anselmo: Não é justo permitir Deus pereçam para sempre criaturas, que fez para a
felicidade. Logo, parece, desde que toda criatura racional foi criada para a felicidade, não ser justo
permita que todas pereçam para sempre.
Mas, em contrário, o Evangelho: Apartai-vos de mim, malditos, para o fogo eterno, que está aparelhado
para o diabo e para os seus anjos. Logo, serão punidos eternamente.

2. Demais. ─ Assim como os bons anjos se tornaram felizes pela sua conversão para Deus, assim os maus
se tornaram infelizes pela aversão dele. Se, portanto, a miséria dos maus deve acabar um dia, um dia
também deverá acabar a felicidade dos bons. O que é inadmissível.

SOLUÇÃO. ─ Foi erro de Orígenes, como refere Agostinho, afirmar que um dia os demônios serão
liberados das suas penas, pela misericórdia de Deus. Mas este erro foi condenado pela Igreja, por duas
razões. ─ Primeiro, por manifestamente repugnar à autoridade da Sagrada Escritura. Assim, diz o
Apocalipse: O diabo que enganava, foi metido no tanque de fogo e de enxofre, onde assim a besta como
o falso profeta serão atormentados de dia e de noite por séculos dos séculos; maneira essa por que a
Escritura costuma significar a eternidade. ─ Segundo, porque tal doutrina torna a misericórdia de Deus,
de um lado, muito larga; e de outro, muito estreita. Pois, pela mesma razão por que os bons anjos
gozam da eterna felicidade devem os maus anjos ser punidos eternamente. Por isso, assim como
ensinava que os demônios e as almas condenadas deverão ser um dia liberados das suas penas, assim
também que os anjos e as almas dos bem-aventurados deverão voltar um dia, da felicidade do céu, às
misérias desta vida.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Deus, pelo que é, tem misericórdia de todos. Mas como a
sua misericórdia é regulada pela ordem da sua: sabedoria, por isso não se estende a certos, como os
demônios e os obstinados na malícia, que dela se tornaram indignos. ─ Contudo, podemos responder
que mesmo para com esses se exerce a sua misericórdia, não pelos absolver totalmente da pena, mas
por serem punidos menos que o que mereceriam.

RESPOSTA À SEGUNDA. ─ No lugar citado do Apóstolo, deve-se entender distributivamente de todos os
gêneros de seres e não de todos os seres de cada gênero. Aplicando-se o texto aos homens enquanto
vivem neste mundo; pois, Deus se compadeceu dos judeus e dos gentios, mas nem de todos os gentios
ou de todos os judeus.

RESPOSTA À TERCEIRA. ─ Anselmo não o entende justo, pelas conveniências da divina bondade; e se
refere às criaturas genericamente consideradas. Pois, não convém à divina bondade fazer todo um
gênero de criaturas ficar impedido de alcançar o fim para que foi criado. Não quer por isso nem que
todos os homens se condenem nem todos os anjos. Mas nada impede alguns homens ou alguns anjos
de se condenarem eternamente; porque os planos da divina vontade se cumprem nos que se salvam.

## Art. 3 — Se a divina misericórdia sofre que ao menos os homens sejam punidos eternamente.
O terceiro discute-se assim. ─ Parece que a divina misericórdia não sofre que ao menos os homens
sejam punidos eternamente.

1. ─ Pois, diz a Escritura: O meu espírito não permanecerá para sempre no homem porque é carne; e
espírito tem aí o sentido de indignação, como o explica a Glosa a esse lugar. Logo, como a indignação de
Deus outra coisa não é senão a pena que impõe, os homens não serão eternamente punidos.

2. Demais. ─ A caridade dos santos nesta vida os leva a orarem pelos inimigos. Ora, no céu terão a
caridade perfeita. Logo hão de aí orar pelos inimigos condenados. Mas, as orações deles não poderão
ser vãs, pois, são por excelência aceitas de Deus. Portanto, movido pelas preces dos santos, a divina
misericórdia um dia livrará os condenados das suas penas.

3. Demais. ─ Que tivesse Deus ameaçado os condenados de os castigar com uma pena eterna, podemos
considerá-lo como uma profecia cominatória. Ora, uma profecia cominatória nem sempre se cumpre;
assim se deu com a relativa à subversão de Nínive, que não foi destruída, como o predissera o profeta,
por terem os seus habitantes feito penitência. Logo e com muito maior razão, a cominação de castigos
eternos feita pela divina misericórdia há de transmutar-se numa sentença mais branda, quando puder
redundar em alegria de todos e não causar pena a ninguém.

4. Demais. ─ O mesmo se conclui do lugar seguinte da Escritura: Porventura a cólera de Deus será
eterna? Ora, a cólera de Deus é a sua punição. Logo, Deus não punirá os homens eternamente.

5. Demais. ─ Aquilo da Escritura: Tu porém foste rejeitado, etc., diz a Glosa: Se todas as almas um dia
tiverem descanso, tu nunca, referindo-se ao diabo. Logo, parece que um dia todas as almas humanas
terão descanso das suas penas.
Mas, em contrário, diz o Evangelho, tanto dos eleitos como dos réprobos: Irão estes para o suplício
eterno e os justos para a vida eterna. Ora, é inadmissível dizer-se que a vida dos justos um dia há de
acabar. Logo, inadmissível também é dizer que há de terminar o suplício dos réprobos.

2. Demais. ─ Como diz Damasceno, o que é a morte para os homens foi para os anjos a queda. Ora, a
queda dos anjos foi irreparável. Logo, também imutável será a situação dos homens depois da morte. E
portanto, o suplício dos réprobos nunca terminará.

SOLUÇÃO. ─ Como refere Agostinho, certos se separaram do erro de Orígenes, ensinando que os
demônios serão punidos eternamente. Mas continuaram-lhe o erro, por admitirem que os homens,
mesmo os infiéis serão um dia liberados das suas penas. ─ Esta opinião porém é absolutamente
irracional. Pois, assim como os demônios serão punidos eternamente por estarem obstinados na
malícia, assim também as almas humanas mortas sem caridade; pois, o que é a morte para os homens
foi para os anjos a queda, como diz Damasceno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O lugar citado deve entender-se do homem,
genericamente considerado; pois, um dia, no advento de Cristo, cessou a indignação de Deus contra o
gênero humano. Mas aqueles que não quiseram aproveitar dessa reconciliação feita por Cristo, em si
mesmos perpetuaram a cólera divina; pois, não temos nenhum outro meio de nos reconciliarmos com
Deus, senão por Cristo.

RESPOSTA À SEGUNDA. ─ Como dizem Agostinho e Gregório, se os santos nesta vida oram pelos
inimigos, é para que, enquanto o podem, se convertam para Deus. Mas se soubéssemos que eram
prescritos, para a morte, não oraríamos por eles, como não oramos pelos demônios. E como para os que
partiram desta vida sem a graça já não haverá mais tempo de conversão, nenhuma oração fará por eles
nem a Igreja militante nem a triunfante. Pois, oramos por eles, como diz o Apóstolo, para que Deus lhe
dê o dom da penitência e para que saiam dos laços do diabo.

RESPOSTA À TERCEIRA. ─ A profecia de uma pena cominatória só fica sem cumprimento quando variam
os méritos daquele contra quem foi feita. Donde o dizer a Escritura: De repente falarei contra uma gente
e contra um reino, para desarraigá-lo e destruí-la e arruiná-lo. Se aquela gente se arrepender do seu mal
também eu me arrependerei do mal que tenho pensado fazer contra ela. Logo, como os méritos dos
condenados não são susceptíveis de mudança, a pena cominatória sempre neles se cumprirá. ─ Todavia,
a profecia cominatória, entendida de certo modo, não deixa nunca de se cumprir. Pois, como diz
Agostinho, Nínive foi realmente destruída, pois, de má que era veio a tornar-se boa; e assim,
conservando os mesmos muros e as mesmas casas, desapareceu a cidade nos maus costumes dos seus
habitantes.

RESPOSTA À QUARTA. ─ As palavras do salmo citado se referem aos vasos de misericórdia que não se
fizeram indignos dela. Pois, nesta vida, que pelas suas misérias é uma como ira de Deus, os vasos de
misericórdia podem mudar-se para melhor. Por isso continua o salmo: Esta mudança vem da dextra do
Altíssimo ─ Ou devemos responder que se entenda da misericórdia que perdoa parte do castigo sem
livrar dele totalmente, dado que deva estender-se também aos condenados. Por isso não disse o
salmista: Conterá da ira, as suas misericórdias, mas, na ira, porque não livrará totalmente da pena mas
obrará, na vigência dela, para a diminuir.

RESPOSTA À QUINTA. ─ A Glosa citada não afirma em sentido absoluto, mas supondo o impossível, a
fim de mostrar a grandeza do pecado do diabo ou de Nabucodonosor.

## Art. 4 — Se ao menos à pena dos cristãos porá termo a divina misericórdia.
O quarto discute-se assim. ─ Parece que ao menos à pena dos cristãos porá termo a divina
misericórdia.

1. ─ Pois, diz o Evangelho: O que crer e for batizado será salvo. Ora, isto se aplica a todos os cristãos.
Logo, todos os cristãos serão finalmente salvos.

2. Demais. ─ Diz o Evangelho: O que come a minha carne e bebe o meu sangue tem a vida eterna. Ora,
essa é uma comida e uma bebida comum a todos os cristãos. Logo, todos os cristãos serão finalmente
salvos.

3. Demais. ─ Diz o Apóstolo: Se a obra de alguém se queimar, padecerá ele detrimento; mas o tal será
salvo, se bem desta maneira por intervenção do fogo. E se refere aqueles que tiveram o fundamento da
fé cristã. Logo, todos esses serão finalmente salvos.
Mas, em contrário, o Apóstolo: Os iníquos não hão de possuir o reino de Deus. Ora, certos cristãos são
iníquos. Logo, nem todos os cristãos alcançarão o reino celeste. Portanto, serão eternamente
castigados.

2. Demais. ─ Diz a Escritura: Melhor lhes era não ter conhecido o caminho da justiça, do que depois de o
ter conhecido, tornar para trás, deixando aquele mandamento santo que te fora dado. Ora, os que não
conhecem o caminho da verdade serão punidos eternamente. Logo, também os cristãos que
retrocederam do caminho conhecido.

SOLUÇÃO. ─ Como refere Agostinho, na obra citada, certos foram de opinião que, não todos os homens,
mas só os cristãos, serão os perdoados da pena eterna. Mas essa opinião tem modalidades diversas.
Assim, uns ensinaram que todos os que receberam os sacramentos da fé serão imunes da pena eterna.
─ Mas isto é contrário à verdade, porque certos recebem os sacramentos da fé sem na terem, e sem ela
é impossível agradar a Deus. Por isso pretenderam outros, que só aqueles ficarão livres da pena eterna
que receberam os sacramentos da fé e conservaram a fé católica. ─ Mas contra isso vai o fato de certos,
que professaram a fé católica, abandonarem-na em seguida. E esses, longe de merecerem uma pena
menor, são dignos de um castigo maior, conforme o lugar da Escritura: Melhor lhes era não ter
conhecido o caminho da justiça, do que depois de o ter conhecido, tornarem para trás. ─ Além disso, é
claro que os heresíarcas que, abandonando a fé católica, ensinaram novas heresias, que aqueles que
desde o princípio seguiram uma heresia determinada.
Por isso opinaram outros que só aqueles são imunes da pena eterna, que perseveraram na fé católica
até a morte, por mais pecados que tivessem cometido. ─ Mas isto contraria manifestamente à Escritura,
que diz: A fé sem obras é morta. E noutro lugar: Nem todo o que me diz ─ Senhor, Senhor, entrará no
reino dos céus. ─ E em muitos outros lugares onde ameaça os pecadores com as penas eternas. Por
onde, nem todos os que perseverarem na fé até à morte ficarão isentos da pena eterna, salvo se, na
hora de morrerem, forem finalmente absolvidos dos pecados cometidos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O Senhor, no lugar citado, se refere à fé formada, que
obra pelo amor; e quem nessa morrer será salvo. Ora, a essa fé se opõe, não somente o erro da
infidelidade, mas também qualquer pecado mortal.

RESPOSTA À SEGUNDA. ─ Essas palavras do Senhor se entendem, não daqueles que lhe comem
sacramentalmente a carne e que, tomando-a indignamente, comem e bebem para si a condenação,
como diz o Apóstolo. Mas se referem aos que a comem espiritualmente, unidos a Cristo pela caridade;
união essa operada pela manducação sacramental, quando dignamente recebemos o sacramento. Por
onde, considerada em si mesma a virtude do sacramento, conduz à vida eterna, embora possa um,
mesmo depois de o ter recebido dignamente, ser privado do fruto da eterna vida, pelo pecado.

RESPOSTA À TERCEIRA. ─ Por fundamento, nas palavras do Apóstolo, se entende a fé formada. E quem
eleva um edifício de pecados veniais sobre esse fundamento padecerá detrimento, porque Deus há de
puni-lo por eles; mas o tal será salvo finalmente, se bem desta maneira por intervenção do fogo, ou das
tribulações temporais, ou das penas do purgatório, depois da morte.

## Art. 5 — Se todos os que praticam as obras de misericórdia serão punidos eternamente, ou se só aqueles que descuraram de praticar essas obras.
O quinto discute-se assim. ─ Parece que todos os que praticam as obras de misericórdia não serão
punidos eternamente, mas só aqueles que descuraram de praticar essas obras.

1. ─ Pois, diz a Escritura: Porque se fará juízo sem misericórdia aquele que não usou misericórdia. E
noutro lugar: Bem-aventurados os misericordiosos, porque eles alcançarão misericórdia.

2. Demais. ─ O Evangelho refere uma discussão do Senhor com os réprobos e os eleitos. Ora, essa
discussão não versou senão sobre as obras de misericórdia. Logo, só os que tiverem omitido as obras de
misericórdia é que serão punidos eternamente. Donde a mesma conclusão anterior.

3. Demais. ─ O Evangelho diz: Perdoai-nos as nossas dívidas assim como nós perdoamos aos nossos
devedores. E continua: Se vós perdoardes aos homens as ofensas que tendes deles, também vosso Pai
celestial vos perdoará os vossos pecados. Logo, parece que os misericordiosos, que perdoam os pecados
aos outros, também alcançarão o perdão dos seus pecados. Portanto, não serão punidos eternamente.

4. Demais. ─ Aquilo do Apóstolo ─ A piedade para tudo é útil, diz a Glosa de Ambrósio: A súmula de toda
a doutrina cristã é a misericórdia e a piedade; quem a praticar, embora venha a cair nos laços da carne,
será sem dúvida punido, mas nem por isso perecerá; mas quem tiver vivido só a vida do corpo, sofrerá
penas eternas. Logo, os que praticam as obras de misericórdia, mas vivem escravos dos pecados da
carne, não serão punidos eternamente. Donde, a mesma conclusão anterior.
Mas, em contrário, o Apóstolo: Nem os fornicários nem os adúlteros hão de possuir o reino de Deus.
Ora, tais são muitos dos que praticam obras de misericórdia. Logo, nem todos os misericordiosos
alcançarão o reino dos céus. Portanto, certos deles serão punidos eternamente.

2. Demais. - Diz a Escritura: Qualquer que tiver guardado toda a lei e faltar em um só ponto fez─se réu
de ter violado todos. Logo, quem quer que observe a lei, no concernente às obras de misericórdia, e
descure as demais obras, incorrerá na transgressão da lei. E assim, será punido eternamente.

SOLUÇÃO. ─ Como diz Agostinho, na obra citada, certos ensinaram que nem todos os que professam a
fé católica hão de livrar-se da pena eterna, mas só os que praticam as obras de misericórdia, embora
andem enredados em outros pecados. ─ Mas isto é inadmissível. Porque sem a caridade ninguém pode
agradar a Deus, nem sem ela nada aproveita à vida eterna. Ora, podem-se praticar as obras de
misericórdia sem contudo ter-se caridade. Por onde, os que assim procederem, elas em nada lhes
aproveitam para merecerem à vida eterna nem para se livrarem das eternas penas, conforme ao
Apóstolo. O absurdo de se admitir o contrário se vê no caso de ladrões que tivessem exercido
largamente o roubo e, contudo, feito obras de misericórdia. ─ Donde devemos concluir que todos os
mortos em estado de pecado mortal, nem a fé nem as obras de misericórdia os livrarão da pena eterna,
seja depois de que espaço de tempo for.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Aqueles conseguirão misericórdia que a praticaram
ordenadamente. Ora, não praticam a misericórdia ordenadamente os que, esquecendo-se de a praticar
para consigo mesmos, antes, fazem-se a si mesmo mal com as suas obras. Por isso esses tais não
conseguirão uma misericórdia que lhes absolverá totalmente os pecados, mas que apenas a que lhes
minorará as penas que deveriam sofrer.

RESPOSTA À SEGUNDA. ─ A discussão referida não versa sobre as obras de misericórdia só porque o
descurar delas seja a causa única de certos serem punidos eternamente. Mas porque aqueles serão
liberados da pena eterna, depois do pecado, que, pelas obras de misericórdia, alcançaram o perdão
granjeando para si amigos com as riquezas da iniquidade.

RESPOSTA À TERCEIRA. ─ Essas palavras o Senhor as dirige aos que pedem o perdão das suas dividas;
mas não aos que perseveram no pecado. Por onde, só os penitentes, pelas obras de misericórdia,
alcançarão um perdão plenamente liberatório.

RESPOSTA À QUARTA. ─ A Glosa de Ambrósio se refere ao lapso no pecado venial da carne, do qual o
pecador será absolvido, pelas obras de misericórdia, depois das penas purificadoras, a que chama
expiação. ─ Ou, se se refere à queda no pecado mortal, deve se entender o lugar citado como
significando que aqueles que, nesta vida, caem por fraqueza nos pecados da carne, as obras de
misericórdia os disporão à penitência. E esses tais não perecerão, i. é, essas obras os disporão para que
não pereçam.
