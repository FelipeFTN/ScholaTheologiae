# Questão 82: Da impassibilidade dos corpos dos bem-aventurados
ressurectos.
Em seguida devemos tratar da condição dos bem-aventurados ressurrectos. E primeiro, da
impassibilidade dos seus corpos. Segundo, da subtileza. Terceiro, da agilidade. Quarto, da claridade.
Sobre a impassibilidade discutem-se quatro artigos:

## Art. 1 — Se os corpos dos santos depois da ressurreição serão impassíveis.
O primeiro discute-se assim. ─ Parece que os corpos dos santos depois da ressurreição não serão
impassíveis.

1. ─ Pois, tudo o que é mortal é passível. Ora, o homem depois da ressurreição será um animal racional
mortal, definição esta do homem, que nunca deixará de se aplicar. Logo, o corpo será passível.

2. Demais. ─ Tudo o que é potencial em relação à forma de outro corpo, pode sofrer a ação deste; pois,
é a potencialidade em relação à forma que constitui a passibilidade, segundo o Filósofo. Ora, os corpos
dos santos depois da ressurreição estarão em potência em relação a outra forma. Logo, serão passíveis.
─ Prova da média. Seres com matéria comum, um deles será potencial em relação à forma de outro; ora,
a matéria, por unida a uma forma não perde a potência para unir-se a outra. Ora, os corpos dos santos
depois da ressurreição comunicarão com os elementos na matéria, porque serão reconstituídos de
matéria idêntica à que agora têem. Logo, serão potenciais em relação a outra forma. E portanto, serão
passíveis.

3. Demais. ─ É natural aos contrários serem ativos e passivos uns em relação aos outros, diz o Filósofo.
Ora, os corpos dos santos depois da ressurreição serão compostos de elementos contrários, como o são
agora. Logo, serão passíveis.

4. Demais. ─ Com o corpo humano ressurgirão o sangue e os outros humores, como se disse. Ora, a luta
dos humores uns com os outros gera as doenças e outras paixões do corpo. Logo, os corpos dos santos
depois da ressurreição serão passíveis.

5. Demais. ─ Mais repugna à perfeição um defeito atual que um defeito potencial. Ora, a passibilidade
implica apenas um defeito potencial. Como porém nos corpos dos bem-aventurados hão de existir em
ato alguns defeitos, como as cicatrizes das chagas nos mártires, como as existiram em Cristo, parece que
nenhum detrimento sofrerá a perfeição deles se admitirmos que tem corpos passíveis.
Mas, em contrário. ─ Todo passível é corruptível, porque a paixão causada por uma ação muito intensa
destrói a substância. Ora, os corpos dos santos depois da ressurreição serão incorruptíveis, conforme
aquilo do Apóstolo: Semeia-se o corpo em corrupção, ressuscitará em incorrupção. Logo, serão
impassíveis.

2. Demais. ─ O mais forte não sofre do mais fraco. Ora, nenhum corpo será mais forte que o dos santos,
dos quais diz o Apóstolo: semeia-se em vileza, ressuscitará em glória. Logo, serão impassíveis.

SOLUÇÃO. ─ A paixão pode ser considerada em duplo sentido. ─ Primeiro, em geral. E então toda
recepção é considerada paixão; quer o recebido convenha ao recipiente e o aperfeiçoe; quer o
contrário, e o corrompa. Pela remoção dessa paixão são impassíveis os corpos gloriosos, pois, não
podem ser privados de nenhuma das suas perfeições. ─ Em sentido próprio paixão é como a define
Damasceno: Paixão é o movimento contrário à natureza. Assim paixão se chama o movimento
imoderado do coração: ao passo que o moderado lhe é a operação. E a razão disso é que, todo paciente
é arrastado para os limites do agente, porque o agente faz assemelhar-se a si o paciente. Por isso o
paciente como tal, é arrastado para fora dos seus limites. Assim, pois, tomando a paixão no seu sentido
próprio, não haverá nos corpos dos santos ressurrectos nenhuma potencialidade para a paixão.
Portanto, serão impassíveis.
Mas razões diversas foram dadas dessa impassibilidade.
Uns a atribuem à condição dos elementos, que no corpo dos ressurrectos não existirão como existem
agora. Pois, pensam, os elementos então existirão na sua substância, mas com perda das suas
qualidades ativas e passivas. Por onde, se os elementos forem reconstituídos sem elas nos corpos dos
ressurrectos, menor perfeição será a deles que a de agora. Além disso, essas qualidades sendo acidentes
próprios dos elementos, causadas pela forma e pela matéria delas, muito absurdo será permanecer uma
causa sem poder produzir o seu efeito.
Por isso outros pretendem que permanecerão as qualidades, mas sem as suas ações próprias, o que o
poder divino assim o fará para a conservação do corpo humano. ─ Mas também isto não é admissível. ─
Porque uma mistura exige a ação e a paixão de qualidades ativas e passivas; e segundo predominarem
umas ou outras, diversa será a compleição do mista. O que devemos admitir no corpo ressurrecto, que
terá carnes e ossos e partes tais, o que tudo não pode constituir uma só compleição. Além disso,
segundo esta opinião, a impassibilidade não poderia considerar-se um dote dos ressurrectos. Porque
não introduziria nenhuma disposição na substância impassível, mas só a isenção de qualquer paixão
exterior causada por virtude divina, que poderia também fazer o mesmo para com os corpos ainda nas
condições da vida presente.
Donde o ensinarem outros que os próprios corpos gloriosos poderão livrar-se por si de qualquer paixão,
pela natureza do quinto corpo, que entra, segundo dizem, na composição do corpo humano, para
conciliar os elementos numa certa harmonia, que os torne a matéria susceptiva da alma racional.
Contudo, no estado desta vida, por causa de predominância da matéria elementar, o corpo humano é
passivo, à semelhança dos outros elementos; mas na ressurreição predominará a natureza do quinto
corpo. E então impassível se tornará o corpo humano, à semelhança do corpo celeste. ─ Mas esta
opinião é inadmissível. Porque o quinto corpo não entra materialmente na composição do corpo
humano, como se provou. Além disso, é impossível que uma virtude natural, como a do corpo celeste,
confira ao corpo humano a propriedade da glória, que tal é a impassibilidade do corpo glorioso. Pois, a
transformação do corpo humano o Apóstolo a atribui ao poder de Cristo, porque qual é o celeste, tais
são também os celestiais. E noutro lugar diz: Reformará o nosso corpo abatido, para o fazer conforme
ao seu corpo glorioso, segundo a operação com que também pode sujeitar a si todas as cousas, etc.
Demais, a natureza celeste não pode ser a ponto predominante no corpo humano que faça desaparecer
a natureza elementar, que implica a passibilidade nos seus princípios essenciais.
Por isso, devemos responder que toda paixão resulta da vitória do agente sobre o paciente, do contrário
aquele não arrastaria a este para os seus limites. Ora, é impossível um agente dominar o paciente senão
lhe enfraquecendo o domínio da sua forma própria sobre a matéria, tratando-se, como agora se trata,
da paixão contrária à natureza. Pois, a matéria não se sujeita a um dos contrários sem que desapareça o
domínio do outro sobre ela, ou pelo menos fique diminuído. Ora, o corpo humano com tudo o existente
nele será, na ressurreição, perfeitamente sujeito à alma, como esta o será perfeitamente a Deus. Por
onde, os corpos gloriosos não poderão sofrer mudança nenhuma contra a disposição pela qual são
aperfeiçoados pela alma. E portanto serão impassíveis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Diz Anselmo: Introduziram a idéia de mortalidade na
definição do homem os filósofos descrentes de que ele um dia pudesse vir a ser completamente imortal;
pois só viam o homem no estado da sua mortalidade atual. ─ Ou podemos responder que, segundo o
Filósofo, as diferenças essenciais sendo-nos desconhecidas, recorremos às acidentais para as exprimir,
por serem elas as causas destas. Por isso a palavra mortal não entra na definição do homem para
significar que a mortalidade lhe pertence à essência; mas sim que a composição de elementos
contrários, causa da passibilidade e da mortalidade na vida presente, é da essência humana. Mas, então,
não mais lhe será a causa, em virtude da vitória da alma sobre o corpo.

RESPOSTA À SEGUNDA. ─ Há duas espécies de potência: a ligada e a livre. E isto é verdade não só da
potência ativa, mas também da passiva; pois, a forma liga a potência da matéria imprimindo-lhe uma
determinação, que a domina. E como nos seres sujeitos à corrupção a forma não domina perfeitamente
a matéria, não pode ligá-la de modo tão completo que não possa às vezes esta receber, imposta por
alguma paixão, uma disposição contrária à forma. Nos santos porém, depois da ressurreição, a alma
dominará completamente o corpo; nem pode de nenhum modo ser privada desse domínio, porque
estará imutavelmente sujeita a Deus, o que não se deu no estado de inocência. Por isso tais corpos
terão a mesma potência para outra forma a que estão presentemente unidos, quanto à substância da
potência; mas estará ligada, pela vitória da alma sobre o corpo, de modo que não poderá nunca sofrer
nenhuma paixão.

RESPOSTA À TERCEIRA. ─ As qualidades elementares são instrumentos da alma, como esta claro em
Aristóteles. Porque o calor do fogo no corpo animal é regulado, no ato da nutrição, pela virtude da alma.
Mas quando o agente principal é perfeito e nenhum defeito tem o instrumento, nenhum ato deste
procede senão por disposição daquele. Por isso, aos corpos dos santos depois da ressurreição, nenhuma
ação ou paixão lhes pode resultar das qualidades elementares, em contra-posição à disposição da alma,
que visa conservar o corpo.

RESPOSTA À QUARTA. ─ Segundo Agostinho, a virtude divina pode privar os corpos visíveis e palpáveis
deste mundo das qualidades que quiser e lhes deixar as que quiser. Por isso, assim como parcialmente
privou o fogo da fornalha dos caldeus do poder de queimar, pois ilesos se conservaram os corpos dos
meninos, mas de certo modo permitiu que queimasse porque queimada ficou a lenha, assim também
privará os humores da sua passibilidade e deixará subsistir a natureza. E a maneira por que o fará, já
dissemos.

RESPOSTA À QUINTA. ─ As cicatrizes das feridas não existirão nos santos, nem existiram em Cristo,
enquanto implicam defeito, mas enquanto sinais da virtude constantíssima, com que sofreram pela
justiça e pela fé; e por isso lhes aumentarão a alegria, a si e aos outros. Donde o dizer Agostinho: Não sei
por que amorosa afeição, nutrida para com os santos mártires, desejamos, no reino celeste,
contemplar-lhes as cicatrizes dos ferimentos que os seus corpos padeceram pelo nome de Cristo. E
talvez as contemplemos. Pois, não lhes constituirão eles uma deformidade, mas uma dignidade; e há de
lhes fulgir uma grande beleza no corpo, embora não do corpo, mas da virtude. Mas nem por terem tido
amputados e arrancados os membros, sem eles aparecerão no ressurgir dos mortos, a eles a quem foi
dito: não se perderá um cabelo da vossa cabeça.

## Art. 2 — Se a impassibilidade será igual em todos.
O segundo discute-se assim. ─ Parece que a impassibilidade será igual em todos.

1. ─ Pois, como diz a Glosa, todos serão igualmente isentos do sofrimento. Ora, não poderão sofrer por
terem o dote da impassibilidade. Logo, a impassibilidade será igual em todos.

2. Demais. ─ A negação não é susceptível de mais e de menos. Ora, a impassibilidade é uma negação ou
privação da passibilidade. Logo, não poderá ser maior em um que em outro.

3. Demais. ─ Mais branco é o que nenhuma mistura tem de preto. Ora, nenhum dos corpos dos santos
terá de mistura qualquer passibilidade. Logo, todos serão igualmente impassíveis.
Mas, em contrário. ─ O mérito deve corresponder proporcionalmente ao prêmio. Ora, dos santos uns
tiveram maior mérito que outros. Logo, sendo a impassibilidade um prêmio, há de ser maior em uns que
em outros.

2. Demais. ─ A impassibilidade entra na mesma divisão que o dom da claridade. Ora, esta não será igual
em todos, como diz o Apóstolo. Logo, nem a impassibilidade.

SOLUÇÃO. ─ A impassibilidade pode ser considerada a dupla luz: em si mesma ou na sua causa. Em si,
como só implica privação ou negação, não é susceptível de mais nem de menos, mas será igual em
todos os bem-aventurados. Considerada porém na sua causa, será maior em um que em outro. Ora, a
sua causa é o domínio da alma sobre o corpo, domínio esse causado da imobilidade com que a alma
goza de Deus. Por onde quem mais perfeitamente gozar de Deus terá aí uma causa de maior
impassibilidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essa glosa se refere à impassibilidade em si mesma
considerada, e não na sua causa.

RESPOSTA À SEGUNDA. ─ Embora as negações e as privações não sejam em si mesmas susceptíveis de
intenção nem de remissão, podem contudo ser mais intensas ou remissas nas suas causas. Assim
dizemos mais escuro o lugar que opõe mais e maiores obstáculos à luz.

RESPOSTA À TERCEIRA. ─ Certas cousas se intensificam não somente pelo afastamento do que lhe é
contrário, mas também por aproximar-se do termo; tal a intensificação da luz. Por isso também a
impassibilidade é maior em um que em outro, embora em nenhum coexista com qualquer espécie de
passibilidade.

## Art. 3 — Se a impassibilidade priva os corpos gloriosos do exercício atual dos sentidos.
O terceiro discute-se assim. ─ Parece que a impassibilidade priva os corpos gloriosos do exercício atual
dos sentidos.

1. ─ Pois, como diz o Filósofo, sentir é de certo modo sofrer. Ora, os corpos gloriosos serão impassíveis.
Logo, não terão o exercício atual dos sentidos.

2. Demais. ─ A modificação natural precede à modificação sensível, como o ser natural precede ao ser
intencional. Ora, os corpos gloriosos, em virtude da sua impassibilidade, não são susceptíveis de
nenhuma modificação natural. Logo, nem da modificação sensível, condição necessária para sentir.

3. Demais. ─ Sempre que a sensação se atualiza, pela recepção de uma nova modificação sensível, dá
lugar a um novo juízo. Ora, na vida futura não se formarão novos juízos, porque não haverá então
mudanças nos pensamentos. Logo, não hão de exercer os corpos gloriosos atos sensíveis.

4. Demais. ─ Quando uma potência da alma está em intensa atividade, as outras potências sofrem
remissão nos seus atos. Ora, na vida futura, a alma será intensamente tomada pelo ato da virtude
intelectiva, com que contempla a Deus. Logo, de nenhum modo exercerá os atos da potência sensitiva.
Mas, em contrário, a Escritura: Todo olho o verá. Logo, haverá então atividade sensível.

2. Demais. ─ Diz o Filósofo: O animado se distingue do inanimado pelo sentido e pelo movimento. Ora,
na vida futura haverá movimento em ato, porque como faíscas por um canavial discorrerão, na frase da
Escritura. Logo, haverá exercício atual da sensibilidade.

SOLUÇÃO. ─ Todos admitem que os corpos gloriosos exercem um certo sentido; do contrário a vida
corporal dos santos depois da ressurreição seria assimilada mais ao sono que à vigília. O que não se lhes
coaduna com a perfeição, porque no sono o corpo sensível não exerce o ato vital na sua plenitude, e por
isso Aristóteles chama ao sono meia vida.
Mas as opiniões variam quando se trata de explicar o modo de sentir.
Uns dizem que, sendo os corpos gloriosos impassíveis e por isso incapazes de receber impressões
estranhas, e muito mais que os corpos celestes, não exercerão a atividade sensível recebendo qualquer
espécie dos sensíveis, mas antes projetando-o para o exterior. ─ Mas isto não pode ser. Porque na
ressurreição perdurará a natureza específica tal qual era no corpo e em todas as suas partes. Ora, os
sentidos são por natureza potências passivas, como o prova o Filósofo. Portanto, se na ressurreição os
santos sentissem projetando a imagem exteriormente em vez de a receberem em si, não lhes seriam os
sentidos potências passivas como presentemente são, mas uma virtude diversa que lhes foi dada; ora,
assim como a matéria nunca pode vir a ser forma, assim uma potência passiva não poderá jamais vir a
ser ativa.
Por isso pretendem outros que os sentidos dos ressurrectos se lhes atualizará por suscepção, não certo
de sensíveis externos, mas por efluxo de forças superiores; de modo que, assim como na vida presente
as potências inferiores recebem o influxo das superiores, assim ao contrário, serão então as inferiores
que o hão de receber das superiores. ─ Mas este modo de receber não faz realmente sentir. Porque
todas as potências passivas segundo a sua natureza específica são determinadas a uma atividade
especial; pois, uma potência como tal se ordena à cousa donde lhe derivou o nome. Ora, o objeto ativo
e próprio dos sentidos externos é a causa existente fora da alma e não a imagem dela existente na
imaginação ou na razão. Por onde, se o órgão do sentido não for movido pelas cousas externas, mas
pela imaginação ou por qualquer potência superior, não haverá verdadeiro ato de sentir. Por isso não se
pode dizer que os frenéticos e outros mentecaptos, nos quais a predominância da imaginação faz
decorrerem as espécies para os órgãos sensíveis, sintam verdadeiramente, mas dizemos que imaginam
sentir.
Por onde, devemos responder, com outros, que os corpos gloriosos exercerão a sua sensibilidade pela
suscepção do ato dos objetos exteriores à alma.
Devemos porém saber, que os órgãos dos sentidos podem ser modificados pelos objetos externos à
alma de dois modos. Primeiro, por modificação natural, quando o órgão dispõe-se pela mesma
qualidade natural do objeto exterior à alma, que age sobre ele. Assim, quando a mão se aquece pelo
contato com um corpo quente ou sente um cheiro pelo contato com um corpo odorífero. De outro
modo, por uma modificação espiritual, quando um órgão recebe a qualidade sensível no seu ser
espiritual, i. é, a espécie ou a imagem da qualidade, e não a qualidade em si mesma; assim a pupila
recebe a imagem de um corpo branco sem contudo tornar-se branca. Ora, a primeira espécie de
percepção não produz a sensação, propriamente falando; porque o sentido é capaz de receber as
espécies na matéria, mas separadas da matéria, i. é, sem o ser material que tem fora da alma, como
ensina Aristóteles. E essa percepção modifica a natureza do recipiente, porque desse modo a qualidade
é recebida no seu ser material; por isso não existirá nos corpos gloriosos. Mas sim a segunda espécie de
percepção, que em si mesma, atualiza o sentido sem alterar a natureza do sujeito que a recebe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Como já resulta do sobredito, a paixão implicada no ato
de sentir, que outra cousa não é senão a referida percepção, não altera o estado natural do corpo na
sua qualidade, mas o aperfeiçoa espiritualmente. Por isso a impassibilidade dos corpos gloriosos não
exclui essa paixão.

RESPOSTA À SEGUNDA. ─ Todo sujeito passivo recebe a seu modo a ação do agente. Se, pois, um ser é
de natureza a poder receber uma modificação de um agente natural e espiritual, a modificação natural
precederá à espiritual, como o ser natural precede ao intencional. Mas se é de natureza a receber
somente uma modificação espiritual, não há mister de ser modificado naturalmente. Tal o caso do ar,
incapaz de receber a cor no seu ser natural senão só no espiritual, modificando-se pois só deste último
modo. Inversamente, os corpos inanimados só naturalmente podem ser modificados pelas qualidades
sensíveis, e não espiritualmente. Ora, os corpos gloriosos não podem sofrer nenhuma modificação
natural. Só poderão portanto recebê-las espirituais.

RESPOSTA À TERCEIRA. ─ Na medida em que um órgão sensível receber uma nova espécie, nessa
mesma o sentido comum, mas não o intelecto, formará um novo juízo sobre o objeto. Tal o caso de
quem vê o que antes não conhecia. Quanto ao dito de Agostinho ─ não haverá então mudança de
pensamentos ─ deve ser entendido dos pensamentos da parte intelectiva. Logo, não colhe a objeção.

RESPOSTA À QUARTA. ─ Quando de duas cousas uma é a causa da outra, a atenção da alma aplicada a
uma não lhe impede nem lhe diminui a atenção aplicada à outra. Assim, um médico, ao mesmo tempo
que examina a urina, pode também considerar as regras da arte concernente à cor dela, e mesmo até
melhor. Ora, Deus é concebido pelos santos como a razão de tudo o que fazem ou conhecem; por isso
os atos da virtude sensitiva, da contemplativa ou da ativa, em nada lhes podem impedir a contemplação
divina, nem inversamente. ─ Ou podemos responder, que uma potência fica impedida no seu ato pela
atividade intensa de outra, porque uma por si não é capaz de uma operação tão intensa sem que as
outras ou os outros órgãos paguem um tributo do influxo do princípio vital que lhes cabia. E como os
santos terão todas as suas potências perfeitíssimas, uma poderá exercer intensamente a sua atividade,
sem que daí resulte qualquer obstáculo ao ato de outra. Tal se deu com Cristo.

## Art. 4 — Se os corpos gloriosos exercerão os atos de todos os sentidos.
O quarto discute-se assim. Parece que os corpos gloriosos não exercerão os atos de todos os sentidos.

1. ─ Pois, o tato é o primeiro de todos os sentidos, como diz Aristóteles. Ora, os corpos gloriosos não
terão absolutamente o sentido do tato, porque esse sentido se opõe em ato pela modificação do corpo
animal proveniente de um corpo externo preponderante por uma virtude ativa ou passiva que o tato
deve discernir. Mas os corpos gloriosos não são susceptíveis dessa modificação. Logo, nenhum será o
sentido do tato.

2. Demais. ─ O sentido do gosto serve à atividade nutritiva. Ora, depois da ressurreição não mais se
exercerá essa atividade. Logo, é inútil o sentido do gosto.

3. Demais. ─ Depois da ressurreição nada se corromperá, porque toda criatura será revestida de uma
virtude incorruptível. Ora, o sentido do olfato não pode exercer-se senão com a produção de alguma
corrupção; pois, o odor não pode ser sentido sem uma espécie de evaporação semelhante ao fumo, que
consiste numa resolução de elementos. Logo, o sentido do olfato não se exercerá nos corpos gloriosos.

4. Demais. ─ O ouvido serve para a aprendizagem, como diz Aristóteles. Ora, depois da ressurreição, os
bem-aventurados não necessitam de aprender nada por meios sensíveis; porque estarão cheios da
sabedoria divina, pela visão mesma de Deus. Logo, não se exercerá então o sentido do ouvido.

5. Demais. ─ A vista se exerce quando a pupila recebe a imagem da cousa vista. Ora, tal não podem os
bem─aventurados depois da ressurreição. Logo, não exercerão a atividade da visão, que contudo é o
mais nobre de todos os sentidos. Prova da média. O que é atualmente lúcido não pode receber uma
imagem visível; por isso um espelho diretamente colocado contra um raio solar não pode reproduzir a
imagem de outros objetos. Ora, a pupila dos bem-aventurados, na ressurreição, bem como todo o corpo
deles, terá o dom da claridade. Logo, não poderá receber nenhuma imagem de corpo colorido.

6. Demais. ─ Como o verifica a perspectiva, tudo o que vemos o vemos sob um certo ângulo. Ora, isto
não é possível aos corpos gloriosos. Logo, não exercerão a atividade do sentido da vista. ─ Prova da
média. Sempre que vemos uma causa sob certo ângulo, é mister haver proporção entre o ângulo e a
distância do objeto visto. Porque uma causa vista de mais longe é menos vista e sobre um menor
ângulo. E poderia o ângulo ser a tal ponto pequeno, que nada visse. Se, portanto, os olhos dos corpos
gloriosos vêem sob um ângulo, há de por força, ver numa distância determinada; e de modo que nada
veja em distância maior que aquela em que podemos nós ver. O que é de todo absurdo. Donde pois, se
conclui, que nos corpos gloriosos não se exercerá o sentido da vista.
Mas, em contrário. ─ A potência atualizada é mais perfeita que a pura potência. Ora, a natureza humana
será maximamente perfeita nos bem-aventurados. Logo, exercerão a atividade de todos os sentidos.

2. Demais. ─ As potências sensitivas se avizinham mais da alma que o corpo. Ora, o corpo será premiado
ou punido pelos méritos ou deméritos da alma. Logo, também todos os sentidos serão premiados nos
bem aventurados e punidos nos maus, conforme o prazer e a dor ou tristeza implicados na atividade
deles sentidos.

SOLUÇÃO. ─ Duas opiniões há sobre este assunto.
Uns dizem que os corpos gloriosos terão todas as potências dos sentidos, mas só exercerão a atividade
de dois: o tato e a vista. Nem será isso por deficiência dos sentidos, mas, do meio e do objeto. Mas não
serão esses outros sentidos inúteis, porque servirão de integrar a natureza humana e a proclamar a
sabedoria do Criador. ─ Mas esta opinião não é verdadeira. Porque o que serve de meio aos dois
sentidos, de tato e da vista, serve também aos outros. Assim, o meio da vista é o ar, meio também do
ouvido e do olfato, como o mostra Aristóteles. Também o gosto, sendo uma espécie de tato, tem o
mesmo meio deste, como explica ainda o Filósofo. O olfato também o terão os bem-aventurados, pois a
Igreja canta que os corpos dos santos exalarão um odor suavíssimo. Louvores vocais também os haverá
na pátria. Donde o dizer Agostinho, àquilo da Escritura ─ Altos louvores de Deus se acham na sua boca:
Os corações e as línguas não acabarão nunca de louvar a Deus. E o mesmo também diz a Glosa àquele
outro lugar: Em cânticos e a toque de tímbales.
Por isso, segundo outros, devemos admitir que os santos exercerão também os sentidos do olfato e do
ouvido. Mas não o gosto de modo que sinta a comida ou a bebida tomadas, como do sobredito resulta.
Salvo se se disser que exercerão a atividade do gosto pela ação de alguma umidade exterior sobre a
língua.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As qualidades percebidas pelo tato são as de que se
constitui o corpo animal. O corpo animal tem, pois, na vida presente, uma natureza tal, que pode
receber do objeto do tato, pelas qualidades tangíveis, tanto a modificação natural como a espiritual. Por
isso o sentido do tato é considerado o mais material de todos os sentidos, porque produz no corpo uma
modificação mais material. Entretanto, como o ato da sensação se perfaz na modificação espiritual, não
implica senão acidentalmente a modificação material. Por onde, os corpos gloriosos, que excluem pela
sua impassibilidade a modificação material, serão modificados apenas espiritualmente pelas qualidades
tangíveis. O que também se deu com o corpo de Adão, que nem o fogo podia queimar nem uma espada
cortar; e contudo sentia a ação desses agentes.

RESPOSTA À SEGUNDA. ─ Os santos não terão o sentido do gosto enquanto dá a sensação dos
alimentos. Mas enquanto serve para julgar dos sabores, poderão talvez exercê-lo, do modo referido.

RESPOSTA À TERCEIRA. ─ Certos ensinaram que o odor outra cousa não é senão uma evaporação à
guisa de fumo. Mas esta doutrina não pode ser verdadeira. Como o demonstra o fato de os abutres
acorrerem de lugares remotíssimos ao sentirem o cheiro dos cadáveres; e contudo, não seria possível a
qualquer evaporação chegar de um cadáver a tão remotos lugares, mesmo se todo ele se resolvesse em
vapor; sobretudo que os sensíveis, a igual distância, causam alterações igualmente em todas as
direções. O odor pode, pois, algumas vezes alterar o meio e produzir no órgão a modificação espiritual
sem o contato de nenhuma evaporação; e se a evaporação é necessária é que o odor fica retido nos
corpos pela umidade, e por isso não pode ser percebido sem uma espécie de dissolução que o ponha
em liberdade. Mas os corpos gloriosos terão o olfato na sua última perfeição, e de nenhum modo
comprimido. E por si mesmo causará a modificação espiritual, como o faz o odor pela evaporação fumal.
E assim os santos com o seu sentido do olfato, não impedido por nenhuma umidade, conhecerão não só
as excelências dos odores, como se dá conosco, por causa da excessiva umidade do nosso cérebro, mas
também as diferenças mínimas entre eles.

RESPOSTA À QUARTA. ─ Cânticos de louvor se farão ouvir na pátria, embora alguns digam o contrário, e
os seus acentos causarão no órgão do ouvido dos bem-aventurados somente uma modificação
espiritual. Nem será por aprendizagem que adquirirão a ciência, mas pela perfeição do sentido e pelo
prazer. Mas no céu poderá haver voz, já o dissemos.

RESPOSTA À QUINTA. ─ A intensidade de uma luz não impede a recepção espiritual da espécie da cor,
contanto que ela conserve a sua natureza diáfana. E isso o demonstra o fato de, por mais iluminado que
esteja o ar, poder ainda ser o meio através do qual exercemos a visão; e quanto mais iluminado tanto
mais claramente enxergamos, salvo se a nossa vista estiver enfraquecida por algum defeito. Quanto ao
espelho que, colocado diretamente contra o raio solar, não reflete a figura de nenhum outro corpo, não
é por ficar impedido de receber a imagem deste, mas por ficar privado da reverberação. Pois, é
necessária, para uma forma aparecer num espelho, uma certa reverberação produzida por um corpo
obscuro; por isso ao vidro do espelho se lhe coloca posteriormente uma folha de chumbo. Mas o raio
solar dissipa a obscuridade desta, e por isso não pode o espelho refletir nenhuma imagem. A claridade
do corpo glorioso porém não priva a pupila da sua diafaneidade, porque a glória não destrói a natureza.
Por isso uma claridade intensa sobre a pupila, longe de enfraquecer a visão, a torna mais aguda.

RESPOSTA À SEXTA. ─ Tanto mais perfeito é um sentido, tanto melhor pode perceber o seu objeto, com
uma fraca impressão. E menor é o ângulo sob a qual a vista é modificada pelo objeto visível, tanto
menor é a modificação que causa. Donde vem que uma vista forte pode enxergar mais longe que uma
fraca; porque o ângulo visual é tanto menor quanto maior é a distância. E como os corpos gloriosos
gozam de uma vista perfeitíssima, poderão ver, mesmo se o órgão visual lhes é ferido por uma
modificação mínima. Por isso poderão enxergar então sob um ângulo muito menor do que o podem
presentemente; e por consequência, de muito mais longe.