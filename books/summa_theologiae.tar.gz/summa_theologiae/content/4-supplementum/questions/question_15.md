# Questão 15: Dos meios pelos quais satisfazemos.
Em seguida devemos tratar dos meios pelos quais satisfazemos.
E nesta questão discutem-se três artigos:

## Art. 1 — Se a satisfação há de dar-se por obras penais.
O primeiro discute-se assim. ─ Parece que a satisfação não há de dar-se por obras penais.

1. ─ Pois, a satisfação há de ser uma compensação pela ofensa a Deus. Ora, nenhuma compensação
pode dar-se por meio de obras penais, porque Deus não se deleita com os nossos males. Logo, não é por
obras penais que se há de dar satisfação.

2. Demais. ─ Quanto maior a caridade donde procede uma obra, tanto menos penal ela é, pois, na
caridade não há temor, como diz a Escritura. Se portanto, as obras satisfatórias hão de ser penais,
quanto mais se inspirarem na caridade tanto menos satisfatórias serão. O que é falso.

3. Demais. ─ Satisfazer, como diz Anselmo, é dar a honra devida a Deus. Ora, isso pode ser feito de outro
modo que não por obras penais. Logo, a satisfação não há de fazer-se por obras penais.
Mas, em contrário, diz Gregório: Justo é que o pecador chore tanto mais os seus pecados pela
penitência, quanto maior se fez mal a si mesmo por eles.

2. Demais. ─ A satisfação deve curar perfeitamente a chaga do pecado. Ora, as penas são o remédio dos
pecados. Logo, pelas obras penais é que devemos dar satisfação.

SOLUÇÃO. ─ A satisfação concerne a ofensa passada, pela qual ela dá uma compensação; e também a
culpa futura, da qual por ela nos preservamos. Ora, de ambos esses modos há de a satisfação dar-se por
meio de obras penais. ─ Assim, a compensação pela ofensa implica uma igualdade que há de ser entre o
ofensor e a vítima da ofensa. Ora, a igualdade, na justiça humana, se produz subtraindo a quem tem
mais do que o justo para adicionar a quem sofreu a subtração. Ora, embora a Deus, como tal, nada
possa ser tirado, contudo o pecador, na medida do seu possível, subtrai-lhe alguma causa pecando,
como se disse. Por onde, é necessário, a fim de haver compensação, que algo seja tirado ao pecador,
pela satisfação, que redunda em glória de Deus. A obra boa porém, como tal, de nada priva ao seu
autor, mas antes, o aperfeiçoa. Portanto, subtração não pode ser feita por uma obra boa, senão penal. E
assim, para uma obra ser satisfatória, há de ser boa, para redundar em glória de Deus; e penal, para
assim o pecador sofrer uma privação. ─ Semelhantemente, a pena preserva da culpa futura, pois não
facilmente voltamos a pecar desde que sofremos uma pena. Por isso, segundo o Filósofo, as penas são
remédios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora Deus não se deleite com os nossos males,
enquanto penas, deleita-se contudo com elas enquanto justas. E assim, podem ser satisfatórias.

RESPOSTA À SEGUNDA. ─ Assim como na satisfação se considera a penalidade, assim no mérito, a
dificuldade. Ora, a diminuição da dificuldade relativa ao ato mesmo, diminui em igualdade de
circunstâncias, o mérito; mas a diminuição da dificuldade relativa à presteza da vontade, longe de
diminuir, aumenta o mérito. Semelhantemente, a diminuição da penalidade, quanto à presteza da
vontade, produzida pela caridade, não diminui a eficácia da satisfação, mas a aumenta.

RESPOSTA À TERCEIRA. ─ O débito pelo pecado cometido é uma compensação da ofensa, que não vai
sem pena para o pecador. E é a esse débito que se refere Anselmo.

## Art. 2 — Se os flagelos com que somos punidos por Deus nesta vida podem ser satisfatórios.
O segundo discute-se assim. ─ Parece que os flagelos por que somos punidos por Deus nesta vida não
podem ser satisfatórios.

1. ─ Pois, satisfatório não pode ser senão o que é meritório, como do sobredito resulta. Ora, não
podemos merecer senão pelo que em nós existe. Logo, como os flagelos pelos quais somos punidos por
Deus não existem em nós, parece que não podem ser satisfatórios.

2. Demais. ─ A satisfação é obra só própria dos bons. Ora, os tais flagelos recaem também sobre os maus
e sobre eles devem principalmente recair. Logo, não podem ser satisfatórios.

3. Demais. ─ A satisfação concerne os pecados passados. Ora, às vezes esses flagelos recaem sobre
quem não tem pecado, como se deu com Jó. Logo, parece que não são satisfatórios.
Mas, em contrário, o Apóstolo: A tribulação produz paciência, e a paciência experiência, isto é,
purificação dos pecados, como o expõe a Glosa. Logo, os flagelos desta vida purificam dos pecados.
Portanto, são satisfatórios.

2. Demais. ─ Ambrósio diz: Embora a fé, isto é, a consciência do pecado, falte, a pena satisfaz. Logo, os
flagelos desta vida são satisfatórios.

SOLUÇÃO. ─ A compensação pela ofensa passada pode ser dada por quem ofendeu, e por outrem.
Quando dada por outrem, essa compensação tem natureza, antes, de vingança, que de satisfação;
quando porém dada pelo ofensor mesmo, tem também natureza de satisfação. Por onde, se os flagelos,
que Deus às vezes inflige pelos pecados, se tornem de certo modo do próprio paciente, assumem a
natureza de satisfação Ora, o paciente os apropria a si quando os aceita para se purificar dos seus
pecados, sofrendo-os com paciência. Mas, se, com impaciência, recalcitrar contra eles, então de
nenhum modo se lhe tornam próprios. Por isso não assumem, a natureza de satisfação, mas só de
vingança.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora os flagelos de nenhum modo dependam da nossa
vontade, têm contudo a finalidade de serem sofridos por nós pacientemente. E assim fazemos da
necessidade virtude. Por onde, podem ser meritórios e satisfatórios.

RESPOSTA À SEGUNDA. ─ Como, no dizer de Agostinho, o mesmo fogo que torna o ouro incandecente
queima a palha, assim também contra os mesmos flagelos, que purificam os bons, os maus se rebelam
com impaciência. Por onde embora os flagelos sejam comuns, contudo servem só aos bons de
satisfação.

RESPOSTA À TERCEIRA. ─ Os flagelos concernem sempre à culpa passada; mas nem sempre a uma culpa
pessoal, porque podem ser provocados por culpa da natureza. Pois, se nenhuma culpa preexistisse na
natureza humana, nenhuma pena haveria. Como porém a culpa precedeu na natureza, Deus faz recair a
pena sobre uma determinada pessoa, sem culpa dela, para mérito da virtude e cautela do pecado
futuro. E esses são dois elementos necessários da satisfação Pois, há de a obra ser meritória para dar
glória a Deus; e é mister seja guarda das virtudes, para ficarmos preservados dos pecados futuros.

## Art. 3 — Se se enumeram convenientemente as obras satisfatórias, quando se diz que são três: a esmola, o jejum e a oração.
O terceiro discute-se assim. ─ Parece que não se enumeram convenientemente as obras satisfatórias,
quando se diz que são três: a esmola, o jejum e a oração.
1 ─ Pois, uma obra satisfatória deve ser penal. Ora, nenhuma oração supõe qualquer pena pois é
remédio contra a tristeza da pena ─ mas sim o prazer. Por isso diz a Escritura: Está triste algum de vós?
Ore. Esta alegre? Cante Louvores a Deus. Logo não deve a oração ser computada entre as obras
satisfatórias.

2. Demais. ─ Todo pecado ou é carnal ou espiritual. Ora, como diz Jerônimo, o jejum cura as doenças do
corpo; a oração, os da alma. Logo, não há necessidade de nenhuma outra obra satisfatória.

3. Demais. ─ A satisfação é necessária para a purificação dos pecados. Ora, a esmola purifica de todos os
pecados, na expressão do Evangelho: Dai esmola e eis aí que todas as coisas vos ficam limpas. Logo, as
outras duas obras são supérfluas.
Mas, em contrário. ─ Parece que devem ser várias.

1. ─ Pois, os contrários se curam. Ora, muito mais que três são os gêneros dos pecados. Logo devem-se
contar várias obras satisfatórias.

2. Demais. ─ Também se impõem, como satisfação as peregrinações e as disciplinas ou flagelações, que
não estão na enumeração supra. Logo, essa enumeração é incompleta.

SOLUÇÃO. ─ A satisfação deve ser tal que nos prive de alguma causa, para glória de Deus. Ora, nós não
temos senão três espécies de bens: os do corpo, os da alma e os da fortuna ou externos. Da parte dos
bens da fortuna nos privamos pela esmola; e da parte dos bens do corpo, pelo jejum. Quanto aos bens
da alma, não é necessário que essencialmente nos privemos deles em nada, ou que soframos qualquer
diminuição dos mesmos, pois, por eles tornamo-nos aceitos de Deus; mas basta que os subordinemos
totalmente a Deus. E isto fazemos pela oração. Também a enumeração referida se funda em que a
satisfação extirpa as causas dos pecados. Pois, as raízes dos pecados são três, conforme o Evangelho:
concupiscência da carne, concupiscência dos olhos e soberba da vida. Contra a concupiscência da carne
se ordena o jejum; contra a dos olhos, a esmola; contra a soberba da vida, a oração, como ensina
Agostinho.
Também é boa a enumeração supra quanto a consistir a satisfação em não permitir a entrada à
sugestão dos pecados. Porque todo pecado ou o cometemos contra Deus, e a isso se ordena a oração;
ou contra o próximo, e contra ele se ordena a esmola; ou contra nós mesmos ao que se ordena o jejum.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Segundo certos há duas espécies de oração. Uma, dos
contemplativos, cuja conversação está nos céus; e essa, totalmente deleitável, não é satisfatória. Outra,
a que derrama gemidos pelos pecados, e essa implica uma pena e faz parte da satisfação. ─ Ou diremos
e melhor, que qualquer oração constitui obra satisfatória porque, embora tenha a suavidade do espírito,
tem contudo a mortificação da carne. Pois, como diz Gregório, à medida que se fortifica em nós o amor
íntimo, enfraquece sem dúvida o poder da carne. Por isso, também, como lemos na Escritura, o nervo
da coxa de Jacob secou na luta com o Anjo.

RESPOSTA À SEGUNDA. ─ O pecado carnal é susceptível de duplo sentido. Num, é o que se consuma na
deleitação mesma da carne, como a gula e a luxúria. Noutro, o que se perfaz no que se ordena para a
carne, embora não consista no prazer carnal, mas no da alma, como a avareza. Por isso tais pecados são
como o meio termo entre os espirituais e os carnais. Por onde, há de corresponder-lhes alguma
satisfação própria, a saber, a esmola.

RESPOSTA À TERCEIRA. ─ Embora cada uma das três obras enumeradas se aproprie, por uma certa
conveniência, a cada pecado, por ser congruente que pelas coisas em que alguém peca, por essas seja
também atormentado, e que pela satisfação seja arrancada a raiz do pecado cometido, contudo
qualquer das obras enumeradas pode satisfazer por qualquer pecado. Por isso, quem não puder praticar
uma dessas obras, se lhe imponha outra e sobretudo a esmola, que pode fazer às vezes das outras,
enquanto as outras obras satisfatórias de certo modo as compramos com a esmola, nas pessoas a quem
as damos. Mas não é por a esmola purificar de todos os pecados que serão supérfluas as outras
satisfações.

RESPOSTA À QUARTA. ─ Embora haja especificamente muitos pecados, contudo vêm a se reduzir todos
a essas três raízes ou a esses três gêneros deles, aos quais dissemos corresponderem as referidas
satisfações.

RESPOSTA À QUINTA. ─ Tudo o que mortifica o corpo vem a cair no jejum; e tudo o que aplicamos a
utilidade do próximo, se inclui na esmola; e semelhantemente, todo culto de latria prestado a Deus
assume a natureza da oração. Por onde, também uma mesma obra pode ser satisfatória por várias
razões.